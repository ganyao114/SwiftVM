00007c47757ce69b  nop [rax+rax*1], eax
00007c47757ce6a0  vmovaps xmm1, [0x00007C47753FE010]
00007c47757ce6a8  movq xmm1, xmm1
00007c47757ce6ac  movaps [r15+0x110], xmm1
00007c47757ce6b4  vmovaps xmm1, [0x00007C47753FE020]
00007c47757ce6bc  movq xmm1, xmm1
00007c47757ce6c0  movaps [r15+0x120], xmm1
00007c47757ce6c8  mov eax, 0x4204C0
00007c47757ce6cd  mov r14, [r13+rax*1]
00007c47757ce6d2  movq xmm1, r14
00007c47757ce6d7  movaps [r15+0x130], xmm1
00007c47757ce6df  vmovaps xmm1, [0x00007C47753FE030]
00007c47757ce6e7  vpbroadcastq xmm1, xmm1
00007c47757ce6ec  movaps [r15+0x140], xmm1
00007c47757ce6f4  mov qword ptr [r15+0x40], 0x02
00007c47757ce6fc  vmovaps xmm15, [0x00007C47753FE040]
00007c47757ce704  movq xmm15, xmm15
00007c47757ce709  movaps [r15+0x150], xmm15
00007c47757ce711  mov qword ptr [r15+0x58], 0x420000
00007c47757ce719  vmovaps xmm15, [0x00007C47753FE050]
00007c47757ce721  vpbroadcastq xmm15, xmm15
00007c47757ce726  movaps [r15+0x160], xmm15
00007c47757ce72e  mov rax, [r15+0x40]
00007c47757ce732  vmovq xmm14, rax
00007c47757ce737  vpbroadcastq xmm14, xmm14
00007c47757ce73c  movaps [r15+0x170], xmm14
00007c47757ce744  mov eax, 0x4204D0
00007c47757ce749  movups xmm13, [r13+rax*1]
00007c47757ce74f  mov qword ptr [r15+0x40], 0x430518
00007c47757ce757  mov qword ptr [r15+0x50], 0x430720
00007c47757ce75f  vpmovqd xmm12, xmm13
00007c47757ce765  pxor xmm11, xmm11
00007c47757ce76a  punpcklqdq xmm12, xmm11
00007c47757ce76f  movaps [r15+0x210], xmm12
00007c47757ce777  movq xmm12, qword ptr [r15+0x120]
00007c47757ce780  movq xmm11, qword ptr [r15+0x130]
00007c47757ce789  psubd xmm12, xmm11
00007c47757ce78e  movq xmm12, xmm12
00007c47757ce793  paddq xmm13, xmm14
00007c47757ce798  movaps [r15+0x180], xmm13
00007c47757ce7a0  movq xmm14, qword ptr [r15+0x150]
00007c47757ce7a9  paddd xmm11, xmm14
00007c47757ce7ae  movq xmm11, xmm11
00007c47757ce7b3  movq xmm11, xmm11
00007c47757ce7b8  movaps [r15+0x130], xmm11
00007c47757ce7c0  pmovzxdq xmm12, xmm12
00007c47757ce7c6  psllq xmm12, 0x00
00007c47757ce7cc  movq xmm14, qword ptr [r15+0x210]
00007c47757ce7d5  movq xmm13, qword ptr [r15+0x110]
00007c47757ce7de  paddd xmm14, xmm13
00007c47757ce7e3  movq xmm14, xmm14
00007c47757ce7e8  vcvtuqq2pd xmm12, xmm12
00007c47757ce7ee  pmovzxdq xmm14, xmm14
00007c47757ce7f4  psllq xmm14, 0x00
00007c47757ce7fa  vcvtuqq2pd xmm14, xmm14
00007c47757ce800  movaps xmm13, xmm12
00007c47757ce804  mulpd xmm13, xmm1
00007c47757ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007c47757ce80f  ptest xmm11, xmm11
00007c47757ce815  jnz 0x00007C47757CE8FF
00007c47757ce81b  movaps [r15+0x220], xmm13
00007c47757ce823  mov eax, 0x430720
00007c47757ce828  movups [r13+rax*1], xmm13
00007c47757ce82e  movaps xmm1, xmm14
00007c47757ce832  mulpd xmm1, xmm15
00007c47757ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007c47757ce83c  ptest xmm13, xmm13
00007c47757ce842  jnz 0x00007C47757CEA4C
00007c47757ce848  movaps [r15+0x210], xmm1
00007c47757ce850  mov eax, 0x430518
00007c47757ce855  movups [r13+rax*1], xmm1
00007c47757ce85b  mov qword ptr [r15+0x48], 0x10
00007c47757ce863  xor eax, eax
00007c47757ce865  mov r14d, 0x10
00007c47757ce86b  mov r12d, 0x200
00007c47757ce871  cmp r14, r12
00007c47757ce874  cmc
00007c47757ce875  lahf
00007c47757ce876  seto al
00007c47757ce879  mov [r15+0x108], eax
00007c47757ce880  mov eax, [r15+0x108]
00007c47757ce887  sahf
00007c47757ce888  jnz 0x00007C47757CE8BA
00007c47757ce88a  cmp dword ptr [r15+0x318], 0x00
00007c47757ce892  jz 0x00007C47757CEFF0
00007c47757ce898  nop [rax+rax*1], ax
00007c47757ce8a1  nop [rax+rax*1], eax
00007c47757ce8a9  mov eax, 0x4101EC
00007c47757ce8ae  mov [r15+0x100], rax
00007c47757ce8b5  jmp 0x00007C47755FE110
00007c47757ce8ba  cmp dword ptr [r15+0x318], 0x00
00007c47757ce8c2  jz 0x00007C47757CEBA0
00007c47757ce8c8  nop [rax+rax*1], ax
00007c47757ce8d1  nop [rax+rax*1], eax
00007c47757ce8d9  mov eax, 0x4101AC
00007c47757ce8de  mov [r15+0x100], rax
00007c47757ce8e5  jmp 0x00007C47755FE110
00007c47757ce8ea  int3
00007c47757ce8eb  call 0x00007C477560DC20
00007c47757ce8f0  jmp 0x00007C47757CE6D2
00007c47757ce8f5  call 0x00007C477560C260
00007c47757ce8fa  jmp 0x00007C47757CE74F
00007c47757ce8ff  sub rsp, 0x08
00007c47757ce903  push rax
00007c47757ce904  push rcx
00007c47757ce905  push rdx
00007c47757ce906  push rdi
00007c47757ce907  push rsi
00007c47757ce908  push r8
00007c47757ce90a  push r9
00007c47757ce90c  push r10
00007c47757ce90e  push r11
00007c47757ce910  sub rsp, 0xF0
00007c47757ce917  vmovaps [rsp], xmm0
00007c47757ce91c  vmovaps [rsp+0x10], xmm1
00007c47757ce922  vmovaps [rsp+0x20], xmm2
00007c47757ce928  vmovaps [rsp+0x30], xmm3
00007c47757ce92e  vmovaps [rsp+0x40], xmm4
00007c47757ce934  vmovaps [rsp+0x50], xmm5
00007c47757ce93a  vmovaps [rsp+0x60], xmm6
00007c47757ce940  vmovaps [rsp+0x70], xmm7
00007c47757ce946  vmovaps [rsp+0x80], xmm8
00007c47757ce94f  vmovaps [rsp+0x90], xmm9
00007c47757ce958  vmovaps [rsp+0xA0], xmm10
00007c47757ce961  vmovaps [rsp+0xB0], xmm11
00007c47757ce96a  vmovaps [rsp+0xC0], xmm12
00007c47757ce973  vmovaps [rsp+0xD0], xmm14
00007c47757ce97c  vmovaps [rsp+0xE0], xmm15
00007c47757ce985  sub rsp, 0x30
00007c47757ce989  movaps [rsp], xmm13
00007c47757ce98e  movaps [rsp+0x10], xmm12
00007c47757ce994  movaps [rsp+0x20], xmm1
00007c47757ce999  lea rdi, [rsp]
00007c47757ce99d  mov esi, 0x00
00007c47757ce9a2  mov rax, 0x62084E409530
00007c47757ce9ac  call rax
00007c47757ce9ae  movaps xmm13, [rsp]
00007c47757ce9b3  add rsp, 0x30
00007c47757ce9b7  vmovaps xmm0, [rsp]
00007c47757ce9bc  vmovaps xmm1, [rsp+0x10]
00007c47757ce9c2  vmovaps xmm2, [rsp+0x20]
00007c47757ce9c8  vmovaps xmm3, [rsp+0x30]
00007c47757ce9ce  vmovaps xmm4, [rsp+0x40]
00007c47757ce9d4  vmovaps xmm5, [rsp+0x50]
00007c47757ce9da  vmovaps xmm6, [rsp+0x60]
00007c47757ce9e0  vmovaps xmm7, [rsp+0x70]
00007c47757ce9e6  vmovaps xmm8, [rsp+0x80]
00007c47757ce9ef  vmovaps xmm9, [rsp+0x90]
00007c47757ce9f8  vmovaps xmm10, [rsp+0xA0]
00007c47757cea01  vmovaps xmm11, [rsp+0xB0]
00007c47757cea0a  vmovaps xmm12, [rsp+0xC0]
00007c47757cea13  vmovaps xmm14, [rsp+0xD0]
00007c47757cea1c  vmovaps xmm15, [rsp+0xE0]
00007c47757cea25  add rsp, 0xF0
00007c47757cea2c  pop r11
00007c47757cea2e  pop r10
00007c47757cea30  pop r9
00007c47757cea32  pop r8
00007c47757cea34  pop rsi
00007c47757cea35  pop rdi
00007c47757cea36  pop rdx
00007c47757cea37  pop rcx
00007c47757cea38  pop rax
00007c47757cea39  add rsp, 0x08
00007c47757cea3d  jmp 0x00007C47757CE81B
00007c47757cea42  call 0x00007C477560C380
00007c47757cea47  jmp 0x00007C47757CE82E
00007c47757cea4c  sub rsp, 0x08
00007c47757cea50  push rax
00007c47757cea51  push rcx
00007c47757cea52  push rdx
00007c47757cea53  push rdi
00007c47757cea54  push rsi
00007c47757cea55  push r8
00007c47757cea57  push r9
00007c47757cea59  push r10
00007c47757cea5b  push r11
00007c47757cea5d  sub rsp, 0xF0
00007c47757cea64  vmovaps [rsp], xmm0
00007c47757cea69  vmovaps [rsp+0x10], xmm2
00007c47757cea6f  vmovaps [rsp+0x20], xmm3
00007c47757cea75  vmovaps [rsp+0x30], xmm4
00007c47757cea7b  vmovaps [rsp+0x40], xmm5
00007c47757cea81  vmovaps [rsp+0x50], xmm6
00007c47757cea87  vmovaps [rsp+0x60], xmm7
00007c47757cea8d  vmovaps [rsp+0x70], xmm8
00007c47757cea93  vmovaps [rsp+0x80], xmm9
00007c47757cea9c  vmovaps [rsp+0x90], xmm10
00007c47757ceaa5  vmovaps [rsp+0xA0], xmm11
00007c47757ceaae  vmovaps [rsp+0xB0], xmm12
00007c47757ceab7  vmovaps [rsp+0xC0], xmm13
00007c47757ceac0  vmovaps [rsp+0xD0], xmm14
00007c47757ceac9  vmovaps [rsp+0xE0], xmm15
00007c47757cead2  sub rsp, 0x30
00007c47757cead6  movaps [rsp], xmm1
00007c47757ceada  movaps [rsp+0x10], xmm14
00007c47757ceae0  movaps [rsp+0x20], xmm15
00007c47757ceae6  lea rdi, [rsp]
00007c47757ceaea  mov esi, 0x00
00007c47757ceaef  mov rax, 0x62084E409530
00007c47757ceaf9  call rax
00007c47757ceafb  movaps xmm1, [rsp]
00007c47757ceaff  add rsp, 0x30
00007c47757ceb03  vmovaps xmm0, [rsp]
00007c47757ceb08  vmovaps xmm2, [rsp+0x10]
00007c47757ceb0e  vmovaps xmm3, [rsp+0x20]
00007c47757ceb14  vmovaps xmm4, [rsp+0x30]
00007c47757ceb1a  vmovaps xmm5, [rsp+0x40]
00007c47757ceb20  vmovaps xmm6, [rsp+0x50]
00007c47757ceb26  vmovaps xmm7, [rsp+0x60]
00007c47757ceb2c  vmovaps xmm8, [rsp+0x70]
00007c47757ceb32  vmovaps xmm9, [rsp+0x80]
00007c47757ceb3b  vmovaps xmm10, [rsp+0x90]
00007c47757ceb44  vmovaps xmm11, [rsp+0xA0]
00007c47757ceb4d  vmovaps xmm12, [rsp+0xB0]
00007c47757ceb56  vmovaps xmm13, [rsp+0xC0]
00007c47757ceb5f  vmovaps xmm14, [rsp+0xD0]
00007c47757ceb68  vmovaps xmm15, [rsp+0xE0]
00007c47757ceb71  add rsp, 0xF0
00007c47757ceb78  pop r11
00007c47757ceb7a  pop r10
00007c47757ceb7c  pop r9
00007c47757ceb7e  pop r8
00007c47757ceb80  pop rsi
00007c47757ceb81  pop rdi
00007c47757ceb82  pop rdx
00007c47757ceb83  pop rcx
00007c47757ceb84  pop rax
00007c47757ceb85  add rsp, 0x08
00007c47757ceb89  jmp 0x00007C47757CE848
00007c47757ceb8e  call 0x00007C47755FF540
00007c47757ceb93  jmp 0x00007C47757CE85B
00007c47757ceb98  int3
00007c47757ceb99  nop [rax], eax
00007c47757ceba0  movaps xmm1, [r15+0x180]
00007c47757ceba8  vpmovqd xmm15, xmm1
00007c47757cebae  pxor xmm14, xmm14
00007c47757cebb3  punpcklqdq xmm15, xmm14
00007c47757cebb8  movaps [r15+0x210], xmm15
00007c47757cebc0  movq xmm15, qword ptr [r15+0x120]
00007c47757cebc9  movq xmm14, qword ptr [r15+0x130]
00007c47757cebd2  psubd xmm15, xmm14
00007c47757cebd7  movq xmm15, xmm15
00007c47757cebdc  movaps xmm13, [r15+0x170]
00007c47757cebe4  paddq xmm1, xmm13
00007c47757cebe9  movaps [r15+0x180], xmm1
00007c47757cebf1  movq xmm1, qword ptr [r15+0x150]
00007c47757cebfa  paddd xmm14, xmm1
00007c47757cebff  movq xmm14, xmm14
00007c47757cec04  movq xmm14, xmm14
00007c47757cec09  movaps [r15+0x130], xmm14
00007c47757cec11  pmovzxdq xmm15, xmm15
00007c47757cec17  psllq xmm15, 0x00
00007c47757cec1d  movq xmm1, qword ptr [r15+0x210]
00007c47757cec26  movq xmm14, qword ptr [r15+0x110]
00007c47757cec2f  paddd xmm1, xmm14
00007c47757cec34  movq xmm1, xmm1
00007c47757cec38  vcvtuqq2pd xmm15, xmm15
00007c47757cec3e  pmovzxdq xmm1, xmm1
00007c47757cec43  psllq xmm1, 0x00
00007c47757cec48  vcvtuqq2pd xmm1, xmm1
00007c47757cec4e  movaps xmm14, [r15+0x140]
00007c47757cec56  movaps xmm13, xmm15
00007c47757cec5a  mulpd xmm13, xmm14
00007c47757cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007c47757cec65  ptest xmm12, xmm12
00007c47757cec6b  jnz 0x00007C47757CED4E
00007c47757cec71  movaps [r15+0x220], xmm13
00007c47757cec79  mov rax, [r15+0x48]
00007c47757cec7d  mov r14, [r15+0x50]
00007c47757cec81  lea r12, [r14+rax*1]
00007c47757cec85  movups [r13+r12*1], xmm13
00007c47757cec8b  movaps xmm15, [r15+0x160]
00007c47757cec93  movaps xmm14, xmm1
00007c47757cec97  mulpd xmm14, xmm15
00007c47757cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007c47757ceca2  ptest xmm13, xmm13
00007c47757ceca8  jnz 0x00007C47757CEE9C
00007c47757cecae  movaps [r15+0x210], xmm14
00007c47757cecb6  mov r14, [r15+0x40]
00007c47757cecba  lea r12, [r14+rax*1]
00007c47757cecbe  movups [r13+r12*1], xmm14
00007c47757cecc4  lea r14, [rax+0x10]
00007c47757cecc8  mov [r15+0x48], r14
00007c47757ceccc  xor eax, eax
00007c47757cecce  mov r12d, 0x200
00007c47757cecd4  cmp r14, r12
00007c47757cecd7  cmc
00007c47757cecd8  lahf
00007c47757cecd9  seto al
00007c47757cecdc  mov [r15+0x108], eax
00007c47757cece3  mov eax, [r15+0x108]
00007c47757cecea  sahf
00007c47757ceceb  jnz 0x00007C47757CED1D
00007c47757ceced  cmp dword ptr [r15+0x318], 0x00
00007c47757cecf5  jz 0x00007C47757CEFF0
00007c47757cecfb  nop [rax+rax*1], ax
00007c47757ced04  nop [rax+rax*1], eax
00007c47757ced0c  mov eax, 0x4101EC
00007c47757ced11  mov [r15+0x100], rax
00007c47757ced18  jmp 0x00007C47755FE110
00007c47757ced1d  cmp dword ptr [r15+0x318], 0x00
00007c47757ced25  jz 0x00007C47757CEBA0
00007c47757ced2b  nop [rax+rax*1], ax
00007c47757ced34  nop [rax+rax*1], eax
00007c47757ced3c  mov eax, 0x4101AC
00007c47757ced41  mov [r15+0x100], rax
00007c47757ced48  jmp 0x00007C47755FE110
00007c47757ced4d  int3
00007c47757ced4e  sub rsp, 0x08
00007c47757ced52  push rax
00007c47757ced53  push rcx
00007c47757ced54  push rdx
00007c47757ced55  push rdi
00007c47757ced56  push rsi
00007c47757ced57  push r8
00007c47757ced59  push r9
00007c47757ced5b  push r10
00007c47757ced5d  push r11
00007c47757ced5f  sub rsp, 0xF0
00007c47757ced66  vmovaps [rsp], xmm0
00007c47757ced6b  vmovaps [rsp+0x10], xmm1
00007c47757ced71  vmovaps [rsp+0x20], xmm2
00007c47757ced77  vmovaps [rsp+0x30], xmm3
00007c47757ced7d  vmovaps [rsp+0x40], xmm4
00007c47757ced83  vmovaps [rsp+0x50], xmm5
00007c47757ced89  vmovaps [rsp+0x60], xmm6
00007c47757ced8f  vmovaps [rsp+0x70], xmm7
00007c47757ced95  vmovaps [rsp+0x80], xmm8
00007c47757ced9e  vmovaps [rsp+0x90], xmm9
00007c47757ceda7  vmovaps [rsp+0xA0], xmm10
00007c47757cedb0  vmovaps [rsp+0xB0], xmm11
00007c47757cedb9  vmovaps [rsp+0xC0], xmm12
00007c47757cedc2  vmovaps [rsp+0xD0], xmm14
00007c47757cedcb  vmovaps [rsp+0xE0], xmm15
00007c47757cedd4  sub rsp, 0x30
00007c47757cedd8  movaps [rsp], xmm13
00007c47757ceddd  movaps [rsp+0x10], xmm15
00007c47757cede3  movaps [rsp+0x20], xmm14
00007c47757cede9  lea rdi, [rsp]
00007c47757ceded  mov esi, 0x00
00007c47757cedf2  mov rax, 0x62084E409530
00007c47757cedfc  call rax
00007c47757cedfe  movaps xmm13, [rsp]
00007c47757cee03  add rsp, 0x30
00007c47757cee07  vmovaps xmm0, [rsp]
00007c47757cee0c  vmovaps xmm1, [rsp+0x10]
00007c47757cee12  vmovaps xmm2, [rsp+0x20]
00007c47757cee18  vmovaps xmm3, [rsp+0x30]
00007c47757cee1e  vmovaps xmm4, [rsp+0x40]
00007c47757cee24  vmovaps xmm5, [rsp+0x50]
00007c47757cee2a  vmovaps xmm6, [rsp+0x60]
00007c47757cee30  vmovaps xmm7, [rsp+0x70]
00007c47757cee36  vmovaps xmm8, [rsp+0x80]
00007c47757cee3f  vmovaps xmm9, [rsp+0x90]
00007c47757cee48  vmovaps xmm10, [rsp+0xA0]
00007c47757cee51  vmovaps xmm11, [rsp+0xB0]
00007c47757cee5a  vmovaps xmm12, [rsp+0xC0]
00007c47757cee63  vmovaps xmm14, [rsp+0xD0]
00007c47757cee6c  vmovaps xmm15, [rsp+0xE0]
00007c47757cee75  add rsp, 0xF0
00007c47757cee7c  pop r11
00007c47757cee7e  pop r10
00007c47757cee80  pop r9
00007c47757cee82  pop r8
00007c47757cee84  pop rsi
00007c47757cee85  pop rdi
00007c47757cee86  pop rdx
00007c47757cee87  pop rcx
00007c47757cee88  pop rax
00007c47757cee89  add rsp, 0x08
00007c47757cee8d  jmp 0x00007C47757CEC71
00007c47757cee92  call 0x00007C47756C2240
00007c47757cee97  jmp 0x00007C47757CEC8B
00007c47757cee9c  sub rsp, 0x08
00007c47757ceea0  push rax
00007c47757ceea1  push rcx
00007c47757ceea2  push rdx
00007c47757ceea3  push rdi
00007c47757ceea4  push rsi
00007c47757ceea5  push r8
00007c47757ceea7  push r9
00007c47757ceea9  push r10
00007c47757ceeab  push r11
00007c47757ceead  sub rsp, 0xF0
00007c47757ceeb4  vmovaps [rsp], xmm0
00007c47757ceeb9  vmovaps [rsp+0x10], xmm1
00007c47757ceebf  vmovaps [rsp+0x20], xmm2
00007c47757ceec5  vmovaps [rsp+0x30], xmm3
00007c47757ceecb  vmovaps [rsp+0x40], xmm4
00007c47757ceed1  vmovaps [rsp+0x50], xmm5
00007c47757ceed7  vmovaps [rsp+0x60], xmm6
00007c47757ceedd  vmovaps [rsp+0x70], xmm7
00007c47757ceee3  vmovaps [rsp+0x80], xmm8
00007c47757ceeec  vmovaps [rsp+0x90], xmm9
00007c47757ceef5  vmovaps [rsp+0xA0], xmm10
00007c47757ceefe  vmovaps [rsp+0xB0], xmm11
00007c47757cef07  vmovaps [rsp+0xC0], xmm12
00007c47757cef10  vmovaps [rsp+0xD0], xmm13
00007c47757cef19  vmovaps [rsp+0xE0], xmm15
00007c47757cef22  sub rsp, 0x30
00007c47757cef26  movaps [rsp], xmm14
00007c47757cef2b  movaps [rsp+0x10], xmm1
00007c47757cef30  movaps [rsp+0x20], xmm15
00007c47757cef36  lea rdi, [rsp]
00007c47757cef3a  mov esi, 0x00
00007c47757cef3f  mov rax, 0x62084E409530
00007c47757cef49  call rax
00007c47757cef4b  movaps xmm14, [rsp]
00007c47757cef50  add rsp, 0x30
00007c47757cef54  vmovaps xmm0, [rsp]
00007c47757cef59  vmovaps xmm1, [rsp+0x10]
00007c47757cef5f  vmovaps xmm2, [rsp+0x20]
00007c47757cef65  vmovaps xmm3, [rsp+0x30]
00007c47757cef6b  vmovaps xmm4, [rsp+0x40]
00007c47757cef71  vmovaps xmm5, [rsp+0x50]
00007c47757cef77  vmovaps xmm6, [rsp+0x60]
00007c47757cef7d  vmovaps xmm7, [rsp+0x70]
00007c47757cef83  vmovaps xmm8, [rsp+0x80]
00007c47757cef8c  vmovaps xmm9, [rsp+0x90]
00007c47757cef95  vmovaps xmm10, [rsp+0xA0]
00007c47757cef9e  vmovaps xmm11, [rsp+0xB0]
00007c47757cefa7  vmovaps xmm12, [rsp+0xC0]
00007c47757cefb0  vmovaps xmm13, [rsp+0xD0]
00007c47757cefb9  vmovaps xmm15, [rsp+0xE0]
00007c47757cefc2  add rsp, 0xF0
00007c47757cefc9  pop r11
00007c47757cefcb  pop r10
00007c47757cefcd  pop r9
00007c47757cefcf  pop r8
00007c47757cefd1  pop rsi
00007c47757cefd2  pop rdi
00007c47757cefd3  pop rdx
00007c47757cefd4  pop rcx
00007c47757cefd5  pop rax
00007c47757cefd6  add rsp, 0x08
00007c47757cefda  jmp 0x00007C47757CECAE
00007c47757cefdf  call 0x00007C47756C34C0
00007c47757cefe4  jmp 0x00007C47757CECC4
00007c47757cefe9  int3
00007c47757cefea  nop [rax+rax*1], ax
00007c47757ceff0  mov rax, [r15+0xF8]
00007c47757ceff7  lea r14, [rax-0x150]
00007c47757ceffe  mov [r15+0xF8], r14
00007c47757cf005  mov rax, [r15+0x50]
00007c47757cf009  lea r12, [rax+0x80]
00007c47757cf010  movups xmm1, [r13+r12*1]
00007c47757cf016  lea r12, [rax+0x90]
00007c47757cf01d  movups xmm15, [r13+r12*1]
00007c47757cf023  mov qword ptr [r15+0x48], 0x00
00007c47757cf02b  lea r12, [rax+0x40]
00007c47757cf02f  movups xmm14, [r13+r12*1]
00007c47757cf035  lea r12, [rax+0x50]
00007c47757cf039  movups xmm13, [r13+r12*1]
00007c47757cf03f  lea r12, [r14+0x120]
00007c47757cf046  movq xmm12, qword ptr [r15+0x1C0]
00007c47757cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007c47757cf058  movq r11, xmm12
00007c47757cf05d  movq r10, xmm11
00007c47757cf062  mov [r13+r12*1], r11
00007c47757cf067  lea r12, [r14+0x128]
00007c47757cf06e  mov [r13+r12*1], r10
00007c47757cf073  vxorps xmm12, xmm12, xmm12
00007c47757cf078  vpbroadcastq xmm12, xmm12
00007c47757cf07d  lea r12, [r14+0x100]
00007c47757cf084  movq xmm11, qword ptr [r15+0x200]
00007c47757cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007c47757cf096  movq r11, xmm11
00007c47757cf09b  movq r10, xmm10
00007c47757cf0a0  mov [r13+r12*1], r11
00007c47757cf0a5  lea r12, [r14+0x108]
00007c47757cf0ac  mov [r13+r12*1], r10
00007c47757cf0b1  lea r12, [r14+0xE0]
00007c47757cf0b8  movups [r13+r12*1], xmm15
00007c47757cf0be  lea r12, [r14+0xF0]
00007c47757cf0c5  movups [r13+r12*1], xmm1
00007c47757cf0cb  lea r12, [rax+0xC0]
00007c47757cf0d2  movups xmm1, [r13+r12*1]
00007c47757cf0d8  lea r12, [rax+0xD0]
00007c47757cf0df  movups xmm15, [r13+r12*1]
00007c47757cf0e5  lea r12, [r14+0x110]
00007c47757cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007c47757cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007c47757cf0fe  movq r11, xmm11
00007c47757cf103  movq r10, xmm10
00007c47757cf108  mov [r13+r12*1], r11
00007c47757cf10d  lea r12, [r14+0x118]
00007c47757cf114  mov [r13+r12*1], r10
00007c47757cf119  movups xmm11, [r13+rax*1]
00007c47757cf11f  lea r12, [rax+0x10]
00007c47757cf123  movups xmm10, [r13+r12*1]
00007c47757cf129  lea r12, [r14+0x130]
00007c47757cf130  movq xmm9, qword ptr [r15+0x1A0]
00007c47757cf139  movq xmm8, qword ptr [r15+0x190]
00007c47757cf142  movq r11, xmm9
00007c47757cf147  movq r10, xmm8
00007c47757cf14c  mov [r13+r12*1], r11
00007c47757cf151  lea r12, [r14+0x138]
00007c47757cf158  mov [r13+r12*1], r10
00007c47757cf15d  lea r12, [rax+0x140]
00007c47757cf164  movups xmm9, [r13+r12*1]
00007c47757cf16a  lea r12, [rax+0x150]
00007c47757cf171  movups xmm8, [r13+r12*1]
00007c47757cf177  lea r12, [r14+0xC0]
00007c47757cf17e  movups [r13+r12*1], xmm15
00007c47757cf184  lea r12, [r14+0xD0]
00007c47757cf18b  movups [r13+r12*1], xmm1
00007c47757cf191  lea r12, [rax+0x100]
00007c47757cf198  movups xmm1, [r13+r12*1]
00007c47757cf19e  lea r12, [rax+0x110]
00007c47757cf1a5  movups xmm15, [r13+r12*1]
00007c47757cf1ab  lea r12, [r14+0x140]
00007c47757cf1b2  mov r11, [r15+0xE8]
00007c47757cf1b9  mov [r13+r12*1], r11
00007c47757cf1be  lea r12, [rax+0x180]
00007c47757cf1c5  movups xmm7, [r13+r12*1]
00007c47757cf1cb  lea r12, [rax+0x190]
00007c47757cf1d2  movups xmm6, [r13+r12*1]
00007c47757cf1d8  lea r12, [rax+0x1C0]
00007c47757cf1df  movups xmm5, [r13+r12*1]
00007c47757cf1e5  lea r12, [rax+0x1D0]
00007c47757cf1ec  movups xmm4, [r13+r12*1]
00007c47757cf1f2  lea r12, [r14+0x20]
00007c47757cf1f6  movups [r13+r12*1], xmm1
00007c47757cf1fc  lea r12, [r14+0x30]
00007c47757cf200  movups [r13+r12*1], xmm13
00007c47757cf206  lea r12, [rax+0x60]
00007c47757cf20a  movups xmm1, [r13+r12*1]
00007c47757cf210  lea r12, [rax+0x70]
00007c47757cf214  movups xmm13, [r13+r12*1]
00007c47757cf21a  lea r12, [rax+0x20]
00007c47757cf21e  movups xmm3, [r13+r12*1]
00007c47757cf224  lea r12, [rax+0x30]
00007c47757cf228  movups xmm2, [r13+r12*1]
00007c47757cf22e  movaps [r15+0x1F0], xmm2
00007c47757cf236  lea r12, [r14+0x60]
00007c47757cf23a  movups [r13+r12*1], xmm11
00007c47757cf240  lea r12, [r14+0x70]
00007c47757cf244  movups [r13+r12*1], xmm5
00007c47757cf24a  lea r12, [rax+0xE0]
00007c47757cf251  movups xmm11, [r13+r12*1]
00007c47757cf257  lea r12, [rax+0xF0]
00007c47757cf25e  movups xmm5, [r13+r12*1]
00007c47757cf264  lea r12, [r14+0xA0]
00007c47757cf26b  movups [r13+r12*1], xmm13
00007c47757cf271  lea r12, [r14+0xB0]
00007c47757cf278  movups [r13+r12*1], xmm1
00007c47757cf27e  lea r12, [rax+0xA0]
00007c47757cf285  movups xmm1, [r13+r12*1]
00007c47757cf28b  lea r12, [rax+0xB0]
00007c47757cf292  movups xmm13, [r13+r12*1]
00007c47757cf298  lea r12, [rax+0x120]
00007c47757cf29f  vmovaps [rsp+0x10], xmm1
00007c47757cf2a5  movups xmm1, [r13+r12*1]
00007c47757cf2ab  lea r12, [rax+0x130]
00007c47757cf2b2  vmovaps [rsp+0x20], xmm1
00007c47757cf2b8  movups xmm1, [r13+r12*1]
00007c47757cf2be  lea r12, [rax+0x160]
00007c47757cf2c5  vmovaps [rsp+0x30], xmm1
00007c47757cf2cb  movups xmm1, [r13+r12*1]
00007c47757cf2d1  lea r12, [rax+0x170]
00007c47757cf2d8  vmovaps [rsp+0x40], xmm1
00007c47757cf2de  movups xmm1, [r13+r12*1]
00007c47757cf2e4  movaps [r15+0x2B0], xmm1
00007c47757cf2ec  lea r12, [r14+0x80]
00007c47757cf2f3  movups [r13+r12*1], xmm13
00007c47757cf2f9  lea r12, [r14+0x90]
00007c47757cf300  vmovaps xmm13, [rsp+0x10]
00007c47757cf306  movups [r13+r12*1], xmm13
00007c47757cf30c  lea r12, [rax+0x1A0]
00007c47757cf313  movups xmm13, [r13+r12*1]
00007c47757cf319  lea r12, [rax+0x1B0]
00007c47757cf320  vmovaps [rsp+0x10], xmm1
00007c47757cf326  movups xmm1, [r13+r12*1]
00007c47757cf32c  movaps [r15+0x290], xmm13
00007c47757cf334  movaps [r15+0x1E0], xmm1
00007c47757cf33c  lea r12, [rax+0x1E0]
00007c47757cf343  vmovaps [rsp+0x50], xmm1
00007c47757cf349  movups xmm1, [r13+r12*1]
00007c47757cf34f  lea r12, [rax+0x1F0]
00007c47757cf356  vmovaps [rsp+0x60], xmm1
00007c47757cf35c  movups xmm1, [r13+r12*1]
00007c47757cf362  mov qword ptr [r15+0x50], 0x430920
00007c47757cf36a  lea rax, [r14+0x40]
00007c47757cf36e  vmovaps [rsp+0x70], xmm1
00007c47757cf374  vmovaps xmm1, [rsp+0x40]
00007c47757cf37a  movups [r13+rax*1], xmm1
00007c47757cf380  lea rax, [r14+0x50]
00007c47757cf384  movups [r13+rax*1], xmm10
00007c47757cf38a  vmovaps xmm1, [rsp+0x70]
00007c47757cf390  movups [r13+r14*1], xmm1
00007c47757cf396  lea rax, [r14+0x10]
00007c47757cf39a  vmovaps xmm1, [rsp+0x60]
00007c47757cf3a0  movups [r13+rax*1], xmm1
00007c47757cf3a6  mov rax, [r15+0x40]
00007c47757cf3aa  vmovaps [rsp+0x40], xmm3
00007c47757cf3b0  vmovaps xmm1, [rsp+0x40]
00007c47757cf3b6  por xmm3, xmm1
00007c47757cf3ba  vmovaps [rsp+0x40], xmm6
00007c47757cf3c0  vmovaps xmm10, [rsp+0x40]
00007c47757cf3c6  por xmm6, xmm10
00007c47757cf3cb  lea r12, [rax+0x30]
00007c47757cf3cf  mov r11, [r13+r12*1]
00007c47757cf3d4  lea r12, [rax+0x38]
00007c47757cf3d8  mov r10, [r13+r12*1]
00007c47757cf3dd  movq xmm10, r11
00007c47757cf3e2  vmovaps [rsp+0x40], xmm1
00007c47757cf3e8  movq xmm1, r10
00007c47757cf3ed  movq xmm10, xmm10
00007c47757cf3f2  vmovaps [rsp+0x60], xmm10
00007c47757cf3f8  movq xmm10, xmm10
00007c47757cf3fd  movaps [r15+0x130], xmm10
00007c47757cf405  movq xmm1, xmm1
00007c47757cf409  vmovaps [rsp+0x70], xmm1
00007c47757cf40f  movq xmm1, xmm1
00007c47757cf413  movaps [r15+0x280], xmm1
00007c47757cf41b  vmovaps [rsp+0x80], xmm9
00007c47757cf424  vmovaps xmm1, [rsp+0x80]
00007c47757cf42d  por xmm9, xmm1
00007c47757cf432  lea r12, [rax+0x20]
00007c47757cf436  mov r11, [r13+r12*1]
00007c47757cf43b  lea r12, [rax+0x28]
00007c47757cf43f  mov r10, [r13+r12*1]
00007c47757cf444  movq xmm1, r11
00007c47757cf449  movq xmm10, r10
00007c47757cf44e  movq xmm1, xmm1
00007c47757cf452  vmovaps [rsp+0x80], xmm1
00007c47757cf45b  movq xmm1, xmm1
00007c47757cf45f  movaps [r15+0x150], xmm1
00007c47757cf467  movq xmm10, xmm10
00007c47757cf46c  vmovaps [rsp+0x90], xmm10
00007c47757cf475  movq xmm10, xmm10
00007c47757cf47a  movaps [r15+0x140], xmm10
00007c47757cf482  lea r12, [rax+0x10]
00007c47757cf486  mov r11, [r13+r12*1]
00007c47757cf48b  lea r12, [rax+0x18]
00007c47757cf48f  mov r10, [r13+r12*1]
00007c47757cf494  movq xmm1, r11
00007c47757cf499  movq xmm10, r10
00007c47757cf49e  movq xmm1, xmm1
00007c47757cf4a2  vmovaps [rsp+0xA0], xmm1
00007c47757cf4ab  movq xmm1, xmm1
00007c47757cf4af  movaps [r15+0x170], xmm1
00007c47757cf4b7  movq xmm10, xmm10
00007c47757cf4bc  vmovaps [rsp+0xB0], xmm10
00007c47757cf4c5  movq xmm10, xmm10
00007c47757cf4ca  movaps [r15+0x160], xmm10
00007c47757cf4d2  mov r12, [r13+rax*1]
00007c47757cf4d7  vmovq xmm1, r12
00007c47757cf4dc  vpbroadcastq xmm1, xmm1
00007c47757cf4e1  lea r12, [rax+0x08]
00007c47757cf4e5  mov rax, [r13+r12*1]
00007c47757cf4ea  movq xmm10, rax
00007c47757cf4ef  movaps [r15+0x230], xmm10
00007c47757cf4f7  lea rax, [r14+0x50]
00007c47757cf4fb  movups xmm10, [r13+rax*1]
00007c47757cf501  lea rax, [r14+0x60]
00007c47757cf505  vmovaps [rsp+0xC0], xmm1
00007c47757cf50e  movups xmm1, [r13+rax*1]
00007c47757cf514  lea rax, [r14+0x30]
00007c47757cf518  vmovaps [rsp+0xD0], xmm1
00007c47757cf521  movups xmm1, [r13+rax*1]
00007c47757cf527  mov qword ptr [r15+0x60], 0x430920
00007c47757cf52f  mov qword ptr [r15+0x58], 0x40
00007c47757cf537  vmovaps [rsp+0xE0], xmm1
00007c47757cf540  vmovaps [rsp+0xF0], xmm15
00007c47757cf549  vmovaps xmm15, [rsp+0xC0]
00007c47757cf552  vmovaps [rsp+0xC0], xmm14
00007c47757cf55b  vmovaps xmm14, [rsp+0x40]
00007c47757cf561  vmovaps [rsp+0x40], xmm13
00007c47757cf567  movaps xmm1, xmm15
00007c47757cf56b  mulpd xmm1, xmm14
00007c47757cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007c47757cf575  ptest xmm13, xmm13
00007c47757cf57b  jnz 0x00007C47757D0682
00007c47757cf581  movq xmm14, qword ptr [r15+0x230]
00007c47757cf58a  vmovaps [rsp+0x100], xmm14
00007c47757cf593  vpermilpd xmm14, xmm14, 0x00
00007c47757cf599  vmovaps [rsp+0x110], xmm1
00007c47757cf5a2  vmovaps xmm1, [rsp+0xE0]
00007c47757cf5ab  vmovaps [rsp+0xE0], xmm15
00007c47757cf5b4  movaps xmm13, xmm1
00007c47757cf5b8  mulpd xmm13, xmm14
00007c47757cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007c47757cf5c3  ptest xmm15, xmm15
00007c47757cf5c9  jnz 0x00007C47757D07C4
00007c47757cf5cf  vxorps xmm1, xmm1, xmm1
00007c47757cf5d3  vpbroadcastq xmm1, xmm1
00007c47757cf5d8  vmovaps xmm14, [rsp+0xE0]
00007c47757cf5e1  vmovaps [rsp+0xE0], xmm1
00007c47757cf5ea  vmovaps xmm1, [rsp+0xD0]
00007c47757cf5f3  vmovaps [rsp+0xD0], xmm13
00007c47757cf5fc  movaps xmm15, xmm14
00007c47757cf600  mulpd xmm15, xmm1
00007c47757cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007c47757cf60b  ptest xmm13, xmm13
00007c47757cf611  jnz 0x00007C47757D0907
00007c47757cf617  movaps xmm1, xmm14
00007c47757cf61b  mulpd xmm1, xmm10
00007c47757cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007c47757cf625  ptest xmm13, xmm13
00007c47757cf62b  jnz 0x00007C47757D0A4A
00007c47757cf631  movaps xmm13, xmm14
00007c47757cf635  mulpd xmm13, xmm2
00007c47757cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007c47757cf640  ptest xmm10, xmm10
00007c47757cf646  jnz 0x00007C47757D0B8C
00007c47757cf64c  vmovaps [rsp+0x120], xmm7
00007c47757cf655  vmovaps xmm14, [rsp+0x120]
00007c47757cf65e  por xmm7, xmm14
00007c47757cf663  vmovaps xmm14, [rsp+0xC0]
00007c47757cf66c  vmovaps xmm10, [rsp+0xC0]
00007c47757cf675  por xmm14, xmm10
00007c47757cf67a  vmovaps xmm2, [rsp+0x100]
00007c47757cf683  vpermilpd xmm2, xmm2, 0x00
00007c47757cf689  vmovaps [rsp+0xC0], xmm1
00007c47757cf692  vmovaps [rsp+0x120], xmm15
00007c47757cf69b  movaps xmm1, xmm10
00007c47757cf69f  mulpd xmm1, xmm2
00007c47757cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007c47757cf6a8  ptest xmm15, xmm15
00007c47757cf6ae  jnz 0x00007C47757D0CCF
00007c47757cf6b4  xor eax, eax
00007c47757cf6b6  mov r12d, 0x40
00007c47757cf6bc  mov r11d, 0x200
00007c47757cf6c2  cmp r12, r11
00007c47757cf6c5  cmc
00007c47757cf6c6  lahf
00007c47757cf6c7  seto al
00007c47757cf6ca  mov [r15+0x108], eax
00007c47757cf6d1  vmovaps xmm10, [rsp+0x110]
00007c47757cf6da  vmovaps xmm2, [rsp+0xE0]
00007c47757cf6e3  vmovaps [rsp+0xE0], xmm1
00007c47757cf6ec  movaps xmm15, xmm10
00007c47757cf6f0  addpd xmm15, xmm2
00007c47757cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757cf6fb  ptest xmm1, xmm1
00007c47757cf700  jnz 0x00007C47757D0E10
00007c47757cf706  vmovaps xmm10, [rsp+0x120]
00007c47757cf70f  vmovaps [rsp+0x110], xmm15
00007c47757cf718  movaps xmm1, xmm10
00007c47757cf71c  addpd xmm1, xmm12
00007c47757cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007c47757cf726  ptest xmm15, xmm15
00007c47757cf72c  jnz 0x00007C47757D0F53
00007c47757cf732  vmovaps xmm10, [rsp+0xC0]
00007c47757cf73b  vmovaps [rsp+0xC0], xmm1
00007c47757cf744  movaps xmm15, xmm10
00007c47757cf748  addpd xmm15, xmm12
00007c47757cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757cf753  ptest xmm1, xmm1
00007c47757cf758  jnz 0x00007C47757D1095
00007c47757cf75e  vmovaps xmm1, [rsp+0x30]
00007c47757cf764  vmovaps xmm12, [rsp+0x30]
00007c47757cf76a  por xmm1, xmm12
00007c47757cf76f  vmovaps xmm12, [rsp+0x20]
00007c47757cf775  vmovaps xmm10, [rsp+0x20]
00007c47757cf77b  por xmm12, xmm10
00007c47757cf780  vmovaps [rsp+0x20], xmm5
00007c47757cf786  vmovaps xmm10, [rsp+0x20]
00007c47757cf78c  por xmm5, xmm10
00007c47757cf791  vmovaps [rsp+0x20], xmm11
00007c47757cf797  vmovaps xmm10, [rsp+0x20]
00007c47757cf79d  por xmm11, xmm10
00007c47757cf7a2  vmovaps [rsp+0x20], xmm4
00007c47757cf7a8  vmovaps xmm10, [rsp+0x20]
00007c47757cf7ae  por xmm4, xmm10
00007c47757cf7b3  vmovaps [rsp+0x20], xmm8
00007c47757cf7b9  vmovaps xmm10, [rsp+0x20]
00007c47757cf7bf  por xmm8, xmm10
00007c47757cf7c4  vmovaps xmm10, [rsp+0xF0]
00007c47757cf7cd  vmovaps [rsp+0x20], xmm1
00007c47757cf7d3  vmovaps xmm1, [rsp+0xF0]
00007c47757cf7dc  por xmm10, xmm1
00007c47757cf7e1  lea rax, [r14+0xA0]
00007c47757cf7e8  movups xmm1, [r13+rax*1]
00007c47757cf7ee  lea rax, [r14+0xB0]
00007c47757cf7f5  vmovaps [rsp+0x30], xmm1
00007c47757cf7fb  movups xmm1, [r13+rax*1]
00007c47757cf801  vmovaps [rsp+0xF0], xmm1
00007c47757cf80a  vmovaps [rsp+0x120], xmm15
00007c47757cf813  movaps xmm1, xmm13
00007c47757cf817  addpd xmm1, xmm2
00007c47757cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007c47757cf820  ptest xmm15, xmm15
00007c47757cf826  jnz 0x00007C47757D11ED
00007c47757cf82c  lea rax, [r14+0xF0]
00007c47757cf833  movups xmm15, [r13+rax*1]
00007c47757cf839  vmovaps xmm2, [rsp+0xC0]
00007c47757cf842  vmovaps [rsp+0xC0], xmm1
00007c47757cf84b  vmovaps xmm1, [rsp+0xE0]
00007c47757cf854  vmovaps [rsp+0xE0], xmm15
00007c47757cf85d  movaps xmm13, xmm2
00007c47757cf861  addpd xmm13, xmm1
00007c47757cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007c47757cf86c  ptest xmm15, xmm15
00007c47757cf872  jnz 0x00007C47757D1338
00007c47757cf878  vmovaps xmm15, [rsp+0x120]
00007c47757cf881  vmovaps xmm2, [rsp+0xD0]
00007c47757cf88a  vmovaps [rsp+0xD0], xmm14
00007c47757cf893  movaps xmm1, xmm15
00007c47757cf897  addpd xmm1, xmm2
00007c47757cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007c47757cf8a0  ptest xmm14, xmm14
00007c47757cf8a6  jnz 0x00007C47757D147A
00007c47757cf8ac  vmovaps xmm15, [rsp+0x100]
00007c47757cf8b5  vpermilpd xmm15, xmm15, 0x00
00007c47757cf8bb  vmovaps xmm2, [rsp+0xF0]
00007c47757cf8c4  vmovaps [rsp+0xF0], xmm1
00007c47757cf8cd  movaps xmm14, xmm2
00007c47757cf8d1  mulpd xmm14, xmm15
00007c47757cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007c47757cf8dc  ptest xmm1, xmm1
00007c47757cf8e1  jnz 0x00007C47757D15BB
00007c47757cf8e7  vmovaps xmm1, [rsp+0xA0]
00007c47757cf8f0  vpermilpd xmm1, xmm1, 0x00
00007c47757cf8f6  vmovaps xmm2, [rsp+0xE0]
00007c47757cf8ff  vmovaps [rsp+0xE0], xmm14
00007c47757cf908  movaps xmm15, xmm2
00007c47757cf90c  mulpd xmm15, xmm1
00007c47757cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007c47757cf917  ptest xmm14, xmm14
00007c47757cf91d  jnz 0x00007C47757D16FE
00007c47757cf923  lea rax, [r14+0xE0]
00007c47757cf92a  movups xmm1, [r13+rax*1]
00007c47757cf930  vmovaps xmm14, [rsp+0x100]
00007c47757cf939  vpermilpd xmm14, xmm14, 0x00
00007c47757cf93f  vmovaps [rsp+0x100], xmm1
00007c47757cf948  vmovaps xmm1, [rsp+0x30]
00007c47757cf94e  vmovaps [rsp+0x30], xmm15
00007c47757cf954  movaps xmm2, xmm1
00007c47757cf957  mulpd xmm2, xmm14
00007c47757cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007c47757cf961  ptest xmm15, xmm15
00007c47757cf967  jnz 0x00007C47757D184A
00007c47757cf96d  vmovaps [rsp+0x120], xmm10
00007c47757cf976  vmovaps xmm1, [rsp+0x120]
00007c47757cf97f  por xmm10, xmm1
00007c47757cf984  movaps [r15+0x300], xmm10
00007c47757cf98c  vmovaps [rsp+0x120], xmm8
00007c47757cf995  vmovaps xmm1, [rsp+0x120]
00007c47757cf99e  por xmm8, xmm1
00007c47757cf9a3  movaps [r15+0x190], xmm8
00007c47757cf9ab  vmovaps xmm1, [rsp+0xA0]
00007c47757cf9b4  vpermilpd xmm1, xmm1, 0x00
00007c47757cf9ba  vmovaps xmm14, [rsp+0x100]
00007c47757cf9c3  vmovaps [rsp+0x100], xmm13
00007c47757cf9cc  movaps xmm15, xmm14
00007c47757cf9d0  mulpd xmm15, xmm1
00007c47757cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007c47757cf9db  ptest xmm13, xmm13
00007c47757cf9e1  jnz 0x00007C47757D198B
00007c47757cf9e7  lea rax, [r14+0x90]
00007c47757cf9ee  movups xmm1, [r13+rax*1]
00007c47757cf9f4  vmovaps [rsp+0x120], xmm4
00007c47757cf9fd  vmovaps xmm14, [rsp+0x120]
00007c47757cfa06  por xmm4, xmm14
00007c47757cfa0b  movaps [r15+0x1C0], xmm4
00007c47757cfa13  vmovaps [rsp+0x120], xmm11
00007c47757cfa1c  vmovaps xmm14, [rsp+0x120]
00007c47757cfa25  por xmm11, xmm14
00007c47757cfa2a  movaps [r15+0x200], xmm11
00007c47757cfa32  vmovaps [rsp+0x120], xmm5
00007c47757cfa3b  vmovaps xmm14, [rsp+0x120]
00007c47757cfa44  por xmm5, xmm14
00007c47757cfa49  movaps [r15+0x2D0], xmm5
00007c47757cfa51  vmovaps [rsp+0x120], xmm12
00007c47757cfa5a  vmovaps xmm14, [rsp+0x120]
00007c47757cfa63  por xmm12, xmm14
00007c47757cfa68  movaps [r15+0x2E0], xmm12
00007c47757cfa70  vmovaps xmm13, [rsp+0x110]
00007c47757cfa79  vmovaps [rsp+0x110], xmm1
00007c47757cfa82  vmovaps xmm1, [rsp+0xE0]
00007c47757cfa8b  vmovaps [rsp+0xE0], xmm15
00007c47757cfa94  movaps xmm14, xmm13
00007c47757cfa98  addpd xmm14, xmm1
00007c47757cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007c47757cfaa3  ptest xmm15, xmm15
00007c47757cfaa9  jnz 0x00007C47757D1AD8
00007c47757cfaaf  vmovaps xmm1, [rsp+0xA0]
00007c47757cfab8  vpermilpd xmm1, xmm1, 0x00
00007c47757cfabe  vmovaps xmm13, [rsp+0x110]
00007c47757cfac7  vmovaps [rsp+0x110], xmm14
00007c47757cfad0  movaps xmm15, xmm13
00007c47757cfad4  mulpd xmm15, xmm1
00007c47757cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007c47757cfadf  ptest xmm14, xmm14
00007c47757cfae5  jnz 0x00007C47757D1C1B
00007c47757cfaeb  lea rax, [r14+0x80]
00007c47757cfaf2  movups xmm1, [r13+rax*1]
00007c47757cfaf8  vmovaps xmm13, [rsp+0xC0]
00007c47757cfb01  vmovaps [rsp+0xC0], xmm1
00007c47757cfb0a  movaps xmm14, xmm13
00007c47757cfb0e  addpd xmm14, xmm2
00007c47757cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007c47757cfb19  ptest xmm1, xmm1
00007c47757cfb1e  jnz 0x00007C47757D1D68
00007c47757cfb24  vmovaps xmm13, [rsp+0x100]
00007c47757cfb2d  vmovaps xmm2, [rsp+0x30]
00007c47757cfb33  vmovaps [rsp+0x30], xmm15
00007c47757cfb39  movaps xmm1, xmm13
00007c47757cfb3d  addpd xmm1, xmm2
00007c47757cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007c47757cfb46  ptest xmm15, xmm15
00007c47757cfb4c  jnz 0x00007C47757D1EAB
00007c47757cfb52  vmovaps xmm15, [rsp+0x20]
00007c47757cfb58  vmovaps xmm13, [rsp+0x20]
00007c47757cfb5e  por xmm15, xmm13
00007c47757cfb63  movaps [r15+0x2F0], xmm15
00007c47757cfb6b  vmovaps xmm13, [rsp+0xA0]
00007c47757cfb74  vpermilpd xmm13, xmm13, 0x00
00007c47757cfb7a  vmovaps [rsp+0x20], xmm1
00007c47757cfb80  vmovaps xmm1, [rsp+0xC0]
00007c47757cfb89  vmovaps [rsp+0xA0], xmm15
00007c47757cfb92  movaps xmm2, xmm1
00007c47757cfb95  mulpd xmm2, xmm13
00007c47757cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007c47757cfb9f  ptest xmm15, xmm15
00007c47757cfba5  jnz 0x00007C47757D1FEC
00007c47757cfbab  lea rax, [r14+0xD0]
00007c47757cfbb2  movups xmm1, [r13+rax*1]
00007c47757cfbb8  vmovaps xmm13, [rsp+0xF0]
00007c47757cfbc1  vmovaps [rsp+0xC0], xmm1
00007c47757cfbca  vmovaps xmm1, [rsp+0xE0]
00007c47757cfbd3  vmovaps [rsp+0xE0], xmm14
00007c47757cfbdc  movaps xmm15, xmm13
00007c47757cfbe0  addpd xmm15, xmm1
00007c47757cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007c47757cfbeb  ptest xmm14, xmm14
00007c47757cfbf1  jnz 0x00007C47757D2137
00007c47757cfbf7  vmovaps xmm1, [rsp+0xB0]
00007c47757cfc00  vpermilpd xmm1, xmm1, 0x00
00007c47757cfc06  movaps xmm14, xmm11
00007c47757cfc0a  mulpd xmm14, xmm1
00007c47757cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007c47757cfc15  ptest xmm13, xmm13
00007c47757cfc1b  jnz 0x00007C47757D227A
00007c47757cfc21  movaps [r15+0x260], xmm14
00007c47757cfc29  vxorps xmm1, xmm1, xmm1
00007c47757cfc2d  vpbroadcastq xmm1, xmm1
00007c47757cfc32  movaps [r15+0x1B0], xmm1
00007c47757cfc3a  vmovaps xmm1, [rsp+0xB0]
00007c47757cfc43  vpermilpd xmm1, xmm1, 0x00
00007c47757cfc49  vmovaps xmm11, [rsp+0xC0]
00007c47757cfc52  vmovaps [rsp+0xC0], xmm15
00007c47757cfc5b  movaps xmm13, xmm11
00007c47757cfc5f  mulpd xmm13, xmm1
00007c47757cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007c47757cfc6a  ptest xmm15, xmm15
00007c47757cfc70  jnz 0x00007C47757D23BD
00007c47757cfc76  lea rax, [r14+0xC0]
00007c47757cfc7d  movups xmm1, [r13+rax*1]
00007c47757cfc83  vmovaps xmm11, [rsp+0x110]
00007c47757cfc8c  vmovaps [rsp+0xF0], xmm1
00007c47757cfc95  vmovaps xmm1, [rsp+0x30]
00007c47757cfc9b  vmovaps [rsp+0x30], xmm14
00007c47757cfca1  movaps xmm15, xmm11
00007c47757cfca5  addpd xmm15, xmm1
00007c47757cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007c47757cfcb0  ptest xmm14, xmm14
00007c47757cfcb6  jnz 0x00007C47757D250A
00007c47757cfcbc  vmovaps [rsp+0x100], xmm9
00007c47757cfcc5  vmovaps xmm1, [rsp+0x100]
00007c47757cfcce  por xmm9, xmm1
00007c47757cfcd3  movaps [r15+0x270], xmm9
00007c47757cfcdb  vmovaps [rsp+0x100], xmm6
00007c47757cfce4  vmovaps xmm1, [rsp+0x100]
00007c47757cfced  por xmm6, xmm1
00007c47757cfcf1  movaps [r15+0x1A0], xmm6
00007c47757cfcf9  vmovaps xmm14, [rsp+0xB0]
00007c47757cfd02  vpermilpd xmm14, xmm14, 0x00
00007c47757cfd08  vmovaps xmm6, [rsp+0xF0]
00007c47757cfd11  vmovaps [rsp+0xF0], xmm1
00007c47757cfd1a  movaps xmm11, xmm6
00007c47757cfd1e  mulpd xmm11, xmm14
00007c47757cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007c47757cfd29  ptest xmm1, xmm1
00007c47757cfd2e  jnz 0x00007C47757D264D
00007c47757cfd34  lea rax, [r14+0x20]
00007c47757cfd38  movups xmm1, [r13+rax*1]
00007c47757cfd3e  movaps [r15+0x110], xmm1
00007c47757cfd46  vmovaps xmm6, [rsp+0xE0]
00007c47757cfd4f  vmovaps [rsp+0xE0], xmm1
00007c47757cfd58  movaps xmm14, xmm6
00007c47757cfd5c  addpd xmm14, xmm2
00007c47757cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007c47757cfd67  ptest xmm1, xmm1
00007c47757cfd6c  jnz 0x00007C47757D279A
00007c47757cfd72  vmovaps xmm1, [rsp+0xB0]
00007c47757cfd7b  vpermilpd xmm1, xmm1, 0x00
00007c47757cfd81  movaps xmm6, xmm5
00007c47757cfd84  mulpd xmm6, xmm1
00007c47757cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007c47757cfd8d  ptest xmm2, xmm2
00007c47757cfd92  jnz 0x00007C47757D28DC
00007c47757cfd98  vmovaps xmm5, [rsp+0x20]
00007c47757cfd9e  movaps xmm1, xmm5
00007c47757cfda1  addpd xmm1, xmm13
00007c47757cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007c47757cfdab  ptest xmm2, xmm2
00007c47757cfdb0  jnz 0x00007C47757D2A1C
00007c47757cfdb6  vmovaps xmm13, [rsp+0x80]
00007c47757cfdbf  vpermilpd xmm13, xmm13, 0x00
00007c47757cfdc5  vmovaps xmm2, [rsp+0xE0]
00007c47757cfdce  vmovaps [rsp+0x20], xmm1
00007c47757cfdd4  movaps xmm5, xmm2
00007c47757cfdd7  mulpd xmm5, xmm13
00007c47757cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007c47757cfde1  ptest xmm1, xmm1
00007c47757cfde6  jnz 0x00007C47757D2B5D
00007c47757cfdec  vmovaps xmm1, [rsp+0x80]
00007c47757cfdf5  vpermilpd xmm1, xmm1, 0x00
00007c47757cfdfb  movaps xmm13, xmm10
00007c47757cfdff  mulpd xmm13, xmm1
00007c47757cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007c47757cfe0a  ptest xmm2, xmm2
00007c47757cfe0f  jnz 0x00007C47757D2C9E
00007c47757cfe15  vmovaps xmm10, [rsp+0x30]
00007c47757cfe1b  movaps xmm1, xmm15
00007c47757cfe1f  addpd xmm1, xmm10
00007c47757cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007c47757cfe29  ptest xmm2, xmm2
00007c47757cfe2e  jnz 0x00007C47757D2DE1
00007c47757cfe34  vmovaps xmm10, [rsp+0xC0]
00007c47757cfe3d  movaps xmm15, xmm10
00007c47757cfe41  addpd xmm15, xmm11
00007c47757cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007c47757cfe4c  ptest xmm2, xmm2
00007c47757cfe51  jnz 0x00007C47757D2F23
00007c47757cfe57  vmovaps xmm11, [rsp+0x80]
00007c47757cfe60  vpermilpd xmm11, xmm11, 0x00
00007c47757cfe66  movaps xmm10, xmm12
00007c47757cfe6a  mulpd xmm10, xmm11
00007c47757cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007c47757cfe75  ptest xmm2, xmm2
00007c47757cfe7a  jnz 0x00007C47757D3067
00007c47757cfe80  vmovaps xmm12, [rsp+0x80]
00007c47757cfe89  vpermilpd xmm12, xmm12, 0x00
00007c47757cfe8f  vmovaps xmm2, [rsp+0xA0]
00007c47757cfe98  vmovaps [rsp+0x30], xmm1
00007c47757cfe9e  movaps xmm11, xmm2
00007c47757cfea2  mulpd xmm11, xmm12
00007c47757cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007c47757cfead  ptest xmm1, xmm1
00007c47757cfeb2  jnz 0x00007C47757D31AB
00007c47757cfeb8  movaps xmm1, xmm14
00007c47757cfebc  addpd xmm1, xmm6
00007c47757cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007c47757cfec5  ptest xmm12, xmm12
00007c47757cfecb  jnz 0x00007C47757D32EE
00007c47757cfed1  vmovaps xmm12, [rsp+0x20]
00007c47757cfed7  movaps xmm14, xmm12
00007c47757cfedb  addpd xmm14, xmm5
00007c47757cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007c47757cfee6  ptest xmm6, xmm6
00007c47757cfeeb  jnz 0x00007C47757D342F
00007c47757cfef1  vmovaps xmm12, [rsp+0x90]
00007c47757cfefa  vpermilpd xmm12, xmm12, 0x00
00007c47757cff00  movaps xmm6, xmm9
00007c47757cff04  mulpd xmm6, xmm12
00007c47757cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007c47757cff0e  ptest xmm5, xmm5
00007c47757cff13  jnz 0x00007C47757D3572
00007c47757cff19  movaps xmm12, xmm15
00007c47757cff1d  addpd xmm12, xmm13
00007c47757cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007c47757cff28  ptest xmm9, xmm9
00007c47757cff2e  jnz 0x00007C47757D36B4
00007c47757cff34  vmovaps xmm13, [rsp+0x30]
00007c47757cff3a  movaps xmm15, xmm13
00007c47757cff3e  addpd xmm15, xmm10
00007c47757cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007c47757cff49  ptest xmm9, xmm9
00007c47757cff4f  jnz 0x00007C47757D37F8
00007c47757cff55  vmovaps xmm13, [rsp+0xD0]
00007c47757cff5e  vmovaps xmm10, [rsp+0xD0]
00007c47757cff67  por xmm13, xmm10
00007c47757cff6c  movaps [r15+0x250], xmm13
00007c47757cff74  vmovaps [rsp+0x20], xmm7
00007c47757cff7a  vmovaps xmm13, [rsp+0x20]
00007c47757cff80  por xmm7, xmm13
00007c47757cff85  movaps [r15+0x2A0], xmm7
00007c47757cff8d  vmovaps [rsp+0x20], xmm3
00007c47757cff93  vmovaps xmm13, [rsp+0x20]
00007c47757cff99  por xmm3, xmm13
00007c47757cff9e  movaps [r15+0x1D0], xmm3
00007c47757cffa6  lea rax, [r14+0x40]
00007c47757cffaa  movups xmm13, [r13+rax*1]
00007c47757cffb0  movaps [r15+0x2C0], xmm13
00007c47757cffb8  vmovaps xmm10, [rsp+0x90]
00007c47757cffc1  vpermilpd xmm10, xmm10, 0x00
00007c47757cffc7  movaps xmm9, xmm8
00007c47757cffcb  mulpd xmm9, xmm10
00007c47757cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007c47757cffd6  ptest xmm5, xmm5
00007c47757cffdb  jnz 0x00007C47757D3946
00007c47757cffe1  movaps xmm10, xmm1
00007c47757cffe5  addpd xmm10, xmm11
00007c47757cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007c47757cfff0  ptest xmm8, xmm8
00007c47757cfff6  jnz 0x00007C47757D3A8A
00007c47757cfffc  movaps xmm1, xmm14
00007c47757d0000  addpd xmm1, xmm6
00007c47757d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007c47757d0009  ptest xmm11, xmm11
00007c47757d000f  jnz 0x00007C47757D3BCD
00007c47757d0015  vmovaps xmm14, [rsp+0x90]
00007c47757d001e  vpermilpd xmm14, xmm14, 0x00
00007c47757d0024  movaps xmm11, xmm13
00007c47757d0028  mulpd xmm11, xmm14
00007c47757d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007c47757d0033  ptest xmm8, xmm8
00007c47757d0039  jnz 0x00007C47757D3D0E
00007c47757d003f  vmovaps xmm14, [rsp+0x90]
00007c47757d0048  vpermilpd xmm14, xmm14, 0x00
00007c47757d004e  vmovaps xmm8, [rsp+0x10]
00007c47757d0054  movaps xmm13, xmm8
00007c47757d0058  mulpd xmm13, xmm14
00007c47757d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007c47757d0063  ptest xmm6, xmm6
00007c47757d0068  jnz 0x00007C47757D3E52
00007c47757d006e  vmovaps xmm14, [rsp+0x60]
00007c47757d0074  vpermilpd xmm14, xmm14, 0x00
00007c47757d007a  movaps xmm8, xmm7
00007c47757d007e  mulpd xmm8, xmm14
00007c47757d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007c47757d0089  ptest xmm6, xmm6
00007c47757d008e  jnz 0x00007C47757D3F96
00007c47757d0094  movaps xmm14, xmm12
00007c47757d0098  addpd xmm14, xmm9
00007c47757d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007c47757d00a3  ptest xmm7, xmm7
00007c47757d00a8  jnz 0x00007C47757D40D9
00007c47757d00ae  vmovaps xmm12, [rsp+0x60]
00007c47757d00b4  vpermilpd xmm12, xmm12, 0x00
00007c47757d00ba  vmovaps xmm7, [rsp+0xF0]
00007c47757d00c3  movaps xmm9, xmm7
00007c47757d00c7  mulpd xmm9, xmm12
00007c47757d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007c47757d00d2  ptest xmm6, xmm6
00007c47757d00d7  jnz 0x00007C47757D421D
00007c47757d00dd  movaps xmm12, xmm15
00007c47757d00e1  addpd xmm12, xmm11
00007c47757d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007c47757d00ec  ptest xmm7, xmm7
00007c47757d00f1  jnz 0x00007C47757D4360
00007c47757d00f7  vmovaps xmm15, [rsp+0x60]
00007c47757d00fd  vpermilpd xmm15, xmm15, 0x00
00007c47757d0103  vmovaps xmm7, [rsp+0x40]
00007c47757d0109  movaps xmm11, xmm7
00007c47757d010d  mulpd xmm11, xmm15
00007c47757d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007c47757d0118  ptest xmm6, xmm6
00007c47757d011d  jnz 0x00007C47757D44A4
00007c47757d0123  movaps xmm15, xmm10
00007c47757d0127  addpd xmm15, xmm13
00007c47757d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007c47757d0132  ptest xmm7, xmm7
00007c47757d0137  jnz 0x00007C47757D45E7
00007c47757d013d  vmovaps xmm13, [rsp+0x60]
00007c47757d0143  vpermilpd xmm13, xmm13, 0x00
00007c47757d0149  vmovaps xmm7, [rsp+0x50]
00007c47757d014f  movaps xmm10, xmm7
00007c47757d0153  mulpd xmm10, xmm13
00007c47757d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007c47757d015e  ptest xmm6, xmm6
00007c47757d0163  jnz 0x00007C47757D472B
00007c47757d0169  movaps xmm13, xmm1
00007c47757d016d  addpd xmm13, xmm8
00007c47757d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007c47757d0178  ptest xmm7, xmm7
00007c47757d017d  jnz 0x00007C47757D486E
00007c47757d0183  lea rax, [r14+0x70]
00007c47757d0187  movups xmm1, [r13+rax*1]
00007c47757d018d  movaps [r15+0x240], xmm1
00007c47757d0195  movaps xmm8, xmm14
00007c47757d0199  addpd xmm8, xmm9
00007c47757d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007c47757d01a4  ptest xmm7, xmm7
00007c47757d01a9  jnz 0x00007C47757D49BB
00007c47757d01af  movaps [r15+0x170], xmm8
00007c47757d01b7  vmovaps xmm14, [rsp+0x70]
00007c47757d01bd  vpermilpd xmm14, xmm14, 0x00
00007c47757d01c3  movaps xmm9, xmm1
00007c47757d01c7  mulpd xmm9, xmm14
00007c47757d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007c47757d01d2  ptest xmm7, xmm7
00007c47757d01d7  jnz 0x00007C47757D4AFF
00007c47757d01dd  vmovaps xmm1, [rsp+0x70]
00007c47757d01e3  vpermilpd xmm1, xmm1, 0x00
00007c47757d01e9  movaps xmm14, xmm4
00007c47757d01ed  mulpd xmm14, xmm1
00007c47757d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007c47757d01f8  ptest xmm7, xmm7
00007c47757d01fd  jnz 0x00007C47757D4C42
00007c47757d0203  movaps [r15+0x180], xmm14
00007c47757d020b  movaps xmm1, xmm12
00007c47757d020f  addpd xmm1, xmm11
00007c47757d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007c47757d0219  ptest xmm7, xmm7
00007c47757d021e  jnz 0x00007C47757D4D84
00007c47757d0224  movaps [r15+0x210], xmm1
00007c47757d022c  movups xmm12, [r13+r14*1]
00007c47757d0232  lea rax, [r14+0x10]
00007c47757d0236  movups xmm11, [r13+rax*1]
00007c47757d023c  movaps [r15+0x230], xmm11
00007c47757d0244  movaps xmm7, xmm15
00007c47757d0248  addpd xmm7, xmm10
00007c47757d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007c47757d0252  ptest xmm6, xmm6
00007c47757d0257  jnz 0x00007C47757D4EDA
00007c47757d025d  movaps [r15+0x130], xmm7
00007c47757d0265  vmovaps xmm15, [rsp+0x70]
00007c47757d026b  vpermilpd xmm15, xmm15, 0x00
00007c47757d0271  movaps xmm10, xmm11
00007c47757d0275  mulpd xmm10, xmm15
00007c47757d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007c47757d0280  ptest xmm6, xmm6
00007c47757d0285  jnz 0x00007C47757D501C
00007c47757d028b  movaps [r15+0x220], xmm10
00007c47757d0293  vmovaps xmm15, [rsp+0x70]
00007c47757d0299  vpermilpd xmm15, xmm15, 0x00
00007c47757d029f  movaps xmm11, xmm12
00007c47757d02a3  mulpd xmm11, xmm15
00007c47757d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007c47757d02ae  ptest xmm6, xmm6
00007c47757d02b3  jnz 0x00007C47757D5160
00007c47757d02b9  movaps xmm15, xmm13
00007c47757d02bd  addpd xmm15, xmm9
00007c47757d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007c47757d02c8  ptest xmm12, xmm12
00007c47757d02ce  jnz 0x00007C47757D52A4
00007c47757d02d4  movaps [r15+0x140], xmm15
00007c47757d02dc  movaps xmm13, xmm8
00007c47757d02e0  addpd xmm13, xmm14
00007c47757d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007c47757d02eb  ptest xmm12, xmm12
00007c47757d02f1  jnz 0x00007C47757D53E8
00007c47757d02f7  movaps [r15+0x150], xmm13
00007c47757d02ff  movaps xmm14, xmm1
00007c47757d0303  addpd xmm14, xmm10
00007c47757d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007c47757d030e  ptest xmm12, xmm12
00007c47757d0314  jnz 0x00007C47757D552C
00007c47757d031a  movaps [r15+0x160], xmm14
00007c47757d0322  movaps xmm1, xmm7
00007c47757d0325  addpd xmm1, xmm11
00007c47757d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007c47757d032f  ptest xmm12, xmm12
00007c47757d0335  jnz 0x00007C47757D566F
00007c47757d033b  movaps [r15+0x120], xmm1
00007c47757d0343  mov eax, 0x430920
00007c47757d0348  movups [r13+rax*1], xmm15
00007c47757d034e  mov eax, 0x430930
00007c47757d0353  movups [r13+rax*1], xmm13
00007c47757d0359  mov eax, 0x430940
00007c47757d035e  movups [r13+rax*1], xmm14
00007c47757d0364  mov eax, 0x430950
00007c47757d0369  movups [r13+rax*1], xmm1
00007c47757d036f  mov eax, [r15+0x108]
00007c47757d0376  sahf
00007c47757d0377  jnz 0x00007C47757D03A9
00007c47757d0379  cmp dword ptr [r15+0x318], 0x00
00007c47757d0381  jz 0x00007C47757DB900
00007c47757d0387  nop [rax+rax*1], ax
00007c47757d0390  nop [rax+rax*1], eax
00007c47757d0398  mov eax, 0x410444
00007c47757d039d  mov [r15+0x100], rax
00007c47757d03a4  jmp 0x00007C47755FE110
00007c47757d03a9  cmp dword ptr [r15+0x318], 0x00
00007c47757d03b1  jz 0x00007C47757D57E0
00007c47757d03b7  nop [rax+rax*1], ax
00007c47757d03c0  nop [rax+rax*1], eax
00007c47757d03c8  mov eax, 0x410278
00007c47757d03cd  mov [r15+0x100], rax
00007c47757d03d4  jmp 0x00007C47755FE110
00007c47757d03d9  int3
00007c47757d03da  call 0x00007C47756B52F0
00007c47757d03df  jmp 0x00007C47757CF016
00007c47757d03e4  call 0x00007C47756C4620
00007c47757d03e9  jmp 0x00007C47757CF023
00007c47757d03ee  call 0x00007C47756C33A0
00007c47757d03f3  jmp 0x00007C47757CF035
00007c47757d03f8  call 0x00007C47756C2120
00007c47757d03fd  jmp 0x00007C47757CF03F
00007c47757d0402  call 0x00007C47756C0860
00007c47757d0407  jmp 0x00007C47757CF067
00007c47757d040c  call 0x00007C47756BF5F0
00007c47757d0411  jmp 0x00007C47757CF073
00007c47757d0416  call 0x00007C47756C0860
00007c47757d041b  jmp 0x00007C47757CF0A5
00007c47757d0420  call 0x00007C47756BF5F0
00007c47757d0425  jmp 0x00007C47757CF0B1
00007c47757d042a  call 0x00007C47756C4740
00007c47757d042f  jmp 0x00007C47757CF0BE
00007c47757d0434  call 0x00007C47756B5400
00007c47757d0439  jmp 0x00007C47757CF0CB
00007c47757d043e  call 0x00007C47756B52F0
00007c47757d0443  jmp 0x00007C47757CF0D8
00007c47757d0448  call 0x00007C47756C4620
00007c47757d044d  jmp 0x00007C47757CF0E5
00007c47757d0452  call 0x00007C47756C0860
00007c47757d0457  jmp 0x00007C47757CF10D
00007c47757d045c  call 0x00007C47756BF5F0
00007c47757d0461  jmp 0x00007C47757CF119
00007c47757d0466  call 0x00007C4775609D70
00007c47757d046b  jmp 0x00007C47757CF11F
00007c47757d0470  call 0x00007C47756BE9C0
00007c47757d0475  jmp 0x00007C47757CF129
00007c47757d047a  call 0x00007C47756C0860
00007c47757d047f  jmp 0x00007C47757CF151
00007c47757d0484  call 0x00007C47756BF5F0
00007c47757d0489  jmp 0x00007C47757CF15D
00007c47757d048e  call 0x00007C47756BD750
00007c47757d0493  jmp 0x00007C47757CF16A
00007c47757d0498  call 0x00007C47756BC4E0
00007c47757d049d  jmp 0x00007C47757CF177
00007c47757d04a2  call 0x00007C47756C4740
00007c47757d04a7  jmp 0x00007C47757CF184
00007c47757d04ac  call 0x00007C47756B5400
00007c47757d04b1  jmp 0x00007C47757CF191
00007c47757d04b6  call 0x00007C47756B52F0
00007c47757d04bb  jmp 0x00007C47757CF19E
00007c47757d04c0  call 0x00007C47756C4620
00007c47757d04c5  jmp 0x00007C47757CF1AB
00007c47757d04ca  call 0x00007C47756C0860
00007c47757d04cf  jmp 0x00007C47757CF1BE
00007c47757d04d4  call 0x00007C47756BB270
00007c47757d04d9  jmp 0x00007C47757CF1CB
00007c47757d04de  call 0x00007C47756BA000
00007c47757d04e3  jmp 0x00007C47757CF1D8
00007c47757d04e8  call 0x00007C47756B8D90
00007c47757d04ed  jmp 0x00007C47757CF1E5
00007c47757d04f2  call 0x00007C47756B8A20
00007c47757d04f7  jmp 0x00007C47757CF1F2
00007c47757d04fc  call 0x00007C47756B5400
00007c47757d0501  jmp 0x00007C47757CF1FC
00007c47757d0506  call 0x00007C47756C2240
00007c47757d050b  jmp 0x00007C47757CF206
00007c47757d0510  call 0x00007C47756B52F0
00007c47757d0515  jmp 0x00007C47757CF210
00007c47757d051a  call 0x00007C47756C2120
00007c47757d051f  jmp 0x00007C47757CF21A
00007c47757d0524  call 0x00007C47756B77B0
00007c47757d0529  jmp 0x00007C47757CF224
00007c47757d052e  call 0x00007C47756B6550
00007c47757d0533  jmp 0x00007C47757CF22E
00007c47757d0538  call 0x00007C47756BFD50
00007c47757d053d  jmp 0x00007C47757CF240
00007c47757d0542  call 0x00007C47756B8EA0
00007c47757d0547  jmp 0x00007C47757CF24A
00007c47757d054c  call 0x00007C47756BFC30
00007c47757d0551  jmp 0x00007C47757CF257
00007c47757d0556  call 0x00007C47756B8D90
00007c47757d055b  jmp 0x00007C47757CF264
00007c47757d0560  call 0x00007C47756C2240
00007c47757d0565  jmp 0x00007C47757CF271
00007c47757d056a  call 0x00007C47756B5400
00007c47757d056f  jmp 0x00007C47757CF27E
00007c47757d0574  call 0x00007C47756B52F0
00007c47757d0579  jmp 0x00007C47757CF28B
00007c47757d057e  call 0x00007C47756C2120
00007c47757d0583  jmp 0x00007C47757CF298
00007c47757d0588  call 0x00007C47756B52F0
00007c47757d058d  jmp 0x00007C47757CF2AB
00007c47757d0592  call 0x00007C47756B52F0
00007c47757d0597  jmp 0x00007C47757CF2BE
00007c47757d059c  call 0x00007C47756B52F0
00007c47757d05a1  jmp 0x00007C47757CF2D1
00007c47757d05a6  call 0x00007C47756B52F0
00007c47757d05ab  jmp 0x00007C47757CF2E4
00007c47757d05b0  call 0x00007C47756C2240
00007c47757d05b5  jmp 0x00007C47757CF2F9
00007c47757d05ba  call 0x00007C47756C2240
00007c47757d05bf  jmp 0x00007C47757CF30C
00007c47757d05c4  call 0x00007C47756C2120
00007c47757d05c9  jmp 0x00007C47757CF319
00007c47757d05ce  call 0x00007C47756B52F0
00007c47757d05d3  jmp 0x00007C47757CF32C
00007c47757d05d8  call 0x00007C47756B52F0
00007c47757d05dd  jmp 0x00007C47757CF34F
00007c47757d05e2  call 0x00007C47756B52F0
00007c47757d05e7  jmp 0x00007C47757CF362
00007c47757d05ec  call 0x00007C47755FF540
00007c47757d05f1  jmp 0x00007C47757CF380
00007c47757d05f6  call 0x00007C4775608C20
00007c47757d05fb  jmp 0x00007C47757CF38A
00007c47757d0600  call 0x00007C47756D6600
00007c47757d0605  jmp 0x00007C47757CF396
00007c47757d060a  call 0x00007C47755FF540
00007c47757d060f  jmp 0x00007C47757CF3A6
00007c47757d0614  call 0x00007C47756C0370
00007c47757d0619  jmp 0x00007C47757CF3D4
00007c47757d061e  call 0x00007C47756BF100
00007c47757d0623  jmp 0x00007C47757CF3DD
00007c47757d0628  call 0x00007C47756C0370
00007c47757d062d  jmp 0x00007C47757CF43B
00007c47757d0632  call 0x00007C47756BF100
00007c47757d0637  jmp 0x00007C47757CF444
00007c47757d063c  call 0x00007C47756C0370
00007c47757d0641  jmp 0x00007C47757CF48B
00007c47757d0646  call 0x00007C47756BF100
00007c47757d064b  jmp 0x00007C47757CF494
00007c47757d0650  call 0x00007C477560B720
00007c47757d0655  jmp 0x00007C47757CF4D7
00007c47757d065a  call 0x00007C47756B47C0
00007c47757d065f  jmp 0x00007C47757CF4EA
00007c47757d0664  call 0x00007C4775608B00
00007c47757d0669  jmp 0x00007C47757CF501
00007c47757d066e  call 0x00007C47755FF430
00007c47757d0673  jmp 0x00007C47757CF514
00007c47757d0678  call 0x00007C47755FF430
00007c47757d067d  jmp 0x00007C47757CF527
00007c47757d0682  sub rsp, 0x08
00007c47757d0686  push rax
00007c47757d0687  push rcx
00007c47757d0688  push rdx
00007c47757d0689  push rdi
00007c47757d068a  push rsi
00007c47757d068b  push r8
00007c47757d068d  push r9
00007c47757d068f  push r10
00007c47757d0691  push r11
00007c47757d0693  sub rsp, 0xF0
00007c47757d069a  vmovaps [rsp], xmm0
00007c47757d069f  vmovaps [rsp+0x10], xmm2
00007c47757d06a5  vmovaps [rsp+0x20], xmm3
00007c47757d06ab  vmovaps [rsp+0x30], xmm4
00007c47757d06b1  vmovaps [rsp+0x40], xmm5
00007c47757d06b7  vmovaps [rsp+0x50], xmm6
00007c47757d06bd  vmovaps [rsp+0x60], xmm7
00007c47757d06c3  vmovaps [rsp+0x70], xmm8
00007c47757d06c9  vmovaps [rsp+0x80], xmm9
00007c47757d06d2  vmovaps [rsp+0x90], xmm10
00007c47757d06db  vmovaps [rsp+0xA0], xmm11
00007c47757d06e4  vmovaps [rsp+0xB0], xmm12
00007c47757d06ed  vmovaps [rsp+0xC0], xmm13
00007c47757d06f6  vmovaps [rsp+0xD0], xmm14
00007c47757d06ff  vmovaps [rsp+0xE0], xmm15
00007c47757d0708  sub rsp, 0x30
00007c47757d070c  movaps [rsp], xmm1
00007c47757d0710  movaps [rsp+0x10], xmm15
00007c47757d0716  movaps [rsp+0x20], xmm14
00007c47757d071c  lea rdi, [rsp]
00007c47757d0720  mov esi, 0x00
00007c47757d0725  mov rax, 0x62084E409530
00007c47757d072f  call rax
00007c47757d0731  movaps xmm1, [rsp]
00007c47757d0735  add rsp, 0x30
00007c47757d0739  vmovaps xmm0, [rsp]
00007c47757d073e  vmovaps xmm2, [rsp+0x10]
00007c47757d0744  vmovaps xmm3, [rsp+0x20]
00007c47757d074a  vmovaps xmm4, [rsp+0x30]
00007c47757d0750  vmovaps xmm5, [rsp+0x40]
00007c47757d0756  vmovaps xmm6, [rsp+0x50]
00007c47757d075c  vmovaps xmm7, [rsp+0x60]
00007c47757d0762  vmovaps xmm8, [rsp+0x70]
00007c47757d0768  vmovaps xmm9, [rsp+0x80]
00007c47757d0771  vmovaps xmm10, [rsp+0x90]
00007c47757d077a  vmovaps xmm11, [rsp+0xA0]
00007c47757d0783  vmovaps xmm12, [rsp+0xB0]
00007c47757d078c  vmovaps xmm13, [rsp+0xC0]
00007c47757d0795  vmovaps xmm14, [rsp+0xD0]
00007c47757d079e  vmovaps xmm15, [rsp+0xE0]
00007c47757d07a7  add rsp, 0xF0
00007c47757d07ae  pop r11
00007c47757d07b0  pop r10
00007c47757d07b2  pop r9
00007c47757d07b4  pop r8
00007c47757d07b6  pop rsi
00007c47757d07b7  pop rdi
00007c47757d07b8  pop rdx
00007c47757d07b9  pop rcx
00007c47757d07ba  pop rax
00007c47757d07bb  add rsp, 0x08
00007c47757d07bf  jmp 0x00007C47757CF581
00007c47757d07c4  sub rsp, 0x08
00007c47757d07c8  push rax
00007c47757d07c9  push rcx
00007c47757d07ca  push rdx
00007c47757d07cb  push rdi
00007c47757d07cc  push rsi
00007c47757d07cd  push r8
00007c47757d07cf  push r9
00007c47757d07d1  push r10
00007c47757d07d3  push r11
00007c47757d07d5  sub rsp, 0xF0
00007c47757d07dc  vmovaps [rsp], xmm0
00007c47757d07e1  vmovaps [rsp+0x10], xmm1
00007c47757d07e7  vmovaps [rsp+0x20], xmm2
00007c47757d07ed  vmovaps [rsp+0x30], xmm3
00007c47757d07f3  vmovaps [rsp+0x40], xmm4
00007c47757d07f9  vmovaps [rsp+0x50], xmm5
00007c47757d07ff  vmovaps [rsp+0x60], xmm6
00007c47757d0805  vmovaps [rsp+0x70], xmm7
00007c47757d080b  vmovaps [rsp+0x80], xmm8
00007c47757d0814  vmovaps [rsp+0x90], xmm9
00007c47757d081d  vmovaps [rsp+0xA0], xmm10
00007c47757d0826  vmovaps [rsp+0xB0], xmm11
00007c47757d082f  vmovaps [rsp+0xC0], xmm12
00007c47757d0838  vmovaps [rsp+0xD0], xmm14
00007c47757d0841  vmovaps [rsp+0xE0], xmm15
00007c47757d084a  sub rsp, 0x30
00007c47757d084e  movaps [rsp], xmm13
00007c47757d0853  movaps [rsp+0x10], xmm1
00007c47757d0858  movaps [rsp+0x20], xmm14
00007c47757d085e  lea rdi, [rsp]
00007c47757d0862  mov esi, 0x00
00007c47757d0867  mov rax, 0x62084E409530
00007c47757d0871  call rax
00007c47757d0873  movaps xmm13, [rsp]
00007c47757d0878  add rsp, 0x30
00007c47757d087c  vmovaps xmm0, [rsp]
00007c47757d0881  vmovaps xmm1, [rsp+0x10]
00007c47757d0887  vmovaps xmm2, [rsp+0x20]
00007c47757d088d  vmovaps xmm3, [rsp+0x30]
00007c47757d0893  vmovaps xmm4, [rsp+0x40]
00007c47757d0899  vmovaps xmm5, [rsp+0x50]
00007c47757d089f  vmovaps xmm6, [rsp+0x60]
00007c47757d08a5  vmovaps xmm7, [rsp+0x70]
00007c47757d08ab  vmovaps xmm8, [rsp+0x80]
00007c47757d08b4  vmovaps xmm9, [rsp+0x90]
00007c47757d08bd  vmovaps xmm10, [rsp+0xA0]
00007c47757d08c6  vmovaps xmm11, [rsp+0xB0]
00007c47757d08cf  vmovaps xmm12, [rsp+0xC0]
00007c47757d08d8  vmovaps xmm14, [rsp+0xD0]
00007c47757d08e1  vmovaps xmm15, [rsp+0xE0]
00007c47757d08ea  add rsp, 0xF0
00007c47757d08f1  pop r11
00007c47757d08f3  pop r10
00007c47757d08f5  pop r9
00007c47757d08f7  pop r8
00007c47757d08f9  pop rsi
00007c47757d08fa  pop rdi
00007c47757d08fb  pop rdx
00007c47757d08fc  pop rcx
00007c47757d08fd  pop rax
00007c47757d08fe  add rsp, 0x08
00007c47757d0902  jmp 0x00007C47757CF5CF
00007c47757d0907  sub rsp, 0x08
00007c47757d090b  push rax
00007c47757d090c  push rcx
00007c47757d090d  push rdx
00007c47757d090e  push rdi
00007c47757d090f  push rsi
00007c47757d0910  push r8
00007c47757d0912  push r9
00007c47757d0914  push r10
00007c47757d0916  push r11
00007c47757d0918  sub rsp, 0xF0
00007c47757d091f  vmovaps [rsp], xmm0
00007c47757d0924  vmovaps [rsp+0x10], xmm1
00007c47757d092a  vmovaps [rsp+0x20], xmm2
00007c47757d0930  vmovaps [rsp+0x30], xmm3
00007c47757d0936  vmovaps [rsp+0x40], xmm4
00007c47757d093c  vmovaps [rsp+0x50], xmm5
00007c47757d0942  vmovaps [rsp+0x60], xmm6
00007c47757d0948  vmovaps [rsp+0x70], xmm7
00007c47757d094e  vmovaps [rsp+0x80], xmm8
00007c47757d0957  vmovaps [rsp+0x90], xmm9
00007c47757d0960  vmovaps [rsp+0xA0], xmm10
00007c47757d0969  vmovaps [rsp+0xB0], xmm11
00007c47757d0972  vmovaps [rsp+0xC0], xmm12
00007c47757d097b  vmovaps [rsp+0xD0], xmm13
00007c47757d0984  vmovaps [rsp+0xE0], xmm14
00007c47757d098d  sub rsp, 0x30
00007c47757d0991  movaps [rsp], xmm15
00007c47757d0996  movaps [rsp+0x10], xmm14
00007c47757d099c  movaps [rsp+0x20], xmm1
00007c47757d09a1  lea rdi, [rsp]
00007c47757d09a5  mov esi, 0x00
00007c47757d09aa  mov rax, 0x62084E409530
00007c47757d09b4  call rax
00007c47757d09b6  movaps xmm15, [rsp]
00007c47757d09bb  add rsp, 0x30
00007c47757d09bf  vmovaps xmm0, [rsp]
00007c47757d09c4  vmovaps xmm1, [rsp+0x10]
00007c47757d09ca  vmovaps xmm2, [rsp+0x20]
00007c47757d09d0  vmovaps xmm3, [rsp+0x30]
00007c47757d09d6  vmovaps xmm4, [rsp+0x40]
00007c47757d09dc  vmovaps xmm5, [rsp+0x50]
00007c47757d09e2  vmovaps xmm6, [rsp+0x60]
00007c47757d09e8  vmovaps xmm7, [rsp+0x70]
00007c47757d09ee  vmovaps xmm8, [rsp+0x80]
00007c47757d09f7  vmovaps xmm9, [rsp+0x90]
00007c47757d0a00  vmovaps xmm10, [rsp+0xA0]
00007c47757d0a09  vmovaps xmm11, [rsp+0xB0]
00007c47757d0a12  vmovaps xmm12, [rsp+0xC0]
00007c47757d0a1b  vmovaps xmm13, [rsp+0xD0]
00007c47757d0a24  vmovaps xmm14, [rsp+0xE0]
00007c47757d0a2d  add rsp, 0xF0
00007c47757d0a34  pop r11
00007c47757d0a36  pop r10
00007c47757d0a38  pop r9
00007c47757d0a3a  pop r8
00007c47757d0a3c  pop rsi
00007c47757d0a3d  pop rdi
00007c47757d0a3e  pop rdx
00007c47757d0a3f  pop rcx
00007c47757d0a40  pop rax
00007c47757d0a41  add rsp, 0x08
00007c47757d0a45  jmp 0x00007C47757CF617
00007c47757d0a4a  sub rsp, 0x08
00007c47757d0a4e  push rax
00007c47757d0a4f  push rcx
00007c47757d0a50  push rdx
00007c47757d0a51  push rdi
00007c47757d0a52  push rsi
00007c47757d0a53  push r8
00007c47757d0a55  push r9
00007c47757d0a57  push r10
00007c47757d0a59  push r11
00007c47757d0a5b  sub rsp, 0xF0
00007c47757d0a62  vmovaps [rsp], xmm0
00007c47757d0a67  vmovaps [rsp+0x10], xmm2
00007c47757d0a6d  vmovaps [rsp+0x20], xmm3
00007c47757d0a73  vmovaps [rsp+0x30], xmm4
00007c47757d0a79  vmovaps [rsp+0x40], xmm5
00007c47757d0a7f  vmovaps [rsp+0x50], xmm6
00007c47757d0a85  vmovaps [rsp+0x60], xmm7
00007c47757d0a8b  vmovaps [rsp+0x70], xmm8
00007c47757d0a91  vmovaps [rsp+0x80], xmm9
00007c47757d0a9a  vmovaps [rsp+0x90], xmm10
00007c47757d0aa3  vmovaps [rsp+0xA0], xmm11
00007c47757d0aac  vmovaps [rsp+0xB0], xmm12
00007c47757d0ab5  vmovaps [rsp+0xC0], xmm13
00007c47757d0abe  vmovaps [rsp+0xD0], xmm14
00007c47757d0ac7  vmovaps [rsp+0xE0], xmm15
00007c47757d0ad0  sub rsp, 0x30
00007c47757d0ad4  movaps [rsp], xmm1
00007c47757d0ad8  movaps [rsp+0x10], xmm14
00007c47757d0ade  movaps [rsp+0x20], xmm10
00007c47757d0ae4  lea rdi, [rsp]
00007c47757d0ae8  mov esi, 0x00
00007c47757d0aed  mov rax, 0x62084E409530
00007c47757d0af7  call rax
00007c47757d0af9  movaps xmm1, [rsp]
00007c47757d0afd  add rsp, 0x30
00007c47757d0b01  vmovaps xmm0, [rsp]
00007c47757d0b06  vmovaps xmm2, [rsp+0x10]
00007c47757d0b0c  vmovaps xmm3, [rsp+0x20]
00007c47757d0b12  vmovaps xmm4, [rsp+0x30]
00007c47757d0b18  vmovaps xmm5, [rsp+0x40]
00007c47757d0b1e  vmovaps xmm6, [rsp+0x50]
00007c47757d0b24  vmovaps xmm7, [rsp+0x60]
00007c47757d0b2a  vmovaps xmm8, [rsp+0x70]
00007c47757d0b30  vmovaps xmm9, [rsp+0x80]
00007c47757d0b39  vmovaps xmm10, [rsp+0x90]
00007c47757d0b42  vmovaps xmm11, [rsp+0xA0]
00007c47757d0b4b  vmovaps xmm12, [rsp+0xB0]
00007c47757d0b54  vmovaps xmm13, [rsp+0xC0]
00007c47757d0b5d  vmovaps xmm14, [rsp+0xD0]
00007c47757d0b66  vmovaps xmm15, [rsp+0xE0]
00007c47757d0b6f  add rsp, 0xF0
00007c47757d0b76  pop r11
00007c47757d0b78  pop r10
00007c47757d0b7a  pop r9
00007c47757d0b7c  pop r8
00007c47757d0b7e  pop rsi
00007c47757d0b7f  pop rdi
00007c47757d0b80  pop rdx
00007c47757d0b81  pop rcx
00007c47757d0b82  pop rax
00007c47757d0b83  add rsp, 0x08
00007c47757d0b87  jmp 0x00007C47757CF631
00007c47757d0b8c  sub rsp, 0x08
00007c47757d0b90  push rax
00007c47757d0b91  push rcx
00007c47757d0b92  push rdx
00007c47757d0b93  push rdi
00007c47757d0b94  push rsi
00007c47757d0b95  push r8
00007c47757d0b97  push r9
00007c47757d0b99  push r10
00007c47757d0b9b  push r11
00007c47757d0b9d  sub rsp, 0xF0
00007c47757d0ba4  vmovaps [rsp], xmm0
00007c47757d0ba9  vmovaps [rsp+0x10], xmm1
00007c47757d0baf  vmovaps [rsp+0x20], xmm2
00007c47757d0bb5  vmovaps [rsp+0x30], xmm3
00007c47757d0bbb  vmovaps [rsp+0x40], xmm4
00007c47757d0bc1  vmovaps [rsp+0x50], xmm5
00007c47757d0bc7  vmovaps [rsp+0x60], xmm6
00007c47757d0bcd  vmovaps [rsp+0x70], xmm7
00007c47757d0bd3  vmovaps [rsp+0x80], xmm8
00007c47757d0bdc  vmovaps [rsp+0x90], xmm9
00007c47757d0be5  vmovaps [rsp+0xA0], xmm10
00007c47757d0bee  vmovaps [rsp+0xB0], xmm11
00007c47757d0bf7  vmovaps [rsp+0xC0], xmm12
00007c47757d0c00  vmovaps [rsp+0xD0], xmm14
00007c47757d0c09  vmovaps [rsp+0xE0], xmm15
00007c47757d0c12  sub rsp, 0x30
00007c47757d0c16  movaps [rsp], xmm13
00007c47757d0c1b  movaps [rsp+0x10], xmm14
00007c47757d0c21  movaps [rsp+0x20], xmm2
00007c47757d0c26  lea rdi, [rsp]
00007c47757d0c2a  mov esi, 0x00
00007c47757d0c2f  mov rax, 0x62084E409530
00007c47757d0c39  call rax
00007c47757d0c3b  movaps xmm13, [rsp]
00007c47757d0c40  add rsp, 0x30
00007c47757d0c44  vmovaps xmm0, [rsp]
00007c47757d0c49  vmovaps xmm1, [rsp+0x10]
00007c47757d0c4f  vmovaps xmm2, [rsp+0x20]
00007c47757d0c55  vmovaps xmm3, [rsp+0x30]
00007c47757d0c5b  vmovaps xmm4, [rsp+0x40]
00007c47757d0c61  vmovaps xmm5, [rsp+0x50]
00007c47757d0c67  vmovaps xmm6, [rsp+0x60]
00007c47757d0c6d  vmovaps xmm7, [rsp+0x70]
00007c47757d0c73  vmovaps xmm8, [rsp+0x80]
00007c47757d0c7c  vmovaps xmm9, [rsp+0x90]
00007c47757d0c85  vmovaps xmm10, [rsp+0xA0]
00007c47757d0c8e  vmovaps xmm11, [rsp+0xB0]
00007c47757d0c97  vmovaps xmm12, [rsp+0xC0]
00007c47757d0ca0  vmovaps xmm14, [rsp+0xD0]
00007c47757d0ca9  vmovaps xmm15, [rsp+0xE0]
00007c47757d0cb2  add rsp, 0xF0
00007c47757d0cb9  pop r11
00007c47757d0cbb  pop r10
00007c47757d0cbd  pop r9
00007c47757d0cbf  pop r8
00007c47757d0cc1  pop rsi
00007c47757d0cc2  pop rdi
00007c47757d0cc3  pop rdx
00007c47757d0cc4  pop rcx
00007c47757d0cc5  pop rax
00007c47757d0cc6  add rsp, 0x08
00007c47757d0cca  jmp 0x00007C47757CF64C
00007c47757d0ccf  sub rsp, 0x08
00007c47757d0cd3  push rax
00007c47757d0cd4  push rcx
00007c47757d0cd5  push rdx
00007c47757d0cd6  push rdi
00007c47757d0cd7  push rsi
00007c47757d0cd8  push r8
00007c47757d0cda  push r9
00007c47757d0cdc  push r10
00007c47757d0cde  push r11
00007c47757d0ce0  sub rsp, 0xF0
00007c47757d0ce7  vmovaps [rsp], xmm0
00007c47757d0cec  vmovaps [rsp+0x10], xmm2
00007c47757d0cf2  vmovaps [rsp+0x20], xmm3
00007c47757d0cf8  vmovaps [rsp+0x30], xmm4
00007c47757d0cfe  vmovaps [rsp+0x40], xmm5
00007c47757d0d04  vmovaps [rsp+0x50], xmm6
00007c47757d0d0a  vmovaps [rsp+0x60], xmm7
00007c47757d0d10  vmovaps [rsp+0x70], xmm8
00007c47757d0d16  vmovaps [rsp+0x80], xmm9
00007c47757d0d1f  vmovaps [rsp+0x90], xmm10
00007c47757d0d28  vmovaps [rsp+0xA0], xmm11
00007c47757d0d31  vmovaps [rsp+0xB0], xmm12
00007c47757d0d3a  vmovaps [rsp+0xC0], xmm13
00007c47757d0d43  vmovaps [rsp+0xD0], xmm14
00007c47757d0d4c  vmovaps [rsp+0xE0], xmm15
00007c47757d0d55  sub rsp, 0x30
00007c47757d0d59  movaps [rsp], xmm1
00007c47757d0d5d  movaps [rsp+0x10], xmm10
00007c47757d0d63  movaps [rsp+0x20], xmm2
00007c47757d0d68  lea rdi, [rsp]
00007c47757d0d6c  mov esi, 0x00
00007c47757d0d71  mov rax, 0x62084E409530
00007c47757d0d7b  call rax
00007c47757d0d7d  movaps xmm1, [rsp]
00007c47757d0d81  add rsp, 0x30
00007c47757d0d85  vmovaps xmm0, [rsp]
00007c47757d0d8a  vmovaps xmm2, [rsp+0x10]
00007c47757d0d90  vmovaps xmm3, [rsp+0x20]
00007c47757d0d96  vmovaps xmm4, [rsp+0x30]
00007c47757d0d9c  vmovaps xmm5, [rsp+0x40]
00007c47757d0da2  vmovaps xmm6, [rsp+0x50]
00007c47757d0da8  vmovaps xmm7, [rsp+0x60]
00007c47757d0dae  vmovaps xmm8, [rsp+0x70]
00007c47757d0db4  vmovaps xmm9, [rsp+0x80]
00007c47757d0dbd  vmovaps xmm10, [rsp+0x90]
00007c47757d0dc6  vmovaps xmm11, [rsp+0xA0]
00007c47757d0dcf  vmovaps xmm12, [rsp+0xB0]
00007c47757d0dd8  vmovaps xmm13, [rsp+0xC0]
00007c47757d0de1  vmovaps xmm14, [rsp+0xD0]
00007c47757d0dea  vmovaps xmm15, [rsp+0xE0]
00007c47757d0df3  add rsp, 0xF0
00007c47757d0dfa  pop r11
00007c47757d0dfc  pop r10
00007c47757d0dfe  pop r9
00007c47757d0e00  pop r8
00007c47757d0e02  pop rsi
00007c47757d0e03  pop rdi
00007c47757d0e04  pop rdx
00007c47757d0e05  pop rcx
00007c47757d0e06  pop rax
00007c47757d0e07  add rsp, 0x08
00007c47757d0e0b  jmp 0x00007C47757CF6B4
00007c47757d0e10  sub rsp, 0x08
00007c47757d0e14  push rax
00007c47757d0e15  push rcx
00007c47757d0e16  push rdx
00007c47757d0e17  push rdi
00007c47757d0e18  push rsi
00007c47757d0e19  push r8
00007c47757d0e1b  push r9
00007c47757d0e1d  push r10
00007c47757d0e1f  push r11
00007c47757d0e21  sub rsp, 0xF0
00007c47757d0e28  vmovaps [rsp], xmm0
00007c47757d0e2d  vmovaps [rsp+0x10], xmm1
00007c47757d0e33  vmovaps [rsp+0x20], xmm2
00007c47757d0e39  vmovaps [rsp+0x30], xmm3
00007c47757d0e3f  vmovaps [rsp+0x40], xmm4
00007c47757d0e45  vmovaps [rsp+0x50], xmm5
00007c47757d0e4b  vmovaps [rsp+0x60], xmm6
00007c47757d0e51  vmovaps [rsp+0x70], xmm7
00007c47757d0e57  vmovaps [rsp+0x80], xmm8
00007c47757d0e60  vmovaps [rsp+0x90], xmm9
00007c47757d0e69  vmovaps [rsp+0xA0], xmm10
00007c47757d0e72  vmovaps [rsp+0xB0], xmm11
00007c47757d0e7b  vmovaps [rsp+0xC0], xmm12
00007c47757d0e84  vmovaps [rsp+0xD0], xmm13
00007c47757d0e8d  vmovaps [rsp+0xE0], xmm14
00007c47757d0e96  sub rsp, 0x30
00007c47757d0e9a  movaps [rsp], xmm15
00007c47757d0e9f  movaps [rsp+0x10], xmm10
00007c47757d0ea5  movaps [rsp+0x20], xmm2
00007c47757d0eaa  lea rdi, [rsp]
00007c47757d0eae  mov esi, 0x00
00007c47757d0eb3  mov rax, 0x62084E409530
00007c47757d0ebd  call rax
00007c47757d0ebf  movaps xmm15, [rsp]
00007c47757d0ec4  add rsp, 0x30
00007c47757d0ec8  vmovaps xmm0, [rsp]
00007c47757d0ecd  vmovaps xmm1, [rsp+0x10]
00007c47757d0ed3  vmovaps xmm2, [rsp+0x20]
00007c47757d0ed9  vmovaps xmm3, [rsp+0x30]
00007c47757d0edf  vmovaps xmm4, [rsp+0x40]
00007c47757d0ee5  vmovaps xmm5, [rsp+0x50]
00007c47757d0eeb  vmovaps xmm6, [rsp+0x60]
00007c47757d0ef1  vmovaps xmm7, [rsp+0x70]
00007c47757d0ef7  vmovaps xmm8, [rsp+0x80]
00007c47757d0f00  vmovaps xmm9, [rsp+0x90]
00007c47757d0f09  vmovaps xmm10, [rsp+0xA0]
00007c47757d0f12  vmovaps xmm11, [rsp+0xB0]
00007c47757d0f1b  vmovaps xmm12, [rsp+0xC0]
00007c47757d0f24  vmovaps xmm13, [rsp+0xD0]
00007c47757d0f2d  vmovaps xmm14, [rsp+0xE0]
00007c47757d0f36  add rsp, 0xF0
00007c47757d0f3d  pop r11
00007c47757d0f3f  pop r10
00007c47757d0f41  pop r9
00007c47757d0f43  pop r8
00007c47757d0f45  pop rsi
00007c47757d0f46  pop rdi
00007c47757d0f47  pop rdx
00007c47757d0f48  pop rcx
00007c47757d0f49  pop rax
00007c47757d0f4a  add rsp, 0x08
00007c47757d0f4e  jmp 0x00007C47757CF706
00007c47757d0f53  sub rsp, 0x08
00007c47757d0f57  push rax
00007c47757d0f58  push rcx
00007c47757d0f59  push rdx
00007c47757d0f5a  push rdi
00007c47757d0f5b  push rsi
00007c47757d0f5c  push r8
00007c47757d0f5e  push r9
00007c47757d0f60  push r10
00007c47757d0f62  push r11
00007c47757d0f64  sub rsp, 0xF0
00007c47757d0f6b  vmovaps [rsp], xmm0
00007c47757d0f70  vmovaps [rsp+0x10], xmm2
00007c47757d0f76  vmovaps [rsp+0x20], xmm3
00007c47757d0f7c  vmovaps [rsp+0x30], xmm4
00007c47757d0f82  vmovaps [rsp+0x40], xmm5
00007c47757d0f88  vmovaps [rsp+0x50], xmm6
00007c47757d0f8e  vmovaps [rsp+0x60], xmm7
00007c47757d0f94  vmovaps [rsp+0x70], xmm8
00007c47757d0f9a  vmovaps [rsp+0x80], xmm9
00007c47757d0fa3  vmovaps [rsp+0x90], xmm10
00007c47757d0fac  vmovaps [rsp+0xA0], xmm11
00007c47757d0fb5  vmovaps [rsp+0xB0], xmm12
00007c47757d0fbe  vmovaps [rsp+0xC0], xmm13
00007c47757d0fc7  vmovaps [rsp+0xD0], xmm14
00007c47757d0fd0  vmovaps [rsp+0xE0], xmm15
00007c47757d0fd9  sub rsp, 0x30
00007c47757d0fdd  movaps [rsp], xmm1
00007c47757d0fe1  movaps [rsp+0x10], xmm10
00007c47757d0fe7  movaps [rsp+0x20], xmm12
00007c47757d0fed  lea rdi, [rsp]
00007c47757d0ff1  mov esi, 0x00
00007c47757d0ff6  mov rax, 0x62084E409530
00007c47757d1000  call rax
00007c47757d1002  movaps xmm1, [rsp]
00007c47757d1006  add rsp, 0x30
00007c47757d100a  vmovaps xmm0, [rsp]
00007c47757d100f  vmovaps xmm2, [rsp+0x10]
00007c47757d1015  vmovaps xmm3, [rsp+0x20]
00007c47757d101b  vmovaps xmm4, [rsp+0x30]
00007c47757d1021  vmovaps xmm5, [rsp+0x40]
00007c47757d1027  vmovaps xmm6, [rsp+0x50]
00007c47757d102d  vmovaps xmm7, [rsp+0x60]
00007c47757d1033  vmovaps xmm8, [rsp+0x70]
00007c47757d1039  vmovaps xmm9, [rsp+0x80]
00007c47757d1042  vmovaps xmm10, [rsp+0x90]
00007c47757d104b  vmovaps xmm11, [rsp+0xA0]
00007c47757d1054  vmovaps xmm12, [rsp+0xB0]
00007c47757d105d  vmovaps xmm13, [rsp+0xC0]
00007c47757d1066  vmovaps xmm14, [rsp+0xD0]
00007c47757d106f  vmovaps xmm15, [rsp+0xE0]
00007c47757d1078  add rsp, 0xF0
00007c47757d107f  pop r11
00007c47757d1081  pop r10
00007c47757d1083  pop r9
00007c47757d1085  pop r8
00007c47757d1087  pop rsi
00007c47757d1088  pop rdi
00007c47757d1089  pop rdx
00007c47757d108a  pop rcx
00007c47757d108b  pop rax
00007c47757d108c  add rsp, 0x08
00007c47757d1090  jmp 0x00007C47757CF732
00007c47757d1095  sub rsp, 0x08
00007c47757d1099  push rax
00007c47757d109a  push rcx
00007c47757d109b  push rdx
00007c47757d109c  push rdi
00007c47757d109d  push rsi
00007c47757d109e  push r8
00007c47757d10a0  push r9
00007c47757d10a2  push r10
00007c47757d10a4  push r11
00007c47757d10a6  sub rsp, 0xF0
00007c47757d10ad  vmovaps [rsp], xmm0
00007c47757d10b2  vmovaps [rsp+0x10], xmm1
00007c47757d10b8  vmovaps [rsp+0x20], xmm2
00007c47757d10be  vmovaps [rsp+0x30], xmm3
00007c47757d10c4  vmovaps [rsp+0x40], xmm4
00007c47757d10ca  vmovaps [rsp+0x50], xmm5
00007c47757d10d0  vmovaps [rsp+0x60], xmm6
00007c47757d10d6  vmovaps [rsp+0x70], xmm7
00007c47757d10dc  vmovaps [rsp+0x80], xmm8
00007c47757d10e5  vmovaps [rsp+0x90], xmm9
00007c47757d10ee  vmovaps [rsp+0xA0], xmm10
00007c47757d10f7  vmovaps [rsp+0xB0], xmm11
00007c47757d1100  vmovaps [rsp+0xC0], xmm12
00007c47757d1109  vmovaps [rsp+0xD0], xmm13
00007c47757d1112  vmovaps [rsp+0xE0], xmm14
00007c47757d111b  sub rsp, 0x30
00007c47757d111f  movaps [rsp], xmm15
00007c47757d1124  movaps [rsp+0x10], xmm10
00007c47757d112a  movaps [rsp+0x20], xmm12
00007c47757d1130  lea rdi, [rsp]
00007c47757d1134  mov esi, 0x00
00007c47757d1139  mov rax, 0x62084E409530
00007c47757d1143  call rax
00007c47757d1145  movaps xmm15, [rsp]
00007c47757d114a  add rsp, 0x30
00007c47757d114e  vmovaps xmm0, [rsp]
00007c47757d1153  vmovaps xmm1, [rsp+0x10]
00007c47757d1159  vmovaps xmm2, [rsp+0x20]
00007c47757d115f  vmovaps xmm3, [rsp+0x30]
00007c47757d1165  vmovaps xmm4, [rsp+0x40]
00007c47757d116b  vmovaps xmm5, [rsp+0x50]
00007c47757d1171  vmovaps xmm6, [rsp+0x60]
00007c47757d1177  vmovaps xmm7, [rsp+0x70]
00007c47757d117d  vmovaps xmm8, [rsp+0x80]
00007c47757d1186  vmovaps xmm9, [rsp+0x90]
00007c47757d118f  vmovaps xmm10, [rsp+0xA0]
00007c47757d1198  vmovaps xmm11, [rsp+0xB0]
00007c47757d11a1  vmovaps xmm12, [rsp+0xC0]
00007c47757d11aa  vmovaps xmm13, [rsp+0xD0]
00007c47757d11b3  vmovaps xmm14, [rsp+0xE0]
00007c47757d11bc  add rsp, 0xF0
00007c47757d11c3  pop r11
00007c47757d11c5  pop r10
00007c47757d11c7  pop r9
00007c47757d11c9  pop r8
00007c47757d11cb  pop rsi
00007c47757d11cc  pop rdi
00007c47757d11cd  pop rdx
00007c47757d11ce  pop rcx
00007c47757d11cf  pop rax
00007c47757d11d0  add rsp, 0x08
00007c47757d11d4  jmp 0x00007C47757CF75E
00007c47757d11d9  call 0x00007C47755FF430
00007c47757d11de  jmp 0x00007C47757CF7EE
00007c47757d11e3  call 0x00007C47755FF430
00007c47757d11e8  jmp 0x00007C47757CF801
00007c47757d11ed  sub rsp, 0x08
00007c47757d11f1  push rax
00007c47757d11f2  push rcx
00007c47757d11f3  push rdx
00007c47757d11f4  push rdi
00007c47757d11f5  push rsi
00007c47757d11f6  push r8
00007c47757d11f8  push r9
00007c47757d11fa  push r10
00007c47757d11fc  push r11
00007c47757d11fe  sub rsp, 0xF0
00007c47757d1205  vmovaps [rsp], xmm0
00007c47757d120a  vmovaps [rsp+0x10], xmm2
00007c47757d1210  vmovaps [rsp+0x20], xmm3
00007c47757d1216  vmovaps [rsp+0x30], xmm4
00007c47757d121c  vmovaps [rsp+0x40], xmm5
00007c47757d1222  vmovaps [rsp+0x50], xmm6
00007c47757d1228  vmovaps [rsp+0x60], xmm7
00007c47757d122e  vmovaps [rsp+0x70], xmm8
00007c47757d1234  vmovaps [rsp+0x80], xmm9
00007c47757d123d  vmovaps [rsp+0x90], xmm10
00007c47757d1246  vmovaps [rsp+0xA0], xmm11
00007c47757d124f  vmovaps [rsp+0xB0], xmm12
00007c47757d1258  vmovaps [rsp+0xC0], xmm13
00007c47757d1261  vmovaps [rsp+0xD0], xmm14
00007c47757d126a  vmovaps [rsp+0xE0], xmm15
00007c47757d1273  sub rsp, 0x30
00007c47757d1277  movaps [rsp], xmm1
00007c47757d127b  movaps [rsp+0x10], xmm13
00007c47757d1281  movaps [rsp+0x20], xmm2
00007c47757d1286  lea rdi, [rsp]
00007c47757d128a  mov esi, 0x00
00007c47757d128f  mov rax, 0x62084E409530
00007c47757d1299  call rax
00007c47757d129b  movaps xmm1, [rsp]
00007c47757d129f  add rsp, 0x30
00007c47757d12a3  vmovaps xmm0, [rsp]
00007c47757d12a8  vmovaps xmm2, [rsp+0x10]
00007c47757d12ae  vmovaps xmm3, [rsp+0x20]
00007c47757d12b4  vmovaps xmm4, [rsp+0x30]
00007c47757d12ba  vmovaps xmm5, [rsp+0x40]
00007c47757d12c0  vmovaps xmm6, [rsp+0x50]
00007c47757d12c6  vmovaps xmm7, [rsp+0x60]
00007c47757d12cc  vmovaps xmm8, [rsp+0x70]
00007c47757d12d2  vmovaps xmm9, [rsp+0x80]
00007c47757d12db  vmovaps xmm10, [rsp+0x90]
00007c47757d12e4  vmovaps xmm11, [rsp+0xA0]
00007c47757d12ed  vmovaps xmm12, [rsp+0xB0]
00007c47757d12f6  vmovaps xmm13, [rsp+0xC0]
00007c47757d12ff  vmovaps xmm14, [rsp+0xD0]
00007c47757d1308  vmovaps xmm15, [rsp+0xE0]
00007c47757d1311  add rsp, 0xF0
00007c47757d1318  pop r11
00007c47757d131a  pop r10
00007c47757d131c  pop r9
00007c47757d131e  pop r8
00007c47757d1320  pop rsi
00007c47757d1321  pop rdi
00007c47757d1322  pop rdx
00007c47757d1323  pop rcx
00007c47757d1324  pop rax
00007c47757d1325  add rsp, 0x08
00007c47757d1329  jmp 0x00007C47757CF82C
00007c47757d132e  call 0x00007C477560E760
00007c47757d1333  jmp 0x00007C47757CF839
00007c47757d1338  sub rsp, 0x08
00007c47757d133c  push rax
00007c47757d133d  push rcx
00007c47757d133e  push rdx
00007c47757d133f  push rdi
00007c47757d1340  push rsi
00007c47757d1341  push r8
00007c47757d1343  push r9
00007c47757d1345  push r10
00007c47757d1347  push r11
00007c47757d1349  sub rsp, 0xF0
00007c47757d1350  vmovaps [rsp], xmm0
00007c47757d1355  vmovaps [rsp+0x10], xmm1
00007c47757d135b  vmovaps [rsp+0x20], xmm2
00007c47757d1361  vmovaps [rsp+0x30], xmm3
00007c47757d1367  vmovaps [rsp+0x40], xmm4
00007c47757d136d  vmovaps [rsp+0x50], xmm5
00007c47757d1373  vmovaps [rsp+0x60], xmm6
00007c47757d1379  vmovaps [rsp+0x70], xmm7
00007c47757d137f  vmovaps [rsp+0x80], xmm8
00007c47757d1388  vmovaps [rsp+0x90], xmm9
00007c47757d1391  vmovaps [rsp+0xA0], xmm10
00007c47757d139a  vmovaps [rsp+0xB0], xmm11
00007c47757d13a3  vmovaps [rsp+0xC0], xmm12
00007c47757d13ac  vmovaps [rsp+0xD0], xmm14
00007c47757d13b5  vmovaps [rsp+0xE0], xmm15
00007c47757d13be  sub rsp, 0x30
00007c47757d13c2  movaps [rsp], xmm13
00007c47757d13c7  movaps [rsp+0x10], xmm2
00007c47757d13cc  movaps [rsp+0x20], xmm1
00007c47757d13d1  lea rdi, [rsp]
00007c47757d13d5  mov esi, 0x00
00007c47757d13da  mov rax, 0x62084E409530
00007c47757d13e4  call rax
00007c47757d13e6  movaps xmm13, [rsp]
00007c47757d13eb  add rsp, 0x30
00007c47757d13ef  vmovaps xmm0, [rsp]
00007c47757d13f4  vmovaps xmm1, [rsp+0x10]
00007c47757d13fa  vmovaps xmm2, [rsp+0x20]
00007c47757d1400  vmovaps xmm3, [rsp+0x30]
00007c47757d1406  vmovaps xmm4, [rsp+0x40]
00007c47757d140c  vmovaps xmm5, [rsp+0x50]
00007c47757d1412  vmovaps xmm6, [rsp+0x60]
00007c47757d1418  vmovaps xmm7, [rsp+0x70]
00007c47757d141e  vmovaps xmm8, [rsp+0x80]
00007c47757d1427  vmovaps xmm9, [rsp+0x90]
00007c47757d1430  vmovaps xmm10, [rsp+0xA0]
00007c47757d1439  vmovaps xmm11, [rsp+0xB0]
00007c47757d1442  vmovaps xmm12, [rsp+0xC0]
00007c47757d144b  vmovaps xmm14, [rsp+0xD0]
00007c47757d1454  vmovaps xmm15, [rsp+0xE0]
00007c47757d145d  add rsp, 0xF0
00007c47757d1464  pop r11
00007c47757d1466  pop r10
00007c47757d1468  pop r9
00007c47757d146a  pop r8
00007c47757d146c  pop rsi
00007c47757d146d  pop rdi
00007c47757d146e  pop rdx
00007c47757d146f  pop rcx
00007c47757d1470  pop rax
00007c47757d1471  add rsp, 0x08
00007c47757d1475  jmp 0x00007C47757CF878
00007c47757d147a  sub rsp, 0x08
00007c47757d147e  push rax
00007c47757d147f  push rcx
00007c47757d1480  push rdx
00007c47757d1481  push rdi
00007c47757d1482  push rsi
00007c47757d1483  push r8
00007c47757d1485  push r9
00007c47757d1487  push r10
00007c47757d1489  push r11
00007c47757d148b  sub rsp, 0xF0
00007c47757d1492  vmovaps [rsp], xmm0
00007c47757d1497  vmovaps [rsp+0x10], xmm2
00007c47757d149d  vmovaps [rsp+0x20], xmm3
00007c47757d14a3  vmovaps [rsp+0x30], xmm4
00007c47757d14a9  vmovaps [rsp+0x40], xmm5
00007c47757d14af  vmovaps [rsp+0x50], xmm6
00007c47757d14b5  vmovaps [rsp+0x60], xmm7
00007c47757d14bb  vmovaps [rsp+0x70], xmm8
00007c47757d14c1  vmovaps [rsp+0x80], xmm9
00007c47757d14ca  vmovaps [rsp+0x90], xmm10
00007c47757d14d3  vmovaps [rsp+0xA0], xmm11
00007c47757d14dc  vmovaps [rsp+0xB0], xmm12
00007c47757d14e5  vmovaps [rsp+0xC0], xmm13
00007c47757d14ee  vmovaps [rsp+0xD0], xmm14
00007c47757d14f7  vmovaps [rsp+0xE0], xmm15
00007c47757d1500  sub rsp, 0x30
00007c47757d1504  movaps [rsp], xmm1
00007c47757d1508  movaps [rsp+0x10], xmm15
00007c47757d150e  movaps [rsp+0x20], xmm2
00007c47757d1513  lea rdi, [rsp]
00007c47757d1517  mov esi, 0x00
00007c47757d151c  mov rax, 0x62084E409530
00007c47757d1526  call rax
00007c47757d1528  movaps xmm1, [rsp]
00007c47757d152c  add rsp, 0x30
00007c47757d1530  vmovaps xmm0, [rsp]
00007c47757d1535  vmovaps xmm2, [rsp+0x10]
00007c47757d153b  vmovaps xmm3, [rsp+0x20]
00007c47757d1541  vmovaps xmm4, [rsp+0x30]
00007c47757d1547  vmovaps xmm5, [rsp+0x40]
00007c47757d154d  vmovaps xmm6, [rsp+0x50]
00007c47757d1553  vmovaps xmm7, [rsp+0x60]
00007c47757d1559  vmovaps xmm8, [rsp+0x70]
00007c47757d155f  vmovaps xmm9, [rsp+0x80]
00007c47757d1568  vmovaps xmm10, [rsp+0x90]
00007c47757d1571  vmovaps xmm11, [rsp+0xA0]
00007c47757d157a  vmovaps xmm12, [rsp+0xB0]
00007c47757d1583  vmovaps xmm13, [rsp+0xC0]
00007c47757d158c  vmovaps xmm14, [rsp+0xD0]
00007c47757d1595  vmovaps xmm15, [rsp+0xE0]
00007c47757d159e  add rsp, 0xF0
00007c47757d15a5  pop r11
00007c47757d15a7  pop r10
00007c47757d15a9  pop r9
00007c47757d15ab  pop r8
00007c47757d15ad  pop rsi
00007c47757d15ae  pop rdi
00007c47757d15af  pop rdx
00007c47757d15b0  pop rcx
00007c47757d15b1  pop rax
00007c47757d15b2  add rsp, 0x08
00007c47757d15b6  jmp 0x00007C47757CF8AC
00007c47757d15bb  sub rsp, 0x08
00007c47757d15bf  push rax
00007c47757d15c0  push rcx
00007c47757d15c1  push rdx
00007c47757d15c2  push rdi
00007c47757d15c3  push rsi
00007c47757d15c4  push r8
00007c47757d15c6  push r9
00007c47757d15c8  push r10
00007c47757d15ca  push r11
00007c47757d15cc  sub rsp, 0xF0
00007c47757d15d3  vmovaps [rsp], xmm0
00007c47757d15d8  vmovaps [rsp+0x10], xmm1
00007c47757d15de  vmovaps [rsp+0x20], xmm2
00007c47757d15e4  vmovaps [rsp+0x30], xmm3
00007c47757d15ea  vmovaps [rsp+0x40], xmm4
00007c47757d15f0  vmovaps [rsp+0x50], xmm5
00007c47757d15f6  vmovaps [rsp+0x60], xmm6
00007c47757d15fc  vmovaps [rsp+0x70], xmm7
00007c47757d1602  vmovaps [rsp+0x80], xmm8
00007c47757d160b  vmovaps [rsp+0x90], xmm9
00007c47757d1614  vmovaps [rsp+0xA0], xmm10
00007c47757d161d  vmovaps [rsp+0xB0], xmm11
00007c47757d1626  vmovaps [rsp+0xC0], xmm12
00007c47757d162f  vmovaps [rsp+0xD0], xmm13
00007c47757d1638  vmovaps [rsp+0xE0], xmm15
00007c47757d1641  sub rsp, 0x30
00007c47757d1645  movaps [rsp], xmm14
00007c47757d164a  movaps [rsp+0x10], xmm2
00007c47757d164f  movaps [rsp+0x20], xmm15
00007c47757d1655  lea rdi, [rsp]
00007c47757d1659  mov esi, 0x00
00007c47757d165e  mov rax, 0x62084E409530
00007c47757d1668  call rax
00007c47757d166a  movaps xmm14, [rsp]
00007c47757d166f  add rsp, 0x30
00007c47757d1673  vmovaps xmm0, [rsp]
00007c47757d1678  vmovaps xmm1, [rsp+0x10]
00007c47757d167e  vmovaps xmm2, [rsp+0x20]
00007c47757d1684  vmovaps xmm3, [rsp+0x30]
00007c47757d168a  vmovaps xmm4, [rsp+0x40]
00007c47757d1690  vmovaps xmm5, [rsp+0x50]
00007c47757d1696  vmovaps xmm6, [rsp+0x60]
00007c47757d169c  vmovaps xmm7, [rsp+0x70]
00007c47757d16a2  vmovaps xmm8, [rsp+0x80]
00007c47757d16ab  vmovaps xmm9, [rsp+0x90]
00007c47757d16b4  vmovaps xmm10, [rsp+0xA0]
00007c47757d16bd  vmovaps xmm11, [rsp+0xB0]
00007c47757d16c6  vmovaps xmm12, [rsp+0xC0]
00007c47757d16cf  vmovaps xmm13, [rsp+0xD0]
00007c47757d16d8  vmovaps xmm15, [rsp+0xE0]
00007c47757d16e1  add rsp, 0xF0
00007c47757d16e8  pop r11
00007c47757d16ea  pop r10
00007c47757d16ec  pop r9
00007c47757d16ee  pop r8
00007c47757d16f0  pop rsi
00007c47757d16f1  pop rdi
00007c47757d16f2  pop rdx
00007c47757d16f3  pop rcx
00007c47757d16f4  pop rax
00007c47757d16f5  add rsp, 0x08
00007c47757d16f9  jmp 0x00007C47757CF8E7
00007c47757d16fe  sub rsp, 0x08
00007c47757d1702  push rax
00007c47757d1703  push rcx
00007c47757d1704  push rdx
00007c47757d1705  push rdi
00007c47757d1706  push rsi
00007c47757d1707  push r8
00007c47757d1709  push r9
00007c47757d170b  push r10
00007c47757d170d  push r11
00007c47757d170f  sub rsp, 0xF0
00007c47757d1716  vmovaps [rsp], xmm0
00007c47757d171b  vmovaps [rsp+0x10], xmm1
00007c47757d1721  vmovaps [rsp+0x20], xmm2
00007c47757d1727  vmovaps [rsp+0x30], xmm3
00007c47757d172d  vmovaps [rsp+0x40], xmm4
00007c47757d1733  vmovaps [rsp+0x50], xmm5
00007c47757d1739  vmovaps [rsp+0x60], xmm6
00007c47757d173f  vmovaps [rsp+0x70], xmm7
00007c47757d1745  vmovaps [rsp+0x80], xmm8
00007c47757d174e  vmovaps [rsp+0x90], xmm9
00007c47757d1757  vmovaps [rsp+0xA0], xmm10
00007c47757d1760  vmovaps [rsp+0xB0], xmm11
00007c47757d1769  vmovaps [rsp+0xC0], xmm12
00007c47757d1772  vmovaps [rsp+0xD0], xmm13
00007c47757d177b  vmovaps [rsp+0xE0], xmm14
00007c47757d1784  sub rsp, 0x30
00007c47757d1788  movaps [rsp], xmm15
00007c47757d178d  movaps [rsp+0x10], xmm2
00007c47757d1792  movaps [rsp+0x20], xmm1
00007c47757d1797  lea rdi, [rsp]
00007c47757d179b  mov esi, 0x00
00007c47757d17a0  mov rax, 0x62084E409530
00007c47757d17aa  call rax
00007c47757d17ac  movaps xmm15, [rsp]
00007c47757d17b1  add rsp, 0x30
00007c47757d17b5  vmovaps xmm0, [rsp]
00007c47757d17ba  vmovaps xmm1, [rsp+0x10]
00007c47757d17c0  vmovaps xmm2, [rsp+0x20]
00007c47757d17c6  vmovaps xmm3, [rsp+0x30]
00007c47757d17cc  vmovaps xmm4, [rsp+0x40]
00007c47757d17d2  vmovaps xmm5, [rsp+0x50]
00007c47757d17d8  vmovaps xmm6, [rsp+0x60]
00007c47757d17de  vmovaps xmm7, [rsp+0x70]
00007c47757d17e4  vmovaps xmm8, [rsp+0x80]
00007c47757d17ed  vmovaps xmm9, [rsp+0x90]
00007c47757d17f6  vmovaps xmm10, [rsp+0xA0]
00007c47757d17ff  vmovaps xmm11, [rsp+0xB0]
00007c47757d1808  vmovaps xmm12, [rsp+0xC0]
00007c47757d1811  vmovaps xmm13, [rsp+0xD0]
00007c47757d181a  vmovaps xmm14, [rsp+0xE0]
00007c47757d1823  add rsp, 0xF0
00007c47757d182a  pop r11
00007c47757d182c  pop r10
00007c47757d182e  pop r9
00007c47757d1830  pop r8
00007c47757d1832  pop rsi
00007c47757d1833  pop rdi
00007c47757d1834  pop rdx
00007c47757d1835  pop rcx
00007c47757d1836  pop rax
00007c47757d1837  add rsp, 0x08
00007c47757d183b  jmp 0x00007C47757CF923
00007c47757d1840  call 0x00007C47755FF430
00007c47757d1845  jmp 0x00007C47757CF930
00007c47757d184a  sub rsp, 0x08
00007c47757d184e  push rax
00007c47757d184f  push rcx
00007c47757d1850  push rdx
00007c47757d1851  push rdi
00007c47757d1852  push rsi
00007c47757d1853  push r8
00007c47757d1855  push r9
00007c47757d1857  push r10
00007c47757d1859  push r11
00007c47757d185b  sub rsp, 0xF0
00007c47757d1862  vmovaps [rsp], xmm0
00007c47757d1867  vmovaps [rsp+0x10], xmm1
00007c47757d186d  vmovaps [rsp+0x20], xmm3
00007c47757d1873  vmovaps [rsp+0x30], xmm4
00007c47757d1879  vmovaps [rsp+0x40], xmm5
00007c47757d187f  vmovaps [rsp+0x50], xmm6
00007c47757d1885  vmovaps [rsp+0x60], xmm7
00007c47757d188b  vmovaps [rsp+0x70], xmm8
00007c47757d1891  vmovaps [rsp+0x80], xmm9
00007c47757d189a  vmovaps [rsp+0x90], xmm10
00007c47757d18a3  vmovaps [rsp+0xA0], xmm11
00007c47757d18ac  vmovaps [rsp+0xB0], xmm12
00007c47757d18b5  vmovaps [rsp+0xC0], xmm13
00007c47757d18be  vmovaps [rsp+0xD0], xmm14
00007c47757d18c7  vmovaps [rsp+0xE0], xmm15
00007c47757d18d0  sub rsp, 0x30
00007c47757d18d4  movaps [rsp], xmm2
00007c47757d18d8  movaps [rsp+0x10], xmm1
00007c47757d18dd  movaps [rsp+0x20], xmm14
00007c47757d18e3  lea rdi, [rsp]
00007c47757d18e7  mov esi, 0x00
00007c47757d18ec  mov rax, 0x62084E409530
00007c47757d18f6  call rax
00007c47757d18f8  movaps xmm2, [rsp]
00007c47757d18fc  add rsp, 0x30
00007c47757d1900  vmovaps xmm0, [rsp]
00007c47757d1905  vmovaps xmm1, [rsp+0x10]
00007c47757d190b  vmovaps xmm3, [rsp+0x20]
00007c47757d1911  vmovaps xmm4, [rsp+0x30]
00007c47757d1917  vmovaps xmm5, [rsp+0x40]
00007c47757d191d  vmovaps xmm6, [rsp+0x50]
00007c47757d1923  vmovaps xmm7, [rsp+0x60]
00007c47757d1929  vmovaps xmm8, [rsp+0x70]
00007c47757d192f  vmovaps xmm9, [rsp+0x80]
00007c47757d1938  vmovaps xmm10, [rsp+0x90]
00007c47757d1941  vmovaps xmm11, [rsp+0xA0]
00007c47757d194a  vmovaps xmm12, [rsp+0xB0]
00007c47757d1953  vmovaps xmm13, [rsp+0xC0]
00007c47757d195c  vmovaps xmm14, [rsp+0xD0]
00007c47757d1965  vmovaps xmm15, [rsp+0xE0]
00007c47757d196e  add rsp, 0xF0
00007c47757d1975  pop r11
00007c47757d1977  pop r10
00007c47757d1979  pop r9
00007c47757d197b  pop r8
00007c47757d197d  pop rsi
00007c47757d197e  pop rdi
00007c47757d197f  pop rdx
00007c47757d1980  pop rcx
00007c47757d1981  pop rax
00007c47757d1982  add rsp, 0x08
00007c47757d1986  jmp 0x00007C47757CF96D
00007c47757d198b  sub rsp, 0x08
00007c47757d198f  push rax
00007c47757d1990  push rcx
00007c47757d1991  push rdx
00007c47757d1992  push rdi
00007c47757d1993  push rsi
00007c47757d1994  push r8
00007c47757d1996  push r9
00007c47757d1998  push r10
00007c47757d199a  push r11
00007c47757d199c  sub rsp, 0xF0
00007c47757d19a3  vmovaps [rsp], xmm0
00007c47757d19a8  vmovaps [rsp+0x10], xmm1
00007c47757d19ae  vmovaps [rsp+0x20], xmm2
00007c47757d19b4  vmovaps [rsp+0x30], xmm3
00007c47757d19ba  vmovaps [rsp+0x40], xmm4
00007c47757d19c0  vmovaps [rsp+0x50], xmm5
00007c47757d19c6  vmovaps [rsp+0x60], xmm6
00007c47757d19cc  vmovaps [rsp+0x70], xmm7
00007c47757d19d2  vmovaps [rsp+0x80], xmm8
00007c47757d19db  vmovaps [rsp+0x90], xmm9
00007c47757d19e4  vmovaps [rsp+0xA0], xmm10
00007c47757d19ed  vmovaps [rsp+0xB0], xmm11
00007c47757d19f6  vmovaps [rsp+0xC0], xmm12
00007c47757d19ff  vmovaps [rsp+0xD0], xmm13
00007c47757d1a08  vmovaps [rsp+0xE0], xmm14
00007c47757d1a11  sub rsp, 0x30
00007c47757d1a15  movaps [rsp], xmm15
00007c47757d1a1a  movaps [rsp+0x10], xmm14
00007c47757d1a20  movaps [rsp+0x20], xmm1
00007c47757d1a25  lea rdi, [rsp]
00007c47757d1a29  mov esi, 0x00
00007c47757d1a2e  mov rax, 0x62084E409530
00007c47757d1a38  call rax
00007c47757d1a3a  movaps xmm15, [rsp]
00007c47757d1a3f  add rsp, 0x30
00007c47757d1a43  vmovaps xmm0, [rsp]
00007c47757d1a48  vmovaps xmm1, [rsp+0x10]
00007c47757d1a4e  vmovaps xmm2, [rsp+0x20]
00007c47757d1a54  vmovaps xmm3, [rsp+0x30]
00007c47757d1a5a  vmovaps xmm4, [rsp+0x40]
00007c47757d1a60  vmovaps xmm5, [rsp+0x50]
00007c47757d1a66  vmovaps xmm6, [rsp+0x60]
00007c47757d1a6c  vmovaps xmm7, [rsp+0x70]
00007c47757d1a72  vmovaps xmm8, [rsp+0x80]
00007c47757d1a7b  vmovaps xmm9, [rsp+0x90]
00007c47757d1a84  vmovaps xmm10, [rsp+0xA0]
00007c47757d1a8d  vmovaps xmm11, [rsp+0xB0]
00007c47757d1a96  vmovaps xmm12, [rsp+0xC0]
00007c47757d1a9f  vmovaps xmm13, [rsp+0xD0]
00007c47757d1aa8  vmovaps xmm14, [rsp+0xE0]
00007c47757d1ab1  add rsp, 0xF0
00007c47757d1ab8  pop r11
00007c47757d1aba  pop r10
00007c47757d1abc  pop r9
00007c47757d1abe  pop r8
00007c47757d1ac0  pop rsi
00007c47757d1ac1  pop rdi
00007c47757d1ac2  pop rdx
00007c47757d1ac3  pop rcx
00007c47757d1ac4  pop rax
00007c47757d1ac5  add rsp, 0x08
00007c47757d1ac9  jmp 0x00007C47757CF9E7
00007c47757d1ace  call 0x00007C47755FF430
00007c47757d1ad3  jmp 0x00007C47757CF9F4
00007c47757d1ad8  sub rsp, 0x08
00007c47757d1adc  push rax
00007c47757d1add  push rcx
00007c47757d1ade  push rdx
00007c47757d1adf  push rdi
00007c47757d1ae0  push rsi
00007c47757d1ae1  push r8
00007c47757d1ae3  push r9
00007c47757d1ae5  push r10
00007c47757d1ae7  push r11
00007c47757d1ae9  sub rsp, 0xF0
00007c47757d1af0  vmovaps [rsp], xmm0
00007c47757d1af5  vmovaps [rsp+0x10], xmm1
00007c47757d1afb  vmovaps [rsp+0x20], xmm2
00007c47757d1b01  vmovaps [rsp+0x30], xmm3
00007c47757d1b07  vmovaps [rsp+0x40], xmm4
00007c47757d1b0d  vmovaps [rsp+0x50], xmm5
00007c47757d1b13  vmovaps [rsp+0x60], xmm6
00007c47757d1b19  vmovaps [rsp+0x70], xmm7
00007c47757d1b1f  vmovaps [rsp+0x80], xmm8
00007c47757d1b28  vmovaps [rsp+0x90], xmm9
00007c47757d1b31  vmovaps [rsp+0xA0], xmm10
00007c47757d1b3a  vmovaps [rsp+0xB0], xmm11
00007c47757d1b43  vmovaps [rsp+0xC0], xmm12
00007c47757d1b4c  vmovaps [rsp+0xD0], xmm13
00007c47757d1b55  vmovaps [rsp+0xE0], xmm15
00007c47757d1b5e  sub rsp, 0x30
00007c47757d1b62  movaps [rsp], xmm14
00007c47757d1b67  movaps [rsp+0x10], xmm13
00007c47757d1b6d  movaps [rsp+0x20], xmm1
00007c47757d1b72  lea rdi, [rsp]
00007c47757d1b76  mov esi, 0x00
00007c47757d1b7b  mov rax, 0x62084E409530
00007c47757d1b85  call rax
00007c47757d1b87  movaps xmm14, [rsp]
00007c47757d1b8c  add rsp, 0x30
00007c47757d1b90  vmovaps xmm0, [rsp]
00007c47757d1b95  vmovaps xmm1, [rsp+0x10]
00007c47757d1b9b  vmovaps xmm2, [rsp+0x20]
00007c47757d1ba1  vmovaps xmm3, [rsp+0x30]
00007c47757d1ba7  vmovaps xmm4, [rsp+0x40]
00007c47757d1bad  vmovaps xmm5, [rsp+0x50]
00007c47757d1bb3  vmovaps xmm6, [rsp+0x60]
00007c47757d1bb9  vmovaps xmm7, [rsp+0x70]
00007c47757d1bbf  vmovaps xmm8, [rsp+0x80]
00007c47757d1bc8  vmovaps xmm9, [rsp+0x90]
00007c47757d1bd1  vmovaps xmm10, [rsp+0xA0]
00007c47757d1bda  vmovaps xmm11, [rsp+0xB0]
00007c47757d1be3  vmovaps xmm12, [rsp+0xC0]
00007c47757d1bec  vmovaps xmm13, [rsp+0xD0]
00007c47757d1bf5  vmovaps xmm15, [rsp+0xE0]
00007c47757d1bfe  add rsp, 0xF0
00007c47757d1c05  pop r11
00007c47757d1c07  pop r10
00007c47757d1c09  pop r9
00007c47757d1c0b  pop r8
00007c47757d1c0d  pop rsi
00007c47757d1c0e  pop rdi
00007c47757d1c0f  pop rdx
00007c47757d1c10  pop rcx
00007c47757d1c11  pop rax
00007c47757d1c12  add rsp, 0x08
00007c47757d1c16  jmp 0x00007C47757CFAAF
00007c47757d1c1b  sub rsp, 0x08
00007c47757d1c1f  push rax
00007c47757d1c20  push rcx
00007c47757d1c21  push rdx
00007c47757d1c22  push rdi
00007c47757d1c23  push rsi
00007c47757d1c24  push r8
00007c47757d1c26  push r9
00007c47757d1c28  push r10
00007c47757d1c2a  push r11
00007c47757d1c2c  sub rsp, 0xF0
00007c47757d1c33  vmovaps [rsp], xmm0
00007c47757d1c38  vmovaps [rsp+0x10], xmm1
00007c47757d1c3e  vmovaps [rsp+0x20], xmm2
00007c47757d1c44  vmovaps [rsp+0x30], xmm3
00007c47757d1c4a  vmovaps [rsp+0x40], xmm4
00007c47757d1c50  vmovaps [rsp+0x50], xmm5
00007c47757d1c56  vmovaps [rsp+0x60], xmm6
00007c47757d1c5c  vmovaps [rsp+0x70], xmm7
00007c47757d1c62  vmovaps [rsp+0x80], xmm8
00007c47757d1c6b  vmovaps [rsp+0x90], xmm9
00007c47757d1c74  vmovaps [rsp+0xA0], xmm10
00007c47757d1c7d  vmovaps [rsp+0xB0], xmm11
00007c47757d1c86  vmovaps [rsp+0xC0], xmm12
00007c47757d1c8f  vmovaps [rsp+0xD0], xmm13
00007c47757d1c98  vmovaps [rsp+0xE0], xmm14
00007c47757d1ca1  sub rsp, 0x30
00007c47757d1ca5  movaps [rsp], xmm15
00007c47757d1caa  movaps [rsp+0x10], xmm13
00007c47757d1cb0  movaps [rsp+0x20], xmm1
00007c47757d1cb5  lea rdi, [rsp]
00007c47757d1cb9  mov esi, 0x00
00007c47757d1cbe  mov rax, 0x62084E409530
00007c47757d1cc8  call rax
00007c47757d1cca  movaps xmm15, [rsp]
00007c47757d1ccf  add rsp, 0x30
00007c47757d1cd3  vmovaps xmm0, [rsp]
00007c47757d1cd8  vmovaps xmm1, [rsp+0x10]
00007c47757d1cde  vmovaps xmm2, [rsp+0x20]
00007c47757d1ce4  vmovaps xmm3, [rsp+0x30]
00007c47757d1cea  vmovaps xmm4, [rsp+0x40]
00007c47757d1cf0  vmovaps xmm5, [rsp+0x50]
00007c47757d1cf6  vmovaps xmm6, [rsp+0x60]
00007c47757d1cfc  vmovaps xmm7, [rsp+0x70]
00007c47757d1d02  vmovaps xmm8, [rsp+0x80]
00007c47757d1d0b  vmovaps xmm9, [rsp+0x90]
00007c47757d1d14  vmovaps xmm10, [rsp+0xA0]
00007c47757d1d1d  vmovaps xmm11, [rsp+0xB0]
00007c47757d1d26  vmovaps xmm12, [rsp+0xC0]
00007c47757d1d2f  vmovaps xmm13, [rsp+0xD0]
00007c47757d1d38  vmovaps xmm14, [rsp+0xE0]
00007c47757d1d41  add rsp, 0xF0
00007c47757d1d48  pop r11
00007c47757d1d4a  pop r10
00007c47757d1d4c  pop r9
00007c47757d1d4e  pop r8
00007c47757d1d50  pop rsi
00007c47757d1d51  pop rdi
00007c47757d1d52  pop rdx
00007c47757d1d53  pop rcx
00007c47757d1d54  pop rax
00007c47757d1d55  add rsp, 0x08
00007c47757d1d59  jmp 0x00007C47757CFAEB
00007c47757d1d5e  call 0x00007C47755FF430
00007c47757d1d63  jmp 0x00007C47757CFAF8
00007c47757d1d68  sub rsp, 0x08
00007c47757d1d6c  push rax
00007c47757d1d6d  push rcx
00007c47757d1d6e  push rdx
00007c47757d1d6f  push rdi
00007c47757d1d70  push rsi
00007c47757d1d71  push r8
00007c47757d1d73  push r9
00007c47757d1d75  push r10
00007c47757d1d77  push r11
00007c47757d1d79  sub rsp, 0xF0
00007c47757d1d80  vmovaps [rsp], xmm0
00007c47757d1d85  vmovaps [rsp+0x10], xmm1
00007c47757d1d8b  vmovaps [rsp+0x20], xmm2
00007c47757d1d91  vmovaps [rsp+0x30], xmm3
00007c47757d1d97  vmovaps [rsp+0x40], xmm4
00007c47757d1d9d  vmovaps [rsp+0x50], xmm5
00007c47757d1da3  vmovaps [rsp+0x60], xmm6
00007c47757d1da9  vmovaps [rsp+0x70], xmm7
00007c47757d1daf  vmovaps [rsp+0x80], xmm8
00007c47757d1db8  vmovaps [rsp+0x90], xmm9
00007c47757d1dc1  vmovaps [rsp+0xA0], xmm10
00007c47757d1dca  vmovaps [rsp+0xB0], xmm11
00007c47757d1dd3  vmovaps [rsp+0xC0], xmm12
00007c47757d1ddc  vmovaps [rsp+0xD0], xmm13
00007c47757d1de5  vmovaps [rsp+0xE0], xmm15
00007c47757d1dee  sub rsp, 0x30
00007c47757d1df2  movaps [rsp], xmm14
00007c47757d1df7  movaps [rsp+0x10], xmm13
00007c47757d1dfd  movaps [rsp+0x20], xmm2
00007c47757d1e02  lea rdi, [rsp]
00007c47757d1e06  mov esi, 0x00
00007c47757d1e0b  mov rax, 0x62084E409530
00007c47757d1e15  call rax
00007c47757d1e17  movaps xmm14, [rsp]
00007c47757d1e1c  add rsp, 0x30
00007c47757d1e20  vmovaps xmm0, [rsp]
00007c47757d1e25  vmovaps xmm1, [rsp+0x10]
00007c47757d1e2b  vmovaps xmm2, [rsp+0x20]
00007c47757d1e31  vmovaps xmm3, [rsp+0x30]
00007c47757d1e37  vmovaps xmm4, [rsp+0x40]
00007c47757d1e3d  vmovaps xmm5, [rsp+0x50]
00007c47757d1e43  vmovaps xmm6, [rsp+0x60]
00007c47757d1e49  vmovaps xmm7, [rsp+0x70]
00007c47757d1e4f  vmovaps xmm8, [rsp+0x80]
00007c47757d1e58  vmovaps xmm9, [rsp+0x90]
00007c47757d1e61  vmovaps xmm10, [rsp+0xA0]
00007c47757d1e6a  vmovaps xmm11, [rsp+0xB0]
00007c47757d1e73  vmovaps xmm12, [rsp+0xC0]
00007c47757d1e7c  vmovaps xmm13, [rsp+0xD0]
00007c47757d1e85  vmovaps xmm15, [rsp+0xE0]
00007c47757d1e8e  add rsp, 0xF0
00007c47757d1e95  pop r11
00007c47757d1e97  pop r10
00007c47757d1e99  pop r9
00007c47757d1e9b  pop r8
00007c47757d1e9d  pop rsi
00007c47757d1e9e  pop rdi
00007c47757d1e9f  pop rdx
00007c47757d1ea0  pop rcx
00007c47757d1ea1  pop rax
00007c47757d1ea2  add rsp, 0x08
00007c47757d1ea6  jmp 0x00007C47757CFB24
00007c47757d1eab  sub rsp, 0x08
00007c47757d1eaf  push rax
00007c47757d1eb0  push rcx
00007c47757d1eb1  push rdx
00007c47757d1eb2  push rdi
00007c47757d1eb3  push rsi
00007c47757d1eb4  push r8
00007c47757d1eb6  push r9
00007c47757d1eb8  push r10
00007c47757d1eba  push r11
00007c47757d1ebc  sub rsp, 0xF0
00007c47757d1ec3  vmovaps [rsp], xmm0
00007c47757d1ec8  vmovaps [rsp+0x10], xmm2
00007c47757d1ece  vmovaps [rsp+0x20], xmm3
00007c47757d1ed4  vmovaps [rsp+0x30], xmm4
00007c47757d1eda  vmovaps [rsp+0x40], xmm5
00007c47757d1ee0  vmovaps [rsp+0x50], xmm6
00007c47757d1ee6  vmovaps [rsp+0x60], xmm7
00007c47757d1eec  vmovaps [rsp+0x70], xmm8
00007c47757d1ef2  vmovaps [rsp+0x80], xmm9
00007c47757d1efb  vmovaps [rsp+0x90], xmm10
00007c47757d1f04  vmovaps [rsp+0xA0], xmm11
00007c47757d1f0d  vmovaps [rsp+0xB0], xmm12
00007c47757d1f16  vmovaps [rsp+0xC0], xmm13
00007c47757d1f1f  vmovaps [rsp+0xD0], xmm14
00007c47757d1f28  vmovaps [rsp+0xE0], xmm15
00007c47757d1f31  sub rsp, 0x30
00007c47757d1f35  movaps [rsp], xmm1
00007c47757d1f39  movaps [rsp+0x10], xmm13
00007c47757d1f3f  movaps [rsp+0x20], xmm2
00007c47757d1f44  lea rdi, [rsp]
00007c47757d1f48  mov esi, 0x00
00007c47757d1f4d  mov rax, 0x62084E409530
00007c47757d1f57  call rax
00007c47757d1f59  movaps xmm1, [rsp]
00007c47757d1f5d  add rsp, 0x30
00007c47757d1f61  vmovaps xmm0, [rsp]
00007c47757d1f66  vmovaps xmm2, [rsp+0x10]
00007c47757d1f6c  vmovaps xmm3, [rsp+0x20]
00007c47757d1f72  vmovaps xmm4, [rsp+0x30]
00007c47757d1f78  vmovaps xmm5, [rsp+0x40]
00007c47757d1f7e  vmovaps xmm6, [rsp+0x50]
00007c47757d1f84  vmovaps xmm7, [rsp+0x60]
00007c47757d1f8a  vmovaps xmm8, [rsp+0x70]
00007c47757d1f90  vmovaps xmm9, [rsp+0x80]
00007c47757d1f99  vmovaps xmm10, [rsp+0x90]
00007c47757d1fa2  vmovaps xmm11, [rsp+0xA0]
00007c47757d1fab  vmovaps xmm12, [rsp+0xB0]
00007c47757d1fb4  vmovaps xmm13, [rsp+0xC0]
00007c47757d1fbd  vmovaps xmm14, [rsp+0xD0]
00007c47757d1fc6  vmovaps xmm15, [rsp+0xE0]
00007c47757d1fcf  add rsp, 0xF0
00007c47757d1fd6  pop r11
00007c47757d1fd8  pop r10
00007c47757d1fda  pop r9
00007c47757d1fdc  pop r8
00007c47757d1fde  pop rsi
00007c47757d1fdf  pop rdi
00007c47757d1fe0  pop rdx
00007c47757d1fe1  pop rcx
00007c47757d1fe2  pop rax
00007c47757d1fe3  add rsp, 0x08
00007c47757d1fe7  jmp 0x00007C47757CFB52
00007c47757d1fec  sub rsp, 0x08
00007c47757d1ff0  push rax
00007c47757d1ff1  push rcx
00007c47757d1ff2  push rdx
00007c47757d1ff3  push rdi
00007c47757d1ff4  push rsi
00007c47757d1ff5  push r8
00007c47757d1ff7  push r9
00007c47757d1ff9  push r10
00007c47757d1ffb  push r11
00007c47757d1ffd  sub rsp, 0xF0
00007c47757d2004  vmovaps [rsp], xmm0
00007c47757d2009  vmovaps [rsp+0x10], xmm1
00007c47757d200f  vmovaps [rsp+0x20], xmm3
00007c47757d2015  vmovaps [rsp+0x30], xmm4
00007c47757d201b  vmovaps [rsp+0x40], xmm5
00007c47757d2021  vmovaps [rsp+0x50], xmm6
00007c47757d2027  vmovaps [rsp+0x60], xmm7
00007c47757d202d  vmovaps [rsp+0x70], xmm8
00007c47757d2033  vmovaps [rsp+0x80], xmm9
00007c47757d203c  vmovaps [rsp+0x90], xmm10
00007c47757d2045  vmovaps [rsp+0xA0], xmm11
00007c47757d204e  vmovaps [rsp+0xB0], xmm12
00007c47757d2057  vmovaps [rsp+0xC0], xmm13
00007c47757d2060  vmovaps [rsp+0xD0], xmm14
00007c47757d2069  vmovaps [rsp+0xE0], xmm15
00007c47757d2072  sub rsp, 0x30
00007c47757d2076  movaps [rsp], xmm2
00007c47757d207a  movaps [rsp+0x10], xmm1
00007c47757d207f  movaps [rsp+0x20], xmm13
00007c47757d2085  lea rdi, [rsp]
00007c47757d2089  mov esi, 0x00
00007c47757d208e  mov rax, 0x62084E409530
00007c47757d2098  call rax
00007c47757d209a  movaps xmm2, [rsp]
00007c47757d209e  add rsp, 0x30
00007c47757d20a2  vmovaps xmm0, [rsp]
00007c47757d20a7  vmovaps xmm1, [rsp+0x10]
00007c47757d20ad  vmovaps xmm3, [rsp+0x20]
00007c47757d20b3  vmovaps xmm4, [rsp+0x30]
00007c47757d20b9  vmovaps xmm5, [rsp+0x40]
00007c47757d20bf  vmovaps xmm6, [rsp+0x50]
00007c47757d20c5  vmovaps xmm7, [rsp+0x60]
00007c47757d20cb  vmovaps xmm8, [rsp+0x70]
00007c47757d20d1  vmovaps xmm9, [rsp+0x80]
00007c47757d20da  vmovaps xmm10, [rsp+0x90]
00007c47757d20e3  vmovaps xmm11, [rsp+0xA0]
00007c47757d20ec  vmovaps xmm12, [rsp+0xB0]
00007c47757d20f5  vmovaps xmm13, [rsp+0xC0]
00007c47757d20fe  vmovaps xmm14, [rsp+0xD0]
00007c47757d2107  vmovaps xmm15, [rsp+0xE0]
00007c47757d2110  add rsp, 0xF0
00007c47757d2117  pop r11
00007c47757d2119  pop r10
00007c47757d211b  pop r9
00007c47757d211d  pop r8
00007c47757d211f  pop rsi
00007c47757d2120  pop rdi
00007c47757d2121  pop rdx
00007c47757d2122  pop rcx
00007c47757d2123  pop rax
00007c47757d2124  add rsp, 0x08
00007c47757d2128  jmp 0x00007C47757CFBAB
00007c47757d212d  call 0x00007C47755FF430
00007c47757d2132  jmp 0x00007C47757CFBB8
00007c47757d2137  sub rsp, 0x08
00007c47757d213b  push rax
00007c47757d213c  push rcx
00007c47757d213d  push rdx
00007c47757d213e  push rdi
00007c47757d213f  push rsi
00007c47757d2140  push r8
00007c47757d2142  push r9
00007c47757d2144  push r10
00007c47757d2146  push r11
00007c47757d2148  sub rsp, 0xF0
00007c47757d214f  vmovaps [rsp], xmm0
00007c47757d2154  vmovaps [rsp+0x10], xmm1
00007c47757d215a  vmovaps [rsp+0x20], xmm2
00007c47757d2160  vmovaps [rsp+0x30], xmm3
00007c47757d2166  vmovaps [rsp+0x40], xmm4
00007c47757d216c  vmovaps [rsp+0x50], xmm5
00007c47757d2172  vmovaps [rsp+0x60], xmm6
00007c47757d2178  vmovaps [rsp+0x70], xmm7
00007c47757d217e  vmovaps [rsp+0x80], xmm8
00007c47757d2187  vmovaps [rsp+0x90], xmm9
00007c47757d2190  vmovaps [rsp+0xA0], xmm10
00007c47757d2199  vmovaps [rsp+0xB0], xmm11
00007c47757d21a2  vmovaps [rsp+0xC0], xmm12
00007c47757d21ab  vmovaps [rsp+0xD0], xmm13
00007c47757d21b4  vmovaps [rsp+0xE0], xmm14
00007c47757d21bd  sub rsp, 0x30
00007c47757d21c1  movaps [rsp], xmm15
00007c47757d21c6  movaps [rsp+0x10], xmm13
00007c47757d21cc  movaps [rsp+0x20], xmm1
00007c47757d21d1  lea rdi, [rsp]
00007c47757d21d5  mov esi, 0x00
00007c47757d21da  mov rax, 0x62084E409530
00007c47757d21e4  call rax
00007c47757d21e6  movaps xmm15, [rsp]
00007c47757d21eb  add rsp, 0x30
00007c47757d21ef  vmovaps xmm0, [rsp]
00007c47757d21f4  vmovaps xmm1, [rsp+0x10]
00007c47757d21fa  vmovaps xmm2, [rsp+0x20]
00007c47757d2200  vmovaps xmm3, [rsp+0x30]
00007c47757d2206  vmovaps xmm4, [rsp+0x40]
00007c47757d220c  vmovaps xmm5, [rsp+0x50]
00007c47757d2212  vmovaps xmm6, [rsp+0x60]
00007c47757d2218  vmovaps xmm7, [rsp+0x70]
00007c47757d221e  vmovaps xmm8, [rsp+0x80]
00007c47757d2227  vmovaps xmm9, [rsp+0x90]
00007c47757d2230  vmovaps xmm10, [rsp+0xA0]
00007c47757d2239  vmovaps xmm11, [rsp+0xB0]
00007c47757d2242  vmovaps xmm12, [rsp+0xC0]
00007c47757d224b  vmovaps xmm13, [rsp+0xD0]
00007c47757d2254  vmovaps xmm14, [rsp+0xE0]
00007c47757d225d  add rsp, 0xF0
00007c47757d2264  pop r11
00007c47757d2266  pop r10
00007c47757d2268  pop r9
00007c47757d226a  pop r8
00007c47757d226c  pop rsi
00007c47757d226d  pop rdi
00007c47757d226e  pop rdx
00007c47757d226f  pop rcx
00007c47757d2270  pop rax
00007c47757d2271  add rsp, 0x08
00007c47757d2275  jmp 0x00007C47757CFBF7
00007c47757d227a  sub rsp, 0x08
00007c47757d227e  push rax
00007c47757d227f  push rcx
00007c47757d2280  push rdx
00007c47757d2281  push rdi
00007c47757d2282  push rsi
00007c47757d2283  push r8
00007c47757d2285  push r9
00007c47757d2287  push r10
00007c47757d2289  push r11
00007c47757d228b  sub rsp, 0xF0
00007c47757d2292  vmovaps [rsp], xmm0
00007c47757d2297  vmovaps [rsp+0x10], xmm1
00007c47757d229d  vmovaps [rsp+0x20], xmm2
00007c47757d22a3  vmovaps [rsp+0x30], xmm3
00007c47757d22a9  vmovaps [rsp+0x40], xmm4
00007c47757d22af  vmovaps [rsp+0x50], xmm5
00007c47757d22b5  vmovaps [rsp+0x60], xmm6
00007c47757d22bb  vmovaps [rsp+0x70], xmm7
00007c47757d22c1  vmovaps [rsp+0x80], xmm8
00007c47757d22ca  vmovaps [rsp+0x90], xmm9
00007c47757d22d3  vmovaps [rsp+0xA0], xmm10
00007c47757d22dc  vmovaps [rsp+0xB0], xmm11
00007c47757d22e5  vmovaps [rsp+0xC0], xmm12
00007c47757d22ee  vmovaps [rsp+0xD0], xmm13
00007c47757d22f7  vmovaps [rsp+0xE0], xmm15
00007c47757d2300  sub rsp, 0x30
00007c47757d2304  movaps [rsp], xmm14
00007c47757d2309  movaps [rsp+0x10], xmm11
00007c47757d230f  movaps [rsp+0x20], xmm1
00007c47757d2314  lea rdi, [rsp]
00007c47757d2318  mov esi, 0x00
00007c47757d231d  mov rax, 0x62084E409530
00007c47757d2327  call rax
00007c47757d2329  movaps xmm14, [rsp]
00007c47757d232e  add rsp, 0x30
00007c47757d2332  vmovaps xmm0, [rsp]
00007c47757d2337  vmovaps xmm1, [rsp+0x10]
00007c47757d233d  vmovaps xmm2, [rsp+0x20]
00007c47757d2343  vmovaps xmm3, [rsp+0x30]
00007c47757d2349  vmovaps xmm4, [rsp+0x40]
00007c47757d234f  vmovaps xmm5, [rsp+0x50]
00007c47757d2355  vmovaps xmm6, [rsp+0x60]
00007c47757d235b  vmovaps xmm7, [rsp+0x70]
00007c47757d2361  vmovaps xmm8, [rsp+0x80]
00007c47757d236a  vmovaps xmm9, [rsp+0x90]
00007c47757d2373  vmovaps xmm10, [rsp+0xA0]
00007c47757d237c  vmovaps xmm11, [rsp+0xB0]
00007c47757d2385  vmovaps xmm12, [rsp+0xC0]
00007c47757d238e  vmovaps xmm13, [rsp+0xD0]
00007c47757d2397  vmovaps xmm15, [rsp+0xE0]
00007c47757d23a0  add rsp, 0xF0
00007c47757d23a7  pop r11
00007c47757d23a9  pop r10
00007c47757d23ab  pop r9
00007c47757d23ad  pop r8
00007c47757d23af  pop rsi
00007c47757d23b0  pop rdi
00007c47757d23b1  pop rdx
00007c47757d23b2  pop rcx
00007c47757d23b3  pop rax
00007c47757d23b4  add rsp, 0x08
00007c47757d23b8  jmp 0x00007C47757CFC21
00007c47757d23bd  sub rsp, 0x08
00007c47757d23c1  push rax
00007c47757d23c2  push rcx
00007c47757d23c3  push rdx
00007c47757d23c4  push rdi
00007c47757d23c5  push rsi
00007c47757d23c6  push r8
00007c47757d23c8  push r9
00007c47757d23ca  push r10
00007c47757d23cc  push r11
00007c47757d23ce  sub rsp, 0xF0
00007c47757d23d5  vmovaps [rsp], xmm0
00007c47757d23da  vmovaps [rsp+0x10], xmm1
00007c47757d23e0  vmovaps [rsp+0x20], xmm2
00007c47757d23e6  vmovaps [rsp+0x30], xmm3
00007c47757d23ec  vmovaps [rsp+0x40], xmm4
00007c47757d23f2  vmovaps [rsp+0x50], xmm5
00007c47757d23f8  vmovaps [rsp+0x60], xmm6
00007c47757d23fe  vmovaps [rsp+0x70], xmm7
00007c47757d2404  vmovaps [rsp+0x80], xmm8
00007c47757d240d  vmovaps [rsp+0x90], xmm9
00007c47757d2416  vmovaps [rsp+0xA0], xmm10
00007c47757d241f  vmovaps [rsp+0xB0], xmm11
00007c47757d2428  vmovaps [rsp+0xC0], xmm12
00007c47757d2431  vmovaps [rsp+0xD0], xmm14
00007c47757d243a  vmovaps [rsp+0xE0], xmm15
00007c47757d2443  sub rsp, 0x30
00007c47757d2447  movaps [rsp], xmm13
00007c47757d244c  movaps [rsp+0x10], xmm11
00007c47757d2452  movaps [rsp+0x20], xmm1
00007c47757d2457  lea rdi, [rsp]
00007c47757d245b  mov esi, 0x00
00007c47757d2460  mov rax, 0x62084E409530
00007c47757d246a  call rax
00007c47757d246c  movaps xmm13, [rsp]
00007c47757d2471  add rsp, 0x30
00007c47757d2475  vmovaps xmm0, [rsp]
00007c47757d247a  vmovaps xmm1, [rsp+0x10]
00007c47757d2480  vmovaps xmm2, [rsp+0x20]
00007c47757d2486  vmovaps xmm3, [rsp+0x30]
00007c47757d248c  vmovaps xmm4, [rsp+0x40]
00007c47757d2492  vmovaps xmm5, [rsp+0x50]
00007c47757d2498  vmovaps xmm6, [rsp+0x60]
00007c47757d249e  vmovaps xmm7, [rsp+0x70]
00007c47757d24a4  vmovaps xmm8, [rsp+0x80]
00007c47757d24ad  vmovaps xmm9, [rsp+0x90]
00007c47757d24b6  vmovaps xmm10, [rsp+0xA0]
00007c47757d24bf  vmovaps xmm11, [rsp+0xB0]
00007c47757d24c8  vmovaps xmm12, [rsp+0xC0]
00007c47757d24d1  vmovaps xmm14, [rsp+0xD0]
00007c47757d24da  vmovaps xmm15, [rsp+0xE0]
00007c47757d24e3  add rsp, 0xF0
00007c47757d24ea  pop r11
00007c47757d24ec  pop r10
00007c47757d24ee  pop r9
00007c47757d24f0  pop r8
00007c47757d24f2  pop rsi
00007c47757d24f3  pop rdi
00007c47757d24f4  pop rdx
00007c47757d24f5  pop rcx
00007c47757d24f6  pop rax
00007c47757d24f7  add rsp, 0x08
00007c47757d24fb  jmp 0x00007C47757CFC76
00007c47757d2500  call 0x00007C47755FF430
00007c47757d2505  jmp 0x00007C47757CFC83
00007c47757d250a  sub rsp, 0x08
00007c47757d250e  push rax
00007c47757d250f  push rcx
00007c47757d2510  push rdx
00007c47757d2511  push rdi
00007c47757d2512  push rsi
00007c47757d2513  push r8
00007c47757d2515  push r9
00007c47757d2517  push r10
00007c47757d2519  push r11
00007c47757d251b  sub rsp, 0xF0
00007c47757d2522  vmovaps [rsp], xmm0
00007c47757d2527  vmovaps [rsp+0x10], xmm1
00007c47757d252d  vmovaps [rsp+0x20], xmm2
00007c47757d2533  vmovaps [rsp+0x30], xmm3
00007c47757d2539  vmovaps [rsp+0x40], xmm4
00007c47757d253f  vmovaps [rsp+0x50], xmm5
00007c47757d2545  vmovaps [rsp+0x60], xmm6
00007c47757d254b  vmovaps [rsp+0x70], xmm7
00007c47757d2551  vmovaps [rsp+0x80], xmm8
00007c47757d255a  vmovaps [rsp+0x90], xmm9
00007c47757d2563  vmovaps [rsp+0xA0], xmm10
00007c47757d256c  vmovaps [rsp+0xB0], xmm11
00007c47757d2575  vmovaps [rsp+0xC0], xmm12
00007c47757d257e  vmovaps [rsp+0xD0], xmm13
00007c47757d2587  vmovaps [rsp+0xE0], xmm14
00007c47757d2590  sub rsp, 0x30
00007c47757d2594  movaps [rsp], xmm15
00007c47757d2599  movaps [rsp+0x10], xmm11
00007c47757d259f  movaps [rsp+0x20], xmm1
00007c47757d25a4  lea rdi, [rsp]
00007c47757d25a8  mov esi, 0x00
00007c47757d25ad  mov rax, 0x62084E409530
00007c47757d25b7  call rax
00007c47757d25b9  movaps xmm15, [rsp]
00007c47757d25be  add rsp, 0x30
00007c47757d25c2  vmovaps xmm0, [rsp]
00007c47757d25c7  vmovaps xmm1, [rsp+0x10]
00007c47757d25cd  vmovaps xmm2, [rsp+0x20]
00007c47757d25d3  vmovaps xmm3, [rsp+0x30]
00007c47757d25d9  vmovaps xmm4, [rsp+0x40]
00007c47757d25df  vmovaps xmm5, [rsp+0x50]
00007c47757d25e5  vmovaps xmm6, [rsp+0x60]
00007c47757d25eb  vmovaps xmm7, [rsp+0x70]
00007c47757d25f1  vmovaps xmm8, [rsp+0x80]
00007c47757d25fa  vmovaps xmm9, [rsp+0x90]
00007c47757d2603  vmovaps xmm10, [rsp+0xA0]
00007c47757d260c  vmovaps xmm11, [rsp+0xB0]
00007c47757d2615  vmovaps xmm12, [rsp+0xC0]
00007c47757d261e  vmovaps xmm13, [rsp+0xD0]
00007c47757d2627  vmovaps xmm14, [rsp+0xE0]
00007c47757d2630  add rsp, 0xF0
00007c47757d2637  pop r11
00007c47757d2639  pop r10
00007c47757d263b  pop r9
00007c47757d263d  pop r8
00007c47757d263f  pop rsi
00007c47757d2640  pop rdi
00007c47757d2641  pop rdx
00007c47757d2642  pop rcx
00007c47757d2643  pop rax
00007c47757d2644  add rsp, 0x08
00007c47757d2648  jmp 0x00007C47757CFCBC
00007c47757d264d  sub rsp, 0x08
00007c47757d2651  push rax
00007c47757d2652  push rcx
00007c47757d2653  push rdx
00007c47757d2654  push rdi
00007c47757d2655  push rsi
00007c47757d2656  push r8
00007c47757d2658  push r9
00007c47757d265a  push r10
00007c47757d265c  push r11
00007c47757d265e  sub rsp, 0xF0
00007c47757d2665  vmovaps [rsp], xmm0
00007c47757d266a  vmovaps [rsp+0x10], xmm1
00007c47757d2670  vmovaps [rsp+0x20], xmm2
00007c47757d2676  vmovaps [rsp+0x30], xmm3
00007c47757d267c  vmovaps [rsp+0x40], xmm4
00007c47757d2682  vmovaps [rsp+0x50], xmm5
00007c47757d2688  vmovaps [rsp+0x60], xmm6
00007c47757d268e  vmovaps [rsp+0x70], xmm7
00007c47757d2694  vmovaps [rsp+0x80], xmm8
00007c47757d269d  vmovaps [rsp+0x90], xmm9
00007c47757d26a6  vmovaps [rsp+0xA0], xmm10
00007c47757d26af  vmovaps [rsp+0xB0], xmm12
00007c47757d26b8  vmovaps [rsp+0xC0], xmm13
00007c47757d26c1  vmovaps [rsp+0xD0], xmm14
00007c47757d26ca  vmovaps [rsp+0xE0], xmm15
00007c47757d26d3  sub rsp, 0x30
00007c47757d26d7  movaps [rsp], xmm11
00007c47757d26dc  movaps [rsp+0x10], xmm6
00007c47757d26e1  movaps [rsp+0x20], xmm14
00007c47757d26e7  lea rdi, [rsp]
00007c47757d26eb  mov esi, 0x00
00007c47757d26f0  mov rax, 0x62084E409530
00007c47757d26fa  call rax
00007c47757d26fc  movaps xmm11, [rsp]
00007c47757d2701  add rsp, 0x30
00007c47757d2705  vmovaps xmm0, [rsp]
00007c47757d270a  vmovaps xmm1, [rsp+0x10]
00007c47757d2710  vmovaps xmm2, [rsp+0x20]
00007c47757d2716  vmovaps xmm3, [rsp+0x30]
00007c47757d271c  vmovaps xmm4, [rsp+0x40]
00007c47757d2722  vmovaps xmm5, [rsp+0x50]
00007c47757d2728  vmovaps xmm6, [rsp+0x60]
00007c47757d272e  vmovaps xmm7, [rsp+0x70]
00007c47757d2734  vmovaps xmm8, [rsp+0x80]
00007c47757d273d  vmovaps xmm9, [rsp+0x90]
00007c47757d2746  vmovaps xmm10, [rsp+0xA0]
00007c47757d274f  vmovaps xmm12, [rsp+0xB0]
00007c47757d2758  vmovaps xmm13, [rsp+0xC0]
00007c47757d2761  vmovaps xmm14, [rsp+0xD0]
00007c47757d276a  vmovaps xmm15, [rsp+0xE0]
00007c47757d2773  add rsp, 0xF0
00007c47757d277a  pop r11
00007c47757d277c  pop r10
00007c47757d277e  pop r9
00007c47757d2780  pop r8
00007c47757d2782  pop rsi
00007c47757d2783  pop rdi
00007c47757d2784  pop rdx
00007c47757d2785  pop rcx
00007c47757d2786  pop rax
00007c47757d2787  add rsp, 0x08
00007c47757d278b  jmp 0x00007C47757CFD34
00007c47757d2790  call 0x00007C47755FF430
00007c47757d2795  jmp 0x00007C47757CFD3E
00007c47757d279a  sub rsp, 0x08
00007c47757d279e  push rax
00007c47757d279f  push rcx
00007c47757d27a0  push rdx
00007c47757d27a1  push rdi
00007c47757d27a2  push rsi
00007c47757d27a3  push r8
00007c47757d27a5  push r9
00007c47757d27a7  push r10
00007c47757d27a9  push r11
00007c47757d27ab  sub rsp, 0xF0
00007c47757d27b2  vmovaps [rsp], xmm0
00007c47757d27b7  vmovaps [rsp+0x10], xmm1
00007c47757d27bd  vmovaps [rsp+0x20], xmm2
00007c47757d27c3  vmovaps [rsp+0x30], xmm3
00007c47757d27c9  vmovaps [rsp+0x40], xmm4
00007c47757d27cf  vmovaps [rsp+0x50], xmm5
00007c47757d27d5  vmovaps [rsp+0x60], xmm6
00007c47757d27db  vmovaps [rsp+0x70], xmm7
00007c47757d27e1  vmovaps [rsp+0x80], xmm8
00007c47757d27ea  vmovaps [rsp+0x90], xmm9
00007c47757d27f3  vmovaps [rsp+0xA0], xmm10
00007c47757d27fc  vmovaps [rsp+0xB0], xmm11
00007c47757d2805  vmovaps [rsp+0xC0], xmm12
00007c47757d280e  vmovaps [rsp+0xD0], xmm13
00007c47757d2817  vmovaps [rsp+0xE0], xmm15
00007c47757d2820  sub rsp, 0x30
00007c47757d2824  movaps [rsp], xmm14
00007c47757d2829  movaps [rsp+0x10], xmm6
00007c47757d282e  movaps [rsp+0x20], xmm2
00007c47757d2833  lea rdi, [rsp]
00007c47757d2837  mov esi, 0x00
00007c47757d283c  mov rax, 0x62084E409530
00007c47757d2846  call rax
00007c47757d2848  movaps xmm14, [rsp]
00007c47757d284d  add rsp, 0x30
00007c47757d2851  vmovaps xmm0, [rsp]
00007c47757d2856  vmovaps xmm1, [rsp+0x10]
00007c47757d285c  vmovaps xmm2, [rsp+0x20]
00007c47757d2862  vmovaps xmm3, [rsp+0x30]
00007c47757d2868  vmovaps xmm4, [rsp+0x40]
00007c47757d286e  vmovaps xmm5, [rsp+0x50]
00007c47757d2874  vmovaps xmm6, [rsp+0x60]
00007c47757d287a  vmovaps xmm7, [rsp+0x70]
00007c47757d2880  vmovaps xmm8, [rsp+0x80]
00007c47757d2889  vmovaps xmm9, [rsp+0x90]
00007c47757d2892  vmovaps xmm10, [rsp+0xA0]
00007c47757d289b  vmovaps xmm11, [rsp+0xB0]
00007c47757d28a4  vmovaps xmm12, [rsp+0xC0]
00007c47757d28ad  vmovaps xmm13, [rsp+0xD0]
00007c47757d28b6  vmovaps xmm15, [rsp+0xE0]
00007c47757d28bf  add rsp, 0xF0
00007c47757d28c6  pop r11
00007c47757d28c8  pop r10
00007c47757d28ca  pop r9
00007c47757d28cc  pop r8
00007c47757d28ce  pop rsi
00007c47757d28cf  pop rdi
00007c47757d28d0  pop rdx
00007c47757d28d1  pop rcx
00007c47757d28d2  pop rax
00007c47757d28d3  add rsp, 0x08
00007c47757d28d7  jmp 0x00007C47757CFD72
00007c47757d28dc  sub rsp, 0x08
00007c47757d28e0  push rax
00007c47757d28e1  push rcx
00007c47757d28e2  push rdx
00007c47757d28e3  push rdi
00007c47757d28e4  push rsi
00007c47757d28e5  push r8
00007c47757d28e7  push r9
00007c47757d28e9  push r10
00007c47757d28eb  push r11
00007c47757d28ed  sub rsp, 0xF0
00007c47757d28f4  vmovaps [rsp], xmm0
00007c47757d28f9  vmovaps [rsp+0x10], xmm1
00007c47757d28ff  vmovaps [rsp+0x20], xmm2
00007c47757d2905  vmovaps [rsp+0x30], xmm3
00007c47757d290b  vmovaps [rsp+0x40], xmm4
00007c47757d2911  vmovaps [rsp+0x50], xmm5
00007c47757d2917  vmovaps [rsp+0x60], xmm7
00007c47757d291d  vmovaps [rsp+0x70], xmm8
00007c47757d2923  vmovaps [rsp+0x80], xmm9
00007c47757d292c  vmovaps [rsp+0x90], xmm10
00007c47757d2935  vmovaps [rsp+0xA0], xmm11
00007c47757d293e  vmovaps [rsp+0xB0], xmm12
00007c47757d2947  vmovaps [rsp+0xC0], xmm13
00007c47757d2950  vmovaps [rsp+0xD0], xmm14
00007c47757d2959  vmovaps [rsp+0xE0], xmm15
00007c47757d2962  sub rsp, 0x30
00007c47757d2966  movaps [rsp], xmm6
00007c47757d296a  movaps [rsp+0x10], xmm5
00007c47757d296f  movaps [rsp+0x20], xmm1
00007c47757d2974  lea rdi, [rsp]
00007c47757d2978  mov esi, 0x00
00007c47757d297d  mov rax, 0x62084E409530
00007c47757d2987  call rax
00007c47757d2989  movaps xmm6, [rsp]
00007c47757d298d  add rsp, 0x30
00007c47757d2991  vmovaps xmm0, [rsp]
00007c47757d2996  vmovaps xmm1, [rsp+0x10]
00007c47757d299c  vmovaps xmm2, [rsp+0x20]
00007c47757d29a2  vmovaps xmm3, [rsp+0x30]
00007c47757d29a8  vmovaps xmm4, [rsp+0x40]
00007c47757d29ae  vmovaps xmm5, [rsp+0x50]
00007c47757d29b4  vmovaps xmm7, [rsp+0x60]
00007c47757d29ba  vmovaps xmm8, [rsp+0x70]
00007c47757d29c0  vmovaps xmm9, [rsp+0x80]
00007c47757d29c9  vmovaps xmm10, [rsp+0x90]
00007c47757d29d2  vmovaps xmm11, [rsp+0xA0]
00007c47757d29db  vmovaps xmm12, [rsp+0xB0]
00007c47757d29e4  vmovaps xmm13, [rsp+0xC0]
00007c47757d29ed  vmovaps xmm14, [rsp+0xD0]
00007c47757d29f6  vmovaps xmm15, [rsp+0xE0]
00007c47757d29ff  add rsp, 0xF0
00007c47757d2a06  pop r11
00007c47757d2a08  pop r10
00007c47757d2a0a  pop r9
00007c47757d2a0c  pop r8
00007c47757d2a0e  pop rsi
00007c47757d2a0f  pop rdi
00007c47757d2a10  pop rdx
00007c47757d2a11  pop rcx
00007c47757d2a12  pop rax
00007c47757d2a13  add rsp, 0x08
00007c47757d2a17  jmp 0x00007C47757CFD98
00007c47757d2a1c  sub rsp, 0x08
00007c47757d2a20  push rax
00007c47757d2a21  push rcx
00007c47757d2a22  push rdx
00007c47757d2a23  push rdi
00007c47757d2a24  push rsi
00007c47757d2a25  push r8
00007c47757d2a27  push r9
00007c47757d2a29  push r10
00007c47757d2a2b  push r11
00007c47757d2a2d  sub rsp, 0xF0
00007c47757d2a34  vmovaps [rsp], xmm0
00007c47757d2a39  vmovaps [rsp+0x10], xmm2
00007c47757d2a3f  vmovaps [rsp+0x20], xmm3
00007c47757d2a45  vmovaps [rsp+0x30], xmm4
00007c47757d2a4b  vmovaps [rsp+0x40], xmm5
00007c47757d2a51  vmovaps [rsp+0x50], xmm6
00007c47757d2a57  vmovaps [rsp+0x60], xmm7
00007c47757d2a5d  vmovaps [rsp+0x70], xmm8
00007c47757d2a63  vmovaps [rsp+0x80], xmm9
00007c47757d2a6c  vmovaps [rsp+0x90], xmm10
00007c47757d2a75  vmovaps [rsp+0xA0], xmm11
00007c47757d2a7e  vmovaps [rsp+0xB0], xmm12
00007c47757d2a87  vmovaps [rsp+0xC0], xmm13
00007c47757d2a90  vmovaps [rsp+0xD0], xmm14
00007c47757d2a99  vmovaps [rsp+0xE0], xmm15
00007c47757d2aa2  sub rsp, 0x30
00007c47757d2aa6  movaps [rsp], xmm1
00007c47757d2aaa  movaps [rsp+0x10], xmm5
00007c47757d2aaf  movaps [rsp+0x20], xmm13
00007c47757d2ab5  lea rdi, [rsp]
00007c47757d2ab9  mov esi, 0x00
00007c47757d2abe  mov rax, 0x62084E409530
00007c47757d2ac8  call rax
00007c47757d2aca  movaps xmm1, [rsp]
00007c47757d2ace  add rsp, 0x30
00007c47757d2ad2  vmovaps xmm0, [rsp]
00007c47757d2ad7  vmovaps xmm2, [rsp+0x10]
00007c47757d2add  vmovaps xmm3, [rsp+0x20]
00007c47757d2ae3  vmovaps xmm4, [rsp+0x30]
00007c47757d2ae9  vmovaps xmm5, [rsp+0x40]
00007c47757d2aef  vmovaps xmm6, [rsp+0x50]
00007c47757d2af5  vmovaps xmm7, [rsp+0x60]
00007c47757d2afb  vmovaps xmm8, [rsp+0x70]
00007c47757d2b01  vmovaps xmm9, [rsp+0x80]
00007c47757d2b0a  vmovaps xmm10, [rsp+0x90]
00007c47757d2b13  vmovaps xmm11, [rsp+0xA0]
00007c47757d2b1c  vmovaps xmm12, [rsp+0xB0]
00007c47757d2b25  vmovaps xmm13, [rsp+0xC0]
00007c47757d2b2e  vmovaps xmm14, [rsp+0xD0]
00007c47757d2b37  vmovaps xmm15, [rsp+0xE0]
00007c47757d2b40  add rsp, 0xF0
00007c47757d2b47  pop r11
00007c47757d2b49  pop r10
00007c47757d2b4b  pop r9
00007c47757d2b4d  pop r8
00007c47757d2b4f  pop rsi
00007c47757d2b50  pop rdi
00007c47757d2b51  pop rdx
00007c47757d2b52  pop rcx
00007c47757d2b53  pop rax
00007c47757d2b54  add rsp, 0x08
00007c47757d2b58  jmp 0x00007C47757CFDB6
00007c47757d2b5d  sub rsp, 0x08
00007c47757d2b61  push rax
00007c47757d2b62  push rcx
00007c47757d2b63  push rdx
00007c47757d2b64  push rdi
00007c47757d2b65  push rsi
00007c47757d2b66  push r8
00007c47757d2b68  push r9
00007c47757d2b6a  push r10
00007c47757d2b6c  push r11
00007c47757d2b6e  sub rsp, 0xF0
00007c47757d2b75  vmovaps [rsp], xmm0
00007c47757d2b7a  vmovaps [rsp+0x10], xmm1
00007c47757d2b80  vmovaps [rsp+0x20], xmm2
00007c47757d2b86  vmovaps [rsp+0x30], xmm3
00007c47757d2b8c  vmovaps [rsp+0x40], xmm4
00007c47757d2b92  vmovaps [rsp+0x50], xmm6
00007c47757d2b98  vmovaps [rsp+0x60], xmm7
00007c47757d2b9e  vmovaps [rsp+0x70], xmm8
00007c47757d2ba4  vmovaps [rsp+0x80], xmm9
00007c47757d2bad  vmovaps [rsp+0x90], xmm10
00007c47757d2bb6  vmovaps [rsp+0xA0], xmm11
00007c47757d2bbf  vmovaps [rsp+0xB0], xmm12
00007c47757d2bc8  vmovaps [rsp+0xC0], xmm13
00007c47757d2bd1  vmovaps [rsp+0xD0], xmm14
00007c47757d2bda  vmovaps [rsp+0xE0], xmm15
00007c47757d2be3  sub rsp, 0x30
00007c47757d2be7  movaps [rsp], xmm5
00007c47757d2beb  movaps [rsp+0x10], xmm2
00007c47757d2bf0  movaps [rsp+0x20], xmm13
00007c47757d2bf6  lea rdi, [rsp]
00007c47757d2bfa  mov esi, 0x00
00007c47757d2bff  mov rax, 0x62084E409530
00007c47757d2c09  call rax
00007c47757d2c0b  movaps xmm5, [rsp]
00007c47757d2c0f  add rsp, 0x30
00007c47757d2c13  vmovaps xmm0, [rsp]
00007c47757d2c18  vmovaps xmm1, [rsp+0x10]
00007c47757d2c1e  vmovaps xmm2, [rsp+0x20]
00007c47757d2c24  vmovaps xmm3, [rsp+0x30]
00007c47757d2c2a  vmovaps xmm4, [rsp+0x40]
00007c47757d2c30  vmovaps xmm6, [rsp+0x50]
00007c47757d2c36  vmovaps xmm7, [rsp+0x60]
00007c47757d2c3c  vmovaps xmm8, [rsp+0x70]
00007c47757d2c42  vmovaps xmm9, [rsp+0x80]
00007c47757d2c4b  vmovaps xmm10, [rsp+0x90]
00007c47757d2c54  vmovaps xmm11, [rsp+0xA0]
00007c47757d2c5d  vmovaps xmm12, [rsp+0xB0]
00007c47757d2c66  vmovaps xmm13, [rsp+0xC0]
00007c47757d2c6f  vmovaps xmm14, [rsp+0xD0]
00007c47757d2c78  vmovaps xmm15, [rsp+0xE0]
00007c47757d2c81  add rsp, 0xF0
00007c47757d2c88  pop r11
00007c47757d2c8a  pop r10
00007c47757d2c8c  pop r9
00007c47757d2c8e  pop r8
00007c47757d2c90  pop rsi
00007c47757d2c91  pop rdi
00007c47757d2c92  pop rdx
00007c47757d2c93  pop rcx
00007c47757d2c94  pop rax
00007c47757d2c95  add rsp, 0x08
00007c47757d2c99  jmp 0x00007C47757CFDEC
00007c47757d2c9e  sub rsp, 0x08
00007c47757d2ca2  push rax
00007c47757d2ca3  push rcx
00007c47757d2ca4  push rdx
00007c47757d2ca5  push rdi
00007c47757d2ca6  push rsi
00007c47757d2ca7  push r8
00007c47757d2ca9  push r9
00007c47757d2cab  push r10
00007c47757d2cad  push r11
00007c47757d2caf  sub rsp, 0xF0
00007c47757d2cb6  vmovaps [rsp], xmm0
00007c47757d2cbb  vmovaps [rsp+0x10], xmm1
00007c47757d2cc1  vmovaps [rsp+0x20], xmm2
00007c47757d2cc7  vmovaps [rsp+0x30], xmm3
00007c47757d2ccd  vmovaps [rsp+0x40], xmm4
00007c47757d2cd3  vmovaps [rsp+0x50], xmm5
00007c47757d2cd9  vmovaps [rsp+0x60], xmm6
00007c47757d2cdf  vmovaps [rsp+0x70], xmm7
00007c47757d2ce5  vmovaps [rsp+0x80], xmm8
00007c47757d2cee  vmovaps [rsp+0x90], xmm9
00007c47757d2cf7  vmovaps [rsp+0xA0], xmm10
00007c47757d2d00  vmovaps [rsp+0xB0], xmm11
00007c47757d2d09  vmovaps [rsp+0xC0], xmm12
00007c47757d2d12  vmovaps [rsp+0xD0], xmm14
00007c47757d2d1b  vmovaps [rsp+0xE0], xmm15
00007c47757d2d24  sub rsp, 0x30
00007c47757d2d28  movaps [rsp], xmm13
00007c47757d2d2d  movaps [rsp+0x10], xmm10
00007c47757d2d33  movaps [rsp+0x20], xmm1
00007c47757d2d38  lea rdi, [rsp]
00007c47757d2d3c  mov esi, 0x00
00007c47757d2d41  mov rax, 0x62084E409530
00007c47757d2d4b  call rax
00007c47757d2d4d  movaps xmm13, [rsp]
00007c47757d2d52  add rsp, 0x30
00007c47757d2d56  vmovaps xmm0, [rsp]
00007c47757d2d5b  vmovaps xmm1, [rsp+0x10]
00007c47757d2d61  vmovaps xmm2, [rsp+0x20]
00007c47757d2d67  vmovaps xmm3, [rsp+0x30]
00007c47757d2d6d  vmovaps xmm4, [rsp+0x40]
00007c47757d2d73  vmovaps xmm5, [rsp+0x50]
00007c47757d2d79  vmovaps xmm6, [rsp+0x60]
00007c47757d2d7f  vmovaps xmm7, [rsp+0x70]
00007c47757d2d85  vmovaps xmm8, [rsp+0x80]
00007c47757d2d8e  vmovaps xmm9, [rsp+0x90]
00007c47757d2d97  vmovaps xmm10, [rsp+0xA0]
00007c47757d2da0  vmovaps xmm11, [rsp+0xB0]
00007c47757d2da9  vmovaps xmm12, [rsp+0xC0]
00007c47757d2db2  vmovaps xmm14, [rsp+0xD0]
00007c47757d2dbb  vmovaps xmm15, [rsp+0xE0]
00007c47757d2dc4  add rsp, 0xF0
00007c47757d2dcb  pop r11
00007c47757d2dcd  pop r10
00007c47757d2dcf  pop r9
00007c47757d2dd1  pop r8
00007c47757d2dd3  pop rsi
00007c47757d2dd4  pop rdi
00007c47757d2dd5  pop rdx
00007c47757d2dd6  pop rcx
00007c47757d2dd7  pop rax
00007c47757d2dd8  add rsp, 0x08
00007c47757d2ddc  jmp 0x00007C47757CFE15
00007c47757d2de1  sub rsp, 0x08
00007c47757d2de5  push rax
00007c47757d2de6  push rcx
00007c47757d2de7  push rdx
00007c47757d2de8  push rdi
00007c47757d2de9  push rsi
00007c47757d2dea  push r8
00007c47757d2dec  push r9
00007c47757d2dee  push r10
00007c47757d2df0  push r11
00007c47757d2df2  sub rsp, 0xF0
00007c47757d2df9  vmovaps [rsp], xmm0
00007c47757d2dfe  vmovaps [rsp+0x10], xmm2
00007c47757d2e04  vmovaps [rsp+0x20], xmm3
00007c47757d2e0a  vmovaps [rsp+0x30], xmm4
00007c47757d2e10  vmovaps [rsp+0x40], xmm5
00007c47757d2e16  vmovaps [rsp+0x50], xmm6
00007c47757d2e1c  vmovaps [rsp+0x60], xmm7
00007c47757d2e22  vmovaps [rsp+0x70], xmm8
00007c47757d2e28  vmovaps [rsp+0x80], xmm9
00007c47757d2e31  vmovaps [rsp+0x90], xmm10
00007c47757d2e3a  vmovaps [rsp+0xA0], xmm11
00007c47757d2e43  vmovaps [rsp+0xB0], xmm12
00007c47757d2e4c  vmovaps [rsp+0xC0], xmm13
00007c47757d2e55  vmovaps [rsp+0xD0], xmm14
00007c47757d2e5e  vmovaps [rsp+0xE0], xmm15
00007c47757d2e67  sub rsp, 0x30
00007c47757d2e6b  movaps [rsp], xmm1
00007c47757d2e6f  movaps [rsp+0x10], xmm15
00007c47757d2e75  movaps [rsp+0x20], xmm10
00007c47757d2e7b  lea rdi, [rsp]
00007c47757d2e7f  mov esi, 0x00
00007c47757d2e84  mov rax, 0x62084E409530
00007c47757d2e8e  call rax
00007c47757d2e90  movaps xmm1, [rsp]
00007c47757d2e94  add rsp, 0x30
00007c47757d2e98  vmovaps xmm0, [rsp]
00007c47757d2e9d  vmovaps xmm2, [rsp+0x10]
00007c47757d2ea3  vmovaps xmm3, [rsp+0x20]
00007c47757d2ea9  vmovaps xmm4, [rsp+0x30]
00007c47757d2eaf  vmovaps xmm5, [rsp+0x40]
00007c47757d2eb5  vmovaps xmm6, [rsp+0x50]
00007c47757d2ebb  vmovaps xmm7, [rsp+0x60]
00007c47757d2ec1  vmovaps xmm8, [rsp+0x70]
00007c47757d2ec7  vmovaps xmm9, [rsp+0x80]
00007c47757d2ed0  vmovaps xmm10, [rsp+0x90]
00007c47757d2ed9  vmovaps xmm11, [rsp+0xA0]
00007c47757d2ee2  vmovaps xmm12, [rsp+0xB0]
00007c47757d2eeb  vmovaps xmm13, [rsp+0xC0]
00007c47757d2ef4  vmovaps xmm14, [rsp+0xD0]
00007c47757d2efd  vmovaps xmm15, [rsp+0xE0]
00007c47757d2f06  add rsp, 0xF0
00007c47757d2f0d  pop r11
00007c47757d2f0f  pop r10
00007c47757d2f11  pop r9
00007c47757d2f13  pop r8
00007c47757d2f15  pop rsi
00007c47757d2f16  pop rdi
00007c47757d2f17  pop rdx
00007c47757d2f18  pop rcx
00007c47757d2f19  pop rax
00007c47757d2f1a  add rsp, 0x08
00007c47757d2f1e  jmp 0x00007C47757CFE34
00007c47757d2f23  sub rsp, 0x08
00007c47757d2f27  push rax
00007c47757d2f28  push rcx
00007c47757d2f29  push rdx
00007c47757d2f2a  push rdi
00007c47757d2f2b  push rsi
00007c47757d2f2c  push r8
00007c47757d2f2e  push r9
00007c47757d2f30  push r10
00007c47757d2f32  push r11
00007c47757d2f34  sub rsp, 0xF0
00007c47757d2f3b  vmovaps [rsp], xmm0
00007c47757d2f40  vmovaps [rsp+0x10], xmm1
00007c47757d2f46  vmovaps [rsp+0x20], xmm2
00007c47757d2f4c  vmovaps [rsp+0x30], xmm3
00007c47757d2f52  vmovaps [rsp+0x40], xmm4
00007c47757d2f58  vmovaps [rsp+0x50], xmm5
00007c47757d2f5e  vmovaps [rsp+0x60], xmm6
00007c47757d2f64  vmovaps [rsp+0x70], xmm7
00007c47757d2f6a  vmovaps [rsp+0x80], xmm8
00007c47757d2f73  vmovaps [rsp+0x90], xmm9
00007c47757d2f7c  vmovaps [rsp+0xA0], xmm10
00007c47757d2f85  vmovaps [rsp+0xB0], xmm11
00007c47757d2f8e  vmovaps [rsp+0xC0], xmm12
00007c47757d2f97  vmovaps [rsp+0xD0], xmm13
00007c47757d2fa0  vmovaps [rsp+0xE0], xmm14
00007c47757d2fa9  sub rsp, 0x30
00007c47757d2fad  movaps [rsp], xmm15
00007c47757d2fb2  movaps [rsp+0x10], xmm10
00007c47757d2fb8  movaps [rsp+0x20], xmm11
00007c47757d2fbe  lea rdi, [rsp]
00007c47757d2fc2  mov esi, 0x00
00007c47757d2fc7  mov rax, 0x62084E409530
00007c47757d2fd1  call rax
00007c47757d2fd3  movaps xmm15, [rsp]
00007c47757d2fd8  add rsp, 0x30
00007c47757d2fdc  vmovaps xmm0, [rsp]
00007c47757d2fe1  vmovaps xmm1, [rsp+0x10]
00007c47757d2fe7  vmovaps xmm2, [rsp+0x20]
00007c47757d2fed  vmovaps xmm3, [rsp+0x30]
00007c47757d2ff3  vmovaps xmm4, [rsp+0x40]
00007c47757d2ff9  vmovaps xmm5, [rsp+0x50]
00007c47757d2fff  vmovaps xmm6, [rsp+0x60]
00007c47757d3005  vmovaps xmm7, [rsp+0x70]
00007c47757d300b  vmovaps xmm8, [rsp+0x80]
00007c47757d3014  vmovaps xmm9, [rsp+0x90]
00007c47757d301d  vmovaps xmm10, [rsp+0xA0]
00007c47757d3026  vmovaps xmm11, [rsp+0xB0]
00007c47757d302f  vmovaps xmm12, [rsp+0xC0]
00007c47757d3038  vmovaps xmm13, [rsp+0xD0]
00007c47757d3041  vmovaps xmm14, [rsp+0xE0]
00007c47757d304a  add rsp, 0xF0
00007c47757d3051  pop r11
00007c47757d3053  pop r10
00007c47757d3055  pop r9
00007c47757d3057  pop r8
00007c47757d3059  pop rsi
00007c47757d305a  pop rdi
00007c47757d305b  pop rdx
00007c47757d305c  pop rcx
00007c47757d305d  pop rax
00007c47757d305e  add rsp, 0x08
00007c47757d3062  jmp 0x00007C47757CFE57
00007c47757d3067  sub rsp, 0x08
00007c47757d306b  push rax
00007c47757d306c  push rcx
00007c47757d306d  push rdx
00007c47757d306e  push rdi
00007c47757d306f  push rsi
00007c47757d3070  push r8
00007c47757d3072  push r9
00007c47757d3074  push r10
00007c47757d3076  push r11
00007c47757d3078  sub rsp, 0xF0
00007c47757d307f  vmovaps [rsp], xmm0
00007c47757d3084  vmovaps [rsp+0x10], xmm1
00007c47757d308a  vmovaps [rsp+0x20], xmm2
00007c47757d3090  vmovaps [rsp+0x30], xmm3
00007c47757d3096  vmovaps [rsp+0x40], xmm4
00007c47757d309c  vmovaps [rsp+0x50], xmm5
00007c47757d30a2  vmovaps [rsp+0x60], xmm6
00007c47757d30a8  vmovaps [rsp+0x70], xmm7
00007c47757d30ae  vmovaps [rsp+0x80], xmm8
00007c47757d30b7  vmovaps [rsp+0x90], xmm9
00007c47757d30c0  vmovaps [rsp+0xA0], xmm11
00007c47757d30c9  vmovaps [rsp+0xB0], xmm12
00007c47757d30d2  vmovaps [rsp+0xC0], xmm13
00007c47757d30db  vmovaps [rsp+0xD0], xmm14
00007c47757d30e4  vmovaps [rsp+0xE0], xmm15
00007c47757d30ed  sub rsp, 0x30
00007c47757d30f1  movaps [rsp], xmm10
00007c47757d30f6  movaps [rsp+0x10], xmm12
00007c47757d30fc  movaps [rsp+0x20], xmm11
00007c47757d3102  lea rdi, [rsp]
00007c47757d3106  mov esi, 0x00
00007c47757d310b  mov rax, 0x62084E409530
00007c47757d3115  call rax
00007c47757d3117  movaps xmm10, [rsp]
00007c47757d311c  add rsp, 0x30
00007c47757d3120  vmovaps xmm0, [rsp]
00007c47757d3125  vmovaps xmm1, [rsp+0x10]
00007c47757d312b  vmovaps xmm2, [rsp+0x20]
00007c47757d3131  vmovaps xmm3, [rsp+0x30]
00007c47757d3137  vmovaps xmm4, [rsp+0x40]
00007c47757d313d  vmovaps xmm5, [rsp+0x50]
00007c47757d3143  vmovaps xmm6, [rsp+0x60]
00007c47757d3149  vmovaps xmm7, [rsp+0x70]
00007c47757d314f  vmovaps xmm8, [rsp+0x80]
00007c47757d3158  vmovaps xmm9, [rsp+0x90]
00007c47757d3161  vmovaps xmm11, [rsp+0xA0]
00007c47757d316a  vmovaps xmm12, [rsp+0xB0]
00007c47757d3173  vmovaps xmm13, [rsp+0xC0]
00007c47757d317c  vmovaps xmm14, [rsp+0xD0]
00007c47757d3185  vmovaps xmm15, [rsp+0xE0]
00007c47757d318e  add rsp, 0xF0
00007c47757d3195  pop r11
00007c47757d3197  pop r10
00007c47757d3199  pop r9
00007c47757d319b  pop r8
00007c47757d319d  pop rsi
00007c47757d319e  pop rdi
00007c47757d319f  pop rdx
00007c47757d31a0  pop rcx
00007c47757d31a1  pop rax
00007c47757d31a2  add rsp, 0x08
00007c47757d31a6  jmp 0x00007C47757CFE80
00007c47757d31ab  sub rsp, 0x08
00007c47757d31af  push rax
00007c47757d31b0  push rcx
00007c47757d31b1  push rdx
00007c47757d31b2  push rdi
00007c47757d31b3  push rsi
00007c47757d31b4  push r8
00007c47757d31b6  push r9
00007c47757d31b8  push r10
00007c47757d31ba  push r11
00007c47757d31bc  sub rsp, 0xF0
00007c47757d31c3  vmovaps [rsp], xmm0
00007c47757d31c8  vmovaps [rsp+0x10], xmm1
00007c47757d31ce  vmovaps [rsp+0x20], xmm2
00007c47757d31d4  vmovaps [rsp+0x30], xmm3
00007c47757d31da  vmovaps [rsp+0x40], xmm4
00007c47757d31e0  vmovaps [rsp+0x50], xmm5
00007c47757d31e6  vmovaps [rsp+0x60], xmm6
00007c47757d31ec  vmovaps [rsp+0x70], xmm7
00007c47757d31f2  vmovaps [rsp+0x80], xmm8
00007c47757d31fb  vmovaps [rsp+0x90], xmm9
00007c47757d3204  vmovaps [rsp+0xA0], xmm10
00007c47757d320d  vmovaps [rsp+0xB0], xmm12
00007c47757d3216  vmovaps [rsp+0xC0], xmm13
00007c47757d321f  vmovaps [rsp+0xD0], xmm14
00007c47757d3228  vmovaps [rsp+0xE0], xmm15
00007c47757d3231  sub rsp, 0x30
00007c47757d3235  movaps [rsp], xmm11
00007c47757d323a  movaps [rsp+0x10], xmm2
00007c47757d323f  movaps [rsp+0x20], xmm12
00007c47757d3245  lea rdi, [rsp]
00007c47757d3249  mov esi, 0x00
00007c47757d324e  mov rax, 0x62084E409530
00007c47757d3258  call rax
00007c47757d325a  movaps xmm11, [rsp]
00007c47757d325f  add rsp, 0x30
00007c47757d3263  vmovaps xmm0, [rsp]
00007c47757d3268  vmovaps xmm1, [rsp+0x10]
00007c47757d326e  vmovaps xmm2, [rsp+0x20]
00007c47757d3274  vmovaps xmm3, [rsp+0x30]
00007c47757d327a  vmovaps xmm4, [rsp+0x40]
00007c47757d3280  vmovaps xmm5, [rsp+0x50]
00007c47757d3286  vmovaps xmm6, [rsp+0x60]
00007c47757d328c  vmovaps xmm7, [rsp+0x70]
00007c47757d3292  vmovaps xmm8, [rsp+0x80]
00007c47757d329b  vmovaps xmm9, [rsp+0x90]
00007c47757d32a4  vmovaps xmm10, [rsp+0xA0]
00007c47757d32ad  vmovaps xmm12, [rsp+0xB0]
00007c47757d32b6  vmovaps xmm13, [rsp+0xC0]
00007c47757d32bf  vmovaps xmm14, [rsp+0xD0]
00007c47757d32c8  vmovaps xmm15, [rsp+0xE0]
00007c47757d32d1  add rsp, 0xF0
00007c47757d32d8  pop r11
00007c47757d32da  pop r10
00007c47757d32dc  pop r9
00007c47757d32de  pop r8
00007c47757d32e0  pop rsi
00007c47757d32e1  pop rdi
00007c47757d32e2  pop rdx
00007c47757d32e3  pop rcx
00007c47757d32e4  pop rax
00007c47757d32e5  add rsp, 0x08
00007c47757d32e9  jmp 0x00007C47757CFEB8
00007c47757d32ee  sub rsp, 0x08
00007c47757d32f2  push rax
00007c47757d32f3  push rcx
00007c47757d32f4  push rdx
00007c47757d32f5  push rdi
00007c47757d32f6  push rsi
00007c47757d32f7  push r8
00007c47757d32f9  push r9
00007c47757d32fb  push r10
00007c47757d32fd  push r11
00007c47757d32ff  sub rsp, 0xF0
00007c47757d3306  vmovaps [rsp], xmm0
00007c47757d330b  vmovaps [rsp+0x10], xmm2
00007c47757d3311  vmovaps [rsp+0x20], xmm3
00007c47757d3317  vmovaps [rsp+0x30], xmm4
00007c47757d331d  vmovaps [rsp+0x40], xmm5
00007c47757d3323  vmovaps [rsp+0x50], xmm6
00007c47757d3329  vmovaps [rsp+0x60], xmm7
00007c47757d332f  vmovaps [rsp+0x70], xmm8
00007c47757d3335  vmovaps [rsp+0x80], xmm9
00007c47757d333e  vmovaps [rsp+0x90], xmm10
00007c47757d3347  vmovaps [rsp+0xA0], xmm11
00007c47757d3350  vmovaps [rsp+0xB0], xmm12
00007c47757d3359  vmovaps [rsp+0xC0], xmm13
00007c47757d3362  vmovaps [rsp+0xD0], xmm14
00007c47757d336b  vmovaps [rsp+0xE0], xmm15
00007c47757d3374  sub rsp, 0x30
00007c47757d3378  movaps [rsp], xmm1
00007c47757d337c  movaps [rsp+0x10], xmm14
00007c47757d3382  movaps [rsp+0x20], xmm6
00007c47757d3387  lea rdi, [rsp]
00007c47757d338b  mov esi, 0x00
00007c47757d3390  mov rax, 0x62084E409530
00007c47757d339a  call rax
00007c47757d339c  movaps xmm1, [rsp]
00007c47757d33a0  add rsp, 0x30
00007c47757d33a4  vmovaps xmm0, [rsp]
00007c47757d33a9  vmovaps xmm2, [rsp+0x10]
00007c47757d33af  vmovaps xmm3, [rsp+0x20]
00007c47757d33b5  vmovaps xmm4, [rsp+0x30]
00007c47757d33bb  vmovaps xmm5, [rsp+0x40]
00007c47757d33c1  vmovaps xmm6, [rsp+0x50]
00007c47757d33c7  vmovaps xmm7, [rsp+0x60]
00007c47757d33cd  vmovaps xmm8, [rsp+0x70]
00007c47757d33d3  vmovaps xmm9, [rsp+0x80]
00007c47757d33dc  vmovaps xmm10, [rsp+0x90]
00007c47757d33e5  vmovaps xmm11, [rsp+0xA0]
00007c47757d33ee  vmovaps xmm12, [rsp+0xB0]
00007c47757d33f7  vmovaps xmm13, [rsp+0xC0]
00007c47757d3400  vmovaps xmm14, [rsp+0xD0]
00007c47757d3409  vmovaps xmm15, [rsp+0xE0]
00007c47757d3412  add rsp, 0xF0
00007c47757d3419  pop r11
00007c47757d341b  pop r10
00007c47757d341d  pop r9
00007c47757d341f  pop r8
00007c47757d3421  pop rsi
00007c47757d3422  pop rdi
00007c47757d3423  pop rdx
00007c47757d3424  pop rcx
00007c47757d3425  pop rax
00007c47757d3426  add rsp, 0x08
00007c47757d342a  jmp 0x00007C47757CFED1
00007c47757d342f  sub rsp, 0x08
00007c47757d3433  push rax
00007c47757d3434  push rcx
00007c47757d3435  push rdx
00007c47757d3436  push rdi
00007c47757d3437  push rsi
00007c47757d3438  push r8
00007c47757d343a  push r9
00007c47757d343c  push r10
00007c47757d343e  push r11
00007c47757d3440  sub rsp, 0xF0
00007c47757d3447  vmovaps [rsp], xmm0
00007c47757d344c  vmovaps [rsp+0x10], xmm1
00007c47757d3452  vmovaps [rsp+0x20], xmm2
00007c47757d3458  vmovaps [rsp+0x30], xmm3
00007c47757d345e  vmovaps [rsp+0x40], xmm4
00007c47757d3464  vmovaps [rsp+0x50], xmm5
00007c47757d346a  vmovaps [rsp+0x60], xmm6
00007c47757d3470  vmovaps [rsp+0x70], xmm7
00007c47757d3476  vmovaps [rsp+0x80], xmm8
00007c47757d347f  vmovaps [rsp+0x90], xmm9
00007c47757d3488  vmovaps [rsp+0xA0], xmm10
00007c47757d3491  vmovaps [rsp+0xB0], xmm11
00007c47757d349a  vmovaps [rsp+0xC0], xmm12
00007c47757d34a3  vmovaps [rsp+0xD0], xmm13
00007c47757d34ac  vmovaps [rsp+0xE0], xmm15
00007c47757d34b5  sub rsp, 0x30
00007c47757d34b9  movaps [rsp], xmm14
00007c47757d34be  movaps [rsp+0x10], xmm12
00007c47757d34c4  movaps [rsp+0x20], xmm5
00007c47757d34c9  lea rdi, [rsp]
00007c47757d34cd  mov esi, 0x00
00007c47757d34d2  mov rax, 0x62084E409530
00007c47757d34dc  call rax
00007c47757d34de  movaps xmm14, [rsp]
00007c47757d34e3  add rsp, 0x30
00007c47757d34e7  vmovaps xmm0, [rsp]
00007c47757d34ec  vmovaps xmm1, [rsp+0x10]
00007c47757d34f2  vmovaps xmm2, [rsp+0x20]
00007c47757d34f8  vmovaps xmm3, [rsp+0x30]
00007c47757d34fe  vmovaps xmm4, [rsp+0x40]
00007c47757d3504  vmovaps xmm5, [rsp+0x50]
00007c47757d350a  vmovaps xmm6, [rsp+0x60]
00007c47757d3510  vmovaps xmm7, [rsp+0x70]
00007c47757d3516  vmovaps xmm8, [rsp+0x80]
00007c47757d351f  vmovaps xmm9, [rsp+0x90]
00007c47757d3528  vmovaps xmm10, [rsp+0xA0]
00007c47757d3531  vmovaps xmm11, [rsp+0xB0]
00007c47757d353a  vmovaps xmm12, [rsp+0xC0]
00007c47757d3543  vmovaps xmm13, [rsp+0xD0]
00007c47757d354c  vmovaps xmm15, [rsp+0xE0]
00007c47757d3555  add rsp, 0xF0
00007c47757d355c  pop r11
00007c47757d355e  pop r10
00007c47757d3560  pop r9
00007c47757d3562  pop r8
00007c47757d3564  pop rsi
00007c47757d3565  pop rdi
00007c47757d3566  pop rdx
00007c47757d3567  pop rcx
00007c47757d3568  pop rax
00007c47757d3569  add rsp, 0x08
00007c47757d356d  jmp 0x00007C47757CFEF1
00007c47757d3572  sub rsp, 0x08
00007c47757d3576  push rax
00007c47757d3577  push rcx
00007c47757d3578  push rdx
00007c47757d3579  push rdi
00007c47757d357a  push rsi
00007c47757d357b  push r8
00007c47757d357d  push r9
00007c47757d357f  push r10
00007c47757d3581  push r11
00007c47757d3583  sub rsp, 0xF0
00007c47757d358a  vmovaps [rsp], xmm0
00007c47757d358f  vmovaps [rsp+0x10], xmm1
00007c47757d3595  vmovaps [rsp+0x20], xmm2
00007c47757d359b  vmovaps [rsp+0x30], xmm3
00007c47757d35a1  vmovaps [rsp+0x40], xmm4
00007c47757d35a7  vmovaps [rsp+0x50], xmm5
00007c47757d35ad  vmovaps [rsp+0x60], xmm7
00007c47757d35b3  vmovaps [rsp+0x70], xmm8
00007c47757d35b9  vmovaps [rsp+0x80], xmm9
00007c47757d35c2  vmovaps [rsp+0x90], xmm10
00007c47757d35cb  vmovaps [rsp+0xA0], xmm11
00007c47757d35d4  vmovaps [rsp+0xB0], xmm12
00007c47757d35dd  vmovaps [rsp+0xC0], xmm13
00007c47757d35e6  vmovaps [rsp+0xD0], xmm14
00007c47757d35ef  vmovaps [rsp+0xE0], xmm15
00007c47757d35f8  sub rsp, 0x30
00007c47757d35fc  movaps [rsp], xmm6
00007c47757d3600  movaps [rsp+0x10], xmm9
00007c47757d3606  movaps [rsp+0x20], xmm12
00007c47757d360c  lea rdi, [rsp]
00007c47757d3610  mov esi, 0x00
00007c47757d3615  mov rax, 0x62084E409530
00007c47757d361f  call rax
00007c47757d3621  movaps xmm6, [rsp]
00007c47757d3625  add rsp, 0x30
00007c47757d3629  vmovaps xmm0, [rsp]
00007c47757d362e  vmovaps xmm1, [rsp+0x10]
00007c47757d3634  vmovaps xmm2, [rsp+0x20]
00007c47757d363a  vmovaps xmm3, [rsp+0x30]
00007c47757d3640  vmovaps xmm4, [rsp+0x40]
00007c47757d3646  vmovaps xmm5, [rsp+0x50]
00007c47757d364c  vmovaps xmm7, [rsp+0x60]
00007c47757d3652  vmovaps xmm8, [rsp+0x70]
00007c47757d3658  vmovaps xmm9, [rsp+0x80]
00007c47757d3661  vmovaps xmm10, [rsp+0x90]
00007c47757d366a  vmovaps xmm11, [rsp+0xA0]
00007c47757d3673  vmovaps xmm12, [rsp+0xB0]
00007c47757d367c  vmovaps xmm13, [rsp+0xC0]
00007c47757d3685  vmovaps xmm14, [rsp+0xD0]
00007c47757d368e  vmovaps xmm15, [rsp+0xE0]
00007c47757d3697  add rsp, 0xF0
00007c47757d369e  pop r11
00007c47757d36a0  pop r10
00007c47757d36a2  pop r9
00007c47757d36a4  pop r8
00007c47757d36a6  pop rsi
00007c47757d36a7  pop rdi
00007c47757d36a8  pop rdx
00007c47757d36a9  pop rcx
00007c47757d36aa  pop rax
00007c47757d36ab  add rsp, 0x08
00007c47757d36af  jmp 0x00007C47757CFF19
00007c47757d36b4  sub rsp, 0x08
00007c47757d36b8  push rax
00007c47757d36b9  push rcx
00007c47757d36ba  push rdx
00007c47757d36bb  push rdi
00007c47757d36bc  push rsi
00007c47757d36bd  push r8
00007c47757d36bf  push r9
00007c47757d36c1  push r10
00007c47757d36c3  push r11
00007c47757d36c5  sub rsp, 0xF0
00007c47757d36cc  vmovaps [rsp], xmm0
00007c47757d36d1  vmovaps [rsp+0x10], xmm1
00007c47757d36d7  vmovaps [rsp+0x20], xmm2
00007c47757d36dd  vmovaps [rsp+0x30], xmm3
00007c47757d36e3  vmovaps [rsp+0x40], xmm4
00007c47757d36e9  vmovaps [rsp+0x50], xmm5
00007c47757d36ef  vmovaps [rsp+0x60], xmm6
00007c47757d36f5  vmovaps [rsp+0x70], xmm7
00007c47757d36fb  vmovaps [rsp+0x80], xmm8
00007c47757d3704  vmovaps [rsp+0x90], xmm9
00007c47757d370d  vmovaps [rsp+0xA0], xmm10
00007c47757d3716  vmovaps [rsp+0xB0], xmm11
00007c47757d371f  vmovaps [rsp+0xC0], xmm13
00007c47757d3728  vmovaps [rsp+0xD0], xmm14
00007c47757d3731  vmovaps [rsp+0xE0], xmm15
00007c47757d373a  sub rsp, 0x30
00007c47757d373e  movaps [rsp], xmm12
00007c47757d3743  movaps [rsp+0x10], xmm15
00007c47757d3749  movaps [rsp+0x20], xmm13
00007c47757d374f  lea rdi, [rsp]
00007c47757d3753  mov esi, 0x00
00007c47757d3758  mov rax, 0x62084E409530
00007c47757d3762  call rax
00007c47757d3764  movaps xmm12, [rsp]
00007c47757d3769  add rsp, 0x30
00007c47757d376d  vmovaps xmm0, [rsp]
00007c47757d3772  vmovaps xmm1, [rsp+0x10]
00007c47757d3778  vmovaps xmm2, [rsp+0x20]
00007c47757d377e  vmovaps xmm3, [rsp+0x30]
00007c47757d3784  vmovaps xmm4, [rsp+0x40]
00007c47757d378a  vmovaps xmm5, [rsp+0x50]
00007c47757d3790  vmovaps xmm6, [rsp+0x60]
00007c47757d3796  vmovaps xmm7, [rsp+0x70]
00007c47757d379c  vmovaps xmm8, [rsp+0x80]
00007c47757d37a5  vmovaps xmm9, [rsp+0x90]
00007c47757d37ae  vmovaps xmm10, [rsp+0xA0]
00007c47757d37b7  vmovaps xmm11, [rsp+0xB0]
00007c47757d37c0  vmovaps xmm13, [rsp+0xC0]
00007c47757d37c9  vmovaps xmm14, [rsp+0xD0]
00007c47757d37d2  vmovaps xmm15, [rsp+0xE0]
00007c47757d37db  add rsp, 0xF0
00007c47757d37e2  pop r11
00007c47757d37e4  pop r10
00007c47757d37e6  pop r9
00007c47757d37e8  pop r8
00007c47757d37ea  pop rsi
00007c47757d37eb  pop rdi
00007c47757d37ec  pop rdx
00007c47757d37ed  pop rcx
00007c47757d37ee  pop rax
00007c47757d37ef  add rsp, 0x08
00007c47757d37f3  jmp 0x00007C47757CFF34
00007c47757d37f8  sub rsp, 0x08
00007c47757d37fc  push rax
00007c47757d37fd  push rcx
00007c47757d37fe  push rdx
00007c47757d37ff  push rdi
00007c47757d3800  push rsi
00007c47757d3801  push r8
00007c47757d3803  push r9
00007c47757d3805  push r10
00007c47757d3807  push r11
00007c47757d3809  sub rsp, 0xF0
00007c47757d3810  vmovaps [rsp], xmm0
00007c47757d3815  vmovaps [rsp+0x10], xmm1
00007c47757d381b  vmovaps [rsp+0x20], xmm2
00007c47757d3821  vmovaps [rsp+0x30], xmm3
00007c47757d3827  vmovaps [rsp+0x40], xmm4
00007c47757d382d  vmovaps [rsp+0x50], xmm5
00007c47757d3833  vmovaps [rsp+0x60], xmm6
00007c47757d3839  vmovaps [rsp+0x70], xmm7
00007c47757d383f  vmovaps [rsp+0x80], xmm8
00007c47757d3848  vmovaps [rsp+0x90], xmm9
00007c47757d3851  vmovaps [rsp+0xA0], xmm10
00007c47757d385a  vmovaps [rsp+0xB0], xmm11
00007c47757d3863  vmovaps [rsp+0xC0], xmm12
00007c47757d386c  vmovaps [rsp+0xD0], xmm13
00007c47757d3875  vmovaps [rsp+0xE0], xmm14
00007c47757d387e  sub rsp, 0x30
00007c47757d3882  movaps [rsp], xmm15
00007c47757d3887  movaps [rsp+0x10], xmm13
00007c47757d388d  movaps [rsp+0x20], xmm10
00007c47757d3893  lea rdi, [rsp]
00007c47757d3897  mov esi, 0x00
00007c47757d389c  mov rax, 0x62084E409530
00007c47757d38a6  call rax
00007c47757d38a8  movaps xmm15, [rsp]
00007c47757d38ad  add rsp, 0x30
00007c47757d38b1  vmovaps xmm0, [rsp]
00007c47757d38b6  vmovaps xmm1, [rsp+0x10]
00007c47757d38bc  vmovaps xmm2, [rsp+0x20]
00007c47757d38c2  vmovaps xmm3, [rsp+0x30]
00007c47757d38c8  vmovaps xmm4, [rsp+0x40]
00007c47757d38ce  vmovaps xmm5, [rsp+0x50]
00007c47757d38d4  vmovaps xmm6, [rsp+0x60]
00007c47757d38da  vmovaps xmm7, [rsp+0x70]
00007c47757d38e0  vmovaps xmm8, [rsp+0x80]
00007c47757d38e9  vmovaps xmm9, [rsp+0x90]
00007c47757d38f2  vmovaps xmm10, [rsp+0xA0]
00007c47757d38fb  vmovaps xmm11, [rsp+0xB0]
00007c47757d3904  vmovaps xmm12, [rsp+0xC0]
00007c47757d390d  vmovaps xmm13, [rsp+0xD0]
00007c47757d3916  vmovaps xmm14, [rsp+0xE0]
00007c47757d391f  add rsp, 0xF0
00007c47757d3926  pop r11
00007c47757d3928  pop r10
00007c47757d392a  pop r9
00007c47757d392c  pop r8
00007c47757d392e  pop rsi
00007c47757d392f  pop rdi
00007c47757d3930  pop rdx
00007c47757d3931  pop rcx
00007c47757d3932  pop rax
00007c47757d3933  add rsp, 0x08
00007c47757d3937  jmp 0x00007C47757CFF55
00007c47757d393c  call 0x00007C477560C260
00007c47757d3941  jmp 0x00007C47757CFFB0
00007c47757d3946  sub rsp, 0x08
00007c47757d394a  push rax
00007c47757d394b  push rcx
00007c47757d394c  push rdx
00007c47757d394d  push rdi
00007c47757d394e  push rsi
00007c47757d394f  push r8
00007c47757d3951  push r9
00007c47757d3953  push r10
00007c47757d3955  push r11
00007c47757d3957  sub rsp, 0xF0
00007c47757d395e  vmovaps [rsp], xmm0
00007c47757d3963  vmovaps [rsp+0x10], xmm1
00007c47757d3969  vmovaps [rsp+0x20], xmm2
00007c47757d396f  vmovaps [rsp+0x30], xmm3
00007c47757d3975  vmovaps [rsp+0x40], xmm4
00007c47757d397b  vmovaps [rsp+0x50], xmm5
00007c47757d3981  vmovaps [rsp+0x60], xmm6
00007c47757d3987  vmovaps [rsp+0x70], xmm7
00007c47757d398d  vmovaps [rsp+0x80], xmm8
00007c47757d3996  vmovaps [rsp+0x90], xmm10
00007c47757d399f  vmovaps [rsp+0xA0], xmm11
00007c47757d39a8  vmovaps [rsp+0xB0], xmm12
00007c47757d39b1  vmovaps [rsp+0xC0], xmm13
00007c47757d39ba  vmovaps [rsp+0xD0], xmm14
00007c47757d39c3  vmovaps [rsp+0xE0], xmm15
00007c47757d39cc  sub rsp, 0x30
00007c47757d39d0  movaps [rsp], xmm9
00007c47757d39d5  movaps [rsp+0x10], xmm8
00007c47757d39db  movaps [rsp+0x20], xmm10
00007c47757d39e1  lea rdi, [rsp]
00007c47757d39e5  mov esi, 0x00
00007c47757d39ea  mov rax, 0x62084E409530
00007c47757d39f4  call rax
00007c47757d39f6  movaps xmm9, [rsp]
00007c47757d39fb  add rsp, 0x30
00007c47757d39ff  vmovaps xmm0, [rsp]
00007c47757d3a04  vmovaps xmm1, [rsp+0x10]
00007c47757d3a0a  vmovaps xmm2, [rsp+0x20]
00007c47757d3a10  vmovaps xmm3, [rsp+0x30]
00007c47757d3a16  vmovaps xmm4, [rsp+0x40]
00007c47757d3a1c  vmovaps xmm5, [rsp+0x50]
00007c47757d3a22  vmovaps xmm6, [rsp+0x60]
00007c47757d3a28  vmovaps xmm7, [rsp+0x70]
00007c47757d3a2e  vmovaps xmm8, [rsp+0x80]
00007c47757d3a37  vmovaps xmm10, [rsp+0x90]
00007c47757d3a40  vmovaps xmm11, [rsp+0xA0]
00007c47757d3a49  vmovaps xmm12, [rsp+0xB0]
00007c47757d3a52  vmovaps xmm13, [rsp+0xC0]
00007c47757d3a5b  vmovaps xmm14, [rsp+0xD0]
00007c47757d3a64  vmovaps xmm15, [rsp+0xE0]
00007c47757d3a6d  add rsp, 0xF0
00007c47757d3a74  pop r11
00007c47757d3a76  pop r10
00007c47757d3a78  pop r9
00007c47757d3a7a  pop r8
00007c47757d3a7c  pop rsi
00007c47757d3a7d  pop rdi
00007c47757d3a7e  pop rdx
00007c47757d3a7f  pop rcx
00007c47757d3a80  pop rax
00007c47757d3a81  add rsp, 0x08
00007c47757d3a85  jmp 0x00007C47757CFFE1
00007c47757d3a8a  sub rsp, 0x08
00007c47757d3a8e  push rax
00007c47757d3a8f  push rcx
00007c47757d3a90  push rdx
00007c47757d3a91  push rdi
00007c47757d3a92  push rsi
00007c47757d3a93  push r8
00007c47757d3a95  push r9
00007c47757d3a97  push r10
00007c47757d3a99  push r11
00007c47757d3a9b  sub rsp, 0xF0
00007c47757d3aa2  vmovaps [rsp], xmm0
00007c47757d3aa7  vmovaps [rsp+0x10], xmm1
00007c47757d3aad  vmovaps [rsp+0x20], xmm2
00007c47757d3ab3  vmovaps [rsp+0x30], xmm3
00007c47757d3ab9  vmovaps [rsp+0x40], xmm4
00007c47757d3abf  vmovaps [rsp+0x50], xmm5
00007c47757d3ac5  vmovaps [rsp+0x60], xmm6
00007c47757d3acb  vmovaps [rsp+0x70], xmm7
00007c47757d3ad1  vmovaps [rsp+0x80], xmm8
00007c47757d3ada  vmovaps [rsp+0x90], xmm9
00007c47757d3ae3  vmovaps [rsp+0xA0], xmm11
00007c47757d3aec  vmovaps [rsp+0xB0], xmm12
00007c47757d3af5  vmovaps [rsp+0xC0], xmm13
00007c47757d3afe  vmovaps [rsp+0xD0], xmm14
00007c47757d3b07  vmovaps [rsp+0xE0], xmm15
00007c47757d3b10  sub rsp, 0x30
00007c47757d3b14  movaps [rsp], xmm10
00007c47757d3b19  movaps [rsp+0x10], xmm1
00007c47757d3b1e  movaps [rsp+0x20], xmm11
00007c47757d3b24  lea rdi, [rsp]
00007c47757d3b28  mov esi, 0x00
00007c47757d3b2d  mov rax, 0x62084E409530
00007c47757d3b37  call rax
00007c47757d3b39  movaps xmm10, [rsp]
00007c47757d3b3e  add rsp, 0x30
00007c47757d3b42  vmovaps xmm0, [rsp]
00007c47757d3b47  vmovaps xmm1, [rsp+0x10]
00007c47757d3b4d  vmovaps xmm2, [rsp+0x20]
00007c47757d3b53  vmovaps xmm3, [rsp+0x30]
00007c47757d3b59  vmovaps xmm4, [rsp+0x40]
00007c47757d3b5f  vmovaps xmm5, [rsp+0x50]
00007c47757d3b65  vmovaps xmm6, [rsp+0x60]
00007c47757d3b6b  vmovaps xmm7, [rsp+0x70]
00007c47757d3b71  vmovaps xmm8, [rsp+0x80]
00007c47757d3b7a  vmovaps xmm9, [rsp+0x90]
00007c47757d3b83  vmovaps xmm11, [rsp+0xA0]
00007c47757d3b8c  vmovaps xmm12, [rsp+0xB0]
00007c47757d3b95  vmovaps xmm13, [rsp+0xC0]
00007c47757d3b9e  vmovaps xmm14, [rsp+0xD0]
00007c47757d3ba7  vmovaps xmm15, [rsp+0xE0]
00007c47757d3bb0  add rsp, 0xF0
00007c47757d3bb7  pop r11
00007c47757d3bb9  pop r10
00007c47757d3bbb  pop r9
00007c47757d3bbd  pop r8
00007c47757d3bbf  pop rsi
00007c47757d3bc0  pop rdi
00007c47757d3bc1  pop rdx
00007c47757d3bc2  pop rcx
00007c47757d3bc3  pop rax
00007c47757d3bc4  add rsp, 0x08
00007c47757d3bc8  jmp 0x00007C47757CFFFC
00007c47757d3bcd  sub rsp, 0x08
00007c47757d3bd1  push rax
00007c47757d3bd2  push rcx
00007c47757d3bd3  push rdx
00007c47757d3bd4  push rdi
00007c47757d3bd5  push rsi
00007c47757d3bd6  push r8
00007c47757d3bd8  push r9
00007c47757d3bda  push r10
00007c47757d3bdc  push r11
00007c47757d3bde  sub rsp, 0xF0
00007c47757d3be5  vmovaps [rsp], xmm0
00007c47757d3bea  vmovaps [rsp+0x10], xmm2
00007c47757d3bf0  vmovaps [rsp+0x20], xmm3
00007c47757d3bf6  vmovaps [rsp+0x30], xmm4
00007c47757d3bfc  vmovaps [rsp+0x40], xmm5
00007c47757d3c02  vmovaps [rsp+0x50], xmm6
00007c47757d3c08  vmovaps [rsp+0x60], xmm7
00007c47757d3c0e  vmovaps [rsp+0x70], xmm8
00007c47757d3c14  vmovaps [rsp+0x80], xmm9
00007c47757d3c1d  vmovaps [rsp+0x90], xmm10
00007c47757d3c26  vmovaps [rsp+0xA0], xmm11
00007c47757d3c2f  vmovaps [rsp+0xB0], xmm12
00007c47757d3c38  vmovaps [rsp+0xC0], xmm13
00007c47757d3c41  vmovaps [rsp+0xD0], xmm14
00007c47757d3c4a  vmovaps [rsp+0xE0], xmm15
00007c47757d3c53  sub rsp, 0x30
00007c47757d3c57  movaps [rsp], xmm1
00007c47757d3c5b  movaps [rsp+0x10], xmm14
00007c47757d3c61  movaps [rsp+0x20], xmm6
00007c47757d3c66  lea rdi, [rsp]
00007c47757d3c6a  mov esi, 0x00
00007c47757d3c6f  mov rax, 0x62084E409530
00007c47757d3c79  call rax
00007c47757d3c7b  movaps xmm1, [rsp]
00007c47757d3c7f  add rsp, 0x30
00007c47757d3c83  vmovaps xmm0, [rsp]
00007c47757d3c88  vmovaps xmm2, [rsp+0x10]
00007c47757d3c8e  vmovaps xmm3, [rsp+0x20]
00007c47757d3c94  vmovaps xmm4, [rsp+0x30]
00007c47757d3c9a  vmovaps xmm5, [rsp+0x40]
00007c47757d3ca0  vmovaps xmm6, [rsp+0x50]
00007c47757d3ca6  vmovaps xmm7, [rsp+0x60]
00007c47757d3cac  vmovaps xmm8, [rsp+0x70]
00007c47757d3cb2  vmovaps xmm9, [rsp+0x80]
00007c47757d3cbb  vmovaps xmm10, [rsp+0x90]
00007c47757d3cc4  vmovaps xmm11, [rsp+0xA0]
00007c47757d3ccd  vmovaps xmm12, [rsp+0xB0]
00007c47757d3cd6  vmovaps xmm13, [rsp+0xC0]
00007c47757d3cdf  vmovaps xmm14, [rsp+0xD0]
00007c47757d3ce8  vmovaps xmm15, [rsp+0xE0]
00007c47757d3cf1  add rsp, 0xF0
00007c47757d3cf8  pop r11
00007c47757d3cfa  pop r10
00007c47757d3cfc  pop r9
00007c47757d3cfe  pop r8
00007c47757d3d00  pop rsi
00007c47757d3d01  pop rdi
00007c47757d3d02  pop rdx
00007c47757d3d03  pop rcx
00007c47757d3d04  pop rax
00007c47757d3d05  add rsp, 0x08
00007c47757d3d09  jmp 0x00007C47757D0015
00007c47757d3d0e  sub rsp, 0x08
00007c47757d3d12  push rax
00007c47757d3d13  push rcx
00007c47757d3d14  push rdx
00007c47757d3d15  push rdi
00007c47757d3d16  push rsi
00007c47757d3d17  push r8
00007c47757d3d19  push r9
00007c47757d3d1b  push r10
00007c47757d3d1d  push r11
00007c47757d3d1f  sub rsp, 0xF0
00007c47757d3d26  vmovaps [rsp], xmm0
00007c47757d3d2b  vmovaps [rsp+0x10], xmm1
00007c47757d3d31  vmovaps [rsp+0x20], xmm2
00007c47757d3d37  vmovaps [rsp+0x30], xmm3
00007c47757d3d3d  vmovaps [rsp+0x40], xmm4
00007c47757d3d43  vmovaps [rsp+0x50], xmm5
00007c47757d3d49  vmovaps [rsp+0x60], xmm6
00007c47757d3d4f  vmovaps [rsp+0x70], xmm7
00007c47757d3d55  vmovaps [rsp+0x80], xmm8
00007c47757d3d5e  vmovaps [rsp+0x90], xmm9
00007c47757d3d67  vmovaps [rsp+0xA0], xmm10
00007c47757d3d70  vmovaps [rsp+0xB0], xmm12
00007c47757d3d79  vmovaps [rsp+0xC0], xmm13
00007c47757d3d82  vmovaps [rsp+0xD0], xmm14
00007c47757d3d8b  vmovaps [rsp+0xE0], xmm15
00007c47757d3d94  sub rsp, 0x30
00007c47757d3d98  movaps [rsp], xmm11
00007c47757d3d9d  movaps [rsp+0x10], xmm13
00007c47757d3da3  movaps [rsp+0x20], xmm14
00007c47757d3da9  lea rdi, [rsp]
00007c47757d3dad  mov esi, 0x00
00007c47757d3db2  mov rax, 0x62084E409530
00007c47757d3dbc  call rax
00007c47757d3dbe  movaps xmm11, [rsp]
00007c47757d3dc3  add rsp, 0x30
00007c47757d3dc7  vmovaps xmm0, [rsp]
00007c47757d3dcc  vmovaps xmm1, [rsp+0x10]
00007c47757d3dd2  vmovaps xmm2, [rsp+0x20]
00007c47757d3dd8  vmovaps xmm3, [rsp+0x30]
00007c47757d3dde  vmovaps xmm4, [rsp+0x40]
00007c47757d3de4  vmovaps xmm5, [rsp+0x50]
00007c47757d3dea  vmovaps xmm6, [rsp+0x60]
00007c47757d3df0  vmovaps xmm7, [rsp+0x70]
00007c47757d3df6  vmovaps xmm8, [rsp+0x80]
00007c47757d3dff  vmovaps xmm9, [rsp+0x90]
00007c47757d3e08  vmovaps xmm10, [rsp+0xA0]
00007c47757d3e11  vmovaps xmm12, [rsp+0xB0]
00007c47757d3e1a  vmovaps xmm13, [rsp+0xC0]
00007c47757d3e23  vmovaps xmm14, [rsp+0xD0]
00007c47757d3e2c  vmovaps xmm15, [rsp+0xE0]
00007c47757d3e35  add rsp, 0xF0
00007c47757d3e3c  pop r11
00007c47757d3e3e  pop r10
00007c47757d3e40  pop r9
00007c47757d3e42  pop r8
00007c47757d3e44  pop rsi
00007c47757d3e45  pop rdi
00007c47757d3e46  pop rdx
00007c47757d3e47  pop rcx
00007c47757d3e48  pop rax
00007c47757d3e49  add rsp, 0x08
00007c47757d3e4d  jmp 0x00007C47757D003F
00007c47757d3e52  sub rsp, 0x08
00007c47757d3e56  push rax
00007c47757d3e57  push rcx
00007c47757d3e58  push rdx
00007c47757d3e59  push rdi
00007c47757d3e5a  push rsi
00007c47757d3e5b  push r8
00007c47757d3e5d  push r9
00007c47757d3e5f  push r10
00007c47757d3e61  push r11
00007c47757d3e63  sub rsp, 0xF0
00007c47757d3e6a  vmovaps [rsp], xmm0
00007c47757d3e6f  vmovaps [rsp+0x10], xmm1
00007c47757d3e75  vmovaps [rsp+0x20], xmm2
00007c47757d3e7b  vmovaps [rsp+0x30], xmm3
00007c47757d3e81  vmovaps [rsp+0x40], xmm4
00007c47757d3e87  vmovaps [rsp+0x50], xmm5
00007c47757d3e8d  vmovaps [rsp+0x60], xmm6
00007c47757d3e93  vmovaps [rsp+0x70], xmm7
00007c47757d3e99  vmovaps [rsp+0x80], xmm8
00007c47757d3ea2  vmovaps [rsp+0x90], xmm9
00007c47757d3eab  vmovaps [rsp+0xA0], xmm10
00007c47757d3eb4  vmovaps [rsp+0xB0], xmm11
00007c47757d3ebd  vmovaps [rsp+0xC0], xmm12
00007c47757d3ec6  vmovaps [rsp+0xD0], xmm14
00007c47757d3ecf  vmovaps [rsp+0xE0], xmm15
00007c47757d3ed8  sub rsp, 0x30
00007c47757d3edc  movaps [rsp], xmm13
00007c47757d3ee1  movaps [rsp+0x10], xmm8
00007c47757d3ee7  movaps [rsp+0x20], xmm14
00007c47757d3eed  lea rdi, [rsp]
00007c47757d3ef1  mov esi, 0x00
00007c47757d3ef6  mov rax, 0x62084E409530
00007c47757d3f00  call rax
00007c47757d3f02  movaps xmm13, [rsp]
00007c47757d3f07  add rsp, 0x30
00007c47757d3f0b  vmovaps xmm0, [rsp]
00007c47757d3f10  vmovaps xmm1, [rsp+0x10]
00007c47757d3f16  vmovaps xmm2, [rsp+0x20]
00007c47757d3f1c  vmovaps xmm3, [rsp+0x30]
00007c47757d3f22  vmovaps xmm4, [rsp+0x40]
00007c47757d3f28  vmovaps xmm5, [rsp+0x50]
00007c47757d3f2e  vmovaps xmm6, [rsp+0x60]
00007c47757d3f34  vmovaps xmm7, [rsp+0x70]
00007c47757d3f3a  vmovaps xmm8, [rsp+0x80]
00007c47757d3f43  vmovaps xmm9, [rsp+0x90]
00007c47757d3f4c  vmovaps xmm10, [rsp+0xA0]
00007c47757d3f55  vmovaps xmm11, [rsp+0xB0]
00007c47757d3f5e  vmovaps xmm12, [rsp+0xC0]
00007c47757d3f67  vmovaps xmm14, [rsp+0xD0]
00007c47757d3f70  vmovaps xmm15, [rsp+0xE0]
00007c47757d3f79  add rsp, 0xF0
00007c47757d3f80  pop r11
00007c47757d3f82  pop r10
00007c47757d3f84  pop r9
00007c47757d3f86  pop r8
00007c47757d3f88  pop rsi
00007c47757d3f89  pop rdi
00007c47757d3f8a  pop rdx
00007c47757d3f8b  pop rcx
00007c47757d3f8c  pop rax
00007c47757d3f8d  add rsp, 0x08
00007c47757d3f91  jmp 0x00007C47757D006E
00007c47757d3f96  sub rsp, 0x08
00007c47757d3f9a  push rax
00007c47757d3f9b  push rcx
00007c47757d3f9c  push rdx
00007c47757d3f9d  push rdi
00007c47757d3f9e  push rsi
00007c47757d3f9f  push r8
00007c47757d3fa1  push r9
00007c47757d3fa3  push r10
00007c47757d3fa5  push r11
00007c47757d3fa7  sub rsp, 0xF0
00007c47757d3fae  vmovaps [rsp], xmm0
00007c47757d3fb3  vmovaps [rsp+0x10], xmm1
00007c47757d3fb9  vmovaps [rsp+0x20], xmm2
00007c47757d3fbf  vmovaps [rsp+0x30], xmm3
00007c47757d3fc5  vmovaps [rsp+0x40], xmm4
00007c47757d3fcb  vmovaps [rsp+0x50], xmm5
00007c47757d3fd1  vmovaps [rsp+0x60], xmm6
00007c47757d3fd7  vmovaps [rsp+0x70], xmm7
00007c47757d3fdd  vmovaps [rsp+0x80], xmm9
00007c47757d3fe6  vmovaps [rsp+0x90], xmm10
00007c47757d3fef  vmovaps [rsp+0xA0], xmm11
00007c47757d3ff8  vmovaps [rsp+0xB0], xmm12
00007c47757d4001  vmovaps [rsp+0xC0], xmm13
00007c47757d400a  vmovaps [rsp+0xD0], xmm14
00007c47757d4013  vmovaps [rsp+0xE0], xmm15
00007c47757d401c  sub rsp, 0x30
00007c47757d4020  movaps [rsp], xmm8
00007c47757d4025  movaps [rsp+0x10], xmm7
00007c47757d402a  movaps [rsp+0x20], xmm14
00007c47757d4030  lea rdi, [rsp]
00007c47757d4034  mov esi, 0x00
00007c47757d4039  mov rax, 0x62084E409530
00007c47757d4043  call rax
00007c47757d4045  movaps xmm8, [rsp]
00007c47757d404a  add rsp, 0x30
00007c47757d404e  vmovaps xmm0, [rsp]
00007c47757d4053  vmovaps xmm1, [rsp+0x10]
00007c47757d4059  vmovaps xmm2, [rsp+0x20]
00007c47757d405f  vmovaps xmm3, [rsp+0x30]
00007c47757d4065  vmovaps xmm4, [rsp+0x40]
00007c47757d406b  vmovaps xmm5, [rsp+0x50]
00007c47757d4071  vmovaps xmm6, [rsp+0x60]
00007c47757d4077  vmovaps xmm7, [rsp+0x70]
00007c47757d407d  vmovaps xmm9, [rsp+0x80]
00007c47757d4086  vmovaps xmm10, [rsp+0x90]
00007c47757d408f  vmovaps xmm11, [rsp+0xA0]
00007c47757d4098  vmovaps xmm12, [rsp+0xB0]
00007c47757d40a1  vmovaps xmm13, [rsp+0xC0]
00007c47757d40aa  vmovaps xmm14, [rsp+0xD0]
00007c47757d40b3  vmovaps xmm15, [rsp+0xE0]
00007c47757d40bc  add rsp, 0xF0
00007c47757d40c3  pop r11
00007c47757d40c5  pop r10
00007c47757d40c7  pop r9
00007c47757d40c9  pop r8
00007c47757d40cb  pop rsi
00007c47757d40cc  pop rdi
00007c47757d40cd  pop rdx
00007c47757d40ce  pop rcx
00007c47757d40cf  pop rax
00007c47757d40d0  add rsp, 0x08
00007c47757d40d4  jmp 0x00007C47757D0094
00007c47757d40d9  sub rsp, 0x08
00007c47757d40dd  push rax
00007c47757d40de  push rcx
00007c47757d40df  push rdx
00007c47757d40e0  push rdi
00007c47757d40e1  push rsi
00007c47757d40e2  push r8
00007c47757d40e4  push r9
00007c47757d40e6  push r10
00007c47757d40e8  push r11
00007c47757d40ea  sub rsp, 0xF0
00007c47757d40f1  vmovaps [rsp], xmm0
00007c47757d40f6  vmovaps [rsp+0x10], xmm1
00007c47757d40fc  vmovaps [rsp+0x20], xmm2
00007c47757d4102  vmovaps [rsp+0x30], xmm3
00007c47757d4108  vmovaps [rsp+0x40], xmm4
00007c47757d410e  vmovaps [rsp+0x50], xmm5
00007c47757d4114  vmovaps [rsp+0x60], xmm6
00007c47757d411a  vmovaps [rsp+0x70], xmm7
00007c47757d4120  vmovaps [rsp+0x80], xmm8
00007c47757d4129  vmovaps [rsp+0x90], xmm9
00007c47757d4132  vmovaps [rsp+0xA0], xmm10
00007c47757d413b  vmovaps [rsp+0xB0], xmm11
00007c47757d4144  vmovaps [rsp+0xC0], xmm12
00007c47757d414d  vmovaps [rsp+0xD0], xmm13
00007c47757d4156  vmovaps [rsp+0xE0], xmm15
00007c47757d415f  sub rsp, 0x30
00007c47757d4163  movaps [rsp], xmm14
00007c47757d4168  movaps [rsp+0x10], xmm12
00007c47757d416e  movaps [rsp+0x20], xmm9
00007c47757d4174  lea rdi, [rsp]
00007c47757d4178  mov esi, 0x00
00007c47757d417d  mov rax, 0x62084E409530
00007c47757d4187  call rax
00007c47757d4189  movaps xmm14, [rsp]
00007c47757d418e  add rsp, 0x30
00007c47757d4192  vmovaps xmm0, [rsp]
00007c47757d4197  vmovaps xmm1, [rsp+0x10]
00007c47757d419d  vmovaps xmm2, [rsp+0x20]
00007c47757d41a3  vmovaps xmm3, [rsp+0x30]
00007c47757d41a9  vmovaps xmm4, [rsp+0x40]
00007c47757d41af  vmovaps xmm5, [rsp+0x50]
00007c47757d41b5  vmovaps xmm6, [rsp+0x60]
00007c47757d41bb  vmovaps xmm7, [rsp+0x70]
00007c47757d41c1  vmovaps xmm8, [rsp+0x80]
00007c47757d41ca  vmovaps xmm9, [rsp+0x90]
00007c47757d41d3  vmovaps xmm10, [rsp+0xA0]
00007c47757d41dc  vmovaps xmm11, [rsp+0xB0]
00007c47757d41e5  vmovaps xmm12, [rsp+0xC0]
00007c47757d41ee  vmovaps xmm13, [rsp+0xD0]
00007c47757d41f7  vmovaps xmm15, [rsp+0xE0]
00007c47757d4200  add rsp, 0xF0
00007c47757d4207  pop r11
00007c47757d4209  pop r10
00007c47757d420b  pop r9
00007c47757d420d  pop r8
00007c47757d420f  pop rsi
00007c47757d4210  pop rdi
00007c47757d4211  pop rdx
00007c47757d4212  pop rcx
00007c47757d4213  pop rax
00007c47757d4214  add rsp, 0x08
00007c47757d4218  jmp 0x00007C47757D00AE
00007c47757d421d  sub rsp, 0x08
00007c47757d4221  push rax
00007c47757d4222  push rcx
00007c47757d4223  push rdx
00007c47757d4224  push rdi
00007c47757d4225  push rsi
00007c47757d4226  push r8
00007c47757d4228  push r9
00007c47757d422a  push r10
00007c47757d422c  push r11
00007c47757d422e  sub rsp, 0xF0
00007c47757d4235  vmovaps [rsp], xmm0
00007c47757d423a  vmovaps [rsp+0x10], xmm1
00007c47757d4240  vmovaps [rsp+0x20], xmm2
00007c47757d4246  vmovaps [rsp+0x30], xmm3
00007c47757d424c  vmovaps [rsp+0x40], xmm4
00007c47757d4252  vmovaps [rsp+0x50], xmm5
00007c47757d4258  vmovaps [rsp+0x60], xmm6
00007c47757d425e  vmovaps [rsp+0x70], xmm7
00007c47757d4264  vmovaps [rsp+0x80], xmm8
00007c47757d426d  vmovaps [rsp+0x90], xmm10
00007c47757d4276  vmovaps [rsp+0xA0], xmm11
00007c47757d427f  vmovaps [rsp+0xB0], xmm12
00007c47757d4288  vmovaps [rsp+0xC0], xmm13
00007c47757d4291  vmovaps [rsp+0xD0], xmm14
00007c47757d429a  vmovaps [rsp+0xE0], xmm15
00007c47757d42a3  sub rsp, 0x30
00007c47757d42a7  movaps [rsp], xmm9
00007c47757d42ac  movaps [rsp+0x10], xmm7
00007c47757d42b1  movaps [rsp+0x20], xmm12
00007c47757d42b7  lea rdi, [rsp]
00007c47757d42bb  mov esi, 0x00
00007c47757d42c0  mov rax, 0x62084E409530
00007c47757d42ca  call rax
00007c47757d42cc  movaps xmm9, [rsp]
00007c47757d42d1  add rsp, 0x30
00007c47757d42d5  vmovaps xmm0, [rsp]
00007c47757d42da  vmovaps xmm1, [rsp+0x10]
00007c47757d42e0  vmovaps xmm2, [rsp+0x20]
00007c47757d42e6  vmovaps xmm3, [rsp+0x30]
00007c47757d42ec  vmovaps xmm4, [rsp+0x40]
00007c47757d42f2  vmovaps xmm5, [rsp+0x50]
00007c47757d42f8  vmovaps xmm6, [rsp+0x60]
00007c47757d42fe  vmovaps xmm7, [rsp+0x70]
00007c47757d4304  vmovaps xmm8, [rsp+0x80]
00007c47757d430d  vmovaps xmm10, [rsp+0x90]
00007c47757d4316  vmovaps xmm11, [rsp+0xA0]
00007c47757d431f  vmovaps xmm12, [rsp+0xB0]
00007c47757d4328  vmovaps xmm13, [rsp+0xC0]
00007c47757d4331  vmovaps xmm14, [rsp+0xD0]
00007c47757d433a  vmovaps xmm15, [rsp+0xE0]
00007c47757d4343  add rsp, 0xF0
00007c47757d434a  pop r11
00007c47757d434c  pop r10
00007c47757d434e  pop r9
00007c47757d4350  pop r8
00007c47757d4352  pop rsi
00007c47757d4353  pop rdi
00007c47757d4354  pop rdx
00007c47757d4355  pop rcx
00007c47757d4356  pop rax
00007c47757d4357  add rsp, 0x08
00007c47757d435b  jmp 0x00007C47757D00DD
00007c47757d4360  sub rsp, 0x08
00007c47757d4364  push rax
00007c47757d4365  push rcx
00007c47757d4366  push rdx
00007c47757d4367  push rdi
00007c47757d4368  push rsi
00007c47757d4369  push r8
00007c47757d436b  push r9
00007c47757d436d  push r10
00007c47757d436f  push r11
00007c47757d4371  sub rsp, 0xF0
00007c47757d4378  vmovaps [rsp], xmm0
00007c47757d437d  vmovaps [rsp+0x10], xmm1
00007c47757d4383  vmovaps [rsp+0x20], xmm2
00007c47757d4389  vmovaps [rsp+0x30], xmm3
00007c47757d438f  vmovaps [rsp+0x40], xmm4
00007c47757d4395  vmovaps [rsp+0x50], xmm5
00007c47757d439b  vmovaps [rsp+0x60], xmm6
00007c47757d43a1  vmovaps [rsp+0x70], xmm7
00007c47757d43a7  vmovaps [rsp+0x80], xmm8
00007c47757d43b0  vmovaps [rsp+0x90], xmm9
00007c47757d43b9  vmovaps [rsp+0xA0], xmm10
00007c47757d43c2  vmovaps [rsp+0xB0], xmm11
00007c47757d43cb  vmovaps [rsp+0xC0], xmm13
00007c47757d43d4  vmovaps [rsp+0xD0], xmm14
00007c47757d43dd  vmovaps [rsp+0xE0], xmm15
00007c47757d43e6  sub rsp, 0x30
00007c47757d43ea  movaps [rsp], xmm12
00007c47757d43ef  movaps [rsp+0x10], xmm15
00007c47757d43f5  movaps [rsp+0x20], xmm11
00007c47757d43fb  lea rdi, [rsp]
00007c47757d43ff  mov esi, 0x00
00007c47757d4404  mov rax, 0x62084E409530
00007c47757d440e  call rax
00007c47757d4410  movaps xmm12, [rsp]
00007c47757d4415  add rsp, 0x30
00007c47757d4419  vmovaps xmm0, [rsp]
00007c47757d441e  vmovaps xmm1, [rsp+0x10]
00007c47757d4424  vmovaps xmm2, [rsp+0x20]
00007c47757d442a  vmovaps xmm3, [rsp+0x30]
00007c47757d4430  vmovaps xmm4, [rsp+0x40]
00007c47757d4436  vmovaps xmm5, [rsp+0x50]
00007c47757d443c  vmovaps xmm6, [rsp+0x60]
00007c47757d4442  vmovaps xmm7, [rsp+0x70]
00007c47757d4448  vmovaps xmm8, [rsp+0x80]
00007c47757d4451  vmovaps xmm9, [rsp+0x90]
00007c47757d445a  vmovaps xmm10, [rsp+0xA0]
00007c47757d4463  vmovaps xmm11, [rsp+0xB0]
00007c47757d446c  vmovaps xmm13, [rsp+0xC0]
00007c47757d4475  vmovaps xmm14, [rsp+0xD0]
00007c47757d447e  vmovaps xmm15, [rsp+0xE0]
00007c47757d4487  add rsp, 0xF0
00007c47757d448e  pop r11
00007c47757d4490  pop r10
00007c47757d4492  pop r9
00007c47757d4494  pop r8
00007c47757d4496  pop rsi
00007c47757d4497  pop rdi
00007c47757d4498  pop rdx
00007c47757d4499  pop rcx
00007c47757d449a  pop rax
00007c47757d449b  add rsp, 0x08
00007c47757d449f  jmp 0x00007C47757D00F7
00007c47757d44a4  sub rsp, 0x08
00007c47757d44a8  push rax
00007c47757d44a9  push rcx
00007c47757d44aa  push rdx
00007c47757d44ab  push rdi
00007c47757d44ac  push rsi
00007c47757d44ad  push r8
00007c47757d44af  push r9
00007c47757d44b1  push r10
00007c47757d44b3  push r11
00007c47757d44b5  sub rsp, 0xF0
00007c47757d44bc  vmovaps [rsp], xmm0
00007c47757d44c1  vmovaps [rsp+0x10], xmm1
00007c47757d44c7  vmovaps [rsp+0x20], xmm2
00007c47757d44cd  vmovaps [rsp+0x30], xmm3
00007c47757d44d3  vmovaps [rsp+0x40], xmm4
00007c47757d44d9  vmovaps [rsp+0x50], xmm5
00007c47757d44df  vmovaps [rsp+0x60], xmm6
00007c47757d44e5  vmovaps [rsp+0x70], xmm7
00007c47757d44eb  vmovaps [rsp+0x80], xmm8
00007c47757d44f4  vmovaps [rsp+0x90], xmm9
00007c47757d44fd  vmovaps [rsp+0xA0], xmm10
00007c47757d4506  vmovaps [rsp+0xB0], xmm12
00007c47757d450f  vmovaps [rsp+0xC0], xmm13
00007c47757d4518  vmovaps [rsp+0xD0], xmm14
00007c47757d4521  vmovaps [rsp+0xE0], xmm15
00007c47757d452a  sub rsp, 0x30
00007c47757d452e  movaps [rsp], xmm11
00007c47757d4533  movaps [rsp+0x10], xmm7
00007c47757d4538  movaps [rsp+0x20], xmm15
00007c47757d453e  lea rdi, [rsp]
00007c47757d4542  mov esi, 0x00
00007c47757d4547  mov rax, 0x62084E409530
00007c47757d4551  call rax
00007c47757d4553  movaps xmm11, [rsp]
00007c47757d4558  add rsp, 0x30
00007c47757d455c  vmovaps xmm0, [rsp]
00007c47757d4561  vmovaps xmm1, [rsp+0x10]
00007c47757d4567  vmovaps xmm2, [rsp+0x20]
00007c47757d456d  vmovaps xmm3, [rsp+0x30]
00007c47757d4573  vmovaps xmm4, [rsp+0x40]
00007c47757d4579  vmovaps xmm5, [rsp+0x50]
00007c47757d457f  vmovaps xmm6, [rsp+0x60]
00007c47757d4585  vmovaps xmm7, [rsp+0x70]
00007c47757d458b  vmovaps xmm8, [rsp+0x80]
00007c47757d4594  vmovaps xmm9, [rsp+0x90]
00007c47757d459d  vmovaps xmm10, [rsp+0xA0]
00007c47757d45a6  vmovaps xmm12, [rsp+0xB0]
00007c47757d45af  vmovaps xmm13, [rsp+0xC0]
00007c47757d45b8  vmovaps xmm14, [rsp+0xD0]
00007c47757d45c1  vmovaps xmm15, [rsp+0xE0]
00007c47757d45ca  add rsp, 0xF0
00007c47757d45d1  pop r11
00007c47757d45d3  pop r10
00007c47757d45d5  pop r9
00007c47757d45d7  pop r8
00007c47757d45d9  pop rsi
00007c47757d45da  pop rdi
00007c47757d45db  pop rdx
00007c47757d45dc  pop rcx
00007c47757d45dd  pop rax
00007c47757d45de  add rsp, 0x08
00007c47757d45e2  jmp 0x00007C47757D0123
00007c47757d45e7  sub rsp, 0x08
00007c47757d45eb  push rax
00007c47757d45ec  push rcx
00007c47757d45ed  push rdx
00007c47757d45ee  push rdi
00007c47757d45ef  push rsi
00007c47757d45f0  push r8
00007c47757d45f2  push r9
00007c47757d45f4  push r10
00007c47757d45f6  push r11
00007c47757d45f8  sub rsp, 0xF0
00007c47757d45ff  vmovaps [rsp], xmm0
00007c47757d4604  vmovaps [rsp+0x10], xmm1
00007c47757d460a  vmovaps [rsp+0x20], xmm2
00007c47757d4610  vmovaps [rsp+0x30], xmm3
00007c47757d4616  vmovaps [rsp+0x40], xmm4
00007c47757d461c  vmovaps [rsp+0x50], xmm5
00007c47757d4622  vmovaps [rsp+0x60], xmm6
00007c47757d4628  vmovaps [rsp+0x70], xmm7
00007c47757d462e  vmovaps [rsp+0x80], xmm8
00007c47757d4637  vmovaps [rsp+0x90], xmm9
00007c47757d4640  vmovaps [rsp+0xA0], xmm10
00007c47757d4649  vmovaps [rsp+0xB0], xmm11
00007c47757d4652  vmovaps [rsp+0xC0], xmm12
00007c47757d465b  vmovaps [rsp+0xD0], xmm13
00007c47757d4664  vmovaps [rsp+0xE0], xmm14
00007c47757d466d  sub rsp, 0x30
00007c47757d4671  movaps [rsp], xmm15
00007c47757d4676  movaps [rsp+0x10], xmm10
00007c47757d467c  movaps [rsp+0x20], xmm13
00007c47757d4682  lea rdi, [rsp]
00007c47757d4686  mov esi, 0x00
00007c47757d468b  mov rax, 0x62084E409530
00007c47757d4695  call rax
00007c47757d4697  movaps xmm15, [rsp]
00007c47757d469c  add rsp, 0x30
00007c47757d46a0  vmovaps xmm0, [rsp]
00007c47757d46a5  vmovaps xmm1, [rsp+0x10]
00007c47757d46ab  vmovaps xmm2, [rsp+0x20]
00007c47757d46b1  vmovaps xmm3, [rsp+0x30]
00007c47757d46b7  vmovaps xmm4, [rsp+0x40]
00007c47757d46bd  vmovaps xmm5, [rsp+0x50]
00007c47757d46c3  vmovaps xmm6, [rsp+0x60]
00007c47757d46c9  vmovaps xmm7, [rsp+0x70]
00007c47757d46cf  vmovaps xmm8, [rsp+0x80]
00007c47757d46d8  vmovaps xmm9, [rsp+0x90]
00007c47757d46e1  vmovaps xmm10, [rsp+0xA0]
00007c47757d46ea  vmovaps xmm11, [rsp+0xB0]
00007c47757d46f3  vmovaps xmm12, [rsp+0xC0]
00007c47757d46fc  vmovaps xmm13, [rsp+0xD0]
00007c47757d4705  vmovaps xmm14, [rsp+0xE0]
00007c47757d470e  add rsp, 0xF0
00007c47757d4715  pop r11
00007c47757d4717  pop r10
00007c47757d4719  pop r9
00007c47757d471b  pop r8
00007c47757d471d  pop rsi
00007c47757d471e  pop rdi
00007c47757d471f  pop rdx
00007c47757d4720  pop rcx
00007c47757d4721  pop rax
00007c47757d4722  add rsp, 0x08
00007c47757d4726  jmp 0x00007C47757D013D
00007c47757d472b  sub rsp, 0x08
00007c47757d472f  push rax
00007c47757d4730  push rcx
00007c47757d4731  push rdx
00007c47757d4732  push rdi
00007c47757d4733  push rsi
00007c47757d4734  push r8
00007c47757d4736  push r9
00007c47757d4738  push r10
00007c47757d473a  push r11
00007c47757d473c  sub rsp, 0xF0
00007c47757d4743  vmovaps [rsp], xmm0
00007c47757d4748  vmovaps [rsp+0x10], xmm1
00007c47757d474e  vmovaps [rsp+0x20], xmm2
00007c47757d4754  vmovaps [rsp+0x30], xmm3
00007c47757d475a  vmovaps [rsp+0x40], xmm4
00007c47757d4760  vmovaps [rsp+0x50], xmm5
00007c47757d4766  vmovaps [rsp+0x60], xmm6
00007c47757d476c  vmovaps [rsp+0x70], xmm7
00007c47757d4772  vmovaps [rsp+0x80], xmm8
00007c47757d477b  vmovaps [rsp+0x90], xmm9
00007c47757d4784  vmovaps [rsp+0xA0], xmm11
00007c47757d478d  vmovaps [rsp+0xB0], xmm12
00007c47757d4796  vmovaps [rsp+0xC0], xmm13
00007c47757d479f  vmovaps [rsp+0xD0], xmm14
00007c47757d47a8  vmovaps [rsp+0xE0], xmm15
00007c47757d47b1  sub rsp, 0x30
00007c47757d47b5  movaps [rsp], xmm10
00007c47757d47ba  movaps [rsp+0x10], xmm7
00007c47757d47bf  movaps [rsp+0x20], xmm13
00007c47757d47c5  lea rdi, [rsp]
00007c47757d47c9  mov esi, 0x00
00007c47757d47ce  mov rax, 0x62084E409530
00007c47757d47d8  call rax
00007c47757d47da  movaps xmm10, [rsp]
00007c47757d47df  add rsp, 0x30
00007c47757d47e3  vmovaps xmm0, [rsp]
00007c47757d47e8  vmovaps xmm1, [rsp+0x10]
00007c47757d47ee  vmovaps xmm2, [rsp+0x20]
00007c47757d47f4  vmovaps xmm3, [rsp+0x30]
00007c47757d47fa  vmovaps xmm4, [rsp+0x40]
00007c47757d4800  vmovaps xmm5, [rsp+0x50]
00007c47757d4806  vmovaps xmm6, [rsp+0x60]
00007c47757d480c  vmovaps xmm7, [rsp+0x70]
00007c47757d4812  vmovaps xmm8, [rsp+0x80]
00007c47757d481b  vmovaps xmm9, [rsp+0x90]
00007c47757d4824  vmovaps xmm11, [rsp+0xA0]
00007c47757d482d  vmovaps xmm12, [rsp+0xB0]
00007c47757d4836  vmovaps xmm13, [rsp+0xC0]
00007c47757d483f  vmovaps xmm14, [rsp+0xD0]
00007c47757d4848  vmovaps xmm15, [rsp+0xE0]
00007c47757d4851  add rsp, 0xF0
00007c47757d4858  pop r11
00007c47757d485a  pop r10
00007c47757d485c  pop r9
00007c47757d485e  pop r8
00007c47757d4860  pop rsi
00007c47757d4861  pop rdi
00007c47757d4862  pop rdx
00007c47757d4863  pop rcx
00007c47757d4864  pop rax
00007c47757d4865  add rsp, 0x08
00007c47757d4869  jmp 0x00007C47757D0169
00007c47757d486e  sub rsp, 0x08
00007c47757d4872  push rax
00007c47757d4873  push rcx
00007c47757d4874  push rdx
00007c47757d4875  push rdi
00007c47757d4876  push rsi
00007c47757d4877  push r8
00007c47757d4879  push r9
00007c47757d487b  push r10
00007c47757d487d  push r11
00007c47757d487f  sub rsp, 0xF0
00007c47757d4886  vmovaps [rsp], xmm0
00007c47757d488b  vmovaps [rsp+0x10], xmm1
00007c47757d4891  vmovaps [rsp+0x20], xmm2
00007c47757d4897  vmovaps [rsp+0x30], xmm3
00007c47757d489d  vmovaps [rsp+0x40], xmm4
00007c47757d48a3  vmovaps [rsp+0x50], xmm5
00007c47757d48a9  vmovaps [rsp+0x60], xmm6
00007c47757d48af  vmovaps [rsp+0x70], xmm7
00007c47757d48b5  vmovaps [rsp+0x80], xmm8
00007c47757d48be  vmovaps [rsp+0x90], xmm9
00007c47757d48c7  vmovaps [rsp+0xA0], xmm10
00007c47757d48d0  vmovaps [rsp+0xB0], xmm11
00007c47757d48d9  vmovaps [rsp+0xC0], xmm12
00007c47757d48e2  vmovaps [rsp+0xD0], xmm14
00007c47757d48eb  vmovaps [rsp+0xE0], xmm15
00007c47757d48f4  sub rsp, 0x30
00007c47757d48f8  movaps [rsp], xmm13
00007c47757d48fd  movaps [rsp+0x10], xmm1
00007c47757d4902  movaps [rsp+0x20], xmm8
00007c47757d4908  lea rdi, [rsp]
00007c47757d490c  mov esi, 0x00
00007c47757d4911  mov rax, 0x62084E409530
00007c47757d491b  call rax
00007c47757d491d  movaps xmm13, [rsp]
00007c47757d4922  add rsp, 0x30
00007c47757d4926  vmovaps xmm0, [rsp]
00007c47757d492b  vmovaps xmm1, [rsp+0x10]
00007c47757d4931  vmovaps xmm2, [rsp+0x20]
00007c47757d4937  vmovaps xmm3, [rsp+0x30]
00007c47757d493d  vmovaps xmm4, [rsp+0x40]
00007c47757d4943  vmovaps xmm5, [rsp+0x50]
00007c47757d4949  vmovaps xmm6, [rsp+0x60]
00007c47757d494f  vmovaps xmm7, [rsp+0x70]
00007c47757d4955  vmovaps xmm8, [rsp+0x80]
00007c47757d495e  vmovaps xmm9, [rsp+0x90]
00007c47757d4967  vmovaps xmm10, [rsp+0xA0]
00007c47757d4970  vmovaps xmm11, [rsp+0xB0]
00007c47757d4979  vmovaps xmm12, [rsp+0xC0]
00007c47757d4982  vmovaps xmm14, [rsp+0xD0]
00007c47757d498b  vmovaps xmm15, [rsp+0xE0]
00007c47757d4994  add rsp, 0xF0
00007c47757d499b  pop r11
00007c47757d499d  pop r10
00007c47757d499f  pop r9
00007c47757d49a1  pop r8
00007c47757d49a3  pop rsi
00007c47757d49a4  pop rdi
00007c47757d49a5  pop rdx
00007c47757d49a6  pop rcx
00007c47757d49a7  pop rax
00007c47757d49a8  add rsp, 0x08
00007c47757d49ac  jmp 0x00007C47757D0183
00007c47757d49b1  call 0x00007C47755FF430
00007c47757d49b6  jmp 0x00007C47757D018D
00007c47757d49bb  sub rsp, 0x08
00007c47757d49bf  push rax
00007c47757d49c0  push rcx
00007c47757d49c1  push rdx
00007c47757d49c2  push rdi
00007c47757d49c3  push rsi
00007c47757d49c4  push r8
00007c47757d49c6  push r9
00007c47757d49c8  push r10
00007c47757d49ca  push r11
00007c47757d49cc  sub rsp, 0xF0
00007c47757d49d3  vmovaps [rsp], xmm0
00007c47757d49d8  vmovaps [rsp+0x10], xmm1
00007c47757d49de  vmovaps [rsp+0x20], xmm2
00007c47757d49e4  vmovaps [rsp+0x30], xmm3
00007c47757d49ea  vmovaps [rsp+0x40], xmm4
00007c47757d49f0  vmovaps [rsp+0x50], xmm5
00007c47757d49f6  vmovaps [rsp+0x60], xmm6
00007c47757d49fc  vmovaps [rsp+0x70], xmm7
00007c47757d4a02  vmovaps [rsp+0x80], xmm9
00007c47757d4a0b  vmovaps [rsp+0x90], xmm10
00007c47757d4a14  vmovaps [rsp+0xA0], xmm11
00007c47757d4a1d  vmovaps [rsp+0xB0], xmm12
00007c47757d4a26  vmovaps [rsp+0xC0], xmm13
00007c47757d4a2f  vmovaps [rsp+0xD0], xmm14
00007c47757d4a38  vmovaps [rsp+0xE0], xmm15
00007c47757d4a41  sub rsp, 0x30
00007c47757d4a45  movaps [rsp], xmm8
00007c47757d4a4a  movaps [rsp+0x10], xmm14
00007c47757d4a50  movaps [rsp+0x20], xmm9
00007c47757d4a56  lea rdi, [rsp]
00007c47757d4a5a  mov esi, 0x00
00007c47757d4a5f  mov rax, 0x62084E409530
00007c47757d4a69  call rax
00007c47757d4a6b  movaps xmm8, [rsp]
00007c47757d4a70  add rsp, 0x30
00007c47757d4a74  vmovaps xmm0, [rsp]
00007c47757d4a79  vmovaps xmm1, [rsp+0x10]
00007c47757d4a7f  vmovaps xmm2, [rsp+0x20]
00007c47757d4a85  vmovaps xmm3, [rsp+0x30]
00007c47757d4a8b  vmovaps xmm4, [rsp+0x40]
00007c47757d4a91  vmovaps xmm5, [rsp+0x50]
00007c47757d4a97  vmovaps xmm6, [rsp+0x60]
00007c47757d4a9d  vmovaps xmm7, [rsp+0x70]
00007c47757d4aa3  vmovaps xmm9, [rsp+0x80]
00007c47757d4aac  vmovaps xmm10, [rsp+0x90]
00007c47757d4ab5  vmovaps xmm11, [rsp+0xA0]
00007c47757d4abe  vmovaps xmm12, [rsp+0xB0]
00007c47757d4ac7  vmovaps xmm13, [rsp+0xC0]
00007c47757d4ad0  vmovaps xmm14, [rsp+0xD0]
00007c47757d4ad9  vmovaps xmm15, [rsp+0xE0]
00007c47757d4ae2  add rsp, 0xF0
00007c47757d4ae9  pop r11
00007c47757d4aeb  pop r10
00007c47757d4aed  pop r9
00007c47757d4aef  pop r8
00007c47757d4af1  pop rsi
00007c47757d4af2  pop rdi
00007c47757d4af3  pop rdx
00007c47757d4af4  pop rcx
00007c47757d4af5  pop rax
00007c47757d4af6  add rsp, 0x08
00007c47757d4afa  jmp 0x00007C47757D01AF
00007c47757d4aff  sub rsp, 0x08
00007c47757d4b03  push rax
00007c47757d4b04  push rcx
00007c47757d4b05  push rdx
00007c47757d4b06  push rdi
00007c47757d4b07  push rsi
00007c47757d4b08  push r8
00007c47757d4b0a  push r9
00007c47757d4b0c  push r10
00007c47757d4b0e  push r11
00007c47757d4b10  sub rsp, 0xF0
00007c47757d4b17  vmovaps [rsp], xmm0
00007c47757d4b1c  vmovaps [rsp+0x10], xmm1
00007c47757d4b22  vmovaps [rsp+0x20], xmm2
00007c47757d4b28  vmovaps [rsp+0x30], xmm3
00007c47757d4b2e  vmovaps [rsp+0x40], xmm4
00007c47757d4b34  vmovaps [rsp+0x50], xmm5
00007c47757d4b3a  vmovaps [rsp+0x60], xmm6
00007c47757d4b40  vmovaps [rsp+0x70], xmm7
00007c47757d4b46  vmovaps [rsp+0x80], xmm8
00007c47757d4b4f  vmovaps [rsp+0x90], xmm10
00007c47757d4b58  vmovaps [rsp+0xA0], xmm11
00007c47757d4b61  vmovaps [rsp+0xB0], xmm12
00007c47757d4b6a  vmovaps [rsp+0xC0], xmm13
00007c47757d4b73  vmovaps [rsp+0xD0], xmm14
00007c47757d4b7c  vmovaps [rsp+0xE0], xmm15
00007c47757d4b85  sub rsp, 0x30
00007c47757d4b89  movaps [rsp], xmm9
00007c47757d4b8e  movaps [rsp+0x10], xmm1
00007c47757d4b93  movaps [rsp+0x20], xmm14
00007c47757d4b99  lea rdi, [rsp]
00007c47757d4b9d  mov esi, 0x00
00007c47757d4ba2  mov rax, 0x62084E409530
00007c47757d4bac  call rax
00007c47757d4bae  movaps xmm9, [rsp]
00007c47757d4bb3  add rsp, 0x30
00007c47757d4bb7  vmovaps xmm0, [rsp]
00007c47757d4bbc  vmovaps xmm1, [rsp+0x10]
00007c47757d4bc2  vmovaps xmm2, [rsp+0x20]
00007c47757d4bc8  vmovaps xmm3, [rsp+0x30]
00007c47757d4bce  vmovaps xmm4, [rsp+0x40]
00007c47757d4bd4  vmovaps xmm5, [rsp+0x50]
00007c47757d4bda  vmovaps xmm6, [rsp+0x60]
00007c47757d4be0  vmovaps xmm7, [rsp+0x70]
00007c47757d4be6  vmovaps xmm8, [rsp+0x80]
00007c47757d4bef  vmovaps xmm10, [rsp+0x90]
00007c47757d4bf8  vmovaps xmm11, [rsp+0xA0]
00007c47757d4c01  vmovaps xmm12, [rsp+0xB0]
00007c47757d4c0a  vmovaps xmm13, [rsp+0xC0]
00007c47757d4c13  vmovaps xmm14, [rsp+0xD0]
00007c47757d4c1c  vmovaps xmm15, [rsp+0xE0]
00007c47757d4c25  add rsp, 0xF0
00007c47757d4c2c  pop r11
00007c47757d4c2e  pop r10
00007c47757d4c30  pop r9
00007c47757d4c32  pop r8
00007c47757d4c34  pop rsi
00007c47757d4c35  pop rdi
00007c47757d4c36  pop rdx
00007c47757d4c37  pop rcx
00007c47757d4c38  pop rax
00007c47757d4c39  add rsp, 0x08
00007c47757d4c3d  jmp 0x00007C47757D01DD
00007c47757d4c42  sub rsp, 0x08
00007c47757d4c46  push rax
00007c47757d4c47  push rcx
00007c47757d4c48  push rdx
00007c47757d4c49  push rdi
00007c47757d4c4a  push rsi
00007c47757d4c4b  push r8
00007c47757d4c4d  push r9
00007c47757d4c4f  push r10
00007c47757d4c51  push r11
00007c47757d4c53  sub rsp, 0xF0
00007c47757d4c5a  vmovaps [rsp], xmm0
00007c47757d4c5f  vmovaps [rsp+0x10], xmm1
00007c47757d4c65  vmovaps [rsp+0x20], xmm2
00007c47757d4c6b  vmovaps [rsp+0x30], xmm3
00007c47757d4c71  vmovaps [rsp+0x40], xmm4
00007c47757d4c77  vmovaps [rsp+0x50], xmm5
00007c47757d4c7d  vmovaps [rsp+0x60], xmm6
00007c47757d4c83  vmovaps [rsp+0x70], xmm7
00007c47757d4c89  vmovaps [rsp+0x80], xmm8
00007c47757d4c92  vmovaps [rsp+0x90], xmm9
00007c47757d4c9b  vmovaps [rsp+0xA0], xmm10
00007c47757d4ca4  vmovaps [rsp+0xB0], xmm11
00007c47757d4cad  vmovaps [rsp+0xC0], xmm12
00007c47757d4cb6  vmovaps [rsp+0xD0], xmm13
00007c47757d4cbf  vmovaps [rsp+0xE0], xmm15
00007c47757d4cc8  sub rsp, 0x30
00007c47757d4ccc  movaps [rsp], xmm14
00007c47757d4cd1  movaps [rsp+0x10], xmm4
00007c47757d4cd6  movaps [rsp+0x20], xmm1
00007c47757d4cdb  lea rdi, [rsp]
00007c47757d4cdf  mov esi, 0x00
00007c47757d4ce4  mov rax, 0x62084E409530
00007c47757d4cee  call rax
00007c47757d4cf0  movaps xmm14, [rsp]
00007c47757d4cf5  add rsp, 0x30
00007c47757d4cf9  vmovaps xmm0, [rsp]
00007c47757d4cfe  vmovaps xmm1, [rsp+0x10]
00007c47757d4d04  vmovaps xmm2, [rsp+0x20]
00007c47757d4d0a  vmovaps xmm3, [rsp+0x30]
00007c47757d4d10  vmovaps xmm4, [rsp+0x40]
00007c47757d4d16  vmovaps xmm5, [rsp+0x50]
00007c47757d4d1c  vmovaps xmm6, [rsp+0x60]
00007c47757d4d22  vmovaps xmm7, [rsp+0x70]
00007c47757d4d28  vmovaps xmm8, [rsp+0x80]
00007c47757d4d31  vmovaps xmm9, [rsp+0x90]
00007c47757d4d3a  vmovaps xmm10, [rsp+0xA0]
00007c47757d4d43  vmovaps xmm11, [rsp+0xB0]
00007c47757d4d4c  vmovaps xmm12, [rsp+0xC0]
00007c47757d4d55  vmovaps xmm13, [rsp+0xD0]
00007c47757d4d5e  vmovaps xmm15, [rsp+0xE0]
00007c47757d4d67  add rsp, 0xF0
00007c47757d4d6e  pop r11
00007c47757d4d70  pop r10
00007c47757d4d72  pop r9
00007c47757d4d74  pop r8
00007c47757d4d76  pop rsi
00007c47757d4d77  pop rdi
00007c47757d4d78  pop rdx
00007c47757d4d79  pop rcx
00007c47757d4d7a  pop rax
00007c47757d4d7b  add rsp, 0x08
00007c47757d4d7f  jmp 0x00007C47757D0203
00007c47757d4d84  sub rsp, 0x08
00007c47757d4d88  push rax
00007c47757d4d89  push rcx
00007c47757d4d8a  push rdx
00007c47757d4d8b  push rdi
00007c47757d4d8c  push rsi
00007c47757d4d8d  push r8
00007c47757d4d8f  push r9
00007c47757d4d91  push r10
00007c47757d4d93  push r11
00007c47757d4d95  sub rsp, 0xF0
00007c47757d4d9c  vmovaps [rsp], xmm0
00007c47757d4da1  vmovaps [rsp+0x10], xmm2
00007c47757d4da7  vmovaps [rsp+0x20], xmm3
00007c47757d4dad  vmovaps [rsp+0x30], xmm4
00007c47757d4db3  vmovaps [rsp+0x40], xmm5
00007c47757d4db9  vmovaps [rsp+0x50], xmm6
00007c47757d4dbf  vmovaps [rsp+0x60], xmm7
00007c47757d4dc5  vmovaps [rsp+0x70], xmm8
00007c47757d4dcb  vmovaps [rsp+0x80], xmm9
00007c47757d4dd4  vmovaps [rsp+0x90], xmm10
00007c47757d4ddd  vmovaps [rsp+0xA0], xmm11
00007c47757d4de6  vmovaps [rsp+0xB0], xmm12
00007c47757d4def  vmovaps [rsp+0xC0], xmm13
00007c47757d4df8  vmovaps [rsp+0xD0], xmm14
00007c47757d4e01  vmovaps [rsp+0xE0], xmm15
00007c47757d4e0a  sub rsp, 0x30
00007c47757d4e0e  movaps [rsp], xmm1
00007c47757d4e12  movaps [rsp+0x10], xmm12
00007c47757d4e18  movaps [rsp+0x20], xmm11
00007c47757d4e1e  lea rdi, [rsp]
00007c47757d4e22  mov esi, 0x00
00007c47757d4e27  mov rax, 0x62084E409530
00007c47757d4e31  call rax
00007c47757d4e33  movaps xmm1, [rsp]
00007c47757d4e37  add rsp, 0x30
00007c47757d4e3b  vmovaps xmm0, [rsp]
00007c47757d4e40  vmovaps xmm2, [rsp+0x10]
00007c47757d4e46  vmovaps xmm3, [rsp+0x20]
00007c47757d4e4c  vmovaps xmm4, [rsp+0x30]
00007c47757d4e52  vmovaps xmm5, [rsp+0x40]
00007c47757d4e58  vmovaps xmm6, [rsp+0x50]
00007c47757d4e5e  vmovaps xmm7, [rsp+0x60]
00007c47757d4e64  vmovaps xmm8, [rsp+0x70]
00007c47757d4e6a  vmovaps xmm9, [rsp+0x80]
00007c47757d4e73  vmovaps xmm10, [rsp+0x90]
00007c47757d4e7c  vmovaps xmm11, [rsp+0xA0]
00007c47757d4e85  vmovaps xmm12, [rsp+0xB0]
00007c47757d4e8e  vmovaps xmm13, [rsp+0xC0]
00007c47757d4e97  vmovaps xmm14, [rsp+0xD0]
00007c47757d4ea0  vmovaps xmm15, [rsp+0xE0]
00007c47757d4ea9  add rsp, 0xF0
00007c47757d4eb0  pop r11
00007c47757d4eb2  pop r10
00007c47757d4eb4  pop r9
00007c47757d4eb6  pop r8
00007c47757d4eb8  pop rsi
00007c47757d4eb9  pop rdi
00007c47757d4eba  pop rdx
00007c47757d4ebb  pop rcx
00007c47757d4ebc  pop rax
00007c47757d4ebd  add rsp, 0x08
00007c47757d4ec1  jmp 0x00007C47757D0224
00007c47757d4ec6  call 0x00007C47756E20A0
00007c47757d4ecb  jmp 0x00007C47757D0232
00007c47757d4ed0  call 0x00007C4775609D70
00007c47757d4ed5  jmp 0x00007C47757D023C
00007c47757d4eda  sub rsp, 0x08
00007c47757d4ede  push rax
00007c47757d4edf  push rcx
00007c47757d4ee0  push rdx
00007c47757d4ee1  push rdi
00007c47757d4ee2  push rsi
00007c47757d4ee3  push r8
00007c47757d4ee5  push r9
00007c47757d4ee7  push r10
00007c47757d4ee9  push r11
00007c47757d4eeb  sub rsp, 0xF0
00007c47757d4ef2  vmovaps [rsp], xmm0
00007c47757d4ef7  vmovaps [rsp+0x10], xmm1
00007c47757d4efd  vmovaps [rsp+0x20], xmm2
00007c47757d4f03  vmovaps [rsp+0x30], xmm3
00007c47757d4f09  vmovaps [rsp+0x40], xmm4
00007c47757d4f0f  vmovaps [rsp+0x50], xmm5
00007c47757d4f15  vmovaps [rsp+0x60], xmm6
00007c47757d4f1b  vmovaps [rsp+0x70], xmm8
00007c47757d4f21  vmovaps [rsp+0x80], xmm9
00007c47757d4f2a  vmovaps [rsp+0x90], xmm10
00007c47757d4f33  vmovaps [rsp+0xA0], xmm11
00007c47757d4f3c  vmovaps [rsp+0xB0], xmm12
00007c47757d4f45  vmovaps [rsp+0xC0], xmm13
00007c47757d4f4e  vmovaps [rsp+0xD0], xmm14
00007c47757d4f57  vmovaps [rsp+0xE0], xmm15
00007c47757d4f60  sub rsp, 0x30
00007c47757d4f64  movaps [rsp], xmm7
00007c47757d4f68  movaps [rsp+0x10], xmm15
00007c47757d4f6e  movaps [rsp+0x20], xmm10
00007c47757d4f74  lea rdi, [rsp]
00007c47757d4f78  mov esi, 0x00
00007c47757d4f7d  mov rax, 0x62084E409530
00007c47757d4f87  call rax
00007c47757d4f89  movaps xmm7, [rsp]
00007c47757d4f8d  add rsp, 0x30
00007c47757d4f91  vmovaps xmm0, [rsp]
00007c47757d4f96  vmovaps xmm1, [rsp+0x10]
00007c47757d4f9c  vmovaps xmm2, [rsp+0x20]
00007c47757d4fa2  vmovaps xmm3, [rsp+0x30]
00007c47757d4fa8  vmovaps xmm4, [rsp+0x40]
00007c47757d4fae  vmovaps xmm5, [rsp+0x50]
00007c47757d4fb4  vmovaps xmm6, [rsp+0x60]
00007c47757d4fba  vmovaps xmm8, [rsp+0x70]
00007c47757d4fc0  vmovaps xmm9, [rsp+0x80]
00007c47757d4fc9  vmovaps xmm10, [rsp+0x90]
00007c47757d4fd2  vmovaps xmm11, [rsp+0xA0]
00007c47757d4fdb  vmovaps xmm12, [rsp+0xB0]
00007c47757d4fe4  vmovaps xmm13, [rsp+0xC0]
00007c47757d4fed  vmovaps xmm14, [rsp+0xD0]
00007c47757d4ff6  vmovaps xmm15, [rsp+0xE0]
00007c47757d4fff  add rsp, 0xF0
00007c47757d5006  pop r11
00007c47757d5008  pop r10
00007c47757d500a  pop r9
00007c47757d500c  pop r8
00007c47757d500e  pop rsi
00007c47757d500f  pop rdi
00007c47757d5010  pop rdx
00007c47757d5011  pop rcx
00007c47757d5012  pop rax
00007c47757d5013  add rsp, 0x08
00007c47757d5017  jmp 0x00007C47757D025D
00007c47757d501c  sub rsp, 0x08
00007c47757d5020  push rax
00007c47757d5021  push rcx
00007c47757d5022  push rdx
00007c47757d5023  push rdi
00007c47757d5024  push rsi
00007c47757d5025  push r8
00007c47757d5027  push r9
00007c47757d5029  push r10
00007c47757d502b  push r11
00007c47757d502d  sub rsp, 0xF0
00007c47757d5034  vmovaps [rsp], xmm0
00007c47757d5039  vmovaps [rsp+0x10], xmm1
00007c47757d503f  vmovaps [rsp+0x20], xmm2
00007c47757d5045  vmovaps [rsp+0x30], xmm3
00007c47757d504b  vmovaps [rsp+0x40], xmm4
00007c47757d5051  vmovaps [rsp+0x50], xmm5
00007c47757d5057  vmovaps [rsp+0x60], xmm6
00007c47757d505d  vmovaps [rsp+0x70], xmm7
00007c47757d5063  vmovaps [rsp+0x80], xmm8
00007c47757d506c  vmovaps [rsp+0x90], xmm9
00007c47757d5075  vmovaps [rsp+0xA0], xmm11
00007c47757d507e  vmovaps [rsp+0xB0], xmm12
00007c47757d5087  vmovaps [rsp+0xC0], xmm13
00007c47757d5090  vmovaps [rsp+0xD0], xmm14
00007c47757d5099  vmovaps [rsp+0xE0], xmm15
00007c47757d50a2  sub rsp, 0x30
00007c47757d50a6  movaps [rsp], xmm10
00007c47757d50ab  movaps [rsp+0x10], xmm11
00007c47757d50b1  movaps [rsp+0x20], xmm15
00007c47757d50b7  lea rdi, [rsp]
00007c47757d50bb  mov esi, 0x00
00007c47757d50c0  mov rax, 0x62084E409530
00007c47757d50ca  call rax
00007c47757d50cc  movaps xmm10, [rsp]
00007c47757d50d1  add rsp, 0x30
00007c47757d50d5  vmovaps xmm0, [rsp]
00007c47757d50da  vmovaps xmm1, [rsp+0x10]
00007c47757d50e0  vmovaps xmm2, [rsp+0x20]
00007c47757d50e6  vmovaps xmm3, [rsp+0x30]
00007c47757d50ec  vmovaps xmm4, [rsp+0x40]
00007c47757d50f2  vmovaps xmm5, [rsp+0x50]
00007c47757d50f8  vmovaps xmm6, [rsp+0x60]
00007c47757d50fe  vmovaps xmm7, [rsp+0x70]
00007c47757d5104  vmovaps xmm8, [rsp+0x80]
00007c47757d510d  vmovaps xmm9, [rsp+0x90]
00007c47757d5116  vmovaps xmm11, [rsp+0xA0]
00007c47757d511f  vmovaps xmm12, [rsp+0xB0]
00007c47757d5128  vmovaps xmm13, [rsp+0xC0]
00007c47757d5131  vmovaps xmm14, [rsp+0xD0]
00007c47757d513a  vmovaps xmm15, [rsp+0xE0]
00007c47757d5143  add rsp, 0xF0
00007c47757d514a  pop r11
00007c47757d514c  pop r10
00007c47757d514e  pop r9
00007c47757d5150  pop r8
00007c47757d5152  pop rsi
00007c47757d5153  pop rdi
00007c47757d5154  pop rdx
00007c47757d5155  pop rcx
00007c47757d5156  pop rax
00007c47757d5157  add rsp, 0x08
00007c47757d515b  jmp 0x00007C47757D028B
00007c47757d5160  sub rsp, 0x08
00007c47757d5164  push rax
00007c47757d5165  push rcx
00007c47757d5166  push rdx
00007c47757d5167  push rdi
00007c47757d5168  push rsi
00007c47757d5169  push r8
00007c47757d516b  push r9
00007c47757d516d  push r10
00007c47757d516f  push r11
00007c47757d5171  sub rsp, 0xF0
00007c47757d5178  vmovaps [rsp], xmm0
00007c47757d517d  vmovaps [rsp+0x10], xmm1
00007c47757d5183  vmovaps [rsp+0x20], xmm2
00007c47757d5189  vmovaps [rsp+0x30], xmm3
00007c47757d518f  vmovaps [rsp+0x40], xmm4
00007c47757d5195  vmovaps [rsp+0x50], xmm5
00007c47757d519b  vmovaps [rsp+0x60], xmm6
00007c47757d51a1  vmovaps [rsp+0x70], xmm7
00007c47757d51a7  vmovaps [rsp+0x80], xmm8
00007c47757d51b0  vmovaps [rsp+0x90], xmm9
00007c47757d51b9  vmovaps [rsp+0xA0], xmm10
00007c47757d51c2  vmovaps [rsp+0xB0], xmm12
00007c47757d51cb  vmovaps [rsp+0xC0], xmm13
00007c47757d51d4  vmovaps [rsp+0xD0], xmm14
00007c47757d51dd  vmovaps [rsp+0xE0], xmm15
00007c47757d51e6  sub rsp, 0x30
00007c47757d51ea  movaps [rsp], xmm11
00007c47757d51ef  movaps [rsp+0x10], xmm12
00007c47757d51f5  movaps [rsp+0x20], xmm15
00007c47757d51fb  lea rdi, [rsp]
00007c47757d51ff  mov esi, 0x00
00007c47757d5204  mov rax, 0x62084E409530
00007c47757d520e  call rax
00007c47757d5210  movaps xmm11, [rsp]
00007c47757d5215  add rsp, 0x30
00007c47757d5219  vmovaps xmm0, [rsp]
00007c47757d521e  vmovaps xmm1, [rsp+0x10]
00007c47757d5224  vmovaps xmm2, [rsp+0x20]
00007c47757d522a  vmovaps xmm3, [rsp+0x30]
00007c47757d5230  vmovaps xmm4, [rsp+0x40]
00007c47757d5236  vmovaps xmm5, [rsp+0x50]
00007c47757d523c  vmovaps xmm6, [rsp+0x60]
00007c47757d5242  vmovaps xmm7, [rsp+0x70]
00007c47757d5248  vmovaps xmm8, [rsp+0x80]
00007c47757d5251  vmovaps xmm9, [rsp+0x90]
00007c47757d525a  vmovaps xmm10, [rsp+0xA0]
00007c47757d5263  vmovaps xmm12, [rsp+0xB0]
00007c47757d526c  vmovaps xmm13, [rsp+0xC0]
00007c47757d5275  vmovaps xmm14, [rsp+0xD0]
00007c47757d527e  vmovaps xmm15, [rsp+0xE0]
00007c47757d5287  add rsp, 0xF0
00007c47757d528e  pop r11
00007c47757d5290  pop r10
00007c47757d5292  pop r9
00007c47757d5294  pop r8
00007c47757d5296  pop rsi
00007c47757d5297  pop rdi
00007c47757d5298  pop rdx
00007c47757d5299  pop rcx
00007c47757d529a  pop rax
00007c47757d529b  add rsp, 0x08
00007c47757d529f  jmp 0x00007C47757D02B9
00007c47757d52a4  sub rsp, 0x08
00007c47757d52a8  push rax
00007c47757d52a9  push rcx
00007c47757d52aa  push rdx
00007c47757d52ab  push rdi
00007c47757d52ac  push rsi
00007c47757d52ad  push r8
00007c47757d52af  push r9
00007c47757d52b1  push r10
00007c47757d52b3  push r11
00007c47757d52b5  sub rsp, 0xF0
00007c47757d52bc  vmovaps [rsp], xmm0
00007c47757d52c1  vmovaps [rsp+0x10], xmm1
00007c47757d52c7  vmovaps [rsp+0x20], xmm2
00007c47757d52cd  vmovaps [rsp+0x30], xmm3
00007c47757d52d3  vmovaps [rsp+0x40], xmm4
00007c47757d52d9  vmovaps [rsp+0x50], xmm5
00007c47757d52df  vmovaps [rsp+0x60], xmm6
00007c47757d52e5  vmovaps [rsp+0x70], xmm7
00007c47757d52eb  vmovaps [rsp+0x80], xmm8
00007c47757d52f4  vmovaps [rsp+0x90], xmm9
00007c47757d52fd  vmovaps [rsp+0xA0], xmm10
00007c47757d5306  vmovaps [rsp+0xB0], xmm11
00007c47757d530f  vmovaps [rsp+0xC0], xmm12
00007c47757d5318  vmovaps [rsp+0xD0], xmm13
00007c47757d5321  vmovaps [rsp+0xE0], xmm14
00007c47757d532a  sub rsp, 0x30
00007c47757d532e  movaps [rsp], xmm15
00007c47757d5333  movaps [rsp+0x10], xmm13
00007c47757d5339  movaps [rsp+0x20], xmm9
00007c47757d533f  lea rdi, [rsp]
00007c47757d5343  mov esi, 0x00
00007c47757d5348  mov rax, 0x62084E409530
00007c47757d5352  call rax
00007c47757d5354  movaps xmm15, [rsp]
00007c47757d5359  add rsp, 0x30
00007c47757d535d  vmovaps xmm0, [rsp]
00007c47757d5362  vmovaps xmm1, [rsp+0x10]
00007c47757d5368  vmovaps xmm2, [rsp+0x20]
00007c47757d536e  vmovaps xmm3, [rsp+0x30]
00007c47757d5374  vmovaps xmm4, [rsp+0x40]
00007c47757d537a  vmovaps xmm5, [rsp+0x50]
00007c47757d5380  vmovaps xmm6, [rsp+0x60]
00007c47757d5386  vmovaps xmm7, [rsp+0x70]
00007c47757d538c  vmovaps xmm8, [rsp+0x80]
00007c47757d5395  vmovaps xmm9, [rsp+0x90]
00007c47757d539e  vmovaps xmm10, [rsp+0xA0]
00007c47757d53a7  vmovaps xmm11, [rsp+0xB0]
00007c47757d53b0  vmovaps xmm12, [rsp+0xC0]
00007c47757d53b9  vmovaps xmm13, [rsp+0xD0]
00007c47757d53c2  vmovaps xmm14, [rsp+0xE0]
00007c47757d53cb  add rsp, 0xF0
00007c47757d53d2  pop r11
00007c47757d53d4  pop r10
00007c47757d53d6  pop r9
00007c47757d53d8  pop r8
00007c47757d53da  pop rsi
00007c47757d53db  pop rdi
00007c47757d53dc  pop rdx
00007c47757d53dd  pop rcx
00007c47757d53de  pop rax
00007c47757d53df  add rsp, 0x08
00007c47757d53e3  jmp 0x00007C47757D02D4
00007c47757d53e8  sub rsp, 0x08
00007c47757d53ec  push rax
00007c47757d53ed  push rcx
00007c47757d53ee  push rdx
00007c47757d53ef  push rdi
00007c47757d53f0  push rsi
00007c47757d53f1  push r8
00007c47757d53f3  push r9
00007c47757d53f5  push r10
00007c47757d53f7  push r11
00007c47757d53f9  sub rsp, 0xF0
00007c47757d5400  vmovaps [rsp], xmm0
00007c47757d5405  vmovaps [rsp+0x10], xmm1
00007c47757d540b  vmovaps [rsp+0x20], xmm2
00007c47757d5411  vmovaps [rsp+0x30], xmm3
00007c47757d5417  vmovaps [rsp+0x40], xmm4
00007c47757d541d  vmovaps [rsp+0x50], xmm5
00007c47757d5423  vmovaps [rsp+0x60], xmm6
00007c47757d5429  vmovaps [rsp+0x70], xmm7
00007c47757d542f  vmovaps [rsp+0x80], xmm8
00007c47757d5438  vmovaps [rsp+0x90], xmm9
00007c47757d5441  vmovaps [rsp+0xA0], xmm10
00007c47757d544a  vmovaps [rsp+0xB0], xmm11
00007c47757d5453  vmovaps [rsp+0xC0], xmm12
00007c47757d545c  vmovaps [rsp+0xD0], xmm14
00007c47757d5465  vmovaps [rsp+0xE0], xmm15
00007c47757d546e  sub rsp, 0x30
00007c47757d5472  movaps [rsp], xmm13
00007c47757d5477  movaps [rsp+0x10], xmm8
00007c47757d547d  movaps [rsp+0x20], xmm14
00007c47757d5483  lea rdi, [rsp]
00007c47757d5487  mov esi, 0x00
00007c47757d548c  mov rax, 0x62084E409530
00007c47757d5496  call rax
00007c47757d5498  movaps xmm13, [rsp]
00007c47757d549d  add rsp, 0x30
00007c47757d54a1  vmovaps xmm0, [rsp]
00007c47757d54a6  vmovaps xmm1, [rsp+0x10]
00007c47757d54ac  vmovaps xmm2, [rsp+0x20]
00007c47757d54b2  vmovaps xmm3, [rsp+0x30]
00007c47757d54b8  vmovaps xmm4, [rsp+0x40]
00007c47757d54be  vmovaps xmm5, [rsp+0x50]
00007c47757d54c4  vmovaps xmm6, [rsp+0x60]
00007c47757d54ca  vmovaps xmm7, [rsp+0x70]
00007c47757d54d0  vmovaps xmm8, [rsp+0x80]
00007c47757d54d9  vmovaps xmm9, [rsp+0x90]
00007c47757d54e2  vmovaps xmm10, [rsp+0xA0]
00007c47757d54eb  vmovaps xmm11, [rsp+0xB0]
00007c47757d54f4  vmovaps xmm12, [rsp+0xC0]
00007c47757d54fd  vmovaps xmm14, [rsp+0xD0]
00007c47757d5506  vmovaps xmm15, [rsp+0xE0]
00007c47757d550f  add rsp, 0xF0
00007c47757d5516  pop r11
00007c47757d5518  pop r10
00007c47757d551a  pop r9
00007c47757d551c  pop r8
00007c47757d551e  pop rsi
00007c47757d551f  pop rdi
00007c47757d5520  pop rdx
00007c47757d5521  pop rcx
00007c47757d5522  pop rax
00007c47757d5523  add rsp, 0x08
00007c47757d5527  jmp 0x00007C47757D02F7
00007c47757d552c  sub rsp, 0x08
00007c47757d5530  push rax
00007c47757d5531  push rcx
00007c47757d5532  push rdx
00007c47757d5533  push rdi
00007c47757d5534  push rsi
00007c47757d5535  push r8
00007c47757d5537  push r9
00007c47757d5539  push r10
00007c47757d553b  push r11
00007c47757d553d  sub rsp, 0xF0
00007c47757d5544  vmovaps [rsp], xmm0
00007c47757d5549  vmovaps [rsp+0x10], xmm1
00007c47757d554f  vmovaps [rsp+0x20], xmm2
00007c47757d5555  vmovaps [rsp+0x30], xmm3
00007c47757d555b  vmovaps [rsp+0x40], xmm4
00007c47757d5561  vmovaps [rsp+0x50], xmm5
00007c47757d5567  vmovaps [rsp+0x60], xmm6
00007c47757d556d  vmovaps [rsp+0x70], xmm7
00007c47757d5573  vmovaps [rsp+0x80], xmm8
00007c47757d557c  vmovaps [rsp+0x90], xmm9
00007c47757d5585  vmovaps [rsp+0xA0], xmm10
00007c47757d558e  vmovaps [rsp+0xB0], xmm11
00007c47757d5597  vmovaps [rsp+0xC0], xmm12
00007c47757d55a0  vmovaps [rsp+0xD0], xmm13
00007c47757d55a9  vmovaps [rsp+0xE0], xmm15
00007c47757d55b2  sub rsp, 0x30
00007c47757d55b6  movaps [rsp], xmm14
00007c47757d55bb  movaps [rsp+0x10], xmm1
00007c47757d55c0  movaps [rsp+0x20], xmm10
00007c47757d55c6  lea rdi, [rsp]
00007c47757d55ca  mov esi, 0x00
00007c47757d55cf  mov rax, 0x62084E409530
00007c47757d55d9  call rax
00007c47757d55db  movaps xmm14, [rsp]
00007c47757d55e0  add rsp, 0x30
00007c47757d55e4  vmovaps xmm0, [rsp]
00007c47757d55e9  vmovaps xmm1, [rsp+0x10]
00007c47757d55ef  vmovaps xmm2, [rsp+0x20]
00007c47757d55f5  vmovaps xmm3, [rsp+0x30]
00007c47757d55fb  vmovaps xmm4, [rsp+0x40]
00007c47757d5601  vmovaps xmm5, [rsp+0x50]
00007c47757d5607  vmovaps xmm6, [rsp+0x60]
00007c47757d560d  vmovaps xmm7, [rsp+0x70]
00007c47757d5613  vmovaps xmm8, [rsp+0x80]
00007c47757d561c  vmovaps xmm9, [rsp+0x90]
00007c47757d5625  vmovaps xmm10, [rsp+0xA0]
00007c47757d562e  vmovaps xmm11, [rsp+0xB0]
00007c47757d5637  vmovaps xmm12, [rsp+0xC0]
00007c47757d5640  vmovaps xmm13, [rsp+0xD0]
00007c47757d5649  vmovaps xmm15, [rsp+0xE0]
00007c47757d5652  add rsp, 0xF0
00007c47757d5659  pop r11
00007c47757d565b  pop r10
00007c47757d565d  pop r9
00007c47757d565f  pop r8
00007c47757d5661  pop rsi
00007c47757d5662  pop rdi
00007c47757d5663  pop rdx
00007c47757d5664  pop rcx
00007c47757d5665  pop rax
00007c47757d5666  add rsp, 0x08
00007c47757d566a  jmp 0x00007C47757D031A
00007c47757d566f  sub rsp, 0x08
00007c47757d5673  push rax
00007c47757d5674  push rcx
00007c47757d5675  push rdx
00007c47757d5676  push rdi
00007c47757d5677  push rsi
00007c47757d5678  push r8
00007c47757d567a  push r9
00007c47757d567c  push r10
00007c47757d567e  push r11
00007c47757d5680  sub rsp, 0xF0
00007c47757d5687  vmovaps [rsp], xmm0
00007c47757d568c  vmovaps [rsp+0x10], xmm2
00007c47757d5692  vmovaps [rsp+0x20], xmm3
00007c47757d5698  vmovaps [rsp+0x30], xmm4
00007c47757d569e  vmovaps [rsp+0x40], xmm5
00007c47757d56a4  vmovaps [rsp+0x50], xmm6
00007c47757d56aa  vmovaps [rsp+0x60], xmm7
00007c47757d56b0  vmovaps [rsp+0x70], xmm8
00007c47757d56b6  vmovaps [rsp+0x80], xmm9
00007c47757d56bf  vmovaps [rsp+0x90], xmm10
00007c47757d56c8  vmovaps [rsp+0xA0], xmm11
00007c47757d56d1  vmovaps [rsp+0xB0], xmm12
00007c47757d56da  vmovaps [rsp+0xC0], xmm13
00007c47757d56e3  vmovaps [rsp+0xD0], xmm14
00007c47757d56ec  vmovaps [rsp+0xE0], xmm15
00007c47757d56f5  sub rsp, 0x30
00007c47757d56f9  movaps [rsp], xmm1
00007c47757d56fd  movaps [rsp+0x10], xmm7
00007c47757d5702  movaps [rsp+0x20], xmm11
00007c47757d5708  lea rdi, [rsp]
00007c47757d570c  mov esi, 0x00
00007c47757d5711  mov rax, 0x62084E409530
00007c47757d571b  call rax
00007c47757d571d  movaps xmm1, [rsp]
00007c47757d5721  add rsp, 0x30
00007c47757d5725  vmovaps xmm0, [rsp]
00007c47757d572a  vmovaps xmm2, [rsp+0x10]
00007c47757d5730  vmovaps xmm3, [rsp+0x20]
00007c47757d5736  vmovaps xmm4, [rsp+0x30]
00007c47757d573c  vmovaps xmm5, [rsp+0x40]
00007c47757d5742  vmovaps xmm6, [rsp+0x50]
00007c47757d5748  vmovaps xmm7, [rsp+0x60]
00007c47757d574e  vmovaps xmm8, [rsp+0x70]
00007c47757d5754  vmovaps xmm9, [rsp+0x80]
00007c47757d575d  vmovaps xmm10, [rsp+0x90]
00007c47757d5766  vmovaps xmm11, [rsp+0xA0]
00007c47757d576f  vmovaps xmm12, [rsp+0xB0]
00007c47757d5778  vmovaps xmm13, [rsp+0xC0]
00007c47757d5781  vmovaps xmm14, [rsp+0xD0]
00007c47757d578a  vmovaps xmm15, [rsp+0xE0]
00007c47757d5793  add rsp, 0xF0
00007c47757d579a  pop r11
00007c47757d579c  pop r10
00007c47757d579e  pop r9
00007c47757d57a0  pop r8
00007c47757d57a2  pop rsi
00007c47757d57a3  pop rdi
00007c47757d57a4  pop rdx
00007c47757d57a5  pop rcx
00007c47757d57a6  pop rax
00007c47757d57a7  add rsp, 0x08
00007c47757d57ab  jmp 0x00007C47757D033B
00007c47757d57b0  call 0x00007C477560E880
00007c47757d57b5  jmp 0x00007C47757D034E
00007c47757d57ba  call 0x00007C477560C380
00007c47757d57bf  jmp 0x00007C47757D0359
00007c47757d57c4  call 0x00007C477560D600
00007c47757d57c9  jmp 0x00007C47757D0364
00007c47757d57ce  call 0x00007C47755FF540
00007c47757d57d3  jmp 0x00007C47757D036F
00007c47757d57d8  int3
00007c47757d57d9  nop [rax], eax
00007c47757d57e0  mov rax, [r15+0x40]
00007c47757d57e4  mov r14, [r15+0x58]
00007c47757d57e8  lea r12, [rax+r14*1]
00007c47757d57ec  movaps xmm1, [r15+0x1D0]
00007c47757d57f4  vmovaps [rsp+0x10], xmm1
00007c47757d57fa  vmovaps xmm15, [rsp+0x10]
00007c47757d5800  por xmm1, xmm15
00007c47757d5805  movaps xmm14, [r15+0x1A0]
00007c47757d580d  vmovaps [rsp+0x10], xmm14
00007c47757d5813  vmovaps xmm13, [rsp+0x10]
00007c47757d5819  por xmm14, xmm13
00007c47757d581e  lea rax, [r12+0x30]
00007c47757d5823  mov r11, [r13+rax*1]
00007c47757d5828  lea rax, [r12+0x38]
00007c47757d582d  mov r10, [r13+rax*1]
00007c47757d5832  movq xmm13, r11
00007c47757d5837  movq xmm12, r10
00007c47757d583c  movq xmm13, xmm13
00007c47757d5841  vmovaps [rsp+0x10], xmm13
00007c47757d5847  movq xmm13, xmm13
00007c47757d584c  movaps [r15+0x130], xmm13
00007c47757d5854  movq xmm12, xmm12
00007c47757d5859  vmovaps [rsp+0x20], xmm12
00007c47757d585f  movq xmm12, xmm12
00007c47757d5864  movaps [r15+0x280], xmm12
00007c47757d586c  movaps xmm13, [r15+0x270]
00007c47757d5874  vmovaps [rsp+0x30], xmm13
00007c47757d587a  vmovaps xmm12, [rsp+0x30]
00007c47757d5880  por xmm13, xmm12
00007c47757d5885  lea rax, [r12+0x20]
00007c47757d588a  mov r11, [r13+rax*1]
00007c47757d588f  lea rax, [r12+0x28]
00007c47757d5894  mov r10, [r13+rax*1]
00007c47757d5899  movq xmm12, r11
00007c47757d589e  movq xmm11, r10
00007c47757d58a3  movq xmm12, xmm12
00007c47757d58a8  vmovaps [rsp+0x30], xmm12
00007c47757d58ae  movq xmm12, xmm12
00007c47757d58b3  movaps [r15+0x150], xmm12
00007c47757d58bb  movq xmm11, xmm11
00007c47757d58c0  vmovaps [rsp+0x40], xmm11
00007c47757d58c6  movq xmm11, xmm11
00007c47757d58cb  movaps [r15+0x140], xmm11
00007c47757d58d3  lea rax, [r12+0x10]
00007c47757d58d8  mov r11, [r13+rax*1]
00007c47757d58dd  lea rax, [r12+0x18]
00007c47757d58e2  mov r10, [r13+rax*1]
00007c47757d58e7  movq xmm12, r11
00007c47757d58ec  movq xmm11, r10
00007c47757d58f1  movq xmm12, xmm12
00007c47757d58f6  vmovaps [rsp+0x50], xmm12
00007c47757d58fc  movq xmm12, xmm12
00007c47757d5901  movaps [r15+0x170], xmm12
00007c47757d5909  movq xmm11, xmm11
00007c47757d590e  vmovaps [rsp+0x60], xmm11
00007c47757d5914  movq xmm11, xmm11
00007c47757d5919  movaps [r15+0x160], xmm11
00007c47757d5921  mov rax, [r13+r12*1]
00007c47757d5926  vmovq xmm12, rax
00007c47757d592b  vpbroadcastq xmm12, xmm12
00007c47757d5930  lea rax, [r12+0x08]
00007c47757d5935  mov r12, [r13+rax*1]
00007c47757d593a  movq xmm11, r12
00007c47757d593f  movaps [r15+0x230], xmm11
00007c47757d5947  mov rax, [r15+0xF8]
00007c47757d594e  lea r12, [rax+0x50]
00007c47757d5952  movups xmm11, [r13+r12*1]
00007c47757d5958  lea r12, [rax+0x60]
00007c47757d595c  movups xmm10, [r13+r12*1]
00007c47757d5962  lea r12, [rax+0x30]
00007c47757d5966  movups xmm9, [r13+r12*1]
00007c47757d596c  mov r12, [r15+0x50]
00007c47757d5970  lea r11, [r12+r14*1]
00007c47757d5974  mov [r15+0x60], r11
00007c47757d5978  lea r12, [r14+0x40]
00007c47757d597c  mov [r15+0x58], r12
00007c47757d5980  movaps xmm8, xmm12
00007c47757d5984  mulpd xmm8, xmm15
00007c47757d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007c47757d598f  ptest xmm7, xmm7
00007c47757d5994  jnz 0x00007C47757D67B7
00007c47757d599a  movq xmm15, qword ptr [r15+0x230]
00007c47757d59a3  vmovaps [rsp+0x70], xmm15
00007c47757d59a9  vpermilpd xmm15, xmm15, 0x00
00007c47757d59af  movaps xmm7, xmm9
00007c47757d59b3  mulpd xmm7, xmm15
00007c47757d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007c47757d59bd  ptest xmm6, xmm6
00007c47757d59c2  jnz 0x00007C47757D68FB
00007c47757d59c8  vxorps xmm15, xmm15, xmm15
00007c47757d59cd  vpbroadcastq xmm15, xmm15
00007c47757d59d2  movaps xmm9, xmm12
00007c47757d59d6  mulpd xmm9, xmm10
00007c47757d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007c47757d59e1  ptest xmm6, xmm6
00007c47757d59e6  jnz 0x00007C47757D6A3D
00007c47757d59ec  movaps xmm10, xmm12
00007c47757d59f0  mulpd xmm10, xmm11
00007c47757d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007c47757d59fb  ptest xmm6, xmm6
00007c47757d5a00  jnz 0x00007C47757D6B81
00007c47757d5a06  movaps xmm11, [r15+0x1F0]
00007c47757d5a0e  movaps xmm6, xmm12
00007c47757d5a12  mulpd xmm6, xmm11
00007c47757d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007c47757d5a1c  ptest xmm5, xmm5
00007c47757d5a21  jnz 0x00007C47757D6CC5
00007c47757d5a27  movaps xmm12, [r15+0x2A0]
00007c47757d5a2f  vmovaps [rsp+0x80], xmm12
00007c47757d5a38  vmovaps xmm11, [rsp+0x80]
00007c47757d5a41  por xmm12, xmm11
00007c47757d5a46  movaps xmm11, [r15+0x250]
00007c47757d5a4e  vmovaps [rsp+0x80], xmm11
00007c47757d5a57  vmovaps xmm5, [rsp+0x80]
00007c47757d5a60  por xmm11, xmm5
00007c47757d5a65  vmovaps xmm4, [rsp+0x70]
00007c47757d5a6b  vpermilpd xmm4, xmm4, 0x00
00007c47757d5a71  movaps xmm3, xmm5
00007c47757d5a74  mulpd xmm3, xmm4
00007c47757d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007c47757d5a7d  ptest xmm2, xmm2
00007c47757d5a82  jnz 0x00007C47757D6E07
00007c47757d5a88  mov [rsp+0x80], rax
00007c47757d5a90  xor eax, eax
00007c47757d5a92  mov r14d, 0x200
00007c47757d5a98  cmp r12, r14
00007c47757d5a9b  cmc
00007c47757d5a9c  lahf
00007c47757d5a9d  seto al
00007c47757d5aa0  mov [r15+0x108], eax
00007c47757d5aa7  movaps xmm5, xmm8
00007c47757d5aab  addpd xmm5, xmm15
00007c47757d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007c47757d5ab5  ptest xmm4, xmm4
00007c47757d5aba  jnz 0x00007C47757D6F47
00007c47757d5ac0  movaps xmm8, [r15+0x1B0]
00007c47757d5ac8  movaps xmm4, xmm9
00007c47757d5acc  addpd xmm4, xmm8
00007c47757d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007c47757d5ad6  ptest xmm2, xmm2
00007c47757d5adb  jnz 0x00007C47757D7089
00007c47757d5ae1  movaps xmm9, xmm10
00007c47757d5ae5  addpd xmm9, xmm8
00007c47757d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007c47757d5af0  ptest xmm2, xmm2
00007c47757d5af5  jnz 0x00007C47757D71CB
00007c47757d5afb  movaps xmm10, [r15+0x2F0]
00007c47757d5b03  vmovaps [rsp+0x90], xmm10
00007c47757d5b0c  vmovaps xmm8, [rsp+0x90]
00007c47757d5b15  por xmm10, xmm8
00007c47757d5b1a  movaps xmm8, [r15+0x2E0]
00007c47757d5b22  vmovaps [rsp+0x90], xmm8
00007c47757d5b2b  vmovaps xmm2, [rsp+0x90]
00007c47757d5b34  por xmm8, xmm2
00007c47757d5b39  movaps xmm2, [r15+0x2D0]
00007c47757d5b41  vmovaps [rsp+0x90], xmm2
00007c47757d5b4a  vmovaps [rsp+0xA0], xmm1
00007c47757d5b53  vmovaps xmm1, [rsp+0x90]
00007c47757d5b5c  por xmm2, xmm1
00007c47757d5b60  movaps xmm1, [r15+0x200]
00007c47757d5b68  vmovaps [rsp+0x90], xmm1
00007c47757d5b71  vmovaps [rsp+0xB0], xmm15
00007c47757d5b7a  vmovaps xmm15, [rsp+0x90]
00007c47757d5b83  por xmm1, xmm15
00007c47757d5b88  movaps xmm15, [r15+0x1C0]
00007c47757d5b90  vmovaps [rsp+0x90], xmm15
00007c47757d5b99  vmovaps [rsp+0xC0], xmm1
00007c47757d5ba2  vmovaps xmm1, [rsp+0x90]
00007c47757d5bab  por xmm15, xmm1
00007c47757d5bb0  movaps xmm1, [r15+0x190]
00007c47757d5bb8  vmovaps [rsp+0x90], xmm1
00007c47757d5bc1  vmovaps [rsp+0xD0], xmm15
00007c47757d5bca  vmovaps xmm15, [rsp+0x90]
00007c47757d5bd3  por xmm1, xmm15
00007c47757d5bd8  movaps xmm15, [r15+0x300]
00007c47757d5be0  vmovaps [rsp+0x90], xmm15
00007c47757d5be9  vmovaps [rsp+0xE0], xmm1
00007c47757d5bf2  vmovaps xmm1, [rsp+0x90]
00007c47757d5bfb  por xmm15, xmm1
00007c47757d5c00  mov rax, [rsp+0x80]
00007c47757d5c08  lea r14, [rax+0xA0]
00007c47757d5c0f  movups xmm1, [r13+r14*1]
00007c47757d5c15  lea r14, [rax+0xB0]
00007c47757d5c1c  vmovaps [rsp+0x80], xmm1
00007c47757d5c25  movups xmm1, [r13+r14*1]
00007c47757d5c2b  vmovaps [rsp+0x90], xmm1
00007c47757d5c34  vmovaps [rsp+0xF0], xmm15
00007c47757d5c3d  vmovaps xmm15, [rsp+0xB0]
00007c47757d5c46  vmovaps [rsp+0xB0], xmm14
00007c47757d5c4f  movaps xmm1, xmm6
00007c47757d5c52  addpd xmm1, xmm15
00007c47757d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007c47757d5c5c  ptest xmm14, xmm14
00007c47757d5c62  jnz 0x00007C47757D7323
00007c47757d5c68  lea r14, [rax+0xF0]
00007c47757d5c6f  movups xmm15, [r13+r14*1]
00007c47757d5c75  movaps xmm14, xmm4
00007c47757d5c79  addpd xmm14, xmm3
00007c47757d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007c47757d5c84  ptest xmm6, xmm6
00007c47757d5c89  jnz 0x00007C47757D746E
00007c47757d5c8f  movaps xmm6, xmm9
00007c47757d5c93  addpd xmm6, xmm7
00007c47757d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007c47757d5c9c  ptest xmm4, xmm4
00007c47757d5ca1  jnz 0x00007C47757D75B0
00007c47757d5ca7  vmovaps xmm9, [rsp+0x70]
00007c47757d5cad  vpermilpd xmm9, xmm9, 0x00
00007c47757d5cb3  vmovaps xmm4, [rsp+0x90]
00007c47757d5cbc  movaps xmm7, xmm4
00007c47757d5cbf  mulpd xmm7, xmm9
00007c47757d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007c47757d5cc9  ptest xmm3, xmm3
00007c47757d5cce  jnz 0x00007C47757D76F1
00007c47757d5cd4  vmovaps xmm9, [rsp+0x50]
00007c47757d5cda  vpermilpd xmm9, xmm9, 0x00
00007c47757d5ce0  movaps xmm4, xmm15
00007c47757d5ce4  mulpd xmm4, xmm9
00007c47757d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007c47757d5cee  ptest xmm3, xmm3
00007c47757d5cf3  jnz 0x00007C47757D7832
00007c47757d5cf9  lea r14, [rax+0xE0]
00007c47757d5d00  movups xmm15, [r13+r14*1]
00007c47757d5d06  vmovaps xmm9, [rsp+0x70]
00007c47757d5d0c  vpermilpd xmm9, xmm9, 0x00
00007c47757d5d12  vmovaps [rsp+0x70], xmm1
00007c47757d5d18  vmovaps xmm1, [rsp+0x80]
00007c47757d5d21  vmovaps [rsp+0x80], xmm15
00007c47757d5d2a  movaps xmm3, xmm1
00007c47757d5d2d  mulpd xmm3, xmm9
00007c47757d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007c47757d5d37  ptest xmm15, xmm15
00007c47757d5d3d  jnz 0x00007C47757D797E
00007c47757d5d43  vmovaps xmm1, [rsp+0xF0]
00007c47757d5d4c  vmovaps xmm15, [rsp+0xF0]
00007c47757d5d55  por xmm1, xmm15
00007c47757d5d5a  movaps [r15+0x300], xmm1
00007c47757d5d62  vmovaps xmm15, [rsp+0xE0]
00007c47757d5d6b  vmovaps xmm9, [rsp+0xE0]
00007c47757d5d74  por xmm15, xmm9
00007c47757d5d79  movaps [r15+0x190], xmm15
00007c47757d5d81  vmovaps xmm9, [rsp+0x50]
00007c47757d5d87  vpermilpd xmm9, xmm9, 0x00
00007c47757d5d8d  vmovaps [rsp+0x90], xmm1
00007c47757d5d96  vmovaps [rsp+0xE0], xmm15
00007c47757d5d9f  vmovaps xmm15, [rsp+0x80]
00007c47757d5da8  vmovaps [rsp+0x80], xmm14
00007c47757d5db1  movaps xmm1, xmm15
00007c47757d5db5  mulpd xmm1, xmm9
00007c47757d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007c47757d5dbf  ptest xmm14, xmm14
00007c47757d5dc5  jnz 0x00007C47757D7ABF
00007c47757d5dcb  lea r14, [rax+0x90]
00007c47757d5dd2  movups xmm15, [r13+r14*1]
00007c47757d5dd8  vmovaps xmm14, [rsp+0xD0]
00007c47757d5de1  vmovaps xmm9, [rsp+0xD0]
00007c47757d5dea  por xmm14, xmm9
00007c47757d5def  movaps [r15+0x1C0], xmm14
00007c47757d5df7  vmovaps xmm9, [rsp+0xC0]
00007c47757d5e00  vmovaps [rsp+0xD0], xmm1
00007c47757d5e09  vmovaps xmm1, [rsp+0xC0]
00007c47757d5e12  por xmm9, xmm1
00007c47757d5e17  movaps [r15+0x200], xmm9
00007c47757d5e1f  vmovaps [rsp+0xC0], xmm2
00007c47757d5e28  vmovaps xmm1, [rsp+0xC0]
00007c47757d5e31  por xmm2, xmm1
00007c47757d5e35  movaps [r15+0x2D0], xmm2
00007c47757d5e3d  vmovaps [rsp+0xC0], xmm8
00007c47757d5e46  vmovaps xmm1, [rsp+0xC0]
00007c47757d5e4f  por xmm8, xmm1
00007c47757d5e54  movaps [r15+0x2E0], xmm8
00007c47757d5e5c  vmovaps [rsp+0xC0], xmm15
00007c47757d5e65  movaps xmm1, xmm5
00007c47757d5e68  addpd xmm1, xmm7
00007c47757d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007c47757d5e71  ptest xmm15, xmm15
00007c47757d5e77  jnz 0x00007C47757D7C0B
00007c47757d5e7d  vmovaps xmm15, [rsp+0x50]
00007c47757d5e83  vpermilpd xmm15, xmm15, 0x00
00007c47757d5e89  vmovaps xmm5, [rsp+0xC0]
00007c47757d5e92  vmovaps [rsp+0xC0], xmm1
00007c47757d5e9b  movaps xmm7, xmm5
00007c47757d5e9e  mulpd xmm7, xmm15
00007c47757d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007c47757d5ea8  ptest xmm1, xmm1
00007c47757d5ead  jnz 0x00007C47757D7D4B
00007c47757d5eb3  lea r14, [rax+0x80]
00007c47757d5eba  movups xmm1, [r13+r14*1]
00007c47757d5ec0  vmovaps xmm5, [rsp+0x70]
00007c47757d5ec6  vmovaps [rsp+0x70], xmm1
00007c47757d5ecc  movaps xmm15, xmm5
00007c47757d5ed0  addpd xmm15, xmm3
00007c47757d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757d5edb  ptest xmm1, xmm1
00007c47757d5ee0  jnz 0x00007C47757D7E96
00007c47757d5ee6  vmovaps xmm5, [rsp+0x80]
00007c47757d5eef  movaps xmm1, xmm5
00007c47757d5ef2  addpd xmm1, xmm4
00007c47757d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007c47757d5efb  ptest xmm3, xmm3
00007c47757d5f00  jnz 0x00007C47757D7FD8
00007c47757d5f06  vmovaps [rsp+0x80], xmm10
00007c47757d5f0f  vmovaps xmm5, [rsp+0x80]
00007c47757d5f18  por xmm10, xmm5
00007c47757d5f1d  movaps [r15+0x2F0], xmm10
00007c47757d5f25  vmovaps xmm5, [rsp+0x50]
00007c47757d5f2b  vpermilpd xmm5, xmm5, 0x00
00007c47757d5f31  vmovaps xmm3, [rsp+0x70]
00007c47757d5f37  vmovaps [rsp+0x50], xmm1
00007c47757d5f3d  movaps xmm4, xmm3
00007c47757d5f40  mulpd xmm4, xmm5
00007c47757d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007c47757d5f49  ptest xmm1, xmm1
00007c47757d5f4e  jnz 0x00007C47757D8118
00007c47757d5f54  lea r14, [rax+0xD0]
00007c47757d5f5b  movups xmm1, [r13+r14*1]
00007c47757d5f61  vmovaps xmm3, [rsp+0xD0]
00007c47757d5f6a  vmovaps [rsp+0x70], xmm1
00007c47757d5f70  movaps xmm5, xmm6
00007c47757d5f73  addpd xmm5, xmm3
00007c47757d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007c47757d5f7c  ptest xmm1, xmm1
00007c47757d5f81  jnz 0x00007C47757D8262
00007c47757d5f87  vmovaps xmm1, [rsp+0x60]
00007c47757d5f8d  vpermilpd xmm1, xmm1, 0x00
00007c47757d5f93  movaps xmm6, xmm9
00007c47757d5f97  mulpd xmm6, xmm1
00007c47757d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007c47757d5fa0  ptest xmm3, xmm3
00007c47757d5fa5  jnz 0x00007C47757D83A2
00007c47757d5fab  movaps [r15+0x260], xmm6
00007c47757d5fb3  vxorps xmm1, xmm1, xmm1
00007c47757d5fb7  vpbroadcastq xmm1, xmm1
00007c47757d5fbc  movaps [r15+0x1B0], xmm1
00007c47757d5fc4  vmovaps xmm1, [rsp+0x60]
00007c47757d5fca  vpermilpd xmm1, xmm1, 0x00
00007c47757d5fd0  vmovaps xmm3, [rsp+0x70]
00007c47757d5fd6  vmovaps [rsp+0x70], xmm15
00007c47757d5fdc  movaps xmm9, xmm3
00007c47757d5fe0  mulpd xmm9, xmm1
00007c47757d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007c47757d5feb  ptest xmm15, xmm15
00007c47757d5ff1  jnz 0x00007C47757D84E3
00007c47757d5ff7  lea r14, [rax+0xC0]
00007c47757d5ffe  movups xmm1, [r13+r14*1]
00007c47757d6004  vmovaps xmm3, [rsp+0xC0]
00007c47757d600d  vmovaps [rsp+0x80], xmm1
00007c47757d6016  movaps xmm15, xmm3
00007c47757d601a  addpd xmm15, xmm7
00007c47757d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757d6025  ptest xmm1, xmm1
00007c47757d602a  jnz 0x00007C47757D862F
00007c47757d6030  vmovaps [rsp+0xC0], xmm13
00007c47757d6039  vmovaps xmm1, [rsp+0xC0]
00007c47757d6042  por xmm13, xmm1
00007c47757d6047  movaps [r15+0x270], xmm13
00007c47757d604f  vmovaps xmm1, [rsp+0xB0]
00007c47757d6058  vmovaps xmm7, [rsp+0xB0]
00007c47757d6061  por xmm1, xmm7
00007c47757d6065  movaps [r15+0x1A0], xmm1
00007c47757d606d  vmovaps xmm1, [rsp+0x60]
00007c47757d6073  vpermilpd xmm1, xmm1, 0x00
00007c47757d6079  vmovaps [rsp+0xB0], xmm1
00007c47757d6082  vmovaps xmm1, [rsp+0x80]
00007c47757d608b  vmovaps [rsp+0x80], xmm15
00007c47757d6094  vmovaps xmm15, [rsp+0xB0]
00007c47757d609d  vmovaps [rsp+0xB0], xmm14
00007c47757d60a6  movaps xmm3, xmm1
00007c47757d60a9  mulpd xmm3, xmm15
00007c47757d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007c47757d60b3  ptest xmm14, xmm14
00007c47757d60b9  jnz 0x00007C47757D8771
00007c47757d60bf  lea r14, [rax+0x20]
00007c47757d60c3  movups xmm1, [r13+r14*1]
00007c47757d60c9  movaps [r15+0x110], xmm1
00007c47757d60d1  vmovaps xmm14, [rsp+0x70]
00007c47757d60d7  vmovaps [rsp+0x70], xmm1
00007c47757d60dd  movaps xmm15, xmm14
00007c47757d60e1  addpd xmm15, xmm4
00007c47757d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757d60ec  ptest xmm1, xmm1
00007c47757d60f1  jnz 0x00007C47757D88BC
00007c47757d60f7  vmovaps xmm1, [rsp+0x60]
00007c47757d60fd  vpermilpd xmm1, xmm1, 0x00
00007c47757d6103  movaps xmm14, xmm2
00007c47757d6107  mulpd xmm14, xmm1
00007c47757d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007c47757d6112  ptest xmm4, xmm4
00007c47757d6117  jnz 0x00007C47757D89FF
00007c47757d611d  vmovaps xmm4, [rsp+0x50]
00007c47757d6123  movaps xmm1, xmm4
00007c47757d6126  addpd xmm1, xmm9
00007c47757d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007c47757d6130  ptest xmm2, xmm2
00007c47757d6135  jnz 0x00007C47757D8B41
00007c47757d613b  vmovaps xmm9, [rsp+0x30]
00007c47757d6141  vpermilpd xmm9, xmm9, 0x00
00007c47757d6147  vmovaps xmm2, [rsp+0x70]
00007c47757d614d  vmovaps [rsp+0x50], xmm1
00007c47757d6153  movaps xmm4, xmm2
00007c47757d6156  mulpd xmm4, xmm9
00007c47757d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007c47757d6160  ptest xmm1, xmm1
00007c47757d6165  jnz 0x00007C47757D8C82
00007c47757d616b  vmovaps xmm1, [rsp+0x30]
00007c47757d6171  vpermilpd xmm1, xmm1, 0x00
00007c47757d6177  vmovaps xmm2, [rsp+0x90]
00007c47757d6180  vmovaps [rsp+0x60], xmm15
00007c47757d6186  movaps xmm9, xmm2
00007c47757d618a  mulpd xmm9, xmm1
00007c47757d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007c47757d6195  ptest xmm15, xmm15
00007c47757d619b  jnz 0x00007C47757D8DC3
00007c47757d61a1  vmovaps xmm15, [rsp+0x80]
00007c47757d61aa  movaps xmm1, xmm15
00007c47757d61ae  addpd xmm1, xmm6
00007c47757d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007c47757d61b7  ptest xmm2, xmm2
00007c47757d61bc  jnz 0x00007C47757D8F05
00007c47757d61c2  movaps xmm15, xmm5
00007c47757d61c6  addpd xmm15, xmm3
00007c47757d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007c47757d61d1  ptest xmm6, xmm6
00007c47757d61d6  jnz 0x00007C47757D9046
00007c47757d61dc  vmovaps xmm6, [rsp+0x30]
00007c47757d61e2  vpermilpd xmm6, xmm6, 0x00
00007c47757d61e8  movaps xmm5, xmm8
00007c47757d61ec  mulpd xmm5, xmm6
00007c47757d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007c47757d61f5  ptest xmm3, xmm3
00007c47757d61fa  jnz 0x00007C47757D9188
00007c47757d6200  vmovaps xmm8, [rsp+0x30]
00007c47757d6206  vpermilpd xmm8, xmm8, 0x00
00007c47757d620c  movaps xmm6, xmm10
00007c47757d6210  mulpd xmm6, xmm8
00007c47757d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007c47757d621a  ptest xmm3, xmm3
00007c47757d621f  jnz 0x00007C47757D92C9
00007c47757d6225  vmovaps xmm8, [rsp+0x60]
00007c47757d622b  movaps xmm10, xmm8
00007c47757d622f  addpd xmm10, xmm14
00007c47757d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007c47757d623a  ptest xmm3, xmm3
00007c47757d623f  jnz 0x00007C47757D940B
00007c47757d6245  vmovaps xmm8, [rsp+0x50]
00007c47757d624b  movaps xmm14, xmm8
00007c47757d624f  addpd xmm14, xmm4
00007c47757d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007c47757d625a  ptest xmm3, xmm3
00007c47757d625f  jnz 0x00007C47757D954F
00007c47757d6265  vmovaps xmm8, [rsp+0x40]
00007c47757d626b  vpermilpd xmm8, xmm8, 0x00
00007c47757d6271  movaps xmm4, xmm13
00007c47757d6275  mulpd xmm4, xmm8
00007c47757d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007c47757d627f  ptest xmm3, xmm3
00007c47757d6284  jnz 0x00007C47757D9692
00007c47757d628a  movaps xmm13, xmm15
00007c47757d628e  addpd xmm13, xmm9
00007c47757d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007c47757d6299  ptest xmm8, xmm8
00007c47757d629f  jnz 0x00007C47757D97D4
00007c47757d62a5  movaps xmm15, xmm1
00007c47757d62a9  addpd xmm15, xmm5
00007c47757d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007c47757d62b4  ptest xmm9, xmm9
00007c47757d62ba  jnz 0x00007C47757D9918
00007c47757d62c0  vmovaps [rsp+0x30], xmm11
00007c47757d62c6  vmovaps xmm1, [rsp+0x30]
00007c47757d62cc  por xmm11, xmm1
00007c47757d62d1  movaps [r15+0x250], xmm11
00007c47757d62d9  vmovaps [rsp+0x30], xmm12
00007c47757d62df  vmovaps xmm1, [rsp+0x30]
00007c47757d62e5  por xmm12, xmm1
00007c47757d62ea  movaps [r15+0x2A0], xmm12
00007c47757d62f2  vmovaps xmm1, [rsp+0xA0]
00007c47757d62fb  vmovaps xmm11, [rsp+0xA0]
00007c47757d6304  por xmm1, xmm11
00007c47757d6309  movaps [r15+0x1D0], xmm1
00007c47757d6311  lea r14, [rax+0x40]
00007c47757d6315  movups xmm1, [r13+r14*1]
00007c47757d631b  movaps [r15+0x2C0], xmm1
00007c47757d6323  vmovaps xmm11, [rsp+0x40]
00007c47757d6329  vpermilpd xmm11, xmm11, 0x00
00007c47757d632f  vmovaps xmm8, [rsp+0xE0]
00007c47757d6338  movaps xmm9, xmm8
00007c47757d633c  mulpd xmm9, xmm11
00007c47757d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007c47757d6347  ptest xmm5, xmm5
00007c47757d634c  jnz 0x00007C47757D9A64
00007c47757d6352  movaps xmm11, xmm10
00007c47757d6356  addpd xmm11, xmm6
00007c47757d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007c47757d6361  ptest xmm8, xmm8
00007c47757d6367  jnz 0x00007C47757D9BA8
00007c47757d636d  movaps xmm10, xmm14
00007c47757d6371  addpd xmm10, xmm4
00007c47757d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007c47757d637c  ptest xmm8, xmm8
00007c47757d6382  jnz 0x00007C47757D9CEB
00007c47757d6388  vmovaps xmm14, [rsp+0x40]
00007c47757d638e  vpermilpd xmm14, xmm14, 0x00
00007c47757d6394  movaps xmm8, xmm1
00007c47757d6398  mulpd xmm8, xmm14
00007c47757d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007c47757d63a3  ptest xmm6, xmm6
00007c47757d63a8  jnz 0x00007C47757D9E2E
00007c47757d63ae  movaps xmm1, [r15+0x2B0]
00007c47757d63b6  vmovaps xmm14, [rsp+0x40]
00007c47757d63bc  vpermilpd xmm14, xmm14, 0x00
00007c47757d63c2  movaps xmm6, xmm1
00007c47757d63c5  mulpd xmm6, xmm14
00007c47757d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007c47757d63cf  ptest xmm5, xmm5
00007c47757d63d4  jnz 0x00007C47757D9F71
00007c47757d63da  vmovaps xmm1, [rsp+0x10]
00007c47757d63e0  vpermilpd xmm1, xmm1, 0x00
00007c47757d63e6  movaps xmm14, xmm12
00007c47757d63ea  mulpd xmm14, xmm1
00007c47757d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007c47757d63f5  ptest xmm5, xmm5
00007c47757d63fa  jnz 0x00007C47757DA0B2
00007c47757d6400  movaps xmm1, xmm13
00007c47757d6404  addpd xmm1, xmm9
00007c47757d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007c47757d640e  ptest xmm12, xmm12
00007c47757d6414  jnz 0x00007C47757DA1F5
00007c47757d641a  vmovaps xmm13, [rsp+0x10]
00007c47757d6420  vpermilpd xmm13, xmm13, 0x00
00007c47757d6426  movaps xmm12, xmm7
00007c47757d642a  mulpd xmm12, xmm13
00007c47757d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007c47757d6435  ptest xmm9, xmm9
00007c47757d643b  jnz 0x00007C47757DA337
00007c47757d6441  movaps xmm13, xmm15
00007c47757d6445  addpd xmm13, xmm8
00007c47757d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007c47757d6450  ptest xmm9, xmm9
00007c47757d6456  jnz 0x00007C47757DA47A
00007c47757d645c  movaps xmm15, [r15+0x290]
00007c47757d6464  vmovaps xmm9, [rsp+0x10]
00007c47757d646a  vpermilpd xmm9, xmm9, 0x00
00007c47757d6470  movaps xmm8, xmm15
00007c47757d6474  mulpd xmm8, xmm9
00007c47757d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007c47757d647f  ptest xmm7, xmm7
00007c47757d6484  jnz 0x00007C47757DA5BE
00007c47757d648a  movaps xmm15, xmm11
00007c47757d648e  addpd xmm15, xmm6
00007c47757d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007c47757d6499  ptest xmm9, xmm9
00007c47757d649f  jnz 0x00007C47757DA702
00007c47757d64a5  movaps xmm11, [r15+0x1E0]
00007c47757d64ad  vmovaps xmm9, [rsp+0x10]
00007c47757d64b3  vpermilpd xmm9, xmm9, 0x00
00007c47757d64b9  movaps xmm7, xmm11
00007c47757d64bd  mulpd xmm7, xmm9
00007c47757d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007c47757d64c7  ptest xmm6, xmm6
00007c47757d64cc  jnz 0x00007C47757DA845
00007c47757d64d2  movaps xmm11, xmm10
00007c47757d64d6  addpd xmm11, xmm14
00007c47757d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007c47757d64e1  ptest xmm9, xmm9
00007c47757d64e7  jnz 0x00007C47757DA987
00007c47757d64ed  lea r14, [rax+0x70]
00007c47757d64f1  movups xmm14, [r13+r14*1]
00007c47757d64f7  movaps [r15+0x240], xmm14
00007c47757d64ff  movaps xmm10, xmm1
00007c47757d6503  addpd xmm10, xmm12
00007c47757d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007c47757d650e  ptest xmm9, xmm9
00007c47757d6514  jnz 0x00007C47757DAAD5
00007c47757d651a  movaps [r15+0x170], xmm10
00007c47757d6522  vmovaps xmm1, [rsp+0x20]
00007c47757d6528  vpermilpd xmm1, xmm1, 0x00
00007c47757d652e  movaps xmm12, xmm14
00007c47757d6532  mulpd xmm12, xmm1
00007c47757d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007c47757d653d  ptest xmm9, xmm9
00007c47757d6543  jnz 0x00007C47757DAC18
00007c47757d6549  vmovaps xmm1, [rsp+0x20]
00007c47757d654f  vpermilpd xmm1, xmm1, 0x00
00007c47757d6555  vmovaps xmm9, [rsp+0xB0]
00007c47757d655e  movaps xmm14, xmm9
00007c47757d6562  mulpd xmm14, xmm1
00007c47757d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007c47757d656d  ptest xmm6, xmm6
00007c47757d6572  jnz 0x00007C47757DAD5B
00007c47757d6578  movaps [r15+0x180], xmm14
00007c47757d6580  movaps xmm1, xmm13
00007c47757d6584  addpd xmm1, xmm8
00007c47757d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007c47757d658e  ptest xmm9, xmm9
00007c47757d6594  jnz 0x00007C47757DAE9E
00007c47757d659a  movaps [r15+0x210], xmm1
00007c47757d65a2  movups xmm13, [r13+rax*1]
00007c47757d65a8  lea r14, [rax+0x10]
00007c47757d65ac  movups xmm9, [r13+r14*1]
00007c47757d65b2  movaps [r15+0x230], xmm9
00007c47757d65ba  movaps xmm8, xmm15
00007c47757d65be  addpd xmm8, xmm7
00007c47757d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007c47757d65c9  ptest xmm6, xmm6
00007c47757d65ce  jnz 0x00007C47757DAFF4
00007c47757d65d4  movaps [r15+0x130], xmm8
00007c47757d65dc  vmovaps xmm15, [rsp+0x20]
00007c47757d65e2  vpermilpd xmm15, xmm15, 0x00
00007c47757d65e8  movaps xmm7, xmm9
00007c47757d65ec  mulpd xmm7, xmm15
00007c47757d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007c47757d65f6  ptest xmm6, xmm6
00007c47757d65fb  jnz 0x00007C47757DB137
00007c47757d6601  movaps [r15+0x220], xmm7
00007c47757d6609  vmovaps xmm15, [rsp+0x20]
00007c47757d660f  vpermilpd xmm15, xmm15, 0x00
00007c47757d6615  movaps xmm9, xmm13
00007c47757d6619  mulpd xmm9, xmm15
00007c47757d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007c47757d6624  ptest xmm6, xmm6
00007c47757d6629  jnz 0x00007C47757DB279
00007c47757d662f  movaps xmm15, xmm11
00007c47757d6633  addpd xmm15, xmm12
00007c47757d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007c47757d663e  ptest xmm13, xmm13
00007c47757d6644  jnz 0x00007C47757DB3BD
00007c47757d664a  movaps [r15+0x140], xmm15
00007c47757d6652  movaps xmm13, xmm10
00007c47757d6656  addpd xmm13, xmm14
00007c47757d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007c47757d6661  ptest xmm12, xmm12
00007c47757d6667  jnz 0x00007C47757DB501
00007c47757d666d  movaps [r15+0x150], xmm13
00007c47757d6675  movaps xmm14, xmm1
00007c47757d6679  addpd xmm14, xmm7
00007c47757d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007c47757d6684  ptest xmm12, xmm12
00007c47757d668a  jnz 0x00007C47757DB645
00007c47757d6690  movaps [r15+0x160], xmm14
00007c47757d6698  movaps xmm1, xmm8
00007c47757d669c  addpd xmm1, xmm9
00007c47757d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007c47757d66a6  ptest xmm12, xmm12
00007c47757d66ac  jnz 0x00007C47757DB787
00007c47757d66b2  movaps [r15+0x120], xmm1
00007c47757d66ba  movups [r13+r11*1], xmm15
00007c47757d66c0  lea rax, [r11+0x10]
00007c47757d66c4  movups [r13+rax*1], xmm13
00007c47757d66ca  lea rax, [r11+0x20]
00007c47757d66ce  movups [r13+rax*1], xmm14
00007c47757d66d4  lea rax, [r11+0x30]
00007c47757d66d8  movups [r13+rax*1], xmm1
00007c47757d66de  mov eax, [r15+0x108]
00007c47757d66e5  sahf
00007c47757d66e6  jnz 0x00007C47757D6718
00007c47757d66e8  cmp dword ptr [r15+0x318], 0x00
00007c47757d66f0  jz 0x00007C47757DB900
00007c47757d66f6  nop [rax+rax*1], ax
00007c47757d66ff  nop [rax+rax*1], eax
00007c47757d6707  mov eax, 0x410444
00007c47757d670c  mov [r15+0x100], rax
00007c47757d6713  jmp 0x00007C47755FE110
00007c47757d6718  cmp dword ptr [r15+0x318], 0x00
00007c47757d6720  jz 0x00007C47757D57E0
00007c47757d6726  nop [rax+rax*1], ax
00007c47757d672f  nop [rax+rax*1], eax
00007c47757d6737  mov eax, 0x410278
00007c47757d673c  mov [r15+0x100], rax
00007c47757d6743  jmp 0x00007C47755FE110
00007c47757d6748  int3
00007c47757d6749  call 0x00007C477560A4B0
00007c47757d674e  jmp 0x00007C47757D5828
00007c47757d6753  call 0x00007C4775609240
00007c47757d6758  jmp 0x00007C47757D5832
00007c47757d675d  call 0x00007C477560A4B0
00007c47757d6762  jmp 0x00007C47757D588F
00007c47757d6767  call 0x00007C4775609240
00007c47757d676c  jmp 0x00007C47757D5899
00007c47757d6771  call 0x00007C477560A4B0
00007c47757d6776  jmp 0x00007C47757D58DD
00007c47757d677b  call 0x00007C4775609240
00007c47757d6780  jmp 0x00007C47757D58E7
00007c47757d6785  call 0x00007C47756B47C0
00007c47757d678a  jmp 0x00007C47757D5926
00007c47757d678f  call 0x00007C477560B720
00007c47757d6794  jmp 0x00007C47757D593A
00007c47757d6799  call 0x00007C47756BFC30
00007c47757d679e  jmp 0x00007C47757D5958
00007c47757d67a3  call 0x00007C47756BE9C0
00007c47757d67a8  jmp 0x00007C47757D5962
00007c47757d67ad  call 0x00007C47756BD750
00007c47757d67b2  jmp 0x00007C47757D596C
00007c47757d67b7  sub rsp, 0x08
00007c47757d67bb  push rax
00007c47757d67bc  push rcx
00007c47757d67bd  push rdx
00007c47757d67be  push rdi
00007c47757d67bf  push rsi
00007c47757d67c0  push r8
00007c47757d67c2  push r9
00007c47757d67c4  push r10
00007c47757d67c6  push r11
00007c47757d67c8  sub rsp, 0xF0
00007c47757d67cf  vmovaps [rsp], xmm0
00007c47757d67d4  vmovaps [rsp+0x10], xmm1
00007c47757d67da  vmovaps [rsp+0x20], xmm2
00007c47757d67e0  vmovaps [rsp+0x30], xmm3
00007c47757d67e6  vmovaps [rsp+0x40], xmm4
00007c47757d67ec  vmovaps [rsp+0x50], xmm5
00007c47757d67f2  vmovaps [rsp+0x60], xmm6
00007c47757d67f8  vmovaps [rsp+0x70], xmm7
00007c47757d67fe  vmovaps [rsp+0x80], xmm9
00007c47757d6807  vmovaps [rsp+0x90], xmm10
00007c47757d6810  vmovaps [rsp+0xA0], xmm11
00007c47757d6819  vmovaps [rsp+0xB0], xmm12
00007c47757d6822  vmovaps [rsp+0xC0], xmm13
00007c47757d682b  vmovaps [rsp+0xD0], xmm14
00007c47757d6834  vmovaps [rsp+0xE0], xmm15
00007c47757d683d  sub rsp, 0x30
00007c47757d6841  movaps [rsp], xmm8
00007c47757d6846  movaps [rsp+0x10], xmm12
00007c47757d684c  movaps [rsp+0x20], xmm15
00007c47757d6852  lea rdi, [rsp]
00007c47757d6856  mov esi, 0x00
00007c47757d685b  mov rax, 0x62084E409530
00007c47757d6865  call rax
00007c47757d6867  movaps xmm8, [rsp]
00007c47757d686c  add rsp, 0x30
00007c47757d6870  vmovaps xmm0, [rsp]
00007c47757d6875  vmovaps xmm1, [rsp+0x10]
00007c47757d687b  vmovaps xmm2, [rsp+0x20]
00007c47757d6881  vmovaps xmm3, [rsp+0x30]
00007c47757d6887  vmovaps xmm4, [rsp+0x40]
00007c47757d688d  vmovaps xmm5, [rsp+0x50]
00007c47757d6893  vmovaps xmm6, [rsp+0x60]
00007c47757d6899  vmovaps xmm7, [rsp+0x70]
00007c47757d689f  vmovaps xmm9, [rsp+0x80]
00007c47757d68a8  vmovaps xmm10, [rsp+0x90]
00007c47757d68b1  vmovaps xmm11, [rsp+0xA0]
00007c47757d68ba  vmovaps xmm12, [rsp+0xB0]
00007c47757d68c3  vmovaps xmm13, [rsp+0xC0]
00007c47757d68cc  vmovaps xmm14, [rsp+0xD0]
00007c47757d68d5  vmovaps xmm15, [rsp+0xE0]
00007c47757d68de  add rsp, 0xF0
00007c47757d68e5  pop r11
00007c47757d68e7  pop r10
00007c47757d68e9  pop r9
00007c47757d68eb  pop r8
00007c47757d68ed  pop rsi
00007c47757d68ee  pop rdi
00007c47757d68ef  pop rdx
00007c47757d68f0  pop rcx
00007c47757d68f1  pop rax
00007c47757d68f2  add rsp, 0x08
00007c47757d68f6  jmp 0x00007C47757D599A
00007c47757d68fb  sub rsp, 0x08
00007c47757d68ff  push rax
00007c47757d6900  push rcx
00007c47757d6901  push rdx
00007c47757d6902  push rdi
00007c47757d6903  push rsi
00007c47757d6904  push r8
00007c47757d6906  push r9
00007c47757d6908  push r10
00007c47757d690a  push r11
00007c47757d690c  sub rsp, 0xF0
00007c47757d6913  vmovaps [rsp], xmm0
00007c47757d6918  vmovaps [rsp+0x10], xmm1
00007c47757d691e  vmovaps [rsp+0x20], xmm2
00007c47757d6924  vmovaps [rsp+0x30], xmm3
00007c47757d692a  vmovaps [rsp+0x40], xmm4
00007c47757d6930  vmovaps [rsp+0x50], xmm5
00007c47757d6936  vmovaps [rsp+0x60], xmm6
00007c47757d693c  vmovaps [rsp+0x70], xmm8
00007c47757d6942  vmovaps [rsp+0x80], xmm9
00007c47757d694b  vmovaps [rsp+0x90], xmm10
00007c47757d6954  vmovaps [rsp+0xA0], xmm11
00007c47757d695d  vmovaps [rsp+0xB0], xmm12
00007c47757d6966  vmovaps [rsp+0xC0], xmm13
00007c47757d696f  vmovaps [rsp+0xD0], xmm14
00007c47757d6978  vmovaps [rsp+0xE0], xmm15
00007c47757d6981  sub rsp, 0x30
00007c47757d6985  movaps [rsp], xmm7
00007c47757d6989  movaps [rsp+0x10], xmm9
00007c47757d698f  movaps [rsp+0x20], xmm15
00007c47757d6995  lea rdi, [rsp]
00007c47757d6999  mov esi, 0x00
00007c47757d699e  mov rax, 0x62084E409530
00007c47757d69a8  call rax
00007c47757d69aa  movaps xmm7, [rsp]
00007c47757d69ae  add rsp, 0x30
00007c47757d69b2  vmovaps xmm0, [rsp]
00007c47757d69b7  vmovaps xmm1, [rsp+0x10]
00007c47757d69bd  vmovaps xmm2, [rsp+0x20]
00007c47757d69c3  vmovaps xmm3, [rsp+0x30]
00007c47757d69c9  vmovaps xmm4, [rsp+0x40]
00007c47757d69cf  vmovaps xmm5, [rsp+0x50]
00007c47757d69d5  vmovaps xmm6, [rsp+0x60]
00007c47757d69db  vmovaps xmm8, [rsp+0x70]
00007c47757d69e1  vmovaps xmm9, [rsp+0x80]
00007c47757d69ea  vmovaps xmm10, [rsp+0x90]
00007c47757d69f3  vmovaps xmm11, [rsp+0xA0]
00007c47757d69fc  vmovaps xmm12, [rsp+0xB0]
00007c47757d6a05  vmovaps xmm13, [rsp+0xC0]
00007c47757d6a0e  vmovaps xmm14, [rsp+0xD0]
00007c47757d6a17  vmovaps xmm15, [rsp+0xE0]
00007c47757d6a20  add rsp, 0xF0
00007c47757d6a27  pop r11
00007c47757d6a29  pop r10
00007c47757d6a2b  pop r9
00007c47757d6a2d  pop r8
00007c47757d6a2f  pop rsi
00007c47757d6a30  pop rdi
00007c47757d6a31  pop rdx
00007c47757d6a32  pop rcx
00007c47757d6a33  pop rax
00007c47757d6a34  add rsp, 0x08
00007c47757d6a38  jmp 0x00007C47757D59C8
00007c47757d6a3d  sub rsp, 0x08
00007c47757d6a41  push rax
00007c47757d6a42  push rcx
00007c47757d6a43  push rdx
00007c47757d6a44  push rdi
00007c47757d6a45  push rsi
00007c47757d6a46  push r8
00007c47757d6a48  push r9
00007c47757d6a4a  push r10
00007c47757d6a4c  push r11
00007c47757d6a4e  sub rsp, 0xF0
00007c47757d6a55  vmovaps [rsp], xmm0
00007c47757d6a5a  vmovaps [rsp+0x10], xmm1
00007c47757d6a60  vmovaps [rsp+0x20], xmm2
00007c47757d6a66  vmovaps [rsp+0x30], xmm3
00007c47757d6a6c  vmovaps [rsp+0x40], xmm4
00007c47757d6a72  vmovaps [rsp+0x50], xmm5
00007c47757d6a78  vmovaps [rsp+0x60], xmm6
00007c47757d6a7e  vmovaps [rsp+0x70], xmm7
00007c47757d6a84  vmovaps [rsp+0x80], xmm8
00007c47757d6a8d  vmovaps [rsp+0x90], xmm10
00007c47757d6a96  vmovaps [rsp+0xA0], xmm11
00007c47757d6a9f  vmovaps [rsp+0xB0], xmm12
00007c47757d6aa8  vmovaps [rsp+0xC0], xmm13
00007c47757d6ab1  vmovaps [rsp+0xD0], xmm14
00007c47757d6aba  vmovaps [rsp+0xE0], xmm15
00007c47757d6ac3  sub rsp, 0x30
00007c47757d6ac7  movaps [rsp], xmm9
00007c47757d6acc  movaps [rsp+0x10], xmm12
00007c47757d6ad2  movaps [rsp+0x20], xmm10
00007c47757d6ad8  lea rdi, [rsp]
00007c47757d6adc  mov esi, 0x00
00007c47757d6ae1  mov rax, 0x62084E409530
00007c47757d6aeb  call rax
00007c47757d6aed  movaps xmm9, [rsp]
00007c47757d6af2  add rsp, 0x30
00007c47757d6af6  vmovaps xmm0, [rsp]
00007c47757d6afb  vmovaps xmm1, [rsp+0x10]
00007c47757d6b01  vmovaps xmm2, [rsp+0x20]
00007c47757d6b07  vmovaps xmm3, [rsp+0x30]
00007c47757d6b0d  vmovaps xmm4, [rsp+0x40]
00007c47757d6b13  vmovaps xmm5, [rsp+0x50]
00007c47757d6b19  vmovaps xmm6, [rsp+0x60]
00007c47757d6b1f  vmovaps xmm7, [rsp+0x70]
00007c47757d6b25  vmovaps xmm8, [rsp+0x80]
00007c47757d6b2e  vmovaps xmm10, [rsp+0x90]
00007c47757d6b37  vmovaps xmm11, [rsp+0xA0]
00007c47757d6b40  vmovaps xmm12, [rsp+0xB0]
00007c47757d6b49  vmovaps xmm13, [rsp+0xC0]
00007c47757d6b52  vmovaps xmm14, [rsp+0xD0]
00007c47757d6b5b  vmovaps xmm15, [rsp+0xE0]
00007c47757d6b64  add rsp, 0xF0
00007c47757d6b6b  pop r11
00007c47757d6b6d  pop r10
00007c47757d6b6f  pop r9
00007c47757d6b71  pop r8
00007c47757d6b73  pop rsi
00007c47757d6b74  pop rdi
00007c47757d6b75  pop rdx
00007c47757d6b76  pop rcx
00007c47757d6b77  pop rax
00007c47757d6b78  add rsp, 0x08
00007c47757d6b7c  jmp 0x00007C47757D59EC
00007c47757d6b81  sub rsp, 0x08
00007c47757d6b85  push rax
00007c47757d6b86  push rcx
00007c47757d6b87  push rdx
00007c47757d6b88  push rdi
00007c47757d6b89  push rsi
00007c47757d6b8a  push r8
00007c47757d6b8c  push r9
00007c47757d6b8e  push r10
00007c47757d6b90  push r11
00007c47757d6b92  sub rsp, 0xF0
00007c47757d6b99  vmovaps [rsp], xmm0
00007c47757d6b9e  vmovaps [rsp+0x10], xmm1
00007c47757d6ba4  vmovaps [rsp+0x20], xmm2
00007c47757d6baa  vmovaps [rsp+0x30], xmm3
00007c47757d6bb0  vmovaps [rsp+0x40], xmm4
00007c47757d6bb6  vmovaps [rsp+0x50], xmm5
00007c47757d6bbc  vmovaps [rsp+0x60], xmm6
00007c47757d6bc2  vmovaps [rsp+0x70], xmm7
00007c47757d6bc8  vmovaps [rsp+0x80], xmm8
00007c47757d6bd1  vmovaps [rsp+0x90], xmm9
00007c47757d6bda  vmovaps [rsp+0xA0], xmm11
00007c47757d6be3  vmovaps [rsp+0xB0], xmm12
00007c47757d6bec  vmovaps [rsp+0xC0], xmm13
00007c47757d6bf5  vmovaps [rsp+0xD0], xmm14
00007c47757d6bfe  vmovaps [rsp+0xE0], xmm15
00007c47757d6c07  sub rsp, 0x30
00007c47757d6c0b  movaps [rsp], xmm10
00007c47757d6c10  movaps [rsp+0x10], xmm12
00007c47757d6c16  movaps [rsp+0x20], xmm11
00007c47757d6c1c  lea rdi, [rsp]
00007c47757d6c20  mov esi, 0x00
00007c47757d6c25  mov rax, 0x62084E409530
00007c47757d6c2f  call rax
00007c47757d6c31  movaps xmm10, [rsp]
00007c47757d6c36  add rsp, 0x30
00007c47757d6c3a  vmovaps xmm0, [rsp]
00007c47757d6c3f  vmovaps xmm1, [rsp+0x10]
00007c47757d6c45  vmovaps xmm2, [rsp+0x20]
00007c47757d6c4b  vmovaps xmm3, [rsp+0x30]
00007c47757d6c51  vmovaps xmm4, [rsp+0x40]
00007c47757d6c57  vmovaps xmm5, [rsp+0x50]
00007c47757d6c5d  vmovaps xmm6, [rsp+0x60]
00007c47757d6c63  vmovaps xmm7, [rsp+0x70]
00007c47757d6c69  vmovaps xmm8, [rsp+0x80]
00007c47757d6c72  vmovaps xmm9, [rsp+0x90]
00007c47757d6c7b  vmovaps xmm11, [rsp+0xA0]
00007c47757d6c84  vmovaps xmm12, [rsp+0xB0]
00007c47757d6c8d  vmovaps xmm13, [rsp+0xC0]
00007c47757d6c96  vmovaps xmm14, [rsp+0xD0]
00007c47757d6c9f  vmovaps xmm15, [rsp+0xE0]
00007c47757d6ca8  add rsp, 0xF0
00007c47757d6caf  pop r11
00007c47757d6cb1  pop r10
00007c47757d6cb3  pop r9
00007c47757d6cb5  pop r8
00007c47757d6cb7  pop rsi
00007c47757d6cb8  pop rdi
00007c47757d6cb9  pop rdx
00007c47757d6cba  pop rcx
00007c47757d6cbb  pop rax
00007c47757d6cbc  add rsp, 0x08
00007c47757d6cc0  jmp 0x00007C47757D5A06
00007c47757d6cc5  sub rsp, 0x08
00007c47757d6cc9  push rax
00007c47757d6cca  push rcx
00007c47757d6ccb  push rdx
00007c47757d6ccc  push rdi
00007c47757d6ccd  push rsi
00007c47757d6cce  push r8
00007c47757d6cd0  push r9
00007c47757d6cd2  push r10
00007c47757d6cd4  push r11
00007c47757d6cd6  sub rsp, 0xF0
00007c47757d6cdd  vmovaps [rsp], xmm0
00007c47757d6ce2  vmovaps [rsp+0x10], xmm1
00007c47757d6ce8  vmovaps [rsp+0x20], xmm2
00007c47757d6cee  vmovaps [rsp+0x30], xmm3
00007c47757d6cf4  vmovaps [rsp+0x40], xmm4
00007c47757d6cfa  vmovaps [rsp+0x50], xmm5
00007c47757d6d00  vmovaps [rsp+0x60], xmm7
00007c47757d6d06  vmovaps [rsp+0x70], xmm8
00007c47757d6d0c  vmovaps [rsp+0x80], xmm9
00007c47757d6d15  vmovaps [rsp+0x90], xmm10
00007c47757d6d1e  vmovaps [rsp+0xA0], xmm11
00007c47757d6d27  vmovaps [rsp+0xB0], xmm12
00007c47757d6d30  vmovaps [rsp+0xC0], xmm13
00007c47757d6d39  vmovaps [rsp+0xD0], xmm14
00007c47757d6d42  vmovaps [rsp+0xE0], xmm15
00007c47757d6d4b  sub rsp, 0x30
00007c47757d6d4f  movaps [rsp], xmm6
00007c47757d6d53  movaps [rsp+0x10], xmm12
00007c47757d6d59  movaps [rsp+0x20], xmm11
00007c47757d6d5f  lea rdi, [rsp]
00007c47757d6d63  mov esi, 0x00
00007c47757d6d68  mov rax, 0x62084E409530
00007c47757d6d72  call rax
00007c47757d6d74  movaps xmm6, [rsp]
00007c47757d6d78  add rsp, 0x30
00007c47757d6d7c  vmovaps xmm0, [rsp]
00007c47757d6d81  vmovaps xmm1, [rsp+0x10]
00007c47757d6d87  vmovaps xmm2, [rsp+0x20]
00007c47757d6d8d  vmovaps xmm3, [rsp+0x30]
00007c47757d6d93  vmovaps xmm4, [rsp+0x40]
00007c47757d6d99  vmovaps xmm5, [rsp+0x50]
00007c47757d6d9f  vmovaps xmm7, [rsp+0x60]
00007c47757d6da5  vmovaps xmm8, [rsp+0x70]
00007c47757d6dab  vmovaps xmm9, [rsp+0x80]
00007c47757d6db4  vmovaps xmm10, [rsp+0x90]
00007c47757d6dbd  vmovaps xmm11, [rsp+0xA0]
00007c47757d6dc6  vmovaps xmm12, [rsp+0xB0]
00007c47757d6dcf  vmovaps xmm13, [rsp+0xC0]
00007c47757d6dd8  vmovaps xmm14, [rsp+0xD0]
00007c47757d6de1  vmovaps xmm15, [rsp+0xE0]
00007c47757d6dea  add rsp, 0xF0
00007c47757d6df1  pop r11
00007c47757d6df3  pop r10
00007c47757d6df5  pop r9
00007c47757d6df7  pop r8
00007c47757d6df9  pop rsi
00007c47757d6dfa  pop rdi
00007c47757d6dfb  pop rdx
00007c47757d6dfc  pop rcx
00007c47757d6dfd  pop rax
00007c47757d6dfe  add rsp, 0x08
00007c47757d6e02  jmp 0x00007C47757D5A27
00007c47757d6e07  sub rsp, 0x08
00007c47757d6e0b  push rax
00007c47757d6e0c  push rcx
00007c47757d6e0d  push rdx
00007c47757d6e0e  push rdi
00007c47757d6e0f  push rsi
00007c47757d6e10  push r8
00007c47757d6e12  push r9
00007c47757d6e14  push r10
00007c47757d6e16  push r11
00007c47757d6e18  sub rsp, 0xF0
00007c47757d6e1f  vmovaps [rsp], xmm0
00007c47757d6e24  vmovaps [rsp+0x10], xmm1
00007c47757d6e2a  vmovaps [rsp+0x20], xmm2
00007c47757d6e30  vmovaps [rsp+0x30], xmm4
00007c47757d6e36  vmovaps [rsp+0x40], xmm5
00007c47757d6e3c  vmovaps [rsp+0x50], xmm6
00007c47757d6e42  vmovaps [rsp+0x60], xmm7
00007c47757d6e48  vmovaps [rsp+0x70], xmm8
00007c47757d6e4e  vmovaps [rsp+0x80], xmm9
00007c47757d6e57  vmovaps [rsp+0x90], xmm10
00007c47757d6e60  vmovaps [rsp+0xA0], xmm11
00007c47757d6e69  vmovaps [rsp+0xB0], xmm12
00007c47757d6e72  vmovaps [rsp+0xC0], xmm13
00007c47757d6e7b  vmovaps [rsp+0xD0], xmm14
00007c47757d6e84  vmovaps [rsp+0xE0], xmm15
00007c47757d6e8d  sub rsp, 0x30
00007c47757d6e91  movaps [rsp], xmm3
00007c47757d6e95  movaps [rsp+0x10], xmm5
00007c47757d6e9a  movaps [rsp+0x20], xmm4
00007c47757d6e9f  lea rdi, [rsp]
00007c47757d6ea3  mov esi, 0x00
00007c47757d6ea8  mov rax, 0x62084E409530
00007c47757d6eb2  call rax
00007c47757d6eb4  movaps xmm3, [rsp]
00007c47757d6eb8  add rsp, 0x30
00007c47757d6ebc  vmovaps xmm0, [rsp]
00007c47757d6ec1  vmovaps xmm1, [rsp+0x10]
00007c47757d6ec7  vmovaps xmm2, [rsp+0x20]
00007c47757d6ecd  vmovaps xmm4, [rsp+0x30]
00007c47757d6ed3  vmovaps xmm5, [rsp+0x40]
00007c47757d6ed9  vmovaps xmm6, [rsp+0x50]
00007c47757d6edf  vmovaps xmm7, [rsp+0x60]
00007c47757d6ee5  vmovaps xmm8, [rsp+0x70]
00007c47757d6eeb  vmovaps xmm9, [rsp+0x80]
00007c47757d6ef4  vmovaps xmm10, [rsp+0x90]
00007c47757d6efd  vmovaps xmm11, [rsp+0xA0]
00007c47757d6f06  vmovaps xmm12, [rsp+0xB0]
00007c47757d6f0f  vmovaps xmm13, [rsp+0xC0]
00007c47757d6f18  vmovaps xmm14, [rsp+0xD0]
00007c47757d6f21  vmovaps xmm15, [rsp+0xE0]
00007c47757d6f2a  add rsp, 0xF0
00007c47757d6f31  pop r11
00007c47757d6f33  pop r10
00007c47757d6f35  pop r9
00007c47757d6f37  pop r8
00007c47757d6f39  pop rsi
00007c47757d6f3a  pop rdi
00007c47757d6f3b  pop rdx
00007c47757d6f3c  pop rcx
00007c47757d6f3d  pop rax
00007c47757d6f3e  add rsp, 0x08
00007c47757d6f42  jmp 0x00007C47757D5A88
00007c47757d6f47  sub rsp, 0x08
00007c47757d6f4b  push rax
00007c47757d6f4c  push rcx
00007c47757d6f4d  push rdx
00007c47757d6f4e  push rdi
00007c47757d6f4f  push rsi
00007c47757d6f50  push r8
00007c47757d6f52  push r9
00007c47757d6f54  push r10
00007c47757d6f56  push r11
00007c47757d6f58  sub rsp, 0xF0
00007c47757d6f5f  vmovaps [rsp], xmm0
00007c47757d6f64  vmovaps [rsp+0x10], xmm1
00007c47757d6f6a  vmovaps [rsp+0x20], xmm2
00007c47757d6f70  vmovaps [rsp+0x30], xmm3
00007c47757d6f76  vmovaps [rsp+0x40], xmm4
00007c47757d6f7c  vmovaps [rsp+0x50], xmm6
00007c47757d6f82  vmovaps [rsp+0x60], xmm7
00007c47757d6f88  vmovaps [rsp+0x70], xmm8
00007c47757d6f8e  vmovaps [rsp+0x80], xmm9
00007c47757d6f97  vmovaps [rsp+0x90], xmm10
00007c47757d6fa0  vmovaps [rsp+0xA0], xmm11
00007c47757d6fa9  vmovaps [rsp+0xB0], xmm12
00007c47757d6fb2  vmovaps [rsp+0xC0], xmm13
00007c47757d6fbb  vmovaps [rsp+0xD0], xmm14
00007c47757d6fc4  vmovaps [rsp+0xE0], xmm15
00007c47757d6fcd  sub rsp, 0x30
00007c47757d6fd1  movaps [rsp], xmm5
00007c47757d6fd5  movaps [rsp+0x10], xmm8
00007c47757d6fdb  movaps [rsp+0x20], xmm15
00007c47757d6fe1  lea rdi, [rsp]
00007c47757d6fe5  mov esi, 0x00
00007c47757d6fea  mov rax, 0x62084E409530
00007c47757d6ff4  call rax
00007c47757d6ff6  movaps xmm5, [rsp]
00007c47757d6ffa  add rsp, 0x30
00007c47757d6ffe  vmovaps xmm0, [rsp]
00007c47757d7003  vmovaps xmm1, [rsp+0x10]
00007c47757d7009  vmovaps xmm2, [rsp+0x20]
00007c47757d700f  vmovaps xmm3, [rsp+0x30]
00007c47757d7015  vmovaps xmm4, [rsp+0x40]
00007c47757d701b  vmovaps xmm6, [rsp+0x50]
00007c47757d7021  vmovaps xmm7, [rsp+0x60]
00007c47757d7027  vmovaps xmm8, [rsp+0x70]
00007c47757d702d  vmovaps xmm9, [rsp+0x80]
00007c47757d7036  vmovaps xmm10, [rsp+0x90]
00007c47757d703f  vmovaps xmm11, [rsp+0xA0]
00007c47757d7048  vmovaps xmm12, [rsp+0xB0]
00007c47757d7051  vmovaps xmm13, [rsp+0xC0]
00007c47757d705a  vmovaps xmm14, [rsp+0xD0]
00007c47757d7063  vmovaps xmm15, [rsp+0xE0]
00007c47757d706c  add rsp, 0xF0
00007c47757d7073  pop r11
00007c47757d7075  pop r10
00007c47757d7077  pop r9
00007c47757d7079  pop r8
00007c47757d707b  pop rsi
00007c47757d707c  pop rdi
00007c47757d707d  pop rdx
00007c47757d707e  pop rcx
00007c47757d707f  pop rax
00007c47757d7080  add rsp, 0x08
00007c47757d7084  jmp 0x00007C47757D5AC0
00007c47757d7089  sub rsp, 0x08
00007c47757d708d  push rax
00007c47757d708e  push rcx
00007c47757d708f  push rdx
00007c47757d7090  push rdi
00007c47757d7091  push rsi
00007c47757d7092  push r8
00007c47757d7094  push r9
00007c47757d7096  push r10
00007c47757d7098  push r11
00007c47757d709a  sub rsp, 0xF0
00007c47757d70a1  vmovaps [rsp], xmm0
00007c47757d70a6  vmovaps [rsp+0x10], xmm1
00007c47757d70ac  vmovaps [rsp+0x20], xmm2
00007c47757d70b2  vmovaps [rsp+0x30], xmm3
00007c47757d70b8  vmovaps [rsp+0x40], xmm5
00007c47757d70be  vmovaps [rsp+0x50], xmm6
00007c47757d70c4  vmovaps [rsp+0x60], xmm7
00007c47757d70ca  vmovaps [rsp+0x70], xmm8
00007c47757d70d0  vmovaps [rsp+0x80], xmm9
00007c47757d70d9  vmovaps [rsp+0x90], xmm10
00007c47757d70e2  vmovaps [rsp+0xA0], xmm11
00007c47757d70eb  vmovaps [rsp+0xB0], xmm12
00007c47757d70f4  vmovaps [rsp+0xC0], xmm13
00007c47757d70fd  vmovaps [rsp+0xD0], xmm14
00007c47757d7106  vmovaps [rsp+0xE0], xmm15
00007c47757d710f  sub rsp, 0x30
00007c47757d7113  movaps [rsp], xmm4
00007c47757d7117  movaps [rsp+0x10], xmm9
00007c47757d711d  movaps [rsp+0x20], xmm8
00007c47757d7123  lea rdi, [rsp]
00007c47757d7127  mov esi, 0x00
00007c47757d712c  mov rax, 0x62084E409530
00007c47757d7136  call rax
00007c47757d7138  movaps xmm4, [rsp]
00007c47757d713c  add rsp, 0x30
00007c47757d7140  vmovaps xmm0, [rsp]
00007c47757d7145  vmovaps xmm1, [rsp+0x10]
00007c47757d714b  vmovaps xmm2, [rsp+0x20]
00007c47757d7151  vmovaps xmm3, [rsp+0x30]
00007c47757d7157  vmovaps xmm5, [rsp+0x40]
00007c47757d715d  vmovaps xmm6, [rsp+0x50]
00007c47757d7163  vmovaps xmm7, [rsp+0x60]
00007c47757d7169  vmovaps xmm8, [rsp+0x70]
00007c47757d716f  vmovaps xmm9, [rsp+0x80]
00007c47757d7178  vmovaps xmm10, [rsp+0x90]
00007c47757d7181  vmovaps xmm11, [rsp+0xA0]
00007c47757d718a  vmovaps xmm12, [rsp+0xB0]
00007c47757d7193  vmovaps xmm13, [rsp+0xC0]
00007c47757d719c  vmovaps xmm14, [rsp+0xD0]
00007c47757d71a5  vmovaps xmm15, [rsp+0xE0]
00007c47757d71ae  add rsp, 0xF0
00007c47757d71b5  pop r11
00007c47757d71b7  pop r10
00007c47757d71b9  pop r9
00007c47757d71bb  pop r8
00007c47757d71bd  pop rsi
00007c47757d71be  pop rdi
00007c47757d71bf  pop rdx
00007c47757d71c0  pop rcx
00007c47757d71c1  pop rax
00007c47757d71c2  add rsp, 0x08
00007c47757d71c6  jmp 0x00007C47757D5AE1
00007c47757d71cb  sub rsp, 0x08
00007c47757d71cf  push rax
00007c47757d71d0  push rcx
00007c47757d71d1  push rdx
00007c47757d71d2  push rdi
00007c47757d71d3  push rsi
00007c47757d71d4  push r8
00007c47757d71d6  push r9
00007c47757d71d8  push r10
00007c47757d71da  push r11
00007c47757d71dc  sub rsp, 0xF0
00007c47757d71e3  vmovaps [rsp], xmm0
00007c47757d71e8  vmovaps [rsp+0x10], xmm1
00007c47757d71ee  vmovaps [rsp+0x20], xmm2
00007c47757d71f4  vmovaps [rsp+0x30], xmm3
00007c47757d71fa  vmovaps [rsp+0x40], xmm4
00007c47757d7200  vmovaps [rsp+0x50], xmm5
00007c47757d7206  vmovaps [rsp+0x60], xmm6
00007c47757d720c  vmovaps [rsp+0x70], xmm7
00007c47757d7212  vmovaps [rsp+0x80], xmm8
00007c47757d721b  vmovaps [rsp+0x90], xmm10
00007c47757d7224  vmovaps [rsp+0xA0], xmm11
00007c47757d722d  vmovaps [rsp+0xB0], xmm12
00007c47757d7236  vmovaps [rsp+0xC0], xmm13
00007c47757d723f  vmovaps [rsp+0xD0], xmm14
00007c47757d7248  vmovaps [rsp+0xE0], xmm15
00007c47757d7251  sub rsp, 0x30
00007c47757d7255  movaps [rsp], xmm9
00007c47757d725a  movaps [rsp+0x10], xmm10
00007c47757d7260  movaps [rsp+0x20], xmm8
00007c47757d7266  lea rdi, [rsp]
00007c47757d726a  mov esi, 0x00
00007c47757d726f  mov rax, 0x62084E409530
00007c47757d7279  call rax
00007c47757d727b  movaps xmm9, [rsp]
00007c47757d7280  add rsp, 0x30
00007c47757d7284  vmovaps xmm0, [rsp]
00007c47757d7289  vmovaps xmm1, [rsp+0x10]
00007c47757d728f  vmovaps xmm2, [rsp+0x20]
00007c47757d7295  vmovaps xmm3, [rsp+0x30]
00007c47757d729b  vmovaps xmm4, [rsp+0x40]
00007c47757d72a1  vmovaps xmm5, [rsp+0x50]
00007c47757d72a7  vmovaps xmm6, [rsp+0x60]
00007c47757d72ad  vmovaps xmm7, [rsp+0x70]
00007c47757d72b3  vmovaps xmm8, [rsp+0x80]
00007c47757d72bc  vmovaps xmm10, [rsp+0x90]
00007c47757d72c5  vmovaps xmm11, [rsp+0xA0]
00007c47757d72ce  vmovaps xmm12, [rsp+0xB0]
00007c47757d72d7  vmovaps xmm13, [rsp+0xC0]
00007c47757d72e0  vmovaps xmm14, [rsp+0xD0]
00007c47757d72e9  vmovaps xmm15, [rsp+0xE0]
00007c47757d72f2  add rsp, 0xF0
00007c47757d72f9  pop r11
00007c47757d72fb  pop r10
00007c47757d72fd  pop r9
00007c47757d72ff  pop r8
00007c47757d7301  pop rsi
00007c47757d7302  pop rdi
00007c47757d7303  pop rdx
00007c47757d7304  pop rcx
00007c47757d7305  pop rax
00007c47757d7306  add rsp, 0x08
00007c47757d730a  jmp 0x00007C47757D5AFB
00007c47757d730f  call 0x00007C47756D64F0
00007c47757d7314  jmp 0x00007C47757D5C15
00007c47757d7319  call 0x00007C47756D64F0
00007c47757d731e  jmp 0x00007C47757D5C2B
00007c47757d7323  sub rsp, 0x08
00007c47757d7327  push rax
00007c47757d7328  push rcx
00007c47757d7329  push rdx
00007c47757d732a  push rdi
00007c47757d732b  push rsi
00007c47757d732c  push r8
00007c47757d732e  push r9
00007c47757d7330  push r10
00007c47757d7332  push r11
00007c47757d7334  sub rsp, 0xF0
00007c47757d733b  vmovaps [rsp], xmm0
00007c47757d7340  vmovaps [rsp+0x10], xmm2
00007c47757d7346  vmovaps [rsp+0x20], xmm3
00007c47757d734c  vmovaps [rsp+0x30], xmm4
00007c47757d7352  vmovaps [rsp+0x40], xmm5
00007c47757d7358  vmovaps [rsp+0x50], xmm6
00007c47757d735e  vmovaps [rsp+0x60], xmm7
00007c47757d7364  vmovaps [rsp+0x70], xmm8
00007c47757d736a  vmovaps [rsp+0x80], xmm9
00007c47757d7373  vmovaps [rsp+0x90], xmm10
00007c47757d737c  vmovaps [rsp+0xA0], xmm11
00007c47757d7385  vmovaps [rsp+0xB0], xmm12
00007c47757d738e  vmovaps [rsp+0xC0], xmm13
00007c47757d7397  vmovaps [rsp+0xD0], xmm14
00007c47757d73a0  vmovaps [rsp+0xE0], xmm15
00007c47757d73a9  sub rsp, 0x30
00007c47757d73ad  movaps [rsp], xmm1
00007c47757d73b1  movaps [rsp+0x10], xmm6
00007c47757d73b6  movaps [rsp+0x20], xmm15
00007c47757d73bc  lea rdi, [rsp]
00007c47757d73c0  mov esi, 0x00
00007c47757d73c5  mov rax, 0x62084E409530
00007c47757d73cf  call rax
00007c47757d73d1  movaps xmm1, [rsp]
00007c47757d73d5  add rsp, 0x30
00007c47757d73d9  vmovaps xmm0, [rsp]
00007c47757d73de  vmovaps xmm2, [rsp+0x10]
00007c47757d73e4  vmovaps xmm3, [rsp+0x20]
00007c47757d73ea  vmovaps xmm4, [rsp+0x30]
00007c47757d73f0  vmovaps xmm5, [rsp+0x40]
00007c47757d73f6  vmovaps xmm6, [rsp+0x50]
00007c47757d73fc  vmovaps xmm7, [rsp+0x60]
00007c47757d7402  vmovaps xmm8, [rsp+0x70]
00007c47757d7408  vmovaps xmm9, [rsp+0x80]
00007c47757d7411  vmovaps xmm10, [rsp+0x90]
00007c47757d741a  vmovaps xmm11, [rsp+0xA0]
00007c47757d7423  vmovaps xmm12, [rsp+0xB0]
00007c47757d742c  vmovaps xmm13, [rsp+0xC0]
00007c47757d7435  vmovaps xmm14, [rsp+0xD0]
00007c47757d743e  vmovaps xmm15, [rsp+0xE0]
00007c47757d7447  add rsp, 0xF0
00007c47757d744e  pop r11
00007c47757d7450  pop r10
00007c47757d7452  pop r9
00007c47757d7454  pop r8
00007c47757d7456  pop rsi
00007c47757d7457  pop rdi
00007c47757d7458  pop rdx
00007c47757d7459  pop rcx
00007c47757d745a  pop rax
00007c47757d745b  add rsp, 0x08
00007c47757d745f  jmp 0x00007C47757D5C68
00007c47757d7464  call 0x00007C47756E5820
00007c47757d7469  jmp 0x00007C47757D5C75
00007c47757d746e  sub rsp, 0x08
00007c47757d7472  push rax
00007c47757d7473  push rcx
00007c47757d7474  push rdx
00007c47757d7475  push rdi
00007c47757d7476  push rsi
00007c47757d7477  push r8
00007c47757d7479  push r9
00007c47757d747b  push r10
00007c47757d747d  push r11
00007c47757d747f  sub rsp, 0xF0
00007c47757d7486  vmovaps [rsp], xmm0
00007c47757d748b  vmovaps [rsp+0x10], xmm1
00007c47757d7491  vmovaps [rsp+0x20], xmm2
00007c47757d7497  vmovaps [rsp+0x30], xmm3
00007c47757d749d  vmovaps [rsp+0x40], xmm4
00007c47757d74a3  vmovaps [rsp+0x50], xmm5
00007c47757d74a9  vmovaps [rsp+0x60], xmm6
00007c47757d74af  vmovaps [rsp+0x70], xmm7
00007c47757d74b5  vmovaps [rsp+0x80], xmm8
00007c47757d74be  vmovaps [rsp+0x90], xmm9
00007c47757d74c7  vmovaps [rsp+0xA0], xmm10
00007c47757d74d0  vmovaps [rsp+0xB0], xmm11
00007c47757d74d9  vmovaps [rsp+0xC0], xmm12
00007c47757d74e2  vmovaps [rsp+0xD0], xmm13
00007c47757d74eb  vmovaps [rsp+0xE0], xmm15
00007c47757d74f4  sub rsp, 0x30
00007c47757d74f8  movaps [rsp], xmm14
00007c47757d74fd  movaps [rsp+0x10], xmm4
00007c47757d7502  movaps [rsp+0x20], xmm3
00007c47757d7507  lea rdi, [rsp]
00007c47757d750b  mov esi, 0x00
00007c47757d7510  mov rax, 0x62084E409530
00007c47757d751a  call rax
00007c47757d751c  movaps xmm14, [rsp]
00007c47757d7521  add rsp, 0x30
00007c47757d7525  vmovaps xmm0, [rsp]
00007c47757d752a  vmovaps xmm1, [rsp+0x10]
00007c47757d7530  vmovaps xmm2, [rsp+0x20]
00007c47757d7536  vmovaps xmm3, [rsp+0x30]
00007c47757d753c  vmovaps xmm4, [rsp+0x40]
00007c47757d7542  vmovaps xmm5, [rsp+0x50]
00007c47757d7548  vmovaps xmm6, [rsp+0x60]
00007c47757d754e  vmovaps xmm7, [rsp+0x70]
00007c47757d7554  vmovaps xmm8, [rsp+0x80]
00007c47757d755d  vmovaps xmm9, [rsp+0x90]
00007c47757d7566  vmovaps xmm10, [rsp+0xA0]
00007c47757d756f  vmovaps xmm11, [rsp+0xB0]
00007c47757d7578  vmovaps xmm12, [rsp+0xC0]
00007c47757d7581  vmovaps xmm13, [rsp+0xD0]
00007c47757d758a  vmovaps xmm15, [rsp+0xE0]
00007c47757d7593  add rsp, 0xF0
00007c47757d759a  pop r11
00007c47757d759c  pop r10
00007c47757d759e  pop r9
00007c47757d75a0  pop r8
00007c47757d75a2  pop rsi
00007c47757d75a3  pop rdi
00007c47757d75a4  pop rdx
00007c47757d75a5  pop rcx
00007c47757d75a6  pop rax
00007c47757d75a7  add rsp, 0x08
00007c47757d75ab  jmp 0x00007C47757D5C8F
00007c47757d75b0  sub rsp, 0x08
00007c47757d75b4  push rax
00007c47757d75b5  push rcx
00007c47757d75b6  push rdx
00007c47757d75b7  push rdi
00007c47757d75b8  push rsi
00007c47757d75b9  push r8
00007c47757d75bb  push r9
00007c47757d75bd  push r10
00007c47757d75bf  push r11
00007c47757d75c1  sub rsp, 0xF0
00007c47757d75c8  vmovaps [rsp], xmm0
00007c47757d75cd  vmovaps [rsp+0x10], xmm1
00007c47757d75d3  vmovaps [rsp+0x20], xmm2
00007c47757d75d9  vmovaps [rsp+0x30], xmm3
00007c47757d75df  vmovaps [rsp+0x40], xmm4
00007c47757d75e5  vmovaps [rsp+0x50], xmm5
00007c47757d75eb  vmovaps [rsp+0x60], xmm7
00007c47757d75f1  vmovaps [rsp+0x70], xmm8
00007c47757d75f7  vmovaps [rsp+0x80], xmm9
00007c47757d7600  vmovaps [rsp+0x90], xmm10
00007c47757d7609  vmovaps [rsp+0xA0], xmm11
00007c47757d7612  vmovaps [rsp+0xB0], xmm12
00007c47757d761b  vmovaps [rsp+0xC0], xmm13
00007c47757d7624  vmovaps [rsp+0xD0], xmm14
00007c47757d762d  vmovaps [rsp+0xE0], xmm15
00007c47757d7636  sub rsp, 0x30
00007c47757d763a  movaps [rsp], xmm6
00007c47757d763e  movaps [rsp+0x10], xmm9
00007c47757d7644  movaps [rsp+0x20], xmm7
00007c47757d7649  lea rdi, [rsp]
00007c47757d764d  mov esi, 0x00
00007c47757d7652  mov rax, 0x62084E409530
00007c47757d765c  call rax
00007c47757d765e  movaps xmm6, [rsp]
00007c47757d7662  add rsp, 0x30
00007c47757d7666  vmovaps xmm0, [rsp]
00007c47757d766b  vmovaps xmm1, [rsp+0x10]
00007c47757d7671  vmovaps xmm2, [rsp+0x20]
00007c47757d7677  vmovaps xmm3, [rsp+0x30]
00007c47757d767d  vmovaps xmm4, [rsp+0x40]
00007c47757d7683  vmovaps xmm5, [rsp+0x50]
00007c47757d7689  vmovaps xmm7, [rsp+0x60]
00007c47757d768f  vmovaps xmm8, [rsp+0x70]
00007c47757d7695  vmovaps xmm9, [rsp+0x80]
00007c47757d769e  vmovaps xmm10, [rsp+0x90]
00007c47757d76a7  vmovaps xmm11, [rsp+0xA0]
00007c47757d76b0  vmovaps xmm12, [rsp+0xB0]
00007c47757d76b9  vmovaps xmm13, [rsp+0xC0]
00007c47757d76c2  vmovaps xmm14, [rsp+0xD0]
00007c47757d76cb  vmovaps xmm15, [rsp+0xE0]
00007c47757d76d4  add rsp, 0xF0
00007c47757d76db  pop r11
00007c47757d76dd  pop r10
00007c47757d76df  pop r9
00007c47757d76e1  pop r8
00007c47757d76e3  pop rsi
00007c47757d76e4  pop rdi
00007c47757d76e5  pop rdx
00007c47757d76e6  pop rcx
00007c47757d76e7  pop rax
00007c47757d76e8  add rsp, 0x08
00007c47757d76ec  jmp 0x00007C47757D5CA7
00007c47757d76f1  sub rsp, 0x08
00007c47757d76f5  push rax
00007c47757d76f6  push rcx
00007c47757d76f7  push rdx
00007c47757d76f8  push rdi
00007c47757d76f9  push rsi
00007c47757d76fa  push r8
00007c47757d76fc  push r9
00007c47757d76fe  push r10
00007c47757d7700  push r11
00007c47757d7702  sub rsp, 0xF0
00007c47757d7709  vmovaps [rsp], xmm0
00007c47757d770e  vmovaps [rsp+0x10], xmm1
00007c47757d7714  vmovaps [rsp+0x20], xmm2
00007c47757d771a  vmovaps [rsp+0x30], xmm3
00007c47757d7720  vmovaps [rsp+0x40], xmm4
00007c47757d7726  vmovaps [rsp+0x50], xmm5
00007c47757d772c  vmovaps [rsp+0x60], xmm6
00007c47757d7732  vmovaps [rsp+0x70], xmm8
00007c47757d7738  vmovaps [rsp+0x80], xmm9
00007c47757d7741  vmovaps [rsp+0x90], xmm10
00007c47757d774a  vmovaps [rsp+0xA0], xmm11
00007c47757d7753  vmovaps [rsp+0xB0], xmm12
00007c47757d775c  vmovaps [rsp+0xC0], xmm13
00007c47757d7765  vmovaps [rsp+0xD0], xmm14
00007c47757d776e  vmovaps [rsp+0xE0], xmm15
00007c47757d7777  sub rsp, 0x30
00007c47757d777b  movaps [rsp], xmm7
00007c47757d777f  movaps [rsp+0x10], xmm4
00007c47757d7784  movaps [rsp+0x20], xmm9
00007c47757d778a  lea rdi, [rsp]
00007c47757d778e  mov esi, 0x00
00007c47757d7793  mov rax, 0x62084E409530
00007c47757d779d  call rax
00007c47757d779f  movaps xmm7, [rsp]
00007c47757d77a3  add rsp, 0x30
00007c47757d77a7  vmovaps xmm0, [rsp]
00007c47757d77ac  vmovaps xmm1, [rsp+0x10]
00007c47757d77b2  vmovaps xmm2, [rsp+0x20]
00007c47757d77b8  vmovaps xmm3, [rsp+0x30]
00007c47757d77be  vmovaps xmm4, [rsp+0x40]
00007c47757d77c4  vmovaps xmm5, [rsp+0x50]
00007c47757d77ca  vmovaps xmm6, [rsp+0x60]
00007c47757d77d0  vmovaps xmm8, [rsp+0x70]
00007c47757d77d6  vmovaps xmm9, [rsp+0x80]
00007c47757d77df  vmovaps xmm10, [rsp+0x90]
00007c47757d77e8  vmovaps xmm11, [rsp+0xA0]
00007c47757d77f1  vmovaps xmm12, [rsp+0xB0]
00007c47757d77fa  vmovaps xmm13, [rsp+0xC0]
00007c47757d7803  vmovaps xmm14, [rsp+0xD0]
00007c47757d780c  vmovaps xmm15, [rsp+0xE0]
00007c47757d7815  add rsp, 0xF0
00007c47757d781c  pop r11
00007c47757d781e  pop r10
00007c47757d7820  pop r9
00007c47757d7822  pop r8
00007c47757d7824  pop rsi
00007c47757d7825  pop rdi
00007c47757d7826  pop rdx
00007c47757d7827  pop rcx
00007c47757d7828  pop rax
00007c47757d7829  add rsp, 0x08
00007c47757d782d  jmp 0x00007C47757D5CD4
00007c47757d7832  sub rsp, 0x08
00007c47757d7836  push rax
00007c47757d7837  push rcx
00007c47757d7838  push rdx
00007c47757d7839  push rdi
00007c47757d783a  push rsi
00007c47757d783b  push r8
00007c47757d783d  push r9
00007c47757d783f  push r10
00007c47757d7841  push r11
00007c47757d7843  sub rsp, 0xF0
00007c47757d784a  vmovaps [rsp], xmm0
00007c47757d784f  vmovaps [rsp+0x10], xmm1
00007c47757d7855  vmovaps [rsp+0x20], xmm2
00007c47757d785b  vmovaps [rsp+0x30], xmm3
00007c47757d7861  vmovaps [rsp+0x40], xmm5
00007c47757d7867  vmovaps [rsp+0x50], xmm6
00007c47757d786d  vmovaps [rsp+0x60], xmm7
00007c47757d7873  vmovaps [rsp+0x70], xmm8
00007c47757d7879  vmovaps [rsp+0x80], xmm9
00007c47757d7882  vmovaps [rsp+0x90], xmm10
00007c47757d788b  vmovaps [rsp+0xA0], xmm11
00007c47757d7894  vmovaps [rsp+0xB0], xmm12
00007c47757d789d  vmovaps [rsp+0xC0], xmm13
00007c47757d78a6  vmovaps [rsp+0xD0], xmm14
00007c47757d78af  vmovaps [rsp+0xE0], xmm15
00007c47757d78b8  sub rsp, 0x30
00007c47757d78bc  movaps [rsp], xmm4
00007c47757d78c0  movaps [rsp+0x10], xmm15
00007c47757d78c6  movaps [rsp+0x20], xmm9
00007c47757d78cc  lea rdi, [rsp]
00007c47757d78d0  mov esi, 0x00
00007c47757d78d5  mov rax, 0x62084E409530
00007c47757d78df  call rax
00007c47757d78e1  movaps xmm4, [rsp]
00007c47757d78e5  add rsp, 0x30
00007c47757d78e9  vmovaps xmm0, [rsp]
00007c47757d78ee  vmovaps xmm1, [rsp+0x10]
00007c47757d78f4  vmovaps xmm2, [rsp+0x20]
00007c47757d78fa  vmovaps xmm3, [rsp+0x30]
00007c47757d7900  vmovaps xmm5, [rsp+0x40]
00007c47757d7906  vmovaps xmm6, [rsp+0x50]
00007c47757d790c  vmovaps xmm7, [rsp+0x60]
00007c47757d7912  vmovaps xmm8, [rsp+0x70]
00007c47757d7918  vmovaps xmm9, [rsp+0x80]
00007c47757d7921  vmovaps xmm10, [rsp+0x90]
00007c47757d792a  vmovaps xmm11, [rsp+0xA0]
00007c47757d7933  vmovaps xmm12, [rsp+0xB0]
00007c47757d793c  vmovaps xmm13, [rsp+0xC0]
00007c47757d7945  vmovaps xmm14, [rsp+0xD0]
00007c47757d794e  vmovaps xmm15, [rsp+0xE0]
00007c47757d7957  add rsp, 0xF0
00007c47757d795e  pop r11
00007c47757d7960  pop r10
00007c47757d7962  pop r9
00007c47757d7964  pop r8
00007c47757d7966  pop rsi
00007c47757d7967  pop rdi
00007c47757d7968  pop rdx
00007c47757d7969  pop rcx
00007c47757d796a  pop rax
00007c47757d796b  add rsp, 0x08
00007c47757d796f  jmp 0x00007C47757D5CF9
00007c47757d7974  call 0x00007C47756E5820
00007c47757d7979  jmp 0x00007C47757D5D06
00007c47757d797e  sub rsp, 0x08
00007c47757d7982  push rax
00007c47757d7983  push rcx
00007c47757d7984  push rdx
00007c47757d7985  push rdi
00007c47757d7986  push rsi
00007c47757d7987  push r8
00007c47757d7989  push r9
00007c47757d798b  push r10
00007c47757d798d  push r11
00007c47757d798f  sub rsp, 0xF0
00007c47757d7996  vmovaps [rsp], xmm0
00007c47757d799b  vmovaps [rsp+0x10], xmm1
00007c47757d79a1  vmovaps [rsp+0x20], xmm2
00007c47757d79a7  vmovaps [rsp+0x30], xmm4
00007c47757d79ad  vmovaps [rsp+0x40], xmm5
00007c47757d79b3  vmovaps [rsp+0x50], xmm6
00007c47757d79b9  vmovaps [rsp+0x60], xmm7
00007c47757d79bf  vmovaps [rsp+0x70], xmm8
00007c47757d79c5  vmovaps [rsp+0x80], xmm9
00007c47757d79ce  vmovaps [rsp+0x90], xmm10
00007c47757d79d7  vmovaps [rsp+0xA0], xmm11
00007c47757d79e0  vmovaps [rsp+0xB0], xmm12
00007c47757d79e9  vmovaps [rsp+0xC0], xmm13
00007c47757d79f2  vmovaps [rsp+0xD0], xmm14
00007c47757d79fb  vmovaps [rsp+0xE0], xmm15
00007c47757d7a04  sub rsp, 0x30
00007c47757d7a08  movaps [rsp], xmm3
00007c47757d7a0c  movaps [rsp+0x10], xmm1
00007c47757d7a11  movaps [rsp+0x20], xmm9
00007c47757d7a17  lea rdi, [rsp]
00007c47757d7a1b  mov esi, 0x00
00007c47757d7a20  mov rax, 0x62084E409530
00007c47757d7a2a  call rax
00007c47757d7a2c  movaps xmm3, [rsp]
00007c47757d7a30  add rsp, 0x30
00007c47757d7a34  vmovaps xmm0, [rsp]
00007c47757d7a39  vmovaps xmm1, [rsp+0x10]
00007c47757d7a3f  vmovaps xmm2, [rsp+0x20]
00007c47757d7a45  vmovaps xmm4, [rsp+0x30]
00007c47757d7a4b  vmovaps xmm5, [rsp+0x40]
00007c47757d7a51  vmovaps xmm6, [rsp+0x50]
00007c47757d7a57  vmovaps xmm7, [rsp+0x60]
00007c47757d7a5d  vmovaps xmm8, [rsp+0x70]
00007c47757d7a63  vmovaps xmm9, [rsp+0x80]
00007c47757d7a6c  vmovaps xmm10, [rsp+0x90]
00007c47757d7a75  vmovaps xmm11, [rsp+0xA0]
00007c47757d7a7e  vmovaps xmm12, [rsp+0xB0]
00007c47757d7a87  vmovaps xmm13, [rsp+0xC0]
00007c47757d7a90  vmovaps xmm14, [rsp+0xD0]
00007c47757d7a99  vmovaps xmm15, [rsp+0xE0]
00007c47757d7aa2  add rsp, 0xF0
00007c47757d7aa9  pop r11
00007c47757d7aab  pop r10
00007c47757d7aad  pop r9
00007c47757d7aaf  pop r8
00007c47757d7ab1  pop rsi
00007c47757d7ab2  pop rdi
00007c47757d7ab3  pop rdx
00007c47757d7ab4  pop rcx
00007c47757d7ab5  pop rax
00007c47757d7ab6  add rsp, 0x08
00007c47757d7aba  jmp 0x00007C47757D5D43
00007c47757d7abf  sub rsp, 0x08
00007c47757d7ac3  push rax
00007c47757d7ac4  push rcx
00007c47757d7ac5  push rdx
00007c47757d7ac6  push rdi
00007c47757d7ac7  push rsi
00007c47757d7ac8  push r8
00007c47757d7aca  push r9
00007c47757d7acc  push r10
00007c47757d7ace  push r11
00007c47757d7ad0  sub rsp, 0xF0
00007c47757d7ad7  vmovaps [rsp], xmm0
00007c47757d7adc  vmovaps [rsp+0x10], xmm2
00007c47757d7ae2  vmovaps [rsp+0x20], xmm3
00007c47757d7ae8  vmovaps [rsp+0x30], xmm4
00007c47757d7aee  vmovaps [rsp+0x40], xmm5
00007c47757d7af4  vmovaps [rsp+0x50], xmm6
00007c47757d7afa  vmovaps [rsp+0x60], xmm7
00007c47757d7b00  vmovaps [rsp+0x70], xmm8
00007c47757d7b06  vmovaps [rsp+0x80], xmm9
00007c47757d7b0f  vmovaps [rsp+0x90], xmm10
00007c47757d7b18  vmovaps [rsp+0xA0], xmm11
00007c47757d7b21  vmovaps [rsp+0xB0], xmm12
00007c47757d7b2a  vmovaps [rsp+0xC0], xmm13
00007c47757d7b33  vmovaps [rsp+0xD0], xmm14
00007c47757d7b3c  vmovaps [rsp+0xE0], xmm15
00007c47757d7b45  sub rsp, 0x30
00007c47757d7b49  movaps [rsp], xmm1
00007c47757d7b4d  movaps [rsp+0x10], xmm15
00007c47757d7b53  movaps [rsp+0x20], xmm9
00007c47757d7b59  lea rdi, [rsp]
00007c47757d7b5d  mov esi, 0x00
00007c47757d7b62  mov rax, 0x62084E409530
00007c47757d7b6c  call rax
00007c47757d7b6e  movaps xmm1, [rsp]
00007c47757d7b72  add rsp, 0x30
00007c47757d7b76  vmovaps xmm0, [rsp]
00007c47757d7b7b  vmovaps xmm2, [rsp+0x10]
00007c47757d7b81  vmovaps xmm3, [rsp+0x20]
00007c47757d7b87  vmovaps xmm4, [rsp+0x30]
00007c47757d7b8d  vmovaps xmm5, [rsp+0x40]
00007c47757d7b93  vmovaps xmm6, [rsp+0x50]
00007c47757d7b99  vmovaps xmm7, [rsp+0x60]
00007c47757d7b9f  vmovaps xmm8, [rsp+0x70]
00007c47757d7ba5  vmovaps xmm9, [rsp+0x80]
00007c47757d7bae  vmovaps xmm10, [rsp+0x90]
00007c47757d7bb7  vmovaps xmm11, [rsp+0xA0]
00007c47757d7bc0  vmovaps xmm12, [rsp+0xB0]
00007c47757d7bc9  vmovaps xmm13, [rsp+0xC0]
00007c47757d7bd2  vmovaps xmm14, [rsp+0xD0]
00007c47757d7bdb  vmovaps xmm15, [rsp+0xE0]
00007c47757d7be4  add rsp, 0xF0
00007c47757d7beb  pop r11
00007c47757d7bed  pop r10
00007c47757d7bef  pop r9
00007c47757d7bf1  pop r8
00007c47757d7bf3  pop rsi
00007c47757d7bf4  pop rdi
00007c47757d7bf5  pop rdx
00007c47757d7bf6  pop rcx
00007c47757d7bf7  pop rax
00007c47757d7bf8  add rsp, 0x08
00007c47757d7bfc  jmp 0x00007C47757D5DCB
00007c47757d7c01  call 0x00007C47756E5820
00007c47757d7c06  jmp 0x00007C47757D5DD8
00007c47757d7c0b  sub rsp, 0x08
00007c47757d7c0f  push rax
00007c47757d7c10  push rcx
00007c47757d7c11  push rdx
00007c47757d7c12  push rdi
00007c47757d7c13  push rsi
00007c47757d7c14  push r8
00007c47757d7c16  push r9
00007c47757d7c18  push r10
00007c47757d7c1a  push r11
00007c47757d7c1c  sub rsp, 0xF0
00007c47757d7c23  vmovaps [rsp], xmm0
00007c47757d7c28  vmovaps [rsp+0x10], xmm2
00007c47757d7c2e  vmovaps [rsp+0x20], xmm3
00007c47757d7c34  vmovaps [rsp+0x30], xmm4
00007c47757d7c3a  vmovaps [rsp+0x40], xmm5
00007c47757d7c40  vmovaps [rsp+0x50], xmm6
00007c47757d7c46  vmovaps [rsp+0x60], xmm7
00007c47757d7c4c  vmovaps [rsp+0x70], xmm8
00007c47757d7c52  vmovaps [rsp+0x80], xmm9
00007c47757d7c5b  vmovaps [rsp+0x90], xmm10
00007c47757d7c64  vmovaps [rsp+0xA0], xmm11
00007c47757d7c6d  vmovaps [rsp+0xB0], xmm12
00007c47757d7c76  vmovaps [rsp+0xC0], xmm13
00007c47757d7c7f  vmovaps [rsp+0xD0], xmm14
00007c47757d7c88  vmovaps [rsp+0xE0], xmm15
00007c47757d7c91  sub rsp, 0x30
00007c47757d7c95  movaps [rsp], xmm1
00007c47757d7c99  movaps [rsp+0x10], xmm5
00007c47757d7c9e  movaps [rsp+0x20], xmm7
00007c47757d7ca3  lea rdi, [rsp]
00007c47757d7ca7  mov esi, 0x00
00007c47757d7cac  mov rax, 0x62084E409530
00007c47757d7cb6  call rax
00007c47757d7cb8  movaps xmm1, [rsp]
00007c47757d7cbc  add rsp, 0x30
00007c47757d7cc0  vmovaps xmm0, [rsp]
00007c47757d7cc5  vmovaps xmm2, [rsp+0x10]
00007c47757d7ccb  vmovaps xmm3, [rsp+0x20]
00007c47757d7cd1  vmovaps xmm4, [rsp+0x30]
00007c47757d7cd7  vmovaps xmm5, [rsp+0x40]
00007c47757d7cdd  vmovaps xmm6, [rsp+0x50]
00007c47757d7ce3  vmovaps xmm7, [rsp+0x60]
00007c47757d7ce9  vmovaps xmm8, [rsp+0x70]
00007c47757d7cef  vmovaps xmm9, [rsp+0x80]
00007c47757d7cf8  vmovaps xmm10, [rsp+0x90]
00007c47757d7d01  vmovaps xmm11, [rsp+0xA0]
00007c47757d7d0a  vmovaps xmm12, [rsp+0xB0]
00007c47757d7d13  vmovaps xmm13, [rsp+0xC0]
00007c47757d7d1c  vmovaps xmm14, [rsp+0xD0]
00007c47757d7d25  vmovaps xmm15, [rsp+0xE0]
00007c47757d7d2e  add rsp, 0xF0
00007c47757d7d35  pop r11
00007c47757d7d37  pop r10
00007c47757d7d39  pop r9
00007c47757d7d3b  pop r8
00007c47757d7d3d  pop rsi
00007c47757d7d3e  pop rdi
00007c47757d7d3f  pop rdx
00007c47757d7d40  pop rcx
00007c47757d7d41  pop rax
00007c47757d7d42  add rsp, 0x08
00007c47757d7d46  jmp 0x00007C47757D5E7D
00007c47757d7d4b  sub rsp, 0x08
00007c47757d7d4f  push rax
00007c47757d7d50  push rcx
00007c47757d7d51  push rdx
00007c47757d7d52  push rdi
00007c47757d7d53  push rsi
00007c47757d7d54  push r8
00007c47757d7d56  push r9
00007c47757d7d58  push r10
00007c47757d7d5a  push r11
00007c47757d7d5c  sub rsp, 0xF0
00007c47757d7d63  vmovaps [rsp], xmm0
00007c47757d7d68  vmovaps [rsp+0x10], xmm1
00007c47757d7d6e  vmovaps [rsp+0x20], xmm2
00007c47757d7d74  vmovaps [rsp+0x30], xmm3
00007c47757d7d7a  vmovaps [rsp+0x40], xmm4
00007c47757d7d80  vmovaps [rsp+0x50], xmm5
00007c47757d7d86  vmovaps [rsp+0x60], xmm6
00007c47757d7d8c  vmovaps [rsp+0x70], xmm8
00007c47757d7d92  vmovaps [rsp+0x80], xmm9
00007c47757d7d9b  vmovaps [rsp+0x90], xmm10
00007c47757d7da4  vmovaps [rsp+0xA0], xmm11
00007c47757d7dad  vmovaps [rsp+0xB0], xmm12
00007c47757d7db6  vmovaps [rsp+0xC0], xmm13
00007c47757d7dbf  vmovaps [rsp+0xD0], xmm14
00007c47757d7dc8  vmovaps [rsp+0xE0], xmm15
00007c47757d7dd1  sub rsp, 0x30
00007c47757d7dd5  movaps [rsp], xmm7
00007c47757d7dd9  movaps [rsp+0x10], xmm5
00007c47757d7dde  movaps [rsp+0x20], xmm15
00007c47757d7de4  lea rdi, [rsp]
00007c47757d7de8  mov esi, 0x00
00007c47757d7ded  mov rax, 0x62084E409530
00007c47757d7df7  call rax
00007c47757d7df9  movaps xmm7, [rsp]
00007c47757d7dfd  add rsp, 0x30
00007c47757d7e01  vmovaps xmm0, [rsp]
00007c47757d7e06  vmovaps xmm1, [rsp+0x10]
00007c47757d7e0c  vmovaps xmm2, [rsp+0x20]
00007c47757d7e12  vmovaps xmm3, [rsp+0x30]
00007c47757d7e18  vmovaps xmm4, [rsp+0x40]
00007c47757d7e1e  vmovaps xmm5, [rsp+0x50]
00007c47757d7e24  vmovaps xmm6, [rsp+0x60]
00007c47757d7e2a  vmovaps xmm8, [rsp+0x70]
00007c47757d7e30  vmovaps xmm9, [rsp+0x80]
00007c47757d7e39  vmovaps xmm10, [rsp+0x90]
00007c47757d7e42  vmovaps xmm11, [rsp+0xA0]
00007c47757d7e4b  vmovaps xmm12, [rsp+0xB0]
00007c47757d7e54  vmovaps xmm13, [rsp+0xC0]
00007c47757d7e5d  vmovaps xmm14, [rsp+0xD0]
00007c47757d7e66  vmovaps xmm15, [rsp+0xE0]
00007c47757d7e6f  add rsp, 0xF0
00007c47757d7e76  pop r11
00007c47757d7e78  pop r10
00007c47757d7e7a  pop r9
00007c47757d7e7c  pop r8
00007c47757d7e7e  pop rsi
00007c47757d7e7f  pop rdi
00007c47757d7e80  pop rdx
00007c47757d7e81  pop rcx
00007c47757d7e82  pop rax
00007c47757d7e83  add rsp, 0x08
00007c47757d7e87  jmp 0x00007C47757D5EB3
00007c47757d7e8c  call 0x00007C47756D64F0
00007c47757d7e91  jmp 0x00007C47757D5EC0
00007c47757d7e96  sub rsp, 0x08
00007c47757d7e9a  push rax
00007c47757d7e9b  push rcx
00007c47757d7e9c  push rdx
00007c47757d7e9d  push rdi
00007c47757d7e9e  push rsi
00007c47757d7e9f  push r8
00007c47757d7ea1  push r9
00007c47757d7ea3  push r10
00007c47757d7ea5  push r11
00007c47757d7ea7  sub rsp, 0xF0
00007c47757d7eae  vmovaps [rsp], xmm0
00007c47757d7eb3  vmovaps [rsp+0x10], xmm1
00007c47757d7eb9  vmovaps [rsp+0x20], xmm2
00007c47757d7ebf  vmovaps [rsp+0x30], xmm3
00007c47757d7ec5  vmovaps [rsp+0x40], xmm4
00007c47757d7ecb  vmovaps [rsp+0x50], xmm5
00007c47757d7ed1  vmovaps [rsp+0x60], xmm6
00007c47757d7ed7  vmovaps [rsp+0x70], xmm7
00007c47757d7edd  vmovaps [rsp+0x80], xmm8
00007c47757d7ee6  vmovaps [rsp+0x90], xmm9
00007c47757d7eef  vmovaps [rsp+0xA0], xmm10
00007c47757d7ef8  vmovaps [rsp+0xB0], xmm11
00007c47757d7f01  vmovaps [rsp+0xC0], xmm12
00007c47757d7f0a  vmovaps [rsp+0xD0], xmm13
00007c47757d7f13  vmovaps [rsp+0xE0], xmm14
00007c47757d7f1c  sub rsp, 0x30
00007c47757d7f20  movaps [rsp], xmm15
00007c47757d7f25  movaps [rsp+0x10], xmm5
00007c47757d7f2a  movaps [rsp+0x20], xmm3
00007c47757d7f2f  lea rdi, [rsp]
00007c47757d7f33  mov esi, 0x00
00007c47757d7f38  mov rax, 0x62084E409530
00007c47757d7f42  call rax
00007c47757d7f44  movaps xmm15, [rsp]
00007c47757d7f49  add rsp, 0x30
00007c47757d7f4d  vmovaps xmm0, [rsp]
00007c47757d7f52  vmovaps xmm1, [rsp+0x10]
00007c47757d7f58  vmovaps xmm2, [rsp+0x20]
00007c47757d7f5e  vmovaps xmm3, [rsp+0x30]
00007c47757d7f64  vmovaps xmm4, [rsp+0x40]
00007c47757d7f6a  vmovaps xmm5, [rsp+0x50]
00007c47757d7f70  vmovaps xmm6, [rsp+0x60]
00007c47757d7f76  vmovaps xmm7, [rsp+0x70]
00007c47757d7f7c  vmovaps xmm8, [rsp+0x80]
00007c47757d7f85  vmovaps xmm9, [rsp+0x90]
00007c47757d7f8e  vmovaps xmm10, [rsp+0xA0]
00007c47757d7f97  vmovaps xmm11, [rsp+0xB0]
00007c47757d7fa0  vmovaps xmm12, [rsp+0xC0]
00007c47757d7fa9  vmovaps xmm13, [rsp+0xD0]
00007c47757d7fb2  vmovaps xmm14, [rsp+0xE0]
00007c47757d7fbb  add rsp, 0xF0
00007c47757d7fc2  pop r11
00007c47757d7fc4  pop r10
00007c47757d7fc6  pop r9
00007c47757d7fc8  pop r8
00007c47757d7fca  pop rsi
00007c47757d7fcb  pop rdi
00007c47757d7fcc  pop rdx
00007c47757d7fcd  pop rcx
00007c47757d7fce  pop rax
00007c47757d7fcf  add rsp, 0x08
00007c47757d7fd3  jmp 0x00007C47757D5EE6
00007c47757d7fd8  sub rsp, 0x08
00007c47757d7fdc  push rax
00007c47757d7fdd  push rcx
00007c47757d7fde  push rdx
00007c47757d7fdf  push rdi
00007c47757d7fe0  push rsi
00007c47757d7fe1  push r8
00007c47757d7fe3  push r9
00007c47757d7fe5  push r10
00007c47757d7fe7  push r11
00007c47757d7fe9  sub rsp, 0xF0
00007c47757d7ff0  vmovaps [rsp], xmm0
00007c47757d7ff5  vmovaps [rsp+0x10], xmm2
00007c47757d7ffb  vmovaps [rsp+0x20], xmm3
00007c47757d8001  vmovaps [rsp+0x30], xmm4
00007c47757d8007  vmovaps [rsp+0x40], xmm5
00007c47757d800d  vmovaps [rsp+0x50], xmm6
00007c47757d8013  vmovaps [rsp+0x60], xmm7
00007c47757d8019  vmovaps [rsp+0x70], xmm8
00007c47757d801f  vmovaps [rsp+0x80], xmm9
00007c47757d8028  vmovaps [rsp+0x90], xmm10
00007c47757d8031  vmovaps [rsp+0xA0], xmm11
00007c47757d803a  vmovaps [rsp+0xB0], xmm12
00007c47757d8043  vmovaps [rsp+0xC0], xmm13
00007c47757d804c  vmovaps [rsp+0xD0], xmm14
00007c47757d8055  vmovaps [rsp+0xE0], xmm15
00007c47757d805e  sub rsp, 0x30
00007c47757d8062  movaps [rsp], xmm1
00007c47757d8066  movaps [rsp+0x10], xmm5
00007c47757d806b  movaps [rsp+0x20], xmm4
00007c47757d8070  lea rdi, [rsp]
00007c47757d8074  mov esi, 0x00
00007c47757d8079  mov rax, 0x62084E409530
00007c47757d8083  call rax
00007c47757d8085  movaps xmm1, [rsp]
00007c47757d8089  add rsp, 0x30
00007c47757d808d  vmovaps xmm0, [rsp]
00007c47757d8092  vmovaps xmm2, [rsp+0x10]
00007c47757d8098  vmovaps xmm3, [rsp+0x20]
00007c47757d809e  vmovaps xmm4, [rsp+0x30]
00007c47757d80a4  vmovaps xmm5, [rsp+0x40]
00007c47757d80aa  vmovaps xmm6, [rsp+0x50]
00007c47757d80b0  vmovaps xmm7, [rsp+0x60]
00007c47757d80b6  vmovaps xmm8, [rsp+0x70]
00007c47757d80bc  vmovaps xmm9, [rsp+0x80]
00007c47757d80c5  vmovaps xmm10, [rsp+0x90]
00007c47757d80ce  vmovaps xmm11, [rsp+0xA0]
00007c47757d80d7  vmovaps xmm12, [rsp+0xB0]
00007c47757d80e0  vmovaps xmm13, [rsp+0xC0]
00007c47757d80e9  vmovaps xmm14, [rsp+0xD0]
00007c47757d80f2  vmovaps xmm15, [rsp+0xE0]
00007c47757d80fb  add rsp, 0xF0
00007c47757d8102  pop r11
00007c47757d8104  pop r10
00007c47757d8106  pop r9
00007c47757d8108  pop r8
00007c47757d810a  pop rsi
00007c47757d810b  pop rdi
00007c47757d810c  pop rdx
00007c47757d810d  pop rcx
00007c47757d810e  pop rax
00007c47757d810f  add rsp, 0x08
00007c47757d8113  jmp 0x00007C47757D5F06
00007c47757d8118  sub rsp, 0x08
00007c47757d811c  push rax
00007c47757d811d  push rcx
00007c47757d811e  push rdx
00007c47757d811f  push rdi
00007c47757d8120  push rsi
00007c47757d8121  push r8
00007c47757d8123  push r9
00007c47757d8125  push r10
00007c47757d8127  push r11
00007c47757d8129  sub rsp, 0xF0
00007c47757d8130  vmovaps [rsp], xmm0
00007c47757d8135  vmovaps [rsp+0x10], xmm1
00007c47757d813b  vmovaps [rsp+0x20], xmm2
00007c47757d8141  vmovaps [rsp+0x30], xmm3
00007c47757d8147  vmovaps [rsp+0x40], xmm5
00007c47757d814d  vmovaps [rsp+0x50], xmm6
00007c47757d8153  vmovaps [rsp+0x60], xmm7
00007c47757d8159  vmovaps [rsp+0x70], xmm8
00007c47757d815f  vmovaps [rsp+0x80], xmm9
00007c47757d8168  vmovaps [rsp+0x90], xmm10
00007c47757d8171  vmovaps [rsp+0xA0], xmm11
00007c47757d817a  vmovaps [rsp+0xB0], xmm12
00007c47757d8183  vmovaps [rsp+0xC0], xmm13
00007c47757d818c  vmovaps [rsp+0xD0], xmm14
00007c47757d8195  vmovaps [rsp+0xE0], xmm15
00007c47757d819e  sub rsp, 0x30
00007c47757d81a2  movaps [rsp], xmm4
00007c47757d81a6  movaps [rsp+0x10], xmm3
00007c47757d81ab  movaps [rsp+0x20], xmm5
00007c47757d81b0  lea rdi, [rsp]
00007c47757d81b4  mov esi, 0x00
00007c47757d81b9  mov rax, 0x62084E409530
00007c47757d81c3  call rax
00007c47757d81c5  movaps xmm4, [rsp]
00007c47757d81c9  add rsp, 0x30
00007c47757d81cd  vmovaps xmm0, [rsp]
00007c47757d81d2  vmovaps xmm1, [rsp+0x10]
00007c47757d81d8  vmovaps xmm2, [rsp+0x20]
00007c47757d81de  vmovaps xmm3, [rsp+0x30]
00007c47757d81e4  vmovaps xmm5, [rsp+0x40]
00007c47757d81ea  vmovaps xmm6, [rsp+0x50]
00007c47757d81f0  vmovaps xmm7, [rsp+0x60]
00007c47757d81f6  vmovaps xmm8, [rsp+0x70]
00007c47757d81fc  vmovaps xmm9, [rsp+0x80]
00007c47757d8205  vmovaps xmm10, [rsp+0x90]
00007c47757d820e  vmovaps xmm11, [rsp+0xA0]
00007c47757d8217  vmovaps xmm12, [rsp+0xB0]
00007c47757d8220  vmovaps xmm13, [rsp+0xC0]
00007c47757d8229  vmovaps xmm14, [rsp+0xD0]
00007c47757d8232  vmovaps xmm15, [rsp+0xE0]
00007c47757d823b  add rsp, 0xF0
00007c47757d8242  pop r11
00007c47757d8244  pop r10
00007c47757d8246  pop r9
00007c47757d8248  pop r8
00007c47757d824a  pop rsi
00007c47757d824b  pop rdi
00007c47757d824c  pop rdx
00007c47757d824d  pop rcx
00007c47757d824e  pop rax
00007c47757d824f  add rsp, 0x08
00007c47757d8253  jmp 0x00007C47757D5F54
00007c47757d8258  call 0x00007C47756D64F0
00007c47757d825d  jmp 0x00007C47757D5F61
00007c47757d8262  sub rsp, 0x08
00007c47757d8266  push rax
00007c47757d8267  push rcx
00007c47757d8268  push rdx
00007c47757d8269  push rdi
00007c47757d826a  push rsi
00007c47757d826b  push r8
00007c47757d826d  push r9
00007c47757d826f  push r10
00007c47757d8271  push r11
00007c47757d8273  sub rsp, 0xF0
00007c47757d827a  vmovaps [rsp], xmm0
00007c47757d827f  vmovaps [rsp+0x10], xmm1
00007c47757d8285  vmovaps [rsp+0x20], xmm2
00007c47757d828b  vmovaps [rsp+0x30], xmm3
00007c47757d8291  vmovaps [rsp+0x40], xmm4
00007c47757d8297  vmovaps [rsp+0x50], xmm6
00007c47757d829d  vmovaps [rsp+0x60], xmm7
00007c47757d82a3  vmovaps [rsp+0x70], xmm8
00007c47757d82a9  vmovaps [rsp+0x80], xmm9
00007c47757d82b2  vmovaps [rsp+0x90], xmm10
00007c47757d82bb  vmovaps [rsp+0xA0], xmm11
00007c47757d82c4  vmovaps [rsp+0xB0], xmm12
00007c47757d82cd  vmovaps [rsp+0xC0], xmm13
00007c47757d82d6  vmovaps [rsp+0xD0], xmm14
00007c47757d82df  vmovaps [rsp+0xE0], xmm15
00007c47757d82e8  sub rsp, 0x30
00007c47757d82ec  movaps [rsp], xmm5
00007c47757d82f0  movaps [rsp+0x10], xmm6
00007c47757d82f5  movaps [rsp+0x20], xmm3
00007c47757d82fa  lea rdi, [rsp]
00007c47757d82fe  mov esi, 0x00
00007c47757d8303  mov rax, 0x62084E409530
00007c47757d830d  call rax
00007c47757d830f  movaps xmm5, [rsp]
00007c47757d8313  add rsp, 0x30
00007c47757d8317  vmovaps xmm0, [rsp]
00007c47757d831c  vmovaps xmm1, [rsp+0x10]
00007c47757d8322  vmovaps xmm2, [rsp+0x20]
00007c47757d8328  vmovaps xmm3, [rsp+0x30]
00007c47757d832e  vmovaps xmm4, [rsp+0x40]
00007c47757d8334  vmovaps xmm6, [rsp+0x50]
00007c47757d833a  vmovaps xmm7, [rsp+0x60]
00007c47757d8340  vmovaps xmm8, [rsp+0x70]
00007c47757d8346  vmovaps xmm9, [rsp+0x80]
00007c47757d834f  vmovaps xmm10, [rsp+0x90]
00007c47757d8358  vmovaps xmm11, [rsp+0xA0]
00007c47757d8361  vmovaps xmm12, [rsp+0xB0]
00007c47757d836a  vmovaps xmm13, [rsp+0xC0]
00007c47757d8373  vmovaps xmm14, [rsp+0xD0]
00007c47757d837c  vmovaps xmm15, [rsp+0xE0]
00007c47757d8385  add rsp, 0xF0
00007c47757d838c  pop r11
00007c47757d838e  pop r10
00007c47757d8390  pop r9
00007c47757d8392  pop r8
00007c47757d8394  pop rsi
00007c47757d8395  pop rdi
00007c47757d8396  pop rdx
00007c47757d8397  pop rcx
00007c47757d8398  pop rax
00007c47757d8399  add rsp, 0x08
00007c47757d839d  jmp 0x00007C47757D5F87
00007c47757d83a2  sub rsp, 0x08
00007c47757d83a6  push rax
00007c47757d83a7  push rcx
00007c47757d83a8  push rdx
00007c47757d83a9  push rdi
00007c47757d83aa  push rsi
00007c47757d83ab  push r8
00007c47757d83ad  push r9
00007c47757d83af  push r10
00007c47757d83b1  push r11
00007c47757d83b3  sub rsp, 0xF0
00007c47757d83ba  vmovaps [rsp], xmm0
00007c47757d83bf  vmovaps [rsp+0x10], xmm1
00007c47757d83c5  vmovaps [rsp+0x20], xmm2
00007c47757d83cb  vmovaps [rsp+0x30], xmm3
00007c47757d83d1  vmovaps [rsp+0x40], xmm4
00007c47757d83d7  vmovaps [rsp+0x50], xmm5
00007c47757d83dd  vmovaps [rsp+0x60], xmm7
00007c47757d83e3  vmovaps [rsp+0x70], xmm8
00007c47757d83e9  vmovaps [rsp+0x80], xmm9
00007c47757d83f2  vmovaps [rsp+0x90], xmm10
00007c47757d83fb  vmovaps [rsp+0xA0], xmm11
00007c47757d8404  vmovaps [rsp+0xB0], xmm12
00007c47757d840d  vmovaps [rsp+0xC0], xmm13
00007c47757d8416  vmovaps [rsp+0xD0], xmm14
00007c47757d841f  vmovaps [rsp+0xE0], xmm15
00007c47757d8428  sub rsp, 0x30
00007c47757d842c  movaps [rsp], xmm6
00007c47757d8430  movaps [rsp+0x10], xmm9
00007c47757d8436  movaps [rsp+0x20], xmm1
00007c47757d843b  lea rdi, [rsp]
00007c47757d843f  mov esi, 0x00
00007c47757d8444  mov rax, 0x62084E409530
00007c47757d844e  call rax
00007c47757d8450  movaps xmm6, [rsp]
00007c47757d8454  add rsp, 0x30
00007c47757d8458  vmovaps xmm0, [rsp]
00007c47757d845d  vmovaps xmm1, [rsp+0x10]
00007c47757d8463  vmovaps xmm2, [rsp+0x20]
00007c47757d8469  vmovaps xmm3, [rsp+0x30]
00007c47757d846f  vmovaps xmm4, [rsp+0x40]
00007c47757d8475  vmovaps xmm5, [rsp+0x50]
00007c47757d847b  vmovaps xmm7, [rsp+0x60]
00007c47757d8481  vmovaps xmm8, [rsp+0x70]
00007c47757d8487  vmovaps xmm9, [rsp+0x80]
00007c47757d8490  vmovaps xmm10, [rsp+0x90]
00007c47757d8499  vmovaps xmm11, [rsp+0xA0]
00007c47757d84a2  vmovaps xmm12, [rsp+0xB0]
00007c47757d84ab  vmovaps xmm13, [rsp+0xC0]
00007c47757d84b4  vmovaps xmm14, [rsp+0xD0]
00007c47757d84bd  vmovaps xmm15, [rsp+0xE0]
00007c47757d84c6  add rsp, 0xF0
00007c47757d84cd  pop r11
00007c47757d84cf  pop r10
00007c47757d84d1  pop r9
00007c47757d84d3  pop r8
00007c47757d84d5  pop rsi
00007c47757d84d6  pop rdi
00007c47757d84d7  pop rdx
00007c47757d84d8  pop rcx
00007c47757d84d9  pop rax
00007c47757d84da  add rsp, 0x08
00007c47757d84de  jmp 0x00007C47757D5FAB
00007c47757d84e3  sub rsp, 0x08
00007c47757d84e7  push rax
00007c47757d84e8  push rcx
00007c47757d84e9  push rdx
00007c47757d84ea  push rdi
00007c47757d84eb  push rsi
00007c47757d84ec  push r8
00007c47757d84ee  push r9
00007c47757d84f0  push r10
00007c47757d84f2  push r11
00007c47757d84f4  sub rsp, 0xF0
00007c47757d84fb  vmovaps [rsp], xmm0
00007c47757d8500  vmovaps [rsp+0x10], xmm1
00007c47757d8506  vmovaps [rsp+0x20], xmm2
00007c47757d850c  vmovaps [rsp+0x30], xmm3
00007c47757d8512  vmovaps [rsp+0x40], xmm4
00007c47757d8518  vmovaps [rsp+0x50], xmm5
00007c47757d851e  vmovaps [rsp+0x60], xmm6
00007c47757d8524  vmovaps [rsp+0x70], xmm7
00007c47757d852a  vmovaps [rsp+0x80], xmm8
00007c47757d8533  vmovaps [rsp+0x90], xmm10
00007c47757d853c  vmovaps [rsp+0xA0], xmm11
00007c47757d8545  vmovaps [rsp+0xB0], xmm12
00007c47757d854e  vmovaps [rsp+0xC0], xmm13
00007c47757d8557  vmovaps [rsp+0xD0], xmm14
00007c47757d8560  vmovaps [rsp+0xE0], xmm15
00007c47757d8569  sub rsp, 0x30
00007c47757d856d  movaps [rsp], xmm9
00007c47757d8572  movaps [rsp+0x10], xmm3
00007c47757d8577  movaps [rsp+0x20], xmm1
00007c47757d857c  lea rdi, [rsp]
00007c47757d8580  mov esi, 0x00
00007c47757d8585  mov rax, 0x62084E409530
00007c47757d858f  call rax
00007c47757d8591  movaps xmm9, [rsp]
00007c47757d8596  add rsp, 0x30
00007c47757d859a  vmovaps xmm0, [rsp]
00007c47757d859f  vmovaps xmm1, [rsp+0x10]
00007c47757d85a5  vmovaps xmm2, [rsp+0x20]
00007c47757d85ab  vmovaps xmm3, [rsp+0x30]
00007c47757d85b1  vmovaps xmm4, [rsp+0x40]
00007c47757d85b7  vmovaps xmm5, [rsp+0x50]
00007c47757d85bd  vmovaps xmm6, [rsp+0x60]
00007c47757d85c3  vmovaps xmm7, [rsp+0x70]
00007c47757d85c9  vmovaps xmm8, [rsp+0x80]
00007c47757d85d2  vmovaps xmm10, [rsp+0x90]
00007c47757d85db  vmovaps xmm11, [rsp+0xA0]
00007c47757d85e4  vmovaps xmm12, [rsp+0xB0]
00007c47757d85ed  vmovaps xmm13, [rsp+0xC0]
00007c47757d85f6  vmovaps xmm14, [rsp+0xD0]
00007c47757d85ff  vmovaps xmm15, [rsp+0xE0]
00007c47757d8608  add rsp, 0xF0
00007c47757d860f  pop r11
00007c47757d8611  pop r10
00007c47757d8613  pop r9
00007c47757d8615  pop r8
00007c47757d8617  pop rsi
00007c47757d8618  pop rdi
00007c47757d8619  pop rdx
00007c47757d861a  pop rcx
00007c47757d861b  pop rax
00007c47757d861c  add rsp, 0x08
00007c47757d8620  jmp 0x00007C47757D5FF7
00007c47757d8625  call 0x00007C47756D64F0
00007c47757d862a  jmp 0x00007C47757D6004
00007c47757d862f  sub rsp, 0x08
00007c47757d8633  push rax
00007c47757d8634  push rcx
00007c47757d8635  push rdx
00007c47757d8636  push rdi
00007c47757d8637  push rsi
00007c47757d8638  push r8
00007c47757d863a  push r9
00007c47757d863c  push r10
00007c47757d863e  push r11
00007c47757d8640  sub rsp, 0xF0
00007c47757d8647  vmovaps [rsp], xmm0
00007c47757d864c  vmovaps [rsp+0x10], xmm1
00007c47757d8652  vmovaps [rsp+0x20], xmm2
00007c47757d8658  vmovaps [rsp+0x30], xmm3
00007c47757d865e  vmovaps [rsp+0x40], xmm4
00007c47757d8664  vmovaps [rsp+0x50], xmm5
00007c47757d866a  vmovaps [rsp+0x60], xmm6
00007c47757d8670  vmovaps [rsp+0x70], xmm7
00007c47757d8676  vmovaps [rsp+0x80], xmm8
00007c47757d867f  vmovaps [rsp+0x90], xmm9
00007c47757d8688  vmovaps [rsp+0xA0], xmm10
00007c47757d8691  vmovaps [rsp+0xB0], xmm11
00007c47757d869a  vmovaps [rsp+0xC0], xmm12
00007c47757d86a3  vmovaps [rsp+0xD0], xmm13
00007c47757d86ac  vmovaps [rsp+0xE0], xmm14
00007c47757d86b5  sub rsp, 0x30
00007c47757d86b9  movaps [rsp], xmm15
00007c47757d86be  movaps [rsp+0x10], xmm3
00007c47757d86c3  movaps [rsp+0x20], xmm7
00007c47757d86c8  lea rdi, [rsp]
00007c47757d86cc  mov esi, 0x00
00007c47757d86d1  mov rax, 0x62084E409530
00007c47757d86db  call rax
00007c47757d86dd  movaps xmm15, [rsp]
00007c47757d86e2  add rsp, 0x30
00007c47757d86e6  vmovaps xmm0, [rsp]
00007c47757d86eb  vmovaps xmm1, [rsp+0x10]
00007c47757d86f1  vmovaps xmm2, [rsp+0x20]
00007c47757d86f7  vmovaps xmm3, [rsp+0x30]
00007c47757d86fd  vmovaps xmm4, [rsp+0x40]
00007c47757d8703  vmovaps xmm5, [rsp+0x50]
00007c47757d8709  vmovaps xmm6, [rsp+0x60]
00007c47757d870f  vmovaps xmm7, [rsp+0x70]
00007c47757d8715  vmovaps xmm8, [rsp+0x80]
00007c47757d871e  vmovaps xmm9, [rsp+0x90]
00007c47757d8727  vmovaps xmm10, [rsp+0xA0]
00007c47757d8730  vmovaps xmm11, [rsp+0xB0]
00007c47757d8739  vmovaps xmm12, [rsp+0xC0]
00007c47757d8742  vmovaps xmm13, [rsp+0xD0]
00007c47757d874b  vmovaps xmm14, [rsp+0xE0]
00007c47757d8754  add rsp, 0xF0
00007c47757d875b  pop r11
00007c47757d875d  pop r10
00007c47757d875f  pop r9
00007c47757d8761  pop r8
00007c47757d8763  pop rsi
00007c47757d8764  pop rdi
00007c47757d8765  pop rdx
00007c47757d8766  pop rcx
00007c47757d8767  pop rax
00007c47757d8768  add rsp, 0x08
00007c47757d876c  jmp 0x00007C47757D6030
00007c47757d8771  sub rsp, 0x08
00007c47757d8775  push rax
00007c47757d8776  push rcx
00007c47757d8777  push rdx
00007c47757d8778  push rdi
00007c47757d8779  push rsi
00007c47757d877a  push r8
00007c47757d877c  push r9
00007c47757d877e  push r10
00007c47757d8780  push r11
00007c47757d8782  sub rsp, 0xF0
00007c47757d8789  vmovaps [rsp], xmm0
00007c47757d878e  vmovaps [rsp+0x10], xmm1
00007c47757d8794  vmovaps [rsp+0x20], xmm2
00007c47757d879a  vmovaps [rsp+0x30], xmm4
00007c47757d87a0  vmovaps [rsp+0x40], xmm5
00007c47757d87a6  vmovaps [rsp+0x50], xmm6
00007c47757d87ac  vmovaps [rsp+0x60], xmm7
00007c47757d87b2  vmovaps [rsp+0x70], xmm8
00007c47757d87b8  vmovaps [rsp+0x80], xmm9
00007c47757d87c1  vmovaps [rsp+0x90], xmm10
00007c47757d87ca  vmovaps [rsp+0xA0], xmm11
00007c47757d87d3  vmovaps [rsp+0xB0], xmm12
00007c47757d87dc  vmovaps [rsp+0xC0], xmm13
00007c47757d87e5  vmovaps [rsp+0xD0], xmm14
00007c47757d87ee  vmovaps [rsp+0xE0], xmm15
00007c47757d87f7  sub rsp, 0x30
00007c47757d87fb  movaps [rsp], xmm3
00007c47757d87ff  movaps [rsp+0x10], xmm1
00007c47757d8804  movaps [rsp+0x20], xmm15
00007c47757d880a  lea rdi, [rsp]
00007c47757d880e  mov esi, 0x00
00007c47757d8813  mov rax, 0x62084E409530
00007c47757d881d  call rax
00007c47757d881f  movaps xmm3, [rsp]
00007c47757d8823  add rsp, 0x30
00007c47757d8827  vmovaps xmm0, [rsp]
00007c47757d882c  vmovaps xmm1, [rsp+0x10]
00007c47757d8832  vmovaps xmm2, [rsp+0x20]
00007c47757d8838  vmovaps xmm4, [rsp+0x30]
00007c47757d883e  vmovaps xmm5, [rsp+0x40]
00007c47757d8844  vmovaps xmm6, [rsp+0x50]
00007c47757d884a  vmovaps xmm7, [rsp+0x60]
00007c47757d8850  vmovaps xmm8, [rsp+0x70]
00007c47757d8856  vmovaps xmm9, [rsp+0x80]
00007c47757d885f  vmovaps xmm10, [rsp+0x90]
00007c47757d8868  vmovaps xmm11, [rsp+0xA0]
00007c47757d8871  vmovaps xmm12, [rsp+0xB0]
00007c47757d887a  vmovaps xmm13, [rsp+0xC0]
00007c47757d8883  vmovaps xmm14, [rsp+0xD0]
00007c47757d888c  vmovaps xmm15, [rsp+0xE0]
00007c47757d8895  add rsp, 0xF0
00007c47757d889c  pop r11
00007c47757d889e  pop r10
00007c47757d88a0  pop r9
00007c47757d88a2  pop r8
00007c47757d88a4  pop rsi
00007c47757d88a5  pop rdi
00007c47757d88a6  pop rdx
00007c47757d88a7  pop rcx
00007c47757d88a8  pop rax
00007c47757d88a9  add rsp, 0x08
00007c47757d88ad  jmp 0x00007C47757D60BF
00007c47757d88b2  call 0x00007C47756D64F0
00007c47757d88b7  jmp 0x00007C47757D60C9
00007c47757d88bc  sub rsp, 0x08
00007c47757d88c0  push rax
00007c47757d88c1  push rcx
00007c47757d88c2  push rdx
00007c47757d88c3  push rdi
00007c47757d88c4  push rsi
00007c47757d88c5  push r8
00007c47757d88c7  push r9
00007c47757d88c9  push r10
00007c47757d88cb  push r11
00007c47757d88cd  sub rsp, 0xF0
00007c47757d88d4  vmovaps [rsp], xmm0
00007c47757d88d9  vmovaps [rsp+0x10], xmm1
00007c47757d88df  vmovaps [rsp+0x20], xmm2
00007c47757d88e5  vmovaps [rsp+0x30], xmm3
00007c47757d88eb  vmovaps [rsp+0x40], xmm4
00007c47757d88f1  vmovaps [rsp+0x50], xmm5
00007c47757d88f7  vmovaps [rsp+0x60], xmm6
00007c47757d88fd  vmovaps [rsp+0x70], xmm7
00007c47757d8903  vmovaps [rsp+0x80], xmm8
00007c47757d890c  vmovaps [rsp+0x90], xmm9
00007c47757d8915  vmovaps [rsp+0xA0], xmm10
00007c47757d891e  vmovaps [rsp+0xB0], xmm11
00007c47757d8927  vmovaps [rsp+0xC0], xmm12
00007c47757d8930  vmovaps [rsp+0xD0], xmm13
00007c47757d8939  vmovaps [rsp+0xE0], xmm14
00007c47757d8942  sub rsp, 0x30
00007c47757d8946  movaps [rsp], xmm15
00007c47757d894b  movaps [rsp+0x10], xmm14
00007c47757d8951  movaps [rsp+0x20], xmm4
00007c47757d8956  lea rdi, [rsp]
00007c47757d895a  mov esi, 0x00
00007c47757d895f  mov rax, 0x62084E409530
00007c47757d8969  call rax
00007c47757d896b  movaps xmm15, [rsp]
00007c47757d8970  add rsp, 0x30
00007c47757d8974  vmovaps xmm0, [rsp]
00007c47757d8979  vmovaps xmm1, [rsp+0x10]
00007c47757d897f  vmovaps xmm2, [rsp+0x20]
00007c47757d8985  vmovaps xmm3, [rsp+0x30]
00007c47757d898b  vmovaps xmm4, [rsp+0x40]
00007c47757d8991  vmovaps xmm5, [rsp+0x50]
00007c47757d8997  vmovaps xmm6, [rsp+0x60]
00007c47757d899d  vmovaps xmm7, [rsp+0x70]
00007c47757d89a3  vmovaps xmm8, [rsp+0x80]
00007c47757d89ac  vmovaps xmm9, [rsp+0x90]
00007c47757d89b5  vmovaps xmm10, [rsp+0xA0]
00007c47757d89be  vmovaps xmm11, [rsp+0xB0]
00007c47757d89c7  vmovaps xmm12, [rsp+0xC0]
00007c47757d89d0  vmovaps xmm13, [rsp+0xD0]
00007c47757d89d9  vmovaps xmm14, [rsp+0xE0]
00007c47757d89e2  add rsp, 0xF0
00007c47757d89e9  pop r11
00007c47757d89eb  pop r10
00007c47757d89ed  pop r9
00007c47757d89ef  pop r8
00007c47757d89f1  pop rsi
00007c47757d89f2  pop rdi
00007c47757d89f3  pop rdx
00007c47757d89f4  pop rcx
00007c47757d89f5  pop rax
00007c47757d89f6  add rsp, 0x08
00007c47757d89fa  jmp 0x00007C47757D60F7
00007c47757d89ff  sub rsp, 0x08
00007c47757d8a03  push rax
00007c47757d8a04  push rcx
00007c47757d8a05  push rdx
00007c47757d8a06  push rdi
00007c47757d8a07  push rsi
00007c47757d8a08  push r8
00007c47757d8a0a  push r9
00007c47757d8a0c  push r10
00007c47757d8a0e  push r11
00007c47757d8a10  sub rsp, 0xF0
00007c47757d8a17  vmovaps [rsp], xmm0
00007c47757d8a1c  vmovaps [rsp+0x10], xmm1
00007c47757d8a22  vmovaps [rsp+0x20], xmm2
00007c47757d8a28  vmovaps [rsp+0x30], xmm3
00007c47757d8a2e  vmovaps [rsp+0x40], xmm4
00007c47757d8a34  vmovaps [rsp+0x50], xmm5
00007c47757d8a3a  vmovaps [rsp+0x60], xmm6
00007c47757d8a40  vmovaps [rsp+0x70], xmm7
00007c47757d8a46  vmovaps [rsp+0x80], xmm8
00007c47757d8a4f  vmovaps [rsp+0x90], xmm9
00007c47757d8a58  vmovaps [rsp+0xA0], xmm10
00007c47757d8a61  vmovaps [rsp+0xB0], xmm11
00007c47757d8a6a  vmovaps [rsp+0xC0], xmm12
00007c47757d8a73  vmovaps [rsp+0xD0], xmm13
00007c47757d8a7c  vmovaps [rsp+0xE0], xmm15
00007c47757d8a85  sub rsp, 0x30
00007c47757d8a89  movaps [rsp], xmm14
00007c47757d8a8e  movaps [rsp+0x10], xmm2
00007c47757d8a93  movaps [rsp+0x20], xmm1
00007c47757d8a98  lea rdi, [rsp]
00007c47757d8a9c  mov esi, 0x00
00007c47757d8aa1  mov rax, 0x62084E409530
00007c47757d8aab  call rax
00007c47757d8aad  movaps xmm14, [rsp]
00007c47757d8ab2  add rsp, 0x30
00007c47757d8ab6  vmovaps xmm0, [rsp]
00007c47757d8abb  vmovaps xmm1, [rsp+0x10]
00007c47757d8ac1  vmovaps xmm2, [rsp+0x20]
00007c47757d8ac7  vmovaps xmm3, [rsp+0x30]
00007c47757d8acd  vmovaps xmm4, [rsp+0x40]
00007c47757d8ad3  vmovaps xmm5, [rsp+0x50]
00007c47757d8ad9  vmovaps xmm6, [rsp+0x60]
00007c47757d8adf  vmovaps xmm7, [rsp+0x70]
00007c47757d8ae5  vmovaps xmm8, [rsp+0x80]
00007c47757d8aee  vmovaps xmm9, [rsp+0x90]
00007c47757d8af7  vmovaps xmm10, [rsp+0xA0]
00007c47757d8b00  vmovaps xmm11, [rsp+0xB0]
00007c47757d8b09  vmovaps xmm12, [rsp+0xC0]
00007c47757d8b12  vmovaps xmm13, [rsp+0xD0]
00007c47757d8b1b  vmovaps xmm15, [rsp+0xE0]
00007c47757d8b24  add rsp, 0xF0
00007c47757d8b2b  pop r11
00007c47757d8b2d  pop r10
00007c47757d8b2f  pop r9
00007c47757d8b31  pop r8
00007c47757d8b33  pop rsi
00007c47757d8b34  pop rdi
00007c47757d8b35  pop rdx
00007c47757d8b36  pop rcx
00007c47757d8b37  pop rax
00007c47757d8b38  add rsp, 0x08
00007c47757d8b3c  jmp 0x00007C47757D611D
00007c47757d8b41  sub rsp, 0x08
00007c47757d8b45  push rax
00007c47757d8b46  push rcx
00007c47757d8b47  push rdx
00007c47757d8b48  push rdi
00007c47757d8b49  push rsi
00007c47757d8b4a  push r8
00007c47757d8b4c  push r9
00007c47757d8b4e  push r10
00007c47757d8b50  push r11
00007c47757d8b52  sub rsp, 0xF0
00007c47757d8b59  vmovaps [rsp], xmm0
00007c47757d8b5e  vmovaps [rsp+0x10], xmm2
00007c47757d8b64  vmovaps [rsp+0x20], xmm3
00007c47757d8b6a  vmovaps [rsp+0x30], xmm4
00007c47757d8b70  vmovaps [rsp+0x40], xmm5
00007c47757d8b76  vmovaps [rsp+0x50], xmm6
00007c47757d8b7c  vmovaps [rsp+0x60], xmm7
00007c47757d8b82  vmovaps [rsp+0x70], xmm8
00007c47757d8b88  vmovaps [rsp+0x80], xmm9
00007c47757d8b91  vmovaps [rsp+0x90], xmm10
00007c47757d8b9a  vmovaps [rsp+0xA0], xmm11
00007c47757d8ba3  vmovaps [rsp+0xB0], xmm12
00007c47757d8bac  vmovaps [rsp+0xC0], xmm13
00007c47757d8bb5  vmovaps [rsp+0xD0], xmm14
00007c47757d8bbe  vmovaps [rsp+0xE0], xmm15
00007c47757d8bc7  sub rsp, 0x30
00007c47757d8bcb  movaps [rsp], xmm1
00007c47757d8bcf  movaps [rsp+0x10], xmm4
00007c47757d8bd4  movaps [rsp+0x20], xmm9
00007c47757d8bda  lea rdi, [rsp]
00007c47757d8bde  mov esi, 0x00
00007c47757d8be3  mov rax, 0x62084E409530
00007c47757d8bed  call rax
00007c47757d8bef  movaps xmm1, [rsp]
00007c47757d8bf3  add rsp, 0x30
00007c47757d8bf7  vmovaps xmm0, [rsp]
00007c47757d8bfc  vmovaps xmm2, [rsp+0x10]
00007c47757d8c02  vmovaps xmm3, [rsp+0x20]
00007c47757d8c08  vmovaps xmm4, [rsp+0x30]
00007c47757d8c0e  vmovaps xmm5, [rsp+0x40]
00007c47757d8c14  vmovaps xmm6, [rsp+0x50]
00007c47757d8c1a  vmovaps xmm7, [rsp+0x60]
00007c47757d8c20  vmovaps xmm8, [rsp+0x70]
00007c47757d8c26  vmovaps xmm9, [rsp+0x80]
00007c47757d8c2f  vmovaps xmm10, [rsp+0x90]
00007c47757d8c38  vmovaps xmm11, [rsp+0xA0]
00007c47757d8c41  vmovaps xmm12, [rsp+0xB0]
00007c47757d8c4a  vmovaps xmm13, [rsp+0xC0]
00007c47757d8c53  vmovaps xmm14, [rsp+0xD0]
00007c47757d8c5c  vmovaps xmm15, [rsp+0xE0]
00007c47757d8c65  add rsp, 0xF0
00007c47757d8c6c  pop r11
00007c47757d8c6e  pop r10
00007c47757d8c70  pop r9
00007c47757d8c72  pop r8
00007c47757d8c74  pop rsi
00007c47757d8c75  pop rdi
00007c47757d8c76  pop rdx
00007c47757d8c77  pop rcx
00007c47757d8c78  pop rax
00007c47757d8c79  add rsp, 0x08
00007c47757d8c7d  jmp 0x00007C47757D613B
00007c47757d8c82  sub rsp, 0x08
00007c47757d8c86  push rax
00007c47757d8c87  push rcx
00007c47757d8c88  push rdx
00007c47757d8c89  push rdi
00007c47757d8c8a  push rsi
00007c47757d8c8b  push r8
00007c47757d8c8d  push r9
00007c47757d8c8f  push r10
00007c47757d8c91  push r11
00007c47757d8c93  sub rsp, 0xF0
00007c47757d8c9a  vmovaps [rsp], xmm0
00007c47757d8c9f  vmovaps [rsp+0x10], xmm1
00007c47757d8ca5  vmovaps [rsp+0x20], xmm2
00007c47757d8cab  vmovaps [rsp+0x30], xmm3
00007c47757d8cb1  vmovaps [rsp+0x40], xmm5
00007c47757d8cb7  vmovaps [rsp+0x50], xmm6
00007c47757d8cbd  vmovaps [rsp+0x60], xmm7
00007c47757d8cc3  vmovaps [rsp+0x70], xmm8
00007c47757d8cc9  vmovaps [rsp+0x80], xmm9
00007c47757d8cd2  vmovaps [rsp+0x90], xmm10
00007c47757d8cdb  vmovaps [rsp+0xA0], xmm11
00007c47757d8ce4  vmovaps [rsp+0xB0], xmm12
00007c47757d8ced  vmovaps [rsp+0xC0], xmm13
00007c47757d8cf6  vmovaps [rsp+0xD0], xmm14
00007c47757d8cff  vmovaps [rsp+0xE0], xmm15
00007c47757d8d08  sub rsp, 0x30
00007c47757d8d0c  movaps [rsp], xmm4
00007c47757d8d10  movaps [rsp+0x10], xmm2
00007c47757d8d15  movaps [rsp+0x20], xmm9
00007c47757d8d1b  lea rdi, [rsp]
00007c47757d8d1f  mov esi, 0x00
00007c47757d8d24  mov rax, 0x62084E409530
00007c47757d8d2e  call rax
00007c47757d8d30  movaps xmm4, [rsp]
00007c47757d8d34  add rsp, 0x30
00007c47757d8d38  vmovaps xmm0, [rsp]
00007c47757d8d3d  vmovaps xmm1, [rsp+0x10]
00007c47757d8d43  vmovaps xmm2, [rsp+0x20]
00007c47757d8d49  vmovaps xmm3, [rsp+0x30]
00007c47757d8d4f  vmovaps xmm5, [rsp+0x40]
00007c47757d8d55  vmovaps xmm6, [rsp+0x50]
00007c47757d8d5b  vmovaps xmm7, [rsp+0x60]
00007c47757d8d61  vmovaps xmm8, [rsp+0x70]
00007c47757d8d67  vmovaps xmm9, [rsp+0x80]
00007c47757d8d70  vmovaps xmm10, [rsp+0x90]
00007c47757d8d79  vmovaps xmm11, [rsp+0xA0]
00007c47757d8d82  vmovaps xmm12, [rsp+0xB0]
00007c47757d8d8b  vmovaps xmm13, [rsp+0xC0]
00007c47757d8d94  vmovaps xmm14, [rsp+0xD0]
00007c47757d8d9d  vmovaps xmm15, [rsp+0xE0]
00007c47757d8da6  add rsp, 0xF0
00007c47757d8dad  pop r11
00007c47757d8daf  pop r10
00007c47757d8db1  pop r9
00007c47757d8db3  pop r8
00007c47757d8db5  pop rsi
00007c47757d8db6  pop rdi
00007c47757d8db7  pop rdx
00007c47757d8db8  pop rcx
00007c47757d8db9  pop rax
00007c47757d8dba  add rsp, 0x08
00007c47757d8dbe  jmp 0x00007C47757D616B
00007c47757d8dc3  sub rsp, 0x08
00007c47757d8dc7  push rax
00007c47757d8dc8  push rcx
00007c47757d8dc9  push rdx
00007c47757d8dca  push rdi
00007c47757d8dcb  push rsi
00007c47757d8dcc  push r8
00007c47757d8dce  push r9
00007c47757d8dd0  push r10
00007c47757d8dd2  push r11
00007c47757d8dd4  sub rsp, 0xF0
00007c47757d8ddb  vmovaps [rsp], xmm0
00007c47757d8de0  vmovaps [rsp+0x10], xmm1
00007c47757d8de6  vmovaps [rsp+0x20], xmm2
00007c47757d8dec  vmovaps [rsp+0x30], xmm3
00007c47757d8df2  vmovaps [rsp+0x40], xmm4
00007c47757d8df8  vmovaps [rsp+0x50], xmm5
00007c47757d8dfe  vmovaps [rsp+0x60], xmm6
00007c47757d8e04  vmovaps [rsp+0x70], xmm7
00007c47757d8e0a  vmovaps [rsp+0x80], xmm8
00007c47757d8e13  vmovaps [rsp+0x90], xmm10
00007c47757d8e1c  vmovaps [rsp+0xA0], xmm11
00007c47757d8e25  vmovaps [rsp+0xB0], xmm12
00007c47757d8e2e  vmovaps [rsp+0xC0], xmm13
00007c47757d8e37  vmovaps [rsp+0xD0], xmm14
00007c47757d8e40  vmovaps [rsp+0xE0], xmm15
00007c47757d8e49  sub rsp, 0x30
00007c47757d8e4d  movaps [rsp], xmm9
00007c47757d8e52  movaps [rsp+0x10], xmm2
00007c47757d8e57  movaps [rsp+0x20], xmm1
00007c47757d8e5c  lea rdi, [rsp]
00007c47757d8e60  mov esi, 0x00
00007c47757d8e65  mov rax, 0x62084E409530
00007c47757d8e6f  call rax
00007c47757d8e71  movaps xmm9, [rsp]
00007c47757d8e76  add rsp, 0x30
00007c47757d8e7a  vmovaps xmm0, [rsp]
00007c47757d8e7f  vmovaps xmm1, [rsp+0x10]
00007c47757d8e85  vmovaps xmm2, [rsp+0x20]
00007c47757d8e8b  vmovaps xmm3, [rsp+0x30]
00007c47757d8e91  vmovaps xmm4, [rsp+0x40]
00007c47757d8e97  vmovaps xmm5, [rsp+0x50]
00007c47757d8e9d  vmovaps xmm6, [rsp+0x60]
00007c47757d8ea3  vmovaps xmm7, [rsp+0x70]
00007c47757d8ea9  vmovaps xmm8, [rsp+0x80]
00007c47757d8eb2  vmovaps xmm10, [rsp+0x90]
00007c47757d8ebb  vmovaps xmm11, [rsp+0xA0]
00007c47757d8ec4  vmovaps xmm12, [rsp+0xB0]
00007c47757d8ecd  vmovaps xmm13, [rsp+0xC0]
00007c47757d8ed6  vmovaps xmm14, [rsp+0xD0]
00007c47757d8edf  vmovaps xmm15, [rsp+0xE0]
00007c47757d8ee8  add rsp, 0xF0
00007c47757d8eef  pop r11
00007c47757d8ef1  pop r10
00007c47757d8ef3  pop r9
00007c47757d8ef5  pop r8
00007c47757d8ef7  pop rsi
00007c47757d8ef8  pop rdi
00007c47757d8ef9  pop rdx
00007c47757d8efa  pop rcx
00007c47757d8efb  pop rax
00007c47757d8efc  add rsp, 0x08
00007c47757d8f00  jmp 0x00007C47757D61A1
00007c47757d8f05  sub rsp, 0x08
00007c47757d8f09  push rax
00007c47757d8f0a  push rcx
00007c47757d8f0b  push rdx
00007c47757d8f0c  push rdi
00007c47757d8f0d  push rsi
00007c47757d8f0e  push r8
00007c47757d8f10  push r9
00007c47757d8f12  push r10
00007c47757d8f14  push r11
00007c47757d8f16  sub rsp, 0xF0
00007c47757d8f1d  vmovaps [rsp], xmm0
00007c47757d8f22  vmovaps [rsp+0x10], xmm2
00007c47757d8f28  vmovaps [rsp+0x20], xmm3
00007c47757d8f2e  vmovaps [rsp+0x30], xmm4
00007c47757d8f34  vmovaps [rsp+0x40], xmm5
00007c47757d8f3a  vmovaps [rsp+0x50], xmm6
00007c47757d8f40  vmovaps [rsp+0x60], xmm7
00007c47757d8f46  vmovaps [rsp+0x70], xmm8
00007c47757d8f4c  vmovaps [rsp+0x80], xmm9
00007c47757d8f55  vmovaps [rsp+0x90], xmm10
00007c47757d8f5e  vmovaps [rsp+0xA0], xmm11
00007c47757d8f67  vmovaps [rsp+0xB0], xmm12
00007c47757d8f70  vmovaps [rsp+0xC0], xmm13
00007c47757d8f79  vmovaps [rsp+0xD0], xmm14
00007c47757d8f82  vmovaps [rsp+0xE0], xmm15
00007c47757d8f8b  sub rsp, 0x30
00007c47757d8f8f  movaps [rsp], xmm1
00007c47757d8f93  movaps [rsp+0x10], xmm15
00007c47757d8f99  movaps [rsp+0x20], xmm6
00007c47757d8f9e  lea rdi, [rsp]
00007c47757d8fa2  mov esi, 0x00
00007c47757d8fa7  mov rax, 0x62084E409530
00007c47757d8fb1  call rax
00007c47757d8fb3  movaps xmm1, [rsp]
00007c47757d8fb7  add rsp, 0x30
00007c47757d8fbb  vmovaps xmm0, [rsp]
00007c47757d8fc0  vmovaps xmm2, [rsp+0x10]
00007c47757d8fc6  vmovaps xmm3, [rsp+0x20]
00007c47757d8fcc  vmovaps xmm4, [rsp+0x30]
00007c47757d8fd2  vmovaps xmm5, [rsp+0x40]
00007c47757d8fd8  vmovaps xmm6, [rsp+0x50]
00007c47757d8fde  vmovaps xmm7, [rsp+0x60]
00007c47757d8fe4  vmovaps xmm8, [rsp+0x70]
00007c47757d8fea  vmovaps xmm9, [rsp+0x80]
00007c47757d8ff3  vmovaps xmm10, [rsp+0x90]
00007c47757d8ffc  vmovaps xmm11, [rsp+0xA0]
00007c47757d9005  vmovaps xmm12, [rsp+0xB0]
00007c47757d900e  vmovaps xmm13, [rsp+0xC0]
00007c47757d9017  vmovaps xmm14, [rsp+0xD0]
00007c47757d9020  vmovaps xmm15, [rsp+0xE0]
00007c47757d9029  add rsp, 0xF0
00007c47757d9030  pop r11
00007c47757d9032  pop r10
00007c47757d9034  pop r9
00007c47757d9036  pop r8
00007c47757d9038  pop rsi
00007c47757d9039  pop rdi
00007c47757d903a  pop rdx
00007c47757d903b  pop rcx
00007c47757d903c  pop rax
00007c47757d903d  add rsp, 0x08
00007c47757d9041  jmp 0x00007C47757D61C2
00007c47757d9046  sub rsp, 0x08
00007c47757d904a  push rax
00007c47757d904b  push rcx
00007c47757d904c  push rdx
00007c47757d904d  push rdi
00007c47757d904e  push rsi
00007c47757d904f  push r8
00007c47757d9051  push r9
00007c47757d9053  push r10
00007c47757d9055  push r11
00007c47757d9057  sub rsp, 0xF0
00007c47757d905e  vmovaps [rsp], xmm0
00007c47757d9063  vmovaps [rsp+0x10], xmm1
00007c47757d9069  vmovaps [rsp+0x20], xmm2
00007c47757d906f  vmovaps [rsp+0x30], xmm3
00007c47757d9075  vmovaps [rsp+0x40], xmm4
00007c47757d907b  vmovaps [rsp+0x50], xmm5
00007c47757d9081  vmovaps [rsp+0x60], xmm6
00007c47757d9087  vmovaps [rsp+0x70], xmm7
00007c47757d908d  vmovaps [rsp+0x80], xmm8
00007c47757d9096  vmovaps [rsp+0x90], xmm9
00007c47757d909f  vmovaps [rsp+0xA0], xmm10
00007c47757d90a8  vmovaps [rsp+0xB0], xmm11
00007c47757d90b1  vmovaps [rsp+0xC0], xmm12
00007c47757d90ba  vmovaps [rsp+0xD0], xmm13
00007c47757d90c3  vmovaps [rsp+0xE0], xmm14
00007c47757d90cc  sub rsp, 0x30
00007c47757d90d0  movaps [rsp], xmm15
00007c47757d90d5  movaps [rsp+0x10], xmm5
00007c47757d90da  movaps [rsp+0x20], xmm3
00007c47757d90df  lea rdi, [rsp]
00007c47757d90e3  mov esi, 0x00
00007c47757d90e8  mov rax, 0x62084E409530
00007c47757d90f2  call rax
00007c47757d90f4  movaps xmm15, [rsp]
00007c47757d90f9  add rsp, 0x30
00007c47757d90fd  vmovaps xmm0, [rsp]
00007c47757d9102  vmovaps xmm1, [rsp+0x10]
00007c47757d9108  vmovaps xmm2, [rsp+0x20]
00007c47757d910e  vmovaps xmm3, [rsp+0x30]
00007c47757d9114  vmovaps xmm4, [rsp+0x40]
00007c47757d911a  vmovaps xmm5, [rsp+0x50]
00007c47757d9120  vmovaps xmm6, [rsp+0x60]
00007c47757d9126  vmovaps xmm7, [rsp+0x70]
00007c47757d912c  vmovaps xmm8, [rsp+0x80]
00007c47757d9135  vmovaps xmm9, [rsp+0x90]
00007c47757d913e  vmovaps xmm10, [rsp+0xA0]
00007c47757d9147  vmovaps xmm11, [rsp+0xB0]
00007c47757d9150  vmovaps xmm12, [rsp+0xC0]
00007c47757d9159  vmovaps xmm13, [rsp+0xD0]
00007c47757d9162  vmovaps xmm14, [rsp+0xE0]
00007c47757d916b  add rsp, 0xF0
00007c47757d9172  pop r11
00007c47757d9174  pop r10
00007c47757d9176  pop r9
00007c47757d9178  pop r8
00007c47757d917a  pop rsi
00007c47757d917b  pop rdi
00007c47757d917c  pop rdx
00007c47757d917d  pop rcx
00007c47757d917e  pop rax
00007c47757d917f  add rsp, 0x08
00007c47757d9183  jmp 0x00007C47757D61DC
00007c47757d9188  sub rsp, 0x08
00007c47757d918c  push rax
00007c47757d918d  push rcx
00007c47757d918e  push rdx
00007c47757d918f  push rdi
00007c47757d9190  push rsi
00007c47757d9191  push r8
00007c47757d9193  push r9
00007c47757d9195  push r10
00007c47757d9197  push r11
00007c47757d9199  sub rsp, 0xF0
00007c47757d91a0  vmovaps [rsp], xmm0
00007c47757d91a5  vmovaps [rsp+0x10], xmm1
00007c47757d91ab  vmovaps [rsp+0x20], xmm2
00007c47757d91b1  vmovaps [rsp+0x30], xmm3
00007c47757d91b7  vmovaps [rsp+0x40], xmm4
00007c47757d91bd  vmovaps [rsp+0x50], xmm6
00007c47757d91c3  vmovaps [rsp+0x60], xmm7
00007c47757d91c9  vmovaps [rsp+0x70], xmm8
00007c47757d91cf  vmovaps [rsp+0x80], xmm9
00007c47757d91d8  vmovaps [rsp+0x90], xmm10
00007c47757d91e1  vmovaps [rsp+0xA0], xmm11
00007c47757d91ea  vmovaps [rsp+0xB0], xmm12
00007c47757d91f3  vmovaps [rsp+0xC0], xmm13
00007c47757d91fc  vmovaps [rsp+0xD0], xmm14
00007c47757d9205  vmovaps [rsp+0xE0], xmm15
00007c47757d920e  sub rsp, 0x30
00007c47757d9212  movaps [rsp], xmm5
00007c47757d9216  movaps [rsp+0x10], xmm8
00007c47757d921c  movaps [rsp+0x20], xmm6
00007c47757d9221  lea rdi, [rsp]
00007c47757d9225  mov esi, 0x00
00007c47757d922a  mov rax, 0x62084E409530
00007c47757d9234  call rax
00007c47757d9236  movaps xmm5, [rsp]
00007c47757d923a  add rsp, 0x30
00007c47757d923e  vmovaps xmm0, [rsp]
00007c47757d9243  vmovaps xmm1, [rsp+0x10]
00007c47757d9249  vmovaps xmm2, [rsp+0x20]
00007c47757d924f  vmovaps xmm3, [rsp+0x30]
00007c47757d9255  vmovaps xmm4, [rsp+0x40]
00007c47757d925b  vmovaps xmm6, [rsp+0x50]
00007c47757d9261  vmovaps xmm7, [rsp+0x60]
00007c47757d9267  vmovaps xmm8, [rsp+0x70]
00007c47757d926d  vmovaps xmm9, [rsp+0x80]
00007c47757d9276  vmovaps xmm10, [rsp+0x90]
00007c47757d927f  vmovaps xmm11, [rsp+0xA0]
00007c47757d9288  vmovaps xmm12, [rsp+0xB0]
00007c47757d9291  vmovaps xmm13, [rsp+0xC0]
00007c47757d929a  vmovaps xmm14, [rsp+0xD0]
00007c47757d92a3  vmovaps xmm15, [rsp+0xE0]
00007c47757d92ac  add rsp, 0xF0
00007c47757d92b3  pop r11
00007c47757d92b5  pop r10
00007c47757d92b7  pop r9
00007c47757d92b9  pop r8
00007c47757d92bb  pop rsi
00007c47757d92bc  pop rdi
00007c47757d92bd  pop rdx
00007c47757d92be  pop rcx
00007c47757d92bf  pop rax
00007c47757d92c0  add rsp, 0x08
00007c47757d92c4  jmp 0x00007C47757D6200
00007c47757d92c9  sub rsp, 0x08
00007c47757d92cd  push rax
00007c47757d92ce  push rcx
00007c47757d92cf  push rdx
00007c47757d92d0  push rdi
00007c47757d92d1  push rsi
00007c47757d92d2  push r8
00007c47757d92d4  push r9
00007c47757d92d6  push r10
00007c47757d92d8  push r11
00007c47757d92da  sub rsp, 0xF0
00007c47757d92e1  vmovaps [rsp], xmm0
00007c47757d92e6  vmovaps [rsp+0x10], xmm1
00007c47757d92ec  vmovaps [rsp+0x20], xmm2
00007c47757d92f2  vmovaps [rsp+0x30], xmm3
00007c47757d92f8  vmovaps [rsp+0x40], xmm4
00007c47757d92fe  vmovaps [rsp+0x50], xmm5
00007c47757d9304  vmovaps [rsp+0x60], xmm7
00007c47757d930a  vmovaps [rsp+0x70], xmm8
00007c47757d9310  vmovaps [rsp+0x80], xmm9
00007c47757d9319  vmovaps [rsp+0x90], xmm10
00007c47757d9322  vmovaps [rsp+0xA0], xmm11
00007c47757d932b  vmovaps [rsp+0xB0], xmm12
00007c47757d9334  vmovaps [rsp+0xC0], xmm13
00007c47757d933d  vmovaps [rsp+0xD0], xmm14
00007c47757d9346  vmovaps [rsp+0xE0], xmm15
00007c47757d934f  sub rsp, 0x30
00007c47757d9353  movaps [rsp], xmm6
00007c47757d9357  movaps [rsp+0x10], xmm10
00007c47757d935d  movaps [rsp+0x20], xmm8
00007c47757d9363  lea rdi, [rsp]
00007c47757d9367  mov esi, 0x00
00007c47757d936c  mov rax, 0x62084E409530
00007c47757d9376  call rax
00007c47757d9378  movaps xmm6, [rsp]
00007c47757d937c  add rsp, 0x30
00007c47757d9380  vmovaps xmm0, [rsp]
00007c47757d9385  vmovaps xmm1, [rsp+0x10]
00007c47757d938b  vmovaps xmm2, [rsp+0x20]
00007c47757d9391  vmovaps xmm3, [rsp+0x30]
00007c47757d9397  vmovaps xmm4, [rsp+0x40]
00007c47757d939d  vmovaps xmm5, [rsp+0x50]
00007c47757d93a3  vmovaps xmm7, [rsp+0x60]
00007c47757d93a9  vmovaps xmm8, [rsp+0x70]
00007c47757d93af  vmovaps xmm9, [rsp+0x80]
00007c47757d93b8  vmovaps xmm10, [rsp+0x90]
00007c47757d93c1  vmovaps xmm11, [rsp+0xA0]
00007c47757d93ca  vmovaps xmm12, [rsp+0xB0]
00007c47757d93d3  vmovaps xmm13, [rsp+0xC0]
00007c47757d93dc  vmovaps xmm14, [rsp+0xD0]
00007c47757d93e5  vmovaps xmm15, [rsp+0xE0]
00007c47757d93ee  add rsp, 0xF0
00007c47757d93f5  pop r11
00007c47757d93f7  pop r10
00007c47757d93f9  pop r9
00007c47757d93fb  pop r8
00007c47757d93fd  pop rsi
00007c47757d93fe  pop rdi
00007c47757d93ff  pop rdx
00007c47757d9400  pop rcx
00007c47757d9401  pop rax
00007c47757d9402  add rsp, 0x08
00007c47757d9406  jmp 0x00007C47757D6225
00007c47757d940b  sub rsp, 0x08
00007c47757d940f  push rax
00007c47757d9410  push rcx
00007c47757d9411  push rdx
00007c47757d9412  push rdi
00007c47757d9413  push rsi
00007c47757d9414  push r8
00007c47757d9416  push r9
00007c47757d9418  push r10
00007c47757d941a  push r11
00007c47757d941c  sub rsp, 0xF0
00007c47757d9423  vmovaps [rsp], xmm0
00007c47757d9428  vmovaps [rsp+0x10], xmm1
00007c47757d942e  vmovaps [rsp+0x20], xmm2
00007c47757d9434  vmovaps [rsp+0x30], xmm3
00007c47757d943a  vmovaps [rsp+0x40], xmm4
00007c47757d9440  vmovaps [rsp+0x50], xmm5
00007c47757d9446  vmovaps [rsp+0x60], xmm6
00007c47757d944c  vmovaps [rsp+0x70], xmm7
00007c47757d9452  vmovaps [rsp+0x80], xmm8
00007c47757d945b  vmovaps [rsp+0x90], xmm9
00007c47757d9464  vmovaps [rsp+0xA0], xmm11
00007c47757d946d  vmovaps [rsp+0xB0], xmm12
00007c47757d9476  vmovaps [rsp+0xC0], xmm13
00007c47757d947f  vmovaps [rsp+0xD0], xmm14
00007c47757d9488  vmovaps [rsp+0xE0], xmm15
00007c47757d9491  sub rsp, 0x30
00007c47757d9495  movaps [rsp], xmm10
00007c47757d949a  movaps [rsp+0x10], xmm8
00007c47757d94a0  movaps [rsp+0x20], xmm14
00007c47757d94a6  lea rdi, [rsp]
00007c47757d94aa  mov esi, 0x00
00007c47757d94af  mov rax, 0x62084E409530
00007c47757d94b9  call rax
00007c47757d94bb  movaps xmm10, [rsp]
00007c47757d94c0  add rsp, 0x30
00007c47757d94c4  vmovaps xmm0, [rsp]
00007c47757d94c9  vmovaps xmm1, [rsp+0x10]
00007c47757d94cf  vmovaps xmm2, [rsp+0x20]
00007c47757d94d5  vmovaps xmm3, [rsp+0x30]
00007c47757d94db  vmovaps xmm4, [rsp+0x40]
00007c47757d94e1  vmovaps xmm5, [rsp+0x50]
00007c47757d94e7  vmovaps xmm6, [rsp+0x60]
00007c47757d94ed  vmovaps xmm7, [rsp+0x70]
00007c47757d94f3  vmovaps xmm8, [rsp+0x80]
00007c47757d94fc  vmovaps xmm9, [rsp+0x90]
00007c47757d9505  vmovaps xmm11, [rsp+0xA0]
00007c47757d950e  vmovaps xmm12, [rsp+0xB0]
00007c47757d9517  vmovaps xmm13, [rsp+0xC0]
00007c47757d9520  vmovaps xmm14, [rsp+0xD0]
00007c47757d9529  vmovaps xmm15, [rsp+0xE0]
00007c47757d9532  add rsp, 0xF0
00007c47757d9539  pop r11
00007c47757d953b  pop r10
00007c47757d953d  pop r9
00007c47757d953f  pop r8
00007c47757d9541  pop rsi
00007c47757d9542  pop rdi
00007c47757d9543  pop rdx
00007c47757d9544  pop rcx
00007c47757d9545  pop rax
00007c47757d9546  add rsp, 0x08
00007c47757d954a  jmp 0x00007C47757D6245
00007c47757d954f  sub rsp, 0x08
00007c47757d9553  push rax
00007c47757d9554  push rcx
00007c47757d9555  push rdx
00007c47757d9556  push rdi
00007c47757d9557  push rsi
00007c47757d9558  push r8
00007c47757d955a  push r9
00007c47757d955c  push r10
00007c47757d955e  push r11
00007c47757d9560  sub rsp, 0xF0
00007c47757d9567  vmovaps [rsp], xmm0
00007c47757d956c  vmovaps [rsp+0x10], xmm1
00007c47757d9572  vmovaps [rsp+0x20], xmm2
00007c47757d9578  vmovaps [rsp+0x30], xmm3
00007c47757d957e  vmovaps [rsp+0x40], xmm4
00007c47757d9584  vmovaps [rsp+0x50], xmm5
00007c47757d958a  vmovaps [rsp+0x60], xmm6
00007c47757d9590  vmovaps [rsp+0x70], xmm7
00007c47757d9596  vmovaps [rsp+0x80], xmm8
00007c47757d959f  vmovaps [rsp+0x90], xmm9
00007c47757d95a8  vmovaps [rsp+0xA0], xmm10
00007c47757d95b1  vmovaps [rsp+0xB0], xmm11
00007c47757d95ba  vmovaps [rsp+0xC0], xmm12
00007c47757d95c3  vmovaps [rsp+0xD0], xmm13
00007c47757d95cc  vmovaps [rsp+0xE0], xmm15
00007c47757d95d5  sub rsp, 0x30
00007c47757d95d9  movaps [rsp], xmm14
00007c47757d95de  movaps [rsp+0x10], xmm8
00007c47757d95e4  movaps [rsp+0x20], xmm4
00007c47757d95e9  lea rdi, [rsp]
00007c47757d95ed  mov esi, 0x00
00007c47757d95f2  mov rax, 0x62084E409530
00007c47757d95fc  call rax
00007c47757d95fe  movaps xmm14, [rsp]
00007c47757d9603  add rsp, 0x30
00007c47757d9607  vmovaps xmm0, [rsp]
00007c47757d960c  vmovaps xmm1, [rsp+0x10]
00007c47757d9612  vmovaps xmm2, [rsp+0x20]
00007c47757d9618  vmovaps xmm3, [rsp+0x30]
00007c47757d961e  vmovaps xmm4, [rsp+0x40]
00007c47757d9624  vmovaps xmm5, [rsp+0x50]
00007c47757d962a  vmovaps xmm6, [rsp+0x60]
00007c47757d9630  vmovaps xmm7, [rsp+0x70]
00007c47757d9636  vmovaps xmm8, [rsp+0x80]
00007c47757d963f  vmovaps xmm9, [rsp+0x90]
00007c47757d9648  vmovaps xmm10, [rsp+0xA0]
00007c47757d9651  vmovaps xmm11, [rsp+0xB0]
00007c47757d965a  vmovaps xmm12, [rsp+0xC0]
00007c47757d9663  vmovaps xmm13, [rsp+0xD0]
00007c47757d966c  vmovaps xmm15, [rsp+0xE0]
00007c47757d9675  add rsp, 0xF0
00007c47757d967c  pop r11
00007c47757d967e  pop r10
00007c47757d9680  pop r9
00007c47757d9682  pop r8
00007c47757d9684  pop rsi
00007c47757d9685  pop rdi
00007c47757d9686  pop rdx
00007c47757d9687  pop rcx
00007c47757d9688  pop rax
00007c47757d9689  add rsp, 0x08
00007c47757d968d  jmp 0x00007C47757D6265
00007c47757d9692  sub rsp, 0x08
00007c47757d9696  push rax
00007c47757d9697  push rcx
00007c47757d9698  push rdx
00007c47757d9699  push rdi
00007c47757d969a  push rsi
00007c47757d969b  push r8
00007c47757d969d  push r9
00007c47757d969f  push r10
00007c47757d96a1  push r11
00007c47757d96a3  sub rsp, 0xF0
00007c47757d96aa  vmovaps [rsp], xmm0
00007c47757d96af  vmovaps [rsp+0x10], xmm1
00007c47757d96b5  vmovaps [rsp+0x20], xmm2
00007c47757d96bb  vmovaps [rsp+0x30], xmm3
00007c47757d96c1  vmovaps [rsp+0x40], xmm5
00007c47757d96c7  vmovaps [rsp+0x50], xmm6
00007c47757d96cd  vmovaps [rsp+0x60], xmm7
00007c47757d96d3  vmovaps [rsp+0x70], xmm8
00007c47757d96d9  vmovaps [rsp+0x80], xmm9
00007c47757d96e2  vmovaps [rsp+0x90], xmm10
00007c47757d96eb  vmovaps [rsp+0xA0], xmm11
00007c47757d96f4  vmovaps [rsp+0xB0], xmm12
00007c47757d96fd  vmovaps [rsp+0xC0], xmm13
00007c47757d9706  vmovaps [rsp+0xD0], xmm14
00007c47757d970f  vmovaps [rsp+0xE0], xmm15
00007c47757d9718  sub rsp, 0x30
00007c47757d971c  movaps [rsp], xmm4
00007c47757d9720  movaps [rsp+0x10], xmm13
00007c47757d9726  movaps [rsp+0x20], xmm8
00007c47757d972c  lea rdi, [rsp]
00007c47757d9730  mov esi, 0x00
00007c47757d9735  mov rax, 0x62084E409530
00007c47757d973f  call rax
00007c47757d9741  movaps xmm4, [rsp]
00007c47757d9745  add rsp, 0x30
00007c47757d9749  vmovaps xmm0, [rsp]
00007c47757d974e  vmovaps xmm1, [rsp+0x10]
00007c47757d9754  vmovaps xmm2, [rsp+0x20]
00007c47757d975a  vmovaps xmm3, [rsp+0x30]
00007c47757d9760  vmovaps xmm5, [rsp+0x40]
00007c47757d9766  vmovaps xmm6, [rsp+0x50]
00007c47757d976c  vmovaps xmm7, [rsp+0x60]
00007c47757d9772  vmovaps xmm8, [rsp+0x70]
00007c47757d9778  vmovaps xmm9, [rsp+0x80]
00007c47757d9781  vmovaps xmm10, [rsp+0x90]
00007c47757d978a  vmovaps xmm11, [rsp+0xA0]
00007c47757d9793  vmovaps xmm12, [rsp+0xB0]
00007c47757d979c  vmovaps xmm13, [rsp+0xC0]
00007c47757d97a5  vmovaps xmm14, [rsp+0xD0]
00007c47757d97ae  vmovaps xmm15, [rsp+0xE0]
00007c47757d97b7  add rsp, 0xF0
00007c47757d97be  pop r11
00007c47757d97c0  pop r10
00007c47757d97c2  pop r9
00007c47757d97c4  pop r8
00007c47757d97c6  pop rsi
00007c47757d97c7  pop rdi
00007c47757d97c8  pop rdx
00007c47757d97c9  pop rcx
00007c47757d97ca  pop rax
00007c47757d97cb  add rsp, 0x08
00007c47757d97cf  jmp 0x00007C47757D628A
00007c47757d97d4  sub rsp, 0x08
00007c47757d97d8  push rax
00007c47757d97d9  push rcx
00007c47757d97da  push rdx
00007c47757d97db  push rdi
00007c47757d97dc  push rsi
00007c47757d97dd  push r8
00007c47757d97df  push r9
00007c47757d97e1  push r10
00007c47757d97e3  push r11
00007c47757d97e5  sub rsp, 0xF0
00007c47757d97ec  vmovaps [rsp], xmm0
00007c47757d97f1  vmovaps [rsp+0x10], xmm1
00007c47757d97f7  vmovaps [rsp+0x20], xmm2
00007c47757d97fd  vmovaps [rsp+0x30], xmm3
00007c47757d9803  vmovaps [rsp+0x40], xmm4
00007c47757d9809  vmovaps [rsp+0x50], xmm5
00007c47757d980f  vmovaps [rsp+0x60], xmm6
00007c47757d9815  vmovaps [rsp+0x70], xmm7
00007c47757d981b  vmovaps [rsp+0x80], xmm8
00007c47757d9824  vmovaps [rsp+0x90], xmm9
00007c47757d982d  vmovaps [rsp+0xA0], xmm10
00007c47757d9836  vmovaps [rsp+0xB0], xmm11
00007c47757d983f  vmovaps [rsp+0xC0], xmm12
00007c47757d9848  vmovaps [rsp+0xD0], xmm14
00007c47757d9851  vmovaps [rsp+0xE0], xmm15
00007c47757d985a  sub rsp, 0x30
00007c47757d985e  movaps [rsp], xmm13
00007c47757d9863  movaps [rsp+0x10], xmm15
00007c47757d9869  movaps [rsp+0x20], xmm9
00007c47757d986f  lea rdi, [rsp]
00007c47757d9873  mov esi, 0x00
00007c47757d9878  mov rax, 0x62084E409530
00007c47757d9882  call rax
00007c47757d9884  movaps xmm13, [rsp]
00007c47757d9889  add rsp, 0x30
00007c47757d988d  vmovaps xmm0, [rsp]
00007c47757d9892  vmovaps xmm1, [rsp+0x10]
00007c47757d9898  vmovaps xmm2, [rsp+0x20]
00007c47757d989e  vmovaps xmm3, [rsp+0x30]
00007c47757d98a4  vmovaps xmm4, [rsp+0x40]
00007c47757d98aa  vmovaps xmm5, [rsp+0x50]
00007c47757d98b0  vmovaps xmm6, [rsp+0x60]
00007c47757d98b6  vmovaps xmm7, [rsp+0x70]
00007c47757d98bc  vmovaps xmm8, [rsp+0x80]
00007c47757d98c5  vmovaps xmm9, [rsp+0x90]
00007c47757d98ce  vmovaps xmm10, [rsp+0xA0]
00007c47757d98d7  vmovaps xmm11, [rsp+0xB0]
00007c47757d98e0  vmovaps xmm12, [rsp+0xC0]
00007c47757d98e9  vmovaps xmm14, [rsp+0xD0]
00007c47757d98f2  vmovaps xmm15, [rsp+0xE0]
00007c47757d98fb  add rsp, 0xF0
00007c47757d9902  pop r11
00007c47757d9904  pop r10
00007c47757d9906  pop r9
00007c47757d9908  pop r8
00007c47757d990a  pop rsi
00007c47757d990b  pop rdi
00007c47757d990c  pop rdx
00007c47757d990d  pop rcx
00007c47757d990e  pop rax
00007c47757d990f  add rsp, 0x08
00007c47757d9913  jmp 0x00007C47757D62A5
00007c47757d9918  sub rsp, 0x08
00007c47757d991c  push rax
00007c47757d991d  push rcx
00007c47757d991e  push rdx
00007c47757d991f  push rdi
00007c47757d9920  push rsi
00007c47757d9921  push r8
00007c47757d9923  push r9
00007c47757d9925  push r10
00007c47757d9927  push r11
00007c47757d9929  sub rsp, 0xF0
00007c47757d9930  vmovaps [rsp], xmm0
00007c47757d9935  vmovaps [rsp+0x10], xmm1
00007c47757d993b  vmovaps [rsp+0x20], xmm2
00007c47757d9941  vmovaps [rsp+0x30], xmm3
00007c47757d9947  vmovaps [rsp+0x40], xmm4
00007c47757d994d  vmovaps [rsp+0x50], xmm5
00007c47757d9953  vmovaps [rsp+0x60], xmm6
00007c47757d9959  vmovaps [rsp+0x70], xmm7
00007c47757d995f  vmovaps [rsp+0x80], xmm8
00007c47757d9968  vmovaps [rsp+0x90], xmm9
00007c47757d9971  vmovaps [rsp+0xA0], xmm10
00007c47757d997a  vmovaps [rsp+0xB0], xmm11
00007c47757d9983  vmovaps [rsp+0xC0], xmm12
00007c47757d998c  vmovaps [rsp+0xD0], xmm13
00007c47757d9995  vmovaps [rsp+0xE0], xmm14
00007c47757d999e  sub rsp, 0x30
00007c47757d99a2  movaps [rsp], xmm15
00007c47757d99a7  movaps [rsp+0x10], xmm1
00007c47757d99ac  movaps [rsp+0x20], xmm5
00007c47757d99b1  lea rdi, [rsp]
00007c47757d99b5  mov esi, 0x00
00007c47757d99ba  mov rax, 0x62084E409530
00007c47757d99c4  call rax
00007c47757d99c6  movaps xmm15, [rsp]
00007c47757d99cb  add rsp, 0x30
00007c47757d99cf  vmovaps xmm0, [rsp]
00007c47757d99d4  vmovaps xmm1, [rsp+0x10]
00007c47757d99da  vmovaps xmm2, [rsp+0x20]
00007c47757d99e0  vmovaps xmm3, [rsp+0x30]
00007c47757d99e6  vmovaps xmm4, [rsp+0x40]
00007c47757d99ec  vmovaps xmm5, [rsp+0x50]
00007c47757d99f2  vmovaps xmm6, [rsp+0x60]
00007c47757d99f8  vmovaps xmm7, [rsp+0x70]
00007c47757d99fe  vmovaps xmm8, [rsp+0x80]
00007c47757d9a07  vmovaps xmm9, [rsp+0x90]
00007c47757d9a10  vmovaps xmm10, [rsp+0xA0]
00007c47757d9a19  vmovaps xmm11, [rsp+0xB0]
00007c47757d9a22  vmovaps xmm12, [rsp+0xC0]
00007c47757d9a2b  vmovaps xmm13, [rsp+0xD0]
00007c47757d9a34  vmovaps xmm14, [rsp+0xE0]
00007c47757d9a3d  add rsp, 0xF0
00007c47757d9a44  pop r11
00007c47757d9a46  pop r10
00007c47757d9a48  pop r9
00007c47757d9a4a  pop r8
00007c47757d9a4c  pop rsi
00007c47757d9a4d  pop rdi
00007c47757d9a4e  pop rdx
00007c47757d9a4f  pop rcx
00007c47757d9a50  pop rax
00007c47757d9a51  add rsp, 0x08
00007c47757d9a55  jmp 0x00007C47757D62C0
00007c47757d9a5a  call 0x00007C47756D64F0
00007c47757d9a5f  jmp 0x00007C47757D631B
00007c47757d9a64  sub rsp, 0x08
00007c47757d9a68  push rax
00007c47757d9a69  push rcx
00007c47757d9a6a  push rdx
00007c47757d9a6b  push rdi
00007c47757d9a6c  push rsi
00007c47757d9a6d  push r8
00007c47757d9a6f  push r9
00007c47757d9a71  push r10
00007c47757d9a73  push r11
00007c47757d9a75  sub rsp, 0xF0
00007c47757d9a7c  vmovaps [rsp], xmm0
00007c47757d9a81  vmovaps [rsp+0x10], xmm1
00007c47757d9a87  vmovaps [rsp+0x20], xmm2
00007c47757d9a8d  vmovaps [rsp+0x30], xmm3
00007c47757d9a93  vmovaps [rsp+0x40], xmm4
00007c47757d9a99  vmovaps [rsp+0x50], xmm5
00007c47757d9a9f  vmovaps [rsp+0x60], xmm6
00007c47757d9aa5  vmovaps [rsp+0x70], xmm7
00007c47757d9aab  vmovaps [rsp+0x80], xmm8
00007c47757d9ab4  vmovaps [rsp+0x90], xmm10
00007c47757d9abd  vmovaps [rsp+0xA0], xmm11
00007c47757d9ac6  vmovaps [rsp+0xB0], xmm12
00007c47757d9acf  vmovaps [rsp+0xC0], xmm13
00007c47757d9ad8  vmovaps [rsp+0xD0], xmm14
00007c47757d9ae1  vmovaps [rsp+0xE0], xmm15
00007c47757d9aea  sub rsp, 0x30
00007c47757d9aee  movaps [rsp], xmm9
00007c47757d9af3  movaps [rsp+0x10], xmm8
00007c47757d9af9  movaps [rsp+0x20], xmm11
00007c47757d9aff  lea rdi, [rsp]
00007c47757d9b03  mov esi, 0x00
00007c47757d9b08  mov rax, 0x62084E409530
00007c47757d9b12  call rax
00007c47757d9b14  movaps xmm9, [rsp]
00007c47757d9b19  add rsp, 0x30
00007c47757d9b1d  vmovaps xmm0, [rsp]
00007c47757d9b22  vmovaps xmm1, [rsp+0x10]
00007c47757d9b28  vmovaps xmm2, [rsp+0x20]
00007c47757d9b2e  vmovaps xmm3, [rsp+0x30]
00007c47757d9b34  vmovaps xmm4, [rsp+0x40]
00007c47757d9b3a  vmovaps xmm5, [rsp+0x50]
00007c47757d9b40  vmovaps xmm6, [rsp+0x60]
00007c47757d9b46  vmovaps xmm7, [rsp+0x70]
00007c47757d9b4c  vmovaps xmm8, [rsp+0x80]
00007c47757d9b55  vmovaps xmm10, [rsp+0x90]
00007c47757d9b5e  vmovaps xmm11, [rsp+0xA0]
00007c47757d9b67  vmovaps xmm12, [rsp+0xB0]
00007c47757d9b70  vmovaps xmm13, [rsp+0xC0]
00007c47757d9b79  vmovaps xmm14, [rsp+0xD0]
00007c47757d9b82  vmovaps xmm15, [rsp+0xE0]
00007c47757d9b8b  add rsp, 0xF0
00007c47757d9b92  pop r11
00007c47757d9b94  pop r10
00007c47757d9b96  pop r9
00007c47757d9b98  pop r8
00007c47757d9b9a  pop rsi
00007c47757d9b9b  pop rdi
00007c47757d9b9c  pop rdx
00007c47757d9b9d  pop rcx
00007c47757d9b9e  pop rax
00007c47757d9b9f  add rsp, 0x08
00007c47757d9ba3  jmp 0x00007C47757D6352
00007c47757d9ba8  sub rsp, 0x08
00007c47757d9bac  push rax
00007c47757d9bad  push rcx
00007c47757d9bae  push rdx
00007c47757d9baf  push rdi
00007c47757d9bb0  push rsi
00007c47757d9bb1  push r8
00007c47757d9bb3  push r9
00007c47757d9bb5  push r10
00007c47757d9bb7  push r11
00007c47757d9bb9  sub rsp, 0xF0
00007c47757d9bc0  vmovaps [rsp], xmm0
00007c47757d9bc5  vmovaps [rsp+0x10], xmm1
00007c47757d9bcb  vmovaps [rsp+0x20], xmm2
00007c47757d9bd1  vmovaps [rsp+0x30], xmm3
00007c47757d9bd7  vmovaps [rsp+0x40], xmm4
00007c47757d9bdd  vmovaps [rsp+0x50], xmm5
00007c47757d9be3  vmovaps [rsp+0x60], xmm6
00007c47757d9be9  vmovaps [rsp+0x70], xmm7
00007c47757d9bef  vmovaps [rsp+0x80], xmm8
00007c47757d9bf8  vmovaps [rsp+0x90], xmm9
00007c47757d9c01  vmovaps [rsp+0xA0], xmm10
00007c47757d9c0a  vmovaps [rsp+0xB0], xmm12
00007c47757d9c13  vmovaps [rsp+0xC0], xmm13
00007c47757d9c1c  vmovaps [rsp+0xD0], xmm14
00007c47757d9c25  vmovaps [rsp+0xE0], xmm15
00007c47757d9c2e  sub rsp, 0x30
00007c47757d9c32  movaps [rsp], xmm11
00007c47757d9c37  movaps [rsp+0x10], xmm10
00007c47757d9c3d  movaps [rsp+0x20], xmm6
00007c47757d9c42  lea rdi, [rsp]
00007c47757d9c46  mov esi, 0x00
00007c47757d9c4b  mov rax, 0x62084E409530
00007c47757d9c55  call rax
00007c47757d9c57  movaps xmm11, [rsp]
00007c47757d9c5c  add rsp, 0x30
00007c47757d9c60  vmovaps xmm0, [rsp]
00007c47757d9c65  vmovaps xmm1, [rsp+0x10]
00007c47757d9c6b  vmovaps xmm2, [rsp+0x20]
00007c47757d9c71  vmovaps xmm3, [rsp+0x30]
00007c47757d9c77  vmovaps xmm4, [rsp+0x40]
00007c47757d9c7d  vmovaps xmm5, [rsp+0x50]
00007c47757d9c83  vmovaps xmm6, [rsp+0x60]
00007c47757d9c89  vmovaps xmm7, [rsp+0x70]
00007c47757d9c8f  vmovaps xmm8, [rsp+0x80]
00007c47757d9c98  vmovaps xmm9, [rsp+0x90]
00007c47757d9ca1  vmovaps xmm10, [rsp+0xA0]
00007c47757d9caa  vmovaps xmm12, [rsp+0xB0]
00007c47757d9cb3  vmovaps xmm13, [rsp+0xC0]
00007c47757d9cbc  vmovaps xmm14, [rsp+0xD0]
00007c47757d9cc5  vmovaps xmm15, [rsp+0xE0]
00007c47757d9cce  add rsp, 0xF0
00007c47757d9cd5  pop r11
00007c47757d9cd7  pop r10
00007c47757d9cd9  pop r9
00007c47757d9cdb  pop r8
00007c47757d9cdd  pop rsi
00007c47757d9cde  pop rdi
00007c47757d9cdf  pop rdx
00007c47757d9ce0  pop rcx
00007c47757d9ce1  pop rax
00007c47757d9ce2  add rsp, 0x08
00007c47757d9ce6  jmp 0x00007C47757D636D
00007c47757d9ceb  sub rsp, 0x08
00007c47757d9cef  push rax
00007c47757d9cf0  push rcx
00007c47757d9cf1  push rdx
00007c47757d9cf2  push rdi
00007c47757d9cf3  push rsi
00007c47757d9cf4  push r8
00007c47757d9cf6  push r9
00007c47757d9cf8  push r10
00007c47757d9cfa  push r11
00007c47757d9cfc  sub rsp, 0xF0
00007c47757d9d03  vmovaps [rsp], xmm0
00007c47757d9d08  vmovaps [rsp+0x10], xmm1
00007c47757d9d0e  vmovaps [rsp+0x20], xmm2
00007c47757d9d14  vmovaps [rsp+0x30], xmm3
00007c47757d9d1a  vmovaps [rsp+0x40], xmm4
00007c47757d9d20  vmovaps [rsp+0x50], xmm5
00007c47757d9d26  vmovaps [rsp+0x60], xmm6
00007c47757d9d2c  vmovaps [rsp+0x70], xmm7
00007c47757d9d32  vmovaps [rsp+0x80], xmm8
00007c47757d9d3b  vmovaps [rsp+0x90], xmm9
00007c47757d9d44  vmovaps [rsp+0xA0], xmm11
00007c47757d9d4d  vmovaps [rsp+0xB0], xmm12
00007c47757d9d56  vmovaps [rsp+0xC0], xmm13
00007c47757d9d5f  vmovaps [rsp+0xD0], xmm14
00007c47757d9d68  vmovaps [rsp+0xE0], xmm15
00007c47757d9d71  sub rsp, 0x30
00007c47757d9d75  movaps [rsp], xmm10
00007c47757d9d7a  movaps [rsp+0x10], xmm14
00007c47757d9d80  movaps [rsp+0x20], xmm4
00007c47757d9d85  lea rdi, [rsp]
00007c47757d9d89  mov esi, 0x00
00007c47757d9d8e  mov rax, 0x62084E409530
00007c47757d9d98  call rax
00007c47757d9d9a  movaps xmm10, [rsp]
00007c47757d9d9f  add rsp, 0x30
00007c47757d9da3  vmovaps xmm0, [rsp]
00007c47757d9da8  vmovaps xmm1, [rsp+0x10]
00007c47757d9dae  vmovaps xmm2, [rsp+0x20]
00007c47757d9db4  vmovaps xmm3, [rsp+0x30]
00007c47757d9dba  vmovaps xmm4, [rsp+0x40]
00007c47757d9dc0  vmovaps xmm5, [rsp+0x50]
00007c47757d9dc6  vmovaps xmm6, [rsp+0x60]
00007c47757d9dcc  vmovaps xmm7, [rsp+0x70]
00007c47757d9dd2  vmovaps xmm8, [rsp+0x80]
00007c47757d9ddb  vmovaps xmm9, [rsp+0x90]
00007c47757d9de4  vmovaps xmm11, [rsp+0xA0]
00007c47757d9ded  vmovaps xmm12, [rsp+0xB0]
00007c47757d9df6  vmovaps xmm13, [rsp+0xC0]
00007c47757d9dff  vmovaps xmm14, [rsp+0xD0]
00007c47757d9e08  vmovaps xmm15, [rsp+0xE0]
00007c47757d9e11  add rsp, 0xF0
00007c47757d9e18  pop r11
00007c47757d9e1a  pop r10
00007c47757d9e1c  pop r9
00007c47757d9e1e  pop r8
00007c47757d9e20  pop rsi
00007c47757d9e21  pop rdi
00007c47757d9e22  pop rdx
00007c47757d9e23  pop rcx
00007c47757d9e24  pop rax
00007c47757d9e25  add rsp, 0x08
00007c47757d9e29  jmp 0x00007C47757D6388
00007c47757d9e2e  sub rsp, 0x08
00007c47757d9e32  push rax
00007c47757d9e33  push rcx
00007c47757d9e34  push rdx
00007c47757d9e35  push rdi
00007c47757d9e36  push rsi
00007c47757d9e37  push r8
00007c47757d9e39  push r9
00007c47757d9e3b  push r10
00007c47757d9e3d  push r11
00007c47757d9e3f  sub rsp, 0xF0
00007c47757d9e46  vmovaps [rsp], xmm0
00007c47757d9e4b  vmovaps [rsp+0x10], xmm1
00007c47757d9e51  vmovaps [rsp+0x20], xmm2
00007c47757d9e57  vmovaps [rsp+0x30], xmm3
00007c47757d9e5d  vmovaps [rsp+0x40], xmm4
00007c47757d9e63  vmovaps [rsp+0x50], xmm5
00007c47757d9e69  vmovaps [rsp+0x60], xmm6
00007c47757d9e6f  vmovaps [rsp+0x70], xmm7
00007c47757d9e75  vmovaps [rsp+0x80], xmm9
00007c47757d9e7e  vmovaps [rsp+0x90], xmm10
00007c47757d9e87  vmovaps [rsp+0xA0], xmm11
00007c47757d9e90  vmovaps [rsp+0xB0], xmm12
00007c47757d9e99  vmovaps [rsp+0xC0], xmm13
00007c47757d9ea2  vmovaps [rsp+0xD0], xmm14
00007c47757d9eab  vmovaps [rsp+0xE0], xmm15
00007c47757d9eb4  sub rsp, 0x30
00007c47757d9eb8  movaps [rsp], xmm8
00007c47757d9ebd  movaps [rsp+0x10], xmm1
00007c47757d9ec2  movaps [rsp+0x20], xmm14
00007c47757d9ec8  lea rdi, [rsp]
00007c47757d9ecc  mov esi, 0x00
00007c47757d9ed1  mov rax, 0x62084E409530
00007c47757d9edb  call rax
00007c47757d9edd  movaps xmm8, [rsp]
00007c47757d9ee2  add rsp, 0x30
00007c47757d9ee6  vmovaps xmm0, [rsp]
00007c47757d9eeb  vmovaps xmm1, [rsp+0x10]
00007c47757d9ef1  vmovaps xmm2, [rsp+0x20]
00007c47757d9ef7  vmovaps xmm3, [rsp+0x30]
00007c47757d9efd  vmovaps xmm4, [rsp+0x40]
00007c47757d9f03  vmovaps xmm5, [rsp+0x50]
00007c47757d9f09  vmovaps xmm6, [rsp+0x60]
00007c47757d9f0f  vmovaps xmm7, [rsp+0x70]
00007c47757d9f15  vmovaps xmm9, [rsp+0x80]
00007c47757d9f1e  vmovaps xmm10, [rsp+0x90]
00007c47757d9f27  vmovaps xmm11, [rsp+0xA0]
00007c47757d9f30  vmovaps xmm12, [rsp+0xB0]
00007c47757d9f39  vmovaps xmm13, [rsp+0xC0]
00007c47757d9f42  vmovaps xmm14, [rsp+0xD0]
00007c47757d9f4b  vmovaps xmm15, [rsp+0xE0]
00007c47757d9f54  add rsp, 0xF0
00007c47757d9f5b  pop r11
00007c47757d9f5d  pop r10
00007c47757d9f5f  pop r9
00007c47757d9f61  pop r8
00007c47757d9f63  pop rsi
00007c47757d9f64  pop rdi
00007c47757d9f65  pop rdx
00007c47757d9f66  pop rcx
00007c47757d9f67  pop rax
00007c47757d9f68  add rsp, 0x08
00007c47757d9f6c  jmp 0x00007C47757D63AE
00007c47757d9f71  sub rsp, 0x08
00007c47757d9f75  push rax
00007c47757d9f76  push rcx
00007c47757d9f77  push rdx
00007c47757d9f78  push rdi
00007c47757d9f79  push rsi
00007c47757d9f7a  push r8
00007c47757d9f7c  push r9
00007c47757d9f7e  push r10
00007c47757d9f80  push r11
00007c47757d9f82  sub rsp, 0xF0
00007c47757d9f89  vmovaps [rsp], xmm0
00007c47757d9f8e  vmovaps [rsp+0x10], xmm1
00007c47757d9f94  vmovaps [rsp+0x20], xmm2
00007c47757d9f9a  vmovaps [rsp+0x30], xmm3
00007c47757d9fa0  vmovaps [rsp+0x40], xmm4
00007c47757d9fa6  vmovaps [rsp+0x50], xmm5
00007c47757d9fac  vmovaps [rsp+0x60], xmm7
00007c47757d9fb2  vmovaps [rsp+0x70], xmm8
00007c47757d9fb8  vmovaps [rsp+0x80], xmm9
00007c47757d9fc1  vmovaps [rsp+0x90], xmm10
00007c47757d9fca  vmovaps [rsp+0xA0], xmm11
00007c47757d9fd3  vmovaps [rsp+0xB0], xmm12
00007c47757d9fdc  vmovaps [rsp+0xC0], xmm13
00007c47757d9fe5  vmovaps [rsp+0xD0], xmm14
00007c47757d9fee  vmovaps [rsp+0xE0], xmm15
00007c47757d9ff7  sub rsp, 0x30
00007c47757d9ffb  movaps [rsp], xmm6
00007c47757d9fff  movaps [rsp+0x10], xmm1
00007c47757da004  movaps [rsp+0x20], xmm14
00007c47757da00a  lea rdi, [rsp]
00007c47757da00e  mov esi, 0x00
00007c47757da013  mov rax, 0x62084E409530
00007c47757da01d  call rax
00007c47757da01f  movaps xmm6, [rsp]
00007c47757da023  add rsp, 0x30
00007c47757da027  vmovaps xmm0, [rsp]
00007c47757da02c  vmovaps xmm1, [rsp+0x10]
00007c47757da032  vmovaps xmm2, [rsp+0x20]
00007c47757da038  vmovaps xmm3, [rsp+0x30]
00007c47757da03e  vmovaps xmm4, [rsp+0x40]
00007c47757da044  vmovaps xmm5, [rsp+0x50]
00007c47757da04a  vmovaps xmm7, [rsp+0x60]
00007c47757da050  vmovaps xmm8, [rsp+0x70]
00007c47757da056  vmovaps xmm9, [rsp+0x80]
00007c47757da05f  vmovaps xmm10, [rsp+0x90]
00007c47757da068  vmovaps xmm11, [rsp+0xA0]
00007c47757da071  vmovaps xmm12, [rsp+0xB0]
00007c47757da07a  vmovaps xmm13, [rsp+0xC0]
00007c47757da083  vmovaps xmm14, [rsp+0xD0]
00007c47757da08c  vmovaps xmm15, [rsp+0xE0]
00007c47757da095  add rsp, 0xF0
00007c47757da09c  pop r11
00007c47757da09e  pop r10
00007c47757da0a0  pop r9
00007c47757da0a2  pop r8
00007c47757da0a4  pop rsi
00007c47757da0a5  pop rdi
00007c47757da0a6  pop rdx
00007c47757da0a7  pop rcx
00007c47757da0a8  pop rax
00007c47757da0a9  add rsp, 0x08
00007c47757da0ad  jmp 0x00007C47757D63DA
00007c47757da0b2  sub rsp, 0x08
00007c47757da0b6  push rax
00007c47757da0b7  push rcx
00007c47757da0b8  push rdx
00007c47757da0b9  push rdi
00007c47757da0ba  push rsi
00007c47757da0bb  push r8
00007c47757da0bd  push r9
00007c47757da0bf  push r10
00007c47757da0c1  push r11
00007c47757da0c3  sub rsp, 0xF0
00007c47757da0ca  vmovaps [rsp], xmm0
00007c47757da0cf  vmovaps [rsp+0x10], xmm1
00007c47757da0d5  vmovaps [rsp+0x20], xmm2
00007c47757da0db  vmovaps [rsp+0x30], xmm3
00007c47757da0e1  vmovaps [rsp+0x40], xmm4
00007c47757da0e7  vmovaps [rsp+0x50], xmm5
00007c47757da0ed  vmovaps [rsp+0x60], xmm6
00007c47757da0f3  vmovaps [rsp+0x70], xmm7
00007c47757da0f9  vmovaps [rsp+0x80], xmm8
00007c47757da102  vmovaps [rsp+0x90], xmm9
00007c47757da10b  vmovaps [rsp+0xA0], xmm10
00007c47757da114  vmovaps [rsp+0xB0], xmm11
00007c47757da11d  vmovaps [rsp+0xC0], xmm12
00007c47757da126  vmovaps [rsp+0xD0], xmm13
00007c47757da12f  vmovaps [rsp+0xE0], xmm15
00007c47757da138  sub rsp, 0x30
00007c47757da13c  movaps [rsp], xmm14
00007c47757da141  movaps [rsp+0x10], xmm12
00007c47757da147  movaps [rsp+0x20], xmm1
00007c47757da14c  lea rdi, [rsp]
00007c47757da150  mov esi, 0x00
00007c47757da155  mov rax, 0x62084E409530
00007c47757da15f  call rax
00007c47757da161  movaps xmm14, [rsp]
00007c47757da166  add rsp, 0x30
00007c47757da16a  vmovaps xmm0, [rsp]
00007c47757da16f  vmovaps xmm1, [rsp+0x10]
00007c47757da175  vmovaps xmm2, [rsp+0x20]
00007c47757da17b  vmovaps xmm3, [rsp+0x30]
00007c47757da181  vmovaps xmm4, [rsp+0x40]
00007c47757da187  vmovaps xmm5, [rsp+0x50]
00007c47757da18d  vmovaps xmm6, [rsp+0x60]
00007c47757da193  vmovaps xmm7, [rsp+0x70]
00007c47757da199  vmovaps xmm8, [rsp+0x80]
00007c47757da1a2  vmovaps xmm9, [rsp+0x90]
00007c47757da1ab  vmovaps xmm10, [rsp+0xA0]
00007c47757da1b4  vmovaps xmm11, [rsp+0xB0]
00007c47757da1bd  vmovaps xmm12, [rsp+0xC0]
00007c47757da1c6  vmovaps xmm13, [rsp+0xD0]
00007c47757da1cf  vmovaps xmm15, [rsp+0xE0]
00007c47757da1d8  add rsp, 0xF0
00007c47757da1df  pop r11
00007c47757da1e1  pop r10
00007c47757da1e3  pop r9
00007c47757da1e5  pop r8
00007c47757da1e7  pop rsi
00007c47757da1e8  pop rdi
00007c47757da1e9  pop rdx
00007c47757da1ea  pop rcx
00007c47757da1eb  pop rax
00007c47757da1ec  add rsp, 0x08
00007c47757da1f0  jmp 0x00007C47757D6400
00007c47757da1f5  sub rsp, 0x08
00007c47757da1f9  push rax
00007c47757da1fa  push rcx
00007c47757da1fb  push rdx
00007c47757da1fc  push rdi
00007c47757da1fd  push rsi
00007c47757da1fe  push r8
00007c47757da200  push r9
00007c47757da202  push r10
00007c47757da204  push r11
00007c47757da206  sub rsp, 0xF0
00007c47757da20d  vmovaps [rsp], xmm0
00007c47757da212  vmovaps [rsp+0x10], xmm2
00007c47757da218  vmovaps [rsp+0x20], xmm3
00007c47757da21e  vmovaps [rsp+0x30], xmm4
00007c47757da224  vmovaps [rsp+0x40], xmm5
00007c47757da22a  vmovaps [rsp+0x50], xmm6
00007c47757da230  vmovaps [rsp+0x60], xmm7
00007c47757da236  vmovaps [rsp+0x70], xmm8
00007c47757da23c  vmovaps [rsp+0x80], xmm9
00007c47757da245  vmovaps [rsp+0x90], xmm10
00007c47757da24e  vmovaps [rsp+0xA0], xmm11
00007c47757da257  vmovaps [rsp+0xB0], xmm12
00007c47757da260  vmovaps [rsp+0xC0], xmm13
00007c47757da269  vmovaps [rsp+0xD0], xmm14
00007c47757da272  vmovaps [rsp+0xE0], xmm15
00007c47757da27b  sub rsp, 0x30
00007c47757da27f  movaps [rsp], xmm1
00007c47757da283  movaps [rsp+0x10], xmm13
00007c47757da289  movaps [rsp+0x20], xmm9
00007c47757da28f  lea rdi, [rsp]
00007c47757da293  mov esi, 0x00
00007c47757da298  mov rax, 0x62084E409530
00007c47757da2a2  call rax
00007c47757da2a4  movaps xmm1, [rsp]
00007c47757da2a8  add rsp, 0x30
00007c47757da2ac  vmovaps xmm0, [rsp]
00007c47757da2b1  vmovaps xmm2, [rsp+0x10]
00007c47757da2b7  vmovaps xmm3, [rsp+0x20]
00007c47757da2bd  vmovaps xmm4, [rsp+0x30]
00007c47757da2c3  vmovaps xmm5, [rsp+0x40]
00007c47757da2c9  vmovaps xmm6, [rsp+0x50]
00007c47757da2cf  vmovaps xmm7, [rsp+0x60]
00007c47757da2d5  vmovaps xmm8, [rsp+0x70]
00007c47757da2db  vmovaps xmm9, [rsp+0x80]
00007c47757da2e4  vmovaps xmm10, [rsp+0x90]
00007c47757da2ed  vmovaps xmm11, [rsp+0xA0]
00007c47757da2f6  vmovaps xmm12, [rsp+0xB0]
00007c47757da2ff  vmovaps xmm13, [rsp+0xC0]
00007c47757da308  vmovaps xmm14, [rsp+0xD0]
00007c47757da311  vmovaps xmm15, [rsp+0xE0]
00007c47757da31a  add rsp, 0xF0
00007c47757da321  pop r11
00007c47757da323  pop r10
00007c47757da325  pop r9
00007c47757da327  pop r8
00007c47757da329  pop rsi
00007c47757da32a  pop rdi
00007c47757da32b  pop rdx
00007c47757da32c  pop rcx
00007c47757da32d  pop rax
00007c47757da32e  add rsp, 0x08
00007c47757da332  jmp 0x00007C47757D641A
00007c47757da337  sub rsp, 0x08
00007c47757da33b  push rax
00007c47757da33c  push rcx
00007c47757da33d  push rdx
00007c47757da33e  push rdi
00007c47757da33f  push rsi
00007c47757da340  push r8
00007c47757da342  push r9
00007c47757da344  push r10
00007c47757da346  push r11
00007c47757da348  sub rsp, 0xF0
00007c47757da34f  vmovaps [rsp], xmm0
00007c47757da354  vmovaps [rsp+0x10], xmm1
00007c47757da35a  vmovaps [rsp+0x20], xmm2
00007c47757da360  vmovaps [rsp+0x30], xmm3
00007c47757da366  vmovaps [rsp+0x40], xmm4
00007c47757da36c  vmovaps [rsp+0x50], xmm5
00007c47757da372  vmovaps [rsp+0x60], xmm6
00007c47757da378  vmovaps [rsp+0x70], xmm7
00007c47757da37e  vmovaps [rsp+0x80], xmm8
00007c47757da387  vmovaps [rsp+0x90], xmm9
00007c47757da390  vmovaps [rsp+0xA0], xmm10
00007c47757da399  vmovaps [rsp+0xB0], xmm11
00007c47757da3a2  vmovaps [rsp+0xC0], xmm13
00007c47757da3ab  vmovaps [rsp+0xD0], xmm14
00007c47757da3b4  vmovaps [rsp+0xE0], xmm15
00007c47757da3bd  sub rsp, 0x30
00007c47757da3c1  movaps [rsp], xmm12
00007c47757da3c6  movaps [rsp+0x10], xmm7
00007c47757da3cb  movaps [rsp+0x20], xmm13
00007c47757da3d1  lea rdi, [rsp]
00007c47757da3d5  mov esi, 0x00
00007c47757da3da  mov rax, 0x62084E409530
00007c47757da3e4  call rax
00007c47757da3e6  movaps xmm12, [rsp]
00007c47757da3eb  add rsp, 0x30
00007c47757da3ef  vmovaps xmm0, [rsp]
00007c47757da3f4  vmovaps xmm1, [rsp+0x10]
00007c47757da3fa  vmovaps xmm2, [rsp+0x20]
00007c47757da400  vmovaps xmm3, [rsp+0x30]
00007c47757da406  vmovaps xmm4, [rsp+0x40]
00007c47757da40c  vmovaps xmm5, [rsp+0x50]
00007c47757da412  vmovaps xmm6, [rsp+0x60]
00007c47757da418  vmovaps xmm7, [rsp+0x70]
00007c47757da41e  vmovaps xmm8, [rsp+0x80]
00007c47757da427  vmovaps xmm9, [rsp+0x90]
00007c47757da430  vmovaps xmm10, [rsp+0xA0]
00007c47757da439  vmovaps xmm11, [rsp+0xB0]
00007c47757da442  vmovaps xmm13, [rsp+0xC0]
00007c47757da44b  vmovaps xmm14, [rsp+0xD0]
00007c47757da454  vmovaps xmm15, [rsp+0xE0]
00007c47757da45d  add rsp, 0xF0
00007c47757da464  pop r11
00007c47757da466  pop r10
00007c47757da468  pop r9
00007c47757da46a  pop r8
00007c47757da46c  pop rsi
00007c47757da46d  pop rdi
00007c47757da46e  pop rdx
00007c47757da46f  pop rcx
00007c47757da470  pop rax
00007c47757da471  add rsp, 0x08
00007c47757da475  jmp 0x00007C47757D6441
00007c47757da47a  sub rsp, 0x08
00007c47757da47e  push rax
00007c47757da47f  push rcx
00007c47757da480  push rdx
00007c47757da481  push rdi
00007c47757da482  push rsi
00007c47757da483  push r8
00007c47757da485  push r9
00007c47757da487  push r10
00007c47757da489  push r11
00007c47757da48b  sub rsp, 0xF0
00007c47757da492  vmovaps [rsp], xmm0
00007c47757da497  vmovaps [rsp+0x10], xmm1
00007c47757da49d  vmovaps [rsp+0x20], xmm2
00007c47757da4a3  vmovaps [rsp+0x30], xmm3
00007c47757da4a9  vmovaps [rsp+0x40], xmm4
00007c47757da4af  vmovaps [rsp+0x50], xmm5
00007c47757da4b5  vmovaps [rsp+0x60], xmm6
00007c47757da4bb  vmovaps [rsp+0x70], xmm7
00007c47757da4c1  vmovaps [rsp+0x80], xmm8
00007c47757da4ca  vmovaps [rsp+0x90], xmm9
00007c47757da4d3  vmovaps [rsp+0xA0], xmm10
00007c47757da4dc  vmovaps [rsp+0xB0], xmm11
00007c47757da4e5  vmovaps [rsp+0xC0], xmm12
00007c47757da4ee  vmovaps [rsp+0xD0], xmm14
00007c47757da4f7  vmovaps [rsp+0xE0], xmm15
00007c47757da500  sub rsp, 0x30
00007c47757da504  movaps [rsp], xmm13
00007c47757da509  movaps [rsp+0x10], xmm15
00007c47757da50f  movaps [rsp+0x20], xmm8
00007c47757da515  lea rdi, [rsp]
00007c47757da519  mov esi, 0x00
00007c47757da51e  mov rax, 0x62084E409530
00007c47757da528  call rax
00007c47757da52a  movaps xmm13, [rsp]
00007c47757da52f  add rsp, 0x30
00007c47757da533  vmovaps xmm0, [rsp]
00007c47757da538  vmovaps xmm1, [rsp+0x10]
00007c47757da53e  vmovaps xmm2, [rsp+0x20]
00007c47757da544  vmovaps xmm3, [rsp+0x30]
00007c47757da54a  vmovaps xmm4, [rsp+0x40]
00007c47757da550  vmovaps xmm5, [rsp+0x50]
00007c47757da556  vmovaps xmm6, [rsp+0x60]
00007c47757da55c  vmovaps xmm7, [rsp+0x70]
00007c47757da562  vmovaps xmm8, [rsp+0x80]
00007c47757da56b  vmovaps xmm9, [rsp+0x90]
00007c47757da574  vmovaps xmm10, [rsp+0xA0]
00007c47757da57d  vmovaps xmm11, [rsp+0xB0]
00007c47757da586  vmovaps xmm12, [rsp+0xC0]
00007c47757da58f  vmovaps xmm14, [rsp+0xD0]
00007c47757da598  vmovaps xmm15, [rsp+0xE0]
00007c47757da5a1  add rsp, 0xF0
00007c47757da5a8  pop r11
00007c47757da5aa  pop r10
00007c47757da5ac  pop r9
00007c47757da5ae  pop r8
00007c47757da5b0  pop rsi
00007c47757da5b1  pop rdi
00007c47757da5b2  pop rdx
00007c47757da5b3  pop rcx
00007c47757da5b4  pop rax
00007c47757da5b5  add rsp, 0x08
00007c47757da5b9  jmp 0x00007C47757D645C
00007c47757da5be  sub rsp, 0x08
00007c47757da5c2  push rax
00007c47757da5c3  push rcx
00007c47757da5c4  push rdx
00007c47757da5c5  push rdi
00007c47757da5c6  push rsi
00007c47757da5c7  push r8
00007c47757da5c9  push r9
00007c47757da5cb  push r10
00007c47757da5cd  push r11
00007c47757da5cf  sub rsp, 0xF0
00007c47757da5d6  vmovaps [rsp], xmm0
00007c47757da5db  vmovaps [rsp+0x10], xmm1
00007c47757da5e1  vmovaps [rsp+0x20], xmm2
00007c47757da5e7  vmovaps [rsp+0x30], xmm3
00007c47757da5ed  vmovaps [rsp+0x40], xmm4
00007c47757da5f3  vmovaps [rsp+0x50], xmm5
00007c47757da5f9  vmovaps [rsp+0x60], xmm6
00007c47757da5ff  vmovaps [rsp+0x70], xmm7
00007c47757da605  vmovaps [rsp+0x80], xmm9
00007c47757da60e  vmovaps [rsp+0x90], xmm10
00007c47757da617  vmovaps [rsp+0xA0], xmm11
00007c47757da620  vmovaps [rsp+0xB0], xmm12
00007c47757da629  vmovaps [rsp+0xC0], xmm13
00007c47757da632  vmovaps [rsp+0xD0], xmm14
00007c47757da63b  vmovaps [rsp+0xE0], xmm15
00007c47757da644  sub rsp, 0x30
00007c47757da648  movaps [rsp], xmm8
00007c47757da64d  movaps [rsp+0x10], xmm15
00007c47757da653  movaps [rsp+0x20], xmm9
00007c47757da659  lea rdi, [rsp]
00007c47757da65d  mov esi, 0x00
00007c47757da662  mov rax, 0x62084E409530
00007c47757da66c  call rax
00007c47757da66e  movaps xmm8, [rsp]
00007c47757da673  add rsp, 0x30
00007c47757da677  vmovaps xmm0, [rsp]
00007c47757da67c  vmovaps xmm1, [rsp+0x10]
00007c47757da682  vmovaps xmm2, [rsp+0x20]
00007c47757da688  vmovaps xmm3, [rsp+0x30]
00007c47757da68e  vmovaps xmm4, [rsp+0x40]
00007c47757da694  vmovaps xmm5, [rsp+0x50]
00007c47757da69a  vmovaps xmm6, [rsp+0x60]
00007c47757da6a0  vmovaps xmm7, [rsp+0x70]
00007c47757da6a6  vmovaps xmm9, [rsp+0x80]
00007c47757da6af  vmovaps xmm10, [rsp+0x90]
00007c47757da6b8  vmovaps xmm11, [rsp+0xA0]
00007c47757da6c1  vmovaps xmm12, [rsp+0xB0]
00007c47757da6ca  vmovaps xmm13, [rsp+0xC0]
00007c47757da6d3  vmovaps xmm14, [rsp+0xD0]
00007c47757da6dc  vmovaps xmm15, [rsp+0xE0]
00007c47757da6e5  add rsp, 0xF0
00007c47757da6ec  pop r11
00007c47757da6ee  pop r10
00007c47757da6f0  pop r9
00007c47757da6f2  pop r8
00007c47757da6f4  pop rsi
00007c47757da6f5  pop rdi
00007c47757da6f6  pop rdx
00007c47757da6f7  pop rcx
00007c47757da6f8  pop rax
00007c47757da6f9  add rsp, 0x08
00007c47757da6fd  jmp 0x00007C47757D648A
00007c47757da702  sub rsp, 0x08
00007c47757da706  push rax
00007c47757da707  push rcx
00007c47757da708  push rdx
00007c47757da709  push rdi
00007c47757da70a  push rsi
00007c47757da70b  push r8
00007c47757da70d  push r9
00007c47757da70f  push r10
00007c47757da711  push r11
00007c47757da713  sub rsp, 0xF0
00007c47757da71a  vmovaps [rsp], xmm0
00007c47757da71f  vmovaps [rsp+0x10], xmm1
00007c47757da725  vmovaps [rsp+0x20], xmm2
00007c47757da72b  vmovaps [rsp+0x30], xmm3
00007c47757da731  vmovaps [rsp+0x40], xmm4
00007c47757da737  vmovaps [rsp+0x50], xmm5
00007c47757da73d  vmovaps [rsp+0x60], xmm6
00007c47757da743  vmovaps [rsp+0x70], xmm7
00007c47757da749  vmovaps [rsp+0x80], xmm8
00007c47757da752  vmovaps [rsp+0x90], xmm9
00007c47757da75b  vmovaps [rsp+0xA0], xmm10
00007c47757da764  vmovaps [rsp+0xB0], xmm11
00007c47757da76d  vmovaps [rsp+0xC0], xmm12
00007c47757da776  vmovaps [rsp+0xD0], xmm13
00007c47757da77f  vmovaps [rsp+0xE0], xmm14
00007c47757da788  sub rsp, 0x30
00007c47757da78c  movaps [rsp], xmm15
00007c47757da791  movaps [rsp+0x10], xmm11
00007c47757da797  movaps [rsp+0x20], xmm6
00007c47757da79c  lea rdi, [rsp]
00007c47757da7a0  mov esi, 0x00
00007c47757da7a5  mov rax, 0x62084E409530
00007c47757da7af  call rax
00007c47757da7b1  movaps xmm15, [rsp]
00007c47757da7b6  add rsp, 0x30
00007c47757da7ba  vmovaps xmm0, [rsp]
00007c47757da7bf  vmovaps xmm1, [rsp+0x10]
00007c47757da7c5  vmovaps xmm2, [rsp+0x20]
00007c47757da7cb  vmovaps xmm3, [rsp+0x30]
00007c47757da7d1  vmovaps xmm4, [rsp+0x40]
00007c47757da7d7  vmovaps xmm5, [rsp+0x50]
00007c47757da7dd  vmovaps xmm6, [rsp+0x60]
00007c47757da7e3  vmovaps xmm7, [rsp+0x70]
00007c47757da7e9  vmovaps xmm8, [rsp+0x80]
00007c47757da7f2  vmovaps xmm9, [rsp+0x90]
00007c47757da7fb  vmovaps xmm10, [rsp+0xA0]
00007c47757da804  vmovaps xmm11, [rsp+0xB0]
00007c47757da80d  vmovaps xmm12, [rsp+0xC0]
00007c47757da816  vmovaps xmm13, [rsp+0xD0]
00007c47757da81f  vmovaps xmm14, [rsp+0xE0]
00007c47757da828  add rsp, 0xF0
00007c47757da82f  pop r11
00007c47757da831  pop r10
00007c47757da833  pop r9
00007c47757da835  pop r8
00007c47757da837  pop rsi
00007c47757da838  pop rdi
00007c47757da839  pop rdx
00007c47757da83a  pop rcx
00007c47757da83b  pop rax
00007c47757da83c  add rsp, 0x08
00007c47757da840  jmp 0x00007C47757D64A5
00007c47757da845  sub rsp, 0x08
00007c47757da849  push rax
00007c47757da84a  push rcx
00007c47757da84b  push rdx
00007c47757da84c  push rdi
00007c47757da84d  push rsi
00007c47757da84e  push r8
00007c47757da850  push r9
00007c47757da852  push r10
00007c47757da854  push r11
00007c47757da856  sub rsp, 0xF0
00007c47757da85d  vmovaps [rsp], xmm0
00007c47757da862  vmovaps [rsp+0x10], xmm1
00007c47757da868  vmovaps [rsp+0x20], xmm2
00007c47757da86e  vmovaps [rsp+0x30], xmm3
00007c47757da874  vmovaps [rsp+0x40], xmm4
00007c47757da87a  vmovaps [rsp+0x50], xmm5
00007c47757da880  vmovaps [rsp+0x60], xmm6
00007c47757da886  vmovaps [rsp+0x70], xmm8
00007c47757da88c  vmovaps [rsp+0x80], xmm9
00007c47757da895  vmovaps [rsp+0x90], xmm10
00007c47757da89e  vmovaps [rsp+0xA0], xmm11
00007c47757da8a7  vmovaps [rsp+0xB0], xmm12
00007c47757da8b0  vmovaps [rsp+0xC0], xmm13
00007c47757da8b9  vmovaps [rsp+0xD0], xmm14
00007c47757da8c2  vmovaps [rsp+0xE0], xmm15
00007c47757da8cb  sub rsp, 0x30
00007c47757da8cf  movaps [rsp], xmm7
00007c47757da8d3  movaps [rsp+0x10], xmm11
00007c47757da8d9  movaps [rsp+0x20], xmm9
00007c47757da8df  lea rdi, [rsp]
00007c47757da8e3  mov esi, 0x00
00007c47757da8e8  mov rax, 0x62084E409530
00007c47757da8f2  call rax
00007c47757da8f4  movaps xmm7, [rsp]
00007c47757da8f8  add rsp, 0x30
00007c47757da8fc  vmovaps xmm0, [rsp]
00007c47757da901  vmovaps xmm1, [rsp+0x10]
00007c47757da907  vmovaps xmm2, [rsp+0x20]
00007c47757da90d  vmovaps xmm3, [rsp+0x30]
00007c47757da913  vmovaps xmm4, [rsp+0x40]
00007c47757da919  vmovaps xmm5, [rsp+0x50]
00007c47757da91f  vmovaps xmm6, [rsp+0x60]
00007c47757da925  vmovaps xmm8, [rsp+0x70]
00007c47757da92b  vmovaps xmm9, [rsp+0x80]
00007c47757da934  vmovaps xmm10, [rsp+0x90]
00007c47757da93d  vmovaps xmm11, [rsp+0xA0]
00007c47757da946  vmovaps xmm12, [rsp+0xB0]
00007c47757da94f  vmovaps xmm13, [rsp+0xC0]
00007c47757da958  vmovaps xmm14, [rsp+0xD0]
00007c47757da961  vmovaps xmm15, [rsp+0xE0]
00007c47757da96a  add rsp, 0xF0
00007c47757da971  pop r11
00007c47757da973  pop r10
00007c47757da975  pop r9
00007c47757da977  pop r8
00007c47757da979  pop rsi
00007c47757da97a  pop rdi
00007c47757da97b  pop rdx
00007c47757da97c  pop rcx
00007c47757da97d  pop rax
00007c47757da97e  add rsp, 0x08
00007c47757da982  jmp 0x00007C47757D64D2
00007c47757da987  sub rsp, 0x08
00007c47757da98b  push rax
00007c47757da98c  push rcx
00007c47757da98d  push rdx
00007c47757da98e  push rdi
00007c47757da98f  push rsi
00007c47757da990  push r8
00007c47757da992  push r9
00007c47757da994  push r10
00007c47757da996  push r11
00007c47757da998  sub rsp, 0xF0
00007c47757da99f  vmovaps [rsp], xmm0
00007c47757da9a4  vmovaps [rsp+0x10], xmm1
00007c47757da9aa  vmovaps [rsp+0x20], xmm2
00007c47757da9b0  vmovaps [rsp+0x30], xmm3
00007c47757da9b6  vmovaps [rsp+0x40], xmm4
00007c47757da9bc  vmovaps [rsp+0x50], xmm5
00007c47757da9c2  vmovaps [rsp+0x60], xmm6
00007c47757da9c8  vmovaps [rsp+0x70], xmm7
00007c47757da9ce  vmovaps [rsp+0x80], xmm8
00007c47757da9d7  vmovaps [rsp+0x90], xmm9
00007c47757da9e0  vmovaps [rsp+0xA0], xmm10
00007c47757da9e9  vmovaps [rsp+0xB0], xmm12
00007c47757da9f2  vmovaps [rsp+0xC0], xmm13
00007c47757da9fb  vmovaps [rsp+0xD0], xmm14
00007c47757daa04  vmovaps [rsp+0xE0], xmm15
00007c47757daa0d  sub rsp, 0x30
00007c47757daa11  movaps [rsp], xmm11
00007c47757daa16  movaps [rsp+0x10], xmm10
00007c47757daa1c  movaps [rsp+0x20], xmm14
00007c47757daa22  lea rdi, [rsp]
00007c47757daa26  mov esi, 0x00
00007c47757daa2b  mov rax, 0x62084E409530
00007c47757daa35  call rax
00007c47757daa37  movaps xmm11, [rsp]
00007c47757daa3c  add rsp, 0x30
00007c47757daa40  vmovaps xmm0, [rsp]
00007c47757daa45  vmovaps xmm1, [rsp+0x10]
00007c47757daa4b  vmovaps xmm2, [rsp+0x20]
00007c47757daa51  vmovaps xmm3, [rsp+0x30]
00007c47757daa57  vmovaps xmm4, [rsp+0x40]
00007c47757daa5d  vmovaps xmm5, [rsp+0x50]
00007c47757daa63  vmovaps xmm6, [rsp+0x60]
00007c47757daa69  vmovaps xmm7, [rsp+0x70]
00007c47757daa6f  vmovaps xmm8, [rsp+0x80]
00007c47757daa78  vmovaps xmm9, [rsp+0x90]
00007c47757daa81  vmovaps xmm10, [rsp+0xA0]
00007c47757daa8a  vmovaps xmm12, [rsp+0xB0]
00007c47757daa93  vmovaps xmm13, [rsp+0xC0]
00007c47757daa9c  vmovaps xmm14, [rsp+0xD0]
00007c47757daaa5  vmovaps xmm15, [rsp+0xE0]
00007c47757daaae  add rsp, 0xF0
00007c47757daab5  pop r11
00007c47757daab7  pop r10
00007c47757daab9  pop r9
00007c47757daabb  pop r8
00007c47757daabd  pop rsi
00007c47757daabe  pop rdi
00007c47757daabf  pop rdx
00007c47757daac0  pop rcx
00007c47757daac1  pop rax
00007c47757daac2  add rsp, 0x08
00007c47757daac6  jmp 0x00007C47757D64ED
00007c47757daacb  call 0x00007C47756E45A0
00007c47757daad0  jmp 0x00007C47757D64F7
00007c47757daad5  sub rsp, 0x08
00007c47757daad9  push rax
00007c47757daada  push rcx
00007c47757daadb  push rdx
00007c47757daadc  push rdi
00007c47757daadd  push rsi
00007c47757daade  push r8
00007c47757daae0  push r9
00007c47757daae2  push r10
00007c47757daae4  push r11
00007c47757daae6  sub rsp, 0xF0
00007c47757daaed  vmovaps [rsp], xmm0
00007c47757daaf2  vmovaps [rsp+0x10], xmm1
00007c47757daaf8  vmovaps [rsp+0x20], xmm2
00007c47757daafe  vmovaps [rsp+0x30], xmm3
00007c47757dab04  vmovaps [rsp+0x40], xmm4
00007c47757dab0a  vmovaps [rsp+0x50], xmm5
00007c47757dab10  vmovaps [rsp+0x60], xmm6
00007c47757dab16  vmovaps [rsp+0x70], xmm7
00007c47757dab1c  vmovaps [rsp+0x80], xmm8
00007c47757dab25  vmovaps [rsp+0x90], xmm9
00007c47757dab2e  vmovaps [rsp+0xA0], xmm11
00007c47757dab37  vmovaps [rsp+0xB0], xmm12
00007c47757dab40  vmovaps [rsp+0xC0], xmm13
00007c47757dab49  vmovaps [rsp+0xD0], xmm14
00007c47757dab52  vmovaps [rsp+0xE0], xmm15
00007c47757dab5b  sub rsp, 0x30
00007c47757dab5f  movaps [rsp], xmm10
00007c47757dab64  movaps [rsp+0x10], xmm1
00007c47757dab69  movaps [rsp+0x20], xmm12
00007c47757dab6f  lea rdi, [rsp]
00007c47757dab73  mov esi, 0x00
00007c47757dab78  mov rax, 0x62084E409530
00007c47757dab82  call rax
00007c47757dab84  movaps xmm10, [rsp]
00007c47757dab89  add rsp, 0x30
00007c47757dab8d  vmovaps xmm0, [rsp]
00007c47757dab92  vmovaps xmm1, [rsp+0x10]
00007c47757dab98  vmovaps xmm2, [rsp+0x20]
00007c47757dab9e  vmovaps xmm3, [rsp+0x30]
00007c47757daba4  vmovaps xmm4, [rsp+0x40]
00007c47757dabaa  vmovaps xmm5, [rsp+0x50]
00007c47757dabb0  vmovaps xmm6, [rsp+0x60]
00007c47757dabb6  vmovaps xmm7, [rsp+0x70]
00007c47757dabbc  vmovaps xmm8, [rsp+0x80]
00007c47757dabc5  vmovaps xmm9, [rsp+0x90]
00007c47757dabce  vmovaps xmm11, [rsp+0xA0]
00007c47757dabd7  vmovaps xmm12, [rsp+0xB0]
00007c47757dabe0  vmovaps xmm13, [rsp+0xC0]
00007c47757dabe9  vmovaps xmm14, [rsp+0xD0]
00007c47757dabf2  vmovaps xmm15, [rsp+0xE0]
00007c47757dabfb  add rsp, 0xF0
00007c47757dac02  pop r11
00007c47757dac04  pop r10
00007c47757dac06  pop r9
00007c47757dac08  pop r8
00007c47757dac0a  pop rsi
00007c47757dac0b  pop rdi
00007c47757dac0c  pop rdx
00007c47757dac0d  pop rcx
00007c47757dac0e  pop rax
00007c47757dac0f  add rsp, 0x08
00007c47757dac13  jmp 0x00007C47757D651A
00007c47757dac18  sub rsp, 0x08
00007c47757dac1c  push rax
00007c47757dac1d  push rcx
00007c47757dac1e  push rdx
00007c47757dac1f  push rdi
00007c47757dac20  push rsi
00007c47757dac21  push r8
00007c47757dac23  push r9
00007c47757dac25  push r10
00007c47757dac27  push r11
00007c47757dac29  sub rsp, 0xF0
00007c47757dac30  vmovaps [rsp], xmm0
00007c47757dac35  vmovaps [rsp+0x10], xmm1
00007c47757dac3b  vmovaps [rsp+0x20], xmm2
00007c47757dac41  vmovaps [rsp+0x30], xmm3
00007c47757dac47  vmovaps [rsp+0x40], xmm4
00007c47757dac4d  vmovaps [rsp+0x50], xmm5
00007c47757dac53  vmovaps [rsp+0x60], xmm6
00007c47757dac59  vmovaps [rsp+0x70], xmm7
00007c47757dac5f  vmovaps [rsp+0x80], xmm8
00007c47757dac68  vmovaps [rsp+0x90], xmm9
00007c47757dac71  vmovaps [rsp+0xA0], xmm10
00007c47757dac7a  vmovaps [rsp+0xB0], xmm11
00007c47757dac83  vmovaps [rsp+0xC0], xmm13
00007c47757dac8c  vmovaps [rsp+0xD0], xmm14
00007c47757dac95  vmovaps [rsp+0xE0], xmm15
00007c47757dac9e  sub rsp, 0x30
00007c47757daca2  movaps [rsp], xmm12
00007c47757daca7  movaps [rsp+0x10], xmm14
00007c47757dacad  movaps [rsp+0x20], xmm1
00007c47757dacb2  lea rdi, [rsp]
00007c47757dacb6  mov esi, 0x00
00007c47757dacbb  mov rax, 0x62084E409530
00007c47757dacc5  call rax
00007c47757dacc7  movaps xmm12, [rsp]
00007c47757daccc  add rsp, 0x30
00007c47757dacd0  vmovaps xmm0, [rsp]
00007c47757dacd5  vmovaps xmm1, [rsp+0x10]
00007c47757dacdb  vmovaps xmm2, [rsp+0x20]
00007c47757dace1  vmovaps xmm3, [rsp+0x30]
00007c47757dace7  vmovaps xmm4, [rsp+0x40]
00007c47757daced  vmovaps xmm5, [rsp+0x50]
00007c47757dacf3  vmovaps xmm6, [rsp+0x60]
00007c47757dacf9  vmovaps xmm7, [rsp+0x70]
00007c47757dacff  vmovaps xmm8, [rsp+0x80]
00007c47757dad08  vmovaps xmm9, [rsp+0x90]
00007c47757dad11  vmovaps xmm10, [rsp+0xA0]
00007c47757dad1a  vmovaps xmm11, [rsp+0xB0]
00007c47757dad23  vmovaps xmm13, [rsp+0xC0]
00007c47757dad2c  vmovaps xmm14, [rsp+0xD0]
00007c47757dad35  vmovaps xmm15, [rsp+0xE0]
00007c47757dad3e  add rsp, 0xF0
00007c47757dad45  pop r11
00007c47757dad47  pop r10
00007c47757dad49  pop r9
00007c47757dad4b  pop r8
00007c47757dad4d  pop rsi
00007c47757dad4e  pop rdi
00007c47757dad4f  pop rdx
00007c47757dad50  pop rcx
00007c47757dad51  pop rax
00007c47757dad52  add rsp, 0x08
00007c47757dad56  jmp 0x00007C47757D6549
00007c47757dad5b  sub rsp, 0x08
00007c47757dad5f  push rax
00007c47757dad60  push rcx
00007c47757dad61  push rdx
00007c47757dad62  push rdi
00007c47757dad63  push rsi
00007c47757dad64  push r8
00007c47757dad66  push r9
00007c47757dad68  push r10
00007c47757dad6a  push r11
00007c47757dad6c  sub rsp, 0xF0
00007c47757dad73  vmovaps [rsp], xmm0
00007c47757dad78  vmovaps [rsp+0x10], xmm1
00007c47757dad7e  vmovaps [rsp+0x20], xmm2
00007c47757dad84  vmovaps [rsp+0x30], xmm3
00007c47757dad8a  vmovaps [rsp+0x40], xmm4
00007c47757dad90  vmovaps [rsp+0x50], xmm5
00007c47757dad96  vmovaps [rsp+0x60], xmm6
00007c47757dad9c  vmovaps [rsp+0x70], xmm7
00007c47757dada2  vmovaps [rsp+0x80], xmm8
00007c47757dadab  vmovaps [rsp+0x90], xmm9
00007c47757dadb4  vmovaps [rsp+0xA0], xmm10
00007c47757dadbd  vmovaps [rsp+0xB0], xmm11
00007c47757dadc6  vmovaps [rsp+0xC0], xmm12
00007c47757dadcf  vmovaps [rsp+0xD0], xmm13
00007c47757dadd8  vmovaps [rsp+0xE0], xmm15
00007c47757dade1  sub rsp, 0x30
00007c47757dade5  movaps [rsp], xmm14
00007c47757dadea  movaps [rsp+0x10], xmm9
00007c47757dadf0  movaps [rsp+0x20], xmm1
00007c47757dadf5  lea rdi, [rsp]
00007c47757dadf9  mov esi, 0x00
00007c47757dadfe  mov rax, 0x62084E409530
00007c47757dae08  call rax
00007c47757dae0a  movaps xmm14, [rsp]
00007c47757dae0f  add rsp, 0x30
00007c47757dae13  vmovaps xmm0, [rsp]
00007c47757dae18  vmovaps xmm1, [rsp+0x10]
00007c47757dae1e  vmovaps xmm2, [rsp+0x20]
00007c47757dae24  vmovaps xmm3, [rsp+0x30]
00007c47757dae2a  vmovaps xmm4, [rsp+0x40]
00007c47757dae30  vmovaps xmm5, [rsp+0x50]
00007c47757dae36  vmovaps xmm6, [rsp+0x60]
00007c47757dae3c  vmovaps xmm7, [rsp+0x70]
00007c47757dae42  vmovaps xmm8, [rsp+0x80]
00007c47757dae4b  vmovaps xmm9, [rsp+0x90]
00007c47757dae54  vmovaps xmm10, [rsp+0xA0]
00007c47757dae5d  vmovaps xmm11, [rsp+0xB0]
00007c47757dae66  vmovaps xmm12, [rsp+0xC0]
00007c47757dae6f  vmovaps xmm13, [rsp+0xD0]
00007c47757dae78  vmovaps xmm15, [rsp+0xE0]
00007c47757dae81  add rsp, 0xF0
00007c47757dae88  pop r11
00007c47757dae8a  pop r10
00007c47757dae8c  pop r9
00007c47757dae8e  pop r8
00007c47757dae90  pop rsi
00007c47757dae91  pop rdi
00007c47757dae92  pop rdx
00007c47757dae93  pop rcx
00007c47757dae94  pop rax
00007c47757dae95  add rsp, 0x08
00007c47757dae99  jmp 0x00007C47757D6578
00007c47757dae9e  sub rsp, 0x08
00007c47757daea2  push rax
00007c47757daea3  push rcx
00007c47757daea4  push rdx
00007c47757daea5  push rdi
00007c47757daea6  push rsi
00007c47757daea7  push r8
00007c47757daea9  push r9
00007c47757daeab  push r10
00007c47757daead  push r11
00007c47757daeaf  sub rsp, 0xF0
00007c47757daeb6  vmovaps [rsp], xmm0
00007c47757daebb  vmovaps [rsp+0x10], xmm2
00007c47757daec1  vmovaps [rsp+0x20], xmm3
00007c47757daec7  vmovaps [rsp+0x30], xmm4
00007c47757daecd  vmovaps [rsp+0x40], xmm5
00007c47757daed3  vmovaps [rsp+0x50], xmm6
00007c47757daed9  vmovaps [rsp+0x60], xmm7
00007c47757daedf  vmovaps [rsp+0x70], xmm8
00007c47757daee5  vmovaps [rsp+0x80], xmm9
00007c47757daeee  vmovaps [rsp+0x90], xmm10
00007c47757daef7  vmovaps [rsp+0xA0], xmm11
00007c47757daf00  vmovaps [rsp+0xB0], xmm12
00007c47757daf09  vmovaps [rsp+0xC0], xmm13
00007c47757daf12  vmovaps [rsp+0xD0], xmm14
00007c47757daf1b  vmovaps [rsp+0xE0], xmm15
00007c47757daf24  sub rsp, 0x30
00007c47757daf28  movaps [rsp], xmm1
00007c47757daf2c  movaps [rsp+0x10], xmm13
00007c47757daf32  movaps [rsp+0x20], xmm8
00007c47757daf38  lea rdi, [rsp]
00007c47757daf3c  mov esi, 0x00
00007c47757daf41  mov rax, 0x62084E409530
00007c47757daf4b  call rax
00007c47757daf4d  movaps xmm1, [rsp]
00007c47757daf51  add rsp, 0x30
00007c47757daf55  vmovaps xmm0, [rsp]
00007c47757daf5a  vmovaps xmm2, [rsp+0x10]
00007c47757daf60  vmovaps xmm3, [rsp+0x20]
00007c47757daf66  vmovaps xmm4, [rsp+0x30]
00007c47757daf6c  vmovaps xmm5, [rsp+0x40]
00007c47757daf72  vmovaps xmm6, [rsp+0x50]
00007c47757daf78  vmovaps xmm7, [rsp+0x60]
00007c47757daf7e  vmovaps xmm8, [rsp+0x70]
00007c47757daf84  vmovaps xmm9, [rsp+0x80]
00007c47757daf8d  vmovaps xmm10, [rsp+0x90]
00007c47757daf96  vmovaps xmm11, [rsp+0xA0]
00007c47757daf9f  vmovaps xmm12, [rsp+0xB0]
00007c47757dafa8  vmovaps xmm13, [rsp+0xC0]
00007c47757dafb1  vmovaps xmm14, [rsp+0xD0]
00007c47757dafba  vmovaps xmm15, [rsp+0xE0]
00007c47757dafc3  add rsp, 0xF0
00007c47757dafca  pop r11
00007c47757dafcc  pop r10
00007c47757dafce  pop r9
00007c47757dafd0  pop r8
00007c47757dafd2  pop rsi
00007c47757dafd3  pop rdi
00007c47757dafd4  pop rdx
00007c47757dafd5  pop rcx
00007c47757dafd6  pop rax
00007c47757dafd7  add rsp, 0x08
00007c47757dafdb  jmp 0x00007C47757D659A
00007c47757dafe0  call 0x00007C477560C260
00007c47757dafe5  jmp 0x00007C47757D65A8
00007c47757dafea  call 0x00007C47756DE950
00007c47757dafef  jmp 0x00007C47757D65B2
00007c47757daff4  sub rsp, 0x08
00007c47757daff8  push rax
00007c47757daff9  push rcx
00007c47757daffa  push rdx
00007c47757daffb  push rdi
00007c47757daffc  push rsi
00007c47757daffd  push r8
00007c47757dafff  push r9
00007c47757db001  push r10
00007c47757db003  push r11
00007c47757db005  sub rsp, 0xF0
00007c47757db00c  vmovaps [rsp], xmm0
00007c47757db011  vmovaps [rsp+0x10], xmm1
00007c47757db017  vmovaps [rsp+0x20], xmm2
00007c47757db01d  vmovaps [rsp+0x30], xmm3
00007c47757db023  vmovaps [rsp+0x40], xmm4
00007c47757db029  vmovaps [rsp+0x50], xmm5
00007c47757db02f  vmovaps [rsp+0x60], xmm6
00007c47757db035  vmovaps [rsp+0x70], xmm7
00007c47757db03b  vmovaps [rsp+0x80], xmm9
00007c47757db044  vmovaps [rsp+0x90], xmm10
00007c47757db04d  vmovaps [rsp+0xA0], xmm11
00007c47757db056  vmovaps [rsp+0xB0], xmm12
00007c47757db05f  vmovaps [rsp+0xC0], xmm13
00007c47757db068  vmovaps [rsp+0xD0], xmm14
00007c47757db071  vmovaps [rsp+0xE0], xmm15
00007c47757db07a  sub rsp, 0x30
00007c47757db07e  movaps [rsp], xmm8
00007c47757db083  movaps [rsp+0x10], xmm15
00007c47757db089  movaps [rsp+0x20], xmm7
00007c47757db08e  lea rdi, [rsp]
00007c47757db092  mov esi, 0x00
00007c47757db097  mov rax, 0x62084E409530
00007c47757db0a1  call rax
00007c47757db0a3  movaps xmm8, [rsp]
00007c47757db0a8  add rsp, 0x30
00007c47757db0ac  vmovaps xmm0, [rsp]
00007c47757db0b1  vmovaps xmm1, [rsp+0x10]
00007c47757db0b7  vmovaps xmm2, [rsp+0x20]
00007c47757db0bd  vmovaps xmm3, [rsp+0x30]
00007c47757db0c3  vmovaps xmm4, [rsp+0x40]
00007c47757db0c9  vmovaps xmm5, [rsp+0x50]
00007c47757db0cf  vmovaps xmm6, [rsp+0x60]
00007c47757db0d5  vmovaps xmm7, [rsp+0x70]
00007c47757db0db  vmovaps xmm9, [rsp+0x80]
00007c47757db0e4  vmovaps xmm10, [rsp+0x90]
00007c47757db0ed  vmovaps xmm11, [rsp+0xA0]
00007c47757db0f6  vmovaps xmm12, [rsp+0xB0]
00007c47757db0ff  vmovaps xmm13, [rsp+0xC0]
00007c47757db108  vmovaps xmm14, [rsp+0xD0]
00007c47757db111  vmovaps xmm15, [rsp+0xE0]
00007c47757db11a  add rsp, 0xF0
00007c47757db121  pop r11
00007c47757db123  pop r10
00007c47757db125  pop r9
00007c47757db127  pop r8
00007c47757db129  pop rsi
00007c47757db12a  pop rdi
00007c47757db12b  pop rdx
00007c47757db12c  pop rcx
00007c47757db12d  pop rax
00007c47757db12e  add rsp, 0x08
00007c47757db132  jmp 0x00007C47757D65D4
00007c47757db137  sub rsp, 0x08
00007c47757db13b  push rax
00007c47757db13c  push rcx
00007c47757db13d  push rdx
00007c47757db13e  push rdi
00007c47757db13f  push rsi
00007c47757db140  push r8
00007c47757db142  push r9
00007c47757db144  push r10
00007c47757db146  push r11
00007c47757db148  sub rsp, 0xF0
00007c47757db14f  vmovaps [rsp], xmm0
00007c47757db154  vmovaps [rsp+0x10], xmm1
00007c47757db15a  vmovaps [rsp+0x20], xmm2
00007c47757db160  vmovaps [rsp+0x30], xmm3
00007c47757db166  vmovaps [rsp+0x40], xmm4
00007c47757db16c  vmovaps [rsp+0x50], xmm5
00007c47757db172  vmovaps [rsp+0x60], xmm6
00007c47757db178  vmovaps [rsp+0x70], xmm8
00007c47757db17e  vmovaps [rsp+0x80], xmm9
00007c47757db187  vmovaps [rsp+0x90], xmm10
00007c47757db190  vmovaps [rsp+0xA0], xmm11
00007c47757db199  vmovaps [rsp+0xB0], xmm12
00007c47757db1a2  vmovaps [rsp+0xC0], xmm13
00007c47757db1ab  vmovaps [rsp+0xD0], xmm14
00007c47757db1b4  vmovaps [rsp+0xE0], xmm15
00007c47757db1bd  sub rsp, 0x30
00007c47757db1c1  movaps [rsp], xmm7
00007c47757db1c5  movaps [rsp+0x10], xmm9
00007c47757db1cb  movaps [rsp+0x20], xmm15
00007c47757db1d1  lea rdi, [rsp]
00007c47757db1d5  mov esi, 0x00
00007c47757db1da  mov rax, 0x62084E409530
00007c47757db1e4  call rax
00007c47757db1e6  movaps xmm7, [rsp]
00007c47757db1ea  add rsp, 0x30
00007c47757db1ee  vmovaps xmm0, [rsp]
00007c47757db1f3  vmovaps xmm1, [rsp+0x10]
00007c47757db1f9  vmovaps xmm2, [rsp+0x20]
00007c47757db1ff  vmovaps xmm3, [rsp+0x30]
00007c47757db205  vmovaps xmm4, [rsp+0x40]
00007c47757db20b  vmovaps xmm5, [rsp+0x50]
00007c47757db211  vmovaps xmm6, [rsp+0x60]
00007c47757db217  vmovaps xmm8, [rsp+0x70]
00007c47757db21d  vmovaps xmm9, [rsp+0x80]
00007c47757db226  vmovaps xmm10, [rsp+0x90]
00007c47757db22f  vmovaps xmm11, [rsp+0xA0]
00007c47757db238  vmovaps xmm12, [rsp+0xB0]
00007c47757db241  vmovaps xmm13, [rsp+0xC0]
00007c47757db24a  vmovaps xmm14, [rsp+0xD0]
00007c47757db253  vmovaps xmm15, [rsp+0xE0]
00007c47757db25c  add rsp, 0xF0
00007c47757db263  pop r11
00007c47757db265  pop r10
00007c47757db267  pop r9
00007c47757db269  pop r8
00007c47757db26b  pop rsi
00007c47757db26c  pop rdi
00007c47757db26d  pop rdx
00007c47757db26e  pop rcx
00007c47757db26f  pop rax
00007c47757db270  add rsp, 0x08
00007c47757db274  jmp 0x00007C47757D6601
00007c47757db279  sub rsp, 0x08
00007c47757db27d  push rax
00007c47757db27e  push rcx
00007c47757db27f  push rdx
00007c47757db280  push rdi
00007c47757db281  push rsi
00007c47757db282  push r8
00007c47757db284  push r9
00007c47757db286  push r10
00007c47757db288  push r11
00007c47757db28a  sub rsp, 0xF0
00007c47757db291  vmovaps [rsp], xmm0
00007c47757db296  vmovaps [rsp+0x10], xmm1
00007c47757db29c  vmovaps [rsp+0x20], xmm2
00007c47757db2a2  vmovaps [rsp+0x30], xmm3
00007c47757db2a8  vmovaps [rsp+0x40], xmm4
00007c47757db2ae  vmovaps [rsp+0x50], xmm5
00007c47757db2b4  vmovaps [rsp+0x60], xmm6
00007c47757db2ba  vmovaps [rsp+0x70], xmm7
00007c47757db2c0  vmovaps [rsp+0x80], xmm8
00007c47757db2c9  vmovaps [rsp+0x90], xmm10
00007c47757db2d2  vmovaps [rsp+0xA0], xmm11
00007c47757db2db  vmovaps [rsp+0xB0], xmm12
00007c47757db2e4  vmovaps [rsp+0xC0], xmm13
00007c47757db2ed  vmovaps [rsp+0xD0], xmm14
00007c47757db2f6  vmovaps [rsp+0xE0], xmm15
00007c47757db2ff  sub rsp, 0x30
00007c47757db303  movaps [rsp], xmm9
00007c47757db308  movaps [rsp+0x10], xmm13
00007c47757db30e  movaps [rsp+0x20], xmm15
00007c47757db314  lea rdi, [rsp]
00007c47757db318  mov esi, 0x00
00007c47757db31d  mov rax, 0x62084E409530
00007c47757db327  call rax
00007c47757db329  movaps xmm9, [rsp]
00007c47757db32e  add rsp, 0x30
00007c47757db332  vmovaps xmm0, [rsp]
00007c47757db337  vmovaps xmm1, [rsp+0x10]
00007c47757db33d  vmovaps xmm2, [rsp+0x20]
00007c47757db343  vmovaps xmm3, [rsp+0x30]
00007c47757db349  vmovaps xmm4, [rsp+0x40]
00007c47757db34f  vmovaps xmm5, [rsp+0x50]
00007c47757db355  vmovaps xmm6, [rsp+0x60]
00007c47757db35b  vmovaps xmm7, [rsp+0x70]
00007c47757db361  vmovaps xmm8, [rsp+0x80]
00007c47757db36a  vmovaps xmm10, [rsp+0x90]
00007c47757db373  vmovaps xmm11, [rsp+0xA0]
00007c47757db37c  vmovaps xmm12, [rsp+0xB0]
00007c47757db385  vmovaps xmm13, [rsp+0xC0]
00007c47757db38e  vmovaps xmm14, [rsp+0xD0]
00007c47757db397  vmovaps xmm15, [rsp+0xE0]
00007c47757db3a0  add rsp, 0xF0
00007c47757db3a7  pop r11
00007c47757db3a9  pop r10
00007c47757db3ab  pop r9
00007c47757db3ad  pop r8
00007c47757db3af  pop rsi
00007c47757db3b0  pop rdi
00007c47757db3b1  pop rdx
00007c47757db3b2  pop rcx
00007c47757db3b3  pop rax
00007c47757db3b4  add rsp, 0x08
00007c47757db3b8  jmp 0x00007C47757D662F
00007c47757db3bd  sub rsp, 0x08
00007c47757db3c1  push rax
00007c47757db3c2  push rcx
00007c47757db3c3  push rdx
00007c47757db3c4  push rdi
00007c47757db3c5  push rsi
00007c47757db3c6  push r8
00007c47757db3c8  push r9
00007c47757db3ca  push r10
00007c47757db3cc  push r11
00007c47757db3ce  sub rsp, 0xF0
00007c47757db3d5  vmovaps [rsp], xmm0
00007c47757db3da  vmovaps [rsp+0x10], xmm1
00007c47757db3e0  vmovaps [rsp+0x20], xmm2
00007c47757db3e6  vmovaps [rsp+0x30], xmm3
00007c47757db3ec  vmovaps [rsp+0x40], xmm4
00007c47757db3f2  vmovaps [rsp+0x50], xmm5
00007c47757db3f8  vmovaps [rsp+0x60], xmm6
00007c47757db3fe  vmovaps [rsp+0x70], xmm7
00007c47757db404  vmovaps [rsp+0x80], xmm8
00007c47757db40d  vmovaps [rsp+0x90], xmm9
00007c47757db416  vmovaps [rsp+0xA0], xmm10
00007c47757db41f  vmovaps [rsp+0xB0], xmm11
00007c47757db428  vmovaps [rsp+0xC0], xmm12
00007c47757db431  vmovaps [rsp+0xD0], xmm13
00007c47757db43a  vmovaps [rsp+0xE0], xmm14
00007c47757db443  sub rsp, 0x30
00007c47757db447  movaps [rsp], xmm15
00007c47757db44c  movaps [rsp+0x10], xmm11
00007c47757db452  movaps [rsp+0x20], xmm12
00007c47757db458  lea rdi, [rsp]
00007c47757db45c  mov esi, 0x00
00007c47757db461  mov rax, 0x62084E409530
00007c47757db46b  call rax
00007c47757db46d  movaps xmm15, [rsp]
00007c47757db472  add rsp, 0x30
00007c47757db476  vmovaps xmm0, [rsp]
00007c47757db47b  vmovaps xmm1, [rsp+0x10]
00007c47757db481  vmovaps xmm2, [rsp+0x20]
00007c47757db487  vmovaps xmm3, [rsp+0x30]
00007c47757db48d  vmovaps xmm4, [rsp+0x40]
00007c47757db493  vmovaps xmm5, [rsp+0x50]
00007c47757db499  vmovaps xmm6, [rsp+0x60]
00007c47757db49f  vmovaps xmm7, [rsp+0x70]
00007c47757db4a5  vmovaps xmm8, [rsp+0x80]
00007c47757db4ae  vmovaps xmm9, [rsp+0x90]
00007c47757db4b7  vmovaps xmm10, [rsp+0xA0]
00007c47757db4c0  vmovaps xmm11, [rsp+0xB0]
00007c47757db4c9  vmovaps xmm12, [rsp+0xC0]
00007c47757db4d2  vmovaps xmm13, [rsp+0xD0]
00007c47757db4db  vmovaps xmm14, [rsp+0xE0]
00007c47757db4e4  add rsp, 0xF0
00007c47757db4eb  pop r11
00007c47757db4ed  pop r10
00007c47757db4ef  pop r9
00007c47757db4f1  pop r8
00007c47757db4f3  pop rsi
00007c47757db4f4  pop rdi
00007c47757db4f5  pop rdx
00007c47757db4f6  pop rcx
00007c47757db4f7  pop rax
00007c47757db4f8  add rsp, 0x08
00007c47757db4fc  jmp 0x00007C47757D664A
00007c47757db501  sub rsp, 0x08
00007c47757db505  push rax
00007c47757db506  push rcx
00007c47757db507  push rdx
00007c47757db508  push rdi
00007c47757db509  push rsi
00007c47757db50a  push r8
00007c47757db50c  push r9
00007c47757db50e  push r10
00007c47757db510  push r11
00007c47757db512  sub rsp, 0xF0
00007c47757db519  vmovaps [rsp], xmm0
00007c47757db51e  vmovaps [rsp+0x10], xmm1
00007c47757db524  vmovaps [rsp+0x20], xmm2
00007c47757db52a  vmovaps [rsp+0x30], xmm3
00007c47757db530  vmovaps [rsp+0x40], xmm4
00007c47757db536  vmovaps [rsp+0x50], xmm5
00007c47757db53c  vmovaps [rsp+0x60], xmm6
00007c47757db542  vmovaps [rsp+0x70], xmm7
00007c47757db548  vmovaps [rsp+0x80], xmm8
00007c47757db551  vmovaps [rsp+0x90], xmm9
00007c47757db55a  vmovaps [rsp+0xA0], xmm10
00007c47757db563  vmovaps [rsp+0xB0], xmm11
00007c47757db56c  vmovaps [rsp+0xC0], xmm12
00007c47757db575  vmovaps [rsp+0xD0], xmm14
00007c47757db57e  vmovaps [rsp+0xE0], xmm15
00007c47757db587  sub rsp, 0x30
00007c47757db58b  movaps [rsp], xmm13
00007c47757db590  movaps [rsp+0x10], xmm10
00007c47757db596  movaps [rsp+0x20], xmm14
00007c47757db59c  lea rdi, [rsp]
00007c47757db5a0  mov esi, 0x00
00007c47757db5a5  mov rax, 0x62084E409530
00007c47757db5af  call rax
00007c47757db5b1  movaps xmm13, [rsp]
00007c47757db5b6  add rsp, 0x30
00007c47757db5ba  vmovaps xmm0, [rsp]
00007c47757db5bf  vmovaps xmm1, [rsp+0x10]
00007c47757db5c5  vmovaps xmm2, [rsp+0x20]
00007c47757db5cb  vmovaps xmm3, [rsp+0x30]
00007c47757db5d1  vmovaps xmm4, [rsp+0x40]
00007c47757db5d7  vmovaps xmm5, [rsp+0x50]
00007c47757db5dd  vmovaps xmm6, [rsp+0x60]
00007c47757db5e3  vmovaps xmm7, [rsp+0x70]
00007c47757db5e9  vmovaps xmm8, [rsp+0x80]
00007c47757db5f2  vmovaps xmm9, [rsp+0x90]
00007c47757db5fb  vmovaps xmm10, [rsp+0xA0]
00007c47757db604  vmovaps xmm11, [rsp+0xB0]
00007c47757db60d  vmovaps xmm12, [rsp+0xC0]
00007c47757db616  vmovaps xmm14, [rsp+0xD0]
00007c47757db61f  vmovaps xmm15, [rsp+0xE0]
00007c47757db628  add rsp, 0xF0
00007c47757db62f  pop r11
00007c47757db631  pop r10
00007c47757db633  pop r9
00007c47757db635  pop r8
00007c47757db637  pop rsi
00007c47757db638  pop rdi
00007c47757db639  pop rdx
00007c47757db63a  pop rcx
00007c47757db63b  pop rax
00007c47757db63c  add rsp, 0x08
00007c47757db640  jmp 0x00007C47757D666D
00007c47757db645  sub rsp, 0x08
00007c47757db649  push rax
00007c47757db64a  push rcx
00007c47757db64b  push rdx
00007c47757db64c  push rdi
00007c47757db64d  push rsi
00007c47757db64e  push r8
00007c47757db650  push r9
00007c47757db652  push r10
00007c47757db654  push r11
00007c47757db656  sub rsp, 0xF0
00007c47757db65d  vmovaps [rsp], xmm0
00007c47757db662  vmovaps [rsp+0x10], xmm1
00007c47757db668  vmovaps [rsp+0x20], xmm2
00007c47757db66e  vmovaps [rsp+0x30], xmm3
00007c47757db674  vmovaps [rsp+0x40], xmm4
00007c47757db67a  vmovaps [rsp+0x50], xmm5
00007c47757db680  vmovaps [rsp+0x60], xmm6
00007c47757db686  vmovaps [rsp+0x70], xmm7
00007c47757db68c  vmovaps [rsp+0x80], xmm8
00007c47757db695  vmovaps [rsp+0x90], xmm9
00007c47757db69e  vmovaps [rsp+0xA0], xmm10
00007c47757db6a7  vmovaps [rsp+0xB0], xmm11
00007c47757db6b0  vmovaps [rsp+0xC0], xmm12
00007c47757db6b9  vmovaps [rsp+0xD0], xmm13
00007c47757db6c2  vmovaps [rsp+0xE0], xmm15
00007c47757db6cb  sub rsp, 0x30
00007c47757db6cf  movaps [rsp], xmm14
00007c47757db6d4  movaps [rsp+0x10], xmm1
00007c47757db6d9  movaps [rsp+0x20], xmm7
00007c47757db6de  lea rdi, [rsp]
00007c47757db6e2  mov esi, 0x00
00007c47757db6e7  mov rax, 0x62084E409530
00007c47757db6f1  call rax
00007c47757db6f3  movaps xmm14, [rsp]
00007c47757db6f8  add rsp, 0x30
00007c47757db6fc  vmovaps xmm0, [rsp]
00007c47757db701  vmovaps xmm1, [rsp+0x10]
00007c47757db707  vmovaps xmm2, [rsp+0x20]
00007c47757db70d  vmovaps xmm3, [rsp+0x30]
00007c47757db713  vmovaps xmm4, [rsp+0x40]
00007c47757db719  vmovaps xmm5, [rsp+0x50]
00007c47757db71f  vmovaps xmm6, [rsp+0x60]
00007c47757db725  vmovaps xmm7, [rsp+0x70]
00007c47757db72b  vmovaps xmm8, [rsp+0x80]
00007c47757db734  vmovaps xmm9, [rsp+0x90]
00007c47757db73d  vmovaps xmm10, [rsp+0xA0]
00007c47757db746  vmovaps xmm11, [rsp+0xB0]
00007c47757db74f  vmovaps xmm12, [rsp+0xC0]
00007c47757db758  vmovaps xmm13, [rsp+0xD0]
00007c47757db761  vmovaps xmm15, [rsp+0xE0]
00007c47757db76a  add rsp, 0xF0
00007c47757db771  pop r11
00007c47757db773  pop r10
00007c47757db775  pop r9
00007c47757db777  pop r8
00007c47757db779  pop rsi
00007c47757db77a  pop rdi
00007c47757db77b  pop rdx
00007c47757db77c  pop rcx
00007c47757db77d  pop rax
00007c47757db77e  add rsp, 0x08
00007c47757db782  jmp 0x00007C47757D6690
00007c47757db787  sub rsp, 0x08
00007c47757db78b  push rax
00007c47757db78c  push rcx
00007c47757db78d  push rdx
00007c47757db78e  push rdi
00007c47757db78f  push rsi
00007c47757db790  push r8
00007c47757db792  push r9
00007c47757db794  push r10
00007c47757db796  push r11
00007c47757db798  sub rsp, 0xF0
00007c47757db79f  vmovaps [rsp], xmm0
00007c47757db7a4  vmovaps [rsp+0x10], xmm2
00007c47757db7aa  vmovaps [rsp+0x20], xmm3
00007c47757db7b0  vmovaps [rsp+0x30], xmm4
00007c47757db7b6  vmovaps [rsp+0x40], xmm5
00007c47757db7bc  vmovaps [rsp+0x50], xmm6
00007c47757db7c2  vmovaps [rsp+0x60], xmm7
00007c47757db7c8  vmovaps [rsp+0x70], xmm8
00007c47757db7ce  vmovaps [rsp+0x80], xmm9
00007c47757db7d7  vmovaps [rsp+0x90], xmm10
00007c47757db7e0  vmovaps [rsp+0xA0], xmm11
00007c47757db7e9  vmovaps [rsp+0xB0], xmm12
00007c47757db7f2  vmovaps [rsp+0xC0], xmm13
00007c47757db7fb  vmovaps [rsp+0xD0], xmm14
00007c47757db804  vmovaps [rsp+0xE0], xmm15
00007c47757db80d  sub rsp, 0x30
00007c47757db811  movaps [rsp], xmm1
00007c47757db815  movaps [rsp+0x10], xmm8
00007c47757db81b  movaps [rsp+0x20], xmm9
00007c47757db821  lea rdi, [rsp]
00007c47757db825  mov esi, 0x00
00007c47757db82a  mov rax, 0x62084E409530
00007c47757db834  call rax
00007c47757db836  movaps xmm1, [rsp]
00007c47757db83a  add rsp, 0x30
00007c47757db83e  vmovaps xmm0, [rsp]
00007c47757db843  vmovaps xmm2, [rsp+0x10]
00007c47757db849  vmovaps xmm3, [rsp+0x20]
00007c47757db84f  vmovaps xmm4, [rsp+0x30]
00007c47757db855  vmovaps xmm5, [rsp+0x40]
00007c47757db85b  vmovaps xmm6, [rsp+0x50]
00007c47757db861  vmovaps xmm7, [rsp+0x60]
00007c47757db867  vmovaps xmm8, [rsp+0x70]
00007c47757db86d  vmovaps xmm9, [rsp+0x80]
00007c47757db876  vmovaps xmm10, [rsp+0x90]
00007c47757db87f  vmovaps xmm11, [rsp+0xA0]
00007c47757db888  vmovaps xmm12, [rsp+0xB0]
00007c47757db891  vmovaps xmm13, [rsp+0xC0]
00007c47757db89a  vmovaps xmm14, [rsp+0xD0]
00007c47757db8a3  vmovaps xmm15, [rsp+0xE0]
00007c47757db8ac  add rsp, 0xF0
00007c47757db8b3  pop r11
00007c47757db8b5  pop r10
00007c47757db8b7  pop r9
00007c47757db8b9  pop r8
00007c47757db8bb  pop rsi
00007c47757db8bc  pop rdi
00007c47757db8bd  pop rdx
00007c47757db8be  pop rcx
00007c47757db8bf  pop rax
00007c47757db8c0  add rsp, 0x08
00007c47757db8c4  jmp 0x00007C47757D66B2
00007c47757db8c9  call 0x00007C47756B3E40
00007c47757db8ce  jmp 0x00007C47757D66C0
00007c47757db8d3  call 0x00007C477560C380
00007c47757db8d8  jmp 0x00007C47757D66CA
00007c47757db8dd  call 0x00007C477560D600
00007c47757db8e2  jmp 0x00007C47757D66D4
00007c47757db8e7  call 0x00007C47755FF540
00007c47757db8ec  jmp 0x00007C47757D66DE
00007c47757db8f1  int3
00007c47757db8f2  nop [rax+rax*1], ax
00007c47757db8fb  nop [rax+rax*1], eax
00007c47757db900  mov eax, [r15+0x48]
00007c47757db904  lea r14d, [eax+0x01]
00007c47757db909  mov [rsp+0x10], r14d
00007c47757db90e  mov r14d, r14d
00007c47757db911  mov [r15+0x48], r14
00007c47757db915  xor eax, eax
00007c47757db917  mov r14d, [rsp+0x10]
00007c47757db91c  cmp r14d, 0x1F4
00007c47757db923  cmc
00007c47757db924  lahf
00007c47757db925  seto al
00007c47757db928  mov [r15+0x108], eax
00007c47757db92f  mov eax, [r15+0x108]
00007c47757db936  sahf
00007c47757db937  jnz 0x00007C47757DB969
00007c47757db939  cmp dword ptr [r15+0x318], 0x00
00007c47757db941  jz 0x00007C47757E1AB0
00007c47757db947  nop [rax+rax*1], ax
00007c47757db950  nop [rax+rax*1], eax
00007c47757db958  mov eax, 0x410450
00007c47757db95d  mov [r15+0x100], rax
00007c47757db964  jmp 0x00007C47755FE110
00007c47757db969  cmp dword ptr [r15+0x318], 0x00
00007c47757db971  jz 0x00007C47757DB9A0
00007c47757db977  nop [rax+rax*1], ax
00007c47757db980  nop [rax+rax*1], eax
00007c47757db988  mov eax, 0x410274
00007c47757db98d  mov [r15+0x100], rax
00007c47757db994  jmp 0x00007C47755FE110
00007c47757db999  int3
00007c47757db99a  int3
00007c47757db99b  nop [rax+rax*1], eax
00007c47757db9a0  mov rax, [r15+0x40]
00007c47757db9a4  movaps xmm1, [r15+0x1D0]
00007c47757db9ac  vmovaps [rsp+0x10], xmm1
00007c47757db9b2  vmovaps xmm15, [rsp+0x10]
00007c47757db9b8  por xmm1, xmm15
00007c47757db9bd  movaps xmm14, [r15+0x1A0]
00007c47757db9c5  vmovaps [rsp+0x10], xmm14
00007c47757db9cb  vmovaps xmm13, [rsp+0x10]
00007c47757db9d1  por xmm14, xmm13
00007c47757db9d6  lea r14, [rax+0x30]
00007c47757db9da  mov r12, [r13+r14*1]
00007c47757db9df  lea r14, [rax+0x38]
00007c47757db9e3  mov r11, [r13+r14*1]
00007c47757db9e8  movq xmm13, r12
00007c47757db9ed  movq xmm12, r11
00007c47757db9f2  movq xmm13, xmm13
00007c47757db9f7  vmovaps [rsp+0x10], xmm13
00007c47757db9fd  movq xmm13, xmm13
00007c47757dba02  movaps [r15+0x130], xmm13
00007c47757dba0a  movq xmm12, xmm12
00007c47757dba0f  vmovaps [rsp+0x20], xmm12
00007c47757dba15  movq xmm12, xmm12
00007c47757dba1a  movaps [r15+0x280], xmm12
00007c47757dba22  movaps xmm13, [r15+0x270]
00007c47757dba2a  vmovaps [rsp+0x30], xmm13
00007c47757dba30  vmovaps xmm12, [rsp+0x30]
00007c47757dba36  por xmm13, xmm12
00007c47757dba3b  lea r14, [rax+0x20]
00007c47757dba3f  mov r12, [r13+r14*1]
00007c47757dba44  lea r14, [rax+0x28]
00007c47757dba48  mov r11, [r13+r14*1]
00007c47757dba4d  movq xmm12, r12
00007c47757dba52  movq xmm11, r11
00007c47757dba57  movq xmm12, xmm12
00007c47757dba5c  vmovaps [rsp+0x30], xmm12
00007c47757dba62  movq xmm12, xmm12
00007c47757dba67  movaps [r15+0x150], xmm12
00007c47757dba6f  movq xmm11, xmm11
00007c47757dba74  vmovaps [rsp+0x40], xmm11
00007c47757dba7a  movq xmm11, xmm11
00007c47757dba7f  movaps [r15+0x140], xmm11
00007c47757dba87  lea r14, [rax+0x10]
00007c47757dba8b  mov r12, [r13+r14*1]
00007c47757dba90  lea r14, [rax+0x18]
00007c47757dba94  mov r11, [r13+r14*1]
00007c47757dba99  movq xmm12, r12
00007c47757dba9e  movq xmm11, r11
00007c47757dbaa3  movq xmm12, xmm12
00007c47757dbaa8  vmovaps [rsp+0x50], xmm12
00007c47757dbaae  movq xmm12, xmm12
00007c47757dbab3  movaps [r15+0x170], xmm12
00007c47757dbabb  movq xmm11, xmm11
00007c47757dbac0  vmovaps [rsp+0x60], xmm11
00007c47757dbac6  movq xmm11, xmm11
00007c47757dbacb  movaps [r15+0x160], xmm11
00007c47757dbad3  mov r14, [r13+rax*1]
00007c47757dbad8  vmovq xmm12, r14
00007c47757dbadd  vpbroadcastq xmm12, xmm12
00007c47757dbae2  lea r14, [rax+0x08]
00007c47757dbae6  mov rax, [r13+r14*1]
00007c47757dbaeb  movq xmm11, rax
00007c47757dbaf0  movaps [r15+0x230], xmm11
00007c47757dbaf8  mov rax, [r15+0xF8]
00007c47757dbaff  lea r14, [rax+0x50]
00007c47757dbb03  movups xmm11, [r13+r14*1]
00007c47757dbb09  lea r14, [rax+0x60]
00007c47757dbb0d  movups xmm10, [r13+r14*1]
00007c47757dbb13  lea r14, [rax+0x30]
00007c47757dbb17  movups xmm9, [r13+r14*1]
00007c47757dbb1d  mov r14, [r15+0x50]
00007c47757dbb21  mov [r15+0x60], r14
00007c47757dbb25  mov qword ptr [r15+0x58], 0x40
00007c47757dbb2d  movaps xmm8, xmm12
00007c47757dbb31  mulpd xmm8, xmm15
00007c47757dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007c47757dbb3c  ptest xmm7, xmm7
00007c47757dbb41  jnz 0x00007C47757DC96A
00007c47757dbb47  movq xmm15, qword ptr [r15+0x230]
00007c47757dbb50  vmovaps [rsp+0x70], xmm15
00007c47757dbb56  vpermilpd xmm15, xmm15, 0x00
00007c47757dbb5c  movaps xmm7, xmm9
00007c47757dbb60  mulpd xmm7, xmm15
00007c47757dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007c47757dbb6a  ptest xmm6, xmm6
00007c47757dbb6f  jnz 0x00007C47757DCAAE
00007c47757dbb75  vxorps xmm15, xmm15, xmm15
00007c47757dbb7a  vpbroadcastq xmm15, xmm15
00007c47757dbb7f  movaps xmm9, xmm12
00007c47757dbb83  mulpd xmm9, xmm10
00007c47757dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007c47757dbb8e  ptest xmm6, xmm6
00007c47757dbb93  jnz 0x00007C47757DCBF0
00007c47757dbb99  movaps xmm10, xmm12
00007c47757dbb9d  mulpd xmm10, xmm11
00007c47757dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007c47757dbba8  ptest xmm6, xmm6
00007c47757dbbad  jnz 0x00007C47757DCD34
00007c47757dbbb3  movaps xmm11, [r15+0x1F0]
00007c47757dbbbb  movaps xmm6, xmm12
00007c47757dbbbf  mulpd xmm6, xmm11
00007c47757dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007c47757dbbc9  ptest xmm5, xmm5
00007c47757dbbce  jnz 0x00007C47757DCE78
00007c47757dbbd4  movaps xmm12, [r15+0x2A0]
00007c47757dbbdc  vmovaps [rsp+0x80], xmm12
00007c47757dbbe5  vmovaps xmm11, [rsp+0x80]
00007c47757dbbee  por xmm12, xmm11
00007c47757dbbf3  movaps xmm11, [r15+0x250]
00007c47757dbbfb  vmovaps [rsp+0x80], xmm11
00007c47757dbc04  vmovaps xmm5, [rsp+0x80]
00007c47757dbc0d  por xmm11, xmm5
00007c47757dbc12  vmovaps xmm4, [rsp+0x70]
00007c47757dbc18  vpermilpd xmm4, xmm4, 0x00
00007c47757dbc1e  movaps xmm3, xmm5
00007c47757dbc21  mulpd xmm3, xmm4
00007c47757dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007c47757dbc2a  ptest xmm2, xmm2
00007c47757dbc2f  jnz 0x00007C47757DCFBA
00007c47757dbc35  mov [rsp+0x80], rax
00007c47757dbc3d  xor eax, eax
00007c47757dbc3f  mov r12d, 0x40
00007c47757dbc45  mov r11d, 0x200
00007c47757dbc4b  cmp r12, r11
00007c47757dbc4e  cmc
00007c47757dbc4f  lahf
00007c47757dbc50  seto al
00007c47757dbc53  mov [r15+0x108], eax
00007c47757dbc5a  movaps xmm5, xmm8
00007c47757dbc5e  addpd xmm5, xmm15
00007c47757dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007c47757dbc68  ptest xmm4, xmm4
00007c47757dbc6d  jnz 0x00007C47757DD0FA
00007c47757dbc73  movaps xmm8, [r15+0x1B0]
00007c47757dbc7b  movaps xmm4, xmm9
00007c47757dbc7f  addpd xmm4, xmm8
00007c47757dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007c47757dbc89  ptest xmm2, xmm2
00007c47757dbc8e  jnz 0x00007C47757DD23C
00007c47757dbc94  movaps xmm9, xmm10
00007c47757dbc98  addpd xmm9, xmm8
00007c47757dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007c47757dbca3  ptest xmm2, xmm2
00007c47757dbca8  jnz 0x00007C47757DD37E
00007c47757dbcae  movaps xmm10, [r15+0x2F0]
00007c47757dbcb6  vmovaps [rsp+0x90], xmm10
00007c47757dbcbf  vmovaps xmm8, [rsp+0x90]
00007c47757dbcc8  por xmm10, xmm8
00007c47757dbccd  movaps xmm8, [r15+0x2E0]
00007c47757dbcd5  vmovaps [rsp+0x90], xmm8
00007c47757dbcde  vmovaps xmm2, [rsp+0x90]
00007c47757dbce7  por xmm8, xmm2
00007c47757dbcec  movaps xmm2, [r15+0x2D0]
00007c47757dbcf4  vmovaps [rsp+0x90], xmm2
00007c47757dbcfd  vmovaps [rsp+0xA0], xmm1
00007c47757dbd06  vmovaps xmm1, [rsp+0x90]
00007c47757dbd0f  por xmm2, xmm1
00007c47757dbd13  movaps xmm1, [r15+0x200]
00007c47757dbd1b  vmovaps [rsp+0x90], xmm1
00007c47757dbd24  vmovaps [rsp+0xB0], xmm15
00007c47757dbd2d  vmovaps xmm15, [rsp+0x90]
00007c47757dbd36  por xmm1, xmm15
00007c47757dbd3b  movaps xmm15, [r15+0x1C0]
00007c47757dbd43  vmovaps [rsp+0x90], xmm15
00007c47757dbd4c  vmovaps [rsp+0xC0], xmm1
00007c47757dbd55  vmovaps xmm1, [rsp+0x90]
00007c47757dbd5e  por xmm15, xmm1
00007c47757dbd63  movaps xmm1, [r15+0x190]
00007c47757dbd6b  vmovaps [rsp+0x90], xmm1
00007c47757dbd74  vmovaps [rsp+0xD0], xmm15
00007c47757dbd7d  vmovaps xmm15, [rsp+0x90]
00007c47757dbd86  por xmm1, xmm15
00007c47757dbd8b  movaps xmm15, [r15+0x300]
00007c47757dbd93  vmovaps [rsp+0x90], xmm15
00007c47757dbd9c  vmovaps [rsp+0xE0], xmm1
00007c47757dbda5  vmovaps xmm1, [rsp+0x90]
00007c47757dbdae  por xmm15, xmm1
00007c47757dbdb3  mov rax, [rsp+0x80]
00007c47757dbdbb  lea r12, [rax+0xA0]
00007c47757dbdc2  movups xmm1, [r13+r12*1]
00007c47757dbdc8  lea r12, [rax+0xB0]
00007c47757dbdcf  vmovaps [rsp+0x80], xmm1
00007c47757dbdd8  movups xmm1, [r13+r12*1]
00007c47757dbdde  vmovaps [rsp+0x90], xmm1
00007c47757dbde7  vmovaps [rsp+0xF0], xmm15
00007c47757dbdf0  vmovaps xmm15, [rsp+0xB0]
00007c47757dbdf9  vmovaps [rsp+0xB0], xmm14
00007c47757dbe02  movaps xmm1, xmm6
00007c47757dbe05  addpd xmm1, xmm15
00007c47757dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007c47757dbe0f  ptest xmm14, xmm14
00007c47757dbe15  jnz 0x00007C47757DD4D6
00007c47757dbe1b  lea r12, [rax+0xF0]
00007c47757dbe22  movups xmm15, [r13+r12*1]
00007c47757dbe28  movaps xmm14, xmm4
00007c47757dbe2c  addpd xmm14, xmm3
00007c47757dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007c47757dbe37  ptest xmm6, xmm6
00007c47757dbe3c  jnz 0x00007C47757DD621
00007c47757dbe42  movaps xmm6, xmm9
00007c47757dbe46  addpd xmm6, xmm7
00007c47757dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007c47757dbe4f  ptest xmm4, xmm4
00007c47757dbe54  jnz 0x00007C47757DD763
00007c47757dbe5a  vmovaps xmm9, [rsp+0x70]
00007c47757dbe60  vpermilpd xmm9, xmm9, 0x00
00007c47757dbe66  vmovaps xmm4, [rsp+0x90]
00007c47757dbe6f  movaps xmm7, xmm4
00007c47757dbe72  mulpd xmm7, xmm9
00007c47757dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007c47757dbe7c  ptest xmm3, xmm3
00007c47757dbe81  jnz 0x00007C47757DD8A4
00007c47757dbe87  vmovaps xmm9, [rsp+0x50]
00007c47757dbe8d  vpermilpd xmm9, xmm9, 0x00
00007c47757dbe93  movaps xmm4, xmm15
00007c47757dbe97  mulpd xmm4, xmm9
00007c47757dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007c47757dbea1  ptest xmm3, xmm3
00007c47757dbea6  jnz 0x00007C47757DD9E5
00007c47757dbeac  lea r12, [rax+0xE0]
00007c47757dbeb3  movups xmm15, [r13+r12*1]
00007c47757dbeb9  vmovaps xmm9, [rsp+0x70]
00007c47757dbebf  vpermilpd xmm9, xmm9, 0x00
00007c47757dbec5  vmovaps [rsp+0x70], xmm1
00007c47757dbecb  vmovaps xmm1, [rsp+0x80]
00007c47757dbed4  vmovaps [rsp+0x80], xmm15
00007c47757dbedd  movaps xmm3, xmm1
00007c47757dbee0  mulpd xmm3, xmm9
00007c47757dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007c47757dbeea  ptest xmm15, xmm15
00007c47757dbef0  jnz 0x00007C47757DDB31
00007c47757dbef6  vmovaps xmm1, [rsp+0xF0]
00007c47757dbeff  vmovaps xmm15, [rsp+0xF0]
00007c47757dbf08  por xmm1, xmm15
00007c47757dbf0d  movaps [r15+0x300], xmm1
00007c47757dbf15  vmovaps xmm15, [rsp+0xE0]
00007c47757dbf1e  vmovaps xmm9, [rsp+0xE0]
00007c47757dbf27  por xmm15, xmm9
00007c47757dbf2c  movaps [r15+0x190], xmm15
00007c47757dbf34  vmovaps xmm9, [rsp+0x50]
00007c47757dbf3a  vpermilpd xmm9, xmm9, 0x00
00007c47757dbf40  vmovaps [rsp+0x90], xmm1
00007c47757dbf49  vmovaps [rsp+0xE0], xmm15
00007c47757dbf52  vmovaps xmm15, [rsp+0x80]
00007c47757dbf5b  vmovaps [rsp+0x80], xmm14
00007c47757dbf64  movaps xmm1, xmm15
00007c47757dbf68  mulpd xmm1, xmm9
00007c47757dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007c47757dbf72  ptest xmm14, xmm14
00007c47757dbf78  jnz 0x00007C47757DDC72
00007c47757dbf7e  lea r12, [rax+0x90]
00007c47757dbf85  movups xmm15, [r13+r12*1]
00007c47757dbf8b  vmovaps xmm14, [rsp+0xD0]
00007c47757dbf94  vmovaps xmm9, [rsp+0xD0]
00007c47757dbf9d  por xmm14, xmm9
00007c47757dbfa2  movaps [r15+0x1C0], xmm14
00007c47757dbfaa  vmovaps xmm9, [rsp+0xC0]
00007c47757dbfb3  vmovaps [rsp+0xD0], xmm1
00007c47757dbfbc  vmovaps xmm1, [rsp+0xC0]
00007c47757dbfc5  por xmm9, xmm1
00007c47757dbfca  movaps [r15+0x200], xmm9
00007c47757dbfd2  vmovaps [rsp+0xC0], xmm2
00007c47757dbfdb  vmovaps xmm1, [rsp+0xC0]
00007c47757dbfe4  por xmm2, xmm1
00007c47757dbfe8  movaps [r15+0x2D0], xmm2
00007c47757dbff0  vmovaps [rsp+0xC0], xmm8
00007c47757dbff9  vmovaps xmm1, [rsp+0xC0]
00007c47757dc002  por xmm8, xmm1
00007c47757dc007  movaps [r15+0x2E0], xmm8
00007c47757dc00f  vmovaps [rsp+0xC0], xmm15
00007c47757dc018  movaps xmm1, xmm5
00007c47757dc01b  addpd xmm1, xmm7
00007c47757dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007c47757dc024  ptest xmm15, xmm15
00007c47757dc02a  jnz 0x00007C47757DDDBE
00007c47757dc030  vmovaps xmm15, [rsp+0x50]
00007c47757dc036  vpermilpd xmm15, xmm15, 0x00
00007c47757dc03c  vmovaps xmm5, [rsp+0xC0]
00007c47757dc045  vmovaps [rsp+0xC0], xmm1
00007c47757dc04e  movaps xmm7, xmm5
00007c47757dc051  mulpd xmm7, xmm15
00007c47757dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007c47757dc05b  ptest xmm1, xmm1
00007c47757dc060  jnz 0x00007C47757DDEFE
00007c47757dc066  lea r12, [rax+0x80]
00007c47757dc06d  movups xmm1, [r13+r12*1]
00007c47757dc073  vmovaps xmm5, [rsp+0x70]
00007c47757dc079  vmovaps [rsp+0x70], xmm1
00007c47757dc07f  movaps xmm15, xmm5
00007c47757dc083  addpd xmm15, xmm3
00007c47757dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757dc08e  ptest xmm1, xmm1
00007c47757dc093  jnz 0x00007C47757DE049
00007c47757dc099  vmovaps xmm5, [rsp+0x80]
00007c47757dc0a2  movaps xmm1, xmm5
00007c47757dc0a5  addpd xmm1, xmm4
00007c47757dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007c47757dc0ae  ptest xmm3, xmm3
00007c47757dc0b3  jnz 0x00007C47757DE18B
00007c47757dc0b9  vmovaps [rsp+0x80], xmm10
00007c47757dc0c2  vmovaps xmm5, [rsp+0x80]
00007c47757dc0cb  por xmm10, xmm5
00007c47757dc0d0  movaps [r15+0x2F0], xmm10
00007c47757dc0d8  vmovaps xmm5, [rsp+0x50]
00007c47757dc0de  vpermilpd xmm5, xmm5, 0x00
00007c47757dc0e4  vmovaps xmm3, [rsp+0x70]
00007c47757dc0ea  vmovaps [rsp+0x50], xmm1
00007c47757dc0f0  movaps xmm4, xmm3
00007c47757dc0f3  mulpd xmm4, xmm5
00007c47757dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007c47757dc0fc  ptest xmm1, xmm1
00007c47757dc101  jnz 0x00007C47757DE2CB
00007c47757dc107  lea r12, [rax+0xD0]
00007c47757dc10e  movups xmm1, [r13+r12*1]
00007c47757dc114  vmovaps xmm3, [rsp+0xD0]
00007c47757dc11d  vmovaps [rsp+0x70], xmm1
00007c47757dc123  movaps xmm5, xmm6
00007c47757dc126  addpd xmm5, xmm3
00007c47757dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007c47757dc12f  ptest xmm1, xmm1
00007c47757dc134  jnz 0x00007C47757DE415
00007c47757dc13a  vmovaps xmm1, [rsp+0x60]
00007c47757dc140  vpermilpd xmm1, xmm1, 0x00
00007c47757dc146  movaps xmm6, xmm9
00007c47757dc14a  mulpd xmm6, xmm1
00007c47757dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007c47757dc153  ptest xmm3, xmm3
00007c47757dc158  jnz 0x00007C47757DE555
00007c47757dc15e  movaps [r15+0x260], xmm6
00007c47757dc166  vxorps xmm1, xmm1, xmm1
00007c47757dc16a  vpbroadcastq xmm1, xmm1
00007c47757dc16f  movaps [r15+0x1B0], xmm1
00007c47757dc177  vmovaps xmm1, [rsp+0x60]
00007c47757dc17d  vpermilpd xmm1, xmm1, 0x00
00007c47757dc183  vmovaps xmm3, [rsp+0x70]
00007c47757dc189  vmovaps [rsp+0x70], xmm15
00007c47757dc18f  movaps xmm9, xmm3
00007c47757dc193  mulpd xmm9, xmm1
00007c47757dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007c47757dc19e  ptest xmm15, xmm15
00007c47757dc1a4  jnz 0x00007C47757DE696
00007c47757dc1aa  lea r12, [rax+0xC0]
00007c47757dc1b1  movups xmm1, [r13+r12*1]
00007c47757dc1b7  vmovaps xmm3, [rsp+0xC0]
00007c47757dc1c0  vmovaps [rsp+0x80], xmm1
00007c47757dc1c9  movaps xmm15, xmm3
00007c47757dc1cd  addpd xmm15, xmm7
00007c47757dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757dc1d8  ptest xmm1, xmm1
00007c47757dc1dd  jnz 0x00007C47757DE7E2
00007c47757dc1e3  vmovaps [rsp+0xC0], xmm13
00007c47757dc1ec  vmovaps xmm1, [rsp+0xC0]
00007c47757dc1f5  por xmm13, xmm1
00007c47757dc1fa  movaps [r15+0x270], xmm13
00007c47757dc202  vmovaps xmm1, [rsp+0xB0]
00007c47757dc20b  vmovaps xmm7, [rsp+0xB0]
00007c47757dc214  por xmm1, xmm7
00007c47757dc218  movaps [r15+0x1A0], xmm1
00007c47757dc220  vmovaps xmm1, [rsp+0x60]
00007c47757dc226  vpermilpd xmm1, xmm1, 0x00
00007c47757dc22c  vmovaps [rsp+0xB0], xmm1
00007c47757dc235  vmovaps xmm1, [rsp+0x80]
00007c47757dc23e  vmovaps [rsp+0x80], xmm15
00007c47757dc247  vmovaps xmm15, [rsp+0xB0]
00007c47757dc250  vmovaps [rsp+0xB0], xmm14
00007c47757dc259  movaps xmm3, xmm1
00007c47757dc25c  mulpd xmm3, xmm15
00007c47757dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007c47757dc266  ptest xmm14, xmm14
00007c47757dc26c  jnz 0x00007C47757DE924
00007c47757dc272  lea r12, [rax+0x20]
00007c47757dc276  movups xmm1, [r13+r12*1]
00007c47757dc27c  movaps [r15+0x110], xmm1
00007c47757dc284  vmovaps xmm14, [rsp+0x70]
00007c47757dc28a  vmovaps [rsp+0x70], xmm1
00007c47757dc290  movaps xmm15, xmm14
00007c47757dc294  addpd xmm15, xmm4
00007c47757dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007c47757dc29f  ptest xmm1, xmm1
00007c47757dc2a4  jnz 0x00007C47757DEA6F
00007c47757dc2aa  vmovaps xmm1, [rsp+0x60]
00007c47757dc2b0  vpermilpd xmm1, xmm1, 0x00
00007c47757dc2b6  movaps xmm14, xmm2
00007c47757dc2ba  mulpd xmm14, xmm1
00007c47757dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007c47757dc2c5  ptest xmm4, xmm4
00007c47757dc2ca  jnz 0x00007C47757DEBB2
00007c47757dc2d0  vmovaps xmm4, [rsp+0x50]
00007c47757dc2d6  movaps xmm1, xmm4
00007c47757dc2d9  addpd xmm1, xmm9
00007c47757dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007c47757dc2e3  ptest xmm2, xmm2
00007c47757dc2e8  jnz 0x00007C47757DECF4
00007c47757dc2ee  vmovaps xmm9, [rsp+0x30]
00007c47757dc2f4  vpermilpd xmm9, xmm9, 0x00
00007c47757dc2fa  vmovaps xmm2, [rsp+0x70]
00007c47757dc300  vmovaps [rsp+0x50], xmm1
00007c47757dc306  movaps xmm4, xmm2
00007c47757dc309  mulpd xmm4, xmm9
00007c47757dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007c47757dc313  ptest xmm1, xmm1
00007c47757dc318  jnz 0x00007C47757DEE35
00007c47757dc31e  vmovaps xmm1, [rsp+0x30]
00007c47757dc324  vpermilpd xmm1, xmm1, 0x00
00007c47757dc32a  vmovaps xmm2, [rsp+0x90]
00007c47757dc333  vmovaps [rsp+0x60], xmm15
00007c47757dc339  movaps xmm9, xmm2
00007c47757dc33d  mulpd xmm9, xmm1
00007c47757dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007c47757dc348  ptest xmm15, xmm15
00007c47757dc34e  jnz 0x00007C47757DEF76
00007c47757dc354  vmovaps xmm15, [rsp+0x80]
00007c47757dc35d  movaps xmm1, xmm15
00007c47757dc361  addpd xmm1, xmm6
00007c47757dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007c47757dc36a  ptest xmm2, xmm2
00007c47757dc36f  jnz 0x00007C47757DF0B8
00007c47757dc375  movaps xmm15, xmm5
00007c47757dc379  addpd xmm15, xmm3
00007c47757dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007c47757dc384  ptest xmm6, xmm6
00007c47757dc389  jnz 0x00007C47757DF1F9
00007c47757dc38f  vmovaps xmm6, [rsp+0x30]
00007c47757dc395  vpermilpd xmm6, xmm6, 0x00
00007c47757dc39b  movaps xmm5, xmm8
00007c47757dc39f  mulpd xmm5, xmm6
00007c47757dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007c47757dc3a8  ptest xmm3, xmm3
00007c47757dc3ad  jnz 0x00007C47757DF33B
00007c47757dc3b3  vmovaps xmm8, [rsp+0x30]
00007c47757dc3b9  vpermilpd xmm8, xmm8, 0x00
00007c47757dc3bf  movaps xmm6, xmm10
00007c47757dc3c3  mulpd xmm6, xmm8
00007c47757dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007c47757dc3cd  ptest xmm3, xmm3
00007c47757dc3d2  jnz 0x00007C47757DF47C
00007c47757dc3d8  vmovaps xmm8, [rsp+0x60]
00007c47757dc3de  movaps xmm10, xmm8
00007c47757dc3e2  addpd xmm10, xmm14
00007c47757dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007c47757dc3ed  ptest xmm3, xmm3
00007c47757dc3f2  jnz 0x00007C47757DF5BE
00007c47757dc3f8  vmovaps xmm8, [rsp+0x50]
00007c47757dc3fe  movaps xmm14, xmm8
00007c47757dc402  addpd xmm14, xmm4
00007c47757dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007c47757dc40d  ptest xmm3, xmm3
00007c47757dc412  jnz 0x00007C47757DF702
00007c47757dc418  vmovaps xmm8, [rsp+0x40]
00007c47757dc41e  vpermilpd xmm8, xmm8, 0x00
00007c47757dc424  movaps xmm4, xmm13
00007c47757dc428  mulpd xmm4, xmm8
00007c47757dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007c47757dc432  ptest xmm3, xmm3
00007c47757dc437  jnz 0x00007C47757DF845
00007c47757dc43d  movaps xmm13, xmm15
00007c47757dc441  addpd xmm13, xmm9
00007c47757dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007c47757dc44c  ptest xmm8, xmm8
00007c47757dc452  jnz 0x00007C47757DF987
00007c47757dc458  movaps xmm15, xmm1
00007c47757dc45c  addpd xmm15, xmm5
00007c47757dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007c47757dc467  ptest xmm9, xmm9
00007c47757dc46d  jnz 0x00007C47757DFACB
00007c47757dc473  vmovaps [rsp+0x30], xmm11
00007c47757dc479  vmovaps xmm1, [rsp+0x30]
00007c47757dc47f  por xmm11, xmm1
00007c47757dc484  movaps [r15+0x250], xmm11
00007c47757dc48c  vmovaps [rsp+0x30], xmm12
00007c47757dc492  vmovaps xmm1, [rsp+0x30]
00007c47757dc498  por xmm12, xmm1
00007c47757dc49d  movaps [r15+0x2A0], xmm12
00007c47757dc4a5  vmovaps xmm1, [rsp+0xA0]
00007c47757dc4ae  vmovaps xmm11, [rsp+0xA0]
00007c47757dc4b7  por xmm1, xmm11
00007c47757dc4bc  movaps [r15+0x1D0], xmm1
00007c47757dc4c4  lea r12, [rax+0x40]
00007c47757dc4c8  movups xmm1, [r13+r12*1]
00007c47757dc4ce  movaps [r15+0x2C0], xmm1
00007c47757dc4d6  vmovaps xmm11, [rsp+0x40]
00007c47757dc4dc  vpermilpd xmm11, xmm11, 0x00
00007c47757dc4e2  vmovaps xmm8, [rsp+0xE0]
00007c47757dc4eb  movaps xmm9, xmm8
00007c47757dc4ef  mulpd xmm9, xmm11
00007c47757dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007c47757dc4fa  ptest xmm5, xmm5
00007c47757dc4ff  jnz 0x00007C47757DFC17
00007c47757dc505  movaps xmm11, xmm10
00007c47757dc509  addpd xmm11, xmm6
00007c47757dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007c47757dc514  ptest xmm8, xmm8
00007c47757dc51a  jnz 0x00007C47757DFD5B
00007c47757dc520  movaps xmm10, xmm14
00007c47757dc524  addpd xmm10, xmm4
00007c47757dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007c47757dc52f  ptest xmm8, xmm8
00007c47757dc535  jnz 0x00007C47757DFE9E
00007c47757dc53b  vmovaps xmm14, [rsp+0x40]
00007c47757dc541  vpermilpd xmm14, xmm14, 0x00
00007c47757dc547  movaps xmm8, xmm1
00007c47757dc54b  mulpd xmm8, xmm14
00007c47757dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007c47757dc556  ptest xmm6, xmm6
00007c47757dc55b  jnz 0x00007C47757DFFE1
00007c47757dc561  movaps xmm1, [r15+0x2B0]
00007c47757dc569  vmovaps xmm14, [rsp+0x40]
00007c47757dc56f  vpermilpd xmm14, xmm14, 0x00
00007c47757dc575  movaps xmm6, xmm1
00007c47757dc578  mulpd xmm6, xmm14
00007c47757dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007c47757dc582  ptest xmm5, xmm5
00007c47757dc587  jnz 0x00007C47757E0124
00007c47757dc58d  vmovaps xmm1, [rsp+0x10]
00007c47757dc593  vpermilpd xmm1, xmm1, 0x00
00007c47757dc599  movaps xmm14, xmm12
00007c47757dc59d  mulpd xmm14, xmm1
00007c47757dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007c47757dc5a8  ptest xmm5, xmm5
00007c47757dc5ad  jnz 0x00007C47757E0265
00007c47757dc5b3  movaps xmm1, xmm13
00007c47757dc5b7  addpd xmm1, xmm9
00007c47757dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007c47757dc5c1  ptest xmm12, xmm12
00007c47757dc5c7  jnz 0x00007C47757E03A8
00007c47757dc5cd  vmovaps xmm13, [rsp+0x10]
00007c47757dc5d3  vpermilpd xmm13, xmm13, 0x00
00007c47757dc5d9  movaps xmm12, xmm7
00007c47757dc5dd  mulpd xmm12, xmm13
00007c47757dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007c47757dc5e8  ptest xmm9, xmm9
00007c47757dc5ee  jnz 0x00007C47757E04EA
00007c47757dc5f4  movaps xmm13, xmm15
00007c47757dc5f8  addpd xmm13, xmm8
00007c47757dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007c47757dc603  ptest xmm9, xmm9
00007c47757dc609  jnz 0x00007C47757E062D
00007c47757dc60f  movaps xmm15, [r15+0x290]
00007c47757dc617  vmovaps xmm9, [rsp+0x10]
00007c47757dc61d  vpermilpd xmm9, xmm9, 0x00
00007c47757dc623  movaps xmm8, xmm15
00007c47757dc627  mulpd xmm8, xmm9
00007c47757dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007c47757dc632  ptest xmm7, xmm7
00007c47757dc637  jnz 0x00007C47757E0771
00007c47757dc63d  movaps xmm15, xmm11
00007c47757dc641  addpd xmm15, xmm6
00007c47757dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007c47757dc64c  ptest xmm9, xmm9
00007c47757dc652  jnz 0x00007C47757E08B5
00007c47757dc658  movaps xmm11, [r15+0x1E0]
00007c47757dc660  vmovaps xmm9, [rsp+0x10]
00007c47757dc666  vpermilpd xmm9, xmm9, 0x00
00007c47757dc66c  movaps xmm7, xmm11
00007c47757dc670  mulpd xmm7, xmm9
00007c47757dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007c47757dc67a  ptest xmm6, xmm6
00007c47757dc67f  jnz 0x00007C47757E09F8
00007c47757dc685  movaps xmm11, xmm10
00007c47757dc689  addpd xmm11, xmm14
00007c47757dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007c47757dc694  ptest xmm9, xmm9
00007c47757dc69a  jnz 0x00007C47757E0B3A
00007c47757dc6a0  lea r12, [rax+0x70]
00007c47757dc6a4  movups xmm14, [r13+r12*1]
00007c47757dc6aa  movaps [r15+0x240], xmm14
00007c47757dc6b2  movaps xmm10, xmm1
00007c47757dc6b6  addpd xmm10, xmm12
00007c47757dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007c47757dc6c1  ptest xmm9, xmm9
00007c47757dc6c7  jnz 0x00007C47757E0C88
00007c47757dc6cd  movaps [r15+0x170], xmm10
00007c47757dc6d5  vmovaps xmm1, [rsp+0x20]
00007c47757dc6db  vpermilpd xmm1, xmm1, 0x00
00007c47757dc6e1  movaps xmm12, xmm14
00007c47757dc6e5  mulpd xmm12, xmm1
00007c47757dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007c47757dc6f0  ptest xmm9, xmm9
00007c47757dc6f6  jnz 0x00007C47757E0DCB
00007c47757dc6fc  vmovaps xmm1, [rsp+0x20]
00007c47757dc702  vpermilpd xmm1, xmm1, 0x00
00007c47757dc708  vmovaps xmm9, [rsp+0xB0]
00007c47757dc711  movaps xmm14, xmm9
00007c47757dc715  mulpd xmm14, xmm1
00007c47757dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007c47757dc720  ptest xmm6, xmm6
00007c47757dc725  jnz 0x00007C47757E0F0E
00007c47757dc72b  movaps [r15+0x180], xmm14
00007c47757dc733  movaps xmm1, xmm13
00007c47757dc737  addpd xmm1, xmm8
00007c47757dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007c47757dc741  ptest xmm9, xmm9
00007c47757dc747  jnz 0x00007C47757E1051
00007c47757dc74d  movaps [r15+0x210], xmm1
00007c47757dc755  movups xmm13, [r13+rax*1]
00007c47757dc75b  lea r12, [rax+0x10]
00007c47757dc75f  movups xmm9, [r13+r12*1]
00007c47757dc765  movaps [r15+0x230], xmm9
00007c47757dc76d  movaps xmm8, xmm15
00007c47757dc771  addpd xmm8, xmm7
00007c47757dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007c47757dc77c  ptest xmm6, xmm6
00007c47757dc781  jnz 0x00007C47757E11A7
00007c47757dc787  movaps [r15+0x130], xmm8
00007c47757dc78f  vmovaps xmm15, [rsp+0x20]
00007c47757dc795  vpermilpd xmm15, xmm15, 0x00
00007c47757dc79b  movaps xmm7, xmm9
00007c47757dc79f  mulpd xmm7, xmm15
00007c47757dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007c47757dc7a9  ptest xmm6, xmm6
00007c47757dc7ae  jnz 0x00007C47757E12EA
00007c47757dc7b4  movaps [r15+0x220], xmm7
00007c47757dc7bc  vmovaps xmm15, [rsp+0x20]
00007c47757dc7c2  vpermilpd xmm15, xmm15, 0x00
00007c47757dc7c8  movaps xmm9, xmm13
00007c47757dc7cc  mulpd xmm9, xmm15
00007c47757dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007c47757dc7d7  ptest xmm6, xmm6
00007c47757dc7dc  jnz 0x00007C47757E142C
00007c47757dc7e2  movaps xmm15, xmm11
00007c47757dc7e6  addpd xmm15, xmm12
00007c47757dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007c47757dc7f1  ptest xmm13, xmm13
00007c47757dc7f7  jnz 0x00007C47757E1570
00007c47757dc7fd  movaps [r15+0x140], xmm15
00007c47757dc805  movaps xmm13, xmm10
00007c47757dc809  addpd xmm13, xmm14
00007c47757dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007c47757dc814  ptest xmm12, xmm12
00007c47757dc81a  jnz 0x00007C47757E16B4
00007c47757dc820  movaps [r15+0x150], xmm13
00007c47757dc828  movaps xmm14, xmm1
00007c47757dc82c  addpd xmm14, xmm7
00007c47757dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007c47757dc837  ptest xmm12, xmm12
00007c47757dc83d  jnz 0x00007C47757E17F8
00007c47757dc843  movaps [r15+0x160], xmm14
00007c47757dc84b  movaps xmm1, xmm8
00007c47757dc84f  addpd xmm1, xmm9
00007c47757dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007c47757dc859  ptest xmm12, xmm12
00007c47757dc85f  jnz 0x00007C47757E193A
00007c47757dc865  movaps [r15+0x120], xmm1
00007c47757dc86d  movups [r13+r14*1], xmm15
00007c47757dc873  lea rax, [r14+0x10]
00007c47757dc877  movups [r13+rax*1], xmm13
00007c47757dc87d  lea rax, [r14+0x20]
00007c47757dc881  movups [r13+rax*1], xmm14
00007c47757dc887  lea rax, [r14+0x30]
00007c47757dc88b  movups [r13+rax*1], xmm1
00007c47757dc891  mov eax, [r15+0x108]
00007c47757dc898  sahf
00007c47757dc899  jnz 0x00007C47757DC8CB
00007c47757dc89b  cmp dword ptr [r15+0x318], 0x00
00007c47757dc8a3  jz 0x00007C47757DB900
00007c47757dc8a9  nop [rax+rax*1], ax
00007c47757dc8b2  nop [rax+rax*1], eax
00007c47757dc8ba  mov eax, 0x410444
00007c47757dc8bf  mov [r15+0x100], rax
00007c47757dc8c6  jmp 0x00007C47755FE110
00007c47757dc8cb  cmp dword ptr [r15+0x318], 0x00
00007c47757dc8d3  jz 0x00007C47757D57E0
00007c47757dc8d9  nop [rax+rax*1], ax
00007c47757dc8e2  nop [rax+rax*1], eax
00007c47757dc8ea  mov eax, 0x410278
00007c47757dc8ef  mov [r15+0x100], rax
00007c47757dc8f6  jmp 0x00007C47755FE110
00007c47757dc8fb  int3
00007c47757dc8fc  call 0x00007C47756E27E0
00007c47757dc901  jmp 0x00007C47757DB9DF
00007c47757dc906  call 0x00007C47756E1570
00007c47757dc90b  jmp 0x00007C47757DB9E8
00007c47757dc910  call 0x00007C47756E27E0
00007c47757dc915  jmp 0x00007C47757DBA44
00007c47757dc91a  call 0x00007C47756E1570
00007c47757dc91f  jmp 0x00007C47757DBA4D
00007c47757dc924  call 0x00007C47756E27E0
00007c47757dc929  jmp 0x00007C47757DBA90
00007c47757dc92e  call 0x00007C47756E1570
00007c47757dc933  jmp 0x00007C47757DBA99
00007c47757dc938  call 0x00007C477560DC20
00007c47757dc93d  jmp 0x00007C47757DBAD8
00007c47757dc942  call 0x00007C47756D59C0
00007c47757dc947  jmp 0x00007C47757DBAEB
00007c47757dc94c  call 0x00007C47756E0E30
00007c47757dc951  jmp 0x00007C47757DBB09
00007c47757dc956  call 0x00007C47756DFBC0
00007c47757dc95b  jmp 0x00007C47757DBB13
00007c47757dc960  call 0x00007C47756DE950
00007c47757dc965  jmp 0x00007C47757DBB1D
00007c47757dc96a  sub rsp, 0x08
00007c47757dc96e  push rax
00007c47757dc96f  push rcx
00007c47757dc970  push rdx
00007c47757dc971  push rdi
00007c47757dc972  push rsi
00007c47757dc973  push r8
00007c47757dc975  push r9
00007c47757dc977  push r10
00007c47757dc979  push r11
00007c47757dc97b  sub rsp, 0xF0
00007c47757dc982  vmovaps [rsp], xmm0
00007c47757dc987  vmovaps [rsp+0x10], xmm1
00007c47757dc98d  vmovaps [rsp+0x20], xmm2
00007c47757dc993  vmovaps [rsp+0x30], xmm3
00007c47757dc999  vmovaps [rsp+0x40], xmm4
00007c47757dc99f  vmovaps [rsp+0x50], xmm5
00007c47757dc9a5  vmovaps [rsp+0x60], xmm6
00007c47757dc9ab  vmovaps [rsp+0x70], xmm7
00007c47757dc9b1  vmovaps [rsp+0x80], xmm9
00007c47757dc9ba  vmovaps [rsp+0x90], xmm10
00007c47757dc9c3  vmovaps [rsp+0xA0], xmm11
00007c47757dc9cc  vmovaps [rsp+0xB0], xmm12
00007c47757dc9d5  vmovaps [rsp+0xC0], xmm13
00007c47757dc9de  vmovaps [rsp+0xD0], xmm14
00007c47757dc9e7  vmovaps [rsp+0xE0], xmm15
00007c47757dc9f0  sub rsp, 0x30
00007c47757dc9f4  movaps [rsp], xmm8
00007c47757dc9f9  movaps [rsp+0x10], xmm12
00007c47757dc9ff  movaps [rsp+0x20], xmm15
00007c47757dca05  lea rdi, [rsp]
00007c47757dca09  mov esi, 0x00
00007c47757dca0e  mov rax, 0x62084E409530
00007c47757dca18  call rax
00007c47757dca1a  movaps xmm8, [rsp]
00007c47757dca1f  add rsp, 0x30
00007c47757dca23  vmovaps xmm0, [rsp]
00007c47757dca28  vmovaps xmm1, [rsp+0x10]
00007c47757dca2e  vmovaps xmm2, [rsp+0x20]
00007c47757dca34  vmovaps xmm3, [rsp+0x30]
00007c47757dca3a  vmovaps xmm4, [rsp+0x40]
00007c47757dca40  vmovaps xmm5, [rsp+0x50]
00007c47757dca46  vmovaps xmm6, [rsp+0x60]
00007c47757dca4c  vmovaps xmm7, [rsp+0x70]
00007c47757dca52  vmovaps xmm9, [rsp+0x80]
00007c47757dca5b  vmovaps xmm10, [rsp+0x90]
00007c47757dca64  vmovaps xmm11, [rsp+0xA0]
00007c47757dca6d  vmovaps xmm12, [rsp+0xB0]
00007c47757dca76  vmovaps xmm13, [rsp+0xC0]
00007c47757dca7f  vmovaps xmm14, [rsp+0xD0]
00007c47757dca88  vmovaps xmm15, [rsp+0xE0]
00007c47757dca91  add rsp, 0xF0
00007c47757dca98  pop r11
00007c47757dca9a  pop r10
00007c47757dca9c  pop r9
00007c47757dca9e  pop r8
00007c47757dcaa0  pop rsi
00007c47757dcaa1  pop rdi
00007c47757dcaa2  pop rdx
00007c47757dcaa3  pop rcx
00007c47757dcaa4  pop rax
00007c47757dcaa5  add rsp, 0x08
00007c47757dcaa9  jmp 0x00007C47757DBB47
00007c47757dcaae  sub rsp, 0x08
00007c47757dcab2  push rax
00007c47757dcab3  push rcx
00007c47757dcab4  push rdx
00007c47757dcab5  push rdi
00007c47757dcab6  push rsi
00007c47757dcab7  push r8
00007c47757dcab9  push r9
00007c47757dcabb  push r10
00007c47757dcabd  push r11
00007c47757dcabf  sub rsp, 0xF0
00007c47757dcac6  vmovaps [rsp], xmm0
00007c47757dcacb  vmovaps [rsp+0x10], xmm1
00007c47757dcad1  vmovaps [rsp+0x20], xmm2
00007c47757dcad7  vmovaps [rsp+0x30], xmm3
00007c47757dcadd  vmovaps [rsp+0x40], xmm4
00007c47757dcae3  vmovaps [rsp+0x50], xmm5
00007c47757dcae9  vmovaps [rsp+0x60], xmm6
00007c47757dcaef  vmovaps [rsp+0x70], xmm8
00007c47757dcaf5  vmovaps [rsp+0x80], xmm9
00007c47757dcafe  vmovaps [rsp+0x90], xmm10
00007c47757dcb07  vmovaps [rsp+0xA0], xmm11
00007c47757dcb10  vmovaps [rsp+0xB0], xmm12
00007c47757dcb19  vmovaps [rsp+0xC0], xmm13
00007c47757dcb22  vmovaps [rsp+0xD0], xmm14
00007c47757dcb2b  vmovaps [rsp+0xE0], xmm15
00007c47757dcb34  sub rsp, 0x30
00007c47757dcb38  movaps [rsp], xmm7
00007c47757dcb3c  movaps [rsp+0x10], xmm9
00007c47757dcb42  movaps [rsp+0x20], xmm15
00007c47757dcb48  lea rdi, [rsp]
00007c47757dcb4c  mov esi, 0x00
00007c47757dcb51  mov rax, 0x62084E409530
00007c47757dcb5b  call rax
00007c47757dcb5d  movaps xmm7, [rsp]
00007c47757dcb61  add rsp, 0x30
00007c47757dcb65  vmovaps xmm0, [rsp]
00007c47757dcb6a  vmovaps xmm1, [rsp+0x10]
00007c47757dcb70  vmovaps xmm2, [rsp+0x20]
00007c47757dcb76  vmovaps xmm3, [rsp+0x30]
00007c47757dcb7c  vmovaps xmm4, [rsp+0x40]
00007c47757dcb82  vmovaps xmm5, [rsp+0x50]
00007c47757dcb88  vmovaps xmm6, [rsp+0x60]
00007c47757dcb8e  vmovaps xmm8, [rsp+0x70]
00007c47757dcb94  vmovaps xmm9, [rsp+0x80]
00007c47757dcb9d  vmovaps xmm10, [rsp+0x90]
00007c47757dcba6  vmovaps xmm11, [rsp+0xA0]
00007c47757dcbaf  vmovaps xmm12, [rsp+0xB0]
00007c47757dcbb8  vmovaps xmm13, [rsp+0xC0]
00007c47757dcbc1  vmovaps xmm14, [rsp+0xD0]
00007c47757dcbca  vmovaps xmm15, [rsp+0xE0]
00007c47757dcbd3  add rsp, 0xF0
00007c47757dcbda  pop r11
00007c47757dcbdc  pop r10
00007c47757dcbde  pop r9
00007c47757dcbe0  pop r8
00007c47757dcbe2  pop rsi
00007c47757dcbe3  pop rdi
00007c47757dcbe4  pop rdx
00007c47757dcbe5  pop rcx
00007c47757dcbe6  pop rax
00007c47757dcbe7  add rsp, 0x08
00007c47757dcbeb  jmp 0x00007C47757DBB75
00007c47757dcbf0  sub rsp, 0x08
00007c47757dcbf4  push rax
00007c47757dcbf5  push rcx
00007c47757dcbf6  push rdx
00007c47757dcbf7  push rdi
00007c47757dcbf8  push rsi
00007c47757dcbf9  push r8
00007c47757dcbfb  push r9
00007c47757dcbfd  push r10
00007c47757dcbff  push r11
00007c47757dcc01  sub rsp, 0xF0
00007c47757dcc08  vmovaps [rsp], xmm0
00007c47757dcc0d  vmovaps [rsp+0x10], xmm1
00007c47757dcc13  vmovaps [rsp+0x20], xmm2
00007c47757dcc19  vmovaps [rsp+0x30], xmm3
00007c47757dcc1f  vmovaps [rsp+0x40], xmm4
00007c47757dcc25  vmovaps [rsp+0x50], xmm5
00007c47757dcc2b  vmovaps [rsp+0x60], xmm6
00007c47757dcc31  vmovaps [rsp+0x70], xmm7
00007c47757dcc37  vmovaps [rsp+0x80], xmm8
00007c47757dcc40  vmovaps [rsp+0x90], xmm10
00007c47757dcc49  vmovaps [rsp+0xA0], xmm11
00007c47757dcc52  vmovaps [rsp+0xB0], xmm12
00007c47757dcc5b  vmovaps [rsp+0xC0], xmm13
00007c47757dcc64  vmovaps [rsp+0xD0], xmm14
00007c47757dcc6d  vmovaps [rsp+0xE0], xmm15
00007c47757dcc76  sub rsp, 0x30
00007c47757dcc7a  movaps [rsp], xmm9
00007c47757dcc7f  movaps [rsp+0x10], xmm12
00007c47757dcc85  movaps [rsp+0x20], xmm10
00007c47757dcc8b  lea rdi, [rsp]
00007c47757dcc8f  mov esi, 0x00
00007c47757dcc94  mov rax, 0x62084E409530
00007c47757dcc9e  call rax
00007c47757dcca0  movaps xmm9, [rsp]
00007c47757dcca5  add rsp, 0x30
00007c47757dcca9  vmovaps xmm0, [rsp]
00007c47757dccae  vmovaps xmm1, [rsp+0x10]
00007c47757dccb4  vmovaps xmm2, [rsp+0x20]
00007c47757dccba  vmovaps xmm3, [rsp+0x30]
00007c47757dccc0  vmovaps xmm4, [rsp+0x40]
00007c47757dccc6  vmovaps xmm5, [rsp+0x50]
00007c47757dcccc  vmovaps xmm6, [rsp+0x60]
00007c47757dccd2  vmovaps xmm7, [rsp+0x70]
00007c47757dccd8  vmovaps xmm8, [rsp+0x80]
00007c47757dcce1  vmovaps xmm10, [rsp+0x90]
00007c47757dccea  vmovaps xmm11, [rsp+0xA0]
00007c47757dccf3  vmovaps xmm12, [rsp+0xB0]
00007c47757dccfc  vmovaps xmm13, [rsp+0xC0]
00007c47757dcd05  vmovaps xmm14, [rsp+0xD0]
00007c47757dcd0e  vmovaps xmm15, [rsp+0xE0]
00007c47757dcd17  add rsp, 0xF0
00007c47757dcd1e  pop r11
00007c47757dcd20  pop r10
00007c47757dcd22  pop r9
00007c47757dcd24  pop r8
00007c47757dcd26  pop rsi
00007c47757dcd27  pop rdi
00007c47757dcd28  pop rdx
00007c47757dcd29  pop rcx
00007c47757dcd2a  pop rax
00007c47757dcd2b  add rsp, 0x08
00007c47757dcd2f  jmp 0x00007C47757DBB99
00007c47757dcd34  sub rsp, 0x08
00007c47757dcd38  push rax
00007c47757dcd39  push rcx
00007c47757dcd3a  push rdx
00007c47757dcd3b  push rdi
00007c47757dcd3c  push rsi
00007c47757dcd3d  push r8
00007c47757dcd3f  push r9
00007c47757dcd41  push r10
00007c47757dcd43  push r11
00007c47757dcd45  sub rsp, 0xF0
00007c47757dcd4c  vmovaps [rsp], xmm0
00007c47757dcd51  vmovaps [rsp+0x10], xmm1
00007c47757dcd57  vmovaps [rsp+0x20], xmm2
00007c47757dcd5d  vmovaps [rsp+0x30], xmm3
00007c47757dcd63  vmovaps [rsp+0x40], xmm4
00007c47757dcd69  vmovaps [rsp+0x50], xmm5
00007c47757dcd6f  vmovaps [rsp+0x60], xmm6
00007c47757dcd75  vmovaps [rsp+0x70], xmm7
00007c47757dcd7b  vmovaps [rsp+0x80], xmm8
00007c47757dcd84  vmovaps [rsp+0x90], xmm9
00007c47757dcd8d  vmovaps [rsp+0xA0], xmm11
00007c47757dcd96  vmovaps [rsp+0xB0], xmm12
00007c47757dcd9f  vmovaps [rsp+0xC0], xmm13
00007c47757dcda8  vmovaps [rsp+0xD0], xmm14
00007c47757dcdb1  vmovaps [rsp+0xE0], xmm15
00007c47757dcdba  sub rsp, 0x30
00007c47757dcdbe  movaps [rsp], xmm10
00007c47757dcdc3  movaps [rsp+0x10], xmm12
00007c47757dcdc9  movaps [rsp+0x20], xmm11
00007c47757dcdcf  lea rdi, [rsp]
00007c47757dcdd3  mov esi, 0x00
00007c47757dcdd8  mov rax, 0x62084E409530
00007c47757dcde2  call rax
00007c47757dcde4  movaps xmm10, [rsp]
00007c47757dcde9  add rsp, 0x30
00007c47757dcded  vmovaps xmm0, [rsp]
00007c47757dcdf2  vmovaps xmm1, [rsp+0x10]
00007c47757dcdf8  vmovaps xmm2, [rsp+0x20]
00007c47757dcdfe  vmovaps xmm3, [rsp+0x30]
00007c47757dce04  vmovaps xmm4, [rsp+0x40]
00007c47757dce0a  vmovaps xmm5, [rsp+0x50]
00007c47757dce10  vmovaps xmm6, [rsp+0x60]
00007c47757dce16  vmovaps xmm7, [rsp+0x70]
00007c47757dce1c  vmovaps xmm8, [rsp+0x80]
00007c47757dce25  vmovaps xmm9, [rsp+0x90]
00007c47757dce2e  vmovaps xmm11, [rsp+0xA0]
00007c47757dce37  vmovaps xmm12, [rsp+0xB0]
00007c47757dce40  vmovaps xmm13, [rsp+0xC0]
00007c47757dce49  vmovaps xmm14, [rsp+0xD0]
00007c47757dce52  vmovaps xmm15, [rsp+0xE0]
00007c47757dce5b  add rsp, 0xF0
00007c47757dce62  pop r11
00007c47757dce64  pop r10
00007c47757dce66  pop r9
00007c47757dce68  pop r8
00007c47757dce6a  pop rsi
00007c47757dce6b  pop rdi
00007c47757dce6c  pop rdx
00007c47757dce6d  pop rcx
00007c47757dce6e  pop rax
00007c47757dce6f  add rsp, 0x08
00007c47757dce73  jmp 0x00007C47757DBBB3
00007c47757dce78  sub rsp, 0x08
00007c47757dce7c  push rax
00007c47757dce7d  push rcx
00007c47757dce7e  push rdx
00007c47757dce7f  push rdi
00007c47757dce80  push rsi
00007c47757dce81  push r8
00007c47757dce83  push r9
00007c47757dce85  push r10
00007c47757dce87  push r11
00007c47757dce89  sub rsp, 0xF0
00007c47757dce90  vmovaps [rsp], xmm0
00007c47757dce95  vmovaps [rsp+0x10], xmm1
00007c47757dce9b  vmovaps [rsp+0x20], xmm2
00007c47757dcea1  vmovaps [rsp+0x30], xmm3
00007c47757dcea7  vmovaps [rsp+0x40], xmm4
00007c47757dcead  vmovaps [rsp+0x50], xmm5
00007c47757dceb3  vmovaps [rsp+0x60], xmm7
00007c47757dceb9  vmovaps [rsp+0x70], xmm8
00007c47757dcebf  vmovaps [rsp+0x80], xmm9
00007c47757dcec8  vmovaps [rsp+0x90], xmm10
00007c47757dced1  vmovaps [rsp+0xA0], xmm11
00007c47757dceda  vmovaps [rsp+0xB0], xmm12
00007c47757dcee3  vmovaps [rsp+0xC0], xmm13
00007c47757dceec  vmovaps [rsp+0xD0], xmm14
00007c47757dcef5  vmovaps [rsp+0xE0], xmm15
00007c47757dcefe  sub rsp, 0x30
00007c47757dcf02  movaps [rsp], xmm6
00007c47757dcf06  movaps [rsp+0x10], xmm12
00007c47757dcf0c  movaps [rsp+0x20], xmm11
00007c47757dcf12  lea rdi, [rsp]
00007c47757dcf16  mov esi, 0x00
00007c47757dcf1b  mov rax, 0x62084E409530
00007c47757dcf25  call rax
00007c47757dcf27  movaps xmm6, [rsp]
00007c47757dcf2b  add rsp, 0x30
00007c47757dcf2f  vmovaps xmm0, [rsp]
00007c47757dcf34  vmovaps xmm1, [rsp+0x10]
00007c47757dcf3a  vmovaps xmm2, [rsp+0x20]
00007c47757dcf40  vmovaps xmm3, [rsp+0x30]
00007c47757dcf46  vmovaps xmm4, [rsp+0x40]
00007c47757dcf4c  vmovaps xmm5, [rsp+0x50]
00007c47757dcf52  vmovaps xmm7, [rsp+0x60]
00007c47757dcf58  vmovaps xmm8, [rsp+0x70]
00007c47757dcf5e  vmovaps xmm9, [rsp+0x80]
00007c47757dcf67  vmovaps xmm10, [rsp+0x90]
00007c47757dcf70  vmovaps xmm11, [rsp+0xA0]
00007c47757dcf79  vmovaps xmm12, [rsp+0xB0]
00007c47757dcf82  vmovaps xmm13, [rsp+0xC0]
00007c47757dcf8b  vmovaps xmm14, [rsp+0xD0]
00007c47757dcf94  vmovaps xmm15, [rsp+0xE0]
00007c47757dcf9d  add rsp, 0xF0
00007c47757dcfa4  pop r11
00007c47757dcfa6  pop r10
00007c47757dcfa8  pop r9
00007c47757dcfaa  pop r8
00007c47757dcfac  pop rsi
00007c47757dcfad  pop rdi
00007c47757dcfae  pop rdx
00007c47757dcfaf  pop rcx
00007c47757dcfb0  pop rax
00007c47757dcfb1  add rsp, 0x08
00007c47757dcfb5  jmp 0x00007C47757DBBD4
00007c47757dcfba  sub rsp, 0x08
00007c47757dcfbe  push rax
00007c47757dcfbf  push rcx
00007c47757dcfc0  push rdx
00007c47757dcfc1  push rdi
00007c47757dcfc2  push rsi
00007c47757dcfc3  push r8
00007c47757dcfc5  push r9
00007c47757dcfc7  push r10
00007c47757dcfc9  push r11
00007c47757dcfcb  sub rsp, 0xF0
00007c47757dcfd2  vmovaps [rsp], xmm0
00007c47757dcfd7  vmovaps [rsp+0x10], xmm1
00007c47757dcfdd  vmovaps [rsp+0x20], xmm2
00007c47757dcfe3  vmovaps [rsp+0x30], xmm4
00007c47757dcfe9  vmovaps [rsp+0x40], xmm5
00007c47757dcfef  vmovaps [rsp+0x50], xmm6
00007c47757dcff5  vmovaps [rsp+0x60], xmm7
00007c47757dcffb  vmovaps [rsp+0x70], xmm8
00007c47757dd001  vmovaps [rsp+0x80], xmm9
00007c47757dd00a  vmovaps [rsp+0x90], xmm10
00007c47757dd013  vmovaps [rsp+0xA0], xmm11
00007c47757dd01c  vmovaps [rsp+0xB0], xmm12
00007c47757dd025  vmovaps [rsp+0xC0], xmm13
00007c47757dd02e  vmovaps [rsp+0xD0], xmm14
00007c47757dd037  vmovaps [rsp+0xE0], xmm15
00007c47757dd040  sub rsp, 0x30
00007c47757dd044  movaps [rsp], xmm3
00007c47757dd048  movaps [rsp+0x10], xmm5
00007c47757dd04d  movaps [rsp+0x20], xmm4
00007c47757dd052  lea rdi, [rsp]
00007c47757dd056  mov esi, 0x00
00007c47757dd05b  mov rax, 0x62084E409530
00007c47757dd065  call rax
00007c47757dd067  movaps xmm3, [rsp]
00007c47757dd06b  add rsp, 0x30
00007c47757dd06f  vmovaps xmm0, [rsp]
00007c47757dd074  vmovaps xmm1, [rsp+0x10]
00007c47757dd07a  vmovaps xmm2, [rsp+0x20]
00007c47757dd080  vmovaps xmm4, [rsp+0x30]
00007c47757dd086  vmovaps xmm5, [rsp+0x40]
00007c47757dd08c  vmovaps xmm6, [rsp+0x50]
00007c47757dd092  vmovaps xmm7, [rsp+0x60]
00007c47757dd098  vmovaps xmm8, [rsp+0x70]
00007c47757dd09e  vmovaps xmm9, [rsp+0x80]
00007c47757dd0a7  vmovaps xmm10, [rsp+0x90]
00007c47757dd0b0  vmovaps xmm11, [rsp+0xA0]
00007c47757dd0b9  vmovaps xmm12, [rsp+0xB0]
00007c47757dd0c2  vmovaps xmm13, [rsp+0xC0]
00007c47757dd0cb  vmovaps xmm14, [rsp+0xD0]
00007c47757dd0d4  vmovaps xmm15, [rsp+0xE0]
00007c47757dd0dd  add rsp, 0xF0
00007c47757dd0e4  pop r11
00007c47757dd0e6  pop r10
00007c47757dd0e8  pop r9
00007c47757dd0ea  pop r8
00007c47757dd0ec  pop rsi
00007c47757dd0ed  pop rdi
00007c47757dd0ee  pop rdx
00007c47757dd0ef  pop rcx
00007c47757dd0f0  pop rax
00007c47757dd0f1  add rsp, 0x08
00007c47757dd0f5  jmp 0x00007C47757DBC35
00007c47757dd0fa  sub rsp, 0x08
00007c47757dd0fe  push rax
00007c47757dd0ff  push rcx
00007c47757dd100  push rdx
00007c47757dd101  push rdi
00007c47757dd102  push rsi
00007c47757dd103  push r8
00007c47757dd105  push r9
00007c47757dd107  push r10
00007c47757dd109  push r11
00007c47757dd10b  sub rsp, 0xF0
00007c47757dd112  vmovaps [rsp], xmm0
00007c47757dd117  vmovaps [rsp+0x10], xmm1
00007c47757dd11d  vmovaps [rsp+0x20], xmm2
00007c47757dd123  vmovaps [rsp+0x30], xmm3
00007c47757dd129  vmovaps [rsp+0x40], xmm4
00007c47757dd12f  vmovaps [rsp+0x50], xmm6
00007c47757dd135  vmovaps [rsp+0x60], xmm7
00007c47757dd13b  vmovaps [rsp+0x70], xmm8
00007c47757dd141  vmovaps [rsp+0x80], xmm9
00007c47757dd14a  vmovaps [rsp+0x90], xmm10
00007c47757dd153  vmovaps [rsp+0xA0], xmm11
00007c47757dd15c  vmovaps [rsp+0xB0], xmm12
00007c47757dd165  vmovaps [rsp+0xC0], xmm13
00007c47757dd16e  vmovaps [rsp+0xD0], xmm14
00007c47757dd177  vmovaps [rsp+0xE0], xmm15
00007c47757dd180  sub rsp, 0x30
00007c47757dd184  movaps [rsp], xmm5
00007c47757dd188  movaps [rsp+0x10], xmm8
00007c47757dd18e  movaps [rsp+0x20], xmm15
00007c47757dd194  lea rdi, [rsp]
00007c47757dd198  mov esi, 0x00
00007c47757dd19d  mov rax, 0x62084E409530
00007c47757dd1a7  call rax
00007c47757dd1a9  movaps xmm5, [rsp]
00007c47757dd1ad  add rsp, 0x30
00007c47757dd1b1  vmovaps xmm0, [rsp]
00007c47757dd1b6  vmovaps xmm1, [rsp+0x10]
00007c47757dd1bc  vmovaps xmm2, [rsp+0x20]
00007c47757dd1c2  vmovaps xmm3, [rsp+0x30]
00007c47757dd1c8  vmovaps xmm4, [rsp+0x40]
00007c47757dd1ce  vmovaps xmm6, [rsp+0x50]
00007c47757dd1d4  vmovaps xmm7, [rsp+0x60]
00007c47757dd1da  vmovaps xmm8, [rsp+0x70]
00007c47757dd1e0  vmovaps xmm9, [rsp+0x80]
00007c47757dd1e9  vmovaps xmm10, [rsp+0x90]
00007c47757dd1f2  vmovaps xmm11, [rsp+0xA0]
00007c47757dd1fb  vmovaps xmm12, [rsp+0xB0]
00007c47757dd204  vmovaps xmm13, [rsp+0xC0]
00007c47757dd20d  vmovaps xmm14, [rsp+0xD0]
00007c47757dd216  vmovaps xmm15, [rsp+0xE0]
00007c47757dd21f  add rsp, 0xF0
00007c47757dd226  pop r11
00007c47757dd228  pop r10
00007c47757dd22a  pop r9
00007c47757dd22c  pop r8
00007c47757dd22e  pop rsi
00007c47757dd22f  pop rdi
00007c47757dd230  pop rdx
00007c47757dd231  pop rcx
00007c47757dd232  pop rax
00007c47757dd233  add rsp, 0x08
00007c47757dd237  jmp 0x00007C47757DBC73
00007c47757dd23c  sub rsp, 0x08
00007c47757dd240  push rax
00007c47757dd241  push rcx
00007c47757dd242  push rdx
00007c47757dd243  push rdi
00007c47757dd244  push rsi
00007c47757dd245  push r8
00007c47757dd247  push r9
00007c47757dd249  push r10
00007c47757dd24b  push r11
00007c47757dd24d  sub rsp, 0xF0
00007c47757dd254  vmovaps [rsp], xmm0
00007c47757dd259  vmovaps [rsp+0x10], xmm1
00007c47757dd25f  vmovaps [rsp+0x20], xmm2
00007c47757dd265  vmovaps [rsp+0x30], xmm3
00007c47757dd26b  vmovaps [rsp+0x40], xmm5
00007c47757dd271  vmovaps [rsp+0x50], xmm6
00007c47757dd277  vmovaps [rsp+0x60], xmm7
00007c47757dd27d  vmovaps [rsp+0x70], xmm8
00007c47757dd283  vmovaps [rsp+0x80], xmm9
00007c47757dd28c  vmovaps [rsp+0x90], xmm10
00007c47757dd295  vmovaps [rsp+0xA0], xmm11
00007c47757dd29e  vmovaps [rsp+0xB0], xmm12
00007c47757dd2a7  vmovaps [rsp+0xC0], xmm13
00007c47757dd2b0  vmovaps [rsp+0xD0], xmm14
00007c47757dd2b9  vmovaps [rsp+0xE0], xmm15
00007c47757dd2c2  sub rsp, 0x30
00007c47757dd2c6  movaps [rsp], xmm4
00007c47757dd2ca  movaps [rsp+0x10], xmm9
00007c47757dd2d0  movaps [rsp+0x20], xmm8
00007c47757dd2d6  lea rdi, [rsp]
00007c47757dd2da  mov esi, 0x00
00007c47757dd2df  mov rax, 0x62084E409530
00007c47757dd2e9  call rax
00007c47757dd2eb  movaps xmm4, [rsp]
00007c47757dd2ef  add rsp, 0x30
00007c47757dd2f3  vmovaps xmm0, [rsp]
00007c47757dd2f8  vmovaps xmm1, [rsp+0x10]
00007c47757dd2fe  vmovaps xmm2, [rsp+0x20]
00007c47757dd304  vmovaps xmm3, [rsp+0x30]
00007c47757dd30a  vmovaps xmm5, [rsp+0x40]
00007c47757dd310  vmovaps xmm6, [rsp+0x50]
00007c47757dd316  vmovaps xmm7, [rsp+0x60]
00007c47757dd31c  vmovaps xmm8, [rsp+0x70]
00007c47757dd322  vmovaps xmm9, [rsp+0x80]
00007c47757dd32b  vmovaps xmm10, [rsp+0x90]
00007c47757dd334  vmovaps xmm11, [rsp+0xA0]
00007c47757dd33d  vmovaps xmm12, [rsp+0xB0]
00007c47757dd346  vmovaps xmm13, [rsp+0xC0]
00007c47757dd34f  vmovaps xmm14, [rsp+0xD0]
00007c47757dd358  vmovaps xmm15, [rsp+0xE0]
00007c47757dd361  add rsp, 0xF0
00007c47757dd368  pop r11
00007c47757dd36a  pop r10
00007c47757dd36c  pop r9
00007c47757dd36e  pop r8
00007c47757dd370  pop rsi
00007c47757dd371  pop rdi
00007c47757dd372  pop rdx
00007c47757dd373  pop rcx
00007c47757dd374  pop rax
00007c47757dd375  add rsp, 0x08
00007c47757dd379  jmp 0x00007C47757DBC94
00007c47757dd37e  sub rsp, 0x08
00007c47757dd382  push rax
00007c47757dd383  push rcx
00007c47757dd384  push rdx
00007c47757dd385  push rdi
00007c47757dd386  push rsi
00007c47757dd387  push r8
00007c47757dd389  push r9
00007c47757dd38b  push r10
00007c47757dd38d  push r11
00007c47757dd38f  sub rsp, 0xF0
00007c47757dd396  vmovaps [rsp], xmm0
00007c47757dd39b  vmovaps [rsp+0x10], xmm1
00007c47757dd3a1  vmovaps [rsp+0x20], xmm2
00007c47757dd3a7  vmovaps [rsp+0x30], xmm3
00007c47757dd3ad  vmovaps [rsp+0x40], xmm4
00007c47757dd3b3  vmovaps [rsp+0x50], xmm5
00007c47757dd3b9  vmovaps [rsp+0x60], xmm6
00007c47757dd3bf  vmovaps [rsp+0x70], xmm7
00007c47757dd3c5  vmovaps [rsp+0x80], xmm8
00007c47757dd3ce  vmovaps [rsp+0x90], xmm10
00007c47757dd3d7  vmovaps [rsp+0xA0], xmm11
00007c47757dd3e0  vmovaps [rsp+0xB0], xmm12
00007c47757dd3e9  vmovaps [rsp+0xC0], xmm13
00007c47757dd3f2  vmovaps [rsp+0xD0], xmm14
00007c47757dd3fb  vmovaps [rsp+0xE0], xmm15
00007c47757dd404  sub rsp, 0x30
00007c47757dd408  movaps [rsp], xmm9
00007c47757dd40d  movaps [rsp+0x10], xmm10
00007c47757dd413  movaps [rsp+0x20], xmm8
00007c47757dd419  lea rdi, [rsp]
00007c47757dd41d  mov esi, 0x00
00007c47757dd422  mov rax, 0x62084E409530
00007c47757dd42c  call rax
00007c47757dd42e  movaps xmm9, [rsp]
00007c47757dd433  add rsp, 0x30
00007c47757dd437  vmovaps xmm0, [rsp]
00007c47757dd43c  vmovaps xmm1, [rsp+0x10]
00007c47757dd442  vmovaps xmm2, [rsp+0x20]
00007c47757dd448  vmovaps xmm3, [rsp+0x30]
00007c47757dd44e  vmovaps xmm4, [rsp+0x40]
00007c47757dd454  vmovaps xmm5, [rsp+0x50]
00007c47757dd45a  vmovaps xmm6, [rsp+0x60]
00007c47757dd460  vmovaps xmm7, [rsp+0x70]
00007c47757dd466  vmovaps xmm8, [rsp+0x80]
00007c47757dd46f  vmovaps xmm10, [rsp+0x90]
00007c47757dd478  vmovaps xmm11, [rsp+0xA0]
00007c47757dd481  vmovaps xmm12, [rsp+0xB0]
00007c47757dd48a  vmovaps xmm13, [rsp+0xC0]
00007c47757dd493  vmovaps xmm14, [rsp+0xD0]
00007c47757dd49c  vmovaps xmm15, [rsp+0xE0]
00007c47757dd4a5  add rsp, 0xF0
00007c47757dd4ac  pop r11
00007c47757dd4ae  pop r10
00007c47757dd4b0  pop r9
00007c47757dd4b2  pop r8
00007c47757dd4b4  pop rsi
00007c47757dd4b5  pop rdi
00007c47757dd4b6  pop rdx
00007c47757dd4b7  pop rcx
00007c47757dd4b8  pop rax
00007c47757dd4b9  add rsp, 0x08
00007c47757dd4bd  jmp 0x00007C47757DBCAE
00007c47757dd4c2  call 0x00007C47756B52F0
00007c47757dd4c7  jmp 0x00007C47757DBDC8
00007c47757dd4cc  call 0x00007C47756B52F0
00007c47757dd4d1  jmp 0x00007C47757DBDDE
00007c47757dd4d6  sub rsp, 0x08
00007c47757dd4da  push rax
00007c47757dd4db  push rcx
00007c47757dd4dc  push rdx
00007c47757dd4dd  push rdi
00007c47757dd4de  push rsi
00007c47757dd4df  push r8
00007c47757dd4e1  push r9
00007c47757dd4e3  push r10
00007c47757dd4e5  push r11
00007c47757dd4e7  sub rsp, 0xF0
00007c47757dd4ee  vmovaps [rsp], xmm0
00007c47757dd4f3  vmovaps [rsp+0x10], xmm2
00007c47757dd4f9  vmovaps [rsp+0x20], xmm3
00007c47757dd4ff  vmovaps [rsp+0x30], xmm4
00007c47757dd505  vmovaps [rsp+0x40], xmm5
00007c47757dd50b  vmovaps [rsp+0x50], xmm6
00007c47757dd511  vmovaps [rsp+0x60], xmm7
00007c47757dd517  vmovaps [rsp+0x70], xmm8
00007c47757dd51d  vmovaps [rsp+0x80], xmm9
00007c47757dd526  vmovaps [rsp+0x90], xmm10
00007c47757dd52f  vmovaps [rsp+0xA0], xmm11
00007c47757dd538  vmovaps [rsp+0xB0], xmm12
00007c47757dd541  vmovaps [rsp+0xC0], xmm13
00007c47757dd54a  vmovaps [rsp+0xD0], xmm14
00007c47757dd553  vmovaps [rsp+0xE0], xmm15
00007c47757dd55c  sub rsp, 0x30
00007c47757dd560  movaps [rsp], xmm1
00007c47757dd564  movaps [rsp+0x10], xmm6
00007c47757dd569  movaps [rsp+0x20], xmm15
00007c47757dd56f  lea rdi, [rsp]
00007c47757dd573  mov esi, 0x00
00007c47757dd578  mov rax, 0x62084E409530
00007c47757dd582  call rax
00007c47757dd584  movaps xmm1, [rsp]
00007c47757dd588  add rsp, 0x30
00007c47757dd58c  vmovaps xmm0, [rsp]
00007c47757dd591  vmovaps xmm2, [rsp+0x10]
00007c47757dd597  vmovaps xmm3, [rsp+0x20]
00007c47757dd59d  vmovaps xmm4, [rsp+0x30]
00007c47757dd5a3  vmovaps xmm5, [rsp+0x40]
00007c47757dd5a9  vmovaps xmm6, [rsp+0x50]
00007c47757dd5af  vmovaps xmm7, [rsp+0x60]
00007c47757dd5b5  vmovaps xmm8, [rsp+0x70]
00007c47757dd5bb  vmovaps xmm9, [rsp+0x80]
00007c47757dd5c4  vmovaps xmm10, [rsp+0x90]
00007c47757dd5cd  vmovaps xmm11, [rsp+0xA0]
00007c47757dd5d6  vmovaps xmm12, [rsp+0xB0]
00007c47757dd5df  vmovaps xmm13, [rsp+0xC0]
00007c47757dd5e8  vmovaps xmm14, [rsp+0xD0]
00007c47757dd5f1  vmovaps xmm15, [rsp+0xE0]
00007c47757dd5fa  add rsp, 0xF0
00007c47757dd601  pop r11
00007c47757dd603  pop r10
00007c47757dd605  pop r9
00007c47757dd607  pop r8
00007c47757dd609  pop rsi
00007c47757dd60a  pop rdi
00007c47757dd60b  pop rdx
00007c47757dd60c  pop rcx
00007c47757dd60d  pop rax
00007c47757dd60e  add rsp, 0x08
00007c47757dd612  jmp 0x00007C47757DBE1B
00007c47757dd617  call 0x00007C47756C4620
00007c47757dd61c  jmp 0x00007C47757DBE28
00007c47757dd621  sub rsp, 0x08
00007c47757dd625  push rax
00007c47757dd626  push rcx
00007c47757dd627  push rdx
00007c47757dd628  push rdi
00007c47757dd629  push rsi
00007c47757dd62a  push r8
00007c47757dd62c  push r9
00007c47757dd62e  push r10
00007c47757dd630  push r11
00007c47757dd632  sub rsp, 0xF0
00007c47757dd639  vmovaps [rsp], xmm0
00007c47757dd63e  vmovaps [rsp+0x10], xmm1
00007c47757dd644  vmovaps [rsp+0x20], xmm2
00007c47757dd64a  vmovaps [rsp+0x30], xmm3
00007c47757dd650  vmovaps [rsp+0x40], xmm4
00007c47757dd656  vmovaps [rsp+0x50], xmm5
00007c47757dd65c  vmovaps [rsp+0x60], xmm6
00007c47757dd662  vmovaps [rsp+0x70], xmm7
00007c47757dd668  vmovaps [rsp+0x80], xmm8
00007c47757dd671  vmovaps [rsp+0x90], xmm9
00007c47757dd67a  vmovaps [rsp+0xA0], xmm10
00007c47757dd683  vmovaps [rsp+0xB0], xmm11
00007c47757dd68c  vmovaps [rsp+0xC0], xmm12
00007c47757dd695  vmovaps [rsp+0xD0], xmm13
00007c47757dd69e  vmovaps [rsp+0xE0], xmm15
00007c47757dd6a7  sub rsp, 0x30
00007c47757dd6ab  movaps [rsp], xmm14
00007c47757dd6b0  movaps [rsp+0x10], xmm4
00007c47757dd6b5  movaps [rsp+0x20], xmm3
00007c47757dd6ba  lea rdi, [rsp]
00007c47757dd6be  mov esi, 0x00
00007c47757dd6c3  mov rax, 0x62084E409530
00007c47757dd6cd  call rax
00007c47757dd6cf  movaps xmm14, [rsp]
00007c47757dd6d4  add rsp, 0x30
00007c47757dd6d8  vmovaps xmm0, [rsp]
00007c47757dd6dd  vmovaps xmm1, [rsp+0x10]
00007c47757dd6e3  vmovaps xmm2, [rsp+0x20]
00007c47757dd6e9  vmovaps xmm3, [rsp+0x30]
00007c47757dd6ef  vmovaps xmm4, [rsp+0x40]
00007c47757dd6f5  vmovaps xmm5, [rsp+0x50]
00007c47757dd6fb  vmovaps xmm6, [rsp+0x60]
00007c47757dd701  vmovaps xmm7, [rsp+0x70]
00007c47757dd707  vmovaps xmm8, [rsp+0x80]
00007c47757dd710  vmovaps xmm9, [rsp+0x90]
00007c47757dd719  vmovaps xmm10, [rsp+0xA0]
00007c47757dd722  vmovaps xmm11, [rsp+0xB0]
00007c47757dd72b  vmovaps xmm12, [rsp+0xC0]
00007c47757dd734  vmovaps xmm13, [rsp+0xD0]
00007c47757dd73d  vmovaps xmm15, [rsp+0xE0]
00007c47757dd746  add rsp, 0xF0
00007c47757dd74d  pop r11
00007c47757dd74f  pop r10
00007c47757dd751  pop r9
00007c47757dd753  pop r8
00007c47757dd755  pop rsi
00007c47757dd756  pop rdi
00007c47757dd757  pop rdx
00007c47757dd758  pop rcx
00007c47757dd759  pop rax
00007c47757dd75a  add rsp, 0x08
00007c47757dd75e  jmp 0x00007C47757DBE42
00007c47757dd763  sub rsp, 0x08
00007c47757dd767  push rax
00007c47757dd768  push rcx
00007c47757dd769  push rdx
00007c47757dd76a  push rdi
00007c47757dd76b  push rsi
00007c47757dd76c  push r8
00007c47757dd76e  push r9
00007c47757dd770  push r10
00007c47757dd772  push r11
00007c47757dd774  sub rsp, 0xF0
00007c47757dd77b  vmovaps [rsp], xmm0
00007c47757dd780  vmovaps [rsp+0x10], xmm1
00007c47757dd786  vmovaps [rsp+0x20], xmm2
00007c47757dd78c  vmovaps [rsp+0x30], xmm3
00007c47757dd792  vmovaps [rsp+0x40], xmm4
00007c47757dd798  vmovaps [rsp+0x50], xmm5
00007c47757dd79e  vmovaps [rsp+0x60], xmm7
00007c47757dd7a4  vmovaps [rsp+0x70], xmm8
00007c47757dd7aa  vmovaps [rsp+0x80], xmm9
00007c47757dd7b3  vmovaps [rsp+0x90], xmm10
00007c47757dd7bc  vmovaps [rsp+0xA0], xmm11
00007c47757dd7c5  vmovaps [rsp+0xB0], xmm12
00007c47757dd7ce  vmovaps [rsp+0xC0], xmm13
00007c47757dd7d7  vmovaps [rsp+0xD0], xmm14
00007c47757dd7e0  vmovaps [rsp+0xE0], xmm15
00007c47757dd7e9  sub rsp, 0x30
00007c47757dd7ed  movaps [rsp], xmm6
00007c47757dd7f1  movaps [rsp+0x10], xmm9
00007c47757dd7f7  movaps [rsp+0x20], xmm7
00007c47757dd7fc  lea rdi, [rsp]
00007c47757dd800  mov esi, 0x00
00007c47757dd805  mov rax, 0x62084E409530
00007c47757dd80f  call rax
00007c47757dd811  movaps xmm6, [rsp]
00007c47757dd815  add rsp, 0x30
00007c47757dd819  vmovaps xmm0, [rsp]
00007c47757dd81e  vmovaps xmm1, [rsp+0x10]
00007c47757dd824  vmovaps xmm2, [rsp+0x20]
00007c47757dd82a  vmovaps xmm3, [rsp+0x30]
00007c47757dd830  vmovaps xmm4, [rsp+0x40]
00007c47757dd836  vmovaps xmm5, [rsp+0x50]
00007c47757dd83c  vmovaps xmm7, [rsp+0x60]
00007c47757dd842  vmovaps xmm8, [rsp+0x70]
00007c47757dd848  vmovaps xmm9, [rsp+0x80]
00007c47757dd851  vmovaps xmm10, [rsp+0x90]
00007c47757dd85a  vmovaps xmm11, [rsp+0xA0]
00007c47757dd863  vmovaps xmm12, [rsp+0xB0]
00007c47757dd86c  vmovaps xmm13, [rsp+0xC0]
00007c47757dd875  vmovaps xmm14, [rsp+0xD0]
00007c47757dd87e  vmovaps xmm15, [rsp+0xE0]
00007c47757dd887  add rsp, 0xF0
00007c47757dd88e  pop r11
00007c47757dd890  pop r10
00007c47757dd892  pop r9
00007c47757dd894  pop r8
00007c47757dd896  pop rsi
00007c47757dd897  pop rdi
00007c47757dd898  pop rdx
00007c47757dd899  pop rcx
00007c47757dd89a  pop rax
00007c47757dd89b  add rsp, 0x08
00007c47757dd89f  jmp 0x00007C47757DBE5A
00007c47757dd8a4  sub rsp, 0x08
00007c47757dd8a8  push rax
00007c47757dd8a9  push rcx
00007c47757dd8aa  push rdx
00007c47757dd8ab  push rdi
00007c47757dd8ac  push rsi
00007c47757dd8ad  push r8
00007c47757dd8af  push r9
00007c47757dd8b1  push r10
00007c47757dd8b3  push r11
00007c47757dd8b5  sub rsp, 0xF0
00007c47757dd8bc  vmovaps [rsp], xmm0
00007c47757dd8c1  vmovaps [rsp+0x10], xmm1
00007c47757dd8c7  vmovaps [rsp+0x20], xmm2
00007c47757dd8cd  vmovaps [rsp+0x30], xmm3
00007c47757dd8d3  vmovaps [rsp+0x40], xmm4
00007c47757dd8d9  vmovaps [rsp+0x50], xmm5
00007c47757dd8df  vmovaps [rsp+0x60], xmm6
00007c47757dd8e5  vmovaps [rsp+0x70], xmm8
00007c47757dd8eb  vmovaps [rsp+0x80], xmm9
00007c47757dd8f4  vmovaps [rsp+0x90], xmm10
00007c47757dd8fd  vmovaps [rsp+0xA0], xmm11
00007c47757dd906  vmovaps [rsp+0xB0], xmm12
00007c47757dd90f  vmovaps [rsp+0xC0], xmm13
00007c47757dd918  vmovaps [rsp+0xD0], xmm14
00007c47757dd921  vmovaps [rsp+0xE0], xmm15
00007c47757dd92a  sub rsp, 0x30
00007c47757dd92e  movaps [rsp], xmm7
00007c47757dd932  movaps [rsp+0x10], xmm4
00007c47757dd937  movaps [rsp+0x20], xmm9
00007c47757dd93d  lea rdi, [rsp]
00007c47757dd941  mov esi, 0x00
00007c47757dd946  mov rax, 0x62084E409530
00007c47757dd950  call rax
00007c47757dd952  movaps xmm7, [rsp]
00007c47757dd956  add rsp, 0x30
00007c47757dd95a  vmovaps xmm0, [rsp]
00007c47757dd95f  vmovaps xmm1, [rsp+0x10]
00007c47757dd965  vmovaps xmm2, [rsp+0x20]
00007c47757dd96b  vmovaps xmm3, [rsp+0x30]
00007c47757dd971  vmovaps xmm4, [rsp+0x40]
00007c47757dd977  vmovaps xmm5, [rsp+0x50]
00007c47757dd97d  vmovaps xmm6, [rsp+0x60]
00007c47757dd983  vmovaps xmm8, [rsp+0x70]
00007c47757dd989  vmovaps xmm9, [rsp+0x80]
00007c47757dd992  vmovaps xmm10, [rsp+0x90]
00007c47757dd99b  vmovaps xmm11, [rsp+0xA0]
00007c47757dd9a4  vmovaps xmm12, [rsp+0xB0]
00007c47757dd9ad  vmovaps xmm13, [rsp+0xC0]
00007c47757dd9b6  vmovaps xmm14, [rsp+0xD0]
00007c47757dd9bf  vmovaps xmm15, [rsp+0xE0]
00007c47757dd9c8  add rsp, 0xF0
00007c47757dd9cf  pop r11
00007c47757dd9d1  pop r10
00007c47757dd9d3  pop r9
00007c47757dd9d5  pop r8
00007c47757dd9d7  pop rsi
00007c47757dd9d8  pop rdi
00007c47757dd9d9  pop rdx
00007c47757dd9da  pop rcx
00007c47757dd9db  pop rax
00007c47757dd9dc  add rsp, 0x08
00007c47757dd9e0  jmp 0x00007C47757DBE87
00007c47757dd9e5  sub rsp, 0x08
00007c47757dd9e9  push rax
00007c47757dd9ea  push rcx
00007c47757dd9eb  push rdx
00007c47757dd9ec  push rdi
00007c47757dd9ed  push rsi
00007c47757dd9ee  push r8
00007c47757dd9f0  push r9
00007c47757dd9f2  push r10
00007c47757dd9f4  push r11
00007c47757dd9f6  sub rsp, 0xF0
00007c47757dd9fd  vmovaps [rsp], xmm0
00007c47757dda02  vmovaps [rsp+0x10], xmm1
00007c47757dda08  vmovaps [rsp+0x20], xmm2
00007c47757dda0e  vmovaps [rsp+0x30], xmm3
00007c47757dda14  vmovaps [rsp+0x40], xmm5
00007c47757dda1a  vmovaps [rsp+0x50], xmm6
00007c47757dda20  vmovaps [rsp+0x60], xmm7
00007c47757dda26  vmovaps [rsp+0x70], xmm8
00007c47757dda2c  vmovaps [rsp+0x80], xmm9
00007c47757dda35  vmovaps [rsp+0x90], xmm10
00007c47757dda3e  vmovaps [rsp+0xA0], xmm11
00007c47757dda47  vmovaps [rsp+0xB0], xmm12
00007c47757dda50  vmovaps [rsp+0xC0], xmm13
00007c47757dda59  vmovaps [rsp+0xD0], xmm14
00007c47757dda62  vmovaps [rsp+0xE0], xmm15
00007c47757dda6b  sub rsp, 0x30
00007c47757dda6f  movaps [rsp], xmm4
00007c47757dda73  movaps [rsp+0x10], xmm15
00007c47757dda79  movaps [rsp+0x20], xmm9
00007c47757dda7f  lea rdi, [rsp]
00007c47757dda83  mov esi, 0x00
00007c47757dda88  mov rax, 0x62084E409530
00007c47757dda92  call rax
00007c47757dda94  movaps xmm4, [rsp]
00007c47757dda98  add rsp, 0x30
00007c47757dda9c  vmovaps xmm0, [rsp]
00007c47757ddaa1  vmovaps xmm1, [rsp+0x10]
00007c47757ddaa7  vmovaps xmm2, [rsp+0x20]
00007c47757ddaad  vmovaps xmm3, [rsp+0x30]
00007c47757ddab3  vmovaps xmm5, [rsp+0x40]
00007c47757ddab9  vmovaps xmm6, [rsp+0x50]
00007c47757ddabf  vmovaps xmm7, [rsp+0x60]
00007c47757ddac5  vmovaps xmm8, [rsp+0x70]
00007c47757ddacb  vmovaps xmm9, [rsp+0x80]
00007c47757ddad4  vmovaps xmm10, [rsp+0x90]
00007c47757ddadd  vmovaps xmm11, [rsp+0xA0]
00007c47757ddae6  vmovaps xmm12, [rsp+0xB0]
00007c47757ddaef  vmovaps xmm13, [rsp+0xC0]
00007c47757ddaf8  vmovaps xmm14, [rsp+0xD0]
00007c47757ddb01  vmovaps xmm15, [rsp+0xE0]
00007c47757ddb0a  add rsp, 0xF0
00007c47757ddb11  pop r11
00007c47757ddb13  pop r10
00007c47757ddb15  pop r9
00007c47757ddb17  pop r8
00007c47757ddb19  pop rsi
00007c47757ddb1a  pop rdi
00007c47757ddb1b  pop rdx
00007c47757ddb1c  pop rcx
00007c47757ddb1d  pop rax
00007c47757ddb1e  add rsp, 0x08
00007c47757ddb22  jmp 0x00007C47757DBEAC
00007c47757ddb27  call 0x00007C47756C4620
00007c47757ddb2c  jmp 0x00007C47757DBEB9
00007c47757ddb31  sub rsp, 0x08
00007c47757ddb35  push rax
00007c47757ddb36  push rcx
00007c47757ddb37  push rdx
00007c47757ddb38  push rdi
00007c47757ddb39  push rsi
00007c47757ddb3a  push r8
00007c47757ddb3c  push r9
00007c47757ddb3e  push r10
00007c47757ddb40  push r11
00007c47757ddb42  sub rsp, 0xF0
00007c47757ddb49  vmovaps [rsp], xmm0
00007c47757ddb4e  vmovaps [rsp+0x10], xmm1
00007c47757ddb54  vmovaps [rsp+0x20], xmm2
00007c47757ddb5a  vmovaps [rsp+0x30], xmm4
00007c47757ddb60  vmovaps [rsp+0x40], xmm5
00007c47757ddb66  vmovaps [rsp+0x50], xmm6
00007c47757ddb6c  vmovaps [rsp+0x60], xmm7
00007c47757ddb72  vmovaps [rsp+0x70], xmm8
00007c47757ddb78  vmovaps [rsp+0x80], xmm9
00007c47757ddb81  vmovaps [rsp+0x90], xmm10
00007c47757ddb8a  vmovaps [rsp+0xA0], xmm11
00007c47757ddb93  vmovaps [rsp+0xB0], xmm12
00007c47757ddb9c  vmovaps [rsp+0xC0], xmm13
00007c47757ddba5  vmovaps [rsp+0xD0], xmm14
00007c47757ddbae  vmovaps [rsp+0xE0], xmm15
00007c47757ddbb7  sub rsp, 0x30
00007c47757ddbbb  movaps [rsp], xmm3
00007c47757ddbbf  movaps [rsp+0x10], xmm1
00007c47757ddbc4  movaps [rsp+0x20], xmm9
00007c47757ddbca  lea rdi, [rsp]
00007c47757ddbce  mov esi, 0x00
00007c47757ddbd3  mov rax, 0x62084E409530
00007c47757ddbdd  call rax
00007c47757ddbdf  movaps xmm3, [rsp]
00007c47757ddbe3  add rsp, 0x30
00007c47757ddbe7  vmovaps xmm0, [rsp]
00007c47757ddbec  vmovaps xmm1, [rsp+0x10]
00007c47757ddbf2  vmovaps xmm2, [rsp+0x20]
00007c47757ddbf8  vmovaps xmm4, [rsp+0x30]
00007c47757ddbfe  vmovaps xmm5, [rsp+0x40]
00007c47757ddc04  vmovaps xmm6, [rsp+0x50]
00007c47757ddc0a  vmovaps xmm7, [rsp+0x60]
00007c47757ddc10  vmovaps xmm8, [rsp+0x70]
00007c47757ddc16  vmovaps xmm9, [rsp+0x80]
00007c47757ddc1f  vmovaps xmm10, [rsp+0x90]
00007c47757ddc28  vmovaps xmm11, [rsp+0xA0]
00007c47757ddc31  vmovaps xmm12, [rsp+0xB0]
00007c47757ddc3a  vmovaps xmm13, [rsp+0xC0]
00007c47757ddc43  vmovaps xmm14, [rsp+0xD0]
00007c47757ddc4c  vmovaps xmm15, [rsp+0xE0]
00007c47757ddc55  add rsp, 0xF0
00007c47757ddc5c  pop r11
00007c47757ddc5e  pop r10
00007c47757ddc60  pop r9
00007c47757ddc62  pop r8
00007c47757ddc64  pop rsi
00007c47757ddc65  pop rdi
00007c47757ddc66  pop rdx
00007c47757ddc67  pop rcx
00007c47757ddc68  pop rax
00007c47757ddc69  add rsp, 0x08
00007c47757ddc6d  jmp 0x00007C47757DBEF6
00007c47757ddc72  sub rsp, 0x08
00007c47757ddc76  push rax
00007c47757ddc77  push rcx
00007c47757ddc78  push rdx
00007c47757ddc79  push rdi
00007c47757ddc7a  push rsi
00007c47757ddc7b  push r8
00007c47757ddc7d  push r9
00007c47757ddc7f  push r10
00007c47757ddc81  push r11
00007c47757ddc83  sub rsp, 0xF0
00007c47757ddc8a  vmovaps [rsp], xmm0
00007c47757ddc8f  vmovaps [rsp+0x10], xmm2
00007c47757ddc95  vmovaps [rsp+0x20], xmm3
00007c47757ddc9b  vmovaps [rsp+0x30], xmm4
00007c47757ddca1  vmovaps [rsp+0x40], xmm5
00007c47757ddca7  vmovaps [rsp+0x50], xmm6
00007c47757ddcad  vmovaps [rsp+0x60], xmm7
00007c47757ddcb3  vmovaps [rsp+0x70], xmm8
00007c47757ddcb9  vmovaps [rsp+0x80], xmm9
00007c47757ddcc2  vmovaps [rsp+0x90], xmm10
00007c47757ddccb  vmovaps [rsp+0xA0], xmm11
00007c47757ddcd4  vmovaps [rsp+0xB0], xmm12
00007c47757ddcdd  vmovaps [rsp+0xC0], xmm13
00007c47757ddce6  vmovaps [rsp+0xD0], xmm14
00007c47757ddcef  vmovaps [rsp+0xE0], xmm15
00007c47757ddcf8  sub rsp, 0x30
00007c47757ddcfc  movaps [rsp], xmm1
00007c47757ddd00  movaps [rsp+0x10], xmm15
00007c47757ddd06  movaps [rsp+0x20], xmm9
00007c47757ddd0c  lea rdi, [rsp]
00007c47757ddd10  mov esi, 0x00
00007c47757ddd15  mov rax, 0x62084E409530
00007c47757ddd1f  call rax
00007c47757ddd21  movaps xmm1, [rsp]
00007c47757ddd25  add rsp, 0x30
00007c47757ddd29  vmovaps xmm0, [rsp]
00007c47757ddd2e  vmovaps xmm2, [rsp+0x10]
00007c47757ddd34  vmovaps xmm3, [rsp+0x20]
00007c47757ddd3a  vmovaps xmm4, [rsp+0x30]
00007c47757ddd40  vmovaps xmm5, [rsp+0x40]
00007c47757ddd46  vmovaps xmm6, [rsp+0x50]
00007c47757ddd4c  vmovaps xmm7, [rsp+0x60]
00007c47757ddd52  vmovaps xmm8, [rsp+0x70]
00007c47757ddd58  vmovaps xmm9, [rsp+0x80]
00007c47757ddd61  vmovaps xmm10, [rsp+0x90]
00007c47757ddd6a  vmovaps xmm11, [rsp+0xA0]
00007c47757ddd73  vmovaps xmm12, [rsp+0xB0]
00007c47757ddd7c  vmovaps xmm13, [rsp+0xC0]
00007c47757ddd85  vmovaps xmm14, [rsp+0xD0]
00007c47757ddd8e  vmovaps xmm15, [rsp+0xE0]
00007c47757ddd97  add rsp, 0xF0
00007c47757ddd9e  pop r11
00007c47757ddda0  pop r10
00007c47757ddda2  pop r9
00007c47757ddda4  pop r8
00007c47757ddda6  pop rsi
00007c47757ddda7  pop rdi
00007c47757ddda8  pop rdx
00007c47757ddda9  pop rcx
00007c47757dddaa  pop rax
00007c47757dddab  add rsp, 0x08
00007c47757dddaf  jmp 0x00007C47757DBF7E
00007c47757dddb4  call 0x00007C47756C4620
00007c47757dddb9  jmp 0x00007C47757DBF8B
00007c47757dddbe  sub rsp, 0x08
00007c47757dddc2  push rax
00007c47757dddc3  push rcx
00007c47757dddc4  push rdx
00007c47757dddc5  push rdi
00007c47757dddc6  push rsi
00007c47757dddc7  push r8
00007c47757dddc9  push r9
00007c47757dddcb  push r10
00007c47757dddcd  push r11
00007c47757dddcf  sub rsp, 0xF0
00007c47757dddd6  vmovaps [rsp], xmm0
00007c47757ddddb  vmovaps [rsp+0x10], xmm2
00007c47757ddde1  vmovaps [rsp+0x20], xmm3
00007c47757ddde7  vmovaps [rsp+0x30], xmm4
00007c47757ddded  vmovaps [rsp+0x40], xmm5
00007c47757dddf3  vmovaps [rsp+0x50], xmm6
00007c47757dddf9  vmovaps [rsp+0x60], xmm7
00007c47757dddff  vmovaps [rsp+0x70], xmm8
00007c47757dde05  vmovaps [rsp+0x80], xmm9
00007c47757dde0e  vmovaps [rsp+0x90], xmm10
00007c47757dde17  vmovaps [rsp+0xA0], xmm11
00007c47757dde20  vmovaps [rsp+0xB0], xmm12
00007c47757dde29  vmovaps [rsp+0xC0], xmm13
00007c47757dde32  vmovaps [rsp+0xD0], xmm14
00007c47757dde3b  vmovaps [rsp+0xE0], xmm15
00007c47757dde44  sub rsp, 0x30
00007c47757dde48  movaps [rsp], xmm1
00007c47757dde4c  movaps [rsp+0x10], xmm5
00007c47757dde51  movaps [rsp+0x20], xmm7
00007c47757dde56  lea rdi, [rsp]
00007c47757dde5a  mov esi, 0x00
00007c47757dde5f  mov rax, 0x62084E409530
00007c47757dde69  call rax
00007c47757dde6b  movaps xmm1, [rsp]
00007c47757dde6f  add rsp, 0x30
00007c47757dde73  vmovaps xmm0, [rsp]
00007c47757dde78  vmovaps xmm2, [rsp+0x10]
00007c47757dde7e  vmovaps xmm3, [rsp+0x20]
00007c47757dde84  vmovaps xmm4, [rsp+0x30]
00007c47757dde8a  vmovaps xmm5, [rsp+0x40]
00007c47757dde90  vmovaps xmm6, [rsp+0x50]
00007c47757dde96  vmovaps xmm7, [rsp+0x60]
00007c47757dde9c  vmovaps xmm8, [rsp+0x70]
00007c47757ddea2  vmovaps xmm9, [rsp+0x80]
00007c47757ddeab  vmovaps xmm10, [rsp+0x90]
00007c47757ddeb4  vmovaps xmm11, [rsp+0xA0]
00007c47757ddebd  vmovaps xmm12, [rsp+0xB0]
00007c47757ddec6  vmovaps xmm13, [rsp+0xC0]
00007c47757ddecf  vmovaps xmm14, [rsp+0xD0]
00007c47757dded8  vmovaps xmm15, [rsp+0xE0]
00007c47757ddee1  add rsp, 0xF0
00007c47757ddee8  pop r11
00007c47757ddeea  pop r10
00007c47757ddeec  pop r9
00007c47757ddeee  pop r8
00007c47757ddef0  pop rsi
00007c47757ddef1  pop rdi
00007c47757ddef2  pop rdx
00007c47757ddef3  pop rcx
00007c47757ddef4  pop rax
00007c47757ddef5  add rsp, 0x08
00007c47757ddef9  jmp 0x00007C47757DC030
00007c47757ddefe  sub rsp, 0x08
00007c47757ddf02  push rax
00007c47757ddf03  push rcx
00007c47757ddf04  push rdx
00007c47757ddf05  push rdi
00007c47757ddf06  push rsi
00007c47757ddf07  push r8
00007c47757ddf09  push r9
00007c47757ddf0b  push r10
00007c47757ddf0d  push r11
00007c47757ddf0f  sub rsp, 0xF0
00007c47757ddf16  vmovaps [rsp], xmm0
00007c47757ddf1b  vmovaps [rsp+0x10], xmm1
00007c47757ddf21  vmovaps [rsp+0x20], xmm2
00007c47757ddf27  vmovaps [rsp+0x30], xmm3
00007c47757ddf2d  vmovaps [rsp+0x40], xmm4
00007c47757ddf33  vmovaps [rsp+0x50], xmm5
00007c47757ddf39  vmovaps [rsp+0x60], xmm6
00007c47757ddf3f  vmovaps [rsp+0x70], xmm8
00007c47757ddf45  vmovaps [rsp+0x80], xmm9
00007c47757ddf4e  vmovaps [rsp+0x90], xmm10
00007c47757ddf57  vmovaps [rsp+0xA0], xmm11
00007c47757ddf60  vmovaps [rsp+0xB0], xmm12
00007c47757ddf69  vmovaps [rsp+0xC0], xmm13
00007c47757ddf72  vmovaps [rsp+0xD0], xmm14
00007c47757ddf7b  vmovaps [rsp+0xE0], xmm15
00007c47757ddf84  sub rsp, 0x30
00007c47757ddf88  movaps [rsp], xmm7
00007c47757ddf8c  movaps [rsp+0x10], xmm5
00007c47757ddf91  movaps [rsp+0x20], xmm15
00007c47757ddf97  lea rdi, [rsp]
00007c47757ddf9b  mov esi, 0x00
00007c47757ddfa0  mov rax, 0x62084E409530
00007c47757ddfaa  call rax
00007c47757ddfac  movaps xmm7, [rsp]
00007c47757ddfb0  add rsp, 0x30
00007c47757ddfb4  vmovaps xmm0, [rsp]
00007c47757ddfb9  vmovaps xmm1, [rsp+0x10]
00007c47757ddfbf  vmovaps xmm2, [rsp+0x20]
00007c47757ddfc5  vmovaps xmm3, [rsp+0x30]
00007c47757ddfcb  vmovaps xmm4, [rsp+0x40]
00007c47757ddfd1  vmovaps xmm5, [rsp+0x50]
00007c47757ddfd7  vmovaps xmm6, [rsp+0x60]
00007c47757ddfdd  vmovaps xmm8, [rsp+0x70]
00007c47757ddfe3  vmovaps xmm9, [rsp+0x80]
00007c47757ddfec  vmovaps xmm10, [rsp+0x90]
00007c47757ddff5  vmovaps xmm11, [rsp+0xA0]
00007c47757ddffe  vmovaps xmm12, [rsp+0xB0]
00007c47757de007  vmovaps xmm13, [rsp+0xC0]
00007c47757de010  vmovaps xmm14, [rsp+0xD0]
00007c47757de019  vmovaps xmm15, [rsp+0xE0]
00007c47757de022  add rsp, 0xF0
00007c47757de029  pop r11
00007c47757de02b  pop r10
00007c47757de02d  pop r9
00007c47757de02f  pop r8
00007c47757de031  pop rsi
00007c47757de032  pop rdi
00007c47757de033  pop rdx
00007c47757de034  pop rcx
00007c47757de035  pop rax
00007c47757de036  add rsp, 0x08
00007c47757de03a  jmp 0x00007C47757DC066
00007c47757de03f  call 0x00007C47756B52F0
00007c47757de044  jmp 0x00007C47757DC073
00007c47757de049  sub rsp, 0x08
00007c47757de04d  push rax
00007c47757de04e  push rcx
00007c47757de04f  push rdx
00007c47757de050  push rdi
00007c47757de051  push rsi
00007c47757de052  push r8
00007c47757de054  push r9
00007c47757de056  push r10
00007c47757de058  push r11
00007c47757de05a  sub rsp, 0xF0
00007c47757de061  vmovaps [rsp], xmm0
00007c47757de066  vmovaps [rsp+0x10], xmm1
00007c47757de06c  vmovaps [rsp+0x20], xmm2
00007c47757de072  vmovaps [rsp+0x30], xmm3
00007c47757de078  vmovaps [rsp+0x40], xmm4
00007c47757de07e  vmovaps [rsp+0x50], xmm5
00007c47757de084  vmovaps [rsp+0x60], xmm6
00007c47757de08a  vmovaps [rsp+0x70], xmm7
00007c47757de090  vmovaps [rsp+0x80], xmm8
00007c47757de099  vmovaps [rsp+0x90], xmm9
00007c47757de0a2  vmovaps [rsp+0xA0], xmm10
00007c47757de0ab  vmovaps [rsp+0xB0], xmm11
00007c47757de0b4  vmovaps [rsp+0xC0], xmm12
00007c47757de0bd  vmovaps [rsp+0xD0], xmm13
00007c47757de0c6  vmovaps [rsp+0xE0], xmm14
00007c47757de0cf  sub rsp, 0x30
00007c47757de0d3  movaps [rsp], xmm15
00007c47757de0d8  movaps [rsp+0x10], xmm5
00007c47757de0dd  movaps [rsp+0x20], xmm3
00007c47757de0e2  lea rdi, [rsp]
00007c47757de0e6  mov esi, 0x00
00007c47757de0eb  mov rax, 0x62084E409530
00007c47757de0f5  call rax
00007c47757de0f7  movaps xmm15, [rsp]
00007c47757de0fc  add rsp, 0x30
00007c47757de100  vmovaps xmm0, [rsp]
00007c47757de105  vmovaps xmm1, [rsp+0x10]
00007c47757de10b  vmovaps xmm2, [rsp+0x20]
00007c47757de111  vmovaps xmm3, [rsp+0x30]
00007c47757de117  vmovaps xmm4, [rsp+0x40]
00007c47757de11d  vmovaps xmm5, [rsp+0x50]
00007c47757de123  vmovaps xmm6, [rsp+0x60]
00007c47757de129  vmovaps xmm7, [rsp+0x70]
00007c47757de12f  vmovaps xmm8, [rsp+0x80]
00007c47757de138  vmovaps xmm9, [rsp+0x90]
00007c47757de141  vmovaps xmm10, [rsp+0xA0]
00007c47757de14a  vmovaps xmm11, [rsp+0xB0]
00007c47757de153  vmovaps xmm12, [rsp+0xC0]
00007c47757de15c  vmovaps xmm13, [rsp+0xD0]
00007c47757de165  vmovaps xmm14, [rsp+0xE0]
00007c47757de16e  add rsp, 0xF0
00007c47757de175  pop r11
00007c47757de177  pop r10
00007c47757de179  pop r9
00007c47757de17b  pop r8
00007c47757de17d  pop rsi
00007c47757de17e  pop rdi
00007c47757de17f  pop rdx
00007c47757de180  pop rcx
00007c47757de181  pop rax
00007c47757de182  add rsp, 0x08
00007c47757de186  jmp 0x00007C47757DC099
00007c47757de18b  sub rsp, 0x08
00007c47757de18f  push rax
00007c47757de190  push rcx
00007c47757de191  push rdx
00007c47757de192  push rdi
00007c47757de193  push rsi
00007c47757de194  push r8
00007c47757de196  push r9
00007c47757de198  push r10
00007c47757de19a  push r11
00007c47757de19c  sub rsp, 0xF0
00007c47757de1a3  vmovaps [rsp], xmm0
00007c47757de1a8  vmovaps [rsp+0x10], xmm2
00007c47757de1ae  vmovaps [rsp+0x20], xmm3
00007c47757de1b4  vmovaps [rsp+0x30], xmm4
00007c47757de1ba  vmovaps [rsp+0x40], xmm5
00007c47757de1c0  vmovaps [rsp+0x50], xmm6
00007c47757de1c6  vmovaps [rsp+0x60], xmm7
00007c47757de1cc  vmovaps [rsp+0x70], xmm8
00007c47757de1d2  vmovaps [rsp+0x80], xmm9
00007c47757de1db  vmovaps [rsp+0x90], xmm10
00007c47757de1e4  vmovaps [rsp+0xA0], xmm11
00007c47757de1ed  vmovaps [rsp+0xB0], xmm12
00007c47757de1f6  vmovaps [rsp+0xC0], xmm13
00007c47757de1ff  vmovaps [rsp+0xD0], xmm14
00007c47757de208  vmovaps [rsp+0xE0], xmm15
00007c47757de211  sub rsp, 0x30
00007c47757de215  movaps [rsp], xmm1
00007c47757de219  movaps [rsp+0x10], xmm5
00007c47757de21e  movaps [rsp+0x20], xmm4
00007c47757de223  lea rdi, [rsp]
00007c47757de227  mov esi, 0x00
00007c47757de22c  mov rax, 0x62084E409530
00007c47757de236  call rax
00007c47757de238  movaps xmm1, [rsp]
00007c47757de23c  add rsp, 0x30
00007c47757de240  vmovaps xmm0, [rsp]
00007c47757de245  vmovaps xmm2, [rsp+0x10]
00007c47757de24b  vmovaps xmm3, [rsp+0x20]
00007c47757de251  vmovaps xmm4, [rsp+0x30]
00007c47757de257  vmovaps xmm5, [rsp+0x40]
00007c47757de25d  vmovaps xmm6, [rsp+0x50]
00007c47757de263  vmovaps xmm7, [rsp+0x60]
00007c47757de269  vmovaps xmm8, [rsp+0x70]
00007c47757de26f  vmovaps xmm9, [rsp+0x80]
00007c47757de278  vmovaps xmm10, [rsp+0x90]
00007c47757de281  vmovaps xmm11, [rsp+0xA0]
00007c47757de28a  vmovaps xmm12, [rsp+0xB0]
00007c47757de293  vmovaps xmm13, [rsp+0xC0]
00007c47757de29c  vmovaps xmm14, [rsp+0xD0]
00007c47757de2a5  vmovaps xmm15, [rsp+0xE0]
00007c47757de2ae  add rsp, 0xF0
00007c47757de2b5  pop r11
00007c47757de2b7  pop r10
00007c47757de2b9  pop r9
00007c47757de2bb  pop r8
00007c47757de2bd  pop rsi
00007c47757de2be  pop rdi
00007c47757de2bf  pop rdx
00007c47757de2c0  pop rcx
00007c47757de2c1  pop rax
00007c47757de2c2  add rsp, 0x08
00007c47757de2c6  jmp 0x00007C47757DC0B9
00007c47757de2cb  sub rsp, 0x08
00007c47757de2cf  push rax
00007c47757de2d0  push rcx
00007c47757de2d1  push rdx
00007c47757de2d2  push rdi
00007c47757de2d3  push rsi
00007c47757de2d4  push r8
00007c47757de2d6  push r9
00007c47757de2d8  push r10
00007c47757de2da  push r11
00007c47757de2dc  sub rsp, 0xF0
00007c47757de2e3  vmovaps [rsp], xmm0
00007c47757de2e8  vmovaps [rsp+0x10], xmm1
00007c47757de2ee  vmovaps [rsp+0x20], xmm2
00007c47757de2f4  vmovaps [rsp+0x30], xmm3
00007c47757de2fa  vmovaps [rsp+0x40], xmm5
00007c47757de300  vmovaps [rsp+0x50], xmm6
00007c47757de306  vmovaps [rsp+0x60], xmm7
00007c47757de30c  vmovaps [rsp+0x70], xmm8
00007c47757de312  vmovaps [rsp+0x80], xmm9
00007c47757de31b  vmovaps [rsp+0x90], xmm10
00007c47757de324  vmovaps [rsp+0xA0], xmm11
00007c47757de32d  vmovaps [rsp+0xB0], xmm12
00007c47757de336  vmovaps [rsp+0xC0], xmm13
00007c47757de33f  vmovaps [rsp+0xD0], xmm14
00007c47757de348  vmovaps [rsp+0xE0], xmm15
00007c47757de351  sub rsp, 0x30
00007c47757de355  movaps [rsp], xmm4
00007c47757de359  movaps [rsp+0x10], xmm3
00007c47757de35e  movaps [rsp+0x20], xmm5
00007c47757de363  lea rdi, [rsp]
00007c47757de367  mov esi, 0x00
00007c47757de36c  mov rax, 0x62084E409530
00007c47757de376  call rax
00007c47757de378  movaps xmm4, [rsp]
00007c47757de37c  add rsp, 0x30
00007c47757de380  vmovaps xmm0, [rsp]
00007c47757de385  vmovaps xmm1, [rsp+0x10]
00007c47757de38b  vmovaps xmm2, [rsp+0x20]
00007c47757de391  vmovaps xmm3, [rsp+0x30]
00007c47757de397  vmovaps xmm5, [rsp+0x40]
00007c47757de39d  vmovaps xmm6, [rsp+0x50]
00007c47757de3a3  vmovaps xmm7, [rsp+0x60]
00007c47757de3a9  vmovaps xmm8, [rsp+0x70]
00007c47757de3af  vmovaps xmm9, [rsp+0x80]
00007c47757de3b8  vmovaps xmm10, [rsp+0x90]
00007c47757de3c1  vmovaps xmm11, [rsp+0xA0]
00007c47757de3ca  vmovaps xmm12, [rsp+0xB0]
00007c47757de3d3  vmovaps xmm13, [rsp+0xC0]
00007c47757de3dc  vmovaps xmm14, [rsp+0xD0]
00007c47757de3e5  vmovaps xmm15, [rsp+0xE0]
00007c47757de3ee  add rsp, 0xF0
00007c47757de3f5  pop r11
00007c47757de3f7  pop r10
00007c47757de3f9  pop r9
00007c47757de3fb  pop r8
00007c47757de3fd  pop rsi
00007c47757de3fe  pop rdi
00007c47757de3ff  pop rdx
00007c47757de400  pop rcx
00007c47757de401  pop rax
00007c47757de402  add rsp, 0x08
00007c47757de406  jmp 0x00007C47757DC107
00007c47757de40b  call 0x00007C47756B52F0
00007c47757de410  jmp 0x00007C47757DC114
00007c47757de415  sub rsp, 0x08
00007c47757de419  push rax
00007c47757de41a  push rcx
00007c47757de41b  push rdx
00007c47757de41c  push rdi
00007c47757de41d  push rsi
00007c47757de41e  push r8
00007c47757de420  push r9
00007c47757de422  push r10
00007c47757de424  push r11
00007c47757de426  sub rsp, 0xF0
00007c47757de42d  vmovaps [rsp], xmm0
00007c47757de432  vmovaps [rsp+0x10], xmm1
00007c47757de438  vmovaps [rsp+0x20], xmm2
00007c47757de43e  vmovaps [rsp+0x30], xmm3
00007c47757de444  vmovaps [rsp+0x40], xmm4
00007c47757de44a  vmovaps [rsp+0x50], xmm6
00007c47757de450  vmovaps [rsp+0x60], xmm7
00007c47757de456  vmovaps [rsp+0x70], xmm8
00007c47757de45c  vmovaps [rsp+0x80], xmm9
00007c47757de465  vmovaps [rsp+0x90], xmm10
00007c47757de46e  vmovaps [rsp+0xA0], xmm11
00007c47757de477  vmovaps [rsp+0xB0], xmm12
00007c47757de480  vmovaps [rsp+0xC0], xmm13
00007c47757de489  vmovaps [rsp+0xD0], xmm14
00007c47757de492  vmovaps [rsp+0xE0], xmm15
00007c47757de49b  sub rsp, 0x30
00007c47757de49f  movaps [rsp], xmm5
00007c47757de4a3  movaps [rsp+0x10], xmm6
00007c47757de4a8  movaps [rsp+0x20], xmm3
00007c47757de4ad  lea rdi, [rsp]
00007c47757de4b1  mov esi, 0x00
00007c47757de4b6  mov rax, 0x62084E409530
00007c47757de4c0  call rax
00007c47757de4c2  movaps xmm5, [rsp]
00007c47757de4c6  add rsp, 0x30
00007c47757de4ca  vmovaps xmm0, [rsp]
00007c47757de4cf  vmovaps xmm1, [rsp+0x10]
00007c47757de4d5  vmovaps xmm2, [rsp+0x20]
00007c47757de4db  vmovaps xmm3, [rsp+0x30]
00007c47757de4e1  vmovaps xmm4, [rsp+0x40]
00007c47757de4e7  vmovaps xmm6, [rsp+0x50]
00007c47757de4ed  vmovaps xmm7, [rsp+0x60]
00007c47757de4f3  vmovaps xmm8, [rsp+0x70]
00007c47757de4f9  vmovaps xmm9, [rsp+0x80]
00007c47757de502  vmovaps xmm10, [rsp+0x90]
00007c47757de50b  vmovaps xmm11, [rsp+0xA0]
00007c47757de514  vmovaps xmm12, [rsp+0xB0]
00007c47757de51d  vmovaps xmm13, [rsp+0xC0]
00007c47757de526  vmovaps xmm14, [rsp+0xD0]
00007c47757de52f  vmovaps xmm15, [rsp+0xE0]
00007c47757de538  add rsp, 0xF0
00007c47757de53f  pop r11
00007c47757de541  pop r10
00007c47757de543  pop r9
00007c47757de545  pop r8
00007c47757de547  pop rsi
00007c47757de548  pop rdi
00007c47757de549  pop rdx
00007c47757de54a  pop rcx
00007c47757de54b  pop rax
00007c47757de54c  add rsp, 0x08
00007c47757de550  jmp 0x00007C47757DC13A
00007c47757de555  sub rsp, 0x08
00007c47757de559  push rax
00007c47757de55a  push rcx
00007c47757de55b  push rdx
00007c47757de55c  push rdi
00007c47757de55d  push rsi
00007c47757de55e  push r8
00007c47757de560  push r9
00007c47757de562  push r10
00007c47757de564  push r11
00007c47757de566  sub rsp, 0xF0
00007c47757de56d  vmovaps [rsp], xmm0
00007c47757de572  vmovaps [rsp+0x10], xmm1
00007c47757de578  vmovaps [rsp+0x20], xmm2
00007c47757de57e  vmovaps [rsp+0x30], xmm3
00007c47757de584  vmovaps [rsp+0x40], xmm4
00007c47757de58a  vmovaps [rsp+0x50], xmm5
00007c47757de590  vmovaps [rsp+0x60], xmm7
00007c47757de596  vmovaps [rsp+0x70], xmm8
00007c47757de59c  vmovaps [rsp+0x80], xmm9
00007c47757de5a5  vmovaps [rsp+0x90], xmm10
00007c47757de5ae  vmovaps [rsp+0xA0], xmm11
00007c47757de5b7  vmovaps [rsp+0xB0], xmm12
00007c47757de5c0  vmovaps [rsp+0xC0], xmm13
00007c47757de5c9  vmovaps [rsp+0xD0], xmm14
00007c47757de5d2  vmovaps [rsp+0xE0], xmm15
00007c47757de5db  sub rsp, 0x30
00007c47757de5df  movaps [rsp], xmm6
00007c47757de5e3  movaps [rsp+0x10], xmm9
00007c47757de5e9  movaps [rsp+0x20], xmm1
00007c47757de5ee  lea rdi, [rsp]
00007c47757de5f2  mov esi, 0x00
00007c47757de5f7  mov rax, 0x62084E409530
00007c47757de601  call rax
00007c47757de603  movaps xmm6, [rsp]
00007c47757de607  add rsp, 0x30
00007c47757de60b  vmovaps xmm0, [rsp]
00007c47757de610  vmovaps xmm1, [rsp+0x10]
00007c47757de616  vmovaps xmm2, [rsp+0x20]
00007c47757de61c  vmovaps xmm3, [rsp+0x30]
00007c47757de622  vmovaps xmm4, [rsp+0x40]
00007c47757de628  vmovaps xmm5, [rsp+0x50]
00007c47757de62e  vmovaps xmm7, [rsp+0x60]
00007c47757de634  vmovaps xmm8, [rsp+0x70]
00007c47757de63a  vmovaps xmm9, [rsp+0x80]
00007c47757de643  vmovaps xmm10, [rsp+0x90]
00007c47757de64c  vmovaps xmm11, [rsp+0xA0]
00007c47757de655  vmovaps xmm12, [rsp+0xB0]
00007c47757de65e  vmovaps xmm13, [rsp+0xC0]
00007c47757de667  vmovaps xmm14, [rsp+0xD0]
00007c47757de670  vmovaps xmm15, [rsp+0xE0]
00007c47757de679  add rsp, 0xF0
00007c47757de680  pop r11
00007c47757de682  pop r10
00007c47757de684  pop r9
00007c47757de686  pop r8
00007c47757de688  pop rsi
00007c47757de689  pop rdi
00007c47757de68a  pop rdx
00007c47757de68b  pop rcx
00007c47757de68c  pop rax
00007c47757de68d  add rsp, 0x08
00007c47757de691  jmp 0x00007C47757DC15E
00007c47757de696  sub rsp, 0x08
00007c47757de69a  push rax
00007c47757de69b  push rcx
00007c47757de69c  push rdx
00007c47757de69d  push rdi
00007c47757de69e  push rsi
00007c47757de69f  push r8
00007c47757de6a1  push r9
00007c47757de6a3  push r10
00007c47757de6a5  push r11
00007c47757de6a7  sub rsp, 0xF0
00007c47757de6ae  vmovaps [rsp], xmm0
00007c47757de6b3  vmovaps [rsp+0x10], xmm1
00007c47757de6b9  vmovaps [rsp+0x20], xmm2
00007c47757de6bf  vmovaps [rsp+0x30], xmm3
00007c47757de6c5  vmovaps [rsp+0x40], xmm4
00007c47757de6cb  vmovaps [rsp+0x50], xmm5
00007c47757de6d1  vmovaps [rsp+0x60], xmm6
00007c47757de6d7  vmovaps [rsp+0x70], xmm7
00007c47757de6dd  vmovaps [rsp+0x80], xmm8
00007c47757de6e6  vmovaps [rsp+0x90], xmm10
00007c47757de6ef  vmovaps [rsp+0xA0], xmm11
00007c47757de6f8  vmovaps [rsp+0xB0], xmm12
00007c47757de701  vmovaps [rsp+0xC0], xmm13
00007c47757de70a  vmovaps [rsp+0xD0], xmm14
00007c47757de713  vmovaps [rsp+0xE0], xmm15
00007c47757de71c  sub rsp, 0x30
00007c47757de720  movaps [rsp], xmm9
00007c47757de725  movaps [rsp+0x10], xmm3
00007c47757de72a  movaps [rsp+0x20], xmm1
00007c47757de72f  lea rdi, [rsp]
00007c47757de733  mov esi, 0x00
00007c47757de738  mov rax, 0x62084E409530
00007c47757de742  call rax
00007c47757de744  movaps xmm9, [rsp]
00007c47757de749  add rsp, 0x30
00007c47757de74d  vmovaps xmm0, [rsp]
00007c47757de752  vmovaps xmm1, [rsp+0x10]
00007c47757de758  vmovaps xmm2, [rsp+0x20]
00007c47757de75e  vmovaps xmm3, [rsp+0x30]
00007c47757de764  vmovaps xmm4, [rsp+0x40]
00007c47757de76a  vmovaps xmm5, [rsp+0x50]
00007c47757de770  vmovaps xmm6, [rsp+0x60]
00007c47757de776  vmovaps xmm7, [rsp+0x70]
00007c47757de77c  vmovaps xmm8, [rsp+0x80]
00007c47757de785  vmovaps xmm10, [rsp+0x90]
00007c47757de78e  vmovaps xmm11, [rsp+0xA0]
00007c47757de797  vmovaps xmm12, [rsp+0xB0]
00007c47757de7a0  vmovaps xmm13, [rsp+0xC0]
00007c47757de7a9  vmovaps xmm14, [rsp+0xD0]
00007c47757de7b2  vmovaps xmm15, [rsp+0xE0]
00007c47757de7bb  add rsp, 0xF0
00007c47757de7c2  pop r11
00007c47757de7c4  pop r10
00007c47757de7c6  pop r9
00007c47757de7c8  pop r8
00007c47757de7ca  pop rsi
00007c47757de7cb  pop rdi
00007c47757de7cc  pop rdx
00007c47757de7cd  pop rcx
00007c47757de7ce  pop rax
00007c47757de7cf  add rsp, 0x08
00007c47757de7d3  jmp 0x00007C47757DC1AA
00007c47757de7d8  call 0x00007C47756B52F0
00007c47757de7dd  jmp 0x00007C47757DC1B7
00007c47757de7e2  sub rsp, 0x08
00007c47757de7e6  push rax
00007c47757de7e7  push rcx
00007c47757de7e8  push rdx
00007c47757de7e9  push rdi
00007c47757de7ea  push rsi
00007c47757de7eb  push r8
00007c47757de7ed  push r9
00007c47757de7ef  push r10
00007c47757de7f1  push r11
00007c47757de7f3  sub rsp, 0xF0
00007c47757de7fa  vmovaps [rsp], xmm0
00007c47757de7ff  vmovaps [rsp+0x10], xmm1
00007c47757de805  vmovaps [rsp+0x20], xmm2
00007c47757de80b  vmovaps [rsp+0x30], xmm3
00007c47757de811  vmovaps [rsp+0x40], xmm4
00007c47757de817  vmovaps [rsp+0x50], xmm5
00007c47757de81d  vmovaps [rsp+0x60], xmm6
00007c47757de823  vmovaps [rsp+0x70], xmm7
00007c47757de829  vmovaps [rsp+0x80], xmm8
00007c47757de832  vmovaps [rsp+0x90], xmm9
00007c47757de83b  vmovaps [rsp+0xA0], xmm10
00007c47757de844  vmovaps [rsp+0xB0], xmm11
00007c47757de84d  vmovaps [rsp+0xC0], xmm12
00007c47757de856  vmovaps [rsp+0xD0], xmm13
00007c47757de85f  vmovaps [rsp+0xE0], xmm14
00007c47757de868  sub rsp, 0x30
00007c47757de86c  movaps [rsp], xmm15
00007c47757de871  movaps [rsp+0x10], xmm3
00007c47757de876  movaps [rsp+0x20], xmm7
00007c47757de87b  lea rdi, [rsp]
00007c47757de87f  mov esi, 0x00
00007c47757de884  mov rax, 0x62084E409530
00007c47757de88e  call rax
00007c47757de890  movaps xmm15, [rsp]
00007c47757de895  add rsp, 0x30
00007c47757de899  vmovaps xmm0, [rsp]
00007c47757de89e  vmovaps xmm1, [rsp+0x10]
00007c47757de8a4  vmovaps xmm2, [rsp+0x20]
00007c47757de8aa  vmovaps xmm3, [rsp+0x30]
00007c47757de8b0  vmovaps xmm4, [rsp+0x40]
00007c47757de8b6  vmovaps xmm5, [rsp+0x50]
00007c47757de8bc  vmovaps xmm6, [rsp+0x60]
00007c47757de8c2  vmovaps xmm7, [rsp+0x70]
00007c47757de8c8  vmovaps xmm8, [rsp+0x80]
00007c47757de8d1  vmovaps xmm9, [rsp+0x90]
00007c47757de8da  vmovaps xmm10, [rsp+0xA0]
00007c47757de8e3  vmovaps xmm11, [rsp+0xB0]
00007c47757de8ec  vmovaps xmm12, [rsp+0xC0]
00007c47757de8f5  vmovaps xmm13, [rsp+0xD0]
00007c47757de8fe  vmovaps xmm14, [rsp+0xE0]
00007c47757de907  add rsp, 0xF0
00007c47757de90e  pop r11
00007c47757de910  pop r10
00007c47757de912  pop r9
00007c47757de914  pop r8
00007c47757de916  pop rsi
00007c47757de917  pop rdi
00007c47757de918  pop rdx
00007c47757de919  pop rcx
00007c47757de91a  pop rax
00007c47757de91b  add rsp, 0x08
00007c47757de91f  jmp 0x00007C47757DC1E3
00007c47757de924  sub rsp, 0x08
00007c47757de928  push rax
00007c47757de929  push rcx
00007c47757de92a  push rdx
00007c47757de92b  push rdi
00007c47757de92c  push rsi
00007c47757de92d  push r8
00007c47757de92f  push r9
00007c47757de931  push r10
00007c47757de933  push r11
00007c47757de935  sub rsp, 0xF0
00007c47757de93c  vmovaps [rsp], xmm0
00007c47757de941  vmovaps [rsp+0x10], xmm1
00007c47757de947  vmovaps [rsp+0x20], xmm2
00007c47757de94d  vmovaps [rsp+0x30], xmm4
00007c47757de953  vmovaps [rsp+0x40], xmm5
00007c47757de959  vmovaps [rsp+0x50], xmm6
00007c47757de95f  vmovaps [rsp+0x60], xmm7
00007c47757de965  vmovaps [rsp+0x70], xmm8
00007c47757de96b  vmovaps [rsp+0x80], xmm9
00007c47757de974  vmovaps [rsp+0x90], xmm10
00007c47757de97d  vmovaps [rsp+0xA0], xmm11
00007c47757de986  vmovaps [rsp+0xB0], xmm12
00007c47757de98f  vmovaps [rsp+0xC0], xmm13
00007c47757de998  vmovaps [rsp+0xD0], xmm14
00007c47757de9a1  vmovaps [rsp+0xE0], xmm15
00007c47757de9aa  sub rsp, 0x30
00007c47757de9ae  movaps [rsp], xmm3
00007c47757de9b2  movaps [rsp+0x10], xmm1
00007c47757de9b7  movaps [rsp+0x20], xmm15
00007c47757de9bd  lea rdi, [rsp]
00007c47757de9c1  mov esi, 0x00
00007c47757de9c6  mov rax, 0x62084E409530
00007c47757de9d0  call rax
00007c47757de9d2  movaps xmm3, [rsp]
00007c47757de9d6  add rsp, 0x30
00007c47757de9da  vmovaps xmm0, [rsp]
00007c47757de9df  vmovaps xmm1, [rsp+0x10]
00007c47757de9e5  vmovaps xmm2, [rsp+0x20]
00007c47757de9eb  vmovaps xmm4, [rsp+0x30]
00007c47757de9f1  vmovaps xmm5, [rsp+0x40]
00007c47757de9f7  vmovaps xmm6, [rsp+0x50]
00007c47757de9fd  vmovaps xmm7, [rsp+0x60]
00007c47757dea03  vmovaps xmm8, [rsp+0x70]
00007c47757dea09  vmovaps xmm9, [rsp+0x80]
00007c47757dea12  vmovaps xmm10, [rsp+0x90]
00007c47757dea1b  vmovaps xmm11, [rsp+0xA0]
00007c47757dea24  vmovaps xmm12, [rsp+0xB0]
00007c47757dea2d  vmovaps xmm13, [rsp+0xC0]
00007c47757dea36  vmovaps xmm14, [rsp+0xD0]
00007c47757dea3f  vmovaps xmm15, [rsp+0xE0]
00007c47757dea48  add rsp, 0xF0
00007c47757dea4f  pop r11
00007c47757dea51  pop r10
00007c47757dea53  pop r9
00007c47757dea55  pop r8
00007c47757dea57  pop rsi
00007c47757dea58  pop rdi
00007c47757dea59  pop rdx
00007c47757dea5a  pop rcx
00007c47757dea5b  pop rax
00007c47757dea5c  add rsp, 0x08
00007c47757dea60  jmp 0x00007C47757DC272
00007c47757dea65  call 0x00007C47756B52F0
00007c47757dea6a  jmp 0x00007C47757DC27C
00007c47757dea6f  sub rsp, 0x08
00007c47757dea73  push rax
00007c47757dea74  push rcx
00007c47757dea75  push rdx
00007c47757dea76  push rdi
00007c47757dea77  push rsi
00007c47757dea78  push r8
00007c47757dea7a  push r9
00007c47757dea7c  push r10
00007c47757dea7e  push r11
00007c47757dea80  sub rsp, 0xF0
00007c47757dea87  vmovaps [rsp], xmm0
00007c47757dea8c  vmovaps [rsp+0x10], xmm1
00007c47757dea92  vmovaps [rsp+0x20], xmm2
00007c47757dea98  vmovaps [rsp+0x30], xmm3
00007c47757dea9e  vmovaps [rsp+0x40], xmm4
00007c47757deaa4  vmovaps [rsp+0x50], xmm5
00007c47757deaaa  vmovaps [rsp+0x60], xmm6
00007c47757deab0  vmovaps [rsp+0x70], xmm7
00007c47757deab6  vmovaps [rsp+0x80], xmm8
00007c47757deabf  vmovaps [rsp+0x90], xmm9
00007c47757deac8  vmovaps [rsp+0xA0], xmm10
00007c47757dead1  vmovaps [rsp+0xB0], xmm11
00007c47757deada  vmovaps [rsp+0xC0], xmm12
00007c47757deae3  vmovaps [rsp+0xD0], xmm13
00007c47757deaec  vmovaps [rsp+0xE0], xmm14
00007c47757deaf5  sub rsp, 0x30
00007c47757deaf9  movaps [rsp], xmm15
00007c47757deafe  movaps [rsp+0x10], xmm14
00007c47757deb04  movaps [rsp+0x20], xmm4
00007c47757deb09  lea rdi, [rsp]
00007c47757deb0d  mov esi, 0x00
00007c47757deb12  mov rax, 0x62084E409530
00007c47757deb1c  call rax
00007c47757deb1e  movaps xmm15, [rsp]
00007c47757deb23  add rsp, 0x30
00007c47757deb27  vmovaps xmm0, [rsp]
00007c47757deb2c  vmovaps xmm1, [rsp+0x10]
00007c47757deb32  vmovaps xmm2, [rsp+0x20]
00007c47757deb38  vmovaps xmm3, [rsp+0x30]
00007c47757deb3e  vmovaps xmm4, [rsp+0x40]
00007c47757deb44  vmovaps xmm5, [rsp+0x50]
00007c47757deb4a  vmovaps xmm6, [rsp+0x60]
00007c47757deb50  vmovaps xmm7, [rsp+0x70]
00007c47757deb56  vmovaps xmm8, [rsp+0x80]
00007c47757deb5f  vmovaps xmm9, [rsp+0x90]
00007c47757deb68  vmovaps xmm10, [rsp+0xA0]
00007c47757deb71  vmovaps xmm11, [rsp+0xB0]
00007c47757deb7a  vmovaps xmm12, [rsp+0xC0]
00007c47757deb83  vmovaps xmm13, [rsp+0xD0]
00007c47757deb8c  vmovaps xmm14, [rsp+0xE0]
00007c47757deb95  add rsp, 0xF0
00007c47757deb9c  pop r11
00007c47757deb9e  pop r10
00007c47757deba0  pop r9
00007c47757deba2  pop r8
00007c47757deba4  pop rsi
00007c47757deba5  pop rdi
00007c47757deba6  pop rdx
00007c47757deba7  pop rcx
00007c47757deba8  pop rax
00007c47757deba9  add rsp, 0x08
00007c47757debad  jmp 0x00007C47757DC2AA
00007c47757debb2  sub rsp, 0x08
00007c47757debb6  push rax
00007c47757debb7  push rcx
00007c47757debb8  push rdx
00007c47757debb9  push rdi
00007c47757debba  push rsi
00007c47757debbb  push r8
00007c47757debbd  push r9
00007c47757debbf  push r10
00007c47757debc1  push r11
00007c47757debc3  sub rsp, 0xF0
00007c47757debca  vmovaps [rsp], xmm0
00007c47757debcf  vmovaps [rsp+0x10], xmm1
00007c47757debd5  vmovaps [rsp+0x20], xmm2
00007c47757debdb  vmovaps [rsp+0x30], xmm3
00007c47757debe1  vmovaps [rsp+0x40], xmm4
00007c47757debe7  vmovaps [rsp+0x50], xmm5
00007c47757debed  vmovaps [rsp+0x60], xmm6
00007c47757debf3  vmovaps [rsp+0x70], xmm7
00007c47757debf9  vmovaps [rsp+0x80], xmm8
00007c47757dec02  vmovaps [rsp+0x90], xmm9
00007c47757dec0b  vmovaps [rsp+0xA0], xmm10
00007c47757dec14  vmovaps [rsp+0xB0], xmm11
00007c47757dec1d  vmovaps [rsp+0xC0], xmm12
00007c47757dec26  vmovaps [rsp+0xD0], xmm13
00007c47757dec2f  vmovaps [rsp+0xE0], xmm15
00007c47757dec38  sub rsp, 0x30
00007c47757dec3c  movaps [rsp], xmm14
00007c47757dec41  movaps [rsp+0x10], xmm2
00007c47757dec46  movaps [rsp+0x20], xmm1
00007c47757dec4b  lea rdi, [rsp]
00007c47757dec4f  mov esi, 0x00
00007c47757dec54  mov rax, 0x62084E409530
00007c47757dec5e  call rax
00007c47757dec60  movaps xmm14, [rsp]
00007c47757dec65  add rsp, 0x30
00007c47757dec69  vmovaps xmm0, [rsp]
00007c47757dec6e  vmovaps xmm1, [rsp+0x10]
00007c47757dec74  vmovaps xmm2, [rsp+0x20]
00007c47757dec7a  vmovaps xmm3, [rsp+0x30]
00007c47757dec80  vmovaps xmm4, [rsp+0x40]
00007c47757dec86  vmovaps xmm5, [rsp+0x50]
00007c47757dec8c  vmovaps xmm6, [rsp+0x60]
00007c47757dec92  vmovaps xmm7, [rsp+0x70]
00007c47757dec98  vmovaps xmm8, [rsp+0x80]
00007c47757deca1  vmovaps xmm9, [rsp+0x90]
00007c47757decaa  vmovaps xmm10, [rsp+0xA0]
00007c47757decb3  vmovaps xmm11, [rsp+0xB0]
00007c47757decbc  vmovaps xmm12, [rsp+0xC0]
00007c47757decc5  vmovaps xmm13, [rsp+0xD0]
00007c47757decce  vmovaps xmm15, [rsp+0xE0]
00007c47757decd7  add rsp, 0xF0
00007c47757decde  pop r11
00007c47757dece0  pop r10
00007c47757dece2  pop r9
00007c47757dece4  pop r8
00007c47757dece6  pop rsi
00007c47757dece7  pop rdi
00007c47757dece8  pop rdx
00007c47757dece9  pop rcx
00007c47757decea  pop rax
00007c47757deceb  add rsp, 0x08
00007c47757decef  jmp 0x00007C47757DC2D0
00007c47757decf4  sub rsp, 0x08
00007c47757decf8  push rax
00007c47757decf9  push rcx
00007c47757decfa  push rdx
00007c47757decfb  push rdi
00007c47757decfc  push rsi
00007c47757decfd  push r8
00007c47757decff  push r9
00007c47757ded01  push r10
00007c47757ded03  push r11
00007c47757ded05  sub rsp, 0xF0
00007c47757ded0c  vmovaps [rsp], xmm0
00007c47757ded11  vmovaps [rsp+0x10], xmm2
00007c47757ded17  vmovaps [rsp+0x20], xmm3
00007c47757ded1d  vmovaps [rsp+0x30], xmm4
00007c47757ded23  vmovaps [rsp+0x40], xmm5
00007c47757ded29  vmovaps [rsp+0x50], xmm6
00007c47757ded2f  vmovaps [rsp+0x60], xmm7
00007c47757ded35  vmovaps [rsp+0x70], xmm8
00007c47757ded3b  vmovaps [rsp+0x80], xmm9
00007c47757ded44  vmovaps [rsp+0x90], xmm10
00007c47757ded4d  vmovaps [rsp+0xA0], xmm11
00007c47757ded56  vmovaps [rsp+0xB0], xmm12
00007c47757ded5f  vmovaps [rsp+0xC0], xmm13
00007c47757ded68  vmovaps [rsp+0xD0], xmm14
00007c47757ded71  vmovaps [rsp+0xE0], xmm15
00007c47757ded7a  sub rsp, 0x30
00007c47757ded7e  movaps [rsp], xmm1
00007c47757ded82  movaps [rsp+0x10], xmm4
00007c47757ded87  movaps [rsp+0x20], xmm9
00007c47757ded8d  lea rdi, [rsp]
00007c47757ded91  mov esi, 0x00
00007c47757ded96  mov rax, 0x62084E409530
00007c47757deda0  call rax
00007c47757deda2  movaps xmm1, [rsp]
00007c47757deda6  add rsp, 0x30
00007c47757dedaa  vmovaps xmm0, [rsp]
00007c47757dedaf  vmovaps xmm2, [rsp+0x10]
00007c47757dedb5  vmovaps xmm3, [rsp+0x20]
00007c47757dedbb  vmovaps xmm4, [rsp+0x30]
00007c47757dedc1  vmovaps xmm5, [rsp+0x40]
00007c47757dedc7  vmovaps xmm6, [rsp+0x50]
00007c47757dedcd  vmovaps xmm7, [rsp+0x60]
00007c47757dedd3  vmovaps xmm8, [rsp+0x70]
00007c47757dedd9  vmovaps xmm9, [rsp+0x80]
00007c47757dede2  vmovaps xmm10, [rsp+0x90]
00007c47757dedeb  vmovaps xmm11, [rsp+0xA0]
00007c47757dedf4  vmovaps xmm12, [rsp+0xB0]
00007c47757dedfd  vmovaps xmm13, [rsp+0xC0]
00007c47757dee06  vmovaps xmm14, [rsp+0xD0]
00007c47757dee0f  vmovaps xmm15, [rsp+0xE0]
00007c47757dee18  add rsp, 0xF0
00007c47757dee1f  pop r11
00007c47757dee21  pop r10
00007c47757dee23  pop r9
00007c47757dee25  pop r8
00007c47757dee27  pop rsi
00007c47757dee28  pop rdi
00007c47757dee29  pop rdx
00007c47757dee2a  pop rcx
00007c47757dee2b  pop rax
00007c47757dee2c  add rsp, 0x08
00007c47757dee30  jmp 0x00007C47757DC2EE
00007c47757dee35  sub rsp, 0x08
00007c47757dee39  push rax
00007c47757dee3a  push rcx
00007c47757dee3b  push rdx
00007c47757dee3c  push rdi
00007c47757dee3d  push rsi
00007c47757dee3e  push r8
00007c47757dee40  push r9
00007c47757dee42  push r10
00007c47757dee44  push r11
00007c47757dee46  sub rsp, 0xF0
00007c47757dee4d  vmovaps [rsp], xmm0
00007c47757dee52  vmovaps [rsp+0x10], xmm1
00007c47757dee58  vmovaps [rsp+0x20], xmm2
00007c47757dee5e  vmovaps [rsp+0x30], xmm3
00007c47757dee64  vmovaps [rsp+0x40], xmm5
00007c47757dee6a  vmovaps [rsp+0x50], xmm6
00007c47757dee70  vmovaps [rsp+0x60], xmm7
00007c47757dee76  vmovaps [rsp+0x70], xmm8
00007c47757dee7c  vmovaps [rsp+0x80], xmm9
00007c47757dee85  vmovaps [rsp+0x90], xmm10
00007c47757dee8e  vmovaps [rsp+0xA0], xmm11
00007c47757dee97  vmovaps [rsp+0xB0], xmm12
00007c47757deea0  vmovaps [rsp+0xC0], xmm13
00007c47757deea9  vmovaps [rsp+0xD0], xmm14
00007c47757deeb2  vmovaps [rsp+0xE0], xmm15
00007c47757deebb  sub rsp, 0x30
00007c47757deebf  movaps [rsp], xmm4
00007c47757deec3  movaps [rsp+0x10], xmm2
00007c47757deec8  movaps [rsp+0x20], xmm9
00007c47757deece  lea rdi, [rsp]
00007c47757deed2  mov esi, 0x00
00007c47757deed7  mov rax, 0x62084E409530
00007c47757deee1  call rax
00007c47757deee3  movaps xmm4, [rsp]
00007c47757deee7  add rsp, 0x30
00007c47757deeeb  vmovaps xmm0, [rsp]
00007c47757deef0  vmovaps xmm1, [rsp+0x10]
00007c47757deef6  vmovaps xmm2, [rsp+0x20]
00007c47757deefc  vmovaps xmm3, [rsp+0x30]
00007c47757def02  vmovaps xmm5, [rsp+0x40]
00007c47757def08  vmovaps xmm6, [rsp+0x50]
00007c47757def0e  vmovaps xmm7, [rsp+0x60]
00007c47757def14  vmovaps xmm8, [rsp+0x70]
00007c47757def1a  vmovaps xmm9, [rsp+0x80]
00007c47757def23  vmovaps xmm10, [rsp+0x90]
00007c47757def2c  vmovaps xmm11, [rsp+0xA0]
00007c47757def35  vmovaps xmm12, [rsp+0xB0]
00007c47757def3e  vmovaps xmm13, [rsp+0xC0]
00007c47757def47  vmovaps xmm14, [rsp+0xD0]
00007c47757def50  vmovaps xmm15, [rsp+0xE0]
00007c47757def59  add rsp, 0xF0
00007c47757def60  pop r11
00007c47757def62  pop r10
00007c47757def64  pop r9
00007c47757def66  pop r8
00007c47757def68  pop rsi
00007c47757def69  pop rdi
00007c47757def6a  pop rdx
00007c47757def6b  pop rcx
00007c47757def6c  pop rax
00007c47757def6d  add rsp, 0x08
00007c47757def71  jmp 0x00007C47757DC31E
00007c47757def76  sub rsp, 0x08
00007c47757def7a  push rax
00007c47757def7b  push rcx
00007c47757def7c  push rdx
00007c47757def7d  push rdi
00007c47757def7e  push rsi
00007c47757def7f  push r8
00007c47757def81  push r9
00007c47757def83  push r10
00007c47757def85  push r11
00007c47757def87  sub rsp, 0xF0
00007c47757def8e  vmovaps [rsp], xmm0
00007c47757def93  vmovaps [rsp+0x10], xmm1
00007c47757def99  vmovaps [rsp+0x20], xmm2
00007c47757def9f  vmovaps [rsp+0x30], xmm3
00007c47757defa5  vmovaps [rsp+0x40], xmm4
00007c47757defab  vmovaps [rsp+0x50], xmm5
00007c47757defb1  vmovaps [rsp+0x60], xmm6
00007c47757defb7  vmovaps [rsp+0x70], xmm7
00007c47757defbd  vmovaps [rsp+0x80], xmm8
00007c47757defc6  vmovaps [rsp+0x90], xmm10
00007c47757defcf  vmovaps [rsp+0xA0], xmm11
00007c47757defd8  vmovaps [rsp+0xB0], xmm12
00007c47757defe1  vmovaps [rsp+0xC0], xmm13
00007c47757defea  vmovaps [rsp+0xD0], xmm14
00007c47757deff3  vmovaps [rsp+0xE0], xmm15
00007c47757deffc  sub rsp, 0x30
00007c47757df000  movaps [rsp], xmm9
00007c47757df005  movaps [rsp+0x10], xmm2
00007c47757df00a  movaps [rsp+0x20], xmm1
00007c47757df00f  lea rdi, [rsp]
00007c47757df013  mov esi, 0x00
00007c47757df018  mov rax, 0x62084E409530
00007c47757df022  call rax
00007c47757df024  movaps xmm9, [rsp]
00007c47757df029  add rsp, 0x30
00007c47757df02d  vmovaps xmm0, [rsp]
00007c47757df032  vmovaps xmm1, [rsp+0x10]
00007c47757df038  vmovaps xmm2, [rsp+0x20]
00007c47757df03e  vmovaps xmm3, [rsp+0x30]
00007c47757df044  vmovaps xmm4, [rsp+0x40]
00007c47757df04a  vmovaps xmm5, [rsp+0x50]
00007c47757df050  vmovaps xmm6, [rsp+0x60]
00007c47757df056  vmovaps xmm7, [rsp+0x70]
00007c47757df05c  vmovaps xmm8, [rsp+0x80]
00007c47757df065  vmovaps xmm10, [rsp+0x90]
00007c47757df06e  vmovaps xmm11, [rsp+0xA0]
00007c47757df077  vmovaps xmm12, [rsp+0xB0]
00007c47757df080  vmovaps xmm13, [rsp+0xC0]
00007c47757df089  vmovaps xmm14, [rsp+0xD0]
00007c47757df092  vmovaps xmm15, [rsp+0xE0]
00007c47757df09b  add rsp, 0xF0
00007c47757df0a2  pop r11
00007c47757df0a4  pop r10
00007c47757df0a6  pop r9
00007c47757df0a8  pop r8
00007c47757df0aa  pop rsi
00007c47757df0ab  pop rdi
00007c47757df0ac  pop rdx
00007c47757df0ad  pop rcx
00007c47757df0ae  pop rax
00007c47757df0af  add rsp, 0x08
00007c47757df0b3  jmp 0x00007C47757DC354
00007c47757df0b8  sub rsp, 0x08
00007c47757df0bc  push rax
00007c47757df0bd  push rcx
00007c47757df0be  push rdx
00007c47757df0bf  push rdi
00007c47757df0c0  push rsi
00007c47757df0c1  push r8
00007c47757df0c3  push r9
00007c47757df0c5  push r10
00007c47757df0c7  push r11
00007c47757df0c9  sub rsp, 0xF0
00007c47757df0d0  vmovaps [rsp], xmm0
00007c47757df0d5  vmovaps [rsp+0x10], xmm2
00007c47757df0db  vmovaps [rsp+0x20], xmm3
00007c47757df0e1  vmovaps [rsp+0x30], xmm4
00007c47757df0e7  vmovaps [rsp+0x40], xmm5
00007c47757df0ed  vmovaps [rsp+0x50], xmm6
00007c47757df0f3  vmovaps [rsp+0x60], xmm7
00007c47757df0f9  vmovaps [rsp+0x70], xmm8
00007c47757df0ff  vmovaps [rsp+0x80], xmm9
00007c47757df108  vmovaps [rsp+0x90], xmm10
00007c47757df111  vmovaps [rsp+0xA0], xmm11
00007c47757df11a  vmovaps [rsp+0xB0], xmm12
00007c47757df123  vmovaps [rsp+0xC0], xmm13
00007c47757df12c  vmovaps [rsp+0xD0], xmm14
00007c47757df135  vmovaps [rsp+0xE0], xmm15
00007c47757df13e  sub rsp, 0x30
00007c47757df142  movaps [rsp], xmm1
00007c47757df146  movaps [rsp+0x10], xmm15
00007c47757df14c  movaps [rsp+0x20], xmm6
00007c47757df151  lea rdi, [rsp]
00007c47757df155  mov esi, 0x00
00007c47757df15a  mov rax, 0x62084E409530
00007c47757df164  call rax
00007c47757df166  movaps xmm1, [rsp]
00007c47757df16a  add rsp, 0x30
00007c47757df16e  vmovaps xmm0, [rsp]
00007c47757df173  vmovaps xmm2, [rsp+0x10]
00007c47757df179  vmovaps xmm3, [rsp+0x20]
00007c47757df17f  vmovaps xmm4, [rsp+0x30]
00007c47757df185  vmovaps xmm5, [rsp+0x40]
00007c47757df18b  vmovaps xmm6, [rsp+0x50]
00007c47757df191  vmovaps xmm7, [rsp+0x60]
00007c47757df197  vmovaps xmm8, [rsp+0x70]
00007c47757df19d  vmovaps xmm9, [rsp+0x80]
00007c47757df1a6  vmovaps xmm10, [rsp+0x90]
00007c47757df1af  vmovaps xmm11, [rsp+0xA0]
00007c47757df1b8  vmovaps xmm12, [rsp+0xB0]
00007c47757df1c1  vmovaps xmm13, [rsp+0xC0]
00007c47757df1ca  vmovaps xmm14, [rsp+0xD0]
00007c47757df1d3  vmovaps xmm15, [rsp+0xE0]
00007c47757df1dc  add rsp, 0xF0
00007c47757df1e3  pop r11
00007c47757df1e5  pop r10
00007c47757df1e7  pop r9
00007c47757df1e9  pop r8
00007c47757df1eb  pop rsi
00007c47757df1ec  pop rdi
00007c47757df1ed  pop rdx
00007c47757df1ee  pop rcx
00007c47757df1ef  pop rax
00007c47757df1f0  add rsp, 0x08
00007c47757df1f4  jmp 0x00007C47757DC375
00007c47757df1f9  sub rsp, 0x08
00007c47757df1fd  push rax
00007c47757df1fe  push rcx
00007c47757df1ff  push rdx
00007c47757df200  push rdi
00007c47757df201  push rsi
00007c47757df202  push r8
00007c47757df204  push r9
00007c47757df206  push r10
00007c47757df208  push r11
00007c47757df20a  sub rsp, 0xF0
00007c47757df211  vmovaps [rsp], xmm0
00007c47757df216  vmovaps [rsp+0x10], xmm1
00007c47757df21c  vmovaps [rsp+0x20], xmm2
00007c47757df222  vmovaps [rsp+0x30], xmm3
00007c47757df228  vmovaps [rsp+0x40], xmm4
00007c47757df22e  vmovaps [rsp+0x50], xmm5
00007c47757df234  vmovaps [rsp+0x60], xmm6
00007c47757df23a  vmovaps [rsp+0x70], xmm7
00007c47757df240  vmovaps [rsp+0x80], xmm8
00007c47757df249  vmovaps [rsp+0x90], xmm9
00007c47757df252  vmovaps [rsp+0xA0], xmm10
00007c47757df25b  vmovaps [rsp+0xB0], xmm11
00007c47757df264  vmovaps [rsp+0xC0], xmm12
00007c47757df26d  vmovaps [rsp+0xD0], xmm13
00007c47757df276  vmovaps [rsp+0xE0], xmm14
00007c47757df27f  sub rsp, 0x30
00007c47757df283  movaps [rsp], xmm15
00007c47757df288  movaps [rsp+0x10], xmm5
00007c47757df28d  movaps [rsp+0x20], xmm3
00007c47757df292  lea rdi, [rsp]
00007c47757df296  mov esi, 0x00
00007c47757df29b  mov rax, 0x62084E409530
00007c47757df2a5  call rax
00007c47757df2a7  movaps xmm15, [rsp]
00007c47757df2ac  add rsp, 0x30
00007c47757df2b0  vmovaps xmm0, [rsp]
00007c47757df2b5  vmovaps xmm1, [rsp+0x10]
00007c47757df2bb  vmovaps xmm2, [rsp+0x20]
00007c47757df2c1  vmovaps xmm3, [rsp+0x30]
00007c47757df2c7  vmovaps xmm4, [rsp+0x40]
00007c47757df2cd  vmovaps xmm5, [rsp+0x50]
00007c47757df2d3  vmovaps xmm6, [rsp+0x60]
00007c47757df2d9  vmovaps xmm7, [rsp+0x70]
00007c47757df2df  vmovaps xmm8, [rsp+0x80]
00007c47757df2e8  vmovaps xmm9, [rsp+0x90]
00007c47757df2f1  vmovaps xmm10, [rsp+0xA0]
00007c47757df2fa  vmovaps xmm11, [rsp+0xB0]
00007c47757df303  vmovaps xmm12, [rsp+0xC0]
00007c47757df30c  vmovaps xmm13, [rsp+0xD0]
00007c47757df315  vmovaps xmm14, [rsp+0xE0]
00007c47757df31e  add rsp, 0xF0
00007c47757df325  pop r11
00007c47757df327  pop r10
00007c47757df329  pop r9
00007c47757df32b  pop r8
00007c47757df32d  pop rsi
00007c47757df32e  pop rdi
00007c47757df32f  pop rdx
00007c47757df330  pop rcx
00007c47757df331  pop rax
00007c47757df332  add rsp, 0x08
00007c47757df336  jmp 0x00007C47757DC38F
00007c47757df33b  sub rsp, 0x08
00007c47757df33f  push rax
00007c47757df340  push rcx
00007c47757df341  push rdx
00007c47757df342  push rdi
00007c47757df343  push rsi
00007c47757df344  push r8
00007c47757df346  push r9
00007c47757df348  push r10
00007c47757df34a  push r11
00007c47757df34c  sub rsp, 0xF0
00007c47757df353  vmovaps [rsp], xmm0
00007c47757df358  vmovaps [rsp+0x10], xmm1
00007c47757df35e  vmovaps [rsp+0x20], xmm2
00007c47757df364  vmovaps [rsp+0x30], xmm3
00007c47757df36a  vmovaps [rsp+0x40], xmm4
00007c47757df370  vmovaps [rsp+0x50], xmm6
00007c47757df376  vmovaps [rsp+0x60], xmm7
00007c47757df37c  vmovaps [rsp+0x70], xmm8
00007c47757df382  vmovaps [rsp+0x80], xmm9
00007c47757df38b  vmovaps [rsp+0x90], xmm10
00007c47757df394  vmovaps [rsp+0xA0], xmm11
00007c47757df39d  vmovaps [rsp+0xB0], xmm12
00007c47757df3a6  vmovaps [rsp+0xC0], xmm13
00007c47757df3af  vmovaps [rsp+0xD0], xmm14
00007c47757df3b8  vmovaps [rsp+0xE0], xmm15
00007c47757df3c1  sub rsp, 0x30
00007c47757df3c5  movaps [rsp], xmm5
00007c47757df3c9  movaps [rsp+0x10], xmm8
00007c47757df3cf  movaps [rsp+0x20], xmm6
00007c47757df3d4  lea rdi, [rsp]
00007c47757df3d8  mov esi, 0x00
00007c47757df3dd  mov rax, 0x62084E409530
00007c47757df3e7  call rax
00007c47757df3e9  movaps xmm5, [rsp]
00007c47757df3ed  add rsp, 0x30
00007c47757df3f1  vmovaps xmm0, [rsp]
00007c47757df3f6  vmovaps xmm1, [rsp+0x10]
00007c47757df3fc  vmovaps xmm2, [rsp+0x20]
00007c47757df402  vmovaps xmm3, [rsp+0x30]
00007c47757df408  vmovaps xmm4, [rsp+0x40]
00007c47757df40e  vmovaps xmm6, [rsp+0x50]
00007c47757df414  vmovaps xmm7, [rsp+0x60]
00007c47757df41a  vmovaps xmm8, [rsp+0x70]
00007c47757df420  vmovaps xmm9, [rsp+0x80]
00007c47757df429  vmovaps xmm10, [rsp+0x90]
00007c47757df432  vmovaps xmm11, [rsp+0xA0]
00007c47757df43b  vmovaps xmm12, [rsp+0xB0]
00007c47757df444  vmovaps xmm13, [rsp+0xC0]
00007c47757df44d  vmovaps xmm14, [rsp+0xD0]
00007c47757df456  vmovaps xmm15, [rsp+0xE0]
00007c47757df45f  add rsp, 0xF0
00007c47757df466  pop r11
00007c47757df468  pop r10
00007c47757df46a  pop r9
00007c47757df46c  pop r8
00007c47757df46e  pop rsi
00007c47757df46f  pop rdi
00007c47757df470  pop rdx
00007c47757df471  pop rcx
00007c47757df472  pop rax
00007c47757df473  add rsp, 0x08
00007c47757df477  jmp 0x00007C47757DC3B3
00007c47757df47c  sub rsp, 0x08
00007c47757df480  push rax
00007c47757df481  push rcx
00007c47757df482  push rdx
00007c47757df483  push rdi
00007c47757df484  push rsi
00007c47757df485  push r8
00007c47757df487  push r9
00007c47757df489  push r10
00007c47757df48b  push r11
00007c47757df48d  sub rsp, 0xF0
00007c47757df494  vmovaps [rsp], xmm0
00007c47757df499  vmovaps [rsp+0x10], xmm1
00007c47757df49f  vmovaps [rsp+0x20], xmm2
00007c47757df4a5  vmovaps [rsp+0x30], xmm3
00007c47757df4ab  vmovaps [rsp+0x40], xmm4
00007c47757df4b1  vmovaps [rsp+0x50], xmm5
00007c47757df4b7  vmovaps [rsp+0x60], xmm7
00007c47757df4bd  vmovaps [rsp+0x70], xmm8
00007c47757df4c3  vmovaps [rsp+0x80], xmm9
00007c47757df4cc  vmovaps [rsp+0x90], xmm10
00007c47757df4d5  vmovaps [rsp+0xA0], xmm11
00007c47757df4de  vmovaps [rsp+0xB0], xmm12
00007c47757df4e7  vmovaps [rsp+0xC0], xmm13
00007c47757df4f0  vmovaps [rsp+0xD0], xmm14
00007c47757df4f9  vmovaps [rsp+0xE0], xmm15
00007c47757df502  sub rsp, 0x30
00007c47757df506  movaps [rsp], xmm6
00007c47757df50a  movaps [rsp+0x10], xmm10
00007c47757df510  movaps [rsp+0x20], xmm8
00007c47757df516  lea rdi, [rsp]
00007c47757df51a  mov esi, 0x00
00007c47757df51f  mov rax, 0x62084E409530
00007c47757df529  call rax
00007c47757df52b  movaps xmm6, [rsp]
00007c47757df52f  add rsp, 0x30
00007c47757df533  vmovaps xmm0, [rsp]
00007c47757df538  vmovaps xmm1, [rsp+0x10]
00007c47757df53e  vmovaps xmm2, [rsp+0x20]
00007c47757df544  vmovaps xmm3, [rsp+0x30]
00007c47757df54a  vmovaps xmm4, [rsp+0x40]
00007c47757df550  vmovaps xmm5, [rsp+0x50]
00007c47757df556  vmovaps xmm7, [rsp+0x60]
00007c47757df55c  vmovaps xmm8, [rsp+0x70]
00007c47757df562  vmovaps xmm9, [rsp+0x80]
00007c47757df56b  vmovaps xmm10, [rsp+0x90]
00007c47757df574  vmovaps xmm11, [rsp+0xA0]
00007c47757df57d  vmovaps xmm12, [rsp+0xB0]
00007c47757df586  vmovaps xmm13, [rsp+0xC0]
00007c47757df58f  vmovaps xmm14, [rsp+0xD0]
00007c47757df598  vmovaps xmm15, [rsp+0xE0]
00007c47757df5a1  add rsp, 0xF0
00007c47757df5a8  pop r11
00007c47757df5aa  pop r10
00007c47757df5ac  pop r9
00007c47757df5ae  pop r8
00007c47757df5b0  pop rsi
00007c47757df5b1  pop rdi
00007c47757df5b2  pop rdx
00007c47757df5b3  pop rcx
00007c47757df5b4  pop rax
00007c47757df5b5  add rsp, 0x08
00007c47757df5b9  jmp 0x00007C47757DC3D8
00007c47757df5be  sub rsp, 0x08
00007c47757df5c2  push rax
00007c47757df5c3  push rcx
00007c47757df5c4  push rdx
00007c47757df5c5  push rdi
00007c47757df5c6  push rsi
00007c47757df5c7  push r8
00007c47757df5c9  push r9
00007c47757df5cb  push r10
00007c47757df5cd  push r11
00007c47757df5cf  sub rsp, 0xF0
00007c47757df5d6  vmovaps [rsp], xmm0
00007c47757df5db  vmovaps [rsp+0x10], xmm1
00007c47757df5e1  vmovaps [rsp+0x20], xmm2
00007c47757df5e7  vmovaps [rsp+0x30], xmm3
00007c47757df5ed  vmovaps [rsp+0x40], xmm4
00007c47757df5f3  vmovaps [rsp+0x50], xmm5
00007c47757df5f9  vmovaps [rsp+0x60], xmm6
00007c47757df5ff  vmovaps [rsp+0x70], xmm7
00007c47757df605  vmovaps [rsp+0x80], xmm8
00007c47757df60e  vmovaps [rsp+0x90], xmm9
00007c47757df617  vmovaps [rsp+0xA0], xmm11
00007c47757df620  vmovaps [rsp+0xB0], xmm12
00007c47757df629  vmovaps [rsp+0xC0], xmm13
00007c47757df632  vmovaps [rsp+0xD0], xmm14
00007c47757df63b  vmovaps [rsp+0xE0], xmm15
00007c47757df644  sub rsp, 0x30
00007c47757df648  movaps [rsp], xmm10
00007c47757df64d  movaps [rsp+0x10], xmm8
00007c47757df653  movaps [rsp+0x20], xmm14
00007c47757df659  lea rdi, [rsp]
00007c47757df65d  mov esi, 0x00
00007c47757df662  mov rax, 0x62084E409530
00007c47757df66c  call rax
00007c47757df66e  movaps xmm10, [rsp]
00007c47757df673  add rsp, 0x30
00007c47757df677  vmovaps xmm0, [rsp]
00007c47757df67c  vmovaps xmm1, [rsp+0x10]
00007c47757df682  vmovaps xmm2, [rsp+0x20]
00007c47757df688  vmovaps xmm3, [rsp+0x30]
00007c47757df68e  vmovaps xmm4, [rsp+0x40]
00007c47757df694  vmovaps xmm5, [rsp+0x50]
00007c47757df69a  vmovaps xmm6, [rsp+0x60]
00007c47757df6a0  vmovaps xmm7, [rsp+0x70]
00007c47757df6a6  vmovaps xmm8, [rsp+0x80]
00007c47757df6af  vmovaps xmm9, [rsp+0x90]
00007c47757df6b8  vmovaps xmm11, [rsp+0xA0]
00007c47757df6c1  vmovaps xmm12, [rsp+0xB0]
00007c47757df6ca  vmovaps xmm13, [rsp+0xC0]
00007c47757df6d3  vmovaps xmm14, [rsp+0xD0]
00007c47757df6dc  vmovaps xmm15, [rsp+0xE0]
00007c47757df6e5  add rsp, 0xF0
00007c47757df6ec  pop r11
00007c47757df6ee  pop r10
00007c47757df6f0  pop r9
00007c47757df6f2  pop r8
00007c47757df6f4  pop rsi
00007c47757df6f5  pop rdi
00007c47757df6f6  pop rdx
00007c47757df6f7  pop rcx
00007c47757df6f8  pop rax
00007c47757df6f9  add rsp, 0x08
00007c47757df6fd  jmp 0x00007C47757DC3F8
00007c47757df702  sub rsp, 0x08
00007c47757df706  push rax
00007c47757df707  push rcx
00007c47757df708  push rdx
00007c47757df709  push rdi
00007c47757df70a  push rsi
00007c47757df70b  push r8
00007c47757df70d  push r9
00007c47757df70f  push r10
00007c47757df711  push r11
00007c47757df713  sub rsp, 0xF0
00007c47757df71a  vmovaps [rsp], xmm0
00007c47757df71f  vmovaps [rsp+0x10], xmm1
00007c47757df725  vmovaps [rsp+0x20], xmm2
00007c47757df72b  vmovaps [rsp+0x30], xmm3
00007c47757df731  vmovaps [rsp+0x40], xmm4
00007c47757df737  vmovaps [rsp+0x50], xmm5
00007c47757df73d  vmovaps [rsp+0x60], xmm6
00007c47757df743  vmovaps [rsp+0x70], xmm7
00007c47757df749  vmovaps [rsp+0x80], xmm8
00007c47757df752  vmovaps [rsp+0x90], xmm9
00007c47757df75b  vmovaps [rsp+0xA0], xmm10
00007c47757df764  vmovaps [rsp+0xB0], xmm11
00007c47757df76d  vmovaps [rsp+0xC0], xmm12
00007c47757df776  vmovaps [rsp+0xD0], xmm13
00007c47757df77f  vmovaps [rsp+0xE0], xmm15
00007c47757df788  sub rsp, 0x30
00007c47757df78c  movaps [rsp], xmm14
00007c47757df791  movaps [rsp+0x10], xmm8
00007c47757df797  movaps [rsp+0x20], xmm4
00007c47757df79c  lea rdi, [rsp]
00007c47757df7a0  mov esi, 0x00
00007c47757df7a5  mov rax, 0x62084E409530
00007c47757df7af  call rax
00007c47757df7b1  movaps xmm14, [rsp]
00007c47757df7b6  add rsp, 0x30
00007c47757df7ba  vmovaps xmm0, [rsp]
00007c47757df7bf  vmovaps xmm1, [rsp+0x10]
00007c47757df7c5  vmovaps xmm2, [rsp+0x20]
00007c47757df7cb  vmovaps xmm3, [rsp+0x30]
00007c47757df7d1  vmovaps xmm4, [rsp+0x40]
00007c47757df7d7  vmovaps xmm5, [rsp+0x50]
00007c47757df7dd  vmovaps xmm6, [rsp+0x60]
00007c47757df7e3  vmovaps xmm7, [rsp+0x70]
00007c47757df7e9  vmovaps xmm8, [rsp+0x80]
00007c47757df7f2  vmovaps xmm9, [rsp+0x90]
00007c47757df7fb  vmovaps xmm10, [rsp+0xA0]
00007c47757df804  vmovaps xmm11, [rsp+0xB0]
00007c47757df80d  vmovaps xmm12, [rsp+0xC0]
00007c47757df816  vmovaps xmm13, [rsp+0xD0]
00007c47757df81f  vmovaps xmm15, [rsp+0xE0]
00007c47757df828  add rsp, 0xF0
00007c47757df82f  pop r11
00007c47757df831  pop r10
00007c47757df833  pop r9
00007c47757df835  pop r8
00007c47757df837  pop rsi
00007c47757df838  pop rdi
00007c47757df839  pop rdx
00007c47757df83a  pop rcx
00007c47757df83b  pop rax
00007c47757df83c  add rsp, 0x08
00007c47757df840  jmp 0x00007C47757DC418
00007c47757df845  sub rsp, 0x08
00007c47757df849  push rax
00007c47757df84a  push rcx
00007c47757df84b  push rdx
00007c47757df84c  push rdi
00007c47757df84d  push rsi
00007c47757df84e  push r8
00007c47757df850  push r9
00007c47757df852  push r10
00007c47757df854  push r11
00007c47757df856  sub rsp, 0xF0
00007c47757df85d  vmovaps [rsp], xmm0
00007c47757df862  vmovaps [rsp+0x10], xmm1
00007c47757df868  vmovaps [rsp+0x20], xmm2
00007c47757df86e  vmovaps [rsp+0x30], xmm3
00007c47757df874  vmovaps [rsp+0x40], xmm5
00007c47757df87a  vmovaps [rsp+0x50], xmm6
00007c47757df880  vmovaps [rsp+0x60], xmm7
00007c47757df886  vmovaps [rsp+0x70], xmm8
00007c47757df88c  vmovaps [rsp+0x80], xmm9
00007c47757df895  vmovaps [rsp+0x90], xmm10
00007c47757df89e  vmovaps [rsp+0xA0], xmm11
00007c47757df8a7  vmovaps [rsp+0xB0], xmm12
00007c47757df8b0  vmovaps [rsp+0xC0], xmm13
00007c47757df8b9  vmovaps [rsp+0xD0], xmm14
00007c47757df8c2  vmovaps [rsp+0xE0], xmm15
00007c47757df8cb  sub rsp, 0x30
00007c47757df8cf  movaps [rsp], xmm4
00007c47757df8d3  movaps [rsp+0x10], xmm13
00007c47757df8d9  movaps [rsp+0x20], xmm8
00007c47757df8df  lea rdi, [rsp]
00007c47757df8e3  mov esi, 0x00
00007c47757df8e8  mov rax, 0x62084E409530
00007c47757df8f2  call rax
00007c47757df8f4  movaps xmm4, [rsp]
00007c47757df8f8  add rsp, 0x30
00007c47757df8fc  vmovaps xmm0, [rsp]
00007c47757df901  vmovaps xmm1, [rsp+0x10]
00007c47757df907  vmovaps xmm2, [rsp+0x20]
00007c47757df90d  vmovaps xmm3, [rsp+0x30]
00007c47757df913  vmovaps xmm5, [rsp+0x40]
00007c47757df919  vmovaps xmm6, [rsp+0x50]
00007c47757df91f  vmovaps xmm7, [rsp+0x60]
00007c47757df925  vmovaps xmm8, [rsp+0x70]
00007c47757df92b  vmovaps xmm9, [rsp+0x80]
00007c47757df934  vmovaps xmm10, [rsp+0x90]
00007c47757df93d  vmovaps xmm11, [rsp+0xA0]
00007c47757df946  vmovaps xmm12, [rsp+0xB0]
00007c47757df94f  vmovaps xmm13, [rsp+0xC0]
00007c47757df958  vmovaps xmm14, [rsp+0xD0]
00007c47757df961  vmovaps xmm15, [rsp+0xE0]
00007c47757df96a  add rsp, 0xF0
00007c47757df971  pop r11
00007c47757df973  pop r10
00007c47757df975  pop r9
00007c47757df977  pop r8
00007c47757df979  pop rsi
00007c47757df97a  pop rdi
00007c47757df97b  pop rdx
00007c47757df97c  pop rcx
00007c47757df97d  pop rax
00007c47757df97e  add rsp, 0x08
00007c47757df982  jmp 0x00007C47757DC43D
00007c47757df987  sub rsp, 0x08
00007c47757df98b  push rax
00007c47757df98c  push rcx
00007c47757df98d  push rdx
00007c47757df98e  push rdi
00007c47757df98f  push rsi
00007c47757df990  push r8
00007c47757df992  push r9
00007c47757df994  push r10
00007c47757df996  push r11
00007c47757df998  sub rsp, 0xF0
00007c47757df99f  vmovaps [rsp], xmm0
00007c47757df9a4  vmovaps [rsp+0x10], xmm1
00007c47757df9aa  vmovaps [rsp+0x20], xmm2
00007c47757df9b0  vmovaps [rsp+0x30], xmm3
00007c47757df9b6  vmovaps [rsp+0x40], xmm4
00007c47757df9bc  vmovaps [rsp+0x50], xmm5
00007c47757df9c2  vmovaps [rsp+0x60], xmm6
00007c47757df9c8  vmovaps [rsp+0x70], xmm7
00007c47757df9ce  vmovaps [rsp+0x80], xmm8
00007c47757df9d7  vmovaps [rsp+0x90], xmm9
00007c47757df9e0  vmovaps [rsp+0xA0], xmm10
00007c47757df9e9  vmovaps [rsp+0xB0], xmm11
00007c47757df9f2  vmovaps [rsp+0xC0], xmm12
00007c47757df9fb  vmovaps [rsp+0xD0], xmm14
00007c47757dfa04  vmovaps [rsp+0xE0], xmm15
00007c47757dfa0d  sub rsp, 0x30
00007c47757dfa11  movaps [rsp], xmm13
00007c47757dfa16  movaps [rsp+0x10], xmm15
00007c47757dfa1c  movaps [rsp+0x20], xmm9
00007c47757dfa22  lea rdi, [rsp]
00007c47757dfa26  mov esi, 0x00
00007c47757dfa2b  mov rax, 0x62084E409530
00007c47757dfa35  call rax
00007c47757dfa37  movaps xmm13, [rsp]
00007c47757dfa3c  add rsp, 0x30
00007c47757dfa40  vmovaps xmm0, [rsp]
00007c47757dfa45  vmovaps xmm1, [rsp+0x10]
00007c47757dfa4b  vmovaps xmm2, [rsp+0x20]
00007c47757dfa51  vmovaps xmm3, [rsp+0x30]
00007c47757dfa57  vmovaps xmm4, [rsp+0x40]
00007c47757dfa5d  vmovaps xmm5, [rsp+0x50]
00007c47757dfa63  vmovaps xmm6, [rsp+0x60]
00007c47757dfa69  vmovaps xmm7, [rsp+0x70]
00007c47757dfa6f  vmovaps xmm8, [rsp+0x80]
00007c47757dfa78  vmovaps xmm9, [rsp+0x90]
00007c47757dfa81  vmovaps xmm10, [rsp+0xA0]
00007c47757dfa8a  vmovaps xmm11, [rsp+0xB0]
00007c47757dfa93  vmovaps xmm12, [rsp+0xC0]
00007c47757dfa9c  vmovaps xmm14, [rsp+0xD0]
00007c47757dfaa5  vmovaps xmm15, [rsp+0xE0]
00007c47757dfaae  add rsp, 0xF0
00007c47757dfab5  pop r11
00007c47757dfab7  pop r10
00007c47757dfab9  pop r9
00007c47757dfabb  pop r8
00007c47757dfabd  pop rsi
00007c47757dfabe  pop rdi
00007c47757dfabf  pop rdx
00007c47757dfac0  pop rcx
00007c47757dfac1  pop rax
00007c47757dfac2  add rsp, 0x08
00007c47757dfac6  jmp 0x00007C47757DC458
00007c47757dfacb  sub rsp, 0x08
00007c47757dfacf  push rax
00007c47757dfad0  push rcx
00007c47757dfad1  push rdx
00007c47757dfad2  push rdi
00007c47757dfad3  push rsi
00007c47757dfad4  push r8
00007c47757dfad6  push r9
00007c47757dfad8  push r10
00007c47757dfada  push r11
00007c47757dfadc  sub rsp, 0xF0
00007c47757dfae3  vmovaps [rsp], xmm0
00007c47757dfae8  vmovaps [rsp+0x10], xmm1
00007c47757dfaee  vmovaps [rsp+0x20], xmm2
00007c47757dfaf4  vmovaps [rsp+0x30], xmm3
00007c47757dfafa  vmovaps [rsp+0x40], xmm4
00007c47757dfb00  vmovaps [rsp+0x50], xmm5
00007c47757dfb06  vmovaps [rsp+0x60], xmm6
00007c47757dfb0c  vmovaps [rsp+0x70], xmm7
00007c47757dfb12  vmovaps [rsp+0x80], xmm8
00007c47757dfb1b  vmovaps [rsp+0x90], xmm9
00007c47757dfb24  vmovaps [rsp+0xA0], xmm10
00007c47757dfb2d  vmovaps [rsp+0xB0], xmm11
00007c47757dfb36  vmovaps [rsp+0xC0], xmm12
00007c47757dfb3f  vmovaps [rsp+0xD0], xmm13
00007c47757dfb48  vmovaps [rsp+0xE0], xmm14
00007c47757dfb51  sub rsp, 0x30
00007c47757dfb55  movaps [rsp], xmm15
00007c47757dfb5a  movaps [rsp+0x10], xmm1
00007c47757dfb5f  movaps [rsp+0x20], xmm5
00007c47757dfb64  lea rdi, [rsp]
00007c47757dfb68  mov esi, 0x00
00007c47757dfb6d  mov rax, 0x62084E409530
00007c47757dfb77  call rax
00007c47757dfb79  movaps xmm15, [rsp]
00007c47757dfb7e  add rsp, 0x30
00007c47757dfb82  vmovaps xmm0, [rsp]
00007c47757dfb87  vmovaps xmm1, [rsp+0x10]
00007c47757dfb8d  vmovaps xmm2, [rsp+0x20]
00007c47757dfb93  vmovaps xmm3, [rsp+0x30]
00007c47757dfb99  vmovaps xmm4, [rsp+0x40]
00007c47757dfb9f  vmovaps xmm5, [rsp+0x50]
00007c47757dfba5  vmovaps xmm6, [rsp+0x60]
00007c47757dfbab  vmovaps xmm7, [rsp+0x70]
00007c47757dfbb1  vmovaps xmm8, [rsp+0x80]
00007c47757dfbba  vmovaps xmm9, [rsp+0x90]
00007c47757dfbc3  vmovaps xmm10, [rsp+0xA0]
00007c47757dfbcc  vmovaps xmm11, [rsp+0xB0]
00007c47757dfbd5  vmovaps xmm12, [rsp+0xC0]
00007c47757dfbde  vmovaps xmm13, [rsp+0xD0]
00007c47757dfbe7  vmovaps xmm14, [rsp+0xE0]
00007c47757dfbf0  add rsp, 0xF0
00007c47757dfbf7  pop r11
00007c47757dfbf9  pop r10
00007c47757dfbfb  pop r9
00007c47757dfbfd  pop r8
00007c47757dfbff  pop rsi
00007c47757dfc00  pop rdi
00007c47757dfc01  pop rdx
00007c47757dfc02  pop rcx
00007c47757dfc03  pop rax
00007c47757dfc04  add rsp, 0x08
00007c47757dfc08  jmp 0x00007C47757DC473
00007c47757dfc0d  call 0x00007C47756B52F0
00007c47757dfc12  jmp 0x00007C47757DC4CE
00007c47757dfc17  sub rsp, 0x08
00007c47757dfc1b  push rax
00007c47757dfc1c  push rcx
00007c47757dfc1d  push rdx
00007c47757dfc1e  push rdi
00007c47757dfc1f  push rsi
00007c47757dfc20  push r8
00007c47757dfc22  push r9
00007c47757dfc24  push r10
00007c47757dfc26  push r11
00007c47757dfc28  sub rsp, 0xF0
00007c47757dfc2f  vmovaps [rsp], xmm0
00007c47757dfc34  vmovaps [rsp+0x10], xmm1
00007c47757dfc3a  vmovaps [rsp+0x20], xmm2
00007c47757dfc40  vmovaps [rsp+0x30], xmm3
00007c47757dfc46  vmovaps [rsp+0x40], xmm4
00007c47757dfc4c  vmovaps [rsp+0x50], xmm5
00007c47757dfc52  vmovaps [rsp+0x60], xmm6
00007c47757dfc58  vmovaps [rsp+0x70], xmm7
00007c47757dfc5e  vmovaps [rsp+0x80], xmm8
00007c47757dfc67  vmovaps [rsp+0x90], xmm10
00007c47757dfc70  vmovaps [rsp+0xA0], xmm11
00007c47757dfc79  vmovaps [rsp+0xB0], xmm12
00007c47757dfc82  vmovaps [rsp+0xC0], xmm13
00007c47757dfc8b  vmovaps [rsp+0xD0], xmm14
00007c47757dfc94  vmovaps [rsp+0xE0], xmm15
00007c47757dfc9d  sub rsp, 0x30
00007c47757dfca1  movaps [rsp], xmm9
00007c47757dfca6  movaps [rsp+0x10], xmm8
00007c47757dfcac  movaps [rsp+0x20], xmm11
00007c47757dfcb2  lea rdi, [rsp]
00007c47757dfcb6  mov esi, 0x00
00007c47757dfcbb  mov rax, 0x62084E409530
00007c47757dfcc5  call rax
00007c47757dfcc7  movaps xmm9, [rsp]
00007c47757dfccc  add rsp, 0x30
00007c47757dfcd0  vmovaps xmm0, [rsp]
00007c47757dfcd5  vmovaps xmm1, [rsp+0x10]
00007c47757dfcdb  vmovaps xmm2, [rsp+0x20]
00007c47757dfce1  vmovaps xmm3, [rsp+0x30]
00007c47757dfce7  vmovaps xmm4, [rsp+0x40]
00007c47757dfced  vmovaps xmm5, [rsp+0x50]
00007c47757dfcf3  vmovaps xmm6, [rsp+0x60]
00007c47757dfcf9  vmovaps xmm7, [rsp+0x70]
00007c47757dfcff  vmovaps xmm8, [rsp+0x80]
00007c47757dfd08  vmovaps xmm10, [rsp+0x90]
00007c47757dfd11  vmovaps xmm11, [rsp+0xA0]
00007c47757dfd1a  vmovaps xmm12, [rsp+0xB0]
00007c47757dfd23  vmovaps xmm13, [rsp+0xC0]
00007c47757dfd2c  vmovaps xmm14, [rsp+0xD0]
00007c47757dfd35  vmovaps xmm15, [rsp+0xE0]
00007c47757dfd3e  add rsp, 0xF0
00007c47757dfd45  pop r11
00007c47757dfd47  pop r10
00007c47757dfd49  pop r9
00007c47757dfd4b  pop r8
00007c47757dfd4d  pop rsi
00007c47757dfd4e  pop rdi
00007c47757dfd4f  pop rdx
00007c47757dfd50  pop rcx
00007c47757dfd51  pop rax
00007c47757dfd52  add rsp, 0x08
00007c47757dfd56  jmp 0x00007C47757DC505
00007c47757dfd5b  sub rsp, 0x08
00007c47757dfd5f  push rax
00007c47757dfd60  push rcx
00007c47757dfd61  push rdx
00007c47757dfd62  push rdi
00007c47757dfd63  push rsi
00007c47757dfd64  push r8
00007c47757dfd66  push r9
00007c47757dfd68  push r10
00007c47757dfd6a  push r11
00007c47757dfd6c  sub rsp, 0xF0
00007c47757dfd73  vmovaps [rsp], xmm0
00007c47757dfd78  vmovaps [rsp+0x10], xmm1
00007c47757dfd7e  vmovaps [rsp+0x20], xmm2
00007c47757dfd84  vmovaps [rsp+0x30], xmm3
00007c47757dfd8a  vmovaps [rsp+0x40], xmm4
00007c47757dfd90  vmovaps [rsp+0x50], xmm5
00007c47757dfd96  vmovaps [rsp+0x60], xmm6
00007c47757dfd9c  vmovaps [rsp+0x70], xmm7
00007c47757dfda2  vmovaps [rsp+0x80], xmm8
00007c47757dfdab  vmovaps [rsp+0x90], xmm9
00007c47757dfdb4  vmovaps [rsp+0xA0], xmm10
00007c47757dfdbd  vmovaps [rsp+0xB0], xmm12
00007c47757dfdc6  vmovaps [rsp+0xC0], xmm13
00007c47757dfdcf  vmovaps [rsp+0xD0], xmm14
00007c47757dfdd8  vmovaps [rsp+0xE0], xmm15
00007c47757dfde1  sub rsp, 0x30
00007c47757dfde5  movaps [rsp], xmm11
00007c47757dfdea  movaps [rsp+0x10], xmm10
00007c47757dfdf0  movaps [rsp+0x20], xmm6
00007c47757dfdf5  lea rdi, [rsp]
00007c47757dfdf9  mov esi, 0x00
00007c47757dfdfe  mov rax, 0x62084E409530
00007c47757dfe08  call rax
00007c47757dfe0a  movaps xmm11, [rsp]
00007c47757dfe0f  add rsp, 0x30
00007c47757dfe13  vmovaps xmm0, [rsp]
00007c47757dfe18  vmovaps xmm1, [rsp+0x10]
00007c47757dfe1e  vmovaps xmm2, [rsp+0x20]
00007c47757dfe24  vmovaps xmm3, [rsp+0x30]
00007c47757dfe2a  vmovaps xmm4, [rsp+0x40]
00007c47757dfe30  vmovaps xmm5, [rsp+0x50]
00007c47757dfe36  vmovaps xmm6, [rsp+0x60]
00007c47757dfe3c  vmovaps xmm7, [rsp+0x70]
00007c47757dfe42  vmovaps xmm8, [rsp+0x80]
00007c47757dfe4b  vmovaps xmm9, [rsp+0x90]
00007c47757dfe54  vmovaps xmm10, [rsp+0xA0]
00007c47757dfe5d  vmovaps xmm12, [rsp+0xB0]
00007c47757dfe66  vmovaps xmm13, [rsp+0xC0]
00007c47757dfe6f  vmovaps xmm14, [rsp+0xD0]
00007c47757dfe78  vmovaps xmm15, [rsp+0xE0]
00007c47757dfe81  add rsp, 0xF0
00007c47757dfe88  pop r11
00007c47757dfe8a  pop r10
00007c47757dfe8c  pop r9
00007c47757dfe8e  pop r8
00007c47757dfe90  pop rsi
00007c47757dfe91  pop rdi
00007c47757dfe92  pop rdx
00007c47757dfe93  pop rcx
00007c47757dfe94  pop rax
00007c47757dfe95  add rsp, 0x08
00007c47757dfe99  jmp 0x00007C47757DC520
00007c47757dfe9e  sub rsp, 0x08
00007c47757dfea2  push rax
00007c47757dfea3  push rcx
00007c47757dfea4  push rdx
00007c47757dfea5  push rdi
00007c47757dfea6  push rsi
00007c47757dfea7  push r8
00007c47757dfea9  push r9
00007c47757dfeab  push r10
00007c47757dfead  push r11
00007c47757dfeaf  sub rsp, 0xF0
00007c47757dfeb6  vmovaps [rsp], xmm0
00007c47757dfebb  vmovaps [rsp+0x10], xmm1
00007c47757dfec1  vmovaps [rsp+0x20], xmm2
00007c47757dfec7  vmovaps [rsp+0x30], xmm3
00007c47757dfecd  vmovaps [rsp+0x40], xmm4
00007c47757dfed3  vmovaps [rsp+0x50], xmm5
00007c47757dfed9  vmovaps [rsp+0x60], xmm6
00007c47757dfedf  vmovaps [rsp+0x70], xmm7
00007c47757dfee5  vmovaps [rsp+0x80], xmm8
00007c47757dfeee  vmovaps [rsp+0x90], xmm9
00007c47757dfef7  vmovaps [rsp+0xA0], xmm11
00007c47757dff00  vmovaps [rsp+0xB0], xmm12
00007c47757dff09  vmovaps [rsp+0xC0], xmm13
00007c47757dff12  vmovaps [rsp+0xD0], xmm14
00007c47757dff1b  vmovaps [rsp+0xE0], xmm15
00007c47757dff24  sub rsp, 0x30
00007c47757dff28  movaps [rsp], xmm10
00007c47757dff2d  movaps [rsp+0x10], xmm14
00007c47757dff33  movaps [rsp+0x20], xmm4
00007c47757dff38  lea rdi, [rsp]
00007c47757dff3c  mov esi, 0x00
00007c47757dff41  mov rax, 0x62084E409530
00007c47757dff4b  call rax
00007c47757dff4d  movaps xmm10, [rsp]
00007c47757dff52  add rsp, 0x30
00007c47757dff56  vmovaps xmm0, [rsp]
00007c47757dff5b  vmovaps xmm1, [rsp+0x10]
00007c47757dff61  vmovaps xmm2, [rsp+0x20]
00007c47757dff67  vmovaps xmm3, [rsp+0x30]
00007c47757dff6d  vmovaps xmm4, [rsp+0x40]
00007c47757dff73  vmovaps xmm5, [rsp+0x50]
00007c47757dff79  vmovaps xmm6, [rsp+0x60]
00007c47757dff7f  vmovaps xmm7, [rsp+0x70]
00007c47757dff85  vmovaps xmm8, [rsp+0x80]
00007c47757dff8e  vmovaps xmm9, [rsp+0x90]
00007c47757dff97  vmovaps xmm11, [rsp+0xA0]
00007c47757dffa0  vmovaps xmm12, [rsp+0xB0]
00007c47757dffa9  vmovaps xmm13, [rsp+0xC0]
00007c47757dffb2  vmovaps xmm14, [rsp+0xD0]
00007c47757dffbb  vmovaps xmm15, [rsp+0xE0]
00007c47757dffc4  add rsp, 0xF0
00007c47757dffcb  pop r11
00007c47757dffcd  pop r10
00007c47757dffcf  pop r9
00007c47757dffd1  pop r8
00007c47757dffd3  pop rsi
00007c47757dffd4  pop rdi
00007c47757dffd5  pop rdx
00007c47757dffd6  pop rcx
00007c47757dffd7  pop rax
00007c47757dffd8  add rsp, 0x08
00007c47757dffdc  jmp 0x00007C47757DC53B
00007c47757dffe1  sub rsp, 0x08
00007c47757dffe5  push rax
00007c47757dffe6  push rcx
00007c47757dffe7  push rdx
00007c47757dffe8  push rdi
00007c47757dffe9  push rsi
00007c47757dffea  push r8
00007c47757dffec  push r9
00007c47757dffee  push r10
00007c47757dfff0  push r11
00007c47757dfff2  sub rsp, 0xF0
00007c47757dfff9  vmovaps [rsp], xmm0
00007c47757dfffe  vmovaps [rsp+0x10], xmm1
00007c47757e0004  vmovaps [rsp+0x20], xmm2
00007c47757e000a  vmovaps [rsp+0x30], xmm3
00007c47757e0010  vmovaps [rsp+0x40], xmm4
00007c47757e0016  vmovaps [rsp+0x50], xmm5
00007c47757e001c  vmovaps [rsp+0x60], xmm6
00007c47757e0022  vmovaps [rsp+0x70], xmm7
00007c47757e0028  vmovaps [rsp+0x80], xmm9
00007c47757e0031  vmovaps [rsp+0x90], xmm10
00007c47757e003a  vmovaps [rsp+0xA0], xmm11
00007c47757e0043  vmovaps [rsp+0xB0], xmm12
00007c47757e004c  vmovaps [rsp+0xC0], xmm13
00007c47757e0055  vmovaps [rsp+0xD0], xmm14
00007c47757e005e  vmovaps [rsp+0xE0], xmm15
00007c47757e0067  sub rsp, 0x30
00007c47757e006b  movaps [rsp], xmm8
00007c47757e0070  movaps [rsp+0x10], xmm1
00007c47757e0075  movaps [rsp+0x20], xmm14
00007c47757e007b  lea rdi, [rsp]
00007c47757e007f  mov esi, 0x00
00007c47757e0084  mov rax, 0x62084E409530
00007c47757e008e  call rax
00007c47757e0090  movaps xmm8, [rsp]
00007c47757e0095  add rsp, 0x30
00007c47757e0099  vmovaps xmm0, [rsp]
00007c47757e009e  vmovaps xmm1, [rsp+0x10]
00007c47757e00a4  vmovaps xmm2, [rsp+0x20]
00007c47757e00aa  vmovaps xmm3, [rsp+0x30]
00007c47757e00b0  vmovaps xmm4, [rsp+0x40]
00007c47757e00b6  vmovaps xmm5, [rsp+0x50]
00007c47757e00bc  vmovaps xmm6, [rsp+0x60]
00007c47757e00c2  vmovaps xmm7, [rsp+0x70]
00007c47757e00c8  vmovaps xmm9, [rsp+0x80]
00007c47757e00d1  vmovaps xmm10, [rsp+0x90]
00007c47757e00da  vmovaps xmm11, [rsp+0xA0]
00007c47757e00e3  vmovaps xmm12, [rsp+0xB0]
00007c47757e00ec  vmovaps xmm13, [rsp+0xC0]
00007c47757e00f5  vmovaps xmm14, [rsp+0xD0]
00007c47757e00fe  vmovaps xmm15, [rsp+0xE0]
00007c47757e0107  add rsp, 0xF0
00007c47757e010e  pop r11
00007c47757e0110  pop r10
00007c47757e0112  pop r9
00007c47757e0114  pop r8
00007c47757e0116  pop rsi
00007c47757e0117  pop rdi
00007c47757e0118  pop rdx
00007c47757e0119  pop rcx
00007c47757e011a  pop rax
00007c47757e011b  add rsp, 0x08
00007c47757e011f  jmp 0x00007C47757DC561
00007c47757e0124  sub rsp, 0x08
00007c47757e0128  push rax
00007c47757e0129  push rcx
00007c47757e012a  push rdx
00007c47757e012b  push rdi
00007c47757e012c  push rsi
00007c47757e012d  push r8
00007c47757e012f  push r9
00007c47757e0131  push r10
00007c47757e0133  push r11
00007c47757e0135  sub rsp, 0xF0
00007c47757e013c  vmovaps [rsp], xmm0
00007c47757e0141  vmovaps [rsp+0x10], xmm1
00007c47757e0147  vmovaps [rsp+0x20], xmm2
00007c47757e014d  vmovaps [rsp+0x30], xmm3
00007c47757e0153  vmovaps [rsp+0x40], xmm4
00007c47757e0159  vmovaps [rsp+0x50], xmm5
00007c47757e015f  vmovaps [rsp+0x60], xmm7
00007c47757e0165  vmovaps [rsp+0x70], xmm8
00007c47757e016b  vmovaps [rsp+0x80], xmm9
00007c47757e0174  vmovaps [rsp+0x90], xmm10
00007c47757e017d  vmovaps [rsp+0xA0], xmm11
00007c47757e0186  vmovaps [rsp+0xB0], xmm12
00007c47757e018f  vmovaps [rsp+0xC0], xmm13
00007c47757e0198  vmovaps [rsp+0xD0], xmm14
00007c47757e01a1  vmovaps [rsp+0xE0], xmm15
00007c47757e01aa  sub rsp, 0x30
00007c47757e01ae  movaps [rsp], xmm6
00007c47757e01b2  movaps [rsp+0x10], xmm1
00007c47757e01b7  movaps [rsp+0x20], xmm14
00007c47757e01bd  lea rdi, [rsp]
00007c47757e01c1  mov esi, 0x00
00007c47757e01c6  mov rax, 0x62084E409530
00007c47757e01d0  call rax
00007c47757e01d2  movaps xmm6, [rsp]
00007c47757e01d6  add rsp, 0x30
00007c47757e01da  vmovaps xmm0, [rsp]
00007c47757e01df  vmovaps xmm1, [rsp+0x10]
00007c47757e01e5  vmovaps xmm2, [rsp+0x20]
00007c47757e01eb  vmovaps xmm3, [rsp+0x30]
00007c47757e01f1  vmovaps xmm4, [rsp+0x40]
00007c47757e01f7  vmovaps xmm5, [rsp+0x50]
00007c47757e01fd  vmovaps xmm7, [rsp+0x60]
00007c47757e0203  vmovaps xmm8, [rsp+0x70]
00007c47757e0209  vmovaps xmm9, [rsp+0x80]
00007c47757e0212  vmovaps xmm10, [rsp+0x90]
00007c47757e021b  vmovaps xmm11, [rsp+0xA0]
00007c47757e0224  vmovaps xmm12, [rsp+0xB0]
00007c47757e022d  vmovaps xmm13, [rsp+0xC0]
00007c47757e0236  vmovaps xmm14, [rsp+0xD0]
00007c47757e023f  vmovaps xmm15, [rsp+0xE0]
00007c47757e0248  add rsp, 0xF0
00007c47757e024f  pop r11
00007c47757e0251  pop r10
00007c47757e0253  pop r9
00007c47757e0255  pop r8
00007c47757e0257  pop rsi
00007c47757e0258  pop rdi
00007c47757e0259  pop rdx
00007c47757e025a  pop rcx
00007c47757e025b  pop rax
00007c47757e025c  add rsp, 0x08
00007c47757e0260  jmp 0x00007C47757DC58D
00007c47757e0265  sub rsp, 0x08
00007c47757e0269  push rax
00007c47757e026a  push rcx
00007c47757e026b  push rdx
00007c47757e026c  push rdi
00007c47757e026d  push rsi
00007c47757e026e  push r8
00007c47757e0270  push r9
00007c47757e0272  push r10
00007c47757e0274  push r11
00007c47757e0276  sub rsp, 0xF0
00007c47757e027d  vmovaps [rsp], xmm0
00007c47757e0282  vmovaps [rsp+0x10], xmm1
00007c47757e0288  vmovaps [rsp+0x20], xmm2
00007c47757e028e  vmovaps [rsp+0x30], xmm3
00007c47757e0294  vmovaps [rsp+0x40], xmm4
00007c47757e029a  vmovaps [rsp+0x50], xmm5
00007c47757e02a0  vmovaps [rsp+0x60], xmm6
00007c47757e02a6  vmovaps [rsp+0x70], xmm7
00007c47757e02ac  vmovaps [rsp+0x80], xmm8
00007c47757e02b5  vmovaps [rsp+0x90], xmm9
00007c47757e02be  vmovaps [rsp+0xA0], xmm10
00007c47757e02c7  vmovaps [rsp+0xB0], xmm11
00007c47757e02d0  vmovaps [rsp+0xC0], xmm12
00007c47757e02d9  vmovaps [rsp+0xD0], xmm13
00007c47757e02e2  vmovaps [rsp+0xE0], xmm15
00007c47757e02eb  sub rsp, 0x30
00007c47757e02ef  movaps [rsp], xmm14
00007c47757e02f4  movaps [rsp+0x10], xmm12
00007c47757e02fa  movaps [rsp+0x20], xmm1
00007c47757e02ff  lea rdi, [rsp]
00007c47757e0303  mov esi, 0x00
00007c47757e0308  mov rax, 0x62084E409530
00007c47757e0312  call rax
00007c47757e0314  movaps xmm14, [rsp]
00007c47757e0319  add rsp, 0x30
00007c47757e031d  vmovaps xmm0, [rsp]
00007c47757e0322  vmovaps xmm1, [rsp+0x10]
00007c47757e0328  vmovaps xmm2, [rsp+0x20]
00007c47757e032e  vmovaps xmm3, [rsp+0x30]
00007c47757e0334  vmovaps xmm4, [rsp+0x40]
00007c47757e033a  vmovaps xmm5, [rsp+0x50]
00007c47757e0340  vmovaps xmm6, [rsp+0x60]
00007c47757e0346  vmovaps xmm7, [rsp+0x70]
00007c47757e034c  vmovaps xmm8, [rsp+0x80]
00007c47757e0355  vmovaps xmm9, [rsp+0x90]
00007c47757e035e  vmovaps xmm10, [rsp+0xA0]
00007c47757e0367  vmovaps xmm11, [rsp+0xB0]
00007c47757e0370  vmovaps xmm12, [rsp+0xC0]
00007c47757e0379  vmovaps xmm13, [rsp+0xD0]
00007c47757e0382  vmovaps xmm15, [rsp+0xE0]
00007c47757e038b  add rsp, 0xF0
00007c47757e0392  pop r11
00007c47757e0394  pop r10
00007c47757e0396  pop r9
00007c47757e0398  pop r8
00007c47757e039a  pop rsi
00007c47757e039b  pop rdi
00007c47757e039c  pop rdx
00007c47757e039d  pop rcx
00007c47757e039e  pop rax
00007c47757e039f  add rsp, 0x08
00007c47757e03a3  jmp 0x00007C47757DC5B3
00007c47757e03a8  sub rsp, 0x08
00007c47757e03ac  push rax
00007c47757e03ad  push rcx
00007c47757e03ae  push rdx
00007c47757e03af  push rdi
00007c47757e03b0  push rsi
00007c47757e03b1  push r8
00007c47757e03b3  push r9
00007c47757e03b5  push r10
00007c47757e03b7  push r11
00007c47757e03b9  sub rsp, 0xF0
00007c47757e03c0  vmovaps [rsp], xmm0
00007c47757e03c5  vmovaps [rsp+0x10], xmm2
00007c47757e03cb  vmovaps [rsp+0x20], xmm3
00007c47757e03d1  vmovaps [rsp+0x30], xmm4
00007c47757e03d7  vmovaps [rsp+0x40], xmm5
00007c47757e03dd  vmovaps [rsp+0x50], xmm6
00007c47757e03e3  vmovaps [rsp+0x60], xmm7
00007c47757e03e9  vmovaps [rsp+0x70], xmm8
00007c47757e03ef  vmovaps [rsp+0x80], xmm9
00007c47757e03f8  vmovaps [rsp+0x90], xmm10
00007c47757e0401  vmovaps [rsp+0xA0], xmm11
00007c47757e040a  vmovaps [rsp+0xB0], xmm12
00007c47757e0413  vmovaps [rsp+0xC0], xmm13
00007c47757e041c  vmovaps [rsp+0xD0], xmm14
00007c47757e0425  vmovaps [rsp+0xE0], xmm15
00007c47757e042e  sub rsp, 0x30
00007c47757e0432  movaps [rsp], xmm1
00007c47757e0436  movaps [rsp+0x10], xmm13
00007c47757e043c  movaps [rsp+0x20], xmm9
00007c47757e0442  lea rdi, [rsp]
00007c47757e0446  mov esi, 0x00
00007c47757e044b  mov rax, 0x62084E409530
00007c47757e0455  call rax
00007c47757e0457  movaps xmm1, [rsp]
00007c47757e045b  add rsp, 0x30
00007c47757e045f  vmovaps xmm0, [rsp]
00007c47757e0464  vmovaps xmm2, [rsp+0x10]
00007c47757e046a  vmovaps xmm3, [rsp+0x20]
00007c47757e0470  vmovaps xmm4, [rsp+0x30]
00007c47757e0476  vmovaps xmm5, [rsp+0x40]
00007c47757e047c  vmovaps xmm6, [rsp+0x50]
00007c47757e0482  vmovaps xmm7, [rsp+0x60]
00007c47757e0488  vmovaps xmm8, [rsp+0x70]
00007c47757e048e  vmovaps xmm9, [rsp+0x80]
00007c47757e0497  vmovaps xmm10, [rsp+0x90]
00007c47757e04a0  vmovaps xmm11, [rsp+0xA0]
00007c47757e04a9  vmovaps xmm12, [rsp+0xB0]
00007c47757e04b2  vmovaps xmm13, [rsp+0xC0]
00007c47757e04bb  vmovaps xmm14, [rsp+0xD0]
00007c47757e04c4  vmovaps xmm15, [rsp+0xE0]
00007c47757e04cd  add rsp, 0xF0
00007c47757e04d4  pop r11
00007c47757e04d6  pop r10
00007c47757e04d8  pop r9
00007c47757e04da  pop r8
00007c47757e04dc  pop rsi
00007c47757e04dd  pop rdi
00007c47757e04de  pop rdx
00007c47757e04df  pop rcx
00007c47757e04e0  pop rax
00007c47757e04e1  add rsp, 0x08
00007c47757e04e5  jmp 0x00007C47757DC5CD
00007c47757e04ea  sub rsp, 0x08
00007c47757e04ee  push rax
00007c47757e04ef  push rcx
00007c47757e04f0  push rdx
00007c47757e04f1  push rdi
00007c47757e04f2  push rsi
00007c47757e04f3  push r8
00007c47757e04f5  push r9
00007c47757e04f7  push r10
00007c47757e04f9  push r11
00007c47757e04fb  sub rsp, 0xF0
00007c47757e0502  vmovaps [rsp], xmm0
00007c47757e0507  vmovaps [rsp+0x10], xmm1
00007c47757e050d  vmovaps [rsp+0x20], xmm2
00007c47757e0513  vmovaps [rsp+0x30], xmm3
00007c47757e0519  vmovaps [rsp+0x40], xmm4
00007c47757e051f  vmovaps [rsp+0x50], xmm5
00007c47757e0525  vmovaps [rsp+0x60], xmm6
00007c47757e052b  vmovaps [rsp+0x70], xmm7
00007c47757e0531  vmovaps [rsp+0x80], xmm8
00007c47757e053a  vmovaps [rsp+0x90], xmm9
00007c47757e0543  vmovaps [rsp+0xA0], xmm10
00007c47757e054c  vmovaps [rsp+0xB0], xmm11
00007c47757e0555  vmovaps [rsp+0xC0], xmm13
00007c47757e055e  vmovaps [rsp+0xD0], xmm14
00007c47757e0567  vmovaps [rsp+0xE0], xmm15
00007c47757e0570  sub rsp, 0x30
00007c47757e0574  movaps [rsp], xmm12
00007c47757e0579  movaps [rsp+0x10], xmm7
00007c47757e057e  movaps [rsp+0x20], xmm13
00007c47757e0584  lea rdi, [rsp]
00007c47757e0588  mov esi, 0x00
00007c47757e058d  mov rax, 0x62084E409530
00007c47757e0597  call rax
00007c47757e0599  movaps xmm12, [rsp]
00007c47757e059e  add rsp, 0x30
00007c47757e05a2  vmovaps xmm0, [rsp]
00007c47757e05a7  vmovaps xmm1, [rsp+0x10]
00007c47757e05ad  vmovaps xmm2, [rsp+0x20]
00007c47757e05b3  vmovaps xmm3, [rsp+0x30]
00007c47757e05b9  vmovaps xmm4, [rsp+0x40]
00007c47757e05bf  vmovaps xmm5, [rsp+0x50]
00007c47757e05c5  vmovaps xmm6, [rsp+0x60]
00007c47757e05cb  vmovaps xmm7, [rsp+0x70]
00007c47757e05d1  vmovaps xmm8, [rsp+0x80]
00007c47757e05da  vmovaps xmm9, [rsp+0x90]
00007c47757e05e3  vmovaps xmm10, [rsp+0xA0]
00007c47757e05ec  vmovaps xmm11, [rsp+0xB0]
00007c47757e05f5  vmovaps xmm13, [rsp+0xC0]
00007c47757e05fe  vmovaps xmm14, [rsp+0xD0]
00007c47757e0607  vmovaps xmm15, [rsp+0xE0]
00007c47757e0610  add rsp, 0xF0
00007c47757e0617  pop r11
00007c47757e0619  pop r10
00007c47757e061b  pop r9
00007c47757e061d  pop r8
00007c47757e061f  pop rsi
00007c47757e0620  pop rdi
00007c47757e0621  pop rdx
00007c47757e0622  pop rcx
00007c47757e0623  pop rax
00007c47757e0624  add rsp, 0x08
00007c47757e0628  jmp 0x00007C47757DC5F4
00007c47757e062d  sub rsp, 0x08
00007c47757e0631  push rax
00007c47757e0632  push rcx
00007c47757e0633  push rdx
00007c47757e0634  push rdi
00007c47757e0635  push rsi
00007c47757e0636  push r8
00007c47757e0638  push r9
00007c47757e063a  push r10
00007c47757e063c  push r11
00007c47757e063e  sub rsp, 0xF0
00007c47757e0645  vmovaps [rsp], xmm0
00007c47757e064a  vmovaps [rsp+0x10], xmm1
00007c47757e0650  vmovaps [rsp+0x20], xmm2
00007c47757e0656  vmovaps [rsp+0x30], xmm3
00007c47757e065c  vmovaps [rsp+0x40], xmm4
00007c47757e0662  vmovaps [rsp+0x50], xmm5
00007c47757e0668  vmovaps [rsp+0x60], xmm6
00007c47757e066e  vmovaps [rsp+0x70], xmm7
00007c47757e0674  vmovaps [rsp+0x80], xmm8
00007c47757e067d  vmovaps [rsp+0x90], xmm9
00007c47757e0686  vmovaps [rsp+0xA0], xmm10
00007c47757e068f  vmovaps [rsp+0xB0], xmm11
00007c47757e0698  vmovaps [rsp+0xC0], xmm12
00007c47757e06a1  vmovaps [rsp+0xD0], xmm14
00007c47757e06aa  vmovaps [rsp+0xE0], xmm15
00007c47757e06b3  sub rsp, 0x30
00007c47757e06b7  movaps [rsp], xmm13
00007c47757e06bc  movaps [rsp+0x10], xmm15
00007c47757e06c2  movaps [rsp+0x20], xmm8
00007c47757e06c8  lea rdi, [rsp]
00007c47757e06cc  mov esi, 0x00
00007c47757e06d1  mov rax, 0x62084E409530
00007c47757e06db  call rax
00007c47757e06dd  movaps xmm13, [rsp]
00007c47757e06e2  add rsp, 0x30
00007c47757e06e6  vmovaps xmm0, [rsp]
00007c47757e06eb  vmovaps xmm1, [rsp+0x10]
00007c47757e06f1  vmovaps xmm2, [rsp+0x20]
00007c47757e06f7  vmovaps xmm3, [rsp+0x30]
00007c47757e06fd  vmovaps xmm4, [rsp+0x40]
00007c47757e0703  vmovaps xmm5, [rsp+0x50]
00007c47757e0709  vmovaps xmm6, [rsp+0x60]
00007c47757e070f  vmovaps xmm7, [rsp+0x70]
00007c47757e0715  vmovaps xmm8, [rsp+0x80]
00007c47757e071e  vmovaps xmm9, [rsp+0x90]
00007c47757e0727  vmovaps xmm10, [rsp+0xA0]
00007c47757e0730  vmovaps xmm11, [rsp+0xB0]
00007c47757e0739  vmovaps xmm12, [rsp+0xC0]
00007c47757e0742  vmovaps xmm14, [rsp+0xD0]
00007c47757e074b  vmovaps xmm15, [rsp+0xE0]
00007c47757e0754  add rsp, 0xF0
00007c47757e075b  pop r11
00007c47757e075d  pop r10
00007c47757e075f  pop r9
00007c47757e0761  pop r8
00007c47757e0763  pop rsi
00007c47757e0764  pop rdi
00007c47757e0765  pop rdx
00007c47757e0766  pop rcx
00007c47757e0767  pop rax
00007c47757e0768  add rsp, 0x08
00007c47757e076c  jmp 0x00007C47757DC60F
00007c47757e0771  sub rsp, 0x08
00007c47757e0775  push rax
00007c47757e0776  push rcx
00007c47757e0777  push rdx
00007c47757e0778  push rdi
00007c47757e0779  push rsi
00007c47757e077a  push r8
00007c47757e077c  push r9
00007c47757e077e  push r10
00007c47757e0780  push r11
00007c47757e0782  sub rsp, 0xF0
00007c47757e0789  vmovaps [rsp], xmm0
00007c47757e078e  vmovaps [rsp+0x10], xmm1
00007c47757e0794  vmovaps [rsp+0x20], xmm2
00007c47757e079a  vmovaps [rsp+0x30], xmm3
00007c47757e07a0  vmovaps [rsp+0x40], xmm4
00007c47757e07a6  vmovaps [rsp+0x50], xmm5
00007c47757e07ac  vmovaps [rsp+0x60], xmm6
00007c47757e07b2  vmovaps [rsp+0x70], xmm7
00007c47757e07b8  vmovaps [rsp+0x80], xmm9
00007c47757e07c1  vmovaps [rsp+0x90], xmm10
00007c47757e07ca  vmovaps [rsp+0xA0], xmm11
00007c47757e07d3  vmovaps [rsp+0xB0], xmm12
00007c47757e07dc  vmovaps [rsp+0xC0], xmm13
00007c47757e07e5  vmovaps [rsp+0xD0], xmm14
00007c47757e07ee  vmovaps [rsp+0xE0], xmm15
00007c47757e07f7  sub rsp, 0x30
00007c47757e07fb  movaps [rsp], xmm8
00007c47757e0800  movaps [rsp+0x10], xmm15
00007c47757e0806  movaps [rsp+0x20], xmm9
00007c47757e080c  lea rdi, [rsp]
00007c47757e0810  mov esi, 0x00
00007c47757e0815  mov rax, 0x62084E409530
00007c47757e081f  call rax
00007c47757e0821  movaps xmm8, [rsp]
00007c47757e0826  add rsp, 0x30
00007c47757e082a  vmovaps xmm0, [rsp]
00007c47757e082f  vmovaps xmm1, [rsp+0x10]
00007c47757e0835  vmovaps xmm2, [rsp+0x20]
00007c47757e083b  vmovaps xmm3, [rsp+0x30]
00007c47757e0841  vmovaps xmm4, [rsp+0x40]
00007c47757e0847  vmovaps xmm5, [rsp+0x50]
00007c47757e084d  vmovaps xmm6, [rsp+0x60]
00007c47757e0853  vmovaps xmm7, [rsp+0x70]
00007c47757e0859  vmovaps xmm9, [rsp+0x80]
00007c47757e0862  vmovaps xmm10, [rsp+0x90]
00007c47757e086b  vmovaps xmm11, [rsp+0xA0]
00007c47757e0874  vmovaps xmm12, [rsp+0xB0]
00007c47757e087d  vmovaps xmm13, [rsp+0xC0]
00007c47757e0886  vmovaps xmm14, [rsp+0xD0]
00007c47757e088f  vmovaps xmm15, [rsp+0xE0]
00007c47757e0898  add rsp, 0xF0
00007c47757e089f  pop r11
00007c47757e08a1  pop r10
00007c47757e08a3  pop r9
00007c47757e08a5  pop r8
00007c47757e08a7  pop rsi
00007c47757e08a8  pop rdi
00007c47757e08a9  pop rdx
00007c47757e08aa  pop rcx
00007c47757e08ab  pop rax
00007c47757e08ac  add rsp, 0x08
00007c47757e08b0  jmp 0x00007C47757DC63D
00007c47757e08b5  sub rsp, 0x08
00007c47757e08b9  push rax
00007c47757e08ba  push rcx
00007c47757e08bb  push rdx
00007c47757e08bc  push rdi
00007c47757e08bd  push rsi
00007c47757e08be  push r8
00007c47757e08c0  push r9
00007c47757e08c2  push r10
00007c47757e08c4  push r11
00007c47757e08c6  sub rsp, 0xF0
00007c47757e08cd  vmovaps [rsp], xmm0
00007c47757e08d2  vmovaps [rsp+0x10], xmm1
00007c47757e08d8  vmovaps [rsp+0x20], xmm2
00007c47757e08de  vmovaps [rsp+0x30], xmm3
00007c47757e08e4  vmovaps [rsp+0x40], xmm4
00007c47757e08ea  vmovaps [rsp+0x50], xmm5
00007c47757e08f0  vmovaps [rsp+0x60], xmm6
00007c47757e08f6  vmovaps [rsp+0x70], xmm7
00007c47757e08fc  vmovaps [rsp+0x80], xmm8
00007c47757e0905  vmovaps [rsp+0x90], xmm9
00007c47757e090e  vmovaps [rsp+0xA0], xmm10
00007c47757e0917  vmovaps [rsp+0xB0], xmm11
00007c47757e0920  vmovaps [rsp+0xC0], xmm12
00007c47757e0929  vmovaps [rsp+0xD0], xmm13
00007c47757e0932  vmovaps [rsp+0xE0], xmm14
00007c47757e093b  sub rsp, 0x30
00007c47757e093f  movaps [rsp], xmm15
00007c47757e0944  movaps [rsp+0x10], xmm11
00007c47757e094a  movaps [rsp+0x20], xmm6
00007c47757e094f  lea rdi, [rsp]
00007c47757e0953  mov esi, 0x00
00007c47757e0958  mov rax, 0x62084E409530
00007c47757e0962  call rax
00007c47757e0964  movaps xmm15, [rsp]
00007c47757e0969  add rsp, 0x30
00007c47757e096d  vmovaps xmm0, [rsp]
00007c47757e0972  vmovaps xmm1, [rsp+0x10]
00007c47757e0978  vmovaps xmm2, [rsp+0x20]
00007c47757e097e  vmovaps xmm3, [rsp+0x30]
00007c47757e0984  vmovaps xmm4, [rsp+0x40]
00007c47757e098a  vmovaps xmm5, [rsp+0x50]
00007c47757e0990  vmovaps xmm6, [rsp+0x60]
00007c47757e0996  vmovaps xmm7, [rsp+0x70]
00007c47757e099c  vmovaps xmm8, [rsp+0x80]
00007c47757e09a5  vmovaps xmm9, [rsp+0x90]
00007c47757e09ae  vmovaps xmm10, [rsp+0xA0]
00007c47757e09b7  vmovaps xmm11, [rsp+0xB0]
00007c47757e09c0  vmovaps xmm12, [rsp+0xC0]
00007c47757e09c9  vmovaps xmm13, [rsp+0xD0]
00007c47757e09d2  vmovaps xmm14, [rsp+0xE0]
00007c47757e09db  add rsp, 0xF0
00007c47757e09e2  pop r11
00007c47757e09e4  pop r10
00007c47757e09e6  pop r9
00007c47757e09e8  pop r8
00007c47757e09ea  pop rsi
00007c47757e09eb  pop rdi
00007c47757e09ec  pop rdx
00007c47757e09ed  pop rcx
00007c47757e09ee  pop rax
00007c47757e09ef  add rsp, 0x08
00007c47757e09f3  jmp 0x00007C47757DC658
00007c47757e09f8  sub rsp, 0x08
00007c47757e09fc  push rax
00007c47757e09fd  push rcx
00007c47757e09fe  push rdx
00007c47757e09ff  push rdi
00007c47757e0a00  push rsi
00007c47757e0a01  push r8
00007c47757e0a03  push r9
00007c47757e0a05  push r10
00007c47757e0a07  push r11
00007c47757e0a09  sub rsp, 0xF0
00007c47757e0a10  vmovaps [rsp], xmm0
00007c47757e0a15  vmovaps [rsp+0x10], xmm1
00007c47757e0a1b  vmovaps [rsp+0x20], xmm2
00007c47757e0a21  vmovaps [rsp+0x30], xmm3
00007c47757e0a27  vmovaps [rsp+0x40], xmm4
00007c47757e0a2d  vmovaps [rsp+0x50], xmm5
00007c47757e0a33  vmovaps [rsp+0x60], xmm6
00007c47757e0a39  vmovaps [rsp+0x70], xmm8
00007c47757e0a3f  vmovaps [rsp+0x80], xmm9
00007c47757e0a48  vmovaps [rsp+0x90], xmm10
00007c47757e0a51  vmovaps [rsp+0xA0], xmm11
00007c47757e0a5a  vmovaps [rsp+0xB0], xmm12
00007c47757e0a63  vmovaps [rsp+0xC0], xmm13
00007c47757e0a6c  vmovaps [rsp+0xD0], xmm14
00007c47757e0a75  vmovaps [rsp+0xE0], xmm15
00007c47757e0a7e  sub rsp, 0x30
00007c47757e0a82  movaps [rsp], xmm7
00007c47757e0a86  movaps [rsp+0x10], xmm11
00007c47757e0a8c  movaps [rsp+0x20], xmm9
00007c47757e0a92  lea rdi, [rsp]
00007c47757e0a96  mov esi, 0x00
00007c47757e0a9b  mov rax, 0x62084E409530
00007c47757e0aa5  call rax
00007c47757e0aa7  movaps xmm7, [rsp]
00007c47757e0aab  add rsp, 0x30
00007c47757e0aaf  vmovaps xmm0, [rsp]
00007c47757e0ab4  vmovaps xmm1, [rsp+0x10]
00007c47757e0aba  vmovaps xmm2, [rsp+0x20]
00007c47757e0ac0  vmovaps xmm3, [rsp+0x30]
00007c47757e0ac6  vmovaps xmm4, [rsp+0x40]
00007c47757e0acc  vmovaps xmm5, [rsp+0x50]
00007c47757e0ad2  vmovaps xmm6, [rsp+0x60]
00007c47757e0ad8  vmovaps xmm8, [rsp+0x70]
00007c47757e0ade  vmovaps xmm9, [rsp+0x80]
00007c47757e0ae7  vmovaps xmm10, [rsp+0x90]
00007c47757e0af0  vmovaps xmm11, [rsp+0xA0]
00007c47757e0af9  vmovaps xmm12, [rsp+0xB0]
00007c47757e0b02  vmovaps xmm13, [rsp+0xC0]
00007c47757e0b0b  vmovaps xmm14, [rsp+0xD0]
00007c47757e0b14  vmovaps xmm15, [rsp+0xE0]
00007c47757e0b1d  add rsp, 0xF0
00007c47757e0b24  pop r11
00007c47757e0b26  pop r10
00007c47757e0b28  pop r9
00007c47757e0b2a  pop r8
00007c47757e0b2c  pop rsi
00007c47757e0b2d  pop rdi
00007c47757e0b2e  pop rdx
00007c47757e0b2f  pop rcx
00007c47757e0b30  pop rax
00007c47757e0b31  add rsp, 0x08
00007c47757e0b35  jmp 0x00007C47757DC685
00007c47757e0b3a  sub rsp, 0x08
00007c47757e0b3e  push rax
00007c47757e0b3f  push rcx
00007c47757e0b40  push rdx
00007c47757e0b41  push rdi
00007c47757e0b42  push rsi
00007c47757e0b43  push r8
00007c47757e0b45  push r9
00007c47757e0b47  push r10
00007c47757e0b49  push r11
00007c47757e0b4b  sub rsp, 0xF0
00007c47757e0b52  vmovaps [rsp], xmm0
00007c47757e0b57  vmovaps [rsp+0x10], xmm1
00007c47757e0b5d  vmovaps [rsp+0x20], xmm2
00007c47757e0b63  vmovaps [rsp+0x30], xmm3
00007c47757e0b69  vmovaps [rsp+0x40], xmm4
00007c47757e0b6f  vmovaps [rsp+0x50], xmm5
00007c47757e0b75  vmovaps [rsp+0x60], xmm6
00007c47757e0b7b  vmovaps [rsp+0x70], xmm7
00007c47757e0b81  vmovaps [rsp+0x80], xmm8
00007c47757e0b8a  vmovaps [rsp+0x90], xmm9
00007c47757e0b93  vmovaps [rsp+0xA0], xmm10
00007c47757e0b9c  vmovaps [rsp+0xB0], xmm12
00007c47757e0ba5  vmovaps [rsp+0xC0], xmm13
00007c47757e0bae  vmovaps [rsp+0xD0], xmm14
00007c47757e0bb7  vmovaps [rsp+0xE0], xmm15
00007c47757e0bc0  sub rsp, 0x30
00007c47757e0bc4  movaps [rsp], xmm11
00007c47757e0bc9  movaps [rsp+0x10], xmm10
00007c47757e0bcf  movaps [rsp+0x20], xmm14
00007c47757e0bd5  lea rdi, [rsp]
00007c47757e0bd9  mov esi, 0x00
00007c47757e0bde  mov rax, 0x62084E409530
00007c47757e0be8  call rax
00007c47757e0bea  movaps xmm11, [rsp]
00007c47757e0bef  add rsp, 0x30
00007c47757e0bf3  vmovaps xmm0, [rsp]
00007c47757e0bf8  vmovaps xmm1, [rsp+0x10]
00007c47757e0bfe  vmovaps xmm2, [rsp+0x20]
00007c47757e0c04  vmovaps xmm3, [rsp+0x30]
00007c47757e0c0a  vmovaps xmm4, [rsp+0x40]
00007c47757e0c10  vmovaps xmm5, [rsp+0x50]
00007c47757e0c16  vmovaps xmm6, [rsp+0x60]
00007c47757e0c1c  vmovaps xmm7, [rsp+0x70]
00007c47757e0c22  vmovaps xmm8, [rsp+0x80]
00007c47757e0c2b  vmovaps xmm9, [rsp+0x90]
00007c47757e0c34  vmovaps xmm10, [rsp+0xA0]
00007c47757e0c3d  vmovaps xmm12, [rsp+0xB0]
00007c47757e0c46  vmovaps xmm13, [rsp+0xC0]
00007c47757e0c4f  vmovaps xmm14, [rsp+0xD0]
00007c47757e0c58  vmovaps xmm15, [rsp+0xE0]
00007c47757e0c61  add rsp, 0xF0
00007c47757e0c68  pop r11
00007c47757e0c6a  pop r10
00007c47757e0c6c  pop r9
00007c47757e0c6e  pop r8
00007c47757e0c70  pop rsi
00007c47757e0c71  pop rdi
00007c47757e0c72  pop rdx
00007c47757e0c73  pop rcx
00007c47757e0c74  pop rax
00007c47757e0c75  add rsp, 0x08
00007c47757e0c79  jmp 0x00007C47757DC6A0
00007c47757e0c7e  call 0x00007C47756C33A0
00007c47757e0c83  jmp 0x00007C47757DC6AA
00007c47757e0c88  sub rsp, 0x08
00007c47757e0c8c  push rax
00007c47757e0c8d  push rcx
00007c47757e0c8e  push rdx
00007c47757e0c8f  push rdi
00007c47757e0c90  push rsi
00007c47757e0c91  push r8
00007c47757e0c93  push r9
00007c47757e0c95  push r10
00007c47757e0c97  push r11
00007c47757e0c99  sub rsp, 0xF0
00007c47757e0ca0  vmovaps [rsp], xmm0
00007c47757e0ca5  vmovaps [rsp+0x10], xmm1
00007c47757e0cab  vmovaps [rsp+0x20], xmm2
00007c47757e0cb1  vmovaps [rsp+0x30], xmm3
00007c47757e0cb7  vmovaps [rsp+0x40], xmm4
00007c47757e0cbd  vmovaps [rsp+0x50], xmm5
00007c47757e0cc3  vmovaps [rsp+0x60], xmm6
00007c47757e0cc9  vmovaps [rsp+0x70], xmm7
00007c47757e0ccf  vmovaps [rsp+0x80], xmm8
00007c47757e0cd8  vmovaps [rsp+0x90], xmm9
00007c47757e0ce1  vmovaps [rsp+0xA0], xmm11
00007c47757e0cea  vmovaps [rsp+0xB0], xmm12
00007c47757e0cf3  vmovaps [rsp+0xC0], xmm13
00007c47757e0cfc  vmovaps [rsp+0xD0], xmm14
00007c47757e0d05  vmovaps [rsp+0xE0], xmm15
00007c47757e0d0e  sub rsp, 0x30
00007c47757e0d12  movaps [rsp], xmm10
00007c47757e0d17  movaps [rsp+0x10], xmm1
00007c47757e0d1c  movaps [rsp+0x20], xmm12
00007c47757e0d22  lea rdi, [rsp]
00007c47757e0d26  mov esi, 0x00
00007c47757e0d2b  mov rax, 0x62084E409530
00007c47757e0d35  call rax
00007c47757e0d37  movaps xmm10, [rsp]
00007c47757e0d3c  add rsp, 0x30
00007c47757e0d40  vmovaps xmm0, [rsp]
00007c47757e0d45  vmovaps xmm1, [rsp+0x10]
00007c47757e0d4b  vmovaps xmm2, [rsp+0x20]
00007c47757e0d51  vmovaps xmm3, [rsp+0x30]
00007c47757e0d57  vmovaps xmm4, [rsp+0x40]
00007c47757e0d5d  vmovaps xmm5, [rsp+0x50]
00007c47757e0d63  vmovaps xmm6, [rsp+0x60]
00007c47757e0d69  vmovaps xmm7, [rsp+0x70]
00007c47757e0d6f  vmovaps xmm8, [rsp+0x80]
00007c47757e0d78  vmovaps xmm9, [rsp+0x90]
00007c47757e0d81  vmovaps xmm11, [rsp+0xA0]
00007c47757e0d8a  vmovaps xmm12, [rsp+0xB0]
00007c47757e0d93  vmovaps xmm13, [rsp+0xC0]
00007c47757e0d9c  vmovaps xmm14, [rsp+0xD0]
00007c47757e0da5  vmovaps xmm15, [rsp+0xE0]
00007c47757e0dae  add rsp, 0xF0
00007c47757e0db5  pop r11
00007c47757e0db7  pop r10
00007c47757e0db9  pop r9
00007c47757e0dbb  pop r8
00007c47757e0dbd  pop rsi
00007c47757e0dbe  pop rdi
00007c47757e0dbf  pop rdx
00007c47757e0dc0  pop rcx
00007c47757e0dc1  pop rax
00007c47757e0dc2  add rsp, 0x08
00007c47757e0dc6  jmp 0x00007C47757DC6CD
00007c47757e0dcb  sub rsp, 0x08
00007c47757e0dcf  push rax
00007c47757e0dd0  push rcx
00007c47757e0dd1  push rdx
00007c47757e0dd2  push rdi
00007c47757e0dd3  push rsi
00007c47757e0dd4  push r8
00007c47757e0dd6  push r9
00007c47757e0dd8  push r10
00007c47757e0dda  push r11
00007c47757e0ddc  sub rsp, 0xF0
00007c47757e0de3  vmovaps [rsp], xmm0
00007c47757e0de8  vmovaps [rsp+0x10], xmm1
00007c47757e0dee  vmovaps [rsp+0x20], xmm2
00007c47757e0df4  vmovaps [rsp+0x30], xmm3
00007c47757e0dfa  vmovaps [rsp+0x40], xmm4
00007c47757e0e00  vmovaps [rsp+0x50], xmm5
00007c47757e0e06  vmovaps [rsp+0x60], xmm6
00007c47757e0e0c  vmovaps [rsp+0x70], xmm7
00007c47757e0e12  vmovaps [rsp+0x80], xmm8
00007c47757e0e1b  vmovaps [rsp+0x90], xmm9
00007c47757e0e24  vmovaps [rsp+0xA0], xmm10
00007c47757e0e2d  vmovaps [rsp+0xB0], xmm11
00007c47757e0e36  vmovaps [rsp+0xC0], xmm13
00007c47757e0e3f  vmovaps [rsp+0xD0], xmm14
00007c47757e0e48  vmovaps [rsp+0xE0], xmm15
00007c47757e0e51  sub rsp, 0x30
00007c47757e0e55  movaps [rsp], xmm12
00007c47757e0e5a  movaps [rsp+0x10], xmm14
00007c47757e0e60  movaps [rsp+0x20], xmm1
00007c47757e0e65  lea rdi, [rsp]
00007c47757e0e69  mov esi, 0x00
00007c47757e0e6e  mov rax, 0x62084E409530
00007c47757e0e78  call rax
00007c47757e0e7a  movaps xmm12, [rsp]
00007c47757e0e7f  add rsp, 0x30
00007c47757e0e83  vmovaps xmm0, [rsp]
00007c47757e0e88  vmovaps xmm1, [rsp+0x10]
00007c47757e0e8e  vmovaps xmm2, [rsp+0x20]
00007c47757e0e94  vmovaps xmm3, [rsp+0x30]
00007c47757e0e9a  vmovaps xmm4, [rsp+0x40]
00007c47757e0ea0  vmovaps xmm5, [rsp+0x50]
00007c47757e0ea6  vmovaps xmm6, [rsp+0x60]
00007c47757e0eac  vmovaps xmm7, [rsp+0x70]
00007c47757e0eb2  vmovaps xmm8, [rsp+0x80]
00007c47757e0ebb  vmovaps xmm9, [rsp+0x90]
00007c47757e0ec4  vmovaps xmm10, [rsp+0xA0]
00007c47757e0ecd  vmovaps xmm11, [rsp+0xB0]
00007c47757e0ed6  vmovaps xmm13, [rsp+0xC0]
00007c47757e0edf  vmovaps xmm14, [rsp+0xD0]
00007c47757e0ee8  vmovaps xmm15, [rsp+0xE0]
00007c47757e0ef1  add rsp, 0xF0
00007c47757e0ef8  pop r11
00007c47757e0efa  pop r10
00007c47757e0efc  pop r9
00007c47757e0efe  pop r8
00007c47757e0f00  pop rsi
00007c47757e0f01  pop rdi
00007c47757e0f02  pop rdx
00007c47757e0f03  pop rcx
00007c47757e0f04  pop rax
00007c47757e0f05  add rsp, 0x08
00007c47757e0f09  jmp 0x00007C47757DC6FC
00007c47757e0f0e  sub rsp, 0x08
00007c47757e0f12  push rax
00007c47757e0f13  push rcx
00007c47757e0f14  push rdx
00007c47757e0f15  push rdi
00007c47757e0f16  push rsi
00007c47757e0f17  push r8
00007c47757e0f19  push r9
00007c47757e0f1b  push r10
00007c47757e0f1d  push r11
00007c47757e0f1f  sub rsp, 0xF0
00007c47757e0f26  vmovaps [rsp], xmm0
00007c47757e0f2b  vmovaps [rsp+0x10], xmm1
00007c47757e0f31  vmovaps [rsp+0x20], xmm2
00007c47757e0f37  vmovaps [rsp+0x30], xmm3
00007c47757e0f3d  vmovaps [rsp+0x40], xmm4
00007c47757e0f43  vmovaps [rsp+0x50], xmm5
00007c47757e0f49  vmovaps [rsp+0x60], xmm6
00007c47757e0f4f  vmovaps [rsp+0x70], xmm7
00007c47757e0f55  vmovaps [rsp+0x80], xmm8
00007c47757e0f5e  vmovaps [rsp+0x90], xmm9
00007c47757e0f67  vmovaps [rsp+0xA0], xmm10
00007c47757e0f70  vmovaps [rsp+0xB0], xmm11
00007c47757e0f79  vmovaps [rsp+0xC0], xmm12
00007c47757e0f82  vmovaps [rsp+0xD0], xmm13
00007c47757e0f8b  vmovaps [rsp+0xE0], xmm15
00007c47757e0f94  sub rsp, 0x30
00007c47757e0f98  movaps [rsp], xmm14
00007c47757e0f9d  movaps [rsp+0x10], xmm9
00007c47757e0fa3  movaps [rsp+0x20], xmm1
00007c47757e0fa8  lea rdi, [rsp]
00007c47757e0fac  mov esi, 0x00
00007c47757e0fb1  mov rax, 0x62084E409530
00007c47757e0fbb  call rax
00007c47757e0fbd  movaps xmm14, [rsp]
00007c47757e0fc2  add rsp, 0x30
00007c47757e0fc6  vmovaps xmm0, [rsp]
00007c47757e0fcb  vmovaps xmm1, [rsp+0x10]
00007c47757e0fd1  vmovaps xmm2, [rsp+0x20]
00007c47757e0fd7  vmovaps xmm3, [rsp+0x30]
00007c47757e0fdd  vmovaps xmm4, [rsp+0x40]
00007c47757e0fe3  vmovaps xmm5, [rsp+0x50]
00007c47757e0fe9  vmovaps xmm6, [rsp+0x60]
00007c47757e0fef  vmovaps xmm7, [rsp+0x70]
00007c47757e0ff5  vmovaps xmm8, [rsp+0x80]
00007c47757e0ffe  vmovaps xmm9, [rsp+0x90]
00007c47757e1007  vmovaps xmm10, [rsp+0xA0]
00007c47757e1010  vmovaps xmm11, [rsp+0xB0]
00007c47757e1019  vmovaps xmm12, [rsp+0xC0]
00007c47757e1022  vmovaps xmm13, [rsp+0xD0]
00007c47757e102b  vmovaps xmm15, [rsp+0xE0]
00007c47757e1034  add rsp, 0xF0
00007c47757e103b  pop r11
00007c47757e103d  pop r10
00007c47757e103f  pop r9
00007c47757e1041  pop r8
00007c47757e1043  pop rsi
00007c47757e1044  pop rdi
00007c47757e1045  pop rdx
00007c47757e1046  pop rcx
00007c47757e1047  pop rax
00007c47757e1048  add rsp, 0x08
00007c47757e104c  jmp 0x00007C47757DC72B
00007c47757e1051  sub rsp, 0x08
00007c47757e1055  push rax
00007c47757e1056  push rcx
00007c47757e1057  push rdx
00007c47757e1058  push rdi
00007c47757e1059  push rsi
00007c47757e105a  push r8
00007c47757e105c  push r9
00007c47757e105e  push r10
00007c47757e1060  push r11
00007c47757e1062  sub rsp, 0xF0
00007c47757e1069  vmovaps [rsp], xmm0
00007c47757e106e  vmovaps [rsp+0x10], xmm2
00007c47757e1074  vmovaps [rsp+0x20], xmm3
00007c47757e107a  vmovaps [rsp+0x30], xmm4
00007c47757e1080  vmovaps [rsp+0x40], xmm5
00007c47757e1086  vmovaps [rsp+0x50], xmm6
00007c47757e108c  vmovaps [rsp+0x60], xmm7
00007c47757e1092  vmovaps [rsp+0x70], xmm8
00007c47757e1098  vmovaps [rsp+0x80], xmm9
00007c47757e10a1  vmovaps [rsp+0x90], xmm10
00007c47757e10aa  vmovaps [rsp+0xA0], xmm11
00007c47757e10b3  vmovaps [rsp+0xB0], xmm12
00007c47757e10bc  vmovaps [rsp+0xC0], xmm13
00007c47757e10c5  vmovaps [rsp+0xD0], xmm14
00007c47757e10ce  vmovaps [rsp+0xE0], xmm15
00007c47757e10d7  sub rsp, 0x30
00007c47757e10db  movaps [rsp], xmm1
00007c47757e10df  movaps [rsp+0x10], xmm13
00007c47757e10e5  movaps [rsp+0x20], xmm8
00007c47757e10eb  lea rdi, [rsp]
00007c47757e10ef  mov esi, 0x00
00007c47757e10f4  mov rax, 0x62084E409530
00007c47757e10fe  call rax
00007c47757e1100  movaps xmm1, [rsp]
00007c47757e1104  add rsp, 0x30
00007c47757e1108  vmovaps xmm0, [rsp]
00007c47757e110d  vmovaps xmm2, [rsp+0x10]
00007c47757e1113  vmovaps xmm3, [rsp+0x20]
00007c47757e1119  vmovaps xmm4, [rsp+0x30]
00007c47757e111f  vmovaps xmm5, [rsp+0x40]
00007c47757e1125  vmovaps xmm6, [rsp+0x50]
00007c47757e112b  vmovaps xmm7, [rsp+0x60]
00007c47757e1131  vmovaps xmm8, [rsp+0x70]
00007c47757e1137  vmovaps xmm9, [rsp+0x80]
00007c47757e1140  vmovaps xmm10, [rsp+0x90]
00007c47757e1149  vmovaps xmm11, [rsp+0xA0]
00007c47757e1152  vmovaps xmm12, [rsp+0xB0]
00007c47757e115b  vmovaps xmm13, [rsp+0xC0]
00007c47757e1164  vmovaps xmm14, [rsp+0xD0]
00007c47757e116d  vmovaps xmm15, [rsp+0xE0]
00007c47757e1176  add rsp, 0xF0
00007c47757e117d  pop r11
00007c47757e117f  pop r10
00007c47757e1181  pop r9
00007c47757e1183  pop r8
00007c47757e1185  pop rsi
00007c47757e1186  pop rdi
00007c47757e1187  pop rdx
00007c47757e1188  pop rcx
00007c47757e1189  pop rax
00007c47757e118a  add rsp, 0x08
00007c47757e118e  jmp 0x00007C47757DC74D
00007c47757e1193  call 0x00007C477560C260
00007c47757e1198  jmp 0x00007C47757DC75B
00007c47757e119d  call 0x00007C47756BD750
00007c47757e11a2  jmp 0x00007C47757DC765
00007c47757e11a7  sub rsp, 0x08
00007c47757e11ab  push rax
00007c47757e11ac  push rcx
00007c47757e11ad  push rdx
00007c47757e11ae  push rdi
00007c47757e11af  push rsi
00007c47757e11b0  push r8
00007c47757e11b2  push r9
00007c47757e11b4  push r10
00007c47757e11b6  push r11
00007c47757e11b8  sub rsp, 0xF0
00007c47757e11bf  vmovaps [rsp], xmm0
00007c47757e11c4  vmovaps [rsp+0x10], xmm1
00007c47757e11ca  vmovaps [rsp+0x20], xmm2
00007c47757e11d0  vmovaps [rsp+0x30], xmm3
00007c47757e11d6  vmovaps [rsp+0x40], xmm4
00007c47757e11dc  vmovaps [rsp+0x50], xmm5
00007c47757e11e2  vmovaps [rsp+0x60], xmm6
00007c47757e11e8  vmovaps [rsp+0x70], xmm7
00007c47757e11ee  vmovaps [rsp+0x80], xmm9
00007c47757e11f7  vmovaps [rsp+0x90], xmm10
00007c47757e1200  vmovaps [rsp+0xA0], xmm11
00007c47757e1209  vmovaps [rsp+0xB0], xmm12
00007c47757e1212  vmovaps [rsp+0xC0], xmm13
00007c47757e121b  vmovaps [rsp+0xD0], xmm14
00007c47757e1224  vmovaps [rsp+0xE0], xmm15
00007c47757e122d  sub rsp, 0x30
00007c47757e1231  movaps [rsp], xmm8
00007c47757e1236  movaps [rsp+0x10], xmm15
00007c47757e123c  movaps [rsp+0x20], xmm7
00007c47757e1241  lea rdi, [rsp]
00007c47757e1245  mov esi, 0x00
00007c47757e124a  mov rax, 0x62084E409530
00007c47757e1254  call rax
00007c47757e1256  movaps xmm8, [rsp]
00007c47757e125b  add rsp, 0x30
00007c47757e125f  vmovaps xmm0, [rsp]
00007c47757e1264  vmovaps xmm1, [rsp+0x10]
00007c47757e126a  vmovaps xmm2, [rsp+0x20]
00007c47757e1270  vmovaps xmm3, [rsp+0x30]
00007c47757e1276  vmovaps xmm4, [rsp+0x40]
00007c47757e127c  vmovaps xmm5, [rsp+0x50]
00007c47757e1282  vmovaps xmm6, [rsp+0x60]
00007c47757e1288  vmovaps xmm7, [rsp+0x70]
00007c47757e128e  vmovaps xmm9, [rsp+0x80]
00007c47757e1297  vmovaps xmm10, [rsp+0x90]
00007c47757e12a0  vmovaps xmm11, [rsp+0xA0]
00007c47757e12a9  vmovaps xmm12, [rsp+0xB0]
00007c47757e12b2  vmovaps xmm13, [rsp+0xC0]
00007c47757e12bb  vmovaps xmm14, [rsp+0xD0]
00007c47757e12c4  vmovaps xmm15, [rsp+0xE0]
00007c47757e12cd  add rsp, 0xF0
00007c47757e12d4  pop r11
00007c47757e12d6  pop r10
00007c47757e12d8  pop r9
00007c47757e12da  pop r8
00007c47757e12dc  pop rsi
00007c47757e12dd  pop rdi
00007c47757e12de  pop rdx
00007c47757e12df  pop rcx
00007c47757e12e0  pop rax
00007c47757e12e1  add rsp, 0x08
00007c47757e12e5  jmp 0x00007C47757DC787
00007c47757e12ea  sub rsp, 0x08
00007c47757e12ee  push rax
00007c47757e12ef  push rcx
00007c47757e12f0  push rdx
00007c47757e12f1  push rdi
00007c47757e12f2  push rsi
00007c47757e12f3  push r8
00007c47757e12f5  push r9
00007c47757e12f7  push r10
00007c47757e12f9  push r11
00007c47757e12fb  sub rsp, 0xF0
00007c47757e1302  vmovaps [rsp], xmm0
00007c47757e1307  vmovaps [rsp+0x10], xmm1
00007c47757e130d  vmovaps [rsp+0x20], xmm2
00007c47757e1313  vmovaps [rsp+0x30], xmm3
00007c47757e1319  vmovaps [rsp+0x40], xmm4
00007c47757e131f  vmovaps [rsp+0x50], xmm5
00007c47757e1325  vmovaps [rsp+0x60], xmm6
00007c47757e132b  vmovaps [rsp+0x70], xmm8
00007c47757e1331  vmovaps [rsp+0x80], xmm9
00007c47757e133a  vmovaps [rsp+0x90], xmm10
00007c47757e1343  vmovaps [rsp+0xA0], xmm11
00007c47757e134c  vmovaps [rsp+0xB0], xmm12
00007c47757e1355  vmovaps [rsp+0xC0], xmm13
00007c47757e135e  vmovaps [rsp+0xD0], xmm14
00007c47757e1367  vmovaps [rsp+0xE0], xmm15
00007c47757e1370  sub rsp, 0x30
00007c47757e1374  movaps [rsp], xmm7
00007c47757e1378  movaps [rsp+0x10], xmm9
00007c47757e137e  movaps [rsp+0x20], xmm15
00007c47757e1384  lea rdi, [rsp]
00007c47757e1388  mov esi, 0x00
00007c47757e138d  mov rax, 0x62084E409530
00007c47757e1397  call rax
00007c47757e1399  movaps xmm7, [rsp]
00007c47757e139d  add rsp, 0x30
00007c47757e13a1  vmovaps xmm0, [rsp]
00007c47757e13a6  vmovaps xmm1, [rsp+0x10]
00007c47757e13ac  vmovaps xmm2, [rsp+0x20]
00007c47757e13b2  vmovaps xmm3, [rsp+0x30]
00007c47757e13b8  vmovaps xmm4, [rsp+0x40]
00007c47757e13be  vmovaps xmm5, [rsp+0x50]
00007c47757e13c4  vmovaps xmm6, [rsp+0x60]
00007c47757e13ca  vmovaps xmm8, [rsp+0x70]
00007c47757e13d0  vmovaps xmm9, [rsp+0x80]
00007c47757e13d9  vmovaps xmm10, [rsp+0x90]
00007c47757e13e2  vmovaps xmm11, [rsp+0xA0]
00007c47757e13eb  vmovaps xmm12, [rsp+0xB0]
00007c47757e13f4  vmovaps xmm13, [rsp+0xC0]
00007c47757e13fd  vmovaps xmm14, [rsp+0xD0]
00007c47757e1406  vmovaps xmm15, [rsp+0xE0]
00007c47757e140f  add rsp, 0xF0
00007c47757e1416  pop r11
00007c47757e1418  pop r10
00007c47757e141a  pop r9
00007c47757e141c  pop r8
00007c47757e141e  pop rsi
00007c47757e141f  pop rdi
00007c47757e1420  pop rdx
00007c47757e1421  pop rcx
00007c47757e1422  pop rax
00007c47757e1423  add rsp, 0x08
00007c47757e1427  jmp 0x00007C47757DC7B4
00007c47757e142c  sub rsp, 0x08
00007c47757e1430  push rax
00007c47757e1431  push rcx
00007c47757e1432  push rdx
00007c47757e1433  push rdi
00007c47757e1434  push rsi
00007c47757e1435  push r8
00007c47757e1437  push r9
00007c47757e1439  push r10
00007c47757e143b  push r11
00007c47757e143d  sub rsp, 0xF0
00007c47757e1444  vmovaps [rsp], xmm0
00007c47757e1449  vmovaps [rsp+0x10], xmm1
00007c47757e144f  vmovaps [rsp+0x20], xmm2
00007c47757e1455  vmovaps [rsp+0x30], xmm3
00007c47757e145b  vmovaps [rsp+0x40], xmm4
00007c47757e1461  vmovaps [rsp+0x50], xmm5
00007c47757e1467  vmovaps [rsp+0x60], xmm6
00007c47757e146d  vmovaps [rsp+0x70], xmm7
00007c47757e1473  vmovaps [rsp+0x80], xmm8
00007c47757e147c  vmovaps [rsp+0x90], xmm10
00007c47757e1485  vmovaps [rsp+0xA0], xmm11
00007c47757e148e  vmovaps [rsp+0xB0], xmm12
00007c47757e1497  vmovaps [rsp+0xC0], xmm13
00007c47757e14a0  vmovaps [rsp+0xD0], xmm14
00007c47757e14a9  vmovaps [rsp+0xE0], xmm15
00007c47757e14b2  sub rsp, 0x30
00007c47757e14b6  movaps [rsp], xmm9
00007c47757e14bb  movaps [rsp+0x10], xmm13
00007c47757e14c1  movaps [rsp+0x20], xmm15
00007c47757e14c7  lea rdi, [rsp]
00007c47757e14cb  mov esi, 0x00
00007c47757e14d0  mov rax, 0x62084E409530
00007c47757e14da  call rax
00007c47757e14dc  movaps xmm9, [rsp]
00007c47757e14e1  add rsp, 0x30
00007c47757e14e5  vmovaps xmm0, [rsp]
00007c47757e14ea  vmovaps xmm1, [rsp+0x10]
00007c47757e14f0  vmovaps xmm2, [rsp+0x20]
00007c47757e14f6  vmovaps xmm3, [rsp+0x30]
00007c47757e14fc  vmovaps xmm4, [rsp+0x40]
00007c47757e1502  vmovaps xmm5, [rsp+0x50]
00007c47757e1508  vmovaps xmm6, [rsp+0x60]
00007c47757e150e  vmovaps xmm7, [rsp+0x70]
00007c47757e1514  vmovaps xmm8, [rsp+0x80]
00007c47757e151d  vmovaps xmm10, [rsp+0x90]
00007c47757e1526  vmovaps xmm11, [rsp+0xA0]
00007c47757e152f  vmovaps xmm12, [rsp+0xB0]
00007c47757e1538  vmovaps xmm13, [rsp+0xC0]
00007c47757e1541  vmovaps xmm14, [rsp+0xD0]
00007c47757e154a  vmovaps xmm15, [rsp+0xE0]
00007c47757e1553  add rsp, 0xF0
00007c47757e155a  pop r11
00007c47757e155c  pop r10
00007c47757e155e  pop r9
00007c47757e1560  pop r8
00007c47757e1562  pop rsi
00007c47757e1563  pop rdi
00007c47757e1564  pop rdx
00007c47757e1565  pop rcx
00007c47757e1566  pop rax
00007c47757e1567  add rsp, 0x08
00007c47757e156b  jmp 0x00007C47757DC7E2
00007c47757e1570  sub rsp, 0x08
00007c47757e1574  push rax
00007c47757e1575  push rcx
00007c47757e1576  push rdx
00007c47757e1577  push rdi
00007c47757e1578  push rsi
00007c47757e1579  push r8
00007c47757e157b  push r9
00007c47757e157d  push r10
00007c47757e157f  push r11
00007c47757e1581  sub rsp, 0xF0
00007c47757e1588  vmovaps [rsp], xmm0
00007c47757e158d  vmovaps [rsp+0x10], xmm1
00007c47757e1593  vmovaps [rsp+0x20], xmm2
00007c47757e1599  vmovaps [rsp+0x30], xmm3
00007c47757e159f  vmovaps [rsp+0x40], xmm4
00007c47757e15a5  vmovaps [rsp+0x50], xmm5
00007c47757e15ab  vmovaps [rsp+0x60], xmm6
00007c47757e15b1  vmovaps [rsp+0x70], xmm7
00007c47757e15b7  vmovaps [rsp+0x80], xmm8
00007c47757e15c0  vmovaps [rsp+0x90], xmm9
00007c47757e15c9  vmovaps [rsp+0xA0], xmm10
00007c47757e15d2  vmovaps [rsp+0xB0], xmm11
00007c47757e15db  vmovaps [rsp+0xC0], xmm12
00007c47757e15e4  vmovaps [rsp+0xD0], xmm13
00007c47757e15ed  vmovaps [rsp+0xE0], xmm14
00007c47757e15f6  sub rsp, 0x30
00007c47757e15fa  movaps [rsp], xmm15
00007c47757e15ff  movaps [rsp+0x10], xmm11
00007c47757e1605  movaps [rsp+0x20], xmm12
00007c47757e160b  lea rdi, [rsp]
00007c47757e160f  mov esi, 0x00
00007c47757e1614  mov rax, 0x62084E409530
00007c47757e161e  call rax
00007c47757e1620  movaps xmm15, [rsp]
00007c47757e1625  add rsp, 0x30
00007c47757e1629  vmovaps xmm0, [rsp]
00007c47757e162e  vmovaps xmm1, [rsp+0x10]
00007c47757e1634  vmovaps xmm2, [rsp+0x20]
00007c47757e163a  vmovaps xmm3, [rsp+0x30]
00007c47757e1640  vmovaps xmm4, [rsp+0x40]
00007c47757e1646  vmovaps xmm5, [rsp+0x50]
00007c47757e164c  vmovaps xmm6, [rsp+0x60]
00007c47757e1652  vmovaps xmm7, [rsp+0x70]
00007c47757e1658  vmovaps xmm8, [rsp+0x80]
00007c47757e1661  vmovaps xmm9, [rsp+0x90]
00007c47757e166a  vmovaps xmm10, [rsp+0xA0]
00007c47757e1673  vmovaps xmm11, [rsp+0xB0]
00007c47757e167c  vmovaps xmm12, [rsp+0xC0]
00007c47757e1685  vmovaps xmm13, [rsp+0xD0]
00007c47757e168e  vmovaps xmm14, [rsp+0xE0]
00007c47757e1697  add rsp, 0xF0
00007c47757e169e  pop r11
00007c47757e16a0  pop r10
00007c47757e16a2  pop r9
00007c47757e16a4  pop r8
00007c47757e16a6  pop rsi
00007c47757e16a7  pop rdi
00007c47757e16a8  pop rdx
00007c47757e16a9  pop rcx
00007c47757e16aa  pop rax
00007c47757e16ab  add rsp, 0x08
00007c47757e16af  jmp 0x00007C47757DC7FD
00007c47757e16b4  sub rsp, 0x08
00007c47757e16b8  push rax
00007c47757e16b9  push rcx
00007c47757e16ba  push rdx
00007c47757e16bb  push rdi
00007c47757e16bc  push rsi
00007c47757e16bd  push r8
00007c47757e16bf  push r9
00007c47757e16c1  push r10
00007c47757e16c3  push r11
00007c47757e16c5  sub rsp, 0xF0
00007c47757e16cc  vmovaps [rsp], xmm0
00007c47757e16d1  vmovaps [rsp+0x10], xmm1
00007c47757e16d7  vmovaps [rsp+0x20], xmm2
00007c47757e16dd  vmovaps [rsp+0x30], xmm3
00007c47757e16e3  vmovaps [rsp+0x40], xmm4
00007c47757e16e9  vmovaps [rsp+0x50], xmm5
00007c47757e16ef  vmovaps [rsp+0x60], xmm6
00007c47757e16f5  vmovaps [rsp+0x70], xmm7
00007c47757e16fb  vmovaps [rsp+0x80], xmm8
00007c47757e1704  vmovaps [rsp+0x90], xmm9
00007c47757e170d  vmovaps [rsp+0xA0], xmm10
00007c47757e1716  vmovaps [rsp+0xB0], xmm11
00007c47757e171f  vmovaps [rsp+0xC0], xmm12
00007c47757e1728  vmovaps [rsp+0xD0], xmm14
00007c47757e1731  vmovaps [rsp+0xE0], xmm15
00007c47757e173a  sub rsp, 0x30
00007c47757e173e  movaps [rsp], xmm13
00007c47757e1743  movaps [rsp+0x10], xmm10
00007c47757e1749  movaps [rsp+0x20], xmm14
00007c47757e174f  lea rdi, [rsp]
00007c47757e1753  mov esi, 0x00
00007c47757e1758  mov rax, 0x62084E409530
00007c47757e1762  call rax
00007c47757e1764  movaps xmm13, [rsp]
00007c47757e1769  add rsp, 0x30
00007c47757e176d  vmovaps xmm0, [rsp]
00007c47757e1772  vmovaps xmm1, [rsp+0x10]
00007c47757e1778  vmovaps xmm2, [rsp+0x20]
00007c47757e177e  vmovaps xmm3, [rsp+0x30]
00007c47757e1784  vmovaps xmm4, [rsp+0x40]
00007c47757e178a  vmovaps xmm5, [rsp+0x50]
00007c47757e1790  vmovaps xmm6, [rsp+0x60]
00007c47757e1796  vmovaps xmm7, [rsp+0x70]
00007c47757e179c  vmovaps xmm8, [rsp+0x80]
00007c47757e17a5  vmovaps xmm9, [rsp+0x90]
00007c47757e17ae  vmovaps xmm10, [rsp+0xA0]
00007c47757e17b7  vmovaps xmm11, [rsp+0xB0]
00007c47757e17c0  vmovaps xmm12, [rsp+0xC0]
00007c47757e17c9  vmovaps xmm14, [rsp+0xD0]
00007c47757e17d2  vmovaps xmm15, [rsp+0xE0]
00007c47757e17db  add rsp, 0xF0
00007c47757e17e2  pop r11
00007c47757e17e4  pop r10
00007c47757e17e6  pop r9
00007c47757e17e8  pop r8
00007c47757e17ea  pop rsi
00007c47757e17eb  pop rdi
00007c47757e17ec  pop rdx
00007c47757e17ed  pop rcx
00007c47757e17ee  pop rax
00007c47757e17ef  add rsp, 0x08
00007c47757e17f3  jmp 0x00007C47757DC820
00007c47757e17f8  sub rsp, 0x08
00007c47757e17fc  push rax
00007c47757e17fd  push rcx
00007c47757e17fe  push rdx
00007c47757e17ff  push rdi
00007c47757e1800  push rsi
00007c47757e1801  push r8
00007c47757e1803  push r9
00007c47757e1805  push r10
00007c47757e1807  push r11
00007c47757e1809  sub rsp, 0xF0
00007c47757e1810  vmovaps [rsp], xmm0
00007c47757e1815  vmovaps [rsp+0x10], xmm1
00007c47757e181b  vmovaps [rsp+0x20], xmm2
00007c47757e1821  vmovaps [rsp+0x30], xmm3
00007c47757e1827  vmovaps [rsp+0x40], xmm4
00007c47757e182d  vmovaps [rsp+0x50], xmm5
00007c47757e1833  vmovaps [rsp+0x60], xmm6
00007c47757e1839  vmovaps [rsp+0x70], xmm7
00007c47757e183f  vmovaps [rsp+0x80], xmm8
00007c47757e1848  vmovaps [rsp+0x90], xmm9
00007c47757e1851  vmovaps [rsp+0xA0], xmm10
00007c47757e185a  vmovaps [rsp+0xB0], xmm11
00007c47757e1863  vmovaps [rsp+0xC0], xmm12
00007c47757e186c  vmovaps [rsp+0xD0], xmm13
00007c47757e1875  vmovaps [rsp+0xE0], xmm15
00007c47757e187e  sub rsp, 0x30
00007c47757e1882  movaps [rsp], xmm14
00007c47757e1887  movaps [rsp+0x10], xmm1
00007c47757e188c  movaps [rsp+0x20], xmm7
00007c47757e1891  lea rdi, [rsp]
00007c47757e1895  mov esi, 0x00
00007c47757e189a  mov rax, 0x62084E409530
00007c47757e18a4  call rax
00007c47757e18a6  movaps xmm14, [rsp]
00007c47757e18ab  add rsp, 0x30
00007c47757e18af  vmovaps xmm0, [rsp]
00007c47757e18b4  vmovaps xmm1, [rsp+0x10]
00007c47757e18ba  vmovaps xmm2, [rsp+0x20]
00007c47757e18c0  vmovaps xmm3, [rsp+0x30]
00007c47757e18c6  vmovaps xmm4, [rsp+0x40]
00007c47757e18cc  vmovaps xmm5, [rsp+0x50]
00007c47757e18d2  vmovaps xmm6, [rsp+0x60]
00007c47757e18d8  vmovaps xmm7, [rsp+0x70]
00007c47757e18de  vmovaps xmm8, [rsp+0x80]
00007c47757e18e7  vmovaps xmm9, [rsp+0x90]
00007c47757e18f0  vmovaps xmm10, [rsp+0xA0]
00007c47757e18f9  vmovaps xmm11, [rsp+0xB0]
00007c47757e1902  vmovaps xmm12, [rsp+0xC0]
00007c47757e190b  vmovaps xmm13, [rsp+0xD0]
00007c47757e1914  vmovaps xmm15, [rsp+0xE0]
00007c47757e191d  add rsp, 0xF0
00007c47757e1924  pop r11
00007c47757e1926  pop r10
00007c47757e1928  pop r9
00007c47757e192a  pop r8
00007c47757e192c  pop rsi
00007c47757e192d  pop rdi
00007c47757e192e  pop rdx
00007c47757e192f  pop rcx
00007c47757e1930  pop rax
00007c47757e1931  add rsp, 0x08
00007c47757e1935  jmp 0x00007C47757DC843
00007c47757e193a  sub rsp, 0x08
00007c47757e193e  push rax
00007c47757e193f  push rcx
00007c47757e1940  push rdx
00007c47757e1941  push rdi
00007c47757e1942  push rsi
00007c47757e1943  push r8
00007c47757e1945  push r9
00007c47757e1947  push r10
00007c47757e1949  push r11
00007c47757e194b  sub rsp, 0xF0
00007c47757e1952  vmovaps [rsp], xmm0
00007c47757e1957  vmovaps [rsp+0x10], xmm2
00007c47757e195d  vmovaps [rsp+0x20], xmm3
00007c47757e1963  vmovaps [rsp+0x30], xmm4
00007c47757e1969  vmovaps [rsp+0x40], xmm5
00007c47757e196f  vmovaps [rsp+0x50], xmm6
00007c47757e1975  vmovaps [rsp+0x60], xmm7
00007c47757e197b  vmovaps [rsp+0x70], xmm8
00007c47757e1981  vmovaps [rsp+0x80], xmm9
00007c47757e198a  vmovaps [rsp+0x90], xmm10
00007c47757e1993  vmovaps [rsp+0xA0], xmm11
00007c47757e199c  vmovaps [rsp+0xB0], xmm12
00007c47757e19a5  vmovaps [rsp+0xC0], xmm13
00007c47757e19ae  vmovaps [rsp+0xD0], xmm14
00007c47757e19b7  vmovaps [rsp+0xE0], xmm15
00007c47757e19c0  sub rsp, 0x30
00007c47757e19c4  movaps [rsp], xmm1
00007c47757e19c8  movaps [rsp+0x10], xmm8
00007c47757e19ce  movaps [rsp+0x20], xmm9
00007c47757e19d4  lea rdi, [rsp]
00007c47757e19d8  mov esi, 0x00
00007c47757e19dd  mov rax, 0x62084E409530
00007c47757e19e7  call rax
00007c47757e19e9  movaps xmm1, [rsp]
00007c47757e19ed  add rsp, 0x30
00007c47757e19f1  vmovaps xmm0, [rsp]
00007c47757e19f6  vmovaps xmm2, [rsp+0x10]
00007c47757e19fc  vmovaps xmm3, [rsp+0x20]
00007c47757e1a02  vmovaps xmm4, [rsp+0x30]
00007c47757e1a08  vmovaps xmm5, [rsp+0x40]
00007c47757e1a0e  vmovaps xmm6, [rsp+0x50]
00007c47757e1a14  vmovaps xmm7, [rsp+0x60]
00007c47757e1a1a  vmovaps xmm8, [rsp+0x70]
00007c47757e1a20  vmovaps xmm9, [rsp+0x80]
00007c47757e1a29  vmovaps xmm10, [rsp+0x90]
00007c47757e1a32  vmovaps xmm11, [rsp+0xA0]
00007c47757e1a3b  vmovaps xmm12, [rsp+0xB0]
00007c47757e1a44  vmovaps xmm13, [rsp+0xC0]
00007c47757e1a4d  vmovaps xmm14, [rsp+0xD0]
00007c47757e1a56  vmovaps xmm15, [rsp+0xE0]
00007c47757e1a5f  add rsp, 0xF0
00007c47757e1a66  pop r11
00007c47757e1a68  pop r10
00007c47757e1a6a  pop r9
00007c47757e1a6c  pop r8
00007c47757e1a6e  pop rsi
00007c47757e1a6f  pop rdi
00007c47757e1a70  pop rdx
00007c47757e1a71  pop rcx
00007c47757e1a72  pop rax
00007c47757e1a73  add rsp, 0x08
00007c47757e1a77  jmp 0x00007C47757DC865
00007c47757e1a7c  call 0x00007C47756E5940
00007c47757e1a81  jmp 0x00007C47757DC873
00007c47757e1a86  call 0x00007C477560C380
00007c47757e1a8b  jmp 0x00007C47757DC87D
00007c47757e1a90  call 0x00007C477560D600
00007c47757e1a95  jmp 0x00007C47757DC887
00007c47757e1a9a  call 0x00007C47755FF540
00007c47757e1a9f  jmp 0x00007C47757DC891
00007c47757e1aa4  int3
00007c47757e1aa5  nop [rax+rax*1], ax
00007c47757e1aae  nop
00007c47757e1ab0  mov rax, [r15+0xF8]
00007c47757e1ab7  lea r14, [rax+0x140]
00007c47757e1abe  mov r12, [r13+r14*1]
00007c47757e1ac3  mov [r15+0xE8], r12
00007c47757e1aca  lea r14, [rax+0x130]
00007c47757e1ad1  mov r12, [r13+r14*1]
00007c47757e1ad6  lea r14, [rax+0x138]
00007c47757e1add  mov r11, [r13+r14*1]
00007c47757e1ae2  movq xmm1, r12
00007c47757e1ae7  movq xmm15, r11
00007c47757e1aec  movq xmm1, xmm1
00007c47757e1af0  movq xmm1, xmm1
00007c47757e1af4  movaps [r15+0x1A0], xmm1
00007c47757e1afc  movq xmm15, xmm15
00007c47757e1b01  movq xmm15, xmm15
00007c47757e1b06  movaps [r15+0x190], xmm15
00007c47757e1b0e  lea r14, [rax+0x120]
00007c47757e1b15  mov r12, [r13+r14*1]
00007c47757e1b1a  lea r14, [rax+0x128]
00007c47757e1b21  mov r11, [r13+r14*1]
00007c47757e1b26  movq xmm1, r12
00007c47757e1b2b  movq xmm15, r11
00007c47757e1b30  movq xmm1, xmm1
00007c47757e1b34  movq xmm1, xmm1
00007c47757e1b38  movaps [r15+0x1C0], xmm1
00007c47757e1b40  movq xmm15, xmm15
00007c47757e1b45  movq xmm15, xmm15
00007c47757e1b4a  movaps [r15+0x1B0], xmm15
00007c47757e1b52  lea r14, [rax+0x110]
00007c47757e1b59  mov r12, [r13+r14*1]
00007c47757e1b5e  lea r14, [rax+0x118]
00007c47757e1b65  mov r11, [r13+r14*1]
00007c47757e1b6a  movq xmm1, r12
00007c47757e1b6f  movq xmm15, r11
00007c47757e1b74  movq xmm1, xmm1
00007c47757e1b78  movq xmm1, xmm1
00007c47757e1b7c  movaps [r15+0x1E0], xmm1
00007c47757e1b84  movq xmm15, xmm15
00007c47757e1b89  movq xmm15, xmm15
00007c47757e1b8e  movaps [r15+0x1D0], xmm15
00007c47757e1b96  lea r14, [rax+0x100]
00007c47757e1b9d  mov r12, [r13+r14*1]
00007c47757e1ba2  lea r14, [rax+0x108]
00007c47757e1ba9  mov r11, [r13+r14*1]
00007c47757e1bae  movq xmm1, r12
00007c47757e1bb3  movq xmm15, r11
00007c47757e1bb8  movq xmm1, xmm1
00007c47757e1bbc  movq xmm1, xmm1
00007c47757e1bc0  movaps [r15+0x200], xmm1
00007c47757e1bc8  movq xmm15, xmm15
00007c47757e1bcd  movq xmm15, xmm15
00007c47757e1bd2  movaps [r15+0x1F0], xmm15
00007c47757e1bda  mov qword ptr [r15+0x40], 0x430000
00007c47757e1be2  mov r14d, 0x430510
00007c47757e1be8  mov r12, [r13+r14*1]
00007c47757e1bed  movq xmm1, r12
00007c47757e1bf2  lea r14, [rax+0x150]
00007c47757e1bf9  mov [r15+0xF8], r14
00007c47757e1c00  mov rax, [r15+0x50]
00007c47757e1c04  movups xmm15, [r13+rax*1]
00007c47757e1c0a  movaps [r15+0x120], xmm15
00007c47757e1c12  mov qword ptr [r15+0x48], 0x10
00007c47757e1c1a  xor eax, eax
00007c47757e1c1c  mov r14d, 0x10
00007c47757e1c22  mov r12d, 0x200
00007c47757e1c28  cmp r14, r12
00007c47757e1c2b  cmc
00007c47757e1c2c  lahf
00007c47757e1c2d  seto al
00007c47757e1c30  mov [r15+0x108], eax
00007c47757e1c37  pextrq rax, xmm15, 0x01
00007c47757e1c3e  movq xmm14, rax
00007c47757e1c43  movaps [r15+0x130], xmm14
00007c47757e1c4b  movq rax, xmm1
00007c47757e1c50  movq r14, xmm15
00007c47757e1c55  vmovq xmm1, rax
00007c47757e1c5a  vmovq xmm15, r14
00007c47757e1c5f  movaps xmm13, xmm1
00007c47757e1c63  addsd xmm13, xmm15
00007c47757e1c68  ucomisd xmm13, xmm13
00007c47757e1c6d  jp 0x00007C47757E1D86
00007c47757e1c73  movq xmm13, xmm13
00007c47757e1c78  movq rax, xmm13
00007c47757e1c7d  movq r14, xmm14
00007c47757e1c82  vmovq xmm1, rax
00007c47757e1c87  vmovq xmm15, r14
00007c47757e1c8c  movaps xmm14, xmm1
00007c47757e1c90  addsd xmm14, xmm15
00007c47757e1c95  ucomisd xmm14, xmm14
00007c47757e1c9a  jp 0x00007C47757E1DCE
00007c47757e1ca0  movq xmm14, xmm14
00007c47757e1ca5  movaps [r15+0x110], xmm14
00007c47757e1cad  mov eax, [r15+0x108]
00007c47757e1cb4  sahf
00007c47757e1cb5  jnz 0x00007C47757E1CE7
00007c47757e1cb7  cmp dword ptr [r15+0x318], 0x00
00007c47757e1cbf  jz 0x00007C47757E1FE0
00007c47757e1cc5  nop [rax+rax*1], ax
00007c47757e1cce  nop [rax+rax*1], eax
00007c47757e1cd6  mov eax, 0x410490
00007c47757e1cdb  mov [r15+0x100], rax
00007c47757e1ce2  jmp 0x00007C47755FE110
00007c47757e1ce7  cmp dword ptr [r15+0x318], 0x00
00007c47757e1cef  jz 0x00007C47757E1E20
00007c47757e1cf5  nop [rax+rax*1], ax
00007c47757e1cfe  nop [rax+rax*1], eax
00007c47757e1d06  mov eax, 0x410474
00007c47757e1d0b  mov [r15+0x100], rax
00007c47757e1d12  jmp 0x00007C47755FE110
00007c47757e1d17  int3
00007c47757e1d18  call 0x00007C47756E27E0
00007c47757e1d1d  jmp 0x00007C47757E1AC3
00007c47757e1d22  call 0x00007C47756E27E0
00007c47757e1d27  jmp 0x00007C47757E1AD6
00007c47757e1d2c  call 0x00007C47756E1570
00007c47757e1d31  jmp 0x00007C47757E1AE2
00007c47757e1d36  call 0x00007C47756E27E0
00007c47757e1d3b  jmp 0x00007C47757E1B1A
00007c47757e1d40  call 0x00007C47756E1570
00007c47757e1d45  jmp 0x00007C47757E1B26
00007c47757e1d4a  call 0x00007C47756E27E0
00007c47757e1d4f  jmp 0x00007C47757E1B5E
00007c47757e1d54  call 0x00007C47756E1570
00007c47757e1d59  jmp 0x00007C47757E1B6A
00007c47757e1d5e  call 0x00007C47756E27E0
00007c47757e1d63  jmp 0x00007C47757E1BA2
00007c47757e1d68  call 0x00007C47756E1570
00007c47757e1d6d  jmp 0x00007C47757E1BAE
00007c47757e1d72  call 0x00007C47756E27E0
00007c47757e1d77  jmp 0x00007C47757E1BED
00007c47757e1d7c  call 0x00007C477560E760
00007c47757e1d81  jmp 0x00007C47757E1C0A
00007c47757e1d86  ucomisd xmm1, xmm15
00007c47757e1d8b  jp 0x00007C47757E1D9A
00007c47757e1d8d  movaps xmm13, [0x00007C47753FE060]
00007c47757e1d95  jmp 0x00007C47757E1C73
00007c47757e1d9a  vxorps xmm0, xmm1, xmm15
00007c47757e1d9f  pextrw eax, xmm0, 0x03
00007c47757e1da4  and eax, 0x7FF8
00007c47757e1da9  cmp eax, 0x08
00007c47757e1dac  jnz 0x00007C47757E1C73
00007c47757e1db2  movq rax, xmm15
00007c47757e1db7  shl rax, 0x0D
00007c47757e1dbb  jbe 0x00007C47757E1C73
00007c47757e1dc1  vorps xmm13, xmm15, [0x00007C47753FE070]
00007c47757e1dc9  jmp 0x00007C47757E1C73
00007c47757e1dce  ucomisd xmm1, xmm15
00007c47757e1dd3  jp 0x00007C47757E1DE2
00007c47757e1dd5  movaps xmm14, [0x00007C47753FE060]
00007c47757e1ddd  jmp 0x00007C47757E1CA0
00007c47757e1de2  vxorps xmm0, xmm1, xmm15
00007c47757e1de7  pextrw eax, xmm0, 0x03
00007c47757e1dec  and eax, 0x7FF8
00007c47757e1df1  cmp eax, 0x08
00007c47757e1df4  jnz 0x00007C47757E1CA0
00007c47757e1dfa  movq rax, xmm15
00007c47757e1dff  shl rax, 0x0D
00007c47757e1e03  jbe 0x00007C47757E1CA0
00007c47757e1e09  vorps xmm14, xmm15, [0x00007C47753FE070]
00007c47757e1e11  jmp 0x00007C47757E1CA0
00007c47757e1e16  int3
00007c47757e1e17  nop [rax+rax*1], ax
00007c47757e1e20  mov rax, [r15+0x48]
00007c47757e1e24  mov r14, [r15+0x50]
00007c47757e1e28  lea r12, [r14+rax*1]
00007c47757e1e2c  movups xmm1, [r13+r12*1]
00007c47757e1e32  movaps [r15+0x120], xmm1
00007c47757e1e3a  lea r14, [rax+0x10]
00007c47757e1e3e  mov [r15+0x48], r14
00007c47757e1e42  xor eax, eax
00007c47757e1e44  mov r12d, 0x200
00007c47757e1e4a  cmp r14, r12
00007c47757e1e4d  cmc
00007c47757e1e4e  lahf
00007c47757e1e4f  seto al
00007c47757e1e52  mov [r15+0x108], eax
00007c47757e1e59  pextrq rax, xmm1, 0x01
00007c47757e1e60  movq xmm15, rax
00007c47757e1e65  movaps [r15+0x130], xmm15
00007c47757e1e6d  movaps xmm14, [r15+0x110]
00007c47757e1e75  movq rax, xmm14
00007c47757e1e7a  movq r14, xmm1
00007c47757e1e7f  vmovq xmm1, rax
00007c47757e1e84  vmovq xmm14, r14
00007c47757e1e89  movaps xmm13, xmm1
00007c47757e1e8d  addsd xmm13, xmm14
00007c47757e1e92  ucomisd xmm13, xmm13
00007c47757e1e97  jp 0x00007C47757E1F4C
00007c47757e1e9d  movq xmm13, xmm13
00007c47757e1ea2  movq rax, xmm13
00007c47757e1ea7  movq r14, xmm15
00007c47757e1eac  vmovq xmm1, rax
00007c47757e1eb1  vmovq xmm15, r14
00007c47757e1eb6  movaps xmm14, xmm1
00007c47757e1eba  addsd xmm14, xmm15
00007c47757e1ebf  ucomisd xmm14, xmm14
00007c47757e1ec4  jp 0x00007C47757E1F94
00007c47757e1eca  movq xmm14, xmm14
00007c47757e1ecf  movaps [r15+0x110], xmm14
00007c47757e1ed7  mov eax, [r15+0x108]
00007c47757e1ede  sahf
00007c47757e1edf  jnz 0x00007C47757E1F11
00007c47757e1ee1  cmp dword ptr [r15+0x318], 0x00
00007c47757e1ee9  jz 0x00007C47757E1FE0
00007c47757e1eef  nop [rax+rax*1], ax
00007c47757e1ef8  nop [rax+rax*1], eax
00007c47757e1f00  mov eax, 0x410490
00007c47757e1f05  mov [r15+0x100], rax
00007c47757e1f0c  jmp 0x00007C47755FE110
00007c47757e1f11  cmp dword ptr [r15+0x318], 0x00
00007c47757e1f19  jz 0x00007C47757E1E20
00007c47757e1f1f  nop [rax+rax*1], ax
00007c47757e1f28  nop [rax+rax*1], eax
00007c47757e1f30  mov eax, 0x410474
00007c47757e1f35  mov [r15+0x100], rax
00007c47757e1f3c  jmp 0x00007C47755FE110
00007c47757e1f41  int3
00007c47757e1f42  call 0x00007C47756B52F0
00007c47757e1f47  jmp 0x00007C47757E1E32
00007c47757e1f4c  ucomisd xmm1, xmm14
00007c47757e1f51  jp 0x00007C47757E1F60
00007c47757e1f53  movaps xmm13, [0x00007C47753FE060]
00007c47757e1f5b  jmp 0x00007C47757E1E9D
00007c47757e1f60  vxorps xmm0, xmm1, xmm14
00007c47757e1f65  pextrw eax, xmm0, 0x03
00007c47757e1f6a  and eax, 0x7FF8
00007c47757e1f6f  cmp eax, 0x08
00007c47757e1f72  jnz 0x00007C47757E1E9D
00007c47757e1f78  movq rax, xmm14
00007c47757e1f7d  shl rax, 0x0D
00007c47757e1f81  jbe 0x00007C47757E1E9D
00007c47757e1f87  vorps xmm13, xmm14, [0x00007C47753FE070]
00007c47757e1f8f  jmp 0x00007C47757E1E9D
00007c47757e1f94  ucomisd xmm1, xmm15
00007c47757e1f99  jp 0x00007C47757E1FA8
00007c47757e1f9b  movaps xmm14, [0x00007C47753FE060]
00007c47757e1fa3  jmp 0x00007C47757E1ECA
00007c47757e1fa8  vxorps xmm0, xmm1, xmm15
00007c47757e1fad  pextrw eax, xmm0, 0x03
00007c47757e1fb2  and eax, 0x7FF8
00007c47757e1fb7  cmp eax, 0x08
00007c47757e1fba  jnz 0x00007C47757E1ECA
00007c47757e1fc0  movq rax, xmm15
00007c47757e1fc5  shl rax, 0x0D
00007c47757e1fc9  jbe 0x00007C47757E1ECA
00007c47757e1fcf  vorps xmm14, xmm15, [0x00007C47753FE070]
00007c47757e1fd7  jmp 0x00007C47757E1ECA
00007c47757e1fdc  int3
00007c47757e1fdd  nop [rax], eax
00007c47757e1fe0  mov rax, [r15+0x40]
00007c47757e1fe4  lea r14, [rax+0x510]
00007c47757e1feb  movaps xmm1, [r15+0x110]
00007c47757e1ff3  movq rax, xmm1
00007c47757e1ff8  mov [r13+r14*1], rax
00007c47757e1ffd  mov rax, [r15+0xF0]
00007c47757e2004  mov [r15+0x100], rax
00007c47757e200b  jmp 0x00007C47757CE5C0
00007c47757e2010  int3
00007c47757e2011  call 0x00007C47756D5EB0
00007c47757e2016  jmp 0x00007C47757E1FFD
00007c47757e201b  int3
00007c47757e201c  nop [rax], eax
00007c47757e2020  mov qword ptr [r15+0x100], 0x04
00007c47757e202b  mov esi, 0x00
00007c47757e2030  mov edx, 0x09
00007c47757e2035  mov rdi, 0x7FFE7DF58B10
00007c47757e203f  mov rax, 0x62084E29C970
00007c47757e2049  call rax
00007c47757e204b  cmp dword ptr [r15+0x318], 0x00
00007c47757e2053  jnz 0x00007C47755FE110
00007c47757e2059  jmp 0x00007C47755FE0A0
00007c47757e205e  int3
00007c47757e205f  int3
