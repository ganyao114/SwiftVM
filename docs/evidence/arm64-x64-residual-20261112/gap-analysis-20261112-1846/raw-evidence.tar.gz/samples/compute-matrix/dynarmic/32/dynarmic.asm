000078805cdce69b  nop [rax+rax*1], eax
000078805cdce6a0  vmovaps xmm1, [0x000078805C9FE010]
000078805cdce6a8  movq xmm1, xmm1
000078805cdce6ac  movaps [r15+0x110], xmm1
000078805cdce6b4  vmovaps xmm1, [0x000078805C9FE020]
000078805cdce6bc  movq xmm1, xmm1
000078805cdce6c0  movaps [r15+0x120], xmm1
000078805cdce6c8  mov eax, 0x4204C0
000078805cdce6cd  mov r14, [r13+rax*1]
000078805cdce6d2  movq xmm1, r14
000078805cdce6d7  movaps [r15+0x130], xmm1
000078805cdce6df  vmovaps xmm1, [0x000078805C9FE030]
000078805cdce6e7  vpbroadcastq xmm1, xmm1
000078805cdce6ec  movaps [r15+0x140], xmm1
000078805cdce6f4  mov qword ptr [r15+0x40], 0x02
000078805cdce6fc  vmovaps xmm15, [0x000078805C9FE040]
000078805cdce704  movq xmm15, xmm15
000078805cdce709  movaps [r15+0x150], xmm15
000078805cdce711  mov qword ptr [r15+0x58], 0x420000
000078805cdce719  vmovaps xmm15, [0x000078805C9FE050]
000078805cdce721  vpbroadcastq xmm15, xmm15
000078805cdce726  movaps [r15+0x160], xmm15
000078805cdce72e  mov rax, [r15+0x40]
000078805cdce732  vmovq xmm14, rax
000078805cdce737  vpbroadcastq xmm14, xmm14
000078805cdce73c  movaps [r15+0x170], xmm14
000078805cdce744  mov eax, 0x4204D0
000078805cdce749  movups xmm13, [r13+rax*1]
000078805cdce74f  mov qword ptr [r15+0x40], 0x430518
000078805cdce757  mov qword ptr [r15+0x50], 0x430720
000078805cdce75f  vpmovqd xmm12, xmm13
000078805cdce765  pxor xmm11, xmm11
000078805cdce76a  punpcklqdq xmm12, xmm11
000078805cdce76f  movaps [r15+0x210], xmm12
000078805cdce777  movq xmm12, qword ptr [r15+0x120]
000078805cdce780  movq xmm11, qword ptr [r15+0x130]
000078805cdce789  psubd xmm12, xmm11
000078805cdce78e  movq xmm12, xmm12
000078805cdce793  paddq xmm13, xmm14
000078805cdce798  movaps [r15+0x180], xmm13
000078805cdce7a0  movq xmm14, qword ptr [r15+0x150]
000078805cdce7a9  paddd xmm11, xmm14
000078805cdce7ae  movq xmm11, xmm11
000078805cdce7b3  movq xmm11, xmm11
000078805cdce7b8  movaps [r15+0x130], xmm11
000078805cdce7c0  pmovzxdq xmm12, xmm12
000078805cdce7c6  psllq xmm12, 0x00
000078805cdce7cc  movq xmm14, qword ptr [r15+0x210]
000078805cdce7d5  movq xmm13, qword ptr [r15+0x110]
000078805cdce7de  paddd xmm14, xmm13
000078805cdce7e3  movq xmm14, xmm14
000078805cdce7e8  vcvtuqq2pd xmm12, xmm12
000078805cdce7ee  pmovzxdq xmm14, xmm14
000078805cdce7f4  psllq xmm14, 0x00
000078805cdce7fa  vcvtuqq2pd xmm14, xmm14
000078805cdce800  movaps xmm13, xmm12
000078805cdce804  mulpd xmm13, xmm1
000078805cdce809  vcmppd xmm11, xmm13, xmm13, 0x03
000078805cdce80f  ptest xmm11, xmm11
000078805cdce815  jnz 0x000078805CDCE8FF
000078805cdce81b  movaps [r15+0x220], xmm13
000078805cdce823  mov eax, 0x430720
000078805cdce828  movups [r13+rax*1], xmm13
000078805cdce82e  movaps xmm1, xmm14
000078805cdce832  mulpd xmm1, xmm15
000078805cdce837  vcmppd xmm13, xmm1, xmm1, 0x03
000078805cdce83c  ptest xmm13, xmm13
000078805cdce842  jnz 0x000078805CDCEA4C
000078805cdce848  movaps [r15+0x210], xmm1
000078805cdce850  mov eax, 0x430518
000078805cdce855  movups [r13+rax*1], xmm1
000078805cdce85b  mov qword ptr [r15+0x48], 0x10
000078805cdce863  xor eax, eax
000078805cdce865  mov r14d, 0x10
000078805cdce86b  mov r12d, 0x200
000078805cdce871  cmp r14, r12
000078805cdce874  cmc
000078805cdce875  lahf
000078805cdce876  seto al
000078805cdce879  mov [r15+0x108], eax
000078805cdce880  mov eax, [r15+0x108]
000078805cdce887  sahf
000078805cdce888  jnz 0x000078805CDCE8BA
000078805cdce88a  cmp dword ptr [r15+0x318], 0x00
000078805cdce892  jz 0x000078805CDCEFF0
000078805cdce898  nop [rax+rax*1], ax
000078805cdce8a1  nop [rax+rax*1], eax
000078805cdce8a9  mov eax, 0x4101EC
000078805cdce8ae  mov [r15+0x100], rax
000078805cdce8b5  jmp 0x000078805CBFE110
000078805cdce8ba  cmp dword ptr [r15+0x318], 0x00
000078805cdce8c2  jz 0x000078805CDCEBA0
000078805cdce8c8  nop [rax+rax*1], ax
000078805cdce8d1  nop [rax+rax*1], eax
000078805cdce8d9  mov eax, 0x4101AC
000078805cdce8de  mov [r15+0x100], rax
000078805cdce8e5  jmp 0x000078805CBFE110
000078805cdce8ea  int3
000078805cdce8eb  call 0x000078805CC0DC20
000078805cdce8f0  jmp 0x000078805CDCE6D2
000078805cdce8f5  call 0x000078805CC0C260
000078805cdce8fa  jmp 0x000078805CDCE74F
000078805cdce8ff  sub rsp, 0x08
000078805cdce903  push rax
000078805cdce904  push rcx
000078805cdce905  push rdx
000078805cdce906  push rdi
000078805cdce907  push rsi
000078805cdce908  push r8
000078805cdce90a  push r9
000078805cdce90c  push r10
000078805cdce90e  push r11
000078805cdce910  sub rsp, 0xF0
000078805cdce917  vmovaps [rsp], xmm0
000078805cdce91c  vmovaps [rsp+0x10], xmm1
000078805cdce922  vmovaps [rsp+0x20], xmm2
000078805cdce928  vmovaps [rsp+0x30], xmm3
000078805cdce92e  vmovaps [rsp+0x40], xmm4
000078805cdce934  vmovaps [rsp+0x50], xmm5
000078805cdce93a  vmovaps [rsp+0x60], xmm6
000078805cdce940  vmovaps [rsp+0x70], xmm7
000078805cdce946  vmovaps [rsp+0x80], xmm8
000078805cdce94f  vmovaps [rsp+0x90], xmm9
000078805cdce958  vmovaps [rsp+0xA0], xmm10
000078805cdce961  vmovaps [rsp+0xB0], xmm11
000078805cdce96a  vmovaps [rsp+0xC0], xmm12
000078805cdce973  vmovaps [rsp+0xD0], xmm14
000078805cdce97c  vmovaps [rsp+0xE0], xmm15
000078805cdce985  sub rsp, 0x30
000078805cdce989  movaps [rsp], xmm13
000078805cdce98e  movaps [rsp+0x10], xmm12
000078805cdce994  movaps [rsp+0x20], xmm1
000078805cdce999  lea rdi, [rsp]
000078805cdce99d  mov esi, 0x00
000078805cdce9a2  mov rax, 0x5771AD6EA530
000078805cdce9ac  call rax
000078805cdce9ae  movaps xmm13, [rsp]
000078805cdce9b3  add rsp, 0x30
000078805cdce9b7  vmovaps xmm0, [rsp]
000078805cdce9bc  vmovaps xmm1, [rsp+0x10]
000078805cdce9c2  vmovaps xmm2, [rsp+0x20]
000078805cdce9c8  vmovaps xmm3, [rsp+0x30]
000078805cdce9ce  vmovaps xmm4, [rsp+0x40]
000078805cdce9d4  vmovaps xmm5, [rsp+0x50]
000078805cdce9da  vmovaps xmm6, [rsp+0x60]
000078805cdce9e0  vmovaps xmm7, [rsp+0x70]
000078805cdce9e6  vmovaps xmm8, [rsp+0x80]
000078805cdce9ef  vmovaps xmm9, [rsp+0x90]
000078805cdce9f8  vmovaps xmm10, [rsp+0xA0]
000078805cdcea01  vmovaps xmm11, [rsp+0xB0]
000078805cdcea0a  vmovaps xmm12, [rsp+0xC0]
000078805cdcea13  vmovaps xmm14, [rsp+0xD0]
000078805cdcea1c  vmovaps xmm15, [rsp+0xE0]
000078805cdcea25  add rsp, 0xF0
000078805cdcea2c  pop r11
000078805cdcea2e  pop r10
000078805cdcea30  pop r9
000078805cdcea32  pop r8
000078805cdcea34  pop rsi
000078805cdcea35  pop rdi
000078805cdcea36  pop rdx
000078805cdcea37  pop rcx
000078805cdcea38  pop rax
000078805cdcea39  add rsp, 0x08
000078805cdcea3d  jmp 0x000078805CDCE81B
000078805cdcea42  call 0x000078805CC0C380
000078805cdcea47  jmp 0x000078805CDCE82E
000078805cdcea4c  sub rsp, 0x08
000078805cdcea50  push rax
000078805cdcea51  push rcx
000078805cdcea52  push rdx
000078805cdcea53  push rdi
000078805cdcea54  push rsi
000078805cdcea55  push r8
000078805cdcea57  push r9
000078805cdcea59  push r10
000078805cdcea5b  push r11
000078805cdcea5d  sub rsp, 0xF0
000078805cdcea64  vmovaps [rsp], xmm0
000078805cdcea69  vmovaps [rsp+0x10], xmm2
000078805cdcea6f  vmovaps [rsp+0x20], xmm3
000078805cdcea75  vmovaps [rsp+0x30], xmm4
000078805cdcea7b  vmovaps [rsp+0x40], xmm5
000078805cdcea81  vmovaps [rsp+0x50], xmm6
000078805cdcea87  vmovaps [rsp+0x60], xmm7
000078805cdcea8d  vmovaps [rsp+0x70], xmm8
000078805cdcea93  vmovaps [rsp+0x80], xmm9
000078805cdcea9c  vmovaps [rsp+0x90], xmm10
000078805cdceaa5  vmovaps [rsp+0xA0], xmm11
000078805cdceaae  vmovaps [rsp+0xB0], xmm12
000078805cdceab7  vmovaps [rsp+0xC0], xmm13
000078805cdceac0  vmovaps [rsp+0xD0], xmm14
000078805cdceac9  vmovaps [rsp+0xE0], xmm15
000078805cdcead2  sub rsp, 0x30
000078805cdcead6  movaps [rsp], xmm1
000078805cdceada  movaps [rsp+0x10], xmm14
000078805cdceae0  movaps [rsp+0x20], xmm15
000078805cdceae6  lea rdi, [rsp]
000078805cdceaea  mov esi, 0x00
000078805cdceaef  mov rax, 0x5771AD6EA530
000078805cdceaf9  call rax
000078805cdceafb  movaps xmm1, [rsp]
000078805cdceaff  add rsp, 0x30
000078805cdceb03  vmovaps xmm0, [rsp]
000078805cdceb08  vmovaps xmm2, [rsp+0x10]
000078805cdceb0e  vmovaps xmm3, [rsp+0x20]
000078805cdceb14  vmovaps xmm4, [rsp+0x30]
000078805cdceb1a  vmovaps xmm5, [rsp+0x40]
000078805cdceb20  vmovaps xmm6, [rsp+0x50]
000078805cdceb26  vmovaps xmm7, [rsp+0x60]
000078805cdceb2c  vmovaps xmm8, [rsp+0x70]
000078805cdceb32  vmovaps xmm9, [rsp+0x80]
000078805cdceb3b  vmovaps xmm10, [rsp+0x90]
000078805cdceb44  vmovaps xmm11, [rsp+0xA0]
000078805cdceb4d  vmovaps xmm12, [rsp+0xB0]
000078805cdceb56  vmovaps xmm13, [rsp+0xC0]
000078805cdceb5f  vmovaps xmm14, [rsp+0xD0]
000078805cdceb68  vmovaps xmm15, [rsp+0xE0]
000078805cdceb71  add rsp, 0xF0
000078805cdceb78  pop r11
000078805cdceb7a  pop r10
000078805cdceb7c  pop r9
000078805cdceb7e  pop r8
000078805cdceb80  pop rsi
000078805cdceb81  pop rdi
000078805cdceb82  pop rdx
000078805cdceb83  pop rcx
000078805cdceb84  pop rax
000078805cdceb85  add rsp, 0x08
000078805cdceb89  jmp 0x000078805CDCE848
000078805cdceb8e  call 0x000078805CBFF540
000078805cdceb93  jmp 0x000078805CDCE85B
000078805cdceb98  int3
000078805cdceb99  nop [rax], eax
000078805cdceba0  movaps xmm1, [r15+0x180]
000078805cdceba8  vpmovqd xmm15, xmm1
000078805cdcebae  pxor xmm14, xmm14
000078805cdcebb3  punpcklqdq xmm15, xmm14
000078805cdcebb8  movaps [r15+0x210], xmm15
000078805cdcebc0  movq xmm15, qword ptr [r15+0x120]
000078805cdcebc9  movq xmm14, qword ptr [r15+0x130]
000078805cdcebd2  psubd xmm15, xmm14
000078805cdcebd7  movq xmm15, xmm15
000078805cdcebdc  movaps xmm13, [r15+0x170]
000078805cdcebe4  paddq xmm1, xmm13
000078805cdcebe9  movaps [r15+0x180], xmm1
000078805cdcebf1  movq xmm1, qword ptr [r15+0x150]
000078805cdcebfa  paddd xmm14, xmm1
000078805cdcebff  movq xmm14, xmm14
000078805cdcec04  movq xmm14, xmm14
000078805cdcec09  movaps [r15+0x130], xmm14
000078805cdcec11  pmovzxdq xmm15, xmm15
000078805cdcec17  psllq xmm15, 0x00
000078805cdcec1d  movq xmm1, qword ptr [r15+0x210]
000078805cdcec26  movq xmm14, qword ptr [r15+0x110]
000078805cdcec2f  paddd xmm1, xmm14
000078805cdcec34  movq xmm1, xmm1
000078805cdcec38  vcvtuqq2pd xmm15, xmm15
000078805cdcec3e  pmovzxdq xmm1, xmm1
000078805cdcec43  psllq xmm1, 0x00
000078805cdcec48  vcvtuqq2pd xmm1, xmm1
000078805cdcec4e  movaps xmm14, [r15+0x140]
000078805cdcec56  movaps xmm13, xmm15
000078805cdcec5a  mulpd xmm13, xmm14
000078805cdcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000078805cdcec65  ptest xmm12, xmm12
000078805cdcec6b  jnz 0x000078805CDCED4E
000078805cdcec71  movaps [r15+0x220], xmm13
000078805cdcec79  mov rax, [r15+0x48]
000078805cdcec7d  mov r14, [r15+0x50]
000078805cdcec81  lea r12, [r14+rax*1]
000078805cdcec85  movups [r13+r12*1], xmm13
000078805cdcec8b  movaps xmm15, [r15+0x160]
000078805cdcec93  movaps xmm14, xmm1
000078805cdcec97  mulpd xmm14, xmm15
000078805cdcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000078805cdceca2  ptest xmm13, xmm13
000078805cdceca8  jnz 0x000078805CDCEE9C
000078805cdcecae  movaps [r15+0x210], xmm14
000078805cdcecb6  mov r14, [r15+0x40]
000078805cdcecba  lea r12, [r14+rax*1]
000078805cdcecbe  movups [r13+r12*1], xmm14
000078805cdcecc4  lea r14, [rax+0x10]
000078805cdcecc8  mov [r15+0x48], r14
000078805cdceccc  xor eax, eax
000078805cdcecce  mov r12d, 0x200
000078805cdcecd4  cmp r14, r12
000078805cdcecd7  cmc
000078805cdcecd8  lahf
000078805cdcecd9  seto al
000078805cdcecdc  mov [r15+0x108], eax
000078805cdcece3  mov eax, [r15+0x108]
000078805cdcecea  sahf
000078805cdceceb  jnz 0x000078805CDCED1D
000078805cdceced  cmp dword ptr [r15+0x318], 0x00
000078805cdcecf5  jz 0x000078805CDCEFF0
000078805cdcecfb  nop [rax+rax*1], ax
000078805cdced04  nop [rax+rax*1], eax
000078805cdced0c  mov eax, 0x4101EC
000078805cdced11  mov [r15+0x100], rax
000078805cdced18  jmp 0x000078805CBFE110
000078805cdced1d  cmp dword ptr [r15+0x318], 0x00
000078805cdced25  jz 0x000078805CDCEBA0
000078805cdced2b  nop [rax+rax*1], ax
000078805cdced34  nop [rax+rax*1], eax
000078805cdced3c  mov eax, 0x4101AC
000078805cdced41  mov [r15+0x100], rax
000078805cdced48  jmp 0x000078805CBFE110
000078805cdced4d  int3
000078805cdced4e  sub rsp, 0x08
000078805cdced52  push rax
000078805cdced53  push rcx
000078805cdced54  push rdx
000078805cdced55  push rdi
000078805cdced56  push rsi
000078805cdced57  push r8
000078805cdced59  push r9
000078805cdced5b  push r10
000078805cdced5d  push r11
000078805cdced5f  sub rsp, 0xF0
000078805cdced66  vmovaps [rsp], xmm0
000078805cdced6b  vmovaps [rsp+0x10], xmm1
000078805cdced71  vmovaps [rsp+0x20], xmm2
000078805cdced77  vmovaps [rsp+0x30], xmm3
000078805cdced7d  vmovaps [rsp+0x40], xmm4
000078805cdced83  vmovaps [rsp+0x50], xmm5
000078805cdced89  vmovaps [rsp+0x60], xmm6
000078805cdced8f  vmovaps [rsp+0x70], xmm7
000078805cdced95  vmovaps [rsp+0x80], xmm8
000078805cdced9e  vmovaps [rsp+0x90], xmm9
000078805cdceda7  vmovaps [rsp+0xA0], xmm10
000078805cdcedb0  vmovaps [rsp+0xB0], xmm11
000078805cdcedb9  vmovaps [rsp+0xC0], xmm12
000078805cdcedc2  vmovaps [rsp+0xD0], xmm14
000078805cdcedcb  vmovaps [rsp+0xE0], xmm15
000078805cdcedd4  sub rsp, 0x30
000078805cdcedd8  movaps [rsp], xmm13
000078805cdceddd  movaps [rsp+0x10], xmm15
000078805cdcede3  movaps [rsp+0x20], xmm14
000078805cdcede9  lea rdi, [rsp]
000078805cdceded  mov esi, 0x00
000078805cdcedf2  mov rax, 0x5771AD6EA530
000078805cdcedfc  call rax
000078805cdcedfe  movaps xmm13, [rsp]
000078805cdcee03  add rsp, 0x30
000078805cdcee07  vmovaps xmm0, [rsp]
000078805cdcee0c  vmovaps xmm1, [rsp+0x10]
000078805cdcee12  vmovaps xmm2, [rsp+0x20]
000078805cdcee18  vmovaps xmm3, [rsp+0x30]
000078805cdcee1e  vmovaps xmm4, [rsp+0x40]
000078805cdcee24  vmovaps xmm5, [rsp+0x50]
000078805cdcee2a  vmovaps xmm6, [rsp+0x60]
000078805cdcee30  vmovaps xmm7, [rsp+0x70]
000078805cdcee36  vmovaps xmm8, [rsp+0x80]
000078805cdcee3f  vmovaps xmm9, [rsp+0x90]
000078805cdcee48  vmovaps xmm10, [rsp+0xA0]
000078805cdcee51  vmovaps xmm11, [rsp+0xB0]
000078805cdcee5a  vmovaps xmm12, [rsp+0xC0]
000078805cdcee63  vmovaps xmm14, [rsp+0xD0]
000078805cdcee6c  vmovaps xmm15, [rsp+0xE0]
000078805cdcee75  add rsp, 0xF0
000078805cdcee7c  pop r11
000078805cdcee7e  pop r10
000078805cdcee80  pop r9
000078805cdcee82  pop r8
000078805cdcee84  pop rsi
000078805cdcee85  pop rdi
000078805cdcee86  pop rdx
000078805cdcee87  pop rcx
000078805cdcee88  pop rax
000078805cdcee89  add rsp, 0x08
000078805cdcee8d  jmp 0x000078805CDCEC71
000078805cdcee92  call 0x000078805CCC2240
000078805cdcee97  jmp 0x000078805CDCEC8B
000078805cdcee9c  sub rsp, 0x08
000078805cdceea0  push rax
000078805cdceea1  push rcx
000078805cdceea2  push rdx
000078805cdceea3  push rdi
000078805cdceea4  push rsi
000078805cdceea5  push r8
000078805cdceea7  push r9
000078805cdceea9  push r10
000078805cdceeab  push r11
000078805cdceead  sub rsp, 0xF0
000078805cdceeb4  vmovaps [rsp], xmm0
000078805cdceeb9  vmovaps [rsp+0x10], xmm1
000078805cdceebf  vmovaps [rsp+0x20], xmm2
000078805cdceec5  vmovaps [rsp+0x30], xmm3
000078805cdceecb  vmovaps [rsp+0x40], xmm4
000078805cdceed1  vmovaps [rsp+0x50], xmm5
000078805cdceed7  vmovaps [rsp+0x60], xmm6
000078805cdceedd  vmovaps [rsp+0x70], xmm7
000078805cdceee3  vmovaps [rsp+0x80], xmm8
000078805cdceeec  vmovaps [rsp+0x90], xmm9
000078805cdceef5  vmovaps [rsp+0xA0], xmm10
000078805cdceefe  vmovaps [rsp+0xB0], xmm11
000078805cdcef07  vmovaps [rsp+0xC0], xmm12
000078805cdcef10  vmovaps [rsp+0xD0], xmm13
000078805cdcef19  vmovaps [rsp+0xE0], xmm15
000078805cdcef22  sub rsp, 0x30
000078805cdcef26  movaps [rsp], xmm14
000078805cdcef2b  movaps [rsp+0x10], xmm1
000078805cdcef30  movaps [rsp+0x20], xmm15
000078805cdcef36  lea rdi, [rsp]
000078805cdcef3a  mov esi, 0x00
000078805cdcef3f  mov rax, 0x5771AD6EA530
000078805cdcef49  call rax
000078805cdcef4b  movaps xmm14, [rsp]
000078805cdcef50  add rsp, 0x30
000078805cdcef54  vmovaps xmm0, [rsp]
000078805cdcef59  vmovaps xmm1, [rsp+0x10]
000078805cdcef5f  vmovaps xmm2, [rsp+0x20]
000078805cdcef65  vmovaps xmm3, [rsp+0x30]
000078805cdcef6b  vmovaps xmm4, [rsp+0x40]
000078805cdcef71  vmovaps xmm5, [rsp+0x50]
000078805cdcef77  vmovaps xmm6, [rsp+0x60]
000078805cdcef7d  vmovaps xmm7, [rsp+0x70]
000078805cdcef83  vmovaps xmm8, [rsp+0x80]
000078805cdcef8c  vmovaps xmm9, [rsp+0x90]
000078805cdcef95  vmovaps xmm10, [rsp+0xA0]
000078805cdcef9e  vmovaps xmm11, [rsp+0xB0]
000078805cdcefa7  vmovaps xmm12, [rsp+0xC0]
000078805cdcefb0  vmovaps xmm13, [rsp+0xD0]
000078805cdcefb9  vmovaps xmm15, [rsp+0xE0]
000078805cdcefc2  add rsp, 0xF0
000078805cdcefc9  pop r11
000078805cdcefcb  pop r10
000078805cdcefcd  pop r9
000078805cdcefcf  pop r8
000078805cdcefd1  pop rsi
000078805cdcefd2  pop rdi
000078805cdcefd3  pop rdx
000078805cdcefd4  pop rcx
000078805cdcefd5  pop rax
000078805cdcefd6  add rsp, 0x08
000078805cdcefda  jmp 0x000078805CDCECAE
000078805cdcefdf  call 0x000078805CCC34C0
000078805cdcefe4  jmp 0x000078805CDCECC4
000078805cdcefe9  int3
000078805cdcefea  nop [rax+rax*1], ax
000078805cdceff0  mov rax, [r15+0xF8]
000078805cdceff7  lea r14, [rax-0x150]
000078805cdceffe  mov [r15+0xF8], r14
000078805cdcf005  mov rax, [r15+0x50]
000078805cdcf009  lea r12, [rax+0x80]
000078805cdcf010  movups xmm1, [r13+r12*1]
000078805cdcf016  lea r12, [rax+0x90]
000078805cdcf01d  movups xmm15, [r13+r12*1]
000078805cdcf023  mov qword ptr [r15+0x48], 0x00
000078805cdcf02b  lea r12, [rax+0x40]
000078805cdcf02f  movups xmm14, [r13+r12*1]
000078805cdcf035  lea r12, [rax+0x50]
000078805cdcf039  movups xmm13, [r13+r12*1]
000078805cdcf03f  lea r12, [r14+0x120]
000078805cdcf046  movq xmm12, qword ptr [r15+0x1C0]
000078805cdcf04f  movq xmm11, qword ptr [r15+0x1B0]
000078805cdcf058  movq r11, xmm12
000078805cdcf05d  movq r10, xmm11
000078805cdcf062  mov [r13+r12*1], r11
000078805cdcf067  lea r12, [r14+0x128]
000078805cdcf06e  mov [r13+r12*1], r10
000078805cdcf073  vxorps xmm12, xmm12, xmm12
000078805cdcf078  vpbroadcastq xmm12, xmm12
000078805cdcf07d  lea r12, [r14+0x100]
000078805cdcf084  movq xmm11, qword ptr [r15+0x200]
000078805cdcf08d  movq xmm10, qword ptr [r15+0x1F0]
000078805cdcf096  movq r11, xmm11
000078805cdcf09b  movq r10, xmm10
000078805cdcf0a0  mov [r13+r12*1], r11
000078805cdcf0a5  lea r12, [r14+0x108]
000078805cdcf0ac  mov [r13+r12*1], r10
000078805cdcf0b1  lea r12, [r14+0xE0]
000078805cdcf0b8  movups [r13+r12*1], xmm15
000078805cdcf0be  lea r12, [r14+0xF0]
000078805cdcf0c5  movups [r13+r12*1], xmm1
000078805cdcf0cb  lea r12, [rax+0xC0]
000078805cdcf0d2  movups xmm1, [r13+r12*1]
000078805cdcf0d8  lea r12, [rax+0xD0]
000078805cdcf0df  movups xmm15, [r13+r12*1]
000078805cdcf0e5  lea r12, [r14+0x110]
000078805cdcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000078805cdcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000078805cdcf0fe  movq r11, xmm11
000078805cdcf103  movq r10, xmm10
000078805cdcf108  mov [r13+r12*1], r11
000078805cdcf10d  lea r12, [r14+0x118]
000078805cdcf114  mov [r13+r12*1], r10
000078805cdcf119  movups xmm11, [r13+rax*1]
000078805cdcf11f  lea r12, [rax+0x10]
000078805cdcf123  movups xmm10, [r13+r12*1]
000078805cdcf129  lea r12, [r14+0x130]
000078805cdcf130  movq xmm9, qword ptr [r15+0x1A0]
000078805cdcf139  movq xmm8, qword ptr [r15+0x190]
000078805cdcf142  movq r11, xmm9
000078805cdcf147  movq r10, xmm8
000078805cdcf14c  mov [r13+r12*1], r11
000078805cdcf151  lea r12, [r14+0x138]
000078805cdcf158  mov [r13+r12*1], r10
000078805cdcf15d  lea r12, [rax+0x140]
000078805cdcf164  movups xmm9, [r13+r12*1]
000078805cdcf16a  lea r12, [rax+0x150]
000078805cdcf171  movups xmm8, [r13+r12*1]
000078805cdcf177  lea r12, [r14+0xC0]
000078805cdcf17e  movups [r13+r12*1], xmm15
000078805cdcf184  lea r12, [r14+0xD0]
000078805cdcf18b  movups [r13+r12*1], xmm1
000078805cdcf191  lea r12, [rax+0x100]
000078805cdcf198  movups xmm1, [r13+r12*1]
000078805cdcf19e  lea r12, [rax+0x110]
000078805cdcf1a5  movups xmm15, [r13+r12*1]
000078805cdcf1ab  lea r12, [r14+0x140]
000078805cdcf1b2  mov r11, [r15+0xE8]
000078805cdcf1b9  mov [r13+r12*1], r11
000078805cdcf1be  lea r12, [rax+0x180]
000078805cdcf1c5  movups xmm7, [r13+r12*1]
000078805cdcf1cb  lea r12, [rax+0x190]
000078805cdcf1d2  movups xmm6, [r13+r12*1]
000078805cdcf1d8  lea r12, [rax+0x1C0]
000078805cdcf1df  movups xmm5, [r13+r12*1]
000078805cdcf1e5  lea r12, [rax+0x1D0]
000078805cdcf1ec  movups xmm4, [r13+r12*1]
000078805cdcf1f2  lea r12, [r14+0x20]
000078805cdcf1f6  movups [r13+r12*1], xmm1
000078805cdcf1fc  lea r12, [r14+0x30]
000078805cdcf200  movups [r13+r12*1], xmm13
000078805cdcf206  lea r12, [rax+0x60]
000078805cdcf20a  movups xmm1, [r13+r12*1]
000078805cdcf210  lea r12, [rax+0x70]
000078805cdcf214  movups xmm13, [r13+r12*1]
000078805cdcf21a  lea r12, [rax+0x20]
000078805cdcf21e  movups xmm3, [r13+r12*1]
000078805cdcf224  lea r12, [rax+0x30]
000078805cdcf228  movups xmm2, [r13+r12*1]
000078805cdcf22e  movaps [r15+0x1F0], xmm2
000078805cdcf236  lea r12, [r14+0x60]
000078805cdcf23a  movups [r13+r12*1], xmm11
000078805cdcf240  lea r12, [r14+0x70]
000078805cdcf244  movups [r13+r12*1], xmm5
000078805cdcf24a  lea r12, [rax+0xE0]
000078805cdcf251  movups xmm11, [r13+r12*1]
000078805cdcf257  lea r12, [rax+0xF0]
000078805cdcf25e  movups xmm5, [r13+r12*1]
000078805cdcf264  lea r12, [r14+0xA0]
000078805cdcf26b  movups [r13+r12*1], xmm13
000078805cdcf271  lea r12, [r14+0xB0]
000078805cdcf278  movups [r13+r12*1], xmm1
000078805cdcf27e  lea r12, [rax+0xA0]
000078805cdcf285  movups xmm1, [r13+r12*1]
000078805cdcf28b  lea r12, [rax+0xB0]
000078805cdcf292  movups xmm13, [r13+r12*1]
000078805cdcf298  lea r12, [rax+0x120]
000078805cdcf29f  vmovaps [rsp+0x10], xmm1
000078805cdcf2a5  movups xmm1, [r13+r12*1]
000078805cdcf2ab  lea r12, [rax+0x130]
000078805cdcf2b2  vmovaps [rsp+0x20], xmm1
000078805cdcf2b8  movups xmm1, [r13+r12*1]
000078805cdcf2be  lea r12, [rax+0x160]
000078805cdcf2c5  vmovaps [rsp+0x30], xmm1
000078805cdcf2cb  movups xmm1, [r13+r12*1]
000078805cdcf2d1  lea r12, [rax+0x170]
000078805cdcf2d8  vmovaps [rsp+0x40], xmm1
000078805cdcf2de  movups xmm1, [r13+r12*1]
000078805cdcf2e4  movaps [r15+0x2B0], xmm1
000078805cdcf2ec  lea r12, [r14+0x80]
000078805cdcf2f3  movups [r13+r12*1], xmm13
000078805cdcf2f9  lea r12, [r14+0x90]
000078805cdcf300  vmovaps xmm13, [rsp+0x10]
000078805cdcf306  movups [r13+r12*1], xmm13
000078805cdcf30c  lea r12, [rax+0x1A0]
000078805cdcf313  movups xmm13, [r13+r12*1]
000078805cdcf319  lea r12, [rax+0x1B0]
000078805cdcf320  vmovaps [rsp+0x10], xmm1
000078805cdcf326  movups xmm1, [r13+r12*1]
000078805cdcf32c  movaps [r15+0x290], xmm13
000078805cdcf334  movaps [r15+0x1E0], xmm1
000078805cdcf33c  lea r12, [rax+0x1E0]
000078805cdcf343  vmovaps [rsp+0x50], xmm1
000078805cdcf349  movups xmm1, [r13+r12*1]
000078805cdcf34f  lea r12, [rax+0x1F0]
000078805cdcf356  vmovaps [rsp+0x60], xmm1
000078805cdcf35c  movups xmm1, [r13+r12*1]
000078805cdcf362  mov qword ptr [r15+0x50], 0x430920
000078805cdcf36a  lea rax, [r14+0x40]
000078805cdcf36e  vmovaps [rsp+0x70], xmm1
000078805cdcf374  vmovaps xmm1, [rsp+0x40]
000078805cdcf37a  movups [r13+rax*1], xmm1
000078805cdcf380  lea rax, [r14+0x50]
000078805cdcf384  movups [r13+rax*1], xmm10
000078805cdcf38a  vmovaps xmm1, [rsp+0x70]
000078805cdcf390  movups [r13+r14*1], xmm1
000078805cdcf396  lea rax, [r14+0x10]
000078805cdcf39a  vmovaps xmm1, [rsp+0x60]
000078805cdcf3a0  movups [r13+rax*1], xmm1
000078805cdcf3a6  mov rax, [r15+0x40]
000078805cdcf3aa  vmovaps [rsp+0x40], xmm3
000078805cdcf3b0  vmovaps xmm1, [rsp+0x40]
000078805cdcf3b6  por xmm3, xmm1
000078805cdcf3ba  vmovaps [rsp+0x40], xmm6
000078805cdcf3c0  vmovaps xmm10, [rsp+0x40]
000078805cdcf3c6  por xmm6, xmm10
000078805cdcf3cb  lea r12, [rax+0x30]
000078805cdcf3cf  mov r11, [r13+r12*1]
000078805cdcf3d4  lea r12, [rax+0x38]
000078805cdcf3d8  mov r10, [r13+r12*1]
000078805cdcf3dd  movq xmm10, r11
000078805cdcf3e2  vmovaps [rsp+0x40], xmm1
000078805cdcf3e8  movq xmm1, r10
000078805cdcf3ed  movq xmm10, xmm10
000078805cdcf3f2  vmovaps [rsp+0x60], xmm10
000078805cdcf3f8  movq xmm10, xmm10
000078805cdcf3fd  movaps [r15+0x130], xmm10
000078805cdcf405  movq xmm1, xmm1
000078805cdcf409  vmovaps [rsp+0x70], xmm1
000078805cdcf40f  movq xmm1, xmm1
000078805cdcf413  movaps [r15+0x280], xmm1
000078805cdcf41b  vmovaps [rsp+0x80], xmm9
000078805cdcf424  vmovaps xmm1, [rsp+0x80]
000078805cdcf42d  por xmm9, xmm1
000078805cdcf432  lea r12, [rax+0x20]
000078805cdcf436  mov r11, [r13+r12*1]
000078805cdcf43b  lea r12, [rax+0x28]
000078805cdcf43f  mov r10, [r13+r12*1]
000078805cdcf444  movq xmm1, r11
000078805cdcf449  movq xmm10, r10
000078805cdcf44e  movq xmm1, xmm1
000078805cdcf452  vmovaps [rsp+0x80], xmm1
000078805cdcf45b  movq xmm1, xmm1
000078805cdcf45f  movaps [r15+0x150], xmm1
000078805cdcf467  movq xmm10, xmm10
000078805cdcf46c  vmovaps [rsp+0x90], xmm10
000078805cdcf475  movq xmm10, xmm10
000078805cdcf47a  movaps [r15+0x140], xmm10
000078805cdcf482  lea r12, [rax+0x10]
000078805cdcf486  mov r11, [r13+r12*1]
000078805cdcf48b  lea r12, [rax+0x18]
000078805cdcf48f  mov r10, [r13+r12*1]
000078805cdcf494  movq xmm1, r11
000078805cdcf499  movq xmm10, r10
000078805cdcf49e  movq xmm1, xmm1
000078805cdcf4a2  vmovaps [rsp+0xA0], xmm1
000078805cdcf4ab  movq xmm1, xmm1
000078805cdcf4af  movaps [r15+0x170], xmm1
000078805cdcf4b7  movq xmm10, xmm10
000078805cdcf4bc  vmovaps [rsp+0xB0], xmm10
000078805cdcf4c5  movq xmm10, xmm10
000078805cdcf4ca  movaps [r15+0x160], xmm10
000078805cdcf4d2  mov r12, [r13+rax*1]
000078805cdcf4d7  vmovq xmm1, r12
000078805cdcf4dc  vpbroadcastq xmm1, xmm1
000078805cdcf4e1  lea r12, [rax+0x08]
000078805cdcf4e5  mov rax, [r13+r12*1]
000078805cdcf4ea  movq xmm10, rax
000078805cdcf4ef  movaps [r15+0x230], xmm10
000078805cdcf4f7  lea rax, [r14+0x50]
000078805cdcf4fb  movups xmm10, [r13+rax*1]
000078805cdcf501  lea rax, [r14+0x60]
000078805cdcf505  vmovaps [rsp+0xC0], xmm1
000078805cdcf50e  movups xmm1, [r13+rax*1]
000078805cdcf514  lea rax, [r14+0x30]
000078805cdcf518  vmovaps [rsp+0xD0], xmm1
000078805cdcf521  movups xmm1, [r13+rax*1]
000078805cdcf527  mov qword ptr [r15+0x60], 0x430920
000078805cdcf52f  mov qword ptr [r15+0x58], 0x40
000078805cdcf537  vmovaps [rsp+0xE0], xmm1
000078805cdcf540  vmovaps [rsp+0xF0], xmm15
000078805cdcf549  vmovaps xmm15, [rsp+0xC0]
000078805cdcf552  vmovaps [rsp+0xC0], xmm14
000078805cdcf55b  vmovaps xmm14, [rsp+0x40]
000078805cdcf561  vmovaps [rsp+0x40], xmm13
000078805cdcf567  movaps xmm1, xmm15
000078805cdcf56b  mulpd xmm1, xmm14
000078805cdcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000078805cdcf575  ptest xmm13, xmm13
000078805cdcf57b  jnz 0x000078805CDD0682
000078805cdcf581  movq xmm14, qword ptr [r15+0x230]
000078805cdcf58a  vmovaps [rsp+0x100], xmm14
000078805cdcf593  vpermilpd xmm14, xmm14, 0x00
000078805cdcf599  vmovaps [rsp+0x110], xmm1
000078805cdcf5a2  vmovaps xmm1, [rsp+0xE0]
000078805cdcf5ab  vmovaps [rsp+0xE0], xmm15
000078805cdcf5b4  movaps xmm13, xmm1
000078805cdcf5b8  mulpd xmm13, xmm14
000078805cdcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000078805cdcf5c3  ptest xmm15, xmm15
000078805cdcf5c9  jnz 0x000078805CDD07C4
000078805cdcf5cf  vxorps xmm1, xmm1, xmm1
000078805cdcf5d3  vpbroadcastq xmm1, xmm1
000078805cdcf5d8  vmovaps xmm14, [rsp+0xE0]
000078805cdcf5e1  vmovaps [rsp+0xE0], xmm1
000078805cdcf5ea  vmovaps xmm1, [rsp+0xD0]
000078805cdcf5f3  vmovaps [rsp+0xD0], xmm13
000078805cdcf5fc  movaps xmm15, xmm14
000078805cdcf600  mulpd xmm15, xmm1
000078805cdcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000078805cdcf60b  ptest xmm13, xmm13
000078805cdcf611  jnz 0x000078805CDD0907
000078805cdcf617  movaps xmm1, xmm14
000078805cdcf61b  mulpd xmm1, xmm10
000078805cdcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000078805cdcf625  ptest xmm13, xmm13
000078805cdcf62b  jnz 0x000078805CDD0A4A
000078805cdcf631  movaps xmm13, xmm14
000078805cdcf635  mulpd xmm13, xmm2
000078805cdcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000078805cdcf640  ptest xmm10, xmm10
000078805cdcf646  jnz 0x000078805CDD0B8C
000078805cdcf64c  vmovaps [rsp+0x120], xmm7
000078805cdcf655  vmovaps xmm14, [rsp+0x120]
000078805cdcf65e  por xmm7, xmm14
000078805cdcf663  vmovaps xmm14, [rsp+0xC0]
000078805cdcf66c  vmovaps xmm10, [rsp+0xC0]
000078805cdcf675  por xmm14, xmm10
000078805cdcf67a  vmovaps xmm2, [rsp+0x100]
000078805cdcf683  vpermilpd xmm2, xmm2, 0x00
000078805cdcf689  vmovaps [rsp+0xC0], xmm1
000078805cdcf692  vmovaps [rsp+0x120], xmm15
000078805cdcf69b  movaps xmm1, xmm10
000078805cdcf69f  mulpd xmm1, xmm2
000078805cdcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000078805cdcf6a8  ptest xmm15, xmm15
000078805cdcf6ae  jnz 0x000078805CDD0CCF
000078805cdcf6b4  xor eax, eax
000078805cdcf6b6  mov r12d, 0x40
000078805cdcf6bc  mov r11d, 0x200
000078805cdcf6c2  cmp r12, r11
000078805cdcf6c5  cmc
000078805cdcf6c6  lahf
000078805cdcf6c7  seto al
000078805cdcf6ca  mov [r15+0x108], eax
000078805cdcf6d1  vmovaps xmm10, [rsp+0x110]
000078805cdcf6da  vmovaps xmm2, [rsp+0xE0]
000078805cdcf6e3  vmovaps [rsp+0xE0], xmm1
000078805cdcf6ec  movaps xmm15, xmm10
000078805cdcf6f0  addpd xmm15, xmm2
000078805cdcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cdcf6fb  ptest xmm1, xmm1
000078805cdcf700  jnz 0x000078805CDD0E10
000078805cdcf706  vmovaps xmm10, [rsp+0x120]
000078805cdcf70f  vmovaps [rsp+0x110], xmm15
000078805cdcf718  movaps xmm1, xmm10
000078805cdcf71c  addpd xmm1, xmm12
000078805cdcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000078805cdcf726  ptest xmm15, xmm15
000078805cdcf72c  jnz 0x000078805CDD0F53
000078805cdcf732  vmovaps xmm10, [rsp+0xC0]
000078805cdcf73b  vmovaps [rsp+0xC0], xmm1
000078805cdcf744  movaps xmm15, xmm10
000078805cdcf748  addpd xmm15, xmm12
000078805cdcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cdcf753  ptest xmm1, xmm1
000078805cdcf758  jnz 0x000078805CDD1095
000078805cdcf75e  vmovaps xmm1, [rsp+0x30]
000078805cdcf764  vmovaps xmm12, [rsp+0x30]
000078805cdcf76a  por xmm1, xmm12
000078805cdcf76f  vmovaps xmm12, [rsp+0x20]
000078805cdcf775  vmovaps xmm10, [rsp+0x20]
000078805cdcf77b  por xmm12, xmm10
000078805cdcf780  vmovaps [rsp+0x20], xmm5
000078805cdcf786  vmovaps xmm10, [rsp+0x20]
000078805cdcf78c  por xmm5, xmm10
000078805cdcf791  vmovaps [rsp+0x20], xmm11
000078805cdcf797  vmovaps xmm10, [rsp+0x20]
000078805cdcf79d  por xmm11, xmm10
000078805cdcf7a2  vmovaps [rsp+0x20], xmm4
000078805cdcf7a8  vmovaps xmm10, [rsp+0x20]
000078805cdcf7ae  por xmm4, xmm10
000078805cdcf7b3  vmovaps [rsp+0x20], xmm8
000078805cdcf7b9  vmovaps xmm10, [rsp+0x20]
000078805cdcf7bf  por xmm8, xmm10
000078805cdcf7c4  vmovaps xmm10, [rsp+0xF0]
000078805cdcf7cd  vmovaps [rsp+0x20], xmm1
000078805cdcf7d3  vmovaps xmm1, [rsp+0xF0]
000078805cdcf7dc  por xmm10, xmm1
000078805cdcf7e1  lea rax, [r14+0xA0]
000078805cdcf7e8  movups xmm1, [r13+rax*1]
000078805cdcf7ee  lea rax, [r14+0xB0]
000078805cdcf7f5  vmovaps [rsp+0x30], xmm1
000078805cdcf7fb  movups xmm1, [r13+rax*1]
000078805cdcf801  vmovaps [rsp+0xF0], xmm1
000078805cdcf80a  vmovaps [rsp+0x120], xmm15
000078805cdcf813  movaps xmm1, xmm13
000078805cdcf817  addpd xmm1, xmm2
000078805cdcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000078805cdcf820  ptest xmm15, xmm15
000078805cdcf826  jnz 0x000078805CDD11ED
000078805cdcf82c  lea rax, [r14+0xF0]
000078805cdcf833  movups xmm15, [r13+rax*1]
000078805cdcf839  vmovaps xmm2, [rsp+0xC0]
000078805cdcf842  vmovaps [rsp+0xC0], xmm1
000078805cdcf84b  vmovaps xmm1, [rsp+0xE0]
000078805cdcf854  vmovaps [rsp+0xE0], xmm15
000078805cdcf85d  movaps xmm13, xmm2
000078805cdcf861  addpd xmm13, xmm1
000078805cdcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000078805cdcf86c  ptest xmm15, xmm15
000078805cdcf872  jnz 0x000078805CDD1338
000078805cdcf878  vmovaps xmm15, [rsp+0x120]
000078805cdcf881  vmovaps xmm2, [rsp+0xD0]
000078805cdcf88a  vmovaps [rsp+0xD0], xmm14
000078805cdcf893  movaps xmm1, xmm15
000078805cdcf897  addpd xmm1, xmm2
000078805cdcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000078805cdcf8a0  ptest xmm14, xmm14
000078805cdcf8a6  jnz 0x000078805CDD147A
000078805cdcf8ac  vmovaps xmm15, [rsp+0x100]
000078805cdcf8b5  vpermilpd xmm15, xmm15, 0x00
000078805cdcf8bb  vmovaps xmm2, [rsp+0xF0]
000078805cdcf8c4  vmovaps [rsp+0xF0], xmm1
000078805cdcf8cd  movaps xmm14, xmm2
000078805cdcf8d1  mulpd xmm14, xmm15
000078805cdcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000078805cdcf8dc  ptest xmm1, xmm1
000078805cdcf8e1  jnz 0x000078805CDD15BB
000078805cdcf8e7  vmovaps xmm1, [rsp+0xA0]
000078805cdcf8f0  vpermilpd xmm1, xmm1, 0x00
000078805cdcf8f6  vmovaps xmm2, [rsp+0xE0]
000078805cdcf8ff  vmovaps [rsp+0xE0], xmm14
000078805cdcf908  movaps xmm15, xmm2
000078805cdcf90c  mulpd xmm15, xmm1
000078805cdcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000078805cdcf917  ptest xmm14, xmm14
000078805cdcf91d  jnz 0x000078805CDD16FE
000078805cdcf923  lea rax, [r14+0xE0]
000078805cdcf92a  movups xmm1, [r13+rax*1]
000078805cdcf930  vmovaps xmm14, [rsp+0x100]
000078805cdcf939  vpermilpd xmm14, xmm14, 0x00
000078805cdcf93f  vmovaps [rsp+0x100], xmm1
000078805cdcf948  vmovaps xmm1, [rsp+0x30]
000078805cdcf94e  vmovaps [rsp+0x30], xmm15
000078805cdcf954  movaps xmm2, xmm1
000078805cdcf957  mulpd xmm2, xmm14
000078805cdcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000078805cdcf961  ptest xmm15, xmm15
000078805cdcf967  jnz 0x000078805CDD184A
000078805cdcf96d  vmovaps [rsp+0x120], xmm10
000078805cdcf976  vmovaps xmm1, [rsp+0x120]
000078805cdcf97f  por xmm10, xmm1
000078805cdcf984  movaps [r15+0x300], xmm10
000078805cdcf98c  vmovaps [rsp+0x120], xmm8
000078805cdcf995  vmovaps xmm1, [rsp+0x120]
000078805cdcf99e  por xmm8, xmm1
000078805cdcf9a3  movaps [r15+0x190], xmm8
000078805cdcf9ab  vmovaps xmm1, [rsp+0xA0]
000078805cdcf9b4  vpermilpd xmm1, xmm1, 0x00
000078805cdcf9ba  vmovaps xmm14, [rsp+0x100]
000078805cdcf9c3  vmovaps [rsp+0x100], xmm13
000078805cdcf9cc  movaps xmm15, xmm14
000078805cdcf9d0  mulpd xmm15, xmm1
000078805cdcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000078805cdcf9db  ptest xmm13, xmm13
000078805cdcf9e1  jnz 0x000078805CDD198B
000078805cdcf9e7  lea rax, [r14+0x90]
000078805cdcf9ee  movups xmm1, [r13+rax*1]
000078805cdcf9f4  vmovaps [rsp+0x120], xmm4
000078805cdcf9fd  vmovaps xmm14, [rsp+0x120]
000078805cdcfa06  por xmm4, xmm14
000078805cdcfa0b  movaps [r15+0x1C0], xmm4
000078805cdcfa13  vmovaps [rsp+0x120], xmm11
000078805cdcfa1c  vmovaps xmm14, [rsp+0x120]
000078805cdcfa25  por xmm11, xmm14
000078805cdcfa2a  movaps [r15+0x200], xmm11
000078805cdcfa32  vmovaps [rsp+0x120], xmm5
000078805cdcfa3b  vmovaps xmm14, [rsp+0x120]
000078805cdcfa44  por xmm5, xmm14
000078805cdcfa49  movaps [r15+0x2D0], xmm5
000078805cdcfa51  vmovaps [rsp+0x120], xmm12
000078805cdcfa5a  vmovaps xmm14, [rsp+0x120]
000078805cdcfa63  por xmm12, xmm14
000078805cdcfa68  movaps [r15+0x2E0], xmm12
000078805cdcfa70  vmovaps xmm13, [rsp+0x110]
000078805cdcfa79  vmovaps [rsp+0x110], xmm1
000078805cdcfa82  vmovaps xmm1, [rsp+0xE0]
000078805cdcfa8b  vmovaps [rsp+0xE0], xmm15
000078805cdcfa94  movaps xmm14, xmm13
000078805cdcfa98  addpd xmm14, xmm1
000078805cdcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000078805cdcfaa3  ptest xmm15, xmm15
000078805cdcfaa9  jnz 0x000078805CDD1AD8
000078805cdcfaaf  vmovaps xmm1, [rsp+0xA0]
000078805cdcfab8  vpermilpd xmm1, xmm1, 0x00
000078805cdcfabe  vmovaps xmm13, [rsp+0x110]
000078805cdcfac7  vmovaps [rsp+0x110], xmm14
000078805cdcfad0  movaps xmm15, xmm13
000078805cdcfad4  mulpd xmm15, xmm1
000078805cdcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000078805cdcfadf  ptest xmm14, xmm14
000078805cdcfae5  jnz 0x000078805CDD1C1B
000078805cdcfaeb  lea rax, [r14+0x80]
000078805cdcfaf2  movups xmm1, [r13+rax*1]
000078805cdcfaf8  vmovaps xmm13, [rsp+0xC0]
000078805cdcfb01  vmovaps [rsp+0xC0], xmm1
000078805cdcfb0a  movaps xmm14, xmm13
000078805cdcfb0e  addpd xmm14, xmm2
000078805cdcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000078805cdcfb19  ptest xmm1, xmm1
000078805cdcfb1e  jnz 0x000078805CDD1D68
000078805cdcfb24  vmovaps xmm13, [rsp+0x100]
000078805cdcfb2d  vmovaps xmm2, [rsp+0x30]
000078805cdcfb33  vmovaps [rsp+0x30], xmm15
000078805cdcfb39  movaps xmm1, xmm13
000078805cdcfb3d  addpd xmm1, xmm2
000078805cdcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000078805cdcfb46  ptest xmm15, xmm15
000078805cdcfb4c  jnz 0x000078805CDD1EAB
000078805cdcfb52  vmovaps xmm15, [rsp+0x20]
000078805cdcfb58  vmovaps xmm13, [rsp+0x20]
000078805cdcfb5e  por xmm15, xmm13
000078805cdcfb63  movaps [r15+0x2F0], xmm15
000078805cdcfb6b  vmovaps xmm13, [rsp+0xA0]
000078805cdcfb74  vpermilpd xmm13, xmm13, 0x00
000078805cdcfb7a  vmovaps [rsp+0x20], xmm1
000078805cdcfb80  vmovaps xmm1, [rsp+0xC0]
000078805cdcfb89  vmovaps [rsp+0xA0], xmm15
000078805cdcfb92  movaps xmm2, xmm1
000078805cdcfb95  mulpd xmm2, xmm13
000078805cdcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000078805cdcfb9f  ptest xmm15, xmm15
000078805cdcfba5  jnz 0x000078805CDD1FEC
000078805cdcfbab  lea rax, [r14+0xD0]
000078805cdcfbb2  movups xmm1, [r13+rax*1]
000078805cdcfbb8  vmovaps xmm13, [rsp+0xF0]
000078805cdcfbc1  vmovaps [rsp+0xC0], xmm1
000078805cdcfbca  vmovaps xmm1, [rsp+0xE0]
000078805cdcfbd3  vmovaps [rsp+0xE0], xmm14
000078805cdcfbdc  movaps xmm15, xmm13
000078805cdcfbe0  addpd xmm15, xmm1
000078805cdcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000078805cdcfbeb  ptest xmm14, xmm14
000078805cdcfbf1  jnz 0x000078805CDD2137
000078805cdcfbf7  vmovaps xmm1, [rsp+0xB0]
000078805cdcfc00  vpermilpd xmm1, xmm1, 0x00
000078805cdcfc06  movaps xmm14, xmm11
000078805cdcfc0a  mulpd xmm14, xmm1
000078805cdcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000078805cdcfc15  ptest xmm13, xmm13
000078805cdcfc1b  jnz 0x000078805CDD227A
000078805cdcfc21  movaps [r15+0x260], xmm14
000078805cdcfc29  vxorps xmm1, xmm1, xmm1
000078805cdcfc2d  vpbroadcastq xmm1, xmm1
000078805cdcfc32  movaps [r15+0x1B0], xmm1
000078805cdcfc3a  vmovaps xmm1, [rsp+0xB0]
000078805cdcfc43  vpermilpd xmm1, xmm1, 0x00
000078805cdcfc49  vmovaps xmm11, [rsp+0xC0]
000078805cdcfc52  vmovaps [rsp+0xC0], xmm15
000078805cdcfc5b  movaps xmm13, xmm11
000078805cdcfc5f  mulpd xmm13, xmm1
000078805cdcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000078805cdcfc6a  ptest xmm15, xmm15
000078805cdcfc70  jnz 0x000078805CDD23BD
000078805cdcfc76  lea rax, [r14+0xC0]
000078805cdcfc7d  movups xmm1, [r13+rax*1]
000078805cdcfc83  vmovaps xmm11, [rsp+0x110]
000078805cdcfc8c  vmovaps [rsp+0xF0], xmm1
000078805cdcfc95  vmovaps xmm1, [rsp+0x30]
000078805cdcfc9b  vmovaps [rsp+0x30], xmm14
000078805cdcfca1  movaps xmm15, xmm11
000078805cdcfca5  addpd xmm15, xmm1
000078805cdcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000078805cdcfcb0  ptest xmm14, xmm14
000078805cdcfcb6  jnz 0x000078805CDD250A
000078805cdcfcbc  vmovaps [rsp+0x100], xmm9
000078805cdcfcc5  vmovaps xmm1, [rsp+0x100]
000078805cdcfcce  por xmm9, xmm1
000078805cdcfcd3  movaps [r15+0x270], xmm9
000078805cdcfcdb  vmovaps [rsp+0x100], xmm6
000078805cdcfce4  vmovaps xmm1, [rsp+0x100]
000078805cdcfced  por xmm6, xmm1
000078805cdcfcf1  movaps [r15+0x1A0], xmm6
000078805cdcfcf9  vmovaps xmm14, [rsp+0xB0]
000078805cdcfd02  vpermilpd xmm14, xmm14, 0x00
000078805cdcfd08  vmovaps xmm6, [rsp+0xF0]
000078805cdcfd11  vmovaps [rsp+0xF0], xmm1
000078805cdcfd1a  movaps xmm11, xmm6
000078805cdcfd1e  mulpd xmm11, xmm14
000078805cdcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000078805cdcfd29  ptest xmm1, xmm1
000078805cdcfd2e  jnz 0x000078805CDD264D
000078805cdcfd34  lea rax, [r14+0x20]
000078805cdcfd38  movups xmm1, [r13+rax*1]
000078805cdcfd3e  movaps [r15+0x110], xmm1
000078805cdcfd46  vmovaps xmm6, [rsp+0xE0]
000078805cdcfd4f  vmovaps [rsp+0xE0], xmm1
000078805cdcfd58  movaps xmm14, xmm6
000078805cdcfd5c  addpd xmm14, xmm2
000078805cdcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000078805cdcfd67  ptest xmm1, xmm1
000078805cdcfd6c  jnz 0x000078805CDD279A
000078805cdcfd72  vmovaps xmm1, [rsp+0xB0]
000078805cdcfd7b  vpermilpd xmm1, xmm1, 0x00
000078805cdcfd81  movaps xmm6, xmm5
000078805cdcfd84  mulpd xmm6, xmm1
000078805cdcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000078805cdcfd8d  ptest xmm2, xmm2
000078805cdcfd92  jnz 0x000078805CDD28DC
000078805cdcfd98  vmovaps xmm5, [rsp+0x20]
000078805cdcfd9e  movaps xmm1, xmm5
000078805cdcfda1  addpd xmm1, xmm13
000078805cdcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000078805cdcfdab  ptest xmm2, xmm2
000078805cdcfdb0  jnz 0x000078805CDD2A1C
000078805cdcfdb6  vmovaps xmm13, [rsp+0x80]
000078805cdcfdbf  vpermilpd xmm13, xmm13, 0x00
000078805cdcfdc5  vmovaps xmm2, [rsp+0xE0]
000078805cdcfdce  vmovaps [rsp+0x20], xmm1
000078805cdcfdd4  movaps xmm5, xmm2
000078805cdcfdd7  mulpd xmm5, xmm13
000078805cdcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000078805cdcfde1  ptest xmm1, xmm1
000078805cdcfde6  jnz 0x000078805CDD2B5D
000078805cdcfdec  vmovaps xmm1, [rsp+0x80]
000078805cdcfdf5  vpermilpd xmm1, xmm1, 0x00
000078805cdcfdfb  movaps xmm13, xmm10
000078805cdcfdff  mulpd xmm13, xmm1
000078805cdcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000078805cdcfe0a  ptest xmm2, xmm2
000078805cdcfe0f  jnz 0x000078805CDD2C9E
000078805cdcfe15  vmovaps xmm10, [rsp+0x30]
000078805cdcfe1b  movaps xmm1, xmm15
000078805cdcfe1f  addpd xmm1, xmm10
000078805cdcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000078805cdcfe29  ptest xmm2, xmm2
000078805cdcfe2e  jnz 0x000078805CDD2DE1
000078805cdcfe34  vmovaps xmm10, [rsp+0xC0]
000078805cdcfe3d  movaps xmm15, xmm10
000078805cdcfe41  addpd xmm15, xmm11
000078805cdcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000078805cdcfe4c  ptest xmm2, xmm2
000078805cdcfe51  jnz 0x000078805CDD2F23
000078805cdcfe57  vmovaps xmm11, [rsp+0x80]
000078805cdcfe60  vpermilpd xmm11, xmm11, 0x00
000078805cdcfe66  movaps xmm10, xmm12
000078805cdcfe6a  mulpd xmm10, xmm11
000078805cdcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000078805cdcfe75  ptest xmm2, xmm2
000078805cdcfe7a  jnz 0x000078805CDD3067
000078805cdcfe80  vmovaps xmm12, [rsp+0x80]
000078805cdcfe89  vpermilpd xmm12, xmm12, 0x00
000078805cdcfe8f  vmovaps xmm2, [rsp+0xA0]
000078805cdcfe98  vmovaps [rsp+0x30], xmm1
000078805cdcfe9e  movaps xmm11, xmm2
000078805cdcfea2  mulpd xmm11, xmm12
000078805cdcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000078805cdcfead  ptest xmm1, xmm1
000078805cdcfeb2  jnz 0x000078805CDD31AB
000078805cdcfeb8  movaps xmm1, xmm14
000078805cdcfebc  addpd xmm1, xmm6
000078805cdcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000078805cdcfec5  ptest xmm12, xmm12
000078805cdcfecb  jnz 0x000078805CDD32EE
000078805cdcfed1  vmovaps xmm12, [rsp+0x20]
000078805cdcfed7  movaps xmm14, xmm12
000078805cdcfedb  addpd xmm14, xmm5
000078805cdcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000078805cdcfee6  ptest xmm6, xmm6
000078805cdcfeeb  jnz 0x000078805CDD342F
000078805cdcfef1  vmovaps xmm12, [rsp+0x90]
000078805cdcfefa  vpermilpd xmm12, xmm12, 0x00
000078805cdcff00  movaps xmm6, xmm9
000078805cdcff04  mulpd xmm6, xmm12
000078805cdcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000078805cdcff0e  ptest xmm5, xmm5
000078805cdcff13  jnz 0x000078805CDD3572
000078805cdcff19  movaps xmm12, xmm15
000078805cdcff1d  addpd xmm12, xmm13
000078805cdcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000078805cdcff28  ptest xmm9, xmm9
000078805cdcff2e  jnz 0x000078805CDD36B4
000078805cdcff34  vmovaps xmm13, [rsp+0x30]
000078805cdcff3a  movaps xmm15, xmm13
000078805cdcff3e  addpd xmm15, xmm10
000078805cdcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000078805cdcff49  ptest xmm9, xmm9
000078805cdcff4f  jnz 0x000078805CDD37F8
000078805cdcff55  vmovaps xmm13, [rsp+0xD0]
000078805cdcff5e  vmovaps xmm10, [rsp+0xD0]
000078805cdcff67  por xmm13, xmm10
000078805cdcff6c  movaps [r15+0x250], xmm13
000078805cdcff74  vmovaps [rsp+0x20], xmm7
000078805cdcff7a  vmovaps xmm13, [rsp+0x20]
000078805cdcff80  por xmm7, xmm13
000078805cdcff85  movaps [r15+0x2A0], xmm7
000078805cdcff8d  vmovaps [rsp+0x20], xmm3
000078805cdcff93  vmovaps xmm13, [rsp+0x20]
000078805cdcff99  por xmm3, xmm13
000078805cdcff9e  movaps [r15+0x1D0], xmm3
000078805cdcffa6  lea rax, [r14+0x40]
000078805cdcffaa  movups xmm13, [r13+rax*1]
000078805cdcffb0  movaps [r15+0x2C0], xmm13
000078805cdcffb8  vmovaps xmm10, [rsp+0x90]
000078805cdcffc1  vpermilpd xmm10, xmm10, 0x00
000078805cdcffc7  movaps xmm9, xmm8
000078805cdcffcb  mulpd xmm9, xmm10
000078805cdcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000078805cdcffd6  ptest xmm5, xmm5
000078805cdcffdb  jnz 0x000078805CDD3946
000078805cdcffe1  movaps xmm10, xmm1
000078805cdcffe5  addpd xmm10, xmm11
000078805cdcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000078805cdcfff0  ptest xmm8, xmm8
000078805cdcfff6  jnz 0x000078805CDD3A8A
000078805cdcfffc  movaps xmm1, xmm14
000078805cdd0000  addpd xmm1, xmm6
000078805cdd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000078805cdd0009  ptest xmm11, xmm11
000078805cdd000f  jnz 0x000078805CDD3BCD
000078805cdd0015  vmovaps xmm14, [rsp+0x90]
000078805cdd001e  vpermilpd xmm14, xmm14, 0x00
000078805cdd0024  movaps xmm11, xmm13
000078805cdd0028  mulpd xmm11, xmm14
000078805cdd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000078805cdd0033  ptest xmm8, xmm8
000078805cdd0039  jnz 0x000078805CDD3D0E
000078805cdd003f  vmovaps xmm14, [rsp+0x90]
000078805cdd0048  vpermilpd xmm14, xmm14, 0x00
000078805cdd004e  vmovaps xmm8, [rsp+0x10]
000078805cdd0054  movaps xmm13, xmm8
000078805cdd0058  mulpd xmm13, xmm14
000078805cdd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000078805cdd0063  ptest xmm6, xmm6
000078805cdd0068  jnz 0x000078805CDD3E52
000078805cdd006e  vmovaps xmm14, [rsp+0x60]
000078805cdd0074  vpermilpd xmm14, xmm14, 0x00
000078805cdd007a  movaps xmm8, xmm7
000078805cdd007e  mulpd xmm8, xmm14
000078805cdd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000078805cdd0089  ptest xmm6, xmm6
000078805cdd008e  jnz 0x000078805CDD3F96
000078805cdd0094  movaps xmm14, xmm12
000078805cdd0098  addpd xmm14, xmm9
000078805cdd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000078805cdd00a3  ptest xmm7, xmm7
000078805cdd00a8  jnz 0x000078805CDD40D9
000078805cdd00ae  vmovaps xmm12, [rsp+0x60]
000078805cdd00b4  vpermilpd xmm12, xmm12, 0x00
000078805cdd00ba  vmovaps xmm7, [rsp+0xF0]
000078805cdd00c3  movaps xmm9, xmm7
000078805cdd00c7  mulpd xmm9, xmm12
000078805cdd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000078805cdd00d2  ptest xmm6, xmm6
000078805cdd00d7  jnz 0x000078805CDD421D
000078805cdd00dd  movaps xmm12, xmm15
000078805cdd00e1  addpd xmm12, xmm11
000078805cdd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000078805cdd00ec  ptest xmm7, xmm7
000078805cdd00f1  jnz 0x000078805CDD4360
000078805cdd00f7  vmovaps xmm15, [rsp+0x60]
000078805cdd00fd  vpermilpd xmm15, xmm15, 0x00
000078805cdd0103  vmovaps xmm7, [rsp+0x40]
000078805cdd0109  movaps xmm11, xmm7
000078805cdd010d  mulpd xmm11, xmm15
000078805cdd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000078805cdd0118  ptest xmm6, xmm6
000078805cdd011d  jnz 0x000078805CDD44A4
000078805cdd0123  movaps xmm15, xmm10
000078805cdd0127  addpd xmm15, xmm13
000078805cdd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000078805cdd0132  ptest xmm7, xmm7
000078805cdd0137  jnz 0x000078805CDD45E7
000078805cdd013d  vmovaps xmm13, [rsp+0x60]
000078805cdd0143  vpermilpd xmm13, xmm13, 0x00
000078805cdd0149  vmovaps xmm7, [rsp+0x50]
000078805cdd014f  movaps xmm10, xmm7
000078805cdd0153  mulpd xmm10, xmm13
000078805cdd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000078805cdd015e  ptest xmm6, xmm6
000078805cdd0163  jnz 0x000078805CDD472B
000078805cdd0169  movaps xmm13, xmm1
000078805cdd016d  addpd xmm13, xmm8
000078805cdd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000078805cdd0178  ptest xmm7, xmm7
000078805cdd017d  jnz 0x000078805CDD486E
000078805cdd0183  lea rax, [r14+0x70]
000078805cdd0187  movups xmm1, [r13+rax*1]
000078805cdd018d  movaps [r15+0x240], xmm1
000078805cdd0195  movaps xmm8, xmm14
000078805cdd0199  addpd xmm8, xmm9
000078805cdd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000078805cdd01a4  ptest xmm7, xmm7
000078805cdd01a9  jnz 0x000078805CDD49BB
000078805cdd01af  movaps [r15+0x170], xmm8
000078805cdd01b7  vmovaps xmm14, [rsp+0x70]
000078805cdd01bd  vpermilpd xmm14, xmm14, 0x00
000078805cdd01c3  movaps xmm9, xmm1
000078805cdd01c7  mulpd xmm9, xmm14
000078805cdd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000078805cdd01d2  ptest xmm7, xmm7
000078805cdd01d7  jnz 0x000078805CDD4AFF
000078805cdd01dd  vmovaps xmm1, [rsp+0x70]
000078805cdd01e3  vpermilpd xmm1, xmm1, 0x00
000078805cdd01e9  movaps xmm14, xmm4
000078805cdd01ed  mulpd xmm14, xmm1
000078805cdd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000078805cdd01f8  ptest xmm7, xmm7
000078805cdd01fd  jnz 0x000078805CDD4C42
000078805cdd0203  movaps [r15+0x180], xmm14
000078805cdd020b  movaps xmm1, xmm12
000078805cdd020f  addpd xmm1, xmm11
000078805cdd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000078805cdd0219  ptest xmm7, xmm7
000078805cdd021e  jnz 0x000078805CDD4D84
000078805cdd0224  movaps [r15+0x210], xmm1
000078805cdd022c  movups xmm12, [r13+r14*1]
000078805cdd0232  lea rax, [r14+0x10]
000078805cdd0236  movups xmm11, [r13+rax*1]
000078805cdd023c  movaps [r15+0x230], xmm11
000078805cdd0244  movaps xmm7, xmm15
000078805cdd0248  addpd xmm7, xmm10
000078805cdd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000078805cdd0252  ptest xmm6, xmm6
000078805cdd0257  jnz 0x000078805CDD4EDA
000078805cdd025d  movaps [r15+0x130], xmm7
000078805cdd0265  vmovaps xmm15, [rsp+0x70]
000078805cdd026b  vpermilpd xmm15, xmm15, 0x00
000078805cdd0271  movaps xmm10, xmm11
000078805cdd0275  mulpd xmm10, xmm15
000078805cdd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000078805cdd0280  ptest xmm6, xmm6
000078805cdd0285  jnz 0x000078805CDD501C
000078805cdd028b  movaps [r15+0x220], xmm10
000078805cdd0293  vmovaps xmm15, [rsp+0x70]
000078805cdd0299  vpermilpd xmm15, xmm15, 0x00
000078805cdd029f  movaps xmm11, xmm12
000078805cdd02a3  mulpd xmm11, xmm15
000078805cdd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000078805cdd02ae  ptest xmm6, xmm6
000078805cdd02b3  jnz 0x000078805CDD5160
000078805cdd02b9  movaps xmm15, xmm13
000078805cdd02bd  addpd xmm15, xmm9
000078805cdd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000078805cdd02c8  ptest xmm12, xmm12
000078805cdd02ce  jnz 0x000078805CDD52A4
000078805cdd02d4  movaps [r15+0x140], xmm15
000078805cdd02dc  movaps xmm13, xmm8
000078805cdd02e0  addpd xmm13, xmm14
000078805cdd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000078805cdd02eb  ptest xmm12, xmm12
000078805cdd02f1  jnz 0x000078805CDD53E8
000078805cdd02f7  movaps [r15+0x150], xmm13
000078805cdd02ff  movaps xmm14, xmm1
000078805cdd0303  addpd xmm14, xmm10
000078805cdd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000078805cdd030e  ptest xmm12, xmm12
000078805cdd0314  jnz 0x000078805CDD552C
000078805cdd031a  movaps [r15+0x160], xmm14
000078805cdd0322  movaps xmm1, xmm7
000078805cdd0325  addpd xmm1, xmm11
000078805cdd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000078805cdd032f  ptest xmm12, xmm12
000078805cdd0335  jnz 0x000078805CDD566F
000078805cdd033b  movaps [r15+0x120], xmm1
000078805cdd0343  mov eax, 0x430920
000078805cdd0348  movups [r13+rax*1], xmm15
000078805cdd034e  mov eax, 0x430930
000078805cdd0353  movups [r13+rax*1], xmm13
000078805cdd0359  mov eax, 0x430940
000078805cdd035e  movups [r13+rax*1], xmm14
000078805cdd0364  mov eax, 0x430950
000078805cdd0369  movups [r13+rax*1], xmm1
000078805cdd036f  mov eax, [r15+0x108]
000078805cdd0376  sahf
000078805cdd0377  jnz 0x000078805CDD03A9
000078805cdd0379  cmp dword ptr [r15+0x318], 0x00
000078805cdd0381  jz 0x000078805CDDB900
000078805cdd0387  nop [rax+rax*1], ax
000078805cdd0390  nop [rax+rax*1], eax
000078805cdd0398  mov eax, 0x410444
000078805cdd039d  mov [r15+0x100], rax
000078805cdd03a4  jmp 0x000078805CBFE110
000078805cdd03a9  cmp dword ptr [r15+0x318], 0x00
000078805cdd03b1  jz 0x000078805CDD57E0
000078805cdd03b7  nop [rax+rax*1], ax
000078805cdd03c0  nop [rax+rax*1], eax
000078805cdd03c8  mov eax, 0x410278
000078805cdd03cd  mov [r15+0x100], rax
000078805cdd03d4  jmp 0x000078805CBFE110
000078805cdd03d9  int3
000078805cdd03da  call 0x000078805CCB52F0
000078805cdd03df  jmp 0x000078805CDCF016
000078805cdd03e4  call 0x000078805CCC4620
000078805cdd03e9  jmp 0x000078805CDCF023
000078805cdd03ee  call 0x000078805CCC33A0
000078805cdd03f3  jmp 0x000078805CDCF035
000078805cdd03f8  call 0x000078805CCC2120
000078805cdd03fd  jmp 0x000078805CDCF03F
000078805cdd0402  call 0x000078805CCC0860
000078805cdd0407  jmp 0x000078805CDCF067
000078805cdd040c  call 0x000078805CCBF5F0
000078805cdd0411  jmp 0x000078805CDCF073
000078805cdd0416  call 0x000078805CCC0860
000078805cdd041b  jmp 0x000078805CDCF0A5
000078805cdd0420  call 0x000078805CCBF5F0
000078805cdd0425  jmp 0x000078805CDCF0B1
000078805cdd042a  call 0x000078805CCC4740
000078805cdd042f  jmp 0x000078805CDCF0BE
000078805cdd0434  call 0x000078805CCB5400
000078805cdd0439  jmp 0x000078805CDCF0CB
000078805cdd043e  call 0x000078805CCB52F0
000078805cdd0443  jmp 0x000078805CDCF0D8
000078805cdd0448  call 0x000078805CCC4620
000078805cdd044d  jmp 0x000078805CDCF0E5
000078805cdd0452  call 0x000078805CCC0860
000078805cdd0457  jmp 0x000078805CDCF10D
000078805cdd045c  call 0x000078805CCBF5F0
000078805cdd0461  jmp 0x000078805CDCF119
000078805cdd0466  call 0x000078805CC09D70
000078805cdd046b  jmp 0x000078805CDCF11F
000078805cdd0470  call 0x000078805CCBE9C0
000078805cdd0475  jmp 0x000078805CDCF129
000078805cdd047a  call 0x000078805CCC0860
000078805cdd047f  jmp 0x000078805CDCF151
000078805cdd0484  call 0x000078805CCBF5F0
000078805cdd0489  jmp 0x000078805CDCF15D
000078805cdd048e  call 0x000078805CCBD750
000078805cdd0493  jmp 0x000078805CDCF16A
000078805cdd0498  call 0x000078805CCBC4E0
000078805cdd049d  jmp 0x000078805CDCF177
000078805cdd04a2  call 0x000078805CCC4740
000078805cdd04a7  jmp 0x000078805CDCF184
000078805cdd04ac  call 0x000078805CCB5400
000078805cdd04b1  jmp 0x000078805CDCF191
000078805cdd04b6  call 0x000078805CCB52F0
000078805cdd04bb  jmp 0x000078805CDCF19E
000078805cdd04c0  call 0x000078805CCC4620
000078805cdd04c5  jmp 0x000078805CDCF1AB
000078805cdd04ca  call 0x000078805CCC0860
000078805cdd04cf  jmp 0x000078805CDCF1BE
000078805cdd04d4  call 0x000078805CCBB270
000078805cdd04d9  jmp 0x000078805CDCF1CB
000078805cdd04de  call 0x000078805CCBA000
000078805cdd04e3  jmp 0x000078805CDCF1D8
000078805cdd04e8  call 0x000078805CCB8D90
000078805cdd04ed  jmp 0x000078805CDCF1E5
000078805cdd04f2  call 0x000078805CCB8A20
000078805cdd04f7  jmp 0x000078805CDCF1F2
000078805cdd04fc  call 0x000078805CCB5400
000078805cdd0501  jmp 0x000078805CDCF1FC
000078805cdd0506  call 0x000078805CCC2240
000078805cdd050b  jmp 0x000078805CDCF206
000078805cdd0510  call 0x000078805CCB52F0
000078805cdd0515  jmp 0x000078805CDCF210
000078805cdd051a  call 0x000078805CCC2120
000078805cdd051f  jmp 0x000078805CDCF21A
000078805cdd0524  call 0x000078805CCB77B0
000078805cdd0529  jmp 0x000078805CDCF224
000078805cdd052e  call 0x000078805CCB6550
000078805cdd0533  jmp 0x000078805CDCF22E
000078805cdd0538  call 0x000078805CCBFD50
000078805cdd053d  jmp 0x000078805CDCF240
000078805cdd0542  call 0x000078805CCB8EA0
000078805cdd0547  jmp 0x000078805CDCF24A
000078805cdd054c  call 0x000078805CCBFC30
000078805cdd0551  jmp 0x000078805CDCF257
000078805cdd0556  call 0x000078805CCB8D90
000078805cdd055b  jmp 0x000078805CDCF264
000078805cdd0560  call 0x000078805CCC2240
000078805cdd0565  jmp 0x000078805CDCF271
000078805cdd056a  call 0x000078805CCB5400
000078805cdd056f  jmp 0x000078805CDCF27E
000078805cdd0574  call 0x000078805CCB52F0
000078805cdd0579  jmp 0x000078805CDCF28B
000078805cdd057e  call 0x000078805CCC2120
000078805cdd0583  jmp 0x000078805CDCF298
000078805cdd0588  call 0x000078805CCB52F0
000078805cdd058d  jmp 0x000078805CDCF2AB
000078805cdd0592  call 0x000078805CCB52F0
000078805cdd0597  jmp 0x000078805CDCF2BE
000078805cdd059c  call 0x000078805CCB52F0
000078805cdd05a1  jmp 0x000078805CDCF2D1
000078805cdd05a6  call 0x000078805CCB52F0
000078805cdd05ab  jmp 0x000078805CDCF2E4
000078805cdd05b0  call 0x000078805CCC2240
000078805cdd05b5  jmp 0x000078805CDCF2F9
000078805cdd05ba  call 0x000078805CCC2240
000078805cdd05bf  jmp 0x000078805CDCF30C
000078805cdd05c4  call 0x000078805CCC2120
000078805cdd05c9  jmp 0x000078805CDCF319
000078805cdd05ce  call 0x000078805CCB52F0
000078805cdd05d3  jmp 0x000078805CDCF32C
000078805cdd05d8  call 0x000078805CCB52F0
000078805cdd05dd  jmp 0x000078805CDCF34F
000078805cdd05e2  call 0x000078805CCB52F0
000078805cdd05e7  jmp 0x000078805CDCF362
000078805cdd05ec  call 0x000078805CBFF540
000078805cdd05f1  jmp 0x000078805CDCF380
000078805cdd05f6  call 0x000078805CC08C20
000078805cdd05fb  jmp 0x000078805CDCF38A
000078805cdd0600  call 0x000078805CCD6600
000078805cdd0605  jmp 0x000078805CDCF396
000078805cdd060a  call 0x000078805CBFF540
000078805cdd060f  jmp 0x000078805CDCF3A6
000078805cdd0614  call 0x000078805CCC0370
000078805cdd0619  jmp 0x000078805CDCF3D4
000078805cdd061e  call 0x000078805CCBF100
000078805cdd0623  jmp 0x000078805CDCF3DD
000078805cdd0628  call 0x000078805CCC0370
000078805cdd062d  jmp 0x000078805CDCF43B
000078805cdd0632  call 0x000078805CCBF100
000078805cdd0637  jmp 0x000078805CDCF444
000078805cdd063c  call 0x000078805CCC0370
000078805cdd0641  jmp 0x000078805CDCF48B
000078805cdd0646  call 0x000078805CCBF100
000078805cdd064b  jmp 0x000078805CDCF494
000078805cdd0650  call 0x000078805CC0B720
000078805cdd0655  jmp 0x000078805CDCF4D7
000078805cdd065a  call 0x000078805CCB47C0
000078805cdd065f  jmp 0x000078805CDCF4EA
000078805cdd0664  call 0x000078805CC08B00
000078805cdd0669  jmp 0x000078805CDCF501
000078805cdd066e  call 0x000078805CBFF430
000078805cdd0673  jmp 0x000078805CDCF514
000078805cdd0678  call 0x000078805CBFF430
000078805cdd067d  jmp 0x000078805CDCF527
000078805cdd0682  sub rsp, 0x08
000078805cdd0686  push rax
000078805cdd0687  push rcx
000078805cdd0688  push rdx
000078805cdd0689  push rdi
000078805cdd068a  push rsi
000078805cdd068b  push r8
000078805cdd068d  push r9
000078805cdd068f  push r10
000078805cdd0691  push r11
000078805cdd0693  sub rsp, 0xF0
000078805cdd069a  vmovaps [rsp], xmm0
000078805cdd069f  vmovaps [rsp+0x10], xmm2
000078805cdd06a5  vmovaps [rsp+0x20], xmm3
000078805cdd06ab  vmovaps [rsp+0x30], xmm4
000078805cdd06b1  vmovaps [rsp+0x40], xmm5
000078805cdd06b7  vmovaps [rsp+0x50], xmm6
000078805cdd06bd  vmovaps [rsp+0x60], xmm7
000078805cdd06c3  vmovaps [rsp+0x70], xmm8
000078805cdd06c9  vmovaps [rsp+0x80], xmm9
000078805cdd06d2  vmovaps [rsp+0x90], xmm10
000078805cdd06db  vmovaps [rsp+0xA0], xmm11
000078805cdd06e4  vmovaps [rsp+0xB0], xmm12
000078805cdd06ed  vmovaps [rsp+0xC0], xmm13
000078805cdd06f6  vmovaps [rsp+0xD0], xmm14
000078805cdd06ff  vmovaps [rsp+0xE0], xmm15
000078805cdd0708  sub rsp, 0x30
000078805cdd070c  movaps [rsp], xmm1
000078805cdd0710  movaps [rsp+0x10], xmm15
000078805cdd0716  movaps [rsp+0x20], xmm14
000078805cdd071c  lea rdi, [rsp]
000078805cdd0720  mov esi, 0x00
000078805cdd0725  mov rax, 0x5771AD6EA530
000078805cdd072f  call rax
000078805cdd0731  movaps xmm1, [rsp]
000078805cdd0735  add rsp, 0x30
000078805cdd0739  vmovaps xmm0, [rsp]
000078805cdd073e  vmovaps xmm2, [rsp+0x10]
000078805cdd0744  vmovaps xmm3, [rsp+0x20]
000078805cdd074a  vmovaps xmm4, [rsp+0x30]
000078805cdd0750  vmovaps xmm5, [rsp+0x40]
000078805cdd0756  vmovaps xmm6, [rsp+0x50]
000078805cdd075c  vmovaps xmm7, [rsp+0x60]
000078805cdd0762  vmovaps xmm8, [rsp+0x70]
000078805cdd0768  vmovaps xmm9, [rsp+0x80]
000078805cdd0771  vmovaps xmm10, [rsp+0x90]
000078805cdd077a  vmovaps xmm11, [rsp+0xA0]
000078805cdd0783  vmovaps xmm12, [rsp+0xB0]
000078805cdd078c  vmovaps xmm13, [rsp+0xC0]
000078805cdd0795  vmovaps xmm14, [rsp+0xD0]
000078805cdd079e  vmovaps xmm15, [rsp+0xE0]
000078805cdd07a7  add rsp, 0xF0
000078805cdd07ae  pop r11
000078805cdd07b0  pop r10
000078805cdd07b2  pop r9
000078805cdd07b4  pop r8
000078805cdd07b6  pop rsi
000078805cdd07b7  pop rdi
000078805cdd07b8  pop rdx
000078805cdd07b9  pop rcx
000078805cdd07ba  pop rax
000078805cdd07bb  add rsp, 0x08
000078805cdd07bf  jmp 0x000078805CDCF581
000078805cdd07c4  sub rsp, 0x08
000078805cdd07c8  push rax
000078805cdd07c9  push rcx
000078805cdd07ca  push rdx
000078805cdd07cb  push rdi
000078805cdd07cc  push rsi
000078805cdd07cd  push r8
000078805cdd07cf  push r9
000078805cdd07d1  push r10
000078805cdd07d3  push r11
000078805cdd07d5  sub rsp, 0xF0
000078805cdd07dc  vmovaps [rsp], xmm0
000078805cdd07e1  vmovaps [rsp+0x10], xmm1
000078805cdd07e7  vmovaps [rsp+0x20], xmm2
000078805cdd07ed  vmovaps [rsp+0x30], xmm3
000078805cdd07f3  vmovaps [rsp+0x40], xmm4
000078805cdd07f9  vmovaps [rsp+0x50], xmm5
000078805cdd07ff  vmovaps [rsp+0x60], xmm6
000078805cdd0805  vmovaps [rsp+0x70], xmm7
000078805cdd080b  vmovaps [rsp+0x80], xmm8
000078805cdd0814  vmovaps [rsp+0x90], xmm9
000078805cdd081d  vmovaps [rsp+0xA0], xmm10
000078805cdd0826  vmovaps [rsp+0xB0], xmm11
000078805cdd082f  vmovaps [rsp+0xC0], xmm12
000078805cdd0838  vmovaps [rsp+0xD0], xmm14
000078805cdd0841  vmovaps [rsp+0xE0], xmm15
000078805cdd084a  sub rsp, 0x30
000078805cdd084e  movaps [rsp], xmm13
000078805cdd0853  movaps [rsp+0x10], xmm1
000078805cdd0858  movaps [rsp+0x20], xmm14
000078805cdd085e  lea rdi, [rsp]
000078805cdd0862  mov esi, 0x00
000078805cdd0867  mov rax, 0x5771AD6EA530
000078805cdd0871  call rax
000078805cdd0873  movaps xmm13, [rsp]
000078805cdd0878  add rsp, 0x30
000078805cdd087c  vmovaps xmm0, [rsp]
000078805cdd0881  vmovaps xmm1, [rsp+0x10]
000078805cdd0887  vmovaps xmm2, [rsp+0x20]
000078805cdd088d  vmovaps xmm3, [rsp+0x30]
000078805cdd0893  vmovaps xmm4, [rsp+0x40]
000078805cdd0899  vmovaps xmm5, [rsp+0x50]
000078805cdd089f  vmovaps xmm6, [rsp+0x60]
000078805cdd08a5  vmovaps xmm7, [rsp+0x70]
000078805cdd08ab  vmovaps xmm8, [rsp+0x80]
000078805cdd08b4  vmovaps xmm9, [rsp+0x90]
000078805cdd08bd  vmovaps xmm10, [rsp+0xA0]
000078805cdd08c6  vmovaps xmm11, [rsp+0xB0]
000078805cdd08cf  vmovaps xmm12, [rsp+0xC0]
000078805cdd08d8  vmovaps xmm14, [rsp+0xD0]
000078805cdd08e1  vmovaps xmm15, [rsp+0xE0]
000078805cdd08ea  add rsp, 0xF0
000078805cdd08f1  pop r11
000078805cdd08f3  pop r10
000078805cdd08f5  pop r9
000078805cdd08f7  pop r8
000078805cdd08f9  pop rsi
000078805cdd08fa  pop rdi
000078805cdd08fb  pop rdx
000078805cdd08fc  pop rcx
000078805cdd08fd  pop rax
000078805cdd08fe  add rsp, 0x08
000078805cdd0902  jmp 0x000078805CDCF5CF
000078805cdd0907  sub rsp, 0x08
000078805cdd090b  push rax
000078805cdd090c  push rcx
000078805cdd090d  push rdx
000078805cdd090e  push rdi
000078805cdd090f  push rsi
000078805cdd0910  push r8
000078805cdd0912  push r9
000078805cdd0914  push r10
000078805cdd0916  push r11
000078805cdd0918  sub rsp, 0xF0
000078805cdd091f  vmovaps [rsp], xmm0
000078805cdd0924  vmovaps [rsp+0x10], xmm1
000078805cdd092a  vmovaps [rsp+0x20], xmm2
000078805cdd0930  vmovaps [rsp+0x30], xmm3
000078805cdd0936  vmovaps [rsp+0x40], xmm4
000078805cdd093c  vmovaps [rsp+0x50], xmm5
000078805cdd0942  vmovaps [rsp+0x60], xmm6
000078805cdd0948  vmovaps [rsp+0x70], xmm7
000078805cdd094e  vmovaps [rsp+0x80], xmm8
000078805cdd0957  vmovaps [rsp+0x90], xmm9
000078805cdd0960  vmovaps [rsp+0xA0], xmm10
000078805cdd0969  vmovaps [rsp+0xB0], xmm11
000078805cdd0972  vmovaps [rsp+0xC0], xmm12
000078805cdd097b  vmovaps [rsp+0xD0], xmm13
000078805cdd0984  vmovaps [rsp+0xE0], xmm14
000078805cdd098d  sub rsp, 0x30
000078805cdd0991  movaps [rsp], xmm15
000078805cdd0996  movaps [rsp+0x10], xmm14
000078805cdd099c  movaps [rsp+0x20], xmm1
000078805cdd09a1  lea rdi, [rsp]
000078805cdd09a5  mov esi, 0x00
000078805cdd09aa  mov rax, 0x5771AD6EA530
000078805cdd09b4  call rax
000078805cdd09b6  movaps xmm15, [rsp]
000078805cdd09bb  add rsp, 0x30
000078805cdd09bf  vmovaps xmm0, [rsp]
000078805cdd09c4  vmovaps xmm1, [rsp+0x10]
000078805cdd09ca  vmovaps xmm2, [rsp+0x20]
000078805cdd09d0  vmovaps xmm3, [rsp+0x30]
000078805cdd09d6  vmovaps xmm4, [rsp+0x40]
000078805cdd09dc  vmovaps xmm5, [rsp+0x50]
000078805cdd09e2  vmovaps xmm6, [rsp+0x60]
000078805cdd09e8  vmovaps xmm7, [rsp+0x70]
000078805cdd09ee  vmovaps xmm8, [rsp+0x80]
000078805cdd09f7  vmovaps xmm9, [rsp+0x90]
000078805cdd0a00  vmovaps xmm10, [rsp+0xA0]
000078805cdd0a09  vmovaps xmm11, [rsp+0xB0]
000078805cdd0a12  vmovaps xmm12, [rsp+0xC0]
000078805cdd0a1b  vmovaps xmm13, [rsp+0xD0]
000078805cdd0a24  vmovaps xmm14, [rsp+0xE0]
000078805cdd0a2d  add rsp, 0xF0
000078805cdd0a34  pop r11
000078805cdd0a36  pop r10
000078805cdd0a38  pop r9
000078805cdd0a3a  pop r8
000078805cdd0a3c  pop rsi
000078805cdd0a3d  pop rdi
000078805cdd0a3e  pop rdx
000078805cdd0a3f  pop rcx
000078805cdd0a40  pop rax
000078805cdd0a41  add rsp, 0x08
000078805cdd0a45  jmp 0x000078805CDCF617
000078805cdd0a4a  sub rsp, 0x08
000078805cdd0a4e  push rax
000078805cdd0a4f  push rcx
000078805cdd0a50  push rdx
000078805cdd0a51  push rdi
000078805cdd0a52  push rsi
000078805cdd0a53  push r8
000078805cdd0a55  push r9
000078805cdd0a57  push r10
000078805cdd0a59  push r11
000078805cdd0a5b  sub rsp, 0xF0
000078805cdd0a62  vmovaps [rsp], xmm0
000078805cdd0a67  vmovaps [rsp+0x10], xmm2
000078805cdd0a6d  vmovaps [rsp+0x20], xmm3
000078805cdd0a73  vmovaps [rsp+0x30], xmm4
000078805cdd0a79  vmovaps [rsp+0x40], xmm5
000078805cdd0a7f  vmovaps [rsp+0x50], xmm6
000078805cdd0a85  vmovaps [rsp+0x60], xmm7
000078805cdd0a8b  vmovaps [rsp+0x70], xmm8
000078805cdd0a91  vmovaps [rsp+0x80], xmm9
000078805cdd0a9a  vmovaps [rsp+0x90], xmm10
000078805cdd0aa3  vmovaps [rsp+0xA0], xmm11
000078805cdd0aac  vmovaps [rsp+0xB0], xmm12
000078805cdd0ab5  vmovaps [rsp+0xC0], xmm13
000078805cdd0abe  vmovaps [rsp+0xD0], xmm14
000078805cdd0ac7  vmovaps [rsp+0xE0], xmm15
000078805cdd0ad0  sub rsp, 0x30
000078805cdd0ad4  movaps [rsp], xmm1
000078805cdd0ad8  movaps [rsp+0x10], xmm14
000078805cdd0ade  movaps [rsp+0x20], xmm10
000078805cdd0ae4  lea rdi, [rsp]
000078805cdd0ae8  mov esi, 0x00
000078805cdd0aed  mov rax, 0x5771AD6EA530
000078805cdd0af7  call rax
000078805cdd0af9  movaps xmm1, [rsp]
000078805cdd0afd  add rsp, 0x30
000078805cdd0b01  vmovaps xmm0, [rsp]
000078805cdd0b06  vmovaps xmm2, [rsp+0x10]
000078805cdd0b0c  vmovaps xmm3, [rsp+0x20]
000078805cdd0b12  vmovaps xmm4, [rsp+0x30]
000078805cdd0b18  vmovaps xmm5, [rsp+0x40]
000078805cdd0b1e  vmovaps xmm6, [rsp+0x50]
000078805cdd0b24  vmovaps xmm7, [rsp+0x60]
000078805cdd0b2a  vmovaps xmm8, [rsp+0x70]
000078805cdd0b30  vmovaps xmm9, [rsp+0x80]
000078805cdd0b39  vmovaps xmm10, [rsp+0x90]
000078805cdd0b42  vmovaps xmm11, [rsp+0xA0]
000078805cdd0b4b  vmovaps xmm12, [rsp+0xB0]
000078805cdd0b54  vmovaps xmm13, [rsp+0xC0]
000078805cdd0b5d  vmovaps xmm14, [rsp+0xD0]
000078805cdd0b66  vmovaps xmm15, [rsp+0xE0]
000078805cdd0b6f  add rsp, 0xF0
000078805cdd0b76  pop r11
000078805cdd0b78  pop r10
000078805cdd0b7a  pop r9
000078805cdd0b7c  pop r8
000078805cdd0b7e  pop rsi
000078805cdd0b7f  pop rdi
000078805cdd0b80  pop rdx
000078805cdd0b81  pop rcx
000078805cdd0b82  pop rax
000078805cdd0b83  add rsp, 0x08
000078805cdd0b87  jmp 0x000078805CDCF631
000078805cdd0b8c  sub rsp, 0x08
000078805cdd0b90  push rax
000078805cdd0b91  push rcx
000078805cdd0b92  push rdx
000078805cdd0b93  push rdi
000078805cdd0b94  push rsi
000078805cdd0b95  push r8
000078805cdd0b97  push r9
000078805cdd0b99  push r10
000078805cdd0b9b  push r11
000078805cdd0b9d  sub rsp, 0xF0
000078805cdd0ba4  vmovaps [rsp], xmm0
000078805cdd0ba9  vmovaps [rsp+0x10], xmm1
000078805cdd0baf  vmovaps [rsp+0x20], xmm2
000078805cdd0bb5  vmovaps [rsp+0x30], xmm3
000078805cdd0bbb  vmovaps [rsp+0x40], xmm4
000078805cdd0bc1  vmovaps [rsp+0x50], xmm5
000078805cdd0bc7  vmovaps [rsp+0x60], xmm6
000078805cdd0bcd  vmovaps [rsp+0x70], xmm7
000078805cdd0bd3  vmovaps [rsp+0x80], xmm8
000078805cdd0bdc  vmovaps [rsp+0x90], xmm9
000078805cdd0be5  vmovaps [rsp+0xA0], xmm10
000078805cdd0bee  vmovaps [rsp+0xB0], xmm11
000078805cdd0bf7  vmovaps [rsp+0xC0], xmm12
000078805cdd0c00  vmovaps [rsp+0xD0], xmm14
000078805cdd0c09  vmovaps [rsp+0xE0], xmm15
000078805cdd0c12  sub rsp, 0x30
000078805cdd0c16  movaps [rsp], xmm13
000078805cdd0c1b  movaps [rsp+0x10], xmm14
000078805cdd0c21  movaps [rsp+0x20], xmm2
000078805cdd0c26  lea rdi, [rsp]
000078805cdd0c2a  mov esi, 0x00
000078805cdd0c2f  mov rax, 0x5771AD6EA530
000078805cdd0c39  call rax
000078805cdd0c3b  movaps xmm13, [rsp]
000078805cdd0c40  add rsp, 0x30
000078805cdd0c44  vmovaps xmm0, [rsp]
000078805cdd0c49  vmovaps xmm1, [rsp+0x10]
000078805cdd0c4f  vmovaps xmm2, [rsp+0x20]
000078805cdd0c55  vmovaps xmm3, [rsp+0x30]
000078805cdd0c5b  vmovaps xmm4, [rsp+0x40]
000078805cdd0c61  vmovaps xmm5, [rsp+0x50]
000078805cdd0c67  vmovaps xmm6, [rsp+0x60]
000078805cdd0c6d  vmovaps xmm7, [rsp+0x70]
000078805cdd0c73  vmovaps xmm8, [rsp+0x80]
000078805cdd0c7c  vmovaps xmm9, [rsp+0x90]
000078805cdd0c85  vmovaps xmm10, [rsp+0xA0]
000078805cdd0c8e  vmovaps xmm11, [rsp+0xB0]
000078805cdd0c97  vmovaps xmm12, [rsp+0xC0]
000078805cdd0ca0  vmovaps xmm14, [rsp+0xD0]
000078805cdd0ca9  vmovaps xmm15, [rsp+0xE0]
000078805cdd0cb2  add rsp, 0xF0
000078805cdd0cb9  pop r11
000078805cdd0cbb  pop r10
000078805cdd0cbd  pop r9
000078805cdd0cbf  pop r8
000078805cdd0cc1  pop rsi
000078805cdd0cc2  pop rdi
000078805cdd0cc3  pop rdx
000078805cdd0cc4  pop rcx
000078805cdd0cc5  pop rax
000078805cdd0cc6  add rsp, 0x08
000078805cdd0cca  jmp 0x000078805CDCF64C
000078805cdd0ccf  sub rsp, 0x08
000078805cdd0cd3  push rax
000078805cdd0cd4  push rcx
000078805cdd0cd5  push rdx
000078805cdd0cd6  push rdi
000078805cdd0cd7  push rsi
000078805cdd0cd8  push r8
000078805cdd0cda  push r9
000078805cdd0cdc  push r10
000078805cdd0cde  push r11
000078805cdd0ce0  sub rsp, 0xF0
000078805cdd0ce7  vmovaps [rsp], xmm0
000078805cdd0cec  vmovaps [rsp+0x10], xmm2
000078805cdd0cf2  vmovaps [rsp+0x20], xmm3
000078805cdd0cf8  vmovaps [rsp+0x30], xmm4
000078805cdd0cfe  vmovaps [rsp+0x40], xmm5
000078805cdd0d04  vmovaps [rsp+0x50], xmm6
000078805cdd0d0a  vmovaps [rsp+0x60], xmm7
000078805cdd0d10  vmovaps [rsp+0x70], xmm8
000078805cdd0d16  vmovaps [rsp+0x80], xmm9
000078805cdd0d1f  vmovaps [rsp+0x90], xmm10
000078805cdd0d28  vmovaps [rsp+0xA0], xmm11
000078805cdd0d31  vmovaps [rsp+0xB0], xmm12
000078805cdd0d3a  vmovaps [rsp+0xC0], xmm13
000078805cdd0d43  vmovaps [rsp+0xD0], xmm14
000078805cdd0d4c  vmovaps [rsp+0xE0], xmm15
000078805cdd0d55  sub rsp, 0x30
000078805cdd0d59  movaps [rsp], xmm1
000078805cdd0d5d  movaps [rsp+0x10], xmm10
000078805cdd0d63  movaps [rsp+0x20], xmm2
000078805cdd0d68  lea rdi, [rsp]
000078805cdd0d6c  mov esi, 0x00
000078805cdd0d71  mov rax, 0x5771AD6EA530
000078805cdd0d7b  call rax
000078805cdd0d7d  movaps xmm1, [rsp]
000078805cdd0d81  add rsp, 0x30
000078805cdd0d85  vmovaps xmm0, [rsp]
000078805cdd0d8a  vmovaps xmm2, [rsp+0x10]
000078805cdd0d90  vmovaps xmm3, [rsp+0x20]
000078805cdd0d96  vmovaps xmm4, [rsp+0x30]
000078805cdd0d9c  vmovaps xmm5, [rsp+0x40]
000078805cdd0da2  vmovaps xmm6, [rsp+0x50]
000078805cdd0da8  vmovaps xmm7, [rsp+0x60]
000078805cdd0dae  vmovaps xmm8, [rsp+0x70]
000078805cdd0db4  vmovaps xmm9, [rsp+0x80]
000078805cdd0dbd  vmovaps xmm10, [rsp+0x90]
000078805cdd0dc6  vmovaps xmm11, [rsp+0xA0]
000078805cdd0dcf  vmovaps xmm12, [rsp+0xB0]
000078805cdd0dd8  vmovaps xmm13, [rsp+0xC0]
000078805cdd0de1  vmovaps xmm14, [rsp+0xD0]
000078805cdd0dea  vmovaps xmm15, [rsp+0xE0]
000078805cdd0df3  add rsp, 0xF0
000078805cdd0dfa  pop r11
000078805cdd0dfc  pop r10
000078805cdd0dfe  pop r9
000078805cdd0e00  pop r8
000078805cdd0e02  pop rsi
000078805cdd0e03  pop rdi
000078805cdd0e04  pop rdx
000078805cdd0e05  pop rcx
000078805cdd0e06  pop rax
000078805cdd0e07  add rsp, 0x08
000078805cdd0e0b  jmp 0x000078805CDCF6B4
000078805cdd0e10  sub rsp, 0x08
000078805cdd0e14  push rax
000078805cdd0e15  push rcx
000078805cdd0e16  push rdx
000078805cdd0e17  push rdi
000078805cdd0e18  push rsi
000078805cdd0e19  push r8
000078805cdd0e1b  push r9
000078805cdd0e1d  push r10
000078805cdd0e1f  push r11
000078805cdd0e21  sub rsp, 0xF0
000078805cdd0e28  vmovaps [rsp], xmm0
000078805cdd0e2d  vmovaps [rsp+0x10], xmm1
000078805cdd0e33  vmovaps [rsp+0x20], xmm2
000078805cdd0e39  vmovaps [rsp+0x30], xmm3
000078805cdd0e3f  vmovaps [rsp+0x40], xmm4
000078805cdd0e45  vmovaps [rsp+0x50], xmm5
000078805cdd0e4b  vmovaps [rsp+0x60], xmm6
000078805cdd0e51  vmovaps [rsp+0x70], xmm7
000078805cdd0e57  vmovaps [rsp+0x80], xmm8
000078805cdd0e60  vmovaps [rsp+0x90], xmm9
000078805cdd0e69  vmovaps [rsp+0xA0], xmm10
000078805cdd0e72  vmovaps [rsp+0xB0], xmm11
000078805cdd0e7b  vmovaps [rsp+0xC0], xmm12
000078805cdd0e84  vmovaps [rsp+0xD0], xmm13
000078805cdd0e8d  vmovaps [rsp+0xE0], xmm14
000078805cdd0e96  sub rsp, 0x30
000078805cdd0e9a  movaps [rsp], xmm15
000078805cdd0e9f  movaps [rsp+0x10], xmm10
000078805cdd0ea5  movaps [rsp+0x20], xmm2
000078805cdd0eaa  lea rdi, [rsp]
000078805cdd0eae  mov esi, 0x00
000078805cdd0eb3  mov rax, 0x5771AD6EA530
000078805cdd0ebd  call rax
000078805cdd0ebf  movaps xmm15, [rsp]
000078805cdd0ec4  add rsp, 0x30
000078805cdd0ec8  vmovaps xmm0, [rsp]
000078805cdd0ecd  vmovaps xmm1, [rsp+0x10]
000078805cdd0ed3  vmovaps xmm2, [rsp+0x20]
000078805cdd0ed9  vmovaps xmm3, [rsp+0x30]
000078805cdd0edf  vmovaps xmm4, [rsp+0x40]
000078805cdd0ee5  vmovaps xmm5, [rsp+0x50]
000078805cdd0eeb  vmovaps xmm6, [rsp+0x60]
000078805cdd0ef1  vmovaps xmm7, [rsp+0x70]
000078805cdd0ef7  vmovaps xmm8, [rsp+0x80]
000078805cdd0f00  vmovaps xmm9, [rsp+0x90]
000078805cdd0f09  vmovaps xmm10, [rsp+0xA0]
000078805cdd0f12  vmovaps xmm11, [rsp+0xB0]
000078805cdd0f1b  vmovaps xmm12, [rsp+0xC0]
000078805cdd0f24  vmovaps xmm13, [rsp+0xD0]
000078805cdd0f2d  vmovaps xmm14, [rsp+0xE0]
000078805cdd0f36  add rsp, 0xF0
000078805cdd0f3d  pop r11
000078805cdd0f3f  pop r10
000078805cdd0f41  pop r9
000078805cdd0f43  pop r8
000078805cdd0f45  pop rsi
000078805cdd0f46  pop rdi
000078805cdd0f47  pop rdx
000078805cdd0f48  pop rcx
000078805cdd0f49  pop rax
000078805cdd0f4a  add rsp, 0x08
000078805cdd0f4e  jmp 0x000078805CDCF706
000078805cdd0f53  sub rsp, 0x08
000078805cdd0f57  push rax
000078805cdd0f58  push rcx
000078805cdd0f59  push rdx
000078805cdd0f5a  push rdi
000078805cdd0f5b  push rsi
000078805cdd0f5c  push r8
000078805cdd0f5e  push r9
000078805cdd0f60  push r10
000078805cdd0f62  push r11
000078805cdd0f64  sub rsp, 0xF0
000078805cdd0f6b  vmovaps [rsp], xmm0
000078805cdd0f70  vmovaps [rsp+0x10], xmm2
000078805cdd0f76  vmovaps [rsp+0x20], xmm3
000078805cdd0f7c  vmovaps [rsp+0x30], xmm4
000078805cdd0f82  vmovaps [rsp+0x40], xmm5
000078805cdd0f88  vmovaps [rsp+0x50], xmm6
000078805cdd0f8e  vmovaps [rsp+0x60], xmm7
000078805cdd0f94  vmovaps [rsp+0x70], xmm8
000078805cdd0f9a  vmovaps [rsp+0x80], xmm9
000078805cdd0fa3  vmovaps [rsp+0x90], xmm10
000078805cdd0fac  vmovaps [rsp+0xA0], xmm11
000078805cdd0fb5  vmovaps [rsp+0xB0], xmm12
000078805cdd0fbe  vmovaps [rsp+0xC0], xmm13
000078805cdd0fc7  vmovaps [rsp+0xD0], xmm14
000078805cdd0fd0  vmovaps [rsp+0xE0], xmm15
000078805cdd0fd9  sub rsp, 0x30
000078805cdd0fdd  movaps [rsp], xmm1
000078805cdd0fe1  movaps [rsp+0x10], xmm10
000078805cdd0fe7  movaps [rsp+0x20], xmm12
000078805cdd0fed  lea rdi, [rsp]
000078805cdd0ff1  mov esi, 0x00
000078805cdd0ff6  mov rax, 0x5771AD6EA530
000078805cdd1000  call rax
000078805cdd1002  movaps xmm1, [rsp]
000078805cdd1006  add rsp, 0x30
000078805cdd100a  vmovaps xmm0, [rsp]
000078805cdd100f  vmovaps xmm2, [rsp+0x10]
000078805cdd1015  vmovaps xmm3, [rsp+0x20]
000078805cdd101b  vmovaps xmm4, [rsp+0x30]
000078805cdd1021  vmovaps xmm5, [rsp+0x40]
000078805cdd1027  vmovaps xmm6, [rsp+0x50]
000078805cdd102d  vmovaps xmm7, [rsp+0x60]
000078805cdd1033  vmovaps xmm8, [rsp+0x70]
000078805cdd1039  vmovaps xmm9, [rsp+0x80]
000078805cdd1042  vmovaps xmm10, [rsp+0x90]
000078805cdd104b  vmovaps xmm11, [rsp+0xA0]
000078805cdd1054  vmovaps xmm12, [rsp+0xB0]
000078805cdd105d  vmovaps xmm13, [rsp+0xC0]
000078805cdd1066  vmovaps xmm14, [rsp+0xD0]
000078805cdd106f  vmovaps xmm15, [rsp+0xE0]
000078805cdd1078  add rsp, 0xF0
000078805cdd107f  pop r11
000078805cdd1081  pop r10
000078805cdd1083  pop r9
000078805cdd1085  pop r8
000078805cdd1087  pop rsi
000078805cdd1088  pop rdi
000078805cdd1089  pop rdx
000078805cdd108a  pop rcx
000078805cdd108b  pop rax
000078805cdd108c  add rsp, 0x08
000078805cdd1090  jmp 0x000078805CDCF732
000078805cdd1095  sub rsp, 0x08
000078805cdd1099  push rax
000078805cdd109a  push rcx
000078805cdd109b  push rdx
000078805cdd109c  push rdi
000078805cdd109d  push rsi
000078805cdd109e  push r8
000078805cdd10a0  push r9
000078805cdd10a2  push r10
000078805cdd10a4  push r11
000078805cdd10a6  sub rsp, 0xF0
000078805cdd10ad  vmovaps [rsp], xmm0
000078805cdd10b2  vmovaps [rsp+0x10], xmm1
000078805cdd10b8  vmovaps [rsp+0x20], xmm2
000078805cdd10be  vmovaps [rsp+0x30], xmm3
000078805cdd10c4  vmovaps [rsp+0x40], xmm4
000078805cdd10ca  vmovaps [rsp+0x50], xmm5
000078805cdd10d0  vmovaps [rsp+0x60], xmm6
000078805cdd10d6  vmovaps [rsp+0x70], xmm7
000078805cdd10dc  vmovaps [rsp+0x80], xmm8
000078805cdd10e5  vmovaps [rsp+0x90], xmm9
000078805cdd10ee  vmovaps [rsp+0xA0], xmm10
000078805cdd10f7  vmovaps [rsp+0xB0], xmm11
000078805cdd1100  vmovaps [rsp+0xC0], xmm12
000078805cdd1109  vmovaps [rsp+0xD0], xmm13
000078805cdd1112  vmovaps [rsp+0xE0], xmm14
000078805cdd111b  sub rsp, 0x30
000078805cdd111f  movaps [rsp], xmm15
000078805cdd1124  movaps [rsp+0x10], xmm10
000078805cdd112a  movaps [rsp+0x20], xmm12
000078805cdd1130  lea rdi, [rsp]
000078805cdd1134  mov esi, 0x00
000078805cdd1139  mov rax, 0x5771AD6EA530
000078805cdd1143  call rax
000078805cdd1145  movaps xmm15, [rsp]
000078805cdd114a  add rsp, 0x30
000078805cdd114e  vmovaps xmm0, [rsp]
000078805cdd1153  vmovaps xmm1, [rsp+0x10]
000078805cdd1159  vmovaps xmm2, [rsp+0x20]
000078805cdd115f  vmovaps xmm3, [rsp+0x30]
000078805cdd1165  vmovaps xmm4, [rsp+0x40]
000078805cdd116b  vmovaps xmm5, [rsp+0x50]
000078805cdd1171  vmovaps xmm6, [rsp+0x60]
000078805cdd1177  vmovaps xmm7, [rsp+0x70]
000078805cdd117d  vmovaps xmm8, [rsp+0x80]
000078805cdd1186  vmovaps xmm9, [rsp+0x90]
000078805cdd118f  vmovaps xmm10, [rsp+0xA0]
000078805cdd1198  vmovaps xmm11, [rsp+0xB0]
000078805cdd11a1  vmovaps xmm12, [rsp+0xC0]
000078805cdd11aa  vmovaps xmm13, [rsp+0xD0]
000078805cdd11b3  vmovaps xmm14, [rsp+0xE0]
000078805cdd11bc  add rsp, 0xF0
000078805cdd11c3  pop r11
000078805cdd11c5  pop r10
000078805cdd11c7  pop r9
000078805cdd11c9  pop r8
000078805cdd11cb  pop rsi
000078805cdd11cc  pop rdi
000078805cdd11cd  pop rdx
000078805cdd11ce  pop rcx
000078805cdd11cf  pop rax
000078805cdd11d0  add rsp, 0x08
000078805cdd11d4  jmp 0x000078805CDCF75E
000078805cdd11d9  call 0x000078805CBFF430
000078805cdd11de  jmp 0x000078805CDCF7EE
000078805cdd11e3  call 0x000078805CBFF430
000078805cdd11e8  jmp 0x000078805CDCF801
000078805cdd11ed  sub rsp, 0x08
000078805cdd11f1  push rax
000078805cdd11f2  push rcx
000078805cdd11f3  push rdx
000078805cdd11f4  push rdi
000078805cdd11f5  push rsi
000078805cdd11f6  push r8
000078805cdd11f8  push r9
000078805cdd11fa  push r10
000078805cdd11fc  push r11
000078805cdd11fe  sub rsp, 0xF0
000078805cdd1205  vmovaps [rsp], xmm0
000078805cdd120a  vmovaps [rsp+0x10], xmm2
000078805cdd1210  vmovaps [rsp+0x20], xmm3
000078805cdd1216  vmovaps [rsp+0x30], xmm4
000078805cdd121c  vmovaps [rsp+0x40], xmm5
000078805cdd1222  vmovaps [rsp+0x50], xmm6
000078805cdd1228  vmovaps [rsp+0x60], xmm7
000078805cdd122e  vmovaps [rsp+0x70], xmm8
000078805cdd1234  vmovaps [rsp+0x80], xmm9
000078805cdd123d  vmovaps [rsp+0x90], xmm10
000078805cdd1246  vmovaps [rsp+0xA0], xmm11
000078805cdd124f  vmovaps [rsp+0xB0], xmm12
000078805cdd1258  vmovaps [rsp+0xC0], xmm13
000078805cdd1261  vmovaps [rsp+0xD0], xmm14
000078805cdd126a  vmovaps [rsp+0xE0], xmm15
000078805cdd1273  sub rsp, 0x30
000078805cdd1277  movaps [rsp], xmm1
000078805cdd127b  movaps [rsp+0x10], xmm13
000078805cdd1281  movaps [rsp+0x20], xmm2
000078805cdd1286  lea rdi, [rsp]
000078805cdd128a  mov esi, 0x00
000078805cdd128f  mov rax, 0x5771AD6EA530
000078805cdd1299  call rax
000078805cdd129b  movaps xmm1, [rsp]
000078805cdd129f  add rsp, 0x30
000078805cdd12a3  vmovaps xmm0, [rsp]
000078805cdd12a8  vmovaps xmm2, [rsp+0x10]
000078805cdd12ae  vmovaps xmm3, [rsp+0x20]
000078805cdd12b4  vmovaps xmm4, [rsp+0x30]
000078805cdd12ba  vmovaps xmm5, [rsp+0x40]
000078805cdd12c0  vmovaps xmm6, [rsp+0x50]
000078805cdd12c6  vmovaps xmm7, [rsp+0x60]
000078805cdd12cc  vmovaps xmm8, [rsp+0x70]
000078805cdd12d2  vmovaps xmm9, [rsp+0x80]
000078805cdd12db  vmovaps xmm10, [rsp+0x90]
000078805cdd12e4  vmovaps xmm11, [rsp+0xA0]
000078805cdd12ed  vmovaps xmm12, [rsp+0xB0]
000078805cdd12f6  vmovaps xmm13, [rsp+0xC0]
000078805cdd12ff  vmovaps xmm14, [rsp+0xD0]
000078805cdd1308  vmovaps xmm15, [rsp+0xE0]
000078805cdd1311  add rsp, 0xF0
000078805cdd1318  pop r11
000078805cdd131a  pop r10
000078805cdd131c  pop r9
000078805cdd131e  pop r8
000078805cdd1320  pop rsi
000078805cdd1321  pop rdi
000078805cdd1322  pop rdx
000078805cdd1323  pop rcx
000078805cdd1324  pop rax
000078805cdd1325  add rsp, 0x08
000078805cdd1329  jmp 0x000078805CDCF82C
000078805cdd132e  call 0x000078805CC0E760
000078805cdd1333  jmp 0x000078805CDCF839
000078805cdd1338  sub rsp, 0x08
000078805cdd133c  push rax
000078805cdd133d  push rcx
000078805cdd133e  push rdx
000078805cdd133f  push rdi
000078805cdd1340  push rsi
000078805cdd1341  push r8
000078805cdd1343  push r9
000078805cdd1345  push r10
000078805cdd1347  push r11
000078805cdd1349  sub rsp, 0xF0
000078805cdd1350  vmovaps [rsp], xmm0
000078805cdd1355  vmovaps [rsp+0x10], xmm1
000078805cdd135b  vmovaps [rsp+0x20], xmm2
000078805cdd1361  vmovaps [rsp+0x30], xmm3
000078805cdd1367  vmovaps [rsp+0x40], xmm4
000078805cdd136d  vmovaps [rsp+0x50], xmm5
000078805cdd1373  vmovaps [rsp+0x60], xmm6
000078805cdd1379  vmovaps [rsp+0x70], xmm7
000078805cdd137f  vmovaps [rsp+0x80], xmm8
000078805cdd1388  vmovaps [rsp+0x90], xmm9
000078805cdd1391  vmovaps [rsp+0xA0], xmm10
000078805cdd139a  vmovaps [rsp+0xB0], xmm11
000078805cdd13a3  vmovaps [rsp+0xC0], xmm12
000078805cdd13ac  vmovaps [rsp+0xD0], xmm14
000078805cdd13b5  vmovaps [rsp+0xE0], xmm15
000078805cdd13be  sub rsp, 0x30
000078805cdd13c2  movaps [rsp], xmm13
000078805cdd13c7  movaps [rsp+0x10], xmm2
000078805cdd13cc  movaps [rsp+0x20], xmm1
000078805cdd13d1  lea rdi, [rsp]
000078805cdd13d5  mov esi, 0x00
000078805cdd13da  mov rax, 0x5771AD6EA530
000078805cdd13e4  call rax
000078805cdd13e6  movaps xmm13, [rsp]
000078805cdd13eb  add rsp, 0x30
000078805cdd13ef  vmovaps xmm0, [rsp]
000078805cdd13f4  vmovaps xmm1, [rsp+0x10]
000078805cdd13fa  vmovaps xmm2, [rsp+0x20]
000078805cdd1400  vmovaps xmm3, [rsp+0x30]
000078805cdd1406  vmovaps xmm4, [rsp+0x40]
000078805cdd140c  vmovaps xmm5, [rsp+0x50]
000078805cdd1412  vmovaps xmm6, [rsp+0x60]
000078805cdd1418  vmovaps xmm7, [rsp+0x70]
000078805cdd141e  vmovaps xmm8, [rsp+0x80]
000078805cdd1427  vmovaps xmm9, [rsp+0x90]
000078805cdd1430  vmovaps xmm10, [rsp+0xA0]
000078805cdd1439  vmovaps xmm11, [rsp+0xB0]
000078805cdd1442  vmovaps xmm12, [rsp+0xC0]
000078805cdd144b  vmovaps xmm14, [rsp+0xD0]
000078805cdd1454  vmovaps xmm15, [rsp+0xE0]
000078805cdd145d  add rsp, 0xF0
000078805cdd1464  pop r11
000078805cdd1466  pop r10
000078805cdd1468  pop r9
000078805cdd146a  pop r8
000078805cdd146c  pop rsi
000078805cdd146d  pop rdi
000078805cdd146e  pop rdx
000078805cdd146f  pop rcx
000078805cdd1470  pop rax
000078805cdd1471  add rsp, 0x08
000078805cdd1475  jmp 0x000078805CDCF878
000078805cdd147a  sub rsp, 0x08
000078805cdd147e  push rax
000078805cdd147f  push rcx
000078805cdd1480  push rdx
000078805cdd1481  push rdi
000078805cdd1482  push rsi
000078805cdd1483  push r8
000078805cdd1485  push r9
000078805cdd1487  push r10
000078805cdd1489  push r11
000078805cdd148b  sub rsp, 0xF0
000078805cdd1492  vmovaps [rsp], xmm0
000078805cdd1497  vmovaps [rsp+0x10], xmm2
000078805cdd149d  vmovaps [rsp+0x20], xmm3
000078805cdd14a3  vmovaps [rsp+0x30], xmm4
000078805cdd14a9  vmovaps [rsp+0x40], xmm5
000078805cdd14af  vmovaps [rsp+0x50], xmm6
000078805cdd14b5  vmovaps [rsp+0x60], xmm7
000078805cdd14bb  vmovaps [rsp+0x70], xmm8
000078805cdd14c1  vmovaps [rsp+0x80], xmm9
000078805cdd14ca  vmovaps [rsp+0x90], xmm10
000078805cdd14d3  vmovaps [rsp+0xA0], xmm11
000078805cdd14dc  vmovaps [rsp+0xB0], xmm12
000078805cdd14e5  vmovaps [rsp+0xC0], xmm13
000078805cdd14ee  vmovaps [rsp+0xD0], xmm14
000078805cdd14f7  vmovaps [rsp+0xE0], xmm15
000078805cdd1500  sub rsp, 0x30
000078805cdd1504  movaps [rsp], xmm1
000078805cdd1508  movaps [rsp+0x10], xmm15
000078805cdd150e  movaps [rsp+0x20], xmm2
000078805cdd1513  lea rdi, [rsp]
000078805cdd1517  mov esi, 0x00
000078805cdd151c  mov rax, 0x5771AD6EA530
000078805cdd1526  call rax
000078805cdd1528  movaps xmm1, [rsp]
000078805cdd152c  add rsp, 0x30
000078805cdd1530  vmovaps xmm0, [rsp]
000078805cdd1535  vmovaps xmm2, [rsp+0x10]
000078805cdd153b  vmovaps xmm3, [rsp+0x20]
000078805cdd1541  vmovaps xmm4, [rsp+0x30]
000078805cdd1547  vmovaps xmm5, [rsp+0x40]
000078805cdd154d  vmovaps xmm6, [rsp+0x50]
000078805cdd1553  vmovaps xmm7, [rsp+0x60]
000078805cdd1559  vmovaps xmm8, [rsp+0x70]
000078805cdd155f  vmovaps xmm9, [rsp+0x80]
000078805cdd1568  vmovaps xmm10, [rsp+0x90]
000078805cdd1571  vmovaps xmm11, [rsp+0xA0]
000078805cdd157a  vmovaps xmm12, [rsp+0xB0]
000078805cdd1583  vmovaps xmm13, [rsp+0xC0]
000078805cdd158c  vmovaps xmm14, [rsp+0xD0]
000078805cdd1595  vmovaps xmm15, [rsp+0xE0]
000078805cdd159e  add rsp, 0xF0
000078805cdd15a5  pop r11
000078805cdd15a7  pop r10
000078805cdd15a9  pop r9
000078805cdd15ab  pop r8
000078805cdd15ad  pop rsi
000078805cdd15ae  pop rdi
000078805cdd15af  pop rdx
000078805cdd15b0  pop rcx
000078805cdd15b1  pop rax
000078805cdd15b2  add rsp, 0x08
000078805cdd15b6  jmp 0x000078805CDCF8AC
000078805cdd15bb  sub rsp, 0x08
000078805cdd15bf  push rax
000078805cdd15c0  push rcx
000078805cdd15c1  push rdx
000078805cdd15c2  push rdi
000078805cdd15c3  push rsi
000078805cdd15c4  push r8
000078805cdd15c6  push r9
000078805cdd15c8  push r10
000078805cdd15ca  push r11
000078805cdd15cc  sub rsp, 0xF0
000078805cdd15d3  vmovaps [rsp], xmm0
000078805cdd15d8  vmovaps [rsp+0x10], xmm1
000078805cdd15de  vmovaps [rsp+0x20], xmm2
000078805cdd15e4  vmovaps [rsp+0x30], xmm3
000078805cdd15ea  vmovaps [rsp+0x40], xmm4
000078805cdd15f0  vmovaps [rsp+0x50], xmm5
000078805cdd15f6  vmovaps [rsp+0x60], xmm6
000078805cdd15fc  vmovaps [rsp+0x70], xmm7
000078805cdd1602  vmovaps [rsp+0x80], xmm8
000078805cdd160b  vmovaps [rsp+0x90], xmm9
000078805cdd1614  vmovaps [rsp+0xA0], xmm10
000078805cdd161d  vmovaps [rsp+0xB0], xmm11
000078805cdd1626  vmovaps [rsp+0xC0], xmm12
000078805cdd162f  vmovaps [rsp+0xD0], xmm13
000078805cdd1638  vmovaps [rsp+0xE0], xmm15
000078805cdd1641  sub rsp, 0x30
000078805cdd1645  movaps [rsp], xmm14
000078805cdd164a  movaps [rsp+0x10], xmm2
000078805cdd164f  movaps [rsp+0x20], xmm15
000078805cdd1655  lea rdi, [rsp]
000078805cdd1659  mov esi, 0x00
000078805cdd165e  mov rax, 0x5771AD6EA530
000078805cdd1668  call rax
000078805cdd166a  movaps xmm14, [rsp]
000078805cdd166f  add rsp, 0x30
000078805cdd1673  vmovaps xmm0, [rsp]
000078805cdd1678  vmovaps xmm1, [rsp+0x10]
000078805cdd167e  vmovaps xmm2, [rsp+0x20]
000078805cdd1684  vmovaps xmm3, [rsp+0x30]
000078805cdd168a  vmovaps xmm4, [rsp+0x40]
000078805cdd1690  vmovaps xmm5, [rsp+0x50]
000078805cdd1696  vmovaps xmm6, [rsp+0x60]
000078805cdd169c  vmovaps xmm7, [rsp+0x70]
000078805cdd16a2  vmovaps xmm8, [rsp+0x80]
000078805cdd16ab  vmovaps xmm9, [rsp+0x90]
000078805cdd16b4  vmovaps xmm10, [rsp+0xA0]
000078805cdd16bd  vmovaps xmm11, [rsp+0xB0]
000078805cdd16c6  vmovaps xmm12, [rsp+0xC0]
000078805cdd16cf  vmovaps xmm13, [rsp+0xD0]
000078805cdd16d8  vmovaps xmm15, [rsp+0xE0]
000078805cdd16e1  add rsp, 0xF0
000078805cdd16e8  pop r11
000078805cdd16ea  pop r10
000078805cdd16ec  pop r9
000078805cdd16ee  pop r8
000078805cdd16f0  pop rsi
000078805cdd16f1  pop rdi
000078805cdd16f2  pop rdx
000078805cdd16f3  pop rcx
000078805cdd16f4  pop rax
000078805cdd16f5  add rsp, 0x08
000078805cdd16f9  jmp 0x000078805CDCF8E7
000078805cdd16fe  sub rsp, 0x08
000078805cdd1702  push rax
000078805cdd1703  push rcx
000078805cdd1704  push rdx
000078805cdd1705  push rdi
000078805cdd1706  push rsi
000078805cdd1707  push r8
000078805cdd1709  push r9
000078805cdd170b  push r10
000078805cdd170d  push r11
000078805cdd170f  sub rsp, 0xF0
000078805cdd1716  vmovaps [rsp], xmm0
000078805cdd171b  vmovaps [rsp+0x10], xmm1
000078805cdd1721  vmovaps [rsp+0x20], xmm2
000078805cdd1727  vmovaps [rsp+0x30], xmm3
000078805cdd172d  vmovaps [rsp+0x40], xmm4
000078805cdd1733  vmovaps [rsp+0x50], xmm5
000078805cdd1739  vmovaps [rsp+0x60], xmm6
000078805cdd173f  vmovaps [rsp+0x70], xmm7
000078805cdd1745  vmovaps [rsp+0x80], xmm8
000078805cdd174e  vmovaps [rsp+0x90], xmm9
000078805cdd1757  vmovaps [rsp+0xA0], xmm10
000078805cdd1760  vmovaps [rsp+0xB0], xmm11
000078805cdd1769  vmovaps [rsp+0xC0], xmm12
000078805cdd1772  vmovaps [rsp+0xD0], xmm13
000078805cdd177b  vmovaps [rsp+0xE0], xmm14
000078805cdd1784  sub rsp, 0x30
000078805cdd1788  movaps [rsp], xmm15
000078805cdd178d  movaps [rsp+0x10], xmm2
000078805cdd1792  movaps [rsp+0x20], xmm1
000078805cdd1797  lea rdi, [rsp]
000078805cdd179b  mov esi, 0x00
000078805cdd17a0  mov rax, 0x5771AD6EA530
000078805cdd17aa  call rax
000078805cdd17ac  movaps xmm15, [rsp]
000078805cdd17b1  add rsp, 0x30
000078805cdd17b5  vmovaps xmm0, [rsp]
000078805cdd17ba  vmovaps xmm1, [rsp+0x10]
000078805cdd17c0  vmovaps xmm2, [rsp+0x20]
000078805cdd17c6  vmovaps xmm3, [rsp+0x30]
000078805cdd17cc  vmovaps xmm4, [rsp+0x40]
000078805cdd17d2  vmovaps xmm5, [rsp+0x50]
000078805cdd17d8  vmovaps xmm6, [rsp+0x60]
000078805cdd17de  vmovaps xmm7, [rsp+0x70]
000078805cdd17e4  vmovaps xmm8, [rsp+0x80]
000078805cdd17ed  vmovaps xmm9, [rsp+0x90]
000078805cdd17f6  vmovaps xmm10, [rsp+0xA0]
000078805cdd17ff  vmovaps xmm11, [rsp+0xB0]
000078805cdd1808  vmovaps xmm12, [rsp+0xC0]
000078805cdd1811  vmovaps xmm13, [rsp+0xD0]
000078805cdd181a  vmovaps xmm14, [rsp+0xE0]
000078805cdd1823  add rsp, 0xF0
000078805cdd182a  pop r11
000078805cdd182c  pop r10
000078805cdd182e  pop r9
000078805cdd1830  pop r8
000078805cdd1832  pop rsi
000078805cdd1833  pop rdi
000078805cdd1834  pop rdx
000078805cdd1835  pop rcx
000078805cdd1836  pop rax
000078805cdd1837  add rsp, 0x08
000078805cdd183b  jmp 0x000078805CDCF923
000078805cdd1840  call 0x000078805CBFF430
000078805cdd1845  jmp 0x000078805CDCF930
000078805cdd184a  sub rsp, 0x08
000078805cdd184e  push rax
000078805cdd184f  push rcx
000078805cdd1850  push rdx
000078805cdd1851  push rdi
000078805cdd1852  push rsi
000078805cdd1853  push r8
000078805cdd1855  push r9
000078805cdd1857  push r10
000078805cdd1859  push r11
000078805cdd185b  sub rsp, 0xF0
000078805cdd1862  vmovaps [rsp], xmm0
000078805cdd1867  vmovaps [rsp+0x10], xmm1
000078805cdd186d  vmovaps [rsp+0x20], xmm3
000078805cdd1873  vmovaps [rsp+0x30], xmm4
000078805cdd1879  vmovaps [rsp+0x40], xmm5
000078805cdd187f  vmovaps [rsp+0x50], xmm6
000078805cdd1885  vmovaps [rsp+0x60], xmm7
000078805cdd188b  vmovaps [rsp+0x70], xmm8
000078805cdd1891  vmovaps [rsp+0x80], xmm9
000078805cdd189a  vmovaps [rsp+0x90], xmm10
000078805cdd18a3  vmovaps [rsp+0xA0], xmm11
000078805cdd18ac  vmovaps [rsp+0xB0], xmm12
000078805cdd18b5  vmovaps [rsp+0xC0], xmm13
000078805cdd18be  vmovaps [rsp+0xD0], xmm14
000078805cdd18c7  vmovaps [rsp+0xE0], xmm15
000078805cdd18d0  sub rsp, 0x30
000078805cdd18d4  movaps [rsp], xmm2
000078805cdd18d8  movaps [rsp+0x10], xmm1
000078805cdd18dd  movaps [rsp+0x20], xmm14
000078805cdd18e3  lea rdi, [rsp]
000078805cdd18e7  mov esi, 0x00
000078805cdd18ec  mov rax, 0x5771AD6EA530
000078805cdd18f6  call rax
000078805cdd18f8  movaps xmm2, [rsp]
000078805cdd18fc  add rsp, 0x30
000078805cdd1900  vmovaps xmm0, [rsp]
000078805cdd1905  vmovaps xmm1, [rsp+0x10]
000078805cdd190b  vmovaps xmm3, [rsp+0x20]
000078805cdd1911  vmovaps xmm4, [rsp+0x30]
000078805cdd1917  vmovaps xmm5, [rsp+0x40]
000078805cdd191d  vmovaps xmm6, [rsp+0x50]
000078805cdd1923  vmovaps xmm7, [rsp+0x60]
000078805cdd1929  vmovaps xmm8, [rsp+0x70]
000078805cdd192f  vmovaps xmm9, [rsp+0x80]
000078805cdd1938  vmovaps xmm10, [rsp+0x90]
000078805cdd1941  vmovaps xmm11, [rsp+0xA0]
000078805cdd194a  vmovaps xmm12, [rsp+0xB0]
000078805cdd1953  vmovaps xmm13, [rsp+0xC0]
000078805cdd195c  vmovaps xmm14, [rsp+0xD0]
000078805cdd1965  vmovaps xmm15, [rsp+0xE0]
000078805cdd196e  add rsp, 0xF0
000078805cdd1975  pop r11
000078805cdd1977  pop r10
000078805cdd1979  pop r9
000078805cdd197b  pop r8
000078805cdd197d  pop rsi
000078805cdd197e  pop rdi
000078805cdd197f  pop rdx
000078805cdd1980  pop rcx
000078805cdd1981  pop rax
000078805cdd1982  add rsp, 0x08
000078805cdd1986  jmp 0x000078805CDCF96D
000078805cdd198b  sub rsp, 0x08
000078805cdd198f  push rax
000078805cdd1990  push rcx
000078805cdd1991  push rdx
000078805cdd1992  push rdi
000078805cdd1993  push rsi
000078805cdd1994  push r8
000078805cdd1996  push r9
000078805cdd1998  push r10
000078805cdd199a  push r11
000078805cdd199c  sub rsp, 0xF0
000078805cdd19a3  vmovaps [rsp], xmm0
000078805cdd19a8  vmovaps [rsp+0x10], xmm1
000078805cdd19ae  vmovaps [rsp+0x20], xmm2
000078805cdd19b4  vmovaps [rsp+0x30], xmm3
000078805cdd19ba  vmovaps [rsp+0x40], xmm4
000078805cdd19c0  vmovaps [rsp+0x50], xmm5
000078805cdd19c6  vmovaps [rsp+0x60], xmm6
000078805cdd19cc  vmovaps [rsp+0x70], xmm7
000078805cdd19d2  vmovaps [rsp+0x80], xmm8
000078805cdd19db  vmovaps [rsp+0x90], xmm9
000078805cdd19e4  vmovaps [rsp+0xA0], xmm10
000078805cdd19ed  vmovaps [rsp+0xB0], xmm11
000078805cdd19f6  vmovaps [rsp+0xC0], xmm12
000078805cdd19ff  vmovaps [rsp+0xD0], xmm13
000078805cdd1a08  vmovaps [rsp+0xE0], xmm14
000078805cdd1a11  sub rsp, 0x30
000078805cdd1a15  movaps [rsp], xmm15
000078805cdd1a1a  movaps [rsp+0x10], xmm14
000078805cdd1a20  movaps [rsp+0x20], xmm1
000078805cdd1a25  lea rdi, [rsp]
000078805cdd1a29  mov esi, 0x00
000078805cdd1a2e  mov rax, 0x5771AD6EA530
000078805cdd1a38  call rax
000078805cdd1a3a  movaps xmm15, [rsp]
000078805cdd1a3f  add rsp, 0x30
000078805cdd1a43  vmovaps xmm0, [rsp]
000078805cdd1a48  vmovaps xmm1, [rsp+0x10]
000078805cdd1a4e  vmovaps xmm2, [rsp+0x20]
000078805cdd1a54  vmovaps xmm3, [rsp+0x30]
000078805cdd1a5a  vmovaps xmm4, [rsp+0x40]
000078805cdd1a60  vmovaps xmm5, [rsp+0x50]
000078805cdd1a66  vmovaps xmm6, [rsp+0x60]
000078805cdd1a6c  vmovaps xmm7, [rsp+0x70]
000078805cdd1a72  vmovaps xmm8, [rsp+0x80]
000078805cdd1a7b  vmovaps xmm9, [rsp+0x90]
000078805cdd1a84  vmovaps xmm10, [rsp+0xA0]
000078805cdd1a8d  vmovaps xmm11, [rsp+0xB0]
000078805cdd1a96  vmovaps xmm12, [rsp+0xC0]
000078805cdd1a9f  vmovaps xmm13, [rsp+0xD0]
000078805cdd1aa8  vmovaps xmm14, [rsp+0xE0]
000078805cdd1ab1  add rsp, 0xF0
000078805cdd1ab8  pop r11
000078805cdd1aba  pop r10
000078805cdd1abc  pop r9
000078805cdd1abe  pop r8
000078805cdd1ac0  pop rsi
000078805cdd1ac1  pop rdi
000078805cdd1ac2  pop rdx
000078805cdd1ac3  pop rcx
000078805cdd1ac4  pop rax
000078805cdd1ac5  add rsp, 0x08
000078805cdd1ac9  jmp 0x000078805CDCF9E7
000078805cdd1ace  call 0x000078805CBFF430
000078805cdd1ad3  jmp 0x000078805CDCF9F4
000078805cdd1ad8  sub rsp, 0x08
000078805cdd1adc  push rax
000078805cdd1add  push rcx
000078805cdd1ade  push rdx
000078805cdd1adf  push rdi
000078805cdd1ae0  push rsi
000078805cdd1ae1  push r8
000078805cdd1ae3  push r9
000078805cdd1ae5  push r10
000078805cdd1ae7  push r11
000078805cdd1ae9  sub rsp, 0xF0
000078805cdd1af0  vmovaps [rsp], xmm0
000078805cdd1af5  vmovaps [rsp+0x10], xmm1
000078805cdd1afb  vmovaps [rsp+0x20], xmm2
000078805cdd1b01  vmovaps [rsp+0x30], xmm3
000078805cdd1b07  vmovaps [rsp+0x40], xmm4
000078805cdd1b0d  vmovaps [rsp+0x50], xmm5
000078805cdd1b13  vmovaps [rsp+0x60], xmm6
000078805cdd1b19  vmovaps [rsp+0x70], xmm7
000078805cdd1b1f  vmovaps [rsp+0x80], xmm8
000078805cdd1b28  vmovaps [rsp+0x90], xmm9
000078805cdd1b31  vmovaps [rsp+0xA0], xmm10
000078805cdd1b3a  vmovaps [rsp+0xB0], xmm11
000078805cdd1b43  vmovaps [rsp+0xC0], xmm12
000078805cdd1b4c  vmovaps [rsp+0xD0], xmm13
000078805cdd1b55  vmovaps [rsp+0xE0], xmm15
000078805cdd1b5e  sub rsp, 0x30
000078805cdd1b62  movaps [rsp], xmm14
000078805cdd1b67  movaps [rsp+0x10], xmm13
000078805cdd1b6d  movaps [rsp+0x20], xmm1
000078805cdd1b72  lea rdi, [rsp]
000078805cdd1b76  mov esi, 0x00
000078805cdd1b7b  mov rax, 0x5771AD6EA530
000078805cdd1b85  call rax
000078805cdd1b87  movaps xmm14, [rsp]
000078805cdd1b8c  add rsp, 0x30
000078805cdd1b90  vmovaps xmm0, [rsp]
000078805cdd1b95  vmovaps xmm1, [rsp+0x10]
000078805cdd1b9b  vmovaps xmm2, [rsp+0x20]
000078805cdd1ba1  vmovaps xmm3, [rsp+0x30]
000078805cdd1ba7  vmovaps xmm4, [rsp+0x40]
000078805cdd1bad  vmovaps xmm5, [rsp+0x50]
000078805cdd1bb3  vmovaps xmm6, [rsp+0x60]
000078805cdd1bb9  vmovaps xmm7, [rsp+0x70]
000078805cdd1bbf  vmovaps xmm8, [rsp+0x80]
000078805cdd1bc8  vmovaps xmm9, [rsp+0x90]
000078805cdd1bd1  vmovaps xmm10, [rsp+0xA0]
000078805cdd1bda  vmovaps xmm11, [rsp+0xB0]
000078805cdd1be3  vmovaps xmm12, [rsp+0xC0]
000078805cdd1bec  vmovaps xmm13, [rsp+0xD0]
000078805cdd1bf5  vmovaps xmm15, [rsp+0xE0]
000078805cdd1bfe  add rsp, 0xF0
000078805cdd1c05  pop r11
000078805cdd1c07  pop r10
000078805cdd1c09  pop r9
000078805cdd1c0b  pop r8
000078805cdd1c0d  pop rsi
000078805cdd1c0e  pop rdi
000078805cdd1c0f  pop rdx
000078805cdd1c10  pop rcx
000078805cdd1c11  pop rax
000078805cdd1c12  add rsp, 0x08
000078805cdd1c16  jmp 0x000078805CDCFAAF
000078805cdd1c1b  sub rsp, 0x08
000078805cdd1c1f  push rax
000078805cdd1c20  push rcx
000078805cdd1c21  push rdx
000078805cdd1c22  push rdi
000078805cdd1c23  push rsi
000078805cdd1c24  push r8
000078805cdd1c26  push r9
000078805cdd1c28  push r10
000078805cdd1c2a  push r11
000078805cdd1c2c  sub rsp, 0xF0
000078805cdd1c33  vmovaps [rsp], xmm0
000078805cdd1c38  vmovaps [rsp+0x10], xmm1
000078805cdd1c3e  vmovaps [rsp+0x20], xmm2
000078805cdd1c44  vmovaps [rsp+0x30], xmm3
000078805cdd1c4a  vmovaps [rsp+0x40], xmm4
000078805cdd1c50  vmovaps [rsp+0x50], xmm5
000078805cdd1c56  vmovaps [rsp+0x60], xmm6
000078805cdd1c5c  vmovaps [rsp+0x70], xmm7
000078805cdd1c62  vmovaps [rsp+0x80], xmm8
000078805cdd1c6b  vmovaps [rsp+0x90], xmm9
000078805cdd1c74  vmovaps [rsp+0xA0], xmm10
000078805cdd1c7d  vmovaps [rsp+0xB0], xmm11
000078805cdd1c86  vmovaps [rsp+0xC0], xmm12
000078805cdd1c8f  vmovaps [rsp+0xD0], xmm13
000078805cdd1c98  vmovaps [rsp+0xE0], xmm14
000078805cdd1ca1  sub rsp, 0x30
000078805cdd1ca5  movaps [rsp], xmm15
000078805cdd1caa  movaps [rsp+0x10], xmm13
000078805cdd1cb0  movaps [rsp+0x20], xmm1
000078805cdd1cb5  lea rdi, [rsp]
000078805cdd1cb9  mov esi, 0x00
000078805cdd1cbe  mov rax, 0x5771AD6EA530
000078805cdd1cc8  call rax
000078805cdd1cca  movaps xmm15, [rsp]
000078805cdd1ccf  add rsp, 0x30
000078805cdd1cd3  vmovaps xmm0, [rsp]
000078805cdd1cd8  vmovaps xmm1, [rsp+0x10]
000078805cdd1cde  vmovaps xmm2, [rsp+0x20]
000078805cdd1ce4  vmovaps xmm3, [rsp+0x30]
000078805cdd1cea  vmovaps xmm4, [rsp+0x40]
000078805cdd1cf0  vmovaps xmm5, [rsp+0x50]
000078805cdd1cf6  vmovaps xmm6, [rsp+0x60]
000078805cdd1cfc  vmovaps xmm7, [rsp+0x70]
000078805cdd1d02  vmovaps xmm8, [rsp+0x80]
000078805cdd1d0b  vmovaps xmm9, [rsp+0x90]
000078805cdd1d14  vmovaps xmm10, [rsp+0xA0]
000078805cdd1d1d  vmovaps xmm11, [rsp+0xB0]
000078805cdd1d26  vmovaps xmm12, [rsp+0xC0]
000078805cdd1d2f  vmovaps xmm13, [rsp+0xD0]
000078805cdd1d38  vmovaps xmm14, [rsp+0xE0]
000078805cdd1d41  add rsp, 0xF0
000078805cdd1d48  pop r11
000078805cdd1d4a  pop r10
000078805cdd1d4c  pop r9
000078805cdd1d4e  pop r8
000078805cdd1d50  pop rsi
000078805cdd1d51  pop rdi
000078805cdd1d52  pop rdx
000078805cdd1d53  pop rcx
000078805cdd1d54  pop rax
000078805cdd1d55  add rsp, 0x08
000078805cdd1d59  jmp 0x000078805CDCFAEB
000078805cdd1d5e  call 0x000078805CBFF430
000078805cdd1d63  jmp 0x000078805CDCFAF8
000078805cdd1d68  sub rsp, 0x08
000078805cdd1d6c  push rax
000078805cdd1d6d  push rcx
000078805cdd1d6e  push rdx
000078805cdd1d6f  push rdi
000078805cdd1d70  push rsi
000078805cdd1d71  push r8
000078805cdd1d73  push r9
000078805cdd1d75  push r10
000078805cdd1d77  push r11
000078805cdd1d79  sub rsp, 0xF0
000078805cdd1d80  vmovaps [rsp], xmm0
000078805cdd1d85  vmovaps [rsp+0x10], xmm1
000078805cdd1d8b  vmovaps [rsp+0x20], xmm2
000078805cdd1d91  vmovaps [rsp+0x30], xmm3
000078805cdd1d97  vmovaps [rsp+0x40], xmm4
000078805cdd1d9d  vmovaps [rsp+0x50], xmm5
000078805cdd1da3  vmovaps [rsp+0x60], xmm6
000078805cdd1da9  vmovaps [rsp+0x70], xmm7
000078805cdd1daf  vmovaps [rsp+0x80], xmm8
000078805cdd1db8  vmovaps [rsp+0x90], xmm9
000078805cdd1dc1  vmovaps [rsp+0xA0], xmm10
000078805cdd1dca  vmovaps [rsp+0xB0], xmm11
000078805cdd1dd3  vmovaps [rsp+0xC0], xmm12
000078805cdd1ddc  vmovaps [rsp+0xD0], xmm13
000078805cdd1de5  vmovaps [rsp+0xE0], xmm15
000078805cdd1dee  sub rsp, 0x30
000078805cdd1df2  movaps [rsp], xmm14
000078805cdd1df7  movaps [rsp+0x10], xmm13
000078805cdd1dfd  movaps [rsp+0x20], xmm2
000078805cdd1e02  lea rdi, [rsp]
000078805cdd1e06  mov esi, 0x00
000078805cdd1e0b  mov rax, 0x5771AD6EA530
000078805cdd1e15  call rax
000078805cdd1e17  movaps xmm14, [rsp]
000078805cdd1e1c  add rsp, 0x30
000078805cdd1e20  vmovaps xmm0, [rsp]
000078805cdd1e25  vmovaps xmm1, [rsp+0x10]
000078805cdd1e2b  vmovaps xmm2, [rsp+0x20]
000078805cdd1e31  vmovaps xmm3, [rsp+0x30]
000078805cdd1e37  vmovaps xmm4, [rsp+0x40]
000078805cdd1e3d  vmovaps xmm5, [rsp+0x50]
000078805cdd1e43  vmovaps xmm6, [rsp+0x60]
000078805cdd1e49  vmovaps xmm7, [rsp+0x70]
000078805cdd1e4f  vmovaps xmm8, [rsp+0x80]
000078805cdd1e58  vmovaps xmm9, [rsp+0x90]
000078805cdd1e61  vmovaps xmm10, [rsp+0xA0]
000078805cdd1e6a  vmovaps xmm11, [rsp+0xB0]
000078805cdd1e73  vmovaps xmm12, [rsp+0xC0]
000078805cdd1e7c  vmovaps xmm13, [rsp+0xD0]
000078805cdd1e85  vmovaps xmm15, [rsp+0xE0]
000078805cdd1e8e  add rsp, 0xF0
000078805cdd1e95  pop r11
000078805cdd1e97  pop r10
000078805cdd1e99  pop r9
000078805cdd1e9b  pop r8
000078805cdd1e9d  pop rsi
000078805cdd1e9e  pop rdi
000078805cdd1e9f  pop rdx
000078805cdd1ea0  pop rcx
000078805cdd1ea1  pop rax
000078805cdd1ea2  add rsp, 0x08
000078805cdd1ea6  jmp 0x000078805CDCFB24
000078805cdd1eab  sub rsp, 0x08
000078805cdd1eaf  push rax
000078805cdd1eb0  push rcx
000078805cdd1eb1  push rdx
000078805cdd1eb2  push rdi
000078805cdd1eb3  push rsi
000078805cdd1eb4  push r8
000078805cdd1eb6  push r9
000078805cdd1eb8  push r10
000078805cdd1eba  push r11
000078805cdd1ebc  sub rsp, 0xF0
000078805cdd1ec3  vmovaps [rsp], xmm0
000078805cdd1ec8  vmovaps [rsp+0x10], xmm2
000078805cdd1ece  vmovaps [rsp+0x20], xmm3
000078805cdd1ed4  vmovaps [rsp+0x30], xmm4
000078805cdd1eda  vmovaps [rsp+0x40], xmm5
000078805cdd1ee0  vmovaps [rsp+0x50], xmm6
000078805cdd1ee6  vmovaps [rsp+0x60], xmm7
000078805cdd1eec  vmovaps [rsp+0x70], xmm8
000078805cdd1ef2  vmovaps [rsp+0x80], xmm9
000078805cdd1efb  vmovaps [rsp+0x90], xmm10
000078805cdd1f04  vmovaps [rsp+0xA0], xmm11
000078805cdd1f0d  vmovaps [rsp+0xB0], xmm12
000078805cdd1f16  vmovaps [rsp+0xC0], xmm13
000078805cdd1f1f  vmovaps [rsp+0xD0], xmm14
000078805cdd1f28  vmovaps [rsp+0xE0], xmm15
000078805cdd1f31  sub rsp, 0x30
000078805cdd1f35  movaps [rsp], xmm1
000078805cdd1f39  movaps [rsp+0x10], xmm13
000078805cdd1f3f  movaps [rsp+0x20], xmm2
000078805cdd1f44  lea rdi, [rsp]
000078805cdd1f48  mov esi, 0x00
000078805cdd1f4d  mov rax, 0x5771AD6EA530
000078805cdd1f57  call rax
000078805cdd1f59  movaps xmm1, [rsp]
000078805cdd1f5d  add rsp, 0x30
000078805cdd1f61  vmovaps xmm0, [rsp]
000078805cdd1f66  vmovaps xmm2, [rsp+0x10]
000078805cdd1f6c  vmovaps xmm3, [rsp+0x20]
000078805cdd1f72  vmovaps xmm4, [rsp+0x30]
000078805cdd1f78  vmovaps xmm5, [rsp+0x40]
000078805cdd1f7e  vmovaps xmm6, [rsp+0x50]
000078805cdd1f84  vmovaps xmm7, [rsp+0x60]
000078805cdd1f8a  vmovaps xmm8, [rsp+0x70]
000078805cdd1f90  vmovaps xmm9, [rsp+0x80]
000078805cdd1f99  vmovaps xmm10, [rsp+0x90]
000078805cdd1fa2  vmovaps xmm11, [rsp+0xA0]
000078805cdd1fab  vmovaps xmm12, [rsp+0xB0]
000078805cdd1fb4  vmovaps xmm13, [rsp+0xC0]
000078805cdd1fbd  vmovaps xmm14, [rsp+0xD0]
000078805cdd1fc6  vmovaps xmm15, [rsp+0xE0]
000078805cdd1fcf  add rsp, 0xF0
000078805cdd1fd6  pop r11
000078805cdd1fd8  pop r10
000078805cdd1fda  pop r9
000078805cdd1fdc  pop r8
000078805cdd1fde  pop rsi
000078805cdd1fdf  pop rdi
000078805cdd1fe0  pop rdx
000078805cdd1fe1  pop rcx
000078805cdd1fe2  pop rax
000078805cdd1fe3  add rsp, 0x08
000078805cdd1fe7  jmp 0x000078805CDCFB52
000078805cdd1fec  sub rsp, 0x08
000078805cdd1ff0  push rax
000078805cdd1ff1  push rcx
000078805cdd1ff2  push rdx
000078805cdd1ff3  push rdi
000078805cdd1ff4  push rsi
000078805cdd1ff5  push r8
000078805cdd1ff7  push r9
000078805cdd1ff9  push r10
000078805cdd1ffb  push r11
000078805cdd1ffd  sub rsp, 0xF0
000078805cdd2004  vmovaps [rsp], xmm0
000078805cdd2009  vmovaps [rsp+0x10], xmm1
000078805cdd200f  vmovaps [rsp+0x20], xmm3
000078805cdd2015  vmovaps [rsp+0x30], xmm4
000078805cdd201b  vmovaps [rsp+0x40], xmm5
000078805cdd2021  vmovaps [rsp+0x50], xmm6
000078805cdd2027  vmovaps [rsp+0x60], xmm7
000078805cdd202d  vmovaps [rsp+0x70], xmm8
000078805cdd2033  vmovaps [rsp+0x80], xmm9
000078805cdd203c  vmovaps [rsp+0x90], xmm10
000078805cdd2045  vmovaps [rsp+0xA0], xmm11
000078805cdd204e  vmovaps [rsp+0xB0], xmm12
000078805cdd2057  vmovaps [rsp+0xC0], xmm13
000078805cdd2060  vmovaps [rsp+0xD0], xmm14
000078805cdd2069  vmovaps [rsp+0xE0], xmm15
000078805cdd2072  sub rsp, 0x30
000078805cdd2076  movaps [rsp], xmm2
000078805cdd207a  movaps [rsp+0x10], xmm1
000078805cdd207f  movaps [rsp+0x20], xmm13
000078805cdd2085  lea rdi, [rsp]
000078805cdd2089  mov esi, 0x00
000078805cdd208e  mov rax, 0x5771AD6EA530
000078805cdd2098  call rax
000078805cdd209a  movaps xmm2, [rsp]
000078805cdd209e  add rsp, 0x30
000078805cdd20a2  vmovaps xmm0, [rsp]
000078805cdd20a7  vmovaps xmm1, [rsp+0x10]
000078805cdd20ad  vmovaps xmm3, [rsp+0x20]
000078805cdd20b3  vmovaps xmm4, [rsp+0x30]
000078805cdd20b9  vmovaps xmm5, [rsp+0x40]
000078805cdd20bf  vmovaps xmm6, [rsp+0x50]
000078805cdd20c5  vmovaps xmm7, [rsp+0x60]
000078805cdd20cb  vmovaps xmm8, [rsp+0x70]
000078805cdd20d1  vmovaps xmm9, [rsp+0x80]
000078805cdd20da  vmovaps xmm10, [rsp+0x90]
000078805cdd20e3  vmovaps xmm11, [rsp+0xA0]
000078805cdd20ec  vmovaps xmm12, [rsp+0xB0]
000078805cdd20f5  vmovaps xmm13, [rsp+0xC0]
000078805cdd20fe  vmovaps xmm14, [rsp+0xD0]
000078805cdd2107  vmovaps xmm15, [rsp+0xE0]
000078805cdd2110  add rsp, 0xF0
000078805cdd2117  pop r11
000078805cdd2119  pop r10
000078805cdd211b  pop r9
000078805cdd211d  pop r8
000078805cdd211f  pop rsi
000078805cdd2120  pop rdi
000078805cdd2121  pop rdx
000078805cdd2122  pop rcx
000078805cdd2123  pop rax
000078805cdd2124  add rsp, 0x08
000078805cdd2128  jmp 0x000078805CDCFBAB
000078805cdd212d  call 0x000078805CBFF430
000078805cdd2132  jmp 0x000078805CDCFBB8
000078805cdd2137  sub rsp, 0x08
000078805cdd213b  push rax
000078805cdd213c  push rcx
000078805cdd213d  push rdx
000078805cdd213e  push rdi
000078805cdd213f  push rsi
000078805cdd2140  push r8
000078805cdd2142  push r9
000078805cdd2144  push r10
000078805cdd2146  push r11
000078805cdd2148  sub rsp, 0xF0
000078805cdd214f  vmovaps [rsp], xmm0
000078805cdd2154  vmovaps [rsp+0x10], xmm1
000078805cdd215a  vmovaps [rsp+0x20], xmm2
000078805cdd2160  vmovaps [rsp+0x30], xmm3
000078805cdd2166  vmovaps [rsp+0x40], xmm4
000078805cdd216c  vmovaps [rsp+0x50], xmm5
000078805cdd2172  vmovaps [rsp+0x60], xmm6
000078805cdd2178  vmovaps [rsp+0x70], xmm7
000078805cdd217e  vmovaps [rsp+0x80], xmm8
000078805cdd2187  vmovaps [rsp+0x90], xmm9
000078805cdd2190  vmovaps [rsp+0xA0], xmm10
000078805cdd2199  vmovaps [rsp+0xB0], xmm11
000078805cdd21a2  vmovaps [rsp+0xC0], xmm12
000078805cdd21ab  vmovaps [rsp+0xD0], xmm13
000078805cdd21b4  vmovaps [rsp+0xE0], xmm14
000078805cdd21bd  sub rsp, 0x30
000078805cdd21c1  movaps [rsp], xmm15
000078805cdd21c6  movaps [rsp+0x10], xmm13
000078805cdd21cc  movaps [rsp+0x20], xmm1
000078805cdd21d1  lea rdi, [rsp]
000078805cdd21d5  mov esi, 0x00
000078805cdd21da  mov rax, 0x5771AD6EA530
000078805cdd21e4  call rax
000078805cdd21e6  movaps xmm15, [rsp]
000078805cdd21eb  add rsp, 0x30
000078805cdd21ef  vmovaps xmm0, [rsp]
000078805cdd21f4  vmovaps xmm1, [rsp+0x10]
000078805cdd21fa  vmovaps xmm2, [rsp+0x20]
000078805cdd2200  vmovaps xmm3, [rsp+0x30]
000078805cdd2206  vmovaps xmm4, [rsp+0x40]
000078805cdd220c  vmovaps xmm5, [rsp+0x50]
000078805cdd2212  vmovaps xmm6, [rsp+0x60]
000078805cdd2218  vmovaps xmm7, [rsp+0x70]
000078805cdd221e  vmovaps xmm8, [rsp+0x80]
000078805cdd2227  vmovaps xmm9, [rsp+0x90]
000078805cdd2230  vmovaps xmm10, [rsp+0xA0]
000078805cdd2239  vmovaps xmm11, [rsp+0xB0]
000078805cdd2242  vmovaps xmm12, [rsp+0xC0]
000078805cdd224b  vmovaps xmm13, [rsp+0xD0]
000078805cdd2254  vmovaps xmm14, [rsp+0xE0]
000078805cdd225d  add rsp, 0xF0
000078805cdd2264  pop r11
000078805cdd2266  pop r10
000078805cdd2268  pop r9
000078805cdd226a  pop r8
000078805cdd226c  pop rsi
000078805cdd226d  pop rdi
000078805cdd226e  pop rdx
000078805cdd226f  pop rcx
000078805cdd2270  pop rax
000078805cdd2271  add rsp, 0x08
000078805cdd2275  jmp 0x000078805CDCFBF7
000078805cdd227a  sub rsp, 0x08
000078805cdd227e  push rax
000078805cdd227f  push rcx
000078805cdd2280  push rdx
000078805cdd2281  push rdi
000078805cdd2282  push rsi
000078805cdd2283  push r8
000078805cdd2285  push r9
000078805cdd2287  push r10
000078805cdd2289  push r11
000078805cdd228b  sub rsp, 0xF0
000078805cdd2292  vmovaps [rsp], xmm0
000078805cdd2297  vmovaps [rsp+0x10], xmm1
000078805cdd229d  vmovaps [rsp+0x20], xmm2
000078805cdd22a3  vmovaps [rsp+0x30], xmm3
000078805cdd22a9  vmovaps [rsp+0x40], xmm4
000078805cdd22af  vmovaps [rsp+0x50], xmm5
000078805cdd22b5  vmovaps [rsp+0x60], xmm6
000078805cdd22bb  vmovaps [rsp+0x70], xmm7
000078805cdd22c1  vmovaps [rsp+0x80], xmm8
000078805cdd22ca  vmovaps [rsp+0x90], xmm9
000078805cdd22d3  vmovaps [rsp+0xA0], xmm10
000078805cdd22dc  vmovaps [rsp+0xB0], xmm11
000078805cdd22e5  vmovaps [rsp+0xC0], xmm12
000078805cdd22ee  vmovaps [rsp+0xD0], xmm13
000078805cdd22f7  vmovaps [rsp+0xE0], xmm15
000078805cdd2300  sub rsp, 0x30
000078805cdd2304  movaps [rsp], xmm14
000078805cdd2309  movaps [rsp+0x10], xmm11
000078805cdd230f  movaps [rsp+0x20], xmm1
000078805cdd2314  lea rdi, [rsp]
000078805cdd2318  mov esi, 0x00
000078805cdd231d  mov rax, 0x5771AD6EA530
000078805cdd2327  call rax
000078805cdd2329  movaps xmm14, [rsp]
000078805cdd232e  add rsp, 0x30
000078805cdd2332  vmovaps xmm0, [rsp]
000078805cdd2337  vmovaps xmm1, [rsp+0x10]
000078805cdd233d  vmovaps xmm2, [rsp+0x20]
000078805cdd2343  vmovaps xmm3, [rsp+0x30]
000078805cdd2349  vmovaps xmm4, [rsp+0x40]
000078805cdd234f  vmovaps xmm5, [rsp+0x50]
000078805cdd2355  vmovaps xmm6, [rsp+0x60]
000078805cdd235b  vmovaps xmm7, [rsp+0x70]
000078805cdd2361  vmovaps xmm8, [rsp+0x80]
000078805cdd236a  vmovaps xmm9, [rsp+0x90]
000078805cdd2373  vmovaps xmm10, [rsp+0xA0]
000078805cdd237c  vmovaps xmm11, [rsp+0xB0]
000078805cdd2385  vmovaps xmm12, [rsp+0xC0]
000078805cdd238e  vmovaps xmm13, [rsp+0xD0]
000078805cdd2397  vmovaps xmm15, [rsp+0xE0]
000078805cdd23a0  add rsp, 0xF0
000078805cdd23a7  pop r11
000078805cdd23a9  pop r10
000078805cdd23ab  pop r9
000078805cdd23ad  pop r8
000078805cdd23af  pop rsi
000078805cdd23b0  pop rdi
000078805cdd23b1  pop rdx
000078805cdd23b2  pop rcx
000078805cdd23b3  pop rax
000078805cdd23b4  add rsp, 0x08
000078805cdd23b8  jmp 0x000078805CDCFC21
000078805cdd23bd  sub rsp, 0x08
000078805cdd23c1  push rax
000078805cdd23c2  push rcx
000078805cdd23c3  push rdx
000078805cdd23c4  push rdi
000078805cdd23c5  push rsi
000078805cdd23c6  push r8
000078805cdd23c8  push r9
000078805cdd23ca  push r10
000078805cdd23cc  push r11
000078805cdd23ce  sub rsp, 0xF0
000078805cdd23d5  vmovaps [rsp], xmm0
000078805cdd23da  vmovaps [rsp+0x10], xmm1
000078805cdd23e0  vmovaps [rsp+0x20], xmm2
000078805cdd23e6  vmovaps [rsp+0x30], xmm3
000078805cdd23ec  vmovaps [rsp+0x40], xmm4
000078805cdd23f2  vmovaps [rsp+0x50], xmm5
000078805cdd23f8  vmovaps [rsp+0x60], xmm6
000078805cdd23fe  vmovaps [rsp+0x70], xmm7
000078805cdd2404  vmovaps [rsp+0x80], xmm8
000078805cdd240d  vmovaps [rsp+0x90], xmm9
000078805cdd2416  vmovaps [rsp+0xA0], xmm10
000078805cdd241f  vmovaps [rsp+0xB0], xmm11
000078805cdd2428  vmovaps [rsp+0xC0], xmm12
000078805cdd2431  vmovaps [rsp+0xD0], xmm14
000078805cdd243a  vmovaps [rsp+0xE0], xmm15
000078805cdd2443  sub rsp, 0x30
000078805cdd2447  movaps [rsp], xmm13
000078805cdd244c  movaps [rsp+0x10], xmm11
000078805cdd2452  movaps [rsp+0x20], xmm1
000078805cdd2457  lea rdi, [rsp]
000078805cdd245b  mov esi, 0x00
000078805cdd2460  mov rax, 0x5771AD6EA530
000078805cdd246a  call rax
000078805cdd246c  movaps xmm13, [rsp]
000078805cdd2471  add rsp, 0x30
000078805cdd2475  vmovaps xmm0, [rsp]
000078805cdd247a  vmovaps xmm1, [rsp+0x10]
000078805cdd2480  vmovaps xmm2, [rsp+0x20]
000078805cdd2486  vmovaps xmm3, [rsp+0x30]
000078805cdd248c  vmovaps xmm4, [rsp+0x40]
000078805cdd2492  vmovaps xmm5, [rsp+0x50]
000078805cdd2498  vmovaps xmm6, [rsp+0x60]
000078805cdd249e  vmovaps xmm7, [rsp+0x70]
000078805cdd24a4  vmovaps xmm8, [rsp+0x80]
000078805cdd24ad  vmovaps xmm9, [rsp+0x90]
000078805cdd24b6  vmovaps xmm10, [rsp+0xA0]
000078805cdd24bf  vmovaps xmm11, [rsp+0xB0]
000078805cdd24c8  vmovaps xmm12, [rsp+0xC0]
000078805cdd24d1  vmovaps xmm14, [rsp+0xD0]
000078805cdd24da  vmovaps xmm15, [rsp+0xE0]
000078805cdd24e3  add rsp, 0xF0
000078805cdd24ea  pop r11
000078805cdd24ec  pop r10
000078805cdd24ee  pop r9
000078805cdd24f0  pop r8
000078805cdd24f2  pop rsi
000078805cdd24f3  pop rdi
000078805cdd24f4  pop rdx
000078805cdd24f5  pop rcx
000078805cdd24f6  pop rax
000078805cdd24f7  add rsp, 0x08
000078805cdd24fb  jmp 0x000078805CDCFC76
000078805cdd2500  call 0x000078805CBFF430
000078805cdd2505  jmp 0x000078805CDCFC83
000078805cdd250a  sub rsp, 0x08
000078805cdd250e  push rax
000078805cdd250f  push rcx
000078805cdd2510  push rdx
000078805cdd2511  push rdi
000078805cdd2512  push rsi
000078805cdd2513  push r8
000078805cdd2515  push r9
000078805cdd2517  push r10
000078805cdd2519  push r11
000078805cdd251b  sub rsp, 0xF0
000078805cdd2522  vmovaps [rsp], xmm0
000078805cdd2527  vmovaps [rsp+0x10], xmm1
000078805cdd252d  vmovaps [rsp+0x20], xmm2
000078805cdd2533  vmovaps [rsp+0x30], xmm3
000078805cdd2539  vmovaps [rsp+0x40], xmm4
000078805cdd253f  vmovaps [rsp+0x50], xmm5
000078805cdd2545  vmovaps [rsp+0x60], xmm6
000078805cdd254b  vmovaps [rsp+0x70], xmm7
000078805cdd2551  vmovaps [rsp+0x80], xmm8
000078805cdd255a  vmovaps [rsp+0x90], xmm9
000078805cdd2563  vmovaps [rsp+0xA0], xmm10
000078805cdd256c  vmovaps [rsp+0xB0], xmm11
000078805cdd2575  vmovaps [rsp+0xC0], xmm12
000078805cdd257e  vmovaps [rsp+0xD0], xmm13
000078805cdd2587  vmovaps [rsp+0xE0], xmm14
000078805cdd2590  sub rsp, 0x30
000078805cdd2594  movaps [rsp], xmm15
000078805cdd2599  movaps [rsp+0x10], xmm11
000078805cdd259f  movaps [rsp+0x20], xmm1
000078805cdd25a4  lea rdi, [rsp]
000078805cdd25a8  mov esi, 0x00
000078805cdd25ad  mov rax, 0x5771AD6EA530
000078805cdd25b7  call rax
000078805cdd25b9  movaps xmm15, [rsp]
000078805cdd25be  add rsp, 0x30
000078805cdd25c2  vmovaps xmm0, [rsp]
000078805cdd25c7  vmovaps xmm1, [rsp+0x10]
000078805cdd25cd  vmovaps xmm2, [rsp+0x20]
000078805cdd25d3  vmovaps xmm3, [rsp+0x30]
000078805cdd25d9  vmovaps xmm4, [rsp+0x40]
000078805cdd25df  vmovaps xmm5, [rsp+0x50]
000078805cdd25e5  vmovaps xmm6, [rsp+0x60]
000078805cdd25eb  vmovaps xmm7, [rsp+0x70]
000078805cdd25f1  vmovaps xmm8, [rsp+0x80]
000078805cdd25fa  vmovaps xmm9, [rsp+0x90]
000078805cdd2603  vmovaps xmm10, [rsp+0xA0]
000078805cdd260c  vmovaps xmm11, [rsp+0xB0]
000078805cdd2615  vmovaps xmm12, [rsp+0xC0]
000078805cdd261e  vmovaps xmm13, [rsp+0xD0]
000078805cdd2627  vmovaps xmm14, [rsp+0xE0]
000078805cdd2630  add rsp, 0xF0
000078805cdd2637  pop r11
000078805cdd2639  pop r10
000078805cdd263b  pop r9
000078805cdd263d  pop r8
000078805cdd263f  pop rsi
000078805cdd2640  pop rdi
000078805cdd2641  pop rdx
000078805cdd2642  pop rcx
000078805cdd2643  pop rax
000078805cdd2644  add rsp, 0x08
000078805cdd2648  jmp 0x000078805CDCFCBC
000078805cdd264d  sub rsp, 0x08
000078805cdd2651  push rax
000078805cdd2652  push rcx
000078805cdd2653  push rdx
000078805cdd2654  push rdi
000078805cdd2655  push rsi
000078805cdd2656  push r8
000078805cdd2658  push r9
000078805cdd265a  push r10
000078805cdd265c  push r11
000078805cdd265e  sub rsp, 0xF0
000078805cdd2665  vmovaps [rsp], xmm0
000078805cdd266a  vmovaps [rsp+0x10], xmm1
000078805cdd2670  vmovaps [rsp+0x20], xmm2
000078805cdd2676  vmovaps [rsp+0x30], xmm3
000078805cdd267c  vmovaps [rsp+0x40], xmm4
000078805cdd2682  vmovaps [rsp+0x50], xmm5
000078805cdd2688  vmovaps [rsp+0x60], xmm6
000078805cdd268e  vmovaps [rsp+0x70], xmm7
000078805cdd2694  vmovaps [rsp+0x80], xmm8
000078805cdd269d  vmovaps [rsp+0x90], xmm9
000078805cdd26a6  vmovaps [rsp+0xA0], xmm10
000078805cdd26af  vmovaps [rsp+0xB0], xmm12
000078805cdd26b8  vmovaps [rsp+0xC0], xmm13
000078805cdd26c1  vmovaps [rsp+0xD0], xmm14
000078805cdd26ca  vmovaps [rsp+0xE0], xmm15
000078805cdd26d3  sub rsp, 0x30
000078805cdd26d7  movaps [rsp], xmm11
000078805cdd26dc  movaps [rsp+0x10], xmm6
000078805cdd26e1  movaps [rsp+0x20], xmm14
000078805cdd26e7  lea rdi, [rsp]
000078805cdd26eb  mov esi, 0x00
000078805cdd26f0  mov rax, 0x5771AD6EA530
000078805cdd26fa  call rax
000078805cdd26fc  movaps xmm11, [rsp]
000078805cdd2701  add rsp, 0x30
000078805cdd2705  vmovaps xmm0, [rsp]
000078805cdd270a  vmovaps xmm1, [rsp+0x10]
000078805cdd2710  vmovaps xmm2, [rsp+0x20]
000078805cdd2716  vmovaps xmm3, [rsp+0x30]
000078805cdd271c  vmovaps xmm4, [rsp+0x40]
000078805cdd2722  vmovaps xmm5, [rsp+0x50]
000078805cdd2728  vmovaps xmm6, [rsp+0x60]
000078805cdd272e  vmovaps xmm7, [rsp+0x70]
000078805cdd2734  vmovaps xmm8, [rsp+0x80]
000078805cdd273d  vmovaps xmm9, [rsp+0x90]
000078805cdd2746  vmovaps xmm10, [rsp+0xA0]
000078805cdd274f  vmovaps xmm12, [rsp+0xB0]
000078805cdd2758  vmovaps xmm13, [rsp+0xC0]
000078805cdd2761  vmovaps xmm14, [rsp+0xD0]
000078805cdd276a  vmovaps xmm15, [rsp+0xE0]
000078805cdd2773  add rsp, 0xF0
000078805cdd277a  pop r11
000078805cdd277c  pop r10
000078805cdd277e  pop r9
000078805cdd2780  pop r8
000078805cdd2782  pop rsi
000078805cdd2783  pop rdi
000078805cdd2784  pop rdx
000078805cdd2785  pop rcx
000078805cdd2786  pop rax
000078805cdd2787  add rsp, 0x08
000078805cdd278b  jmp 0x000078805CDCFD34
000078805cdd2790  call 0x000078805CBFF430
000078805cdd2795  jmp 0x000078805CDCFD3E
000078805cdd279a  sub rsp, 0x08
000078805cdd279e  push rax
000078805cdd279f  push rcx
000078805cdd27a0  push rdx
000078805cdd27a1  push rdi
000078805cdd27a2  push rsi
000078805cdd27a3  push r8
000078805cdd27a5  push r9
000078805cdd27a7  push r10
000078805cdd27a9  push r11
000078805cdd27ab  sub rsp, 0xF0
000078805cdd27b2  vmovaps [rsp], xmm0
000078805cdd27b7  vmovaps [rsp+0x10], xmm1
000078805cdd27bd  vmovaps [rsp+0x20], xmm2
000078805cdd27c3  vmovaps [rsp+0x30], xmm3
000078805cdd27c9  vmovaps [rsp+0x40], xmm4
000078805cdd27cf  vmovaps [rsp+0x50], xmm5
000078805cdd27d5  vmovaps [rsp+0x60], xmm6
000078805cdd27db  vmovaps [rsp+0x70], xmm7
000078805cdd27e1  vmovaps [rsp+0x80], xmm8
000078805cdd27ea  vmovaps [rsp+0x90], xmm9
000078805cdd27f3  vmovaps [rsp+0xA0], xmm10
000078805cdd27fc  vmovaps [rsp+0xB0], xmm11
000078805cdd2805  vmovaps [rsp+0xC0], xmm12
000078805cdd280e  vmovaps [rsp+0xD0], xmm13
000078805cdd2817  vmovaps [rsp+0xE0], xmm15
000078805cdd2820  sub rsp, 0x30
000078805cdd2824  movaps [rsp], xmm14
000078805cdd2829  movaps [rsp+0x10], xmm6
000078805cdd282e  movaps [rsp+0x20], xmm2
000078805cdd2833  lea rdi, [rsp]
000078805cdd2837  mov esi, 0x00
000078805cdd283c  mov rax, 0x5771AD6EA530
000078805cdd2846  call rax
000078805cdd2848  movaps xmm14, [rsp]
000078805cdd284d  add rsp, 0x30
000078805cdd2851  vmovaps xmm0, [rsp]
000078805cdd2856  vmovaps xmm1, [rsp+0x10]
000078805cdd285c  vmovaps xmm2, [rsp+0x20]
000078805cdd2862  vmovaps xmm3, [rsp+0x30]
000078805cdd2868  vmovaps xmm4, [rsp+0x40]
000078805cdd286e  vmovaps xmm5, [rsp+0x50]
000078805cdd2874  vmovaps xmm6, [rsp+0x60]
000078805cdd287a  vmovaps xmm7, [rsp+0x70]
000078805cdd2880  vmovaps xmm8, [rsp+0x80]
000078805cdd2889  vmovaps xmm9, [rsp+0x90]
000078805cdd2892  vmovaps xmm10, [rsp+0xA0]
000078805cdd289b  vmovaps xmm11, [rsp+0xB0]
000078805cdd28a4  vmovaps xmm12, [rsp+0xC0]
000078805cdd28ad  vmovaps xmm13, [rsp+0xD0]
000078805cdd28b6  vmovaps xmm15, [rsp+0xE0]
000078805cdd28bf  add rsp, 0xF0
000078805cdd28c6  pop r11
000078805cdd28c8  pop r10
000078805cdd28ca  pop r9
000078805cdd28cc  pop r8
000078805cdd28ce  pop rsi
000078805cdd28cf  pop rdi
000078805cdd28d0  pop rdx
000078805cdd28d1  pop rcx
000078805cdd28d2  pop rax
000078805cdd28d3  add rsp, 0x08
000078805cdd28d7  jmp 0x000078805CDCFD72
000078805cdd28dc  sub rsp, 0x08
000078805cdd28e0  push rax
000078805cdd28e1  push rcx
000078805cdd28e2  push rdx
000078805cdd28e3  push rdi
000078805cdd28e4  push rsi
000078805cdd28e5  push r8
000078805cdd28e7  push r9
000078805cdd28e9  push r10
000078805cdd28eb  push r11
000078805cdd28ed  sub rsp, 0xF0
000078805cdd28f4  vmovaps [rsp], xmm0
000078805cdd28f9  vmovaps [rsp+0x10], xmm1
000078805cdd28ff  vmovaps [rsp+0x20], xmm2
000078805cdd2905  vmovaps [rsp+0x30], xmm3
000078805cdd290b  vmovaps [rsp+0x40], xmm4
000078805cdd2911  vmovaps [rsp+0x50], xmm5
000078805cdd2917  vmovaps [rsp+0x60], xmm7
000078805cdd291d  vmovaps [rsp+0x70], xmm8
000078805cdd2923  vmovaps [rsp+0x80], xmm9
000078805cdd292c  vmovaps [rsp+0x90], xmm10
000078805cdd2935  vmovaps [rsp+0xA0], xmm11
000078805cdd293e  vmovaps [rsp+0xB0], xmm12
000078805cdd2947  vmovaps [rsp+0xC0], xmm13
000078805cdd2950  vmovaps [rsp+0xD0], xmm14
000078805cdd2959  vmovaps [rsp+0xE0], xmm15
000078805cdd2962  sub rsp, 0x30
000078805cdd2966  movaps [rsp], xmm6
000078805cdd296a  movaps [rsp+0x10], xmm5
000078805cdd296f  movaps [rsp+0x20], xmm1
000078805cdd2974  lea rdi, [rsp]
000078805cdd2978  mov esi, 0x00
000078805cdd297d  mov rax, 0x5771AD6EA530
000078805cdd2987  call rax
000078805cdd2989  movaps xmm6, [rsp]
000078805cdd298d  add rsp, 0x30
000078805cdd2991  vmovaps xmm0, [rsp]
000078805cdd2996  vmovaps xmm1, [rsp+0x10]
000078805cdd299c  vmovaps xmm2, [rsp+0x20]
000078805cdd29a2  vmovaps xmm3, [rsp+0x30]
000078805cdd29a8  vmovaps xmm4, [rsp+0x40]
000078805cdd29ae  vmovaps xmm5, [rsp+0x50]
000078805cdd29b4  vmovaps xmm7, [rsp+0x60]
000078805cdd29ba  vmovaps xmm8, [rsp+0x70]
000078805cdd29c0  vmovaps xmm9, [rsp+0x80]
000078805cdd29c9  vmovaps xmm10, [rsp+0x90]
000078805cdd29d2  vmovaps xmm11, [rsp+0xA0]
000078805cdd29db  vmovaps xmm12, [rsp+0xB0]
000078805cdd29e4  vmovaps xmm13, [rsp+0xC0]
000078805cdd29ed  vmovaps xmm14, [rsp+0xD0]
000078805cdd29f6  vmovaps xmm15, [rsp+0xE0]
000078805cdd29ff  add rsp, 0xF0
000078805cdd2a06  pop r11
000078805cdd2a08  pop r10
000078805cdd2a0a  pop r9
000078805cdd2a0c  pop r8
000078805cdd2a0e  pop rsi
000078805cdd2a0f  pop rdi
000078805cdd2a10  pop rdx
000078805cdd2a11  pop rcx
000078805cdd2a12  pop rax
000078805cdd2a13  add rsp, 0x08
000078805cdd2a17  jmp 0x000078805CDCFD98
000078805cdd2a1c  sub rsp, 0x08
000078805cdd2a20  push rax
000078805cdd2a21  push rcx
000078805cdd2a22  push rdx
000078805cdd2a23  push rdi
000078805cdd2a24  push rsi
000078805cdd2a25  push r8
000078805cdd2a27  push r9
000078805cdd2a29  push r10
000078805cdd2a2b  push r11
000078805cdd2a2d  sub rsp, 0xF0
000078805cdd2a34  vmovaps [rsp], xmm0
000078805cdd2a39  vmovaps [rsp+0x10], xmm2
000078805cdd2a3f  vmovaps [rsp+0x20], xmm3
000078805cdd2a45  vmovaps [rsp+0x30], xmm4
000078805cdd2a4b  vmovaps [rsp+0x40], xmm5
000078805cdd2a51  vmovaps [rsp+0x50], xmm6
000078805cdd2a57  vmovaps [rsp+0x60], xmm7
000078805cdd2a5d  vmovaps [rsp+0x70], xmm8
000078805cdd2a63  vmovaps [rsp+0x80], xmm9
000078805cdd2a6c  vmovaps [rsp+0x90], xmm10
000078805cdd2a75  vmovaps [rsp+0xA0], xmm11
000078805cdd2a7e  vmovaps [rsp+0xB0], xmm12
000078805cdd2a87  vmovaps [rsp+0xC0], xmm13
000078805cdd2a90  vmovaps [rsp+0xD0], xmm14
000078805cdd2a99  vmovaps [rsp+0xE0], xmm15
000078805cdd2aa2  sub rsp, 0x30
000078805cdd2aa6  movaps [rsp], xmm1
000078805cdd2aaa  movaps [rsp+0x10], xmm5
000078805cdd2aaf  movaps [rsp+0x20], xmm13
000078805cdd2ab5  lea rdi, [rsp]
000078805cdd2ab9  mov esi, 0x00
000078805cdd2abe  mov rax, 0x5771AD6EA530
000078805cdd2ac8  call rax
000078805cdd2aca  movaps xmm1, [rsp]
000078805cdd2ace  add rsp, 0x30
000078805cdd2ad2  vmovaps xmm0, [rsp]
000078805cdd2ad7  vmovaps xmm2, [rsp+0x10]
000078805cdd2add  vmovaps xmm3, [rsp+0x20]
000078805cdd2ae3  vmovaps xmm4, [rsp+0x30]
000078805cdd2ae9  vmovaps xmm5, [rsp+0x40]
000078805cdd2aef  vmovaps xmm6, [rsp+0x50]
000078805cdd2af5  vmovaps xmm7, [rsp+0x60]
000078805cdd2afb  vmovaps xmm8, [rsp+0x70]
000078805cdd2b01  vmovaps xmm9, [rsp+0x80]
000078805cdd2b0a  vmovaps xmm10, [rsp+0x90]
000078805cdd2b13  vmovaps xmm11, [rsp+0xA0]
000078805cdd2b1c  vmovaps xmm12, [rsp+0xB0]
000078805cdd2b25  vmovaps xmm13, [rsp+0xC0]
000078805cdd2b2e  vmovaps xmm14, [rsp+0xD0]
000078805cdd2b37  vmovaps xmm15, [rsp+0xE0]
000078805cdd2b40  add rsp, 0xF0
000078805cdd2b47  pop r11
000078805cdd2b49  pop r10
000078805cdd2b4b  pop r9
000078805cdd2b4d  pop r8
000078805cdd2b4f  pop rsi
000078805cdd2b50  pop rdi
000078805cdd2b51  pop rdx
000078805cdd2b52  pop rcx
000078805cdd2b53  pop rax
000078805cdd2b54  add rsp, 0x08
000078805cdd2b58  jmp 0x000078805CDCFDB6
000078805cdd2b5d  sub rsp, 0x08
000078805cdd2b61  push rax
000078805cdd2b62  push rcx
000078805cdd2b63  push rdx
000078805cdd2b64  push rdi
000078805cdd2b65  push rsi
000078805cdd2b66  push r8
000078805cdd2b68  push r9
000078805cdd2b6a  push r10
000078805cdd2b6c  push r11
000078805cdd2b6e  sub rsp, 0xF0
000078805cdd2b75  vmovaps [rsp], xmm0
000078805cdd2b7a  vmovaps [rsp+0x10], xmm1
000078805cdd2b80  vmovaps [rsp+0x20], xmm2
000078805cdd2b86  vmovaps [rsp+0x30], xmm3
000078805cdd2b8c  vmovaps [rsp+0x40], xmm4
000078805cdd2b92  vmovaps [rsp+0x50], xmm6
000078805cdd2b98  vmovaps [rsp+0x60], xmm7
000078805cdd2b9e  vmovaps [rsp+0x70], xmm8
000078805cdd2ba4  vmovaps [rsp+0x80], xmm9
000078805cdd2bad  vmovaps [rsp+0x90], xmm10
000078805cdd2bb6  vmovaps [rsp+0xA0], xmm11
000078805cdd2bbf  vmovaps [rsp+0xB0], xmm12
000078805cdd2bc8  vmovaps [rsp+0xC0], xmm13
000078805cdd2bd1  vmovaps [rsp+0xD0], xmm14
000078805cdd2bda  vmovaps [rsp+0xE0], xmm15
000078805cdd2be3  sub rsp, 0x30
000078805cdd2be7  movaps [rsp], xmm5
000078805cdd2beb  movaps [rsp+0x10], xmm2
000078805cdd2bf0  movaps [rsp+0x20], xmm13
000078805cdd2bf6  lea rdi, [rsp]
000078805cdd2bfa  mov esi, 0x00
000078805cdd2bff  mov rax, 0x5771AD6EA530
000078805cdd2c09  call rax
000078805cdd2c0b  movaps xmm5, [rsp]
000078805cdd2c0f  add rsp, 0x30
000078805cdd2c13  vmovaps xmm0, [rsp]
000078805cdd2c18  vmovaps xmm1, [rsp+0x10]
000078805cdd2c1e  vmovaps xmm2, [rsp+0x20]
000078805cdd2c24  vmovaps xmm3, [rsp+0x30]
000078805cdd2c2a  vmovaps xmm4, [rsp+0x40]
000078805cdd2c30  vmovaps xmm6, [rsp+0x50]
000078805cdd2c36  vmovaps xmm7, [rsp+0x60]
000078805cdd2c3c  vmovaps xmm8, [rsp+0x70]
000078805cdd2c42  vmovaps xmm9, [rsp+0x80]
000078805cdd2c4b  vmovaps xmm10, [rsp+0x90]
000078805cdd2c54  vmovaps xmm11, [rsp+0xA0]
000078805cdd2c5d  vmovaps xmm12, [rsp+0xB0]
000078805cdd2c66  vmovaps xmm13, [rsp+0xC0]
000078805cdd2c6f  vmovaps xmm14, [rsp+0xD0]
000078805cdd2c78  vmovaps xmm15, [rsp+0xE0]
000078805cdd2c81  add rsp, 0xF0
000078805cdd2c88  pop r11
000078805cdd2c8a  pop r10
000078805cdd2c8c  pop r9
000078805cdd2c8e  pop r8
000078805cdd2c90  pop rsi
000078805cdd2c91  pop rdi
000078805cdd2c92  pop rdx
000078805cdd2c93  pop rcx
000078805cdd2c94  pop rax
000078805cdd2c95  add rsp, 0x08
000078805cdd2c99  jmp 0x000078805CDCFDEC
000078805cdd2c9e  sub rsp, 0x08
000078805cdd2ca2  push rax
000078805cdd2ca3  push rcx
000078805cdd2ca4  push rdx
000078805cdd2ca5  push rdi
000078805cdd2ca6  push rsi
000078805cdd2ca7  push r8
000078805cdd2ca9  push r9
000078805cdd2cab  push r10
000078805cdd2cad  push r11
000078805cdd2caf  sub rsp, 0xF0
000078805cdd2cb6  vmovaps [rsp], xmm0
000078805cdd2cbb  vmovaps [rsp+0x10], xmm1
000078805cdd2cc1  vmovaps [rsp+0x20], xmm2
000078805cdd2cc7  vmovaps [rsp+0x30], xmm3
000078805cdd2ccd  vmovaps [rsp+0x40], xmm4
000078805cdd2cd3  vmovaps [rsp+0x50], xmm5
000078805cdd2cd9  vmovaps [rsp+0x60], xmm6
000078805cdd2cdf  vmovaps [rsp+0x70], xmm7
000078805cdd2ce5  vmovaps [rsp+0x80], xmm8
000078805cdd2cee  vmovaps [rsp+0x90], xmm9
000078805cdd2cf7  vmovaps [rsp+0xA0], xmm10
000078805cdd2d00  vmovaps [rsp+0xB0], xmm11
000078805cdd2d09  vmovaps [rsp+0xC0], xmm12
000078805cdd2d12  vmovaps [rsp+0xD0], xmm14
000078805cdd2d1b  vmovaps [rsp+0xE0], xmm15
000078805cdd2d24  sub rsp, 0x30
000078805cdd2d28  movaps [rsp], xmm13
000078805cdd2d2d  movaps [rsp+0x10], xmm10
000078805cdd2d33  movaps [rsp+0x20], xmm1
000078805cdd2d38  lea rdi, [rsp]
000078805cdd2d3c  mov esi, 0x00
000078805cdd2d41  mov rax, 0x5771AD6EA530
000078805cdd2d4b  call rax
000078805cdd2d4d  movaps xmm13, [rsp]
000078805cdd2d52  add rsp, 0x30
000078805cdd2d56  vmovaps xmm0, [rsp]
000078805cdd2d5b  vmovaps xmm1, [rsp+0x10]
000078805cdd2d61  vmovaps xmm2, [rsp+0x20]
000078805cdd2d67  vmovaps xmm3, [rsp+0x30]
000078805cdd2d6d  vmovaps xmm4, [rsp+0x40]
000078805cdd2d73  vmovaps xmm5, [rsp+0x50]
000078805cdd2d79  vmovaps xmm6, [rsp+0x60]
000078805cdd2d7f  vmovaps xmm7, [rsp+0x70]
000078805cdd2d85  vmovaps xmm8, [rsp+0x80]
000078805cdd2d8e  vmovaps xmm9, [rsp+0x90]
000078805cdd2d97  vmovaps xmm10, [rsp+0xA0]
000078805cdd2da0  vmovaps xmm11, [rsp+0xB0]
000078805cdd2da9  vmovaps xmm12, [rsp+0xC0]
000078805cdd2db2  vmovaps xmm14, [rsp+0xD0]
000078805cdd2dbb  vmovaps xmm15, [rsp+0xE0]
000078805cdd2dc4  add rsp, 0xF0
000078805cdd2dcb  pop r11
000078805cdd2dcd  pop r10
000078805cdd2dcf  pop r9
000078805cdd2dd1  pop r8
000078805cdd2dd3  pop rsi
000078805cdd2dd4  pop rdi
000078805cdd2dd5  pop rdx
000078805cdd2dd6  pop rcx
000078805cdd2dd7  pop rax
000078805cdd2dd8  add rsp, 0x08
000078805cdd2ddc  jmp 0x000078805CDCFE15
000078805cdd2de1  sub rsp, 0x08
000078805cdd2de5  push rax
000078805cdd2de6  push rcx
000078805cdd2de7  push rdx
000078805cdd2de8  push rdi
000078805cdd2de9  push rsi
000078805cdd2dea  push r8
000078805cdd2dec  push r9
000078805cdd2dee  push r10
000078805cdd2df0  push r11
000078805cdd2df2  sub rsp, 0xF0
000078805cdd2df9  vmovaps [rsp], xmm0
000078805cdd2dfe  vmovaps [rsp+0x10], xmm2
000078805cdd2e04  vmovaps [rsp+0x20], xmm3
000078805cdd2e0a  vmovaps [rsp+0x30], xmm4
000078805cdd2e10  vmovaps [rsp+0x40], xmm5
000078805cdd2e16  vmovaps [rsp+0x50], xmm6
000078805cdd2e1c  vmovaps [rsp+0x60], xmm7
000078805cdd2e22  vmovaps [rsp+0x70], xmm8
000078805cdd2e28  vmovaps [rsp+0x80], xmm9
000078805cdd2e31  vmovaps [rsp+0x90], xmm10
000078805cdd2e3a  vmovaps [rsp+0xA0], xmm11
000078805cdd2e43  vmovaps [rsp+0xB0], xmm12
000078805cdd2e4c  vmovaps [rsp+0xC0], xmm13
000078805cdd2e55  vmovaps [rsp+0xD0], xmm14
000078805cdd2e5e  vmovaps [rsp+0xE0], xmm15
000078805cdd2e67  sub rsp, 0x30
000078805cdd2e6b  movaps [rsp], xmm1
000078805cdd2e6f  movaps [rsp+0x10], xmm15
000078805cdd2e75  movaps [rsp+0x20], xmm10
000078805cdd2e7b  lea rdi, [rsp]
000078805cdd2e7f  mov esi, 0x00
000078805cdd2e84  mov rax, 0x5771AD6EA530
000078805cdd2e8e  call rax
000078805cdd2e90  movaps xmm1, [rsp]
000078805cdd2e94  add rsp, 0x30
000078805cdd2e98  vmovaps xmm0, [rsp]
000078805cdd2e9d  vmovaps xmm2, [rsp+0x10]
000078805cdd2ea3  vmovaps xmm3, [rsp+0x20]
000078805cdd2ea9  vmovaps xmm4, [rsp+0x30]
000078805cdd2eaf  vmovaps xmm5, [rsp+0x40]
000078805cdd2eb5  vmovaps xmm6, [rsp+0x50]
000078805cdd2ebb  vmovaps xmm7, [rsp+0x60]
000078805cdd2ec1  vmovaps xmm8, [rsp+0x70]
000078805cdd2ec7  vmovaps xmm9, [rsp+0x80]
000078805cdd2ed0  vmovaps xmm10, [rsp+0x90]
000078805cdd2ed9  vmovaps xmm11, [rsp+0xA0]
000078805cdd2ee2  vmovaps xmm12, [rsp+0xB0]
000078805cdd2eeb  vmovaps xmm13, [rsp+0xC0]
000078805cdd2ef4  vmovaps xmm14, [rsp+0xD0]
000078805cdd2efd  vmovaps xmm15, [rsp+0xE0]
000078805cdd2f06  add rsp, 0xF0
000078805cdd2f0d  pop r11
000078805cdd2f0f  pop r10
000078805cdd2f11  pop r9
000078805cdd2f13  pop r8
000078805cdd2f15  pop rsi
000078805cdd2f16  pop rdi
000078805cdd2f17  pop rdx
000078805cdd2f18  pop rcx
000078805cdd2f19  pop rax
000078805cdd2f1a  add rsp, 0x08
000078805cdd2f1e  jmp 0x000078805CDCFE34
000078805cdd2f23  sub rsp, 0x08
000078805cdd2f27  push rax
000078805cdd2f28  push rcx
000078805cdd2f29  push rdx
000078805cdd2f2a  push rdi
000078805cdd2f2b  push rsi
000078805cdd2f2c  push r8
000078805cdd2f2e  push r9
000078805cdd2f30  push r10
000078805cdd2f32  push r11
000078805cdd2f34  sub rsp, 0xF0
000078805cdd2f3b  vmovaps [rsp], xmm0
000078805cdd2f40  vmovaps [rsp+0x10], xmm1
000078805cdd2f46  vmovaps [rsp+0x20], xmm2
000078805cdd2f4c  vmovaps [rsp+0x30], xmm3
000078805cdd2f52  vmovaps [rsp+0x40], xmm4
000078805cdd2f58  vmovaps [rsp+0x50], xmm5
000078805cdd2f5e  vmovaps [rsp+0x60], xmm6
000078805cdd2f64  vmovaps [rsp+0x70], xmm7
000078805cdd2f6a  vmovaps [rsp+0x80], xmm8
000078805cdd2f73  vmovaps [rsp+0x90], xmm9
000078805cdd2f7c  vmovaps [rsp+0xA0], xmm10
000078805cdd2f85  vmovaps [rsp+0xB0], xmm11
000078805cdd2f8e  vmovaps [rsp+0xC0], xmm12
000078805cdd2f97  vmovaps [rsp+0xD0], xmm13
000078805cdd2fa0  vmovaps [rsp+0xE0], xmm14
000078805cdd2fa9  sub rsp, 0x30
000078805cdd2fad  movaps [rsp], xmm15
000078805cdd2fb2  movaps [rsp+0x10], xmm10
000078805cdd2fb8  movaps [rsp+0x20], xmm11
000078805cdd2fbe  lea rdi, [rsp]
000078805cdd2fc2  mov esi, 0x00
000078805cdd2fc7  mov rax, 0x5771AD6EA530
000078805cdd2fd1  call rax
000078805cdd2fd3  movaps xmm15, [rsp]
000078805cdd2fd8  add rsp, 0x30
000078805cdd2fdc  vmovaps xmm0, [rsp]
000078805cdd2fe1  vmovaps xmm1, [rsp+0x10]
000078805cdd2fe7  vmovaps xmm2, [rsp+0x20]
000078805cdd2fed  vmovaps xmm3, [rsp+0x30]
000078805cdd2ff3  vmovaps xmm4, [rsp+0x40]
000078805cdd2ff9  vmovaps xmm5, [rsp+0x50]
000078805cdd2fff  vmovaps xmm6, [rsp+0x60]
000078805cdd3005  vmovaps xmm7, [rsp+0x70]
000078805cdd300b  vmovaps xmm8, [rsp+0x80]
000078805cdd3014  vmovaps xmm9, [rsp+0x90]
000078805cdd301d  vmovaps xmm10, [rsp+0xA0]
000078805cdd3026  vmovaps xmm11, [rsp+0xB0]
000078805cdd302f  vmovaps xmm12, [rsp+0xC0]
000078805cdd3038  vmovaps xmm13, [rsp+0xD0]
000078805cdd3041  vmovaps xmm14, [rsp+0xE0]
000078805cdd304a  add rsp, 0xF0
000078805cdd3051  pop r11
000078805cdd3053  pop r10
000078805cdd3055  pop r9
000078805cdd3057  pop r8
000078805cdd3059  pop rsi
000078805cdd305a  pop rdi
000078805cdd305b  pop rdx
000078805cdd305c  pop rcx
000078805cdd305d  pop rax
000078805cdd305e  add rsp, 0x08
000078805cdd3062  jmp 0x000078805CDCFE57
000078805cdd3067  sub rsp, 0x08
000078805cdd306b  push rax
000078805cdd306c  push rcx
000078805cdd306d  push rdx
000078805cdd306e  push rdi
000078805cdd306f  push rsi
000078805cdd3070  push r8
000078805cdd3072  push r9
000078805cdd3074  push r10
000078805cdd3076  push r11
000078805cdd3078  sub rsp, 0xF0
000078805cdd307f  vmovaps [rsp], xmm0
000078805cdd3084  vmovaps [rsp+0x10], xmm1
000078805cdd308a  vmovaps [rsp+0x20], xmm2
000078805cdd3090  vmovaps [rsp+0x30], xmm3
000078805cdd3096  vmovaps [rsp+0x40], xmm4
000078805cdd309c  vmovaps [rsp+0x50], xmm5
000078805cdd30a2  vmovaps [rsp+0x60], xmm6
000078805cdd30a8  vmovaps [rsp+0x70], xmm7
000078805cdd30ae  vmovaps [rsp+0x80], xmm8
000078805cdd30b7  vmovaps [rsp+0x90], xmm9
000078805cdd30c0  vmovaps [rsp+0xA0], xmm11
000078805cdd30c9  vmovaps [rsp+0xB0], xmm12
000078805cdd30d2  vmovaps [rsp+0xC0], xmm13
000078805cdd30db  vmovaps [rsp+0xD0], xmm14
000078805cdd30e4  vmovaps [rsp+0xE0], xmm15
000078805cdd30ed  sub rsp, 0x30
000078805cdd30f1  movaps [rsp], xmm10
000078805cdd30f6  movaps [rsp+0x10], xmm12
000078805cdd30fc  movaps [rsp+0x20], xmm11
000078805cdd3102  lea rdi, [rsp]
000078805cdd3106  mov esi, 0x00
000078805cdd310b  mov rax, 0x5771AD6EA530
000078805cdd3115  call rax
000078805cdd3117  movaps xmm10, [rsp]
000078805cdd311c  add rsp, 0x30
000078805cdd3120  vmovaps xmm0, [rsp]
000078805cdd3125  vmovaps xmm1, [rsp+0x10]
000078805cdd312b  vmovaps xmm2, [rsp+0x20]
000078805cdd3131  vmovaps xmm3, [rsp+0x30]
000078805cdd3137  vmovaps xmm4, [rsp+0x40]
000078805cdd313d  vmovaps xmm5, [rsp+0x50]
000078805cdd3143  vmovaps xmm6, [rsp+0x60]
000078805cdd3149  vmovaps xmm7, [rsp+0x70]
000078805cdd314f  vmovaps xmm8, [rsp+0x80]
000078805cdd3158  vmovaps xmm9, [rsp+0x90]
000078805cdd3161  vmovaps xmm11, [rsp+0xA0]
000078805cdd316a  vmovaps xmm12, [rsp+0xB0]
000078805cdd3173  vmovaps xmm13, [rsp+0xC0]
000078805cdd317c  vmovaps xmm14, [rsp+0xD0]
000078805cdd3185  vmovaps xmm15, [rsp+0xE0]
000078805cdd318e  add rsp, 0xF0
000078805cdd3195  pop r11
000078805cdd3197  pop r10
000078805cdd3199  pop r9
000078805cdd319b  pop r8
000078805cdd319d  pop rsi
000078805cdd319e  pop rdi
000078805cdd319f  pop rdx
000078805cdd31a0  pop rcx
000078805cdd31a1  pop rax
000078805cdd31a2  add rsp, 0x08
000078805cdd31a6  jmp 0x000078805CDCFE80
000078805cdd31ab  sub rsp, 0x08
000078805cdd31af  push rax
000078805cdd31b0  push rcx
000078805cdd31b1  push rdx
000078805cdd31b2  push rdi
000078805cdd31b3  push rsi
000078805cdd31b4  push r8
000078805cdd31b6  push r9
000078805cdd31b8  push r10
000078805cdd31ba  push r11
000078805cdd31bc  sub rsp, 0xF0
000078805cdd31c3  vmovaps [rsp], xmm0
000078805cdd31c8  vmovaps [rsp+0x10], xmm1
000078805cdd31ce  vmovaps [rsp+0x20], xmm2
000078805cdd31d4  vmovaps [rsp+0x30], xmm3
000078805cdd31da  vmovaps [rsp+0x40], xmm4
000078805cdd31e0  vmovaps [rsp+0x50], xmm5
000078805cdd31e6  vmovaps [rsp+0x60], xmm6
000078805cdd31ec  vmovaps [rsp+0x70], xmm7
000078805cdd31f2  vmovaps [rsp+0x80], xmm8
000078805cdd31fb  vmovaps [rsp+0x90], xmm9
000078805cdd3204  vmovaps [rsp+0xA0], xmm10
000078805cdd320d  vmovaps [rsp+0xB0], xmm12
000078805cdd3216  vmovaps [rsp+0xC0], xmm13
000078805cdd321f  vmovaps [rsp+0xD0], xmm14
000078805cdd3228  vmovaps [rsp+0xE0], xmm15
000078805cdd3231  sub rsp, 0x30
000078805cdd3235  movaps [rsp], xmm11
000078805cdd323a  movaps [rsp+0x10], xmm2
000078805cdd323f  movaps [rsp+0x20], xmm12
000078805cdd3245  lea rdi, [rsp]
000078805cdd3249  mov esi, 0x00
000078805cdd324e  mov rax, 0x5771AD6EA530
000078805cdd3258  call rax
000078805cdd325a  movaps xmm11, [rsp]
000078805cdd325f  add rsp, 0x30
000078805cdd3263  vmovaps xmm0, [rsp]
000078805cdd3268  vmovaps xmm1, [rsp+0x10]
000078805cdd326e  vmovaps xmm2, [rsp+0x20]
000078805cdd3274  vmovaps xmm3, [rsp+0x30]
000078805cdd327a  vmovaps xmm4, [rsp+0x40]
000078805cdd3280  vmovaps xmm5, [rsp+0x50]
000078805cdd3286  vmovaps xmm6, [rsp+0x60]
000078805cdd328c  vmovaps xmm7, [rsp+0x70]
000078805cdd3292  vmovaps xmm8, [rsp+0x80]
000078805cdd329b  vmovaps xmm9, [rsp+0x90]
000078805cdd32a4  vmovaps xmm10, [rsp+0xA0]
000078805cdd32ad  vmovaps xmm12, [rsp+0xB0]
000078805cdd32b6  vmovaps xmm13, [rsp+0xC0]
000078805cdd32bf  vmovaps xmm14, [rsp+0xD0]
000078805cdd32c8  vmovaps xmm15, [rsp+0xE0]
000078805cdd32d1  add rsp, 0xF0
000078805cdd32d8  pop r11
000078805cdd32da  pop r10
000078805cdd32dc  pop r9
000078805cdd32de  pop r8
000078805cdd32e0  pop rsi
000078805cdd32e1  pop rdi
000078805cdd32e2  pop rdx
000078805cdd32e3  pop rcx
000078805cdd32e4  pop rax
000078805cdd32e5  add rsp, 0x08
000078805cdd32e9  jmp 0x000078805CDCFEB8
000078805cdd32ee  sub rsp, 0x08
000078805cdd32f2  push rax
000078805cdd32f3  push rcx
000078805cdd32f4  push rdx
000078805cdd32f5  push rdi
000078805cdd32f6  push rsi
000078805cdd32f7  push r8
000078805cdd32f9  push r9
000078805cdd32fb  push r10
000078805cdd32fd  push r11
000078805cdd32ff  sub rsp, 0xF0
000078805cdd3306  vmovaps [rsp], xmm0
000078805cdd330b  vmovaps [rsp+0x10], xmm2
000078805cdd3311  vmovaps [rsp+0x20], xmm3
000078805cdd3317  vmovaps [rsp+0x30], xmm4
000078805cdd331d  vmovaps [rsp+0x40], xmm5
000078805cdd3323  vmovaps [rsp+0x50], xmm6
000078805cdd3329  vmovaps [rsp+0x60], xmm7
000078805cdd332f  vmovaps [rsp+0x70], xmm8
000078805cdd3335  vmovaps [rsp+0x80], xmm9
000078805cdd333e  vmovaps [rsp+0x90], xmm10
000078805cdd3347  vmovaps [rsp+0xA0], xmm11
000078805cdd3350  vmovaps [rsp+0xB0], xmm12
000078805cdd3359  vmovaps [rsp+0xC0], xmm13
000078805cdd3362  vmovaps [rsp+0xD0], xmm14
000078805cdd336b  vmovaps [rsp+0xE0], xmm15
000078805cdd3374  sub rsp, 0x30
000078805cdd3378  movaps [rsp], xmm1
000078805cdd337c  movaps [rsp+0x10], xmm14
000078805cdd3382  movaps [rsp+0x20], xmm6
000078805cdd3387  lea rdi, [rsp]
000078805cdd338b  mov esi, 0x00
000078805cdd3390  mov rax, 0x5771AD6EA530
000078805cdd339a  call rax
000078805cdd339c  movaps xmm1, [rsp]
000078805cdd33a0  add rsp, 0x30
000078805cdd33a4  vmovaps xmm0, [rsp]
000078805cdd33a9  vmovaps xmm2, [rsp+0x10]
000078805cdd33af  vmovaps xmm3, [rsp+0x20]
000078805cdd33b5  vmovaps xmm4, [rsp+0x30]
000078805cdd33bb  vmovaps xmm5, [rsp+0x40]
000078805cdd33c1  vmovaps xmm6, [rsp+0x50]
000078805cdd33c7  vmovaps xmm7, [rsp+0x60]
000078805cdd33cd  vmovaps xmm8, [rsp+0x70]
000078805cdd33d3  vmovaps xmm9, [rsp+0x80]
000078805cdd33dc  vmovaps xmm10, [rsp+0x90]
000078805cdd33e5  vmovaps xmm11, [rsp+0xA0]
000078805cdd33ee  vmovaps xmm12, [rsp+0xB0]
000078805cdd33f7  vmovaps xmm13, [rsp+0xC0]
000078805cdd3400  vmovaps xmm14, [rsp+0xD0]
000078805cdd3409  vmovaps xmm15, [rsp+0xE0]
000078805cdd3412  add rsp, 0xF0
000078805cdd3419  pop r11
000078805cdd341b  pop r10
000078805cdd341d  pop r9
000078805cdd341f  pop r8
000078805cdd3421  pop rsi
000078805cdd3422  pop rdi
000078805cdd3423  pop rdx
000078805cdd3424  pop rcx
000078805cdd3425  pop rax
000078805cdd3426  add rsp, 0x08
000078805cdd342a  jmp 0x000078805CDCFED1
000078805cdd342f  sub rsp, 0x08
000078805cdd3433  push rax
000078805cdd3434  push rcx
000078805cdd3435  push rdx
000078805cdd3436  push rdi
000078805cdd3437  push rsi
000078805cdd3438  push r8
000078805cdd343a  push r9
000078805cdd343c  push r10
000078805cdd343e  push r11
000078805cdd3440  sub rsp, 0xF0
000078805cdd3447  vmovaps [rsp], xmm0
000078805cdd344c  vmovaps [rsp+0x10], xmm1
000078805cdd3452  vmovaps [rsp+0x20], xmm2
000078805cdd3458  vmovaps [rsp+0x30], xmm3
000078805cdd345e  vmovaps [rsp+0x40], xmm4
000078805cdd3464  vmovaps [rsp+0x50], xmm5
000078805cdd346a  vmovaps [rsp+0x60], xmm6
000078805cdd3470  vmovaps [rsp+0x70], xmm7
000078805cdd3476  vmovaps [rsp+0x80], xmm8
000078805cdd347f  vmovaps [rsp+0x90], xmm9
000078805cdd3488  vmovaps [rsp+0xA0], xmm10
000078805cdd3491  vmovaps [rsp+0xB0], xmm11
000078805cdd349a  vmovaps [rsp+0xC0], xmm12
000078805cdd34a3  vmovaps [rsp+0xD0], xmm13
000078805cdd34ac  vmovaps [rsp+0xE0], xmm15
000078805cdd34b5  sub rsp, 0x30
000078805cdd34b9  movaps [rsp], xmm14
000078805cdd34be  movaps [rsp+0x10], xmm12
000078805cdd34c4  movaps [rsp+0x20], xmm5
000078805cdd34c9  lea rdi, [rsp]
000078805cdd34cd  mov esi, 0x00
000078805cdd34d2  mov rax, 0x5771AD6EA530
000078805cdd34dc  call rax
000078805cdd34de  movaps xmm14, [rsp]
000078805cdd34e3  add rsp, 0x30
000078805cdd34e7  vmovaps xmm0, [rsp]
000078805cdd34ec  vmovaps xmm1, [rsp+0x10]
000078805cdd34f2  vmovaps xmm2, [rsp+0x20]
000078805cdd34f8  vmovaps xmm3, [rsp+0x30]
000078805cdd34fe  vmovaps xmm4, [rsp+0x40]
000078805cdd3504  vmovaps xmm5, [rsp+0x50]
000078805cdd350a  vmovaps xmm6, [rsp+0x60]
000078805cdd3510  vmovaps xmm7, [rsp+0x70]
000078805cdd3516  vmovaps xmm8, [rsp+0x80]
000078805cdd351f  vmovaps xmm9, [rsp+0x90]
000078805cdd3528  vmovaps xmm10, [rsp+0xA0]
000078805cdd3531  vmovaps xmm11, [rsp+0xB0]
000078805cdd353a  vmovaps xmm12, [rsp+0xC0]
000078805cdd3543  vmovaps xmm13, [rsp+0xD0]
000078805cdd354c  vmovaps xmm15, [rsp+0xE0]
000078805cdd3555  add rsp, 0xF0
000078805cdd355c  pop r11
000078805cdd355e  pop r10
000078805cdd3560  pop r9
000078805cdd3562  pop r8
000078805cdd3564  pop rsi
000078805cdd3565  pop rdi
000078805cdd3566  pop rdx
000078805cdd3567  pop rcx
000078805cdd3568  pop rax
000078805cdd3569  add rsp, 0x08
000078805cdd356d  jmp 0x000078805CDCFEF1
000078805cdd3572  sub rsp, 0x08
000078805cdd3576  push rax
000078805cdd3577  push rcx
000078805cdd3578  push rdx
000078805cdd3579  push rdi
000078805cdd357a  push rsi
000078805cdd357b  push r8
000078805cdd357d  push r9
000078805cdd357f  push r10
000078805cdd3581  push r11
000078805cdd3583  sub rsp, 0xF0
000078805cdd358a  vmovaps [rsp], xmm0
000078805cdd358f  vmovaps [rsp+0x10], xmm1
000078805cdd3595  vmovaps [rsp+0x20], xmm2
000078805cdd359b  vmovaps [rsp+0x30], xmm3
000078805cdd35a1  vmovaps [rsp+0x40], xmm4
000078805cdd35a7  vmovaps [rsp+0x50], xmm5
000078805cdd35ad  vmovaps [rsp+0x60], xmm7
000078805cdd35b3  vmovaps [rsp+0x70], xmm8
000078805cdd35b9  vmovaps [rsp+0x80], xmm9
000078805cdd35c2  vmovaps [rsp+0x90], xmm10
000078805cdd35cb  vmovaps [rsp+0xA0], xmm11
000078805cdd35d4  vmovaps [rsp+0xB0], xmm12
000078805cdd35dd  vmovaps [rsp+0xC0], xmm13
000078805cdd35e6  vmovaps [rsp+0xD0], xmm14
000078805cdd35ef  vmovaps [rsp+0xE0], xmm15
000078805cdd35f8  sub rsp, 0x30
000078805cdd35fc  movaps [rsp], xmm6
000078805cdd3600  movaps [rsp+0x10], xmm9
000078805cdd3606  movaps [rsp+0x20], xmm12
000078805cdd360c  lea rdi, [rsp]
000078805cdd3610  mov esi, 0x00
000078805cdd3615  mov rax, 0x5771AD6EA530
000078805cdd361f  call rax
000078805cdd3621  movaps xmm6, [rsp]
000078805cdd3625  add rsp, 0x30
000078805cdd3629  vmovaps xmm0, [rsp]
000078805cdd362e  vmovaps xmm1, [rsp+0x10]
000078805cdd3634  vmovaps xmm2, [rsp+0x20]
000078805cdd363a  vmovaps xmm3, [rsp+0x30]
000078805cdd3640  vmovaps xmm4, [rsp+0x40]
000078805cdd3646  vmovaps xmm5, [rsp+0x50]
000078805cdd364c  vmovaps xmm7, [rsp+0x60]
000078805cdd3652  vmovaps xmm8, [rsp+0x70]
000078805cdd3658  vmovaps xmm9, [rsp+0x80]
000078805cdd3661  vmovaps xmm10, [rsp+0x90]
000078805cdd366a  vmovaps xmm11, [rsp+0xA0]
000078805cdd3673  vmovaps xmm12, [rsp+0xB0]
000078805cdd367c  vmovaps xmm13, [rsp+0xC0]
000078805cdd3685  vmovaps xmm14, [rsp+0xD0]
000078805cdd368e  vmovaps xmm15, [rsp+0xE0]
000078805cdd3697  add rsp, 0xF0
000078805cdd369e  pop r11
000078805cdd36a0  pop r10
000078805cdd36a2  pop r9
000078805cdd36a4  pop r8
000078805cdd36a6  pop rsi
000078805cdd36a7  pop rdi
000078805cdd36a8  pop rdx
000078805cdd36a9  pop rcx
000078805cdd36aa  pop rax
000078805cdd36ab  add rsp, 0x08
000078805cdd36af  jmp 0x000078805CDCFF19
000078805cdd36b4  sub rsp, 0x08
000078805cdd36b8  push rax
000078805cdd36b9  push rcx
000078805cdd36ba  push rdx
000078805cdd36bb  push rdi
000078805cdd36bc  push rsi
000078805cdd36bd  push r8
000078805cdd36bf  push r9
000078805cdd36c1  push r10
000078805cdd36c3  push r11
000078805cdd36c5  sub rsp, 0xF0
000078805cdd36cc  vmovaps [rsp], xmm0
000078805cdd36d1  vmovaps [rsp+0x10], xmm1
000078805cdd36d7  vmovaps [rsp+0x20], xmm2
000078805cdd36dd  vmovaps [rsp+0x30], xmm3
000078805cdd36e3  vmovaps [rsp+0x40], xmm4
000078805cdd36e9  vmovaps [rsp+0x50], xmm5
000078805cdd36ef  vmovaps [rsp+0x60], xmm6
000078805cdd36f5  vmovaps [rsp+0x70], xmm7
000078805cdd36fb  vmovaps [rsp+0x80], xmm8
000078805cdd3704  vmovaps [rsp+0x90], xmm9
000078805cdd370d  vmovaps [rsp+0xA0], xmm10
000078805cdd3716  vmovaps [rsp+0xB0], xmm11
000078805cdd371f  vmovaps [rsp+0xC0], xmm13
000078805cdd3728  vmovaps [rsp+0xD0], xmm14
000078805cdd3731  vmovaps [rsp+0xE0], xmm15
000078805cdd373a  sub rsp, 0x30
000078805cdd373e  movaps [rsp], xmm12
000078805cdd3743  movaps [rsp+0x10], xmm15
000078805cdd3749  movaps [rsp+0x20], xmm13
000078805cdd374f  lea rdi, [rsp]
000078805cdd3753  mov esi, 0x00
000078805cdd3758  mov rax, 0x5771AD6EA530
000078805cdd3762  call rax
000078805cdd3764  movaps xmm12, [rsp]
000078805cdd3769  add rsp, 0x30
000078805cdd376d  vmovaps xmm0, [rsp]
000078805cdd3772  vmovaps xmm1, [rsp+0x10]
000078805cdd3778  vmovaps xmm2, [rsp+0x20]
000078805cdd377e  vmovaps xmm3, [rsp+0x30]
000078805cdd3784  vmovaps xmm4, [rsp+0x40]
000078805cdd378a  vmovaps xmm5, [rsp+0x50]
000078805cdd3790  vmovaps xmm6, [rsp+0x60]
000078805cdd3796  vmovaps xmm7, [rsp+0x70]
000078805cdd379c  vmovaps xmm8, [rsp+0x80]
000078805cdd37a5  vmovaps xmm9, [rsp+0x90]
000078805cdd37ae  vmovaps xmm10, [rsp+0xA0]
000078805cdd37b7  vmovaps xmm11, [rsp+0xB0]
000078805cdd37c0  vmovaps xmm13, [rsp+0xC0]
000078805cdd37c9  vmovaps xmm14, [rsp+0xD0]
000078805cdd37d2  vmovaps xmm15, [rsp+0xE0]
000078805cdd37db  add rsp, 0xF0
000078805cdd37e2  pop r11
000078805cdd37e4  pop r10
000078805cdd37e6  pop r9
000078805cdd37e8  pop r8
000078805cdd37ea  pop rsi
000078805cdd37eb  pop rdi
000078805cdd37ec  pop rdx
000078805cdd37ed  pop rcx
000078805cdd37ee  pop rax
000078805cdd37ef  add rsp, 0x08
000078805cdd37f3  jmp 0x000078805CDCFF34
000078805cdd37f8  sub rsp, 0x08
000078805cdd37fc  push rax
000078805cdd37fd  push rcx
000078805cdd37fe  push rdx
000078805cdd37ff  push rdi
000078805cdd3800  push rsi
000078805cdd3801  push r8
000078805cdd3803  push r9
000078805cdd3805  push r10
000078805cdd3807  push r11
000078805cdd3809  sub rsp, 0xF0
000078805cdd3810  vmovaps [rsp], xmm0
000078805cdd3815  vmovaps [rsp+0x10], xmm1
000078805cdd381b  vmovaps [rsp+0x20], xmm2
000078805cdd3821  vmovaps [rsp+0x30], xmm3
000078805cdd3827  vmovaps [rsp+0x40], xmm4
000078805cdd382d  vmovaps [rsp+0x50], xmm5
000078805cdd3833  vmovaps [rsp+0x60], xmm6
000078805cdd3839  vmovaps [rsp+0x70], xmm7
000078805cdd383f  vmovaps [rsp+0x80], xmm8
000078805cdd3848  vmovaps [rsp+0x90], xmm9
000078805cdd3851  vmovaps [rsp+0xA0], xmm10
000078805cdd385a  vmovaps [rsp+0xB0], xmm11
000078805cdd3863  vmovaps [rsp+0xC0], xmm12
000078805cdd386c  vmovaps [rsp+0xD0], xmm13
000078805cdd3875  vmovaps [rsp+0xE0], xmm14
000078805cdd387e  sub rsp, 0x30
000078805cdd3882  movaps [rsp], xmm15
000078805cdd3887  movaps [rsp+0x10], xmm13
000078805cdd388d  movaps [rsp+0x20], xmm10
000078805cdd3893  lea rdi, [rsp]
000078805cdd3897  mov esi, 0x00
000078805cdd389c  mov rax, 0x5771AD6EA530
000078805cdd38a6  call rax
000078805cdd38a8  movaps xmm15, [rsp]
000078805cdd38ad  add rsp, 0x30
000078805cdd38b1  vmovaps xmm0, [rsp]
000078805cdd38b6  vmovaps xmm1, [rsp+0x10]
000078805cdd38bc  vmovaps xmm2, [rsp+0x20]
000078805cdd38c2  vmovaps xmm3, [rsp+0x30]
000078805cdd38c8  vmovaps xmm4, [rsp+0x40]
000078805cdd38ce  vmovaps xmm5, [rsp+0x50]
000078805cdd38d4  vmovaps xmm6, [rsp+0x60]
000078805cdd38da  vmovaps xmm7, [rsp+0x70]
000078805cdd38e0  vmovaps xmm8, [rsp+0x80]
000078805cdd38e9  vmovaps xmm9, [rsp+0x90]
000078805cdd38f2  vmovaps xmm10, [rsp+0xA0]
000078805cdd38fb  vmovaps xmm11, [rsp+0xB0]
000078805cdd3904  vmovaps xmm12, [rsp+0xC0]
000078805cdd390d  vmovaps xmm13, [rsp+0xD0]
000078805cdd3916  vmovaps xmm14, [rsp+0xE0]
000078805cdd391f  add rsp, 0xF0
000078805cdd3926  pop r11
000078805cdd3928  pop r10
000078805cdd392a  pop r9
000078805cdd392c  pop r8
000078805cdd392e  pop rsi
000078805cdd392f  pop rdi
000078805cdd3930  pop rdx
000078805cdd3931  pop rcx
000078805cdd3932  pop rax
000078805cdd3933  add rsp, 0x08
000078805cdd3937  jmp 0x000078805CDCFF55
000078805cdd393c  call 0x000078805CC0C260
000078805cdd3941  jmp 0x000078805CDCFFB0
000078805cdd3946  sub rsp, 0x08
000078805cdd394a  push rax
000078805cdd394b  push rcx
000078805cdd394c  push rdx
000078805cdd394d  push rdi
000078805cdd394e  push rsi
000078805cdd394f  push r8
000078805cdd3951  push r9
000078805cdd3953  push r10
000078805cdd3955  push r11
000078805cdd3957  sub rsp, 0xF0
000078805cdd395e  vmovaps [rsp], xmm0
000078805cdd3963  vmovaps [rsp+0x10], xmm1
000078805cdd3969  vmovaps [rsp+0x20], xmm2
000078805cdd396f  vmovaps [rsp+0x30], xmm3
000078805cdd3975  vmovaps [rsp+0x40], xmm4
000078805cdd397b  vmovaps [rsp+0x50], xmm5
000078805cdd3981  vmovaps [rsp+0x60], xmm6
000078805cdd3987  vmovaps [rsp+0x70], xmm7
000078805cdd398d  vmovaps [rsp+0x80], xmm8
000078805cdd3996  vmovaps [rsp+0x90], xmm10
000078805cdd399f  vmovaps [rsp+0xA0], xmm11
000078805cdd39a8  vmovaps [rsp+0xB0], xmm12
000078805cdd39b1  vmovaps [rsp+0xC0], xmm13
000078805cdd39ba  vmovaps [rsp+0xD0], xmm14
000078805cdd39c3  vmovaps [rsp+0xE0], xmm15
000078805cdd39cc  sub rsp, 0x30
000078805cdd39d0  movaps [rsp], xmm9
000078805cdd39d5  movaps [rsp+0x10], xmm8
000078805cdd39db  movaps [rsp+0x20], xmm10
000078805cdd39e1  lea rdi, [rsp]
000078805cdd39e5  mov esi, 0x00
000078805cdd39ea  mov rax, 0x5771AD6EA530
000078805cdd39f4  call rax
000078805cdd39f6  movaps xmm9, [rsp]
000078805cdd39fb  add rsp, 0x30
000078805cdd39ff  vmovaps xmm0, [rsp]
000078805cdd3a04  vmovaps xmm1, [rsp+0x10]
000078805cdd3a0a  vmovaps xmm2, [rsp+0x20]
000078805cdd3a10  vmovaps xmm3, [rsp+0x30]
000078805cdd3a16  vmovaps xmm4, [rsp+0x40]
000078805cdd3a1c  vmovaps xmm5, [rsp+0x50]
000078805cdd3a22  vmovaps xmm6, [rsp+0x60]
000078805cdd3a28  vmovaps xmm7, [rsp+0x70]
000078805cdd3a2e  vmovaps xmm8, [rsp+0x80]
000078805cdd3a37  vmovaps xmm10, [rsp+0x90]
000078805cdd3a40  vmovaps xmm11, [rsp+0xA0]
000078805cdd3a49  vmovaps xmm12, [rsp+0xB0]
000078805cdd3a52  vmovaps xmm13, [rsp+0xC0]
000078805cdd3a5b  vmovaps xmm14, [rsp+0xD0]
000078805cdd3a64  vmovaps xmm15, [rsp+0xE0]
000078805cdd3a6d  add rsp, 0xF0
000078805cdd3a74  pop r11
000078805cdd3a76  pop r10
000078805cdd3a78  pop r9
000078805cdd3a7a  pop r8
000078805cdd3a7c  pop rsi
000078805cdd3a7d  pop rdi
000078805cdd3a7e  pop rdx
000078805cdd3a7f  pop rcx
000078805cdd3a80  pop rax
000078805cdd3a81  add rsp, 0x08
000078805cdd3a85  jmp 0x000078805CDCFFE1
000078805cdd3a8a  sub rsp, 0x08
000078805cdd3a8e  push rax
000078805cdd3a8f  push rcx
000078805cdd3a90  push rdx
000078805cdd3a91  push rdi
000078805cdd3a92  push rsi
000078805cdd3a93  push r8
000078805cdd3a95  push r9
000078805cdd3a97  push r10
000078805cdd3a99  push r11
000078805cdd3a9b  sub rsp, 0xF0
000078805cdd3aa2  vmovaps [rsp], xmm0
000078805cdd3aa7  vmovaps [rsp+0x10], xmm1
000078805cdd3aad  vmovaps [rsp+0x20], xmm2
000078805cdd3ab3  vmovaps [rsp+0x30], xmm3
000078805cdd3ab9  vmovaps [rsp+0x40], xmm4
000078805cdd3abf  vmovaps [rsp+0x50], xmm5
000078805cdd3ac5  vmovaps [rsp+0x60], xmm6
000078805cdd3acb  vmovaps [rsp+0x70], xmm7
000078805cdd3ad1  vmovaps [rsp+0x80], xmm8
000078805cdd3ada  vmovaps [rsp+0x90], xmm9
000078805cdd3ae3  vmovaps [rsp+0xA0], xmm11
000078805cdd3aec  vmovaps [rsp+0xB0], xmm12
000078805cdd3af5  vmovaps [rsp+0xC0], xmm13
000078805cdd3afe  vmovaps [rsp+0xD0], xmm14
000078805cdd3b07  vmovaps [rsp+0xE0], xmm15
000078805cdd3b10  sub rsp, 0x30
000078805cdd3b14  movaps [rsp], xmm10
000078805cdd3b19  movaps [rsp+0x10], xmm1
000078805cdd3b1e  movaps [rsp+0x20], xmm11
000078805cdd3b24  lea rdi, [rsp]
000078805cdd3b28  mov esi, 0x00
000078805cdd3b2d  mov rax, 0x5771AD6EA530
000078805cdd3b37  call rax
000078805cdd3b39  movaps xmm10, [rsp]
000078805cdd3b3e  add rsp, 0x30
000078805cdd3b42  vmovaps xmm0, [rsp]
000078805cdd3b47  vmovaps xmm1, [rsp+0x10]
000078805cdd3b4d  vmovaps xmm2, [rsp+0x20]
000078805cdd3b53  vmovaps xmm3, [rsp+0x30]
000078805cdd3b59  vmovaps xmm4, [rsp+0x40]
000078805cdd3b5f  vmovaps xmm5, [rsp+0x50]
000078805cdd3b65  vmovaps xmm6, [rsp+0x60]
000078805cdd3b6b  vmovaps xmm7, [rsp+0x70]
000078805cdd3b71  vmovaps xmm8, [rsp+0x80]
000078805cdd3b7a  vmovaps xmm9, [rsp+0x90]
000078805cdd3b83  vmovaps xmm11, [rsp+0xA0]
000078805cdd3b8c  vmovaps xmm12, [rsp+0xB0]
000078805cdd3b95  vmovaps xmm13, [rsp+0xC0]
000078805cdd3b9e  vmovaps xmm14, [rsp+0xD0]
000078805cdd3ba7  vmovaps xmm15, [rsp+0xE0]
000078805cdd3bb0  add rsp, 0xF0
000078805cdd3bb7  pop r11
000078805cdd3bb9  pop r10
000078805cdd3bbb  pop r9
000078805cdd3bbd  pop r8
000078805cdd3bbf  pop rsi
000078805cdd3bc0  pop rdi
000078805cdd3bc1  pop rdx
000078805cdd3bc2  pop rcx
000078805cdd3bc3  pop rax
000078805cdd3bc4  add rsp, 0x08
000078805cdd3bc8  jmp 0x000078805CDCFFFC
000078805cdd3bcd  sub rsp, 0x08
000078805cdd3bd1  push rax
000078805cdd3bd2  push rcx
000078805cdd3bd3  push rdx
000078805cdd3bd4  push rdi
000078805cdd3bd5  push rsi
000078805cdd3bd6  push r8
000078805cdd3bd8  push r9
000078805cdd3bda  push r10
000078805cdd3bdc  push r11
000078805cdd3bde  sub rsp, 0xF0
000078805cdd3be5  vmovaps [rsp], xmm0
000078805cdd3bea  vmovaps [rsp+0x10], xmm2
000078805cdd3bf0  vmovaps [rsp+0x20], xmm3
000078805cdd3bf6  vmovaps [rsp+0x30], xmm4
000078805cdd3bfc  vmovaps [rsp+0x40], xmm5
000078805cdd3c02  vmovaps [rsp+0x50], xmm6
000078805cdd3c08  vmovaps [rsp+0x60], xmm7
000078805cdd3c0e  vmovaps [rsp+0x70], xmm8
000078805cdd3c14  vmovaps [rsp+0x80], xmm9
000078805cdd3c1d  vmovaps [rsp+0x90], xmm10
000078805cdd3c26  vmovaps [rsp+0xA0], xmm11
000078805cdd3c2f  vmovaps [rsp+0xB0], xmm12
000078805cdd3c38  vmovaps [rsp+0xC0], xmm13
000078805cdd3c41  vmovaps [rsp+0xD0], xmm14
000078805cdd3c4a  vmovaps [rsp+0xE0], xmm15
000078805cdd3c53  sub rsp, 0x30
000078805cdd3c57  movaps [rsp], xmm1
000078805cdd3c5b  movaps [rsp+0x10], xmm14
000078805cdd3c61  movaps [rsp+0x20], xmm6
000078805cdd3c66  lea rdi, [rsp]
000078805cdd3c6a  mov esi, 0x00
000078805cdd3c6f  mov rax, 0x5771AD6EA530
000078805cdd3c79  call rax
000078805cdd3c7b  movaps xmm1, [rsp]
000078805cdd3c7f  add rsp, 0x30
000078805cdd3c83  vmovaps xmm0, [rsp]
000078805cdd3c88  vmovaps xmm2, [rsp+0x10]
000078805cdd3c8e  vmovaps xmm3, [rsp+0x20]
000078805cdd3c94  vmovaps xmm4, [rsp+0x30]
000078805cdd3c9a  vmovaps xmm5, [rsp+0x40]
000078805cdd3ca0  vmovaps xmm6, [rsp+0x50]
000078805cdd3ca6  vmovaps xmm7, [rsp+0x60]
000078805cdd3cac  vmovaps xmm8, [rsp+0x70]
000078805cdd3cb2  vmovaps xmm9, [rsp+0x80]
000078805cdd3cbb  vmovaps xmm10, [rsp+0x90]
000078805cdd3cc4  vmovaps xmm11, [rsp+0xA0]
000078805cdd3ccd  vmovaps xmm12, [rsp+0xB0]
000078805cdd3cd6  vmovaps xmm13, [rsp+0xC0]
000078805cdd3cdf  vmovaps xmm14, [rsp+0xD0]
000078805cdd3ce8  vmovaps xmm15, [rsp+0xE0]
000078805cdd3cf1  add rsp, 0xF0
000078805cdd3cf8  pop r11
000078805cdd3cfa  pop r10
000078805cdd3cfc  pop r9
000078805cdd3cfe  pop r8
000078805cdd3d00  pop rsi
000078805cdd3d01  pop rdi
000078805cdd3d02  pop rdx
000078805cdd3d03  pop rcx
000078805cdd3d04  pop rax
000078805cdd3d05  add rsp, 0x08
000078805cdd3d09  jmp 0x000078805CDD0015
000078805cdd3d0e  sub rsp, 0x08
000078805cdd3d12  push rax
000078805cdd3d13  push rcx
000078805cdd3d14  push rdx
000078805cdd3d15  push rdi
000078805cdd3d16  push rsi
000078805cdd3d17  push r8
000078805cdd3d19  push r9
000078805cdd3d1b  push r10
000078805cdd3d1d  push r11
000078805cdd3d1f  sub rsp, 0xF0
000078805cdd3d26  vmovaps [rsp], xmm0
000078805cdd3d2b  vmovaps [rsp+0x10], xmm1
000078805cdd3d31  vmovaps [rsp+0x20], xmm2
000078805cdd3d37  vmovaps [rsp+0x30], xmm3
000078805cdd3d3d  vmovaps [rsp+0x40], xmm4
000078805cdd3d43  vmovaps [rsp+0x50], xmm5
000078805cdd3d49  vmovaps [rsp+0x60], xmm6
000078805cdd3d4f  vmovaps [rsp+0x70], xmm7
000078805cdd3d55  vmovaps [rsp+0x80], xmm8
000078805cdd3d5e  vmovaps [rsp+0x90], xmm9
000078805cdd3d67  vmovaps [rsp+0xA0], xmm10
000078805cdd3d70  vmovaps [rsp+0xB0], xmm12
000078805cdd3d79  vmovaps [rsp+0xC0], xmm13
000078805cdd3d82  vmovaps [rsp+0xD0], xmm14
000078805cdd3d8b  vmovaps [rsp+0xE0], xmm15
000078805cdd3d94  sub rsp, 0x30
000078805cdd3d98  movaps [rsp], xmm11
000078805cdd3d9d  movaps [rsp+0x10], xmm13
000078805cdd3da3  movaps [rsp+0x20], xmm14
000078805cdd3da9  lea rdi, [rsp]
000078805cdd3dad  mov esi, 0x00
000078805cdd3db2  mov rax, 0x5771AD6EA530
000078805cdd3dbc  call rax
000078805cdd3dbe  movaps xmm11, [rsp]
000078805cdd3dc3  add rsp, 0x30
000078805cdd3dc7  vmovaps xmm0, [rsp]
000078805cdd3dcc  vmovaps xmm1, [rsp+0x10]
000078805cdd3dd2  vmovaps xmm2, [rsp+0x20]
000078805cdd3dd8  vmovaps xmm3, [rsp+0x30]
000078805cdd3dde  vmovaps xmm4, [rsp+0x40]
000078805cdd3de4  vmovaps xmm5, [rsp+0x50]
000078805cdd3dea  vmovaps xmm6, [rsp+0x60]
000078805cdd3df0  vmovaps xmm7, [rsp+0x70]
000078805cdd3df6  vmovaps xmm8, [rsp+0x80]
000078805cdd3dff  vmovaps xmm9, [rsp+0x90]
000078805cdd3e08  vmovaps xmm10, [rsp+0xA0]
000078805cdd3e11  vmovaps xmm12, [rsp+0xB0]
000078805cdd3e1a  vmovaps xmm13, [rsp+0xC0]
000078805cdd3e23  vmovaps xmm14, [rsp+0xD0]
000078805cdd3e2c  vmovaps xmm15, [rsp+0xE0]
000078805cdd3e35  add rsp, 0xF0
000078805cdd3e3c  pop r11
000078805cdd3e3e  pop r10
000078805cdd3e40  pop r9
000078805cdd3e42  pop r8
000078805cdd3e44  pop rsi
000078805cdd3e45  pop rdi
000078805cdd3e46  pop rdx
000078805cdd3e47  pop rcx
000078805cdd3e48  pop rax
000078805cdd3e49  add rsp, 0x08
000078805cdd3e4d  jmp 0x000078805CDD003F
000078805cdd3e52  sub rsp, 0x08
000078805cdd3e56  push rax
000078805cdd3e57  push rcx
000078805cdd3e58  push rdx
000078805cdd3e59  push rdi
000078805cdd3e5a  push rsi
000078805cdd3e5b  push r8
000078805cdd3e5d  push r9
000078805cdd3e5f  push r10
000078805cdd3e61  push r11
000078805cdd3e63  sub rsp, 0xF0
000078805cdd3e6a  vmovaps [rsp], xmm0
000078805cdd3e6f  vmovaps [rsp+0x10], xmm1
000078805cdd3e75  vmovaps [rsp+0x20], xmm2
000078805cdd3e7b  vmovaps [rsp+0x30], xmm3
000078805cdd3e81  vmovaps [rsp+0x40], xmm4
000078805cdd3e87  vmovaps [rsp+0x50], xmm5
000078805cdd3e8d  vmovaps [rsp+0x60], xmm6
000078805cdd3e93  vmovaps [rsp+0x70], xmm7
000078805cdd3e99  vmovaps [rsp+0x80], xmm8
000078805cdd3ea2  vmovaps [rsp+0x90], xmm9
000078805cdd3eab  vmovaps [rsp+0xA0], xmm10
000078805cdd3eb4  vmovaps [rsp+0xB0], xmm11
000078805cdd3ebd  vmovaps [rsp+0xC0], xmm12
000078805cdd3ec6  vmovaps [rsp+0xD0], xmm14
000078805cdd3ecf  vmovaps [rsp+0xE0], xmm15
000078805cdd3ed8  sub rsp, 0x30
000078805cdd3edc  movaps [rsp], xmm13
000078805cdd3ee1  movaps [rsp+0x10], xmm8
000078805cdd3ee7  movaps [rsp+0x20], xmm14
000078805cdd3eed  lea rdi, [rsp]
000078805cdd3ef1  mov esi, 0x00
000078805cdd3ef6  mov rax, 0x5771AD6EA530
000078805cdd3f00  call rax
000078805cdd3f02  movaps xmm13, [rsp]
000078805cdd3f07  add rsp, 0x30
000078805cdd3f0b  vmovaps xmm0, [rsp]
000078805cdd3f10  vmovaps xmm1, [rsp+0x10]
000078805cdd3f16  vmovaps xmm2, [rsp+0x20]
000078805cdd3f1c  vmovaps xmm3, [rsp+0x30]
000078805cdd3f22  vmovaps xmm4, [rsp+0x40]
000078805cdd3f28  vmovaps xmm5, [rsp+0x50]
000078805cdd3f2e  vmovaps xmm6, [rsp+0x60]
000078805cdd3f34  vmovaps xmm7, [rsp+0x70]
000078805cdd3f3a  vmovaps xmm8, [rsp+0x80]
000078805cdd3f43  vmovaps xmm9, [rsp+0x90]
000078805cdd3f4c  vmovaps xmm10, [rsp+0xA0]
000078805cdd3f55  vmovaps xmm11, [rsp+0xB0]
000078805cdd3f5e  vmovaps xmm12, [rsp+0xC0]
000078805cdd3f67  vmovaps xmm14, [rsp+0xD0]
000078805cdd3f70  vmovaps xmm15, [rsp+0xE0]
000078805cdd3f79  add rsp, 0xF0
000078805cdd3f80  pop r11
000078805cdd3f82  pop r10
000078805cdd3f84  pop r9
000078805cdd3f86  pop r8
000078805cdd3f88  pop rsi
000078805cdd3f89  pop rdi
000078805cdd3f8a  pop rdx
000078805cdd3f8b  pop rcx
000078805cdd3f8c  pop rax
000078805cdd3f8d  add rsp, 0x08
000078805cdd3f91  jmp 0x000078805CDD006E
000078805cdd3f96  sub rsp, 0x08
000078805cdd3f9a  push rax
000078805cdd3f9b  push rcx
000078805cdd3f9c  push rdx
000078805cdd3f9d  push rdi
000078805cdd3f9e  push rsi
000078805cdd3f9f  push r8
000078805cdd3fa1  push r9
000078805cdd3fa3  push r10
000078805cdd3fa5  push r11
000078805cdd3fa7  sub rsp, 0xF0
000078805cdd3fae  vmovaps [rsp], xmm0
000078805cdd3fb3  vmovaps [rsp+0x10], xmm1
000078805cdd3fb9  vmovaps [rsp+0x20], xmm2
000078805cdd3fbf  vmovaps [rsp+0x30], xmm3
000078805cdd3fc5  vmovaps [rsp+0x40], xmm4
000078805cdd3fcb  vmovaps [rsp+0x50], xmm5
000078805cdd3fd1  vmovaps [rsp+0x60], xmm6
000078805cdd3fd7  vmovaps [rsp+0x70], xmm7
000078805cdd3fdd  vmovaps [rsp+0x80], xmm9
000078805cdd3fe6  vmovaps [rsp+0x90], xmm10
000078805cdd3fef  vmovaps [rsp+0xA0], xmm11
000078805cdd3ff8  vmovaps [rsp+0xB0], xmm12
000078805cdd4001  vmovaps [rsp+0xC0], xmm13
000078805cdd400a  vmovaps [rsp+0xD0], xmm14
000078805cdd4013  vmovaps [rsp+0xE0], xmm15
000078805cdd401c  sub rsp, 0x30
000078805cdd4020  movaps [rsp], xmm8
000078805cdd4025  movaps [rsp+0x10], xmm7
000078805cdd402a  movaps [rsp+0x20], xmm14
000078805cdd4030  lea rdi, [rsp]
000078805cdd4034  mov esi, 0x00
000078805cdd4039  mov rax, 0x5771AD6EA530
000078805cdd4043  call rax
000078805cdd4045  movaps xmm8, [rsp]
000078805cdd404a  add rsp, 0x30
000078805cdd404e  vmovaps xmm0, [rsp]
000078805cdd4053  vmovaps xmm1, [rsp+0x10]
000078805cdd4059  vmovaps xmm2, [rsp+0x20]
000078805cdd405f  vmovaps xmm3, [rsp+0x30]
000078805cdd4065  vmovaps xmm4, [rsp+0x40]
000078805cdd406b  vmovaps xmm5, [rsp+0x50]
000078805cdd4071  vmovaps xmm6, [rsp+0x60]
000078805cdd4077  vmovaps xmm7, [rsp+0x70]
000078805cdd407d  vmovaps xmm9, [rsp+0x80]
000078805cdd4086  vmovaps xmm10, [rsp+0x90]
000078805cdd408f  vmovaps xmm11, [rsp+0xA0]
000078805cdd4098  vmovaps xmm12, [rsp+0xB0]
000078805cdd40a1  vmovaps xmm13, [rsp+0xC0]
000078805cdd40aa  vmovaps xmm14, [rsp+0xD0]
000078805cdd40b3  vmovaps xmm15, [rsp+0xE0]
000078805cdd40bc  add rsp, 0xF0
000078805cdd40c3  pop r11
000078805cdd40c5  pop r10
000078805cdd40c7  pop r9
000078805cdd40c9  pop r8
000078805cdd40cb  pop rsi
000078805cdd40cc  pop rdi
000078805cdd40cd  pop rdx
000078805cdd40ce  pop rcx
000078805cdd40cf  pop rax
000078805cdd40d0  add rsp, 0x08
000078805cdd40d4  jmp 0x000078805CDD0094
000078805cdd40d9  sub rsp, 0x08
000078805cdd40dd  push rax
000078805cdd40de  push rcx
000078805cdd40df  push rdx
000078805cdd40e0  push rdi
000078805cdd40e1  push rsi
000078805cdd40e2  push r8
000078805cdd40e4  push r9
000078805cdd40e6  push r10
000078805cdd40e8  push r11
000078805cdd40ea  sub rsp, 0xF0
000078805cdd40f1  vmovaps [rsp], xmm0
000078805cdd40f6  vmovaps [rsp+0x10], xmm1
000078805cdd40fc  vmovaps [rsp+0x20], xmm2
000078805cdd4102  vmovaps [rsp+0x30], xmm3
000078805cdd4108  vmovaps [rsp+0x40], xmm4
000078805cdd410e  vmovaps [rsp+0x50], xmm5
000078805cdd4114  vmovaps [rsp+0x60], xmm6
000078805cdd411a  vmovaps [rsp+0x70], xmm7
000078805cdd4120  vmovaps [rsp+0x80], xmm8
000078805cdd4129  vmovaps [rsp+0x90], xmm9
000078805cdd4132  vmovaps [rsp+0xA0], xmm10
000078805cdd413b  vmovaps [rsp+0xB0], xmm11
000078805cdd4144  vmovaps [rsp+0xC0], xmm12
000078805cdd414d  vmovaps [rsp+0xD0], xmm13
000078805cdd4156  vmovaps [rsp+0xE0], xmm15
000078805cdd415f  sub rsp, 0x30
000078805cdd4163  movaps [rsp], xmm14
000078805cdd4168  movaps [rsp+0x10], xmm12
000078805cdd416e  movaps [rsp+0x20], xmm9
000078805cdd4174  lea rdi, [rsp]
000078805cdd4178  mov esi, 0x00
000078805cdd417d  mov rax, 0x5771AD6EA530
000078805cdd4187  call rax
000078805cdd4189  movaps xmm14, [rsp]
000078805cdd418e  add rsp, 0x30
000078805cdd4192  vmovaps xmm0, [rsp]
000078805cdd4197  vmovaps xmm1, [rsp+0x10]
000078805cdd419d  vmovaps xmm2, [rsp+0x20]
000078805cdd41a3  vmovaps xmm3, [rsp+0x30]
000078805cdd41a9  vmovaps xmm4, [rsp+0x40]
000078805cdd41af  vmovaps xmm5, [rsp+0x50]
000078805cdd41b5  vmovaps xmm6, [rsp+0x60]
000078805cdd41bb  vmovaps xmm7, [rsp+0x70]
000078805cdd41c1  vmovaps xmm8, [rsp+0x80]
000078805cdd41ca  vmovaps xmm9, [rsp+0x90]
000078805cdd41d3  vmovaps xmm10, [rsp+0xA0]
000078805cdd41dc  vmovaps xmm11, [rsp+0xB0]
000078805cdd41e5  vmovaps xmm12, [rsp+0xC0]
000078805cdd41ee  vmovaps xmm13, [rsp+0xD0]
000078805cdd41f7  vmovaps xmm15, [rsp+0xE0]
000078805cdd4200  add rsp, 0xF0
000078805cdd4207  pop r11
000078805cdd4209  pop r10
000078805cdd420b  pop r9
000078805cdd420d  pop r8
000078805cdd420f  pop rsi
000078805cdd4210  pop rdi
000078805cdd4211  pop rdx
000078805cdd4212  pop rcx
000078805cdd4213  pop rax
000078805cdd4214  add rsp, 0x08
000078805cdd4218  jmp 0x000078805CDD00AE
000078805cdd421d  sub rsp, 0x08
000078805cdd4221  push rax
000078805cdd4222  push rcx
000078805cdd4223  push rdx
000078805cdd4224  push rdi
000078805cdd4225  push rsi
000078805cdd4226  push r8
000078805cdd4228  push r9
000078805cdd422a  push r10
000078805cdd422c  push r11
000078805cdd422e  sub rsp, 0xF0
000078805cdd4235  vmovaps [rsp], xmm0
000078805cdd423a  vmovaps [rsp+0x10], xmm1
000078805cdd4240  vmovaps [rsp+0x20], xmm2
000078805cdd4246  vmovaps [rsp+0x30], xmm3
000078805cdd424c  vmovaps [rsp+0x40], xmm4
000078805cdd4252  vmovaps [rsp+0x50], xmm5
000078805cdd4258  vmovaps [rsp+0x60], xmm6
000078805cdd425e  vmovaps [rsp+0x70], xmm7
000078805cdd4264  vmovaps [rsp+0x80], xmm8
000078805cdd426d  vmovaps [rsp+0x90], xmm10
000078805cdd4276  vmovaps [rsp+0xA0], xmm11
000078805cdd427f  vmovaps [rsp+0xB0], xmm12
000078805cdd4288  vmovaps [rsp+0xC0], xmm13
000078805cdd4291  vmovaps [rsp+0xD0], xmm14
000078805cdd429a  vmovaps [rsp+0xE0], xmm15
000078805cdd42a3  sub rsp, 0x30
000078805cdd42a7  movaps [rsp], xmm9
000078805cdd42ac  movaps [rsp+0x10], xmm7
000078805cdd42b1  movaps [rsp+0x20], xmm12
000078805cdd42b7  lea rdi, [rsp]
000078805cdd42bb  mov esi, 0x00
000078805cdd42c0  mov rax, 0x5771AD6EA530
000078805cdd42ca  call rax
000078805cdd42cc  movaps xmm9, [rsp]
000078805cdd42d1  add rsp, 0x30
000078805cdd42d5  vmovaps xmm0, [rsp]
000078805cdd42da  vmovaps xmm1, [rsp+0x10]
000078805cdd42e0  vmovaps xmm2, [rsp+0x20]
000078805cdd42e6  vmovaps xmm3, [rsp+0x30]
000078805cdd42ec  vmovaps xmm4, [rsp+0x40]
000078805cdd42f2  vmovaps xmm5, [rsp+0x50]
000078805cdd42f8  vmovaps xmm6, [rsp+0x60]
000078805cdd42fe  vmovaps xmm7, [rsp+0x70]
000078805cdd4304  vmovaps xmm8, [rsp+0x80]
000078805cdd430d  vmovaps xmm10, [rsp+0x90]
000078805cdd4316  vmovaps xmm11, [rsp+0xA0]
000078805cdd431f  vmovaps xmm12, [rsp+0xB0]
000078805cdd4328  vmovaps xmm13, [rsp+0xC0]
000078805cdd4331  vmovaps xmm14, [rsp+0xD0]
000078805cdd433a  vmovaps xmm15, [rsp+0xE0]
000078805cdd4343  add rsp, 0xF0
000078805cdd434a  pop r11
000078805cdd434c  pop r10
000078805cdd434e  pop r9
000078805cdd4350  pop r8
000078805cdd4352  pop rsi
000078805cdd4353  pop rdi
000078805cdd4354  pop rdx
000078805cdd4355  pop rcx
000078805cdd4356  pop rax
000078805cdd4357  add rsp, 0x08
000078805cdd435b  jmp 0x000078805CDD00DD
000078805cdd4360  sub rsp, 0x08
000078805cdd4364  push rax
000078805cdd4365  push rcx
000078805cdd4366  push rdx
000078805cdd4367  push rdi
000078805cdd4368  push rsi
000078805cdd4369  push r8
000078805cdd436b  push r9
000078805cdd436d  push r10
000078805cdd436f  push r11
000078805cdd4371  sub rsp, 0xF0
000078805cdd4378  vmovaps [rsp], xmm0
000078805cdd437d  vmovaps [rsp+0x10], xmm1
000078805cdd4383  vmovaps [rsp+0x20], xmm2
000078805cdd4389  vmovaps [rsp+0x30], xmm3
000078805cdd438f  vmovaps [rsp+0x40], xmm4
000078805cdd4395  vmovaps [rsp+0x50], xmm5
000078805cdd439b  vmovaps [rsp+0x60], xmm6
000078805cdd43a1  vmovaps [rsp+0x70], xmm7
000078805cdd43a7  vmovaps [rsp+0x80], xmm8
000078805cdd43b0  vmovaps [rsp+0x90], xmm9
000078805cdd43b9  vmovaps [rsp+0xA0], xmm10
000078805cdd43c2  vmovaps [rsp+0xB0], xmm11
000078805cdd43cb  vmovaps [rsp+0xC0], xmm13
000078805cdd43d4  vmovaps [rsp+0xD0], xmm14
000078805cdd43dd  vmovaps [rsp+0xE0], xmm15
000078805cdd43e6  sub rsp, 0x30
000078805cdd43ea  movaps [rsp], xmm12
000078805cdd43ef  movaps [rsp+0x10], xmm15
000078805cdd43f5  movaps [rsp+0x20], xmm11
000078805cdd43fb  lea rdi, [rsp]
000078805cdd43ff  mov esi, 0x00
000078805cdd4404  mov rax, 0x5771AD6EA530
000078805cdd440e  call rax
000078805cdd4410  movaps xmm12, [rsp]
000078805cdd4415  add rsp, 0x30
000078805cdd4419  vmovaps xmm0, [rsp]
000078805cdd441e  vmovaps xmm1, [rsp+0x10]
000078805cdd4424  vmovaps xmm2, [rsp+0x20]
000078805cdd442a  vmovaps xmm3, [rsp+0x30]
000078805cdd4430  vmovaps xmm4, [rsp+0x40]
000078805cdd4436  vmovaps xmm5, [rsp+0x50]
000078805cdd443c  vmovaps xmm6, [rsp+0x60]
000078805cdd4442  vmovaps xmm7, [rsp+0x70]
000078805cdd4448  vmovaps xmm8, [rsp+0x80]
000078805cdd4451  vmovaps xmm9, [rsp+0x90]
000078805cdd445a  vmovaps xmm10, [rsp+0xA0]
000078805cdd4463  vmovaps xmm11, [rsp+0xB0]
000078805cdd446c  vmovaps xmm13, [rsp+0xC0]
000078805cdd4475  vmovaps xmm14, [rsp+0xD0]
000078805cdd447e  vmovaps xmm15, [rsp+0xE0]
000078805cdd4487  add rsp, 0xF0
000078805cdd448e  pop r11
000078805cdd4490  pop r10
000078805cdd4492  pop r9
000078805cdd4494  pop r8
000078805cdd4496  pop rsi
000078805cdd4497  pop rdi
000078805cdd4498  pop rdx
000078805cdd4499  pop rcx
000078805cdd449a  pop rax
000078805cdd449b  add rsp, 0x08
000078805cdd449f  jmp 0x000078805CDD00F7
000078805cdd44a4  sub rsp, 0x08
000078805cdd44a8  push rax
000078805cdd44a9  push rcx
000078805cdd44aa  push rdx
000078805cdd44ab  push rdi
000078805cdd44ac  push rsi
000078805cdd44ad  push r8
000078805cdd44af  push r9
000078805cdd44b1  push r10
000078805cdd44b3  push r11
000078805cdd44b5  sub rsp, 0xF0
000078805cdd44bc  vmovaps [rsp], xmm0
000078805cdd44c1  vmovaps [rsp+0x10], xmm1
000078805cdd44c7  vmovaps [rsp+0x20], xmm2
000078805cdd44cd  vmovaps [rsp+0x30], xmm3
000078805cdd44d3  vmovaps [rsp+0x40], xmm4
000078805cdd44d9  vmovaps [rsp+0x50], xmm5
000078805cdd44df  vmovaps [rsp+0x60], xmm6
000078805cdd44e5  vmovaps [rsp+0x70], xmm7
000078805cdd44eb  vmovaps [rsp+0x80], xmm8
000078805cdd44f4  vmovaps [rsp+0x90], xmm9
000078805cdd44fd  vmovaps [rsp+0xA0], xmm10
000078805cdd4506  vmovaps [rsp+0xB0], xmm12
000078805cdd450f  vmovaps [rsp+0xC0], xmm13
000078805cdd4518  vmovaps [rsp+0xD0], xmm14
000078805cdd4521  vmovaps [rsp+0xE0], xmm15
000078805cdd452a  sub rsp, 0x30
000078805cdd452e  movaps [rsp], xmm11
000078805cdd4533  movaps [rsp+0x10], xmm7
000078805cdd4538  movaps [rsp+0x20], xmm15
000078805cdd453e  lea rdi, [rsp]
000078805cdd4542  mov esi, 0x00
000078805cdd4547  mov rax, 0x5771AD6EA530
000078805cdd4551  call rax
000078805cdd4553  movaps xmm11, [rsp]
000078805cdd4558  add rsp, 0x30
000078805cdd455c  vmovaps xmm0, [rsp]
000078805cdd4561  vmovaps xmm1, [rsp+0x10]
000078805cdd4567  vmovaps xmm2, [rsp+0x20]
000078805cdd456d  vmovaps xmm3, [rsp+0x30]
000078805cdd4573  vmovaps xmm4, [rsp+0x40]
000078805cdd4579  vmovaps xmm5, [rsp+0x50]
000078805cdd457f  vmovaps xmm6, [rsp+0x60]
000078805cdd4585  vmovaps xmm7, [rsp+0x70]
000078805cdd458b  vmovaps xmm8, [rsp+0x80]
000078805cdd4594  vmovaps xmm9, [rsp+0x90]
000078805cdd459d  vmovaps xmm10, [rsp+0xA0]
000078805cdd45a6  vmovaps xmm12, [rsp+0xB0]
000078805cdd45af  vmovaps xmm13, [rsp+0xC0]
000078805cdd45b8  vmovaps xmm14, [rsp+0xD0]
000078805cdd45c1  vmovaps xmm15, [rsp+0xE0]
000078805cdd45ca  add rsp, 0xF0
000078805cdd45d1  pop r11
000078805cdd45d3  pop r10
000078805cdd45d5  pop r9
000078805cdd45d7  pop r8
000078805cdd45d9  pop rsi
000078805cdd45da  pop rdi
000078805cdd45db  pop rdx
000078805cdd45dc  pop rcx
000078805cdd45dd  pop rax
000078805cdd45de  add rsp, 0x08
000078805cdd45e2  jmp 0x000078805CDD0123
000078805cdd45e7  sub rsp, 0x08
000078805cdd45eb  push rax
000078805cdd45ec  push rcx
000078805cdd45ed  push rdx
000078805cdd45ee  push rdi
000078805cdd45ef  push rsi
000078805cdd45f0  push r8
000078805cdd45f2  push r9
000078805cdd45f4  push r10
000078805cdd45f6  push r11
000078805cdd45f8  sub rsp, 0xF0
000078805cdd45ff  vmovaps [rsp], xmm0
000078805cdd4604  vmovaps [rsp+0x10], xmm1
000078805cdd460a  vmovaps [rsp+0x20], xmm2
000078805cdd4610  vmovaps [rsp+0x30], xmm3
000078805cdd4616  vmovaps [rsp+0x40], xmm4
000078805cdd461c  vmovaps [rsp+0x50], xmm5
000078805cdd4622  vmovaps [rsp+0x60], xmm6
000078805cdd4628  vmovaps [rsp+0x70], xmm7
000078805cdd462e  vmovaps [rsp+0x80], xmm8
000078805cdd4637  vmovaps [rsp+0x90], xmm9
000078805cdd4640  vmovaps [rsp+0xA0], xmm10
000078805cdd4649  vmovaps [rsp+0xB0], xmm11
000078805cdd4652  vmovaps [rsp+0xC0], xmm12
000078805cdd465b  vmovaps [rsp+0xD0], xmm13
000078805cdd4664  vmovaps [rsp+0xE0], xmm14
000078805cdd466d  sub rsp, 0x30
000078805cdd4671  movaps [rsp], xmm15
000078805cdd4676  movaps [rsp+0x10], xmm10
000078805cdd467c  movaps [rsp+0x20], xmm13
000078805cdd4682  lea rdi, [rsp]
000078805cdd4686  mov esi, 0x00
000078805cdd468b  mov rax, 0x5771AD6EA530
000078805cdd4695  call rax
000078805cdd4697  movaps xmm15, [rsp]
000078805cdd469c  add rsp, 0x30
000078805cdd46a0  vmovaps xmm0, [rsp]
000078805cdd46a5  vmovaps xmm1, [rsp+0x10]
000078805cdd46ab  vmovaps xmm2, [rsp+0x20]
000078805cdd46b1  vmovaps xmm3, [rsp+0x30]
000078805cdd46b7  vmovaps xmm4, [rsp+0x40]
000078805cdd46bd  vmovaps xmm5, [rsp+0x50]
000078805cdd46c3  vmovaps xmm6, [rsp+0x60]
000078805cdd46c9  vmovaps xmm7, [rsp+0x70]
000078805cdd46cf  vmovaps xmm8, [rsp+0x80]
000078805cdd46d8  vmovaps xmm9, [rsp+0x90]
000078805cdd46e1  vmovaps xmm10, [rsp+0xA0]
000078805cdd46ea  vmovaps xmm11, [rsp+0xB0]
000078805cdd46f3  vmovaps xmm12, [rsp+0xC0]
000078805cdd46fc  vmovaps xmm13, [rsp+0xD0]
000078805cdd4705  vmovaps xmm14, [rsp+0xE0]
000078805cdd470e  add rsp, 0xF0
000078805cdd4715  pop r11
000078805cdd4717  pop r10
000078805cdd4719  pop r9
000078805cdd471b  pop r8
000078805cdd471d  pop rsi
000078805cdd471e  pop rdi
000078805cdd471f  pop rdx
000078805cdd4720  pop rcx
000078805cdd4721  pop rax
000078805cdd4722  add rsp, 0x08
000078805cdd4726  jmp 0x000078805CDD013D
000078805cdd472b  sub rsp, 0x08
000078805cdd472f  push rax
000078805cdd4730  push rcx
000078805cdd4731  push rdx
000078805cdd4732  push rdi
000078805cdd4733  push rsi
000078805cdd4734  push r8
000078805cdd4736  push r9
000078805cdd4738  push r10
000078805cdd473a  push r11
000078805cdd473c  sub rsp, 0xF0
000078805cdd4743  vmovaps [rsp], xmm0
000078805cdd4748  vmovaps [rsp+0x10], xmm1
000078805cdd474e  vmovaps [rsp+0x20], xmm2
000078805cdd4754  vmovaps [rsp+0x30], xmm3
000078805cdd475a  vmovaps [rsp+0x40], xmm4
000078805cdd4760  vmovaps [rsp+0x50], xmm5
000078805cdd4766  vmovaps [rsp+0x60], xmm6
000078805cdd476c  vmovaps [rsp+0x70], xmm7
000078805cdd4772  vmovaps [rsp+0x80], xmm8
000078805cdd477b  vmovaps [rsp+0x90], xmm9
000078805cdd4784  vmovaps [rsp+0xA0], xmm11
000078805cdd478d  vmovaps [rsp+0xB0], xmm12
000078805cdd4796  vmovaps [rsp+0xC0], xmm13
000078805cdd479f  vmovaps [rsp+0xD0], xmm14
000078805cdd47a8  vmovaps [rsp+0xE0], xmm15
000078805cdd47b1  sub rsp, 0x30
000078805cdd47b5  movaps [rsp], xmm10
000078805cdd47ba  movaps [rsp+0x10], xmm7
000078805cdd47bf  movaps [rsp+0x20], xmm13
000078805cdd47c5  lea rdi, [rsp]
000078805cdd47c9  mov esi, 0x00
000078805cdd47ce  mov rax, 0x5771AD6EA530
000078805cdd47d8  call rax
000078805cdd47da  movaps xmm10, [rsp]
000078805cdd47df  add rsp, 0x30
000078805cdd47e3  vmovaps xmm0, [rsp]
000078805cdd47e8  vmovaps xmm1, [rsp+0x10]
000078805cdd47ee  vmovaps xmm2, [rsp+0x20]
000078805cdd47f4  vmovaps xmm3, [rsp+0x30]
000078805cdd47fa  vmovaps xmm4, [rsp+0x40]
000078805cdd4800  vmovaps xmm5, [rsp+0x50]
000078805cdd4806  vmovaps xmm6, [rsp+0x60]
000078805cdd480c  vmovaps xmm7, [rsp+0x70]
000078805cdd4812  vmovaps xmm8, [rsp+0x80]
000078805cdd481b  vmovaps xmm9, [rsp+0x90]
000078805cdd4824  vmovaps xmm11, [rsp+0xA0]
000078805cdd482d  vmovaps xmm12, [rsp+0xB0]
000078805cdd4836  vmovaps xmm13, [rsp+0xC0]
000078805cdd483f  vmovaps xmm14, [rsp+0xD0]
000078805cdd4848  vmovaps xmm15, [rsp+0xE0]
000078805cdd4851  add rsp, 0xF0
000078805cdd4858  pop r11
000078805cdd485a  pop r10
000078805cdd485c  pop r9
000078805cdd485e  pop r8
000078805cdd4860  pop rsi
000078805cdd4861  pop rdi
000078805cdd4862  pop rdx
000078805cdd4863  pop rcx
000078805cdd4864  pop rax
000078805cdd4865  add rsp, 0x08
000078805cdd4869  jmp 0x000078805CDD0169
000078805cdd486e  sub rsp, 0x08
000078805cdd4872  push rax
000078805cdd4873  push rcx
000078805cdd4874  push rdx
000078805cdd4875  push rdi
000078805cdd4876  push rsi
000078805cdd4877  push r8
000078805cdd4879  push r9
000078805cdd487b  push r10
000078805cdd487d  push r11
000078805cdd487f  sub rsp, 0xF0
000078805cdd4886  vmovaps [rsp], xmm0
000078805cdd488b  vmovaps [rsp+0x10], xmm1
000078805cdd4891  vmovaps [rsp+0x20], xmm2
000078805cdd4897  vmovaps [rsp+0x30], xmm3
000078805cdd489d  vmovaps [rsp+0x40], xmm4
000078805cdd48a3  vmovaps [rsp+0x50], xmm5
000078805cdd48a9  vmovaps [rsp+0x60], xmm6
000078805cdd48af  vmovaps [rsp+0x70], xmm7
000078805cdd48b5  vmovaps [rsp+0x80], xmm8
000078805cdd48be  vmovaps [rsp+0x90], xmm9
000078805cdd48c7  vmovaps [rsp+0xA0], xmm10
000078805cdd48d0  vmovaps [rsp+0xB0], xmm11
000078805cdd48d9  vmovaps [rsp+0xC0], xmm12
000078805cdd48e2  vmovaps [rsp+0xD0], xmm14
000078805cdd48eb  vmovaps [rsp+0xE0], xmm15
000078805cdd48f4  sub rsp, 0x30
000078805cdd48f8  movaps [rsp], xmm13
000078805cdd48fd  movaps [rsp+0x10], xmm1
000078805cdd4902  movaps [rsp+0x20], xmm8
000078805cdd4908  lea rdi, [rsp]
000078805cdd490c  mov esi, 0x00
000078805cdd4911  mov rax, 0x5771AD6EA530
000078805cdd491b  call rax
000078805cdd491d  movaps xmm13, [rsp]
000078805cdd4922  add rsp, 0x30
000078805cdd4926  vmovaps xmm0, [rsp]
000078805cdd492b  vmovaps xmm1, [rsp+0x10]
000078805cdd4931  vmovaps xmm2, [rsp+0x20]
000078805cdd4937  vmovaps xmm3, [rsp+0x30]
000078805cdd493d  vmovaps xmm4, [rsp+0x40]
000078805cdd4943  vmovaps xmm5, [rsp+0x50]
000078805cdd4949  vmovaps xmm6, [rsp+0x60]
000078805cdd494f  vmovaps xmm7, [rsp+0x70]
000078805cdd4955  vmovaps xmm8, [rsp+0x80]
000078805cdd495e  vmovaps xmm9, [rsp+0x90]
000078805cdd4967  vmovaps xmm10, [rsp+0xA0]
000078805cdd4970  vmovaps xmm11, [rsp+0xB0]
000078805cdd4979  vmovaps xmm12, [rsp+0xC0]
000078805cdd4982  vmovaps xmm14, [rsp+0xD0]
000078805cdd498b  vmovaps xmm15, [rsp+0xE0]
000078805cdd4994  add rsp, 0xF0
000078805cdd499b  pop r11
000078805cdd499d  pop r10
000078805cdd499f  pop r9
000078805cdd49a1  pop r8
000078805cdd49a3  pop rsi
000078805cdd49a4  pop rdi
000078805cdd49a5  pop rdx
000078805cdd49a6  pop rcx
000078805cdd49a7  pop rax
000078805cdd49a8  add rsp, 0x08
000078805cdd49ac  jmp 0x000078805CDD0183
000078805cdd49b1  call 0x000078805CBFF430
000078805cdd49b6  jmp 0x000078805CDD018D
000078805cdd49bb  sub rsp, 0x08
000078805cdd49bf  push rax
000078805cdd49c0  push rcx
000078805cdd49c1  push rdx
000078805cdd49c2  push rdi
000078805cdd49c3  push rsi
000078805cdd49c4  push r8
000078805cdd49c6  push r9
000078805cdd49c8  push r10
000078805cdd49ca  push r11
000078805cdd49cc  sub rsp, 0xF0
000078805cdd49d3  vmovaps [rsp], xmm0
000078805cdd49d8  vmovaps [rsp+0x10], xmm1
000078805cdd49de  vmovaps [rsp+0x20], xmm2
000078805cdd49e4  vmovaps [rsp+0x30], xmm3
000078805cdd49ea  vmovaps [rsp+0x40], xmm4
000078805cdd49f0  vmovaps [rsp+0x50], xmm5
000078805cdd49f6  vmovaps [rsp+0x60], xmm6
000078805cdd49fc  vmovaps [rsp+0x70], xmm7
000078805cdd4a02  vmovaps [rsp+0x80], xmm9
000078805cdd4a0b  vmovaps [rsp+0x90], xmm10
000078805cdd4a14  vmovaps [rsp+0xA0], xmm11
000078805cdd4a1d  vmovaps [rsp+0xB0], xmm12
000078805cdd4a26  vmovaps [rsp+0xC0], xmm13
000078805cdd4a2f  vmovaps [rsp+0xD0], xmm14
000078805cdd4a38  vmovaps [rsp+0xE0], xmm15
000078805cdd4a41  sub rsp, 0x30
000078805cdd4a45  movaps [rsp], xmm8
000078805cdd4a4a  movaps [rsp+0x10], xmm14
000078805cdd4a50  movaps [rsp+0x20], xmm9
000078805cdd4a56  lea rdi, [rsp]
000078805cdd4a5a  mov esi, 0x00
000078805cdd4a5f  mov rax, 0x5771AD6EA530
000078805cdd4a69  call rax
000078805cdd4a6b  movaps xmm8, [rsp]
000078805cdd4a70  add rsp, 0x30
000078805cdd4a74  vmovaps xmm0, [rsp]
000078805cdd4a79  vmovaps xmm1, [rsp+0x10]
000078805cdd4a7f  vmovaps xmm2, [rsp+0x20]
000078805cdd4a85  vmovaps xmm3, [rsp+0x30]
000078805cdd4a8b  vmovaps xmm4, [rsp+0x40]
000078805cdd4a91  vmovaps xmm5, [rsp+0x50]
000078805cdd4a97  vmovaps xmm6, [rsp+0x60]
000078805cdd4a9d  vmovaps xmm7, [rsp+0x70]
000078805cdd4aa3  vmovaps xmm9, [rsp+0x80]
000078805cdd4aac  vmovaps xmm10, [rsp+0x90]
000078805cdd4ab5  vmovaps xmm11, [rsp+0xA0]
000078805cdd4abe  vmovaps xmm12, [rsp+0xB0]
000078805cdd4ac7  vmovaps xmm13, [rsp+0xC0]
000078805cdd4ad0  vmovaps xmm14, [rsp+0xD0]
000078805cdd4ad9  vmovaps xmm15, [rsp+0xE0]
000078805cdd4ae2  add rsp, 0xF0
000078805cdd4ae9  pop r11
000078805cdd4aeb  pop r10
000078805cdd4aed  pop r9
000078805cdd4aef  pop r8
000078805cdd4af1  pop rsi
000078805cdd4af2  pop rdi
000078805cdd4af3  pop rdx
000078805cdd4af4  pop rcx
000078805cdd4af5  pop rax
000078805cdd4af6  add rsp, 0x08
000078805cdd4afa  jmp 0x000078805CDD01AF
000078805cdd4aff  sub rsp, 0x08
000078805cdd4b03  push rax
000078805cdd4b04  push rcx
000078805cdd4b05  push rdx
000078805cdd4b06  push rdi
000078805cdd4b07  push rsi
000078805cdd4b08  push r8
000078805cdd4b0a  push r9
000078805cdd4b0c  push r10
000078805cdd4b0e  push r11
000078805cdd4b10  sub rsp, 0xF0
000078805cdd4b17  vmovaps [rsp], xmm0
000078805cdd4b1c  vmovaps [rsp+0x10], xmm1
000078805cdd4b22  vmovaps [rsp+0x20], xmm2
000078805cdd4b28  vmovaps [rsp+0x30], xmm3
000078805cdd4b2e  vmovaps [rsp+0x40], xmm4
000078805cdd4b34  vmovaps [rsp+0x50], xmm5
000078805cdd4b3a  vmovaps [rsp+0x60], xmm6
000078805cdd4b40  vmovaps [rsp+0x70], xmm7
000078805cdd4b46  vmovaps [rsp+0x80], xmm8
000078805cdd4b4f  vmovaps [rsp+0x90], xmm10
000078805cdd4b58  vmovaps [rsp+0xA0], xmm11
000078805cdd4b61  vmovaps [rsp+0xB0], xmm12
000078805cdd4b6a  vmovaps [rsp+0xC0], xmm13
000078805cdd4b73  vmovaps [rsp+0xD0], xmm14
000078805cdd4b7c  vmovaps [rsp+0xE0], xmm15
000078805cdd4b85  sub rsp, 0x30
000078805cdd4b89  movaps [rsp], xmm9
000078805cdd4b8e  movaps [rsp+0x10], xmm1
000078805cdd4b93  movaps [rsp+0x20], xmm14
000078805cdd4b99  lea rdi, [rsp]
000078805cdd4b9d  mov esi, 0x00
000078805cdd4ba2  mov rax, 0x5771AD6EA530
000078805cdd4bac  call rax
000078805cdd4bae  movaps xmm9, [rsp]
000078805cdd4bb3  add rsp, 0x30
000078805cdd4bb7  vmovaps xmm0, [rsp]
000078805cdd4bbc  vmovaps xmm1, [rsp+0x10]
000078805cdd4bc2  vmovaps xmm2, [rsp+0x20]
000078805cdd4bc8  vmovaps xmm3, [rsp+0x30]
000078805cdd4bce  vmovaps xmm4, [rsp+0x40]
000078805cdd4bd4  vmovaps xmm5, [rsp+0x50]
000078805cdd4bda  vmovaps xmm6, [rsp+0x60]
000078805cdd4be0  vmovaps xmm7, [rsp+0x70]
000078805cdd4be6  vmovaps xmm8, [rsp+0x80]
000078805cdd4bef  vmovaps xmm10, [rsp+0x90]
000078805cdd4bf8  vmovaps xmm11, [rsp+0xA0]
000078805cdd4c01  vmovaps xmm12, [rsp+0xB0]
000078805cdd4c0a  vmovaps xmm13, [rsp+0xC0]
000078805cdd4c13  vmovaps xmm14, [rsp+0xD0]
000078805cdd4c1c  vmovaps xmm15, [rsp+0xE0]
000078805cdd4c25  add rsp, 0xF0
000078805cdd4c2c  pop r11
000078805cdd4c2e  pop r10
000078805cdd4c30  pop r9
000078805cdd4c32  pop r8
000078805cdd4c34  pop rsi
000078805cdd4c35  pop rdi
000078805cdd4c36  pop rdx
000078805cdd4c37  pop rcx
000078805cdd4c38  pop rax
000078805cdd4c39  add rsp, 0x08
000078805cdd4c3d  jmp 0x000078805CDD01DD
000078805cdd4c42  sub rsp, 0x08
000078805cdd4c46  push rax
000078805cdd4c47  push rcx
000078805cdd4c48  push rdx
000078805cdd4c49  push rdi
000078805cdd4c4a  push rsi
000078805cdd4c4b  push r8
000078805cdd4c4d  push r9
000078805cdd4c4f  push r10
000078805cdd4c51  push r11
000078805cdd4c53  sub rsp, 0xF0
000078805cdd4c5a  vmovaps [rsp], xmm0
000078805cdd4c5f  vmovaps [rsp+0x10], xmm1
000078805cdd4c65  vmovaps [rsp+0x20], xmm2
000078805cdd4c6b  vmovaps [rsp+0x30], xmm3
000078805cdd4c71  vmovaps [rsp+0x40], xmm4
000078805cdd4c77  vmovaps [rsp+0x50], xmm5
000078805cdd4c7d  vmovaps [rsp+0x60], xmm6
000078805cdd4c83  vmovaps [rsp+0x70], xmm7
000078805cdd4c89  vmovaps [rsp+0x80], xmm8
000078805cdd4c92  vmovaps [rsp+0x90], xmm9
000078805cdd4c9b  vmovaps [rsp+0xA0], xmm10
000078805cdd4ca4  vmovaps [rsp+0xB0], xmm11
000078805cdd4cad  vmovaps [rsp+0xC0], xmm12
000078805cdd4cb6  vmovaps [rsp+0xD0], xmm13
000078805cdd4cbf  vmovaps [rsp+0xE0], xmm15
000078805cdd4cc8  sub rsp, 0x30
000078805cdd4ccc  movaps [rsp], xmm14
000078805cdd4cd1  movaps [rsp+0x10], xmm4
000078805cdd4cd6  movaps [rsp+0x20], xmm1
000078805cdd4cdb  lea rdi, [rsp]
000078805cdd4cdf  mov esi, 0x00
000078805cdd4ce4  mov rax, 0x5771AD6EA530
000078805cdd4cee  call rax
000078805cdd4cf0  movaps xmm14, [rsp]
000078805cdd4cf5  add rsp, 0x30
000078805cdd4cf9  vmovaps xmm0, [rsp]
000078805cdd4cfe  vmovaps xmm1, [rsp+0x10]
000078805cdd4d04  vmovaps xmm2, [rsp+0x20]
000078805cdd4d0a  vmovaps xmm3, [rsp+0x30]
000078805cdd4d10  vmovaps xmm4, [rsp+0x40]
000078805cdd4d16  vmovaps xmm5, [rsp+0x50]
000078805cdd4d1c  vmovaps xmm6, [rsp+0x60]
000078805cdd4d22  vmovaps xmm7, [rsp+0x70]
000078805cdd4d28  vmovaps xmm8, [rsp+0x80]
000078805cdd4d31  vmovaps xmm9, [rsp+0x90]
000078805cdd4d3a  vmovaps xmm10, [rsp+0xA0]
000078805cdd4d43  vmovaps xmm11, [rsp+0xB0]
000078805cdd4d4c  vmovaps xmm12, [rsp+0xC0]
000078805cdd4d55  vmovaps xmm13, [rsp+0xD0]
000078805cdd4d5e  vmovaps xmm15, [rsp+0xE0]
000078805cdd4d67  add rsp, 0xF0
000078805cdd4d6e  pop r11
000078805cdd4d70  pop r10
000078805cdd4d72  pop r9
000078805cdd4d74  pop r8
000078805cdd4d76  pop rsi
000078805cdd4d77  pop rdi
000078805cdd4d78  pop rdx
000078805cdd4d79  pop rcx
000078805cdd4d7a  pop rax
000078805cdd4d7b  add rsp, 0x08
000078805cdd4d7f  jmp 0x000078805CDD0203
000078805cdd4d84  sub rsp, 0x08
000078805cdd4d88  push rax
000078805cdd4d89  push rcx
000078805cdd4d8a  push rdx
000078805cdd4d8b  push rdi
000078805cdd4d8c  push rsi
000078805cdd4d8d  push r8
000078805cdd4d8f  push r9
000078805cdd4d91  push r10
000078805cdd4d93  push r11
000078805cdd4d95  sub rsp, 0xF0
000078805cdd4d9c  vmovaps [rsp], xmm0
000078805cdd4da1  vmovaps [rsp+0x10], xmm2
000078805cdd4da7  vmovaps [rsp+0x20], xmm3
000078805cdd4dad  vmovaps [rsp+0x30], xmm4
000078805cdd4db3  vmovaps [rsp+0x40], xmm5
000078805cdd4db9  vmovaps [rsp+0x50], xmm6
000078805cdd4dbf  vmovaps [rsp+0x60], xmm7
000078805cdd4dc5  vmovaps [rsp+0x70], xmm8
000078805cdd4dcb  vmovaps [rsp+0x80], xmm9
000078805cdd4dd4  vmovaps [rsp+0x90], xmm10
000078805cdd4ddd  vmovaps [rsp+0xA0], xmm11
000078805cdd4de6  vmovaps [rsp+0xB0], xmm12
000078805cdd4def  vmovaps [rsp+0xC0], xmm13
000078805cdd4df8  vmovaps [rsp+0xD0], xmm14
000078805cdd4e01  vmovaps [rsp+0xE0], xmm15
000078805cdd4e0a  sub rsp, 0x30
000078805cdd4e0e  movaps [rsp], xmm1
000078805cdd4e12  movaps [rsp+0x10], xmm12
000078805cdd4e18  movaps [rsp+0x20], xmm11
000078805cdd4e1e  lea rdi, [rsp]
000078805cdd4e22  mov esi, 0x00
000078805cdd4e27  mov rax, 0x5771AD6EA530
000078805cdd4e31  call rax
000078805cdd4e33  movaps xmm1, [rsp]
000078805cdd4e37  add rsp, 0x30
000078805cdd4e3b  vmovaps xmm0, [rsp]
000078805cdd4e40  vmovaps xmm2, [rsp+0x10]
000078805cdd4e46  vmovaps xmm3, [rsp+0x20]
000078805cdd4e4c  vmovaps xmm4, [rsp+0x30]
000078805cdd4e52  vmovaps xmm5, [rsp+0x40]
000078805cdd4e58  vmovaps xmm6, [rsp+0x50]
000078805cdd4e5e  vmovaps xmm7, [rsp+0x60]
000078805cdd4e64  vmovaps xmm8, [rsp+0x70]
000078805cdd4e6a  vmovaps xmm9, [rsp+0x80]
000078805cdd4e73  vmovaps xmm10, [rsp+0x90]
000078805cdd4e7c  vmovaps xmm11, [rsp+0xA0]
000078805cdd4e85  vmovaps xmm12, [rsp+0xB0]
000078805cdd4e8e  vmovaps xmm13, [rsp+0xC0]
000078805cdd4e97  vmovaps xmm14, [rsp+0xD0]
000078805cdd4ea0  vmovaps xmm15, [rsp+0xE0]
000078805cdd4ea9  add rsp, 0xF0
000078805cdd4eb0  pop r11
000078805cdd4eb2  pop r10
000078805cdd4eb4  pop r9
000078805cdd4eb6  pop r8
000078805cdd4eb8  pop rsi
000078805cdd4eb9  pop rdi
000078805cdd4eba  pop rdx
000078805cdd4ebb  pop rcx
000078805cdd4ebc  pop rax
000078805cdd4ebd  add rsp, 0x08
000078805cdd4ec1  jmp 0x000078805CDD0224
000078805cdd4ec6  call 0x000078805CCE20A0
000078805cdd4ecb  jmp 0x000078805CDD0232
000078805cdd4ed0  call 0x000078805CC09D70
000078805cdd4ed5  jmp 0x000078805CDD023C
000078805cdd4eda  sub rsp, 0x08
000078805cdd4ede  push rax
000078805cdd4edf  push rcx
000078805cdd4ee0  push rdx
000078805cdd4ee1  push rdi
000078805cdd4ee2  push rsi
000078805cdd4ee3  push r8
000078805cdd4ee5  push r9
000078805cdd4ee7  push r10
000078805cdd4ee9  push r11
000078805cdd4eeb  sub rsp, 0xF0
000078805cdd4ef2  vmovaps [rsp], xmm0
000078805cdd4ef7  vmovaps [rsp+0x10], xmm1
000078805cdd4efd  vmovaps [rsp+0x20], xmm2
000078805cdd4f03  vmovaps [rsp+0x30], xmm3
000078805cdd4f09  vmovaps [rsp+0x40], xmm4
000078805cdd4f0f  vmovaps [rsp+0x50], xmm5
000078805cdd4f15  vmovaps [rsp+0x60], xmm6
000078805cdd4f1b  vmovaps [rsp+0x70], xmm8
000078805cdd4f21  vmovaps [rsp+0x80], xmm9
000078805cdd4f2a  vmovaps [rsp+0x90], xmm10
000078805cdd4f33  vmovaps [rsp+0xA0], xmm11
000078805cdd4f3c  vmovaps [rsp+0xB0], xmm12
000078805cdd4f45  vmovaps [rsp+0xC0], xmm13
000078805cdd4f4e  vmovaps [rsp+0xD0], xmm14
000078805cdd4f57  vmovaps [rsp+0xE0], xmm15
000078805cdd4f60  sub rsp, 0x30
000078805cdd4f64  movaps [rsp], xmm7
000078805cdd4f68  movaps [rsp+0x10], xmm15
000078805cdd4f6e  movaps [rsp+0x20], xmm10
000078805cdd4f74  lea rdi, [rsp]
000078805cdd4f78  mov esi, 0x00
000078805cdd4f7d  mov rax, 0x5771AD6EA530
000078805cdd4f87  call rax
000078805cdd4f89  movaps xmm7, [rsp]
000078805cdd4f8d  add rsp, 0x30
000078805cdd4f91  vmovaps xmm0, [rsp]
000078805cdd4f96  vmovaps xmm1, [rsp+0x10]
000078805cdd4f9c  vmovaps xmm2, [rsp+0x20]
000078805cdd4fa2  vmovaps xmm3, [rsp+0x30]
000078805cdd4fa8  vmovaps xmm4, [rsp+0x40]
000078805cdd4fae  vmovaps xmm5, [rsp+0x50]
000078805cdd4fb4  vmovaps xmm6, [rsp+0x60]
000078805cdd4fba  vmovaps xmm8, [rsp+0x70]
000078805cdd4fc0  vmovaps xmm9, [rsp+0x80]
000078805cdd4fc9  vmovaps xmm10, [rsp+0x90]
000078805cdd4fd2  vmovaps xmm11, [rsp+0xA0]
000078805cdd4fdb  vmovaps xmm12, [rsp+0xB0]
000078805cdd4fe4  vmovaps xmm13, [rsp+0xC0]
000078805cdd4fed  vmovaps xmm14, [rsp+0xD0]
000078805cdd4ff6  vmovaps xmm15, [rsp+0xE0]
000078805cdd4fff  add rsp, 0xF0
000078805cdd5006  pop r11
000078805cdd5008  pop r10
000078805cdd500a  pop r9
000078805cdd500c  pop r8
000078805cdd500e  pop rsi
000078805cdd500f  pop rdi
000078805cdd5010  pop rdx
000078805cdd5011  pop rcx
000078805cdd5012  pop rax
000078805cdd5013  add rsp, 0x08
000078805cdd5017  jmp 0x000078805CDD025D
000078805cdd501c  sub rsp, 0x08
000078805cdd5020  push rax
000078805cdd5021  push rcx
000078805cdd5022  push rdx
000078805cdd5023  push rdi
000078805cdd5024  push rsi
000078805cdd5025  push r8
000078805cdd5027  push r9
000078805cdd5029  push r10
000078805cdd502b  push r11
000078805cdd502d  sub rsp, 0xF0
000078805cdd5034  vmovaps [rsp], xmm0
000078805cdd5039  vmovaps [rsp+0x10], xmm1
000078805cdd503f  vmovaps [rsp+0x20], xmm2
000078805cdd5045  vmovaps [rsp+0x30], xmm3
000078805cdd504b  vmovaps [rsp+0x40], xmm4
000078805cdd5051  vmovaps [rsp+0x50], xmm5
000078805cdd5057  vmovaps [rsp+0x60], xmm6
000078805cdd505d  vmovaps [rsp+0x70], xmm7
000078805cdd5063  vmovaps [rsp+0x80], xmm8
000078805cdd506c  vmovaps [rsp+0x90], xmm9
000078805cdd5075  vmovaps [rsp+0xA0], xmm11
000078805cdd507e  vmovaps [rsp+0xB0], xmm12
000078805cdd5087  vmovaps [rsp+0xC0], xmm13
000078805cdd5090  vmovaps [rsp+0xD0], xmm14
000078805cdd5099  vmovaps [rsp+0xE0], xmm15
000078805cdd50a2  sub rsp, 0x30
000078805cdd50a6  movaps [rsp], xmm10
000078805cdd50ab  movaps [rsp+0x10], xmm11
000078805cdd50b1  movaps [rsp+0x20], xmm15
000078805cdd50b7  lea rdi, [rsp]
000078805cdd50bb  mov esi, 0x00
000078805cdd50c0  mov rax, 0x5771AD6EA530
000078805cdd50ca  call rax
000078805cdd50cc  movaps xmm10, [rsp]
000078805cdd50d1  add rsp, 0x30
000078805cdd50d5  vmovaps xmm0, [rsp]
000078805cdd50da  vmovaps xmm1, [rsp+0x10]
000078805cdd50e0  vmovaps xmm2, [rsp+0x20]
000078805cdd50e6  vmovaps xmm3, [rsp+0x30]
000078805cdd50ec  vmovaps xmm4, [rsp+0x40]
000078805cdd50f2  vmovaps xmm5, [rsp+0x50]
000078805cdd50f8  vmovaps xmm6, [rsp+0x60]
000078805cdd50fe  vmovaps xmm7, [rsp+0x70]
000078805cdd5104  vmovaps xmm8, [rsp+0x80]
000078805cdd510d  vmovaps xmm9, [rsp+0x90]
000078805cdd5116  vmovaps xmm11, [rsp+0xA0]
000078805cdd511f  vmovaps xmm12, [rsp+0xB0]
000078805cdd5128  vmovaps xmm13, [rsp+0xC0]
000078805cdd5131  vmovaps xmm14, [rsp+0xD0]
000078805cdd513a  vmovaps xmm15, [rsp+0xE0]
000078805cdd5143  add rsp, 0xF0
000078805cdd514a  pop r11
000078805cdd514c  pop r10
000078805cdd514e  pop r9
000078805cdd5150  pop r8
000078805cdd5152  pop rsi
000078805cdd5153  pop rdi
000078805cdd5154  pop rdx
000078805cdd5155  pop rcx
000078805cdd5156  pop rax
000078805cdd5157  add rsp, 0x08
000078805cdd515b  jmp 0x000078805CDD028B
000078805cdd5160  sub rsp, 0x08
000078805cdd5164  push rax
000078805cdd5165  push rcx
000078805cdd5166  push rdx
000078805cdd5167  push rdi
000078805cdd5168  push rsi
000078805cdd5169  push r8
000078805cdd516b  push r9
000078805cdd516d  push r10
000078805cdd516f  push r11
000078805cdd5171  sub rsp, 0xF0
000078805cdd5178  vmovaps [rsp], xmm0
000078805cdd517d  vmovaps [rsp+0x10], xmm1
000078805cdd5183  vmovaps [rsp+0x20], xmm2
000078805cdd5189  vmovaps [rsp+0x30], xmm3
000078805cdd518f  vmovaps [rsp+0x40], xmm4
000078805cdd5195  vmovaps [rsp+0x50], xmm5
000078805cdd519b  vmovaps [rsp+0x60], xmm6
000078805cdd51a1  vmovaps [rsp+0x70], xmm7
000078805cdd51a7  vmovaps [rsp+0x80], xmm8
000078805cdd51b0  vmovaps [rsp+0x90], xmm9
000078805cdd51b9  vmovaps [rsp+0xA0], xmm10
000078805cdd51c2  vmovaps [rsp+0xB0], xmm12
000078805cdd51cb  vmovaps [rsp+0xC0], xmm13
000078805cdd51d4  vmovaps [rsp+0xD0], xmm14
000078805cdd51dd  vmovaps [rsp+0xE0], xmm15
000078805cdd51e6  sub rsp, 0x30
000078805cdd51ea  movaps [rsp], xmm11
000078805cdd51ef  movaps [rsp+0x10], xmm12
000078805cdd51f5  movaps [rsp+0x20], xmm15
000078805cdd51fb  lea rdi, [rsp]
000078805cdd51ff  mov esi, 0x00
000078805cdd5204  mov rax, 0x5771AD6EA530
000078805cdd520e  call rax
000078805cdd5210  movaps xmm11, [rsp]
000078805cdd5215  add rsp, 0x30
000078805cdd5219  vmovaps xmm0, [rsp]
000078805cdd521e  vmovaps xmm1, [rsp+0x10]
000078805cdd5224  vmovaps xmm2, [rsp+0x20]
000078805cdd522a  vmovaps xmm3, [rsp+0x30]
000078805cdd5230  vmovaps xmm4, [rsp+0x40]
000078805cdd5236  vmovaps xmm5, [rsp+0x50]
000078805cdd523c  vmovaps xmm6, [rsp+0x60]
000078805cdd5242  vmovaps xmm7, [rsp+0x70]
000078805cdd5248  vmovaps xmm8, [rsp+0x80]
000078805cdd5251  vmovaps xmm9, [rsp+0x90]
000078805cdd525a  vmovaps xmm10, [rsp+0xA0]
000078805cdd5263  vmovaps xmm12, [rsp+0xB0]
000078805cdd526c  vmovaps xmm13, [rsp+0xC0]
000078805cdd5275  vmovaps xmm14, [rsp+0xD0]
000078805cdd527e  vmovaps xmm15, [rsp+0xE0]
000078805cdd5287  add rsp, 0xF0
000078805cdd528e  pop r11
000078805cdd5290  pop r10
000078805cdd5292  pop r9
000078805cdd5294  pop r8
000078805cdd5296  pop rsi
000078805cdd5297  pop rdi
000078805cdd5298  pop rdx
000078805cdd5299  pop rcx
000078805cdd529a  pop rax
000078805cdd529b  add rsp, 0x08
000078805cdd529f  jmp 0x000078805CDD02B9
000078805cdd52a4  sub rsp, 0x08
000078805cdd52a8  push rax
000078805cdd52a9  push rcx
000078805cdd52aa  push rdx
000078805cdd52ab  push rdi
000078805cdd52ac  push rsi
000078805cdd52ad  push r8
000078805cdd52af  push r9
000078805cdd52b1  push r10
000078805cdd52b3  push r11
000078805cdd52b5  sub rsp, 0xF0
000078805cdd52bc  vmovaps [rsp], xmm0
000078805cdd52c1  vmovaps [rsp+0x10], xmm1
000078805cdd52c7  vmovaps [rsp+0x20], xmm2
000078805cdd52cd  vmovaps [rsp+0x30], xmm3
000078805cdd52d3  vmovaps [rsp+0x40], xmm4
000078805cdd52d9  vmovaps [rsp+0x50], xmm5
000078805cdd52df  vmovaps [rsp+0x60], xmm6
000078805cdd52e5  vmovaps [rsp+0x70], xmm7
000078805cdd52eb  vmovaps [rsp+0x80], xmm8
000078805cdd52f4  vmovaps [rsp+0x90], xmm9
000078805cdd52fd  vmovaps [rsp+0xA0], xmm10
000078805cdd5306  vmovaps [rsp+0xB0], xmm11
000078805cdd530f  vmovaps [rsp+0xC0], xmm12
000078805cdd5318  vmovaps [rsp+0xD0], xmm13
000078805cdd5321  vmovaps [rsp+0xE0], xmm14
000078805cdd532a  sub rsp, 0x30
000078805cdd532e  movaps [rsp], xmm15
000078805cdd5333  movaps [rsp+0x10], xmm13
000078805cdd5339  movaps [rsp+0x20], xmm9
000078805cdd533f  lea rdi, [rsp]
000078805cdd5343  mov esi, 0x00
000078805cdd5348  mov rax, 0x5771AD6EA530
000078805cdd5352  call rax
000078805cdd5354  movaps xmm15, [rsp]
000078805cdd5359  add rsp, 0x30
000078805cdd535d  vmovaps xmm0, [rsp]
000078805cdd5362  vmovaps xmm1, [rsp+0x10]
000078805cdd5368  vmovaps xmm2, [rsp+0x20]
000078805cdd536e  vmovaps xmm3, [rsp+0x30]
000078805cdd5374  vmovaps xmm4, [rsp+0x40]
000078805cdd537a  vmovaps xmm5, [rsp+0x50]
000078805cdd5380  vmovaps xmm6, [rsp+0x60]
000078805cdd5386  vmovaps xmm7, [rsp+0x70]
000078805cdd538c  vmovaps xmm8, [rsp+0x80]
000078805cdd5395  vmovaps xmm9, [rsp+0x90]
000078805cdd539e  vmovaps xmm10, [rsp+0xA0]
000078805cdd53a7  vmovaps xmm11, [rsp+0xB0]
000078805cdd53b0  vmovaps xmm12, [rsp+0xC0]
000078805cdd53b9  vmovaps xmm13, [rsp+0xD0]
000078805cdd53c2  vmovaps xmm14, [rsp+0xE0]
000078805cdd53cb  add rsp, 0xF0
000078805cdd53d2  pop r11
000078805cdd53d4  pop r10
000078805cdd53d6  pop r9
000078805cdd53d8  pop r8
000078805cdd53da  pop rsi
000078805cdd53db  pop rdi
000078805cdd53dc  pop rdx
000078805cdd53dd  pop rcx
000078805cdd53de  pop rax
000078805cdd53df  add rsp, 0x08
000078805cdd53e3  jmp 0x000078805CDD02D4
000078805cdd53e8  sub rsp, 0x08
000078805cdd53ec  push rax
000078805cdd53ed  push rcx
000078805cdd53ee  push rdx
000078805cdd53ef  push rdi
000078805cdd53f0  push rsi
000078805cdd53f1  push r8
000078805cdd53f3  push r9
000078805cdd53f5  push r10
000078805cdd53f7  push r11
000078805cdd53f9  sub rsp, 0xF0
000078805cdd5400  vmovaps [rsp], xmm0
000078805cdd5405  vmovaps [rsp+0x10], xmm1
000078805cdd540b  vmovaps [rsp+0x20], xmm2
000078805cdd5411  vmovaps [rsp+0x30], xmm3
000078805cdd5417  vmovaps [rsp+0x40], xmm4
000078805cdd541d  vmovaps [rsp+0x50], xmm5
000078805cdd5423  vmovaps [rsp+0x60], xmm6
000078805cdd5429  vmovaps [rsp+0x70], xmm7
000078805cdd542f  vmovaps [rsp+0x80], xmm8
000078805cdd5438  vmovaps [rsp+0x90], xmm9
000078805cdd5441  vmovaps [rsp+0xA0], xmm10
000078805cdd544a  vmovaps [rsp+0xB0], xmm11
000078805cdd5453  vmovaps [rsp+0xC0], xmm12
000078805cdd545c  vmovaps [rsp+0xD0], xmm14
000078805cdd5465  vmovaps [rsp+0xE0], xmm15
000078805cdd546e  sub rsp, 0x30
000078805cdd5472  movaps [rsp], xmm13
000078805cdd5477  movaps [rsp+0x10], xmm8
000078805cdd547d  movaps [rsp+0x20], xmm14
000078805cdd5483  lea rdi, [rsp]
000078805cdd5487  mov esi, 0x00
000078805cdd548c  mov rax, 0x5771AD6EA530
000078805cdd5496  call rax
000078805cdd5498  movaps xmm13, [rsp]
000078805cdd549d  add rsp, 0x30
000078805cdd54a1  vmovaps xmm0, [rsp]
000078805cdd54a6  vmovaps xmm1, [rsp+0x10]
000078805cdd54ac  vmovaps xmm2, [rsp+0x20]
000078805cdd54b2  vmovaps xmm3, [rsp+0x30]
000078805cdd54b8  vmovaps xmm4, [rsp+0x40]
000078805cdd54be  vmovaps xmm5, [rsp+0x50]
000078805cdd54c4  vmovaps xmm6, [rsp+0x60]
000078805cdd54ca  vmovaps xmm7, [rsp+0x70]
000078805cdd54d0  vmovaps xmm8, [rsp+0x80]
000078805cdd54d9  vmovaps xmm9, [rsp+0x90]
000078805cdd54e2  vmovaps xmm10, [rsp+0xA0]
000078805cdd54eb  vmovaps xmm11, [rsp+0xB0]
000078805cdd54f4  vmovaps xmm12, [rsp+0xC0]
000078805cdd54fd  vmovaps xmm14, [rsp+0xD0]
000078805cdd5506  vmovaps xmm15, [rsp+0xE0]
000078805cdd550f  add rsp, 0xF0
000078805cdd5516  pop r11
000078805cdd5518  pop r10
000078805cdd551a  pop r9
000078805cdd551c  pop r8
000078805cdd551e  pop rsi
000078805cdd551f  pop rdi
000078805cdd5520  pop rdx
000078805cdd5521  pop rcx
000078805cdd5522  pop rax
000078805cdd5523  add rsp, 0x08
000078805cdd5527  jmp 0x000078805CDD02F7
000078805cdd552c  sub rsp, 0x08
000078805cdd5530  push rax
000078805cdd5531  push rcx
000078805cdd5532  push rdx
000078805cdd5533  push rdi
000078805cdd5534  push rsi
000078805cdd5535  push r8
000078805cdd5537  push r9
000078805cdd5539  push r10
000078805cdd553b  push r11
000078805cdd553d  sub rsp, 0xF0
000078805cdd5544  vmovaps [rsp], xmm0
000078805cdd5549  vmovaps [rsp+0x10], xmm1
000078805cdd554f  vmovaps [rsp+0x20], xmm2
000078805cdd5555  vmovaps [rsp+0x30], xmm3
000078805cdd555b  vmovaps [rsp+0x40], xmm4
000078805cdd5561  vmovaps [rsp+0x50], xmm5
000078805cdd5567  vmovaps [rsp+0x60], xmm6
000078805cdd556d  vmovaps [rsp+0x70], xmm7
000078805cdd5573  vmovaps [rsp+0x80], xmm8
000078805cdd557c  vmovaps [rsp+0x90], xmm9
000078805cdd5585  vmovaps [rsp+0xA0], xmm10
000078805cdd558e  vmovaps [rsp+0xB0], xmm11
000078805cdd5597  vmovaps [rsp+0xC0], xmm12
000078805cdd55a0  vmovaps [rsp+0xD0], xmm13
000078805cdd55a9  vmovaps [rsp+0xE0], xmm15
000078805cdd55b2  sub rsp, 0x30
000078805cdd55b6  movaps [rsp], xmm14
000078805cdd55bb  movaps [rsp+0x10], xmm1
000078805cdd55c0  movaps [rsp+0x20], xmm10
000078805cdd55c6  lea rdi, [rsp]
000078805cdd55ca  mov esi, 0x00
000078805cdd55cf  mov rax, 0x5771AD6EA530
000078805cdd55d9  call rax
000078805cdd55db  movaps xmm14, [rsp]
000078805cdd55e0  add rsp, 0x30
000078805cdd55e4  vmovaps xmm0, [rsp]
000078805cdd55e9  vmovaps xmm1, [rsp+0x10]
000078805cdd55ef  vmovaps xmm2, [rsp+0x20]
000078805cdd55f5  vmovaps xmm3, [rsp+0x30]
000078805cdd55fb  vmovaps xmm4, [rsp+0x40]
000078805cdd5601  vmovaps xmm5, [rsp+0x50]
000078805cdd5607  vmovaps xmm6, [rsp+0x60]
000078805cdd560d  vmovaps xmm7, [rsp+0x70]
000078805cdd5613  vmovaps xmm8, [rsp+0x80]
000078805cdd561c  vmovaps xmm9, [rsp+0x90]
000078805cdd5625  vmovaps xmm10, [rsp+0xA0]
000078805cdd562e  vmovaps xmm11, [rsp+0xB0]
000078805cdd5637  vmovaps xmm12, [rsp+0xC0]
000078805cdd5640  vmovaps xmm13, [rsp+0xD0]
000078805cdd5649  vmovaps xmm15, [rsp+0xE0]
000078805cdd5652  add rsp, 0xF0
000078805cdd5659  pop r11
000078805cdd565b  pop r10
000078805cdd565d  pop r9
000078805cdd565f  pop r8
000078805cdd5661  pop rsi
000078805cdd5662  pop rdi
000078805cdd5663  pop rdx
000078805cdd5664  pop rcx
000078805cdd5665  pop rax
000078805cdd5666  add rsp, 0x08
000078805cdd566a  jmp 0x000078805CDD031A
000078805cdd566f  sub rsp, 0x08
000078805cdd5673  push rax
000078805cdd5674  push rcx
000078805cdd5675  push rdx
000078805cdd5676  push rdi
000078805cdd5677  push rsi
000078805cdd5678  push r8
000078805cdd567a  push r9
000078805cdd567c  push r10
000078805cdd567e  push r11
000078805cdd5680  sub rsp, 0xF0
000078805cdd5687  vmovaps [rsp], xmm0
000078805cdd568c  vmovaps [rsp+0x10], xmm2
000078805cdd5692  vmovaps [rsp+0x20], xmm3
000078805cdd5698  vmovaps [rsp+0x30], xmm4
000078805cdd569e  vmovaps [rsp+0x40], xmm5
000078805cdd56a4  vmovaps [rsp+0x50], xmm6
000078805cdd56aa  vmovaps [rsp+0x60], xmm7
000078805cdd56b0  vmovaps [rsp+0x70], xmm8
000078805cdd56b6  vmovaps [rsp+0x80], xmm9
000078805cdd56bf  vmovaps [rsp+0x90], xmm10
000078805cdd56c8  vmovaps [rsp+0xA0], xmm11
000078805cdd56d1  vmovaps [rsp+0xB0], xmm12
000078805cdd56da  vmovaps [rsp+0xC0], xmm13
000078805cdd56e3  vmovaps [rsp+0xD0], xmm14
000078805cdd56ec  vmovaps [rsp+0xE0], xmm15
000078805cdd56f5  sub rsp, 0x30
000078805cdd56f9  movaps [rsp], xmm1
000078805cdd56fd  movaps [rsp+0x10], xmm7
000078805cdd5702  movaps [rsp+0x20], xmm11
000078805cdd5708  lea rdi, [rsp]
000078805cdd570c  mov esi, 0x00
000078805cdd5711  mov rax, 0x5771AD6EA530
000078805cdd571b  call rax
000078805cdd571d  movaps xmm1, [rsp]
000078805cdd5721  add rsp, 0x30
000078805cdd5725  vmovaps xmm0, [rsp]
000078805cdd572a  vmovaps xmm2, [rsp+0x10]
000078805cdd5730  vmovaps xmm3, [rsp+0x20]
000078805cdd5736  vmovaps xmm4, [rsp+0x30]
000078805cdd573c  vmovaps xmm5, [rsp+0x40]
000078805cdd5742  vmovaps xmm6, [rsp+0x50]
000078805cdd5748  vmovaps xmm7, [rsp+0x60]
000078805cdd574e  vmovaps xmm8, [rsp+0x70]
000078805cdd5754  vmovaps xmm9, [rsp+0x80]
000078805cdd575d  vmovaps xmm10, [rsp+0x90]
000078805cdd5766  vmovaps xmm11, [rsp+0xA0]
000078805cdd576f  vmovaps xmm12, [rsp+0xB0]
000078805cdd5778  vmovaps xmm13, [rsp+0xC0]
000078805cdd5781  vmovaps xmm14, [rsp+0xD0]
000078805cdd578a  vmovaps xmm15, [rsp+0xE0]
000078805cdd5793  add rsp, 0xF0
000078805cdd579a  pop r11
000078805cdd579c  pop r10
000078805cdd579e  pop r9
000078805cdd57a0  pop r8
000078805cdd57a2  pop rsi
000078805cdd57a3  pop rdi
000078805cdd57a4  pop rdx
000078805cdd57a5  pop rcx
000078805cdd57a6  pop rax
000078805cdd57a7  add rsp, 0x08
000078805cdd57ab  jmp 0x000078805CDD033B
000078805cdd57b0  call 0x000078805CC0E880
000078805cdd57b5  jmp 0x000078805CDD034E
000078805cdd57ba  call 0x000078805CC0C380
000078805cdd57bf  jmp 0x000078805CDD0359
000078805cdd57c4  call 0x000078805CC0D600
000078805cdd57c9  jmp 0x000078805CDD0364
000078805cdd57ce  call 0x000078805CBFF540
000078805cdd57d3  jmp 0x000078805CDD036F
000078805cdd57d8  int3
000078805cdd57d9  nop [rax], eax
000078805cdd57e0  mov rax, [r15+0x40]
000078805cdd57e4  mov r14, [r15+0x58]
000078805cdd57e8  lea r12, [rax+r14*1]
000078805cdd57ec  movaps xmm1, [r15+0x1D0]
000078805cdd57f4  vmovaps [rsp+0x10], xmm1
000078805cdd57fa  vmovaps xmm15, [rsp+0x10]
000078805cdd5800  por xmm1, xmm15
000078805cdd5805  movaps xmm14, [r15+0x1A0]
000078805cdd580d  vmovaps [rsp+0x10], xmm14
000078805cdd5813  vmovaps xmm13, [rsp+0x10]
000078805cdd5819  por xmm14, xmm13
000078805cdd581e  lea rax, [r12+0x30]
000078805cdd5823  mov r11, [r13+rax*1]
000078805cdd5828  lea rax, [r12+0x38]
000078805cdd582d  mov r10, [r13+rax*1]
000078805cdd5832  movq xmm13, r11
000078805cdd5837  movq xmm12, r10
000078805cdd583c  movq xmm13, xmm13
000078805cdd5841  vmovaps [rsp+0x10], xmm13
000078805cdd5847  movq xmm13, xmm13
000078805cdd584c  movaps [r15+0x130], xmm13
000078805cdd5854  movq xmm12, xmm12
000078805cdd5859  vmovaps [rsp+0x20], xmm12
000078805cdd585f  movq xmm12, xmm12
000078805cdd5864  movaps [r15+0x280], xmm12
000078805cdd586c  movaps xmm13, [r15+0x270]
000078805cdd5874  vmovaps [rsp+0x30], xmm13
000078805cdd587a  vmovaps xmm12, [rsp+0x30]
000078805cdd5880  por xmm13, xmm12
000078805cdd5885  lea rax, [r12+0x20]
000078805cdd588a  mov r11, [r13+rax*1]
000078805cdd588f  lea rax, [r12+0x28]
000078805cdd5894  mov r10, [r13+rax*1]
000078805cdd5899  movq xmm12, r11
000078805cdd589e  movq xmm11, r10
000078805cdd58a3  movq xmm12, xmm12
000078805cdd58a8  vmovaps [rsp+0x30], xmm12
000078805cdd58ae  movq xmm12, xmm12
000078805cdd58b3  movaps [r15+0x150], xmm12
000078805cdd58bb  movq xmm11, xmm11
000078805cdd58c0  vmovaps [rsp+0x40], xmm11
000078805cdd58c6  movq xmm11, xmm11
000078805cdd58cb  movaps [r15+0x140], xmm11
000078805cdd58d3  lea rax, [r12+0x10]
000078805cdd58d8  mov r11, [r13+rax*1]
000078805cdd58dd  lea rax, [r12+0x18]
000078805cdd58e2  mov r10, [r13+rax*1]
000078805cdd58e7  movq xmm12, r11
000078805cdd58ec  movq xmm11, r10
000078805cdd58f1  movq xmm12, xmm12
000078805cdd58f6  vmovaps [rsp+0x50], xmm12
000078805cdd58fc  movq xmm12, xmm12
000078805cdd5901  movaps [r15+0x170], xmm12
000078805cdd5909  movq xmm11, xmm11
000078805cdd590e  vmovaps [rsp+0x60], xmm11
000078805cdd5914  movq xmm11, xmm11
000078805cdd5919  movaps [r15+0x160], xmm11
000078805cdd5921  mov rax, [r13+r12*1]
000078805cdd5926  vmovq xmm12, rax
000078805cdd592b  vpbroadcastq xmm12, xmm12
000078805cdd5930  lea rax, [r12+0x08]
000078805cdd5935  mov r12, [r13+rax*1]
000078805cdd593a  movq xmm11, r12
000078805cdd593f  movaps [r15+0x230], xmm11
000078805cdd5947  mov rax, [r15+0xF8]
000078805cdd594e  lea r12, [rax+0x50]
000078805cdd5952  movups xmm11, [r13+r12*1]
000078805cdd5958  lea r12, [rax+0x60]
000078805cdd595c  movups xmm10, [r13+r12*1]
000078805cdd5962  lea r12, [rax+0x30]
000078805cdd5966  movups xmm9, [r13+r12*1]
000078805cdd596c  mov r12, [r15+0x50]
000078805cdd5970  lea r11, [r12+r14*1]
000078805cdd5974  mov [r15+0x60], r11
000078805cdd5978  lea r12, [r14+0x40]
000078805cdd597c  mov [r15+0x58], r12
000078805cdd5980  movaps xmm8, xmm12
000078805cdd5984  mulpd xmm8, xmm15
000078805cdd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000078805cdd598f  ptest xmm7, xmm7
000078805cdd5994  jnz 0x000078805CDD67B7
000078805cdd599a  movq xmm15, qword ptr [r15+0x230]
000078805cdd59a3  vmovaps [rsp+0x70], xmm15
000078805cdd59a9  vpermilpd xmm15, xmm15, 0x00
000078805cdd59af  movaps xmm7, xmm9
000078805cdd59b3  mulpd xmm7, xmm15
000078805cdd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000078805cdd59bd  ptest xmm6, xmm6
000078805cdd59c2  jnz 0x000078805CDD68FB
000078805cdd59c8  vxorps xmm15, xmm15, xmm15
000078805cdd59cd  vpbroadcastq xmm15, xmm15
000078805cdd59d2  movaps xmm9, xmm12
000078805cdd59d6  mulpd xmm9, xmm10
000078805cdd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000078805cdd59e1  ptest xmm6, xmm6
000078805cdd59e6  jnz 0x000078805CDD6A3D
000078805cdd59ec  movaps xmm10, xmm12
000078805cdd59f0  mulpd xmm10, xmm11
000078805cdd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000078805cdd59fb  ptest xmm6, xmm6
000078805cdd5a00  jnz 0x000078805CDD6B81
000078805cdd5a06  movaps xmm11, [r15+0x1F0]
000078805cdd5a0e  movaps xmm6, xmm12
000078805cdd5a12  mulpd xmm6, xmm11
000078805cdd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000078805cdd5a1c  ptest xmm5, xmm5
000078805cdd5a21  jnz 0x000078805CDD6CC5
000078805cdd5a27  movaps xmm12, [r15+0x2A0]
000078805cdd5a2f  vmovaps [rsp+0x80], xmm12
000078805cdd5a38  vmovaps xmm11, [rsp+0x80]
000078805cdd5a41  por xmm12, xmm11
000078805cdd5a46  movaps xmm11, [r15+0x250]
000078805cdd5a4e  vmovaps [rsp+0x80], xmm11
000078805cdd5a57  vmovaps xmm5, [rsp+0x80]
000078805cdd5a60  por xmm11, xmm5
000078805cdd5a65  vmovaps xmm4, [rsp+0x70]
000078805cdd5a6b  vpermilpd xmm4, xmm4, 0x00
000078805cdd5a71  movaps xmm3, xmm5
000078805cdd5a74  mulpd xmm3, xmm4
000078805cdd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000078805cdd5a7d  ptest xmm2, xmm2
000078805cdd5a82  jnz 0x000078805CDD6E07
000078805cdd5a88  mov [rsp+0x80], rax
000078805cdd5a90  xor eax, eax
000078805cdd5a92  mov r14d, 0x200
000078805cdd5a98  cmp r12, r14
000078805cdd5a9b  cmc
000078805cdd5a9c  lahf
000078805cdd5a9d  seto al
000078805cdd5aa0  mov [r15+0x108], eax
000078805cdd5aa7  movaps xmm5, xmm8
000078805cdd5aab  addpd xmm5, xmm15
000078805cdd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000078805cdd5ab5  ptest xmm4, xmm4
000078805cdd5aba  jnz 0x000078805CDD6F47
000078805cdd5ac0  movaps xmm8, [r15+0x1B0]
000078805cdd5ac8  movaps xmm4, xmm9
000078805cdd5acc  addpd xmm4, xmm8
000078805cdd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000078805cdd5ad6  ptest xmm2, xmm2
000078805cdd5adb  jnz 0x000078805CDD7089
000078805cdd5ae1  movaps xmm9, xmm10
000078805cdd5ae5  addpd xmm9, xmm8
000078805cdd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000078805cdd5af0  ptest xmm2, xmm2
000078805cdd5af5  jnz 0x000078805CDD71CB
000078805cdd5afb  movaps xmm10, [r15+0x2F0]
000078805cdd5b03  vmovaps [rsp+0x90], xmm10
000078805cdd5b0c  vmovaps xmm8, [rsp+0x90]
000078805cdd5b15  por xmm10, xmm8
000078805cdd5b1a  movaps xmm8, [r15+0x2E0]
000078805cdd5b22  vmovaps [rsp+0x90], xmm8
000078805cdd5b2b  vmovaps xmm2, [rsp+0x90]
000078805cdd5b34  por xmm8, xmm2
000078805cdd5b39  movaps xmm2, [r15+0x2D0]
000078805cdd5b41  vmovaps [rsp+0x90], xmm2
000078805cdd5b4a  vmovaps [rsp+0xA0], xmm1
000078805cdd5b53  vmovaps xmm1, [rsp+0x90]
000078805cdd5b5c  por xmm2, xmm1
000078805cdd5b60  movaps xmm1, [r15+0x200]
000078805cdd5b68  vmovaps [rsp+0x90], xmm1
000078805cdd5b71  vmovaps [rsp+0xB0], xmm15
000078805cdd5b7a  vmovaps xmm15, [rsp+0x90]
000078805cdd5b83  por xmm1, xmm15
000078805cdd5b88  movaps xmm15, [r15+0x1C0]
000078805cdd5b90  vmovaps [rsp+0x90], xmm15
000078805cdd5b99  vmovaps [rsp+0xC0], xmm1
000078805cdd5ba2  vmovaps xmm1, [rsp+0x90]
000078805cdd5bab  por xmm15, xmm1
000078805cdd5bb0  movaps xmm1, [r15+0x190]
000078805cdd5bb8  vmovaps [rsp+0x90], xmm1
000078805cdd5bc1  vmovaps [rsp+0xD0], xmm15
000078805cdd5bca  vmovaps xmm15, [rsp+0x90]
000078805cdd5bd3  por xmm1, xmm15
000078805cdd5bd8  movaps xmm15, [r15+0x300]
000078805cdd5be0  vmovaps [rsp+0x90], xmm15
000078805cdd5be9  vmovaps [rsp+0xE0], xmm1
000078805cdd5bf2  vmovaps xmm1, [rsp+0x90]
000078805cdd5bfb  por xmm15, xmm1
000078805cdd5c00  mov rax, [rsp+0x80]
000078805cdd5c08  lea r14, [rax+0xA0]
000078805cdd5c0f  movups xmm1, [r13+r14*1]
000078805cdd5c15  lea r14, [rax+0xB0]
000078805cdd5c1c  vmovaps [rsp+0x80], xmm1
000078805cdd5c25  movups xmm1, [r13+r14*1]
000078805cdd5c2b  vmovaps [rsp+0x90], xmm1
000078805cdd5c34  vmovaps [rsp+0xF0], xmm15
000078805cdd5c3d  vmovaps xmm15, [rsp+0xB0]
000078805cdd5c46  vmovaps [rsp+0xB0], xmm14
000078805cdd5c4f  movaps xmm1, xmm6
000078805cdd5c52  addpd xmm1, xmm15
000078805cdd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000078805cdd5c5c  ptest xmm14, xmm14
000078805cdd5c62  jnz 0x000078805CDD7323
000078805cdd5c68  lea r14, [rax+0xF0]
000078805cdd5c6f  movups xmm15, [r13+r14*1]
000078805cdd5c75  movaps xmm14, xmm4
000078805cdd5c79  addpd xmm14, xmm3
000078805cdd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000078805cdd5c84  ptest xmm6, xmm6
000078805cdd5c89  jnz 0x000078805CDD746E
000078805cdd5c8f  movaps xmm6, xmm9
000078805cdd5c93  addpd xmm6, xmm7
000078805cdd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000078805cdd5c9c  ptest xmm4, xmm4
000078805cdd5ca1  jnz 0x000078805CDD75B0
000078805cdd5ca7  vmovaps xmm9, [rsp+0x70]
000078805cdd5cad  vpermilpd xmm9, xmm9, 0x00
000078805cdd5cb3  vmovaps xmm4, [rsp+0x90]
000078805cdd5cbc  movaps xmm7, xmm4
000078805cdd5cbf  mulpd xmm7, xmm9
000078805cdd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000078805cdd5cc9  ptest xmm3, xmm3
000078805cdd5cce  jnz 0x000078805CDD76F1
000078805cdd5cd4  vmovaps xmm9, [rsp+0x50]
000078805cdd5cda  vpermilpd xmm9, xmm9, 0x00
000078805cdd5ce0  movaps xmm4, xmm15
000078805cdd5ce4  mulpd xmm4, xmm9
000078805cdd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000078805cdd5cee  ptest xmm3, xmm3
000078805cdd5cf3  jnz 0x000078805CDD7832
000078805cdd5cf9  lea r14, [rax+0xE0]
000078805cdd5d00  movups xmm15, [r13+r14*1]
000078805cdd5d06  vmovaps xmm9, [rsp+0x70]
000078805cdd5d0c  vpermilpd xmm9, xmm9, 0x00
000078805cdd5d12  vmovaps [rsp+0x70], xmm1
000078805cdd5d18  vmovaps xmm1, [rsp+0x80]
000078805cdd5d21  vmovaps [rsp+0x80], xmm15
000078805cdd5d2a  movaps xmm3, xmm1
000078805cdd5d2d  mulpd xmm3, xmm9
000078805cdd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000078805cdd5d37  ptest xmm15, xmm15
000078805cdd5d3d  jnz 0x000078805CDD797E
000078805cdd5d43  vmovaps xmm1, [rsp+0xF0]
000078805cdd5d4c  vmovaps xmm15, [rsp+0xF0]
000078805cdd5d55  por xmm1, xmm15
000078805cdd5d5a  movaps [r15+0x300], xmm1
000078805cdd5d62  vmovaps xmm15, [rsp+0xE0]
000078805cdd5d6b  vmovaps xmm9, [rsp+0xE0]
000078805cdd5d74  por xmm15, xmm9
000078805cdd5d79  movaps [r15+0x190], xmm15
000078805cdd5d81  vmovaps xmm9, [rsp+0x50]
000078805cdd5d87  vpermilpd xmm9, xmm9, 0x00
000078805cdd5d8d  vmovaps [rsp+0x90], xmm1
000078805cdd5d96  vmovaps [rsp+0xE0], xmm15
000078805cdd5d9f  vmovaps xmm15, [rsp+0x80]
000078805cdd5da8  vmovaps [rsp+0x80], xmm14
000078805cdd5db1  movaps xmm1, xmm15
000078805cdd5db5  mulpd xmm1, xmm9
000078805cdd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000078805cdd5dbf  ptest xmm14, xmm14
000078805cdd5dc5  jnz 0x000078805CDD7ABF
000078805cdd5dcb  lea r14, [rax+0x90]
000078805cdd5dd2  movups xmm15, [r13+r14*1]
000078805cdd5dd8  vmovaps xmm14, [rsp+0xD0]
000078805cdd5de1  vmovaps xmm9, [rsp+0xD0]
000078805cdd5dea  por xmm14, xmm9
000078805cdd5def  movaps [r15+0x1C0], xmm14
000078805cdd5df7  vmovaps xmm9, [rsp+0xC0]
000078805cdd5e00  vmovaps [rsp+0xD0], xmm1
000078805cdd5e09  vmovaps xmm1, [rsp+0xC0]
000078805cdd5e12  por xmm9, xmm1
000078805cdd5e17  movaps [r15+0x200], xmm9
000078805cdd5e1f  vmovaps [rsp+0xC0], xmm2
000078805cdd5e28  vmovaps xmm1, [rsp+0xC0]
000078805cdd5e31  por xmm2, xmm1
000078805cdd5e35  movaps [r15+0x2D0], xmm2
000078805cdd5e3d  vmovaps [rsp+0xC0], xmm8
000078805cdd5e46  vmovaps xmm1, [rsp+0xC0]
000078805cdd5e4f  por xmm8, xmm1
000078805cdd5e54  movaps [r15+0x2E0], xmm8
000078805cdd5e5c  vmovaps [rsp+0xC0], xmm15
000078805cdd5e65  movaps xmm1, xmm5
000078805cdd5e68  addpd xmm1, xmm7
000078805cdd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000078805cdd5e71  ptest xmm15, xmm15
000078805cdd5e77  jnz 0x000078805CDD7C0B
000078805cdd5e7d  vmovaps xmm15, [rsp+0x50]
000078805cdd5e83  vpermilpd xmm15, xmm15, 0x00
000078805cdd5e89  vmovaps xmm5, [rsp+0xC0]
000078805cdd5e92  vmovaps [rsp+0xC0], xmm1
000078805cdd5e9b  movaps xmm7, xmm5
000078805cdd5e9e  mulpd xmm7, xmm15
000078805cdd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000078805cdd5ea8  ptest xmm1, xmm1
000078805cdd5ead  jnz 0x000078805CDD7D4B
000078805cdd5eb3  lea r14, [rax+0x80]
000078805cdd5eba  movups xmm1, [r13+r14*1]
000078805cdd5ec0  vmovaps xmm5, [rsp+0x70]
000078805cdd5ec6  vmovaps [rsp+0x70], xmm1
000078805cdd5ecc  movaps xmm15, xmm5
000078805cdd5ed0  addpd xmm15, xmm3
000078805cdd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cdd5edb  ptest xmm1, xmm1
000078805cdd5ee0  jnz 0x000078805CDD7E96
000078805cdd5ee6  vmovaps xmm5, [rsp+0x80]
000078805cdd5eef  movaps xmm1, xmm5
000078805cdd5ef2  addpd xmm1, xmm4
000078805cdd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000078805cdd5efb  ptest xmm3, xmm3
000078805cdd5f00  jnz 0x000078805CDD7FD8
000078805cdd5f06  vmovaps [rsp+0x80], xmm10
000078805cdd5f0f  vmovaps xmm5, [rsp+0x80]
000078805cdd5f18  por xmm10, xmm5
000078805cdd5f1d  movaps [r15+0x2F0], xmm10
000078805cdd5f25  vmovaps xmm5, [rsp+0x50]
000078805cdd5f2b  vpermilpd xmm5, xmm5, 0x00
000078805cdd5f31  vmovaps xmm3, [rsp+0x70]
000078805cdd5f37  vmovaps [rsp+0x50], xmm1
000078805cdd5f3d  movaps xmm4, xmm3
000078805cdd5f40  mulpd xmm4, xmm5
000078805cdd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000078805cdd5f49  ptest xmm1, xmm1
000078805cdd5f4e  jnz 0x000078805CDD8118
000078805cdd5f54  lea r14, [rax+0xD0]
000078805cdd5f5b  movups xmm1, [r13+r14*1]
000078805cdd5f61  vmovaps xmm3, [rsp+0xD0]
000078805cdd5f6a  vmovaps [rsp+0x70], xmm1
000078805cdd5f70  movaps xmm5, xmm6
000078805cdd5f73  addpd xmm5, xmm3
000078805cdd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000078805cdd5f7c  ptest xmm1, xmm1
000078805cdd5f81  jnz 0x000078805CDD8262
000078805cdd5f87  vmovaps xmm1, [rsp+0x60]
000078805cdd5f8d  vpermilpd xmm1, xmm1, 0x00
000078805cdd5f93  movaps xmm6, xmm9
000078805cdd5f97  mulpd xmm6, xmm1
000078805cdd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000078805cdd5fa0  ptest xmm3, xmm3
000078805cdd5fa5  jnz 0x000078805CDD83A2
000078805cdd5fab  movaps [r15+0x260], xmm6
000078805cdd5fb3  vxorps xmm1, xmm1, xmm1
000078805cdd5fb7  vpbroadcastq xmm1, xmm1
000078805cdd5fbc  movaps [r15+0x1B0], xmm1
000078805cdd5fc4  vmovaps xmm1, [rsp+0x60]
000078805cdd5fca  vpermilpd xmm1, xmm1, 0x00
000078805cdd5fd0  vmovaps xmm3, [rsp+0x70]
000078805cdd5fd6  vmovaps [rsp+0x70], xmm15
000078805cdd5fdc  movaps xmm9, xmm3
000078805cdd5fe0  mulpd xmm9, xmm1
000078805cdd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000078805cdd5feb  ptest xmm15, xmm15
000078805cdd5ff1  jnz 0x000078805CDD84E3
000078805cdd5ff7  lea r14, [rax+0xC0]
000078805cdd5ffe  movups xmm1, [r13+r14*1]
000078805cdd6004  vmovaps xmm3, [rsp+0xC0]
000078805cdd600d  vmovaps [rsp+0x80], xmm1
000078805cdd6016  movaps xmm15, xmm3
000078805cdd601a  addpd xmm15, xmm7
000078805cdd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cdd6025  ptest xmm1, xmm1
000078805cdd602a  jnz 0x000078805CDD862F
000078805cdd6030  vmovaps [rsp+0xC0], xmm13
000078805cdd6039  vmovaps xmm1, [rsp+0xC0]
000078805cdd6042  por xmm13, xmm1
000078805cdd6047  movaps [r15+0x270], xmm13
000078805cdd604f  vmovaps xmm1, [rsp+0xB0]
000078805cdd6058  vmovaps xmm7, [rsp+0xB0]
000078805cdd6061  por xmm1, xmm7
000078805cdd6065  movaps [r15+0x1A0], xmm1
000078805cdd606d  vmovaps xmm1, [rsp+0x60]
000078805cdd6073  vpermilpd xmm1, xmm1, 0x00
000078805cdd6079  vmovaps [rsp+0xB0], xmm1
000078805cdd6082  vmovaps xmm1, [rsp+0x80]
000078805cdd608b  vmovaps [rsp+0x80], xmm15
000078805cdd6094  vmovaps xmm15, [rsp+0xB0]
000078805cdd609d  vmovaps [rsp+0xB0], xmm14
000078805cdd60a6  movaps xmm3, xmm1
000078805cdd60a9  mulpd xmm3, xmm15
000078805cdd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000078805cdd60b3  ptest xmm14, xmm14
000078805cdd60b9  jnz 0x000078805CDD8771
000078805cdd60bf  lea r14, [rax+0x20]
000078805cdd60c3  movups xmm1, [r13+r14*1]
000078805cdd60c9  movaps [r15+0x110], xmm1
000078805cdd60d1  vmovaps xmm14, [rsp+0x70]
000078805cdd60d7  vmovaps [rsp+0x70], xmm1
000078805cdd60dd  movaps xmm15, xmm14
000078805cdd60e1  addpd xmm15, xmm4
000078805cdd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cdd60ec  ptest xmm1, xmm1
000078805cdd60f1  jnz 0x000078805CDD88BC
000078805cdd60f7  vmovaps xmm1, [rsp+0x60]
000078805cdd60fd  vpermilpd xmm1, xmm1, 0x00
000078805cdd6103  movaps xmm14, xmm2
000078805cdd6107  mulpd xmm14, xmm1
000078805cdd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000078805cdd6112  ptest xmm4, xmm4
000078805cdd6117  jnz 0x000078805CDD89FF
000078805cdd611d  vmovaps xmm4, [rsp+0x50]
000078805cdd6123  movaps xmm1, xmm4
000078805cdd6126  addpd xmm1, xmm9
000078805cdd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000078805cdd6130  ptest xmm2, xmm2
000078805cdd6135  jnz 0x000078805CDD8B41
000078805cdd613b  vmovaps xmm9, [rsp+0x30]
000078805cdd6141  vpermilpd xmm9, xmm9, 0x00
000078805cdd6147  vmovaps xmm2, [rsp+0x70]
000078805cdd614d  vmovaps [rsp+0x50], xmm1
000078805cdd6153  movaps xmm4, xmm2
000078805cdd6156  mulpd xmm4, xmm9
000078805cdd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000078805cdd6160  ptest xmm1, xmm1
000078805cdd6165  jnz 0x000078805CDD8C82
000078805cdd616b  vmovaps xmm1, [rsp+0x30]
000078805cdd6171  vpermilpd xmm1, xmm1, 0x00
000078805cdd6177  vmovaps xmm2, [rsp+0x90]
000078805cdd6180  vmovaps [rsp+0x60], xmm15
000078805cdd6186  movaps xmm9, xmm2
000078805cdd618a  mulpd xmm9, xmm1
000078805cdd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000078805cdd6195  ptest xmm15, xmm15
000078805cdd619b  jnz 0x000078805CDD8DC3
000078805cdd61a1  vmovaps xmm15, [rsp+0x80]
000078805cdd61aa  movaps xmm1, xmm15
000078805cdd61ae  addpd xmm1, xmm6
000078805cdd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000078805cdd61b7  ptest xmm2, xmm2
000078805cdd61bc  jnz 0x000078805CDD8F05
000078805cdd61c2  movaps xmm15, xmm5
000078805cdd61c6  addpd xmm15, xmm3
000078805cdd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000078805cdd61d1  ptest xmm6, xmm6
000078805cdd61d6  jnz 0x000078805CDD9046
000078805cdd61dc  vmovaps xmm6, [rsp+0x30]
000078805cdd61e2  vpermilpd xmm6, xmm6, 0x00
000078805cdd61e8  movaps xmm5, xmm8
000078805cdd61ec  mulpd xmm5, xmm6
000078805cdd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000078805cdd61f5  ptest xmm3, xmm3
000078805cdd61fa  jnz 0x000078805CDD9188
000078805cdd6200  vmovaps xmm8, [rsp+0x30]
000078805cdd6206  vpermilpd xmm8, xmm8, 0x00
000078805cdd620c  movaps xmm6, xmm10
000078805cdd6210  mulpd xmm6, xmm8
000078805cdd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000078805cdd621a  ptest xmm3, xmm3
000078805cdd621f  jnz 0x000078805CDD92C9
000078805cdd6225  vmovaps xmm8, [rsp+0x60]
000078805cdd622b  movaps xmm10, xmm8
000078805cdd622f  addpd xmm10, xmm14
000078805cdd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000078805cdd623a  ptest xmm3, xmm3
000078805cdd623f  jnz 0x000078805CDD940B
000078805cdd6245  vmovaps xmm8, [rsp+0x50]
000078805cdd624b  movaps xmm14, xmm8
000078805cdd624f  addpd xmm14, xmm4
000078805cdd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000078805cdd625a  ptest xmm3, xmm3
000078805cdd625f  jnz 0x000078805CDD954F
000078805cdd6265  vmovaps xmm8, [rsp+0x40]
000078805cdd626b  vpermilpd xmm8, xmm8, 0x00
000078805cdd6271  movaps xmm4, xmm13
000078805cdd6275  mulpd xmm4, xmm8
000078805cdd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000078805cdd627f  ptest xmm3, xmm3
000078805cdd6284  jnz 0x000078805CDD9692
000078805cdd628a  movaps xmm13, xmm15
000078805cdd628e  addpd xmm13, xmm9
000078805cdd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000078805cdd6299  ptest xmm8, xmm8
000078805cdd629f  jnz 0x000078805CDD97D4
000078805cdd62a5  movaps xmm15, xmm1
000078805cdd62a9  addpd xmm15, xmm5
000078805cdd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000078805cdd62b4  ptest xmm9, xmm9
000078805cdd62ba  jnz 0x000078805CDD9918
000078805cdd62c0  vmovaps [rsp+0x30], xmm11
000078805cdd62c6  vmovaps xmm1, [rsp+0x30]
000078805cdd62cc  por xmm11, xmm1
000078805cdd62d1  movaps [r15+0x250], xmm11
000078805cdd62d9  vmovaps [rsp+0x30], xmm12
000078805cdd62df  vmovaps xmm1, [rsp+0x30]
000078805cdd62e5  por xmm12, xmm1
000078805cdd62ea  movaps [r15+0x2A0], xmm12
000078805cdd62f2  vmovaps xmm1, [rsp+0xA0]
000078805cdd62fb  vmovaps xmm11, [rsp+0xA0]
000078805cdd6304  por xmm1, xmm11
000078805cdd6309  movaps [r15+0x1D0], xmm1
000078805cdd6311  lea r14, [rax+0x40]
000078805cdd6315  movups xmm1, [r13+r14*1]
000078805cdd631b  movaps [r15+0x2C0], xmm1
000078805cdd6323  vmovaps xmm11, [rsp+0x40]
000078805cdd6329  vpermilpd xmm11, xmm11, 0x00
000078805cdd632f  vmovaps xmm8, [rsp+0xE0]
000078805cdd6338  movaps xmm9, xmm8
000078805cdd633c  mulpd xmm9, xmm11
000078805cdd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000078805cdd6347  ptest xmm5, xmm5
000078805cdd634c  jnz 0x000078805CDD9A64
000078805cdd6352  movaps xmm11, xmm10
000078805cdd6356  addpd xmm11, xmm6
000078805cdd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000078805cdd6361  ptest xmm8, xmm8
000078805cdd6367  jnz 0x000078805CDD9BA8
000078805cdd636d  movaps xmm10, xmm14
000078805cdd6371  addpd xmm10, xmm4
000078805cdd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000078805cdd637c  ptest xmm8, xmm8
000078805cdd6382  jnz 0x000078805CDD9CEB
000078805cdd6388  vmovaps xmm14, [rsp+0x40]
000078805cdd638e  vpermilpd xmm14, xmm14, 0x00
000078805cdd6394  movaps xmm8, xmm1
000078805cdd6398  mulpd xmm8, xmm14
000078805cdd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000078805cdd63a3  ptest xmm6, xmm6
000078805cdd63a8  jnz 0x000078805CDD9E2E
000078805cdd63ae  movaps xmm1, [r15+0x2B0]
000078805cdd63b6  vmovaps xmm14, [rsp+0x40]
000078805cdd63bc  vpermilpd xmm14, xmm14, 0x00
000078805cdd63c2  movaps xmm6, xmm1
000078805cdd63c5  mulpd xmm6, xmm14
000078805cdd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000078805cdd63cf  ptest xmm5, xmm5
000078805cdd63d4  jnz 0x000078805CDD9F71
000078805cdd63da  vmovaps xmm1, [rsp+0x10]
000078805cdd63e0  vpermilpd xmm1, xmm1, 0x00
000078805cdd63e6  movaps xmm14, xmm12
000078805cdd63ea  mulpd xmm14, xmm1
000078805cdd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000078805cdd63f5  ptest xmm5, xmm5
000078805cdd63fa  jnz 0x000078805CDDA0B2
000078805cdd6400  movaps xmm1, xmm13
000078805cdd6404  addpd xmm1, xmm9
000078805cdd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000078805cdd640e  ptest xmm12, xmm12
000078805cdd6414  jnz 0x000078805CDDA1F5
000078805cdd641a  vmovaps xmm13, [rsp+0x10]
000078805cdd6420  vpermilpd xmm13, xmm13, 0x00
000078805cdd6426  movaps xmm12, xmm7
000078805cdd642a  mulpd xmm12, xmm13
000078805cdd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000078805cdd6435  ptest xmm9, xmm9
000078805cdd643b  jnz 0x000078805CDDA337
000078805cdd6441  movaps xmm13, xmm15
000078805cdd6445  addpd xmm13, xmm8
000078805cdd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000078805cdd6450  ptest xmm9, xmm9
000078805cdd6456  jnz 0x000078805CDDA47A
000078805cdd645c  movaps xmm15, [r15+0x290]
000078805cdd6464  vmovaps xmm9, [rsp+0x10]
000078805cdd646a  vpermilpd xmm9, xmm9, 0x00
000078805cdd6470  movaps xmm8, xmm15
000078805cdd6474  mulpd xmm8, xmm9
000078805cdd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000078805cdd647f  ptest xmm7, xmm7
000078805cdd6484  jnz 0x000078805CDDA5BE
000078805cdd648a  movaps xmm15, xmm11
000078805cdd648e  addpd xmm15, xmm6
000078805cdd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000078805cdd6499  ptest xmm9, xmm9
000078805cdd649f  jnz 0x000078805CDDA702
000078805cdd64a5  movaps xmm11, [r15+0x1E0]
000078805cdd64ad  vmovaps xmm9, [rsp+0x10]
000078805cdd64b3  vpermilpd xmm9, xmm9, 0x00
000078805cdd64b9  movaps xmm7, xmm11
000078805cdd64bd  mulpd xmm7, xmm9
000078805cdd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000078805cdd64c7  ptest xmm6, xmm6
000078805cdd64cc  jnz 0x000078805CDDA845
000078805cdd64d2  movaps xmm11, xmm10
000078805cdd64d6  addpd xmm11, xmm14
000078805cdd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000078805cdd64e1  ptest xmm9, xmm9
000078805cdd64e7  jnz 0x000078805CDDA987
000078805cdd64ed  lea r14, [rax+0x70]
000078805cdd64f1  movups xmm14, [r13+r14*1]
000078805cdd64f7  movaps [r15+0x240], xmm14
000078805cdd64ff  movaps xmm10, xmm1
000078805cdd6503  addpd xmm10, xmm12
000078805cdd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000078805cdd650e  ptest xmm9, xmm9
000078805cdd6514  jnz 0x000078805CDDAAD5
000078805cdd651a  movaps [r15+0x170], xmm10
000078805cdd6522  vmovaps xmm1, [rsp+0x20]
000078805cdd6528  vpermilpd xmm1, xmm1, 0x00
000078805cdd652e  movaps xmm12, xmm14
000078805cdd6532  mulpd xmm12, xmm1
000078805cdd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000078805cdd653d  ptest xmm9, xmm9
000078805cdd6543  jnz 0x000078805CDDAC18
000078805cdd6549  vmovaps xmm1, [rsp+0x20]
000078805cdd654f  vpermilpd xmm1, xmm1, 0x00
000078805cdd6555  vmovaps xmm9, [rsp+0xB0]
000078805cdd655e  movaps xmm14, xmm9
000078805cdd6562  mulpd xmm14, xmm1
000078805cdd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000078805cdd656d  ptest xmm6, xmm6
000078805cdd6572  jnz 0x000078805CDDAD5B
000078805cdd6578  movaps [r15+0x180], xmm14
000078805cdd6580  movaps xmm1, xmm13
000078805cdd6584  addpd xmm1, xmm8
000078805cdd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000078805cdd658e  ptest xmm9, xmm9
000078805cdd6594  jnz 0x000078805CDDAE9E
000078805cdd659a  movaps [r15+0x210], xmm1
000078805cdd65a2  movups xmm13, [r13+rax*1]
000078805cdd65a8  lea r14, [rax+0x10]
000078805cdd65ac  movups xmm9, [r13+r14*1]
000078805cdd65b2  movaps [r15+0x230], xmm9
000078805cdd65ba  movaps xmm8, xmm15
000078805cdd65be  addpd xmm8, xmm7
000078805cdd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000078805cdd65c9  ptest xmm6, xmm6
000078805cdd65ce  jnz 0x000078805CDDAFF4
000078805cdd65d4  movaps [r15+0x130], xmm8
000078805cdd65dc  vmovaps xmm15, [rsp+0x20]
000078805cdd65e2  vpermilpd xmm15, xmm15, 0x00
000078805cdd65e8  movaps xmm7, xmm9
000078805cdd65ec  mulpd xmm7, xmm15
000078805cdd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000078805cdd65f6  ptest xmm6, xmm6
000078805cdd65fb  jnz 0x000078805CDDB137
000078805cdd6601  movaps [r15+0x220], xmm7
000078805cdd6609  vmovaps xmm15, [rsp+0x20]
000078805cdd660f  vpermilpd xmm15, xmm15, 0x00
000078805cdd6615  movaps xmm9, xmm13
000078805cdd6619  mulpd xmm9, xmm15
000078805cdd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000078805cdd6624  ptest xmm6, xmm6
000078805cdd6629  jnz 0x000078805CDDB279
000078805cdd662f  movaps xmm15, xmm11
000078805cdd6633  addpd xmm15, xmm12
000078805cdd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000078805cdd663e  ptest xmm13, xmm13
000078805cdd6644  jnz 0x000078805CDDB3BD
000078805cdd664a  movaps [r15+0x140], xmm15
000078805cdd6652  movaps xmm13, xmm10
000078805cdd6656  addpd xmm13, xmm14
000078805cdd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000078805cdd6661  ptest xmm12, xmm12
000078805cdd6667  jnz 0x000078805CDDB501
000078805cdd666d  movaps [r15+0x150], xmm13
000078805cdd6675  movaps xmm14, xmm1
000078805cdd6679  addpd xmm14, xmm7
000078805cdd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000078805cdd6684  ptest xmm12, xmm12
000078805cdd668a  jnz 0x000078805CDDB645
000078805cdd6690  movaps [r15+0x160], xmm14
000078805cdd6698  movaps xmm1, xmm8
000078805cdd669c  addpd xmm1, xmm9
000078805cdd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000078805cdd66a6  ptest xmm12, xmm12
000078805cdd66ac  jnz 0x000078805CDDB787
000078805cdd66b2  movaps [r15+0x120], xmm1
000078805cdd66ba  movups [r13+r11*1], xmm15
000078805cdd66c0  lea rax, [r11+0x10]
000078805cdd66c4  movups [r13+rax*1], xmm13
000078805cdd66ca  lea rax, [r11+0x20]
000078805cdd66ce  movups [r13+rax*1], xmm14
000078805cdd66d4  lea rax, [r11+0x30]
000078805cdd66d8  movups [r13+rax*1], xmm1
000078805cdd66de  mov eax, [r15+0x108]
000078805cdd66e5  sahf
000078805cdd66e6  jnz 0x000078805CDD6718
000078805cdd66e8  cmp dword ptr [r15+0x318], 0x00
000078805cdd66f0  jz 0x000078805CDDB900
000078805cdd66f6  nop [rax+rax*1], ax
000078805cdd66ff  nop [rax+rax*1], eax
000078805cdd6707  mov eax, 0x410444
000078805cdd670c  mov [r15+0x100], rax
000078805cdd6713  jmp 0x000078805CBFE110
000078805cdd6718  cmp dword ptr [r15+0x318], 0x00
000078805cdd6720  jz 0x000078805CDD57E0
000078805cdd6726  nop [rax+rax*1], ax
000078805cdd672f  nop [rax+rax*1], eax
000078805cdd6737  mov eax, 0x410278
000078805cdd673c  mov [r15+0x100], rax
000078805cdd6743  jmp 0x000078805CBFE110
000078805cdd6748  int3
000078805cdd6749  call 0x000078805CC0A4B0
000078805cdd674e  jmp 0x000078805CDD5828
000078805cdd6753  call 0x000078805CC09240
000078805cdd6758  jmp 0x000078805CDD5832
000078805cdd675d  call 0x000078805CC0A4B0
000078805cdd6762  jmp 0x000078805CDD588F
000078805cdd6767  call 0x000078805CC09240
000078805cdd676c  jmp 0x000078805CDD5899
000078805cdd6771  call 0x000078805CC0A4B0
000078805cdd6776  jmp 0x000078805CDD58DD
000078805cdd677b  call 0x000078805CC09240
000078805cdd6780  jmp 0x000078805CDD58E7
000078805cdd6785  call 0x000078805CCB47C0
000078805cdd678a  jmp 0x000078805CDD5926
000078805cdd678f  call 0x000078805CC0B720
000078805cdd6794  jmp 0x000078805CDD593A
000078805cdd6799  call 0x000078805CCBFC30
000078805cdd679e  jmp 0x000078805CDD5958
000078805cdd67a3  call 0x000078805CCBE9C0
000078805cdd67a8  jmp 0x000078805CDD5962
000078805cdd67ad  call 0x000078805CCBD750
000078805cdd67b2  jmp 0x000078805CDD596C
000078805cdd67b7  sub rsp, 0x08
000078805cdd67bb  push rax
000078805cdd67bc  push rcx
000078805cdd67bd  push rdx
000078805cdd67be  push rdi
000078805cdd67bf  push rsi
000078805cdd67c0  push r8
000078805cdd67c2  push r9
000078805cdd67c4  push r10
000078805cdd67c6  push r11
000078805cdd67c8  sub rsp, 0xF0
000078805cdd67cf  vmovaps [rsp], xmm0
000078805cdd67d4  vmovaps [rsp+0x10], xmm1
000078805cdd67da  vmovaps [rsp+0x20], xmm2
000078805cdd67e0  vmovaps [rsp+0x30], xmm3
000078805cdd67e6  vmovaps [rsp+0x40], xmm4
000078805cdd67ec  vmovaps [rsp+0x50], xmm5
000078805cdd67f2  vmovaps [rsp+0x60], xmm6
000078805cdd67f8  vmovaps [rsp+0x70], xmm7
000078805cdd67fe  vmovaps [rsp+0x80], xmm9
000078805cdd6807  vmovaps [rsp+0x90], xmm10
000078805cdd6810  vmovaps [rsp+0xA0], xmm11
000078805cdd6819  vmovaps [rsp+0xB0], xmm12
000078805cdd6822  vmovaps [rsp+0xC0], xmm13
000078805cdd682b  vmovaps [rsp+0xD0], xmm14
000078805cdd6834  vmovaps [rsp+0xE0], xmm15
000078805cdd683d  sub rsp, 0x30
000078805cdd6841  movaps [rsp], xmm8
000078805cdd6846  movaps [rsp+0x10], xmm12
000078805cdd684c  movaps [rsp+0x20], xmm15
000078805cdd6852  lea rdi, [rsp]
000078805cdd6856  mov esi, 0x00
000078805cdd685b  mov rax, 0x5771AD6EA530
000078805cdd6865  call rax
000078805cdd6867  movaps xmm8, [rsp]
000078805cdd686c  add rsp, 0x30
000078805cdd6870  vmovaps xmm0, [rsp]
000078805cdd6875  vmovaps xmm1, [rsp+0x10]
000078805cdd687b  vmovaps xmm2, [rsp+0x20]
000078805cdd6881  vmovaps xmm3, [rsp+0x30]
000078805cdd6887  vmovaps xmm4, [rsp+0x40]
000078805cdd688d  vmovaps xmm5, [rsp+0x50]
000078805cdd6893  vmovaps xmm6, [rsp+0x60]
000078805cdd6899  vmovaps xmm7, [rsp+0x70]
000078805cdd689f  vmovaps xmm9, [rsp+0x80]
000078805cdd68a8  vmovaps xmm10, [rsp+0x90]
000078805cdd68b1  vmovaps xmm11, [rsp+0xA0]
000078805cdd68ba  vmovaps xmm12, [rsp+0xB0]
000078805cdd68c3  vmovaps xmm13, [rsp+0xC0]
000078805cdd68cc  vmovaps xmm14, [rsp+0xD0]
000078805cdd68d5  vmovaps xmm15, [rsp+0xE0]
000078805cdd68de  add rsp, 0xF0
000078805cdd68e5  pop r11
000078805cdd68e7  pop r10
000078805cdd68e9  pop r9
000078805cdd68eb  pop r8
000078805cdd68ed  pop rsi
000078805cdd68ee  pop rdi
000078805cdd68ef  pop rdx
000078805cdd68f0  pop rcx
000078805cdd68f1  pop rax
000078805cdd68f2  add rsp, 0x08
000078805cdd68f6  jmp 0x000078805CDD599A
000078805cdd68fb  sub rsp, 0x08
000078805cdd68ff  push rax
000078805cdd6900  push rcx
000078805cdd6901  push rdx
000078805cdd6902  push rdi
000078805cdd6903  push rsi
000078805cdd6904  push r8
000078805cdd6906  push r9
000078805cdd6908  push r10
000078805cdd690a  push r11
000078805cdd690c  sub rsp, 0xF0
000078805cdd6913  vmovaps [rsp], xmm0
000078805cdd6918  vmovaps [rsp+0x10], xmm1
000078805cdd691e  vmovaps [rsp+0x20], xmm2
000078805cdd6924  vmovaps [rsp+0x30], xmm3
000078805cdd692a  vmovaps [rsp+0x40], xmm4
000078805cdd6930  vmovaps [rsp+0x50], xmm5
000078805cdd6936  vmovaps [rsp+0x60], xmm6
000078805cdd693c  vmovaps [rsp+0x70], xmm8
000078805cdd6942  vmovaps [rsp+0x80], xmm9
000078805cdd694b  vmovaps [rsp+0x90], xmm10
000078805cdd6954  vmovaps [rsp+0xA0], xmm11
000078805cdd695d  vmovaps [rsp+0xB0], xmm12
000078805cdd6966  vmovaps [rsp+0xC0], xmm13
000078805cdd696f  vmovaps [rsp+0xD0], xmm14
000078805cdd6978  vmovaps [rsp+0xE0], xmm15
000078805cdd6981  sub rsp, 0x30
000078805cdd6985  movaps [rsp], xmm7
000078805cdd6989  movaps [rsp+0x10], xmm9
000078805cdd698f  movaps [rsp+0x20], xmm15
000078805cdd6995  lea rdi, [rsp]
000078805cdd6999  mov esi, 0x00
000078805cdd699e  mov rax, 0x5771AD6EA530
000078805cdd69a8  call rax
000078805cdd69aa  movaps xmm7, [rsp]
000078805cdd69ae  add rsp, 0x30
000078805cdd69b2  vmovaps xmm0, [rsp]
000078805cdd69b7  vmovaps xmm1, [rsp+0x10]
000078805cdd69bd  vmovaps xmm2, [rsp+0x20]
000078805cdd69c3  vmovaps xmm3, [rsp+0x30]
000078805cdd69c9  vmovaps xmm4, [rsp+0x40]
000078805cdd69cf  vmovaps xmm5, [rsp+0x50]
000078805cdd69d5  vmovaps xmm6, [rsp+0x60]
000078805cdd69db  vmovaps xmm8, [rsp+0x70]
000078805cdd69e1  vmovaps xmm9, [rsp+0x80]
000078805cdd69ea  vmovaps xmm10, [rsp+0x90]
000078805cdd69f3  vmovaps xmm11, [rsp+0xA0]
000078805cdd69fc  vmovaps xmm12, [rsp+0xB0]
000078805cdd6a05  vmovaps xmm13, [rsp+0xC0]
000078805cdd6a0e  vmovaps xmm14, [rsp+0xD0]
000078805cdd6a17  vmovaps xmm15, [rsp+0xE0]
000078805cdd6a20  add rsp, 0xF0
000078805cdd6a27  pop r11
000078805cdd6a29  pop r10
000078805cdd6a2b  pop r9
000078805cdd6a2d  pop r8
000078805cdd6a2f  pop rsi
000078805cdd6a30  pop rdi
000078805cdd6a31  pop rdx
000078805cdd6a32  pop rcx
000078805cdd6a33  pop rax
000078805cdd6a34  add rsp, 0x08
000078805cdd6a38  jmp 0x000078805CDD59C8
000078805cdd6a3d  sub rsp, 0x08
000078805cdd6a41  push rax
000078805cdd6a42  push rcx
000078805cdd6a43  push rdx
000078805cdd6a44  push rdi
000078805cdd6a45  push rsi
000078805cdd6a46  push r8
000078805cdd6a48  push r9
000078805cdd6a4a  push r10
000078805cdd6a4c  push r11
000078805cdd6a4e  sub rsp, 0xF0
000078805cdd6a55  vmovaps [rsp], xmm0
000078805cdd6a5a  vmovaps [rsp+0x10], xmm1
000078805cdd6a60  vmovaps [rsp+0x20], xmm2
000078805cdd6a66  vmovaps [rsp+0x30], xmm3
000078805cdd6a6c  vmovaps [rsp+0x40], xmm4
000078805cdd6a72  vmovaps [rsp+0x50], xmm5
000078805cdd6a78  vmovaps [rsp+0x60], xmm6
000078805cdd6a7e  vmovaps [rsp+0x70], xmm7
000078805cdd6a84  vmovaps [rsp+0x80], xmm8
000078805cdd6a8d  vmovaps [rsp+0x90], xmm10
000078805cdd6a96  vmovaps [rsp+0xA0], xmm11
000078805cdd6a9f  vmovaps [rsp+0xB0], xmm12
000078805cdd6aa8  vmovaps [rsp+0xC0], xmm13
000078805cdd6ab1  vmovaps [rsp+0xD0], xmm14
000078805cdd6aba  vmovaps [rsp+0xE0], xmm15
000078805cdd6ac3  sub rsp, 0x30
000078805cdd6ac7  movaps [rsp], xmm9
000078805cdd6acc  movaps [rsp+0x10], xmm12
000078805cdd6ad2  movaps [rsp+0x20], xmm10
000078805cdd6ad8  lea rdi, [rsp]
000078805cdd6adc  mov esi, 0x00
000078805cdd6ae1  mov rax, 0x5771AD6EA530
000078805cdd6aeb  call rax
000078805cdd6aed  movaps xmm9, [rsp]
000078805cdd6af2  add rsp, 0x30
000078805cdd6af6  vmovaps xmm0, [rsp]
000078805cdd6afb  vmovaps xmm1, [rsp+0x10]
000078805cdd6b01  vmovaps xmm2, [rsp+0x20]
000078805cdd6b07  vmovaps xmm3, [rsp+0x30]
000078805cdd6b0d  vmovaps xmm4, [rsp+0x40]
000078805cdd6b13  vmovaps xmm5, [rsp+0x50]
000078805cdd6b19  vmovaps xmm6, [rsp+0x60]
000078805cdd6b1f  vmovaps xmm7, [rsp+0x70]
000078805cdd6b25  vmovaps xmm8, [rsp+0x80]
000078805cdd6b2e  vmovaps xmm10, [rsp+0x90]
000078805cdd6b37  vmovaps xmm11, [rsp+0xA0]
000078805cdd6b40  vmovaps xmm12, [rsp+0xB0]
000078805cdd6b49  vmovaps xmm13, [rsp+0xC0]
000078805cdd6b52  vmovaps xmm14, [rsp+0xD0]
000078805cdd6b5b  vmovaps xmm15, [rsp+0xE0]
000078805cdd6b64  add rsp, 0xF0
000078805cdd6b6b  pop r11
000078805cdd6b6d  pop r10
000078805cdd6b6f  pop r9
000078805cdd6b71  pop r8
000078805cdd6b73  pop rsi
000078805cdd6b74  pop rdi
000078805cdd6b75  pop rdx
000078805cdd6b76  pop rcx
000078805cdd6b77  pop rax
000078805cdd6b78  add rsp, 0x08
000078805cdd6b7c  jmp 0x000078805CDD59EC
000078805cdd6b81  sub rsp, 0x08
000078805cdd6b85  push rax
000078805cdd6b86  push rcx
000078805cdd6b87  push rdx
000078805cdd6b88  push rdi
000078805cdd6b89  push rsi
000078805cdd6b8a  push r8
000078805cdd6b8c  push r9
000078805cdd6b8e  push r10
000078805cdd6b90  push r11
000078805cdd6b92  sub rsp, 0xF0
000078805cdd6b99  vmovaps [rsp], xmm0
000078805cdd6b9e  vmovaps [rsp+0x10], xmm1
000078805cdd6ba4  vmovaps [rsp+0x20], xmm2
000078805cdd6baa  vmovaps [rsp+0x30], xmm3
000078805cdd6bb0  vmovaps [rsp+0x40], xmm4
000078805cdd6bb6  vmovaps [rsp+0x50], xmm5
000078805cdd6bbc  vmovaps [rsp+0x60], xmm6
000078805cdd6bc2  vmovaps [rsp+0x70], xmm7
000078805cdd6bc8  vmovaps [rsp+0x80], xmm8
000078805cdd6bd1  vmovaps [rsp+0x90], xmm9
000078805cdd6bda  vmovaps [rsp+0xA0], xmm11
000078805cdd6be3  vmovaps [rsp+0xB0], xmm12
000078805cdd6bec  vmovaps [rsp+0xC0], xmm13
000078805cdd6bf5  vmovaps [rsp+0xD0], xmm14
000078805cdd6bfe  vmovaps [rsp+0xE0], xmm15
000078805cdd6c07  sub rsp, 0x30
000078805cdd6c0b  movaps [rsp], xmm10
000078805cdd6c10  movaps [rsp+0x10], xmm12
000078805cdd6c16  movaps [rsp+0x20], xmm11
000078805cdd6c1c  lea rdi, [rsp]
000078805cdd6c20  mov esi, 0x00
000078805cdd6c25  mov rax, 0x5771AD6EA530
000078805cdd6c2f  call rax
000078805cdd6c31  movaps xmm10, [rsp]
000078805cdd6c36  add rsp, 0x30
000078805cdd6c3a  vmovaps xmm0, [rsp]
000078805cdd6c3f  vmovaps xmm1, [rsp+0x10]
000078805cdd6c45  vmovaps xmm2, [rsp+0x20]
000078805cdd6c4b  vmovaps xmm3, [rsp+0x30]
000078805cdd6c51  vmovaps xmm4, [rsp+0x40]
000078805cdd6c57  vmovaps xmm5, [rsp+0x50]
000078805cdd6c5d  vmovaps xmm6, [rsp+0x60]
000078805cdd6c63  vmovaps xmm7, [rsp+0x70]
000078805cdd6c69  vmovaps xmm8, [rsp+0x80]
000078805cdd6c72  vmovaps xmm9, [rsp+0x90]
000078805cdd6c7b  vmovaps xmm11, [rsp+0xA0]
000078805cdd6c84  vmovaps xmm12, [rsp+0xB0]
000078805cdd6c8d  vmovaps xmm13, [rsp+0xC0]
000078805cdd6c96  vmovaps xmm14, [rsp+0xD0]
000078805cdd6c9f  vmovaps xmm15, [rsp+0xE0]
000078805cdd6ca8  add rsp, 0xF0
000078805cdd6caf  pop r11
000078805cdd6cb1  pop r10
000078805cdd6cb3  pop r9
000078805cdd6cb5  pop r8
000078805cdd6cb7  pop rsi
000078805cdd6cb8  pop rdi
000078805cdd6cb9  pop rdx
000078805cdd6cba  pop rcx
000078805cdd6cbb  pop rax
000078805cdd6cbc  add rsp, 0x08
000078805cdd6cc0  jmp 0x000078805CDD5A06
000078805cdd6cc5  sub rsp, 0x08
000078805cdd6cc9  push rax
000078805cdd6cca  push rcx
000078805cdd6ccb  push rdx
000078805cdd6ccc  push rdi
000078805cdd6ccd  push rsi
000078805cdd6cce  push r8
000078805cdd6cd0  push r9
000078805cdd6cd2  push r10
000078805cdd6cd4  push r11
000078805cdd6cd6  sub rsp, 0xF0
000078805cdd6cdd  vmovaps [rsp], xmm0
000078805cdd6ce2  vmovaps [rsp+0x10], xmm1
000078805cdd6ce8  vmovaps [rsp+0x20], xmm2
000078805cdd6cee  vmovaps [rsp+0x30], xmm3
000078805cdd6cf4  vmovaps [rsp+0x40], xmm4
000078805cdd6cfa  vmovaps [rsp+0x50], xmm5
000078805cdd6d00  vmovaps [rsp+0x60], xmm7
000078805cdd6d06  vmovaps [rsp+0x70], xmm8
000078805cdd6d0c  vmovaps [rsp+0x80], xmm9
000078805cdd6d15  vmovaps [rsp+0x90], xmm10
000078805cdd6d1e  vmovaps [rsp+0xA0], xmm11
000078805cdd6d27  vmovaps [rsp+0xB0], xmm12
000078805cdd6d30  vmovaps [rsp+0xC0], xmm13
000078805cdd6d39  vmovaps [rsp+0xD0], xmm14
000078805cdd6d42  vmovaps [rsp+0xE0], xmm15
000078805cdd6d4b  sub rsp, 0x30
000078805cdd6d4f  movaps [rsp], xmm6
000078805cdd6d53  movaps [rsp+0x10], xmm12
000078805cdd6d59  movaps [rsp+0x20], xmm11
000078805cdd6d5f  lea rdi, [rsp]
000078805cdd6d63  mov esi, 0x00
000078805cdd6d68  mov rax, 0x5771AD6EA530
000078805cdd6d72  call rax
000078805cdd6d74  movaps xmm6, [rsp]
000078805cdd6d78  add rsp, 0x30
000078805cdd6d7c  vmovaps xmm0, [rsp]
000078805cdd6d81  vmovaps xmm1, [rsp+0x10]
000078805cdd6d87  vmovaps xmm2, [rsp+0x20]
000078805cdd6d8d  vmovaps xmm3, [rsp+0x30]
000078805cdd6d93  vmovaps xmm4, [rsp+0x40]
000078805cdd6d99  vmovaps xmm5, [rsp+0x50]
000078805cdd6d9f  vmovaps xmm7, [rsp+0x60]
000078805cdd6da5  vmovaps xmm8, [rsp+0x70]
000078805cdd6dab  vmovaps xmm9, [rsp+0x80]
000078805cdd6db4  vmovaps xmm10, [rsp+0x90]
000078805cdd6dbd  vmovaps xmm11, [rsp+0xA0]
000078805cdd6dc6  vmovaps xmm12, [rsp+0xB0]
000078805cdd6dcf  vmovaps xmm13, [rsp+0xC0]
000078805cdd6dd8  vmovaps xmm14, [rsp+0xD0]
000078805cdd6de1  vmovaps xmm15, [rsp+0xE0]
000078805cdd6dea  add rsp, 0xF0
000078805cdd6df1  pop r11
000078805cdd6df3  pop r10
000078805cdd6df5  pop r9
000078805cdd6df7  pop r8
000078805cdd6df9  pop rsi
000078805cdd6dfa  pop rdi
000078805cdd6dfb  pop rdx
000078805cdd6dfc  pop rcx
000078805cdd6dfd  pop rax
000078805cdd6dfe  add rsp, 0x08
000078805cdd6e02  jmp 0x000078805CDD5A27
000078805cdd6e07  sub rsp, 0x08
000078805cdd6e0b  push rax
000078805cdd6e0c  push rcx
000078805cdd6e0d  push rdx
000078805cdd6e0e  push rdi
000078805cdd6e0f  push rsi
000078805cdd6e10  push r8
000078805cdd6e12  push r9
000078805cdd6e14  push r10
000078805cdd6e16  push r11
000078805cdd6e18  sub rsp, 0xF0
000078805cdd6e1f  vmovaps [rsp], xmm0
000078805cdd6e24  vmovaps [rsp+0x10], xmm1
000078805cdd6e2a  vmovaps [rsp+0x20], xmm2
000078805cdd6e30  vmovaps [rsp+0x30], xmm4
000078805cdd6e36  vmovaps [rsp+0x40], xmm5
000078805cdd6e3c  vmovaps [rsp+0x50], xmm6
000078805cdd6e42  vmovaps [rsp+0x60], xmm7
000078805cdd6e48  vmovaps [rsp+0x70], xmm8
000078805cdd6e4e  vmovaps [rsp+0x80], xmm9
000078805cdd6e57  vmovaps [rsp+0x90], xmm10
000078805cdd6e60  vmovaps [rsp+0xA0], xmm11
000078805cdd6e69  vmovaps [rsp+0xB0], xmm12
000078805cdd6e72  vmovaps [rsp+0xC0], xmm13
000078805cdd6e7b  vmovaps [rsp+0xD0], xmm14
000078805cdd6e84  vmovaps [rsp+0xE0], xmm15
000078805cdd6e8d  sub rsp, 0x30
000078805cdd6e91  movaps [rsp], xmm3
000078805cdd6e95  movaps [rsp+0x10], xmm5
000078805cdd6e9a  movaps [rsp+0x20], xmm4
000078805cdd6e9f  lea rdi, [rsp]
000078805cdd6ea3  mov esi, 0x00
000078805cdd6ea8  mov rax, 0x5771AD6EA530
000078805cdd6eb2  call rax
000078805cdd6eb4  movaps xmm3, [rsp]
000078805cdd6eb8  add rsp, 0x30
000078805cdd6ebc  vmovaps xmm0, [rsp]
000078805cdd6ec1  vmovaps xmm1, [rsp+0x10]
000078805cdd6ec7  vmovaps xmm2, [rsp+0x20]
000078805cdd6ecd  vmovaps xmm4, [rsp+0x30]
000078805cdd6ed3  vmovaps xmm5, [rsp+0x40]
000078805cdd6ed9  vmovaps xmm6, [rsp+0x50]
000078805cdd6edf  vmovaps xmm7, [rsp+0x60]
000078805cdd6ee5  vmovaps xmm8, [rsp+0x70]
000078805cdd6eeb  vmovaps xmm9, [rsp+0x80]
000078805cdd6ef4  vmovaps xmm10, [rsp+0x90]
000078805cdd6efd  vmovaps xmm11, [rsp+0xA0]
000078805cdd6f06  vmovaps xmm12, [rsp+0xB0]
000078805cdd6f0f  vmovaps xmm13, [rsp+0xC0]
000078805cdd6f18  vmovaps xmm14, [rsp+0xD0]
000078805cdd6f21  vmovaps xmm15, [rsp+0xE0]
000078805cdd6f2a  add rsp, 0xF0
000078805cdd6f31  pop r11
000078805cdd6f33  pop r10
000078805cdd6f35  pop r9
000078805cdd6f37  pop r8
000078805cdd6f39  pop rsi
000078805cdd6f3a  pop rdi
000078805cdd6f3b  pop rdx
000078805cdd6f3c  pop rcx
000078805cdd6f3d  pop rax
000078805cdd6f3e  add rsp, 0x08
000078805cdd6f42  jmp 0x000078805CDD5A88
000078805cdd6f47  sub rsp, 0x08
000078805cdd6f4b  push rax
000078805cdd6f4c  push rcx
000078805cdd6f4d  push rdx
000078805cdd6f4e  push rdi
000078805cdd6f4f  push rsi
000078805cdd6f50  push r8
000078805cdd6f52  push r9
000078805cdd6f54  push r10
000078805cdd6f56  push r11
000078805cdd6f58  sub rsp, 0xF0
000078805cdd6f5f  vmovaps [rsp], xmm0
000078805cdd6f64  vmovaps [rsp+0x10], xmm1
000078805cdd6f6a  vmovaps [rsp+0x20], xmm2
000078805cdd6f70  vmovaps [rsp+0x30], xmm3
000078805cdd6f76  vmovaps [rsp+0x40], xmm4
000078805cdd6f7c  vmovaps [rsp+0x50], xmm6
000078805cdd6f82  vmovaps [rsp+0x60], xmm7
000078805cdd6f88  vmovaps [rsp+0x70], xmm8
000078805cdd6f8e  vmovaps [rsp+0x80], xmm9
000078805cdd6f97  vmovaps [rsp+0x90], xmm10
000078805cdd6fa0  vmovaps [rsp+0xA0], xmm11
000078805cdd6fa9  vmovaps [rsp+0xB0], xmm12
000078805cdd6fb2  vmovaps [rsp+0xC0], xmm13
000078805cdd6fbb  vmovaps [rsp+0xD0], xmm14
000078805cdd6fc4  vmovaps [rsp+0xE0], xmm15
000078805cdd6fcd  sub rsp, 0x30
000078805cdd6fd1  movaps [rsp], xmm5
000078805cdd6fd5  movaps [rsp+0x10], xmm8
000078805cdd6fdb  movaps [rsp+0x20], xmm15
000078805cdd6fe1  lea rdi, [rsp]
000078805cdd6fe5  mov esi, 0x00
000078805cdd6fea  mov rax, 0x5771AD6EA530
000078805cdd6ff4  call rax
000078805cdd6ff6  movaps xmm5, [rsp]
000078805cdd6ffa  add rsp, 0x30
000078805cdd6ffe  vmovaps xmm0, [rsp]
000078805cdd7003  vmovaps xmm1, [rsp+0x10]
000078805cdd7009  vmovaps xmm2, [rsp+0x20]
000078805cdd700f  vmovaps xmm3, [rsp+0x30]
000078805cdd7015  vmovaps xmm4, [rsp+0x40]
000078805cdd701b  vmovaps xmm6, [rsp+0x50]
000078805cdd7021  vmovaps xmm7, [rsp+0x60]
000078805cdd7027  vmovaps xmm8, [rsp+0x70]
000078805cdd702d  vmovaps xmm9, [rsp+0x80]
000078805cdd7036  vmovaps xmm10, [rsp+0x90]
000078805cdd703f  vmovaps xmm11, [rsp+0xA0]
000078805cdd7048  vmovaps xmm12, [rsp+0xB0]
000078805cdd7051  vmovaps xmm13, [rsp+0xC0]
000078805cdd705a  vmovaps xmm14, [rsp+0xD0]
000078805cdd7063  vmovaps xmm15, [rsp+0xE0]
000078805cdd706c  add rsp, 0xF0
000078805cdd7073  pop r11
000078805cdd7075  pop r10
000078805cdd7077  pop r9
000078805cdd7079  pop r8
000078805cdd707b  pop rsi
000078805cdd707c  pop rdi
000078805cdd707d  pop rdx
000078805cdd707e  pop rcx
000078805cdd707f  pop rax
000078805cdd7080  add rsp, 0x08
000078805cdd7084  jmp 0x000078805CDD5AC0
000078805cdd7089  sub rsp, 0x08
000078805cdd708d  push rax
000078805cdd708e  push rcx
000078805cdd708f  push rdx
000078805cdd7090  push rdi
000078805cdd7091  push rsi
000078805cdd7092  push r8
000078805cdd7094  push r9
000078805cdd7096  push r10
000078805cdd7098  push r11
000078805cdd709a  sub rsp, 0xF0
000078805cdd70a1  vmovaps [rsp], xmm0
000078805cdd70a6  vmovaps [rsp+0x10], xmm1
000078805cdd70ac  vmovaps [rsp+0x20], xmm2
000078805cdd70b2  vmovaps [rsp+0x30], xmm3
000078805cdd70b8  vmovaps [rsp+0x40], xmm5
000078805cdd70be  vmovaps [rsp+0x50], xmm6
000078805cdd70c4  vmovaps [rsp+0x60], xmm7
000078805cdd70ca  vmovaps [rsp+0x70], xmm8
000078805cdd70d0  vmovaps [rsp+0x80], xmm9
000078805cdd70d9  vmovaps [rsp+0x90], xmm10
000078805cdd70e2  vmovaps [rsp+0xA0], xmm11
000078805cdd70eb  vmovaps [rsp+0xB0], xmm12
000078805cdd70f4  vmovaps [rsp+0xC0], xmm13
000078805cdd70fd  vmovaps [rsp+0xD0], xmm14
000078805cdd7106  vmovaps [rsp+0xE0], xmm15
000078805cdd710f  sub rsp, 0x30
000078805cdd7113  movaps [rsp], xmm4
000078805cdd7117  movaps [rsp+0x10], xmm9
000078805cdd711d  movaps [rsp+0x20], xmm8
000078805cdd7123  lea rdi, [rsp]
000078805cdd7127  mov esi, 0x00
000078805cdd712c  mov rax, 0x5771AD6EA530
000078805cdd7136  call rax
000078805cdd7138  movaps xmm4, [rsp]
000078805cdd713c  add rsp, 0x30
000078805cdd7140  vmovaps xmm0, [rsp]
000078805cdd7145  vmovaps xmm1, [rsp+0x10]
000078805cdd714b  vmovaps xmm2, [rsp+0x20]
000078805cdd7151  vmovaps xmm3, [rsp+0x30]
000078805cdd7157  vmovaps xmm5, [rsp+0x40]
000078805cdd715d  vmovaps xmm6, [rsp+0x50]
000078805cdd7163  vmovaps xmm7, [rsp+0x60]
000078805cdd7169  vmovaps xmm8, [rsp+0x70]
000078805cdd716f  vmovaps xmm9, [rsp+0x80]
000078805cdd7178  vmovaps xmm10, [rsp+0x90]
000078805cdd7181  vmovaps xmm11, [rsp+0xA0]
000078805cdd718a  vmovaps xmm12, [rsp+0xB0]
000078805cdd7193  vmovaps xmm13, [rsp+0xC0]
000078805cdd719c  vmovaps xmm14, [rsp+0xD0]
000078805cdd71a5  vmovaps xmm15, [rsp+0xE0]
000078805cdd71ae  add rsp, 0xF0
000078805cdd71b5  pop r11
000078805cdd71b7  pop r10
000078805cdd71b9  pop r9
000078805cdd71bb  pop r8
000078805cdd71bd  pop rsi
000078805cdd71be  pop rdi
000078805cdd71bf  pop rdx
000078805cdd71c0  pop rcx
000078805cdd71c1  pop rax
000078805cdd71c2  add rsp, 0x08
000078805cdd71c6  jmp 0x000078805CDD5AE1
000078805cdd71cb  sub rsp, 0x08
000078805cdd71cf  push rax
000078805cdd71d0  push rcx
000078805cdd71d1  push rdx
000078805cdd71d2  push rdi
000078805cdd71d3  push rsi
000078805cdd71d4  push r8
000078805cdd71d6  push r9
000078805cdd71d8  push r10
000078805cdd71da  push r11
000078805cdd71dc  sub rsp, 0xF0
000078805cdd71e3  vmovaps [rsp], xmm0
000078805cdd71e8  vmovaps [rsp+0x10], xmm1
000078805cdd71ee  vmovaps [rsp+0x20], xmm2
000078805cdd71f4  vmovaps [rsp+0x30], xmm3
000078805cdd71fa  vmovaps [rsp+0x40], xmm4
000078805cdd7200  vmovaps [rsp+0x50], xmm5
000078805cdd7206  vmovaps [rsp+0x60], xmm6
000078805cdd720c  vmovaps [rsp+0x70], xmm7
000078805cdd7212  vmovaps [rsp+0x80], xmm8
000078805cdd721b  vmovaps [rsp+0x90], xmm10
000078805cdd7224  vmovaps [rsp+0xA0], xmm11
000078805cdd722d  vmovaps [rsp+0xB0], xmm12
000078805cdd7236  vmovaps [rsp+0xC0], xmm13
000078805cdd723f  vmovaps [rsp+0xD0], xmm14
000078805cdd7248  vmovaps [rsp+0xE0], xmm15
000078805cdd7251  sub rsp, 0x30
000078805cdd7255  movaps [rsp], xmm9
000078805cdd725a  movaps [rsp+0x10], xmm10
000078805cdd7260  movaps [rsp+0x20], xmm8
000078805cdd7266  lea rdi, [rsp]
000078805cdd726a  mov esi, 0x00
000078805cdd726f  mov rax, 0x5771AD6EA530
000078805cdd7279  call rax
000078805cdd727b  movaps xmm9, [rsp]
000078805cdd7280  add rsp, 0x30
000078805cdd7284  vmovaps xmm0, [rsp]
000078805cdd7289  vmovaps xmm1, [rsp+0x10]
000078805cdd728f  vmovaps xmm2, [rsp+0x20]
000078805cdd7295  vmovaps xmm3, [rsp+0x30]
000078805cdd729b  vmovaps xmm4, [rsp+0x40]
000078805cdd72a1  vmovaps xmm5, [rsp+0x50]
000078805cdd72a7  vmovaps xmm6, [rsp+0x60]
000078805cdd72ad  vmovaps xmm7, [rsp+0x70]
000078805cdd72b3  vmovaps xmm8, [rsp+0x80]
000078805cdd72bc  vmovaps xmm10, [rsp+0x90]
000078805cdd72c5  vmovaps xmm11, [rsp+0xA0]
000078805cdd72ce  vmovaps xmm12, [rsp+0xB0]
000078805cdd72d7  vmovaps xmm13, [rsp+0xC0]
000078805cdd72e0  vmovaps xmm14, [rsp+0xD0]
000078805cdd72e9  vmovaps xmm15, [rsp+0xE0]
000078805cdd72f2  add rsp, 0xF0
000078805cdd72f9  pop r11
000078805cdd72fb  pop r10
000078805cdd72fd  pop r9
000078805cdd72ff  pop r8
000078805cdd7301  pop rsi
000078805cdd7302  pop rdi
000078805cdd7303  pop rdx
000078805cdd7304  pop rcx
000078805cdd7305  pop rax
000078805cdd7306  add rsp, 0x08
000078805cdd730a  jmp 0x000078805CDD5AFB
000078805cdd730f  call 0x000078805CCD64F0
000078805cdd7314  jmp 0x000078805CDD5C15
000078805cdd7319  call 0x000078805CCD64F0
000078805cdd731e  jmp 0x000078805CDD5C2B
000078805cdd7323  sub rsp, 0x08
000078805cdd7327  push rax
000078805cdd7328  push rcx
000078805cdd7329  push rdx
000078805cdd732a  push rdi
000078805cdd732b  push rsi
000078805cdd732c  push r8
000078805cdd732e  push r9
000078805cdd7330  push r10
000078805cdd7332  push r11
000078805cdd7334  sub rsp, 0xF0
000078805cdd733b  vmovaps [rsp], xmm0
000078805cdd7340  vmovaps [rsp+0x10], xmm2
000078805cdd7346  vmovaps [rsp+0x20], xmm3
000078805cdd734c  vmovaps [rsp+0x30], xmm4
000078805cdd7352  vmovaps [rsp+0x40], xmm5
000078805cdd7358  vmovaps [rsp+0x50], xmm6
000078805cdd735e  vmovaps [rsp+0x60], xmm7
000078805cdd7364  vmovaps [rsp+0x70], xmm8
000078805cdd736a  vmovaps [rsp+0x80], xmm9
000078805cdd7373  vmovaps [rsp+0x90], xmm10
000078805cdd737c  vmovaps [rsp+0xA0], xmm11
000078805cdd7385  vmovaps [rsp+0xB0], xmm12
000078805cdd738e  vmovaps [rsp+0xC0], xmm13
000078805cdd7397  vmovaps [rsp+0xD0], xmm14
000078805cdd73a0  vmovaps [rsp+0xE0], xmm15
000078805cdd73a9  sub rsp, 0x30
000078805cdd73ad  movaps [rsp], xmm1
000078805cdd73b1  movaps [rsp+0x10], xmm6
000078805cdd73b6  movaps [rsp+0x20], xmm15
000078805cdd73bc  lea rdi, [rsp]
000078805cdd73c0  mov esi, 0x00
000078805cdd73c5  mov rax, 0x5771AD6EA530
000078805cdd73cf  call rax
000078805cdd73d1  movaps xmm1, [rsp]
000078805cdd73d5  add rsp, 0x30
000078805cdd73d9  vmovaps xmm0, [rsp]
000078805cdd73de  vmovaps xmm2, [rsp+0x10]
000078805cdd73e4  vmovaps xmm3, [rsp+0x20]
000078805cdd73ea  vmovaps xmm4, [rsp+0x30]
000078805cdd73f0  vmovaps xmm5, [rsp+0x40]
000078805cdd73f6  vmovaps xmm6, [rsp+0x50]
000078805cdd73fc  vmovaps xmm7, [rsp+0x60]
000078805cdd7402  vmovaps xmm8, [rsp+0x70]
000078805cdd7408  vmovaps xmm9, [rsp+0x80]
000078805cdd7411  vmovaps xmm10, [rsp+0x90]
000078805cdd741a  vmovaps xmm11, [rsp+0xA0]
000078805cdd7423  vmovaps xmm12, [rsp+0xB0]
000078805cdd742c  vmovaps xmm13, [rsp+0xC0]
000078805cdd7435  vmovaps xmm14, [rsp+0xD0]
000078805cdd743e  vmovaps xmm15, [rsp+0xE0]
000078805cdd7447  add rsp, 0xF0
000078805cdd744e  pop r11
000078805cdd7450  pop r10
000078805cdd7452  pop r9
000078805cdd7454  pop r8
000078805cdd7456  pop rsi
000078805cdd7457  pop rdi
000078805cdd7458  pop rdx
000078805cdd7459  pop rcx
000078805cdd745a  pop rax
000078805cdd745b  add rsp, 0x08
000078805cdd745f  jmp 0x000078805CDD5C68
000078805cdd7464  call 0x000078805CCE5820
000078805cdd7469  jmp 0x000078805CDD5C75
000078805cdd746e  sub rsp, 0x08
000078805cdd7472  push rax
000078805cdd7473  push rcx
000078805cdd7474  push rdx
000078805cdd7475  push rdi
000078805cdd7476  push rsi
000078805cdd7477  push r8
000078805cdd7479  push r9
000078805cdd747b  push r10
000078805cdd747d  push r11
000078805cdd747f  sub rsp, 0xF0
000078805cdd7486  vmovaps [rsp], xmm0
000078805cdd748b  vmovaps [rsp+0x10], xmm1
000078805cdd7491  vmovaps [rsp+0x20], xmm2
000078805cdd7497  vmovaps [rsp+0x30], xmm3
000078805cdd749d  vmovaps [rsp+0x40], xmm4
000078805cdd74a3  vmovaps [rsp+0x50], xmm5
000078805cdd74a9  vmovaps [rsp+0x60], xmm6
000078805cdd74af  vmovaps [rsp+0x70], xmm7
000078805cdd74b5  vmovaps [rsp+0x80], xmm8
000078805cdd74be  vmovaps [rsp+0x90], xmm9
000078805cdd74c7  vmovaps [rsp+0xA0], xmm10
000078805cdd74d0  vmovaps [rsp+0xB0], xmm11
000078805cdd74d9  vmovaps [rsp+0xC0], xmm12
000078805cdd74e2  vmovaps [rsp+0xD0], xmm13
000078805cdd74eb  vmovaps [rsp+0xE0], xmm15
000078805cdd74f4  sub rsp, 0x30
000078805cdd74f8  movaps [rsp], xmm14
000078805cdd74fd  movaps [rsp+0x10], xmm4
000078805cdd7502  movaps [rsp+0x20], xmm3
000078805cdd7507  lea rdi, [rsp]
000078805cdd750b  mov esi, 0x00
000078805cdd7510  mov rax, 0x5771AD6EA530
000078805cdd751a  call rax
000078805cdd751c  movaps xmm14, [rsp]
000078805cdd7521  add rsp, 0x30
000078805cdd7525  vmovaps xmm0, [rsp]
000078805cdd752a  vmovaps xmm1, [rsp+0x10]
000078805cdd7530  vmovaps xmm2, [rsp+0x20]
000078805cdd7536  vmovaps xmm3, [rsp+0x30]
000078805cdd753c  vmovaps xmm4, [rsp+0x40]
000078805cdd7542  vmovaps xmm5, [rsp+0x50]
000078805cdd7548  vmovaps xmm6, [rsp+0x60]
000078805cdd754e  vmovaps xmm7, [rsp+0x70]
000078805cdd7554  vmovaps xmm8, [rsp+0x80]
000078805cdd755d  vmovaps xmm9, [rsp+0x90]
000078805cdd7566  vmovaps xmm10, [rsp+0xA0]
000078805cdd756f  vmovaps xmm11, [rsp+0xB0]
000078805cdd7578  vmovaps xmm12, [rsp+0xC0]
000078805cdd7581  vmovaps xmm13, [rsp+0xD0]
000078805cdd758a  vmovaps xmm15, [rsp+0xE0]
000078805cdd7593  add rsp, 0xF0
000078805cdd759a  pop r11
000078805cdd759c  pop r10
000078805cdd759e  pop r9
000078805cdd75a0  pop r8
000078805cdd75a2  pop rsi
000078805cdd75a3  pop rdi
000078805cdd75a4  pop rdx
000078805cdd75a5  pop rcx
000078805cdd75a6  pop rax
000078805cdd75a7  add rsp, 0x08
000078805cdd75ab  jmp 0x000078805CDD5C8F
000078805cdd75b0  sub rsp, 0x08
000078805cdd75b4  push rax
000078805cdd75b5  push rcx
000078805cdd75b6  push rdx
000078805cdd75b7  push rdi
000078805cdd75b8  push rsi
000078805cdd75b9  push r8
000078805cdd75bb  push r9
000078805cdd75bd  push r10
000078805cdd75bf  push r11
000078805cdd75c1  sub rsp, 0xF0
000078805cdd75c8  vmovaps [rsp], xmm0
000078805cdd75cd  vmovaps [rsp+0x10], xmm1
000078805cdd75d3  vmovaps [rsp+0x20], xmm2
000078805cdd75d9  vmovaps [rsp+0x30], xmm3
000078805cdd75df  vmovaps [rsp+0x40], xmm4
000078805cdd75e5  vmovaps [rsp+0x50], xmm5
000078805cdd75eb  vmovaps [rsp+0x60], xmm7
000078805cdd75f1  vmovaps [rsp+0x70], xmm8
000078805cdd75f7  vmovaps [rsp+0x80], xmm9
000078805cdd7600  vmovaps [rsp+0x90], xmm10
000078805cdd7609  vmovaps [rsp+0xA0], xmm11
000078805cdd7612  vmovaps [rsp+0xB0], xmm12
000078805cdd761b  vmovaps [rsp+0xC0], xmm13
000078805cdd7624  vmovaps [rsp+0xD0], xmm14
000078805cdd762d  vmovaps [rsp+0xE0], xmm15
000078805cdd7636  sub rsp, 0x30
000078805cdd763a  movaps [rsp], xmm6
000078805cdd763e  movaps [rsp+0x10], xmm9
000078805cdd7644  movaps [rsp+0x20], xmm7
000078805cdd7649  lea rdi, [rsp]
000078805cdd764d  mov esi, 0x00
000078805cdd7652  mov rax, 0x5771AD6EA530
000078805cdd765c  call rax
000078805cdd765e  movaps xmm6, [rsp]
000078805cdd7662  add rsp, 0x30
000078805cdd7666  vmovaps xmm0, [rsp]
000078805cdd766b  vmovaps xmm1, [rsp+0x10]
000078805cdd7671  vmovaps xmm2, [rsp+0x20]
000078805cdd7677  vmovaps xmm3, [rsp+0x30]
000078805cdd767d  vmovaps xmm4, [rsp+0x40]
000078805cdd7683  vmovaps xmm5, [rsp+0x50]
000078805cdd7689  vmovaps xmm7, [rsp+0x60]
000078805cdd768f  vmovaps xmm8, [rsp+0x70]
000078805cdd7695  vmovaps xmm9, [rsp+0x80]
000078805cdd769e  vmovaps xmm10, [rsp+0x90]
000078805cdd76a7  vmovaps xmm11, [rsp+0xA0]
000078805cdd76b0  vmovaps xmm12, [rsp+0xB0]
000078805cdd76b9  vmovaps xmm13, [rsp+0xC0]
000078805cdd76c2  vmovaps xmm14, [rsp+0xD0]
000078805cdd76cb  vmovaps xmm15, [rsp+0xE0]
000078805cdd76d4  add rsp, 0xF0
000078805cdd76db  pop r11
000078805cdd76dd  pop r10
000078805cdd76df  pop r9
000078805cdd76e1  pop r8
000078805cdd76e3  pop rsi
000078805cdd76e4  pop rdi
000078805cdd76e5  pop rdx
000078805cdd76e6  pop rcx
000078805cdd76e7  pop rax
000078805cdd76e8  add rsp, 0x08
000078805cdd76ec  jmp 0x000078805CDD5CA7
000078805cdd76f1  sub rsp, 0x08
000078805cdd76f5  push rax
000078805cdd76f6  push rcx
000078805cdd76f7  push rdx
000078805cdd76f8  push rdi
000078805cdd76f9  push rsi
000078805cdd76fa  push r8
000078805cdd76fc  push r9
000078805cdd76fe  push r10
000078805cdd7700  push r11
000078805cdd7702  sub rsp, 0xF0
000078805cdd7709  vmovaps [rsp], xmm0
000078805cdd770e  vmovaps [rsp+0x10], xmm1
000078805cdd7714  vmovaps [rsp+0x20], xmm2
000078805cdd771a  vmovaps [rsp+0x30], xmm3
000078805cdd7720  vmovaps [rsp+0x40], xmm4
000078805cdd7726  vmovaps [rsp+0x50], xmm5
000078805cdd772c  vmovaps [rsp+0x60], xmm6
000078805cdd7732  vmovaps [rsp+0x70], xmm8
000078805cdd7738  vmovaps [rsp+0x80], xmm9
000078805cdd7741  vmovaps [rsp+0x90], xmm10
000078805cdd774a  vmovaps [rsp+0xA0], xmm11
000078805cdd7753  vmovaps [rsp+0xB0], xmm12
000078805cdd775c  vmovaps [rsp+0xC0], xmm13
000078805cdd7765  vmovaps [rsp+0xD0], xmm14
000078805cdd776e  vmovaps [rsp+0xE0], xmm15
000078805cdd7777  sub rsp, 0x30
000078805cdd777b  movaps [rsp], xmm7
000078805cdd777f  movaps [rsp+0x10], xmm4
000078805cdd7784  movaps [rsp+0x20], xmm9
000078805cdd778a  lea rdi, [rsp]
000078805cdd778e  mov esi, 0x00
000078805cdd7793  mov rax, 0x5771AD6EA530
000078805cdd779d  call rax
000078805cdd779f  movaps xmm7, [rsp]
000078805cdd77a3  add rsp, 0x30
000078805cdd77a7  vmovaps xmm0, [rsp]
000078805cdd77ac  vmovaps xmm1, [rsp+0x10]
000078805cdd77b2  vmovaps xmm2, [rsp+0x20]
000078805cdd77b8  vmovaps xmm3, [rsp+0x30]
000078805cdd77be  vmovaps xmm4, [rsp+0x40]
000078805cdd77c4  vmovaps xmm5, [rsp+0x50]
000078805cdd77ca  vmovaps xmm6, [rsp+0x60]
000078805cdd77d0  vmovaps xmm8, [rsp+0x70]
000078805cdd77d6  vmovaps xmm9, [rsp+0x80]
000078805cdd77df  vmovaps xmm10, [rsp+0x90]
000078805cdd77e8  vmovaps xmm11, [rsp+0xA0]
000078805cdd77f1  vmovaps xmm12, [rsp+0xB0]
000078805cdd77fa  vmovaps xmm13, [rsp+0xC0]
000078805cdd7803  vmovaps xmm14, [rsp+0xD0]
000078805cdd780c  vmovaps xmm15, [rsp+0xE0]
000078805cdd7815  add rsp, 0xF0
000078805cdd781c  pop r11
000078805cdd781e  pop r10
000078805cdd7820  pop r9
000078805cdd7822  pop r8
000078805cdd7824  pop rsi
000078805cdd7825  pop rdi
000078805cdd7826  pop rdx
000078805cdd7827  pop rcx
000078805cdd7828  pop rax
000078805cdd7829  add rsp, 0x08
000078805cdd782d  jmp 0x000078805CDD5CD4
000078805cdd7832  sub rsp, 0x08
000078805cdd7836  push rax
000078805cdd7837  push rcx
000078805cdd7838  push rdx
000078805cdd7839  push rdi
000078805cdd783a  push rsi
000078805cdd783b  push r8
000078805cdd783d  push r9
000078805cdd783f  push r10
000078805cdd7841  push r11
000078805cdd7843  sub rsp, 0xF0
000078805cdd784a  vmovaps [rsp], xmm0
000078805cdd784f  vmovaps [rsp+0x10], xmm1
000078805cdd7855  vmovaps [rsp+0x20], xmm2
000078805cdd785b  vmovaps [rsp+0x30], xmm3
000078805cdd7861  vmovaps [rsp+0x40], xmm5
000078805cdd7867  vmovaps [rsp+0x50], xmm6
000078805cdd786d  vmovaps [rsp+0x60], xmm7
000078805cdd7873  vmovaps [rsp+0x70], xmm8
000078805cdd7879  vmovaps [rsp+0x80], xmm9
000078805cdd7882  vmovaps [rsp+0x90], xmm10
000078805cdd788b  vmovaps [rsp+0xA0], xmm11
000078805cdd7894  vmovaps [rsp+0xB0], xmm12
000078805cdd789d  vmovaps [rsp+0xC0], xmm13
000078805cdd78a6  vmovaps [rsp+0xD0], xmm14
000078805cdd78af  vmovaps [rsp+0xE0], xmm15
000078805cdd78b8  sub rsp, 0x30
000078805cdd78bc  movaps [rsp], xmm4
000078805cdd78c0  movaps [rsp+0x10], xmm15
000078805cdd78c6  movaps [rsp+0x20], xmm9
000078805cdd78cc  lea rdi, [rsp]
000078805cdd78d0  mov esi, 0x00
000078805cdd78d5  mov rax, 0x5771AD6EA530
000078805cdd78df  call rax
000078805cdd78e1  movaps xmm4, [rsp]
000078805cdd78e5  add rsp, 0x30
000078805cdd78e9  vmovaps xmm0, [rsp]
000078805cdd78ee  vmovaps xmm1, [rsp+0x10]
000078805cdd78f4  vmovaps xmm2, [rsp+0x20]
000078805cdd78fa  vmovaps xmm3, [rsp+0x30]
000078805cdd7900  vmovaps xmm5, [rsp+0x40]
000078805cdd7906  vmovaps xmm6, [rsp+0x50]
000078805cdd790c  vmovaps xmm7, [rsp+0x60]
000078805cdd7912  vmovaps xmm8, [rsp+0x70]
000078805cdd7918  vmovaps xmm9, [rsp+0x80]
000078805cdd7921  vmovaps xmm10, [rsp+0x90]
000078805cdd792a  vmovaps xmm11, [rsp+0xA0]
000078805cdd7933  vmovaps xmm12, [rsp+0xB0]
000078805cdd793c  vmovaps xmm13, [rsp+0xC0]
000078805cdd7945  vmovaps xmm14, [rsp+0xD0]
000078805cdd794e  vmovaps xmm15, [rsp+0xE0]
000078805cdd7957  add rsp, 0xF0
000078805cdd795e  pop r11
000078805cdd7960  pop r10
000078805cdd7962  pop r9
000078805cdd7964  pop r8
000078805cdd7966  pop rsi
000078805cdd7967  pop rdi
000078805cdd7968  pop rdx
000078805cdd7969  pop rcx
000078805cdd796a  pop rax
000078805cdd796b  add rsp, 0x08
000078805cdd796f  jmp 0x000078805CDD5CF9
000078805cdd7974  call 0x000078805CCE5820
000078805cdd7979  jmp 0x000078805CDD5D06
000078805cdd797e  sub rsp, 0x08
000078805cdd7982  push rax
000078805cdd7983  push rcx
000078805cdd7984  push rdx
000078805cdd7985  push rdi
000078805cdd7986  push rsi
000078805cdd7987  push r8
000078805cdd7989  push r9
000078805cdd798b  push r10
000078805cdd798d  push r11
000078805cdd798f  sub rsp, 0xF0
000078805cdd7996  vmovaps [rsp], xmm0
000078805cdd799b  vmovaps [rsp+0x10], xmm1
000078805cdd79a1  vmovaps [rsp+0x20], xmm2
000078805cdd79a7  vmovaps [rsp+0x30], xmm4
000078805cdd79ad  vmovaps [rsp+0x40], xmm5
000078805cdd79b3  vmovaps [rsp+0x50], xmm6
000078805cdd79b9  vmovaps [rsp+0x60], xmm7
000078805cdd79bf  vmovaps [rsp+0x70], xmm8
000078805cdd79c5  vmovaps [rsp+0x80], xmm9
000078805cdd79ce  vmovaps [rsp+0x90], xmm10
000078805cdd79d7  vmovaps [rsp+0xA0], xmm11
000078805cdd79e0  vmovaps [rsp+0xB0], xmm12
000078805cdd79e9  vmovaps [rsp+0xC0], xmm13
000078805cdd79f2  vmovaps [rsp+0xD0], xmm14
000078805cdd79fb  vmovaps [rsp+0xE0], xmm15
000078805cdd7a04  sub rsp, 0x30
000078805cdd7a08  movaps [rsp], xmm3
000078805cdd7a0c  movaps [rsp+0x10], xmm1
000078805cdd7a11  movaps [rsp+0x20], xmm9
000078805cdd7a17  lea rdi, [rsp]
000078805cdd7a1b  mov esi, 0x00
000078805cdd7a20  mov rax, 0x5771AD6EA530
000078805cdd7a2a  call rax
000078805cdd7a2c  movaps xmm3, [rsp]
000078805cdd7a30  add rsp, 0x30
000078805cdd7a34  vmovaps xmm0, [rsp]
000078805cdd7a39  vmovaps xmm1, [rsp+0x10]
000078805cdd7a3f  vmovaps xmm2, [rsp+0x20]
000078805cdd7a45  vmovaps xmm4, [rsp+0x30]
000078805cdd7a4b  vmovaps xmm5, [rsp+0x40]
000078805cdd7a51  vmovaps xmm6, [rsp+0x50]
000078805cdd7a57  vmovaps xmm7, [rsp+0x60]
000078805cdd7a5d  vmovaps xmm8, [rsp+0x70]
000078805cdd7a63  vmovaps xmm9, [rsp+0x80]
000078805cdd7a6c  vmovaps xmm10, [rsp+0x90]
000078805cdd7a75  vmovaps xmm11, [rsp+0xA0]
000078805cdd7a7e  vmovaps xmm12, [rsp+0xB0]
000078805cdd7a87  vmovaps xmm13, [rsp+0xC0]
000078805cdd7a90  vmovaps xmm14, [rsp+0xD0]
000078805cdd7a99  vmovaps xmm15, [rsp+0xE0]
000078805cdd7aa2  add rsp, 0xF0
000078805cdd7aa9  pop r11
000078805cdd7aab  pop r10
000078805cdd7aad  pop r9
000078805cdd7aaf  pop r8
000078805cdd7ab1  pop rsi
000078805cdd7ab2  pop rdi
000078805cdd7ab3  pop rdx
000078805cdd7ab4  pop rcx
000078805cdd7ab5  pop rax
000078805cdd7ab6  add rsp, 0x08
000078805cdd7aba  jmp 0x000078805CDD5D43
000078805cdd7abf  sub rsp, 0x08
000078805cdd7ac3  push rax
000078805cdd7ac4  push rcx
000078805cdd7ac5  push rdx
000078805cdd7ac6  push rdi
000078805cdd7ac7  push rsi
000078805cdd7ac8  push r8
000078805cdd7aca  push r9
000078805cdd7acc  push r10
000078805cdd7ace  push r11
000078805cdd7ad0  sub rsp, 0xF0
000078805cdd7ad7  vmovaps [rsp], xmm0
000078805cdd7adc  vmovaps [rsp+0x10], xmm2
000078805cdd7ae2  vmovaps [rsp+0x20], xmm3
000078805cdd7ae8  vmovaps [rsp+0x30], xmm4
000078805cdd7aee  vmovaps [rsp+0x40], xmm5
000078805cdd7af4  vmovaps [rsp+0x50], xmm6
000078805cdd7afa  vmovaps [rsp+0x60], xmm7
000078805cdd7b00  vmovaps [rsp+0x70], xmm8
000078805cdd7b06  vmovaps [rsp+0x80], xmm9
000078805cdd7b0f  vmovaps [rsp+0x90], xmm10
000078805cdd7b18  vmovaps [rsp+0xA0], xmm11
000078805cdd7b21  vmovaps [rsp+0xB0], xmm12
000078805cdd7b2a  vmovaps [rsp+0xC0], xmm13
000078805cdd7b33  vmovaps [rsp+0xD0], xmm14
000078805cdd7b3c  vmovaps [rsp+0xE0], xmm15
000078805cdd7b45  sub rsp, 0x30
000078805cdd7b49  movaps [rsp], xmm1
000078805cdd7b4d  movaps [rsp+0x10], xmm15
000078805cdd7b53  movaps [rsp+0x20], xmm9
000078805cdd7b59  lea rdi, [rsp]
000078805cdd7b5d  mov esi, 0x00
000078805cdd7b62  mov rax, 0x5771AD6EA530
000078805cdd7b6c  call rax
000078805cdd7b6e  movaps xmm1, [rsp]
000078805cdd7b72  add rsp, 0x30
000078805cdd7b76  vmovaps xmm0, [rsp]
000078805cdd7b7b  vmovaps xmm2, [rsp+0x10]
000078805cdd7b81  vmovaps xmm3, [rsp+0x20]
000078805cdd7b87  vmovaps xmm4, [rsp+0x30]
000078805cdd7b8d  vmovaps xmm5, [rsp+0x40]
000078805cdd7b93  vmovaps xmm6, [rsp+0x50]
000078805cdd7b99  vmovaps xmm7, [rsp+0x60]
000078805cdd7b9f  vmovaps xmm8, [rsp+0x70]
000078805cdd7ba5  vmovaps xmm9, [rsp+0x80]
000078805cdd7bae  vmovaps xmm10, [rsp+0x90]
000078805cdd7bb7  vmovaps xmm11, [rsp+0xA0]
000078805cdd7bc0  vmovaps xmm12, [rsp+0xB0]
000078805cdd7bc9  vmovaps xmm13, [rsp+0xC0]
000078805cdd7bd2  vmovaps xmm14, [rsp+0xD0]
000078805cdd7bdb  vmovaps xmm15, [rsp+0xE0]
000078805cdd7be4  add rsp, 0xF0
000078805cdd7beb  pop r11
000078805cdd7bed  pop r10
000078805cdd7bef  pop r9
000078805cdd7bf1  pop r8
000078805cdd7bf3  pop rsi
000078805cdd7bf4  pop rdi
000078805cdd7bf5  pop rdx
000078805cdd7bf6  pop rcx
000078805cdd7bf7  pop rax
000078805cdd7bf8  add rsp, 0x08
000078805cdd7bfc  jmp 0x000078805CDD5DCB
000078805cdd7c01  call 0x000078805CCE5820
000078805cdd7c06  jmp 0x000078805CDD5DD8
000078805cdd7c0b  sub rsp, 0x08
000078805cdd7c0f  push rax
000078805cdd7c10  push rcx
000078805cdd7c11  push rdx
000078805cdd7c12  push rdi
000078805cdd7c13  push rsi
000078805cdd7c14  push r8
000078805cdd7c16  push r9
000078805cdd7c18  push r10
000078805cdd7c1a  push r11
000078805cdd7c1c  sub rsp, 0xF0
000078805cdd7c23  vmovaps [rsp], xmm0
000078805cdd7c28  vmovaps [rsp+0x10], xmm2
000078805cdd7c2e  vmovaps [rsp+0x20], xmm3
000078805cdd7c34  vmovaps [rsp+0x30], xmm4
000078805cdd7c3a  vmovaps [rsp+0x40], xmm5
000078805cdd7c40  vmovaps [rsp+0x50], xmm6
000078805cdd7c46  vmovaps [rsp+0x60], xmm7
000078805cdd7c4c  vmovaps [rsp+0x70], xmm8
000078805cdd7c52  vmovaps [rsp+0x80], xmm9
000078805cdd7c5b  vmovaps [rsp+0x90], xmm10
000078805cdd7c64  vmovaps [rsp+0xA0], xmm11
000078805cdd7c6d  vmovaps [rsp+0xB0], xmm12
000078805cdd7c76  vmovaps [rsp+0xC0], xmm13
000078805cdd7c7f  vmovaps [rsp+0xD0], xmm14
000078805cdd7c88  vmovaps [rsp+0xE0], xmm15
000078805cdd7c91  sub rsp, 0x30
000078805cdd7c95  movaps [rsp], xmm1
000078805cdd7c99  movaps [rsp+0x10], xmm5
000078805cdd7c9e  movaps [rsp+0x20], xmm7
000078805cdd7ca3  lea rdi, [rsp]
000078805cdd7ca7  mov esi, 0x00
000078805cdd7cac  mov rax, 0x5771AD6EA530
000078805cdd7cb6  call rax
000078805cdd7cb8  movaps xmm1, [rsp]
000078805cdd7cbc  add rsp, 0x30
000078805cdd7cc0  vmovaps xmm0, [rsp]
000078805cdd7cc5  vmovaps xmm2, [rsp+0x10]
000078805cdd7ccb  vmovaps xmm3, [rsp+0x20]
000078805cdd7cd1  vmovaps xmm4, [rsp+0x30]
000078805cdd7cd7  vmovaps xmm5, [rsp+0x40]
000078805cdd7cdd  vmovaps xmm6, [rsp+0x50]
000078805cdd7ce3  vmovaps xmm7, [rsp+0x60]
000078805cdd7ce9  vmovaps xmm8, [rsp+0x70]
000078805cdd7cef  vmovaps xmm9, [rsp+0x80]
000078805cdd7cf8  vmovaps xmm10, [rsp+0x90]
000078805cdd7d01  vmovaps xmm11, [rsp+0xA0]
000078805cdd7d0a  vmovaps xmm12, [rsp+0xB0]
000078805cdd7d13  vmovaps xmm13, [rsp+0xC0]
000078805cdd7d1c  vmovaps xmm14, [rsp+0xD0]
000078805cdd7d25  vmovaps xmm15, [rsp+0xE0]
000078805cdd7d2e  add rsp, 0xF0
000078805cdd7d35  pop r11
000078805cdd7d37  pop r10
000078805cdd7d39  pop r9
000078805cdd7d3b  pop r8
000078805cdd7d3d  pop rsi
000078805cdd7d3e  pop rdi
000078805cdd7d3f  pop rdx
000078805cdd7d40  pop rcx
000078805cdd7d41  pop rax
000078805cdd7d42  add rsp, 0x08
000078805cdd7d46  jmp 0x000078805CDD5E7D
000078805cdd7d4b  sub rsp, 0x08
000078805cdd7d4f  push rax
000078805cdd7d50  push rcx
000078805cdd7d51  push rdx
000078805cdd7d52  push rdi
000078805cdd7d53  push rsi
000078805cdd7d54  push r8
000078805cdd7d56  push r9
000078805cdd7d58  push r10
000078805cdd7d5a  push r11
000078805cdd7d5c  sub rsp, 0xF0
000078805cdd7d63  vmovaps [rsp], xmm0
000078805cdd7d68  vmovaps [rsp+0x10], xmm1
000078805cdd7d6e  vmovaps [rsp+0x20], xmm2
000078805cdd7d74  vmovaps [rsp+0x30], xmm3
000078805cdd7d7a  vmovaps [rsp+0x40], xmm4
000078805cdd7d80  vmovaps [rsp+0x50], xmm5
000078805cdd7d86  vmovaps [rsp+0x60], xmm6
000078805cdd7d8c  vmovaps [rsp+0x70], xmm8
000078805cdd7d92  vmovaps [rsp+0x80], xmm9
000078805cdd7d9b  vmovaps [rsp+0x90], xmm10
000078805cdd7da4  vmovaps [rsp+0xA0], xmm11
000078805cdd7dad  vmovaps [rsp+0xB0], xmm12
000078805cdd7db6  vmovaps [rsp+0xC0], xmm13
000078805cdd7dbf  vmovaps [rsp+0xD0], xmm14
000078805cdd7dc8  vmovaps [rsp+0xE0], xmm15
000078805cdd7dd1  sub rsp, 0x30
000078805cdd7dd5  movaps [rsp], xmm7
000078805cdd7dd9  movaps [rsp+0x10], xmm5
000078805cdd7dde  movaps [rsp+0x20], xmm15
000078805cdd7de4  lea rdi, [rsp]
000078805cdd7de8  mov esi, 0x00
000078805cdd7ded  mov rax, 0x5771AD6EA530
000078805cdd7df7  call rax
000078805cdd7df9  movaps xmm7, [rsp]
000078805cdd7dfd  add rsp, 0x30
000078805cdd7e01  vmovaps xmm0, [rsp]
000078805cdd7e06  vmovaps xmm1, [rsp+0x10]
000078805cdd7e0c  vmovaps xmm2, [rsp+0x20]
000078805cdd7e12  vmovaps xmm3, [rsp+0x30]
000078805cdd7e18  vmovaps xmm4, [rsp+0x40]
000078805cdd7e1e  vmovaps xmm5, [rsp+0x50]
000078805cdd7e24  vmovaps xmm6, [rsp+0x60]
000078805cdd7e2a  vmovaps xmm8, [rsp+0x70]
000078805cdd7e30  vmovaps xmm9, [rsp+0x80]
000078805cdd7e39  vmovaps xmm10, [rsp+0x90]
000078805cdd7e42  vmovaps xmm11, [rsp+0xA0]
000078805cdd7e4b  vmovaps xmm12, [rsp+0xB0]
000078805cdd7e54  vmovaps xmm13, [rsp+0xC0]
000078805cdd7e5d  vmovaps xmm14, [rsp+0xD0]
000078805cdd7e66  vmovaps xmm15, [rsp+0xE0]
000078805cdd7e6f  add rsp, 0xF0
000078805cdd7e76  pop r11
000078805cdd7e78  pop r10
000078805cdd7e7a  pop r9
000078805cdd7e7c  pop r8
000078805cdd7e7e  pop rsi
000078805cdd7e7f  pop rdi
000078805cdd7e80  pop rdx
000078805cdd7e81  pop rcx
000078805cdd7e82  pop rax
000078805cdd7e83  add rsp, 0x08
000078805cdd7e87  jmp 0x000078805CDD5EB3
000078805cdd7e8c  call 0x000078805CCD64F0
000078805cdd7e91  jmp 0x000078805CDD5EC0
000078805cdd7e96  sub rsp, 0x08
000078805cdd7e9a  push rax
000078805cdd7e9b  push rcx
000078805cdd7e9c  push rdx
000078805cdd7e9d  push rdi
000078805cdd7e9e  push rsi
000078805cdd7e9f  push r8
000078805cdd7ea1  push r9
000078805cdd7ea3  push r10
000078805cdd7ea5  push r11
000078805cdd7ea7  sub rsp, 0xF0
000078805cdd7eae  vmovaps [rsp], xmm0
000078805cdd7eb3  vmovaps [rsp+0x10], xmm1
000078805cdd7eb9  vmovaps [rsp+0x20], xmm2
000078805cdd7ebf  vmovaps [rsp+0x30], xmm3
000078805cdd7ec5  vmovaps [rsp+0x40], xmm4
000078805cdd7ecb  vmovaps [rsp+0x50], xmm5
000078805cdd7ed1  vmovaps [rsp+0x60], xmm6
000078805cdd7ed7  vmovaps [rsp+0x70], xmm7
000078805cdd7edd  vmovaps [rsp+0x80], xmm8
000078805cdd7ee6  vmovaps [rsp+0x90], xmm9
000078805cdd7eef  vmovaps [rsp+0xA0], xmm10
000078805cdd7ef8  vmovaps [rsp+0xB0], xmm11
000078805cdd7f01  vmovaps [rsp+0xC0], xmm12
000078805cdd7f0a  vmovaps [rsp+0xD0], xmm13
000078805cdd7f13  vmovaps [rsp+0xE0], xmm14
000078805cdd7f1c  sub rsp, 0x30
000078805cdd7f20  movaps [rsp], xmm15
000078805cdd7f25  movaps [rsp+0x10], xmm5
000078805cdd7f2a  movaps [rsp+0x20], xmm3
000078805cdd7f2f  lea rdi, [rsp]
000078805cdd7f33  mov esi, 0x00
000078805cdd7f38  mov rax, 0x5771AD6EA530
000078805cdd7f42  call rax
000078805cdd7f44  movaps xmm15, [rsp]
000078805cdd7f49  add rsp, 0x30
000078805cdd7f4d  vmovaps xmm0, [rsp]
000078805cdd7f52  vmovaps xmm1, [rsp+0x10]
000078805cdd7f58  vmovaps xmm2, [rsp+0x20]
000078805cdd7f5e  vmovaps xmm3, [rsp+0x30]
000078805cdd7f64  vmovaps xmm4, [rsp+0x40]
000078805cdd7f6a  vmovaps xmm5, [rsp+0x50]
000078805cdd7f70  vmovaps xmm6, [rsp+0x60]
000078805cdd7f76  vmovaps xmm7, [rsp+0x70]
000078805cdd7f7c  vmovaps xmm8, [rsp+0x80]
000078805cdd7f85  vmovaps xmm9, [rsp+0x90]
000078805cdd7f8e  vmovaps xmm10, [rsp+0xA0]
000078805cdd7f97  vmovaps xmm11, [rsp+0xB0]
000078805cdd7fa0  vmovaps xmm12, [rsp+0xC0]
000078805cdd7fa9  vmovaps xmm13, [rsp+0xD0]
000078805cdd7fb2  vmovaps xmm14, [rsp+0xE0]
000078805cdd7fbb  add rsp, 0xF0
000078805cdd7fc2  pop r11
000078805cdd7fc4  pop r10
000078805cdd7fc6  pop r9
000078805cdd7fc8  pop r8
000078805cdd7fca  pop rsi
000078805cdd7fcb  pop rdi
000078805cdd7fcc  pop rdx
000078805cdd7fcd  pop rcx
000078805cdd7fce  pop rax
000078805cdd7fcf  add rsp, 0x08
000078805cdd7fd3  jmp 0x000078805CDD5EE6
000078805cdd7fd8  sub rsp, 0x08
000078805cdd7fdc  push rax
000078805cdd7fdd  push rcx
000078805cdd7fde  push rdx
000078805cdd7fdf  push rdi
000078805cdd7fe0  push rsi
000078805cdd7fe1  push r8
000078805cdd7fe3  push r9
000078805cdd7fe5  push r10
000078805cdd7fe7  push r11
000078805cdd7fe9  sub rsp, 0xF0
000078805cdd7ff0  vmovaps [rsp], xmm0
000078805cdd7ff5  vmovaps [rsp+0x10], xmm2
000078805cdd7ffb  vmovaps [rsp+0x20], xmm3
000078805cdd8001  vmovaps [rsp+0x30], xmm4
000078805cdd8007  vmovaps [rsp+0x40], xmm5
000078805cdd800d  vmovaps [rsp+0x50], xmm6
000078805cdd8013  vmovaps [rsp+0x60], xmm7
000078805cdd8019  vmovaps [rsp+0x70], xmm8
000078805cdd801f  vmovaps [rsp+0x80], xmm9
000078805cdd8028  vmovaps [rsp+0x90], xmm10
000078805cdd8031  vmovaps [rsp+0xA0], xmm11
000078805cdd803a  vmovaps [rsp+0xB0], xmm12
000078805cdd8043  vmovaps [rsp+0xC0], xmm13
000078805cdd804c  vmovaps [rsp+0xD0], xmm14
000078805cdd8055  vmovaps [rsp+0xE0], xmm15
000078805cdd805e  sub rsp, 0x30
000078805cdd8062  movaps [rsp], xmm1
000078805cdd8066  movaps [rsp+0x10], xmm5
000078805cdd806b  movaps [rsp+0x20], xmm4
000078805cdd8070  lea rdi, [rsp]
000078805cdd8074  mov esi, 0x00
000078805cdd8079  mov rax, 0x5771AD6EA530
000078805cdd8083  call rax
000078805cdd8085  movaps xmm1, [rsp]
000078805cdd8089  add rsp, 0x30
000078805cdd808d  vmovaps xmm0, [rsp]
000078805cdd8092  vmovaps xmm2, [rsp+0x10]
000078805cdd8098  vmovaps xmm3, [rsp+0x20]
000078805cdd809e  vmovaps xmm4, [rsp+0x30]
000078805cdd80a4  vmovaps xmm5, [rsp+0x40]
000078805cdd80aa  vmovaps xmm6, [rsp+0x50]
000078805cdd80b0  vmovaps xmm7, [rsp+0x60]
000078805cdd80b6  vmovaps xmm8, [rsp+0x70]
000078805cdd80bc  vmovaps xmm9, [rsp+0x80]
000078805cdd80c5  vmovaps xmm10, [rsp+0x90]
000078805cdd80ce  vmovaps xmm11, [rsp+0xA0]
000078805cdd80d7  vmovaps xmm12, [rsp+0xB0]
000078805cdd80e0  vmovaps xmm13, [rsp+0xC0]
000078805cdd80e9  vmovaps xmm14, [rsp+0xD0]
000078805cdd80f2  vmovaps xmm15, [rsp+0xE0]
000078805cdd80fb  add rsp, 0xF0
000078805cdd8102  pop r11
000078805cdd8104  pop r10
000078805cdd8106  pop r9
000078805cdd8108  pop r8
000078805cdd810a  pop rsi
000078805cdd810b  pop rdi
000078805cdd810c  pop rdx
000078805cdd810d  pop rcx
000078805cdd810e  pop rax
000078805cdd810f  add rsp, 0x08
000078805cdd8113  jmp 0x000078805CDD5F06
000078805cdd8118  sub rsp, 0x08
000078805cdd811c  push rax
000078805cdd811d  push rcx
000078805cdd811e  push rdx
000078805cdd811f  push rdi
000078805cdd8120  push rsi
000078805cdd8121  push r8
000078805cdd8123  push r9
000078805cdd8125  push r10
000078805cdd8127  push r11
000078805cdd8129  sub rsp, 0xF0
000078805cdd8130  vmovaps [rsp], xmm0
000078805cdd8135  vmovaps [rsp+0x10], xmm1
000078805cdd813b  vmovaps [rsp+0x20], xmm2
000078805cdd8141  vmovaps [rsp+0x30], xmm3
000078805cdd8147  vmovaps [rsp+0x40], xmm5
000078805cdd814d  vmovaps [rsp+0x50], xmm6
000078805cdd8153  vmovaps [rsp+0x60], xmm7
000078805cdd8159  vmovaps [rsp+0x70], xmm8
000078805cdd815f  vmovaps [rsp+0x80], xmm9
000078805cdd8168  vmovaps [rsp+0x90], xmm10
000078805cdd8171  vmovaps [rsp+0xA0], xmm11
000078805cdd817a  vmovaps [rsp+0xB0], xmm12
000078805cdd8183  vmovaps [rsp+0xC0], xmm13
000078805cdd818c  vmovaps [rsp+0xD0], xmm14
000078805cdd8195  vmovaps [rsp+0xE0], xmm15
000078805cdd819e  sub rsp, 0x30
000078805cdd81a2  movaps [rsp], xmm4
000078805cdd81a6  movaps [rsp+0x10], xmm3
000078805cdd81ab  movaps [rsp+0x20], xmm5
000078805cdd81b0  lea rdi, [rsp]
000078805cdd81b4  mov esi, 0x00
000078805cdd81b9  mov rax, 0x5771AD6EA530
000078805cdd81c3  call rax
000078805cdd81c5  movaps xmm4, [rsp]
000078805cdd81c9  add rsp, 0x30
000078805cdd81cd  vmovaps xmm0, [rsp]
000078805cdd81d2  vmovaps xmm1, [rsp+0x10]
000078805cdd81d8  vmovaps xmm2, [rsp+0x20]
000078805cdd81de  vmovaps xmm3, [rsp+0x30]
000078805cdd81e4  vmovaps xmm5, [rsp+0x40]
000078805cdd81ea  vmovaps xmm6, [rsp+0x50]
000078805cdd81f0  vmovaps xmm7, [rsp+0x60]
000078805cdd81f6  vmovaps xmm8, [rsp+0x70]
000078805cdd81fc  vmovaps xmm9, [rsp+0x80]
000078805cdd8205  vmovaps xmm10, [rsp+0x90]
000078805cdd820e  vmovaps xmm11, [rsp+0xA0]
000078805cdd8217  vmovaps xmm12, [rsp+0xB0]
000078805cdd8220  vmovaps xmm13, [rsp+0xC0]
000078805cdd8229  vmovaps xmm14, [rsp+0xD0]
000078805cdd8232  vmovaps xmm15, [rsp+0xE0]
000078805cdd823b  add rsp, 0xF0
000078805cdd8242  pop r11
000078805cdd8244  pop r10
000078805cdd8246  pop r9
000078805cdd8248  pop r8
000078805cdd824a  pop rsi
000078805cdd824b  pop rdi
000078805cdd824c  pop rdx
000078805cdd824d  pop rcx
000078805cdd824e  pop rax
000078805cdd824f  add rsp, 0x08
000078805cdd8253  jmp 0x000078805CDD5F54
000078805cdd8258  call 0x000078805CCD64F0
000078805cdd825d  jmp 0x000078805CDD5F61
000078805cdd8262  sub rsp, 0x08
000078805cdd8266  push rax
000078805cdd8267  push rcx
000078805cdd8268  push rdx
000078805cdd8269  push rdi
000078805cdd826a  push rsi
000078805cdd826b  push r8
000078805cdd826d  push r9
000078805cdd826f  push r10
000078805cdd8271  push r11
000078805cdd8273  sub rsp, 0xF0
000078805cdd827a  vmovaps [rsp], xmm0
000078805cdd827f  vmovaps [rsp+0x10], xmm1
000078805cdd8285  vmovaps [rsp+0x20], xmm2
000078805cdd828b  vmovaps [rsp+0x30], xmm3
000078805cdd8291  vmovaps [rsp+0x40], xmm4
000078805cdd8297  vmovaps [rsp+0x50], xmm6
000078805cdd829d  vmovaps [rsp+0x60], xmm7
000078805cdd82a3  vmovaps [rsp+0x70], xmm8
000078805cdd82a9  vmovaps [rsp+0x80], xmm9
000078805cdd82b2  vmovaps [rsp+0x90], xmm10
000078805cdd82bb  vmovaps [rsp+0xA0], xmm11
000078805cdd82c4  vmovaps [rsp+0xB0], xmm12
000078805cdd82cd  vmovaps [rsp+0xC0], xmm13
000078805cdd82d6  vmovaps [rsp+0xD0], xmm14
000078805cdd82df  vmovaps [rsp+0xE0], xmm15
000078805cdd82e8  sub rsp, 0x30
000078805cdd82ec  movaps [rsp], xmm5
000078805cdd82f0  movaps [rsp+0x10], xmm6
000078805cdd82f5  movaps [rsp+0x20], xmm3
000078805cdd82fa  lea rdi, [rsp]
000078805cdd82fe  mov esi, 0x00
000078805cdd8303  mov rax, 0x5771AD6EA530
000078805cdd830d  call rax
000078805cdd830f  movaps xmm5, [rsp]
000078805cdd8313  add rsp, 0x30
000078805cdd8317  vmovaps xmm0, [rsp]
000078805cdd831c  vmovaps xmm1, [rsp+0x10]
000078805cdd8322  vmovaps xmm2, [rsp+0x20]
000078805cdd8328  vmovaps xmm3, [rsp+0x30]
000078805cdd832e  vmovaps xmm4, [rsp+0x40]
000078805cdd8334  vmovaps xmm6, [rsp+0x50]
000078805cdd833a  vmovaps xmm7, [rsp+0x60]
000078805cdd8340  vmovaps xmm8, [rsp+0x70]
000078805cdd8346  vmovaps xmm9, [rsp+0x80]
000078805cdd834f  vmovaps xmm10, [rsp+0x90]
000078805cdd8358  vmovaps xmm11, [rsp+0xA0]
000078805cdd8361  vmovaps xmm12, [rsp+0xB0]
000078805cdd836a  vmovaps xmm13, [rsp+0xC0]
000078805cdd8373  vmovaps xmm14, [rsp+0xD0]
000078805cdd837c  vmovaps xmm15, [rsp+0xE0]
000078805cdd8385  add rsp, 0xF0
000078805cdd838c  pop r11
000078805cdd838e  pop r10
000078805cdd8390  pop r9
000078805cdd8392  pop r8
000078805cdd8394  pop rsi
000078805cdd8395  pop rdi
000078805cdd8396  pop rdx
000078805cdd8397  pop rcx
000078805cdd8398  pop rax
000078805cdd8399  add rsp, 0x08
000078805cdd839d  jmp 0x000078805CDD5F87
000078805cdd83a2  sub rsp, 0x08
000078805cdd83a6  push rax
000078805cdd83a7  push rcx
000078805cdd83a8  push rdx
000078805cdd83a9  push rdi
000078805cdd83aa  push rsi
000078805cdd83ab  push r8
000078805cdd83ad  push r9
000078805cdd83af  push r10
000078805cdd83b1  push r11
000078805cdd83b3  sub rsp, 0xF0
000078805cdd83ba  vmovaps [rsp], xmm0
000078805cdd83bf  vmovaps [rsp+0x10], xmm1
000078805cdd83c5  vmovaps [rsp+0x20], xmm2
000078805cdd83cb  vmovaps [rsp+0x30], xmm3
000078805cdd83d1  vmovaps [rsp+0x40], xmm4
000078805cdd83d7  vmovaps [rsp+0x50], xmm5
000078805cdd83dd  vmovaps [rsp+0x60], xmm7
000078805cdd83e3  vmovaps [rsp+0x70], xmm8
000078805cdd83e9  vmovaps [rsp+0x80], xmm9
000078805cdd83f2  vmovaps [rsp+0x90], xmm10
000078805cdd83fb  vmovaps [rsp+0xA0], xmm11
000078805cdd8404  vmovaps [rsp+0xB0], xmm12
000078805cdd840d  vmovaps [rsp+0xC0], xmm13
000078805cdd8416  vmovaps [rsp+0xD0], xmm14
000078805cdd841f  vmovaps [rsp+0xE0], xmm15
000078805cdd8428  sub rsp, 0x30
000078805cdd842c  movaps [rsp], xmm6
000078805cdd8430  movaps [rsp+0x10], xmm9
000078805cdd8436  movaps [rsp+0x20], xmm1
000078805cdd843b  lea rdi, [rsp]
000078805cdd843f  mov esi, 0x00
000078805cdd8444  mov rax, 0x5771AD6EA530
000078805cdd844e  call rax
000078805cdd8450  movaps xmm6, [rsp]
000078805cdd8454  add rsp, 0x30
000078805cdd8458  vmovaps xmm0, [rsp]
000078805cdd845d  vmovaps xmm1, [rsp+0x10]
000078805cdd8463  vmovaps xmm2, [rsp+0x20]
000078805cdd8469  vmovaps xmm3, [rsp+0x30]
000078805cdd846f  vmovaps xmm4, [rsp+0x40]
000078805cdd8475  vmovaps xmm5, [rsp+0x50]
000078805cdd847b  vmovaps xmm7, [rsp+0x60]
000078805cdd8481  vmovaps xmm8, [rsp+0x70]
000078805cdd8487  vmovaps xmm9, [rsp+0x80]
000078805cdd8490  vmovaps xmm10, [rsp+0x90]
000078805cdd8499  vmovaps xmm11, [rsp+0xA0]
000078805cdd84a2  vmovaps xmm12, [rsp+0xB0]
000078805cdd84ab  vmovaps xmm13, [rsp+0xC0]
000078805cdd84b4  vmovaps xmm14, [rsp+0xD0]
000078805cdd84bd  vmovaps xmm15, [rsp+0xE0]
000078805cdd84c6  add rsp, 0xF0
000078805cdd84cd  pop r11
000078805cdd84cf  pop r10
000078805cdd84d1  pop r9
000078805cdd84d3  pop r8
000078805cdd84d5  pop rsi
000078805cdd84d6  pop rdi
000078805cdd84d7  pop rdx
000078805cdd84d8  pop rcx
000078805cdd84d9  pop rax
000078805cdd84da  add rsp, 0x08
000078805cdd84de  jmp 0x000078805CDD5FAB
000078805cdd84e3  sub rsp, 0x08
000078805cdd84e7  push rax
000078805cdd84e8  push rcx
000078805cdd84e9  push rdx
000078805cdd84ea  push rdi
000078805cdd84eb  push rsi
000078805cdd84ec  push r8
000078805cdd84ee  push r9
000078805cdd84f0  push r10
000078805cdd84f2  push r11
000078805cdd84f4  sub rsp, 0xF0
000078805cdd84fb  vmovaps [rsp], xmm0
000078805cdd8500  vmovaps [rsp+0x10], xmm1
000078805cdd8506  vmovaps [rsp+0x20], xmm2
000078805cdd850c  vmovaps [rsp+0x30], xmm3
000078805cdd8512  vmovaps [rsp+0x40], xmm4
000078805cdd8518  vmovaps [rsp+0x50], xmm5
000078805cdd851e  vmovaps [rsp+0x60], xmm6
000078805cdd8524  vmovaps [rsp+0x70], xmm7
000078805cdd852a  vmovaps [rsp+0x80], xmm8
000078805cdd8533  vmovaps [rsp+0x90], xmm10
000078805cdd853c  vmovaps [rsp+0xA0], xmm11
000078805cdd8545  vmovaps [rsp+0xB0], xmm12
000078805cdd854e  vmovaps [rsp+0xC0], xmm13
000078805cdd8557  vmovaps [rsp+0xD0], xmm14
000078805cdd8560  vmovaps [rsp+0xE0], xmm15
000078805cdd8569  sub rsp, 0x30
000078805cdd856d  movaps [rsp], xmm9
000078805cdd8572  movaps [rsp+0x10], xmm3
000078805cdd8577  movaps [rsp+0x20], xmm1
000078805cdd857c  lea rdi, [rsp]
000078805cdd8580  mov esi, 0x00
000078805cdd8585  mov rax, 0x5771AD6EA530
000078805cdd858f  call rax
000078805cdd8591  movaps xmm9, [rsp]
000078805cdd8596  add rsp, 0x30
000078805cdd859a  vmovaps xmm0, [rsp]
000078805cdd859f  vmovaps xmm1, [rsp+0x10]
000078805cdd85a5  vmovaps xmm2, [rsp+0x20]
000078805cdd85ab  vmovaps xmm3, [rsp+0x30]
000078805cdd85b1  vmovaps xmm4, [rsp+0x40]
000078805cdd85b7  vmovaps xmm5, [rsp+0x50]
000078805cdd85bd  vmovaps xmm6, [rsp+0x60]
000078805cdd85c3  vmovaps xmm7, [rsp+0x70]
000078805cdd85c9  vmovaps xmm8, [rsp+0x80]
000078805cdd85d2  vmovaps xmm10, [rsp+0x90]
000078805cdd85db  vmovaps xmm11, [rsp+0xA0]
000078805cdd85e4  vmovaps xmm12, [rsp+0xB0]
000078805cdd85ed  vmovaps xmm13, [rsp+0xC0]
000078805cdd85f6  vmovaps xmm14, [rsp+0xD0]
000078805cdd85ff  vmovaps xmm15, [rsp+0xE0]
000078805cdd8608  add rsp, 0xF0
000078805cdd860f  pop r11
000078805cdd8611  pop r10
000078805cdd8613  pop r9
000078805cdd8615  pop r8
000078805cdd8617  pop rsi
000078805cdd8618  pop rdi
000078805cdd8619  pop rdx
000078805cdd861a  pop rcx
000078805cdd861b  pop rax
000078805cdd861c  add rsp, 0x08
000078805cdd8620  jmp 0x000078805CDD5FF7
000078805cdd8625  call 0x000078805CCD64F0
000078805cdd862a  jmp 0x000078805CDD6004
000078805cdd862f  sub rsp, 0x08
000078805cdd8633  push rax
000078805cdd8634  push rcx
000078805cdd8635  push rdx
000078805cdd8636  push rdi
000078805cdd8637  push rsi
000078805cdd8638  push r8
000078805cdd863a  push r9
000078805cdd863c  push r10
000078805cdd863e  push r11
000078805cdd8640  sub rsp, 0xF0
000078805cdd8647  vmovaps [rsp], xmm0
000078805cdd864c  vmovaps [rsp+0x10], xmm1
000078805cdd8652  vmovaps [rsp+0x20], xmm2
000078805cdd8658  vmovaps [rsp+0x30], xmm3
000078805cdd865e  vmovaps [rsp+0x40], xmm4
000078805cdd8664  vmovaps [rsp+0x50], xmm5
000078805cdd866a  vmovaps [rsp+0x60], xmm6
000078805cdd8670  vmovaps [rsp+0x70], xmm7
000078805cdd8676  vmovaps [rsp+0x80], xmm8
000078805cdd867f  vmovaps [rsp+0x90], xmm9
000078805cdd8688  vmovaps [rsp+0xA0], xmm10
000078805cdd8691  vmovaps [rsp+0xB0], xmm11
000078805cdd869a  vmovaps [rsp+0xC0], xmm12
000078805cdd86a3  vmovaps [rsp+0xD0], xmm13
000078805cdd86ac  vmovaps [rsp+0xE0], xmm14
000078805cdd86b5  sub rsp, 0x30
000078805cdd86b9  movaps [rsp], xmm15
000078805cdd86be  movaps [rsp+0x10], xmm3
000078805cdd86c3  movaps [rsp+0x20], xmm7
000078805cdd86c8  lea rdi, [rsp]
000078805cdd86cc  mov esi, 0x00
000078805cdd86d1  mov rax, 0x5771AD6EA530
000078805cdd86db  call rax
000078805cdd86dd  movaps xmm15, [rsp]
000078805cdd86e2  add rsp, 0x30
000078805cdd86e6  vmovaps xmm0, [rsp]
000078805cdd86eb  vmovaps xmm1, [rsp+0x10]
000078805cdd86f1  vmovaps xmm2, [rsp+0x20]
000078805cdd86f7  vmovaps xmm3, [rsp+0x30]
000078805cdd86fd  vmovaps xmm4, [rsp+0x40]
000078805cdd8703  vmovaps xmm5, [rsp+0x50]
000078805cdd8709  vmovaps xmm6, [rsp+0x60]
000078805cdd870f  vmovaps xmm7, [rsp+0x70]
000078805cdd8715  vmovaps xmm8, [rsp+0x80]
000078805cdd871e  vmovaps xmm9, [rsp+0x90]
000078805cdd8727  vmovaps xmm10, [rsp+0xA0]
000078805cdd8730  vmovaps xmm11, [rsp+0xB0]
000078805cdd8739  vmovaps xmm12, [rsp+0xC0]
000078805cdd8742  vmovaps xmm13, [rsp+0xD0]
000078805cdd874b  vmovaps xmm14, [rsp+0xE0]
000078805cdd8754  add rsp, 0xF0
000078805cdd875b  pop r11
000078805cdd875d  pop r10
000078805cdd875f  pop r9
000078805cdd8761  pop r8
000078805cdd8763  pop rsi
000078805cdd8764  pop rdi
000078805cdd8765  pop rdx
000078805cdd8766  pop rcx
000078805cdd8767  pop rax
000078805cdd8768  add rsp, 0x08
000078805cdd876c  jmp 0x000078805CDD6030
000078805cdd8771  sub rsp, 0x08
000078805cdd8775  push rax
000078805cdd8776  push rcx
000078805cdd8777  push rdx
000078805cdd8778  push rdi
000078805cdd8779  push rsi
000078805cdd877a  push r8
000078805cdd877c  push r9
000078805cdd877e  push r10
000078805cdd8780  push r11
000078805cdd8782  sub rsp, 0xF0
000078805cdd8789  vmovaps [rsp], xmm0
000078805cdd878e  vmovaps [rsp+0x10], xmm1
000078805cdd8794  vmovaps [rsp+0x20], xmm2
000078805cdd879a  vmovaps [rsp+0x30], xmm4
000078805cdd87a0  vmovaps [rsp+0x40], xmm5
000078805cdd87a6  vmovaps [rsp+0x50], xmm6
000078805cdd87ac  vmovaps [rsp+0x60], xmm7
000078805cdd87b2  vmovaps [rsp+0x70], xmm8
000078805cdd87b8  vmovaps [rsp+0x80], xmm9
000078805cdd87c1  vmovaps [rsp+0x90], xmm10
000078805cdd87ca  vmovaps [rsp+0xA0], xmm11
000078805cdd87d3  vmovaps [rsp+0xB0], xmm12
000078805cdd87dc  vmovaps [rsp+0xC0], xmm13
000078805cdd87e5  vmovaps [rsp+0xD0], xmm14
000078805cdd87ee  vmovaps [rsp+0xE0], xmm15
000078805cdd87f7  sub rsp, 0x30
000078805cdd87fb  movaps [rsp], xmm3
000078805cdd87ff  movaps [rsp+0x10], xmm1
000078805cdd8804  movaps [rsp+0x20], xmm15
000078805cdd880a  lea rdi, [rsp]
000078805cdd880e  mov esi, 0x00
000078805cdd8813  mov rax, 0x5771AD6EA530
000078805cdd881d  call rax
000078805cdd881f  movaps xmm3, [rsp]
000078805cdd8823  add rsp, 0x30
000078805cdd8827  vmovaps xmm0, [rsp]
000078805cdd882c  vmovaps xmm1, [rsp+0x10]
000078805cdd8832  vmovaps xmm2, [rsp+0x20]
000078805cdd8838  vmovaps xmm4, [rsp+0x30]
000078805cdd883e  vmovaps xmm5, [rsp+0x40]
000078805cdd8844  vmovaps xmm6, [rsp+0x50]
000078805cdd884a  vmovaps xmm7, [rsp+0x60]
000078805cdd8850  vmovaps xmm8, [rsp+0x70]
000078805cdd8856  vmovaps xmm9, [rsp+0x80]
000078805cdd885f  vmovaps xmm10, [rsp+0x90]
000078805cdd8868  vmovaps xmm11, [rsp+0xA0]
000078805cdd8871  vmovaps xmm12, [rsp+0xB0]
000078805cdd887a  vmovaps xmm13, [rsp+0xC0]
000078805cdd8883  vmovaps xmm14, [rsp+0xD0]
000078805cdd888c  vmovaps xmm15, [rsp+0xE0]
000078805cdd8895  add rsp, 0xF0
000078805cdd889c  pop r11
000078805cdd889e  pop r10
000078805cdd88a0  pop r9
000078805cdd88a2  pop r8
000078805cdd88a4  pop rsi
000078805cdd88a5  pop rdi
000078805cdd88a6  pop rdx
000078805cdd88a7  pop rcx
000078805cdd88a8  pop rax
000078805cdd88a9  add rsp, 0x08
000078805cdd88ad  jmp 0x000078805CDD60BF
000078805cdd88b2  call 0x000078805CCD64F0
000078805cdd88b7  jmp 0x000078805CDD60C9
000078805cdd88bc  sub rsp, 0x08
000078805cdd88c0  push rax
000078805cdd88c1  push rcx
000078805cdd88c2  push rdx
000078805cdd88c3  push rdi
000078805cdd88c4  push rsi
000078805cdd88c5  push r8
000078805cdd88c7  push r9
000078805cdd88c9  push r10
000078805cdd88cb  push r11
000078805cdd88cd  sub rsp, 0xF0
000078805cdd88d4  vmovaps [rsp], xmm0
000078805cdd88d9  vmovaps [rsp+0x10], xmm1
000078805cdd88df  vmovaps [rsp+0x20], xmm2
000078805cdd88e5  vmovaps [rsp+0x30], xmm3
000078805cdd88eb  vmovaps [rsp+0x40], xmm4
000078805cdd88f1  vmovaps [rsp+0x50], xmm5
000078805cdd88f7  vmovaps [rsp+0x60], xmm6
000078805cdd88fd  vmovaps [rsp+0x70], xmm7
000078805cdd8903  vmovaps [rsp+0x80], xmm8
000078805cdd890c  vmovaps [rsp+0x90], xmm9
000078805cdd8915  vmovaps [rsp+0xA0], xmm10
000078805cdd891e  vmovaps [rsp+0xB0], xmm11
000078805cdd8927  vmovaps [rsp+0xC0], xmm12
000078805cdd8930  vmovaps [rsp+0xD0], xmm13
000078805cdd8939  vmovaps [rsp+0xE0], xmm14
000078805cdd8942  sub rsp, 0x30
000078805cdd8946  movaps [rsp], xmm15
000078805cdd894b  movaps [rsp+0x10], xmm14
000078805cdd8951  movaps [rsp+0x20], xmm4
000078805cdd8956  lea rdi, [rsp]
000078805cdd895a  mov esi, 0x00
000078805cdd895f  mov rax, 0x5771AD6EA530
000078805cdd8969  call rax
000078805cdd896b  movaps xmm15, [rsp]
000078805cdd8970  add rsp, 0x30
000078805cdd8974  vmovaps xmm0, [rsp]
000078805cdd8979  vmovaps xmm1, [rsp+0x10]
000078805cdd897f  vmovaps xmm2, [rsp+0x20]
000078805cdd8985  vmovaps xmm3, [rsp+0x30]
000078805cdd898b  vmovaps xmm4, [rsp+0x40]
000078805cdd8991  vmovaps xmm5, [rsp+0x50]
000078805cdd8997  vmovaps xmm6, [rsp+0x60]
000078805cdd899d  vmovaps xmm7, [rsp+0x70]
000078805cdd89a3  vmovaps xmm8, [rsp+0x80]
000078805cdd89ac  vmovaps xmm9, [rsp+0x90]
000078805cdd89b5  vmovaps xmm10, [rsp+0xA0]
000078805cdd89be  vmovaps xmm11, [rsp+0xB0]
000078805cdd89c7  vmovaps xmm12, [rsp+0xC0]
000078805cdd89d0  vmovaps xmm13, [rsp+0xD0]
000078805cdd89d9  vmovaps xmm14, [rsp+0xE0]
000078805cdd89e2  add rsp, 0xF0
000078805cdd89e9  pop r11
000078805cdd89eb  pop r10
000078805cdd89ed  pop r9
000078805cdd89ef  pop r8
000078805cdd89f1  pop rsi
000078805cdd89f2  pop rdi
000078805cdd89f3  pop rdx
000078805cdd89f4  pop rcx
000078805cdd89f5  pop rax
000078805cdd89f6  add rsp, 0x08
000078805cdd89fa  jmp 0x000078805CDD60F7
000078805cdd89ff  sub rsp, 0x08
000078805cdd8a03  push rax
000078805cdd8a04  push rcx
000078805cdd8a05  push rdx
000078805cdd8a06  push rdi
000078805cdd8a07  push rsi
000078805cdd8a08  push r8
000078805cdd8a0a  push r9
000078805cdd8a0c  push r10
000078805cdd8a0e  push r11
000078805cdd8a10  sub rsp, 0xF0
000078805cdd8a17  vmovaps [rsp], xmm0
000078805cdd8a1c  vmovaps [rsp+0x10], xmm1
000078805cdd8a22  vmovaps [rsp+0x20], xmm2
000078805cdd8a28  vmovaps [rsp+0x30], xmm3
000078805cdd8a2e  vmovaps [rsp+0x40], xmm4
000078805cdd8a34  vmovaps [rsp+0x50], xmm5
000078805cdd8a3a  vmovaps [rsp+0x60], xmm6
000078805cdd8a40  vmovaps [rsp+0x70], xmm7
000078805cdd8a46  vmovaps [rsp+0x80], xmm8
000078805cdd8a4f  vmovaps [rsp+0x90], xmm9
000078805cdd8a58  vmovaps [rsp+0xA0], xmm10
000078805cdd8a61  vmovaps [rsp+0xB0], xmm11
000078805cdd8a6a  vmovaps [rsp+0xC0], xmm12
000078805cdd8a73  vmovaps [rsp+0xD0], xmm13
000078805cdd8a7c  vmovaps [rsp+0xE0], xmm15
000078805cdd8a85  sub rsp, 0x30
000078805cdd8a89  movaps [rsp], xmm14
000078805cdd8a8e  movaps [rsp+0x10], xmm2
000078805cdd8a93  movaps [rsp+0x20], xmm1
000078805cdd8a98  lea rdi, [rsp]
000078805cdd8a9c  mov esi, 0x00
000078805cdd8aa1  mov rax, 0x5771AD6EA530
000078805cdd8aab  call rax
000078805cdd8aad  movaps xmm14, [rsp]
000078805cdd8ab2  add rsp, 0x30
000078805cdd8ab6  vmovaps xmm0, [rsp]
000078805cdd8abb  vmovaps xmm1, [rsp+0x10]
000078805cdd8ac1  vmovaps xmm2, [rsp+0x20]
000078805cdd8ac7  vmovaps xmm3, [rsp+0x30]
000078805cdd8acd  vmovaps xmm4, [rsp+0x40]
000078805cdd8ad3  vmovaps xmm5, [rsp+0x50]
000078805cdd8ad9  vmovaps xmm6, [rsp+0x60]
000078805cdd8adf  vmovaps xmm7, [rsp+0x70]
000078805cdd8ae5  vmovaps xmm8, [rsp+0x80]
000078805cdd8aee  vmovaps xmm9, [rsp+0x90]
000078805cdd8af7  vmovaps xmm10, [rsp+0xA0]
000078805cdd8b00  vmovaps xmm11, [rsp+0xB0]
000078805cdd8b09  vmovaps xmm12, [rsp+0xC0]
000078805cdd8b12  vmovaps xmm13, [rsp+0xD0]
000078805cdd8b1b  vmovaps xmm15, [rsp+0xE0]
000078805cdd8b24  add rsp, 0xF0
000078805cdd8b2b  pop r11
000078805cdd8b2d  pop r10
000078805cdd8b2f  pop r9
000078805cdd8b31  pop r8
000078805cdd8b33  pop rsi
000078805cdd8b34  pop rdi
000078805cdd8b35  pop rdx
000078805cdd8b36  pop rcx
000078805cdd8b37  pop rax
000078805cdd8b38  add rsp, 0x08
000078805cdd8b3c  jmp 0x000078805CDD611D
000078805cdd8b41  sub rsp, 0x08
000078805cdd8b45  push rax
000078805cdd8b46  push rcx
000078805cdd8b47  push rdx
000078805cdd8b48  push rdi
000078805cdd8b49  push rsi
000078805cdd8b4a  push r8
000078805cdd8b4c  push r9
000078805cdd8b4e  push r10
000078805cdd8b50  push r11
000078805cdd8b52  sub rsp, 0xF0
000078805cdd8b59  vmovaps [rsp], xmm0
000078805cdd8b5e  vmovaps [rsp+0x10], xmm2
000078805cdd8b64  vmovaps [rsp+0x20], xmm3
000078805cdd8b6a  vmovaps [rsp+0x30], xmm4
000078805cdd8b70  vmovaps [rsp+0x40], xmm5
000078805cdd8b76  vmovaps [rsp+0x50], xmm6
000078805cdd8b7c  vmovaps [rsp+0x60], xmm7
000078805cdd8b82  vmovaps [rsp+0x70], xmm8
000078805cdd8b88  vmovaps [rsp+0x80], xmm9
000078805cdd8b91  vmovaps [rsp+0x90], xmm10
000078805cdd8b9a  vmovaps [rsp+0xA0], xmm11
000078805cdd8ba3  vmovaps [rsp+0xB0], xmm12
000078805cdd8bac  vmovaps [rsp+0xC0], xmm13
000078805cdd8bb5  vmovaps [rsp+0xD0], xmm14
000078805cdd8bbe  vmovaps [rsp+0xE0], xmm15
000078805cdd8bc7  sub rsp, 0x30
000078805cdd8bcb  movaps [rsp], xmm1
000078805cdd8bcf  movaps [rsp+0x10], xmm4
000078805cdd8bd4  movaps [rsp+0x20], xmm9
000078805cdd8bda  lea rdi, [rsp]
000078805cdd8bde  mov esi, 0x00
000078805cdd8be3  mov rax, 0x5771AD6EA530
000078805cdd8bed  call rax
000078805cdd8bef  movaps xmm1, [rsp]
000078805cdd8bf3  add rsp, 0x30
000078805cdd8bf7  vmovaps xmm0, [rsp]
000078805cdd8bfc  vmovaps xmm2, [rsp+0x10]
000078805cdd8c02  vmovaps xmm3, [rsp+0x20]
000078805cdd8c08  vmovaps xmm4, [rsp+0x30]
000078805cdd8c0e  vmovaps xmm5, [rsp+0x40]
000078805cdd8c14  vmovaps xmm6, [rsp+0x50]
000078805cdd8c1a  vmovaps xmm7, [rsp+0x60]
000078805cdd8c20  vmovaps xmm8, [rsp+0x70]
000078805cdd8c26  vmovaps xmm9, [rsp+0x80]
000078805cdd8c2f  vmovaps xmm10, [rsp+0x90]
000078805cdd8c38  vmovaps xmm11, [rsp+0xA0]
000078805cdd8c41  vmovaps xmm12, [rsp+0xB0]
000078805cdd8c4a  vmovaps xmm13, [rsp+0xC0]
000078805cdd8c53  vmovaps xmm14, [rsp+0xD0]
000078805cdd8c5c  vmovaps xmm15, [rsp+0xE0]
000078805cdd8c65  add rsp, 0xF0
000078805cdd8c6c  pop r11
000078805cdd8c6e  pop r10
000078805cdd8c70  pop r9
000078805cdd8c72  pop r8
000078805cdd8c74  pop rsi
000078805cdd8c75  pop rdi
000078805cdd8c76  pop rdx
000078805cdd8c77  pop rcx
000078805cdd8c78  pop rax
000078805cdd8c79  add rsp, 0x08
000078805cdd8c7d  jmp 0x000078805CDD613B
000078805cdd8c82  sub rsp, 0x08
000078805cdd8c86  push rax
000078805cdd8c87  push rcx
000078805cdd8c88  push rdx
000078805cdd8c89  push rdi
000078805cdd8c8a  push rsi
000078805cdd8c8b  push r8
000078805cdd8c8d  push r9
000078805cdd8c8f  push r10
000078805cdd8c91  push r11
000078805cdd8c93  sub rsp, 0xF0
000078805cdd8c9a  vmovaps [rsp], xmm0
000078805cdd8c9f  vmovaps [rsp+0x10], xmm1
000078805cdd8ca5  vmovaps [rsp+0x20], xmm2
000078805cdd8cab  vmovaps [rsp+0x30], xmm3
000078805cdd8cb1  vmovaps [rsp+0x40], xmm5
000078805cdd8cb7  vmovaps [rsp+0x50], xmm6
000078805cdd8cbd  vmovaps [rsp+0x60], xmm7
000078805cdd8cc3  vmovaps [rsp+0x70], xmm8
000078805cdd8cc9  vmovaps [rsp+0x80], xmm9
000078805cdd8cd2  vmovaps [rsp+0x90], xmm10
000078805cdd8cdb  vmovaps [rsp+0xA0], xmm11
000078805cdd8ce4  vmovaps [rsp+0xB0], xmm12
000078805cdd8ced  vmovaps [rsp+0xC0], xmm13
000078805cdd8cf6  vmovaps [rsp+0xD0], xmm14
000078805cdd8cff  vmovaps [rsp+0xE0], xmm15
000078805cdd8d08  sub rsp, 0x30
000078805cdd8d0c  movaps [rsp], xmm4
000078805cdd8d10  movaps [rsp+0x10], xmm2
000078805cdd8d15  movaps [rsp+0x20], xmm9
000078805cdd8d1b  lea rdi, [rsp]
000078805cdd8d1f  mov esi, 0x00
000078805cdd8d24  mov rax, 0x5771AD6EA530
000078805cdd8d2e  call rax
000078805cdd8d30  movaps xmm4, [rsp]
000078805cdd8d34  add rsp, 0x30
000078805cdd8d38  vmovaps xmm0, [rsp]
000078805cdd8d3d  vmovaps xmm1, [rsp+0x10]
000078805cdd8d43  vmovaps xmm2, [rsp+0x20]
000078805cdd8d49  vmovaps xmm3, [rsp+0x30]
000078805cdd8d4f  vmovaps xmm5, [rsp+0x40]
000078805cdd8d55  vmovaps xmm6, [rsp+0x50]
000078805cdd8d5b  vmovaps xmm7, [rsp+0x60]
000078805cdd8d61  vmovaps xmm8, [rsp+0x70]
000078805cdd8d67  vmovaps xmm9, [rsp+0x80]
000078805cdd8d70  vmovaps xmm10, [rsp+0x90]
000078805cdd8d79  vmovaps xmm11, [rsp+0xA0]
000078805cdd8d82  vmovaps xmm12, [rsp+0xB0]
000078805cdd8d8b  vmovaps xmm13, [rsp+0xC0]
000078805cdd8d94  vmovaps xmm14, [rsp+0xD0]
000078805cdd8d9d  vmovaps xmm15, [rsp+0xE0]
000078805cdd8da6  add rsp, 0xF0
000078805cdd8dad  pop r11
000078805cdd8daf  pop r10
000078805cdd8db1  pop r9
000078805cdd8db3  pop r8
000078805cdd8db5  pop rsi
000078805cdd8db6  pop rdi
000078805cdd8db7  pop rdx
000078805cdd8db8  pop rcx
000078805cdd8db9  pop rax
000078805cdd8dba  add rsp, 0x08
000078805cdd8dbe  jmp 0x000078805CDD616B
000078805cdd8dc3  sub rsp, 0x08
000078805cdd8dc7  push rax
000078805cdd8dc8  push rcx
000078805cdd8dc9  push rdx
000078805cdd8dca  push rdi
000078805cdd8dcb  push rsi
000078805cdd8dcc  push r8
000078805cdd8dce  push r9
000078805cdd8dd0  push r10
000078805cdd8dd2  push r11
000078805cdd8dd4  sub rsp, 0xF0
000078805cdd8ddb  vmovaps [rsp], xmm0
000078805cdd8de0  vmovaps [rsp+0x10], xmm1
000078805cdd8de6  vmovaps [rsp+0x20], xmm2
000078805cdd8dec  vmovaps [rsp+0x30], xmm3
000078805cdd8df2  vmovaps [rsp+0x40], xmm4
000078805cdd8df8  vmovaps [rsp+0x50], xmm5
000078805cdd8dfe  vmovaps [rsp+0x60], xmm6
000078805cdd8e04  vmovaps [rsp+0x70], xmm7
000078805cdd8e0a  vmovaps [rsp+0x80], xmm8
000078805cdd8e13  vmovaps [rsp+0x90], xmm10
000078805cdd8e1c  vmovaps [rsp+0xA0], xmm11
000078805cdd8e25  vmovaps [rsp+0xB0], xmm12
000078805cdd8e2e  vmovaps [rsp+0xC0], xmm13
000078805cdd8e37  vmovaps [rsp+0xD0], xmm14
000078805cdd8e40  vmovaps [rsp+0xE0], xmm15
000078805cdd8e49  sub rsp, 0x30
000078805cdd8e4d  movaps [rsp], xmm9
000078805cdd8e52  movaps [rsp+0x10], xmm2
000078805cdd8e57  movaps [rsp+0x20], xmm1
000078805cdd8e5c  lea rdi, [rsp]
000078805cdd8e60  mov esi, 0x00
000078805cdd8e65  mov rax, 0x5771AD6EA530
000078805cdd8e6f  call rax
000078805cdd8e71  movaps xmm9, [rsp]
000078805cdd8e76  add rsp, 0x30
000078805cdd8e7a  vmovaps xmm0, [rsp]
000078805cdd8e7f  vmovaps xmm1, [rsp+0x10]
000078805cdd8e85  vmovaps xmm2, [rsp+0x20]
000078805cdd8e8b  vmovaps xmm3, [rsp+0x30]
000078805cdd8e91  vmovaps xmm4, [rsp+0x40]
000078805cdd8e97  vmovaps xmm5, [rsp+0x50]
000078805cdd8e9d  vmovaps xmm6, [rsp+0x60]
000078805cdd8ea3  vmovaps xmm7, [rsp+0x70]
000078805cdd8ea9  vmovaps xmm8, [rsp+0x80]
000078805cdd8eb2  vmovaps xmm10, [rsp+0x90]
000078805cdd8ebb  vmovaps xmm11, [rsp+0xA0]
000078805cdd8ec4  vmovaps xmm12, [rsp+0xB0]
000078805cdd8ecd  vmovaps xmm13, [rsp+0xC0]
000078805cdd8ed6  vmovaps xmm14, [rsp+0xD0]
000078805cdd8edf  vmovaps xmm15, [rsp+0xE0]
000078805cdd8ee8  add rsp, 0xF0
000078805cdd8eef  pop r11
000078805cdd8ef1  pop r10
000078805cdd8ef3  pop r9
000078805cdd8ef5  pop r8
000078805cdd8ef7  pop rsi
000078805cdd8ef8  pop rdi
000078805cdd8ef9  pop rdx
000078805cdd8efa  pop rcx
000078805cdd8efb  pop rax
000078805cdd8efc  add rsp, 0x08
000078805cdd8f00  jmp 0x000078805CDD61A1
000078805cdd8f05  sub rsp, 0x08
000078805cdd8f09  push rax
000078805cdd8f0a  push rcx
000078805cdd8f0b  push rdx
000078805cdd8f0c  push rdi
000078805cdd8f0d  push rsi
000078805cdd8f0e  push r8
000078805cdd8f10  push r9
000078805cdd8f12  push r10
000078805cdd8f14  push r11
000078805cdd8f16  sub rsp, 0xF0
000078805cdd8f1d  vmovaps [rsp], xmm0
000078805cdd8f22  vmovaps [rsp+0x10], xmm2
000078805cdd8f28  vmovaps [rsp+0x20], xmm3
000078805cdd8f2e  vmovaps [rsp+0x30], xmm4
000078805cdd8f34  vmovaps [rsp+0x40], xmm5
000078805cdd8f3a  vmovaps [rsp+0x50], xmm6
000078805cdd8f40  vmovaps [rsp+0x60], xmm7
000078805cdd8f46  vmovaps [rsp+0x70], xmm8
000078805cdd8f4c  vmovaps [rsp+0x80], xmm9
000078805cdd8f55  vmovaps [rsp+0x90], xmm10
000078805cdd8f5e  vmovaps [rsp+0xA0], xmm11
000078805cdd8f67  vmovaps [rsp+0xB0], xmm12
000078805cdd8f70  vmovaps [rsp+0xC0], xmm13
000078805cdd8f79  vmovaps [rsp+0xD0], xmm14
000078805cdd8f82  vmovaps [rsp+0xE0], xmm15
000078805cdd8f8b  sub rsp, 0x30
000078805cdd8f8f  movaps [rsp], xmm1
000078805cdd8f93  movaps [rsp+0x10], xmm15
000078805cdd8f99  movaps [rsp+0x20], xmm6
000078805cdd8f9e  lea rdi, [rsp]
000078805cdd8fa2  mov esi, 0x00
000078805cdd8fa7  mov rax, 0x5771AD6EA530
000078805cdd8fb1  call rax
000078805cdd8fb3  movaps xmm1, [rsp]
000078805cdd8fb7  add rsp, 0x30
000078805cdd8fbb  vmovaps xmm0, [rsp]
000078805cdd8fc0  vmovaps xmm2, [rsp+0x10]
000078805cdd8fc6  vmovaps xmm3, [rsp+0x20]
000078805cdd8fcc  vmovaps xmm4, [rsp+0x30]
000078805cdd8fd2  vmovaps xmm5, [rsp+0x40]
000078805cdd8fd8  vmovaps xmm6, [rsp+0x50]
000078805cdd8fde  vmovaps xmm7, [rsp+0x60]
000078805cdd8fe4  vmovaps xmm8, [rsp+0x70]
000078805cdd8fea  vmovaps xmm9, [rsp+0x80]
000078805cdd8ff3  vmovaps xmm10, [rsp+0x90]
000078805cdd8ffc  vmovaps xmm11, [rsp+0xA0]
000078805cdd9005  vmovaps xmm12, [rsp+0xB0]
000078805cdd900e  vmovaps xmm13, [rsp+0xC0]
000078805cdd9017  vmovaps xmm14, [rsp+0xD0]
000078805cdd9020  vmovaps xmm15, [rsp+0xE0]
000078805cdd9029  add rsp, 0xF0
000078805cdd9030  pop r11
000078805cdd9032  pop r10
000078805cdd9034  pop r9
000078805cdd9036  pop r8
000078805cdd9038  pop rsi
000078805cdd9039  pop rdi
000078805cdd903a  pop rdx
000078805cdd903b  pop rcx
000078805cdd903c  pop rax
000078805cdd903d  add rsp, 0x08
000078805cdd9041  jmp 0x000078805CDD61C2
000078805cdd9046  sub rsp, 0x08
000078805cdd904a  push rax
000078805cdd904b  push rcx
000078805cdd904c  push rdx
000078805cdd904d  push rdi
000078805cdd904e  push rsi
000078805cdd904f  push r8
000078805cdd9051  push r9
000078805cdd9053  push r10
000078805cdd9055  push r11
000078805cdd9057  sub rsp, 0xF0
000078805cdd905e  vmovaps [rsp], xmm0
000078805cdd9063  vmovaps [rsp+0x10], xmm1
000078805cdd9069  vmovaps [rsp+0x20], xmm2
000078805cdd906f  vmovaps [rsp+0x30], xmm3
000078805cdd9075  vmovaps [rsp+0x40], xmm4
000078805cdd907b  vmovaps [rsp+0x50], xmm5
000078805cdd9081  vmovaps [rsp+0x60], xmm6
000078805cdd9087  vmovaps [rsp+0x70], xmm7
000078805cdd908d  vmovaps [rsp+0x80], xmm8
000078805cdd9096  vmovaps [rsp+0x90], xmm9
000078805cdd909f  vmovaps [rsp+0xA0], xmm10
000078805cdd90a8  vmovaps [rsp+0xB0], xmm11
000078805cdd90b1  vmovaps [rsp+0xC0], xmm12
000078805cdd90ba  vmovaps [rsp+0xD0], xmm13
000078805cdd90c3  vmovaps [rsp+0xE0], xmm14
000078805cdd90cc  sub rsp, 0x30
000078805cdd90d0  movaps [rsp], xmm15
000078805cdd90d5  movaps [rsp+0x10], xmm5
000078805cdd90da  movaps [rsp+0x20], xmm3
000078805cdd90df  lea rdi, [rsp]
000078805cdd90e3  mov esi, 0x00
000078805cdd90e8  mov rax, 0x5771AD6EA530
000078805cdd90f2  call rax
000078805cdd90f4  movaps xmm15, [rsp]
000078805cdd90f9  add rsp, 0x30
000078805cdd90fd  vmovaps xmm0, [rsp]
000078805cdd9102  vmovaps xmm1, [rsp+0x10]
000078805cdd9108  vmovaps xmm2, [rsp+0x20]
000078805cdd910e  vmovaps xmm3, [rsp+0x30]
000078805cdd9114  vmovaps xmm4, [rsp+0x40]
000078805cdd911a  vmovaps xmm5, [rsp+0x50]
000078805cdd9120  vmovaps xmm6, [rsp+0x60]
000078805cdd9126  vmovaps xmm7, [rsp+0x70]
000078805cdd912c  vmovaps xmm8, [rsp+0x80]
000078805cdd9135  vmovaps xmm9, [rsp+0x90]
000078805cdd913e  vmovaps xmm10, [rsp+0xA0]
000078805cdd9147  vmovaps xmm11, [rsp+0xB0]
000078805cdd9150  vmovaps xmm12, [rsp+0xC0]
000078805cdd9159  vmovaps xmm13, [rsp+0xD0]
000078805cdd9162  vmovaps xmm14, [rsp+0xE0]
000078805cdd916b  add rsp, 0xF0
000078805cdd9172  pop r11
000078805cdd9174  pop r10
000078805cdd9176  pop r9
000078805cdd9178  pop r8
000078805cdd917a  pop rsi
000078805cdd917b  pop rdi
000078805cdd917c  pop rdx
000078805cdd917d  pop rcx
000078805cdd917e  pop rax
000078805cdd917f  add rsp, 0x08
000078805cdd9183  jmp 0x000078805CDD61DC
000078805cdd9188  sub rsp, 0x08
000078805cdd918c  push rax
000078805cdd918d  push rcx
000078805cdd918e  push rdx
000078805cdd918f  push rdi
000078805cdd9190  push rsi
000078805cdd9191  push r8
000078805cdd9193  push r9
000078805cdd9195  push r10
000078805cdd9197  push r11
000078805cdd9199  sub rsp, 0xF0
000078805cdd91a0  vmovaps [rsp], xmm0
000078805cdd91a5  vmovaps [rsp+0x10], xmm1
000078805cdd91ab  vmovaps [rsp+0x20], xmm2
000078805cdd91b1  vmovaps [rsp+0x30], xmm3
000078805cdd91b7  vmovaps [rsp+0x40], xmm4
000078805cdd91bd  vmovaps [rsp+0x50], xmm6
000078805cdd91c3  vmovaps [rsp+0x60], xmm7
000078805cdd91c9  vmovaps [rsp+0x70], xmm8
000078805cdd91cf  vmovaps [rsp+0x80], xmm9
000078805cdd91d8  vmovaps [rsp+0x90], xmm10
000078805cdd91e1  vmovaps [rsp+0xA0], xmm11
000078805cdd91ea  vmovaps [rsp+0xB0], xmm12
000078805cdd91f3  vmovaps [rsp+0xC0], xmm13
000078805cdd91fc  vmovaps [rsp+0xD0], xmm14
000078805cdd9205  vmovaps [rsp+0xE0], xmm15
000078805cdd920e  sub rsp, 0x30
000078805cdd9212  movaps [rsp], xmm5
000078805cdd9216  movaps [rsp+0x10], xmm8
000078805cdd921c  movaps [rsp+0x20], xmm6
000078805cdd9221  lea rdi, [rsp]
000078805cdd9225  mov esi, 0x00
000078805cdd922a  mov rax, 0x5771AD6EA530
000078805cdd9234  call rax
000078805cdd9236  movaps xmm5, [rsp]
000078805cdd923a  add rsp, 0x30
000078805cdd923e  vmovaps xmm0, [rsp]
000078805cdd9243  vmovaps xmm1, [rsp+0x10]
000078805cdd9249  vmovaps xmm2, [rsp+0x20]
000078805cdd924f  vmovaps xmm3, [rsp+0x30]
000078805cdd9255  vmovaps xmm4, [rsp+0x40]
000078805cdd925b  vmovaps xmm6, [rsp+0x50]
000078805cdd9261  vmovaps xmm7, [rsp+0x60]
000078805cdd9267  vmovaps xmm8, [rsp+0x70]
000078805cdd926d  vmovaps xmm9, [rsp+0x80]
000078805cdd9276  vmovaps xmm10, [rsp+0x90]
000078805cdd927f  vmovaps xmm11, [rsp+0xA0]
000078805cdd9288  vmovaps xmm12, [rsp+0xB0]
000078805cdd9291  vmovaps xmm13, [rsp+0xC0]
000078805cdd929a  vmovaps xmm14, [rsp+0xD0]
000078805cdd92a3  vmovaps xmm15, [rsp+0xE0]
000078805cdd92ac  add rsp, 0xF0
000078805cdd92b3  pop r11
000078805cdd92b5  pop r10
000078805cdd92b7  pop r9
000078805cdd92b9  pop r8
000078805cdd92bb  pop rsi
000078805cdd92bc  pop rdi
000078805cdd92bd  pop rdx
000078805cdd92be  pop rcx
000078805cdd92bf  pop rax
000078805cdd92c0  add rsp, 0x08
000078805cdd92c4  jmp 0x000078805CDD6200
000078805cdd92c9  sub rsp, 0x08
000078805cdd92cd  push rax
000078805cdd92ce  push rcx
000078805cdd92cf  push rdx
000078805cdd92d0  push rdi
000078805cdd92d1  push rsi
000078805cdd92d2  push r8
000078805cdd92d4  push r9
000078805cdd92d6  push r10
000078805cdd92d8  push r11
000078805cdd92da  sub rsp, 0xF0
000078805cdd92e1  vmovaps [rsp], xmm0
000078805cdd92e6  vmovaps [rsp+0x10], xmm1
000078805cdd92ec  vmovaps [rsp+0x20], xmm2
000078805cdd92f2  vmovaps [rsp+0x30], xmm3
000078805cdd92f8  vmovaps [rsp+0x40], xmm4
000078805cdd92fe  vmovaps [rsp+0x50], xmm5
000078805cdd9304  vmovaps [rsp+0x60], xmm7
000078805cdd930a  vmovaps [rsp+0x70], xmm8
000078805cdd9310  vmovaps [rsp+0x80], xmm9
000078805cdd9319  vmovaps [rsp+0x90], xmm10
000078805cdd9322  vmovaps [rsp+0xA0], xmm11
000078805cdd932b  vmovaps [rsp+0xB0], xmm12
000078805cdd9334  vmovaps [rsp+0xC0], xmm13
000078805cdd933d  vmovaps [rsp+0xD0], xmm14
000078805cdd9346  vmovaps [rsp+0xE0], xmm15
000078805cdd934f  sub rsp, 0x30
000078805cdd9353  movaps [rsp], xmm6
000078805cdd9357  movaps [rsp+0x10], xmm10
000078805cdd935d  movaps [rsp+0x20], xmm8
000078805cdd9363  lea rdi, [rsp]
000078805cdd9367  mov esi, 0x00
000078805cdd936c  mov rax, 0x5771AD6EA530
000078805cdd9376  call rax
000078805cdd9378  movaps xmm6, [rsp]
000078805cdd937c  add rsp, 0x30
000078805cdd9380  vmovaps xmm0, [rsp]
000078805cdd9385  vmovaps xmm1, [rsp+0x10]
000078805cdd938b  vmovaps xmm2, [rsp+0x20]
000078805cdd9391  vmovaps xmm3, [rsp+0x30]
000078805cdd9397  vmovaps xmm4, [rsp+0x40]
000078805cdd939d  vmovaps xmm5, [rsp+0x50]
000078805cdd93a3  vmovaps xmm7, [rsp+0x60]
000078805cdd93a9  vmovaps xmm8, [rsp+0x70]
000078805cdd93af  vmovaps xmm9, [rsp+0x80]
000078805cdd93b8  vmovaps xmm10, [rsp+0x90]
000078805cdd93c1  vmovaps xmm11, [rsp+0xA0]
000078805cdd93ca  vmovaps xmm12, [rsp+0xB0]
000078805cdd93d3  vmovaps xmm13, [rsp+0xC0]
000078805cdd93dc  vmovaps xmm14, [rsp+0xD0]
000078805cdd93e5  vmovaps xmm15, [rsp+0xE0]
000078805cdd93ee  add rsp, 0xF0
000078805cdd93f5  pop r11
000078805cdd93f7  pop r10
000078805cdd93f9  pop r9
000078805cdd93fb  pop r8
000078805cdd93fd  pop rsi
000078805cdd93fe  pop rdi
000078805cdd93ff  pop rdx
000078805cdd9400  pop rcx
000078805cdd9401  pop rax
000078805cdd9402  add rsp, 0x08
000078805cdd9406  jmp 0x000078805CDD6225
000078805cdd940b  sub rsp, 0x08
000078805cdd940f  push rax
000078805cdd9410  push rcx
000078805cdd9411  push rdx
000078805cdd9412  push rdi
000078805cdd9413  push rsi
000078805cdd9414  push r8
000078805cdd9416  push r9
000078805cdd9418  push r10
000078805cdd941a  push r11
000078805cdd941c  sub rsp, 0xF0
000078805cdd9423  vmovaps [rsp], xmm0
000078805cdd9428  vmovaps [rsp+0x10], xmm1
000078805cdd942e  vmovaps [rsp+0x20], xmm2
000078805cdd9434  vmovaps [rsp+0x30], xmm3
000078805cdd943a  vmovaps [rsp+0x40], xmm4
000078805cdd9440  vmovaps [rsp+0x50], xmm5
000078805cdd9446  vmovaps [rsp+0x60], xmm6
000078805cdd944c  vmovaps [rsp+0x70], xmm7
000078805cdd9452  vmovaps [rsp+0x80], xmm8
000078805cdd945b  vmovaps [rsp+0x90], xmm9
000078805cdd9464  vmovaps [rsp+0xA0], xmm11
000078805cdd946d  vmovaps [rsp+0xB0], xmm12
000078805cdd9476  vmovaps [rsp+0xC0], xmm13
000078805cdd947f  vmovaps [rsp+0xD0], xmm14
000078805cdd9488  vmovaps [rsp+0xE0], xmm15
000078805cdd9491  sub rsp, 0x30
000078805cdd9495  movaps [rsp], xmm10
000078805cdd949a  movaps [rsp+0x10], xmm8
000078805cdd94a0  movaps [rsp+0x20], xmm14
000078805cdd94a6  lea rdi, [rsp]
000078805cdd94aa  mov esi, 0x00
000078805cdd94af  mov rax, 0x5771AD6EA530
000078805cdd94b9  call rax
000078805cdd94bb  movaps xmm10, [rsp]
000078805cdd94c0  add rsp, 0x30
000078805cdd94c4  vmovaps xmm0, [rsp]
000078805cdd94c9  vmovaps xmm1, [rsp+0x10]
000078805cdd94cf  vmovaps xmm2, [rsp+0x20]
000078805cdd94d5  vmovaps xmm3, [rsp+0x30]
000078805cdd94db  vmovaps xmm4, [rsp+0x40]
000078805cdd94e1  vmovaps xmm5, [rsp+0x50]
000078805cdd94e7  vmovaps xmm6, [rsp+0x60]
000078805cdd94ed  vmovaps xmm7, [rsp+0x70]
000078805cdd94f3  vmovaps xmm8, [rsp+0x80]
000078805cdd94fc  vmovaps xmm9, [rsp+0x90]
000078805cdd9505  vmovaps xmm11, [rsp+0xA0]
000078805cdd950e  vmovaps xmm12, [rsp+0xB0]
000078805cdd9517  vmovaps xmm13, [rsp+0xC0]
000078805cdd9520  vmovaps xmm14, [rsp+0xD0]
000078805cdd9529  vmovaps xmm15, [rsp+0xE0]
000078805cdd9532  add rsp, 0xF0
000078805cdd9539  pop r11
000078805cdd953b  pop r10
000078805cdd953d  pop r9
000078805cdd953f  pop r8
000078805cdd9541  pop rsi
000078805cdd9542  pop rdi
000078805cdd9543  pop rdx
000078805cdd9544  pop rcx
000078805cdd9545  pop rax
000078805cdd9546  add rsp, 0x08
000078805cdd954a  jmp 0x000078805CDD6245
000078805cdd954f  sub rsp, 0x08
000078805cdd9553  push rax
000078805cdd9554  push rcx
000078805cdd9555  push rdx
000078805cdd9556  push rdi
000078805cdd9557  push rsi
000078805cdd9558  push r8
000078805cdd955a  push r9
000078805cdd955c  push r10
000078805cdd955e  push r11
000078805cdd9560  sub rsp, 0xF0
000078805cdd9567  vmovaps [rsp], xmm0
000078805cdd956c  vmovaps [rsp+0x10], xmm1
000078805cdd9572  vmovaps [rsp+0x20], xmm2
000078805cdd9578  vmovaps [rsp+0x30], xmm3
000078805cdd957e  vmovaps [rsp+0x40], xmm4
000078805cdd9584  vmovaps [rsp+0x50], xmm5
000078805cdd958a  vmovaps [rsp+0x60], xmm6
000078805cdd9590  vmovaps [rsp+0x70], xmm7
000078805cdd9596  vmovaps [rsp+0x80], xmm8
000078805cdd959f  vmovaps [rsp+0x90], xmm9
000078805cdd95a8  vmovaps [rsp+0xA0], xmm10
000078805cdd95b1  vmovaps [rsp+0xB0], xmm11
000078805cdd95ba  vmovaps [rsp+0xC0], xmm12
000078805cdd95c3  vmovaps [rsp+0xD0], xmm13
000078805cdd95cc  vmovaps [rsp+0xE0], xmm15
000078805cdd95d5  sub rsp, 0x30
000078805cdd95d9  movaps [rsp], xmm14
000078805cdd95de  movaps [rsp+0x10], xmm8
000078805cdd95e4  movaps [rsp+0x20], xmm4
000078805cdd95e9  lea rdi, [rsp]
000078805cdd95ed  mov esi, 0x00
000078805cdd95f2  mov rax, 0x5771AD6EA530
000078805cdd95fc  call rax
000078805cdd95fe  movaps xmm14, [rsp]
000078805cdd9603  add rsp, 0x30
000078805cdd9607  vmovaps xmm0, [rsp]
000078805cdd960c  vmovaps xmm1, [rsp+0x10]
000078805cdd9612  vmovaps xmm2, [rsp+0x20]
000078805cdd9618  vmovaps xmm3, [rsp+0x30]
000078805cdd961e  vmovaps xmm4, [rsp+0x40]
000078805cdd9624  vmovaps xmm5, [rsp+0x50]
000078805cdd962a  vmovaps xmm6, [rsp+0x60]
000078805cdd9630  vmovaps xmm7, [rsp+0x70]
000078805cdd9636  vmovaps xmm8, [rsp+0x80]
000078805cdd963f  vmovaps xmm9, [rsp+0x90]
000078805cdd9648  vmovaps xmm10, [rsp+0xA0]
000078805cdd9651  vmovaps xmm11, [rsp+0xB0]
000078805cdd965a  vmovaps xmm12, [rsp+0xC0]
000078805cdd9663  vmovaps xmm13, [rsp+0xD0]
000078805cdd966c  vmovaps xmm15, [rsp+0xE0]
000078805cdd9675  add rsp, 0xF0
000078805cdd967c  pop r11
000078805cdd967e  pop r10
000078805cdd9680  pop r9
000078805cdd9682  pop r8
000078805cdd9684  pop rsi
000078805cdd9685  pop rdi
000078805cdd9686  pop rdx
000078805cdd9687  pop rcx
000078805cdd9688  pop rax
000078805cdd9689  add rsp, 0x08
000078805cdd968d  jmp 0x000078805CDD6265
000078805cdd9692  sub rsp, 0x08
000078805cdd9696  push rax
000078805cdd9697  push rcx
000078805cdd9698  push rdx
000078805cdd9699  push rdi
000078805cdd969a  push rsi
000078805cdd969b  push r8
000078805cdd969d  push r9
000078805cdd969f  push r10
000078805cdd96a1  push r11
000078805cdd96a3  sub rsp, 0xF0
000078805cdd96aa  vmovaps [rsp], xmm0
000078805cdd96af  vmovaps [rsp+0x10], xmm1
000078805cdd96b5  vmovaps [rsp+0x20], xmm2
000078805cdd96bb  vmovaps [rsp+0x30], xmm3
000078805cdd96c1  vmovaps [rsp+0x40], xmm5
000078805cdd96c7  vmovaps [rsp+0x50], xmm6
000078805cdd96cd  vmovaps [rsp+0x60], xmm7
000078805cdd96d3  vmovaps [rsp+0x70], xmm8
000078805cdd96d9  vmovaps [rsp+0x80], xmm9
000078805cdd96e2  vmovaps [rsp+0x90], xmm10
000078805cdd96eb  vmovaps [rsp+0xA0], xmm11
000078805cdd96f4  vmovaps [rsp+0xB0], xmm12
000078805cdd96fd  vmovaps [rsp+0xC0], xmm13
000078805cdd9706  vmovaps [rsp+0xD0], xmm14
000078805cdd970f  vmovaps [rsp+0xE0], xmm15
000078805cdd9718  sub rsp, 0x30
000078805cdd971c  movaps [rsp], xmm4
000078805cdd9720  movaps [rsp+0x10], xmm13
000078805cdd9726  movaps [rsp+0x20], xmm8
000078805cdd972c  lea rdi, [rsp]
000078805cdd9730  mov esi, 0x00
000078805cdd9735  mov rax, 0x5771AD6EA530
000078805cdd973f  call rax
000078805cdd9741  movaps xmm4, [rsp]
000078805cdd9745  add rsp, 0x30
000078805cdd9749  vmovaps xmm0, [rsp]
000078805cdd974e  vmovaps xmm1, [rsp+0x10]
000078805cdd9754  vmovaps xmm2, [rsp+0x20]
000078805cdd975a  vmovaps xmm3, [rsp+0x30]
000078805cdd9760  vmovaps xmm5, [rsp+0x40]
000078805cdd9766  vmovaps xmm6, [rsp+0x50]
000078805cdd976c  vmovaps xmm7, [rsp+0x60]
000078805cdd9772  vmovaps xmm8, [rsp+0x70]
000078805cdd9778  vmovaps xmm9, [rsp+0x80]
000078805cdd9781  vmovaps xmm10, [rsp+0x90]
000078805cdd978a  vmovaps xmm11, [rsp+0xA0]
000078805cdd9793  vmovaps xmm12, [rsp+0xB0]
000078805cdd979c  vmovaps xmm13, [rsp+0xC0]
000078805cdd97a5  vmovaps xmm14, [rsp+0xD0]
000078805cdd97ae  vmovaps xmm15, [rsp+0xE0]
000078805cdd97b7  add rsp, 0xF0
000078805cdd97be  pop r11
000078805cdd97c0  pop r10
000078805cdd97c2  pop r9
000078805cdd97c4  pop r8
000078805cdd97c6  pop rsi
000078805cdd97c7  pop rdi
000078805cdd97c8  pop rdx
000078805cdd97c9  pop rcx
000078805cdd97ca  pop rax
000078805cdd97cb  add rsp, 0x08
000078805cdd97cf  jmp 0x000078805CDD628A
000078805cdd97d4  sub rsp, 0x08
000078805cdd97d8  push rax
000078805cdd97d9  push rcx
000078805cdd97da  push rdx
000078805cdd97db  push rdi
000078805cdd97dc  push rsi
000078805cdd97dd  push r8
000078805cdd97df  push r9
000078805cdd97e1  push r10
000078805cdd97e3  push r11
000078805cdd97e5  sub rsp, 0xF0
000078805cdd97ec  vmovaps [rsp], xmm0
000078805cdd97f1  vmovaps [rsp+0x10], xmm1
000078805cdd97f7  vmovaps [rsp+0x20], xmm2
000078805cdd97fd  vmovaps [rsp+0x30], xmm3
000078805cdd9803  vmovaps [rsp+0x40], xmm4
000078805cdd9809  vmovaps [rsp+0x50], xmm5
000078805cdd980f  vmovaps [rsp+0x60], xmm6
000078805cdd9815  vmovaps [rsp+0x70], xmm7
000078805cdd981b  vmovaps [rsp+0x80], xmm8
000078805cdd9824  vmovaps [rsp+0x90], xmm9
000078805cdd982d  vmovaps [rsp+0xA0], xmm10
000078805cdd9836  vmovaps [rsp+0xB0], xmm11
000078805cdd983f  vmovaps [rsp+0xC0], xmm12
000078805cdd9848  vmovaps [rsp+0xD0], xmm14
000078805cdd9851  vmovaps [rsp+0xE0], xmm15
000078805cdd985a  sub rsp, 0x30
000078805cdd985e  movaps [rsp], xmm13
000078805cdd9863  movaps [rsp+0x10], xmm15
000078805cdd9869  movaps [rsp+0x20], xmm9
000078805cdd986f  lea rdi, [rsp]
000078805cdd9873  mov esi, 0x00
000078805cdd9878  mov rax, 0x5771AD6EA530
000078805cdd9882  call rax
000078805cdd9884  movaps xmm13, [rsp]
000078805cdd9889  add rsp, 0x30
000078805cdd988d  vmovaps xmm0, [rsp]
000078805cdd9892  vmovaps xmm1, [rsp+0x10]
000078805cdd9898  vmovaps xmm2, [rsp+0x20]
000078805cdd989e  vmovaps xmm3, [rsp+0x30]
000078805cdd98a4  vmovaps xmm4, [rsp+0x40]
000078805cdd98aa  vmovaps xmm5, [rsp+0x50]
000078805cdd98b0  vmovaps xmm6, [rsp+0x60]
000078805cdd98b6  vmovaps xmm7, [rsp+0x70]
000078805cdd98bc  vmovaps xmm8, [rsp+0x80]
000078805cdd98c5  vmovaps xmm9, [rsp+0x90]
000078805cdd98ce  vmovaps xmm10, [rsp+0xA0]
000078805cdd98d7  vmovaps xmm11, [rsp+0xB0]
000078805cdd98e0  vmovaps xmm12, [rsp+0xC0]
000078805cdd98e9  vmovaps xmm14, [rsp+0xD0]
000078805cdd98f2  vmovaps xmm15, [rsp+0xE0]
000078805cdd98fb  add rsp, 0xF0
000078805cdd9902  pop r11
000078805cdd9904  pop r10
000078805cdd9906  pop r9
000078805cdd9908  pop r8
000078805cdd990a  pop rsi
000078805cdd990b  pop rdi
000078805cdd990c  pop rdx
000078805cdd990d  pop rcx
000078805cdd990e  pop rax
000078805cdd990f  add rsp, 0x08
000078805cdd9913  jmp 0x000078805CDD62A5
000078805cdd9918  sub rsp, 0x08
000078805cdd991c  push rax
000078805cdd991d  push rcx
000078805cdd991e  push rdx
000078805cdd991f  push rdi
000078805cdd9920  push rsi
000078805cdd9921  push r8
000078805cdd9923  push r9
000078805cdd9925  push r10
000078805cdd9927  push r11
000078805cdd9929  sub rsp, 0xF0
000078805cdd9930  vmovaps [rsp], xmm0
000078805cdd9935  vmovaps [rsp+0x10], xmm1
000078805cdd993b  vmovaps [rsp+0x20], xmm2
000078805cdd9941  vmovaps [rsp+0x30], xmm3
000078805cdd9947  vmovaps [rsp+0x40], xmm4
000078805cdd994d  vmovaps [rsp+0x50], xmm5
000078805cdd9953  vmovaps [rsp+0x60], xmm6
000078805cdd9959  vmovaps [rsp+0x70], xmm7
000078805cdd995f  vmovaps [rsp+0x80], xmm8
000078805cdd9968  vmovaps [rsp+0x90], xmm9
000078805cdd9971  vmovaps [rsp+0xA0], xmm10
000078805cdd997a  vmovaps [rsp+0xB0], xmm11
000078805cdd9983  vmovaps [rsp+0xC0], xmm12
000078805cdd998c  vmovaps [rsp+0xD0], xmm13
000078805cdd9995  vmovaps [rsp+0xE0], xmm14
000078805cdd999e  sub rsp, 0x30
000078805cdd99a2  movaps [rsp], xmm15
000078805cdd99a7  movaps [rsp+0x10], xmm1
000078805cdd99ac  movaps [rsp+0x20], xmm5
000078805cdd99b1  lea rdi, [rsp]
000078805cdd99b5  mov esi, 0x00
000078805cdd99ba  mov rax, 0x5771AD6EA530
000078805cdd99c4  call rax
000078805cdd99c6  movaps xmm15, [rsp]
000078805cdd99cb  add rsp, 0x30
000078805cdd99cf  vmovaps xmm0, [rsp]
000078805cdd99d4  vmovaps xmm1, [rsp+0x10]
000078805cdd99da  vmovaps xmm2, [rsp+0x20]
000078805cdd99e0  vmovaps xmm3, [rsp+0x30]
000078805cdd99e6  vmovaps xmm4, [rsp+0x40]
000078805cdd99ec  vmovaps xmm5, [rsp+0x50]
000078805cdd99f2  vmovaps xmm6, [rsp+0x60]
000078805cdd99f8  vmovaps xmm7, [rsp+0x70]
000078805cdd99fe  vmovaps xmm8, [rsp+0x80]
000078805cdd9a07  vmovaps xmm9, [rsp+0x90]
000078805cdd9a10  vmovaps xmm10, [rsp+0xA0]
000078805cdd9a19  vmovaps xmm11, [rsp+0xB0]
000078805cdd9a22  vmovaps xmm12, [rsp+0xC0]
000078805cdd9a2b  vmovaps xmm13, [rsp+0xD0]
000078805cdd9a34  vmovaps xmm14, [rsp+0xE0]
000078805cdd9a3d  add rsp, 0xF0
000078805cdd9a44  pop r11
000078805cdd9a46  pop r10
000078805cdd9a48  pop r9
000078805cdd9a4a  pop r8
000078805cdd9a4c  pop rsi
000078805cdd9a4d  pop rdi
000078805cdd9a4e  pop rdx
000078805cdd9a4f  pop rcx
000078805cdd9a50  pop rax
000078805cdd9a51  add rsp, 0x08
000078805cdd9a55  jmp 0x000078805CDD62C0
000078805cdd9a5a  call 0x000078805CCD64F0
000078805cdd9a5f  jmp 0x000078805CDD631B
000078805cdd9a64  sub rsp, 0x08
000078805cdd9a68  push rax
000078805cdd9a69  push rcx
000078805cdd9a6a  push rdx
000078805cdd9a6b  push rdi
000078805cdd9a6c  push rsi
000078805cdd9a6d  push r8
000078805cdd9a6f  push r9
000078805cdd9a71  push r10
000078805cdd9a73  push r11
000078805cdd9a75  sub rsp, 0xF0
000078805cdd9a7c  vmovaps [rsp], xmm0
000078805cdd9a81  vmovaps [rsp+0x10], xmm1
000078805cdd9a87  vmovaps [rsp+0x20], xmm2
000078805cdd9a8d  vmovaps [rsp+0x30], xmm3
000078805cdd9a93  vmovaps [rsp+0x40], xmm4
000078805cdd9a99  vmovaps [rsp+0x50], xmm5
000078805cdd9a9f  vmovaps [rsp+0x60], xmm6
000078805cdd9aa5  vmovaps [rsp+0x70], xmm7
000078805cdd9aab  vmovaps [rsp+0x80], xmm8
000078805cdd9ab4  vmovaps [rsp+0x90], xmm10
000078805cdd9abd  vmovaps [rsp+0xA0], xmm11
000078805cdd9ac6  vmovaps [rsp+0xB0], xmm12
000078805cdd9acf  vmovaps [rsp+0xC0], xmm13
000078805cdd9ad8  vmovaps [rsp+0xD0], xmm14
000078805cdd9ae1  vmovaps [rsp+0xE0], xmm15
000078805cdd9aea  sub rsp, 0x30
000078805cdd9aee  movaps [rsp], xmm9
000078805cdd9af3  movaps [rsp+0x10], xmm8
000078805cdd9af9  movaps [rsp+0x20], xmm11
000078805cdd9aff  lea rdi, [rsp]
000078805cdd9b03  mov esi, 0x00
000078805cdd9b08  mov rax, 0x5771AD6EA530
000078805cdd9b12  call rax
000078805cdd9b14  movaps xmm9, [rsp]
000078805cdd9b19  add rsp, 0x30
000078805cdd9b1d  vmovaps xmm0, [rsp]
000078805cdd9b22  vmovaps xmm1, [rsp+0x10]
000078805cdd9b28  vmovaps xmm2, [rsp+0x20]
000078805cdd9b2e  vmovaps xmm3, [rsp+0x30]
000078805cdd9b34  vmovaps xmm4, [rsp+0x40]
000078805cdd9b3a  vmovaps xmm5, [rsp+0x50]
000078805cdd9b40  vmovaps xmm6, [rsp+0x60]
000078805cdd9b46  vmovaps xmm7, [rsp+0x70]
000078805cdd9b4c  vmovaps xmm8, [rsp+0x80]
000078805cdd9b55  vmovaps xmm10, [rsp+0x90]
000078805cdd9b5e  vmovaps xmm11, [rsp+0xA0]
000078805cdd9b67  vmovaps xmm12, [rsp+0xB0]
000078805cdd9b70  vmovaps xmm13, [rsp+0xC0]
000078805cdd9b79  vmovaps xmm14, [rsp+0xD0]
000078805cdd9b82  vmovaps xmm15, [rsp+0xE0]
000078805cdd9b8b  add rsp, 0xF0
000078805cdd9b92  pop r11
000078805cdd9b94  pop r10
000078805cdd9b96  pop r9
000078805cdd9b98  pop r8
000078805cdd9b9a  pop rsi
000078805cdd9b9b  pop rdi
000078805cdd9b9c  pop rdx
000078805cdd9b9d  pop rcx
000078805cdd9b9e  pop rax
000078805cdd9b9f  add rsp, 0x08
000078805cdd9ba3  jmp 0x000078805CDD6352
000078805cdd9ba8  sub rsp, 0x08
000078805cdd9bac  push rax
000078805cdd9bad  push rcx
000078805cdd9bae  push rdx
000078805cdd9baf  push rdi
000078805cdd9bb0  push rsi
000078805cdd9bb1  push r8
000078805cdd9bb3  push r9
000078805cdd9bb5  push r10
000078805cdd9bb7  push r11
000078805cdd9bb9  sub rsp, 0xF0
000078805cdd9bc0  vmovaps [rsp], xmm0
000078805cdd9bc5  vmovaps [rsp+0x10], xmm1
000078805cdd9bcb  vmovaps [rsp+0x20], xmm2
000078805cdd9bd1  vmovaps [rsp+0x30], xmm3
000078805cdd9bd7  vmovaps [rsp+0x40], xmm4
000078805cdd9bdd  vmovaps [rsp+0x50], xmm5
000078805cdd9be3  vmovaps [rsp+0x60], xmm6
000078805cdd9be9  vmovaps [rsp+0x70], xmm7
000078805cdd9bef  vmovaps [rsp+0x80], xmm8
000078805cdd9bf8  vmovaps [rsp+0x90], xmm9
000078805cdd9c01  vmovaps [rsp+0xA0], xmm10
000078805cdd9c0a  vmovaps [rsp+0xB0], xmm12
000078805cdd9c13  vmovaps [rsp+0xC0], xmm13
000078805cdd9c1c  vmovaps [rsp+0xD0], xmm14
000078805cdd9c25  vmovaps [rsp+0xE0], xmm15
000078805cdd9c2e  sub rsp, 0x30
000078805cdd9c32  movaps [rsp], xmm11
000078805cdd9c37  movaps [rsp+0x10], xmm10
000078805cdd9c3d  movaps [rsp+0x20], xmm6
000078805cdd9c42  lea rdi, [rsp]
000078805cdd9c46  mov esi, 0x00
000078805cdd9c4b  mov rax, 0x5771AD6EA530
000078805cdd9c55  call rax
000078805cdd9c57  movaps xmm11, [rsp]
000078805cdd9c5c  add rsp, 0x30
000078805cdd9c60  vmovaps xmm0, [rsp]
000078805cdd9c65  vmovaps xmm1, [rsp+0x10]
000078805cdd9c6b  vmovaps xmm2, [rsp+0x20]
000078805cdd9c71  vmovaps xmm3, [rsp+0x30]
000078805cdd9c77  vmovaps xmm4, [rsp+0x40]
000078805cdd9c7d  vmovaps xmm5, [rsp+0x50]
000078805cdd9c83  vmovaps xmm6, [rsp+0x60]
000078805cdd9c89  vmovaps xmm7, [rsp+0x70]
000078805cdd9c8f  vmovaps xmm8, [rsp+0x80]
000078805cdd9c98  vmovaps xmm9, [rsp+0x90]
000078805cdd9ca1  vmovaps xmm10, [rsp+0xA0]
000078805cdd9caa  vmovaps xmm12, [rsp+0xB0]
000078805cdd9cb3  vmovaps xmm13, [rsp+0xC0]
000078805cdd9cbc  vmovaps xmm14, [rsp+0xD0]
000078805cdd9cc5  vmovaps xmm15, [rsp+0xE0]
000078805cdd9cce  add rsp, 0xF0
000078805cdd9cd5  pop r11
000078805cdd9cd7  pop r10
000078805cdd9cd9  pop r9
000078805cdd9cdb  pop r8
000078805cdd9cdd  pop rsi
000078805cdd9cde  pop rdi
000078805cdd9cdf  pop rdx
000078805cdd9ce0  pop rcx
000078805cdd9ce1  pop rax
000078805cdd9ce2  add rsp, 0x08
000078805cdd9ce6  jmp 0x000078805CDD636D
000078805cdd9ceb  sub rsp, 0x08
000078805cdd9cef  push rax
000078805cdd9cf0  push rcx
000078805cdd9cf1  push rdx
000078805cdd9cf2  push rdi
000078805cdd9cf3  push rsi
000078805cdd9cf4  push r8
000078805cdd9cf6  push r9
000078805cdd9cf8  push r10
000078805cdd9cfa  push r11
000078805cdd9cfc  sub rsp, 0xF0
000078805cdd9d03  vmovaps [rsp], xmm0
000078805cdd9d08  vmovaps [rsp+0x10], xmm1
000078805cdd9d0e  vmovaps [rsp+0x20], xmm2
000078805cdd9d14  vmovaps [rsp+0x30], xmm3
000078805cdd9d1a  vmovaps [rsp+0x40], xmm4
000078805cdd9d20  vmovaps [rsp+0x50], xmm5
000078805cdd9d26  vmovaps [rsp+0x60], xmm6
000078805cdd9d2c  vmovaps [rsp+0x70], xmm7
000078805cdd9d32  vmovaps [rsp+0x80], xmm8
000078805cdd9d3b  vmovaps [rsp+0x90], xmm9
000078805cdd9d44  vmovaps [rsp+0xA0], xmm11
000078805cdd9d4d  vmovaps [rsp+0xB0], xmm12
000078805cdd9d56  vmovaps [rsp+0xC0], xmm13
000078805cdd9d5f  vmovaps [rsp+0xD0], xmm14
000078805cdd9d68  vmovaps [rsp+0xE0], xmm15
000078805cdd9d71  sub rsp, 0x30
000078805cdd9d75  movaps [rsp], xmm10
000078805cdd9d7a  movaps [rsp+0x10], xmm14
000078805cdd9d80  movaps [rsp+0x20], xmm4
000078805cdd9d85  lea rdi, [rsp]
000078805cdd9d89  mov esi, 0x00
000078805cdd9d8e  mov rax, 0x5771AD6EA530
000078805cdd9d98  call rax
000078805cdd9d9a  movaps xmm10, [rsp]
000078805cdd9d9f  add rsp, 0x30
000078805cdd9da3  vmovaps xmm0, [rsp]
000078805cdd9da8  vmovaps xmm1, [rsp+0x10]
000078805cdd9dae  vmovaps xmm2, [rsp+0x20]
000078805cdd9db4  vmovaps xmm3, [rsp+0x30]
000078805cdd9dba  vmovaps xmm4, [rsp+0x40]
000078805cdd9dc0  vmovaps xmm5, [rsp+0x50]
000078805cdd9dc6  vmovaps xmm6, [rsp+0x60]
000078805cdd9dcc  vmovaps xmm7, [rsp+0x70]
000078805cdd9dd2  vmovaps xmm8, [rsp+0x80]
000078805cdd9ddb  vmovaps xmm9, [rsp+0x90]
000078805cdd9de4  vmovaps xmm11, [rsp+0xA0]
000078805cdd9ded  vmovaps xmm12, [rsp+0xB0]
000078805cdd9df6  vmovaps xmm13, [rsp+0xC0]
000078805cdd9dff  vmovaps xmm14, [rsp+0xD0]
000078805cdd9e08  vmovaps xmm15, [rsp+0xE0]
000078805cdd9e11  add rsp, 0xF0
000078805cdd9e18  pop r11
000078805cdd9e1a  pop r10
000078805cdd9e1c  pop r9
000078805cdd9e1e  pop r8
000078805cdd9e20  pop rsi
000078805cdd9e21  pop rdi
000078805cdd9e22  pop rdx
000078805cdd9e23  pop rcx
000078805cdd9e24  pop rax
000078805cdd9e25  add rsp, 0x08
000078805cdd9e29  jmp 0x000078805CDD6388
000078805cdd9e2e  sub rsp, 0x08
000078805cdd9e32  push rax
000078805cdd9e33  push rcx
000078805cdd9e34  push rdx
000078805cdd9e35  push rdi
000078805cdd9e36  push rsi
000078805cdd9e37  push r8
000078805cdd9e39  push r9
000078805cdd9e3b  push r10
000078805cdd9e3d  push r11
000078805cdd9e3f  sub rsp, 0xF0
000078805cdd9e46  vmovaps [rsp], xmm0
000078805cdd9e4b  vmovaps [rsp+0x10], xmm1
000078805cdd9e51  vmovaps [rsp+0x20], xmm2
000078805cdd9e57  vmovaps [rsp+0x30], xmm3
000078805cdd9e5d  vmovaps [rsp+0x40], xmm4
000078805cdd9e63  vmovaps [rsp+0x50], xmm5
000078805cdd9e69  vmovaps [rsp+0x60], xmm6
000078805cdd9e6f  vmovaps [rsp+0x70], xmm7
000078805cdd9e75  vmovaps [rsp+0x80], xmm9
000078805cdd9e7e  vmovaps [rsp+0x90], xmm10
000078805cdd9e87  vmovaps [rsp+0xA0], xmm11
000078805cdd9e90  vmovaps [rsp+0xB0], xmm12
000078805cdd9e99  vmovaps [rsp+0xC0], xmm13
000078805cdd9ea2  vmovaps [rsp+0xD0], xmm14
000078805cdd9eab  vmovaps [rsp+0xE0], xmm15
000078805cdd9eb4  sub rsp, 0x30
000078805cdd9eb8  movaps [rsp], xmm8
000078805cdd9ebd  movaps [rsp+0x10], xmm1
000078805cdd9ec2  movaps [rsp+0x20], xmm14
000078805cdd9ec8  lea rdi, [rsp]
000078805cdd9ecc  mov esi, 0x00
000078805cdd9ed1  mov rax, 0x5771AD6EA530
000078805cdd9edb  call rax
000078805cdd9edd  movaps xmm8, [rsp]
000078805cdd9ee2  add rsp, 0x30
000078805cdd9ee6  vmovaps xmm0, [rsp]
000078805cdd9eeb  vmovaps xmm1, [rsp+0x10]
000078805cdd9ef1  vmovaps xmm2, [rsp+0x20]
000078805cdd9ef7  vmovaps xmm3, [rsp+0x30]
000078805cdd9efd  vmovaps xmm4, [rsp+0x40]
000078805cdd9f03  vmovaps xmm5, [rsp+0x50]
000078805cdd9f09  vmovaps xmm6, [rsp+0x60]
000078805cdd9f0f  vmovaps xmm7, [rsp+0x70]
000078805cdd9f15  vmovaps xmm9, [rsp+0x80]
000078805cdd9f1e  vmovaps xmm10, [rsp+0x90]
000078805cdd9f27  vmovaps xmm11, [rsp+0xA0]
000078805cdd9f30  vmovaps xmm12, [rsp+0xB0]
000078805cdd9f39  vmovaps xmm13, [rsp+0xC0]
000078805cdd9f42  vmovaps xmm14, [rsp+0xD0]
000078805cdd9f4b  vmovaps xmm15, [rsp+0xE0]
000078805cdd9f54  add rsp, 0xF0
000078805cdd9f5b  pop r11
000078805cdd9f5d  pop r10
000078805cdd9f5f  pop r9
000078805cdd9f61  pop r8
000078805cdd9f63  pop rsi
000078805cdd9f64  pop rdi
000078805cdd9f65  pop rdx
000078805cdd9f66  pop rcx
000078805cdd9f67  pop rax
000078805cdd9f68  add rsp, 0x08
000078805cdd9f6c  jmp 0x000078805CDD63AE
000078805cdd9f71  sub rsp, 0x08
000078805cdd9f75  push rax
000078805cdd9f76  push rcx
000078805cdd9f77  push rdx
000078805cdd9f78  push rdi
000078805cdd9f79  push rsi
000078805cdd9f7a  push r8
000078805cdd9f7c  push r9
000078805cdd9f7e  push r10
000078805cdd9f80  push r11
000078805cdd9f82  sub rsp, 0xF0
000078805cdd9f89  vmovaps [rsp], xmm0
000078805cdd9f8e  vmovaps [rsp+0x10], xmm1
000078805cdd9f94  vmovaps [rsp+0x20], xmm2
000078805cdd9f9a  vmovaps [rsp+0x30], xmm3
000078805cdd9fa0  vmovaps [rsp+0x40], xmm4
000078805cdd9fa6  vmovaps [rsp+0x50], xmm5
000078805cdd9fac  vmovaps [rsp+0x60], xmm7
000078805cdd9fb2  vmovaps [rsp+0x70], xmm8
000078805cdd9fb8  vmovaps [rsp+0x80], xmm9
000078805cdd9fc1  vmovaps [rsp+0x90], xmm10
000078805cdd9fca  vmovaps [rsp+0xA0], xmm11
000078805cdd9fd3  vmovaps [rsp+0xB0], xmm12
000078805cdd9fdc  vmovaps [rsp+0xC0], xmm13
000078805cdd9fe5  vmovaps [rsp+0xD0], xmm14
000078805cdd9fee  vmovaps [rsp+0xE0], xmm15
000078805cdd9ff7  sub rsp, 0x30
000078805cdd9ffb  movaps [rsp], xmm6
000078805cdd9fff  movaps [rsp+0x10], xmm1
000078805cdda004  movaps [rsp+0x20], xmm14
000078805cdda00a  lea rdi, [rsp]
000078805cdda00e  mov esi, 0x00
000078805cdda013  mov rax, 0x5771AD6EA530
000078805cdda01d  call rax
000078805cdda01f  movaps xmm6, [rsp]
000078805cdda023  add rsp, 0x30
000078805cdda027  vmovaps xmm0, [rsp]
000078805cdda02c  vmovaps xmm1, [rsp+0x10]
000078805cdda032  vmovaps xmm2, [rsp+0x20]
000078805cdda038  vmovaps xmm3, [rsp+0x30]
000078805cdda03e  vmovaps xmm4, [rsp+0x40]
000078805cdda044  vmovaps xmm5, [rsp+0x50]
000078805cdda04a  vmovaps xmm7, [rsp+0x60]
000078805cdda050  vmovaps xmm8, [rsp+0x70]
000078805cdda056  vmovaps xmm9, [rsp+0x80]
000078805cdda05f  vmovaps xmm10, [rsp+0x90]
000078805cdda068  vmovaps xmm11, [rsp+0xA0]
000078805cdda071  vmovaps xmm12, [rsp+0xB0]
000078805cdda07a  vmovaps xmm13, [rsp+0xC0]
000078805cdda083  vmovaps xmm14, [rsp+0xD0]
000078805cdda08c  vmovaps xmm15, [rsp+0xE0]
000078805cdda095  add rsp, 0xF0
000078805cdda09c  pop r11
000078805cdda09e  pop r10
000078805cdda0a0  pop r9
000078805cdda0a2  pop r8
000078805cdda0a4  pop rsi
000078805cdda0a5  pop rdi
000078805cdda0a6  pop rdx
000078805cdda0a7  pop rcx
000078805cdda0a8  pop rax
000078805cdda0a9  add rsp, 0x08
000078805cdda0ad  jmp 0x000078805CDD63DA
000078805cdda0b2  sub rsp, 0x08
000078805cdda0b6  push rax
000078805cdda0b7  push rcx
000078805cdda0b8  push rdx
000078805cdda0b9  push rdi
000078805cdda0ba  push rsi
000078805cdda0bb  push r8
000078805cdda0bd  push r9
000078805cdda0bf  push r10
000078805cdda0c1  push r11
000078805cdda0c3  sub rsp, 0xF0
000078805cdda0ca  vmovaps [rsp], xmm0
000078805cdda0cf  vmovaps [rsp+0x10], xmm1
000078805cdda0d5  vmovaps [rsp+0x20], xmm2
000078805cdda0db  vmovaps [rsp+0x30], xmm3
000078805cdda0e1  vmovaps [rsp+0x40], xmm4
000078805cdda0e7  vmovaps [rsp+0x50], xmm5
000078805cdda0ed  vmovaps [rsp+0x60], xmm6
000078805cdda0f3  vmovaps [rsp+0x70], xmm7
000078805cdda0f9  vmovaps [rsp+0x80], xmm8
000078805cdda102  vmovaps [rsp+0x90], xmm9
000078805cdda10b  vmovaps [rsp+0xA0], xmm10
000078805cdda114  vmovaps [rsp+0xB0], xmm11
000078805cdda11d  vmovaps [rsp+0xC0], xmm12
000078805cdda126  vmovaps [rsp+0xD0], xmm13
000078805cdda12f  vmovaps [rsp+0xE0], xmm15
000078805cdda138  sub rsp, 0x30
000078805cdda13c  movaps [rsp], xmm14
000078805cdda141  movaps [rsp+0x10], xmm12
000078805cdda147  movaps [rsp+0x20], xmm1
000078805cdda14c  lea rdi, [rsp]
000078805cdda150  mov esi, 0x00
000078805cdda155  mov rax, 0x5771AD6EA530
000078805cdda15f  call rax
000078805cdda161  movaps xmm14, [rsp]
000078805cdda166  add rsp, 0x30
000078805cdda16a  vmovaps xmm0, [rsp]
000078805cdda16f  vmovaps xmm1, [rsp+0x10]
000078805cdda175  vmovaps xmm2, [rsp+0x20]
000078805cdda17b  vmovaps xmm3, [rsp+0x30]
000078805cdda181  vmovaps xmm4, [rsp+0x40]
000078805cdda187  vmovaps xmm5, [rsp+0x50]
000078805cdda18d  vmovaps xmm6, [rsp+0x60]
000078805cdda193  vmovaps xmm7, [rsp+0x70]
000078805cdda199  vmovaps xmm8, [rsp+0x80]
000078805cdda1a2  vmovaps xmm9, [rsp+0x90]
000078805cdda1ab  vmovaps xmm10, [rsp+0xA0]
000078805cdda1b4  vmovaps xmm11, [rsp+0xB0]
000078805cdda1bd  vmovaps xmm12, [rsp+0xC0]
000078805cdda1c6  vmovaps xmm13, [rsp+0xD0]
000078805cdda1cf  vmovaps xmm15, [rsp+0xE0]
000078805cdda1d8  add rsp, 0xF0
000078805cdda1df  pop r11
000078805cdda1e1  pop r10
000078805cdda1e3  pop r9
000078805cdda1e5  pop r8
000078805cdda1e7  pop rsi
000078805cdda1e8  pop rdi
000078805cdda1e9  pop rdx
000078805cdda1ea  pop rcx
000078805cdda1eb  pop rax
000078805cdda1ec  add rsp, 0x08
000078805cdda1f0  jmp 0x000078805CDD6400
000078805cdda1f5  sub rsp, 0x08
000078805cdda1f9  push rax
000078805cdda1fa  push rcx
000078805cdda1fb  push rdx
000078805cdda1fc  push rdi
000078805cdda1fd  push rsi
000078805cdda1fe  push r8
000078805cdda200  push r9
000078805cdda202  push r10
000078805cdda204  push r11
000078805cdda206  sub rsp, 0xF0
000078805cdda20d  vmovaps [rsp], xmm0
000078805cdda212  vmovaps [rsp+0x10], xmm2
000078805cdda218  vmovaps [rsp+0x20], xmm3
000078805cdda21e  vmovaps [rsp+0x30], xmm4
000078805cdda224  vmovaps [rsp+0x40], xmm5
000078805cdda22a  vmovaps [rsp+0x50], xmm6
000078805cdda230  vmovaps [rsp+0x60], xmm7
000078805cdda236  vmovaps [rsp+0x70], xmm8
000078805cdda23c  vmovaps [rsp+0x80], xmm9
000078805cdda245  vmovaps [rsp+0x90], xmm10
000078805cdda24e  vmovaps [rsp+0xA0], xmm11
000078805cdda257  vmovaps [rsp+0xB0], xmm12
000078805cdda260  vmovaps [rsp+0xC0], xmm13
000078805cdda269  vmovaps [rsp+0xD0], xmm14
000078805cdda272  vmovaps [rsp+0xE0], xmm15
000078805cdda27b  sub rsp, 0x30
000078805cdda27f  movaps [rsp], xmm1
000078805cdda283  movaps [rsp+0x10], xmm13
000078805cdda289  movaps [rsp+0x20], xmm9
000078805cdda28f  lea rdi, [rsp]
000078805cdda293  mov esi, 0x00
000078805cdda298  mov rax, 0x5771AD6EA530
000078805cdda2a2  call rax
000078805cdda2a4  movaps xmm1, [rsp]
000078805cdda2a8  add rsp, 0x30
000078805cdda2ac  vmovaps xmm0, [rsp]
000078805cdda2b1  vmovaps xmm2, [rsp+0x10]
000078805cdda2b7  vmovaps xmm3, [rsp+0x20]
000078805cdda2bd  vmovaps xmm4, [rsp+0x30]
000078805cdda2c3  vmovaps xmm5, [rsp+0x40]
000078805cdda2c9  vmovaps xmm6, [rsp+0x50]
000078805cdda2cf  vmovaps xmm7, [rsp+0x60]
000078805cdda2d5  vmovaps xmm8, [rsp+0x70]
000078805cdda2db  vmovaps xmm9, [rsp+0x80]
000078805cdda2e4  vmovaps xmm10, [rsp+0x90]
000078805cdda2ed  vmovaps xmm11, [rsp+0xA0]
000078805cdda2f6  vmovaps xmm12, [rsp+0xB0]
000078805cdda2ff  vmovaps xmm13, [rsp+0xC0]
000078805cdda308  vmovaps xmm14, [rsp+0xD0]
000078805cdda311  vmovaps xmm15, [rsp+0xE0]
000078805cdda31a  add rsp, 0xF0
000078805cdda321  pop r11
000078805cdda323  pop r10
000078805cdda325  pop r9
000078805cdda327  pop r8
000078805cdda329  pop rsi
000078805cdda32a  pop rdi
000078805cdda32b  pop rdx
000078805cdda32c  pop rcx
000078805cdda32d  pop rax
000078805cdda32e  add rsp, 0x08
000078805cdda332  jmp 0x000078805CDD641A
000078805cdda337  sub rsp, 0x08
000078805cdda33b  push rax
000078805cdda33c  push rcx
000078805cdda33d  push rdx
000078805cdda33e  push rdi
000078805cdda33f  push rsi
000078805cdda340  push r8
000078805cdda342  push r9
000078805cdda344  push r10
000078805cdda346  push r11
000078805cdda348  sub rsp, 0xF0
000078805cdda34f  vmovaps [rsp], xmm0
000078805cdda354  vmovaps [rsp+0x10], xmm1
000078805cdda35a  vmovaps [rsp+0x20], xmm2
000078805cdda360  vmovaps [rsp+0x30], xmm3
000078805cdda366  vmovaps [rsp+0x40], xmm4
000078805cdda36c  vmovaps [rsp+0x50], xmm5
000078805cdda372  vmovaps [rsp+0x60], xmm6
000078805cdda378  vmovaps [rsp+0x70], xmm7
000078805cdda37e  vmovaps [rsp+0x80], xmm8
000078805cdda387  vmovaps [rsp+0x90], xmm9
000078805cdda390  vmovaps [rsp+0xA0], xmm10
000078805cdda399  vmovaps [rsp+0xB0], xmm11
000078805cdda3a2  vmovaps [rsp+0xC0], xmm13
000078805cdda3ab  vmovaps [rsp+0xD0], xmm14
000078805cdda3b4  vmovaps [rsp+0xE0], xmm15
000078805cdda3bd  sub rsp, 0x30
000078805cdda3c1  movaps [rsp], xmm12
000078805cdda3c6  movaps [rsp+0x10], xmm7
000078805cdda3cb  movaps [rsp+0x20], xmm13
000078805cdda3d1  lea rdi, [rsp]
000078805cdda3d5  mov esi, 0x00
000078805cdda3da  mov rax, 0x5771AD6EA530
000078805cdda3e4  call rax
000078805cdda3e6  movaps xmm12, [rsp]
000078805cdda3eb  add rsp, 0x30
000078805cdda3ef  vmovaps xmm0, [rsp]
000078805cdda3f4  vmovaps xmm1, [rsp+0x10]
000078805cdda3fa  vmovaps xmm2, [rsp+0x20]
000078805cdda400  vmovaps xmm3, [rsp+0x30]
000078805cdda406  vmovaps xmm4, [rsp+0x40]
000078805cdda40c  vmovaps xmm5, [rsp+0x50]
000078805cdda412  vmovaps xmm6, [rsp+0x60]
000078805cdda418  vmovaps xmm7, [rsp+0x70]
000078805cdda41e  vmovaps xmm8, [rsp+0x80]
000078805cdda427  vmovaps xmm9, [rsp+0x90]
000078805cdda430  vmovaps xmm10, [rsp+0xA0]
000078805cdda439  vmovaps xmm11, [rsp+0xB0]
000078805cdda442  vmovaps xmm13, [rsp+0xC0]
000078805cdda44b  vmovaps xmm14, [rsp+0xD0]
000078805cdda454  vmovaps xmm15, [rsp+0xE0]
000078805cdda45d  add rsp, 0xF0
000078805cdda464  pop r11
000078805cdda466  pop r10
000078805cdda468  pop r9
000078805cdda46a  pop r8
000078805cdda46c  pop rsi
000078805cdda46d  pop rdi
000078805cdda46e  pop rdx
000078805cdda46f  pop rcx
000078805cdda470  pop rax
000078805cdda471  add rsp, 0x08
000078805cdda475  jmp 0x000078805CDD6441
000078805cdda47a  sub rsp, 0x08
000078805cdda47e  push rax
000078805cdda47f  push rcx
000078805cdda480  push rdx
000078805cdda481  push rdi
000078805cdda482  push rsi
000078805cdda483  push r8
000078805cdda485  push r9
000078805cdda487  push r10
000078805cdda489  push r11
000078805cdda48b  sub rsp, 0xF0
000078805cdda492  vmovaps [rsp], xmm0
000078805cdda497  vmovaps [rsp+0x10], xmm1
000078805cdda49d  vmovaps [rsp+0x20], xmm2
000078805cdda4a3  vmovaps [rsp+0x30], xmm3
000078805cdda4a9  vmovaps [rsp+0x40], xmm4
000078805cdda4af  vmovaps [rsp+0x50], xmm5
000078805cdda4b5  vmovaps [rsp+0x60], xmm6
000078805cdda4bb  vmovaps [rsp+0x70], xmm7
000078805cdda4c1  vmovaps [rsp+0x80], xmm8
000078805cdda4ca  vmovaps [rsp+0x90], xmm9
000078805cdda4d3  vmovaps [rsp+0xA0], xmm10
000078805cdda4dc  vmovaps [rsp+0xB0], xmm11
000078805cdda4e5  vmovaps [rsp+0xC0], xmm12
000078805cdda4ee  vmovaps [rsp+0xD0], xmm14
000078805cdda4f7  vmovaps [rsp+0xE0], xmm15
000078805cdda500  sub rsp, 0x30
000078805cdda504  movaps [rsp], xmm13
000078805cdda509  movaps [rsp+0x10], xmm15
000078805cdda50f  movaps [rsp+0x20], xmm8
000078805cdda515  lea rdi, [rsp]
000078805cdda519  mov esi, 0x00
000078805cdda51e  mov rax, 0x5771AD6EA530
000078805cdda528  call rax
000078805cdda52a  movaps xmm13, [rsp]
000078805cdda52f  add rsp, 0x30
000078805cdda533  vmovaps xmm0, [rsp]
000078805cdda538  vmovaps xmm1, [rsp+0x10]
000078805cdda53e  vmovaps xmm2, [rsp+0x20]
000078805cdda544  vmovaps xmm3, [rsp+0x30]
000078805cdda54a  vmovaps xmm4, [rsp+0x40]
000078805cdda550  vmovaps xmm5, [rsp+0x50]
000078805cdda556  vmovaps xmm6, [rsp+0x60]
000078805cdda55c  vmovaps xmm7, [rsp+0x70]
000078805cdda562  vmovaps xmm8, [rsp+0x80]
000078805cdda56b  vmovaps xmm9, [rsp+0x90]
000078805cdda574  vmovaps xmm10, [rsp+0xA0]
000078805cdda57d  vmovaps xmm11, [rsp+0xB0]
000078805cdda586  vmovaps xmm12, [rsp+0xC0]
000078805cdda58f  vmovaps xmm14, [rsp+0xD0]
000078805cdda598  vmovaps xmm15, [rsp+0xE0]
000078805cdda5a1  add rsp, 0xF0
000078805cdda5a8  pop r11
000078805cdda5aa  pop r10
000078805cdda5ac  pop r9
000078805cdda5ae  pop r8
000078805cdda5b0  pop rsi
000078805cdda5b1  pop rdi
000078805cdda5b2  pop rdx
000078805cdda5b3  pop rcx
000078805cdda5b4  pop rax
000078805cdda5b5  add rsp, 0x08
000078805cdda5b9  jmp 0x000078805CDD645C
000078805cdda5be  sub rsp, 0x08
000078805cdda5c2  push rax
000078805cdda5c3  push rcx
000078805cdda5c4  push rdx
000078805cdda5c5  push rdi
000078805cdda5c6  push rsi
000078805cdda5c7  push r8
000078805cdda5c9  push r9
000078805cdda5cb  push r10
000078805cdda5cd  push r11
000078805cdda5cf  sub rsp, 0xF0
000078805cdda5d6  vmovaps [rsp], xmm0
000078805cdda5db  vmovaps [rsp+0x10], xmm1
000078805cdda5e1  vmovaps [rsp+0x20], xmm2
000078805cdda5e7  vmovaps [rsp+0x30], xmm3
000078805cdda5ed  vmovaps [rsp+0x40], xmm4
000078805cdda5f3  vmovaps [rsp+0x50], xmm5
000078805cdda5f9  vmovaps [rsp+0x60], xmm6
000078805cdda5ff  vmovaps [rsp+0x70], xmm7
000078805cdda605  vmovaps [rsp+0x80], xmm9
000078805cdda60e  vmovaps [rsp+0x90], xmm10
000078805cdda617  vmovaps [rsp+0xA0], xmm11
000078805cdda620  vmovaps [rsp+0xB0], xmm12
000078805cdda629  vmovaps [rsp+0xC0], xmm13
000078805cdda632  vmovaps [rsp+0xD0], xmm14
000078805cdda63b  vmovaps [rsp+0xE0], xmm15
000078805cdda644  sub rsp, 0x30
000078805cdda648  movaps [rsp], xmm8
000078805cdda64d  movaps [rsp+0x10], xmm15
000078805cdda653  movaps [rsp+0x20], xmm9
000078805cdda659  lea rdi, [rsp]
000078805cdda65d  mov esi, 0x00
000078805cdda662  mov rax, 0x5771AD6EA530
000078805cdda66c  call rax
000078805cdda66e  movaps xmm8, [rsp]
000078805cdda673  add rsp, 0x30
000078805cdda677  vmovaps xmm0, [rsp]
000078805cdda67c  vmovaps xmm1, [rsp+0x10]
000078805cdda682  vmovaps xmm2, [rsp+0x20]
000078805cdda688  vmovaps xmm3, [rsp+0x30]
000078805cdda68e  vmovaps xmm4, [rsp+0x40]
000078805cdda694  vmovaps xmm5, [rsp+0x50]
000078805cdda69a  vmovaps xmm6, [rsp+0x60]
000078805cdda6a0  vmovaps xmm7, [rsp+0x70]
000078805cdda6a6  vmovaps xmm9, [rsp+0x80]
000078805cdda6af  vmovaps xmm10, [rsp+0x90]
000078805cdda6b8  vmovaps xmm11, [rsp+0xA0]
000078805cdda6c1  vmovaps xmm12, [rsp+0xB0]
000078805cdda6ca  vmovaps xmm13, [rsp+0xC0]
000078805cdda6d3  vmovaps xmm14, [rsp+0xD0]
000078805cdda6dc  vmovaps xmm15, [rsp+0xE0]
000078805cdda6e5  add rsp, 0xF0
000078805cdda6ec  pop r11
000078805cdda6ee  pop r10
000078805cdda6f0  pop r9
000078805cdda6f2  pop r8
000078805cdda6f4  pop rsi
000078805cdda6f5  pop rdi
000078805cdda6f6  pop rdx
000078805cdda6f7  pop rcx
000078805cdda6f8  pop rax
000078805cdda6f9  add rsp, 0x08
000078805cdda6fd  jmp 0x000078805CDD648A
000078805cdda702  sub rsp, 0x08
000078805cdda706  push rax
000078805cdda707  push rcx
000078805cdda708  push rdx
000078805cdda709  push rdi
000078805cdda70a  push rsi
000078805cdda70b  push r8
000078805cdda70d  push r9
000078805cdda70f  push r10
000078805cdda711  push r11
000078805cdda713  sub rsp, 0xF0
000078805cdda71a  vmovaps [rsp], xmm0
000078805cdda71f  vmovaps [rsp+0x10], xmm1
000078805cdda725  vmovaps [rsp+0x20], xmm2
000078805cdda72b  vmovaps [rsp+0x30], xmm3
000078805cdda731  vmovaps [rsp+0x40], xmm4
000078805cdda737  vmovaps [rsp+0x50], xmm5
000078805cdda73d  vmovaps [rsp+0x60], xmm6
000078805cdda743  vmovaps [rsp+0x70], xmm7
000078805cdda749  vmovaps [rsp+0x80], xmm8
000078805cdda752  vmovaps [rsp+0x90], xmm9
000078805cdda75b  vmovaps [rsp+0xA0], xmm10
000078805cdda764  vmovaps [rsp+0xB0], xmm11
000078805cdda76d  vmovaps [rsp+0xC0], xmm12
000078805cdda776  vmovaps [rsp+0xD0], xmm13
000078805cdda77f  vmovaps [rsp+0xE0], xmm14
000078805cdda788  sub rsp, 0x30
000078805cdda78c  movaps [rsp], xmm15
000078805cdda791  movaps [rsp+0x10], xmm11
000078805cdda797  movaps [rsp+0x20], xmm6
000078805cdda79c  lea rdi, [rsp]
000078805cdda7a0  mov esi, 0x00
000078805cdda7a5  mov rax, 0x5771AD6EA530
000078805cdda7af  call rax
000078805cdda7b1  movaps xmm15, [rsp]
000078805cdda7b6  add rsp, 0x30
000078805cdda7ba  vmovaps xmm0, [rsp]
000078805cdda7bf  vmovaps xmm1, [rsp+0x10]
000078805cdda7c5  vmovaps xmm2, [rsp+0x20]
000078805cdda7cb  vmovaps xmm3, [rsp+0x30]
000078805cdda7d1  vmovaps xmm4, [rsp+0x40]
000078805cdda7d7  vmovaps xmm5, [rsp+0x50]
000078805cdda7dd  vmovaps xmm6, [rsp+0x60]
000078805cdda7e3  vmovaps xmm7, [rsp+0x70]
000078805cdda7e9  vmovaps xmm8, [rsp+0x80]
000078805cdda7f2  vmovaps xmm9, [rsp+0x90]
000078805cdda7fb  vmovaps xmm10, [rsp+0xA0]
000078805cdda804  vmovaps xmm11, [rsp+0xB0]
000078805cdda80d  vmovaps xmm12, [rsp+0xC0]
000078805cdda816  vmovaps xmm13, [rsp+0xD0]
000078805cdda81f  vmovaps xmm14, [rsp+0xE0]
000078805cdda828  add rsp, 0xF0
000078805cdda82f  pop r11
000078805cdda831  pop r10
000078805cdda833  pop r9
000078805cdda835  pop r8
000078805cdda837  pop rsi
000078805cdda838  pop rdi
000078805cdda839  pop rdx
000078805cdda83a  pop rcx
000078805cdda83b  pop rax
000078805cdda83c  add rsp, 0x08
000078805cdda840  jmp 0x000078805CDD64A5
000078805cdda845  sub rsp, 0x08
000078805cdda849  push rax
000078805cdda84a  push rcx
000078805cdda84b  push rdx
000078805cdda84c  push rdi
000078805cdda84d  push rsi
000078805cdda84e  push r8
000078805cdda850  push r9
000078805cdda852  push r10
000078805cdda854  push r11
000078805cdda856  sub rsp, 0xF0
000078805cdda85d  vmovaps [rsp], xmm0
000078805cdda862  vmovaps [rsp+0x10], xmm1
000078805cdda868  vmovaps [rsp+0x20], xmm2
000078805cdda86e  vmovaps [rsp+0x30], xmm3
000078805cdda874  vmovaps [rsp+0x40], xmm4
000078805cdda87a  vmovaps [rsp+0x50], xmm5
000078805cdda880  vmovaps [rsp+0x60], xmm6
000078805cdda886  vmovaps [rsp+0x70], xmm8
000078805cdda88c  vmovaps [rsp+0x80], xmm9
000078805cdda895  vmovaps [rsp+0x90], xmm10
000078805cdda89e  vmovaps [rsp+0xA0], xmm11
000078805cdda8a7  vmovaps [rsp+0xB0], xmm12
000078805cdda8b0  vmovaps [rsp+0xC0], xmm13
000078805cdda8b9  vmovaps [rsp+0xD0], xmm14
000078805cdda8c2  vmovaps [rsp+0xE0], xmm15
000078805cdda8cb  sub rsp, 0x30
000078805cdda8cf  movaps [rsp], xmm7
000078805cdda8d3  movaps [rsp+0x10], xmm11
000078805cdda8d9  movaps [rsp+0x20], xmm9
000078805cdda8df  lea rdi, [rsp]
000078805cdda8e3  mov esi, 0x00
000078805cdda8e8  mov rax, 0x5771AD6EA530
000078805cdda8f2  call rax
000078805cdda8f4  movaps xmm7, [rsp]
000078805cdda8f8  add rsp, 0x30
000078805cdda8fc  vmovaps xmm0, [rsp]
000078805cdda901  vmovaps xmm1, [rsp+0x10]
000078805cdda907  vmovaps xmm2, [rsp+0x20]
000078805cdda90d  vmovaps xmm3, [rsp+0x30]
000078805cdda913  vmovaps xmm4, [rsp+0x40]
000078805cdda919  vmovaps xmm5, [rsp+0x50]
000078805cdda91f  vmovaps xmm6, [rsp+0x60]
000078805cdda925  vmovaps xmm8, [rsp+0x70]
000078805cdda92b  vmovaps xmm9, [rsp+0x80]
000078805cdda934  vmovaps xmm10, [rsp+0x90]
000078805cdda93d  vmovaps xmm11, [rsp+0xA0]
000078805cdda946  vmovaps xmm12, [rsp+0xB0]
000078805cdda94f  vmovaps xmm13, [rsp+0xC0]
000078805cdda958  vmovaps xmm14, [rsp+0xD0]
000078805cdda961  vmovaps xmm15, [rsp+0xE0]
000078805cdda96a  add rsp, 0xF0
000078805cdda971  pop r11
000078805cdda973  pop r10
000078805cdda975  pop r9
000078805cdda977  pop r8
000078805cdda979  pop rsi
000078805cdda97a  pop rdi
000078805cdda97b  pop rdx
000078805cdda97c  pop rcx
000078805cdda97d  pop rax
000078805cdda97e  add rsp, 0x08
000078805cdda982  jmp 0x000078805CDD64D2
000078805cdda987  sub rsp, 0x08
000078805cdda98b  push rax
000078805cdda98c  push rcx
000078805cdda98d  push rdx
000078805cdda98e  push rdi
000078805cdda98f  push rsi
000078805cdda990  push r8
000078805cdda992  push r9
000078805cdda994  push r10
000078805cdda996  push r11
000078805cdda998  sub rsp, 0xF0
000078805cdda99f  vmovaps [rsp], xmm0
000078805cdda9a4  vmovaps [rsp+0x10], xmm1
000078805cdda9aa  vmovaps [rsp+0x20], xmm2
000078805cdda9b0  vmovaps [rsp+0x30], xmm3
000078805cdda9b6  vmovaps [rsp+0x40], xmm4
000078805cdda9bc  vmovaps [rsp+0x50], xmm5
000078805cdda9c2  vmovaps [rsp+0x60], xmm6
000078805cdda9c8  vmovaps [rsp+0x70], xmm7
000078805cdda9ce  vmovaps [rsp+0x80], xmm8
000078805cdda9d7  vmovaps [rsp+0x90], xmm9
000078805cdda9e0  vmovaps [rsp+0xA0], xmm10
000078805cdda9e9  vmovaps [rsp+0xB0], xmm12
000078805cdda9f2  vmovaps [rsp+0xC0], xmm13
000078805cdda9fb  vmovaps [rsp+0xD0], xmm14
000078805cddaa04  vmovaps [rsp+0xE0], xmm15
000078805cddaa0d  sub rsp, 0x30
000078805cddaa11  movaps [rsp], xmm11
000078805cddaa16  movaps [rsp+0x10], xmm10
000078805cddaa1c  movaps [rsp+0x20], xmm14
000078805cddaa22  lea rdi, [rsp]
000078805cddaa26  mov esi, 0x00
000078805cddaa2b  mov rax, 0x5771AD6EA530
000078805cddaa35  call rax
000078805cddaa37  movaps xmm11, [rsp]
000078805cddaa3c  add rsp, 0x30
000078805cddaa40  vmovaps xmm0, [rsp]
000078805cddaa45  vmovaps xmm1, [rsp+0x10]
000078805cddaa4b  vmovaps xmm2, [rsp+0x20]
000078805cddaa51  vmovaps xmm3, [rsp+0x30]
000078805cddaa57  vmovaps xmm4, [rsp+0x40]
000078805cddaa5d  vmovaps xmm5, [rsp+0x50]
000078805cddaa63  vmovaps xmm6, [rsp+0x60]
000078805cddaa69  vmovaps xmm7, [rsp+0x70]
000078805cddaa6f  vmovaps xmm8, [rsp+0x80]
000078805cddaa78  vmovaps xmm9, [rsp+0x90]
000078805cddaa81  vmovaps xmm10, [rsp+0xA0]
000078805cddaa8a  vmovaps xmm12, [rsp+0xB0]
000078805cddaa93  vmovaps xmm13, [rsp+0xC0]
000078805cddaa9c  vmovaps xmm14, [rsp+0xD0]
000078805cddaaa5  vmovaps xmm15, [rsp+0xE0]
000078805cddaaae  add rsp, 0xF0
000078805cddaab5  pop r11
000078805cddaab7  pop r10
000078805cddaab9  pop r9
000078805cddaabb  pop r8
000078805cddaabd  pop rsi
000078805cddaabe  pop rdi
000078805cddaabf  pop rdx
000078805cddaac0  pop rcx
000078805cddaac1  pop rax
000078805cddaac2  add rsp, 0x08
000078805cddaac6  jmp 0x000078805CDD64ED
000078805cddaacb  call 0x000078805CCE45A0
000078805cddaad0  jmp 0x000078805CDD64F7
000078805cddaad5  sub rsp, 0x08
000078805cddaad9  push rax
000078805cddaada  push rcx
000078805cddaadb  push rdx
000078805cddaadc  push rdi
000078805cddaadd  push rsi
000078805cddaade  push r8
000078805cddaae0  push r9
000078805cddaae2  push r10
000078805cddaae4  push r11
000078805cddaae6  sub rsp, 0xF0
000078805cddaaed  vmovaps [rsp], xmm0
000078805cddaaf2  vmovaps [rsp+0x10], xmm1
000078805cddaaf8  vmovaps [rsp+0x20], xmm2
000078805cddaafe  vmovaps [rsp+0x30], xmm3
000078805cddab04  vmovaps [rsp+0x40], xmm4
000078805cddab0a  vmovaps [rsp+0x50], xmm5
000078805cddab10  vmovaps [rsp+0x60], xmm6
000078805cddab16  vmovaps [rsp+0x70], xmm7
000078805cddab1c  vmovaps [rsp+0x80], xmm8
000078805cddab25  vmovaps [rsp+0x90], xmm9
000078805cddab2e  vmovaps [rsp+0xA0], xmm11
000078805cddab37  vmovaps [rsp+0xB0], xmm12
000078805cddab40  vmovaps [rsp+0xC0], xmm13
000078805cddab49  vmovaps [rsp+0xD0], xmm14
000078805cddab52  vmovaps [rsp+0xE0], xmm15
000078805cddab5b  sub rsp, 0x30
000078805cddab5f  movaps [rsp], xmm10
000078805cddab64  movaps [rsp+0x10], xmm1
000078805cddab69  movaps [rsp+0x20], xmm12
000078805cddab6f  lea rdi, [rsp]
000078805cddab73  mov esi, 0x00
000078805cddab78  mov rax, 0x5771AD6EA530
000078805cddab82  call rax
000078805cddab84  movaps xmm10, [rsp]
000078805cddab89  add rsp, 0x30
000078805cddab8d  vmovaps xmm0, [rsp]
000078805cddab92  vmovaps xmm1, [rsp+0x10]
000078805cddab98  vmovaps xmm2, [rsp+0x20]
000078805cddab9e  vmovaps xmm3, [rsp+0x30]
000078805cddaba4  vmovaps xmm4, [rsp+0x40]
000078805cddabaa  vmovaps xmm5, [rsp+0x50]
000078805cddabb0  vmovaps xmm6, [rsp+0x60]
000078805cddabb6  vmovaps xmm7, [rsp+0x70]
000078805cddabbc  vmovaps xmm8, [rsp+0x80]
000078805cddabc5  vmovaps xmm9, [rsp+0x90]
000078805cddabce  vmovaps xmm11, [rsp+0xA0]
000078805cddabd7  vmovaps xmm12, [rsp+0xB0]
000078805cddabe0  vmovaps xmm13, [rsp+0xC0]
000078805cddabe9  vmovaps xmm14, [rsp+0xD0]
000078805cddabf2  vmovaps xmm15, [rsp+0xE0]
000078805cddabfb  add rsp, 0xF0
000078805cddac02  pop r11
000078805cddac04  pop r10
000078805cddac06  pop r9
000078805cddac08  pop r8
000078805cddac0a  pop rsi
000078805cddac0b  pop rdi
000078805cddac0c  pop rdx
000078805cddac0d  pop rcx
000078805cddac0e  pop rax
000078805cddac0f  add rsp, 0x08
000078805cddac13  jmp 0x000078805CDD651A
000078805cddac18  sub rsp, 0x08
000078805cddac1c  push rax
000078805cddac1d  push rcx
000078805cddac1e  push rdx
000078805cddac1f  push rdi
000078805cddac20  push rsi
000078805cddac21  push r8
000078805cddac23  push r9
000078805cddac25  push r10
000078805cddac27  push r11
000078805cddac29  sub rsp, 0xF0
000078805cddac30  vmovaps [rsp], xmm0
000078805cddac35  vmovaps [rsp+0x10], xmm1
000078805cddac3b  vmovaps [rsp+0x20], xmm2
000078805cddac41  vmovaps [rsp+0x30], xmm3
000078805cddac47  vmovaps [rsp+0x40], xmm4
000078805cddac4d  vmovaps [rsp+0x50], xmm5
000078805cddac53  vmovaps [rsp+0x60], xmm6
000078805cddac59  vmovaps [rsp+0x70], xmm7
000078805cddac5f  vmovaps [rsp+0x80], xmm8
000078805cddac68  vmovaps [rsp+0x90], xmm9
000078805cddac71  vmovaps [rsp+0xA0], xmm10
000078805cddac7a  vmovaps [rsp+0xB0], xmm11
000078805cddac83  vmovaps [rsp+0xC0], xmm13
000078805cddac8c  vmovaps [rsp+0xD0], xmm14
000078805cddac95  vmovaps [rsp+0xE0], xmm15
000078805cddac9e  sub rsp, 0x30
000078805cddaca2  movaps [rsp], xmm12
000078805cddaca7  movaps [rsp+0x10], xmm14
000078805cddacad  movaps [rsp+0x20], xmm1
000078805cddacb2  lea rdi, [rsp]
000078805cddacb6  mov esi, 0x00
000078805cddacbb  mov rax, 0x5771AD6EA530
000078805cddacc5  call rax
000078805cddacc7  movaps xmm12, [rsp]
000078805cddaccc  add rsp, 0x30
000078805cddacd0  vmovaps xmm0, [rsp]
000078805cddacd5  vmovaps xmm1, [rsp+0x10]
000078805cddacdb  vmovaps xmm2, [rsp+0x20]
000078805cddace1  vmovaps xmm3, [rsp+0x30]
000078805cddace7  vmovaps xmm4, [rsp+0x40]
000078805cddaced  vmovaps xmm5, [rsp+0x50]
000078805cddacf3  vmovaps xmm6, [rsp+0x60]
000078805cddacf9  vmovaps xmm7, [rsp+0x70]
000078805cddacff  vmovaps xmm8, [rsp+0x80]
000078805cddad08  vmovaps xmm9, [rsp+0x90]
000078805cddad11  vmovaps xmm10, [rsp+0xA0]
000078805cddad1a  vmovaps xmm11, [rsp+0xB0]
000078805cddad23  vmovaps xmm13, [rsp+0xC0]
000078805cddad2c  vmovaps xmm14, [rsp+0xD0]
000078805cddad35  vmovaps xmm15, [rsp+0xE0]
000078805cddad3e  add rsp, 0xF0
000078805cddad45  pop r11
000078805cddad47  pop r10
000078805cddad49  pop r9
000078805cddad4b  pop r8
000078805cddad4d  pop rsi
000078805cddad4e  pop rdi
000078805cddad4f  pop rdx
000078805cddad50  pop rcx
000078805cddad51  pop rax
000078805cddad52  add rsp, 0x08
000078805cddad56  jmp 0x000078805CDD6549
000078805cddad5b  sub rsp, 0x08
000078805cddad5f  push rax
000078805cddad60  push rcx
000078805cddad61  push rdx
000078805cddad62  push rdi
000078805cddad63  push rsi
000078805cddad64  push r8
000078805cddad66  push r9
000078805cddad68  push r10
000078805cddad6a  push r11
000078805cddad6c  sub rsp, 0xF0
000078805cddad73  vmovaps [rsp], xmm0
000078805cddad78  vmovaps [rsp+0x10], xmm1
000078805cddad7e  vmovaps [rsp+0x20], xmm2
000078805cddad84  vmovaps [rsp+0x30], xmm3
000078805cddad8a  vmovaps [rsp+0x40], xmm4
000078805cddad90  vmovaps [rsp+0x50], xmm5
000078805cddad96  vmovaps [rsp+0x60], xmm6
000078805cddad9c  vmovaps [rsp+0x70], xmm7
000078805cddada2  vmovaps [rsp+0x80], xmm8
000078805cddadab  vmovaps [rsp+0x90], xmm9
000078805cddadb4  vmovaps [rsp+0xA0], xmm10
000078805cddadbd  vmovaps [rsp+0xB0], xmm11
000078805cddadc6  vmovaps [rsp+0xC0], xmm12
000078805cddadcf  vmovaps [rsp+0xD0], xmm13
000078805cddadd8  vmovaps [rsp+0xE0], xmm15
000078805cddade1  sub rsp, 0x30
000078805cddade5  movaps [rsp], xmm14
000078805cddadea  movaps [rsp+0x10], xmm9
000078805cddadf0  movaps [rsp+0x20], xmm1
000078805cddadf5  lea rdi, [rsp]
000078805cddadf9  mov esi, 0x00
000078805cddadfe  mov rax, 0x5771AD6EA530
000078805cddae08  call rax
000078805cddae0a  movaps xmm14, [rsp]
000078805cddae0f  add rsp, 0x30
000078805cddae13  vmovaps xmm0, [rsp]
000078805cddae18  vmovaps xmm1, [rsp+0x10]
000078805cddae1e  vmovaps xmm2, [rsp+0x20]
000078805cddae24  vmovaps xmm3, [rsp+0x30]
000078805cddae2a  vmovaps xmm4, [rsp+0x40]
000078805cddae30  vmovaps xmm5, [rsp+0x50]
000078805cddae36  vmovaps xmm6, [rsp+0x60]
000078805cddae3c  vmovaps xmm7, [rsp+0x70]
000078805cddae42  vmovaps xmm8, [rsp+0x80]
000078805cddae4b  vmovaps xmm9, [rsp+0x90]
000078805cddae54  vmovaps xmm10, [rsp+0xA0]
000078805cddae5d  vmovaps xmm11, [rsp+0xB0]
000078805cddae66  vmovaps xmm12, [rsp+0xC0]
000078805cddae6f  vmovaps xmm13, [rsp+0xD0]
000078805cddae78  vmovaps xmm15, [rsp+0xE0]
000078805cddae81  add rsp, 0xF0
000078805cddae88  pop r11
000078805cddae8a  pop r10
000078805cddae8c  pop r9
000078805cddae8e  pop r8
000078805cddae90  pop rsi
000078805cddae91  pop rdi
000078805cddae92  pop rdx
000078805cddae93  pop rcx
000078805cddae94  pop rax
000078805cddae95  add rsp, 0x08
000078805cddae99  jmp 0x000078805CDD6578
000078805cddae9e  sub rsp, 0x08
000078805cddaea2  push rax
000078805cddaea3  push rcx
000078805cddaea4  push rdx
000078805cddaea5  push rdi
000078805cddaea6  push rsi
000078805cddaea7  push r8
000078805cddaea9  push r9
000078805cddaeab  push r10
000078805cddaead  push r11
000078805cddaeaf  sub rsp, 0xF0
000078805cddaeb6  vmovaps [rsp], xmm0
000078805cddaebb  vmovaps [rsp+0x10], xmm2
000078805cddaec1  vmovaps [rsp+0x20], xmm3
000078805cddaec7  vmovaps [rsp+0x30], xmm4
000078805cddaecd  vmovaps [rsp+0x40], xmm5
000078805cddaed3  vmovaps [rsp+0x50], xmm6
000078805cddaed9  vmovaps [rsp+0x60], xmm7
000078805cddaedf  vmovaps [rsp+0x70], xmm8
000078805cddaee5  vmovaps [rsp+0x80], xmm9
000078805cddaeee  vmovaps [rsp+0x90], xmm10
000078805cddaef7  vmovaps [rsp+0xA0], xmm11
000078805cddaf00  vmovaps [rsp+0xB0], xmm12
000078805cddaf09  vmovaps [rsp+0xC0], xmm13
000078805cddaf12  vmovaps [rsp+0xD0], xmm14
000078805cddaf1b  vmovaps [rsp+0xE0], xmm15
000078805cddaf24  sub rsp, 0x30
000078805cddaf28  movaps [rsp], xmm1
000078805cddaf2c  movaps [rsp+0x10], xmm13
000078805cddaf32  movaps [rsp+0x20], xmm8
000078805cddaf38  lea rdi, [rsp]
000078805cddaf3c  mov esi, 0x00
000078805cddaf41  mov rax, 0x5771AD6EA530
000078805cddaf4b  call rax
000078805cddaf4d  movaps xmm1, [rsp]
000078805cddaf51  add rsp, 0x30
000078805cddaf55  vmovaps xmm0, [rsp]
000078805cddaf5a  vmovaps xmm2, [rsp+0x10]
000078805cddaf60  vmovaps xmm3, [rsp+0x20]
000078805cddaf66  vmovaps xmm4, [rsp+0x30]
000078805cddaf6c  vmovaps xmm5, [rsp+0x40]
000078805cddaf72  vmovaps xmm6, [rsp+0x50]
000078805cddaf78  vmovaps xmm7, [rsp+0x60]
000078805cddaf7e  vmovaps xmm8, [rsp+0x70]
000078805cddaf84  vmovaps xmm9, [rsp+0x80]
000078805cddaf8d  vmovaps xmm10, [rsp+0x90]
000078805cddaf96  vmovaps xmm11, [rsp+0xA0]
000078805cddaf9f  vmovaps xmm12, [rsp+0xB0]
000078805cddafa8  vmovaps xmm13, [rsp+0xC0]
000078805cddafb1  vmovaps xmm14, [rsp+0xD0]
000078805cddafba  vmovaps xmm15, [rsp+0xE0]
000078805cddafc3  add rsp, 0xF0
000078805cddafca  pop r11
000078805cddafcc  pop r10
000078805cddafce  pop r9
000078805cddafd0  pop r8
000078805cddafd2  pop rsi
000078805cddafd3  pop rdi
000078805cddafd4  pop rdx
000078805cddafd5  pop rcx
000078805cddafd6  pop rax
000078805cddafd7  add rsp, 0x08
000078805cddafdb  jmp 0x000078805CDD659A
000078805cddafe0  call 0x000078805CC0C260
000078805cddafe5  jmp 0x000078805CDD65A8
000078805cddafea  call 0x000078805CCDE950
000078805cddafef  jmp 0x000078805CDD65B2
000078805cddaff4  sub rsp, 0x08
000078805cddaff8  push rax
000078805cddaff9  push rcx
000078805cddaffa  push rdx
000078805cddaffb  push rdi
000078805cddaffc  push rsi
000078805cddaffd  push r8
000078805cddafff  push r9
000078805cddb001  push r10
000078805cddb003  push r11
000078805cddb005  sub rsp, 0xF0
000078805cddb00c  vmovaps [rsp], xmm0
000078805cddb011  vmovaps [rsp+0x10], xmm1
000078805cddb017  vmovaps [rsp+0x20], xmm2
000078805cddb01d  vmovaps [rsp+0x30], xmm3
000078805cddb023  vmovaps [rsp+0x40], xmm4
000078805cddb029  vmovaps [rsp+0x50], xmm5
000078805cddb02f  vmovaps [rsp+0x60], xmm6
000078805cddb035  vmovaps [rsp+0x70], xmm7
000078805cddb03b  vmovaps [rsp+0x80], xmm9
000078805cddb044  vmovaps [rsp+0x90], xmm10
000078805cddb04d  vmovaps [rsp+0xA0], xmm11
000078805cddb056  vmovaps [rsp+0xB0], xmm12
000078805cddb05f  vmovaps [rsp+0xC0], xmm13
000078805cddb068  vmovaps [rsp+0xD0], xmm14
000078805cddb071  vmovaps [rsp+0xE0], xmm15
000078805cddb07a  sub rsp, 0x30
000078805cddb07e  movaps [rsp], xmm8
000078805cddb083  movaps [rsp+0x10], xmm15
000078805cddb089  movaps [rsp+0x20], xmm7
000078805cddb08e  lea rdi, [rsp]
000078805cddb092  mov esi, 0x00
000078805cddb097  mov rax, 0x5771AD6EA530
000078805cddb0a1  call rax
000078805cddb0a3  movaps xmm8, [rsp]
000078805cddb0a8  add rsp, 0x30
000078805cddb0ac  vmovaps xmm0, [rsp]
000078805cddb0b1  vmovaps xmm1, [rsp+0x10]
000078805cddb0b7  vmovaps xmm2, [rsp+0x20]
000078805cddb0bd  vmovaps xmm3, [rsp+0x30]
000078805cddb0c3  vmovaps xmm4, [rsp+0x40]
000078805cddb0c9  vmovaps xmm5, [rsp+0x50]
000078805cddb0cf  vmovaps xmm6, [rsp+0x60]
000078805cddb0d5  vmovaps xmm7, [rsp+0x70]
000078805cddb0db  vmovaps xmm9, [rsp+0x80]
000078805cddb0e4  vmovaps xmm10, [rsp+0x90]
000078805cddb0ed  vmovaps xmm11, [rsp+0xA0]
000078805cddb0f6  vmovaps xmm12, [rsp+0xB0]
000078805cddb0ff  vmovaps xmm13, [rsp+0xC0]
000078805cddb108  vmovaps xmm14, [rsp+0xD0]
000078805cddb111  vmovaps xmm15, [rsp+0xE0]
000078805cddb11a  add rsp, 0xF0
000078805cddb121  pop r11
000078805cddb123  pop r10
000078805cddb125  pop r9
000078805cddb127  pop r8
000078805cddb129  pop rsi
000078805cddb12a  pop rdi
000078805cddb12b  pop rdx
000078805cddb12c  pop rcx
000078805cddb12d  pop rax
000078805cddb12e  add rsp, 0x08
000078805cddb132  jmp 0x000078805CDD65D4
000078805cddb137  sub rsp, 0x08
000078805cddb13b  push rax
000078805cddb13c  push rcx
000078805cddb13d  push rdx
000078805cddb13e  push rdi
000078805cddb13f  push rsi
000078805cddb140  push r8
000078805cddb142  push r9
000078805cddb144  push r10
000078805cddb146  push r11
000078805cddb148  sub rsp, 0xF0
000078805cddb14f  vmovaps [rsp], xmm0
000078805cddb154  vmovaps [rsp+0x10], xmm1
000078805cddb15a  vmovaps [rsp+0x20], xmm2
000078805cddb160  vmovaps [rsp+0x30], xmm3
000078805cddb166  vmovaps [rsp+0x40], xmm4
000078805cddb16c  vmovaps [rsp+0x50], xmm5
000078805cddb172  vmovaps [rsp+0x60], xmm6
000078805cddb178  vmovaps [rsp+0x70], xmm8
000078805cddb17e  vmovaps [rsp+0x80], xmm9
000078805cddb187  vmovaps [rsp+0x90], xmm10
000078805cddb190  vmovaps [rsp+0xA0], xmm11
000078805cddb199  vmovaps [rsp+0xB0], xmm12
000078805cddb1a2  vmovaps [rsp+0xC0], xmm13
000078805cddb1ab  vmovaps [rsp+0xD0], xmm14
000078805cddb1b4  vmovaps [rsp+0xE0], xmm15
000078805cddb1bd  sub rsp, 0x30
000078805cddb1c1  movaps [rsp], xmm7
000078805cddb1c5  movaps [rsp+0x10], xmm9
000078805cddb1cb  movaps [rsp+0x20], xmm15
000078805cddb1d1  lea rdi, [rsp]
000078805cddb1d5  mov esi, 0x00
000078805cddb1da  mov rax, 0x5771AD6EA530
000078805cddb1e4  call rax
000078805cddb1e6  movaps xmm7, [rsp]
000078805cddb1ea  add rsp, 0x30
000078805cddb1ee  vmovaps xmm0, [rsp]
000078805cddb1f3  vmovaps xmm1, [rsp+0x10]
000078805cddb1f9  vmovaps xmm2, [rsp+0x20]
000078805cddb1ff  vmovaps xmm3, [rsp+0x30]
000078805cddb205  vmovaps xmm4, [rsp+0x40]
000078805cddb20b  vmovaps xmm5, [rsp+0x50]
000078805cddb211  vmovaps xmm6, [rsp+0x60]
000078805cddb217  vmovaps xmm8, [rsp+0x70]
000078805cddb21d  vmovaps xmm9, [rsp+0x80]
000078805cddb226  vmovaps xmm10, [rsp+0x90]
000078805cddb22f  vmovaps xmm11, [rsp+0xA0]
000078805cddb238  vmovaps xmm12, [rsp+0xB0]
000078805cddb241  vmovaps xmm13, [rsp+0xC0]
000078805cddb24a  vmovaps xmm14, [rsp+0xD0]
000078805cddb253  vmovaps xmm15, [rsp+0xE0]
000078805cddb25c  add rsp, 0xF0
000078805cddb263  pop r11
000078805cddb265  pop r10
000078805cddb267  pop r9
000078805cddb269  pop r8
000078805cddb26b  pop rsi
000078805cddb26c  pop rdi
000078805cddb26d  pop rdx
000078805cddb26e  pop rcx
000078805cddb26f  pop rax
000078805cddb270  add rsp, 0x08
000078805cddb274  jmp 0x000078805CDD6601
000078805cddb279  sub rsp, 0x08
000078805cddb27d  push rax
000078805cddb27e  push rcx
000078805cddb27f  push rdx
000078805cddb280  push rdi
000078805cddb281  push rsi
000078805cddb282  push r8
000078805cddb284  push r9
000078805cddb286  push r10
000078805cddb288  push r11
000078805cddb28a  sub rsp, 0xF0
000078805cddb291  vmovaps [rsp], xmm0
000078805cddb296  vmovaps [rsp+0x10], xmm1
000078805cddb29c  vmovaps [rsp+0x20], xmm2
000078805cddb2a2  vmovaps [rsp+0x30], xmm3
000078805cddb2a8  vmovaps [rsp+0x40], xmm4
000078805cddb2ae  vmovaps [rsp+0x50], xmm5
000078805cddb2b4  vmovaps [rsp+0x60], xmm6
000078805cddb2ba  vmovaps [rsp+0x70], xmm7
000078805cddb2c0  vmovaps [rsp+0x80], xmm8
000078805cddb2c9  vmovaps [rsp+0x90], xmm10
000078805cddb2d2  vmovaps [rsp+0xA0], xmm11
000078805cddb2db  vmovaps [rsp+0xB0], xmm12
000078805cddb2e4  vmovaps [rsp+0xC0], xmm13
000078805cddb2ed  vmovaps [rsp+0xD0], xmm14
000078805cddb2f6  vmovaps [rsp+0xE0], xmm15
000078805cddb2ff  sub rsp, 0x30
000078805cddb303  movaps [rsp], xmm9
000078805cddb308  movaps [rsp+0x10], xmm13
000078805cddb30e  movaps [rsp+0x20], xmm15
000078805cddb314  lea rdi, [rsp]
000078805cddb318  mov esi, 0x00
000078805cddb31d  mov rax, 0x5771AD6EA530
000078805cddb327  call rax
000078805cddb329  movaps xmm9, [rsp]
000078805cddb32e  add rsp, 0x30
000078805cddb332  vmovaps xmm0, [rsp]
000078805cddb337  vmovaps xmm1, [rsp+0x10]
000078805cddb33d  vmovaps xmm2, [rsp+0x20]
000078805cddb343  vmovaps xmm3, [rsp+0x30]
000078805cddb349  vmovaps xmm4, [rsp+0x40]
000078805cddb34f  vmovaps xmm5, [rsp+0x50]
000078805cddb355  vmovaps xmm6, [rsp+0x60]
000078805cddb35b  vmovaps xmm7, [rsp+0x70]
000078805cddb361  vmovaps xmm8, [rsp+0x80]
000078805cddb36a  vmovaps xmm10, [rsp+0x90]
000078805cddb373  vmovaps xmm11, [rsp+0xA0]
000078805cddb37c  vmovaps xmm12, [rsp+0xB0]
000078805cddb385  vmovaps xmm13, [rsp+0xC0]
000078805cddb38e  vmovaps xmm14, [rsp+0xD0]
000078805cddb397  vmovaps xmm15, [rsp+0xE0]
000078805cddb3a0  add rsp, 0xF0
000078805cddb3a7  pop r11
000078805cddb3a9  pop r10
000078805cddb3ab  pop r9
000078805cddb3ad  pop r8
000078805cddb3af  pop rsi
000078805cddb3b0  pop rdi
000078805cddb3b1  pop rdx
000078805cddb3b2  pop rcx
000078805cddb3b3  pop rax
000078805cddb3b4  add rsp, 0x08
000078805cddb3b8  jmp 0x000078805CDD662F
000078805cddb3bd  sub rsp, 0x08
000078805cddb3c1  push rax
000078805cddb3c2  push rcx
000078805cddb3c3  push rdx
000078805cddb3c4  push rdi
000078805cddb3c5  push rsi
000078805cddb3c6  push r8
000078805cddb3c8  push r9
000078805cddb3ca  push r10
000078805cddb3cc  push r11
000078805cddb3ce  sub rsp, 0xF0
000078805cddb3d5  vmovaps [rsp], xmm0
000078805cddb3da  vmovaps [rsp+0x10], xmm1
000078805cddb3e0  vmovaps [rsp+0x20], xmm2
000078805cddb3e6  vmovaps [rsp+0x30], xmm3
000078805cddb3ec  vmovaps [rsp+0x40], xmm4
000078805cddb3f2  vmovaps [rsp+0x50], xmm5
000078805cddb3f8  vmovaps [rsp+0x60], xmm6
000078805cddb3fe  vmovaps [rsp+0x70], xmm7
000078805cddb404  vmovaps [rsp+0x80], xmm8
000078805cddb40d  vmovaps [rsp+0x90], xmm9
000078805cddb416  vmovaps [rsp+0xA0], xmm10
000078805cddb41f  vmovaps [rsp+0xB0], xmm11
000078805cddb428  vmovaps [rsp+0xC0], xmm12
000078805cddb431  vmovaps [rsp+0xD0], xmm13
000078805cddb43a  vmovaps [rsp+0xE0], xmm14
000078805cddb443  sub rsp, 0x30
000078805cddb447  movaps [rsp], xmm15
000078805cddb44c  movaps [rsp+0x10], xmm11
000078805cddb452  movaps [rsp+0x20], xmm12
000078805cddb458  lea rdi, [rsp]
000078805cddb45c  mov esi, 0x00
000078805cddb461  mov rax, 0x5771AD6EA530
000078805cddb46b  call rax
000078805cddb46d  movaps xmm15, [rsp]
000078805cddb472  add rsp, 0x30
000078805cddb476  vmovaps xmm0, [rsp]
000078805cddb47b  vmovaps xmm1, [rsp+0x10]
000078805cddb481  vmovaps xmm2, [rsp+0x20]
000078805cddb487  vmovaps xmm3, [rsp+0x30]
000078805cddb48d  vmovaps xmm4, [rsp+0x40]
000078805cddb493  vmovaps xmm5, [rsp+0x50]
000078805cddb499  vmovaps xmm6, [rsp+0x60]
000078805cddb49f  vmovaps xmm7, [rsp+0x70]
000078805cddb4a5  vmovaps xmm8, [rsp+0x80]
000078805cddb4ae  vmovaps xmm9, [rsp+0x90]
000078805cddb4b7  vmovaps xmm10, [rsp+0xA0]
000078805cddb4c0  vmovaps xmm11, [rsp+0xB0]
000078805cddb4c9  vmovaps xmm12, [rsp+0xC0]
000078805cddb4d2  vmovaps xmm13, [rsp+0xD0]
000078805cddb4db  vmovaps xmm14, [rsp+0xE0]
000078805cddb4e4  add rsp, 0xF0
000078805cddb4eb  pop r11
000078805cddb4ed  pop r10
000078805cddb4ef  pop r9
000078805cddb4f1  pop r8
000078805cddb4f3  pop rsi
000078805cddb4f4  pop rdi
000078805cddb4f5  pop rdx
000078805cddb4f6  pop rcx
000078805cddb4f7  pop rax
000078805cddb4f8  add rsp, 0x08
000078805cddb4fc  jmp 0x000078805CDD664A
000078805cddb501  sub rsp, 0x08
000078805cddb505  push rax
000078805cddb506  push rcx
000078805cddb507  push rdx
000078805cddb508  push rdi
000078805cddb509  push rsi
000078805cddb50a  push r8
000078805cddb50c  push r9
000078805cddb50e  push r10
000078805cddb510  push r11
000078805cddb512  sub rsp, 0xF0
000078805cddb519  vmovaps [rsp], xmm0
000078805cddb51e  vmovaps [rsp+0x10], xmm1
000078805cddb524  vmovaps [rsp+0x20], xmm2
000078805cddb52a  vmovaps [rsp+0x30], xmm3
000078805cddb530  vmovaps [rsp+0x40], xmm4
000078805cddb536  vmovaps [rsp+0x50], xmm5
000078805cddb53c  vmovaps [rsp+0x60], xmm6
000078805cddb542  vmovaps [rsp+0x70], xmm7
000078805cddb548  vmovaps [rsp+0x80], xmm8
000078805cddb551  vmovaps [rsp+0x90], xmm9
000078805cddb55a  vmovaps [rsp+0xA0], xmm10
000078805cddb563  vmovaps [rsp+0xB0], xmm11
000078805cddb56c  vmovaps [rsp+0xC0], xmm12
000078805cddb575  vmovaps [rsp+0xD0], xmm14
000078805cddb57e  vmovaps [rsp+0xE0], xmm15
000078805cddb587  sub rsp, 0x30
000078805cddb58b  movaps [rsp], xmm13
000078805cddb590  movaps [rsp+0x10], xmm10
000078805cddb596  movaps [rsp+0x20], xmm14
000078805cddb59c  lea rdi, [rsp]
000078805cddb5a0  mov esi, 0x00
000078805cddb5a5  mov rax, 0x5771AD6EA530
000078805cddb5af  call rax
000078805cddb5b1  movaps xmm13, [rsp]
000078805cddb5b6  add rsp, 0x30
000078805cddb5ba  vmovaps xmm0, [rsp]
000078805cddb5bf  vmovaps xmm1, [rsp+0x10]
000078805cddb5c5  vmovaps xmm2, [rsp+0x20]
000078805cddb5cb  vmovaps xmm3, [rsp+0x30]
000078805cddb5d1  vmovaps xmm4, [rsp+0x40]
000078805cddb5d7  vmovaps xmm5, [rsp+0x50]
000078805cddb5dd  vmovaps xmm6, [rsp+0x60]
000078805cddb5e3  vmovaps xmm7, [rsp+0x70]
000078805cddb5e9  vmovaps xmm8, [rsp+0x80]
000078805cddb5f2  vmovaps xmm9, [rsp+0x90]
000078805cddb5fb  vmovaps xmm10, [rsp+0xA0]
000078805cddb604  vmovaps xmm11, [rsp+0xB0]
000078805cddb60d  vmovaps xmm12, [rsp+0xC0]
000078805cddb616  vmovaps xmm14, [rsp+0xD0]
000078805cddb61f  vmovaps xmm15, [rsp+0xE0]
000078805cddb628  add rsp, 0xF0
000078805cddb62f  pop r11
000078805cddb631  pop r10
000078805cddb633  pop r9
000078805cddb635  pop r8
000078805cddb637  pop rsi
000078805cddb638  pop rdi
000078805cddb639  pop rdx
000078805cddb63a  pop rcx
000078805cddb63b  pop rax
000078805cddb63c  add rsp, 0x08
000078805cddb640  jmp 0x000078805CDD666D
000078805cddb645  sub rsp, 0x08
000078805cddb649  push rax
000078805cddb64a  push rcx
000078805cddb64b  push rdx
000078805cddb64c  push rdi
000078805cddb64d  push rsi
000078805cddb64e  push r8
000078805cddb650  push r9
000078805cddb652  push r10
000078805cddb654  push r11
000078805cddb656  sub rsp, 0xF0
000078805cddb65d  vmovaps [rsp], xmm0
000078805cddb662  vmovaps [rsp+0x10], xmm1
000078805cddb668  vmovaps [rsp+0x20], xmm2
000078805cddb66e  vmovaps [rsp+0x30], xmm3
000078805cddb674  vmovaps [rsp+0x40], xmm4
000078805cddb67a  vmovaps [rsp+0x50], xmm5
000078805cddb680  vmovaps [rsp+0x60], xmm6
000078805cddb686  vmovaps [rsp+0x70], xmm7
000078805cddb68c  vmovaps [rsp+0x80], xmm8
000078805cddb695  vmovaps [rsp+0x90], xmm9
000078805cddb69e  vmovaps [rsp+0xA0], xmm10
000078805cddb6a7  vmovaps [rsp+0xB0], xmm11
000078805cddb6b0  vmovaps [rsp+0xC0], xmm12
000078805cddb6b9  vmovaps [rsp+0xD0], xmm13
000078805cddb6c2  vmovaps [rsp+0xE0], xmm15
000078805cddb6cb  sub rsp, 0x30
000078805cddb6cf  movaps [rsp], xmm14
000078805cddb6d4  movaps [rsp+0x10], xmm1
000078805cddb6d9  movaps [rsp+0x20], xmm7
000078805cddb6de  lea rdi, [rsp]
000078805cddb6e2  mov esi, 0x00
000078805cddb6e7  mov rax, 0x5771AD6EA530
000078805cddb6f1  call rax
000078805cddb6f3  movaps xmm14, [rsp]
000078805cddb6f8  add rsp, 0x30
000078805cddb6fc  vmovaps xmm0, [rsp]
000078805cddb701  vmovaps xmm1, [rsp+0x10]
000078805cddb707  vmovaps xmm2, [rsp+0x20]
000078805cddb70d  vmovaps xmm3, [rsp+0x30]
000078805cddb713  vmovaps xmm4, [rsp+0x40]
000078805cddb719  vmovaps xmm5, [rsp+0x50]
000078805cddb71f  vmovaps xmm6, [rsp+0x60]
000078805cddb725  vmovaps xmm7, [rsp+0x70]
000078805cddb72b  vmovaps xmm8, [rsp+0x80]
000078805cddb734  vmovaps xmm9, [rsp+0x90]
000078805cddb73d  vmovaps xmm10, [rsp+0xA0]
000078805cddb746  vmovaps xmm11, [rsp+0xB0]
000078805cddb74f  vmovaps xmm12, [rsp+0xC0]
000078805cddb758  vmovaps xmm13, [rsp+0xD0]
000078805cddb761  vmovaps xmm15, [rsp+0xE0]
000078805cddb76a  add rsp, 0xF0
000078805cddb771  pop r11
000078805cddb773  pop r10
000078805cddb775  pop r9
000078805cddb777  pop r8
000078805cddb779  pop rsi
000078805cddb77a  pop rdi
000078805cddb77b  pop rdx
000078805cddb77c  pop rcx
000078805cddb77d  pop rax
000078805cddb77e  add rsp, 0x08
000078805cddb782  jmp 0x000078805CDD6690
000078805cddb787  sub rsp, 0x08
000078805cddb78b  push rax
000078805cddb78c  push rcx
000078805cddb78d  push rdx
000078805cddb78e  push rdi
000078805cddb78f  push rsi
000078805cddb790  push r8
000078805cddb792  push r9
000078805cddb794  push r10
000078805cddb796  push r11
000078805cddb798  sub rsp, 0xF0
000078805cddb79f  vmovaps [rsp], xmm0
000078805cddb7a4  vmovaps [rsp+0x10], xmm2
000078805cddb7aa  vmovaps [rsp+0x20], xmm3
000078805cddb7b0  vmovaps [rsp+0x30], xmm4
000078805cddb7b6  vmovaps [rsp+0x40], xmm5
000078805cddb7bc  vmovaps [rsp+0x50], xmm6
000078805cddb7c2  vmovaps [rsp+0x60], xmm7
000078805cddb7c8  vmovaps [rsp+0x70], xmm8
000078805cddb7ce  vmovaps [rsp+0x80], xmm9
000078805cddb7d7  vmovaps [rsp+0x90], xmm10
000078805cddb7e0  vmovaps [rsp+0xA0], xmm11
000078805cddb7e9  vmovaps [rsp+0xB0], xmm12
000078805cddb7f2  vmovaps [rsp+0xC0], xmm13
000078805cddb7fb  vmovaps [rsp+0xD0], xmm14
000078805cddb804  vmovaps [rsp+0xE0], xmm15
000078805cddb80d  sub rsp, 0x30
000078805cddb811  movaps [rsp], xmm1
000078805cddb815  movaps [rsp+0x10], xmm8
000078805cddb81b  movaps [rsp+0x20], xmm9
000078805cddb821  lea rdi, [rsp]
000078805cddb825  mov esi, 0x00
000078805cddb82a  mov rax, 0x5771AD6EA530
000078805cddb834  call rax
000078805cddb836  movaps xmm1, [rsp]
000078805cddb83a  add rsp, 0x30
000078805cddb83e  vmovaps xmm0, [rsp]
000078805cddb843  vmovaps xmm2, [rsp+0x10]
000078805cddb849  vmovaps xmm3, [rsp+0x20]
000078805cddb84f  vmovaps xmm4, [rsp+0x30]
000078805cddb855  vmovaps xmm5, [rsp+0x40]
000078805cddb85b  vmovaps xmm6, [rsp+0x50]
000078805cddb861  vmovaps xmm7, [rsp+0x60]
000078805cddb867  vmovaps xmm8, [rsp+0x70]
000078805cddb86d  vmovaps xmm9, [rsp+0x80]
000078805cddb876  vmovaps xmm10, [rsp+0x90]
000078805cddb87f  vmovaps xmm11, [rsp+0xA0]
000078805cddb888  vmovaps xmm12, [rsp+0xB0]
000078805cddb891  vmovaps xmm13, [rsp+0xC0]
000078805cddb89a  vmovaps xmm14, [rsp+0xD0]
000078805cddb8a3  vmovaps xmm15, [rsp+0xE0]
000078805cddb8ac  add rsp, 0xF0
000078805cddb8b3  pop r11
000078805cddb8b5  pop r10
000078805cddb8b7  pop r9
000078805cddb8b9  pop r8
000078805cddb8bb  pop rsi
000078805cddb8bc  pop rdi
000078805cddb8bd  pop rdx
000078805cddb8be  pop rcx
000078805cddb8bf  pop rax
000078805cddb8c0  add rsp, 0x08
000078805cddb8c4  jmp 0x000078805CDD66B2
000078805cddb8c9  call 0x000078805CCB3E40
000078805cddb8ce  jmp 0x000078805CDD66C0
000078805cddb8d3  call 0x000078805CC0C380
000078805cddb8d8  jmp 0x000078805CDD66CA
000078805cddb8dd  call 0x000078805CC0D600
000078805cddb8e2  jmp 0x000078805CDD66D4
000078805cddb8e7  call 0x000078805CBFF540
000078805cddb8ec  jmp 0x000078805CDD66DE
000078805cddb8f1  int3
000078805cddb8f2  nop [rax+rax*1], ax
000078805cddb8fb  nop [rax+rax*1], eax
000078805cddb900  mov eax, [r15+0x48]
000078805cddb904  lea r14d, [eax+0x01]
000078805cddb909  mov [rsp+0x10], r14d
000078805cddb90e  mov r14d, r14d
000078805cddb911  mov [r15+0x48], r14
000078805cddb915  xor eax, eax
000078805cddb917  mov r14d, [rsp+0x10]
000078805cddb91c  cmp r14d, 0x1F4
000078805cddb923  cmc
000078805cddb924  lahf
000078805cddb925  seto al
000078805cddb928  mov [r15+0x108], eax
000078805cddb92f  mov eax, [r15+0x108]
000078805cddb936  sahf
000078805cddb937  jnz 0x000078805CDDB969
000078805cddb939  cmp dword ptr [r15+0x318], 0x00
000078805cddb941  jz 0x000078805CDE1AB0
000078805cddb947  nop [rax+rax*1], ax
000078805cddb950  nop [rax+rax*1], eax
000078805cddb958  mov eax, 0x410450
000078805cddb95d  mov [r15+0x100], rax
000078805cddb964  jmp 0x000078805CBFE110
000078805cddb969  cmp dword ptr [r15+0x318], 0x00
000078805cddb971  jz 0x000078805CDDB9A0
000078805cddb977  nop [rax+rax*1], ax
000078805cddb980  nop [rax+rax*1], eax
000078805cddb988  mov eax, 0x410274
000078805cddb98d  mov [r15+0x100], rax
000078805cddb994  jmp 0x000078805CBFE110
000078805cddb999  int3
000078805cddb99a  int3
000078805cddb99b  nop [rax+rax*1], eax
000078805cddb9a0  mov rax, [r15+0x40]
000078805cddb9a4  movaps xmm1, [r15+0x1D0]
000078805cddb9ac  vmovaps [rsp+0x10], xmm1
000078805cddb9b2  vmovaps xmm15, [rsp+0x10]
000078805cddb9b8  por xmm1, xmm15
000078805cddb9bd  movaps xmm14, [r15+0x1A0]
000078805cddb9c5  vmovaps [rsp+0x10], xmm14
000078805cddb9cb  vmovaps xmm13, [rsp+0x10]
000078805cddb9d1  por xmm14, xmm13
000078805cddb9d6  lea r14, [rax+0x30]
000078805cddb9da  mov r12, [r13+r14*1]
000078805cddb9df  lea r14, [rax+0x38]
000078805cddb9e3  mov r11, [r13+r14*1]
000078805cddb9e8  movq xmm13, r12
000078805cddb9ed  movq xmm12, r11
000078805cddb9f2  movq xmm13, xmm13
000078805cddb9f7  vmovaps [rsp+0x10], xmm13
000078805cddb9fd  movq xmm13, xmm13
000078805cddba02  movaps [r15+0x130], xmm13
000078805cddba0a  movq xmm12, xmm12
000078805cddba0f  vmovaps [rsp+0x20], xmm12
000078805cddba15  movq xmm12, xmm12
000078805cddba1a  movaps [r15+0x280], xmm12
000078805cddba22  movaps xmm13, [r15+0x270]
000078805cddba2a  vmovaps [rsp+0x30], xmm13
000078805cddba30  vmovaps xmm12, [rsp+0x30]
000078805cddba36  por xmm13, xmm12
000078805cddba3b  lea r14, [rax+0x20]
000078805cddba3f  mov r12, [r13+r14*1]
000078805cddba44  lea r14, [rax+0x28]
000078805cddba48  mov r11, [r13+r14*1]
000078805cddba4d  movq xmm12, r12
000078805cddba52  movq xmm11, r11
000078805cddba57  movq xmm12, xmm12
000078805cddba5c  vmovaps [rsp+0x30], xmm12
000078805cddba62  movq xmm12, xmm12
000078805cddba67  movaps [r15+0x150], xmm12
000078805cddba6f  movq xmm11, xmm11
000078805cddba74  vmovaps [rsp+0x40], xmm11
000078805cddba7a  movq xmm11, xmm11
000078805cddba7f  movaps [r15+0x140], xmm11
000078805cddba87  lea r14, [rax+0x10]
000078805cddba8b  mov r12, [r13+r14*1]
000078805cddba90  lea r14, [rax+0x18]
000078805cddba94  mov r11, [r13+r14*1]
000078805cddba99  movq xmm12, r12
000078805cddba9e  movq xmm11, r11
000078805cddbaa3  movq xmm12, xmm12
000078805cddbaa8  vmovaps [rsp+0x50], xmm12
000078805cddbaae  movq xmm12, xmm12
000078805cddbab3  movaps [r15+0x170], xmm12
000078805cddbabb  movq xmm11, xmm11
000078805cddbac0  vmovaps [rsp+0x60], xmm11
000078805cddbac6  movq xmm11, xmm11
000078805cddbacb  movaps [r15+0x160], xmm11
000078805cddbad3  mov r14, [r13+rax*1]
000078805cddbad8  vmovq xmm12, r14
000078805cddbadd  vpbroadcastq xmm12, xmm12
000078805cddbae2  lea r14, [rax+0x08]
000078805cddbae6  mov rax, [r13+r14*1]
000078805cddbaeb  movq xmm11, rax
000078805cddbaf0  movaps [r15+0x230], xmm11
000078805cddbaf8  mov rax, [r15+0xF8]
000078805cddbaff  lea r14, [rax+0x50]
000078805cddbb03  movups xmm11, [r13+r14*1]
000078805cddbb09  lea r14, [rax+0x60]
000078805cddbb0d  movups xmm10, [r13+r14*1]
000078805cddbb13  lea r14, [rax+0x30]
000078805cddbb17  movups xmm9, [r13+r14*1]
000078805cddbb1d  mov r14, [r15+0x50]
000078805cddbb21  mov [r15+0x60], r14
000078805cddbb25  mov qword ptr [r15+0x58], 0x40
000078805cddbb2d  movaps xmm8, xmm12
000078805cddbb31  mulpd xmm8, xmm15
000078805cddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000078805cddbb3c  ptest xmm7, xmm7
000078805cddbb41  jnz 0x000078805CDDC96A
000078805cddbb47  movq xmm15, qword ptr [r15+0x230]
000078805cddbb50  vmovaps [rsp+0x70], xmm15
000078805cddbb56  vpermilpd xmm15, xmm15, 0x00
000078805cddbb5c  movaps xmm7, xmm9
000078805cddbb60  mulpd xmm7, xmm15
000078805cddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000078805cddbb6a  ptest xmm6, xmm6
000078805cddbb6f  jnz 0x000078805CDDCAAE
000078805cddbb75  vxorps xmm15, xmm15, xmm15
000078805cddbb7a  vpbroadcastq xmm15, xmm15
000078805cddbb7f  movaps xmm9, xmm12
000078805cddbb83  mulpd xmm9, xmm10
000078805cddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000078805cddbb8e  ptest xmm6, xmm6
000078805cddbb93  jnz 0x000078805CDDCBF0
000078805cddbb99  movaps xmm10, xmm12
000078805cddbb9d  mulpd xmm10, xmm11
000078805cddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000078805cddbba8  ptest xmm6, xmm6
000078805cddbbad  jnz 0x000078805CDDCD34
000078805cddbbb3  movaps xmm11, [r15+0x1F0]
000078805cddbbbb  movaps xmm6, xmm12
000078805cddbbbf  mulpd xmm6, xmm11
000078805cddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000078805cddbbc9  ptest xmm5, xmm5
000078805cddbbce  jnz 0x000078805CDDCE78
000078805cddbbd4  movaps xmm12, [r15+0x2A0]
000078805cddbbdc  vmovaps [rsp+0x80], xmm12
000078805cddbbe5  vmovaps xmm11, [rsp+0x80]
000078805cddbbee  por xmm12, xmm11
000078805cddbbf3  movaps xmm11, [r15+0x250]
000078805cddbbfb  vmovaps [rsp+0x80], xmm11
000078805cddbc04  vmovaps xmm5, [rsp+0x80]
000078805cddbc0d  por xmm11, xmm5
000078805cddbc12  vmovaps xmm4, [rsp+0x70]
000078805cddbc18  vpermilpd xmm4, xmm4, 0x00
000078805cddbc1e  movaps xmm3, xmm5
000078805cddbc21  mulpd xmm3, xmm4
000078805cddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000078805cddbc2a  ptest xmm2, xmm2
000078805cddbc2f  jnz 0x000078805CDDCFBA
000078805cddbc35  mov [rsp+0x80], rax
000078805cddbc3d  xor eax, eax
000078805cddbc3f  mov r12d, 0x40
000078805cddbc45  mov r11d, 0x200
000078805cddbc4b  cmp r12, r11
000078805cddbc4e  cmc
000078805cddbc4f  lahf
000078805cddbc50  seto al
000078805cddbc53  mov [r15+0x108], eax
000078805cddbc5a  movaps xmm5, xmm8
000078805cddbc5e  addpd xmm5, xmm15
000078805cddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000078805cddbc68  ptest xmm4, xmm4
000078805cddbc6d  jnz 0x000078805CDDD0FA
000078805cddbc73  movaps xmm8, [r15+0x1B0]
000078805cddbc7b  movaps xmm4, xmm9
000078805cddbc7f  addpd xmm4, xmm8
000078805cddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000078805cddbc89  ptest xmm2, xmm2
000078805cddbc8e  jnz 0x000078805CDDD23C
000078805cddbc94  movaps xmm9, xmm10
000078805cddbc98  addpd xmm9, xmm8
000078805cddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000078805cddbca3  ptest xmm2, xmm2
000078805cddbca8  jnz 0x000078805CDDD37E
000078805cddbcae  movaps xmm10, [r15+0x2F0]
000078805cddbcb6  vmovaps [rsp+0x90], xmm10
000078805cddbcbf  vmovaps xmm8, [rsp+0x90]
000078805cddbcc8  por xmm10, xmm8
000078805cddbccd  movaps xmm8, [r15+0x2E0]
000078805cddbcd5  vmovaps [rsp+0x90], xmm8
000078805cddbcde  vmovaps xmm2, [rsp+0x90]
000078805cddbce7  por xmm8, xmm2
000078805cddbcec  movaps xmm2, [r15+0x2D0]
000078805cddbcf4  vmovaps [rsp+0x90], xmm2
000078805cddbcfd  vmovaps [rsp+0xA0], xmm1
000078805cddbd06  vmovaps xmm1, [rsp+0x90]
000078805cddbd0f  por xmm2, xmm1
000078805cddbd13  movaps xmm1, [r15+0x200]
000078805cddbd1b  vmovaps [rsp+0x90], xmm1
000078805cddbd24  vmovaps [rsp+0xB0], xmm15
000078805cddbd2d  vmovaps xmm15, [rsp+0x90]
000078805cddbd36  por xmm1, xmm15
000078805cddbd3b  movaps xmm15, [r15+0x1C0]
000078805cddbd43  vmovaps [rsp+0x90], xmm15
000078805cddbd4c  vmovaps [rsp+0xC0], xmm1
000078805cddbd55  vmovaps xmm1, [rsp+0x90]
000078805cddbd5e  por xmm15, xmm1
000078805cddbd63  movaps xmm1, [r15+0x190]
000078805cddbd6b  vmovaps [rsp+0x90], xmm1
000078805cddbd74  vmovaps [rsp+0xD0], xmm15
000078805cddbd7d  vmovaps xmm15, [rsp+0x90]
000078805cddbd86  por xmm1, xmm15
000078805cddbd8b  movaps xmm15, [r15+0x300]
000078805cddbd93  vmovaps [rsp+0x90], xmm15
000078805cddbd9c  vmovaps [rsp+0xE0], xmm1
000078805cddbda5  vmovaps xmm1, [rsp+0x90]
000078805cddbdae  por xmm15, xmm1
000078805cddbdb3  mov rax, [rsp+0x80]
000078805cddbdbb  lea r12, [rax+0xA0]
000078805cddbdc2  movups xmm1, [r13+r12*1]
000078805cddbdc8  lea r12, [rax+0xB0]
000078805cddbdcf  vmovaps [rsp+0x80], xmm1
000078805cddbdd8  movups xmm1, [r13+r12*1]
000078805cddbdde  vmovaps [rsp+0x90], xmm1
000078805cddbde7  vmovaps [rsp+0xF0], xmm15
000078805cddbdf0  vmovaps xmm15, [rsp+0xB0]
000078805cddbdf9  vmovaps [rsp+0xB0], xmm14
000078805cddbe02  movaps xmm1, xmm6
000078805cddbe05  addpd xmm1, xmm15
000078805cddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000078805cddbe0f  ptest xmm14, xmm14
000078805cddbe15  jnz 0x000078805CDDD4D6
000078805cddbe1b  lea r12, [rax+0xF0]
000078805cddbe22  movups xmm15, [r13+r12*1]
000078805cddbe28  movaps xmm14, xmm4
000078805cddbe2c  addpd xmm14, xmm3
000078805cddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000078805cddbe37  ptest xmm6, xmm6
000078805cddbe3c  jnz 0x000078805CDDD621
000078805cddbe42  movaps xmm6, xmm9
000078805cddbe46  addpd xmm6, xmm7
000078805cddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000078805cddbe4f  ptest xmm4, xmm4
000078805cddbe54  jnz 0x000078805CDDD763
000078805cddbe5a  vmovaps xmm9, [rsp+0x70]
000078805cddbe60  vpermilpd xmm9, xmm9, 0x00
000078805cddbe66  vmovaps xmm4, [rsp+0x90]
000078805cddbe6f  movaps xmm7, xmm4
000078805cddbe72  mulpd xmm7, xmm9
000078805cddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000078805cddbe7c  ptest xmm3, xmm3
000078805cddbe81  jnz 0x000078805CDDD8A4
000078805cddbe87  vmovaps xmm9, [rsp+0x50]
000078805cddbe8d  vpermilpd xmm9, xmm9, 0x00
000078805cddbe93  movaps xmm4, xmm15
000078805cddbe97  mulpd xmm4, xmm9
000078805cddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000078805cddbea1  ptest xmm3, xmm3
000078805cddbea6  jnz 0x000078805CDDD9E5
000078805cddbeac  lea r12, [rax+0xE0]
000078805cddbeb3  movups xmm15, [r13+r12*1]
000078805cddbeb9  vmovaps xmm9, [rsp+0x70]
000078805cddbebf  vpermilpd xmm9, xmm9, 0x00
000078805cddbec5  vmovaps [rsp+0x70], xmm1
000078805cddbecb  vmovaps xmm1, [rsp+0x80]
000078805cddbed4  vmovaps [rsp+0x80], xmm15
000078805cddbedd  movaps xmm3, xmm1
000078805cddbee0  mulpd xmm3, xmm9
000078805cddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000078805cddbeea  ptest xmm15, xmm15
000078805cddbef0  jnz 0x000078805CDDDB31
000078805cddbef6  vmovaps xmm1, [rsp+0xF0]
000078805cddbeff  vmovaps xmm15, [rsp+0xF0]
000078805cddbf08  por xmm1, xmm15
000078805cddbf0d  movaps [r15+0x300], xmm1
000078805cddbf15  vmovaps xmm15, [rsp+0xE0]
000078805cddbf1e  vmovaps xmm9, [rsp+0xE0]
000078805cddbf27  por xmm15, xmm9
000078805cddbf2c  movaps [r15+0x190], xmm15
000078805cddbf34  vmovaps xmm9, [rsp+0x50]
000078805cddbf3a  vpermilpd xmm9, xmm9, 0x00
000078805cddbf40  vmovaps [rsp+0x90], xmm1
000078805cddbf49  vmovaps [rsp+0xE0], xmm15
000078805cddbf52  vmovaps xmm15, [rsp+0x80]
000078805cddbf5b  vmovaps [rsp+0x80], xmm14
000078805cddbf64  movaps xmm1, xmm15
000078805cddbf68  mulpd xmm1, xmm9
000078805cddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000078805cddbf72  ptest xmm14, xmm14
000078805cddbf78  jnz 0x000078805CDDDC72
000078805cddbf7e  lea r12, [rax+0x90]
000078805cddbf85  movups xmm15, [r13+r12*1]
000078805cddbf8b  vmovaps xmm14, [rsp+0xD0]
000078805cddbf94  vmovaps xmm9, [rsp+0xD0]
000078805cddbf9d  por xmm14, xmm9
000078805cddbfa2  movaps [r15+0x1C0], xmm14
000078805cddbfaa  vmovaps xmm9, [rsp+0xC0]
000078805cddbfb3  vmovaps [rsp+0xD0], xmm1
000078805cddbfbc  vmovaps xmm1, [rsp+0xC0]
000078805cddbfc5  por xmm9, xmm1
000078805cddbfca  movaps [r15+0x200], xmm9
000078805cddbfd2  vmovaps [rsp+0xC0], xmm2
000078805cddbfdb  vmovaps xmm1, [rsp+0xC0]
000078805cddbfe4  por xmm2, xmm1
000078805cddbfe8  movaps [r15+0x2D0], xmm2
000078805cddbff0  vmovaps [rsp+0xC0], xmm8
000078805cddbff9  vmovaps xmm1, [rsp+0xC0]
000078805cddc002  por xmm8, xmm1
000078805cddc007  movaps [r15+0x2E0], xmm8
000078805cddc00f  vmovaps [rsp+0xC0], xmm15
000078805cddc018  movaps xmm1, xmm5
000078805cddc01b  addpd xmm1, xmm7
000078805cddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000078805cddc024  ptest xmm15, xmm15
000078805cddc02a  jnz 0x000078805CDDDDBE
000078805cddc030  vmovaps xmm15, [rsp+0x50]
000078805cddc036  vpermilpd xmm15, xmm15, 0x00
000078805cddc03c  vmovaps xmm5, [rsp+0xC0]
000078805cddc045  vmovaps [rsp+0xC0], xmm1
000078805cddc04e  movaps xmm7, xmm5
000078805cddc051  mulpd xmm7, xmm15
000078805cddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000078805cddc05b  ptest xmm1, xmm1
000078805cddc060  jnz 0x000078805CDDDEFE
000078805cddc066  lea r12, [rax+0x80]
000078805cddc06d  movups xmm1, [r13+r12*1]
000078805cddc073  vmovaps xmm5, [rsp+0x70]
000078805cddc079  vmovaps [rsp+0x70], xmm1
000078805cddc07f  movaps xmm15, xmm5
000078805cddc083  addpd xmm15, xmm3
000078805cddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cddc08e  ptest xmm1, xmm1
000078805cddc093  jnz 0x000078805CDDE049
000078805cddc099  vmovaps xmm5, [rsp+0x80]
000078805cddc0a2  movaps xmm1, xmm5
000078805cddc0a5  addpd xmm1, xmm4
000078805cddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000078805cddc0ae  ptest xmm3, xmm3
000078805cddc0b3  jnz 0x000078805CDDE18B
000078805cddc0b9  vmovaps [rsp+0x80], xmm10
000078805cddc0c2  vmovaps xmm5, [rsp+0x80]
000078805cddc0cb  por xmm10, xmm5
000078805cddc0d0  movaps [r15+0x2F0], xmm10
000078805cddc0d8  vmovaps xmm5, [rsp+0x50]
000078805cddc0de  vpermilpd xmm5, xmm5, 0x00
000078805cddc0e4  vmovaps xmm3, [rsp+0x70]
000078805cddc0ea  vmovaps [rsp+0x50], xmm1
000078805cddc0f0  movaps xmm4, xmm3
000078805cddc0f3  mulpd xmm4, xmm5
000078805cddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000078805cddc0fc  ptest xmm1, xmm1
000078805cddc101  jnz 0x000078805CDDE2CB
000078805cddc107  lea r12, [rax+0xD0]
000078805cddc10e  movups xmm1, [r13+r12*1]
000078805cddc114  vmovaps xmm3, [rsp+0xD0]
000078805cddc11d  vmovaps [rsp+0x70], xmm1
000078805cddc123  movaps xmm5, xmm6
000078805cddc126  addpd xmm5, xmm3
000078805cddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000078805cddc12f  ptest xmm1, xmm1
000078805cddc134  jnz 0x000078805CDDE415
000078805cddc13a  vmovaps xmm1, [rsp+0x60]
000078805cddc140  vpermilpd xmm1, xmm1, 0x00
000078805cddc146  movaps xmm6, xmm9
000078805cddc14a  mulpd xmm6, xmm1
000078805cddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000078805cddc153  ptest xmm3, xmm3
000078805cddc158  jnz 0x000078805CDDE555
000078805cddc15e  movaps [r15+0x260], xmm6
000078805cddc166  vxorps xmm1, xmm1, xmm1
000078805cddc16a  vpbroadcastq xmm1, xmm1
000078805cddc16f  movaps [r15+0x1B0], xmm1
000078805cddc177  vmovaps xmm1, [rsp+0x60]
000078805cddc17d  vpermilpd xmm1, xmm1, 0x00
000078805cddc183  vmovaps xmm3, [rsp+0x70]
000078805cddc189  vmovaps [rsp+0x70], xmm15
000078805cddc18f  movaps xmm9, xmm3
000078805cddc193  mulpd xmm9, xmm1
000078805cddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000078805cddc19e  ptest xmm15, xmm15
000078805cddc1a4  jnz 0x000078805CDDE696
000078805cddc1aa  lea r12, [rax+0xC0]
000078805cddc1b1  movups xmm1, [r13+r12*1]
000078805cddc1b7  vmovaps xmm3, [rsp+0xC0]
000078805cddc1c0  vmovaps [rsp+0x80], xmm1
000078805cddc1c9  movaps xmm15, xmm3
000078805cddc1cd  addpd xmm15, xmm7
000078805cddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cddc1d8  ptest xmm1, xmm1
000078805cddc1dd  jnz 0x000078805CDDE7E2
000078805cddc1e3  vmovaps [rsp+0xC0], xmm13
000078805cddc1ec  vmovaps xmm1, [rsp+0xC0]
000078805cddc1f5  por xmm13, xmm1
000078805cddc1fa  movaps [r15+0x270], xmm13
000078805cddc202  vmovaps xmm1, [rsp+0xB0]
000078805cddc20b  vmovaps xmm7, [rsp+0xB0]
000078805cddc214  por xmm1, xmm7
000078805cddc218  movaps [r15+0x1A0], xmm1
000078805cddc220  vmovaps xmm1, [rsp+0x60]
000078805cddc226  vpermilpd xmm1, xmm1, 0x00
000078805cddc22c  vmovaps [rsp+0xB0], xmm1
000078805cddc235  vmovaps xmm1, [rsp+0x80]
000078805cddc23e  vmovaps [rsp+0x80], xmm15
000078805cddc247  vmovaps xmm15, [rsp+0xB0]
000078805cddc250  vmovaps [rsp+0xB0], xmm14
000078805cddc259  movaps xmm3, xmm1
000078805cddc25c  mulpd xmm3, xmm15
000078805cddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000078805cddc266  ptest xmm14, xmm14
000078805cddc26c  jnz 0x000078805CDDE924
000078805cddc272  lea r12, [rax+0x20]
000078805cddc276  movups xmm1, [r13+r12*1]
000078805cddc27c  movaps [r15+0x110], xmm1
000078805cddc284  vmovaps xmm14, [rsp+0x70]
000078805cddc28a  vmovaps [rsp+0x70], xmm1
000078805cddc290  movaps xmm15, xmm14
000078805cddc294  addpd xmm15, xmm4
000078805cddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000078805cddc29f  ptest xmm1, xmm1
000078805cddc2a4  jnz 0x000078805CDDEA6F
000078805cddc2aa  vmovaps xmm1, [rsp+0x60]
000078805cddc2b0  vpermilpd xmm1, xmm1, 0x00
000078805cddc2b6  movaps xmm14, xmm2
000078805cddc2ba  mulpd xmm14, xmm1
000078805cddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000078805cddc2c5  ptest xmm4, xmm4
000078805cddc2ca  jnz 0x000078805CDDEBB2
000078805cddc2d0  vmovaps xmm4, [rsp+0x50]
000078805cddc2d6  movaps xmm1, xmm4
000078805cddc2d9  addpd xmm1, xmm9
000078805cddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000078805cddc2e3  ptest xmm2, xmm2
000078805cddc2e8  jnz 0x000078805CDDECF4
000078805cddc2ee  vmovaps xmm9, [rsp+0x30]
000078805cddc2f4  vpermilpd xmm9, xmm9, 0x00
000078805cddc2fa  vmovaps xmm2, [rsp+0x70]
000078805cddc300  vmovaps [rsp+0x50], xmm1
000078805cddc306  movaps xmm4, xmm2
000078805cddc309  mulpd xmm4, xmm9
000078805cddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000078805cddc313  ptest xmm1, xmm1
000078805cddc318  jnz 0x000078805CDDEE35
000078805cddc31e  vmovaps xmm1, [rsp+0x30]
000078805cddc324  vpermilpd xmm1, xmm1, 0x00
000078805cddc32a  vmovaps xmm2, [rsp+0x90]
000078805cddc333  vmovaps [rsp+0x60], xmm15
000078805cddc339  movaps xmm9, xmm2
000078805cddc33d  mulpd xmm9, xmm1
000078805cddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000078805cddc348  ptest xmm15, xmm15
000078805cddc34e  jnz 0x000078805CDDEF76
000078805cddc354  vmovaps xmm15, [rsp+0x80]
000078805cddc35d  movaps xmm1, xmm15
000078805cddc361  addpd xmm1, xmm6
000078805cddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000078805cddc36a  ptest xmm2, xmm2
000078805cddc36f  jnz 0x000078805CDDF0B8
000078805cddc375  movaps xmm15, xmm5
000078805cddc379  addpd xmm15, xmm3
000078805cddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000078805cddc384  ptest xmm6, xmm6
000078805cddc389  jnz 0x000078805CDDF1F9
000078805cddc38f  vmovaps xmm6, [rsp+0x30]
000078805cddc395  vpermilpd xmm6, xmm6, 0x00
000078805cddc39b  movaps xmm5, xmm8
000078805cddc39f  mulpd xmm5, xmm6
000078805cddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000078805cddc3a8  ptest xmm3, xmm3
000078805cddc3ad  jnz 0x000078805CDDF33B
000078805cddc3b3  vmovaps xmm8, [rsp+0x30]
000078805cddc3b9  vpermilpd xmm8, xmm8, 0x00
000078805cddc3bf  movaps xmm6, xmm10
000078805cddc3c3  mulpd xmm6, xmm8
000078805cddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000078805cddc3cd  ptest xmm3, xmm3
000078805cddc3d2  jnz 0x000078805CDDF47C
000078805cddc3d8  vmovaps xmm8, [rsp+0x60]
000078805cddc3de  movaps xmm10, xmm8
000078805cddc3e2  addpd xmm10, xmm14
000078805cddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000078805cddc3ed  ptest xmm3, xmm3
000078805cddc3f2  jnz 0x000078805CDDF5BE
000078805cddc3f8  vmovaps xmm8, [rsp+0x50]
000078805cddc3fe  movaps xmm14, xmm8
000078805cddc402  addpd xmm14, xmm4
000078805cddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000078805cddc40d  ptest xmm3, xmm3
000078805cddc412  jnz 0x000078805CDDF702
000078805cddc418  vmovaps xmm8, [rsp+0x40]
000078805cddc41e  vpermilpd xmm8, xmm8, 0x00
000078805cddc424  movaps xmm4, xmm13
000078805cddc428  mulpd xmm4, xmm8
000078805cddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000078805cddc432  ptest xmm3, xmm3
000078805cddc437  jnz 0x000078805CDDF845
000078805cddc43d  movaps xmm13, xmm15
000078805cddc441  addpd xmm13, xmm9
000078805cddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000078805cddc44c  ptest xmm8, xmm8
000078805cddc452  jnz 0x000078805CDDF987
000078805cddc458  movaps xmm15, xmm1
000078805cddc45c  addpd xmm15, xmm5
000078805cddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000078805cddc467  ptest xmm9, xmm9
000078805cddc46d  jnz 0x000078805CDDFACB
000078805cddc473  vmovaps [rsp+0x30], xmm11
000078805cddc479  vmovaps xmm1, [rsp+0x30]
000078805cddc47f  por xmm11, xmm1
000078805cddc484  movaps [r15+0x250], xmm11
000078805cddc48c  vmovaps [rsp+0x30], xmm12
000078805cddc492  vmovaps xmm1, [rsp+0x30]
000078805cddc498  por xmm12, xmm1
000078805cddc49d  movaps [r15+0x2A0], xmm12
000078805cddc4a5  vmovaps xmm1, [rsp+0xA0]
000078805cddc4ae  vmovaps xmm11, [rsp+0xA0]
000078805cddc4b7  por xmm1, xmm11
000078805cddc4bc  movaps [r15+0x1D0], xmm1
000078805cddc4c4  lea r12, [rax+0x40]
000078805cddc4c8  movups xmm1, [r13+r12*1]
000078805cddc4ce  movaps [r15+0x2C0], xmm1
000078805cddc4d6  vmovaps xmm11, [rsp+0x40]
000078805cddc4dc  vpermilpd xmm11, xmm11, 0x00
000078805cddc4e2  vmovaps xmm8, [rsp+0xE0]
000078805cddc4eb  movaps xmm9, xmm8
000078805cddc4ef  mulpd xmm9, xmm11
000078805cddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000078805cddc4fa  ptest xmm5, xmm5
000078805cddc4ff  jnz 0x000078805CDDFC17
000078805cddc505  movaps xmm11, xmm10
000078805cddc509  addpd xmm11, xmm6
000078805cddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000078805cddc514  ptest xmm8, xmm8
000078805cddc51a  jnz 0x000078805CDDFD5B
000078805cddc520  movaps xmm10, xmm14
000078805cddc524  addpd xmm10, xmm4
000078805cddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000078805cddc52f  ptest xmm8, xmm8
000078805cddc535  jnz 0x000078805CDDFE9E
000078805cddc53b  vmovaps xmm14, [rsp+0x40]
000078805cddc541  vpermilpd xmm14, xmm14, 0x00
000078805cddc547  movaps xmm8, xmm1
000078805cddc54b  mulpd xmm8, xmm14
000078805cddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000078805cddc556  ptest xmm6, xmm6
000078805cddc55b  jnz 0x000078805CDDFFE1
000078805cddc561  movaps xmm1, [r15+0x2B0]
000078805cddc569  vmovaps xmm14, [rsp+0x40]
000078805cddc56f  vpermilpd xmm14, xmm14, 0x00
000078805cddc575  movaps xmm6, xmm1
000078805cddc578  mulpd xmm6, xmm14
000078805cddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000078805cddc582  ptest xmm5, xmm5
000078805cddc587  jnz 0x000078805CDE0124
000078805cddc58d  vmovaps xmm1, [rsp+0x10]
000078805cddc593  vpermilpd xmm1, xmm1, 0x00
000078805cddc599  movaps xmm14, xmm12
000078805cddc59d  mulpd xmm14, xmm1
000078805cddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000078805cddc5a8  ptest xmm5, xmm5
000078805cddc5ad  jnz 0x000078805CDE0265
000078805cddc5b3  movaps xmm1, xmm13
000078805cddc5b7  addpd xmm1, xmm9
000078805cddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000078805cddc5c1  ptest xmm12, xmm12
000078805cddc5c7  jnz 0x000078805CDE03A8
000078805cddc5cd  vmovaps xmm13, [rsp+0x10]
000078805cddc5d3  vpermilpd xmm13, xmm13, 0x00
000078805cddc5d9  movaps xmm12, xmm7
000078805cddc5dd  mulpd xmm12, xmm13
000078805cddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000078805cddc5e8  ptest xmm9, xmm9
000078805cddc5ee  jnz 0x000078805CDE04EA
000078805cddc5f4  movaps xmm13, xmm15
000078805cddc5f8  addpd xmm13, xmm8
000078805cddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000078805cddc603  ptest xmm9, xmm9
000078805cddc609  jnz 0x000078805CDE062D
000078805cddc60f  movaps xmm15, [r15+0x290]
000078805cddc617  vmovaps xmm9, [rsp+0x10]
000078805cddc61d  vpermilpd xmm9, xmm9, 0x00
000078805cddc623  movaps xmm8, xmm15
000078805cddc627  mulpd xmm8, xmm9
000078805cddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000078805cddc632  ptest xmm7, xmm7
000078805cddc637  jnz 0x000078805CDE0771
000078805cddc63d  movaps xmm15, xmm11
000078805cddc641  addpd xmm15, xmm6
000078805cddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000078805cddc64c  ptest xmm9, xmm9
000078805cddc652  jnz 0x000078805CDE08B5
000078805cddc658  movaps xmm11, [r15+0x1E0]
000078805cddc660  vmovaps xmm9, [rsp+0x10]
000078805cddc666  vpermilpd xmm9, xmm9, 0x00
000078805cddc66c  movaps xmm7, xmm11
000078805cddc670  mulpd xmm7, xmm9
000078805cddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000078805cddc67a  ptest xmm6, xmm6
000078805cddc67f  jnz 0x000078805CDE09F8
000078805cddc685  movaps xmm11, xmm10
000078805cddc689  addpd xmm11, xmm14
000078805cddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000078805cddc694  ptest xmm9, xmm9
000078805cddc69a  jnz 0x000078805CDE0B3A
000078805cddc6a0  lea r12, [rax+0x70]
000078805cddc6a4  movups xmm14, [r13+r12*1]
000078805cddc6aa  movaps [r15+0x240], xmm14
000078805cddc6b2  movaps xmm10, xmm1
000078805cddc6b6  addpd xmm10, xmm12
000078805cddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000078805cddc6c1  ptest xmm9, xmm9
000078805cddc6c7  jnz 0x000078805CDE0C88
000078805cddc6cd  movaps [r15+0x170], xmm10
000078805cddc6d5  vmovaps xmm1, [rsp+0x20]
000078805cddc6db  vpermilpd xmm1, xmm1, 0x00
000078805cddc6e1  movaps xmm12, xmm14
000078805cddc6e5  mulpd xmm12, xmm1
000078805cddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000078805cddc6f0  ptest xmm9, xmm9
000078805cddc6f6  jnz 0x000078805CDE0DCB
000078805cddc6fc  vmovaps xmm1, [rsp+0x20]
000078805cddc702  vpermilpd xmm1, xmm1, 0x00
000078805cddc708  vmovaps xmm9, [rsp+0xB0]
000078805cddc711  movaps xmm14, xmm9
000078805cddc715  mulpd xmm14, xmm1
000078805cddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000078805cddc720  ptest xmm6, xmm6
000078805cddc725  jnz 0x000078805CDE0F0E
000078805cddc72b  movaps [r15+0x180], xmm14
000078805cddc733  movaps xmm1, xmm13
000078805cddc737  addpd xmm1, xmm8
000078805cddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000078805cddc741  ptest xmm9, xmm9
000078805cddc747  jnz 0x000078805CDE1051
000078805cddc74d  movaps [r15+0x210], xmm1
000078805cddc755  movups xmm13, [r13+rax*1]
000078805cddc75b  lea r12, [rax+0x10]
000078805cddc75f  movups xmm9, [r13+r12*1]
000078805cddc765  movaps [r15+0x230], xmm9
000078805cddc76d  movaps xmm8, xmm15
000078805cddc771  addpd xmm8, xmm7
000078805cddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000078805cddc77c  ptest xmm6, xmm6
000078805cddc781  jnz 0x000078805CDE11A7
000078805cddc787  movaps [r15+0x130], xmm8
000078805cddc78f  vmovaps xmm15, [rsp+0x20]
000078805cddc795  vpermilpd xmm15, xmm15, 0x00
000078805cddc79b  movaps xmm7, xmm9
000078805cddc79f  mulpd xmm7, xmm15
000078805cddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000078805cddc7a9  ptest xmm6, xmm6
000078805cddc7ae  jnz 0x000078805CDE12EA
000078805cddc7b4  movaps [r15+0x220], xmm7
000078805cddc7bc  vmovaps xmm15, [rsp+0x20]
000078805cddc7c2  vpermilpd xmm15, xmm15, 0x00
000078805cddc7c8  movaps xmm9, xmm13
000078805cddc7cc  mulpd xmm9, xmm15
000078805cddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000078805cddc7d7  ptest xmm6, xmm6
000078805cddc7dc  jnz 0x000078805CDE142C
000078805cddc7e2  movaps xmm15, xmm11
000078805cddc7e6  addpd xmm15, xmm12
000078805cddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000078805cddc7f1  ptest xmm13, xmm13
000078805cddc7f7  jnz 0x000078805CDE1570
000078805cddc7fd  movaps [r15+0x140], xmm15
000078805cddc805  movaps xmm13, xmm10
000078805cddc809  addpd xmm13, xmm14
000078805cddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000078805cddc814  ptest xmm12, xmm12
000078805cddc81a  jnz 0x000078805CDE16B4
000078805cddc820  movaps [r15+0x150], xmm13
000078805cddc828  movaps xmm14, xmm1
000078805cddc82c  addpd xmm14, xmm7
000078805cddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000078805cddc837  ptest xmm12, xmm12
000078805cddc83d  jnz 0x000078805CDE17F8
000078805cddc843  movaps [r15+0x160], xmm14
000078805cddc84b  movaps xmm1, xmm8
000078805cddc84f  addpd xmm1, xmm9
000078805cddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000078805cddc859  ptest xmm12, xmm12
000078805cddc85f  jnz 0x000078805CDE193A
000078805cddc865  movaps [r15+0x120], xmm1
000078805cddc86d  movups [r13+r14*1], xmm15
000078805cddc873  lea rax, [r14+0x10]
000078805cddc877  movups [r13+rax*1], xmm13
000078805cddc87d  lea rax, [r14+0x20]
000078805cddc881  movups [r13+rax*1], xmm14
000078805cddc887  lea rax, [r14+0x30]
000078805cddc88b  movups [r13+rax*1], xmm1
000078805cddc891  mov eax, [r15+0x108]
000078805cddc898  sahf
000078805cddc899  jnz 0x000078805CDDC8CB
000078805cddc89b  cmp dword ptr [r15+0x318], 0x00
000078805cddc8a3  jz 0x000078805CDDB900
000078805cddc8a9  nop [rax+rax*1], ax
000078805cddc8b2  nop [rax+rax*1], eax
000078805cddc8ba  mov eax, 0x410444
000078805cddc8bf  mov [r15+0x100], rax
000078805cddc8c6  jmp 0x000078805CBFE110
000078805cddc8cb  cmp dword ptr [r15+0x318], 0x00
000078805cddc8d3  jz 0x000078805CDD57E0
000078805cddc8d9  nop [rax+rax*1], ax
000078805cddc8e2  nop [rax+rax*1], eax
000078805cddc8ea  mov eax, 0x410278
000078805cddc8ef  mov [r15+0x100], rax
000078805cddc8f6  jmp 0x000078805CBFE110
000078805cddc8fb  int3
000078805cddc8fc  call 0x000078805CCE27E0
000078805cddc901  jmp 0x000078805CDDB9DF
000078805cddc906  call 0x000078805CCE1570
000078805cddc90b  jmp 0x000078805CDDB9E8
000078805cddc910  call 0x000078805CCE27E0
000078805cddc915  jmp 0x000078805CDDBA44
000078805cddc91a  call 0x000078805CCE1570
000078805cddc91f  jmp 0x000078805CDDBA4D
000078805cddc924  call 0x000078805CCE27E0
000078805cddc929  jmp 0x000078805CDDBA90
000078805cddc92e  call 0x000078805CCE1570
000078805cddc933  jmp 0x000078805CDDBA99
000078805cddc938  call 0x000078805CC0DC20
000078805cddc93d  jmp 0x000078805CDDBAD8
000078805cddc942  call 0x000078805CCD59C0
000078805cddc947  jmp 0x000078805CDDBAEB
000078805cddc94c  call 0x000078805CCE0E30
000078805cddc951  jmp 0x000078805CDDBB09
000078805cddc956  call 0x000078805CCDFBC0
000078805cddc95b  jmp 0x000078805CDDBB13
000078805cddc960  call 0x000078805CCDE950
000078805cddc965  jmp 0x000078805CDDBB1D
000078805cddc96a  sub rsp, 0x08
000078805cddc96e  push rax
000078805cddc96f  push rcx
000078805cddc970  push rdx
000078805cddc971  push rdi
000078805cddc972  push rsi
000078805cddc973  push r8
000078805cddc975  push r9
000078805cddc977  push r10
000078805cddc979  push r11
000078805cddc97b  sub rsp, 0xF0
000078805cddc982  vmovaps [rsp], xmm0
000078805cddc987  vmovaps [rsp+0x10], xmm1
000078805cddc98d  vmovaps [rsp+0x20], xmm2
000078805cddc993  vmovaps [rsp+0x30], xmm3
000078805cddc999  vmovaps [rsp+0x40], xmm4
000078805cddc99f  vmovaps [rsp+0x50], xmm5
000078805cddc9a5  vmovaps [rsp+0x60], xmm6
000078805cddc9ab  vmovaps [rsp+0x70], xmm7
000078805cddc9b1  vmovaps [rsp+0x80], xmm9
000078805cddc9ba  vmovaps [rsp+0x90], xmm10
000078805cddc9c3  vmovaps [rsp+0xA0], xmm11
000078805cddc9cc  vmovaps [rsp+0xB0], xmm12
000078805cddc9d5  vmovaps [rsp+0xC0], xmm13
000078805cddc9de  vmovaps [rsp+0xD0], xmm14
000078805cddc9e7  vmovaps [rsp+0xE0], xmm15
000078805cddc9f0  sub rsp, 0x30
000078805cddc9f4  movaps [rsp], xmm8
000078805cddc9f9  movaps [rsp+0x10], xmm12
000078805cddc9ff  movaps [rsp+0x20], xmm15
000078805cddca05  lea rdi, [rsp]
000078805cddca09  mov esi, 0x00
000078805cddca0e  mov rax, 0x5771AD6EA530
000078805cddca18  call rax
000078805cddca1a  movaps xmm8, [rsp]
000078805cddca1f  add rsp, 0x30
000078805cddca23  vmovaps xmm0, [rsp]
000078805cddca28  vmovaps xmm1, [rsp+0x10]
000078805cddca2e  vmovaps xmm2, [rsp+0x20]
000078805cddca34  vmovaps xmm3, [rsp+0x30]
000078805cddca3a  vmovaps xmm4, [rsp+0x40]
000078805cddca40  vmovaps xmm5, [rsp+0x50]
000078805cddca46  vmovaps xmm6, [rsp+0x60]
000078805cddca4c  vmovaps xmm7, [rsp+0x70]
000078805cddca52  vmovaps xmm9, [rsp+0x80]
000078805cddca5b  vmovaps xmm10, [rsp+0x90]
000078805cddca64  vmovaps xmm11, [rsp+0xA0]
000078805cddca6d  vmovaps xmm12, [rsp+0xB0]
000078805cddca76  vmovaps xmm13, [rsp+0xC0]
000078805cddca7f  vmovaps xmm14, [rsp+0xD0]
000078805cddca88  vmovaps xmm15, [rsp+0xE0]
000078805cddca91  add rsp, 0xF0
000078805cddca98  pop r11
000078805cddca9a  pop r10
000078805cddca9c  pop r9
000078805cddca9e  pop r8
000078805cddcaa0  pop rsi
000078805cddcaa1  pop rdi
000078805cddcaa2  pop rdx
000078805cddcaa3  pop rcx
000078805cddcaa4  pop rax
000078805cddcaa5  add rsp, 0x08
000078805cddcaa9  jmp 0x000078805CDDBB47
000078805cddcaae  sub rsp, 0x08
000078805cddcab2  push rax
000078805cddcab3  push rcx
000078805cddcab4  push rdx
000078805cddcab5  push rdi
000078805cddcab6  push rsi
000078805cddcab7  push r8
000078805cddcab9  push r9
000078805cddcabb  push r10
000078805cddcabd  push r11
000078805cddcabf  sub rsp, 0xF0
000078805cddcac6  vmovaps [rsp], xmm0
000078805cddcacb  vmovaps [rsp+0x10], xmm1
000078805cddcad1  vmovaps [rsp+0x20], xmm2
000078805cddcad7  vmovaps [rsp+0x30], xmm3
000078805cddcadd  vmovaps [rsp+0x40], xmm4
000078805cddcae3  vmovaps [rsp+0x50], xmm5
000078805cddcae9  vmovaps [rsp+0x60], xmm6
000078805cddcaef  vmovaps [rsp+0x70], xmm8
000078805cddcaf5  vmovaps [rsp+0x80], xmm9
000078805cddcafe  vmovaps [rsp+0x90], xmm10
000078805cddcb07  vmovaps [rsp+0xA0], xmm11
000078805cddcb10  vmovaps [rsp+0xB0], xmm12
000078805cddcb19  vmovaps [rsp+0xC0], xmm13
000078805cddcb22  vmovaps [rsp+0xD0], xmm14
000078805cddcb2b  vmovaps [rsp+0xE0], xmm15
000078805cddcb34  sub rsp, 0x30
000078805cddcb38  movaps [rsp], xmm7
000078805cddcb3c  movaps [rsp+0x10], xmm9
000078805cddcb42  movaps [rsp+0x20], xmm15
000078805cddcb48  lea rdi, [rsp]
000078805cddcb4c  mov esi, 0x00
000078805cddcb51  mov rax, 0x5771AD6EA530
000078805cddcb5b  call rax
000078805cddcb5d  movaps xmm7, [rsp]
000078805cddcb61  add rsp, 0x30
000078805cddcb65  vmovaps xmm0, [rsp]
000078805cddcb6a  vmovaps xmm1, [rsp+0x10]
000078805cddcb70  vmovaps xmm2, [rsp+0x20]
000078805cddcb76  vmovaps xmm3, [rsp+0x30]
000078805cddcb7c  vmovaps xmm4, [rsp+0x40]
000078805cddcb82  vmovaps xmm5, [rsp+0x50]
000078805cddcb88  vmovaps xmm6, [rsp+0x60]
000078805cddcb8e  vmovaps xmm8, [rsp+0x70]
000078805cddcb94  vmovaps xmm9, [rsp+0x80]
000078805cddcb9d  vmovaps xmm10, [rsp+0x90]
000078805cddcba6  vmovaps xmm11, [rsp+0xA0]
000078805cddcbaf  vmovaps xmm12, [rsp+0xB0]
000078805cddcbb8  vmovaps xmm13, [rsp+0xC0]
000078805cddcbc1  vmovaps xmm14, [rsp+0xD0]
000078805cddcbca  vmovaps xmm15, [rsp+0xE0]
000078805cddcbd3  add rsp, 0xF0
000078805cddcbda  pop r11
000078805cddcbdc  pop r10
000078805cddcbde  pop r9
000078805cddcbe0  pop r8
000078805cddcbe2  pop rsi
000078805cddcbe3  pop rdi
000078805cddcbe4  pop rdx
000078805cddcbe5  pop rcx
000078805cddcbe6  pop rax
000078805cddcbe7  add rsp, 0x08
000078805cddcbeb  jmp 0x000078805CDDBB75
000078805cddcbf0  sub rsp, 0x08
000078805cddcbf4  push rax
000078805cddcbf5  push rcx
000078805cddcbf6  push rdx
000078805cddcbf7  push rdi
000078805cddcbf8  push rsi
000078805cddcbf9  push r8
000078805cddcbfb  push r9
000078805cddcbfd  push r10
000078805cddcbff  push r11
000078805cddcc01  sub rsp, 0xF0
000078805cddcc08  vmovaps [rsp], xmm0
000078805cddcc0d  vmovaps [rsp+0x10], xmm1
000078805cddcc13  vmovaps [rsp+0x20], xmm2
000078805cddcc19  vmovaps [rsp+0x30], xmm3
000078805cddcc1f  vmovaps [rsp+0x40], xmm4
000078805cddcc25  vmovaps [rsp+0x50], xmm5
000078805cddcc2b  vmovaps [rsp+0x60], xmm6
000078805cddcc31  vmovaps [rsp+0x70], xmm7
000078805cddcc37  vmovaps [rsp+0x80], xmm8
000078805cddcc40  vmovaps [rsp+0x90], xmm10
000078805cddcc49  vmovaps [rsp+0xA0], xmm11
000078805cddcc52  vmovaps [rsp+0xB0], xmm12
000078805cddcc5b  vmovaps [rsp+0xC0], xmm13
000078805cddcc64  vmovaps [rsp+0xD0], xmm14
000078805cddcc6d  vmovaps [rsp+0xE0], xmm15
000078805cddcc76  sub rsp, 0x30
000078805cddcc7a  movaps [rsp], xmm9
000078805cddcc7f  movaps [rsp+0x10], xmm12
000078805cddcc85  movaps [rsp+0x20], xmm10
000078805cddcc8b  lea rdi, [rsp]
000078805cddcc8f  mov esi, 0x00
000078805cddcc94  mov rax, 0x5771AD6EA530
000078805cddcc9e  call rax
000078805cddcca0  movaps xmm9, [rsp]
000078805cddcca5  add rsp, 0x30
000078805cddcca9  vmovaps xmm0, [rsp]
000078805cddccae  vmovaps xmm1, [rsp+0x10]
000078805cddccb4  vmovaps xmm2, [rsp+0x20]
000078805cddccba  vmovaps xmm3, [rsp+0x30]
000078805cddccc0  vmovaps xmm4, [rsp+0x40]
000078805cddccc6  vmovaps xmm5, [rsp+0x50]
000078805cddcccc  vmovaps xmm6, [rsp+0x60]
000078805cddccd2  vmovaps xmm7, [rsp+0x70]
000078805cddccd8  vmovaps xmm8, [rsp+0x80]
000078805cddcce1  vmovaps xmm10, [rsp+0x90]
000078805cddccea  vmovaps xmm11, [rsp+0xA0]
000078805cddccf3  vmovaps xmm12, [rsp+0xB0]
000078805cddccfc  vmovaps xmm13, [rsp+0xC0]
000078805cddcd05  vmovaps xmm14, [rsp+0xD0]
000078805cddcd0e  vmovaps xmm15, [rsp+0xE0]
000078805cddcd17  add rsp, 0xF0
000078805cddcd1e  pop r11
000078805cddcd20  pop r10
000078805cddcd22  pop r9
000078805cddcd24  pop r8
000078805cddcd26  pop rsi
000078805cddcd27  pop rdi
000078805cddcd28  pop rdx
000078805cddcd29  pop rcx
000078805cddcd2a  pop rax
000078805cddcd2b  add rsp, 0x08
000078805cddcd2f  jmp 0x000078805CDDBB99
000078805cddcd34  sub rsp, 0x08
000078805cddcd38  push rax
000078805cddcd39  push rcx
000078805cddcd3a  push rdx
000078805cddcd3b  push rdi
000078805cddcd3c  push rsi
000078805cddcd3d  push r8
000078805cddcd3f  push r9
000078805cddcd41  push r10
000078805cddcd43  push r11
000078805cddcd45  sub rsp, 0xF0
000078805cddcd4c  vmovaps [rsp], xmm0
000078805cddcd51  vmovaps [rsp+0x10], xmm1
000078805cddcd57  vmovaps [rsp+0x20], xmm2
000078805cddcd5d  vmovaps [rsp+0x30], xmm3
000078805cddcd63  vmovaps [rsp+0x40], xmm4
000078805cddcd69  vmovaps [rsp+0x50], xmm5
000078805cddcd6f  vmovaps [rsp+0x60], xmm6
000078805cddcd75  vmovaps [rsp+0x70], xmm7
000078805cddcd7b  vmovaps [rsp+0x80], xmm8
000078805cddcd84  vmovaps [rsp+0x90], xmm9
000078805cddcd8d  vmovaps [rsp+0xA0], xmm11
000078805cddcd96  vmovaps [rsp+0xB0], xmm12
000078805cddcd9f  vmovaps [rsp+0xC0], xmm13
000078805cddcda8  vmovaps [rsp+0xD0], xmm14
000078805cddcdb1  vmovaps [rsp+0xE0], xmm15
000078805cddcdba  sub rsp, 0x30
000078805cddcdbe  movaps [rsp], xmm10
000078805cddcdc3  movaps [rsp+0x10], xmm12
000078805cddcdc9  movaps [rsp+0x20], xmm11
000078805cddcdcf  lea rdi, [rsp]
000078805cddcdd3  mov esi, 0x00
000078805cddcdd8  mov rax, 0x5771AD6EA530
000078805cddcde2  call rax
000078805cddcde4  movaps xmm10, [rsp]
000078805cddcde9  add rsp, 0x30
000078805cddcded  vmovaps xmm0, [rsp]
000078805cddcdf2  vmovaps xmm1, [rsp+0x10]
000078805cddcdf8  vmovaps xmm2, [rsp+0x20]
000078805cddcdfe  vmovaps xmm3, [rsp+0x30]
000078805cddce04  vmovaps xmm4, [rsp+0x40]
000078805cddce0a  vmovaps xmm5, [rsp+0x50]
000078805cddce10  vmovaps xmm6, [rsp+0x60]
000078805cddce16  vmovaps xmm7, [rsp+0x70]
000078805cddce1c  vmovaps xmm8, [rsp+0x80]
000078805cddce25  vmovaps xmm9, [rsp+0x90]
000078805cddce2e  vmovaps xmm11, [rsp+0xA0]
000078805cddce37  vmovaps xmm12, [rsp+0xB0]
000078805cddce40  vmovaps xmm13, [rsp+0xC0]
000078805cddce49  vmovaps xmm14, [rsp+0xD0]
000078805cddce52  vmovaps xmm15, [rsp+0xE0]
000078805cddce5b  add rsp, 0xF0
000078805cddce62  pop r11
000078805cddce64  pop r10
000078805cddce66  pop r9
000078805cddce68  pop r8
000078805cddce6a  pop rsi
000078805cddce6b  pop rdi
000078805cddce6c  pop rdx
000078805cddce6d  pop rcx
000078805cddce6e  pop rax
000078805cddce6f  add rsp, 0x08
000078805cddce73  jmp 0x000078805CDDBBB3
000078805cddce78  sub rsp, 0x08
000078805cddce7c  push rax
000078805cddce7d  push rcx
000078805cddce7e  push rdx
000078805cddce7f  push rdi
000078805cddce80  push rsi
000078805cddce81  push r8
000078805cddce83  push r9
000078805cddce85  push r10
000078805cddce87  push r11
000078805cddce89  sub rsp, 0xF0
000078805cddce90  vmovaps [rsp], xmm0
000078805cddce95  vmovaps [rsp+0x10], xmm1
000078805cddce9b  vmovaps [rsp+0x20], xmm2
000078805cddcea1  vmovaps [rsp+0x30], xmm3
000078805cddcea7  vmovaps [rsp+0x40], xmm4
000078805cddcead  vmovaps [rsp+0x50], xmm5
000078805cddceb3  vmovaps [rsp+0x60], xmm7
000078805cddceb9  vmovaps [rsp+0x70], xmm8
000078805cddcebf  vmovaps [rsp+0x80], xmm9
000078805cddcec8  vmovaps [rsp+0x90], xmm10
000078805cddced1  vmovaps [rsp+0xA0], xmm11
000078805cddceda  vmovaps [rsp+0xB0], xmm12
000078805cddcee3  vmovaps [rsp+0xC0], xmm13
000078805cddceec  vmovaps [rsp+0xD0], xmm14
000078805cddcef5  vmovaps [rsp+0xE0], xmm15
000078805cddcefe  sub rsp, 0x30
000078805cddcf02  movaps [rsp], xmm6
000078805cddcf06  movaps [rsp+0x10], xmm12
000078805cddcf0c  movaps [rsp+0x20], xmm11
000078805cddcf12  lea rdi, [rsp]
000078805cddcf16  mov esi, 0x00
000078805cddcf1b  mov rax, 0x5771AD6EA530
000078805cddcf25  call rax
000078805cddcf27  movaps xmm6, [rsp]
000078805cddcf2b  add rsp, 0x30
000078805cddcf2f  vmovaps xmm0, [rsp]
000078805cddcf34  vmovaps xmm1, [rsp+0x10]
000078805cddcf3a  vmovaps xmm2, [rsp+0x20]
000078805cddcf40  vmovaps xmm3, [rsp+0x30]
000078805cddcf46  vmovaps xmm4, [rsp+0x40]
000078805cddcf4c  vmovaps xmm5, [rsp+0x50]
000078805cddcf52  vmovaps xmm7, [rsp+0x60]
000078805cddcf58  vmovaps xmm8, [rsp+0x70]
000078805cddcf5e  vmovaps xmm9, [rsp+0x80]
000078805cddcf67  vmovaps xmm10, [rsp+0x90]
000078805cddcf70  vmovaps xmm11, [rsp+0xA0]
000078805cddcf79  vmovaps xmm12, [rsp+0xB0]
000078805cddcf82  vmovaps xmm13, [rsp+0xC0]
000078805cddcf8b  vmovaps xmm14, [rsp+0xD0]
000078805cddcf94  vmovaps xmm15, [rsp+0xE0]
000078805cddcf9d  add rsp, 0xF0
000078805cddcfa4  pop r11
000078805cddcfa6  pop r10
000078805cddcfa8  pop r9
000078805cddcfaa  pop r8
000078805cddcfac  pop rsi
000078805cddcfad  pop rdi
000078805cddcfae  pop rdx
000078805cddcfaf  pop rcx
000078805cddcfb0  pop rax
000078805cddcfb1  add rsp, 0x08
000078805cddcfb5  jmp 0x000078805CDDBBD4
000078805cddcfba  sub rsp, 0x08
000078805cddcfbe  push rax
000078805cddcfbf  push rcx
000078805cddcfc0  push rdx
000078805cddcfc1  push rdi
000078805cddcfc2  push rsi
000078805cddcfc3  push r8
000078805cddcfc5  push r9
000078805cddcfc7  push r10
000078805cddcfc9  push r11
000078805cddcfcb  sub rsp, 0xF0
000078805cddcfd2  vmovaps [rsp], xmm0
000078805cddcfd7  vmovaps [rsp+0x10], xmm1
000078805cddcfdd  vmovaps [rsp+0x20], xmm2
000078805cddcfe3  vmovaps [rsp+0x30], xmm4
000078805cddcfe9  vmovaps [rsp+0x40], xmm5
000078805cddcfef  vmovaps [rsp+0x50], xmm6
000078805cddcff5  vmovaps [rsp+0x60], xmm7
000078805cddcffb  vmovaps [rsp+0x70], xmm8
000078805cddd001  vmovaps [rsp+0x80], xmm9
000078805cddd00a  vmovaps [rsp+0x90], xmm10
000078805cddd013  vmovaps [rsp+0xA0], xmm11
000078805cddd01c  vmovaps [rsp+0xB0], xmm12
000078805cddd025  vmovaps [rsp+0xC0], xmm13
000078805cddd02e  vmovaps [rsp+0xD0], xmm14
000078805cddd037  vmovaps [rsp+0xE0], xmm15
000078805cddd040  sub rsp, 0x30
000078805cddd044  movaps [rsp], xmm3
000078805cddd048  movaps [rsp+0x10], xmm5
000078805cddd04d  movaps [rsp+0x20], xmm4
000078805cddd052  lea rdi, [rsp]
000078805cddd056  mov esi, 0x00
000078805cddd05b  mov rax, 0x5771AD6EA530
000078805cddd065  call rax
000078805cddd067  movaps xmm3, [rsp]
000078805cddd06b  add rsp, 0x30
000078805cddd06f  vmovaps xmm0, [rsp]
000078805cddd074  vmovaps xmm1, [rsp+0x10]
000078805cddd07a  vmovaps xmm2, [rsp+0x20]
000078805cddd080  vmovaps xmm4, [rsp+0x30]
000078805cddd086  vmovaps xmm5, [rsp+0x40]
000078805cddd08c  vmovaps xmm6, [rsp+0x50]
000078805cddd092  vmovaps xmm7, [rsp+0x60]
000078805cddd098  vmovaps xmm8, [rsp+0x70]
000078805cddd09e  vmovaps xmm9, [rsp+0x80]
000078805cddd0a7  vmovaps xmm10, [rsp+0x90]
000078805cddd0b0  vmovaps xmm11, [rsp+0xA0]
000078805cddd0b9  vmovaps xmm12, [rsp+0xB0]
000078805cddd0c2  vmovaps xmm13, [rsp+0xC0]
000078805cddd0cb  vmovaps xmm14, [rsp+0xD0]
000078805cddd0d4  vmovaps xmm15, [rsp+0xE0]
000078805cddd0dd  add rsp, 0xF0
000078805cddd0e4  pop r11
000078805cddd0e6  pop r10
000078805cddd0e8  pop r9
000078805cddd0ea  pop r8
000078805cddd0ec  pop rsi
000078805cddd0ed  pop rdi
000078805cddd0ee  pop rdx
000078805cddd0ef  pop rcx
000078805cddd0f0  pop rax
000078805cddd0f1  add rsp, 0x08
000078805cddd0f5  jmp 0x000078805CDDBC35
000078805cddd0fa  sub rsp, 0x08
000078805cddd0fe  push rax
000078805cddd0ff  push rcx
000078805cddd100  push rdx
000078805cddd101  push rdi
000078805cddd102  push rsi
000078805cddd103  push r8
000078805cddd105  push r9
000078805cddd107  push r10
000078805cddd109  push r11
000078805cddd10b  sub rsp, 0xF0
000078805cddd112  vmovaps [rsp], xmm0
000078805cddd117  vmovaps [rsp+0x10], xmm1
000078805cddd11d  vmovaps [rsp+0x20], xmm2
000078805cddd123  vmovaps [rsp+0x30], xmm3
000078805cddd129  vmovaps [rsp+0x40], xmm4
000078805cddd12f  vmovaps [rsp+0x50], xmm6
000078805cddd135  vmovaps [rsp+0x60], xmm7
000078805cddd13b  vmovaps [rsp+0x70], xmm8
000078805cddd141  vmovaps [rsp+0x80], xmm9
000078805cddd14a  vmovaps [rsp+0x90], xmm10
000078805cddd153  vmovaps [rsp+0xA0], xmm11
000078805cddd15c  vmovaps [rsp+0xB0], xmm12
000078805cddd165  vmovaps [rsp+0xC0], xmm13
000078805cddd16e  vmovaps [rsp+0xD0], xmm14
000078805cddd177  vmovaps [rsp+0xE0], xmm15
000078805cddd180  sub rsp, 0x30
000078805cddd184  movaps [rsp], xmm5
000078805cddd188  movaps [rsp+0x10], xmm8
000078805cddd18e  movaps [rsp+0x20], xmm15
000078805cddd194  lea rdi, [rsp]
000078805cddd198  mov esi, 0x00
000078805cddd19d  mov rax, 0x5771AD6EA530
000078805cddd1a7  call rax
000078805cddd1a9  movaps xmm5, [rsp]
000078805cddd1ad  add rsp, 0x30
000078805cddd1b1  vmovaps xmm0, [rsp]
000078805cddd1b6  vmovaps xmm1, [rsp+0x10]
000078805cddd1bc  vmovaps xmm2, [rsp+0x20]
000078805cddd1c2  vmovaps xmm3, [rsp+0x30]
000078805cddd1c8  vmovaps xmm4, [rsp+0x40]
000078805cddd1ce  vmovaps xmm6, [rsp+0x50]
000078805cddd1d4  vmovaps xmm7, [rsp+0x60]
000078805cddd1da  vmovaps xmm8, [rsp+0x70]
000078805cddd1e0  vmovaps xmm9, [rsp+0x80]
000078805cddd1e9  vmovaps xmm10, [rsp+0x90]
000078805cddd1f2  vmovaps xmm11, [rsp+0xA0]
000078805cddd1fb  vmovaps xmm12, [rsp+0xB0]
000078805cddd204  vmovaps xmm13, [rsp+0xC0]
000078805cddd20d  vmovaps xmm14, [rsp+0xD0]
000078805cddd216  vmovaps xmm15, [rsp+0xE0]
000078805cddd21f  add rsp, 0xF0
000078805cddd226  pop r11
000078805cddd228  pop r10
000078805cddd22a  pop r9
000078805cddd22c  pop r8
000078805cddd22e  pop rsi
000078805cddd22f  pop rdi
000078805cddd230  pop rdx
000078805cddd231  pop rcx
000078805cddd232  pop rax
000078805cddd233  add rsp, 0x08
000078805cddd237  jmp 0x000078805CDDBC73
000078805cddd23c  sub rsp, 0x08
000078805cddd240  push rax
000078805cddd241  push rcx
000078805cddd242  push rdx
000078805cddd243  push rdi
000078805cddd244  push rsi
000078805cddd245  push r8
000078805cddd247  push r9
000078805cddd249  push r10
000078805cddd24b  push r11
000078805cddd24d  sub rsp, 0xF0
000078805cddd254  vmovaps [rsp], xmm0
000078805cddd259  vmovaps [rsp+0x10], xmm1
000078805cddd25f  vmovaps [rsp+0x20], xmm2
000078805cddd265  vmovaps [rsp+0x30], xmm3
000078805cddd26b  vmovaps [rsp+0x40], xmm5
000078805cddd271  vmovaps [rsp+0x50], xmm6
000078805cddd277  vmovaps [rsp+0x60], xmm7
000078805cddd27d  vmovaps [rsp+0x70], xmm8
000078805cddd283  vmovaps [rsp+0x80], xmm9
000078805cddd28c  vmovaps [rsp+0x90], xmm10
000078805cddd295  vmovaps [rsp+0xA0], xmm11
000078805cddd29e  vmovaps [rsp+0xB0], xmm12
000078805cddd2a7  vmovaps [rsp+0xC0], xmm13
000078805cddd2b0  vmovaps [rsp+0xD0], xmm14
000078805cddd2b9  vmovaps [rsp+0xE0], xmm15
000078805cddd2c2  sub rsp, 0x30
000078805cddd2c6  movaps [rsp], xmm4
000078805cddd2ca  movaps [rsp+0x10], xmm9
000078805cddd2d0  movaps [rsp+0x20], xmm8
000078805cddd2d6  lea rdi, [rsp]
000078805cddd2da  mov esi, 0x00
000078805cddd2df  mov rax, 0x5771AD6EA530
000078805cddd2e9  call rax
000078805cddd2eb  movaps xmm4, [rsp]
000078805cddd2ef  add rsp, 0x30
000078805cddd2f3  vmovaps xmm0, [rsp]
000078805cddd2f8  vmovaps xmm1, [rsp+0x10]
000078805cddd2fe  vmovaps xmm2, [rsp+0x20]
000078805cddd304  vmovaps xmm3, [rsp+0x30]
000078805cddd30a  vmovaps xmm5, [rsp+0x40]
000078805cddd310  vmovaps xmm6, [rsp+0x50]
000078805cddd316  vmovaps xmm7, [rsp+0x60]
000078805cddd31c  vmovaps xmm8, [rsp+0x70]
000078805cddd322  vmovaps xmm9, [rsp+0x80]
000078805cddd32b  vmovaps xmm10, [rsp+0x90]
000078805cddd334  vmovaps xmm11, [rsp+0xA0]
000078805cddd33d  vmovaps xmm12, [rsp+0xB0]
000078805cddd346  vmovaps xmm13, [rsp+0xC0]
000078805cddd34f  vmovaps xmm14, [rsp+0xD0]
000078805cddd358  vmovaps xmm15, [rsp+0xE0]
000078805cddd361  add rsp, 0xF0
000078805cddd368  pop r11
000078805cddd36a  pop r10
000078805cddd36c  pop r9
000078805cddd36e  pop r8
000078805cddd370  pop rsi
000078805cddd371  pop rdi
000078805cddd372  pop rdx
000078805cddd373  pop rcx
000078805cddd374  pop rax
000078805cddd375  add rsp, 0x08
000078805cddd379  jmp 0x000078805CDDBC94
000078805cddd37e  sub rsp, 0x08
000078805cddd382  push rax
000078805cddd383  push rcx
000078805cddd384  push rdx
000078805cddd385  push rdi
000078805cddd386  push rsi
000078805cddd387  push r8
000078805cddd389  push r9
000078805cddd38b  push r10
000078805cddd38d  push r11
000078805cddd38f  sub rsp, 0xF0
000078805cddd396  vmovaps [rsp], xmm0
000078805cddd39b  vmovaps [rsp+0x10], xmm1
000078805cddd3a1  vmovaps [rsp+0x20], xmm2
000078805cddd3a7  vmovaps [rsp+0x30], xmm3
000078805cddd3ad  vmovaps [rsp+0x40], xmm4
000078805cddd3b3  vmovaps [rsp+0x50], xmm5
000078805cddd3b9  vmovaps [rsp+0x60], xmm6
000078805cddd3bf  vmovaps [rsp+0x70], xmm7
000078805cddd3c5  vmovaps [rsp+0x80], xmm8
000078805cddd3ce  vmovaps [rsp+0x90], xmm10
000078805cddd3d7  vmovaps [rsp+0xA0], xmm11
000078805cddd3e0  vmovaps [rsp+0xB0], xmm12
000078805cddd3e9  vmovaps [rsp+0xC0], xmm13
000078805cddd3f2  vmovaps [rsp+0xD0], xmm14
000078805cddd3fb  vmovaps [rsp+0xE0], xmm15
000078805cddd404  sub rsp, 0x30
000078805cddd408  movaps [rsp], xmm9
000078805cddd40d  movaps [rsp+0x10], xmm10
000078805cddd413  movaps [rsp+0x20], xmm8
000078805cddd419  lea rdi, [rsp]
000078805cddd41d  mov esi, 0x00
000078805cddd422  mov rax, 0x5771AD6EA530
000078805cddd42c  call rax
000078805cddd42e  movaps xmm9, [rsp]
000078805cddd433  add rsp, 0x30
000078805cddd437  vmovaps xmm0, [rsp]
000078805cddd43c  vmovaps xmm1, [rsp+0x10]
000078805cddd442  vmovaps xmm2, [rsp+0x20]
000078805cddd448  vmovaps xmm3, [rsp+0x30]
000078805cddd44e  vmovaps xmm4, [rsp+0x40]
000078805cddd454  vmovaps xmm5, [rsp+0x50]
000078805cddd45a  vmovaps xmm6, [rsp+0x60]
000078805cddd460  vmovaps xmm7, [rsp+0x70]
000078805cddd466  vmovaps xmm8, [rsp+0x80]
000078805cddd46f  vmovaps xmm10, [rsp+0x90]
000078805cddd478  vmovaps xmm11, [rsp+0xA0]
000078805cddd481  vmovaps xmm12, [rsp+0xB0]
000078805cddd48a  vmovaps xmm13, [rsp+0xC0]
000078805cddd493  vmovaps xmm14, [rsp+0xD0]
000078805cddd49c  vmovaps xmm15, [rsp+0xE0]
000078805cddd4a5  add rsp, 0xF0
000078805cddd4ac  pop r11
000078805cddd4ae  pop r10
000078805cddd4b0  pop r9
000078805cddd4b2  pop r8
000078805cddd4b4  pop rsi
000078805cddd4b5  pop rdi
000078805cddd4b6  pop rdx
000078805cddd4b7  pop rcx
000078805cddd4b8  pop rax
000078805cddd4b9  add rsp, 0x08
000078805cddd4bd  jmp 0x000078805CDDBCAE
000078805cddd4c2  call 0x000078805CCB52F0
000078805cddd4c7  jmp 0x000078805CDDBDC8
000078805cddd4cc  call 0x000078805CCB52F0
000078805cddd4d1  jmp 0x000078805CDDBDDE
000078805cddd4d6  sub rsp, 0x08
000078805cddd4da  push rax
000078805cddd4db  push rcx
000078805cddd4dc  push rdx
000078805cddd4dd  push rdi
000078805cddd4de  push rsi
000078805cddd4df  push r8
000078805cddd4e1  push r9
000078805cddd4e3  push r10
000078805cddd4e5  push r11
000078805cddd4e7  sub rsp, 0xF0
000078805cddd4ee  vmovaps [rsp], xmm0
000078805cddd4f3  vmovaps [rsp+0x10], xmm2
000078805cddd4f9  vmovaps [rsp+0x20], xmm3
000078805cddd4ff  vmovaps [rsp+0x30], xmm4
000078805cddd505  vmovaps [rsp+0x40], xmm5
000078805cddd50b  vmovaps [rsp+0x50], xmm6
000078805cddd511  vmovaps [rsp+0x60], xmm7
000078805cddd517  vmovaps [rsp+0x70], xmm8
000078805cddd51d  vmovaps [rsp+0x80], xmm9
000078805cddd526  vmovaps [rsp+0x90], xmm10
000078805cddd52f  vmovaps [rsp+0xA0], xmm11
000078805cddd538  vmovaps [rsp+0xB0], xmm12
000078805cddd541  vmovaps [rsp+0xC0], xmm13
000078805cddd54a  vmovaps [rsp+0xD0], xmm14
000078805cddd553  vmovaps [rsp+0xE0], xmm15
000078805cddd55c  sub rsp, 0x30
000078805cddd560  movaps [rsp], xmm1
000078805cddd564  movaps [rsp+0x10], xmm6
000078805cddd569  movaps [rsp+0x20], xmm15
000078805cddd56f  lea rdi, [rsp]
000078805cddd573  mov esi, 0x00
000078805cddd578  mov rax, 0x5771AD6EA530
000078805cddd582  call rax
000078805cddd584  movaps xmm1, [rsp]
000078805cddd588  add rsp, 0x30
000078805cddd58c  vmovaps xmm0, [rsp]
000078805cddd591  vmovaps xmm2, [rsp+0x10]
000078805cddd597  vmovaps xmm3, [rsp+0x20]
000078805cddd59d  vmovaps xmm4, [rsp+0x30]
000078805cddd5a3  vmovaps xmm5, [rsp+0x40]
000078805cddd5a9  vmovaps xmm6, [rsp+0x50]
000078805cddd5af  vmovaps xmm7, [rsp+0x60]
000078805cddd5b5  vmovaps xmm8, [rsp+0x70]
000078805cddd5bb  vmovaps xmm9, [rsp+0x80]
000078805cddd5c4  vmovaps xmm10, [rsp+0x90]
000078805cddd5cd  vmovaps xmm11, [rsp+0xA0]
000078805cddd5d6  vmovaps xmm12, [rsp+0xB0]
000078805cddd5df  vmovaps xmm13, [rsp+0xC0]
000078805cddd5e8  vmovaps xmm14, [rsp+0xD0]
000078805cddd5f1  vmovaps xmm15, [rsp+0xE0]
000078805cddd5fa  add rsp, 0xF0
000078805cddd601  pop r11
000078805cddd603  pop r10
000078805cddd605  pop r9
000078805cddd607  pop r8
000078805cddd609  pop rsi
000078805cddd60a  pop rdi
000078805cddd60b  pop rdx
000078805cddd60c  pop rcx
000078805cddd60d  pop rax
000078805cddd60e  add rsp, 0x08
000078805cddd612  jmp 0x000078805CDDBE1B
000078805cddd617  call 0x000078805CCC4620
000078805cddd61c  jmp 0x000078805CDDBE28
000078805cddd621  sub rsp, 0x08
000078805cddd625  push rax
000078805cddd626  push rcx
000078805cddd627  push rdx
000078805cddd628  push rdi
000078805cddd629  push rsi
000078805cddd62a  push r8
000078805cddd62c  push r9
000078805cddd62e  push r10
000078805cddd630  push r11
000078805cddd632  sub rsp, 0xF0
000078805cddd639  vmovaps [rsp], xmm0
000078805cddd63e  vmovaps [rsp+0x10], xmm1
000078805cddd644  vmovaps [rsp+0x20], xmm2
000078805cddd64a  vmovaps [rsp+0x30], xmm3
000078805cddd650  vmovaps [rsp+0x40], xmm4
000078805cddd656  vmovaps [rsp+0x50], xmm5
000078805cddd65c  vmovaps [rsp+0x60], xmm6
000078805cddd662  vmovaps [rsp+0x70], xmm7
000078805cddd668  vmovaps [rsp+0x80], xmm8
000078805cddd671  vmovaps [rsp+0x90], xmm9
000078805cddd67a  vmovaps [rsp+0xA0], xmm10
000078805cddd683  vmovaps [rsp+0xB0], xmm11
000078805cddd68c  vmovaps [rsp+0xC0], xmm12
000078805cddd695  vmovaps [rsp+0xD0], xmm13
000078805cddd69e  vmovaps [rsp+0xE0], xmm15
000078805cddd6a7  sub rsp, 0x30
000078805cddd6ab  movaps [rsp], xmm14
000078805cddd6b0  movaps [rsp+0x10], xmm4
000078805cddd6b5  movaps [rsp+0x20], xmm3
000078805cddd6ba  lea rdi, [rsp]
000078805cddd6be  mov esi, 0x00
000078805cddd6c3  mov rax, 0x5771AD6EA530
000078805cddd6cd  call rax
000078805cddd6cf  movaps xmm14, [rsp]
000078805cddd6d4  add rsp, 0x30
000078805cddd6d8  vmovaps xmm0, [rsp]
000078805cddd6dd  vmovaps xmm1, [rsp+0x10]
000078805cddd6e3  vmovaps xmm2, [rsp+0x20]
000078805cddd6e9  vmovaps xmm3, [rsp+0x30]
000078805cddd6ef  vmovaps xmm4, [rsp+0x40]
000078805cddd6f5  vmovaps xmm5, [rsp+0x50]
000078805cddd6fb  vmovaps xmm6, [rsp+0x60]
000078805cddd701  vmovaps xmm7, [rsp+0x70]
000078805cddd707  vmovaps xmm8, [rsp+0x80]
000078805cddd710  vmovaps xmm9, [rsp+0x90]
000078805cddd719  vmovaps xmm10, [rsp+0xA0]
000078805cddd722  vmovaps xmm11, [rsp+0xB0]
000078805cddd72b  vmovaps xmm12, [rsp+0xC0]
000078805cddd734  vmovaps xmm13, [rsp+0xD0]
000078805cddd73d  vmovaps xmm15, [rsp+0xE0]
000078805cddd746  add rsp, 0xF0
000078805cddd74d  pop r11
000078805cddd74f  pop r10
000078805cddd751  pop r9
000078805cddd753  pop r8
000078805cddd755  pop rsi
000078805cddd756  pop rdi
000078805cddd757  pop rdx
000078805cddd758  pop rcx
000078805cddd759  pop rax
000078805cddd75a  add rsp, 0x08
000078805cddd75e  jmp 0x000078805CDDBE42
000078805cddd763  sub rsp, 0x08
000078805cddd767  push rax
000078805cddd768  push rcx
000078805cddd769  push rdx
000078805cddd76a  push rdi
000078805cddd76b  push rsi
000078805cddd76c  push r8
000078805cddd76e  push r9
000078805cddd770  push r10
000078805cddd772  push r11
000078805cddd774  sub rsp, 0xF0
000078805cddd77b  vmovaps [rsp], xmm0
000078805cddd780  vmovaps [rsp+0x10], xmm1
000078805cddd786  vmovaps [rsp+0x20], xmm2
000078805cddd78c  vmovaps [rsp+0x30], xmm3
000078805cddd792  vmovaps [rsp+0x40], xmm4
000078805cddd798  vmovaps [rsp+0x50], xmm5
000078805cddd79e  vmovaps [rsp+0x60], xmm7
000078805cddd7a4  vmovaps [rsp+0x70], xmm8
000078805cddd7aa  vmovaps [rsp+0x80], xmm9
000078805cddd7b3  vmovaps [rsp+0x90], xmm10
000078805cddd7bc  vmovaps [rsp+0xA0], xmm11
000078805cddd7c5  vmovaps [rsp+0xB0], xmm12
000078805cddd7ce  vmovaps [rsp+0xC0], xmm13
000078805cddd7d7  vmovaps [rsp+0xD0], xmm14
000078805cddd7e0  vmovaps [rsp+0xE0], xmm15
000078805cddd7e9  sub rsp, 0x30
000078805cddd7ed  movaps [rsp], xmm6
000078805cddd7f1  movaps [rsp+0x10], xmm9
000078805cddd7f7  movaps [rsp+0x20], xmm7
000078805cddd7fc  lea rdi, [rsp]
000078805cddd800  mov esi, 0x00
000078805cddd805  mov rax, 0x5771AD6EA530
000078805cddd80f  call rax
000078805cddd811  movaps xmm6, [rsp]
000078805cddd815  add rsp, 0x30
000078805cddd819  vmovaps xmm0, [rsp]
000078805cddd81e  vmovaps xmm1, [rsp+0x10]
000078805cddd824  vmovaps xmm2, [rsp+0x20]
000078805cddd82a  vmovaps xmm3, [rsp+0x30]
000078805cddd830  vmovaps xmm4, [rsp+0x40]
000078805cddd836  vmovaps xmm5, [rsp+0x50]
000078805cddd83c  vmovaps xmm7, [rsp+0x60]
000078805cddd842  vmovaps xmm8, [rsp+0x70]
000078805cddd848  vmovaps xmm9, [rsp+0x80]
000078805cddd851  vmovaps xmm10, [rsp+0x90]
000078805cddd85a  vmovaps xmm11, [rsp+0xA0]
000078805cddd863  vmovaps xmm12, [rsp+0xB0]
000078805cddd86c  vmovaps xmm13, [rsp+0xC0]
000078805cddd875  vmovaps xmm14, [rsp+0xD0]
000078805cddd87e  vmovaps xmm15, [rsp+0xE0]
000078805cddd887  add rsp, 0xF0
000078805cddd88e  pop r11
000078805cddd890  pop r10
000078805cddd892  pop r9
000078805cddd894  pop r8
000078805cddd896  pop rsi
000078805cddd897  pop rdi
000078805cddd898  pop rdx
000078805cddd899  pop rcx
000078805cddd89a  pop rax
000078805cddd89b  add rsp, 0x08
000078805cddd89f  jmp 0x000078805CDDBE5A
000078805cddd8a4  sub rsp, 0x08
000078805cddd8a8  push rax
000078805cddd8a9  push rcx
000078805cddd8aa  push rdx
000078805cddd8ab  push rdi
000078805cddd8ac  push rsi
000078805cddd8ad  push r8
000078805cddd8af  push r9
000078805cddd8b1  push r10
000078805cddd8b3  push r11
000078805cddd8b5  sub rsp, 0xF0
000078805cddd8bc  vmovaps [rsp], xmm0
000078805cddd8c1  vmovaps [rsp+0x10], xmm1
000078805cddd8c7  vmovaps [rsp+0x20], xmm2
000078805cddd8cd  vmovaps [rsp+0x30], xmm3
000078805cddd8d3  vmovaps [rsp+0x40], xmm4
000078805cddd8d9  vmovaps [rsp+0x50], xmm5
000078805cddd8df  vmovaps [rsp+0x60], xmm6
000078805cddd8e5  vmovaps [rsp+0x70], xmm8
000078805cddd8eb  vmovaps [rsp+0x80], xmm9
000078805cddd8f4  vmovaps [rsp+0x90], xmm10
000078805cddd8fd  vmovaps [rsp+0xA0], xmm11
000078805cddd906  vmovaps [rsp+0xB0], xmm12
000078805cddd90f  vmovaps [rsp+0xC0], xmm13
000078805cddd918  vmovaps [rsp+0xD0], xmm14
000078805cddd921  vmovaps [rsp+0xE0], xmm15
000078805cddd92a  sub rsp, 0x30
000078805cddd92e  movaps [rsp], xmm7
000078805cddd932  movaps [rsp+0x10], xmm4
000078805cddd937  movaps [rsp+0x20], xmm9
000078805cddd93d  lea rdi, [rsp]
000078805cddd941  mov esi, 0x00
000078805cddd946  mov rax, 0x5771AD6EA530
000078805cddd950  call rax
000078805cddd952  movaps xmm7, [rsp]
000078805cddd956  add rsp, 0x30
000078805cddd95a  vmovaps xmm0, [rsp]
000078805cddd95f  vmovaps xmm1, [rsp+0x10]
000078805cddd965  vmovaps xmm2, [rsp+0x20]
000078805cddd96b  vmovaps xmm3, [rsp+0x30]
000078805cddd971  vmovaps xmm4, [rsp+0x40]
000078805cddd977  vmovaps xmm5, [rsp+0x50]
000078805cddd97d  vmovaps xmm6, [rsp+0x60]
000078805cddd983  vmovaps xmm8, [rsp+0x70]
000078805cddd989  vmovaps xmm9, [rsp+0x80]
000078805cddd992  vmovaps xmm10, [rsp+0x90]
000078805cddd99b  vmovaps xmm11, [rsp+0xA0]
000078805cddd9a4  vmovaps xmm12, [rsp+0xB0]
000078805cddd9ad  vmovaps xmm13, [rsp+0xC0]
000078805cddd9b6  vmovaps xmm14, [rsp+0xD0]
000078805cddd9bf  vmovaps xmm15, [rsp+0xE0]
000078805cddd9c8  add rsp, 0xF0
000078805cddd9cf  pop r11
000078805cddd9d1  pop r10
000078805cddd9d3  pop r9
000078805cddd9d5  pop r8
000078805cddd9d7  pop rsi
000078805cddd9d8  pop rdi
000078805cddd9d9  pop rdx
000078805cddd9da  pop rcx
000078805cddd9db  pop rax
000078805cddd9dc  add rsp, 0x08
000078805cddd9e0  jmp 0x000078805CDDBE87
000078805cddd9e5  sub rsp, 0x08
000078805cddd9e9  push rax
000078805cddd9ea  push rcx
000078805cddd9eb  push rdx
000078805cddd9ec  push rdi
000078805cddd9ed  push rsi
000078805cddd9ee  push r8
000078805cddd9f0  push r9
000078805cddd9f2  push r10
000078805cddd9f4  push r11
000078805cddd9f6  sub rsp, 0xF0
000078805cddd9fd  vmovaps [rsp], xmm0
000078805cddda02  vmovaps [rsp+0x10], xmm1
000078805cddda08  vmovaps [rsp+0x20], xmm2
000078805cddda0e  vmovaps [rsp+0x30], xmm3
000078805cddda14  vmovaps [rsp+0x40], xmm5
000078805cddda1a  vmovaps [rsp+0x50], xmm6
000078805cddda20  vmovaps [rsp+0x60], xmm7
000078805cddda26  vmovaps [rsp+0x70], xmm8
000078805cddda2c  vmovaps [rsp+0x80], xmm9
000078805cddda35  vmovaps [rsp+0x90], xmm10
000078805cddda3e  vmovaps [rsp+0xA0], xmm11
000078805cddda47  vmovaps [rsp+0xB0], xmm12
000078805cddda50  vmovaps [rsp+0xC0], xmm13
000078805cddda59  vmovaps [rsp+0xD0], xmm14
000078805cddda62  vmovaps [rsp+0xE0], xmm15
000078805cddda6b  sub rsp, 0x30
000078805cddda6f  movaps [rsp], xmm4
000078805cddda73  movaps [rsp+0x10], xmm15
000078805cddda79  movaps [rsp+0x20], xmm9
000078805cddda7f  lea rdi, [rsp]
000078805cddda83  mov esi, 0x00
000078805cddda88  mov rax, 0x5771AD6EA530
000078805cddda92  call rax
000078805cddda94  movaps xmm4, [rsp]
000078805cddda98  add rsp, 0x30
000078805cddda9c  vmovaps xmm0, [rsp]
000078805cdddaa1  vmovaps xmm1, [rsp+0x10]
000078805cdddaa7  vmovaps xmm2, [rsp+0x20]
000078805cdddaad  vmovaps xmm3, [rsp+0x30]
000078805cdddab3  vmovaps xmm5, [rsp+0x40]
000078805cdddab9  vmovaps xmm6, [rsp+0x50]
000078805cdddabf  vmovaps xmm7, [rsp+0x60]
000078805cdddac5  vmovaps xmm8, [rsp+0x70]
000078805cdddacb  vmovaps xmm9, [rsp+0x80]
000078805cdddad4  vmovaps xmm10, [rsp+0x90]
000078805cdddadd  vmovaps xmm11, [rsp+0xA0]
000078805cdddae6  vmovaps xmm12, [rsp+0xB0]
000078805cdddaef  vmovaps xmm13, [rsp+0xC0]
000078805cdddaf8  vmovaps xmm14, [rsp+0xD0]
000078805cdddb01  vmovaps xmm15, [rsp+0xE0]
000078805cdddb0a  add rsp, 0xF0
000078805cdddb11  pop r11
000078805cdddb13  pop r10
000078805cdddb15  pop r9
000078805cdddb17  pop r8
000078805cdddb19  pop rsi
000078805cdddb1a  pop rdi
000078805cdddb1b  pop rdx
000078805cdddb1c  pop rcx
000078805cdddb1d  pop rax
000078805cdddb1e  add rsp, 0x08
000078805cdddb22  jmp 0x000078805CDDBEAC
000078805cdddb27  call 0x000078805CCC4620
000078805cdddb2c  jmp 0x000078805CDDBEB9
000078805cdddb31  sub rsp, 0x08
000078805cdddb35  push rax
000078805cdddb36  push rcx
000078805cdddb37  push rdx
000078805cdddb38  push rdi
000078805cdddb39  push rsi
000078805cdddb3a  push r8
000078805cdddb3c  push r9
000078805cdddb3e  push r10
000078805cdddb40  push r11
000078805cdddb42  sub rsp, 0xF0
000078805cdddb49  vmovaps [rsp], xmm0
000078805cdddb4e  vmovaps [rsp+0x10], xmm1
000078805cdddb54  vmovaps [rsp+0x20], xmm2
000078805cdddb5a  vmovaps [rsp+0x30], xmm4
000078805cdddb60  vmovaps [rsp+0x40], xmm5
000078805cdddb66  vmovaps [rsp+0x50], xmm6
000078805cdddb6c  vmovaps [rsp+0x60], xmm7
000078805cdddb72  vmovaps [rsp+0x70], xmm8
000078805cdddb78  vmovaps [rsp+0x80], xmm9
000078805cdddb81  vmovaps [rsp+0x90], xmm10
000078805cdddb8a  vmovaps [rsp+0xA0], xmm11
000078805cdddb93  vmovaps [rsp+0xB0], xmm12
000078805cdddb9c  vmovaps [rsp+0xC0], xmm13
000078805cdddba5  vmovaps [rsp+0xD0], xmm14
000078805cdddbae  vmovaps [rsp+0xE0], xmm15
000078805cdddbb7  sub rsp, 0x30
000078805cdddbbb  movaps [rsp], xmm3
000078805cdddbbf  movaps [rsp+0x10], xmm1
000078805cdddbc4  movaps [rsp+0x20], xmm9
000078805cdddbca  lea rdi, [rsp]
000078805cdddbce  mov esi, 0x00
000078805cdddbd3  mov rax, 0x5771AD6EA530
000078805cdddbdd  call rax
000078805cdddbdf  movaps xmm3, [rsp]
000078805cdddbe3  add rsp, 0x30
000078805cdddbe7  vmovaps xmm0, [rsp]
000078805cdddbec  vmovaps xmm1, [rsp+0x10]
000078805cdddbf2  vmovaps xmm2, [rsp+0x20]
000078805cdddbf8  vmovaps xmm4, [rsp+0x30]
000078805cdddbfe  vmovaps xmm5, [rsp+0x40]
000078805cdddc04  vmovaps xmm6, [rsp+0x50]
000078805cdddc0a  vmovaps xmm7, [rsp+0x60]
000078805cdddc10  vmovaps xmm8, [rsp+0x70]
000078805cdddc16  vmovaps xmm9, [rsp+0x80]
000078805cdddc1f  vmovaps xmm10, [rsp+0x90]
000078805cdddc28  vmovaps xmm11, [rsp+0xA0]
000078805cdddc31  vmovaps xmm12, [rsp+0xB0]
000078805cdddc3a  vmovaps xmm13, [rsp+0xC0]
000078805cdddc43  vmovaps xmm14, [rsp+0xD0]
000078805cdddc4c  vmovaps xmm15, [rsp+0xE0]
000078805cdddc55  add rsp, 0xF0
000078805cdddc5c  pop r11
000078805cdddc5e  pop r10
000078805cdddc60  pop r9
000078805cdddc62  pop r8
000078805cdddc64  pop rsi
000078805cdddc65  pop rdi
000078805cdddc66  pop rdx
000078805cdddc67  pop rcx
000078805cdddc68  pop rax
000078805cdddc69  add rsp, 0x08
000078805cdddc6d  jmp 0x000078805CDDBEF6
000078805cdddc72  sub rsp, 0x08
000078805cdddc76  push rax
000078805cdddc77  push rcx
000078805cdddc78  push rdx
000078805cdddc79  push rdi
000078805cdddc7a  push rsi
000078805cdddc7b  push r8
000078805cdddc7d  push r9
000078805cdddc7f  push r10
000078805cdddc81  push r11
000078805cdddc83  sub rsp, 0xF0
000078805cdddc8a  vmovaps [rsp], xmm0
000078805cdddc8f  vmovaps [rsp+0x10], xmm2
000078805cdddc95  vmovaps [rsp+0x20], xmm3
000078805cdddc9b  vmovaps [rsp+0x30], xmm4
000078805cdddca1  vmovaps [rsp+0x40], xmm5
000078805cdddca7  vmovaps [rsp+0x50], xmm6
000078805cdddcad  vmovaps [rsp+0x60], xmm7
000078805cdddcb3  vmovaps [rsp+0x70], xmm8
000078805cdddcb9  vmovaps [rsp+0x80], xmm9
000078805cdddcc2  vmovaps [rsp+0x90], xmm10
000078805cdddccb  vmovaps [rsp+0xA0], xmm11
000078805cdddcd4  vmovaps [rsp+0xB0], xmm12
000078805cdddcdd  vmovaps [rsp+0xC0], xmm13
000078805cdddce6  vmovaps [rsp+0xD0], xmm14
000078805cdddcef  vmovaps [rsp+0xE0], xmm15
000078805cdddcf8  sub rsp, 0x30
000078805cdddcfc  movaps [rsp], xmm1
000078805cdddd00  movaps [rsp+0x10], xmm15
000078805cdddd06  movaps [rsp+0x20], xmm9
000078805cdddd0c  lea rdi, [rsp]
000078805cdddd10  mov esi, 0x00
000078805cdddd15  mov rax, 0x5771AD6EA530
000078805cdddd1f  call rax
000078805cdddd21  movaps xmm1, [rsp]
000078805cdddd25  add rsp, 0x30
000078805cdddd29  vmovaps xmm0, [rsp]
000078805cdddd2e  vmovaps xmm2, [rsp+0x10]
000078805cdddd34  vmovaps xmm3, [rsp+0x20]
000078805cdddd3a  vmovaps xmm4, [rsp+0x30]
000078805cdddd40  vmovaps xmm5, [rsp+0x40]
000078805cdddd46  vmovaps xmm6, [rsp+0x50]
000078805cdddd4c  vmovaps xmm7, [rsp+0x60]
000078805cdddd52  vmovaps xmm8, [rsp+0x70]
000078805cdddd58  vmovaps xmm9, [rsp+0x80]
000078805cdddd61  vmovaps xmm10, [rsp+0x90]
000078805cdddd6a  vmovaps xmm11, [rsp+0xA0]
000078805cdddd73  vmovaps xmm12, [rsp+0xB0]
000078805cdddd7c  vmovaps xmm13, [rsp+0xC0]
000078805cdddd85  vmovaps xmm14, [rsp+0xD0]
000078805cdddd8e  vmovaps xmm15, [rsp+0xE0]
000078805cdddd97  add rsp, 0xF0
000078805cdddd9e  pop r11
000078805cdddda0  pop r10
000078805cdddda2  pop r9
000078805cdddda4  pop r8
000078805cdddda6  pop rsi
000078805cdddda7  pop rdi
000078805cdddda8  pop rdx
000078805cdddda9  pop rcx
000078805cddddaa  pop rax
000078805cddddab  add rsp, 0x08
000078805cddddaf  jmp 0x000078805CDDBF7E
000078805cddddb4  call 0x000078805CCC4620
000078805cddddb9  jmp 0x000078805CDDBF8B
000078805cddddbe  sub rsp, 0x08
000078805cddddc2  push rax
000078805cddddc3  push rcx
000078805cddddc4  push rdx
000078805cddddc5  push rdi
000078805cddddc6  push rsi
000078805cddddc7  push r8
000078805cddddc9  push r9
000078805cddddcb  push r10
000078805cddddcd  push r11
000078805cddddcf  sub rsp, 0xF0
000078805cddddd6  vmovaps [rsp], xmm0
000078805cdddddb  vmovaps [rsp+0x10], xmm2
000078805cdddde1  vmovaps [rsp+0x20], xmm3
000078805cdddde7  vmovaps [rsp+0x30], xmm4
000078805cdddded  vmovaps [rsp+0x40], xmm5
000078805cddddf3  vmovaps [rsp+0x50], xmm6
000078805cddddf9  vmovaps [rsp+0x60], xmm7
000078805cddddff  vmovaps [rsp+0x70], xmm8
000078805cddde05  vmovaps [rsp+0x80], xmm9
000078805cddde0e  vmovaps [rsp+0x90], xmm10
000078805cddde17  vmovaps [rsp+0xA0], xmm11
000078805cddde20  vmovaps [rsp+0xB0], xmm12
000078805cddde29  vmovaps [rsp+0xC0], xmm13
000078805cddde32  vmovaps [rsp+0xD0], xmm14
000078805cddde3b  vmovaps [rsp+0xE0], xmm15
000078805cddde44  sub rsp, 0x30
000078805cddde48  movaps [rsp], xmm1
000078805cddde4c  movaps [rsp+0x10], xmm5
000078805cddde51  movaps [rsp+0x20], xmm7
000078805cddde56  lea rdi, [rsp]
000078805cddde5a  mov esi, 0x00
000078805cddde5f  mov rax, 0x5771AD6EA530
000078805cddde69  call rax
000078805cddde6b  movaps xmm1, [rsp]
000078805cddde6f  add rsp, 0x30
000078805cddde73  vmovaps xmm0, [rsp]
000078805cddde78  vmovaps xmm2, [rsp+0x10]
000078805cddde7e  vmovaps xmm3, [rsp+0x20]
000078805cddde84  vmovaps xmm4, [rsp+0x30]
000078805cddde8a  vmovaps xmm5, [rsp+0x40]
000078805cddde90  vmovaps xmm6, [rsp+0x50]
000078805cddde96  vmovaps xmm7, [rsp+0x60]
000078805cddde9c  vmovaps xmm8, [rsp+0x70]
000078805cdddea2  vmovaps xmm9, [rsp+0x80]
000078805cdddeab  vmovaps xmm10, [rsp+0x90]
000078805cdddeb4  vmovaps xmm11, [rsp+0xA0]
000078805cdddebd  vmovaps xmm12, [rsp+0xB0]
000078805cdddec6  vmovaps xmm13, [rsp+0xC0]
000078805cdddecf  vmovaps xmm14, [rsp+0xD0]
000078805cddded8  vmovaps xmm15, [rsp+0xE0]
000078805cdddee1  add rsp, 0xF0
000078805cdddee8  pop r11
000078805cdddeea  pop r10
000078805cdddeec  pop r9
000078805cdddeee  pop r8
000078805cdddef0  pop rsi
000078805cdddef1  pop rdi
000078805cdddef2  pop rdx
000078805cdddef3  pop rcx
000078805cdddef4  pop rax
000078805cdddef5  add rsp, 0x08
000078805cdddef9  jmp 0x000078805CDDC030
000078805cdddefe  sub rsp, 0x08
000078805cdddf02  push rax
000078805cdddf03  push rcx
000078805cdddf04  push rdx
000078805cdddf05  push rdi
000078805cdddf06  push rsi
000078805cdddf07  push r8
000078805cdddf09  push r9
000078805cdddf0b  push r10
000078805cdddf0d  push r11
000078805cdddf0f  sub rsp, 0xF0
000078805cdddf16  vmovaps [rsp], xmm0
000078805cdddf1b  vmovaps [rsp+0x10], xmm1
000078805cdddf21  vmovaps [rsp+0x20], xmm2
000078805cdddf27  vmovaps [rsp+0x30], xmm3
000078805cdddf2d  vmovaps [rsp+0x40], xmm4
000078805cdddf33  vmovaps [rsp+0x50], xmm5
000078805cdddf39  vmovaps [rsp+0x60], xmm6
000078805cdddf3f  vmovaps [rsp+0x70], xmm8
000078805cdddf45  vmovaps [rsp+0x80], xmm9
000078805cdddf4e  vmovaps [rsp+0x90], xmm10
000078805cdddf57  vmovaps [rsp+0xA0], xmm11
000078805cdddf60  vmovaps [rsp+0xB0], xmm12
000078805cdddf69  vmovaps [rsp+0xC0], xmm13
000078805cdddf72  vmovaps [rsp+0xD0], xmm14
000078805cdddf7b  vmovaps [rsp+0xE0], xmm15
000078805cdddf84  sub rsp, 0x30
000078805cdddf88  movaps [rsp], xmm7
000078805cdddf8c  movaps [rsp+0x10], xmm5
000078805cdddf91  movaps [rsp+0x20], xmm15
000078805cdddf97  lea rdi, [rsp]
000078805cdddf9b  mov esi, 0x00
000078805cdddfa0  mov rax, 0x5771AD6EA530
000078805cdddfaa  call rax
000078805cdddfac  movaps xmm7, [rsp]
000078805cdddfb0  add rsp, 0x30
000078805cdddfb4  vmovaps xmm0, [rsp]
000078805cdddfb9  vmovaps xmm1, [rsp+0x10]
000078805cdddfbf  vmovaps xmm2, [rsp+0x20]
000078805cdddfc5  vmovaps xmm3, [rsp+0x30]
000078805cdddfcb  vmovaps xmm4, [rsp+0x40]
000078805cdddfd1  vmovaps xmm5, [rsp+0x50]
000078805cdddfd7  vmovaps xmm6, [rsp+0x60]
000078805cdddfdd  vmovaps xmm8, [rsp+0x70]
000078805cdddfe3  vmovaps xmm9, [rsp+0x80]
000078805cdddfec  vmovaps xmm10, [rsp+0x90]
000078805cdddff5  vmovaps xmm11, [rsp+0xA0]
000078805cdddffe  vmovaps xmm12, [rsp+0xB0]
000078805cdde007  vmovaps xmm13, [rsp+0xC0]
000078805cdde010  vmovaps xmm14, [rsp+0xD0]
000078805cdde019  vmovaps xmm15, [rsp+0xE0]
000078805cdde022  add rsp, 0xF0
000078805cdde029  pop r11
000078805cdde02b  pop r10
000078805cdde02d  pop r9
000078805cdde02f  pop r8
000078805cdde031  pop rsi
000078805cdde032  pop rdi
000078805cdde033  pop rdx
000078805cdde034  pop rcx
000078805cdde035  pop rax
000078805cdde036  add rsp, 0x08
000078805cdde03a  jmp 0x000078805CDDC066
000078805cdde03f  call 0x000078805CCB52F0
000078805cdde044  jmp 0x000078805CDDC073
000078805cdde049  sub rsp, 0x08
000078805cdde04d  push rax
000078805cdde04e  push rcx
000078805cdde04f  push rdx
000078805cdde050  push rdi
000078805cdde051  push rsi
000078805cdde052  push r8
000078805cdde054  push r9
000078805cdde056  push r10
000078805cdde058  push r11
000078805cdde05a  sub rsp, 0xF0
000078805cdde061  vmovaps [rsp], xmm0
000078805cdde066  vmovaps [rsp+0x10], xmm1
000078805cdde06c  vmovaps [rsp+0x20], xmm2
000078805cdde072  vmovaps [rsp+0x30], xmm3
000078805cdde078  vmovaps [rsp+0x40], xmm4
000078805cdde07e  vmovaps [rsp+0x50], xmm5
000078805cdde084  vmovaps [rsp+0x60], xmm6
000078805cdde08a  vmovaps [rsp+0x70], xmm7
000078805cdde090  vmovaps [rsp+0x80], xmm8
000078805cdde099  vmovaps [rsp+0x90], xmm9
000078805cdde0a2  vmovaps [rsp+0xA0], xmm10
000078805cdde0ab  vmovaps [rsp+0xB0], xmm11
000078805cdde0b4  vmovaps [rsp+0xC0], xmm12
000078805cdde0bd  vmovaps [rsp+0xD0], xmm13
000078805cdde0c6  vmovaps [rsp+0xE0], xmm14
000078805cdde0cf  sub rsp, 0x30
000078805cdde0d3  movaps [rsp], xmm15
000078805cdde0d8  movaps [rsp+0x10], xmm5
000078805cdde0dd  movaps [rsp+0x20], xmm3
000078805cdde0e2  lea rdi, [rsp]
000078805cdde0e6  mov esi, 0x00
000078805cdde0eb  mov rax, 0x5771AD6EA530
000078805cdde0f5  call rax
000078805cdde0f7  movaps xmm15, [rsp]
000078805cdde0fc  add rsp, 0x30
000078805cdde100  vmovaps xmm0, [rsp]
000078805cdde105  vmovaps xmm1, [rsp+0x10]
000078805cdde10b  vmovaps xmm2, [rsp+0x20]
000078805cdde111  vmovaps xmm3, [rsp+0x30]
000078805cdde117  vmovaps xmm4, [rsp+0x40]
000078805cdde11d  vmovaps xmm5, [rsp+0x50]
000078805cdde123  vmovaps xmm6, [rsp+0x60]
000078805cdde129  vmovaps xmm7, [rsp+0x70]
000078805cdde12f  vmovaps xmm8, [rsp+0x80]
000078805cdde138  vmovaps xmm9, [rsp+0x90]
000078805cdde141  vmovaps xmm10, [rsp+0xA0]
000078805cdde14a  vmovaps xmm11, [rsp+0xB0]
000078805cdde153  vmovaps xmm12, [rsp+0xC0]
000078805cdde15c  vmovaps xmm13, [rsp+0xD0]
000078805cdde165  vmovaps xmm14, [rsp+0xE0]
000078805cdde16e  add rsp, 0xF0
000078805cdde175  pop r11
000078805cdde177  pop r10
000078805cdde179  pop r9
000078805cdde17b  pop r8
000078805cdde17d  pop rsi
000078805cdde17e  pop rdi
000078805cdde17f  pop rdx
000078805cdde180  pop rcx
000078805cdde181  pop rax
000078805cdde182  add rsp, 0x08
000078805cdde186  jmp 0x000078805CDDC099
000078805cdde18b  sub rsp, 0x08
000078805cdde18f  push rax
000078805cdde190  push rcx
000078805cdde191  push rdx
000078805cdde192  push rdi
000078805cdde193  push rsi
000078805cdde194  push r8
000078805cdde196  push r9
000078805cdde198  push r10
000078805cdde19a  push r11
000078805cdde19c  sub rsp, 0xF0
000078805cdde1a3  vmovaps [rsp], xmm0
000078805cdde1a8  vmovaps [rsp+0x10], xmm2
000078805cdde1ae  vmovaps [rsp+0x20], xmm3
000078805cdde1b4  vmovaps [rsp+0x30], xmm4
000078805cdde1ba  vmovaps [rsp+0x40], xmm5
000078805cdde1c0  vmovaps [rsp+0x50], xmm6
000078805cdde1c6  vmovaps [rsp+0x60], xmm7
000078805cdde1cc  vmovaps [rsp+0x70], xmm8
000078805cdde1d2  vmovaps [rsp+0x80], xmm9
000078805cdde1db  vmovaps [rsp+0x90], xmm10
000078805cdde1e4  vmovaps [rsp+0xA0], xmm11
000078805cdde1ed  vmovaps [rsp+0xB0], xmm12
000078805cdde1f6  vmovaps [rsp+0xC0], xmm13
000078805cdde1ff  vmovaps [rsp+0xD0], xmm14
000078805cdde208  vmovaps [rsp+0xE0], xmm15
000078805cdde211  sub rsp, 0x30
000078805cdde215  movaps [rsp], xmm1
000078805cdde219  movaps [rsp+0x10], xmm5
000078805cdde21e  movaps [rsp+0x20], xmm4
000078805cdde223  lea rdi, [rsp]
000078805cdde227  mov esi, 0x00
000078805cdde22c  mov rax, 0x5771AD6EA530
000078805cdde236  call rax
000078805cdde238  movaps xmm1, [rsp]
000078805cdde23c  add rsp, 0x30
000078805cdde240  vmovaps xmm0, [rsp]
000078805cdde245  vmovaps xmm2, [rsp+0x10]
000078805cdde24b  vmovaps xmm3, [rsp+0x20]
000078805cdde251  vmovaps xmm4, [rsp+0x30]
000078805cdde257  vmovaps xmm5, [rsp+0x40]
000078805cdde25d  vmovaps xmm6, [rsp+0x50]
000078805cdde263  vmovaps xmm7, [rsp+0x60]
000078805cdde269  vmovaps xmm8, [rsp+0x70]
000078805cdde26f  vmovaps xmm9, [rsp+0x80]
000078805cdde278  vmovaps xmm10, [rsp+0x90]
000078805cdde281  vmovaps xmm11, [rsp+0xA0]
000078805cdde28a  vmovaps xmm12, [rsp+0xB0]
000078805cdde293  vmovaps xmm13, [rsp+0xC0]
000078805cdde29c  vmovaps xmm14, [rsp+0xD0]
000078805cdde2a5  vmovaps xmm15, [rsp+0xE0]
000078805cdde2ae  add rsp, 0xF0
000078805cdde2b5  pop r11
000078805cdde2b7  pop r10
000078805cdde2b9  pop r9
000078805cdde2bb  pop r8
000078805cdde2bd  pop rsi
000078805cdde2be  pop rdi
000078805cdde2bf  pop rdx
000078805cdde2c0  pop rcx
000078805cdde2c1  pop rax
000078805cdde2c2  add rsp, 0x08
000078805cdde2c6  jmp 0x000078805CDDC0B9
000078805cdde2cb  sub rsp, 0x08
000078805cdde2cf  push rax
000078805cdde2d0  push rcx
000078805cdde2d1  push rdx
000078805cdde2d2  push rdi
000078805cdde2d3  push rsi
000078805cdde2d4  push r8
000078805cdde2d6  push r9
000078805cdde2d8  push r10
000078805cdde2da  push r11
000078805cdde2dc  sub rsp, 0xF0
000078805cdde2e3  vmovaps [rsp], xmm0
000078805cdde2e8  vmovaps [rsp+0x10], xmm1
000078805cdde2ee  vmovaps [rsp+0x20], xmm2
000078805cdde2f4  vmovaps [rsp+0x30], xmm3
000078805cdde2fa  vmovaps [rsp+0x40], xmm5
000078805cdde300  vmovaps [rsp+0x50], xmm6
000078805cdde306  vmovaps [rsp+0x60], xmm7
000078805cdde30c  vmovaps [rsp+0x70], xmm8
000078805cdde312  vmovaps [rsp+0x80], xmm9
000078805cdde31b  vmovaps [rsp+0x90], xmm10
000078805cdde324  vmovaps [rsp+0xA0], xmm11
000078805cdde32d  vmovaps [rsp+0xB0], xmm12
000078805cdde336  vmovaps [rsp+0xC0], xmm13
000078805cdde33f  vmovaps [rsp+0xD0], xmm14
000078805cdde348  vmovaps [rsp+0xE0], xmm15
000078805cdde351  sub rsp, 0x30
000078805cdde355  movaps [rsp], xmm4
000078805cdde359  movaps [rsp+0x10], xmm3
000078805cdde35e  movaps [rsp+0x20], xmm5
000078805cdde363  lea rdi, [rsp]
000078805cdde367  mov esi, 0x00
000078805cdde36c  mov rax, 0x5771AD6EA530
000078805cdde376  call rax
000078805cdde378  movaps xmm4, [rsp]
000078805cdde37c  add rsp, 0x30
000078805cdde380  vmovaps xmm0, [rsp]
000078805cdde385  vmovaps xmm1, [rsp+0x10]
000078805cdde38b  vmovaps xmm2, [rsp+0x20]
000078805cdde391  vmovaps xmm3, [rsp+0x30]
000078805cdde397  vmovaps xmm5, [rsp+0x40]
000078805cdde39d  vmovaps xmm6, [rsp+0x50]
000078805cdde3a3  vmovaps xmm7, [rsp+0x60]
000078805cdde3a9  vmovaps xmm8, [rsp+0x70]
000078805cdde3af  vmovaps xmm9, [rsp+0x80]
000078805cdde3b8  vmovaps xmm10, [rsp+0x90]
000078805cdde3c1  vmovaps xmm11, [rsp+0xA0]
000078805cdde3ca  vmovaps xmm12, [rsp+0xB0]
000078805cdde3d3  vmovaps xmm13, [rsp+0xC0]
000078805cdde3dc  vmovaps xmm14, [rsp+0xD0]
000078805cdde3e5  vmovaps xmm15, [rsp+0xE0]
000078805cdde3ee  add rsp, 0xF0
000078805cdde3f5  pop r11
000078805cdde3f7  pop r10
000078805cdde3f9  pop r9
000078805cdde3fb  pop r8
000078805cdde3fd  pop rsi
000078805cdde3fe  pop rdi
000078805cdde3ff  pop rdx
000078805cdde400  pop rcx
000078805cdde401  pop rax
000078805cdde402  add rsp, 0x08
000078805cdde406  jmp 0x000078805CDDC107
000078805cdde40b  call 0x000078805CCB52F0
000078805cdde410  jmp 0x000078805CDDC114
000078805cdde415  sub rsp, 0x08
000078805cdde419  push rax
000078805cdde41a  push rcx
000078805cdde41b  push rdx
000078805cdde41c  push rdi
000078805cdde41d  push rsi
000078805cdde41e  push r8
000078805cdde420  push r9
000078805cdde422  push r10
000078805cdde424  push r11
000078805cdde426  sub rsp, 0xF0
000078805cdde42d  vmovaps [rsp], xmm0
000078805cdde432  vmovaps [rsp+0x10], xmm1
000078805cdde438  vmovaps [rsp+0x20], xmm2
000078805cdde43e  vmovaps [rsp+0x30], xmm3
000078805cdde444  vmovaps [rsp+0x40], xmm4
000078805cdde44a  vmovaps [rsp+0x50], xmm6
000078805cdde450  vmovaps [rsp+0x60], xmm7
000078805cdde456  vmovaps [rsp+0x70], xmm8
000078805cdde45c  vmovaps [rsp+0x80], xmm9
000078805cdde465  vmovaps [rsp+0x90], xmm10
000078805cdde46e  vmovaps [rsp+0xA0], xmm11
000078805cdde477  vmovaps [rsp+0xB0], xmm12
000078805cdde480  vmovaps [rsp+0xC0], xmm13
000078805cdde489  vmovaps [rsp+0xD0], xmm14
000078805cdde492  vmovaps [rsp+0xE0], xmm15
000078805cdde49b  sub rsp, 0x30
000078805cdde49f  movaps [rsp], xmm5
000078805cdde4a3  movaps [rsp+0x10], xmm6
000078805cdde4a8  movaps [rsp+0x20], xmm3
000078805cdde4ad  lea rdi, [rsp]
000078805cdde4b1  mov esi, 0x00
000078805cdde4b6  mov rax, 0x5771AD6EA530
000078805cdde4c0  call rax
000078805cdde4c2  movaps xmm5, [rsp]
000078805cdde4c6  add rsp, 0x30
000078805cdde4ca  vmovaps xmm0, [rsp]
000078805cdde4cf  vmovaps xmm1, [rsp+0x10]
000078805cdde4d5  vmovaps xmm2, [rsp+0x20]
000078805cdde4db  vmovaps xmm3, [rsp+0x30]
000078805cdde4e1  vmovaps xmm4, [rsp+0x40]
000078805cdde4e7  vmovaps xmm6, [rsp+0x50]
000078805cdde4ed  vmovaps xmm7, [rsp+0x60]
000078805cdde4f3  vmovaps xmm8, [rsp+0x70]
000078805cdde4f9  vmovaps xmm9, [rsp+0x80]
000078805cdde502  vmovaps xmm10, [rsp+0x90]
000078805cdde50b  vmovaps xmm11, [rsp+0xA0]
000078805cdde514  vmovaps xmm12, [rsp+0xB0]
000078805cdde51d  vmovaps xmm13, [rsp+0xC0]
000078805cdde526  vmovaps xmm14, [rsp+0xD0]
000078805cdde52f  vmovaps xmm15, [rsp+0xE0]
000078805cdde538  add rsp, 0xF0
000078805cdde53f  pop r11
000078805cdde541  pop r10
000078805cdde543  pop r9
000078805cdde545  pop r8
000078805cdde547  pop rsi
000078805cdde548  pop rdi
000078805cdde549  pop rdx
000078805cdde54a  pop rcx
000078805cdde54b  pop rax
000078805cdde54c  add rsp, 0x08
000078805cdde550  jmp 0x000078805CDDC13A
000078805cdde555  sub rsp, 0x08
000078805cdde559  push rax
000078805cdde55a  push rcx
000078805cdde55b  push rdx
000078805cdde55c  push rdi
000078805cdde55d  push rsi
000078805cdde55e  push r8
000078805cdde560  push r9
000078805cdde562  push r10
000078805cdde564  push r11
000078805cdde566  sub rsp, 0xF0
000078805cdde56d  vmovaps [rsp], xmm0
000078805cdde572  vmovaps [rsp+0x10], xmm1
000078805cdde578  vmovaps [rsp+0x20], xmm2
000078805cdde57e  vmovaps [rsp+0x30], xmm3
000078805cdde584  vmovaps [rsp+0x40], xmm4
000078805cdde58a  vmovaps [rsp+0x50], xmm5
000078805cdde590  vmovaps [rsp+0x60], xmm7
000078805cdde596  vmovaps [rsp+0x70], xmm8
000078805cdde59c  vmovaps [rsp+0x80], xmm9
000078805cdde5a5  vmovaps [rsp+0x90], xmm10
000078805cdde5ae  vmovaps [rsp+0xA0], xmm11
000078805cdde5b7  vmovaps [rsp+0xB0], xmm12
000078805cdde5c0  vmovaps [rsp+0xC0], xmm13
000078805cdde5c9  vmovaps [rsp+0xD0], xmm14
000078805cdde5d2  vmovaps [rsp+0xE0], xmm15
000078805cdde5db  sub rsp, 0x30
000078805cdde5df  movaps [rsp], xmm6
000078805cdde5e3  movaps [rsp+0x10], xmm9
000078805cdde5e9  movaps [rsp+0x20], xmm1
000078805cdde5ee  lea rdi, [rsp]
000078805cdde5f2  mov esi, 0x00
000078805cdde5f7  mov rax, 0x5771AD6EA530
000078805cdde601  call rax
000078805cdde603  movaps xmm6, [rsp]
000078805cdde607  add rsp, 0x30
000078805cdde60b  vmovaps xmm0, [rsp]
000078805cdde610  vmovaps xmm1, [rsp+0x10]
000078805cdde616  vmovaps xmm2, [rsp+0x20]
000078805cdde61c  vmovaps xmm3, [rsp+0x30]
000078805cdde622  vmovaps xmm4, [rsp+0x40]
000078805cdde628  vmovaps xmm5, [rsp+0x50]
000078805cdde62e  vmovaps xmm7, [rsp+0x60]
000078805cdde634  vmovaps xmm8, [rsp+0x70]
000078805cdde63a  vmovaps xmm9, [rsp+0x80]
000078805cdde643  vmovaps xmm10, [rsp+0x90]
000078805cdde64c  vmovaps xmm11, [rsp+0xA0]
000078805cdde655  vmovaps xmm12, [rsp+0xB0]
000078805cdde65e  vmovaps xmm13, [rsp+0xC0]
000078805cdde667  vmovaps xmm14, [rsp+0xD0]
000078805cdde670  vmovaps xmm15, [rsp+0xE0]
000078805cdde679  add rsp, 0xF0
000078805cdde680  pop r11
000078805cdde682  pop r10
000078805cdde684  pop r9
000078805cdde686  pop r8
000078805cdde688  pop rsi
000078805cdde689  pop rdi
000078805cdde68a  pop rdx
000078805cdde68b  pop rcx
000078805cdde68c  pop rax
000078805cdde68d  add rsp, 0x08
000078805cdde691  jmp 0x000078805CDDC15E
000078805cdde696  sub rsp, 0x08
000078805cdde69a  push rax
000078805cdde69b  push rcx
000078805cdde69c  push rdx
000078805cdde69d  push rdi
000078805cdde69e  push rsi
000078805cdde69f  push r8
000078805cdde6a1  push r9
000078805cdde6a3  push r10
000078805cdde6a5  push r11
000078805cdde6a7  sub rsp, 0xF0
000078805cdde6ae  vmovaps [rsp], xmm0
000078805cdde6b3  vmovaps [rsp+0x10], xmm1
000078805cdde6b9  vmovaps [rsp+0x20], xmm2
000078805cdde6bf  vmovaps [rsp+0x30], xmm3
000078805cdde6c5  vmovaps [rsp+0x40], xmm4
000078805cdde6cb  vmovaps [rsp+0x50], xmm5
000078805cdde6d1  vmovaps [rsp+0x60], xmm6
000078805cdde6d7  vmovaps [rsp+0x70], xmm7
000078805cdde6dd  vmovaps [rsp+0x80], xmm8
000078805cdde6e6  vmovaps [rsp+0x90], xmm10
000078805cdde6ef  vmovaps [rsp+0xA0], xmm11
000078805cdde6f8  vmovaps [rsp+0xB0], xmm12
000078805cdde701  vmovaps [rsp+0xC0], xmm13
000078805cdde70a  vmovaps [rsp+0xD0], xmm14
000078805cdde713  vmovaps [rsp+0xE0], xmm15
000078805cdde71c  sub rsp, 0x30
000078805cdde720  movaps [rsp], xmm9
000078805cdde725  movaps [rsp+0x10], xmm3
000078805cdde72a  movaps [rsp+0x20], xmm1
000078805cdde72f  lea rdi, [rsp]
000078805cdde733  mov esi, 0x00
000078805cdde738  mov rax, 0x5771AD6EA530
000078805cdde742  call rax
000078805cdde744  movaps xmm9, [rsp]
000078805cdde749  add rsp, 0x30
000078805cdde74d  vmovaps xmm0, [rsp]
000078805cdde752  vmovaps xmm1, [rsp+0x10]
000078805cdde758  vmovaps xmm2, [rsp+0x20]
000078805cdde75e  vmovaps xmm3, [rsp+0x30]
000078805cdde764  vmovaps xmm4, [rsp+0x40]
000078805cdde76a  vmovaps xmm5, [rsp+0x50]
000078805cdde770  vmovaps xmm6, [rsp+0x60]
000078805cdde776  vmovaps xmm7, [rsp+0x70]
000078805cdde77c  vmovaps xmm8, [rsp+0x80]
000078805cdde785  vmovaps xmm10, [rsp+0x90]
000078805cdde78e  vmovaps xmm11, [rsp+0xA0]
000078805cdde797  vmovaps xmm12, [rsp+0xB0]
000078805cdde7a0  vmovaps xmm13, [rsp+0xC0]
000078805cdde7a9  vmovaps xmm14, [rsp+0xD0]
000078805cdde7b2  vmovaps xmm15, [rsp+0xE0]
000078805cdde7bb  add rsp, 0xF0
000078805cdde7c2  pop r11
000078805cdde7c4  pop r10
000078805cdde7c6  pop r9
000078805cdde7c8  pop r8
000078805cdde7ca  pop rsi
000078805cdde7cb  pop rdi
000078805cdde7cc  pop rdx
000078805cdde7cd  pop rcx
000078805cdde7ce  pop rax
000078805cdde7cf  add rsp, 0x08
000078805cdde7d3  jmp 0x000078805CDDC1AA
000078805cdde7d8  call 0x000078805CCB52F0
000078805cdde7dd  jmp 0x000078805CDDC1B7
000078805cdde7e2  sub rsp, 0x08
000078805cdde7e6  push rax
000078805cdde7e7  push rcx
000078805cdde7e8  push rdx
000078805cdde7e9  push rdi
000078805cdde7ea  push rsi
000078805cdde7eb  push r8
000078805cdde7ed  push r9
000078805cdde7ef  push r10
000078805cdde7f1  push r11
000078805cdde7f3  sub rsp, 0xF0
000078805cdde7fa  vmovaps [rsp], xmm0
000078805cdde7ff  vmovaps [rsp+0x10], xmm1
000078805cdde805  vmovaps [rsp+0x20], xmm2
000078805cdde80b  vmovaps [rsp+0x30], xmm3
000078805cdde811  vmovaps [rsp+0x40], xmm4
000078805cdde817  vmovaps [rsp+0x50], xmm5
000078805cdde81d  vmovaps [rsp+0x60], xmm6
000078805cdde823  vmovaps [rsp+0x70], xmm7
000078805cdde829  vmovaps [rsp+0x80], xmm8
000078805cdde832  vmovaps [rsp+0x90], xmm9
000078805cdde83b  vmovaps [rsp+0xA0], xmm10
000078805cdde844  vmovaps [rsp+0xB0], xmm11
000078805cdde84d  vmovaps [rsp+0xC0], xmm12
000078805cdde856  vmovaps [rsp+0xD0], xmm13
000078805cdde85f  vmovaps [rsp+0xE0], xmm14
000078805cdde868  sub rsp, 0x30
000078805cdde86c  movaps [rsp], xmm15
000078805cdde871  movaps [rsp+0x10], xmm3
000078805cdde876  movaps [rsp+0x20], xmm7
000078805cdde87b  lea rdi, [rsp]
000078805cdde87f  mov esi, 0x00
000078805cdde884  mov rax, 0x5771AD6EA530
000078805cdde88e  call rax
000078805cdde890  movaps xmm15, [rsp]
000078805cdde895  add rsp, 0x30
000078805cdde899  vmovaps xmm0, [rsp]
000078805cdde89e  vmovaps xmm1, [rsp+0x10]
000078805cdde8a4  vmovaps xmm2, [rsp+0x20]
000078805cdde8aa  vmovaps xmm3, [rsp+0x30]
000078805cdde8b0  vmovaps xmm4, [rsp+0x40]
000078805cdde8b6  vmovaps xmm5, [rsp+0x50]
000078805cdde8bc  vmovaps xmm6, [rsp+0x60]
000078805cdde8c2  vmovaps xmm7, [rsp+0x70]
000078805cdde8c8  vmovaps xmm8, [rsp+0x80]
000078805cdde8d1  vmovaps xmm9, [rsp+0x90]
000078805cdde8da  vmovaps xmm10, [rsp+0xA0]
000078805cdde8e3  vmovaps xmm11, [rsp+0xB0]
000078805cdde8ec  vmovaps xmm12, [rsp+0xC0]
000078805cdde8f5  vmovaps xmm13, [rsp+0xD0]
000078805cdde8fe  vmovaps xmm14, [rsp+0xE0]
000078805cdde907  add rsp, 0xF0
000078805cdde90e  pop r11
000078805cdde910  pop r10
000078805cdde912  pop r9
000078805cdde914  pop r8
000078805cdde916  pop rsi
000078805cdde917  pop rdi
000078805cdde918  pop rdx
000078805cdde919  pop rcx
000078805cdde91a  pop rax
000078805cdde91b  add rsp, 0x08
000078805cdde91f  jmp 0x000078805CDDC1E3
000078805cdde924  sub rsp, 0x08
000078805cdde928  push rax
000078805cdde929  push rcx
000078805cdde92a  push rdx
000078805cdde92b  push rdi
000078805cdde92c  push rsi
000078805cdde92d  push r8
000078805cdde92f  push r9
000078805cdde931  push r10
000078805cdde933  push r11
000078805cdde935  sub rsp, 0xF0
000078805cdde93c  vmovaps [rsp], xmm0
000078805cdde941  vmovaps [rsp+0x10], xmm1
000078805cdde947  vmovaps [rsp+0x20], xmm2
000078805cdde94d  vmovaps [rsp+0x30], xmm4
000078805cdde953  vmovaps [rsp+0x40], xmm5
000078805cdde959  vmovaps [rsp+0x50], xmm6
000078805cdde95f  vmovaps [rsp+0x60], xmm7
000078805cdde965  vmovaps [rsp+0x70], xmm8
000078805cdde96b  vmovaps [rsp+0x80], xmm9
000078805cdde974  vmovaps [rsp+0x90], xmm10
000078805cdde97d  vmovaps [rsp+0xA0], xmm11
000078805cdde986  vmovaps [rsp+0xB0], xmm12
000078805cdde98f  vmovaps [rsp+0xC0], xmm13
000078805cdde998  vmovaps [rsp+0xD0], xmm14
000078805cdde9a1  vmovaps [rsp+0xE0], xmm15
000078805cdde9aa  sub rsp, 0x30
000078805cdde9ae  movaps [rsp], xmm3
000078805cdde9b2  movaps [rsp+0x10], xmm1
000078805cdde9b7  movaps [rsp+0x20], xmm15
000078805cdde9bd  lea rdi, [rsp]
000078805cdde9c1  mov esi, 0x00
000078805cdde9c6  mov rax, 0x5771AD6EA530
000078805cdde9d0  call rax
000078805cdde9d2  movaps xmm3, [rsp]
000078805cdde9d6  add rsp, 0x30
000078805cdde9da  vmovaps xmm0, [rsp]
000078805cdde9df  vmovaps xmm1, [rsp+0x10]
000078805cdde9e5  vmovaps xmm2, [rsp+0x20]
000078805cdde9eb  vmovaps xmm4, [rsp+0x30]
000078805cdde9f1  vmovaps xmm5, [rsp+0x40]
000078805cdde9f7  vmovaps xmm6, [rsp+0x50]
000078805cdde9fd  vmovaps xmm7, [rsp+0x60]
000078805cddea03  vmovaps xmm8, [rsp+0x70]
000078805cddea09  vmovaps xmm9, [rsp+0x80]
000078805cddea12  vmovaps xmm10, [rsp+0x90]
000078805cddea1b  vmovaps xmm11, [rsp+0xA0]
000078805cddea24  vmovaps xmm12, [rsp+0xB0]
000078805cddea2d  vmovaps xmm13, [rsp+0xC0]
000078805cddea36  vmovaps xmm14, [rsp+0xD0]
000078805cddea3f  vmovaps xmm15, [rsp+0xE0]
000078805cddea48  add rsp, 0xF0
000078805cddea4f  pop r11
000078805cddea51  pop r10
000078805cddea53  pop r9
000078805cddea55  pop r8
000078805cddea57  pop rsi
000078805cddea58  pop rdi
000078805cddea59  pop rdx
000078805cddea5a  pop rcx
000078805cddea5b  pop rax
000078805cddea5c  add rsp, 0x08
000078805cddea60  jmp 0x000078805CDDC272
000078805cddea65  call 0x000078805CCB52F0
000078805cddea6a  jmp 0x000078805CDDC27C
000078805cddea6f  sub rsp, 0x08
000078805cddea73  push rax
000078805cddea74  push rcx
000078805cddea75  push rdx
000078805cddea76  push rdi
000078805cddea77  push rsi
000078805cddea78  push r8
000078805cddea7a  push r9
000078805cddea7c  push r10
000078805cddea7e  push r11
000078805cddea80  sub rsp, 0xF0
000078805cddea87  vmovaps [rsp], xmm0
000078805cddea8c  vmovaps [rsp+0x10], xmm1
000078805cddea92  vmovaps [rsp+0x20], xmm2
000078805cddea98  vmovaps [rsp+0x30], xmm3
000078805cddea9e  vmovaps [rsp+0x40], xmm4
000078805cddeaa4  vmovaps [rsp+0x50], xmm5
000078805cddeaaa  vmovaps [rsp+0x60], xmm6
000078805cddeab0  vmovaps [rsp+0x70], xmm7
000078805cddeab6  vmovaps [rsp+0x80], xmm8
000078805cddeabf  vmovaps [rsp+0x90], xmm9
000078805cddeac8  vmovaps [rsp+0xA0], xmm10
000078805cddead1  vmovaps [rsp+0xB0], xmm11
000078805cddeada  vmovaps [rsp+0xC0], xmm12
000078805cddeae3  vmovaps [rsp+0xD0], xmm13
000078805cddeaec  vmovaps [rsp+0xE0], xmm14
000078805cddeaf5  sub rsp, 0x30
000078805cddeaf9  movaps [rsp], xmm15
000078805cddeafe  movaps [rsp+0x10], xmm14
000078805cddeb04  movaps [rsp+0x20], xmm4
000078805cddeb09  lea rdi, [rsp]
000078805cddeb0d  mov esi, 0x00
000078805cddeb12  mov rax, 0x5771AD6EA530
000078805cddeb1c  call rax
000078805cddeb1e  movaps xmm15, [rsp]
000078805cddeb23  add rsp, 0x30
000078805cddeb27  vmovaps xmm0, [rsp]
000078805cddeb2c  vmovaps xmm1, [rsp+0x10]
000078805cddeb32  vmovaps xmm2, [rsp+0x20]
000078805cddeb38  vmovaps xmm3, [rsp+0x30]
000078805cddeb3e  vmovaps xmm4, [rsp+0x40]
000078805cddeb44  vmovaps xmm5, [rsp+0x50]
000078805cddeb4a  vmovaps xmm6, [rsp+0x60]
000078805cddeb50  vmovaps xmm7, [rsp+0x70]
000078805cddeb56  vmovaps xmm8, [rsp+0x80]
000078805cddeb5f  vmovaps xmm9, [rsp+0x90]
000078805cddeb68  vmovaps xmm10, [rsp+0xA0]
000078805cddeb71  vmovaps xmm11, [rsp+0xB0]
000078805cddeb7a  vmovaps xmm12, [rsp+0xC0]
000078805cddeb83  vmovaps xmm13, [rsp+0xD0]
000078805cddeb8c  vmovaps xmm14, [rsp+0xE0]
000078805cddeb95  add rsp, 0xF0
000078805cddeb9c  pop r11
000078805cddeb9e  pop r10
000078805cddeba0  pop r9
000078805cddeba2  pop r8
000078805cddeba4  pop rsi
000078805cddeba5  pop rdi
000078805cddeba6  pop rdx
000078805cddeba7  pop rcx
000078805cddeba8  pop rax
000078805cddeba9  add rsp, 0x08
000078805cddebad  jmp 0x000078805CDDC2AA
000078805cddebb2  sub rsp, 0x08
000078805cddebb6  push rax
000078805cddebb7  push rcx
000078805cddebb8  push rdx
000078805cddebb9  push rdi
000078805cddebba  push rsi
000078805cddebbb  push r8
000078805cddebbd  push r9
000078805cddebbf  push r10
000078805cddebc1  push r11
000078805cddebc3  sub rsp, 0xF0
000078805cddebca  vmovaps [rsp], xmm0
000078805cddebcf  vmovaps [rsp+0x10], xmm1
000078805cddebd5  vmovaps [rsp+0x20], xmm2
000078805cddebdb  vmovaps [rsp+0x30], xmm3
000078805cddebe1  vmovaps [rsp+0x40], xmm4
000078805cddebe7  vmovaps [rsp+0x50], xmm5
000078805cddebed  vmovaps [rsp+0x60], xmm6
000078805cddebf3  vmovaps [rsp+0x70], xmm7
000078805cddebf9  vmovaps [rsp+0x80], xmm8
000078805cddec02  vmovaps [rsp+0x90], xmm9
000078805cddec0b  vmovaps [rsp+0xA0], xmm10
000078805cddec14  vmovaps [rsp+0xB0], xmm11
000078805cddec1d  vmovaps [rsp+0xC0], xmm12
000078805cddec26  vmovaps [rsp+0xD0], xmm13
000078805cddec2f  vmovaps [rsp+0xE0], xmm15
000078805cddec38  sub rsp, 0x30
000078805cddec3c  movaps [rsp], xmm14
000078805cddec41  movaps [rsp+0x10], xmm2
000078805cddec46  movaps [rsp+0x20], xmm1
000078805cddec4b  lea rdi, [rsp]
000078805cddec4f  mov esi, 0x00
000078805cddec54  mov rax, 0x5771AD6EA530
000078805cddec5e  call rax
000078805cddec60  movaps xmm14, [rsp]
000078805cddec65  add rsp, 0x30
000078805cddec69  vmovaps xmm0, [rsp]
000078805cddec6e  vmovaps xmm1, [rsp+0x10]
000078805cddec74  vmovaps xmm2, [rsp+0x20]
000078805cddec7a  vmovaps xmm3, [rsp+0x30]
000078805cddec80  vmovaps xmm4, [rsp+0x40]
000078805cddec86  vmovaps xmm5, [rsp+0x50]
000078805cddec8c  vmovaps xmm6, [rsp+0x60]
000078805cddec92  vmovaps xmm7, [rsp+0x70]
000078805cddec98  vmovaps xmm8, [rsp+0x80]
000078805cddeca1  vmovaps xmm9, [rsp+0x90]
000078805cddecaa  vmovaps xmm10, [rsp+0xA0]
000078805cddecb3  vmovaps xmm11, [rsp+0xB0]
000078805cddecbc  vmovaps xmm12, [rsp+0xC0]
000078805cddecc5  vmovaps xmm13, [rsp+0xD0]
000078805cddecce  vmovaps xmm15, [rsp+0xE0]
000078805cddecd7  add rsp, 0xF0
000078805cddecde  pop r11
000078805cddece0  pop r10
000078805cddece2  pop r9
000078805cddece4  pop r8
000078805cddece6  pop rsi
000078805cddece7  pop rdi
000078805cddece8  pop rdx
000078805cddece9  pop rcx
000078805cddecea  pop rax
000078805cddeceb  add rsp, 0x08
000078805cddecef  jmp 0x000078805CDDC2D0
000078805cddecf4  sub rsp, 0x08
000078805cddecf8  push rax
000078805cddecf9  push rcx
000078805cddecfa  push rdx
000078805cddecfb  push rdi
000078805cddecfc  push rsi
000078805cddecfd  push r8
000078805cddecff  push r9
000078805cdded01  push r10
000078805cdded03  push r11
000078805cdded05  sub rsp, 0xF0
000078805cdded0c  vmovaps [rsp], xmm0
000078805cdded11  vmovaps [rsp+0x10], xmm2
000078805cdded17  vmovaps [rsp+0x20], xmm3
000078805cdded1d  vmovaps [rsp+0x30], xmm4
000078805cdded23  vmovaps [rsp+0x40], xmm5
000078805cdded29  vmovaps [rsp+0x50], xmm6
000078805cdded2f  vmovaps [rsp+0x60], xmm7
000078805cdded35  vmovaps [rsp+0x70], xmm8
000078805cdded3b  vmovaps [rsp+0x80], xmm9
000078805cdded44  vmovaps [rsp+0x90], xmm10
000078805cdded4d  vmovaps [rsp+0xA0], xmm11
000078805cdded56  vmovaps [rsp+0xB0], xmm12
000078805cdded5f  vmovaps [rsp+0xC0], xmm13
000078805cdded68  vmovaps [rsp+0xD0], xmm14
000078805cdded71  vmovaps [rsp+0xE0], xmm15
000078805cdded7a  sub rsp, 0x30
000078805cdded7e  movaps [rsp], xmm1
000078805cdded82  movaps [rsp+0x10], xmm4
000078805cdded87  movaps [rsp+0x20], xmm9
000078805cdded8d  lea rdi, [rsp]
000078805cdded91  mov esi, 0x00
000078805cdded96  mov rax, 0x5771AD6EA530
000078805cddeda0  call rax
000078805cddeda2  movaps xmm1, [rsp]
000078805cddeda6  add rsp, 0x30
000078805cddedaa  vmovaps xmm0, [rsp]
000078805cddedaf  vmovaps xmm2, [rsp+0x10]
000078805cddedb5  vmovaps xmm3, [rsp+0x20]
000078805cddedbb  vmovaps xmm4, [rsp+0x30]
000078805cddedc1  vmovaps xmm5, [rsp+0x40]
000078805cddedc7  vmovaps xmm6, [rsp+0x50]
000078805cddedcd  vmovaps xmm7, [rsp+0x60]
000078805cddedd3  vmovaps xmm8, [rsp+0x70]
000078805cddedd9  vmovaps xmm9, [rsp+0x80]
000078805cddede2  vmovaps xmm10, [rsp+0x90]
000078805cddedeb  vmovaps xmm11, [rsp+0xA0]
000078805cddedf4  vmovaps xmm12, [rsp+0xB0]
000078805cddedfd  vmovaps xmm13, [rsp+0xC0]
000078805cddee06  vmovaps xmm14, [rsp+0xD0]
000078805cddee0f  vmovaps xmm15, [rsp+0xE0]
000078805cddee18  add rsp, 0xF0
000078805cddee1f  pop r11
000078805cddee21  pop r10
000078805cddee23  pop r9
000078805cddee25  pop r8
000078805cddee27  pop rsi
000078805cddee28  pop rdi
000078805cddee29  pop rdx
000078805cddee2a  pop rcx
000078805cddee2b  pop rax
000078805cddee2c  add rsp, 0x08
000078805cddee30  jmp 0x000078805CDDC2EE
000078805cddee35  sub rsp, 0x08
000078805cddee39  push rax
000078805cddee3a  push rcx
000078805cddee3b  push rdx
000078805cddee3c  push rdi
000078805cddee3d  push rsi
000078805cddee3e  push r8
000078805cddee40  push r9
000078805cddee42  push r10
000078805cddee44  push r11
000078805cddee46  sub rsp, 0xF0
000078805cddee4d  vmovaps [rsp], xmm0
000078805cddee52  vmovaps [rsp+0x10], xmm1
000078805cddee58  vmovaps [rsp+0x20], xmm2
000078805cddee5e  vmovaps [rsp+0x30], xmm3
000078805cddee64  vmovaps [rsp+0x40], xmm5
000078805cddee6a  vmovaps [rsp+0x50], xmm6
000078805cddee70  vmovaps [rsp+0x60], xmm7
000078805cddee76  vmovaps [rsp+0x70], xmm8
000078805cddee7c  vmovaps [rsp+0x80], xmm9
000078805cddee85  vmovaps [rsp+0x90], xmm10
000078805cddee8e  vmovaps [rsp+0xA0], xmm11
000078805cddee97  vmovaps [rsp+0xB0], xmm12
000078805cddeea0  vmovaps [rsp+0xC0], xmm13
000078805cddeea9  vmovaps [rsp+0xD0], xmm14
000078805cddeeb2  vmovaps [rsp+0xE0], xmm15
000078805cddeebb  sub rsp, 0x30
000078805cddeebf  movaps [rsp], xmm4
000078805cddeec3  movaps [rsp+0x10], xmm2
000078805cddeec8  movaps [rsp+0x20], xmm9
000078805cddeece  lea rdi, [rsp]
000078805cddeed2  mov esi, 0x00
000078805cddeed7  mov rax, 0x5771AD6EA530
000078805cddeee1  call rax
000078805cddeee3  movaps xmm4, [rsp]
000078805cddeee7  add rsp, 0x30
000078805cddeeeb  vmovaps xmm0, [rsp]
000078805cddeef0  vmovaps xmm1, [rsp+0x10]
000078805cddeef6  vmovaps xmm2, [rsp+0x20]
000078805cddeefc  vmovaps xmm3, [rsp+0x30]
000078805cddef02  vmovaps xmm5, [rsp+0x40]
000078805cddef08  vmovaps xmm6, [rsp+0x50]
000078805cddef0e  vmovaps xmm7, [rsp+0x60]
000078805cddef14  vmovaps xmm8, [rsp+0x70]
000078805cddef1a  vmovaps xmm9, [rsp+0x80]
000078805cddef23  vmovaps xmm10, [rsp+0x90]
000078805cddef2c  vmovaps xmm11, [rsp+0xA0]
000078805cddef35  vmovaps xmm12, [rsp+0xB0]
000078805cddef3e  vmovaps xmm13, [rsp+0xC0]
000078805cddef47  vmovaps xmm14, [rsp+0xD0]
000078805cddef50  vmovaps xmm15, [rsp+0xE0]
000078805cddef59  add rsp, 0xF0
000078805cddef60  pop r11
000078805cddef62  pop r10
000078805cddef64  pop r9
000078805cddef66  pop r8
000078805cddef68  pop rsi
000078805cddef69  pop rdi
000078805cddef6a  pop rdx
000078805cddef6b  pop rcx
000078805cddef6c  pop rax
000078805cddef6d  add rsp, 0x08
000078805cddef71  jmp 0x000078805CDDC31E
000078805cddef76  sub rsp, 0x08
000078805cddef7a  push rax
000078805cddef7b  push rcx
000078805cddef7c  push rdx
000078805cddef7d  push rdi
000078805cddef7e  push rsi
000078805cddef7f  push r8
000078805cddef81  push r9
000078805cddef83  push r10
000078805cddef85  push r11
000078805cddef87  sub rsp, 0xF0
000078805cddef8e  vmovaps [rsp], xmm0
000078805cddef93  vmovaps [rsp+0x10], xmm1
000078805cddef99  vmovaps [rsp+0x20], xmm2
000078805cddef9f  vmovaps [rsp+0x30], xmm3
000078805cddefa5  vmovaps [rsp+0x40], xmm4
000078805cddefab  vmovaps [rsp+0x50], xmm5
000078805cddefb1  vmovaps [rsp+0x60], xmm6
000078805cddefb7  vmovaps [rsp+0x70], xmm7
000078805cddefbd  vmovaps [rsp+0x80], xmm8
000078805cddefc6  vmovaps [rsp+0x90], xmm10
000078805cddefcf  vmovaps [rsp+0xA0], xmm11
000078805cddefd8  vmovaps [rsp+0xB0], xmm12
000078805cddefe1  vmovaps [rsp+0xC0], xmm13
000078805cddefea  vmovaps [rsp+0xD0], xmm14
000078805cddeff3  vmovaps [rsp+0xE0], xmm15
000078805cddeffc  sub rsp, 0x30
000078805cddf000  movaps [rsp], xmm9
000078805cddf005  movaps [rsp+0x10], xmm2
000078805cddf00a  movaps [rsp+0x20], xmm1
000078805cddf00f  lea rdi, [rsp]
000078805cddf013  mov esi, 0x00
000078805cddf018  mov rax, 0x5771AD6EA530
000078805cddf022  call rax
000078805cddf024  movaps xmm9, [rsp]
000078805cddf029  add rsp, 0x30
000078805cddf02d  vmovaps xmm0, [rsp]
000078805cddf032  vmovaps xmm1, [rsp+0x10]
000078805cddf038  vmovaps xmm2, [rsp+0x20]
000078805cddf03e  vmovaps xmm3, [rsp+0x30]
000078805cddf044  vmovaps xmm4, [rsp+0x40]
000078805cddf04a  vmovaps xmm5, [rsp+0x50]
000078805cddf050  vmovaps xmm6, [rsp+0x60]
000078805cddf056  vmovaps xmm7, [rsp+0x70]
000078805cddf05c  vmovaps xmm8, [rsp+0x80]
000078805cddf065  vmovaps xmm10, [rsp+0x90]
000078805cddf06e  vmovaps xmm11, [rsp+0xA0]
000078805cddf077  vmovaps xmm12, [rsp+0xB0]
000078805cddf080  vmovaps xmm13, [rsp+0xC0]
000078805cddf089  vmovaps xmm14, [rsp+0xD0]
000078805cddf092  vmovaps xmm15, [rsp+0xE0]
000078805cddf09b  add rsp, 0xF0
000078805cddf0a2  pop r11
000078805cddf0a4  pop r10
000078805cddf0a6  pop r9
000078805cddf0a8  pop r8
000078805cddf0aa  pop rsi
000078805cddf0ab  pop rdi
000078805cddf0ac  pop rdx
000078805cddf0ad  pop rcx
000078805cddf0ae  pop rax
000078805cddf0af  add rsp, 0x08
000078805cddf0b3  jmp 0x000078805CDDC354
000078805cddf0b8  sub rsp, 0x08
000078805cddf0bc  push rax
000078805cddf0bd  push rcx
000078805cddf0be  push rdx
000078805cddf0bf  push rdi
000078805cddf0c0  push rsi
000078805cddf0c1  push r8
000078805cddf0c3  push r9
000078805cddf0c5  push r10
000078805cddf0c7  push r11
000078805cddf0c9  sub rsp, 0xF0
000078805cddf0d0  vmovaps [rsp], xmm0
000078805cddf0d5  vmovaps [rsp+0x10], xmm2
000078805cddf0db  vmovaps [rsp+0x20], xmm3
000078805cddf0e1  vmovaps [rsp+0x30], xmm4
000078805cddf0e7  vmovaps [rsp+0x40], xmm5
000078805cddf0ed  vmovaps [rsp+0x50], xmm6
000078805cddf0f3  vmovaps [rsp+0x60], xmm7
000078805cddf0f9  vmovaps [rsp+0x70], xmm8
000078805cddf0ff  vmovaps [rsp+0x80], xmm9
000078805cddf108  vmovaps [rsp+0x90], xmm10
000078805cddf111  vmovaps [rsp+0xA0], xmm11
000078805cddf11a  vmovaps [rsp+0xB0], xmm12
000078805cddf123  vmovaps [rsp+0xC0], xmm13
000078805cddf12c  vmovaps [rsp+0xD0], xmm14
000078805cddf135  vmovaps [rsp+0xE0], xmm15
000078805cddf13e  sub rsp, 0x30
000078805cddf142  movaps [rsp], xmm1
000078805cddf146  movaps [rsp+0x10], xmm15
000078805cddf14c  movaps [rsp+0x20], xmm6
000078805cddf151  lea rdi, [rsp]
000078805cddf155  mov esi, 0x00
000078805cddf15a  mov rax, 0x5771AD6EA530
000078805cddf164  call rax
000078805cddf166  movaps xmm1, [rsp]
000078805cddf16a  add rsp, 0x30
000078805cddf16e  vmovaps xmm0, [rsp]
000078805cddf173  vmovaps xmm2, [rsp+0x10]
000078805cddf179  vmovaps xmm3, [rsp+0x20]
000078805cddf17f  vmovaps xmm4, [rsp+0x30]
000078805cddf185  vmovaps xmm5, [rsp+0x40]
000078805cddf18b  vmovaps xmm6, [rsp+0x50]
000078805cddf191  vmovaps xmm7, [rsp+0x60]
000078805cddf197  vmovaps xmm8, [rsp+0x70]
000078805cddf19d  vmovaps xmm9, [rsp+0x80]
000078805cddf1a6  vmovaps xmm10, [rsp+0x90]
000078805cddf1af  vmovaps xmm11, [rsp+0xA0]
000078805cddf1b8  vmovaps xmm12, [rsp+0xB0]
000078805cddf1c1  vmovaps xmm13, [rsp+0xC0]
000078805cddf1ca  vmovaps xmm14, [rsp+0xD0]
000078805cddf1d3  vmovaps xmm15, [rsp+0xE0]
000078805cddf1dc  add rsp, 0xF0
000078805cddf1e3  pop r11
000078805cddf1e5  pop r10
000078805cddf1e7  pop r9
000078805cddf1e9  pop r8
000078805cddf1eb  pop rsi
000078805cddf1ec  pop rdi
000078805cddf1ed  pop rdx
000078805cddf1ee  pop rcx
000078805cddf1ef  pop rax
000078805cddf1f0  add rsp, 0x08
000078805cddf1f4  jmp 0x000078805CDDC375
000078805cddf1f9  sub rsp, 0x08
000078805cddf1fd  push rax
000078805cddf1fe  push rcx
000078805cddf1ff  push rdx
000078805cddf200  push rdi
000078805cddf201  push rsi
000078805cddf202  push r8
000078805cddf204  push r9
000078805cddf206  push r10
000078805cddf208  push r11
000078805cddf20a  sub rsp, 0xF0
000078805cddf211  vmovaps [rsp], xmm0
000078805cddf216  vmovaps [rsp+0x10], xmm1
000078805cddf21c  vmovaps [rsp+0x20], xmm2
000078805cddf222  vmovaps [rsp+0x30], xmm3
000078805cddf228  vmovaps [rsp+0x40], xmm4
000078805cddf22e  vmovaps [rsp+0x50], xmm5
000078805cddf234  vmovaps [rsp+0x60], xmm6
000078805cddf23a  vmovaps [rsp+0x70], xmm7
000078805cddf240  vmovaps [rsp+0x80], xmm8
000078805cddf249  vmovaps [rsp+0x90], xmm9
000078805cddf252  vmovaps [rsp+0xA0], xmm10
000078805cddf25b  vmovaps [rsp+0xB0], xmm11
000078805cddf264  vmovaps [rsp+0xC0], xmm12
000078805cddf26d  vmovaps [rsp+0xD0], xmm13
000078805cddf276  vmovaps [rsp+0xE0], xmm14
000078805cddf27f  sub rsp, 0x30
000078805cddf283  movaps [rsp], xmm15
000078805cddf288  movaps [rsp+0x10], xmm5
000078805cddf28d  movaps [rsp+0x20], xmm3
000078805cddf292  lea rdi, [rsp]
000078805cddf296  mov esi, 0x00
000078805cddf29b  mov rax, 0x5771AD6EA530
000078805cddf2a5  call rax
000078805cddf2a7  movaps xmm15, [rsp]
000078805cddf2ac  add rsp, 0x30
000078805cddf2b0  vmovaps xmm0, [rsp]
000078805cddf2b5  vmovaps xmm1, [rsp+0x10]
000078805cddf2bb  vmovaps xmm2, [rsp+0x20]
000078805cddf2c1  vmovaps xmm3, [rsp+0x30]
000078805cddf2c7  vmovaps xmm4, [rsp+0x40]
000078805cddf2cd  vmovaps xmm5, [rsp+0x50]
000078805cddf2d3  vmovaps xmm6, [rsp+0x60]
000078805cddf2d9  vmovaps xmm7, [rsp+0x70]
000078805cddf2df  vmovaps xmm8, [rsp+0x80]
000078805cddf2e8  vmovaps xmm9, [rsp+0x90]
000078805cddf2f1  vmovaps xmm10, [rsp+0xA0]
000078805cddf2fa  vmovaps xmm11, [rsp+0xB0]
000078805cddf303  vmovaps xmm12, [rsp+0xC0]
000078805cddf30c  vmovaps xmm13, [rsp+0xD0]
000078805cddf315  vmovaps xmm14, [rsp+0xE0]
000078805cddf31e  add rsp, 0xF0
000078805cddf325  pop r11
000078805cddf327  pop r10
000078805cddf329  pop r9
000078805cddf32b  pop r8
000078805cddf32d  pop rsi
000078805cddf32e  pop rdi
000078805cddf32f  pop rdx
000078805cddf330  pop rcx
000078805cddf331  pop rax
000078805cddf332  add rsp, 0x08
000078805cddf336  jmp 0x000078805CDDC38F
000078805cddf33b  sub rsp, 0x08
000078805cddf33f  push rax
000078805cddf340  push rcx
000078805cddf341  push rdx
000078805cddf342  push rdi
000078805cddf343  push rsi
000078805cddf344  push r8
000078805cddf346  push r9
000078805cddf348  push r10
000078805cddf34a  push r11
000078805cddf34c  sub rsp, 0xF0
000078805cddf353  vmovaps [rsp], xmm0
000078805cddf358  vmovaps [rsp+0x10], xmm1
000078805cddf35e  vmovaps [rsp+0x20], xmm2
000078805cddf364  vmovaps [rsp+0x30], xmm3
000078805cddf36a  vmovaps [rsp+0x40], xmm4
000078805cddf370  vmovaps [rsp+0x50], xmm6
000078805cddf376  vmovaps [rsp+0x60], xmm7
000078805cddf37c  vmovaps [rsp+0x70], xmm8
000078805cddf382  vmovaps [rsp+0x80], xmm9
000078805cddf38b  vmovaps [rsp+0x90], xmm10
000078805cddf394  vmovaps [rsp+0xA0], xmm11
000078805cddf39d  vmovaps [rsp+0xB0], xmm12
000078805cddf3a6  vmovaps [rsp+0xC0], xmm13
000078805cddf3af  vmovaps [rsp+0xD0], xmm14
000078805cddf3b8  vmovaps [rsp+0xE0], xmm15
000078805cddf3c1  sub rsp, 0x30
000078805cddf3c5  movaps [rsp], xmm5
000078805cddf3c9  movaps [rsp+0x10], xmm8
000078805cddf3cf  movaps [rsp+0x20], xmm6
000078805cddf3d4  lea rdi, [rsp]
000078805cddf3d8  mov esi, 0x00
000078805cddf3dd  mov rax, 0x5771AD6EA530
000078805cddf3e7  call rax
000078805cddf3e9  movaps xmm5, [rsp]
000078805cddf3ed  add rsp, 0x30
000078805cddf3f1  vmovaps xmm0, [rsp]
000078805cddf3f6  vmovaps xmm1, [rsp+0x10]
000078805cddf3fc  vmovaps xmm2, [rsp+0x20]
000078805cddf402  vmovaps xmm3, [rsp+0x30]
000078805cddf408  vmovaps xmm4, [rsp+0x40]
000078805cddf40e  vmovaps xmm6, [rsp+0x50]
000078805cddf414  vmovaps xmm7, [rsp+0x60]
000078805cddf41a  vmovaps xmm8, [rsp+0x70]
000078805cddf420  vmovaps xmm9, [rsp+0x80]
000078805cddf429  vmovaps xmm10, [rsp+0x90]
000078805cddf432  vmovaps xmm11, [rsp+0xA0]
000078805cddf43b  vmovaps xmm12, [rsp+0xB0]
000078805cddf444  vmovaps xmm13, [rsp+0xC0]
000078805cddf44d  vmovaps xmm14, [rsp+0xD0]
000078805cddf456  vmovaps xmm15, [rsp+0xE0]
000078805cddf45f  add rsp, 0xF0
000078805cddf466  pop r11
000078805cddf468  pop r10
000078805cddf46a  pop r9
000078805cddf46c  pop r8
000078805cddf46e  pop rsi
000078805cddf46f  pop rdi
000078805cddf470  pop rdx
000078805cddf471  pop rcx
000078805cddf472  pop rax
000078805cddf473  add rsp, 0x08
000078805cddf477  jmp 0x000078805CDDC3B3
000078805cddf47c  sub rsp, 0x08
000078805cddf480  push rax
000078805cddf481  push rcx
000078805cddf482  push rdx
000078805cddf483  push rdi
000078805cddf484  push rsi
000078805cddf485  push r8
000078805cddf487  push r9
000078805cddf489  push r10
000078805cddf48b  push r11
000078805cddf48d  sub rsp, 0xF0
000078805cddf494  vmovaps [rsp], xmm0
000078805cddf499  vmovaps [rsp+0x10], xmm1
000078805cddf49f  vmovaps [rsp+0x20], xmm2
000078805cddf4a5  vmovaps [rsp+0x30], xmm3
000078805cddf4ab  vmovaps [rsp+0x40], xmm4
000078805cddf4b1  vmovaps [rsp+0x50], xmm5
000078805cddf4b7  vmovaps [rsp+0x60], xmm7
000078805cddf4bd  vmovaps [rsp+0x70], xmm8
000078805cddf4c3  vmovaps [rsp+0x80], xmm9
000078805cddf4cc  vmovaps [rsp+0x90], xmm10
000078805cddf4d5  vmovaps [rsp+0xA0], xmm11
000078805cddf4de  vmovaps [rsp+0xB0], xmm12
000078805cddf4e7  vmovaps [rsp+0xC0], xmm13
000078805cddf4f0  vmovaps [rsp+0xD0], xmm14
000078805cddf4f9  vmovaps [rsp+0xE0], xmm15
000078805cddf502  sub rsp, 0x30
000078805cddf506  movaps [rsp], xmm6
000078805cddf50a  movaps [rsp+0x10], xmm10
000078805cddf510  movaps [rsp+0x20], xmm8
000078805cddf516  lea rdi, [rsp]
000078805cddf51a  mov esi, 0x00
000078805cddf51f  mov rax, 0x5771AD6EA530
000078805cddf529  call rax
000078805cddf52b  movaps xmm6, [rsp]
000078805cddf52f  add rsp, 0x30
000078805cddf533  vmovaps xmm0, [rsp]
000078805cddf538  vmovaps xmm1, [rsp+0x10]
000078805cddf53e  vmovaps xmm2, [rsp+0x20]
000078805cddf544  vmovaps xmm3, [rsp+0x30]
000078805cddf54a  vmovaps xmm4, [rsp+0x40]
000078805cddf550  vmovaps xmm5, [rsp+0x50]
000078805cddf556  vmovaps xmm7, [rsp+0x60]
000078805cddf55c  vmovaps xmm8, [rsp+0x70]
000078805cddf562  vmovaps xmm9, [rsp+0x80]
000078805cddf56b  vmovaps xmm10, [rsp+0x90]
000078805cddf574  vmovaps xmm11, [rsp+0xA0]
000078805cddf57d  vmovaps xmm12, [rsp+0xB0]
000078805cddf586  vmovaps xmm13, [rsp+0xC0]
000078805cddf58f  vmovaps xmm14, [rsp+0xD0]
000078805cddf598  vmovaps xmm15, [rsp+0xE0]
000078805cddf5a1  add rsp, 0xF0
000078805cddf5a8  pop r11
000078805cddf5aa  pop r10
000078805cddf5ac  pop r9
000078805cddf5ae  pop r8
000078805cddf5b0  pop rsi
000078805cddf5b1  pop rdi
000078805cddf5b2  pop rdx
000078805cddf5b3  pop rcx
000078805cddf5b4  pop rax
000078805cddf5b5  add rsp, 0x08
000078805cddf5b9  jmp 0x000078805CDDC3D8
000078805cddf5be  sub rsp, 0x08
000078805cddf5c2  push rax
000078805cddf5c3  push rcx
000078805cddf5c4  push rdx
000078805cddf5c5  push rdi
000078805cddf5c6  push rsi
000078805cddf5c7  push r8
000078805cddf5c9  push r9
000078805cddf5cb  push r10
000078805cddf5cd  push r11
000078805cddf5cf  sub rsp, 0xF0
000078805cddf5d6  vmovaps [rsp], xmm0
000078805cddf5db  vmovaps [rsp+0x10], xmm1
000078805cddf5e1  vmovaps [rsp+0x20], xmm2
000078805cddf5e7  vmovaps [rsp+0x30], xmm3
000078805cddf5ed  vmovaps [rsp+0x40], xmm4
000078805cddf5f3  vmovaps [rsp+0x50], xmm5
000078805cddf5f9  vmovaps [rsp+0x60], xmm6
000078805cddf5ff  vmovaps [rsp+0x70], xmm7
000078805cddf605  vmovaps [rsp+0x80], xmm8
000078805cddf60e  vmovaps [rsp+0x90], xmm9
000078805cddf617  vmovaps [rsp+0xA0], xmm11
000078805cddf620  vmovaps [rsp+0xB0], xmm12
000078805cddf629  vmovaps [rsp+0xC0], xmm13
000078805cddf632  vmovaps [rsp+0xD0], xmm14
000078805cddf63b  vmovaps [rsp+0xE0], xmm15
000078805cddf644  sub rsp, 0x30
000078805cddf648  movaps [rsp], xmm10
000078805cddf64d  movaps [rsp+0x10], xmm8
000078805cddf653  movaps [rsp+0x20], xmm14
000078805cddf659  lea rdi, [rsp]
000078805cddf65d  mov esi, 0x00
000078805cddf662  mov rax, 0x5771AD6EA530
000078805cddf66c  call rax
000078805cddf66e  movaps xmm10, [rsp]
000078805cddf673  add rsp, 0x30
000078805cddf677  vmovaps xmm0, [rsp]
000078805cddf67c  vmovaps xmm1, [rsp+0x10]
000078805cddf682  vmovaps xmm2, [rsp+0x20]
000078805cddf688  vmovaps xmm3, [rsp+0x30]
000078805cddf68e  vmovaps xmm4, [rsp+0x40]
000078805cddf694  vmovaps xmm5, [rsp+0x50]
000078805cddf69a  vmovaps xmm6, [rsp+0x60]
000078805cddf6a0  vmovaps xmm7, [rsp+0x70]
000078805cddf6a6  vmovaps xmm8, [rsp+0x80]
000078805cddf6af  vmovaps xmm9, [rsp+0x90]
000078805cddf6b8  vmovaps xmm11, [rsp+0xA0]
000078805cddf6c1  vmovaps xmm12, [rsp+0xB0]
000078805cddf6ca  vmovaps xmm13, [rsp+0xC0]
000078805cddf6d3  vmovaps xmm14, [rsp+0xD0]
000078805cddf6dc  vmovaps xmm15, [rsp+0xE0]
000078805cddf6e5  add rsp, 0xF0
000078805cddf6ec  pop r11
000078805cddf6ee  pop r10
000078805cddf6f0  pop r9
000078805cddf6f2  pop r8
000078805cddf6f4  pop rsi
000078805cddf6f5  pop rdi
000078805cddf6f6  pop rdx
000078805cddf6f7  pop rcx
000078805cddf6f8  pop rax
000078805cddf6f9  add rsp, 0x08
000078805cddf6fd  jmp 0x000078805CDDC3F8
000078805cddf702  sub rsp, 0x08
000078805cddf706  push rax
000078805cddf707  push rcx
000078805cddf708  push rdx
000078805cddf709  push rdi
000078805cddf70a  push rsi
000078805cddf70b  push r8
000078805cddf70d  push r9
000078805cddf70f  push r10
000078805cddf711  push r11
000078805cddf713  sub rsp, 0xF0
000078805cddf71a  vmovaps [rsp], xmm0
000078805cddf71f  vmovaps [rsp+0x10], xmm1
000078805cddf725  vmovaps [rsp+0x20], xmm2
000078805cddf72b  vmovaps [rsp+0x30], xmm3
000078805cddf731  vmovaps [rsp+0x40], xmm4
000078805cddf737  vmovaps [rsp+0x50], xmm5
000078805cddf73d  vmovaps [rsp+0x60], xmm6
000078805cddf743  vmovaps [rsp+0x70], xmm7
000078805cddf749  vmovaps [rsp+0x80], xmm8
000078805cddf752  vmovaps [rsp+0x90], xmm9
000078805cddf75b  vmovaps [rsp+0xA0], xmm10
000078805cddf764  vmovaps [rsp+0xB0], xmm11
000078805cddf76d  vmovaps [rsp+0xC0], xmm12
000078805cddf776  vmovaps [rsp+0xD0], xmm13
000078805cddf77f  vmovaps [rsp+0xE0], xmm15
000078805cddf788  sub rsp, 0x30
000078805cddf78c  movaps [rsp], xmm14
000078805cddf791  movaps [rsp+0x10], xmm8
000078805cddf797  movaps [rsp+0x20], xmm4
000078805cddf79c  lea rdi, [rsp]
000078805cddf7a0  mov esi, 0x00
000078805cddf7a5  mov rax, 0x5771AD6EA530
000078805cddf7af  call rax
000078805cddf7b1  movaps xmm14, [rsp]
000078805cddf7b6  add rsp, 0x30
000078805cddf7ba  vmovaps xmm0, [rsp]
000078805cddf7bf  vmovaps xmm1, [rsp+0x10]
000078805cddf7c5  vmovaps xmm2, [rsp+0x20]
000078805cddf7cb  vmovaps xmm3, [rsp+0x30]
000078805cddf7d1  vmovaps xmm4, [rsp+0x40]
000078805cddf7d7  vmovaps xmm5, [rsp+0x50]
000078805cddf7dd  vmovaps xmm6, [rsp+0x60]
000078805cddf7e3  vmovaps xmm7, [rsp+0x70]
000078805cddf7e9  vmovaps xmm8, [rsp+0x80]
000078805cddf7f2  vmovaps xmm9, [rsp+0x90]
000078805cddf7fb  vmovaps xmm10, [rsp+0xA0]
000078805cddf804  vmovaps xmm11, [rsp+0xB0]
000078805cddf80d  vmovaps xmm12, [rsp+0xC0]
000078805cddf816  vmovaps xmm13, [rsp+0xD0]
000078805cddf81f  vmovaps xmm15, [rsp+0xE0]
000078805cddf828  add rsp, 0xF0
000078805cddf82f  pop r11
000078805cddf831  pop r10
000078805cddf833  pop r9
000078805cddf835  pop r8
000078805cddf837  pop rsi
000078805cddf838  pop rdi
000078805cddf839  pop rdx
000078805cddf83a  pop rcx
000078805cddf83b  pop rax
000078805cddf83c  add rsp, 0x08
000078805cddf840  jmp 0x000078805CDDC418
000078805cddf845  sub rsp, 0x08
000078805cddf849  push rax
000078805cddf84a  push rcx
000078805cddf84b  push rdx
000078805cddf84c  push rdi
000078805cddf84d  push rsi
000078805cddf84e  push r8
000078805cddf850  push r9
000078805cddf852  push r10
000078805cddf854  push r11
000078805cddf856  sub rsp, 0xF0
000078805cddf85d  vmovaps [rsp], xmm0
000078805cddf862  vmovaps [rsp+0x10], xmm1
000078805cddf868  vmovaps [rsp+0x20], xmm2
000078805cddf86e  vmovaps [rsp+0x30], xmm3
000078805cddf874  vmovaps [rsp+0x40], xmm5
000078805cddf87a  vmovaps [rsp+0x50], xmm6
000078805cddf880  vmovaps [rsp+0x60], xmm7
000078805cddf886  vmovaps [rsp+0x70], xmm8
000078805cddf88c  vmovaps [rsp+0x80], xmm9
000078805cddf895  vmovaps [rsp+0x90], xmm10
000078805cddf89e  vmovaps [rsp+0xA0], xmm11
000078805cddf8a7  vmovaps [rsp+0xB0], xmm12
000078805cddf8b0  vmovaps [rsp+0xC0], xmm13
000078805cddf8b9  vmovaps [rsp+0xD0], xmm14
000078805cddf8c2  vmovaps [rsp+0xE0], xmm15
000078805cddf8cb  sub rsp, 0x30
000078805cddf8cf  movaps [rsp], xmm4
000078805cddf8d3  movaps [rsp+0x10], xmm13
000078805cddf8d9  movaps [rsp+0x20], xmm8
000078805cddf8df  lea rdi, [rsp]
000078805cddf8e3  mov esi, 0x00
000078805cddf8e8  mov rax, 0x5771AD6EA530
000078805cddf8f2  call rax
000078805cddf8f4  movaps xmm4, [rsp]
000078805cddf8f8  add rsp, 0x30
000078805cddf8fc  vmovaps xmm0, [rsp]
000078805cddf901  vmovaps xmm1, [rsp+0x10]
000078805cddf907  vmovaps xmm2, [rsp+0x20]
000078805cddf90d  vmovaps xmm3, [rsp+0x30]
000078805cddf913  vmovaps xmm5, [rsp+0x40]
000078805cddf919  vmovaps xmm6, [rsp+0x50]
000078805cddf91f  vmovaps xmm7, [rsp+0x60]
000078805cddf925  vmovaps xmm8, [rsp+0x70]
000078805cddf92b  vmovaps xmm9, [rsp+0x80]
000078805cddf934  vmovaps xmm10, [rsp+0x90]
000078805cddf93d  vmovaps xmm11, [rsp+0xA0]
000078805cddf946  vmovaps xmm12, [rsp+0xB0]
000078805cddf94f  vmovaps xmm13, [rsp+0xC0]
000078805cddf958  vmovaps xmm14, [rsp+0xD0]
000078805cddf961  vmovaps xmm15, [rsp+0xE0]
000078805cddf96a  add rsp, 0xF0
000078805cddf971  pop r11
000078805cddf973  pop r10
000078805cddf975  pop r9
000078805cddf977  pop r8
000078805cddf979  pop rsi
000078805cddf97a  pop rdi
000078805cddf97b  pop rdx
000078805cddf97c  pop rcx
000078805cddf97d  pop rax
000078805cddf97e  add rsp, 0x08
000078805cddf982  jmp 0x000078805CDDC43D
000078805cddf987  sub rsp, 0x08
000078805cddf98b  push rax
000078805cddf98c  push rcx
000078805cddf98d  push rdx
000078805cddf98e  push rdi
000078805cddf98f  push rsi
000078805cddf990  push r8
000078805cddf992  push r9
000078805cddf994  push r10
000078805cddf996  push r11
000078805cddf998  sub rsp, 0xF0
000078805cddf99f  vmovaps [rsp], xmm0
000078805cddf9a4  vmovaps [rsp+0x10], xmm1
000078805cddf9aa  vmovaps [rsp+0x20], xmm2
000078805cddf9b0  vmovaps [rsp+0x30], xmm3
000078805cddf9b6  vmovaps [rsp+0x40], xmm4
000078805cddf9bc  vmovaps [rsp+0x50], xmm5
000078805cddf9c2  vmovaps [rsp+0x60], xmm6
000078805cddf9c8  vmovaps [rsp+0x70], xmm7
000078805cddf9ce  vmovaps [rsp+0x80], xmm8
000078805cddf9d7  vmovaps [rsp+0x90], xmm9
000078805cddf9e0  vmovaps [rsp+0xA0], xmm10
000078805cddf9e9  vmovaps [rsp+0xB0], xmm11
000078805cddf9f2  vmovaps [rsp+0xC0], xmm12
000078805cddf9fb  vmovaps [rsp+0xD0], xmm14
000078805cddfa04  vmovaps [rsp+0xE0], xmm15
000078805cddfa0d  sub rsp, 0x30
000078805cddfa11  movaps [rsp], xmm13
000078805cddfa16  movaps [rsp+0x10], xmm15
000078805cddfa1c  movaps [rsp+0x20], xmm9
000078805cddfa22  lea rdi, [rsp]
000078805cddfa26  mov esi, 0x00
000078805cddfa2b  mov rax, 0x5771AD6EA530
000078805cddfa35  call rax
000078805cddfa37  movaps xmm13, [rsp]
000078805cddfa3c  add rsp, 0x30
000078805cddfa40  vmovaps xmm0, [rsp]
000078805cddfa45  vmovaps xmm1, [rsp+0x10]
000078805cddfa4b  vmovaps xmm2, [rsp+0x20]
000078805cddfa51  vmovaps xmm3, [rsp+0x30]
000078805cddfa57  vmovaps xmm4, [rsp+0x40]
000078805cddfa5d  vmovaps xmm5, [rsp+0x50]
000078805cddfa63  vmovaps xmm6, [rsp+0x60]
000078805cddfa69  vmovaps xmm7, [rsp+0x70]
000078805cddfa6f  vmovaps xmm8, [rsp+0x80]
000078805cddfa78  vmovaps xmm9, [rsp+0x90]
000078805cddfa81  vmovaps xmm10, [rsp+0xA0]
000078805cddfa8a  vmovaps xmm11, [rsp+0xB0]
000078805cddfa93  vmovaps xmm12, [rsp+0xC0]
000078805cddfa9c  vmovaps xmm14, [rsp+0xD0]
000078805cddfaa5  vmovaps xmm15, [rsp+0xE0]
000078805cddfaae  add rsp, 0xF0
000078805cddfab5  pop r11
000078805cddfab7  pop r10
000078805cddfab9  pop r9
000078805cddfabb  pop r8
000078805cddfabd  pop rsi
000078805cddfabe  pop rdi
000078805cddfabf  pop rdx
000078805cddfac0  pop rcx
000078805cddfac1  pop rax
000078805cddfac2  add rsp, 0x08
000078805cddfac6  jmp 0x000078805CDDC458
000078805cddfacb  sub rsp, 0x08
000078805cddfacf  push rax
000078805cddfad0  push rcx
000078805cddfad1  push rdx
000078805cddfad2  push rdi
000078805cddfad3  push rsi
000078805cddfad4  push r8
000078805cddfad6  push r9
000078805cddfad8  push r10
000078805cddfada  push r11
000078805cddfadc  sub rsp, 0xF0
000078805cddfae3  vmovaps [rsp], xmm0
000078805cddfae8  vmovaps [rsp+0x10], xmm1
000078805cddfaee  vmovaps [rsp+0x20], xmm2
000078805cddfaf4  vmovaps [rsp+0x30], xmm3
000078805cddfafa  vmovaps [rsp+0x40], xmm4
000078805cddfb00  vmovaps [rsp+0x50], xmm5
000078805cddfb06  vmovaps [rsp+0x60], xmm6
000078805cddfb0c  vmovaps [rsp+0x70], xmm7
000078805cddfb12  vmovaps [rsp+0x80], xmm8
000078805cddfb1b  vmovaps [rsp+0x90], xmm9
000078805cddfb24  vmovaps [rsp+0xA0], xmm10
000078805cddfb2d  vmovaps [rsp+0xB0], xmm11
000078805cddfb36  vmovaps [rsp+0xC0], xmm12
000078805cddfb3f  vmovaps [rsp+0xD0], xmm13
000078805cddfb48  vmovaps [rsp+0xE0], xmm14
000078805cddfb51  sub rsp, 0x30
000078805cddfb55  movaps [rsp], xmm15
000078805cddfb5a  movaps [rsp+0x10], xmm1
000078805cddfb5f  movaps [rsp+0x20], xmm5
000078805cddfb64  lea rdi, [rsp]
000078805cddfb68  mov esi, 0x00
000078805cddfb6d  mov rax, 0x5771AD6EA530
000078805cddfb77  call rax
000078805cddfb79  movaps xmm15, [rsp]
000078805cddfb7e  add rsp, 0x30
000078805cddfb82  vmovaps xmm0, [rsp]
000078805cddfb87  vmovaps xmm1, [rsp+0x10]
000078805cddfb8d  vmovaps xmm2, [rsp+0x20]
000078805cddfb93  vmovaps xmm3, [rsp+0x30]
000078805cddfb99  vmovaps xmm4, [rsp+0x40]
000078805cddfb9f  vmovaps xmm5, [rsp+0x50]
000078805cddfba5  vmovaps xmm6, [rsp+0x60]
000078805cddfbab  vmovaps xmm7, [rsp+0x70]
000078805cddfbb1  vmovaps xmm8, [rsp+0x80]
000078805cddfbba  vmovaps xmm9, [rsp+0x90]
000078805cddfbc3  vmovaps xmm10, [rsp+0xA0]
000078805cddfbcc  vmovaps xmm11, [rsp+0xB0]
000078805cddfbd5  vmovaps xmm12, [rsp+0xC0]
000078805cddfbde  vmovaps xmm13, [rsp+0xD0]
000078805cddfbe7  vmovaps xmm14, [rsp+0xE0]
000078805cddfbf0  add rsp, 0xF0
000078805cddfbf7  pop r11
000078805cddfbf9  pop r10
000078805cddfbfb  pop r9
000078805cddfbfd  pop r8
000078805cddfbff  pop rsi
000078805cddfc00  pop rdi
000078805cddfc01  pop rdx
000078805cddfc02  pop rcx
000078805cddfc03  pop rax
000078805cddfc04  add rsp, 0x08
000078805cddfc08  jmp 0x000078805CDDC473
000078805cddfc0d  call 0x000078805CCB52F0
000078805cddfc12  jmp 0x000078805CDDC4CE
000078805cddfc17  sub rsp, 0x08
000078805cddfc1b  push rax
000078805cddfc1c  push rcx
000078805cddfc1d  push rdx
000078805cddfc1e  push rdi
000078805cddfc1f  push rsi
000078805cddfc20  push r8
000078805cddfc22  push r9
000078805cddfc24  push r10
000078805cddfc26  push r11
000078805cddfc28  sub rsp, 0xF0
000078805cddfc2f  vmovaps [rsp], xmm0
000078805cddfc34  vmovaps [rsp+0x10], xmm1
000078805cddfc3a  vmovaps [rsp+0x20], xmm2
000078805cddfc40  vmovaps [rsp+0x30], xmm3
000078805cddfc46  vmovaps [rsp+0x40], xmm4
000078805cddfc4c  vmovaps [rsp+0x50], xmm5
000078805cddfc52  vmovaps [rsp+0x60], xmm6
000078805cddfc58  vmovaps [rsp+0x70], xmm7
000078805cddfc5e  vmovaps [rsp+0x80], xmm8
000078805cddfc67  vmovaps [rsp+0x90], xmm10
000078805cddfc70  vmovaps [rsp+0xA0], xmm11
000078805cddfc79  vmovaps [rsp+0xB0], xmm12
000078805cddfc82  vmovaps [rsp+0xC0], xmm13
000078805cddfc8b  vmovaps [rsp+0xD0], xmm14
000078805cddfc94  vmovaps [rsp+0xE0], xmm15
000078805cddfc9d  sub rsp, 0x30
000078805cddfca1  movaps [rsp], xmm9
000078805cddfca6  movaps [rsp+0x10], xmm8
000078805cddfcac  movaps [rsp+0x20], xmm11
000078805cddfcb2  lea rdi, [rsp]
000078805cddfcb6  mov esi, 0x00
000078805cddfcbb  mov rax, 0x5771AD6EA530
000078805cddfcc5  call rax
000078805cddfcc7  movaps xmm9, [rsp]
000078805cddfccc  add rsp, 0x30
000078805cddfcd0  vmovaps xmm0, [rsp]
000078805cddfcd5  vmovaps xmm1, [rsp+0x10]
000078805cddfcdb  vmovaps xmm2, [rsp+0x20]
000078805cddfce1  vmovaps xmm3, [rsp+0x30]
000078805cddfce7  vmovaps xmm4, [rsp+0x40]
000078805cddfced  vmovaps xmm5, [rsp+0x50]
000078805cddfcf3  vmovaps xmm6, [rsp+0x60]
000078805cddfcf9  vmovaps xmm7, [rsp+0x70]
000078805cddfcff  vmovaps xmm8, [rsp+0x80]
000078805cddfd08  vmovaps xmm10, [rsp+0x90]
000078805cddfd11  vmovaps xmm11, [rsp+0xA0]
000078805cddfd1a  vmovaps xmm12, [rsp+0xB0]
000078805cddfd23  vmovaps xmm13, [rsp+0xC0]
000078805cddfd2c  vmovaps xmm14, [rsp+0xD0]
000078805cddfd35  vmovaps xmm15, [rsp+0xE0]
000078805cddfd3e  add rsp, 0xF0
000078805cddfd45  pop r11
000078805cddfd47  pop r10
000078805cddfd49  pop r9
000078805cddfd4b  pop r8
000078805cddfd4d  pop rsi
000078805cddfd4e  pop rdi
000078805cddfd4f  pop rdx
000078805cddfd50  pop rcx
000078805cddfd51  pop rax
000078805cddfd52  add rsp, 0x08
000078805cddfd56  jmp 0x000078805CDDC505
000078805cddfd5b  sub rsp, 0x08
000078805cddfd5f  push rax
000078805cddfd60  push rcx
000078805cddfd61  push rdx
000078805cddfd62  push rdi
000078805cddfd63  push rsi
000078805cddfd64  push r8
000078805cddfd66  push r9
000078805cddfd68  push r10
000078805cddfd6a  push r11
000078805cddfd6c  sub rsp, 0xF0
000078805cddfd73  vmovaps [rsp], xmm0
000078805cddfd78  vmovaps [rsp+0x10], xmm1
000078805cddfd7e  vmovaps [rsp+0x20], xmm2
000078805cddfd84  vmovaps [rsp+0x30], xmm3
000078805cddfd8a  vmovaps [rsp+0x40], xmm4
000078805cddfd90  vmovaps [rsp+0x50], xmm5
000078805cddfd96  vmovaps [rsp+0x60], xmm6
000078805cddfd9c  vmovaps [rsp+0x70], xmm7
000078805cddfda2  vmovaps [rsp+0x80], xmm8
000078805cddfdab  vmovaps [rsp+0x90], xmm9
000078805cddfdb4  vmovaps [rsp+0xA0], xmm10
000078805cddfdbd  vmovaps [rsp+0xB0], xmm12
000078805cddfdc6  vmovaps [rsp+0xC0], xmm13
000078805cddfdcf  vmovaps [rsp+0xD0], xmm14
000078805cddfdd8  vmovaps [rsp+0xE0], xmm15
000078805cddfde1  sub rsp, 0x30
000078805cddfde5  movaps [rsp], xmm11
000078805cddfdea  movaps [rsp+0x10], xmm10
000078805cddfdf0  movaps [rsp+0x20], xmm6
000078805cddfdf5  lea rdi, [rsp]
000078805cddfdf9  mov esi, 0x00
000078805cddfdfe  mov rax, 0x5771AD6EA530
000078805cddfe08  call rax
000078805cddfe0a  movaps xmm11, [rsp]
000078805cddfe0f  add rsp, 0x30
000078805cddfe13  vmovaps xmm0, [rsp]
000078805cddfe18  vmovaps xmm1, [rsp+0x10]
000078805cddfe1e  vmovaps xmm2, [rsp+0x20]
000078805cddfe24  vmovaps xmm3, [rsp+0x30]
000078805cddfe2a  vmovaps xmm4, [rsp+0x40]
000078805cddfe30  vmovaps xmm5, [rsp+0x50]
000078805cddfe36  vmovaps xmm6, [rsp+0x60]
000078805cddfe3c  vmovaps xmm7, [rsp+0x70]
000078805cddfe42  vmovaps xmm8, [rsp+0x80]
000078805cddfe4b  vmovaps xmm9, [rsp+0x90]
000078805cddfe54  vmovaps xmm10, [rsp+0xA0]
000078805cddfe5d  vmovaps xmm12, [rsp+0xB0]
000078805cddfe66  vmovaps xmm13, [rsp+0xC0]
000078805cddfe6f  vmovaps xmm14, [rsp+0xD0]
000078805cddfe78  vmovaps xmm15, [rsp+0xE0]
000078805cddfe81  add rsp, 0xF0
000078805cddfe88  pop r11
000078805cddfe8a  pop r10
000078805cddfe8c  pop r9
000078805cddfe8e  pop r8
000078805cddfe90  pop rsi
000078805cddfe91  pop rdi
000078805cddfe92  pop rdx
000078805cddfe93  pop rcx
000078805cddfe94  pop rax
000078805cddfe95  add rsp, 0x08
000078805cddfe99  jmp 0x000078805CDDC520
000078805cddfe9e  sub rsp, 0x08
000078805cddfea2  push rax
000078805cddfea3  push rcx
000078805cddfea4  push rdx
000078805cddfea5  push rdi
000078805cddfea6  push rsi
000078805cddfea7  push r8
000078805cddfea9  push r9
000078805cddfeab  push r10
000078805cddfead  push r11
000078805cddfeaf  sub rsp, 0xF0
000078805cddfeb6  vmovaps [rsp], xmm0
000078805cddfebb  vmovaps [rsp+0x10], xmm1
000078805cddfec1  vmovaps [rsp+0x20], xmm2
000078805cddfec7  vmovaps [rsp+0x30], xmm3
000078805cddfecd  vmovaps [rsp+0x40], xmm4
000078805cddfed3  vmovaps [rsp+0x50], xmm5
000078805cddfed9  vmovaps [rsp+0x60], xmm6
000078805cddfedf  vmovaps [rsp+0x70], xmm7
000078805cddfee5  vmovaps [rsp+0x80], xmm8
000078805cddfeee  vmovaps [rsp+0x90], xmm9
000078805cddfef7  vmovaps [rsp+0xA0], xmm11
000078805cddff00  vmovaps [rsp+0xB0], xmm12
000078805cddff09  vmovaps [rsp+0xC0], xmm13
000078805cddff12  vmovaps [rsp+0xD0], xmm14
000078805cddff1b  vmovaps [rsp+0xE0], xmm15
000078805cddff24  sub rsp, 0x30
000078805cddff28  movaps [rsp], xmm10
000078805cddff2d  movaps [rsp+0x10], xmm14
000078805cddff33  movaps [rsp+0x20], xmm4
000078805cddff38  lea rdi, [rsp]
000078805cddff3c  mov esi, 0x00
000078805cddff41  mov rax, 0x5771AD6EA530
000078805cddff4b  call rax
000078805cddff4d  movaps xmm10, [rsp]
000078805cddff52  add rsp, 0x30
000078805cddff56  vmovaps xmm0, [rsp]
000078805cddff5b  vmovaps xmm1, [rsp+0x10]
000078805cddff61  vmovaps xmm2, [rsp+0x20]
000078805cddff67  vmovaps xmm3, [rsp+0x30]
000078805cddff6d  vmovaps xmm4, [rsp+0x40]
000078805cddff73  vmovaps xmm5, [rsp+0x50]
000078805cddff79  vmovaps xmm6, [rsp+0x60]
000078805cddff7f  vmovaps xmm7, [rsp+0x70]
000078805cddff85  vmovaps xmm8, [rsp+0x80]
000078805cddff8e  vmovaps xmm9, [rsp+0x90]
000078805cddff97  vmovaps xmm11, [rsp+0xA0]
000078805cddffa0  vmovaps xmm12, [rsp+0xB0]
000078805cddffa9  vmovaps xmm13, [rsp+0xC0]
000078805cddffb2  vmovaps xmm14, [rsp+0xD0]
000078805cddffbb  vmovaps xmm15, [rsp+0xE0]
000078805cddffc4  add rsp, 0xF0
000078805cddffcb  pop r11
000078805cddffcd  pop r10
000078805cddffcf  pop r9
000078805cddffd1  pop r8
000078805cddffd3  pop rsi
000078805cddffd4  pop rdi
000078805cddffd5  pop rdx
000078805cddffd6  pop rcx
000078805cddffd7  pop rax
000078805cddffd8  add rsp, 0x08
000078805cddffdc  jmp 0x000078805CDDC53B
000078805cddffe1  sub rsp, 0x08
000078805cddffe5  push rax
000078805cddffe6  push rcx
000078805cddffe7  push rdx
000078805cddffe8  push rdi
000078805cddffe9  push rsi
000078805cddffea  push r8
000078805cddffec  push r9
000078805cddffee  push r10
000078805cddfff0  push r11
000078805cddfff2  sub rsp, 0xF0
000078805cddfff9  vmovaps [rsp], xmm0
000078805cddfffe  vmovaps [rsp+0x10], xmm1
000078805cde0004  vmovaps [rsp+0x20], xmm2
000078805cde000a  vmovaps [rsp+0x30], xmm3
000078805cde0010  vmovaps [rsp+0x40], xmm4
000078805cde0016  vmovaps [rsp+0x50], xmm5
000078805cde001c  vmovaps [rsp+0x60], xmm6
000078805cde0022  vmovaps [rsp+0x70], xmm7
000078805cde0028  vmovaps [rsp+0x80], xmm9
000078805cde0031  vmovaps [rsp+0x90], xmm10
000078805cde003a  vmovaps [rsp+0xA0], xmm11
000078805cde0043  vmovaps [rsp+0xB0], xmm12
000078805cde004c  vmovaps [rsp+0xC0], xmm13
000078805cde0055  vmovaps [rsp+0xD0], xmm14
000078805cde005e  vmovaps [rsp+0xE0], xmm15
000078805cde0067  sub rsp, 0x30
000078805cde006b  movaps [rsp], xmm8
000078805cde0070  movaps [rsp+0x10], xmm1
000078805cde0075  movaps [rsp+0x20], xmm14
000078805cde007b  lea rdi, [rsp]
000078805cde007f  mov esi, 0x00
000078805cde0084  mov rax, 0x5771AD6EA530
000078805cde008e  call rax
000078805cde0090  movaps xmm8, [rsp]
000078805cde0095  add rsp, 0x30
000078805cde0099  vmovaps xmm0, [rsp]
000078805cde009e  vmovaps xmm1, [rsp+0x10]
000078805cde00a4  vmovaps xmm2, [rsp+0x20]
000078805cde00aa  vmovaps xmm3, [rsp+0x30]
000078805cde00b0  vmovaps xmm4, [rsp+0x40]
000078805cde00b6  vmovaps xmm5, [rsp+0x50]
000078805cde00bc  vmovaps xmm6, [rsp+0x60]
000078805cde00c2  vmovaps xmm7, [rsp+0x70]
000078805cde00c8  vmovaps xmm9, [rsp+0x80]
000078805cde00d1  vmovaps xmm10, [rsp+0x90]
000078805cde00da  vmovaps xmm11, [rsp+0xA0]
000078805cde00e3  vmovaps xmm12, [rsp+0xB0]
000078805cde00ec  vmovaps xmm13, [rsp+0xC0]
000078805cde00f5  vmovaps xmm14, [rsp+0xD0]
000078805cde00fe  vmovaps xmm15, [rsp+0xE0]
000078805cde0107  add rsp, 0xF0
000078805cde010e  pop r11
000078805cde0110  pop r10
000078805cde0112  pop r9
000078805cde0114  pop r8
000078805cde0116  pop rsi
000078805cde0117  pop rdi
000078805cde0118  pop rdx
000078805cde0119  pop rcx
000078805cde011a  pop rax
000078805cde011b  add rsp, 0x08
000078805cde011f  jmp 0x000078805CDDC561
000078805cde0124  sub rsp, 0x08
000078805cde0128  push rax
000078805cde0129  push rcx
000078805cde012a  push rdx
000078805cde012b  push rdi
000078805cde012c  push rsi
000078805cde012d  push r8
000078805cde012f  push r9
000078805cde0131  push r10
000078805cde0133  push r11
000078805cde0135  sub rsp, 0xF0
000078805cde013c  vmovaps [rsp], xmm0
000078805cde0141  vmovaps [rsp+0x10], xmm1
000078805cde0147  vmovaps [rsp+0x20], xmm2
000078805cde014d  vmovaps [rsp+0x30], xmm3
000078805cde0153  vmovaps [rsp+0x40], xmm4
000078805cde0159  vmovaps [rsp+0x50], xmm5
000078805cde015f  vmovaps [rsp+0x60], xmm7
000078805cde0165  vmovaps [rsp+0x70], xmm8
000078805cde016b  vmovaps [rsp+0x80], xmm9
000078805cde0174  vmovaps [rsp+0x90], xmm10
000078805cde017d  vmovaps [rsp+0xA0], xmm11
000078805cde0186  vmovaps [rsp+0xB0], xmm12
000078805cde018f  vmovaps [rsp+0xC0], xmm13
000078805cde0198  vmovaps [rsp+0xD0], xmm14
000078805cde01a1  vmovaps [rsp+0xE0], xmm15
000078805cde01aa  sub rsp, 0x30
000078805cde01ae  movaps [rsp], xmm6
000078805cde01b2  movaps [rsp+0x10], xmm1
000078805cde01b7  movaps [rsp+0x20], xmm14
000078805cde01bd  lea rdi, [rsp]
000078805cde01c1  mov esi, 0x00
000078805cde01c6  mov rax, 0x5771AD6EA530
000078805cde01d0  call rax
000078805cde01d2  movaps xmm6, [rsp]
000078805cde01d6  add rsp, 0x30
000078805cde01da  vmovaps xmm0, [rsp]
000078805cde01df  vmovaps xmm1, [rsp+0x10]
000078805cde01e5  vmovaps xmm2, [rsp+0x20]
000078805cde01eb  vmovaps xmm3, [rsp+0x30]
000078805cde01f1  vmovaps xmm4, [rsp+0x40]
000078805cde01f7  vmovaps xmm5, [rsp+0x50]
000078805cde01fd  vmovaps xmm7, [rsp+0x60]
000078805cde0203  vmovaps xmm8, [rsp+0x70]
000078805cde0209  vmovaps xmm9, [rsp+0x80]
000078805cde0212  vmovaps xmm10, [rsp+0x90]
000078805cde021b  vmovaps xmm11, [rsp+0xA0]
000078805cde0224  vmovaps xmm12, [rsp+0xB0]
000078805cde022d  vmovaps xmm13, [rsp+0xC0]
000078805cde0236  vmovaps xmm14, [rsp+0xD0]
000078805cde023f  vmovaps xmm15, [rsp+0xE0]
000078805cde0248  add rsp, 0xF0
000078805cde024f  pop r11
000078805cde0251  pop r10
000078805cde0253  pop r9
000078805cde0255  pop r8
000078805cde0257  pop rsi
000078805cde0258  pop rdi
000078805cde0259  pop rdx
000078805cde025a  pop rcx
000078805cde025b  pop rax
000078805cde025c  add rsp, 0x08
000078805cde0260  jmp 0x000078805CDDC58D
000078805cde0265  sub rsp, 0x08
000078805cde0269  push rax
000078805cde026a  push rcx
000078805cde026b  push rdx
000078805cde026c  push rdi
000078805cde026d  push rsi
000078805cde026e  push r8
000078805cde0270  push r9
000078805cde0272  push r10
000078805cde0274  push r11
000078805cde0276  sub rsp, 0xF0
000078805cde027d  vmovaps [rsp], xmm0
000078805cde0282  vmovaps [rsp+0x10], xmm1
000078805cde0288  vmovaps [rsp+0x20], xmm2
000078805cde028e  vmovaps [rsp+0x30], xmm3
000078805cde0294  vmovaps [rsp+0x40], xmm4
000078805cde029a  vmovaps [rsp+0x50], xmm5
000078805cde02a0  vmovaps [rsp+0x60], xmm6
000078805cde02a6  vmovaps [rsp+0x70], xmm7
000078805cde02ac  vmovaps [rsp+0x80], xmm8
000078805cde02b5  vmovaps [rsp+0x90], xmm9
000078805cde02be  vmovaps [rsp+0xA0], xmm10
000078805cde02c7  vmovaps [rsp+0xB0], xmm11
000078805cde02d0  vmovaps [rsp+0xC0], xmm12
000078805cde02d9  vmovaps [rsp+0xD0], xmm13
000078805cde02e2  vmovaps [rsp+0xE0], xmm15
000078805cde02eb  sub rsp, 0x30
000078805cde02ef  movaps [rsp], xmm14
000078805cde02f4  movaps [rsp+0x10], xmm12
000078805cde02fa  movaps [rsp+0x20], xmm1
000078805cde02ff  lea rdi, [rsp]
000078805cde0303  mov esi, 0x00
000078805cde0308  mov rax, 0x5771AD6EA530
000078805cde0312  call rax
000078805cde0314  movaps xmm14, [rsp]
000078805cde0319  add rsp, 0x30
000078805cde031d  vmovaps xmm0, [rsp]
000078805cde0322  vmovaps xmm1, [rsp+0x10]
000078805cde0328  vmovaps xmm2, [rsp+0x20]
000078805cde032e  vmovaps xmm3, [rsp+0x30]
000078805cde0334  vmovaps xmm4, [rsp+0x40]
000078805cde033a  vmovaps xmm5, [rsp+0x50]
000078805cde0340  vmovaps xmm6, [rsp+0x60]
000078805cde0346  vmovaps xmm7, [rsp+0x70]
000078805cde034c  vmovaps xmm8, [rsp+0x80]
000078805cde0355  vmovaps xmm9, [rsp+0x90]
000078805cde035e  vmovaps xmm10, [rsp+0xA0]
000078805cde0367  vmovaps xmm11, [rsp+0xB0]
000078805cde0370  vmovaps xmm12, [rsp+0xC0]
000078805cde0379  vmovaps xmm13, [rsp+0xD0]
000078805cde0382  vmovaps xmm15, [rsp+0xE0]
000078805cde038b  add rsp, 0xF0
000078805cde0392  pop r11
000078805cde0394  pop r10
000078805cde0396  pop r9
000078805cde0398  pop r8
000078805cde039a  pop rsi
000078805cde039b  pop rdi
000078805cde039c  pop rdx
000078805cde039d  pop rcx
000078805cde039e  pop rax
000078805cde039f  add rsp, 0x08
000078805cde03a3  jmp 0x000078805CDDC5B3
000078805cde03a8  sub rsp, 0x08
000078805cde03ac  push rax
000078805cde03ad  push rcx
000078805cde03ae  push rdx
000078805cde03af  push rdi
000078805cde03b0  push rsi
000078805cde03b1  push r8
000078805cde03b3  push r9
000078805cde03b5  push r10
000078805cde03b7  push r11
000078805cde03b9  sub rsp, 0xF0
000078805cde03c0  vmovaps [rsp], xmm0
000078805cde03c5  vmovaps [rsp+0x10], xmm2
000078805cde03cb  vmovaps [rsp+0x20], xmm3
000078805cde03d1  vmovaps [rsp+0x30], xmm4
000078805cde03d7  vmovaps [rsp+0x40], xmm5
000078805cde03dd  vmovaps [rsp+0x50], xmm6
000078805cde03e3  vmovaps [rsp+0x60], xmm7
000078805cde03e9  vmovaps [rsp+0x70], xmm8
000078805cde03ef  vmovaps [rsp+0x80], xmm9
000078805cde03f8  vmovaps [rsp+0x90], xmm10
000078805cde0401  vmovaps [rsp+0xA0], xmm11
000078805cde040a  vmovaps [rsp+0xB0], xmm12
000078805cde0413  vmovaps [rsp+0xC0], xmm13
000078805cde041c  vmovaps [rsp+0xD0], xmm14
000078805cde0425  vmovaps [rsp+0xE0], xmm15
000078805cde042e  sub rsp, 0x30
000078805cde0432  movaps [rsp], xmm1
000078805cde0436  movaps [rsp+0x10], xmm13
000078805cde043c  movaps [rsp+0x20], xmm9
000078805cde0442  lea rdi, [rsp]
000078805cde0446  mov esi, 0x00
000078805cde044b  mov rax, 0x5771AD6EA530
000078805cde0455  call rax
000078805cde0457  movaps xmm1, [rsp]
000078805cde045b  add rsp, 0x30
000078805cde045f  vmovaps xmm0, [rsp]
000078805cde0464  vmovaps xmm2, [rsp+0x10]
000078805cde046a  vmovaps xmm3, [rsp+0x20]
000078805cde0470  vmovaps xmm4, [rsp+0x30]
000078805cde0476  vmovaps xmm5, [rsp+0x40]
000078805cde047c  vmovaps xmm6, [rsp+0x50]
000078805cde0482  vmovaps xmm7, [rsp+0x60]
000078805cde0488  vmovaps xmm8, [rsp+0x70]
000078805cde048e  vmovaps xmm9, [rsp+0x80]
000078805cde0497  vmovaps xmm10, [rsp+0x90]
000078805cde04a0  vmovaps xmm11, [rsp+0xA0]
000078805cde04a9  vmovaps xmm12, [rsp+0xB0]
000078805cde04b2  vmovaps xmm13, [rsp+0xC0]
000078805cde04bb  vmovaps xmm14, [rsp+0xD0]
000078805cde04c4  vmovaps xmm15, [rsp+0xE0]
000078805cde04cd  add rsp, 0xF0
000078805cde04d4  pop r11
000078805cde04d6  pop r10
000078805cde04d8  pop r9
000078805cde04da  pop r8
000078805cde04dc  pop rsi
000078805cde04dd  pop rdi
000078805cde04de  pop rdx
000078805cde04df  pop rcx
000078805cde04e0  pop rax
000078805cde04e1  add rsp, 0x08
000078805cde04e5  jmp 0x000078805CDDC5CD
000078805cde04ea  sub rsp, 0x08
000078805cde04ee  push rax
000078805cde04ef  push rcx
000078805cde04f0  push rdx
000078805cde04f1  push rdi
000078805cde04f2  push rsi
000078805cde04f3  push r8
000078805cde04f5  push r9
000078805cde04f7  push r10
000078805cde04f9  push r11
000078805cde04fb  sub rsp, 0xF0
000078805cde0502  vmovaps [rsp], xmm0
000078805cde0507  vmovaps [rsp+0x10], xmm1
000078805cde050d  vmovaps [rsp+0x20], xmm2
000078805cde0513  vmovaps [rsp+0x30], xmm3
000078805cde0519  vmovaps [rsp+0x40], xmm4
000078805cde051f  vmovaps [rsp+0x50], xmm5
000078805cde0525  vmovaps [rsp+0x60], xmm6
000078805cde052b  vmovaps [rsp+0x70], xmm7
000078805cde0531  vmovaps [rsp+0x80], xmm8
000078805cde053a  vmovaps [rsp+0x90], xmm9
000078805cde0543  vmovaps [rsp+0xA0], xmm10
000078805cde054c  vmovaps [rsp+0xB0], xmm11
000078805cde0555  vmovaps [rsp+0xC0], xmm13
000078805cde055e  vmovaps [rsp+0xD0], xmm14
000078805cde0567  vmovaps [rsp+0xE0], xmm15
000078805cde0570  sub rsp, 0x30
000078805cde0574  movaps [rsp], xmm12
000078805cde0579  movaps [rsp+0x10], xmm7
000078805cde057e  movaps [rsp+0x20], xmm13
000078805cde0584  lea rdi, [rsp]
000078805cde0588  mov esi, 0x00
000078805cde058d  mov rax, 0x5771AD6EA530
000078805cde0597  call rax
000078805cde0599  movaps xmm12, [rsp]
000078805cde059e  add rsp, 0x30
000078805cde05a2  vmovaps xmm0, [rsp]
000078805cde05a7  vmovaps xmm1, [rsp+0x10]
000078805cde05ad  vmovaps xmm2, [rsp+0x20]
000078805cde05b3  vmovaps xmm3, [rsp+0x30]
000078805cde05b9  vmovaps xmm4, [rsp+0x40]
000078805cde05bf  vmovaps xmm5, [rsp+0x50]
000078805cde05c5  vmovaps xmm6, [rsp+0x60]
000078805cde05cb  vmovaps xmm7, [rsp+0x70]
000078805cde05d1  vmovaps xmm8, [rsp+0x80]
000078805cde05da  vmovaps xmm9, [rsp+0x90]
000078805cde05e3  vmovaps xmm10, [rsp+0xA0]
000078805cde05ec  vmovaps xmm11, [rsp+0xB0]
000078805cde05f5  vmovaps xmm13, [rsp+0xC0]
000078805cde05fe  vmovaps xmm14, [rsp+0xD0]
000078805cde0607  vmovaps xmm15, [rsp+0xE0]
000078805cde0610  add rsp, 0xF0
000078805cde0617  pop r11
000078805cde0619  pop r10
000078805cde061b  pop r9
000078805cde061d  pop r8
000078805cde061f  pop rsi
000078805cde0620  pop rdi
000078805cde0621  pop rdx
000078805cde0622  pop rcx
000078805cde0623  pop rax
000078805cde0624  add rsp, 0x08
000078805cde0628  jmp 0x000078805CDDC5F4
000078805cde062d  sub rsp, 0x08
000078805cde0631  push rax
000078805cde0632  push rcx
000078805cde0633  push rdx
000078805cde0634  push rdi
000078805cde0635  push rsi
000078805cde0636  push r8
000078805cde0638  push r9
000078805cde063a  push r10
000078805cde063c  push r11
000078805cde063e  sub rsp, 0xF0
000078805cde0645  vmovaps [rsp], xmm0
000078805cde064a  vmovaps [rsp+0x10], xmm1
000078805cde0650  vmovaps [rsp+0x20], xmm2
000078805cde0656  vmovaps [rsp+0x30], xmm3
000078805cde065c  vmovaps [rsp+0x40], xmm4
000078805cde0662  vmovaps [rsp+0x50], xmm5
000078805cde0668  vmovaps [rsp+0x60], xmm6
000078805cde066e  vmovaps [rsp+0x70], xmm7
000078805cde0674  vmovaps [rsp+0x80], xmm8
000078805cde067d  vmovaps [rsp+0x90], xmm9
000078805cde0686  vmovaps [rsp+0xA0], xmm10
000078805cde068f  vmovaps [rsp+0xB0], xmm11
000078805cde0698  vmovaps [rsp+0xC0], xmm12
000078805cde06a1  vmovaps [rsp+0xD0], xmm14
000078805cde06aa  vmovaps [rsp+0xE0], xmm15
000078805cde06b3  sub rsp, 0x30
000078805cde06b7  movaps [rsp], xmm13
000078805cde06bc  movaps [rsp+0x10], xmm15
000078805cde06c2  movaps [rsp+0x20], xmm8
000078805cde06c8  lea rdi, [rsp]
000078805cde06cc  mov esi, 0x00
000078805cde06d1  mov rax, 0x5771AD6EA530
000078805cde06db  call rax
000078805cde06dd  movaps xmm13, [rsp]
000078805cde06e2  add rsp, 0x30
000078805cde06e6  vmovaps xmm0, [rsp]
000078805cde06eb  vmovaps xmm1, [rsp+0x10]
000078805cde06f1  vmovaps xmm2, [rsp+0x20]
000078805cde06f7  vmovaps xmm3, [rsp+0x30]
000078805cde06fd  vmovaps xmm4, [rsp+0x40]
000078805cde0703  vmovaps xmm5, [rsp+0x50]
000078805cde0709  vmovaps xmm6, [rsp+0x60]
000078805cde070f  vmovaps xmm7, [rsp+0x70]
000078805cde0715  vmovaps xmm8, [rsp+0x80]
000078805cde071e  vmovaps xmm9, [rsp+0x90]
000078805cde0727  vmovaps xmm10, [rsp+0xA0]
000078805cde0730  vmovaps xmm11, [rsp+0xB0]
000078805cde0739  vmovaps xmm12, [rsp+0xC0]
000078805cde0742  vmovaps xmm14, [rsp+0xD0]
000078805cde074b  vmovaps xmm15, [rsp+0xE0]
000078805cde0754  add rsp, 0xF0
000078805cde075b  pop r11
000078805cde075d  pop r10
000078805cde075f  pop r9
000078805cde0761  pop r8
000078805cde0763  pop rsi
000078805cde0764  pop rdi
000078805cde0765  pop rdx
000078805cde0766  pop rcx
000078805cde0767  pop rax
000078805cde0768  add rsp, 0x08
000078805cde076c  jmp 0x000078805CDDC60F
000078805cde0771  sub rsp, 0x08
000078805cde0775  push rax
000078805cde0776  push rcx
000078805cde0777  push rdx
000078805cde0778  push rdi
000078805cde0779  push rsi
000078805cde077a  push r8
000078805cde077c  push r9
000078805cde077e  push r10
000078805cde0780  push r11
000078805cde0782  sub rsp, 0xF0
000078805cde0789  vmovaps [rsp], xmm0
000078805cde078e  vmovaps [rsp+0x10], xmm1
000078805cde0794  vmovaps [rsp+0x20], xmm2
000078805cde079a  vmovaps [rsp+0x30], xmm3
000078805cde07a0  vmovaps [rsp+0x40], xmm4
000078805cde07a6  vmovaps [rsp+0x50], xmm5
000078805cde07ac  vmovaps [rsp+0x60], xmm6
000078805cde07b2  vmovaps [rsp+0x70], xmm7
000078805cde07b8  vmovaps [rsp+0x80], xmm9
000078805cde07c1  vmovaps [rsp+0x90], xmm10
000078805cde07ca  vmovaps [rsp+0xA0], xmm11
000078805cde07d3  vmovaps [rsp+0xB0], xmm12
000078805cde07dc  vmovaps [rsp+0xC0], xmm13
000078805cde07e5  vmovaps [rsp+0xD0], xmm14
000078805cde07ee  vmovaps [rsp+0xE0], xmm15
000078805cde07f7  sub rsp, 0x30
000078805cde07fb  movaps [rsp], xmm8
000078805cde0800  movaps [rsp+0x10], xmm15
000078805cde0806  movaps [rsp+0x20], xmm9
000078805cde080c  lea rdi, [rsp]
000078805cde0810  mov esi, 0x00
000078805cde0815  mov rax, 0x5771AD6EA530
000078805cde081f  call rax
000078805cde0821  movaps xmm8, [rsp]
000078805cde0826  add rsp, 0x30
000078805cde082a  vmovaps xmm0, [rsp]
000078805cde082f  vmovaps xmm1, [rsp+0x10]
000078805cde0835  vmovaps xmm2, [rsp+0x20]
000078805cde083b  vmovaps xmm3, [rsp+0x30]
000078805cde0841  vmovaps xmm4, [rsp+0x40]
000078805cde0847  vmovaps xmm5, [rsp+0x50]
000078805cde084d  vmovaps xmm6, [rsp+0x60]
000078805cde0853  vmovaps xmm7, [rsp+0x70]
000078805cde0859  vmovaps xmm9, [rsp+0x80]
000078805cde0862  vmovaps xmm10, [rsp+0x90]
000078805cde086b  vmovaps xmm11, [rsp+0xA0]
000078805cde0874  vmovaps xmm12, [rsp+0xB0]
000078805cde087d  vmovaps xmm13, [rsp+0xC0]
000078805cde0886  vmovaps xmm14, [rsp+0xD0]
000078805cde088f  vmovaps xmm15, [rsp+0xE0]
000078805cde0898  add rsp, 0xF0
000078805cde089f  pop r11
000078805cde08a1  pop r10
000078805cde08a3  pop r9
000078805cde08a5  pop r8
000078805cde08a7  pop rsi
000078805cde08a8  pop rdi
000078805cde08a9  pop rdx
000078805cde08aa  pop rcx
000078805cde08ab  pop rax
000078805cde08ac  add rsp, 0x08
000078805cde08b0  jmp 0x000078805CDDC63D
000078805cde08b5  sub rsp, 0x08
000078805cde08b9  push rax
000078805cde08ba  push rcx
000078805cde08bb  push rdx
000078805cde08bc  push rdi
000078805cde08bd  push rsi
000078805cde08be  push r8
000078805cde08c0  push r9
000078805cde08c2  push r10
000078805cde08c4  push r11
000078805cde08c6  sub rsp, 0xF0
000078805cde08cd  vmovaps [rsp], xmm0
000078805cde08d2  vmovaps [rsp+0x10], xmm1
000078805cde08d8  vmovaps [rsp+0x20], xmm2
000078805cde08de  vmovaps [rsp+0x30], xmm3
000078805cde08e4  vmovaps [rsp+0x40], xmm4
000078805cde08ea  vmovaps [rsp+0x50], xmm5
000078805cde08f0  vmovaps [rsp+0x60], xmm6
000078805cde08f6  vmovaps [rsp+0x70], xmm7
000078805cde08fc  vmovaps [rsp+0x80], xmm8
000078805cde0905  vmovaps [rsp+0x90], xmm9
000078805cde090e  vmovaps [rsp+0xA0], xmm10
000078805cde0917  vmovaps [rsp+0xB0], xmm11
000078805cde0920  vmovaps [rsp+0xC0], xmm12
000078805cde0929  vmovaps [rsp+0xD0], xmm13
000078805cde0932  vmovaps [rsp+0xE0], xmm14
000078805cde093b  sub rsp, 0x30
000078805cde093f  movaps [rsp], xmm15
000078805cde0944  movaps [rsp+0x10], xmm11
000078805cde094a  movaps [rsp+0x20], xmm6
000078805cde094f  lea rdi, [rsp]
000078805cde0953  mov esi, 0x00
000078805cde0958  mov rax, 0x5771AD6EA530
000078805cde0962  call rax
000078805cde0964  movaps xmm15, [rsp]
000078805cde0969  add rsp, 0x30
000078805cde096d  vmovaps xmm0, [rsp]
000078805cde0972  vmovaps xmm1, [rsp+0x10]
000078805cde0978  vmovaps xmm2, [rsp+0x20]
000078805cde097e  vmovaps xmm3, [rsp+0x30]
000078805cde0984  vmovaps xmm4, [rsp+0x40]
000078805cde098a  vmovaps xmm5, [rsp+0x50]
000078805cde0990  vmovaps xmm6, [rsp+0x60]
000078805cde0996  vmovaps xmm7, [rsp+0x70]
000078805cde099c  vmovaps xmm8, [rsp+0x80]
000078805cde09a5  vmovaps xmm9, [rsp+0x90]
000078805cde09ae  vmovaps xmm10, [rsp+0xA0]
000078805cde09b7  vmovaps xmm11, [rsp+0xB0]
000078805cde09c0  vmovaps xmm12, [rsp+0xC0]
000078805cde09c9  vmovaps xmm13, [rsp+0xD0]
000078805cde09d2  vmovaps xmm14, [rsp+0xE0]
000078805cde09db  add rsp, 0xF0
000078805cde09e2  pop r11
000078805cde09e4  pop r10
000078805cde09e6  pop r9
000078805cde09e8  pop r8
000078805cde09ea  pop rsi
000078805cde09eb  pop rdi
000078805cde09ec  pop rdx
000078805cde09ed  pop rcx
000078805cde09ee  pop rax
000078805cde09ef  add rsp, 0x08
000078805cde09f3  jmp 0x000078805CDDC658
000078805cde09f8  sub rsp, 0x08
000078805cde09fc  push rax
000078805cde09fd  push rcx
000078805cde09fe  push rdx
000078805cde09ff  push rdi
000078805cde0a00  push rsi
000078805cde0a01  push r8
000078805cde0a03  push r9
000078805cde0a05  push r10
000078805cde0a07  push r11
000078805cde0a09  sub rsp, 0xF0
000078805cde0a10  vmovaps [rsp], xmm0
000078805cde0a15  vmovaps [rsp+0x10], xmm1
000078805cde0a1b  vmovaps [rsp+0x20], xmm2
000078805cde0a21  vmovaps [rsp+0x30], xmm3
000078805cde0a27  vmovaps [rsp+0x40], xmm4
000078805cde0a2d  vmovaps [rsp+0x50], xmm5
000078805cde0a33  vmovaps [rsp+0x60], xmm6
000078805cde0a39  vmovaps [rsp+0x70], xmm8
000078805cde0a3f  vmovaps [rsp+0x80], xmm9
000078805cde0a48  vmovaps [rsp+0x90], xmm10
000078805cde0a51  vmovaps [rsp+0xA0], xmm11
000078805cde0a5a  vmovaps [rsp+0xB0], xmm12
000078805cde0a63  vmovaps [rsp+0xC0], xmm13
000078805cde0a6c  vmovaps [rsp+0xD0], xmm14
000078805cde0a75  vmovaps [rsp+0xE0], xmm15
000078805cde0a7e  sub rsp, 0x30
000078805cde0a82  movaps [rsp], xmm7
000078805cde0a86  movaps [rsp+0x10], xmm11
000078805cde0a8c  movaps [rsp+0x20], xmm9
000078805cde0a92  lea rdi, [rsp]
000078805cde0a96  mov esi, 0x00
000078805cde0a9b  mov rax, 0x5771AD6EA530
000078805cde0aa5  call rax
000078805cde0aa7  movaps xmm7, [rsp]
000078805cde0aab  add rsp, 0x30
000078805cde0aaf  vmovaps xmm0, [rsp]
000078805cde0ab4  vmovaps xmm1, [rsp+0x10]
000078805cde0aba  vmovaps xmm2, [rsp+0x20]
000078805cde0ac0  vmovaps xmm3, [rsp+0x30]
000078805cde0ac6  vmovaps xmm4, [rsp+0x40]
000078805cde0acc  vmovaps xmm5, [rsp+0x50]
000078805cde0ad2  vmovaps xmm6, [rsp+0x60]
000078805cde0ad8  vmovaps xmm8, [rsp+0x70]
000078805cde0ade  vmovaps xmm9, [rsp+0x80]
000078805cde0ae7  vmovaps xmm10, [rsp+0x90]
000078805cde0af0  vmovaps xmm11, [rsp+0xA0]
000078805cde0af9  vmovaps xmm12, [rsp+0xB0]
000078805cde0b02  vmovaps xmm13, [rsp+0xC0]
000078805cde0b0b  vmovaps xmm14, [rsp+0xD0]
000078805cde0b14  vmovaps xmm15, [rsp+0xE0]
000078805cde0b1d  add rsp, 0xF0
000078805cde0b24  pop r11
000078805cde0b26  pop r10
000078805cde0b28  pop r9
000078805cde0b2a  pop r8
000078805cde0b2c  pop rsi
000078805cde0b2d  pop rdi
000078805cde0b2e  pop rdx
000078805cde0b2f  pop rcx
000078805cde0b30  pop rax
000078805cde0b31  add rsp, 0x08
000078805cde0b35  jmp 0x000078805CDDC685
000078805cde0b3a  sub rsp, 0x08
000078805cde0b3e  push rax
000078805cde0b3f  push rcx
000078805cde0b40  push rdx
000078805cde0b41  push rdi
000078805cde0b42  push rsi
000078805cde0b43  push r8
000078805cde0b45  push r9
000078805cde0b47  push r10
000078805cde0b49  push r11
000078805cde0b4b  sub rsp, 0xF0
000078805cde0b52  vmovaps [rsp], xmm0
000078805cde0b57  vmovaps [rsp+0x10], xmm1
000078805cde0b5d  vmovaps [rsp+0x20], xmm2
000078805cde0b63  vmovaps [rsp+0x30], xmm3
000078805cde0b69  vmovaps [rsp+0x40], xmm4
000078805cde0b6f  vmovaps [rsp+0x50], xmm5
000078805cde0b75  vmovaps [rsp+0x60], xmm6
000078805cde0b7b  vmovaps [rsp+0x70], xmm7
000078805cde0b81  vmovaps [rsp+0x80], xmm8
000078805cde0b8a  vmovaps [rsp+0x90], xmm9
000078805cde0b93  vmovaps [rsp+0xA0], xmm10
000078805cde0b9c  vmovaps [rsp+0xB0], xmm12
000078805cde0ba5  vmovaps [rsp+0xC0], xmm13
000078805cde0bae  vmovaps [rsp+0xD0], xmm14
000078805cde0bb7  vmovaps [rsp+0xE0], xmm15
000078805cde0bc0  sub rsp, 0x30
000078805cde0bc4  movaps [rsp], xmm11
000078805cde0bc9  movaps [rsp+0x10], xmm10
000078805cde0bcf  movaps [rsp+0x20], xmm14
000078805cde0bd5  lea rdi, [rsp]
000078805cde0bd9  mov esi, 0x00
000078805cde0bde  mov rax, 0x5771AD6EA530
000078805cde0be8  call rax
000078805cde0bea  movaps xmm11, [rsp]
000078805cde0bef  add rsp, 0x30
000078805cde0bf3  vmovaps xmm0, [rsp]
000078805cde0bf8  vmovaps xmm1, [rsp+0x10]
000078805cde0bfe  vmovaps xmm2, [rsp+0x20]
000078805cde0c04  vmovaps xmm3, [rsp+0x30]
000078805cde0c0a  vmovaps xmm4, [rsp+0x40]
000078805cde0c10  vmovaps xmm5, [rsp+0x50]
000078805cde0c16  vmovaps xmm6, [rsp+0x60]
000078805cde0c1c  vmovaps xmm7, [rsp+0x70]
000078805cde0c22  vmovaps xmm8, [rsp+0x80]
000078805cde0c2b  vmovaps xmm9, [rsp+0x90]
000078805cde0c34  vmovaps xmm10, [rsp+0xA0]
000078805cde0c3d  vmovaps xmm12, [rsp+0xB0]
000078805cde0c46  vmovaps xmm13, [rsp+0xC0]
000078805cde0c4f  vmovaps xmm14, [rsp+0xD0]
000078805cde0c58  vmovaps xmm15, [rsp+0xE0]
000078805cde0c61  add rsp, 0xF0
000078805cde0c68  pop r11
000078805cde0c6a  pop r10
000078805cde0c6c  pop r9
000078805cde0c6e  pop r8
000078805cde0c70  pop rsi
000078805cde0c71  pop rdi
000078805cde0c72  pop rdx
000078805cde0c73  pop rcx
000078805cde0c74  pop rax
000078805cde0c75  add rsp, 0x08
000078805cde0c79  jmp 0x000078805CDDC6A0
000078805cde0c7e  call 0x000078805CCC33A0
000078805cde0c83  jmp 0x000078805CDDC6AA
000078805cde0c88  sub rsp, 0x08
000078805cde0c8c  push rax
000078805cde0c8d  push rcx
000078805cde0c8e  push rdx
000078805cde0c8f  push rdi
000078805cde0c90  push rsi
000078805cde0c91  push r8
000078805cde0c93  push r9
000078805cde0c95  push r10
000078805cde0c97  push r11
000078805cde0c99  sub rsp, 0xF0
000078805cde0ca0  vmovaps [rsp], xmm0
000078805cde0ca5  vmovaps [rsp+0x10], xmm1
000078805cde0cab  vmovaps [rsp+0x20], xmm2
000078805cde0cb1  vmovaps [rsp+0x30], xmm3
000078805cde0cb7  vmovaps [rsp+0x40], xmm4
000078805cde0cbd  vmovaps [rsp+0x50], xmm5
000078805cde0cc3  vmovaps [rsp+0x60], xmm6
000078805cde0cc9  vmovaps [rsp+0x70], xmm7
000078805cde0ccf  vmovaps [rsp+0x80], xmm8
000078805cde0cd8  vmovaps [rsp+0x90], xmm9
000078805cde0ce1  vmovaps [rsp+0xA0], xmm11
000078805cde0cea  vmovaps [rsp+0xB0], xmm12
000078805cde0cf3  vmovaps [rsp+0xC0], xmm13
000078805cde0cfc  vmovaps [rsp+0xD0], xmm14
000078805cde0d05  vmovaps [rsp+0xE0], xmm15
000078805cde0d0e  sub rsp, 0x30
000078805cde0d12  movaps [rsp], xmm10
000078805cde0d17  movaps [rsp+0x10], xmm1
000078805cde0d1c  movaps [rsp+0x20], xmm12
000078805cde0d22  lea rdi, [rsp]
000078805cde0d26  mov esi, 0x00
000078805cde0d2b  mov rax, 0x5771AD6EA530
000078805cde0d35  call rax
000078805cde0d37  movaps xmm10, [rsp]
000078805cde0d3c  add rsp, 0x30
000078805cde0d40  vmovaps xmm0, [rsp]
000078805cde0d45  vmovaps xmm1, [rsp+0x10]
000078805cde0d4b  vmovaps xmm2, [rsp+0x20]
000078805cde0d51  vmovaps xmm3, [rsp+0x30]
000078805cde0d57  vmovaps xmm4, [rsp+0x40]
000078805cde0d5d  vmovaps xmm5, [rsp+0x50]
000078805cde0d63  vmovaps xmm6, [rsp+0x60]
000078805cde0d69  vmovaps xmm7, [rsp+0x70]
000078805cde0d6f  vmovaps xmm8, [rsp+0x80]
000078805cde0d78  vmovaps xmm9, [rsp+0x90]
000078805cde0d81  vmovaps xmm11, [rsp+0xA0]
000078805cde0d8a  vmovaps xmm12, [rsp+0xB0]
000078805cde0d93  vmovaps xmm13, [rsp+0xC0]
000078805cde0d9c  vmovaps xmm14, [rsp+0xD0]
000078805cde0da5  vmovaps xmm15, [rsp+0xE0]
000078805cde0dae  add rsp, 0xF0
000078805cde0db5  pop r11
000078805cde0db7  pop r10
000078805cde0db9  pop r9
000078805cde0dbb  pop r8
000078805cde0dbd  pop rsi
000078805cde0dbe  pop rdi
000078805cde0dbf  pop rdx
000078805cde0dc0  pop rcx
000078805cde0dc1  pop rax
000078805cde0dc2  add rsp, 0x08
000078805cde0dc6  jmp 0x000078805CDDC6CD
000078805cde0dcb  sub rsp, 0x08
000078805cde0dcf  push rax
000078805cde0dd0  push rcx
000078805cde0dd1  push rdx
000078805cde0dd2  push rdi
000078805cde0dd3  push rsi
000078805cde0dd4  push r8
000078805cde0dd6  push r9
000078805cde0dd8  push r10
000078805cde0dda  push r11
000078805cde0ddc  sub rsp, 0xF0
000078805cde0de3  vmovaps [rsp], xmm0
000078805cde0de8  vmovaps [rsp+0x10], xmm1
000078805cde0dee  vmovaps [rsp+0x20], xmm2
000078805cde0df4  vmovaps [rsp+0x30], xmm3
000078805cde0dfa  vmovaps [rsp+0x40], xmm4
000078805cde0e00  vmovaps [rsp+0x50], xmm5
000078805cde0e06  vmovaps [rsp+0x60], xmm6
000078805cde0e0c  vmovaps [rsp+0x70], xmm7
000078805cde0e12  vmovaps [rsp+0x80], xmm8
000078805cde0e1b  vmovaps [rsp+0x90], xmm9
000078805cde0e24  vmovaps [rsp+0xA0], xmm10
000078805cde0e2d  vmovaps [rsp+0xB0], xmm11
000078805cde0e36  vmovaps [rsp+0xC0], xmm13
000078805cde0e3f  vmovaps [rsp+0xD0], xmm14
000078805cde0e48  vmovaps [rsp+0xE0], xmm15
000078805cde0e51  sub rsp, 0x30
000078805cde0e55  movaps [rsp], xmm12
000078805cde0e5a  movaps [rsp+0x10], xmm14
000078805cde0e60  movaps [rsp+0x20], xmm1
000078805cde0e65  lea rdi, [rsp]
000078805cde0e69  mov esi, 0x00
000078805cde0e6e  mov rax, 0x5771AD6EA530
000078805cde0e78  call rax
000078805cde0e7a  movaps xmm12, [rsp]
000078805cde0e7f  add rsp, 0x30
000078805cde0e83  vmovaps xmm0, [rsp]
000078805cde0e88  vmovaps xmm1, [rsp+0x10]
000078805cde0e8e  vmovaps xmm2, [rsp+0x20]
000078805cde0e94  vmovaps xmm3, [rsp+0x30]
000078805cde0e9a  vmovaps xmm4, [rsp+0x40]
000078805cde0ea0  vmovaps xmm5, [rsp+0x50]
000078805cde0ea6  vmovaps xmm6, [rsp+0x60]
000078805cde0eac  vmovaps xmm7, [rsp+0x70]
000078805cde0eb2  vmovaps xmm8, [rsp+0x80]
000078805cde0ebb  vmovaps xmm9, [rsp+0x90]
000078805cde0ec4  vmovaps xmm10, [rsp+0xA0]
000078805cde0ecd  vmovaps xmm11, [rsp+0xB0]
000078805cde0ed6  vmovaps xmm13, [rsp+0xC0]
000078805cde0edf  vmovaps xmm14, [rsp+0xD0]
000078805cde0ee8  vmovaps xmm15, [rsp+0xE0]
000078805cde0ef1  add rsp, 0xF0
000078805cde0ef8  pop r11
000078805cde0efa  pop r10
000078805cde0efc  pop r9
000078805cde0efe  pop r8
000078805cde0f00  pop rsi
000078805cde0f01  pop rdi
000078805cde0f02  pop rdx
000078805cde0f03  pop rcx
000078805cde0f04  pop rax
000078805cde0f05  add rsp, 0x08
000078805cde0f09  jmp 0x000078805CDDC6FC
000078805cde0f0e  sub rsp, 0x08
000078805cde0f12  push rax
000078805cde0f13  push rcx
000078805cde0f14  push rdx
000078805cde0f15  push rdi
000078805cde0f16  push rsi
000078805cde0f17  push r8
000078805cde0f19  push r9
000078805cde0f1b  push r10
000078805cde0f1d  push r11
000078805cde0f1f  sub rsp, 0xF0
000078805cde0f26  vmovaps [rsp], xmm0
000078805cde0f2b  vmovaps [rsp+0x10], xmm1
000078805cde0f31  vmovaps [rsp+0x20], xmm2
000078805cde0f37  vmovaps [rsp+0x30], xmm3
000078805cde0f3d  vmovaps [rsp+0x40], xmm4
000078805cde0f43  vmovaps [rsp+0x50], xmm5
000078805cde0f49  vmovaps [rsp+0x60], xmm6
000078805cde0f4f  vmovaps [rsp+0x70], xmm7
000078805cde0f55  vmovaps [rsp+0x80], xmm8
000078805cde0f5e  vmovaps [rsp+0x90], xmm9
000078805cde0f67  vmovaps [rsp+0xA0], xmm10
000078805cde0f70  vmovaps [rsp+0xB0], xmm11
000078805cde0f79  vmovaps [rsp+0xC0], xmm12
000078805cde0f82  vmovaps [rsp+0xD0], xmm13
000078805cde0f8b  vmovaps [rsp+0xE0], xmm15
000078805cde0f94  sub rsp, 0x30
000078805cde0f98  movaps [rsp], xmm14
000078805cde0f9d  movaps [rsp+0x10], xmm9
000078805cde0fa3  movaps [rsp+0x20], xmm1
000078805cde0fa8  lea rdi, [rsp]
000078805cde0fac  mov esi, 0x00
000078805cde0fb1  mov rax, 0x5771AD6EA530
000078805cde0fbb  call rax
000078805cde0fbd  movaps xmm14, [rsp]
000078805cde0fc2  add rsp, 0x30
000078805cde0fc6  vmovaps xmm0, [rsp]
000078805cde0fcb  vmovaps xmm1, [rsp+0x10]
000078805cde0fd1  vmovaps xmm2, [rsp+0x20]
000078805cde0fd7  vmovaps xmm3, [rsp+0x30]
000078805cde0fdd  vmovaps xmm4, [rsp+0x40]
000078805cde0fe3  vmovaps xmm5, [rsp+0x50]
000078805cde0fe9  vmovaps xmm6, [rsp+0x60]
000078805cde0fef  vmovaps xmm7, [rsp+0x70]
000078805cde0ff5  vmovaps xmm8, [rsp+0x80]
000078805cde0ffe  vmovaps xmm9, [rsp+0x90]
000078805cde1007  vmovaps xmm10, [rsp+0xA0]
000078805cde1010  vmovaps xmm11, [rsp+0xB0]
000078805cde1019  vmovaps xmm12, [rsp+0xC0]
000078805cde1022  vmovaps xmm13, [rsp+0xD0]
000078805cde102b  vmovaps xmm15, [rsp+0xE0]
000078805cde1034  add rsp, 0xF0
000078805cde103b  pop r11
000078805cde103d  pop r10
000078805cde103f  pop r9
000078805cde1041  pop r8
000078805cde1043  pop rsi
000078805cde1044  pop rdi
000078805cde1045  pop rdx
000078805cde1046  pop rcx
000078805cde1047  pop rax
000078805cde1048  add rsp, 0x08
000078805cde104c  jmp 0x000078805CDDC72B
000078805cde1051  sub rsp, 0x08
000078805cde1055  push rax
000078805cde1056  push rcx
000078805cde1057  push rdx
000078805cde1058  push rdi
000078805cde1059  push rsi
000078805cde105a  push r8
000078805cde105c  push r9
000078805cde105e  push r10
000078805cde1060  push r11
000078805cde1062  sub rsp, 0xF0
000078805cde1069  vmovaps [rsp], xmm0
000078805cde106e  vmovaps [rsp+0x10], xmm2
000078805cde1074  vmovaps [rsp+0x20], xmm3
000078805cde107a  vmovaps [rsp+0x30], xmm4
000078805cde1080  vmovaps [rsp+0x40], xmm5
000078805cde1086  vmovaps [rsp+0x50], xmm6
000078805cde108c  vmovaps [rsp+0x60], xmm7
000078805cde1092  vmovaps [rsp+0x70], xmm8
000078805cde1098  vmovaps [rsp+0x80], xmm9
000078805cde10a1  vmovaps [rsp+0x90], xmm10
000078805cde10aa  vmovaps [rsp+0xA0], xmm11
000078805cde10b3  vmovaps [rsp+0xB0], xmm12
000078805cde10bc  vmovaps [rsp+0xC0], xmm13
000078805cde10c5  vmovaps [rsp+0xD0], xmm14
000078805cde10ce  vmovaps [rsp+0xE0], xmm15
000078805cde10d7  sub rsp, 0x30
000078805cde10db  movaps [rsp], xmm1
000078805cde10df  movaps [rsp+0x10], xmm13
000078805cde10e5  movaps [rsp+0x20], xmm8
000078805cde10eb  lea rdi, [rsp]
000078805cde10ef  mov esi, 0x00
000078805cde10f4  mov rax, 0x5771AD6EA530
000078805cde10fe  call rax
000078805cde1100  movaps xmm1, [rsp]
000078805cde1104  add rsp, 0x30
000078805cde1108  vmovaps xmm0, [rsp]
000078805cde110d  vmovaps xmm2, [rsp+0x10]
000078805cde1113  vmovaps xmm3, [rsp+0x20]
000078805cde1119  vmovaps xmm4, [rsp+0x30]
000078805cde111f  vmovaps xmm5, [rsp+0x40]
000078805cde1125  vmovaps xmm6, [rsp+0x50]
000078805cde112b  vmovaps xmm7, [rsp+0x60]
000078805cde1131  vmovaps xmm8, [rsp+0x70]
000078805cde1137  vmovaps xmm9, [rsp+0x80]
000078805cde1140  vmovaps xmm10, [rsp+0x90]
000078805cde1149  vmovaps xmm11, [rsp+0xA0]
000078805cde1152  vmovaps xmm12, [rsp+0xB0]
000078805cde115b  vmovaps xmm13, [rsp+0xC0]
000078805cde1164  vmovaps xmm14, [rsp+0xD0]
000078805cde116d  vmovaps xmm15, [rsp+0xE0]
000078805cde1176  add rsp, 0xF0
000078805cde117d  pop r11
000078805cde117f  pop r10
000078805cde1181  pop r9
000078805cde1183  pop r8
000078805cde1185  pop rsi
000078805cde1186  pop rdi
000078805cde1187  pop rdx
000078805cde1188  pop rcx
000078805cde1189  pop rax
000078805cde118a  add rsp, 0x08
000078805cde118e  jmp 0x000078805CDDC74D
000078805cde1193  call 0x000078805CC0C260
000078805cde1198  jmp 0x000078805CDDC75B
000078805cde119d  call 0x000078805CCBD750
000078805cde11a2  jmp 0x000078805CDDC765
000078805cde11a7  sub rsp, 0x08
000078805cde11ab  push rax
000078805cde11ac  push rcx
000078805cde11ad  push rdx
000078805cde11ae  push rdi
000078805cde11af  push rsi
000078805cde11b0  push r8
000078805cde11b2  push r9
000078805cde11b4  push r10
000078805cde11b6  push r11
000078805cde11b8  sub rsp, 0xF0
000078805cde11bf  vmovaps [rsp], xmm0
000078805cde11c4  vmovaps [rsp+0x10], xmm1
000078805cde11ca  vmovaps [rsp+0x20], xmm2
000078805cde11d0  vmovaps [rsp+0x30], xmm3
000078805cde11d6  vmovaps [rsp+0x40], xmm4
000078805cde11dc  vmovaps [rsp+0x50], xmm5
000078805cde11e2  vmovaps [rsp+0x60], xmm6
000078805cde11e8  vmovaps [rsp+0x70], xmm7
000078805cde11ee  vmovaps [rsp+0x80], xmm9
000078805cde11f7  vmovaps [rsp+0x90], xmm10
000078805cde1200  vmovaps [rsp+0xA0], xmm11
000078805cde1209  vmovaps [rsp+0xB0], xmm12
000078805cde1212  vmovaps [rsp+0xC0], xmm13
000078805cde121b  vmovaps [rsp+0xD0], xmm14
000078805cde1224  vmovaps [rsp+0xE0], xmm15
000078805cde122d  sub rsp, 0x30
000078805cde1231  movaps [rsp], xmm8
000078805cde1236  movaps [rsp+0x10], xmm15
000078805cde123c  movaps [rsp+0x20], xmm7
000078805cde1241  lea rdi, [rsp]
000078805cde1245  mov esi, 0x00
000078805cde124a  mov rax, 0x5771AD6EA530
000078805cde1254  call rax
000078805cde1256  movaps xmm8, [rsp]
000078805cde125b  add rsp, 0x30
000078805cde125f  vmovaps xmm0, [rsp]
000078805cde1264  vmovaps xmm1, [rsp+0x10]
000078805cde126a  vmovaps xmm2, [rsp+0x20]
000078805cde1270  vmovaps xmm3, [rsp+0x30]
000078805cde1276  vmovaps xmm4, [rsp+0x40]
000078805cde127c  vmovaps xmm5, [rsp+0x50]
000078805cde1282  vmovaps xmm6, [rsp+0x60]
000078805cde1288  vmovaps xmm7, [rsp+0x70]
000078805cde128e  vmovaps xmm9, [rsp+0x80]
000078805cde1297  vmovaps xmm10, [rsp+0x90]
000078805cde12a0  vmovaps xmm11, [rsp+0xA0]
000078805cde12a9  vmovaps xmm12, [rsp+0xB0]
000078805cde12b2  vmovaps xmm13, [rsp+0xC0]
000078805cde12bb  vmovaps xmm14, [rsp+0xD0]
000078805cde12c4  vmovaps xmm15, [rsp+0xE0]
000078805cde12cd  add rsp, 0xF0
000078805cde12d4  pop r11
000078805cde12d6  pop r10
000078805cde12d8  pop r9
000078805cde12da  pop r8
000078805cde12dc  pop rsi
000078805cde12dd  pop rdi
000078805cde12de  pop rdx
000078805cde12df  pop rcx
000078805cde12e0  pop rax
000078805cde12e1  add rsp, 0x08
000078805cde12e5  jmp 0x000078805CDDC787
000078805cde12ea  sub rsp, 0x08
000078805cde12ee  push rax
000078805cde12ef  push rcx
000078805cde12f0  push rdx
000078805cde12f1  push rdi
000078805cde12f2  push rsi
000078805cde12f3  push r8
000078805cde12f5  push r9
000078805cde12f7  push r10
000078805cde12f9  push r11
000078805cde12fb  sub rsp, 0xF0
000078805cde1302  vmovaps [rsp], xmm0
000078805cde1307  vmovaps [rsp+0x10], xmm1
000078805cde130d  vmovaps [rsp+0x20], xmm2
000078805cde1313  vmovaps [rsp+0x30], xmm3
000078805cde1319  vmovaps [rsp+0x40], xmm4
000078805cde131f  vmovaps [rsp+0x50], xmm5
000078805cde1325  vmovaps [rsp+0x60], xmm6
000078805cde132b  vmovaps [rsp+0x70], xmm8
000078805cde1331  vmovaps [rsp+0x80], xmm9
000078805cde133a  vmovaps [rsp+0x90], xmm10
000078805cde1343  vmovaps [rsp+0xA0], xmm11
000078805cde134c  vmovaps [rsp+0xB0], xmm12
000078805cde1355  vmovaps [rsp+0xC0], xmm13
000078805cde135e  vmovaps [rsp+0xD0], xmm14
000078805cde1367  vmovaps [rsp+0xE0], xmm15
000078805cde1370  sub rsp, 0x30
000078805cde1374  movaps [rsp], xmm7
000078805cde1378  movaps [rsp+0x10], xmm9
000078805cde137e  movaps [rsp+0x20], xmm15
000078805cde1384  lea rdi, [rsp]
000078805cde1388  mov esi, 0x00
000078805cde138d  mov rax, 0x5771AD6EA530
000078805cde1397  call rax
000078805cde1399  movaps xmm7, [rsp]
000078805cde139d  add rsp, 0x30
000078805cde13a1  vmovaps xmm0, [rsp]
000078805cde13a6  vmovaps xmm1, [rsp+0x10]
000078805cde13ac  vmovaps xmm2, [rsp+0x20]
000078805cde13b2  vmovaps xmm3, [rsp+0x30]
000078805cde13b8  vmovaps xmm4, [rsp+0x40]
000078805cde13be  vmovaps xmm5, [rsp+0x50]
000078805cde13c4  vmovaps xmm6, [rsp+0x60]
000078805cde13ca  vmovaps xmm8, [rsp+0x70]
000078805cde13d0  vmovaps xmm9, [rsp+0x80]
000078805cde13d9  vmovaps xmm10, [rsp+0x90]
000078805cde13e2  vmovaps xmm11, [rsp+0xA0]
000078805cde13eb  vmovaps xmm12, [rsp+0xB0]
000078805cde13f4  vmovaps xmm13, [rsp+0xC0]
000078805cde13fd  vmovaps xmm14, [rsp+0xD0]
000078805cde1406  vmovaps xmm15, [rsp+0xE0]
000078805cde140f  add rsp, 0xF0
000078805cde1416  pop r11
000078805cde1418  pop r10
000078805cde141a  pop r9
000078805cde141c  pop r8
000078805cde141e  pop rsi
000078805cde141f  pop rdi
000078805cde1420  pop rdx
000078805cde1421  pop rcx
000078805cde1422  pop rax
000078805cde1423  add rsp, 0x08
000078805cde1427  jmp 0x000078805CDDC7B4
000078805cde142c  sub rsp, 0x08
000078805cde1430  push rax
000078805cde1431  push rcx
000078805cde1432  push rdx
000078805cde1433  push rdi
000078805cde1434  push rsi
000078805cde1435  push r8
000078805cde1437  push r9
000078805cde1439  push r10
000078805cde143b  push r11
000078805cde143d  sub rsp, 0xF0
000078805cde1444  vmovaps [rsp], xmm0
000078805cde1449  vmovaps [rsp+0x10], xmm1
000078805cde144f  vmovaps [rsp+0x20], xmm2
000078805cde1455  vmovaps [rsp+0x30], xmm3
000078805cde145b  vmovaps [rsp+0x40], xmm4
000078805cde1461  vmovaps [rsp+0x50], xmm5
000078805cde1467  vmovaps [rsp+0x60], xmm6
000078805cde146d  vmovaps [rsp+0x70], xmm7
000078805cde1473  vmovaps [rsp+0x80], xmm8
000078805cde147c  vmovaps [rsp+0x90], xmm10
000078805cde1485  vmovaps [rsp+0xA0], xmm11
000078805cde148e  vmovaps [rsp+0xB0], xmm12
000078805cde1497  vmovaps [rsp+0xC0], xmm13
000078805cde14a0  vmovaps [rsp+0xD0], xmm14
000078805cde14a9  vmovaps [rsp+0xE0], xmm15
000078805cde14b2  sub rsp, 0x30
000078805cde14b6  movaps [rsp], xmm9
000078805cde14bb  movaps [rsp+0x10], xmm13
000078805cde14c1  movaps [rsp+0x20], xmm15
000078805cde14c7  lea rdi, [rsp]
000078805cde14cb  mov esi, 0x00
000078805cde14d0  mov rax, 0x5771AD6EA530
000078805cde14da  call rax
000078805cde14dc  movaps xmm9, [rsp]
000078805cde14e1  add rsp, 0x30
000078805cde14e5  vmovaps xmm0, [rsp]
000078805cde14ea  vmovaps xmm1, [rsp+0x10]
000078805cde14f0  vmovaps xmm2, [rsp+0x20]
000078805cde14f6  vmovaps xmm3, [rsp+0x30]
000078805cde14fc  vmovaps xmm4, [rsp+0x40]
000078805cde1502  vmovaps xmm5, [rsp+0x50]
000078805cde1508  vmovaps xmm6, [rsp+0x60]
000078805cde150e  vmovaps xmm7, [rsp+0x70]
000078805cde1514  vmovaps xmm8, [rsp+0x80]
000078805cde151d  vmovaps xmm10, [rsp+0x90]
000078805cde1526  vmovaps xmm11, [rsp+0xA0]
000078805cde152f  vmovaps xmm12, [rsp+0xB0]
000078805cde1538  vmovaps xmm13, [rsp+0xC0]
000078805cde1541  vmovaps xmm14, [rsp+0xD0]
000078805cde154a  vmovaps xmm15, [rsp+0xE0]
000078805cde1553  add rsp, 0xF0
000078805cde155a  pop r11
000078805cde155c  pop r10
000078805cde155e  pop r9
000078805cde1560  pop r8
000078805cde1562  pop rsi
000078805cde1563  pop rdi
000078805cde1564  pop rdx
000078805cde1565  pop rcx
000078805cde1566  pop rax
000078805cde1567  add rsp, 0x08
000078805cde156b  jmp 0x000078805CDDC7E2
000078805cde1570  sub rsp, 0x08
000078805cde1574  push rax
000078805cde1575  push rcx
000078805cde1576  push rdx
000078805cde1577  push rdi
000078805cde1578  push rsi
000078805cde1579  push r8
000078805cde157b  push r9
000078805cde157d  push r10
000078805cde157f  push r11
000078805cde1581  sub rsp, 0xF0
000078805cde1588  vmovaps [rsp], xmm0
000078805cde158d  vmovaps [rsp+0x10], xmm1
000078805cde1593  vmovaps [rsp+0x20], xmm2
000078805cde1599  vmovaps [rsp+0x30], xmm3
000078805cde159f  vmovaps [rsp+0x40], xmm4
000078805cde15a5  vmovaps [rsp+0x50], xmm5
000078805cde15ab  vmovaps [rsp+0x60], xmm6
000078805cde15b1  vmovaps [rsp+0x70], xmm7
000078805cde15b7  vmovaps [rsp+0x80], xmm8
000078805cde15c0  vmovaps [rsp+0x90], xmm9
000078805cde15c9  vmovaps [rsp+0xA0], xmm10
000078805cde15d2  vmovaps [rsp+0xB0], xmm11
000078805cde15db  vmovaps [rsp+0xC0], xmm12
000078805cde15e4  vmovaps [rsp+0xD0], xmm13
000078805cde15ed  vmovaps [rsp+0xE0], xmm14
000078805cde15f6  sub rsp, 0x30
000078805cde15fa  movaps [rsp], xmm15
000078805cde15ff  movaps [rsp+0x10], xmm11
000078805cde1605  movaps [rsp+0x20], xmm12
000078805cde160b  lea rdi, [rsp]
000078805cde160f  mov esi, 0x00
000078805cde1614  mov rax, 0x5771AD6EA530
000078805cde161e  call rax
000078805cde1620  movaps xmm15, [rsp]
000078805cde1625  add rsp, 0x30
000078805cde1629  vmovaps xmm0, [rsp]
000078805cde162e  vmovaps xmm1, [rsp+0x10]
000078805cde1634  vmovaps xmm2, [rsp+0x20]
000078805cde163a  vmovaps xmm3, [rsp+0x30]
000078805cde1640  vmovaps xmm4, [rsp+0x40]
000078805cde1646  vmovaps xmm5, [rsp+0x50]
000078805cde164c  vmovaps xmm6, [rsp+0x60]
000078805cde1652  vmovaps xmm7, [rsp+0x70]
000078805cde1658  vmovaps xmm8, [rsp+0x80]
000078805cde1661  vmovaps xmm9, [rsp+0x90]
000078805cde166a  vmovaps xmm10, [rsp+0xA0]
000078805cde1673  vmovaps xmm11, [rsp+0xB0]
000078805cde167c  vmovaps xmm12, [rsp+0xC0]
000078805cde1685  vmovaps xmm13, [rsp+0xD0]
000078805cde168e  vmovaps xmm14, [rsp+0xE0]
000078805cde1697  add rsp, 0xF0
000078805cde169e  pop r11
000078805cde16a0  pop r10
000078805cde16a2  pop r9
000078805cde16a4  pop r8
000078805cde16a6  pop rsi
000078805cde16a7  pop rdi
000078805cde16a8  pop rdx
000078805cde16a9  pop rcx
000078805cde16aa  pop rax
000078805cde16ab  add rsp, 0x08
000078805cde16af  jmp 0x000078805CDDC7FD
000078805cde16b4  sub rsp, 0x08
000078805cde16b8  push rax
000078805cde16b9  push rcx
000078805cde16ba  push rdx
000078805cde16bb  push rdi
000078805cde16bc  push rsi
000078805cde16bd  push r8
000078805cde16bf  push r9
000078805cde16c1  push r10
000078805cde16c3  push r11
000078805cde16c5  sub rsp, 0xF0
000078805cde16cc  vmovaps [rsp], xmm0
000078805cde16d1  vmovaps [rsp+0x10], xmm1
000078805cde16d7  vmovaps [rsp+0x20], xmm2
000078805cde16dd  vmovaps [rsp+0x30], xmm3
000078805cde16e3  vmovaps [rsp+0x40], xmm4
000078805cde16e9  vmovaps [rsp+0x50], xmm5
000078805cde16ef  vmovaps [rsp+0x60], xmm6
000078805cde16f5  vmovaps [rsp+0x70], xmm7
000078805cde16fb  vmovaps [rsp+0x80], xmm8
000078805cde1704  vmovaps [rsp+0x90], xmm9
000078805cde170d  vmovaps [rsp+0xA0], xmm10
000078805cde1716  vmovaps [rsp+0xB0], xmm11
000078805cde171f  vmovaps [rsp+0xC0], xmm12
000078805cde1728  vmovaps [rsp+0xD0], xmm14
000078805cde1731  vmovaps [rsp+0xE0], xmm15
000078805cde173a  sub rsp, 0x30
000078805cde173e  movaps [rsp], xmm13
000078805cde1743  movaps [rsp+0x10], xmm10
000078805cde1749  movaps [rsp+0x20], xmm14
000078805cde174f  lea rdi, [rsp]
000078805cde1753  mov esi, 0x00
000078805cde1758  mov rax, 0x5771AD6EA530
000078805cde1762  call rax
000078805cde1764  movaps xmm13, [rsp]
000078805cde1769  add rsp, 0x30
000078805cde176d  vmovaps xmm0, [rsp]
000078805cde1772  vmovaps xmm1, [rsp+0x10]
000078805cde1778  vmovaps xmm2, [rsp+0x20]
000078805cde177e  vmovaps xmm3, [rsp+0x30]
000078805cde1784  vmovaps xmm4, [rsp+0x40]
000078805cde178a  vmovaps xmm5, [rsp+0x50]
000078805cde1790  vmovaps xmm6, [rsp+0x60]
000078805cde1796  vmovaps xmm7, [rsp+0x70]
000078805cde179c  vmovaps xmm8, [rsp+0x80]
000078805cde17a5  vmovaps xmm9, [rsp+0x90]
000078805cde17ae  vmovaps xmm10, [rsp+0xA0]
000078805cde17b7  vmovaps xmm11, [rsp+0xB0]
000078805cde17c0  vmovaps xmm12, [rsp+0xC0]
000078805cde17c9  vmovaps xmm14, [rsp+0xD0]
000078805cde17d2  vmovaps xmm15, [rsp+0xE0]
000078805cde17db  add rsp, 0xF0
000078805cde17e2  pop r11
000078805cde17e4  pop r10
000078805cde17e6  pop r9
000078805cde17e8  pop r8
000078805cde17ea  pop rsi
000078805cde17eb  pop rdi
000078805cde17ec  pop rdx
000078805cde17ed  pop rcx
000078805cde17ee  pop rax
000078805cde17ef  add rsp, 0x08
000078805cde17f3  jmp 0x000078805CDDC820
000078805cde17f8  sub rsp, 0x08
000078805cde17fc  push rax
000078805cde17fd  push rcx
000078805cde17fe  push rdx
000078805cde17ff  push rdi
000078805cde1800  push rsi
000078805cde1801  push r8
000078805cde1803  push r9
000078805cde1805  push r10
000078805cde1807  push r11
000078805cde1809  sub rsp, 0xF0
000078805cde1810  vmovaps [rsp], xmm0
000078805cde1815  vmovaps [rsp+0x10], xmm1
000078805cde181b  vmovaps [rsp+0x20], xmm2
000078805cde1821  vmovaps [rsp+0x30], xmm3
000078805cde1827  vmovaps [rsp+0x40], xmm4
000078805cde182d  vmovaps [rsp+0x50], xmm5
000078805cde1833  vmovaps [rsp+0x60], xmm6
000078805cde1839  vmovaps [rsp+0x70], xmm7
000078805cde183f  vmovaps [rsp+0x80], xmm8
000078805cde1848  vmovaps [rsp+0x90], xmm9
000078805cde1851  vmovaps [rsp+0xA0], xmm10
000078805cde185a  vmovaps [rsp+0xB0], xmm11
000078805cde1863  vmovaps [rsp+0xC0], xmm12
000078805cde186c  vmovaps [rsp+0xD0], xmm13
000078805cde1875  vmovaps [rsp+0xE0], xmm15
000078805cde187e  sub rsp, 0x30
000078805cde1882  movaps [rsp], xmm14
000078805cde1887  movaps [rsp+0x10], xmm1
000078805cde188c  movaps [rsp+0x20], xmm7
000078805cde1891  lea rdi, [rsp]
000078805cde1895  mov esi, 0x00
000078805cde189a  mov rax, 0x5771AD6EA530
000078805cde18a4  call rax
000078805cde18a6  movaps xmm14, [rsp]
000078805cde18ab  add rsp, 0x30
000078805cde18af  vmovaps xmm0, [rsp]
000078805cde18b4  vmovaps xmm1, [rsp+0x10]
000078805cde18ba  vmovaps xmm2, [rsp+0x20]
000078805cde18c0  vmovaps xmm3, [rsp+0x30]
000078805cde18c6  vmovaps xmm4, [rsp+0x40]
000078805cde18cc  vmovaps xmm5, [rsp+0x50]
000078805cde18d2  vmovaps xmm6, [rsp+0x60]
000078805cde18d8  vmovaps xmm7, [rsp+0x70]
000078805cde18de  vmovaps xmm8, [rsp+0x80]
000078805cde18e7  vmovaps xmm9, [rsp+0x90]
000078805cde18f0  vmovaps xmm10, [rsp+0xA0]
000078805cde18f9  vmovaps xmm11, [rsp+0xB0]
000078805cde1902  vmovaps xmm12, [rsp+0xC0]
000078805cde190b  vmovaps xmm13, [rsp+0xD0]
000078805cde1914  vmovaps xmm15, [rsp+0xE0]
000078805cde191d  add rsp, 0xF0
000078805cde1924  pop r11
000078805cde1926  pop r10
000078805cde1928  pop r9
000078805cde192a  pop r8
000078805cde192c  pop rsi
000078805cde192d  pop rdi
000078805cde192e  pop rdx
000078805cde192f  pop rcx
000078805cde1930  pop rax
000078805cde1931  add rsp, 0x08
000078805cde1935  jmp 0x000078805CDDC843
000078805cde193a  sub rsp, 0x08
000078805cde193e  push rax
000078805cde193f  push rcx
000078805cde1940  push rdx
000078805cde1941  push rdi
000078805cde1942  push rsi
000078805cde1943  push r8
000078805cde1945  push r9
000078805cde1947  push r10
000078805cde1949  push r11
000078805cde194b  sub rsp, 0xF0
000078805cde1952  vmovaps [rsp], xmm0
000078805cde1957  vmovaps [rsp+0x10], xmm2
000078805cde195d  vmovaps [rsp+0x20], xmm3
000078805cde1963  vmovaps [rsp+0x30], xmm4
000078805cde1969  vmovaps [rsp+0x40], xmm5
000078805cde196f  vmovaps [rsp+0x50], xmm6
000078805cde1975  vmovaps [rsp+0x60], xmm7
000078805cde197b  vmovaps [rsp+0x70], xmm8
000078805cde1981  vmovaps [rsp+0x80], xmm9
000078805cde198a  vmovaps [rsp+0x90], xmm10
000078805cde1993  vmovaps [rsp+0xA0], xmm11
000078805cde199c  vmovaps [rsp+0xB0], xmm12
000078805cde19a5  vmovaps [rsp+0xC0], xmm13
000078805cde19ae  vmovaps [rsp+0xD0], xmm14
000078805cde19b7  vmovaps [rsp+0xE0], xmm15
000078805cde19c0  sub rsp, 0x30
000078805cde19c4  movaps [rsp], xmm1
000078805cde19c8  movaps [rsp+0x10], xmm8
000078805cde19ce  movaps [rsp+0x20], xmm9
000078805cde19d4  lea rdi, [rsp]
000078805cde19d8  mov esi, 0x00
000078805cde19dd  mov rax, 0x5771AD6EA530
000078805cde19e7  call rax
000078805cde19e9  movaps xmm1, [rsp]
000078805cde19ed  add rsp, 0x30
000078805cde19f1  vmovaps xmm0, [rsp]
000078805cde19f6  vmovaps xmm2, [rsp+0x10]
000078805cde19fc  vmovaps xmm3, [rsp+0x20]
000078805cde1a02  vmovaps xmm4, [rsp+0x30]
000078805cde1a08  vmovaps xmm5, [rsp+0x40]
000078805cde1a0e  vmovaps xmm6, [rsp+0x50]
000078805cde1a14  vmovaps xmm7, [rsp+0x60]
000078805cde1a1a  vmovaps xmm8, [rsp+0x70]
000078805cde1a20  vmovaps xmm9, [rsp+0x80]
000078805cde1a29  vmovaps xmm10, [rsp+0x90]
000078805cde1a32  vmovaps xmm11, [rsp+0xA0]
000078805cde1a3b  vmovaps xmm12, [rsp+0xB0]
000078805cde1a44  vmovaps xmm13, [rsp+0xC0]
000078805cde1a4d  vmovaps xmm14, [rsp+0xD0]
000078805cde1a56  vmovaps xmm15, [rsp+0xE0]
000078805cde1a5f  add rsp, 0xF0
000078805cde1a66  pop r11
000078805cde1a68  pop r10
000078805cde1a6a  pop r9
000078805cde1a6c  pop r8
000078805cde1a6e  pop rsi
000078805cde1a6f  pop rdi
000078805cde1a70  pop rdx
000078805cde1a71  pop rcx
000078805cde1a72  pop rax
000078805cde1a73  add rsp, 0x08
000078805cde1a77  jmp 0x000078805CDDC865
000078805cde1a7c  call 0x000078805CCE5940
000078805cde1a81  jmp 0x000078805CDDC873
000078805cde1a86  call 0x000078805CC0C380
000078805cde1a8b  jmp 0x000078805CDDC87D
000078805cde1a90  call 0x000078805CC0D600
000078805cde1a95  jmp 0x000078805CDDC887
000078805cde1a9a  call 0x000078805CBFF540
000078805cde1a9f  jmp 0x000078805CDDC891
000078805cde1aa4  int3
000078805cde1aa5  nop [rax+rax*1], ax
000078805cde1aae  nop
000078805cde1ab0  mov rax, [r15+0xF8]
000078805cde1ab7  lea r14, [rax+0x140]
000078805cde1abe  mov r12, [r13+r14*1]
000078805cde1ac3  mov [r15+0xE8], r12
000078805cde1aca  lea r14, [rax+0x130]
000078805cde1ad1  mov r12, [r13+r14*1]
000078805cde1ad6  lea r14, [rax+0x138]
000078805cde1add  mov r11, [r13+r14*1]
000078805cde1ae2  movq xmm1, r12
000078805cde1ae7  movq xmm15, r11
000078805cde1aec  movq xmm1, xmm1
000078805cde1af0  movq xmm1, xmm1
000078805cde1af4  movaps [r15+0x1A0], xmm1
000078805cde1afc  movq xmm15, xmm15
000078805cde1b01  movq xmm15, xmm15
000078805cde1b06  movaps [r15+0x190], xmm15
000078805cde1b0e  lea r14, [rax+0x120]
000078805cde1b15  mov r12, [r13+r14*1]
000078805cde1b1a  lea r14, [rax+0x128]
000078805cde1b21  mov r11, [r13+r14*1]
000078805cde1b26  movq xmm1, r12
000078805cde1b2b  movq xmm15, r11
000078805cde1b30  movq xmm1, xmm1
000078805cde1b34  movq xmm1, xmm1
000078805cde1b38  movaps [r15+0x1C0], xmm1
000078805cde1b40  movq xmm15, xmm15
000078805cde1b45  movq xmm15, xmm15
000078805cde1b4a  movaps [r15+0x1B0], xmm15
000078805cde1b52  lea r14, [rax+0x110]
000078805cde1b59  mov r12, [r13+r14*1]
000078805cde1b5e  lea r14, [rax+0x118]
000078805cde1b65  mov r11, [r13+r14*1]
000078805cde1b6a  movq xmm1, r12
000078805cde1b6f  movq xmm15, r11
000078805cde1b74  movq xmm1, xmm1
000078805cde1b78  movq xmm1, xmm1
000078805cde1b7c  movaps [r15+0x1E0], xmm1
000078805cde1b84  movq xmm15, xmm15
000078805cde1b89  movq xmm15, xmm15
000078805cde1b8e  movaps [r15+0x1D0], xmm15
000078805cde1b96  lea r14, [rax+0x100]
000078805cde1b9d  mov r12, [r13+r14*1]
000078805cde1ba2  lea r14, [rax+0x108]
000078805cde1ba9  mov r11, [r13+r14*1]
000078805cde1bae  movq xmm1, r12
000078805cde1bb3  movq xmm15, r11
000078805cde1bb8  movq xmm1, xmm1
000078805cde1bbc  movq xmm1, xmm1
000078805cde1bc0  movaps [r15+0x200], xmm1
000078805cde1bc8  movq xmm15, xmm15
000078805cde1bcd  movq xmm15, xmm15
000078805cde1bd2  movaps [r15+0x1F0], xmm15
000078805cde1bda  mov qword ptr [r15+0x40], 0x430000
000078805cde1be2  mov r14d, 0x430510
000078805cde1be8  mov r12, [r13+r14*1]
000078805cde1bed  movq xmm1, r12
000078805cde1bf2  lea r14, [rax+0x150]
000078805cde1bf9  mov [r15+0xF8], r14
000078805cde1c00  mov rax, [r15+0x50]
000078805cde1c04  movups xmm15, [r13+rax*1]
000078805cde1c0a  movaps [r15+0x120], xmm15
000078805cde1c12  mov qword ptr [r15+0x48], 0x10
000078805cde1c1a  xor eax, eax
000078805cde1c1c  mov r14d, 0x10
000078805cde1c22  mov r12d, 0x200
000078805cde1c28  cmp r14, r12
000078805cde1c2b  cmc
000078805cde1c2c  lahf
000078805cde1c2d  seto al
000078805cde1c30  mov [r15+0x108], eax
000078805cde1c37  pextrq rax, xmm15, 0x01
000078805cde1c3e  movq xmm14, rax
000078805cde1c43  movaps [r15+0x130], xmm14
000078805cde1c4b  movq rax, xmm1
000078805cde1c50  movq r14, xmm15
000078805cde1c55  vmovq xmm1, rax
000078805cde1c5a  vmovq xmm15, r14
000078805cde1c5f  movaps xmm13, xmm1
000078805cde1c63  addsd xmm13, xmm15
000078805cde1c68  ucomisd xmm13, xmm13
000078805cde1c6d  jp 0x000078805CDE1D86
000078805cde1c73  movq xmm13, xmm13
000078805cde1c78  movq rax, xmm13
000078805cde1c7d  movq r14, xmm14
000078805cde1c82  vmovq xmm1, rax
000078805cde1c87  vmovq xmm15, r14
000078805cde1c8c  movaps xmm14, xmm1
000078805cde1c90  addsd xmm14, xmm15
000078805cde1c95  ucomisd xmm14, xmm14
000078805cde1c9a  jp 0x000078805CDE1DCE
000078805cde1ca0  movq xmm14, xmm14
000078805cde1ca5  movaps [r15+0x110], xmm14
000078805cde1cad  mov eax, [r15+0x108]
000078805cde1cb4  sahf
000078805cde1cb5  jnz 0x000078805CDE1CE7
000078805cde1cb7  cmp dword ptr [r15+0x318], 0x00
000078805cde1cbf  jz 0x000078805CDE1FE0
000078805cde1cc5  nop [rax+rax*1], ax
000078805cde1cce  nop [rax+rax*1], eax
000078805cde1cd6  mov eax, 0x410490
000078805cde1cdb  mov [r15+0x100], rax
000078805cde1ce2  jmp 0x000078805CBFE110
000078805cde1ce7  cmp dword ptr [r15+0x318], 0x00
000078805cde1cef  jz 0x000078805CDE1E20
000078805cde1cf5  nop [rax+rax*1], ax
000078805cde1cfe  nop [rax+rax*1], eax
000078805cde1d06  mov eax, 0x410474
000078805cde1d0b  mov [r15+0x100], rax
000078805cde1d12  jmp 0x000078805CBFE110
000078805cde1d17  int3
000078805cde1d18  call 0x000078805CCE27E0
000078805cde1d1d  jmp 0x000078805CDE1AC3
000078805cde1d22  call 0x000078805CCE27E0
000078805cde1d27  jmp 0x000078805CDE1AD6
000078805cde1d2c  call 0x000078805CCE1570
000078805cde1d31  jmp 0x000078805CDE1AE2
000078805cde1d36  call 0x000078805CCE27E0
000078805cde1d3b  jmp 0x000078805CDE1B1A
000078805cde1d40  call 0x000078805CCE1570
000078805cde1d45  jmp 0x000078805CDE1B26
000078805cde1d4a  call 0x000078805CCE27E0
000078805cde1d4f  jmp 0x000078805CDE1B5E
000078805cde1d54  call 0x000078805CCE1570
000078805cde1d59  jmp 0x000078805CDE1B6A
000078805cde1d5e  call 0x000078805CCE27E0
000078805cde1d63  jmp 0x000078805CDE1BA2
000078805cde1d68  call 0x000078805CCE1570
000078805cde1d6d  jmp 0x000078805CDE1BAE
000078805cde1d72  call 0x000078805CCE27E0
000078805cde1d77  jmp 0x000078805CDE1BED
000078805cde1d7c  call 0x000078805CC0E760
000078805cde1d81  jmp 0x000078805CDE1C0A
000078805cde1d86  ucomisd xmm1, xmm15
000078805cde1d8b  jp 0x000078805CDE1D9A
000078805cde1d8d  movaps xmm13, [0x000078805C9FE060]
000078805cde1d95  jmp 0x000078805CDE1C73
000078805cde1d9a  vxorps xmm0, xmm1, xmm15
000078805cde1d9f  pextrw eax, xmm0, 0x03
000078805cde1da4  and eax, 0x7FF8
000078805cde1da9  cmp eax, 0x08
000078805cde1dac  jnz 0x000078805CDE1C73
000078805cde1db2  movq rax, xmm15
000078805cde1db7  shl rax, 0x0D
000078805cde1dbb  jbe 0x000078805CDE1C73
000078805cde1dc1  vorps xmm13, xmm15, [0x000078805C9FE070]
000078805cde1dc9  jmp 0x000078805CDE1C73
000078805cde1dce  ucomisd xmm1, xmm15
000078805cde1dd3  jp 0x000078805CDE1DE2
000078805cde1dd5  movaps xmm14, [0x000078805C9FE060]
000078805cde1ddd  jmp 0x000078805CDE1CA0
000078805cde1de2  vxorps xmm0, xmm1, xmm15
000078805cde1de7  pextrw eax, xmm0, 0x03
000078805cde1dec  and eax, 0x7FF8
000078805cde1df1  cmp eax, 0x08
000078805cde1df4  jnz 0x000078805CDE1CA0
000078805cde1dfa  movq rax, xmm15
000078805cde1dff  shl rax, 0x0D
000078805cde1e03  jbe 0x000078805CDE1CA0
000078805cde1e09  vorps xmm14, xmm15, [0x000078805C9FE070]
000078805cde1e11  jmp 0x000078805CDE1CA0
000078805cde1e16  int3
000078805cde1e17  nop [rax+rax*1], ax
000078805cde1e20  mov rax, [r15+0x48]
000078805cde1e24  mov r14, [r15+0x50]
000078805cde1e28  lea r12, [r14+rax*1]
000078805cde1e2c  movups xmm1, [r13+r12*1]
000078805cde1e32  movaps [r15+0x120], xmm1
000078805cde1e3a  lea r14, [rax+0x10]
000078805cde1e3e  mov [r15+0x48], r14
000078805cde1e42  xor eax, eax
000078805cde1e44  mov r12d, 0x200
000078805cde1e4a  cmp r14, r12
000078805cde1e4d  cmc
000078805cde1e4e  lahf
000078805cde1e4f  seto al
000078805cde1e52  mov [r15+0x108], eax
000078805cde1e59  pextrq rax, xmm1, 0x01
000078805cde1e60  movq xmm15, rax
000078805cde1e65  movaps [r15+0x130], xmm15
000078805cde1e6d  movaps xmm14, [r15+0x110]
000078805cde1e75  movq rax, xmm14
000078805cde1e7a  movq r14, xmm1
000078805cde1e7f  vmovq xmm1, rax
000078805cde1e84  vmovq xmm14, r14
000078805cde1e89  movaps xmm13, xmm1
000078805cde1e8d  addsd xmm13, xmm14
000078805cde1e92  ucomisd xmm13, xmm13
000078805cde1e97  jp 0x000078805CDE1F4C
000078805cde1e9d  movq xmm13, xmm13
000078805cde1ea2  movq rax, xmm13
000078805cde1ea7  movq r14, xmm15
000078805cde1eac  vmovq xmm1, rax
000078805cde1eb1  vmovq xmm15, r14
000078805cde1eb6  movaps xmm14, xmm1
000078805cde1eba  addsd xmm14, xmm15
000078805cde1ebf  ucomisd xmm14, xmm14
000078805cde1ec4  jp 0x000078805CDE1F94
000078805cde1eca  movq xmm14, xmm14
000078805cde1ecf  movaps [r15+0x110], xmm14
000078805cde1ed7  mov eax, [r15+0x108]
000078805cde1ede  sahf
000078805cde1edf  jnz 0x000078805CDE1F11
000078805cde1ee1  cmp dword ptr [r15+0x318], 0x00
000078805cde1ee9  jz 0x000078805CDE1FE0
000078805cde1eef  nop [rax+rax*1], ax
000078805cde1ef8  nop [rax+rax*1], eax
000078805cde1f00  mov eax, 0x410490
000078805cde1f05  mov [r15+0x100], rax
000078805cde1f0c  jmp 0x000078805CBFE110
000078805cde1f11  cmp dword ptr [r15+0x318], 0x00
000078805cde1f19  jz 0x000078805CDE1E20
000078805cde1f1f  nop [rax+rax*1], ax
000078805cde1f28  nop [rax+rax*1], eax
000078805cde1f30  mov eax, 0x410474
000078805cde1f35  mov [r15+0x100], rax
000078805cde1f3c  jmp 0x000078805CBFE110
000078805cde1f41  int3
000078805cde1f42  call 0x000078805CCB52F0
000078805cde1f47  jmp 0x000078805CDE1E32
000078805cde1f4c  ucomisd xmm1, xmm14
000078805cde1f51  jp 0x000078805CDE1F60
000078805cde1f53  movaps xmm13, [0x000078805C9FE060]
000078805cde1f5b  jmp 0x000078805CDE1E9D
000078805cde1f60  vxorps xmm0, xmm1, xmm14
000078805cde1f65  pextrw eax, xmm0, 0x03
000078805cde1f6a  and eax, 0x7FF8
000078805cde1f6f  cmp eax, 0x08
000078805cde1f72  jnz 0x000078805CDE1E9D
000078805cde1f78  movq rax, xmm14
000078805cde1f7d  shl rax, 0x0D
000078805cde1f81  jbe 0x000078805CDE1E9D
000078805cde1f87  vorps xmm13, xmm14, [0x000078805C9FE070]
000078805cde1f8f  jmp 0x000078805CDE1E9D
000078805cde1f94  ucomisd xmm1, xmm15
000078805cde1f99  jp 0x000078805CDE1FA8
000078805cde1f9b  movaps xmm14, [0x000078805C9FE060]
000078805cde1fa3  jmp 0x000078805CDE1ECA
000078805cde1fa8  vxorps xmm0, xmm1, xmm15
000078805cde1fad  pextrw eax, xmm0, 0x03
000078805cde1fb2  and eax, 0x7FF8
000078805cde1fb7  cmp eax, 0x08
000078805cde1fba  jnz 0x000078805CDE1ECA
000078805cde1fc0  movq rax, xmm15
000078805cde1fc5  shl rax, 0x0D
000078805cde1fc9  jbe 0x000078805CDE1ECA
000078805cde1fcf  vorps xmm14, xmm15, [0x000078805C9FE070]
000078805cde1fd7  jmp 0x000078805CDE1ECA
000078805cde1fdc  int3
000078805cde1fdd  nop [rax], eax
000078805cde1fe0  mov rax, [r15+0x40]
000078805cde1fe4  lea r14, [rax+0x510]
000078805cde1feb  movaps xmm1, [r15+0x110]
000078805cde1ff3  movq rax, xmm1
000078805cde1ff8  mov [r13+r14*1], rax
000078805cde1ffd  mov rax, [r15+0xF0]
000078805cde2004  mov [r15+0x100], rax
000078805cde200b  jmp 0x000078805CDCE5C0
000078805cde2010  int3
000078805cde2011  call 0x000078805CCD5EB0
000078805cde2016  jmp 0x000078805CDE1FFD
000078805cde201b  int3
000078805cde201c  nop [rax], eax
000078805cde2020  mov qword ptr [r15+0x100], 0x04
000078805cde202b  mov esi, 0x00
000078805cde2030  mov edx, 0x09
000078805cde2035  mov rdi, 0x7FFE08EC6C60
000078805cde203f  mov rax, 0x5771AD57D970
000078805cde2049  call rax
000078805cde204b  cmp dword ptr [r15+0x318], 0x00
000078805cde2053  jnz 0x000078805CBFE110
000078805cde2059  jmp 0x000078805CBFE0A0
000078805cde205e  int3
000078805cde205f  int3
