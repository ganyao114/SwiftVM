000074fc937ce69b  nop [rax+rax*1], eax
000074fc937ce6a0  vmovaps xmm1, [0x000074FC933FE010]
000074fc937ce6a8  movq xmm1, xmm1
000074fc937ce6ac  movaps [r15+0x110], xmm1
000074fc937ce6b4  vmovaps xmm1, [0x000074FC933FE020]
000074fc937ce6bc  movq xmm1, xmm1
000074fc937ce6c0  movaps [r15+0x120], xmm1
000074fc937ce6c8  mov eax, 0x4204C0
000074fc937ce6cd  mov r14, [r13+rax*1]
000074fc937ce6d2  movq xmm1, r14
000074fc937ce6d7  movaps [r15+0x130], xmm1
000074fc937ce6df  vmovaps xmm1, [0x000074FC933FE030]
000074fc937ce6e7  vpbroadcastq xmm1, xmm1
000074fc937ce6ec  movaps [r15+0x140], xmm1
000074fc937ce6f4  mov qword ptr [r15+0x40], 0x02
000074fc937ce6fc  vmovaps xmm15, [0x000074FC933FE040]
000074fc937ce704  movq xmm15, xmm15
000074fc937ce709  movaps [r15+0x150], xmm15
000074fc937ce711  mov qword ptr [r15+0x58], 0x420000
000074fc937ce719  vmovaps xmm15, [0x000074FC933FE050]
000074fc937ce721  vpbroadcastq xmm15, xmm15
000074fc937ce726  movaps [r15+0x160], xmm15
000074fc937ce72e  mov rax, [r15+0x40]
000074fc937ce732  vmovq xmm14, rax
000074fc937ce737  vpbroadcastq xmm14, xmm14
000074fc937ce73c  movaps [r15+0x170], xmm14
000074fc937ce744  mov eax, 0x4204D0
000074fc937ce749  movups xmm13, [r13+rax*1]
000074fc937ce74f  mov qword ptr [r15+0x40], 0x430518
000074fc937ce757  mov qword ptr [r15+0x50], 0x430720
000074fc937ce75f  vpmovqd xmm12, xmm13
000074fc937ce765  pxor xmm11, xmm11
000074fc937ce76a  punpcklqdq xmm12, xmm11
000074fc937ce76f  movaps [r15+0x210], xmm12
000074fc937ce777  movq xmm12, qword ptr [r15+0x120]
000074fc937ce780  movq xmm11, qword ptr [r15+0x130]
000074fc937ce789  psubd xmm12, xmm11
000074fc937ce78e  movq xmm12, xmm12
000074fc937ce793  paddq xmm13, xmm14
000074fc937ce798  movaps [r15+0x180], xmm13
000074fc937ce7a0  movq xmm14, qword ptr [r15+0x150]
000074fc937ce7a9  paddd xmm11, xmm14
000074fc937ce7ae  movq xmm11, xmm11
000074fc937ce7b3  movq xmm11, xmm11
000074fc937ce7b8  movaps [r15+0x130], xmm11
000074fc937ce7c0  pmovzxdq xmm12, xmm12
000074fc937ce7c6  psllq xmm12, 0x00
000074fc937ce7cc  movq xmm14, qword ptr [r15+0x210]
000074fc937ce7d5  movq xmm13, qword ptr [r15+0x110]
000074fc937ce7de  paddd xmm14, xmm13
000074fc937ce7e3  movq xmm14, xmm14
000074fc937ce7e8  vcvtuqq2pd xmm12, xmm12
000074fc937ce7ee  pmovzxdq xmm14, xmm14
000074fc937ce7f4  psllq xmm14, 0x00
000074fc937ce7fa  vcvtuqq2pd xmm14, xmm14
000074fc937ce800  movaps xmm13, xmm12
000074fc937ce804  mulpd xmm13, xmm1
000074fc937ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000074fc937ce80f  ptest xmm11, xmm11
000074fc937ce815  jnz 0x000074FC937CE8FF
000074fc937ce81b  movaps [r15+0x220], xmm13
000074fc937ce823  mov eax, 0x430720
000074fc937ce828  movups [r13+rax*1], xmm13
000074fc937ce82e  movaps xmm1, xmm14
000074fc937ce832  mulpd xmm1, xmm15
000074fc937ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000074fc937ce83c  ptest xmm13, xmm13
000074fc937ce842  jnz 0x000074FC937CEA4C
000074fc937ce848  movaps [r15+0x210], xmm1
000074fc937ce850  mov eax, 0x430518
000074fc937ce855  movups [r13+rax*1], xmm1
000074fc937ce85b  mov qword ptr [r15+0x48], 0x10
000074fc937ce863  xor eax, eax
000074fc937ce865  mov r14d, 0x10
000074fc937ce86b  mov r12d, 0x200
000074fc937ce871  cmp r14, r12
000074fc937ce874  cmc
000074fc937ce875  lahf
000074fc937ce876  seto al
000074fc937ce879  mov [r15+0x108], eax
000074fc937ce880  mov eax, [r15+0x108]
000074fc937ce887  sahf
000074fc937ce888  jnz 0x000074FC937CE8BA
000074fc937ce88a  cmp dword ptr [r15+0x318], 0x00
000074fc937ce892  jz 0x000074FC937CEFF0
000074fc937ce898  nop [rax+rax*1], ax
000074fc937ce8a1  nop [rax+rax*1], eax
000074fc937ce8a9  mov eax, 0x4101EC
000074fc937ce8ae  mov [r15+0x100], rax
000074fc937ce8b5  jmp 0x000074FC935FE110
000074fc937ce8ba  cmp dword ptr [r15+0x318], 0x00
000074fc937ce8c2  jz 0x000074FC937CEBA0
000074fc937ce8c8  nop [rax+rax*1], ax
000074fc937ce8d1  nop [rax+rax*1], eax
000074fc937ce8d9  mov eax, 0x4101AC
000074fc937ce8de  mov [r15+0x100], rax
000074fc937ce8e5  jmp 0x000074FC935FE110
000074fc937ce8ea  int3
000074fc937ce8eb  call 0x000074FC9360DC20
000074fc937ce8f0  jmp 0x000074FC937CE6D2
000074fc937ce8f5  call 0x000074FC9360C260
000074fc937ce8fa  jmp 0x000074FC937CE74F
000074fc937ce8ff  sub rsp, 0x08
000074fc937ce903  push rax
000074fc937ce904  push rcx
000074fc937ce905  push rdx
000074fc937ce906  push rdi
000074fc937ce907  push rsi
000074fc937ce908  push r8
000074fc937ce90a  push r9
000074fc937ce90c  push r10
000074fc937ce90e  push r11
000074fc937ce910  sub rsp, 0xF0
000074fc937ce917  vmovaps [rsp], xmm0
000074fc937ce91c  vmovaps [rsp+0x10], xmm1
000074fc937ce922  vmovaps [rsp+0x20], xmm2
000074fc937ce928  vmovaps [rsp+0x30], xmm3
000074fc937ce92e  vmovaps [rsp+0x40], xmm4
000074fc937ce934  vmovaps [rsp+0x50], xmm5
000074fc937ce93a  vmovaps [rsp+0x60], xmm6
000074fc937ce940  vmovaps [rsp+0x70], xmm7
000074fc937ce946  vmovaps [rsp+0x80], xmm8
000074fc937ce94f  vmovaps [rsp+0x90], xmm9
000074fc937ce958  vmovaps [rsp+0xA0], xmm10
000074fc937ce961  vmovaps [rsp+0xB0], xmm11
000074fc937ce96a  vmovaps [rsp+0xC0], xmm12
000074fc937ce973  vmovaps [rsp+0xD0], xmm14
000074fc937ce97c  vmovaps [rsp+0xE0], xmm15
000074fc937ce985  sub rsp, 0x30
000074fc937ce989  movaps [rsp], xmm13
000074fc937ce98e  movaps [rsp+0x10], xmm12
000074fc937ce994  movaps [rsp+0x20], xmm1
000074fc937ce999  lea rdi, [rsp]
000074fc937ce99d  mov esi, 0x00
000074fc937ce9a2  mov rax, 0x5D72CBC20530
000074fc937ce9ac  call rax
000074fc937ce9ae  movaps xmm13, [rsp]
000074fc937ce9b3  add rsp, 0x30
000074fc937ce9b7  vmovaps xmm0, [rsp]
000074fc937ce9bc  vmovaps xmm1, [rsp+0x10]
000074fc937ce9c2  vmovaps xmm2, [rsp+0x20]
000074fc937ce9c8  vmovaps xmm3, [rsp+0x30]
000074fc937ce9ce  vmovaps xmm4, [rsp+0x40]
000074fc937ce9d4  vmovaps xmm5, [rsp+0x50]
000074fc937ce9da  vmovaps xmm6, [rsp+0x60]
000074fc937ce9e0  vmovaps xmm7, [rsp+0x70]
000074fc937ce9e6  vmovaps xmm8, [rsp+0x80]
000074fc937ce9ef  vmovaps xmm9, [rsp+0x90]
000074fc937ce9f8  vmovaps xmm10, [rsp+0xA0]
000074fc937cea01  vmovaps xmm11, [rsp+0xB0]
000074fc937cea0a  vmovaps xmm12, [rsp+0xC0]
000074fc937cea13  vmovaps xmm14, [rsp+0xD0]
000074fc937cea1c  vmovaps xmm15, [rsp+0xE0]
000074fc937cea25  add rsp, 0xF0
000074fc937cea2c  pop r11
000074fc937cea2e  pop r10
000074fc937cea30  pop r9
000074fc937cea32  pop r8
000074fc937cea34  pop rsi
000074fc937cea35  pop rdi
000074fc937cea36  pop rdx
000074fc937cea37  pop rcx
000074fc937cea38  pop rax
000074fc937cea39  add rsp, 0x08
000074fc937cea3d  jmp 0x000074FC937CE81B
000074fc937cea42  call 0x000074FC9360C380
000074fc937cea47  jmp 0x000074FC937CE82E
000074fc937cea4c  sub rsp, 0x08
000074fc937cea50  push rax
000074fc937cea51  push rcx
000074fc937cea52  push rdx
000074fc937cea53  push rdi
000074fc937cea54  push rsi
000074fc937cea55  push r8
000074fc937cea57  push r9
000074fc937cea59  push r10
000074fc937cea5b  push r11
000074fc937cea5d  sub rsp, 0xF0
000074fc937cea64  vmovaps [rsp], xmm0
000074fc937cea69  vmovaps [rsp+0x10], xmm2
000074fc937cea6f  vmovaps [rsp+0x20], xmm3
000074fc937cea75  vmovaps [rsp+0x30], xmm4
000074fc937cea7b  vmovaps [rsp+0x40], xmm5
000074fc937cea81  vmovaps [rsp+0x50], xmm6
000074fc937cea87  vmovaps [rsp+0x60], xmm7
000074fc937cea8d  vmovaps [rsp+0x70], xmm8
000074fc937cea93  vmovaps [rsp+0x80], xmm9
000074fc937cea9c  vmovaps [rsp+0x90], xmm10
000074fc937ceaa5  vmovaps [rsp+0xA0], xmm11
000074fc937ceaae  vmovaps [rsp+0xB0], xmm12
000074fc937ceab7  vmovaps [rsp+0xC0], xmm13
000074fc937ceac0  vmovaps [rsp+0xD0], xmm14
000074fc937ceac9  vmovaps [rsp+0xE0], xmm15
000074fc937cead2  sub rsp, 0x30
000074fc937cead6  movaps [rsp], xmm1
000074fc937ceada  movaps [rsp+0x10], xmm14
000074fc937ceae0  movaps [rsp+0x20], xmm15
000074fc937ceae6  lea rdi, [rsp]
000074fc937ceaea  mov esi, 0x00
000074fc937ceaef  mov rax, 0x5D72CBC20530
000074fc937ceaf9  call rax
000074fc937ceafb  movaps xmm1, [rsp]
000074fc937ceaff  add rsp, 0x30
000074fc937ceb03  vmovaps xmm0, [rsp]
000074fc937ceb08  vmovaps xmm2, [rsp+0x10]
000074fc937ceb0e  vmovaps xmm3, [rsp+0x20]
000074fc937ceb14  vmovaps xmm4, [rsp+0x30]
000074fc937ceb1a  vmovaps xmm5, [rsp+0x40]
000074fc937ceb20  vmovaps xmm6, [rsp+0x50]
000074fc937ceb26  vmovaps xmm7, [rsp+0x60]
000074fc937ceb2c  vmovaps xmm8, [rsp+0x70]
000074fc937ceb32  vmovaps xmm9, [rsp+0x80]
000074fc937ceb3b  vmovaps xmm10, [rsp+0x90]
000074fc937ceb44  vmovaps xmm11, [rsp+0xA0]
000074fc937ceb4d  vmovaps xmm12, [rsp+0xB0]
000074fc937ceb56  vmovaps xmm13, [rsp+0xC0]
000074fc937ceb5f  vmovaps xmm14, [rsp+0xD0]
000074fc937ceb68  vmovaps xmm15, [rsp+0xE0]
000074fc937ceb71  add rsp, 0xF0
000074fc937ceb78  pop r11
000074fc937ceb7a  pop r10
000074fc937ceb7c  pop r9
000074fc937ceb7e  pop r8
000074fc937ceb80  pop rsi
000074fc937ceb81  pop rdi
000074fc937ceb82  pop rdx
000074fc937ceb83  pop rcx
000074fc937ceb84  pop rax
000074fc937ceb85  add rsp, 0x08
000074fc937ceb89  jmp 0x000074FC937CE848
000074fc937ceb8e  call 0x000074FC935FF540
000074fc937ceb93  jmp 0x000074FC937CE85B
000074fc937ceb98  int3
000074fc937ceb99  nop [rax], eax
000074fc937ceba0  movaps xmm1, [r15+0x180]
000074fc937ceba8  vpmovqd xmm15, xmm1
000074fc937cebae  pxor xmm14, xmm14
000074fc937cebb3  punpcklqdq xmm15, xmm14
000074fc937cebb8  movaps [r15+0x210], xmm15
000074fc937cebc0  movq xmm15, qword ptr [r15+0x120]
000074fc937cebc9  movq xmm14, qword ptr [r15+0x130]
000074fc937cebd2  psubd xmm15, xmm14
000074fc937cebd7  movq xmm15, xmm15
000074fc937cebdc  movaps xmm13, [r15+0x170]
000074fc937cebe4  paddq xmm1, xmm13
000074fc937cebe9  movaps [r15+0x180], xmm1
000074fc937cebf1  movq xmm1, qword ptr [r15+0x150]
000074fc937cebfa  paddd xmm14, xmm1
000074fc937cebff  movq xmm14, xmm14
000074fc937cec04  movq xmm14, xmm14
000074fc937cec09  movaps [r15+0x130], xmm14
000074fc937cec11  pmovzxdq xmm15, xmm15
000074fc937cec17  psllq xmm15, 0x00
000074fc937cec1d  movq xmm1, qword ptr [r15+0x210]
000074fc937cec26  movq xmm14, qword ptr [r15+0x110]
000074fc937cec2f  paddd xmm1, xmm14
000074fc937cec34  movq xmm1, xmm1
000074fc937cec38  vcvtuqq2pd xmm15, xmm15
000074fc937cec3e  pmovzxdq xmm1, xmm1
000074fc937cec43  psllq xmm1, 0x00
000074fc937cec48  vcvtuqq2pd xmm1, xmm1
000074fc937cec4e  movaps xmm14, [r15+0x140]
000074fc937cec56  movaps xmm13, xmm15
000074fc937cec5a  mulpd xmm13, xmm14
000074fc937cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc937cec65  ptest xmm12, xmm12
000074fc937cec6b  jnz 0x000074FC937CED4E
000074fc937cec71  movaps [r15+0x220], xmm13
000074fc937cec79  mov rax, [r15+0x48]
000074fc937cec7d  mov r14, [r15+0x50]
000074fc937cec81  lea r12, [r14+rax*1]
000074fc937cec85  movups [r13+r12*1], xmm13
000074fc937cec8b  movaps xmm15, [r15+0x160]
000074fc937cec93  movaps xmm14, xmm1
000074fc937cec97  mulpd xmm14, xmm15
000074fc937cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000074fc937ceca2  ptest xmm13, xmm13
000074fc937ceca8  jnz 0x000074FC937CEE9C
000074fc937cecae  movaps [r15+0x210], xmm14
000074fc937cecb6  mov r14, [r15+0x40]
000074fc937cecba  lea r12, [r14+rax*1]
000074fc937cecbe  movups [r13+r12*1], xmm14
000074fc937cecc4  lea r14, [rax+0x10]
000074fc937cecc8  mov [r15+0x48], r14
000074fc937ceccc  xor eax, eax
000074fc937cecce  mov r12d, 0x200
000074fc937cecd4  cmp r14, r12
000074fc937cecd7  cmc
000074fc937cecd8  lahf
000074fc937cecd9  seto al
000074fc937cecdc  mov [r15+0x108], eax
000074fc937cece3  mov eax, [r15+0x108]
000074fc937cecea  sahf
000074fc937ceceb  jnz 0x000074FC937CED1D
000074fc937ceced  cmp dword ptr [r15+0x318], 0x00
000074fc937cecf5  jz 0x000074FC937CEFF0
000074fc937cecfb  nop [rax+rax*1], ax
000074fc937ced04  nop [rax+rax*1], eax
000074fc937ced0c  mov eax, 0x4101EC
000074fc937ced11  mov [r15+0x100], rax
000074fc937ced18  jmp 0x000074FC935FE110
000074fc937ced1d  cmp dword ptr [r15+0x318], 0x00
000074fc937ced25  jz 0x000074FC937CEBA0
000074fc937ced2b  nop [rax+rax*1], ax
000074fc937ced34  nop [rax+rax*1], eax
000074fc937ced3c  mov eax, 0x4101AC
000074fc937ced41  mov [r15+0x100], rax
000074fc937ced48  jmp 0x000074FC935FE110
000074fc937ced4d  int3
000074fc937ced4e  sub rsp, 0x08
000074fc937ced52  push rax
000074fc937ced53  push rcx
000074fc937ced54  push rdx
000074fc937ced55  push rdi
000074fc937ced56  push rsi
000074fc937ced57  push r8
000074fc937ced59  push r9
000074fc937ced5b  push r10
000074fc937ced5d  push r11
000074fc937ced5f  sub rsp, 0xF0
000074fc937ced66  vmovaps [rsp], xmm0
000074fc937ced6b  vmovaps [rsp+0x10], xmm1
000074fc937ced71  vmovaps [rsp+0x20], xmm2
000074fc937ced77  vmovaps [rsp+0x30], xmm3
000074fc937ced7d  vmovaps [rsp+0x40], xmm4
000074fc937ced83  vmovaps [rsp+0x50], xmm5
000074fc937ced89  vmovaps [rsp+0x60], xmm6
000074fc937ced8f  vmovaps [rsp+0x70], xmm7
000074fc937ced95  vmovaps [rsp+0x80], xmm8
000074fc937ced9e  vmovaps [rsp+0x90], xmm9
000074fc937ceda7  vmovaps [rsp+0xA0], xmm10
000074fc937cedb0  vmovaps [rsp+0xB0], xmm11
000074fc937cedb9  vmovaps [rsp+0xC0], xmm12
000074fc937cedc2  vmovaps [rsp+0xD0], xmm14
000074fc937cedcb  vmovaps [rsp+0xE0], xmm15
000074fc937cedd4  sub rsp, 0x30
000074fc937cedd8  movaps [rsp], xmm13
000074fc937ceddd  movaps [rsp+0x10], xmm15
000074fc937cede3  movaps [rsp+0x20], xmm14
000074fc937cede9  lea rdi, [rsp]
000074fc937ceded  mov esi, 0x00
000074fc937cedf2  mov rax, 0x5D72CBC20530
000074fc937cedfc  call rax
000074fc937cedfe  movaps xmm13, [rsp]
000074fc937cee03  add rsp, 0x30
000074fc937cee07  vmovaps xmm0, [rsp]
000074fc937cee0c  vmovaps xmm1, [rsp+0x10]
000074fc937cee12  vmovaps xmm2, [rsp+0x20]
000074fc937cee18  vmovaps xmm3, [rsp+0x30]
000074fc937cee1e  vmovaps xmm4, [rsp+0x40]
000074fc937cee24  vmovaps xmm5, [rsp+0x50]
000074fc937cee2a  vmovaps xmm6, [rsp+0x60]
000074fc937cee30  vmovaps xmm7, [rsp+0x70]
000074fc937cee36  vmovaps xmm8, [rsp+0x80]
000074fc937cee3f  vmovaps xmm9, [rsp+0x90]
000074fc937cee48  vmovaps xmm10, [rsp+0xA0]
000074fc937cee51  vmovaps xmm11, [rsp+0xB0]
000074fc937cee5a  vmovaps xmm12, [rsp+0xC0]
000074fc937cee63  vmovaps xmm14, [rsp+0xD0]
000074fc937cee6c  vmovaps xmm15, [rsp+0xE0]
000074fc937cee75  add rsp, 0xF0
000074fc937cee7c  pop r11
000074fc937cee7e  pop r10
000074fc937cee80  pop r9
000074fc937cee82  pop r8
000074fc937cee84  pop rsi
000074fc937cee85  pop rdi
000074fc937cee86  pop rdx
000074fc937cee87  pop rcx
000074fc937cee88  pop rax
000074fc937cee89  add rsp, 0x08
000074fc937cee8d  jmp 0x000074FC937CEC71
000074fc937cee92  call 0x000074FC936C2240
000074fc937cee97  jmp 0x000074FC937CEC8B
000074fc937cee9c  sub rsp, 0x08
000074fc937ceea0  push rax
000074fc937ceea1  push rcx
000074fc937ceea2  push rdx
000074fc937ceea3  push rdi
000074fc937ceea4  push rsi
000074fc937ceea5  push r8
000074fc937ceea7  push r9
000074fc937ceea9  push r10
000074fc937ceeab  push r11
000074fc937ceead  sub rsp, 0xF0
000074fc937ceeb4  vmovaps [rsp], xmm0
000074fc937ceeb9  vmovaps [rsp+0x10], xmm1
000074fc937ceebf  vmovaps [rsp+0x20], xmm2
000074fc937ceec5  vmovaps [rsp+0x30], xmm3
000074fc937ceecb  vmovaps [rsp+0x40], xmm4
000074fc937ceed1  vmovaps [rsp+0x50], xmm5
000074fc937ceed7  vmovaps [rsp+0x60], xmm6
000074fc937ceedd  vmovaps [rsp+0x70], xmm7
000074fc937ceee3  vmovaps [rsp+0x80], xmm8
000074fc937ceeec  vmovaps [rsp+0x90], xmm9
000074fc937ceef5  vmovaps [rsp+0xA0], xmm10
000074fc937ceefe  vmovaps [rsp+0xB0], xmm11
000074fc937cef07  vmovaps [rsp+0xC0], xmm12
000074fc937cef10  vmovaps [rsp+0xD0], xmm13
000074fc937cef19  vmovaps [rsp+0xE0], xmm15
000074fc937cef22  sub rsp, 0x30
000074fc937cef26  movaps [rsp], xmm14
000074fc937cef2b  movaps [rsp+0x10], xmm1
000074fc937cef30  movaps [rsp+0x20], xmm15
000074fc937cef36  lea rdi, [rsp]
000074fc937cef3a  mov esi, 0x00
000074fc937cef3f  mov rax, 0x5D72CBC20530
000074fc937cef49  call rax
000074fc937cef4b  movaps xmm14, [rsp]
000074fc937cef50  add rsp, 0x30
000074fc937cef54  vmovaps xmm0, [rsp]
000074fc937cef59  vmovaps xmm1, [rsp+0x10]
000074fc937cef5f  vmovaps xmm2, [rsp+0x20]
000074fc937cef65  vmovaps xmm3, [rsp+0x30]
000074fc937cef6b  vmovaps xmm4, [rsp+0x40]
000074fc937cef71  vmovaps xmm5, [rsp+0x50]
000074fc937cef77  vmovaps xmm6, [rsp+0x60]
000074fc937cef7d  vmovaps xmm7, [rsp+0x70]
000074fc937cef83  vmovaps xmm8, [rsp+0x80]
000074fc937cef8c  vmovaps xmm9, [rsp+0x90]
000074fc937cef95  vmovaps xmm10, [rsp+0xA0]
000074fc937cef9e  vmovaps xmm11, [rsp+0xB0]
000074fc937cefa7  vmovaps xmm12, [rsp+0xC0]
000074fc937cefb0  vmovaps xmm13, [rsp+0xD0]
000074fc937cefb9  vmovaps xmm15, [rsp+0xE0]
000074fc937cefc2  add rsp, 0xF0
000074fc937cefc9  pop r11
000074fc937cefcb  pop r10
000074fc937cefcd  pop r9
000074fc937cefcf  pop r8
000074fc937cefd1  pop rsi
000074fc937cefd2  pop rdi
000074fc937cefd3  pop rdx
000074fc937cefd4  pop rcx
000074fc937cefd5  pop rax
000074fc937cefd6  add rsp, 0x08
000074fc937cefda  jmp 0x000074FC937CECAE
000074fc937cefdf  call 0x000074FC936C34C0
000074fc937cefe4  jmp 0x000074FC937CECC4
000074fc937cefe9  int3
000074fc937cefea  nop [rax+rax*1], ax
000074fc937ceff0  mov rax, [r15+0xF8]
000074fc937ceff7  lea r14, [rax-0x150]
000074fc937ceffe  mov [r15+0xF8], r14
000074fc937cf005  mov rax, [r15+0x50]
000074fc937cf009  lea r12, [rax+0x80]
000074fc937cf010  movups xmm1, [r13+r12*1]
000074fc937cf016  lea r12, [rax+0x90]
000074fc937cf01d  movups xmm15, [r13+r12*1]
000074fc937cf023  mov qword ptr [r15+0x48], 0x00
000074fc937cf02b  lea r12, [rax+0x40]
000074fc937cf02f  movups xmm14, [r13+r12*1]
000074fc937cf035  lea r12, [rax+0x50]
000074fc937cf039  movups xmm13, [r13+r12*1]
000074fc937cf03f  lea r12, [r14+0x120]
000074fc937cf046  movq xmm12, qword ptr [r15+0x1C0]
000074fc937cf04f  movq xmm11, qword ptr [r15+0x1B0]
000074fc937cf058  movq r11, xmm12
000074fc937cf05d  movq r10, xmm11
000074fc937cf062  mov [r13+r12*1], r11
000074fc937cf067  lea r12, [r14+0x128]
000074fc937cf06e  mov [r13+r12*1], r10
000074fc937cf073  vxorps xmm12, xmm12, xmm12
000074fc937cf078  vpbroadcastq xmm12, xmm12
000074fc937cf07d  lea r12, [r14+0x100]
000074fc937cf084  movq xmm11, qword ptr [r15+0x200]
000074fc937cf08d  movq xmm10, qword ptr [r15+0x1F0]
000074fc937cf096  movq r11, xmm11
000074fc937cf09b  movq r10, xmm10
000074fc937cf0a0  mov [r13+r12*1], r11
000074fc937cf0a5  lea r12, [r14+0x108]
000074fc937cf0ac  mov [r13+r12*1], r10
000074fc937cf0b1  lea r12, [r14+0xE0]
000074fc937cf0b8  movups [r13+r12*1], xmm15
000074fc937cf0be  lea r12, [r14+0xF0]
000074fc937cf0c5  movups [r13+r12*1], xmm1
000074fc937cf0cb  lea r12, [rax+0xC0]
000074fc937cf0d2  movups xmm1, [r13+r12*1]
000074fc937cf0d8  lea r12, [rax+0xD0]
000074fc937cf0df  movups xmm15, [r13+r12*1]
000074fc937cf0e5  lea r12, [r14+0x110]
000074fc937cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000074fc937cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000074fc937cf0fe  movq r11, xmm11
000074fc937cf103  movq r10, xmm10
000074fc937cf108  mov [r13+r12*1], r11
000074fc937cf10d  lea r12, [r14+0x118]
000074fc937cf114  mov [r13+r12*1], r10
000074fc937cf119  movups xmm11, [r13+rax*1]
000074fc937cf11f  lea r12, [rax+0x10]
000074fc937cf123  movups xmm10, [r13+r12*1]
000074fc937cf129  lea r12, [r14+0x130]
000074fc937cf130  movq xmm9, qword ptr [r15+0x1A0]
000074fc937cf139  movq xmm8, qword ptr [r15+0x190]
000074fc937cf142  movq r11, xmm9
000074fc937cf147  movq r10, xmm8
000074fc937cf14c  mov [r13+r12*1], r11
000074fc937cf151  lea r12, [r14+0x138]
000074fc937cf158  mov [r13+r12*1], r10
000074fc937cf15d  lea r12, [rax+0x140]
000074fc937cf164  movups xmm9, [r13+r12*1]
000074fc937cf16a  lea r12, [rax+0x150]
000074fc937cf171  movups xmm8, [r13+r12*1]
000074fc937cf177  lea r12, [r14+0xC0]
000074fc937cf17e  movups [r13+r12*1], xmm15
000074fc937cf184  lea r12, [r14+0xD0]
000074fc937cf18b  movups [r13+r12*1], xmm1
000074fc937cf191  lea r12, [rax+0x100]
000074fc937cf198  movups xmm1, [r13+r12*1]
000074fc937cf19e  lea r12, [rax+0x110]
000074fc937cf1a5  movups xmm15, [r13+r12*1]
000074fc937cf1ab  lea r12, [r14+0x140]
000074fc937cf1b2  mov r11, [r15+0xE8]
000074fc937cf1b9  mov [r13+r12*1], r11
000074fc937cf1be  lea r12, [rax+0x180]
000074fc937cf1c5  movups xmm7, [r13+r12*1]
000074fc937cf1cb  lea r12, [rax+0x190]
000074fc937cf1d2  movups xmm6, [r13+r12*1]
000074fc937cf1d8  lea r12, [rax+0x1C0]
000074fc937cf1df  movups xmm5, [r13+r12*1]
000074fc937cf1e5  lea r12, [rax+0x1D0]
000074fc937cf1ec  movups xmm4, [r13+r12*1]
000074fc937cf1f2  lea r12, [r14+0x20]
000074fc937cf1f6  movups [r13+r12*1], xmm1
000074fc937cf1fc  lea r12, [r14+0x30]
000074fc937cf200  movups [r13+r12*1], xmm13
000074fc937cf206  lea r12, [rax+0x60]
000074fc937cf20a  movups xmm1, [r13+r12*1]
000074fc937cf210  lea r12, [rax+0x70]
000074fc937cf214  movups xmm13, [r13+r12*1]
000074fc937cf21a  lea r12, [rax+0x20]
000074fc937cf21e  movups xmm3, [r13+r12*1]
000074fc937cf224  lea r12, [rax+0x30]
000074fc937cf228  movups xmm2, [r13+r12*1]
000074fc937cf22e  movaps [r15+0x1F0], xmm2
000074fc937cf236  lea r12, [r14+0x60]
000074fc937cf23a  movups [r13+r12*1], xmm11
000074fc937cf240  lea r12, [r14+0x70]
000074fc937cf244  movups [r13+r12*1], xmm5
000074fc937cf24a  lea r12, [rax+0xE0]
000074fc937cf251  movups xmm11, [r13+r12*1]
000074fc937cf257  lea r12, [rax+0xF0]
000074fc937cf25e  movups xmm5, [r13+r12*1]
000074fc937cf264  lea r12, [r14+0xA0]
000074fc937cf26b  movups [r13+r12*1], xmm13
000074fc937cf271  lea r12, [r14+0xB0]
000074fc937cf278  movups [r13+r12*1], xmm1
000074fc937cf27e  lea r12, [rax+0xA0]
000074fc937cf285  movups xmm1, [r13+r12*1]
000074fc937cf28b  lea r12, [rax+0xB0]
000074fc937cf292  movups xmm13, [r13+r12*1]
000074fc937cf298  lea r12, [rax+0x120]
000074fc937cf29f  vmovaps [rsp+0x10], xmm1
000074fc937cf2a5  movups xmm1, [r13+r12*1]
000074fc937cf2ab  lea r12, [rax+0x130]
000074fc937cf2b2  vmovaps [rsp+0x20], xmm1
000074fc937cf2b8  movups xmm1, [r13+r12*1]
000074fc937cf2be  lea r12, [rax+0x160]
000074fc937cf2c5  vmovaps [rsp+0x30], xmm1
000074fc937cf2cb  movups xmm1, [r13+r12*1]
000074fc937cf2d1  lea r12, [rax+0x170]
000074fc937cf2d8  vmovaps [rsp+0x40], xmm1
000074fc937cf2de  movups xmm1, [r13+r12*1]
000074fc937cf2e4  movaps [r15+0x2B0], xmm1
000074fc937cf2ec  lea r12, [r14+0x80]
000074fc937cf2f3  movups [r13+r12*1], xmm13
000074fc937cf2f9  lea r12, [r14+0x90]
000074fc937cf300  vmovaps xmm13, [rsp+0x10]
000074fc937cf306  movups [r13+r12*1], xmm13
000074fc937cf30c  lea r12, [rax+0x1A0]
000074fc937cf313  movups xmm13, [r13+r12*1]
000074fc937cf319  lea r12, [rax+0x1B0]
000074fc937cf320  vmovaps [rsp+0x10], xmm1
000074fc937cf326  movups xmm1, [r13+r12*1]
000074fc937cf32c  movaps [r15+0x290], xmm13
000074fc937cf334  movaps [r15+0x1E0], xmm1
000074fc937cf33c  lea r12, [rax+0x1E0]
000074fc937cf343  vmovaps [rsp+0x50], xmm1
000074fc937cf349  movups xmm1, [r13+r12*1]
000074fc937cf34f  lea r12, [rax+0x1F0]
000074fc937cf356  vmovaps [rsp+0x60], xmm1
000074fc937cf35c  movups xmm1, [r13+r12*1]
000074fc937cf362  mov qword ptr [r15+0x50], 0x430920
000074fc937cf36a  lea rax, [r14+0x40]
000074fc937cf36e  vmovaps [rsp+0x70], xmm1
000074fc937cf374  vmovaps xmm1, [rsp+0x40]
000074fc937cf37a  movups [r13+rax*1], xmm1
000074fc937cf380  lea rax, [r14+0x50]
000074fc937cf384  movups [r13+rax*1], xmm10
000074fc937cf38a  vmovaps xmm1, [rsp+0x70]
000074fc937cf390  movups [r13+r14*1], xmm1
000074fc937cf396  lea rax, [r14+0x10]
000074fc937cf39a  vmovaps xmm1, [rsp+0x60]
000074fc937cf3a0  movups [r13+rax*1], xmm1
000074fc937cf3a6  mov rax, [r15+0x40]
000074fc937cf3aa  vmovaps [rsp+0x40], xmm3
000074fc937cf3b0  vmovaps xmm1, [rsp+0x40]
000074fc937cf3b6  por xmm3, xmm1
000074fc937cf3ba  vmovaps [rsp+0x40], xmm6
000074fc937cf3c0  vmovaps xmm10, [rsp+0x40]
000074fc937cf3c6  por xmm6, xmm10
000074fc937cf3cb  lea r12, [rax+0x30]
000074fc937cf3cf  mov r11, [r13+r12*1]
000074fc937cf3d4  lea r12, [rax+0x38]
000074fc937cf3d8  mov r10, [r13+r12*1]
000074fc937cf3dd  movq xmm10, r11
000074fc937cf3e2  vmovaps [rsp+0x40], xmm1
000074fc937cf3e8  movq xmm1, r10
000074fc937cf3ed  movq xmm10, xmm10
000074fc937cf3f2  vmovaps [rsp+0x60], xmm10
000074fc937cf3f8  movq xmm10, xmm10
000074fc937cf3fd  movaps [r15+0x130], xmm10
000074fc937cf405  movq xmm1, xmm1
000074fc937cf409  vmovaps [rsp+0x70], xmm1
000074fc937cf40f  movq xmm1, xmm1
000074fc937cf413  movaps [r15+0x280], xmm1
000074fc937cf41b  vmovaps [rsp+0x80], xmm9
000074fc937cf424  vmovaps xmm1, [rsp+0x80]
000074fc937cf42d  por xmm9, xmm1
000074fc937cf432  lea r12, [rax+0x20]
000074fc937cf436  mov r11, [r13+r12*1]
000074fc937cf43b  lea r12, [rax+0x28]
000074fc937cf43f  mov r10, [r13+r12*1]
000074fc937cf444  movq xmm1, r11
000074fc937cf449  movq xmm10, r10
000074fc937cf44e  movq xmm1, xmm1
000074fc937cf452  vmovaps [rsp+0x80], xmm1
000074fc937cf45b  movq xmm1, xmm1
000074fc937cf45f  movaps [r15+0x150], xmm1
000074fc937cf467  movq xmm10, xmm10
000074fc937cf46c  vmovaps [rsp+0x90], xmm10
000074fc937cf475  movq xmm10, xmm10
000074fc937cf47a  movaps [r15+0x140], xmm10
000074fc937cf482  lea r12, [rax+0x10]
000074fc937cf486  mov r11, [r13+r12*1]
000074fc937cf48b  lea r12, [rax+0x18]
000074fc937cf48f  mov r10, [r13+r12*1]
000074fc937cf494  movq xmm1, r11
000074fc937cf499  movq xmm10, r10
000074fc937cf49e  movq xmm1, xmm1
000074fc937cf4a2  vmovaps [rsp+0xA0], xmm1
000074fc937cf4ab  movq xmm1, xmm1
000074fc937cf4af  movaps [r15+0x170], xmm1
000074fc937cf4b7  movq xmm10, xmm10
000074fc937cf4bc  vmovaps [rsp+0xB0], xmm10
000074fc937cf4c5  movq xmm10, xmm10
000074fc937cf4ca  movaps [r15+0x160], xmm10
000074fc937cf4d2  mov r12, [r13+rax*1]
000074fc937cf4d7  vmovq xmm1, r12
000074fc937cf4dc  vpbroadcastq xmm1, xmm1
000074fc937cf4e1  lea r12, [rax+0x08]
000074fc937cf4e5  mov rax, [r13+r12*1]
000074fc937cf4ea  movq xmm10, rax
000074fc937cf4ef  movaps [r15+0x230], xmm10
000074fc937cf4f7  lea rax, [r14+0x50]
000074fc937cf4fb  movups xmm10, [r13+rax*1]
000074fc937cf501  lea rax, [r14+0x60]
000074fc937cf505  vmovaps [rsp+0xC0], xmm1
000074fc937cf50e  movups xmm1, [r13+rax*1]
000074fc937cf514  lea rax, [r14+0x30]
000074fc937cf518  vmovaps [rsp+0xD0], xmm1
000074fc937cf521  movups xmm1, [r13+rax*1]
000074fc937cf527  mov qword ptr [r15+0x60], 0x430920
000074fc937cf52f  mov qword ptr [r15+0x58], 0x40
000074fc937cf537  vmovaps [rsp+0xE0], xmm1
000074fc937cf540  vmovaps [rsp+0xF0], xmm15
000074fc937cf549  vmovaps xmm15, [rsp+0xC0]
000074fc937cf552  vmovaps [rsp+0xC0], xmm14
000074fc937cf55b  vmovaps xmm14, [rsp+0x40]
000074fc937cf561  vmovaps [rsp+0x40], xmm13
000074fc937cf567  movaps xmm1, xmm15
000074fc937cf56b  mulpd xmm1, xmm14
000074fc937cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000074fc937cf575  ptest xmm13, xmm13
000074fc937cf57b  jnz 0x000074FC937D0682
000074fc937cf581  movq xmm14, qword ptr [r15+0x230]
000074fc937cf58a  vmovaps [rsp+0x100], xmm14
000074fc937cf593  vpermilpd xmm14, xmm14, 0x00
000074fc937cf599  vmovaps [rsp+0x110], xmm1
000074fc937cf5a2  vmovaps xmm1, [rsp+0xE0]
000074fc937cf5ab  vmovaps [rsp+0xE0], xmm15
000074fc937cf5b4  movaps xmm13, xmm1
000074fc937cf5b8  mulpd xmm13, xmm14
000074fc937cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000074fc937cf5c3  ptest xmm15, xmm15
000074fc937cf5c9  jnz 0x000074FC937D07C4
000074fc937cf5cf  vxorps xmm1, xmm1, xmm1
000074fc937cf5d3  vpbroadcastq xmm1, xmm1
000074fc937cf5d8  vmovaps xmm14, [rsp+0xE0]
000074fc937cf5e1  vmovaps [rsp+0xE0], xmm1
000074fc937cf5ea  vmovaps xmm1, [rsp+0xD0]
000074fc937cf5f3  vmovaps [rsp+0xD0], xmm13
000074fc937cf5fc  movaps xmm15, xmm14
000074fc937cf600  mulpd xmm15, xmm1
000074fc937cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc937cf60b  ptest xmm13, xmm13
000074fc937cf611  jnz 0x000074FC937D0907
000074fc937cf617  movaps xmm1, xmm14
000074fc937cf61b  mulpd xmm1, xmm10
000074fc937cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000074fc937cf625  ptest xmm13, xmm13
000074fc937cf62b  jnz 0x000074FC937D0A4A
000074fc937cf631  movaps xmm13, xmm14
000074fc937cf635  mulpd xmm13, xmm2
000074fc937cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000074fc937cf640  ptest xmm10, xmm10
000074fc937cf646  jnz 0x000074FC937D0B8C
000074fc937cf64c  vmovaps [rsp+0x120], xmm7
000074fc937cf655  vmovaps xmm14, [rsp+0x120]
000074fc937cf65e  por xmm7, xmm14
000074fc937cf663  vmovaps xmm14, [rsp+0xC0]
000074fc937cf66c  vmovaps xmm10, [rsp+0xC0]
000074fc937cf675  por xmm14, xmm10
000074fc937cf67a  vmovaps xmm2, [rsp+0x100]
000074fc937cf683  vpermilpd xmm2, xmm2, 0x00
000074fc937cf689  vmovaps [rsp+0xC0], xmm1
000074fc937cf692  vmovaps [rsp+0x120], xmm15
000074fc937cf69b  movaps xmm1, xmm10
000074fc937cf69f  mulpd xmm1, xmm2
000074fc937cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc937cf6a8  ptest xmm15, xmm15
000074fc937cf6ae  jnz 0x000074FC937D0CCF
000074fc937cf6b4  xor eax, eax
000074fc937cf6b6  mov r12d, 0x40
000074fc937cf6bc  mov r11d, 0x200
000074fc937cf6c2  cmp r12, r11
000074fc937cf6c5  cmc
000074fc937cf6c6  lahf
000074fc937cf6c7  seto al
000074fc937cf6ca  mov [r15+0x108], eax
000074fc937cf6d1  vmovaps xmm10, [rsp+0x110]
000074fc937cf6da  vmovaps xmm2, [rsp+0xE0]
000074fc937cf6e3  vmovaps [rsp+0xE0], xmm1
000074fc937cf6ec  movaps xmm15, xmm10
000074fc937cf6f0  addpd xmm15, xmm2
000074fc937cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937cf6fb  ptest xmm1, xmm1
000074fc937cf700  jnz 0x000074FC937D0E10
000074fc937cf706  vmovaps xmm10, [rsp+0x120]
000074fc937cf70f  vmovaps [rsp+0x110], xmm15
000074fc937cf718  movaps xmm1, xmm10
000074fc937cf71c  addpd xmm1, xmm12
000074fc937cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc937cf726  ptest xmm15, xmm15
000074fc937cf72c  jnz 0x000074FC937D0F53
000074fc937cf732  vmovaps xmm10, [rsp+0xC0]
000074fc937cf73b  vmovaps [rsp+0xC0], xmm1
000074fc937cf744  movaps xmm15, xmm10
000074fc937cf748  addpd xmm15, xmm12
000074fc937cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937cf753  ptest xmm1, xmm1
000074fc937cf758  jnz 0x000074FC937D1095
000074fc937cf75e  vmovaps xmm1, [rsp+0x30]
000074fc937cf764  vmovaps xmm12, [rsp+0x30]
000074fc937cf76a  por xmm1, xmm12
000074fc937cf76f  vmovaps xmm12, [rsp+0x20]
000074fc937cf775  vmovaps xmm10, [rsp+0x20]
000074fc937cf77b  por xmm12, xmm10
000074fc937cf780  vmovaps [rsp+0x20], xmm5
000074fc937cf786  vmovaps xmm10, [rsp+0x20]
000074fc937cf78c  por xmm5, xmm10
000074fc937cf791  vmovaps [rsp+0x20], xmm11
000074fc937cf797  vmovaps xmm10, [rsp+0x20]
000074fc937cf79d  por xmm11, xmm10
000074fc937cf7a2  vmovaps [rsp+0x20], xmm4
000074fc937cf7a8  vmovaps xmm10, [rsp+0x20]
000074fc937cf7ae  por xmm4, xmm10
000074fc937cf7b3  vmovaps [rsp+0x20], xmm8
000074fc937cf7b9  vmovaps xmm10, [rsp+0x20]
000074fc937cf7bf  por xmm8, xmm10
000074fc937cf7c4  vmovaps xmm10, [rsp+0xF0]
000074fc937cf7cd  vmovaps [rsp+0x20], xmm1
000074fc937cf7d3  vmovaps xmm1, [rsp+0xF0]
000074fc937cf7dc  por xmm10, xmm1
000074fc937cf7e1  lea rax, [r14+0xA0]
000074fc937cf7e8  movups xmm1, [r13+rax*1]
000074fc937cf7ee  lea rax, [r14+0xB0]
000074fc937cf7f5  vmovaps [rsp+0x30], xmm1
000074fc937cf7fb  movups xmm1, [r13+rax*1]
000074fc937cf801  vmovaps [rsp+0xF0], xmm1
000074fc937cf80a  vmovaps [rsp+0x120], xmm15
000074fc937cf813  movaps xmm1, xmm13
000074fc937cf817  addpd xmm1, xmm2
000074fc937cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc937cf820  ptest xmm15, xmm15
000074fc937cf826  jnz 0x000074FC937D11ED
000074fc937cf82c  lea rax, [r14+0xF0]
000074fc937cf833  movups xmm15, [r13+rax*1]
000074fc937cf839  vmovaps xmm2, [rsp+0xC0]
000074fc937cf842  vmovaps [rsp+0xC0], xmm1
000074fc937cf84b  vmovaps xmm1, [rsp+0xE0]
000074fc937cf854  vmovaps [rsp+0xE0], xmm15
000074fc937cf85d  movaps xmm13, xmm2
000074fc937cf861  addpd xmm13, xmm1
000074fc937cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000074fc937cf86c  ptest xmm15, xmm15
000074fc937cf872  jnz 0x000074FC937D1338
000074fc937cf878  vmovaps xmm15, [rsp+0x120]
000074fc937cf881  vmovaps xmm2, [rsp+0xD0]
000074fc937cf88a  vmovaps [rsp+0xD0], xmm14
000074fc937cf893  movaps xmm1, xmm15
000074fc937cf897  addpd xmm1, xmm2
000074fc937cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc937cf8a0  ptest xmm14, xmm14
000074fc937cf8a6  jnz 0x000074FC937D147A
000074fc937cf8ac  vmovaps xmm15, [rsp+0x100]
000074fc937cf8b5  vpermilpd xmm15, xmm15, 0x00
000074fc937cf8bb  vmovaps xmm2, [rsp+0xF0]
000074fc937cf8c4  vmovaps [rsp+0xF0], xmm1
000074fc937cf8cd  movaps xmm14, xmm2
000074fc937cf8d1  mulpd xmm14, xmm15
000074fc937cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000074fc937cf8dc  ptest xmm1, xmm1
000074fc937cf8e1  jnz 0x000074FC937D15BB
000074fc937cf8e7  vmovaps xmm1, [rsp+0xA0]
000074fc937cf8f0  vpermilpd xmm1, xmm1, 0x00
000074fc937cf8f6  vmovaps xmm2, [rsp+0xE0]
000074fc937cf8ff  vmovaps [rsp+0xE0], xmm14
000074fc937cf908  movaps xmm15, xmm2
000074fc937cf90c  mulpd xmm15, xmm1
000074fc937cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc937cf917  ptest xmm14, xmm14
000074fc937cf91d  jnz 0x000074FC937D16FE
000074fc937cf923  lea rax, [r14+0xE0]
000074fc937cf92a  movups xmm1, [r13+rax*1]
000074fc937cf930  vmovaps xmm14, [rsp+0x100]
000074fc937cf939  vpermilpd xmm14, xmm14, 0x00
000074fc937cf93f  vmovaps [rsp+0x100], xmm1
000074fc937cf948  vmovaps xmm1, [rsp+0x30]
000074fc937cf94e  vmovaps [rsp+0x30], xmm15
000074fc937cf954  movaps xmm2, xmm1
000074fc937cf957  mulpd xmm2, xmm14
000074fc937cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000074fc937cf961  ptest xmm15, xmm15
000074fc937cf967  jnz 0x000074FC937D184A
000074fc937cf96d  vmovaps [rsp+0x120], xmm10
000074fc937cf976  vmovaps xmm1, [rsp+0x120]
000074fc937cf97f  por xmm10, xmm1
000074fc937cf984  movaps [r15+0x300], xmm10
000074fc937cf98c  vmovaps [rsp+0x120], xmm8
000074fc937cf995  vmovaps xmm1, [rsp+0x120]
000074fc937cf99e  por xmm8, xmm1
000074fc937cf9a3  movaps [r15+0x190], xmm8
000074fc937cf9ab  vmovaps xmm1, [rsp+0xA0]
000074fc937cf9b4  vpermilpd xmm1, xmm1, 0x00
000074fc937cf9ba  vmovaps xmm14, [rsp+0x100]
000074fc937cf9c3  vmovaps [rsp+0x100], xmm13
000074fc937cf9cc  movaps xmm15, xmm14
000074fc937cf9d0  mulpd xmm15, xmm1
000074fc937cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc937cf9db  ptest xmm13, xmm13
000074fc937cf9e1  jnz 0x000074FC937D198B
000074fc937cf9e7  lea rax, [r14+0x90]
000074fc937cf9ee  movups xmm1, [r13+rax*1]
000074fc937cf9f4  vmovaps [rsp+0x120], xmm4
000074fc937cf9fd  vmovaps xmm14, [rsp+0x120]
000074fc937cfa06  por xmm4, xmm14
000074fc937cfa0b  movaps [r15+0x1C0], xmm4
000074fc937cfa13  vmovaps [rsp+0x120], xmm11
000074fc937cfa1c  vmovaps xmm14, [rsp+0x120]
000074fc937cfa25  por xmm11, xmm14
000074fc937cfa2a  movaps [r15+0x200], xmm11
000074fc937cfa32  vmovaps [rsp+0x120], xmm5
000074fc937cfa3b  vmovaps xmm14, [rsp+0x120]
000074fc937cfa44  por xmm5, xmm14
000074fc937cfa49  movaps [r15+0x2D0], xmm5
000074fc937cfa51  vmovaps [rsp+0x120], xmm12
000074fc937cfa5a  vmovaps xmm14, [rsp+0x120]
000074fc937cfa63  por xmm12, xmm14
000074fc937cfa68  movaps [r15+0x2E0], xmm12
000074fc937cfa70  vmovaps xmm13, [rsp+0x110]
000074fc937cfa79  vmovaps [rsp+0x110], xmm1
000074fc937cfa82  vmovaps xmm1, [rsp+0xE0]
000074fc937cfa8b  vmovaps [rsp+0xE0], xmm15
000074fc937cfa94  movaps xmm14, xmm13
000074fc937cfa98  addpd xmm14, xmm1
000074fc937cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000074fc937cfaa3  ptest xmm15, xmm15
000074fc937cfaa9  jnz 0x000074FC937D1AD8
000074fc937cfaaf  vmovaps xmm1, [rsp+0xA0]
000074fc937cfab8  vpermilpd xmm1, xmm1, 0x00
000074fc937cfabe  vmovaps xmm13, [rsp+0x110]
000074fc937cfac7  vmovaps [rsp+0x110], xmm14
000074fc937cfad0  movaps xmm15, xmm13
000074fc937cfad4  mulpd xmm15, xmm1
000074fc937cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc937cfadf  ptest xmm14, xmm14
000074fc937cfae5  jnz 0x000074FC937D1C1B
000074fc937cfaeb  lea rax, [r14+0x80]
000074fc937cfaf2  movups xmm1, [r13+rax*1]
000074fc937cfaf8  vmovaps xmm13, [rsp+0xC0]
000074fc937cfb01  vmovaps [rsp+0xC0], xmm1
000074fc937cfb0a  movaps xmm14, xmm13
000074fc937cfb0e  addpd xmm14, xmm2
000074fc937cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000074fc937cfb19  ptest xmm1, xmm1
000074fc937cfb1e  jnz 0x000074FC937D1D68
000074fc937cfb24  vmovaps xmm13, [rsp+0x100]
000074fc937cfb2d  vmovaps xmm2, [rsp+0x30]
000074fc937cfb33  vmovaps [rsp+0x30], xmm15
000074fc937cfb39  movaps xmm1, xmm13
000074fc937cfb3d  addpd xmm1, xmm2
000074fc937cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc937cfb46  ptest xmm15, xmm15
000074fc937cfb4c  jnz 0x000074FC937D1EAB
000074fc937cfb52  vmovaps xmm15, [rsp+0x20]
000074fc937cfb58  vmovaps xmm13, [rsp+0x20]
000074fc937cfb5e  por xmm15, xmm13
000074fc937cfb63  movaps [r15+0x2F0], xmm15
000074fc937cfb6b  vmovaps xmm13, [rsp+0xA0]
000074fc937cfb74  vpermilpd xmm13, xmm13, 0x00
000074fc937cfb7a  vmovaps [rsp+0x20], xmm1
000074fc937cfb80  vmovaps xmm1, [rsp+0xC0]
000074fc937cfb89  vmovaps [rsp+0xA0], xmm15
000074fc937cfb92  movaps xmm2, xmm1
000074fc937cfb95  mulpd xmm2, xmm13
000074fc937cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000074fc937cfb9f  ptest xmm15, xmm15
000074fc937cfba5  jnz 0x000074FC937D1FEC
000074fc937cfbab  lea rax, [r14+0xD0]
000074fc937cfbb2  movups xmm1, [r13+rax*1]
000074fc937cfbb8  vmovaps xmm13, [rsp+0xF0]
000074fc937cfbc1  vmovaps [rsp+0xC0], xmm1
000074fc937cfbca  vmovaps xmm1, [rsp+0xE0]
000074fc937cfbd3  vmovaps [rsp+0xE0], xmm14
000074fc937cfbdc  movaps xmm15, xmm13
000074fc937cfbe0  addpd xmm15, xmm1
000074fc937cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc937cfbeb  ptest xmm14, xmm14
000074fc937cfbf1  jnz 0x000074FC937D2137
000074fc937cfbf7  vmovaps xmm1, [rsp+0xB0]
000074fc937cfc00  vpermilpd xmm1, xmm1, 0x00
000074fc937cfc06  movaps xmm14, xmm11
000074fc937cfc0a  mulpd xmm14, xmm1
000074fc937cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000074fc937cfc15  ptest xmm13, xmm13
000074fc937cfc1b  jnz 0x000074FC937D227A
000074fc937cfc21  movaps [r15+0x260], xmm14
000074fc937cfc29  vxorps xmm1, xmm1, xmm1
000074fc937cfc2d  vpbroadcastq xmm1, xmm1
000074fc937cfc32  movaps [r15+0x1B0], xmm1
000074fc937cfc3a  vmovaps xmm1, [rsp+0xB0]
000074fc937cfc43  vpermilpd xmm1, xmm1, 0x00
000074fc937cfc49  vmovaps xmm11, [rsp+0xC0]
000074fc937cfc52  vmovaps [rsp+0xC0], xmm15
000074fc937cfc5b  movaps xmm13, xmm11
000074fc937cfc5f  mulpd xmm13, xmm1
000074fc937cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000074fc937cfc6a  ptest xmm15, xmm15
000074fc937cfc70  jnz 0x000074FC937D23BD
000074fc937cfc76  lea rax, [r14+0xC0]
000074fc937cfc7d  movups xmm1, [r13+rax*1]
000074fc937cfc83  vmovaps xmm11, [rsp+0x110]
000074fc937cfc8c  vmovaps [rsp+0xF0], xmm1
000074fc937cfc95  vmovaps xmm1, [rsp+0x30]
000074fc937cfc9b  vmovaps [rsp+0x30], xmm14
000074fc937cfca1  movaps xmm15, xmm11
000074fc937cfca5  addpd xmm15, xmm1
000074fc937cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc937cfcb0  ptest xmm14, xmm14
000074fc937cfcb6  jnz 0x000074FC937D250A
000074fc937cfcbc  vmovaps [rsp+0x100], xmm9
000074fc937cfcc5  vmovaps xmm1, [rsp+0x100]
000074fc937cfcce  por xmm9, xmm1
000074fc937cfcd3  movaps [r15+0x270], xmm9
000074fc937cfcdb  vmovaps [rsp+0x100], xmm6
000074fc937cfce4  vmovaps xmm1, [rsp+0x100]
000074fc937cfced  por xmm6, xmm1
000074fc937cfcf1  movaps [r15+0x1A0], xmm6
000074fc937cfcf9  vmovaps xmm14, [rsp+0xB0]
000074fc937cfd02  vpermilpd xmm14, xmm14, 0x00
000074fc937cfd08  vmovaps xmm6, [rsp+0xF0]
000074fc937cfd11  vmovaps [rsp+0xF0], xmm1
000074fc937cfd1a  movaps xmm11, xmm6
000074fc937cfd1e  mulpd xmm11, xmm14
000074fc937cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000074fc937cfd29  ptest xmm1, xmm1
000074fc937cfd2e  jnz 0x000074FC937D264D
000074fc937cfd34  lea rax, [r14+0x20]
000074fc937cfd38  movups xmm1, [r13+rax*1]
000074fc937cfd3e  movaps [r15+0x110], xmm1
000074fc937cfd46  vmovaps xmm6, [rsp+0xE0]
000074fc937cfd4f  vmovaps [rsp+0xE0], xmm1
000074fc937cfd58  movaps xmm14, xmm6
000074fc937cfd5c  addpd xmm14, xmm2
000074fc937cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000074fc937cfd67  ptest xmm1, xmm1
000074fc937cfd6c  jnz 0x000074FC937D279A
000074fc937cfd72  vmovaps xmm1, [rsp+0xB0]
000074fc937cfd7b  vpermilpd xmm1, xmm1, 0x00
000074fc937cfd81  movaps xmm6, xmm5
000074fc937cfd84  mulpd xmm6, xmm1
000074fc937cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000074fc937cfd8d  ptest xmm2, xmm2
000074fc937cfd92  jnz 0x000074FC937D28DC
000074fc937cfd98  vmovaps xmm5, [rsp+0x20]
000074fc937cfd9e  movaps xmm1, xmm5
000074fc937cfda1  addpd xmm1, xmm13
000074fc937cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc937cfdab  ptest xmm2, xmm2
000074fc937cfdb0  jnz 0x000074FC937D2A1C
000074fc937cfdb6  vmovaps xmm13, [rsp+0x80]
000074fc937cfdbf  vpermilpd xmm13, xmm13, 0x00
000074fc937cfdc5  vmovaps xmm2, [rsp+0xE0]
000074fc937cfdce  vmovaps [rsp+0x20], xmm1
000074fc937cfdd4  movaps xmm5, xmm2
000074fc937cfdd7  mulpd xmm5, xmm13
000074fc937cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000074fc937cfde1  ptest xmm1, xmm1
000074fc937cfde6  jnz 0x000074FC937D2B5D
000074fc937cfdec  vmovaps xmm1, [rsp+0x80]
000074fc937cfdf5  vpermilpd xmm1, xmm1, 0x00
000074fc937cfdfb  movaps xmm13, xmm10
000074fc937cfdff  mulpd xmm13, xmm1
000074fc937cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000074fc937cfe0a  ptest xmm2, xmm2
000074fc937cfe0f  jnz 0x000074FC937D2C9E
000074fc937cfe15  vmovaps xmm10, [rsp+0x30]
000074fc937cfe1b  movaps xmm1, xmm15
000074fc937cfe1f  addpd xmm1, xmm10
000074fc937cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc937cfe29  ptest xmm2, xmm2
000074fc937cfe2e  jnz 0x000074FC937D2DE1
000074fc937cfe34  vmovaps xmm10, [rsp+0xC0]
000074fc937cfe3d  movaps xmm15, xmm10
000074fc937cfe41  addpd xmm15, xmm11
000074fc937cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000074fc937cfe4c  ptest xmm2, xmm2
000074fc937cfe51  jnz 0x000074FC937D2F23
000074fc937cfe57  vmovaps xmm11, [rsp+0x80]
000074fc937cfe60  vpermilpd xmm11, xmm11, 0x00
000074fc937cfe66  movaps xmm10, xmm12
000074fc937cfe6a  mulpd xmm10, xmm11
000074fc937cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000074fc937cfe75  ptest xmm2, xmm2
000074fc937cfe7a  jnz 0x000074FC937D3067
000074fc937cfe80  vmovaps xmm12, [rsp+0x80]
000074fc937cfe89  vpermilpd xmm12, xmm12, 0x00
000074fc937cfe8f  vmovaps xmm2, [rsp+0xA0]
000074fc937cfe98  vmovaps [rsp+0x30], xmm1
000074fc937cfe9e  movaps xmm11, xmm2
000074fc937cfea2  mulpd xmm11, xmm12
000074fc937cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000074fc937cfead  ptest xmm1, xmm1
000074fc937cfeb2  jnz 0x000074FC937D31AB
000074fc937cfeb8  movaps xmm1, xmm14
000074fc937cfebc  addpd xmm1, xmm6
000074fc937cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc937cfec5  ptest xmm12, xmm12
000074fc937cfecb  jnz 0x000074FC937D32EE
000074fc937cfed1  vmovaps xmm12, [rsp+0x20]
000074fc937cfed7  movaps xmm14, xmm12
000074fc937cfedb  addpd xmm14, xmm5
000074fc937cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc937cfee6  ptest xmm6, xmm6
000074fc937cfeeb  jnz 0x000074FC937D342F
000074fc937cfef1  vmovaps xmm12, [rsp+0x90]
000074fc937cfefa  vpermilpd xmm12, xmm12, 0x00
000074fc937cff00  movaps xmm6, xmm9
000074fc937cff04  mulpd xmm6, xmm12
000074fc937cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc937cff0e  ptest xmm5, xmm5
000074fc937cff13  jnz 0x000074FC937D3572
000074fc937cff19  movaps xmm12, xmm15
000074fc937cff1d  addpd xmm12, xmm13
000074fc937cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc937cff28  ptest xmm9, xmm9
000074fc937cff2e  jnz 0x000074FC937D36B4
000074fc937cff34  vmovaps xmm13, [rsp+0x30]
000074fc937cff3a  movaps xmm15, xmm13
000074fc937cff3e  addpd xmm15, xmm10
000074fc937cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc937cff49  ptest xmm9, xmm9
000074fc937cff4f  jnz 0x000074FC937D37F8
000074fc937cff55  vmovaps xmm13, [rsp+0xD0]
000074fc937cff5e  vmovaps xmm10, [rsp+0xD0]
000074fc937cff67  por xmm13, xmm10
000074fc937cff6c  movaps [r15+0x250], xmm13
000074fc937cff74  vmovaps [rsp+0x20], xmm7
000074fc937cff7a  vmovaps xmm13, [rsp+0x20]
000074fc937cff80  por xmm7, xmm13
000074fc937cff85  movaps [r15+0x2A0], xmm7
000074fc937cff8d  vmovaps [rsp+0x20], xmm3
000074fc937cff93  vmovaps xmm13, [rsp+0x20]
000074fc937cff99  por xmm3, xmm13
000074fc937cff9e  movaps [r15+0x1D0], xmm3
000074fc937cffa6  lea rax, [r14+0x40]
000074fc937cffaa  movups xmm13, [r13+rax*1]
000074fc937cffb0  movaps [r15+0x2C0], xmm13
000074fc937cffb8  vmovaps xmm10, [rsp+0x90]
000074fc937cffc1  vpermilpd xmm10, xmm10, 0x00
000074fc937cffc7  movaps xmm9, xmm8
000074fc937cffcb  mulpd xmm9, xmm10
000074fc937cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000074fc937cffd6  ptest xmm5, xmm5
000074fc937cffdb  jnz 0x000074FC937D3946
000074fc937cffe1  movaps xmm10, xmm1
000074fc937cffe5  addpd xmm10, xmm11
000074fc937cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000074fc937cfff0  ptest xmm8, xmm8
000074fc937cfff6  jnz 0x000074FC937D3A8A
000074fc937cfffc  movaps xmm1, xmm14
000074fc937d0000  addpd xmm1, xmm6
000074fc937d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000074fc937d0009  ptest xmm11, xmm11
000074fc937d000f  jnz 0x000074FC937D3BCD
000074fc937d0015  vmovaps xmm14, [rsp+0x90]
000074fc937d001e  vpermilpd xmm14, xmm14, 0x00
000074fc937d0024  movaps xmm11, xmm13
000074fc937d0028  mulpd xmm11, xmm14
000074fc937d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000074fc937d0033  ptest xmm8, xmm8
000074fc937d0039  jnz 0x000074FC937D3D0E
000074fc937d003f  vmovaps xmm14, [rsp+0x90]
000074fc937d0048  vpermilpd xmm14, xmm14, 0x00
000074fc937d004e  vmovaps xmm8, [rsp+0x10]
000074fc937d0054  movaps xmm13, xmm8
000074fc937d0058  mulpd xmm13, xmm14
000074fc937d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000074fc937d0063  ptest xmm6, xmm6
000074fc937d0068  jnz 0x000074FC937D3E52
000074fc937d006e  vmovaps xmm14, [rsp+0x60]
000074fc937d0074  vpermilpd xmm14, xmm14, 0x00
000074fc937d007a  movaps xmm8, xmm7
000074fc937d007e  mulpd xmm8, xmm14
000074fc937d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc937d0089  ptest xmm6, xmm6
000074fc937d008e  jnz 0x000074FC937D3F96
000074fc937d0094  movaps xmm14, xmm12
000074fc937d0098  addpd xmm14, xmm9
000074fc937d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000074fc937d00a3  ptest xmm7, xmm7
000074fc937d00a8  jnz 0x000074FC937D40D9
000074fc937d00ae  vmovaps xmm12, [rsp+0x60]
000074fc937d00b4  vpermilpd xmm12, xmm12, 0x00
000074fc937d00ba  vmovaps xmm7, [rsp+0xF0]
000074fc937d00c3  movaps xmm9, xmm7
000074fc937d00c7  mulpd xmm9, xmm12
000074fc937d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc937d00d2  ptest xmm6, xmm6
000074fc937d00d7  jnz 0x000074FC937D421D
000074fc937d00dd  movaps xmm12, xmm15
000074fc937d00e1  addpd xmm12, xmm11
000074fc937d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000074fc937d00ec  ptest xmm7, xmm7
000074fc937d00f1  jnz 0x000074FC937D4360
000074fc937d00f7  vmovaps xmm15, [rsp+0x60]
000074fc937d00fd  vpermilpd xmm15, xmm15, 0x00
000074fc937d0103  vmovaps xmm7, [rsp+0x40]
000074fc937d0109  movaps xmm11, xmm7
000074fc937d010d  mulpd xmm11, xmm15
000074fc937d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000074fc937d0118  ptest xmm6, xmm6
000074fc937d011d  jnz 0x000074FC937D44A4
000074fc937d0123  movaps xmm15, xmm10
000074fc937d0127  addpd xmm15, xmm13
000074fc937d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000074fc937d0132  ptest xmm7, xmm7
000074fc937d0137  jnz 0x000074FC937D45E7
000074fc937d013d  vmovaps xmm13, [rsp+0x60]
000074fc937d0143  vpermilpd xmm13, xmm13, 0x00
000074fc937d0149  vmovaps xmm7, [rsp+0x50]
000074fc937d014f  movaps xmm10, xmm7
000074fc937d0153  mulpd xmm10, xmm13
000074fc937d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc937d015e  ptest xmm6, xmm6
000074fc937d0163  jnz 0x000074FC937D472B
000074fc937d0169  movaps xmm13, xmm1
000074fc937d016d  addpd xmm13, xmm8
000074fc937d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000074fc937d0178  ptest xmm7, xmm7
000074fc937d017d  jnz 0x000074FC937D486E
000074fc937d0183  lea rax, [r14+0x70]
000074fc937d0187  movups xmm1, [r13+rax*1]
000074fc937d018d  movaps [r15+0x240], xmm1
000074fc937d0195  movaps xmm8, xmm14
000074fc937d0199  addpd xmm8, xmm9
000074fc937d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc937d01a4  ptest xmm7, xmm7
000074fc937d01a9  jnz 0x000074FC937D49BB
000074fc937d01af  movaps [r15+0x170], xmm8
000074fc937d01b7  vmovaps xmm14, [rsp+0x70]
000074fc937d01bd  vpermilpd xmm14, xmm14, 0x00
000074fc937d01c3  movaps xmm9, xmm1
000074fc937d01c7  mulpd xmm9, xmm14
000074fc937d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000074fc937d01d2  ptest xmm7, xmm7
000074fc937d01d7  jnz 0x000074FC937D4AFF
000074fc937d01dd  vmovaps xmm1, [rsp+0x70]
000074fc937d01e3  vpermilpd xmm1, xmm1, 0x00
000074fc937d01e9  movaps xmm14, xmm4
000074fc937d01ed  mulpd xmm14, xmm1
000074fc937d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000074fc937d01f8  ptest xmm7, xmm7
000074fc937d01fd  jnz 0x000074FC937D4C42
000074fc937d0203  movaps [r15+0x180], xmm14
000074fc937d020b  movaps xmm1, xmm12
000074fc937d020f  addpd xmm1, xmm11
000074fc937d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000074fc937d0219  ptest xmm7, xmm7
000074fc937d021e  jnz 0x000074FC937D4D84
000074fc937d0224  movaps [r15+0x210], xmm1
000074fc937d022c  movups xmm12, [r13+r14*1]
000074fc937d0232  lea rax, [r14+0x10]
000074fc937d0236  movups xmm11, [r13+rax*1]
000074fc937d023c  movaps [r15+0x230], xmm11
000074fc937d0244  movaps xmm7, xmm15
000074fc937d0248  addpd xmm7, xmm10
000074fc937d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc937d0252  ptest xmm6, xmm6
000074fc937d0257  jnz 0x000074FC937D4EDA
000074fc937d025d  movaps [r15+0x130], xmm7
000074fc937d0265  vmovaps xmm15, [rsp+0x70]
000074fc937d026b  vpermilpd xmm15, xmm15, 0x00
000074fc937d0271  movaps xmm10, xmm11
000074fc937d0275  mulpd xmm10, xmm15
000074fc937d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc937d0280  ptest xmm6, xmm6
000074fc937d0285  jnz 0x000074FC937D501C
000074fc937d028b  movaps [r15+0x220], xmm10
000074fc937d0293  vmovaps xmm15, [rsp+0x70]
000074fc937d0299  vpermilpd xmm15, xmm15, 0x00
000074fc937d029f  movaps xmm11, xmm12
000074fc937d02a3  mulpd xmm11, xmm15
000074fc937d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000074fc937d02ae  ptest xmm6, xmm6
000074fc937d02b3  jnz 0x000074FC937D5160
000074fc937d02b9  movaps xmm15, xmm13
000074fc937d02bd  addpd xmm15, xmm9
000074fc937d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000074fc937d02c8  ptest xmm12, xmm12
000074fc937d02ce  jnz 0x000074FC937D52A4
000074fc937d02d4  movaps [r15+0x140], xmm15
000074fc937d02dc  movaps xmm13, xmm8
000074fc937d02e0  addpd xmm13, xmm14
000074fc937d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc937d02eb  ptest xmm12, xmm12
000074fc937d02f1  jnz 0x000074FC937D53E8
000074fc937d02f7  movaps [r15+0x150], xmm13
000074fc937d02ff  movaps xmm14, xmm1
000074fc937d0303  addpd xmm14, xmm10
000074fc937d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000074fc937d030e  ptest xmm12, xmm12
000074fc937d0314  jnz 0x000074FC937D552C
000074fc937d031a  movaps [r15+0x160], xmm14
000074fc937d0322  movaps xmm1, xmm7
000074fc937d0325  addpd xmm1, xmm11
000074fc937d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc937d032f  ptest xmm12, xmm12
000074fc937d0335  jnz 0x000074FC937D566F
000074fc937d033b  movaps [r15+0x120], xmm1
000074fc937d0343  mov eax, 0x430920
000074fc937d0348  movups [r13+rax*1], xmm15
000074fc937d034e  mov eax, 0x430930
000074fc937d0353  movups [r13+rax*1], xmm13
000074fc937d0359  mov eax, 0x430940
000074fc937d035e  movups [r13+rax*1], xmm14
000074fc937d0364  mov eax, 0x430950
000074fc937d0369  movups [r13+rax*1], xmm1
000074fc937d036f  mov eax, [r15+0x108]
000074fc937d0376  sahf
000074fc937d0377  jnz 0x000074FC937D03A9
000074fc937d0379  cmp dword ptr [r15+0x318], 0x00
000074fc937d0381  jz 0x000074FC937DB900
000074fc937d0387  nop [rax+rax*1], ax
000074fc937d0390  nop [rax+rax*1], eax
000074fc937d0398  mov eax, 0x410444
000074fc937d039d  mov [r15+0x100], rax
000074fc937d03a4  jmp 0x000074FC935FE110
000074fc937d03a9  cmp dword ptr [r15+0x318], 0x00
000074fc937d03b1  jz 0x000074FC937D57E0
000074fc937d03b7  nop [rax+rax*1], ax
000074fc937d03c0  nop [rax+rax*1], eax
000074fc937d03c8  mov eax, 0x410278
000074fc937d03cd  mov [r15+0x100], rax
000074fc937d03d4  jmp 0x000074FC935FE110
000074fc937d03d9  int3
000074fc937d03da  call 0x000074FC936B52F0
000074fc937d03df  jmp 0x000074FC937CF016
000074fc937d03e4  call 0x000074FC936C4620
000074fc937d03e9  jmp 0x000074FC937CF023
000074fc937d03ee  call 0x000074FC936C33A0
000074fc937d03f3  jmp 0x000074FC937CF035
000074fc937d03f8  call 0x000074FC936C2120
000074fc937d03fd  jmp 0x000074FC937CF03F
000074fc937d0402  call 0x000074FC936C0860
000074fc937d0407  jmp 0x000074FC937CF067
000074fc937d040c  call 0x000074FC936BF5F0
000074fc937d0411  jmp 0x000074FC937CF073
000074fc937d0416  call 0x000074FC936C0860
000074fc937d041b  jmp 0x000074FC937CF0A5
000074fc937d0420  call 0x000074FC936BF5F0
000074fc937d0425  jmp 0x000074FC937CF0B1
000074fc937d042a  call 0x000074FC936C4740
000074fc937d042f  jmp 0x000074FC937CF0BE
000074fc937d0434  call 0x000074FC936B5400
000074fc937d0439  jmp 0x000074FC937CF0CB
000074fc937d043e  call 0x000074FC936B52F0
000074fc937d0443  jmp 0x000074FC937CF0D8
000074fc937d0448  call 0x000074FC936C4620
000074fc937d044d  jmp 0x000074FC937CF0E5
000074fc937d0452  call 0x000074FC936C0860
000074fc937d0457  jmp 0x000074FC937CF10D
000074fc937d045c  call 0x000074FC936BF5F0
000074fc937d0461  jmp 0x000074FC937CF119
000074fc937d0466  call 0x000074FC93609D70
000074fc937d046b  jmp 0x000074FC937CF11F
000074fc937d0470  call 0x000074FC936BE9C0
000074fc937d0475  jmp 0x000074FC937CF129
000074fc937d047a  call 0x000074FC936C0860
000074fc937d047f  jmp 0x000074FC937CF151
000074fc937d0484  call 0x000074FC936BF5F0
000074fc937d0489  jmp 0x000074FC937CF15D
000074fc937d048e  call 0x000074FC936BD750
000074fc937d0493  jmp 0x000074FC937CF16A
000074fc937d0498  call 0x000074FC936BC4E0
000074fc937d049d  jmp 0x000074FC937CF177
000074fc937d04a2  call 0x000074FC936C4740
000074fc937d04a7  jmp 0x000074FC937CF184
000074fc937d04ac  call 0x000074FC936B5400
000074fc937d04b1  jmp 0x000074FC937CF191
000074fc937d04b6  call 0x000074FC936B52F0
000074fc937d04bb  jmp 0x000074FC937CF19E
000074fc937d04c0  call 0x000074FC936C4620
000074fc937d04c5  jmp 0x000074FC937CF1AB
000074fc937d04ca  call 0x000074FC936C0860
000074fc937d04cf  jmp 0x000074FC937CF1BE
000074fc937d04d4  call 0x000074FC936BB270
000074fc937d04d9  jmp 0x000074FC937CF1CB
000074fc937d04de  call 0x000074FC936BA000
000074fc937d04e3  jmp 0x000074FC937CF1D8
000074fc937d04e8  call 0x000074FC936B8D90
000074fc937d04ed  jmp 0x000074FC937CF1E5
000074fc937d04f2  call 0x000074FC936B8A20
000074fc937d04f7  jmp 0x000074FC937CF1F2
000074fc937d04fc  call 0x000074FC936B5400
000074fc937d0501  jmp 0x000074FC937CF1FC
000074fc937d0506  call 0x000074FC936C2240
000074fc937d050b  jmp 0x000074FC937CF206
000074fc937d0510  call 0x000074FC936B52F0
000074fc937d0515  jmp 0x000074FC937CF210
000074fc937d051a  call 0x000074FC936C2120
000074fc937d051f  jmp 0x000074FC937CF21A
000074fc937d0524  call 0x000074FC936B77B0
000074fc937d0529  jmp 0x000074FC937CF224
000074fc937d052e  call 0x000074FC936B6550
000074fc937d0533  jmp 0x000074FC937CF22E
000074fc937d0538  call 0x000074FC936BFD50
000074fc937d053d  jmp 0x000074FC937CF240
000074fc937d0542  call 0x000074FC936B8EA0
000074fc937d0547  jmp 0x000074FC937CF24A
000074fc937d054c  call 0x000074FC936BFC30
000074fc937d0551  jmp 0x000074FC937CF257
000074fc937d0556  call 0x000074FC936B8D90
000074fc937d055b  jmp 0x000074FC937CF264
000074fc937d0560  call 0x000074FC936C2240
000074fc937d0565  jmp 0x000074FC937CF271
000074fc937d056a  call 0x000074FC936B5400
000074fc937d056f  jmp 0x000074FC937CF27E
000074fc937d0574  call 0x000074FC936B52F0
000074fc937d0579  jmp 0x000074FC937CF28B
000074fc937d057e  call 0x000074FC936C2120
000074fc937d0583  jmp 0x000074FC937CF298
000074fc937d0588  call 0x000074FC936B52F0
000074fc937d058d  jmp 0x000074FC937CF2AB
000074fc937d0592  call 0x000074FC936B52F0
000074fc937d0597  jmp 0x000074FC937CF2BE
000074fc937d059c  call 0x000074FC936B52F0
000074fc937d05a1  jmp 0x000074FC937CF2D1
000074fc937d05a6  call 0x000074FC936B52F0
000074fc937d05ab  jmp 0x000074FC937CF2E4
000074fc937d05b0  call 0x000074FC936C2240
000074fc937d05b5  jmp 0x000074FC937CF2F9
000074fc937d05ba  call 0x000074FC936C2240
000074fc937d05bf  jmp 0x000074FC937CF30C
000074fc937d05c4  call 0x000074FC936C2120
000074fc937d05c9  jmp 0x000074FC937CF319
000074fc937d05ce  call 0x000074FC936B52F0
000074fc937d05d3  jmp 0x000074FC937CF32C
000074fc937d05d8  call 0x000074FC936B52F0
000074fc937d05dd  jmp 0x000074FC937CF34F
000074fc937d05e2  call 0x000074FC936B52F0
000074fc937d05e7  jmp 0x000074FC937CF362
000074fc937d05ec  call 0x000074FC935FF540
000074fc937d05f1  jmp 0x000074FC937CF380
000074fc937d05f6  call 0x000074FC93608C20
000074fc937d05fb  jmp 0x000074FC937CF38A
000074fc937d0600  call 0x000074FC936D6600
000074fc937d0605  jmp 0x000074FC937CF396
000074fc937d060a  call 0x000074FC935FF540
000074fc937d060f  jmp 0x000074FC937CF3A6
000074fc937d0614  call 0x000074FC936C0370
000074fc937d0619  jmp 0x000074FC937CF3D4
000074fc937d061e  call 0x000074FC936BF100
000074fc937d0623  jmp 0x000074FC937CF3DD
000074fc937d0628  call 0x000074FC936C0370
000074fc937d062d  jmp 0x000074FC937CF43B
000074fc937d0632  call 0x000074FC936BF100
000074fc937d0637  jmp 0x000074FC937CF444
000074fc937d063c  call 0x000074FC936C0370
000074fc937d0641  jmp 0x000074FC937CF48B
000074fc937d0646  call 0x000074FC936BF100
000074fc937d064b  jmp 0x000074FC937CF494
000074fc937d0650  call 0x000074FC9360B720
000074fc937d0655  jmp 0x000074FC937CF4D7
000074fc937d065a  call 0x000074FC936B47C0
000074fc937d065f  jmp 0x000074FC937CF4EA
000074fc937d0664  call 0x000074FC93608B00
000074fc937d0669  jmp 0x000074FC937CF501
000074fc937d066e  call 0x000074FC935FF430
000074fc937d0673  jmp 0x000074FC937CF514
000074fc937d0678  call 0x000074FC935FF430
000074fc937d067d  jmp 0x000074FC937CF527
000074fc937d0682  sub rsp, 0x08
000074fc937d0686  push rax
000074fc937d0687  push rcx
000074fc937d0688  push rdx
000074fc937d0689  push rdi
000074fc937d068a  push rsi
000074fc937d068b  push r8
000074fc937d068d  push r9
000074fc937d068f  push r10
000074fc937d0691  push r11
000074fc937d0693  sub rsp, 0xF0
000074fc937d069a  vmovaps [rsp], xmm0
000074fc937d069f  vmovaps [rsp+0x10], xmm2
000074fc937d06a5  vmovaps [rsp+0x20], xmm3
000074fc937d06ab  vmovaps [rsp+0x30], xmm4
000074fc937d06b1  vmovaps [rsp+0x40], xmm5
000074fc937d06b7  vmovaps [rsp+0x50], xmm6
000074fc937d06bd  vmovaps [rsp+0x60], xmm7
000074fc937d06c3  vmovaps [rsp+0x70], xmm8
000074fc937d06c9  vmovaps [rsp+0x80], xmm9
000074fc937d06d2  vmovaps [rsp+0x90], xmm10
000074fc937d06db  vmovaps [rsp+0xA0], xmm11
000074fc937d06e4  vmovaps [rsp+0xB0], xmm12
000074fc937d06ed  vmovaps [rsp+0xC0], xmm13
000074fc937d06f6  vmovaps [rsp+0xD0], xmm14
000074fc937d06ff  vmovaps [rsp+0xE0], xmm15
000074fc937d0708  sub rsp, 0x30
000074fc937d070c  movaps [rsp], xmm1
000074fc937d0710  movaps [rsp+0x10], xmm15
000074fc937d0716  movaps [rsp+0x20], xmm14
000074fc937d071c  lea rdi, [rsp]
000074fc937d0720  mov esi, 0x00
000074fc937d0725  mov rax, 0x5D72CBC20530
000074fc937d072f  call rax
000074fc937d0731  movaps xmm1, [rsp]
000074fc937d0735  add rsp, 0x30
000074fc937d0739  vmovaps xmm0, [rsp]
000074fc937d073e  vmovaps xmm2, [rsp+0x10]
000074fc937d0744  vmovaps xmm3, [rsp+0x20]
000074fc937d074a  vmovaps xmm4, [rsp+0x30]
000074fc937d0750  vmovaps xmm5, [rsp+0x40]
000074fc937d0756  vmovaps xmm6, [rsp+0x50]
000074fc937d075c  vmovaps xmm7, [rsp+0x60]
000074fc937d0762  vmovaps xmm8, [rsp+0x70]
000074fc937d0768  vmovaps xmm9, [rsp+0x80]
000074fc937d0771  vmovaps xmm10, [rsp+0x90]
000074fc937d077a  vmovaps xmm11, [rsp+0xA0]
000074fc937d0783  vmovaps xmm12, [rsp+0xB0]
000074fc937d078c  vmovaps xmm13, [rsp+0xC0]
000074fc937d0795  vmovaps xmm14, [rsp+0xD0]
000074fc937d079e  vmovaps xmm15, [rsp+0xE0]
000074fc937d07a7  add rsp, 0xF0
000074fc937d07ae  pop r11
000074fc937d07b0  pop r10
000074fc937d07b2  pop r9
000074fc937d07b4  pop r8
000074fc937d07b6  pop rsi
000074fc937d07b7  pop rdi
000074fc937d07b8  pop rdx
000074fc937d07b9  pop rcx
000074fc937d07ba  pop rax
000074fc937d07bb  add rsp, 0x08
000074fc937d07bf  jmp 0x000074FC937CF581
000074fc937d07c4  sub rsp, 0x08
000074fc937d07c8  push rax
000074fc937d07c9  push rcx
000074fc937d07ca  push rdx
000074fc937d07cb  push rdi
000074fc937d07cc  push rsi
000074fc937d07cd  push r8
000074fc937d07cf  push r9
000074fc937d07d1  push r10
000074fc937d07d3  push r11
000074fc937d07d5  sub rsp, 0xF0
000074fc937d07dc  vmovaps [rsp], xmm0
000074fc937d07e1  vmovaps [rsp+0x10], xmm1
000074fc937d07e7  vmovaps [rsp+0x20], xmm2
000074fc937d07ed  vmovaps [rsp+0x30], xmm3
000074fc937d07f3  vmovaps [rsp+0x40], xmm4
000074fc937d07f9  vmovaps [rsp+0x50], xmm5
000074fc937d07ff  vmovaps [rsp+0x60], xmm6
000074fc937d0805  vmovaps [rsp+0x70], xmm7
000074fc937d080b  vmovaps [rsp+0x80], xmm8
000074fc937d0814  vmovaps [rsp+0x90], xmm9
000074fc937d081d  vmovaps [rsp+0xA0], xmm10
000074fc937d0826  vmovaps [rsp+0xB0], xmm11
000074fc937d082f  vmovaps [rsp+0xC0], xmm12
000074fc937d0838  vmovaps [rsp+0xD0], xmm14
000074fc937d0841  vmovaps [rsp+0xE0], xmm15
000074fc937d084a  sub rsp, 0x30
000074fc937d084e  movaps [rsp], xmm13
000074fc937d0853  movaps [rsp+0x10], xmm1
000074fc937d0858  movaps [rsp+0x20], xmm14
000074fc937d085e  lea rdi, [rsp]
000074fc937d0862  mov esi, 0x00
000074fc937d0867  mov rax, 0x5D72CBC20530
000074fc937d0871  call rax
000074fc937d0873  movaps xmm13, [rsp]
000074fc937d0878  add rsp, 0x30
000074fc937d087c  vmovaps xmm0, [rsp]
000074fc937d0881  vmovaps xmm1, [rsp+0x10]
000074fc937d0887  vmovaps xmm2, [rsp+0x20]
000074fc937d088d  vmovaps xmm3, [rsp+0x30]
000074fc937d0893  vmovaps xmm4, [rsp+0x40]
000074fc937d0899  vmovaps xmm5, [rsp+0x50]
000074fc937d089f  vmovaps xmm6, [rsp+0x60]
000074fc937d08a5  vmovaps xmm7, [rsp+0x70]
000074fc937d08ab  vmovaps xmm8, [rsp+0x80]
000074fc937d08b4  vmovaps xmm9, [rsp+0x90]
000074fc937d08bd  vmovaps xmm10, [rsp+0xA0]
000074fc937d08c6  vmovaps xmm11, [rsp+0xB0]
000074fc937d08cf  vmovaps xmm12, [rsp+0xC0]
000074fc937d08d8  vmovaps xmm14, [rsp+0xD0]
000074fc937d08e1  vmovaps xmm15, [rsp+0xE0]
000074fc937d08ea  add rsp, 0xF0
000074fc937d08f1  pop r11
000074fc937d08f3  pop r10
000074fc937d08f5  pop r9
000074fc937d08f7  pop r8
000074fc937d08f9  pop rsi
000074fc937d08fa  pop rdi
000074fc937d08fb  pop rdx
000074fc937d08fc  pop rcx
000074fc937d08fd  pop rax
000074fc937d08fe  add rsp, 0x08
000074fc937d0902  jmp 0x000074FC937CF5CF
000074fc937d0907  sub rsp, 0x08
000074fc937d090b  push rax
000074fc937d090c  push rcx
000074fc937d090d  push rdx
000074fc937d090e  push rdi
000074fc937d090f  push rsi
000074fc937d0910  push r8
000074fc937d0912  push r9
000074fc937d0914  push r10
000074fc937d0916  push r11
000074fc937d0918  sub rsp, 0xF0
000074fc937d091f  vmovaps [rsp], xmm0
000074fc937d0924  vmovaps [rsp+0x10], xmm1
000074fc937d092a  vmovaps [rsp+0x20], xmm2
000074fc937d0930  vmovaps [rsp+0x30], xmm3
000074fc937d0936  vmovaps [rsp+0x40], xmm4
000074fc937d093c  vmovaps [rsp+0x50], xmm5
000074fc937d0942  vmovaps [rsp+0x60], xmm6
000074fc937d0948  vmovaps [rsp+0x70], xmm7
000074fc937d094e  vmovaps [rsp+0x80], xmm8
000074fc937d0957  vmovaps [rsp+0x90], xmm9
000074fc937d0960  vmovaps [rsp+0xA0], xmm10
000074fc937d0969  vmovaps [rsp+0xB0], xmm11
000074fc937d0972  vmovaps [rsp+0xC0], xmm12
000074fc937d097b  vmovaps [rsp+0xD0], xmm13
000074fc937d0984  vmovaps [rsp+0xE0], xmm14
000074fc937d098d  sub rsp, 0x30
000074fc937d0991  movaps [rsp], xmm15
000074fc937d0996  movaps [rsp+0x10], xmm14
000074fc937d099c  movaps [rsp+0x20], xmm1
000074fc937d09a1  lea rdi, [rsp]
000074fc937d09a5  mov esi, 0x00
000074fc937d09aa  mov rax, 0x5D72CBC20530
000074fc937d09b4  call rax
000074fc937d09b6  movaps xmm15, [rsp]
000074fc937d09bb  add rsp, 0x30
000074fc937d09bf  vmovaps xmm0, [rsp]
000074fc937d09c4  vmovaps xmm1, [rsp+0x10]
000074fc937d09ca  vmovaps xmm2, [rsp+0x20]
000074fc937d09d0  vmovaps xmm3, [rsp+0x30]
000074fc937d09d6  vmovaps xmm4, [rsp+0x40]
000074fc937d09dc  vmovaps xmm5, [rsp+0x50]
000074fc937d09e2  vmovaps xmm6, [rsp+0x60]
000074fc937d09e8  vmovaps xmm7, [rsp+0x70]
000074fc937d09ee  vmovaps xmm8, [rsp+0x80]
000074fc937d09f7  vmovaps xmm9, [rsp+0x90]
000074fc937d0a00  vmovaps xmm10, [rsp+0xA0]
000074fc937d0a09  vmovaps xmm11, [rsp+0xB0]
000074fc937d0a12  vmovaps xmm12, [rsp+0xC0]
000074fc937d0a1b  vmovaps xmm13, [rsp+0xD0]
000074fc937d0a24  vmovaps xmm14, [rsp+0xE0]
000074fc937d0a2d  add rsp, 0xF0
000074fc937d0a34  pop r11
000074fc937d0a36  pop r10
000074fc937d0a38  pop r9
000074fc937d0a3a  pop r8
000074fc937d0a3c  pop rsi
000074fc937d0a3d  pop rdi
000074fc937d0a3e  pop rdx
000074fc937d0a3f  pop rcx
000074fc937d0a40  pop rax
000074fc937d0a41  add rsp, 0x08
000074fc937d0a45  jmp 0x000074FC937CF617
000074fc937d0a4a  sub rsp, 0x08
000074fc937d0a4e  push rax
000074fc937d0a4f  push rcx
000074fc937d0a50  push rdx
000074fc937d0a51  push rdi
000074fc937d0a52  push rsi
000074fc937d0a53  push r8
000074fc937d0a55  push r9
000074fc937d0a57  push r10
000074fc937d0a59  push r11
000074fc937d0a5b  sub rsp, 0xF0
000074fc937d0a62  vmovaps [rsp], xmm0
000074fc937d0a67  vmovaps [rsp+0x10], xmm2
000074fc937d0a6d  vmovaps [rsp+0x20], xmm3
000074fc937d0a73  vmovaps [rsp+0x30], xmm4
000074fc937d0a79  vmovaps [rsp+0x40], xmm5
000074fc937d0a7f  vmovaps [rsp+0x50], xmm6
000074fc937d0a85  vmovaps [rsp+0x60], xmm7
000074fc937d0a8b  vmovaps [rsp+0x70], xmm8
000074fc937d0a91  vmovaps [rsp+0x80], xmm9
000074fc937d0a9a  vmovaps [rsp+0x90], xmm10
000074fc937d0aa3  vmovaps [rsp+0xA0], xmm11
000074fc937d0aac  vmovaps [rsp+0xB0], xmm12
000074fc937d0ab5  vmovaps [rsp+0xC0], xmm13
000074fc937d0abe  vmovaps [rsp+0xD0], xmm14
000074fc937d0ac7  vmovaps [rsp+0xE0], xmm15
000074fc937d0ad0  sub rsp, 0x30
000074fc937d0ad4  movaps [rsp], xmm1
000074fc937d0ad8  movaps [rsp+0x10], xmm14
000074fc937d0ade  movaps [rsp+0x20], xmm10
000074fc937d0ae4  lea rdi, [rsp]
000074fc937d0ae8  mov esi, 0x00
000074fc937d0aed  mov rax, 0x5D72CBC20530
000074fc937d0af7  call rax
000074fc937d0af9  movaps xmm1, [rsp]
000074fc937d0afd  add rsp, 0x30
000074fc937d0b01  vmovaps xmm0, [rsp]
000074fc937d0b06  vmovaps xmm2, [rsp+0x10]
000074fc937d0b0c  vmovaps xmm3, [rsp+0x20]
000074fc937d0b12  vmovaps xmm4, [rsp+0x30]
000074fc937d0b18  vmovaps xmm5, [rsp+0x40]
000074fc937d0b1e  vmovaps xmm6, [rsp+0x50]
000074fc937d0b24  vmovaps xmm7, [rsp+0x60]
000074fc937d0b2a  vmovaps xmm8, [rsp+0x70]
000074fc937d0b30  vmovaps xmm9, [rsp+0x80]
000074fc937d0b39  vmovaps xmm10, [rsp+0x90]
000074fc937d0b42  vmovaps xmm11, [rsp+0xA0]
000074fc937d0b4b  vmovaps xmm12, [rsp+0xB0]
000074fc937d0b54  vmovaps xmm13, [rsp+0xC0]
000074fc937d0b5d  vmovaps xmm14, [rsp+0xD0]
000074fc937d0b66  vmovaps xmm15, [rsp+0xE0]
000074fc937d0b6f  add rsp, 0xF0
000074fc937d0b76  pop r11
000074fc937d0b78  pop r10
000074fc937d0b7a  pop r9
000074fc937d0b7c  pop r8
000074fc937d0b7e  pop rsi
000074fc937d0b7f  pop rdi
000074fc937d0b80  pop rdx
000074fc937d0b81  pop rcx
000074fc937d0b82  pop rax
000074fc937d0b83  add rsp, 0x08
000074fc937d0b87  jmp 0x000074FC937CF631
000074fc937d0b8c  sub rsp, 0x08
000074fc937d0b90  push rax
000074fc937d0b91  push rcx
000074fc937d0b92  push rdx
000074fc937d0b93  push rdi
000074fc937d0b94  push rsi
000074fc937d0b95  push r8
000074fc937d0b97  push r9
000074fc937d0b99  push r10
000074fc937d0b9b  push r11
000074fc937d0b9d  sub rsp, 0xF0
000074fc937d0ba4  vmovaps [rsp], xmm0
000074fc937d0ba9  vmovaps [rsp+0x10], xmm1
000074fc937d0baf  vmovaps [rsp+0x20], xmm2
000074fc937d0bb5  vmovaps [rsp+0x30], xmm3
000074fc937d0bbb  vmovaps [rsp+0x40], xmm4
000074fc937d0bc1  vmovaps [rsp+0x50], xmm5
000074fc937d0bc7  vmovaps [rsp+0x60], xmm6
000074fc937d0bcd  vmovaps [rsp+0x70], xmm7
000074fc937d0bd3  vmovaps [rsp+0x80], xmm8
000074fc937d0bdc  vmovaps [rsp+0x90], xmm9
000074fc937d0be5  vmovaps [rsp+0xA0], xmm10
000074fc937d0bee  vmovaps [rsp+0xB0], xmm11
000074fc937d0bf7  vmovaps [rsp+0xC0], xmm12
000074fc937d0c00  vmovaps [rsp+0xD0], xmm14
000074fc937d0c09  vmovaps [rsp+0xE0], xmm15
000074fc937d0c12  sub rsp, 0x30
000074fc937d0c16  movaps [rsp], xmm13
000074fc937d0c1b  movaps [rsp+0x10], xmm14
000074fc937d0c21  movaps [rsp+0x20], xmm2
000074fc937d0c26  lea rdi, [rsp]
000074fc937d0c2a  mov esi, 0x00
000074fc937d0c2f  mov rax, 0x5D72CBC20530
000074fc937d0c39  call rax
000074fc937d0c3b  movaps xmm13, [rsp]
000074fc937d0c40  add rsp, 0x30
000074fc937d0c44  vmovaps xmm0, [rsp]
000074fc937d0c49  vmovaps xmm1, [rsp+0x10]
000074fc937d0c4f  vmovaps xmm2, [rsp+0x20]
000074fc937d0c55  vmovaps xmm3, [rsp+0x30]
000074fc937d0c5b  vmovaps xmm4, [rsp+0x40]
000074fc937d0c61  vmovaps xmm5, [rsp+0x50]
000074fc937d0c67  vmovaps xmm6, [rsp+0x60]
000074fc937d0c6d  vmovaps xmm7, [rsp+0x70]
000074fc937d0c73  vmovaps xmm8, [rsp+0x80]
000074fc937d0c7c  vmovaps xmm9, [rsp+0x90]
000074fc937d0c85  vmovaps xmm10, [rsp+0xA0]
000074fc937d0c8e  vmovaps xmm11, [rsp+0xB0]
000074fc937d0c97  vmovaps xmm12, [rsp+0xC0]
000074fc937d0ca0  vmovaps xmm14, [rsp+0xD0]
000074fc937d0ca9  vmovaps xmm15, [rsp+0xE0]
000074fc937d0cb2  add rsp, 0xF0
000074fc937d0cb9  pop r11
000074fc937d0cbb  pop r10
000074fc937d0cbd  pop r9
000074fc937d0cbf  pop r8
000074fc937d0cc1  pop rsi
000074fc937d0cc2  pop rdi
000074fc937d0cc3  pop rdx
000074fc937d0cc4  pop rcx
000074fc937d0cc5  pop rax
000074fc937d0cc6  add rsp, 0x08
000074fc937d0cca  jmp 0x000074FC937CF64C
000074fc937d0ccf  sub rsp, 0x08
000074fc937d0cd3  push rax
000074fc937d0cd4  push rcx
000074fc937d0cd5  push rdx
000074fc937d0cd6  push rdi
000074fc937d0cd7  push rsi
000074fc937d0cd8  push r8
000074fc937d0cda  push r9
000074fc937d0cdc  push r10
000074fc937d0cde  push r11
000074fc937d0ce0  sub rsp, 0xF0
000074fc937d0ce7  vmovaps [rsp], xmm0
000074fc937d0cec  vmovaps [rsp+0x10], xmm2
000074fc937d0cf2  vmovaps [rsp+0x20], xmm3
000074fc937d0cf8  vmovaps [rsp+0x30], xmm4
000074fc937d0cfe  vmovaps [rsp+0x40], xmm5
000074fc937d0d04  vmovaps [rsp+0x50], xmm6
000074fc937d0d0a  vmovaps [rsp+0x60], xmm7
000074fc937d0d10  vmovaps [rsp+0x70], xmm8
000074fc937d0d16  vmovaps [rsp+0x80], xmm9
000074fc937d0d1f  vmovaps [rsp+0x90], xmm10
000074fc937d0d28  vmovaps [rsp+0xA0], xmm11
000074fc937d0d31  vmovaps [rsp+0xB0], xmm12
000074fc937d0d3a  vmovaps [rsp+0xC0], xmm13
000074fc937d0d43  vmovaps [rsp+0xD0], xmm14
000074fc937d0d4c  vmovaps [rsp+0xE0], xmm15
000074fc937d0d55  sub rsp, 0x30
000074fc937d0d59  movaps [rsp], xmm1
000074fc937d0d5d  movaps [rsp+0x10], xmm10
000074fc937d0d63  movaps [rsp+0x20], xmm2
000074fc937d0d68  lea rdi, [rsp]
000074fc937d0d6c  mov esi, 0x00
000074fc937d0d71  mov rax, 0x5D72CBC20530
000074fc937d0d7b  call rax
000074fc937d0d7d  movaps xmm1, [rsp]
000074fc937d0d81  add rsp, 0x30
000074fc937d0d85  vmovaps xmm0, [rsp]
000074fc937d0d8a  vmovaps xmm2, [rsp+0x10]
000074fc937d0d90  vmovaps xmm3, [rsp+0x20]
000074fc937d0d96  vmovaps xmm4, [rsp+0x30]
000074fc937d0d9c  vmovaps xmm5, [rsp+0x40]
000074fc937d0da2  vmovaps xmm6, [rsp+0x50]
000074fc937d0da8  vmovaps xmm7, [rsp+0x60]
000074fc937d0dae  vmovaps xmm8, [rsp+0x70]
000074fc937d0db4  vmovaps xmm9, [rsp+0x80]
000074fc937d0dbd  vmovaps xmm10, [rsp+0x90]
000074fc937d0dc6  vmovaps xmm11, [rsp+0xA0]
000074fc937d0dcf  vmovaps xmm12, [rsp+0xB0]
000074fc937d0dd8  vmovaps xmm13, [rsp+0xC0]
000074fc937d0de1  vmovaps xmm14, [rsp+0xD0]
000074fc937d0dea  vmovaps xmm15, [rsp+0xE0]
000074fc937d0df3  add rsp, 0xF0
000074fc937d0dfa  pop r11
000074fc937d0dfc  pop r10
000074fc937d0dfe  pop r9
000074fc937d0e00  pop r8
000074fc937d0e02  pop rsi
000074fc937d0e03  pop rdi
000074fc937d0e04  pop rdx
000074fc937d0e05  pop rcx
000074fc937d0e06  pop rax
000074fc937d0e07  add rsp, 0x08
000074fc937d0e0b  jmp 0x000074FC937CF6B4
000074fc937d0e10  sub rsp, 0x08
000074fc937d0e14  push rax
000074fc937d0e15  push rcx
000074fc937d0e16  push rdx
000074fc937d0e17  push rdi
000074fc937d0e18  push rsi
000074fc937d0e19  push r8
000074fc937d0e1b  push r9
000074fc937d0e1d  push r10
000074fc937d0e1f  push r11
000074fc937d0e21  sub rsp, 0xF0
000074fc937d0e28  vmovaps [rsp], xmm0
000074fc937d0e2d  vmovaps [rsp+0x10], xmm1
000074fc937d0e33  vmovaps [rsp+0x20], xmm2
000074fc937d0e39  vmovaps [rsp+0x30], xmm3
000074fc937d0e3f  vmovaps [rsp+0x40], xmm4
000074fc937d0e45  vmovaps [rsp+0x50], xmm5
000074fc937d0e4b  vmovaps [rsp+0x60], xmm6
000074fc937d0e51  vmovaps [rsp+0x70], xmm7
000074fc937d0e57  vmovaps [rsp+0x80], xmm8
000074fc937d0e60  vmovaps [rsp+0x90], xmm9
000074fc937d0e69  vmovaps [rsp+0xA0], xmm10
000074fc937d0e72  vmovaps [rsp+0xB0], xmm11
000074fc937d0e7b  vmovaps [rsp+0xC0], xmm12
000074fc937d0e84  vmovaps [rsp+0xD0], xmm13
000074fc937d0e8d  vmovaps [rsp+0xE0], xmm14
000074fc937d0e96  sub rsp, 0x30
000074fc937d0e9a  movaps [rsp], xmm15
000074fc937d0e9f  movaps [rsp+0x10], xmm10
000074fc937d0ea5  movaps [rsp+0x20], xmm2
000074fc937d0eaa  lea rdi, [rsp]
000074fc937d0eae  mov esi, 0x00
000074fc937d0eb3  mov rax, 0x5D72CBC20530
000074fc937d0ebd  call rax
000074fc937d0ebf  movaps xmm15, [rsp]
000074fc937d0ec4  add rsp, 0x30
000074fc937d0ec8  vmovaps xmm0, [rsp]
000074fc937d0ecd  vmovaps xmm1, [rsp+0x10]
000074fc937d0ed3  vmovaps xmm2, [rsp+0x20]
000074fc937d0ed9  vmovaps xmm3, [rsp+0x30]
000074fc937d0edf  vmovaps xmm4, [rsp+0x40]
000074fc937d0ee5  vmovaps xmm5, [rsp+0x50]
000074fc937d0eeb  vmovaps xmm6, [rsp+0x60]
000074fc937d0ef1  vmovaps xmm7, [rsp+0x70]
000074fc937d0ef7  vmovaps xmm8, [rsp+0x80]
000074fc937d0f00  vmovaps xmm9, [rsp+0x90]
000074fc937d0f09  vmovaps xmm10, [rsp+0xA0]
000074fc937d0f12  vmovaps xmm11, [rsp+0xB0]
000074fc937d0f1b  vmovaps xmm12, [rsp+0xC0]
000074fc937d0f24  vmovaps xmm13, [rsp+0xD0]
000074fc937d0f2d  vmovaps xmm14, [rsp+0xE0]
000074fc937d0f36  add rsp, 0xF0
000074fc937d0f3d  pop r11
000074fc937d0f3f  pop r10
000074fc937d0f41  pop r9
000074fc937d0f43  pop r8
000074fc937d0f45  pop rsi
000074fc937d0f46  pop rdi
000074fc937d0f47  pop rdx
000074fc937d0f48  pop rcx
000074fc937d0f49  pop rax
000074fc937d0f4a  add rsp, 0x08
000074fc937d0f4e  jmp 0x000074FC937CF706
000074fc937d0f53  sub rsp, 0x08
000074fc937d0f57  push rax
000074fc937d0f58  push rcx
000074fc937d0f59  push rdx
000074fc937d0f5a  push rdi
000074fc937d0f5b  push rsi
000074fc937d0f5c  push r8
000074fc937d0f5e  push r9
000074fc937d0f60  push r10
000074fc937d0f62  push r11
000074fc937d0f64  sub rsp, 0xF0
000074fc937d0f6b  vmovaps [rsp], xmm0
000074fc937d0f70  vmovaps [rsp+0x10], xmm2
000074fc937d0f76  vmovaps [rsp+0x20], xmm3
000074fc937d0f7c  vmovaps [rsp+0x30], xmm4
000074fc937d0f82  vmovaps [rsp+0x40], xmm5
000074fc937d0f88  vmovaps [rsp+0x50], xmm6
000074fc937d0f8e  vmovaps [rsp+0x60], xmm7
000074fc937d0f94  vmovaps [rsp+0x70], xmm8
000074fc937d0f9a  vmovaps [rsp+0x80], xmm9
000074fc937d0fa3  vmovaps [rsp+0x90], xmm10
000074fc937d0fac  vmovaps [rsp+0xA0], xmm11
000074fc937d0fb5  vmovaps [rsp+0xB0], xmm12
000074fc937d0fbe  vmovaps [rsp+0xC0], xmm13
000074fc937d0fc7  vmovaps [rsp+0xD0], xmm14
000074fc937d0fd0  vmovaps [rsp+0xE0], xmm15
000074fc937d0fd9  sub rsp, 0x30
000074fc937d0fdd  movaps [rsp], xmm1
000074fc937d0fe1  movaps [rsp+0x10], xmm10
000074fc937d0fe7  movaps [rsp+0x20], xmm12
000074fc937d0fed  lea rdi, [rsp]
000074fc937d0ff1  mov esi, 0x00
000074fc937d0ff6  mov rax, 0x5D72CBC20530
000074fc937d1000  call rax
000074fc937d1002  movaps xmm1, [rsp]
000074fc937d1006  add rsp, 0x30
000074fc937d100a  vmovaps xmm0, [rsp]
000074fc937d100f  vmovaps xmm2, [rsp+0x10]
000074fc937d1015  vmovaps xmm3, [rsp+0x20]
000074fc937d101b  vmovaps xmm4, [rsp+0x30]
000074fc937d1021  vmovaps xmm5, [rsp+0x40]
000074fc937d1027  vmovaps xmm6, [rsp+0x50]
000074fc937d102d  vmovaps xmm7, [rsp+0x60]
000074fc937d1033  vmovaps xmm8, [rsp+0x70]
000074fc937d1039  vmovaps xmm9, [rsp+0x80]
000074fc937d1042  vmovaps xmm10, [rsp+0x90]
000074fc937d104b  vmovaps xmm11, [rsp+0xA0]
000074fc937d1054  vmovaps xmm12, [rsp+0xB0]
000074fc937d105d  vmovaps xmm13, [rsp+0xC0]
000074fc937d1066  vmovaps xmm14, [rsp+0xD0]
000074fc937d106f  vmovaps xmm15, [rsp+0xE0]
000074fc937d1078  add rsp, 0xF0
000074fc937d107f  pop r11
000074fc937d1081  pop r10
000074fc937d1083  pop r9
000074fc937d1085  pop r8
000074fc937d1087  pop rsi
000074fc937d1088  pop rdi
000074fc937d1089  pop rdx
000074fc937d108a  pop rcx
000074fc937d108b  pop rax
000074fc937d108c  add rsp, 0x08
000074fc937d1090  jmp 0x000074FC937CF732
000074fc937d1095  sub rsp, 0x08
000074fc937d1099  push rax
000074fc937d109a  push rcx
000074fc937d109b  push rdx
000074fc937d109c  push rdi
000074fc937d109d  push rsi
000074fc937d109e  push r8
000074fc937d10a0  push r9
000074fc937d10a2  push r10
000074fc937d10a4  push r11
000074fc937d10a6  sub rsp, 0xF0
000074fc937d10ad  vmovaps [rsp], xmm0
000074fc937d10b2  vmovaps [rsp+0x10], xmm1
000074fc937d10b8  vmovaps [rsp+0x20], xmm2
000074fc937d10be  vmovaps [rsp+0x30], xmm3
000074fc937d10c4  vmovaps [rsp+0x40], xmm4
000074fc937d10ca  vmovaps [rsp+0x50], xmm5
000074fc937d10d0  vmovaps [rsp+0x60], xmm6
000074fc937d10d6  vmovaps [rsp+0x70], xmm7
000074fc937d10dc  vmovaps [rsp+0x80], xmm8
000074fc937d10e5  vmovaps [rsp+0x90], xmm9
000074fc937d10ee  vmovaps [rsp+0xA0], xmm10
000074fc937d10f7  vmovaps [rsp+0xB0], xmm11
000074fc937d1100  vmovaps [rsp+0xC0], xmm12
000074fc937d1109  vmovaps [rsp+0xD0], xmm13
000074fc937d1112  vmovaps [rsp+0xE0], xmm14
000074fc937d111b  sub rsp, 0x30
000074fc937d111f  movaps [rsp], xmm15
000074fc937d1124  movaps [rsp+0x10], xmm10
000074fc937d112a  movaps [rsp+0x20], xmm12
000074fc937d1130  lea rdi, [rsp]
000074fc937d1134  mov esi, 0x00
000074fc937d1139  mov rax, 0x5D72CBC20530
000074fc937d1143  call rax
000074fc937d1145  movaps xmm15, [rsp]
000074fc937d114a  add rsp, 0x30
000074fc937d114e  vmovaps xmm0, [rsp]
000074fc937d1153  vmovaps xmm1, [rsp+0x10]
000074fc937d1159  vmovaps xmm2, [rsp+0x20]
000074fc937d115f  vmovaps xmm3, [rsp+0x30]
000074fc937d1165  vmovaps xmm4, [rsp+0x40]
000074fc937d116b  vmovaps xmm5, [rsp+0x50]
000074fc937d1171  vmovaps xmm6, [rsp+0x60]
000074fc937d1177  vmovaps xmm7, [rsp+0x70]
000074fc937d117d  vmovaps xmm8, [rsp+0x80]
000074fc937d1186  vmovaps xmm9, [rsp+0x90]
000074fc937d118f  vmovaps xmm10, [rsp+0xA0]
000074fc937d1198  vmovaps xmm11, [rsp+0xB0]
000074fc937d11a1  vmovaps xmm12, [rsp+0xC0]
000074fc937d11aa  vmovaps xmm13, [rsp+0xD0]
000074fc937d11b3  vmovaps xmm14, [rsp+0xE0]
000074fc937d11bc  add rsp, 0xF0
000074fc937d11c3  pop r11
000074fc937d11c5  pop r10
000074fc937d11c7  pop r9
000074fc937d11c9  pop r8
000074fc937d11cb  pop rsi
000074fc937d11cc  pop rdi
000074fc937d11cd  pop rdx
000074fc937d11ce  pop rcx
000074fc937d11cf  pop rax
000074fc937d11d0  add rsp, 0x08
000074fc937d11d4  jmp 0x000074FC937CF75E
000074fc937d11d9  call 0x000074FC935FF430
000074fc937d11de  jmp 0x000074FC937CF7EE
000074fc937d11e3  call 0x000074FC935FF430
000074fc937d11e8  jmp 0x000074FC937CF801
000074fc937d11ed  sub rsp, 0x08
000074fc937d11f1  push rax
000074fc937d11f2  push rcx
000074fc937d11f3  push rdx
000074fc937d11f4  push rdi
000074fc937d11f5  push rsi
000074fc937d11f6  push r8
000074fc937d11f8  push r9
000074fc937d11fa  push r10
000074fc937d11fc  push r11
000074fc937d11fe  sub rsp, 0xF0
000074fc937d1205  vmovaps [rsp], xmm0
000074fc937d120a  vmovaps [rsp+0x10], xmm2
000074fc937d1210  vmovaps [rsp+0x20], xmm3
000074fc937d1216  vmovaps [rsp+0x30], xmm4
000074fc937d121c  vmovaps [rsp+0x40], xmm5
000074fc937d1222  vmovaps [rsp+0x50], xmm6
000074fc937d1228  vmovaps [rsp+0x60], xmm7
000074fc937d122e  vmovaps [rsp+0x70], xmm8
000074fc937d1234  vmovaps [rsp+0x80], xmm9
000074fc937d123d  vmovaps [rsp+0x90], xmm10
000074fc937d1246  vmovaps [rsp+0xA0], xmm11
000074fc937d124f  vmovaps [rsp+0xB0], xmm12
000074fc937d1258  vmovaps [rsp+0xC0], xmm13
000074fc937d1261  vmovaps [rsp+0xD0], xmm14
000074fc937d126a  vmovaps [rsp+0xE0], xmm15
000074fc937d1273  sub rsp, 0x30
000074fc937d1277  movaps [rsp], xmm1
000074fc937d127b  movaps [rsp+0x10], xmm13
000074fc937d1281  movaps [rsp+0x20], xmm2
000074fc937d1286  lea rdi, [rsp]
000074fc937d128a  mov esi, 0x00
000074fc937d128f  mov rax, 0x5D72CBC20530
000074fc937d1299  call rax
000074fc937d129b  movaps xmm1, [rsp]
000074fc937d129f  add rsp, 0x30
000074fc937d12a3  vmovaps xmm0, [rsp]
000074fc937d12a8  vmovaps xmm2, [rsp+0x10]
000074fc937d12ae  vmovaps xmm3, [rsp+0x20]
000074fc937d12b4  vmovaps xmm4, [rsp+0x30]
000074fc937d12ba  vmovaps xmm5, [rsp+0x40]
000074fc937d12c0  vmovaps xmm6, [rsp+0x50]
000074fc937d12c6  vmovaps xmm7, [rsp+0x60]
000074fc937d12cc  vmovaps xmm8, [rsp+0x70]
000074fc937d12d2  vmovaps xmm9, [rsp+0x80]
000074fc937d12db  vmovaps xmm10, [rsp+0x90]
000074fc937d12e4  vmovaps xmm11, [rsp+0xA0]
000074fc937d12ed  vmovaps xmm12, [rsp+0xB0]
000074fc937d12f6  vmovaps xmm13, [rsp+0xC0]
000074fc937d12ff  vmovaps xmm14, [rsp+0xD0]
000074fc937d1308  vmovaps xmm15, [rsp+0xE0]
000074fc937d1311  add rsp, 0xF0
000074fc937d1318  pop r11
000074fc937d131a  pop r10
000074fc937d131c  pop r9
000074fc937d131e  pop r8
000074fc937d1320  pop rsi
000074fc937d1321  pop rdi
000074fc937d1322  pop rdx
000074fc937d1323  pop rcx
000074fc937d1324  pop rax
000074fc937d1325  add rsp, 0x08
000074fc937d1329  jmp 0x000074FC937CF82C
000074fc937d132e  call 0x000074FC9360E760
000074fc937d1333  jmp 0x000074FC937CF839
000074fc937d1338  sub rsp, 0x08
000074fc937d133c  push rax
000074fc937d133d  push rcx
000074fc937d133e  push rdx
000074fc937d133f  push rdi
000074fc937d1340  push rsi
000074fc937d1341  push r8
000074fc937d1343  push r9
000074fc937d1345  push r10
000074fc937d1347  push r11
000074fc937d1349  sub rsp, 0xF0
000074fc937d1350  vmovaps [rsp], xmm0
000074fc937d1355  vmovaps [rsp+0x10], xmm1
000074fc937d135b  vmovaps [rsp+0x20], xmm2
000074fc937d1361  vmovaps [rsp+0x30], xmm3
000074fc937d1367  vmovaps [rsp+0x40], xmm4
000074fc937d136d  vmovaps [rsp+0x50], xmm5
000074fc937d1373  vmovaps [rsp+0x60], xmm6
000074fc937d1379  vmovaps [rsp+0x70], xmm7
000074fc937d137f  vmovaps [rsp+0x80], xmm8
000074fc937d1388  vmovaps [rsp+0x90], xmm9
000074fc937d1391  vmovaps [rsp+0xA0], xmm10
000074fc937d139a  vmovaps [rsp+0xB0], xmm11
000074fc937d13a3  vmovaps [rsp+0xC0], xmm12
000074fc937d13ac  vmovaps [rsp+0xD0], xmm14
000074fc937d13b5  vmovaps [rsp+0xE0], xmm15
000074fc937d13be  sub rsp, 0x30
000074fc937d13c2  movaps [rsp], xmm13
000074fc937d13c7  movaps [rsp+0x10], xmm2
000074fc937d13cc  movaps [rsp+0x20], xmm1
000074fc937d13d1  lea rdi, [rsp]
000074fc937d13d5  mov esi, 0x00
000074fc937d13da  mov rax, 0x5D72CBC20530
000074fc937d13e4  call rax
000074fc937d13e6  movaps xmm13, [rsp]
000074fc937d13eb  add rsp, 0x30
000074fc937d13ef  vmovaps xmm0, [rsp]
000074fc937d13f4  vmovaps xmm1, [rsp+0x10]
000074fc937d13fa  vmovaps xmm2, [rsp+0x20]
000074fc937d1400  vmovaps xmm3, [rsp+0x30]
000074fc937d1406  vmovaps xmm4, [rsp+0x40]
000074fc937d140c  vmovaps xmm5, [rsp+0x50]
000074fc937d1412  vmovaps xmm6, [rsp+0x60]
000074fc937d1418  vmovaps xmm7, [rsp+0x70]
000074fc937d141e  vmovaps xmm8, [rsp+0x80]
000074fc937d1427  vmovaps xmm9, [rsp+0x90]
000074fc937d1430  vmovaps xmm10, [rsp+0xA0]
000074fc937d1439  vmovaps xmm11, [rsp+0xB0]
000074fc937d1442  vmovaps xmm12, [rsp+0xC0]
000074fc937d144b  vmovaps xmm14, [rsp+0xD0]
000074fc937d1454  vmovaps xmm15, [rsp+0xE0]
000074fc937d145d  add rsp, 0xF0
000074fc937d1464  pop r11
000074fc937d1466  pop r10
000074fc937d1468  pop r9
000074fc937d146a  pop r8
000074fc937d146c  pop rsi
000074fc937d146d  pop rdi
000074fc937d146e  pop rdx
000074fc937d146f  pop rcx
000074fc937d1470  pop rax
000074fc937d1471  add rsp, 0x08
000074fc937d1475  jmp 0x000074FC937CF878
000074fc937d147a  sub rsp, 0x08
000074fc937d147e  push rax
000074fc937d147f  push rcx
000074fc937d1480  push rdx
000074fc937d1481  push rdi
000074fc937d1482  push rsi
000074fc937d1483  push r8
000074fc937d1485  push r9
000074fc937d1487  push r10
000074fc937d1489  push r11
000074fc937d148b  sub rsp, 0xF0
000074fc937d1492  vmovaps [rsp], xmm0
000074fc937d1497  vmovaps [rsp+0x10], xmm2
000074fc937d149d  vmovaps [rsp+0x20], xmm3
000074fc937d14a3  vmovaps [rsp+0x30], xmm4
000074fc937d14a9  vmovaps [rsp+0x40], xmm5
000074fc937d14af  vmovaps [rsp+0x50], xmm6
000074fc937d14b5  vmovaps [rsp+0x60], xmm7
000074fc937d14bb  vmovaps [rsp+0x70], xmm8
000074fc937d14c1  vmovaps [rsp+0x80], xmm9
000074fc937d14ca  vmovaps [rsp+0x90], xmm10
000074fc937d14d3  vmovaps [rsp+0xA0], xmm11
000074fc937d14dc  vmovaps [rsp+0xB0], xmm12
000074fc937d14e5  vmovaps [rsp+0xC0], xmm13
000074fc937d14ee  vmovaps [rsp+0xD0], xmm14
000074fc937d14f7  vmovaps [rsp+0xE0], xmm15
000074fc937d1500  sub rsp, 0x30
000074fc937d1504  movaps [rsp], xmm1
000074fc937d1508  movaps [rsp+0x10], xmm15
000074fc937d150e  movaps [rsp+0x20], xmm2
000074fc937d1513  lea rdi, [rsp]
000074fc937d1517  mov esi, 0x00
000074fc937d151c  mov rax, 0x5D72CBC20530
000074fc937d1526  call rax
000074fc937d1528  movaps xmm1, [rsp]
000074fc937d152c  add rsp, 0x30
000074fc937d1530  vmovaps xmm0, [rsp]
000074fc937d1535  vmovaps xmm2, [rsp+0x10]
000074fc937d153b  vmovaps xmm3, [rsp+0x20]
000074fc937d1541  vmovaps xmm4, [rsp+0x30]
000074fc937d1547  vmovaps xmm5, [rsp+0x40]
000074fc937d154d  vmovaps xmm6, [rsp+0x50]
000074fc937d1553  vmovaps xmm7, [rsp+0x60]
000074fc937d1559  vmovaps xmm8, [rsp+0x70]
000074fc937d155f  vmovaps xmm9, [rsp+0x80]
000074fc937d1568  vmovaps xmm10, [rsp+0x90]
000074fc937d1571  vmovaps xmm11, [rsp+0xA0]
000074fc937d157a  vmovaps xmm12, [rsp+0xB0]
000074fc937d1583  vmovaps xmm13, [rsp+0xC0]
000074fc937d158c  vmovaps xmm14, [rsp+0xD0]
000074fc937d1595  vmovaps xmm15, [rsp+0xE0]
000074fc937d159e  add rsp, 0xF0
000074fc937d15a5  pop r11
000074fc937d15a7  pop r10
000074fc937d15a9  pop r9
000074fc937d15ab  pop r8
000074fc937d15ad  pop rsi
000074fc937d15ae  pop rdi
000074fc937d15af  pop rdx
000074fc937d15b0  pop rcx
000074fc937d15b1  pop rax
000074fc937d15b2  add rsp, 0x08
000074fc937d15b6  jmp 0x000074FC937CF8AC
000074fc937d15bb  sub rsp, 0x08
000074fc937d15bf  push rax
000074fc937d15c0  push rcx
000074fc937d15c1  push rdx
000074fc937d15c2  push rdi
000074fc937d15c3  push rsi
000074fc937d15c4  push r8
000074fc937d15c6  push r9
000074fc937d15c8  push r10
000074fc937d15ca  push r11
000074fc937d15cc  sub rsp, 0xF0
000074fc937d15d3  vmovaps [rsp], xmm0
000074fc937d15d8  vmovaps [rsp+0x10], xmm1
000074fc937d15de  vmovaps [rsp+0x20], xmm2
000074fc937d15e4  vmovaps [rsp+0x30], xmm3
000074fc937d15ea  vmovaps [rsp+0x40], xmm4
000074fc937d15f0  vmovaps [rsp+0x50], xmm5
000074fc937d15f6  vmovaps [rsp+0x60], xmm6
000074fc937d15fc  vmovaps [rsp+0x70], xmm7
000074fc937d1602  vmovaps [rsp+0x80], xmm8
000074fc937d160b  vmovaps [rsp+0x90], xmm9
000074fc937d1614  vmovaps [rsp+0xA0], xmm10
000074fc937d161d  vmovaps [rsp+0xB0], xmm11
000074fc937d1626  vmovaps [rsp+0xC0], xmm12
000074fc937d162f  vmovaps [rsp+0xD0], xmm13
000074fc937d1638  vmovaps [rsp+0xE0], xmm15
000074fc937d1641  sub rsp, 0x30
000074fc937d1645  movaps [rsp], xmm14
000074fc937d164a  movaps [rsp+0x10], xmm2
000074fc937d164f  movaps [rsp+0x20], xmm15
000074fc937d1655  lea rdi, [rsp]
000074fc937d1659  mov esi, 0x00
000074fc937d165e  mov rax, 0x5D72CBC20530
000074fc937d1668  call rax
000074fc937d166a  movaps xmm14, [rsp]
000074fc937d166f  add rsp, 0x30
000074fc937d1673  vmovaps xmm0, [rsp]
000074fc937d1678  vmovaps xmm1, [rsp+0x10]
000074fc937d167e  vmovaps xmm2, [rsp+0x20]
000074fc937d1684  vmovaps xmm3, [rsp+0x30]
000074fc937d168a  vmovaps xmm4, [rsp+0x40]
000074fc937d1690  vmovaps xmm5, [rsp+0x50]
000074fc937d1696  vmovaps xmm6, [rsp+0x60]
000074fc937d169c  vmovaps xmm7, [rsp+0x70]
000074fc937d16a2  vmovaps xmm8, [rsp+0x80]
000074fc937d16ab  vmovaps xmm9, [rsp+0x90]
000074fc937d16b4  vmovaps xmm10, [rsp+0xA0]
000074fc937d16bd  vmovaps xmm11, [rsp+0xB0]
000074fc937d16c6  vmovaps xmm12, [rsp+0xC0]
000074fc937d16cf  vmovaps xmm13, [rsp+0xD0]
000074fc937d16d8  vmovaps xmm15, [rsp+0xE0]
000074fc937d16e1  add rsp, 0xF0
000074fc937d16e8  pop r11
000074fc937d16ea  pop r10
000074fc937d16ec  pop r9
000074fc937d16ee  pop r8
000074fc937d16f0  pop rsi
000074fc937d16f1  pop rdi
000074fc937d16f2  pop rdx
000074fc937d16f3  pop rcx
000074fc937d16f4  pop rax
000074fc937d16f5  add rsp, 0x08
000074fc937d16f9  jmp 0x000074FC937CF8E7
000074fc937d16fe  sub rsp, 0x08
000074fc937d1702  push rax
000074fc937d1703  push rcx
000074fc937d1704  push rdx
000074fc937d1705  push rdi
000074fc937d1706  push rsi
000074fc937d1707  push r8
000074fc937d1709  push r9
000074fc937d170b  push r10
000074fc937d170d  push r11
000074fc937d170f  sub rsp, 0xF0
000074fc937d1716  vmovaps [rsp], xmm0
000074fc937d171b  vmovaps [rsp+0x10], xmm1
000074fc937d1721  vmovaps [rsp+0x20], xmm2
000074fc937d1727  vmovaps [rsp+0x30], xmm3
000074fc937d172d  vmovaps [rsp+0x40], xmm4
000074fc937d1733  vmovaps [rsp+0x50], xmm5
000074fc937d1739  vmovaps [rsp+0x60], xmm6
000074fc937d173f  vmovaps [rsp+0x70], xmm7
000074fc937d1745  vmovaps [rsp+0x80], xmm8
000074fc937d174e  vmovaps [rsp+0x90], xmm9
000074fc937d1757  vmovaps [rsp+0xA0], xmm10
000074fc937d1760  vmovaps [rsp+0xB0], xmm11
000074fc937d1769  vmovaps [rsp+0xC0], xmm12
000074fc937d1772  vmovaps [rsp+0xD0], xmm13
000074fc937d177b  vmovaps [rsp+0xE0], xmm14
000074fc937d1784  sub rsp, 0x30
000074fc937d1788  movaps [rsp], xmm15
000074fc937d178d  movaps [rsp+0x10], xmm2
000074fc937d1792  movaps [rsp+0x20], xmm1
000074fc937d1797  lea rdi, [rsp]
000074fc937d179b  mov esi, 0x00
000074fc937d17a0  mov rax, 0x5D72CBC20530
000074fc937d17aa  call rax
000074fc937d17ac  movaps xmm15, [rsp]
000074fc937d17b1  add rsp, 0x30
000074fc937d17b5  vmovaps xmm0, [rsp]
000074fc937d17ba  vmovaps xmm1, [rsp+0x10]
000074fc937d17c0  vmovaps xmm2, [rsp+0x20]
000074fc937d17c6  vmovaps xmm3, [rsp+0x30]
000074fc937d17cc  vmovaps xmm4, [rsp+0x40]
000074fc937d17d2  vmovaps xmm5, [rsp+0x50]
000074fc937d17d8  vmovaps xmm6, [rsp+0x60]
000074fc937d17de  vmovaps xmm7, [rsp+0x70]
000074fc937d17e4  vmovaps xmm8, [rsp+0x80]
000074fc937d17ed  vmovaps xmm9, [rsp+0x90]
000074fc937d17f6  vmovaps xmm10, [rsp+0xA0]
000074fc937d17ff  vmovaps xmm11, [rsp+0xB0]
000074fc937d1808  vmovaps xmm12, [rsp+0xC0]
000074fc937d1811  vmovaps xmm13, [rsp+0xD0]
000074fc937d181a  vmovaps xmm14, [rsp+0xE0]
000074fc937d1823  add rsp, 0xF0
000074fc937d182a  pop r11
000074fc937d182c  pop r10
000074fc937d182e  pop r9
000074fc937d1830  pop r8
000074fc937d1832  pop rsi
000074fc937d1833  pop rdi
000074fc937d1834  pop rdx
000074fc937d1835  pop rcx
000074fc937d1836  pop rax
000074fc937d1837  add rsp, 0x08
000074fc937d183b  jmp 0x000074FC937CF923
000074fc937d1840  call 0x000074FC935FF430
000074fc937d1845  jmp 0x000074FC937CF930
000074fc937d184a  sub rsp, 0x08
000074fc937d184e  push rax
000074fc937d184f  push rcx
000074fc937d1850  push rdx
000074fc937d1851  push rdi
000074fc937d1852  push rsi
000074fc937d1853  push r8
000074fc937d1855  push r9
000074fc937d1857  push r10
000074fc937d1859  push r11
000074fc937d185b  sub rsp, 0xF0
000074fc937d1862  vmovaps [rsp], xmm0
000074fc937d1867  vmovaps [rsp+0x10], xmm1
000074fc937d186d  vmovaps [rsp+0x20], xmm3
000074fc937d1873  vmovaps [rsp+0x30], xmm4
000074fc937d1879  vmovaps [rsp+0x40], xmm5
000074fc937d187f  vmovaps [rsp+0x50], xmm6
000074fc937d1885  vmovaps [rsp+0x60], xmm7
000074fc937d188b  vmovaps [rsp+0x70], xmm8
000074fc937d1891  vmovaps [rsp+0x80], xmm9
000074fc937d189a  vmovaps [rsp+0x90], xmm10
000074fc937d18a3  vmovaps [rsp+0xA0], xmm11
000074fc937d18ac  vmovaps [rsp+0xB0], xmm12
000074fc937d18b5  vmovaps [rsp+0xC0], xmm13
000074fc937d18be  vmovaps [rsp+0xD0], xmm14
000074fc937d18c7  vmovaps [rsp+0xE0], xmm15
000074fc937d18d0  sub rsp, 0x30
000074fc937d18d4  movaps [rsp], xmm2
000074fc937d18d8  movaps [rsp+0x10], xmm1
000074fc937d18dd  movaps [rsp+0x20], xmm14
000074fc937d18e3  lea rdi, [rsp]
000074fc937d18e7  mov esi, 0x00
000074fc937d18ec  mov rax, 0x5D72CBC20530
000074fc937d18f6  call rax
000074fc937d18f8  movaps xmm2, [rsp]
000074fc937d18fc  add rsp, 0x30
000074fc937d1900  vmovaps xmm0, [rsp]
000074fc937d1905  vmovaps xmm1, [rsp+0x10]
000074fc937d190b  vmovaps xmm3, [rsp+0x20]
000074fc937d1911  vmovaps xmm4, [rsp+0x30]
000074fc937d1917  vmovaps xmm5, [rsp+0x40]
000074fc937d191d  vmovaps xmm6, [rsp+0x50]
000074fc937d1923  vmovaps xmm7, [rsp+0x60]
000074fc937d1929  vmovaps xmm8, [rsp+0x70]
000074fc937d192f  vmovaps xmm9, [rsp+0x80]
000074fc937d1938  vmovaps xmm10, [rsp+0x90]
000074fc937d1941  vmovaps xmm11, [rsp+0xA0]
000074fc937d194a  vmovaps xmm12, [rsp+0xB0]
000074fc937d1953  vmovaps xmm13, [rsp+0xC0]
000074fc937d195c  vmovaps xmm14, [rsp+0xD0]
000074fc937d1965  vmovaps xmm15, [rsp+0xE0]
000074fc937d196e  add rsp, 0xF0
000074fc937d1975  pop r11
000074fc937d1977  pop r10
000074fc937d1979  pop r9
000074fc937d197b  pop r8
000074fc937d197d  pop rsi
000074fc937d197e  pop rdi
000074fc937d197f  pop rdx
000074fc937d1980  pop rcx
000074fc937d1981  pop rax
000074fc937d1982  add rsp, 0x08
000074fc937d1986  jmp 0x000074FC937CF96D
000074fc937d198b  sub rsp, 0x08
000074fc937d198f  push rax
000074fc937d1990  push rcx
000074fc937d1991  push rdx
000074fc937d1992  push rdi
000074fc937d1993  push rsi
000074fc937d1994  push r8
000074fc937d1996  push r9
000074fc937d1998  push r10
000074fc937d199a  push r11
000074fc937d199c  sub rsp, 0xF0
000074fc937d19a3  vmovaps [rsp], xmm0
000074fc937d19a8  vmovaps [rsp+0x10], xmm1
000074fc937d19ae  vmovaps [rsp+0x20], xmm2
000074fc937d19b4  vmovaps [rsp+0x30], xmm3
000074fc937d19ba  vmovaps [rsp+0x40], xmm4
000074fc937d19c0  vmovaps [rsp+0x50], xmm5
000074fc937d19c6  vmovaps [rsp+0x60], xmm6
000074fc937d19cc  vmovaps [rsp+0x70], xmm7
000074fc937d19d2  vmovaps [rsp+0x80], xmm8
000074fc937d19db  vmovaps [rsp+0x90], xmm9
000074fc937d19e4  vmovaps [rsp+0xA0], xmm10
000074fc937d19ed  vmovaps [rsp+0xB0], xmm11
000074fc937d19f6  vmovaps [rsp+0xC0], xmm12
000074fc937d19ff  vmovaps [rsp+0xD0], xmm13
000074fc937d1a08  vmovaps [rsp+0xE0], xmm14
000074fc937d1a11  sub rsp, 0x30
000074fc937d1a15  movaps [rsp], xmm15
000074fc937d1a1a  movaps [rsp+0x10], xmm14
000074fc937d1a20  movaps [rsp+0x20], xmm1
000074fc937d1a25  lea rdi, [rsp]
000074fc937d1a29  mov esi, 0x00
000074fc937d1a2e  mov rax, 0x5D72CBC20530
000074fc937d1a38  call rax
000074fc937d1a3a  movaps xmm15, [rsp]
000074fc937d1a3f  add rsp, 0x30
000074fc937d1a43  vmovaps xmm0, [rsp]
000074fc937d1a48  vmovaps xmm1, [rsp+0x10]
000074fc937d1a4e  vmovaps xmm2, [rsp+0x20]
000074fc937d1a54  vmovaps xmm3, [rsp+0x30]
000074fc937d1a5a  vmovaps xmm4, [rsp+0x40]
000074fc937d1a60  vmovaps xmm5, [rsp+0x50]
000074fc937d1a66  vmovaps xmm6, [rsp+0x60]
000074fc937d1a6c  vmovaps xmm7, [rsp+0x70]
000074fc937d1a72  vmovaps xmm8, [rsp+0x80]
000074fc937d1a7b  vmovaps xmm9, [rsp+0x90]
000074fc937d1a84  vmovaps xmm10, [rsp+0xA0]
000074fc937d1a8d  vmovaps xmm11, [rsp+0xB0]
000074fc937d1a96  vmovaps xmm12, [rsp+0xC0]
000074fc937d1a9f  vmovaps xmm13, [rsp+0xD0]
000074fc937d1aa8  vmovaps xmm14, [rsp+0xE0]
000074fc937d1ab1  add rsp, 0xF0
000074fc937d1ab8  pop r11
000074fc937d1aba  pop r10
000074fc937d1abc  pop r9
000074fc937d1abe  pop r8
000074fc937d1ac0  pop rsi
000074fc937d1ac1  pop rdi
000074fc937d1ac2  pop rdx
000074fc937d1ac3  pop rcx
000074fc937d1ac4  pop rax
000074fc937d1ac5  add rsp, 0x08
000074fc937d1ac9  jmp 0x000074FC937CF9E7
000074fc937d1ace  call 0x000074FC935FF430
000074fc937d1ad3  jmp 0x000074FC937CF9F4
000074fc937d1ad8  sub rsp, 0x08
000074fc937d1adc  push rax
000074fc937d1add  push rcx
000074fc937d1ade  push rdx
000074fc937d1adf  push rdi
000074fc937d1ae0  push rsi
000074fc937d1ae1  push r8
000074fc937d1ae3  push r9
000074fc937d1ae5  push r10
000074fc937d1ae7  push r11
000074fc937d1ae9  sub rsp, 0xF0
000074fc937d1af0  vmovaps [rsp], xmm0
000074fc937d1af5  vmovaps [rsp+0x10], xmm1
000074fc937d1afb  vmovaps [rsp+0x20], xmm2
000074fc937d1b01  vmovaps [rsp+0x30], xmm3
000074fc937d1b07  vmovaps [rsp+0x40], xmm4
000074fc937d1b0d  vmovaps [rsp+0x50], xmm5
000074fc937d1b13  vmovaps [rsp+0x60], xmm6
000074fc937d1b19  vmovaps [rsp+0x70], xmm7
000074fc937d1b1f  vmovaps [rsp+0x80], xmm8
000074fc937d1b28  vmovaps [rsp+0x90], xmm9
000074fc937d1b31  vmovaps [rsp+0xA0], xmm10
000074fc937d1b3a  vmovaps [rsp+0xB0], xmm11
000074fc937d1b43  vmovaps [rsp+0xC0], xmm12
000074fc937d1b4c  vmovaps [rsp+0xD0], xmm13
000074fc937d1b55  vmovaps [rsp+0xE0], xmm15
000074fc937d1b5e  sub rsp, 0x30
000074fc937d1b62  movaps [rsp], xmm14
000074fc937d1b67  movaps [rsp+0x10], xmm13
000074fc937d1b6d  movaps [rsp+0x20], xmm1
000074fc937d1b72  lea rdi, [rsp]
000074fc937d1b76  mov esi, 0x00
000074fc937d1b7b  mov rax, 0x5D72CBC20530
000074fc937d1b85  call rax
000074fc937d1b87  movaps xmm14, [rsp]
000074fc937d1b8c  add rsp, 0x30
000074fc937d1b90  vmovaps xmm0, [rsp]
000074fc937d1b95  vmovaps xmm1, [rsp+0x10]
000074fc937d1b9b  vmovaps xmm2, [rsp+0x20]
000074fc937d1ba1  vmovaps xmm3, [rsp+0x30]
000074fc937d1ba7  vmovaps xmm4, [rsp+0x40]
000074fc937d1bad  vmovaps xmm5, [rsp+0x50]
000074fc937d1bb3  vmovaps xmm6, [rsp+0x60]
000074fc937d1bb9  vmovaps xmm7, [rsp+0x70]
000074fc937d1bbf  vmovaps xmm8, [rsp+0x80]
000074fc937d1bc8  vmovaps xmm9, [rsp+0x90]
000074fc937d1bd1  vmovaps xmm10, [rsp+0xA0]
000074fc937d1bda  vmovaps xmm11, [rsp+0xB0]
000074fc937d1be3  vmovaps xmm12, [rsp+0xC0]
000074fc937d1bec  vmovaps xmm13, [rsp+0xD0]
000074fc937d1bf5  vmovaps xmm15, [rsp+0xE0]
000074fc937d1bfe  add rsp, 0xF0
000074fc937d1c05  pop r11
000074fc937d1c07  pop r10
000074fc937d1c09  pop r9
000074fc937d1c0b  pop r8
000074fc937d1c0d  pop rsi
000074fc937d1c0e  pop rdi
000074fc937d1c0f  pop rdx
000074fc937d1c10  pop rcx
000074fc937d1c11  pop rax
000074fc937d1c12  add rsp, 0x08
000074fc937d1c16  jmp 0x000074FC937CFAAF
000074fc937d1c1b  sub rsp, 0x08
000074fc937d1c1f  push rax
000074fc937d1c20  push rcx
000074fc937d1c21  push rdx
000074fc937d1c22  push rdi
000074fc937d1c23  push rsi
000074fc937d1c24  push r8
000074fc937d1c26  push r9
000074fc937d1c28  push r10
000074fc937d1c2a  push r11
000074fc937d1c2c  sub rsp, 0xF0
000074fc937d1c33  vmovaps [rsp], xmm0
000074fc937d1c38  vmovaps [rsp+0x10], xmm1
000074fc937d1c3e  vmovaps [rsp+0x20], xmm2
000074fc937d1c44  vmovaps [rsp+0x30], xmm3
000074fc937d1c4a  vmovaps [rsp+0x40], xmm4
000074fc937d1c50  vmovaps [rsp+0x50], xmm5
000074fc937d1c56  vmovaps [rsp+0x60], xmm6
000074fc937d1c5c  vmovaps [rsp+0x70], xmm7
000074fc937d1c62  vmovaps [rsp+0x80], xmm8
000074fc937d1c6b  vmovaps [rsp+0x90], xmm9
000074fc937d1c74  vmovaps [rsp+0xA0], xmm10
000074fc937d1c7d  vmovaps [rsp+0xB0], xmm11
000074fc937d1c86  vmovaps [rsp+0xC0], xmm12
000074fc937d1c8f  vmovaps [rsp+0xD0], xmm13
000074fc937d1c98  vmovaps [rsp+0xE0], xmm14
000074fc937d1ca1  sub rsp, 0x30
000074fc937d1ca5  movaps [rsp], xmm15
000074fc937d1caa  movaps [rsp+0x10], xmm13
000074fc937d1cb0  movaps [rsp+0x20], xmm1
000074fc937d1cb5  lea rdi, [rsp]
000074fc937d1cb9  mov esi, 0x00
000074fc937d1cbe  mov rax, 0x5D72CBC20530
000074fc937d1cc8  call rax
000074fc937d1cca  movaps xmm15, [rsp]
000074fc937d1ccf  add rsp, 0x30
000074fc937d1cd3  vmovaps xmm0, [rsp]
000074fc937d1cd8  vmovaps xmm1, [rsp+0x10]
000074fc937d1cde  vmovaps xmm2, [rsp+0x20]
000074fc937d1ce4  vmovaps xmm3, [rsp+0x30]
000074fc937d1cea  vmovaps xmm4, [rsp+0x40]
000074fc937d1cf0  vmovaps xmm5, [rsp+0x50]
000074fc937d1cf6  vmovaps xmm6, [rsp+0x60]
000074fc937d1cfc  vmovaps xmm7, [rsp+0x70]
000074fc937d1d02  vmovaps xmm8, [rsp+0x80]
000074fc937d1d0b  vmovaps xmm9, [rsp+0x90]
000074fc937d1d14  vmovaps xmm10, [rsp+0xA0]
000074fc937d1d1d  vmovaps xmm11, [rsp+0xB0]
000074fc937d1d26  vmovaps xmm12, [rsp+0xC0]
000074fc937d1d2f  vmovaps xmm13, [rsp+0xD0]
000074fc937d1d38  vmovaps xmm14, [rsp+0xE0]
000074fc937d1d41  add rsp, 0xF0
000074fc937d1d48  pop r11
000074fc937d1d4a  pop r10
000074fc937d1d4c  pop r9
000074fc937d1d4e  pop r8
000074fc937d1d50  pop rsi
000074fc937d1d51  pop rdi
000074fc937d1d52  pop rdx
000074fc937d1d53  pop rcx
000074fc937d1d54  pop rax
000074fc937d1d55  add rsp, 0x08
000074fc937d1d59  jmp 0x000074FC937CFAEB
000074fc937d1d5e  call 0x000074FC935FF430
000074fc937d1d63  jmp 0x000074FC937CFAF8
000074fc937d1d68  sub rsp, 0x08
000074fc937d1d6c  push rax
000074fc937d1d6d  push rcx
000074fc937d1d6e  push rdx
000074fc937d1d6f  push rdi
000074fc937d1d70  push rsi
000074fc937d1d71  push r8
000074fc937d1d73  push r9
000074fc937d1d75  push r10
000074fc937d1d77  push r11
000074fc937d1d79  sub rsp, 0xF0
000074fc937d1d80  vmovaps [rsp], xmm0
000074fc937d1d85  vmovaps [rsp+0x10], xmm1
000074fc937d1d8b  vmovaps [rsp+0x20], xmm2
000074fc937d1d91  vmovaps [rsp+0x30], xmm3
000074fc937d1d97  vmovaps [rsp+0x40], xmm4
000074fc937d1d9d  vmovaps [rsp+0x50], xmm5
000074fc937d1da3  vmovaps [rsp+0x60], xmm6
000074fc937d1da9  vmovaps [rsp+0x70], xmm7
000074fc937d1daf  vmovaps [rsp+0x80], xmm8
000074fc937d1db8  vmovaps [rsp+0x90], xmm9
000074fc937d1dc1  vmovaps [rsp+0xA0], xmm10
000074fc937d1dca  vmovaps [rsp+0xB0], xmm11
000074fc937d1dd3  vmovaps [rsp+0xC0], xmm12
000074fc937d1ddc  vmovaps [rsp+0xD0], xmm13
000074fc937d1de5  vmovaps [rsp+0xE0], xmm15
000074fc937d1dee  sub rsp, 0x30
000074fc937d1df2  movaps [rsp], xmm14
000074fc937d1df7  movaps [rsp+0x10], xmm13
000074fc937d1dfd  movaps [rsp+0x20], xmm2
000074fc937d1e02  lea rdi, [rsp]
000074fc937d1e06  mov esi, 0x00
000074fc937d1e0b  mov rax, 0x5D72CBC20530
000074fc937d1e15  call rax
000074fc937d1e17  movaps xmm14, [rsp]
000074fc937d1e1c  add rsp, 0x30
000074fc937d1e20  vmovaps xmm0, [rsp]
000074fc937d1e25  vmovaps xmm1, [rsp+0x10]
000074fc937d1e2b  vmovaps xmm2, [rsp+0x20]
000074fc937d1e31  vmovaps xmm3, [rsp+0x30]
000074fc937d1e37  vmovaps xmm4, [rsp+0x40]
000074fc937d1e3d  vmovaps xmm5, [rsp+0x50]
000074fc937d1e43  vmovaps xmm6, [rsp+0x60]
000074fc937d1e49  vmovaps xmm7, [rsp+0x70]
000074fc937d1e4f  vmovaps xmm8, [rsp+0x80]
000074fc937d1e58  vmovaps xmm9, [rsp+0x90]
000074fc937d1e61  vmovaps xmm10, [rsp+0xA0]
000074fc937d1e6a  vmovaps xmm11, [rsp+0xB0]
000074fc937d1e73  vmovaps xmm12, [rsp+0xC0]
000074fc937d1e7c  vmovaps xmm13, [rsp+0xD0]
000074fc937d1e85  vmovaps xmm15, [rsp+0xE0]
000074fc937d1e8e  add rsp, 0xF0
000074fc937d1e95  pop r11
000074fc937d1e97  pop r10
000074fc937d1e99  pop r9
000074fc937d1e9b  pop r8
000074fc937d1e9d  pop rsi
000074fc937d1e9e  pop rdi
000074fc937d1e9f  pop rdx
000074fc937d1ea0  pop rcx
000074fc937d1ea1  pop rax
000074fc937d1ea2  add rsp, 0x08
000074fc937d1ea6  jmp 0x000074FC937CFB24
000074fc937d1eab  sub rsp, 0x08
000074fc937d1eaf  push rax
000074fc937d1eb0  push rcx
000074fc937d1eb1  push rdx
000074fc937d1eb2  push rdi
000074fc937d1eb3  push rsi
000074fc937d1eb4  push r8
000074fc937d1eb6  push r9
000074fc937d1eb8  push r10
000074fc937d1eba  push r11
000074fc937d1ebc  sub rsp, 0xF0
000074fc937d1ec3  vmovaps [rsp], xmm0
000074fc937d1ec8  vmovaps [rsp+0x10], xmm2
000074fc937d1ece  vmovaps [rsp+0x20], xmm3
000074fc937d1ed4  vmovaps [rsp+0x30], xmm4
000074fc937d1eda  vmovaps [rsp+0x40], xmm5
000074fc937d1ee0  vmovaps [rsp+0x50], xmm6
000074fc937d1ee6  vmovaps [rsp+0x60], xmm7
000074fc937d1eec  vmovaps [rsp+0x70], xmm8
000074fc937d1ef2  vmovaps [rsp+0x80], xmm9
000074fc937d1efb  vmovaps [rsp+0x90], xmm10
000074fc937d1f04  vmovaps [rsp+0xA0], xmm11
000074fc937d1f0d  vmovaps [rsp+0xB0], xmm12
000074fc937d1f16  vmovaps [rsp+0xC0], xmm13
000074fc937d1f1f  vmovaps [rsp+0xD0], xmm14
000074fc937d1f28  vmovaps [rsp+0xE0], xmm15
000074fc937d1f31  sub rsp, 0x30
000074fc937d1f35  movaps [rsp], xmm1
000074fc937d1f39  movaps [rsp+0x10], xmm13
000074fc937d1f3f  movaps [rsp+0x20], xmm2
000074fc937d1f44  lea rdi, [rsp]
000074fc937d1f48  mov esi, 0x00
000074fc937d1f4d  mov rax, 0x5D72CBC20530
000074fc937d1f57  call rax
000074fc937d1f59  movaps xmm1, [rsp]
000074fc937d1f5d  add rsp, 0x30
000074fc937d1f61  vmovaps xmm0, [rsp]
000074fc937d1f66  vmovaps xmm2, [rsp+0x10]
000074fc937d1f6c  vmovaps xmm3, [rsp+0x20]
000074fc937d1f72  vmovaps xmm4, [rsp+0x30]
000074fc937d1f78  vmovaps xmm5, [rsp+0x40]
000074fc937d1f7e  vmovaps xmm6, [rsp+0x50]
000074fc937d1f84  vmovaps xmm7, [rsp+0x60]
000074fc937d1f8a  vmovaps xmm8, [rsp+0x70]
000074fc937d1f90  vmovaps xmm9, [rsp+0x80]
000074fc937d1f99  vmovaps xmm10, [rsp+0x90]
000074fc937d1fa2  vmovaps xmm11, [rsp+0xA0]
000074fc937d1fab  vmovaps xmm12, [rsp+0xB0]
000074fc937d1fb4  vmovaps xmm13, [rsp+0xC0]
000074fc937d1fbd  vmovaps xmm14, [rsp+0xD0]
000074fc937d1fc6  vmovaps xmm15, [rsp+0xE0]
000074fc937d1fcf  add rsp, 0xF0
000074fc937d1fd6  pop r11
000074fc937d1fd8  pop r10
000074fc937d1fda  pop r9
000074fc937d1fdc  pop r8
000074fc937d1fde  pop rsi
000074fc937d1fdf  pop rdi
000074fc937d1fe0  pop rdx
000074fc937d1fe1  pop rcx
000074fc937d1fe2  pop rax
000074fc937d1fe3  add rsp, 0x08
000074fc937d1fe7  jmp 0x000074FC937CFB52
000074fc937d1fec  sub rsp, 0x08
000074fc937d1ff0  push rax
000074fc937d1ff1  push rcx
000074fc937d1ff2  push rdx
000074fc937d1ff3  push rdi
000074fc937d1ff4  push rsi
000074fc937d1ff5  push r8
000074fc937d1ff7  push r9
000074fc937d1ff9  push r10
000074fc937d1ffb  push r11
000074fc937d1ffd  sub rsp, 0xF0
000074fc937d2004  vmovaps [rsp], xmm0
000074fc937d2009  vmovaps [rsp+0x10], xmm1
000074fc937d200f  vmovaps [rsp+0x20], xmm3
000074fc937d2015  vmovaps [rsp+0x30], xmm4
000074fc937d201b  vmovaps [rsp+0x40], xmm5
000074fc937d2021  vmovaps [rsp+0x50], xmm6
000074fc937d2027  vmovaps [rsp+0x60], xmm7
000074fc937d202d  vmovaps [rsp+0x70], xmm8
000074fc937d2033  vmovaps [rsp+0x80], xmm9
000074fc937d203c  vmovaps [rsp+0x90], xmm10
000074fc937d2045  vmovaps [rsp+0xA0], xmm11
000074fc937d204e  vmovaps [rsp+0xB0], xmm12
000074fc937d2057  vmovaps [rsp+0xC0], xmm13
000074fc937d2060  vmovaps [rsp+0xD0], xmm14
000074fc937d2069  vmovaps [rsp+0xE0], xmm15
000074fc937d2072  sub rsp, 0x30
000074fc937d2076  movaps [rsp], xmm2
000074fc937d207a  movaps [rsp+0x10], xmm1
000074fc937d207f  movaps [rsp+0x20], xmm13
000074fc937d2085  lea rdi, [rsp]
000074fc937d2089  mov esi, 0x00
000074fc937d208e  mov rax, 0x5D72CBC20530
000074fc937d2098  call rax
000074fc937d209a  movaps xmm2, [rsp]
000074fc937d209e  add rsp, 0x30
000074fc937d20a2  vmovaps xmm0, [rsp]
000074fc937d20a7  vmovaps xmm1, [rsp+0x10]
000074fc937d20ad  vmovaps xmm3, [rsp+0x20]
000074fc937d20b3  vmovaps xmm4, [rsp+0x30]
000074fc937d20b9  vmovaps xmm5, [rsp+0x40]
000074fc937d20bf  vmovaps xmm6, [rsp+0x50]
000074fc937d20c5  vmovaps xmm7, [rsp+0x60]
000074fc937d20cb  vmovaps xmm8, [rsp+0x70]
000074fc937d20d1  vmovaps xmm9, [rsp+0x80]
000074fc937d20da  vmovaps xmm10, [rsp+0x90]
000074fc937d20e3  vmovaps xmm11, [rsp+0xA0]
000074fc937d20ec  vmovaps xmm12, [rsp+0xB0]
000074fc937d20f5  vmovaps xmm13, [rsp+0xC0]
000074fc937d20fe  vmovaps xmm14, [rsp+0xD0]
000074fc937d2107  vmovaps xmm15, [rsp+0xE0]
000074fc937d2110  add rsp, 0xF0
000074fc937d2117  pop r11
000074fc937d2119  pop r10
000074fc937d211b  pop r9
000074fc937d211d  pop r8
000074fc937d211f  pop rsi
000074fc937d2120  pop rdi
000074fc937d2121  pop rdx
000074fc937d2122  pop rcx
000074fc937d2123  pop rax
000074fc937d2124  add rsp, 0x08
000074fc937d2128  jmp 0x000074FC937CFBAB
000074fc937d212d  call 0x000074FC935FF430
000074fc937d2132  jmp 0x000074FC937CFBB8
000074fc937d2137  sub rsp, 0x08
000074fc937d213b  push rax
000074fc937d213c  push rcx
000074fc937d213d  push rdx
000074fc937d213e  push rdi
000074fc937d213f  push rsi
000074fc937d2140  push r8
000074fc937d2142  push r9
000074fc937d2144  push r10
000074fc937d2146  push r11
000074fc937d2148  sub rsp, 0xF0
000074fc937d214f  vmovaps [rsp], xmm0
000074fc937d2154  vmovaps [rsp+0x10], xmm1
000074fc937d215a  vmovaps [rsp+0x20], xmm2
000074fc937d2160  vmovaps [rsp+0x30], xmm3
000074fc937d2166  vmovaps [rsp+0x40], xmm4
000074fc937d216c  vmovaps [rsp+0x50], xmm5
000074fc937d2172  vmovaps [rsp+0x60], xmm6
000074fc937d2178  vmovaps [rsp+0x70], xmm7
000074fc937d217e  vmovaps [rsp+0x80], xmm8
000074fc937d2187  vmovaps [rsp+0x90], xmm9
000074fc937d2190  vmovaps [rsp+0xA0], xmm10
000074fc937d2199  vmovaps [rsp+0xB0], xmm11
000074fc937d21a2  vmovaps [rsp+0xC0], xmm12
000074fc937d21ab  vmovaps [rsp+0xD0], xmm13
000074fc937d21b4  vmovaps [rsp+0xE0], xmm14
000074fc937d21bd  sub rsp, 0x30
000074fc937d21c1  movaps [rsp], xmm15
000074fc937d21c6  movaps [rsp+0x10], xmm13
000074fc937d21cc  movaps [rsp+0x20], xmm1
000074fc937d21d1  lea rdi, [rsp]
000074fc937d21d5  mov esi, 0x00
000074fc937d21da  mov rax, 0x5D72CBC20530
000074fc937d21e4  call rax
000074fc937d21e6  movaps xmm15, [rsp]
000074fc937d21eb  add rsp, 0x30
000074fc937d21ef  vmovaps xmm0, [rsp]
000074fc937d21f4  vmovaps xmm1, [rsp+0x10]
000074fc937d21fa  vmovaps xmm2, [rsp+0x20]
000074fc937d2200  vmovaps xmm3, [rsp+0x30]
000074fc937d2206  vmovaps xmm4, [rsp+0x40]
000074fc937d220c  vmovaps xmm5, [rsp+0x50]
000074fc937d2212  vmovaps xmm6, [rsp+0x60]
000074fc937d2218  vmovaps xmm7, [rsp+0x70]
000074fc937d221e  vmovaps xmm8, [rsp+0x80]
000074fc937d2227  vmovaps xmm9, [rsp+0x90]
000074fc937d2230  vmovaps xmm10, [rsp+0xA0]
000074fc937d2239  vmovaps xmm11, [rsp+0xB0]
000074fc937d2242  vmovaps xmm12, [rsp+0xC0]
000074fc937d224b  vmovaps xmm13, [rsp+0xD0]
000074fc937d2254  vmovaps xmm14, [rsp+0xE0]
000074fc937d225d  add rsp, 0xF0
000074fc937d2264  pop r11
000074fc937d2266  pop r10
000074fc937d2268  pop r9
000074fc937d226a  pop r8
000074fc937d226c  pop rsi
000074fc937d226d  pop rdi
000074fc937d226e  pop rdx
000074fc937d226f  pop rcx
000074fc937d2270  pop rax
000074fc937d2271  add rsp, 0x08
000074fc937d2275  jmp 0x000074FC937CFBF7
000074fc937d227a  sub rsp, 0x08
000074fc937d227e  push rax
000074fc937d227f  push rcx
000074fc937d2280  push rdx
000074fc937d2281  push rdi
000074fc937d2282  push rsi
000074fc937d2283  push r8
000074fc937d2285  push r9
000074fc937d2287  push r10
000074fc937d2289  push r11
000074fc937d228b  sub rsp, 0xF0
000074fc937d2292  vmovaps [rsp], xmm0
000074fc937d2297  vmovaps [rsp+0x10], xmm1
000074fc937d229d  vmovaps [rsp+0x20], xmm2
000074fc937d22a3  vmovaps [rsp+0x30], xmm3
000074fc937d22a9  vmovaps [rsp+0x40], xmm4
000074fc937d22af  vmovaps [rsp+0x50], xmm5
000074fc937d22b5  vmovaps [rsp+0x60], xmm6
000074fc937d22bb  vmovaps [rsp+0x70], xmm7
000074fc937d22c1  vmovaps [rsp+0x80], xmm8
000074fc937d22ca  vmovaps [rsp+0x90], xmm9
000074fc937d22d3  vmovaps [rsp+0xA0], xmm10
000074fc937d22dc  vmovaps [rsp+0xB0], xmm11
000074fc937d22e5  vmovaps [rsp+0xC0], xmm12
000074fc937d22ee  vmovaps [rsp+0xD0], xmm13
000074fc937d22f7  vmovaps [rsp+0xE0], xmm15
000074fc937d2300  sub rsp, 0x30
000074fc937d2304  movaps [rsp], xmm14
000074fc937d2309  movaps [rsp+0x10], xmm11
000074fc937d230f  movaps [rsp+0x20], xmm1
000074fc937d2314  lea rdi, [rsp]
000074fc937d2318  mov esi, 0x00
000074fc937d231d  mov rax, 0x5D72CBC20530
000074fc937d2327  call rax
000074fc937d2329  movaps xmm14, [rsp]
000074fc937d232e  add rsp, 0x30
000074fc937d2332  vmovaps xmm0, [rsp]
000074fc937d2337  vmovaps xmm1, [rsp+0x10]
000074fc937d233d  vmovaps xmm2, [rsp+0x20]
000074fc937d2343  vmovaps xmm3, [rsp+0x30]
000074fc937d2349  vmovaps xmm4, [rsp+0x40]
000074fc937d234f  vmovaps xmm5, [rsp+0x50]
000074fc937d2355  vmovaps xmm6, [rsp+0x60]
000074fc937d235b  vmovaps xmm7, [rsp+0x70]
000074fc937d2361  vmovaps xmm8, [rsp+0x80]
000074fc937d236a  vmovaps xmm9, [rsp+0x90]
000074fc937d2373  vmovaps xmm10, [rsp+0xA0]
000074fc937d237c  vmovaps xmm11, [rsp+0xB0]
000074fc937d2385  vmovaps xmm12, [rsp+0xC0]
000074fc937d238e  vmovaps xmm13, [rsp+0xD0]
000074fc937d2397  vmovaps xmm15, [rsp+0xE0]
000074fc937d23a0  add rsp, 0xF0
000074fc937d23a7  pop r11
000074fc937d23a9  pop r10
000074fc937d23ab  pop r9
000074fc937d23ad  pop r8
000074fc937d23af  pop rsi
000074fc937d23b0  pop rdi
000074fc937d23b1  pop rdx
000074fc937d23b2  pop rcx
000074fc937d23b3  pop rax
000074fc937d23b4  add rsp, 0x08
000074fc937d23b8  jmp 0x000074FC937CFC21
000074fc937d23bd  sub rsp, 0x08
000074fc937d23c1  push rax
000074fc937d23c2  push rcx
000074fc937d23c3  push rdx
000074fc937d23c4  push rdi
000074fc937d23c5  push rsi
000074fc937d23c6  push r8
000074fc937d23c8  push r9
000074fc937d23ca  push r10
000074fc937d23cc  push r11
000074fc937d23ce  sub rsp, 0xF0
000074fc937d23d5  vmovaps [rsp], xmm0
000074fc937d23da  vmovaps [rsp+0x10], xmm1
000074fc937d23e0  vmovaps [rsp+0x20], xmm2
000074fc937d23e6  vmovaps [rsp+0x30], xmm3
000074fc937d23ec  vmovaps [rsp+0x40], xmm4
000074fc937d23f2  vmovaps [rsp+0x50], xmm5
000074fc937d23f8  vmovaps [rsp+0x60], xmm6
000074fc937d23fe  vmovaps [rsp+0x70], xmm7
000074fc937d2404  vmovaps [rsp+0x80], xmm8
000074fc937d240d  vmovaps [rsp+0x90], xmm9
000074fc937d2416  vmovaps [rsp+0xA0], xmm10
000074fc937d241f  vmovaps [rsp+0xB0], xmm11
000074fc937d2428  vmovaps [rsp+0xC0], xmm12
000074fc937d2431  vmovaps [rsp+0xD0], xmm14
000074fc937d243a  vmovaps [rsp+0xE0], xmm15
000074fc937d2443  sub rsp, 0x30
000074fc937d2447  movaps [rsp], xmm13
000074fc937d244c  movaps [rsp+0x10], xmm11
000074fc937d2452  movaps [rsp+0x20], xmm1
000074fc937d2457  lea rdi, [rsp]
000074fc937d245b  mov esi, 0x00
000074fc937d2460  mov rax, 0x5D72CBC20530
000074fc937d246a  call rax
000074fc937d246c  movaps xmm13, [rsp]
000074fc937d2471  add rsp, 0x30
000074fc937d2475  vmovaps xmm0, [rsp]
000074fc937d247a  vmovaps xmm1, [rsp+0x10]
000074fc937d2480  vmovaps xmm2, [rsp+0x20]
000074fc937d2486  vmovaps xmm3, [rsp+0x30]
000074fc937d248c  vmovaps xmm4, [rsp+0x40]
000074fc937d2492  vmovaps xmm5, [rsp+0x50]
000074fc937d2498  vmovaps xmm6, [rsp+0x60]
000074fc937d249e  vmovaps xmm7, [rsp+0x70]
000074fc937d24a4  vmovaps xmm8, [rsp+0x80]
000074fc937d24ad  vmovaps xmm9, [rsp+0x90]
000074fc937d24b6  vmovaps xmm10, [rsp+0xA0]
000074fc937d24bf  vmovaps xmm11, [rsp+0xB0]
000074fc937d24c8  vmovaps xmm12, [rsp+0xC0]
000074fc937d24d1  vmovaps xmm14, [rsp+0xD0]
000074fc937d24da  vmovaps xmm15, [rsp+0xE0]
000074fc937d24e3  add rsp, 0xF0
000074fc937d24ea  pop r11
000074fc937d24ec  pop r10
000074fc937d24ee  pop r9
000074fc937d24f0  pop r8
000074fc937d24f2  pop rsi
000074fc937d24f3  pop rdi
000074fc937d24f4  pop rdx
000074fc937d24f5  pop rcx
000074fc937d24f6  pop rax
000074fc937d24f7  add rsp, 0x08
000074fc937d24fb  jmp 0x000074FC937CFC76
000074fc937d2500  call 0x000074FC935FF430
000074fc937d2505  jmp 0x000074FC937CFC83
000074fc937d250a  sub rsp, 0x08
000074fc937d250e  push rax
000074fc937d250f  push rcx
000074fc937d2510  push rdx
000074fc937d2511  push rdi
000074fc937d2512  push rsi
000074fc937d2513  push r8
000074fc937d2515  push r9
000074fc937d2517  push r10
000074fc937d2519  push r11
000074fc937d251b  sub rsp, 0xF0
000074fc937d2522  vmovaps [rsp], xmm0
000074fc937d2527  vmovaps [rsp+0x10], xmm1
000074fc937d252d  vmovaps [rsp+0x20], xmm2
000074fc937d2533  vmovaps [rsp+0x30], xmm3
000074fc937d2539  vmovaps [rsp+0x40], xmm4
000074fc937d253f  vmovaps [rsp+0x50], xmm5
000074fc937d2545  vmovaps [rsp+0x60], xmm6
000074fc937d254b  vmovaps [rsp+0x70], xmm7
000074fc937d2551  vmovaps [rsp+0x80], xmm8
000074fc937d255a  vmovaps [rsp+0x90], xmm9
000074fc937d2563  vmovaps [rsp+0xA0], xmm10
000074fc937d256c  vmovaps [rsp+0xB0], xmm11
000074fc937d2575  vmovaps [rsp+0xC0], xmm12
000074fc937d257e  vmovaps [rsp+0xD0], xmm13
000074fc937d2587  vmovaps [rsp+0xE0], xmm14
000074fc937d2590  sub rsp, 0x30
000074fc937d2594  movaps [rsp], xmm15
000074fc937d2599  movaps [rsp+0x10], xmm11
000074fc937d259f  movaps [rsp+0x20], xmm1
000074fc937d25a4  lea rdi, [rsp]
000074fc937d25a8  mov esi, 0x00
000074fc937d25ad  mov rax, 0x5D72CBC20530
000074fc937d25b7  call rax
000074fc937d25b9  movaps xmm15, [rsp]
000074fc937d25be  add rsp, 0x30
000074fc937d25c2  vmovaps xmm0, [rsp]
000074fc937d25c7  vmovaps xmm1, [rsp+0x10]
000074fc937d25cd  vmovaps xmm2, [rsp+0x20]
000074fc937d25d3  vmovaps xmm3, [rsp+0x30]
000074fc937d25d9  vmovaps xmm4, [rsp+0x40]
000074fc937d25df  vmovaps xmm5, [rsp+0x50]
000074fc937d25e5  vmovaps xmm6, [rsp+0x60]
000074fc937d25eb  vmovaps xmm7, [rsp+0x70]
000074fc937d25f1  vmovaps xmm8, [rsp+0x80]
000074fc937d25fa  vmovaps xmm9, [rsp+0x90]
000074fc937d2603  vmovaps xmm10, [rsp+0xA0]
000074fc937d260c  vmovaps xmm11, [rsp+0xB0]
000074fc937d2615  vmovaps xmm12, [rsp+0xC0]
000074fc937d261e  vmovaps xmm13, [rsp+0xD0]
000074fc937d2627  vmovaps xmm14, [rsp+0xE0]
000074fc937d2630  add rsp, 0xF0
000074fc937d2637  pop r11
000074fc937d2639  pop r10
000074fc937d263b  pop r9
000074fc937d263d  pop r8
000074fc937d263f  pop rsi
000074fc937d2640  pop rdi
000074fc937d2641  pop rdx
000074fc937d2642  pop rcx
000074fc937d2643  pop rax
000074fc937d2644  add rsp, 0x08
000074fc937d2648  jmp 0x000074FC937CFCBC
000074fc937d264d  sub rsp, 0x08
000074fc937d2651  push rax
000074fc937d2652  push rcx
000074fc937d2653  push rdx
000074fc937d2654  push rdi
000074fc937d2655  push rsi
000074fc937d2656  push r8
000074fc937d2658  push r9
000074fc937d265a  push r10
000074fc937d265c  push r11
000074fc937d265e  sub rsp, 0xF0
000074fc937d2665  vmovaps [rsp], xmm0
000074fc937d266a  vmovaps [rsp+0x10], xmm1
000074fc937d2670  vmovaps [rsp+0x20], xmm2
000074fc937d2676  vmovaps [rsp+0x30], xmm3
000074fc937d267c  vmovaps [rsp+0x40], xmm4
000074fc937d2682  vmovaps [rsp+0x50], xmm5
000074fc937d2688  vmovaps [rsp+0x60], xmm6
000074fc937d268e  vmovaps [rsp+0x70], xmm7
000074fc937d2694  vmovaps [rsp+0x80], xmm8
000074fc937d269d  vmovaps [rsp+0x90], xmm9
000074fc937d26a6  vmovaps [rsp+0xA0], xmm10
000074fc937d26af  vmovaps [rsp+0xB0], xmm12
000074fc937d26b8  vmovaps [rsp+0xC0], xmm13
000074fc937d26c1  vmovaps [rsp+0xD0], xmm14
000074fc937d26ca  vmovaps [rsp+0xE0], xmm15
000074fc937d26d3  sub rsp, 0x30
000074fc937d26d7  movaps [rsp], xmm11
000074fc937d26dc  movaps [rsp+0x10], xmm6
000074fc937d26e1  movaps [rsp+0x20], xmm14
000074fc937d26e7  lea rdi, [rsp]
000074fc937d26eb  mov esi, 0x00
000074fc937d26f0  mov rax, 0x5D72CBC20530
000074fc937d26fa  call rax
000074fc937d26fc  movaps xmm11, [rsp]
000074fc937d2701  add rsp, 0x30
000074fc937d2705  vmovaps xmm0, [rsp]
000074fc937d270a  vmovaps xmm1, [rsp+0x10]
000074fc937d2710  vmovaps xmm2, [rsp+0x20]
000074fc937d2716  vmovaps xmm3, [rsp+0x30]
000074fc937d271c  vmovaps xmm4, [rsp+0x40]
000074fc937d2722  vmovaps xmm5, [rsp+0x50]
000074fc937d2728  vmovaps xmm6, [rsp+0x60]
000074fc937d272e  vmovaps xmm7, [rsp+0x70]
000074fc937d2734  vmovaps xmm8, [rsp+0x80]
000074fc937d273d  vmovaps xmm9, [rsp+0x90]
000074fc937d2746  vmovaps xmm10, [rsp+0xA0]
000074fc937d274f  vmovaps xmm12, [rsp+0xB0]
000074fc937d2758  vmovaps xmm13, [rsp+0xC0]
000074fc937d2761  vmovaps xmm14, [rsp+0xD0]
000074fc937d276a  vmovaps xmm15, [rsp+0xE0]
000074fc937d2773  add rsp, 0xF0
000074fc937d277a  pop r11
000074fc937d277c  pop r10
000074fc937d277e  pop r9
000074fc937d2780  pop r8
000074fc937d2782  pop rsi
000074fc937d2783  pop rdi
000074fc937d2784  pop rdx
000074fc937d2785  pop rcx
000074fc937d2786  pop rax
000074fc937d2787  add rsp, 0x08
000074fc937d278b  jmp 0x000074FC937CFD34
000074fc937d2790  call 0x000074FC935FF430
000074fc937d2795  jmp 0x000074FC937CFD3E
000074fc937d279a  sub rsp, 0x08
000074fc937d279e  push rax
000074fc937d279f  push rcx
000074fc937d27a0  push rdx
000074fc937d27a1  push rdi
000074fc937d27a2  push rsi
000074fc937d27a3  push r8
000074fc937d27a5  push r9
000074fc937d27a7  push r10
000074fc937d27a9  push r11
000074fc937d27ab  sub rsp, 0xF0
000074fc937d27b2  vmovaps [rsp], xmm0
000074fc937d27b7  vmovaps [rsp+0x10], xmm1
000074fc937d27bd  vmovaps [rsp+0x20], xmm2
000074fc937d27c3  vmovaps [rsp+0x30], xmm3
000074fc937d27c9  vmovaps [rsp+0x40], xmm4
000074fc937d27cf  vmovaps [rsp+0x50], xmm5
000074fc937d27d5  vmovaps [rsp+0x60], xmm6
000074fc937d27db  vmovaps [rsp+0x70], xmm7
000074fc937d27e1  vmovaps [rsp+0x80], xmm8
000074fc937d27ea  vmovaps [rsp+0x90], xmm9
000074fc937d27f3  vmovaps [rsp+0xA0], xmm10
000074fc937d27fc  vmovaps [rsp+0xB0], xmm11
000074fc937d2805  vmovaps [rsp+0xC0], xmm12
000074fc937d280e  vmovaps [rsp+0xD0], xmm13
000074fc937d2817  vmovaps [rsp+0xE0], xmm15
000074fc937d2820  sub rsp, 0x30
000074fc937d2824  movaps [rsp], xmm14
000074fc937d2829  movaps [rsp+0x10], xmm6
000074fc937d282e  movaps [rsp+0x20], xmm2
000074fc937d2833  lea rdi, [rsp]
000074fc937d2837  mov esi, 0x00
000074fc937d283c  mov rax, 0x5D72CBC20530
000074fc937d2846  call rax
000074fc937d2848  movaps xmm14, [rsp]
000074fc937d284d  add rsp, 0x30
000074fc937d2851  vmovaps xmm0, [rsp]
000074fc937d2856  vmovaps xmm1, [rsp+0x10]
000074fc937d285c  vmovaps xmm2, [rsp+0x20]
000074fc937d2862  vmovaps xmm3, [rsp+0x30]
000074fc937d2868  vmovaps xmm4, [rsp+0x40]
000074fc937d286e  vmovaps xmm5, [rsp+0x50]
000074fc937d2874  vmovaps xmm6, [rsp+0x60]
000074fc937d287a  vmovaps xmm7, [rsp+0x70]
000074fc937d2880  vmovaps xmm8, [rsp+0x80]
000074fc937d2889  vmovaps xmm9, [rsp+0x90]
000074fc937d2892  vmovaps xmm10, [rsp+0xA0]
000074fc937d289b  vmovaps xmm11, [rsp+0xB0]
000074fc937d28a4  vmovaps xmm12, [rsp+0xC0]
000074fc937d28ad  vmovaps xmm13, [rsp+0xD0]
000074fc937d28b6  vmovaps xmm15, [rsp+0xE0]
000074fc937d28bf  add rsp, 0xF0
000074fc937d28c6  pop r11
000074fc937d28c8  pop r10
000074fc937d28ca  pop r9
000074fc937d28cc  pop r8
000074fc937d28ce  pop rsi
000074fc937d28cf  pop rdi
000074fc937d28d0  pop rdx
000074fc937d28d1  pop rcx
000074fc937d28d2  pop rax
000074fc937d28d3  add rsp, 0x08
000074fc937d28d7  jmp 0x000074FC937CFD72
000074fc937d28dc  sub rsp, 0x08
000074fc937d28e0  push rax
000074fc937d28e1  push rcx
000074fc937d28e2  push rdx
000074fc937d28e3  push rdi
000074fc937d28e4  push rsi
000074fc937d28e5  push r8
000074fc937d28e7  push r9
000074fc937d28e9  push r10
000074fc937d28eb  push r11
000074fc937d28ed  sub rsp, 0xF0
000074fc937d28f4  vmovaps [rsp], xmm0
000074fc937d28f9  vmovaps [rsp+0x10], xmm1
000074fc937d28ff  vmovaps [rsp+0x20], xmm2
000074fc937d2905  vmovaps [rsp+0x30], xmm3
000074fc937d290b  vmovaps [rsp+0x40], xmm4
000074fc937d2911  vmovaps [rsp+0x50], xmm5
000074fc937d2917  vmovaps [rsp+0x60], xmm7
000074fc937d291d  vmovaps [rsp+0x70], xmm8
000074fc937d2923  vmovaps [rsp+0x80], xmm9
000074fc937d292c  vmovaps [rsp+0x90], xmm10
000074fc937d2935  vmovaps [rsp+0xA0], xmm11
000074fc937d293e  vmovaps [rsp+0xB0], xmm12
000074fc937d2947  vmovaps [rsp+0xC0], xmm13
000074fc937d2950  vmovaps [rsp+0xD0], xmm14
000074fc937d2959  vmovaps [rsp+0xE0], xmm15
000074fc937d2962  sub rsp, 0x30
000074fc937d2966  movaps [rsp], xmm6
000074fc937d296a  movaps [rsp+0x10], xmm5
000074fc937d296f  movaps [rsp+0x20], xmm1
000074fc937d2974  lea rdi, [rsp]
000074fc937d2978  mov esi, 0x00
000074fc937d297d  mov rax, 0x5D72CBC20530
000074fc937d2987  call rax
000074fc937d2989  movaps xmm6, [rsp]
000074fc937d298d  add rsp, 0x30
000074fc937d2991  vmovaps xmm0, [rsp]
000074fc937d2996  vmovaps xmm1, [rsp+0x10]
000074fc937d299c  vmovaps xmm2, [rsp+0x20]
000074fc937d29a2  vmovaps xmm3, [rsp+0x30]
000074fc937d29a8  vmovaps xmm4, [rsp+0x40]
000074fc937d29ae  vmovaps xmm5, [rsp+0x50]
000074fc937d29b4  vmovaps xmm7, [rsp+0x60]
000074fc937d29ba  vmovaps xmm8, [rsp+0x70]
000074fc937d29c0  vmovaps xmm9, [rsp+0x80]
000074fc937d29c9  vmovaps xmm10, [rsp+0x90]
000074fc937d29d2  vmovaps xmm11, [rsp+0xA0]
000074fc937d29db  vmovaps xmm12, [rsp+0xB0]
000074fc937d29e4  vmovaps xmm13, [rsp+0xC0]
000074fc937d29ed  vmovaps xmm14, [rsp+0xD0]
000074fc937d29f6  vmovaps xmm15, [rsp+0xE0]
000074fc937d29ff  add rsp, 0xF0
000074fc937d2a06  pop r11
000074fc937d2a08  pop r10
000074fc937d2a0a  pop r9
000074fc937d2a0c  pop r8
000074fc937d2a0e  pop rsi
000074fc937d2a0f  pop rdi
000074fc937d2a10  pop rdx
000074fc937d2a11  pop rcx
000074fc937d2a12  pop rax
000074fc937d2a13  add rsp, 0x08
000074fc937d2a17  jmp 0x000074FC937CFD98
000074fc937d2a1c  sub rsp, 0x08
000074fc937d2a20  push rax
000074fc937d2a21  push rcx
000074fc937d2a22  push rdx
000074fc937d2a23  push rdi
000074fc937d2a24  push rsi
000074fc937d2a25  push r8
000074fc937d2a27  push r9
000074fc937d2a29  push r10
000074fc937d2a2b  push r11
000074fc937d2a2d  sub rsp, 0xF0
000074fc937d2a34  vmovaps [rsp], xmm0
000074fc937d2a39  vmovaps [rsp+0x10], xmm2
000074fc937d2a3f  vmovaps [rsp+0x20], xmm3
000074fc937d2a45  vmovaps [rsp+0x30], xmm4
000074fc937d2a4b  vmovaps [rsp+0x40], xmm5
000074fc937d2a51  vmovaps [rsp+0x50], xmm6
000074fc937d2a57  vmovaps [rsp+0x60], xmm7
000074fc937d2a5d  vmovaps [rsp+0x70], xmm8
000074fc937d2a63  vmovaps [rsp+0x80], xmm9
000074fc937d2a6c  vmovaps [rsp+0x90], xmm10
000074fc937d2a75  vmovaps [rsp+0xA0], xmm11
000074fc937d2a7e  vmovaps [rsp+0xB0], xmm12
000074fc937d2a87  vmovaps [rsp+0xC0], xmm13
000074fc937d2a90  vmovaps [rsp+0xD0], xmm14
000074fc937d2a99  vmovaps [rsp+0xE0], xmm15
000074fc937d2aa2  sub rsp, 0x30
000074fc937d2aa6  movaps [rsp], xmm1
000074fc937d2aaa  movaps [rsp+0x10], xmm5
000074fc937d2aaf  movaps [rsp+0x20], xmm13
000074fc937d2ab5  lea rdi, [rsp]
000074fc937d2ab9  mov esi, 0x00
000074fc937d2abe  mov rax, 0x5D72CBC20530
000074fc937d2ac8  call rax
000074fc937d2aca  movaps xmm1, [rsp]
000074fc937d2ace  add rsp, 0x30
000074fc937d2ad2  vmovaps xmm0, [rsp]
000074fc937d2ad7  vmovaps xmm2, [rsp+0x10]
000074fc937d2add  vmovaps xmm3, [rsp+0x20]
000074fc937d2ae3  vmovaps xmm4, [rsp+0x30]
000074fc937d2ae9  vmovaps xmm5, [rsp+0x40]
000074fc937d2aef  vmovaps xmm6, [rsp+0x50]
000074fc937d2af5  vmovaps xmm7, [rsp+0x60]
000074fc937d2afb  vmovaps xmm8, [rsp+0x70]
000074fc937d2b01  vmovaps xmm9, [rsp+0x80]
000074fc937d2b0a  vmovaps xmm10, [rsp+0x90]
000074fc937d2b13  vmovaps xmm11, [rsp+0xA0]
000074fc937d2b1c  vmovaps xmm12, [rsp+0xB0]
000074fc937d2b25  vmovaps xmm13, [rsp+0xC0]
000074fc937d2b2e  vmovaps xmm14, [rsp+0xD0]
000074fc937d2b37  vmovaps xmm15, [rsp+0xE0]
000074fc937d2b40  add rsp, 0xF0
000074fc937d2b47  pop r11
000074fc937d2b49  pop r10
000074fc937d2b4b  pop r9
000074fc937d2b4d  pop r8
000074fc937d2b4f  pop rsi
000074fc937d2b50  pop rdi
000074fc937d2b51  pop rdx
000074fc937d2b52  pop rcx
000074fc937d2b53  pop rax
000074fc937d2b54  add rsp, 0x08
000074fc937d2b58  jmp 0x000074FC937CFDB6
000074fc937d2b5d  sub rsp, 0x08
000074fc937d2b61  push rax
000074fc937d2b62  push rcx
000074fc937d2b63  push rdx
000074fc937d2b64  push rdi
000074fc937d2b65  push rsi
000074fc937d2b66  push r8
000074fc937d2b68  push r9
000074fc937d2b6a  push r10
000074fc937d2b6c  push r11
000074fc937d2b6e  sub rsp, 0xF0
000074fc937d2b75  vmovaps [rsp], xmm0
000074fc937d2b7a  vmovaps [rsp+0x10], xmm1
000074fc937d2b80  vmovaps [rsp+0x20], xmm2
000074fc937d2b86  vmovaps [rsp+0x30], xmm3
000074fc937d2b8c  vmovaps [rsp+0x40], xmm4
000074fc937d2b92  vmovaps [rsp+0x50], xmm6
000074fc937d2b98  vmovaps [rsp+0x60], xmm7
000074fc937d2b9e  vmovaps [rsp+0x70], xmm8
000074fc937d2ba4  vmovaps [rsp+0x80], xmm9
000074fc937d2bad  vmovaps [rsp+0x90], xmm10
000074fc937d2bb6  vmovaps [rsp+0xA0], xmm11
000074fc937d2bbf  vmovaps [rsp+0xB0], xmm12
000074fc937d2bc8  vmovaps [rsp+0xC0], xmm13
000074fc937d2bd1  vmovaps [rsp+0xD0], xmm14
000074fc937d2bda  vmovaps [rsp+0xE0], xmm15
000074fc937d2be3  sub rsp, 0x30
000074fc937d2be7  movaps [rsp], xmm5
000074fc937d2beb  movaps [rsp+0x10], xmm2
000074fc937d2bf0  movaps [rsp+0x20], xmm13
000074fc937d2bf6  lea rdi, [rsp]
000074fc937d2bfa  mov esi, 0x00
000074fc937d2bff  mov rax, 0x5D72CBC20530
000074fc937d2c09  call rax
000074fc937d2c0b  movaps xmm5, [rsp]
000074fc937d2c0f  add rsp, 0x30
000074fc937d2c13  vmovaps xmm0, [rsp]
000074fc937d2c18  vmovaps xmm1, [rsp+0x10]
000074fc937d2c1e  vmovaps xmm2, [rsp+0x20]
000074fc937d2c24  vmovaps xmm3, [rsp+0x30]
000074fc937d2c2a  vmovaps xmm4, [rsp+0x40]
000074fc937d2c30  vmovaps xmm6, [rsp+0x50]
000074fc937d2c36  vmovaps xmm7, [rsp+0x60]
000074fc937d2c3c  vmovaps xmm8, [rsp+0x70]
000074fc937d2c42  vmovaps xmm9, [rsp+0x80]
000074fc937d2c4b  vmovaps xmm10, [rsp+0x90]
000074fc937d2c54  vmovaps xmm11, [rsp+0xA0]
000074fc937d2c5d  vmovaps xmm12, [rsp+0xB0]
000074fc937d2c66  vmovaps xmm13, [rsp+0xC0]
000074fc937d2c6f  vmovaps xmm14, [rsp+0xD0]
000074fc937d2c78  vmovaps xmm15, [rsp+0xE0]
000074fc937d2c81  add rsp, 0xF0
000074fc937d2c88  pop r11
000074fc937d2c8a  pop r10
000074fc937d2c8c  pop r9
000074fc937d2c8e  pop r8
000074fc937d2c90  pop rsi
000074fc937d2c91  pop rdi
000074fc937d2c92  pop rdx
000074fc937d2c93  pop rcx
000074fc937d2c94  pop rax
000074fc937d2c95  add rsp, 0x08
000074fc937d2c99  jmp 0x000074FC937CFDEC
000074fc937d2c9e  sub rsp, 0x08
000074fc937d2ca2  push rax
000074fc937d2ca3  push rcx
000074fc937d2ca4  push rdx
000074fc937d2ca5  push rdi
000074fc937d2ca6  push rsi
000074fc937d2ca7  push r8
000074fc937d2ca9  push r9
000074fc937d2cab  push r10
000074fc937d2cad  push r11
000074fc937d2caf  sub rsp, 0xF0
000074fc937d2cb6  vmovaps [rsp], xmm0
000074fc937d2cbb  vmovaps [rsp+0x10], xmm1
000074fc937d2cc1  vmovaps [rsp+0x20], xmm2
000074fc937d2cc7  vmovaps [rsp+0x30], xmm3
000074fc937d2ccd  vmovaps [rsp+0x40], xmm4
000074fc937d2cd3  vmovaps [rsp+0x50], xmm5
000074fc937d2cd9  vmovaps [rsp+0x60], xmm6
000074fc937d2cdf  vmovaps [rsp+0x70], xmm7
000074fc937d2ce5  vmovaps [rsp+0x80], xmm8
000074fc937d2cee  vmovaps [rsp+0x90], xmm9
000074fc937d2cf7  vmovaps [rsp+0xA0], xmm10
000074fc937d2d00  vmovaps [rsp+0xB0], xmm11
000074fc937d2d09  vmovaps [rsp+0xC0], xmm12
000074fc937d2d12  vmovaps [rsp+0xD0], xmm14
000074fc937d2d1b  vmovaps [rsp+0xE0], xmm15
000074fc937d2d24  sub rsp, 0x30
000074fc937d2d28  movaps [rsp], xmm13
000074fc937d2d2d  movaps [rsp+0x10], xmm10
000074fc937d2d33  movaps [rsp+0x20], xmm1
000074fc937d2d38  lea rdi, [rsp]
000074fc937d2d3c  mov esi, 0x00
000074fc937d2d41  mov rax, 0x5D72CBC20530
000074fc937d2d4b  call rax
000074fc937d2d4d  movaps xmm13, [rsp]
000074fc937d2d52  add rsp, 0x30
000074fc937d2d56  vmovaps xmm0, [rsp]
000074fc937d2d5b  vmovaps xmm1, [rsp+0x10]
000074fc937d2d61  vmovaps xmm2, [rsp+0x20]
000074fc937d2d67  vmovaps xmm3, [rsp+0x30]
000074fc937d2d6d  vmovaps xmm4, [rsp+0x40]
000074fc937d2d73  vmovaps xmm5, [rsp+0x50]
000074fc937d2d79  vmovaps xmm6, [rsp+0x60]
000074fc937d2d7f  vmovaps xmm7, [rsp+0x70]
000074fc937d2d85  vmovaps xmm8, [rsp+0x80]
000074fc937d2d8e  vmovaps xmm9, [rsp+0x90]
000074fc937d2d97  vmovaps xmm10, [rsp+0xA0]
000074fc937d2da0  vmovaps xmm11, [rsp+0xB0]
000074fc937d2da9  vmovaps xmm12, [rsp+0xC0]
000074fc937d2db2  vmovaps xmm14, [rsp+0xD0]
000074fc937d2dbb  vmovaps xmm15, [rsp+0xE0]
000074fc937d2dc4  add rsp, 0xF0
000074fc937d2dcb  pop r11
000074fc937d2dcd  pop r10
000074fc937d2dcf  pop r9
000074fc937d2dd1  pop r8
000074fc937d2dd3  pop rsi
000074fc937d2dd4  pop rdi
000074fc937d2dd5  pop rdx
000074fc937d2dd6  pop rcx
000074fc937d2dd7  pop rax
000074fc937d2dd8  add rsp, 0x08
000074fc937d2ddc  jmp 0x000074FC937CFE15
000074fc937d2de1  sub rsp, 0x08
000074fc937d2de5  push rax
000074fc937d2de6  push rcx
000074fc937d2de7  push rdx
000074fc937d2de8  push rdi
000074fc937d2de9  push rsi
000074fc937d2dea  push r8
000074fc937d2dec  push r9
000074fc937d2dee  push r10
000074fc937d2df0  push r11
000074fc937d2df2  sub rsp, 0xF0
000074fc937d2df9  vmovaps [rsp], xmm0
000074fc937d2dfe  vmovaps [rsp+0x10], xmm2
000074fc937d2e04  vmovaps [rsp+0x20], xmm3
000074fc937d2e0a  vmovaps [rsp+0x30], xmm4
000074fc937d2e10  vmovaps [rsp+0x40], xmm5
000074fc937d2e16  vmovaps [rsp+0x50], xmm6
000074fc937d2e1c  vmovaps [rsp+0x60], xmm7
000074fc937d2e22  vmovaps [rsp+0x70], xmm8
000074fc937d2e28  vmovaps [rsp+0x80], xmm9
000074fc937d2e31  vmovaps [rsp+0x90], xmm10
000074fc937d2e3a  vmovaps [rsp+0xA0], xmm11
000074fc937d2e43  vmovaps [rsp+0xB0], xmm12
000074fc937d2e4c  vmovaps [rsp+0xC0], xmm13
000074fc937d2e55  vmovaps [rsp+0xD0], xmm14
000074fc937d2e5e  vmovaps [rsp+0xE0], xmm15
000074fc937d2e67  sub rsp, 0x30
000074fc937d2e6b  movaps [rsp], xmm1
000074fc937d2e6f  movaps [rsp+0x10], xmm15
000074fc937d2e75  movaps [rsp+0x20], xmm10
000074fc937d2e7b  lea rdi, [rsp]
000074fc937d2e7f  mov esi, 0x00
000074fc937d2e84  mov rax, 0x5D72CBC20530
000074fc937d2e8e  call rax
000074fc937d2e90  movaps xmm1, [rsp]
000074fc937d2e94  add rsp, 0x30
000074fc937d2e98  vmovaps xmm0, [rsp]
000074fc937d2e9d  vmovaps xmm2, [rsp+0x10]
000074fc937d2ea3  vmovaps xmm3, [rsp+0x20]
000074fc937d2ea9  vmovaps xmm4, [rsp+0x30]
000074fc937d2eaf  vmovaps xmm5, [rsp+0x40]
000074fc937d2eb5  vmovaps xmm6, [rsp+0x50]
000074fc937d2ebb  vmovaps xmm7, [rsp+0x60]
000074fc937d2ec1  vmovaps xmm8, [rsp+0x70]
000074fc937d2ec7  vmovaps xmm9, [rsp+0x80]
000074fc937d2ed0  vmovaps xmm10, [rsp+0x90]
000074fc937d2ed9  vmovaps xmm11, [rsp+0xA0]
000074fc937d2ee2  vmovaps xmm12, [rsp+0xB0]
000074fc937d2eeb  vmovaps xmm13, [rsp+0xC0]
000074fc937d2ef4  vmovaps xmm14, [rsp+0xD0]
000074fc937d2efd  vmovaps xmm15, [rsp+0xE0]
000074fc937d2f06  add rsp, 0xF0
000074fc937d2f0d  pop r11
000074fc937d2f0f  pop r10
000074fc937d2f11  pop r9
000074fc937d2f13  pop r8
000074fc937d2f15  pop rsi
000074fc937d2f16  pop rdi
000074fc937d2f17  pop rdx
000074fc937d2f18  pop rcx
000074fc937d2f19  pop rax
000074fc937d2f1a  add rsp, 0x08
000074fc937d2f1e  jmp 0x000074FC937CFE34
000074fc937d2f23  sub rsp, 0x08
000074fc937d2f27  push rax
000074fc937d2f28  push rcx
000074fc937d2f29  push rdx
000074fc937d2f2a  push rdi
000074fc937d2f2b  push rsi
000074fc937d2f2c  push r8
000074fc937d2f2e  push r9
000074fc937d2f30  push r10
000074fc937d2f32  push r11
000074fc937d2f34  sub rsp, 0xF0
000074fc937d2f3b  vmovaps [rsp], xmm0
000074fc937d2f40  vmovaps [rsp+0x10], xmm1
000074fc937d2f46  vmovaps [rsp+0x20], xmm2
000074fc937d2f4c  vmovaps [rsp+0x30], xmm3
000074fc937d2f52  vmovaps [rsp+0x40], xmm4
000074fc937d2f58  vmovaps [rsp+0x50], xmm5
000074fc937d2f5e  vmovaps [rsp+0x60], xmm6
000074fc937d2f64  vmovaps [rsp+0x70], xmm7
000074fc937d2f6a  vmovaps [rsp+0x80], xmm8
000074fc937d2f73  vmovaps [rsp+0x90], xmm9
000074fc937d2f7c  vmovaps [rsp+0xA0], xmm10
000074fc937d2f85  vmovaps [rsp+0xB0], xmm11
000074fc937d2f8e  vmovaps [rsp+0xC0], xmm12
000074fc937d2f97  vmovaps [rsp+0xD0], xmm13
000074fc937d2fa0  vmovaps [rsp+0xE0], xmm14
000074fc937d2fa9  sub rsp, 0x30
000074fc937d2fad  movaps [rsp], xmm15
000074fc937d2fb2  movaps [rsp+0x10], xmm10
000074fc937d2fb8  movaps [rsp+0x20], xmm11
000074fc937d2fbe  lea rdi, [rsp]
000074fc937d2fc2  mov esi, 0x00
000074fc937d2fc7  mov rax, 0x5D72CBC20530
000074fc937d2fd1  call rax
000074fc937d2fd3  movaps xmm15, [rsp]
000074fc937d2fd8  add rsp, 0x30
000074fc937d2fdc  vmovaps xmm0, [rsp]
000074fc937d2fe1  vmovaps xmm1, [rsp+0x10]
000074fc937d2fe7  vmovaps xmm2, [rsp+0x20]
000074fc937d2fed  vmovaps xmm3, [rsp+0x30]
000074fc937d2ff3  vmovaps xmm4, [rsp+0x40]
000074fc937d2ff9  vmovaps xmm5, [rsp+0x50]
000074fc937d2fff  vmovaps xmm6, [rsp+0x60]
000074fc937d3005  vmovaps xmm7, [rsp+0x70]
000074fc937d300b  vmovaps xmm8, [rsp+0x80]
000074fc937d3014  vmovaps xmm9, [rsp+0x90]
000074fc937d301d  vmovaps xmm10, [rsp+0xA0]
000074fc937d3026  vmovaps xmm11, [rsp+0xB0]
000074fc937d302f  vmovaps xmm12, [rsp+0xC0]
000074fc937d3038  vmovaps xmm13, [rsp+0xD0]
000074fc937d3041  vmovaps xmm14, [rsp+0xE0]
000074fc937d304a  add rsp, 0xF0
000074fc937d3051  pop r11
000074fc937d3053  pop r10
000074fc937d3055  pop r9
000074fc937d3057  pop r8
000074fc937d3059  pop rsi
000074fc937d305a  pop rdi
000074fc937d305b  pop rdx
000074fc937d305c  pop rcx
000074fc937d305d  pop rax
000074fc937d305e  add rsp, 0x08
000074fc937d3062  jmp 0x000074FC937CFE57
000074fc937d3067  sub rsp, 0x08
000074fc937d306b  push rax
000074fc937d306c  push rcx
000074fc937d306d  push rdx
000074fc937d306e  push rdi
000074fc937d306f  push rsi
000074fc937d3070  push r8
000074fc937d3072  push r9
000074fc937d3074  push r10
000074fc937d3076  push r11
000074fc937d3078  sub rsp, 0xF0
000074fc937d307f  vmovaps [rsp], xmm0
000074fc937d3084  vmovaps [rsp+0x10], xmm1
000074fc937d308a  vmovaps [rsp+0x20], xmm2
000074fc937d3090  vmovaps [rsp+0x30], xmm3
000074fc937d3096  vmovaps [rsp+0x40], xmm4
000074fc937d309c  vmovaps [rsp+0x50], xmm5
000074fc937d30a2  vmovaps [rsp+0x60], xmm6
000074fc937d30a8  vmovaps [rsp+0x70], xmm7
000074fc937d30ae  vmovaps [rsp+0x80], xmm8
000074fc937d30b7  vmovaps [rsp+0x90], xmm9
000074fc937d30c0  vmovaps [rsp+0xA0], xmm11
000074fc937d30c9  vmovaps [rsp+0xB0], xmm12
000074fc937d30d2  vmovaps [rsp+0xC0], xmm13
000074fc937d30db  vmovaps [rsp+0xD0], xmm14
000074fc937d30e4  vmovaps [rsp+0xE0], xmm15
000074fc937d30ed  sub rsp, 0x30
000074fc937d30f1  movaps [rsp], xmm10
000074fc937d30f6  movaps [rsp+0x10], xmm12
000074fc937d30fc  movaps [rsp+0x20], xmm11
000074fc937d3102  lea rdi, [rsp]
000074fc937d3106  mov esi, 0x00
000074fc937d310b  mov rax, 0x5D72CBC20530
000074fc937d3115  call rax
000074fc937d3117  movaps xmm10, [rsp]
000074fc937d311c  add rsp, 0x30
000074fc937d3120  vmovaps xmm0, [rsp]
000074fc937d3125  vmovaps xmm1, [rsp+0x10]
000074fc937d312b  vmovaps xmm2, [rsp+0x20]
000074fc937d3131  vmovaps xmm3, [rsp+0x30]
000074fc937d3137  vmovaps xmm4, [rsp+0x40]
000074fc937d313d  vmovaps xmm5, [rsp+0x50]
000074fc937d3143  vmovaps xmm6, [rsp+0x60]
000074fc937d3149  vmovaps xmm7, [rsp+0x70]
000074fc937d314f  vmovaps xmm8, [rsp+0x80]
000074fc937d3158  vmovaps xmm9, [rsp+0x90]
000074fc937d3161  vmovaps xmm11, [rsp+0xA0]
000074fc937d316a  vmovaps xmm12, [rsp+0xB0]
000074fc937d3173  vmovaps xmm13, [rsp+0xC0]
000074fc937d317c  vmovaps xmm14, [rsp+0xD0]
000074fc937d3185  vmovaps xmm15, [rsp+0xE0]
000074fc937d318e  add rsp, 0xF0
000074fc937d3195  pop r11
000074fc937d3197  pop r10
000074fc937d3199  pop r9
000074fc937d319b  pop r8
000074fc937d319d  pop rsi
000074fc937d319e  pop rdi
000074fc937d319f  pop rdx
000074fc937d31a0  pop rcx
000074fc937d31a1  pop rax
000074fc937d31a2  add rsp, 0x08
000074fc937d31a6  jmp 0x000074FC937CFE80
000074fc937d31ab  sub rsp, 0x08
000074fc937d31af  push rax
000074fc937d31b0  push rcx
000074fc937d31b1  push rdx
000074fc937d31b2  push rdi
000074fc937d31b3  push rsi
000074fc937d31b4  push r8
000074fc937d31b6  push r9
000074fc937d31b8  push r10
000074fc937d31ba  push r11
000074fc937d31bc  sub rsp, 0xF0
000074fc937d31c3  vmovaps [rsp], xmm0
000074fc937d31c8  vmovaps [rsp+0x10], xmm1
000074fc937d31ce  vmovaps [rsp+0x20], xmm2
000074fc937d31d4  vmovaps [rsp+0x30], xmm3
000074fc937d31da  vmovaps [rsp+0x40], xmm4
000074fc937d31e0  vmovaps [rsp+0x50], xmm5
000074fc937d31e6  vmovaps [rsp+0x60], xmm6
000074fc937d31ec  vmovaps [rsp+0x70], xmm7
000074fc937d31f2  vmovaps [rsp+0x80], xmm8
000074fc937d31fb  vmovaps [rsp+0x90], xmm9
000074fc937d3204  vmovaps [rsp+0xA0], xmm10
000074fc937d320d  vmovaps [rsp+0xB0], xmm12
000074fc937d3216  vmovaps [rsp+0xC0], xmm13
000074fc937d321f  vmovaps [rsp+0xD0], xmm14
000074fc937d3228  vmovaps [rsp+0xE0], xmm15
000074fc937d3231  sub rsp, 0x30
000074fc937d3235  movaps [rsp], xmm11
000074fc937d323a  movaps [rsp+0x10], xmm2
000074fc937d323f  movaps [rsp+0x20], xmm12
000074fc937d3245  lea rdi, [rsp]
000074fc937d3249  mov esi, 0x00
000074fc937d324e  mov rax, 0x5D72CBC20530
000074fc937d3258  call rax
000074fc937d325a  movaps xmm11, [rsp]
000074fc937d325f  add rsp, 0x30
000074fc937d3263  vmovaps xmm0, [rsp]
000074fc937d3268  vmovaps xmm1, [rsp+0x10]
000074fc937d326e  vmovaps xmm2, [rsp+0x20]
000074fc937d3274  vmovaps xmm3, [rsp+0x30]
000074fc937d327a  vmovaps xmm4, [rsp+0x40]
000074fc937d3280  vmovaps xmm5, [rsp+0x50]
000074fc937d3286  vmovaps xmm6, [rsp+0x60]
000074fc937d328c  vmovaps xmm7, [rsp+0x70]
000074fc937d3292  vmovaps xmm8, [rsp+0x80]
000074fc937d329b  vmovaps xmm9, [rsp+0x90]
000074fc937d32a4  vmovaps xmm10, [rsp+0xA0]
000074fc937d32ad  vmovaps xmm12, [rsp+0xB0]
000074fc937d32b6  vmovaps xmm13, [rsp+0xC0]
000074fc937d32bf  vmovaps xmm14, [rsp+0xD0]
000074fc937d32c8  vmovaps xmm15, [rsp+0xE0]
000074fc937d32d1  add rsp, 0xF0
000074fc937d32d8  pop r11
000074fc937d32da  pop r10
000074fc937d32dc  pop r9
000074fc937d32de  pop r8
000074fc937d32e0  pop rsi
000074fc937d32e1  pop rdi
000074fc937d32e2  pop rdx
000074fc937d32e3  pop rcx
000074fc937d32e4  pop rax
000074fc937d32e5  add rsp, 0x08
000074fc937d32e9  jmp 0x000074FC937CFEB8
000074fc937d32ee  sub rsp, 0x08
000074fc937d32f2  push rax
000074fc937d32f3  push rcx
000074fc937d32f4  push rdx
000074fc937d32f5  push rdi
000074fc937d32f6  push rsi
000074fc937d32f7  push r8
000074fc937d32f9  push r9
000074fc937d32fb  push r10
000074fc937d32fd  push r11
000074fc937d32ff  sub rsp, 0xF0
000074fc937d3306  vmovaps [rsp], xmm0
000074fc937d330b  vmovaps [rsp+0x10], xmm2
000074fc937d3311  vmovaps [rsp+0x20], xmm3
000074fc937d3317  vmovaps [rsp+0x30], xmm4
000074fc937d331d  vmovaps [rsp+0x40], xmm5
000074fc937d3323  vmovaps [rsp+0x50], xmm6
000074fc937d3329  vmovaps [rsp+0x60], xmm7
000074fc937d332f  vmovaps [rsp+0x70], xmm8
000074fc937d3335  vmovaps [rsp+0x80], xmm9
000074fc937d333e  vmovaps [rsp+0x90], xmm10
000074fc937d3347  vmovaps [rsp+0xA0], xmm11
000074fc937d3350  vmovaps [rsp+0xB0], xmm12
000074fc937d3359  vmovaps [rsp+0xC0], xmm13
000074fc937d3362  vmovaps [rsp+0xD0], xmm14
000074fc937d336b  vmovaps [rsp+0xE0], xmm15
000074fc937d3374  sub rsp, 0x30
000074fc937d3378  movaps [rsp], xmm1
000074fc937d337c  movaps [rsp+0x10], xmm14
000074fc937d3382  movaps [rsp+0x20], xmm6
000074fc937d3387  lea rdi, [rsp]
000074fc937d338b  mov esi, 0x00
000074fc937d3390  mov rax, 0x5D72CBC20530
000074fc937d339a  call rax
000074fc937d339c  movaps xmm1, [rsp]
000074fc937d33a0  add rsp, 0x30
000074fc937d33a4  vmovaps xmm0, [rsp]
000074fc937d33a9  vmovaps xmm2, [rsp+0x10]
000074fc937d33af  vmovaps xmm3, [rsp+0x20]
000074fc937d33b5  vmovaps xmm4, [rsp+0x30]
000074fc937d33bb  vmovaps xmm5, [rsp+0x40]
000074fc937d33c1  vmovaps xmm6, [rsp+0x50]
000074fc937d33c7  vmovaps xmm7, [rsp+0x60]
000074fc937d33cd  vmovaps xmm8, [rsp+0x70]
000074fc937d33d3  vmovaps xmm9, [rsp+0x80]
000074fc937d33dc  vmovaps xmm10, [rsp+0x90]
000074fc937d33e5  vmovaps xmm11, [rsp+0xA0]
000074fc937d33ee  vmovaps xmm12, [rsp+0xB0]
000074fc937d33f7  vmovaps xmm13, [rsp+0xC0]
000074fc937d3400  vmovaps xmm14, [rsp+0xD0]
000074fc937d3409  vmovaps xmm15, [rsp+0xE0]
000074fc937d3412  add rsp, 0xF0
000074fc937d3419  pop r11
000074fc937d341b  pop r10
000074fc937d341d  pop r9
000074fc937d341f  pop r8
000074fc937d3421  pop rsi
000074fc937d3422  pop rdi
000074fc937d3423  pop rdx
000074fc937d3424  pop rcx
000074fc937d3425  pop rax
000074fc937d3426  add rsp, 0x08
000074fc937d342a  jmp 0x000074FC937CFED1
000074fc937d342f  sub rsp, 0x08
000074fc937d3433  push rax
000074fc937d3434  push rcx
000074fc937d3435  push rdx
000074fc937d3436  push rdi
000074fc937d3437  push rsi
000074fc937d3438  push r8
000074fc937d343a  push r9
000074fc937d343c  push r10
000074fc937d343e  push r11
000074fc937d3440  sub rsp, 0xF0
000074fc937d3447  vmovaps [rsp], xmm0
000074fc937d344c  vmovaps [rsp+0x10], xmm1
000074fc937d3452  vmovaps [rsp+0x20], xmm2
000074fc937d3458  vmovaps [rsp+0x30], xmm3
000074fc937d345e  vmovaps [rsp+0x40], xmm4
000074fc937d3464  vmovaps [rsp+0x50], xmm5
000074fc937d346a  vmovaps [rsp+0x60], xmm6
000074fc937d3470  vmovaps [rsp+0x70], xmm7
000074fc937d3476  vmovaps [rsp+0x80], xmm8
000074fc937d347f  vmovaps [rsp+0x90], xmm9
000074fc937d3488  vmovaps [rsp+0xA0], xmm10
000074fc937d3491  vmovaps [rsp+0xB0], xmm11
000074fc937d349a  vmovaps [rsp+0xC0], xmm12
000074fc937d34a3  vmovaps [rsp+0xD0], xmm13
000074fc937d34ac  vmovaps [rsp+0xE0], xmm15
000074fc937d34b5  sub rsp, 0x30
000074fc937d34b9  movaps [rsp], xmm14
000074fc937d34be  movaps [rsp+0x10], xmm12
000074fc937d34c4  movaps [rsp+0x20], xmm5
000074fc937d34c9  lea rdi, [rsp]
000074fc937d34cd  mov esi, 0x00
000074fc937d34d2  mov rax, 0x5D72CBC20530
000074fc937d34dc  call rax
000074fc937d34de  movaps xmm14, [rsp]
000074fc937d34e3  add rsp, 0x30
000074fc937d34e7  vmovaps xmm0, [rsp]
000074fc937d34ec  vmovaps xmm1, [rsp+0x10]
000074fc937d34f2  vmovaps xmm2, [rsp+0x20]
000074fc937d34f8  vmovaps xmm3, [rsp+0x30]
000074fc937d34fe  vmovaps xmm4, [rsp+0x40]
000074fc937d3504  vmovaps xmm5, [rsp+0x50]
000074fc937d350a  vmovaps xmm6, [rsp+0x60]
000074fc937d3510  vmovaps xmm7, [rsp+0x70]
000074fc937d3516  vmovaps xmm8, [rsp+0x80]
000074fc937d351f  vmovaps xmm9, [rsp+0x90]
000074fc937d3528  vmovaps xmm10, [rsp+0xA0]
000074fc937d3531  vmovaps xmm11, [rsp+0xB0]
000074fc937d353a  vmovaps xmm12, [rsp+0xC0]
000074fc937d3543  vmovaps xmm13, [rsp+0xD0]
000074fc937d354c  vmovaps xmm15, [rsp+0xE0]
000074fc937d3555  add rsp, 0xF0
000074fc937d355c  pop r11
000074fc937d355e  pop r10
000074fc937d3560  pop r9
000074fc937d3562  pop r8
000074fc937d3564  pop rsi
000074fc937d3565  pop rdi
000074fc937d3566  pop rdx
000074fc937d3567  pop rcx
000074fc937d3568  pop rax
000074fc937d3569  add rsp, 0x08
000074fc937d356d  jmp 0x000074FC937CFEF1
000074fc937d3572  sub rsp, 0x08
000074fc937d3576  push rax
000074fc937d3577  push rcx
000074fc937d3578  push rdx
000074fc937d3579  push rdi
000074fc937d357a  push rsi
000074fc937d357b  push r8
000074fc937d357d  push r9
000074fc937d357f  push r10
000074fc937d3581  push r11
000074fc937d3583  sub rsp, 0xF0
000074fc937d358a  vmovaps [rsp], xmm0
000074fc937d358f  vmovaps [rsp+0x10], xmm1
000074fc937d3595  vmovaps [rsp+0x20], xmm2
000074fc937d359b  vmovaps [rsp+0x30], xmm3
000074fc937d35a1  vmovaps [rsp+0x40], xmm4
000074fc937d35a7  vmovaps [rsp+0x50], xmm5
000074fc937d35ad  vmovaps [rsp+0x60], xmm7
000074fc937d35b3  vmovaps [rsp+0x70], xmm8
000074fc937d35b9  vmovaps [rsp+0x80], xmm9
000074fc937d35c2  vmovaps [rsp+0x90], xmm10
000074fc937d35cb  vmovaps [rsp+0xA0], xmm11
000074fc937d35d4  vmovaps [rsp+0xB0], xmm12
000074fc937d35dd  vmovaps [rsp+0xC0], xmm13
000074fc937d35e6  vmovaps [rsp+0xD0], xmm14
000074fc937d35ef  vmovaps [rsp+0xE0], xmm15
000074fc937d35f8  sub rsp, 0x30
000074fc937d35fc  movaps [rsp], xmm6
000074fc937d3600  movaps [rsp+0x10], xmm9
000074fc937d3606  movaps [rsp+0x20], xmm12
000074fc937d360c  lea rdi, [rsp]
000074fc937d3610  mov esi, 0x00
000074fc937d3615  mov rax, 0x5D72CBC20530
000074fc937d361f  call rax
000074fc937d3621  movaps xmm6, [rsp]
000074fc937d3625  add rsp, 0x30
000074fc937d3629  vmovaps xmm0, [rsp]
000074fc937d362e  vmovaps xmm1, [rsp+0x10]
000074fc937d3634  vmovaps xmm2, [rsp+0x20]
000074fc937d363a  vmovaps xmm3, [rsp+0x30]
000074fc937d3640  vmovaps xmm4, [rsp+0x40]
000074fc937d3646  vmovaps xmm5, [rsp+0x50]
000074fc937d364c  vmovaps xmm7, [rsp+0x60]
000074fc937d3652  vmovaps xmm8, [rsp+0x70]
000074fc937d3658  vmovaps xmm9, [rsp+0x80]
000074fc937d3661  vmovaps xmm10, [rsp+0x90]
000074fc937d366a  vmovaps xmm11, [rsp+0xA0]
000074fc937d3673  vmovaps xmm12, [rsp+0xB0]
000074fc937d367c  vmovaps xmm13, [rsp+0xC0]
000074fc937d3685  vmovaps xmm14, [rsp+0xD0]
000074fc937d368e  vmovaps xmm15, [rsp+0xE0]
000074fc937d3697  add rsp, 0xF0
000074fc937d369e  pop r11
000074fc937d36a0  pop r10
000074fc937d36a2  pop r9
000074fc937d36a4  pop r8
000074fc937d36a6  pop rsi
000074fc937d36a7  pop rdi
000074fc937d36a8  pop rdx
000074fc937d36a9  pop rcx
000074fc937d36aa  pop rax
000074fc937d36ab  add rsp, 0x08
000074fc937d36af  jmp 0x000074FC937CFF19
000074fc937d36b4  sub rsp, 0x08
000074fc937d36b8  push rax
000074fc937d36b9  push rcx
000074fc937d36ba  push rdx
000074fc937d36bb  push rdi
000074fc937d36bc  push rsi
000074fc937d36bd  push r8
000074fc937d36bf  push r9
000074fc937d36c1  push r10
000074fc937d36c3  push r11
000074fc937d36c5  sub rsp, 0xF0
000074fc937d36cc  vmovaps [rsp], xmm0
000074fc937d36d1  vmovaps [rsp+0x10], xmm1
000074fc937d36d7  vmovaps [rsp+0x20], xmm2
000074fc937d36dd  vmovaps [rsp+0x30], xmm3
000074fc937d36e3  vmovaps [rsp+0x40], xmm4
000074fc937d36e9  vmovaps [rsp+0x50], xmm5
000074fc937d36ef  vmovaps [rsp+0x60], xmm6
000074fc937d36f5  vmovaps [rsp+0x70], xmm7
000074fc937d36fb  vmovaps [rsp+0x80], xmm8
000074fc937d3704  vmovaps [rsp+0x90], xmm9
000074fc937d370d  vmovaps [rsp+0xA0], xmm10
000074fc937d3716  vmovaps [rsp+0xB0], xmm11
000074fc937d371f  vmovaps [rsp+0xC0], xmm13
000074fc937d3728  vmovaps [rsp+0xD0], xmm14
000074fc937d3731  vmovaps [rsp+0xE0], xmm15
000074fc937d373a  sub rsp, 0x30
000074fc937d373e  movaps [rsp], xmm12
000074fc937d3743  movaps [rsp+0x10], xmm15
000074fc937d3749  movaps [rsp+0x20], xmm13
000074fc937d374f  lea rdi, [rsp]
000074fc937d3753  mov esi, 0x00
000074fc937d3758  mov rax, 0x5D72CBC20530
000074fc937d3762  call rax
000074fc937d3764  movaps xmm12, [rsp]
000074fc937d3769  add rsp, 0x30
000074fc937d376d  vmovaps xmm0, [rsp]
000074fc937d3772  vmovaps xmm1, [rsp+0x10]
000074fc937d3778  vmovaps xmm2, [rsp+0x20]
000074fc937d377e  vmovaps xmm3, [rsp+0x30]
000074fc937d3784  vmovaps xmm4, [rsp+0x40]
000074fc937d378a  vmovaps xmm5, [rsp+0x50]
000074fc937d3790  vmovaps xmm6, [rsp+0x60]
000074fc937d3796  vmovaps xmm7, [rsp+0x70]
000074fc937d379c  vmovaps xmm8, [rsp+0x80]
000074fc937d37a5  vmovaps xmm9, [rsp+0x90]
000074fc937d37ae  vmovaps xmm10, [rsp+0xA0]
000074fc937d37b7  vmovaps xmm11, [rsp+0xB0]
000074fc937d37c0  vmovaps xmm13, [rsp+0xC0]
000074fc937d37c9  vmovaps xmm14, [rsp+0xD0]
000074fc937d37d2  vmovaps xmm15, [rsp+0xE0]
000074fc937d37db  add rsp, 0xF0
000074fc937d37e2  pop r11
000074fc937d37e4  pop r10
000074fc937d37e6  pop r9
000074fc937d37e8  pop r8
000074fc937d37ea  pop rsi
000074fc937d37eb  pop rdi
000074fc937d37ec  pop rdx
000074fc937d37ed  pop rcx
000074fc937d37ee  pop rax
000074fc937d37ef  add rsp, 0x08
000074fc937d37f3  jmp 0x000074FC937CFF34
000074fc937d37f8  sub rsp, 0x08
000074fc937d37fc  push rax
000074fc937d37fd  push rcx
000074fc937d37fe  push rdx
000074fc937d37ff  push rdi
000074fc937d3800  push rsi
000074fc937d3801  push r8
000074fc937d3803  push r9
000074fc937d3805  push r10
000074fc937d3807  push r11
000074fc937d3809  sub rsp, 0xF0
000074fc937d3810  vmovaps [rsp], xmm0
000074fc937d3815  vmovaps [rsp+0x10], xmm1
000074fc937d381b  vmovaps [rsp+0x20], xmm2
000074fc937d3821  vmovaps [rsp+0x30], xmm3
000074fc937d3827  vmovaps [rsp+0x40], xmm4
000074fc937d382d  vmovaps [rsp+0x50], xmm5
000074fc937d3833  vmovaps [rsp+0x60], xmm6
000074fc937d3839  vmovaps [rsp+0x70], xmm7
000074fc937d383f  vmovaps [rsp+0x80], xmm8
000074fc937d3848  vmovaps [rsp+0x90], xmm9
000074fc937d3851  vmovaps [rsp+0xA0], xmm10
000074fc937d385a  vmovaps [rsp+0xB0], xmm11
000074fc937d3863  vmovaps [rsp+0xC0], xmm12
000074fc937d386c  vmovaps [rsp+0xD0], xmm13
000074fc937d3875  vmovaps [rsp+0xE0], xmm14
000074fc937d387e  sub rsp, 0x30
000074fc937d3882  movaps [rsp], xmm15
000074fc937d3887  movaps [rsp+0x10], xmm13
000074fc937d388d  movaps [rsp+0x20], xmm10
000074fc937d3893  lea rdi, [rsp]
000074fc937d3897  mov esi, 0x00
000074fc937d389c  mov rax, 0x5D72CBC20530
000074fc937d38a6  call rax
000074fc937d38a8  movaps xmm15, [rsp]
000074fc937d38ad  add rsp, 0x30
000074fc937d38b1  vmovaps xmm0, [rsp]
000074fc937d38b6  vmovaps xmm1, [rsp+0x10]
000074fc937d38bc  vmovaps xmm2, [rsp+0x20]
000074fc937d38c2  vmovaps xmm3, [rsp+0x30]
000074fc937d38c8  vmovaps xmm4, [rsp+0x40]
000074fc937d38ce  vmovaps xmm5, [rsp+0x50]
000074fc937d38d4  vmovaps xmm6, [rsp+0x60]
000074fc937d38da  vmovaps xmm7, [rsp+0x70]
000074fc937d38e0  vmovaps xmm8, [rsp+0x80]
000074fc937d38e9  vmovaps xmm9, [rsp+0x90]
000074fc937d38f2  vmovaps xmm10, [rsp+0xA0]
000074fc937d38fb  vmovaps xmm11, [rsp+0xB0]
000074fc937d3904  vmovaps xmm12, [rsp+0xC0]
000074fc937d390d  vmovaps xmm13, [rsp+0xD0]
000074fc937d3916  vmovaps xmm14, [rsp+0xE0]
000074fc937d391f  add rsp, 0xF0
000074fc937d3926  pop r11
000074fc937d3928  pop r10
000074fc937d392a  pop r9
000074fc937d392c  pop r8
000074fc937d392e  pop rsi
000074fc937d392f  pop rdi
000074fc937d3930  pop rdx
000074fc937d3931  pop rcx
000074fc937d3932  pop rax
000074fc937d3933  add rsp, 0x08
000074fc937d3937  jmp 0x000074FC937CFF55
000074fc937d393c  call 0x000074FC9360C260
000074fc937d3941  jmp 0x000074FC937CFFB0
000074fc937d3946  sub rsp, 0x08
000074fc937d394a  push rax
000074fc937d394b  push rcx
000074fc937d394c  push rdx
000074fc937d394d  push rdi
000074fc937d394e  push rsi
000074fc937d394f  push r8
000074fc937d3951  push r9
000074fc937d3953  push r10
000074fc937d3955  push r11
000074fc937d3957  sub rsp, 0xF0
000074fc937d395e  vmovaps [rsp], xmm0
000074fc937d3963  vmovaps [rsp+0x10], xmm1
000074fc937d3969  vmovaps [rsp+0x20], xmm2
000074fc937d396f  vmovaps [rsp+0x30], xmm3
000074fc937d3975  vmovaps [rsp+0x40], xmm4
000074fc937d397b  vmovaps [rsp+0x50], xmm5
000074fc937d3981  vmovaps [rsp+0x60], xmm6
000074fc937d3987  vmovaps [rsp+0x70], xmm7
000074fc937d398d  vmovaps [rsp+0x80], xmm8
000074fc937d3996  vmovaps [rsp+0x90], xmm10
000074fc937d399f  vmovaps [rsp+0xA0], xmm11
000074fc937d39a8  vmovaps [rsp+0xB0], xmm12
000074fc937d39b1  vmovaps [rsp+0xC0], xmm13
000074fc937d39ba  vmovaps [rsp+0xD0], xmm14
000074fc937d39c3  vmovaps [rsp+0xE0], xmm15
000074fc937d39cc  sub rsp, 0x30
000074fc937d39d0  movaps [rsp], xmm9
000074fc937d39d5  movaps [rsp+0x10], xmm8
000074fc937d39db  movaps [rsp+0x20], xmm10
000074fc937d39e1  lea rdi, [rsp]
000074fc937d39e5  mov esi, 0x00
000074fc937d39ea  mov rax, 0x5D72CBC20530
000074fc937d39f4  call rax
000074fc937d39f6  movaps xmm9, [rsp]
000074fc937d39fb  add rsp, 0x30
000074fc937d39ff  vmovaps xmm0, [rsp]
000074fc937d3a04  vmovaps xmm1, [rsp+0x10]
000074fc937d3a0a  vmovaps xmm2, [rsp+0x20]
000074fc937d3a10  vmovaps xmm3, [rsp+0x30]
000074fc937d3a16  vmovaps xmm4, [rsp+0x40]
000074fc937d3a1c  vmovaps xmm5, [rsp+0x50]
000074fc937d3a22  vmovaps xmm6, [rsp+0x60]
000074fc937d3a28  vmovaps xmm7, [rsp+0x70]
000074fc937d3a2e  vmovaps xmm8, [rsp+0x80]
000074fc937d3a37  vmovaps xmm10, [rsp+0x90]
000074fc937d3a40  vmovaps xmm11, [rsp+0xA0]
000074fc937d3a49  vmovaps xmm12, [rsp+0xB0]
000074fc937d3a52  vmovaps xmm13, [rsp+0xC0]
000074fc937d3a5b  vmovaps xmm14, [rsp+0xD0]
000074fc937d3a64  vmovaps xmm15, [rsp+0xE0]
000074fc937d3a6d  add rsp, 0xF0
000074fc937d3a74  pop r11
000074fc937d3a76  pop r10
000074fc937d3a78  pop r9
000074fc937d3a7a  pop r8
000074fc937d3a7c  pop rsi
000074fc937d3a7d  pop rdi
000074fc937d3a7e  pop rdx
000074fc937d3a7f  pop rcx
000074fc937d3a80  pop rax
000074fc937d3a81  add rsp, 0x08
000074fc937d3a85  jmp 0x000074FC937CFFE1
000074fc937d3a8a  sub rsp, 0x08
000074fc937d3a8e  push rax
000074fc937d3a8f  push rcx
000074fc937d3a90  push rdx
000074fc937d3a91  push rdi
000074fc937d3a92  push rsi
000074fc937d3a93  push r8
000074fc937d3a95  push r9
000074fc937d3a97  push r10
000074fc937d3a99  push r11
000074fc937d3a9b  sub rsp, 0xF0
000074fc937d3aa2  vmovaps [rsp], xmm0
000074fc937d3aa7  vmovaps [rsp+0x10], xmm1
000074fc937d3aad  vmovaps [rsp+0x20], xmm2
000074fc937d3ab3  vmovaps [rsp+0x30], xmm3
000074fc937d3ab9  vmovaps [rsp+0x40], xmm4
000074fc937d3abf  vmovaps [rsp+0x50], xmm5
000074fc937d3ac5  vmovaps [rsp+0x60], xmm6
000074fc937d3acb  vmovaps [rsp+0x70], xmm7
000074fc937d3ad1  vmovaps [rsp+0x80], xmm8
000074fc937d3ada  vmovaps [rsp+0x90], xmm9
000074fc937d3ae3  vmovaps [rsp+0xA0], xmm11
000074fc937d3aec  vmovaps [rsp+0xB0], xmm12
000074fc937d3af5  vmovaps [rsp+0xC0], xmm13
000074fc937d3afe  vmovaps [rsp+0xD0], xmm14
000074fc937d3b07  vmovaps [rsp+0xE0], xmm15
000074fc937d3b10  sub rsp, 0x30
000074fc937d3b14  movaps [rsp], xmm10
000074fc937d3b19  movaps [rsp+0x10], xmm1
000074fc937d3b1e  movaps [rsp+0x20], xmm11
000074fc937d3b24  lea rdi, [rsp]
000074fc937d3b28  mov esi, 0x00
000074fc937d3b2d  mov rax, 0x5D72CBC20530
000074fc937d3b37  call rax
000074fc937d3b39  movaps xmm10, [rsp]
000074fc937d3b3e  add rsp, 0x30
000074fc937d3b42  vmovaps xmm0, [rsp]
000074fc937d3b47  vmovaps xmm1, [rsp+0x10]
000074fc937d3b4d  vmovaps xmm2, [rsp+0x20]
000074fc937d3b53  vmovaps xmm3, [rsp+0x30]
000074fc937d3b59  vmovaps xmm4, [rsp+0x40]
000074fc937d3b5f  vmovaps xmm5, [rsp+0x50]
000074fc937d3b65  vmovaps xmm6, [rsp+0x60]
000074fc937d3b6b  vmovaps xmm7, [rsp+0x70]
000074fc937d3b71  vmovaps xmm8, [rsp+0x80]
000074fc937d3b7a  vmovaps xmm9, [rsp+0x90]
000074fc937d3b83  vmovaps xmm11, [rsp+0xA0]
000074fc937d3b8c  vmovaps xmm12, [rsp+0xB0]
000074fc937d3b95  vmovaps xmm13, [rsp+0xC0]
000074fc937d3b9e  vmovaps xmm14, [rsp+0xD0]
000074fc937d3ba7  vmovaps xmm15, [rsp+0xE0]
000074fc937d3bb0  add rsp, 0xF0
000074fc937d3bb7  pop r11
000074fc937d3bb9  pop r10
000074fc937d3bbb  pop r9
000074fc937d3bbd  pop r8
000074fc937d3bbf  pop rsi
000074fc937d3bc0  pop rdi
000074fc937d3bc1  pop rdx
000074fc937d3bc2  pop rcx
000074fc937d3bc3  pop rax
000074fc937d3bc4  add rsp, 0x08
000074fc937d3bc8  jmp 0x000074FC937CFFFC
000074fc937d3bcd  sub rsp, 0x08
000074fc937d3bd1  push rax
000074fc937d3bd2  push rcx
000074fc937d3bd3  push rdx
000074fc937d3bd4  push rdi
000074fc937d3bd5  push rsi
000074fc937d3bd6  push r8
000074fc937d3bd8  push r9
000074fc937d3bda  push r10
000074fc937d3bdc  push r11
000074fc937d3bde  sub rsp, 0xF0
000074fc937d3be5  vmovaps [rsp], xmm0
000074fc937d3bea  vmovaps [rsp+0x10], xmm2
000074fc937d3bf0  vmovaps [rsp+0x20], xmm3
000074fc937d3bf6  vmovaps [rsp+0x30], xmm4
000074fc937d3bfc  vmovaps [rsp+0x40], xmm5
000074fc937d3c02  vmovaps [rsp+0x50], xmm6
000074fc937d3c08  vmovaps [rsp+0x60], xmm7
000074fc937d3c0e  vmovaps [rsp+0x70], xmm8
000074fc937d3c14  vmovaps [rsp+0x80], xmm9
000074fc937d3c1d  vmovaps [rsp+0x90], xmm10
000074fc937d3c26  vmovaps [rsp+0xA0], xmm11
000074fc937d3c2f  vmovaps [rsp+0xB0], xmm12
000074fc937d3c38  vmovaps [rsp+0xC0], xmm13
000074fc937d3c41  vmovaps [rsp+0xD0], xmm14
000074fc937d3c4a  vmovaps [rsp+0xE0], xmm15
000074fc937d3c53  sub rsp, 0x30
000074fc937d3c57  movaps [rsp], xmm1
000074fc937d3c5b  movaps [rsp+0x10], xmm14
000074fc937d3c61  movaps [rsp+0x20], xmm6
000074fc937d3c66  lea rdi, [rsp]
000074fc937d3c6a  mov esi, 0x00
000074fc937d3c6f  mov rax, 0x5D72CBC20530
000074fc937d3c79  call rax
000074fc937d3c7b  movaps xmm1, [rsp]
000074fc937d3c7f  add rsp, 0x30
000074fc937d3c83  vmovaps xmm0, [rsp]
000074fc937d3c88  vmovaps xmm2, [rsp+0x10]
000074fc937d3c8e  vmovaps xmm3, [rsp+0x20]
000074fc937d3c94  vmovaps xmm4, [rsp+0x30]
000074fc937d3c9a  vmovaps xmm5, [rsp+0x40]
000074fc937d3ca0  vmovaps xmm6, [rsp+0x50]
000074fc937d3ca6  vmovaps xmm7, [rsp+0x60]
000074fc937d3cac  vmovaps xmm8, [rsp+0x70]
000074fc937d3cb2  vmovaps xmm9, [rsp+0x80]
000074fc937d3cbb  vmovaps xmm10, [rsp+0x90]
000074fc937d3cc4  vmovaps xmm11, [rsp+0xA0]
000074fc937d3ccd  vmovaps xmm12, [rsp+0xB0]
000074fc937d3cd6  vmovaps xmm13, [rsp+0xC0]
000074fc937d3cdf  vmovaps xmm14, [rsp+0xD0]
000074fc937d3ce8  vmovaps xmm15, [rsp+0xE0]
000074fc937d3cf1  add rsp, 0xF0
000074fc937d3cf8  pop r11
000074fc937d3cfa  pop r10
000074fc937d3cfc  pop r9
000074fc937d3cfe  pop r8
000074fc937d3d00  pop rsi
000074fc937d3d01  pop rdi
000074fc937d3d02  pop rdx
000074fc937d3d03  pop rcx
000074fc937d3d04  pop rax
000074fc937d3d05  add rsp, 0x08
000074fc937d3d09  jmp 0x000074FC937D0015
000074fc937d3d0e  sub rsp, 0x08
000074fc937d3d12  push rax
000074fc937d3d13  push rcx
000074fc937d3d14  push rdx
000074fc937d3d15  push rdi
000074fc937d3d16  push rsi
000074fc937d3d17  push r8
000074fc937d3d19  push r9
000074fc937d3d1b  push r10
000074fc937d3d1d  push r11
000074fc937d3d1f  sub rsp, 0xF0
000074fc937d3d26  vmovaps [rsp], xmm0
000074fc937d3d2b  vmovaps [rsp+0x10], xmm1
000074fc937d3d31  vmovaps [rsp+0x20], xmm2
000074fc937d3d37  vmovaps [rsp+0x30], xmm3
000074fc937d3d3d  vmovaps [rsp+0x40], xmm4
000074fc937d3d43  vmovaps [rsp+0x50], xmm5
000074fc937d3d49  vmovaps [rsp+0x60], xmm6
000074fc937d3d4f  vmovaps [rsp+0x70], xmm7
000074fc937d3d55  vmovaps [rsp+0x80], xmm8
000074fc937d3d5e  vmovaps [rsp+0x90], xmm9
000074fc937d3d67  vmovaps [rsp+0xA0], xmm10
000074fc937d3d70  vmovaps [rsp+0xB0], xmm12
000074fc937d3d79  vmovaps [rsp+0xC0], xmm13
000074fc937d3d82  vmovaps [rsp+0xD0], xmm14
000074fc937d3d8b  vmovaps [rsp+0xE0], xmm15
000074fc937d3d94  sub rsp, 0x30
000074fc937d3d98  movaps [rsp], xmm11
000074fc937d3d9d  movaps [rsp+0x10], xmm13
000074fc937d3da3  movaps [rsp+0x20], xmm14
000074fc937d3da9  lea rdi, [rsp]
000074fc937d3dad  mov esi, 0x00
000074fc937d3db2  mov rax, 0x5D72CBC20530
000074fc937d3dbc  call rax
000074fc937d3dbe  movaps xmm11, [rsp]
000074fc937d3dc3  add rsp, 0x30
000074fc937d3dc7  vmovaps xmm0, [rsp]
000074fc937d3dcc  vmovaps xmm1, [rsp+0x10]
000074fc937d3dd2  vmovaps xmm2, [rsp+0x20]
000074fc937d3dd8  vmovaps xmm3, [rsp+0x30]
000074fc937d3dde  vmovaps xmm4, [rsp+0x40]
000074fc937d3de4  vmovaps xmm5, [rsp+0x50]
000074fc937d3dea  vmovaps xmm6, [rsp+0x60]
000074fc937d3df0  vmovaps xmm7, [rsp+0x70]
000074fc937d3df6  vmovaps xmm8, [rsp+0x80]
000074fc937d3dff  vmovaps xmm9, [rsp+0x90]
000074fc937d3e08  vmovaps xmm10, [rsp+0xA0]
000074fc937d3e11  vmovaps xmm12, [rsp+0xB0]
000074fc937d3e1a  vmovaps xmm13, [rsp+0xC0]
000074fc937d3e23  vmovaps xmm14, [rsp+0xD0]
000074fc937d3e2c  vmovaps xmm15, [rsp+0xE0]
000074fc937d3e35  add rsp, 0xF0
000074fc937d3e3c  pop r11
000074fc937d3e3e  pop r10
000074fc937d3e40  pop r9
000074fc937d3e42  pop r8
000074fc937d3e44  pop rsi
000074fc937d3e45  pop rdi
000074fc937d3e46  pop rdx
000074fc937d3e47  pop rcx
000074fc937d3e48  pop rax
000074fc937d3e49  add rsp, 0x08
000074fc937d3e4d  jmp 0x000074FC937D003F
000074fc937d3e52  sub rsp, 0x08
000074fc937d3e56  push rax
000074fc937d3e57  push rcx
000074fc937d3e58  push rdx
000074fc937d3e59  push rdi
000074fc937d3e5a  push rsi
000074fc937d3e5b  push r8
000074fc937d3e5d  push r9
000074fc937d3e5f  push r10
000074fc937d3e61  push r11
000074fc937d3e63  sub rsp, 0xF0
000074fc937d3e6a  vmovaps [rsp], xmm0
000074fc937d3e6f  vmovaps [rsp+0x10], xmm1
000074fc937d3e75  vmovaps [rsp+0x20], xmm2
000074fc937d3e7b  vmovaps [rsp+0x30], xmm3
000074fc937d3e81  vmovaps [rsp+0x40], xmm4
000074fc937d3e87  vmovaps [rsp+0x50], xmm5
000074fc937d3e8d  vmovaps [rsp+0x60], xmm6
000074fc937d3e93  vmovaps [rsp+0x70], xmm7
000074fc937d3e99  vmovaps [rsp+0x80], xmm8
000074fc937d3ea2  vmovaps [rsp+0x90], xmm9
000074fc937d3eab  vmovaps [rsp+0xA0], xmm10
000074fc937d3eb4  vmovaps [rsp+0xB0], xmm11
000074fc937d3ebd  vmovaps [rsp+0xC0], xmm12
000074fc937d3ec6  vmovaps [rsp+0xD0], xmm14
000074fc937d3ecf  vmovaps [rsp+0xE0], xmm15
000074fc937d3ed8  sub rsp, 0x30
000074fc937d3edc  movaps [rsp], xmm13
000074fc937d3ee1  movaps [rsp+0x10], xmm8
000074fc937d3ee7  movaps [rsp+0x20], xmm14
000074fc937d3eed  lea rdi, [rsp]
000074fc937d3ef1  mov esi, 0x00
000074fc937d3ef6  mov rax, 0x5D72CBC20530
000074fc937d3f00  call rax
000074fc937d3f02  movaps xmm13, [rsp]
000074fc937d3f07  add rsp, 0x30
000074fc937d3f0b  vmovaps xmm0, [rsp]
000074fc937d3f10  vmovaps xmm1, [rsp+0x10]
000074fc937d3f16  vmovaps xmm2, [rsp+0x20]
000074fc937d3f1c  vmovaps xmm3, [rsp+0x30]
000074fc937d3f22  vmovaps xmm4, [rsp+0x40]
000074fc937d3f28  vmovaps xmm5, [rsp+0x50]
000074fc937d3f2e  vmovaps xmm6, [rsp+0x60]
000074fc937d3f34  vmovaps xmm7, [rsp+0x70]
000074fc937d3f3a  vmovaps xmm8, [rsp+0x80]
000074fc937d3f43  vmovaps xmm9, [rsp+0x90]
000074fc937d3f4c  vmovaps xmm10, [rsp+0xA0]
000074fc937d3f55  vmovaps xmm11, [rsp+0xB0]
000074fc937d3f5e  vmovaps xmm12, [rsp+0xC0]
000074fc937d3f67  vmovaps xmm14, [rsp+0xD0]
000074fc937d3f70  vmovaps xmm15, [rsp+0xE0]
000074fc937d3f79  add rsp, 0xF0
000074fc937d3f80  pop r11
000074fc937d3f82  pop r10
000074fc937d3f84  pop r9
000074fc937d3f86  pop r8
000074fc937d3f88  pop rsi
000074fc937d3f89  pop rdi
000074fc937d3f8a  pop rdx
000074fc937d3f8b  pop rcx
000074fc937d3f8c  pop rax
000074fc937d3f8d  add rsp, 0x08
000074fc937d3f91  jmp 0x000074FC937D006E
000074fc937d3f96  sub rsp, 0x08
000074fc937d3f9a  push rax
000074fc937d3f9b  push rcx
000074fc937d3f9c  push rdx
000074fc937d3f9d  push rdi
000074fc937d3f9e  push rsi
000074fc937d3f9f  push r8
000074fc937d3fa1  push r9
000074fc937d3fa3  push r10
000074fc937d3fa5  push r11
000074fc937d3fa7  sub rsp, 0xF0
000074fc937d3fae  vmovaps [rsp], xmm0
000074fc937d3fb3  vmovaps [rsp+0x10], xmm1
000074fc937d3fb9  vmovaps [rsp+0x20], xmm2
000074fc937d3fbf  vmovaps [rsp+0x30], xmm3
000074fc937d3fc5  vmovaps [rsp+0x40], xmm4
000074fc937d3fcb  vmovaps [rsp+0x50], xmm5
000074fc937d3fd1  vmovaps [rsp+0x60], xmm6
000074fc937d3fd7  vmovaps [rsp+0x70], xmm7
000074fc937d3fdd  vmovaps [rsp+0x80], xmm9
000074fc937d3fe6  vmovaps [rsp+0x90], xmm10
000074fc937d3fef  vmovaps [rsp+0xA0], xmm11
000074fc937d3ff8  vmovaps [rsp+0xB0], xmm12
000074fc937d4001  vmovaps [rsp+0xC0], xmm13
000074fc937d400a  vmovaps [rsp+0xD0], xmm14
000074fc937d4013  vmovaps [rsp+0xE0], xmm15
000074fc937d401c  sub rsp, 0x30
000074fc937d4020  movaps [rsp], xmm8
000074fc937d4025  movaps [rsp+0x10], xmm7
000074fc937d402a  movaps [rsp+0x20], xmm14
000074fc937d4030  lea rdi, [rsp]
000074fc937d4034  mov esi, 0x00
000074fc937d4039  mov rax, 0x5D72CBC20530
000074fc937d4043  call rax
000074fc937d4045  movaps xmm8, [rsp]
000074fc937d404a  add rsp, 0x30
000074fc937d404e  vmovaps xmm0, [rsp]
000074fc937d4053  vmovaps xmm1, [rsp+0x10]
000074fc937d4059  vmovaps xmm2, [rsp+0x20]
000074fc937d405f  vmovaps xmm3, [rsp+0x30]
000074fc937d4065  vmovaps xmm4, [rsp+0x40]
000074fc937d406b  vmovaps xmm5, [rsp+0x50]
000074fc937d4071  vmovaps xmm6, [rsp+0x60]
000074fc937d4077  vmovaps xmm7, [rsp+0x70]
000074fc937d407d  vmovaps xmm9, [rsp+0x80]
000074fc937d4086  vmovaps xmm10, [rsp+0x90]
000074fc937d408f  vmovaps xmm11, [rsp+0xA0]
000074fc937d4098  vmovaps xmm12, [rsp+0xB0]
000074fc937d40a1  vmovaps xmm13, [rsp+0xC0]
000074fc937d40aa  vmovaps xmm14, [rsp+0xD0]
000074fc937d40b3  vmovaps xmm15, [rsp+0xE0]
000074fc937d40bc  add rsp, 0xF0
000074fc937d40c3  pop r11
000074fc937d40c5  pop r10
000074fc937d40c7  pop r9
000074fc937d40c9  pop r8
000074fc937d40cb  pop rsi
000074fc937d40cc  pop rdi
000074fc937d40cd  pop rdx
000074fc937d40ce  pop rcx
000074fc937d40cf  pop rax
000074fc937d40d0  add rsp, 0x08
000074fc937d40d4  jmp 0x000074FC937D0094
000074fc937d40d9  sub rsp, 0x08
000074fc937d40dd  push rax
000074fc937d40de  push rcx
000074fc937d40df  push rdx
000074fc937d40e0  push rdi
000074fc937d40e1  push rsi
000074fc937d40e2  push r8
000074fc937d40e4  push r9
000074fc937d40e6  push r10
000074fc937d40e8  push r11
000074fc937d40ea  sub rsp, 0xF0
000074fc937d40f1  vmovaps [rsp], xmm0
000074fc937d40f6  vmovaps [rsp+0x10], xmm1
000074fc937d40fc  vmovaps [rsp+0x20], xmm2
000074fc937d4102  vmovaps [rsp+0x30], xmm3
000074fc937d4108  vmovaps [rsp+0x40], xmm4
000074fc937d410e  vmovaps [rsp+0x50], xmm5
000074fc937d4114  vmovaps [rsp+0x60], xmm6
000074fc937d411a  vmovaps [rsp+0x70], xmm7
000074fc937d4120  vmovaps [rsp+0x80], xmm8
000074fc937d4129  vmovaps [rsp+0x90], xmm9
000074fc937d4132  vmovaps [rsp+0xA0], xmm10
000074fc937d413b  vmovaps [rsp+0xB0], xmm11
000074fc937d4144  vmovaps [rsp+0xC0], xmm12
000074fc937d414d  vmovaps [rsp+0xD0], xmm13
000074fc937d4156  vmovaps [rsp+0xE0], xmm15
000074fc937d415f  sub rsp, 0x30
000074fc937d4163  movaps [rsp], xmm14
000074fc937d4168  movaps [rsp+0x10], xmm12
000074fc937d416e  movaps [rsp+0x20], xmm9
000074fc937d4174  lea rdi, [rsp]
000074fc937d4178  mov esi, 0x00
000074fc937d417d  mov rax, 0x5D72CBC20530
000074fc937d4187  call rax
000074fc937d4189  movaps xmm14, [rsp]
000074fc937d418e  add rsp, 0x30
000074fc937d4192  vmovaps xmm0, [rsp]
000074fc937d4197  vmovaps xmm1, [rsp+0x10]
000074fc937d419d  vmovaps xmm2, [rsp+0x20]
000074fc937d41a3  vmovaps xmm3, [rsp+0x30]
000074fc937d41a9  vmovaps xmm4, [rsp+0x40]
000074fc937d41af  vmovaps xmm5, [rsp+0x50]
000074fc937d41b5  vmovaps xmm6, [rsp+0x60]
000074fc937d41bb  vmovaps xmm7, [rsp+0x70]
000074fc937d41c1  vmovaps xmm8, [rsp+0x80]
000074fc937d41ca  vmovaps xmm9, [rsp+0x90]
000074fc937d41d3  vmovaps xmm10, [rsp+0xA0]
000074fc937d41dc  vmovaps xmm11, [rsp+0xB0]
000074fc937d41e5  vmovaps xmm12, [rsp+0xC0]
000074fc937d41ee  vmovaps xmm13, [rsp+0xD0]
000074fc937d41f7  vmovaps xmm15, [rsp+0xE0]
000074fc937d4200  add rsp, 0xF0
000074fc937d4207  pop r11
000074fc937d4209  pop r10
000074fc937d420b  pop r9
000074fc937d420d  pop r8
000074fc937d420f  pop rsi
000074fc937d4210  pop rdi
000074fc937d4211  pop rdx
000074fc937d4212  pop rcx
000074fc937d4213  pop rax
000074fc937d4214  add rsp, 0x08
000074fc937d4218  jmp 0x000074FC937D00AE
000074fc937d421d  sub rsp, 0x08
000074fc937d4221  push rax
000074fc937d4222  push rcx
000074fc937d4223  push rdx
000074fc937d4224  push rdi
000074fc937d4225  push rsi
000074fc937d4226  push r8
000074fc937d4228  push r9
000074fc937d422a  push r10
000074fc937d422c  push r11
000074fc937d422e  sub rsp, 0xF0
000074fc937d4235  vmovaps [rsp], xmm0
000074fc937d423a  vmovaps [rsp+0x10], xmm1
000074fc937d4240  vmovaps [rsp+0x20], xmm2
000074fc937d4246  vmovaps [rsp+0x30], xmm3
000074fc937d424c  vmovaps [rsp+0x40], xmm4
000074fc937d4252  vmovaps [rsp+0x50], xmm5
000074fc937d4258  vmovaps [rsp+0x60], xmm6
000074fc937d425e  vmovaps [rsp+0x70], xmm7
000074fc937d4264  vmovaps [rsp+0x80], xmm8
000074fc937d426d  vmovaps [rsp+0x90], xmm10
000074fc937d4276  vmovaps [rsp+0xA0], xmm11
000074fc937d427f  vmovaps [rsp+0xB0], xmm12
000074fc937d4288  vmovaps [rsp+0xC0], xmm13
000074fc937d4291  vmovaps [rsp+0xD0], xmm14
000074fc937d429a  vmovaps [rsp+0xE0], xmm15
000074fc937d42a3  sub rsp, 0x30
000074fc937d42a7  movaps [rsp], xmm9
000074fc937d42ac  movaps [rsp+0x10], xmm7
000074fc937d42b1  movaps [rsp+0x20], xmm12
000074fc937d42b7  lea rdi, [rsp]
000074fc937d42bb  mov esi, 0x00
000074fc937d42c0  mov rax, 0x5D72CBC20530
000074fc937d42ca  call rax
000074fc937d42cc  movaps xmm9, [rsp]
000074fc937d42d1  add rsp, 0x30
000074fc937d42d5  vmovaps xmm0, [rsp]
000074fc937d42da  vmovaps xmm1, [rsp+0x10]
000074fc937d42e0  vmovaps xmm2, [rsp+0x20]
000074fc937d42e6  vmovaps xmm3, [rsp+0x30]
000074fc937d42ec  vmovaps xmm4, [rsp+0x40]
000074fc937d42f2  vmovaps xmm5, [rsp+0x50]
000074fc937d42f8  vmovaps xmm6, [rsp+0x60]
000074fc937d42fe  vmovaps xmm7, [rsp+0x70]
000074fc937d4304  vmovaps xmm8, [rsp+0x80]
000074fc937d430d  vmovaps xmm10, [rsp+0x90]
000074fc937d4316  vmovaps xmm11, [rsp+0xA0]
000074fc937d431f  vmovaps xmm12, [rsp+0xB0]
000074fc937d4328  vmovaps xmm13, [rsp+0xC0]
000074fc937d4331  vmovaps xmm14, [rsp+0xD0]
000074fc937d433a  vmovaps xmm15, [rsp+0xE0]
000074fc937d4343  add rsp, 0xF0
000074fc937d434a  pop r11
000074fc937d434c  pop r10
000074fc937d434e  pop r9
000074fc937d4350  pop r8
000074fc937d4352  pop rsi
000074fc937d4353  pop rdi
000074fc937d4354  pop rdx
000074fc937d4355  pop rcx
000074fc937d4356  pop rax
000074fc937d4357  add rsp, 0x08
000074fc937d435b  jmp 0x000074FC937D00DD
000074fc937d4360  sub rsp, 0x08
000074fc937d4364  push rax
000074fc937d4365  push rcx
000074fc937d4366  push rdx
000074fc937d4367  push rdi
000074fc937d4368  push rsi
000074fc937d4369  push r8
000074fc937d436b  push r9
000074fc937d436d  push r10
000074fc937d436f  push r11
000074fc937d4371  sub rsp, 0xF0
000074fc937d4378  vmovaps [rsp], xmm0
000074fc937d437d  vmovaps [rsp+0x10], xmm1
000074fc937d4383  vmovaps [rsp+0x20], xmm2
000074fc937d4389  vmovaps [rsp+0x30], xmm3
000074fc937d438f  vmovaps [rsp+0x40], xmm4
000074fc937d4395  vmovaps [rsp+0x50], xmm5
000074fc937d439b  vmovaps [rsp+0x60], xmm6
000074fc937d43a1  vmovaps [rsp+0x70], xmm7
000074fc937d43a7  vmovaps [rsp+0x80], xmm8
000074fc937d43b0  vmovaps [rsp+0x90], xmm9
000074fc937d43b9  vmovaps [rsp+0xA0], xmm10
000074fc937d43c2  vmovaps [rsp+0xB0], xmm11
000074fc937d43cb  vmovaps [rsp+0xC0], xmm13
000074fc937d43d4  vmovaps [rsp+0xD0], xmm14
000074fc937d43dd  vmovaps [rsp+0xE0], xmm15
000074fc937d43e6  sub rsp, 0x30
000074fc937d43ea  movaps [rsp], xmm12
000074fc937d43ef  movaps [rsp+0x10], xmm15
000074fc937d43f5  movaps [rsp+0x20], xmm11
000074fc937d43fb  lea rdi, [rsp]
000074fc937d43ff  mov esi, 0x00
000074fc937d4404  mov rax, 0x5D72CBC20530
000074fc937d440e  call rax
000074fc937d4410  movaps xmm12, [rsp]
000074fc937d4415  add rsp, 0x30
000074fc937d4419  vmovaps xmm0, [rsp]
000074fc937d441e  vmovaps xmm1, [rsp+0x10]
000074fc937d4424  vmovaps xmm2, [rsp+0x20]
000074fc937d442a  vmovaps xmm3, [rsp+0x30]
000074fc937d4430  vmovaps xmm4, [rsp+0x40]
000074fc937d4436  vmovaps xmm5, [rsp+0x50]
000074fc937d443c  vmovaps xmm6, [rsp+0x60]
000074fc937d4442  vmovaps xmm7, [rsp+0x70]
000074fc937d4448  vmovaps xmm8, [rsp+0x80]
000074fc937d4451  vmovaps xmm9, [rsp+0x90]
000074fc937d445a  vmovaps xmm10, [rsp+0xA0]
000074fc937d4463  vmovaps xmm11, [rsp+0xB0]
000074fc937d446c  vmovaps xmm13, [rsp+0xC0]
000074fc937d4475  vmovaps xmm14, [rsp+0xD0]
000074fc937d447e  vmovaps xmm15, [rsp+0xE0]
000074fc937d4487  add rsp, 0xF0
000074fc937d448e  pop r11
000074fc937d4490  pop r10
000074fc937d4492  pop r9
000074fc937d4494  pop r8
000074fc937d4496  pop rsi
000074fc937d4497  pop rdi
000074fc937d4498  pop rdx
000074fc937d4499  pop rcx
000074fc937d449a  pop rax
000074fc937d449b  add rsp, 0x08
000074fc937d449f  jmp 0x000074FC937D00F7
000074fc937d44a4  sub rsp, 0x08
000074fc937d44a8  push rax
000074fc937d44a9  push rcx
000074fc937d44aa  push rdx
000074fc937d44ab  push rdi
000074fc937d44ac  push rsi
000074fc937d44ad  push r8
000074fc937d44af  push r9
000074fc937d44b1  push r10
000074fc937d44b3  push r11
000074fc937d44b5  sub rsp, 0xF0
000074fc937d44bc  vmovaps [rsp], xmm0
000074fc937d44c1  vmovaps [rsp+0x10], xmm1
000074fc937d44c7  vmovaps [rsp+0x20], xmm2
000074fc937d44cd  vmovaps [rsp+0x30], xmm3
000074fc937d44d3  vmovaps [rsp+0x40], xmm4
000074fc937d44d9  vmovaps [rsp+0x50], xmm5
000074fc937d44df  vmovaps [rsp+0x60], xmm6
000074fc937d44e5  vmovaps [rsp+0x70], xmm7
000074fc937d44eb  vmovaps [rsp+0x80], xmm8
000074fc937d44f4  vmovaps [rsp+0x90], xmm9
000074fc937d44fd  vmovaps [rsp+0xA0], xmm10
000074fc937d4506  vmovaps [rsp+0xB0], xmm12
000074fc937d450f  vmovaps [rsp+0xC0], xmm13
000074fc937d4518  vmovaps [rsp+0xD0], xmm14
000074fc937d4521  vmovaps [rsp+0xE0], xmm15
000074fc937d452a  sub rsp, 0x30
000074fc937d452e  movaps [rsp], xmm11
000074fc937d4533  movaps [rsp+0x10], xmm7
000074fc937d4538  movaps [rsp+0x20], xmm15
000074fc937d453e  lea rdi, [rsp]
000074fc937d4542  mov esi, 0x00
000074fc937d4547  mov rax, 0x5D72CBC20530
000074fc937d4551  call rax
000074fc937d4553  movaps xmm11, [rsp]
000074fc937d4558  add rsp, 0x30
000074fc937d455c  vmovaps xmm0, [rsp]
000074fc937d4561  vmovaps xmm1, [rsp+0x10]
000074fc937d4567  vmovaps xmm2, [rsp+0x20]
000074fc937d456d  vmovaps xmm3, [rsp+0x30]
000074fc937d4573  vmovaps xmm4, [rsp+0x40]
000074fc937d4579  vmovaps xmm5, [rsp+0x50]
000074fc937d457f  vmovaps xmm6, [rsp+0x60]
000074fc937d4585  vmovaps xmm7, [rsp+0x70]
000074fc937d458b  vmovaps xmm8, [rsp+0x80]
000074fc937d4594  vmovaps xmm9, [rsp+0x90]
000074fc937d459d  vmovaps xmm10, [rsp+0xA0]
000074fc937d45a6  vmovaps xmm12, [rsp+0xB0]
000074fc937d45af  vmovaps xmm13, [rsp+0xC0]
000074fc937d45b8  vmovaps xmm14, [rsp+0xD0]
000074fc937d45c1  vmovaps xmm15, [rsp+0xE0]
000074fc937d45ca  add rsp, 0xF0
000074fc937d45d1  pop r11
000074fc937d45d3  pop r10
000074fc937d45d5  pop r9
000074fc937d45d7  pop r8
000074fc937d45d9  pop rsi
000074fc937d45da  pop rdi
000074fc937d45db  pop rdx
000074fc937d45dc  pop rcx
000074fc937d45dd  pop rax
000074fc937d45de  add rsp, 0x08
000074fc937d45e2  jmp 0x000074FC937D0123
000074fc937d45e7  sub rsp, 0x08
000074fc937d45eb  push rax
000074fc937d45ec  push rcx
000074fc937d45ed  push rdx
000074fc937d45ee  push rdi
000074fc937d45ef  push rsi
000074fc937d45f0  push r8
000074fc937d45f2  push r9
000074fc937d45f4  push r10
000074fc937d45f6  push r11
000074fc937d45f8  sub rsp, 0xF0
000074fc937d45ff  vmovaps [rsp], xmm0
000074fc937d4604  vmovaps [rsp+0x10], xmm1
000074fc937d460a  vmovaps [rsp+0x20], xmm2
000074fc937d4610  vmovaps [rsp+0x30], xmm3
000074fc937d4616  vmovaps [rsp+0x40], xmm4
000074fc937d461c  vmovaps [rsp+0x50], xmm5
000074fc937d4622  vmovaps [rsp+0x60], xmm6
000074fc937d4628  vmovaps [rsp+0x70], xmm7
000074fc937d462e  vmovaps [rsp+0x80], xmm8
000074fc937d4637  vmovaps [rsp+0x90], xmm9
000074fc937d4640  vmovaps [rsp+0xA0], xmm10
000074fc937d4649  vmovaps [rsp+0xB0], xmm11
000074fc937d4652  vmovaps [rsp+0xC0], xmm12
000074fc937d465b  vmovaps [rsp+0xD0], xmm13
000074fc937d4664  vmovaps [rsp+0xE0], xmm14
000074fc937d466d  sub rsp, 0x30
000074fc937d4671  movaps [rsp], xmm15
000074fc937d4676  movaps [rsp+0x10], xmm10
000074fc937d467c  movaps [rsp+0x20], xmm13
000074fc937d4682  lea rdi, [rsp]
000074fc937d4686  mov esi, 0x00
000074fc937d468b  mov rax, 0x5D72CBC20530
000074fc937d4695  call rax
000074fc937d4697  movaps xmm15, [rsp]
000074fc937d469c  add rsp, 0x30
000074fc937d46a0  vmovaps xmm0, [rsp]
000074fc937d46a5  vmovaps xmm1, [rsp+0x10]
000074fc937d46ab  vmovaps xmm2, [rsp+0x20]
000074fc937d46b1  vmovaps xmm3, [rsp+0x30]
000074fc937d46b7  vmovaps xmm4, [rsp+0x40]
000074fc937d46bd  vmovaps xmm5, [rsp+0x50]
000074fc937d46c3  vmovaps xmm6, [rsp+0x60]
000074fc937d46c9  vmovaps xmm7, [rsp+0x70]
000074fc937d46cf  vmovaps xmm8, [rsp+0x80]
000074fc937d46d8  vmovaps xmm9, [rsp+0x90]
000074fc937d46e1  vmovaps xmm10, [rsp+0xA0]
000074fc937d46ea  vmovaps xmm11, [rsp+0xB0]
000074fc937d46f3  vmovaps xmm12, [rsp+0xC0]
000074fc937d46fc  vmovaps xmm13, [rsp+0xD0]
000074fc937d4705  vmovaps xmm14, [rsp+0xE0]
000074fc937d470e  add rsp, 0xF0
000074fc937d4715  pop r11
000074fc937d4717  pop r10
000074fc937d4719  pop r9
000074fc937d471b  pop r8
000074fc937d471d  pop rsi
000074fc937d471e  pop rdi
000074fc937d471f  pop rdx
000074fc937d4720  pop rcx
000074fc937d4721  pop rax
000074fc937d4722  add rsp, 0x08
000074fc937d4726  jmp 0x000074FC937D013D
000074fc937d472b  sub rsp, 0x08
000074fc937d472f  push rax
000074fc937d4730  push rcx
000074fc937d4731  push rdx
000074fc937d4732  push rdi
000074fc937d4733  push rsi
000074fc937d4734  push r8
000074fc937d4736  push r9
000074fc937d4738  push r10
000074fc937d473a  push r11
000074fc937d473c  sub rsp, 0xF0
000074fc937d4743  vmovaps [rsp], xmm0
000074fc937d4748  vmovaps [rsp+0x10], xmm1
000074fc937d474e  vmovaps [rsp+0x20], xmm2
000074fc937d4754  vmovaps [rsp+0x30], xmm3
000074fc937d475a  vmovaps [rsp+0x40], xmm4
000074fc937d4760  vmovaps [rsp+0x50], xmm5
000074fc937d4766  vmovaps [rsp+0x60], xmm6
000074fc937d476c  vmovaps [rsp+0x70], xmm7
000074fc937d4772  vmovaps [rsp+0x80], xmm8
000074fc937d477b  vmovaps [rsp+0x90], xmm9
000074fc937d4784  vmovaps [rsp+0xA0], xmm11
000074fc937d478d  vmovaps [rsp+0xB0], xmm12
000074fc937d4796  vmovaps [rsp+0xC0], xmm13
000074fc937d479f  vmovaps [rsp+0xD0], xmm14
000074fc937d47a8  vmovaps [rsp+0xE0], xmm15
000074fc937d47b1  sub rsp, 0x30
000074fc937d47b5  movaps [rsp], xmm10
000074fc937d47ba  movaps [rsp+0x10], xmm7
000074fc937d47bf  movaps [rsp+0x20], xmm13
000074fc937d47c5  lea rdi, [rsp]
000074fc937d47c9  mov esi, 0x00
000074fc937d47ce  mov rax, 0x5D72CBC20530
000074fc937d47d8  call rax
000074fc937d47da  movaps xmm10, [rsp]
000074fc937d47df  add rsp, 0x30
000074fc937d47e3  vmovaps xmm0, [rsp]
000074fc937d47e8  vmovaps xmm1, [rsp+0x10]
000074fc937d47ee  vmovaps xmm2, [rsp+0x20]
000074fc937d47f4  vmovaps xmm3, [rsp+0x30]
000074fc937d47fa  vmovaps xmm4, [rsp+0x40]
000074fc937d4800  vmovaps xmm5, [rsp+0x50]
000074fc937d4806  vmovaps xmm6, [rsp+0x60]
000074fc937d480c  vmovaps xmm7, [rsp+0x70]
000074fc937d4812  vmovaps xmm8, [rsp+0x80]
000074fc937d481b  vmovaps xmm9, [rsp+0x90]
000074fc937d4824  vmovaps xmm11, [rsp+0xA0]
000074fc937d482d  vmovaps xmm12, [rsp+0xB0]
000074fc937d4836  vmovaps xmm13, [rsp+0xC0]
000074fc937d483f  vmovaps xmm14, [rsp+0xD0]
000074fc937d4848  vmovaps xmm15, [rsp+0xE0]
000074fc937d4851  add rsp, 0xF0
000074fc937d4858  pop r11
000074fc937d485a  pop r10
000074fc937d485c  pop r9
000074fc937d485e  pop r8
000074fc937d4860  pop rsi
000074fc937d4861  pop rdi
000074fc937d4862  pop rdx
000074fc937d4863  pop rcx
000074fc937d4864  pop rax
000074fc937d4865  add rsp, 0x08
000074fc937d4869  jmp 0x000074FC937D0169
000074fc937d486e  sub rsp, 0x08
000074fc937d4872  push rax
000074fc937d4873  push rcx
000074fc937d4874  push rdx
000074fc937d4875  push rdi
000074fc937d4876  push rsi
000074fc937d4877  push r8
000074fc937d4879  push r9
000074fc937d487b  push r10
000074fc937d487d  push r11
000074fc937d487f  sub rsp, 0xF0
000074fc937d4886  vmovaps [rsp], xmm0
000074fc937d488b  vmovaps [rsp+0x10], xmm1
000074fc937d4891  vmovaps [rsp+0x20], xmm2
000074fc937d4897  vmovaps [rsp+0x30], xmm3
000074fc937d489d  vmovaps [rsp+0x40], xmm4
000074fc937d48a3  vmovaps [rsp+0x50], xmm5
000074fc937d48a9  vmovaps [rsp+0x60], xmm6
000074fc937d48af  vmovaps [rsp+0x70], xmm7
000074fc937d48b5  vmovaps [rsp+0x80], xmm8
000074fc937d48be  vmovaps [rsp+0x90], xmm9
000074fc937d48c7  vmovaps [rsp+0xA0], xmm10
000074fc937d48d0  vmovaps [rsp+0xB0], xmm11
000074fc937d48d9  vmovaps [rsp+0xC0], xmm12
000074fc937d48e2  vmovaps [rsp+0xD0], xmm14
000074fc937d48eb  vmovaps [rsp+0xE0], xmm15
000074fc937d48f4  sub rsp, 0x30
000074fc937d48f8  movaps [rsp], xmm13
000074fc937d48fd  movaps [rsp+0x10], xmm1
000074fc937d4902  movaps [rsp+0x20], xmm8
000074fc937d4908  lea rdi, [rsp]
000074fc937d490c  mov esi, 0x00
000074fc937d4911  mov rax, 0x5D72CBC20530
000074fc937d491b  call rax
000074fc937d491d  movaps xmm13, [rsp]
000074fc937d4922  add rsp, 0x30
000074fc937d4926  vmovaps xmm0, [rsp]
000074fc937d492b  vmovaps xmm1, [rsp+0x10]
000074fc937d4931  vmovaps xmm2, [rsp+0x20]
000074fc937d4937  vmovaps xmm3, [rsp+0x30]
000074fc937d493d  vmovaps xmm4, [rsp+0x40]
000074fc937d4943  vmovaps xmm5, [rsp+0x50]
000074fc937d4949  vmovaps xmm6, [rsp+0x60]
000074fc937d494f  vmovaps xmm7, [rsp+0x70]
000074fc937d4955  vmovaps xmm8, [rsp+0x80]
000074fc937d495e  vmovaps xmm9, [rsp+0x90]
000074fc937d4967  vmovaps xmm10, [rsp+0xA0]
000074fc937d4970  vmovaps xmm11, [rsp+0xB0]
000074fc937d4979  vmovaps xmm12, [rsp+0xC0]
000074fc937d4982  vmovaps xmm14, [rsp+0xD0]
000074fc937d498b  vmovaps xmm15, [rsp+0xE0]
000074fc937d4994  add rsp, 0xF0
000074fc937d499b  pop r11
000074fc937d499d  pop r10
000074fc937d499f  pop r9
000074fc937d49a1  pop r8
000074fc937d49a3  pop rsi
000074fc937d49a4  pop rdi
000074fc937d49a5  pop rdx
000074fc937d49a6  pop rcx
000074fc937d49a7  pop rax
000074fc937d49a8  add rsp, 0x08
000074fc937d49ac  jmp 0x000074FC937D0183
000074fc937d49b1  call 0x000074FC935FF430
000074fc937d49b6  jmp 0x000074FC937D018D
000074fc937d49bb  sub rsp, 0x08
000074fc937d49bf  push rax
000074fc937d49c0  push rcx
000074fc937d49c1  push rdx
000074fc937d49c2  push rdi
000074fc937d49c3  push rsi
000074fc937d49c4  push r8
000074fc937d49c6  push r9
000074fc937d49c8  push r10
000074fc937d49ca  push r11
000074fc937d49cc  sub rsp, 0xF0
000074fc937d49d3  vmovaps [rsp], xmm0
000074fc937d49d8  vmovaps [rsp+0x10], xmm1
000074fc937d49de  vmovaps [rsp+0x20], xmm2
000074fc937d49e4  vmovaps [rsp+0x30], xmm3
000074fc937d49ea  vmovaps [rsp+0x40], xmm4
000074fc937d49f0  vmovaps [rsp+0x50], xmm5
000074fc937d49f6  vmovaps [rsp+0x60], xmm6
000074fc937d49fc  vmovaps [rsp+0x70], xmm7
000074fc937d4a02  vmovaps [rsp+0x80], xmm9
000074fc937d4a0b  vmovaps [rsp+0x90], xmm10
000074fc937d4a14  vmovaps [rsp+0xA0], xmm11
000074fc937d4a1d  vmovaps [rsp+0xB0], xmm12
000074fc937d4a26  vmovaps [rsp+0xC0], xmm13
000074fc937d4a2f  vmovaps [rsp+0xD0], xmm14
000074fc937d4a38  vmovaps [rsp+0xE0], xmm15
000074fc937d4a41  sub rsp, 0x30
000074fc937d4a45  movaps [rsp], xmm8
000074fc937d4a4a  movaps [rsp+0x10], xmm14
000074fc937d4a50  movaps [rsp+0x20], xmm9
000074fc937d4a56  lea rdi, [rsp]
000074fc937d4a5a  mov esi, 0x00
000074fc937d4a5f  mov rax, 0x5D72CBC20530
000074fc937d4a69  call rax
000074fc937d4a6b  movaps xmm8, [rsp]
000074fc937d4a70  add rsp, 0x30
000074fc937d4a74  vmovaps xmm0, [rsp]
000074fc937d4a79  vmovaps xmm1, [rsp+0x10]
000074fc937d4a7f  vmovaps xmm2, [rsp+0x20]
000074fc937d4a85  vmovaps xmm3, [rsp+0x30]
000074fc937d4a8b  vmovaps xmm4, [rsp+0x40]
000074fc937d4a91  vmovaps xmm5, [rsp+0x50]
000074fc937d4a97  vmovaps xmm6, [rsp+0x60]
000074fc937d4a9d  vmovaps xmm7, [rsp+0x70]
000074fc937d4aa3  vmovaps xmm9, [rsp+0x80]
000074fc937d4aac  vmovaps xmm10, [rsp+0x90]
000074fc937d4ab5  vmovaps xmm11, [rsp+0xA0]
000074fc937d4abe  vmovaps xmm12, [rsp+0xB0]
000074fc937d4ac7  vmovaps xmm13, [rsp+0xC0]
000074fc937d4ad0  vmovaps xmm14, [rsp+0xD0]
000074fc937d4ad9  vmovaps xmm15, [rsp+0xE0]
000074fc937d4ae2  add rsp, 0xF0
000074fc937d4ae9  pop r11
000074fc937d4aeb  pop r10
000074fc937d4aed  pop r9
000074fc937d4aef  pop r8
000074fc937d4af1  pop rsi
000074fc937d4af2  pop rdi
000074fc937d4af3  pop rdx
000074fc937d4af4  pop rcx
000074fc937d4af5  pop rax
000074fc937d4af6  add rsp, 0x08
000074fc937d4afa  jmp 0x000074FC937D01AF
000074fc937d4aff  sub rsp, 0x08
000074fc937d4b03  push rax
000074fc937d4b04  push rcx
000074fc937d4b05  push rdx
000074fc937d4b06  push rdi
000074fc937d4b07  push rsi
000074fc937d4b08  push r8
000074fc937d4b0a  push r9
000074fc937d4b0c  push r10
000074fc937d4b0e  push r11
000074fc937d4b10  sub rsp, 0xF0
000074fc937d4b17  vmovaps [rsp], xmm0
000074fc937d4b1c  vmovaps [rsp+0x10], xmm1
000074fc937d4b22  vmovaps [rsp+0x20], xmm2
000074fc937d4b28  vmovaps [rsp+0x30], xmm3
000074fc937d4b2e  vmovaps [rsp+0x40], xmm4
000074fc937d4b34  vmovaps [rsp+0x50], xmm5
000074fc937d4b3a  vmovaps [rsp+0x60], xmm6
000074fc937d4b40  vmovaps [rsp+0x70], xmm7
000074fc937d4b46  vmovaps [rsp+0x80], xmm8
000074fc937d4b4f  vmovaps [rsp+0x90], xmm10
000074fc937d4b58  vmovaps [rsp+0xA0], xmm11
000074fc937d4b61  vmovaps [rsp+0xB0], xmm12
000074fc937d4b6a  vmovaps [rsp+0xC0], xmm13
000074fc937d4b73  vmovaps [rsp+0xD0], xmm14
000074fc937d4b7c  vmovaps [rsp+0xE0], xmm15
000074fc937d4b85  sub rsp, 0x30
000074fc937d4b89  movaps [rsp], xmm9
000074fc937d4b8e  movaps [rsp+0x10], xmm1
000074fc937d4b93  movaps [rsp+0x20], xmm14
000074fc937d4b99  lea rdi, [rsp]
000074fc937d4b9d  mov esi, 0x00
000074fc937d4ba2  mov rax, 0x5D72CBC20530
000074fc937d4bac  call rax
000074fc937d4bae  movaps xmm9, [rsp]
000074fc937d4bb3  add rsp, 0x30
000074fc937d4bb7  vmovaps xmm0, [rsp]
000074fc937d4bbc  vmovaps xmm1, [rsp+0x10]
000074fc937d4bc2  vmovaps xmm2, [rsp+0x20]
000074fc937d4bc8  vmovaps xmm3, [rsp+0x30]
000074fc937d4bce  vmovaps xmm4, [rsp+0x40]
000074fc937d4bd4  vmovaps xmm5, [rsp+0x50]
000074fc937d4bda  vmovaps xmm6, [rsp+0x60]
000074fc937d4be0  vmovaps xmm7, [rsp+0x70]
000074fc937d4be6  vmovaps xmm8, [rsp+0x80]
000074fc937d4bef  vmovaps xmm10, [rsp+0x90]
000074fc937d4bf8  vmovaps xmm11, [rsp+0xA0]
000074fc937d4c01  vmovaps xmm12, [rsp+0xB0]
000074fc937d4c0a  vmovaps xmm13, [rsp+0xC0]
000074fc937d4c13  vmovaps xmm14, [rsp+0xD0]
000074fc937d4c1c  vmovaps xmm15, [rsp+0xE0]
000074fc937d4c25  add rsp, 0xF0
000074fc937d4c2c  pop r11
000074fc937d4c2e  pop r10
000074fc937d4c30  pop r9
000074fc937d4c32  pop r8
000074fc937d4c34  pop rsi
000074fc937d4c35  pop rdi
000074fc937d4c36  pop rdx
000074fc937d4c37  pop rcx
000074fc937d4c38  pop rax
000074fc937d4c39  add rsp, 0x08
000074fc937d4c3d  jmp 0x000074FC937D01DD
000074fc937d4c42  sub rsp, 0x08
000074fc937d4c46  push rax
000074fc937d4c47  push rcx
000074fc937d4c48  push rdx
000074fc937d4c49  push rdi
000074fc937d4c4a  push rsi
000074fc937d4c4b  push r8
000074fc937d4c4d  push r9
000074fc937d4c4f  push r10
000074fc937d4c51  push r11
000074fc937d4c53  sub rsp, 0xF0
000074fc937d4c5a  vmovaps [rsp], xmm0
000074fc937d4c5f  vmovaps [rsp+0x10], xmm1
000074fc937d4c65  vmovaps [rsp+0x20], xmm2
000074fc937d4c6b  vmovaps [rsp+0x30], xmm3
000074fc937d4c71  vmovaps [rsp+0x40], xmm4
000074fc937d4c77  vmovaps [rsp+0x50], xmm5
000074fc937d4c7d  vmovaps [rsp+0x60], xmm6
000074fc937d4c83  vmovaps [rsp+0x70], xmm7
000074fc937d4c89  vmovaps [rsp+0x80], xmm8
000074fc937d4c92  vmovaps [rsp+0x90], xmm9
000074fc937d4c9b  vmovaps [rsp+0xA0], xmm10
000074fc937d4ca4  vmovaps [rsp+0xB0], xmm11
000074fc937d4cad  vmovaps [rsp+0xC0], xmm12
000074fc937d4cb6  vmovaps [rsp+0xD0], xmm13
000074fc937d4cbf  vmovaps [rsp+0xE0], xmm15
000074fc937d4cc8  sub rsp, 0x30
000074fc937d4ccc  movaps [rsp], xmm14
000074fc937d4cd1  movaps [rsp+0x10], xmm4
000074fc937d4cd6  movaps [rsp+0x20], xmm1
000074fc937d4cdb  lea rdi, [rsp]
000074fc937d4cdf  mov esi, 0x00
000074fc937d4ce4  mov rax, 0x5D72CBC20530
000074fc937d4cee  call rax
000074fc937d4cf0  movaps xmm14, [rsp]
000074fc937d4cf5  add rsp, 0x30
000074fc937d4cf9  vmovaps xmm0, [rsp]
000074fc937d4cfe  vmovaps xmm1, [rsp+0x10]
000074fc937d4d04  vmovaps xmm2, [rsp+0x20]
000074fc937d4d0a  vmovaps xmm3, [rsp+0x30]
000074fc937d4d10  vmovaps xmm4, [rsp+0x40]
000074fc937d4d16  vmovaps xmm5, [rsp+0x50]
000074fc937d4d1c  vmovaps xmm6, [rsp+0x60]
000074fc937d4d22  vmovaps xmm7, [rsp+0x70]
000074fc937d4d28  vmovaps xmm8, [rsp+0x80]
000074fc937d4d31  vmovaps xmm9, [rsp+0x90]
000074fc937d4d3a  vmovaps xmm10, [rsp+0xA0]
000074fc937d4d43  vmovaps xmm11, [rsp+0xB0]
000074fc937d4d4c  vmovaps xmm12, [rsp+0xC0]
000074fc937d4d55  vmovaps xmm13, [rsp+0xD0]
000074fc937d4d5e  vmovaps xmm15, [rsp+0xE0]
000074fc937d4d67  add rsp, 0xF0
000074fc937d4d6e  pop r11
000074fc937d4d70  pop r10
000074fc937d4d72  pop r9
000074fc937d4d74  pop r8
000074fc937d4d76  pop rsi
000074fc937d4d77  pop rdi
000074fc937d4d78  pop rdx
000074fc937d4d79  pop rcx
000074fc937d4d7a  pop rax
000074fc937d4d7b  add rsp, 0x08
000074fc937d4d7f  jmp 0x000074FC937D0203
000074fc937d4d84  sub rsp, 0x08
000074fc937d4d88  push rax
000074fc937d4d89  push rcx
000074fc937d4d8a  push rdx
000074fc937d4d8b  push rdi
000074fc937d4d8c  push rsi
000074fc937d4d8d  push r8
000074fc937d4d8f  push r9
000074fc937d4d91  push r10
000074fc937d4d93  push r11
000074fc937d4d95  sub rsp, 0xF0
000074fc937d4d9c  vmovaps [rsp], xmm0
000074fc937d4da1  vmovaps [rsp+0x10], xmm2
000074fc937d4da7  vmovaps [rsp+0x20], xmm3
000074fc937d4dad  vmovaps [rsp+0x30], xmm4
000074fc937d4db3  vmovaps [rsp+0x40], xmm5
000074fc937d4db9  vmovaps [rsp+0x50], xmm6
000074fc937d4dbf  vmovaps [rsp+0x60], xmm7
000074fc937d4dc5  vmovaps [rsp+0x70], xmm8
000074fc937d4dcb  vmovaps [rsp+0x80], xmm9
000074fc937d4dd4  vmovaps [rsp+0x90], xmm10
000074fc937d4ddd  vmovaps [rsp+0xA0], xmm11
000074fc937d4de6  vmovaps [rsp+0xB0], xmm12
000074fc937d4def  vmovaps [rsp+0xC0], xmm13
000074fc937d4df8  vmovaps [rsp+0xD0], xmm14
000074fc937d4e01  vmovaps [rsp+0xE0], xmm15
000074fc937d4e0a  sub rsp, 0x30
000074fc937d4e0e  movaps [rsp], xmm1
000074fc937d4e12  movaps [rsp+0x10], xmm12
000074fc937d4e18  movaps [rsp+0x20], xmm11
000074fc937d4e1e  lea rdi, [rsp]
000074fc937d4e22  mov esi, 0x00
000074fc937d4e27  mov rax, 0x5D72CBC20530
000074fc937d4e31  call rax
000074fc937d4e33  movaps xmm1, [rsp]
000074fc937d4e37  add rsp, 0x30
000074fc937d4e3b  vmovaps xmm0, [rsp]
000074fc937d4e40  vmovaps xmm2, [rsp+0x10]
000074fc937d4e46  vmovaps xmm3, [rsp+0x20]
000074fc937d4e4c  vmovaps xmm4, [rsp+0x30]
000074fc937d4e52  vmovaps xmm5, [rsp+0x40]
000074fc937d4e58  vmovaps xmm6, [rsp+0x50]
000074fc937d4e5e  vmovaps xmm7, [rsp+0x60]
000074fc937d4e64  vmovaps xmm8, [rsp+0x70]
000074fc937d4e6a  vmovaps xmm9, [rsp+0x80]
000074fc937d4e73  vmovaps xmm10, [rsp+0x90]
000074fc937d4e7c  vmovaps xmm11, [rsp+0xA0]
000074fc937d4e85  vmovaps xmm12, [rsp+0xB0]
000074fc937d4e8e  vmovaps xmm13, [rsp+0xC0]
000074fc937d4e97  vmovaps xmm14, [rsp+0xD0]
000074fc937d4ea0  vmovaps xmm15, [rsp+0xE0]
000074fc937d4ea9  add rsp, 0xF0
000074fc937d4eb0  pop r11
000074fc937d4eb2  pop r10
000074fc937d4eb4  pop r9
000074fc937d4eb6  pop r8
000074fc937d4eb8  pop rsi
000074fc937d4eb9  pop rdi
000074fc937d4eba  pop rdx
000074fc937d4ebb  pop rcx
000074fc937d4ebc  pop rax
000074fc937d4ebd  add rsp, 0x08
000074fc937d4ec1  jmp 0x000074FC937D0224
000074fc937d4ec6  call 0x000074FC936E20A0
000074fc937d4ecb  jmp 0x000074FC937D0232
000074fc937d4ed0  call 0x000074FC93609D70
000074fc937d4ed5  jmp 0x000074FC937D023C
000074fc937d4eda  sub rsp, 0x08
000074fc937d4ede  push rax
000074fc937d4edf  push rcx
000074fc937d4ee0  push rdx
000074fc937d4ee1  push rdi
000074fc937d4ee2  push rsi
000074fc937d4ee3  push r8
000074fc937d4ee5  push r9
000074fc937d4ee7  push r10
000074fc937d4ee9  push r11
000074fc937d4eeb  sub rsp, 0xF0
000074fc937d4ef2  vmovaps [rsp], xmm0
000074fc937d4ef7  vmovaps [rsp+0x10], xmm1
000074fc937d4efd  vmovaps [rsp+0x20], xmm2
000074fc937d4f03  vmovaps [rsp+0x30], xmm3
000074fc937d4f09  vmovaps [rsp+0x40], xmm4
000074fc937d4f0f  vmovaps [rsp+0x50], xmm5
000074fc937d4f15  vmovaps [rsp+0x60], xmm6
000074fc937d4f1b  vmovaps [rsp+0x70], xmm8
000074fc937d4f21  vmovaps [rsp+0x80], xmm9
000074fc937d4f2a  vmovaps [rsp+0x90], xmm10
000074fc937d4f33  vmovaps [rsp+0xA0], xmm11
000074fc937d4f3c  vmovaps [rsp+0xB0], xmm12
000074fc937d4f45  vmovaps [rsp+0xC0], xmm13
000074fc937d4f4e  vmovaps [rsp+0xD0], xmm14
000074fc937d4f57  vmovaps [rsp+0xE0], xmm15
000074fc937d4f60  sub rsp, 0x30
000074fc937d4f64  movaps [rsp], xmm7
000074fc937d4f68  movaps [rsp+0x10], xmm15
000074fc937d4f6e  movaps [rsp+0x20], xmm10
000074fc937d4f74  lea rdi, [rsp]
000074fc937d4f78  mov esi, 0x00
000074fc937d4f7d  mov rax, 0x5D72CBC20530
000074fc937d4f87  call rax
000074fc937d4f89  movaps xmm7, [rsp]
000074fc937d4f8d  add rsp, 0x30
000074fc937d4f91  vmovaps xmm0, [rsp]
000074fc937d4f96  vmovaps xmm1, [rsp+0x10]
000074fc937d4f9c  vmovaps xmm2, [rsp+0x20]
000074fc937d4fa2  vmovaps xmm3, [rsp+0x30]
000074fc937d4fa8  vmovaps xmm4, [rsp+0x40]
000074fc937d4fae  vmovaps xmm5, [rsp+0x50]
000074fc937d4fb4  vmovaps xmm6, [rsp+0x60]
000074fc937d4fba  vmovaps xmm8, [rsp+0x70]
000074fc937d4fc0  vmovaps xmm9, [rsp+0x80]
000074fc937d4fc9  vmovaps xmm10, [rsp+0x90]
000074fc937d4fd2  vmovaps xmm11, [rsp+0xA0]
000074fc937d4fdb  vmovaps xmm12, [rsp+0xB0]
000074fc937d4fe4  vmovaps xmm13, [rsp+0xC0]
000074fc937d4fed  vmovaps xmm14, [rsp+0xD0]
000074fc937d4ff6  vmovaps xmm15, [rsp+0xE0]
000074fc937d4fff  add rsp, 0xF0
000074fc937d5006  pop r11
000074fc937d5008  pop r10
000074fc937d500a  pop r9
000074fc937d500c  pop r8
000074fc937d500e  pop rsi
000074fc937d500f  pop rdi
000074fc937d5010  pop rdx
000074fc937d5011  pop rcx
000074fc937d5012  pop rax
000074fc937d5013  add rsp, 0x08
000074fc937d5017  jmp 0x000074FC937D025D
000074fc937d501c  sub rsp, 0x08
000074fc937d5020  push rax
000074fc937d5021  push rcx
000074fc937d5022  push rdx
000074fc937d5023  push rdi
000074fc937d5024  push rsi
000074fc937d5025  push r8
000074fc937d5027  push r9
000074fc937d5029  push r10
000074fc937d502b  push r11
000074fc937d502d  sub rsp, 0xF0
000074fc937d5034  vmovaps [rsp], xmm0
000074fc937d5039  vmovaps [rsp+0x10], xmm1
000074fc937d503f  vmovaps [rsp+0x20], xmm2
000074fc937d5045  vmovaps [rsp+0x30], xmm3
000074fc937d504b  vmovaps [rsp+0x40], xmm4
000074fc937d5051  vmovaps [rsp+0x50], xmm5
000074fc937d5057  vmovaps [rsp+0x60], xmm6
000074fc937d505d  vmovaps [rsp+0x70], xmm7
000074fc937d5063  vmovaps [rsp+0x80], xmm8
000074fc937d506c  vmovaps [rsp+0x90], xmm9
000074fc937d5075  vmovaps [rsp+0xA0], xmm11
000074fc937d507e  vmovaps [rsp+0xB0], xmm12
000074fc937d5087  vmovaps [rsp+0xC0], xmm13
000074fc937d5090  vmovaps [rsp+0xD0], xmm14
000074fc937d5099  vmovaps [rsp+0xE0], xmm15
000074fc937d50a2  sub rsp, 0x30
000074fc937d50a6  movaps [rsp], xmm10
000074fc937d50ab  movaps [rsp+0x10], xmm11
000074fc937d50b1  movaps [rsp+0x20], xmm15
000074fc937d50b7  lea rdi, [rsp]
000074fc937d50bb  mov esi, 0x00
000074fc937d50c0  mov rax, 0x5D72CBC20530
000074fc937d50ca  call rax
000074fc937d50cc  movaps xmm10, [rsp]
000074fc937d50d1  add rsp, 0x30
000074fc937d50d5  vmovaps xmm0, [rsp]
000074fc937d50da  vmovaps xmm1, [rsp+0x10]
000074fc937d50e0  vmovaps xmm2, [rsp+0x20]
000074fc937d50e6  vmovaps xmm3, [rsp+0x30]
000074fc937d50ec  vmovaps xmm4, [rsp+0x40]
000074fc937d50f2  vmovaps xmm5, [rsp+0x50]
000074fc937d50f8  vmovaps xmm6, [rsp+0x60]
000074fc937d50fe  vmovaps xmm7, [rsp+0x70]
000074fc937d5104  vmovaps xmm8, [rsp+0x80]
000074fc937d510d  vmovaps xmm9, [rsp+0x90]
000074fc937d5116  vmovaps xmm11, [rsp+0xA0]
000074fc937d511f  vmovaps xmm12, [rsp+0xB0]
000074fc937d5128  vmovaps xmm13, [rsp+0xC0]
000074fc937d5131  vmovaps xmm14, [rsp+0xD0]
000074fc937d513a  vmovaps xmm15, [rsp+0xE0]
000074fc937d5143  add rsp, 0xF0
000074fc937d514a  pop r11
000074fc937d514c  pop r10
000074fc937d514e  pop r9
000074fc937d5150  pop r8
000074fc937d5152  pop rsi
000074fc937d5153  pop rdi
000074fc937d5154  pop rdx
000074fc937d5155  pop rcx
000074fc937d5156  pop rax
000074fc937d5157  add rsp, 0x08
000074fc937d515b  jmp 0x000074FC937D028B
000074fc937d5160  sub rsp, 0x08
000074fc937d5164  push rax
000074fc937d5165  push rcx
000074fc937d5166  push rdx
000074fc937d5167  push rdi
000074fc937d5168  push rsi
000074fc937d5169  push r8
000074fc937d516b  push r9
000074fc937d516d  push r10
000074fc937d516f  push r11
000074fc937d5171  sub rsp, 0xF0
000074fc937d5178  vmovaps [rsp], xmm0
000074fc937d517d  vmovaps [rsp+0x10], xmm1
000074fc937d5183  vmovaps [rsp+0x20], xmm2
000074fc937d5189  vmovaps [rsp+0x30], xmm3
000074fc937d518f  vmovaps [rsp+0x40], xmm4
000074fc937d5195  vmovaps [rsp+0x50], xmm5
000074fc937d519b  vmovaps [rsp+0x60], xmm6
000074fc937d51a1  vmovaps [rsp+0x70], xmm7
000074fc937d51a7  vmovaps [rsp+0x80], xmm8
000074fc937d51b0  vmovaps [rsp+0x90], xmm9
000074fc937d51b9  vmovaps [rsp+0xA0], xmm10
000074fc937d51c2  vmovaps [rsp+0xB0], xmm12
000074fc937d51cb  vmovaps [rsp+0xC0], xmm13
000074fc937d51d4  vmovaps [rsp+0xD0], xmm14
000074fc937d51dd  vmovaps [rsp+0xE0], xmm15
000074fc937d51e6  sub rsp, 0x30
000074fc937d51ea  movaps [rsp], xmm11
000074fc937d51ef  movaps [rsp+0x10], xmm12
000074fc937d51f5  movaps [rsp+0x20], xmm15
000074fc937d51fb  lea rdi, [rsp]
000074fc937d51ff  mov esi, 0x00
000074fc937d5204  mov rax, 0x5D72CBC20530
000074fc937d520e  call rax
000074fc937d5210  movaps xmm11, [rsp]
000074fc937d5215  add rsp, 0x30
000074fc937d5219  vmovaps xmm0, [rsp]
000074fc937d521e  vmovaps xmm1, [rsp+0x10]
000074fc937d5224  vmovaps xmm2, [rsp+0x20]
000074fc937d522a  vmovaps xmm3, [rsp+0x30]
000074fc937d5230  vmovaps xmm4, [rsp+0x40]
000074fc937d5236  vmovaps xmm5, [rsp+0x50]
000074fc937d523c  vmovaps xmm6, [rsp+0x60]
000074fc937d5242  vmovaps xmm7, [rsp+0x70]
000074fc937d5248  vmovaps xmm8, [rsp+0x80]
000074fc937d5251  vmovaps xmm9, [rsp+0x90]
000074fc937d525a  vmovaps xmm10, [rsp+0xA0]
000074fc937d5263  vmovaps xmm12, [rsp+0xB0]
000074fc937d526c  vmovaps xmm13, [rsp+0xC0]
000074fc937d5275  vmovaps xmm14, [rsp+0xD0]
000074fc937d527e  vmovaps xmm15, [rsp+0xE0]
000074fc937d5287  add rsp, 0xF0
000074fc937d528e  pop r11
000074fc937d5290  pop r10
000074fc937d5292  pop r9
000074fc937d5294  pop r8
000074fc937d5296  pop rsi
000074fc937d5297  pop rdi
000074fc937d5298  pop rdx
000074fc937d5299  pop rcx
000074fc937d529a  pop rax
000074fc937d529b  add rsp, 0x08
000074fc937d529f  jmp 0x000074FC937D02B9
000074fc937d52a4  sub rsp, 0x08
000074fc937d52a8  push rax
000074fc937d52a9  push rcx
000074fc937d52aa  push rdx
000074fc937d52ab  push rdi
000074fc937d52ac  push rsi
000074fc937d52ad  push r8
000074fc937d52af  push r9
000074fc937d52b1  push r10
000074fc937d52b3  push r11
000074fc937d52b5  sub rsp, 0xF0
000074fc937d52bc  vmovaps [rsp], xmm0
000074fc937d52c1  vmovaps [rsp+0x10], xmm1
000074fc937d52c7  vmovaps [rsp+0x20], xmm2
000074fc937d52cd  vmovaps [rsp+0x30], xmm3
000074fc937d52d3  vmovaps [rsp+0x40], xmm4
000074fc937d52d9  vmovaps [rsp+0x50], xmm5
000074fc937d52df  vmovaps [rsp+0x60], xmm6
000074fc937d52e5  vmovaps [rsp+0x70], xmm7
000074fc937d52eb  vmovaps [rsp+0x80], xmm8
000074fc937d52f4  vmovaps [rsp+0x90], xmm9
000074fc937d52fd  vmovaps [rsp+0xA0], xmm10
000074fc937d5306  vmovaps [rsp+0xB0], xmm11
000074fc937d530f  vmovaps [rsp+0xC0], xmm12
000074fc937d5318  vmovaps [rsp+0xD0], xmm13
000074fc937d5321  vmovaps [rsp+0xE0], xmm14
000074fc937d532a  sub rsp, 0x30
000074fc937d532e  movaps [rsp], xmm15
000074fc937d5333  movaps [rsp+0x10], xmm13
000074fc937d5339  movaps [rsp+0x20], xmm9
000074fc937d533f  lea rdi, [rsp]
000074fc937d5343  mov esi, 0x00
000074fc937d5348  mov rax, 0x5D72CBC20530
000074fc937d5352  call rax
000074fc937d5354  movaps xmm15, [rsp]
000074fc937d5359  add rsp, 0x30
000074fc937d535d  vmovaps xmm0, [rsp]
000074fc937d5362  vmovaps xmm1, [rsp+0x10]
000074fc937d5368  vmovaps xmm2, [rsp+0x20]
000074fc937d536e  vmovaps xmm3, [rsp+0x30]
000074fc937d5374  vmovaps xmm4, [rsp+0x40]
000074fc937d537a  vmovaps xmm5, [rsp+0x50]
000074fc937d5380  vmovaps xmm6, [rsp+0x60]
000074fc937d5386  vmovaps xmm7, [rsp+0x70]
000074fc937d538c  vmovaps xmm8, [rsp+0x80]
000074fc937d5395  vmovaps xmm9, [rsp+0x90]
000074fc937d539e  vmovaps xmm10, [rsp+0xA0]
000074fc937d53a7  vmovaps xmm11, [rsp+0xB0]
000074fc937d53b0  vmovaps xmm12, [rsp+0xC0]
000074fc937d53b9  vmovaps xmm13, [rsp+0xD0]
000074fc937d53c2  vmovaps xmm14, [rsp+0xE0]
000074fc937d53cb  add rsp, 0xF0
000074fc937d53d2  pop r11
000074fc937d53d4  pop r10
000074fc937d53d6  pop r9
000074fc937d53d8  pop r8
000074fc937d53da  pop rsi
000074fc937d53db  pop rdi
000074fc937d53dc  pop rdx
000074fc937d53dd  pop rcx
000074fc937d53de  pop rax
000074fc937d53df  add rsp, 0x08
000074fc937d53e3  jmp 0x000074FC937D02D4
000074fc937d53e8  sub rsp, 0x08
000074fc937d53ec  push rax
000074fc937d53ed  push rcx
000074fc937d53ee  push rdx
000074fc937d53ef  push rdi
000074fc937d53f0  push rsi
000074fc937d53f1  push r8
000074fc937d53f3  push r9
000074fc937d53f5  push r10
000074fc937d53f7  push r11
000074fc937d53f9  sub rsp, 0xF0
000074fc937d5400  vmovaps [rsp], xmm0
000074fc937d5405  vmovaps [rsp+0x10], xmm1
000074fc937d540b  vmovaps [rsp+0x20], xmm2
000074fc937d5411  vmovaps [rsp+0x30], xmm3
000074fc937d5417  vmovaps [rsp+0x40], xmm4
000074fc937d541d  vmovaps [rsp+0x50], xmm5
000074fc937d5423  vmovaps [rsp+0x60], xmm6
000074fc937d5429  vmovaps [rsp+0x70], xmm7
000074fc937d542f  vmovaps [rsp+0x80], xmm8
000074fc937d5438  vmovaps [rsp+0x90], xmm9
000074fc937d5441  vmovaps [rsp+0xA0], xmm10
000074fc937d544a  vmovaps [rsp+0xB0], xmm11
000074fc937d5453  vmovaps [rsp+0xC0], xmm12
000074fc937d545c  vmovaps [rsp+0xD0], xmm14
000074fc937d5465  vmovaps [rsp+0xE0], xmm15
000074fc937d546e  sub rsp, 0x30
000074fc937d5472  movaps [rsp], xmm13
000074fc937d5477  movaps [rsp+0x10], xmm8
000074fc937d547d  movaps [rsp+0x20], xmm14
000074fc937d5483  lea rdi, [rsp]
000074fc937d5487  mov esi, 0x00
000074fc937d548c  mov rax, 0x5D72CBC20530
000074fc937d5496  call rax
000074fc937d5498  movaps xmm13, [rsp]
000074fc937d549d  add rsp, 0x30
000074fc937d54a1  vmovaps xmm0, [rsp]
000074fc937d54a6  vmovaps xmm1, [rsp+0x10]
000074fc937d54ac  vmovaps xmm2, [rsp+0x20]
000074fc937d54b2  vmovaps xmm3, [rsp+0x30]
000074fc937d54b8  vmovaps xmm4, [rsp+0x40]
000074fc937d54be  vmovaps xmm5, [rsp+0x50]
000074fc937d54c4  vmovaps xmm6, [rsp+0x60]
000074fc937d54ca  vmovaps xmm7, [rsp+0x70]
000074fc937d54d0  vmovaps xmm8, [rsp+0x80]
000074fc937d54d9  vmovaps xmm9, [rsp+0x90]
000074fc937d54e2  vmovaps xmm10, [rsp+0xA0]
000074fc937d54eb  vmovaps xmm11, [rsp+0xB0]
000074fc937d54f4  vmovaps xmm12, [rsp+0xC0]
000074fc937d54fd  vmovaps xmm14, [rsp+0xD0]
000074fc937d5506  vmovaps xmm15, [rsp+0xE0]
000074fc937d550f  add rsp, 0xF0
000074fc937d5516  pop r11
000074fc937d5518  pop r10
000074fc937d551a  pop r9
000074fc937d551c  pop r8
000074fc937d551e  pop rsi
000074fc937d551f  pop rdi
000074fc937d5520  pop rdx
000074fc937d5521  pop rcx
000074fc937d5522  pop rax
000074fc937d5523  add rsp, 0x08
000074fc937d5527  jmp 0x000074FC937D02F7
000074fc937d552c  sub rsp, 0x08
000074fc937d5530  push rax
000074fc937d5531  push rcx
000074fc937d5532  push rdx
000074fc937d5533  push rdi
000074fc937d5534  push rsi
000074fc937d5535  push r8
000074fc937d5537  push r9
000074fc937d5539  push r10
000074fc937d553b  push r11
000074fc937d553d  sub rsp, 0xF0
000074fc937d5544  vmovaps [rsp], xmm0
000074fc937d5549  vmovaps [rsp+0x10], xmm1
000074fc937d554f  vmovaps [rsp+0x20], xmm2
000074fc937d5555  vmovaps [rsp+0x30], xmm3
000074fc937d555b  vmovaps [rsp+0x40], xmm4
000074fc937d5561  vmovaps [rsp+0x50], xmm5
000074fc937d5567  vmovaps [rsp+0x60], xmm6
000074fc937d556d  vmovaps [rsp+0x70], xmm7
000074fc937d5573  vmovaps [rsp+0x80], xmm8
000074fc937d557c  vmovaps [rsp+0x90], xmm9
000074fc937d5585  vmovaps [rsp+0xA0], xmm10
000074fc937d558e  vmovaps [rsp+0xB0], xmm11
000074fc937d5597  vmovaps [rsp+0xC0], xmm12
000074fc937d55a0  vmovaps [rsp+0xD0], xmm13
000074fc937d55a9  vmovaps [rsp+0xE0], xmm15
000074fc937d55b2  sub rsp, 0x30
000074fc937d55b6  movaps [rsp], xmm14
000074fc937d55bb  movaps [rsp+0x10], xmm1
000074fc937d55c0  movaps [rsp+0x20], xmm10
000074fc937d55c6  lea rdi, [rsp]
000074fc937d55ca  mov esi, 0x00
000074fc937d55cf  mov rax, 0x5D72CBC20530
000074fc937d55d9  call rax
000074fc937d55db  movaps xmm14, [rsp]
000074fc937d55e0  add rsp, 0x30
000074fc937d55e4  vmovaps xmm0, [rsp]
000074fc937d55e9  vmovaps xmm1, [rsp+0x10]
000074fc937d55ef  vmovaps xmm2, [rsp+0x20]
000074fc937d55f5  vmovaps xmm3, [rsp+0x30]
000074fc937d55fb  vmovaps xmm4, [rsp+0x40]
000074fc937d5601  vmovaps xmm5, [rsp+0x50]
000074fc937d5607  vmovaps xmm6, [rsp+0x60]
000074fc937d560d  vmovaps xmm7, [rsp+0x70]
000074fc937d5613  vmovaps xmm8, [rsp+0x80]
000074fc937d561c  vmovaps xmm9, [rsp+0x90]
000074fc937d5625  vmovaps xmm10, [rsp+0xA0]
000074fc937d562e  vmovaps xmm11, [rsp+0xB0]
000074fc937d5637  vmovaps xmm12, [rsp+0xC0]
000074fc937d5640  vmovaps xmm13, [rsp+0xD0]
000074fc937d5649  vmovaps xmm15, [rsp+0xE0]
000074fc937d5652  add rsp, 0xF0
000074fc937d5659  pop r11
000074fc937d565b  pop r10
000074fc937d565d  pop r9
000074fc937d565f  pop r8
000074fc937d5661  pop rsi
000074fc937d5662  pop rdi
000074fc937d5663  pop rdx
000074fc937d5664  pop rcx
000074fc937d5665  pop rax
000074fc937d5666  add rsp, 0x08
000074fc937d566a  jmp 0x000074FC937D031A
000074fc937d566f  sub rsp, 0x08
000074fc937d5673  push rax
000074fc937d5674  push rcx
000074fc937d5675  push rdx
000074fc937d5676  push rdi
000074fc937d5677  push rsi
000074fc937d5678  push r8
000074fc937d567a  push r9
000074fc937d567c  push r10
000074fc937d567e  push r11
000074fc937d5680  sub rsp, 0xF0
000074fc937d5687  vmovaps [rsp], xmm0
000074fc937d568c  vmovaps [rsp+0x10], xmm2
000074fc937d5692  vmovaps [rsp+0x20], xmm3
000074fc937d5698  vmovaps [rsp+0x30], xmm4
000074fc937d569e  vmovaps [rsp+0x40], xmm5
000074fc937d56a4  vmovaps [rsp+0x50], xmm6
000074fc937d56aa  vmovaps [rsp+0x60], xmm7
000074fc937d56b0  vmovaps [rsp+0x70], xmm8
000074fc937d56b6  vmovaps [rsp+0x80], xmm9
000074fc937d56bf  vmovaps [rsp+0x90], xmm10
000074fc937d56c8  vmovaps [rsp+0xA0], xmm11
000074fc937d56d1  vmovaps [rsp+0xB0], xmm12
000074fc937d56da  vmovaps [rsp+0xC0], xmm13
000074fc937d56e3  vmovaps [rsp+0xD0], xmm14
000074fc937d56ec  vmovaps [rsp+0xE0], xmm15
000074fc937d56f5  sub rsp, 0x30
000074fc937d56f9  movaps [rsp], xmm1
000074fc937d56fd  movaps [rsp+0x10], xmm7
000074fc937d5702  movaps [rsp+0x20], xmm11
000074fc937d5708  lea rdi, [rsp]
000074fc937d570c  mov esi, 0x00
000074fc937d5711  mov rax, 0x5D72CBC20530
000074fc937d571b  call rax
000074fc937d571d  movaps xmm1, [rsp]
000074fc937d5721  add rsp, 0x30
000074fc937d5725  vmovaps xmm0, [rsp]
000074fc937d572a  vmovaps xmm2, [rsp+0x10]
000074fc937d5730  vmovaps xmm3, [rsp+0x20]
000074fc937d5736  vmovaps xmm4, [rsp+0x30]
000074fc937d573c  vmovaps xmm5, [rsp+0x40]
000074fc937d5742  vmovaps xmm6, [rsp+0x50]
000074fc937d5748  vmovaps xmm7, [rsp+0x60]
000074fc937d574e  vmovaps xmm8, [rsp+0x70]
000074fc937d5754  vmovaps xmm9, [rsp+0x80]
000074fc937d575d  vmovaps xmm10, [rsp+0x90]
000074fc937d5766  vmovaps xmm11, [rsp+0xA0]
000074fc937d576f  vmovaps xmm12, [rsp+0xB0]
000074fc937d5778  vmovaps xmm13, [rsp+0xC0]
000074fc937d5781  vmovaps xmm14, [rsp+0xD0]
000074fc937d578a  vmovaps xmm15, [rsp+0xE0]
000074fc937d5793  add rsp, 0xF0
000074fc937d579a  pop r11
000074fc937d579c  pop r10
000074fc937d579e  pop r9
000074fc937d57a0  pop r8
000074fc937d57a2  pop rsi
000074fc937d57a3  pop rdi
000074fc937d57a4  pop rdx
000074fc937d57a5  pop rcx
000074fc937d57a6  pop rax
000074fc937d57a7  add rsp, 0x08
000074fc937d57ab  jmp 0x000074FC937D033B
000074fc937d57b0  call 0x000074FC9360E880
000074fc937d57b5  jmp 0x000074FC937D034E
000074fc937d57ba  call 0x000074FC9360C380
000074fc937d57bf  jmp 0x000074FC937D0359
000074fc937d57c4  call 0x000074FC9360D600
000074fc937d57c9  jmp 0x000074FC937D0364
000074fc937d57ce  call 0x000074FC935FF540
000074fc937d57d3  jmp 0x000074FC937D036F
000074fc937d57d8  int3
000074fc937d57d9  nop [rax], eax
000074fc937d57e0  mov rax, [r15+0x40]
000074fc937d57e4  mov r14, [r15+0x58]
000074fc937d57e8  lea r12, [rax+r14*1]
000074fc937d57ec  movaps xmm1, [r15+0x1D0]
000074fc937d57f4  vmovaps [rsp+0x10], xmm1
000074fc937d57fa  vmovaps xmm15, [rsp+0x10]
000074fc937d5800  por xmm1, xmm15
000074fc937d5805  movaps xmm14, [r15+0x1A0]
000074fc937d580d  vmovaps [rsp+0x10], xmm14
000074fc937d5813  vmovaps xmm13, [rsp+0x10]
000074fc937d5819  por xmm14, xmm13
000074fc937d581e  lea rax, [r12+0x30]
000074fc937d5823  mov r11, [r13+rax*1]
000074fc937d5828  lea rax, [r12+0x38]
000074fc937d582d  mov r10, [r13+rax*1]
000074fc937d5832  movq xmm13, r11
000074fc937d5837  movq xmm12, r10
000074fc937d583c  movq xmm13, xmm13
000074fc937d5841  vmovaps [rsp+0x10], xmm13
000074fc937d5847  movq xmm13, xmm13
000074fc937d584c  movaps [r15+0x130], xmm13
000074fc937d5854  movq xmm12, xmm12
000074fc937d5859  vmovaps [rsp+0x20], xmm12
000074fc937d585f  movq xmm12, xmm12
000074fc937d5864  movaps [r15+0x280], xmm12
000074fc937d586c  movaps xmm13, [r15+0x270]
000074fc937d5874  vmovaps [rsp+0x30], xmm13
000074fc937d587a  vmovaps xmm12, [rsp+0x30]
000074fc937d5880  por xmm13, xmm12
000074fc937d5885  lea rax, [r12+0x20]
000074fc937d588a  mov r11, [r13+rax*1]
000074fc937d588f  lea rax, [r12+0x28]
000074fc937d5894  mov r10, [r13+rax*1]
000074fc937d5899  movq xmm12, r11
000074fc937d589e  movq xmm11, r10
000074fc937d58a3  movq xmm12, xmm12
000074fc937d58a8  vmovaps [rsp+0x30], xmm12
000074fc937d58ae  movq xmm12, xmm12
000074fc937d58b3  movaps [r15+0x150], xmm12
000074fc937d58bb  movq xmm11, xmm11
000074fc937d58c0  vmovaps [rsp+0x40], xmm11
000074fc937d58c6  movq xmm11, xmm11
000074fc937d58cb  movaps [r15+0x140], xmm11
000074fc937d58d3  lea rax, [r12+0x10]
000074fc937d58d8  mov r11, [r13+rax*1]
000074fc937d58dd  lea rax, [r12+0x18]
000074fc937d58e2  mov r10, [r13+rax*1]
000074fc937d58e7  movq xmm12, r11
000074fc937d58ec  movq xmm11, r10
000074fc937d58f1  movq xmm12, xmm12
000074fc937d58f6  vmovaps [rsp+0x50], xmm12
000074fc937d58fc  movq xmm12, xmm12
000074fc937d5901  movaps [r15+0x170], xmm12
000074fc937d5909  movq xmm11, xmm11
000074fc937d590e  vmovaps [rsp+0x60], xmm11
000074fc937d5914  movq xmm11, xmm11
000074fc937d5919  movaps [r15+0x160], xmm11
000074fc937d5921  mov rax, [r13+r12*1]
000074fc937d5926  vmovq xmm12, rax
000074fc937d592b  vpbroadcastq xmm12, xmm12
000074fc937d5930  lea rax, [r12+0x08]
000074fc937d5935  mov r12, [r13+rax*1]
000074fc937d593a  movq xmm11, r12
000074fc937d593f  movaps [r15+0x230], xmm11
000074fc937d5947  mov rax, [r15+0xF8]
000074fc937d594e  lea r12, [rax+0x50]
000074fc937d5952  movups xmm11, [r13+r12*1]
000074fc937d5958  lea r12, [rax+0x60]
000074fc937d595c  movups xmm10, [r13+r12*1]
000074fc937d5962  lea r12, [rax+0x30]
000074fc937d5966  movups xmm9, [r13+r12*1]
000074fc937d596c  mov r12, [r15+0x50]
000074fc937d5970  lea r11, [r12+r14*1]
000074fc937d5974  mov [r15+0x60], r11
000074fc937d5978  lea r12, [r14+0x40]
000074fc937d597c  mov [r15+0x58], r12
000074fc937d5980  movaps xmm8, xmm12
000074fc937d5984  mulpd xmm8, xmm15
000074fc937d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc937d598f  ptest xmm7, xmm7
000074fc937d5994  jnz 0x000074FC937D67B7
000074fc937d599a  movq xmm15, qword ptr [r15+0x230]
000074fc937d59a3  vmovaps [rsp+0x70], xmm15
000074fc937d59a9  vpermilpd xmm15, xmm15, 0x00
000074fc937d59af  movaps xmm7, xmm9
000074fc937d59b3  mulpd xmm7, xmm15
000074fc937d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc937d59bd  ptest xmm6, xmm6
000074fc937d59c2  jnz 0x000074FC937D68FB
000074fc937d59c8  vxorps xmm15, xmm15, xmm15
000074fc937d59cd  vpbroadcastq xmm15, xmm15
000074fc937d59d2  movaps xmm9, xmm12
000074fc937d59d6  mulpd xmm9, xmm10
000074fc937d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc937d59e1  ptest xmm6, xmm6
000074fc937d59e6  jnz 0x000074FC937D6A3D
000074fc937d59ec  movaps xmm10, xmm12
000074fc937d59f0  mulpd xmm10, xmm11
000074fc937d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc937d59fb  ptest xmm6, xmm6
000074fc937d5a00  jnz 0x000074FC937D6B81
000074fc937d5a06  movaps xmm11, [r15+0x1F0]
000074fc937d5a0e  movaps xmm6, xmm12
000074fc937d5a12  mulpd xmm6, xmm11
000074fc937d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc937d5a1c  ptest xmm5, xmm5
000074fc937d5a21  jnz 0x000074FC937D6CC5
000074fc937d5a27  movaps xmm12, [r15+0x2A0]
000074fc937d5a2f  vmovaps [rsp+0x80], xmm12
000074fc937d5a38  vmovaps xmm11, [rsp+0x80]
000074fc937d5a41  por xmm12, xmm11
000074fc937d5a46  movaps xmm11, [r15+0x250]
000074fc937d5a4e  vmovaps [rsp+0x80], xmm11
000074fc937d5a57  vmovaps xmm5, [rsp+0x80]
000074fc937d5a60  por xmm11, xmm5
000074fc937d5a65  vmovaps xmm4, [rsp+0x70]
000074fc937d5a6b  vpermilpd xmm4, xmm4, 0x00
000074fc937d5a71  movaps xmm3, xmm5
000074fc937d5a74  mulpd xmm3, xmm4
000074fc937d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000074fc937d5a7d  ptest xmm2, xmm2
000074fc937d5a82  jnz 0x000074FC937D6E07
000074fc937d5a88  mov [rsp+0x80], rax
000074fc937d5a90  xor eax, eax
000074fc937d5a92  mov r14d, 0x200
000074fc937d5a98  cmp r12, r14
000074fc937d5a9b  cmc
000074fc937d5a9c  lahf
000074fc937d5a9d  seto al
000074fc937d5aa0  mov [r15+0x108], eax
000074fc937d5aa7  movaps xmm5, xmm8
000074fc937d5aab  addpd xmm5, xmm15
000074fc937d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000074fc937d5ab5  ptest xmm4, xmm4
000074fc937d5aba  jnz 0x000074FC937D6F47
000074fc937d5ac0  movaps xmm8, [r15+0x1B0]
000074fc937d5ac8  movaps xmm4, xmm9
000074fc937d5acc  addpd xmm4, xmm8
000074fc937d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000074fc937d5ad6  ptest xmm2, xmm2
000074fc937d5adb  jnz 0x000074FC937D7089
000074fc937d5ae1  movaps xmm9, xmm10
000074fc937d5ae5  addpd xmm9, xmm8
000074fc937d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000074fc937d5af0  ptest xmm2, xmm2
000074fc937d5af5  jnz 0x000074FC937D71CB
000074fc937d5afb  movaps xmm10, [r15+0x2F0]
000074fc937d5b03  vmovaps [rsp+0x90], xmm10
000074fc937d5b0c  vmovaps xmm8, [rsp+0x90]
000074fc937d5b15  por xmm10, xmm8
000074fc937d5b1a  movaps xmm8, [r15+0x2E0]
000074fc937d5b22  vmovaps [rsp+0x90], xmm8
000074fc937d5b2b  vmovaps xmm2, [rsp+0x90]
000074fc937d5b34  por xmm8, xmm2
000074fc937d5b39  movaps xmm2, [r15+0x2D0]
000074fc937d5b41  vmovaps [rsp+0x90], xmm2
000074fc937d5b4a  vmovaps [rsp+0xA0], xmm1
000074fc937d5b53  vmovaps xmm1, [rsp+0x90]
000074fc937d5b5c  por xmm2, xmm1
000074fc937d5b60  movaps xmm1, [r15+0x200]
000074fc937d5b68  vmovaps [rsp+0x90], xmm1
000074fc937d5b71  vmovaps [rsp+0xB0], xmm15
000074fc937d5b7a  vmovaps xmm15, [rsp+0x90]
000074fc937d5b83  por xmm1, xmm15
000074fc937d5b88  movaps xmm15, [r15+0x1C0]
000074fc937d5b90  vmovaps [rsp+0x90], xmm15
000074fc937d5b99  vmovaps [rsp+0xC0], xmm1
000074fc937d5ba2  vmovaps xmm1, [rsp+0x90]
000074fc937d5bab  por xmm15, xmm1
000074fc937d5bb0  movaps xmm1, [r15+0x190]
000074fc937d5bb8  vmovaps [rsp+0x90], xmm1
000074fc937d5bc1  vmovaps [rsp+0xD0], xmm15
000074fc937d5bca  vmovaps xmm15, [rsp+0x90]
000074fc937d5bd3  por xmm1, xmm15
000074fc937d5bd8  movaps xmm15, [r15+0x300]
000074fc937d5be0  vmovaps [rsp+0x90], xmm15
000074fc937d5be9  vmovaps [rsp+0xE0], xmm1
000074fc937d5bf2  vmovaps xmm1, [rsp+0x90]
000074fc937d5bfb  por xmm15, xmm1
000074fc937d5c00  mov rax, [rsp+0x80]
000074fc937d5c08  lea r14, [rax+0xA0]
000074fc937d5c0f  movups xmm1, [r13+r14*1]
000074fc937d5c15  lea r14, [rax+0xB0]
000074fc937d5c1c  vmovaps [rsp+0x80], xmm1
000074fc937d5c25  movups xmm1, [r13+r14*1]
000074fc937d5c2b  vmovaps [rsp+0x90], xmm1
000074fc937d5c34  vmovaps [rsp+0xF0], xmm15
000074fc937d5c3d  vmovaps xmm15, [rsp+0xB0]
000074fc937d5c46  vmovaps [rsp+0xB0], xmm14
000074fc937d5c4f  movaps xmm1, xmm6
000074fc937d5c52  addpd xmm1, xmm15
000074fc937d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc937d5c5c  ptest xmm14, xmm14
000074fc937d5c62  jnz 0x000074FC937D7323
000074fc937d5c68  lea r14, [rax+0xF0]
000074fc937d5c6f  movups xmm15, [r13+r14*1]
000074fc937d5c75  movaps xmm14, xmm4
000074fc937d5c79  addpd xmm14, xmm3
000074fc937d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc937d5c84  ptest xmm6, xmm6
000074fc937d5c89  jnz 0x000074FC937D746E
000074fc937d5c8f  movaps xmm6, xmm9
000074fc937d5c93  addpd xmm6, xmm7
000074fc937d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000074fc937d5c9c  ptest xmm4, xmm4
000074fc937d5ca1  jnz 0x000074FC937D75B0
000074fc937d5ca7  vmovaps xmm9, [rsp+0x70]
000074fc937d5cad  vpermilpd xmm9, xmm9, 0x00
000074fc937d5cb3  vmovaps xmm4, [rsp+0x90]
000074fc937d5cbc  movaps xmm7, xmm4
000074fc937d5cbf  mulpd xmm7, xmm9
000074fc937d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000074fc937d5cc9  ptest xmm3, xmm3
000074fc937d5cce  jnz 0x000074FC937D76F1
000074fc937d5cd4  vmovaps xmm9, [rsp+0x50]
000074fc937d5cda  vpermilpd xmm9, xmm9, 0x00
000074fc937d5ce0  movaps xmm4, xmm15
000074fc937d5ce4  mulpd xmm4, xmm9
000074fc937d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc937d5cee  ptest xmm3, xmm3
000074fc937d5cf3  jnz 0x000074FC937D7832
000074fc937d5cf9  lea r14, [rax+0xE0]
000074fc937d5d00  movups xmm15, [r13+r14*1]
000074fc937d5d06  vmovaps xmm9, [rsp+0x70]
000074fc937d5d0c  vpermilpd xmm9, xmm9, 0x00
000074fc937d5d12  vmovaps [rsp+0x70], xmm1
000074fc937d5d18  vmovaps xmm1, [rsp+0x80]
000074fc937d5d21  vmovaps [rsp+0x80], xmm15
000074fc937d5d2a  movaps xmm3, xmm1
000074fc937d5d2d  mulpd xmm3, xmm9
000074fc937d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000074fc937d5d37  ptest xmm15, xmm15
000074fc937d5d3d  jnz 0x000074FC937D797E
000074fc937d5d43  vmovaps xmm1, [rsp+0xF0]
000074fc937d5d4c  vmovaps xmm15, [rsp+0xF0]
000074fc937d5d55  por xmm1, xmm15
000074fc937d5d5a  movaps [r15+0x300], xmm1
000074fc937d5d62  vmovaps xmm15, [rsp+0xE0]
000074fc937d5d6b  vmovaps xmm9, [rsp+0xE0]
000074fc937d5d74  por xmm15, xmm9
000074fc937d5d79  movaps [r15+0x190], xmm15
000074fc937d5d81  vmovaps xmm9, [rsp+0x50]
000074fc937d5d87  vpermilpd xmm9, xmm9, 0x00
000074fc937d5d8d  vmovaps [rsp+0x90], xmm1
000074fc937d5d96  vmovaps [rsp+0xE0], xmm15
000074fc937d5d9f  vmovaps xmm15, [rsp+0x80]
000074fc937d5da8  vmovaps [rsp+0x80], xmm14
000074fc937d5db1  movaps xmm1, xmm15
000074fc937d5db5  mulpd xmm1, xmm9
000074fc937d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc937d5dbf  ptest xmm14, xmm14
000074fc937d5dc5  jnz 0x000074FC937D7ABF
000074fc937d5dcb  lea r14, [rax+0x90]
000074fc937d5dd2  movups xmm15, [r13+r14*1]
000074fc937d5dd8  vmovaps xmm14, [rsp+0xD0]
000074fc937d5de1  vmovaps xmm9, [rsp+0xD0]
000074fc937d5dea  por xmm14, xmm9
000074fc937d5def  movaps [r15+0x1C0], xmm14
000074fc937d5df7  vmovaps xmm9, [rsp+0xC0]
000074fc937d5e00  vmovaps [rsp+0xD0], xmm1
000074fc937d5e09  vmovaps xmm1, [rsp+0xC0]
000074fc937d5e12  por xmm9, xmm1
000074fc937d5e17  movaps [r15+0x200], xmm9
000074fc937d5e1f  vmovaps [rsp+0xC0], xmm2
000074fc937d5e28  vmovaps xmm1, [rsp+0xC0]
000074fc937d5e31  por xmm2, xmm1
000074fc937d5e35  movaps [r15+0x2D0], xmm2
000074fc937d5e3d  vmovaps [rsp+0xC0], xmm8
000074fc937d5e46  vmovaps xmm1, [rsp+0xC0]
000074fc937d5e4f  por xmm8, xmm1
000074fc937d5e54  movaps [r15+0x2E0], xmm8
000074fc937d5e5c  vmovaps [rsp+0xC0], xmm15
000074fc937d5e65  movaps xmm1, xmm5
000074fc937d5e68  addpd xmm1, xmm7
000074fc937d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc937d5e71  ptest xmm15, xmm15
000074fc937d5e77  jnz 0x000074FC937D7C0B
000074fc937d5e7d  vmovaps xmm15, [rsp+0x50]
000074fc937d5e83  vpermilpd xmm15, xmm15, 0x00
000074fc937d5e89  vmovaps xmm5, [rsp+0xC0]
000074fc937d5e92  vmovaps [rsp+0xC0], xmm1
000074fc937d5e9b  movaps xmm7, xmm5
000074fc937d5e9e  mulpd xmm7, xmm15
000074fc937d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000074fc937d5ea8  ptest xmm1, xmm1
000074fc937d5ead  jnz 0x000074FC937D7D4B
000074fc937d5eb3  lea r14, [rax+0x80]
000074fc937d5eba  movups xmm1, [r13+r14*1]
000074fc937d5ec0  vmovaps xmm5, [rsp+0x70]
000074fc937d5ec6  vmovaps [rsp+0x70], xmm1
000074fc937d5ecc  movaps xmm15, xmm5
000074fc937d5ed0  addpd xmm15, xmm3
000074fc937d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937d5edb  ptest xmm1, xmm1
000074fc937d5ee0  jnz 0x000074FC937D7E96
000074fc937d5ee6  vmovaps xmm5, [rsp+0x80]
000074fc937d5eef  movaps xmm1, xmm5
000074fc937d5ef2  addpd xmm1, xmm4
000074fc937d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000074fc937d5efb  ptest xmm3, xmm3
000074fc937d5f00  jnz 0x000074FC937D7FD8
000074fc937d5f06  vmovaps [rsp+0x80], xmm10
000074fc937d5f0f  vmovaps xmm5, [rsp+0x80]
000074fc937d5f18  por xmm10, xmm5
000074fc937d5f1d  movaps [r15+0x2F0], xmm10
000074fc937d5f25  vmovaps xmm5, [rsp+0x50]
000074fc937d5f2b  vpermilpd xmm5, xmm5, 0x00
000074fc937d5f31  vmovaps xmm3, [rsp+0x70]
000074fc937d5f37  vmovaps [rsp+0x50], xmm1
000074fc937d5f3d  movaps xmm4, xmm3
000074fc937d5f40  mulpd xmm4, xmm5
000074fc937d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc937d5f49  ptest xmm1, xmm1
000074fc937d5f4e  jnz 0x000074FC937D8118
000074fc937d5f54  lea r14, [rax+0xD0]
000074fc937d5f5b  movups xmm1, [r13+r14*1]
000074fc937d5f61  vmovaps xmm3, [rsp+0xD0]
000074fc937d5f6a  vmovaps [rsp+0x70], xmm1
000074fc937d5f70  movaps xmm5, xmm6
000074fc937d5f73  addpd xmm5, xmm3
000074fc937d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000074fc937d5f7c  ptest xmm1, xmm1
000074fc937d5f81  jnz 0x000074FC937D8262
000074fc937d5f87  vmovaps xmm1, [rsp+0x60]
000074fc937d5f8d  vpermilpd xmm1, xmm1, 0x00
000074fc937d5f93  movaps xmm6, xmm9
000074fc937d5f97  mulpd xmm6, xmm1
000074fc937d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc937d5fa0  ptest xmm3, xmm3
000074fc937d5fa5  jnz 0x000074FC937D83A2
000074fc937d5fab  movaps [r15+0x260], xmm6
000074fc937d5fb3  vxorps xmm1, xmm1, xmm1
000074fc937d5fb7  vpbroadcastq xmm1, xmm1
000074fc937d5fbc  movaps [r15+0x1B0], xmm1
000074fc937d5fc4  vmovaps xmm1, [rsp+0x60]
000074fc937d5fca  vpermilpd xmm1, xmm1, 0x00
000074fc937d5fd0  vmovaps xmm3, [rsp+0x70]
000074fc937d5fd6  vmovaps [rsp+0x70], xmm15
000074fc937d5fdc  movaps xmm9, xmm3
000074fc937d5fe0  mulpd xmm9, xmm1
000074fc937d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc937d5feb  ptest xmm15, xmm15
000074fc937d5ff1  jnz 0x000074FC937D84E3
000074fc937d5ff7  lea r14, [rax+0xC0]
000074fc937d5ffe  movups xmm1, [r13+r14*1]
000074fc937d6004  vmovaps xmm3, [rsp+0xC0]
000074fc937d600d  vmovaps [rsp+0x80], xmm1
000074fc937d6016  movaps xmm15, xmm3
000074fc937d601a  addpd xmm15, xmm7
000074fc937d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937d6025  ptest xmm1, xmm1
000074fc937d602a  jnz 0x000074FC937D862F
000074fc937d6030  vmovaps [rsp+0xC0], xmm13
000074fc937d6039  vmovaps xmm1, [rsp+0xC0]
000074fc937d6042  por xmm13, xmm1
000074fc937d6047  movaps [r15+0x270], xmm13
000074fc937d604f  vmovaps xmm1, [rsp+0xB0]
000074fc937d6058  vmovaps xmm7, [rsp+0xB0]
000074fc937d6061  por xmm1, xmm7
000074fc937d6065  movaps [r15+0x1A0], xmm1
000074fc937d606d  vmovaps xmm1, [rsp+0x60]
000074fc937d6073  vpermilpd xmm1, xmm1, 0x00
000074fc937d6079  vmovaps [rsp+0xB0], xmm1
000074fc937d6082  vmovaps xmm1, [rsp+0x80]
000074fc937d608b  vmovaps [rsp+0x80], xmm15
000074fc937d6094  vmovaps xmm15, [rsp+0xB0]
000074fc937d609d  vmovaps [rsp+0xB0], xmm14
000074fc937d60a6  movaps xmm3, xmm1
000074fc937d60a9  mulpd xmm3, xmm15
000074fc937d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000074fc937d60b3  ptest xmm14, xmm14
000074fc937d60b9  jnz 0x000074FC937D8771
000074fc937d60bf  lea r14, [rax+0x20]
000074fc937d60c3  movups xmm1, [r13+r14*1]
000074fc937d60c9  movaps [r15+0x110], xmm1
000074fc937d60d1  vmovaps xmm14, [rsp+0x70]
000074fc937d60d7  vmovaps [rsp+0x70], xmm1
000074fc937d60dd  movaps xmm15, xmm14
000074fc937d60e1  addpd xmm15, xmm4
000074fc937d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937d60ec  ptest xmm1, xmm1
000074fc937d60f1  jnz 0x000074FC937D88BC
000074fc937d60f7  vmovaps xmm1, [rsp+0x60]
000074fc937d60fd  vpermilpd xmm1, xmm1, 0x00
000074fc937d6103  movaps xmm14, xmm2
000074fc937d6107  mulpd xmm14, xmm1
000074fc937d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000074fc937d6112  ptest xmm4, xmm4
000074fc937d6117  jnz 0x000074FC937D89FF
000074fc937d611d  vmovaps xmm4, [rsp+0x50]
000074fc937d6123  movaps xmm1, xmm4
000074fc937d6126  addpd xmm1, xmm9
000074fc937d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc937d6130  ptest xmm2, xmm2
000074fc937d6135  jnz 0x000074FC937D8B41
000074fc937d613b  vmovaps xmm9, [rsp+0x30]
000074fc937d6141  vpermilpd xmm9, xmm9, 0x00
000074fc937d6147  vmovaps xmm2, [rsp+0x70]
000074fc937d614d  vmovaps [rsp+0x50], xmm1
000074fc937d6153  movaps xmm4, xmm2
000074fc937d6156  mulpd xmm4, xmm9
000074fc937d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc937d6160  ptest xmm1, xmm1
000074fc937d6165  jnz 0x000074FC937D8C82
000074fc937d616b  vmovaps xmm1, [rsp+0x30]
000074fc937d6171  vpermilpd xmm1, xmm1, 0x00
000074fc937d6177  vmovaps xmm2, [rsp+0x90]
000074fc937d6180  vmovaps [rsp+0x60], xmm15
000074fc937d6186  movaps xmm9, xmm2
000074fc937d618a  mulpd xmm9, xmm1
000074fc937d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc937d6195  ptest xmm15, xmm15
000074fc937d619b  jnz 0x000074FC937D8DC3
000074fc937d61a1  vmovaps xmm15, [rsp+0x80]
000074fc937d61aa  movaps xmm1, xmm15
000074fc937d61ae  addpd xmm1, xmm6
000074fc937d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc937d61b7  ptest xmm2, xmm2
000074fc937d61bc  jnz 0x000074FC937D8F05
000074fc937d61c2  movaps xmm15, xmm5
000074fc937d61c6  addpd xmm15, xmm3
000074fc937d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000074fc937d61d1  ptest xmm6, xmm6
000074fc937d61d6  jnz 0x000074FC937D9046
000074fc937d61dc  vmovaps xmm6, [rsp+0x30]
000074fc937d61e2  vpermilpd xmm6, xmm6, 0x00
000074fc937d61e8  movaps xmm5, xmm8
000074fc937d61ec  mulpd xmm5, xmm6
000074fc937d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000074fc937d61f5  ptest xmm3, xmm3
000074fc937d61fa  jnz 0x000074FC937D9188
000074fc937d6200  vmovaps xmm8, [rsp+0x30]
000074fc937d6206  vpermilpd xmm8, xmm8, 0x00
000074fc937d620c  movaps xmm6, xmm10
000074fc937d6210  mulpd xmm6, xmm8
000074fc937d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc937d621a  ptest xmm3, xmm3
000074fc937d621f  jnz 0x000074FC937D92C9
000074fc937d6225  vmovaps xmm8, [rsp+0x60]
000074fc937d622b  movaps xmm10, xmm8
000074fc937d622f  addpd xmm10, xmm14
000074fc937d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000074fc937d623a  ptest xmm3, xmm3
000074fc937d623f  jnz 0x000074FC937D940B
000074fc937d6245  vmovaps xmm8, [rsp+0x50]
000074fc937d624b  movaps xmm14, xmm8
000074fc937d624f  addpd xmm14, xmm4
000074fc937d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000074fc937d625a  ptest xmm3, xmm3
000074fc937d625f  jnz 0x000074FC937D954F
000074fc937d6265  vmovaps xmm8, [rsp+0x40]
000074fc937d626b  vpermilpd xmm8, xmm8, 0x00
000074fc937d6271  movaps xmm4, xmm13
000074fc937d6275  mulpd xmm4, xmm8
000074fc937d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc937d627f  ptest xmm3, xmm3
000074fc937d6284  jnz 0x000074FC937D9692
000074fc937d628a  movaps xmm13, xmm15
000074fc937d628e  addpd xmm13, xmm9
000074fc937d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000074fc937d6299  ptest xmm8, xmm8
000074fc937d629f  jnz 0x000074FC937D97D4
000074fc937d62a5  movaps xmm15, xmm1
000074fc937d62a9  addpd xmm15, xmm5
000074fc937d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc937d62b4  ptest xmm9, xmm9
000074fc937d62ba  jnz 0x000074FC937D9918
000074fc937d62c0  vmovaps [rsp+0x30], xmm11
000074fc937d62c6  vmovaps xmm1, [rsp+0x30]
000074fc937d62cc  por xmm11, xmm1
000074fc937d62d1  movaps [r15+0x250], xmm11
000074fc937d62d9  vmovaps [rsp+0x30], xmm12
000074fc937d62df  vmovaps xmm1, [rsp+0x30]
000074fc937d62e5  por xmm12, xmm1
000074fc937d62ea  movaps [r15+0x2A0], xmm12
000074fc937d62f2  vmovaps xmm1, [rsp+0xA0]
000074fc937d62fb  vmovaps xmm11, [rsp+0xA0]
000074fc937d6304  por xmm1, xmm11
000074fc937d6309  movaps [r15+0x1D0], xmm1
000074fc937d6311  lea r14, [rax+0x40]
000074fc937d6315  movups xmm1, [r13+r14*1]
000074fc937d631b  movaps [r15+0x2C0], xmm1
000074fc937d6323  vmovaps xmm11, [rsp+0x40]
000074fc937d6329  vpermilpd xmm11, xmm11, 0x00
000074fc937d632f  vmovaps xmm8, [rsp+0xE0]
000074fc937d6338  movaps xmm9, xmm8
000074fc937d633c  mulpd xmm9, xmm11
000074fc937d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000074fc937d6347  ptest xmm5, xmm5
000074fc937d634c  jnz 0x000074FC937D9A64
000074fc937d6352  movaps xmm11, xmm10
000074fc937d6356  addpd xmm11, xmm6
000074fc937d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000074fc937d6361  ptest xmm8, xmm8
000074fc937d6367  jnz 0x000074FC937D9BA8
000074fc937d636d  movaps xmm10, xmm14
000074fc937d6371  addpd xmm10, xmm4
000074fc937d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000074fc937d637c  ptest xmm8, xmm8
000074fc937d6382  jnz 0x000074FC937D9CEB
000074fc937d6388  vmovaps xmm14, [rsp+0x40]
000074fc937d638e  vpermilpd xmm14, xmm14, 0x00
000074fc937d6394  movaps xmm8, xmm1
000074fc937d6398  mulpd xmm8, xmm14
000074fc937d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc937d63a3  ptest xmm6, xmm6
000074fc937d63a8  jnz 0x000074FC937D9E2E
000074fc937d63ae  movaps xmm1, [r15+0x2B0]
000074fc937d63b6  vmovaps xmm14, [rsp+0x40]
000074fc937d63bc  vpermilpd xmm14, xmm14, 0x00
000074fc937d63c2  movaps xmm6, xmm1
000074fc937d63c5  mulpd xmm6, xmm14
000074fc937d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc937d63cf  ptest xmm5, xmm5
000074fc937d63d4  jnz 0x000074FC937D9F71
000074fc937d63da  vmovaps xmm1, [rsp+0x10]
000074fc937d63e0  vpermilpd xmm1, xmm1, 0x00
000074fc937d63e6  movaps xmm14, xmm12
000074fc937d63ea  mulpd xmm14, xmm1
000074fc937d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000074fc937d63f5  ptest xmm5, xmm5
000074fc937d63fa  jnz 0x000074FC937DA0B2
000074fc937d6400  movaps xmm1, xmm13
000074fc937d6404  addpd xmm1, xmm9
000074fc937d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc937d640e  ptest xmm12, xmm12
000074fc937d6414  jnz 0x000074FC937DA1F5
000074fc937d641a  vmovaps xmm13, [rsp+0x10]
000074fc937d6420  vpermilpd xmm13, xmm13, 0x00
000074fc937d6426  movaps xmm12, xmm7
000074fc937d642a  mulpd xmm12, xmm13
000074fc937d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc937d6435  ptest xmm9, xmm9
000074fc937d643b  jnz 0x000074FC937DA337
000074fc937d6441  movaps xmm13, xmm15
000074fc937d6445  addpd xmm13, xmm8
000074fc937d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000074fc937d6450  ptest xmm9, xmm9
000074fc937d6456  jnz 0x000074FC937DA47A
000074fc937d645c  movaps xmm15, [r15+0x290]
000074fc937d6464  vmovaps xmm9, [rsp+0x10]
000074fc937d646a  vpermilpd xmm9, xmm9, 0x00
000074fc937d6470  movaps xmm8, xmm15
000074fc937d6474  mulpd xmm8, xmm9
000074fc937d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc937d647f  ptest xmm7, xmm7
000074fc937d6484  jnz 0x000074FC937DA5BE
000074fc937d648a  movaps xmm15, xmm11
000074fc937d648e  addpd xmm15, xmm6
000074fc937d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc937d6499  ptest xmm9, xmm9
000074fc937d649f  jnz 0x000074FC937DA702
000074fc937d64a5  movaps xmm11, [r15+0x1E0]
000074fc937d64ad  vmovaps xmm9, [rsp+0x10]
000074fc937d64b3  vpermilpd xmm9, xmm9, 0x00
000074fc937d64b9  movaps xmm7, xmm11
000074fc937d64bd  mulpd xmm7, xmm9
000074fc937d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc937d64c7  ptest xmm6, xmm6
000074fc937d64cc  jnz 0x000074FC937DA845
000074fc937d64d2  movaps xmm11, xmm10
000074fc937d64d6  addpd xmm11, xmm14
000074fc937d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000074fc937d64e1  ptest xmm9, xmm9
000074fc937d64e7  jnz 0x000074FC937DA987
000074fc937d64ed  lea r14, [rax+0x70]
000074fc937d64f1  movups xmm14, [r13+r14*1]
000074fc937d64f7  movaps [r15+0x240], xmm14
000074fc937d64ff  movaps xmm10, xmm1
000074fc937d6503  addpd xmm10, xmm12
000074fc937d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000074fc937d650e  ptest xmm9, xmm9
000074fc937d6514  jnz 0x000074FC937DAAD5
000074fc937d651a  movaps [r15+0x170], xmm10
000074fc937d6522  vmovaps xmm1, [rsp+0x20]
000074fc937d6528  vpermilpd xmm1, xmm1, 0x00
000074fc937d652e  movaps xmm12, xmm14
000074fc937d6532  mulpd xmm12, xmm1
000074fc937d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc937d653d  ptest xmm9, xmm9
000074fc937d6543  jnz 0x000074FC937DAC18
000074fc937d6549  vmovaps xmm1, [rsp+0x20]
000074fc937d654f  vpermilpd xmm1, xmm1, 0x00
000074fc937d6555  vmovaps xmm9, [rsp+0xB0]
000074fc937d655e  movaps xmm14, xmm9
000074fc937d6562  mulpd xmm14, xmm1
000074fc937d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc937d656d  ptest xmm6, xmm6
000074fc937d6572  jnz 0x000074FC937DAD5B
000074fc937d6578  movaps [r15+0x180], xmm14
000074fc937d6580  movaps xmm1, xmm13
000074fc937d6584  addpd xmm1, xmm8
000074fc937d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000074fc937d658e  ptest xmm9, xmm9
000074fc937d6594  jnz 0x000074FC937DAE9E
000074fc937d659a  movaps [r15+0x210], xmm1
000074fc937d65a2  movups xmm13, [r13+rax*1]
000074fc937d65a8  lea r14, [rax+0x10]
000074fc937d65ac  movups xmm9, [r13+r14*1]
000074fc937d65b2  movaps [r15+0x230], xmm9
000074fc937d65ba  movaps xmm8, xmm15
000074fc937d65be  addpd xmm8, xmm7
000074fc937d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc937d65c9  ptest xmm6, xmm6
000074fc937d65ce  jnz 0x000074FC937DAFF4
000074fc937d65d4  movaps [r15+0x130], xmm8
000074fc937d65dc  vmovaps xmm15, [rsp+0x20]
000074fc937d65e2  vpermilpd xmm15, xmm15, 0x00
000074fc937d65e8  movaps xmm7, xmm9
000074fc937d65ec  mulpd xmm7, xmm15
000074fc937d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc937d65f6  ptest xmm6, xmm6
000074fc937d65fb  jnz 0x000074FC937DB137
000074fc937d6601  movaps [r15+0x220], xmm7
000074fc937d6609  vmovaps xmm15, [rsp+0x20]
000074fc937d660f  vpermilpd xmm15, xmm15, 0x00
000074fc937d6615  movaps xmm9, xmm13
000074fc937d6619  mulpd xmm9, xmm15
000074fc937d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc937d6624  ptest xmm6, xmm6
000074fc937d6629  jnz 0x000074FC937DB279
000074fc937d662f  movaps xmm15, xmm11
000074fc937d6633  addpd xmm15, xmm12
000074fc937d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc937d663e  ptest xmm13, xmm13
000074fc937d6644  jnz 0x000074FC937DB3BD
000074fc937d664a  movaps [r15+0x140], xmm15
000074fc937d6652  movaps xmm13, xmm10
000074fc937d6656  addpd xmm13, xmm14
000074fc937d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc937d6661  ptest xmm12, xmm12
000074fc937d6667  jnz 0x000074FC937DB501
000074fc937d666d  movaps [r15+0x150], xmm13
000074fc937d6675  movaps xmm14, xmm1
000074fc937d6679  addpd xmm14, xmm7
000074fc937d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000074fc937d6684  ptest xmm12, xmm12
000074fc937d668a  jnz 0x000074FC937DB645
000074fc937d6690  movaps [r15+0x160], xmm14
000074fc937d6698  movaps xmm1, xmm8
000074fc937d669c  addpd xmm1, xmm9
000074fc937d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc937d66a6  ptest xmm12, xmm12
000074fc937d66ac  jnz 0x000074FC937DB787
000074fc937d66b2  movaps [r15+0x120], xmm1
000074fc937d66ba  movups [r13+r11*1], xmm15
000074fc937d66c0  lea rax, [r11+0x10]
000074fc937d66c4  movups [r13+rax*1], xmm13
000074fc937d66ca  lea rax, [r11+0x20]
000074fc937d66ce  movups [r13+rax*1], xmm14
000074fc937d66d4  lea rax, [r11+0x30]
000074fc937d66d8  movups [r13+rax*1], xmm1
000074fc937d66de  mov eax, [r15+0x108]
000074fc937d66e5  sahf
000074fc937d66e6  jnz 0x000074FC937D6718
000074fc937d66e8  cmp dword ptr [r15+0x318], 0x00
000074fc937d66f0  jz 0x000074FC937DB900
000074fc937d66f6  nop [rax+rax*1], ax
000074fc937d66ff  nop [rax+rax*1], eax
000074fc937d6707  mov eax, 0x410444
000074fc937d670c  mov [r15+0x100], rax
000074fc937d6713  jmp 0x000074FC935FE110
000074fc937d6718  cmp dword ptr [r15+0x318], 0x00
000074fc937d6720  jz 0x000074FC937D57E0
000074fc937d6726  nop [rax+rax*1], ax
000074fc937d672f  nop [rax+rax*1], eax
000074fc937d6737  mov eax, 0x410278
000074fc937d673c  mov [r15+0x100], rax
000074fc937d6743  jmp 0x000074FC935FE110
000074fc937d6748  int3
000074fc937d6749  call 0x000074FC9360A4B0
000074fc937d674e  jmp 0x000074FC937D5828
000074fc937d6753  call 0x000074FC93609240
000074fc937d6758  jmp 0x000074FC937D5832
000074fc937d675d  call 0x000074FC9360A4B0
000074fc937d6762  jmp 0x000074FC937D588F
000074fc937d6767  call 0x000074FC93609240
000074fc937d676c  jmp 0x000074FC937D5899
000074fc937d6771  call 0x000074FC9360A4B0
000074fc937d6776  jmp 0x000074FC937D58DD
000074fc937d677b  call 0x000074FC93609240
000074fc937d6780  jmp 0x000074FC937D58E7
000074fc937d6785  call 0x000074FC936B47C0
000074fc937d678a  jmp 0x000074FC937D5926
000074fc937d678f  call 0x000074FC9360B720
000074fc937d6794  jmp 0x000074FC937D593A
000074fc937d6799  call 0x000074FC936BFC30
000074fc937d679e  jmp 0x000074FC937D5958
000074fc937d67a3  call 0x000074FC936BE9C0
000074fc937d67a8  jmp 0x000074FC937D5962
000074fc937d67ad  call 0x000074FC936BD750
000074fc937d67b2  jmp 0x000074FC937D596C
000074fc937d67b7  sub rsp, 0x08
000074fc937d67bb  push rax
000074fc937d67bc  push rcx
000074fc937d67bd  push rdx
000074fc937d67be  push rdi
000074fc937d67bf  push rsi
000074fc937d67c0  push r8
000074fc937d67c2  push r9
000074fc937d67c4  push r10
000074fc937d67c6  push r11
000074fc937d67c8  sub rsp, 0xF0
000074fc937d67cf  vmovaps [rsp], xmm0
000074fc937d67d4  vmovaps [rsp+0x10], xmm1
000074fc937d67da  vmovaps [rsp+0x20], xmm2
000074fc937d67e0  vmovaps [rsp+0x30], xmm3
000074fc937d67e6  vmovaps [rsp+0x40], xmm4
000074fc937d67ec  vmovaps [rsp+0x50], xmm5
000074fc937d67f2  vmovaps [rsp+0x60], xmm6
000074fc937d67f8  vmovaps [rsp+0x70], xmm7
000074fc937d67fe  vmovaps [rsp+0x80], xmm9
000074fc937d6807  vmovaps [rsp+0x90], xmm10
000074fc937d6810  vmovaps [rsp+0xA0], xmm11
000074fc937d6819  vmovaps [rsp+0xB0], xmm12
000074fc937d6822  vmovaps [rsp+0xC0], xmm13
000074fc937d682b  vmovaps [rsp+0xD0], xmm14
000074fc937d6834  vmovaps [rsp+0xE0], xmm15
000074fc937d683d  sub rsp, 0x30
000074fc937d6841  movaps [rsp], xmm8
000074fc937d6846  movaps [rsp+0x10], xmm12
000074fc937d684c  movaps [rsp+0x20], xmm15
000074fc937d6852  lea rdi, [rsp]
000074fc937d6856  mov esi, 0x00
000074fc937d685b  mov rax, 0x5D72CBC20530
000074fc937d6865  call rax
000074fc937d6867  movaps xmm8, [rsp]
000074fc937d686c  add rsp, 0x30
000074fc937d6870  vmovaps xmm0, [rsp]
000074fc937d6875  vmovaps xmm1, [rsp+0x10]
000074fc937d687b  vmovaps xmm2, [rsp+0x20]
000074fc937d6881  vmovaps xmm3, [rsp+0x30]
000074fc937d6887  vmovaps xmm4, [rsp+0x40]
000074fc937d688d  vmovaps xmm5, [rsp+0x50]
000074fc937d6893  vmovaps xmm6, [rsp+0x60]
000074fc937d6899  vmovaps xmm7, [rsp+0x70]
000074fc937d689f  vmovaps xmm9, [rsp+0x80]
000074fc937d68a8  vmovaps xmm10, [rsp+0x90]
000074fc937d68b1  vmovaps xmm11, [rsp+0xA0]
000074fc937d68ba  vmovaps xmm12, [rsp+0xB0]
000074fc937d68c3  vmovaps xmm13, [rsp+0xC0]
000074fc937d68cc  vmovaps xmm14, [rsp+0xD0]
000074fc937d68d5  vmovaps xmm15, [rsp+0xE0]
000074fc937d68de  add rsp, 0xF0
000074fc937d68e5  pop r11
000074fc937d68e7  pop r10
000074fc937d68e9  pop r9
000074fc937d68eb  pop r8
000074fc937d68ed  pop rsi
000074fc937d68ee  pop rdi
000074fc937d68ef  pop rdx
000074fc937d68f0  pop rcx
000074fc937d68f1  pop rax
000074fc937d68f2  add rsp, 0x08
000074fc937d68f6  jmp 0x000074FC937D599A
000074fc937d68fb  sub rsp, 0x08
000074fc937d68ff  push rax
000074fc937d6900  push rcx
000074fc937d6901  push rdx
000074fc937d6902  push rdi
000074fc937d6903  push rsi
000074fc937d6904  push r8
000074fc937d6906  push r9
000074fc937d6908  push r10
000074fc937d690a  push r11
000074fc937d690c  sub rsp, 0xF0
000074fc937d6913  vmovaps [rsp], xmm0
000074fc937d6918  vmovaps [rsp+0x10], xmm1
000074fc937d691e  vmovaps [rsp+0x20], xmm2
000074fc937d6924  vmovaps [rsp+0x30], xmm3
000074fc937d692a  vmovaps [rsp+0x40], xmm4
000074fc937d6930  vmovaps [rsp+0x50], xmm5
000074fc937d6936  vmovaps [rsp+0x60], xmm6
000074fc937d693c  vmovaps [rsp+0x70], xmm8
000074fc937d6942  vmovaps [rsp+0x80], xmm9
000074fc937d694b  vmovaps [rsp+0x90], xmm10
000074fc937d6954  vmovaps [rsp+0xA0], xmm11
000074fc937d695d  vmovaps [rsp+0xB0], xmm12
000074fc937d6966  vmovaps [rsp+0xC0], xmm13
000074fc937d696f  vmovaps [rsp+0xD0], xmm14
000074fc937d6978  vmovaps [rsp+0xE0], xmm15
000074fc937d6981  sub rsp, 0x30
000074fc937d6985  movaps [rsp], xmm7
000074fc937d6989  movaps [rsp+0x10], xmm9
000074fc937d698f  movaps [rsp+0x20], xmm15
000074fc937d6995  lea rdi, [rsp]
000074fc937d6999  mov esi, 0x00
000074fc937d699e  mov rax, 0x5D72CBC20530
000074fc937d69a8  call rax
000074fc937d69aa  movaps xmm7, [rsp]
000074fc937d69ae  add rsp, 0x30
000074fc937d69b2  vmovaps xmm0, [rsp]
000074fc937d69b7  vmovaps xmm1, [rsp+0x10]
000074fc937d69bd  vmovaps xmm2, [rsp+0x20]
000074fc937d69c3  vmovaps xmm3, [rsp+0x30]
000074fc937d69c9  vmovaps xmm4, [rsp+0x40]
000074fc937d69cf  vmovaps xmm5, [rsp+0x50]
000074fc937d69d5  vmovaps xmm6, [rsp+0x60]
000074fc937d69db  vmovaps xmm8, [rsp+0x70]
000074fc937d69e1  vmovaps xmm9, [rsp+0x80]
000074fc937d69ea  vmovaps xmm10, [rsp+0x90]
000074fc937d69f3  vmovaps xmm11, [rsp+0xA0]
000074fc937d69fc  vmovaps xmm12, [rsp+0xB0]
000074fc937d6a05  vmovaps xmm13, [rsp+0xC0]
000074fc937d6a0e  vmovaps xmm14, [rsp+0xD0]
000074fc937d6a17  vmovaps xmm15, [rsp+0xE0]
000074fc937d6a20  add rsp, 0xF0
000074fc937d6a27  pop r11
000074fc937d6a29  pop r10
000074fc937d6a2b  pop r9
000074fc937d6a2d  pop r8
000074fc937d6a2f  pop rsi
000074fc937d6a30  pop rdi
000074fc937d6a31  pop rdx
000074fc937d6a32  pop rcx
000074fc937d6a33  pop rax
000074fc937d6a34  add rsp, 0x08
000074fc937d6a38  jmp 0x000074FC937D59C8
000074fc937d6a3d  sub rsp, 0x08
000074fc937d6a41  push rax
000074fc937d6a42  push rcx
000074fc937d6a43  push rdx
000074fc937d6a44  push rdi
000074fc937d6a45  push rsi
000074fc937d6a46  push r8
000074fc937d6a48  push r9
000074fc937d6a4a  push r10
000074fc937d6a4c  push r11
000074fc937d6a4e  sub rsp, 0xF0
000074fc937d6a55  vmovaps [rsp], xmm0
000074fc937d6a5a  vmovaps [rsp+0x10], xmm1
000074fc937d6a60  vmovaps [rsp+0x20], xmm2
000074fc937d6a66  vmovaps [rsp+0x30], xmm3
000074fc937d6a6c  vmovaps [rsp+0x40], xmm4
000074fc937d6a72  vmovaps [rsp+0x50], xmm5
000074fc937d6a78  vmovaps [rsp+0x60], xmm6
000074fc937d6a7e  vmovaps [rsp+0x70], xmm7
000074fc937d6a84  vmovaps [rsp+0x80], xmm8
000074fc937d6a8d  vmovaps [rsp+0x90], xmm10
000074fc937d6a96  vmovaps [rsp+0xA0], xmm11
000074fc937d6a9f  vmovaps [rsp+0xB0], xmm12
000074fc937d6aa8  vmovaps [rsp+0xC0], xmm13
000074fc937d6ab1  vmovaps [rsp+0xD0], xmm14
000074fc937d6aba  vmovaps [rsp+0xE0], xmm15
000074fc937d6ac3  sub rsp, 0x30
000074fc937d6ac7  movaps [rsp], xmm9
000074fc937d6acc  movaps [rsp+0x10], xmm12
000074fc937d6ad2  movaps [rsp+0x20], xmm10
000074fc937d6ad8  lea rdi, [rsp]
000074fc937d6adc  mov esi, 0x00
000074fc937d6ae1  mov rax, 0x5D72CBC20530
000074fc937d6aeb  call rax
000074fc937d6aed  movaps xmm9, [rsp]
000074fc937d6af2  add rsp, 0x30
000074fc937d6af6  vmovaps xmm0, [rsp]
000074fc937d6afb  vmovaps xmm1, [rsp+0x10]
000074fc937d6b01  vmovaps xmm2, [rsp+0x20]
000074fc937d6b07  vmovaps xmm3, [rsp+0x30]
000074fc937d6b0d  vmovaps xmm4, [rsp+0x40]
000074fc937d6b13  vmovaps xmm5, [rsp+0x50]
000074fc937d6b19  vmovaps xmm6, [rsp+0x60]
000074fc937d6b1f  vmovaps xmm7, [rsp+0x70]
000074fc937d6b25  vmovaps xmm8, [rsp+0x80]
000074fc937d6b2e  vmovaps xmm10, [rsp+0x90]
000074fc937d6b37  vmovaps xmm11, [rsp+0xA0]
000074fc937d6b40  vmovaps xmm12, [rsp+0xB0]
000074fc937d6b49  vmovaps xmm13, [rsp+0xC0]
000074fc937d6b52  vmovaps xmm14, [rsp+0xD0]
000074fc937d6b5b  vmovaps xmm15, [rsp+0xE0]
000074fc937d6b64  add rsp, 0xF0
000074fc937d6b6b  pop r11
000074fc937d6b6d  pop r10
000074fc937d6b6f  pop r9
000074fc937d6b71  pop r8
000074fc937d6b73  pop rsi
000074fc937d6b74  pop rdi
000074fc937d6b75  pop rdx
000074fc937d6b76  pop rcx
000074fc937d6b77  pop rax
000074fc937d6b78  add rsp, 0x08
000074fc937d6b7c  jmp 0x000074FC937D59EC
000074fc937d6b81  sub rsp, 0x08
000074fc937d6b85  push rax
000074fc937d6b86  push rcx
000074fc937d6b87  push rdx
000074fc937d6b88  push rdi
000074fc937d6b89  push rsi
000074fc937d6b8a  push r8
000074fc937d6b8c  push r9
000074fc937d6b8e  push r10
000074fc937d6b90  push r11
000074fc937d6b92  sub rsp, 0xF0
000074fc937d6b99  vmovaps [rsp], xmm0
000074fc937d6b9e  vmovaps [rsp+0x10], xmm1
000074fc937d6ba4  vmovaps [rsp+0x20], xmm2
000074fc937d6baa  vmovaps [rsp+0x30], xmm3
000074fc937d6bb0  vmovaps [rsp+0x40], xmm4
000074fc937d6bb6  vmovaps [rsp+0x50], xmm5
000074fc937d6bbc  vmovaps [rsp+0x60], xmm6
000074fc937d6bc2  vmovaps [rsp+0x70], xmm7
000074fc937d6bc8  vmovaps [rsp+0x80], xmm8
000074fc937d6bd1  vmovaps [rsp+0x90], xmm9
000074fc937d6bda  vmovaps [rsp+0xA0], xmm11
000074fc937d6be3  vmovaps [rsp+0xB0], xmm12
000074fc937d6bec  vmovaps [rsp+0xC0], xmm13
000074fc937d6bf5  vmovaps [rsp+0xD0], xmm14
000074fc937d6bfe  vmovaps [rsp+0xE0], xmm15
000074fc937d6c07  sub rsp, 0x30
000074fc937d6c0b  movaps [rsp], xmm10
000074fc937d6c10  movaps [rsp+0x10], xmm12
000074fc937d6c16  movaps [rsp+0x20], xmm11
000074fc937d6c1c  lea rdi, [rsp]
000074fc937d6c20  mov esi, 0x00
000074fc937d6c25  mov rax, 0x5D72CBC20530
000074fc937d6c2f  call rax
000074fc937d6c31  movaps xmm10, [rsp]
000074fc937d6c36  add rsp, 0x30
000074fc937d6c3a  vmovaps xmm0, [rsp]
000074fc937d6c3f  vmovaps xmm1, [rsp+0x10]
000074fc937d6c45  vmovaps xmm2, [rsp+0x20]
000074fc937d6c4b  vmovaps xmm3, [rsp+0x30]
000074fc937d6c51  vmovaps xmm4, [rsp+0x40]
000074fc937d6c57  vmovaps xmm5, [rsp+0x50]
000074fc937d6c5d  vmovaps xmm6, [rsp+0x60]
000074fc937d6c63  vmovaps xmm7, [rsp+0x70]
000074fc937d6c69  vmovaps xmm8, [rsp+0x80]
000074fc937d6c72  vmovaps xmm9, [rsp+0x90]
000074fc937d6c7b  vmovaps xmm11, [rsp+0xA0]
000074fc937d6c84  vmovaps xmm12, [rsp+0xB0]
000074fc937d6c8d  vmovaps xmm13, [rsp+0xC0]
000074fc937d6c96  vmovaps xmm14, [rsp+0xD0]
000074fc937d6c9f  vmovaps xmm15, [rsp+0xE0]
000074fc937d6ca8  add rsp, 0xF0
000074fc937d6caf  pop r11
000074fc937d6cb1  pop r10
000074fc937d6cb3  pop r9
000074fc937d6cb5  pop r8
000074fc937d6cb7  pop rsi
000074fc937d6cb8  pop rdi
000074fc937d6cb9  pop rdx
000074fc937d6cba  pop rcx
000074fc937d6cbb  pop rax
000074fc937d6cbc  add rsp, 0x08
000074fc937d6cc0  jmp 0x000074FC937D5A06
000074fc937d6cc5  sub rsp, 0x08
000074fc937d6cc9  push rax
000074fc937d6cca  push rcx
000074fc937d6ccb  push rdx
000074fc937d6ccc  push rdi
000074fc937d6ccd  push rsi
000074fc937d6cce  push r8
000074fc937d6cd0  push r9
000074fc937d6cd2  push r10
000074fc937d6cd4  push r11
000074fc937d6cd6  sub rsp, 0xF0
000074fc937d6cdd  vmovaps [rsp], xmm0
000074fc937d6ce2  vmovaps [rsp+0x10], xmm1
000074fc937d6ce8  vmovaps [rsp+0x20], xmm2
000074fc937d6cee  vmovaps [rsp+0x30], xmm3
000074fc937d6cf4  vmovaps [rsp+0x40], xmm4
000074fc937d6cfa  vmovaps [rsp+0x50], xmm5
000074fc937d6d00  vmovaps [rsp+0x60], xmm7
000074fc937d6d06  vmovaps [rsp+0x70], xmm8
000074fc937d6d0c  vmovaps [rsp+0x80], xmm9
000074fc937d6d15  vmovaps [rsp+0x90], xmm10
000074fc937d6d1e  vmovaps [rsp+0xA0], xmm11
000074fc937d6d27  vmovaps [rsp+0xB0], xmm12
000074fc937d6d30  vmovaps [rsp+0xC0], xmm13
000074fc937d6d39  vmovaps [rsp+0xD0], xmm14
000074fc937d6d42  vmovaps [rsp+0xE0], xmm15
000074fc937d6d4b  sub rsp, 0x30
000074fc937d6d4f  movaps [rsp], xmm6
000074fc937d6d53  movaps [rsp+0x10], xmm12
000074fc937d6d59  movaps [rsp+0x20], xmm11
000074fc937d6d5f  lea rdi, [rsp]
000074fc937d6d63  mov esi, 0x00
000074fc937d6d68  mov rax, 0x5D72CBC20530
000074fc937d6d72  call rax
000074fc937d6d74  movaps xmm6, [rsp]
000074fc937d6d78  add rsp, 0x30
000074fc937d6d7c  vmovaps xmm0, [rsp]
000074fc937d6d81  vmovaps xmm1, [rsp+0x10]
000074fc937d6d87  vmovaps xmm2, [rsp+0x20]
000074fc937d6d8d  vmovaps xmm3, [rsp+0x30]
000074fc937d6d93  vmovaps xmm4, [rsp+0x40]
000074fc937d6d99  vmovaps xmm5, [rsp+0x50]
000074fc937d6d9f  vmovaps xmm7, [rsp+0x60]
000074fc937d6da5  vmovaps xmm8, [rsp+0x70]
000074fc937d6dab  vmovaps xmm9, [rsp+0x80]
000074fc937d6db4  vmovaps xmm10, [rsp+0x90]
000074fc937d6dbd  vmovaps xmm11, [rsp+0xA0]
000074fc937d6dc6  vmovaps xmm12, [rsp+0xB0]
000074fc937d6dcf  vmovaps xmm13, [rsp+0xC0]
000074fc937d6dd8  vmovaps xmm14, [rsp+0xD0]
000074fc937d6de1  vmovaps xmm15, [rsp+0xE0]
000074fc937d6dea  add rsp, 0xF0
000074fc937d6df1  pop r11
000074fc937d6df3  pop r10
000074fc937d6df5  pop r9
000074fc937d6df7  pop r8
000074fc937d6df9  pop rsi
000074fc937d6dfa  pop rdi
000074fc937d6dfb  pop rdx
000074fc937d6dfc  pop rcx
000074fc937d6dfd  pop rax
000074fc937d6dfe  add rsp, 0x08
000074fc937d6e02  jmp 0x000074FC937D5A27
000074fc937d6e07  sub rsp, 0x08
000074fc937d6e0b  push rax
000074fc937d6e0c  push rcx
000074fc937d6e0d  push rdx
000074fc937d6e0e  push rdi
000074fc937d6e0f  push rsi
000074fc937d6e10  push r8
000074fc937d6e12  push r9
000074fc937d6e14  push r10
000074fc937d6e16  push r11
000074fc937d6e18  sub rsp, 0xF0
000074fc937d6e1f  vmovaps [rsp], xmm0
000074fc937d6e24  vmovaps [rsp+0x10], xmm1
000074fc937d6e2a  vmovaps [rsp+0x20], xmm2
000074fc937d6e30  vmovaps [rsp+0x30], xmm4
000074fc937d6e36  vmovaps [rsp+0x40], xmm5
000074fc937d6e3c  vmovaps [rsp+0x50], xmm6
000074fc937d6e42  vmovaps [rsp+0x60], xmm7
000074fc937d6e48  vmovaps [rsp+0x70], xmm8
000074fc937d6e4e  vmovaps [rsp+0x80], xmm9
000074fc937d6e57  vmovaps [rsp+0x90], xmm10
000074fc937d6e60  vmovaps [rsp+0xA0], xmm11
000074fc937d6e69  vmovaps [rsp+0xB0], xmm12
000074fc937d6e72  vmovaps [rsp+0xC0], xmm13
000074fc937d6e7b  vmovaps [rsp+0xD0], xmm14
000074fc937d6e84  vmovaps [rsp+0xE0], xmm15
000074fc937d6e8d  sub rsp, 0x30
000074fc937d6e91  movaps [rsp], xmm3
000074fc937d6e95  movaps [rsp+0x10], xmm5
000074fc937d6e9a  movaps [rsp+0x20], xmm4
000074fc937d6e9f  lea rdi, [rsp]
000074fc937d6ea3  mov esi, 0x00
000074fc937d6ea8  mov rax, 0x5D72CBC20530
000074fc937d6eb2  call rax
000074fc937d6eb4  movaps xmm3, [rsp]
000074fc937d6eb8  add rsp, 0x30
000074fc937d6ebc  vmovaps xmm0, [rsp]
000074fc937d6ec1  vmovaps xmm1, [rsp+0x10]
000074fc937d6ec7  vmovaps xmm2, [rsp+0x20]
000074fc937d6ecd  vmovaps xmm4, [rsp+0x30]
000074fc937d6ed3  vmovaps xmm5, [rsp+0x40]
000074fc937d6ed9  vmovaps xmm6, [rsp+0x50]
000074fc937d6edf  vmovaps xmm7, [rsp+0x60]
000074fc937d6ee5  vmovaps xmm8, [rsp+0x70]
000074fc937d6eeb  vmovaps xmm9, [rsp+0x80]
000074fc937d6ef4  vmovaps xmm10, [rsp+0x90]
000074fc937d6efd  vmovaps xmm11, [rsp+0xA0]
000074fc937d6f06  vmovaps xmm12, [rsp+0xB0]
000074fc937d6f0f  vmovaps xmm13, [rsp+0xC0]
000074fc937d6f18  vmovaps xmm14, [rsp+0xD0]
000074fc937d6f21  vmovaps xmm15, [rsp+0xE0]
000074fc937d6f2a  add rsp, 0xF0
000074fc937d6f31  pop r11
000074fc937d6f33  pop r10
000074fc937d6f35  pop r9
000074fc937d6f37  pop r8
000074fc937d6f39  pop rsi
000074fc937d6f3a  pop rdi
000074fc937d6f3b  pop rdx
000074fc937d6f3c  pop rcx
000074fc937d6f3d  pop rax
000074fc937d6f3e  add rsp, 0x08
000074fc937d6f42  jmp 0x000074FC937D5A88
000074fc937d6f47  sub rsp, 0x08
000074fc937d6f4b  push rax
000074fc937d6f4c  push rcx
000074fc937d6f4d  push rdx
000074fc937d6f4e  push rdi
000074fc937d6f4f  push rsi
000074fc937d6f50  push r8
000074fc937d6f52  push r9
000074fc937d6f54  push r10
000074fc937d6f56  push r11
000074fc937d6f58  sub rsp, 0xF0
000074fc937d6f5f  vmovaps [rsp], xmm0
000074fc937d6f64  vmovaps [rsp+0x10], xmm1
000074fc937d6f6a  vmovaps [rsp+0x20], xmm2
000074fc937d6f70  vmovaps [rsp+0x30], xmm3
000074fc937d6f76  vmovaps [rsp+0x40], xmm4
000074fc937d6f7c  vmovaps [rsp+0x50], xmm6
000074fc937d6f82  vmovaps [rsp+0x60], xmm7
000074fc937d6f88  vmovaps [rsp+0x70], xmm8
000074fc937d6f8e  vmovaps [rsp+0x80], xmm9
000074fc937d6f97  vmovaps [rsp+0x90], xmm10
000074fc937d6fa0  vmovaps [rsp+0xA0], xmm11
000074fc937d6fa9  vmovaps [rsp+0xB0], xmm12
000074fc937d6fb2  vmovaps [rsp+0xC0], xmm13
000074fc937d6fbb  vmovaps [rsp+0xD0], xmm14
000074fc937d6fc4  vmovaps [rsp+0xE0], xmm15
000074fc937d6fcd  sub rsp, 0x30
000074fc937d6fd1  movaps [rsp], xmm5
000074fc937d6fd5  movaps [rsp+0x10], xmm8
000074fc937d6fdb  movaps [rsp+0x20], xmm15
000074fc937d6fe1  lea rdi, [rsp]
000074fc937d6fe5  mov esi, 0x00
000074fc937d6fea  mov rax, 0x5D72CBC20530
000074fc937d6ff4  call rax
000074fc937d6ff6  movaps xmm5, [rsp]
000074fc937d6ffa  add rsp, 0x30
000074fc937d6ffe  vmovaps xmm0, [rsp]
000074fc937d7003  vmovaps xmm1, [rsp+0x10]
000074fc937d7009  vmovaps xmm2, [rsp+0x20]
000074fc937d700f  vmovaps xmm3, [rsp+0x30]
000074fc937d7015  vmovaps xmm4, [rsp+0x40]
000074fc937d701b  vmovaps xmm6, [rsp+0x50]
000074fc937d7021  vmovaps xmm7, [rsp+0x60]
000074fc937d7027  vmovaps xmm8, [rsp+0x70]
000074fc937d702d  vmovaps xmm9, [rsp+0x80]
000074fc937d7036  vmovaps xmm10, [rsp+0x90]
000074fc937d703f  vmovaps xmm11, [rsp+0xA0]
000074fc937d7048  vmovaps xmm12, [rsp+0xB0]
000074fc937d7051  vmovaps xmm13, [rsp+0xC0]
000074fc937d705a  vmovaps xmm14, [rsp+0xD0]
000074fc937d7063  vmovaps xmm15, [rsp+0xE0]
000074fc937d706c  add rsp, 0xF0
000074fc937d7073  pop r11
000074fc937d7075  pop r10
000074fc937d7077  pop r9
000074fc937d7079  pop r8
000074fc937d707b  pop rsi
000074fc937d707c  pop rdi
000074fc937d707d  pop rdx
000074fc937d707e  pop rcx
000074fc937d707f  pop rax
000074fc937d7080  add rsp, 0x08
000074fc937d7084  jmp 0x000074FC937D5AC0
000074fc937d7089  sub rsp, 0x08
000074fc937d708d  push rax
000074fc937d708e  push rcx
000074fc937d708f  push rdx
000074fc937d7090  push rdi
000074fc937d7091  push rsi
000074fc937d7092  push r8
000074fc937d7094  push r9
000074fc937d7096  push r10
000074fc937d7098  push r11
000074fc937d709a  sub rsp, 0xF0
000074fc937d70a1  vmovaps [rsp], xmm0
000074fc937d70a6  vmovaps [rsp+0x10], xmm1
000074fc937d70ac  vmovaps [rsp+0x20], xmm2
000074fc937d70b2  vmovaps [rsp+0x30], xmm3
000074fc937d70b8  vmovaps [rsp+0x40], xmm5
000074fc937d70be  vmovaps [rsp+0x50], xmm6
000074fc937d70c4  vmovaps [rsp+0x60], xmm7
000074fc937d70ca  vmovaps [rsp+0x70], xmm8
000074fc937d70d0  vmovaps [rsp+0x80], xmm9
000074fc937d70d9  vmovaps [rsp+0x90], xmm10
000074fc937d70e2  vmovaps [rsp+0xA0], xmm11
000074fc937d70eb  vmovaps [rsp+0xB0], xmm12
000074fc937d70f4  vmovaps [rsp+0xC0], xmm13
000074fc937d70fd  vmovaps [rsp+0xD0], xmm14
000074fc937d7106  vmovaps [rsp+0xE0], xmm15
000074fc937d710f  sub rsp, 0x30
000074fc937d7113  movaps [rsp], xmm4
000074fc937d7117  movaps [rsp+0x10], xmm9
000074fc937d711d  movaps [rsp+0x20], xmm8
000074fc937d7123  lea rdi, [rsp]
000074fc937d7127  mov esi, 0x00
000074fc937d712c  mov rax, 0x5D72CBC20530
000074fc937d7136  call rax
000074fc937d7138  movaps xmm4, [rsp]
000074fc937d713c  add rsp, 0x30
000074fc937d7140  vmovaps xmm0, [rsp]
000074fc937d7145  vmovaps xmm1, [rsp+0x10]
000074fc937d714b  vmovaps xmm2, [rsp+0x20]
000074fc937d7151  vmovaps xmm3, [rsp+0x30]
000074fc937d7157  vmovaps xmm5, [rsp+0x40]
000074fc937d715d  vmovaps xmm6, [rsp+0x50]
000074fc937d7163  vmovaps xmm7, [rsp+0x60]
000074fc937d7169  vmovaps xmm8, [rsp+0x70]
000074fc937d716f  vmovaps xmm9, [rsp+0x80]
000074fc937d7178  vmovaps xmm10, [rsp+0x90]
000074fc937d7181  vmovaps xmm11, [rsp+0xA0]
000074fc937d718a  vmovaps xmm12, [rsp+0xB0]
000074fc937d7193  vmovaps xmm13, [rsp+0xC0]
000074fc937d719c  vmovaps xmm14, [rsp+0xD0]
000074fc937d71a5  vmovaps xmm15, [rsp+0xE0]
000074fc937d71ae  add rsp, 0xF0
000074fc937d71b5  pop r11
000074fc937d71b7  pop r10
000074fc937d71b9  pop r9
000074fc937d71bb  pop r8
000074fc937d71bd  pop rsi
000074fc937d71be  pop rdi
000074fc937d71bf  pop rdx
000074fc937d71c0  pop rcx
000074fc937d71c1  pop rax
000074fc937d71c2  add rsp, 0x08
000074fc937d71c6  jmp 0x000074FC937D5AE1
000074fc937d71cb  sub rsp, 0x08
000074fc937d71cf  push rax
000074fc937d71d0  push rcx
000074fc937d71d1  push rdx
000074fc937d71d2  push rdi
000074fc937d71d3  push rsi
000074fc937d71d4  push r8
000074fc937d71d6  push r9
000074fc937d71d8  push r10
000074fc937d71da  push r11
000074fc937d71dc  sub rsp, 0xF0
000074fc937d71e3  vmovaps [rsp], xmm0
000074fc937d71e8  vmovaps [rsp+0x10], xmm1
000074fc937d71ee  vmovaps [rsp+0x20], xmm2
000074fc937d71f4  vmovaps [rsp+0x30], xmm3
000074fc937d71fa  vmovaps [rsp+0x40], xmm4
000074fc937d7200  vmovaps [rsp+0x50], xmm5
000074fc937d7206  vmovaps [rsp+0x60], xmm6
000074fc937d720c  vmovaps [rsp+0x70], xmm7
000074fc937d7212  vmovaps [rsp+0x80], xmm8
000074fc937d721b  vmovaps [rsp+0x90], xmm10
000074fc937d7224  vmovaps [rsp+0xA0], xmm11
000074fc937d722d  vmovaps [rsp+0xB0], xmm12
000074fc937d7236  vmovaps [rsp+0xC0], xmm13
000074fc937d723f  vmovaps [rsp+0xD0], xmm14
000074fc937d7248  vmovaps [rsp+0xE0], xmm15
000074fc937d7251  sub rsp, 0x30
000074fc937d7255  movaps [rsp], xmm9
000074fc937d725a  movaps [rsp+0x10], xmm10
000074fc937d7260  movaps [rsp+0x20], xmm8
000074fc937d7266  lea rdi, [rsp]
000074fc937d726a  mov esi, 0x00
000074fc937d726f  mov rax, 0x5D72CBC20530
000074fc937d7279  call rax
000074fc937d727b  movaps xmm9, [rsp]
000074fc937d7280  add rsp, 0x30
000074fc937d7284  vmovaps xmm0, [rsp]
000074fc937d7289  vmovaps xmm1, [rsp+0x10]
000074fc937d728f  vmovaps xmm2, [rsp+0x20]
000074fc937d7295  vmovaps xmm3, [rsp+0x30]
000074fc937d729b  vmovaps xmm4, [rsp+0x40]
000074fc937d72a1  vmovaps xmm5, [rsp+0x50]
000074fc937d72a7  vmovaps xmm6, [rsp+0x60]
000074fc937d72ad  vmovaps xmm7, [rsp+0x70]
000074fc937d72b3  vmovaps xmm8, [rsp+0x80]
000074fc937d72bc  vmovaps xmm10, [rsp+0x90]
000074fc937d72c5  vmovaps xmm11, [rsp+0xA0]
000074fc937d72ce  vmovaps xmm12, [rsp+0xB0]
000074fc937d72d7  vmovaps xmm13, [rsp+0xC0]
000074fc937d72e0  vmovaps xmm14, [rsp+0xD0]
000074fc937d72e9  vmovaps xmm15, [rsp+0xE0]
000074fc937d72f2  add rsp, 0xF0
000074fc937d72f9  pop r11
000074fc937d72fb  pop r10
000074fc937d72fd  pop r9
000074fc937d72ff  pop r8
000074fc937d7301  pop rsi
000074fc937d7302  pop rdi
000074fc937d7303  pop rdx
000074fc937d7304  pop rcx
000074fc937d7305  pop rax
000074fc937d7306  add rsp, 0x08
000074fc937d730a  jmp 0x000074FC937D5AFB
000074fc937d730f  call 0x000074FC936D64F0
000074fc937d7314  jmp 0x000074FC937D5C15
000074fc937d7319  call 0x000074FC936D64F0
000074fc937d731e  jmp 0x000074FC937D5C2B
000074fc937d7323  sub rsp, 0x08
000074fc937d7327  push rax
000074fc937d7328  push rcx
000074fc937d7329  push rdx
000074fc937d732a  push rdi
000074fc937d732b  push rsi
000074fc937d732c  push r8
000074fc937d732e  push r9
000074fc937d7330  push r10
000074fc937d7332  push r11
000074fc937d7334  sub rsp, 0xF0
000074fc937d733b  vmovaps [rsp], xmm0
000074fc937d7340  vmovaps [rsp+0x10], xmm2
000074fc937d7346  vmovaps [rsp+0x20], xmm3
000074fc937d734c  vmovaps [rsp+0x30], xmm4
000074fc937d7352  vmovaps [rsp+0x40], xmm5
000074fc937d7358  vmovaps [rsp+0x50], xmm6
000074fc937d735e  vmovaps [rsp+0x60], xmm7
000074fc937d7364  vmovaps [rsp+0x70], xmm8
000074fc937d736a  vmovaps [rsp+0x80], xmm9
000074fc937d7373  vmovaps [rsp+0x90], xmm10
000074fc937d737c  vmovaps [rsp+0xA0], xmm11
000074fc937d7385  vmovaps [rsp+0xB0], xmm12
000074fc937d738e  vmovaps [rsp+0xC0], xmm13
000074fc937d7397  vmovaps [rsp+0xD0], xmm14
000074fc937d73a0  vmovaps [rsp+0xE0], xmm15
000074fc937d73a9  sub rsp, 0x30
000074fc937d73ad  movaps [rsp], xmm1
000074fc937d73b1  movaps [rsp+0x10], xmm6
000074fc937d73b6  movaps [rsp+0x20], xmm15
000074fc937d73bc  lea rdi, [rsp]
000074fc937d73c0  mov esi, 0x00
000074fc937d73c5  mov rax, 0x5D72CBC20530
000074fc937d73cf  call rax
000074fc937d73d1  movaps xmm1, [rsp]
000074fc937d73d5  add rsp, 0x30
000074fc937d73d9  vmovaps xmm0, [rsp]
000074fc937d73de  vmovaps xmm2, [rsp+0x10]
000074fc937d73e4  vmovaps xmm3, [rsp+0x20]
000074fc937d73ea  vmovaps xmm4, [rsp+0x30]
000074fc937d73f0  vmovaps xmm5, [rsp+0x40]
000074fc937d73f6  vmovaps xmm6, [rsp+0x50]
000074fc937d73fc  vmovaps xmm7, [rsp+0x60]
000074fc937d7402  vmovaps xmm8, [rsp+0x70]
000074fc937d7408  vmovaps xmm9, [rsp+0x80]
000074fc937d7411  vmovaps xmm10, [rsp+0x90]
000074fc937d741a  vmovaps xmm11, [rsp+0xA0]
000074fc937d7423  vmovaps xmm12, [rsp+0xB0]
000074fc937d742c  vmovaps xmm13, [rsp+0xC0]
000074fc937d7435  vmovaps xmm14, [rsp+0xD0]
000074fc937d743e  vmovaps xmm15, [rsp+0xE0]
000074fc937d7447  add rsp, 0xF0
000074fc937d744e  pop r11
000074fc937d7450  pop r10
000074fc937d7452  pop r9
000074fc937d7454  pop r8
000074fc937d7456  pop rsi
000074fc937d7457  pop rdi
000074fc937d7458  pop rdx
000074fc937d7459  pop rcx
000074fc937d745a  pop rax
000074fc937d745b  add rsp, 0x08
000074fc937d745f  jmp 0x000074FC937D5C68
000074fc937d7464  call 0x000074FC936E5820
000074fc937d7469  jmp 0x000074FC937D5C75
000074fc937d746e  sub rsp, 0x08
000074fc937d7472  push rax
000074fc937d7473  push rcx
000074fc937d7474  push rdx
000074fc937d7475  push rdi
000074fc937d7476  push rsi
000074fc937d7477  push r8
000074fc937d7479  push r9
000074fc937d747b  push r10
000074fc937d747d  push r11
000074fc937d747f  sub rsp, 0xF0
000074fc937d7486  vmovaps [rsp], xmm0
000074fc937d748b  vmovaps [rsp+0x10], xmm1
000074fc937d7491  vmovaps [rsp+0x20], xmm2
000074fc937d7497  vmovaps [rsp+0x30], xmm3
000074fc937d749d  vmovaps [rsp+0x40], xmm4
000074fc937d74a3  vmovaps [rsp+0x50], xmm5
000074fc937d74a9  vmovaps [rsp+0x60], xmm6
000074fc937d74af  vmovaps [rsp+0x70], xmm7
000074fc937d74b5  vmovaps [rsp+0x80], xmm8
000074fc937d74be  vmovaps [rsp+0x90], xmm9
000074fc937d74c7  vmovaps [rsp+0xA0], xmm10
000074fc937d74d0  vmovaps [rsp+0xB0], xmm11
000074fc937d74d9  vmovaps [rsp+0xC0], xmm12
000074fc937d74e2  vmovaps [rsp+0xD0], xmm13
000074fc937d74eb  vmovaps [rsp+0xE0], xmm15
000074fc937d74f4  sub rsp, 0x30
000074fc937d74f8  movaps [rsp], xmm14
000074fc937d74fd  movaps [rsp+0x10], xmm4
000074fc937d7502  movaps [rsp+0x20], xmm3
000074fc937d7507  lea rdi, [rsp]
000074fc937d750b  mov esi, 0x00
000074fc937d7510  mov rax, 0x5D72CBC20530
000074fc937d751a  call rax
000074fc937d751c  movaps xmm14, [rsp]
000074fc937d7521  add rsp, 0x30
000074fc937d7525  vmovaps xmm0, [rsp]
000074fc937d752a  vmovaps xmm1, [rsp+0x10]
000074fc937d7530  vmovaps xmm2, [rsp+0x20]
000074fc937d7536  vmovaps xmm3, [rsp+0x30]
000074fc937d753c  vmovaps xmm4, [rsp+0x40]
000074fc937d7542  vmovaps xmm5, [rsp+0x50]
000074fc937d7548  vmovaps xmm6, [rsp+0x60]
000074fc937d754e  vmovaps xmm7, [rsp+0x70]
000074fc937d7554  vmovaps xmm8, [rsp+0x80]
000074fc937d755d  vmovaps xmm9, [rsp+0x90]
000074fc937d7566  vmovaps xmm10, [rsp+0xA0]
000074fc937d756f  vmovaps xmm11, [rsp+0xB0]
000074fc937d7578  vmovaps xmm12, [rsp+0xC0]
000074fc937d7581  vmovaps xmm13, [rsp+0xD0]
000074fc937d758a  vmovaps xmm15, [rsp+0xE0]
000074fc937d7593  add rsp, 0xF0
000074fc937d759a  pop r11
000074fc937d759c  pop r10
000074fc937d759e  pop r9
000074fc937d75a0  pop r8
000074fc937d75a2  pop rsi
000074fc937d75a3  pop rdi
000074fc937d75a4  pop rdx
000074fc937d75a5  pop rcx
000074fc937d75a6  pop rax
000074fc937d75a7  add rsp, 0x08
000074fc937d75ab  jmp 0x000074FC937D5C8F
000074fc937d75b0  sub rsp, 0x08
000074fc937d75b4  push rax
000074fc937d75b5  push rcx
000074fc937d75b6  push rdx
000074fc937d75b7  push rdi
000074fc937d75b8  push rsi
000074fc937d75b9  push r8
000074fc937d75bb  push r9
000074fc937d75bd  push r10
000074fc937d75bf  push r11
000074fc937d75c1  sub rsp, 0xF0
000074fc937d75c8  vmovaps [rsp], xmm0
000074fc937d75cd  vmovaps [rsp+0x10], xmm1
000074fc937d75d3  vmovaps [rsp+0x20], xmm2
000074fc937d75d9  vmovaps [rsp+0x30], xmm3
000074fc937d75df  vmovaps [rsp+0x40], xmm4
000074fc937d75e5  vmovaps [rsp+0x50], xmm5
000074fc937d75eb  vmovaps [rsp+0x60], xmm7
000074fc937d75f1  vmovaps [rsp+0x70], xmm8
000074fc937d75f7  vmovaps [rsp+0x80], xmm9
000074fc937d7600  vmovaps [rsp+0x90], xmm10
000074fc937d7609  vmovaps [rsp+0xA0], xmm11
000074fc937d7612  vmovaps [rsp+0xB0], xmm12
000074fc937d761b  vmovaps [rsp+0xC0], xmm13
000074fc937d7624  vmovaps [rsp+0xD0], xmm14
000074fc937d762d  vmovaps [rsp+0xE0], xmm15
000074fc937d7636  sub rsp, 0x30
000074fc937d763a  movaps [rsp], xmm6
000074fc937d763e  movaps [rsp+0x10], xmm9
000074fc937d7644  movaps [rsp+0x20], xmm7
000074fc937d7649  lea rdi, [rsp]
000074fc937d764d  mov esi, 0x00
000074fc937d7652  mov rax, 0x5D72CBC20530
000074fc937d765c  call rax
000074fc937d765e  movaps xmm6, [rsp]
000074fc937d7662  add rsp, 0x30
000074fc937d7666  vmovaps xmm0, [rsp]
000074fc937d766b  vmovaps xmm1, [rsp+0x10]
000074fc937d7671  vmovaps xmm2, [rsp+0x20]
000074fc937d7677  vmovaps xmm3, [rsp+0x30]
000074fc937d767d  vmovaps xmm4, [rsp+0x40]
000074fc937d7683  vmovaps xmm5, [rsp+0x50]
000074fc937d7689  vmovaps xmm7, [rsp+0x60]
000074fc937d768f  vmovaps xmm8, [rsp+0x70]
000074fc937d7695  vmovaps xmm9, [rsp+0x80]
000074fc937d769e  vmovaps xmm10, [rsp+0x90]
000074fc937d76a7  vmovaps xmm11, [rsp+0xA0]
000074fc937d76b0  vmovaps xmm12, [rsp+0xB0]
000074fc937d76b9  vmovaps xmm13, [rsp+0xC0]
000074fc937d76c2  vmovaps xmm14, [rsp+0xD0]
000074fc937d76cb  vmovaps xmm15, [rsp+0xE0]
000074fc937d76d4  add rsp, 0xF0
000074fc937d76db  pop r11
000074fc937d76dd  pop r10
000074fc937d76df  pop r9
000074fc937d76e1  pop r8
000074fc937d76e3  pop rsi
000074fc937d76e4  pop rdi
000074fc937d76e5  pop rdx
000074fc937d76e6  pop rcx
000074fc937d76e7  pop rax
000074fc937d76e8  add rsp, 0x08
000074fc937d76ec  jmp 0x000074FC937D5CA7
000074fc937d76f1  sub rsp, 0x08
000074fc937d76f5  push rax
000074fc937d76f6  push rcx
000074fc937d76f7  push rdx
000074fc937d76f8  push rdi
000074fc937d76f9  push rsi
000074fc937d76fa  push r8
000074fc937d76fc  push r9
000074fc937d76fe  push r10
000074fc937d7700  push r11
000074fc937d7702  sub rsp, 0xF0
000074fc937d7709  vmovaps [rsp], xmm0
000074fc937d770e  vmovaps [rsp+0x10], xmm1
000074fc937d7714  vmovaps [rsp+0x20], xmm2
000074fc937d771a  vmovaps [rsp+0x30], xmm3
000074fc937d7720  vmovaps [rsp+0x40], xmm4
000074fc937d7726  vmovaps [rsp+0x50], xmm5
000074fc937d772c  vmovaps [rsp+0x60], xmm6
000074fc937d7732  vmovaps [rsp+0x70], xmm8
000074fc937d7738  vmovaps [rsp+0x80], xmm9
000074fc937d7741  vmovaps [rsp+0x90], xmm10
000074fc937d774a  vmovaps [rsp+0xA0], xmm11
000074fc937d7753  vmovaps [rsp+0xB0], xmm12
000074fc937d775c  vmovaps [rsp+0xC0], xmm13
000074fc937d7765  vmovaps [rsp+0xD0], xmm14
000074fc937d776e  vmovaps [rsp+0xE0], xmm15
000074fc937d7777  sub rsp, 0x30
000074fc937d777b  movaps [rsp], xmm7
000074fc937d777f  movaps [rsp+0x10], xmm4
000074fc937d7784  movaps [rsp+0x20], xmm9
000074fc937d778a  lea rdi, [rsp]
000074fc937d778e  mov esi, 0x00
000074fc937d7793  mov rax, 0x5D72CBC20530
000074fc937d779d  call rax
000074fc937d779f  movaps xmm7, [rsp]
000074fc937d77a3  add rsp, 0x30
000074fc937d77a7  vmovaps xmm0, [rsp]
000074fc937d77ac  vmovaps xmm1, [rsp+0x10]
000074fc937d77b2  vmovaps xmm2, [rsp+0x20]
000074fc937d77b8  vmovaps xmm3, [rsp+0x30]
000074fc937d77be  vmovaps xmm4, [rsp+0x40]
000074fc937d77c4  vmovaps xmm5, [rsp+0x50]
000074fc937d77ca  vmovaps xmm6, [rsp+0x60]
000074fc937d77d0  vmovaps xmm8, [rsp+0x70]
000074fc937d77d6  vmovaps xmm9, [rsp+0x80]
000074fc937d77df  vmovaps xmm10, [rsp+0x90]
000074fc937d77e8  vmovaps xmm11, [rsp+0xA0]
000074fc937d77f1  vmovaps xmm12, [rsp+0xB0]
000074fc937d77fa  vmovaps xmm13, [rsp+0xC0]
000074fc937d7803  vmovaps xmm14, [rsp+0xD0]
000074fc937d780c  vmovaps xmm15, [rsp+0xE0]
000074fc937d7815  add rsp, 0xF0
000074fc937d781c  pop r11
000074fc937d781e  pop r10
000074fc937d7820  pop r9
000074fc937d7822  pop r8
000074fc937d7824  pop rsi
000074fc937d7825  pop rdi
000074fc937d7826  pop rdx
000074fc937d7827  pop rcx
000074fc937d7828  pop rax
000074fc937d7829  add rsp, 0x08
000074fc937d782d  jmp 0x000074FC937D5CD4
000074fc937d7832  sub rsp, 0x08
000074fc937d7836  push rax
000074fc937d7837  push rcx
000074fc937d7838  push rdx
000074fc937d7839  push rdi
000074fc937d783a  push rsi
000074fc937d783b  push r8
000074fc937d783d  push r9
000074fc937d783f  push r10
000074fc937d7841  push r11
000074fc937d7843  sub rsp, 0xF0
000074fc937d784a  vmovaps [rsp], xmm0
000074fc937d784f  vmovaps [rsp+0x10], xmm1
000074fc937d7855  vmovaps [rsp+0x20], xmm2
000074fc937d785b  vmovaps [rsp+0x30], xmm3
000074fc937d7861  vmovaps [rsp+0x40], xmm5
000074fc937d7867  vmovaps [rsp+0x50], xmm6
000074fc937d786d  vmovaps [rsp+0x60], xmm7
000074fc937d7873  vmovaps [rsp+0x70], xmm8
000074fc937d7879  vmovaps [rsp+0x80], xmm9
000074fc937d7882  vmovaps [rsp+0x90], xmm10
000074fc937d788b  vmovaps [rsp+0xA0], xmm11
000074fc937d7894  vmovaps [rsp+0xB0], xmm12
000074fc937d789d  vmovaps [rsp+0xC0], xmm13
000074fc937d78a6  vmovaps [rsp+0xD0], xmm14
000074fc937d78af  vmovaps [rsp+0xE0], xmm15
000074fc937d78b8  sub rsp, 0x30
000074fc937d78bc  movaps [rsp], xmm4
000074fc937d78c0  movaps [rsp+0x10], xmm15
000074fc937d78c6  movaps [rsp+0x20], xmm9
000074fc937d78cc  lea rdi, [rsp]
000074fc937d78d0  mov esi, 0x00
000074fc937d78d5  mov rax, 0x5D72CBC20530
000074fc937d78df  call rax
000074fc937d78e1  movaps xmm4, [rsp]
000074fc937d78e5  add rsp, 0x30
000074fc937d78e9  vmovaps xmm0, [rsp]
000074fc937d78ee  vmovaps xmm1, [rsp+0x10]
000074fc937d78f4  vmovaps xmm2, [rsp+0x20]
000074fc937d78fa  vmovaps xmm3, [rsp+0x30]
000074fc937d7900  vmovaps xmm5, [rsp+0x40]
000074fc937d7906  vmovaps xmm6, [rsp+0x50]
000074fc937d790c  vmovaps xmm7, [rsp+0x60]
000074fc937d7912  vmovaps xmm8, [rsp+0x70]
000074fc937d7918  vmovaps xmm9, [rsp+0x80]
000074fc937d7921  vmovaps xmm10, [rsp+0x90]
000074fc937d792a  vmovaps xmm11, [rsp+0xA0]
000074fc937d7933  vmovaps xmm12, [rsp+0xB0]
000074fc937d793c  vmovaps xmm13, [rsp+0xC0]
000074fc937d7945  vmovaps xmm14, [rsp+0xD0]
000074fc937d794e  vmovaps xmm15, [rsp+0xE0]
000074fc937d7957  add rsp, 0xF0
000074fc937d795e  pop r11
000074fc937d7960  pop r10
000074fc937d7962  pop r9
000074fc937d7964  pop r8
000074fc937d7966  pop rsi
000074fc937d7967  pop rdi
000074fc937d7968  pop rdx
000074fc937d7969  pop rcx
000074fc937d796a  pop rax
000074fc937d796b  add rsp, 0x08
000074fc937d796f  jmp 0x000074FC937D5CF9
000074fc937d7974  call 0x000074FC936E5820
000074fc937d7979  jmp 0x000074FC937D5D06
000074fc937d797e  sub rsp, 0x08
000074fc937d7982  push rax
000074fc937d7983  push rcx
000074fc937d7984  push rdx
000074fc937d7985  push rdi
000074fc937d7986  push rsi
000074fc937d7987  push r8
000074fc937d7989  push r9
000074fc937d798b  push r10
000074fc937d798d  push r11
000074fc937d798f  sub rsp, 0xF0
000074fc937d7996  vmovaps [rsp], xmm0
000074fc937d799b  vmovaps [rsp+0x10], xmm1
000074fc937d79a1  vmovaps [rsp+0x20], xmm2
000074fc937d79a7  vmovaps [rsp+0x30], xmm4
000074fc937d79ad  vmovaps [rsp+0x40], xmm5
000074fc937d79b3  vmovaps [rsp+0x50], xmm6
000074fc937d79b9  vmovaps [rsp+0x60], xmm7
000074fc937d79bf  vmovaps [rsp+0x70], xmm8
000074fc937d79c5  vmovaps [rsp+0x80], xmm9
000074fc937d79ce  vmovaps [rsp+0x90], xmm10
000074fc937d79d7  vmovaps [rsp+0xA0], xmm11
000074fc937d79e0  vmovaps [rsp+0xB0], xmm12
000074fc937d79e9  vmovaps [rsp+0xC0], xmm13
000074fc937d79f2  vmovaps [rsp+0xD0], xmm14
000074fc937d79fb  vmovaps [rsp+0xE0], xmm15
000074fc937d7a04  sub rsp, 0x30
000074fc937d7a08  movaps [rsp], xmm3
000074fc937d7a0c  movaps [rsp+0x10], xmm1
000074fc937d7a11  movaps [rsp+0x20], xmm9
000074fc937d7a17  lea rdi, [rsp]
000074fc937d7a1b  mov esi, 0x00
000074fc937d7a20  mov rax, 0x5D72CBC20530
000074fc937d7a2a  call rax
000074fc937d7a2c  movaps xmm3, [rsp]
000074fc937d7a30  add rsp, 0x30
000074fc937d7a34  vmovaps xmm0, [rsp]
000074fc937d7a39  vmovaps xmm1, [rsp+0x10]
000074fc937d7a3f  vmovaps xmm2, [rsp+0x20]
000074fc937d7a45  vmovaps xmm4, [rsp+0x30]
000074fc937d7a4b  vmovaps xmm5, [rsp+0x40]
000074fc937d7a51  vmovaps xmm6, [rsp+0x50]
000074fc937d7a57  vmovaps xmm7, [rsp+0x60]
000074fc937d7a5d  vmovaps xmm8, [rsp+0x70]
000074fc937d7a63  vmovaps xmm9, [rsp+0x80]
000074fc937d7a6c  vmovaps xmm10, [rsp+0x90]
000074fc937d7a75  vmovaps xmm11, [rsp+0xA0]
000074fc937d7a7e  vmovaps xmm12, [rsp+0xB0]
000074fc937d7a87  vmovaps xmm13, [rsp+0xC0]
000074fc937d7a90  vmovaps xmm14, [rsp+0xD0]
000074fc937d7a99  vmovaps xmm15, [rsp+0xE0]
000074fc937d7aa2  add rsp, 0xF0
000074fc937d7aa9  pop r11
000074fc937d7aab  pop r10
000074fc937d7aad  pop r9
000074fc937d7aaf  pop r8
000074fc937d7ab1  pop rsi
000074fc937d7ab2  pop rdi
000074fc937d7ab3  pop rdx
000074fc937d7ab4  pop rcx
000074fc937d7ab5  pop rax
000074fc937d7ab6  add rsp, 0x08
000074fc937d7aba  jmp 0x000074FC937D5D43
000074fc937d7abf  sub rsp, 0x08
000074fc937d7ac3  push rax
000074fc937d7ac4  push rcx
000074fc937d7ac5  push rdx
000074fc937d7ac6  push rdi
000074fc937d7ac7  push rsi
000074fc937d7ac8  push r8
000074fc937d7aca  push r9
000074fc937d7acc  push r10
000074fc937d7ace  push r11
000074fc937d7ad0  sub rsp, 0xF0
000074fc937d7ad7  vmovaps [rsp], xmm0
000074fc937d7adc  vmovaps [rsp+0x10], xmm2
000074fc937d7ae2  vmovaps [rsp+0x20], xmm3
000074fc937d7ae8  vmovaps [rsp+0x30], xmm4
000074fc937d7aee  vmovaps [rsp+0x40], xmm5
000074fc937d7af4  vmovaps [rsp+0x50], xmm6
000074fc937d7afa  vmovaps [rsp+0x60], xmm7
000074fc937d7b00  vmovaps [rsp+0x70], xmm8
000074fc937d7b06  vmovaps [rsp+0x80], xmm9
000074fc937d7b0f  vmovaps [rsp+0x90], xmm10
000074fc937d7b18  vmovaps [rsp+0xA0], xmm11
000074fc937d7b21  vmovaps [rsp+0xB0], xmm12
000074fc937d7b2a  vmovaps [rsp+0xC0], xmm13
000074fc937d7b33  vmovaps [rsp+0xD0], xmm14
000074fc937d7b3c  vmovaps [rsp+0xE0], xmm15
000074fc937d7b45  sub rsp, 0x30
000074fc937d7b49  movaps [rsp], xmm1
000074fc937d7b4d  movaps [rsp+0x10], xmm15
000074fc937d7b53  movaps [rsp+0x20], xmm9
000074fc937d7b59  lea rdi, [rsp]
000074fc937d7b5d  mov esi, 0x00
000074fc937d7b62  mov rax, 0x5D72CBC20530
000074fc937d7b6c  call rax
000074fc937d7b6e  movaps xmm1, [rsp]
000074fc937d7b72  add rsp, 0x30
000074fc937d7b76  vmovaps xmm0, [rsp]
000074fc937d7b7b  vmovaps xmm2, [rsp+0x10]
000074fc937d7b81  vmovaps xmm3, [rsp+0x20]
000074fc937d7b87  vmovaps xmm4, [rsp+0x30]
000074fc937d7b8d  vmovaps xmm5, [rsp+0x40]
000074fc937d7b93  vmovaps xmm6, [rsp+0x50]
000074fc937d7b99  vmovaps xmm7, [rsp+0x60]
000074fc937d7b9f  vmovaps xmm8, [rsp+0x70]
000074fc937d7ba5  vmovaps xmm9, [rsp+0x80]
000074fc937d7bae  vmovaps xmm10, [rsp+0x90]
000074fc937d7bb7  vmovaps xmm11, [rsp+0xA0]
000074fc937d7bc0  vmovaps xmm12, [rsp+0xB0]
000074fc937d7bc9  vmovaps xmm13, [rsp+0xC0]
000074fc937d7bd2  vmovaps xmm14, [rsp+0xD0]
000074fc937d7bdb  vmovaps xmm15, [rsp+0xE0]
000074fc937d7be4  add rsp, 0xF0
000074fc937d7beb  pop r11
000074fc937d7bed  pop r10
000074fc937d7bef  pop r9
000074fc937d7bf1  pop r8
000074fc937d7bf3  pop rsi
000074fc937d7bf4  pop rdi
000074fc937d7bf5  pop rdx
000074fc937d7bf6  pop rcx
000074fc937d7bf7  pop rax
000074fc937d7bf8  add rsp, 0x08
000074fc937d7bfc  jmp 0x000074FC937D5DCB
000074fc937d7c01  call 0x000074FC936E5820
000074fc937d7c06  jmp 0x000074FC937D5DD8
000074fc937d7c0b  sub rsp, 0x08
000074fc937d7c0f  push rax
000074fc937d7c10  push rcx
000074fc937d7c11  push rdx
000074fc937d7c12  push rdi
000074fc937d7c13  push rsi
000074fc937d7c14  push r8
000074fc937d7c16  push r9
000074fc937d7c18  push r10
000074fc937d7c1a  push r11
000074fc937d7c1c  sub rsp, 0xF0
000074fc937d7c23  vmovaps [rsp], xmm0
000074fc937d7c28  vmovaps [rsp+0x10], xmm2
000074fc937d7c2e  vmovaps [rsp+0x20], xmm3
000074fc937d7c34  vmovaps [rsp+0x30], xmm4
000074fc937d7c3a  vmovaps [rsp+0x40], xmm5
000074fc937d7c40  vmovaps [rsp+0x50], xmm6
000074fc937d7c46  vmovaps [rsp+0x60], xmm7
000074fc937d7c4c  vmovaps [rsp+0x70], xmm8
000074fc937d7c52  vmovaps [rsp+0x80], xmm9
000074fc937d7c5b  vmovaps [rsp+0x90], xmm10
000074fc937d7c64  vmovaps [rsp+0xA0], xmm11
000074fc937d7c6d  vmovaps [rsp+0xB0], xmm12
000074fc937d7c76  vmovaps [rsp+0xC0], xmm13
000074fc937d7c7f  vmovaps [rsp+0xD0], xmm14
000074fc937d7c88  vmovaps [rsp+0xE0], xmm15
000074fc937d7c91  sub rsp, 0x30
000074fc937d7c95  movaps [rsp], xmm1
000074fc937d7c99  movaps [rsp+0x10], xmm5
000074fc937d7c9e  movaps [rsp+0x20], xmm7
000074fc937d7ca3  lea rdi, [rsp]
000074fc937d7ca7  mov esi, 0x00
000074fc937d7cac  mov rax, 0x5D72CBC20530
000074fc937d7cb6  call rax
000074fc937d7cb8  movaps xmm1, [rsp]
000074fc937d7cbc  add rsp, 0x30
000074fc937d7cc0  vmovaps xmm0, [rsp]
000074fc937d7cc5  vmovaps xmm2, [rsp+0x10]
000074fc937d7ccb  vmovaps xmm3, [rsp+0x20]
000074fc937d7cd1  vmovaps xmm4, [rsp+0x30]
000074fc937d7cd7  vmovaps xmm5, [rsp+0x40]
000074fc937d7cdd  vmovaps xmm6, [rsp+0x50]
000074fc937d7ce3  vmovaps xmm7, [rsp+0x60]
000074fc937d7ce9  vmovaps xmm8, [rsp+0x70]
000074fc937d7cef  vmovaps xmm9, [rsp+0x80]
000074fc937d7cf8  vmovaps xmm10, [rsp+0x90]
000074fc937d7d01  vmovaps xmm11, [rsp+0xA0]
000074fc937d7d0a  vmovaps xmm12, [rsp+0xB0]
000074fc937d7d13  vmovaps xmm13, [rsp+0xC0]
000074fc937d7d1c  vmovaps xmm14, [rsp+0xD0]
000074fc937d7d25  vmovaps xmm15, [rsp+0xE0]
000074fc937d7d2e  add rsp, 0xF0
000074fc937d7d35  pop r11
000074fc937d7d37  pop r10
000074fc937d7d39  pop r9
000074fc937d7d3b  pop r8
000074fc937d7d3d  pop rsi
000074fc937d7d3e  pop rdi
000074fc937d7d3f  pop rdx
000074fc937d7d40  pop rcx
000074fc937d7d41  pop rax
000074fc937d7d42  add rsp, 0x08
000074fc937d7d46  jmp 0x000074FC937D5E7D
000074fc937d7d4b  sub rsp, 0x08
000074fc937d7d4f  push rax
000074fc937d7d50  push rcx
000074fc937d7d51  push rdx
000074fc937d7d52  push rdi
000074fc937d7d53  push rsi
000074fc937d7d54  push r8
000074fc937d7d56  push r9
000074fc937d7d58  push r10
000074fc937d7d5a  push r11
000074fc937d7d5c  sub rsp, 0xF0
000074fc937d7d63  vmovaps [rsp], xmm0
000074fc937d7d68  vmovaps [rsp+0x10], xmm1
000074fc937d7d6e  vmovaps [rsp+0x20], xmm2
000074fc937d7d74  vmovaps [rsp+0x30], xmm3
000074fc937d7d7a  vmovaps [rsp+0x40], xmm4
000074fc937d7d80  vmovaps [rsp+0x50], xmm5
000074fc937d7d86  vmovaps [rsp+0x60], xmm6
000074fc937d7d8c  vmovaps [rsp+0x70], xmm8
000074fc937d7d92  vmovaps [rsp+0x80], xmm9
000074fc937d7d9b  vmovaps [rsp+0x90], xmm10
000074fc937d7da4  vmovaps [rsp+0xA0], xmm11
000074fc937d7dad  vmovaps [rsp+0xB0], xmm12
000074fc937d7db6  vmovaps [rsp+0xC0], xmm13
000074fc937d7dbf  vmovaps [rsp+0xD0], xmm14
000074fc937d7dc8  vmovaps [rsp+0xE0], xmm15
000074fc937d7dd1  sub rsp, 0x30
000074fc937d7dd5  movaps [rsp], xmm7
000074fc937d7dd9  movaps [rsp+0x10], xmm5
000074fc937d7dde  movaps [rsp+0x20], xmm15
000074fc937d7de4  lea rdi, [rsp]
000074fc937d7de8  mov esi, 0x00
000074fc937d7ded  mov rax, 0x5D72CBC20530
000074fc937d7df7  call rax
000074fc937d7df9  movaps xmm7, [rsp]
000074fc937d7dfd  add rsp, 0x30
000074fc937d7e01  vmovaps xmm0, [rsp]
000074fc937d7e06  vmovaps xmm1, [rsp+0x10]
000074fc937d7e0c  vmovaps xmm2, [rsp+0x20]
000074fc937d7e12  vmovaps xmm3, [rsp+0x30]
000074fc937d7e18  vmovaps xmm4, [rsp+0x40]
000074fc937d7e1e  vmovaps xmm5, [rsp+0x50]
000074fc937d7e24  vmovaps xmm6, [rsp+0x60]
000074fc937d7e2a  vmovaps xmm8, [rsp+0x70]
000074fc937d7e30  vmovaps xmm9, [rsp+0x80]
000074fc937d7e39  vmovaps xmm10, [rsp+0x90]
000074fc937d7e42  vmovaps xmm11, [rsp+0xA0]
000074fc937d7e4b  vmovaps xmm12, [rsp+0xB0]
000074fc937d7e54  vmovaps xmm13, [rsp+0xC0]
000074fc937d7e5d  vmovaps xmm14, [rsp+0xD0]
000074fc937d7e66  vmovaps xmm15, [rsp+0xE0]
000074fc937d7e6f  add rsp, 0xF0
000074fc937d7e76  pop r11
000074fc937d7e78  pop r10
000074fc937d7e7a  pop r9
000074fc937d7e7c  pop r8
000074fc937d7e7e  pop rsi
000074fc937d7e7f  pop rdi
000074fc937d7e80  pop rdx
000074fc937d7e81  pop rcx
000074fc937d7e82  pop rax
000074fc937d7e83  add rsp, 0x08
000074fc937d7e87  jmp 0x000074FC937D5EB3
000074fc937d7e8c  call 0x000074FC936D64F0
000074fc937d7e91  jmp 0x000074FC937D5EC0
000074fc937d7e96  sub rsp, 0x08
000074fc937d7e9a  push rax
000074fc937d7e9b  push rcx
000074fc937d7e9c  push rdx
000074fc937d7e9d  push rdi
000074fc937d7e9e  push rsi
000074fc937d7e9f  push r8
000074fc937d7ea1  push r9
000074fc937d7ea3  push r10
000074fc937d7ea5  push r11
000074fc937d7ea7  sub rsp, 0xF0
000074fc937d7eae  vmovaps [rsp], xmm0
000074fc937d7eb3  vmovaps [rsp+0x10], xmm1
000074fc937d7eb9  vmovaps [rsp+0x20], xmm2
000074fc937d7ebf  vmovaps [rsp+0x30], xmm3
000074fc937d7ec5  vmovaps [rsp+0x40], xmm4
000074fc937d7ecb  vmovaps [rsp+0x50], xmm5
000074fc937d7ed1  vmovaps [rsp+0x60], xmm6
000074fc937d7ed7  vmovaps [rsp+0x70], xmm7
000074fc937d7edd  vmovaps [rsp+0x80], xmm8
000074fc937d7ee6  vmovaps [rsp+0x90], xmm9
000074fc937d7eef  vmovaps [rsp+0xA0], xmm10
000074fc937d7ef8  vmovaps [rsp+0xB0], xmm11
000074fc937d7f01  vmovaps [rsp+0xC0], xmm12
000074fc937d7f0a  vmovaps [rsp+0xD0], xmm13
000074fc937d7f13  vmovaps [rsp+0xE0], xmm14
000074fc937d7f1c  sub rsp, 0x30
000074fc937d7f20  movaps [rsp], xmm15
000074fc937d7f25  movaps [rsp+0x10], xmm5
000074fc937d7f2a  movaps [rsp+0x20], xmm3
000074fc937d7f2f  lea rdi, [rsp]
000074fc937d7f33  mov esi, 0x00
000074fc937d7f38  mov rax, 0x5D72CBC20530
000074fc937d7f42  call rax
000074fc937d7f44  movaps xmm15, [rsp]
000074fc937d7f49  add rsp, 0x30
000074fc937d7f4d  vmovaps xmm0, [rsp]
000074fc937d7f52  vmovaps xmm1, [rsp+0x10]
000074fc937d7f58  vmovaps xmm2, [rsp+0x20]
000074fc937d7f5e  vmovaps xmm3, [rsp+0x30]
000074fc937d7f64  vmovaps xmm4, [rsp+0x40]
000074fc937d7f6a  vmovaps xmm5, [rsp+0x50]
000074fc937d7f70  vmovaps xmm6, [rsp+0x60]
000074fc937d7f76  vmovaps xmm7, [rsp+0x70]
000074fc937d7f7c  vmovaps xmm8, [rsp+0x80]
000074fc937d7f85  vmovaps xmm9, [rsp+0x90]
000074fc937d7f8e  vmovaps xmm10, [rsp+0xA0]
000074fc937d7f97  vmovaps xmm11, [rsp+0xB0]
000074fc937d7fa0  vmovaps xmm12, [rsp+0xC0]
000074fc937d7fa9  vmovaps xmm13, [rsp+0xD0]
000074fc937d7fb2  vmovaps xmm14, [rsp+0xE0]
000074fc937d7fbb  add rsp, 0xF0
000074fc937d7fc2  pop r11
000074fc937d7fc4  pop r10
000074fc937d7fc6  pop r9
000074fc937d7fc8  pop r8
000074fc937d7fca  pop rsi
000074fc937d7fcb  pop rdi
000074fc937d7fcc  pop rdx
000074fc937d7fcd  pop rcx
000074fc937d7fce  pop rax
000074fc937d7fcf  add rsp, 0x08
000074fc937d7fd3  jmp 0x000074FC937D5EE6
000074fc937d7fd8  sub rsp, 0x08
000074fc937d7fdc  push rax
000074fc937d7fdd  push rcx
000074fc937d7fde  push rdx
000074fc937d7fdf  push rdi
000074fc937d7fe0  push rsi
000074fc937d7fe1  push r8
000074fc937d7fe3  push r9
000074fc937d7fe5  push r10
000074fc937d7fe7  push r11
000074fc937d7fe9  sub rsp, 0xF0
000074fc937d7ff0  vmovaps [rsp], xmm0
000074fc937d7ff5  vmovaps [rsp+0x10], xmm2
000074fc937d7ffb  vmovaps [rsp+0x20], xmm3
000074fc937d8001  vmovaps [rsp+0x30], xmm4
000074fc937d8007  vmovaps [rsp+0x40], xmm5
000074fc937d800d  vmovaps [rsp+0x50], xmm6
000074fc937d8013  vmovaps [rsp+0x60], xmm7
000074fc937d8019  vmovaps [rsp+0x70], xmm8
000074fc937d801f  vmovaps [rsp+0x80], xmm9
000074fc937d8028  vmovaps [rsp+0x90], xmm10
000074fc937d8031  vmovaps [rsp+0xA0], xmm11
000074fc937d803a  vmovaps [rsp+0xB0], xmm12
000074fc937d8043  vmovaps [rsp+0xC0], xmm13
000074fc937d804c  vmovaps [rsp+0xD0], xmm14
000074fc937d8055  vmovaps [rsp+0xE0], xmm15
000074fc937d805e  sub rsp, 0x30
000074fc937d8062  movaps [rsp], xmm1
000074fc937d8066  movaps [rsp+0x10], xmm5
000074fc937d806b  movaps [rsp+0x20], xmm4
000074fc937d8070  lea rdi, [rsp]
000074fc937d8074  mov esi, 0x00
000074fc937d8079  mov rax, 0x5D72CBC20530
000074fc937d8083  call rax
000074fc937d8085  movaps xmm1, [rsp]
000074fc937d8089  add rsp, 0x30
000074fc937d808d  vmovaps xmm0, [rsp]
000074fc937d8092  vmovaps xmm2, [rsp+0x10]
000074fc937d8098  vmovaps xmm3, [rsp+0x20]
000074fc937d809e  vmovaps xmm4, [rsp+0x30]
000074fc937d80a4  vmovaps xmm5, [rsp+0x40]
000074fc937d80aa  vmovaps xmm6, [rsp+0x50]
000074fc937d80b0  vmovaps xmm7, [rsp+0x60]
000074fc937d80b6  vmovaps xmm8, [rsp+0x70]
000074fc937d80bc  vmovaps xmm9, [rsp+0x80]
000074fc937d80c5  vmovaps xmm10, [rsp+0x90]
000074fc937d80ce  vmovaps xmm11, [rsp+0xA0]
000074fc937d80d7  vmovaps xmm12, [rsp+0xB0]
000074fc937d80e0  vmovaps xmm13, [rsp+0xC0]
000074fc937d80e9  vmovaps xmm14, [rsp+0xD0]
000074fc937d80f2  vmovaps xmm15, [rsp+0xE0]
000074fc937d80fb  add rsp, 0xF0
000074fc937d8102  pop r11
000074fc937d8104  pop r10
000074fc937d8106  pop r9
000074fc937d8108  pop r8
000074fc937d810a  pop rsi
000074fc937d810b  pop rdi
000074fc937d810c  pop rdx
000074fc937d810d  pop rcx
000074fc937d810e  pop rax
000074fc937d810f  add rsp, 0x08
000074fc937d8113  jmp 0x000074FC937D5F06
000074fc937d8118  sub rsp, 0x08
000074fc937d811c  push rax
000074fc937d811d  push rcx
000074fc937d811e  push rdx
000074fc937d811f  push rdi
000074fc937d8120  push rsi
000074fc937d8121  push r8
000074fc937d8123  push r9
000074fc937d8125  push r10
000074fc937d8127  push r11
000074fc937d8129  sub rsp, 0xF0
000074fc937d8130  vmovaps [rsp], xmm0
000074fc937d8135  vmovaps [rsp+0x10], xmm1
000074fc937d813b  vmovaps [rsp+0x20], xmm2
000074fc937d8141  vmovaps [rsp+0x30], xmm3
000074fc937d8147  vmovaps [rsp+0x40], xmm5
000074fc937d814d  vmovaps [rsp+0x50], xmm6
000074fc937d8153  vmovaps [rsp+0x60], xmm7
000074fc937d8159  vmovaps [rsp+0x70], xmm8
000074fc937d815f  vmovaps [rsp+0x80], xmm9
000074fc937d8168  vmovaps [rsp+0x90], xmm10
000074fc937d8171  vmovaps [rsp+0xA0], xmm11
000074fc937d817a  vmovaps [rsp+0xB0], xmm12
000074fc937d8183  vmovaps [rsp+0xC0], xmm13
000074fc937d818c  vmovaps [rsp+0xD0], xmm14
000074fc937d8195  vmovaps [rsp+0xE0], xmm15
000074fc937d819e  sub rsp, 0x30
000074fc937d81a2  movaps [rsp], xmm4
000074fc937d81a6  movaps [rsp+0x10], xmm3
000074fc937d81ab  movaps [rsp+0x20], xmm5
000074fc937d81b0  lea rdi, [rsp]
000074fc937d81b4  mov esi, 0x00
000074fc937d81b9  mov rax, 0x5D72CBC20530
000074fc937d81c3  call rax
000074fc937d81c5  movaps xmm4, [rsp]
000074fc937d81c9  add rsp, 0x30
000074fc937d81cd  vmovaps xmm0, [rsp]
000074fc937d81d2  vmovaps xmm1, [rsp+0x10]
000074fc937d81d8  vmovaps xmm2, [rsp+0x20]
000074fc937d81de  vmovaps xmm3, [rsp+0x30]
000074fc937d81e4  vmovaps xmm5, [rsp+0x40]
000074fc937d81ea  vmovaps xmm6, [rsp+0x50]
000074fc937d81f0  vmovaps xmm7, [rsp+0x60]
000074fc937d81f6  vmovaps xmm8, [rsp+0x70]
000074fc937d81fc  vmovaps xmm9, [rsp+0x80]
000074fc937d8205  vmovaps xmm10, [rsp+0x90]
000074fc937d820e  vmovaps xmm11, [rsp+0xA0]
000074fc937d8217  vmovaps xmm12, [rsp+0xB0]
000074fc937d8220  vmovaps xmm13, [rsp+0xC0]
000074fc937d8229  vmovaps xmm14, [rsp+0xD0]
000074fc937d8232  vmovaps xmm15, [rsp+0xE0]
000074fc937d823b  add rsp, 0xF0
000074fc937d8242  pop r11
000074fc937d8244  pop r10
000074fc937d8246  pop r9
000074fc937d8248  pop r8
000074fc937d824a  pop rsi
000074fc937d824b  pop rdi
000074fc937d824c  pop rdx
000074fc937d824d  pop rcx
000074fc937d824e  pop rax
000074fc937d824f  add rsp, 0x08
000074fc937d8253  jmp 0x000074FC937D5F54
000074fc937d8258  call 0x000074FC936D64F0
000074fc937d825d  jmp 0x000074FC937D5F61
000074fc937d8262  sub rsp, 0x08
000074fc937d8266  push rax
000074fc937d8267  push rcx
000074fc937d8268  push rdx
000074fc937d8269  push rdi
000074fc937d826a  push rsi
000074fc937d826b  push r8
000074fc937d826d  push r9
000074fc937d826f  push r10
000074fc937d8271  push r11
000074fc937d8273  sub rsp, 0xF0
000074fc937d827a  vmovaps [rsp], xmm0
000074fc937d827f  vmovaps [rsp+0x10], xmm1
000074fc937d8285  vmovaps [rsp+0x20], xmm2
000074fc937d828b  vmovaps [rsp+0x30], xmm3
000074fc937d8291  vmovaps [rsp+0x40], xmm4
000074fc937d8297  vmovaps [rsp+0x50], xmm6
000074fc937d829d  vmovaps [rsp+0x60], xmm7
000074fc937d82a3  vmovaps [rsp+0x70], xmm8
000074fc937d82a9  vmovaps [rsp+0x80], xmm9
000074fc937d82b2  vmovaps [rsp+0x90], xmm10
000074fc937d82bb  vmovaps [rsp+0xA0], xmm11
000074fc937d82c4  vmovaps [rsp+0xB0], xmm12
000074fc937d82cd  vmovaps [rsp+0xC0], xmm13
000074fc937d82d6  vmovaps [rsp+0xD0], xmm14
000074fc937d82df  vmovaps [rsp+0xE0], xmm15
000074fc937d82e8  sub rsp, 0x30
000074fc937d82ec  movaps [rsp], xmm5
000074fc937d82f0  movaps [rsp+0x10], xmm6
000074fc937d82f5  movaps [rsp+0x20], xmm3
000074fc937d82fa  lea rdi, [rsp]
000074fc937d82fe  mov esi, 0x00
000074fc937d8303  mov rax, 0x5D72CBC20530
000074fc937d830d  call rax
000074fc937d830f  movaps xmm5, [rsp]
000074fc937d8313  add rsp, 0x30
000074fc937d8317  vmovaps xmm0, [rsp]
000074fc937d831c  vmovaps xmm1, [rsp+0x10]
000074fc937d8322  vmovaps xmm2, [rsp+0x20]
000074fc937d8328  vmovaps xmm3, [rsp+0x30]
000074fc937d832e  vmovaps xmm4, [rsp+0x40]
000074fc937d8334  vmovaps xmm6, [rsp+0x50]
000074fc937d833a  vmovaps xmm7, [rsp+0x60]
000074fc937d8340  vmovaps xmm8, [rsp+0x70]
000074fc937d8346  vmovaps xmm9, [rsp+0x80]
000074fc937d834f  vmovaps xmm10, [rsp+0x90]
000074fc937d8358  vmovaps xmm11, [rsp+0xA0]
000074fc937d8361  vmovaps xmm12, [rsp+0xB0]
000074fc937d836a  vmovaps xmm13, [rsp+0xC0]
000074fc937d8373  vmovaps xmm14, [rsp+0xD0]
000074fc937d837c  vmovaps xmm15, [rsp+0xE0]
000074fc937d8385  add rsp, 0xF0
000074fc937d838c  pop r11
000074fc937d838e  pop r10
000074fc937d8390  pop r9
000074fc937d8392  pop r8
000074fc937d8394  pop rsi
000074fc937d8395  pop rdi
000074fc937d8396  pop rdx
000074fc937d8397  pop rcx
000074fc937d8398  pop rax
000074fc937d8399  add rsp, 0x08
000074fc937d839d  jmp 0x000074FC937D5F87
000074fc937d83a2  sub rsp, 0x08
000074fc937d83a6  push rax
000074fc937d83a7  push rcx
000074fc937d83a8  push rdx
000074fc937d83a9  push rdi
000074fc937d83aa  push rsi
000074fc937d83ab  push r8
000074fc937d83ad  push r9
000074fc937d83af  push r10
000074fc937d83b1  push r11
000074fc937d83b3  sub rsp, 0xF0
000074fc937d83ba  vmovaps [rsp], xmm0
000074fc937d83bf  vmovaps [rsp+0x10], xmm1
000074fc937d83c5  vmovaps [rsp+0x20], xmm2
000074fc937d83cb  vmovaps [rsp+0x30], xmm3
000074fc937d83d1  vmovaps [rsp+0x40], xmm4
000074fc937d83d7  vmovaps [rsp+0x50], xmm5
000074fc937d83dd  vmovaps [rsp+0x60], xmm7
000074fc937d83e3  vmovaps [rsp+0x70], xmm8
000074fc937d83e9  vmovaps [rsp+0x80], xmm9
000074fc937d83f2  vmovaps [rsp+0x90], xmm10
000074fc937d83fb  vmovaps [rsp+0xA0], xmm11
000074fc937d8404  vmovaps [rsp+0xB0], xmm12
000074fc937d840d  vmovaps [rsp+0xC0], xmm13
000074fc937d8416  vmovaps [rsp+0xD0], xmm14
000074fc937d841f  vmovaps [rsp+0xE0], xmm15
000074fc937d8428  sub rsp, 0x30
000074fc937d842c  movaps [rsp], xmm6
000074fc937d8430  movaps [rsp+0x10], xmm9
000074fc937d8436  movaps [rsp+0x20], xmm1
000074fc937d843b  lea rdi, [rsp]
000074fc937d843f  mov esi, 0x00
000074fc937d8444  mov rax, 0x5D72CBC20530
000074fc937d844e  call rax
000074fc937d8450  movaps xmm6, [rsp]
000074fc937d8454  add rsp, 0x30
000074fc937d8458  vmovaps xmm0, [rsp]
000074fc937d845d  vmovaps xmm1, [rsp+0x10]
000074fc937d8463  vmovaps xmm2, [rsp+0x20]
000074fc937d8469  vmovaps xmm3, [rsp+0x30]
000074fc937d846f  vmovaps xmm4, [rsp+0x40]
000074fc937d8475  vmovaps xmm5, [rsp+0x50]
000074fc937d847b  vmovaps xmm7, [rsp+0x60]
000074fc937d8481  vmovaps xmm8, [rsp+0x70]
000074fc937d8487  vmovaps xmm9, [rsp+0x80]
000074fc937d8490  vmovaps xmm10, [rsp+0x90]
000074fc937d8499  vmovaps xmm11, [rsp+0xA0]
000074fc937d84a2  vmovaps xmm12, [rsp+0xB0]
000074fc937d84ab  vmovaps xmm13, [rsp+0xC0]
000074fc937d84b4  vmovaps xmm14, [rsp+0xD0]
000074fc937d84bd  vmovaps xmm15, [rsp+0xE0]
000074fc937d84c6  add rsp, 0xF0
000074fc937d84cd  pop r11
000074fc937d84cf  pop r10
000074fc937d84d1  pop r9
000074fc937d84d3  pop r8
000074fc937d84d5  pop rsi
000074fc937d84d6  pop rdi
000074fc937d84d7  pop rdx
000074fc937d84d8  pop rcx
000074fc937d84d9  pop rax
000074fc937d84da  add rsp, 0x08
000074fc937d84de  jmp 0x000074FC937D5FAB
000074fc937d84e3  sub rsp, 0x08
000074fc937d84e7  push rax
000074fc937d84e8  push rcx
000074fc937d84e9  push rdx
000074fc937d84ea  push rdi
000074fc937d84eb  push rsi
000074fc937d84ec  push r8
000074fc937d84ee  push r9
000074fc937d84f0  push r10
000074fc937d84f2  push r11
000074fc937d84f4  sub rsp, 0xF0
000074fc937d84fb  vmovaps [rsp], xmm0
000074fc937d8500  vmovaps [rsp+0x10], xmm1
000074fc937d8506  vmovaps [rsp+0x20], xmm2
000074fc937d850c  vmovaps [rsp+0x30], xmm3
000074fc937d8512  vmovaps [rsp+0x40], xmm4
000074fc937d8518  vmovaps [rsp+0x50], xmm5
000074fc937d851e  vmovaps [rsp+0x60], xmm6
000074fc937d8524  vmovaps [rsp+0x70], xmm7
000074fc937d852a  vmovaps [rsp+0x80], xmm8
000074fc937d8533  vmovaps [rsp+0x90], xmm10
000074fc937d853c  vmovaps [rsp+0xA0], xmm11
000074fc937d8545  vmovaps [rsp+0xB0], xmm12
000074fc937d854e  vmovaps [rsp+0xC0], xmm13
000074fc937d8557  vmovaps [rsp+0xD0], xmm14
000074fc937d8560  vmovaps [rsp+0xE0], xmm15
000074fc937d8569  sub rsp, 0x30
000074fc937d856d  movaps [rsp], xmm9
000074fc937d8572  movaps [rsp+0x10], xmm3
000074fc937d8577  movaps [rsp+0x20], xmm1
000074fc937d857c  lea rdi, [rsp]
000074fc937d8580  mov esi, 0x00
000074fc937d8585  mov rax, 0x5D72CBC20530
000074fc937d858f  call rax
000074fc937d8591  movaps xmm9, [rsp]
000074fc937d8596  add rsp, 0x30
000074fc937d859a  vmovaps xmm0, [rsp]
000074fc937d859f  vmovaps xmm1, [rsp+0x10]
000074fc937d85a5  vmovaps xmm2, [rsp+0x20]
000074fc937d85ab  vmovaps xmm3, [rsp+0x30]
000074fc937d85b1  vmovaps xmm4, [rsp+0x40]
000074fc937d85b7  vmovaps xmm5, [rsp+0x50]
000074fc937d85bd  vmovaps xmm6, [rsp+0x60]
000074fc937d85c3  vmovaps xmm7, [rsp+0x70]
000074fc937d85c9  vmovaps xmm8, [rsp+0x80]
000074fc937d85d2  vmovaps xmm10, [rsp+0x90]
000074fc937d85db  vmovaps xmm11, [rsp+0xA0]
000074fc937d85e4  vmovaps xmm12, [rsp+0xB0]
000074fc937d85ed  vmovaps xmm13, [rsp+0xC0]
000074fc937d85f6  vmovaps xmm14, [rsp+0xD0]
000074fc937d85ff  vmovaps xmm15, [rsp+0xE0]
000074fc937d8608  add rsp, 0xF0
000074fc937d860f  pop r11
000074fc937d8611  pop r10
000074fc937d8613  pop r9
000074fc937d8615  pop r8
000074fc937d8617  pop rsi
000074fc937d8618  pop rdi
000074fc937d8619  pop rdx
000074fc937d861a  pop rcx
000074fc937d861b  pop rax
000074fc937d861c  add rsp, 0x08
000074fc937d8620  jmp 0x000074FC937D5FF7
000074fc937d8625  call 0x000074FC936D64F0
000074fc937d862a  jmp 0x000074FC937D6004
000074fc937d862f  sub rsp, 0x08
000074fc937d8633  push rax
000074fc937d8634  push rcx
000074fc937d8635  push rdx
000074fc937d8636  push rdi
000074fc937d8637  push rsi
000074fc937d8638  push r8
000074fc937d863a  push r9
000074fc937d863c  push r10
000074fc937d863e  push r11
000074fc937d8640  sub rsp, 0xF0
000074fc937d8647  vmovaps [rsp], xmm0
000074fc937d864c  vmovaps [rsp+0x10], xmm1
000074fc937d8652  vmovaps [rsp+0x20], xmm2
000074fc937d8658  vmovaps [rsp+0x30], xmm3
000074fc937d865e  vmovaps [rsp+0x40], xmm4
000074fc937d8664  vmovaps [rsp+0x50], xmm5
000074fc937d866a  vmovaps [rsp+0x60], xmm6
000074fc937d8670  vmovaps [rsp+0x70], xmm7
000074fc937d8676  vmovaps [rsp+0x80], xmm8
000074fc937d867f  vmovaps [rsp+0x90], xmm9
000074fc937d8688  vmovaps [rsp+0xA0], xmm10
000074fc937d8691  vmovaps [rsp+0xB0], xmm11
000074fc937d869a  vmovaps [rsp+0xC0], xmm12
000074fc937d86a3  vmovaps [rsp+0xD0], xmm13
000074fc937d86ac  vmovaps [rsp+0xE0], xmm14
000074fc937d86b5  sub rsp, 0x30
000074fc937d86b9  movaps [rsp], xmm15
000074fc937d86be  movaps [rsp+0x10], xmm3
000074fc937d86c3  movaps [rsp+0x20], xmm7
000074fc937d86c8  lea rdi, [rsp]
000074fc937d86cc  mov esi, 0x00
000074fc937d86d1  mov rax, 0x5D72CBC20530
000074fc937d86db  call rax
000074fc937d86dd  movaps xmm15, [rsp]
000074fc937d86e2  add rsp, 0x30
000074fc937d86e6  vmovaps xmm0, [rsp]
000074fc937d86eb  vmovaps xmm1, [rsp+0x10]
000074fc937d86f1  vmovaps xmm2, [rsp+0x20]
000074fc937d86f7  vmovaps xmm3, [rsp+0x30]
000074fc937d86fd  vmovaps xmm4, [rsp+0x40]
000074fc937d8703  vmovaps xmm5, [rsp+0x50]
000074fc937d8709  vmovaps xmm6, [rsp+0x60]
000074fc937d870f  vmovaps xmm7, [rsp+0x70]
000074fc937d8715  vmovaps xmm8, [rsp+0x80]
000074fc937d871e  vmovaps xmm9, [rsp+0x90]
000074fc937d8727  vmovaps xmm10, [rsp+0xA0]
000074fc937d8730  vmovaps xmm11, [rsp+0xB0]
000074fc937d8739  vmovaps xmm12, [rsp+0xC0]
000074fc937d8742  vmovaps xmm13, [rsp+0xD0]
000074fc937d874b  vmovaps xmm14, [rsp+0xE0]
000074fc937d8754  add rsp, 0xF0
000074fc937d875b  pop r11
000074fc937d875d  pop r10
000074fc937d875f  pop r9
000074fc937d8761  pop r8
000074fc937d8763  pop rsi
000074fc937d8764  pop rdi
000074fc937d8765  pop rdx
000074fc937d8766  pop rcx
000074fc937d8767  pop rax
000074fc937d8768  add rsp, 0x08
000074fc937d876c  jmp 0x000074FC937D6030
000074fc937d8771  sub rsp, 0x08
000074fc937d8775  push rax
000074fc937d8776  push rcx
000074fc937d8777  push rdx
000074fc937d8778  push rdi
000074fc937d8779  push rsi
000074fc937d877a  push r8
000074fc937d877c  push r9
000074fc937d877e  push r10
000074fc937d8780  push r11
000074fc937d8782  sub rsp, 0xF0
000074fc937d8789  vmovaps [rsp], xmm0
000074fc937d878e  vmovaps [rsp+0x10], xmm1
000074fc937d8794  vmovaps [rsp+0x20], xmm2
000074fc937d879a  vmovaps [rsp+0x30], xmm4
000074fc937d87a0  vmovaps [rsp+0x40], xmm5
000074fc937d87a6  vmovaps [rsp+0x50], xmm6
000074fc937d87ac  vmovaps [rsp+0x60], xmm7
000074fc937d87b2  vmovaps [rsp+0x70], xmm8
000074fc937d87b8  vmovaps [rsp+0x80], xmm9
000074fc937d87c1  vmovaps [rsp+0x90], xmm10
000074fc937d87ca  vmovaps [rsp+0xA0], xmm11
000074fc937d87d3  vmovaps [rsp+0xB0], xmm12
000074fc937d87dc  vmovaps [rsp+0xC0], xmm13
000074fc937d87e5  vmovaps [rsp+0xD0], xmm14
000074fc937d87ee  vmovaps [rsp+0xE0], xmm15
000074fc937d87f7  sub rsp, 0x30
000074fc937d87fb  movaps [rsp], xmm3
000074fc937d87ff  movaps [rsp+0x10], xmm1
000074fc937d8804  movaps [rsp+0x20], xmm15
000074fc937d880a  lea rdi, [rsp]
000074fc937d880e  mov esi, 0x00
000074fc937d8813  mov rax, 0x5D72CBC20530
000074fc937d881d  call rax
000074fc937d881f  movaps xmm3, [rsp]
000074fc937d8823  add rsp, 0x30
000074fc937d8827  vmovaps xmm0, [rsp]
000074fc937d882c  vmovaps xmm1, [rsp+0x10]
000074fc937d8832  vmovaps xmm2, [rsp+0x20]
000074fc937d8838  vmovaps xmm4, [rsp+0x30]
000074fc937d883e  vmovaps xmm5, [rsp+0x40]
000074fc937d8844  vmovaps xmm6, [rsp+0x50]
000074fc937d884a  vmovaps xmm7, [rsp+0x60]
000074fc937d8850  vmovaps xmm8, [rsp+0x70]
000074fc937d8856  vmovaps xmm9, [rsp+0x80]
000074fc937d885f  vmovaps xmm10, [rsp+0x90]
000074fc937d8868  vmovaps xmm11, [rsp+0xA0]
000074fc937d8871  vmovaps xmm12, [rsp+0xB0]
000074fc937d887a  vmovaps xmm13, [rsp+0xC0]
000074fc937d8883  vmovaps xmm14, [rsp+0xD0]
000074fc937d888c  vmovaps xmm15, [rsp+0xE0]
000074fc937d8895  add rsp, 0xF0
000074fc937d889c  pop r11
000074fc937d889e  pop r10
000074fc937d88a0  pop r9
000074fc937d88a2  pop r8
000074fc937d88a4  pop rsi
000074fc937d88a5  pop rdi
000074fc937d88a6  pop rdx
000074fc937d88a7  pop rcx
000074fc937d88a8  pop rax
000074fc937d88a9  add rsp, 0x08
000074fc937d88ad  jmp 0x000074FC937D60BF
000074fc937d88b2  call 0x000074FC936D64F0
000074fc937d88b7  jmp 0x000074FC937D60C9
000074fc937d88bc  sub rsp, 0x08
000074fc937d88c0  push rax
000074fc937d88c1  push rcx
000074fc937d88c2  push rdx
000074fc937d88c3  push rdi
000074fc937d88c4  push rsi
000074fc937d88c5  push r8
000074fc937d88c7  push r9
000074fc937d88c9  push r10
000074fc937d88cb  push r11
000074fc937d88cd  sub rsp, 0xF0
000074fc937d88d4  vmovaps [rsp], xmm0
000074fc937d88d9  vmovaps [rsp+0x10], xmm1
000074fc937d88df  vmovaps [rsp+0x20], xmm2
000074fc937d88e5  vmovaps [rsp+0x30], xmm3
000074fc937d88eb  vmovaps [rsp+0x40], xmm4
000074fc937d88f1  vmovaps [rsp+0x50], xmm5
000074fc937d88f7  vmovaps [rsp+0x60], xmm6
000074fc937d88fd  vmovaps [rsp+0x70], xmm7
000074fc937d8903  vmovaps [rsp+0x80], xmm8
000074fc937d890c  vmovaps [rsp+0x90], xmm9
000074fc937d8915  vmovaps [rsp+0xA0], xmm10
000074fc937d891e  vmovaps [rsp+0xB0], xmm11
000074fc937d8927  vmovaps [rsp+0xC0], xmm12
000074fc937d8930  vmovaps [rsp+0xD0], xmm13
000074fc937d8939  vmovaps [rsp+0xE0], xmm14
000074fc937d8942  sub rsp, 0x30
000074fc937d8946  movaps [rsp], xmm15
000074fc937d894b  movaps [rsp+0x10], xmm14
000074fc937d8951  movaps [rsp+0x20], xmm4
000074fc937d8956  lea rdi, [rsp]
000074fc937d895a  mov esi, 0x00
000074fc937d895f  mov rax, 0x5D72CBC20530
000074fc937d8969  call rax
000074fc937d896b  movaps xmm15, [rsp]
000074fc937d8970  add rsp, 0x30
000074fc937d8974  vmovaps xmm0, [rsp]
000074fc937d8979  vmovaps xmm1, [rsp+0x10]
000074fc937d897f  vmovaps xmm2, [rsp+0x20]
000074fc937d8985  vmovaps xmm3, [rsp+0x30]
000074fc937d898b  vmovaps xmm4, [rsp+0x40]
000074fc937d8991  vmovaps xmm5, [rsp+0x50]
000074fc937d8997  vmovaps xmm6, [rsp+0x60]
000074fc937d899d  vmovaps xmm7, [rsp+0x70]
000074fc937d89a3  vmovaps xmm8, [rsp+0x80]
000074fc937d89ac  vmovaps xmm9, [rsp+0x90]
000074fc937d89b5  vmovaps xmm10, [rsp+0xA0]
000074fc937d89be  vmovaps xmm11, [rsp+0xB0]
000074fc937d89c7  vmovaps xmm12, [rsp+0xC0]
000074fc937d89d0  vmovaps xmm13, [rsp+0xD0]
000074fc937d89d9  vmovaps xmm14, [rsp+0xE0]
000074fc937d89e2  add rsp, 0xF0
000074fc937d89e9  pop r11
000074fc937d89eb  pop r10
000074fc937d89ed  pop r9
000074fc937d89ef  pop r8
000074fc937d89f1  pop rsi
000074fc937d89f2  pop rdi
000074fc937d89f3  pop rdx
000074fc937d89f4  pop rcx
000074fc937d89f5  pop rax
000074fc937d89f6  add rsp, 0x08
000074fc937d89fa  jmp 0x000074FC937D60F7
000074fc937d89ff  sub rsp, 0x08
000074fc937d8a03  push rax
000074fc937d8a04  push rcx
000074fc937d8a05  push rdx
000074fc937d8a06  push rdi
000074fc937d8a07  push rsi
000074fc937d8a08  push r8
000074fc937d8a0a  push r9
000074fc937d8a0c  push r10
000074fc937d8a0e  push r11
000074fc937d8a10  sub rsp, 0xF0
000074fc937d8a17  vmovaps [rsp], xmm0
000074fc937d8a1c  vmovaps [rsp+0x10], xmm1
000074fc937d8a22  vmovaps [rsp+0x20], xmm2
000074fc937d8a28  vmovaps [rsp+0x30], xmm3
000074fc937d8a2e  vmovaps [rsp+0x40], xmm4
000074fc937d8a34  vmovaps [rsp+0x50], xmm5
000074fc937d8a3a  vmovaps [rsp+0x60], xmm6
000074fc937d8a40  vmovaps [rsp+0x70], xmm7
000074fc937d8a46  vmovaps [rsp+0x80], xmm8
000074fc937d8a4f  vmovaps [rsp+0x90], xmm9
000074fc937d8a58  vmovaps [rsp+0xA0], xmm10
000074fc937d8a61  vmovaps [rsp+0xB0], xmm11
000074fc937d8a6a  vmovaps [rsp+0xC0], xmm12
000074fc937d8a73  vmovaps [rsp+0xD0], xmm13
000074fc937d8a7c  vmovaps [rsp+0xE0], xmm15
000074fc937d8a85  sub rsp, 0x30
000074fc937d8a89  movaps [rsp], xmm14
000074fc937d8a8e  movaps [rsp+0x10], xmm2
000074fc937d8a93  movaps [rsp+0x20], xmm1
000074fc937d8a98  lea rdi, [rsp]
000074fc937d8a9c  mov esi, 0x00
000074fc937d8aa1  mov rax, 0x5D72CBC20530
000074fc937d8aab  call rax
000074fc937d8aad  movaps xmm14, [rsp]
000074fc937d8ab2  add rsp, 0x30
000074fc937d8ab6  vmovaps xmm0, [rsp]
000074fc937d8abb  vmovaps xmm1, [rsp+0x10]
000074fc937d8ac1  vmovaps xmm2, [rsp+0x20]
000074fc937d8ac7  vmovaps xmm3, [rsp+0x30]
000074fc937d8acd  vmovaps xmm4, [rsp+0x40]
000074fc937d8ad3  vmovaps xmm5, [rsp+0x50]
000074fc937d8ad9  vmovaps xmm6, [rsp+0x60]
000074fc937d8adf  vmovaps xmm7, [rsp+0x70]
000074fc937d8ae5  vmovaps xmm8, [rsp+0x80]
000074fc937d8aee  vmovaps xmm9, [rsp+0x90]
000074fc937d8af7  vmovaps xmm10, [rsp+0xA0]
000074fc937d8b00  vmovaps xmm11, [rsp+0xB0]
000074fc937d8b09  vmovaps xmm12, [rsp+0xC0]
000074fc937d8b12  vmovaps xmm13, [rsp+0xD0]
000074fc937d8b1b  vmovaps xmm15, [rsp+0xE0]
000074fc937d8b24  add rsp, 0xF0
000074fc937d8b2b  pop r11
000074fc937d8b2d  pop r10
000074fc937d8b2f  pop r9
000074fc937d8b31  pop r8
000074fc937d8b33  pop rsi
000074fc937d8b34  pop rdi
000074fc937d8b35  pop rdx
000074fc937d8b36  pop rcx
000074fc937d8b37  pop rax
000074fc937d8b38  add rsp, 0x08
000074fc937d8b3c  jmp 0x000074FC937D611D
000074fc937d8b41  sub rsp, 0x08
000074fc937d8b45  push rax
000074fc937d8b46  push rcx
000074fc937d8b47  push rdx
000074fc937d8b48  push rdi
000074fc937d8b49  push rsi
000074fc937d8b4a  push r8
000074fc937d8b4c  push r9
000074fc937d8b4e  push r10
000074fc937d8b50  push r11
000074fc937d8b52  sub rsp, 0xF0
000074fc937d8b59  vmovaps [rsp], xmm0
000074fc937d8b5e  vmovaps [rsp+0x10], xmm2
000074fc937d8b64  vmovaps [rsp+0x20], xmm3
000074fc937d8b6a  vmovaps [rsp+0x30], xmm4
000074fc937d8b70  vmovaps [rsp+0x40], xmm5
000074fc937d8b76  vmovaps [rsp+0x50], xmm6
000074fc937d8b7c  vmovaps [rsp+0x60], xmm7
000074fc937d8b82  vmovaps [rsp+0x70], xmm8
000074fc937d8b88  vmovaps [rsp+0x80], xmm9
000074fc937d8b91  vmovaps [rsp+0x90], xmm10
000074fc937d8b9a  vmovaps [rsp+0xA0], xmm11
000074fc937d8ba3  vmovaps [rsp+0xB0], xmm12
000074fc937d8bac  vmovaps [rsp+0xC0], xmm13
000074fc937d8bb5  vmovaps [rsp+0xD0], xmm14
000074fc937d8bbe  vmovaps [rsp+0xE0], xmm15
000074fc937d8bc7  sub rsp, 0x30
000074fc937d8bcb  movaps [rsp], xmm1
000074fc937d8bcf  movaps [rsp+0x10], xmm4
000074fc937d8bd4  movaps [rsp+0x20], xmm9
000074fc937d8bda  lea rdi, [rsp]
000074fc937d8bde  mov esi, 0x00
000074fc937d8be3  mov rax, 0x5D72CBC20530
000074fc937d8bed  call rax
000074fc937d8bef  movaps xmm1, [rsp]
000074fc937d8bf3  add rsp, 0x30
000074fc937d8bf7  vmovaps xmm0, [rsp]
000074fc937d8bfc  vmovaps xmm2, [rsp+0x10]
000074fc937d8c02  vmovaps xmm3, [rsp+0x20]
000074fc937d8c08  vmovaps xmm4, [rsp+0x30]
000074fc937d8c0e  vmovaps xmm5, [rsp+0x40]
000074fc937d8c14  vmovaps xmm6, [rsp+0x50]
000074fc937d8c1a  vmovaps xmm7, [rsp+0x60]
000074fc937d8c20  vmovaps xmm8, [rsp+0x70]
000074fc937d8c26  vmovaps xmm9, [rsp+0x80]
000074fc937d8c2f  vmovaps xmm10, [rsp+0x90]
000074fc937d8c38  vmovaps xmm11, [rsp+0xA0]
000074fc937d8c41  vmovaps xmm12, [rsp+0xB0]
000074fc937d8c4a  vmovaps xmm13, [rsp+0xC0]
000074fc937d8c53  vmovaps xmm14, [rsp+0xD0]
000074fc937d8c5c  vmovaps xmm15, [rsp+0xE0]
000074fc937d8c65  add rsp, 0xF0
000074fc937d8c6c  pop r11
000074fc937d8c6e  pop r10
000074fc937d8c70  pop r9
000074fc937d8c72  pop r8
000074fc937d8c74  pop rsi
000074fc937d8c75  pop rdi
000074fc937d8c76  pop rdx
000074fc937d8c77  pop rcx
000074fc937d8c78  pop rax
000074fc937d8c79  add rsp, 0x08
000074fc937d8c7d  jmp 0x000074FC937D613B
000074fc937d8c82  sub rsp, 0x08
000074fc937d8c86  push rax
000074fc937d8c87  push rcx
000074fc937d8c88  push rdx
000074fc937d8c89  push rdi
000074fc937d8c8a  push rsi
000074fc937d8c8b  push r8
000074fc937d8c8d  push r9
000074fc937d8c8f  push r10
000074fc937d8c91  push r11
000074fc937d8c93  sub rsp, 0xF0
000074fc937d8c9a  vmovaps [rsp], xmm0
000074fc937d8c9f  vmovaps [rsp+0x10], xmm1
000074fc937d8ca5  vmovaps [rsp+0x20], xmm2
000074fc937d8cab  vmovaps [rsp+0x30], xmm3
000074fc937d8cb1  vmovaps [rsp+0x40], xmm5
000074fc937d8cb7  vmovaps [rsp+0x50], xmm6
000074fc937d8cbd  vmovaps [rsp+0x60], xmm7
000074fc937d8cc3  vmovaps [rsp+0x70], xmm8
000074fc937d8cc9  vmovaps [rsp+0x80], xmm9
000074fc937d8cd2  vmovaps [rsp+0x90], xmm10
000074fc937d8cdb  vmovaps [rsp+0xA0], xmm11
000074fc937d8ce4  vmovaps [rsp+0xB0], xmm12
000074fc937d8ced  vmovaps [rsp+0xC0], xmm13
000074fc937d8cf6  vmovaps [rsp+0xD0], xmm14
000074fc937d8cff  vmovaps [rsp+0xE0], xmm15
000074fc937d8d08  sub rsp, 0x30
000074fc937d8d0c  movaps [rsp], xmm4
000074fc937d8d10  movaps [rsp+0x10], xmm2
000074fc937d8d15  movaps [rsp+0x20], xmm9
000074fc937d8d1b  lea rdi, [rsp]
000074fc937d8d1f  mov esi, 0x00
000074fc937d8d24  mov rax, 0x5D72CBC20530
000074fc937d8d2e  call rax
000074fc937d8d30  movaps xmm4, [rsp]
000074fc937d8d34  add rsp, 0x30
000074fc937d8d38  vmovaps xmm0, [rsp]
000074fc937d8d3d  vmovaps xmm1, [rsp+0x10]
000074fc937d8d43  vmovaps xmm2, [rsp+0x20]
000074fc937d8d49  vmovaps xmm3, [rsp+0x30]
000074fc937d8d4f  vmovaps xmm5, [rsp+0x40]
000074fc937d8d55  vmovaps xmm6, [rsp+0x50]
000074fc937d8d5b  vmovaps xmm7, [rsp+0x60]
000074fc937d8d61  vmovaps xmm8, [rsp+0x70]
000074fc937d8d67  vmovaps xmm9, [rsp+0x80]
000074fc937d8d70  vmovaps xmm10, [rsp+0x90]
000074fc937d8d79  vmovaps xmm11, [rsp+0xA0]
000074fc937d8d82  vmovaps xmm12, [rsp+0xB0]
000074fc937d8d8b  vmovaps xmm13, [rsp+0xC0]
000074fc937d8d94  vmovaps xmm14, [rsp+0xD0]
000074fc937d8d9d  vmovaps xmm15, [rsp+0xE0]
000074fc937d8da6  add rsp, 0xF0
000074fc937d8dad  pop r11
000074fc937d8daf  pop r10
000074fc937d8db1  pop r9
000074fc937d8db3  pop r8
000074fc937d8db5  pop rsi
000074fc937d8db6  pop rdi
000074fc937d8db7  pop rdx
000074fc937d8db8  pop rcx
000074fc937d8db9  pop rax
000074fc937d8dba  add rsp, 0x08
000074fc937d8dbe  jmp 0x000074FC937D616B
000074fc937d8dc3  sub rsp, 0x08
000074fc937d8dc7  push rax
000074fc937d8dc8  push rcx
000074fc937d8dc9  push rdx
000074fc937d8dca  push rdi
000074fc937d8dcb  push rsi
000074fc937d8dcc  push r8
000074fc937d8dce  push r9
000074fc937d8dd0  push r10
000074fc937d8dd2  push r11
000074fc937d8dd4  sub rsp, 0xF0
000074fc937d8ddb  vmovaps [rsp], xmm0
000074fc937d8de0  vmovaps [rsp+0x10], xmm1
000074fc937d8de6  vmovaps [rsp+0x20], xmm2
000074fc937d8dec  vmovaps [rsp+0x30], xmm3
000074fc937d8df2  vmovaps [rsp+0x40], xmm4
000074fc937d8df8  vmovaps [rsp+0x50], xmm5
000074fc937d8dfe  vmovaps [rsp+0x60], xmm6
000074fc937d8e04  vmovaps [rsp+0x70], xmm7
000074fc937d8e0a  vmovaps [rsp+0x80], xmm8
000074fc937d8e13  vmovaps [rsp+0x90], xmm10
000074fc937d8e1c  vmovaps [rsp+0xA0], xmm11
000074fc937d8e25  vmovaps [rsp+0xB0], xmm12
000074fc937d8e2e  vmovaps [rsp+0xC0], xmm13
000074fc937d8e37  vmovaps [rsp+0xD0], xmm14
000074fc937d8e40  vmovaps [rsp+0xE0], xmm15
000074fc937d8e49  sub rsp, 0x30
000074fc937d8e4d  movaps [rsp], xmm9
000074fc937d8e52  movaps [rsp+0x10], xmm2
000074fc937d8e57  movaps [rsp+0x20], xmm1
000074fc937d8e5c  lea rdi, [rsp]
000074fc937d8e60  mov esi, 0x00
000074fc937d8e65  mov rax, 0x5D72CBC20530
000074fc937d8e6f  call rax
000074fc937d8e71  movaps xmm9, [rsp]
000074fc937d8e76  add rsp, 0x30
000074fc937d8e7a  vmovaps xmm0, [rsp]
000074fc937d8e7f  vmovaps xmm1, [rsp+0x10]
000074fc937d8e85  vmovaps xmm2, [rsp+0x20]
000074fc937d8e8b  vmovaps xmm3, [rsp+0x30]
000074fc937d8e91  vmovaps xmm4, [rsp+0x40]
000074fc937d8e97  vmovaps xmm5, [rsp+0x50]
000074fc937d8e9d  vmovaps xmm6, [rsp+0x60]
000074fc937d8ea3  vmovaps xmm7, [rsp+0x70]
000074fc937d8ea9  vmovaps xmm8, [rsp+0x80]
000074fc937d8eb2  vmovaps xmm10, [rsp+0x90]
000074fc937d8ebb  vmovaps xmm11, [rsp+0xA0]
000074fc937d8ec4  vmovaps xmm12, [rsp+0xB0]
000074fc937d8ecd  vmovaps xmm13, [rsp+0xC0]
000074fc937d8ed6  vmovaps xmm14, [rsp+0xD0]
000074fc937d8edf  vmovaps xmm15, [rsp+0xE0]
000074fc937d8ee8  add rsp, 0xF0
000074fc937d8eef  pop r11
000074fc937d8ef1  pop r10
000074fc937d8ef3  pop r9
000074fc937d8ef5  pop r8
000074fc937d8ef7  pop rsi
000074fc937d8ef8  pop rdi
000074fc937d8ef9  pop rdx
000074fc937d8efa  pop rcx
000074fc937d8efb  pop rax
000074fc937d8efc  add rsp, 0x08
000074fc937d8f00  jmp 0x000074FC937D61A1
000074fc937d8f05  sub rsp, 0x08
000074fc937d8f09  push rax
000074fc937d8f0a  push rcx
000074fc937d8f0b  push rdx
000074fc937d8f0c  push rdi
000074fc937d8f0d  push rsi
000074fc937d8f0e  push r8
000074fc937d8f10  push r9
000074fc937d8f12  push r10
000074fc937d8f14  push r11
000074fc937d8f16  sub rsp, 0xF0
000074fc937d8f1d  vmovaps [rsp], xmm0
000074fc937d8f22  vmovaps [rsp+0x10], xmm2
000074fc937d8f28  vmovaps [rsp+0x20], xmm3
000074fc937d8f2e  vmovaps [rsp+0x30], xmm4
000074fc937d8f34  vmovaps [rsp+0x40], xmm5
000074fc937d8f3a  vmovaps [rsp+0x50], xmm6
000074fc937d8f40  vmovaps [rsp+0x60], xmm7
000074fc937d8f46  vmovaps [rsp+0x70], xmm8
000074fc937d8f4c  vmovaps [rsp+0x80], xmm9
000074fc937d8f55  vmovaps [rsp+0x90], xmm10
000074fc937d8f5e  vmovaps [rsp+0xA0], xmm11
000074fc937d8f67  vmovaps [rsp+0xB0], xmm12
000074fc937d8f70  vmovaps [rsp+0xC0], xmm13
000074fc937d8f79  vmovaps [rsp+0xD0], xmm14
000074fc937d8f82  vmovaps [rsp+0xE0], xmm15
000074fc937d8f8b  sub rsp, 0x30
000074fc937d8f8f  movaps [rsp], xmm1
000074fc937d8f93  movaps [rsp+0x10], xmm15
000074fc937d8f99  movaps [rsp+0x20], xmm6
000074fc937d8f9e  lea rdi, [rsp]
000074fc937d8fa2  mov esi, 0x00
000074fc937d8fa7  mov rax, 0x5D72CBC20530
000074fc937d8fb1  call rax
000074fc937d8fb3  movaps xmm1, [rsp]
000074fc937d8fb7  add rsp, 0x30
000074fc937d8fbb  vmovaps xmm0, [rsp]
000074fc937d8fc0  vmovaps xmm2, [rsp+0x10]
000074fc937d8fc6  vmovaps xmm3, [rsp+0x20]
000074fc937d8fcc  vmovaps xmm4, [rsp+0x30]
000074fc937d8fd2  vmovaps xmm5, [rsp+0x40]
000074fc937d8fd8  vmovaps xmm6, [rsp+0x50]
000074fc937d8fde  vmovaps xmm7, [rsp+0x60]
000074fc937d8fe4  vmovaps xmm8, [rsp+0x70]
000074fc937d8fea  vmovaps xmm9, [rsp+0x80]
000074fc937d8ff3  vmovaps xmm10, [rsp+0x90]
000074fc937d8ffc  vmovaps xmm11, [rsp+0xA0]
000074fc937d9005  vmovaps xmm12, [rsp+0xB0]
000074fc937d900e  vmovaps xmm13, [rsp+0xC0]
000074fc937d9017  vmovaps xmm14, [rsp+0xD0]
000074fc937d9020  vmovaps xmm15, [rsp+0xE0]
000074fc937d9029  add rsp, 0xF0
000074fc937d9030  pop r11
000074fc937d9032  pop r10
000074fc937d9034  pop r9
000074fc937d9036  pop r8
000074fc937d9038  pop rsi
000074fc937d9039  pop rdi
000074fc937d903a  pop rdx
000074fc937d903b  pop rcx
000074fc937d903c  pop rax
000074fc937d903d  add rsp, 0x08
000074fc937d9041  jmp 0x000074FC937D61C2
000074fc937d9046  sub rsp, 0x08
000074fc937d904a  push rax
000074fc937d904b  push rcx
000074fc937d904c  push rdx
000074fc937d904d  push rdi
000074fc937d904e  push rsi
000074fc937d904f  push r8
000074fc937d9051  push r9
000074fc937d9053  push r10
000074fc937d9055  push r11
000074fc937d9057  sub rsp, 0xF0
000074fc937d905e  vmovaps [rsp], xmm0
000074fc937d9063  vmovaps [rsp+0x10], xmm1
000074fc937d9069  vmovaps [rsp+0x20], xmm2
000074fc937d906f  vmovaps [rsp+0x30], xmm3
000074fc937d9075  vmovaps [rsp+0x40], xmm4
000074fc937d907b  vmovaps [rsp+0x50], xmm5
000074fc937d9081  vmovaps [rsp+0x60], xmm6
000074fc937d9087  vmovaps [rsp+0x70], xmm7
000074fc937d908d  vmovaps [rsp+0x80], xmm8
000074fc937d9096  vmovaps [rsp+0x90], xmm9
000074fc937d909f  vmovaps [rsp+0xA0], xmm10
000074fc937d90a8  vmovaps [rsp+0xB0], xmm11
000074fc937d90b1  vmovaps [rsp+0xC0], xmm12
000074fc937d90ba  vmovaps [rsp+0xD0], xmm13
000074fc937d90c3  vmovaps [rsp+0xE0], xmm14
000074fc937d90cc  sub rsp, 0x30
000074fc937d90d0  movaps [rsp], xmm15
000074fc937d90d5  movaps [rsp+0x10], xmm5
000074fc937d90da  movaps [rsp+0x20], xmm3
000074fc937d90df  lea rdi, [rsp]
000074fc937d90e3  mov esi, 0x00
000074fc937d90e8  mov rax, 0x5D72CBC20530
000074fc937d90f2  call rax
000074fc937d90f4  movaps xmm15, [rsp]
000074fc937d90f9  add rsp, 0x30
000074fc937d90fd  vmovaps xmm0, [rsp]
000074fc937d9102  vmovaps xmm1, [rsp+0x10]
000074fc937d9108  vmovaps xmm2, [rsp+0x20]
000074fc937d910e  vmovaps xmm3, [rsp+0x30]
000074fc937d9114  vmovaps xmm4, [rsp+0x40]
000074fc937d911a  vmovaps xmm5, [rsp+0x50]
000074fc937d9120  vmovaps xmm6, [rsp+0x60]
000074fc937d9126  vmovaps xmm7, [rsp+0x70]
000074fc937d912c  vmovaps xmm8, [rsp+0x80]
000074fc937d9135  vmovaps xmm9, [rsp+0x90]
000074fc937d913e  vmovaps xmm10, [rsp+0xA0]
000074fc937d9147  vmovaps xmm11, [rsp+0xB0]
000074fc937d9150  vmovaps xmm12, [rsp+0xC0]
000074fc937d9159  vmovaps xmm13, [rsp+0xD0]
000074fc937d9162  vmovaps xmm14, [rsp+0xE0]
000074fc937d916b  add rsp, 0xF0
000074fc937d9172  pop r11
000074fc937d9174  pop r10
000074fc937d9176  pop r9
000074fc937d9178  pop r8
000074fc937d917a  pop rsi
000074fc937d917b  pop rdi
000074fc937d917c  pop rdx
000074fc937d917d  pop rcx
000074fc937d917e  pop rax
000074fc937d917f  add rsp, 0x08
000074fc937d9183  jmp 0x000074FC937D61DC
000074fc937d9188  sub rsp, 0x08
000074fc937d918c  push rax
000074fc937d918d  push rcx
000074fc937d918e  push rdx
000074fc937d918f  push rdi
000074fc937d9190  push rsi
000074fc937d9191  push r8
000074fc937d9193  push r9
000074fc937d9195  push r10
000074fc937d9197  push r11
000074fc937d9199  sub rsp, 0xF0
000074fc937d91a0  vmovaps [rsp], xmm0
000074fc937d91a5  vmovaps [rsp+0x10], xmm1
000074fc937d91ab  vmovaps [rsp+0x20], xmm2
000074fc937d91b1  vmovaps [rsp+0x30], xmm3
000074fc937d91b7  vmovaps [rsp+0x40], xmm4
000074fc937d91bd  vmovaps [rsp+0x50], xmm6
000074fc937d91c3  vmovaps [rsp+0x60], xmm7
000074fc937d91c9  vmovaps [rsp+0x70], xmm8
000074fc937d91cf  vmovaps [rsp+0x80], xmm9
000074fc937d91d8  vmovaps [rsp+0x90], xmm10
000074fc937d91e1  vmovaps [rsp+0xA0], xmm11
000074fc937d91ea  vmovaps [rsp+0xB0], xmm12
000074fc937d91f3  vmovaps [rsp+0xC0], xmm13
000074fc937d91fc  vmovaps [rsp+0xD0], xmm14
000074fc937d9205  vmovaps [rsp+0xE0], xmm15
000074fc937d920e  sub rsp, 0x30
000074fc937d9212  movaps [rsp], xmm5
000074fc937d9216  movaps [rsp+0x10], xmm8
000074fc937d921c  movaps [rsp+0x20], xmm6
000074fc937d9221  lea rdi, [rsp]
000074fc937d9225  mov esi, 0x00
000074fc937d922a  mov rax, 0x5D72CBC20530
000074fc937d9234  call rax
000074fc937d9236  movaps xmm5, [rsp]
000074fc937d923a  add rsp, 0x30
000074fc937d923e  vmovaps xmm0, [rsp]
000074fc937d9243  vmovaps xmm1, [rsp+0x10]
000074fc937d9249  vmovaps xmm2, [rsp+0x20]
000074fc937d924f  vmovaps xmm3, [rsp+0x30]
000074fc937d9255  vmovaps xmm4, [rsp+0x40]
000074fc937d925b  vmovaps xmm6, [rsp+0x50]
000074fc937d9261  vmovaps xmm7, [rsp+0x60]
000074fc937d9267  vmovaps xmm8, [rsp+0x70]
000074fc937d926d  vmovaps xmm9, [rsp+0x80]
000074fc937d9276  vmovaps xmm10, [rsp+0x90]
000074fc937d927f  vmovaps xmm11, [rsp+0xA0]
000074fc937d9288  vmovaps xmm12, [rsp+0xB0]
000074fc937d9291  vmovaps xmm13, [rsp+0xC0]
000074fc937d929a  vmovaps xmm14, [rsp+0xD0]
000074fc937d92a3  vmovaps xmm15, [rsp+0xE0]
000074fc937d92ac  add rsp, 0xF0
000074fc937d92b3  pop r11
000074fc937d92b5  pop r10
000074fc937d92b7  pop r9
000074fc937d92b9  pop r8
000074fc937d92bb  pop rsi
000074fc937d92bc  pop rdi
000074fc937d92bd  pop rdx
000074fc937d92be  pop rcx
000074fc937d92bf  pop rax
000074fc937d92c0  add rsp, 0x08
000074fc937d92c4  jmp 0x000074FC937D6200
000074fc937d92c9  sub rsp, 0x08
000074fc937d92cd  push rax
000074fc937d92ce  push rcx
000074fc937d92cf  push rdx
000074fc937d92d0  push rdi
000074fc937d92d1  push rsi
000074fc937d92d2  push r8
000074fc937d92d4  push r9
000074fc937d92d6  push r10
000074fc937d92d8  push r11
000074fc937d92da  sub rsp, 0xF0
000074fc937d92e1  vmovaps [rsp], xmm0
000074fc937d92e6  vmovaps [rsp+0x10], xmm1
000074fc937d92ec  vmovaps [rsp+0x20], xmm2
000074fc937d92f2  vmovaps [rsp+0x30], xmm3
000074fc937d92f8  vmovaps [rsp+0x40], xmm4
000074fc937d92fe  vmovaps [rsp+0x50], xmm5
000074fc937d9304  vmovaps [rsp+0x60], xmm7
000074fc937d930a  vmovaps [rsp+0x70], xmm8
000074fc937d9310  vmovaps [rsp+0x80], xmm9
000074fc937d9319  vmovaps [rsp+0x90], xmm10
000074fc937d9322  vmovaps [rsp+0xA0], xmm11
000074fc937d932b  vmovaps [rsp+0xB0], xmm12
000074fc937d9334  vmovaps [rsp+0xC0], xmm13
000074fc937d933d  vmovaps [rsp+0xD0], xmm14
000074fc937d9346  vmovaps [rsp+0xE0], xmm15
000074fc937d934f  sub rsp, 0x30
000074fc937d9353  movaps [rsp], xmm6
000074fc937d9357  movaps [rsp+0x10], xmm10
000074fc937d935d  movaps [rsp+0x20], xmm8
000074fc937d9363  lea rdi, [rsp]
000074fc937d9367  mov esi, 0x00
000074fc937d936c  mov rax, 0x5D72CBC20530
000074fc937d9376  call rax
000074fc937d9378  movaps xmm6, [rsp]
000074fc937d937c  add rsp, 0x30
000074fc937d9380  vmovaps xmm0, [rsp]
000074fc937d9385  vmovaps xmm1, [rsp+0x10]
000074fc937d938b  vmovaps xmm2, [rsp+0x20]
000074fc937d9391  vmovaps xmm3, [rsp+0x30]
000074fc937d9397  vmovaps xmm4, [rsp+0x40]
000074fc937d939d  vmovaps xmm5, [rsp+0x50]
000074fc937d93a3  vmovaps xmm7, [rsp+0x60]
000074fc937d93a9  vmovaps xmm8, [rsp+0x70]
000074fc937d93af  vmovaps xmm9, [rsp+0x80]
000074fc937d93b8  vmovaps xmm10, [rsp+0x90]
000074fc937d93c1  vmovaps xmm11, [rsp+0xA0]
000074fc937d93ca  vmovaps xmm12, [rsp+0xB0]
000074fc937d93d3  vmovaps xmm13, [rsp+0xC0]
000074fc937d93dc  vmovaps xmm14, [rsp+0xD0]
000074fc937d93e5  vmovaps xmm15, [rsp+0xE0]
000074fc937d93ee  add rsp, 0xF0
000074fc937d93f5  pop r11
000074fc937d93f7  pop r10
000074fc937d93f9  pop r9
000074fc937d93fb  pop r8
000074fc937d93fd  pop rsi
000074fc937d93fe  pop rdi
000074fc937d93ff  pop rdx
000074fc937d9400  pop rcx
000074fc937d9401  pop rax
000074fc937d9402  add rsp, 0x08
000074fc937d9406  jmp 0x000074FC937D6225
000074fc937d940b  sub rsp, 0x08
000074fc937d940f  push rax
000074fc937d9410  push rcx
000074fc937d9411  push rdx
000074fc937d9412  push rdi
000074fc937d9413  push rsi
000074fc937d9414  push r8
000074fc937d9416  push r9
000074fc937d9418  push r10
000074fc937d941a  push r11
000074fc937d941c  sub rsp, 0xF0
000074fc937d9423  vmovaps [rsp], xmm0
000074fc937d9428  vmovaps [rsp+0x10], xmm1
000074fc937d942e  vmovaps [rsp+0x20], xmm2
000074fc937d9434  vmovaps [rsp+0x30], xmm3
000074fc937d943a  vmovaps [rsp+0x40], xmm4
000074fc937d9440  vmovaps [rsp+0x50], xmm5
000074fc937d9446  vmovaps [rsp+0x60], xmm6
000074fc937d944c  vmovaps [rsp+0x70], xmm7
000074fc937d9452  vmovaps [rsp+0x80], xmm8
000074fc937d945b  vmovaps [rsp+0x90], xmm9
000074fc937d9464  vmovaps [rsp+0xA0], xmm11
000074fc937d946d  vmovaps [rsp+0xB0], xmm12
000074fc937d9476  vmovaps [rsp+0xC0], xmm13
000074fc937d947f  vmovaps [rsp+0xD0], xmm14
000074fc937d9488  vmovaps [rsp+0xE0], xmm15
000074fc937d9491  sub rsp, 0x30
000074fc937d9495  movaps [rsp], xmm10
000074fc937d949a  movaps [rsp+0x10], xmm8
000074fc937d94a0  movaps [rsp+0x20], xmm14
000074fc937d94a6  lea rdi, [rsp]
000074fc937d94aa  mov esi, 0x00
000074fc937d94af  mov rax, 0x5D72CBC20530
000074fc937d94b9  call rax
000074fc937d94bb  movaps xmm10, [rsp]
000074fc937d94c0  add rsp, 0x30
000074fc937d94c4  vmovaps xmm0, [rsp]
000074fc937d94c9  vmovaps xmm1, [rsp+0x10]
000074fc937d94cf  vmovaps xmm2, [rsp+0x20]
000074fc937d94d5  vmovaps xmm3, [rsp+0x30]
000074fc937d94db  vmovaps xmm4, [rsp+0x40]
000074fc937d94e1  vmovaps xmm5, [rsp+0x50]
000074fc937d94e7  vmovaps xmm6, [rsp+0x60]
000074fc937d94ed  vmovaps xmm7, [rsp+0x70]
000074fc937d94f3  vmovaps xmm8, [rsp+0x80]
000074fc937d94fc  vmovaps xmm9, [rsp+0x90]
000074fc937d9505  vmovaps xmm11, [rsp+0xA0]
000074fc937d950e  vmovaps xmm12, [rsp+0xB0]
000074fc937d9517  vmovaps xmm13, [rsp+0xC0]
000074fc937d9520  vmovaps xmm14, [rsp+0xD0]
000074fc937d9529  vmovaps xmm15, [rsp+0xE0]
000074fc937d9532  add rsp, 0xF0
000074fc937d9539  pop r11
000074fc937d953b  pop r10
000074fc937d953d  pop r9
000074fc937d953f  pop r8
000074fc937d9541  pop rsi
000074fc937d9542  pop rdi
000074fc937d9543  pop rdx
000074fc937d9544  pop rcx
000074fc937d9545  pop rax
000074fc937d9546  add rsp, 0x08
000074fc937d954a  jmp 0x000074FC937D6245
000074fc937d954f  sub rsp, 0x08
000074fc937d9553  push rax
000074fc937d9554  push rcx
000074fc937d9555  push rdx
000074fc937d9556  push rdi
000074fc937d9557  push rsi
000074fc937d9558  push r8
000074fc937d955a  push r9
000074fc937d955c  push r10
000074fc937d955e  push r11
000074fc937d9560  sub rsp, 0xF0
000074fc937d9567  vmovaps [rsp], xmm0
000074fc937d956c  vmovaps [rsp+0x10], xmm1
000074fc937d9572  vmovaps [rsp+0x20], xmm2
000074fc937d9578  vmovaps [rsp+0x30], xmm3
000074fc937d957e  vmovaps [rsp+0x40], xmm4
000074fc937d9584  vmovaps [rsp+0x50], xmm5
000074fc937d958a  vmovaps [rsp+0x60], xmm6
000074fc937d9590  vmovaps [rsp+0x70], xmm7
000074fc937d9596  vmovaps [rsp+0x80], xmm8
000074fc937d959f  vmovaps [rsp+0x90], xmm9
000074fc937d95a8  vmovaps [rsp+0xA0], xmm10
000074fc937d95b1  vmovaps [rsp+0xB0], xmm11
000074fc937d95ba  vmovaps [rsp+0xC0], xmm12
000074fc937d95c3  vmovaps [rsp+0xD0], xmm13
000074fc937d95cc  vmovaps [rsp+0xE0], xmm15
000074fc937d95d5  sub rsp, 0x30
000074fc937d95d9  movaps [rsp], xmm14
000074fc937d95de  movaps [rsp+0x10], xmm8
000074fc937d95e4  movaps [rsp+0x20], xmm4
000074fc937d95e9  lea rdi, [rsp]
000074fc937d95ed  mov esi, 0x00
000074fc937d95f2  mov rax, 0x5D72CBC20530
000074fc937d95fc  call rax
000074fc937d95fe  movaps xmm14, [rsp]
000074fc937d9603  add rsp, 0x30
000074fc937d9607  vmovaps xmm0, [rsp]
000074fc937d960c  vmovaps xmm1, [rsp+0x10]
000074fc937d9612  vmovaps xmm2, [rsp+0x20]
000074fc937d9618  vmovaps xmm3, [rsp+0x30]
000074fc937d961e  vmovaps xmm4, [rsp+0x40]
000074fc937d9624  vmovaps xmm5, [rsp+0x50]
000074fc937d962a  vmovaps xmm6, [rsp+0x60]
000074fc937d9630  vmovaps xmm7, [rsp+0x70]
000074fc937d9636  vmovaps xmm8, [rsp+0x80]
000074fc937d963f  vmovaps xmm9, [rsp+0x90]
000074fc937d9648  vmovaps xmm10, [rsp+0xA0]
000074fc937d9651  vmovaps xmm11, [rsp+0xB0]
000074fc937d965a  vmovaps xmm12, [rsp+0xC0]
000074fc937d9663  vmovaps xmm13, [rsp+0xD0]
000074fc937d966c  vmovaps xmm15, [rsp+0xE0]
000074fc937d9675  add rsp, 0xF0
000074fc937d967c  pop r11
000074fc937d967e  pop r10
000074fc937d9680  pop r9
000074fc937d9682  pop r8
000074fc937d9684  pop rsi
000074fc937d9685  pop rdi
000074fc937d9686  pop rdx
000074fc937d9687  pop rcx
000074fc937d9688  pop rax
000074fc937d9689  add rsp, 0x08
000074fc937d968d  jmp 0x000074FC937D6265
000074fc937d9692  sub rsp, 0x08
000074fc937d9696  push rax
000074fc937d9697  push rcx
000074fc937d9698  push rdx
000074fc937d9699  push rdi
000074fc937d969a  push rsi
000074fc937d969b  push r8
000074fc937d969d  push r9
000074fc937d969f  push r10
000074fc937d96a1  push r11
000074fc937d96a3  sub rsp, 0xF0
000074fc937d96aa  vmovaps [rsp], xmm0
000074fc937d96af  vmovaps [rsp+0x10], xmm1
000074fc937d96b5  vmovaps [rsp+0x20], xmm2
000074fc937d96bb  vmovaps [rsp+0x30], xmm3
000074fc937d96c1  vmovaps [rsp+0x40], xmm5
000074fc937d96c7  vmovaps [rsp+0x50], xmm6
000074fc937d96cd  vmovaps [rsp+0x60], xmm7
000074fc937d96d3  vmovaps [rsp+0x70], xmm8
000074fc937d96d9  vmovaps [rsp+0x80], xmm9
000074fc937d96e2  vmovaps [rsp+0x90], xmm10
000074fc937d96eb  vmovaps [rsp+0xA0], xmm11
000074fc937d96f4  vmovaps [rsp+0xB0], xmm12
000074fc937d96fd  vmovaps [rsp+0xC0], xmm13
000074fc937d9706  vmovaps [rsp+0xD0], xmm14
000074fc937d970f  vmovaps [rsp+0xE0], xmm15
000074fc937d9718  sub rsp, 0x30
000074fc937d971c  movaps [rsp], xmm4
000074fc937d9720  movaps [rsp+0x10], xmm13
000074fc937d9726  movaps [rsp+0x20], xmm8
000074fc937d972c  lea rdi, [rsp]
000074fc937d9730  mov esi, 0x00
000074fc937d9735  mov rax, 0x5D72CBC20530
000074fc937d973f  call rax
000074fc937d9741  movaps xmm4, [rsp]
000074fc937d9745  add rsp, 0x30
000074fc937d9749  vmovaps xmm0, [rsp]
000074fc937d974e  vmovaps xmm1, [rsp+0x10]
000074fc937d9754  vmovaps xmm2, [rsp+0x20]
000074fc937d975a  vmovaps xmm3, [rsp+0x30]
000074fc937d9760  vmovaps xmm5, [rsp+0x40]
000074fc937d9766  vmovaps xmm6, [rsp+0x50]
000074fc937d976c  vmovaps xmm7, [rsp+0x60]
000074fc937d9772  vmovaps xmm8, [rsp+0x70]
000074fc937d9778  vmovaps xmm9, [rsp+0x80]
000074fc937d9781  vmovaps xmm10, [rsp+0x90]
000074fc937d978a  vmovaps xmm11, [rsp+0xA0]
000074fc937d9793  vmovaps xmm12, [rsp+0xB0]
000074fc937d979c  vmovaps xmm13, [rsp+0xC0]
000074fc937d97a5  vmovaps xmm14, [rsp+0xD0]
000074fc937d97ae  vmovaps xmm15, [rsp+0xE0]
000074fc937d97b7  add rsp, 0xF0
000074fc937d97be  pop r11
000074fc937d97c0  pop r10
000074fc937d97c2  pop r9
000074fc937d97c4  pop r8
000074fc937d97c6  pop rsi
000074fc937d97c7  pop rdi
000074fc937d97c8  pop rdx
000074fc937d97c9  pop rcx
000074fc937d97ca  pop rax
000074fc937d97cb  add rsp, 0x08
000074fc937d97cf  jmp 0x000074FC937D628A
000074fc937d97d4  sub rsp, 0x08
000074fc937d97d8  push rax
000074fc937d97d9  push rcx
000074fc937d97da  push rdx
000074fc937d97db  push rdi
000074fc937d97dc  push rsi
000074fc937d97dd  push r8
000074fc937d97df  push r9
000074fc937d97e1  push r10
000074fc937d97e3  push r11
000074fc937d97e5  sub rsp, 0xF0
000074fc937d97ec  vmovaps [rsp], xmm0
000074fc937d97f1  vmovaps [rsp+0x10], xmm1
000074fc937d97f7  vmovaps [rsp+0x20], xmm2
000074fc937d97fd  vmovaps [rsp+0x30], xmm3
000074fc937d9803  vmovaps [rsp+0x40], xmm4
000074fc937d9809  vmovaps [rsp+0x50], xmm5
000074fc937d980f  vmovaps [rsp+0x60], xmm6
000074fc937d9815  vmovaps [rsp+0x70], xmm7
000074fc937d981b  vmovaps [rsp+0x80], xmm8
000074fc937d9824  vmovaps [rsp+0x90], xmm9
000074fc937d982d  vmovaps [rsp+0xA0], xmm10
000074fc937d9836  vmovaps [rsp+0xB0], xmm11
000074fc937d983f  vmovaps [rsp+0xC0], xmm12
000074fc937d9848  vmovaps [rsp+0xD0], xmm14
000074fc937d9851  vmovaps [rsp+0xE0], xmm15
000074fc937d985a  sub rsp, 0x30
000074fc937d985e  movaps [rsp], xmm13
000074fc937d9863  movaps [rsp+0x10], xmm15
000074fc937d9869  movaps [rsp+0x20], xmm9
000074fc937d986f  lea rdi, [rsp]
000074fc937d9873  mov esi, 0x00
000074fc937d9878  mov rax, 0x5D72CBC20530
000074fc937d9882  call rax
000074fc937d9884  movaps xmm13, [rsp]
000074fc937d9889  add rsp, 0x30
000074fc937d988d  vmovaps xmm0, [rsp]
000074fc937d9892  vmovaps xmm1, [rsp+0x10]
000074fc937d9898  vmovaps xmm2, [rsp+0x20]
000074fc937d989e  vmovaps xmm3, [rsp+0x30]
000074fc937d98a4  vmovaps xmm4, [rsp+0x40]
000074fc937d98aa  vmovaps xmm5, [rsp+0x50]
000074fc937d98b0  vmovaps xmm6, [rsp+0x60]
000074fc937d98b6  vmovaps xmm7, [rsp+0x70]
000074fc937d98bc  vmovaps xmm8, [rsp+0x80]
000074fc937d98c5  vmovaps xmm9, [rsp+0x90]
000074fc937d98ce  vmovaps xmm10, [rsp+0xA0]
000074fc937d98d7  vmovaps xmm11, [rsp+0xB0]
000074fc937d98e0  vmovaps xmm12, [rsp+0xC0]
000074fc937d98e9  vmovaps xmm14, [rsp+0xD0]
000074fc937d98f2  vmovaps xmm15, [rsp+0xE0]
000074fc937d98fb  add rsp, 0xF0
000074fc937d9902  pop r11
000074fc937d9904  pop r10
000074fc937d9906  pop r9
000074fc937d9908  pop r8
000074fc937d990a  pop rsi
000074fc937d990b  pop rdi
000074fc937d990c  pop rdx
000074fc937d990d  pop rcx
000074fc937d990e  pop rax
000074fc937d990f  add rsp, 0x08
000074fc937d9913  jmp 0x000074FC937D62A5
000074fc937d9918  sub rsp, 0x08
000074fc937d991c  push rax
000074fc937d991d  push rcx
000074fc937d991e  push rdx
000074fc937d991f  push rdi
000074fc937d9920  push rsi
000074fc937d9921  push r8
000074fc937d9923  push r9
000074fc937d9925  push r10
000074fc937d9927  push r11
000074fc937d9929  sub rsp, 0xF0
000074fc937d9930  vmovaps [rsp], xmm0
000074fc937d9935  vmovaps [rsp+0x10], xmm1
000074fc937d993b  vmovaps [rsp+0x20], xmm2
000074fc937d9941  vmovaps [rsp+0x30], xmm3
000074fc937d9947  vmovaps [rsp+0x40], xmm4
000074fc937d994d  vmovaps [rsp+0x50], xmm5
000074fc937d9953  vmovaps [rsp+0x60], xmm6
000074fc937d9959  vmovaps [rsp+0x70], xmm7
000074fc937d995f  vmovaps [rsp+0x80], xmm8
000074fc937d9968  vmovaps [rsp+0x90], xmm9
000074fc937d9971  vmovaps [rsp+0xA0], xmm10
000074fc937d997a  vmovaps [rsp+0xB0], xmm11
000074fc937d9983  vmovaps [rsp+0xC0], xmm12
000074fc937d998c  vmovaps [rsp+0xD0], xmm13
000074fc937d9995  vmovaps [rsp+0xE0], xmm14
000074fc937d999e  sub rsp, 0x30
000074fc937d99a2  movaps [rsp], xmm15
000074fc937d99a7  movaps [rsp+0x10], xmm1
000074fc937d99ac  movaps [rsp+0x20], xmm5
000074fc937d99b1  lea rdi, [rsp]
000074fc937d99b5  mov esi, 0x00
000074fc937d99ba  mov rax, 0x5D72CBC20530
000074fc937d99c4  call rax
000074fc937d99c6  movaps xmm15, [rsp]
000074fc937d99cb  add rsp, 0x30
000074fc937d99cf  vmovaps xmm0, [rsp]
000074fc937d99d4  vmovaps xmm1, [rsp+0x10]
000074fc937d99da  vmovaps xmm2, [rsp+0x20]
000074fc937d99e0  vmovaps xmm3, [rsp+0x30]
000074fc937d99e6  vmovaps xmm4, [rsp+0x40]
000074fc937d99ec  vmovaps xmm5, [rsp+0x50]
000074fc937d99f2  vmovaps xmm6, [rsp+0x60]
000074fc937d99f8  vmovaps xmm7, [rsp+0x70]
000074fc937d99fe  vmovaps xmm8, [rsp+0x80]
000074fc937d9a07  vmovaps xmm9, [rsp+0x90]
000074fc937d9a10  vmovaps xmm10, [rsp+0xA0]
000074fc937d9a19  vmovaps xmm11, [rsp+0xB0]
000074fc937d9a22  vmovaps xmm12, [rsp+0xC0]
000074fc937d9a2b  vmovaps xmm13, [rsp+0xD0]
000074fc937d9a34  vmovaps xmm14, [rsp+0xE0]
000074fc937d9a3d  add rsp, 0xF0
000074fc937d9a44  pop r11
000074fc937d9a46  pop r10
000074fc937d9a48  pop r9
000074fc937d9a4a  pop r8
000074fc937d9a4c  pop rsi
000074fc937d9a4d  pop rdi
000074fc937d9a4e  pop rdx
000074fc937d9a4f  pop rcx
000074fc937d9a50  pop rax
000074fc937d9a51  add rsp, 0x08
000074fc937d9a55  jmp 0x000074FC937D62C0
000074fc937d9a5a  call 0x000074FC936D64F0
000074fc937d9a5f  jmp 0x000074FC937D631B
000074fc937d9a64  sub rsp, 0x08
000074fc937d9a68  push rax
000074fc937d9a69  push rcx
000074fc937d9a6a  push rdx
000074fc937d9a6b  push rdi
000074fc937d9a6c  push rsi
000074fc937d9a6d  push r8
000074fc937d9a6f  push r9
000074fc937d9a71  push r10
000074fc937d9a73  push r11
000074fc937d9a75  sub rsp, 0xF0
000074fc937d9a7c  vmovaps [rsp], xmm0
000074fc937d9a81  vmovaps [rsp+0x10], xmm1
000074fc937d9a87  vmovaps [rsp+0x20], xmm2
000074fc937d9a8d  vmovaps [rsp+0x30], xmm3
000074fc937d9a93  vmovaps [rsp+0x40], xmm4
000074fc937d9a99  vmovaps [rsp+0x50], xmm5
000074fc937d9a9f  vmovaps [rsp+0x60], xmm6
000074fc937d9aa5  vmovaps [rsp+0x70], xmm7
000074fc937d9aab  vmovaps [rsp+0x80], xmm8
000074fc937d9ab4  vmovaps [rsp+0x90], xmm10
000074fc937d9abd  vmovaps [rsp+0xA0], xmm11
000074fc937d9ac6  vmovaps [rsp+0xB0], xmm12
000074fc937d9acf  vmovaps [rsp+0xC0], xmm13
000074fc937d9ad8  vmovaps [rsp+0xD0], xmm14
000074fc937d9ae1  vmovaps [rsp+0xE0], xmm15
000074fc937d9aea  sub rsp, 0x30
000074fc937d9aee  movaps [rsp], xmm9
000074fc937d9af3  movaps [rsp+0x10], xmm8
000074fc937d9af9  movaps [rsp+0x20], xmm11
000074fc937d9aff  lea rdi, [rsp]
000074fc937d9b03  mov esi, 0x00
000074fc937d9b08  mov rax, 0x5D72CBC20530
000074fc937d9b12  call rax
000074fc937d9b14  movaps xmm9, [rsp]
000074fc937d9b19  add rsp, 0x30
000074fc937d9b1d  vmovaps xmm0, [rsp]
000074fc937d9b22  vmovaps xmm1, [rsp+0x10]
000074fc937d9b28  vmovaps xmm2, [rsp+0x20]
000074fc937d9b2e  vmovaps xmm3, [rsp+0x30]
000074fc937d9b34  vmovaps xmm4, [rsp+0x40]
000074fc937d9b3a  vmovaps xmm5, [rsp+0x50]
000074fc937d9b40  vmovaps xmm6, [rsp+0x60]
000074fc937d9b46  vmovaps xmm7, [rsp+0x70]
000074fc937d9b4c  vmovaps xmm8, [rsp+0x80]
000074fc937d9b55  vmovaps xmm10, [rsp+0x90]
000074fc937d9b5e  vmovaps xmm11, [rsp+0xA0]
000074fc937d9b67  vmovaps xmm12, [rsp+0xB0]
000074fc937d9b70  vmovaps xmm13, [rsp+0xC0]
000074fc937d9b79  vmovaps xmm14, [rsp+0xD0]
000074fc937d9b82  vmovaps xmm15, [rsp+0xE0]
000074fc937d9b8b  add rsp, 0xF0
000074fc937d9b92  pop r11
000074fc937d9b94  pop r10
000074fc937d9b96  pop r9
000074fc937d9b98  pop r8
000074fc937d9b9a  pop rsi
000074fc937d9b9b  pop rdi
000074fc937d9b9c  pop rdx
000074fc937d9b9d  pop rcx
000074fc937d9b9e  pop rax
000074fc937d9b9f  add rsp, 0x08
000074fc937d9ba3  jmp 0x000074FC937D6352
000074fc937d9ba8  sub rsp, 0x08
000074fc937d9bac  push rax
000074fc937d9bad  push rcx
000074fc937d9bae  push rdx
000074fc937d9baf  push rdi
000074fc937d9bb0  push rsi
000074fc937d9bb1  push r8
000074fc937d9bb3  push r9
000074fc937d9bb5  push r10
000074fc937d9bb7  push r11
000074fc937d9bb9  sub rsp, 0xF0
000074fc937d9bc0  vmovaps [rsp], xmm0
000074fc937d9bc5  vmovaps [rsp+0x10], xmm1
000074fc937d9bcb  vmovaps [rsp+0x20], xmm2
000074fc937d9bd1  vmovaps [rsp+0x30], xmm3
000074fc937d9bd7  vmovaps [rsp+0x40], xmm4
000074fc937d9bdd  vmovaps [rsp+0x50], xmm5
000074fc937d9be3  vmovaps [rsp+0x60], xmm6
000074fc937d9be9  vmovaps [rsp+0x70], xmm7
000074fc937d9bef  vmovaps [rsp+0x80], xmm8
000074fc937d9bf8  vmovaps [rsp+0x90], xmm9
000074fc937d9c01  vmovaps [rsp+0xA0], xmm10
000074fc937d9c0a  vmovaps [rsp+0xB0], xmm12
000074fc937d9c13  vmovaps [rsp+0xC0], xmm13
000074fc937d9c1c  vmovaps [rsp+0xD0], xmm14
000074fc937d9c25  vmovaps [rsp+0xE0], xmm15
000074fc937d9c2e  sub rsp, 0x30
000074fc937d9c32  movaps [rsp], xmm11
000074fc937d9c37  movaps [rsp+0x10], xmm10
000074fc937d9c3d  movaps [rsp+0x20], xmm6
000074fc937d9c42  lea rdi, [rsp]
000074fc937d9c46  mov esi, 0x00
000074fc937d9c4b  mov rax, 0x5D72CBC20530
000074fc937d9c55  call rax
000074fc937d9c57  movaps xmm11, [rsp]
000074fc937d9c5c  add rsp, 0x30
000074fc937d9c60  vmovaps xmm0, [rsp]
000074fc937d9c65  vmovaps xmm1, [rsp+0x10]
000074fc937d9c6b  vmovaps xmm2, [rsp+0x20]
000074fc937d9c71  vmovaps xmm3, [rsp+0x30]
000074fc937d9c77  vmovaps xmm4, [rsp+0x40]
000074fc937d9c7d  vmovaps xmm5, [rsp+0x50]
000074fc937d9c83  vmovaps xmm6, [rsp+0x60]
000074fc937d9c89  vmovaps xmm7, [rsp+0x70]
000074fc937d9c8f  vmovaps xmm8, [rsp+0x80]
000074fc937d9c98  vmovaps xmm9, [rsp+0x90]
000074fc937d9ca1  vmovaps xmm10, [rsp+0xA0]
000074fc937d9caa  vmovaps xmm12, [rsp+0xB0]
000074fc937d9cb3  vmovaps xmm13, [rsp+0xC0]
000074fc937d9cbc  vmovaps xmm14, [rsp+0xD0]
000074fc937d9cc5  vmovaps xmm15, [rsp+0xE0]
000074fc937d9cce  add rsp, 0xF0
000074fc937d9cd5  pop r11
000074fc937d9cd7  pop r10
000074fc937d9cd9  pop r9
000074fc937d9cdb  pop r8
000074fc937d9cdd  pop rsi
000074fc937d9cde  pop rdi
000074fc937d9cdf  pop rdx
000074fc937d9ce0  pop rcx
000074fc937d9ce1  pop rax
000074fc937d9ce2  add rsp, 0x08
000074fc937d9ce6  jmp 0x000074FC937D636D
000074fc937d9ceb  sub rsp, 0x08
000074fc937d9cef  push rax
000074fc937d9cf0  push rcx
000074fc937d9cf1  push rdx
000074fc937d9cf2  push rdi
000074fc937d9cf3  push rsi
000074fc937d9cf4  push r8
000074fc937d9cf6  push r9
000074fc937d9cf8  push r10
000074fc937d9cfa  push r11
000074fc937d9cfc  sub rsp, 0xF0
000074fc937d9d03  vmovaps [rsp], xmm0
000074fc937d9d08  vmovaps [rsp+0x10], xmm1
000074fc937d9d0e  vmovaps [rsp+0x20], xmm2
000074fc937d9d14  vmovaps [rsp+0x30], xmm3
000074fc937d9d1a  vmovaps [rsp+0x40], xmm4
000074fc937d9d20  vmovaps [rsp+0x50], xmm5
000074fc937d9d26  vmovaps [rsp+0x60], xmm6
000074fc937d9d2c  vmovaps [rsp+0x70], xmm7
000074fc937d9d32  vmovaps [rsp+0x80], xmm8
000074fc937d9d3b  vmovaps [rsp+0x90], xmm9
000074fc937d9d44  vmovaps [rsp+0xA0], xmm11
000074fc937d9d4d  vmovaps [rsp+0xB0], xmm12
000074fc937d9d56  vmovaps [rsp+0xC0], xmm13
000074fc937d9d5f  vmovaps [rsp+0xD0], xmm14
000074fc937d9d68  vmovaps [rsp+0xE0], xmm15
000074fc937d9d71  sub rsp, 0x30
000074fc937d9d75  movaps [rsp], xmm10
000074fc937d9d7a  movaps [rsp+0x10], xmm14
000074fc937d9d80  movaps [rsp+0x20], xmm4
000074fc937d9d85  lea rdi, [rsp]
000074fc937d9d89  mov esi, 0x00
000074fc937d9d8e  mov rax, 0x5D72CBC20530
000074fc937d9d98  call rax
000074fc937d9d9a  movaps xmm10, [rsp]
000074fc937d9d9f  add rsp, 0x30
000074fc937d9da3  vmovaps xmm0, [rsp]
000074fc937d9da8  vmovaps xmm1, [rsp+0x10]
000074fc937d9dae  vmovaps xmm2, [rsp+0x20]
000074fc937d9db4  vmovaps xmm3, [rsp+0x30]
000074fc937d9dba  vmovaps xmm4, [rsp+0x40]
000074fc937d9dc0  vmovaps xmm5, [rsp+0x50]
000074fc937d9dc6  vmovaps xmm6, [rsp+0x60]
000074fc937d9dcc  vmovaps xmm7, [rsp+0x70]
000074fc937d9dd2  vmovaps xmm8, [rsp+0x80]
000074fc937d9ddb  vmovaps xmm9, [rsp+0x90]
000074fc937d9de4  vmovaps xmm11, [rsp+0xA0]
000074fc937d9ded  vmovaps xmm12, [rsp+0xB0]
000074fc937d9df6  vmovaps xmm13, [rsp+0xC0]
000074fc937d9dff  vmovaps xmm14, [rsp+0xD0]
000074fc937d9e08  vmovaps xmm15, [rsp+0xE0]
000074fc937d9e11  add rsp, 0xF0
000074fc937d9e18  pop r11
000074fc937d9e1a  pop r10
000074fc937d9e1c  pop r9
000074fc937d9e1e  pop r8
000074fc937d9e20  pop rsi
000074fc937d9e21  pop rdi
000074fc937d9e22  pop rdx
000074fc937d9e23  pop rcx
000074fc937d9e24  pop rax
000074fc937d9e25  add rsp, 0x08
000074fc937d9e29  jmp 0x000074FC937D6388
000074fc937d9e2e  sub rsp, 0x08
000074fc937d9e32  push rax
000074fc937d9e33  push rcx
000074fc937d9e34  push rdx
000074fc937d9e35  push rdi
000074fc937d9e36  push rsi
000074fc937d9e37  push r8
000074fc937d9e39  push r9
000074fc937d9e3b  push r10
000074fc937d9e3d  push r11
000074fc937d9e3f  sub rsp, 0xF0
000074fc937d9e46  vmovaps [rsp], xmm0
000074fc937d9e4b  vmovaps [rsp+0x10], xmm1
000074fc937d9e51  vmovaps [rsp+0x20], xmm2
000074fc937d9e57  vmovaps [rsp+0x30], xmm3
000074fc937d9e5d  vmovaps [rsp+0x40], xmm4
000074fc937d9e63  vmovaps [rsp+0x50], xmm5
000074fc937d9e69  vmovaps [rsp+0x60], xmm6
000074fc937d9e6f  vmovaps [rsp+0x70], xmm7
000074fc937d9e75  vmovaps [rsp+0x80], xmm9
000074fc937d9e7e  vmovaps [rsp+0x90], xmm10
000074fc937d9e87  vmovaps [rsp+0xA0], xmm11
000074fc937d9e90  vmovaps [rsp+0xB0], xmm12
000074fc937d9e99  vmovaps [rsp+0xC0], xmm13
000074fc937d9ea2  vmovaps [rsp+0xD0], xmm14
000074fc937d9eab  vmovaps [rsp+0xE0], xmm15
000074fc937d9eb4  sub rsp, 0x30
000074fc937d9eb8  movaps [rsp], xmm8
000074fc937d9ebd  movaps [rsp+0x10], xmm1
000074fc937d9ec2  movaps [rsp+0x20], xmm14
000074fc937d9ec8  lea rdi, [rsp]
000074fc937d9ecc  mov esi, 0x00
000074fc937d9ed1  mov rax, 0x5D72CBC20530
000074fc937d9edb  call rax
000074fc937d9edd  movaps xmm8, [rsp]
000074fc937d9ee2  add rsp, 0x30
000074fc937d9ee6  vmovaps xmm0, [rsp]
000074fc937d9eeb  vmovaps xmm1, [rsp+0x10]
000074fc937d9ef1  vmovaps xmm2, [rsp+0x20]
000074fc937d9ef7  vmovaps xmm3, [rsp+0x30]
000074fc937d9efd  vmovaps xmm4, [rsp+0x40]
000074fc937d9f03  vmovaps xmm5, [rsp+0x50]
000074fc937d9f09  vmovaps xmm6, [rsp+0x60]
000074fc937d9f0f  vmovaps xmm7, [rsp+0x70]
000074fc937d9f15  vmovaps xmm9, [rsp+0x80]
000074fc937d9f1e  vmovaps xmm10, [rsp+0x90]
000074fc937d9f27  vmovaps xmm11, [rsp+0xA0]
000074fc937d9f30  vmovaps xmm12, [rsp+0xB0]
000074fc937d9f39  vmovaps xmm13, [rsp+0xC0]
000074fc937d9f42  vmovaps xmm14, [rsp+0xD0]
000074fc937d9f4b  vmovaps xmm15, [rsp+0xE0]
000074fc937d9f54  add rsp, 0xF0
000074fc937d9f5b  pop r11
000074fc937d9f5d  pop r10
000074fc937d9f5f  pop r9
000074fc937d9f61  pop r8
000074fc937d9f63  pop rsi
000074fc937d9f64  pop rdi
000074fc937d9f65  pop rdx
000074fc937d9f66  pop rcx
000074fc937d9f67  pop rax
000074fc937d9f68  add rsp, 0x08
000074fc937d9f6c  jmp 0x000074FC937D63AE
000074fc937d9f71  sub rsp, 0x08
000074fc937d9f75  push rax
000074fc937d9f76  push rcx
000074fc937d9f77  push rdx
000074fc937d9f78  push rdi
000074fc937d9f79  push rsi
000074fc937d9f7a  push r8
000074fc937d9f7c  push r9
000074fc937d9f7e  push r10
000074fc937d9f80  push r11
000074fc937d9f82  sub rsp, 0xF0
000074fc937d9f89  vmovaps [rsp], xmm0
000074fc937d9f8e  vmovaps [rsp+0x10], xmm1
000074fc937d9f94  vmovaps [rsp+0x20], xmm2
000074fc937d9f9a  vmovaps [rsp+0x30], xmm3
000074fc937d9fa0  vmovaps [rsp+0x40], xmm4
000074fc937d9fa6  vmovaps [rsp+0x50], xmm5
000074fc937d9fac  vmovaps [rsp+0x60], xmm7
000074fc937d9fb2  vmovaps [rsp+0x70], xmm8
000074fc937d9fb8  vmovaps [rsp+0x80], xmm9
000074fc937d9fc1  vmovaps [rsp+0x90], xmm10
000074fc937d9fca  vmovaps [rsp+0xA0], xmm11
000074fc937d9fd3  vmovaps [rsp+0xB0], xmm12
000074fc937d9fdc  vmovaps [rsp+0xC0], xmm13
000074fc937d9fe5  vmovaps [rsp+0xD0], xmm14
000074fc937d9fee  vmovaps [rsp+0xE0], xmm15
000074fc937d9ff7  sub rsp, 0x30
000074fc937d9ffb  movaps [rsp], xmm6
000074fc937d9fff  movaps [rsp+0x10], xmm1
000074fc937da004  movaps [rsp+0x20], xmm14
000074fc937da00a  lea rdi, [rsp]
000074fc937da00e  mov esi, 0x00
000074fc937da013  mov rax, 0x5D72CBC20530
000074fc937da01d  call rax
000074fc937da01f  movaps xmm6, [rsp]
000074fc937da023  add rsp, 0x30
000074fc937da027  vmovaps xmm0, [rsp]
000074fc937da02c  vmovaps xmm1, [rsp+0x10]
000074fc937da032  vmovaps xmm2, [rsp+0x20]
000074fc937da038  vmovaps xmm3, [rsp+0x30]
000074fc937da03e  vmovaps xmm4, [rsp+0x40]
000074fc937da044  vmovaps xmm5, [rsp+0x50]
000074fc937da04a  vmovaps xmm7, [rsp+0x60]
000074fc937da050  vmovaps xmm8, [rsp+0x70]
000074fc937da056  vmovaps xmm9, [rsp+0x80]
000074fc937da05f  vmovaps xmm10, [rsp+0x90]
000074fc937da068  vmovaps xmm11, [rsp+0xA0]
000074fc937da071  vmovaps xmm12, [rsp+0xB0]
000074fc937da07a  vmovaps xmm13, [rsp+0xC0]
000074fc937da083  vmovaps xmm14, [rsp+0xD0]
000074fc937da08c  vmovaps xmm15, [rsp+0xE0]
000074fc937da095  add rsp, 0xF0
000074fc937da09c  pop r11
000074fc937da09e  pop r10
000074fc937da0a0  pop r9
000074fc937da0a2  pop r8
000074fc937da0a4  pop rsi
000074fc937da0a5  pop rdi
000074fc937da0a6  pop rdx
000074fc937da0a7  pop rcx
000074fc937da0a8  pop rax
000074fc937da0a9  add rsp, 0x08
000074fc937da0ad  jmp 0x000074FC937D63DA
000074fc937da0b2  sub rsp, 0x08
000074fc937da0b6  push rax
000074fc937da0b7  push rcx
000074fc937da0b8  push rdx
000074fc937da0b9  push rdi
000074fc937da0ba  push rsi
000074fc937da0bb  push r8
000074fc937da0bd  push r9
000074fc937da0bf  push r10
000074fc937da0c1  push r11
000074fc937da0c3  sub rsp, 0xF0
000074fc937da0ca  vmovaps [rsp], xmm0
000074fc937da0cf  vmovaps [rsp+0x10], xmm1
000074fc937da0d5  vmovaps [rsp+0x20], xmm2
000074fc937da0db  vmovaps [rsp+0x30], xmm3
000074fc937da0e1  vmovaps [rsp+0x40], xmm4
000074fc937da0e7  vmovaps [rsp+0x50], xmm5
000074fc937da0ed  vmovaps [rsp+0x60], xmm6
000074fc937da0f3  vmovaps [rsp+0x70], xmm7
000074fc937da0f9  vmovaps [rsp+0x80], xmm8
000074fc937da102  vmovaps [rsp+0x90], xmm9
000074fc937da10b  vmovaps [rsp+0xA0], xmm10
000074fc937da114  vmovaps [rsp+0xB0], xmm11
000074fc937da11d  vmovaps [rsp+0xC0], xmm12
000074fc937da126  vmovaps [rsp+0xD0], xmm13
000074fc937da12f  vmovaps [rsp+0xE0], xmm15
000074fc937da138  sub rsp, 0x30
000074fc937da13c  movaps [rsp], xmm14
000074fc937da141  movaps [rsp+0x10], xmm12
000074fc937da147  movaps [rsp+0x20], xmm1
000074fc937da14c  lea rdi, [rsp]
000074fc937da150  mov esi, 0x00
000074fc937da155  mov rax, 0x5D72CBC20530
000074fc937da15f  call rax
000074fc937da161  movaps xmm14, [rsp]
000074fc937da166  add rsp, 0x30
000074fc937da16a  vmovaps xmm0, [rsp]
000074fc937da16f  vmovaps xmm1, [rsp+0x10]
000074fc937da175  vmovaps xmm2, [rsp+0x20]
000074fc937da17b  vmovaps xmm3, [rsp+0x30]
000074fc937da181  vmovaps xmm4, [rsp+0x40]
000074fc937da187  vmovaps xmm5, [rsp+0x50]
000074fc937da18d  vmovaps xmm6, [rsp+0x60]
000074fc937da193  vmovaps xmm7, [rsp+0x70]
000074fc937da199  vmovaps xmm8, [rsp+0x80]
000074fc937da1a2  vmovaps xmm9, [rsp+0x90]
000074fc937da1ab  vmovaps xmm10, [rsp+0xA0]
000074fc937da1b4  vmovaps xmm11, [rsp+0xB0]
000074fc937da1bd  vmovaps xmm12, [rsp+0xC0]
000074fc937da1c6  vmovaps xmm13, [rsp+0xD0]
000074fc937da1cf  vmovaps xmm15, [rsp+0xE0]
000074fc937da1d8  add rsp, 0xF0
000074fc937da1df  pop r11
000074fc937da1e1  pop r10
000074fc937da1e3  pop r9
000074fc937da1e5  pop r8
000074fc937da1e7  pop rsi
000074fc937da1e8  pop rdi
000074fc937da1e9  pop rdx
000074fc937da1ea  pop rcx
000074fc937da1eb  pop rax
000074fc937da1ec  add rsp, 0x08
000074fc937da1f0  jmp 0x000074FC937D6400
000074fc937da1f5  sub rsp, 0x08
000074fc937da1f9  push rax
000074fc937da1fa  push rcx
000074fc937da1fb  push rdx
000074fc937da1fc  push rdi
000074fc937da1fd  push rsi
000074fc937da1fe  push r8
000074fc937da200  push r9
000074fc937da202  push r10
000074fc937da204  push r11
000074fc937da206  sub rsp, 0xF0
000074fc937da20d  vmovaps [rsp], xmm0
000074fc937da212  vmovaps [rsp+0x10], xmm2
000074fc937da218  vmovaps [rsp+0x20], xmm3
000074fc937da21e  vmovaps [rsp+0x30], xmm4
000074fc937da224  vmovaps [rsp+0x40], xmm5
000074fc937da22a  vmovaps [rsp+0x50], xmm6
000074fc937da230  vmovaps [rsp+0x60], xmm7
000074fc937da236  vmovaps [rsp+0x70], xmm8
000074fc937da23c  vmovaps [rsp+0x80], xmm9
000074fc937da245  vmovaps [rsp+0x90], xmm10
000074fc937da24e  vmovaps [rsp+0xA0], xmm11
000074fc937da257  vmovaps [rsp+0xB0], xmm12
000074fc937da260  vmovaps [rsp+0xC0], xmm13
000074fc937da269  vmovaps [rsp+0xD0], xmm14
000074fc937da272  vmovaps [rsp+0xE0], xmm15
000074fc937da27b  sub rsp, 0x30
000074fc937da27f  movaps [rsp], xmm1
000074fc937da283  movaps [rsp+0x10], xmm13
000074fc937da289  movaps [rsp+0x20], xmm9
000074fc937da28f  lea rdi, [rsp]
000074fc937da293  mov esi, 0x00
000074fc937da298  mov rax, 0x5D72CBC20530
000074fc937da2a2  call rax
000074fc937da2a4  movaps xmm1, [rsp]
000074fc937da2a8  add rsp, 0x30
000074fc937da2ac  vmovaps xmm0, [rsp]
000074fc937da2b1  vmovaps xmm2, [rsp+0x10]
000074fc937da2b7  vmovaps xmm3, [rsp+0x20]
000074fc937da2bd  vmovaps xmm4, [rsp+0x30]
000074fc937da2c3  vmovaps xmm5, [rsp+0x40]
000074fc937da2c9  vmovaps xmm6, [rsp+0x50]
000074fc937da2cf  vmovaps xmm7, [rsp+0x60]
000074fc937da2d5  vmovaps xmm8, [rsp+0x70]
000074fc937da2db  vmovaps xmm9, [rsp+0x80]
000074fc937da2e4  vmovaps xmm10, [rsp+0x90]
000074fc937da2ed  vmovaps xmm11, [rsp+0xA0]
000074fc937da2f6  vmovaps xmm12, [rsp+0xB0]
000074fc937da2ff  vmovaps xmm13, [rsp+0xC0]
000074fc937da308  vmovaps xmm14, [rsp+0xD0]
000074fc937da311  vmovaps xmm15, [rsp+0xE0]
000074fc937da31a  add rsp, 0xF0
000074fc937da321  pop r11
000074fc937da323  pop r10
000074fc937da325  pop r9
000074fc937da327  pop r8
000074fc937da329  pop rsi
000074fc937da32a  pop rdi
000074fc937da32b  pop rdx
000074fc937da32c  pop rcx
000074fc937da32d  pop rax
000074fc937da32e  add rsp, 0x08
000074fc937da332  jmp 0x000074FC937D641A
000074fc937da337  sub rsp, 0x08
000074fc937da33b  push rax
000074fc937da33c  push rcx
000074fc937da33d  push rdx
000074fc937da33e  push rdi
000074fc937da33f  push rsi
000074fc937da340  push r8
000074fc937da342  push r9
000074fc937da344  push r10
000074fc937da346  push r11
000074fc937da348  sub rsp, 0xF0
000074fc937da34f  vmovaps [rsp], xmm0
000074fc937da354  vmovaps [rsp+0x10], xmm1
000074fc937da35a  vmovaps [rsp+0x20], xmm2
000074fc937da360  vmovaps [rsp+0x30], xmm3
000074fc937da366  vmovaps [rsp+0x40], xmm4
000074fc937da36c  vmovaps [rsp+0x50], xmm5
000074fc937da372  vmovaps [rsp+0x60], xmm6
000074fc937da378  vmovaps [rsp+0x70], xmm7
000074fc937da37e  vmovaps [rsp+0x80], xmm8
000074fc937da387  vmovaps [rsp+0x90], xmm9
000074fc937da390  vmovaps [rsp+0xA0], xmm10
000074fc937da399  vmovaps [rsp+0xB0], xmm11
000074fc937da3a2  vmovaps [rsp+0xC0], xmm13
000074fc937da3ab  vmovaps [rsp+0xD0], xmm14
000074fc937da3b4  vmovaps [rsp+0xE0], xmm15
000074fc937da3bd  sub rsp, 0x30
000074fc937da3c1  movaps [rsp], xmm12
000074fc937da3c6  movaps [rsp+0x10], xmm7
000074fc937da3cb  movaps [rsp+0x20], xmm13
000074fc937da3d1  lea rdi, [rsp]
000074fc937da3d5  mov esi, 0x00
000074fc937da3da  mov rax, 0x5D72CBC20530
000074fc937da3e4  call rax
000074fc937da3e6  movaps xmm12, [rsp]
000074fc937da3eb  add rsp, 0x30
000074fc937da3ef  vmovaps xmm0, [rsp]
000074fc937da3f4  vmovaps xmm1, [rsp+0x10]
000074fc937da3fa  vmovaps xmm2, [rsp+0x20]
000074fc937da400  vmovaps xmm3, [rsp+0x30]
000074fc937da406  vmovaps xmm4, [rsp+0x40]
000074fc937da40c  vmovaps xmm5, [rsp+0x50]
000074fc937da412  vmovaps xmm6, [rsp+0x60]
000074fc937da418  vmovaps xmm7, [rsp+0x70]
000074fc937da41e  vmovaps xmm8, [rsp+0x80]
000074fc937da427  vmovaps xmm9, [rsp+0x90]
000074fc937da430  vmovaps xmm10, [rsp+0xA0]
000074fc937da439  vmovaps xmm11, [rsp+0xB0]
000074fc937da442  vmovaps xmm13, [rsp+0xC0]
000074fc937da44b  vmovaps xmm14, [rsp+0xD0]
000074fc937da454  vmovaps xmm15, [rsp+0xE0]
000074fc937da45d  add rsp, 0xF0
000074fc937da464  pop r11
000074fc937da466  pop r10
000074fc937da468  pop r9
000074fc937da46a  pop r8
000074fc937da46c  pop rsi
000074fc937da46d  pop rdi
000074fc937da46e  pop rdx
000074fc937da46f  pop rcx
000074fc937da470  pop rax
000074fc937da471  add rsp, 0x08
000074fc937da475  jmp 0x000074FC937D6441
000074fc937da47a  sub rsp, 0x08
000074fc937da47e  push rax
000074fc937da47f  push rcx
000074fc937da480  push rdx
000074fc937da481  push rdi
000074fc937da482  push rsi
000074fc937da483  push r8
000074fc937da485  push r9
000074fc937da487  push r10
000074fc937da489  push r11
000074fc937da48b  sub rsp, 0xF0
000074fc937da492  vmovaps [rsp], xmm0
000074fc937da497  vmovaps [rsp+0x10], xmm1
000074fc937da49d  vmovaps [rsp+0x20], xmm2
000074fc937da4a3  vmovaps [rsp+0x30], xmm3
000074fc937da4a9  vmovaps [rsp+0x40], xmm4
000074fc937da4af  vmovaps [rsp+0x50], xmm5
000074fc937da4b5  vmovaps [rsp+0x60], xmm6
000074fc937da4bb  vmovaps [rsp+0x70], xmm7
000074fc937da4c1  vmovaps [rsp+0x80], xmm8
000074fc937da4ca  vmovaps [rsp+0x90], xmm9
000074fc937da4d3  vmovaps [rsp+0xA0], xmm10
000074fc937da4dc  vmovaps [rsp+0xB0], xmm11
000074fc937da4e5  vmovaps [rsp+0xC0], xmm12
000074fc937da4ee  vmovaps [rsp+0xD0], xmm14
000074fc937da4f7  vmovaps [rsp+0xE0], xmm15
000074fc937da500  sub rsp, 0x30
000074fc937da504  movaps [rsp], xmm13
000074fc937da509  movaps [rsp+0x10], xmm15
000074fc937da50f  movaps [rsp+0x20], xmm8
000074fc937da515  lea rdi, [rsp]
000074fc937da519  mov esi, 0x00
000074fc937da51e  mov rax, 0x5D72CBC20530
000074fc937da528  call rax
000074fc937da52a  movaps xmm13, [rsp]
000074fc937da52f  add rsp, 0x30
000074fc937da533  vmovaps xmm0, [rsp]
000074fc937da538  vmovaps xmm1, [rsp+0x10]
000074fc937da53e  vmovaps xmm2, [rsp+0x20]
000074fc937da544  vmovaps xmm3, [rsp+0x30]
000074fc937da54a  vmovaps xmm4, [rsp+0x40]
000074fc937da550  vmovaps xmm5, [rsp+0x50]
000074fc937da556  vmovaps xmm6, [rsp+0x60]
000074fc937da55c  vmovaps xmm7, [rsp+0x70]
000074fc937da562  vmovaps xmm8, [rsp+0x80]
000074fc937da56b  vmovaps xmm9, [rsp+0x90]
000074fc937da574  vmovaps xmm10, [rsp+0xA0]
000074fc937da57d  vmovaps xmm11, [rsp+0xB0]
000074fc937da586  vmovaps xmm12, [rsp+0xC0]
000074fc937da58f  vmovaps xmm14, [rsp+0xD0]
000074fc937da598  vmovaps xmm15, [rsp+0xE0]
000074fc937da5a1  add rsp, 0xF0
000074fc937da5a8  pop r11
000074fc937da5aa  pop r10
000074fc937da5ac  pop r9
000074fc937da5ae  pop r8
000074fc937da5b0  pop rsi
000074fc937da5b1  pop rdi
000074fc937da5b2  pop rdx
000074fc937da5b3  pop rcx
000074fc937da5b4  pop rax
000074fc937da5b5  add rsp, 0x08
000074fc937da5b9  jmp 0x000074FC937D645C
000074fc937da5be  sub rsp, 0x08
000074fc937da5c2  push rax
000074fc937da5c3  push rcx
000074fc937da5c4  push rdx
000074fc937da5c5  push rdi
000074fc937da5c6  push rsi
000074fc937da5c7  push r8
000074fc937da5c9  push r9
000074fc937da5cb  push r10
000074fc937da5cd  push r11
000074fc937da5cf  sub rsp, 0xF0
000074fc937da5d6  vmovaps [rsp], xmm0
000074fc937da5db  vmovaps [rsp+0x10], xmm1
000074fc937da5e1  vmovaps [rsp+0x20], xmm2
000074fc937da5e7  vmovaps [rsp+0x30], xmm3
000074fc937da5ed  vmovaps [rsp+0x40], xmm4
000074fc937da5f3  vmovaps [rsp+0x50], xmm5
000074fc937da5f9  vmovaps [rsp+0x60], xmm6
000074fc937da5ff  vmovaps [rsp+0x70], xmm7
000074fc937da605  vmovaps [rsp+0x80], xmm9
000074fc937da60e  vmovaps [rsp+0x90], xmm10
000074fc937da617  vmovaps [rsp+0xA0], xmm11
000074fc937da620  vmovaps [rsp+0xB0], xmm12
000074fc937da629  vmovaps [rsp+0xC0], xmm13
000074fc937da632  vmovaps [rsp+0xD0], xmm14
000074fc937da63b  vmovaps [rsp+0xE0], xmm15
000074fc937da644  sub rsp, 0x30
000074fc937da648  movaps [rsp], xmm8
000074fc937da64d  movaps [rsp+0x10], xmm15
000074fc937da653  movaps [rsp+0x20], xmm9
000074fc937da659  lea rdi, [rsp]
000074fc937da65d  mov esi, 0x00
000074fc937da662  mov rax, 0x5D72CBC20530
000074fc937da66c  call rax
000074fc937da66e  movaps xmm8, [rsp]
000074fc937da673  add rsp, 0x30
000074fc937da677  vmovaps xmm0, [rsp]
000074fc937da67c  vmovaps xmm1, [rsp+0x10]
000074fc937da682  vmovaps xmm2, [rsp+0x20]
000074fc937da688  vmovaps xmm3, [rsp+0x30]
000074fc937da68e  vmovaps xmm4, [rsp+0x40]
000074fc937da694  vmovaps xmm5, [rsp+0x50]
000074fc937da69a  vmovaps xmm6, [rsp+0x60]
000074fc937da6a0  vmovaps xmm7, [rsp+0x70]
000074fc937da6a6  vmovaps xmm9, [rsp+0x80]
000074fc937da6af  vmovaps xmm10, [rsp+0x90]
000074fc937da6b8  vmovaps xmm11, [rsp+0xA0]
000074fc937da6c1  vmovaps xmm12, [rsp+0xB0]
000074fc937da6ca  vmovaps xmm13, [rsp+0xC0]
000074fc937da6d3  vmovaps xmm14, [rsp+0xD0]
000074fc937da6dc  vmovaps xmm15, [rsp+0xE0]
000074fc937da6e5  add rsp, 0xF0
000074fc937da6ec  pop r11
000074fc937da6ee  pop r10
000074fc937da6f0  pop r9
000074fc937da6f2  pop r8
000074fc937da6f4  pop rsi
000074fc937da6f5  pop rdi
000074fc937da6f6  pop rdx
000074fc937da6f7  pop rcx
000074fc937da6f8  pop rax
000074fc937da6f9  add rsp, 0x08
000074fc937da6fd  jmp 0x000074FC937D648A
000074fc937da702  sub rsp, 0x08
000074fc937da706  push rax
000074fc937da707  push rcx
000074fc937da708  push rdx
000074fc937da709  push rdi
000074fc937da70a  push rsi
000074fc937da70b  push r8
000074fc937da70d  push r9
000074fc937da70f  push r10
000074fc937da711  push r11
000074fc937da713  sub rsp, 0xF0
000074fc937da71a  vmovaps [rsp], xmm0
000074fc937da71f  vmovaps [rsp+0x10], xmm1
000074fc937da725  vmovaps [rsp+0x20], xmm2
000074fc937da72b  vmovaps [rsp+0x30], xmm3
000074fc937da731  vmovaps [rsp+0x40], xmm4
000074fc937da737  vmovaps [rsp+0x50], xmm5
000074fc937da73d  vmovaps [rsp+0x60], xmm6
000074fc937da743  vmovaps [rsp+0x70], xmm7
000074fc937da749  vmovaps [rsp+0x80], xmm8
000074fc937da752  vmovaps [rsp+0x90], xmm9
000074fc937da75b  vmovaps [rsp+0xA0], xmm10
000074fc937da764  vmovaps [rsp+0xB0], xmm11
000074fc937da76d  vmovaps [rsp+0xC0], xmm12
000074fc937da776  vmovaps [rsp+0xD0], xmm13
000074fc937da77f  vmovaps [rsp+0xE0], xmm14
000074fc937da788  sub rsp, 0x30
000074fc937da78c  movaps [rsp], xmm15
000074fc937da791  movaps [rsp+0x10], xmm11
000074fc937da797  movaps [rsp+0x20], xmm6
000074fc937da79c  lea rdi, [rsp]
000074fc937da7a0  mov esi, 0x00
000074fc937da7a5  mov rax, 0x5D72CBC20530
000074fc937da7af  call rax
000074fc937da7b1  movaps xmm15, [rsp]
000074fc937da7b6  add rsp, 0x30
000074fc937da7ba  vmovaps xmm0, [rsp]
000074fc937da7bf  vmovaps xmm1, [rsp+0x10]
000074fc937da7c5  vmovaps xmm2, [rsp+0x20]
000074fc937da7cb  vmovaps xmm3, [rsp+0x30]
000074fc937da7d1  vmovaps xmm4, [rsp+0x40]
000074fc937da7d7  vmovaps xmm5, [rsp+0x50]
000074fc937da7dd  vmovaps xmm6, [rsp+0x60]
000074fc937da7e3  vmovaps xmm7, [rsp+0x70]
000074fc937da7e9  vmovaps xmm8, [rsp+0x80]
000074fc937da7f2  vmovaps xmm9, [rsp+0x90]
000074fc937da7fb  vmovaps xmm10, [rsp+0xA0]
000074fc937da804  vmovaps xmm11, [rsp+0xB0]
000074fc937da80d  vmovaps xmm12, [rsp+0xC0]
000074fc937da816  vmovaps xmm13, [rsp+0xD0]
000074fc937da81f  vmovaps xmm14, [rsp+0xE0]
000074fc937da828  add rsp, 0xF0
000074fc937da82f  pop r11
000074fc937da831  pop r10
000074fc937da833  pop r9
000074fc937da835  pop r8
000074fc937da837  pop rsi
000074fc937da838  pop rdi
000074fc937da839  pop rdx
000074fc937da83a  pop rcx
000074fc937da83b  pop rax
000074fc937da83c  add rsp, 0x08
000074fc937da840  jmp 0x000074FC937D64A5
000074fc937da845  sub rsp, 0x08
000074fc937da849  push rax
000074fc937da84a  push rcx
000074fc937da84b  push rdx
000074fc937da84c  push rdi
000074fc937da84d  push rsi
000074fc937da84e  push r8
000074fc937da850  push r9
000074fc937da852  push r10
000074fc937da854  push r11
000074fc937da856  sub rsp, 0xF0
000074fc937da85d  vmovaps [rsp], xmm0
000074fc937da862  vmovaps [rsp+0x10], xmm1
000074fc937da868  vmovaps [rsp+0x20], xmm2
000074fc937da86e  vmovaps [rsp+0x30], xmm3
000074fc937da874  vmovaps [rsp+0x40], xmm4
000074fc937da87a  vmovaps [rsp+0x50], xmm5
000074fc937da880  vmovaps [rsp+0x60], xmm6
000074fc937da886  vmovaps [rsp+0x70], xmm8
000074fc937da88c  vmovaps [rsp+0x80], xmm9
000074fc937da895  vmovaps [rsp+0x90], xmm10
000074fc937da89e  vmovaps [rsp+0xA0], xmm11
000074fc937da8a7  vmovaps [rsp+0xB0], xmm12
000074fc937da8b0  vmovaps [rsp+0xC0], xmm13
000074fc937da8b9  vmovaps [rsp+0xD0], xmm14
000074fc937da8c2  vmovaps [rsp+0xE0], xmm15
000074fc937da8cb  sub rsp, 0x30
000074fc937da8cf  movaps [rsp], xmm7
000074fc937da8d3  movaps [rsp+0x10], xmm11
000074fc937da8d9  movaps [rsp+0x20], xmm9
000074fc937da8df  lea rdi, [rsp]
000074fc937da8e3  mov esi, 0x00
000074fc937da8e8  mov rax, 0x5D72CBC20530
000074fc937da8f2  call rax
000074fc937da8f4  movaps xmm7, [rsp]
000074fc937da8f8  add rsp, 0x30
000074fc937da8fc  vmovaps xmm0, [rsp]
000074fc937da901  vmovaps xmm1, [rsp+0x10]
000074fc937da907  vmovaps xmm2, [rsp+0x20]
000074fc937da90d  vmovaps xmm3, [rsp+0x30]
000074fc937da913  vmovaps xmm4, [rsp+0x40]
000074fc937da919  vmovaps xmm5, [rsp+0x50]
000074fc937da91f  vmovaps xmm6, [rsp+0x60]
000074fc937da925  vmovaps xmm8, [rsp+0x70]
000074fc937da92b  vmovaps xmm9, [rsp+0x80]
000074fc937da934  vmovaps xmm10, [rsp+0x90]
000074fc937da93d  vmovaps xmm11, [rsp+0xA0]
000074fc937da946  vmovaps xmm12, [rsp+0xB0]
000074fc937da94f  vmovaps xmm13, [rsp+0xC0]
000074fc937da958  vmovaps xmm14, [rsp+0xD0]
000074fc937da961  vmovaps xmm15, [rsp+0xE0]
000074fc937da96a  add rsp, 0xF0
000074fc937da971  pop r11
000074fc937da973  pop r10
000074fc937da975  pop r9
000074fc937da977  pop r8
000074fc937da979  pop rsi
000074fc937da97a  pop rdi
000074fc937da97b  pop rdx
000074fc937da97c  pop rcx
000074fc937da97d  pop rax
000074fc937da97e  add rsp, 0x08
000074fc937da982  jmp 0x000074FC937D64D2
000074fc937da987  sub rsp, 0x08
000074fc937da98b  push rax
000074fc937da98c  push rcx
000074fc937da98d  push rdx
000074fc937da98e  push rdi
000074fc937da98f  push rsi
000074fc937da990  push r8
000074fc937da992  push r9
000074fc937da994  push r10
000074fc937da996  push r11
000074fc937da998  sub rsp, 0xF0
000074fc937da99f  vmovaps [rsp], xmm0
000074fc937da9a4  vmovaps [rsp+0x10], xmm1
000074fc937da9aa  vmovaps [rsp+0x20], xmm2
000074fc937da9b0  vmovaps [rsp+0x30], xmm3
000074fc937da9b6  vmovaps [rsp+0x40], xmm4
000074fc937da9bc  vmovaps [rsp+0x50], xmm5
000074fc937da9c2  vmovaps [rsp+0x60], xmm6
000074fc937da9c8  vmovaps [rsp+0x70], xmm7
000074fc937da9ce  vmovaps [rsp+0x80], xmm8
000074fc937da9d7  vmovaps [rsp+0x90], xmm9
000074fc937da9e0  vmovaps [rsp+0xA0], xmm10
000074fc937da9e9  vmovaps [rsp+0xB0], xmm12
000074fc937da9f2  vmovaps [rsp+0xC0], xmm13
000074fc937da9fb  vmovaps [rsp+0xD0], xmm14
000074fc937daa04  vmovaps [rsp+0xE0], xmm15
000074fc937daa0d  sub rsp, 0x30
000074fc937daa11  movaps [rsp], xmm11
000074fc937daa16  movaps [rsp+0x10], xmm10
000074fc937daa1c  movaps [rsp+0x20], xmm14
000074fc937daa22  lea rdi, [rsp]
000074fc937daa26  mov esi, 0x00
000074fc937daa2b  mov rax, 0x5D72CBC20530
000074fc937daa35  call rax
000074fc937daa37  movaps xmm11, [rsp]
000074fc937daa3c  add rsp, 0x30
000074fc937daa40  vmovaps xmm0, [rsp]
000074fc937daa45  vmovaps xmm1, [rsp+0x10]
000074fc937daa4b  vmovaps xmm2, [rsp+0x20]
000074fc937daa51  vmovaps xmm3, [rsp+0x30]
000074fc937daa57  vmovaps xmm4, [rsp+0x40]
000074fc937daa5d  vmovaps xmm5, [rsp+0x50]
000074fc937daa63  vmovaps xmm6, [rsp+0x60]
000074fc937daa69  vmovaps xmm7, [rsp+0x70]
000074fc937daa6f  vmovaps xmm8, [rsp+0x80]
000074fc937daa78  vmovaps xmm9, [rsp+0x90]
000074fc937daa81  vmovaps xmm10, [rsp+0xA0]
000074fc937daa8a  vmovaps xmm12, [rsp+0xB0]
000074fc937daa93  vmovaps xmm13, [rsp+0xC0]
000074fc937daa9c  vmovaps xmm14, [rsp+0xD0]
000074fc937daaa5  vmovaps xmm15, [rsp+0xE0]
000074fc937daaae  add rsp, 0xF0
000074fc937daab5  pop r11
000074fc937daab7  pop r10
000074fc937daab9  pop r9
000074fc937daabb  pop r8
000074fc937daabd  pop rsi
000074fc937daabe  pop rdi
000074fc937daabf  pop rdx
000074fc937daac0  pop rcx
000074fc937daac1  pop rax
000074fc937daac2  add rsp, 0x08
000074fc937daac6  jmp 0x000074FC937D64ED
000074fc937daacb  call 0x000074FC936E45A0
000074fc937daad0  jmp 0x000074FC937D64F7
000074fc937daad5  sub rsp, 0x08
000074fc937daad9  push rax
000074fc937daada  push rcx
000074fc937daadb  push rdx
000074fc937daadc  push rdi
000074fc937daadd  push rsi
000074fc937daade  push r8
000074fc937daae0  push r9
000074fc937daae2  push r10
000074fc937daae4  push r11
000074fc937daae6  sub rsp, 0xF0
000074fc937daaed  vmovaps [rsp], xmm0
000074fc937daaf2  vmovaps [rsp+0x10], xmm1
000074fc937daaf8  vmovaps [rsp+0x20], xmm2
000074fc937daafe  vmovaps [rsp+0x30], xmm3
000074fc937dab04  vmovaps [rsp+0x40], xmm4
000074fc937dab0a  vmovaps [rsp+0x50], xmm5
000074fc937dab10  vmovaps [rsp+0x60], xmm6
000074fc937dab16  vmovaps [rsp+0x70], xmm7
000074fc937dab1c  vmovaps [rsp+0x80], xmm8
000074fc937dab25  vmovaps [rsp+0x90], xmm9
000074fc937dab2e  vmovaps [rsp+0xA0], xmm11
000074fc937dab37  vmovaps [rsp+0xB0], xmm12
000074fc937dab40  vmovaps [rsp+0xC0], xmm13
000074fc937dab49  vmovaps [rsp+0xD0], xmm14
000074fc937dab52  vmovaps [rsp+0xE0], xmm15
000074fc937dab5b  sub rsp, 0x30
000074fc937dab5f  movaps [rsp], xmm10
000074fc937dab64  movaps [rsp+0x10], xmm1
000074fc937dab69  movaps [rsp+0x20], xmm12
000074fc937dab6f  lea rdi, [rsp]
000074fc937dab73  mov esi, 0x00
000074fc937dab78  mov rax, 0x5D72CBC20530
000074fc937dab82  call rax
000074fc937dab84  movaps xmm10, [rsp]
000074fc937dab89  add rsp, 0x30
000074fc937dab8d  vmovaps xmm0, [rsp]
000074fc937dab92  vmovaps xmm1, [rsp+0x10]
000074fc937dab98  vmovaps xmm2, [rsp+0x20]
000074fc937dab9e  vmovaps xmm3, [rsp+0x30]
000074fc937daba4  vmovaps xmm4, [rsp+0x40]
000074fc937dabaa  vmovaps xmm5, [rsp+0x50]
000074fc937dabb0  vmovaps xmm6, [rsp+0x60]
000074fc937dabb6  vmovaps xmm7, [rsp+0x70]
000074fc937dabbc  vmovaps xmm8, [rsp+0x80]
000074fc937dabc5  vmovaps xmm9, [rsp+0x90]
000074fc937dabce  vmovaps xmm11, [rsp+0xA0]
000074fc937dabd7  vmovaps xmm12, [rsp+0xB0]
000074fc937dabe0  vmovaps xmm13, [rsp+0xC0]
000074fc937dabe9  vmovaps xmm14, [rsp+0xD0]
000074fc937dabf2  vmovaps xmm15, [rsp+0xE0]
000074fc937dabfb  add rsp, 0xF0
000074fc937dac02  pop r11
000074fc937dac04  pop r10
000074fc937dac06  pop r9
000074fc937dac08  pop r8
000074fc937dac0a  pop rsi
000074fc937dac0b  pop rdi
000074fc937dac0c  pop rdx
000074fc937dac0d  pop rcx
000074fc937dac0e  pop rax
000074fc937dac0f  add rsp, 0x08
000074fc937dac13  jmp 0x000074FC937D651A
000074fc937dac18  sub rsp, 0x08
000074fc937dac1c  push rax
000074fc937dac1d  push rcx
000074fc937dac1e  push rdx
000074fc937dac1f  push rdi
000074fc937dac20  push rsi
000074fc937dac21  push r8
000074fc937dac23  push r9
000074fc937dac25  push r10
000074fc937dac27  push r11
000074fc937dac29  sub rsp, 0xF0
000074fc937dac30  vmovaps [rsp], xmm0
000074fc937dac35  vmovaps [rsp+0x10], xmm1
000074fc937dac3b  vmovaps [rsp+0x20], xmm2
000074fc937dac41  vmovaps [rsp+0x30], xmm3
000074fc937dac47  vmovaps [rsp+0x40], xmm4
000074fc937dac4d  vmovaps [rsp+0x50], xmm5
000074fc937dac53  vmovaps [rsp+0x60], xmm6
000074fc937dac59  vmovaps [rsp+0x70], xmm7
000074fc937dac5f  vmovaps [rsp+0x80], xmm8
000074fc937dac68  vmovaps [rsp+0x90], xmm9
000074fc937dac71  vmovaps [rsp+0xA0], xmm10
000074fc937dac7a  vmovaps [rsp+0xB0], xmm11
000074fc937dac83  vmovaps [rsp+0xC0], xmm13
000074fc937dac8c  vmovaps [rsp+0xD0], xmm14
000074fc937dac95  vmovaps [rsp+0xE0], xmm15
000074fc937dac9e  sub rsp, 0x30
000074fc937daca2  movaps [rsp], xmm12
000074fc937daca7  movaps [rsp+0x10], xmm14
000074fc937dacad  movaps [rsp+0x20], xmm1
000074fc937dacb2  lea rdi, [rsp]
000074fc937dacb6  mov esi, 0x00
000074fc937dacbb  mov rax, 0x5D72CBC20530
000074fc937dacc5  call rax
000074fc937dacc7  movaps xmm12, [rsp]
000074fc937daccc  add rsp, 0x30
000074fc937dacd0  vmovaps xmm0, [rsp]
000074fc937dacd5  vmovaps xmm1, [rsp+0x10]
000074fc937dacdb  vmovaps xmm2, [rsp+0x20]
000074fc937dace1  vmovaps xmm3, [rsp+0x30]
000074fc937dace7  vmovaps xmm4, [rsp+0x40]
000074fc937daced  vmovaps xmm5, [rsp+0x50]
000074fc937dacf3  vmovaps xmm6, [rsp+0x60]
000074fc937dacf9  vmovaps xmm7, [rsp+0x70]
000074fc937dacff  vmovaps xmm8, [rsp+0x80]
000074fc937dad08  vmovaps xmm9, [rsp+0x90]
000074fc937dad11  vmovaps xmm10, [rsp+0xA0]
000074fc937dad1a  vmovaps xmm11, [rsp+0xB0]
000074fc937dad23  vmovaps xmm13, [rsp+0xC0]
000074fc937dad2c  vmovaps xmm14, [rsp+0xD0]
000074fc937dad35  vmovaps xmm15, [rsp+0xE0]
000074fc937dad3e  add rsp, 0xF0
000074fc937dad45  pop r11
000074fc937dad47  pop r10
000074fc937dad49  pop r9
000074fc937dad4b  pop r8
000074fc937dad4d  pop rsi
000074fc937dad4e  pop rdi
000074fc937dad4f  pop rdx
000074fc937dad50  pop rcx
000074fc937dad51  pop rax
000074fc937dad52  add rsp, 0x08
000074fc937dad56  jmp 0x000074FC937D6549
000074fc937dad5b  sub rsp, 0x08
000074fc937dad5f  push rax
000074fc937dad60  push rcx
000074fc937dad61  push rdx
000074fc937dad62  push rdi
000074fc937dad63  push rsi
000074fc937dad64  push r8
000074fc937dad66  push r9
000074fc937dad68  push r10
000074fc937dad6a  push r11
000074fc937dad6c  sub rsp, 0xF0
000074fc937dad73  vmovaps [rsp], xmm0
000074fc937dad78  vmovaps [rsp+0x10], xmm1
000074fc937dad7e  vmovaps [rsp+0x20], xmm2
000074fc937dad84  vmovaps [rsp+0x30], xmm3
000074fc937dad8a  vmovaps [rsp+0x40], xmm4
000074fc937dad90  vmovaps [rsp+0x50], xmm5
000074fc937dad96  vmovaps [rsp+0x60], xmm6
000074fc937dad9c  vmovaps [rsp+0x70], xmm7
000074fc937dada2  vmovaps [rsp+0x80], xmm8
000074fc937dadab  vmovaps [rsp+0x90], xmm9
000074fc937dadb4  vmovaps [rsp+0xA0], xmm10
000074fc937dadbd  vmovaps [rsp+0xB0], xmm11
000074fc937dadc6  vmovaps [rsp+0xC0], xmm12
000074fc937dadcf  vmovaps [rsp+0xD0], xmm13
000074fc937dadd8  vmovaps [rsp+0xE0], xmm15
000074fc937dade1  sub rsp, 0x30
000074fc937dade5  movaps [rsp], xmm14
000074fc937dadea  movaps [rsp+0x10], xmm9
000074fc937dadf0  movaps [rsp+0x20], xmm1
000074fc937dadf5  lea rdi, [rsp]
000074fc937dadf9  mov esi, 0x00
000074fc937dadfe  mov rax, 0x5D72CBC20530
000074fc937dae08  call rax
000074fc937dae0a  movaps xmm14, [rsp]
000074fc937dae0f  add rsp, 0x30
000074fc937dae13  vmovaps xmm0, [rsp]
000074fc937dae18  vmovaps xmm1, [rsp+0x10]
000074fc937dae1e  vmovaps xmm2, [rsp+0x20]
000074fc937dae24  vmovaps xmm3, [rsp+0x30]
000074fc937dae2a  vmovaps xmm4, [rsp+0x40]
000074fc937dae30  vmovaps xmm5, [rsp+0x50]
000074fc937dae36  vmovaps xmm6, [rsp+0x60]
000074fc937dae3c  vmovaps xmm7, [rsp+0x70]
000074fc937dae42  vmovaps xmm8, [rsp+0x80]
000074fc937dae4b  vmovaps xmm9, [rsp+0x90]
000074fc937dae54  vmovaps xmm10, [rsp+0xA0]
000074fc937dae5d  vmovaps xmm11, [rsp+0xB0]
000074fc937dae66  vmovaps xmm12, [rsp+0xC0]
000074fc937dae6f  vmovaps xmm13, [rsp+0xD0]
000074fc937dae78  vmovaps xmm15, [rsp+0xE0]
000074fc937dae81  add rsp, 0xF0
000074fc937dae88  pop r11
000074fc937dae8a  pop r10
000074fc937dae8c  pop r9
000074fc937dae8e  pop r8
000074fc937dae90  pop rsi
000074fc937dae91  pop rdi
000074fc937dae92  pop rdx
000074fc937dae93  pop rcx
000074fc937dae94  pop rax
000074fc937dae95  add rsp, 0x08
000074fc937dae99  jmp 0x000074FC937D6578
000074fc937dae9e  sub rsp, 0x08
000074fc937daea2  push rax
000074fc937daea3  push rcx
000074fc937daea4  push rdx
000074fc937daea5  push rdi
000074fc937daea6  push rsi
000074fc937daea7  push r8
000074fc937daea9  push r9
000074fc937daeab  push r10
000074fc937daead  push r11
000074fc937daeaf  sub rsp, 0xF0
000074fc937daeb6  vmovaps [rsp], xmm0
000074fc937daebb  vmovaps [rsp+0x10], xmm2
000074fc937daec1  vmovaps [rsp+0x20], xmm3
000074fc937daec7  vmovaps [rsp+0x30], xmm4
000074fc937daecd  vmovaps [rsp+0x40], xmm5
000074fc937daed3  vmovaps [rsp+0x50], xmm6
000074fc937daed9  vmovaps [rsp+0x60], xmm7
000074fc937daedf  vmovaps [rsp+0x70], xmm8
000074fc937daee5  vmovaps [rsp+0x80], xmm9
000074fc937daeee  vmovaps [rsp+0x90], xmm10
000074fc937daef7  vmovaps [rsp+0xA0], xmm11
000074fc937daf00  vmovaps [rsp+0xB0], xmm12
000074fc937daf09  vmovaps [rsp+0xC0], xmm13
000074fc937daf12  vmovaps [rsp+0xD0], xmm14
000074fc937daf1b  vmovaps [rsp+0xE0], xmm15
000074fc937daf24  sub rsp, 0x30
000074fc937daf28  movaps [rsp], xmm1
000074fc937daf2c  movaps [rsp+0x10], xmm13
000074fc937daf32  movaps [rsp+0x20], xmm8
000074fc937daf38  lea rdi, [rsp]
000074fc937daf3c  mov esi, 0x00
000074fc937daf41  mov rax, 0x5D72CBC20530
000074fc937daf4b  call rax
000074fc937daf4d  movaps xmm1, [rsp]
000074fc937daf51  add rsp, 0x30
000074fc937daf55  vmovaps xmm0, [rsp]
000074fc937daf5a  vmovaps xmm2, [rsp+0x10]
000074fc937daf60  vmovaps xmm3, [rsp+0x20]
000074fc937daf66  vmovaps xmm4, [rsp+0x30]
000074fc937daf6c  vmovaps xmm5, [rsp+0x40]
000074fc937daf72  vmovaps xmm6, [rsp+0x50]
000074fc937daf78  vmovaps xmm7, [rsp+0x60]
000074fc937daf7e  vmovaps xmm8, [rsp+0x70]
000074fc937daf84  vmovaps xmm9, [rsp+0x80]
000074fc937daf8d  vmovaps xmm10, [rsp+0x90]
000074fc937daf96  vmovaps xmm11, [rsp+0xA0]
000074fc937daf9f  vmovaps xmm12, [rsp+0xB0]
000074fc937dafa8  vmovaps xmm13, [rsp+0xC0]
000074fc937dafb1  vmovaps xmm14, [rsp+0xD0]
000074fc937dafba  vmovaps xmm15, [rsp+0xE0]
000074fc937dafc3  add rsp, 0xF0
000074fc937dafca  pop r11
000074fc937dafcc  pop r10
000074fc937dafce  pop r9
000074fc937dafd0  pop r8
000074fc937dafd2  pop rsi
000074fc937dafd3  pop rdi
000074fc937dafd4  pop rdx
000074fc937dafd5  pop rcx
000074fc937dafd6  pop rax
000074fc937dafd7  add rsp, 0x08
000074fc937dafdb  jmp 0x000074FC937D659A
000074fc937dafe0  call 0x000074FC9360C260
000074fc937dafe5  jmp 0x000074FC937D65A8
000074fc937dafea  call 0x000074FC936DE950
000074fc937dafef  jmp 0x000074FC937D65B2
000074fc937daff4  sub rsp, 0x08
000074fc937daff8  push rax
000074fc937daff9  push rcx
000074fc937daffa  push rdx
000074fc937daffb  push rdi
000074fc937daffc  push rsi
000074fc937daffd  push r8
000074fc937dafff  push r9
000074fc937db001  push r10
000074fc937db003  push r11
000074fc937db005  sub rsp, 0xF0
000074fc937db00c  vmovaps [rsp], xmm0
000074fc937db011  vmovaps [rsp+0x10], xmm1
000074fc937db017  vmovaps [rsp+0x20], xmm2
000074fc937db01d  vmovaps [rsp+0x30], xmm3
000074fc937db023  vmovaps [rsp+0x40], xmm4
000074fc937db029  vmovaps [rsp+0x50], xmm5
000074fc937db02f  vmovaps [rsp+0x60], xmm6
000074fc937db035  vmovaps [rsp+0x70], xmm7
000074fc937db03b  vmovaps [rsp+0x80], xmm9
000074fc937db044  vmovaps [rsp+0x90], xmm10
000074fc937db04d  vmovaps [rsp+0xA0], xmm11
000074fc937db056  vmovaps [rsp+0xB0], xmm12
000074fc937db05f  vmovaps [rsp+0xC0], xmm13
000074fc937db068  vmovaps [rsp+0xD0], xmm14
000074fc937db071  vmovaps [rsp+0xE0], xmm15
000074fc937db07a  sub rsp, 0x30
000074fc937db07e  movaps [rsp], xmm8
000074fc937db083  movaps [rsp+0x10], xmm15
000074fc937db089  movaps [rsp+0x20], xmm7
000074fc937db08e  lea rdi, [rsp]
000074fc937db092  mov esi, 0x00
000074fc937db097  mov rax, 0x5D72CBC20530
000074fc937db0a1  call rax
000074fc937db0a3  movaps xmm8, [rsp]
000074fc937db0a8  add rsp, 0x30
000074fc937db0ac  vmovaps xmm0, [rsp]
000074fc937db0b1  vmovaps xmm1, [rsp+0x10]
000074fc937db0b7  vmovaps xmm2, [rsp+0x20]
000074fc937db0bd  vmovaps xmm3, [rsp+0x30]
000074fc937db0c3  vmovaps xmm4, [rsp+0x40]
000074fc937db0c9  vmovaps xmm5, [rsp+0x50]
000074fc937db0cf  vmovaps xmm6, [rsp+0x60]
000074fc937db0d5  vmovaps xmm7, [rsp+0x70]
000074fc937db0db  vmovaps xmm9, [rsp+0x80]
000074fc937db0e4  vmovaps xmm10, [rsp+0x90]
000074fc937db0ed  vmovaps xmm11, [rsp+0xA0]
000074fc937db0f6  vmovaps xmm12, [rsp+0xB0]
000074fc937db0ff  vmovaps xmm13, [rsp+0xC0]
000074fc937db108  vmovaps xmm14, [rsp+0xD0]
000074fc937db111  vmovaps xmm15, [rsp+0xE0]
000074fc937db11a  add rsp, 0xF0
000074fc937db121  pop r11
000074fc937db123  pop r10
000074fc937db125  pop r9
000074fc937db127  pop r8
000074fc937db129  pop rsi
000074fc937db12a  pop rdi
000074fc937db12b  pop rdx
000074fc937db12c  pop rcx
000074fc937db12d  pop rax
000074fc937db12e  add rsp, 0x08
000074fc937db132  jmp 0x000074FC937D65D4
000074fc937db137  sub rsp, 0x08
000074fc937db13b  push rax
000074fc937db13c  push rcx
000074fc937db13d  push rdx
000074fc937db13e  push rdi
000074fc937db13f  push rsi
000074fc937db140  push r8
000074fc937db142  push r9
000074fc937db144  push r10
000074fc937db146  push r11
000074fc937db148  sub rsp, 0xF0
000074fc937db14f  vmovaps [rsp], xmm0
000074fc937db154  vmovaps [rsp+0x10], xmm1
000074fc937db15a  vmovaps [rsp+0x20], xmm2
000074fc937db160  vmovaps [rsp+0x30], xmm3
000074fc937db166  vmovaps [rsp+0x40], xmm4
000074fc937db16c  vmovaps [rsp+0x50], xmm5
000074fc937db172  vmovaps [rsp+0x60], xmm6
000074fc937db178  vmovaps [rsp+0x70], xmm8
000074fc937db17e  vmovaps [rsp+0x80], xmm9
000074fc937db187  vmovaps [rsp+0x90], xmm10
000074fc937db190  vmovaps [rsp+0xA0], xmm11
000074fc937db199  vmovaps [rsp+0xB0], xmm12
000074fc937db1a2  vmovaps [rsp+0xC0], xmm13
000074fc937db1ab  vmovaps [rsp+0xD0], xmm14
000074fc937db1b4  vmovaps [rsp+0xE0], xmm15
000074fc937db1bd  sub rsp, 0x30
000074fc937db1c1  movaps [rsp], xmm7
000074fc937db1c5  movaps [rsp+0x10], xmm9
000074fc937db1cb  movaps [rsp+0x20], xmm15
000074fc937db1d1  lea rdi, [rsp]
000074fc937db1d5  mov esi, 0x00
000074fc937db1da  mov rax, 0x5D72CBC20530
000074fc937db1e4  call rax
000074fc937db1e6  movaps xmm7, [rsp]
000074fc937db1ea  add rsp, 0x30
000074fc937db1ee  vmovaps xmm0, [rsp]
000074fc937db1f3  vmovaps xmm1, [rsp+0x10]
000074fc937db1f9  vmovaps xmm2, [rsp+0x20]
000074fc937db1ff  vmovaps xmm3, [rsp+0x30]
000074fc937db205  vmovaps xmm4, [rsp+0x40]
000074fc937db20b  vmovaps xmm5, [rsp+0x50]
000074fc937db211  vmovaps xmm6, [rsp+0x60]
000074fc937db217  vmovaps xmm8, [rsp+0x70]
000074fc937db21d  vmovaps xmm9, [rsp+0x80]
000074fc937db226  vmovaps xmm10, [rsp+0x90]
000074fc937db22f  vmovaps xmm11, [rsp+0xA0]
000074fc937db238  vmovaps xmm12, [rsp+0xB0]
000074fc937db241  vmovaps xmm13, [rsp+0xC0]
000074fc937db24a  vmovaps xmm14, [rsp+0xD0]
000074fc937db253  vmovaps xmm15, [rsp+0xE0]
000074fc937db25c  add rsp, 0xF0
000074fc937db263  pop r11
000074fc937db265  pop r10
000074fc937db267  pop r9
000074fc937db269  pop r8
000074fc937db26b  pop rsi
000074fc937db26c  pop rdi
000074fc937db26d  pop rdx
000074fc937db26e  pop rcx
000074fc937db26f  pop rax
000074fc937db270  add rsp, 0x08
000074fc937db274  jmp 0x000074FC937D6601
000074fc937db279  sub rsp, 0x08
000074fc937db27d  push rax
000074fc937db27e  push rcx
000074fc937db27f  push rdx
000074fc937db280  push rdi
000074fc937db281  push rsi
000074fc937db282  push r8
000074fc937db284  push r9
000074fc937db286  push r10
000074fc937db288  push r11
000074fc937db28a  sub rsp, 0xF0
000074fc937db291  vmovaps [rsp], xmm0
000074fc937db296  vmovaps [rsp+0x10], xmm1
000074fc937db29c  vmovaps [rsp+0x20], xmm2
000074fc937db2a2  vmovaps [rsp+0x30], xmm3
000074fc937db2a8  vmovaps [rsp+0x40], xmm4
000074fc937db2ae  vmovaps [rsp+0x50], xmm5
000074fc937db2b4  vmovaps [rsp+0x60], xmm6
000074fc937db2ba  vmovaps [rsp+0x70], xmm7
000074fc937db2c0  vmovaps [rsp+0x80], xmm8
000074fc937db2c9  vmovaps [rsp+0x90], xmm10
000074fc937db2d2  vmovaps [rsp+0xA0], xmm11
000074fc937db2db  vmovaps [rsp+0xB0], xmm12
000074fc937db2e4  vmovaps [rsp+0xC0], xmm13
000074fc937db2ed  vmovaps [rsp+0xD0], xmm14
000074fc937db2f6  vmovaps [rsp+0xE0], xmm15
000074fc937db2ff  sub rsp, 0x30
000074fc937db303  movaps [rsp], xmm9
000074fc937db308  movaps [rsp+0x10], xmm13
000074fc937db30e  movaps [rsp+0x20], xmm15
000074fc937db314  lea rdi, [rsp]
000074fc937db318  mov esi, 0x00
000074fc937db31d  mov rax, 0x5D72CBC20530
000074fc937db327  call rax
000074fc937db329  movaps xmm9, [rsp]
000074fc937db32e  add rsp, 0x30
000074fc937db332  vmovaps xmm0, [rsp]
000074fc937db337  vmovaps xmm1, [rsp+0x10]
000074fc937db33d  vmovaps xmm2, [rsp+0x20]
000074fc937db343  vmovaps xmm3, [rsp+0x30]
000074fc937db349  vmovaps xmm4, [rsp+0x40]
000074fc937db34f  vmovaps xmm5, [rsp+0x50]
000074fc937db355  vmovaps xmm6, [rsp+0x60]
000074fc937db35b  vmovaps xmm7, [rsp+0x70]
000074fc937db361  vmovaps xmm8, [rsp+0x80]
000074fc937db36a  vmovaps xmm10, [rsp+0x90]
000074fc937db373  vmovaps xmm11, [rsp+0xA0]
000074fc937db37c  vmovaps xmm12, [rsp+0xB0]
000074fc937db385  vmovaps xmm13, [rsp+0xC0]
000074fc937db38e  vmovaps xmm14, [rsp+0xD0]
000074fc937db397  vmovaps xmm15, [rsp+0xE0]
000074fc937db3a0  add rsp, 0xF0
000074fc937db3a7  pop r11
000074fc937db3a9  pop r10
000074fc937db3ab  pop r9
000074fc937db3ad  pop r8
000074fc937db3af  pop rsi
000074fc937db3b0  pop rdi
000074fc937db3b1  pop rdx
000074fc937db3b2  pop rcx
000074fc937db3b3  pop rax
000074fc937db3b4  add rsp, 0x08
000074fc937db3b8  jmp 0x000074FC937D662F
000074fc937db3bd  sub rsp, 0x08
000074fc937db3c1  push rax
000074fc937db3c2  push rcx
000074fc937db3c3  push rdx
000074fc937db3c4  push rdi
000074fc937db3c5  push rsi
000074fc937db3c6  push r8
000074fc937db3c8  push r9
000074fc937db3ca  push r10
000074fc937db3cc  push r11
000074fc937db3ce  sub rsp, 0xF0
000074fc937db3d5  vmovaps [rsp], xmm0
000074fc937db3da  vmovaps [rsp+0x10], xmm1
000074fc937db3e0  vmovaps [rsp+0x20], xmm2
000074fc937db3e6  vmovaps [rsp+0x30], xmm3
000074fc937db3ec  vmovaps [rsp+0x40], xmm4
000074fc937db3f2  vmovaps [rsp+0x50], xmm5
000074fc937db3f8  vmovaps [rsp+0x60], xmm6
000074fc937db3fe  vmovaps [rsp+0x70], xmm7
000074fc937db404  vmovaps [rsp+0x80], xmm8
000074fc937db40d  vmovaps [rsp+0x90], xmm9
000074fc937db416  vmovaps [rsp+0xA0], xmm10
000074fc937db41f  vmovaps [rsp+0xB0], xmm11
000074fc937db428  vmovaps [rsp+0xC0], xmm12
000074fc937db431  vmovaps [rsp+0xD0], xmm13
000074fc937db43a  vmovaps [rsp+0xE0], xmm14
000074fc937db443  sub rsp, 0x30
000074fc937db447  movaps [rsp], xmm15
000074fc937db44c  movaps [rsp+0x10], xmm11
000074fc937db452  movaps [rsp+0x20], xmm12
000074fc937db458  lea rdi, [rsp]
000074fc937db45c  mov esi, 0x00
000074fc937db461  mov rax, 0x5D72CBC20530
000074fc937db46b  call rax
000074fc937db46d  movaps xmm15, [rsp]
000074fc937db472  add rsp, 0x30
000074fc937db476  vmovaps xmm0, [rsp]
000074fc937db47b  vmovaps xmm1, [rsp+0x10]
000074fc937db481  vmovaps xmm2, [rsp+0x20]
000074fc937db487  vmovaps xmm3, [rsp+0x30]
000074fc937db48d  vmovaps xmm4, [rsp+0x40]
000074fc937db493  vmovaps xmm5, [rsp+0x50]
000074fc937db499  vmovaps xmm6, [rsp+0x60]
000074fc937db49f  vmovaps xmm7, [rsp+0x70]
000074fc937db4a5  vmovaps xmm8, [rsp+0x80]
000074fc937db4ae  vmovaps xmm9, [rsp+0x90]
000074fc937db4b7  vmovaps xmm10, [rsp+0xA0]
000074fc937db4c0  vmovaps xmm11, [rsp+0xB0]
000074fc937db4c9  vmovaps xmm12, [rsp+0xC0]
000074fc937db4d2  vmovaps xmm13, [rsp+0xD0]
000074fc937db4db  vmovaps xmm14, [rsp+0xE0]
000074fc937db4e4  add rsp, 0xF0
000074fc937db4eb  pop r11
000074fc937db4ed  pop r10
000074fc937db4ef  pop r9
000074fc937db4f1  pop r8
000074fc937db4f3  pop rsi
000074fc937db4f4  pop rdi
000074fc937db4f5  pop rdx
000074fc937db4f6  pop rcx
000074fc937db4f7  pop rax
000074fc937db4f8  add rsp, 0x08
000074fc937db4fc  jmp 0x000074FC937D664A
000074fc937db501  sub rsp, 0x08
000074fc937db505  push rax
000074fc937db506  push rcx
000074fc937db507  push rdx
000074fc937db508  push rdi
000074fc937db509  push rsi
000074fc937db50a  push r8
000074fc937db50c  push r9
000074fc937db50e  push r10
000074fc937db510  push r11
000074fc937db512  sub rsp, 0xF0
000074fc937db519  vmovaps [rsp], xmm0
000074fc937db51e  vmovaps [rsp+0x10], xmm1
000074fc937db524  vmovaps [rsp+0x20], xmm2
000074fc937db52a  vmovaps [rsp+0x30], xmm3
000074fc937db530  vmovaps [rsp+0x40], xmm4
000074fc937db536  vmovaps [rsp+0x50], xmm5
000074fc937db53c  vmovaps [rsp+0x60], xmm6
000074fc937db542  vmovaps [rsp+0x70], xmm7
000074fc937db548  vmovaps [rsp+0x80], xmm8
000074fc937db551  vmovaps [rsp+0x90], xmm9
000074fc937db55a  vmovaps [rsp+0xA0], xmm10
000074fc937db563  vmovaps [rsp+0xB0], xmm11
000074fc937db56c  vmovaps [rsp+0xC0], xmm12
000074fc937db575  vmovaps [rsp+0xD0], xmm14
000074fc937db57e  vmovaps [rsp+0xE0], xmm15
000074fc937db587  sub rsp, 0x30
000074fc937db58b  movaps [rsp], xmm13
000074fc937db590  movaps [rsp+0x10], xmm10
000074fc937db596  movaps [rsp+0x20], xmm14
000074fc937db59c  lea rdi, [rsp]
000074fc937db5a0  mov esi, 0x00
000074fc937db5a5  mov rax, 0x5D72CBC20530
000074fc937db5af  call rax
000074fc937db5b1  movaps xmm13, [rsp]
000074fc937db5b6  add rsp, 0x30
000074fc937db5ba  vmovaps xmm0, [rsp]
000074fc937db5bf  vmovaps xmm1, [rsp+0x10]
000074fc937db5c5  vmovaps xmm2, [rsp+0x20]
000074fc937db5cb  vmovaps xmm3, [rsp+0x30]
000074fc937db5d1  vmovaps xmm4, [rsp+0x40]
000074fc937db5d7  vmovaps xmm5, [rsp+0x50]
000074fc937db5dd  vmovaps xmm6, [rsp+0x60]
000074fc937db5e3  vmovaps xmm7, [rsp+0x70]
000074fc937db5e9  vmovaps xmm8, [rsp+0x80]
000074fc937db5f2  vmovaps xmm9, [rsp+0x90]
000074fc937db5fb  vmovaps xmm10, [rsp+0xA0]
000074fc937db604  vmovaps xmm11, [rsp+0xB0]
000074fc937db60d  vmovaps xmm12, [rsp+0xC0]
000074fc937db616  vmovaps xmm14, [rsp+0xD0]
000074fc937db61f  vmovaps xmm15, [rsp+0xE0]
000074fc937db628  add rsp, 0xF0
000074fc937db62f  pop r11
000074fc937db631  pop r10
000074fc937db633  pop r9
000074fc937db635  pop r8
000074fc937db637  pop rsi
000074fc937db638  pop rdi
000074fc937db639  pop rdx
000074fc937db63a  pop rcx
000074fc937db63b  pop rax
000074fc937db63c  add rsp, 0x08
000074fc937db640  jmp 0x000074FC937D666D
000074fc937db645  sub rsp, 0x08
000074fc937db649  push rax
000074fc937db64a  push rcx
000074fc937db64b  push rdx
000074fc937db64c  push rdi
000074fc937db64d  push rsi
000074fc937db64e  push r8
000074fc937db650  push r9
000074fc937db652  push r10
000074fc937db654  push r11
000074fc937db656  sub rsp, 0xF0
000074fc937db65d  vmovaps [rsp], xmm0
000074fc937db662  vmovaps [rsp+0x10], xmm1
000074fc937db668  vmovaps [rsp+0x20], xmm2
000074fc937db66e  vmovaps [rsp+0x30], xmm3
000074fc937db674  vmovaps [rsp+0x40], xmm4
000074fc937db67a  vmovaps [rsp+0x50], xmm5
000074fc937db680  vmovaps [rsp+0x60], xmm6
000074fc937db686  vmovaps [rsp+0x70], xmm7
000074fc937db68c  vmovaps [rsp+0x80], xmm8
000074fc937db695  vmovaps [rsp+0x90], xmm9
000074fc937db69e  vmovaps [rsp+0xA0], xmm10
000074fc937db6a7  vmovaps [rsp+0xB0], xmm11
000074fc937db6b0  vmovaps [rsp+0xC0], xmm12
000074fc937db6b9  vmovaps [rsp+0xD0], xmm13
000074fc937db6c2  vmovaps [rsp+0xE0], xmm15
000074fc937db6cb  sub rsp, 0x30
000074fc937db6cf  movaps [rsp], xmm14
000074fc937db6d4  movaps [rsp+0x10], xmm1
000074fc937db6d9  movaps [rsp+0x20], xmm7
000074fc937db6de  lea rdi, [rsp]
000074fc937db6e2  mov esi, 0x00
000074fc937db6e7  mov rax, 0x5D72CBC20530
000074fc937db6f1  call rax
000074fc937db6f3  movaps xmm14, [rsp]
000074fc937db6f8  add rsp, 0x30
000074fc937db6fc  vmovaps xmm0, [rsp]
000074fc937db701  vmovaps xmm1, [rsp+0x10]
000074fc937db707  vmovaps xmm2, [rsp+0x20]
000074fc937db70d  vmovaps xmm3, [rsp+0x30]
000074fc937db713  vmovaps xmm4, [rsp+0x40]
000074fc937db719  vmovaps xmm5, [rsp+0x50]
000074fc937db71f  vmovaps xmm6, [rsp+0x60]
000074fc937db725  vmovaps xmm7, [rsp+0x70]
000074fc937db72b  vmovaps xmm8, [rsp+0x80]
000074fc937db734  vmovaps xmm9, [rsp+0x90]
000074fc937db73d  vmovaps xmm10, [rsp+0xA0]
000074fc937db746  vmovaps xmm11, [rsp+0xB0]
000074fc937db74f  vmovaps xmm12, [rsp+0xC0]
000074fc937db758  vmovaps xmm13, [rsp+0xD0]
000074fc937db761  vmovaps xmm15, [rsp+0xE0]
000074fc937db76a  add rsp, 0xF0
000074fc937db771  pop r11
000074fc937db773  pop r10
000074fc937db775  pop r9
000074fc937db777  pop r8
000074fc937db779  pop rsi
000074fc937db77a  pop rdi
000074fc937db77b  pop rdx
000074fc937db77c  pop rcx
000074fc937db77d  pop rax
000074fc937db77e  add rsp, 0x08
000074fc937db782  jmp 0x000074FC937D6690
000074fc937db787  sub rsp, 0x08
000074fc937db78b  push rax
000074fc937db78c  push rcx
000074fc937db78d  push rdx
000074fc937db78e  push rdi
000074fc937db78f  push rsi
000074fc937db790  push r8
000074fc937db792  push r9
000074fc937db794  push r10
000074fc937db796  push r11
000074fc937db798  sub rsp, 0xF0
000074fc937db79f  vmovaps [rsp], xmm0
000074fc937db7a4  vmovaps [rsp+0x10], xmm2
000074fc937db7aa  vmovaps [rsp+0x20], xmm3
000074fc937db7b0  vmovaps [rsp+0x30], xmm4
000074fc937db7b6  vmovaps [rsp+0x40], xmm5
000074fc937db7bc  vmovaps [rsp+0x50], xmm6
000074fc937db7c2  vmovaps [rsp+0x60], xmm7
000074fc937db7c8  vmovaps [rsp+0x70], xmm8
000074fc937db7ce  vmovaps [rsp+0x80], xmm9
000074fc937db7d7  vmovaps [rsp+0x90], xmm10
000074fc937db7e0  vmovaps [rsp+0xA0], xmm11
000074fc937db7e9  vmovaps [rsp+0xB0], xmm12
000074fc937db7f2  vmovaps [rsp+0xC0], xmm13
000074fc937db7fb  vmovaps [rsp+0xD0], xmm14
000074fc937db804  vmovaps [rsp+0xE0], xmm15
000074fc937db80d  sub rsp, 0x30
000074fc937db811  movaps [rsp], xmm1
000074fc937db815  movaps [rsp+0x10], xmm8
000074fc937db81b  movaps [rsp+0x20], xmm9
000074fc937db821  lea rdi, [rsp]
000074fc937db825  mov esi, 0x00
000074fc937db82a  mov rax, 0x5D72CBC20530
000074fc937db834  call rax
000074fc937db836  movaps xmm1, [rsp]
000074fc937db83a  add rsp, 0x30
000074fc937db83e  vmovaps xmm0, [rsp]
000074fc937db843  vmovaps xmm2, [rsp+0x10]
000074fc937db849  vmovaps xmm3, [rsp+0x20]
000074fc937db84f  vmovaps xmm4, [rsp+0x30]
000074fc937db855  vmovaps xmm5, [rsp+0x40]
000074fc937db85b  vmovaps xmm6, [rsp+0x50]
000074fc937db861  vmovaps xmm7, [rsp+0x60]
000074fc937db867  vmovaps xmm8, [rsp+0x70]
000074fc937db86d  vmovaps xmm9, [rsp+0x80]
000074fc937db876  vmovaps xmm10, [rsp+0x90]
000074fc937db87f  vmovaps xmm11, [rsp+0xA0]
000074fc937db888  vmovaps xmm12, [rsp+0xB0]
000074fc937db891  vmovaps xmm13, [rsp+0xC0]
000074fc937db89a  vmovaps xmm14, [rsp+0xD0]
000074fc937db8a3  vmovaps xmm15, [rsp+0xE0]
000074fc937db8ac  add rsp, 0xF0
000074fc937db8b3  pop r11
000074fc937db8b5  pop r10
000074fc937db8b7  pop r9
000074fc937db8b9  pop r8
000074fc937db8bb  pop rsi
000074fc937db8bc  pop rdi
000074fc937db8bd  pop rdx
000074fc937db8be  pop rcx
000074fc937db8bf  pop rax
000074fc937db8c0  add rsp, 0x08
000074fc937db8c4  jmp 0x000074FC937D66B2
000074fc937db8c9  call 0x000074FC936B3E40
000074fc937db8ce  jmp 0x000074FC937D66C0
000074fc937db8d3  call 0x000074FC9360C380
000074fc937db8d8  jmp 0x000074FC937D66CA
000074fc937db8dd  call 0x000074FC9360D600
000074fc937db8e2  jmp 0x000074FC937D66D4
000074fc937db8e7  call 0x000074FC935FF540
000074fc937db8ec  jmp 0x000074FC937D66DE
000074fc937db8f1  int3
000074fc937db8f2  nop [rax+rax*1], ax
000074fc937db8fb  nop [rax+rax*1], eax
000074fc937db900  mov eax, [r15+0x48]
000074fc937db904  lea r14d, [eax+0x01]
000074fc937db909  mov [rsp+0x10], r14d
000074fc937db90e  mov r14d, r14d
000074fc937db911  mov [r15+0x48], r14
000074fc937db915  xor eax, eax
000074fc937db917  mov r14d, [rsp+0x10]
000074fc937db91c  cmp r14d, 0x1F4
000074fc937db923  cmc
000074fc937db924  lahf
000074fc937db925  seto al
000074fc937db928  mov [r15+0x108], eax
000074fc937db92f  mov eax, [r15+0x108]
000074fc937db936  sahf
000074fc937db937  jnz 0x000074FC937DB969
000074fc937db939  cmp dword ptr [r15+0x318], 0x00
000074fc937db941  jz 0x000074FC937E1AB0
000074fc937db947  nop [rax+rax*1], ax
000074fc937db950  nop [rax+rax*1], eax
000074fc937db958  mov eax, 0x410450
000074fc937db95d  mov [r15+0x100], rax
000074fc937db964  jmp 0x000074FC935FE110
000074fc937db969  cmp dword ptr [r15+0x318], 0x00
000074fc937db971  jz 0x000074FC937DB9A0
000074fc937db977  nop [rax+rax*1], ax
000074fc937db980  nop [rax+rax*1], eax
000074fc937db988  mov eax, 0x410274
000074fc937db98d  mov [r15+0x100], rax
000074fc937db994  jmp 0x000074FC935FE110
000074fc937db999  int3
000074fc937db99a  int3
000074fc937db99b  nop [rax+rax*1], eax
000074fc937db9a0  mov rax, [r15+0x40]
000074fc937db9a4  movaps xmm1, [r15+0x1D0]
000074fc937db9ac  vmovaps [rsp+0x10], xmm1
000074fc937db9b2  vmovaps xmm15, [rsp+0x10]
000074fc937db9b8  por xmm1, xmm15
000074fc937db9bd  movaps xmm14, [r15+0x1A0]
000074fc937db9c5  vmovaps [rsp+0x10], xmm14
000074fc937db9cb  vmovaps xmm13, [rsp+0x10]
000074fc937db9d1  por xmm14, xmm13
000074fc937db9d6  lea r14, [rax+0x30]
000074fc937db9da  mov r12, [r13+r14*1]
000074fc937db9df  lea r14, [rax+0x38]
000074fc937db9e3  mov r11, [r13+r14*1]
000074fc937db9e8  movq xmm13, r12
000074fc937db9ed  movq xmm12, r11
000074fc937db9f2  movq xmm13, xmm13
000074fc937db9f7  vmovaps [rsp+0x10], xmm13
000074fc937db9fd  movq xmm13, xmm13
000074fc937dba02  movaps [r15+0x130], xmm13
000074fc937dba0a  movq xmm12, xmm12
000074fc937dba0f  vmovaps [rsp+0x20], xmm12
000074fc937dba15  movq xmm12, xmm12
000074fc937dba1a  movaps [r15+0x280], xmm12
000074fc937dba22  movaps xmm13, [r15+0x270]
000074fc937dba2a  vmovaps [rsp+0x30], xmm13
000074fc937dba30  vmovaps xmm12, [rsp+0x30]
000074fc937dba36  por xmm13, xmm12
000074fc937dba3b  lea r14, [rax+0x20]
000074fc937dba3f  mov r12, [r13+r14*1]
000074fc937dba44  lea r14, [rax+0x28]
000074fc937dba48  mov r11, [r13+r14*1]
000074fc937dba4d  movq xmm12, r12
000074fc937dba52  movq xmm11, r11
000074fc937dba57  movq xmm12, xmm12
000074fc937dba5c  vmovaps [rsp+0x30], xmm12
000074fc937dba62  movq xmm12, xmm12
000074fc937dba67  movaps [r15+0x150], xmm12
000074fc937dba6f  movq xmm11, xmm11
000074fc937dba74  vmovaps [rsp+0x40], xmm11
000074fc937dba7a  movq xmm11, xmm11
000074fc937dba7f  movaps [r15+0x140], xmm11
000074fc937dba87  lea r14, [rax+0x10]
000074fc937dba8b  mov r12, [r13+r14*1]
000074fc937dba90  lea r14, [rax+0x18]
000074fc937dba94  mov r11, [r13+r14*1]
000074fc937dba99  movq xmm12, r12
000074fc937dba9e  movq xmm11, r11
000074fc937dbaa3  movq xmm12, xmm12
000074fc937dbaa8  vmovaps [rsp+0x50], xmm12
000074fc937dbaae  movq xmm12, xmm12
000074fc937dbab3  movaps [r15+0x170], xmm12
000074fc937dbabb  movq xmm11, xmm11
000074fc937dbac0  vmovaps [rsp+0x60], xmm11
000074fc937dbac6  movq xmm11, xmm11
000074fc937dbacb  movaps [r15+0x160], xmm11
000074fc937dbad3  mov r14, [r13+rax*1]
000074fc937dbad8  vmovq xmm12, r14
000074fc937dbadd  vpbroadcastq xmm12, xmm12
000074fc937dbae2  lea r14, [rax+0x08]
000074fc937dbae6  mov rax, [r13+r14*1]
000074fc937dbaeb  movq xmm11, rax
000074fc937dbaf0  movaps [r15+0x230], xmm11
000074fc937dbaf8  mov rax, [r15+0xF8]
000074fc937dbaff  lea r14, [rax+0x50]
000074fc937dbb03  movups xmm11, [r13+r14*1]
000074fc937dbb09  lea r14, [rax+0x60]
000074fc937dbb0d  movups xmm10, [r13+r14*1]
000074fc937dbb13  lea r14, [rax+0x30]
000074fc937dbb17  movups xmm9, [r13+r14*1]
000074fc937dbb1d  mov r14, [r15+0x50]
000074fc937dbb21  mov [r15+0x60], r14
000074fc937dbb25  mov qword ptr [r15+0x58], 0x40
000074fc937dbb2d  movaps xmm8, xmm12
000074fc937dbb31  mulpd xmm8, xmm15
000074fc937dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc937dbb3c  ptest xmm7, xmm7
000074fc937dbb41  jnz 0x000074FC937DC96A
000074fc937dbb47  movq xmm15, qword ptr [r15+0x230]
000074fc937dbb50  vmovaps [rsp+0x70], xmm15
000074fc937dbb56  vpermilpd xmm15, xmm15, 0x00
000074fc937dbb5c  movaps xmm7, xmm9
000074fc937dbb60  mulpd xmm7, xmm15
000074fc937dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc937dbb6a  ptest xmm6, xmm6
000074fc937dbb6f  jnz 0x000074FC937DCAAE
000074fc937dbb75  vxorps xmm15, xmm15, xmm15
000074fc937dbb7a  vpbroadcastq xmm15, xmm15
000074fc937dbb7f  movaps xmm9, xmm12
000074fc937dbb83  mulpd xmm9, xmm10
000074fc937dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc937dbb8e  ptest xmm6, xmm6
000074fc937dbb93  jnz 0x000074FC937DCBF0
000074fc937dbb99  movaps xmm10, xmm12
000074fc937dbb9d  mulpd xmm10, xmm11
000074fc937dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc937dbba8  ptest xmm6, xmm6
000074fc937dbbad  jnz 0x000074FC937DCD34
000074fc937dbbb3  movaps xmm11, [r15+0x1F0]
000074fc937dbbbb  movaps xmm6, xmm12
000074fc937dbbbf  mulpd xmm6, xmm11
000074fc937dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc937dbbc9  ptest xmm5, xmm5
000074fc937dbbce  jnz 0x000074FC937DCE78
000074fc937dbbd4  movaps xmm12, [r15+0x2A0]
000074fc937dbbdc  vmovaps [rsp+0x80], xmm12
000074fc937dbbe5  vmovaps xmm11, [rsp+0x80]
000074fc937dbbee  por xmm12, xmm11
000074fc937dbbf3  movaps xmm11, [r15+0x250]
000074fc937dbbfb  vmovaps [rsp+0x80], xmm11
000074fc937dbc04  vmovaps xmm5, [rsp+0x80]
000074fc937dbc0d  por xmm11, xmm5
000074fc937dbc12  vmovaps xmm4, [rsp+0x70]
000074fc937dbc18  vpermilpd xmm4, xmm4, 0x00
000074fc937dbc1e  movaps xmm3, xmm5
000074fc937dbc21  mulpd xmm3, xmm4
000074fc937dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000074fc937dbc2a  ptest xmm2, xmm2
000074fc937dbc2f  jnz 0x000074FC937DCFBA
000074fc937dbc35  mov [rsp+0x80], rax
000074fc937dbc3d  xor eax, eax
000074fc937dbc3f  mov r12d, 0x40
000074fc937dbc45  mov r11d, 0x200
000074fc937dbc4b  cmp r12, r11
000074fc937dbc4e  cmc
000074fc937dbc4f  lahf
000074fc937dbc50  seto al
000074fc937dbc53  mov [r15+0x108], eax
000074fc937dbc5a  movaps xmm5, xmm8
000074fc937dbc5e  addpd xmm5, xmm15
000074fc937dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000074fc937dbc68  ptest xmm4, xmm4
000074fc937dbc6d  jnz 0x000074FC937DD0FA
000074fc937dbc73  movaps xmm8, [r15+0x1B0]
000074fc937dbc7b  movaps xmm4, xmm9
000074fc937dbc7f  addpd xmm4, xmm8
000074fc937dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000074fc937dbc89  ptest xmm2, xmm2
000074fc937dbc8e  jnz 0x000074FC937DD23C
000074fc937dbc94  movaps xmm9, xmm10
000074fc937dbc98  addpd xmm9, xmm8
000074fc937dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000074fc937dbca3  ptest xmm2, xmm2
000074fc937dbca8  jnz 0x000074FC937DD37E
000074fc937dbcae  movaps xmm10, [r15+0x2F0]
000074fc937dbcb6  vmovaps [rsp+0x90], xmm10
000074fc937dbcbf  vmovaps xmm8, [rsp+0x90]
000074fc937dbcc8  por xmm10, xmm8
000074fc937dbccd  movaps xmm8, [r15+0x2E0]
000074fc937dbcd5  vmovaps [rsp+0x90], xmm8
000074fc937dbcde  vmovaps xmm2, [rsp+0x90]
000074fc937dbce7  por xmm8, xmm2
000074fc937dbcec  movaps xmm2, [r15+0x2D0]
000074fc937dbcf4  vmovaps [rsp+0x90], xmm2
000074fc937dbcfd  vmovaps [rsp+0xA0], xmm1
000074fc937dbd06  vmovaps xmm1, [rsp+0x90]
000074fc937dbd0f  por xmm2, xmm1
000074fc937dbd13  movaps xmm1, [r15+0x200]
000074fc937dbd1b  vmovaps [rsp+0x90], xmm1
000074fc937dbd24  vmovaps [rsp+0xB0], xmm15
000074fc937dbd2d  vmovaps xmm15, [rsp+0x90]
000074fc937dbd36  por xmm1, xmm15
000074fc937dbd3b  movaps xmm15, [r15+0x1C0]
000074fc937dbd43  vmovaps [rsp+0x90], xmm15
000074fc937dbd4c  vmovaps [rsp+0xC0], xmm1
000074fc937dbd55  vmovaps xmm1, [rsp+0x90]
000074fc937dbd5e  por xmm15, xmm1
000074fc937dbd63  movaps xmm1, [r15+0x190]
000074fc937dbd6b  vmovaps [rsp+0x90], xmm1
000074fc937dbd74  vmovaps [rsp+0xD0], xmm15
000074fc937dbd7d  vmovaps xmm15, [rsp+0x90]
000074fc937dbd86  por xmm1, xmm15
000074fc937dbd8b  movaps xmm15, [r15+0x300]
000074fc937dbd93  vmovaps [rsp+0x90], xmm15
000074fc937dbd9c  vmovaps [rsp+0xE0], xmm1
000074fc937dbda5  vmovaps xmm1, [rsp+0x90]
000074fc937dbdae  por xmm15, xmm1
000074fc937dbdb3  mov rax, [rsp+0x80]
000074fc937dbdbb  lea r12, [rax+0xA0]
000074fc937dbdc2  movups xmm1, [r13+r12*1]
000074fc937dbdc8  lea r12, [rax+0xB0]
000074fc937dbdcf  vmovaps [rsp+0x80], xmm1
000074fc937dbdd8  movups xmm1, [r13+r12*1]
000074fc937dbdde  vmovaps [rsp+0x90], xmm1
000074fc937dbde7  vmovaps [rsp+0xF0], xmm15
000074fc937dbdf0  vmovaps xmm15, [rsp+0xB0]
000074fc937dbdf9  vmovaps [rsp+0xB0], xmm14
000074fc937dbe02  movaps xmm1, xmm6
000074fc937dbe05  addpd xmm1, xmm15
000074fc937dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc937dbe0f  ptest xmm14, xmm14
000074fc937dbe15  jnz 0x000074FC937DD4D6
000074fc937dbe1b  lea r12, [rax+0xF0]
000074fc937dbe22  movups xmm15, [r13+r12*1]
000074fc937dbe28  movaps xmm14, xmm4
000074fc937dbe2c  addpd xmm14, xmm3
000074fc937dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc937dbe37  ptest xmm6, xmm6
000074fc937dbe3c  jnz 0x000074FC937DD621
000074fc937dbe42  movaps xmm6, xmm9
000074fc937dbe46  addpd xmm6, xmm7
000074fc937dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000074fc937dbe4f  ptest xmm4, xmm4
000074fc937dbe54  jnz 0x000074FC937DD763
000074fc937dbe5a  vmovaps xmm9, [rsp+0x70]
000074fc937dbe60  vpermilpd xmm9, xmm9, 0x00
000074fc937dbe66  vmovaps xmm4, [rsp+0x90]
000074fc937dbe6f  movaps xmm7, xmm4
000074fc937dbe72  mulpd xmm7, xmm9
000074fc937dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000074fc937dbe7c  ptest xmm3, xmm3
000074fc937dbe81  jnz 0x000074FC937DD8A4
000074fc937dbe87  vmovaps xmm9, [rsp+0x50]
000074fc937dbe8d  vpermilpd xmm9, xmm9, 0x00
000074fc937dbe93  movaps xmm4, xmm15
000074fc937dbe97  mulpd xmm4, xmm9
000074fc937dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc937dbea1  ptest xmm3, xmm3
000074fc937dbea6  jnz 0x000074FC937DD9E5
000074fc937dbeac  lea r12, [rax+0xE0]
000074fc937dbeb3  movups xmm15, [r13+r12*1]
000074fc937dbeb9  vmovaps xmm9, [rsp+0x70]
000074fc937dbebf  vpermilpd xmm9, xmm9, 0x00
000074fc937dbec5  vmovaps [rsp+0x70], xmm1
000074fc937dbecb  vmovaps xmm1, [rsp+0x80]
000074fc937dbed4  vmovaps [rsp+0x80], xmm15
000074fc937dbedd  movaps xmm3, xmm1
000074fc937dbee0  mulpd xmm3, xmm9
000074fc937dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000074fc937dbeea  ptest xmm15, xmm15
000074fc937dbef0  jnz 0x000074FC937DDB31
000074fc937dbef6  vmovaps xmm1, [rsp+0xF0]
000074fc937dbeff  vmovaps xmm15, [rsp+0xF0]
000074fc937dbf08  por xmm1, xmm15
000074fc937dbf0d  movaps [r15+0x300], xmm1
000074fc937dbf15  vmovaps xmm15, [rsp+0xE0]
000074fc937dbf1e  vmovaps xmm9, [rsp+0xE0]
000074fc937dbf27  por xmm15, xmm9
000074fc937dbf2c  movaps [r15+0x190], xmm15
000074fc937dbf34  vmovaps xmm9, [rsp+0x50]
000074fc937dbf3a  vpermilpd xmm9, xmm9, 0x00
000074fc937dbf40  vmovaps [rsp+0x90], xmm1
000074fc937dbf49  vmovaps [rsp+0xE0], xmm15
000074fc937dbf52  vmovaps xmm15, [rsp+0x80]
000074fc937dbf5b  vmovaps [rsp+0x80], xmm14
000074fc937dbf64  movaps xmm1, xmm15
000074fc937dbf68  mulpd xmm1, xmm9
000074fc937dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc937dbf72  ptest xmm14, xmm14
000074fc937dbf78  jnz 0x000074FC937DDC72
000074fc937dbf7e  lea r12, [rax+0x90]
000074fc937dbf85  movups xmm15, [r13+r12*1]
000074fc937dbf8b  vmovaps xmm14, [rsp+0xD0]
000074fc937dbf94  vmovaps xmm9, [rsp+0xD0]
000074fc937dbf9d  por xmm14, xmm9
000074fc937dbfa2  movaps [r15+0x1C0], xmm14
000074fc937dbfaa  vmovaps xmm9, [rsp+0xC0]
000074fc937dbfb3  vmovaps [rsp+0xD0], xmm1
000074fc937dbfbc  vmovaps xmm1, [rsp+0xC0]
000074fc937dbfc5  por xmm9, xmm1
000074fc937dbfca  movaps [r15+0x200], xmm9
000074fc937dbfd2  vmovaps [rsp+0xC0], xmm2
000074fc937dbfdb  vmovaps xmm1, [rsp+0xC0]
000074fc937dbfe4  por xmm2, xmm1
000074fc937dbfe8  movaps [r15+0x2D0], xmm2
000074fc937dbff0  vmovaps [rsp+0xC0], xmm8
000074fc937dbff9  vmovaps xmm1, [rsp+0xC0]
000074fc937dc002  por xmm8, xmm1
000074fc937dc007  movaps [r15+0x2E0], xmm8
000074fc937dc00f  vmovaps [rsp+0xC0], xmm15
000074fc937dc018  movaps xmm1, xmm5
000074fc937dc01b  addpd xmm1, xmm7
000074fc937dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc937dc024  ptest xmm15, xmm15
000074fc937dc02a  jnz 0x000074FC937DDDBE
000074fc937dc030  vmovaps xmm15, [rsp+0x50]
000074fc937dc036  vpermilpd xmm15, xmm15, 0x00
000074fc937dc03c  vmovaps xmm5, [rsp+0xC0]
000074fc937dc045  vmovaps [rsp+0xC0], xmm1
000074fc937dc04e  movaps xmm7, xmm5
000074fc937dc051  mulpd xmm7, xmm15
000074fc937dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000074fc937dc05b  ptest xmm1, xmm1
000074fc937dc060  jnz 0x000074FC937DDEFE
000074fc937dc066  lea r12, [rax+0x80]
000074fc937dc06d  movups xmm1, [r13+r12*1]
000074fc937dc073  vmovaps xmm5, [rsp+0x70]
000074fc937dc079  vmovaps [rsp+0x70], xmm1
000074fc937dc07f  movaps xmm15, xmm5
000074fc937dc083  addpd xmm15, xmm3
000074fc937dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937dc08e  ptest xmm1, xmm1
000074fc937dc093  jnz 0x000074FC937DE049
000074fc937dc099  vmovaps xmm5, [rsp+0x80]
000074fc937dc0a2  movaps xmm1, xmm5
000074fc937dc0a5  addpd xmm1, xmm4
000074fc937dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000074fc937dc0ae  ptest xmm3, xmm3
000074fc937dc0b3  jnz 0x000074FC937DE18B
000074fc937dc0b9  vmovaps [rsp+0x80], xmm10
000074fc937dc0c2  vmovaps xmm5, [rsp+0x80]
000074fc937dc0cb  por xmm10, xmm5
000074fc937dc0d0  movaps [r15+0x2F0], xmm10
000074fc937dc0d8  vmovaps xmm5, [rsp+0x50]
000074fc937dc0de  vpermilpd xmm5, xmm5, 0x00
000074fc937dc0e4  vmovaps xmm3, [rsp+0x70]
000074fc937dc0ea  vmovaps [rsp+0x50], xmm1
000074fc937dc0f0  movaps xmm4, xmm3
000074fc937dc0f3  mulpd xmm4, xmm5
000074fc937dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc937dc0fc  ptest xmm1, xmm1
000074fc937dc101  jnz 0x000074FC937DE2CB
000074fc937dc107  lea r12, [rax+0xD0]
000074fc937dc10e  movups xmm1, [r13+r12*1]
000074fc937dc114  vmovaps xmm3, [rsp+0xD0]
000074fc937dc11d  vmovaps [rsp+0x70], xmm1
000074fc937dc123  movaps xmm5, xmm6
000074fc937dc126  addpd xmm5, xmm3
000074fc937dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000074fc937dc12f  ptest xmm1, xmm1
000074fc937dc134  jnz 0x000074FC937DE415
000074fc937dc13a  vmovaps xmm1, [rsp+0x60]
000074fc937dc140  vpermilpd xmm1, xmm1, 0x00
000074fc937dc146  movaps xmm6, xmm9
000074fc937dc14a  mulpd xmm6, xmm1
000074fc937dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc937dc153  ptest xmm3, xmm3
000074fc937dc158  jnz 0x000074FC937DE555
000074fc937dc15e  movaps [r15+0x260], xmm6
000074fc937dc166  vxorps xmm1, xmm1, xmm1
000074fc937dc16a  vpbroadcastq xmm1, xmm1
000074fc937dc16f  movaps [r15+0x1B0], xmm1
000074fc937dc177  vmovaps xmm1, [rsp+0x60]
000074fc937dc17d  vpermilpd xmm1, xmm1, 0x00
000074fc937dc183  vmovaps xmm3, [rsp+0x70]
000074fc937dc189  vmovaps [rsp+0x70], xmm15
000074fc937dc18f  movaps xmm9, xmm3
000074fc937dc193  mulpd xmm9, xmm1
000074fc937dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc937dc19e  ptest xmm15, xmm15
000074fc937dc1a4  jnz 0x000074FC937DE696
000074fc937dc1aa  lea r12, [rax+0xC0]
000074fc937dc1b1  movups xmm1, [r13+r12*1]
000074fc937dc1b7  vmovaps xmm3, [rsp+0xC0]
000074fc937dc1c0  vmovaps [rsp+0x80], xmm1
000074fc937dc1c9  movaps xmm15, xmm3
000074fc937dc1cd  addpd xmm15, xmm7
000074fc937dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937dc1d8  ptest xmm1, xmm1
000074fc937dc1dd  jnz 0x000074FC937DE7E2
000074fc937dc1e3  vmovaps [rsp+0xC0], xmm13
000074fc937dc1ec  vmovaps xmm1, [rsp+0xC0]
000074fc937dc1f5  por xmm13, xmm1
000074fc937dc1fa  movaps [r15+0x270], xmm13
000074fc937dc202  vmovaps xmm1, [rsp+0xB0]
000074fc937dc20b  vmovaps xmm7, [rsp+0xB0]
000074fc937dc214  por xmm1, xmm7
000074fc937dc218  movaps [r15+0x1A0], xmm1
000074fc937dc220  vmovaps xmm1, [rsp+0x60]
000074fc937dc226  vpermilpd xmm1, xmm1, 0x00
000074fc937dc22c  vmovaps [rsp+0xB0], xmm1
000074fc937dc235  vmovaps xmm1, [rsp+0x80]
000074fc937dc23e  vmovaps [rsp+0x80], xmm15
000074fc937dc247  vmovaps xmm15, [rsp+0xB0]
000074fc937dc250  vmovaps [rsp+0xB0], xmm14
000074fc937dc259  movaps xmm3, xmm1
000074fc937dc25c  mulpd xmm3, xmm15
000074fc937dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000074fc937dc266  ptest xmm14, xmm14
000074fc937dc26c  jnz 0x000074FC937DE924
000074fc937dc272  lea r12, [rax+0x20]
000074fc937dc276  movups xmm1, [r13+r12*1]
000074fc937dc27c  movaps [r15+0x110], xmm1
000074fc937dc284  vmovaps xmm14, [rsp+0x70]
000074fc937dc28a  vmovaps [rsp+0x70], xmm1
000074fc937dc290  movaps xmm15, xmm14
000074fc937dc294  addpd xmm15, xmm4
000074fc937dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc937dc29f  ptest xmm1, xmm1
000074fc937dc2a4  jnz 0x000074FC937DEA6F
000074fc937dc2aa  vmovaps xmm1, [rsp+0x60]
000074fc937dc2b0  vpermilpd xmm1, xmm1, 0x00
000074fc937dc2b6  movaps xmm14, xmm2
000074fc937dc2ba  mulpd xmm14, xmm1
000074fc937dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000074fc937dc2c5  ptest xmm4, xmm4
000074fc937dc2ca  jnz 0x000074FC937DEBB2
000074fc937dc2d0  vmovaps xmm4, [rsp+0x50]
000074fc937dc2d6  movaps xmm1, xmm4
000074fc937dc2d9  addpd xmm1, xmm9
000074fc937dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc937dc2e3  ptest xmm2, xmm2
000074fc937dc2e8  jnz 0x000074FC937DECF4
000074fc937dc2ee  vmovaps xmm9, [rsp+0x30]
000074fc937dc2f4  vpermilpd xmm9, xmm9, 0x00
000074fc937dc2fa  vmovaps xmm2, [rsp+0x70]
000074fc937dc300  vmovaps [rsp+0x50], xmm1
000074fc937dc306  movaps xmm4, xmm2
000074fc937dc309  mulpd xmm4, xmm9
000074fc937dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc937dc313  ptest xmm1, xmm1
000074fc937dc318  jnz 0x000074FC937DEE35
000074fc937dc31e  vmovaps xmm1, [rsp+0x30]
000074fc937dc324  vpermilpd xmm1, xmm1, 0x00
000074fc937dc32a  vmovaps xmm2, [rsp+0x90]
000074fc937dc333  vmovaps [rsp+0x60], xmm15
000074fc937dc339  movaps xmm9, xmm2
000074fc937dc33d  mulpd xmm9, xmm1
000074fc937dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc937dc348  ptest xmm15, xmm15
000074fc937dc34e  jnz 0x000074FC937DEF76
000074fc937dc354  vmovaps xmm15, [rsp+0x80]
000074fc937dc35d  movaps xmm1, xmm15
000074fc937dc361  addpd xmm1, xmm6
000074fc937dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc937dc36a  ptest xmm2, xmm2
000074fc937dc36f  jnz 0x000074FC937DF0B8
000074fc937dc375  movaps xmm15, xmm5
000074fc937dc379  addpd xmm15, xmm3
000074fc937dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000074fc937dc384  ptest xmm6, xmm6
000074fc937dc389  jnz 0x000074FC937DF1F9
000074fc937dc38f  vmovaps xmm6, [rsp+0x30]
000074fc937dc395  vpermilpd xmm6, xmm6, 0x00
000074fc937dc39b  movaps xmm5, xmm8
000074fc937dc39f  mulpd xmm5, xmm6
000074fc937dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000074fc937dc3a8  ptest xmm3, xmm3
000074fc937dc3ad  jnz 0x000074FC937DF33B
000074fc937dc3b3  vmovaps xmm8, [rsp+0x30]
000074fc937dc3b9  vpermilpd xmm8, xmm8, 0x00
000074fc937dc3bf  movaps xmm6, xmm10
000074fc937dc3c3  mulpd xmm6, xmm8
000074fc937dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc937dc3cd  ptest xmm3, xmm3
000074fc937dc3d2  jnz 0x000074FC937DF47C
000074fc937dc3d8  vmovaps xmm8, [rsp+0x60]
000074fc937dc3de  movaps xmm10, xmm8
000074fc937dc3e2  addpd xmm10, xmm14
000074fc937dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000074fc937dc3ed  ptest xmm3, xmm3
000074fc937dc3f2  jnz 0x000074FC937DF5BE
000074fc937dc3f8  vmovaps xmm8, [rsp+0x50]
000074fc937dc3fe  movaps xmm14, xmm8
000074fc937dc402  addpd xmm14, xmm4
000074fc937dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000074fc937dc40d  ptest xmm3, xmm3
000074fc937dc412  jnz 0x000074FC937DF702
000074fc937dc418  vmovaps xmm8, [rsp+0x40]
000074fc937dc41e  vpermilpd xmm8, xmm8, 0x00
000074fc937dc424  movaps xmm4, xmm13
000074fc937dc428  mulpd xmm4, xmm8
000074fc937dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc937dc432  ptest xmm3, xmm3
000074fc937dc437  jnz 0x000074FC937DF845
000074fc937dc43d  movaps xmm13, xmm15
000074fc937dc441  addpd xmm13, xmm9
000074fc937dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000074fc937dc44c  ptest xmm8, xmm8
000074fc937dc452  jnz 0x000074FC937DF987
000074fc937dc458  movaps xmm15, xmm1
000074fc937dc45c  addpd xmm15, xmm5
000074fc937dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc937dc467  ptest xmm9, xmm9
000074fc937dc46d  jnz 0x000074FC937DFACB
000074fc937dc473  vmovaps [rsp+0x30], xmm11
000074fc937dc479  vmovaps xmm1, [rsp+0x30]
000074fc937dc47f  por xmm11, xmm1
000074fc937dc484  movaps [r15+0x250], xmm11
000074fc937dc48c  vmovaps [rsp+0x30], xmm12
000074fc937dc492  vmovaps xmm1, [rsp+0x30]
000074fc937dc498  por xmm12, xmm1
000074fc937dc49d  movaps [r15+0x2A0], xmm12
000074fc937dc4a5  vmovaps xmm1, [rsp+0xA0]
000074fc937dc4ae  vmovaps xmm11, [rsp+0xA0]
000074fc937dc4b7  por xmm1, xmm11
000074fc937dc4bc  movaps [r15+0x1D0], xmm1
000074fc937dc4c4  lea r12, [rax+0x40]
000074fc937dc4c8  movups xmm1, [r13+r12*1]
000074fc937dc4ce  movaps [r15+0x2C0], xmm1
000074fc937dc4d6  vmovaps xmm11, [rsp+0x40]
000074fc937dc4dc  vpermilpd xmm11, xmm11, 0x00
000074fc937dc4e2  vmovaps xmm8, [rsp+0xE0]
000074fc937dc4eb  movaps xmm9, xmm8
000074fc937dc4ef  mulpd xmm9, xmm11
000074fc937dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000074fc937dc4fa  ptest xmm5, xmm5
000074fc937dc4ff  jnz 0x000074FC937DFC17
000074fc937dc505  movaps xmm11, xmm10
000074fc937dc509  addpd xmm11, xmm6
000074fc937dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000074fc937dc514  ptest xmm8, xmm8
000074fc937dc51a  jnz 0x000074FC937DFD5B
000074fc937dc520  movaps xmm10, xmm14
000074fc937dc524  addpd xmm10, xmm4
000074fc937dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000074fc937dc52f  ptest xmm8, xmm8
000074fc937dc535  jnz 0x000074FC937DFE9E
000074fc937dc53b  vmovaps xmm14, [rsp+0x40]
000074fc937dc541  vpermilpd xmm14, xmm14, 0x00
000074fc937dc547  movaps xmm8, xmm1
000074fc937dc54b  mulpd xmm8, xmm14
000074fc937dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc937dc556  ptest xmm6, xmm6
000074fc937dc55b  jnz 0x000074FC937DFFE1
000074fc937dc561  movaps xmm1, [r15+0x2B0]
000074fc937dc569  vmovaps xmm14, [rsp+0x40]
000074fc937dc56f  vpermilpd xmm14, xmm14, 0x00
000074fc937dc575  movaps xmm6, xmm1
000074fc937dc578  mulpd xmm6, xmm14
000074fc937dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc937dc582  ptest xmm5, xmm5
000074fc937dc587  jnz 0x000074FC937E0124
000074fc937dc58d  vmovaps xmm1, [rsp+0x10]
000074fc937dc593  vpermilpd xmm1, xmm1, 0x00
000074fc937dc599  movaps xmm14, xmm12
000074fc937dc59d  mulpd xmm14, xmm1
000074fc937dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000074fc937dc5a8  ptest xmm5, xmm5
000074fc937dc5ad  jnz 0x000074FC937E0265
000074fc937dc5b3  movaps xmm1, xmm13
000074fc937dc5b7  addpd xmm1, xmm9
000074fc937dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc937dc5c1  ptest xmm12, xmm12
000074fc937dc5c7  jnz 0x000074FC937E03A8
000074fc937dc5cd  vmovaps xmm13, [rsp+0x10]
000074fc937dc5d3  vpermilpd xmm13, xmm13, 0x00
000074fc937dc5d9  movaps xmm12, xmm7
000074fc937dc5dd  mulpd xmm12, xmm13
000074fc937dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc937dc5e8  ptest xmm9, xmm9
000074fc937dc5ee  jnz 0x000074FC937E04EA
000074fc937dc5f4  movaps xmm13, xmm15
000074fc937dc5f8  addpd xmm13, xmm8
000074fc937dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000074fc937dc603  ptest xmm9, xmm9
000074fc937dc609  jnz 0x000074FC937E062D
000074fc937dc60f  movaps xmm15, [r15+0x290]
000074fc937dc617  vmovaps xmm9, [rsp+0x10]
000074fc937dc61d  vpermilpd xmm9, xmm9, 0x00
000074fc937dc623  movaps xmm8, xmm15
000074fc937dc627  mulpd xmm8, xmm9
000074fc937dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc937dc632  ptest xmm7, xmm7
000074fc937dc637  jnz 0x000074FC937E0771
000074fc937dc63d  movaps xmm15, xmm11
000074fc937dc641  addpd xmm15, xmm6
000074fc937dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc937dc64c  ptest xmm9, xmm9
000074fc937dc652  jnz 0x000074FC937E08B5
000074fc937dc658  movaps xmm11, [r15+0x1E0]
000074fc937dc660  vmovaps xmm9, [rsp+0x10]
000074fc937dc666  vpermilpd xmm9, xmm9, 0x00
000074fc937dc66c  movaps xmm7, xmm11
000074fc937dc670  mulpd xmm7, xmm9
000074fc937dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc937dc67a  ptest xmm6, xmm6
000074fc937dc67f  jnz 0x000074FC937E09F8
000074fc937dc685  movaps xmm11, xmm10
000074fc937dc689  addpd xmm11, xmm14
000074fc937dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000074fc937dc694  ptest xmm9, xmm9
000074fc937dc69a  jnz 0x000074FC937E0B3A
000074fc937dc6a0  lea r12, [rax+0x70]
000074fc937dc6a4  movups xmm14, [r13+r12*1]
000074fc937dc6aa  movaps [r15+0x240], xmm14
000074fc937dc6b2  movaps xmm10, xmm1
000074fc937dc6b6  addpd xmm10, xmm12
000074fc937dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000074fc937dc6c1  ptest xmm9, xmm9
000074fc937dc6c7  jnz 0x000074FC937E0C88
000074fc937dc6cd  movaps [r15+0x170], xmm10
000074fc937dc6d5  vmovaps xmm1, [rsp+0x20]
000074fc937dc6db  vpermilpd xmm1, xmm1, 0x00
000074fc937dc6e1  movaps xmm12, xmm14
000074fc937dc6e5  mulpd xmm12, xmm1
000074fc937dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc937dc6f0  ptest xmm9, xmm9
000074fc937dc6f6  jnz 0x000074FC937E0DCB
000074fc937dc6fc  vmovaps xmm1, [rsp+0x20]
000074fc937dc702  vpermilpd xmm1, xmm1, 0x00
000074fc937dc708  vmovaps xmm9, [rsp+0xB0]
000074fc937dc711  movaps xmm14, xmm9
000074fc937dc715  mulpd xmm14, xmm1
000074fc937dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc937dc720  ptest xmm6, xmm6
000074fc937dc725  jnz 0x000074FC937E0F0E
000074fc937dc72b  movaps [r15+0x180], xmm14
000074fc937dc733  movaps xmm1, xmm13
000074fc937dc737  addpd xmm1, xmm8
000074fc937dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000074fc937dc741  ptest xmm9, xmm9
000074fc937dc747  jnz 0x000074FC937E1051
000074fc937dc74d  movaps [r15+0x210], xmm1
000074fc937dc755  movups xmm13, [r13+rax*1]
000074fc937dc75b  lea r12, [rax+0x10]
000074fc937dc75f  movups xmm9, [r13+r12*1]
000074fc937dc765  movaps [r15+0x230], xmm9
000074fc937dc76d  movaps xmm8, xmm15
000074fc937dc771  addpd xmm8, xmm7
000074fc937dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc937dc77c  ptest xmm6, xmm6
000074fc937dc781  jnz 0x000074FC937E11A7
000074fc937dc787  movaps [r15+0x130], xmm8
000074fc937dc78f  vmovaps xmm15, [rsp+0x20]
000074fc937dc795  vpermilpd xmm15, xmm15, 0x00
000074fc937dc79b  movaps xmm7, xmm9
000074fc937dc79f  mulpd xmm7, xmm15
000074fc937dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc937dc7a9  ptest xmm6, xmm6
000074fc937dc7ae  jnz 0x000074FC937E12EA
000074fc937dc7b4  movaps [r15+0x220], xmm7
000074fc937dc7bc  vmovaps xmm15, [rsp+0x20]
000074fc937dc7c2  vpermilpd xmm15, xmm15, 0x00
000074fc937dc7c8  movaps xmm9, xmm13
000074fc937dc7cc  mulpd xmm9, xmm15
000074fc937dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc937dc7d7  ptest xmm6, xmm6
000074fc937dc7dc  jnz 0x000074FC937E142C
000074fc937dc7e2  movaps xmm15, xmm11
000074fc937dc7e6  addpd xmm15, xmm12
000074fc937dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc937dc7f1  ptest xmm13, xmm13
000074fc937dc7f7  jnz 0x000074FC937E1570
000074fc937dc7fd  movaps [r15+0x140], xmm15
000074fc937dc805  movaps xmm13, xmm10
000074fc937dc809  addpd xmm13, xmm14
000074fc937dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc937dc814  ptest xmm12, xmm12
000074fc937dc81a  jnz 0x000074FC937E16B4
000074fc937dc820  movaps [r15+0x150], xmm13
000074fc937dc828  movaps xmm14, xmm1
000074fc937dc82c  addpd xmm14, xmm7
000074fc937dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000074fc937dc837  ptest xmm12, xmm12
000074fc937dc83d  jnz 0x000074FC937E17F8
000074fc937dc843  movaps [r15+0x160], xmm14
000074fc937dc84b  movaps xmm1, xmm8
000074fc937dc84f  addpd xmm1, xmm9
000074fc937dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc937dc859  ptest xmm12, xmm12
000074fc937dc85f  jnz 0x000074FC937E193A
000074fc937dc865  movaps [r15+0x120], xmm1
000074fc937dc86d  movups [r13+r14*1], xmm15
000074fc937dc873  lea rax, [r14+0x10]
000074fc937dc877  movups [r13+rax*1], xmm13
000074fc937dc87d  lea rax, [r14+0x20]
000074fc937dc881  movups [r13+rax*1], xmm14
000074fc937dc887  lea rax, [r14+0x30]
000074fc937dc88b  movups [r13+rax*1], xmm1
000074fc937dc891  mov eax, [r15+0x108]
000074fc937dc898  sahf
000074fc937dc899  jnz 0x000074FC937DC8CB
000074fc937dc89b  cmp dword ptr [r15+0x318], 0x00
000074fc937dc8a3  jz 0x000074FC937DB900
000074fc937dc8a9  nop [rax+rax*1], ax
000074fc937dc8b2  nop [rax+rax*1], eax
000074fc937dc8ba  mov eax, 0x410444
000074fc937dc8bf  mov [r15+0x100], rax
000074fc937dc8c6  jmp 0x000074FC935FE110
000074fc937dc8cb  cmp dword ptr [r15+0x318], 0x00
000074fc937dc8d3  jz 0x000074FC937D57E0
000074fc937dc8d9  nop [rax+rax*1], ax
000074fc937dc8e2  nop [rax+rax*1], eax
000074fc937dc8ea  mov eax, 0x410278
000074fc937dc8ef  mov [r15+0x100], rax
000074fc937dc8f6  jmp 0x000074FC935FE110
000074fc937dc8fb  int3
000074fc937dc8fc  call 0x000074FC936E27E0
000074fc937dc901  jmp 0x000074FC937DB9DF
000074fc937dc906  call 0x000074FC936E1570
000074fc937dc90b  jmp 0x000074FC937DB9E8
000074fc937dc910  call 0x000074FC936E27E0
000074fc937dc915  jmp 0x000074FC937DBA44
000074fc937dc91a  call 0x000074FC936E1570
000074fc937dc91f  jmp 0x000074FC937DBA4D
000074fc937dc924  call 0x000074FC936E27E0
000074fc937dc929  jmp 0x000074FC937DBA90
000074fc937dc92e  call 0x000074FC936E1570
000074fc937dc933  jmp 0x000074FC937DBA99
000074fc937dc938  call 0x000074FC9360DC20
000074fc937dc93d  jmp 0x000074FC937DBAD8
000074fc937dc942  call 0x000074FC936D59C0
000074fc937dc947  jmp 0x000074FC937DBAEB
000074fc937dc94c  call 0x000074FC936E0E30
000074fc937dc951  jmp 0x000074FC937DBB09
000074fc937dc956  call 0x000074FC936DFBC0
000074fc937dc95b  jmp 0x000074FC937DBB13
000074fc937dc960  call 0x000074FC936DE950
000074fc937dc965  jmp 0x000074FC937DBB1D
000074fc937dc96a  sub rsp, 0x08
000074fc937dc96e  push rax
000074fc937dc96f  push rcx
000074fc937dc970  push rdx
000074fc937dc971  push rdi
000074fc937dc972  push rsi
000074fc937dc973  push r8
000074fc937dc975  push r9
000074fc937dc977  push r10
000074fc937dc979  push r11
000074fc937dc97b  sub rsp, 0xF0
000074fc937dc982  vmovaps [rsp], xmm0
000074fc937dc987  vmovaps [rsp+0x10], xmm1
000074fc937dc98d  vmovaps [rsp+0x20], xmm2
000074fc937dc993  vmovaps [rsp+0x30], xmm3
000074fc937dc999  vmovaps [rsp+0x40], xmm4
000074fc937dc99f  vmovaps [rsp+0x50], xmm5
000074fc937dc9a5  vmovaps [rsp+0x60], xmm6
000074fc937dc9ab  vmovaps [rsp+0x70], xmm7
000074fc937dc9b1  vmovaps [rsp+0x80], xmm9
000074fc937dc9ba  vmovaps [rsp+0x90], xmm10
000074fc937dc9c3  vmovaps [rsp+0xA0], xmm11
000074fc937dc9cc  vmovaps [rsp+0xB0], xmm12
000074fc937dc9d5  vmovaps [rsp+0xC0], xmm13
000074fc937dc9de  vmovaps [rsp+0xD0], xmm14
000074fc937dc9e7  vmovaps [rsp+0xE0], xmm15
000074fc937dc9f0  sub rsp, 0x30
000074fc937dc9f4  movaps [rsp], xmm8
000074fc937dc9f9  movaps [rsp+0x10], xmm12
000074fc937dc9ff  movaps [rsp+0x20], xmm15
000074fc937dca05  lea rdi, [rsp]
000074fc937dca09  mov esi, 0x00
000074fc937dca0e  mov rax, 0x5D72CBC20530
000074fc937dca18  call rax
000074fc937dca1a  movaps xmm8, [rsp]
000074fc937dca1f  add rsp, 0x30
000074fc937dca23  vmovaps xmm0, [rsp]
000074fc937dca28  vmovaps xmm1, [rsp+0x10]
000074fc937dca2e  vmovaps xmm2, [rsp+0x20]
000074fc937dca34  vmovaps xmm3, [rsp+0x30]
000074fc937dca3a  vmovaps xmm4, [rsp+0x40]
000074fc937dca40  vmovaps xmm5, [rsp+0x50]
000074fc937dca46  vmovaps xmm6, [rsp+0x60]
000074fc937dca4c  vmovaps xmm7, [rsp+0x70]
000074fc937dca52  vmovaps xmm9, [rsp+0x80]
000074fc937dca5b  vmovaps xmm10, [rsp+0x90]
000074fc937dca64  vmovaps xmm11, [rsp+0xA0]
000074fc937dca6d  vmovaps xmm12, [rsp+0xB0]
000074fc937dca76  vmovaps xmm13, [rsp+0xC0]
000074fc937dca7f  vmovaps xmm14, [rsp+0xD0]
000074fc937dca88  vmovaps xmm15, [rsp+0xE0]
000074fc937dca91  add rsp, 0xF0
000074fc937dca98  pop r11
000074fc937dca9a  pop r10
000074fc937dca9c  pop r9
000074fc937dca9e  pop r8
000074fc937dcaa0  pop rsi
000074fc937dcaa1  pop rdi
000074fc937dcaa2  pop rdx
000074fc937dcaa3  pop rcx
000074fc937dcaa4  pop rax
000074fc937dcaa5  add rsp, 0x08
000074fc937dcaa9  jmp 0x000074FC937DBB47
000074fc937dcaae  sub rsp, 0x08
000074fc937dcab2  push rax
000074fc937dcab3  push rcx
000074fc937dcab4  push rdx
000074fc937dcab5  push rdi
000074fc937dcab6  push rsi
000074fc937dcab7  push r8
000074fc937dcab9  push r9
000074fc937dcabb  push r10
000074fc937dcabd  push r11
000074fc937dcabf  sub rsp, 0xF0
000074fc937dcac6  vmovaps [rsp], xmm0
000074fc937dcacb  vmovaps [rsp+0x10], xmm1
000074fc937dcad1  vmovaps [rsp+0x20], xmm2
000074fc937dcad7  vmovaps [rsp+0x30], xmm3
000074fc937dcadd  vmovaps [rsp+0x40], xmm4
000074fc937dcae3  vmovaps [rsp+0x50], xmm5
000074fc937dcae9  vmovaps [rsp+0x60], xmm6
000074fc937dcaef  vmovaps [rsp+0x70], xmm8
000074fc937dcaf5  vmovaps [rsp+0x80], xmm9
000074fc937dcafe  vmovaps [rsp+0x90], xmm10
000074fc937dcb07  vmovaps [rsp+0xA0], xmm11
000074fc937dcb10  vmovaps [rsp+0xB0], xmm12
000074fc937dcb19  vmovaps [rsp+0xC0], xmm13
000074fc937dcb22  vmovaps [rsp+0xD0], xmm14
000074fc937dcb2b  vmovaps [rsp+0xE0], xmm15
000074fc937dcb34  sub rsp, 0x30
000074fc937dcb38  movaps [rsp], xmm7
000074fc937dcb3c  movaps [rsp+0x10], xmm9
000074fc937dcb42  movaps [rsp+0x20], xmm15
000074fc937dcb48  lea rdi, [rsp]
000074fc937dcb4c  mov esi, 0x00
000074fc937dcb51  mov rax, 0x5D72CBC20530
000074fc937dcb5b  call rax
000074fc937dcb5d  movaps xmm7, [rsp]
000074fc937dcb61  add rsp, 0x30
000074fc937dcb65  vmovaps xmm0, [rsp]
000074fc937dcb6a  vmovaps xmm1, [rsp+0x10]
000074fc937dcb70  vmovaps xmm2, [rsp+0x20]
000074fc937dcb76  vmovaps xmm3, [rsp+0x30]
000074fc937dcb7c  vmovaps xmm4, [rsp+0x40]
000074fc937dcb82  vmovaps xmm5, [rsp+0x50]
000074fc937dcb88  vmovaps xmm6, [rsp+0x60]
000074fc937dcb8e  vmovaps xmm8, [rsp+0x70]
000074fc937dcb94  vmovaps xmm9, [rsp+0x80]
000074fc937dcb9d  vmovaps xmm10, [rsp+0x90]
000074fc937dcba6  vmovaps xmm11, [rsp+0xA0]
000074fc937dcbaf  vmovaps xmm12, [rsp+0xB0]
000074fc937dcbb8  vmovaps xmm13, [rsp+0xC0]
000074fc937dcbc1  vmovaps xmm14, [rsp+0xD0]
000074fc937dcbca  vmovaps xmm15, [rsp+0xE0]
000074fc937dcbd3  add rsp, 0xF0
000074fc937dcbda  pop r11
000074fc937dcbdc  pop r10
000074fc937dcbde  pop r9
000074fc937dcbe0  pop r8
000074fc937dcbe2  pop rsi
000074fc937dcbe3  pop rdi
000074fc937dcbe4  pop rdx
000074fc937dcbe5  pop rcx
000074fc937dcbe6  pop rax
000074fc937dcbe7  add rsp, 0x08
000074fc937dcbeb  jmp 0x000074FC937DBB75
000074fc937dcbf0  sub rsp, 0x08
000074fc937dcbf4  push rax
000074fc937dcbf5  push rcx
000074fc937dcbf6  push rdx
000074fc937dcbf7  push rdi
000074fc937dcbf8  push rsi
000074fc937dcbf9  push r8
000074fc937dcbfb  push r9
000074fc937dcbfd  push r10
000074fc937dcbff  push r11
000074fc937dcc01  sub rsp, 0xF0
000074fc937dcc08  vmovaps [rsp], xmm0
000074fc937dcc0d  vmovaps [rsp+0x10], xmm1
000074fc937dcc13  vmovaps [rsp+0x20], xmm2
000074fc937dcc19  vmovaps [rsp+0x30], xmm3
000074fc937dcc1f  vmovaps [rsp+0x40], xmm4
000074fc937dcc25  vmovaps [rsp+0x50], xmm5
000074fc937dcc2b  vmovaps [rsp+0x60], xmm6
000074fc937dcc31  vmovaps [rsp+0x70], xmm7
000074fc937dcc37  vmovaps [rsp+0x80], xmm8
000074fc937dcc40  vmovaps [rsp+0x90], xmm10
000074fc937dcc49  vmovaps [rsp+0xA0], xmm11
000074fc937dcc52  vmovaps [rsp+0xB0], xmm12
000074fc937dcc5b  vmovaps [rsp+0xC0], xmm13
000074fc937dcc64  vmovaps [rsp+0xD0], xmm14
000074fc937dcc6d  vmovaps [rsp+0xE0], xmm15
000074fc937dcc76  sub rsp, 0x30
000074fc937dcc7a  movaps [rsp], xmm9
000074fc937dcc7f  movaps [rsp+0x10], xmm12
000074fc937dcc85  movaps [rsp+0x20], xmm10
000074fc937dcc8b  lea rdi, [rsp]
000074fc937dcc8f  mov esi, 0x00
000074fc937dcc94  mov rax, 0x5D72CBC20530
000074fc937dcc9e  call rax
000074fc937dcca0  movaps xmm9, [rsp]
000074fc937dcca5  add rsp, 0x30
000074fc937dcca9  vmovaps xmm0, [rsp]
000074fc937dccae  vmovaps xmm1, [rsp+0x10]
000074fc937dccb4  vmovaps xmm2, [rsp+0x20]
000074fc937dccba  vmovaps xmm3, [rsp+0x30]
000074fc937dccc0  vmovaps xmm4, [rsp+0x40]
000074fc937dccc6  vmovaps xmm5, [rsp+0x50]
000074fc937dcccc  vmovaps xmm6, [rsp+0x60]
000074fc937dccd2  vmovaps xmm7, [rsp+0x70]
000074fc937dccd8  vmovaps xmm8, [rsp+0x80]
000074fc937dcce1  vmovaps xmm10, [rsp+0x90]
000074fc937dccea  vmovaps xmm11, [rsp+0xA0]
000074fc937dccf3  vmovaps xmm12, [rsp+0xB0]
000074fc937dccfc  vmovaps xmm13, [rsp+0xC0]
000074fc937dcd05  vmovaps xmm14, [rsp+0xD0]
000074fc937dcd0e  vmovaps xmm15, [rsp+0xE0]
000074fc937dcd17  add rsp, 0xF0
000074fc937dcd1e  pop r11
000074fc937dcd20  pop r10
000074fc937dcd22  pop r9
000074fc937dcd24  pop r8
000074fc937dcd26  pop rsi
000074fc937dcd27  pop rdi
000074fc937dcd28  pop rdx
000074fc937dcd29  pop rcx
000074fc937dcd2a  pop rax
000074fc937dcd2b  add rsp, 0x08
000074fc937dcd2f  jmp 0x000074FC937DBB99
000074fc937dcd34  sub rsp, 0x08
000074fc937dcd38  push rax
000074fc937dcd39  push rcx
000074fc937dcd3a  push rdx
000074fc937dcd3b  push rdi
000074fc937dcd3c  push rsi
000074fc937dcd3d  push r8
000074fc937dcd3f  push r9
000074fc937dcd41  push r10
000074fc937dcd43  push r11
000074fc937dcd45  sub rsp, 0xF0
000074fc937dcd4c  vmovaps [rsp], xmm0
000074fc937dcd51  vmovaps [rsp+0x10], xmm1
000074fc937dcd57  vmovaps [rsp+0x20], xmm2
000074fc937dcd5d  vmovaps [rsp+0x30], xmm3
000074fc937dcd63  vmovaps [rsp+0x40], xmm4
000074fc937dcd69  vmovaps [rsp+0x50], xmm5
000074fc937dcd6f  vmovaps [rsp+0x60], xmm6
000074fc937dcd75  vmovaps [rsp+0x70], xmm7
000074fc937dcd7b  vmovaps [rsp+0x80], xmm8
000074fc937dcd84  vmovaps [rsp+0x90], xmm9
000074fc937dcd8d  vmovaps [rsp+0xA0], xmm11
000074fc937dcd96  vmovaps [rsp+0xB0], xmm12
000074fc937dcd9f  vmovaps [rsp+0xC0], xmm13
000074fc937dcda8  vmovaps [rsp+0xD0], xmm14
000074fc937dcdb1  vmovaps [rsp+0xE0], xmm15
000074fc937dcdba  sub rsp, 0x30
000074fc937dcdbe  movaps [rsp], xmm10
000074fc937dcdc3  movaps [rsp+0x10], xmm12
000074fc937dcdc9  movaps [rsp+0x20], xmm11
000074fc937dcdcf  lea rdi, [rsp]
000074fc937dcdd3  mov esi, 0x00
000074fc937dcdd8  mov rax, 0x5D72CBC20530
000074fc937dcde2  call rax
000074fc937dcde4  movaps xmm10, [rsp]
000074fc937dcde9  add rsp, 0x30
000074fc937dcded  vmovaps xmm0, [rsp]
000074fc937dcdf2  vmovaps xmm1, [rsp+0x10]
000074fc937dcdf8  vmovaps xmm2, [rsp+0x20]
000074fc937dcdfe  vmovaps xmm3, [rsp+0x30]
000074fc937dce04  vmovaps xmm4, [rsp+0x40]
000074fc937dce0a  vmovaps xmm5, [rsp+0x50]
000074fc937dce10  vmovaps xmm6, [rsp+0x60]
000074fc937dce16  vmovaps xmm7, [rsp+0x70]
000074fc937dce1c  vmovaps xmm8, [rsp+0x80]
000074fc937dce25  vmovaps xmm9, [rsp+0x90]
000074fc937dce2e  vmovaps xmm11, [rsp+0xA0]
000074fc937dce37  vmovaps xmm12, [rsp+0xB0]
000074fc937dce40  vmovaps xmm13, [rsp+0xC0]
000074fc937dce49  vmovaps xmm14, [rsp+0xD0]
000074fc937dce52  vmovaps xmm15, [rsp+0xE0]
000074fc937dce5b  add rsp, 0xF0
000074fc937dce62  pop r11
000074fc937dce64  pop r10
000074fc937dce66  pop r9
000074fc937dce68  pop r8
000074fc937dce6a  pop rsi
000074fc937dce6b  pop rdi
000074fc937dce6c  pop rdx
000074fc937dce6d  pop rcx
000074fc937dce6e  pop rax
000074fc937dce6f  add rsp, 0x08
000074fc937dce73  jmp 0x000074FC937DBBB3
000074fc937dce78  sub rsp, 0x08
000074fc937dce7c  push rax
000074fc937dce7d  push rcx
000074fc937dce7e  push rdx
000074fc937dce7f  push rdi
000074fc937dce80  push rsi
000074fc937dce81  push r8
000074fc937dce83  push r9
000074fc937dce85  push r10
000074fc937dce87  push r11
000074fc937dce89  sub rsp, 0xF0
000074fc937dce90  vmovaps [rsp], xmm0
000074fc937dce95  vmovaps [rsp+0x10], xmm1
000074fc937dce9b  vmovaps [rsp+0x20], xmm2
000074fc937dcea1  vmovaps [rsp+0x30], xmm3
000074fc937dcea7  vmovaps [rsp+0x40], xmm4
000074fc937dcead  vmovaps [rsp+0x50], xmm5
000074fc937dceb3  vmovaps [rsp+0x60], xmm7
000074fc937dceb9  vmovaps [rsp+0x70], xmm8
000074fc937dcebf  vmovaps [rsp+0x80], xmm9
000074fc937dcec8  vmovaps [rsp+0x90], xmm10
000074fc937dced1  vmovaps [rsp+0xA0], xmm11
000074fc937dceda  vmovaps [rsp+0xB0], xmm12
000074fc937dcee3  vmovaps [rsp+0xC0], xmm13
000074fc937dceec  vmovaps [rsp+0xD0], xmm14
000074fc937dcef5  vmovaps [rsp+0xE0], xmm15
000074fc937dcefe  sub rsp, 0x30
000074fc937dcf02  movaps [rsp], xmm6
000074fc937dcf06  movaps [rsp+0x10], xmm12
000074fc937dcf0c  movaps [rsp+0x20], xmm11
000074fc937dcf12  lea rdi, [rsp]
000074fc937dcf16  mov esi, 0x00
000074fc937dcf1b  mov rax, 0x5D72CBC20530
000074fc937dcf25  call rax
000074fc937dcf27  movaps xmm6, [rsp]
000074fc937dcf2b  add rsp, 0x30
000074fc937dcf2f  vmovaps xmm0, [rsp]
000074fc937dcf34  vmovaps xmm1, [rsp+0x10]
000074fc937dcf3a  vmovaps xmm2, [rsp+0x20]
000074fc937dcf40  vmovaps xmm3, [rsp+0x30]
000074fc937dcf46  vmovaps xmm4, [rsp+0x40]
000074fc937dcf4c  vmovaps xmm5, [rsp+0x50]
000074fc937dcf52  vmovaps xmm7, [rsp+0x60]
000074fc937dcf58  vmovaps xmm8, [rsp+0x70]
000074fc937dcf5e  vmovaps xmm9, [rsp+0x80]
000074fc937dcf67  vmovaps xmm10, [rsp+0x90]
000074fc937dcf70  vmovaps xmm11, [rsp+0xA0]
000074fc937dcf79  vmovaps xmm12, [rsp+0xB0]
000074fc937dcf82  vmovaps xmm13, [rsp+0xC0]
000074fc937dcf8b  vmovaps xmm14, [rsp+0xD0]
000074fc937dcf94  vmovaps xmm15, [rsp+0xE0]
000074fc937dcf9d  add rsp, 0xF0
000074fc937dcfa4  pop r11
000074fc937dcfa6  pop r10
000074fc937dcfa8  pop r9
000074fc937dcfaa  pop r8
000074fc937dcfac  pop rsi
000074fc937dcfad  pop rdi
000074fc937dcfae  pop rdx
000074fc937dcfaf  pop rcx
000074fc937dcfb0  pop rax
000074fc937dcfb1  add rsp, 0x08
000074fc937dcfb5  jmp 0x000074FC937DBBD4
000074fc937dcfba  sub rsp, 0x08
000074fc937dcfbe  push rax
000074fc937dcfbf  push rcx
000074fc937dcfc0  push rdx
000074fc937dcfc1  push rdi
000074fc937dcfc2  push rsi
000074fc937dcfc3  push r8
000074fc937dcfc5  push r9
000074fc937dcfc7  push r10
000074fc937dcfc9  push r11
000074fc937dcfcb  sub rsp, 0xF0
000074fc937dcfd2  vmovaps [rsp], xmm0
000074fc937dcfd7  vmovaps [rsp+0x10], xmm1
000074fc937dcfdd  vmovaps [rsp+0x20], xmm2
000074fc937dcfe3  vmovaps [rsp+0x30], xmm4
000074fc937dcfe9  vmovaps [rsp+0x40], xmm5
000074fc937dcfef  vmovaps [rsp+0x50], xmm6
000074fc937dcff5  vmovaps [rsp+0x60], xmm7
000074fc937dcffb  vmovaps [rsp+0x70], xmm8
000074fc937dd001  vmovaps [rsp+0x80], xmm9
000074fc937dd00a  vmovaps [rsp+0x90], xmm10
000074fc937dd013  vmovaps [rsp+0xA0], xmm11
000074fc937dd01c  vmovaps [rsp+0xB0], xmm12
000074fc937dd025  vmovaps [rsp+0xC0], xmm13
000074fc937dd02e  vmovaps [rsp+0xD0], xmm14
000074fc937dd037  vmovaps [rsp+0xE0], xmm15
000074fc937dd040  sub rsp, 0x30
000074fc937dd044  movaps [rsp], xmm3
000074fc937dd048  movaps [rsp+0x10], xmm5
000074fc937dd04d  movaps [rsp+0x20], xmm4
000074fc937dd052  lea rdi, [rsp]
000074fc937dd056  mov esi, 0x00
000074fc937dd05b  mov rax, 0x5D72CBC20530
000074fc937dd065  call rax
000074fc937dd067  movaps xmm3, [rsp]
000074fc937dd06b  add rsp, 0x30
000074fc937dd06f  vmovaps xmm0, [rsp]
000074fc937dd074  vmovaps xmm1, [rsp+0x10]
000074fc937dd07a  vmovaps xmm2, [rsp+0x20]
000074fc937dd080  vmovaps xmm4, [rsp+0x30]
000074fc937dd086  vmovaps xmm5, [rsp+0x40]
000074fc937dd08c  vmovaps xmm6, [rsp+0x50]
000074fc937dd092  vmovaps xmm7, [rsp+0x60]
000074fc937dd098  vmovaps xmm8, [rsp+0x70]
000074fc937dd09e  vmovaps xmm9, [rsp+0x80]
000074fc937dd0a7  vmovaps xmm10, [rsp+0x90]
000074fc937dd0b0  vmovaps xmm11, [rsp+0xA0]
000074fc937dd0b9  vmovaps xmm12, [rsp+0xB0]
000074fc937dd0c2  vmovaps xmm13, [rsp+0xC0]
000074fc937dd0cb  vmovaps xmm14, [rsp+0xD0]
000074fc937dd0d4  vmovaps xmm15, [rsp+0xE0]
000074fc937dd0dd  add rsp, 0xF0
000074fc937dd0e4  pop r11
000074fc937dd0e6  pop r10
000074fc937dd0e8  pop r9
000074fc937dd0ea  pop r8
000074fc937dd0ec  pop rsi
000074fc937dd0ed  pop rdi
000074fc937dd0ee  pop rdx
000074fc937dd0ef  pop rcx
000074fc937dd0f0  pop rax
000074fc937dd0f1  add rsp, 0x08
000074fc937dd0f5  jmp 0x000074FC937DBC35
000074fc937dd0fa  sub rsp, 0x08
000074fc937dd0fe  push rax
000074fc937dd0ff  push rcx
000074fc937dd100  push rdx
000074fc937dd101  push rdi
000074fc937dd102  push rsi
000074fc937dd103  push r8
000074fc937dd105  push r9
000074fc937dd107  push r10
000074fc937dd109  push r11
000074fc937dd10b  sub rsp, 0xF0
000074fc937dd112  vmovaps [rsp], xmm0
000074fc937dd117  vmovaps [rsp+0x10], xmm1
000074fc937dd11d  vmovaps [rsp+0x20], xmm2
000074fc937dd123  vmovaps [rsp+0x30], xmm3
000074fc937dd129  vmovaps [rsp+0x40], xmm4
000074fc937dd12f  vmovaps [rsp+0x50], xmm6
000074fc937dd135  vmovaps [rsp+0x60], xmm7
000074fc937dd13b  vmovaps [rsp+0x70], xmm8
000074fc937dd141  vmovaps [rsp+0x80], xmm9
000074fc937dd14a  vmovaps [rsp+0x90], xmm10
000074fc937dd153  vmovaps [rsp+0xA0], xmm11
000074fc937dd15c  vmovaps [rsp+0xB0], xmm12
000074fc937dd165  vmovaps [rsp+0xC0], xmm13
000074fc937dd16e  vmovaps [rsp+0xD0], xmm14
000074fc937dd177  vmovaps [rsp+0xE0], xmm15
000074fc937dd180  sub rsp, 0x30
000074fc937dd184  movaps [rsp], xmm5
000074fc937dd188  movaps [rsp+0x10], xmm8
000074fc937dd18e  movaps [rsp+0x20], xmm15
000074fc937dd194  lea rdi, [rsp]
000074fc937dd198  mov esi, 0x00
000074fc937dd19d  mov rax, 0x5D72CBC20530
000074fc937dd1a7  call rax
000074fc937dd1a9  movaps xmm5, [rsp]
000074fc937dd1ad  add rsp, 0x30
000074fc937dd1b1  vmovaps xmm0, [rsp]
000074fc937dd1b6  vmovaps xmm1, [rsp+0x10]
000074fc937dd1bc  vmovaps xmm2, [rsp+0x20]
000074fc937dd1c2  vmovaps xmm3, [rsp+0x30]
000074fc937dd1c8  vmovaps xmm4, [rsp+0x40]
000074fc937dd1ce  vmovaps xmm6, [rsp+0x50]
000074fc937dd1d4  vmovaps xmm7, [rsp+0x60]
000074fc937dd1da  vmovaps xmm8, [rsp+0x70]
000074fc937dd1e0  vmovaps xmm9, [rsp+0x80]
000074fc937dd1e9  vmovaps xmm10, [rsp+0x90]
000074fc937dd1f2  vmovaps xmm11, [rsp+0xA0]
000074fc937dd1fb  vmovaps xmm12, [rsp+0xB0]
000074fc937dd204  vmovaps xmm13, [rsp+0xC0]
000074fc937dd20d  vmovaps xmm14, [rsp+0xD0]
000074fc937dd216  vmovaps xmm15, [rsp+0xE0]
000074fc937dd21f  add rsp, 0xF0
000074fc937dd226  pop r11
000074fc937dd228  pop r10
000074fc937dd22a  pop r9
000074fc937dd22c  pop r8
000074fc937dd22e  pop rsi
000074fc937dd22f  pop rdi
000074fc937dd230  pop rdx
000074fc937dd231  pop rcx
000074fc937dd232  pop rax
000074fc937dd233  add rsp, 0x08
000074fc937dd237  jmp 0x000074FC937DBC73
000074fc937dd23c  sub rsp, 0x08
000074fc937dd240  push rax
000074fc937dd241  push rcx
000074fc937dd242  push rdx
000074fc937dd243  push rdi
000074fc937dd244  push rsi
000074fc937dd245  push r8
000074fc937dd247  push r9
000074fc937dd249  push r10
000074fc937dd24b  push r11
000074fc937dd24d  sub rsp, 0xF0
000074fc937dd254  vmovaps [rsp], xmm0
000074fc937dd259  vmovaps [rsp+0x10], xmm1
000074fc937dd25f  vmovaps [rsp+0x20], xmm2
000074fc937dd265  vmovaps [rsp+0x30], xmm3
000074fc937dd26b  vmovaps [rsp+0x40], xmm5
000074fc937dd271  vmovaps [rsp+0x50], xmm6
000074fc937dd277  vmovaps [rsp+0x60], xmm7
000074fc937dd27d  vmovaps [rsp+0x70], xmm8
000074fc937dd283  vmovaps [rsp+0x80], xmm9
000074fc937dd28c  vmovaps [rsp+0x90], xmm10
000074fc937dd295  vmovaps [rsp+0xA0], xmm11
000074fc937dd29e  vmovaps [rsp+0xB0], xmm12
000074fc937dd2a7  vmovaps [rsp+0xC0], xmm13
000074fc937dd2b0  vmovaps [rsp+0xD0], xmm14
000074fc937dd2b9  vmovaps [rsp+0xE0], xmm15
000074fc937dd2c2  sub rsp, 0x30
000074fc937dd2c6  movaps [rsp], xmm4
000074fc937dd2ca  movaps [rsp+0x10], xmm9
000074fc937dd2d0  movaps [rsp+0x20], xmm8
000074fc937dd2d6  lea rdi, [rsp]
000074fc937dd2da  mov esi, 0x00
000074fc937dd2df  mov rax, 0x5D72CBC20530
000074fc937dd2e9  call rax
000074fc937dd2eb  movaps xmm4, [rsp]
000074fc937dd2ef  add rsp, 0x30
000074fc937dd2f3  vmovaps xmm0, [rsp]
000074fc937dd2f8  vmovaps xmm1, [rsp+0x10]
000074fc937dd2fe  vmovaps xmm2, [rsp+0x20]
000074fc937dd304  vmovaps xmm3, [rsp+0x30]
000074fc937dd30a  vmovaps xmm5, [rsp+0x40]
000074fc937dd310  vmovaps xmm6, [rsp+0x50]
000074fc937dd316  vmovaps xmm7, [rsp+0x60]
000074fc937dd31c  vmovaps xmm8, [rsp+0x70]
000074fc937dd322  vmovaps xmm9, [rsp+0x80]
000074fc937dd32b  vmovaps xmm10, [rsp+0x90]
000074fc937dd334  vmovaps xmm11, [rsp+0xA0]
000074fc937dd33d  vmovaps xmm12, [rsp+0xB0]
000074fc937dd346  vmovaps xmm13, [rsp+0xC0]
000074fc937dd34f  vmovaps xmm14, [rsp+0xD0]
000074fc937dd358  vmovaps xmm15, [rsp+0xE0]
000074fc937dd361  add rsp, 0xF0
000074fc937dd368  pop r11
000074fc937dd36a  pop r10
000074fc937dd36c  pop r9
000074fc937dd36e  pop r8
000074fc937dd370  pop rsi
000074fc937dd371  pop rdi
000074fc937dd372  pop rdx
000074fc937dd373  pop rcx
000074fc937dd374  pop rax
000074fc937dd375  add rsp, 0x08
000074fc937dd379  jmp 0x000074FC937DBC94
000074fc937dd37e  sub rsp, 0x08
000074fc937dd382  push rax
000074fc937dd383  push rcx
000074fc937dd384  push rdx
000074fc937dd385  push rdi
000074fc937dd386  push rsi
000074fc937dd387  push r8
000074fc937dd389  push r9
000074fc937dd38b  push r10
000074fc937dd38d  push r11
000074fc937dd38f  sub rsp, 0xF0
000074fc937dd396  vmovaps [rsp], xmm0
000074fc937dd39b  vmovaps [rsp+0x10], xmm1
000074fc937dd3a1  vmovaps [rsp+0x20], xmm2
000074fc937dd3a7  vmovaps [rsp+0x30], xmm3
000074fc937dd3ad  vmovaps [rsp+0x40], xmm4
000074fc937dd3b3  vmovaps [rsp+0x50], xmm5
000074fc937dd3b9  vmovaps [rsp+0x60], xmm6
000074fc937dd3bf  vmovaps [rsp+0x70], xmm7
000074fc937dd3c5  vmovaps [rsp+0x80], xmm8
000074fc937dd3ce  vmovaps [rsp+0x90], xmm10
000074fc937dd3d7  vmovaps [rsp+0xA0], xmm11
000074fc937dd3e0  vmovaps [rsp+0xB0], xmm12
000074fc937dd3e9  vmovaps [rsp+0xC0], xmm13
000074fc937dd3f2  vmovaps [rsp+0xD0], xmm14
000074fc937dd3fb  vmovaps [rsp+0xE0], xmm15
000074fc937dd404  sub rsp, 0x30
000074fc937dd408  movaps [rsp], xmm9
000074fc937dd40d  movaps [rsp+0x10], xmm10
000074fc937dd413  movaps [rsp+0x20], xmm8
000074fc937dd419  lea rdi, [rsp]
000074fc937dd41d  mov esi, 0x00
000074fc937dd422  mov rax, 0x5D72CBC20530
000074fc937dd42c  call rax
000074fc937dd42e  movaps xmm9, [rsp]
000074fc937dd433  add rsp, 0x30
000074fc937dd437  vmovaps xmm0, [rsp]
000074fc937dd43c  vmovaps xmm1, [rsp+0x10]
000074fc937dd442  vmovaps xmm2, [rsp+0x20]
000074fc937dd448  vmovaps xmm3, [rsp+0x30]
000074fc937dd44e  vmovaps xmm4, [rsp+0x40]
000074fc937dd454  vmovaps xmm5, [rsp+0x50]
000074fc937dd45a  vmovaps xmm6, [rsp+0x60]
000074fc937dd460  vmovaps xmm7, [rsp+0x70]
000074fc937dd466  vmovaps xmm8, [rsp+0x80]
000074fc937dd46f  vmovaps xmm10, [rsp+0x90]
000074fc937dd478  vmovaps xmm11, [rsp+0xA0]
000074fc937dd481  vmovaps xmm12, [rsp+0xB0]
000074fc937dd48a  vmovaps xmm13, [rsp+0xC0]
000074fc937dd493  vmovaps xmm14, [rsp+0xD0]
000074fc937dd49c  vmovaps xmm15, [rsp+0xE0]
000074fc937dd4a5  add rsp, 0xF0
000074fc937dd4ac  pop r11
000074fc937dd4ae  pop r10
000074fc937dd4b0  pop r9
000074fc937dd4b2  pop r8
000074fc937dd4b4  pop rsi
000074fc937dd4b5  pop rdi
000074fc937dd4b6  pop rdx
000074fc937dd4b7  pop rcx
000074fc937dd4b8  pop rax
000074fc937dd4b9  add rsp, 0x08
000074fc937dd4bd  jmp 0x000074FC937DBCAE
000074fc937dd4c2  call 0x000074FC936B52F0
000074fc937dd4c7  jmp 0x000074FC937DBDC8
000074fc937dd4cc  call 0x000074FC936B52F0
000074fc937dd4d1  jmp 0x000074FC937DBDDE
000074fc937dd4d6  sub rsp, 0x08
000074fc937dd4da  push rax
000074fc937dd4db  push rcx
000074fc937dd4dc  push rdx
000074fc937dd4dd  push rdi
000074fc937dd4de  push rsi
000074fc937dd4df  push r8
000074fc937dd4e1  push r9
000074fc937dd4e3  push r10
000074fc937dd4e5  push r11
000074fc937dd4e7  sub rsp, 0xF0
000074fc937dd4ee  vmovaps [rsp], xmm0
000074fc937dd4f3  vmovaps [rsp+0x10], xmm2
000074fc937dd4f9  vmovaps [rsp+0x20], xmm3
000074fc937dd4ff  vmovaps [rsp+0x30], xmm4
000074fc937dd505  vmovaps [rsp+0x40], xmm5
000074fc937dd50b  vmovaps [rsp+0x50], xmm6
000074fc937dd511  vmovaps [rsp+0x60], xmm7
000074fc937dd517  vmovaps [rsp+0x70], xmm8
000074fc937dd51d  vmovaps [rsp+0x80], xmm9
000074fc937dd526  vmovaps [rsp+0x90], xmm10
000074fc937dd52f  vmovaps [rsp+0xA0], xmm11
000074fc937dd538  vmovaps [rsp+0xB0], xmm12
000074fc937dd541  vmovaps [rsp+0xC0], xmm13
000074fc937dd54a  vmovaps [rsp+0xD0], xmm14
000074fc937dd553  vmovaps [rsp+0xE0], xmm15
000074fc937dd55c  sub rsp, 0x30
000074fc937dd560  movaps [rsp], xmm1
000074fc937dd564  movaps [rsp+0x10], xmm6
000074fc937dd569  movaps [rsp+0x20], xmm15
000074fc937dd56f  lea rdi, [rsp]
000074fc937dd573  mov esi, 0x00
000074fc937dd578  mov rax, 0x5D72CBC20530
000074fc937dd582  call rax
000074fc937dd584  movaps xmm1, [rsp]
000074fc937dd588  add rsp, 0x30
000074fc937dd58c  vmovaps xmm0, [rsp]
000074fc937dd591  vmovaps xmm2, [rsp+0x10]
000074fc937dd597  vmovaps xmm3, [rsp+0x20]
000074fc937dd59d  vmovaps xmm4, [rsp+0x30]
000074fc937dd5a3  vmovaps xmm5, [rsp+0x40]
000074fc937dd5a9  vmovaps xmm6, [rsp+0x50]
000074fc937dd5af  vmovaps xmm7, [rsp+0x60]
000074fc937dd5b5  vmovaps xmm8, [rsp+0x70]
000074fc937dd5bb  vmovaps xmm9, [rsp+0x80]
000074fc937dd5c4  vmovaps xmm10, [rsp+0x90]
000074fc937dd5cd  vmovaps xmm11, [rsp+0xA0]
000074fc937dd5d6  vmovaps xmm12, [rsp+0xB0]
000074fc937dd5df  vmovaps xmm13, [rsp+0xC0]
000074fc937dd5e8  vmovaps xmm14, [rsp+0xD0]
000074fc937dd5f1  vmovaps xmm15, [rsp+0xE0]
000074fc937dd5fa  add rsp, 0xF0
000074fc937dd601  pop r11
000074fc937dd603  pop r10
000074fc937dd605  pop r9
000074fc937dd607  pop r8
000074fc937dd609  pop rsi
000074fc937dd60a  pop rdi
000074fc937dd60b  pop rdx
000074fc937dd60c  pop rcx
000074fc937dd60d  pop rax
000074fc937dd60e  add rsp, 0x08
000074fc937dd612  jmp 0x000074FC937DBE1B
000074fc937dd617  call 0x000074FC936C4620
000074fc937dd61c  jmp 0x000074FC937DBE28
000074fc937dd621  sub rsp, 0x08
000074fc937dd625  push rax
000074fc937dd626  push rcx
000074fc937dd627  push rdx
000074fc937dd628  push rdi
000074fc937dd629  push rsi
000074fc937dd62a  push r8
000074fc937dd62c  push r9
000074fc937dd62e  push r10
000074fc937dd630  push r11
000074fc937dd632  sub rsp, 0xF0
000074fc937dd639  vmovaps [rsp], xmm0
000074fc937dd63e  vmovaps [rsp+0x10], xmm1
000074fc937dd644  vmovaps [rsp+0x20], xmm2
000074fc937dd64a  vmovaps [rsp+0x30], xmm3
000074fc937dd650  vmovaps [rsp+0x40], xmm4
000074fc937dd656  vmovaps [rsp+0x50], xmm5
000074fc937dd65c  vmovaps [rsp+0x60], xmm6
000074fc937dd662  vmovaps [rsp+0x70], xmm7
000074fc937dd668  vmovaps [rsp+0x80], xmm8
000074fc937dd671  vmovaps [rsp+0x90], xmm9
000074fc937dd67a  vmovaps [rsp+0xA0], xmm10
000074fc937dd683  vmovaps [rsp+0xB0], xmm11
000074fc937dd68c  vmovaps [rsp+0xC0], xmm12
000074fc937dd695  vmovaps [rsp+0xD0], xmm13
000074fc937dd69e  vmovaps [rsp+0xE0], xmm15
000074fc937dd6a7  sub rsp, 0x30
000074fc937dd6ab  movaps [rsp], xmm14
000074fc937dd6b0  movaps [rsp+0x10], xmm4
000074fc937dd6b5  movaps [rsp+0x20], xmm3
000074fc937dd6ba  lea rdi, [rsp]
000074fc937dd6be  mov esi, 0x00
000074fc937dd6c3  mov rax, 0x5D72CBC20530
000074fc937dd6cd  call rax
000074fc937dd6cf  movaps xmm14, [rsp]
000074fc937dd6d4  add rsp, 0x30
000074fc937dd6d8  vmovaps xmm0, [rsp]
000074fc937dd6dd  vmovaps xmm1, [rsp+0x10]
000074fc937dd6e3  vmovaps xmm2, [rsp+0x20]
000074fc937dd6e9  vmovaps xmm3, [rsp+0x30]
000074fc937dd6ef  vmovaps xmm4, [rsp+0x40]
000074fc937dd6f5  vmovaps xmm5, [rsp+0x50]
000074fc937dd6fb  vmovaps xmm6, [rsp+0x60]
000074fc937dd701  vmovaps xmm7, [rsp+0x70]
000074fc937dd707  vmovaps xmm8, [rsp+0x80]
000074fc937dd710  vmovaps xmm9, [rsp+0x90]
000074fc937dd719  vmovaps xmm10, [rsp+0xA0]
000074fc937dd722  vmovaps xmm11, [rsp+0xB0]
000074fc937dd72b  vmovaps xmm12, [rsp+0xC0]
000074fc937dd734  vmovaps xmm13, [rsp+0xD0]
000074fc937dd73d  vmovaps xmm15, [rsp+0xE0]
000074fc937dd746  add rsp, 0xF0
000074fc937dd74d  pop r11
000074fc937dd74f  pop r10
000074fc937dd751  pop r9
000074fc937dd753  pop r8
000074fc937dd755  pop rsi
000074fc937dd756  pop rdi
000074fc937dd757  pop rdx
000074fc937dd758  pop rcx
000074fc937dd759  pop rax
000074fc937dd75a  add rsp, 0x08
000074fc937dd75e  jmp 0x000074FC937DBE42
000074fc937dd763  sub rsp, 0x08
000074fc937dd767  push rax
000074fc937dd768  push rcx
000074fc937dd769  push rdx
000074fc937dd76a  push rdi
000074fc937dd76b  push rsi
000074fc937dd76c  push r8
000074fc937dd76e  push r9
000074fc937dd770  push r10
000074fc937dd772  push r11
000074fc937dd774  sub rsp, 0xF0
000074fc937dd77b  vmovaps [rsp], xmm0
000074fc937dd780  vmovaps [rsp+0x10], xmm1
000074fc937dd786  vmovaps [rsp+0x20], xmm2
000074fc937dd78c  vmovaps [rsp+0x30], xmm3
000074fc937dd792  vmovaps [rsp+0x40], xmm4
000074fc937dd798  vmovaps [rsp+0x50], xmm5
000074fc937dd79e  vmovaps [rsp+0x60], xmm7
000074fc937dd7a4  vmovaps [rsp+0x70], xmm8
000074fc937dd7aa  vmovaps [rsp+0x80], xmm9
000074fc937dd7b3  vmovaps [rsp+0x90], xmm10
000074fc937dd7bc  vmovaps [rsp+0xA0], xmm11
000074fc937dd7c5  vmovaps [rsp+0xB0], xmm12
000074fc937dd7ce  vmovaps [rsp+0xC0], xmm13
000074fc937dd7d7  vmovaps [rsp+0xD0], xmm14
000074fc937dd7e0  vmovaps [rsp+0xE0], xmm15
000074fc937dd7e9  sub rsp, 0x30
000074fc937dd7ed  movaps [rsp], xmm6
000074fc937dd7f1  movaps [rsp+0x10], xmm9
000074fc937dd7f7  movaps [rsp+0x20], xmm7
000074fc937dd7fc  lea rdi, [rsp]
000074fc937dd800  mov esi, 0x00
000074fc937dd805  mov rax, 0x5D72CBC20530
000074fc937dd80f  call rax
000074fc937dd811  movaps xmm6, [rsp]
000074fc937dd815  add rsp, 0x30
000074fc937dd819  vmovaps xmm0, [rsp]
000074fc937dd81e  vmovaps xmm1, [rsp+0x10]
000074fc937dd824  vmovaps xmm2, [rsp+0x20]
000074fc937dd82a  vmovaps xmm3, [rsp+0x30]
000074fc937dd830  vmovaps xmm4, [rsp+0x40]
000074fc937dd836  vmovaps xmm5, [rsp+0x50]
000074fc937dd83c  vmovaps xmm7, [rsp+0x60]
000074fc937dd842  vmovaps xmm8, [rsp+0x70]
000074fc937dd848  vmovaps xmm9, [rsp+0x80]
000074fc937dd851  vmovaps xmm10, [rsp+0x90]
000074fc937dd85a  vmovaps xmm11, [rsp+0xA0]
000074fc937dd863  vmovaps xmm12, [rsp+0xB0]
000074fc937dd86c  vmovaps xmm13, [rsp+0xC0]
000074fc937dd875  vmovaps xmm14, [rsp+0xD0]
000074fc937dd87e  vmovaps xmm15, [rsp+0xE0]
000074fc937dd887  add rsp, 0xF0
000074fc937dd88e  pop r11
000074fc937dd890  pop r10
000074fc937dd892  pop r9
000074fc937dd894  pop r8
000074fc937dd896  pop rsi
000074fc937dd897  pop rdi
000074fc937dd898  pop rdx
000074fc937dd899  pop rcx
000074fc937dd89a  pop rax
000074fc937dd89b  add rsp, 0x08
000074fc937dd89f  jmp 0x000074FC937DBE5A
000074fc937dd8a4  sub rsp, 0x08
000074fc937dd8a8  push rax
000074fc937dd8a9  push rcx
000074fc937dd8aa  push rdx
000074fc937dd8ab  push rdi
000074fc937dd8ac  push rsi
000074fc937dd8ad  push r8
000074fc937dd8af  push r9
000074fc937dd8b1  push r10
000074fc937dd8b3  push r11
000074fc937dd8b5  sub rsp, 0xF0
000074fc937dd8bc  vmovaps [rsp], xmm0
000074fc937dd8c1  vmovaps [rsp+0x10], xmm1
000074fc937dd8c7  vmovaps [rsp+0x20], xmm2
000074fc937dd8cd  vmovaps [rsp+0x30], xmm3
000074fc937dd8d3  vmovaps [rsp+0x40], xmm4
000074fc937dd8d9  vmovaps [rsp+0x50], xmm5
000074fc937dd8df  vmovaps [rsp+0x60], xmm6
000074fc937dd8e5  vmovaps [rsp+0x70], xmm8
000074fc937dd8eb  vmovaps [rsp+0x80], xmm9
000074fc937dd8f4  vmovaps [rsp+0x90], xmm10
000074fc937dd8fd  vmovaps [rsp+0xA0], xmm11
000074fc937dd906  vmovaps [rsp+0xB0], xmm12
000074fc937dd90f  vmovaps [rsp+0xC0], xmm13
000074fc937dd918  vmovaps [rsp+0xD0], xmm14
000074fc937dd921  vmovaps [rsp+0xE0], xmm15
000074fc937dd92a  sub rsp, 0x30
000074fc937dd92e  movaps [rsp], xmm7
000074fc937dd932  movaps [rsp+0x10], xmm4
000074fc937dd937  movaps [rsp+0x20], xmm9
000074fc937dd93d  lea rdi, [rsp]
000074fc937dd941  mov esi, 0x00
000074fc937dd946  mov rax, 0x5D72CBC20530
000074fc937dd950  call rax
000074fc937dd952  movaps xmm7, [rsp]
000074fc937dd956  add rsp, 0x30
000074fc937dd95a  vmovaps xmm0, [rsp]
000074fc937dd95f  vmovaps xmm1, [rsp+0x10]
000074fc937dd965  vmovaps xmm2, [rsp+0x20]
000074fc937dd96b  vmovaps xmm3, [rsp+0x30]
000074fc937dd971  vmovaps xmm4, [rsp+0x40]
000074fc937dd977  vmovaps xmm5, [rsp+0x50]
000074fc937dd97d  vmovaps xmm6, [rsp+0x60]
000074fc937dd983  vmovaps xmm8, [rsp+0x70]
000074fc937dd989  vmovaps xmm9, [rsp+0x80]
000074fc937dd992  vmovaps xmm10, [rsp+0x90]
000074fc937dd99b  vmovaps xmm11, [rsp+0xA0]
000074fc937dd9a4  vmovaps xmm12, [rsp+0xB0]
000074fc937dd9ad  vmovaps xmm13, [rsp+0xC0]
000074fc937dd9b6  vmovaps xmm14, [rsp+0xD0]
000074fc937dd9bf  vmovaps xmm15, [rsp+0xE0]
000074fc937dd9c8  add rsp, 0xF0
000074fc937dd9cf  pop r11
000074fc937dd9d1  pop r10
000074fc937dd9d3  pop r9
000074fc937dd9d5  pop r8
000074fc937dd9d7  pop rsi
000074fc937dd9d8  pop rdi
000074fc937dd9d9  pop rdx
000074fc937dd9da  pop rcx
000074fc937dd9db  pop rax
000074fc937dd9dc  add rsp, 0x08
000074fc937dd9e0  jmp 0x000074FC937DBE87
000074fc937dd9e5  sub rsp, 0x08
000074fc937dd9e9  push rax
000074fc937dd9ea  push rcx
000074fc937dd9eb  push rdx
000074fc937dd9ec  push rdi
000074fc937dd9ed  push rsi
000074fc937dd9ee  push r8
000074fc937dd9f0  push r9
000074fc937dd9f2  push r10
000074fc937dd9f4  push r11
000074fc937dd9f6  sub rsp, 0xF0
000074fc937dd9fd  vmovaps [rsp], xmm0
000074fc937dda02  vmovaps [rsp+0x10], xmm1
000074fc937dda08  vmovaps [rsp+0x20], xmm2
000074fc937dda0e  vmovaps [rsp+0x30], xmm3
000074fc937dda14  vmovaps [rsp+0x40], xmm5
000074fc937dda1a  vmovaps [rsp+0x50], xmm6
000074fc937dda20  vmovaps [rsp+0x60], xmm7
000074fc937dda26  vmovaps [rsp+0x70], xmm8
000074fc937dda2c  vmovaps [rsp+0x80], xmm9
000074fc937dda35  vmovaps [rsp+0x90], xmm10
000074fc937dda3e  vmovaps [rsp+0xA0], xmm11
000074fc937dda47  vmovaps [rsp+0xB0], xmm12
000074fc937dda50  vmovaps [rsp+0xC0], xmm13
000074fc937dda59  vmovaps [rsp+0xD0], xmm14
000074fc937dda62  vmovaps [rsp+0xE0], xmm15
000074fc937dda6b  sub rsp, 0x30
000074fc937dda6f  movaps [rsp], xmm4
000074fc937dda73  movaps [rsp+0x10], xmm15
000074fc937dda79  movaps [rsp+0x20], xmm9
000074fc937dda7f  lea rdi, [rsp]
000074fc937dda83  mov esi, 0x00
000074fc937dda88  mov rax, 0x5D72CBC20530
000074fc937dda92  call rax
000074fc937dda94  movaps xmm4, [rsp]
000074fc937dda98  add rsp, 0x30
000074fc937dda9c  vmovaps xmm0, [rsp]
000074fc937ddaa1  vmovaps xmm1, [rsp+0x10]
000074fc937ddaa7  vmovaps xmm2, [rsp+0x20]
000074fc937ddaad  vmovaps xmm3, [rsp+0x30]
000074fc937ddab3  vmovaps xmm5, [rsp+0x40]
000074fc937ddab9  vmovaps xmm6, [rsp+0x50]
000074fc937ddabf  vmovaps xmm7, [rsp+0x60]
000074fc937ddac5  vmovaps xmm8, [rsp+0x70]
000074fc937ddacb  vmovaps xmm9, [rsp+0x80]
000074fc937ddad4  vmovaps xmm10, [rsp+0x90]
000074fc937ddadd  vmovaps xmm11, [rsp+0xA0]
000074fc937ddae6  vmovaps xmm12, [rsp+0xB0]
000074fc937ddaef  vmovaps xmm13, [rsp+0xC0]
000074fc937ddaf8  vmovaps xmm14, [rsp+0xD0]
000074fc937ddb01  vmovaps xmm15, [rsp+0xE0]
000074fc937ddb0a  add rsp, 0xF0
000074fc937ddb11  pop r11
000074fc937ddb13  pop r10
000074fc937ddb15  pop r9
000074fc937ddb17  pop r8
000074fc937ddb19  pop rsi
000074fc937ddb1a  pop rdi
000074fc937ddb1b  pop rdx
000074fc937ddb1c  pop rcx
000074fc937ddb1d  pop rax
000074fc937ddb1e  add rsp, 0x08
000074fc937ddb22  jmp 0x000074FC937DBEAC
000074fc937ddb27  call 0x000074FC936C4620
000074fc937ddb2c  jmp 0x000074FC937DBEB9
000074fc937ddb31  sub rsp, 0x08
000074fc937ddb35  push rax
000074fc937ddb36  push rcx
000074fc937ddb37  push rdx
000074fc937ddb38  push rdi
000074fc937ddb39  push rsi
000074fc937ddb3a  push r8
000074fc937ddb3c  push r9
000074fc937ddb3e  push r10
000074fc937ddb40  push r11
000074fc937ddb42  sub rsp, 0xF0
000074fc937ddb49  vmovaps [rsp], xmm0
000074fc937ddb4e  vmovaps [rsp+0x10], xmm1
000074fc937ddb54  vmovaps [rsp+0x20], xmm2
000074fc937ddb5a  vmovaps [rsp+0x30], xmm4
000074fc937ddb60  vmovaps [rsp+0x40], xmm5
000074fc937ddb66  vmovaps [rsp+0x50], xmm6
000074fc937ddb6c  vmovaps [rsp+0x60], xmm7
000074fc937ddb72  vmovaps [rsp+0x70], xmm8
000074fc937ddb78  vmovaps [rsp+0x80], xmm9
000074fc937ddb81  vmovaps [rsp+0x90], xmm10
000074fc937ddb8a  vmovaps [rsp+0xA0], xmm11
000074fc937ddb93  vmovaps [rsp+0xB0], xmm12
000074fc937ddb9c  vmovaps [rsp+0xC0], xmm13
000074fc937ddba5  vmovaps [rsp+0xD0], xmm14
000074fc937ddbae  vmovaps [rsp+0xE0], xmm15
000074fc937ddbb7  sub rsp, 0x30
000074fc937ddbbb  movaps [rsp], xmm3
000074fc937ddbbf  movaps [rsp+0x10], xmm1
000074fc937ddbc4  movaps [rsp+0x20], xmm9
000074fc937ddbca  lea rdi, [rsp]
000074fc937ddbce  mov esi, 0x00
000074fc937ddbd3  mov rax, 0x5D72CBC20530
000074fc937ddbdd  call rax
000074fc937ddbdf  movaps xmm3, [rsp]
000074fc937ddbe3  add rsp, 0x30
000074fc937ddbe7  vmovaps xmm0, [rsp]
000074fc937ddbec  vmovaps xmm1, [rsp+0x10]
000074fc937ddbf2  vmovaps xmm2, [rsp+0x20]
000074fc937ddbf8  vmovaps xmm4, [rsp+0x30]
000074fc937ddbfe  vmovaps xmm5, [rsp+0x40]
000074fc937ddc04  vmovaps xmm6, [rsp+0x50]
000074fc937ddc0a  vmovaps xmm7, [rsp+0x60]
000074fc937ddc10  vmovaps xmm8, [rsp+0x70]
000074fc937ddc16  vmovaps xmm9, [rsp+0x80]
000074fc937ddc1f  vmovaps xmm10, [rsp+0x90]
000074fc937ddc28  vmovaps xmm11, [rsp+0xA0]
000074fc937ddc31  vmovaps xmm12, [rsp+0xB0]
000074fc937ddc3a  vmovaps xmm13, [rsp+0xC0]
000074fc937ddc43  vmovaps xmm14, [rsp+0xD0]
000074fc937ddc4c  vmovaps xmm15, [rsp+0xE0]
000074fc937ddc55  add rsp, 0xF0
000074fc937ddc5c  pop r11
000074fc937ddc5e  pop r10
000074fc937ddc60  pop r9
000074fc937ddc62  pop r8
000074fc937ddc64  pop rsi
000074fc937ddc65  pop rdi
000074fc937ddc66  pop rdx
000074fc937ddc67  pop rcx
000074fc937ddc68  pop rax
000074fc937ddc69  add rsp, 0x08
000074fc937ddc6d  jmp 0x000074FC937DBEF6
000074fc937ddc72  sub rsp, 0x08
000074fc937ddc76  push rax
000074fc937ddc77  push rcx
000074fc937ddc78  push rdx
000074fc937ddc79  push rdi
000074fc937ddc7a  push rsi
000074fc937ddc7b  push r8
000074fc937ddc7d  push r9
000074fc937ddc7f  push r10
000074fc937ddc81  push r11
000074fc937ddc83  sub rsp, 0xF0
000074fc937ddc8a  vmovaps [rsp], xmm0
000074fc937ddc8f  vmovaps [rsp+0x10], xmm2
000074fc937ddc95  vmovaps [rsp+0x20], xmm3
000074fc937ddc9b  vmovaps [rsp+0x30], xmm4
000074fc937ddca1  vmovaps [rsp+0x40], xmm5
000074fc937ddca7  vmovaps [rsp+0x50], xmm6
000074fc937ddcad  vmovaps [rsp+0x60], xmm7
000074fc937ddcb3  vmovaps [rsp+0x70], xmm8
000074fc937ddcb9  vmovaps [rsp+0x80], xmm9
000074fc937ddcc2  vmovaps [rsp+0x90], xmm10
000074fc937ddccb  vmovaps [rsp+0xA0], xmm11
000074fc937ddcd4  vmovaps [rsp+0xB0], xmm12
000074fc937ddcdd  vmovaps [rsp+0xC0], xmm13
000074fc937ddce6  vmovaps [rsp+0xD0], xmm14
000074fc937ddcef  vmovaps [rsp+0xE0], xmm15
000074fc937ddcf8  sub rsp, 0x30
000074fc937ddcfc  movaps [rsp], xmm1
000074fc937ddd00  movaps [rsp+0x10], xmm15
000074fc937ddd06  movaps [rsp+0x20], xmm9
000074fc937ddd0c  lea rdi, [rsp]
000074fc937ddd10  mov esi, 0x00
000074fc937ddd15  mov rax, 0x5D72CBC20530
000074fc937ddd1f  call rax
000074fc937ddd21  movaps xmm1, [rsp]
000074fc937ddd25  add rsp, 0x30
000074fc937ddd29  vmovaps xmm0, [rsp]
000074fc937ddd2e  vmovaps xmm2, [rsp+0x10]
000074fc937ddd34  vmovaps xmm3, [rsp+0x20]
000074fc937ddd3a  vmovaps xmm4, [rsp+0x30]
000074fc937ddd40  vmovaps xmm5, [rsp+0x40]
000074fc937ddd46  vmovaps xmm6, [rsp+0x50]
000074fc937ddd4c  vmovaps xmm7, [rsp+0x60]
000074fc937ddd52  vmovaps xmm8, [rsp+0x70]
000074fc937ddd58  vmovaps xmm9, [rsp+0x80]
000074fc937ddd61  vmovaps xmm10, [rsp+0x90]
000074fc937ddd6a  vmovaps xmm11, [rsp+0xA0]
000074fc937ddd73  vmovaps xmm12, [rsp+0xB0]
000074fc937ddd7c  vmovaps xmm13, [rsp+0xC0]
000074fc937ddd85  vmovaps xmm14, [rsp+0xD0]
000074fc937ddd8e  vmovaps xmm15, [rsp+0xE0]
000074fc937ddd97  add rsp, 0xF0
000074fc937ddd9e  pop r11
000074fc937ddda0  pop r10
000074fc937ddda2  pop r9
000074fc937ddda4  pop r8
000074fc937ddda6  pop rsi
000074fc937ddda7  pop rdi
000074fc937ddda8  pop rdx
000074fc937ddda9  pop rcx
000074fc937dddaa  pop rax
000074fc937dddab  add rsp, 0x08
000074fc937dddaf  jmp 0x000074FC937DBF7E
000074fc937dddb4  call 0x000074FC936C4620
000074fc937dddb9  jmp 0x000074FC937DBF8B
000074fc937dddbe  sub rsp, 0x08
000074fc937dddc2  push rax
000074fc937dddc3  push rcx
000074fc937dddc4  push rdx
000074fc937dddc5  push rdi
000074fc937dddc6  push rsi
000074fc937dddc7  push r8
000074fc937dddc9  push r9
000074fc937dddcb  push r10
000074fc937dddcd  push r11
000074fc937dddcf  sub rsp, 0xF0
000074fc937dddd6  vmovaps [rsp], xmm0
000074fc937ddddb  vmovaps [rsp+0x10], xmm2
000074fc937ddde1  vmovaps [rsp+0x20], xmm3
000074fc937ddde7  vmovaps [rsp+0x30], xmm4
000074fc937ddded  vmovaps [rsp+0x40], xmm5
000074fc937dddf3  vmovaps [rsp+0x50], xmm6
000074fc937dddf9  vmovaps [rsp+0x60], xmm7
000074fc937dddff  vmovaps [rsp+0x70], xmm8
000074fc937dde05  vmovaps [rsp+0x80], xmm9
000074fc937dde0e  vmovaps [rsp+0x90], xmm10
000074fc937dde17  vmovaps [rsp+0xA0], xmm11
000074fc937dde20  vmovaps [rsp+0xB0], xmm12
000074fc937dde29  vmovaps [rsp+0xC0], xmm13
000074fc937dde32  vmovaps [rsp+0xD0], xmm14
000074fc937dde3b  vmovaps [rsp+0xE0], xmm15
000074fc937dde44  sub rsp, 0x30
000074fc937dde48  movaps [rsp], xmm1
000074fc937dde4c  movaps [rsp+0x10], xmm5
000074fc937dde51  movaps [rsp+0x20], xmm7
000074fc937dde56  lea rdi, [rsp]
000074fc937dde5a  mov esi, 0x00
000074fc937dde5f  mov rax, 0x5D72CBC20530
000074fc937dde69  call rax
000074fc937dde6b  movaps xmm1, [rsp]
000074fc937dde6f  add rsp, 0x30
000074fc937dde73  vmovaps xmm0, [rsp]
000074fc937dde78  vmovaps xmm2, [rsp+0x10]
000074fc937dde7e  vmovaps xmm3, [rsp+0x20]
000074fc937dde84  vmovaps xmm4, [rsp+0x30]
000074fc937dde8a  vmovaps xmm5, [rsp+0x40]
000074fc937dde90  vmovaps xmm6, [rsp+0x50]
000074fc937dde96  vmovaps xmm7, [rsp+0x60]
000074fc937dde9c  vmovaps xmm8, [rsp+0x70]
000074fc937ddea2  vmovaps xmm9, [rsp+0x80]
000074fc937ddeab  vmovaps xmm10, [rsp+0x90]
000074fc937ddeb4  vmovaps xmm11, [rsp+0xA0]
000074fc937ddebd  vmovaps xmm12, [rsp+0xB0]
000074fc937ddec6  vmovaps xmm13, [rsp+0xC0]
000074fc937ddecf  vmovaps xmm14, [rsp+0xD0]
000074fc937dded8  vmovaps xmm15, [rsp+0xE0]
000074fc937ddee1  add rsp, 0xF0
000074fc937ddee8  pop r11
000074fc937ddeea  pop r10
000074fc937ddeec  pop r9
000074fc937ddeee  pop r8
000074fc937ddef0  pop rsi
000074fc937ddef1  pop rdi
000074fc937ddef2  pop rdx
000074fc937ddef3  pop rcx
000074fc937ddef4  pop rax
000074fc937ddef5  add rsp, 0x08
000074fc937ddef9  jmp 0x000074FC937DC030
000074fc937ddefe  sub rsp, 0x08
000074fc937ddf02  push rax
000074fc937ddf03  push rcx
000074fc937ddf04  push rdx
000074fc937ddf05  push rdi
000074fc937ddf06  push rsi
000074fc937ddf07  push r8
000074fc937ddf09  push r9
000074fc937ddf0b  push r10
000074fc937ddf0d  push r11
000074fc937ddf0f  sub rsp, 0xF0
000074fc937ddf16  vmovaps [rsp], xmm0
000074fc937ddf1b  vmovaps [rsp+0x10], xmm1
000074fc937ddf21  vmovaps [rsp+0x20], xmm2
000074fc937ddf27  vmovaps [rsp+0x30], xmm3
000074fc937ddf2d  vmovaps [rsp+0x40], xmm4
000074fc937ddf33  vmovaps [rsp+0x50], xmm5
000074fc937ddf39  vmovaps [rsp+0x60], xmm6
000074fc937ddf3f  vmovaps [rsp+0x70], xmm8
000074fc937ddf45  vmovaps [rsp+0x80], xmm9
000074fc937ddf4e  vmovaps [rsp+0x90], xmm10
000074fc937ddf57  vmovaps [rsp+0xA0], xmm11
000074fc937ddf60  vmovaps [rsp+0xB0], xmm12
000074fc937ddf69  vmovaps [rsp+0xC0], xmm13
000074fc937ddf72  vmovaps [rsp+0xD0], xmm14
000074fc937ddf7b  vmovaps [rsp+0xE0], xmm15
000074fc937ddf84  sub rsp, 0x30
000074fc937ddf88  movaps [rsp], xmm7
000074fc937ddf8c  movaps [rsp+0x10], xmm5
000074fc937ddf91  movaps [rsp+0x20], xmm15
000074fc937ddf97  lea rdi, [rsp]
000074fc937ddf9b  mov esi, 0x00
000074fc937ddfa0  mov rax, 0x5D72CBC20530
000074fc937ddfaa  call rax
000074fc937ddfac  movaps xmm7, [rsp]
000074fc937ddfb0  add rsp, 0x30
000074fc937ddfb4  vmovaps xmm0, [rsp]
000074fc937ddfb9  vmovaps xmm1, [rsp+0x10]
000074fc937ddfbf  vmovaps xmm2, [rsp+0x20]
000074fc937ddfc5  vmovaps xmm3, [rsp+0x30]
000074fc937ddfcb  vmovaps xmm4, [rsp+0x40]
000074fc937ddfd1  vmovaps xmm5, [rsp+0x50]
000074fc937ddfd7  vmovaps xmm6, [rsp+0x60]
000074fc937ddfdd  vmovaps xmm8, [rsp+0x70]
000074fc937ddfe3  vmovaps xmm9, [rsp+0x80]
000074fc937ddfec  vmovaps xmm10, [rsp+0x90]
000074fc937ddff5  vmovaps xmm11, [rsp+0xA0]
000074fc937ddffe  vmovaps xmm12, [rsp+0xB0]
000074fc937de007  vmovaps xmm13, [rsp+0xC0]
000074fc937de010  vmovaps xmm14, [rsp+0xD0]
000074fc937de019  vmovaps xmm15, [rsp+0xE0]
000074fc937de022  add rsp, 0xF0
000074fc937de029  pop r11
000074fc937de02b  pop r10
000074fc937de02d  pop r9
000074fc937de02f  pop r8
000074fc937de031  pop rsi
000074fc937de032  pop rdi
000074fc937de033  pop rdx
000074fc937de034  pop rcx
000074fc937de035  pop rax
000074fc937de036  add rsp, 0x08
000074fc937de03a  jmp 0x000074FC937DC066
000074fc937de03f  call 0x000074FC936B52F0
000074fc937de044  jmp 0x000074FC937DC073
000074fc937de049  sub rsp, 0x08
000074fc937de04d  push rax
000074fc937de04e  push rcx
000074fc937de04f  push rdx
000074fc937de050  push rdi
000074fc937de051  push rsi
000074fc937de052  push r8
000074fc937de054  push r9
000074fc937de056  push r10
000074fc937de058  push r11
000074fc937de05a  sub rsp, 0xF0
000074fc937de061  vmovaps [rsp], xmm0
000074fc937de066  vmovaps [rsp+0x10], xmm1
000074fc937de06c  vmovaps [rsp+0x20], xmm2
000074fc937de072  vmovaps [rsp+0x30], xmm3
000074fc937de078  vmovaps [rsp+0x40], xmm4
000074fc937de07e  vmovaps [rsp+0x50], xmm5
000074fc937de084  vmovaps [rsp+0x60], xmm6
000074fc937de08a  vmovaps [rsp+0x70], xmm7
000074fc937de090  vmovaps [rsp+0x80], xmm8
000074fc937de099  vmovaps [rsp+0x90], xmm9
000074fc937de0a2  vmovaps [rsp+0xA0], xmm10
000074fc937de0ab  vmovaps [rsp+0xB0], xmm11
000074fc937de0b4  vmovaps [rsp+0xC0], xmm12
000074fc937de0bd  vmovaps [rsp+0xD0], xmm13
000074fc937de0c6  vmovaps [rsp+0xE0], xmm14
000074fc937de0cf  sub rsp, 0x30
000074fc937de0d3  movaps [rsp], xmm15
000074fc937de0d8  movaps [rsp+0x10], xmm5
000074fc937de0dd  movaps [rsp+0x20], xmm3
000074fc937de0e2  lea rdi, [rsp]
000074fc937de0e6  mov esi, 0x00
000074fc937de0eb  mov rax, 0x5D72CBC20530
000074fc937de0f5  call rax
000074fc937de0f7  movaps xmm15, [rsp]
000074fc937de0fc  add rsp, 0x30
000074fc937de100  vmovaps xmm0, [rsp]
000074fc937de105  vmovaps xmm1, [rsp+0x10]
000074fc937de10b  vmovaps xmm2, [rsp+0x20]
000074fc937de111  vmovaps xmm3, [rsp+0x30]
000074fc937de117  vmovaps xmm4, [rsp+0x40]
000074fc937de11d  vmovaps xmm5, [rsp+0x50]
000074fc937de123  vmovaps xmm6, [rsp+0x60]
000074fc937de129  vmovaps xmm7, [rsp+0x70]
000074fc937de12f  vmovaps xmm8, [rsp+0x80]
000074fc937de138  vmovaps xmm9, [rsp+0x90]
000074fc937de141  vmovaps xmm10, [rsp+0xA0]
000074fc937de14a  vmovaps xmm11, [rsp+0xB0]
000074fc937de153  vmovaps xmm12, [rsp+0xC0]
000074fc937de15c  vmovaps xmm13, [rsp+0xD0]
000074fc937de165  vmovaps xmm14, [rsp+0xE0]
000074fc937de16e  add rsp, 0xF0
000074fc937de175  pop r11
000074fc937de177  pop r10
000074fc937de179  pop r9
000074fc937de17b  pop r8
000074fc937de17d  pop rsi
000074fc937de17e  pop rdi
000074fc937de17f  pop rdx
000074fc937de180  pop rcx
000074fc937de181  pop rax
000074fc937de182  add rsp, 0x08
000074fc937de186  jmp 0x000074FC937DC099
000074fc937de18b  sub rsp, 0x08
000074fc937de18f  push rax
000074fc937de190  push rcx
000074fc937de191  push rdx
000074fc937de192  push rdi
000074fc937de193  push rsi
000074fc937de194  push r8
000074fc937de196  push r9
000074fc937de198  push r10
000074fc937de19a  push r11
000074fc937de19c  sub rsp, 0xF0
000074fc937de1a3  vmovaps [rsp], xmm0
000074fc937de1a8  vmovaps [rsp+0x10], xmm2
000074fc937de1ae  vmovaps [rsp+0x20], xmm3
000074fc937de1b4  vmovaps [rsp+0x30], xmm4
000074fc937de1ba  vmovaps [rsp+0x40], xmm5
000074fc937de1c0  vmovaps [rsp+0x50], xmm6
000074fc937de1c6  vmovaps [rsp+0x60], xmm7
000074fc937de1cc  vmovaps [rsp+0x70], xmm8
000074fc937de1d2  vmovaps [rsp+0x80], xmm9
000074fc937de1db  vmovaps [rsp+0x90], xmm10
000074fc937de1e4  vmovaps [rsp+0xA0], xmm11
000074fc937de1ed  vmovaps [rsp+0xB0], xmm12
000074fc937de1f6  vmovaps [rsp+0xC0], xmm13
000074fc937de1ff  vmovaps [rsp+0xD0], xmm14
000074fc937de208  vmovaps [rsp+0xE0], xmm15
000074fc937de211  sub rsp, 0x30
000074fc937de215  movaps [rsp], xmm1
000074fc937de219  movaps [rsp+0x10], xmm5
000074fc937de21e  movaps [rsp+0x20], xmm4
000074fc937de223  lea rdi, [rsp]
000074fc937de227  mov esi, 0x00
000074fc937de22c  mov rax, 0x5D72CBC20530
000074fc937de236  call rax
000074fc937de238  movaps xmm1, [rsp]
000074fc937de23c  add rsp, 0x30
000074fc937de240  vmovaps xmm0, [rsp]
000074fc937de245  vmovaps xmm2, [rsp+0x10]
000074fc937de24b  vmovaps xmm3, [rsp+0x20]
000074fc937de251  vmovaps xmm4, [rsp+0x30]
000074fc937de257  vmovaps xmm5, [rsp+0x40]
000074fc937de25d  vmovaps xmm6, [rsp+0x50]
000074fc937de263  vmovaps xmm7, [rsp+0x60]
000074fc937de269  vmovaps xmm8, [rsp+0x70]
000074fc937de26f  vmovaps xmm9, [rsp+0x80]
000074fc937de278  vmovaps xmm10, [rsp+0x90]
000074fc937de281  vmovaps xmm11, [rsp+0xA0]
000074fc937de28a  vmovaps xmm12, [rsp+0xB0]
000074fc937de293  vmovaps xmm13, [rsp+0xC0]
000074fc937de29c  vmovaps xmm14, [rsp+0xD0]
000074fc937de2a5  vmovaps xmm15, [rsp+0xE0]
000074fc937de2ae  add rsp, 0xF0
000074fc937de2b5  pop r11
000074fc937de2b7  pop r10
000074fc937de2b9  pop r9
000074fc937de2bb  pop r8
000074fc937de2bd  pop rsi
000074fc937de2be  pop rdi
000074fc937de2bf  pop rdx
000074fc937de2c0  pop rcx
000074fc937de2c1  pop rax
000074fc937de2c2  add rsp, 0x08
000074fc937de2c6  jmp 0x000074FC937DC0B9
000074fc937de2cb  sub rsp, 0x08
000074fc937de2cf  push rax
000074fc937de2d0  push rcx
000074fc937de2d1  push rdx
000074fc937de2d2  push rdi
000074fc937de2d3  push rsi
000074fc937de2d4  push r8
000074fc937de2d6  push r9
000074fc937de2d8  push r10
000074fc937de2da  push r11
000074fc937de2dc  sub rsp, 0xF0
000074fc937de2e3  vmovaps [rsp], xmm0
000074fc937de2e8  vmovaps [rsp+0x10], xmm1
000074fc937de2ee  vmovaps [rsp+0x20], xmm2
000074fc937de2f4  vmovaps [rsp+0x30], xmm3
000074fc937de2fa  vmovaps [rsp+0x40], xmm5
000074fc937de300  vmovaps [rsp+0x50], xmm6
000074fc937de306  vmovaps [rsp+0x60], xmm7
000074fc937de30c  vmovaps [rsp+0x70], xmm8
000074fc937de312  vmovaps [rsp+0x80], xmm9
000074fc937de31b  vmovaps [rsp+0x90], xmm10
000074fc937de324  vmovaps [rsp+0xA0], xmm11
000074fc937de32d  vmovaps [rsp+0xB0], xmm12
000074fc937de336  vmovaps [rsp+0xC0], xmm13
000074fc937de33f  vmovaps [rsp+0xD0], xmm14
000074fc937de348  vmovaps [rsp+0xE0], xmm15
000074fc937de351  sub rsp, 0x30
000074fc937de355  movaps [rsp], xmm4
000074fc937de359  movaps [rsp+0x10], xmm3
000074fc937de35e  movaps [rsp+0x20], xmm5
000074fc937de363  lea rdi, [rsp]
000074fc937de367  mov esi, 0x00
000074fc937de36c  mov rax, 0x5D72CBC20530
000074fc937de376  call rax
000074fc937de378  movaps xmm4, [rsp]
000074fc937de37c  add rsp, 0x30
000074fc937de380  vmovaps xmm0, [rsp]
000074fc937de385  vmovaps xmm1, [rsp+0x10]
000074fc937de38b  vmovaps xmm2, [rsp+0x20]
000074fc937de391  vmovaps xmm3, [rsp+0x30]
000074fc937de397  vmovaps xmm5, [rsp+0x40]
000074fc937de39d  vmovaps xmm6, [rsp+0x50]
000074fc937de3a3  vmovaps xmm7, [rsp+0x60]
000074fc937de3a9  vmovaps xmm8, [rsp+0x70]
000074fc937de3af  vmovaps xmm9, [rsp+0x80]
000074fc937de3b8  vmovaps xmm10, [rsp+0x90]
000074fc937de3c1  vmovaps xmm11, [rsp+0xA0]
000074fc937de3ca  vmovaps xmm12, [rsp+0xB0]
000074fc937de3d3  vmovaps xmm13, [rsp+0xC0]
000074fc937de3dc  vmovaps xmm14, [rsp+0xD0]
000074fc937de3e5  vmovaps xmm15, [rsp+0xE0]
000074fc937de3ee  add rsp, 0xF0
000074fc937de3f5  pop r11
000074fc937de3f7  pop r10
000074fc937de3f9  pop r9
000074fc937de3fb  pop r8
000074fc937de3fd  pop rsi
000074fc937de3fe  pop rdi
000074fc937de3ff  pop rdx
000074fc937de400  pop rcx
000074fc937de401  pop rax
000074fc937de402  add rsp, 0x08
000074fc937de406  jmp 0x000074FC937DC107
000074fc937de40b  call 0x000074FC936B52F0
000074fc937de410  jmp 0x000074FC937DC114
000074fc937de415  sub rsp, 0x08
000074fc937de419  push rax
000074fc937de41a  push rcx
000074fc937de41b  push rdx
000074fc937de41c  push rdi
000074fc937de41d  push rsi
000074fc937de41e  push r8
000074fc937de420  push r9
000074fc937de422  push r10
000074fc937de424  push r11
000074fc937de426  sub rsp, 0xF0
000074fc937de42d  vmovaps [rsp], xmm0
000074fc937de432  vmovaps [rsp+0x10], xmm1
000074fc937de438  vmovaps [rsp+0x20], xmm2
000074fc937de43e  vmovaps [rsp+0x30], xmm3
000074fc937de444  vmovaps [rsp+0x40], xmm4
000074fc937de44a  vmovaps [rsp+0x50], xmm6
000074fc937de450  vmovaps [rsp+0x60], xmm7
000074fc937de456  vmovaps [rsp+0x70], xmm8
000074fc937de45c  vmovaps [rsp+0x80], xmm9
000074fc937de465  vmovaps [rsp+0x90], xmm10
000074fc937de46e  vmovaps [rsp+0xA0], xmm11
000074fc937de477  vmovaps [rsp+0xB0], xmm12
000074fc937de480  vmovaps [rsp+0xC0], xmm13
000074fc937de489  vmovaps [rsp+0xD0], xmm14
000074fc937de492  vmovaps [rsp+0xE0], xmm15
000074fc937de49b  sub rsp, 0x30
000074fc937de49f  movaps [rsp], xmm5
000074fc937de4a3  movaps [rsp+0x10], xmm6
000074fc937de4a8  movaps [rsp+0x20], xmm3
000074fc937de4ad  lea rdi, [rsp]
000074fc937de4b1  mov esi, 0x00
000074fc937de4b6  mov rax, 0x5D72CBC20530
000074fc937de4c0  call rax
000074fc937de4c2  movaps xmm5, [rsp]
000074fc937de4c6  add rsp, 0x30
000074fc937de4ca  vmovaps xmm0, [rsp]
000074fc937de4cf  vmovaps xmm1, [rsp+0x10]
000074fc937de4d5  vmovaps xmm2, [rsp+0x20]
000074fc937de4db  vmovaps xmm3, [rsp+0x30]
000074fc937de4e1  vmovaps xmm4, [rsp+0x40]
000074fc937de4e7  vmovaps xmm6, [rsp+0x50]
000074fc937de4ed  vmovaps xmm7, [rsp+0x60]
000074fc937de4f3  vmovaps xmm8, [rsp+0x70]
000074fc937de4f9  vmovaps xmm9, [rsp+0x80]
000074fc937de502  vmovaps xmm10, [rsp+0x90]
000074fc937de50b  vmovaps xmm11, [rsp+0xA0]
000074fc937de514  vmovaps xmm12, [rsp+0xB0]
000074fc937de51d  vmovaps xmm13, [rsp+0xC0]
000074fc937de526  vmovaps xmm14, [rsp+0xD0]
000074fc937de52f  vmovaps xmm15, [rsp+0xE0]
000074fc937de538  add rsp, 0xF0
000074fc937de53f  pop r11
000074fc937de541  pop r10
000074fc937de543  pop r9
000074fc937de545  pop r8
000074fc937de547  pop rsi
000074fc937de548  pop rdi
000074fc937de549  pop rdx
000074fc937de54a  pop rcx
000074fc937de54b  pop rax
000074fc937de54c  add rsp, 0x08
000074fc937de550  jmp 0x000074FC937DC13A
000074fc937de555  sub rsp, 0x08
000074fc937de559  push rax
000074fc937de55a  push rcx
000074fc937de55b  push rdx
000074fc937de55c  push rdi
000074fc937de55d  push rsi
000074fc937de55e  push r8
000074fc937de560  push r9
000074fc937de562  push r10
000074fc937de564  push r11
000074fc937de566  sub rsp, 0xF0
000074fc937de56d  vmovaps [rsp], xmm0
000074fc937de572  vmovaps [rsp+0x10], xmm1
000074fc937de578  vmovaps [rsp+0x20], xmm2
000074fc937de57e  vmovaps [rsp+0x30], xmm3
000074fc937de584  vmovaps [rsp+0x40], xmm4
000074fc937de58a  vmovaps [rsp+0x50], xmm5
000074fc937de590  vmovaps [rsp+0x60], xmm7
000074fc937de596  vmovaps [rsp+0x70], xmm8
000074fc937de59c  vmovaps [rsp+0x80], xmm9
000074fc937de5a5  vmovaps [rsp+0x90], xmm10
000074fc937de5ae  vmovaps [rsp+0xA0], xmm11
000074fc937de5b7  vmovaps [rsp+0xB0], xmm12
000074fc937de5c0  vmovaps [rsp+0xC0], xmm13
000074fc937de5c9  vmovaps [rsp+0xD0], xmm14
000074fc937de5d2  vmovaps [rsp+0xE0], xmm15
000074fc937de5db  sub rsp, 0x30
000074fc937de5df  movaps [rsp], xmm6
000074fc937de5e3  movaps [rsp+0x10], xmm9
000074fc937de5e9  movaps [rsp+0x20], xmm1
000074fc937de5ee  lea rdi, [rsp]
000074fc937de5f2  mov esi, 0x00
000074fc937de5f7  mov rax, 0x5D72CBC20530
000074fc937de601  call rax
000074fc937de603  movaps xmm6, [rsp]
000074fc937de607  add rsp, 0x30
000074fc937de60b  vmovaps xmm0, [rsp]
000074fc937de610  vmovaps xmm1, [rsp+0x10]
000074fc937de616  vmovaps xmm2, [rsp+0x20]
000074fc937de61c  vmovaps xmm3, [rsp+0x30]
000074fc937de622  vmovaps xmm4, [rsp+0x40]
000074fc937de628  vmovaps xmm5, [rsp+0x50]
000074fc937de62e  vmovaps xmm7, [rsp+0x60]
000074fc937de634  vmovaps xmm8, [rsp+0x70]
000074fc937de63a  vmovaps xmm9, [rsp+0x80]
000074fc937de643  vmovaps xmm10, [rsp+0x90]
000074fc937de64c  vmovaps xmm11, [rsp+0xA0]
000074fc937de655  vmovaps xmm12, [rsp+0xB0]
000074fc937de65e  vmovaps xmm13, [rsp+0xC0]
000074fc937de667  vmovaps xmm14, [rsp+0xD0]
000074fc937de670  vmovaps xmm15, [rsp+0xE0]
000074fc937de679  add rsp, 0xF0
000074fc937de680  pop r11
000074fc937de682  pop r10
000074fc937de684  pop r9
000074fc937de686  pop r8
000074fc937de688  pop rsi
000074fc937de689  pop rdi
000074fc937de68a  pop rdx
000074fc937de68b  pop rcx
000074fc937de68c  pop rax
000074fc937de68d  add rsp, 0x08
000074fc937de691  jmp 0x000074FC937DC15E
000074fc937de696  sub rsp, 0x08
000074fc937de69a  push rax
000074fc937de69b  push rcx
000074fc937de69c  push rdx
000074fc937de69d  push rdi
000074fc937de69e  push rsi
000074fc937de69f  push r8
000074fc937de6a1  push r9
000074fc937de6a3  push r10
000074fc937de6a5  push r11
000074fc937de6a7  sub rsp, 0xF0
000074fc937de6ae  vmovaps [rsp], xmm0
000074fc937de6b3  vmovaps [rsp+0x10], xmm1
000074fc937de6b9  vmovaps [rsp+0x20], xmm2
000074fc937de6bf  vmovaps [rsp+0x30], xmm3
000074fc937de6c5  vmovaps [rsp+0x40], xmm4
000074fc937de6cb  vmovaps [rsp+0x50], xmm5
000074fc937de6d1  vmovaps [rsp+0x60], xmm6
000074fc937de6d7  vmovaps [rsp+0x70], xmm7
000074fc937de6dd  vmovaps [rsp+0x80], xmm8
000074fc937de6e6  vmovaps [rsp+0x90], xmm10
000074fc937de6ef  vmovaps [rsp+0xA0], xmm11
000074fc937de6f8  vmovaps [rsp+0xB0], xmm12
000074fc937de701  vmovaps [rsp+0xC0], xmm13
000074fc937de70a  vmovaps [rsp+0xD0], xmm14
000074fc937de713  vmovaps [rsp+0xE0], xmm15
000074fc937de71c  sub rsp, 0x30
000074fc937de720  movaps [rsp], xmm9
000074fc937de725  movaps [rsp+0x10], xmm3
000074fc937de72a  movaps [rsp+0x20], xmm1
000074fc937de72f  lea rdi, [rsp]
000074fc937de733  mov esi, 0x00
000074fc937de738  mov rax, 0x5D72CBC20530
000074fc937de742  call rax
000074fc937de744  movaps xmm9, [rsp]
000074fc937de749  add rsp, 0x30
000074fc937de74d  vmovaps xmm0, [rsp]
000074fc937de752  vmovaps xmm1, [rsp+0x10]
000074fc937de758  vmovaps xmm2, [rsp+0x20]
000074fc937de75e  vmovaps xmm3, [rsp+0x30]
000074fc937de764  vmovaps xmm4, [rsp+0x40]
000074fc937de76a  vmovaps xmm5, [rsp+0x50]
000074fc937de770  vmovaps xmm6, [rsp+0x60]
000074fc937de776  vmovaps xmm7, [rsp+0x70]
000074fc937de77c  vmovaps xmm8, [rsp+0x80]
000074fc937de785  vmovaps xmm10, [rsp+0x90]
000074fc937de78e  vmovaps xmm11, [rsp+0xA0]
000074fc937de797  vmovaps xmm12, [rsp+0xB0]
000074fc937de7a0  vmovaps xmm13, [rsp+0xC0]
000074fc937de7a9  vmovaps xmm14, [rsp+0xD0]
000074fc937de7b2  vmovaps xmm15, [rsp+0xE0]
000074fc937de7bb  add rsp, 0xF0
000074fc937de7c2  pop r11
000074fc937de7c4  pop r10
000074fc937de7c6  pop r9
000074fc937de7c8  pop r8
000074fc937de7ca  pop rsi
000074fc937de7cb  pop rdi
000074fc937de7cc  pop rdx
000074fc937de7cd  pop rcx
000074fc937de7ce  pop rax
000074fc937de7cf  add rsp, 0x08
000074fc937de7d3  jmp 0x000074FC937DC1AA
000074fc937de7d8  call 0x000074FC936B52F0
000074fc937de7dd  jmp 0x000074FC937DC1B7
000074fc937de7e2  sub rsp, 0x08
000074fc937de7e6  push rax
000074fc937de7e7  push rcx
000074fc937de7e8  push rdx
000074fc937de7e9  push rdi
000074fc937de7ea  push rsi
000074fc937de7eb  push r8
000074fc937de7ed  push r9
000074fc937de7ef  push r10
000074fc937de7f1  push r11
000074fc937de7f3  sub rsp, 0xF0
000074fc937de7fa  vmovaps [rsp], xmm0
000074fc937de7ff  vmovaps [rsp+0x10], xmm1
000074fc937de805  vmovaps [rsp+0x20], xmm2
000074fc937de80b  vmovaps [rsp+0x30], xmm3
000074fc937de811  vmovaps [rsp+0x40], xmm4
000074fc937de817  vmovaps [rsp+0x50], xmm5
000074fc937de81d  vmovaps [rsp+0x60], xmm6
000074fc937de823  vmovaps [rsp+0x70], xmm7
000074fc937de829  vmovaps [rsp+0x80], xmm8
000074fc937de832  vmovaps [rsp+0x90], xmm9
000074fc937de83b  vmovaps [rsp+0xA0], xmm10
000074fc937de844  vmovaps [rsp+0xB0], xmm11
000074fc937de84d  vmovaps [rsp+0xC0], xmm12
000074fc937de856  vmovaps [rsp+0xD0], xmm13
000074fc937de85f  vmovaps [rsp+0xE0], xmm14
000074fc937de868  sub rsp, 0x30
000074fc937de86c  movaps [rsp], xmm15
000074fc937de871  movaps [rsp+0x10], xmm3
000074fc937de876  movaps [rsp+0x20], xmm7
000074fc937de87b  lea rdi, [rsp]
000074fc937de87f  mov esi, 0x00
000074fc937de884  mov rax, 0x5D72CBC20530
000074fc937de88e  call rax
000074fc937de890  movaps xmm15, [rsp]
000074fc937de895  add rsp, 0x30
000074fc937de899  vmovaps xmm0, [rsp]
000074fc937de89e  vmovaps xmm1, [rsp+0x10]
000074fc937de8a4  vmovaps xmm2, [rsp+0x20]
000074fc937de8aa  vmovaps xmm3, [rsp+0x30]
000074fc937de8b0  vmovaps xmm4, [rsp+0x40]
000074fc937de8b6  vmovaps xmm5, [rsp+0x50]
000074fc937de8bc  vmovaps xmm6, [rsp+0x60]
000074fc937de8c2  vmovaps xmm7, [rsp+0x70]
000074fc937de8c8  vmovaps xmm8, [rsp+0x80]
000074fc937de8d1  vmovaps xmm9, [rsp+0x90]
000074fc937de8da  vmovaps xmm10, [rsp+0xA0]
000074fc937de8e3  vmovaps xmm11, [rsp+0xB0]
000074fc937de8ec  vmovaps xmm12, [rsp+0xC0]
000074fc937de8f5  vmovaps xmm13, [rsp+0xD0]
000074fc937de8fe  vmovaps xmm14, [rsp+0xE0]
000074fc937de907  add rsp, 0xF0
000074fc937de90e  pop r11
000074fc937de910  pop r10
000074fc937de912  pop r9
000074fc937de914  pop r8
000074fc937de916  pop rsi
000074fc937de917  pop rdi
000074fc937de918  pop rdx
000074fc937de919  pop rcx
000074fc937de91a  pop rax
000074fc937de91b  add rsp, 0x08
000074fc937de91f  jmp 0x000074FC937DC1E3
000074fc937de924  sub rsp, 0x08
000074fc937de928  push rax
000074fc937de929  push rcx
000074fc937de92a  push rdx
000074fc937de92b  push rdi
000074fc937de92c  push rsi
000074fc937de92d  push r8
000074fc937de92f  push r9
000074fc937de931  push r10
000074fc937de933  push r11
000074fc937de935  sub rsp, 0xF0
000074fc937de93c  vmovaps [rsp], xmm0
000074fc937de941  vmovaps [rsp+0x10], xmm1
000074fc937de947  vmovaps [rsp+0x20], xmm2
000074fc937de94d  vmovaps [rsp+0x30], xmm4
000074fc937de953  vmovaps [rsp+0x40], xmm5
000074fc937de959  vmovaps [rsp+0x50], xmm6
000074fc937de95f  vmovaps [rsp+0x60], xmm7
000074fc937de965  vmovaps [rsp+0x70], xmm8
000074fc937de96b  vmovaps [rsp+0x80], xmm9
000074fc937de974  vmovaps [rsp+0x90], xmm10
000074fc937de97d  vmovaps [rsp+0xA0], xmm11
000074fc937de986  vmovaps [rsp+0xB0], xmm12
000074fc937de98f  vmovaps [rsp+0xC0], xmm13
000074fc937de998  vmovaps [rsp+0xD0], xmm14
000074fc937de9a1  vmovaps [rsp+0xE0], xmm15
000074fc937de9aa  sub rsp, 0x30
000074fc937de9ae  movaps [rsp], xmm3
000074fc937de9b2  movaps [rsp+0x10], xmm1
000074fc937de9b7  movaps [rsp+0x20], xmm15
000074fc937de9bd  lea rdi, [rsp]
000074fc937de9c1  mov esi, 0x00
000074fc937de9c6  mov rax, 0x5D72CBC20530
000074fc937de9d0  call rax
000074fc937de9d2  movaps xmm3, [rsp]
000074fc937de9d6  add rsp, 0x30
000074fc937de9da  vmovaps xmm0, [rsp]
000074fc937de9df  vmovaps xmm1, [rsp+0x10]
000074fc937de9e5  vmovaps xmm2, [rsp+0x20]
000074fc937de9eb  vmovaps xmm4, [rsp+0x30]
000074fc937de9f1  vmovaps xmm5, [rsp+0x40]
000074fc937de9f7  vmovaps xmm6, [rsp+0x50]
000074fc937de9fd  vmovaps xmm7, [rsp+0x60]
000074fc937dea03  vmovaps xmm8, [rsp+0x70]
000074fc937dea09  vmovaps xmm9, [rsp+0x80]
000074fc937dea12  vmovaps xmm10, [rsp+0x90]
000074fc937dea1b  vmovaps xmm11, [rsp+0xA0]
000074fc937dea24  vmovaps xmm12, [rsp+0xB0]
000074fc937dea2d  vmovaps xmm13, [rsp+0xC0]
000074fc937dea36  vmovaps xmm14, [rsp+0xD0]
000074fc937dea3f  vmovaps xmm15, [rsp+0xE0]
000074fc937dea48  add rsp, 0xF0
000074fc937dea4f  pop r11
000074fc937dea51  pop r10
000074fc937dea53  pop r9
000074fc937dea55  pop r8
000074fc937dea57  pop rsi
000074fc937dea58  pop rdi
000074fc937dea59  pop rdx
000074fc937dea5a  pop rcx
000074fc937dea5b  pop rax
000074fc937dea5c  add rsp, 0x08
000074fc937dea60  jmp 0x000074FC937DC272
000074fc937dea65  call 0x000074FC936B52F0
000074fc937dea6a  jmp 0x000074FC937DC27C
000074fc937dea6f  sub rsp, 0x08
000074fc937dea73  push rax
000074fc937dea74  push rcx
000074fc937dea75  push rdx
000074fc937dea76  push rdi
000074fc937dea77  push rsi
000074fc937dea78  push r8
000074fc937dea7a  push r9
000074fc937dea7c  push r10
000074fc937dea7e  push r11
000074fc937dea80  sub rsp, 0xF0
000074fc937dea87  vmovaps [rsp], xmm0
000074fc937dea8c  vmovaps [rsp+0x10], xmm1
000074fc937dea92  vmovaps [rsp+0x20], xmm2
000074fc937dea98  vmovaps [rsp+0x30], xmm3
000074fc937dea9e  vmovaps [rsp+0x40], xmm4
000074fc937deaa4  vmovaps [rsp+0x50], xmm5
000074fc937deaaa  vmovaps [rsp+0x60], xmm6
000074fc937deab0  vmovaps [rsp+0x70], xmm7
000074fc937deab6  vmovaps [rsp+0x80], xmm8
000074fc937deabf  vmovaps [rsp+0x90], xmm9
000074fc937deac8  vmovaps [rsp+0xA0], xmm10
000074fc937dead1  vmovaps [rsp+0xB0], xmm11
000074fc937deada  vmovaps [rsp+0xC0], xmm12
000074fc937deae3  vmovaps [rsp+0xD0], xmm13
000074fc937deaec  vmovaps [rsp+0xE0], xmm14
000074fc937deaf5  sub rsp, 0x30
000074fc937deaf9  movaps [rsp], xmm15
000074fc937deafe  movaps [rsp+0x10], xmm14
000074fc937deb04  movaps [rsp+0x20], xmm4
000074fc937deb09  lea rdi, [rsp]
000074fc937deb0d  mov esi, 0x00
000074fc937deb12  mov rax, 0x5D72CBC20530
000074fc937deb1c  call rax
000074fc937deb1e  movaps xmm15, [rsp]
000074fc937deb23  add rsp, 0x30
000074fc937deb27  vmovaps xmm0, [rsp]
000074fc937deb2c  vmovaps xmm1, [rsp+0x10]
000074fc937deb32  vmovaps xmm2, [rsp+0x20]
000074fc937deb38  vmovaps xmm3, [rsp+0x30]
000074fc937deb3e  vmovaps xmm4, [rsp+0x40]
000074fc937deb44  vmovaps xmm5, [rsp+0x50]
000074fc937deb4a  vmovaps xmm6, [rsp+0x60]
000074fc937deb50  vmovaps xmm7, [rsp+0x70]
000074fc937deb56  vmovaps xmm8, [rsp+0x80]
000074fc937deb5f  vmovaps xmm9, [rsp+0x90]
000074fc937deb68  vmovaps xmm10, [rsp+0xA0]
000074fc937deb71  vmovaps xmm11, [rsp+0xB0]
000074fc937deb7a  vmovaps xmm12, [rsp+0xC0]
000074fc937deb83  vmovaps xmm13, [rsp+0xD0]
000074fc937deb8c  vmovaps xmm14, [rsp+0xE0]
000074fc937deb95  add rsp, 0xF0
000074fc937deb9c  pop r11
000074fc937deb9e  pop r10
000074fc937deba0  pop r9
000074fc937deba2  pop r8
000074fc937deba4  pop rsi
000074fc937deba5  pop rdi
000074fc937deba6  pop rdx
000074fc937deba7  pop rcx
000074fc937deba8  pop rax
000074fc937deba9  add rsp, 0x08
000074fc937debad  jmp 0x000074FC937DC2AA
000074fc937debb2  sub rsp, 0x08
000074fc937debb6  push rax
000074fc937debb7  push rcx
000074fc937debb8  push rdx
000074fc937debb9  push rdi
000074fc937debba  push rsi
000074fc937debbb  push r8
000074fc937debbd  push r9
000074fc937debbf  push r10
000074fc937debc1  push r11
000074fc937debc3  sub rsp, 0xF0
000074fc937debca  vmovaps [rsp], xmm0
000074fc937debcf  vmovaps [rsp+0x10], xmm1
000074fc937debd5  vmovaps [rsp+0x20], xmm2
000074fc937debdb  vmovaps [rsp+0x30], xmm3
000074fc937debe1  vmovaps [rsp+0x40], xmm4
000074fc937debe7  vmovaps [rsp+0x50], xmm5
000074fc937debed  vmovaps [rsp+0x60], xmm6
000074fc937debf3  vmovaps [rsp+0x70], xmm7
000074fc937debf9  vmovaps [rsp+0x80], xmm8
000074fc937dec02  vmovaps [rsp+0x90], xmm9
000074fc937dec0b  vmovaps [rsp+0xA0], xmm10
000074fc937dec14  vmovaps [rsp+0xB0], xmm11
000074fc937dec1d  vmovaps [rsp+0xC0], xmm12
000074fc937dec26  vmovaps [rsp+0xD0], xmm13
000074fc937dec2f  vmovaps [rsp+0xE0], xmm15
000074fc937dec38  sub rsp, 0x30
000074fc937dec3c  movaps [rsp], xmm14
000074fc937dec41  movaps [rsp+0x10], xmm2
000074fc937dec46  movaps [rsp+0x20], xmm1
000074fc937dec4b  lea rdi, [rsp]
000074fc937dec4f  mov esi, 0x00
000074fc937dec54  mov rax, 0x5D72CBC20530
000074fc937dec5e  call rax
000074fc937dec60  movaps xmm14, [rsp]
000074fc937dec65  add rsp, 0x30
000074fc937dec69  vmovaps xmm0, [rsp]
000074fc937dec6e  vmovaps xmm1, [rsp+0x10]
000074fc937dec74  vmovaps xmm2, [rsp+0x20]
000074fc937dec7a  vmovaps xmm3, [rsp+0x30]
000074fc937dec80  vmovaps xmm4, [rsp+0x40]
000074fc937dec86  vmovaps xmm5, [rsp+0x50]
000074fc937dec8c  vmovaps xmm6, [rsp+0x60]
000074fc937dec92  vmovaps xmm7, [rsp+0x70]
000074fc937dec98  vmovaps xmm8, [rsp+0x80]
000074fc937deca1  vmovaps xmm9, [rsp+0x90]
000074fc937decaa  vmovaps xmm10, [rsp+0xA0]
000074fc937decb3  vmovaps xmm11, [rsp+0xB0]
000074fc937decbc  vmovaps xmm12, [rsp+0xC0]
000074fc937decc5  vmovaps xmm13, [rsp+0xD0]
000074fc937decce  vmovaps xmm15, [rsp+0xE0]
000074fc937decd7  add rsp, 0xF0
000074fc937decde  pop r11
000074fc937dece0  pop r10
000074fc937dece2  pop r9
000074fc937dece4  pop r8
000074fc937dece6  pop rsi
000074fc937dece7  pop rdi
000074fc937dece8  pop rdx
000074fc937dece9  pop rcx
000074fc937decea  pop rax
000074fc937deceb  add rsp, 0x08
000074fc937decef  jmp 0x000074FC937DC2D0
000074fc937decf4  sub rsp, 0x08
000074fc937decf8  push rax
000074fc937decf9  push rcx
000074fc937decfa  push rdx
000074fc937decfb  push rdi
000074fc937decfc  push rsi
000074fc937decfd  push r8
000074fc937decff  push r9
000074fc937ded01  push r10
000074fc937ded03  push r11
000074fc937ded05  sub rsp, 0xF0
000074fc937ded0c  vmovaps [rsp], xmm0
000074fc937ded11  vmovaps [rsp+0x10], xmm2
000074fc937ded17  vmovaps [rsp+0x20], xmm3
000074fc937ded1d  vmovaps [rsp+0x30], xmm4
000074fc937ded23  vmovaps [rsp+0x40], xmm5
000074fc937ded29  vmovaps [rsp+0x50], xmm6
000074fc937ded2f  vmovaps [rsp+0x60], xmm7
000074fc937ded35  vmovaps [rsp+0x70], xmm8
000074fc937ded3b  vmovaps [rsp+0x80], xmm9
000074fc937ded44  vmovaps [rsp+0x90], xmm10
000074fc937ded4d  vmovaps [rsp+0xA0], xmm11
000074fc937ded56  vmovaps [rsp+0xB0], xmm12
000074fc937ded5f  vmovaps [rsp+0xC0], xmm13
000074fc937ded68  vmovaps [rsp+0xD0], xmm14
000074fc937ded71  vmovaps [rsp+0xE0], xmm15
000074fc937ded7a  sub rsp, 0x30
000074fc937ded7e  movaps [rsp], xmm1
000074fc937ded82  movaps [rsp+0x10], xmm4
000074fc937ded87  movaps [rsp+0x20], xmm9
000074fc937ded8d  lea rdi, [rsp]
000074fc937ded91  mov esi, 0x00
000074fc937ded96  mov rax, 0x5D72CBC20530
000074fc937deda0  call rax
000074fc937deda2  movaps xmm1, [rsp]
000074fc937deda6  add rsp, 0x30
000074fc937dedaa  vmovaps xmm0, [rsp]
000074fc937dedaf  vmovaps xmm2, [rsp+0x10]
000074fc937dedb5  vmovaps xmm3, [rsp+0x20]
000074fc937dedbb  vmovaps xmm4, [rsp+0x30]
000074fc937dedc1  vmovaps xmm5, [rsp+0x40]
000074fc937dedc7  vmovaps xmm6, [rsp+0x50]
000074fc937dedcd  vmovaps xmm7, [rsp+0x60]
000074fc937dedd3  vmovaps xmm8, [rsp+0x70]
000074fc937dedd9  vmovaps xmm9, [rsp+0x80]
000074fc937dede2  vmovaps xmm10, [rsp+0x90]
000074fc937dedeb  vmovaps xmm11, [rsp+0xA0]
000074fc937dedf4  vmovaps xmm12, [rsp+0xB0]
000074fc937dedfd  vmovaps xmm13, [rsp+0xC0]
000074fc937dee06  vmovaps xmm14, [rsp+0xD0]
000074fc937dee0f  vmovaps xmm15, [rsp+0xE0]
000074fc937dee18  add rsp, 0xF0
000074fc937dee1f  pop r11
000074fc937dee21  pop r10
000074fc937dee23  pop r9
000074fc937dee25  pop r8
000074fc937dee27  pop rsi
000074fc937dee28  pop rdi
000074fc937dee29  pop rdx
000074fc937dee2a  pop rcx
000074fc937dee2b  pop rax
000074fc937dee2c  add rsp, 0x08
000074fc937dee30  jmp 0x000074FC937DC2EE
000074fc937dee35  sub rsp, 0x08
000074fc937dee39  push rax
000074fc937dee3a  push rcx
000074fc937dee3b  push rdx
000074fc937dee3c  push rdi
000074fc937dee3d  push rsi
000074fc937dee3e  push r8
000074fc937dee40  push r9
000074fc937dee42  push r10
000074fc937dee44  push r11
000074fc937dee46  sub rsp, 0xF0
000074fc937dee4d  vmovaps [rsp], xmm0
000074fc937dee52  vmovaps [rsp+0x10], xmm1
000074fc937dee58  vmovaps [rsp+0x20], xmm2
000074fc937dee5e  vmovaps [rsp+0x30], xmm3
000074fc937dee64  vmovaps [rsp+0x40], xmm5
000074fc937dee6a  vmovaps [rsp+0x50], xmm6
000074fc937dee70  vmovaps [rsp+0x60], xmm7
000074fc937dee76  vmovaps [rsp+0x70], xmm8
000074fc937dee7c  vmovaps [rsp+0x80], xmm9
000074fc937dee85  vmovaps [rsp+0x90], xmm10
000074fc937dee8e  vmovaps [rsp+0xA0], xmm11
000074fc937dee97  vmovaps [rsp+0xB0], xmm12
000074fc937deea0  vmovaps [rsp+0xC0], xmm13
000074fc937deea9  vmovaps [rsp+0xD0], xmm14
000074fc937deeb2  vmovaps [rsp+0xE0], xmm15
000074fc937deebb  sub rsp, 0x30
000074fc937deebf  movaps [rsp], xmm4
000074fc937deec3  movaps [rsp+0x10], xmm2
000074fc937deec8  movaps [rsp+0x20], xmm9
000074fc937deece  lea rdi, [rsp]
000074fc937deed2  mov esi, 0x00
000074fc937deed7  mov rax, 0x5D72CBC20530
000074fc937deee1  call rax
000074fc937deee3  movaps xmm4, [rsp]
000074fc937deee7  add rsp, 0x30
000074fc937deeeb  vmovaps xmm0, [rsp]
000074fc937deef0  vmovaps xmm1, [rsp+0x10]
000074fc937deef6  vmovaps xmm2, [rsp+0x20]
000074fc937deefc  vmovaps xmm3, [rsp+0x30]
000074fc937def02  vmovaps xmm5, [rsp+0x40]
000074fc937def08  vmovaps xmm6, [rsp+0x50]
000074fc937def0e  vmovaps xmm7, [rsp+0x60]
000074fc937def14  vmovaps xmm8, [rsp+0x70]
000074fc937def1a  vmovaps xmm9, [rsp+0x80]
000074fc937def23  vmovaps xmm10, [rsp+0x90]
000074fc937def2c  vmovaps xmm11, [rsp+0xA0]
000074fc937def35  vmovaps xmm12, [rsp+0xB0]
000074fc937def3e  vmovaps xmm13, [rsp+0xC0]
000074fc937def47  vmovaps xmm14, [rsp+0xD0]
000074fc937def50  vmovaps xmm15, [rsp+0xE0]
000074fc937def59  add rsp, 0xF0
000074fc937def60  pop r11
000074fc937def62  pop r10
000074fc937def64  pop r9
000074fc937def66  pop r8
000074fc937def68  pop rsi
000074fc937def69  pop rdi
000074fc937def6a  pop rdx
000074fc937def6b  pop rcx
000074fc937def6c  pop rax
000074fc937def6d  add rsp, 0x08
000074fc937def71  jmp 0x000074FC937DC31E
000074fc937def76  sub rsp, 0x08
000074fc937def7a  push rax
000074fc937def7b  push rcx
000074fc937def7c  push rdx
000074fc937def7d  push rdi
000074fc937def7e  push rsi
000074fc937def7f  push r8
000074fc937def81  push r9
000074fc937def83  push r10
000074fc937def85  push r11
000074fc937def87  sub rsp, 0xF0
000074fc937def8e  vmovaps [rsp], xmm0
000074fc937def93  vmovaps [rsp+0x10], xmm1
000074fc937def99  vmovaps [rsp+0x20], xmm2
000074fc937def9f  vmovaps [rsp+0x30], xmm3
000074fc937defa5  vmovaps [rsp+0x40], xmm4
000074fc937defab  vmovaps [rsp+0x50], xmm5
000074fc937defb1  vmovaps [rsp+0x60], xmm6
000074fc937defb7  vmovaps [rsp+0x70], xmm7
000074fc937defbd  vmovaps [rsp+0x80], xmm8
000074fc937defc6  vmovaps [rsp+0x90], xmm10
000074fc937defcf  vmovaps [rsp+0xA0], xmm11
000074fc937defd8  vmovaps [rsp+0xB0], xmm12
000074fc937defe1  vmovaps [rsp+0xC0], xmm13
000074fc937defea  vmovaps [rsp+0xD0], xmm14
000074fc937deff3  vmovaps [rsp+0xE0], xmm15
000074fc937deffc  sub rsp, 0x30
000074fc937df000  movaps [rsp], xmm9
000074fc937df005  movaps [rsp+0x10], xmm2
000074fc937df00a  movaps [rsp+0x20], xmm1
000074fc937df00f  lea rdi, [rsp]
000074fc937df013  mov esi, 0x00
000074fc937df018  mov rax, 0x5D72CBC20530
000074fc937df022  call rax
000074fc937df024  movaps xmm9, [rsp]
000074fc937df029  add rsp, 0x30
000074fc937df02d  vmovaps xmm0, [rsp]
000074fc937df032  vmovaps xmm1, [rsp+0x10]
000074fc937df038  vmovaps xmm2, [rsp+0x20]
000074fc937df03e  vmovaps xmm3, [rsp+0x30]
000074fc937df044  vmovaps xmm4, [rsp+0x40]
000074fc937df04a  vmovaps xmm5, [rsp+0x50]
000074fc937df050  vmovaps xmm6, [rsp+0x60]
000074fc937df056  vmovaps xmm7, [rsp+0x70]
000074fc937df05c  vmovaps xmm8, [rsp+0x80]
000074fc937df065  vmovaps xmm10, [rsp+0x90]
000074fc937df06e  vmovaps xmm11, [rsp+0xA0]
000074fc937df077  vmovaps xmm12, [rsp+0xB0]
000074fc937df080  vmovaps xmm13, [rsp+0xC0]
000074fc937df089  vmovaps xmm14, [rsp+0xD0]
000074fc937df092  vmovaps xmm15, [rsp+0xE0]
000074fc937df09b  add rsp, 0xF0
000074fc937df0a2  pop r11
000074fc937df0a4  pop r10
000074fc937df0a6  pop r9
000074fc937df0a8  pop r8
000074fc937df0aa  pop rsi
000074fc937df0ab  pop rdi
000074fc937df0ac  pop rdx
000074fc937df0ad  pop rcx
000074fc937df0ae  pop rax
000074fc937df0af  add rsp, 0x08
000074fc937df0b3  jmp 0x000074FC937DC354
000074fc937df0b8  sub rsp, 0x08
000074fc937df0bc  push rax
000074fc937df0bd  push rcx
000074fc937df0be  push rdx
000074fc937df0bf  push rdi
000074fc937df0c0  push rsi
000074fc937df0c1  push r8
000074fc937df0c3  push r9
000074fc937df0c5  push r10
000074fc937df0c7  push r11
000074fc937df0c9  sub rsp, 0xF0
000074fc937df0d0  vmovaps [rsp], xmm0
000074fc937df0d5  vmovaps [rsp+0x10], xmm2
000074fc937df0db  vmovaps [rsp+0x20], xmm3
000074fc937df0e1  vmovaps [rsp+0x30], xmm4
000074fc937df0e7  vmovaps [rsp+0x40], xmm5
000074fc937df0ed  vmovaps [rsp+0x50], xmm6
000074fc937df0f3  vmovaps [rsp+0x60], xmm7
000074fc937df0f9  vmovaps [rsp+0x70], xmm8
000074fc937df0ff  vmovaps [rsp+0x80], xmm9
000074fc937df108  vmovaps [rsp+0x90], xmm10
000074fc937df111  vmovaps [rsp+0xA0], xmm11
000074fc937df11a  vmovaps [rsp+0xB0], xmm12
000074fc937df123  vmovaps [rsp+0xC0], xmm13
000074fc937df12c  vmovaps [rsp+0xD0], xmm14
000074fc937df135  vmovaps [rsp+0xE0], xmm15
000074fc937df13e  sub rsp, 0x30
000074fc937df142  movaps [rsp], xmm1
000074fc937df146  movaps [rsp+0x10], xmm15
000074fc937df14c  movaps [rsp+0x20], xmm6
000074fc937df151  lea rdi, [rsp]
000074fc937df155  mov esi, 0x00
000074fc937df15a  mov rax, 0x5D72CBC20530
000074fc937df164  call rax
000074fc937df166  movaps xmm1, [rsp]
000074fc937df16a  add rsp, 0x30
000074fc937df16e  vmovaps xmm0, [rsp]
000074fc937df173  vmovaps xmm2, [rsp+0x10]
000074fc937df179  vmovaps xmm3, [rsp+0x20]
000074fc937df17f  vmovaps xmm4, [rsp+0x30]
000074fc937df185  vmovaps xmm5, [rsp+0x40]
000074fc937df18b  vmovaps xmm6, [rsp+0x50]
000074fc937df191  vmovaps xmm7, [rsp+0x60]
000074fc937df197  vmovaps xmm8, [rsp+0x70]
000074fc937df19d  vmovaps xmm9, [rsp+0x80]
000074fc937df1a6  vmovaps xmm10, [rsp+0x90]
000074fc937df1af  vmovaps xmm11, [rsp+0xA0]
000074fc937df1b8  vmovaps xmm12, [rsp+0xB0]
000074fc937df1c1  vmovaps xmm13, [rsp+0xC0]
000074fc937df1ca  vmovaps xmm14, [rsp+0xD0]
000074fc937df1d3  vmovaps xmm15, [rsp+0xE0]
000074fc937df1dc  add rsp, 0xF0
000074fc937df1e3  pop r11
000074fc937df1e5  pop r10
000074fc937df1e7  pop r9
000074fc937df1e9  pop r8
000074fc937df1eb  pop rsi
000074fc937df1ec  pop rdi
000074fc937df1ed  pop rdx
000074fc937df1ee  pop rcx
000074fc937df1ef  pop rax
000074fc937df1f0  add rsp, 0x08
000074fc937df1f4  jmp 0x000074FC937DC375
000074fc937df1f9  sub rsp, 0x08
000074fc937df1fd  push rax
000074fc937df1fe  push rcx
000074fc937df1ff  push rdx
000074fc937df200  push rdi
000074fc937df201  push rsi
000074fc937df202  push r8
000074fc937df204  push r9
000074fc937df206  push r10
000074fc937df208  push r11
000074fc937df20a  sub rsp, 0xF0
000074fc937df211  vmovaps [rsp], xmm0
000074fc937df216  vmovaps [rsp+0x10], xmm1
000074fc937df21c  vmovaps [rsp+0x20], xmm2
000074fc937df222  vmovaps [rsp+0x30], xmm3
000074fc937df228  vmovaps [rsp+0x40], xmm4
000074fc937df22e  vmovaps [rsp+0x50], xmm5
000074fc937df234  vmovaps [rsp+0x60], xmm6
000074fc937df23a  vmovaps [rsp+0x70], xmm7
000074fc937df240  vmovaps [rsp+0x80], xmm8
000074fc937df249  vmovaps [rsp+0x90], xmm9
000074fc937df252  vmovaps [rsp+0xA0], xmm10
000074fc937df25b  vmovaps [rsp+0xB0], xmm11
000074fc937df264  vmovaps [rsp+0xC0], xmm12
000074fc937df26d  vmovaps [rsp+0xD0], xmm13
000074fc937df276  vmovaps [rsp+0xE0], xmm14
000074fc937df27f  sub rsp, 0x30
000074fc937df283  movaps [rsp], xmm15
000074fc937df288  movaps [rsp+0x10], xmm5
000074fc937df28d  movaps [rsp+0x20], xmm3
000074fc937df292  lea rdi, [rsp]
000074fc937df296  mov esi, 0x00
000074fc937df29b  mov rax, 0x5D72CBC20530
000074fc937df2a5  call rax
000074fc937df2a7  movaps xmm15, [rsp]
000074fc937df2ac  add rsp, 0x30
000074fc937df2b0  vmovaps xmm0, [rsp]
000074fc937df2b5  vmovaps xmm1, [rsp+0x10]
000074fc937df2bb  vmovaps xmm2, [rsp+0x20]
000074fc937df2c1  vmovaps xmm3, [rsp+0x30]
000074fc937df2c7  vmovaps xmm4, [rsp+0x40]
000074fc937df2cd  vmovaps xmm5, [rsp+0x50]
000074fc937df2d3  vmovaps xmm6, [rsp+0x60]
000074fc937df2d9  vmovaps xmm7, [rsp+0x70]
000074fc937df2df  vmovaps xmm8, [rsp+0x80]
000074fc937df2e8  vmovaps xmm9, [rsp+0x90]
000074fc937df2f1  vmovaps xmm10, [rsp+0xA0]
000074fc937df2fa  vmovaps xmm11, [rsp+0xB0]
000074fc937df303  vmovaps xmm12, [rsp+0xC0]
000074fc937df30c  vmovaps xmm13, [rsp+0xD0]
000074fc937df315  vmovaps xmm14, [rsp+0xE0]
000074fc937df31e  add rsp, 0xF0
000074fc937df325  pop r11
000074fc937df327  pop r10
000074fc937df329  pop r9
000074fc937df32b  pop r8
000074fc937df32d  pop rsi
000074fc937df32e  pop rdi
000074fc937df32f  pop rdx
000074fc937df330  pop rcx
000074fc937df331  pop rax
000074fc937df332  add rsp, 0x08
000074fc937df336  jmp 0x000074FC937DC38F
000074fc937df33b  sub rsp, 0x08
000074fc937df33f  push rax
000074fc937df340  push rcx
000074fc937df341  push rdx
000074fc937df342  push rdi
000074fc937df343  push rsi
000074fc937df344  push r8
000074fc937df346  push r9
000074fc937df348  push r10
000074fc937df34a  push r11
000074fc937df34c  sub rsp, 0xF0
000074fc937df353  vmovaps [rsp], xmm0
000074fc937df358  vmovaps [rsp+0x10], xmm1
000074fc937df35e  vmovaps [rsp+0x20], xmm2
000074fc937df364  vmovaps [rsp+0x30], xmm3
000074fc937df36a  vmovaps [rsp+0x40], xmm4
000074fc937df370  vmovaps [rsp+0x50], xmm6
000074fc937df376  vmovaps [rsp+0x60], xmm7
000074fc937df37c  vmovaps [rsp+0x70], xmm8
000074fc937df382  vmovaps [rsp+0x80], xmm9
000074fc937df38b  vmovaps [rsp+0x90], xmm10
000074fc937df394  vmovaps [rsp+0xA0], xmm11
000074fc937df39d  vmovaps [rsp+0xB0], xmm12
000074fc937df3a6  vmovaps [rsp+0xC0], xmm13
000074fc937df3af  vmovaps [rsp+0xD0], xmm14
000074fc937df3b8  vmovaps [rsp+0xE0], xmm15
000074fc937df3c1  sub rsp, 0x30
000074fc937df3c5  movaps [rsp], xmm5
000074fc937df3c9  movaps [rsp+0x10], xmm8
000074fc937df3cf  movaps [rsp+0x20], xmm6
000074fc937df3d4  lea rdi, [rsp]
000074fc937df3d8  mov esi, 0x00
000074fc937df3dd  mov rax, 0x5D72CBC20530
000074fc937df3e7  call rax
000074fc937df3e9  movaps xmm5, [rsp]
000074fc937df3ed  add rsp, 0x30
000074fc937df3f1  vmovaps xmm0, [rsp]
000074fc937df3f6  vmovaps xmm1, [rsp+0x10]
000074fc937df3fc  vmovaps xmm2, [rsp+0x20]
000074fc937df402  vmovaps xmm3, [rsp+0x30]
000074fc937df408  vmovaps xmm4, [rsp+0x40]
000074fc937df40e  vmovaps xmm6, [rsp+0x50]
000074fc937df414  vmovaps xmm7, [rsp+0x60]
000074fc937df41a  vmovaps xmm8, [rsp+0x70]
000074fc937df420  vmovaps xmm9, [rsp+0x80]
000074fc937df429  vmovaps xmm10, [rsp+0x90]
000074fc937df432  vmovaps xmm11, [rsp+0xA0]
000074fc937df43b  vmovaps xmm12, [rsp+0xB0]
000074fc937df444  vmovaps xmm13, [rsp+0xC0]
000074fc937df44d  vmovaps xmm14, [rsp+0xD0]
000074fc937df456  vmovaps xmm15, [rsp+0xE0]
000074fc937df45f  add rsp, 0xF0
000074fc937df466  pop r11
000074fc937df468  pop r10
000074fc937df46a  pop r9
000074fc937df46c  pop r8
000074fc937df46e  pop rsi
000074fc937df46f  pop rdi
000074fc937df470  pop rdx
000074fc937df471  pop rcx
000074fc937df472  pop rax
000074fc937df473  add rsp, 0x08
000074fc937df477  jmp 0x000074FC937DC3B3
000074fc937df47c  sub rsp, 0x08
000074fc937df480  push rax
000074fc937df481  push rcx
000074fc937df482  push rdx
000074fc937df483  push rdi
000074fc937df484  push rsi
000074fc937df485  push r8
000074fc937df487  push r9
000074fc937df489  push r10
000074fc937df48b  push r11
000074fc937df48d  sub rsp, 0xF0
000074fc937df494  vmovaps [rsp], xmm0
000074fc937df499  vmovaps [rsp+0x10], xmm1
000074fc937df49f  vmovaps [rsp+0x20], xmm2
000074fc937df4a5  vmovaps [rsp+0x30], xmm3
000074fc937df4ab  vmovaps [rsp+0x40], xmm4
000074fc937df4b1  vmovaps [rsp+0x50], xmm5
000074fc937df4b7  vmovaps [rsp+0x60], xmm7
000074fc937df4bd  vmovaps [rsp+0x70], xmm8
000074fc937df4c3  vmovaps [rsp+0x80], xmm9
000074fc937df4cc  vmovaps [rsp+0x90], xmm10
000074fc937df4d5  vmovaps [rsp+0xA0], xmm11
000074fc937df4de  vmovaps [rsp+0xB0], xmm12
000074fc937df4e7  vmovaps [rsp+0xC0], xmm13
000074fc937df4f0  vmovaps [rsp+0xD0], xmm14
000074fc937df4f9  vmovaps [rsp+0xE0], xmm15
000074fc937df502  sub rsp, 0x30
000074fc937df506  movaps [rsp], xmm6
000074fc937df50a  movaps [rsp+0x10], xmm10
000074fc937df510  movaps [rsp+0x20], xmm8
000074fc937df516  lea rdi, [rsp]
000074fc937df51a  mov esi, 0x00
000074fc937df51f  mov rax, 0x5D72CBC20530
000074fc937df529  call rax
000074fc937df52b  movaps xmm6, [rsp]
000074fc937df52f  add rsp, 0x30
000074fc937df533  vmovaps xmm0, [rsp]
000074fc937df538  vmovaps xmm1, [rsp+0x10]
000074fc937df53e  vmovaps xmm2, [rsp+0x20]
000074fc937df544  vmovaps xmm3, [rsp+0x30]
000074fc937df54a  vmovaps xmm4, [rsp+0x40]
000074fc937df550  vmovaps xmm5, [rsp+0x50]
000074fc937df556  vmovaps xmm7, [rsp+0x60]
000074fc937df55c  vmovaps xmm8, [rsp+0x70]
000074fc937df562  vmovaps xmm9, [rsp+0x80]
000074fc937df56b  vmovaps xmm10, [rsp+0x90]
000074fc937df574  vmovaps xmm11, [rsp+0xA0]
000074fc937df57d  vmovaps xmm12, [rsp+0xB0]
000074fc937df586  vmovaps xmm13, [rsp+0xC0]
000074fc937df58f  vmovaps xmm14, [rsp+0xD0]
000074fc937df598  vmovaps xmm15, [rsp+0xE0]
000074fc937df5a1  add rsp, 0xF0
000074fc937df5a8  pop r11
000074fc937df5aa  pop r10
000074fc937df5ac  pop r9
000074fc937df5ae  pop r8
000074fc937df5b0  pop rsi
000074fc937df5b1  pop rdi
000074fc937df5b2  pop rdx
000074fc937df5b3  pop rcx
000074fc937df5b4  pop rax
000074fc937df5b5  add rsp, 0x08
000074fc937df5b9  jmp 0x000074FC937DC3D8
000074fc937df5be  sub rsp, 0x08
000074fc937df5c2  push rax
000074fc937df5c3  push rcx
000074fc937df5c4  push rdx
000074fc937df5c5  push rdi
000074fc937df5c6  push rsi
000074fc937df5c7  push r8
000074fc937df5c9  push r9
000074fc937df5cb  push r10
000074fc937df5cd  push r11
000074fc937df5cf  sub rsp, 0xF0
000074fc937df5d6  vmovaps [rsp], xmm0
000074fc937df5db  vmovaps [rsp+0x10], xmm1
000074fc937df5e1  vmovaps [rsp+0x20], xmm2
000074fc937df5e7  vmovaps [rsp+0x30], xmm3
000074fc937df5ed  vmovaps [rsp+0x40], xmm4
000074fc937df5f3  vmovaps [rsp+0x50], xmm5
000074fc937df5f9  vmovaps [rsp+0x60], xmm6
000074fc937df5ff  vmovaps [rsp+0x70], xmm7
000074fc937df605  vmovaps [rsp+0x80], xmm8
000074fc937df60e  vmovaps [rsp+0x90], xmm9
000074fc937df617  vmovaps [rsp+0xA0], xmm11
000074fc937df620  vmovaps [rsp+0xB0], xmm12
000074fc937df629  vmovaps [rsp+0xC0], xmm13
000074fc937df632  vmovaps [rsp+0xD0], xmm14
000074fc937df63b  vmovaps [rsp+0xE0], xmm15
000074fc937df644  sub rsp, 0x30
000074fc937df648  movaps [rsp], xmm10
000074fc937df64d  movaps [rsp+0x10], xmm8
000074fc937df653  movaps [rsp+0x20], xmm14
000074fc937df659  lea rdi, [rsp]
000074fc937df65d  mov esi, 0x00
000074fc937df662  mov rax, 0x5D72CBC20530
000074fc937df66c  call rax
000074fc937df66e  movaps xmm10, [rsp]
000074fc937df673  add rsp, 0x30
000074fc937df677  vmovaps xmm0, [rsp]
000074fc937df67c  vmovaps xmm1, [rsp+0x10]
000074fc937df682  vmovaps xmm2, [rsp+0x20]
000074fc937df688  vmovaps xmm3, [rsp+0x30]
000074fc937df68e  vmovaps xmm4, [rsp+0x40]
000074fc937df694  vmovaps xmm5, [rsp+0x50]
000074fc937df69a  vmovaps xmm6, [rsp+0x60]
000074fc937df6a0  vmovaps xmm7, [rsp+0x70]
000074fc937df6a6  vmovaps xmm8, [rsp+0x80]
000074fc937df6af  vmovaps xmm9, [rsp+0x90]
000074fc937df6b8  vmovaps xmm11, [rsp+0xA0]
000074fc937df6c1  vmovaps xmm12, [rsp+0xB0]
000074fc937df6ca  vmovaps xmm13, [rsp+0xC0]
000074fc937df6d3  vmovaps xmm14, [rsp+0xD0]
000074fc937df6dc  vmovaps xmm15, [rsp+0xE0]
000074fc937df6e5  add rsp, 0xF0
000074fc937df6ec  pop r11
000074fc937df6ee  pop r10
000074fc937df6f0  pop r9
000074fc937df6f2  pop r8
000074fc937df6f4  pop rsi
000074fc937df6f5  pop rdi
000074fc937df6f6  pop rdx
000074fc937df6f7  pop rcx
000074fc937df6f8  pop rax
000074fc937df6f9  add rsp, 0x08
000074fc937df6fd  jmp 0x000074FC937DC3F8
000074fc937df702  sub rsp, 0x08
000074fc937df706  push rax
000074fc937df707  push rcx
000074fc937df708  push rdx
000074fc937df709  push rdi
000074fc937df70a  push rsi
000074fc937df70b  push r8
000074fc937df70d  push r9
000074fc937df70f  push r10
000074fc937df711  push r11
000074fc937df713  sub rsp, 0xF0
000074fc937df71a  vmovaps [rsp], xmm0
000074fc937df71f  vmovaps [rsp+0x10], xmm1
000074fc937df725  vmovaps [rsp+0x20], xmm2
000074fc937df72b  vmovaps [rsp+0x30], xmm3
000074fc937df731  vmovaps [rsp+0x40], xmm4
000074fc937df737  vmovaps [rsp+0x50], xmm5
000074fc937df73d  vmovaps [rsp+0x60], xmm6
000074fc937df743  vmovaps [rsp+0x70], xmm7
000074fc937df749  vmovaps [rsp+0x80], xmm8
000074fc937df752  vmovaps [rsp+0x90], xmm9
000074fc937df75b  vmovaps [rsp+0xA0], xmm10
000074fc937df764  vmovaps [rsp+0xB0], xmm11
000074fc937df76d  vmovaps [rsp+0xC0], xmm12
000074fc937df776  vmovaps [rsp+0xD0], xmm13
000074fc937df77f  vmovaps [rsp+0xE0], xmm15
000074fc937df788  sub rsp, 0x30
000074fc937df78c  movaps [rsp], xmm14
000074fc937df791  movaps [rsp+0x10], xmm8
000074fc937df797  movaps [rsp+0x20], xmm4
000074fc937df79c  lea rdi, [rsp]
000074fc937df7a0  mov esi, 0x00
000074fc937df7a5  mov rax, 0x5D72CBC20530
000074fc937df7af  call rax
000074fc937df7b1  movaps xmm14, [rsp]
000074fc937df7b6  add rsp, 0x30
000074fc937df7ba  vmovaps xmm0, [rsp]
000074fc937df7bf  vmovaps xmm1, [rsp+0x10]
000074fc937df7c5  vmovaps xmm2, [rsp+0x20]
000074fc937df7cb  vmovaps xmm3, [rsp+0x30]
000074fc937df7d1  vmovaps xmm4, [rsp+0x40]
000074fc937df7d7  vmovaps xmm5, [rsp+0x50]
000074fc937df7dd  vmovaps xmm6, [rsp+0x60]
000074fc937df7e3  vmovaps xmm7, [rsp+0x70]
000074fc937df7e9  vmovaps xmm8, [rsp+0x80]
000074fc937df7f2  vmovaps xmm9, [rsp+0x90]
000074fc937df7fb  vmovaps xmm10, [rsp+0xA0]
000074fc937df804  vmovaps xmm11, [rsp+0xB0]
000074fc937df80d  vmovaps xmm12, [rsp+0xC0]
000074fc937df816  vmovaps xmm13, [rsp+0xD0]
000074fc937df81f  vmovaps xmm15, [rsp+0xE0]
000074fc937df828  add rsp, 0xF0
000074fc937df82f  pop r11
000074fc937df831  pop r10
000074fc937df833  pop r9
000074fc937df835  pop r8
000074fc937df837  pop rsi
000074fc937df838  pop rdi
000074fc937df839  pop rdx
000074fc937df83a  pop rcx
000074fc937df83b  pop rax
000074fc937df83c  add rsp, 0x08
000074fc937df840  jmp 0x000074FC937DC418
000074fc937df845  sub rsp, 0x08
000074fc937df849  push rax
000074fc937df84a  push rcx
000074fc937df84b  push rdx
000074fc937df84c  push rdi
000074fc937df84d  push rsi
000074fc937df84e  push r8
000074fc937df850  push r9
000074fc937df852  push r10
000074fc937df854  push r11
000074fc937df856  sub rsp, 0xF0
000074fc937df85d  vmovaps [rsp], xmm0
000074fc937df862  vmovaps [rsp+0x10], xmm1
000074fc937df868  vmovaps [rsp+0x20], xmm2
000074fc937df86e  vmovaps [rsp+0x30], xmm3
000074fc937df874  vmovaps [rsp+0x40], xmm5
000074fc937df87a  vmovaps [rsp+0x50], xmm6
000074fc937df880  vmovaps [rsp+0x60], xmm7
000074fc937df886  vmovaps [rsp+0x70], xmm8
000074fc937df88c  vmovaps [rsp+0x80], xmm9
000074fc937df895  vmovaps [rsp+0x90], xmm10
000074fc937df89e  vmovaps [rsp+0xA0], xmm11
000074fc937df8a7  vmovaps [rsp+0xB0], xmm12
000074fc937df8b0  vmovaps [rsp+0xC0], xmm13
000074fc937df8b9  vmovaps [rsp+0xD0], xmm14
000074fc937df8c2  vmovaps [rsp+0xE0], xmm15
000074fc937df8cb  sub rsp, 0x30
000074fc937df8cf  movaps [rsp], xmm4
000074fc937df8d3  movaps [rsp+0x10], xmm13
000074fc937df8d9  movaps [rsp+0x20], xmm8
000074fc937df8df  lea rdi, [rsp]
000074fc937df8e3  mov esi, 0x00
000074fc937df8e8  mov rax, 0x5D72CBC20530
000074fc937df8f2  call rax
000074fc937df8f4  movaps xmm4, [rsp]
000074fc937df8f8  add rsp, 0x30
000074fc937df8fc  vmovaps xmm0, [rsp]
000074fc937df901  vmovaps xmm1, [rsp+0x10]
000074fc937df907  vmovaps xmm2, [rsp+0x20]
000074fc937df90d  vmovaps xmm3, [rsp+0x30]
000074fc937df913  vmovaps xmm5, [rsp+0x40]
000074fc937df919  vmovaps xmm6, [rsp+0x50]
000074fc937df91f  vmovaps xmm7, [rsp+0x60]
000074fc937df925  vmovaps xmm8, [rsp+0x70]
000074fc937df92b  vmovaps xmm9, [rsp+0x80]
000074fc937df934  vmovaps xmm10, [rsp+0x90]
000074fc937df93d  vmovaps xmm11, [rsp+0xA0]
000074fc937df946  vmovaps xmm12, [rsp+0xB0]
000074fc937df94f  vmovaps xmm13, [rsp+0xC0]
000074fc937df958  vmovaps xmm14, [rsp+0xD0]
000074fc937df961  vmovaps xmm15, [rsp+0xE0]
000074fc937df96a  add rsp, 0xF0
000074fc937df971  pop r11
000074fc937df973  pop r10
000074fc937df975  pop r9
000074fc937df977  pop r8
000074fc937df979  pop rsi
000074fc937df97a  pop rdi
000074fc937df97b  pop rdx
000074fc937df97c  pop rcx
000074fc937df97d  pop rax
000074fc937df97e  add rsp, 0x08
000074fc937df982  jmp 0x000074FC937DC43D
000074fc937df987  sub rsp, 0x08
000074fc937df98b  push rax
000074fc937df98c  push rcx
000074fc937df98d  push rdx
000074fc937df98e  push rdi
000074fc937df98f  push rsi
000074fc937df990  push r8
000074fc937df992  push r9
000074fc937df994  push r10
000074fc937df996  push r11
000074fc937df998  sub rsp, 0xF0
000074fc937df99f  vmovaps [rsp], xmm0
000074fc937df9a4  vmovaps [rsp+0x10], xmm1
000074fc937df9aa  vmovaps [rsp+0x20], xmm2
000074fc937df9b0  vmovaps [rsp+0x30], xmm3
000074fc937df9b6  vmovaps [rsp+0x40], xmm4
000074fc937df9bc  vmovaps [rsp+0x50], xmm5
000074fc937df9c2  vmovaps [rsp+0x60], xmm6
000074fc937df9c8  vmovaps [rsp+0x70], xmm7
000074fc937df9ce  vmovaps [rsp+0x80], xmm8
000074fc937df9d7  vmovaps [rsp+0x90], xmm9
000074fc937df9e0  vmovaps [rsp+0xA0], xmm10
000074fc937df9e9  vmovaps [rsp+0xB0], xmm11
000074fc937df9f2  vmovaps [rsp+0xC0], xmm12
000074fc937df9fb  vmovaps [rsp+0xD0], xmm14
000074fc937dfa04  vmovaps [rsp+0xE0], xmm15
000074fc937dfa0d  sub rsp, 0x30
000074fc937dfa11  movaps [rsp], xmm13
000074fc937dfa16  movaps [rsp+0x10], xmm15
000074fc937dfa1c  movaps [rsp+0x20], xmm9
000074fc937dfa22  lea rdi, [rsp]
000074fc937dfa26  mov esi, 0x00
000074fc937dfa2b  mov rax, 0x5D72CBC20530
000074fc937dfa35  call rax
000074fc937dfa37  movaps xmm13, [rsp]
000074fc937dfa3c  add rsp, 0x30
000074fc937dfa40  vmovaps xmm0, [rsp]
000074fc937dfa45  vmovaps xmm1, [rsp+0x10]
000074fc937dfa4b  vmovaps xmm2, [rsp+0x20]
000074fc937dfa51  vmovaps xmm3, [rsp+0x30]
000074fc937dfa57  vmovaps xmm4, [rsp+0x40]
000074fc937dfa5d  vmovaps xmm5, [rsp+0x50]
000074fc937dfa63  vmovaps xmm6, [rsp+0x60]
000074fc937dfa69  vmovaps xmm7, [rsp+0x70]
000074fc937dfa6f  vmovaps xmm8, [rsp+0x80]
000074fc937dfa78  vmovaps xmm9, [rsp+0x90]
000074fc937dfa81  vmovaps xmm10, [rsp+0xA0]
000074fc937dfa8a  vmovaps xmm11, [rsp+0xB0]
000074fc937dfa93  vmovaps xmm12, [rsp+0xC0]
000074fc937dfa9c  vmovaps xmm14, [rsp+0xD0]
000074fc937dfaa5  vmovaps xmm15, [rsp+0xE0]
000074fc937dfaae  add rsp, 0xF0
000074fc937dfab5  pop r11
000074fc937dfab7  pop r10
000074fc937dfab9  pop r9
000074fc937dfabb  pop r8
000074fc937dfabd  pop rsi
000074fc937dfabe  pop rdi
000074fc937dfabf  pop rdx
000074fc937dfac0  pop rcx
000074fc937dfac1  pop rax
000074fc937dfac2  add rsp, 0x08
000074fc937dfac6  jmp 0x000074FC937DC458
000074fc937dfacb  sub rsp, 0x08
000074fc937dfacf  push rax
000074fc937dfad0  push rcx
000074fc937dfad1  push rdx
000074fc937dfad2  push rdi
000074fc937dfad3  push rsi
000074fc937dfad4  push r8
000074fc937dfad6  push r9
000074fc937dfad8  push r10
000074fc937dfada  push r11
000074fc937dfadc  sub rsp, 0xF0
000074fc937dfae3  vmovaps [rsp], xmm0
000074fc937dfae8  vmovaps [rsp+0x10], xmm1
000074fc937dfaee  vmovaps [rsp+0x20], xmm2
000074fc937dfaf4  vmovaps [rsp+0x30], xmm3
000074fc937dfafa  vmovaps [rsp+0x40], xmm4
000074fc937dfb00  vmovaps [rsp+0x50], xmm5
000074fc937dfb06  vmovaps [rsp+0x60], xmm6
000074fc937dfb0c  vmovaps [rsp+0x70], xmm7
000074fc937dfb12  vmovaps [rsp+0x80], xmm8
000074fc937dfb1b  vmovaps [rsp+0x90], xmm9
000074fc937dfb24  vmovaps [rsp+0xA0], xmm10
000074fc937dfb2d  vmovaps [rsp+0xB0], xmm11
000074fc937dfb36  vmovaps [rsp+0xC0], xmm12
000074fc937dfb3f  vmovaps [rsp+0xD0], xmm13
000074fc937dfb48  vmovaps [rsp+0xE0], xmm14
000074fc937dfb51  sub rsp, 0x30
000074fc937dfb55  movaps [rsp], xmm15
000074fc937dfb5a  movaps [rsp+0x10], xmm1
000074fc937dfb5f  movaps [rsp+0x20], xmm5
000074fc937dfb64  lea rdi, [rsp]
000074fc937dfb68  mov esi, 0x00
000074fc937dfb6d  mov rax, 0x5D72CBC20530
000074fc937dfb77  call rax
000074fc937dfb79  movaps xmm15, [rsp]
000074fc937dfb7e  add rsp, 0x30
000074fc937dfb82  vmovaps xmm0, [rsp]
000074fc937dfb87  vmovaps xmm1, [rsp+0x10]
000074fc937dfb8d  vmovaps xmm2, [rsp+0x20]
000074fc937dfb93  vmovaps xmm3, [rsp+0x30]
000074fc937dfb99  vmovaps xmm4, [rsp+0x40]
000074fc937dfb9f  vmovaps xmm5, [rsp+0x50]
000074fc937dfba5  vmovaps xmm6, [rsp+0x60]
000074fc937dfbab  vmovaps xmm7, [rsp+0x70]
000074fc937dfbb1  vmovaps xmm8, [rsp+0x80]
000074fc937dfbba  vmovaps xmm9, [rsp+0x90]
000074fc937dfbc3  vmovaps xmm10, [rsp+0xA0]
000074fc937dfbcc  vmovaps xmm11, [rsp+0xB0]
000074fc937dfbd5  vmovaps xmm12, [rsp+0xC0]
000074fc937dfbde  vmovaps xmm13, [rsp+0xD0]
000074fc937dfbe7  vmovaps xmm14, [rsp+0xE0]
000074fc937dfbf0  add rsp, 0xF0
000074fc937dfbf7  pop r11
000074fc937dfbf9  pop r10
000074fc937dfbfb  pop r9
000074fc937dfbfd  pop r8
000074fc937dfbff  pop rsi
000074fc937dfc00  pop rdi
000074fc937dfc01  pop rdx
000074fc937dfc02  pop rcx
000074fc937dfc03  pop rax
000074fc937dfc04  add rsp, 0x08
000074fc937dfc08  jmp 0x000074FC937DC473
000074fc937dfc0d  call 0x000074FC936B52F0
000074fc937dfc12  jmp 0x000074FC937DC4CE
000074fc937dfc17  sub rsp, 0x08
000074fc937dfc1b  push rax
000074fc937dfc1c  push rcx
000074fc937dfc1d  push rdx
000074fc937dfc1e  push rdi
000074fc937dfc1f  push rsi
000074fc937dfc20  push r8
000074fc937dfc22  push r9
000074fc937dfc24  push r10
000074fc937dfc26  push r11
000074fc937dfc28  sub rsp, 0xF0
000074fc937dfc2f  vmovaps [rsp], xmm0
000074fc937dfc34  vmovaps [rsp+0x10], xmm1
000074fc937dfc3a  vmovaps [rsp+0x20], xmm2
000074fc937dfc40  vmovaps [rsp+0x30], xmm3
000074fc937dfc46  vmovaps [rsp+0x40], xmm4
000074fc937dfc4c  vmovaps [rsp+0x50], xmm5
000074fc937dfc52  vmovaps [rsp+0x60], xmm6
000074fc937dfc58  vmovaps [rsp+0x70], xmm7
000074fc937dfc5e  vmovaps [rsp+0x80], xmm8
000074fc937dfc67  vmovaps [rsp+0x90], xmm10
000074fc937dfc70  vmovaps [rsp+0xA0], xmm11
000074fc937dfc79  vmovaps [rsp+0xB0], xmm12
000074fc937dfc82  vmovaps [rsp+0xC0], xmm13
000074fc937dfc8b  vmovaps [rsp+0xD0], xmm14
000074fc937dfc94  vmovaps [rsp+0xE0], xmm15
000074fc937dfc9d  sub rsp, 0x30
000074fc937dfca1  movaps [rsp], xmm9
000074fc937dfca6  movaps [rsp+0x10], xmm8
000074fc937dfcac  movaps [rsp+0x20], xmm11
000074fc937dfcb2  lea rdi, [rsp]
000074fc937dfcb6  mov esi, 0x00
000074fc937dfcbb  mov rax, 0x5D72CBC20530
000074fc937dfcc5  call rax
000074fc937dfcc7  movaps xmm9, [rsp]
000074fc937dfccc  add rsp, 0x30
000074fc937dfcd0  vmovaps xmm0, [rsp]
000074fc937dfcd5  vmovaps xmm1, [rsp+0x10]
000074fc937dfcdb  vmovaps xmm2, [rsp+0x20]
000074fc937dfce1  vmovaps xmm3, [rsp+0x30]
000074fc937dfce7  vmovaps xmm4, [rsp+0x40]
000074fc937dfced  vmovaps xmm5, [rsp+0x50]
000074fc937dfcf3  vmovaps xmm6, [rsp+0x60]
000074fc937dfcf9  vmovaps xmm7, [rsp+0x70]
000074fc937dfcff  vmovaps xmm8, [rsp+0x80]
000074fc937dfd08  vmovaps xmm10, [rsp+0x90]
000074fc937dfd11  vmovaps xmm11, [rsp+0xA0]
000074fc937dfd1a  vmovaps xmm12, [rsp+0xB0]
000074fc937dfd23  vmovaps xmm13, [rsp+0xC0]
000074fc937dfd2c  vmovaps xmm14, [rsp+0xD0]
000074fc937dfd35  vmovaps xmm15, [rsp+0xE0]
000074fc937dfd3e  add rsp, 0xF0
000074fc937dfd45  pop r11
000074fc937dfd47  pop r10
000074fc937dfd49  pop r9
000074fc937dfd4b  pop r8
000074fc937dfd4d  pop rsi
000074fc937dfd4e  pop rdi
000074fc937dfd4f  pop rdx
000074fc937dfd50  pop rcx
000074fc937dfd51  pop rax
000074fc937dfd52  add rsp, 0x08
000074fc937dfd56  jmp 0x000074FC937DC505
000074fc937dfd5b  sub rsp, 0x08
000074fc937dfd5f  push rax
000074fc937dfd60  push rcx
000074fc937dfd61  push rdx
000074fc937dfd62  push rdi
000074fc937dfd63  push rsi
000074fc937dfd64  push r8
000074fc937dfd66  push r9
000074fc937dfd68  push r10
000074fc937dfd6a  push r11
000074fc937dfd6c  sub rsp, 0xF0
000074fc937dfd73  vmovaps [rsp], xmm0
000074fc937dfd78  vmovaps [rsp+0x10], xmm1
000074fc937dfd7e  vmovaps [rsp+0x20], xmm2
000074fc937dfd84  vmovaps [rsp+0x30], xmm3
000074fc937dfd8a  vmovaps [rsp+0x40], xmm4
000074fc937dfd90  vmovaps [rsp+0x50], xmm5
000074fc937dfd96  vmovaps [rsp+0x60], xmm6
000074fc937dfd9c  vmovaps [rsp+0x70], xmm7
000074fc937dfda2  vmovaps [rsp+0x80], xmm8
000074fc937dfdab  vmovaps [rsp+0x90], xmm9
000074fc937dfdb4  vmovaps [rsp+0xA0], xmm10
000074fc937dfdbd  vmovaps [rsp+0xB0], xmm12
000074fc937dfdc6  vmovaps [rsp+0xC0], xmm13
000074fc937dfdcf  vmovaps [rsp+0xD0], xmm14
000074fc937dfdd8  vmovaps [rsp+0xE0], xmm15
000074fc937dfde1  sub rsp, 0x30
000074fc937dfde5  movaps [rsp], xmm11
000074fc937dfdea  movaps [rsp+0x10], xmm10
000074fc937dfdf0  movaps [rsp+0x20], xmm6
000074fc937dfdf5  lea rdi, [rsp]
000074fc937dfdf9  mov esi, 0x00
000074fc937dfdfe  mov rax, 0x5D72CBC20530
000074fc937dfe08  call rax
000074fc937dfe0a  movaps xmm11, [rsp]
000074fc937dfe0f  add rsp, 0x30
000074fc937dfe13  vmovaps xmm0, [rsp]
000074fc937dfe18  vmovaps xmm1, [rsp+0x10]
000074fc937dfe1e  vmovaps xmm2, [rsp+0x20]
000074fc937dfe24  vmovaps xmm3, [rsp+0x30]
000074fc937dfe2a  vmovaps xmm4, [rsp+0x40]
000074fc937dfe30  vmovaps xmm5, [rsp+0x50]
000074fc937dfe36  vmovaps xmm6, [rsp+0x60]
000074fc937dfe3c  vmovaps xmm7, [rsp+0x70]
000074fc937dfe42  vmovaps xmm8, [rsp+0x80]
000074fc937dfe4b  vmovaps xmm9, [rsp+0x90]
000074fc937dfe54  vmovaps xmm10, [rsp+0xA0]
000074fc937dfe5d  vmovaps xmm12, [rsp+0xB0]
000074fc937dfe66  vmovaps xmm13, [rsp+0xC0]
000074fc937dfe6f  vmovaps xmm14, [rsp+0xD0]
000074fc937dfe78  vmovaps xmm15, [rsp+0xE0]
000074fc937dfe81  add rsp, 0xF0
000074fc937dfe88  pop r11
000074fc937dfe8a  pop r10
000074fc937dfe8c  pop r9
000074fc937dfe8e  pop r8
000074fc937dfe90  pop rsi
000074fc937dfe91  pop rdi
000074fc937dfe92  pop rdx
000074fc937dfe93  pop rcx
000074fc937dfe94  pop rax
000074fc937dfe95  add rsp, 0x08
000074fc937dfe99  jmp 0x000074FC937DC520
000074fc937dfe9e  sub rsp, 0x08
000074fc937dfea2  push rax
000074fc937dfea3  push rcx
000074fc937dfea4  push rdx
000074fc937dfea5  push rdi
000074fc937dfea6  push rsi
000074fc937dfea7  push r8
000074fc937dfea9  push r9
000074fc937dfeab  push r10
000074fc937dfead  push r11
000074fc937dfeaf  sub rsp, 0xF0
000074fc937dfeb6  vmovaps [rsp], xmm0
000074fc937dfebb  vmovaps [rsp+0x10], xmm1
000074fc937dfec1  vmovaps [rsp+0x20], xmm2
000074fc937dfec7  vmovaps [rsp+0x30], xmm3
000074fc937dfecd  vmovaps [rsp+0x40], xmm4
000074fc937dfed3  vmovaps [rsp+0x50], xmm5
000074fc937dfed9  vmovaps [rsp+0x60], xmm6
000074fc937dfedf  vmovaps [rsp+0x70], xmm7
000074fc937dfee5  vmovaps [rsp+0x80], xmm8
000074fc937dfeee  vmovaps [rsp+0x90], xmm9
000074fc937dfef7  vmovaps [rsp+0xA0], xmm11
000074fc937dff00  vmovaps [rsp+0xB0], xmm12
000074fc937dff09  vmovaps [rsp+0xC0], xmm13
000074fc937dff12  vmovaps [rsp+0xD0], xmm14
000074fc937dff1b  vmovaps [rsp+0xE0], xmm15
000074fc937dff24  sub rsp, 0x30
000074fc937dff28  movaps [rsp], xmm10
000074fc937dff2d  movaps [rsp+0x10], xmm14
000074fc937dff33  movaps [rsp+0x20], xmm4
000074fc937dff38  lea rdi, [rsp]
000074fc937dff3c  mov esi, 0x00
000074fc937dff41  mov rax, 0x5D72CBC20530
000074fc937dff4b  call rax
000074fc937dff4d  movaps xmm10, [rsp]
000074fc937dff52  add rsp, 0x30
000074fc937dff56  vmovaps xmm0, [rsp]
000074fc937dff5b  vmovaps xmm1, [rsp+0x10]
000074fc937dff61  vmovaps xmm2, [rsp+0x20]
000074fc937dff67  vmovaps xmm3, [rsp+0x30]
000074fc937dff6d  vmovaps xmm4, [rsp+0x40]
000074fc937dff73  vmovaps xmm5, [rsp+0x50]
000074fc937dff79  vmovaps xmm6, [rsp+0x60]
000074fc937dff7f  vmovaps xmm7, [rsp+0x70]
000074fc937dff85  vmovaps xmm8, [rsp+0x80]
000074fc937dff8e  vmovaps xmm9, [rsp+0x90]
000074fc937dff97  vmovaps xmm11, [rsp+0xA0]
000074fc937dffa0  vmovaps xmm12, [rsp+0xB0]
000074fc937dffa9  vmovaps xmm13, [rsp+0xC0]
000074fc937dffb2  vmovaps xmm14, [rsp+0xD0]
000074fc937dffbb  vmovaps xmm15, [rsp+0xE0]
000074fc937dffc4  add rsp, 0xF0
000074fc937dffcb  pop r11
000074fc937dffcd  pop r10
000074fc937dffcf  pop r9
000074fc937dffd1  pop r8
000074fc937dffd3  pop rsi
000074fc937dffd4  pop rdi
000074fc937dffd5  pop rdx
000074fc937dffd6  pop rcx
000074fc937dffd7  pop rax
000074fc937dffd8  add rsp, 0x08
000074fc937dffdc  jmp 0x000074FC937DC53B
000074fc937dffe1  sub rsp, 0x08
000074fc937dffe5  push rax
000074fc937dffe6  push rcx
000074fc937dffe7  push rdx
000074fc937dffe8  push rdi
000074fc937dffe9  push rsi
000074fc937dffea  push r8
000074fc937dffec  push r9
000074fc937dffee  push r10
000074fc937dfff0  push r11
000074fc937dfff2  sub rsp, 0xF0
000074fc937dfff9  vmovaps [rsp], xmm0
000074fc937dfffe  vmovaps [rsp+0x10], xmm1
000074fc937e0004  vmovaps [rsp+0x20], xmm2
000074fc937e000a  vmovaps [rsp+0x30], xmm3
000074fc937e0010  vmovaps [rsp+0x40], xmm4
000074fc937e0016  vmovaps [rsp+0x50], xmm5
000074fc937e001c  vmovaps [rsp+0x60], xmm6
000074fc937e0022  vmovaps [rsp+0x70], xmm7
000074fc937e0028  vmovaps [rsp+0x80], xmm9
000074fc937e0031  vmovaps [rsp+0x90], xmm10
000074fc937e003a  vmovaps [rsp+0xA0], xmm11
000074fc937e0043  vmovaps [rsp+0xB0], xmm12
000074fc937e004c  vmovaps [rsp+0xC0], xmm13
000074fc937e0055  vmovaps [rsp+0xD0], xmm14
000074fc937e005e  vmovaps [rsp+0xE0], xmm15
000074fc937e0067  sub rsp, 0x30
000074fc937e006b  movaps [rsp], xmm8
000074fc937e0070  movaps [rsp+0x10], xmm1
000074fc937e0075  movaps [rsp+0x20], xmm14
000074fc937e007b  lea rdi, [rsp]
000074fc937e007f  mov esi, 0x00
000074fc937e0084  mov rax, 0x5D72CBC20530
000074fc937e008e  call rax
000074fc937e0090  movaps xmm8, [rsp]
000074fc937e0095  add rsp, 0x30
000074fc937e0099  vmovaps xmm0, [rsp]
000074fc937e009e  vmovaps xmm1, [rsp+0x10]
000074fc937e00a4  vmovaps xmm2, [rsp+0x20]
000074fc937e00aa  vmovaps xmm3, [rsp+0x30]
000074fc937e00b0  vmovaps xmm4, [rsp+0x40]
000074fc937e00b6  vmovaps xmm5, [rsp+0x50]
000074fc937e00bc  vmovaps xmm6, [rsp+0x60]
000074fc937e00c2  vmovaps xmm7, [rsp+0x70]
000074fc937e00c8  vmovaps xmm9, [rsp+0x80]
000074fc937e00d1  vmovaps xmm10, [rsp+0x90]
000074fc937e00da  vmovaps xmm11, [rsp+0xA0]
000074fc937e00e3  vmovaps xmm12, [rsp+0xB0]
000074fc937e00ec  vmovaps xmm13, [rsp+0xC0]
000074fc937e00f5  vmovaps xmm14, [rsp+0xD0]
000074fc937e00fe  vmovaps xmm15, [rsp+0xE0]
000074fc937e0107  add rsp, 0xF0
000074fc937e010e  pop r11
000074fc937e0110  pop r10
000074fc937e0112  pop r9
000074fc937e0114  pop r8
000074fc937e0116  pop rsi
000074fc937e0117  pop rdi
000074fc937e0118  pop rdx
000074fc937e0119  pop rcx
000074fc937e011a  pop rax
000074fc937e011b  add rsp, 0x08
000074fc937e011f  jmp 0x000074FC937DC561
000074fc937e0124  sub rsp, 0x08
000074fc937e0128  push rax
000074fc937e0129  push rcx
000074fc937e012a  push rdx
000074fc937e012b  push rdi
000074fc937e012c  push rsi
000074fc937e012d  push r8
000074fc937e012f  push r9
000074fc937e0131  push r10
000074fc937e0133  push r11
000074fc937e0135  sub rsp, 0xF0
000074fc937e013c  vmovaps [rsp], xmm0
000074fc937e0141  vmovaps [rsp+0x10], xmm1
000074fc937e0147  vmovaps [rsp+0x20], xmm2
000074fc937e014d  vmovaps [rsp+0x30], xmm3
000074fc937e0153  vmovaps [rsp+0x40], xmm4
000074fc937e0159  vmovaps [rsp+0x50], xmm5
000074fc937e015f  vmovaps [rsp+0x60], xmm7
000074fc937e0165  vmovaps [rsp+0x70], xmm8
000074fc937e016b  vmovaps [rsp+0x80], xmm9
000074fc937e0174  vmovaps [rsp+0x90], xmm10
000074fc937e017d  vmovaps [rsp+0xA0], xmm11
000074fc937e0186  vmovaps [rsp+0xB0], xmm12
000074fc937e018f  vmovaps [rsp+0xC0], xmm13
000074fc937e0198  vmovaps [rsp+0xD0], xmm14
000074fc937e01a1  vmovaps [rsp+0xE0], xmm15
000074fc937e01aa  sub rsp, 0x30
000074fc937e01ae  movaps [rsp], xmm6
000074fc937e01b2  movaps [rsp+0x10], xmm1
000074fc937e01b7  movaps [rsp+0x20], xmm14
000074fc937e01bd  lea rdi, [rsp]
000074fc937e01c1  mov esi, 0x00
000074fc937e01c6  mov rax, 0x5D72CBC20530
000074fc937e01d0  call rax
000074fc937e01d2  movaps xmm6, [rsp]
000074fc937e01d6  add rsp, 0x30
000074fc937e01da  vmovaps xmm0, [rsp]
000074fc937e01df  vmovaps xmm1, [rsp+0x10]
000074fc937e01e5  vmovaps xmm2, [rsp+0x20]
000074fc937e01eb  vmovaps xmm3, [rsp+0x30]
000074fc937e01f1  vmovaps xmm4, [rsp+0x40]
000074fc937e01f7  vmovaps xmm5, [rsp+0x50]
000074fc937e01fd  vmovaps xmm7, [rsp+0x60]
000074fc937e0203  vmovaps xmm8, [rsp+0x70]
000074fc937e0209  vmovaps xmm9, [rsp+0x80]
000074fc937e0212  vmovaps xmm10, [rsp+0x90]
000074fc937e021b  vmovaps xmm11, [rsp+0xA0]
000074fc937e0224  vmovaps xmm12, [rsp+0xB0]
000074fc937e022d  vmovaps xmm13, [rsp+0xC0]
000074fc937e0236  vmovaps xmm14, [rsp+0xD0]
000074fc937e023f  vmovaps xmm15, [rsp+0xE0]
000074fc937e0248  add rsp, 0xF0
000074fc937e024f  pop r11
000074fc937e0251  pop r10
000074fc937e0253  pop r9
000074fc937e0255  pop r8
000074fc937e0257  pop rsi
000074fc937e0258  pop rdi
000074fc937e0259  pop rdx
000074fc937e025a  pop rcx
000074fc937e025b  pop rax
000074fc937e025c  add rsp, 0x08
000074fc937e0260  jmp 0x000074FC937DC58D
000074fc937e0265  sub rsp, 0x08
000074fc937e0269  push rax
000074fc937e026a  push rcx
000074fc937e026b  push rdx
000074fc937e026c  push rdi
000074fc937e026d  push rsi
000074fc937e026e  push r8
000074fc937e0270  push r9
000074fc937e0272  push r10
000074fc937e0274  push r11
000074fc937e0276  sub rsp, 0xF0
000074fc937e027d  vmovaps [rsp], xmm0
000074fc937e0282  vmovaps [rsp+0x10], xmm1
000074fc937e0288  vmovaps [rsp+0x20], xmm2
000074fc937e028e  vmovaps [rsp+0x30], xmm3
000074fc937e0294  vmovaps [rsp+0x40], xmm4
000074fc937e029a  vmovaps [rsp+0x50], xmm5
000074fc937e02a0  vmovaps [rsp+0x60], xmm6
000074fc937e02a6  vmovaps [rsp+0x70], xmm7
000074fc937e02ac  vmovaps [rsp+0x80], xmm8
000074fc937e02b5  vmovaps [rsp+0x90], xmm9
000074fc937e02be  vmovaps [rsp+0xA0], xmm10
000074fc937e02c7  vmovaps [rsp+0xB0], xmm11
000074fc937e02d0  vmovaps [rsp+0xC0], xmm12
000074fc937e02d9  vmovaps [rsp+0xD0], xmm13
000074fc937e02e2  vmovaps [rsp+0xE0], xmm15
000074fc937e02eb  sub rsp, 0x30
000074fc937e02ef  movaps [rsp], xmm14
000074fc937e02f4  movaps [rsp+0x10], xmm12
000074fc937e02fa  movaps [rsp+0x20], xmm1
000074fc937e02ff  lea rdi, [rsp]
000074fc937e0303  mov esi, 0x00
000074fc937e0308  mov rax, 0x5D72CBC20530
000074fc937e0312  call rax
000074fc937e0314  movaps xmm14, [rsp]
000074fc937e0319  add rsp, 0x30
000074fc937e031d  vmovaps xmm0, [rsp]
000074fc937e0322  vmovaps xmm1, [rsp+0x10]
000074fc937e0328  vmovaps xmm2, [rsp+0x20]
000074fc937e032e  vmovaps xmm3, [rsp+0x30]
000074fc937e0334  vmovaps xmm4, [rsp+0x40]
000074fc937e033a  vmovaps xmm5, [rsp+0x50]
000074fc937e0340  vmovaps xmm6, [rsp+0x60]
000074fc937e0346  vmovaps xmm7, [rsp+0x70]
000074fc937e034c  vmovaps xmm8, [rsp+0x80]
000074fc937e0355  vmovaps xmm9, [rsp+0x90]
000074fc937e035e  vmovaps xmm10, [rsp+0xA0]
000074fc937e0367  vmovaps xmm11, [rsp+0xB0]
000074fc937e0370  vmovaps xmm12, [rsp+0xC0]
000074fc937e0379  vmovaps xmm13, [rsp+0xD0]
000074fc937e0382  vmovaps xmm15, [rsp+0xE0]
000074fc937e038b  add rsp, 0xF0
000074fc937e0392  pop r11
000074fc937e0394  pop r10
000074fc937e0396  pop r9
000074fc937e0398  pop r8
000074fc937e039a  pop rsi
000074fc937e039b  pop rdi
000074fc937e039c  pop rdx
000074fc937e039d  pop rcx
000074fc937e039e  pop rax
000074fc937e039f  add rsp, 0x08
000074fc937e03a3  jmp 0x000074FC937DC5B3
000074fc937e03a8  sub rsp, 0x08
000074fc937e03ac  push rax
000074fc937e03ad  push rcx
000074fc937e03ae  push rdx
000074fc937e03af  push rdi
000074fc937e03b0  push rsi
000074fc937e03b1  push r8
000074fc937e03b3  push r9
000074fc937e03b5  push r10
000074fc937e03b7  push r11
000074fc937e03b9  sub rsp, 0xF0
000074fc937e03c0  vmovaps [rsp], xmm0
000074fc937e03c5  vmovaps [rsp+0x10], xmm2
000074fc937e03cb  vmovaps [rsp+0x20], xmm3
000074fc937e03d1  vmovaps [rsp+0x30], xmm4
000074fc937e03d7  vmovaps [rsp+0x40], xmm5
000074fc937e03dd  vmovaps [rsp+0x50], xmm6
000074fc937e03e3  vmovaps [rsp+0x60], xmm7
000074fc937e03e9  vmovaps [rsp+0x70], xmm8
000074fc937e03ef  vmovaps [rsp+0x80], xmm9
000074fc937e03f8  vmovaps [rsp+0x90], xmm10
000074fc937e0401  vmovaps [rsp+0xA0], xmm11
000074fc937e040a  vmovaps [rsp+0xB0], xmm12
000074fc937e0413  vmovaps [rsp+0xC0], xmm13
000074fc937e041c  vmovaps [rsp+0xD0], xmm14
000074fc937e0425  vmovaps [rsp+0xE0], xmm15
000074fc937e042e  sub rsp, 0x30
000074fc937e0432  movaps [rsp], xmm1
000074fc937e0436  movaps [rsp+0x10], xmm13
000074fc937e043c  movaps [rsp+0x20], xmm9
000074fc937e0442  lea rdi, [rsp]
000074fc937e0446  mov esi, 0x00
000074fc937e044b  mov rax, 0x5D72CBC20530
000074fc937e0455  call rax
000074fc937e0457  movaps xmm1, [rsp]
000074fc937e045b  add rsp, 0x30
000074fc937e045f  vmovaps xmm0, [rsp]
000074fc937e0464  vmovaps xmm2, [rsp+0x10]
000074fc937e046a  vmovaps xmm3, [rsp+0x20]
000074fc937e0470  vmovaps xmm4, [rsp+0x30]
000074fc937e0476  vmovaps xmm5, [rsp+0x40]
000074fc937e047c  vmovaps xmm6, [rsp+0x50]
000074fc937e0482  vmovaps xmm7, [rsp+0x60]
000074fc937e0488  vmovaps xmm8, [rsp+0x70]
000074fc937e048e  vmovaps xmm9, [rsp+0x80]
000074fc937e0497  vmovaps xmm10, [rsp+0x90]
000074fc937e04a0  vmovaps xmm11, [rsp+0xA0]
000074fc937e04a9  vmovaps xmm12, [rsp+0xB0]
000074fc937e04b2  vmovaps xmm13, [rsp+0xC0]
000074fc937e04bb  vmovaps xmm14, [rsp+0xD0]
000074fc937e04c4  vmovaps xmm15, [rsp+0xE0]
000074fc937e04cd  add rsp, 0xF0
000074fc937e04d4  pop r11
000074fc937e04d6  pop r10
000074fc937e04d8  pop r9
000074fc937e04da  pop r8
000074fc937e04dc  pop rsi
000074fc937e04dd  pop rdi
000074fc937e04de  pop rdx
000074fc937e04df  pop rcx
000074fc937e04e0  pop rax
000074fc937e04e1  add rsp, 0x08
000074fc937e04e5  jmp 0x000074FC937DC5CD
000074fc937e04ea  sub rsp, 0x08
000074fc937e04ee  push rax
000074fc937e04ef  push rcx
000074fc937e04f0  push rdx
000074fc937e04f1  push rdi
000074fc937e04f2  push rsi
000074fc937e04f3  push r8
000074fc937e04f5  push r9
000074fc937e04f7  push r10
000074fc937e04f9  push r11
000074fc937e04fb  sub rsp, 0xF0
000074fc937e0502  vmovaps [rsp], xmm0
000074fc937e0507  vmovaps [rsp+0x10], xmm1
000074fc937e050d  vmovaps [rsp+0x20], xmm2
000074fc937e0513  vmovaps [rsp+0x30], xmm3
000074fc937e0519  vmovaps [rsp+0x40], xmm4
000074fc937e051f  vmovaps [rsp+0x50], xmm5
000074fc937e0525  vmovaps [rsp+0x60], xmm6
000074fc937e052b  vmovaps [rsp+0x70], xmm7
000074fc937e0531  vmovaps [rsp+0x80], xmm8
000074fc937e053a  vmovaps [rsp+0x90], xmm9
000074fc937e0543  vmovaps [rsp+0xA0], xmm10
000074fc937e054c  vmovaps [rsp+0xB0], xmm11
000074fc937e0555  vmovaps [rsp+0xC0], xmm13
000074fc937e055e  vmovaps [rsp+0xD0], xmm14
000074fc937e0567  vmovaps [rsp+0xE0], xmm15
000074fc937e0570  sub rsp, 0x30
000074fc937e0574  movaps [rsp], xmm12
000074fc937e0579  movaps [rsp+0x10], xmm7
000074fc937e057e  movaps [rsp+0x20], xmm13
000074fc937e0584  lea rdi, [rsp]
000074fc937e0588  mov esi, 0x00
000074fc937e058d  mov rax, 0x5D72CBC20530
000074fc937e0597  call rax
000074fc937e0599  movaps xmm12, [rsp]
000074fc937e059e  add rsp, 0x30
000074fc937e05a2  vmovaps xmm0, [rsp]
000074fc937e05a7  vmovaps xmm1, [rsp+0x10]
000074fc937e05ad  vmovaps xmm2, [rsp+0x20]
000074fc937e05b3  vmovaps xmm3, [rsp+0x30]
000074fc937e05b9  vmovaps xmm4, [rsp+0x40]
000074fc937e05bf  vmovaps xmm5, [rsp+0x50]
000074fc937e05c5  vmovaps xmm6, [rsp+0x60]
000074fc937e05cb  vmovaps xmm7, [rsp+0x70]
000074fc937e05d1  vmovaps xmm8, [rsp+0x80]
000074fc937e05da  vmovaps xmm9, [rsp+0x90]
000074fc937e05e3  vmovaps xmm10, [rsp+0xA0]
000074fc937e05ec  vmovaps xmm11, [rsp+0xB0]
000074fc937e05f5  vmovaps xmm13, [rsp+0xC0]
000074fc937e05fe  vmovaps xmm14, [rsp+0xD0]
000074fc937e0607  vmovaps xmm15, [rsp+0xE0]
000074fc937e0610  add rsp, 0xF0
000074fc937e0617  pop r11
000074fc937e0619  pop r10
000074fc937e061b  pop r9
000074fc937e061d  pop r8
000074fc937e061f  pop rsi
000074fc937e0620  pop rdi
000074fc937e0621  pop rdx
000074fc937e0622  pop rcx
000074fc937e0623  pop rax
000074fc937e0624  add rsp, 0x08
000074fc937e0628  jmp 0x000074FC937DC5F4
000074fc937e062d  sub rsp, 0x08
000074fc937e0631  push rax
000074fc937e0632  push rcx
000074fc937e0633  push rdx
000074fc937e0634  push rdi
000074fc937e0635  push rsi
000074fc937e0636  push r8
000074fc937e0638  push r9
000074fc937e063a  push r10
000074fc937e063c  push r11
000074fc937e063e  sub rsp, 0xF0
000074fc937e0645  vmovaps [rsp], xmm0
000074fc937e064a  vmovaps [rsp+0x10], xmm1
000074fc937e0650  vmovaps [rsp+0x20], xmm2
000074fc937e0656  vmovaps [rsp+0x30], xmm3
000074fc937e065c  vmovaps [rsp+0x40], xmm4
000074fc937e0662  vmovaps [rsp+0x50], xmm5
000074fc937e0668  vmovaps [rsp+0x60], xmm6
000074fc937e066e  vmovaps [rsp+0x70], xmm7
000074fc937e0674  vmovaps [rsp+0x80], xmm8
000074fc937e067d  vmovaps [rsp+0x90], xmm9
000074fc937e0686  vmovaps [rsp+0xA0], xmm10
000074fc937e068f  vmovaps [rsp+0xB0], xmm11
000074fc937e0698  vmovaps [rsp+0xC0], xmm12
000074fc937e06a1  vmovaps [rsp+0xD0], xmm14
000074fc937e06aa  vmovaps [rsp+0xE0], xmm15
000074fc937e06b3  sub rsp, 0x30
000074fc937e06b7  movaps [rsp], xmm13
000074fc937e06bc  movaps [rsp+0x10], xmm15
000074fc937e06c2  movaps [rsp+0x20], xmm8
000074fc937e06c8  lea rdi, [rsp]
000074fc937e06cc  mov esi, 0x00
000074fc937e06d1  mov rax, 0x5D72CBC20530
000074fc937e06db  call rax
000074fc937e06dd  movaps xmm13, [rsp]
000074fc937e06e2  add rsp, 0x30
000074fc937e06e6  vmovaps xmm0, [rsp]
000074fc937e06eb  vmovaps xmm1, [rsp+0x10]
000074fc937e06f1  vmovaps xmm2, [rsp+0x20]
000074fc937e06f7  vmovaps xmm3, [rsp+0x30]
000074fc937e06fd  vmovaps xmm4, [rsp+0x40]
000074fc937e0703  vmovaps xmm5, [rsp+0x50]
000074fc937e0709  vmovaps xmm6, [rsp+0x60]
000074fc937e070f  vmovaps xmm7, [rsp+0x70]
000074fc937e0715  vmovaps xmm8, [rsp+0x80]
000074fc937e071e  vmovaps xmm9, [rsp+0x90]
000074fc937e0727  vmovaps xmm10, [rsp+0xA0]
000074fc937e0730  vmovaps xmm11, [rsp+0xB0]
000074fc937e0739  vmovaps xmm12, [rsp+0xC0]
000074fc937e0742  vmovaps xmm14, [rsp+0xD0]
000074fc937e074b  vmovaps xmm15, [rsp+0xE0]
000074fc937e0754  add rsp, 0xF0
000074fc937e075b  pop r11
000074fc937e075d  pop r10
000074fc937e075f  pop r9
000074fc937e0761  pop r8
000074fc937e0763  pop rsi
000074fc937e0764  pop rdi
000074fc937e0765  pop rdx
000074fc937e0766  pop rcx
000074fc937e0767  pop rax
000074fc937e0768  add rsp, 0x08
000074fc937e076c  jmp 0x000074FC937DC60F
000074fc937e0771  sub rsp, 0x08
000074fc937e0775  push rax
000074fc937e0776  push rcx
000074fc937e0777  push rdx
000074fc937e0778  push rdi
000074fc937e0779  push rsi
000074fc937e077a  push r8
000074fc937e077c  push r9
000074fc937e077e  push r10
000074fc937e0780  push r11
000074fc937e0782  sub rsp, 0xF0
000074fc937e0789  vmovaps [rsp], xmm0
000074fc937e078e  vmovaps [rsp+0x10], xmm1
000074fc937e0794  vmovaps [rsp+0x20], xmm2
000074fc937e079a  vmovaps [rsp+0x30], xmm3
000074fc937e07a0  vmovaps [rsp+0x40], xmm4
000074fc937e07a6  vmovaps [rsp+0x50], xmm5
000074fc937e07ac  vmovaps [rsp+0x60], xmm6
000074fc937e07b2  vmovaps [rsp+0x70], xmm7
000074fc937e07b8  vmovaps [rsp+0x80], xmm9
000074fc937e07c1  vmovaps [rsp+0x90], xmm10
000074fc937e07ca  vmovaps [rsp+0xA0], xmm11
000074fc937e07d3  vmovaps [rsp+0xB0], xmm12
000074fc937e07dc  vmovaps [rsp+0xC0], xmm13
000074fc937e07e5  vmovaps [rsp+0xD0], xmm14
000074fc937e07ee  vmovaps [rsp+0xE0], xmm15
000074fc937e07f7  sub rsp, 0x30
000074fc937e07fb  movaps [rsp], xmm8
000074fc937e0800  movaps [rsp+0x10], xmm15
000074fc937e0806  movaps [rsp+0x20], xmm9
000074fc937e080c  lea rdi, [rsp]
000074fc937e0810  mov esi, 0x00
000074fc937e0815  mov rax, 0x5D72CBC20530
000074fc937e081f  call rax
000074fc937e0821  movaps xmm8, [rsp]
000074fc937e0826  add rsp, 0x30
000074fc937e082a  vmovaps xmm0, [rsp]
000074fc937e082f  vmovaps xmm1, [rsp+0x10]
000074fc937e0835  vmovaps xmm2, [rsp+0x20]
000074fc937e083b  vmovaps xmm3, [rsp+0x30]
000074fc937e0841  vmovaps xmm4, [rsp+0x40]
000074fc937e0847  vmovaps xmm5, [rsp+0x50]
000074fc937e084d  vmovaps xmm6, [rsp+0x60]
000074fc937e0853  vmovaps xmm7, [rsp+0x70]
000074fc937e0859  vmovaps xmm9, [rsp+0x80]
000074fc937e0862  vmovaps xmm10, [rsp+0x90]
000074fc937e086b  vmovaps xmm11, [rsp+0xA0]
000074fc937e0874  vmovaps xmm12, [rsp+0xB0]
000074fc937e087d  vmovaps xmm13, [rsp+0xC0]
000074fc937e0886  vmovaps xmm14, [rsp+0xD0]
000074fc937e088f  vmovaps xmm15, [rsp+0xE0]
000074fc937e0898  add rsp, 0xF0
000074fc937e089f  pop r11
000074fc937e08a1  pop r10
000074fc937e08a3  pop r9
000074fc937e08a5  pop r8
000074fc937e08a7  pop rsi
000074fc937e08a8  pop rdi
000074fc937e08a9  pop rdx
000074fc937e08aa  pop rcx
000074fc937e08ab  pop rax
000074fc937e08ac  add rsp, 0x08
000074fc937e08b0  jmp 0x000074FC937DC63D
000074fc937e08b5  sub rsp, 0x08
000074fc937e08b9  push rax
000074fc937e08ba  push rcx
000074fc937e08bb  push rdx
000074fc937e08bc  push rdi
000074fc937e08bd  push rsi
000074fc937e08be  push r8
000074fc937e08c0  push r9
000074fc937e08c2  push r10
000074fc937e08c4  push r11
000074fc937e08c6  sub rsp, 0xF0
000074fc937e08cd  vmovaps [rsp], xmm0
000074fc937e08d2  vmovaps [rsp+0x10], xmm1
000074fc937e08d8  vmovaps [rsp+0x20], xmm2
000074fc937e08de  vmovaps [rsp+0x30], xmm3
000074fc937e08e4  vmovaps [rsp+0x40], xmm4
000074fc937e08ea  vmovaps [rsp+0x50], xmm5
000074fc937e08f0  vmovaps [rsp+0x60], xmm6
000074fc937e08f6  vmovaps [rsp+0x70], xmm7
000074fc937e08fc  vmovaps [rsp+0x80], xmm8
000074fc937e0905  vmovaps [rsp+0x90], xmm9
000074fc937e090e  vmovaps [rsp+0xA0], xmm10
000074fc937e0917  vmovaps [rsp+0xB0], xmm11
000074fc937e0920  vmovaps [rsp+0xC0], xmm12
000074fc937e0929  vmovaps [rsp+0xD0], xmm13
000074fc937e0932  vmovaps [rsp+0xE0], xmm14
000074fc937e093b  sub rsp, 0x30
000074fc937e093f  movaps [rsp], xmm15
000074fc937e0944  movaps [rsp+0x10], xmm11
000074fc937e094a  movaps [rsp+0x20], xmm6
000074fc937e094f  lea rdi, [rsp]
000074fc937e0953  mov esi, 0x00
000074fc937e0958  mov rax, 0x5D72CBC20530
000074fc937e0962  call rax
000074fc937e0964  movaps xmm15, [rsp]
000074fc937e0969  add rsp, 0x30
000074fc937e096d  vmovaps xmm0, [rsp]
000074fc937e0972  vmovaps xmm1, [rsp+0x10]
000074fc937e0978  vmovaps xmm2, [rsp+0x20]
000074fc937e097e  vmovaps xmm3, [rsp+0x30]
000074fc937e0984  vmovaps xmm4, [rsp+0x40]
000074fc937e098a  vmovaps xmm5, [rsp+0x50]
000074fc937e0990  vmovaps xmm6, [rsp+0x60]
000074fc937e0996  vmovaps xmm7, [rsp+0x70]
000074fc937e099c  vmovaps xmm8, [rsp+0x80]
000074fc937e09a5  vmovaps xmm9, [rsp+0x90]
000074fc937e09ae  vmovaps xmm10, [rsp+0xA0]
000074fc937e09b7  vmovaps xmm11, [rsp+0xB0]
000074fc937e09c0  vmovaps xmm12, [rsp+0xC0]
000074fc937e09c9  vmovaps xmm13, [rsp+0xD0]
000074fc937e09d2  vmovaps xmm14, [rsp+0xE0]
000074fc937e09db  add rsp, 0xF0
000074fc937e09e2  pop r11
000074fc937e09e4  pop r10
000074fc937e09e6  pop r9
000074fc937e09e8  pop r8
000074fc937e09ea  pop rsi
000074fc937e09eb  pop rdi
000074fc937e09ec  pop rdx
000074fc937e09ed  pop rcx
000074fc937e09ee  pop rax
000074fc937e09ef  add rsp, 0x08
000074fc937e09f3  jmp 0x000074FC937DC658
000074fc937e09f8  sub rsp, 0x08
000074fc937e09fc  push rax
000074fc937e09fd  push rcx
000074fc937e09fe  push rdx
000074fc937e09ff  push rdi
000074fc937e0a00  push rsi
000074fc937e0a01  push r8
000074fc937e0a03  push r9
000074fc937e0a05  push r10
000074fc937e0a07  push r11
000074fc937e0a09  sub rsp, 0xF0
000074fc937e0a10  vmovaps [rsp], xmm0
000074fc937e0a15  vmovaps [rsp+0x10], xmm1
000074fc937e0a1b  vmovaps [rsp+0x20], xmm2
000074fc937e0a21  vmovaps [rsp+0x30], xmm3
000074fc937e0a27  vmovaps [rsp+0x40], xmm4
000074fc937e0a2d  vmovaps [rsp+0x50], xmm5
000074fc937e0a33  vmovaps [rsp+0x60], xmm6
000074fc937e0a39  vmovaps [rsp+0x70], xmm8
000074fc937e0a3f  vmovaps [rsp+0x80], xmm9
000074fc937e0a48  vmovaps [rsp+0x90], xmm10
000074fc937e0a51  vmovaps [rsp+0xA0], xmm11
000074fc937e0a5a  vmovaps [rsp+0xB0], xmm12
000074fc937e0a63  vmovaps [rsp+0xC0], xmm13
000074fc937e0a6c  vmovaps [rsp+0xD0], xmm14
000074fc937e0a75  vmovaps [rsp+0xE0], xmm15
000074fc937e0a7e  sub rsp, 0x30
000074fc937e0a82  movaps [rsp], xmm7
000074fc937e0a86  movaps [rsp+0x10], xmm11
000074fc937e0a8c  movaps [rsp+0x20], xmm9
000074fc937e0a92  lea rdi, [rsp]
000074fc937e0a96  mov esi, 0x00
000074fc937e0a9b  mov rax, 0x5D72CBC20530
000074fc937e0aa5  call rax
000074fc937e0aa7  movaps xmm7, [rsp]
000074fc937e0aab  add rsp, 0x30
000074fc937e0aaf  vmovaps xmm0, [rsp]
000074fc937e0ab4  vmovaps xmm1, [rsp+0x10]
000074fc937e0aba  vmovaps xmm2, [rsp+0x20]
000074fc937e0ac0  vmovaps xmm3, [rsp+0x30]
000074fc937e0ac6  vmovaps xmm4, [rsp+0x40]
000074fc937e0acc  vmovaps xmm5, [rsp+0x50]
000074fc937e0ad2  vmovaps xmm6, [rsp+0x60]
000074fc937e0ad8  vmovaps xmm8, [rsp+0x70]
000074fc937e0ade  vmovaps xmm9, [rsp+0x80]
000074fc937e0ae7  vmovaps xmm10, [rsp+0x90]
000074fc937e0af0  vmovaps xmm11, [rsp+0xA0]
000074fc937e0af9  vmovaps xmm12, [rsp+0xB0]
000074fc937e0b02  vmovaps xmm13, [rsp+0xC0]
000074fc937e0b0b  vmovaps xmm14, [rsp+0xD0]
000074fc937e0b14  vmovaps xmm15, [rsp+0xE0]
000074fc937e0b1d  add rsp, 0xF0
000074fc937e0b24  pop r11
000074fc937e0b26  pop r10
000074fc937e0b28  pop r9
000074fc937e0b2a  pop r8
000074fc937e0b2c  pop rsi
000074fc937e0b2d  pop rdi
000074fc937e0b2e  pop rdx
000074fc937e0b2f  pop rcx
000074fc937e0b30  pop rax
000074fc937e0b31  add rsp, 0x08
000074fc937e0b35  jmp 0x000074FC937DC685
000074fc937e0b3a  sub rsp, 0x08
000074fc937e0b3e  push rax
000074fc937e0b3f  push rcx
000074fc937e0b40  push rdx
000074fc937e0b41  push rdi
000074fc937e0b42  push rsi
000074fc937e0b43  push r8
000074fc937e0b45  push r9
000074fc937e0b47  push r10
000074fc937e0b49  push r11
000074fc937e0b4b  sub rsp, 0xF0
000074fc937e0b52  vmovaps [rsp], xmm0
000074fc937e0b57  vmovaps [rsp+0x10], xmm1
000074fc937e0b5d  vmovaps [rsp+0x20], xmm2
000074fc937e0b63  vmovaps [rsp+0x30], xmm3
000074fc937e0b69  vmovaps [rsp+0x40], xmm4
000074fc937e0b6f  vmovaps [rsp+0x50], xmm5
000074fc937e0b75  vmovaps [rsp+0x60], xmm6
000074fc937e0b7b  vmovaps [rsp+0x70], xmm7
000074fc937e0b81  vmovaps [rsp+0x80], xmm8
000074fc937e0b8a  vmovaps [rsp+0x90], xmm9
000074fc937e0b93  vmovaps [rsp+0xA0], xmm10
000074fc937e0b9c  vmovaps [rsp+0xB0], xmm12
000074fc937e0ba5  vmovaps [rsp+0xC0], xmm13
000074fc937e0bae  vmovaps [rsp+0xD0], xmm14
000074fc937e0bb7  vmovaps [rsp+0xE0], xmm15
000074fc937e0bc0  sub rsp, 0x30
000074fc937e0bc4  movaps [rsp], xmm11
000074fc937e0bc9  movaps [rsp+0x10], xmm10
000074fc937e0bcf  movaps [rsp+0x20], xmm14
000074fc937e0bd5  lea rdi, [rsp]
000074fc937e0bd9  mov esi, 0x00
000074fc937e0bde  mov rax, 0x5D72CBC20530
000074fc937e0be8  call rax
000074fc937e0bea  movaps xmm11, [rsp]
000074fc937e0bef  add rsp, 0x30
000074fc937e0bf3  vmovaps xmm0, [rsp]
000074fc937e0bf8  vmovaps xmm1, [rsp+0x10]
000074fc937e0bfe  vmovaps xmm2, [rsp+0x20]
000074fc937e0c04  vmovaps xmm3, [rsp+0x30]
000074fc937e0c0a  vmovaps xmm4, [rsp+0x40]
000074fc937e0c10  vmovaps xmm5, [rsp+0x50]
000074fc937e0c16  vmovaps xmm6, [rsp+0x60]
000074fc937e0c1c  vmovaps xmm7, [rsp+0x70]
000074fc937e0c22  vmovaps xmm8, [rsp+0x80]
000074fc937e0c2b  vmovaps xmm9, [rsp+0x90]
000074fc937e0c34  vmovaps xmm10, [rsp+0xA0]
000074fc937e0c3d  vmovaps xmm12, [rsp+0xB0]
000074fc937e0c46  vmovaps xmm13, [rsp+0xC0]
000074fc937e0c4f  vmovaps xmm14, [rsp+0xD0]
000074fc937e0c58  vmovaps xmm15, [rsp+0xE0]
000074fc937e0c61  add rsp, 0xF0
000074fc937e0c68  pop r11
000074fc937e0c6a  pop r10
000074fc937e0c6c  pop r9
000074fc937e0c6e  pop r8
000074fc937e0c70  pop rsi
000074fc937e0c71  pop rdi
000074fc937e0c72  pop rdx
000074fc937e0c73  pop rcx
000074fc937e0c74  pop rax
000074fc937e0c75  add rsp, 0x08
000074fc937e0c79  jmp 0x000074FC937DC6A0
000074fc937e0c7e  call 0x000074FC936C33A0
000074fc937e0c83  jmp 0x000074FC937DC6AA
000074fc937e0c88  sub rsp, 0x08
000074fc937e0c8c  push rax
000074fc937e0c8d  push rcx
000074fc937e0c8e  push rdx
000074fc937e0c8f  push rdi
000074fc937e0c90  push rsi
000074fc937e0c91  push r8
000074fc937e0c93  push r9
000074fc937e0c95  push r10
000074fc937e0c97  push r11
000074fc937e0c99  sub rsp, 0xF0
000074fc937e0ca0  vmovaps [rsp], xmm0
000074fc937e0ca5  vmovaps [rsp+0x10], xmm1
000074fc937e0cab  vmovaps [rsp+0x20], xmm2
000074fc937e0cb1  vmovaps [rsp+0x30], xmm3
000074fc937e0cb7  vmovaps [rsp+0x40], xmm4
000074fc937e0cbd  vmovaps [rsp+0x50], xmm5
000074fc937e0cc3  vmovaps [rsp+0x60], xmm6
000074fc937e0cc9  vmovaps [rsp+0x70], xmm7
000074fc937e0ccf  vmovaps [rsp+0x80], xmm8
000074fc937e0cd8  vmovaps [rsp+0x90], xmm9
000074fc937e0ce1  vmovaps [rsp+0xA0], xmm11
000074fc937e0cea  vmovaps [rsp+0xB0], xmm12
000074fc937e0cf3  vmovaps [rsp+0xC0], xmm13
000074fc937e0cfc  vmovaps [rsp+0xD0], xmm14
000074fc937e0d05  vmovaps [rsp+0xE0], xmm15
000074fc937e0d0e  sub rsp, 0x30
000074fc937e0d12  movaps [rsp], xmm10
000074fc937e0d17  movaps [rsp+0x10], xmm1
000074fc937e0d1c  movaps [rsp+0x20], xmm12
000074fc937e0d22  lea rdi, [rsp]
000074fc937e0d26  mov esi, 0x00
000074fc937e0d2b  mov rax, 0x5D72CBC20530
000074fc937e0d35  call rax
000074fc937e0d37  movaps xmm10, [rsp]
000074fc937e0d3c  add rsp, 0x30
000074fc937e0d40  vmovaps xmm0, [rsp]
000074fc937e0d45  vmovaps xmm1, [rsp+0x10]
000074fc937e0d4b  vmovaps xmm2, [rsp+0x20]
000074fc937e0d51  vmovaps xmm3, [rsp+0x30]
000074fc937e0d57  vmovaps xmm4, [rsp+0x40]
000074fc937e0d5d  vmovaps xmm5, [rsp+0x50]
000074fc937e0d63  vmovaps xmm6, [rsp+0x60]
000074fc937e0d69  vmovaps xmm7, [rsp+0x70]
000074fc937e0d6f  vmovaps xmm8, [rsp+0x80]
000074fc937e0d78  vmovaps xmm9, [rsp+0x90]
000074fc937e0d81  vmovaps xmm11, [rsp+0xA0]
000074fc937e0d8a  vmovaps xmm12, [rsp+0xB0]
000074fc937e0d93  vmovaps xmm13, [rsp+0xC0]
000074fc937e0d9c  vmovaps xmm14, [rsp+0xD0]
000074fc937e0da5  vmovaps xmm15, [rsp+0xE0]
000074fc937e0dae  add rsp, 0xF0
000074fc937e0db5  pop r11
000074fc937e0db7  pop r10
000074fc937e0db9  pop r9
000074fc937e0dbb  pop r8
000074fc937e0dbd  pop rsi
000074fc937e0dbe  pop rdi
000074fc937e0dbf  pop rdx
000074fc937e0dc0  pop rcx
000074fc937e0dc1  pop rax
000074fc937e0dc2  add rsp, 0x08
000074fc937e0dc6  jmp 0x000074FC937DC6CD
000074fc937e0dcb  sub rsp, 0x08
000074fc937e0dcf  push rax
000074fc937e0dd0  push rcx
000074fc937e0dd1  push rdx
000074fc937e0dd2  push rdi
000074fc937e0dd3  push rsi
000074fc937e0dd4  push r8
000074fc937e0dd6  push r9
000074fc937e0dd8  push r10
000074fc937e0dda  push r11
000074fc937e0ddc  sub rsp, 0xF0
000074fc937e0de3  vmovaps [rsp], xmm0
000074fc937e0de8  vmovaps [rsp+0x10], xmm1
000074fc937e0dee  vmovaps [rsp+0x20], xmm2
000074fc937e0df4  vmovaps [rsp+0x30], xmm3
000074fc937e0dfa  vmovaps [rsp+0x40], xmm4
000074fc937e0e00  vmovaps [rsp+0x50], xmm5
000074fc937e0e06  vmovaps [rsp+0x60], xmm6
000074fc937e0e0c  vmovaps [rsp+0x70], xmm7
000074fc937e0e12  vmovaps [rsp+0x80], xmm8
000074fc937e0e1b  vmovaps [rsp+0x90], xmm9
000074fc937e0e24  vmovaps [rsp+0xA0], xmm10
000074fc937e0e2d  vmovaps [rsp+0xB0], xmm11
000074fc937e0e36  vmovaps [rsp+0xC0], xmm13
000074fc937e0e3f  vmovaps [rsp+0xD0], xmm14
000074fc937e0e48  vmovaps [rsp+0xE0], xmm15
000074fc937e0e51  sub rsp, 0x30
000074fc937e0e55  movaps [rsp], xmm12
000074fc937e0e5a  movaps [rsp+0x10], xmm14
000074fc937e0e60  movaps [rsp+0x20], xmm1
000074fc937e0e65  lea rdi, [rsp]
000074fc937e0e69  mov esi, 0x00
000074fc937e0e6e  mov rax, 0x5D72CBC20530
000074fc937e0e78  call rax
000074fc937e0e7a  movaps xmm12, [rsp]
000074fc937e0e7f  add rsp, 0x30
000074fc937e0e83  vmovaps xmm0, [rsp]
000074fc937e0e88  vmovaps xmm1, [rsp+0x10]
000074fc937e0e8e  vmovaps xmm2, [rsp+0x20]
000074fc937e0e94  vmovaps xmm3, [rsp+0x30]
000074fc937e0e9a  vmovaps xmm4, [rsp+0x40]
000074fc937e0ea0  vmovaps xmm5, [rsp+0x50]
000074fc937e0ea6  vmovaps xmm6, [rsp+0x60]
000074fc937e0eac  vmovaps xmm7, [rsp+0x70]
000074fc937e0eb2  vmovaps xmm8, [rsp+0x80]
000074fc937e0ebb  vmovaps xmm9, [rsp+0x90]
000074fc937e0ec4  vmovaps xmm10, [rsp+0xA0]
000074fc937e0ecd  vmovaps xmm11, [rsp+0xB0]
000074fc937e0ed6  vmovaps xmm13, [rsp+0xC0]
000074fc937e0edf  vmovaps xmm14, [rsp+0xD0]
000074fc937e0ee8  vmovaps xmm15, [rsp+0xE0]
000074fc937e0ef1  add rsp, 0xF0
000074fc937e0ef8  pop r11
000074fc937e0efa  pop r10
000074fc937e0efc  pop r9
000074fc937e0efe  pop r8
000074fc937e0f00  pop rsi
000074fc937e0f01  pop rdi
000074fc937e0f02  pop rdx
000074fc937e0f03  pop rcx
000074fc937e0f04  pop rax
000074fc937e0f05  add rsp, 0x08
000074fc937e0f09  jmp 0x000074FC937DC6FC
000074fc937e0f0e  sub rsp, 0x08
000074fc937e0f12  push rax
000074fc937e0f13  push rcx
000074fc937e0f14  push rdx
000074fc937e0f15  push rdi
000074fc937e0f16  push rsi
000074fc937e0f17  push r8
000074fc937e0f19  push r9
000074fc937e0f1b  push r10
000074fc937e0f1d  push r11
000074fc937e0f1f  sub rsp, 0xF0
000074fc937e0f26  vmovaps [rsp], xmm0
000074fc937e0f2b  vmovaps [rsp+0x10], xmm1
000074fc937e0f31  vmovaps [rsp+0x20], xmm2
000074fc937e0f37  vmovaps [rsp+0x30], xmm3
000074fc937e0f3d  vmovaps [rsp+0x40], xmm4
000074fc937e0f43  vmovaps [rsp+0x50], xmm5
000074fc937e0f49  vmovaps [rsp+0x60], xmm6
000074fc937e0f4f  vmovaps [rsp+0x70], xmm7
000074fc937e0f55  vmovaps [rsp+0x80], xmm8
000074fc937e0f5e  vmovaps [rsp+0x90], xmm9
000074fc937e0f67  vmovaps [rsp+0xA0], xmm10
000074fc937e0f70  vmovaps [rsp+0xB0], xmm11
000074fc937e0f79  vmovaps [rsp+0xC0], xmm12
000074fc937e0f82  vmovaps [rsp+0xD0], xmm13
000074fc937e0f8b  vmovaps [rsp+0xE0], xmm15
000074fc937e0f94  sub rsp, 0x30
000074fc937e0f98  movaps [rsp], xmm14
000074fc937e0f9d  movaps [rsp+0x10], xmm9
000074fc937e0fa3  movaps [rsp+0x20], xmm1
000074fc937e0fa8  lea rdi, [rsp]
000074fc937e0fac  mov esi, 0x00
000074fc937e0fb1  mov rax, 0x5D72CBC20530
000074fc937e0fbb  call rax
000074fc937e0fbd  movaps xmm14, [rsp]
000074fc937e0fc2  add rsp, 0x30
000074fc937e0fc6  vmovaps xmm0, [rsp]
000074fc937e0fcb  vmovaps xmm1, [rsp+0x10]
000074fc937e0fd1  vmovaps xmm2, [rsp+0x20]
000074fc937e0fd7  vmovaps xmm3, [rsp+0x30]
000074fc937e0fdd  vmovaps xmm4, [rsp+0x40]
000074fc937e0fe3  vmovaps xmm5, [rsp+0x50]
000074fc937e0fe9  vmovaps xmm6, [rsp+0x60]
000074fc937e0fef  vmovaps xmm7, [rsp+0x70]
000074fc937e0ff5  vmovaps xmm8, [rsp+0x80]
000074fc937e0ffe  vmovaps xmm9, [rsp+0x90]
000074fc937e1007  vmovaps xmm10, [rsp+0xA0]
000074fc937e1010  vmovaps xmm11, [rsp+0xB0]
000074fc937e1019  vmovaps xmm12, [rsp+0xC0]
000074fc937e1022  vmovaps xmm13, [rsp+0xD0]
000074fc937e102b  vmovaps xmm15, [rsp+0xE0]
000074fc937e1034  add rsp, 0xF0
000074fc937e103b  pop r11
000074fc937e103d  pop r10
000074fc937e103f  pop r9
000074fc937e1041  pop r8
000074fc937e1043  pop rsi
000074fc937e1044  pop rdi
000074fc937e1045  pop rdx
000074fc937e1046  pop rcx
000074fc937e1047  pop rax
000074fc937e1048  add rsp, 0x08
000074fc937e104c  jmp 0x000074FC937DC72B
000074fc937e1051  sub rsp, 0x08
000074fc937e1055  push rax
000074fc937e1056  push rcx
000074fc937e1057  push rdx
000074fc937e1058  push rdi
000074fc937e1059  push rsi
000074fc937e105a  push r8
000074fc937e105c  push r9
000074fc937e105e  push r10
000074fc937e1060  push r11
000074fc937e1062  sub rsp, 0xF0
000074fc937e1069  vmovaps [rsp], xmm0
000074fc937e106e  vmovaps [rsp+0x10], xmm2
000074fc937e1074  vmovaps [rsp+0x20], xmm3
000074fc937e107a  vmovaps [rsp+0x30], xmm4
000074fc937e1080  vmovaps [rsp+0x40], xmm5
000074fc937e1086  vmovaps [rsp+0x50], xmm6
000074fc937e108c  vmovaps [rsp+0x60], xmm7
000074fc937e1092  vmovaps [rsp+0x70], xmm8
000074fc937e1098  vmovaps [rsp+0x80], xmm9
000074fc937e10a1  vmovaps [rsp+0x90], xmm10
000074fc937e10aa  vmovaps [rsp+0xA0], xmm11
000074fc937e10b3  vmovaps [rsp+0xB0], xmm12
000074fc937e10bc  vmovaps [rsp+0xC0], xmm13
000074fc937e10c5  vmovaps [rsp+0xD0], xmm14
000074fc937e10ce  vmovaps [rsp+0xE0], xmm15
000074fc937e10d7  sub rsp, 0x30
000074fc937e10db  movaps [rsp], xmm1
000074fc937e10df  movaps [rsp+0x10], xmm13
000074fc937e10e5  movaps [rsp+0x20], xmm8
000074fc937e10eb  lea rdi, [rsp]
000074fc937e10ef  mov esi, 0x00
000074fc937e10f4  mov rax, 0x5D72CBC20530
000074fc937e10fe  call rax
000074fc937e1100  movaps xmm1, [rsp]
000074fc937e1104  add rsp, 0x30
000074fc937e1108  vmovaps xmm0, [rsp]
000074fc937e110d  vmovaps xmm2, [rsp+0x10]
000074fc937e1113  vmovaps xmm3, [rsp+0x20]
000074fc937e1119  vmovaps xmm4, [rsp+0x30]
000074fc937e111f  vmovaps xmm5, [rsp+0x40]
000074fc937e1125  vmovaps xmm6, [rsp+0x50]
000074fc937e112b  vmovaps xmm7, [rsp+0x60]
000074fc937e1131  vmovaps xmm8, [rsp+0x70]
000074fc937e1137  vmovaps xmm9, [rsp+0x80]
000074fc937e1140  vmovaps xmm10, [rsp+0x90]
000074fc937e1149  vmovaps xmm11, [rsp+0xA0]
000074fc937e1152  vmovaps xmm12, [rsp+0xB0]
000074fc937e115b  vmovaps xmm13, [rsp+0xC0]
000074fc937e1164  vmovaps xmm14, [rsp+0xD0]
000074fc937e116d  vmovaps xmm15, [rsp+0xE0]
000074fc937e1176  add rsp, 0xF0
000074fc937e117d  pop r11
000074fc937e117f  pop r10
000074fc937e1181  pop r9
000074fc937e1183  pop r8
000074fc937e1185  pop rsi
000074fc937e1186  pop rdi
000074fc937e1187  pop rdx
000074fc937e1188  pop rcx
000074fc937e1189  pop rax
000074fc937e118a  add rsp, 0x08
000074fc937e118e  jmp 0x000074FC937DC74D
000074fc937e1193  call 0x000074FC9360C260
000074fc937e1198  jmp 0x000074FC937DC75B
000074fc937e119d  call 0x000074FC936BD750
000074fc937e11a2  jmp 0x000074FC937DC765
000074fc937e11a7  sub rsp, 0x08
000074fc937e11ab  push rax
000074fc937e11ac  push rcx
000074fc937e11ad  push rdx
000074fc937e11ae  push rdi
000074fc937e11af  push rsi
000074fc937e11b0  push r8
000074fc937e11b2  push r9
000074fc937e11b4  push r10
000074fc937e11b6  push r11
000074fc937e11b8  sub rsp, 0xF0
000074fc937e11bf  vmovaps [rsp], xmm0
000074fc937e11c4  vmovaps [rsp+0x10], xmm1
000074fc937e11ca  vmovaps [rsp+0x20], xmm2
000074fc937e11d0  vmovaps [rsp+0x30], xmm3
000074fc937e11d6  vmovaps [rsp+0x40], xmm4
000074fc937e11dc  vmovaps [rsp+0x50], xmm5
000074fc937e11e2  vmovaps [rsp+0x60], xmm6
000074fc937e11e8  vmovaps [rsp+0x70], xmm7
000074fc937e11ee  vmovaps [rsp+0x80], xmm9
000074fc937e11f7  vmovaps [rsp+0x90], xmm10
000074fc937e1200  vmovaps [rsp+0xA0], xmm11
000074fc937e1209  vmovaps [rsp+0xB0], xmm12
000074fc937e1212  vmovaps [rsp+0xC0], xmm13
000074fc937e121b  vmovaps [rsp+0xD0], xmm14
000074fc937e1224  vmovaps [rsp+0xE0], xmm15
000074fc937e122d  sub rsp, 0x30
000074fc937e1231  movaps [rsp], xmm8
000074fc937e1236  movaps [rsp+0x10], xmm15
000074fc937e123c  movaps [rsp+0x20], xmm7
000074fc937e1241  lea rdi, [rsp]
000074fc937e1245  mov esi, 0x00
000074fc937e124a  mov rax, 0x5D72CBC20530
000074fc937e1254  call rax
000074fc937e1256  movaps xmm8, [rsp]
000074fc937e125b  add rsp, 0x30
000074fc937e125f  vmovaps xmm0, [rsp]
000074fc937e1264  vmovaps xmm1, [rsp+0x10]
000074fc937e126a  vmovaps xmm2, [rsp+0x20]
000074fc937e1270  vmovaps xmm3, [rsp+0x30]
000074fc937e1276  vmovaps xmm4, [rsp+0x40]
000074fc937e127c  vmovaps xmm5, [rsp+0x50]
000074fc937e1282  vmovaps xmm6, [rsp+0x60]
000074fc937e1288  vmovaps xmm7, [rsp+0x70]
000074fc937e128e  vmovaps xmm9, [rsp+0x80]
000074fc937e1297  vmovaps xmm10, [rsp+0x90]
000074fc937e12a0  vmovaps xmm11, [rsp+0xA0]
000074fc937e12a9  vmovaps xmm12, [rsp+0xB0]
000074fc937e12b2  vmovaps xmm13, [rsp+0xC0]
000074fc937e12bb  vmovaps xmm14, [rsp+0xD0]
000074fc937e12c4  vmovaps xmm15, [rsp+0xE0]
000074fc937e12cd  add rsp, 0xF0
000074fc937e12d4  pop r11
000074fc937e12d6  pop r10
000074fc937e12d8  pop r9
000074fc937e12da  pop r8
000074fc937e12dc  pop rsi
000074fc937e12dd  pop rdi
000074fc937e12de  pop rdx
000074fc937e12df  pop rcx
000074fc937e12e0  pop rax
000074fc937e12e1  add rsp, 0x08
000074fc937e12e5  jmp 0x000074FC937DC787
000074fc937e12ea  sub rsp, 0x08
000074fc937e12ee  push rax
000074fc937e12ef  push rcx
000074fc937e12f0  push rdx
000074fc937e12f1  push rdi
000074fc937e12f2  push rsi
000074fc937e12f3  push r8
000074fc937e12f5  push r9
000074fc937e12f7  push r10
000074fc937e12f9  push r11
000074fc937e12fb  sub rsp, 0xF0
000074fc937e1302  vmovaps [rsp], xmm0
000074fc937e1307  vmovaps [rsp+0x10], xmm1
000074fc937e130d  vmovaps [rsp+0x20], xmm2
000074fc937e1313  vmovaps [rsp+0x30], xmm3
000074fc937e1319  vmovaps [rsp+0x40], xmm4
000074fc937e131f  vmovaps [rsp+0x50], xmm5
000074fc937e1325  vmovaps [rsp+0x60], xmm6
000074fc937e132b  vmovaps [rsp+0x70], xmm8
000074fc937e1331  vmovaps [rsp+0x80], xmm9
000074fc937e133a  vmovaps [rsp+0x90], xmm10
000074fc937e1343  vmovaps [rsp+0xA0], xmm11
000074fc937e134c  vmovaps [rsp+0xB0], xmm12
000074fc937e1355  vmovaps [rsp+0xC0], xmm13
000074fc937e135e  vmovaps [rsp+0xD0], xmm14
000074fc937e1367  vmovaps [rsp+0xE0], xmm15
000074fc937e1370  sub rsp, 0x30
000074fc937e1374  movaps [rsp], xmm7
000074fc937e1378  movaps [rsp+0x10], xmm9
000074fc937e137e  movaps [rsp+0x20], xmm15
000074fc937e1384  lea rdi, [rsp]
000074fc937e1388  mov esi, 0x00
000074fc937e138d  mov rax, 0x5D72CBC20530
000074fc937e1397  call rax
000074fc937e1399  movaps xmm7, [rsp]
000074fc937e139d  add rsp, 0x30
000074fc937e13a1  vmovaps xmm0, [rsp]
000074fc937e13a6  vmovaps xmm1, [rsp+0x10]
000074fc937e13ac  vmovaps xmm2, [rsp+0x20]
000074fc937e13b2  vmovaps xmm3, [rsp+0x30]
000074fc937e13b8  vmovaps xmm4, [rsp+0x40]
000074fc937e13be  vmovaps xmm5, [rsp+0x50]
000074fc937e13c4  vmovaps xmm6, [rsp+0x60]
000074fc937e13ca  vmovaps xmm8, [rsp+0x70]
000074fc937e13d0  vmovaps xmm9, [rsp+0x80]
000074fc937e13d9  vmovaps xmm10, [rsp+0x90]
000074fc937e13e2  vmovaps xmm11, [rsp+0xA0]
000074fc937e13eb  vmovaps xmm12, [rsp+0xB0]
000074fc937e13f4  vmovaps xmm13, [rsp+0xC0]
000074fc937e13fd  vmovaps xmm14, [rsp+0xD0]
000074fc937e1406  vmovaps xmm15, [rsp+0xE0]
000074fc937e140f  add rsp, 0xF0
000074fc937e1416  pop r11
000074fc937e1418  pop r10
000074fc937e141a  pop r9
000074fc937e141c  pop r8
000074fc937e141e  pop rsi
000074fc937e141f  pop rdi
000074fc937e1420  pop rdx
000074fc937e1421  pop rcx
000074fc937e1422  pop rax
000074fc937e1423  add rsp, 0x08
000074fc937e1427  jmp 0x000074FC937DC7B4
000074fc937e142c  sub rsp, 0x08
000074fc937e1430  push rax
000074fc937e1431  push rcx
000074fc937e1432  push rdx
000074fc937e1433  push rdi
000074fc937e1434  push rsi
000074fc937e1435  push r8
000074fc937e1437  push r9
000074fc937e1439  push r10
000074fc937e143b  push r11
000074fc937e143d  sub rsp, 0xF0
000074fc937e1444  vmovaps [rsp], xmm0
000074fc937e1449  vmovaps [rsp+0x10], xmm1
000074fc937e144f  vmovaps [rsp+0x20], xmm2
000074fc937e1455  vmovaps [rsp+0x30], xmm3
000074fc937e145b  vmovaps [rsp+0x40], xmm4
000074fc937e1461  vmovaps [rsp+0x50], xmm5
000074fc937e1467  vmovaps [rsp+0x60], xmm6
000074fc937e146d  vmovaps [rsp+0x70], xmm7
000074fc937e1473  vmovaps [rsp+0x80], xmm8
000074fc937e147c  vmovaps [rsp+0x90], xmm10
000074fc937e1485  vmovaps [rsp+0xA0], xmm11
000074fc937e148e  vmovaps [rsp+0xB0], xmm12
000074fc937e1497  vmovaps [rsp+0xC0], xmm13
000074fc937e14a0  vmovaps [rsp+0xD0], xmm14
000074fc937e14a9  vmovaps [rsp+0xE0], xmm15
000074fc937e14b2  sub rsp, 0x30
000074fc937e14b6  movaps [rsp], xmm9
000074fc937e14bb  movaps [rsp+0x10], xmm13
000074fc937e14c1  movaps [rsp+0x20], xmm15
000074fc937e14c7  lea rdi, [rsp]
000074fc937e14cb  mov esi, 0x00
000074fc937e14d0  mov rax, 0x5D72CBC20530
000074fc937e14da  call rax
000074fc937e14dc  movaps xmm9, [rsp]
000074fc937e14e1  add rsp, 0x30
000074fc937e14e5  vmovaps xmm0, [rsp]
000074fc937e14ea  vmovaps xmm1, [rsp+0x10]
000074fc937e14f0  vmovaps xmm2, [rsp+0x20]
000074fc937e14f6  vmovaps xmm3, [rsp+0x30]
000074fc937e14fc  vmovaps xmm4, [rsp+0x40]
000074fc937e1502  vmovaps xmm5, [rsp+0x50]
000074fc937e1508  vmovaps xmm6, [rsp+0x60]
000074fc937e150e  vmovaps xmm7, [rsp+0x70]
000074fc937e1514  vmovaps xmm8, [rsp+0x80]
000074fc937e151d  vmovaps xmm10, [rsp+0x90]
000074fc937e1526  vmovaps xmm11, [rsp+0xA0]
000074fc937e152f  vmovaps xmm12, [rsp+0xB0]
000074fc937e1538  vmovaps xmm13, [rsp+0xC0]
000074fc937e1541  vmovaps xmm14, [rsp+0xD0]
000074fc937e154a  vmovaps xmm15, [rsp+0xE0]
000074fc937e1553  add rsp, 0xF0
000074fc937e155a  pop r11
000074fc937e155c  pop r10
000074fc937e155e  pop r9
000074fc937e1560  pop r8
000074fc937e1562  pop rsi
000074fc937e1563  pop rdi
000074fc937e1564  pop rdx
000074fc937e1565  pop rcx
000074fc937e1566  pop rax
000074fc937e1567  add rsp, 0x08
000074fc937e156b  jmp 0x000074FC937DC7E2
000074fc937e1570  sub rsp, 0x08
000074fc937e1574  push rax
000074fc937e1575  push rcx
000074fc937e1576  push rdx
000074fc937e1577  push rdi
000074fc937e1578  push rsi
000074fc937e1579  push r8
000074fc937e157b  push r9
000074fc937e157d  push r10
000074fc937e157f  push r11
000074fc937e1581  sub rsp, 0xF0
000074fc937e1588  vmovaps [rsp], xmm0
000074fc937e158d  vmovaps [rsp+0x10], xmm1
000074fc937e1593  vmovaps [rsp+0x20], xmm2
000074fc937e1599  vmovaps [rsp+0x30], xmm3
000074fc937e159f  vmovaps [rsp+0x40], xmm4
000074fc937e15a5  vmovaps [rsp+0x50], xmm5
000074fc937e15ab  vmovaps [rsp+0x60], xmm6
000074fc937e15b1  vmovaps [rsp+0x70], xmm7
000074fc937e15b7  vmovaps [rsp+0x80], xmm8
000074fc937e15c0  vmovaps [rsp+0x90], xmm9
000074fc937e15c9  vmovaps [rsp+0xA0], xmm10
000074fc937e15d2  vmovaps [rsp+0xB0], xmm11
000074fc937e15db  vmovaps [rsp+0xC0], xmm12
000074fc937e15e4  vmovaps [rsp+0xD0], xmm13
000074fc937e15ed  vmovaps [rsp+0xE0], xmm14
000074fc937e15f6  sub rsp, 0x30
000074fc937e15fa  movaps [rsp], xmm15
000074fc937e15ff  movaps [rsp+0x10], xmm11
000074fc937e1605  movaps [rsp+0x20], xmm12
000074fc937e160b  lea rdi, [rsp]
000074fc937e160f  mov esi, 0x00
000074fc937e1614  mov rax, 0x5D72CBC20530
000074fc937e161e  call rax
000074fc937e1620  movaps xmm15, [rsp]
000074fc937e1625  add rsp, 0x30
000074fc937e1629  vmovaps xmm0, [rsp]
000074fc937e162e  vmovaps xmm1, [rsp+0x10]
000074fc937e1634  vmovaps xmm2, [rsp+0x20]
000074fc937e163a  vmovaps xmm3, [rsp+0x30]
000074fc937e1640  vmovaps xmm4, [rsp+0x40]
000074fc937e1646  vmovaps xmm5, [rsp+0x50]
000074fc937e164c  vmovaps xmm6, [rsp+0x60]
000074fc937e1652  vmovaps xmm7, [rsp+0x70]
000074fc937e1658  vmovaps xmm8, [rsp+0x80]
000074fc937e1661  vmovaps xmm9, [rsp+0x90]
000074fc937e166a  vmovaps xmm10, [rsp+0xA0]
000074fc937e1673  vmovaps xmm11, [rsp+0xB0]
000074fc937e167c  vmovaps xmm12, [rsp+0xC0]
000074fc937e1685  vmovaps xmm13, [rsp+0xD0]
000074fc937e168e  vmovaps xmm14, [rsp+0xE0]
000074fc937e1697  add rsp, 0xF0
000074fc937e169e  pop r11
000074fc937e16a0  pop r10
000074fc937e16a2  pop r9
000074fc937e16a4  pop r8
000074fc937e16a6  pop rsi
000074fc937e16a7  pop rdi
000074fc937e16a8  pop rdx
000074fc937e16a9  pop rcx
000074fc937e16aa  pop rax
000074fc937e16ab  add rsp, 0x08
000074fc937e16af  jmp 0x000074FC937DC7FD
000074fc937e16b4  sub rsp, 0x08
000074fc937e16b8  push rax
000074fc937e16b9  push rcx
000074fc937e16ba  push rdx
000074fc937e16bb  push rdi
000074fc937e16bc  push rsi
000074fc937e16bd  push r8
000074fc937e16bf  push r9
000074fc937e16c1  push r10
000074fc937e16c3  push r11
000074fc937e16c5  sub rsp, 0xF0
000074fc937e16cc  vmovaps [rsp], xmm0
000074fc937e16d1  vmovaps [rsp+0x10], xmm1
000074fc937e16d7  vmovaps [rsp+0x20], xmm2
000074fc937e16dd  vmovaps [rsp+0x30], xmm3
000074fc937e16e3  vmovaps [rsp+0x40], xmm4
000074fc937e16e9  vmovaps [rsp+0x50], xmm5
000074fc937e16ef  vmovaps [rsp+0x60], xmm6
000074fc937e16f5  vmovaps [rsp+0x70], xmm7
000074fc937e16fb  vmovaps [rsp+0x80], xmm8
000074fc937e1704  vmovaps [rsp+0x90], xmm9
000074fc937e170d  vmovaps [rsp+0xA0], xmm10
000074fc937e1716  vmovaps [rsp+0xB0], xmm11
000074fc937e171f  vmovaps [rsp+0xC0], xmm12
000074fc937e1728  vmovaps [rsp+0xD0], xmm14
000074fc937e1731  vmovaps [rsp+0xE0], xmm15
000074fc937e173a  sub rsp, 0x30
000074fc937e173e  movaps [rsp], xmm13
000074fc937e1743  movaps [rsp+0x10], xmm10
000074fc937e1749  movaps [rsp+0x20], xmm14
000074fc937e174f  lea rdi, [rsp]
000074fc937e1753  mov esi, 0x00
000074fc937e1758  mov rax, 0x5D72CBC20530
000074fc937e1762  call rax
000074fc937e1764  movaps xmm13, [rsp]
000074fc937e1769  add rsp, 0x30
000074fc937e176d  vmovaps xmm0, [rsp]
000074fc937e1772  vmovaps xmm1, [rsp+0x10]
000074fc937e1778  vmovaps xmm2, [rsp+0x20]
000074fc937e177e  vmovaps xmm3, [rsp+0x30]
000074fc937e1784  vmovaps xmm4, [rsp+0x40]
000074fc937e178a  vmovaps xmm5, [rsp+0x50]
000074fc937e1790  vmovaps xmm6, [rsp+0x60]
000074fc937e1796  vmovaps xmm7, [rsp+0x70]
000074fc937e179c  vmovaps xmm8, [rsp+0x80]
000074fc937e17a5  vmovaps xmm9, [rsp+0x90]
000074fc937e17ae  vmovaps xmm10, [rsp+0xA0]
000074fc937e17b7  vmovaps xmm11, [rsp+0xB0]
000074fc937e17c0  vmovaps xmm12, [rsp+0xC0]
000074fc937e17c9  vmovaps xmm14, [rsp+0xD0]
000074fc937e17d2  vmovaps xmm15, [rsp+0xE0]
000074fc937e17db  add rsp, 0xF0
000074fc937e17e2  pop r11
000074fc937e17e4  pop r10
000074fc937e17e6  pop r9
000074fc937e17e8  pop r8
000074fc937e17ea  pop rsi
000074fc937e17eb  pop rdi
000074fc937e17ec  pop rdx
000074fc937e17ed  pop rcx
000074fc937e17ee  pop rax
000074fc937e17ef  add rsp, 0x08
000074fc937e17f3  jmp 0x000074FC937DC820
000074fc937e17f8  sub rsp, 0x08
000074fc937e17fc  push rax
000074fc937e17fd  push rcx
000074fc937e17fe  push rdx
000074fc937e17ff  push rdi
000074fc937e1800  push rsi
000074fc937e1801  push r8
000074fc937e1803  push r9
000074fc937e1805  push r10
000074fc937e1807  push r11
000074fc937e1809  sub rsp, 0xF0
000074fc937e1810  vmovaps [rsp], xmm0
000074fc937e1815  vmovaps [rsp+0x10], xmm1
000074fc937e181b  vmovaps [rsp+0x20], xmm2
000074fc937e1821  vmovaps [rsp+0x30], xmm3
000074fc937e1827  vmovaps [rsp+0x40], xmm4
000074fc937e182d  vmovaps [rsp+0x50], xmm5
000074fc937e1833  vmovaps [rsp+0x60], xmm6
000074fc937e1839  vmovaps [rsp+0x70], xmm7
000074fc937e183f  vmovaps [rsp+0x80], xmm8
000074fc937e1848  vmovaps [rsp+0x90], xmm9
000074fc937e1851  vmovaps [rsp+0xA0], xmm10
000074fc937e185a  vmovaps [rsp+0xB0], xmm11
000074fc937e1863  vmovaps [rsp+0xC0], xmm12
000074fc937e186c  vmovaps [rsp+0xD0], xmm13
000074fc937e1875  vmovaps [rsp+0xE0], xmm15
000074fc937e187e  sub rsp, 0x30
000074fc937e1882  movaps [rsp], xmm14
000074fc937e1887  movaps [rsp+0x10], xmm1
000074fc937e188c  movaps [rsp+0x20], xmm7
000074fc937e1891  lea rdi, [rsp]
000074fc937e1895  mov esi, 0x00
000074fc937e189a  mov rax, 0x5D72CBC20530
000074fc937e18a4  call rax
000074fc937e18a6  movaps xmm14, [rsp]
000074fc937e18ab  add rsp, 0x30
000074fc937e18af  vmovaps xmm0, [rsp]
000074fc937e18b4  vmovaps xmm1, [rsp+0x10]
000074fc937e18ba  vmovaps xmm2, [rsp+0x20]
000074fc937e18c0  vmovaps xmm3, [rsp+0x30]
000074fc937e18c6  vmovaps xmm4, [rsp+0x40]
000074fc937e18cc  vmovaps xmm5, [rsp+0x50]
000074fc937e18d2  vmovaps xmm6, [rsp+0x60]
000074fc937e18d8  vmovaps xmm7, [rsp+0x70]
000074fc937e18de  vmovaps xmm8, [rsp+0x80]
000074fc937e18e7  vmovaps xmm9, [rsp+0x90]
000074fc937e18f0  vmovaps xmm10, [rsp+0xA0]
000074fc937e18f9  vmovaps xmm11, [rsp+0xB0]
000074fc937e1902  vmovaps xmm12, [rsp+0xC0]
000074fc937e190b  vmovaps xmm13, [rsp+0xD0]
000074fc937e1914  vmovaps xmm15, [rsp+0xE0]
000074fc937e191d  add rsp, 0xF0
000074fc937e1924  pop r11
000074fc937e1926  pop r10
000074fc937e1928  pop r9
000074fc937e192a  pop r8
000074fc937e192c  pop rsi
000074fc937e192d  pop rdi
000074fc937e192e  pop rdx
000074fc937e192f  pop rcx
000074fc937e1930  pop rax
000074fc937e1931  add rsp, 0x08
000074fc937e1935  jmp 0x000074FC937DC843
000074fc937e193a  sub rsp, 0x08
000074fc937e193e  push rax
000074fc937e193f  push rcx
000074fc937e1940  push rdx
000074fc937e1941  push rdi
000074fc937e1942  push rsi
000074fc937e1943  push r8
000074fc937e1945  push r9
000074fc937e1947  push r10
000074fc937e1949  push r11
000074fc937e194b  sub rsp, 0xF0
000074fc937e1952  vmovaps [rsp], xmm0
000074fc937e1957  vmovaps [rsp+0x10], xmm2
000074fc937e195d  vmovaps [rsp+0x20], xmm3
000074fc937e1963  vmovaps [rsp+0x30], xmm4
000074fc937e1969  vmovaps [rsp+0x40], xmm5
000074fc937e196f  vmovaps [rsp+0x50], xmm6
000074fc937e1975  vmovaps [rsp+0x60], xmm7
000074fc937e197b  vmovaps [rsp+0x70], xmm8
000074fc937e1981  vmovaps [rsp+0x80], xmm9
000074fc937e198a  vmovaps [rsp+0x90], xmm10
000074fc937e1993  vmovaps [rsp+0xA0], xmm11
000074fc937e199c  vmovaps [rsp+0xB0], xmm12
000074fc937e19a5  vmovaps [rsp+0xC0], xmm13
000074fc937e19ae  vmovaps [rsp+0xD0], xmm14
000074fc937e19b7  vmovaps [rsp+0xE0], xmm15
000074fc937e19c0  sub rsp, 0x30
000074fc937e19c4  movaps [rsp], xmm1
000074fc937e19c8  movaps [rsp+0x10], xmm8
000074fc937e19ce  movaps [rsp+0x20], xmm9
000074fc937e19d4  lea rdi, [rsp]
000074fc937e19d8  mov esi, 0x00
000074fc937e19dd  mov rax, 0x5D72CBC20530
000074fc937e19e7  call rax
000074fc937e19e9  movaps xmm1, [rsp]
000074fc937e19ed  add rsp, 0x30
000074fc937e19f1  vmovaps xmm0, [rsp]
000074fc937e19f6  vmovaps xmm2, [rsp+0x10]
000074fc937e19fc  vmovaps xmm3, [rsp+0x20]
000074fc937e1a02  vmovaps xmm4, [rsp+0x30]
000074fc937e1a08  vmovaps xmm5, [rsp+0x40]
000074fc937e1a0e  vmovaps xmm6, [rsp+0x50]
000074fc937e1a14  vmovaps xmm7, [rsp+0x60]
000074fc937e1a1a  vmovaps xmm8, [rsp+0x70]
000074fc937e1a20  vmovaps xmm9, [rsp+0x80]
000074fc937e1a29  vmovaps xmm10, [rsp+0x90]
000074fc937e1a32  vmovaps xmm11, [rsp+0xA0]
000074fc937e1a3b  vmovaps xmm12, [rsp+0xB0]
000074fc937e1a44  vmovaps xmm13, [rsp+0xC0]
000074fc937e1a4d  vmovaps xmm14, [rsp+0xD0]
000074fc937e1a56  vmovaps xmm15, [rsp+0xE0]
000074fc937e1a5f  add rsp, 0xF0
000074fc937e1a66  pop r11
000074fc937e1a68  pop r10
000074fc937e1a6a  pop r9
000074fc937e1a6c  pop r8
000074fc937e1a6e  pop rsi
000074fc937e1a6f  pop rdi
000074fc937e1a70  pop rdx
000074fc937e1a71  pop rcx
000074fc937e1a72  pop rax
000074fc937e1a73  add rsp, 0x08
000074fc937e1a77  jmp 0x000074FC937DC865
000074fc937e1a7c  call 0x000074FC936E5940
000074fc937e1a81  jmp 0x000074FC937DC873
000074fc937e1a86  call 0x000074FC9360C380
000074fc937e1a8b  jmp 0x000074FC937DC87D
000074fc937e1a90  call 0x000074FC9360D600
000074fc937e1a95  jmp 0x000074FC937DC887
000074fc937e1a9a  call 0x000074FC935FF540
000074fc937e1a9f  jmp 0x000074FC937DC891
000074fc937e1aa4  int3
000074fc937e1aa5  nop [rax+rax*1], ax
000074fc937e1aae  nop
000074fc937e1ab0  mov rax, [r15+0xF8]
000074fc937e1ab7  lea r14, [rax+0x140]
000074fc937e1abe  mov r12, [r13+r14*1]
000074fc937e1ac3  mov [r15+0xE8], r12
000074fc937e1aca  lea r14, [rax+0x130]
000074fc937e1ad1  mov r12, [r13+r14*1]
000074fc937e1ad6  lea r14, [rax+0x138]
000074fc937e1add  mov r11, [r13+r14*1]
000074fc937e1ae2  movq xmm1, r12
000074fc937e1ae7  movq xmm15, r11
000074fc937e1aec  movq xmm1, xmm1
000074fc937e1af0  movq xmm1, xmm1
000074fc937e1af4  movaps [r15+0x1A0], xmm1
000074fc937e1afc  movq xmm15, xmm15
000074fc937e1b01  movq xmm15, xmm15
000074fc937e1b06  movaps [r15+0x190], xmm15
000074fc937e1b0e  lea r14, [rax+0x120]
000074fc937e1b15  mov r12, [r13+r14*1]
000074fc937e1b1a  lea r14, [rax+0x128]
000074fc937e1b21  mov r11, [r13+r14*1]
000074fc937e1b26  movq xmm1, r12
000074fc937e1b2b  movq xmm15, r11
000074fc937e1b30  movq xmm1, xmm1
000074fc937e1b34  movq xmm1, xmm1
000074fc937e1b38  movaps [r15+0x1C0], xmm1
000074fc937e1b40  movq xmm15, xmm15
000074fc937e1b45  movq xmm15, xmm15
000074fc937e1b4a  movaps [r15+0x1B0], xmm15
000074fc937e1b52  lea r14, [rax+0x110]
000074fc937e1b59  mov r12, [r13+r14*1]
000074fc937e1b5e  lea r14, [rax+0x118]
000074fc937e1b65  mov r11, [r13+r14*1]
000074fc937e1b6a  movq xmm1, r12
000074fc937e1b6f  movq xmm15, r11
000074fc937e1b74  movq xmm1, xmm1
000074fc937e1b78  movq xmm1, xmm1
000074fc937e1b7c  movaps [r15+0x1E0], xmm1
000074fc937e1b84  movq xmm15, xmm15
000074fc937e1b89  movq xmm15, xmm15
000074fc937e1b8e  movaps [r15+0x1D0], xmm15
000074fc937e1b96  lea r14, [rax+0x100]
000074fc937e1b9d  mov r12, [r13+r14*1]
000074fc937e1ba2  lea r14, [rax+0x108]
000074fc937e1ba9  mov r11, [r13+r14*1]
000074fc937e1bae  movq xmm1, r12
000074fc937e1bb3  movq xmm15, r11
000074fc937e1bb8  movq xmm1, xmm1
000074fc937e1bbc  movq xmm1, xmm1
000074fc937e1bc0  movaps [r15+0x200], xmm1
000074fc937e1bc8  movq xmm15, xmm15
000074fc937e1bcd  movq xmm15, xmm15
000074fc937e1bd2  movaps [r15+0x1F0], xmm15
000074fc937e1bda  mov qword ptr [r15+0x40], 0x430000
000074fc937e1be2  mov r14d, 0x430510
000074fc937e1be8  mov r12, [r13+r14*1]
000074fc937e1bed  movq xmm1, r12
000074fc937e1bf2  lea r14, [rax+0x150]
000074fc937e1bf9  mov [r15+0xF8], r14
000074fc937e1c00  mov rax, [r15+0x50]
000074fc937e1c04  movups xmm15, [r13+rax*1]
000074fc937e1c0a  movaps [r15+0x120], xmm15
000074fc937e1c12  mov qword ptr [r15+0x48], 0x10
000074fc937e1c1a  xor eax, eax
000074fc937e1c1c  mov r14d, 0x10
000074fc937e1c22  mov r12d, 0x200
000074fc937e1c28  cmp r14, r12
000074fc937e1c2b  cmc
000074fc937e1c2c  lahf
000074fc937e1c2d  seto al
000074fc937e1c30  mov [r15+0x108], eax
000074fc937e1c37  pextrq rax, xmm15, 0x01
000074fc937e1c3e  movq xmm14, rax
000074fc937e1c43  movaps [r15+0x130], xmm14
000074fc937e1c4b  movq rax, xmm1
000074fc937e1c50  movq r14, xmm15
000074fc937e1c55  vmovq xmm1, rax
000074fc937e1c5a  vmovq xmm15, r14
000074fc937e1c5f  movaps xmm13, xmm1
000074fc937e1c63  addsd xmm13, xmm15
000074fc937e1c68  ucomisd xmm13, xmm13
000074fc937e1c6d  jp 0x000074FC937E1D86
000074fc937e1c73  movq xmm13, xmm13
000074fc937e1c78  movq rax, xmm13
000074fc937e1c7d  movq r14, xmm14
000074fc937e1c82  vmovq xmm1, rax
000074fc937e1c87  vmovq xmm15, r14
000074fc937e1c8c  movaps xmm14, xmm1
000074fc937e1c90  addsd xmm14, xmm15
000074fc937e1c95  ucomisd xmm14, xmm14
000074fc937e1c9a  jp 0x000074FC937E1DCE
000074fc937e1ca0  movq xmm14, xmm14
000074fc937e1ca5  movaps [r15+0x110], xmm14
000074fc937e1cad  mov eax, [r15+0x108]
000074fc937e1cb4  sahf
000074fc937e1cb5  jnz 0x000074FC937E1CE7
000074fc937e1cb7  cmp dword ptr [r15+0x318], 0x00
000074fc937e1cbf  jz 0x000074FC937E1FE0
000074fc937e1cc5  nop [rax+rax*1], ax
000074fc937e1cce  nop [rax+rax*1], eax
000074fc937e1cd6  mov eax, 0x410490
000074fc937e1cdb  mov [r15+0x100], rax
000074fc937e1ce2  jmp 0x000074FC935FE110
000074fc937e1ce7  cmp dword ptr [r15+0x318], 0x00
000074fc937e1cef  jz 0x000074FC937E1E20
000074fc937e1cf5  nop [rax+rax*1], ax
000074fc937e1cfe  nop [rax+rax*1], eax
000074fc937e1d06  mov eax, 0x410474
000074fc937e1d0b  mov [r15+0x100], rax
000074fc937e1d12  jmp 0x000074FC935FE110
000074fc937e1d17  int3
000074fc937e1d18  call 0x000074FC936E27E0
000074fc937e1d1d  jmp 0x000074FC937E1AC3
000074fc937e1d22  call 0x000074FC936E27E0
000074fc937e1d27  jmp 0x000074FC937E1AD6
000074fc937e1d2c  call 0x000074FC936E1570
000074fc937e1d31  jmp 0x000074FC937E1AE2
000074fc937e1d36  call 0x000074FC936E27E0
000074fc937e1d3b  jmp 0x000074FC937E1B1A
000074fc937e1d40  call 0x000074FC936E1570
000074fc937e1d45  jmp 0x000074FC937E1B26
000074fc937e1d4a  call 0x000074FC936E27E0
000074fc937e1d4f  jmp 0x000074FC937E1B5E
000074fc937e1d54  call 0x000074FC936E1570
000074fc937e1d59  jmp 0x000074FC937E1B6A
000074fc937e1d5e  call 0x000074FC936E27E0
000074fc937e1d63  jmp 0x000074FC937E1BA2
000074fc937e1d68  call 0x000074FC936E1570
000074fc937e1d6d  jmp 0x000074FC937E1BAE
000074fc937e1d72  call 0x000074FC936E27E0
000074fc937e1d77  jmp 0x000074FC937E1BED
000074fc937e1d7c  call 0x000074FC9360E760
000074fc937e1d81  jmp 0x000074FC937E1C0A
000074fc937e1d86  ucomisd xmm1, xmm15
000074fc937e1d8b  jp 0x000074FC937E1D9A
000074fc937e1d8d  movaps xmm13, [0x000074FC933FE060]
000074fc937e1d95  jmp 0x000074FC937E1C73
000074fc937e1d9a  vxorps xmm0, xmm1, xmm15
000074fc937e1d9f  pextrw eax, xmm0, 0x03
000074fc937e1da4  and eax, 0x7FF8
000074fc937e1da9  cmp eax, 0x08
000074fc937e1dac  jnz 0x000074FC937E1C73
000074fc937e1db2  movq rax, xmm15
000074fc937e1db7  shl rax, 0x0D
000074fc937e1dbb  jbe 0x000074FC937E1C73
000074fc937e1dc1  vorps xmm13, xmm15, [0x000074FC933FE070]
000074fc937e1dc9  jmp 0x000074FC937E1C73
000074fc937e1dce  ucomisd xmm1, xmm15
000074fc937e1dd3  jp 0x000074FC937E1DE2
000074fc937e1dd5  movaps xmm14, [0x000074FC933FE060]
000074fc937e1ddd  jmp 0x000074FC937E1CA0
000074fc937e1de2  vxorps xmm0, xmm1, xmm15
000074fc937e1de7  pextrw eax, xmm0, 0x03
000074fc937e1dec  and eax, 0x7FF8
000074fc937e1df1  cmp eax, 0x08
000074fc937e1df4  jnz 0x000074FC937E1CA0
000074fc937e1dfa  movq rax, xmm15
000074fc937e1dff  shl rax, 0x0D
000074fc937e1e03  jbe 0x000074FC937E1CA0
000074fc937e1e09  vorps xmm14, xmm15, [0x000074FC933FE070]
000074fc937e1e11  jmp 0x000074FC937E1CA0
000074fc937e1e16  int3
000074fc937e1e17  nop [rax+rax*1], ax
000074fc937e1e20  mov rax, [r15+0x48]
000074fc937e1e24  mov r14, [r15+0x50]
000074fc937e1e28  lea r12, [r14+rax*1]
000074fc937e1e2c  movups xmm1, [r13+r12*1]
000074fc937e1e32  movaps [r15+0x120], xmm1
000074fc937e1e3a  lea r14, [rax+0x10]
000074fc937e1e3e  mov [r15+0x48], r14
000074fc937e1e42  xor eax, eax
000074fc937e1e44  mov r12d, 0x200
000074fc937e1e4a  cmp r14, r12
000074fc937e1e4d  cmc
000074fc937e1e4e  lahf
000074fc937e1e4f  seto al
000074fc937e1e52  mov [r15+0x108], eax
000074fc937e1e59  pextrq rax, xmm1, 0x01
000074fc937e1e60  movq xmm15, rax
000074fc937e1e65  movaps [r15+0x130], xmm15
000074fc937e1e6d  movaps xmm14, [r15+0x110]
000074fc937e1e75  movq rax, xmm14
000074fc937e1e7a  movq r14, xmm1
000074fc937e1e7f  vmovq xmm1, rax
000074fc937e1e84  vmovq xmm14, r14
000074fc937e1e89  movaps xmm13, xmm1
000074fc937e1e8d  addsd xmm13, xmm14
000074fc937e1e92  ucomisd xmm13, xmm13
000074fc937e1e97  jp 0x000074FC937E1F4C
000074fc937e1e9d  movq xmm13, xmm13
000074fc937e1ea2  movq rax, xmm13
000074fc937e1ea7  movq r14, xmm15
000074fc937e1eac  vmovq xmm1, rax
000074fc937e1eb1  vmovq xmm15, r14
000074fc937e1eb6  movaps xmm14, xmm1
000074fc937e1eba  addsd xmm14, xmm15
000074fc937e1ebf  ucomisd xmm14, xmm14
000074fc937e1ec4  jp 0x000074FC937E1F94
000074fc937e1eca  movq xmm14, xmm14
000074fc937e1ecf  movaps [r15+0x110], xmm14
000074fc937e1ed7  mov eax, [r15+0x108]
000074fc937e1ede  sahf
000074fc937e1edf  jnz 0x000074FC937E1F11
000074fc937e1ee1  cmp dword ptr [r15+0x318], 0x00
000074fc937e1ee9  jz 0x000074FC937E1FE0
000074fc937e1eef  nop [rax+rax*1], ax
000074fc937e1ef8  nop [rax+rax*1], eax
000074fc937e1f00  mov eax, 0x410490
000074fc937e1f05  mov [r15+0x100], rax
000074fc937e1f0c  jmp 0x000074FC935FE110
000074fc937e1f11  cmp dword ptr [r15+0x318], 0x00
000074fc937e1f19  jz 0x000074FC937E1E20
000074fc937e1f1f  nop [rax+rax*1], ax
000074fc937e1f28  nop [rax+rax*1], eax
000074fc937e1f30  mov eax, 0x410474
000074fc937e1f35  mov [r15+0x100], rax
000074fc937e1f3c  jmp 0x000074FC935FE110
000074fc937e1f41  int3
000074fc937e1f42  call 0x000074FC936B52F0
000074fc937e1f47  jmp 0x000074FC937E1E32
000074fc937e1f4c  ucomisd xmm1, xmm14
000074fc937e1f51  jp 0x000074FC937E1F60
000074fc937e1f53  movaps xmm13, [0x000074FC933FE060]
000074fc937e1f5b  jmp 0x000074FC937E1E9D
000074fc937e1f60  vxorps xmm0, xmm1, xmm14
000074fc937e1f65  pextrw eax, xmm0, 0x03
000074fc937e1f6a  and eax, 0x7FF8
000074fc937e1f6f  cmp eax, 0x08
000074fc937e1f72  jnz 0x000074FC937E1E9D
000074fc937e1f78  movq rax, xmm14
000074fc937e1f7d  shl rax, 0x0D
000074fc937e1f81  jbe 0x000074FC937E1E9D
000074fc937e1f87  vorps xmm13, xmm14, [0x000074FC933FE070]
000074fc937e1f8f  jmp 0x000074FC937E1E9D
000074fc937e1f94  ucomisd xmm1, xmm15
000074fc937e1f99  jp 0x000074FC937E1FA8
000074fc937e1f9b  movaps xmm14, [0x000074FC933FE060]
000074fc937e1fa3  jmp 0x000074FC937E1ECA
000074fc937e1fa8  vxorps xmm0, xmm1, xmm15
000074fc937e1fad  pextrw eax, xmm0, 0x03
000074fc937e1fb2  and eax, 0x7FF8
000074fc937e1fb7  cmp eax, 0x08
000074fc937e1fba  jnz 0x000074FC937E1ECA
000074fc937e1fc0  movq rax, xmm15
000074fc937e1fc5  shl rax, 0x0D
000074fc937e1fc9  jbe 0x000074FC937E1ECA
000074fc937e1fcf  vorps xmm14, xmm15, [0x000074FC933FE070]
000074fc937e1fd7  jmp 0x000074FC937E1ECA
000074fc937e1fdc  int3
000074fc937e1fdd  nop [rax], eax
000074fc937e1fe0  mov rax, [r15+0x40]
000074fc937e1fe4  lea r14, [rax+0x510]
000074fc937e1feb  movaps xmm1, [r15+0x110]
000074fc937e1ff3  movq rax, xmm1
000074fc937e1ff8  mov [r13+r14*1], rax
000074fc937e1ffd  mov rax, [r15+0xF0]
000074fc937e2004  mov [r15+0x100], rax
000074fc937e200b  jmp 0x000074FC937CE5C0
000074fc937e2010  int3
000074fc937e2011  call 0x000074FC936D5EB0
000074fc937e2016  jmp 0x000074FC937E1FFD
000074fc937e201b  int3
000074fc937e201c  nop [rax], eax
000074fc937e2020  mov qword ptr [r15+0x100], 0x04
000074fc937e202b  mov esi, 0x00
000074fc937e2030  mov edx, 0x09
000074fc937e2035  mov rdi, 0x7FFD00FF8E60
000074fc937e203f  mov rax, 0x5D72CBAB3970
000074fc937e2049  call rax
000074fc937e204b  cmp dword ptr [r15+0x318], 0x00
000074fc937e2053  jnz 0x000074FC935FE110
000074fc937e2059  jmp 0x000074FC935FE0A0
000074fc937e205e  int3
000074fc937e205f  int3
