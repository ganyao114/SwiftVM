0000705c56fce69b  nop [rax+rax*1], eax
0000705c56fce6a0  vmovaps xmm1, [0x0000705C56BFE010]
0000705c56fce6a8  movq xmm1, xmm1
0000705c56fce6ac  movaps [r15+0x110], xmm1
0000705c56fce6b4  vmovaps xmm1, [0x0000705C56BFE020]
0000705c56fce6bc  movq xmm1, xmm1
0000705c56fce6c0  movaps [r15+0x120], xmm1
0000705c56fce6c8  mov eax, 0x4204C0
0000705c56fce6cd  mov r14, [r13+rax*1]
0000705c56fce6d2  movq xmm1, r14
0000705c56fce6d7  movaps [r15+0x130], xmm1
0000705c56fce6df  vmovaps xmm1, [0x0000705C56BFE030]
0000705c56fce6e7  vpbroadcastq xmm1, xmm1
0000705c56fce6ec  movaps [r15+0x140], xmm1
0000705c56fce6f4  mov qword ptr [r15+0x40], 0x02
0000705c56fce6fc  vmovaps xmm15, [0x0000705C56BFE040]
0000705c56fce704  movq xmm15, xmm15
0000705c56fce709  movaps [r15+0x150], xmm15
0000705c56fce711  mov qword ptr [r15+0x58], 0x420000
0000705c56fce719  vmovaps xmm15, [0x0000705C56BFE050]
0000705c56fce721  vpbroadcastq xmm15, xmm15
0000705c56fce726  movaps [r15+0x160], xmm15
0000705c56fce72e  mov rax, [r15+0x40]
0000705c56fce732  vmovq xmm14, rax
0000705c56fce737  vpbroadcastq xmm14, xmm14
0000705c56fce73c  movaps [r15+0x170], xmm14
0000705c56fce744  mov eax, 0x4204D0
0000705c56fce749  movups xmm13, [r13+rax*1]
0000705c56fce74f  mov qword ptr [r15+0x40], 0x430518
0000705c56fce757  mov qword ptr [r15+0x50], 0x430720
0000705c56fce75f  vpmovqd xmm12, xmm13
0000705c56fce765  pxor xmm11, xmm11
0000705c56fce76a  punpcklqdq xmm12, xmm11
0000705c56fce76f  movaps [r15+0x210], xmm12
0000705c56fce777  movq xmm12, qword ptr [r15+0x120]
0000705c56fce780  movq xmm11, qword ptr [r15+0x130]
0000705c56fce789  psubd xmm12, xmm11
0000705c56fce78e  movq xmm12, xmm12
0000705c56fce793  paddq xmm13, xmm14
0000705c56fce798  movaps [r15+0x180], xmm13
0000705c56fce7a0  movq xmm14, qword ptr [r15+0x150]
0000705c56fce7a9  paddd xmm11, xmm14
0000705c56fce7ae  movq xmm11, xmm11
0000705c56fce7b3  movq xmm11, xmm11
0000705c56fce7b8  movaps [r15+0x130], xmm11
0000705c56fce7c0  pmovzxdq xmm12, xmm12
0000705c56fce7c6  psllq xmm12, 0x00
0000705c56fce7cc  movq xmm14, qword ptr [r15+0x210]
0000705c56fce7d5  movq xmm13, qword ptr [r15+0x110]
0000705c56fce7de  paddd xmm14, xmm13
0000705c56fce7e3  movq xmm14, xmm14
0000705c56fce7e8  vcvtuqq2pd xmm12, xmm12
0000705c56fce7ee  pmovzxdq xmm14, xmm14
0000705c56fce7f4  psllq xmm14, 0x00
0000705c56fce7fa  vcvtuqq2pd xmm14, xmm14
0000705c56fce800  movaps xmm13, xmm12
0000705c56fce804  mulpd xmm13, xmm1
0000705c56fce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000705c56fce80f  ptest xmm11, xmm11
0000705c56fce815  jnz 0x0000705C56FCE8FF
0000705c56fce81b  movaps [r15+0x220], xmm13
0000705c56fce823  mov eax, 0x430720
0000705c56fce828  movups [r13+rax*1], xmm13
0000705c56fce82e  movaps xmm1, xmm14
0000705c56fce832  mulpd xmm1, xmm15
0000705c56fce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000705c56fce83c  ptest xmm13, xmm13
0000705c56fce842  jnz 0x0000705C56FCEA4C
0000705c56fce848  movaps [r15+0x210], xmm1
0000705c56fce850  mov eax, 0x430518
0000705c56fce855  movups [r13+rax*1], xmm1
0000705c56fce85b  mov qword ptr [r15+0x48], 0x10
0000705c56fce863  xor eax, eax
0000705c56fce865  mov r14d, 0x10
0000705c56fce86b  mov r12d, 0x200
0000705c56fce871  cmp r14, r12
0000705c56fce874  cmc
0000705c56fce875  lahf
0000705c56fce876  seto al
0000705c56fce879  mov [r15+0x108], eax
0000705c56fce880  mov eax, [r15+0x108]
0000705c56fce887  sahf
0000705c56fce888  jnz 0x0000705C56FCE8BA
0000705c56fce88a  cmp dword ptr [r15+0x318], 0x00
0000705c56fce892  jz 0x0000705C56FCEFF0
0000705c56fce898  nop [rax+rax*1], ax
0000705c56fce8a1  nop [rax+rax*1], eax
0000705c56fce8a9  mov eax, 0x4101EC
0000705c56fce8ae  mov [r15+0x100], rax
0000705c56fce8b5  jmp 0x0000705C56DFE110
0000705c56fce8ba  cmp dword ptr [r15+0x318], 0x00
0000705c56fce8c2  jz 0x0000705C56FCEBA0
0000705c56fce8c8  nop [rax+rax*1], ax
0000705c56fce8d1  nop [rax+rax*1], eax
0000705c56fce8d9  mov eax, 0x4101AC
0000705c56fce8de  mov [r15+0x100], rax
0000705c56fce8e5  jmp 0x0000705C56DFE110
0000705c56fce8ea  int3
0000705c56fce8eb  call 0x0000705C56E0DC20
0000705c56fce8f0  jmp 0x0000705C56FCE6D2
0000705c56fce8f5  call 0x0000705C56E0C260
0000705c56fce8fa  jmp 0x0000705C56FCE74F
0000705c56fce8ff  sub rsp, 0x08
0000705c56fce903  push rax
0000705c56fce904  push rcx
0000705c56fce905  push rdx
0000705c56fce906  push rdi
0000705c56fce907  push rsi
0000705c56fce908  push r8
0000705c56fce90a  push r9
0000705c56fce90c  push r10
0000705c56fce90e  push r11
0000705c56fce910  sub rsp, 0xF0
0000705c56fce917  vmovaps [rsp], xmm0
0000705c56fce91c  vmovaps [rsp+0x10], xmm1
0000705c56fce922  vmovaps [rsp+0x20], xmm2
0000705c56fce928  vmovaps [rsp+0x30], xmm3
0000705c56fce92e  vmovaps [rsp+0x40], xmm4
0000705c56fce934  vmovaps [rsp+0x50], xmm5
0000705c56fce93a  vmovaps [rsp+0x60], xmm6
0000705c56fce940  vmovaps [rsp+0x70], xmm7
0000705c56fce946  vmovaps [rsp+0x80], xmm8
0000705c56fce94f  vmovaps [rsp+0x90], xmm9
0000705c56fce958  vmovaps [rsp+0xA0], xmm10
0000705c56fce961  vmovaps [rsp+0xB0], xmm11
0000705c56fce96a  vmovaps [rsp+0xC0], xmm12
0000705c56fce973  vmovaps [rsp+0xD0], xmm14
0000705c56fce97c  vmovaps [rsp+0xE0], xmm15
0000705c56fce985  sub rsp, 0x30
0000705c56fce989  movaps [rsp], xmm13
0000705c56fce98e  movaps [rsp+0x10], xmm12
0000705c56fce994  movaps [rsp+0x20], xmm1
0000705c56fce999  lea rdi, [rsp]
0000705c56fce99d  mov esi, 0x00
0000705c56fce9a2  mov rax, 0x5877D3629530
0000705c56fce9ac  call rax
0000705c56fce9ae  movaps xmm13, [rsp]
0000705c56fce9b3  add rsp, 0x30
0000705c56fce9b7  vmovaps xmm0, [rsp]
0000705c56fce9bc  vmovaps xmm1, [rsp+0x10]
0000705c56fce9c2  vmovaps xmm2, [rsp+0x20]
0000705c56fce9c8  vmovaps xmm3, [rsp+0x30]
0000705c56fce9ce  vmovaps xmm4, [rsp+0x40]
0000705c56fce9d4  vmovaps xmm5, [rsp+0x50]
0000705c56fce9da  vmovaps xmm6, [rsp+0x60]
0000705c56fce9e0  vmovaps xmm7, [rsp+0x70]
0000705c56fce9e6  vmovaps xmm8, [rsp+0x80]
0000705c56fce9ef  vmovaps xmm9, [rsp+0x90]
0000705c56fce9f8  vmovaps xmm10, [rsp+0xA0]
0000705c56fcea01  vmovaps xmm11, [rsp+0xB0]
0000705c56fcea0a  vmovaps xmm12, [rsp+0xC0]
0000705c56fcea13  vmovaps xmm14, [rsp+0xD0]
0000705c56fcea1c  vmovaps xmm15, [rsp+0xE0]
0000705c56fcea25  add rsp, 0xF0
0000705c56fcea2c  pop r11
0000705c56fcea2e  pop r10
0000705c56fcea30  pop r9
0000705c56fcea32  pop r8
0000705c56fcea34  pop rsi
0000705c56fcea35  pop rdi
0000705c56fcea36  pop rdx
0000705c56fcea37  pop rcx
0000705c56fcea38  pop rax
0000705c56fcea39  add rsp, 0x08
0000705c56fcea3d  jmp 0x0000705C56FCE81B
0000705c56fcea42  call 0x0000705C56E0C380
0000705c56fcea47  jmp 0x0000705C56FCE82E
0000705c56fcea4c  sub rsp, 0x08
0000705c56fcea50  push rax
0000705c56fcea51  push rcx
0000705c56fcea52  push rdx
0000705c56fcea53  push rdi
0000705c56fcea54  push rsi
0000705c56fcea55  push r8
0000705c56fcea57  push r9
0000705c56fcea59  push r10
0000705c56fcea5b  push r11
0000705c56fcea5d  sub rsp, 0xF0
0000705c56fcea64  vmovaps [rsp], xmm0
0000705c56fcea69  vmovaps [rsp+0x10], xmm2
0000705c56fcea6f  vmovaps [rsp+0x20], xmm3
0000705c56fcea75  vmovaps [rsp+0x30], xmm4
0000705c56fcea7b  vmovaps [rsp+0x40], xmm5
0000705c56fcea81  vmovaps [rsp+0x50], xmm6
0000705c56fcea87  vmovaps [rsp+0x60], xmm7
0000705c56fcea8d  vmovaps [rsp+0x70], xmm8
0000705c56fcea93  vmovaps [rsp+0x80], xmm9
0000705c56fcea9c  vmovaps [rsp+0x90], xmm10
0000705c56fceaa5  vmovaps [rsp+0xA0], xmm11
0000705c56fceaae  vmovaps [rsp+0xB0], xmm12
0000705c56fceab7  vmovaps [rsp+0xC0], xmm13
0000705c56fceac0  vmovaps [rsp+0xD0], xmm14
0000705c56fceac9  vmovaps [rsp+0xE0], xmm15
0000705c56fcead2  sub rsp, 0x30
0000705c56fcead6  movaps [rsp], xmm1
0000705c56fceada  movaps [rsp+0x10], xmm14
0000705c56fceae0  movaps [rsp+0x20], xmm15
0000705c56fceae6  lea rdi, [rsp]
0000705c56fceaea  mov esi, 0x00
0000705c56fceaef  mov rax, 0x5877D3629530
0000705c56fceaf9  call rax
0000705c56fceafb  movaps xmm1, [rsp]
0000705c56fceaff  add rsp, 0x30
0000705c56fceb03  vmovaps xmm0, [rsp]
0000705c56fceb08  vmovaps xmm2, [rsp+0x10]
0000705c56fceb0e  vmovaps xmm3, [rsp+0x20]
0000705c56fceb14  vmovaps xmm4, [rsp+0x30]
0000705c56fceb1a  vmovaps xmm5, [rsp+0x40]
0000705c56fceb20  vmovaps xmm6, [rsp+0x50]
0000705c56fceb26  vmovaps xmm7, [rsp+0x60]
0000705c56fceb2c  vmovaps xmm8, [rsp+0x70]
0000705c56fceb32  vmovaps xmm9, [rsp+0x80]
0000705c56fceb3b  vmovaps xmm10, [rsp+0x90]
0000705c56fceb44  vmovaps xmm11, [rsp+0xA0]
0000705c56fceb4d  vmovaps xmm12, [rsp+0xB0]
0000705c56fceb56  vmovaps xmm13, [rsp+0xC0]
0000705c56fceb5f  vmovaps xmm14, [rsp+0xD0]
0000705c56fceb68  vmovaps xmm15, [rsp+0xE0]
0000705c56fceb71  add rsp, 0xF0
0000705c56fceb78  pop r11
0000705c56fceb7a  pop r10
0000705c56fceb7c  pop r9
0000705c56fceb7e  pop r8
0000705c56fceb80  pop rsi
0000705c56fceb81  pop rdi
0000705c56fceb82  pop rdx
0000705c56fceb83  pop rcx
0000705c56fceb84  pop rax
0000705c56fceb85  add rsp, 0x08
0000705c56fceb89  jmp 0x0000705C56FCE848
0000705c56fceb8e  call 0x0000705C56DFF540
0000705c56fceb93  jmp 0x0000705C56FCE85B
0000705c56fceb98  int3
0000705c56fceb99  nop [rax], eax
0000705c56fceba0  movaps xmm1, [r15+0x180]
0000705c56fceba8  vpmovqd xmm15, xmm1
0000705c56fcebae  pxor xmm14, xmm14
0000705c56fcebb3  punpcklqdq xmm15, xmm14
0000705c56fcebb8  movaps [r15+0x210], xmm15
0000705c56fcebc0  movq xmm15, qword ptr [r15+0x120]
0000705c56fcebc9  movq xmm14, qword ptr [r15+0x130]
0000705c56fcebd2  psubd xmm15, xmm14
0000705c56fcebd7  movq xmm15, xmm15
0000705c56fcebdc  movaps xmm13, [r15+0x170]
0000705c56fcebe4  paddq xmm1, xmm13
0000705c56fcebe9  movaps [r15+0x180], xmm1
0000705c56fcebf1  movq xmm1, qword ptr [r15+0x150]
0000705c56fcebfa  paddd xmm14, xmm1
0000705c56fcebff  movq xmm14, xmm14
0000705c56fcec04  movq xmm14, xmm14
0000705c56fcec09  movaps [r15+0x130], xmm14
0000705c56fcec11  pmovzxdq xmm15, xmm15
0000705c56fcec17  psllq xmm15, 0x00
0000705c56fcec1d  movq xmm1, qword ptr [r15+0x210]
0000705c56fcec26  movq xmm14, qword ptr [r15+0x110]
0000705c56fcec2f  paddd xmm1, xmm14
0000705c56fcec34  movq xmm1, xmm1
0000705c56fcec38  vcvtuqq2pd xmm15, xmm15
0000705c56fcec3e  pmovzxdq xmm1, xmm1
0000705c56fcec43  psllq xmm1, 0x00
0000705c56fcec48  vcvtuqq2pd xmm1, xmm1
0000705c56fcec4e  movaps xmm14, [r15+0x140]
0000705c56fcec56  movaps xmm13, xmm15
0000705c56fcec5a  mulpd xmm13, xmm14
0000705c56fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c56fcec65  ptest xmm12, xmm12
0000705c56fcec6b  jnz 0x0000705C56FCED4E
0000705c56fcec71  movaps [r15+0x220], xmm13
0000705c56fcec79  mov rax, [r15+0x48]
0000705c56fcec7d  mov r14, [r15+0x50]
0000705c56fcec81  lea r12, [r14+rax*1]
0000705c56fcec85  movups [r13+r12*1], xmm13
0000705c56fcec8b  movaps xmm15, [r15+0x160]
0000705c56fcec93  movaps xmm14, xmm1
0000705c56fcec97  mulpd xmm14, xmm15
0000705c56fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000705c56fceca2  ptest xmm13, xmm13
0000705c56fceca8  jnz 0x0000705C56FCEE9C
0000705c56fcecae  movaps [r15+0x210], xmm14
0000705c56fcecb6  mov r14, [r15+0x40]
0000705c56fcecba  lea r12, [r14+rax*1]
0000705c56fcecbe  movups [r13+r12*1], xmm14
0000705c56fcecc4  lea r14, [rax+0x10]
0000705c56fcecc8  mov [r15+0x48], r14
0000705c56fceccc  xor eax, eax
0000705c56fcecce  mov r12d, 0x200
0000705c56fcecd4  cmp r14, r12
0000705c56fcecd7  cmc
0000705c56fcecd8  lahf
0000705c56fcecd9  seto al
0000705c56fcecdc  mov [r15+0x108], eax
0000705c56fcece3  mov eax, [r15+0x108]
0000705c56fcecea  sahf
0000705c56fceceb  jnz 0x0000705C56FCED1D
0000705c56fceced  cmp dword ptr [r15+0x318], 0x00
0000705c56fcecf5  jz 0x0000705C56FCEFF0
0000705c56fcecfb  nop [rax+rax*1], ax
0000705c56fced04  nop [rax+rax*1], eax
0000705c56fced0c  mov eax, 0x4101EC
0000705c56fced11  mov [r15+0x100], rax
0000705c56fced18  jmp 0x0000705C56DFE110
0000705c56fced1d  cmp dword ptr [r15+0x318], 0x00
0000705c56fced25  jz 0x0000705C56FCEBA0
0000705c56fced2b  nop [rax+rax*1], ax
0000705c56fced34  nop [rax+rax*1], eax
0000705c56fced3c  mov eax, 0x4101AC
0000705c56fced41  mov [r15+0x100], rax
0000705c56fced48  jmp 0x0000705C56DFE110
0000705c56fced4d  int3
0000705c56fced4e  sub rsp, 0x08
0000705c56fced52  push rax
0000705c56fced53  push rcx
0000705c56fced54  push rdx
0000705c56fced55  push rdi
0000705c56fced56  push rsi
0000705c56fced57  push r8
0000705c56fced59  push r9
0000705c56fced5b  push r10
0000705c56fced5d  push r11
0000705c56fced5f  sub rsp, 0xF0
0000705c56fced66  vmovaps [rsp], xmm0
0000705c56fced6b  vmovaps [rsp+0x10], xmm1
0000705c56fced71  vmovaps [rsp+0x20], xmm2
0000705c56fced77  vmovaps [rsp+0x30], xmm3
0000705c56fced7d  vmovaps [rsp+0x40], xmm4
0000705c56fced83  vmovaps [rsp+0x50], xmm5
0000705c56fced89  vmovaps [rsp+0x60], xmm6
0000705c56fced8f  vmovaps [rsp+0x70], xmm7
0000705c56fced95  vmovaps [rsp+0x80], xmm8
0000705c56fced9e  vmovaps [rsp+0x90], xmm9
0000705c56fceda7  vmovaps [rsp+0xA0], xmm10
0000705c56fcedb0  vmovaps [rsp+0xB0], xmm11
0000705c56fcedb9  vmovaps [rsp+0xC0], xmm12
0000705c56fcedc2  vmovaps [rsp+0xD0], xmm14
0000705c56fcedcb  vmovaps [rsp+0xE0], xmm15
0000705c56fcedd4  sub rsp, 0x30
0000705c56fcedd8  movaps [rsp], xmm13
0000705c56fceddd  movaps [rsp+0x10], xmm15
0000705c56fcede3  movaps [rsp+0x20], xmm14
0000705c56fcede9  lea rdi, [rsp]
0000705c56fceded  mov esi, 0x00
0000705c56fcedf2  mov rax, 0x5877D3629530
0000705c56fcedfc  call rax
0000705c56fcedfe  movaps xmm13, [rsp]
0000705c56fcee03  add rsp, 0x30
0000705c56fcee07  vmovaps xmm0, [rsp]
0000705c56fcee0c  vmovaps xmm1, [rsp+0x10]
0000705c56fcee12  vmovaps xmm2, [rsp+0x20]
0000705c56fcee18  vmovaps xmm3, [rsp+0x30]
0000705c56fcee1e  vmovaps xmm4, [rsp+0x40]
0000705c56fcee24  vmovaps xmm5, [rsp+0x50]
0000705c56fcee2a  vmovaps xmm6, [rsp+0x60]
0000705c56fcee30  vmovaps xmm7, [rsp+0x70]
0000705c56fcee36  vmovaps xmm8, [rsp+0x80]
0000705c56fcee3f  vmovaps xmm9, [rsp+0x90]
0000705c56fcee48  vmovaps xmm10, [rsp+0xA0]
0000705c56fcee51  vmovaps xmm11, [rsp+0xB0]
0000705c56fcee5a  vmovaps xmm12, [rsp+0xC0]
0000705c56fcee63  vmovaps xmm14, [rsp+0xD0]
0000705c56fcee6c  vmovaps xmm15, [rsp+0xE0]
0000705c56fcee75  add rsp, 0xF0
0000705c56fcee7c  pop r11
0000705c56fcee7e  pop r10
0000705c56fcee80  pop r9
0000705c56fcee82  pop r8
0000705c56fcee84  pop rsi
0000705c56fcee85  pop rdi
0000705c56fcee86  pop rdx
0000705c56fcee87  pop rcx
0000705c56fcee88  pop rax
0000705c56fcee89  add rsp, 0x08
0000705c56fcee8d  jmp 0x0000705C56FCEC71
0000705c56fcee92  call 0x0000705C56EC2240
0000705c56fcee97  jmp 0x0000705C56FCEC8B
0000705c56fcee9c  sub rsp, 0x08
0000705c56fceea0  push rax
0000705c56fceea1  push rcx
0000705c56fceea2  push rdx
0000705c56fceea3  push rdi
0000705c56fceea4  push rsi
0000705c56fceea5  push r8
0000705c56fceea7  push r9
0000705c56fceea9  push r10
0000705c56fceeab  push r11
0000705c56fceead  sub rsp, 0xF0
0000705c56fceeb4  vmovaps [rsp], xmm0
0000705c56fceeb9  vmovaps [rsp+0x10], xmm1
0000705c56fceebf  vmovaps [rsp+0x20], xmm2
0000705c56fceec5  vmovaps [rsp+0x30], xmm3
0000705c56fceecb  vmovaps [rsp+0x40], xmm4
0000705c56fceed1  vmovaps [rsp+0x50], xmm5
0000705c56fceed7  vmovaps [rsp+0x60], xmm6
0000705c56fceedd  vmovaps [rsp+0x70], xmm7
0000705c56fceee3  vmovaps [rsp+0x80], xmm8
0000705c56fceeec  vmovaps [rsp+0x90], xmm9
0000705c56fceef5  vmovaps [rsp+0xA0], xmm10
0000705c56fceefe  vmovaps [rsp+0xB0], xmm11
0000705c56fcef07  vmovaps [rsp+0xC0], xmm12
0000705c56fcef10  vmovaps [rsp+0xD0], xmm13
0000705c56fcef19  vmovaps [rsp+0xE0], xmm15
0000705c56fcef22  sub rsp, 0x30
0000705c56fcef26  movaps [rsp], xmm14
0000705c56fcef2b  movaps [rsp+0x10], xmm1
0000705c56fcef30  movaps [rsp+0x20], xmm15
0000705c56fcef36  lea rdi, [rsp]
0000705c56fcef3a  mov esi, 0x00
0000705c56fcef3f  mov rax, 0x5877D3629530
0000705c56fcef49  call rax
0000705c56fcef4b  movaps xmm14, [rsp]
0000705c56fcef50  add rsp, 0x30
0000705c56fcef54  vmovaps xmm0, [rsp]
0000705c56fcef59  vmovaps xmm1, [rsp+0x10]
0000705c56fcef5f  vmovaps xmm2, [rsp+0x20]
0000705c56fcef65  vmovaps xmm3, [rsp+0x30]
0000705c56fcef6b  vmovaps xmm4, [rsp+0x40]
0000705c56fcef71  vmovaps xmm5, [rsp+0x50]
0000705c56fcef77  vmovaps xmm6, [rsp+0x60]
0000705c56fcef7d  vmovaps xmm7, [rsp+0x70]
0000705c56fcef83  vmovaps xmm8, [rsp+0x80]
0000705c56fcef8c  vmovaps xmm9, [rsp+0x90]
0000705c56fcef95  vmovaps xmm10, [rsp+0xA0]
0000705c56fcef9e  vmovaps xmm11, [rsp+0xB0]
0000705c56fcefa7  vmovaps xmm12, [rsp+0xC0]
0000705c56fcefb0  vmovaps xmm13, [rsp+0xD0]
0000705c56fcefb9  vmovaps xmm15, [rsp+0xE0]
0000705c56fcefc2  add rsp, 0xF0
0000705c56fcefc9  pop r11
0000705c56fcefcb  pop r10
0000705c56fcefcd  pop r9
0000705c56fcefcf  pop r8
0000705c56fcefd1  pop rsi
0000705c56fcefd2  pop rdi
0000705c56fcefd3  pop rdx
0000705c56fcefd4  pop rcx
0000705c56fcefd5  pop rax
0000705c56fcefd6  add rsp, 0x08
0000705c56fcefda  jmp 0x0000705C56FCECAE
0000705c56fcefdf  call 0x0000705C56EC34C0
0000705c56fcefe4  jmp 0x0000705C56FCECC4
0000705c56fcefe9  int3
0000705c56fcefea  nop [rax+rax*1], ax
0000705c56fceff0  mov rax, [r15+0xF8]
0000705c56fceff7  lea r14, [rax-0x150]
0000705c56fceffe  mov [r15+0xF8], r14
0000705c56fcf005  mov rax, [r15+0x50]
0000705c56fcf009  lea r12, [rax+0x80]
0000705c56fcf010  movups xmm1, [r13+r12*1]
0000705c56fcf016  lea r12, [rax+0x90]
0000705c56fcf01d  movups xmm15, [r13+r12*1]
0000705c56fcf023  mov qword ptr [r15+0x48], 0x00
0000705c56fcf02b  lea r12, [rax+0x40]
0000705c56fcf02f  movups xmm14, [r13+r12*1]
0000705c56fcf035  lea r12, [rax+0x50]
0000705c56fcf039  movups xmm13, [r13+r12*1]
0000705c56fcf03f  lea r12, [r14+0x120]
0000705c56fcf046  movq xmm12, qword ptr [r15+0x1C0]
0000705c56fcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000705c56fcf058  movq r11, xmm12
0000705c56fcf05d  movq r10, xmm11
0000705c56fcf062  mov [r13+r12*1], r11
0000705c56fcf067  lea r12, [r14+0x128]
0000705c56fcf06e  mov [r13+r12*1], r10
0000705c56fcf073  vxorps xmm12, xmm12, xmm12
0000705c56fcf078  vpbroadcastq xmm12, xmm12
0000705c56fcf07d  lea r12, [r14+0x100]
0000705c56fcf084  movq xmm11, qword ptr [r15+0x200]
0000705c56fcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000705c56fcf096  movq r11, xmm11
0000705c56fcf09b  movq r10, xmm10
0000705c56fcf0a0  mov [r13+r12*1], r11
0000705c56fcf0a5  lea r12, [r14+0x108]
0000705c56fcf0ac  mov [r13+r12*1], r10
0000705c56fcf0b1  lea r12, [r14+0xE0]
0000705c56fcf0b8  movups [r13+r12*1], xmm15
0000705c56fcf0be  lea r12, [r14+0xF0]
0000705c56fcf0c5  movups [r13+r12*1], xmm1
0000705c56fcf0cb  lea r12, [rax+0xC0]
0000705c56fcf0d2  movups xmm1, [r13+r12*1]
0000705c56fcf0d8  lea r12, [rax+0xD0]
0000705c56fcf0df  movups xmm15, [r13+r12*1]
0000705c56fcf0e5  lea r12, [r14+0x110]
0000705c56fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000705c56fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000705c56fcf0fe  movq r11, xmm11
0000705c56fcf103  movq r10, xmm10
0000705c56fcf108  mov [r13+r12*1], r11
0000705c56fcf10d  lea r12, [r14+0x118]
0000705c56fcf114  mov [r13+r12*1], r10
0000705c56fcf119  movups xmm11, [r13+rax*1]
0000705c56fcf11f  lea r12, [rax+0x10]
0000705c56fcf123  movups xmm10, [r13+r12*1]
0000705c56fcf129  lea r12, [r14+0x130]
0000705c56fcf130  movq xmm9, qword ptr [r15+0x1A0]
0000705c56fcf139  movq xmm8, qword ptr [r15+0x190]
0000705c56fcf142  movq r11, xmm9
0000705c56fcf147  movq r10, xmm8
0000705c56fcf14c  mov [r13+r12*1], r11
0000705c56fcf151  lea r12, [r14+0x138]
0000705c56fcf158  mov [r13+r12*1], r10
0000705c56fcf15d  lea r12, [rax+0x140]
0000705c56fcf164  movups xmm9, [r13+r12*1]
0000705c56fcf16a  lea r12, [rax+0x150]
0000705c56fcf171  movups xmm8, [r13+r12*1]
0000705c56fcf177  lea r12, [r14+0xC0]
0000705c56fcf17e  movups [r13+r12*1], xmm15
0000705c56fcf184  lea r12, [r14+0xD0]
0000705c56fcf18b  movups [r13+r12*1], xmm1
0000705c56fcf191  lea r12, [rax+0x100]
0000705c56fcf198  movups xmm1, [r13+r12*1]
0000705c56fcf19e  lea r12, [rax+0x110]
0000705c56fcf1a5  movups xmm15, [r13+r12*1]
0000705c56fcf1ab  lea r12, [r14+0x140]
0000705c56fcf1b2  mov r11, [r15+0xE8]
0000705c56fcf1b9  mov [r13+r12*1], r11
0000705c56fcf1be  lea r12, [rax+0x180]
0000705c56fcf1c5  movups xmm7, [r13+r12*1]
0000705c56fcf1cb  lea r12, [rax+0x190]
0000705c56fcf1d2  movups xmm6, [r13+r12*1]
0000705c56fcf1d8  lea r12, [rax+0x1C0]
0000705c56fcf1df  movups xmm5, [r13+r12*1]
0000705c56fcf1e5  lea r12, [rax+0x1D0]
0000705c56fcf1ec  movups xmm4, [r13+r12*1]
0000705c56fcf1f2  lea r12, [r14+0x20]
0000705c56fcf1f6  movups [r13+r12*1], xmm1
0000705c56fcf1fc  lea r12, [r14+0x30]
0000705c56fcf200  movups [r13+r12*1], xmm13
0000705c56fcf206  lea r12, [rax+0x60]
0000705c56fcf20a  movups xmm1, [r13+r12*1]
0000705c56fcf210  lea r12, [rax+0x70]
0000705c56fcf214  movups xmm13, [r13+r12*1]
0000705c56fcf21a  lea r12, [rax+0x20]
0000705c56fcf21e  movups xmm3, [r13+r12*1]
0000705c56fcf224  lea r12, [rax+0x30]
0000705c56fcf228  movups xmm2, [r13+r12*1]
0000705c56fcf22e  movaps [r15+0x1F0], xmm2
0000705c56fcf236  lea r12, [r14+0x60]
0000705c56fcf23a  movups [r13+r12*1], xmm11
0000705c56fcf240  lea r12, [r14+0x70]
0000705c56fcf244  movups [r13+r12*1], xmm5
0000705c56fcf24a  lea r12, [rax+0xE0]
0000705c56fcf251  movups xmm11, [r13+r12*1]
0000705c56fcf257  lea r12, [rax+0xF0]
0000705c56fcf25e  movups xmm5, [r13+r12*1]
0000705c56fcf264  lea r12, [r14+0xA0]
0000705c56fcf26b  movups [r13+r12*1], xmm13
0000705c56fcf271  lea r12, [r14+0xB0]
0000705c56fcf278  movups [r13+r12*1], xmm1
0000705c56fcf27e  lea r12, [rax+0xA0]
0000705c56fcf285  movups xmm1, [r13+r12*1]
0000705c56fcf28b  lea r12, [rax+0xB0]
0000705c56fcf292  movups xmm13, [r13+r12*1]
0000705c56fcf298  lea r12, [rax+0x120]
0000705c56fcf29f  vmovaps [rsp+0x10], xmm1
0000705c56fcf2a5  movups xmm1, [r13+r12*1]
0000705c56fcf2ab  lea r12, [rax+0x130]
0000705c56fcf2b2  vmovaps [rsp+0x20], xmm1
0000705c56fcf2b8  movups xmm1, [r13+r12*1]
0000705c56fcf2be  lea r12, [rax+0x160]
0000705c56fcf2c5  vmovaps [rsp+0x30], xmm1
0000705c56fcf2cb  movups xmm1, [r13+r12*1]
0000705c56fcf2d1  lea r12, [rax+0x170]
0000705c56fcf2d8  vmovaps [rsp+0x40], xmm1
0000705c56fcf2de  movups xmm1, [r13+r12*1]
0000705c56fcf2e4  movaps [r15+0x2B0], xmm1
0000705c56fcf2ec  lea r12, [r14+0x80]
0000705c56fcf2f3  movups [r13+r12*1], xmm13
0000705c56fcf2f9  lea r12, [r14+0x90]
0000705c56fcf300  vmovaps xmm13, [rsp+0x10]
0000705c56fcf306  movups [r13+r12*1], xmm13
0000705c56fcf30c  lea r12, [rax+0x1A0]
0000705c56fcf313  movups xmm13, [r13+r12*1]
0000705c56fcf319  lea r12, [rax+0x1B0]
0000705c56fcf320  vmovaps [rsp+0x10], xmm1
0000705c56fcf326  movups xmm1, [r13+r12*1]
0000705c56fcf32c  movaps [r15+0x290], xmm13
0000705c56fcf334  movaps [r15+0x1E0], xmm1
0000705c56fcf33c  lea r12, [rax+0x1E0]
0000705c56fcf343  vmovaps [rsp+0x50], xmm1
0000705c56fcf349  movups xmm1, [r13+r12*1]
0000705c56fcf34f  lea r12, [rax+0x1F0]
0000705c56fcf356  vmovaps [rsp+0x60], xmm1
0000705c56fcf35c  movups xmm1, [r13+r12*1]
0000705c56fcf362  mov qword ptr [r15+0x50], 0x430920
0000705c56fcf36a  lea rax, [r14+0x40]
0000705c56fcf36e  vmovaps [rsp+0x70], xmm1
0000705c56fcf374  vmovaps xmm1, [rsp+0x40]
0000705c56fcf37a  movups [r13+rax*1], xmm1
0000705c56fcf380  lea rax, [r14+0x50]
0000705c56fcf384  movups [r13+rax*1], xmm10
0000705c56fcf38a  vmovaps xmm1, [rsp+0x70]
0000705c56fcf390  movups [r13+r14*1], xmm1
0000705c56fcf396  lea rax, [r14+0x10]
0000705c56fcf39a  vmovaps xmm1, [rsp+0x60]
0000705c56fcf3a0  movups [r13+rax*1], xmm1
0000705c56fcf3a6  mov rax, [r15+0x40]
0000705c56fcf3aa  vmovaps [rsp+0x40], xmm3
0000705c56fcf3b0  vmovaps xmm1, [rsp+0x40]
0000705c56fcf3b6  por xmm3, xmm1
0000705c56fcf3ba  vmovaps [rsp+0x40], xmm6
0000705c56fcf3c0  vmovaps xmm10, [rsp+0x40]
0000705c56fcf3c6  por xmm6, xmm10
0000705c56fcf3cb  lea r12, [rax+0x30]
0000705c56fcf3cf  mov r11, [r13+r12*1]
0000705c56fcf3d4  lea r12, [rax+0x38]
0000705c56fcf3d8  mov r10, [r13+r12*1]
0000705c56fcf3dd  movq xmm10, r11
0000705c56fcf3e2  vmovaps [rsp+0x40], xmm1
0000705c56fcf3e8  movq xmm1, r10
0000705c56fcf3ed  movq xmm10, xmm10
0000705c56fcf3f2  vmovaps [rsp+0x60], xmm10
0000705c56fcf3f8  movq xmm10, xmm10
0000705c56fcf3fd  movaps [r15+0x130], xmm10
0000705c56fcf405  movq xmm1, xmm1
0000705c56fcf409  vmovaps [rsp+0x70], xmm1
0000705c56fcf40f  movq xmm1, xmm1
0000705c56fcf413  movaps [r15+0x280], xmm1
0000705c56fcf41b  vmovaps [rsp+0x80], xmm9
0000705c56fcf424  vmovaps xmm1, [rsp+0x80]
0000705c56fcf42d  por xmm9, xmm1
0000705c56fcf432  lea r12, [rax+0x20]
0000705c56fcf436  mov r11, [r13+r12*1]
0000705c56fcf43b  lea r12, [rax+0x28]
0000705c56fcf43f  mov r10, [r13+r12*1]
0000705c56fcf444  movq xmm1, r11
0000705c56fcf449  movq xmm10, r10
0000705c56fcf44e  movq xmm1, xmm1
0000705c56fcf452  vmovaps [rsp+0x80], xmm1
0000705c56fcf45b  movq xmm1, xmm1
0000705c56fcf45f  movaps [r15+0x150], xmm1
0000705c56fcf467  movq xmm10, xmm10
0000705c56fcf46c  vmovaps [rsp+0x90], xmm10
0000705c56fcf475  movq xmm10, xmm10
0000705c56fcf47a  movaps [r15+0x140], xmm10
0000705c56fcf482  lea r12, [rax+0x10]
0000705c56fcf486  mov r11, [r13+r12*1]
0000705c56fcf48b  lea r12, [rax+0x18]
0000705c56fcf48f  mov r10, [r13+r12*1]
0000705c56fcf494  movq xmm1, r11
0000705c56fcf499  movq xmm10, r10
0000705c56fcf49e  movq xmm1, xmm1
0000705c56fcf4a2  vmovaps [rsp+0xA0], xmm1
0000705c56fcf4ab  movq xmm1, xmm1
0000705c56fcf4af  movaps [r15+0x170], xmm1
0000705c56fcf4b7  movq xmm10, xmm10
0000705c56fcf4bc  vmovaps [rsp+0xB0], xmm10
0000705c56fcf4c5  movq xmm10, xmm10
0000705c56fcf4ca  movaps [r15+0x160], xmm10
0000705c56fcf4d2  mov r12, [r13+rax*1]
0000705c56fcf4d7  vmovq xmm1, r12
0000705c56fcf4dc  vpbroadcastq xmm1, xmm1
0000705c56fcf4e1  lea r12, [rax+0x08]
0000705c56fcf4e5  mov rax, [r13+r12*1]
0000705c56fcf4ea  movq xmm10, rax
0000705c56fcf4ef  movaps [r15+0x230], xmm10
0000705c56fcf4f7  lea rax, [r14+0x50]
0000705c56fcf4fb  movups xmm10, [r13+rax*1]
0000705c56fcf501  lea rax, [r14+0x60]
0000705c56fcf505  vmovaps [rsp+0xC0], xmm1
0000705c56fcf50e  movups xmm1, [r13+rax*1]
0000705c56fcf514  lea rax, [r14+0x30]
0000705c56fcf518  vmovaps [rsp+0xD0], xmm1
0000705c56fcf521  movups xmm1, [r13+rax*1]
0000705c56fcf527  mov qword ptr [r15+0x60], 0x430920
0000705c56fcf52f  mov qword ptr [r15+0x58], 0x40
0000705c56fcf537  vmovaps [rsp+0xE0], xmm1
0000705c56fcf540  vmovaps [rsp+0xF0], xmm15
0000705c56fcf549  vmovaps xmm15, [rsp+0xC0]
0000705c56fcf552  vmovaps [rsp+0xC0], xmm14
0000705c56fcf55b  vmovaps xmm14, [rsp+0x40]
0000705c56fcf561  vmovaps [rsp+0x40], xmm13
0000705c56fcf567  movaps xmm1, xmm15
0000705c56fcf56b  mulpd xmm1, xmm14
0000705c56fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000705c56fcf575  ptest xmm13, xmm13
0000705c56fcf57b  jnz 0x0000705C56FD0682
0000705c56fcf581  movq xmm14, qword ptr [r15+0x230]
0000705c56fcf58a  vmovaps [rsp+0x100], xmm14
0000705c56fcf593  vpermilpd xmm14, xmm14, 0x00
0000705c56fcf599  vmovaps [rsp+0x110], xmm1
0000705c56fcf5a2  vmovaps xmm1, [rsp+0xE0]
0000705c56fcf5ab  vmovaps [rsp+0xE0], xmm15
0000705c56fcf5b4  movaps xmm13, xmm1
0000705c56fcf5b8  mulpd xmm13, xmm14
0000705c56fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000705c56fcf5c3  ptest xmm15, xmm15
0000705c56fcf5c9  jnz 0x0000705C56FD07C4
0000705c56fcf5cf  vxorps xmm1, xmm1, xmm1
0000705c56fcf5d3  vpbroadcastq xmm1, xmm1
0000705c56fcf5d8  vmovaps xmm14, [rsp+0xE0]
0000705c56fcf5e1  vmovaps [rsp+0xE0], xmm1
0000705c56fcf5ea  vmovaps xmm1, [rsp+0xD0]
0000705c56fcf5f3  vmovaps [rsp+0xD0], xmm13
0000705c56fcf5fc  movaps xmm15, xmm14
0000705c56fcf600  mulpd xmm15, xmm1
0000705c56fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c56fcf60b  ptest xmm13, xmm13
0000705c56fcf611  jnz 0x0000705C56FD0907
0000705c56fcf617  movaps xmm1, xmm14
0000705c56fcf61b  mulpd xmm1, xmm10
0000705c56fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000705c56fcf625  ptest xmm13, xmm13
0000705c56fcf62b  jnz 0x0000705C56FD0A4A
0000705c56fcf631  movaps xmm13, xmm14
0000705c56fcf635  mulpd xmm13, xmm2
0000705c56fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000705c56fcf640  ptest xmm10, xmm10
0000705c56fcf646  jnz 0x0000705C56FD0B8C
0000705c56fcf64c  vmovaps [rsp+0x120], xmm7
0000705c56fcf655  vmovaps xmm14, [rsp+0x120]
0000705c56fcf65e  por xmm7, xmm14
0000705c56fcf663  vmovaps xmm14, [rsp+0xC0]
0000705c56fcf66c  vmovaps xmm10, [rsp+0xC0]
0000705c56fcf675  por xmm14, xmm10
0000705c56fcf67a  vmovaps xmm2, [rsp+0x100]
0000705c56fcf683  vpermilpd xmm2, xmm2, 0x00
0000705c56fcf689  vmovaps [rsp+0xC0], xmm1
0000705c56fcf692  vmovaps [rsp+0x120], xmm15
0000705c56fcf69b  movaps xmm1, xmm10
0000705c56fcf69f  mulpd xmm1, xmm2
0000705c56fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c56fcf6a8  ptest xmm15, xmm15
0000705c56fcf6ae  jnz 0x0000705C56FD0CCF
0000705c56fcf6b4  xor eax, eax
0000705c56fcf6b6  mov r12d, 0x40
0000705c56fcf6bc  mov r11d, 0x200
0000705c56fcf6c2  cmp r12, r11
0000705c56fcf6c5  cmc
0000705c56fcf6c6  lahf
0000705c56fcf6c7  seto al
0000705c56fcf6ca  mov [r15+0x108], eax
0000705c56fcf6d1  vmovaps xmm10, [rsp+0x110]
0000705c56fcf6da  vmovaps xmm2, [rsp+0xE0]
0000705c56fcf6e3  vmovaps [rsp+0xE0], xmm1
0000705c56fcf6ec  movaps xmm15, xmm10
0000705c56fcf6f0  addpd xmm15, xmm2
0000705c56fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fcf6fb  ptest xmm1, xmm1
0000705c56fcf700  jnz 0x0000705C56FD0E10
0000705c56fcf706  vmovaps xmm10, [rsp+0x120]
0000705c56fcf70f  vmovaps [rsp+0x110], xmm15
0000705c56fcf718  movaps xmm1, xmm10
0000705c56fcf71c  addpd xmm1, xmm12
0000705c56fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c56fcf726  ptest xmm15, xmm15
0000705c56fcf72c  jnz 0x0000705C56FD0F53
0000705c56fcf732  vmovaps xmm10, [rsp+0xC0]
0000705c56fcf73b  vmovaps [rsp+0xC0], xmm1
0000705c56fcf744  movaps xmm15, xmm10
0000705c56fcf748  addpd xmm15, xmm12
0000705c56fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fcf753  ptest xmm1, xmm1
0000705c56fcf758  jnz 0x0000705C56FD1095
0000705c56fcf75e  vmovaps xmm1, [rsp+0x30]
0000705c56fcf764  vmovaps xmm12, [rsp+0x30]
0000705c56fcf76a  por xmm1, xmm12
0000705c56fcf76f  vmovaps xmm12, [rsp+0x20]
0000705c56fcf775  vmovaps xmm10, [rsp+0x20]
0000705c56fcf77b  por xmm12, xmm10
0000705c56fcf780  vmovaps [rsp+0x20], xmm5
0000705c56fcf786  vmovaps xmm10, [rsp+0x20]
0000705c56fcf78c  por xmm5, xmm10
0000705c56fcf791  vmovaps [rsp+0x20], xmm11
0000705c56fcf797  vmovaps xmm10, [rsp+0x20]
0000705c56fcf79d  por xmm11, xmm10
0000705c56fcf7a2  vmovaps [rsp+0x20], xmm4
0000705c56fcf7a8  vmovaps xmm10, [rsp+0x20]
0000705c56fcf7ae  por xmm4, xmm10
0000705c56fcf7b3  vmovaps [rsp+0x20], xmm8
0000705c56fcf7b9  vmovaps xmm10, [rsp+0x20]
0000705c56fcf7bf  por xmm8, xmm10
0000705c56fcf7c4  vmovaps xmm10, [rsp+0xF0]
0000705c56fcf7cd  vmovaps [rsp+0x20], xmm1
0000705c56fcf7d3  vmovaps xmm1, [rsp+0xF0]
0000705c56fcf7dc  por xmm10, xmm1
0000705c56fcf7e1  lea rax, [r14+0xA0]
0000705c56fcf7e8  movups xmm1, [r13+rax*1]
0000705c56fcf7ee  lea rax, [r14+0xB0]
0000705c56fcf7f5  vmovaps [rsp+0x30], xmm1
0000705c56fcf7fb  movups xmm1, [r13+rax*1]
0000705c56fcf801  vmovaps [rsp+0xF0], xmm1
0000705c56fcf80a  vmovaps [rsp+0x120], xmm15
0000705c56fcf813  movaps xmm1, xmm13
0000705c56fcf817  addpd xmm1, xmm2
0000705c56fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c56fcf820  ptest xmm15, xmm15
0000705c56fcf826  jnz 0x0000705C56FD11ED
0000705c56fcf82c  lea rax, [r14+0xF0]
0000705c56fcf833  movups xmm15, [r13+rax*1]
0000705c56fcf839  vmovaps xmm2, [rsp+0xC0]
0000705c56fcf842  vmovaps [rsp+0xC0], xmm1
0000705c56fcf84b  vmovaps xmm1, [rsp+0xE0]
0000705c56fcf854  vmovaps [rsp+0xE0], xmm15
0000705c56fcf85d  movaps xmm13, xmm2
0000705c56fcf861  addpd xmm13, xmm1
0000705c56fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000705c56fcf86c  ptest xmm15, xmm15
0000705c56fcf872  jnz 0x0000705C56FD1338
0000705c56fcf878  vmovaps xmm15, [rsp+0x120]
0000705c56fcf881  vmovaps xmm2, [rsp+0xD0]
0000705c56fcf88a  vmovaps [rsp+0xD0], xmm14
0000705c56fcf893  movaps xmm1, xmm15
0000705c56fcf897  addpd xmm1, xmm2
0000705c56fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c56fcf8a0  ptest xmm14, xmm14
0000705c56fcf8a6  jnz 0x0000705C56FD147A
0000705c56fcf8ac  vmovaps xmm15, [rsp+0x100]
0000705c56fcf8b5  vpermilpd xmm15, xmm15, 0x00
0000705c56fcf8bb  vmovaps xmm2, [rsp+0xF0]
0000705c56fcf8c4  vmovaps [rsp+0xF0], xmm1
0000705c56fcf8cd  movaps xmm14, xmm2
0000705c56fcf8d1  mulpd xmm14, xmm15
0000705c56fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000705c56fcf8dc  ptest xmm1, xmm1
0000705c56fcf8e1  jnz 0x0000705C56FD15BB
0000705c56fcf8e7  vmovaps xmm1, [rsp+0xA0]
0000705c56fcf8f0  vpermilpd xmm1, xmm1, 0x00
0000705c56fcf8f6  vmovaps xmm2, [rsp+0xE0]
0000705c56fcf8ff  vmovaps [rsp+0xE0], xmm14
0000705c56fcf908  movaps xmm15, xmm2
0000705c56fcf90c  mulpd xmm15, xmm1
0000705c56fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000705c56fcf917  ptest xmm14, xmm14
0000705c56fcf91d  jnz 0x0000705C56FD16FE
0000705c56fcf923  lea rax, [r14+0xE0]
0000705c56fcf92a  movups xmm1, [r13+rax*1]
0000705c56fcf930  vmovaps xmm14, [rsp+0x100]
0000705c56fcf939  vpermilpd xmm14, xmm14, 0x00
0000705c56fcf93f  vmovaps [rsp+0x100], xmm1
0000705c56fcf948  vmovaps xmm1, [rsp+0x30]
0000705c56fcf94e  vmovaps [rsp+0x30], xmm15
0000705c56fcf954  movaps xmm2, xmm1
0000705c56fcf957  mulpd xmm2, xmm14
0000705c56fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000705c56fcf961  ptest xmm15, xmm15
0000705c56fcf967  jnz 0x0000705C56FD184A
0000705c56fcf96d  vmovaps [rsp+0x120], xmm10
0000705c56fcf976  vmovaps xmm1, [rsp+0x120]
0000705c56fcf97f  por xmm10, xmm1
0000705c56fcf984  movaps [r15+0x300], xmm10
0000705c56fcf98c  vmovaps [rsp+0x120], xmm8
0000705c56fcf995  vmovaps xmm1, [rsp+0x120]
0000705c56fcf99e  por xmm8, xmm1
0000705c56fcf9a3  movaps [r15+0x190], xmm8
0000705c56fcf9ab  vmovaps xmm1, [rsp+0xA0]
0000705c56fcf9b4  vpermilpd xmm1, xmm1, 0x00
0000705c56fcf9ba  vmovaps xmm14, [rsp+0x100]
0000705c56fcf9c3  vmovaps [rsp+0x100], xmm13
0000705c56fcf9cc  movaps xmm15, xmm14
0000705c56fcf9d0  mulpd xmm15, xmm1
0000705c56fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c56fcf9db  ptest xmm13, xmm13
0000705c56fcf9e1  jnz 0x0000705C56FD198B
0000705c56fcf9e7  lea rax, [r14+0x90]
0000705c56fcf9ee  movups xmm1, [r13+rax*1]
0000705c56fcf9f4  vmovaps [rsp+0x120], xmm4
0000705c56fcf9fd  vmovaps xmm14, [rsp+0x120]
0000705c56fcfa06  por xmm4, xmm14
0000705c56fcfa0b  movaps [r15+0x1C0], xmm4
0000705c56fcfa13  vmovaps [rsp+0x120], xmm11
0000705c56fcfa1c  vmovaps xmm14, [rsp+0x120]
0000705c56fcfa25  por xmm11, xmm14
0000705c56fcfa2a  movaps [r15+0x200], xmm11
0000705c56fcfa32  vmovaps [rsp+0x120], xmm5
0000705c56fcfa3b  vmovaps xmm14, [rsp+0x120]
0000705c56fcfa44  por xmm5, xmm14
0000705c56fcfa49  movaps [r15+0x2D0], xmm5
0000705c56fcfa51  vmovaps [rsp+0x120], xmm12
0000705c56fcfa5a  vmovaps xmm14, [rsp+0x120]
0000705c56fcfa63  por xmm12, xmm14
0000705c56fcfa68  movaps [r15+0x2E0], xmm12
0000705c56fcfa70  vmovaps xmm13, [rsp+0x110]
0000705c56fcfa79  vmovaps [rsp+0x110], xmm1
0000705c56fcfa82  vmovaps xmm1, [rsp+0xE0]
0000705c56fcfa8b  vmovaps [rsp+0xE0], xmm15
0000705c56fcfa94  movaps xmm14, xmm13
0000705c56fcfa98  addpd xmm14, xmm1
0000705c56fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000705c56fcfaa3  ptest xmm15, xmm15
0000705c56fcfaa9  jnz 0x0000705C56FD1AD8
0000705c56fcfaaf  vmovaps xmm1, [rsp+0xA0]
0000705c56fcfab8  vpermilpd xmm1, xmm1, 0x00
0000705c56fcfabe  vmovaps xmm13, [rsp+0x110]
0000705c56fcfac7  vmovaps [rsp+0x110], xmm14
0000705c56fcfad0  movaps xmm15, xmm13
0000705c56fcfad4  mulpd xmm15, xmm1
0000705c56fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000705c56fcfadf  ptest xmm14, xmm14
0000705c56fcfae5  jnz 0x0000705C56FD1C1B
0000705c56fcfaeb  lea rax, [r14+0x80]
0000705c56fcfaf2  movups xmm1, [r13+rax*1]
0000705c56fcfaf8  vmovaps xmm13, [rsp+0xC0]
0000705c56fcfb01  vmovaps [rsp+0xC0], xmm1
0000705c56fcfb0a  movaps xmm14, xmm13
0000705c56fcfb0e  addpd xmm14, xmm2
0000705c56fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000705c56fcfb19  ptest xmm1, xmm1
0000705c56fcfb1e  jnz 0x0000705C56FD1D68
0000705c56fcfb24  vmovaps xmm13, [rsp+0x100]
0000705c56fcfb2d  vmovaps xmm2, [rsp+0x30]
0000705c56fcfb33  vmovaps [rsp+0x30], xmm15
0000705c56fcfb39  movaps xmm1, xmm13
0000705c56fcfb3d  addpd xmm1, xmm2
0000705c56fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c56fcfb46  ptest xmm15, xmm15
0000705c56fcfb4c  jnz 0x0000705C56FD1EAB
0000705c56fcfb52  vmovaps xmm15, [rsp+0x20]
0000705c56fcfb58  vmovaps xmm13, [rsp+0x20]
0000705c56fcfb5e  por xmm15, xmm13
0000705c56fcfb63  movaps [r15+0x2F0], xmm15
0000705c56fcfb6b  vmovaps xmm13, [rsp+0xA0]
0000705c56fcfb74  vpermilpd xmm13, xmm13, 0x00
0000705c56fcfb7a  vmovaps [rsp+0x20], xmm1
0000705c56fcfb80  vmovaps xmm1, [rsp+0xC0]
0000705c56fcfb89  vmovaps [rsp+0xA0], xmm15
0000705c56fcfb92  movaps xmm2, xmm1
0000705c56fcfb95  mulpd xmm2, xmm13
0000705c56fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000705c56fcfb9f  ptest xmm15, xmm15
0000705c56fcfba5  jnz 0x0000705C56FD1FEC
0000705c56fcfbab  lea rax, [r14+0xD0]
0000705c56fcfbb2  movups xmm1, [r13+rax*1]
0000705c56fcfbb8  vmovaps xmm13, [rsp+0xF0]
0000705c56fcfbc1  vmovaps [rsp+0xC0], xmm1
0000705c56fcfbca  vmovaps xmm1, [rsp+0xE0]
0000705c56fcfbd3  vmovaps [rsp+0xE0], xmm14
0000705c56fcfbdc  movaps xmm15, xmm13
0000705c56fcfbe0  addpd xmm15, xmm1
0000705c56fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000705c56fcfbeb  ptest xmm14, xmm14
0000705c56fcfbf1  jnz 0x0000705C56FD2137
0000705c56fcfbf7  vmovaps xmm1, [rsp+0xB0]
0000705c56fcfc00  vpermilpd xmm1, xmm1, 0x00
0000705c56fcfc06  movaps xmm14, xmm11
0000705c56fcfc0a  mulpd xmm14, xmm1
0000705c56fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000705c56fcfc15  ptest xmm13, xmm13
0000705c56fcfc1b  jnz 0x0000705C56FD227A
0000705c56fcfc21  movaps [r15+0x260], xmm14
0000705c56fcfc29  vxorps xmm1, xmm1, xmm1
0000705c56fcfc2d  vpbroadcastq xmm1, xmm1
0000705c56fcfc32  movaps [r15+0x1B0], xmm1
0000705c56fcfc3a  vmovaps xmm1, [rsp+0xB0]
0000705c56fcfc43  vpermilpd xmm1, xmm1, 0x00
0000705c56fcfc49  vmovaps xmm11, [rsp+0xC0]
0000705c56fcfc52  vmovaps [rsp+0xC0], xmm15
0000705c56fcfc5b  movaps xmm13, xmm11
0000705c56fcfc5f  mulpd xmm13, xmm1
0000705c56fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000705c56fcfc6a  ptest xmm15, xmm15
0000705c56fcfc70  jnz 0x0000705C56FD23BD
0000705c56fcfc76  lea rax, [r14+0xC0]
0000705c56fcfc7d  movups xmm1, [r13+rax*1]
0000705c56fcfc83  vmovaps xmm11, [rsp+0x110]
0000705c56fcfc8c  vmovaps [rsp+0xF0], xmm1
0000705c56fcfc95  vmovaps xmm1, [rsp+0x30]
0000705c56fcfc9b  vmovaps [rsp+0x30], xmm14
0000705c56fcfca1  movaps xmm15, xmm11
0000705c56fcfca5  addpd xmm15, xmm1
0000705c56fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000705c56fcfcb0  ptest xmm14, xmm14
0000705c56fcfcb6  jnz 0x0000705C56FD250A
0000705c56fcfcbc  vmovaps [rsp+0x100], xmm9
0000705c56fcfcc5  vmovaps xmm1, [rsp+0x100]
0000705c56fcfcce  por xmm9, xmm1
0000705c56fcfcd3  movaps [r15+0x270], xmm9
0000705c56fcfcdb  vmovaps [rsp+0x100], xmm6
0000705c56fcfce4  vmovaps xmm1, [rsp+0x100]
0000705c56fcfced  por xmm6, xmm1
0000705c56fcfcf1  movaps [r15+0x1A0], xmm6
0000705c56fcfcf9  vmovaps xmm14, [rsp+0xB0]
0000705c56fcfd02  vpermilpd xmm14, xmm14, 0x00
0000705c56fcfd08  vmovaps xmm6, [rsp+0xF0]
0000705c56fcfd11  vmovaps [rsp+0xF0], xmm1
0000705c56fcfd1a  movaps xmm11, xmm6
0000705c56fcfd1e  mulpd xmm11, xmm14
0000705c56fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000705c56fcfd29  ptest xmm1, xmm1
0000705c56fcfd2e  jnz 0x0000705C56FD264D
0000705c56fcfd34  lea rax, [r14+0x20]
0000705c56fcfd38  movups xmm1, [r13+rax*1]
0000705c56fcfd3e  movaps [r15+0x110], xmm1
0000705c56fcfd46  vmovaps xmm6, [rsp+0xE0]
0000705c56fcfd4f  vmovaps [rsp+0xE0], xmm1
0000705c56fcfd58  movaps xmm14, xmm6
0000705c56fcfd5c  addpd xmm14, xmm2
0000705c56fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000705c56fcfd67  ptest xmm1, xmm1
0000705c56fcfd6c  jnz 0x0000705C56FD279A
0000705c56fcfd72  vmovaps xmm1, [rsp+0xB0]
0000705c56fcfd7b  vpermilpd xmm1, xmm1, 0x00
0000705c56fcfd81  movaps xmm6, xmm5
0000705c56fcfd84  mulpd xmm6, xmm1
0000705c56fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000705c56fcfd8d  ptest xmm2, xmm2
0000705c56fcfd92  jnz 0x0000705C56FD28DC
0000705c56fcfd98  vmovaps xmm5, [rsp+0x20]
0000705c56fcfd9e  movaps xmm1, xmm5
0000705c56fcfda1  addpd xmm1, xmm13
0000705c56fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c56fcfdab  ptest xmm2, xmm2
0000705c56fcfdb0  jnz 0x0000705C56FD2A1C
0000705c56fcfdb6  vmovaps xmm13, [rsp+0x80]
0000705c56fcfdbf  vpermilpd xmm13, xmm13, 0x00
0000705c56fcfdc5  vmovaps xmm2, [rsp+0xE0]
0000705c56fcfdce  vmovaps [rsp+0x20], xmm1
0000705c56fcfdd4  movaps xmm5, xmm2
0000705c56fcfdd7  mulpd xmm5, xmm13
0000705c56fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000705c56fcfde1  ptest xmm1, xmm1
0000705c56fcfde6  jnz 0x0000705C56FD2B5D
0000705c56fcfdec  vmovaps xmm1, [rsp+0x80]
0000705c56fcfdf5  vpermilpd xmm1, xmm1, 0x00
0000705c56fcfdfb  movaps xmm13, xmm10
0000705c56fcfdff  mulpd xmm13, xmm1
0000705c56fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000705c56fcfe0a  ptest xmm2, xmm2
0000705c56fcfe0f  jnz 0x0000705C56FD2C9E
0000705c56fcfe15  vmovaps xmm10, [rsp+0x30]
0000705c56fcfe1b  movaps xmm1, xmm15
0000705c56fcfe1f  addpd xmm1, xmm10
0000705c56fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c56fcfe29  ptest xmm2, xmm2
0000705c56fcfe2e  jnz 0x0000705C56FD2DE1
0000705c56fcfe34  vmovaps xmm10, [rsp+0xC0]
0000705c56fcfe3d  movaps xmm15, xmm10
0000705c56fcfe41  addpd xmm15, xmm11
0000705c56fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000705c56fcfe4c  ptest xmm2, xmm2
0000705c56fcfe51  jnz 0x0000705C56FD2F23
0000705c56fcfe57  vmovaps xmm11, [rsp+0x80]
0000705c56fcfe60  vpermilpd xmm11, xmm11, 0x00
0000705c56fcfe66  movaps xmm10, xmm12
0000705c56fcfe6a  mulpd xmm10, xmm11
0000705c56fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000705c56fcfe75  ptest xmm2, xmm2
0000705c56fcfe7a  jnz 0x0000705C56FD3067
0000705c56fcfe80  vmovaps xmm12, [rsp+0x80]
0000705c56fcfe89  vpermilpd xmm12, xmm12, 0x00
0000705c56fcfe8f  vmovaps xmm2, [rsp+0xA0]
0000705c56fcfe98  vmovaps [rsp+0x30], xmm1
0000705c56fcfe9e  movaps xmm11, xmm2
0000705c56fcfea2  mulpd xmm11, xmm12
0000705c56fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000705c56fcfead  ptest xmm1, xmm1
0000705c56fcfeb2  jnz 0x0000705C56FD31AB
0000705c56fcfeb8  movaps xmm1, xmm14
0000705c56fcfebc  addpd xmm1, xmm6
0000705c56fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c56fcfec5  ptest xmm12, xmm12
0000705c56fcfecb  jnz 0x0000705C56FD32EE
0000705c56fcfed1  vmovaps xmm12, [rsp+0x20]
0000705c56fcfed7  movaps xmm14, xmm12
0000705c56fcfedb  addpd xmm14, xmm5
0000705c56fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c56fcfee6  ptest xmm6, xmm6
0000705c56fcfeeb  jnz 0x0000705C56FD342F
0000705c56fcfef1  vmovaps xmm12, [rsp+0x90]
0000705c56fcfefa  vpermilpd xmm12, xmm12, 0x00
0000705c56fcff00  movaps xmm6, xmm9
0000705c56fcff04  mulpd xmm6, xmm12
0000705c56fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c56fcff0e  ptest xmm5, xmm5
0000705c56fcff13  jnz 0x0000705C56FD3572
0000705c56fcff19  movaps xmm12, xmm15
0000705c56fcff1d  addpd xmm12, xmm13
0000705c56fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c56fcff28  ptest xmm9, xmm9
0000705c56fcff2e  jnz 0x0000705C56FD36B4
0000705c56fcff34  vmovaps xmm13, [rsp+0x30]
0000705c56fcff3a  movaps xmm15, xmm13
0000705c56fcff3e  addpd xmm15, xmm10
0000705c56fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c56fcff49  ptest xmm9, xmm9
0000705c56fcff4f  jnz 0x0000705C56FD37F8
0000705c56fcff55  vmovaps xmm13, [rsp+0xD0]
0000705c56fcff5e  vmovaps xmm10, [rsp+0xD0]
0000705c56fcff67  por xmm13, xmm10
0000705c56fcff6c  movaps [r15+0x250], xmm13
0000705c56fcff74  vmovaps [rsp+0x20], xmm7
0000705c56fcff7a  vmovaps xmm13, [rsp+0x20]
0000705c56fcff80  por xmm7, xmm13
0000705c56fcff85  movaps [r15+0x2A0], xmm7
0000705c56fcff8d  vmovaps [rsp+0x20], xmm3
0000705c56fcff93  vmovaps xmm13, [rsp+0x20]
0000705c56fcff99  por xmm3, xmm13
0000705c56fcff9e  movaps [r15+0x1D0], xmm3
0000705c56fcffa6  lea rax, [r14+0x40]
0000705c56fcffaa  movups xmm13, [r13+rax*1]
0000705c56fcffb0  movaps [r15+0x2C0], xmm13
0000705c56fcffb8  vmovaps xmm10, [rsp+0x90]
0000705c56fcffc1  vpermilpd xmm10, xmm10, 0x00
0000705c56fcffc7  movaps xmm9, xmm8
0000705c56fcffcb  mulpd xmm9, xmm10
0000705c56fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000705c56fcffd6  ptest xmm5, xmm5
0000705c56fcffdb  jnz 0x0000705C56FD3946
0000705c56fcffe1  movaps xmm10, xmm1
0000705c56fcffe5  addpd xmm10, xmm11
0000705c56fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000705c56fcfff0  ptest xmm8, xmm8
0000705c56fcfff6  jnz 0x0000705C56FD3A8A
0000705c56fcfffc  movaps xmm1, xmm14
0000705c56fd0000  addpd xmm1, xmm6
0000705c56fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000705c56fd0009  ptest xmm11, xmm11
0000705c56fd000f  jnz 0x0000705C56FD3BCD
0000705c56fd0015  vmovaps xmm14, [rsp+0x90]
0000705c56fd001e  vpermilpd xmm14, xmm14, 0x00
0000705c56fd0024  movaps xmm11, xmm13
0000705c56fd0028  mulpd xmm11, xmm14
0000705c56fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000705c56fd0033  ptest xmm8, xmm8
0000705c56fd0039  jnz 0x0000705C56FD3D0E
0000705c56fd003f  vmovaps xmm14, [rsp+0x90]
0000705c56fd0048  vpermilpd xmm14, xmm14, 0x00
0000705c56fd004e  vmovaps xmm8, [rsp+0x10]
0000705c56fd0054  movaps xmm13, xmm8
0000705c56fd0058  mulpd xmm13, xmm14
0000705c56fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000705c56fd0063  ptest xmm6, xmm6
0000705c56fd0068  jnz 0x0000705C56FD3E52
0000705c56fd006e  vmovaps xmm14, [rsp+0x60]
0000705c56fd0074  vpermilpd xmm14, xmm14, 0x00
0000705c56fd007a  movaps xmm8, xmm7
0000705c56fd007e  mulpd xmm8, xmm14
0000705c56fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c56fd0089  ptest xmm6, xmm6
0000705c56fd008e  jnz 0x0000705C56FD3F96
0000705c56fd0094  movaps xmm14, xmm12
0000705c56fd0098  addpd xmm14, xmm9
0000705c56fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000705c56fd00a3  ptest xmm7, xmm7
0000705c56fd00a8  jnz 0x0000705C56FD40D9
0000705c56fd00ae  vmovaps xmm12, [rsp+0x60]
0000705c56fd00b4  vpermilpd xmm12, xmm12, 0x00
0000705c56fd00ba  vmovaps xmm7, [rsp+0xF0]
0000705c56fd00c3  movaps xmm9, xmm7
0000705c56fd00c7  mulpd xmm9, xmm12
0000705c56fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c56fd00d2  ptest xmm6, xmm6
0000705c56fd00d7  jnz 0x0000705C56FD421D
0000705c56fd00dd  movaps xmm12, xmm15
0000705c56fd00e1  addpd xmm12, xmm11
0000705c56fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000705c56fd00ec  ptest xmm7, xmm7
0000705c56fd00f1  jnz 0x0000705C56FD4360
0000705c56fd00f7  vmovaps xmm15, [rsp+0x60]
0000705c56fd00fd  vpermilpd xmm15, xmm15, 0x00
0000705c56fd0103  vmovaps xmm7, [rsp+0x40]
0000705c56fd0109  movaps xmm11, xmm7
0000705c56fd010d  mulpd xmm11, xmm15
0000705c56fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000705c56fd0118  ptest xmm6, xmm6
0000705c56fd011d  jnz 0x0000705C56FD44A4
0000705c56fd0123  movaps xmm15, xmm10
0000705c56fd0127  addpd xmm15, xmm13
0000705c56fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000705c56fd0132  ptest xmm7, xmm7
0000705c56fd0137  jnz 0x0000705C56FD45E7
0000705c56fd013d  vmovaps xmm13, [rsp+0x60]
0000705c56fd0143  vpermilpd xmm13, xmm13, 0x00
0000705c56fd0149  vmovaps xmm7, [rsp+0x50]
0000705c56fd014f  movaps xmm10, xmm7
0000705c56fd0153  mulpd xmm10, xmm13
0000705c56fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c56fd015e  ptest xmm6, xmm6
0000705c56fd0163  jnz 0x0000705C56FD472B
0000705c56fd0169  movaps xmm13, xmm1
0000705c56fd016d  addpd xmm13, xmm8
0000705c56fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000705c56fd0178  ptest xmm7, xmm7
0000705c56fd017d  jnz 0x0000705C56FD486E
0000705c56fd0183  lea rax, [r14+0x70]
0000705c56fd0187  movups xmm1, [r13+rax*1]
0000705c56fd018d  movaps [r15+0x240], xmm1
0000705c56fd0195  movaps xmm8, xmm14
0000705c56fd0199  addpd xmm8, xmm9
0000705c56fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c56fd01a4  ptest xmm7, xmm7
0000705c56fd01a9  jnz 0x0000705C56FD49BB
0000705c56fd01af  movaps [r15+0x170], xmm8
0000705c56fd01b7  vmovaps xmm14, [rsp+0x70]
0000705c56fd01bd  vpermilpd xmm14, xmm14, 0x00
0000705c56fd01c3  movaps xmm9, xmm1
0000705c56fd01c7  mulpd xmm9, xmm14
0000705c56fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000705c56fd01d2  ptest xmm7, xmm7
0000705c56fd01d7  jnz 0x0000705C56FD4AFF
0000705c56fd01dd  vmovaps xmm1, [rsp+0x70]
0000705c56fd01e3  vpermilpd xmm1, xmm1, 0x00
0000705c56fd01e9  movaps xmm14, xmm4
0000705c56fd01ed  mulpd xmm14, xmm1
0000705c56fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000705c56fd01f8  ptest xmm7, xmm7
0000705c56fd01fd  jnz 0x0000705C56FD4C42
0000705c56fd0203  movaps [r15+0x180], xmm14
0000705c56fd020b  movaps xmm1, xmm12
0000705c56fd020f  addpd xmm1, xmm11
0000705c56fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000705c56fd0219  ptest xmm7, xmm7
0000705c56fd021e  jnz 0x0000705C56FD4D84
0000705c56fd0224  movaps [r15+0x210], xmm1
0000705c56fd022c  movups xmm12, [r13+r14*1]
0000705c56fd0232  lea rax, [r14+0x10]
0000705c56fd0236  movups xmm11, [r13+rax*1]
0000705c56fd023c  movaps [r15+0x230], xmm11
0000705c56fd0244  movaps xmm7, xmm15
0000705c56fd0248  addpd xmm7, xmm10
0000705c56fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c56fd0252  ptest xmm6, xmm6
0000705c56fd0257  jnz 0x0000705C56FD4EDA
0000705c56fd025d  movaps [r15+0x130], xmm7
0000705c56fd0265  vmovaps xmm15, [rsp+0x70]
0000705c56fd026b  vpermilpd xmm15, xmm15, 0x00
0000705c56fd0271  movaps xmm10, xmm11
0000705c56fd0275  mulpd xmm10, xmm15
0000705c56fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c56fd0280  ptest xmm6, xmm6
0000705c56fd0285  jnz 0x0000705C56FD501C
0000705c56fd028b  movaps [r15+0x220], xmm10
0000705c56fd0293  vmovaps xmm15, [rsp+0x70]
0000705c56fd0299  vpermilpd xmm15, xmm15, 0x00
0000705c56fd029f  movaps xmm11, xmm12
0000705c56fd02a3  mulpd xmm11, xmm15
0000705c56fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000705c56fd02ae  ptest xmm6, xmm6
0000705c56fd02b3  jnz 0x0000705C56FD5160
0000705c56fd02b9  movaps xmm15, xmm13
0000705c56fd02bd  addpd xmm15, xmm9
0000705c56fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000705c56fd02c8  ptest xmm12, xmm12
0000705c56fd02ce  jnz 0x0000705C56FD52A4
0000705c56fd02d4  movaps [r15+0x140], xmm15
0000705c56fd02dc  movaps xmm13, xmm8
0000705c56fd02e0  addpd xmm13, xmm14
0000705c56fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c56fd02eb  ptest xmm12, xmm12
0000705c56fd02f1  jnz 0x0000705C56FD53E8
0000705c56fd02f7  movaps [r15+0x150], xmm13
0000705c56fd02ff  movaps xmm14, xmm1
0000705c56fd0303  addpd xmm14, xmm10
0000705c56fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000705c56fd030e  ptest xmm12, xmm12
0000705c56fd0314  jnz 0x0000705C56FD552C
0000705c56fd031a  movaps [r15+0x160], xmm14
0000705c56fd0322  movaps xmm1, xmm7
0000705c56fd0325  addpd xmm1, xmm11
0000705c56fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c56fd032f  ptest xmm12, xmm12
0000705c56fd0335  jnz 0x0000705C56FD566F
0000705c56fd033b  movaps [r15+0x120], xmm1
0000705c56fd0343  mov eax, 0x430920
0000705c56fd0348  movups [r13+rax*1], xmm15
0000705c56fd034e  mov eax, 0x430930
0000705c56fd0353  movups [r13+rax*1], xmm13
0000705c56fd0359  mov eax, 0x430940
0000705c56fd035e  movups [r13+rax*1], xmm14
0000705c56fd0364  mov eax, 0x430950
0000705c56fd0369  movups [r13+rax*1], xmm1
0000705c56fd036f  mov eax, [r15+0x108]
0000705c56fd0376  sahf
0000705c56fd0377  jnz 0x0000705C56FD03A9
0000705c56fd0379  cmp dword ptr [r15+0x318], 0x00
0000705c56fd0381  jz 0x0000705C56FDB900
0000705c56fd0387  nop [rax+rax*1], ax
0000705c56fd0390  nop [rax+rax*1], eax
0000705c56fd0398  mov eax, 0x410444
0000705c56fd039d  mov [r15+0x100], rax
0000705c56fd03a4  jmp 0x0000705C56DFE110
0000705c56fd03a9  cmp dword ptr [r15+0x318], 0x00
0000705c56fd03b1  jz 0x0000705C56FD57E0
0000705c56fd03b7  nop [rax+rax*1], ax
0000705c56fd03c0  nop [rax+rax*1], eax
0000705c56fd03c8  mov eax, 0x410278
0000705c56fd03cd  mov [r15+0x100], rax
0000705c56fd03d4  jmp 0x0000705C56DFE110
0000705c56fd03d9  int3
0000705c56fd03da  call 0x0000705C56EB52F0
0000705c56fd03df  jmp 0x0000705C56FCF016
0000705c56fd03e4  call 0x0000705C56EC4620
0000705c56fd03e9  jmp 0x0000705C56FCF023
0000705c56fd03ee  call 0x0000705C56EC33A0
0000705c56fd03f3  jmp 0x0000705C56FCF035
0000705c56fd03f8  call 0x0000705C56EC2120
0000705c56fd03fd  jmp 0x0000705C56FCF03F
0000705c56fd0402  call 0x0000705C56EC0860
0000705c56fd0407  jmp 0x0000705C56FCF067
0000705c56fd040c  call 0x0000705C56EBF5F0
0000705c56fd0411  jmp 0x0000705C56FCF073
0000705c56fd0416  call 0x0000705C56EC0860
0000705c56fd041b  jmp 0x0000705C56FCF0A5
0000705c56fd0420  call 0x0000705C56EBF5F0
0000705c56fd0425  jmp 0x0000705C56FCF0B1
0000705c56fd042a  call 0x0000705C56EC4740
0000705c56fd042f  jmp 0x0000705C56FCF0BE
0000705c56fd0434  call 0x0000705C56EB5400
0000705c56fd0439  jmp 0x0000705C56FCF0CB
0000705c56fd043e  call 0x0000705C56EB52F0
0000705c56fd0443  jmp 0x0000705C56FCF0D8
0000705c56fd0448  call 0x0000705C56EC4620
0000705c56fd044d  jmp 0x0000705C56FCF0E5
0000705c56fd0452  call 0x0000705C56EC0860
0000705c56fd0457  jmp 0x0000705C56FCF10D
0000705c56fd045c  call 0x0000705C56EBF5F0
0000705c56fd0461  jmp 0x0000705C56FCF119
0000705c56fd0466  call 0x0000705C56E09D70
0000705c56fd046b  jmp 0x0000705C56FCF11F
0000705c56fd0470  call 0x0000705C56EBE9C0
0000705c56fd0475  jmp 0x0000705C56FCF129
0000705c56fd047a  call 0x0000705C56EC0860
0000705c56fd047f  jmp 0x0000705C56FCF151
0000705c56fd0484  call 0x0000705C56EBF5F0
0000705c56fd0489  jmp 0x0000705C56FCF15D
0000705c56fd048e  call 0x0000705C56EBD750
0000705c56fd0493  jmp 0x0000705C56FCF16A
0000705c56fd0498  call 0x0000705C56EBC4E0
0000705c56fd049d  jmp 0x0000705C56FCF177
0000705c56fd04a2  call 0x0000705C56EC4740
0000705c56fd04a7  jmp 0x0000705C56FCF184
0000705c56fd04ac  call 0x0000705C56EB5400
0000705c56fd04b1  jmp 0x0000705C56FCF191
0000705c56fd04b6  call 0x0000705C56EB52F0
0000705c56fd04bb  jmp 0x0000705C56FCF19E
0000705c56fd04c0  call 0x0000705C56EC4620
0000705c56fd04c5  jmp 0x0000705C56FCF1AB
0000705c56fd04ca  call 0x0000705C56EC0860
0000705c56fd04cf  jmp 0x0000705C56FCF1BE
0000705c56fd04d4  call 0x0000705C56EBB270
0000705c56fd04d9  jmp 0x0000705C56FCF1CB
0000705c56fd04de  call 0x0000705C56EBA000
0000705c56fd04e3  jmp 0x0000705C56FCF1D8
0000705c56fd04e8  call 0x0000705C56EB8D90
0000705c56fd04ed  jmp 0x0000705C56FCF1E5
0000705c56fd04f2  call 0x0000705C56EB8A20
0000705c56fd04f7  jmp 0x0000705C56FCF1F2
0000705c56fd04fc  call 0x0000705C56EB5400
0000705c56fd0501  jmp 0x0000705C56FCF1FC
0000705c56fd0506  call 0x0000705C56EC2240
0000705c56fd050b  jmp 0x0000705C56FCF206
0000705c56fd0510  call 0x0000705C56EB52F0
0000705c56fd0515  jmp 0x0000705C56FCF210
0000705c56fd051a  call 0x0000705C56EC2120
0000705c56fd051f  jmp 0x0000705C56FCF21A
0000705c56fd0524  call 0x0000705C56EB77B0
0000705c56fd0529  jmp 0x0000705C56FCF224
0000705c56fd052e  call 0x0000705C56EB6550
0000705c56fd0533  jmp 0x0000705C56FCF22E
0000705c56fd0538  call 0x0000705C56EBFD50
0000705c56fd053d  jmp 0x0000705C56FCF240
0000705c56fd0542  call 0x0000705C56EB8EA0
0000705c56fd0547  jmp 0x0000705C56FCF24A
0000705c56fd054c  call 0x0000705C56EBFC30
0000705c56fd0551  jmp 0x0000705C56FCF257
0000705c56fd0556  call 0x0000705C56EB8D90
0000705c56fd055b  jmp 0x0000705C56FCF264
0000705c56fd0560  call 0x0000705C56EC2240
0000705c56fd0565  jmp 0x0000705C56FCF271
0000705c56fd056a  call 0x0000705C56EB5400
0000705c56fd056f  jmp 0x0000705C56FCF27E
0000705c56fd0574  call 0x0000705C56EB52F0
0000705c56fd0579  jmp 0x0000705C56FCF28B
0000705c56fd057e  call 0x0000705C56EC2120
0000705c56fd0583  jmp 0x0000705C56FCF298
0000705c56fd0588  call 0x0000705C56EB52F0
0000705c56fd058d  jmp 0x0000705C56FCF2AB
0000705c56fd0592  call 0x0000705C56EB52F0
0000705c56fd0597  jmp 0x0000705C56FCF2BE
0000705c56fd059c  call 0x0000705C56EB52F0
0000705c56fd05a1  jmp 0x0000705C56FCF2D1
0000705c56fd05a6  call 0x0000705C56EB52F0
0000705c56fd05ab  jmp 0x0000705C56FCF2E4
0000705c56fd05b0  call 0x0000705C56EC2240
0000705c56fd05b5  jmp 0x0000705C56FCF2F9
0000705c56fd05ba  call 0x0000705C56EC2240
0000705c56fd05bf  jmp 0x0000705C56FCF30C
0000705c56fd05c4  call 0x0000705C56EC2120
0000705c56fd05c9  jmp 0x0000705C56FCF319
0000705c56fd05ce  call 0x0000705C56EB52F0
0000705c56fd05d3  jmp 0x0000705C56FCF32C
0000705c56fd05d8  call 0x0000705C56EB52F0
0000705c56fd05dd  jmp 0x0000705C56FCF34F
0000705c56fd05e2  call 0x0000705C56EB52F0
0000705c56fd05e7  jmp 0x0000705C56FCF362
0000705c56fd05ec  call 0x0000705C56DFF540
0000705c56fd05f1  jmp 0x0000705C56FCF380
0000705c56fd05f6  call 0x0000705C56E08C20
0000705c56fd05fb  jmp 0x0000705C56FCF38A
0000705c56fd0600  call 0x0000705C56ED6600
0000705c56fd0605  jmp 0x0000705C56FCF396
0000705c56fd060a  call 0x0000705C56DFF540
0000705c56fd060f  jmp 0x0000705C56FCF3A6
0000705c56fd0614  call 0x0000705C56EC0370
0000705c56fd0619  jmp 0x0000705C56FCF3D4
0000705c56fd061e  call 0x0000705C56EBF100
0000705c56fd0623  jmp 0x0000705C56FCF3DD
0000705c56fd0628  call 0x0000705C56EC0370
0000705c56fd062d  jmp 0x0000705C56FCF43B
0000705c56fd0632  call 0x0000705C56EBF100
0000705c56fd0637  jmp 0x0000705C56FCF444
0000705c56fd063c  call 0x0000705C56EC0370
0000705c56fd0641  jmp 0x0000705C56FCF48B
0000705c56fd0646  call 0x0000705C56EBF100
0000705c56fd064b  jmp 0x0000705C56FCF494
0000705c56fd0650  call 0x0000705C56E0B720
0000705c56fd0655  jmp 0x0000705C56FCF4D7
0000705c56fd065a  call 0x0000705C56EB47C0
0000705c56fd065f  jmp 0x0000705C56FCF4EA
0000705c56fd0664  call 0x0000705C56E08B00
0000705c56fd0669  jmp 0x0000705C56FCF501
0000705c56fd066e  call 0x0000705C56DFF430
0000705c56fd0673  jmp 0x0000705C56FCF514
0000705c56fd0678  call 0x0000705C56DFF430
0000705c56fd067d  jmp 0x0000705C56FCF527
0000705c56fd0682  sub rsp, 0x08
0000705c56fd0686  push rax
0000705c56fd0687  push rcx
0000705c56fd0688  push rdx
0000705c56fd0689  push rdi
0000705c56fd068a  push rsi
0000705c56fd068b  push r8
0000705c56fd068d  push r9
0000705c56fd068f  push r10
0000705c56fd0691  push r11
0000705c56fd0693  sub rsp, 0xF0
0000705c56fd069a  vmovaps [rsp], xmm0
0000705c56fd069f  vmovaps [rsp+0x10], xmm2
0000705c56fd06a5  vmovaps [rsp+0x20], xmm3
0000705c56fd06ab  vmovaps [rsp+0x30], xmm4
0000705c56fd06b1  vmovaps [rsp+0x40], xmm5
0000705c56fd06b7  vmovaps [rsp+0x50], xmm6
0000705c56fd06bd  vmovaps [rsp+0x60], xmm7
0000705c56fd06c3  vmovaps [rsp+0x70], xmm8
0000705c56fd06c9  vmovaps [rsp+0x80], xmm9
0000705c56fd06d2  vmovaps [rsp+0x90], xmm10
0000705c56fd06db  vmovaps [rsp+0xA0], xmm11
0000705c56fd06e4  vmovaps [rsp+0xB0], xmm12
0000705c56fd06ed  vmovaps [rsp+0xC0], xmm13
0000705c56fd06f6  vmovaps [rsp+0xD0], xmm14
0000705c56fd06ff  vmovaps [rsp+0xE0], xmm15
0000705c56fd0708  sub rsp, 0x30
0000705c56fd070c  movaps [rsp], xmm1
0000705c56fd0710  movaps [rsp+0x10], xmm15
0000705c56fd0716  movaps [rsp+0x20], xmm14
0000705c56fd071c  lea rdi, [rsp]
0000705c56fd0720  mov esi, 0x00
0000705c56fd0725  mov rax, 0x5877D3629530
0000705c56fd072f  call rax
0000705c56fd0731  movaps xmm1, [rsp]
0000705c56fd0735  add rsp, 0x30
0000705c56fd0739  vmovaps xmm0, [rsp]
0000705c56fd073e  vmovaps xmm2, [rsp+0x10]
0000705c56fd0744  vmovaps xmm3, [rsp+0x20]
0000705c56fd074a  vmovaps xmm4, [rsp+0x30]
0000705c56fd0750  vmovaps xmm5, [rsp+0x40]
0000705c56fd0756  vmovaps xmm6, [rsp+0x50]
0000705c56fd075c  vmovaps xmm7, [rsp+0x60]
0000705c56fd0762  vmovaps xmm8, [rsp+0x70]
0000705c56fd0768  vmovaps xmm9, [rsp+0x80]
0000705c56fd0771  vmovaps xmm10, [rsp+0x90]
0000705c56fd077a  vmovaps xmm11, [rsp+0xA0]
0000705c56fd0783  vmovaps xmm12, [rsp+0xB0]
0000705c56fd078c  vmovaps xmm13, [rsp+0xC0]
0000705c56fd0795  vmovaps xmm14, [rsp+0xD0]
0000705c56fd079e  vmovaps xmm15, [rsp+0xE0]
0000705c56fd07a7  add rsp, 0xF0
0000705c56fd07ae  pop r11
0000705c56fd07b0  pop r10
0000705c56fd07b2  pop r9
0000705c56fd07b4  pop r8
0000705c56fd07b6  pop rsi
0000705c56fd07b7  pop rdi
0000705c56fd07b8  pop rdx
0000705c56fd07b9  pop rcx
0000705c56fd07ba  pop rax
0000705c56fd07bb  add rsp, 0x08
0000705c56fd07bf  jmp 0x0000705C56FCF581
0000705c56fd07c4  sub rsp, 0x08
0000705c56fd07c8  push rax
0000705c56fd07c9  push rcx
0000705c56fd07ca  push rdx
0000705c56fd07cb  push rdi
0000705c56fd07cc  push rsi
0000705c56fd07cd  push r8
0000705c56fd07cf  push r9
0000705c56fd07d1  push r10
0000705c56fd07d3  push r11
0000705c56fd07d5  sub rsp, 0xF0
0000705c56fd07dc  vmovaps [rsp], xmm0
0000705c56fd07e1  vmovaps [rsp+0x10], xmm1
0000705c56fd07e7  vmovaps [rsp+0x20], xmm2
0000705c56fd07ed  vmovaps [rsp+0x30], xmm3
0000705c56fd07f3  vmovaps [rsp+0x40], xmm4
0000705c56fd07f9  vmovaps [rsp+0x50], xmm5
0000705c56fd07ff  vmovaps [rsp+0x60], xmm6
0000705c56fd0805  vmovaps [rsp+0x70], xmm7
0000705c56fd080b  vmovaps [rsp+0x80], xmm8
0000705c56fd0814  vmovaps [rsp+0x90], xmm9
0000705c56fd081d  vmovaps [rsp+0xA0], xmm10
0000705c56fd0826  vmovaps [rsp+0xB0], xmm11
0000705c56fd082f  vmovaps [rsp+0xC0], xmm12
0000705c56fd0838  vmovaps [rsp+0xD0], xmm14
0000705c56fd0841  vmovaps [rsp+0xE0], xmm15
0000705c56fd084a  sub rsp, 0x30
0000705c56fd084e  movaps [rsp], xmm13
0000705c56fd0853  movaps [rsp+0x10], xmm1
0000705c56fd0858  movaps [rsp+0x20], xmm14
0000705c56fd085e  lea rdi, [rsp]
0000705c56fd0862  mov esi, 0x00
0000705c56fd0867  mov rax, 0x5877D3629530
0000705c56fd0871  call rax
0000705c56fd0873  movaps xmm13, [rsp]
0000705c56fd0878  add rsp, 0x30
0000705c56fd087c  vmovaps xmm0, [rsp]
0000705c56fd0881  vmovaps xmm1, [rsp+0x10]
0000705c56fd0887  vmovaps xmm2, [rsp+0x20]
0000705c56fd088d  vmovaps xmm3, [rsp+0x30]
0000705c56fd0893  vmovaps xmm4, [rsp+0x40]
0000705c56fd0899  vmovaps xmm5, [rsp+0x50]
0000705c56fd089f  vmovaps xmm6, [rsp+0x60]
0000705c56fd08a5  vmovaps xmm7, [rsp+0x70]
0000705c56fd08ab  vmovaps xmm8, [rsp+0x80]
0000705c56fd08b4  vmovaps xmm9, [rsp+0x90]
0000705c56fd08bd  vmovaps xmm10, [rsp+0xA0]
0000705c56fd08c6  vmovaps xmm11, [rsp+0xB0]
0000705c56fd08cf  vmovaps xmm12, [rsp+0xC0]
0000705c56fd08d8  vmovaps xmm14, [rsp+0xD0]
0000705c56fd08e1  vmovaps xmm15, [rsp+0xE0]
0000705c56fd08ea  add rsp, 0xF0
0000705c56fd08f1  pop r11
0000705c56fd08f3  pop r10
0000705c56fd08f5  pop r9
0000705c56fd08f7  pop r8
0000705c56fd08f9  pop rsi
0000705c56fd08fa  pop rdi
0000705c56fd08fb  pop rdx
0000705c56fd08fc  pop rcx
0000705c56fd08fd  pop rax
0000705c56fd08fe  add rsp, 0x08
0000705c56fd0902  jmp 0x0000705C56FCF5CF
0000705c56fd0907  sub rsp, 0x08
0000705c56fd090b  push rax
0000705c56fd090c  push rcx
0000705c56fd090d  push rdx
0000705c56fd090e  push rdi
0000705c56fd090f  push rsi
0000705c56fd0910  push r8
0000705c56fd0912  push r9
0000705c56fd0914  push r10
0000705c56fd0916  push r11
0000705c56fd0918  sub rsp, 0xF0
0000705c56fd091f  vmovaps [rsp], xmm0
0000705c56fd0924  vmovaps [rsp+0x10], xmm1
0000705c56fd092a  vmovaps [rsp+0x20], xmm2
0000705c56fd0930  vmovaps [rsp+0x30], xmm3
0000705c56fd0936  vmovaps [rsp+0x40], xmm4
0000705c56fd093c  vmovaps [rsp+0x50], xmm5
0000705c56fd0942  vmovaps [rsp+0x60], xmm6
0000705c56fd0948  vmovaps [rsp+0x70], xmm7
0000705c56fd094e  vmovaps [rsp+0x80], xmm8
0000705c56fd0957  vmovaps [rsp+0x90], xmm9
0000705c56fd0960  vmovaps [rsp+0xA0], xmm10
0000705c56fd0969  vmovaps [rsp+0xB0], xmm11
0000705c56fd0972  vmovaps [rsp+0xC0], xmm12
0000705c56fd097b  vmovaps [rsp+0xD0], xmm13
0000705c56fd0984  vmovaps [rsp+0xE0], xmm14
0000705c56fd098d  sub rsp, 0x30
0000705c56fd0991  movaps [rsp], xmm15
0000705c56fd0996  movaps [rsp+0x10], xmm14
0000705c56fd099c  movaps [rsp+0x20], xmm1
0000705c56fd09a1  lea rdi, [rsp]
0000705c56fd09a5  mov esi, 0x00
0000705c56fd09aa  mov rax, 0x5877D3629530
0000705c56fd09b4  call rax
0000705c56fd09b6  movaps xmm15, [rsp]
0000705c56fd09bb  add rsp, 0x30
0000705c56fd09bf  vmovaps xmm0, [rsp]
0000705c56fd09c4  vmovaps xmm1, [rsp+0x10]
0000705c56fd09ca  vmovaps xmm2, [rsp+0x20]
0000705c56fd09d0  vmovaps xmm3, [rsp+0x30]
0000705c56fd09d6  vmovaps xmm4, [rsp+0x40]
0000705c56fd09dc  vmovaps xmm5, [rsp+0x50]
0000705c56fd09e2  vmovaps xmm6, [rsp+0x60]
0000705c56fd09e8  vmovaps xmm7, [rsp+0x70]
0000705c56fd09ee  vmovaps xmm8, [rsp+0x80]
0000705c56fd09f7  vmovaps xmm9, [rsp+0x90]
0000705c56fd0a00  vmovaps xmm10, [rsp+0xA0]
0000705c56fd0a09  vmovaps xmm11, [rsp+0xB0]
0000705c56fd0a12  vmovaps xmm12, [rsp+0xC0]
0000705c56fd0a1b  vmovaps xmm13, [rsp+0xD0]
0000705c56fd0a24  vmovaps xmm14, [rsp+0xE0]
0000705c56fd0a2d  add rsp, 0xF0
0000705c56fd0a34  pop r11
0000705c56fd0a36  pop r10
0000705c56fd0a38  pop r9
0000705c56fd0a3a  pop r8
0000705c56fd0a3c  pop rsi
0000705c56fd0a3d  pop rdi
0000705c56fd0a3e  pop rdx
0000705c56fd0a3f  pop rcx
0000705c56fd0a40  pop rax
0000705c56fd0a41  add rsp, 0x08
0000705c56fd0a45  jmp 0x0000705C56FCF617
0000705c56fd0a4a  sub rsp, 0x08
0000705c56fd0a4e  push rax
0000705c56fd0a4f  push rcx
0000705c56fd0a50  push rdx
0000705c56fd0a51  push rdi
0000705c56fd0a52  push rsi
0000705c56fd0a53  push r8
0000705c56fd0a55  push r9
0000705c56fd0a57  push r10
0000705c56fd0a59  push r11
0000705c56fd0a5b  sub rsp, 0xF0
0000705c56fd0a62  vmovaps [rsp], xmm0
0000705c56fd0a67  vmovaps [rsp+0x10], xmm2
0000705c56fd0a6d  vmovaps [rsp+0x20], xmm3
0000705c56fd0a73  vmovaps [rsp+0x30], xmm4
0000705c56fd0a79  vmovaps [rsp+0x40], xmm5
0000705c56fd0a7f  vmovaps [rsp+0x50], xmm6
0000705c56fd0a85  vmovaps [rsp+0x60], xmm7
0000705c56fd0a8b  vmovaps [rsp+0x70], xmm8
0000705c56fd0a91  vmovaps [rsp+0x80], xmm9
0000705c56fd0a9a  vmovaps [rsp+0x90], xmm10
0000705c56fd0aa3  vmovaps [rsp+0xA0], xmm11
0000705c56fd0aac  vmovaps [rsp+0xB0], xmm12
0000705c56fd0ab5  vmovaps [rsp+0xC0], xmm13
0000705c56fd0abe  vmovaps [rsp+0xD0], xmm14
0000705c56fd0ac7  vmovaps [rsp+0xE0], xmm15
0000705c56fd0ad0  sub rsp, 0x30
0000705c56fd0ad4  movaps [rsp], xmm1
0000705c56fd0ad8  movaps [rsp+0x10], xmm14
0000705c56fd0ade  movaps [rsp+0x20], xmm10
0000705c56fd0ae4  lea rdi, [rsp]
0000705c56fd0ae8  mov esi, 0x00
0000705c56fd0aed  mov rax, 0x5877D3629530
0000705c56fd0af7  call rax
0000705c56fd0af9  movaps xmm1, [rsp]
0000705c56fd0afd  add rsp, 0x30
0000705c56fd0b01  vmovaps xmm0, [rsp]
0000705c56fd0b06  vmovaps xmm2, [rsp+0x10]
0000705c56fd0b0c  vmovaps xmm3, [rsp+0x20]
0000705c56fd0b12  vmovaps xmm4, [rsp+0x30]
0000705c56fd0b18  vmovaps xmm5, [rsp+0x40]
0000705c56fd0b1e  vmovaps xmm6, [rsp+0x50]
0000705c56fd0b24  vmovaps xmm7, [rsp+0x60]
0000705c56fd0b2a  vmovaps xmm8, [rsp+0x70]
0000705c56fd0b30  vmovaps xmm9, [rsp+0x80]
0000705c56fd0b39  vmovaps xmm10, [rsp+0x90]
0000705c56fd0b42  vmovaps xmm11, [rsp+0xA0]
0000705c56fd0b4b  vmovaps xmm12, [rsp+0xB0]
0000705c56fd0b54  vmovaps xmm13, [rsp+0xC0]
0000705c56fd0b5d  vmovaps xmm14, [rsp+0xD0]
0000705c56fd0b66  vmovaps xmm15, [rsp+0xE0]
0000705c56fd0b6f  add rsp, 0xF0
0000705c56fd0b76  pop r11
0000705c56fd0b78  pop r10
0000705c56fd0b7a  pop r9
0000705c56fd0b7c  pop r8
0000705c56fd0b7e  pop rsi
0000705c56fd0b7f  pop rdi
0000705c56fd0b80  pop rdx
0000705c56fd0b81  pop rcx
0000705c56fd0b82  pop rax
0000705c56fd0b83  add rsp, 0x08
0000705c56fd0b87  jmp 0x0000705C56FCF631
0000705c56fd0b8c  sub rsp, 0x08
0000705c56fd0b90  push rax
0000705c56fd0b91  push rcx
0000705c56fd0b92  push rdx
0000705c56fd0b93  push rdi
0000705c56fd0b94  push rsi
0000705c56fd0b95  push r8
0000705c56fd0b97  push r9
0000705c56fd0b99  push r10
0000705c56fd0b9b  push r11
0000705c56fd0b9d  sub rsp, 0xF0
0000705c56fd0ba4  vmovaps [rsp], xmm0
0000705c56fd0ba9  vmovaps [rsp+0x10], xmm1
0000705c56fd0baf  vmovaps [rsp+0x20], xmm2
0000705c56fd0bb5  vmovaps [rsp+0x30], xmm3
0000705c56fd0bbb  vmovaps [rsp+0x40], xmm4
0000705c56fd0bc1  vmovaps [rsp+0x50], xmm5
0000705c56fd0bc7  vmovaps [rsp+0x60], xmm6
0000705c56fd0bcd  vmovaps [rsp+0x70], xmm7
0000705c56fd0bd3  vmovaps [rsp+0x80], xmm8
0000705c56fd0bdc  vmovaps [rsp+0x90], xmm9
0000705c56fd0be5  vmovaps [rsp+0xA0], xmm10
0000705c56fd0bee  vmovaps [rsp+0xB0], xmm11
0000705c56fd0bf7  vmovaps [rsp+0xC0], xmm12
0000705c56fd0c00  vmovaps [rsp+0xD0], xmm14
0000705c56fd0c09  vmovaps [rsp+0xE0], xmm15
0000705c56fd0c12  sub rsp, 0x30
0000705c56fd0c16  movaps [rsp], xmm13
0000705c56fd0c1b  movaps [rsp+0x10], xmm14
0000705c56fd0c21  movaps [rsp+0x20], xmm2
0000705c56fd0c26  lea rdi, [rsp]
0000705c56fd0c2a  mov esi, 0x00
0000705c56fd0c2f  mov rax, 0x5877D3629530
0000705c56fd0c39  call rax
0000705c56fd0c3b  movaps xmm13, [rsp]
0000705c56fd0c40  add rsp, 0x30
0000705c56fd0c44  vmovaps xmm0, [rsp]
0000705c56fd0c49  vmovaps xmm1, [rsp+0x10]
0000705c56fd0c4f  vmovaps xmm2, [rsp+0x20]
0000705c56fd0c55  vmovaps xmm3, [rsp+0x30]
0000705c56fd0c5b  vmovaps xmm4, [rsp+0x40]
0000705c56fd0c61  vmovaps xmm5, [rsp+0x50]
0000705c56fd0c67  vmovaps xmm6, [rsp+0x60]
0000705c56fd0c6d  vmovaps xmm7, [rsp+0x70]
0000705c56fd0c73  vmovaps xmm8, [rsp+0x80]
0000705c56fd0c7c  vmovaps xmm9, [rsp+0x90]
0000705c56fd0c85  vmovaps xmm10, [rsp+0xA0]
0000705c56fd0c8e  vmovaps xmm11, [rsp+0xB0]
0000705c56fd0c97  vmovaps xmm12, [rsp+0xC0]
0000705c56fd0ca0  vmovaps xmm14, [rsp+0xD0]
0000705c56fd0ca9  vmovaps xmm15, [rsp+0xE0]
0000705c56fd0cb2  add rsp, 0xF0
0000705c56fd0cb9  pop r11
0000705c56fd0cbb  pop r10
0000705c56fd0cbd  pop r9
0000705c56fd0cbf  pop r8
0000705c56fd0cc1  pop rsi
0000705c56fd0cc2  pop rdi
0000705c56fd0cc3  pop rdx
0000705c56fd0cc4  pop rcx
0000705c56fd0cc5  pop rax
0000705c56fd0cc6  add rsp, 0x08
0000705c56fd0cca  jmp 0x0000705C56FCF64C
0000705c56fd0ccf  sub rsp, 0x08
0000705c56fd0cd3  push rax
0000705c56fd0cd4  push rcx
0000705c56fd0cd5  push rdx
0000705c56fd0cd6  push rdi
0000705c56fd0cd7  push rsi
0000705c56fd0cd8  push r8
0000705c56fd0cda  push r9
0000705c56fd0cdc  push r10
0000705c56fd0cde  push r11
0000705c56fd0ce0  sub rsp, 0xF0
0000705c56fd0ce7  vmovaps [rsp], xmm0
0000705c56fd0cec  vmovaps [rsp+0x10], xmm2
0000705c56fd0cf2  vmovaps [rsp+0x20], xmm3
0000705c56fd0cf8  vmovaps [rsp+0x30], xmm4
0000705c56fd0cfe  vmovaps [rsp+0x40], xmm5
0000705c56fd0d04  vmovaps [rsp+0x50], xmm6
0000705c56fd0d0a  vmovaps [rsp+0x60], xmm7
0000705c56fd0d10  vmovaps [rsp+0x70], xmm8
0000705c56fd0d16  vmovaps [rsp+0x80], xmm9
0000705c56fd0d1f  vmovaps [rsp+0x90], xmm10
0000705c56fd0d28  vmovaps [rsp+0xA0], xmm11
0000705c56fd0d31  vmovaps [rsp+0xB0], xmm12
0000705c56fd0d3a  vmovaps [rsp+0xC0], xmm13
0000705c56fd0d43  vmovaps [rsp+0xD0], xmm14
0000705c56fd0d4c  vmovaps [rsp+0xE0], xmm15
0000705c56fd0d55  sub rsp, 0x30
0000705c56fd0d59  movaps [rsp], xmm1
0000705c56fd0d5d  movaps [rsp+0x10], xmm10
0000705c56fd0d63  movaps [rsp+0x20], xmm2
0000705c56fd0d68  lea rdi, [rsp]
0000705c56fd0d6c  mov esi, 0x00
0000705c56fd0d71  mov rax, 0x5877D3629530
0000705c56fd0d7b  call rax
0000705c56fd0d7d  movaps xmm1, [rsp]
0000705c56fd0d81  add rsp, 0x30
0000705c56fd0d85  vmovaps xmm0, [rsp]
0000705c56fd0d8a  vmovaps xmm2, [rsp+0x10]
0000705c56fd0d90  vmovaps xmm3, [rsp+0x20]
0000705c56fd0d96  vmovaps xmm4, [rsp+0x30]
0000705c56fd0d9c  vmovaps xmm5, [rsp+0x40]
0000705c56fd0da2  vmovaps xmm6, [rsp+0x50]
0000705c56fd0da8  vmovaps xmm7, [rsp+0x60]
0000705c56fd0dae  vmovaps xmm8, [rsp+0x70]
0000705c56fd0db4  vmovaps xmm9, [rsp+0x80]
0000705c56fd0dbd  vmovaps xmm10, [rsp+0x90]
0000705c56fd0dc6  vmovaps xmm11, [rsp+0xA0]
0000705c56fd0dcf  vmovaps xmm12, [rsp+0xB0]
0000705c56fd0dd8  vmovaps xmm13, [rsp+0xC0]
0000705c56fd0de1  vmovaps xmm14, [rsp+0xD0]
0000705c56fd0dea  vmovaps xmm15, [rsp+0xE0]
0000705c56fd0df3  add rsp, 0xF0
0000705c56fd0dfa  pop r11
0000705c56fd0dfc  pop r10
0000705c56fd0dfe  pop r9
0000705c56fd0e00  pop r8
0000705c56fd0e02  pop rsi
0000705c56fd0e03  pop rdi
0000705c56fd0e04  pop rdx
0000705c56fd0e05  pop rcx
0000705c56fd0e06  pop rax
0000705c56fd0e07  add rsp, 0x08
0000705c56fd0e0b  jmp 0x0000705C56FCF6B4
0000705c56fd0e10  sub rsp, 0x08
0000705c56fd0e14  push rax
0000705c56fd0e15  push rcx
0000705c56fd0e16  push rdx
0000705c56fd0e17  push rdi
0000705c56fd0e18  push rsi
0000705c56fd0e19  push r8
0000705c56fd0e1b  push r9
0000705c56fd0e1d  push r10
0000705c56fd0e1f  push r11
0000705c56fd0e21  sub rsp, 0xF0
0000705c56fd0e28  vmovaps [rsp], xmm0
0000705c56fd0e2d  vmovaps [rsp+0x10], xmm1
0000705c56fd0e33  vmovaps [rsp+0x20], xmm2
0000705c56fd0e39  vmovaps [rsp+0x30], xmm3
0000705c56fd0e3f  vmovaps [rsp+0x40], xmm4
0000705c56fd0e45  vmovaps [rsp+0x50], xmm5
0000705c56fd0e4b  vmovaps [rsp+0x60], xmm6
0000705c56fd0e51  vmovaps [rsp+0x70], xmm7
0000705c56fd0e57  vmovaps [rsp+0x80], xmm8
0000705c56fd0e60  vmovaps [rsp+0x90], xmm9
0000705c56fd0e69  vmovaps [rsp+0xA0], xmm10
0000705c56fd0e72  vmovaps [rsp+0xB0], xmm11
0000705c56fd0e7b  vmovaps [rsp+0xC0], xmm12
0000705c56fd0e84  vmovaps [rsp+0xD0], xmm13
0000705c56fd0e8d  vmovaps [rsp+0xE0], xmm14
0000705c56fd0e96  sub rsp, 0x30
0000705c56fd0e9a  movaps [rsp], xmm15
0000705c56fd0e9f  movaps [rsp+0x10], xmm10
0000705c56fd0ea5  movaps [rsp+0x20], xmm2
0000705c56fd0eaa  lea rdi, [rsp]
0000705c56fd0eae  mov esi, 0x00
0000705c56fd0eb3  mov rax, 0x5877D3629530
0000705c56fd0ebd  call rax
0000705c56fd0ebf  movaps xmm15, [rsp]
0000705c56fd0ec4  add rsp, 0x30
0000705c56fd0ec8  vmovaps xmm0, [rsp]
0000705c56fd0ecd  vmovaps xmm1, [rsp+0x10]
0000705c56fd0ed3  vmovaps xmm2, [rsp+0x20]
0000705c56fd0ed9  vmovaps xmm3, [rsp+0x30]
0000705c56fd0edf  vmovaps xmm4, [rsp+0x40]
0000705c56fd0ee5  vmovaps xmm5, [rsp+0x50]
0000705c56fd0eeb  vmovaps xmm6, [rsp+0x60]
0000705c56fd0ef1  vmovaps xmm7, [rsp+0x70]
0000705c56fd0ef7  vmovaps xmm8, [rsp+0x80]
0000705c56fd0f00  vmovaps xmm9, [rsp+0x90]
0000705c56fd0f09  vmovaps xmm10, [rsp+0xA0]
0000705c56fd0f12  vmovaps xmm11, [rsp+0xB0]
0000705c56fd0f1b  vmovaps xmm12, [rsp+0xC0]
0000705c56fd0f24  vmovaps xmm13, [rsp+0xD0]
0000705c56fd0f2d  vmovaps xmm14, [rsp+0xE0]
0000705c56fd0f36  add rsp, 0xF0
0000705c56fd0f3d  pop r11
0000705c56fd0f3f  pop r10
0000705c56fd0f41  pop r9
0000705c56fd0f43  pop r8
0000705c56fd0f45  pop rsi
0000705c56fd0f46  pop rdi
0000705c56fd0f47  pop rdx
0000705c56fd0f48  pop rcx
0000705c56fd0f49  pop rax
0000705c56fd0f4a  add rsp, 0x08
0000705c56fd0f4e  jmp 0x0000705C56FCF706
0000705c56fd0f53  sub rsp, 0x08
0000705c56fd0f57  push rax
0000705c56fd0f58  push rcx
0000705c56fd0f59  push rdx
0000705c56fd0f5a  push rdi
0000705c56fd0f5b  push rsi
0000705c56fd0f5c  push r8
0000705c56fd0f5e  push r9
0000705c56fd0f60  push r10
0000705c56fd0f62  push r11
0000705c56fd0f64  sub rsp, 0xF0
0000705c56fd0f6b  vmovaps [rsp], xmm0
0000705c56fd0f70  vmovaps [rsp+0x10], xmm2
0000705c56fd0f76  vmovaps [rsp+0x20], xmm3
0000705c56fd0f7c  vmovaps [rsp+0x30], xmm4
0000705c56fd0f82  vmovaps [rsp+0x40], xmm5
0000705c56fd0f88  vmovaps [rsp+0x50], xmm6
0000705c56fd0f8e  vmovaps [rsp+0x60], xmm7
0000705c56fd0f94  vmovaps [rsp+0x70], xmm8
0000705c56fd0f9a  vmovaps [rsp+0x80], xmm9
0000705c56fd0fa3  vmovaps [rsp+0x90], xmm10
0000705c56fd0fac  vmovaps [rsp+0xA0], xmm11
0000705c56fd0fb5  vmovaps [rsp+0xB0], xmm12
0000705c56fd0fbe  vmovaps [rsp+0xC0], xmm13
0000705c56fd0fc7  vmovaps [rsp+0xD0], xmm14
0000705c56fd0fd0  vmovaps [rsp+0xE0], xmm15
0000705c56fd0fd9  sub rsp, 0x30
0000705c56fd0fdd  movaps [rsp], xmm1
0000705c56fd0fe1  movaps [rsp+0x10], xmm10
0000705c56fd0fe7  movaps [rsp+0x20], xmm12
0000705c56fd0fed  lea rdi, [rsp]
0000705c56fd0ff1  mov esi, 0x00
0000705c56fd0ff6  mov rax, 0x5877D3629530
0000705c56fd1000  call rax
0000705c56fd1002  movaps xmm1, [rsp]
0000705c56fd1006  add rsp, 0x30
0000705c56fd100a  vmovaps xmm0, [rsp]
0000705c56fd100f  vmovaps xmm2, [rsp+0x10]
0000705c56fd1015  vmovaps xmm3, [rsp+0x20]
0000705c56fd101b  vmovaps xmm4, [rsp+0x30]
0000705c56fd1021  vmovaps xmm5, [rsp+0x40]
0000705c56fd1027  vmovaps xmm6, [rsp+0x50]
0000705c56fd102d  vmovaps xmm7, [rsp+0x60]
0000705c56fd1033  vmovaps xmm8, [rsp+0x70]
0000705c56fd1039  vmovaps xmm9, [rsp+0x80]
0000705c56fd1042  vmovaps xmm10, [rsp+0x90]
0000705c56fd104b  vmovaps xmm11, [rsp+0xA0]
0000705c56fd1054  vmovaps xmm12, [rsp+0xB0]
0000705c56fd105d  vmovaps xmm13, [rsp+0xC0]
0000705c56fd1066  vmovaps xmm14, [rsp+0xD0]
0000705c56fd106f  vmovaps xmm15, [rsp+0xE0]
0000705c56fd1078  add rsp, 0xF0
0000705c56fd107f  pop r11
0000705c56fd1081  pop r10
0000705c56fd1083  pop r9
0000705c56fd1085  pop r8
0000705c56fd1087  pop rsi
0000705c56fd1088  pop rdi
0000705c56fd1089  pop rdx
0000705c56fd108a  pop rcx
0000705c56fd108b  pop rax
0000705c56fd108c  add rsp, 0x08
0000705c56fd1090  jmp 0x0000705C56FCF732
0000705c56fd1095  sub rsp, 0x08
0000705c56fd1099  push rax
0000705c56fd109a  push rcx
0000705c56fd109b  push rdx
0000705c56fd109c  push rdi
0000705c56fd109d  push rsi
0000705c56fd109e  push r8
0000705c56fd10a0  push r9
0000705c56fd10a2  push r10
0000705c56fd10a4  push r11
0000705c56fd10a6  sub rsp, 0xF0
0000705c56fd10ad  vmovaps [rsp], xmm0
0000705c56fd10b2  vmovaps [rsp+0x10], xmm1
0000705c56fd10b8  vmovaps [rsp+0x20], xmm2
0000705c56fd10be  vmovaps [rsp+0x30], xmm3
0000705c56fd10c4  vmovaps [rsp+0x40], xmm4
0000705c56fd10ca  vmovaps [rsp+0x50], xmm5
0000705c56fd10d0  vmovaps [rsp+0x60], xmm6
0000705c56fd10d6  vmovaps [rsp+0x70], xmm7
0000705c56fd10dc  vmovaps [rsp+0x80], xmm8
0000705c56fd10e5  vmovaps [rsp+0x90], xmm9
0000705c56fd10ee  vmovaps [rsp+0xA0], xmm10
0000705c56fd10f7  vmovaps [rsp+0xB0], xmm11
0000705c56fd1100  vmovaps [rsp+0xC0], xmm12
0000705c56fd1109  vmovaps [rsp+0xD0], xmm13
0000705c56fd1112  vmovaps [rsp+0xE0], xmm14
0000705c56fd111b  sub rsp, 0x30
0000705c56fd111f  movaps [rsp], xmm15
0000705c56fd1124  movaps [rsp+0x10], xmm10
0000705c56fd112a  movaps [rsp+0x20], xmm12
0000705c56fd1130  lea rdi, [rsp]
0000705c56fd1134  mov esi, 0x00
0000705c56fd1139  mov rax, 0x5877D3629530
0000705c56fd1143  call rax
0000705c56fd1145  movaps xmm15, [rsp]
0000705c56fd114a  add rsp, 0x30
0000705c56fd114e  vmovaps xmm0, [rsp]
0000705c56fd1153  vmovaps xmm1, [rsp+0x10]
0000705c56fd1159  vmovaps xmm2, [rsp+0x20]
0000705c56fd115f  vmovaps xmm3, [rsp+0x30]
0000705c56fd1165  vmovaps xmm4, [rsp+0x40]
0000705c56fd116b  vmovaps xmm5, [rsp+0x50]
0000705c56fd1171  vmovaps xmm6, [rsp+0x60]
0000705c56fd1177  vmovaps xmm7, [rsp+0x70]
0000705c56fd117d  vmovaps xmm8, [rsp+0x80]
0000705c56fd1186  vmovaps xmm9, [rsp+0x90]
0000705c56fd118f  vmovaps xmm10, [rsp+0xA0]
0000705c56fd1198  vmovaps xmm11, [rsp+0xB0]
0000705c56fd11a1  vmovaps xmm12, [rsp+0xC0]
0000705c56fd11aa  vmovaps xmm13, [rsp+0xD0]
0000705c56fd11b3  vmovaps xmm14, [rsp+0xE0]
0000705c56fd11bc  add rsp, 0xF0
0000705c56fd11c3  pop r11
0000705c56fd11c5  pop r10
0000705c56fd11c7  pop r9
0000705c56fd11c9  pop r8
0000705c56fd11cb  pop rsi
0000705c56fd11cc  pop rdi
0000705c56fd11cd  pop rdx
0000705c56fd11ce  pop rcx
0000705c56fd11cf  pop rax
0000705c56fd11d0  add rsp, 0x08
0000705c56fd11d4  jmp 0x0000705C56FCF75E
0000705c56fd11d9  call 0x0000705C56DFF430
0000705c56fd11de  jmp 0x0000705C56FCF7EE
0000705c56fd11e3  call 0x0000705C56DFF430
0000705c56fd11e8  jmp 0x0000705C56FCF801
0000705c56fd11ed  sub rsp, 0x08
0000705c56fd11f1  push rax
0000705c56fd11f2  push rcx
0000705c56fd11f3  push rdx
0000705c56fd11f4  push rdi
0000705c56fd11f5  push rsi
0000705c56fd11f6  push r8
0000705c56fd11f8  push r9
0000705c56fd11fa  push r10
0000705c56fd11fc  push r11
0000705c56fd11fe  sub rsp, 0xF0
0000705c56fd1205  vmovaps [rsp], xmm0
0000705c56fd120a  vmovaps [rsp+0x10], xmm2
0000705c56fd1210  vmovaps [rsp+0x20], xmm3
0000705c56fd1216  vmovaps [rsp+0x30], xmm4
0000705c56fd121c  vmovaps [rsp+0x40], xmm5
0000705c56fd1222  vmovaps [rsp+0x50], xmm6
0000705c56fd1228  vmovaps [rsp+0x60], xmm7
0000705c56fd122e  vmovaps [rsp+0x70], xmm8
0000705c56fd1234  vmovaps [rsp+0x80], xmm9
0000705c56fd123d  vmovaps [rsp+0x90], xmm10
0000705c56fd1246  vmovaps [rsp+0xA0], xmm11
0000705c56fd124f  vmovaps [rsp+0xB0], xmm12
0000705c56fd1258  vmovaps [rsp+0xC0], xmm13
0000705c56fd1261  vmovaps [rsp+0xD0], xmm14
0000705c56fd126a  vmovaps [rsp+0xE0], xmm15
0000705c56fd1273  sub rsp, 0x30
0000705c56fd1277  movaps [rsp], xmm1
0000705c56fd127b  movaps [rsp+0x10], xmm13
0000705c56fd1281  movaps [rsp+0x20], xmm2
0000705c56fd1286  lea rdi, [rsp]
0000705c56fd128a  mov esi, 0x00
0000705c56fd128f  mov rax, 0x5877D3629530
0000705c56fd1299  call rax
0000705c56fd129b  movaps xmm1, [rsp]
0000705c56fd129f  add rsp, 0x30
0000705c56fd12a3  vmovaps xmm0, [rsp]
0000705c56fd12a8  vmovaps xmm2, [rsp+0x10]
0000705c56fd12ae  vmovaps xmm3, [rsp+0x20]
0000705c56fd12b4  vmovaps xmm4, [rsp+0x30]
0000705c56fd12ba  vmovaps xmm5, [rsp+0x40]
0000705c56fd12c0  vmovaps xmm6, [rsp+0x50]
0000705c56fd12c6  vmovaps xmm7, [rsp+0x60]
0000705c56fd12cc  vmovaps xmm8, [rsp+0x70]
0000705c56fd12d2  vmovaps xmm9, [rsp+0x80]
0000705c56fd12db  vmovaps xmm10, [rsp+0x90]
0000705c56fd12e4  vmovaps xmm11, [rsp+0xA0]
0000705c56fd12ed  vmovaps xmm12, [rsp+0xB0]
0000705c56fd12f6  vmovaps xmm13, [rsp+0xC0]
0000705c56fd12ff  vmovaps xmm14, [rsp+0xD0]
0000705c56fd1308  vmovaps xmm15, [rsp+0xE0]
0000705c56fd1311  add rsp, 0xF0
0000705c56fd1318  pop r11
0000705c56fd131a  pop r10
0000705c56fd131c  pop r9
0000705c56fd131e  pop r8
0000705c56fd1320  pop rsi
0000705c56fd1321  pop rdi
0000705c56fd1322  pop rdx
0000705c56fd1323  pop rcx
0000705c56fd1324  pop rax
0000705c56fd1325  add rsp, 0x08
0000705c56fd1329  jmp 0x0000705C56FCF82C
0000705c56fd132e  call 0x0000705C56E0E760
0000705c56fd1333  jmp 0x0000705C56FCF839
0000705c56fd1338  sub rsp, 0x08
0000705c56fd133c  push rax
0000705c56fd133d  push rcx
0000705c56fd133e  push rdx
0000705c56fd133f  push rdi
0000705c56fd1340  push rsi
0000705c56fd1341  push r8
0000705c56fd1343  push r9
0000705c56fd1345  push r10
0000705c56fd1347  push r11
0000705c56fd1349  sub rsp, 0xF0
0000705c56fd1350  vmovaps [rsp], xmm0
0000705c56fd1355  vmovaps [rsp+0x10], xmm1
0000705c56fd135b  vmovaps [rsp+0x20], xmm2
0000705c56fd1361  vmovaps [rsp+0x30], xmm3
0000705c56fd1367  vmovaps [rsp+0x40], xmm4
0000705c56fd136d  vmovaps [rsp+0x50], xmm5
0000705c56fd1373  vmovaps [rsp+0x60], xmm6
0000705c56fd1379  vmovaps [rsp+0x70], xmm7
0000705c56fd137f  vmovaps [rsp+0x80], xmm8
0000705c56fd1388  vmovaps [rsp+0x90], xmm9
0000705c56fd1391  vmovaps [rsp+0xA0], xmm10
0000705c56fd139a  vmovaps [rsp+0xB0], xmm11
0000705c56fd13a3  vmovaps [rsp+0xC0], xmm12
0000705c56fd13ac  vmovaps [rsp+0xD0], xmm14
0000705c56fd13b5  vmovaps [rsp+0xE0], xmm15
0000705c56fd13be  sub rsp, 0x30
0000705c56fd13c2  movaps [rsp], xmm13
0000705c56fd13c7  movaps [rsp+0x10], xmm2
0000705c56fd13cc  movaps [rsp+0x20], xmm1
0000705c56fd13d1  lea rdi, [rsp]
0000705c56fd13d5  mov esi, 0x00
0000705c56fd13da  mov rax, 0x5877D3629530
0000705c56fd13e4  call rax
0000705c56fd13e6  movaps xmm13, [rsp]
0000705c56fd13eb  add rsp, 0x30
0000705c56fd13ef  vmovaps xmm0, [rsp]
0000705c56fd13f4  vmovaps xmm1, [rsp+0x10]
0000705c56fd13fa  vmovaps xmm2, [rsp+0x20]
0000705c56fd1400  vmovaps xmm3, [rsp+0x30]
0000705c56fd1406  vmovaps xmm4, [rsp+0x40]
0000705c56fd140c  vmovaps xmm5, [rsp+0x50]
0000705c56fd1412  vmovaps xmm6, [rsp+0x60]
0000705c56fd1418  vmovaps xmm7, [rsp+0x70]
0000705c56fd141e  vmovaps xmm8, [rsp+0x80]
0000705c56fd1427  vmovaps xmm9, [rsp+0x90]
0000705c56fd1430  vmovaps xmm10, [rsp+0xA0]
0000705c56fd1439  vmovaps xmm11, [rsp+0xB0]
0000705c56fd1442  vmovaps xmm12, [rsp+0xC0]
0000705c56fd144b  vmovaps xmm14, [rsp+0xD0]
0000705c56fd1454  vmovaps xmm15, [rsp+0xE0]
0000705c56fd145d  add rsp, 0xF0
0000705c56fd1464  pop r11
0000705c56fd1466  pop r10
0000705c56fd1468  pop r9
0000705c56fd146a  pop r8
0000705c56fd146c  pop rsi
0000705c56fd146d  pop rdi
0000705c56fd146e  pop rdx
0000705c56fd146f  pop rcx
0000705c56fd1470  pop rax
0000705c56fd1471  add rsp, 0x08
0000705c56fd1475  jmp 0x0000705C56FCF878
0000705c56fd147a  sub rsp, 0x08
0000705c56fd147e  push rax
0000705c56fd147f  push rcx
0000705c56fd1480  push rdx
0000705c56fd1481  push rdi
0000705c56fd1482  push rsi
0000705c56fd1483  push r8
0000705c56fd1485  push r9
0000705c56fd1487  push r10
0000705c56fd1489  push r11
0000705c56fd148b  sub rsp, 0xF0
0000705c56fd1492  vmovaps [rsp], xmm0
0000705c56fd1497  vmovaps [rsp+0x10], xmm2
0000705c56fd149d  vmovaps [rsp+0x20], xmm3
0000705c56fd14a3  vmovaps [rsp+0x30], xmm4
0000705c56fd14a9  vmovaps [rsp+0x40], xmm5
0000705c56fd14af  vmovaps [rsp+0x50], xmm6
0000705c56fd14b5  vmovaps [rsp+0x60], xmm7
0000705c56fd14bb  vmovaps [rsp+0x70], xmm8
0000705c56fd14c1  vmovaps [rsp+0x80], xmm9
0000705c56fd14ca  vmovaps [rsp+0x90], xmm10
0000705c56fd14d3  vmovaps [rsp+0xA0], xmm11
0000705c56fd14dc  vmovaps [rsp+0xB0], xmm12
0000705c56fd14e5  vmovaps [rsp+0xC0], xmm13
0000705c56fd14ee  vmovaps [rsp+0xD0], xmm14
0000705c56fd14f7  vmovaps [rsp+0xE0], xmm15
0000705c56fd1500  sub rsp, 0x30
0000705c56fd1504  movaps [rsp], xmm1
0000705c56fd1508  movaps [rsp+0x10], xmm15
0000705c56fd150e  movaps [rsp+0x20], xmm2
0000705c56fd1513  lea rdi, [rsp]
0000705c56fd1517  mov esi, 0x00
0000705c56fd151c  mov rax, 0x5877D3629530
0000705c56fd1526  call rax
0000705c56fd1528  movaps xmm1, [rsp]
0000705c56fd152c  add rsp, 0x30
0000705c56fd1530  vmovaps xmm0, [rsp]
0000705c56fd1535  vmovaps xmm2, [rsp+0x10]
0000705c56fd153b  vmovaps xmm3, [rsp+0x20]
0000705c56fd1541  vmovaps xmm4, [rsp+0x30]
0000705c56fd1547  vmovaps xmm5, [rsp+0x40]
0000705c56fd154d  vmovaps xmm6, [rsp+0x50]
0000705c56fd1553  vmovaps xmm7, [rsp+0x60]
0000705c56fd1559  vmovaps xmm8, [rsp+0x70]
0000705c56fd155f  vmovaps xmm9, [rsp+0x80]
0000705c56fd1568  vmovaps xmm10, [rsp+0x90]
0000705c56fd1571  vmovaps xmm11, [rsp+0xA0]
0000705c56fd157a  vmovaps xmm12, [rsp+0xB0]
0000705c56fd1583  vmovaps xmm13, [rsp+0xC0]
0000705c56fd158c  vmovaps xmm14, [rsp+0xD0]
0000705c56fd1595  vmovaps xmm15, [rsp+0xE0]
0000705c56fd159e  add rsp, 0xF0
0000705c56fd15a5  pop r11
0000705c56fd15a7  pop r10
0000705c56fd15a9  pop r9
0000705c56fd15ab  pop r8
0000705c56fd15ad  pop rsi
0000705c56fd15ae  pop rdi
0000705c56fd15af  pop rdx
0000705c56fd15b0  pop rcx
0000705c56fd15b1  pop rax
0000705c56fd15b2  add rsp, 0x08
0000705c56fd15b6  jmp 0x0000705C56FCF8AC
0000705c56fd15bb  sub rsp, 0x08
0000705c56fd15bf  push rax
0000705c56fd15c0  push rcx
0000705c56fd15c1  push rdx
0000705c56fd15c2  push rdi
0000705c56fd15c3  push rsi
0000705c56fd15c4  push r8
0000705c56fd15c6  push r9
0000705c56fd15c8  push r10
0000705c56fd15ca  push r11
0000705c56fd15cc  sub rsp, 0xF0
0000705c56fd15d3  vmovaps [rsp], xmm0
0000705c56fd15d8  vmovaps [rsp+0x10], xmm1
0000705c56fd15de  vmovaps [rsp+0x20], xmm2
0000705c56fd15e4  vmovaps [rsp+0x30], xmm3
0000705c56fd15ea  vmovaps [rsp+0x40], xmm4
0000705c56fd15f0  vmovaps [rsp+0x50], xmm5
0000705c56fd15f6  vmovaps [rsp+0x60], xmm6
0000705c56fd15fc  vmovaps [rsp+0x70], xmm7
0000705c56fd1602  vmovaps [rsp+0x80], xmm8
0000705c56fd160b  vmovaps [rsp+0x90], xmm9
0000705c56fd1614  vmovaps [rsp+0xA0], xmm10
0000705c56fd161d  vmovaps [rsp+0xB0], xmm11
0000705c56fd1626  vmovaps [rsp+0xC0], xmm12
0000705c56fd162f  vmovaps [rsp+0xD0], xmm13
0000705c56fd1638  vmovaps [rsp+0xE0], xmm15
0000705c56fd1641  sub rsp, 0x30
0000705c56fd1645  movaps [rsp], xmm14
0000705c56fd164a  movaps [rsp+0x10], xmm2
0000705c56fd164f  movaps [rsp+0x20], xmm15
0000705c56fd1655  lea rdi, [rsp]
0000705c56fd1659  mov esi, 0x00
0000705c56fd165e  mov rax, 0x5877D3629530
0000705c56fd1668  call rax
0000705c56fd166a  movaps xmm14, [rsp]
0000705c56fd166f  add rsp, 0x30
0000705c56fd1673  vmovaps xmm0, [rsp]
0000705c56fd1678  vmovaps xmm1, [rsp+0x10]
0000705c56fd167e  vmovaps xmm2, [rsp+0x20]
0000705c56fd1684  vmovaps xmm3, [rsp+0x30]
0000705c56fd168a  vmovaps xmm4, [rsp+0x40]
0000705c56fd1690  vmovaps xmm5, [rsp+0x50]
0000705c56fd1696  vmovaps xmm6, [rsp+0x60]
0000705c56fd169c  vmovaps xmm7, [rsp+0x70]
0000705c56fd16a2  vmovaps xmm8, [rsp+0x80]
0000705c56fd16ab  vmovaps xmm9, [rsp+0x90]
0000705c56fd16b4  vmovaps xmm10, [rsp+0xA0]
0000705c56fd16bd  vmovaps xmm11, [rsp+0xB0]
0000705c56fd16c6  vmovaps xmm12, [rsp+0xC0]
0000705c56fd16cf  vmovaps xmm13, [rsp+0xD0]
0000705c56fd16d8  vmovaps xmm15, [rsp+0xE0]
0000705c56fd16e1  add rsp, 0xF0
0000705c56fd16e8  pop r11
0000705c56fd16ea  pop r10
0000705c56fd16ec  pop r9
0000705c56fd16ee  pop r8
0000705c56fd16f0  pop rsi
0000705c56fd16f1  pop rdi
0000705c56fd16f2  pop rdx
0000705c56fd16f3  pop rcx
0000705c56fd16f4  pop rax
0000705c56fd16f5  add rsp, 0x08
0000705c56fd16f9  jmp 0x0000705C56FCF8E7
0000705c56fd16fe  sub rsp, 0x08
0000705c56fd1702  push rax
0000705c56fd1703  push rcx
0000705c56fd1704  push rdx
0000705c56fd1705  push rdi
0000705c56fd1706  push rsi
0000705c56fd1707  push r8
0000705c56fd1709  push r9
0000705c56fd170b  push r10
0000705c56fd170d  push r11
0000705c56fd170f  sub rsp, 0xF0
0000705c56fd1716  vmovaps [rsp], xmm0
0000705c56fd171b  vmovaps [rsp+0x10], xmm1
0000705c56fd1721  vmovaps [rsp+0x20], xmm2
0000705c56fd1727  vmovaps [rsp+0x30], xmm3
0000705c56fd172d  vmovaps [rsp+0x40], xmm4
0000705c56fd1733  vmovaps [rsp+0x50], xmm5
0000705c56fd1739  vmovaps [rsp+0x60], xmm6
0000705c56fd173f  vmovaps [rsp+0x70], xmm7
0000705c56fd1745  vmovaps [rsp+0x80], xmm8
0000705c56fd174e  vmovaps [rsp+0x90], xmm9
0000705c56fd1757  vmovaps [rsp+0xA0], xmm10
0000705c56fd1760  vmovaps [rsp+0xB0], xmm11
0000705c56fd1769  vmovaps [rsp+0xC0], xmm12
0000705c56fd1772  vmovaps [rsp+0xD0], xmm13
0000705c56fd177b  vmovaps [rsp+0xE0], xmm14
0000705c56fd1784  sub rsp, 0x30
0000705c56fd1788  movaps [rsp], xmm15
0000705c56fd178d  movaps [rsp+0x10], xmm2
0000705c56fd1792  movaps [rsp+0x20], xmm1
0000705c56fd1797  lea rdi, [rsp]
0000705c56fd179b  mov esi, 0x00
0000705c56fd17a0  mov rax, 0x5877D3629530
0000705c56fd17aa  call rax
0000705c56fd17ac  movaps xmm15, [rsp]
0000705c56fd17b1  add rsp, 0x30
0000705c56fd17b5  vmovaps xmm0, [rsp]
0000705c56fd17ba  vmovaps xmm1, [rsp+0x10]
0000705c56fd17c0  vmovaps xmm2, [rsp+0x20]
0000705c56fd17c6  vmovaps xmm3, [rsp+0x30]
0000705c56fd17cc  vmovaps xmm4, [rsp+0x40]
0000705c56fd17d2  vmovaps xmm5, [rsp+0x50]
0000705c56fd17d8  vmovaps xmm6, [rsp+0x60]
0000705c56fd17de  vmovaps xmm7, [rsp+0x70]
0000705c56fd17e4  vmovaps xmm8, [rsp+0x80]
0000705c56fd17ed  vmovaps xmm9, [rsp+0x90]
0000705c56fd17f6  vmovaps xmm10, [rsp+0xA0]
0000705c56fd17ff  vmovaps xmm11, [rsp+0xB0]
0000705c56fd1808  vmovaps xmm12, [rsp+0xC0]
0000705c56fd1811  vmovaps xmm13, [rsp+0xD0]
0000705c56fd181a  vmovaps xmm14, [rsp+0xE0]
0000705c56fd1823  add rsp, 0xF0
0000705c56fd182a  pop r11
0000705c56fd182c  pop r10
0000705c56fd182e  pop r9
0000705c56fd1830  pop r8
0000705c56fd1832  pop rsi
0000705c56fd1833  pop rdi
0000705c56fd1834  pop rdx
0000705c56fd1835  pop rcx
0000705c56fd1836  pop rax
0000705c56fd1837  add rsp, 0x08
0000705c56fd183b  jmp 0x0000705C56FCF923
0000705c56fd1840  call 0x0000705C56DFF430
0000705c56fd1845  jmp 0x0000705C56FCF930
0000705c56fd184a  sub rsp, 0x08
0000705c56fd184e  push rax
0000705c56fd184f  push rcx
0000705c56fd1850  push rdx
0000705c56fd1851  push rdi
0000705c56fd1852  push rsi
0000705c56fd1853  push r8
0000705c56fd1855  push r9
0000705c56fd1857  push r10
0000705c56fd1859  push r11
0000705c56fd185b  sub rsp, 0xF0
0000705c56fd1862  vmovaps [rsp], xmm0
0000705c56fd1867  vmovaps [rsp+0x10], xmm1
0000705c56fd186d  vmovaps [rsp+0x20], xmm3
0000705c56fd1873  vmovaps [rsp+0x30], xmm4
0000705c56fd1879  vmovaps [rsp+0x40], xmm5
0000705c56fd187f  vmovaps [rsp+0x50], xmm6
0000705c56fd1885  vmovaps [rsp+0x60], xmm7
0000705c56fd188b  vmovaps [rsp+0x70], xmm8
0000705c56fd1891  vmovaps [rsp+0x80], xmm9
0000705c56fd189a  vmovaps [rsp+0x90], xmm10
0000705c56fd18a3  vmovaps [rsp+0xA0], xmm11
0000705c56fd18ac  vmovaps [rsp+0xB0], xmm12
0000705c56fd18b5  vmovaps [rsp+0xC0], xmm13
0000705c56fd18be  vmovaps [rsp+0xD0], xmm14
0000705c56fd18c7  vmovaps [rsp+0xE0], xmm15
0000705c56fd18d0  sub rsp, 0x30
0000705c56fd18d4  movaps [rsp], xmm2
0000705c56fd18d8  movaps [rsp+0x10], xmm1
0000705c56fd18dd  movaps [rsp+0x20], xmm14
0000705c56fd18e3  lea rdi, [rsp]
0000705c56fd18e7  mov esi, 0x00
0000705c56fd18ec  mov rax, 0x5877D3629530
0000705c56fd18f6  call rax
0000705c56fd18f8  movaps xmm2, [rsp]
0000705c56fd18fc  add rsp, 0x30
0000705c56fd1900  vmovaps xmm0, [rsp]
0000705c56fd1905  vmovaps xmm1, [rsp+0x10]
0000705c56fd190b  vmovaps xmm3, [rsp+0x20]
0000705c56fd1911  vmovaps xmm4, [rsp+0x30]
0000705c56fd1917  vmovaps xmm5, [rsp+0x40]
0000705c56fd191d  vmovaps xmm6, [rsp+0x50]
0000705c56fd1923  vmovaps xmm7, [rsp+0x60]
0000705c56fd1929  vmovaps xmm8, [rsp+0x70]
0000705c56fd192f  vmovaps xmm9, [rsp+0x80]
0000705c56fd1938  vmovaps xmm10, [rsp+0x90]
0000705c56fd1941  vmovaps xmm11, [rsp+0xA0]
0000705c56fd194a  vmovaps xmm12, [rsp+0xB0]
0000705c56fd1953  vmovaps xmm13, [rsp+0xC0]
0000705c56fd195c  vmovaps xmm14, [rsp+0xD0]
0000705c56fd1965  vmovaps xmm15, [rsp+0xE0]
0000705c56fd196e  add rsp, 0xF0
0000705c56fd1975  pop r11
0000705c56fd1977  pop r10
0000705c56fd1979  pop r9
0000705c56fd197b  pop r8
0000705c56fd197d  pop rsi
0000705c56fd197e  pop rdi
0000705c56fd197f  pop rdx
0000705c56fd1980  pop rcx
0000705c56fd1981  pop rax
0000705c56fd1982  add rsp, 0x08
0000705c56fd1986  jmp 0x0000705C56FCF96D
0000705c56fd198b  sub rsp, 0x08
0000705c56fd198f  push rax
0000705c56fd1990  push rcx
0000705c56fd1991  push rdx
0000705c56fd1992  push rdi
0000705c56fd1993  push rsi
0000705c56fd1994  push r8
0000705c56fd1996  push r9
0000705c56fd1998  push r10
0000705c56fd199a  push r11
0000705c56fd199c  sub rsp, 0xF0
0000705c56fd19a3  vmovaps [rsp], xmm0
0000705c56fd19a8  vmovaps [rsp+0x10], xmm1
0000705c56fd19ae  vmovaps [rsp+0x20], xmm2
0000705c56fd19b4  vmovaps [rsp+0x30], xmm3
0000705c56fd19ba  vmovaps [rsp+0x40], xmm4
0000705c56fd19c0  vmovaps [rsp+0x50], xmm5
0000705c56fd19c6  vmovaps [rsp+0x60], xmm6
0000705c56fd19cc  vmovaps [rsp+0x70], xmm7
0000705c56fd19d2  vmovaps [rsp+0x80], xmm8
0000705c56fd19db  vmovaps [rsp+0x90], xmm9
0000705c56fd19e4  vmovaps [rsp+0xA0], xmm10
0000705c56fd19ed  vmovaps [rsp+0xB0], xmm11
0000705c56fd19f6  vmovaps [rsp+0xC0], xmm12
0000705c56fd19ff  vmovaps [rsp+0xD0], xmm13
0000705c56fd1a08  vmovaps [rsp+0xE0], xmm14
0000705c56fd1a11  sub rsp, 0x30
0000705c56fd1a15  movaps [rsp], xmm15
0000705c56fd1a1a  movaps [rsp+0x10], xmm14
0000705c56fd1a20  movaps [rsp+0x20], xmm1
0000705c56fd1a25  lea rdi, [rsp]
0000705c56fd1a29  mov esi, 0x00
0000705c56fd1a2e  mov rax, 0x5877D3629530
0000705c56fd1a38  call rax
0000705c56fd1a3a  movaps xmm15, [rsp]
0000705c56fd1a3f  add rsp, 0x30
0000705c56fd1a43  vmovaps xmm0, [rsp]
0000705c56fd1a48  vmovaps xmm1, [rsp+0x10]
0000705c56fd1a4e  vmovaps xmm2, [rsp+0x20]
0000705c56fd1a54  vmovaps xmm3, [rsp+0x30]
0000705c56fd1a5a  vmovaps xmm4, [rsp+0x40]
0000705c56fd1a60  vmovaps xmm5, [rsp+0x50]
0000705c56fd1a66  vmovaps xmm6, [rsp+0x60]
0000705c56fd1a6c  vmovaps xmm7, [rsp+0x70]
0000705c56fd1a72  vmovaps xmm8, [rsp+0x80]
0000705c56fd1a7b  vmovaps xmm9, [rsp+0x90]
0000705c56fd1a84  vmovaps xmm10, [rsp+0xA0]
0000705c56fd1a8d  vmovaps xmm11, [rsp+0xB0]
0000705c56fd1a96  vmovaps xmm12, [rsp+0xC0]
0000705c56fd1a9f  vmovaps xmm13, [rsp+0xD0]
0000705c56fd1aa8  vmovaps xmm14, [rsp+0xE0]
0000705c56fd1ab1  add rsp, 0xF0
0000705c56fd1ab8  pop r11
0000705c56fd1aba  pop r10
0000705c56fd1abc  pop r9
0000705c56fd1abe  pop r8
0000705c56fd1ac0  pop rsi
0000705c56fd1ac1  pop rdi
0000705c56fd1ac2  pop rdx
0000705c56fd1ac3  pop rcx
0000705c56fd1ac4  pop rax
0000705c56fd1ac5  add rsp, 0x08
0000705c56fd1ac9  jmp 0x0000705C56FCF9E7
0000705c56fd1ace  call 0x0000705C56DFF430
0000705c56fd1ad3  jmp 0x0000705C56FCF9F4
0000705c56fd1ad8  sub rsp, 0x08
0000705c56fd1adc  push rax
0000705c56fd1add  push rcx
0000705c56fd1ade  push rdx
0000705c56fd1adf  push rdi
0000705c56fd1ae0  push rsi
0000705c56fd1ae1  push r8
0000705c56fd1ae3  push r9
0000705c56fd1ae5  push r10
0000705c56fd1ae7  push r11
0000705c56fd1ae9  sub rsp, 0xF0
0000705c56fd1af0  vmovaps [rsp], xmm0
0000705c56fd1af5  vmovaps [rsp+0x10], xmm1
0000705c56fd1afb  vmovaps [rsp+0x20], xmm2
0000705c56fd1b01  vmovaps [rsp+0x30], xmm3
0000705c56fd1b07  vmovaps [rsp+0x40], xmm4
0000705c56fd1b0d  vmovaps [rsp+0x50], xmm5
0000705c56fd1b13  vmovaps [rsp+0x60], xmm6
0000705c56fd1b19  vmovaps [rsp+0x70], xmm7
0000705c56fd1b1f  vmovaps [rsp+0x80], xmm8
0000705c56fd1b28  vmovaps [rsp+0x90], xmm9
0000705c56fd1b31  vmovaps [rsp+0xA0], xmm10
0000705c56fd1b3a  vmovaps [rsp+0xB0], xmm11
0000705c56fd1b43  vmovaps [rsp+0xC0], xmm12
0000705c56fd1b4c  vmovaps [rsp+0xD0], xmm13
0000705c56fd1b55  vmovaps [rsp+0xE0], xmm15
0000705c56fd1b5e  sub rsp, 0x30
0000705c56fd1b62  movaps [rsp], xmm14
0000705c56fd1b67  movaps [rsp+0x10], xmm13
0000705c56fd1b6d  movaps [rsp+0x20], xmm1
0000705c56fd1b72  lea rdi, [rsp]
0000705c56fd1b76  mov esi, 0x00
0000705c56fd1b7b  mov rax, 0x5877D3629530
0000705c56fd1b85  call rax
0000705c56fd1b87  movaps xmm14, [rsp]
0000705c56fd1b8c  add rsp, 0x30
0000705c56fd1b90  vmovaps xmm0, [rsp]
0000705c56fd1b95  vmovaps xmm1, [rsp+0x10]
0000705c56fd1b9b  vmovaps xmm2, [rsp+0x20]
0000705c56fd1ba1  vmovaps xmm3, [rsp+0x30]
0000705c56fd1ba7  vmovaps xmm4, [rsp+0x40]
0000705c56fd1bad  vmovaps xmm5, [rsp+0x50]
0000705c56fd1bb3  vmovaps xmm6, [rsp+0x60]
0000705c56fd1bb9  vmovaps xmm7, [rsp+0x70]
0000705c56fd1bbf  vmovaps xmm8, [rsp+0x80]
0000705c56fd1bc8  vmovaps xmm9, [rsp+0x90]
0000705c56fd1bd1  vmovaps xmm10, [rsp+0xA0]
0000705c56fd1bda  vmovaps xmm11, [rsp+0xB0]
0000705c56fd1be3  vmovaps xmm12, [rsp+0xC0]
0000705c56fd1bec  vmovaps xmm13, [rsp+0xD0]
0000705c56fd1bf5  vmovaps xmm15, [rsp+0xE0]
0000705c56fd1bfe  add rsp, 0xF0
0000705c56fd1c05  pop r11
0000705c56fd1c07  pop r10
0000705c56fd1c09  pop r9
0000705c56fd1c0b  pop r8
0000705c56fd1c0d  pop rsi
0000705c56fd1c0e  pop rdi
0000705c56fd1c0f  pop rdx
0000705c56fd1c10  pop rcx
0000705c56fd1c11  pop rax
0000705c56fd1c12  add rsp, 0x08
0000705c56fd1c16  jmp 0x0000705C56FCFAAF
0000705c56fd1c1b  sub rsp, 0x08
0000705c56fd1c1f  push rax
0000705c56fd1c20  push rcx
0000705c56fd1c21  push rdx
0000705c56fd1c22  push rdi
0000705c56fd1c23  push rsi
0000705c56fd1c24  push r8
0000705c56fd1c26  push r9
0000705c56fd1c28  push r10
0000705c56fd1c2a  push r11
0000705c56fd1c2c  sub rsp, 0xF0
0000705c56fd1c33  vmovaps [rsp], xmm0
0000705c56fd1c38  vmovaps [rsp+0x10], xmm1
0000705c56fd1c3e  vmovaps [rsp+0x20], xmm2
0000705c56fd1c44  vmovaps [rsp+0x30], xmm3
0000705c56fd1c4a  vmovaps [rsp+0x40], xmm4
0000705c56fd1c50  vmovaps [rsp+0x50], xmm5
0000705c56fd1c56  vmovaps [rsp+0x60], xmm6
0000705c56fd1c5c  vmovaps [rsp+0x70], xmm7
0000705c56fd1c62  vmovaps [rsp+0x80], xmm8
0000705c56fd1c6b  vmovaps [rsp+0x90], xmm9
0000705c56fd1c74  vmovaps [rsp+0xA0], xmm10
0000705c56fd1c7d  vmovaps [rsp+0xB0], xmm11
0000705c56fd1c86  vmovaps [rsp+0xC0], xmm12
0000705c56fd1c8f  vmovaps [rsp+0xD0], xmm13
0000705c56fd1c98  vmovaps [rsp+0xE0], xmm14
0000705c56fd1ca1  sub rsp, 0x30
0000705c56fd1ca5  movaps [rsp], xmm15
0000705c56fd1caa  movaps [rsp+0x10], xmm13
0000705c56fd1cb0  movaps [rsp+0x20], xmm1
0000705c56fd1cb5  lea rdi, [rsp]
0000705c56fd1cb9  mov esi, 0x00
0000705c56fd1cbe  mov rax, 0x5877D3629530
0000705c56fd1cc8  call rax
0000705c56fd1cca  movaps xmm15, [rsp]
0000705c56fd1ccf  add rsp, 0x30
0000705c56fd1cd3  vmovaps xmm0, [rsp]
0000705c56fd1cd8  vmovaps xmm1, [rsp+0x10]
0000705c56fd1cde  vmovaps xmm2, [rsp+0x20]
0000705c56fd1ce4  vmovaps xmm3, [rsp+0x30]
0000705c56fd1cea  vmovaps xmm4, [rsp+0x40]
0000705c56fd1cf0  vmovaps xmm5, [rsp+0x50]
0000705c56fd1cf6  vmovaps xmm6, [rsp+0x60]
0000705c56fd1cfc  vmovaps xmm7, [rsp+0x70]
0000705c56fd1d02  vmovaps xmm8, [rsp+0x80]
0000705c56fd1d0b  vmovaps xmm9, [rsp+0x90]
0000705c56fd1d14  vmovaps xmm10, [rsp+0xA0]
0000705c56fd1d1d  vmovaps xmm11, [rsp+0xB0]
0000705c56fd1d26  vmovaps xmm12, [rsp+0xC0]
0000705c56fd1d2f  vmovaps xmm13, [rsp+0xD0]
0000705c56fd1d38  vmovaps xmm14, [rsp+0xE0]
0000705c56fd1d41  add rsp, 0xF0
0000705c56fd1d48  pop r11
0000705c56fd1d4a  pop r10
0000705c56fd1d4c  pop r9
0000705c56fd1d4e  pop r8
0000705c56fd1d50  pop rsi
0000705c56fd1d51  pop rdi
0000705c56fd1d52  pop rdx
0000705c56fd1d53  pop rcx
0000705c56fd1d54  pop rax
0000705c56fd1d55  add rsp, 0x08
0000705c56fd1d59  jmp 0x0000705C56FCFAEB
0000705c56fd1d5e  call 0x0000705C56DFF430
0000705c56fd1d63  jmp 0x0000705C56FCFAF8
0000705c56fd1d68  sub rsp, 0x08
0000705c56fd1d6c  push rax
0000705c56fd1d6d  push rcx
0000705c56fd1d6e  push rdx
0000705c56fd1d6f  push rdi
0000705c56fd1d70  push rsi
0000705c56fd1d71  push r8
0000705c56fd1d73  push r9
0000705c56fd1d75  push r10
0000705c56fd1d77  push r11
0000705c56fd1d79  sub rsp, 0xF0
0000705c56fd1d80  vmovaps [rsp], xmm0
0000705c56fd1d85  vmovaps [rsp+0x10], xmm1
0000705c56fd1d8b  vmovaps [rsp+0x20], xmm2
0000705c56fd1d91  vmovaps [rsp+0x30], xmm3
0000705c56fd1d97  vmovaps [rsp+0x40], xmm4
0000705c56fd1d9d  vmovaps [rsp+0x50], xmm5
0000705c56fd1da3  vmovaps [rsp+0x60], xmm6
0000705c56fd1da9  vmovaps [rsp+0x70], xmm7
0000705c56fd1daf  vmovaps [rsp+0x80], xmm8
0000705c56fd1db8  vmovaps [rsp+0x90], xmm9
0000705c56fd1dc1  vmovaps [rsp+0xA0], xmm10
0000705c56fd1dca  vmovaps [rsp+0xB0], xmm11
0000705c56fd1dd3  vmovaps [rsp+0xC0], xmm12
0000705c56fd1ddc  vmovaps [rsp+0xD0], xmm13
0000705c56fd1de5  vmovaps [rsp+0xE0], xmm15
0000705c56fd1dee  sub rsp, 0x30
0000705c56fd1df2  movaps [rsp], xmm14
0000705c56fd1df7  movaps [rsp+0x10], xmm13
0000705c56fd1dfd  movaps [rsp+0x20], xmm2
0000705c56fd1e02  lea rdi, [rsp]
0000705c56fd1e06  mov esi, 0x00
0000705c56fd1e0b  mov rax, 0x5877D3629530
0000705c56fd1e15  call rax
0000705c56fd1e17  movaps xmm14, [rsp]
0000705c56fd1e1c  add rsp, 0x30
0000705c56fd1e20  vmovaps xmm0, [rsp]
0000705c56fd1e25  vmovaps xmm1, [rsp+0x10]
0000705c56fd1e2b  vmovaps xmm2, [rsp+0x20]
0000705c56fd1e31  vmovaps xmm3, [rsp+0x30]
0000705c56fd1e37  vmovaps xmm4, [rsp+0x40]
0000705c56fd1e3d  vmovaps xmm5, [rsp+0x50]
0000705c56fd1e43  vmovaps xmm6, [rsp+0x60]
0000705c56fd1e49  vmovaps xmm7, [rsp+0x70]
0000705c56fd1e4f  vmovaps xmm8, [rsp+0x80]
0000705c56fd1e58  vmovaps xmm9, [rsp+0x90]
0000705c56fd1e61  vmovaps xmm10, [rsp+0xA0]
0000705c56fd1e6a  vmovaps xmm11, [rsp+0xB0]
0000705c56fd1e73  vmovaps xmm12, [rsp+0xC0]
0000705c56fd1e7c  vmovaps xmm13, [rsp+0xD0]
0000705c56fd1e85  vmovaps xmm15, [rsp+0xE0]
0000705c56fd1e8e  add rsp, 0xF0
0000705c56fd1e95  pop r11
0000705c56fd1e97  pop r10
0000705c56fd1e99  pop r9
0000705c56fd1e9b  pop r8
0000705c56fd1e9d  pop rsi
0000705c56fd1e9e  pop rdi
0000705c56fd1e9f  pop rdx
0000705c56fd1ea0  pop rcx
0000705c56fd1ea1  pop rax
0000705c56fd1ea2  add rsp, 0x08
0000705c56fd1ea6  jmp 0x0000705C56FCFB24
0000705c56fd1eab  sub rsp, 0x08
0000705c56fd1eaf  push rax
0000705c56fd1eb0  push rcx
0000705c56fd1eb1  push rdx
0000705c56fd1eb2  push rdi
0000705c56fd1eb3  push rsi
0000705c56fd1eb4  push r8
0000705c56fd1eb6  push r9
0000705c56fd1eb8  push r10
0000705c56fd1eba  push r11
0000705c56fd1ebc  sub rsp, 0xF0
0000705c56fd1ec3  vmovaps [rsp], xmm0
0000705c56fd1ec8  vmovaps [rsp+0x10], xmm2
0000705c56fd1ece  vmovaps [rsp+0x20], xmm3
0000705c56fd1ed4  vmovaps [rsp+0x30], xmm4
0000705c56fd1eda  vmovaps [rsp+0x40], xmm5
0000705c56fd1ee0  vmovaps [rsp+0x50], xmm6
0000705c56fd1ee6  vmovaps [rsp+0x60], xmm7
0000705c56fd1eec  vmovaps [rsp+0x70], xmm8
0000705c56fd1ef2  vmovaps [rsp+0x80], xmm9
0000705c56fd1efb  vmovaps [rsp+0x90], xmm10
0000705c56fd1f04  vmovaps [rsp+0xA0], xmm11
0000705c56fd1f0d  vmovaps [rsp+0xB0], xmm12
0000705c56fd1f16  vmovaps [rsp+0xC0], xmm13
0000705c56fd1f1f  vmovaps [rsp+0xD0], xmm14
0000705c56fd1f28  vmovaps [rsp+0xE0], xmm15
0000705c56fd1f31  sub rsp, 0x30
0000705c56fd1f35  movaps [rsp], xmm1
0000705c56fd1f39  movaps [rsp+0x10], xmm13
0000705c56fd1f3f  movaps [rsp+0x20], xmm2
0000705c56fd1f44  lea rdi, [rsp]
0000705c56fd1f48  mov esi, 0x00
0000705c56fd1f4d  mov rax, 0x5877D3629530
0000705c56fd1f57  call rax
0000705c56fd1f59  movaps xmm1, [rsp]
0000705c56fd1f5d  add rsp, 0x30
0000705c56fd1f61  vmovaps xmm0, [rsp]
0000705c56fd1f66  vmovaps xmm2, [rsp+0x10]
0000705c56fd1f6c  vmovaps xmm3, [rsp+0x20]
0000705c56fd1f72  vmovaps xmm4, [rsp+0x30]
0000705c56fd1f78  vmovaps xmm5, [rsp+0x40]
0000705c56fd1f7e  vmovaps xmm6, [rsp+0x50]
0000705c56fd1f84  vmovaps xmm7, [rsp+0x60]
0000705c56fd1f8a  vmovaps xmm8, [rsp+0x70]
0000705c56fd1f90  vmovaps xmm9, [rsp+0x80]
0000705c56fd1f99  vmovaps xmm10, [rsp+0x90]
0000705c56fd1fa2  vmovaps xmm11, [rsp+0xA0]
0000705c56fd1fab  vmovaps xmm12, [rsp+0xB0]
0000705c56fd1fb4  vmovaps xmm13, [rsp+0xC0]
0000705c56fd1fbd  vmovaps xmm14, [rsp+0xD0]
0000705c56fd1fc6  vmovaps xmm15, [rsp+0xE0]
0000705c56fd1fcf  add rsp, 0xF0
0000705c56fd1fd6  pop r11
0000705c56fd1fd8  pop r10
0000705c56fd1fda  pop r9
0000705c56fd1fdc  pop r8
0000705c56fd1fde  pop rsi
0000705c56fd1fdf  pop rdi
0000705c56fd1fe0  pop rdx
0000705c56fd1fe1  pop rcx
0000705c56fd1fe2  pop rax
0000705c56fd1fe3  add rsp, 0x08
0000705c56fd1fe7  jmp 0x0000705C56FCFB52
0000705c56fd1fec  sub rsp, 0x08
0000705c56fd1ff0  push rax
0000705c56fd1ff1  push rcx
0000705c56fd1ff2  push rdx
0000705c56fd1ff3  push rdi
0000705c56fd1ff4  push rsi
0000705c56fd1ff5  push r8
0000705c56fd1ff7  push r9
0000705c56fd1ff9  push r10
0000705c56fd1ffb  push r11
0000705c56fd1ffd  sub rsp, 0xF0
0000705c56fd2004  vmovaps [rsp], xmm0
0000705c56fd2009  vmovaps [rsp+0x10], xmm1
0000705c56fd200f  vmovaps [rsp+0x20], xmm3
0000705c56fd2015  vmovaps [rsp+0x30], xmm4
0000705c56fd201b  vmovaps [rsp+0x40], xmm5
0000705c56fd2021  vmovaps [rsp+0x50], xmm6
0000705c56fd2027  vmovaps [rsp+0x60], xmm7
0000705c56fd202d  vmovaps [rsp+0x70], xmm8
0000705c56fd2033  vmovaps [rsp+0x80], xmm9
0000705c56fd203c  vmovaps [rsp+0x90], xmm10
0000705c56fd2045  vmovaps [rsp+0xA0], xmm11
0000705c56fd204e  vmovaps [rsp+0xB0], xmm12
0000705c56fd2057  vmovaps [rsp+0xC0], xmm13
0000705c56fd2060  vmovaps [rsp+0xD0], xmm14
0000705c56fd2069  vmovaps [rsp+0xE0], xmm15
0000705c56fd2072  sub rsp, 0x30
0000705c56fd2076  movaps [rsp], xmm2
0000705c56fd207a  movaps [rsp+0x10], xmm1
0000705c56fd207f  movaps [rsp+0x20], xmm13
0000705c56fd2085  lea rdi, [rsp]
0000705c56fd2089  mov esi, 0x00
0000705c56fd208e  mov rax, 0x5877D3629530
0000705c56fd2098  call rax
0000705c56fd209a  movaps xmm2, [rsp]
0000705c56fd209e  add rsp, 0x30
0000705c56fd20a2  vmovaps xmm0, [rsp]
0000705c56fd20a7  vmovaps xmm1, [rsp+0x10]
0000705c56fd20ad  vmovaps xmm3, [rsp+0x20]
0000705c56fd20b3  vmovaps xmm4, [rsp+0x30]
0000705c56fd20b9  vmovaps xmm5, [rsp+0x40]
0000705c56fd20bf  vmovaps xmm6, [rsp+0x50]
0000705c56fd20c5  vmovaps xmm7, [rsp+0x60]
0000705c56fd20cb  vmovaps xmm8, [rsp+0x70]
0000705c56fd20d1  vmovaps xmm9, [rsp+0x80]
0000705c56fd20da  vmovaps xmm10, [rsp+0x90]
0000705c56fd20e3  vmovaps xmm11, [rsp+0xA0]
0000705c56fd20ec  vmovaps xmm12, [rsp+0xB0]
0000705c56fd20f5  vmovaps xmm13, [rsp+0xC0]
0000705c56fd20fe  vmovaps xmm14, [rsp+0xD0]
0000705c56fd2107  vmovaps xmm15, [rsp+0xE0]
0000705c56fd2110  add rsp, 0xF0
0000705c56fd2117  pop r11
0000705c56fd2119  pop r10
0000705c56fd211b  pop r9
0000705c56fd211d  pop r8
0000705c56fd211f  pop rsi
0000705c56fd2120  pop rdi
0000705c56fd2121  pop rdx
0000705c56fd2122  pop rcx
0000705c56fd2123  pop rax
0000705c56fd2124  add rsp, 0x08
0000705c56fd2128  jmp 0x0000705C56FCFBAB
0000705c56fd212d  call 0x0000705C56DFF430
0000705c56fd2132  jmp 0x0000705C56FCFBB8
0000705c56fd2137  sub rsp, 0x08
0000705c56fd213b  push rax
0000705c56fd213c  push rcx
0000705c56fd213d  push rdx
0000705c56fd213e  push rdi
0000705c56fd213f  push rsi
0000705c56fd2140  push r8
0000705c56fd2142  push r9
0000705c56fd2144  push r10
0000705c56fd2146  push r11
0000705c56fd2148  sub rsp, 0xF0
0000705c56fd214f  vmovaps [rsp], xmm0
0000705c56fd2154  vmovaps [rsp+0x10], xmm1
0000705c56fd215a  vmovaps [rsp+0x20], xmm2
0000705c56fd2160  vmovaps [rsp+0x30], xmm3
0000705c56fd2166  vmovaps [rsp+0x40], xmm4
0000705c56fd216c  vmovaps [rsp+0x50], xmm5
0000705c56fd2172  vmovaps [rsp+0x60], xmm6
0000705c56fd2178  vmovaps [rsp+0x70], xmm7
0000705c56fd217e  vmovaps [rsp+0x80], xmm8
0000705c56fd2187  vmovaps [rsp+0x90], xmm9
0000705c56fd2190  vmovaps [rsp+0xA0], xmm10
0000705c56fd2199  vmovaps [rsp+0xB0], xmm11
0000705c56fd21a2  vmovaps [rsp+0xC0], xmm12
0000705c56fd21ab  vmovaps [rsp+0xD0], xmm13
0000705c56fd21b4  vmovaps [rsp+0xE0], xmm14
0000705c56fd21bd  sub rsp, 0x30
0000705c56fd21c1  movaps [rsp], xmm15
0000705c56fd21c6  movaps [rsp+0x10], xmm13
0000705c56fd21cc  movaps [rsp+0x20], xmm1
0000705c56fd21d1  lea rdi, [rsp]
0000705c56fd21d5  mov esi, 0x00
0000705c56fd21da  mov rax, 0x5877D3629530
0000705c56fd21e4  call rax
0000705c56fd21e6  movaps xmm15, [rsp]
0000705c56fd21eb  add rsp, 0x30
0000705c56fd21ef  vmovaps xmm0, [rsp]
0000705c56fd21f4  vmovaps xmm1, [rsp+0x10]
0000705c56fd21fa  vmovaps xmm2, [rsp+0x20]
0000705c56fd2200  vmovaps xmm3, [rsp+0x30]
0000705c56fd2206  vmovaps xmm4, [rsp+0x40]
0000705c56fd220c  vmovaps xmm5, [rsp+0x50]
0000705c56fd2212  vmovaps xmm6, [rsp+0x60]
0000705c56fd2218  vmovaps xmm7, [rsp+0x70]
0000705c56fd221e  vmovaps xmm8, [rsp+0x80]
0000705c56fd2227  vmovaps xmm9, [rsp+0x90]
0000705c56fd2230  vmovaps xmm10, [rsp+0xA0]
0000705c56fd2239  vmovaps xmm11, [rsp+0xB0]
0000705c56fd2242  vmovaps xmm12, [rsp+0xC0]
0000705c56fd224b  vmovaps xmm13, [rsp+0xD0]
0000705c56fd2254  vmovaps xmm14, [rsp+0xE0]
0000705c56fd225d  add rsp, 0xF0
0000705c56fd2264  pop r11
0000705c56fd2266  pop r10
0000705c56fd2268  pop r9
0000705c56fd226a  pop r8
0000705c56fd226c  pop rsi
0000705c56fd226d  pop rdi
0000705c56fd226e  pop rdx
0000705c56fd226f  pop rcx
0000705c56fd2270  pop rax
0000705c56fd2271  add rsp, 0x08
0000705c56fd2275  jmp 0x0000705C56FCFBF7
0000705c56fd227a  sub rsp, 0x08
0000705c56fd227e  push rax
0000705c56fd227f  push rcx
0000705c56fd2280  push rdx
0000705c56fd2281  push rdi
0000705c56fd2282  push rsi
0000705c56fd2283  push r8
0000705c56fd2285  push r9
0000705c56fd2287  push r10
0000705c56fd2289  push r11
0000705c56fd228b  sub rsp, 0xF0
0000705c56fd2292  vmovaps [rsp], xmm0
0000705c56fd2297  vmovaps [rsp+0x10], xmm1
0000705c56fd229d  vmovaps [rsp+0x20], xmm2
0000705c56fd22a3  vmovaps [rsp+0x30], xmm3
0000705c56fd22a9  vmovaps [rsp+0x40], xmm4
0000705c56fd22af  vmovaps [rsp+0x50], xmm5
0000705c56fd22b5  vmovaps [rsp+0x60], xmm6
0000705c56fd22bb  vmovaps [rsp+0x70], xmm7
0000705c56fd22c1  vmovaps [rsp+0x80], xmm8
0000705c56fd22ca  vmovaps [rsp+0x90], xmm9
0000705c56fd22d3  vmovaps [rsp+0xA0], xmm10
0000705c56fd22dc  vmovaps [rsp+0xB0], xmm11
0000705c56fd22e5  vmovaps [rsp+0xC0], xmm12
0000705c56fd22ee  vmovaps [rsp+0xD0], xmm13
0000705c56fd22f7  vmovaps [rsp+0xE0], xmm15
0000705c56fd2300  sub rsp, 0x30
0000705c56fd2304  movaps [rsp], xmm14
0000705c56fd2309  movaps [rsp+0x10], xmm11
0000705c56fd230f  movaps [rsp+0x20], xmm1
0000705c56fd2314  lea rdi, [rsp]
0000705c56fd2318  mov esi, 0x00
0000705c56fd231d  mov rax, 0x5877D3629530
0000705c56fd2327  call rax
0000705c56fd2329  movaps xmm14, [rsp]
0000705c56fd232e  add rsp, 0x30
0000705c56fd2332  vmovaps xmm0, [rsp]
0000705c56fd2337  vmovaps xmm1, [rsp+0x10]
0000705c56fd233d  vmovaps xmm2, [rsp+0x20]
0000705c56fd2343  vmovaps xmm3, [rsp+0x30]
0000705c56fd2349  vmovaps xmm4, [rsp+0x40]
0000705c56fd234f  vmovaps xmm5, [rsp+0x50]
0000705c56fd2355  vmovaps xmm6, [rsp+0x60]
0000705c56fd235b  vmovaps xmm7, [rsp+0x70]
0000705c56fd2361  vmovaps xmm8, [rsp+0x80]
0000705c56fd236a  vmovaps xmm9, [rsp+0x90]
0000705c56fd2373  vmovaps xmm10, [rsp+0xA0]
0000705c56fd237c  vmovaps xmm11, [rsp+0xB0]
0000705c56fd2385  vmovaps xmm12, [rsp+0xC0]
0000705c56fd238e  vmovaps xmm13, [rsp+0xD0]
0000705c56fd2397  vmovaps xmm15, [rsp+0xE0]
0000705c56fd23a0  add rsp, 0xF0
0000705c56fd23a7  pop r11
0000705c56fd23a9  pop r10
0000705c56fd23ab  pop r9
0000705c56fd23ad  pop r8
0000705c56fd23af  pop rsi
0000705c56fd23b0  pop rdi
0000705c56fd23b1  pop rdx
0000705c56fd23b2  pop rcx
0000705c56fd23b3  pop rax
0000705c56fd23b4  add rsp, 0x08
0000705c56fd23b8  jmp 0x0000705C56FCFC21
0000705c56fd23bd  sub rsp, 0x08
0000705c56fd23c1  push rax
0000705c56fd23c2  push rcx
0000705c56fd23c3  push rdx
0000705c56fd23c4  push rdi
0000705c56fd23c5  push rsi
0000705c56fd23c6  push r8
0000705c56fd23c8  push r9
0000705c56fd23ca  push r10
0000705c56fd23cc  push r11
0000705c56fd23ce  sub rsp, 0xF0
0000705c56fd23d5  vmovaps [rsp], xmm0
0000705c56fd23da  vmovaps [rsp+0x10], xmm1
0000705c56fd23e0  vmovaps [rsp+0x20], xmm2
0000705c56fd23e6  vmovaps [rsp+0x30], xmm3
0000705c56fd23ec  vmovaps [rsp+0x40], xmm4
0000705c56fd23f2  vmovaps [rsp+0x50], xmm5
0000705c56fd23f8  vmovaps [rsp+0x60], xmm6
0000705c56fd23fe  vmovaps [rsp+0x70], xmm7
0000705c56fd2404  vmovaps [rsp+0x80], xmm8
0000705c56fd240d  vmovaps [rsp+0x90], xmm9
0000705c56fd2416  vmovaps [rsp+0xA0], xmm10
0000705c56fd241f  vmovaps [rsp+0xB0], xmm11
0000705c56fd2428  vmovaps [rsp+0xC0], xmm12
0000705c56fd2431  vmovaps [rsp+0xD0], xmm14
0000705c56fd243a  vmovaps [rsp+0xE0], xmm15
0000705c56fd2443  sub rsp, 0x30
0000705c56fd2447  movaps [rsp], xmm13
0000705c56fd244c  movaps [rsp+0x10], xmm11
0000705c56fd2452  movaps [rsp+0x20], xmm1
0000705c56fd2457  lea rdi, [rsp]
0000705c56fd245b  mov esi, 0x00
0000705c56fd2460  mov rax, 0x5877D3629530
0000705c56fd246a  call rax
0000705c56fd246c  movaps xmm13, [rsp]
0000705c56fd2471  add rsp, 0x30
0000705c56fd2475  vmovaps xmm0, [rsp]
0000705c56fd247a  vmovaps xmm1, [rsp+0x10]
0000705c56fd2480  vmovaps xmm2, [rsp+0x20]
0000705c56fd2486  vmovaps xmm3, [rsp+0x30]
0000705c56fd248c  vmovaps xmm4, [rsp+0x40]
0000705c56fd2492  vmovaps xmm5, [rsp+0x50]
0000705c56fd2498  vmovaps xmm6, [rsp+0x60]
0000705c56fd249e  vmovaps xmm7, [rsp+0x70]
0000705c56fd24a4  vmovaps xmm8, [rsp+0x80]
0000705c56fd24ad  vmovaps xmm9, [rsp+0x90]
0000705c56fd24b6  vmovaps xmm10, [rsp+0xA0]
0000705c56fd24bf  vmovaps xmm11, [rsp+0xB0]
0000705c56fd24c8  vmovaps xmm12, [rsp+0xC0]
0000705c56fd24d1  vmovaps xmm14, [rsp+0xD0]
0000705c56fd24da  vmovaps xmm15, [rsp+0xE0]
0000705c56fd24e3  add rsp, 0xF0
0000705c56fd24ea  pop r11
0000705c56fd24ec  pop r10
0000705c56fd24ee  pop r9
0000705c56fd24f0  pop r8
0000705c56fd24f2  pop rsi
0000705c56fd24f3  pop rdi
0000705c56fd24f4  pop rdx
0000705c56fd24f5  pop rcx
0000705c56fd24f6  pop rax
0000705c56fd24f7  add rsp, 0x08
0000705c56fd24fb  jmp 0x0000705C56FCFC76
0000705c56fd2500  call 0x0000705C56DFF430
0000705c56fd2505  jmp 0x0000705C56FCFC83
0000705c56fd250a  sub rsp, 0x08
0000705c56fd250e  push rax
0000705c56fd250f  push rcx
0000705c56fd2510  push rdx
0000705c56fd2511  push rdi
0000705c56fd2512  push rsi
0000705c56fd2513  push r8
0000705c56fd2515  push r9
0000705c56fd2517  push r10
0000705c56fd2519  push r11
0000705c56fd251b  sub rsp, 0xF0
0000705c56fd2522  vmovaps [rsp], xmm0
0000705c56fd2527  vmovaps [rsp+0x10], xmm1
0000705c56fd252d  vmovaps [rsp+0x20], xmm2
0000705c56fd2533  vmovaps [rsp+0x30], xmm3
0000705c56fd2539  vmovaps [rsp+0x40], xmm4
0000705c56fd253f  vmovaps [rsp+0x50], xmm5
0000705c56fd2545  vmovaps [rsp+0x60], xmm6
0000705c56fd254b  vmovaps [rsp+0x70], xmm7
0000705c56fd2551  vmovaps [rsp+0x80], xmm8
0000705c56fd255a  vmovaps [rsp+0x90], xmm9
0000705c56fd2563  vmovaps [rsp+0xA0], xmm10
0000705c56fd256c  vmovaps [rsp+0xB0], xmm11
0000705c56fd2575  vmovaps [rsp+0xC0], xmm12
0000705c56fd257e  vmovaps [rsp+0xD0], xmm13
0000705c56fd2587  vmovaps [rsp+0xE0], xmm14
0000705c56fd2590  sub rsp, 0x30
0000705c56fd2594  movaps [rsp], xmm15
0000705c56fd2599  movaps [rsp+0x10], xmm11
0000705c56fd259f  movaps [rsp+0x20], xmm1
0000705c56fd25a4  lea rdi, [rsp]
0000705c56fd25a8  mov esi, 0x00
0000705c56fd25ad  mov rax, 0x5877D3629530
0000705c56fd25b7  call rax
0000705c56fd25b9  movaps xmm15, [rsp]
0000705c56fd25be  add rsp, 0x30
0000705c56fd25c2  vmovaps xmm0, [rsp]
0000705c56fd25c7  vmovaps xmm1, [rsp+0x10]
0000705c56fd25cd  vmovaps xmm2, [rsp+0x20]
0000705c56fd25d3  vmovaps xmm3, [rsp+0x30]
0000705c56fd25d9  vmovaps xmm4, [rsp+0x40]
0000705c56fd25df  vmovaps xmm5, [rsp+0x50]
0000705c56fd25e5  vmovaps xmm6, [rsp+0x60]
0000705c56fd25eb  vmovaps xmm7, [rsp+0x70]
0000705c56fd25f1  vmovaps xmm8, [rsp+0x80]
0000705c56fd25fa  vmovaps xmm9, [rsp+0x90]
0000705c56fd2603  vmovaps xmm10, [rsp+0xA0]
0000705c56fd260c  vmovaps xmm11, [rsp+0xB0]
0000705c56fd2615  vmovaps xmm12, [rsp+0xC0]
0000705c56fd261e  vmovaps xmm13, [rsp+0xD0]
0000705c56fd2627  vmovaps xmm14, [rsp+0xE0]
0000705c56fd2630  add rsp, 0xF0
0000705c56fd2637  pop r11
0000705c56fd2639  pop r10
0000705c56fd263b  pop r9
0000705c56fd263d  pop r8
0000705c56fd263f  pop rsi
0000705c56fd2640  pop rdi
0000705c56fd2641  pop rdx
0000705c56fd2642  pop rcx
0000705c56fd2643  pop rax
0000705c56fd2644  add rsp, 0x08
0000705c56fd2648  jmp 0x0000705C56FCFCBC
0000705c56fd264d  sub rsp, 0x08
0000705c56fd2651  push rax
0000705c56fd2652  push rcx
0000705c56fd2653  push rdx
0000705c56fd2654  push rdi
0000705c56fd2655  push rsi
0000705c56fd2656  push r8
0000705c56fd2658  push r9
0000705c56fd265a  push r10
0000705c56fd265c  push r11
0000705c56fd265e  sub rsp, 0xF0
0000705c56fd2665  vmovaps [rsp], xmm0
0000705c56fd266a  vmovaps [rsp+0x10], xmm1
0000705c56fd2670  vmovaps [rsp+0x20], xmm2
0000705c56fd2676  vmovaps [rsp+0x30], xmm3
0000705c56fd267c  vmovaps [rsp+0x40], xmm4
0000705c56fd2682  vmovaps [rsp+0x50], xmm5
0000705c56fd2688  vmovaps [rsp+0x60], xmm6
0000705c56fd268e  vmovaps [rsp+0x70], xmm7
0000705c56fd2694  vmovaps [rsp+0x80], xmm8
0000705c56fd269d  vmovaps [rsp+0x90], xmm9
0000705c56fd26a6  vmovaps [rsp+0xA0], xmm10
0000705c56fd26af  vmovaps [rsp+0xB0], xmm12
0000705c56fd26b8  vmovaps [rsp+0xC0], xmm13
0000705c56fd26c1  vmovaps [rsp+0xD0], xmm14
0000705c56fd26ca  vmovaps [rsp+0xE0], xmm15
0000705c56fd26d3  sub rsp, 0x30
0000705c56fd26d7  movaps [rsp], xmm11
0000705c56fd26dc  movaps [rsp+0x10], xmm6
0000705c56fd26e1  movaps [rsp+0x20], xmm14
0000705c56fd26e7  lea rdi, [rsp]
0000705c56fd26eb  mov esi, 0x00
0000705c56fd26f0  mov rax, 0x5877D3629530
0000705c56fd26fa  call rax
0000705c56fd26fc  movaps xmm11, [rsp]
0000705c56fd2701  add rsp, 0x30
0000705c56fd2705  vmovaps xmm0, [rsp]
0000705c56fd270a  vmovaps xmm1, [rsp+0x10]
0000705c56fd2710  vmovaps xmm2, [rsp+0x20]
0000705c56fd2716  vmovaps xmm3, [rsp+0x30]
0000705c56fd271c  vmovaps xmm4, [rsp+0x40]
0000705c56fd2722  vmovaps xmm5, [rsp+0x50]
0000705c56fd2728  vmovaps xmm6, [rsp+0x60]
0000705c56fd272e  vmovaps xmm7, [rsp+0x70]
0000705c56fd2734  vmovaps xmm8, [rsp+0x80]
0000705c56fd273d  vmovaps xmm9, [rsp+0x90]
0000705c56fd2746  vmovaps xmm10, [rsp+0xA0]
0000705c56fd274f  vmovaps xmm12, [rsp+0xB0]
0000705c56fd2758  vmovaps xmm13, [rsp+0xC0]
0000705c56fd2761  vmovaps xmm14, [rsp+0xD0]
0000705c56fd276a  vmovaps xmm15, [rsp+0xE0]
0000705c56fd2773  add rsp, 0xF0
0000705c56fd277a  pop r11
0000705c56fd277c  pop r10
0000705c56fd277e  pop r9
0000705c56fd2780  pop r8
0000705c56fd2782  pop rsi
0000705c56fd2783  pop rdi
0000705c56fd2784  pop rdx
0000705c56fd2785  pop rcx
0000705c56fd2786  pop rax
0000705c56fd2787  add rsp, 0x08
0000705c56fd278b  jmp 0x0000705C56FCFD34
0000705c56fd2790  call 0x0000705C56DFF430
0000705c56fd2795  jmp 0x0000705C56FCFD3E
0000705c56fd279a  sub rsp, 0x08
0000705c56fd279e  push rax
0000705c56fd279f  push rcx
0000705c56fd27a0  push rdx
0000705c56fd27a1  push rdi
0000705c56fd27a2  push rsi
0000705c56fd27a3  push r8
0000705c56fd27a5  push r9
0000705c56fd27a7  push r10
0000705c56fd27a9  push r11
0000705c56fd27ab  sub rsp, 0xF0
0000705c56fd27b2  vmovaps [rsp], xmm0
0000705c56fd27b7  vmovaps [rsp+0x10], xmm1
0000705c56fd27bd  vmovaps [rsp+0x20], xmm2
0000705c56fd27c3  vmovaps [rsp+0x30], xmm3
0000705c56fd27c9  vmovaps [rsp+0x40], xmm4
0000705c56fd27cf  vmovaps [rsp+0x50], xmm5
0000705c56fd27d5  vmovaps [rsp+0x60], xmm6
0000705c56fd27db  vmovaps [rsp+0x70], xmm7
0000705c56fd27e1  vmovaps [rsp+0x80], xmm8
0000705c56fd27ea  vmovaps [rsp+0x90], xmm9
0000705c56fd27f3  vmovaps [rsp+0xA0], xmm10
0000705c56fd27fc  vmovaps [rsp+0xB0], xmm11
0000705c56fd2805  vmovaps [rsp+0xC0], xmm12
0000705c56fd280e  vmovaps [rsp+0xD0], xmm13
0000705c56fd2817  vmovaps [rsp+0xE0], xmm15
0000705c56fd2820  sub rsp, 0x30
0000705c56fd2824  movaps [rsp], xmm14
0000705c56fd2829  movaps [rsp+0x10], xmm6
0000705c56fd282e  movaps [rsp+0x20], xmm2
0000705c56fd2833  lea rdi, [rsp]
0000705c56fd2837  mov esi, 0x00
0000705c56fd283c  mov rax, 0x5877D3629530
0000705c56fd2846  call rax
0000705c56fd2848  movaps xmm14, [rsp]
0000705c56fd284d  add rsp, 0x30
0000705c56fd2851  vmovaps xmm0, [rsp]
0000705c56fd2856  vmovaps xmm1, [rsp+0x10]
0000705c56fd285c  vmovaps xmm2, [rsp+0x20]
0000705c56fd2862  vmovaps xmm3, [rsp+0x30]
0000705c56fd2868  vmovaps xmm4, [rsp+0x40]
0000705c56fd286e  vmovaps xmm5, [rsp+0x50]
0000705c56fd2874  vmovaps xmm6, [rsp+0x60]
0000705c56fd287a  vmovaps xmm7, [rsp+0x70]
0000705c56fd2880  vmovaps xmm8, [rsp+0x80]
0000705c56fd2889  vmovaps xmm9, [rsp+0x90]
0000705c56fd2892  vmovaps xmm10, [rsp+0xA0]
0000705c56fd289b  vmovaps xmm11, [rsp+0xB0]
0000705c56fd28a4  vmovaps xmm12, [rsp+0xC0]
0000705c56fd28ad  vmovaps xmm13, [rsp+0xD0]
0000705c56fd28b6  vmovaps xmm15, [rsp+0xE0]
0000705c56fd28bf  add rsp, 0xF0
0000705c56fd28c6  pop r11
0000705c56fd28c8  pop r10
0000705c56fd28ca  pop r9
0000705c56fd28cc  pop r8
0000705c56fd28ce  pop rsi
0000705c56fd28cf  pop rdi
0000705c56fd28d0  pop rdx
0000705c56fd28d1  pop rcx
0000705c56fd28d2  pop rax
0000705c56fd28d3  add rsp, 0x08
0000705c56fd28d7  jmp 0x0000705C56FCFD72
0000705c56fd28dc  sub rsp, 0x08
0000705c56fd28e0  push rax
0000705c56fd28e1  push rcx
0000705c56fd28e2  push rdx
0000705c56fd28e3  push rdi
0000705c56fd28e4  push rsi
0000705c56fd28e5  push r8
0000705c56fd28e7  push r9
0000705c56fd28e9  push r10
0000705c56fd28eb  push r11
0000705c56fd28ed  sub rsp, 0xF0
0000705c56fd28f4  vmovaps [rsp], xmm0
0000705c56fd28f9  vmovaps [rsp+0x10], xmm1
0000705c56fd28ff  vmovaps [rsp+0x20], xmm2
0000705c56fd2905  vmovaps [rsp+0x30], xmm3
0000705c56fd290b  vmovaps [rsp+0x40], xmm4
0000705c56fd2911  vmovaps [rsp+0x50], xmm5
0000705c56fd2917  vmovaps [rsp+0x60], xmm7
0000705c56fd291d  vmovaps [rsp+0x70], xmm8
0000705c56fd2923  vmovaps [rsp+0x80], xmm9
0000705c56fd292c  vmovaps [rsp+0x90], xmm10
0000705c56fd2935  vmovaps [rsp+0xA0], xmm11
0000705c56fd293e  vmovaps [rsp+0xB0], xmm12
0000705c56fd2947  vmovaps [rsp+0xC0], xmm13
0000705c56fd2950  vmovaps [rsp+0xD0], xmm14
0000705c56fd2959  vmovaps [rsp+0xE0], xmm15
0000705c56fd2962  sub rsp, 0x30
0000705c56fd2966  movaps [rsp], xmm6
0000705c56fd296a  movaps [rsp+0x10], xmm5
0000705c56fd296f  movaps [rsp+0x20], xmm1
0000705c56fd2974  lea rdi, [rsp]
0000705c56fd2978  mov esi, 0x00
0000705c56fd297d  mov rax, 0x5877D3629530
0000705c56fd2987  call rax
0000705c56fd2989  movaps xmm6, [rsp]
0000705c56fd298d  add rsp, 0x30
0000705c56fd2991  vmovaps xmm0, [rsp]
0000705c56fd2996  vmovaps xmm1, [rsp+0x10]
0000705c56fd299c  vmovaps xmm2, [rsp+0x20]
0000705c56fd29a2  vmovaps xmm3, [rsp+0x30]
0000705c56fd29a8  vmovaps xmm4, [rsp+0x40]
0000705c56fd29ae  vmovaps xmm5, [rsp+0x50]
0000705c56fd29b4  vmovaps xmm7, [rsp+0x60]
0000705c56fd29ba  vmovaps xmm8, [rsp+0x70]
0000705c56fd29c0  vmovaps xmm9, [rsp+0x80]
0000705c56fd29c9  vmovaps xmm10, [rsp+0x90]
0000705c56fd29d2  vmovaps xmm11, [rsp+0xA0]
0000705c56fd29db  vmovaps xmm12, [rsp+0xB0]
0000705c56fd29e4  vmovaps xmm13, [rsp+0xC0]
0000705c56fd29ed  vmovaps xmm14, [rsp+0xD0]
0000705c56fd29f6  vmovaps xmm15, [rsp+0xE0]
0000705c56fd29ff  add rsp, 0xF0
0000705c56fd2a06  pop r11
0000705c56fd2a08  pop r10
0000705c56fd2a0a  pop r9
0000705c56fd2a0c  pop r8
0000705c56fd2a0e  pop rsi
0000705c56fd2a0f  pop rdi
0000705c56fd2a10  pop rdx
0000705c56fd2a11  pop rcx
0000705c56fd2a12  pop rax
0000705c56fd2a13  add rsp, 0x08
0000705c56fd2a17  jmp 0x0000705C56FCFD98
0000705c56fd2a1c  sub rsp, 0x08
0000705c56fd2a20  push rax
0000705c56fd2a21  push rcx
0000705c56fd2a22  push rdx
0000705c56fd2a23  push rdi
0000705c56fd2a24  push rsi
0000705c56fd2a25  push r8
0000705c56fd2a27  push r9
0000705c56fd2a29  push r10
0000705c56fd2a2b  push r11
0000705c56fd2a2d  sub rsp, 0xF0
0000705c56fd2a34  vmovaps [rsp], xmm0
0000705c56fd2a39  vmovaps [rsp+0x10], xmm2
0000705c56fd2a3f  vmovaps [rsp+0x20], xmm3
0000705c56fd2a45  vmovaps [rsp+0x30], xmm4
0000705c56fd2a4b  vmovaps [rsp+0x40], xmm5
0000705c56fd2a51  vmovaps [rsp+0x50], xmm6
0000705c56fd2a57  vmovaps [rsp+0x60], xmm7
0000705c56fd2a5d  vmovaps [rsp+0x70], xmm8
0000705c56fd2a63  vmovaps [rsp+0x80], xmm9
0000705c56fd2a6c  vmovaps [rsp+0x90], xmm10
0000705c56fd2a75  vmovaps [rsp+0xA0], xmm11
0000705c56fd2a7e  vmovaps [rsp+0xB0], xmm12
0000705c56fd2a87  vmovaps [rsp+0xC0], xmm13
0000705c56fd2a90  vmovaps [rsp+0xD0], xmm14
0000705c56fd2a99  vmovaps [rsp+0xE0], xmm15
0000705c56fd2aa2  sub rsp, 0x30
0000705c56fd2aa6  movaps [rsp], xmm1
0000705c56fd2aaa  movaps [rsp+0x10], xmm5
0000705c56fd2aaf  movaps [rsp+0x20], xmm13
0000705c56fd2ab5  lea rdi, [rsp]
0000705c56fd2ab9  mov esi, 0x00
0000705c56fd2abe  mov rax, 0x5877D3629530
0000705c56fd2ac8  call rax
0000705c56fd2aca  movaps xmm1, [rsp]
0000705c56fd2ace  add rsp, 0x30
0000705c56fd2ad2  vmovaps xmm0, [rsp]
0000705c56fd2ad7  vmovaps xmm2, [rsp+0x10]
0000705c56fd2add  vmovaps xmm3, [rsp+0x20]
0000705c56fd2ae3  vmovaps xmm4, [rsp+0x30]
0000705c56fd2ae9  vmovaps xmm5, [rsp+0x40]
0000705c56fd2aef  vmovaps xmm6, [rsp+0x50]
0000705c56fd2af5  vmovaps xmm7, [rsp+0x60]
0000705c56fd2afb  vmovaps xmm8, [rsp+0x70]
0000705c56fd2b01  vmovaps xmm9, [rsp+0x80]
0000705c56fd2b0a  vmovaps xmm10, [rsp+0x90]
0000705c56fd2b13  vmovaps xmm11, [rsp+0xA0]
0000705c56fd2b1c  vmovaps xmm12, [rsp+0xB0]
0000705c56fd2b25  vmovaps xmm13, [rsp+0xC0]
0000705c56fd2b2e  vmovaps xmm14, [rsp+0xD0]
0000705c56fd2b37  vmovaps xmm15, [rsp+0xE0]
0000705c56fd2b40  add rsp, 0xF0
0000705c56fd2b47  pop r11
0000705c56fd2b49  pop r10
0000705c56fd2b4b  pop r9
0000705c56fd2b4d  pop r8
0000705c56fd2b4f  pop rsi
0000705c56fd2b50  pop rdi
0000705c56fd2b51  pop rdx
0000705c56fd2b52  pop rcx
0000705c56fd2b53  pop rax
0000705c56fd2b54  add rsp, 0x08
0000705c56fd2b58  jmp 0x0000705C56FCFDB6
0000705c56fd2b5d  sub rsp, 0x08
0000705c56fd2b61  push rax
0000705c56fd2b62  push rcx
0000705c56fd2b63  push rdx
0000705c56fd2b64  push rdi
0000705c56fd2b65  push rsi
0000705c56fd2b66  push r8
0000705c56fd2b68  push r9
0000705c56fd2b6a  push r10
0000705c56fd2b6c  push r11
0000705c56fd2b6e  sub rsp, 0xF0
0000705c56fd2b75  vmovaps [rsp], xmm0
0000705c56fd2b7a  vmovaps [rsp+0x10], xmm1
0000705c56fd2b80  vmovaps [rsp+0x20], xmm2
0000705c56fd2b86  vmovaps [rsp+0x30], xmm3
0000705c56fd2b8c  vmovaps [rsp+0x40], xmm4
0000705c56fd2b92  vmovaps [rsp+0x50], xmm6
0000705c56fd2b98  vmovaps [rsp+0x60], xmm7
0000705c56fd2b9e  vmovaps [rsp+0x70], xmm8
0000705c56fd2ba4  vmovaps [rsp+0x80], xmm9
0000705c56fd2bad  vmovaps [rsp+0x90], xmm10
0000705c56fd2bb6  vmovaps [rsp+0xA0], xmm11
0000705c56fd2bbf  vmovaps [rsp+0xB0], xmm12
0000705c56fd2bc8  vmovaps [rsp+0xC0], xmm13
0000705c56fd2bd1  vmovaps [rsp+0xD0], xmm14
0000705c56fd2bda  vmovaps [rsp+0xE0], xmm15
0000705c56fd2be3  sub rsp, 0x30
0000705c56fd2be7  movaps [rsp], xmm5
0000705c56fd2beb  movaps [rsp+0x10], xmm2
0000705c56fd2bf0  movaps [rsp+0x20], xmm13
0000705c56fd2bf6  lea rdi, [rsp]
0000705c56fd2bfa  mov esi, 0x00
0000705c56fd2bff  mov rax, 0x5877D3629530
0000705c56fd2c09  call rax
0000705c56fd2c0b  movaps xmm5, [rsp]
0000705c56fd2c0f  add rsp, 0x30
0000705c56fd2c13  vmovaps xmm0, [rsp]
0000705c56fd2c18  vmovaps xmm1, [rsp+0x10]
0000705c56fd2c1e  vmovaps xmm2, [rsp+0x20]
0000705c56fd2c24  vmovaps xmm3, [rsp+0x30]
0000705c56fd2c2a  vmovaps xmm4, [rsp+0x40]
0000705c56fd2c30  vmovaps xmm6, [rsp+0x50]
0000705c56fd2c36  vmovaps xmm7, [rsp+0x60]
0000705c56fd2c3c  vmovaps xmm8, [rsp+0x70]
0000705c56fd2c42  vmovaps xmm9, [rsp+0x80]
0000705c56fd2c4b  vmovaps xmm10, [rsp+0x90]
0000705c56fd2c54  vmovaps xmm11, [rsp+0xA0]
0000705c56fd2c5d  vmovaps xmm12, [rsp+0xB0]
0000705c56fd2c66  vmovaps xmm13, [rsp+0xC0]
0000705c56fd2c6f  vmovaps xmm14, [rsp+0xD0]
0000705c56fd2c78  vmovaps xmm15, [rsp+0xE0]
0000705c56fd2c81  add rsp, 0xF0
0000705c56fd2c88  pop r11
0000705c56fd2c8a  pop r10
0000705c56fd2c8c  pop r9
0000705c56fd2c8e  pop r8
0000705c56fd2c90  pop rsi
0000705c56fd2c91  pop rdi
0000705c56fd2c92  pop rdx
0000705c56fd2c93  pop rcx
0000705c56fd2c94  pop rax
0000705c56fd2c95  add rsp, 0x08
0000705c56fd2c99  jmp 0x0000705C56FCFDEC
0000705c56fd2c9e  sub rsp, 0x08
0000705c56fd2ca2  push rax
0000705c56fd2ca3  push rcx
0000705c56fd2ca4  push rdx
0000705c56fd2ca5  push rdi
0000705c56fd2ca6  push rsi
0000705c56fd2ca7  push r8
0000705c56fd2ca9  push r9
0000705c56fd2cab  push r10
0000705c56fd2cad  push r11
0000705c56fd2caf  sub rsp, 0xF0
0000705c56fd2cb6  vmovaps [rsp], xmm0
0000705c56fd2cbb  vmovaps [rsp+0x10], xmm1
0000705c56fd2cc1  vmovaps [rsp+0x20], xmm2
0000705c56fd2cc7  vmovaps [rsp+0x30], xmm3
0000705c56fd2ccd  vmovaps [rsp+0x40], xmm4
0000705c56fd2cd3  vmovaps [rsp+0x50], xmm5
0000705c56fd2cd9  vmovaps [rsp+0x60], xmm6
0000705c56fd2cdf  vmovaps [rsp+0x70], xmm7
0000705c56fd2ce5  vmovaps [rsp+0x80], xmm8
0000705c56fd2cee  vmovaps [rsp+0x90], xmm9
0000705c56fd2cf7  vmovaps [rsp+0xA0], xmm10
0000705c56fd2d00  vmovaps [rsp+0xB0], xmm11
0000705c56fd2d09  vmovaps [rsp+0xC0], xmm12
0000705c56fd2d12  vmovaps [rsp+0xD0], xmm14
0000705c56fd2d1b  vmovaps [rsp+0xE0], xmm15
0000705c56fd2d24  sub rsp, 0x30
0000705c56fd2d28  movaps [rsp], xmm13
0000705c56fd2d2d  movaps [rsp+0x10], xmm10
0000705c56fd2d33  movaps [rsp+0x20], xmm1
0000705c56fd2d38  lea rdi, [rsp]
0000705c56fd2d3c  mov esi, 0x00
0000705c56fd2d41  mov rax, 0x5877D3629530
0000705c56fd2d4b  call rax
0000705c56fd2d4d  movaps xmm13, [rsp]
0000705c56fd2d52  add rsp, 0x30
0000705c56fd2d56  vmovaps xmm0, [rsp]
0000705c56fd2d5b  vmovaps xmm1, [rsp+0x10]
0000705c56fd2d61  vmovaps xmm2, [rsp+0x20]
0000705c56fd2d67  vmovaps xmm3, [rsp+0x30]
0000705c56fd2d6d  vmovaps xmm4, [rsp+0x40]
0000705c56fd2d73  vmovaps xmm5, [rsp+0x50]
0000705c56fd2d79  vmovaps xmm6, [rsp+0x60]
0000705c56fd2d7f  vmovaps xmm7, [rsp+0x70]
0000705c56fd2d85  vmovaps xmm8, [rsp+0x80]
0000705c56fd2d8e  vmovaps xmm9, [rsp+0x90]
0000705c56fd2d97  vmovaps xmm10, [rsp+0xA0]
0000705c56fd2da0  vmovaps xmm11, [rsp+0xB0]
0000705c56fd2da9  vmovaps xmm12, [rsp+0xC0]
0000705c56fd2db2  vmovaps xmm14, [rsp+0xD0]
0000705c56fd2dbb  vmovaps xmm15, [rsp+0xE0]
0000705c56fd2dc4  add rsp, 0xF0
0000705c56fd2dcb  pop r11
0000705c56fd2dcd  pop r10
0000705c56fd2dcf  pop r9
0000705c56fd2dd1  pop r8
0000705c56fd2dd3  pop rsi
0000705c56fd2dd4  pop rdi
0000705c56fd2dd5  pop rdx
0000705c56fd2dd6  pop rcx
0000705c56fd2dd7  pop rax
0000705c56fd2dd8  add rsp, 0x08
0000705c56fd2ddc  jmp 0x0000705C56FCFE15
0000705c56fd2de1  sub rsp, 0x08
0000705c56fd2de5  push rax
0000705c56fd2de6  push rcx
0000705c56fd2de7  push rdx
0000705c56fd2de8  push rdi
0000705c56fd2de9  push rsi
0000705c56fd2dea  push r8
0000705c56fd2dec  push r9
0000705c56fd2dee  push r10
0000705c56fd2df0  push r11
0000705c56fd2df2  sub rsp, 0xF0
0000705c56fd2df9  vmovaps [rsp], xmm0
0000705c56fd2dfe  vmovaps [rsp+0x10], xmm2
0000705c56fd2e04  vmovaps [rsp+0x20], xmm3
0000705c56fd2e0a  vmovaps [rsp+0x30], xmm4
0000705c56fd2e10  vmovaps [rsp+0x40], xmm5
0000705c56fd2e16  vmovaps [rsp+0x50], xmm6
0000705c56fd2e1c  vmovaps [rsp+0x60], xmm7
0000705c56fd2e22  vmovaps [rsp+0x70], xmm8
0000705c56fd2e28  vmovaps [rsp+0x80], xmm9
0000705c56fd2e31  vmovaps [rsp+0x90], xmm10
0000705c56fd2e3a  vmovaps [rsp+0xA0], xmm11
0000705c56fd2e43  vmovaps [rsp+0xB0], xmm12
0000705c56fd2e4c  vmovaps [rsp+0xC0], xmm13
0000705c56fd2e55  vmovaps [rsp+0xD0], xmm14
0000705c56fd2e5e  vmovaps [rsp+0xE0], xmm15
0000705c56fd2e67  sub rsp, 0x30
0000705c56fd2e6b  movaps [rsp], xmm1
0000705c56fd2e6f  movaps [rsp+0x10], xmm15
0000705c56fd2e75  movaps [rsp+0x20], xmm10
0000705c56fd2e7b  lea rdi, [rsp]
0000705c56fd2e7f  mov esi, 0x00
0000705c56fd2e84  mov rax, 0x5877D3629530
0000705c56fd2e8e  call rax
0000705c56fd2e90  movaps xmm1, [rsp]
0000705c56fd2e94  add rsp, 0x30
0000705c56fd2e98  vmovaps xmm0, [rsp]
0000705c56fd2e9d  vmovaps xmm2, [rsp+0x10]
0000705c56fd2ea3  vmovaps xmm3, [rsp+0x20]
0000705c56fd2ea9  vmovaps xmm4, [rsp+0x30]
0000705c56fd2eaf  vmovaps xmm5, [rsp+0x40]
0000705c56fd2eb5  vmovaps xmm6, [rsp+0x50]
0000705c56fd2ebb  vmovaps xmm7, [rsp+0x60]
0000705c56fd2ec1  vmovaps xmm8, [rsp+0x70]
0000705c56fd2ec7  vmovaps xmm9, [rsp+0x80]
0000705c56fd2ed0  vmovaps xmm10, [rsp+0x90]
0000705c56fd2ed9  vmovaps xmm11, [rsp+0xA0]
0000705c56fd2ee2  vmovaps xmm12, [rsp+0xB0]
0000705c56fd2eeb  vmovaps xmm13, [rsp+0xC0]
0000705c56fd2ef4  vmovaps xmm14, [rsp+0xD0]
0000705c56fd2efd  vmovaps xmm15, [rsp+0xE0]
0000705c56fd2f06  add rsp, 0xF0
0000705c56fd2f0d  pop r11
0000705c56fd2f0f  pop r10
0000705c56fd2f11  pop r9
0000705c56fd2f13  pop r8
0000705c56fd2f15  pop rsi
0000705c56fd2f16  pop rdi
0000705c56fd2f17  pop rdx
0000705c56fd2f18  pop rcx
0000705c56fd2f19  pop rax
0000705c56fd2f1a  add rsp, 0x08
0000705c56fd2f1e  jmp 0x0000705C56FCFE34
0000705c56fd2f23  sub rsp, 0x08
0000705c56fd2f27  push rax
0000705c56fd2f28  push rcx
0000705c56fd2f29  push rdx
0000705c56fd2f2a  push rdi
0000705c56fd2f2b  push rsi
0000705c56fd2f2c  push r8
0000705c56fd2f2e  push r9
0000705c56fd2f30  push r10
0000705c56fd2f32  push r11
0000705c56fd2f34  sub rsp, 0xF0
0000705c56fd2f3b  vmovaps [rsp], xmm0
0000705c56fd2f40  vmovaps [rsp+0x10], xmm1
0000705c56fd2f46  vmovaps [rsp+0x20], xmm2
0000705c56fd2f4c  vmovaps [rsp+0x30], xmm3
0000705c56fd2f52  vmovaps [rsp+0x40], xmm4
0000705c56fd2f58  vmovaps [rsp+0x50], xmm5
0000705c56fd2f5e  vmovaps [rsp+0x60], xmm6
0000705c56fd2f64  vmovaps [rsp+0x70], xmm7
0000705c56fd2f6a  vmovaps [rsp+0x80], xmm8
0000705c56fd2f73  vmovaps [rsp+0x90], xmm9
0000705c56fd2f7c  vmovaps [rsp+0xA0], xmm10
0000705c56fd2f85  vmovaps [rsp+0xB0], xmm11
0000705c56fd2f8e  vmovaps [rsp+0xC0], xmm12
0000705c56fd2f97  vmovaps [rsp+0xD0], xmm13
0000705c56fd2fa0  vmovaps [rsp+0xE0], xmm14
0000705c56fd2fa9  sub rsp, 0x30
0000705c56fd2fad  movaps [rsp], xmm15
0000705c56fd2fb2  movaps [rsp+0x10], xmm10
0000705c56fd2fb8  movaps [rsp+0x20], xmm11
0000705c56fd2fbe  lea rdi, [rsp]
0000705c56fd2fc2  mov esi, 0x00
0000705c56fd2fc7  mov rax, 0x5877D3629530
0000705c56fd2fd1  call rax
0000705c56fd2fd3  movaps xmm15, [rsp]
0000705c56fd2fd8  add rsp, 0x30
0000705c56fd2fdc  vmovaps xmm0, [rsp]
0000705c56fd2fe1  vmovaps xmm1, [rsp+0x10]
0000705c56fd2fe7  vmovaps xmm2, [rsp+0x20]
0000705c56fd2fed  vmovaps xmm3, [rsp+0x30]
0000705c56fd2ff3  vmovaps xmm4, [rsp+0x40]
0000705c56fd2ff9  vmovaps xmm5, [rsp+0x50]
0000705c56fd2fff  vmovaps xmm6, [rsp+0x60]
0000705c56fd3005  vmovaps xmm7, [rsp+0x70]
0000705c56fd300b  vmovaps xmm8, [rsp+0x80]
0000705c56fd3014  vmovaps xmm9, [rsp+0x90]
0000705c56fd301d  vmovaps xmm10, [rsp+0xA0]
0000705c56fd3026  vmovaps xmm11, [rsp+0xB0]
0000705c56fd302f  vmovaps xmm12, [rsp+0xC0]
0000705c56fd3038  vmovaps xmm13, [rsp+0xD0]
0000705c56fd3041  vmovaps xmm14, [rsp+0xE0]
0000705c56fd304a  add rsp, 0xF0
0000705c56fd3051  pop r11
0000705c56fd3053  pop r10
0000705c56fd3055  pop r9
0000705c56fd3057  pop r8
0000705c56fd3059  pop rsi
0000705c56fd305a  pop rdi
0000705c56fd305b  pop rdx
0000705c56fd305c  pop rcx
0000705c56fd305d  pop rax
0000705c56fd305e  add rsp, 0x08
0000705c56fd3062  jmp 0x0000705C56FCFE57
0000705c56fd3067  sub rsp, 0x08
0000705c56fd306b  push rax
0000705c56fd306c  push rcx
0000705c56fd306d  push rdx
0000705c56fd306e  push rdi
0000705c56fd306f  push rsi
0000705c56fd3070  push r8
0000705c56fd3072  push r9
0000705c56fd3074  push r10
0000705c56fd3076  push r11
0000705c56fd3078  sub rsp, 0xF0
0000705c56fd307f  vmovaps [rsp], xmm0
0000705c56fd3084  vmovaps [rsp+0x10], xmm1
0000705c56fd308a  vmovaps [rsp+0x20], xmm2
0000705c56fd3090  vmovaps [rsp+0x30], xmm3
0000705c56fd3096  vmovaps [rsp+0x40], xmm4
0000705c56fd309c  vmovaps [rsp+0x50], xmm5
0000705c56fd30a2  vmovaps [rsp+0x60], xmm6
0000705c56fd30a8  vmovaps [rsp+0x70], xmm7
0000705c56fd30ae  vmovaps [rsp+0x80], xmm8
0000705c56fd30b7  vmovaps [rsp+0x90], xmm9
0000705c56fd30c0  vmovaps [rsp+0xA0], xmm11
0000705c56fd30c9  vmovaps [rsp+0xB0], xmm12
0000705c56fd30d2  vmovaps [rsp+0xC0], xmm13
0000705c56fd30db  vmovaps [rsp+0xD0], xmm14
0000705c56fd30e4  vmovaps [rsp+0xE0], xmm15
0000705c56fd30ed  sub rsp, 0x30
0000705c56fd30f1  movaps [rsp], xmm10
0000705c56fd30f6  movaps [rsp+0x10], xmm12
0000705c56fd30fc  movaps [rsp+0x20], xmm11
0000705c56fd3102  lea rdi, [rsp]
0000705c56fd3106  mov esi, 0x00
0000705c56fd310b  mov rax, 0x5877D3629530
0000705c56fd3115  call rax
0000705c56fd3117  movaps xmm10, [rsp]
0000705c56fd311c  add rsp, 0x30
0000705c56fd3120  vmovaps xmm0, [rsp]
0000705c56fd3125  vmovaps xmm1, [rsp+0x10]
0000705c56fd312b  vmovaps xmm2, [rsp+0x20]
0000705c56fd3131  vmovaps xmm3, [rsp+0x30]
0000705c56fd3137  vmovaps xmm4, [rsp+0x40]
0000705c56fd313d  vmovaps xmm5, [rsp+0x50]
0000705c56fd3143  vmovaps xmm6, [rsp+0x60]
0000705c56fd3149  vmovaps xmm7, [rsp+0x70]
0000705c56fd314f  vmovaps xmm8, [rsp+0x80]
0000705c56fd3158  vmovaps xmm9, [rsp+0x90]
0000705c56fd3161  vmovaps xmm11, [rsp+0xA0]
0000705c56fd316a  vmovaps xmm12, [rsp+0xB0]
0000705c56fd3173  vmovaps xmm13, [rsp+0xC0]
0000705c56fd317c  vmovaps xmm14, [rsp+0xD0]
0000705c56fd3185  vmovaps xmm15, [rsp+0xE0]
0000705c56fd318e  add rsp, 0xF0
0000705c56fd3195  pop r11
0000705c56fd3197  pop r10
0000705c56fd3199  pop r9
0000705c56fd319b  pop r8
0000705c56fd319d  pop rsi
0000705c56fd319e  pop rdi
0000705c56fd319f  pop rdx
0000705c56fd31a0  pop rcx
0000705c56fd31a1  pop rax
0000705c56fd31a2  add rsp, 0x08
0000705c56fd31a6  jmp 0x0000705C56FCFE80
0000705c56fd31ab  sub rsp, 0x08
0000705c56fd31af  push rax
0000705c56fd31b0  push rcx
0000705c56fd31b1  push rdx
0000705c56fd31b2  push rdi
0000705c56fd31b3  push rsi
0000705c56fd31b4  push r8
0000705c56fd31b6  push r9
0000705c56fd31b8  push r10
0000705c56fd31ba  push r11
0000705c56fd31bc  sub rsp, 0xF0
0000705c56fd31c3  vmovaps [rsp], xmm0
0000705c56fd31c8  vmovaps [rsp+0x10], xmm1
0000705c56fd31ce  vmovaps [rsp+0x20], xmm2
0000705c56fd31d4  vmovaps [rsp+0x30], xmm3
0000705c56fd31da  vmovaps [rsp+0x40], xmm4
0000705c56fd31e0  vmovaps [rsp+0x50], xmm5
0000705c56fd31e6  vmovaps [rsp+0x60], xmm6
0000705c56fd31ec  vmovaps [rsp+0x70], xmm7
0000705c56fd31f2  vmovaps [rsp+0x80], xmm8
0000705c56fd31fb  vmovaps [rsp+0x90], xmm9
0000705c56fd3204  vmovaps [rsp+0xA0], xmm10
0000705c56fd320d  vmovaps [rsp+0xB0], xmm12
0000705c56fd3216  vmovaps [rsp+0xC0], xmm13
0000705c56fd321f  vmovaps [rsp+0xD0], xmm14
0000705c56fd3228  vmovaps [rsp+0xE0], xmm15
0000705c56fd3231  sub rsp, 0x30
0000705c56fd3235  movaps [rsp], xmm11
0000705c56fd323a  movaps [rsp+0x10], xmm2
0000705c56fd323f  movaps [rsp+0x20], xmm12
0000705c56fd3245  lea rdi, [rsp]
0000705c56fd3249  mov esi, 0x00
0000705c56fd324e  mov rax, 0x5877D3629530
0000705c56fd3258  call rax
0000705c56fd325a  movaps xmm11, [rsp]
0000705c56fd325f  add rsp, 0x30
0000705c56fd3263  vmovaps xmm0, [rsp]
0000705c56fd3268  vmovaps xmm1, [rsp+0x10]
0000705c56fd326e  vmovaps xmm2, [rsp+0x20]
0000705c56fd3274  vmovaps xmm3, [rsp+0x30]
0000705c56fd327a  vmovaps xmm4, [rsp+0x40]
0000705c56fd3280  vmovaps xmm5, [rsp+0x50]
0000705c56fd3286  vmovaps xmm6, [rsp+0x60]
0000705c56fd328c  vmovaps xmm7, [rsp+0x70]
0000705c56fd3292  vmovaps xmm8, [rsp+0x80]
0000705c56fd329b  vmovaps xmm9, [rsp+0x90]
0000705c56fd32a4  vmovaps xmm10, [rsp+0xA0]
0000705c56fd32ad  vmovaps xmm12, [rsp+0xB0]
0000705c56fd32b6  vmovaps xmm13, [rsp+0xC0]
0000705c56fd32bf  vmovaps xmm14, [rsp+0xD0]
0000705c56fd32c8  vmovaps xmm15, [rsp+0xE0]
0000705c56fd32d1  add rsp, 0xF0
0000705c56fd32d8  pop r11
0000705c56fd32da  pop r10
0000705c56fd32dc  pop r9
0000705c56fd32de  pop r8
0000705c56fd32e0  pop rsi
0000705c56fd32e1  pop rdi
0000705c56fd32e2  pop rdx
0000705c56fd32e3  pop rcx
0000705c56fd32e4  pop rax
0000705c56fd32e5  add rsp, 0x08
0000705c56fd32e9  jmp 0x0000705C56FCFEB8
0000705c56fd32ee  sub rsp, 0x08
0000705c56fd32f2  push rax
0000705c56fd32f3  push rcx
0000705c56fd32f4  push rdx
0000705c56fd32f5  push rdi
0000705c56fd32f6  push rsi
0000705c56fd32f7  push r8
0000705c56fd32f9  push r9
0000705c56fd32fb  push r10
0000705c56fd32fd  push r11
0000705c56fd32ff  sub rsp, 0xF0
0000705c56fd3306  vmovaps [rsp], xmm0
0000705c56fd330b  vmovaps [rsp+0x10], xmm2
0000705c56fd3311  vmovaps [rsp+0x20], xmm3
0000705c56fd3317  vmovaps [rsp+0x30], xmm4
0000705c56fd331d  vmovaps [rsp+0x40], xmm5
0000705c56fd3323  vmovaps [rsp+0x50], xmm6
0000705c56fd3329  vmovaps [rsp+0x60], xmm7
0000705c56fd332f  vmovaps [rsp+0x70], xmm8
0000705c56fd3335  vmovaps [rsp+0x80], xmm9
0000705c56fd333e  vmovaps [rsp+0x90], xmm10
0000705c56fd3347  vmovaps [rsp+0xA0], xmm11
0000705c56fd3350  vmovaps [rsp+0xB0], xmm12
0000705c56fd3359  vmovaps [rsp+0xC0], xmm13
0000705c56fd3362  vmovaps [rsp+0xD0], xmm14
0000705c56fd336b  vmovaps [rsp+0xE0], xmm15
0000705c56fd3374  sub rsp, 0x30
0000705c56fd3378  movaps [rsp], xmm1
0000705c56fd337c  movaps [rsp+0x10], xmm14
0000705c56fd3382  movaps [rsp+0x20], xmm6
0000705c56fd3387  lea rdi, [rsp]
0000705c56fd338b  mov esi, 0x00
0000705c56fd3390  mov rax, 0x5877D3629530
0000705c56fd339a  call rax
0000705c56fd339c  movaps xmm1, [rsp]
0000705c56fd33a0  add rsp, 0x30
0000705c56fd33a4  vmovaps xmm0, [rsp]
0000705c56fd33a9  vmovaps xmm2, [rsp+0x10]
0000705c56fd33af  vmovaps xmm3, [rsp+0x20]
0000705c56fd33b5  vmovaps xmm4, [rsp+0x30]
0000705c56fd33bb  vmovaps xmm5, [rsp+0x40]
0000705c56fd33c1  vmovaps xmm6, [rsp+0x50]
0000705c56fd33c7  vmovaps xmm7, [rsp+0x60]
0000705c56fd33cd  vmovaps xmm8, [rsp+0x70]
0000705c56fd33d3  vmovaps xmm9, [rsp+0x80]
0000705c56fd33dc  vmovaps xmm10, [rsp+0x90]
0000705c56fd33e5  vmovaps xmm11, [rsp+0xA0]
0000705c56fd33ee  vmovaps xmm12, [rsp+0xB0]
0000705c56fd33f7  vmovaps xmm13, [rsp+0xC0]
0000705c56fd3400  vmovaps xmm14, [rsp+0xD0]
0000705c56fd3409  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3412  add rsp, 0xF0
0000705c56fd3419  pop r11
0000705c56fd341b  pop r10
0000705c56fd341d  pop r9
0000705c56fd341f  pop r8
0000705c56fd3421  pop rsi
0000705c56fd3422  pop rdi
0000705c56fd3423  pop rdx
0000705c56fd3424  pop rcx
0000705c56fd3425  pop rax
0000705c56fd3426  add rsp, 0x08
0000705c56fd342a  jmp 0x0000705C56FCFED1
0000705c56fd342f  sub rsp, 0x08
0000705c56fd3433  push rax
0000705c56fd3434  push rcx
0000705c56fd3435  push rdx
0000705c56fd3436  push rdi
0000705c56fd3437  push rsi
0000705c56fd3438  push r8
0000705c56fd343a  push r9
0000705c56fd343c  push r10
0000705c56fd343e  push r11
0000705c56fd3440  sub rsp, 0xF0
0000705c56fd3447  vmovaps [rsp], xmm0
0000705c56fd344c  vmovaps [rsp+0x10], xmm1
0000705c56fd3452  vmovaps [rsp+0x20], xmm2
0000705c56fd3458  vmovaps [rsp+0x30], xmm3
0000705c56fd345e  vmovaps [rsp+0x40], xmm4
0000705c56fd3464  vmovaps [rsp+0x50], xmm5
0000705c56fd346a  vmovaps [rsp+0x60], xmm6
0000705c56fd3470  vmovaps [rsp+0x70], xmm7
0000705c56fd3476  vmovaps [rsp+0x80], xmm8
0000705c56fd347f  vmovaps [rsp+0x90], xmm9
0000705c56fd3488  vmovaps [rsp+0xA0], xmm10
0000705c56fd3491  vmovaps [rsp+0xB0], xmm11
0000705c56fd349a  vmovaps [rsp+0xC0], xmm12
0000705c56fd34a3  vmovaps [rsp+0xD0], xmm13
0000705c56fd34ac  vmovaps [rsp+0xE0], xmm15
0000705c56fd34b5  sub rsp, 0x30
0000705c56fd34b9  movaps [rsp], xmm14
0000705c56fd34be  movaps [rsp+0x10], xmm12
0000705c56fd34c4  movaps [rsp+0x20], xmm5
0000705c56fd34c9  lea rdi, [rsp]
0000705c56fd34cd  mov esi, 0x00
0000705c56fd34d2  mov rax, 0x5877D3629530
0000705c56fd34dc  call rax
0000705c56fd34de  movaps xmm14, [rsp]
0000705c56fd34e3  add rsp, 0x30
0000705c56fd34e7  vmovaps xmm0, [rsp]
0000705c56fd34ec  vmovaps xmm1, [rsp+0x10]
0000705c56fd34f2  vmovaps xmm2, [rsp+0x20]
0000705c56fd34f8  vmovaps xmm3, [rsp+0x30]
0000705c56fd34fe  vmovaps xmm4, [rsp+0x40]
0000705c56fd3504  vmovaps xmm5, [rsp+0x50]
0000705c56fd350a  vmovaps xmm6, [rsp+0x60]
0000705c56fd3510  vmovaps xmm7, [rsp+0x70]
0000705c56fd3516  vmovaps xmm8, [rsp+0x80]
0000705c56fd351f  vmovaps xmm9, [rsp+0x90]
0000705c56fd3528  vmovaps xmm10, [rsp+0xA0]
0000705c56fd3531  vmovaps xmm11, [rsp+0xB0]
0000705c56fd353a  vmovaps xmm12, [rsp+0xC0]
0000705c56fd3543  vmovaps xmm13, [rsp+0xD0]
0000705c56fd354c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3555  add rsp, 0xF0
0000705c56fd355c  pop r11
0000705c56fd355e  pop r10
0000705c56fd3560  pop r9
0000705c56fd3562  pop r8
0000705c56fd3564  pop rsi
0000705c56fd3565  pop rdi
0000705c56fd3566  pop rdx
0000705c56fd3567  pop rcx
0000705c56fd3568  pop rax
0000705c56fd3569  add rsp, 0x08
0000705c56fd356d  jmp 0x0000705C56FCFEF1
0000705c56fd3572  sub rsp, 0x08
0000705c56fd3576  push rax
0000705c56fd3577  push rcx
0000705c56fd3578  push rdx
0000705c56fd3579  push rdi
0000705c56fd357a  push rsi
0000705c56fd357b  push r8
0000705c56fd357d  push r9
0000705c56fd357f  push r10
0000705c56fd3581  push r11
0000705c56fd3583  sub rsp, 0xF0
0000705c56fd358a  vmovaps [rsp], xmm0
0000705c56fd358f  vmovaps [rsp+0x10], xmm1
0000705c56fd3595  vmovaps [rsp+0x20], xmm2
0000705c56fd359b  vmovaps [rsp+0x30], xmm3
0000705c56fd35a1  vmovaps [rsp+0x40], xmm4
0000705c56fd35a7  vmovaps [rsp+0x50], xmm5
0000705c56fd35ad  vmovaps [rsp+0x60], xmm7
0000705c56fd35b3  vmovaps [rsp+0x70], xmm8
0000705c56fd35b9  vmovaps [rsp+0x80], xmm9
0000705c56fd35c2  vmovaps [rsp+0x90], xmm10
0000705c56fd35cb  vmovaps [rsp+0xA0], xmm11
0000705c56fd35d4  vmovaps [rsp+0xB0], xmm12
0000705c56fd35dd  vmovaps [rsp+0xC0], xmm13
0000705c56fd35e6  vmovaps [rsp+0xD0], xmm14
0000705c56fd35ef  vmovaps [rsp+0xE0], xmm15
0000705c56fd35f8  sub rsp, 0x30
0000705c56fd35fc  movaps [rsp], xmm6
0000705c56fd3600  movaps [rsp+0x10], xmm9
0000705c56fd3606  movaps [rsp+0x20], xmm12
0000705c56fd360c  lea rdi, [rsp]
0000705c56fd3610  mov esi, 0x00
0000705c56fd3615  mov rax, 0x5877D3629530
0000705c56fd361f  call rax
0000705c56fd3621  movaps xmm6, [rsp]
0000705c56fd3625  add rsp, 0x30
0000705c56fd3629  vmovaps xmm0, [rsp]
0000705c56fd362e  vmovaps xmm1, [rsp+0x10]
0000705c56fd3634  vmovaps xmm2, [rsp+0x20]
0000705c56fd363a  vmovaps xmm3, [rsp+0x30]
0000705c56fd3640  vmovaps xmm4, [rsp+0x40]
0000705c56fd3646  vmovaps xmm5, [rsp+0x50]
0000705c56fd364c  vmovaps xmm7, [rsp+0x60]
0000705c56fd3652  vmovaps xmm8, [rsp+0x70]
0000705c56fd3658  vmovaps xmm9, [rsp+0x80]
0000705c56fd3661  vmovaps xmm10, [rsp+0x90]
0000705c56fd366a  vmovaps xmm11, [rsp+0xA0]
0000705c56fd3673  vmovaps xmm12, [rsp+0xB0]
0000705c56fd367c  vmovaps xmm13, [rsp+0xC0]
0000705c56fd3685  vmovaps xmm14, [rsp+0xD0]
0000705c56fd368e  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3697  add rsp, 0xF0
0000705c56fd369e  pop r11
0000705c56fd36a0  pop r10
0000705c56fd36a2  pop r9
0000705c56fd36a4  pop r8
0000705c56fd36a6  pop rsi
0000705c56fd36a7  pop rdi
0000705c56fd36a8  pop rdx
0000705c56fd36a9  pop rcx
0000705c56fd36aa  pop rax
0000705c56fd36ab  add rsp, 0x08
0000705c56fd36af  jmp 0x0000705C56FCFF19
0000705c56fd36b4  sub rsp, 0x08
0000705c56fd36b8  push rax
0000705c56fd36b9  push rcx
0000705c56fd36ba  push rdx
0000705c56fd36bb  push rdi
0000705c56fd36bc  push rsi
0000705c56fd36bd  push r8
0000705c56fd36bf  push r9
0000705c56fd36c1  push r10
0000705c56fd36c3  push r11
0000705c56fd36c5  sub rsp, 0xF0
0000705c56fd36cc  vmovaps [rsp], xmm0
0000705c56fd36d1  vmovaps [rsp+0x10], xmm1
0000705c56fd36d7  vmovaps [rsp+0x20], xmm2
0000705c56fd36dd  vmovaps [rsp+0x30], xmm3
0000705c56fd36e3  vmovaps [rsp+0x40], xmm4
0000705c56fd36e9  vmovaps [rsp+0x50], xmm5
0000705c56fd36ef  vmovaps [rsp+0x60], xmm6
0000705c56fd36f5  vmovaps [rsp+0x70], xmm7
0000705c56fd36fb  vmovaps [rsp+0x80], xmm8
0000705c56fd3704  vmovaps [rsp+0x90], xmm9
0000705c56fd370d  vmovaps [rsp+0xA0], xmm10
0000705c56fd3716  vmovaps [rsp+0xB0], xmm11
0000705c56fd371f  vmovaps [rsp+0xC0], xmm13
0000705c56fd3728  vmovaps [rsp+0xD0], xmm14
0000705c56fd3731  vmovaps [rsp+0xE0], xmm15
0000705c56fd373a  sub rsp, 0x30
0000705c56fd373e  movaps [rsp], xmm12
0000705c56fd3743  movaps [rsp+0x10], xmm15
0000705c56fd3749  movaps [rsp+0x20], xmm13
0000705c56fd374f  lea rdi, [rsp]
0000705c56fd3753  mov esi, 0x00
0000705c56fd3758  mov rax, 0x5877D3629530
0000705c56fd3762  call rax
0000705c56fd3764  movaps xmm12, [rsp]
0000705c56fd3769  add rsp, 0x30
0000705c56fd376d  vmovaps xmm0, [rsp]
0000705c56fd3772  vmovaps xmm1, [rsp+0x10]
0000705c56fd3778  vmovaps xmm2, [rsp+0x20]
0000705c56fd377e  vmovaps xmm3, [rsp+0x30]
0000705c56fd3784  vmovaps xmm4, [rsp+0x40]
0000705c56fd378a  vmovaps xmm5, [rsp+0x50]
0000705c56fd3790  vmovaps xmm6, [rsp+0x60]
0000705c56fd3796  vmovaps xmm7, [rsp+0x70]
0000705c56fd379c  vmovaps xmm8, [rsp+0x80]
0000705c56fd37a5  vmovaps xmm9, [rsp+0x90]
0000705c56fd37ae  vmovaps xmm10, [rsp+0xA0]
0000705c56fd37b7  vmovaps xmm11, [rsp+0xB0]
0000705c56fd37c0  vmovaps xmm13, [rsp+0xC0]
0000705c56fd37c9  vmovaps xmm14, [rsp+0xD0]
0000705c56fd37d2  vmovaps xmm15, [rsp+0xE0]
0000705c56fd37db  add rsp, 0xF0
0000705c56fd37e2  pop r11
0000705c56fd37e4  pop r10
0000705c56fd37e6  pop r9
0000705c56fd37e8  pop r8
0000705c56fd37ea  pop rsi
0000705c56fd37eb  pop rdi
0000705c56fd37ec  pop rdx
0000705c56fd37ed  pop rcx
0000705c56fd37ee  pop rax
0000705c56fd37ef  add rsp, 0x08
0000705c56fd37f3  jmp 0x0000705C56FCFF34
0000705c56fd37f8  sub rsp, 0x08
0000705c56fd37fc  push rax
0000705c56fd37fd  push rcx
0000705c56fd37fe  push rdx
0000705c56fd37ff  push rdi
0000705c56fd3800  push rsi
0000705c56fd3801  push r8
0000705c56fd3803  push r9
0000705c56fd3805  push r10
0000705c56fd3807  push r11
0000705c56fd3809  sub rsp, 0xF0
0000705c56fd3810  vmovaps [rsp], xmm0
0000705c56fd3815  vmovaps [rsp+0x10], xmm1
0000705c56fd381b  vmovaps [rsp+0x20], xmm2
0000705c56fd3821  vmovaps [rsp+0x30], xmm3
0000705c56fd3827  vmovaps [rsp+0x40], xmm4
0000705c56fd382d  vmovaps [rsp+0x50], xmm5
0000705c56fd3833  vmovaps [rsp+0x60], xmm6
0000705c56fd3839  vmovaps [rsp+0x70], xmm7
0000705c56fd383f  vmovaps [rsp+0x80], xmm8
0000705c56fd3848  vmovaps [rsp+0x90], xmm9
0000705c56fd3851  vmovaps [rsp+0xA0], xmm10
0000705c56fd385a  vmovaps [rsp+0xB0], xmm11
0000705c56fd3863  vmovaps [rsp+0xC0], xmm12
0000705c56fd386c  vmovaps [rsp+0xD0], xmm13
0000705c56fd3875  vmovaps [rsp+0xE0], xmm14
0000705c56fd387e  sub rsp, 0x30
0000705c56fd3882  movaps [rsp], xmm15
0000705c56fd3887  movaps [rsp+0x10], xmm13
0000705c56fd388d  movaps [rsp+0x20], xmm10
0000705c56fd3893  lea rdi, [rsp]
0000705c56fd3897  mov esi, 0x00
0000705c56fd389c  mov rax, 0x5877D3629530
0000705c56fd38a6  call rax
0000705c56fd38a8  movaps xmm15, [rsp]
0000705c56fd38ad  add rsp, 0x30
0000705c56fd38b1  vmovaps xmm0, [rsp]
0000705c56fd38b6  vmovaps xmm1, [rsp+0x10]
0000705c56fd38bc  vmovaps xmm2, [rsp+0x20]
0000705c56fd38c2  vmovaps xmm3, [rsp+0x30]
0000705c56fd38c8  vmovaps xmm4, [rsp+0x40]
0000705c56fd38ce  vmovaps xmm5, [rsp+0x50]
0000705c56fd38d4  vmovaps xmm6, [rsp+0x60]
0000705c56fd38da  vmovaps xmm7, [rsp+0x70]
0000705c56fd38e0  vmovaps xmm8, [rsp+0x80]
0000705c56fd38e9  vmovaps xmm9, [rsp+0x90]
0000705c56fd38f2  vmovaps xmm10, [rsp+0xA0]
0000705c56fd38fb  vmovaps xmm11, [rsp+0xB0]
0000705c56fd3904  vmovaps xmm12, [rsp+0xC0]
0000705c56fd390d  vmovaps xmm13, [rsp+0xD0]
0000705c56fd3916  vmovaps xmm14, [rsp+0xE0]
0000705c56fd391f  add rsp, 0xF0
0000705c56fd3926  pop r11
0000705c56fd3928  pop r10
0000705c56fd392a  pop r9
0000705c56fd392c  pop r8
0000705c56fd392e  pop rsi
0000705c56fd392f  pop rdi
0000705c56fd3930  pop rdx
0000705c56fd3931  pop rcx
0000705c56fd3932  pop rax
0000705c56fd3933  add rsp, 0x08
0000705c56fd3937  jmp 0x0000705C56FCFF55
0000705c56fd393c  call 0x0000705C56E0C260
0000705c56fd3941  jmp 0x0000705C56FCFFB0
0000705c56fd3946  sub rsp, 0x08
0000705c56fd394a  push rax
0000705c56fd394b  push rcx
0000705c56fd394c  push rdx
0000705c56fd394d  push rdi
0000705c56fd394e  push rsi
0000705c56fd394f  push r8
0000705c56fd3951  push r9
0000705c56fd3953  push r10
0000705c56fd3955  push r11
0000705c56fd3957  sub rsp, 0xF0
0000705c56fd395e  vmovaps [rsp], xmm0
0000705c56fd3963  vmovaps [rsp+0x10], xmm1
0000705c56fd3969  vmovaps [rsp+0x20], xmm2
0000705c56fd396f  vmovaps [rsp+0x30], xmm3
0000705c56fd3975  vmovaps [rsp+0x40], xmm4
0000705c56fd397b  vmovaps [rsp+0x50], xmm5
0000705c56fd3981  vmovaps [rsp+0x60], xmm6
0000705c56fd3987  vmovaps [rsp+0x70], xmm7
0000705c56fd398d  vmovaps [rsp+0x80], xmm8
0000705c56fd3996  vmovaps [rsp+0x90], xmm10
0000705c56fd399f  vmovaps [rsp+0xA0], xmm11
0000705c56fd39a8  vmovaps [rsp+0xB0], xmm12
0000705c56fd39b1  vmovaps [rsp+0xC0], xmm13
0000705c56fd39ba  vmovaps [rsp+0xD0], xmm14
0000705c56fd39c3  vmovaps [rsp+0xE0], xmm15
0000705c56fd39cc  sub rsp, 0x30
0000705c56fd39d0  movaps [rsp], xmm9
0000705c56fd39d5  movaps [rsp+0x10], xmm8
0000705c56fd39db  movaps [rsp+0x20], xmm10
0000705c56fd39e1  lea rdi, [rsp]
0000705c56fd39e5  mov esi, 0x00
0000705c56fd39ea  mov rax, 0x5877D3629530
0000705c56fd39f4  call rax
0000705c56fd39f6  movaps xmm9, [rsp]
0000705c56fd39fb  add rsp, 0x30
0000705c56fd39ff  vmovaps xmm0, [rsp]
0000705c56fd3a04  vmovaps xmm1, [rsp+0x10]
0000705c56fd3a0a  vmovaps xmm2, [rsp+0x20]
0000705c56fd3a10  vmovaps xmm3, [rsp+0x30]
0000705c56fd3a16  vmovaps xmm4, [rsp+0x40]
0000705c56fd3a1c  vmovaps xmm5, [rsp+0x50]
0000705c56fd3a22  vmovaps xmm6, [rsp+0x60]
0000705c56fd3a28  vmovaps xmm7, [rsp+0x70]
0000705c56fd3a2e  vmovaps xmm8, [rsp+0x80]
0000705c56fd3a37  vmovaps xmm10, [rsp+0x90]
0000705c56fd3a40  vmovaps xmm11, [rsp+0xA0]
0000705c56fd3a49  vmovaps xmm12, [rsp+0xB0]
0000705c56fd3a52  vmovaps xmm13, [rsp+0xC0]
0000705c56fd3a5b  vmovaps xmm14, [rsp+0xD0]
0000705c56fd3a64  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3a6d  add rsp, 0xF0
0000705c56fd3a74  pop r11
0000705c56fd3a76  pop r10
0000705c56fd3a78  pop r9
0000705c56fd3a7a  pop r8
0000705c56fd3a7c  pop rsi
0000705c56fd3a7d  pop rdi
0000705c56fd3a7e  pop rdx
0000705c56fd3a7f  pop rcx
0000705c56fd3a80  pop rax
0000705c56fd3a81  add rsp, 0x08
0000705c56fd3a85  jmp 0x0000705C56FCFFE1
0000705c56fd3a8a  sub rsp, 0x08
0000705c56fd3a8e  push rax
0000705c56fd3a8f  push rcx
0000705c56fd3a90  push rdx
0000705c56fd3a91  push rdi
0000705c56fd3a92  push rsi
0000705c56fd3a93  push r8
0000705c56fd3a95  push r9
0000705c56fd3a97  push r10
0000705c56fd3a99  push r11
0000705c56fd3a9b  sub rsp, 0xF0
0000705c56fd3aa2  vmovaps [rsp], xmm0
0000705c56fd3aa7  vmovaps [rsp+0x10], xmm1
0000705c56fd3aad  vmovaps [rsp+0x20], xmm2
0000705c56fd3ab3  vmovaps [rsp+0x30], xmm3
0000705c56fd3ab9  vmovaps [rsp+0x40], xmm4
0000705c56fd3abf  vmovaps [rsp+0x50], xmm5
0000705c56fd3ac5  vmovaps [rsp+0x60], xmm6
0000705c56fd3acb  vmovaps [rsp+0x70], xmm7
0000705c56fd3ad1  vmovaps [rsp+0x80], xmm8
0000705c56fd3ada  vmovaps [rsp+0x90], xmm9
0000705c56fd3ae3  vmovaps [rsp+0xA0], xmm11
0000705c56fd3aec  vmovaps [rsp+0xB0], xmm12
0000705c56fd3af5  vmovaps [rsp+0xC0], xmm13
0000705c56fd3afe  vmovaps [rsp+0xD0], xmm14
0000705c56fd3b07  vmovaps [rsp+0xE0], xmm15
0000705c56fd3b10  sub rsp, 0x30
0000705c56fd3b14  movaps [rsp], xmm10
0000705c56fd3b19  movaps [rsp+0x10], xmm1
0000705c56fd3b1e  movaps [rsp+0x20], xmm11
0000705c56fd3b24  lea rdi, [rsp]
0000705c56fd3b28  mov esi, 0x00
0000705c56fd3b2d  mov rax, 0x5877D3629530
0000705c56fd3b37  call rax
0000705c56fd3b39  movaps xmm10, [rsp]
0000705c56fd3b3e  add rsp, 0x30
0000705c56fd3b42  vmovaps xmm0, [rsp]
0000705c56fd3b47  vmovaps xmm1, [rsp+0x10]
0000705c56fd3b4d  vmovaps xmm2, [rsp+0x20]
0000705c56fd3b53  vmovaps xmm3, [rsp+0x30]
0000705c56fd3b59  vmovaps xmm4, [rsp+0x40]
0000705c56fd3b5f  vmovaps xmm5, [rsp+0x50]
0000705c56fd3b65  vmovaps xmm6, [rsp+0x60]
0000705c56fd3b6b  vmovaps xmm7, [rsp+0x70]
0000705c56fd3b71  vmovaps xmm8, [rsp+0x80]
0000705c56fd3b7a  vmovaps xmm9, [rsp+0x90]
0000705c56fd3b83  vmovaps xmm11, [rsp+0xA0]
0000705c56fd3b8c  vmovaps xmm12, [rsp+0xB0]
0000705c56fd3b95  vmovaps xmm13, [rsp+0xC0]
0000705c56fd3b9e  vmovaps xmm14, [rsp+0xD0]
0000705c56fd3ba7  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3bb0  add rsp, 0xF0
0000705c56fd3bb7  pop r11
0000705c56fd3bb9  pop r10
0000705c56fd3bbb  pop r9
0000705c56fd3bbd  pop r8
0000705c56fd3bbf  pop rsi
0000705c56fd3bc0  pop rdi
0000705c56fd3bc1  pop rdx
0000705c56fd3bc2  pop rcx
0000705c56fd3bc3  pop rax
0000705c56fd3bc4  add rsp, 0x08
0000705c56fd3bc8  jmp 0x0000705C56FCFFFC
0000705c56fd3bcd  sub rsp, 0x08
0000705c56fd3bd1  push rax
0000705c56fd3bd2  push rcx
0000705c56fd3bd3  push rdx
0000705c56fd3bd4  push rdi
0000705c56fd3bd5  push rsi
0000705c56fd3bd6  push r8
0000705c56fd3bd8  push r9
0000705c56fd3bda  push r10
0000705c56fd3bdc  push r11
0000705c56fd3bde  sub rsp, 0xF0
0000705c56fd3be5  vmovaps [rsp], xmm0
0000705c56fd3bea  vmovaps [rsp+0x10], xmm2
0000705c56fd3bf0  vmovaps [rsp+0x20], xmm3
0000705c56fd3bf6  vmovaps [rsp+0x30], xmm4
0000705c56fd3bfc  vmovaps [rsp+0x40], xmm5
0000705c56fd3c02  vmovaps [rsp+0x50], xmm6
0000705c56fd3c08  vmovaps [rsp+0x60], xmm7
0000705c56fd3c0e  vmovaps [rsp+0x70], xmm8
0000705c56fd3c14  vmovaps [rsp+0x80], xmm9
0000705c56fd3c1d  vmovaps [rsp+0x90], xmm10
0000705c56fd3c26  vmovaps [rsp+0xA0], xmm11
0000705c56fd3c2f  vmovaps [rsp+0xB0], xmm12
0000705c56fd3c38  vmovaps [rsp+0xC0], xmm13
0000705c56fd3c41  vmovaps [rsp+0xD0], xmm14
0000705c56fd3c4a  vmovaps [rsp+0xE0], xmm15
0000705c56fd3c53  sub rsp, 0x30
0000705c56fd3c57  movaps [rsp], xmm1
0000705c56fd3c5b  movaps [rsp+0x10], xmm14
0000705c56fd3c61  movaps [rsp+0x20], xmm6
0000705c56fd3c66  lea rdi, [rsp]
0000705c56fd3c6a  mov esi, 0x00
0000705c56fd3c6f  mov rax, 0x5877D3629530
0000705c56fd3c79  call rax
0000705c56fd3c7b  movaps xmm1, [rsp]
0000705c56fd3c7f  add rsp, 0x30
0000705c56fd3c83  vmovaps xmm0, [rsp]
0000705c56fd3c88  vmovaps xmm2, [rsp+0x10]
0000705c56fd3c8e  vmovaps xmm3, [rsp+0x20]
0000705c56fd3c94  vmovaps xmm4, [rsp+0x30]
0000705c56fd3c9a  vmovaps xmm5, [rsp+0x40]
0000705c56fd3ca0  vmovaps xmm6, [rsp+0x50]
0000705c56fd3ca6  vmovaps xmm7, [rsp+0x60]
0000705c56fd3cac  vmovaps xmm8, [rsp+0x70]
0000705c56fd3cb2  vmovaps xmm9, [rsp+0x80]
0000705c56fd3cbb  vmovaps xmm10, [rsp+0x90]
0000705c56fd3cc4  vmovaps xmm11, [rsp+0xA0]
0000705c56fd3ccd  vmovaps xmm12, [rsp+0xB0]
0000705c56fd3cd6  vmovaps xmm13, [rsp+0xC0]
0000705c56fd3cdf  vmovaps xmm14, [rsp+0xD0]
0000705c56fd3ce8  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3cf1  add rsp, 0xF0
0000705c56fd3cf8  pop r11
0000705c56fd3cfa  pop r10
0000705c56fd3cfc  pop r9
0000705c56fd3cfe  pop r8
0000705c56fd3d00  pop rsi
0000705c56fd3d01  pop rdi
0000705c56fd3d02  pop rdx
0000705c56fd3d03  pop rcx
0000705c56fd3d04  pop rax
0000705c56fd3d05  add rsp, 0x08
0000705c56fd3d09  jmp 0x0000705C56FD0015
0000705c56fd3d0e  sub rsp, 0x08
0000705c56fd3d12  push rax
0000705c56fd3d13  push rcx
0000705c56fd3d14  push rdx
0000705c56fd3d15  push rdi
0000705c56fd3d16  push rsi
0000705c56fd3d17  push r8
0000705c56fd3d19  push r9
0000705c56fd3d1b  push r10
0000705c56fd3d1d  push r11
0000705c56fd3d1f  sub rsp, 0xF0
0000705c56fd3d26  vmovaps [rsp], xmm0
0000705c56fd3d2b  vmovaps [rsp+0x10], xmm1
0000705c56fd3d31  vmovaps [rsp+0x20], xmm2
0000705c56fd3d37  vmovaps [rsp+0x30], xmm3
0000705c56fd3d3d  vmovaps [rsp+0x40], xmm4
0000705c56fd3d43  vmovaps [rsp+0x50], xmm5
0000705c56fd3d49  vmovaps [rsp+0x60], xmm6
0000705c56fd3d4f  vmovaps [rsp+0x70], xmm7
0000705c56fd3d55  vmovaps [rsp+0x80], xmm8
0000705c56fd3d5e  vmovaps [rsp+0x90], xmm9
0000705c56fd3d67  vmovaps [rsp+0xA0], xmm10
0000705c56fd3d70  vmovaps [rsp+0xB0], xmm12
0000705c56fd3d79  vmovaps [rsp+0xC0], xmm13
0000705c56fd3d82  vmovaps [rsp+0xD0], xmm14
0000705c56fd3d8b  vmovaps [rsp+0xE0], xmm15
0000705c56fd3d94  sub rsp, 0x30
0000705c56fd3d98  movaps [rsp], xmm11
0000705c56fd3d9d  movaps [rsp+0x10], xmm13
0000705c56fd3da3  movaps [rsp+0x20], xmm14
0000705c56fd3da9  lea rdi, [rsp]
0000705c56fd3dad  mov esi, 0x00
0000705c56fd3db2  mov rax, 0x5877D3629530
0000705c56fd3dbc  call rax
0000705c56fd3dbe  movaps xmm11, [rsp]
0000705c56fd3dc3  add rsp, 0x30
0000705c56fd3dc7  vmovaps xmm0, [rsp]
0000705c56fd3dcc  vmovaps xmm1, [rsp+0x10]
0000705c56fd3dd2  vmovaps xmm2, [rsp+0x20]
0000705c56fd3dd8  vmovaps xmm3, [rsp+0x30]
0000705c56fd3dde  vmovaps xmm4, [rsp+0x40]
0000705c56fd3de4  vmovaps xmm5, [rsp+0x50]
0000705c56fd3dea  vmovaps xmm6, [rsp+0x60]
0000705c56fd3df0  vmovaps xmm7, [rsp+0x70]
0000705c56fd3df6  vmovaps xmm8, [rsp+0x80]
0000705c56fd3dff  vmovaps xmm9, [rsp+0x90]
0000705c56fd3e08  vmovaps xmm10, [rsp+0xA0]
0000705c56fd3e11  vmovaps xmm12, [rsp+0xB0]
0000705c56fd3e1a  vmovaps xmm13, [rsp+0xC0]
0000705c56fd3e23  vmovaps xmm14, [rsp+0xD0]
0000705c56fd3e2c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3e35  add rsp, 0xF0
0000705c56fd3e3c  pop r11
0000705c56fd3e3e  pop r10
0000705c56fd3e40  pop r9
0000705c56fd3e42  pop r8
0000705c56fd3e44  pop rsi
0000705c56fd3e45  pop rdi
0000705c56fd3e46  pop rdx
0000705c56fd3e47  pop rcx
0000705c56fd3e48  pop rax
0000705c56fd3e49  add rsp, 0x08
0000705c56fd3e4d  jmp 0x0000705C56FD003F
0000705c56fd3e52  sub rsp, 0x08
0000705c56fd3e56  push rax
0000705c56fd3e57  push rcx
0000705c56fd3e58  push rdx
0000705c56fd3e59  push rdi
0000705c56fd3e5a  push rsi
0000705c56fd3e5b  push r8
0000705c56fd3e5d  push r9
0000705c56fd3e5f  push r10
0000705c56fd3e61  push r11
0000705c56fd3e63  sub rsp, 0xF0
0000705c56fd3e6a  vmovaps [rsp], xmm0
0000705c56fd3e6f  vmovaps [rsp+0x10], xmm1
0000705c56fd3e75  vmovaps [rsp+0x20], xmm2
0000705c56fd3e7b  vmovaps [rsp+0x30], xmm3
0000705c56fd3e81  vmovaps [rsp+0x40], xmm4
0000705c56fd3e87  vmovaps [rsp+0x50], xmm5
0000705c56fd3e8d  vmovaps [rsp+0x60], xmm6
0000705c56fd3e93  vmovaps [rsp+0x70], xmm7
0000705c56fd3e99  vmovaps [rsp+0x80], xmm8
0000705c56fd3ea2  vmovaps [rsp+0x90], xmm9
0000705c56fd3eab  vmovaps [rsp+0xA0], xmm10
0000705c56fd3eb4  vmovaps [rsp+0xB0], xmm11
0000705c56fd3ebd  vmovaps [rsp+0xC0], xmm12
0000705c56fd3ec6  vmovaps [rsp+0xD0], xmm14
0000705c56fd3ecf  vmovaps [rsp+0xE0], xmm15
0000705c56fd3ed8  sub rsp, 0x30
0000705c56fd3edc  movaps [rsp], xmm13
0000705c56fd3ee1  movaps [rsp+0x10], xmm8
0000705c56fd3ee7  movaps [rsp+0x20], xmm14
0000705c56fd3eed  lea rdi, [rsp]
0000705c56fd3ef1  mov esi, 0x00
0000705c56fd3ef6  mov rax, 0x5877D3629530
0000705c56fd3f00  call rax
0000705c56fd3f02  movaps xmm13, [rsp]
0000705c56fd3f07  add rsp, 0x30
0000705c56fd3f0b  vmovaps xmm0, [rsp]
0000705c56fd3f10  vmovaps xmm1, [rsp+0x10]
0000705c56fd3f16  vmovaps xmm2, [rsp+0x20]
0000705c56fd3f1c  vmovaps xmm3, [rsp+0x30]
0000705c56fd3f22  vmovaps xmm4, [rsp+0x40]
0000705c56fd3f28  vmovaps xmm5, [rsp+0x50]
0000705c56fd3f2e  vmovaps xmm6, [rsp+0x60]
0000705c56fd3f34  vmovaps xmm7, [rsp+0x70]
0000705c56fd3f3a  vmovaps xmm8, [rsp+0x80]
0000705c56fd3f43  vmovaps xmm9, [rsp+0x90]
0000705c56fd3f4c  vmovaps xmm10, [rsp+0xA0]
0000705c56fd3f55  vmovaps xmm11, [rsp+0xB0]
0000705c56fd3f5e  vmovaps xmm12, [rsp+0xC0]
0000705c56fd3f67  vmovaps xmm14, [rsp+0xD0]
0000705c56fd3f70  vmovaps xmm15, [rsp+0xE0]
0000705c56fd3f79  add rsp, 0xF0
0000705c56fd3f80  pop r11
0000705c56fd3f82  pop r10
0000705c56fd3f84  pop r9
0000705c56fd3f86  pop r8
0000705c56fd3f88  pop rsi
0000705c56fd3f89  pop rdi
0000705c56fd3f8a  pop rdx
0000705c56fd3f8b  pop rcx
0000705c56fd3f8c  pop rax
0000705c56fd3f8d  add rsp, 0x08
0000705c56fd3f91  jmp 0x0000705C56FD006E
0000705c56fd3f96  sub rsp, 0x08
0000705c56fd3f9a  push rax
0000705c56fd3f9b  push rcx
0000705c56fd3f9c  push rdx
0000705c56fd3f9d  push rdi
0000705c56fd3f9e  push rsi
0000705c56fd3f9f  push r8
0000705c56fd3fa1  push r9
0000705c56fd3fa3  push r10
0000705c56fd3fa5  push r11
0000705c56fd3fa7  sub rsp, 0xF0
0000705c56fd3fae  vmovaps [rsp], xmm0
0000705c56fd3fb3  vmovaps [rsp+0x10], xmm1
0000705c56fd3fb9  vmovaps [rsp+0x20], xmm2
0000705c56fd3fbf  vmovaps [rsp+0x30], xmm3
0000705c56fd3fc5  vmovaps [rsp+0x40], xmm4
0000705c56fd3fcb  vmovaps [rsp+0x50], xmm5
0000705c56fd3fd1  vmovaps [rsp+0x60], xmm6
0000705c56fd3fd7  vmovaps [rsp+0x70], xmm7
0000705c56fd3fdd  vmovaps [rsp+0x80], xmm9
0000705c56fd3fe6  vmovaps [rsp+0x90], xmm10
0000705c56fd3fef  vmovaps [rsp+0xA0], xmm11
0000705c56fd3ff8  vmovaps [rsp+0xB0], xmm12
0000705c56fd4001  vmovaps [rsp+0xC0], xmm13
0000705c56fd400a  vmovaps [rsp+0xD0], xmm14
0000705c56fd4013  vmovaps [rsp+0xE0], xmm15
0000705c56fd401c  sub rsp, 0x30
0000705c56fd4020  movaps [rsp], xmm8
0000705c56fd4025  movaps [rsp+0x10], xmm7
0000705c56fd402a  movaps [rsp+0x20], xmm14
0000705c56fd4030  lea rdi, [rsp]
0000705c56fd4034  mov esi, 0x00
0000705c56fd4039  mov rax, 0x5877D3629530
0000705c56fd4043  call rax
0000705c56fd4045  movaps xmm8, [rsp]
0000705c56fd404a  add rsp, 0x30
0000705c56fd404e  vmovaps xmm0, [rsp]
0000705c56fd4053  vmovaps xmm1, [rsp+0x10]
0000705c56fd4059  vmovaps xmm2, [rsp+0x20]
0000705c56fd405f  vmovaps xmm3, [rsp+0x30]
0000705c56fd4065  vmovaps xmm4, [rsp+0x40]
0000705c56fd406b  vmovaps xmm5, [rsp+0x50]
0000705c56fd4071  vmovaps xmm6, [rsp+0x60]
0000705c56fd4077  vmovaps xmm7, [rsp+0x70]
0000705c56fd407d  vmovaps xmm9, [rsp+0x80]
0000705c56fd4086  vmovaps xmm10, [rsp+0x90]
0000705c56fd408f  vmovaps xmm11, [rsp+0xA0]
0000705c56fd4098  vmovaps xmm12, [rsp+0xB0]
0000705c56fd40a1  vmovaps xmm13, [rsp+0xC0]
0000705c56fd40aa  vmovaps xmm14, [rsp+0xD0]
0000705c56fd40b3  vmovaps xmm15, [rsp+0xE0]
0000705c56fd40bc  add rsp, 0xF0
0000705c56fd40c3  pop r11
0000705c56fd40c5  pop r10
0000705c56fd40c7  pop r9
0000705c56fd40c9  pop r8
0000705c56fd40cb  pop rsi
0000705c56fd40cc  pop rdi
0000705c56fd40cd  pop rdx
0000705c56fd40ce  pop rcx
0000705c56fd40cf  pop rax
0000705c56fd40d0  add rsp, 0x08
0000705c56fd40d4  jmp 0x0000705C56FD0094
0000705c56fd40d9  sub rsp, 0x08
0000705c56fd40dd  push rax
0000705c56fd40de  push rcx
0000705c56fd40df  push rdx
0000705c56fd40e0  push rdi
0000705c56fd40e1  push rsi
0000705c56fd40e2  push r8
0000705c56fd40e4  push r9
0000705c56fd40e6  push r10
0000705c56fd40e8  push r11
0000705c56fd40ea  sub rsp, 0xF0
0000705c56fd40f1  vmovaps [rsp], xmm0
0000705c56fd40f6  vmovaps [rsp+0x10], xmm1
0000705c56fd40fc  vmovaps [rsp+0x20], xmm2
0000705c56fd4102  vmovaps [rsp+0x30], xmm3
0000705c56fd4108  vmovaps [rsp+0x40], xmm4
0000705c56fd410e  vmovaps [rsp+0x50], xmm5
0000705c56fd4114  vmovaps [rsp+0x60], xmm6
0000705c56fd411a  vmovaps [rsp+0x70], xmm7
0000705c56fd4120  vmovaps [rsp+0x80], xmm8
0000705c56fd4129  vmovaps [rsp+0x90], xmm9
0000705c56fd4132  vmovaps [rsp+0xA0], xmm10
0000705c56fd413b  vmovaps [rsp+0xB0], xmm11
0000705c56fd4144  vmovaps [rsp+0xC0], xmm12
0000705c56fd414d  vmovaps [rsp+0xD0], xmm13
0000705c56fd4156  vmovaps [rsp+0xE0], xmm15
0000705c56fd415f  sub rsp, 0x30
0000705c56fd4163  movaps [rsp], xmm14
0000705c56fd4168  movaps [rsp+0x10], xmm12
0000705c56fd416e  movaps [rsp+0x20], xmm9
0000705c56fd4174  lea rdi, [rsp]
0000705c56fd4178  mov esi, 0x00
0000705c56fd417d  mov rax, 0x5877D3629530
0000705c56fd4187  call rax
0000705c56fd4189  movaps xmm14, [rsp]
0000705c56fd418e  add rsp, 0x30
0000705c56fd4192  vmovaps xmm0, [rsp]
0000705c56fd4197  vmovaps xmm1, [rsp+0x10]
0000705c56fd419d  vmovaps xmm2, [rsp+0x20]
0000705c56fd41a3  vmovaps xmm3, [rsp+0x30]
0000705c56fd41a9  vmovaps xmm4, [rsp+0x40]
0000705c56fd41af  vmovaps xmm5, [rsp+0x50]
0000705c56fd41b5  vmovaps xmm6, [rsp+0x60]
0000705c56fd41bb  vmovaps xmm7, [rsp+0x70]
0000705c56fd41c1  vmovaps xmm8, [rsp+0x80]
0000705c56fd41ca  vmovaps xmm9, [rsp+0x90]
0000705c56fd41d3  vmovaps xmm10, [rsp+0xA0]
0000705c56fd41dc  vmovaps xmm11, [rsp+0xB0]
0000705c56fd41e5  vmovaps xmm12, [rsp+0xC0]
0000705c56fd41ee  vmovaps xmm13, [rsp+0xD0]
0000705c56fd41f7  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4200  add rsp, 0xF0
0000705c56fd4207  pop r11
0000705c56fd4209  pop r10
0000705c56fd420b  pop r9
0000705c56fd420d  pop r8
0000705c56fd420f  pop rsi
0000705c56fd4210  pop rdi
0000705c56fd4211  pop rdx
0000705c56fd4212  pop rcx
0000705c56fd4213  pop rax
0000705c56fd4214  add rsp, 0x08
0000705c56fd4218  jmp 0x0000705C56FD00AE
0000705c56fd421d  sub rsp, 0x08
0000705c56fd4221  push rax
0000705c56fd4222  push rcx
0000705c56fd4223  push rdx
0000705c56fd4224  push rdi
0000705c56fd4225  push rsi
0000705c56fd4226  push r8
0000705c56fd4228  push r9
0000705c56fd422a  push r10
0000705c56fd422c  push r11
0000705c56fd422e  sub rsp, 0xF0
0000705c56fd4235  vmovaps [rsp], xmm0
0000705c56fd423a  vmovaps [rsp+0x10], xmm1
0000705c56fd4240  vmovaps [rsp+0x20], xmm2
0000705c56fd4246  vmovaps [rsp+0x30], xmm3
0000705c56fd424c  vmovaps [rsp+0x40], xmm4
0000705c56fd4252  vmovaps [rsp+0x50], xmm5
0000705c56fd4258  vmovaps [rsp+0x60], xmm6
0000705c56fd425e  vmovaps [rsp+0x70], xmm7
0000705c56fd4264  vmovaps [rsp+0x80], xmm8
0000705c56fd426d  vmovaps [rsp+0x90], xmm10
0000705c56fd4276  vmovaps [rsp+0xA0], xmm11
0000705c56fd427f  vmovaps [rsp+0xB0], xmm12
0000705c56fd4288  vmovaps [rsp+0xC0], xmm13
0000705c56fd4291  vmovaps [rsp+0xD0], xmm14
0000705c56fd429a  vmovaps [rsp+0xE0], xmm15
0000705c56fd42a3  sub rsp, 0x30
0000705c56fd42a7  movaps [rsp], xmm9
0000705c56fd42ac  movaps [rsp+0x10], xmm7
0000705c56fd42b1  movaps [rsp+0x20], xmm12
0000705c56fd42b7  lea rdi, [rsp]
0000705c56fd42bb  mov esi, 0x00
0000705c56fd42c0  mov rax, 0x5877D3629530
0000705c56fd42ca  call rax
0000705c56fd42cc  movaps xmm9, [rsp]
0000705c56fd42d1  add rsp, 0x30
0000705c56fd42d5  vmovaps xmm0, [rsp]
0000705c56fd42da  vmovaps xmm1, [rsp+0x10]
0000705c56fd42e0  vmovaps xmm2, [rsp+0x20]
0000705c56fd42e6  vmovaps xmm3, [rsp+0x30]
0000705c56fd42ec  vmovaps xmm4, [rsp+0x40]
0000705c56fd42f2  vmovaps xmm5, [rsp+0x50]
0000705c56fd42f8  vmovaps xmm6, [rsp+0x60]
0000705c56fd42fe  vmovaps xmm7, [rsp+0x70]
0000705c56fd4304  vmovaps xmm8, [rsp+0x80]
0000705c56fd430d  vmovaps xmm10, [rsp+0x90]
0000705c56fd4316  vmovaps xmm11, [rsp+0xA0]
0000705c56fd431f  vmovaps xmm12, [rsp+0xB0]
0000705c56fd4328  vmovaps xmm13, [rsp+0xC0]
0000705c56fd4331  vmovaps xmm14, [rsp+0xD0]
0000705c56fd433a  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4343  add rsp, 0xF0
0000705c56fd434a  pop r11
0000705c56fd434c  pop r10
0000705c56fd434e  pop r9
0000705c56fd4350  pop r8
0000705c56fd4352  pop rsi
0000705c56fd4353  pop rdi
0000705c56fd4354  pop rdx
0000705c56fd4355  pop rcx
0000705c56fd4356  pop rax
0000705c56fd4357  add rsp, 0x08
0000705c56fd435b  jmp 0x0000705C56FD00DD
0000705c56fd4360  sub rsp, 0x08
0000705c56fd4364  push rax
0000705c56fd4365  push rcx
0000705c56fd4366  push rdx
0000705c56fd4367  push rdi
0000705c56fd4368  push rsi
0000705c56fd4369  push r8
0000705c56fd436b  push r9
0000705c56fd436d  push r10
0000705c56fd436f  push r11
0000705c56fd4371  sub rsp, 0xF0
0000705c56fd4378  vmovaps [rsp], xmm0
0000705c56fd437d  vmovaps [rsp+0x10], xmm1
0000705c56fd4383  vmovaps [rsp+0x20], xmm2
0000705c56fd4389  vmovaps [rsp+0x30], xmm3
0000705c56fd438f  vmovaps [rsp+0x40], xmm4
0000705c56fd4395  vmovaps [rsp+0x50], xmm5
0000705c56fd439b  vmovaps [rsp+0x60], xmm6
0000705c56fd43a1  vmovaps [rsp+0x70], xmm7
0000705c56fd43a7  vmovaps [rsp+0x80], xmm8
0000705c56fd43b0  vmovaps [rsp+0x90], xmm9
0000705c56fd43b9  vmovaps [rsp+0xA0], xmm10
0000705c56fd43c2  vmovaps [rsp+0xB0], xmm11
0000705c56fd43cb  vmovaps [rsp+0xC0], xmm13
0000705c56fd43d4  vmovaps [rsp+0xD0], xmm14
0000705c56fd43dd  vmovaps [rsp+0xE0], xmm15
0000705c56fd43e6  sub rsp, 0x30
0000705c56fd43ea  movaps [rsp], xmm12
0000705c56fd43ef  movaps [rsp+0x10], xmm15
0000705c56fd43f5  movaps [rsp+0x20], xmm11
0000705c56fd43fb  lea rdi, [rsp]
0000705c56fd43ff  mov esi, 0x00
0000705c56fd4404  mov rax, 0x5877D3629530
0000705c56fd440e  call rax
0000705c56fd4410  movaps xmm12, [rsp]
0000705c56fd4415  add rsp, 0x30
0000705c56fd4419  vmovaps xmm0, [rsp]
0000705c56fd441e  vmovaps xmm1, [rsp+0x10]
0000705c56fd4424  vmovaps xmm2, [rsp+0x20]
0000705c56fd442a  vmovaps xmm3, [rsp+0x30]
0000705c56fd4430  vmovaps xmm4, [rsp+0x40]
0000705c56fd4436  vmovaps xmm5, [rsp+0x50]
0000705c56fd443c  vmovaps xmm6, [rsp+0x60]
0000705c56fd4442  vmovaps xmm7, [rsp+0x70]
0000705c56fd4448  vmovaps xmm8, [rsp+0x80]
0000705c56fd4451  vmovaps xmm9, [rsp+0x90]
0000705c56fd445a  vmovaps xmm10, [rsp+0xA0]
0000705c56fd4463  vmovaps xmm11, [rsp+0xB0]
0000705c56fd446c  vmovaps xmm13, [rsp+0xC0]
0000705c56fd4475  vmovaps xmm14, [rsp+0xD0]
0000705c56fd447e  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4487  add rsp, 0xF0
0000705c56fd448e  pop r11
0000705c56fd4490  pop r10
0000705c56fd4492  pop r9
0000705c56fd4494  pop r8
0000705c56fd4496  pop rsi
0000705c56fd4497  pop rdi
0000705c56fd4498  pop rdx
0000705c56fd4499  pop rcx
0000705c56fd449a  pop rax
0000705c56fd449b  add rsp, 0x08
0000705c56fd449f  jmp 0x0000705C56FD00F7
0000705c56fd44a4  sub rsp, 0x08
0000705c56fd44a8  push rax
0000705c56fd44a9  push rcx
0000705c56fd44aa  push rdx
0000705c56fd44ab  push rdi
0000705c56fd44ac  push rsi
0000705c56fd44ad  push r8
0000705c56fd44af  push r9
0000705c56fd44b1  push r10
0000705c56fd44b3  push r11
0000705c56fd44b5  sub rsp, 0xF0
0000705c56fd44bc  vmovaps [rsp], xmm0
0000705c56fd44c1  vmovaps [rsp+0x10], xmm1
0000705c56fd44c7  vmovaps [rsp+0x20], xmm2
0000705c56fd44cd  vmovaps [rsp+0x30], xmm3
0000705c56fd44d3  vmovaps [rsp+0x40], xmm4
0000705c56fd44d9  vmovaps [rsp+0x50], xmm5
0000705c56fd44df  vmovaps [rsp+0x60], xmm6
0000705c56fd44e5  vmovaps [rsp+0x70], xmm7
0000705c56fd44eb  vmovaps [rsp+0x80], xmm8
0000705c56fd44f4  vmovaps [rsp+0x90], xmm9
0000705c56fd44fd  vmovaps [rsp+0xA0], xmm10
0000705c56fd4506  vmovaps [rsp+0xB0], xmm12
0000705c56fd450f  vmovaps [rsp+0xC0], xmm13
0000705c56fd4518  vmovaps [rsp+0xD0], xmm14
0000705c56fd4521  vmovaps [rsp+0xE0], xmm15
0000705c56fd452a  sub rsp, 0x30
0000705c56fd452e  movaps [rsp], xmm11
0000705c56fd4533  movaps [rsp+0x10], xmm7
0000705c56fd4538  movaps [rsp+0x20], xmm15
0000705c56fd453e  lea rdi, [rsp]
0000705c56fd4542  mov esi, 0x00
0000705c56fd4547  mov rax, 0x5877D3629530
0000705c56fd4551  call rax
0000705c56fd4553  movaps xmm11, [rsp]
0000705c56fd4558  add rsp, 0x30
0000705c56fd455c  vmovaps xmm0, [rsp]
0000705c56fd4561  vmovaps xmm1, [rsp+0x10]
0000705c56fd4567  vmovaps xmm2, [rsp+0x20]
0000705c56fd456d  vmovaps xmm3, [rsp+0x30]
0000705c56fd4573  vmovaps xmm4, [rsp+0x40]
0000705c56fd4579  vmovaps xmm5, [rsp+0x50]
0000705c56fd457f  vmovaps xmm6, [rsp+0x60]
0000705c56fd4585  vmovaps xmm7, [rsp+0x70]
0000705c56fd458b  vmovaps xmm8, [rsp+0x80]
0000705c56fd4594  vmovaps xmm9, [rsp+0x90]
0000705c56fd459d  vmovaps xmm10, [rsp+0xA0]
0000705c56fd45a6  vmovaps xmm12, [rsp+0xB0]
0000705c56fd45af  vmovaps xmm13, [rsp+0xC0]
0000705c56fd45b8  vmovaps xmm14, [rsp+0xD0]
0000705c56fd45c1  vmovaps xmm15, [rsp+0xE0]
0000705c56fd45ca  add rsp, 0xF0
0000705c56fd45d1  pop r11
0000705c56fd45d3  pop r10
0000705c56fd45d5  pop r9
0000705c56fd45d7  pop r8
0000705c56fd45d9  pop rsi
0000705c56fd45da  pop rdi
0000705c56fd45db  pop rdx
0000705c56fd45dc  pop rcx
0000705c56fd45dd  pop rax
0000705c56fd45de  add rsp, 0x08
0000705c56fd45e2  jmp 0x0000705C56FD0123
0000705c56fd45e7  sub rsp, 0x08
0000705c56fd45eb  push rax
0000705c56fd45ec  push rcx
0000705c56fd45ed  push rdx
0000705c56fd45ee  push rdi
0000705c56fd45ef  push rsi
0000705c56fd45f0  push r8
0000705c56fd45f2  push r9
0000705c56fd45f4  push r10
0000705c56fd45f6  push r11
0000705c56fd45f8  sub rsp, 0xF0
0000705c56fd45ff  vmovaps [rsp], xmm0
0000705c56fd4604  vmovaps [rsp+0x10], xmm1
0000705c56fd460a  vmovaps [rsp+0x20], xmm2
0000705c56fd4610  vmovaps [rsp+0x30], xmm3
0000705c56fd4616  vmovaps [rsp+0x40], xmm4
0000705c56fd461c  vmovaps [rsp+0x50], xmm5
0000705c56fd4622  vmovaps [rsp+0x60], xmm6
0000705c56fd4628  vmovaps [rsp+0x70], xmm7
0000705c56fd462e  vmovaps [rsp+0x80], xmm8
0000705c56fd4637  vmovaps [rsp+0x90], xmm9
0000705c56fd4640  vmovaps [rsp+0xA0], xmm10
0000705c56fd4649  vmovaps [rsp+0xB0], xmm11
0000705c56fd4652  vmovaps [rsp+0xC0], xmm12
0000705c56fd465b  vmovaps [rsp+0xD0], xmm13
0000705c56fd4664  vmovaps [rsp+0xE0], xmm14
0000705c56fd466d  sub rsp, 0x30
0000705c56fd4671  movaps [rsp], xmm15
0000705c56fd4676  movaps [rsp+0x10], xmm10
0000705c56fd467c  movaps [rsp+0x20], xmm13
0000705c56fd4682  lea rdi, [rsp]
0000705c56fd4686  mov esi, 0x00
0000705c56fd468b  mov rax, 0x5877D3629530
0000705c56fd4695  call rax
0000705c56fd4697  movaps xmm15, [rsp]
0000705c56fd469c  add rsp, 0x30
0000705c56fd46a0  vmovaps xmm0, [rsp]
0000705c56fd46a5  vmovaps xmm1, [rsp+0x10]
0000705c56fd46ab  vmovaps xmm2, [rsp+0x20]
0000705c56fd46b1  vmovaps xmm3, [rsp+0x30]
0000705c56fd46b7  vmovaps xmm4, [rsp+0x40]
0000705c56fd46bd  vmovaps xmm5, [rsp+0x50]
0000705c56fd46c3  vmovaps xmm6, [rsp+0x60]
0000705c56fd46c9  vmovaps xmm7, [rsp+0x70]
0000705c56fd46cf  vmovaps xmm8, [rsp+0x80]
0000705c56fd46d8  vmovaps xmm9, [rsp+0x90]
0000705c56fd46e1  vmovaps xmm10, [rsp+0xA0]
0000705c56fd46ea  vmovaps xmm11, [rsp+0xB0]
0000705c56fd46f3  vmovaps xmm12, [rsp+0xC0]
0000705c56fd46fc  vmovaps xmm13, [rsp+0xD0]
0000705c56fd4705  vmovaps xmm14, [rsp+0xE0]
0000705c56fd470e  add rsp, 0xF0
0000705c56fd4715  pop r11
0000705c56fd4717  pop r10
0000705c56fd4719  pop r9
0000705c56fd471b  pop r8
0000705c56fd471d  pop rsi
0000705c56fd471e  pop rdi
0000705c56fd471f  pop rdx
0000705c56fd4720  pop rcx
0000705c56fd4721  pop rax
0000705c56fd4722  add rsp, 0x08
0000705c56fd4726  jmp 0x0000705C56FD013D
0000705c56fd472b  sub rsp, 0x08
0000705c56fd472f  push rax
0000705c56fd4730  push rcx
0000705c56fd4731  push rdx
0000705c56fd4732  push rdi
0000705c56fd4733  push rsi
0000705c56fd4734  push r8
0000705c56fd4736  push r9
0000705c56fd4738  push r10
0000705c56fd473a  push r11
0000705c56fd473c  sub rsp, 0xF0
0000705c56fd4743  vmovaps [rsp], xmm0
0000705c56fd4748  vmovaps [rsp+0x10], xmm1
0000705c56fd474e  vmovaps [rsp+0x20], xmm2
0000705c56fd4754  vmovaps [rsp+0x30], xmm3
0000705c56fd475a  vmovaps [rsp+0x40], xmm4
0000705c56fd4760  vmovaps [rsp+0x50], xmm5
0000705c56fd4766  vmovaps [rsp+0x60], xmm6
0000705c56fd476c  vmovaps [rsp+0x70], xmm7
0000705c56fd4772  vmovaps [rsp+0x80], xmm8
0000705c56fd477b  vmovaps [rsp+0x90], xmm9
0000705c56fd4784  vmovaps [rsp+0xA0], xmm11
0000705c56fd478d  vmovaps [rsp+0xB0], xmm12
0000705c56fd4796  vmovaps [rsp+0xC0], xmm13
0000705c56fd479f  vmovaps [rsp+0xD0], xmm14
0000705c56fd47a8  vmovaps [rsp+0xE0], xmm15
0000705c56fd47b1  sub rsp, 0x30
0000705c56fd47b5  movaps [rsp], xmm10
0000705c56fd47ba  movaps [rsp+0x10], xmm7
0000705c56fd47bf  movaps [rsp+0x20], xmm13
0000705c56fd47c5  lea rdi, [rsp]
0000705c56fd47c9  mov esi, 0x00
0000705c56fd47ce  mov rax, 0x5877D3629530
0000705c56fd47d8  call rax
0000705c56fd47da  movaps xmm10, [rsp]
0000705c56fd47df  add rsp, 0x30
0000705c56fd47e3  vmovaps xmm0, [rsp]
0000705c56fd47e8  vmovaps xmm1, [rsp+0x10]
0000705c56fd47ee  vmovaps xmm2, [rsp+0x20]
0000705c56fd47f4  vmovaps xmm3, [rsp+0x30]
0000705c56fd47fa  vmovaps xmm4, [rsp+0x40]
0000705c56fd4800  vmovaps xmm5, [rsp+0x50]
0000705c56fd4806  vmovaps xmm6, [rsp+0x60]
0000705c56fd480c  vmovaps xmm7, [rsp+0x70]
0000705c56fd4812  vmovaps xmm8, [rsp+0x80]
0000705c56fd481b  vmovaps xmm9, [rsp+0x90]
0000705c56fd4824  vmovaps xmm11, [rsp+0xA0]
0000705c56fd482d  vmovaps xmm12, [rsp+0xB0]
0000705c56fd4836  vmovaps xmm13, [rsp+0xC0]
0000705c56fd483f  vmovaps xmm14, [rsp+0xD0]
0000705c56fd4848  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4851  add rsp, 0xF0
0000705c56fd4858  pop r11
0000705c56fd485a  pop r10
0000705c56fd485c  pop r9
0000705c56fd485e  pop r8
0000705c56fd4860  pop rsi
0000705c56fd4861  pop rdi
0000705c56fd4862  pop rdx
0000705c56fd4863  pop rcx
0000705c56fd4864  pop rax
0000705c56fd4865  add rsp, 0x08
0000705c56fd4869  jmp 0x0000705C56FD0169
0000705c56fd486e  sub rsp, 0x08
0000705c56fd4872  push rax
0000705c56fd4873  push rcx
0000705c56fd4874  push rdx
0000705c56fd4875  push rdi
0000705c56fd4876  push rsi
0000705c56fd4877  push r8
0000705c56fd4879  push r9
0000705c56fd487b  push r10
0000705c56fd487d  push r11
0000705c56fd487f  sub rsp, 0xF0
0000705c56fd4886  vmovaps [rsp], xmm0
0000705c56fd488b  vmovaps [rsp+0x10], xmm1
0000705c56fd4891  vmovaps [rsp+0x20], xmm2
0000705c56fd4897  vmovaps [rsp+0x30], xmm3
0000705c56fd489d  vmovaps [rsp+0x40], xmm4
0000705c56fd48a3  vmovaps [rsp+0x50], xmm5
0000705c56fd48a9  vmovaps [rsp+0x60], xmm6
0000705c56fd48af  vmovaps [rsp+0x70], xmm7
0000705c56fd48b5  vmovaps [rsp+0x80], xmm8
0000705c56fd48be  vmovaps [rsp+0x90], xmm9
0000705c56fd48c7  vmovaps [rsp+0xA0], xmm10
0000705c56fd48d0  vmovaps [rsp+0xB0], xmm11
0000705c56fd48d9  vmovaps [rsp+0xC0], xmm12
0000705c56fd48e2  vmovaps [rsp+0xD0], xmm14
0000705c56fd48eb  vmovaps [rsp+0xE0], xmm15
0000705c56fd48f4  sub rsp, 0x30
0000705c56fd48f8  movaps [rsp], xmm13
0000705c56fd48fd  movaps [rsp+0x10], xmm1
0000705c56fd4902  movaps [rsp+0x20], xmm8
0000705c56fd4908  lea rdi, [rsp]
0000705c56fd490c  mov esi, 0x00
0000705c56fd4911  mov rax, 0x5877D3629530
0000705c56fd491b  call rax
0000705c56fd491d  movaps xmm13, [rsp]
0000705c56fd4922  add rsp, 0x30
0000705c56fd4926  vmovaps xmm0, [rsp]
0000705c56fd492b  vmovaps xmm1, [rsp+0x10]
0000705c56fd4931  vmovaps xmm2, [rsp+0x20]
0000705c56fd4937  vmovaps xmm3, [rsp+0x30]
0000705c56fd493d  vmovaps xmm4, [rsp+0x40]
0000705c56fd4943  vmovaps xmm5, [rsp+0x50]
0000705c56fd4949  vmovaps xmm6, [rsp+0x60]
0000705c56fd494f  vmovaps xmm7, [rsp+0x70]
0000705c56fd4955  vmovaps xmm8, [rsp+0x80]
0000705c56fd495e  vmovaps xmm9, [rsp+0x90]
0000705c56fd4967  vmovaps xmm10, [rsp+0xA0]
0000705c56fd4970  vmovaps xmm11, [rsp+0xB0]
0000705c56fd4979  vmovaps xmm12, [rsp+0xC0]
0000705c56fd4982  vmovaps xmm14, [rsp+0xD0]
0000705c56fd498b  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4994  add rsp, 0xF0
0000705c56fd499b  pop r11
0000705c56fd499d  pop r10
0000705c56fd499f  pop r9
0000705c56fd49a1  pop r8
0000705c56fd49a3  pop rsi
0000705c56fd49a4  pop rdi
0000705c56fd49a5  pop rdx
0000705c56fd49a6  pop rcx
0000705c56fd49a7  pop rax
0000705c56fd49a8  add rsp, 0x08
0000705c56fd49ac  jmp 0x0000705C56FD0183
0000705c56fd49b1  call 0x0000705C56DFF430
0000705c56fd49b6  jmp 0x0000705C56FD018D
0000705c56fd49bb  sub rsp, 0x08
0000705c56fd49bf  push rax
0000705c56fd49c0  push rcx
0000705c56fd49c1  push rdx
0000705c56fd49c2  push rdi
0000705c56fd49c3  push rsi
0000705c56fd49c4  push r8
0000705c56fd49c6  push r9
0000705c56fd49c8  push r10
0000705c56fd49ca  push r11
0000705c56fd49cc  sub rsp, 0xF0
0000705c56fd49d3  vmovaps [rsp], xmm0
0000705c56fd49d8  vmovaps [rsp+0x10], xmm1
0000705c56fd49de  vmovaps [rsp+0x20], xmm2
0000705c56fd49e4  vmovaps [rsp+0x30], xmm3
0000705c56fd49ea  vmovaps [rsp+0x40], xmm4
0000705c56fd49f0  vmovaps [rsp+0x50], xmm5
0000705c56fd49f6  vmovaps [rsp+0x60], xmm6
0000705c56fd49fc  vmovaps [rsp+0x70], xmm7
0000705c56fd4a02  vmovaps [rsp+0x80], xmm9
0000705c56fd4a0b  vmovaps [rsp+0x90], xmm10
0000705c56fd4a14  vmovaps [rsp+0xA0], xmm11
0000705c56fd4a1d  vmovaps [rsp+0xB0], xmm12
0000705c56fd4a26  vmovaps [rsp+0xC0], xmm13
0000705c56fd4a2f  vmovaps [rsp+0xD0], xmm14
0000705c56fd4a38  vmovaps [rsp+0xE0], xmm15
0000705c56fd4a41  sub rsp, 0x30
0000705c56fd4a45  movaps [rsp], xmm8
0000705c56fd4a4a  movaps [rsp+0x10], xmm14
0000705c56fd4a50  movaps [rsp+0x20], xmm9
0000705c56fd4a56  lea rdi, [rsp]
0000705c56fd4a5a  mov esi, 0x00
0000705c56fd4a5f  mov rax, 0x5877D3629530
0000705c56fd4a69  call rax
0000705c56fd4a6b  movaps xmm8, [rsp]
0000705c56fd4a70  add rsp, 0x30
0000705c56fd4a74  vmovaps xmm0, [rsp]
0000705c56fd4a79  vmovaps xmm1, [rsp+0x10]
0000705c56fd4a7f  vmovaps xmm2, [rsp+0x20]
0000705c56fd4a85  vmovaps xmm3, [rsp+0x30]
0000705c56fd4a8b  vmovaps xmm4, [rsp+0x40]
0000705c56fd4a91  vmovaps xmm5, [rsp+0x50]
0000705c56fd4a97  vmovaps xmm6, [rsp+0x60]
0000705c56fd4a9d  vmovaps xmm7, [rsp+0x70]
0000705c56fd4aa3  vmovaps xmm9, [rsp+0x80]
0000705c56fd4aac  vmovaps xmm10, [rsp+0x90]
0000705c56fd4ab5  vmovaps xmm11, [rsp+0xA0]
0000705c56fd4abe  vmovaps xmm12, [rsp+0xB0]
0000705c56fd4ac7  vmovaps xmm13, [rsp+0xC0]
0000705c56fd4ad0  vmovaps xmm14, [rsp+0xD0]
0000705c56fd4ad9  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4ae2  add rsp, 0xF0
0000705c56fd4ae9  pop r11
0000705c56fd4aeb  pop r10
0000705c56fd4aed  pop r9
0000705c56fd4aef  pop r8
0000705c56fd4af1  pop rsi
0000705c56fd4af2  pop rdi
0000705c56fd4af3  pop rdx
0000705c56fd4af4  pop rcx
0000705c56fd4af5  pop rax
0000705c56fd4af6  add rsp, 0x08
0000705c56fd4afa  jmp 0x0000705C56FD01AF
0000705c56fd4aff  sub rsp, 0x08
0000705c56fd4b03  push rax
0000705c56fd4b04  push rcx
0000705c56fd4b05  push rdx
0000705c56fd4b06  push rdi
0000705c56fd4b07  push rsi
0000705c56fd4b08  push r8
0000705c56fd4b0a  push r9
0000705c56fd4b0c  push r10
0000705c56fd4b0e  push r11
0000705c56fd4b10  sub rsp, 0xF0
0000705c56fd4b17  vmovaps [rsp], xmm0
0000705c56fd4b1c  vmovaps [rsp+0x10], xmm1
0000705c56fd4b22  vmovaps [rsp+0x20], xmm2
0000705c56fd4b28  vmovaps [rsp+0x30], xmm3
0000705c56fd4b2e  vmovaps [rsp+0x40], xmm4
0000705c56fd4b34  vmovaps [rsp+0x50], xmm5
0000705c56fd4b3a  vmovaps [rsp+0x60], xmm6
0000705c56fd4b40  vmovaps [rsp+0x70], xmm7
0000705c56fd4b46  vmovaps [rsp+0x80], xmm8
0000705c56fd4b4f  vmovaps [rsp+0x90], xmm10
0000705c56fd4b58  vmovaps [rsp+0xA0], xmm11
0000705c56fd4b61  vmovaps [rsp+0xB0], xmm12
0000705c56fd4b6a  vmovaps [rsp+0xC0], xmm13
0000705c56fd4b73  vmovaps [rsp+0xD0], xmm14
0000705c56fd4b7c  vmovaps [rsp+0xE0], xmm15
0000705c56fd4b85  sub rsp, 0x30
0000705c56fd4b89  movaps [rsp], xmm9
0000705c56fd4b8e  movaps [rsp+0x10], xmm1
0000705c56fd4b93  movaps [rsp+0x20], xmm14
0000705c56fd4b99  lea rdi, [rsp]
0000705c56fd4b9d  mov esi, 0x00
0000705c56fd4ba2  mov rax, 0x5877D3629530
0000705c56fd4bac  call rax
0000705c56fd4bae  movaps xmm9, [rsp]
0000705c56fd4bb3  add rsp, 0x30
0000705c56fd4bb7  vmovaps xmm0, [rsp]
0000705c56fd4bbc  vmovaps xmm1, [rsp+0x10]
0000705c56fd4bc2  vmovaps xmm2, [rsp+0x20]
0000705c56fd4bc8  vmovaps xmm3, [rsp+0x30]
0000705c56fd4bce  vmovaps xmm4, [rsp+0x40]
0000705c56fd4bd4  vmovaps xmm5, [rsp+0x50]
0000705c56fd4bda  vmovaps xmm6, [rsp+0x60]
0000705c56fd4be0  vmovaps xmm7, [rsp+0x70]
0000705c56fd4be6  vmovaps xmm8, [rsp+0x80]
0000705c56fd4bef  vmovaps xmm10, [rsp+0x90]
0000705c56fd4bf8  vmovaps xmm11, [rsp+0xA0]
0000705c56fd4c01  vmovaps xmm12, [rsp+0xB0]
0000705c56fd4c0a  vmovaps xmm13, [rsp+0xC0]
0000705c56fd4c13  vmovaps xmm14, [rsp+0xD0]
0000705c56fd4c1c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4c25  add rsp, 0xF0
0000705c56fd4c2c  pop r11
0000705c56fd4c2e  pop r10
0000705c56fd4c30  pop r9
0000705c56fd4c32  pop r8
0000705c56fd4c34  pop rsi
0000705c56fd4c35  pop rdi
0000705c56fd4c36  pop rdx
0000705c56fd4c37  pop rcx
0000705c56fd4c38  pop rax
0000705c56fd4c39  add rsp, 0x08
0000705c56fd4c3d  jmp 0x0000705C56FD01DD
0000705c56fd4c42  sub rsp, 0x08
0000705c56fd4c46  push rax
0000705c56fd4c47  push rcx
0000705c56fd4c48  push rdx
0000705c56fd4c49  push rdi
0000705c56fd4c4a  push rsi
0000705c56fd4c4b  push r8
0000705c56fd4c4d  push r9
0000705c56fd4c4f  push r10
0000705c56fd4c51  push r11
0000705c56fd4c53  sub rsp, 0xF0
0000705c56fd4c5a  vmovaps [rsp], xmm0
0000705c56fd4c5f  vmovaps [rsp+0x10], xmm1
0000705c56fd4c65  vmovaps [rsp+0x20], xmm2
0000705c56fd4c6b  vmovaps [rsp+0x30], xmm3
0000705c56fd4c71  vmovaps [rsp+0x40], xmm4
0000705c56fd4c77  vmovaps [rsp+0x50], xmm5
0000705c56fd4c7d  vmovaps [rsp+0x60], xmm6
0000705c56fd4c83  vmovaps [rsp+0x70], xmm7
0000705c56fd4c89  vmovaps [rsp+0x80], xmm8
0000705c56fd4c92  vmovaps [rsp+0x90], xmm9
0000705c56fd4c9b  vmovaps [rsp+0xA0], xmm10
0000705c56fd4ca4  vmovaps [rsp+0xB0], xmm11
0000705c56fd4cad  vmovaps [rsp+0xC0], xmm12
0000705c56fd4cb6  vmovaps [rsp+0xD0], xmm13
0000705c56fd4cbf  vmovaps [rsp+0xE0], xmm15
0000705c56fd4cc8  sub rsp, 0x30
0000705c56fd4ccc  movaps [rsp], xmm14
0000705c56fd4cd1  movaps [rsp+0x10], xmm4
0000705c56fd4cd6  movaps [rsp+0x20], xmm1
0000705c56fd4cdb  lea rdi, [rsp]
0000705c56fd4cdf  mov esi, 0x00
0000705c56fd4ce4  mov rax, 0x5877D3629530
0000705c56fd4cee  call rax
0000705c56fd4cf0  movaps xmm14, [rsp]
0000705c56fd4cf5  add rsp, 0x30
0000705c56fd4cf9  vmovaps xmm0, [rsp]
0000705c56fd4cfe  vmovaps xmm1, [rsp+0x10]
0000705c56fd4d04  vmovaps xmm2, [rsp+0x20]
0000705c56fd4d0a  vmovaps xmm3, [rsp+0x30]
0000705c56fd4d10  vmovaps xmm4, [rsp+0x40]
0000705c56fd4d16  vmovaps xmm5, [rsp+0x50]
0000705c56fd4d1c  vmovaps xmm6, [rsp+0x60]
0000705c56fd4d22  vmovaps xmm7, [rsp+0x70]
0000705c56fd4d28  vmovaps xmm8, [rsp+0x80]
0000705c56fd4d31  vmovaps xmm9, [rsp+0x90]
0000705c56fd4d3a  vmovaps xmm10, [rsp+0xA0]
0000705c56fd4d43  vmovaps xmm11, [rsp+0xB0]
0000705c56fd4d4c  vmovaps xmm12, [rsp+0xC0]
0000705c56fd4d55  vmovaps xmm13, [rsp+0xD0]
0000705c56fd4d5e  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4d67  add rsp, 0xF0
0000705c56fd4d6e  pop r11
0000705c56fd4d70  pop r10
0000705c56fd4d72  pop r9
0000705c56fd4d74  pop r8
0000705c56fd4d76  pop rsi
0000705c56fd4d77  pop rdi
0000705c56fd4d78  pop rdx
0000705c56fd4d79  pop rcx
0000705c56fd4d7a  pop rax
0000705c56fd4d7b  add rsp, 0x08
0000705c56fd4d7f  jmp 0x0000705C56FD0203
0000705c56fd4d84  sub rsp, 0x08
0000705c56fd4d88  push rax
0000705c56fd4d89  push rcx
0000705c56fd4d8a  push rdx
0000705c56fd4d8b  push rdi
0000705c56fd4d8c  push rsi
0000705c56fd4d8d  push r8
0000705c56fd4d8f  push r9
0000705c56fd4d91  push r10
0000705c56fd4d93  push r11
0000705c56fd4d95  sub rsp, 0xF0
0000705c56fd4d9c  vmovaps [rsp], xmm0
0000705c56fd4da1  vmovaps [rsp+0x10], xmm2
0000705c56fd4da7  vmovaps [rsp+0x20], xmm3
0000705c56fd4dad  vmovaps [rsp+0x30], xmm4
0000705c56fd4db3  vmovaps [rsp+0x40], xmm5
0000705c56fd4db9  vmovaps [rsp+0x50], xmm6
0000705c56fd4dbf  vmovaps [rsp+0x60], xmm7
0000705c56fd4dc5  vmovaps [rsp+0x70], xmm8
0000705c56fd4dcb  vmovaps [rsp+0x80], xmm9
0000705c56fd4dd4  vmovaps [rsp+0x90], xmm10
0000705c56fd4ddd  vmovaps [rsp+0xA0], xmm11
0000705c56fd4de6  vmovaps [rsp+0xB0], xmm12
0000705c56fd4def  vmovaps [rsp+0xC0], xmm13
0000705c56fd4df8  vmovaps [rsp+0xD0], xmm14
0000705c56fd4e01  vmovaps [rsp+0xE0], xmm15
0000705c56fd4e0a  sub rsp, 0x30
0000705c56fd4e0e  movaps [rsp], xmm1
0000705c56fd4e12  movaps [rsp+0x10], xmm12
0000705c56fd4e18  movaps [rsp+0x20], xmm11
0000705c56fd4e1e  lea rdi, [rsp]
0000705c56fd4e22  mov esi, 0x00
0000705c56fd4e27  mov rax, 0x5877D3629530
0000705c56fd4e31  call rax
0000705c56fd4e33  movaps xmm1, [rsp]
0000705c56fd4e37  add rsp, 0x30
0000705c56fd4e3b  vmovaps xmm0, [rsp]
0000705c56fd4e40  vmovaps xmm2, [rsp+0x10]
0000705c56fd4e46  vmovaps xmm3, [rsp+0x20]
0000705c56fd4e4c  vmovaps xmm4, [rsp+0x30]
0000705c56fd4e52  vmovaps xmm5, [rsp+0x40]
0000705c56fd4e58  vmovaps xmm6, [rsp+0x50]
0000705c56fd4e5e  vmovaps xmm7, [rsp+0x60]
0000705c56fd4e64  vmovaps xmm8, [rsp+0x70]
0000705c56fd4e6a  vmovaps xmm9, [rsp+0x80]
0000705c56fd4e73  vmovaps xmm10, [rsp+0x90]
0000705c56fd4e7c  vmovaps xmm11, [rsp+0xA0]
0000705c56fd4e85  vmovaps xmm12, [rsp+0xB0]
0000705c56fd4e8e  vmovaps xmm13, [rsp+0xC0]
0000705c56fd4e97  vmovaps xmm14, [rsp+0xD0]
0000705c56fd4ea0  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4ea9  add rsp, 0xF0
0000705c56fd4eb0  pop r11
0000705c56fd4eb2  pop r10
0000705c56fd4eb4  pop r9
0000705c56fd4eb6  pop r8
0000705c56fd4eb8  pop rsi
0000705c56fd4eb9  pop rdi
0000705c56fd4eba  pop rdx
0000705c56fd4ebb  pop rcx
0000705c56fd4ebc  pop rax
0000705c56fd4ebd  add rsp, 0x08
0000705c56fd4ec1  jmp 0x0000705C56FD0224
0000705c56fd4ec6  call 0x0000705C56EE20A0
0000705c56fd4ecb  jmp 0x0000705C56FD0232
0000705c56fd4ed0  call 0x0000705C56E09D70
0000705c56fd4ed5  jmp 0x0000705C56FD023C
0000705c56fd4eda  sub rsp, 0x08
0000705c56fd4ede  push rax
0000705c56fd4edf  push rcx
0000705c56fd4ee0  push rdx
0000705c56fd4ee1  push rdi
0000705c56fd4ee2  push rsi
0000705c56fd4ee3  push r8
0000705c56fd4ee5  push r9
0000705c56fd4ee7  push r10
0000705c56fd4ee9  push r11
0000705c56fd4eeb  sub rsp, 0xF0
0000705c56fd4ef2  vmovaps [rsp], xmm0
0000705c56fd4ef7  vmovaps [rsp+0x10], xmm1
0000705c56fd4efd  vmovaps [rsp+0x20], xmm2
0000705c56fd4f03  vmovaps [rsp+0x30], xmm3
0000705c56fd4f09  vmovaps [rsp+0x40], xmm4
0000705c56fd4f0f  vmovaps [rsp+0x50], xmm5
0000705c56fd4f15  vmovaps [rsp+0x60], xmm6
0000705c56fd4f1b  vmovaps [rsp+0x70], xmm8
0000705c56fd4f21  vmovaps [rsp+0x80], xmm9
0000705c56fd4f2a  vmovaps [rsp+0x90], xmm10
0000705c56fd4f33  vmovaps [rsp+0xA0], xmm11
0000705c56fd4f3c  vmovaps [rsp+0xB0], xmm12
0000705c56fd4f45  vmovaps [rsp+0xC0], xmm13
0000705c56fd4f4e  vmovaps [rsp+0xD0], xmm14
0000705c56fd4f57  vmovaps [rsp+0xE0], xmm15
0000705c56fd4f60  sub rsp, 0x30
0000705c56fd4f64  movaps [rsp], xmm7
0000705c56fd4f68  movaps [rsp+0x10], xmm15
0000705c56fd4f6e  movaps [rsp+0x20], xmm10
0000705c56fd4f74  lea rdi, [rsp]
0000705c56fd4f78  mov esi, 0x00
0000705c56fd4f7d  mov rax, 0x5877D3629530
0000705c56fd4f87  call rax
0000705c56fd4f89  movaps xmm7, [rsp]
0000705c56fd4f8d  add rsp, 0x30
0000705c56fd4f91  vmovaps xmm0, [rsp]
0000705c56fd4f96  vmovaps xmm1, [rsp+0x10]
0000705c56fd4f9c  vmovaps xmm2, [rsp+0x20]
0000705c56fd4fa2  vmovaps xmm3, [rsp+0x30]
0000705c56fd4fa8  vmovaps xmm4, [rsp+0x40]
0000705c56fd4fae  vmovaps xmm5, [rsp+0x50]
0000705c56fd4fb4  vmovaps xmm6, [rsp+0x60]
0000705c56fd4fba  vmovaps xmm8, [rsp+0x70]
0000705c56fd4fc0  vmovaps xmm9, [rsp+0x80]
0000705c56fd4fc9  vmovaps xmm10, [rsp+0x90]
0000705c56fd4fd2  vmovaps xmm11, [rsp+0xA0]
0000705c56fd4fdb  vmovaps xmm12, [rsp+0xB0]
0000705c56fd4fe4  vmovaps xmm13, [rsp+0xC0]
0000705c56fd4fed  vmovaps xmm14, [rsp+0xD0]
0000705c56fd4ff6  vmovaps xmm15, [rsp+0xE0]
0000705c56fd4fff  add rsp, 0xF0
0000705c56fd5006  pop r11
0000705c56fd5008  pop r10
0000705c56fd500a  pop r9
0000705c56fd500c  pop r8
0000705c56fd500e  pop rsi
0000705c56fd500f  pop rdi
0000705c56fd5010  pop rdx
0000705c56fd5011  pop rcx
0000705c56fd5012  pop rax
0000705c56fd5013  add rsp, 0x08
0000705c56fd5017  jmp 0x0000705C56FD025D
0000705c56fd501c  sub rsp, 0x08
0000705c56fd5020  push rax
0000705c56fd5021  push rcx
0000705c56fd5022  push rdx
0000705c56fd5023  push rdi
0000705c56fd5024  push rsi
0000705c56fd5025  push r8
0000705c56fd5027  push r9
0000705c56fd5029  push r10
0000705c56fd502b  push r11
0000705c56fd502d  sub rsp, 0xF0
0000705c56fd5034  vmovaps [rsp], xmm0
0000705c56fd5039  vmovaps [rsp+0x10], xmm1
0000705c56fd503f  vmovaps [rsp+0x20], xmm2
0000705c56fd5045  vmovaps [rsp+0x30], xmm3
0000705c56fd504b  vmovaps [rsp+0x40], xmm4
0000705c56fd5051  vmovaps [rsp+0x50], xmm5
0000705c56fd5057  vmovaps [rsp+0x60], xmm6
0000705c56fd505d  vmovaps [rsp+0x70], xmm7
0000705c56fd5063  vmovaps [rsp+0x80], xmm8
0000705c56fd506c  vmovaps [rsp+0x90], xmm9
0000705c56fd5075  vmovaps [rsp+0xA0], xmm11
0000705c56fd507e  vmovaps [rsp+0xB0], xmm12
0000705c56fd5087  vmovaps [rsp+0xC0], xmm13
0000705c56fd5090  vmovaps [rsp+0xD0], xmm14
0000705c56fd5099  vmovaps [rsp+0xE0], xmm15
0000705c56fd50a2  sub rsp, 0x30
0000705c56fd50a6  movaps [rsp], xmm10
0000705c56fd50ab  movaps [rsp+0x10], xmm11
0000705c56fd50b1  movaps [rsp+0x20], xmm15
0000705c56fd50b7  lea rdi, [rsp]
0000705c56fd50bb  mov esi, 0x00
0000705c56fd50c0  mov rax, 0x5877D3629530
0000705c56fd50ca  call rax
0000705c56fd50cc  movaps xmm10, [rsp]
0000705c56fd50d1  add rsp, 0x30
0000705c56fd50d5  vmovaps xmm0, [rsp]
0000705c56fd50da  vmovaps xmm1, [rsp+0x10]
0000705c56fd50e0  vmovaps xmm2, [rsp+0x20]
0000705c56fd50e6  vmovaps xmm3, [rsp+0x30]
0000705c56fd50ec  vmovaps xmm4, [rsp+0x40]
0000705c56fd50f2  vmovaps xmm5, [rsp+0x50]
0000705c56fd50f8  vmovaps xmm6, [rsp+0x60]
0000705c56fd50fe  vmovaps xmm7, [rsp+0x70]
0000705c56fd5104  vmovaps xmm8, [rsp+0x80]
0000705c56fd510d  vmovaps xmm9, [rsp+0x90]
0000705c56fd5116  vmovaps xmm11, [rsp+0xA0]
0000705c56fd511f  vmovaps xmm12, [rsp+0xB0]
0000705c56fd5128  vmovaps xmm13, [rsp+0xC0]
0000705c56fd5131  vmovaps xmm14, [rsp+0xD0]
0000705c56fd513a  vmovaps xmm15, [rsp+0xE0]
0000705c56fd5143  add rsp, 0xF0
0000705c56fd514a  pop r11
0000705c56fd514c  pop r10
0000705c56fd514e  pop r9
0000705c56fd5150  pop r8
0000705c56fd5152  pop rsi
0000705c56fd5153  pop rdi
0000705c56fd5154  pop rdx
0000705c56fd5155  pop rcx
0000705c56fd5156  pop rax
0000705c56fd5157  add rsp, 0x08
0000705c56fd515b  jmp 0x0000705C56FD028B
0000705c56fd5160  sub rsp, 0x08
0000705c56fd5164  push rax
0000705c56fd5165  push rcx
0000705c56fd5166  push rdx
0000705c56fd5167  push rdi
0000705c56fd5168  push rsi
0000705c56fd5169  push r8
0000705c56fd516b  push r9
0000705c56fd516d  push r10
0000705c56fd516f  push r11
0000705c56fd5171  sub rsp, 0xF0
0000705c56fd5178  vmovaps [rsp], xmm0
0000705c56fd517d  vmovaps [rsp+0x10], xmm1
0000705c56fd5183  vmovaps [rsp+0x20], xmm2
0000705c56fd5189  vmovaps [rsp+0x30], xmm3
0000705c56fd518f  vmovaps [rsp+0x40], xmm4
0000705c56fd5195  vmovaps [rsp+0x50], xmm5
0000705c56fd519b  vmovaps [rsp+0x60], xmm6
0000705c56fd51a1  vmovaps [rsp+0x70], xmm7
0000705c56fd51a7  vmovaps [rsp+0x80], xmm8
0000705c56fd51b0  vmovaps [rsp+0x90], xmm9
0000705c56fd51b9  vmovaps [rsp+0xA0], xmm10
0000705c56fd51c2  vmovaps [rsp+0xB0], xmm12
0000705c56fd51cb  vmovaps [rsp+0xC0], xmm13
0000705c56fd51d4  vmovaps [rsp+0xD0], xmm14
0000705c56fd51dd  vmovaps [rsp+0xE0], xmm15
0000705c56fd51e6  sub rsp, 0x30
0000705c56fd51ea  movaps [rsp], xmm11
0000705c56fd51ef  movaps [rsp+0x10], xmm12
0000705c56fd51f5  movaps [rsp+0x20], xmm15
0000705c56fd51fb  lea rdi, [rsp]
0000705c56fd51ff  mov esi, 0x00
0000705c56fd5204  mov rax, 0x5877D3629530
0000705c56fd520e  call rax
0000705c56fd5210  movaps xmm11, [rsp]
0000705c56fd5215  add rsp, 0x30
0000705c56fd5219  vmovaps xmm0, [rsp]
0000705c56fd521e  vmovaps xmm1, [rsp+0x10]
0000705c56fd5224  vmovaps xmm2, [rsp+0x20]
0000705c56fd522a  vmovaps xmm3, [rsp+0x30]
0000705c56fd5230  vmovaps xmm4, [rsp+0x40]
0000705c56fd5236  vmovaps xmm5, [rsp+0x50]
0000705c56fd523c  vmovaps xmm6, [rsp+0x60]
0000705c56fd5242  vmovaps xmm7, [rsp+0x70]
0000705c56fd5248  vmovaps xmm8, [rsp+0x80]
0000705c56fd5251  vmovaps xmm9, [rsp+0x90]
0000705c56fd525a  vmovaps xmm10, [rsp+0xA0]
0000705c56fd5263  vmovaps xmm12, [rsp+0xB0]
0000705c56fd526c  vmovaps xmm13, [rsp+0xC0]
0000705c56fd5275  vmovaps xmm14, [rsp+0xD0]
0000705c56fd527e  vmovaps xmm15, [rsp+0xE0]
0000705c56fd5287  add rsp, 0xF0
0000705c56fd528e  pop r11
0000705c56fd5290  pop r10
0000705c56fd5292  pop r9
0000705c56fd5294  pop r8
0000705c56fd5296  pop rsi
0000705c56fd5297  pop rdi
0000705c56fd5298  pop rdx
0000705c56fd5299  pop rcx
0000705c56fd529a  pop rax
0000705c56fd529b  add rsp, 0x08
0000705c56fd529f  jmp 0x0000705C56FD02B9
0000705c56fd52a4  sub rsp, 0x08
0000705c56fd52a8  push rax
0000705c56fd52a9  push rcx
0000705c56fd52aa  push rdx
0000705c56fd52ab  push rdi
0000705c56fd52ac  push rsi
0000705c56fd52ad  push r8
0000705c56fd52af  push r9
0000705c56fd52b1  push r10
0000705c56fd52b3  push r11
0000705c56fd52b5  sub rsp, 0xF0
0000705c56fd52bc  vmovaps [rsp], xmm0
0000705c56fd52c1  vmovaps [rsp+0x10], xmm1
0000705c56fd52c7  vmovaps [rsp+0x20], xmm2
0000705c56fd52cd  vmovaps [rsp+0x30], xmm3
0000705c56fd52d3  vmovaps [rsp+0x40], xmm4
0000705c56fd52d9  vmovaps [rsp+0x50], xmm5
0000705c56fd52df  vmovaps [rsp+0x60], xmm6
0000705c56fd52e5  vmovaps [rsp+0x70], xmm7
0000705c56fd52eb  vmovaps [rsp+0x80], xmm8
0000705c56fd52f4  vmovaps [rsp+0x90], xmm9
0000705c56fd52fd  vmovaps [rsp+0xA0], xmm10
0000705c56fd5306  vmovaps [rsp+0xB0], xmm11
0000705c56fd530f  vmovaps [rsp+0xC0], xmm12
0000705c56fd5318  vmovaps [rsp+0xD0], xmm13
0000705c56fd5321  vmovaps [rsp+0xE0], xmm14
0000705c56fd532a  sub rsp, 0x30
0000705c56fd532e  movaps [rsp], xmm15
0000705c56fd5333  movaps [rsp+0x10], xmm13
0000705c56fd5339  movaps [rsp+0x20], xmm9
0000705c56fd533f  lea rdi, [rsp]
0000705c56fd5343  mov esi, 0x00
0000705c56fd5348  mov rax, 0x5877D3629530
0000705c56fd5352  call rax
0000705c56fd5354  movaps xmm15, [rsp]
0000705c56fd5359  add rsp, 0x30
0000705c56fd535d  vmovaps xmm0, [rsp]
0000705c56fd5362  vmovaps xmm1, [rsp+0x10]
0000705c56fd5368  vmovaps xmm2, [rsp+0x20]
0000705c56fd536e  vmovaps xmm3, [rsp+0x30]
0000705c56fd5374  vmovaps xmm4, [rsp+0x40]
0000705c56fd537a  vmovaps xmm5, [rsp+0x50]
0000705c56fd5380  vmovaps xmm6, [rsp+0x60]
0000705c56fd5386  vmovaps xmm7, [rsp+0x70]
0000705c56fd538c  vmovaps xmm8, [rsp+0x80]
0000705c56fd5395  vmovaps xmm9, [rsp+0x90]
0000705c56fd539e  vmovaps xmm10, [rsp+0xA0]
0000705c56fd53a7  vmovaps xmm11, [rsp+0xB0]
0000705c56fd53b0  vmovaps xmm12, [rsp+0xC0]
0000705c56fd53b9  vmovaps xmm13, [rsp+0xD0]
0000705c56fd53c2  vmovaps xmm14, [rsp+0xE0]
0000705c56fd53cb  add rsp, 0xF0
0000705c56fd53d2  pop r11
0000705c56fd53d4  pop r10
0000705c56fd53d6  pop r9
0000705c56fd53d8  pop r8
0000705c56fd53da  pop rsi
0000705c56fd53db  pop rdi
0000705c56fd53dc  pop rdx
0000705c56fd53dd  pop rcx
0000705c56fd53de  pop rax
0000705c56fd53df  add rsp, 0x08
0000705c56fd53e3  jmp 0x0000705C56FD02D4
0000705c56fd53e8  sub rsp, 0x08
0000705c56fd53ec  push rax
0000705c56fd53ed  push rcx
0000705c56fd53ee  push rdx
0000705c56fd53ef  push rdi
0000705c56fd53f0  push rsi
0000705c56fd53f1  push r8
0000705c56fd53f3  push r9
0000705c56fd53f5  push r10
0000705c56fd53f7  push r11
0000705c56fd53f9  sub rsp, 0xF0
0000705c56fd5400  vmovaps [rsp], xmm0
0000705c56fd5405  vmovaps [rsp+0x10], xmm1
0000705c56fd540b  vmovaps [rsp+0x20], xmm2
0000705c56fd5411  vmovaps [rsp+0x30], xmm3
0000705c56fd5417  vmovaps [rsp+0x40], xmm4
0000705c56fd541d  vmovaps [rsp+0x50], xmm5
0000705c56fd5423  vmovaps [rsp+0x60], xmm6
0000705c56fd5429  vmovaps [rsp+0x70], xmm7
0000705c56fd542f  vmovaps [rsp+0x80], xmm8
0000705c56fd5438  vmovaps [rsp+0x90], xmm9
0000705c56fd5441  vmovaps [rsp+0xA0], xmm10
0000705c56fd544a  vmovaps [rsp+0xB0], xmm11
0000705c56fd5453  vmovaps [rsp+0xC0], xmm12
0000705c56fd545c  vmovaps [rsp+0xD0], xmm14
0000705c56fd5465  vmovaps [rsp+0xE0], xmm15
0000705c56fd546e  sub rsp, 0x30
0000705c56fd5472  movaps [rsp], xmm13
0000705c56fd5477  movaps [rsp+0x10], xmm8
0000705c56fd547d  movaps [rsp+0x20], xmm14
0000705c56fd5483  lea rdi, [rsp]
0000705c56fd5487  mov esi, 0x00
0000705c56fd548c  mov rax, 0x5877D3629530
0000705c56fd5496  call rax
0000705c56fd5498  movaps xmm13, [rsp]
0000705c56fd549d  add rsp, 0x30
0000705c56fd54a1  vmovaps xmm0, [rsp]
0000705c56fd54a6  vmovaps xmm1, [rsp+0x10]
0000705c56fd54ac  vmovaps xmm2, [rsp+0x20]
0000705c56fd54b2  vmovaps xmm3, [rsp+0x30]
0000705c56fd54b8  vmovaps xmm4, [rsp+0x40]
0000705c56fd54be  vmovaps xmm5, [rsp+0x50]
0000705c56fd54c4  vmovaps xmm6, [rsp+0x60]
0000705c56fd54ca  vmovaps xmm7, [rsp+0x70]
0000705c56fd54d0  vmovaps xmm8, [rsp+0x80]
0000705c56fd54d9  vmovaps xmm9, [rsp+0x90]
0000705c56fd54e2  vmovaps xmm10, [rsp+0xA0]
0000705c56fd54eb  vmovaps xmm11, [rsp+0xB0]
0000705c56fd54f4  vmovaps xmm12, [rsp+0xC0]
0000705c56fd54fd  vmovaps xmm14, [rsp+0xD0]
0000705c56fd5506  vmovaps xmm15, [rsp+0xE0]
0000705c56fd550f  add rsp, 0xF0
0000705c56fd5516  pop r11
0000705c56fd5518  pop r10
0000705c56fd551a  pop r9
0000705c56fd551c  pop r8
0000705c56fd551e  pop rsi
0000705c56fd551f  pop rdi
0000705c56fd5520  pop rdx
0000705c56fd5521  pop rcx
0000705c56fd5522  pop rax
0000705c56fd5523  add rsp, 0x08
0000705c56fd5527  jmp 0x0000705C56FD02F7
0000705c56fd552c  sub rsp, 0x08
0000705c56fd5530  push rax
0000705c56fd5531  push rcx
0000705c56fd5532  push rdx
0000705c56fd5533  push rdi
0000705c56fd5534  push rsi
0000705c56fd5535  push r8
0000705c56fd5537  push r9
0000705c56fd5539  push r10
0000705c56fd553b  push r11
0000705c56fd553d  sub rsp, 0xF0
0000705c56fd5544  vmovaps [rsp], xmm0
0000705c56fd5549  vmovaps [rsp+0x10], xmm1
0000705c56fd554f  vmovaps [rsp+0x20], xmm2
0000705c56fd5555  vmovaps [rsp+0x30], xmm3
0000705c56fd555b  vmovaps [rsp+0x40], xmm4
0000705c56fd5561  vmovaps [rsp+0x50], xmm5
0000705c56fd5567  vmovaps [rsp+0x60], xmm6
0000705c56fd556d  vmovaps [rsp+0x70], xmm7
0000705c56fd5573  vmovaps [rsp+0x80], xmm8
0000705c56fd557c  vmovaps [rsp+0x90], xmm9
0000705c56fd5585  vmovaps [rsp+0xA0], xmm10
0000705c56fd558e  vmovaps [rsp+0xB0], xmm11
0000705c56fd5597  vmovaps [rsp+0xC0], xmm12
0000705c56fd55a0  vmovaps [rsp+0xD0], xmm13
0000705c56fd55a9  vmovaps [rsp+0xE0], xmm15
0000705c56fd55b2  sub rsp, 0x30
0000705c56fd55b6  movaps [rsp], xmm14
0000705c56fd55bb  movaps [rsp+0x10], xmm1
0000705c56fd55c0  movaps [rsp+0x20], xmm10
0000705c56fd55c6  lea rdi, [rsp]
0000705c56fd55ca  mov esi, 0x00
0000705c56fd55cf  mov rax, 0x5877D3629530
0000705c56fd55d9  call rax
0000705c56fd55db  movaps xmm14, [rsp]
0000705c56fd55e0  add rsp, 0x30
0000705c56fd55e4  vmovaps xmm0, [rsp]
0000705c56fd55e9  vmovaps xmm1, [rsp+0x10]
0000705c56fd55ef  vmovaps xmm2, [rsp+0x20]
0000705c56fd55f5  vmovaps xmm3, [rsp+0x30]
0000705c56fd55fb  vmovaps xmm4, [rsp+0x40]
0000705c56fd5601  vmovaps xmm5, [rsp+0x50]
0000705c56fd5607  vmovaps xmm6, [rsp+0x60]
0000705c56fd560d  vmovaps xmm7, [rsp+0x70]
0000705c56fd5613  vmovaps xmm8, [rsp+0x80]
0000705c56fd561c  vmovaps xmm9, [rsp+0x90]
0000705c56fd5625  vmovaps xmm10, [rsp+0xA0]
0000705c56fd562e  vmovaps xmm11, [rsp+0xB0]
0000705c56fd5637  vmovaps xmm12, [rsp+0xC0]
0000705c56fd5640  vmovaps xmm13, [rsp+0xD0]
0000705c56fd5649  vmovaps xmm15, [rsp+0xE0]
0000705c56fd5652  add rsp, 0xF0
0000705c56fd5659  pop r11
0000705c56fd565b  pop r10
0000705c56fd565d  pop r9
0000705c56fd565f  pop r8
0000705c56fd5661  pop rsi
0000705c56fd5662  pop rdi
0000705c56fd5663  pop rdx
0000705c56fd5664  pop rcx
0000705c56fd5665  pop rax
0000705c56fd5666  add rsp, 0x08
0000705c56fd566a  jmp 0x0000705C56FD031A
0000705c56fd566f  sub rsp, 0x08
0000705c56fd5673  push rax
0000705c56fd5674  push rcx
0000705c56fd5675  push rdx
0000705c56fd5676  push rdi
0000705c56fd5677  push rsi
0000705c56fd5678  push r8
0000705c56fd567a  push r9
0000705c56fd567c  push r10
0000705c56fd567e  push r11
0000705c56fd5680  sub rsp, 0xF0
0000705c56fd5687  vmovaps [rsp], xmm0
0000705c56fd568c  vmovaps [rsp+0x10], xmm2
0000705c56fd5692  vmovaps [rsp+0x20], xmm3
0000705c56fd5698  vmovaps [rsp+0x30], xmm4
0000705c56fd569e  vmovaps [rsp+0x40], xmm5
0000705c56fd56a4  vmovaps [rsp+0x50], xmm6
0000705c56fd56aa  vmovaps [rsp+0x60], xmm7
0000705c56fd56b0  vmovaps [rsp+0x70], xmm8
0000705c56fd56b6  vmovaps [rsp+0x80], xmm9
0000705c56fd56bf  vmovaps [rsp+0x90], xmm10
0000705c56fd56c8  vmovaps [rsp+0xA0], xmm11
0000705c56fd56d1  vmovaps [rsp+0xB0], xmm12
0000705c56fd56da  vmovaps [rsp+0xC0], xmm13
0000705c56fd56e3  vmovaps [rsp+0xD0], xmm14
0000705c56fd56ec  vmovaps [rsp+0xE0], xmm15
0000705c56fd56f5  sub rsp, 0x30
0000705c56fd56f9  movaps [rsp], xmm1
0000705c56fd56fd  movaps [rsp+0x10], xmm7
0000705c56fd5702  movaps [rsp+0x20], xmm11
0000705c56fd5708  lea rdi, [rsp]
0000705c56fd570c  mov esi, 0x00
0000705c56fd5711  mov rax, 0x5877D3629530
0000705c56fd571b  call rax
0000705c56fd571d  movaps xmm1, [rsp]
0000705c56fd5721  add rsp, 0x30
0000705c56fd5725  vmovaps xmm0, [rsp]
0000705c56fd572a  vmovaps xmm2, [rsp+0x10]
0000705c56fd5730  vmovaps xmm3, [rsp+0x20]
0000705c56fd5736  vmovaps xmm4, [rsp+0x30]
0000705c56fd573c  vmovaps xmm5, [rsp+0x40]
0000705c56fd5742  vmovaps xmm6, [rsp+0x50]
0000705c56fd5748  vmovaps xmm7, [rsp+0x60]
0000705c56fd574e  vmovaps xmm8, [rsp+0x70]
0000705c56fd5754  vmovaps xmm9, [rsp+0x80]
0000705c56fd575d  vmovaps xmm10, [rsp+0x90]
0000705c56fd5766  vmovaps xmm11, [rsp+0xA0]
0000705c56fd576f  vmovaps xmm12, [rsp+0xB0]
0000705c56fd5778  vmovaps xmm13, [rsp+0xC0]
0000705c56fd5781  vmovaps xmm14, [rsp+0xD0]
0000705c56fd578a  vmovaps xmm15, [rsp+0xE0]
0000705c56fd5793  add rsp, 0xF0
0000705c56fd579a  pop r11
0000705c56fd579c  pop r10
0000705c56fd579e  pop r9
0000705c56fd57a0  pop r8
0000705c56fd57a2  pop rsi
0000705c56fd57a3  pop rdi
0000705c56fd57a4  pop rdx
0000705c56fd57a5  pop rcx
0000705c56fd57a6  pop rax
0000705c56fd57a7  add rsp, 0x08
0000705c56fd57ab  jmp 0x0000705C56FD033B
0000705c56fd57b0  call 0x0000705C56E0E880
0000705c56fd57b5  jmp 0x0000705C56FD034E
0000705c56fd57ba  call 0x0000705C56E0C380
0000705c56fd57bf  jmp 0x0000705C56FD0359
0000705c56fd57c4  call 0x0000705C56E0D600
0000705c56fd57c9  jmp 0x0000705C56FD0364
0000705c56fd57ce  call 0x0000705C56DFF540
0000705c56fd57d3  jmp 0x0000705C56FD036F
0000705c56fd57d8  int3
0000705c56fd57d9  nop [rax], eax
0000705c56fd57e0  mov rax, [r15+0x40]
0000705c56fd57e4  mov r14, [r15+0x58]
0000705c56fd57e8  lea r12, [rax+r14*1]
0000705c56fd57ec  movaps xmm1, [r15+0x1D0]
0000705c56fd57f4  vmovaps [rsp+0x10], xmm1
0000705c56fd57fa  vmovaps xmm15, [rsp+0x10]
0000705c56fd5800  por xmm1, xmm15
0000705c56fd5805  movaps xmm14, [r15+0x1A0]
0000705c56fd580d  vmovaps [rsp+0x10], xmm14
0000705c56fd5813  vmovaps xmm13, [rsp+0x10]
0000705c56fd5819  por xmm14, xmm13
0000705c56fd581e  lea rax, [r12+0x30]
0000705c56fd5823  mov r11, [r13+rax*1]
0000705c56fd5828  lea rax, [r12+0x38]
0000705c56fd582d  mov r10, [r13+rax*1]
0000705c56fd5832  movq xmm13, r11
0000705c56fd5837  movq xmm12, r10
0000705c56fd583c  movq xmm13, xmm13
0000705c56fd5841  vmovaps [rsp+0x10], xmm13
0000705c56fd5847  movq xmm13, xmm13
0000705c56fd584c  movaps [r15+0x130], xmm13
0000705c56fd5854  movq xmm12, xmm12
0000705c56fd5859  vmovaps [rsp+0x20], xmm12
0000705c56fd585f  movq xmm12, xmm12
0000705c56fd5864  movaps [r15+0x280], xmm12
0000705c56fd586c  movaps xmm13, [r15+0x270]
0000705c56fd5874  vmovaps [rsp+0x30], xmm13
0000705c56fd587a  vmovaps xmm12, [rsp+0x30]
0000705c56fd5880  por xmm13, xmm12
0000705c56fd5885  lea rax, [r12+0x20]
0000705c56fd588a  mov r11, [r13+rax*1]
0000705c56fd588f  lea rax, [r12+0x28]
0000705c56fd5894  mov r10, [r13+rax*1]
0000705c56fd5899  movq xmm12, r11
0000705c56fd589e  movq xmm11, r10
0000705c56fd58a3  movq xmm12, xmm12
0000705c56fd58a8  vmovaps [rsp+0x30], xmm12
0000705c56fd58ae  movq xmm12, xmm12
0000705c56fd58b3  movaps [r15+0x150], xmm12
0000705c56fd58bb  movq xmm11, xmm11
0000705c56fd58c0  vmovaps [rsp+0x40], xmm11
0000705c56fd58c6  movq xmm11, xmm11
0000705c56fd58cb  movaps [r15+0x140], xmm11
0000705c56fd58d3  lea rax, [r12+0x10]
0000705c56fd58d8  mov r11, [r13+rax*1]
0000705c56fd58dd  lea rax, [r12+0x18]
0000705c56fd58e2  mov r10, [r13+rax*1]
0000705c56fd58e7  movq xmm12, r11
0000705c56fd58ec  movq xmm11, r10
0000705c56fd58f1  movq xmm12, xmm12
0000705c56fd58f6  vmovaps [rsp+0x50], xmm12
0000705c56fd58fc  movq xmm12, xmm12
0000705c56fd5901  movaps [r15+0x170], xmm12
0000705c56fd5909  movq xmm11, xmm11
0000705c56fd590e  vmovaps [rsp+0x60], xmm11
0000705c56fd5914  movq xmm11, xmm11
0000705c56fd5919  movaps [r15+0x160], xmm11
0000705c56fd5921  mov rax, [r13+r12*1]
0000705c56fd5926  vmovq xmm12, rax
0000705c56fd592b  vpbroadcastq xmm12, xmm12
0000705c56fd5930  lea rax, [r12+0x08]
0000705c56fd5935  mov r12, [r13+rax*1]
0000705c56fd593a  movq xmm11, r12
0000705c56fd593f  movaps [r15+0x230], xmm11
0000705c56fd5947  mov rax, [r15+0xF8]
0000705c56fd594e  lea r12, [rax+0x50]
0000705c56fd5952  movups xmm11, [r13+r12*1]
0000705c56fd5958  lea r12, [rax+0x60]
0000705c56fd595c  movups xmm10, [r13+r12*1]
0000705c56fd5962  lea r12, [rax+0x30]
0000705c56fd5966  movups xmm9, [r13+r12*1]
0000705c56fd596c  mov r12, [r15+0x50]
0000705c56fd5970  lea r11, [r12+r14*1]
0000705c56fd5974  mov [r15+0x60], r11
0000705c56fd5978  lea r12, [r14+0x40]
0000705c56fd597c  mov [r15+0x58], r12
0000705c56fd5980  movaps xmm8, xmm12
0000705c56fd5984  mulpd xmm8, xmm15
0000705c56fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c56fd598f  ptest xmm7, xmm7
0000705c56fd5994  jnz 0x0000705C56FD67B7
0000705c56fd599a  movq xmm15, qword ptr [r15+0x230]
0000705c56fd59a3  vmovaps [rsp+0x70], xmm15
0000705c56fd59a9  vpermilpd xmm15, xmm15, 0x00
0000705c56fd59af  movaps xmm7, xmm9
0000705c56fd59b3  mulpd xmm7, xmm15
0000705c56fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c56fd59bd  ptest xmm6, xmm6
0000705c56fd59c2  jnz 0x0000705C56FD68FB
0000705c56fd59c8  vxorps xmm15, xmm15, xmm15
0000705c56fd59cd  vpbroadcastq xmm15, xmm15
0000705c56fd59d2  movaps xmm9, xmm12
0000705c56fd59d6  mulpd xmm9, xmm10
0000705c56fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c56fd59e1  ptest xmm6, xmm6
0000705c56fd59e6  jnz 0x0000705C56FD6A3D
0000705c56fd59ec  movaps xmm10, xmm12
0000705c56fd59f0  mulpd xmm10, xmm11
0000705c56fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c56fd59fb  ptest xmm6, xmm6
0000705c56fd5a00  jnz 0x0000705C56FD6B81
0000705c56fd5a06  movaps xmm11, [r15+0x1F0]
0000705c56fd5a0e  movaps xmm6, xmm12
0000705c56fd5a12  mulpd xmm6, xmm11
0000705c56fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c56fd5a1c  ptest xmm5, xmm5
0000705c56fd5a21  jnz 0x0000705C56FD6CC5
0000705c56fd5a27  movaps xmm12, [r15+0x2A0]
0000705c56fd5a2f  vmovaps [rsp+0x80], xmm12
0000705c56fd5a38  vmovaps xmm11, [rsp+0x80]
0000705c56fd5a41  por xmm12, xmm11
0000705c56fd5a46  movaps xmm11, [r15+0x250]
0000705c56fd5a4e  vmovaps [rsp+0x80], xmm11
0000705c56fd5a57  vmovaps xmm5, [rsp+0x80]
0000705c56fd5a60  por xmm11, xmm5
0000705c56fd5a65  vmovaps xmm4, [rsp+0x70]
0000705c56fd5a6b  vpermilpd xmm4, xmm4, 0x00
0000705c56fd5a71  movaps xmm3, xmm5
0000705c56fd5a74  mulpd xmm3, xmm4
0000705c56fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000705c56fd5a7d  ptest xmm2, xmm2
0000705c56fd5a82  jnz 0x0000705C56FD6E07
0000705c56fd5a88  mov [rsp+0x80], rax
0000705c56fd5a90  xor eax, eax
0000705c56fd5a92  mov r14d, 0x200
0000705c56fd5a98  cmp r12, r14
0000705c56fd5a9b  cmc
0000705c56fd5a9c  lahf
0000705c56fd5a9d  seto al
0000705c56fd5aa0  mov [r15+0x108], eax
0000705c56fd5aa7  movaps xmm5, xmm8
0000705c56fd5aab  addpd xmm5, xmm15
0000705c56fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000705c56fd5ab5  ptest xmm4, xmm4
0000705c56fd5aba  jnz 0x0000705C56FD6F47
0000705c56fd5ac0  movaps xmm8, [r15+0x1B0]
0000705c56fd5ac8  movaps xmm4, xmm9
0000705c56fd5acc  addpd xmm4, xmm8
0000705c56fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000705c56fd5ad6  ptest xmm2, xmm2
0000705c56fd5adb  jnz 0x0000705C56FD7089
0000705c56fd5ae1  movaps xmm9, xmm10
0000705c56fd5ae5  addpd xmm9, xmm8
0000705c56fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000705c56fd5af0  ptest xmm2, xmm2
0000705c56fd5af5  jnz 0x0000705C56FD71CB
0000705c56fd5afb  movaps xmm10, [r15+0x2F0]
0000705c56fd5b03  vmovaps [rsp+0x90], xmm10
0000705c56fd5b0c  vmovaps xmm8, [rsp+0x90]
0000705c56fd5b15  por xmm10, xmm8
0000705c56fd5b1a  movaps xmm8, [r15+0x2E0]
0000705c56fd5b22  vmovaps [rsp+0x90], xmm8
0000705c56fd5b2b  vmovaps xmm2, [rsp+0x90]
0000705c56fd5b34  por xmm8, xmm2
0000705c56fd5b39  movaps xmm2, [r15+0x2D0]
0000705c56fd5b41  vmovaps [rsp+0x90], xmm2
0000705c56fd5b4a  vmovaps [rsp+0xA0], xmm1
0000705c56fd5b53  vmovaps xmm1, [rsp+0x90]
0000705c56fd5b5c  por xmm2, xmm1
0000705c56fd5b60  movaps xmm1, [r15+0x200]
0000705c56fd5b68  vmovaps [rsp+0x90], xmm1
0000705c56fd5b71  vmovaps [rsp+0xB0], xmm15
0000705c56fd5b7a  vmovaps xmm15, [rsp+0x90]
0000705c56fd5b83  por xmm1, xmm15
0000705c56fd5b88  movaps xmm15, [r15+0x1C0]
0000705c56fd5b90  vmovaps [rsp+0x90], xmm15
0000705c56fd5b99  vmovaps [rsp+0xC0], xmm1
0000705c56fd5ba2  vmovaps xmm1, [rsp+0x90]
0000705c56fd5bab  por xmm15, xmm1
0000705c56fd5bb0  movaps xmm1, [r15+0x190]
0000705c56fd5bb8  vmovaps [rsp+0x90], xmm1
0000705c56fd5bc1  vmovaps [rsp+0xD0], xmm15
0000705c56fd5bca  vmovaps xmm15, [rsp+0x90]
0000705c56fd5bd3  por xmm1, xmm15
0000705c56fd5bd8  movaps xmm15, [r15+0x300]
0000705c56fd5be0  vmovaps [rsp+0x90], xmm15
0000705c56fd5be9  vmovaps [rsp+0xE0], xmm1
0000705c56fd5bf2  vmovaps xmm1, [rsp+0x90]
0000705c56fd5bfb  por xmm15, xmm1
0000705c56fd5c00  mov rax, [rsp+0x80]
0000705c56fd5c08  lea r14, [rax+0xA0]
0000705c56fd5c0f  movups xmm1, [r13+r14*1]
0000705c56fd5c15  lea r14, [rax+0xB0]
0000705c56fd5c1c  vmovaps [rsp+0x80], xmm1
0000705c56fd5c25  movups xmm1, [r13+r14*1]
0000705c56fd5c2b  vmovaps [rsp+0x90], xmm1
0000705c56fd5c34  vmovaps [rsp+0xF0], xmm15
0000705c56fd5c3d  vmovaps xmm15, [rsp+0xB0]
0000705c56fd5c46  vmovaps [rsp+0xB0], xmm14
0000705c56fd5c4f  movaps xmm1, xmm6
0000705c56fd5c52  addpd xmm1, xmm15
0000705c56fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c56fd5c5c  ptest xmm14, xmm14
0000705c56fd5c62  jnz 0x0000705C56FD7323
0000705c56fd5c68  lea r14, [rax+0xF0]
0000705c56fd5c6f  movups xmm15, [r13+r14*1]
0000705c56fd5c75  movaps xmm14, xmm4
0000705c56fd5c79  addpd xmm14, xmm3
0000705c56fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c56fd5c84  ptest xmm6, xmm6
0000705c56fd5c89  jnz 0x0000705C56FD746E
0000705c56fd5c8f  movaps xmm6, xmm9
0000705c56fd5c93  addpd xmm6, xmm7
0000705c56fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000705c56fd5c9c  ptest xmm4, xmm4
0000705c56fd5ca1  jnz 0x0000705C56FD75B0
0000705c56fd5ca7  vmovaps xmm9, [rsp+0x70]
0000705c56fd5cad  vpermilpd xmm9, xmm9, 0x00
0000705c56fd5cb3  vmovaps xmm4, [rsp+0x90]
0000705c56fd5cbc  movaps xmm7, xmm4
0000705c56fd5cbf  mulpd xmm7, xmm9
0000705c56fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000705c56fd5cc9  ptest xmm3, xmm3
0000705c56fd5cce  jnz 0x0000705C56FD76F1
0000705c56fd5cd4  vmovaps xmm9, [rsp+0x50]
0000705c56fd5cda  vpermilpd xmm9, xmm9, 0x00
0000705c56fd5ce0  movaps xmm4, xmm15
0000705c56fd5ce4  mulpd xmm4, xmm9
0000705c56fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c56fd5cee  ptest xmm3, xmm3
0000705c56fd5cf3  jnz 0x0000705C56FD7832
0000705c56fd5cf9  lea r14, [rax+0xE0]
0000705c56fd5d00  movups xmm15, [r13+r14*1]
0000705c56fd5d06  vmovaps xmm9, [rsp+0x70]
0000705c56fd5d0c  vpermilpd xmm9, xmm9, 0x00
0000705c56fd5d12  vmovaps [rsp+0x70], xmm1
0000705c56fd5d18  vmovaps xmm1, [rsp+0x80]
0000705c56fd5d21  vmovaps [rsp+0x80], xmm15
0000705c56fd5d2a  movaps xmm3, xmm1
0000705c56fd5d2d  mulpd xmm3, xmm9
0000705c56fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000705c56fd5d37  ptest xmm15, xmm15
0000705c56fd5d3d  jnz 0x0000705C56FD797E
0000705c56fd5d43  vmovaps xmm1, [rsp+0xF0]
0000705c56fd5d4c  vmovaps xmm15, [rsp+0xF0]
0000705c56fd5d55  por xmm1, xmm15
0000705c56fd5d5a  movaps [r15+0x300], xmm1
0000705c56fd5d62  vmovaps xmm15, [rsp+0xE0]
0000705c56fd5d6b  vmovaps xmm9, [rsp+0xE0]
0000705c56fd5d74  por xmm15, xmm9
0000705c56fd5d79  movaps [r15+0x190], xmm15
0000705c56fd5d81  vmovaps xmm9, [rsp+0x50]
0000705c56fd5d87  vpermilpd xmm9, xmm9, 0x00
0000705c56fd5d8d  vmovaps [rsp+0x90], xmm1
0000705c56fd5d96  vmovaps [rsp+0xE0], xmm15
0000705c56fd5d9f  vmovaps xmm15, [rsp+0x80]
0000705c56fd5da8  vmovaps [rsp+0x80], xmm14
0000705c56fd5db1  movaps xmm1, xmm15
0000705c56fd5db5  mulpd xmm1, xmm9
0000705c56fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c56fd5dbf  ptest xmm14, xmm14
0000705c56fd5dc5  jnz 0x0000705C56FD7ABF
0000705c56fd5dcb  lea r14, [rax+0x90]
0000705c56fd5dd2  movups xmm15, [r13+r14*1]
0000705c56fd5dd8  vmovaps xmm14, [rsp+0xD0]
0000705c56fd5de1  vmovaps xmm9, [rsp+0xD0]
0000705c56fd5dea  por xmm14, xmm9
0000705c56fd5def  movaps [r15+0x1C0], xmm14
0000705c56fd5df7  vmovaps xmm9, [rsp+0xC0]
0000705c56fd5e00  vmovaps [rsp+0xD0], xmm1
0000705c56fd5e09  vmovaps xmm1, [rsp+0xC0]
0000705c56fd5e12  por xmm9, xmm1
0000705c56fd5e17  movaps [r15+0x200], xmm9
0000705c56fd5e1f  vmovaps [rsp+0xC0], xmm2
0000705c56fd5e28  vmovaps xmm1, [rsp+0xC0]
0000705c56fd5e31  por xmm2, xmm1
0000705c56fd5e35  movaps [r15+0x2D0], xmm2
0000705c56fd5e3d  vmovaps [rsp+0xC0], xmm8
0000705c56fd5e46  vmovaps xmm1, [rsp+0xC0]
0000705c56fd5e4f  por xmm8, xmm1
0000705c56fd5e54  movaps [r15+0x2E0], xmm8
0000705c56fd5e5c  vmovaps [rsp+0xC0], xmm15
0000705c56fd5e65  movaps xmm1, xmm5
0000705c56fd5e68  addpd xmm1, xmm7
0000705c56fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c56fd5e71  ptest xmm15, xmm15
0000705c56fd5e77  jnz 0x0000705C56FD7C0B
0000705c56fd5e7d  vmovaps xmm15, [rsp+0x50]
0000705c56fd5e83  vpermilpd xmm15, xmm15, 0x00
0000705c56fd5e89  vmovaps xmm5, [rsp+0xC0]
0000705c56fd5e92  vmovaps [rsp+0xC0], xmm1
0000705c56fd5e9b  movaps xmm7, xmm5
0000705c56fd5e9e  mulpd xmm7, xmm15
0000705c56fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000705c56fd5ea8  ptest xmm1, xmm1
0000705c56fd5ead  jnz 0x0000705C56FD7D4B
0000705c56fd5eb3  lea r14, [rax+0x80]
0000705c56fd5eba  movups xmm1, [r13+r14*1]
0000705c56fd5ec0  vmovaps xmm5, [rsp+0x70]
0000705c56fd5ec6  vmovaps [rsp+0x70], xmm1
0000705c56fd5ecc  movaps xmm15, xmm5
0000705c56fd5ed0  addpd xmm15, xmm3
0000705c56fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fd5edb  ptest xmm1, xmm1
0000705c56fd5ee0  jnz 0x0000705C56FD7E96
0000705c56fd5ee6  vmovaps xmm5, [rsp+0x80]
0000705c56fd5eef  movaps xmm1, xmm5
0000705c56fd5ef2  addpd xmm1, xmm4
0000705c56fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000705c56fd5efb  ptest xmm3, xmm3
0000705c56fd5f00  jnz 0x0000705C56FD7FD8
0000705c56fd5f06  vmovaps [rsp+0x80], xmm10
0000705c56fd5f0f  vmovaps xmm5, [rsp+0x80]
0000705c56fd5f18  por xmm10, xmm5
0000705c56fd5f1d  movaps [r15+0x2F0], xmm10
0000705c56fd5f25  vmovaps xmm5, [rsp+0x50]
0000705c56fd5f2b  vpermilpd xmm5, xmm5, 0x00
0000705c56fd5f31  vmovaps xmm3, [rsp+0x70]
0000705c56fd5f37  vmovaps [rsp+0x50], xmm1
0000705c56fd5f3d  movaps xmm4, xmm3
0000705c56fd5f40  mulpd xmm4, xmm5
0000705c56fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c56fd5f49  ptest xmm1, xmm1
0000705c56fd5f4e  jnz 0x0000705C56FD8118
0000705c56fd5f54  lea r14, [rax+0xD0]
0000705c56fd5f5b  movups xmm1, [r13+r14*1]
0000705c56fd5f61  vmovaps xmm3, [rsp+0xD0]
0000705c56fd5f6a  vmovaps [rsp+0x70], xmm1
0000705c56fd5f70  movaps xmm5, xmm6
0000705c56fd5f73  addpd xmm5, xmm3
0000705c56fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000705c56fd5f7c  ptest xmm1, xmm1
0000705c56fd5f81  jnz 0x0000705C56FD8262
0000705c56fd5f87  vmovaps xmm1, [rsp+0x60]
0000705c56fd5f8d  vpermilpd xmm1, xmm1, 0x00
0000705c56fd5f93  movaps xmm6, xmm9
0000705c56fd5f97  mulpd xmm6, xmm1
0000705c56fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c56fd5fa0  ptest xmm3, xmm3
0000705c56fd5fa5  jnz 0x0000705C56FD83A2
0000705c56fd5fab  movaps [r15+0x260], xmm6
0000705c56fd5fb3  vxorps xmm1, xmm1, xmm1
0000705c56fd5fb7  vpbroadcastq xmm1, xmm1
0000705c56fd5fbc  movaps [r15+0x1B0], xmm1
0000705c56fd5fc4  vmovaps xmm1, [rsp+0x60]
0000705c56fd5fca  vpermilpd xmm1, xmm1, 0x00
0000705c56fd5fd0  vmovaps xmm3, [rsp+0x70]
0000705c56fd5fd6  vmovaps [rsp+0x70], xmm15
0000705c56fd5fdc  movaps xmm9, xmm3
0000705c56fd5fe0  mulpd xmm9, xmm1
0000705c56fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c56fd5feb  ptest xmm15, xmm15
0000705c56fd5ff1  jnz 0x0000705C56FD84E3
0000705c56fd5ff7  lea r14, [rax+0xC0]
0000705c56fd5ffe  movups xmm1, [r13+r14*1]
0000705c56fd6004  vmovaps xmm3, [rsp+0xC0]
0000705c56fd600d  vmovaps [rsp+0x80], xmm1
0000705c56fd6016  movaps xmm15, xmm3
0000705c56fd601a  addpd xmm15, xmm7
0000705c56fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fd6025  ptest xmm1, xmm1
0000705c56fd602a  jnz 0x0000705C56FD862F
0000705c56fd6030  vmovaps [rsp+0xC0], xmm13
0000705c56fd6039  vmovaps xmm1, [rsp+0xC0]
0000705c56fd6042  por xmm13, xmm1
0000705c56fd6047  movaps [r15+0x270], xmm13
0000705c56fd604f  vmovaps xmm1, [rsp+0xB0]
0000705c56fd6058  vmovaps xmm7, [rsp+0xB0]
0000705c56fd6061  por xmm1, xmm7
0000705c56fd6065  movaps [r15+0x1A0], xmm1
0000705c56fd606d  vmovaps xmm1, [rsp+0x60]
0000705c56fd6073  vpermilpd xmm1, xmm1, 0x00
0000705c56fd6079  vmovaps [rsp+0xB0], xmm1
0000705c56fd6082  vmovaps xmm1, [rsp+0x80]
0000705c56fd608b  vmovaps [rsp+0x80], xmm15
0000705c56fd6094  vmovaps xmm15, [rsp+0xB0]
0000705c56fd609d  vmovaps [rsp+0xB0], xmm14
0000705c56fd60a6  movaps xmm3, xmm1
0000705c56fd60a9  mulpd xmm3, xmm15
0000705c56fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000705c56fd60b3  ptest xmm14, xmm14
0000705c56fd60b9  jnz 0x0000705C56FD8771
0000705c56fd60bf  lea r14, [rax+0x20]
0000705c56fd60c3  movups xmm1, [r13+r14*1]
0000705c56fd60c9  movaps [r15+0x110], xmm1
0000705c56fd60d1  vmovaps xmm14, [rsp+0x70]
0000705c56fd60d7  vmovaps [rsp+0x70], xmm1
0000705c56fd60dd  movaps xmm15, xmm14
0000705c56fd60e1  addpd xmm15, xmm4
0000705c56fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fd60ec  ptest xmm1, xmm1
0000705c56fd60f1  jnz 0x0000705C56FD88BC
0000705c56fd60f7  vmovaps xmm1, [rsp+0x60]
0000705c56fd60fd  vpermilpd xmm1, xmm1, 0x00
0000705c56fd6103  movaps xmm14, xmm2
0000705c56fd6107  mulpd xmm14, xmm1
0000705c56fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000705c56fd6112  ptest xmm4, xmm4
0000705c56fd6117  jnz 0x0000705C56FD89FF
0000705c56fd611d  vmovaps xmm4, [rsp+0x50]
0000705c56fd6123  movaps xmm1, xmm4
0000705c56fd6126  addpd xmm1, xmm9
0000705c56fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c56fd6130  ptest xmm2, xmm2
0000705c56fd6135  jnz 0x0000705C56FD8B41
0000705c56fd613b  vmovaps xmm9, [rsp+0x30]
0000705c56fd6141  vpermilpd xmm9, xmm9, 0x00
0000705c56fd6147  vmovaps xmm2, [rsp+0x70]
0000705c56fd614d  vmovaps [rsp+0x50], xmm1
0000705c56fd6153  movaps xmm4, xmm2
0000705c56fd6156  mulpd xmm4, xmm9
0000705c56fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c56fd6160  ptest xmm1, xmm1
0000705c56fd6165  jnz 0x0000705C56FD8C82
0000705c56fd616b  vmovaps xmm1, [rsp+0x30]
0000705c56fd6171  vpermilpd xmm1, xmm1, 0x00
0000705c56fd6177  vmovaps xmm2, [rsp+0x90]
0000705c56fd6180  vmovaps [rsp+0x60], xmm15
0000705c56fd6186  movaps xmm9, xmm2
0000705c56fd618a  mulpd xmm9, xmm1
0000705c56fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c56fd6195  ptest xmm15, xmm15
0000705c56fd619b  jnz 0x0000705C56FD8DC3
0000705c56fd61a1  vmovaps xmm15, [rsp+0x80]
0000705c56fd61aa  movaps xmm1, xmm15
0000705c56fd61ae  addpd xmm1, xmm6
0000705c56fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c56fd61b7  ptest xmm2, xmm2
0000705c56fd61bc  jnz 0x0000705C56FD8F05
0000705c56fd61c2  movaps xmm15, xmm5
0000705c56fd61c6  addpd xmm15, xmm3
0000705c56fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000705c56fd61d1  ptest xmm6, xmm6
0000705c56fd61d6  jnz 0x0000705C56FD9046
0000705c56fd61dc  vmovaps xmm6, [rsp+0x30]
0000705c56fd61e2  vpermilpd xmm6, xmm6, 0x00
0000705c56fd61e8  movaps xmm5, xmm8
0000705c56fd61ec  mulpd xmm5, xmm6
0000705c56fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000705c56fd61f5  ptest xmm3, xmm3
0000705c56fd61fa  jnz 0x0000705C56FD9188
0000705c56fd6200  vmovaps xmm8, [rsp+0x30]
0000705c56fd6206  vpermilpd xmm8, xmm8, 0x00
0000705c56fd620c  movaps xmm6, xmm10
0000705c56fd6210  mulpd xmm6, xmm8
0000705c56fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c56fd621a  ptest xmm3, xmm3
0000705c56fd621f  jnz 0x0000705C56FD92C9
0000705c56fd6225  vmovaps xmm8, [rsp+0x60]
0000705c56fd622b  movaps xmm10, xmm8
0000705c56fd622f  addpd xmm10, xmm14
0000705c56fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000705c56fd623a  ptest xmm3, xmm3
0000705c56fd623f  jnz 0x0000705C56FD940B
0000705c56fd6245  vmovaps xmm8, [rsp+0x50]
0000705c56fd624b  movaps xmm14, xmm8
0000705c56fd624f  addpd xmm14, xmm4
0000705c56fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000705c56fd625a  ptest xmm3, xmm3
0000705c56fd625f  jnz 0x0000705C56FD954F
0000705c56fd6265  vmovaps xmm8, [rsp+0x40]
0000705c56fd626b  vpermilpd xmm8, xmm8, 0x00
0000705c56fd6271  movaps xmm4, xmm13
0000705c56fd6275  mulpd xmm4, xmm8
0000705c56fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c56fd627f  ptest xmm3, xmm3
0000705c56fd6284  jnz 0x0000705C56FD9692
0000705c56fd628a  movaps xmm13, xmm15
0000705c56fd628e  addpd xmm13, xmm9
0000705c56fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000705c56fd6299  ptest xmm8, xmm8
0000705c56fd629f  jnz 0x0000705C56FD97D4
0000705c56fd62a5  movaps xmm15, xmm1
0000705c56fd62a9  addpd xmm15, xmm5
0000705c56fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c56fd62b4  ptest xmm9, xmm9
0000705c56fd62ba  jnz 0x0000705C56FD9918
0000705c56fd62c0  vmovaps [rsp+0x30], xmm11
0000705c56fd62c6  vmovaps xmm1, [rsp+0x30]
0000705c56fd62cc  por xmm11, xmm1
0000705c56fd62d1  movaps [r15+0x250], xmm11
0000705c56fd62d9  vmovaps [rsp+0x30], xmm12
0000705c56fd62df  vmovaps xmm1, [rsp+0x30]
0000705c56fd62e5  por xmm12, xmm1
0000705c56fd62ea  movaps [r15+0x2A0], xmm12
0000705c56fd62f2  vmovaps xmm1, [rsp+0xA0]
0000705c56fd62fb  vmovaps xmm11, [rsp+0xA0]
0000705c56fd6304  por xmm1, xmm11
0000705c56fd6309  movaps [r15+0x1D0], xmm1
0000705c56fd6311  lea r14, [rax+0x40]
0000705c56fd6315  movups xmm1, [r13+r14*1]
0000705c56fd631b  movaps [r15+0x2C0], xmm1
0000705c56fd6323  vmovaps xmm11, [rsp+0x40]
0000705c56fd6329  vpermilpd xmm11, xmm11, 0x00
0000705c56fd632f  vmovaps xmm8, [rsp+0xE0]
0000705c56fd6338  movaps xmm9, xmm8
0000705c56fd633c  mulpd xmm9, xmm11
0000705c56fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000705c56fd6347  ptest xmm5, xmm5
0000705c56fd634c  jnz 0x0000705C56FD9A64
0000705c56fd6352  movaps xmm11, xmm10
0000705c56fd6356  addpd xmm11, xmm6
0000705c56fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000705c56fd6361  ptest xmm8, xmm8
0000705c56fd6367  jnz 0x0000705C56FD9BA8
0000705c56fd636d  movaps xmm10, xmm14
0000705c56fd6371  addpd xmm10, xmm4
0000705c56fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000705c56fd637c  ptest xmm8, xmm8
0000705c56fd6382  jnz 0x0000705C56FD9CEB
0000705c56fd6388  vmovaps xmm14, [rsp+0x40]
0000705c56fd638e  vpermilpd xmm14, xmm14, 0x00
0000705c56fd6394  movaps xmm8, xmm1
0000705c56fd6398  mulpd xmm8, xmm14
0000705c56fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c56fd63a3  ptest xmm6, xmm6
0000705c56fd63a8  jnz 0x0000705C56FD9E2E
0000705c56fd63ae  movaps xmm1, [r15+0x2B0]
0000705c56fd63b6  vmovaps xmm14, [rsp+0x40]
0000705c56fd63bc  vpermilpd xmm14, xmm14, 0x00
0000705c56fd63c2  movaps xmm6, xmm1
0000705c56fd63c5  mulpd xmm6, xmm14
0000705c56fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c56fd63cf  ptest xmm5, xmm5
0000705c56fd63d4  jnz 0x0000705C56FD9F71
0000705c56fd63da  vmovaps xmm1, [rsp+0x10]
0000705c56fd63e0  vpermilpd xmm1, xmm1, 0x00
0000705c56fd63e6  movaps xmm14, xmm12
0000705c56fd63ea  mulpd xmm14, xmm1
0000705c56fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000705c56fd63f5  ptest xmm5, xmm5
0000705c56fd63fa  jnz 0x0000705C56FDA0B2
0000705c56fd6400  movaps xmm1, xmm13
0000705c56fd6404  addpd xmm1, xmm9
0000705c56fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c56fd640e  ptest xmm12, xmm12
0000705c56fd6414  jnz 0x0000705C56FDA1F5
0000705c56fd641a  vmovaps xmm13, [rsp+0x10]
0000705c56fd6420  vpermilpd xmm13, xmm13, 0x00
0000705c56fd6426  movaps xmm12, xmm7
0000705c56fd642a  mulpd xmm12, xmm13
0000705c56fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c56fd6435  ptest xmm9, xmm9
0000705c56fd643b  jnz 0x0000705C56FDA337
0000705c56fd6441  movaps xmm13, xmm15
0000705c56fd6445  addpd xmm13, xmm8
0000705c56fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000705c56fd6450  ptest xmm9, xmm9
0000705c56fd6456  jnz 0x0000705C56FDA47A
0000705c56fd645c  movaps xmm15, [r15+0x290]
0000705c56fd6464  vmovaps xmm9, [rsp+0x10]
0000705c56fd646a  vpermilpd xmm9, xmm9, 0x00
0000705c56fd6470  movaps xmm8, xmm15
0000705c56fd6474  mulpd xmm8, xmm9
0000705c56fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c56fd647f  ptest xmm7, xmm7
0000705c56fd6484  jnz 0x0000705C56FDA5BE
0000705c56fd648a  movaps xmm15, xmm11
0000705c56fd648e  addpd xmm15, xmm6
0000705c56fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c56fd6499  ptest xmm9, xmm9
0000705c56fd649f  jnz 0x0000705C56FDA702
0000705c56fd64a5  movaps xmm11, [r15+0x1E0]
0000705c56fd64ad  vmovaps xmm9, [rsp+0x10]
0000705c56fd64b3  vpermilpd xmm9, xmm9, 0x00
0000705c56fd64b9  movaps xmm7, xmm11
0000705c56fd64bd  mulpd xmm7, xmm9
0000705c56fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c56fd64c7  ptest xmm6, xmm6
0000705c56fd64cc  jnz 0x0000705C56FDA845
0000705c56fd64d2  movaps xmm11, xmm10
0000705c56fd64d6  addpd xmm11, xmm14
0000705c56fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000705c56fd64e1  ptest xmm9, xmm9
0000705c56fd64e7  jnz 0x0000705C56FDA987
0000705c56fd64ed  lea r14, [rax+0x70]
0000705c56fd64f1  movups xmm14, [r13+r14*1]
0000705c56fd64f7  movaps [r15+0x240], xmm14
0000705c56fd64ff  movaps xmm10, xmm1
0000705c56fd6503  addpd xmm10, xmm12
0000705c56fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000705c56fd650e  ptest xmm9, xmm9
0000705c56fd6514  jnz 0x0000705C56FDAAD5
0000705c56fd651a  movaps [r15+0x170], xmm10
0000705c56fd6522  vmovaps xmm1, [rsp+0x20]
0000705c56fd6528  vpermilpd xmm1, xmm1, 0x00
0000705c56fd652e  movaps xmm12, xmm14
0000705c56fd6532  mulpd xmm12, xmm1
0000705c56fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c56fd653d  ptest xmm9, xmm9
0000705c56fd6543  jnz 0x0000705C56FDAC18
0000705c56fd6549  vmovaps xmm1, [rsp+0x20]
0000705c56fd654f  vpermilpd xmm1, xmm1, 0x00
0000705c56fd6555  vmovaps xmm9, [rsp+0xB0]
0000705c56fd655e  movaps xmm14, xmm9
0000705c56fd6562  mulpd xmm14, xmm1
0000705c56fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c56fd656d  ptest xmm6, xmm6
0000705c56fd6572  jnz 0x0000705C56FDAD5B
0000705c56fd6578  movaps [r15+0x180], xmm14
0000705c56fd6580  movaps xmm1, xmm13
0000705c56fd6584  addpd xmm1, xmm8
0000705c56fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000705c56fd658e  ptest xmm9, xmm9
0000705c56fd6594  jnz 0x0000705C56FDAE9E
0000705c56fd659a  movaps [r15+0x210], xmm1
0000705c56fd65a2  movups xmm13, [r13+rax*1]
0000705c56fd65a8  lea r14, [rax+0x10]
0000705c56fd65ac  movups xmm9, [r13+r14*1]
0000705c56fd65b2  movaps [r15+0x230], xmm9
0000705c56fd65ba  movaps xmm8, xmm15
0000705c56fd65be  addpd xmm8, xmm7
0000705c56fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c56fd65c9  ptest xmm6, xmm6
0000705c56fd65ce  jnz 0x0000705C56FDAFF4
0000705c56fd65d4  movaps [r15+0x130], xmm8
0000705c56fd65dc  vmovaps xmm15, [rsp+0x20]
0000705c56fd65e2  vpermilpd xmm15, xmm15, 0x00
0000705c56fd65e8  movaps xmm7, xmm9
0000705c56fd65ec  mulpd xmm7, xmm15
0000705c56fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c56fd65f6  ptest xmm6, xmm6
0000705c56fd65fb  jnz 0x0000705C56FDB137
0000705c56fd6601  movaps [r15+0x220], xmm7
0000705c56fd6609  vmovaps xmm15, [rsp+0x20]
0000705c56fd660f  vpermilpd xmm15, xmm15, 0x00
0000705c56fd6615  movaps xmm9, xmm13
0000705c56fd6619  mulpd xmm9, xmm15
0000705c56fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c56fd6624  ptest xmm6, xmm6
0000705c56fd6629  jnz 0x0000705C56FDB279
0000705c56fd662f  movaps xmm15, xmm11
0000705c56fd6633  addpd xmm15, xmm12
0000705c56fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c56fd663e  ptest xmm13, xmm13
0000705c56fd6644  jnz 0x0000705C56FDB3BD
0000705c56fd664a  movaps [r15+0x140], xmm15
0000705c56fd6652  movaps xmm13, xmm10
0000705c56fd6656  addpd xmm13, xmm14
0000705c56fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c56fd6661  ptest xmm12, xmm12
0000705c56fd6667  jnz 0x0000705C56FDB501
0000705c56fd666d  movaps [r15+0x150], xmm13
0000705c56fd6675  movaps xmm14, xmm1
0000705c56fd6679  addpd xmm14, xmm7
0000705c56fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000705c56fd6684  ptest xmm12, xmm12
0000705c56fd668a  jnz 0x0000705C56FDB645
0000705c56fd6690  movaps [r15+0x160], xmm14
0000705c56fd6698  movaps xmm1, xmm8
0000705c56fd669c  addpd xmm1, xmm9
0000705c56fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c56fd66a6  ptest xmm12, xmm12
0000705c56fd66ac  jnz 0x0000705C56FDB787
0000705c56fd66b2  movaps [r15+0x120], xmm1
0000705c56fd66ba  movups [r13+r11*1], xmm15
0000705c56fd66c0  lea rax, [r11+0x10]
0000705c56fd66c4  movups [r13+rax*1], xmm13
0000705c56fd66ca  lea rax, [r11+0x20]
0000705c56fd66ce  movups [r13+rax*1], xmm14
0000705c56fd66d4  lea rax, [r11+0x30]
0000705c56fd66d8  movups [r13+rax*1], xmm1
0000705c56fd66de  mov eax, [r15+0x108]
0000705c56fd66e5  sahf
0000705c56fd66e6  jnz 0x0000705C56FD6718
0000705c56fd66e8  cmp dword ptr [r15+0x318], 0x00
0000705c56fd66f0  jz 0x0000705C56FDB900
0000705c56fd66f6  nop [rax+rax*1], ax
0000705c56fd66ff  nop [rax+rax*1], eax
0000705c56fd6707  mov eax, 0x410444
0000705c56fd670c  mov [r15+0x100], rax
0000705c56fd6713  jmp 0x0000705C56DFE110
0000705c56fd6718  cmp dword ptr [r15+0x318], 0x00
0000705c56fd6720  jz 0x0000705C56FD57E0
0000705c56fd6726  nop [rax+rax*1], ax
0000705c56fd672f  nop [rax+rax*1], eax
0000705c56fd6737  mov eax, 0x410278
0000705c56fd673c  mov [r15+0x100], rax
0000705c56fd6743  jmp 0x0000705C56DFE110
0000705c56fd6748  int3
0000705c56fd6749  call 0x0000705C56E0A4B0
0000705c56fd674e  jmp 0x0000705C56FD5828
0000705c56fd6753  call 0x0000705C56E09240
0000705c56fd6758  jmp 0x0000705C56FD5832
0000705c56fd675d  call 0x0000705C56E0A4B0
0000705c56fd6762  jmp 0x0000705C56FD588F
0000705c56fd6767  call 0x0000705C56E09240
0000705c56fd676c  jmp 0x0000705C56FD5899
0000705c56fd6771  call 0x0000705C56E0A4B0
0000705c56fd6776  jmp 0x0000705C56FD58DD
0000705c56fd677b  call 0x0000705C56E09240
0000705c56fd6780  jmp 0x0000705C56FD58E7
0000705c56fd6785  call 0x0000705C56EB47C0
0000705c56fd678a  jmp 0x0000705C56FD5926
0000705c56fd678f  call 0x0000705C56E0B720
0000705c56fd6794  jmp 0x0000705C56FD593A
0000705c56fd6799  call 0x0000705C56EBFC30
0000705c56fd679e  jmp 0x0000705C56FD5958
0000705c56fd67a3  call 0x0000705C56EBE9C0
0000705c56fd67a8  jmp 0x0000705C56FD5962
0000705c56fd67ad  call 0x0000705C56EBD750
0000705c56fd67b2  jmp 0x0000705C56FD596C
0000705c56fd67b7  sub rsp, 0x08
0000705c56fd67bb  push rax
0000705c56fd67bc  push rcx
0000705c56fd67bd  push rdx
0000705c56fd67be  push rdi
0000705c56fd67bf  push rsi
0000705c56fd67c0  push r8
0000705c56fd67c2  push r9
0000705c56fd67c4  push r10
0000705c56fd67c6  push r11
0000705c56fd67c8  sub rsp, 0xF0
0000705c56fd67cf  vmovaps [rsp], xmm0
0000705c56fd67d4  vmovaps [rsp+0x10], xmm1
0000705c56fd67da  vmovaps [rsp+0x20], xmm2
0000705c56fd67e0  vmovaps [rsp+0x30], xmm3
0000705c56fd67e6  vmovaps [rsp+0x40], xmm4
0000705c56fd67ec  vmovaps [rsp+0x50], xmm5
0000705c56fd67f2  vmovaps [rsp+0x60], xmm6
0000705c56fd67f8  vmovaps [rsp+0x70], xmm7
0000705c56fd67fe  vmovaps [rsp+0x80], xmm9
0000705c56fd6807  vmovaps [rsp+0x90], xmm10
0000705c56fd6810  vmovaps [rsp+0xA0], xmm11
0000705c56fd6819  vmovaps [rsp+0xB0], xmm12
0000705c56fd6822  vmovaps [rsp+0xC0], xmm13
0000705c56fd682b  vmovaps [rsp+0xD0], xmm14
0000705c56fd6834  vmovaps [rsp+0xE0], xmm15
0000705c56fd683d  sub rsp, 0x30
0000705c56fd6841  movaps [rsp], xmm8
0000705c56fd6846  movaps [rsp+0x10], xmm12
0000705c56fd684c  movaps [rsp+0x20], xmm15
0000705c56fd6852  lea rdi, [rsp]
0000705c56fd6856  mov esi, 0x00
0000705c56fd685b  mov rax, 0x5877D3629530
0000705c56fd6865  call rax
0000705c56fd6867  movaps xmm8, [rsp]
0000705c56fd686c  add rsp, 0x30
0000705c56fd6870  vmovaps xmm0, [rsp]
0000705c56fd6875  vmovaps xmm1, [rsp+0x10]
0000705c56fd687b  vmovaps xmm2, [rsp+0x20]
0000705c56fd6881  vmovaps xmm3, [rsp+0x30]
0000705c56fd6887  vmovaps xmm4, [rsp+0x40]
0000705c56fd688d  vmovaps xmm5, [rsp+0x50]
0000705c56fd6893  vmovaps xmm6, [rsp+0x60]
0000705c56fd6899  vmovaps xmm7, [rsp+0x70]
0000705c56fd689f  vmovaps xmm9, [rsp+0x80]
0000705c56fd68a8  vmovaps xmm10, [rsp+0x90]
0000705c56fd68b1  vmovaps xmm11, [rsp+0xA0]
0000705c56fd68ba  vmovaps xmm12, [rsp+0xB0]
0000705c56fd68c3  vmovaps xmm13, [rsp+0xC0]
0000705c56fd68cc  vmovaps xmm14, [rsp+0xD0]
0000705c56fd68d5  vmovaps xmm15, [rsp+0xE0]
0000705c56fd68de  add rsp, 0xF0
0000705c56fd68e5  pop r11
0000705c56fd68e7  pop r10
0000705c56fd68e9  pop r9
0000705c56fd68eb  pop r8
0000705c56fd68ed  pop rsi
0000705c56fd68ee  pop rdi
0000705c56fd68ef  pop rdx
0000705c56fd68f0  pop rcx
0000705c56fd68f1  pop rax
0000705c56fd68f2  add rsp, 0x08
0000705c56fd68f6  jmp 0x0000705C56FD599A
0000705c56fd68fb  sub rsp, 0x08
0000705c56fd68ff  push rax
0000705c56fd6900  push rcx
0000705c56fd6901  push rdx
0000705c56fd6902  push rdi
0000705c56fd6903  push rsi
0000705c56fd6904  push r8
0000705c56fd6906  push r9
0000705c56fd6908  push r10
0000705c56fd690a  push r11
0000705c56fd690c  sub rsp, 0xF0
0000705c56fd6913  vmovaps [rsp], xmm0
0000705c56fd6918  vmovaps [rsp+0x10], xmm1
0000705c56fd691e  vmovaps [rsp+0x20], xmm2
0000705c56fd6924  vmovaps [rsp+0x30], xmm3
0000705c56fd692a  vmovaps [rsp+0x40], xmm4
0000705c56fd6930  vmovaps [rsp+0x50], xmm5
0000705c56fd6936  vmovaps [rsp+0x60], xmm6
0000705c56fd693c  vmovaps [rsp+0x70], xmm8
0000705c56fd6942  vmovaps [rsp+0x80], xmm9
0000705c56fd694b  vmovaps [rsp+0x90], xmm10
0000705c56fd6954  vmovaps [rsp+0xA0], xmm11
0000705c56fd695d  vmovaps [rsp+0xB0], xmm12
0000705c56fd6966  vmovaps [rsp+0xC0], xmm13
0000705c56fd696f  vmovaps [rsp+0xD0], xmm14
0000705c56fd6978  vmovaps [rsp+0xE0], xmm15
0000705c56fd6981  sub rsp, 0x30
0000705c56fd6985  movaps [rsp], xmm7
0000705c56fd6989  movaps [rsp+0x10], xmm9
0000705c56fd698f  movaps [rsp+0x20], xmm15
0000705c56fd6995  lea rdi, [rsp]
0000705c56fd6999  mov esi, 0x00
0000705c56fd699e  mov rax, 0x5877D3629530
0000705c56fd69a8  call rax
0000705c56fd69aa  movaps xmm7, [rsp]
0000705c56fd69ae  add rsp, 0x30
0000705c56fd69b2  vmovaps xmm0, [rsp]
0000705c56fd69b7  vmovaps xmm1, [rsp+0x10]
0000705c56fd69bd  vmovaps xmm2, [rsp+0x20]
0000705c56fd69c3  vmovaps xmm3, [rsp+0x30]
0000705c56fd69c9  vmovaps xmm4, [rsp+0x40]
0000705c56fd69cf  vmovaps xmm5, [rsp+0x50]
0000705c56fd69d5  vmovaps xmm6, [rsp+0x60]
0000705c56fd69db  vmovaps xmm8, [rsp+0x70]
0000705c56fd69e1  vmovaps xmm9, [rsp+0x80]
0000705c56fd69ea  vmovaps xmm10, [rsp+0x90]
0000705c56fd69f3  vmovaps xmm11, [rsp+0xA0]
0000705c56fd69fc  vmovaps xmm12, [rsp+0xB0]
0000705c56fd6a05  vmovaps xmm13, [rsp+0xC0]
0000705c56fd6a0e  vmovaps xmm14, [rsp+0xD0]
0000705c56fd6a17  vmovaps xmm15, [rsp+0xE0]
0000705c56fd6a20  add rsp, 0xF0
0000705c56fd6a27  pop r11
0000705c56fd6a29  pop r10
0000705c56fd6a2b  pop r9
0000705c56fd6a2d  pop r8
0000705c56fd6a2f  pop rsi
0000705c56fd6a30  pop rdi
0000705c56fd6a31  pop rdx
0000705c56fd6a32  pop rcx
0000705c56fd6a33  pop rax
0000705c56fd6a34  add rsp, 0x08
0000705c56fd6a38  jmp 0x0000705C56FD59C8
0000705c56fd6a3d  sub rsp, 0x08
0000705c56fd6a41  push rax
0000705c56fd6a42  push rcx
0000705c56fd6a43  push rdx
0000705c56fd6a44  push rdi
0000705c56fd6a45  push rsi
0000705c56fd6a46  push r8
0000705c56fd6a48  push r9
0000705c56fd6a4a  push r10
0000705c56fd6a4c  push r11
0000705c56fd6a4e  sub rsp, 0xF0
0000705c56fd6a55  vmovaps [rsp], xmm0
0000705c56fd6a5a  vmovaps [rsp+0x10], xmm1
0000705c56fd6a60  vmovaps [rsp+0x20], xmm2
0000705c56fd6a66  vmovaps [rsp+0x30], xmm3
0000705c56fd6a6c  vmovaps [rsp+0x40], xmm4
0000705c56fd6a72  vmovaps [rsp+0x50], xmm5
0000705c56fd6a78  vmovaps [rsp+0x60], xmm6
0000705c56fd6a7e  vmovaps [rsp+0x70], xmm7
0000705c56fd6a84  vmovaps [rsp+0x80], xmm8
0000705c56fd6a8d  vmovaps [rsp+0x90], xmm10
0000705c56fd6a96  vmovaps [rsp+0xA0], xmm11
0000705c56fd6a9f  vmovaps [rsp+0xB0], xmm12
0000705c56fd6aa8  vmovaps [rsp+0xC0], xmm13
0000705c56fd6ab1  vmovaps [rsp+0xD0], xmm14
0000705c56fd6aba  vmovaps [rsp+0xE0], xmm15
0000705c56fd6ac3  sub rsp, 0x30
0000705c56fd6ac7  movaps [rsp], xmm9
0000705c56fd6acc  movaps [rsp+0x10], xmm12
0000705c56fd6ad2  movaps [rsp+0x20], xmm10
0000705c56fd6ad8  lea rdi, [rsp]
0000705c56fd6adc  mov esi, 0x00
0000705c56fd6ae1  mov rax, 0x5877D3629530
0000705c56fd6aeb  call rax
0000705c56fd6aed  movaps xmm9, [rsp]
0000705c56fd6af2  add rsp, 0x30
0000705c56fd6af6  vmovaps xmm0, [rsp]
0000705c56fd6afb  vmovaps xmm1, [rsp+0x10]
0000705c56fd6b01  vmovaps xmm2, [rsp+0x20]
0000705c56fd6b07  vmovaps xmm3, [rsp+0x30]
0000705c56fd6b0d  vmovaps xmm4, [rsp+0x40]
0000705c56fd6b13  vmovaps xmm5, [rsp+0x50]
0000705c56fd6b19  vmovaps xmm6, [rsp+0x60]
0000705c56fd6b1f  vmovaps xmm7, [rsp+0x70]
0000705c56fd6b25  vmovaps xmm8, [rsp+0x80]
0000705c56fd6b2e  vmovaps xmm10, [rsp+0x90]
0000705c56fd6b37  vmovaps xmm11, [rsp+0xA0]
0000705c56fd6b40  vmovaps xmm12, [rsp+0xB0]
0000705c56fd6b49  vmovaps xmm13, [rsp+0xC0]
0000705c56fd6b52  vmovaps xmm14, [rsp+0xD0]
0000705c56fd6b5b  vmovaps xmm15, [rsp+0xE0]
0000705c56fd6b64  add rsp, 0xF0
0000705c56fd6b6b  pop r11
0000705c56fd6b6d  pop r10
0000705c56fd6b6f  pop r9
0000705c56fd6b71  pop r8
0000705c56fd6b73  pop rsi
0000705c56fd6b74  pop rdi
0000705c56fd6b75  pop rdx
0000705c56fd6b76  pop rcx
0000705c56fd6b77  pop rax
0000705c56fd6b78  add rsp, 0x08
0000705c56fd6b7c  jmp 0x0000705C56FD59EC
0000705c56fd6b81  sub rsp, 0x08
0000705c56fd6b85  push rax
0000705c56fd6b86  push rcx
0000705c56fd6b87  push rdx
0000705c56fd6b88  push rdi
0000705c56fd6b89  push rsi
0000705c56fd6b8a  push r8
0000705c56fd6b8c  push r9
0000705c56fd6b8e  push r10
0000705c56fd6b90  push r11
0000705c56fd6b92  sub rsp, 0xF0
0000705c56fd6b99  vmovaps [rsp], xmm0
0000705c56fd6b9e  vmovaps [rsp+0x10], xmm1
0000705c56fd6ba4  vmovaps [rsp+0x20], xmm2
0000705c56fd6baa  vmovaps [rsp+0x30], xmm3
0000705c56fd6bb0  vmovaps [rsp+0x40], xmm4
0000705c56fd6bb6  vmovaps [rsp+0x50], xmm5
0000705c56fd6bbc  vmovaps [rsp+0x60], xmm6
0000705c56fd6bc2  vmovaps [rsp+0x70], xmm7
0000705c56fd6bc8  vmovaps [rsp+0x80], xmm8
0000705c56fd6bd1  vmovaps [rsp+0x90], xmm9
0000705c56fd6bda  vmovaps [rsp+0xA0], xmm11
0000705c56fd6be3  vmovaps [rsp+0xB0], xmm12
0000705c56fd6bec  vmovaps [rsp+0xC0], xmm13
0000705c56fd6bf5  vmovaps [rsp+0xD0], xmm14
0000705c56fd6bfe  vmovaps [rsp+0xE0], xmm15
0000705c56fd6c07  sub rsp, 0x30
0000705c56fd6c0b  movaps [rsp], xmm10
0000705c56fd6c10  movaps [rsp+0x10], xmm12
0000705c56fd6c16  movaps [rsp+0x20], xmm11
0000705c56fd6c1c  lea rdi, [rsp]
0000705c56fd6c20  mov esi, 0x00
0000705c56fd6c25  mov rax, 0x5877D3629530
0000705c56fd6c2f  call rax
0000705c56fd6c31  movaps xmm10, [rsp]
0000705c56fd6c36  add rsp, 0x30
0000705c56fd6c3a  vmovaps xmm0, [rsp]
0000705c56fd6c3f  vmovaps xmm1, [rsp+0x10]
0000705c56fd6c45  vmovaps xmm2, [rsp+0x20]
0000705c56fd6c4b  vmovaps xmm3, [rsp+0x30]
0000705c56fd6c51  vmovaps xmm4, [rsp+0x40]
0000705c56fd6c57  vmovaps xmm5, [rsp+0x50]
0000705c56fd6c5d  vmovaps xmm6, [rsp+0x60]
0000705c56fd6c63  vmovaps xmm7, [rsp+0x70]
0000705c56fd6c69  vmovaps xmm8, [rsp+0x80]
0000705c56fd6c72  vmovaps xmm9, [rsp+0x90]
0000705c56fd6c7b  vmovaps xmm11, [rsp+0xA0]
0000705c56fd6c84  vmovaps xmm12, [rsp+0xB0]
0000705c56fd6c8d  vmovaps xmm13, [rsp+0xC0]
0000705c56fd6c96  vmovaps xmm14, [rsp+0xD0]
0000705c56fd6c9f  vmovaps xmm15, [rsp+0xE0]
0000705c56fd6ca8  add rsp, 0xF0
0000705c56fd6caf  pop r11
0000705c56fd6cb1  pop r10
0000705c56fd6cb3  pop r9
0000705c56fd6cb5  pop r8
0000705c56fd6cb7  pop rsi
0000705c56fd6cb8  pop rdi
0000705c56fd6cb9  pop rdx
0000705c56fd6cba  pop rcx
0000705c56fd6cbb  pop rax
0000705c56fd6cbc  add rsp, 0x08
0000705c56fd6cc0  jmp 0x0000705C56FD5A06
0000705c56fd6cc5  sub rsp, 0x08
0000705c56fd6cc9  push rax
0000705c56fd6cca  push rcx
0000705c56fd6ccb  push rdx
0000705c56fd6ccc  push rdi
0000705c56fd6ccd  push rsi
0000705c56fd6cce  push r8
0000705c56fd6cd0  push r9
0000705c56fd6cd2  push r10
0000705c56fd6cd4  push r11
0000705c56fd6cd6  sub rsp, 0xF0
0000705c56fd6cdd  vmovaps [rsp], xmm0
0000705c56fd6ce2  vmovaps [rsp+0x10], xmm1
0000705c56fd6ce8  vmovaps [rsp+0x20], xmm2
0000705c56fd6cee  vmovaps [rsp+0x30], xmm3
0000705c56fd6cf4  vmovaps [rsp+0x40], xmm4
0000705c56fd6cfa  vmovaps [rsp+0x50], xmm5
0000705c56fd6d00  vmovaps [rsp+0x60], xmm7
0000705c56fd6d06  vmovaps [rsp+0x70], xmm8
0000705c56fd6d0c  vmovaps [rsp+0x80], xmm9
0000705c56fd6d15  vmovaps [rsp+0x90], xmm10
0000705c56fd6d1e  vmovaps [rsp+0xA0], xmm11
0000705c56fd6d27  vmovaps [rsp+0xB0], xmm12
0000705c56fd6d30  vmovaps [rsp+0xC0], xmm13
0000705c56fd6d39  vmovaps [rsp+0xD0], xmm14
0000705c56fd6d42  vmovaps [rsp+0xE0], xmm15
0000705c56fd6d4b  sub rsp, 0x30
0000705c56fd6d4f  movaps [rsp], xmm6
0000705c56fd6d53  movaps [rsp+0x10], xmm12
0000705c56fd6d59  movaps [rsp+0x20], xmm11
0000705c56fd6d5f  lea rdi, [rsp]
0000705c56fd6d63  mov esi, 0x00
0000705c56fd6d68  mov rax, 0x5877D3629530
0000705c56fd6d72  call rax
0000705c56fd6d74  movaps xmm6, [rsp]
0000705c56fd6d78  add rsp, 0x30
0000705c56fd6d7c  vmovaps xmm0, [rsp]
0000705c56fd6d81  vmovaps xmm1, [rsp+0x10]
0000705c56fd6d87  vmovaps xmm2, [rsp+0x20]
0000705c56fd6d8d  vmovaps xmm3, [rsp+0x30]
0000705c56fd6d93  vmovaps xmm4, [rsp+0x40]
0000705c56fd6d99  vmovaps xmm5, [rsp+0x50]
0000705c56fd6d9f  vmovaps xmm7, [rsp+0x60]
0000705c56fd6da5  vmovaps xmm8, [rsp+0x70]
0000705c56fd6dab  vmovaps xmm9, [rsp+0x80]
0000705c56fd6db4  vmovaps xmm10, [rsp+0x90]
0000705c56fd6dbd  vmovaps xmm11, [rsp+0xA0]
0000705c56fd6dc6  vmovaps xmm12, [rsp+0xB0]
0000705c56fd6dcf  vmovaps xmm13, [rsp+0xC0]
0000705c56fd6dd8  vmovaps xmm14, [rsp+0xD0]
0000705c56fd6de1  vmovaps xmm15, [rsp+0xE0]
0000705c56fd6dea  add rsp, 0xF0
0000705c56fd6df1  pop r11
0000705c56fd6df3  pop r10
0000705c56fd6df5  pop r9
0000705c56fd6df7  pop r8
0000705c56fd6df9  pop rsi
0000705c56fd6dfa  pop rdi
0000705c56fd6dfb  pop rdx
0000705c56fd6dfc  pop rcx
0000705c56fd6dfd  pop rax
0000705c56fd6dfe  add rsp, 0x08
0000705c56fd6e02  jmp 0x0000705C56FD5A27
0000705c56fd6e07  sub rsp, 0x08
0000705c56fd6e0b  push rax
0000705c56fd6e0c  push rcx
0000705c56fd6e0d  push rdx
0000705c56fd6e0e  push rdi
0000705c56fd6e0f  push rsi
0000705c56fd6e10  push r8
0000705c56fd6e12  push r9
0000705c56fd6e14  push r10
0000705c56fd6e16  push r11
0000705c56fd6e18  sub rsp, 0xF0
0000705c56fd6e1f  vmovaps [rsp], xmm0
0000705c56fd6e24  vmovaps [rsp+0x10], xmm1
0000705c56fd6e2a  vmovaps [rsp+0x20], xmm2
0000705c56fd6e30  vmovaps [rsp+0x30], xmm4
0000705c56fd6e36  vmovaps [rsp+0x40], xmm5
0000705c56fd6e3c  vmovaps [rsp+0x50], xmm6
0000705c56fd6e42  vmovaps [rsp+0x60], xmm7
0000705c56fd6e48  vmovaps [rsp+0x70], xmm8
0000705c56fd6e4e  vmovaps [rsp+0x80], xmm9
0000705c56fd6e57  vmovaps [rsp+0x90], xmm10
0000705c56fd6e60  vmovaps [rsp+0xA0], xmm11
0000705c56fd6e69  vmovaps [rsp+0xB0], xmm12
0000705c56fd6e72  vmovaps [rsp+0xC0], xmm13
0000705c56fd6e7b  vmovaps [rsp+0xD0], xmm14
0000705c56fd6e84  vmovaps [rsp+0xE0], xmm15
0000705c56fd6e8d  sub rsp, 0x30
0000705c56fd6e91  movaps [rsp], xmm3
0000705c56fd6e95  movaps [rsp+0x10], xmm5
0000705c56fd6e9a  movaps [rsp+0x20], xmm4
0000705c56fd6e9f  lea rdi, [rsp]
0000705c56fd6ea3  mov esi, 0x00
0000705c56fd6ea8  mov rax, 0x5877D3629530
0000705c56fd6eb2  call rax
0000705c56fd6eb4  movaps xmm3, [rsp]
0000705c56fd6eb8  add rsp, 0x30
0000705c56fd6ebc  vmovaps xmm0, [rsp]
0000705c56fd6ec1  vmovaps xmm1, [rsp+0x10]
0000705c56fd6ec7  vmovaps xmm2, [rsp+0x20]
0000705c56fd6ecd  vmovaps xmm4, [rsp+0x30]
0000705c56fd6ed3  vmovaps xmm5, [rsp+0x40]
0000705c56fd6ed9  vmovaps xmm6, [rsp+0x50]
0000705c56fd6edf  vmovaps xmm7, [rsp+0x60]
0000705c56fd6ee5  vmovaps xmm8, [rsp+0x70]
0000705c56fd6eeb  vmovaps xmm9, [rsp+0x80]
0000705c56fd6ef4  vmovaps xmm10, [rsp+0x90]
0000705c56fd6efd  vmovaps xmm11, [rsp+0xA0]
0000705c56fd6f06  vmovaps xmm12, [rsp+0xB0]
0000705c56fd6f0f  vmovaps xmm13, [rsp+0xC0]
0000705c56fd6f18  vmovaps xmm14, [rsp+0xD0]
0000705c56fd6f21  vmovaps xmm15, [rsp+0xE0]
0000705c56fd6f2a  add rsp, 0xF0
0000705c56fd6f31  pop r11
0000705c56fd6f33  pop r10
0000705c56fd6f35  pop r9
0000705c56fd6f37  pop r8
0000705c56fd6f39  pop rsi
0000705c56fd6f3a  pop rdi
0000705c56fd6f3b  pop rdx
0000705c56fd6f3c  pop rcx
0000705c56fd6f3d  pop rax
0000705c56fd6f3e  add rsp, 0x08
0000705c56fd6f42  jmp 0x0000705C56FD5A88
0000705c56fd6f47  sub rsp, 0x08
0000705c56fd6f4b  push rax
0000705c56fd6f4c  push rcx
0000705c56fd6f4d  push rdx
0000705c56fd6f4e  push rdi
0000705c56fd6f4f  push rsi
0000705c56fd6f50  push r8
0000705c56fd6f52  push r9
0000705c56fd6f54  push r10
0000705c56fd6f56  push r11
0000705c56fd6f58  sub rsp, 0xF0
0000705c56fd6f5f  vmovaps [rsp], xmm0
0000705c56fd6f64  vmovaps [rsp+0x10], xmm1
0000705c56fd6f6a  vmovaps [rsp+0x20], xmm2
0000705c56fd6f70  vmovaps [rsp+0x30], xmm3
0000705c56fd6f76  vmovaps [rsp+0x40], xmm4
0000705c56fd6f7c  vmovaps [rsp+0x50], xmm6
0000705c56fd6f82  vmovaps [rsp+0x60], xmm7
0000705c56fd6f88  vmovaps [rsp+0x70], xmm8
0000705c56fd6f8e  vmovaps [rsp+0x80], xmm9
0000705c56fd6f97  vmovaps [rsp+0x90], xmm10
0000705c56fd6fa0  vmovaps [rsp+0xA0], xmm11
0000705c56fd6fa9  vmovaps [rsp+0xB0], xmm12
0000705c56fd6fb2  vmovaps [rsp+0xC0], xmm13
0000705c56fd6fbb  vmovaps [rsp+0xD0], xmm14
0000705c56fd6fc4  vmovaps [rsp+0xE0], xmm15
0000705c56fd6fcd  sub rsp, 0x30
0000705c56fd6fd1  movaps [rsp], xmm5
0000705c56fd6fd5  movaps [rsp+0x10], xmm8
0000705c56fd6fdb  movaps [rsp+0x20], xmm15
0000705c56fd6fe1  lea rdi, [rsp]
0000705c56fd6fe5  mov esi, 0x00
0000705c56fd6fea  mov rax, 0x5877D3629530
0000705c56fd6ff4  call rax
0000705c56fd6ff6  movaps xmm5, [rsp]
0000705c56fd6ffa  add rsp, 0x30
0000705c56fd6ffe  vmovaps xmm0, [rsp]
0000705c56fd7003  vmovaps xmm1, [rsp+0x10]
0000705c56fd7009  vmovaps xmm2, [rsp+0x20]
0000705c56fd700f  vmovaps xmm3, [rsp+0x30]
0000705c56fd7015  vmovaps xmm4, [rsp+0x40]
0000705c56fd701b  vmovaps xmm6, [rsp+0x50]
0000705c56fd7021  vmovaps xmm7, [rsp+0x60]
0000705c56fd7027  vmovaps xmm8, [rsp+0x70]
0000705c56fd702d  vmovaps xmm9, [rsp+0x80]
0000705c56fd7036  vmovaps xmm10, [rsp+0x90]
0000705c56fd703f  vmovaps xmm11, [rsp+0xA0]
0000705c56fd7048  vmovaps xmm12, [rsp+0xB0]
0000705c56fd7051  vmovaps xmm13, [rsp+0xC0]
0000705c56fd705a  vmovaps xmm14, [rsp+0xD0]
0000705c56fd7063  vmovaps xmm15, [rsp+0xE0]
0000705c56fd706c  add rsp, 0xF0
0000705c56fd7073  pop r11
0000705c56fd7075  pop r10
0000705c56fd7077  pop r9
0000705c56fd7079  pop r8
0000705c56fd707b  pop rsi
0000705c56fd707c  pop rdi
0000705c56fd707d  pop rdx
0000705c56fd707e  pop rcx
0000705c56fd707f  pop rax
0000705c56fd7080  add rsp, 0x08
0000705c56fd7084  jmp 0x0000705C56FD5AC0
0000705c56fd7089  sub rsp, 0x08
0000705c56fd708d  push rax
0000705c56fd708e  push rcx
0000705c56fd708f  push rdx
0000705c56fd7090  push rdi
0000705c56fd7091  push rsi
0000705c56fd7092  push r8
0000705c56fd7094  push r9
0000705c56fd7096  push r10
0000705c56fd7098  push r11
0000705c56fd709a  sub rsp, 0xF0
0000705c56fd70a1  vmovaps [rsp], xmm0
0000705c56fd70a6  vmovaps [rsp+0x10], xmm1
0000705c56fd70ac  vmovaps [rsp+0x20], xmm2
0000705c56fd70b2  vmovaps [rsp+0x30], xmm3
0000705c56fd70b8  vmovaps [rsp+0x40], xmm5
0000705c56fd70be  vmovaps [rsp+0x50], xmm6
0000705c56fd70c4  vmovaps [rsp+0x60], xmm7
0000705c56fd70ca  vmovaps [rsp+0x70], xmm8
0000705c56fd70d0  vmovaps [rsp+0x80], xmm9
0000705c56fd70d9  vmovaps [rsp+0x90], xmm10
0000705c56fd70e2  vmovaps [rsp+0xA0], xmm11
0000705c56fd70eb  vmovaps [rsp+0xB0], xmm12
0000705c56fd70f4  vmovaps [rsp+0xC0], xmm13
0000705c56fd70fd  vmovaps [rsp+0xD0], xmm14
0000705c56fd7106  vmovaps [rsp+0xE0], xmm15
0000705c56fd710f  sub rsp, 0x30
0000705c56fd7113  movaps [rsp], xmm4
0000705c56fd7117  movaps [rsp+0x10], xmm9
0000705c56fd711d  movaps [rsp+0x20], xmm8
0000705c56fd7123  lea rdi, [rsp]
0000705c56fd7127  mov esi, 0x00
0000705c56fd712c  mov rax, 0x5877D3629530
0000705c56fd7136  call rax
0000705c56fd7138  movaps xmm4, [rsp]
0000705c56fd713c  add rsp, 0x30
0000705c56fd7140  vmovaps xmm0, [rsp]
0000705c56fd7145  vmovaps xmm1, [rsp+0x10]
0000705c56fd714b  vmovaps xmm2, [rsp+0x20]
0000705c56fd7151  vmovaps xmm3, [rsp+0x30]
0000705c56fd7157  vmovaps xmm5, [rsp+0x40]
0000705c56fd715d  vmovaps xmm6, [rsp+0x50]
0000705c56fd7163  vmovaps xmm7, [rsp+0x60]
0000705c56fd7169  vmovaps xmm8, [rsp+0x70]
0000705c56fd716f  vmovaps xmm9, [rsp+0x80]
0000705c56fd7178  vmovaps xmm10, [rsp+0x90]
0000705c56fd7181  vmovaps xmm11, [rsp+0xA0]
0000705c56fd718a  vmovaps xmm12, [rsp+0xB0]
0000705c56fd7193  vmovaps xmm13, [rsp+0xC0]
0000705c56fd719c  vmovaps xmm14, [rsp+0xD0]
0000705c56fd71a5  vmovaps xmm15, [rsp+0xE0]
0000705c56fd71ae  add rsp, 0xF0
0000705c56fd71b5  pop r11
0000705c56fd71b7  pop r10
0000705c56fd71b9  pop r9
0000705c56fd71bb  pop r8
0000705c56fd71bd  pop rsi
0000705c56fd71be  pop rdi
0000705c56fd71bf  pop rdx
0000705c56fd71c0  pop rcx
0000705c56fd71c1  pop rax
0000705c56fd71c2  add rsp, 0x08
0000705c56fd71c6  jmp 0x0000705C56FD5AE1
0000705c56fd71cb  sub rsp, 0x08
0000705c56fd71cf  push rax
0000705c56fd71d0  push rcx
0000705c56fd71d1  push rdx
0000705c56fd71d2  push rdi
0000705c56fd71d3  push rsi
0000705c56fd71d4  push r8
0000705c56fd71d6  push r9
0000705c56fd71d8  push r10
0000705c56fd71da  push r11
0000705c56fd71dc  sub rsp, 0xF0
0000705c56fd71e3  vmovaps [rsp], xmm0
0000705c56fd71e8  vmovaps [rsp+0x10], xmm1
0000705c56fd71ee  vmovaps [rsp+0x20], xmm2
0000705c56fd71f4  vmovaps [rsp+0x30], xmm3
0000705c56fd71fa  vmovaps [rsp+0x40], xmm4
0000705c56fd7200  vmovaps [rsp+0x50], xmm5
0000705c56fd7206  vmovaps [rsp+0x60], xmm6
0000705c56fd720c  vmovaps [rsp+0x70], xmm7
0000705c56fd7212  vmovaps [rsp+0x80], xmm8
0000705c56fd721b  vmovaps [rsp+0x90], xmm10
0000705c56fd7224  vmovaps [rsp+0xA0], xmm11
0000705c56fd722d  vmovaps [rsp+0xB0], xmm12
0000705c56fd7236  vmovaps [rsp+0xC0], xmm13
0000705c56fd723f  vmovaps [rsp+0xD0], xmm14
0000705c56fd7248  vmovaps [rsp+0xE0], xmm15
0000705c56fd7251  sub rsp, 0x30
0000705c56fd7255  movaps [rsp], xmm9
0000705c56fd725a  movaps [rsp+0x10], xmm10
0000705c56fd7260  movaps [rsp+0x20], xmm8
0000705c56fd7266  lea rdi, [rsp]
0000705c56fd726a  mov esi, 0x00
0000705c56fd726f  mov rax, 0x5877D3629530
0000705c56fd7279  call rax
0000705c56fd727b  movaps xmm9, [rsp]
0000705c56fd7280  add rsp, 0x30
0000705c56fd7284  vmovaps xmm0, [rsp]
0000705c56fd7289  vmovaps xmm1, [rsp+0x10]
0000705c56fd728f  vmovaps xmm2, [rsp+0x20]
0000705c56fd7295  vmovaps xmm3, [rsp+0x30]
0000705c56fd729b  vmovaps xmm4, [rsp+0x40]
0000705c56fd72a1  vmovaps xmm5, [rsp+0x50]
0000705c56fd72a7  vmovaps xmm6, [rsp+0x60]
0000705c56fd72ad  vmovaps xmm7, [rsp+0x70]
0000705c56fd72b3  vmovaps xmm8, [rsp+0x80]
0000705c56fd72bc  vmovaps xmm10, [rsp+0x90]
0000705c56fd72c5  vmovaps xmm11, [rsp+0xA0]
0000705c56fd72ce  vmovaps xmm12, [rsp+0xB0]
0000705c56fd72d7  vmovaps xmm13, [rsp+0xC0]
0000705c56fd72e0  vmovaps xmm14, [rsp+0xD0]
0000705c56fd72e9  vmovaps xmm15, [rsp+0xE0]
0000705c56fd72f2  add rsp, 0xF0
0000705c56fd72f9  pop r11
0000705c56fd72fb  pop r10
0000705c56fd72fd  pop r9
0000705c56fd72ff  pop r8
0000705c56fd7301  pop rsi
0000705c56fd7302  pop rdi
0000705c56fd7303  pop rdx
0000705c56fd7304  pop rcx
0000705c56fd7305  pop rax
0000705c56fd7306  add rsp, 0x08
0000705c56fd730a  jmp 0x0000705C56FD5AFB
0000705c56fd730f  call 0x0000705C56ED64F0
0000705c56fd7314  jmp 0x0000705C56FD5C15
0000705c56fd7319  call 0x0000705C56ED64F0
0000705c56fd731e  jmp 0x0000705C56FD5C2B
0000705c56fd7323  sub rsp, 0x08
0000705c56fd7327  push rax
0000705c56fd7328  push rcx
0000705c56fd7329  push rdx
0000705c56fd732a  push rdi
0000705c56fd732b  push rsi
0000705c56fd732c  push r8
0000705c56fd732e  push r9
0000705c56fd7330  push r10
0000705c56fd7332  push r11
0000705c56fd7334  sub rsp, 0xF0
0000705c56fd733b  vmovaps [rsp], xmm0
0000705c56fd7340  vmovaps [rsp+0x10], xmm2
0000705c56fd7346  vmovaps [rsp+0x20], xmm3
0000705c56fd734c  vmovaps [rsp+0x30], xmm4
0000705c56fd7352  vmovaps [rsp+0x40], xmm5
0000705c56fd7358  vmovaps [rsp+0x50], xmm6
0000705c56fd735e  vmovaps [rsp+0x60], xmm7
0000705c56fd7364  vmovaps [rsp+0x70], xmm8
0000705c56fd736a  vmovaps [rsp+0x80], xmm9
0000705c56fd7373  vmovaps [rsp+0x90], xmm10
0000705c56fd737c  vmovaps [rsp+0xA0], xmm11
0000705c56fd7385  vmovaps [rsp+0xB0], xmm12
0000705c56fd738e  vmovaps [rsp+0xC0], xmm13
0000705c56fd7397  vmovaps [rsp+0xD0], xmm14
0000705c56fd73a0  vmovaps [rsp+0xE0], xmm15
0000705c56fd73a9  sub rsp, 0x30
0000705c56fd73ad  movaps [rsp], xmm1
0000705c56fd73b1  movaps [rsp+0x10], xmm6
0000705c56fd73b6  movaps [rsp+0x20], xmm15
0000705c56fd73bc  lea rdi, [rsp]
0000705c56fd73c0  mov esi, 0x00
0000705c56fd73c5  mov rax, 0x5877D3629530
0000705c56fd73cf  call rax
0000705c56fd73d1  movaps xmm1, [rsp]
0000705c56fd73d5  add rsp, 0x30
0000705c56fd73d9  vmovaps xmm0, [rsp]
0000705c56fd73de  vmovaps xmm2, [rsp+0x10]
0000705c56fd73e4  vmovaps xmm3, [rsp+0x20]
0000705c56fd73ea  vmovaps xmm4, [rsp+0x30]
0000705c56fd73f0  vmovaps xmm5, [rsp+0x40]
0000705c56fd73f6  vmovaps xmm6, [rsp+0x50]
0000705c56fd73fc  vmovaps xmm7, [rsp+0x60]
0000705c56fd7402  vmovaps xmm8, [rsp+0x70]
0000705c56fd7408  vmovaps xmm9, [rsp+0x80]
0000705c56fd7411  vmovaps xmm10, [rsp+0x90]
0000705c56fd741a  vmovaps xmm11, [rsp+0xA0]
0000705c56fd7423  vmovaps xmm12, [rsp+0xB0]
0000705c56fd742c  vmovaps xmm13, [rsp+0xC0]
0000705c56fd7435  vmovaps xmm14, [rsp+0xD0]
0000705c56fd743e  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7447  add rsp, 0xF0
0000705c56fd744e  pop r11
0000705c56fd7450  pop r10
0000705c56fd7452  pop r9
0000705c56fd7454  pop r8
0000705c56fd7456  pop rsi
0000705c56fd7457  pop rdi
0000705c56fd7458  pop rdx
0000705c56fd7459  pop rcx
0000705c56fd745a  pop rax
0000705c56fd745b  add rsp, 0x08
0000705c56fd745f  jmp 0x0000705C56FD5C68
0000705c56fd7464  call 0x0000705C56EE5820
0000705c56fd7469  jmp 0x0000705C56FD5C75
0000705c56fd746e  sub rsp, 0x08
0000705c56fd7472  push rax
0000705c56fd7473  push rcx
0000705c56fd7474  push rdx
0000705c56fd7475  push rdi
0000705c56fd7476  push rsi
0000705c56fd7477  push r8
0000705c56fd7479  push r9
0000705c56fd747b  push r10
0000705c56fd747d  push r11
0000705c56fd747f  sub rsp, 0xF0
0000705c56fd7486  vmovaps [rsp], xmm0
0000705c56fd748b  vmovaps [rsp+0x10], xmm1
0000705c56fd7491  vmovaps [rsp+0x20], xmm2
0000705c56fd7497  vmovaps [rsp+0x30], xmm3
0000705c56fd749d  vmovaps [rsp+0x40], xmm4
0000705c56fd74a3  vmovaps [rsp+0x50], xmm5
0000705c56fd74a9  vmovaps [rsp+0x60], xmm6
0000705c56fd74af  vmovaps [rsp+0x70], xmm7
0000705c56fd74b5  vmovaps [rsp+0x80], xmm8
0000705c56fd74be  vmovaps [rsp+0x90], xmm9
0000705c56fd74c7  vmovaps [rsp+0xA0], xmm10
0000705c56fd74d0  vmovaps [rsp+0xB0], xmm11
0000705c56fd74d9  vmovaps [rsp+0xC0], xmm12
0000705c56fd74e2  vmovaps [rsp+0xD0], xmm13
0000705c56fd74eb  vmovaps [rsp+0xE0], xmm15
0000705c56fd74f4  sub rsp, 0x30
0000705c56fd74f8  movaps [rsp], xmm14
0000705c56fd74fd  movaps [rsp+0x10], xmm4
0000705c56fd7502  movaps [rsp+0x20], xmm3
0000705c56fd7507  lea rdi, [rsp]
0000705c56fd750b  mov esi, 0x00
0000705c56fd7510  mov rax, 0x5877D3629530
0000705c56fd751a  call rax
0000705c56fd751c  movaps xmm14, [rsp]
0000705c56fd7521  add rsp, 0x30
0000705c56fd7525  vmovaps xmm0, [rsp]
0000705c56fd752a  vmovaps xmm1, [rsp+0x10]
0000705c56fd7530  vmovaps xmm2, [rsp+0x20]
0000705c56fd7536  vmovaps xmm3, [rsp+0x30]
0000705c56fd753c  vmovaps xmm4, [rsp+0x40]
0000705c56fd7542  vmovaps xmm5, [rsp+0x50]
0000705c56fd7548  vmovaps xmm6, [rsp+0x60]
0000705c56fd754e  vmovaps xmm7, [rsp+0x70]
0000705c56fd7554  vmovaps xmm8, [rsp+0x80]
0000705c56fd755d  vmovaps xmm9, [rsp+0x90]
0000705c56fd7566  vmovaps xmm10, [rsp+0xA0]
0000705c56fd756f  vmovaps xmm11, [rsp+0xB0]
0000705c56fd7578  vmovaps xmm12, [rsp+0xC0]
0000705c56fd7581  vmovaps xmm13, [rsp+0xD0]
0000705c56fd758a  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7593  add rsp, 0xF0
0000705c56fd759a  pop r11
0000705c56fd759c  pop r10
0000705c56fd759e  pop r9
0000705c56fd75a0  pop r8
0000705c56fd75a2  pop rsi
0000705c56fd75a3  pop rdi
0000705c56fd75a4  pop rdx
0000705c56fd75a5  pop rcx
0000705c56fd75a6  pop rax
0000705c56fd75a7  add rsp, 0x08
0000705c56fd75ab  jmp 0x0000705C56FD5C8F
0000705c56fd75b0  sub rsp, 0x08
0000705c56fd75b4  push rax
0000705c56fd75b5  push rcx
0000705c56fd75b6  push rdx
0000705c56fd75b7  push rdi
0000705c56fd75b8  push rsi
0000705c56fd75b9  push r8
0000705c56fd75bb  push r9
0000705c56fd75bd  push r10
0000705c56fd75bf  push r11
0000705c56fd75c1  sub rsp, 0xF0
0000705c56fd75c8  vmovaps [rsp], xmm0
0000705c56fd75cd  vmovaps [rsp+0x10], xmm1
0000705c56fd75d3  vmovaps [rsp+0x20], xmm2
0000705c56fd75d9  vmovaps [rsp+0x30], xmm3
0000705c56fd75df  vmovaps [rsp+0x40], xmm4
0000705c56fd75e5  vmovaps [rsp+0x50], xmm5
0000705c56fd75eb  vmovaps [rsp+0x60], xmm7
0000705c56fd75f1  vmovaps [rsp+0x70], xmm8
0000705c56fd75f7  vmovaps [rsp+0x80], xmm9
0000705c56fd7600  vmovaps [rsp+0x90], xmm10
0000705c56fd7609  vmovaps [rsp+0xA0], xmm11
0000705c56fd7612  vmovaps [rsp+0xB0], xmm12
0000705c56fd761b  vmovaps [rsp+0xC0], xmm13
0000705c56fd7624  vmovaps [rsp+0xD0], xmm14
0000705c56fd762d  vmovaps [rsp+0xE0], xmm15
0000705c56fd7636  sub rsp, 0x30
0000705c56fd763a  movaps [rsp], xmm6
0000705c56fd763e  movaps [rsp+0x10], xmm9
0000705c56fd7644  movaps [rsp+0x20], xmm7
0000705c56fd7649  lea rdi, [rsp]
0000705c56fd764d  mov esi, 0x00
0000705c56fd7652  mov rax, 0x5877D3629530
0000705c56fd765c  call rax
0000705c56fd765e  movaps xmm6, [rsp]
0000705c56fd7662  add rsp, 0x30
0000705c56fd7666  vmovaps xmm0, [rsp]
0000705c56fd766b  vmovaps xmm1, [rsp+0x10]
0000705c56fd7671  vmovaps xmm2, [rsp+0x20]
0000705c56fd7677  vmovaps xmm3, [rsp+0x30]
0000705c56fd767d  vmovaps xmm4, [rsp+0x40]
0000705c56fd7683  vmovaps xmm5, [rsp+0x50]
0000705c56fd7689  vmovaps xmm7, [rsp+0x60]
0000705c56fd768f  vmovaps xmm8, [rsp+0x70]
0000705c56fd7695  vmovaps xmm9, [rsp+0x80]
0000705c56fd769e  vmovaps xmm10, [rsp+0x90]
0000705c56fd76a7  vmovaps xmm11, [rsp+0xA0]
0000705c56fd76b0  vmovaps xmm12, [rsp+0xB0]
0000705c56fd76b9  vmovaps xmm13, [rsp+0xC0]
0000705c56fd76c2  vmovaps xmm14, [rsp+0xD0]
0000705c56fd76cb  vmovaps xmm15, [rsp+0xE0]
0000705c56fd76d4  add rsp, 0xF0
0000705c56fd76db  pop r11
0000705c56fd76dd  pop r10
0000705c56fd76df  pop r9
0000705c56fd76e1  pop r8
0000705c56fd76e3  pop rsi
0000705c56fd76e4  pop rdi
0000705c56fd76e5  pop rdx
0000705c56fd76e6  pop rcx
0000705c56fd76e7  pop rax
0000705c56fd76e8  add rsp, 0x08
0000705c56fd76ec  jmp 0x0000705C56FD5CA7
0000705c56fd76f1  sub rsp, 0x08
0000705c56fd76f5  push rax
0000705c56fd76f6  push rcx
0000705c56fd76f7  push rdx
0000705c56fd76f8  push rdi
0000705c56fd76f9  push rsi
0000705c56fd76fa  push r8
0000705c56fd76fc  push r9
0000705c56fd76fe  push r10
0000705c56fd7700  push r11
0000705c56fd7702  sub rsp, 0xF0
0000705c56fd7709  vmovaps [rsp], xmm0
0000705c56fd770e  vmovaps [rsp+0x10], xmm1
0000705c56fd7714  vmovaps [rsp+0x20], xmm2
0000705c56fd771a  vmovaps [rsp+0x30], xmm3
0000705c56fd7720  vmovaps [rsp+0x40], xmm4
0000705c56fd7726  vmovaps [rsp+0x50], xmm5
0000705c56fd772c  vmovaps [rsp+0x60], xmm6
0000705c56fd7732  vmovaps [rsp+0x70], xmm8
0000705c56fd7738  vmovaps [rsp+0x80], xmm9
0000705c56fd7741  vmovaps [rsp+0x90], xmm10
0000705c56fd774a  vmovaps [rsp+0xA0], xmm11
0000705c56fd7753  vmovaps [rsp+0xB0], xmm12
0000705c56fd775c  vmovaps [rsp+0xC0], xmm13
0000705c56fd7765  vmovaps [rsp+0xD0], xmm14
0000705c56fd776e  vmovaps [rsp+0xE0], xmm15
0000705c56fd7777  sub rsp, 0x30
0000705c56fd777b  movaps [rsp], xmm7
0000705c56fd777f  movaps [rsp+0x10], xmm4
0000705c56fd7784  movaps [rsp+0x20], xmm9
0000705c56fd778a  lea rdi, [rsp]
0000705c56fd778e  mov esi, 0x00
0000705c56fd7793  mov rax, 0x5877D3629530
0000705c56fd779d  call rax
0000705c56fd779f  movaps xmm7, [rsp]
0000705c56fd77a3  add rsp, 0x30
0000705c56fd77a7  vmovaps xmm0, [rsp]
0000705c56fd77ac  vmovaps xmm1, [rsp+0x10]
0000705c56fd77b2  vmovaps xmm2, [rsp+0x20]
0000705c56fd77b8  vmovaps xmm3, [rsp+0x30]
0000705c56fd77be  vmovaps xmm4, [rsp+0x40]
0000705c56fd77c4  vmovaps xmm5, [rsp+0x50]
0000705c56fd77ca  vmovaps xmm6, [rsp+0x60]
0000705c56fd77d0  vmovaps xmm8, [rsp+0x70]
0000705c56fd77d6  vmovaps xmm9, [rsp+0x80]
0000705c56fd77df  vmovaps xmm10, [rsp+0x90]
0000705c56fd77e8  vmovaps xmm11, [rsp+0xA0]
0000705c56fd77f1  vmovaps xmm12, [rsp+0xB0]
0000705c56fd77fa  vmovaps xmm13, [rsp+0xC0]
0000705c56fd7803  vmovaps xmm14, [rsp+0xD0]
0000705c56fd780c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7815  add rsp, 0xF0
0000705c56fd781c  pop r11
0000705c56fd781e  pop r10
0000705c56fd7820  pop r9
0000705c56fd7822  pop r8
0000705c56fd7824  pop rsi
0000705c56fd7825  pop rdi
0000705c56fd7826  pop rdx
0000705c56fd7827  pop rcx
0000705c56fd7828  pop rax
0000705c56fd7829  add rsp, 0x08
0000705c56fd782d  jmp 0x0000705C56FD5CD4
0000705c56fd7832  sub rsp, 0x08
0000705c56fd7836  push rax
0000705c56fd7837  push rcx
0000705c56fd7838  push rdx
0000705c56fd7839  push rdi
0000705c56fd783a  push rsi
0000705c56fd783b  push r8
0000705c56fd783d  push r9
0000705c56fd783f  push r10
0000705c56fd7841  push r11
0000705c56fd7843  sub rsp, 0xF0
0000705c56fd784a  vmovaps [rsp], xmm0
0000705c56fd784f  vmovaps [rsp+0x10], xmm1
0000705c56fd7855  vmovaps [rsp+0x20], xmm2
0000705c56fd785b  vmovaps [rsp+0x30], xmm3
0000705c56fd7861  vmovaps [rsp+0x40], xmm5
0000705c56fd7867  vmovaps [rsp+0x50], xmm6
0000705c56fd786d  vmovaps [rsp+0x60], xmm7
0000705c56fd7873  vmovaps [rsp+0x70], xmm8
0000705c56fd7879  vmovaps [rsp+0x80], xmm9
0000705c56fd7882  vmovaps [rsp+0x90], xmm10
0000705c56fd788b  vmovaps [rsp+0xA0], xmm11
0000705c56fd7894  vmovaps [rsp+0xB0], xmm12
0000705c56fd789d  vmovaps [rsp+0xC0], xmm13
0000705c56fd78a6  vmovaps [rsp+0xD0], xmm14
0000705c56fd78af  vmovaps [rsp+0xE0], xmm15
0000705c56fd78b8  sub rsp, 0x30
0000705c56fd78bc  movaps [rsp], xmm4
0000705c56fd78c0  movaps [rsp+0x10], xmm15
0000705c56fd78c6  movaps [rsp+0x20], xmm9
0000705c56fd78cc  lea rdi, [rsp]
0000705c56fd78d0  mov esi, 0x00
0000705c56fd78d5  mov rax, 0x5877D3629530
0000705c56fd78df  call rax
0000705c56fd78e1  movaps xmm4, [rsp]
0000705c56fd78e5  add rsp, 0x30
0000705c56fd78e9  vmovaps xmm0, [rsp]
0000705c56fd78ee  vmovaps xmm1, [rsp+0x10]
0000705c56fd78f4  vmovaps xmm2, [rsp+0x20]
0000705c56fd78fa  vmovaps xmm3, [rsp+0x30]
0000705c56fd7900  vmovaps xmm5, [rsp+0x40]
0000705c56fd7906  vmovaps xmm6, [rsp+0x50]
0000705c56fd790c  vmovaps xmm7, [rsp+0x60]
0000705c56fd7912  vmovaps xmm8, [rsp+0x70]
0000705c56fd7918  vmovaps xmm9, [rsp+0x80]
0000705c56fd7921  vmovaps xmm10, [rsp+0x90]
0000705c56fd792a  vmovaps xmm11, [rsp+0xA0]
0000705c56fd7933  vmovaps xmm12, [rsp+0xB0]
0000705c56fd793c  vmovaps xmm13, [rsp+0xC0]
0000705c56fd7945  vmovaps xmm14, [rsp+0xD0]
0000705c56fd794e  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7957  add rsp, 0xF0
0000705c56fd795e  pop r11
0000705c56fd7960  pop r10
0000705c56fd7962  pop r9
0000705c56fd7964  pop r8
0000705c56fd7966  pop rsi
0000705c56fd7967  pop rdi
0000705c56fd7968  pop rdx
0000705c56fd7969  pop rcx
0000705c56fd796a  pop rax
0000705c56fd796b  add rsp, 0x08
0000705c56fd796f  jmp 0x0000705C56FD5CF9
0000705c56fd7974  call 0x0000705C56EE5820
0000705c56fd7979  jmp 0x0000705C56FD5D06
0000705c56fd797e  sub rsp, 0x08
0000705c56fd7982  push rax
0000705c56fd7983  push rcx
0000705c56fd7984  push rdx
0000705c56fd7985  push rdi
0000705c56fd7986  push rsi
0000705c56fd7987  push r8
0000705c56fd7989  push r9
0000705c56fd798b  push r10
0000705c56fd798d  push r11
0000705c56fd798f  sub rsp, 0xF0
0000705c56fd7996  vmovaps [rsp], xmm0
0000705c56fd799b  vmovaps [rsp+0x10], xmm1
0000705c56fd79a1  vmovaps [rsp+0x20], xmm2
0000705c56fd79a7  vmovaps [rsp+0x30], xmm4
0000705c56fd79ad  vmovaps [rsp+0x40], xmm5
0000705c56fd79b3  vmovaps [rsp+0x50], xmm6
0000705c56fd79b9  vmovaps [rsp+0x60], xmm7
0000705c56fd79bf  vmovaps [rsp+0x70], xmm8
0000705c56fd79c5  vmovaps [rsp+0x80], xmm9
0000705c56fd79ce  vmovaps [rsp+0x90], xmm10
0000705c56fd79d7  vmovaps [rsp+0xA0], xmm11
0000705c56fd79e0  vmovaps [rsp+0xB0], xmm12
0000705c56fd79e9  vmovaps [rsp+0xC0], xmm13
0000705c56fd79f2  vmovaps [rsp+0xD0], xmm14
0000705c56fd79fb  vmovaps [rsp+0xE0], xmm15
0000705c56fd7a04  sub rsp, 0x30
0000705c56fd7a08  movaps [rsp], xmm3
0000705c56fd7a0c  movaps [rsp+0x10], xmm1
0000705c56fd7a11  movaps [rsp+0x20], xmm9
0000705c56fd7a17  lea rdi, [rsp]
0000705c56fd7a1b  mov esi, 0x00
0000705c56fd7a20  mov rax, 0x5877D3629530
0000705c56fd7a2a  call rax
0000705c56fd7a2c  movaps xmm3, [rsp]
0000705c56fd7a30  add rsp, 0x30
0000705c56fd7a34  vmovaps xmm0, [rsp]
0000705c56fd7a39  vmovaps xmm1, [rsp+0x10]
0000705c56fd7a3f  vmovaps xmm2, [rsp+0x20]
0000705c56fd7a45  vmovaps xmm4, [rsp+0x30]
0000705c56fd7a4b  vmovaps xmm5, [rsp+0x40]
0000705c56fd7a51  vmovaps xmm6, [rsp+0x50]
0000705c56fd7a57  vmovaps xmm7, [rsp+0x60]
0000705c56fd7a5d  vmovaps xmm8, [rsp+0x70]
0000705c56fd7a63  vmovaps xmm9, [rsp+0x80]
0000705c56fd7a6c  vmovaps xmm10, [rsp+0x90]
0000705c56fd7a75  vmovaps xmm11, [rsp+0xA0]
0000705c56fd7a7e  vmovaps xmm12, [rsp+0xB0]
0000705c56fd7a87  vmovaps xmm13, [rsp+0xC0]
0000705c56fd7a90  vmovaps xmm14, [rsp+0xD0]
0000705c56fd7a99  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7aa2  add rsp, 0xF0
0000705c56fd7aa9  pop r11
0000705c56fd7aab  pop r10
0000705c56fd7aad  pop r9
0000705c56fd7aaf  pop r8
0000705c56fd7ab1  pop rsi
0000705c56fd7ab2  pop rdi
0000705c56fd7ab3  pop rdx
0000705c56fd7ab4  pop rcx
0000705c56fd7ab5  pop rax
0000705c56fd7ab6  add rsp, 0x08
0000705c56fd7aba  jmp 0x0000705C56FD5D43
0000705c56fd7abf  sub rsp, 0x08
0000705c56fd7ac3  push rax
0000705c56fd7ac4  push rcx
0000705c56fd7ac5  push rdx
0000705c56fd7ac6  push rdi
0000705c56fd7ac7  push rsi
0000705c56fd7ac8  push r8
0000705c56fd7aca  push r9
0000705c56fd7acc  push r10
0000705c56fd7ace  push r11
0000705c56fd7ad0  sub rsp, 0xF0
0000705c56fd7ad7  vmovaps [rsp], xmm0
0000705c56fd7adc  vmovaps [rsp+0x10], xmm2
0000705c56fd7ae2  vmovaps [rsp+0x20], xmm3
0000705c56fd7ae8  vmovaps [rsp+0x30], xmm4
0000705c56fd7aee  vmovaps [rsp+0x40], xmm5
0000705c56fd7af4  vmovaps [rsp+0x50], xmm6
0000705c56fd7afa  vmovaps [rsp+0x60], xmm7
0000705c56fd7b00  vmovaps [rsp+0x70], xmm8
0000705c56fd7b06  vmovaps [rsp+0x80], xmm9
0000705c56fd7b0f  vmovaps [rsp+0x90], xmm10
0000705c56fd7b18  vmovaps [rsp+0xA0], xmm11
0000705c56fd7b21  vmovaps [rsp+0xB0], xmm12
0000705c56fd7b2a  vmovaps [rsp+0xC0], xmm13
0000705c56fd7b33  vmovaps [rsp+0xD0], xmm14
0000705c56fd7b3c  vmovaps [rsp+0xE0], xmm15
0000705c56fd7b45  sub rsp, 0x30
0000705c56fd7b49  movaps [rsp], xmm1
0000705c56fd7b4d  movaps [rsp+0x10], xmm15
0000705c56fd7b53  movaps [rsp+0x20], xmm9
0000705c56fd7b59  lea rdi, [rsp]
0000705c56fd7b5d  mov esi, 0x00
0000705c56fd7b62  mov rax, 0x5877D3629530
0000705c56fd7b6c  call rax
0000705c56fd7b6e  movaps xmm1, [rsp]
0000705c56fd7b72  add rsp, 0x30
0000705c56fd7b76  vmovaps xmm0, [rsp]
0000705c56fd7b7b  vmovaps xmm2, [rsp+0x10]
0000705c56fd7b81  vmovaps xmm3, [rsp+0x20]
0000705c56fd7b87  vmovaps xmm4, [rsp+0x30]
0000705c56fd7b8d  vmovaps xmm5, [rsp+0x40]
0000705c56fd7b93  vmovaps xmm6, [rsp+0x50]
0000705c56fd7b99  vmovaps xmm7, [rsp+0x60]
0000705c56fd7b9f  vmovaps xmm8, [rsp+0x70]
0000705c56fd7ba5  vmovaps xmm9, [rsp+0x80]
0000705c56fd7bae  vmovaps xmm10, [rsp+0x90]
0000705c56fd7bb7  vmovaps xmm11, [rsp+0xA0]
0000705c56fd7bc0  vmovaps xmm12, [rsp+0xB0]
0000705c56fd7bc9  vmovaps xmm13, [rsp+0xC0]
0000705c56fd7bd2  vmovaps xmm14, [rsp+0xD0]
0000705c56fd7bdb  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7be4  add rsp, 0xF0
0000705c56fd7beb  pop r11
0000705c56fd7bed  pop r10
0000705c56fd7bef  pop r9
0000705c56fd7bf1  pop r8
0000705c56fd7bf3  pop rsi
0000705c56fd7bf4  pop rdi
0000705c56fd7bf5  pop rdx
0000705c56fd7bf6  pop rcx
0000705c56fd7bf7  pop rax
0000705c56fd7bf8  add rsp, 0x08
0000705c56fd7bfc  jmp 0x0000705C56FD5DCB
0000705c56fd7c01  call 0x0000705C56EE5820
0000705c56fd7c06  jmp 0x0000705C56FD5DD8
0000705c56fd7c0b  sub rsp, 0x08
0000705c56fd7c0f  push rax
0000705c56fd7c10  push rcx
0000705c56fd7c11  push rdx
0000705c56fd7c12  push rdi
0000705c56fd7c13  push rsi
0000705c56fd7c14  push r8
0000705c56fd7c16  push r9
0000705c56fd7c18  push r10
0000705c56fd7c1a  push r11
0000705c56fd7c1c  sub rsp, 0xF0
0000705c56fd7c23  vmovaps [rsp], xmm0
0000705c56fd7c28  vmovaps [rsp+0x10], xmm2
0000705c56fd7c2e  vmovaps [rsp+0x20], xmm3
0000705c56fd7c34  vmovaps [rsp+0x30], xmm4
0000705c56fd7c3a  vmovaps [rsp+0x40], xmm5
0000705c56fd7c40  vmovaps [rsp+0x50], xmm6
0000705c56fd7c46  vmovaps [rsp+0x60], xmm7
0000705c56fd7c4c  vmovaps [rsp+0x70], xmm8
0000705c56fd7c52  vmovaps [rsp+0x80], xmm9
0000705c56fd7c5b  vmovaps [rsp+0x90], xmm10
0000705c56fd7c64  vmovaps [rsp+0xA0], xmm11
0000705c56fd7c6d  vmovaps [rsp+0xB0], xmm12
0000705c56fd7c76  vmovaps [rsp+0xC0], xmm13
0000705c56fd7c7f  vmovaps [rsp+0xD0], xmm14
0000705c56fd7c88  vmovaps [rsp+0xE0], xmm15
0000705c56fd7c91  sub rsp, 0x30
0000705c56fd7c95  movaps [rsp], xmm1
0000705c56fd7c99  movaps [rsp+0x10], xmm5
0000705c56fd7c9e  movaps [rsp+0x20], xmm7
0000705c56fd7ca3  lea rdi, [rsp]
0000705c56fd7ca7  mov esi, 0x00
0000705c56fd7cac  mov rax, 0x5877D3629530
0000705c56fd7cb6  call rax
0000705c56fd7cb8  movaps xmm1, [rsp]
0000705c56fd7cbc  add rsp, 0x30
0000705c56fd7cc0  vmovaps xmm0, [rsp]
0000705c56fd7cc5  vmovaps xmm2, [rsp+0x10]
0000705c56fd7ccb  vmovaps xmm3, [rsp+0x20]
0000705c56fd7cd1  vmovaps xmm4, [rsp+0x30]
0000705c56fd7cd7  vmovaps xmm5, [rsp+0x40]
0000705c56fd7cdd  vmovaps xmm6, [rsp+0x50]
0000705c56fd7ce3  vmovaps xmm7, [rsp+0x60]
0000705c56fd7ce9  vmovaps xmm8, [rsp+0x70]
0000705c56fd7cef  vmovaps xmm9, [rsp+0x80]
0000705c56fd7cf8  vmovaps xmm10, [rsp+0x90]
0000705c56fd7d01  vmovaps xmm11, [rsp+0xA0]
0000705c56fd7d0a  vmovaps xmm12, [rsp+0xB0]
0000705c56fd7d13  vmovaps xmm13, [rsp+0xC0]
0000705c56fd7d1c  vmovaps xmm14, [rsp+0xD0]
0000705c56fd7d25  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7d2e  add rsp, 0xF0
0000705c56fd7d35  pop r11
0000705c56fd7d37  pop r10
0000705c56fd7d39  pop r9
0000705c56fd7d3b  pop r8
0000705c56fd7d3d  pop rsi
0000705c56fd7d3e  pop rdi
0000705c56fd7d3f  pop rdx
0000705c56fd7d40  pop rcx
0000705c56fd7d41  pop rax
0000705c56fd7d42  add rsp, 0x08
0000705c56fd7d46  jmp 0x0000705C56FD5E7D
0000705c56fd7d4b  sub rsp, 0x08
0000705c56fd7d4f  push rax
0000705c56fd7d50  push rcx
0000705c56fd7d51  push rdx
0000705c56fd7d52  push rdi
0000705c56fd7d53  push rsi
0000705c56fd7d54  push r8
0000705c56fd7d56  push r9
0000705c56fd7d58  push r10
0000705c56fd7d5a  push r11
0000705c56fd7d5c  sub rsp, 0xF0
0000705c56fd7d63  vmovaps [rsp], xmm0
0000705c56fd7d68  vmovaps [rsp+0x10], xmm1
0000705c56fd7d6e  vmovaps [rsp+0x20], xmm2
0000705c56fd7d74  vmovaps [rsp+0x30], xmm3
0000705c56fd7d7a  vmovaps [rsp+0x40], xmm4
0000705c56fd7d80  vmovaps [rsp+0x50], xmm5
0000705c56fd7d86  vmovaps [rsp+0x60], xmm6
0000705c56fd7d8c  vmovaps [rsp+0x70], xmm8
0000705c56fd7d92  vmovaps [rsp+0x80], xmm9
0000705c56fd7d9b  vmovaps [rsp+0x90], xmm10
0000705c56fd7da4  vmovaps [rsp+0xA0], xmm11
0000705c56fd7dad  vmovaps [rsp+0xB0], xmm12
0000705c56fd7db6  vmovaps [rsp+0xC0], xmm13
0000705c56fd7dbf  vmovaps [rsp+0xD0], xmm14
0000705c56fd7dc8  vmovaps [rsp+0xE0], xmm15
0000705c56fd7dd1  sub rsp, 0x30
0000705c56fd7dd5  movaps [rsp], xmm7
0000705c56fd7dd9  movaps [rsp+0x10], xmm5
0000705c56fd7dde  movaps [rsp+0x20], xmm15
0000705c56fd7de4  lea rdi, [rsp]
0000705c56fd7de8  mov esi, 0x00
0000705c56fd7ded  mov rax, 0x5877D3629530
0000705c56fd7df7  call rax
0000705c56fd7df9  movaps xmm7, [rsp]
0000705c56fd7dfd  add rsp, 0x30
0000705c56fd7e01  vmovaps xmm0, [rsp]
0000705c56fd7e06  vmovaps xmm1, [rsp+0x10]
0000705c56fd7e0c  vmovaps xmm2, [rsp+0x20]
0000705c56fd7e12  vmovaps xmm3, [rsp+0x30]
0000705c56fd7e18  vmovaps xmm4, [rsp+0x40]
0000705c56fd7e1e  vmovaps xmm5, [rsp+0x50]
0000705c56fd7e24  vmovaps xmm6, [rsp+0x60]
0000705c56fd7e2a  vmovaps xmm8, [rsp+0x70]
0000705c56fd7e30  vmovaps xmm9, [rsp+0x80]
0000705c56fd7e39  vmovaps xmm10, [rsp+0x90]
0000705c56fd7e42  vmovaps xmm11, [rsp+0xA0]
0000705c56fd7e4b  vmovaps xmm12, [rsp+0xB0]
0000705c56fd7e54  vmovaps xmm13, [rsp+0xC0]
0000705c56fd7e5d  vmovaps xmm14, [rsp+0xD0]
0000705c56fd7e66  vmovaps xmm15, [rsp+0xE0]
0000705c56fd7e6f  add rsp, 0xF0
0000705c56fd7e76  pop r11
0000705c56fd7e78  pop r10
0000705c56fd7e7a  pop r9
0000705c56fd7e7c  pop r8
0000705c56fd7e7e  pop rsi
0000705c56fd7e7f  pop rdi
0000705c56fd7e80  pop rdx
0000705c56fd7e81  pop rcx
0000705c56fd7e82  pop rax
0000705c56fd7e83  add rsp, 0x08
0000705c56fd7e87  jmp 0x0000705C56FD5EB3
0000705c56fd7e8c  call 0x0000705C56ED64F0
0000705c56fd7e91  jmp 0x0000705C56FD5EC0
0000705c56fd7e96  sub rsp, 0x08
0000705c56fd7e9a  push rax
0000705c56fd7e9b  push rcx
0000705c56fd7e9c  push rdx
0000705c56fd7e9d  push rdi
0000705c56fd7e9e  push rsi
0000705c56fd7e9f  push r8
0000705c56fd7ea1  push r9
0000705c56fd7ea3  push r10
0000705c56fd7ea5  push r11
0000705c56fd7ea7  sub rsp, 0xF0
0000705c56fd7eae  vmovaps [rsp], xmm0
0000705c56fd7eb3  vmovaps [rsp+0x10], xmm1
0000705c56fd7eb9  vmovaps [rsp+0x20], xmm2
0000705c56fd7ebf  vmovaps [rsp+0x30], xmm3
0000705c56fd7ec5  vmovaps [rsp+0x40], xmm4
0000705c56fd7ecb  vmovaps [rsp+0x50], xmm5
0000705c56fd7ed1  vmovaps [rsp+0x60], xmm6
0000705c56fd7ed7  vmovaps [rsp+0x70], xmm7
0000705c56fd7edd  vmovaps [rsp+0x80], xmm8
0000705c56fd7ee6  vmovaps [rsp+0x90], xmm9
0000705c56fd7eef  vmovaps [rsp+0xA0], xmm10
0000705c56fd7ef8  vmovaps [rsp+0xB0], xmm11
0000705c56fd7f01  vmovaps [rsp+0xC0], xmm12
0000705c56fd7f0a  vmovaps [rsp+0xD0], xmm13
0000705c56fd7f13  vmovaps [rsp+0xE0], xmm14
0000705c56fd7f1c  sub rsp, 0x30
0000705c56fd7f20  movaps [rsp], xmm15
0000705c56fd7f25  movaps [rsp+0x10], xmm5
0000705c56fd7f2a  movaps [rsp+0x20], xmm3
0000705c56fd7f2f  lea rdi, [rsp]
0000705c56fd7f33  mov esi, 0x00
0000705c56fd7f38  mov rax, 0x5877D3629530
0000705c56fd7f42  call rax
0000705c56fd7f44  movaps xmm15, [rsp]
0000705c56fd7f49  add rsp, 0x30
0000705c56fd7f4d  vmovaps xmm0, [rsp]
0000705c56fd7f52  vmovaps xmm1, [rsp+0x10]
0000705c56fd7f58  vmovaps xmm2, [rsp+0x20]
0000705c56fd7f5e  vmovaps xmm3, [rsp+0x30]
0000705c56fd7f64  vmovaps xmm4, [rsp+0x40]
0000705c56fd7f6a  vmovaps xmm5, [rsp+0x50]
0000705c56fd7f70  vmovaps xmm6, [rsp+0x60]
0000705c56fd7f76  vmovaps xmm7, [rsp+0x70]
0000705c56fd7f7c  vmovaps xmm8, [rsp+0x80]
0000705c56fd7f85  vmovaps xmm9, [rsp+0x90]
0000705c56fd7f8e  vmovaps xmm10, [rsp+0xA0]
0000705c56fd7f97  vmovaps xmm11, [rsp+0xB0]
0000705c56fd7fa0  vmovaps xmm12, [rsp+0xC0]
0000705c56fd7fa9  vmovaps xmm13, [rsp+0xD0]
0000705c56fd7fb2  vmovaps xmm14, [rsp+0xE0]
0000705c56fd7fbb  add rsp, 0xF0
0000705c56fd7fc2  pop r11
0000705c56fd7fc4  pop r10
0000705c56fd7fc6  pop r9
0000705c56fd7fc8  pop r8
0000705c56fd7fca  pop rsi
0000705c56fd7fcb  pop rdi
0000705c56fd7fcc  pop rdx
0000705c56fd7fcd  pop rcx
0000705c56fd7fce  pop rax
0000705c56fd7fcf  add rsp, 0x08
0000705c56fd7fd3  jmp 0x0000705C56FD5EE6
0000705c56fd7fd8  sub rsp, 0x08
0000705c56fd7fdc  push rax
0000705c56fd7fdd  push rcx
0000705c56fd7fde  push rdx
0000705c56fd7fdf  push rdi
0000705c56fd7fe0  push rsi
0000705c56fd7fe1  push r8
0000705c56fd7fe3  push r9
0000705c56fd7fe5  push r10
0000705c56fd7fe7  push r11
0000705c56fd7fe9  sub rsp, 0xF0
0000705c56fd7ff0  vmovaps [rsp], xmm0
0000705c56fd7ff5  vmovaps [rsp+0x10], xmm2
0000705c56fd7ffb  vmovaps [rsp+0x20], xmm3
0000705c56fd8001  vmovaps [rsp+0x30], xmm4
0000705c56fd8007  vmovaps [rsp+0x40], xmm5
0000705c56fd800d  vmovaps [rsp+0x50], xmm6
0000705c56fd8013  vmovaps [rsp+0x60], xmm7
0000705c56fd8019  vmovaps [rsp+0x70], xmm8
0000705c56fd801f  vmovaps [rsp+0x80], xmm9
0000705c56fd8028  vmovaps [rsp+0x90], xmm10
0000705c56fd8031  vmovaps [rsp+0xA0], xmm11
0000705c56fd803a  vmovaps [rsp+0xB0], xmm12
0000705c56fd8043  vmovaps [rsp+0xC0], xmm13
0000705c56fd804c  vmovaps [rsp+0xD0], xmm14
0000705c56fd8055  vmovaps [rsp+0xE0], xmm15
0000705c56fd805e  sub rsp, 0x30
0000705c56fd8062  movaps [rsp], xmm1
0000705c56fd8066  movaps [rsp+0x10], xmm5
0000705c56fd806b  movaps [rsp+0x20], xmm4
0000705c56fd8070  lea rdi, [rsp]
0000705c56fd8074  mov esi, 0x00
0000705c56fd8079  mov rax, 0x5877D3629530
0000705c56fd8083  call rax
0000705c56fd8085  movaps xmm1, [rsp]
0000705c56fd8089  add rsp, 0x30
0000705c56fd808d  vmovaps xmm0, [rsp]
0000705c56fd8092  vmovaps xmm2, [rsp+0x10]
0000705c56fd8098  vmovaps xmm3, [rsp+0x20]
0000705c56fd809e  vmovaps xmm4, [rsp+0x30]
0000705c56fd80a4  vmovaps xmm5, [rsp+0x40]
0000705c56fd80aa  vmovaps xmm6, [rsp+0x50]
0000705c56fd80b0  vmovaps xmm7, [rsp+0x60]
0000705c56fd80b6  vmovaps xmm8, [rsp+0x70]
0000705c56fd80bc  vmovaps xmm9, [rsp+0x80]
0000705c56fd80c5  vmovaps xmm10, [rsp+0x90]
0000705c56fd80ce  vmovaps xmm11, [rsp+0xA0]
0000705c56fd80d7  vmovaps xmm12, [rsp+0xB0]
0000705c56fd80e0  vmovaps xmm13, [rsp+0xC0]
0000705c56fd80e9  vmovaps xmm14, [rsp+0xD0]
0000705c56fd80f2  vmovaps xmm15, [rsp+0xE0]
0000705c56fd80fb  add rsp, 0xF0
0000705c56fd8102  pop r11
0000705c56fd8104  pop r10
0000705c56fd8106  pop r9
0000705c56fd8108  pop r8
0000705c56fd810a  pop rsi
0000705c56fd810b  pop rdi
0000705c56fd810c  pop rdx
0000705c56fd810d  pop rcx
0000705c56fd810e  pop rax
0000705c56fd810f  add rsp, 0x08
0000705c56fd8113  jmp 0x0000705C56FD5F06
0000705c56fd8118  sub rsp, 0x08
0000705c56fd811c  push rax
0000705c56fd811d  push rcx
0000705c56fd811e  push rdx
0000705c56fd811f  push rdi
0000705c56fd8120  push rsi
0000705c56fd8121  push r8
0000705c56fd8123  push r9
0000705c56fd8125  push r10
0000705c56fd8127  push r11
0000705c56fd8129  sub rsp, 0xF0
0000705c56fd8130  vmovaps [rsp], xmm0
0000705c56fd8135  vmovaps [rsp+0x10], xmm1
0000705c56fd813b  vmovaps [rsp+0x20], xmm2
0000705c56fd8141  vmovaps [rsp+0x30], xmm3
0000705c56fd8147  vmovaps [rsp+0x40], xmm5
0000705c56fd814d  vmovaps [rsp+0x50], xmm6
0000705c56fd8153  vmovaps [rsp+0x60], xmm7
0000705c56fd8159  vmovaps [rsp+0x70], xmm8
0000705c56fd815f  vmovaps [rsp+0x80], xmm9
0000705c56fd8168  vmovaps [rsp+0x90], xmm10
0000705c56fd8171  vmovaps [rsp+0xA0], xmm11
0000705c56fd817a  vmovaps [rsp+0xB0], xmm12
0000705c56fd8183  vmovaps [rsp+0xC0], xmm13
0000705c56fd818c  vmovaps [rsp+0xD0], xmm14
0000705c56fd8195  vmovaps [rsp+0xE0], xmm15
0000705c56fd819e  sub rsp, 0x30
0000705c56fd81a2  movaps [rsp], xmm4
0000705c56fd81a6  movaps [rsp+0x10], xmm3
0000705c56fd81ab  movaps [rsp+0x20], xmm5
0000705c56fd81b0  lea rdi, [rsp]
0000705c56fd81b4  mov esi, 0x00
0000705c56fd81b9  mov rax, 0x5877D3629530
0000705c56fd81c3  call rax
0000705c56fd81c5  movaps xmm4, [rsp]
0000705c56fd81c9  add rsp, 0x30
0000705c56fd81cd  vmovaps xmm0, [rsp]
0000705c56fd81d2  vmovaps xmm1, [rsp+0x10]
0000705c56fd81d8  vmovaps xmm2, [rsp+0x20]
0000705c56fd81de  vmovaps xmm3, [rsp+0x30]
0000705c56fd81e4  vmovaps xmm5, [rsp+0x40]
0000705c56fd81ea  vmovaps xmm6, [rsp+0x50]
0000705c56fd81f0  vmovaps xmm7, [rsp+0x60]
0000705c56fd81f6  vmovaps xmm8, [rsp+0x70]
0000705c56fd81fc  vmovaps xmm9, [rsp+0x80]
0000705c56fd8205  vmovaps xmm10, [rsp+0x90]
0000705c56fd820e  vmovaps xmm11, [rsp+0xA0]
0000705c56fd8217  vmovaps xmm12, [rsp+0xB0]
0000705c56fd8220  vmovaps xmm13, [rsp+0xC0]
0000705c56fd8229  vmovaps xmm14, [rsp+0xD0]
0000705c56fd8232  vmovaps xmm15, [rsp+0xE0]
0000705c56fd823b  add rsp, 0xF0
0000705c56fd8242  pop r11
0000705c56fd8244  pop r10
0000705c56fd8246  pop r9
0000705c56fd8248  pop r8
0000705c56fd824a  pop rsi
0000705c56fd824b  pop rdi
0000705c56fd824c  pop rdx
0000705c56fd824d  pop rcx
0000705c56fd824e  pop rax
0000705c56fd824f  add rsp, 0x08
0000705c56fd8253  jmp 0x0000705C56FD5F54
0000705c56fd8258  call 0x0000705C56ED64F0
0000705c56fd825d  jmp 0x0000705C56FD5F61
0000705c56fd8262  sub rsp, 0x08
0000705c56fd8266  push rax
0000705c56fd8267  push rcx
0000705c56fd8268  push rdx
0000705c56fd8269  push rdi
0000705c56fd826a  push rsi
0000705c56fd826b  push r8
0000705c56fd826d  push r9
0000705c56fd826f  push r10
0000705c56fd8271  push r11
0000705c56fd8273  sub rsp, 0xF0
0000705c56fd827a  vmovaps [rsp], xmm0
0000705c56fd827f  vmovaps [rsp+0x10], xmm1
0000705c56fd8285  vmovaps [rsp+0x20], xmm2
0000705c56fd828b  vmovaps [rsp+0x30], xmm3
0000705c56fd8291  vmovaps [rsp+0x40], xmm4
0000705c56fd8297  vmovaps [rsp+0x50], xmm6
0000705c56fd829d  vmovaps [rsp+0x60], xmm7
0000705c56fd82a3  vmovaps [rsp+0x70], xmm8
0000705c56fd82a9  vmovaps [rsp+0x80], xmm9
0000705c56fd82b2  vmovaps [rsp+0x90], xmm10
0000705c56fd82bb  vmovaps [rsp+0xA0], xmm11
0000705c56fd82c4  vmovaps [rsp+0xB0], xmm12
0000705c56fd82cd  vmovaps [rsp+0xC0], xmm13
0000705c56fd82d6  vmovaps [rsp+0xD0], xmm14
0000705c56fd82df  vmovaps [rsp+0xE0], xmm15
0000705c56fd82e8  sub rsp, 0x30
0000705c56fd82ec  movaps [rsp], xmm5
0000705c56fd82f0  movaps [rsp+0x10], xmm6
0000705c56fd82f5  movaps [rsp+0x20], xmm3
0000705c56fd82fa  lea rdi, [rsp]
0000705c56fd82fe  mov esi, 0x00
0000705c56fd8303  mov rax, 0x5877D3629530
0000705c56fd830d  call rax
0000705c56fd830f  movaps xmm5, [rsp]
0000705c56fd8313  add rsp, 0x30
0000705c56fd8317  vmovaps xmm0, [rsp]
0000705c56fd831c  vmovaps xmm1, [rsp+0x10]
0000705c56fd8322  vmovaps xmm2, [rsp+0x20]
0000705c56fd8328  vmovaps xmm3, [rsp+0x30]
0000705c56fd832e  vmovaps xmm4, [rsp+0x40]
0000705c56fd8334  vmovaps xmm6, [rsp+0x50]
0000705c56fd833a  vmovaps xmm7, [rsp+0x60]
0000705c56fd8340  vmovaps xmm8, [rsp+0x70]
0000705c56fd8346  vmovaps xmm9, [rsp+0x80]
0000705c56fd834f  vmovaps xmm10, [rsp+0x90]
0000705c56fd8358  vmovaps xmm11, [rsp+0xA0]
0000705c56fd8361  vmovaps xmm12, [rsp+0xB0]
0000705c56fd836a  vmovaps xmm13, [rsp+0xC0]
0000705c56fd8373  vmovaps xmm14, [rsp+0xD0]
0000705c56fd837c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd8385  add rsp, 0xF0
0000705c56fd838c  pop r11
0000705c56fd838e  pop r10
0000705c56fd8390  pop r9
0000705c56fd8392  pop r8
0000705c56fd8394  pop rsi
0000705c56fd8395  pop rdi
0000705c56fd8396  pop rdx
0000705c56fd8397  pop rcx
0000705c56fd8398  pop rax
0000705c56fd8399  add rsp, 0x08
0000705c56fd839d  jmp 0x0000705C56FD5F87
0000705c56fd83a2  sub rsp, 0x08
0000705c56fd83a6  push rax
0000705c56fd83a7  push rcx
0000705c56fd83a8  push rdx
0000705c56fd83a9  push rdi
0000705c56fd83aa  push rsi
0000705c56fd83ab  push r8
0000705c56fd83ad  push r9
0000705c56fd83af  push r10
0000705c56fd83b1  push r11
0000705c56fd83b3  sub rsp, 0xF0
0000705c56fd83ba  vmovaps [rsp], xmm0
0000705c56fd83bf  vmovaps [rsp+0x10], xmm1
0000705c56fd83c5  vmovaps [rsp+0x20], xmm2
0000705c56fd83cb  vmovaps [rsp+0x30], xmm3
0000705c56fd83d1  vmovaps [rsp+0x40], xmm4
0000705c56fd83d7  vmovaps [rsp+0x50], xmm5
0000705c56fd83dd  vmovaps [rsp+0x60], xmm7
0000705c56fd83e3  vmovaps [rsp+0x70], xmm8
0000705c56fd83e9  vmovaps [rsp+0x80], xmm9
0000705c56fd83f2  vmovaps [rsp+0x90], xmm10
0000705c56fd83fb  vmovaps [rsp+0xA0], xmm11
0000705c56fd8404  vmovaps [rsp+0xB0], xmm12
0000705c56fd840d  vmovaps [rsp+0xC0], xmm13
0000705c56fd8416  vmovaps [rsp+0xD0], xmm14
0000705c56fd841f  vmovaps [rsp+0xE0], xmm15
0000705c56fd8428  sub rsp, 0x30
0000705c56fd842c  movaps [rsp], xmm6
0000705c56fd8430  movaps [rsp+0x10], xmm9
0000705c56fd8436  movaps [rsp+0x20], xmm1
0000705c56fd843b  lea rdi, [rsp]
0000705c56fd843f  mov esi, 0x00
0000705c56fd8444  mov rax, 0x5877D3629530
0000705c56fd844e  call rax
0000705c56fd8450  movaps xmm6, [rsp]
0000705c56fd8454  add rsp, 0x30
0000705c56fd8458  vmovaps xmm0, [rsp]
0000705c56fd845d  vmovaps xmm1, [rsp+0x10]
0000705c56fd8463  vmovaps xmm2, [rsp+0x20]
0000705c56fd8469  vmovaps xmm3, [rsp+0x30]
0000705c56fd846f  vmovaps xmm4, [rsp+0x40]
0000705c56fd8475  vmovaps xmm5, [rsp+0x50]
0000705c56fd847b  vmovaps xmm7, [rsp+0x60]
0000705c56fd8481  vmovaps xmm8, [rsp+0x70]
0000705c56fd8487  vmovaps xmm9, [rsp+0x80]
0000705c56fd8490  vmovaps xmm10, [rsp+0x90]
0000705c56fd8499  vmovaps xmm11, [rsp+0xA0]
0000705c56fd84a2  vmovaps xmm12, [rsp+0xB0]
0000705c56fd84ab  vmovaps xmm13, [rsp+0xC0]
0000705c56fd84b4  vmovaps xmm14, [rsp+0xD0]
0000705c56fd84bd  vmovaps xmm15, [rsp+0xE0]
0000705c56fd84c6  add rsp, 0xF0
0000705c56fd84cd  pop r11
0000705c56fd84cf  pop r10
0000705c56fd84d1  pop r9
0000705c56fd84d3  pop r8
0000705c56fd84d5  pop rsi
0000705c56fd84d6  pop rdi
0000705c56fd84d7  pop rdx
0000705c56fd84d8  pop rcx
0000705c56fd84d9  pop rax
0000705c56fd84da  add rsp, 0x08
0000705c56fd84de  jmp 0x0000705C56FD5FAB
0000705c56fd84e3  sub rsp, 0x08
0000705c56fd84e7  push rax
0000705c56fd84e8  push rcx
0000705c56fd84e9  push rdx
0000705c56fd84ea  push rdi
0000705c56fd84eb  push rsi
0000705c56fd84ec  push r8
0000705c56fd84ee  push r9
0000705c56fd84f0  push r10
0000705c56fd84f2  push r11
0000705c56fd84f4  sub rsp, 0xF0
0000705c56fd84fb  vmovaps [rsp], xmm0
0000705c56fd8500  vmovaps [rsp+0x10], xmm1
0000705c56fd8506  vmovaps [rsp+0x20], xmm2
0000705c56fd850c  vmovaps [rsp+0x30], xmm3
0000705c56fd8512  vmovaps [rsp+0x40], xmm4
0000705c56fd8518  vmovaps [rsp+0x50], xmm5
0000705c56fd851e  vmovaps [rsp+0x60], xmm6
0000705c56fd8524  vmovaps [rsp+0x70], xmm7
0000705c56fd852a  vmovaps [rsp+0x80], xmm8
0000705c56fd8533  vmovaps [rsp+0x90], xmm10
0000705c56fd853c  vmovaps [rsp+0xA0], xmm11
0000705c56fd8545  vmovaps [rsp+0xB0], xmm12
0000705c56fd854e  vmovaps [rsp+0xC0], xmm13
0000705c56fd8557  vmovaps [rsp+0xD0], xmm14
0000705c56fd8560  vmovaps [rsp+0xE0], xmm15
0000705c56fd8569  sub rsp, 0x30
0000705c56fd856d  movaps [rsp], xmm9
0000705c56fd8572  movaps [rsp+0x10], xmm3
0000705c56fd8577  movaps [rsp+0x20], xmm1
0000705c56fd857c  lea rdi, [rsp]
0000705c56fd8580  mov esi, 0x00
0000705c56fd8585  mov rax, 0x5877D3629530
0000705c56fd858f  call rax
0000705c56fd8591  movaps xmm9, [rsp]
0000705c56fd8596  add rsp, 0x30
0000705c56fd859a  vmovaps xmm0, [rsp]
0000705c56fd859f  vmovaps xmm1, [rsp+0x10]
0000705c56fd85a5  vmovaps xmm2, [rsp+0x20]
0000705c56fd85ab  vmovaps xmm3, [rsp+0x30]
0000705c56fd85b1  vmovaps xmm4, [rsp+0x40]
0000705c56fd85b7  vmovaps xmm5, [rsp+0x50]
0000705c56fd85bd  vmovaps xmm6, [rsp+0x60]
0000705c56fd85c3  vmovaps xmm7, [rsp+0x70]
0000705c56fd85c9  vmovaps xmm8, [rsp+0x80]
0000705c56fd85d2  vmovaps xmm10, [rsp+0x90]
0000705c56fd85db  vmovaps xmm11, [rsp+0xA0]
0000705c56fd85e4  vmovaps xmm12, [rsp+0xB0]
0000705c56fd85ed  vmovaps xmm13, [rsp+0xC0]
0000705c56fd85f6  vmovaps xmm14, [rsp+0xD0]
0000705c56fd85ff  vmovaps xmm15, [rsp+0xE0]
0000705c56fd8608  add rsp, 0xF0
0000705c56fd860f  pop r11
0000705c56fd8611  pop r10
0000705c56fd8613  pop r9
0000705c56fd8615  pop r8
0000705c56fd8617  pop rsi
0000705c56fd8618  pop rdi
0000705c56fd8619  pop rdx
0000705c56fd861a  pop rcx
0000705c56fd861b  pop rax
0000705c56fd861c  add rsp, 0x08
0000705c56fd8620  jmp 0x0000705C56FD5FF7
0000705c56fd8625  call 0x0000705C56ED64F0
0000705c56fd862a  jmp 0x0000705C56FD6004
0000705c56fd862f  sub rsp, 0x08
0000705c56fd8633  push rax
0000705c56fd8634  push rcx
0000705c56fd8635  push rdx
0000705c56fd8636  push rdi
0000705c56fd8637  push rsi
0000705c56fd8638  push r8
0000705c56fd863a  push r9
0000705c56fd863c  push r10
0000705c56fd863e  push r11
0000705c56fd8640  sub rsp, 0xF0
0000705c56fd8647  vmovaps [rsp], xmm0
0000705c56fd864c  vmovaps [rsp+0x10], xmm1
0000705c56fd8652  vmovaps [rsp+0x20], xmm2
0000705c56fd8658  vmovaps [rsp+0x30], xmm3
0000705c56fd865e  vmovaps [rsp+0x40], xmm4
0000705c56fd8664  vmovaps [rsp+0x50], xmm5
0000705c56fd866a  vmovaps [rsp+0x60], xmm6
0000705c56fd8670  vmovaps [rsp+0x70], xmm7
0000705c56fd8676  vmovaps [rsp+0x80], xmm8
0000705c56fd867f  vmovaps [rsp+0x90], xmm9
0000705c56fd8688  vmovaps [rsp+0xA0], xmm10
0000705c56fd8691  vmovaps [rsp+0xB0], xmm11
0000705c56fd869a  vmovaps [rsp+0xC0], xmm12
0000705c56fd86a3  vmovaps [rsp+0xD0], xmm13
0000705c56fd86ac  vmovaps [rsp+0xE0], xmm14
0000705c56fd86b5  sub rsp, 0x30
0000705c56fd86b9  movaps [rsp], xmm15
0000705c56fd86be  movaps [rsp+0x10], xmm3
0000705c56fd86c3  movaps [rsp+0x20], xmm7
0000705c56fd86c8  lea rdi, [rsp]
0000705c56fd86cc  mov esi, 0x00
0000705c56fd86d1  mov rax, 0x5877D3629530
0000705c56fd86db  call rax
0000705c56fd86dd  movaps xmm15, [rsp]
0000705c56fd86e2  add rsp, 0x30
0000705c56fd86e6  vmovaps xmm0, [rsp]
0000705c56fd86eb  vmovaps xmm1, [rsp+0x10]
0000705c56fd86f1  vmovaps xmm2, [rsp+0x20]
0000705c56fd86f7  vmovaps xmm3, [rsp+0x30]
0000705c56fd86fd  vmovaps xmm4, [rsp+0x40]
0000705c56fd8703  vmovaps xmm5, [rsp+0x50]
0000705c56fd8709  vmovaps xmm6, [rsp+0x60]
0000705c56fd870f  vmovaps xmm7, [rsp+0x70]
0000705c56fd8715  vmovaps xmm8, [rsp+0x80]
0000705c56fd871e  vmovaps xmm9, [rsp+0x90]
0000705c56fd8727  vmovaps xmm10, [rsp+0xA0]
0000705c56fd8730  vmovaps xmm11, [rsp+0xB0]
0000705c56fd8739  vmovaps xmm12, [rsp+0xC0]
0000705c56fd8742  vmovaps xmm13, [rsp+0xD0]
0000705c56fd874b  vmovaps xmm14, [rsp+0xE0]
0000705c56fd8754  add rsp, 0xF0
0000705c56fd875b  pop r11
0000705c56fd875d  pop r10
0000705c56fd875f  pop r9
0000705c56fd8761  pop r8
0000705c56fd8763  pop rsi
0000705c56fd8764  pop rdi
0000705c56fd8765  pop rdx
0000705c56fd8766  pop rcx
0000705c56fd8767  pop rax
0000705c56fd8768  add rsp, 0x08
0000705c56fd876c  jmp 0x0000705C56FD6030
0000705c56fd8771  sub rsp, 0x08
0000705c56fd8775  push rax
0000705c56fd8776  push rcx
0000705c56fd8777  push rdx
0000705c56fd8778  push rdi
0000705c56fd8779  push rsi
0000705c56fd877a  push r8
0000705c56fd877c  push r9
0000705c56fd877e  push r10
0000705c56fd8780  push r11
0000705c56fd8782  sub rsp, 0xF0
0000705c56fd8789  vmovaps [rsp], xmm0
0000705c56fd878e  vmovaps [rsp+0x10], xmm1
0000705c56fd8794  vmovaps [rsp+0x20], xmm2
0000705c56fd879a  vmovaps [rsp+0x30], xmm4
0000705c56fd87a0  vmovaps [rsp+0x40], xmm5
0000705c56fd87a6  vmovaps [rsp+0x50], xmm6
0000705c56fd87ac  vmovaps [rsp+0x60], xmm7
0000705c56fd87b2  vmovaps [rsp+0x70], xmm8
0000705c56fd87b8  vmovaps [rsp+0x80], xmm9
0000705c56fd87c1  vmovaps [rsp+0x90], xmm10
0000705c56fd87ca  vmovaps [rsp+0xA0], xmm11
0000705c56fd87d3  vmovaps [rsp+0xB0], xmm12
0000705c56fd87dc  vmovaps [rsp+0xC0], xmm13
0000705c56fd87e5  vmovaps [rsp+0xD0], xmm14
0000705c56fd87ee  vmovaps [rsp+0xE0], xmm15
0000705c56fd87f7  sub rsp, 0x30
0000705c56fd87fb  movaps [rsp], xmm3
0000705c56fd87ff  movaps [rsp+0x10], xmm1
0000705c56fd8804  movaps [rsp+0x20], xmm15
0000705c56fd880a  lea rdi, [rsp]
0000705c56fd880e  mov esi, 0x00
0000705c56fd8813  mov rax, 0x5877D3629530
0000705c56fd881d  call rax
0000705c56fd881f  movaps xmm3, [rsp]
0000705c56fd8823  add rsp, 0x30
0000705c56fd8827  vmovaps xmm0, [rsp]
0000705c56fd882c  vmovaps xmm1, [rsp+0x10]
0000705c56fd8832  vmovaps xmm2, [rsp+0x20]
0000705c56fd8838  vmovaps xmm4, [rsp+0x30]
0000705c56fd883e  vmovaps xmm5, [rsp+0x40]
0000705c56fd8844  vmovaps xmm6, [rsp+0x50]
0000705c56fd884a  vmovaps xmm7, [rsp+0x60]
0000705c56fd8850  vmovaps xmm8, [rsp+0x70]
0000705c56fd8856  vmovaps xmm9, [rsp+0x80]
0000705c56fd885f  vmovaps xmm10, [rsp+0x90]
0000705c56fd8868  vmovaps xmm11, [rsp+0xA0]
0000705c56fd8871  vmovaps xmm12, [rsp+0xB0]
0000705c56fd887a  vmovaps xmm13, [rsp+0xC0]
0000705c56fd8883  vmovaps xmm14, [rsp+0xD0]
0000705c56fd888c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd8895  add rsp, 0xF0
0000705c56fd889c  pop r11
0000705c56fd889e  pop r10
0000705c56fd88a0  pop r9
0000705c56fd88a2  pop r8
0000705c56fd88a4  pop rsi
0000705c56fd88a5  pop rdi
0000705c56fd88a6  pop rdx
0000705c56fd88a7  pop rcx
0000705c56fd88a8  pop rax
0000705c56fd88a9  add rsp, 0x08
0000705c56fd88ad  jmp 0x0000705C56FD60BF
0000705c56fd88b2  call 0x0000705C56ED64F0
0000705c56fd88b7  jmp 0x0000705C56FD60C9
0000705c56fd88bc  sub rsp, 0x08
0000705c56fd88c0  push rax
0000705c56fd88c1  push rcx
0000705c56fd88c2  push rdx
0000705c56fd88c3  push rdi
0000705c56fd88c4  push rsi
0000705c56fd88c5  push r8
0000705c56fd88c7  push r9
0000705c56fd88c9  push r10
0000705c56fd88cb  push r11
0000705c56fd88cd  sub rsp, 0xF0
0000705c56fd88d4  vmovaps [rsp], xmm0
0000705c56fd88d9  vmovaps [rsp+0x10], xmm1
0000705c56fd88df  vmovaps [rsp+0x20], xmm2
0000705c56fd88e5  vmovaps [rsp+0x30], xmm3
0000705c56fd88eb  vmovaps [rsp+0x40], xmm4
0000705c56fd88f1  vmovaps [rsp+0x50], xmm5
0000705c56fd88f7  vmovaps [rsp+0x60], xmm6
0000705c56fd88fd  vmovaps [rsp+0x70], xmm7
0000705c56fd8903  vmovaps [rsp+0x80], xmm8
0000705c56fd890c  vmovaps [rsp+0x90], xmm9
0000705c56fd8915  vmovaps [rsp+0xA0], xmm10
0000705c56fd891e  vmovaps [rsp+0xB0], xmm11
0000705c56fd8927  vmovaps [rsp+0xC0], xmm12
0000705c56fd8930  vmovaps [rsp+0xD0], xmm13
0000705c56fd8939  vmovaps [rsp+0xE0], xmm14
0000705c56fd8942  sub rsp, 0x30
0000705c56fd8946  movaps [rsp], xmm15
0000705c56fd894b  movaps [rsp+0x10], xmm14
0000705c56fd8951  movaps [rsp+0x20], xmm4
0000705c56fd8956  lea rdi, [rsp]
0000705c56fd895a  mov esi, 0x00
0000705c56fd895f  mov rax, 0x5877D3629530
0000705c56fd8969  call rax
0000705c56fd896b  movaps xmm15, [rsp]
0000705c56fd8970  add rsp, 0x30
0000705c56fd8974  vmovaps xmm0, [rsp]
0000705c56fd8979  vmovaps xmm1, [rsp+0x10]
0000705c56fd897f  vmovaps xmm2, [rsp+0x20]
0000705c56fd8985  vmovaps xmm3, [rsp+0x30]
0000705c56fd898b  vmovaps xmm4, [rsp+0x40]
0000705c56fd8991  vmovaps xmm5, [rsp+0x50]
0000705c56fd8997  vmovaps xmm6, [rsp+0x60]
0000705c56fd899d  vmovaps xmm7, [rsp+0x70]
0000705c56fd89a3  vmovaps xmm8, [rsp+0x80]
0000705c56fd89ac  vmovaps xmm9, [rsp+0x90]
0000705c56fd89b5  vmovaps xmm10, [rsp+0xA0]
0000705c56fd89be  vmovaps xmm11, [rsp+0xB0]
0000705c56fd89c7  vmovaps xmm12, [rsp+0xC0]
0000705c56fd89d0  vmovaps xmm13, [rsp+0xD0]
0000705c56fd89d9  vmovaps xmm14, [rsp+0xE0]
0000705c56fd89e2  add rsp, 0xF0
0000705c56fd89e9  pop r11
0000705c56fd89eb  pop r10
0000705c56fd89ed  pop r9
0000705c56fd89ef  pop r8
0000705c56fd89f1  pop rsi
0000705c56fd89f2  pop rdi
0000705c56fd89f3  pop rdx
0000705c56fd89f4  pop rcx
0000705c56fd89f5  pop rax
0000705c56fd89f6  add rsp, 0x08
0000705c56fd89fa  jmp 0x0000705C56FD60F7
0000705c56fd89ff  sub rsp, 0x08
0000705c56fd8a03  push rax
0000705c56fd8a04  push rcx
0000705c56fd8a05  push rdx
0000705c56fd8a06  push rdi
0000705c56fd8a07  push rsi
0000705c56fd8a08  push r8
0000705c56fd8a0a  push r9
0000705c56fd8a0c  push r10
0000705c56fd8a0e  push r11
0000705c56fd8a10  sub rsp, 0xF0
0000705c56fd8a17  vmovaps [rsp], xmm0
0000705c56fd8a1c  vmovaps [rsp+0x10], xmm1
0000705c56fd8a22  vmovaps [rsp+0x20], xmm2
0000705c56fd8a28  vmovaps [rsp+0x30], xmm3
0000705c56fd8a2e  vmovaps [rsp+0x40], xmm4
0000705c56fd8a34  vmovaps [rsp+0x50], xmm5
0000705c56fd8a3a  vmovaps [rsp+0x60], xmm6
0000705c56fd8a40  vmovaps [rsp+0x70], xmm7
0000705c56fd8a46  vmovaps [rsp+0x80], xmm8
0000705c56fd8a4f  vmovaps [rsp+0x90], xmm9
0000705c56fd8a58  vmovaps [rsp+0xA0], xmm10
0000705c56fd8a61  vmovaps [rsp+0xB0], xmm11
0000705c56fd8a6a  vmovaps [rsp+0xC0], xmm12
0000705c56fd8a73  vmovaps [rsp+0xD0], xmm13
0000705c56fd8a7c  vmovaps [rsp+0xE0], xmm15
0000705c56fd8a85  sub rsp, 0x30
0000705c56fd8a89  movaps [rsp], xmm14
0000705c56fd8a8e  movaps [rsp+0x10], xmm2
0000705c56fd8a93  movaps [rsp+0x20], xmm1
0000705c56fd8a98  lea rdi, [rsp]
0000705c56fd8a9c  mov esi, 0x00
0000705c56fd8aa1  mov rax, 0x5877D3629530
0000705c56fd8aab  call rax
0000705c56fd8aad  movaps xmm14, [rsp]
0000705c56fd8ab2  add rsp, 0x30
0000705c56fd8ab6  vmovaps xmm0, [rsp]
0000705c56fd8abb  vmovaps xmm1, [rsp+0x10]
0000705c56fd8ac1  vmovaps xmm2, [rsp+0x20]
0000705c56fd8ac7  vmovaps xmm3, [rsp+0x30]
0000705c56fd8acd  vmovaps xmm4, [rsp+0x40]
0000705c56fd8ad3  vmovaps xmm5, [rsp+0x50]
0000705c56fd8ad9  vmovaps xmm6, [rsp+0x60]
0000705c56fd8adf  vmovaps xmm7, [rsp+0x70]
0000705c56fd8ae5  vmovaps xmm8, [rsp+0x80]
0000705c56fd8aee  vmovaps xmm9, [rsp+0x90]
0000705c56fd8af7  vmovaps xmm10, [rsp+0xA0]
0000705c56fd8b00  vmovaps xmm11, [rsp+0xB0]
0000705c56fd8b09  vmovaps xmm12, [rsp+0xC0]
0000705c56fd8b12  vmovaps xmm13, [rsp+0xD0]
0000705c56fd8b1b  vmovaps xmm15, [rsp+0xE0]
0000705c56fd8b24  add rsp, 0xF0
0000705c56fd8b2b  pop r11
0000705c56fd8b2d  pop r10
0000705c56fd8b2f  pop r9
0000705c56fd8b31  pop r8
0000705c56fd8b33  pop rsi
0000705c56fd8b34  pop rdi
0000705c56fd8b35  pop rdx
0000705c56fd8b36  pop rcx
0000705c56fd8b37  pop rax
0000705c56fd8b38  add rsp, 0x08
0000705c56fd8b3c  jmp 0x0000705C56FD611D
0000705c56fd8b41  sub rsp, 0x08
0000705c56fd8b45  push rax
0000705c56fd8b46  push rcx
0000705c56fd8b47  push rdx
0000705c56fd8b48  push rdi
0000705c56fd8b49  push rsi
0000705c56fd8b4a  push r8
0000705c56fd8b4c  push r9
0000705c56fd8b4e  push r10
0000705c56fd8b50  push r11
0000705c56fd8b52  sub rsp, 0xF0
0000705c56fd8b59  vmovaps [rsp], xmm0
0000705c56fd8b5e  vmovaps [rsp+0x10], xmm2
0000705c56fd8b64  vmovaps [rsp+0x20], xmm3
0000705c56fd8b6a  vmovaps [rsp+0x30], xmm4
0000705c56fd8b70  vmovaps [rsp+0x40], xmm5
0000705c56fd8b76  vmovaps [rsp+0x50], xmm6
0000705c56fd8b7c  vmovaps [rsp+0x60], xmm7
0000705c56fd8b82  vmovaps [rsp+0x70], xmm8
0000705c56fd8b88  vmovaps [rsp+0x80], xmm9
0000705c56fd8b91  vmovaps [rsp+0x90], xmm10
0000705c56fd8b9a  vmovaps [rsp+0xA0], xmm11
0000705c56fd8ba3  vmovaps [rsp+0xB0], xmm12
0000705c56fd8bac  vmovaps [rsp+0xC0], xmm13
0000705c56fd8bb5  vmovaps [rsp+0xD0], xmm14
0000705c56fd8bbe  vmovaps [rsp+0xE0], xmm15
0000705c56fd8bc7  sub rsp, 0x30
0000705c56fd8bcb  movaps [rsp], xmm1
0000705c56fd8bcf  movaps [rsp+0x10], xmm4
0000705c56fd8bd4  movaps [rsp+0x20], xmm9
0000705c56fd8bda  lea rdi, [rsp]
0000705c56fd8bde  mov esi, 0x00
0000705c56fd8be3  mov rax, 0x5877D3629530
0000705c56fd8bed  call rax
0000705c56fd8bef  movaps xmm1, [rsp]
0000705c56fd8bf3  add rsp, 0x30
0000705c56fd8bf7  vmovaps xmm0, [rsp]
0000705c56fd8bfc  vmovaps xmm2, [rsp+0x10]
0000705c56fd8c02  vmovaps xmm3, [rsp+0x20]
0000705c56fd8c08  vmovaps xmm4, [rsp+0x30]
0000705c56fd8c0e  vmovaps xmm5, [rsp+0x40]
0000705c56fd8c14  vmovaps xmm6, [rsp+0x50]
0000705c56fd8c1a  vmovaps xmm7, [rsp+0x60]
0000705c56fd8c20  vmovaps xmm8, [rsp+0x70]
0000705c56fd8c26  vmovaps xmm9, [rsp+0x80]
0000705c56fd8c2f  vmovaps xmm10, [rsp+0x90]
0000705c56fd8c38  vmovaps xmm11, [rsp+0xA0]
0000705c56fd8c41  vmovaps xmm12, [rsp+0xB0]
0000705c56fd8c4a  vmovaps xmm13, [rsp+0xC0]
0000705c56fd8c53  vmovaps xmm14, [rsp+0xD0]
0000705c56fd8c5c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd8c65  add rsp, 0xF0
0000705c56fd8c6c  pop r11
0000705c56fd8c6e  pop r10
0000705c56fd8c70  pop r9
0000705c56fd8c72  pop r8
0000705c56fd8c74  pop rsi
0000705c56fd8c75  pop rdi
0000705c56fd8c76  pop rdx
0000705c56fd8c77  pop rcx
0000705c56fd8c78  pop rax
0000705c56fd8c79  add rsp, 0x08
0000705c56fd8c7d  jmp 0x0000705C56FD613B
0000705c56fd8c82  sub rsp, 0x08
0000705c56fd8c86  push rax
0000705c56fd8c87  push rcx
0000705c56fd8c88  push rdx
0000705c56fd8c89  push rdi
0000705c56fd8c8a  push rsi
0000705c56fd8c8b  push r8
0000705c56fd8c8d  push r9
0000705c56fd8c8f  push r10
0000705c56fd8c91  push r11
0000705c56fd8c93  sub rsp, 0xF0
0000705c56fd8c9a  vmovaps [rsp], xmm0
0000705c56fd8c9f  vmovaps [rsp+0x10], xmm1
0000705c56fd8ca5  vmovaps [rsp+0x20], xmm2
0000705c56fd8cab  vmovaps [rsp+0x30], xmm3
0000705c56fd8cb1  vmovaps [rsp+0x40], xmm5
0000705c56fd8cb7  vmovaps [rsp+0x50], xmm6
0000705c56fd8cbd  vmovaps [rsp+0x60], xmm7
0000705c56fd8cc3  vmovaps [rsp+0x70], xmm8
0000705c56fd8cc9  vmovaps [rsp+0x80], xmm9
0000705c56fd8cd2  vmovaps [rsp+0x90], xmm10
0000705c56fd8cdb  vmovaps [rsp+0xA0], xmm11
0000705c56fd8ce4  vmovaps [rsp+0xB0], xmm12
0000705c56fd8ced  vmovaps [rsp+0xC0], xmm13
0000705c56fd8cf6  vmovaps [rsp+0xD0], xmm14
0000705c56fd8cff  vmovaps [rsp+0xE0], xmm15
0000705c56fd8d08  sub rsp, 0x30
0000705c56fd8d0c  movaps [rsp], xmm4
0000705c56fd8d10  movaps [rsp+0x10], xmm2
0000705c56fd8d15  movaps [rsp+0x20], xmm9
0000705c56fd8d1b  lea rdi, [rsp]
0000705c56fd8d1f  mov esi, 0x00
0000705c56fd8d24  mov rax, 0x5877D3629530
0000705c56fd8d2e  call rax
0000705c56fd8d30  movaps xmm4, [rsp]
0000705c56fd8d34  add rsp, 0x30
0000705c56fd8d38  vmovaps xmm0, [rsp]
0000705c56fd8d3d  vmovaps xmm1, [rsp+0x10]
0000705c56fd8d43  vmovaps xmm2, [rsp+0x20]
0000705c56fd8d49  vmovaps xmm3, [rsp+0x30]
0000705c56fd8d4f  vmovaps xmm5, [rsp+0x40]
0000705c56fd8d55  vmovaps xmm6, [rsp+0x50]
0000705c56fd8d5b  vmovaps xmm7, [rsp+0x60]
0000705c56fd8d61  vmovaps xmm8, [rsp+0x70]
0000705c56fd8d67  vmovaps xmm9, [rsp+0x80]
0000705c56fd8d70  vmovaps xmm10, [rsp+0x90]
0000705c56fd8d79  vmovaps xmm11, [rsp+0xA0]
0000705c56fd8d82  vmovaps xmm12, [rsp+0xB0]
0000705c56fd8d8b  vmovaps xmm13, [rsp+0xC0]
0000705c56fd8d94  vmovaps xmm14, [rsp+0xD0]
0000705c56fd8d9d  vmovaps xmm15, [rsp+0xE0]
0000705c56fd8da6  add rsp, 0xF0
0000705c56fd8dad  pop r11
0000705c56fd8daf  pop r10
0000705c56fd8db1  pop r9
0000705c56fd8db3  pop r8
0000705c56fd8db5  pop rsi
0000705c56fd8db6  pop rdi
0000705c56fd8db7  pop rdx
0000705c56fd8db8  pop rcx
0000705c56fd8db9  pop rax
0000705c56fd8dba  add rsp, 0x08
0000705c56fd8dbe  jmp 0x0000705C56FD616B
0000705c56fd8dc3  sub rsp, 0x08
0000705c56fd8dc7  push rax
0000705c56fd8dc8  push rcx
0000705c56fd8dc9  push rdx
0000705c56fd8dca  push rdi
0000705c56fd8dcb  push rsi
0000705c56fd8dcc  push r8
0000705c56fd8dce  push r9
0000705c56fd8dd0  push r10
0000705c56fd8dd2  push r11
0000705c56fd8dd4  sub rsp, 0xF0
0000705c56fd8ddb  vmovaps [rsp], xmm0
0000705c56fd8de0  vmovaps [rsp+0x10], xmm1
0000705c56fd8de6  vmovaps [rsp+0x20], xmm2
0000705c56fd8dec  vmovaps [rsp+0x30], xmm3
0000705c56fd8df2  vmovaps [rsp+0x40], xmm4
0000705c56fd8df8  vmovaps [rsp+0x50], xmm5
0000705c56fd8dfe  vmovaps [rsp+0x60], xmm6
0000705c56fd8e04  vmovaps [rsp+0x70], xmm7
0000705c56fd8e0a  vmovaps [rsp+0x80], xmm8
0000705c56fd8e13  vmovaps [rsp+0x90], xmm10
0000705c56fd8e1c  vmovaps [rsp+0xA0], xmm11
0000705c56fd8e25  vmovaps [rsp+0xB0], xmm12
0000705c56fd8e2e  vmovaps [rsp+0xC0], xmm13
0000705c56fd8e37  vmovaps [rsp+0xD0], xmm14
0000705c56fd8e40  vmovaps [rsp+0xE0], xmm15
0000705c56fd8e49  sub rsp, 0x30
0000705c56fd8e4d  movaps [rsp], xmm9
0000705c56fd8e52  movaps [rsp+0x10], xmm2
0000705c56fd8e57  movaps [rsp+0x20], xmm1
0000705c56fd8e5c  lea rdi, [rsp]
0000705c56fd8e60  mov esi, 0x00
0000705c56fd8e65  mov rax, 0x5877D3629530
0000705c56fd8e6f  call rax
0000705c56fd8e71  movaps xmm9, [rsp]
0000705c56fd8e76  add rsp, 0x30
0000705c56fd8e7a  vmovaps xmm0, [rsp]
0000705c56fd8e7f  vmovaps xmm1, [rsp+0x10]
0000705c56fd8e85  vmovaps xmm2, [rsp+0x20]
0000705c56fd8e8b  vmovaps xmm3, [rsp+0x30]
0000705c56fd8e91  vmovaps xmm4, [rsp+0x40]
0000705c56fd8e97  vmovaps xmm5, [rsp+0x50]
0000705c56fd8e9d  vmovaps xmm6, [rsp+0x60]
0000705c56fd8ea3  vmovaps xmm7, [rsp+0x70]
0000705c56fd8ea9  vmovaps xmm8, [rsp+0x80]
0000705c56fd8eb2  vmovaps xmm10, [rsp+0x90]
0000705c56fd8ebb  vmovaps xmm11, [rsp+0xA0]
0000705c56fd8ec4  vmovaps xmm12, [rsp+0xB0]
0000705c56fd8ecd  vmovaps xmm13, [rsp+0xC0]
0000705c56fd8ed6  vmovaps xmm14, [rsp+0xD0]
0000705c56fd8edf  vmovaps xmm15, [rsp+0xE0]
0000705c56fd8ee8  add rsp, 0xF0
0000705c56fd8eef  pop r11
0000705c56fd8ef1  pop r10
0000705c56fd8ef3  pop r9
0000705c56fd8ef5  pop r8
0000705c56fd8ef7  pop rsi
0000705c56fd8ef8  pop rdi
0000705c56fd8ef9  pop rdx
0000705c56fd8efa  pop rcx
0000705c56fd8efb  pop rax
0000705c56fd8efc  add rsp, 0x08
0000705c56fd8f00  jmp 0x0000705C56FD61A1
0000705c56fd8f05  sub rsp, 0x08
0000705c56fd8f09  push rax
0000705c56fd8f0a  push rcx
0000705c56fd8f0b  push rdx
0000705c56fd8f0c  push rdi
0000705c56fd8f0d  push rsi
0000705c56fd8f0e  push r8
0000705c56fd8f10  push r9
0000705c56fd8f12  push r10
0000705c56fd8f14  push r11
0000705c56fd8f16  sub rsp, 0xF0
0000705c56fd8f1d  vmovaps [rsp], xmm0
0000705c56fd8f22  vmovaps [rsp+0x10], xmm2
0000705c56fd8f28  vmovaps [rsp+0x20], xmm3
0000705c56fd8f2e  vmovaps [rsp+0x30], xmm4
0000705c56fd8f34  vmovaps [rsp+0x40], xmm5
0000705c56fd8f3a  vmovaps [rsp+0x50], xmm6
0000705c56fd8f40  vmovaps [rsp+0x60], xmm7
0000705c56fd8f46  vmovaps [rsp+0x70], xmm8
0000705c56fd8f4c  vmovaps [rsp+0x80], xmm9
0000705c56fd8f55  vmovaps [rsp+0x90], xmm10
0000705c56fd8f5e  vmovaps [rsp+0xA0], xmm11
0000705c56fd8f67  vmovaps [rsp+0xB0], xmm12
0000705c56fd8f70  vmovaps [rsp+0xC0], xmm13
0000705c56fd8f79  vmovaps [rsp+0xD0], xmm14
0000705c56fd8f82  vmovaps [rsp+0xE0], xmm15
0000705c56fd8f8b  sub rsp, 0x30
0000705c56fd8f8f  movaps [rsp], xmm1
0000705c56fd8f93  movaps [rsp+0x10], xmm15
0000705c56fd8f99  movaps [rsp+0x20], xmm6
0000705c56fd8f9e  lea rdi, [rsp]
0000705c56fd8fa2  mov esi, 0x00
0000705c56fd8fa7  mov rax, 0x5877D3629530
0000705c56fd8fb1  call rax
0000705c56fd8fb3  movaps xmm1, [rsp]
0000705c56fd8fb7  add rsp, 0x30
0000705c56fd8fbb  vmovaps xmm0, [rsp]
0000705c56fd8fc0  vmovaps xmm2, [rsp+0x10]
0000705c56fd8fc6  vmovaps xmm3, [rsp+0x20]
0000705c56fd8fcc  vmovaps xmm4, [rsp+0x30]
0000705c56fd8fd2  vmovaps xmm5, [rsp+0x40]
0000705c56fd8fd8  vmovaps xmm6, [rsp+0x50]
0000705c56fd8fde  vmovaps xmm7, [rsp+0x60]
0000705c56fd8fe4  vmovaps xmm8, [rsp+0x70]
0000705c56fd8fea  vmovaps xmm9, [rsp+0x80]
0000705c56fd8ff3  vmovaps xmm10, [rsp+0x90]
0000705c56fd8ffc  vmovaps xmm11, [rsp+0xA0]
0000705c56fd9005  vmovaps xmm12, [rsp+0xB0]
0000705c56fd900e  vmovaps xmm13, [rsp+0xC0]
0000705c56fd9017  vmovaps xmm14, [rsp+0xD0]
0000705c56fd9020  vmovaps xmm15, [rsp+0xE0]
0000705c56fd9029  add rsp, 0xF0
0000705c56fd9030  pop r11
0000705c56fd9032  pop r10
0000705c56fd9034  pop r9
0000705c56fd9036  pop r8
0000705c56fd9038  pop rsi
0000705c56fd9039  pop rdi
0000705c56fd903a  pop rdx
0000705c56fd903b  pop rcx
0000705c56fd903c  pop rax
0000705c56fd903d  add rsp, 0x08
0000705c56fd9041  jmp 0x0000705C56FD61C2
0000705c56fd9046  sub rsp, 0x08
0000705c56fd904a  push rax
0000705c56fd904b  push rcx
0000705c56fd904c  push rdx
0000705c56fd904d  push rdi
0000705c56fd904e  push rsi
0000705c56fd904f  push r8
0000705c56fd9051  push r9
0000705c56fd9053  push r10
0000705c56fd9055  push r11
0000705c56fd9057  sub rsp, 0xF0
0000705c56fd905e  vmovaps [rsp], xmm0
0000705c56fd9063  vmovaps [rsp+0x10], xmm1
0000705c56fd9069  vmovaps [rsp+0x20], xmm2
0000705c56fd906f  vmovaps [rsp+0x30], xmm3
0000705c56fd9075  vmovaps [rsp+0x40], xmm4
0000705c56fd907b  vmovaps [rsp+0x50], xmm5
0000705c56fd9081  vmovaps [rsp+0x60], xmm6
0000705c56fd9087  vmovaps [rsp+0x70], xmm7
0000705c56fd908d  vmovaps [rsp+0x80], xmm8
0000705c56fd9096  vmovaps [rsp+0x90], xmm9
0000705c56fd909f  vmovaps [rsp+0xA0], xmm10
0000705c56fd90a8  vmovaps [rsp+0xB0], xmm11
0000705c56fd90b1  vmovaps [rsp+0xC0], xmm12
0000705c56fd90ba  vmovaps [rsp+0xD0], xmm13
0000705c56fd90c3  vmovaps [rsp+0xE0], xmm14
0000705c56fd90cc  sub rsp, 0x30
0000705c56fd90d0  movaps [rsp], xmm15
0000705c56fd90d5  movaps [rsp+0x10], xmm5
0000705c56fd90da  movaps [rsp+0x20], xmm3
0000705c56fd90df  lea rdi, [rsp]
0000705c56fd90e3  mov esi, 0x00
0000705c56fd90e8  mov rax, 0x5877D3629530
0000705c56fd90f2  call rax
0000705c56fd90f4  movaps xmm15, [rsp]
0000705c56fd90f9  add rsp, 0x30
0000705c56fd90fd  vmovaps xmm0, [rsp]
0000705c56fd9102  vmovaps xmm1, [rsp+0x10]
0000705c56fd9108  vmovaps xmm2, [rsp+0x20]
0000705c56fd910e  vmovaps xmm3, [rsp+0x30]
0000705c56fd9114  vmovaps xmm4, [rsp+0x40]
0000705c56fd911a  vmovaps xmm5, [rsp+0x50]
0000705c56fd9120  vmovaps xmm6, [rsp+0x60]
0000705c56fd9126  vmovaps xmm7, [rsp+0x70]
0000705c56fd912c  vmovaps xmm8, [rsp+0x80]
0000705c56fd9135  vmovaps xmm9, [rsp+0x90]
0000705c56fd913e  vmovaps xmm10, [rsp+0xA0]
0000705c56fd9147  vmovaps xmm11, [rsp+0xB0]
0000705c56fd9150  vmovaps xmm12, [rsp+0xC0]
0000705c56fd9159  vmovaps xmm13, [rsp+0xD0]
0000705c56fd9162  vmovaps xmm14, [rsp+0xE0]
0000705c56fd916b  add rsp, 0xF0
0000705c56fd9172  pop r11
0000705c56fd9174  pop r10
0000705c56fd9176  pop r9
0000705c56fd9178  pop r8
0000705c56fd917a  pop rsi
0000705c56fd917b  pop rdi
0000705c56fd917c  pop rdx
0000705c56fd917d  pop rcx
0000705c56fd917e  pop rax
0000705c56fd917f  add rsp, 0x08
0000705c56fd9183  jmp 0x0000705C56FD61DC
0000705c56fd9188  sub rsp, 0x08
0000705c56fd918c  push rax
0000705c56fd918d  push rcx
0000705c56fd918e  push rdx
0000705c56fd918f  push rdi
0000705c56fd9190  push rsi
0000705c56fd9191  push r8
0000705c56fd9193  push r9
0000705c56fd9195  push r10
0000705c56fd9197  push r11
0000705c56fd9199  sub rsp, 0xF0
0000705c56fd91a0  vmovaps [rsp], xmm0
0000705c56fd91a5  vmovaps [rsp+0x10], xmm1
0000705c56fd91ab  vmovaps [rsp+0x20], xmm2
0000705c56fd91b1  vmovaps [rsp+0x30], xmm3
0000705c56fd91b7  vmovaps [rsp+0x40], xmm4
0000705c56fd91bd  vmovaps [rsp+0x50], xmm6
0000705c56fd91c3  vmovaps [rsp+0x60], xmm7
0000705c56fd91c9  vmovaps [rsp+0x70], xmm8
0000705c56fd91cf  vmovaps [rsp+0x80], xmm9
0000705c56fd91d8  vmovaps [rsp+0x90], xmm10
0000705c56fd91e1  vmovaps [rsp+0xA0], xmm11
0000705c56fd91ea  vmovaps [rsp+0xB0], xmm12
0000705c56fd91f3  vmovaps [rsp+0xC0], xmm13
0000705c56fd91fc  vmovaps [rsp+0xD0], xmm14
0000705c56fd9205  vmovaps [rsp+0xE0], xmm15
0000705c56fd920e  sub rsp, 0x30
0000705c56fd9212  movaps [rsp], xmm5
0000705c56fd9216  movaps [rsp+0x10], xmm8
0000705c56fd921c  movaps [rsp+0x20], xmm6
0000705c56fd9221  lea rdi, [rsp]
0000705c56fd9225  mov esi, 0x00
0000705c56fd922a  mov rax, 0x5877D3629530
0000705c56fd9234  call rax
0000705c56fd9236  movaps xmm5, [rsp]
0000705c56fd923a  add rsp, 0x30
0000705c56fd923e  vmovaps xmm0, [rsp]
0000705c56fd9243  vmovaps xmm1, [rsp+0x10]
0000705c56fd9249  vmovaps xmm2, [rsp+0x20]
0000705c56fd924f  vmovaps xmm3, [rsp+0x30]
0000705c56fd9255  vmovaps xmm4, [rsp+0x40]
0000705c56fd925b  vmovaps xmm6, [rsp+0x50]
0000705c56fd9261  vmovaps xmm7, [rsp+0x60]
0000705c56fd9267  vmovaps xmm8, [rsp+0x70]
0000705c56fd926d  vmovaps xmm9, [rsp+0x80]
0000705c56fd9276  vmovaps xmm10, [rsp+0x90]
0000705c56fd927f  vmovaps xmm11, [rsp+0xA0]
0000705c56fd9288  vmovaps xmm12, [rsp+0xB0]
0000705c56fd9291  vmovaps xmm13, [rsp+0xC0]
0000705c56fd929a  vmovaps xmm14, [rsp+0xD0]
0000705c56fd92a3  vmovaps xmm15, [rsp+0xE0]
0000705c56fd92ac  add rsp, 0xF0
0000705c56fd92b3  pop r11
0000705c56fd92b5  pop r10
0000705c56fd92b7  pop r9
0000705c56fd92b9  pop r8
0000705c56fd92bb  pop rsi
0000705c56fd92bc  pop rdi
0000705c56fd92bd  pop rdx
0000705c56fd92be  pop rcx
0000705c56fd92bf  pop rax
0000705c56fd92c0  add rsp, 0x08
0000705c56fd92c4  jmp 0x0000705C56FD6200
0000705c56fd92c9  sub rsp, 0x08
0000705c56fd92cd  push rax
0000705c56fd92ce  push rcx
0000705c56fd92cf  push rdx
0000705c56fd92d0  push rdi
0000705c56fd92d1  push rsi
0000705c56fd92d2  push r8
0000705c56fd92d4  push r9
0000705c56fd92d6  push r10
0000705c56fd92d8  push r11
0000705c56fd92da  sub rsp, 0xF0
0000705c56fd92e1  vmovaps [rsp], xmm0
0000705c56fd92e6  vmovaps [rsp+0x10], xmm1
0000705c56fd92ec  vmovaps [rsp+0x20], xmm2
0000705c56fd92f2  vmovaps [rsp+0x30], xmm3
0000705c56fd92f8  vmovaps [rsp+0x40], xmm4
0000705c56fd92fe  vmovaps [rsp+0x50], xmm5
0000705c56fd9304  vmovaps [rsp+0x60], xmm7
0000705c56fd930a  vmovaps [rsp+0x70], xmm8
0000705c56fd9310  vmovaps [rsp+0x80], xmm9
0000705c56fd9319  vmovaps [rsp+0x90], xmm10
0000705c56fd9322  vmovaps [rsp+0xA0], xmm11
0000705c56fd932b  vmovaps [rsp+0xB0], xmm12
0000705c56fd9334  vmovaps [rsp+0xC0], xmm13
0000705c56fd933d  vmovaps [rsp+0xD0], xmm14
0000705c56fd9346  vmovaps [rsp+0xE0], xmm15
0000705c56fd934f  sub rsp, 0x30
0000705c56fd9353  movaps [rsp], xmm6
0000705c56fd9357  movaps [rsp+0x10], xmm10
0000705c56fd935d  movaps [rsp+0x20], xmm8
0000705c56fd9363  lea rdi, [rsp]
0000705c56fd9367  mov esi, 0x00
0000705c56fd936c  mov rax, 0x5877D3629530
0000705c56fd9376  call rax
0000705c56fd9378  movaps xmm6, [rsp]
0000705c56fd937c  add rsp, 0x30
0000705c56fd9380  vmovaps xmm0, [rsp]
0000705c56fd9385  vmovaps xmm1, [rsp+0x10]
0000705c56fd938b  vmovaps xmm2, [rsp+0x20]
0000705c56fd9391  vmovaps xmm3, [rsp+0x30]
0000705c56fd9397  vmovaps xmm4, [rsp+0x40]
0000705c56fd939d  vmovaps xmm5, [rsp+0x50]
0000705c56fd93a3  vmovaps xmm7, [rsp+0x60]
0000705c56fd93a9  vmovaps xmm8, [rsp+0x70]
0000705c56fd93af  vmovaps xmm9, [rsp+0x80]
0000705c56fd93b8  vmovaps xmm10, [rsp+0x90]
0000705c56fd93c1  vmovaps xmm11, [rsp+0xA0]
0000705c56fd93ca  vmovaps xmm12, [rsp+0xB0]
0000705c56fd93d3  vmovaps xmm13, [rsp+0xC0]
0000705c56fd93dc  vmovaps xmm14, [rsp+0xD0]
0000705c56fd93e5  vmovaps xmm15, [rsp+0xE0]
0000705c56fd93ee  add rsp, 0xF0
0000705c56fd93f5  pop r11
0000705c56fd93f7  pop r10
0000705c56fd93f9  pop r9
0000705c56fd93fb  pop r8
0000705c56fd93fd  pop rsi
0000705c56fd93fe  pop rdi
0000705c56fd93ff  pop rdx
0000705c56fd9400  pop rcx
0000705c56fd9401  pop rax
0000705c56fd9402  add rsp, 0x08
0000705c56fd9406  jmp 0x0000705C56FD6225
0000705c56fd940b  sub rsp, 0x08
0000705c56fd940f  push rax
0000705c56fd9410  push rcx
0000705c56fd9411  push rdx
0000705c56fd9412  push rdi
0000705c56fd9413  push rsi
0000705c56fd9414  push r8
0000705c56fd9416  push r9
0000705c56fd9418  push r10
0000705c56fd941a  push r11
0000705c56fd941c  sub rsp, 0xF0
0000705c56fd9423  vmovaps [rsp], xmm0
0000705c56fd9428  vmovaps [rsp+0x10], xmm1
0000705c56fd942e  vmovaps [rsp+0x20], xmm2
0000705c56fd9434  vmovaps [rsp+0x30], xmm3
0000705c56fd943a  vmovaps [rsp+0x40], xmm4
0000705c56fd9440  vmovaps [rsp+0x50], xmm5
0000705c56fd9446  vmovaps [rsp+0x60], xmm6
0000705c56fd944c  vmovaps [rsp+0x70], xmm7
0000705c56fd9452  vmovaps [rsp+0x80], xmm8
0000705c56fd945b  vmovaps [rsp+0x90], xmm9
0000705c56fd9464  vmovaps [rsp+0xA0], xmm11
0000705c56fd946d  vmovaps [rsp+0xB0], xmm12
0000705c56fd9476  vmovaps [rsp+0xC0], xmm13
0000705c56fd947f  vmovaps [rsp+0xD0], xmm14
0000705c56fd9488  vmovaps [rsp+0xE0], xmm15
0000705c56fd9491  sub rsp, 0x30
0000705c56fd9495  movaps [rsp], xmm10
0000705c56fd949a  movaps [rsp+0x10], xmm8
0000705c56fd94a0  movaps [rsp+0x20], xmm14
0000705c56fd94a6  lea rdi, [rsp]
0000705c56fd94aa  mov esi, 0x00
0000705c56fd94af  mov rax, 0x5877D3629530
0000705c56fd94b9  call rax
0000705c56fd94bb  movaps xmm10, [rsp]
0000705c56fd94c0  add rsp, 0x30
0000705c56fd94c4  vmovaps xmm0, [rsp]
0000705c56fd94c9  vmovaps xmm1, [rsp+0x10]
0000705c56fd94cf  vmovaps xmm2, [rsp+0x20]
0000705c56fd94d5  vmovaps xmm3, [rsp+0x30]
0000705c56fd94db  vmovaps xmm4, [rsp+0x40]
0000705c56fd94e1  vmovaps xmm5, [rsp+0x50]
0000705c56fd94e7  vmovaps xmm6, [rsp+0x60]
0000705c56fd94ed  vmovaps xmm7, [rsp+0x70]
0000705c56fd94f3  vmovaps xmm8, [rsp+0x80]
0000705c56fd94fc  vmovaps xmm9, [rsp+0x90]
0000705c56fd9505  vmovaps xmm11, [rsp+0xA0]
0000705c56fd950e  vmovaps xmm12, [rsp+0xB0]
0000705c56fd9517  vmovaps xmm13, [rsp+0xC0]
0000705c56fd9520  vmovaps xmm14, [rsp+0xD0]
0000705c56fd9529  vmovaps xmm15, [rsp+0xE0]
0000705c56fd9532  add rsp, 0xF0
0000705c56fd9539  pop r11
0000705c56fd953b  pop r10
0000705c56fd953d  pop r9
0000705c56fd953f  pop r8
0000705c56fd9541  pop rsi
0000705c56fd9542  pop rdi
0000705c56fd9543  pop rdx
0000705c56fd9544  pop rcx
0000705c56fd9545  pop rax
0000705c56fd9546  add rsp, 0x08
0000705c56fd954a  jmp 0x0000705C56FD6245
0000705c56fd954f  sub rsp, 0x08
0000705c56fd9553  push rax
0000705c56fd9554  push rcx
0000705c56fd9555  push rdx
0000705c56fd9556  push rdi
0000705c56fd9557  push rsi
0000705c56fd9558  push r8
0000705c56fd955a  push r9
0000705c56fd955c  push r10
0000705c56fd955e  push r11
0000705c56fd9560  sub rsp, 0xF0
0000705c56fd9567  vmovaps [rsp], xmm0
0000705c56fd956c  vmovaps [rsp+0x10], xmm1
0000705c56fd9572  vmovaps [rsp+0x20], xmm2
0000705c56fd9578  vmovaps [rsp+0x30], xmm3
0000705c56fd957e  vmovaps [rsp+0x40], xmm4
0000705c56fd9584  vmovaps [rsp+0x50], xmm5
0000705c56fd958a  vmovaps [rsp+0x60], xmm6
0000705c56fd9590  vmovaps [rsp+0x70], xmm7
0000705c56fd9596  vmovaps [rsp+0x80], xmm8
0000705c56fd959f  vmovaps [rsp+0x90], xmm9
0000705c56fd95a8  vmovaps [rsp+0xA0], xmm10
0000705c56fd95b1  vmovaps [rsp+0xB0], xmm11
0000705c56fd95ba  vmovaps [rsp+0xC0], xmm12
0000705c56fd95c3  vmovaps [rsp+0xD0], xmm13
0000705c56fd95cc  vmovaps [rsp+0xE0], xmm15
0000705c56fd95d5  sub rsp, 0x30
0000705c56fd95d9  movaps [rsp], xmm14
0000705c56fd95de  movaps [rsp+0x10], xmm8
0000705c56fd95e4  movaps [rsp+0x20], xmm4
0000705c56fd95e9  lea rdi, [rsp]
0000705c56fd95ed  mov esi, 0x00
0000705c56fd95f2  mov rax, 0x5877D3629530
0000705c56fd95fc  call rax
0000705c56fd95fe  movaps xmm14, [rsp]
0000705c56fd9603  add rsp, 0x30
0000705c56fd9607  vmovaps xmm0, [rsp]
0000705c56fd960c  vmovaps xmm1, [rsp+0x10]
0000705c56fd9612  vmovaps xmm2, [rsp+0x20]
0000705c56fd9618  vmovaps xmm3, [rsp+0x30]
0000705c56fd961e  vmovaps xmm4, [rsp+0x40]
0000705c56fd9624  vmovaps xmm5, [rsp+0x50]
0000705c56fd962a  vmovaps xmm6, [rsp+0x60]
0000705c56fd9630  vmovaps xmm7, [rsp+0x70]
0000705c56fd9636  vmovaps xmm8, [rsp+0x80]
0000705c56fd963f  vmovaps xmm9, [rsp+0x90]
0000705c56fd9648  vmovaps xmm10, [rsp+0xA0]
0000705c56fd9651  vmovaps xmm11, [rsp+0xB0]
0000705c56fd965a  vmovaps xmm12, [rsp+0xC0]
0000705c56fd9663  vmovaps xmm13, [rsp+0xD0]
0000705c56fd966c  vmovaps xmm15, [rsp+0xE0]
0000705c56fd9675  add rsp, 0xF0
0000705c56fd967c  pop r11
0000705c56fd967e  pop r10
0000705c56fd9680  pop r9
0000705c56fd9682  pop r8
0000705c56fd9684  pop rsi
0000705c56fd9685  pop rdi
0000705c56fd9686  pop rdx
0000705c56fd9687  pop rcx
0000705c56fd9688  pop rax
0000705c56fd9689  add rsp, 0x08
0000705c56fd968d  jmp 0x0000705C56FD6265
0000705c56fd9692  sub rsp, 0x08
0000705c56fd9696  push rax
0000705c56fd9697  push rcx
0000705c56fd9698  push rdx
0000705c56fd9699  push rdi
0000705c56fd969a  push rsi
0000705c56fd969b  push r8
0000705c56fd969d  push r9
0000705c56fd969f  push r10
0000705c56fd96a1  push r11
0000705c56fd96a3  sub rsp, 0xF0
0000705c56fd96aa  vmovaps [rsp], xmm0
0000705c56fd96af  vmovaps [rsp+0x10], xmm1
0000705c56fd96b5  vmovaps [rsp+0x20], xmm2
0000705c56fd96bb  vmovaps [rsp+0x30], xmm3
0000705c56fd96c1  vmovaps [rsp+0x40], xmm5
0000705c56fd96c7  vmovaps [rsp+0x50], xmm6
0000705c56fd96cd  vmovaps [rsp+0x60], xmm7
0000705c56fd96d3  vmovaps [rsp+0x70], xmm8
0000705c56fd96d9  vmovaps [rsp+0x80], xmm9
0000705c56fd96e2  vmovaps [rsp+0x90], xmm10
0000705c56fd96eb  vmovaps [rsp+0xA0], xmm11
0000705c56fd96f4  vmovaps [rsp+0xB0], xmm12
0000705c56fd96fd  vmovaps [rsp+0xC0], xmm13
0000705c56fd9706  vmovaps [rsp+0xD0], xmm14
0000705c56fd970f  vmovaps [rsp+0xE0], xmm15
0000705c56fd9718  sub rsp, 0x30
0000705c56fd971c  movaps [rsp], xmm4
0000705c56fd9720  movaps [rsp+0x10], xmm13
0000705c56fd9726  movaps [rsp+0x20], xmm8
0000705c56fd972c  lea rdi, [rsp]
0000705c56fd9730  mov esi, 0x00
0000705c56fd9735  mov rax, 0x5877D3629530
0000705c56fd973f  call rax
0000705c56fd9741  movaps xmm4, [rsp]
0000705c56fd9745  add rsp, 0x30
0000705c56fd9749  vmovaps xmm0, [rsp]
0000705c56fd974e  vmovaps xmm1, [rsp+0x10]
0000705c56fd9754  vmovaps xmm2, [rsp+0x20]
0000705c56fd975a  vmovaps xmm3, [rsp+0x30]
0000705c56fd9760  vmovaps xmm5, [rsp+0x40]
0000705c56fd9766  vmovaps xmm6, [rsp+0x50]
0000705c56fd976c  vmovaps xmm7, [rsp+0x60]
0000705c56fd9772  vmovaps xmm8, [rsp+0x70]
0000705c56fd9778  vmovaps xmm9, [rsp+0x80]
0000705c56fd9781  vmovaps xmm10, [rsp+0x90]
0000705c56fd978a  vmovaps xmm11, [rsp+0xA0]
0000705c56fd9793  vmovaps xmm12, [rsp+0xB0]
0000705c56fd979c  vmovaps xmm13, [rsp+0xC0]
0000705c56fd97a5  vmovaps xmm14, [rsp+0xD0]
0000705c56fd97ae  vmovaps xmm15, [rsp+0xE0]
0000705c56fd97b7  add rsp, 0xF0
0000705c56fd97be  pop r11
0000705c56fd97c0  pop r10
0000705c56fd97c2  pop r9
0000705c56fd97c4  pop r8
0000705c56fd97c6  pop rsi
0000705c56fd97c7  pop rdi
0000705c56fd97c8  pop rdx
0000705c56fd97c9  pop rcx
0000705c56fd97ca  pop rax
0000705c56fd97cb  add rsp, 0x08
0000705c56fd97cf  jmp 0x0000705C56FD628A
0000705c56fd97d4  sub rsp, 0x08
0000705c56fd97d8  push rax
0000705c56fd97d9  push rcx
0000705c56fd97da  push rdx
0000705c56fd97db  push rdi
0000705c56fd97dc  push rsi
0000705c56fd97dd  push r8
0000705c56fd97df  push r9
0000705c56fd97e1  push r10
0000705c56fd97e3  push r11
0000705c56fd97e5  sub rsp, 0xF0
0000705c56fd97ec  vmovaps [rsp], xmm0
0000705c56fd97f1  vmovaps [rsp+0x10], xmm1
0000705c56fd97f7  vmovaps [rsp+0x20], xmm2
0000705c56fd97fd  vmovaps [rsp+0x30], xmm3
0000705c56fd9803  vmovaps [rsp+0x40], xmm4
0000705c56fd9809  vmovaps [rsp+0x50], xmm5
0000705c56fd980f  vmovaps [rsp+0x60], xmm6
0000705c56fd9815  vmovaps [rsp+0x70], xmm7
0000705c56fd981b  vmovaps [rsp+0x80], xmm8
0000705c56fd9824  vmovaps [rsp+0x90], xmm9
0000705c56fd982d  vmovaps [rsp+0xA0], xmm10
0000705c56fd9836  vmovaps [rsp+0xB0], xmm11
0000705c56fd983f  vmovaps [rsp+0xC0], xmm12
0000705c56fd9848  vmovaps [rsp+0xD0], xmm14
0000705c56fd9851  vmovaps [rsp+0xE0], xmm15
0000705c56fd985a  sub rsp, 0x30
0000705c56fd985e  movaps [rsp], xmm13
0000705c56fd9863  movaps [rsp+0x10], xmm15
0000705c56fd9869  movaps [rsp+0x20], xmm9
0000705c56fd986f  lea rdi, [rsp]
0000705c56fd9873  mov esi, 0x00
0000705c56fd9878  mov rax, 0x5877D3629530
0000705c56fd9882  call rax
0000705c56fd9884  movaps xmm13, [rsp]
0000705c56fd9889  add rsp, 0x30
0000705c56fd988d  vmovaps xmm0, [rsp]
0000705c56fd9892  vmovaps xmm1, [rsp+0x10]
0000705c56fd9898  vmovaps xmm2, [rsp+0x20]
0000705c56fd989e  vmovaps xmm3, [rsp+0x30]
0000705c56fd98a4  vmovaps xmm4, [rsp+0x40]
0000705c56fd98aa  vmovaps xmm5, [rsp+0x50]
0000705c56fd98b0  vmovaps xmm6, [rsp+0x60]
0000705c56fd98b6  vmovaps xmm7, [rsp+0x70]
0000705c56fd98bc  vmovaps xmm8, [rsp+0x80]
0000705c56fd98c5  vmovaps xmm9, [rsp+0x90]
0000705c56fd98ce  vmovaps xmm10, [rsp+0xA0]
0000705c56fd98d7  vmovaps xmm11, [rsp+0xB0]
0000705c56fd98e0  vmovaps xmm12, [rsp+0xC0]
0000705c56fd98e9  vmovaps xmm14, [rsp+0xD0]
0000705c56fd98f2  vmovaps xmm15, [rsp+0xE0]
0000705c56fd98fb  add rsp, 0xF0
0000705c56fd9902  pop r11
0000705c56fd9904  pop r10
0000705c56fd9906  pop r9
0000705c56fd9908  pop r8
0000705c56fd990a  pop rsi
0000705c56fd990b  pop rdi
0000705c56fd990c  pop rdx
0000705c56fd990d  pop rcx
0000705c56fd990e  pop rax
0000705c56fd990f  add rsp, 0x08
0000705c56fd9913  jmp 0x0000705C56FD62A5
0000705c56fd9918  sub rsp, 0x08
0000705c56fd991c  push rax
0000705c56fd991d  push rcx
0000705c56fd991e  push rdx
0000705c56fd991f  push rdi
0000705c56fd9920  push rsi
0000705c56fd9921  push r8
0000705c56fd9923  push r9
0000705c56fd9925  push r10
0000705c56fd9927  push r11
0000705c56fd9929  sub rsp, 0xF0
0000705c56fd9930  vmovaps [rsp], xmm0
0000705c56fd9935  vmovaps [rsp+0x10], xmm1
0000705c56fd993b  vmovaps [rsp+0x20], xmm2
0000705c56fd9941  vmovaps [rsp+0x30], xmm3
0000705c56fd9947  vmovaps [rsp+0x40], xmm4
0000705c56fd994d  vmovaps [rsp+0x50], xmm5
0000705c56fd9953  vmovaps [rsp+0x60], xmm6
0000705c56fd9959  vmovaps [rsp+0x70], xmm7
0000705c56fd995f  vmovaps [rsp+0x80], xmm8
0000705c56fd9968  vmovaps [rsp+0x90], xmm9
0000705c56fd9971  vmovaps [rsp+0xA0], xmm10
0000705c56fd997a  vmovaps [rsp+0xB0], xmm11
0000705c56fd9983  vmovaps [rsp+0xC0], xmm12
0000705c56fd998c  vmovaps [rsp+0xD0], xmm13
0000705c56fd9995  vmovaps [rsp+0xE0], xmm14
0000705c56fd999e  sub rsp, 0x30
0000705c56fd99a2  movaps [rsp], xmm15
0000705c56fd99a7  movaps [rsp+0x10], xmm1
0000705c56fd99ac  movaps [rsp+0x20], xmm5
0000705c56fd99b1  lea rdi, [rsp]
0000705c56fd99b5  mov esi, 0x00
0000705c56fd99ba  mov rax, 0x5877D3629530
0000705c56fd99c4  call rax
0000705c56fd99c6  movaps xmm15, [rsp]
0000705c56fd99cb  add rsp, 0x30
0000705c56fd99cf  vmovaps xmm0, [rsp]
0000705c56fd99d4  vmovaps xmm1, [rsp+0x10]
0000705c56fd99da  vmovaps xmm2, [rsp+0x20]
0000705c56fd99e0  vmovaps xmm3, [rsp+0x30]
0000705c56fd99e6  vmovaps xmm4, [rsp+0x40]
0000705c56fd99ec  vmovaps xmm5, [rsp+0x50]
0000705c56fd99f2  vmovaps xmm6, [rsp+0x60]
0000705c56fd99f8  vmovaps xmm7, [rsp+0x70]
0000705c56fd99fe  vmovaps xmm8, [rsp+0x80]
0000705c56fd9a07  vmovaps xmm9, [rsp+0x90]
0000705c56fd9a10  vmovaps xmm10, [rsp+0xA0]
0000705c56fd9a19  vmovaps xmm11, [rsp+0xB0]
0000705c56fd9a22  vmovaps xmm12, [rsp+0xC0]
0000705c56fd9a2b  vmovaps xmm13, [rsp+0xD0]
0000705c56fd9a34  vmovaps xmm14, [rsp+0xE0]
0000705c56fd9a3d  add rsp, 0xF0
0000705c56fd9a44  pop r11
0000705c56fd9a46  pop r10
0000705c56fd9a48  pop r9
0000705c56fd9a4a  pop r8
0000705c56fd9a4c  pop rsi
0000705c56fd9a4d  pop rdi
0000705c56fd9a4e  pop rdx
0000705c56fd9a4f  pop rcx
0000705c56fd9a50  pop rax
0000705c56fd9a51  add rsp, 0x08
0000705c56fd9a55  jmp 0x0000705C56FD62C0
0000705c56fd9a5a  call 0x0000705C56ED64F0
0000705c56fd9a5f  jmp 0x0000705C56FD631B
0000705c56fd9a64  sub rsp, 0x08
0000705c56fd9a68  push rax
0000705c56fd9a69  push rcx
0000705c56fd9a6a  push rdx
0000705c56fd9a6b  push rdi
0000705c56fd9a6c  push rsi
0000705c56fd9a6d  push r8
0000705c56fd9a6f  push r9
0000705c56fd9a71  push r10
0000705c56fd9a73  push r11
0000705c56fd9a75  sub rsp, 0xF0
0000705c56fd9a7c  vmovaps [rsp], xmm0
0000705c56fd9a81  vmovaps [rsp+0x10], xmm1
0000705c56fd9a87  vmovaps [rsp+0x20], xmm2
0000705c56fd9a8d  vmovaps [rsp+0x30], xmm3
0000705c56fd9a93  vmovaps [rsp+0x40], xmm4
0000705c56fd9a99  vmovaps [rsp+0x50], xmm5
0000705c56fd9a9f  vmovaps [rsp+0x60], xmm6
0000705c56fd9aa5  vmovaps [rsp+0x70], xmm7
0000705c56fd9aab  vmovaps [rsp+0x80], xmm8
0000705c56fd9ab4  vmovaps [rsp+0x90], xmm10
0000705c56fd9abd  vmovaps [rsp+0xA0], xmm11
0000705c56fd9ac6  vmovaps [rsp+0xB0], xmm12
0000705c56fd9acf  vmovaps [rsp+0xC0], xmm13
0000705c56fd9ad8  vmovaps [rsp+0xD0], xmm14
0000705c56fd9ae1  vmovaps [rsp+0xE0], xmm15
0000705c56fd9aea  sub rsp, 0x30
0000705c56fd9aee  movaps [rsp], xmm9
0000705c56fd9af3  movaps [rsp+0x10], xmm8
0000705c56fd9af9  movaps [rsp+0x20], xmm11
0000705c56fd9aff  lea rdi, [rsp]
0000705c56fd9b03  mov esi, 0x00
0000705c56fd9b08  mov rax, 0x5877D3629530
0000705c56fd9b12  call rax
0000705c56fd9b14  movaps xmm9, [rsp]
0000705c56fd9b19  add rsp, 0x30
0000705c56fd9b1d  vmovaps xmm0, [rsp]
0000705c56fd9b22  vmovaps xmm1, [rsp+0x10]
0000705c56fd9b28  vmovaps xmm2, [rsp+0x20]
0000705c56fd9b2e  vmovaps xmm3, [rsp+0x30]
0000705c56fd9b34  vmovaps xmm4, [rsp+0x40]
0000705c56fd9b3a  vmovaps xmm5, [rsp+0x50]
0000705c56fd9b40  vmovaps xmm6, [rsp+0x60]
0000705c56fd9b46  vmovaps xmm7, [rsp+0x70]
0000705c56fd9b4c  vmovaps xmm8, [rsp+0x80]
0000705c56fd9b55  vmovaps xmm10, [rsp+0x90]
0000705c56fd9b5e  vmovaps xmm11, [rsp+0xA0]
0000705c56fd9b67  vmovaps xmm12, [rsp+0xB0]
0000705c56fd9b70  vmovaps xmm13, [rsp+0xC0]
0000705c56fd9b79  vmovaps xmm14, [rsp+0xD0]
0000705c56fd9b82  vmovaps xmm15, [rsp+0xE0]
0000705c56fd9b8b  add rsp, 0xF0
0000705c56fd9b92  pop r11
0000705c56fd9b94  pop r10
0000705c56fd9b96  pop r9
0000705c56fd9b98  pop r8
0000705c56fd9b9a  pop rsi
0000705c56fd9b9b  pop rdi
0000705c56fd9b9c  pop rdx
0000705c56fd9b9d  pop rcx
0000705c56fd9b9e  pop rax
0000705c56fd9b9f  add rsp, 0x08
0000705c56fd9ba3  jmp 0x0000705C56FD6352
0000705c56fd9ba8  sub rsp, 0x08
0000705c56fd9bac  push rax
0000705c56fd9bad  push rcx
0000705c56fd9bae  push rdx
0000705c56fd9baf  push rdi
0000705c56fd9bb0  push rsi
0000705c56fd9bb1  push r8
0000705c56fd9bb3  push r9
0000705c56fd9bb5  push r10
0000705c56fd9bb7  push r11
0000705c56fd9bb9  sub rsp, 0xF0
0000705c56fd9bc0  vmovaps [rsp], xmm0
0000705c56fd9bc5  vmovaps [rsp+0x10], xmm1
0000705c56fd9bcb  vmovaps [rsp+0x20], xmm2
0000705c56fd9bd1  vmovaps [rsp+0x30], xmm3
0000705c56fd9bd7  vmovaps [rsp+0x40], xmm4
0000705c56fd9bdd  vmovaps [rsp+0x50], xmm5
0000705c56fd9be3  vmovaps [rsp+0x60], xmm6
0000705c56fd9be9  vmovaps [rsp+0x70], xmm7
0000705c56fd9bef  vmovaps [rsp+0x80], xmm8
0000705c56fd9bf8  vmovaps [rsp+0x90], xmm9
0000705c56fd9c01  vmovaps [rsp+0xA0], xmm10
0000705c56fd9c0a  vmovaps [rsp+0xB0], xmm12
0000705c56fd9c13  vmovaps [rsp+0xC0], xmm13
0000705c56fd9c1c  vmovaps [rsp+0xD0], xmm14
0000705c56fd9c25  vmovaps [rsp+0xE0], xmm15
0000705c56fd9c2e  sub rsp, 0x30
0000705c56fd9c32  movaps [rsp], xmm11
0000705c56fd9c37  movaps [rsp+0x10], xmm10
0000705c56fd9c3d  movaps [rsp+0x20], xmm6
0000705c56fd9c42  lea rdi, [rsp]
0000705c56fd9c46  mov esi, 0x00
0000705c56fd9c4b  mov rax, 0x5877D3629530
0000705c56fd9c55  call rax
0000705c56fd9c57  movaps xmm11, [rsp]
0000705c56fd9c5c  add rsp, 0x30
0000705c56fd9c60  vmovaps xmm0, [rsp]
0000705c56fd9c65  vmovaps xmm1, [rsp+0x10]
0000705c56fd9c6b  vmovaps xmm2, [rsp+0x20]
0000705c56fd9c71  vmovaps xmm3, [rsp+0x30]
0000705c56fd9c77  vmovaps xmm4, [rsp+0x40]
0000705c56fd9c7d  vmovaps xmm5, [rsp+0x50]
0000705c56fd9c83  vmovaps xmm6, [rsp+0x60]
0000705c56fd9c89  vmovaps xmm7, [rsp+0x70]
0000705c56fd9c8f  vmovaps xmm8, [rsp+0x80]
0000705c56fd9c98  vmovaps xmm9, [rsp+0x90]
0000705c56fd9ca1  vmovaps xmm10, [rsp+0xA0]
0000705c56fd9caa  vmovaps xmm12, [rsp+0xB0]
0000705c56fd9cb3  vmovaps xmm13, [rsp+0xC0]
0000705c56fd9cbc  vmovaps xmm14, [rsp+0xD0]
0000705c56fd9cc5  vmovaps xmm15, [rsp+0xE0]
0000705c56fd9cce  add rsp, 0xF0
0000705c56fd9cd5  pop r11
0000705c56fd9cd7  pop r10
0000705c56fd9cd9  pop r9
0000705c56fd9cdb  pop r8
0000705c56fd9cdd  pop rsi
0000705c56fd9cde  pop rdi
0000705c56fd9cdf  pop rdx
0000705c56fd9ce0  pop rcx
0000705c56fd9ce1  pop rax
0000705c56fd9ce2  add rsp, 0x08
0000705c56fd9ce6  jmp 0x0000705C56FD636D
0000705c56fd9ceb  sub rsp, 0x08
0000705c56fd9cef  push rax
0000705c56fd9cf0  push rcx
0000705c56fd9cf1  push rdx
0000705c56fd9cf2  push rdi
0000705c56fd9cf3  push rsi
0000705c56fd9cf4  push r8
0000705c56fd9cf6  push r9
0000705c56fd9cf8  push r10
0000705c56fd9cfa  push r11
0000705c56fd9cfc  sub rsp, 0xF0
0000705c56fd9d03  vmovaps [rsp], xmm0
0000705c56fd9d08  vmovaps [rsp+0x10], xmm1
0000705c56fd9d0e  vmovaps [rsp+0x20], xmm2
0000705c56fd9d14  vmovaps [rsp+0x30], xmm3
0000705c56fd9d1a  vmovaps [rsp+0x40], xmm4
0000705c56fd9d20  vmovaps [rsp+0x50], xmm5
0000705c56fd9d26  vmovaps [rsp+0x60], xmm6
0000705c56fd9d2c  vmovaps [rsp+0x70], xmm7
0000705c56fd9d32  vmovaps [rsp+0x80], xmm8
0000705c56fd9d3b  vmovaps [rsp+0x90], xmm9
0000705c56fd9d44  vmovaps [rsp+0xA0], xmm11
0000705c56fd9d4d  vmovaps [rsp+0xB0], xmm12
0000705c56fd9d56  vmovaps [rsp+0xC0], xmm13
0000705c56fd9d5f  vmovaps [rsp+0xD0], xmm14
0000705c56fd9d68  vmovaps [rsp+0xE0], xmm15
0000705c56fd9d71  sub rsp, 0x30
0000705c56fd9d75  movaps [rsp], xmm10
0000705c56fd9d7a  movaps [rsp+0x10], xmm14
0000705c56fd9d80  movaps [rsp+0x20], xmm4
0000705c56fd9d85  lea rdi, [rsp]
0000705c56fd9d89  mov esi, 0x00
0000705c56fd9d8e  mov rax, 0x5877D3629530
0000705c56fd9d98  call rax
0000705c56fd9d9a  movaps xmm10, [rsp]
0000705c56fd9d9f  add rsp, 0x30
0000705c56fd9da3  vmovaps xmm0, [rsp]
0000705c56fd9da8  vmovaps xmm1, [rsp+0x10]
0000705c56fd9dae  vmovaps xmm2, [rsp+0x20]
0000705c56fd9db4  vmovaps xmm3, [rsp+0x30]
0000705c56fd9dba  vmovaps xmm4, [rsp+0x40]
0000705c56fd9dc0  vmovaps xmm5, [rsp+0x50]
0000705c56fd9dc6  vmovaps xmm6, [rsp+0x60]
0000705c56fd9dcc  vmovaps xmm7, [rsp+0x70]
0000705c56fd9dd2  vmovaps xmm8, [rsp+0x80]
0000705c56fd9ddb  vmovaps xmm9, [rsp+0x90]
0000705c56fd9de4  vmovaps xmm11, [rsp+0xA0]
0000705c56fd9ded  vmovaps xmm12, [rsp+0xB0]
0000705c56fd9df6  vmovaps xmm13, [rsp+0xC0]
0000705c56fd9dff  vmovaps xmm14, [rsp+0xD0]
0000705c56fd9e08  vmovaps xmm15, [rsp+0xE0]
0000705c56fd9e11  add rsp, 0xF0
0000705c56fd9e18  pop r11
0000705c56fd9e1a  pop r10
0000705c56fd9e1c  pop r9
0000705c56fd9e1e  pop r8
0000705c56fd9e20  pop rsi
0000705c56fd9e21  pop rdi
0000705c56fd9e22  pop rdx
0000705c56fd9e23  pop rcx
0000705c56fd9e24  pop rax
0000705c56fd9e25  add rsp, 0x08
0000705c56fd9e29  jmp 0x0000705C56FD6388
0000705c56fd9e2e  sub rsp, 0x08
0000705c56fd9e32  push rax
0000705c56fd9e33  push rcx
0000705c56fd9e34  push rdx
0000705c56fd9e35  push rdi
0000705c56fd9e36  push rsi
0000705c56fd9e37  push r8
0000705c56fd9e39  push r9
0000705c56fd9e3b  push r10
0000705c56fd9e3d  push r11
0000705c56fd9e3f  sub rsp, 0xF0
0000705c56fd9e46  vmovaps [rsp], xmm0
0000705c56fd9e4b  vmovaps [rsp+0x10], xmm1
0000705c56fd9e51  vmovaps [rsp+0x20], xmm2
0000705c56fd9e57  vmovaps [rsp+0x30], xmm3
0000705c56fd9e5d  vmovaps [rsp+0x40], xmm4
0000705c56fd9e63  vmovaps [rsp+0x50], xmm5
0000705c56fd9e69  vmovaps [rsp+0x60], xmm6
0000705c56fd9e6f  vmovaps [rsp+0x70], xmm7
0000705c56fd9e75  vmovaps [rsp+0x80], xmm9
0000705c56fd9e7e  vmovaps [rsp+0x90], xmm10
0000705c56fd9e87  vmovaps [rsp+0xA0], xmm11
0000705c56fd9e90  vmovaps [rsp+0xB0], xmm12
0000705c56fd9e99  vmovaps [rsp+0xC0], xmm13
0000705c56fd9ea2  vmovaps [rsp+0xD0], xmm14
0000705c56fd9eab  vmovaps [rsp+0xE0], xmm15
0000705c56fd9eb4  sub rsp, 0x30
0000705c56fd9eb8  movaps [rsp], xmm8
0000705c56fd9ebd  movaps [rsp+0x10], xmm1
0000705c56fd9ec2  movaps [rsp+0x20], xmm14
0000705c56fd9ec8  lea rdi, [rsp]
0000705c56fd9ecc  mov esi, 0x00
0000705c56fd9ed1  mov rax, 0x5877D3629530
0000705c56fd9edb  call rax
0000705c56fd9edd  movaps xmm8, [rsp]
0000705c56fd9ee2  add rsp, 0x30
0000705c56fd9ee6  vmovaps xmm0, [rsp]
0000705c56fd9eeb  vmovaps xmm1, [rsp+0x10]
0000705c56fd9ef1  vmovaps xmm2, [rsp+0x20]
0000705c56fd9ef7  vmovaps xmm3, [rsp+0x30]
0000705c56fd9efd  vmovaps xmm4, [rsp+0x40]
0000705c56fd9f03  vmovaps xmm5, [rsp+0x50]
0000705c56fd9f09  vmovaps xmm6, [rsp+0x60]
0000705c56fd9f0f  vmovaps xmm7, [rsp+0x70]
0000705c56fd9f15  vmovaps xmm9, [rsp+0x80]
0000705c56fd9f1e  vmovaps xmm10, [rsp+0x90]
0000705c56fd9f27  vmovaps xmm11, [rsp+0xA0]
0000705c56fd9f30  vmovaps xmm12, [rsp+0xB0]
0000705c56fd9f39  vmovaps xmm13, [rsp+0xC0]
0000705c56fd9f42  vmovaps xmm14, [rsp+0xD0]
0000705c56fd9f4b  vmovaps xmm15, [rsp+0xE0]
0000705c56fd9f54  add rsp, 0xF0
0000705c56fd9f5b  pop r11
0000705c56fd9f5d  pop r10
0000705c56fd9f5f  pop r9
0000705c56fd9f61  pop r8
0000705c56fd9f63  pop rsi
0000705c56fd9f64  pop rdi
0000705c56fd9f65  pop rdx
0000705c56fd9f66  pop rcx
0000705c56fd9f67  pop rax
0000705c56fd9f68  add rsp, 0x08
0000705c56fd9f6c  jmp 0x0000705C56FD63AE
0000705c56fd9f71  sub rsp, 0x08
0000705c56fd9f75  push rax
0000705c56fd9f76  push rcx
0000705c56fd9f77  push rdx
0000705c56fd9f78  push rdi
0000705c56fd9f79  push rsi
0000705c56fd9f7a  push r8
0000705c56fd9f7c  push r9
0000705c56fd9f7e  push r10
0000705c56fd9f80  push r11
0000705c56fd9f82  sub rsp, 0xF0
0000705c56fd9f89  vmovaps [rsp], xmm0
0000705c56fd9f8e  vmovaps [rsp+0x10], xmm1
0000705c56fd9f94  vmovaps [rsp+0x20], xmm2
0000705c56fd9f9a  vmovaps [rsp+0x30], xmm3
0000705c56fd9fa0  vmovaps [rsp+0x40], xmm4
0000705c56fd9fa6  vmovaps [rsp+0x50], xmm5
0000705c56fd9fac  vmovaps [rsp+0x60], xmm7
0000705c56fd9fb2  vmovaps [rsp+0x70], xmm8
0000705c56fd9fb8  vmovaps [rsp+0x80], xmm9
0000705c56fd9fc1  vmovaps [rsp+0x90], xmm10
0000705c56fd9fca  vmovaps [rsp+0xA0], xmm11
0000705c56fd9fd3  vmovaps [rsp+0xB0], xmm12
0000705c56fd9fdc  vmovaps [rsp+0xC0], xmm13
0000705c56fd9fe5  vmovaps [rsp+0xD0], xmm14
0000705c56fd9fee  vmovaps [rsp+0xE0], xmm15
0000705c56fd9ff7  sub rsp, 0x30
0000705c56fd9ffb  movaps [rsp], xmm6
0000705c56fd9fff  movaps [rsp+0x10], xmm1
0000705c56fda004  movaps [rsp+0x20], xmm14
0000705c56fda00a  lea rdi, [rsp]
0000705c56fda00e  mov esi, 0x00
0000705c56fda013  mov rax, 0x5877D3629530
0000705c56fda01d  call rax
0000705c56fda01f  movaps xmm6, [rsp]
0000705c56fda023  add rsp, 0x30
0000705c56fda027  vmovaps xmm0, [rsp]
0000705c56fda02c  vmovaps xmm1, [rsp+0x10]
0000705c56fda032  vmovaps xmm2, [rsp+0x20]
0000705c56fda038  vmovaps xmm3, [rsp+0x30]
0000705c56fda03e  vmovaps xmm4, [rsp+0x40]
0000705c56fda044  vmovaps xmm5, [rsp+0x50]
0000705c56fda04a  vmovaps xmm7, [rsp+0x60]
0000705c56fda050  vmovaps xmm8, [rsp+0x70]
0000705c56fda056  vmovaps xmm9, [rsp+0x80]
0000705c56fda05f  vmovaps xmm10, [rsp+0x90]
0000705c56fda068  vmovaps xmm11, [rsp+0xA0]
0000705c56fda071  vmovaps xmm12, [rsp+0xB0]
0000705c56fda07a  vmovaps xmm13, [rsp+0xC0]
0000705c56fda083  vmovaps xmm14, [rsp+0xD0]
0000705c56fda08c  vmovaps xmm15, [rsp+0xE0]
0000705c56fda095  add rsp, 0xF0
0000705c56fda09c  pop r11
0000705c56fda09e  pop r10
0000705c56fda0a0  pop r9
0000705c56fda0a2  pop r8
0000705c56fda0a4  pop rsi
0000705c56fda0a5  pop rdi
0000705c56fda0a6  pop rdx
0000705c56fda0a7  pop rcx
0000705c56fda0a8  pop rax
0000705c56fda0a9  add rsp, 0x08
0000705c56fda0ad  jmp 0x0000705C56FD63DA
0000705c56fda0b2  sub rsp, 0x08
0000705c56fda0b6  push rax
0000705c56fda0b7  push rcx
0000705c56fda0b8  push rdx
0000705c56fda0b9  push rdi
0000705c56fda0ba  push rsi
0000705c56fda0bb  push r8
0000705c56fda0bd  push r9
0000705c56fda0bf  push r10
0000705c56fda0c1  push r11
0000705c56fda0c3  sub rsp, 0xF0
0000705c56fda0ca  vmovaps [rsp], xmm0
0000705c56fda0cf  vmovaps [rsp+0x10], xmm1
0000705c56fda0d5  vmovaps [rsp+0x20], xmm2
0000705c56fda0db  vmovaps [rsp+0x30], xmm3
0000705c56fda0e1  vmovaps [rsp+0x40], xmm4
0000705c56fda0e7  vmovaps [rsp+0x50], xmm5
0000705c56fda0ed  vmovaps [rsp+0x60], xmm6
0000705c56fda0f3  vmovaps [rsp+0x70], xmm7
0000705c56fda0f9  vmovaps [rsp+0x80], xmm8
0000705c56fda102  vmovaps [rsp+0x90], xmm9
0000705c56fda10b  vmovaps [rsp+0xA0], xmm10
0000705c56fda114  vmovaps [rsp+0xB0], xmm11
0000705c56fda11d  vmovaps [rsp+0xC0], xmm12
0000705c56fda126  vmovaps [rsp+0xD0], xmm13
0000705c56fda12f  vmovaps [rsp+0xE0], xmm15
0000705c56fda138  sub rsp, 0x30
0000705c56fda13c  movaps [rsp], xmm14
0000705c56fda141  movaps [rsp+0x10], xmm12
0000705c56fda147  movaps [rsp+0x20], xmm1
0000705c56fda14c  lea rdi, [rsp]
0000705c56fda150  mov esi, 0x00
0000705c56fda155  mov rax, 0x5877D3629530
0000705c56fda15f  call rax
0000705c56fda161  movaps xmm14, [rsp]
0000705c56fda166  add rsp, 0x30
0000705c56fda16a  vmovaps xmm0, [rsp]
0000705c56fda16f  vmovaps xmm1, [rsp+0x10]
0000705c56fda175  vmovaps xmm2, [rsp+0x20]
0000705c56fda17b  vmovaps xmm3, [rsp+0x30]
0000705c56fda181  vmovaps xmm4, [rsp+0x40]
0000705c56fda187  vmovaps xmm5, [rsp+0x50]
0000705c56fda18d  vmovaps xmm6, [rsp+0x60]
0000705c56fda193  vmovaps xmm7, [rsp+0x70]
0000705c56fda199  vmovaps xmm8, [rsp+0x80]
0000705c56fda1a2  vmovaps xmm9, [rsp+0x90]
0000705c56fda1ab  vmovaps xmm10, [rsp+0xA0]
0000705c56fda1b4  vmovaps xmm11, [rsp+0xB0]
0000705c56fda1bd  vmovaps xmm12, [rsp+0xC0]
0000705c56fda1c6  vmovaps xmm13, [rsp+0xD0]
0000705c56fda1cf  vmovaps xmm15, [rsp+0xE0]
0000705c56fda1d8  add rsp, 0xF0
0000705c56fda1df  pop r11
0000705c56fda1e1  pop r10
0000705c56fda1e3  pop r9
0000705c56fda1e5  pop r8
0000705c56fda1e7  pop rsi
0000705c56fda1e8  pop rdi
0000705c56fda1e9  pop rdx
0000705c56fda1ea  pop rcx
0000705c56fda1eb  pop rax
0000705c56fda1ec  add rsp, 0x08
0000705c56fda1f0  jmp 0x0000705C56FD6400
0000705c56fda1f5  sub rsp, 0x08
0000705c56fda1f9  push rax
0000705c56fda1fa  push rcx
0000705c56fda1fb  push rdx
0000705c56fda1fc  push rdi
0000705c56fda1fd  push rsi
0000705c56fda1fe  push r8
0000705c56fda200  push r9
0000705c56fda202  push r10
0000705c56fda204  push r11
0000705c56fda206  sub rsp, 0xF0
0000705c56fda20d  vmovaps [rsp], xmm0
0000705c56fda212  vmovaps [rsp+0x10], xmm2
0000705c56fda218  vmovaps [rsp+0x20], xmm3
0000705c56fda21e  vmovaps [rsp+0x30], xmm4
0000705c56fda224  vmovaps [rsp+0x40], xmm5
0000705c56fda22a  vmovaps [rsp+0x50], xmm6
0000705c56fda230  vmovaps [rsp+0x60], xmm7
0000705c56fda236  vmovaps [rsp+0x70], xmm8
0000705c56fda23c  vmovaps [rsp+0x80], xmm9
0000705c56fda245  vmovaps [rsp+0x90], xmm10
0000705c56fda24e  vmovaps [rsp+0xA0], xmm11
0000705c56fda257  vmovaps [rsp+0xB0], xmm12
0000705c56fda260  vmovaps [rsp+0xC0], xmm13
0000705c56fda269  vmovaps [rsp+0xD0], xmm14
0000705c56fda272  vmovaps [rsp+0xE0], xmm15
0000705c56fda27b  sub rsp, 0x30
0000705c56fda27f  movaps [rsp], xmm1
0000705c56fda283  movaps [rsp+0x10], xmm13
0000705c56fda289  movaps [rsp+0x20], xmm9
0000705c56fda28f  lea rdi, [rsp]
0000705c56fda293  mov esi, 0x00
0000705c56fda298  mov rax, 0x5877D3629530
0000705c56fda2a2  call rax
0000705c56fda2a4  movaps xmm1, [rsp]
0000705c56fda2a8  add rsp, 0x30
0000705c56fda2ac  vmovaps xmm0, [rsp]
0000705c56fda2b1  vmovaps xmm2, [rsp+0x10]
0000705c56fda2b7  vmovaps xmm3, [rsp+0x20]
0000705c56fda2bd  vmovaps xmm4, [rsp+0x30]
0000705c56fda2c3  vmovaps xmm5, [rsp+0x40]
0000705c56fda2c9  vmovaps xmm6, [rsp+0x50]
0000705c56fda2cf  vmovaps xmm7, [rsp+0x60]
0000705c56fda2d5  vmovaps xmm8, [rsp+0x70]
0000705c56fda2db  vmovaps xmm9, [rsp+0x80]
0000705c56fda2e4  vmovaps xmm10, [rsp+0x90]
0000705c56fda2ed  vmovaps xmm11, [rsp+0xA0]
0000705c56fda2f6  vmovaps xmm12, [rsp+0xB0]
0000705c56fda2ff  vmovaps xmm13, [rsp+0xC0]
0000705c56fda308  vmovaps xmm14, [rsp+0xD0]
0000705c56fda311  vmovaps xmm15, [rsp+0xE0]
0000705c56fda31a  add rsp, 0xF0
0000705c56fda321  pop r11
0000705c56fda323  pop r10
0000705c56fda325  pop r9
0000705c56fda327  pop r8
0000705c56fda329  pop rsi
0000705c56fda32a  pop rdi
0000705c56fda32b  pop rdx
0000705c56fda32c  pop rcx
0000705c56fda32d  pop rax
0000705c56fda32e  add rsp, 0x08
0000705c56fda332  jmp 0x0000705C56FD641A
0000705c56fda337  sub rsp, 0x08
0000705c56fda33b  push rax
0000705c56fda33c  push rcx
0000705c56fda33d  push rdx
0000705c56fda33e  push rdi
0000705c56fda33f  push rsi
0000705c56fda340  push r8
0000705c56fda342  push r9
0000705c56fda344  push r10
0000705c56fda346  push r11
0000705c56fda348  sub rsp, 0xF0
0000705c56fda34f  vmovaps [rsp], xmm0
0000705c56fda354  vmovaps [rsp+0x10], xmm1
0000705c56fda35a  vmovaps [rsp+0x20], xmm2
0000705c56fda360  vmovaps [rsp+0x30], xmm3
0000705c56fda366  vmovaps [rsp+0x40], xmm4
0000705c56fda36c  vmovaps [rsp+0x50], xmm5
0000705c56fda372  vmovaps [rsp+0x60], xmm6
0000705c56fda378  vmovaps [rsp+0x70], xmm7
0000705c56fda37e  vmovaps [rsp+0x80], xmm8
0000705c56fda387  vmovaps [rsp+0x90], xmm9
0000705c56fda390  vmovaps [rsp+0xA0], xmm10
0000705c56fda399  vmovaps [rsp+0xB0], xmm11
0000705c56fda3a2  vmovaps [rsp+0xC0], xmm13
0000705c56fda3ab  vmovaps [rsp+0xD0], xmm14
0000705c56fda3b4  vmovaps [rsp+0xE0], xmm15
0000705c56fda3bd  sub rsp, 0x30
0000705c56fda3c1  movaps [rsp], xmm12
0000705c56fda3c6  movaps [rsp+0x10], xmm7
0000705c56fda3cb  movaps [rsp+0x20], xmm13
0000705c56fda3d1  lea rdi, [rsp]
0000705c56fda3d5  mov esi, 0x00
0000705c56fda3da  mov rax, 0x5877D3629530
0000705c56fda3e4  call rax
0000705c56fda3e6  movaps xmm12, [rsp]
0000705c56fda3eb  add rsp, 0x30
0000705c56fda3ef  vmovaps xmm0, [rsp]
0000705c56fda3f4  vmovaps xmm1, [rsp+0x10]
0000705c56fda3fa  vmovaps xmm2, [rsp+0x20]
0000705c56fda400  vmovaps xmm3, [rsp+0x30]
0000705c56fda406  vmovaps xmm4, [rsp+0x40]
0000705c56fda40c  vmovaps xmm5, [rsp+0x50]
0000705c56fda412  vmovaps xmm6, [rsp+0x60]
0000705c56fda418  vmovaps xmm7, [rsp+0x70]
0000705c56fda41e  vmovaps xmm8, [rsp+0x80]
0000705c56fda427  vmovaps xmm9, [rsp+0x90]
0000705c56fda430  vmovaps xmm10, [rsp+0xA0]
0000705c56fda439  vmovaps xmm11, [rsp+0xB0]
0000705c56fda442  vmovaps xmm13, [rsp+0xC0]
0000705c56fda44b  vmovaps xmm14, [rsp+0xD0]
0000705c56fda454  vmovaps xmm15, [rsp+0xE0]
0000705c56fda45d  add rsp, 0xF0
0000705c56fda464  pop r11
0000705c56fda466  pop r10
0000705c56fda468  pop r9
0000705c56fda46a  pop r8
0000705c56fda46c  pop rsi
0000705c56fda46d  pop rdi
0000705c56fda46e  pop rdx
0000705c56fda46f  pop rcx
0000705c56fda470  pop rax
0000705c56fda471  add rsp, 0x08
0000705c56fda475  jmp 0x0000705C56FD6441
0000705c56fda47a  sub rsp, 0x08
0000705c56fda47e  push rax
0000705c56fda47f  push rcx
0000705c56fda480  push rdx
0000705c56fda481  push rdi
0000705c56fda482  push rsi
0000705c56fda483  push r8
0000705c56fda485  push r9
0000705c56fda487  push r10
0000705c56fda489  push r11
0000705c56fda48b  sub rsp, 0xF0
0000705c56fda492  vmovaps [rsp], xmm0
0000705c56fda497  vmovaps [rsp+0x10], xmm1
0000705c56fda49d  vmovaps [rsp+0x20], xmm2
0000705c56fda4a3  vmovaps [rsp+0x30], xmm3
0000705c56fda4a9  vmovaps [rsp+0x40], xmm4
0000705c56fda4af  vmovaps [rsp+0x50], xmm5
0000705c56fda4b5  vmovaps [rsp+0x60], xmm6
0000705c56fda4bb  vmovaps [rsp+0x70], xmm7
0000705c56fda4c1  vmovaps [rsp+0x80], xmm8
0000705c56fda4ca  vmovaps [rsp+0x90], xmm9
0000705c56fda4d3  vmovaps [rsp+0xA0], xmm10
0000705c56fda4dc  vmovaps [rsp+0xB0], xmm11
0000705c56fda4e5  vmovaps [rsp+0xC0], xmm12
0000705c56fda4ee  vmovaps [rsp+0xD0], xmm14
0000705c56fda4f7  vmovaps [rsp+0xE0], xmm15
0000705c56fda500  sub rsp, 0x30
0000705c56fda504  movaps [rsp], xmm13
0000705c56fda509  movaps [rsp+0x10], xmm15
0000705c56fda50f  movaps [rsp+0x20], xmm8
0000705c56fda515  lea rdi, [rsp]
0000705c56fda519  mov esi, 0x00
0000705c56fda51e  mov rax, 0x5877D3629530
0000705c56fda528  call rax
0000705c56fda52a  movaps xmm13, [rsp]
0000705c56fda52f  add rsp, 0x30
0000705c56fda533  vmovaps xmm0, [rsp]
0000705c56fda538  vmovaps xmm1, [rsp+0x10]
0000705c56fda53e  vmovaps xmm2, [rsp+0x20]
0000705c56fda544  vmovaps xmm3, [rsp+0x30]
0000705c56fda54a  vmovaps xmm4, [rsp+0x40]
0000705c56fda550  vmovaps xmm5, [rsp+0x50]
0000705c56fda556  vmovaps xmm6, [rsp+0x60]
0000705c56fda55c  vmovaps xmm7, [rsp+0x70]
0000705c56fda562  vmovaps xmm8, [rsp+0x80]
0000705c56fda56b  vmovaps xmm9, [rsp+0x90]
0000705c56fda574  vmovaps xmm10, [rsp+0xA0]
0000705c56fda57d  vmovaps xmm11, [rsp+0xB0]
0000705c56fda586  vmovaps xmm12, [rsp+0xC0]
0000705c56fda58f  vmovaps xmm14, [rsp+0xD0]
0000705c56fda598  vmovaps xmm15, [rsp+0xE0]
0000705c56fda5a1  add rsp, 0xF0
0000705c56fda5a8  pop r11
0000705c56fda5aa  pop r10
0000705c56fda5ac  pop r9
0000705c56fda5ae  pop r8
0000705c56fda5b0  pop rsi
0000705c56fda5b1  pop rdi
0000705c56fda5b2  pop rdx
0000705c56fda5b3  pop rcx
0000705c56fda5b4  pop rax
0000705c56fda5b5  add rsp, 0x08
0000705c56fda5b9  jmp 0x0000705C56FD645C
0000705c56fda5be  sub rsp, 0x08
0000705c56fda5c2  push rax
0000705c56fda5c3  push rcx
0000705c56fda5c4  push rdx
0000705c56fda5c5  push rdi
0000705c56fda5c6  push rsi
0000705c56fda5c7  push r8
0000705c56fda5c9  push r9
0000705c56fda5cb  push r10
0000705c56fda5cd  push r11
0000705c56fda5cf  sub rsp, 0xF0
0000705c56fda5d6  vmovaps [rsp], xmm0
0000705c56fda5db  vmovaps [rsp+0x10], xmm1
0000705c56fda5e1  vmovaps [rsp+0x20], xmm2
0000705c56fda5e7  vmovaps [rsp+0x30], xmm3
0000705c56fda5ed  vmovaps [rsp+0x40], xmm4
0000705c56fda5f3  vmovaps [rsp+0x50], xmm5
0000705c56fda5f9  vmovaps [rsp+0x60], xmm6
0000705c56fda5ff  vmovaps [rsp+0x70], xmm7
0000705c56fda605  vmovaps [rsp+0x80], xmm9
0000705c56fda60e  vmovaps [rsp+0x90], xmm10
0000705c56fda617  vmovaps [rsp+0xA0], xmm11
0000705c56fda620  vmovaps [rsp+0xB0], xmm12
0000705c56fda629  vmovaps [rsp+0xC0], xmm13
0000705c56fda632  vmovaps [rsp+0xD0], xmm14
0000705c56fda63b  vmovaps [rsp+0xE0], xmm15
0000705c56fda644  sub rsp, 0x30
0000705c56fda648  movaps [rsp], xmm8
0000705c56fda64d  movaps [rsp+0x10], xmm15
0000705c56fda653  movaps [rsp+0x20], xmm9
0000705c56fda659  lea rdi, [rsp]
0000705c56fda65d  mov esi, 0x00
0000705c56fda662  mov rax, 0x5877D3629530
0000705c56fda66c  call rax
0000705c56fda66e  movaps xmm8, [rsp]
0000705c56fda673  add rsp, 0x30
0000705c56fda677  vmovaps xmm0, [rsp]
0000705c56fda67c  vmovaps xmm1, [rsp+0x10]
0000705c56fda682  vmovaps xmm2, [rsp+0x20]
0000705c56fda688  vmovaps xmm3, [rsp+0x30]
0000705c56fda68e  vmovaps xmm4, [rsp+0x40]
0000705c56fda694  vmovaps xmm5, [rsp+0x50]
0000705c56fda69a  vmovaps xmm6, [rsp+0x60]
0000705c56fda6a0  vmovaps xmm7, [rsp+0x70]
0000705c56fda6a6  vmovaps xmm9, [rsp+0x80]
0000705c56fda6af  vmovaps xmm10, [rsp+0x90]
0000705c56fda6b8  vmovaps xmm11, [rsp+0xA0]
0000705c56fda6c1  vmovaps xmm12, [rsp+0xB0]
0000705c56fda6ca  vmovaps xmm13, [rsp+0xC0]
0000705c56fda6d3  vmovaps xmm14, [rsp+0xD0]
0000705c56fda6dc  vmovaps xmm15, [rsp+0xE0]
0000705c56fda6e5  add rsp, 0xF0
0000705c56fda6ec  pop r11
0000705c56fda6ee  pop r10
0000705c56fda6f0  pop r9
0000705c56fda6f2  pop r8
0000705c56fda6f4  pop rsi
0000705c56fda6f5  pop rdi
0000705c56fda6f6  pop rdx
0000705c56fda6f7  pop rcx
0000705c56fda6f8  pop rax
0000705c56fda6f9  add rsp, 0x08
0000705c56fda6fd  jmp 0x0000705C56FD648A
0000705c56fda702  sub rsp, 0x08
0000705c56fda706  push rax
0000705c56fda707  push rcx
0000705c56fda708  push rdx
0000705c56fda709  push rdi
0000705c56fda70a  push rsi
0000705c56fda70b  push r8
0000705c56fda70d  push r9
0000705c56fda70f  push r10
0000705c56fda711  push r11
0000705c56fda713  sub rsp, 0xF0
0000705c56fda71a  vmovaps [rsp], xmm0
0000705c56fda71f  vmovaps [rsp+0x10], xmm1
0000705c56fda725  vmovaps [rsp+0x20], xmm2
0000705c56fda72b  vmovaps [rsp+0x30], xmm3
0000705c56fda731  vmovaps [rsp+0x40], xmm4
0000705c56fda737  vmovaps [rsp+0x50], xmm5
0000705c56fda73d  vmovaps [rsp+0x60], xmm6
0000705c56fda743  vmovaps [rsp+0x70], xmm7
0000705c56fda749  vmovaps [rsp+0x80], xmm8
0000705c56fda752  vmovaps [rsp+0x90], xmm9
0000705c56fda75b  vmovaps [rsp+0xA0], xmm10
0000705c56fda764  vmovaps [rsp+0xB0], xmm11
0000705c56fda76d  vmovaps [rsp+0xC0], xmm12
0000705c56fda776  vmovaps [rsp+0xD0], xmm13
0000705c56fda77f  vmovaps [rsp+0xE0], xmm14
0000705c56fda788  sub rsp, 0x30
0000705c56fda78c  movaps [rsp], xmm15
0000705c56fda791  movaps [rsp+0x10], xmm11
0000705c56fda797  movaps [rsp+0x20], xmm6
0000705c56fda79c  lea rdi, [rsp]
0000705c56fda7a0  mov esi, 0x00
0000705c56fda7a5  mov rax, 0x5877D3629530
0000705c56fda7af  call rax
0000705c56fda7b1  movaps xmm15, [rsp]
0000705c56fda7b6  add rsp, 0x30
0000705c56fda7ba  vmovaps xmm0, [rsp]
0000705c56fda7bf  vmovaps xmm1, [rsp+0x10]
0000705c56fda7c5  vmovaps xmm2, [rsp+0x20]
0000705c56fda7cb  vmovaps xmm3, [rsp+0x30]
0000705c56fda7d1  vmovaps xmm4, [rsp+0x40]
0000705c56fda7d7  vmovaps xmm5, [rsp+0x50]
0000705c56fda7dd  vmovaps xmm6, [rsp+0x60]
0000705c56fda7e3  vmovaps xmm7, [rsp+0x70]
0000705c56fda7e9  vmovaps xmm8, [rsp+0x80]
0000705c56fda7f2  vmovaps xmm9, [rsp+0x90]
0000705c56fda7fb  vmovaps xmm10, [rsp+0xA0]
0000705c56fda804  vmovaps xmm11, [rsp+0xB0]
0000705c56fda80d  vmovaps xmm12, [rsp+0xC0]
0000705c56fda816  vmovaps xmm13, [rsp+0xD0]
0000705c56fda81f  vmovaps xmm14, [rsp+0xE0]
0000705c56fda828  add rsp, 0xF0
0000705c56fda82f  pop r11
0000705c56fda831  pop r10
0000705c56fda833  pop r9
0000705c56fda835  pop r8
0000705c56fda837  pop rsi
0000705c56fda838  pop rdi
0000705c56fda839  pop rdx
0000705c56fda83a  pop rcx
0000705c56fda83b  pop rax
0000705c56fda83c  add rsp, 0x08
0000705c56fda840  jmp 0x0000705C56FD64A5
0000705c56fda845  sub rsp, 0x08
0000705c56fda849  push rax
0000705c56fda84a  push rcx
0000705c56fda84b  push rdx
0000705c56fda84c  push rdi
0000705c56fda84d  push rsi
0000705c56fda84e  push r8
0000705c56fda850  push r9
0000705c56fda852  push r10
0000705c56fda854  push r11
0000705c56fda856  sub rsp, 0xF0
0000705c56fda85d  vmovaps [rsp], xmm0
0000705c56fda862  vmovaps [rsp+0x10], xmm1
0000705c56fda868  vmovaps [rsp+0x20], xmm2
0000705c56fda86e  vmovaps [rsp+0x30], xmm3
0000705c56fda874  vmovaps [rsp+0x40], xmm4
0000705c56fda87a  vmovaps [rsp+0x50], xmm5
0000705c56fda880  vmovaps [rsp+0x60], xmm6
0000705c56fda886  vmovaps [rsp+0x70], xmm8
0000705c56fda88c  vmovaps [rsp+0x80], xmm9
0000705c56fda895  vmovaps [rsp+0x90], xmm10
0000705c56fda89e  vmovaps [rsp+0xA0], xmm11
0000705c56fda8a7  vmovaps [rsp+0xB0], xmm12
0000705c56fda8b0  vmovaps [rsp+0xC0], xmm13
0000705c56fda8b9  vmovaps [rsp+0xD0], xmm14
0000705c56fda8c2  vmovaps [rsp+0xE0], xmm15
0000705c56fda8cb  sub rsp, 0x30
0000705c56fda8cf  movaps [rsp], xmm7
0000705c56fda8d3  movaps [rsp+0x10], xmm11
0000705c56fda8d9  movaps [rsp+0x20], xmm9
0000705c56fda8df  lea rdi, [rsp]
0000705c56fda8e3  mov esi, 0x00
0000705c56fda8e8  mov rax, 0x5877D3629530
0000705c56fda8f2  call rax
0000705c56fda8f4  movaps xmm7, [rsp]
0000705c56fda8f8  add rsp, 0x30
0000705c56fda8fc  vmovaps xmm0, [rsp]
0000705c56fda901  vmovaps xmm1, [rsp+0x10]
0000705c56fda907  vmovaps xmm2, [rsp+0x20]
0000705c56fda90d  vmovaps xmm3, [rsp+0x30]
0000705c56fda913  vmovaps xmm4, [rsp+0x40]
0000705c56fda919  vmovaps xmm5, [rsp+0x50]
0000705c56fda91f  vmovaps xmm6, [rsp+0x60]
0000705c56fda925  vmovaps xmm8, [rsp+0x70]
0000705c56fda92b  vmovaps xmm9, [rsp+0x80]
0000705c56fda934  vmovaps xmm10, [rsp+0x90]
0000705c56fda93d  vmovaps xmm11, [rsp+0xA0]
0000705c56fda946  vmovaps xmm12, [rsp+0xB0]
0000705c56fda94f  vmovaps xmm13, [rsp+0xC0]
0000705c56fda958  vmovaps xmm14, [rsp+0xD0]
0000705c56fda961  vmovaps xmm15, [rsp+0xE0]
0000705c56fda96a  add rsp, 0xF0
0000705c56fda971  pop r11
0000705c56fda973  pop r10
0000705c56fda975  pop r9
0000705c56fda977  pop r8
0000705c56fda979  pop rsi
0000705c56fda97a  pop rdi
0000705c56fda97b  pop rdx
0000705c56fda97c  pop rcx
0000705c56fda97d  pop rax
0000705c56fda97e  add rsp, 0x08
0000705c56fda982  jmp 0x0000705C56FD64D2
0000705c56fda987  sub rsp, 0x08
0000705c56fda98b  push rax
0000705c56fda98c  push rcx
0000705c56fda98d  push rdx
0000705c56fda98e  push rdi
0000705c56fda98f  push rsi
0000705c56fda990  push r8
0000705c56fda992  push r9
0000705c56fda994  push r10
0000705c56fda996  push r11
0000705c56fda998  sub rsp, 0xF0
0000705c56fda99f  vmovaps [rsp], xmm0
0000705c56fda9a4  vmovaps [rsp+0x10], xmm1
0000705c56fda9aa  vmovaps [rsp+0x20], xmm2
0000705c56fda9b0  vmovaps [rsp+0x30], xmm3
0000705c56fda9b6  vmovaps [rsp+0x40], xmm4
0000705c56fda9bc  vmovaps [rsp+0x50], xmm5
0000705c56fda9c2  vmovaps [rsp+0x60], xmm6
0000705c56fda9c8  vmovaps [rsp+0x70], xmm7
0000705c56fda9ce  vmovaps [rsp+0x80], xmm8
0000705c56fda9d7  vmovaps [rsp+0x90], xmm9
0000705c56fda9e0  vmovaps [rsp+0xA0], xmm10
0000705c56fda9e9  vmovaps [rsp+0xB0], xmm12
0000705c56fda9f2  vmovaps [rsp+0xC0], xmm13
0000705c56fda9fb  vmovaps [rsp+0xD0], xmm14
0000705c56fdaa04  vmovaps [rsp+0xE0], xmm15
0000705c56fdaa0d  sub rsp, 0x30
0000705c56fdaa11  movaps [rsp], xmm11
0000705c56fdaa16  movaps [rsp+0x10], xmm10
0000705c56fdaa1c  movaps [rsp+0x20], xmm14
0000705c56fdaa22  lea rdi, [rsp]
0000705c56fdaa26  mov esi, 0x00
0000705c56fdaa2b  mov rax, 0x5877D3629530
0000705c56fdaa35  call rax
0000705c56fdaa37  movaps xmm11, [rsp]
0000705c56fdaa3c  add rsp, 0x30
0000705c56fdaa40  vmovaps xmm0, [rsp]
0000705c56fdaa45  vmovaps xmm1, [rsp+0x10]
0000705c56fdaa4b  vmovaps xmm2, [rsp+0x20]
0000705c56fdaa51  vmovaps xmm3, [rsp+0x30]
0000705c56fdaa57  vmovaps xmm4, [rsp+0x40]
0000705c56fdaa5d  vmovaps xmm5, [rsp+0x50]
0000705c56fdaa63  vmovaps xmm6, [rsp+0x60]
0000705c56fdaa69  vmovaps xmm7, [rsp+0x70]
0000705c56fdaa6f  vmovaps xmm8, [rsp+0x80]
0000705c56fdaa78  vmovaps xmm9, [rsp+0x90]
0000705c56fdaa81  vmovaps xmm10, [rsp+0xA0]
0000705c56fdaa8a  vmovaps xmm12, [rsp+0xB0]
0000705c56fdaa93  vmovaps xmm13, [rsp+0xC0]
0000705c56fdaa9c  vmovaps xmm14, [rsp+0xD0]
0000705c56fdaaa5  vmovaps xmm15, [rsp+0xE0]
0000705c56fdaaae  add rsp, 0xF0
0000705c56fdaab5  pop r11
0000705c56fdaab7  pop r10
0000705c56fdaab9  pop r9
0000705c56fdaabb  pop r8
0000705c56fdaabd  pop rsi
0000705c56fdaabe  pop rdi
0000705c56fdaabf  pop rdx
0000705c56fdaac0  pop rcx
0000705c56fdaac1  pop rax
0000705c56fdaac2  add rsp, 0x08
0000705c56fdaac6  jmp 0x0000705C56FD64ED
0000705c56fdaacb  call 0x0000705C56EE45A0
0000705c56fdaad0  jmp 0x0000705C56FD64F7
0000705c56fdaad5  sub rsp, 0x08
0000705c56fdaad9  push rax
0000705c56fdaada  push rcx
0000705c56fdaadb  push rdx
0000705c56fdaadc  push rdi
0000705c56fdaadd  push rsi
0000705c56fdaade  push r8
0000705c56fdaae0  push r9
0000705c56fdaae2  push r10
0000705c56fdaae4  push r11
0000705c56fdaae6  sub rsp, 0xF0
0000705c56fdaaed  vmovaps [rsp], xmm0
0000705c56fdaaf2  vmovaps [rsp+0x10], xmm1
0000705c56fdaaf8  vmovaps [rsp+0x20], xmm2
0000705c56fdaafe  vmovaps [rsp+0x30], xmm3
0000705c56fdab04  vmovaps [rsp+0x40], xmm4
0000705c56fdab0a  vmovaps [rsp+0x50], xmm5
0000705c56fdab10  vmovaps [rsp+0x60], xmm6
0000705c56fdab16  vmovaps [rsp+0x70], xmm7
0000705c56fdab1c  vmovaps [rsp+0x80], xmm8
0000705c56fdab25  vmovaps [rsp+0x90], xmm9
0000705c56fdab2e  vmovaps [rsp+0xA0], xmm11
0000705c56fdab37  vmovaps [rsp+0xB0], xmm12
0000705c56fdab40  vmovaps [rsp+0xC0], xmm13
0000705c56fdab49  vmovaps [rsp+0xD0], xmm14
0000705c56fdab52  vmovaps [rsp+0xE0], xmm15
0000705c56fdab5b  sub rsp, 0x30
0000705c56fdab5f  movaps [rsp], xmm10
0000705c56fdab64  movaps [rsp+0x10], xmm1
0000705c56fdab69  movaps [rsp+0x20], xmm12
0000705c56fdab6f  lea rdi, [rsp]
0000705c56fdab73  mov esi, 0x00
0000705c56fdab78  mov rax, 0x5877D3629530
0000705c56fdab82  call rax
0000705c56fdab84  movaps xmm10, [rsp]
0000705c56fdab89  add rsp, 0x30
0000705c56fdab8d  vmovaps xmm0, [rsp]
0000705c56fdab92  vmovaps xmm1, [rsp+0x10]
0000705c56fdab98  vmovaps xmm2, [rsp+0x20]
0000705c56fdab9e  vmovaps xmm3, [rsp+0x30]
0000705c56fdaba4  vmovaps xmm4, [rsp+0x40]
0000705c56fdabaa  vmovaps xmm5, [rsp+0x50]
0000705c56fdabb0  vmovaps xmm6, [rsp+0x60]
0000705c56fdabb6  vmovaps xmm7, [rsp+0x70]
0000705c56fdabbc  vmovaps xmm8, [rsp+0x80]
0000705c56fdabc5  vmovaps xmm9, [rsp+0x90]
0000705c56fdabce  vmovaps xmm11, [rsp+0xA0]
0000705c56fdabd7  vmovaps xmm12, [rsp+0xB0]
0000705c56fdabe0  vmovaps xmm13, [rsp+0xC0]
0000705c56fdabe9  vmovaps xmm14, [rsp+0xD0]
0000705c56fdabf2  vmovaps xmm15, [rsp+0xE0]
0000705c56fdabfb  add rsp, 0xF0
0000705c56fdac02  pop r11
0000705c56fdac04  pop r10
0000705c56fdac06  pop r9
0000705c56fdac08  pop r8
0000705c56fdac0a  pop rsi
0000705c56fdac0b  pop rdi
0000705c56fdac0c  pop rdx
0000705c56fdac0d  pop rcx
0000705c56fdac0e  pop rax
0000705c56fdac0f  add rsp, 0x08
0000705c56fdac13  jmp 0x0000705C56FD651A
0000705c56fdac18  sub rsp, 0x08
0000705c56fdac1c  push rax
0000705c56fdac1d  push rcx
0000705c56fdac1e  push rdx
0000705c56fdac1f  push rdi
0000705c56fdac20  push rsi
0000705c56fdac21  push r8
0000705c56fdac23  push r9
0000705c56fdac25  push r10
0000705c56fdac27  push r11
0000705c56fdac29  sub rsp, 0xF0
0000705c56fdac30  vmovaps [rsp], xmm0
0000705c56fdac35  vmovaps [rsp+0x10], xmm1
0000705c56fdac3b  vmovaps [rsp+0x20], xmm2
0000705c56fdac41  vmovaps [rsp+0x30], xmm3
0000705c56fdac47  vmovaps [rsp+0x40], xmm4
0000705c56fdac4d  vmovaps [rsp+0x50], xmm5
0000705c56fdac53  vmovaps [rsp+0x60], xmm6
0000705c56fdac59  vmovaps [rsp+0x70], xmm7
0000705c56fdac5f  vmovaps [rsp+0x80], xmm8
0000705c56fdac68  vmovaps [rsp+0x90], xmm9
0000705c56fdac71  vmovaps [rsp+0xA0], xmm10
0000705c56fdac7a  vmovaps [rsp+0xB0], xmm11
0000705c56fdac83  vmovaps [rsp+0xC0], xmm13
0000705c56fdac8c  vmovaps [rsp+0xD0], xmm14
0000705c56fdac95  vmovaps [rsp+0xE0], xmm15
0000705c56fdac9e  sub rsp, 0x30
0000705c56fdaca2  movaps [rsp], xmm12
0000705c56fdaca7  movaps [rsp+0x10], xmm14
0000705c56fdacad  movaps [rsp+0x20], xmm1
0000705c56fdacb2  lea rdi, [rsp]
0000705c56fdacb6  mov esi, 0x00
0000705c56fdacbb  mov rax, 0x5877D3629530
0000705c56fdacc5  call rax
0000705c56fdacc7  movaps xmm12, [rsp]
0000705c56fdaccc  add rsp, 0x30
0000705c56fdacd0  vmovaps xmm0, [rsp]
0000705c56fdacd5  vmovaps xmm1, [rsp+0x10]
0000705c56fdacdb  vmovaps xmm2, [rsp+0x20]
0000705c56fdace1  vmovaps xmm3, [rsp+0x30]
0000705c56fdace7  vmovaps xmm4, [rsp+0x40]
0000705c56fdaced  vmovaps xmm5, [rsp+0x50]
0000705c56fdacf3  vmovaps xmm6, [rsp+0x60]
0000705c56fdacf9  vmovaps xmm7, [rsp+0x70]
0000705c56fdacff  vmovaps xmm8, [rsp+0x80]
0000705c56fdad08  vmovaps xmm9, [rsp+0x90]
0000705c56fdad11  vmovaps xmm10, [rsp+0xA0]
0000705c56fdad1a  vmovaps xmm11, [rsp+0xB0]
0000705c56fdad23  vmovaps xmm13, [rsp+0xC0]
0000705c56fdad2c  vmovaps xmm14, [rsp+0xD0]
0000705c56fdad35  vmovaps xmm15, [rsp+0xE0]
0000705c56fdad3e  add rsp, 0xF0
0000705c56fdad45  pop r11
0000705c56fdad47  pop r10
0000705c56fdad49  pop r9
0000705c56fdad4b  pop r8
0000705c56fdad4d  pop rsi
0000705c56fdad4e  pop rdi
0000705c56fdad4f  pop rdx
0000705c56fdad50  pop rcx
0000705c56fdad51  pop rax
0000705c56fdad52  add rsp, 0x08
0000705c56fdad56  jmp 0x0000705C56FD6549
0000705c56fdad5b  sub rsp, 0x08
0000705c56fdad5f  push rax
0000705c56fdad60  push rcx
0000705c56fdad61  push rdx
0000705c56fdad62  push rdi
0000705c56fdad63  push rsi
0000705c56fdad64  push r8
0000705c56fdad66  push r9
0000705c56fdad68  push r10
0000705c56fdad6a  push r11
0000705c56fdad6c  sub rsp, 0xF0
0000705c56fdad73  vmovaps [rsp], xmm0
0000705c56fdad78  vmovaps [rsp+0x10], xmm1
0000705c56fdad7e  vmovaps [rsp+0x20], xmm2
0000705c56fdad84  vmovaps [rsp+0x30], xmm3
0000705c56fdad8a  vmovaps [rsp+0x40], xmm4
0000705c56fdad90  vmovaps [rsp+0x50], xmm5
0000705c56fdad96  vmovaps [rsp+0x60], xmm6
0000705c56fdad9c  vmovaps [rsp+0x70], xmm7
0000705c56fdada2  vmovaps [rsp+0x80], xmm8
0000705c56fdadab  vmovaps [rsp+0x90], xmm9
0000705c56fdadb4  vmovaps [rsp+0xA0], xmm10
0000705c56fdadbd  vmovaps [rsp+0xB0], xmm11
0000705c56fdadc6  vmovaps [rsp+0xC0], xmm12
0000705c56fdadcf  vmovaps [rsp+0xD0], xmm13
0000705c56fdadd8  vmovaps [rsp+0xE0], xmm15
0000705c56fdade1  sub rsp, 0x30
0000705c56fdade5  movaps [rsp], xmm14
0000705c56fdadea  movaps [rsp+0x10], xmm9
0000705c56fdadf0  movaps [rsp+0x20], xmm1
0000705c56fdadf5  lea rdi, [rsp]
0000705c56fdadf9  mov esi, 0x00
0000705c56fdadfe  mov rax, 0x5877D3629530
0000705c56fdae08  call rax
0000705c56fdae0a  movaps xmm14, [rsp]
0000705c56fdae0f  add rsp, 0x30
0000705c56fdae13  vmovaps xmm0, [rsp]
0000705c56fdae18  vmovaps xmm1, [rsp+0x10]
0000705c56fdae1e  vmovaps xmm2, [rsp+0x20]
0000705c56fdae24  vmovaps xmm3, [rsp+0x30]
0000705c56fdae2a  vmovaps xmm4, [rsp+0x40]
0000705c56fdae30  vmovaps xmm5, [rsp+0x50]
0000705c56fdae36  vmovaps xmm6, [rsp+0x60]
0000705c56fdae3c  vmovaps xmm7, [rsp+0x70]
0000705c56fdae42  vmovaps xmm8, [rsp+0x80]
0000705c56fdae4b  vmovaps xmm9, [rsp+0x90]
0000705c56fdae54  vmovaps xmm10, [rsp+0xA0]
0000705c56fdae5d  vmovaps xmm11, [rsp+0xB0]
0000705c56fdae66  vmovaps xmm12, [rsp+0xC0]
0000705c56fdae6f  vmovaps xmm13, [rsp+0xD0]
0000705c56fdae78  vmovaps xmm15, [rsp+0xE0]
0000705c56fdae81  add rsp, 0xF0
0000705c56fdae88  pop r11
0000705c56fdae8a  pop r10
0000705c56fdae8c  pop r9
0000705c56fdae8e  pop r8
0000705c56fdae90  pop rsi
0000705c56fdae91  pop rdi
0000705c56fdae92  pop rdx
0000705c56fdae93  pop rcx
0000705c56fdae94  pop rax
0000705c56fdae95  add rsp, 0x08
0000705c56fdae99  jmp 0x0000705C56FD6578
0000705c56fdae9e  sub rsp, 0x08
0000705c56fdaea2  push rax
0000705c56fdaea3  push rcx
0000705c56fdaea4  push rdx
0000705c56fdaea5  push rdi
0000705c56fdaea6  push rsi
0000705c56fdaea7  push r8
0000705c56fdaea9  push r9
0000705c56fdaeab  push r10
0000705c56fdaead  push r11
0000705c56fdaeaf  sub rsp, 0xF0
0000705c56fdaeb6  vmovaps [rsp], xmm0
0000705c56fdaebb  vmovaps [rsp+0x10], xmm2
0000705c56fdaec1  vmovaps [rsp+0x20], xmm3
0000705c56fdaec7  vmovaps [rsp+0x30], xmm4
0000705c56fdaecd  vmovaps [rsp+0x40], xmm5
0000705c56fdaed3  vmovaps [rsp+0x50], xmm6
0000705c56fdaed9  vmovaps [rsp+0x60], xmm7
0000705c56fdaedf  vmovaps [rsp+0x70], xmm8
0000705c56fdaee5  vmovaps [rsp+0x80], xmm9
0000705c56fdaeee  vmovaps [rsp+0x90], xmm10
0000705c56fdaef7  vmovaps [rsp+0xA0], xmm11
0000705c56fdaf00  vmovaps [rsp+0xB0], xmm12
0000705c56fdaf09  vmovaps [rsp+0xC0], xmm13
0000705c56fdaf12  vmovaps [rsp+0xD0], xmm14
0000705c56fdaf1b  vmovaps [rsp+0xE0], xmm15
0000705c56fdaf24  sub rsp, 0x30
0000705c56fdaf28  movaps [rsp], xmm1
0000705c56fdaf2c  movaps [rsp+0x10], xmm13
0000705c56fdaf32  movaps [rsp+0x20], xmm8
0000705c56fdaf38  lea rdi, [rsp]
0000705c56fdaf3c  mov esi, 0x00
0000705c56fdaf41  mov rax, 0x5877D3629530
0000705c56fdaf4b  call rax
0000705c56fdaf4d  movaps xmm1, [rsp]
0000705c56fdaf51  add rsp, 0x30
0000705c56fdaf55  vmovaps xmm0, [rsp]
0000705c56fdaf5a  vmovaps xmm2, [rsp+0x10]
0000705c56fdaf60  vmovaps xmm3, [rsp+0x20]
0000705c56fdaf66  vmovaps xmm4, [rsp+0x30]
0000705c56fdaf6c  vmovaps xmm5, [rsp+0x40]
0000705c56fdaf72  vmovaps xmm6, [rsp+0x50]
0000705c56fdaf78  vmovaps xmm7, [rsp+0x60]
0000705c56fdaf7e  vmovaps xmm8, [rsp+0x70]
0000705c56fdaf84  vmovaps xmm9, [rsp+0x80]
0000705c56fdaf8d  vmovaps xmm10, [rsp+0x90]
0000705c56fdaf96  vmovaps xmm11, [rsp+0xA0]
0000705c56fdaf9f  vmovaps xmm12, [rsp+0xB0]
0000705c56fdafa8  vmovaps xmm13, [rsp+0xC0]
0000705c56fdafb1  vmovaps xmm14, [rsp+0xD0]
0000705c56fdafba  vmovaps xmm15, [rsp+0xE0]
0000705c56fdafc3  add rsp, 0xF0
0000705c56fdafca  pop r11
0000705c56fdafcc  pop r10
0000705c56fdafce  pop r9
0000705c56fdafd0  pop r8
0000705c56fdafd2  pop rsi
0000705c56fdafd3  pop rdi
0000705c56fdafd4  pop rdx
0000705c56fdafd5  pop rcx
0000705c56fdafd6  pop rax
0000705c56fdafd7  add rsp, 0x08
0000705c56fdafdb  jmp 0x0000705C56FD659A
0000705c56fdafe0  call 0x0000705C56E0C260
0000705c56fdafe5  jmp 0x0000705C56FD65A8
0000705c56fdafea  call 0x0000705C56EDE950
0000705c56fdafef  jmp 0x0000705C56FD65B2
0000705c56fdaff4  sub rsp, 0x08
0000705c56fdaff8  push rax
0000705c56fdaff9  push rcx
0000705c56fdaffa  push rdx
0000705c56fdaffb  push rdi
0000705c56fdaffc  push rsi
0000705c56fdaffd  push r8
0000705c56fdafff  push r9
0000705c56fdb001  push r10
0000705c56fdb003  push r11
0000705c56fdb005  sub rsp, 0xF0
0000705c56fdb00c  vmovaps [rsp], xmm0
0000705c56fdb011  vmovaps [rsp+0x10], xmm1
0000705c56fdb017  vmovaps [rsp+0x20], xmm2
0000705c56fdb01d  vmovaps [rsp+0x30], xmm3
0000705c56fdb023  vmovaps [rsp+0x40], xmm4
0000705c56fdb029  vmovaps [rsp+0x50], xmm5
0000705c56fdb02f  vmovaps [rsp+0x60], xmm6
0000705c56fdb035  vmovaps [rsp+0x70], xmm7
0000705c56fdb03b  vmovaps [rsp+0x80], xmm9
0000705c56fdb044  vmovaps [rsp+0x90], xmm10
0000705c56fdb04d  vmovaps [rsp+0xA0], xmm11
0000705c56fdb056  vmovaps [rsp+0xB0], xmm12
0000705c56fdb05f  vmovaps [rsp+0xC0], xmm13
0000705c56fdb068  vmovaps [rsp+0xD0], xmm14
0000705c56fdb071  vmovaps [rsp+0xE0], xmm15
0000705c56fdb07a  sub rsp, 0x30
0000705c56fdb07e  movaps [rsp], xmm8
0000705c56fdb083  movaps [rsp+0x10], xmm15
0000705c56fdb089  movaps [rsp+0x20], xmm7
0000705c56fdb08e  lea rdi, [rsp]
0000705c56fdb092  mov esi, 0x00
0000705c56fdb097  mov rax, 0x5877D3629530
0000705c56fdb0a1  call rax
0000705c56fdb0a3  movaps xmm8, [rsp]
0000705c56fdb0a8  add rsp, 0x30
0000705c56fdb0ac  vmovaps xmm0, [rsp]
0000705c56fdb0b1  vmovaps xmm1, [rsp+0x10]
0000705c56fdb0b7  vmovaps xmm2, [rsp+0x20]
0000705c56fdb0bd  vmovaps xmm3, [rsp+0x30]
0000705c56fdb0c3  vmovaps xmm4, [rsp+0x40]
0000705c56fdb0c9  vmovaps xmm5, [rsp+0x50]
0000705c56fdb0cf  vmovaps xmm6, [rsp+0x60]
0000705c56fdb0d5  vmovaps xmm7, [rsp+0x70]
0000705c56fdb0db  vmovaps xmm9, [rsp+0x80]
0000705c56fdb0e4  vmovaps xmm10, [rsp+0x90]
0000705c56fdb0ed  vmovaps xmm11, [rsp+0xA0]
0000705c56fdb0f6  vmovaps xmm12, [rsp+0xB0]
0000705c56fdb0ff  vmovaps xmm13, [rsp+0xC0]
0000705c56fdb108  vmovaps xmm14, [rsp+0xD0]
0000705c56fdb111  vmovaps xmm15, [rsp+0xE0]
0000705c56fdb11a  add rsp, 0xF0
0000705c56fdb121  pop r11
0000705c56fdb123  pop r10
0000705c56fdb125  pop r9
0000705c56fdb127  pop r8
0000705c56fdb129  pop rsi
0000705c56fdb12a  pop rdi
0000705c56fdb12b  pop rdx
0000705c56fdb12c  pop rcx
0000705c56fdb12d  pop rax
0000705c56fdb12e  add rsp, 0x08
0000705c56fdb132  jmp 0x0000705C56FD65D4
0000705c56fdb137  sub rsp, 0x08
0000705c56fdb13b  push rax
0000705c56fdb13c  push rcx
0000705c56fdb13d  push rdx
0000705c56fdb13e  push rdi
0000705c56fdb13f  push rsi
0000705c56fdb140  push r8
0000705c56fdb142  push r9
0000705c56fdb144  push r10
0000705c56fdb146  push r11
0000705c56fdb148  sub rsp, 0xF0
0000705c56fdb14f  vmovaps [rsp], xmm0
0000705c56fdb154  vmovaps [rsp+0x10], xmm1
0000705c56fdb15a  vmovaps [rsp+0x20], xmm2
0000705c56fdb160  vmovaps [rsp+0x30], xmm3
0000705c56fdb166  vmovaps [rsp+0x40], xmm4
0000705c56fdb16c  vmovaps [rsp+0x50], xmm5
0000705c56fdb172  vmovaps [rsp+0x60], xmm6
0000705c56fdb178  vmovaps [rsp+0x70], xmm8
0000705c56fdb17e  vmovaps [rsp+0x80], xmm9
0000705c56fdb187  vmovaps [rsp+0x90], xmm10
0000705c56fdb190  vmovaps [rsp+0xA0], xmm11
0000705c56fdb199  vmovaps [rsp+0xB0], xmm12
0000705c56fdb1a2  vmovaps [rsp+0xC0], xmm13
0000705c56fdb1ab  vmovaps [rsp+0xD0], xmm14
0000705c56fdb1b4  vmovaps [rsp+0xE0], xmm15
0000705c56fdb1bd  sub rsp, 0x30
0000705c56fdb1c1  movaps [rsp], xmm7
0000705c56fdb1c5  movaps [rsp+0x10], xmm9
0000705c56fdb1cb  movaps [rsp+0x20], xmm15
0000705c56fdb1d1  lea rdi, [rsp]
0000705c56fdb1d5  mov esi, 0x00
0000705c56fdb1da  mov rax, 0x5877D3629530
0000705c56fdb1e4  call rax
0000705c56fdb1e6  movaps xmm7, [rsp]
0000705c56fdb1ea  add rsp, 0x30
0000705c56fdb1ee  vmovaps xmm0, [rsp]
0000705c56fdb1f3  vmovaps xmm1, [rsp+0x10]
0000705c56fdb1f9  vmovaps xmm2, [rsp+0x20]
0000705c56fdb1ff  vmovaps xmm3, [rsp+0x30]
0000705c56fdb205  vmovaps xmm4, [rsp+0x40]
0000705c56fdb20b  vmovaps xmm5, [rsp+0x50]
0000705c56fdb211  vmovaps xmm6, [rsp+0x60]
0000705c56fdb217  vmovaps xmm8, [rsp+0x70]
0000705c56fdb21d  vmovaps xmm9, [rsp+0x80]
0000705c56fdb226  vmovaps xmm10, [rsp+0x90]
0000705c56fdb22f  vmovaps xmm11, [rsp+0xA0]
0000705c56fdb238  vmovaps xmm12, [rsp+0xB0]
0000705c56fdb241  vmovaps xmm13, [rsp+0xC0]
0000705c56fdb24a  vmovaps xmm14, [rsp+0xD0]
0000705c56fdb253  vmovaps xmm15, [rsp+0xE0]
0000705c56fdb25c  add rsp, 0xF0
0000705c56fdb263  pop r11
0000705c56fdb265  pop r10
0000705c56fdb267  pop r9
0000705c56fdb269  pop r8
0000705c56fdb26b  pop rsi
0000705c56fdb26c  pop rdi
0000705c56fdb26d  pop rdx
0000705c56fdb26e  pop rcx
0000705c56fdb26f  pop rax
0000705c56fdb270  add rsp, 0x08
0000705c56fdb274  jmp 0x0000705C56FD6601
0000705c56fdb279  sub rsp, 0x08
0000705c56fdb27d  push rax
0000705c56fdb27e  push rcx
0000705c56fdb27f  push rdx
0000705c56fdb280  push rdi
0000705c56fdb281  push rsi
0000705c56fdb282  push r8
0000705c56fdb284  push r9
0000705c56fdb286  push r10
0000705c56fdb288  push r11
0000705c56fdb28a  sub rsp, 0xF0
0000705c56fdb291  vmovaps [rsp], xmm0
0000705c56fdb296  vmovaps [rsp+0x10], xmm1
0000705c56fdb29c  vmovaps [rsp+0x20], xmm2
0000705c56fdb2a2  vmovaps [rsp+0x30], xmm3
0000705c56fdb2a8  vmovaps [rsp+0x40], xmm4
0000705c56fdb2ae  vmovaps [rsp+0x50], xmm5
0000705c56fdb2b4  vmovaps [rsp+0x60], xmm6
0000705c56fdb2ba  vmovaps [rsp+0x70], xmm7
0000705c56fdb2c0  vmovaps [rsp+0x80], xmm8
0000705c56fdb2c9  vmovaps [rsp+0x90], xmm10
0000705c56fdb2d2  vmovaps [rsp+0xA0], xmm11
0000705c56fdb2db  vmovaps [rsp+0xB0], xmm12
0000705c56fdb2e4  vmovaps [rsp+0xC0], xmm13
0000705c56fdb2ed  vmovaps [rsp+0xD0], xmm14
0000705c56fdb2f6  vmovaps [rsp+0xE0], xmm15
0000705c56fdb2ff  sub rsp, 0x30
0000705c56fdb303  movaps [rsp], xmm9
0000705c56fdb308  movaps [rsp+0x10], xmm13
0000705c56fdb30e  movaps [rsp+0x20], xmm15
0000705c56fdb314  lea rdi, [rsp]
0000705c56fdb318  mov esi, 0x00
0000705c56fdb31d  mov rax, 0x5877D3629530
0000705c56fdb327  call rax
0000705c56fdb329  movaps xmm9, [rsp]
0000705c56fdb32e  add rsp, 0x30
0000705c56fdb332  vmovaps xmm0, [rsp]
0000705c56fdb337  vmovaps xmm1, [rsp+0x10]
0000705c56fdb33d  vmovaps xmm2, [rsp+0x20]
0000705c56fdb343  vmovaps xmm3, [rsp+0x30]
0000705c56fdb349  vmovaps xmm4, [rsp+0x40]
0000705c56fdb34f  vmovaps xmm5, [rsp+0x50]
0000705c56fdb355  vmovaps xmm6, [rsp+0x60]
0000705c56fdb35b  vmovaps xmm7, [rsp+0x70]
0000705c56fdb361  vmovaps xmm8, [rsp+0x80]
0000705c56fdb36a  vmovaps xmm10, [rsp+0x90]
0000705c56fdb373  vmovaps xmm11, [rsp+0xA0]
0000705c56fdb37c  vmovaps xmm12, [rsp+0xB0]
0000705c56fdb385  vmovaps xmm13, [rsp+0xC0]
0000705c56fdb38e  vmovaps xmm14, [rsp+0xD0]
0000705c56fdb397  vmovaps xmm15, [rsp+0xE0]
0000705c56fdb3a0  add rsp, 0xF0
0000705c56fdb3a7  pop r11
0000705c56fdb3a9  pop r10
0000705c56fdb3ab  pop r9
0000705c56fdb3ad  pop r8
0000705c56fdb3af  pop rsi
0000705c56fdb3b0  pop rdi
0000705c56fdb3b1  pop rdx
0000705c56fdb3b2  pop rcx
0000705c56fdb3b3  pop rax
0000705c56fdb3b4  add rsp, 0x08
0000705c56fdb3b8  jmp 0x0000705C56FD662F
0000705c56fdb3bd  sub rsp, 0x08
0000705c56fdb3c1  push rax
0000705c56fdb3c2  push rcx
0000705c56fdb3c3  push rdx
0000705c56fdb3c4  push rdi
0000705c56fdb3c5  push rsi
0000705c56fdb3c6  push r8
0000705c56fdb3c8  push r9
0000705c56fdb3ca  push r10
0000705c56fdb3cc  push r11
0000705c56fdb3ce  sub rsp, 0xF0
0000705c56fdb3d5  vmovaps [rsp], xmm0
0000705c56fdb3da  vmovaps [rsp+0x10], xmm1
0000705c56fdb3e0  vmovaps [rsp+0x20], xmm2
0000705c56fdb3e6  vmovaps [rsp+0x30], xmm3
0000705c56fdb3ec  vmovaps [rsp+0x40], xmm4
0000705c56fdb3f2  vmovaps [rsp+0x50], xmm5
0000705c56fdb3f8  vmovaps [rsp+0x60], xmm6
0000705c56fdb3fe  vmovaps [rsp+0x70], xmm7
0000705c56fdb404  vmovaps [rsp+0x80], xmm8
0000705c56fdb40d  vmovaps [rsp+0x90], xmm9
0000705c56fdb416  vmovaps [rsp+0xA0], xmm10
0000705c56fdb41f  vmovaps [rsp+0xB0], xmm11
0000705c56fdb428  vmovaps [rsp+0xC0], xmm12
0000705c56fdb431  vmovaps [rsp+0xD0], xmm13
0000705c56fdb43a  vmovaps [rsp+0xE0], xmm14
0000705c56fdb443  sub rsp, 0x30
0000705c56fdb447  movaps [rsp], xmm15
0000705c56fdb44c  movaps [rsp+0x10], xmm11
0000705c56fdb452  movaps [rsp+0x20], xmm12
0000705c56fdb458  lea rdi, [rsp]
0000705c56fdb45c  mov esi, 0x00
0000705c56fdb461  mov rax, 0x5877D3629530
0000705c56fdb46b  call rax
0000705c56fdb46d  movaps xmm15, [rsp]
0000705c56fdb472  add rsp, 0x30
0000705c56fdb476  vmovaps xmm0, [rsp]
0000705c56fdb47b  vmovaps xmm1, [rsp+0x10]
0000705c56fdb481  vmovaps xmm2, [rsp+0x20]
0000705c56fdb487  vmovaps xmm3, [rsp+0x30]
0000705c56fdb48d  vmovaps xmm4, [rsp+0x40]
0000705c56fdb493  vmovaps xmm5, [rsp+0x50]
0000705c56fdb499  vmovaps xmm6, [rsp+0x60]
0000705c56fdb49f  vmovaps xmm7, [rsp+0x70]
0000705c56fdb4a5  vmovaps xmm8, [rsp+0x80]
0000705c56fdb4ae  vmovaps xmm9, [rsp+0x90]
0000705c56fdb4b7  vmovaps xmm10, [rsp+0xA0]
0000705c56fdb4c0  vmovaps xmm11, [rsp+0xB0]
0000705c56fdb4c9  vmovaps xmm12, [rsp+0xC0]
0000705c56fdb4d2  vmovaps xmm13, [rsp+0xD0]
0000705c56fdb4db  vmovaps xmm14, [rsp+0xE0]
0000705c56fdb4e4  add rsp, 0xF0
0000705c56fdb4eb  pop r11
0000705c56fdb4ed  pop r10
0000705c56fdb4ef  pop r9
0000705c56fdb4f1  pop r8
0000705c56fdb4f3  pop rsi
0000705c56fdb4f4  pop rdi
0000705c56fdb4f5  pop rdx
0000705c56fdb4f6  pop rcx
0000705c56fdb4f7  pop rax
0000705c56fdb4f8  add rsp, 0x08
0000705c56fdb4fc  jmp 0x0000705C56FD664A
0000705c56fdb501  sub rsp, 0x08
0000705c56fdb505  push rax
0000705c56fdb506  push rcx
0000705c56fdb507  push rdx
0000705c56fdb508  push rdi
0000705c56fdb509  push rsi
0000705c56fdb50a  push r8
0000705c56fdb50c  push r9
0000705c56fdb50e  push r10
0000705c56fdb510  push r11
0000705c56fdb512  sub rsp, 0xF0
0000705c56fdb519  vmovaps [rsp], xmm0
0000705c56fdb51e  vmovaps [rsp+0x10], xmm1
0000705c56fdb524  vmovaps [rsp+0x20], xmm2
0000705c56fdb52a  vmovaps [rsp+0x30], xmm3
0000705c56fdb530  vmovaps [rsp+0x40], xmm4
0000705c56fdb536  vmovaps [rsp+0x50], xmm5
0000705c56fdb53c  vmovaps [rsp+0x60], xmm6
0000705c56fdb542  vmovaps [rsp+0x70], xmm7
0000705c56fdb548  vmovaps [rsp+0x80], xmm8
0000705c56fdb551  vmovaps [rsp+0x90], xmm9
0000705c56fdb55a  vmovaps [rsp+0xA0], xmm10
0000705c56fdb563  vmovaps [rsp+0xB0], xmm11
0000705c56fdb56c  vmovaps [rsp+0xC0], xmm12
0000705c56fdb575  vmovaps [rsp+0xD0], xmm14
0000705c56fdb57e  vmovaps [rsp+0xE0], xmm15
0000705c56fdb587  sub rsp, 0x30
0000705c56fdb58b  movaps [rsp], xmm13
0000705c56fdb590  movaps [rsp+0x10], xmm10
0000705c56fdb596  movaps [rsp+0x20], xmm14
0000705c56fdb59c  lea rdi, [rsp]
0000705c56fdb5a0  mov esi, 0x00
0000705c56fdb5a5  mov rax, 0x5877D3629530
0000705c56fdb5af  call rax
0000705c56fdb5b1  movaps xmm13, [rsp]
0000705c56fdb5b6  add rsp, 0x30
0000705c56fdb5ba  vmovaps xmm0, [rsp]
0000705c56fdb5bf  vmovaps xmm1, [rsp+0x10]
0000705c56fdb5c5  vmovaps xmm2, [rsp+0x20]
0000705c56fdb5cb  vmovaps xmm3, [rsp+0x30]
0000705c56fdb5d1  vmovaps xmm4, [rsp+0x40]
0000705c56fdb5d7  vmovaps xmm5, [rsp+0x50]
0000705c56fdb5dd  vmovaps xmm6, [rsp+0x60]
0000705c56fdb5e3  vmovaps xmm7, [rsp+0x70]
0000705c56fdb5e9  vmovaps xmm8, [rsp+0x80]
0000705c56fdb5f2  vmovaps xmm9, [rsp+0x90]
0000705c56fdb5fb  vmovaps xmm10, [rsp+0xA0]
0000705c56fdb604  vmovaps xmm11, [rsp+0xB0]
0000705c56fdb60d  vmovaps xmm12, [rsp+0xC0]
0000705c56fdb616  vmovaps xmm14, [rsp+0xD0]
0000705c56fdb61f  vmovaps xmm15, [rsp+0xE0]
0000705c56fdb628  add rsp, 0xF0
0000705c56fdb62f  pop r11
0000705c56fdb631  pop r10
0000705c56fdb633  pop r9
0000705c56fdb635  pop r8
0000705c56fdb637  pop rsi
0000705c56fdb638  pop rdi
0000705c56fdb639  pop rdx
0000705c56fdb63a  pop rcx
0000705c56fdb63b  pop rax
0000705c56fdb63c  add rsp, 0x08
0000705c56fdb640  jmp 0x0000705C56FD666D
0000705c56fdb645  sub rsp, 0x08
0000705c56fdb649  push rax
0000705c56fdb64a  push rcx
0000705c56fdb64b  push rdx
0000705c56fdb64c  push rdi
0000705c56fdb64d  push rsi
0000705c56fdb64e  push r8
0000705c56fdb650  push r9
0000705c56fdb652  push r10
0000705c56fdb654  push r11
0000705c56fdb656  sub rsp, 0xF0
0000705c56fdb65d  vmovaps [rsp], xmm0
0000705c56fdb662  vmovaps [rsp+0x10], xmm1
0000705c56fdb668  vmovaps [rsp+0x20], xmm2
0000705c56fdb66e  vmovaps [rsp+0x30], xmm3
0000705c56fdb674  vmovaps [rsp+0x40], xmm4
0000705c56fdb67a  vmovaps [rsp+0x50], xmm5
0000705c56fdb680  vmovaps [rsp+0x60], xmm6
0000705c56fdb686  vmovaps [rsp+0x70], xmm7
0000705c56fdb68c  vmovaps [rsp+0x80], xmm8
0000705c56fdb695  vmovaps [rsp+0x90], xmm9
0000705c56fdb69e  vmovaps [rsp+0xA0], xmm10
0000705c56fdb6a7  vmovaps [rsp+0xB0], xmm11
0000705c56fdb6b0  vmovaps [rsp+0xC0], xmm12
0000705c56fdb6b9  vmovaps [rsp+0xD0], xmm13
0000705c56fdb6c2  vmovaps [rsp+0xE0], xmm15
0000705c56fdb6cb  sub rsp, 0x30
0000705c56fdb6cf  movaps [rsp], xmm14
0000705c56fdb6d4  movaps [rsp+0x10], xmm1
0000705c56fdb6d9  movaps [rsp+0x20], xmm7
0000705c56fdb6de  lea rdi, [rsp]
0000705c56fdb6e2  mov esi, 0x00
0000705c56fdb6e7  mov rax, 0x5877D3629530
0000705c56fdb6f1  call rax
0000705c56fdb6f3  movaps xmm14, [rsp]
0000705c56fdb6f8  add rsp, 0x30
0000705c56fdb6fc  vmovaps xmm0, [rsp]
0000705c56fdb701  vmovaps xmm1, [rsp+0x10]
0000705c56fdb707  vmovaps xmm2, [rsp+0x20]
0000705c56fdb70d  vmovaps xmm3, [rsp+0x30]
0000705c56fdb713  vmovaps xmm4, [rsp+0x40]
0000705c56fdb719  vmovaps xmm5, [rsp+0x50]
0000705c56fdb71f  vmovaps xmm6, [rsp+0x60]
0000705c56fdb725  vmovaps xmm7, [rsp+0x70]
0000705c56fdb72b  vmovaps xmm8, [rsp+0x80]
0000705c56fdb734  vmovaps xmm9, [rsp+0x90]
0000705c56fdb73d  vmovaps xmm10, [rsp+0xA0]
0000705c56fdb746  vmovaps xmm11, [rsp+0xB0]
0000705c56fdb74f  vmovaps xmm12, [rsp+0xC0]
0000705c56fdb758  vmovaps xmm13, [rsp+0xD0]
0000705c56fdb761  vmovaps xmm15, [rsp+0xE0]
0000705c56fdb76a  add rsp, 0xF0
0000705c56fdb771  pop r11
0000705c56fdb773  pop r10
0000705c56fdb775  pop r9
0000705c56fdb777  pop r8
0000705c56fdb779  pop rsi
0000705c56fdb77a  pop rdi
0000705c56fdb77b  pop rdx
0000705c56fdb77c  pop rcx
0000705c56fdb77d  pop rax
0000705c56fdb77e  add rsp, 0x08
0000705c56fdb782  jmp 0x0000705C56FD6690
0000705c56fdb787  sub rsp, 0x08
0000705c56fdb78b  push rax
0000705c56fdb78c  push rcx
0000705c56fdb78d  push rdx
0000705c56fdb78e  push rdi
0000705c56fdb78f  push rsi
0000705c56fdb790  push r8
0000705c56fdb792  push r9
0000705c56fdb794  push r10
0000705c56fdb796  push r11
0000705c56fdb798  sub rsp, 0xF0
0000705c56fdb79f  vmovaps [rsp], xmm0
0000705c56fdb7a4  vmovaps [rsp+0x10], xmm2
0000705c56fdb7aa  vmovaps [rsp+0x20], xmm3
0000705c56fdb7b0  vmovaps [rsp+0x30], xmm4
0000705c56fdb7b6  vmovaps [rsp+0x40], xmm5
0000705c56fdb7bc  vmovaps [rsp+0x50], xmm6
0000705c56fdb7c2  vmovaps [rsp+0x60], xmm7
0000705c56fdb7c8  vmovaps [rsp+0x70], xmm8
0000705c56fdb7ce  vmovaps [rsp+0x80], xmm9
0000705c56fdb7d7  vmovaps [rsp+0x90], xmm10
0000705c56fdb7e0  vmovaps [rsp+0xA0], xmm11
0000705c56fdb7e9  vmovaps [rsp+0xB0], xmm12
0000705c56fdb7f2  vmovaps [rsp+0xC0], xmm13
0000705c56fdb7fb  vmovaps [rsp+0xD0], xmm14
0000705c56fdb804  vmovaps [rsp+0xE0], xmm15
0000705c56fdb80d  sub rsp, 0x30
0000705c56fdb811  movaps [rsp], xmm1
0000705c56fdb815  movaps [rsp+0x10], xmm8
0000705c56fdb81b  movaps [rsp+0x20], xmm9
0000705c56fdb821  lea rdi, [rsp]
0000705c56fdb825  mov esi, 0x00
0000705c56fdb82a  mov rax, 0x5877D3629530
0000705c56fdb834  call rax
0000705c56fdb836  movaps xmm1, [rsp]
0000705c56fdb83a  add rsp, 0x30
0000705c56fdb83e  vmovaps xmm0, [rsp]
0000705c56fdb843  vmovaps xmm2, [rsp+0x10]
0000705c56fdb849  vmovaps xmm3, [rsp+0x20]
0000705c56fdb84f  vmovaps xmm4, [rsp+0x30]
0000705c56fdb855  vmovaps xmm5, [rsp+0x40]
0000705c56fdb85b  vmovaps xmm6, [rsp+0x50]
0000705c56fdb861  vmovaps xmm7, [rsp+0x60]
0000705c56fdb867  vmovaps xmm8, [rsp+0x70]
0000705c56fdb86d  vmovaps xmm9, [rsp+0x80]
0000705c56fdb876  vmovaps xmm10, [rsp+0x90]
0000705c56fdb87f  vmovaps xmm11, [rsp+0xA0]
0000705c56fdb888  vmovaps xmm12, [rsp+0xB0]
0000705c56fdb891  vmovaps xmm13, [rsp+0xC0]
0000705c56fdb89a  vmovaps xmm14, [rsp+0xD0]
0000705c56fdb8a3  vmovaps xmm15, [rsp+0xE0]
0000705c56fdb8ac  add rsp, 0xF0
0000705c56fdb8b3  pop r11
0000705c56fdb8b5  pop r10
0000705c56fdb8b7  pop r9
0000705c56fdb8b9  pop r8
0000705c56fdb8bb  pop rsi
0000705c56fdb8bc  pop rdi
0000705c56fdb8bd  pop rdx
0000705c56fdb8be  pop rcx
0000705c56fdb8bf  pop rax
0000705c56fdb8c0  add rsp, 0x08
0000705c56fdb8c4  jmp 0x0000705C56FD66B2
0000705c56fdb8c9  call 0x0000705C56EB3E40
0000705c56fdb8ce  jmp 0x0000705C56FD66C0
0000705c56fdb8d3  call 0x0000705C56E0C380
0000705c56fdb8d8  jmp 0x0000705C56FD66CA
0000705c56fdb8dd  call 0x0000705C56E0D600
0000705c56fdb8e2  jmp 0x0000705C56FD66D4
0000705c56fdb8e7  call 0x0000705C56DFF540
0000705c56fdb8ec  jmp 0x0000705C56FD66DE
0000705c56fdb8f1  int3
0000705c56fdb8f2  nop [rax+rax*1], ax
0000705c56fdb8fb  nop [rax+rax*1], eax
0000705c56fdb900  mov eax, [r15+0x48]
0000705c56fdb904  lea r14d, [eax+0x01]
0000705c56fdb909  mov [rsp+0x10], r14d
0000705c56fdb90e  mov r14d, r14d
0000705c56fdb911  mov [r15+0x48], r14
0000705c56fdb915  xor eax, eax
0000705c56fdb917  mov r14d, [rsp+0x10]
0000705c56fdb91c  cmp r14d, 0x1F4
0000705c56fdb923  cmc
0000705c56fdb924  lahf
0000705c56fdb925  seto al
0000705c56fdb928  mov [r15+0x108], eax
0000705c56fdb92f  mov eax, [r15+0x108]
0000705c56fdb936  sahf
0000705c56fdb937  jnz 0x0000705C56FDB969
0000705c56fdb939  cmp dword ptr [r15+0x318], 0x00
0000705c56fdb941  jz 0x0000705C56FE1AB0
0000705c56fdb947  nop [rax+rax*1], ax
0000705c56fdb950  nop [rax+rax*1], eax
0000705c56fdb958  mov eax, 0x410450
0000705c56fdb95d  mov [r15+0x100], rax
0000705c56fdb964  jmp 0x0000705C56DFE110
0000705c56fdb969  cmp dword ptr [r15+0x318], 0x00
0000705c56fdb971  jz 0x0000705C56FDB9A0
0000705c56fdb977  nop [rax+rax*1], ax
0000705c56fdb980  nop [rax+rax*1], eax
0000705c56fdb988  mov eax, 0x410274
0000705c56fdb98d  mov [r15+0x100], rax
0000705c56fdb994  jmp 0x0000705C56DFE110
0000705c56fdb999  int3
0000705c56fdb99a  int3
0000705c56fdb99b  nop [rax+rax*1], eax
0000705c56fdb9a0  mov rax, [r15+0x40]
0000705c56fdb9a4  movaps xmm1, [r15+0x1D0]
0000705c56fdb9ac  vmovaps [rsp+0x10], xmm1
0000705c56fdb9b2  vmovaps xmm15, [rsp+0x10]
0000705c56fdb9b8  por xmm1, xmm15
0000705c56fdb9bd  movaps xmm14, [r15+0x1A0]
0000705c56fdb9c5  vmovaps [rsp+0x10], xmm14
0000705c56fdb9cb  vmovaps xmm13, [rsp+0x10]
0000705c56fdb9d1  por xmm14, xmm13
0000705c56fdb9d6  lea r14, [rax+0x30]
0000705c56fdb9da  mov r12, [r13+r14*1]
0000705c56fdb9df  lea r14, [rax+0x38]
0000705c56fdb9e3  mov r11, [r13+r14*1]
0000705c56fdb9e8  movq xmm13, r12
0000705c56fdb9ed  movq xmm12, r11
0000705c56fdb9f2  movq xmm13, xmm13
0000705c56fdb9f7  vmovaps [rsp+0x10], xmm13
0000705c56fdb9fd  movq xmm13, xmm13
0000705c56fdba02  movaps [r15+0x130], xmm13
0000705c56fdba0a  movq xmm12, xmm12
0000705c56fdba0f  vmovaps [rsp+0x20], xmm12
0000705c56fdba15  movq xmm12, xmm12
0000705c56fdba1a  movaps [r15+0x280], xmm12
0000705c56fdba22  movaps xmm13, [r15+0x270]
0000705c56fdba2a  vmovaps [rsp+0x30], xmm13
0000705c56fdba30  vmovaps xmm12, [rsp+0x30]
0000705c56fdba36  por xmm13, xmm12
0000705c56fdba3b  lea r14, [rax+0x20]
0000705c56fdba3f  mov r12, [r13+r14*1]
0000705c56fdba44  lea r14, [rax+0x28]
0000705c56fdba48  mov r11, [r13+r14*1]
0000705c56fdba4d  movq xmm12, r12
0000705c56fdba52  movq xmm11, r11
0000705c56fdba57  movq xmm12, xmm12
0000705c56fdba5c  vmovaps [rsp+0x30], xmm12
0000705c56fdba62  movq xmm12, xmm12
0000705c56fdba67  movaps [r15+0x150], xmm12
0000705c56fdba6f  movq xmm11, xmm11
0000705c56fdba74  vmovaps [rsp+0x40], xmm11
0000705c56fdba7a  movq xmm11, xmm11
0000705c56fdba7f  movaps [r15+0x140], xmm11
0000705c56fdba87  lea r14, [rax+0x10]
0000705c56fdba8b  mov r12, [r13+r14*1]
0000705c56fdba90  lea r14, [rax+0x18]
0000705c56fdba94  mov r11, [r13+r14*1]
0000705c56fdba99  movq xmm12, r12
0000705c56fdba9e  movq xmm11, r11
0000705c56fdbaa3  movq xmm12, xmm12
0000705c56fdbaa8  vmovaps [rsp+0x50], xmm12
0000705c56fdbaae  movq xmm12, xmm12
0000705c56fdbab3  movaps [r15+0x170], xmm12
0000705c56fdbabb  movq xmm11, xmm11
0000705c56fdbac0  vmovaps [rsp+0x60], xmm11
0000705c56fdbac6  movq xmm11, xmm11
0000705c56fdbacb  movaps [r15+0x160], xmm11
0000705c56fdbad3  mov r14, [r13+rax*1]
0000705c56fdbad8  vmovq xmm12, r14
0000705c56fdbadd  vpbroadcastq xmm12, xmm12
0000705c56fdbae2  lea r14, [rax+0x08]
0000705c56fdbae6  mov rax, [r13+r14*1]
0000705c56fdbaeb  movq xmm11, rax
0000705c56fdbaf0  movaps [r15+0x230], xmm11
0000705c56fdbaf8  mov rax, [r15+0xF8]
0000705c56fdbaff  lea r14, [rax+0x50]
0000705c56fdbb03  movups xmm11, [r13+r14*1]
0000705c56fdbb09  lea r14, [rax+0x60]
0000705c56fdbb0d  movups xmm10, [r13+r14*1]
0000705c56fdbb13  lea r14, [rax+0x30]
0000705c56fdbb17  movups xmm9, [r13+r14*1]
0000705c56fdbb1d  mov r14, [r15+0x50]
0000705c56fdbb21  mov [r15+0x60], r14
0000705c56fdbb25  mov qword ptr [r15+0x58], 0x40
0000705c56fdbb2d  movaps xmm8, xmm12
0000705c56fdbb31  mulpd xmm8, xmm15
0000705c56fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c56fdbb3c  ptest xmm7, xmm7
0000705c56fdbb41  jnz 0x0000705C56FDC96A
0000705c56fdbb47  movq xmm15, qword ptr [r15+0x230]
0000705c56fdbb50  vmovaps [rsp+0x70], xmm15
0000705c56fdbb56  vpermilpd xmm15, xmm15, 0x00
0000705c56fdbb5c  movaps xmm7, xmm9
0000705c56fdbb60  mulpd xmm7, xmm15
0000705c56fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c56fdbb6a  ptest xmm6, xmm6
0000705c56fdbb6f  jnz 0x0000705C56FDCAAE
0000705c56fdbb75  vxorps xmm15, xmm15, xmm15
0000705c56fdbb7a  vpbroadcastq xmm15, xmm15
0000705c56fdbb7f  movaps xmm9, xmm12
0000705c56fdbb83  mulpd xmm9, xmm10
0000705c56fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c56fdbb8e  ptest xmm6, xmm6
0000705c56fdbb93  jnz 0x0000705C56FDCBF0
0000705c56fdbb99  movaps xmm10, xmm12
0000705c56fdbb9d  mulpd xmm10, xmm11
0000705c56fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c56fdbba8  ptest xmm6, xmm6
0000705c56fdbbad  jnz 0x0000705C56FDCD34
0000705c56fdbbb3  movaps xmm11, [r15+0x1F0]
0000705c56fdbbbb  movaps xmm6, xmm12
0000705c56fdbbbf  mulpd xmm6, xmm11
0000705c56fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c56fdbbc9  ptest xmm5, xmm5
0000705c56fdbbce  jnz 0x0000705C56FDCE78
0000705c56fdbbd4  movaps xmm12, [r15+0x2A0]
0000705c56fdbbdc  vmovaps [rsp+0x80], xmm12
0000705c56fdbbe5  vmovaps xmm11, [rsp+0x80]
0000705c56fdbbee  por xmm12, xmm11
0000705c56fdbbf3  movaps xmm11, [r15+0x250]
0000705c56fdbbfb  vmovaps [rsp+0x80], xmm11
0000705c56fdbc04  vmovaps xmm5, [rsp+0x80]
0000705c56fdbc0d  por xmm11, xmm5
0000705c56fdbc12  vmovaps xmm4, [rsp+0x70]
0000705c56fdbc18  vpermilpd xmm4, xmm4, 0x00
0000705c56fdbc1e  movaps xmm3, xmm5
0000705c56fdbc21  mulpd xmm3, xmm4
0000705c56fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000705c56fdbc2a  ptest xmm2, xmm2
0000705c56fdbc2f  jnz 0x0000705C56FDCFBA
0000705c56fdbc35  mov [rsp+0x80], rax
0000705c56fdbc3d  xor eax, eax
0000705c56fdbc3f  mov r12d, 0x40
0000705c56fdbc45  mov r11d, 0x200
0000705c56fdbc4b  cmp r12, r11
0000705c56fdbc4e  cmc
0000705c56fdbc4f  lahf
0000705c56fdbc50  seto al
0000705c56fdbc53  mov [r15+0x108], eax
0000705c56fdbc5a  movaps xmm5, xmm8
0000705c56fdbc5e  addpd xmm5, xmm15
0000705c56fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000705c56fdbc68  ptest xmm4, xmm4
0000705c56fdbc6d  jnz 0x0000705C56FDD0FA
0000705c56fdbc73  movaps xmm8, [r15+0x1B0]
0000705c56fdbc7b  movaps xmm4, xmm9
0000705c56fdbc7f  addpd xmm4, xmm8
0000705c56fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000705c56fdbc89  ptest xmm2, xmm2
0000705c56fdbc8e  jnz 0x0000705C56FDD23C
0000705c56fdbc94  movaps xmm9, xmm10
0000705c56fdbc98  addpd xmm9, xmm8
0000705c56fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000705c56fdbca3  ptest xmm2, xmm2
0000705c56fdbca8  jnz 0x0000705C56FDD37E
0000705c56fdbcae  movaps xmm10, [r15+0x2F0]
0000705c56fdbcb6  vmovaps [rsp+0x90], xmm10
0000705c56fdbcbf  vmovaps xmm8, [rsp+0x90]
0000705c56fdbcc8  por xmm10, xmm8
0000705c56fdbccd  movaps xmm8, [r15+0x2E0]
0000705c56fdbcd5  vmovaps [rsp+0x90], xmm8
0000705c56fdbcde  vmovaps xmm2, [rsp+0x90]
0000705c56fdbce7  por xmm8, xmm2
0000705c56fdbcec  movaps xmm2, [r15+0x2D0]
0000705c56fdbcf4  vmovaps [rsp+0x90], xmm2
0000705c56fdbcfd  vmovaps [rsp+0xA0], xmm1
0000705c56fdbd06  vmovaps xmm1, [rsp+0x90]
0000705c56fdbd0f  por xmm2, xmm1
0000705c56fdbd13  movaps xmm1, [r15+0x200]
0000705c56fdbd1b  vmovaps [rsp+0x90], xmm1
0000705c56fdbd24  vmovaps [rsp+0xB0], xmm15
0000705c56fdbd2d  vmovaps xmm15, [rsp+0x90]
0000705c56fdbd36  por xmm1, xmm15
0000705c56fdbd3b  movaps xmm15, [r15+0x1C0]
0000705c56fdbd43  vmovaps [rsp+0x90], xmm15
0000705c56fdbd4c  vmovaps [rsp+0xC0], xmm1
0000705c56fdbd55  vmovaps xmm1, [rsp+0x90]
0000705c56fdbd5e  por xmm15, xmm1
0000705c56fdbd63  movaps xmm1, [r15+0x190]
0000705c56fdbd6b  vmovaps [rsp+0x90], xmm1
0000705c56fdbd74  vmovaps [rsp+0xD0], xmm15
0000705c56fdbd7d  vmovaps xmm15, [rsp+0x90]
0000705c56fdbd86  por xmm1, xmm15
0000705c56fdbd8b  movaps xmm15, [r15+0x300]
0000705c56fdbd93  vmovaps [rsp+0x90], xmm15
0000705c56fdbd9c  vmovaps [rsp+0xE0], xmm1
0000705c56fdbda5  vmovaps xmm1, [rsp+0x90]
0000705c56fdbdae  por xmm15, xmm1
0000705c56fdbdb3  mov rax, [rsp+0x80]
0000705c56fdbdbb  lea r12, [rax+0xA0]
0000705c56fdbdc2  movups xmm1, [r13+r12*1]
0000705c56fdbdc8  lea r12, [rax+0xB0]
0000705c56fdbdcf  vmovaps [rsp+0x80], xmm1
0000705c56fdbdd8  movups xmm1, [r13+r12*1]
0000705c56fdbdde  vmovaps [rsp+0x90], xmm1
0000705c56fdbde7  vmovaps [rsp+0xF0], xmm15
0000705c56fdbdf0  vmovaps xmm15, [rsp+0xB0]
0000705c56fdbdf9  vmovaps [rsp+0xB0], xmm14
0000705c56fdbe02  movaps xmm1, xmm6
0000705c56fdbe05  addpd xmm1, xmm15
0000705c56fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c56fdbe0f  ptest xmm14, xmm14
0000705c56fdbe15  jnz 0x0000705C56FDD4D6
0000705c56fdbe1b  lea r12, [rax+0xF0]
0000705c56fdbe22  movups xmm15, [r13+r12*1]
0000705c56fdbe28  movaps xmm14, xmm4
0000705c56fdbe2c  addpd xmm14, xmm3
0000705c56fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c56fdbe37  ptest xmm6, xmm6
0000705c56fdbe3c  jnz 0x0000705C56FDD621
0000705c56fdbe42  movaps xmm6, xmm9
0000705c56fdbe46  addpd xmm6, xmm7
0000705c56fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000705c56fdbe4f  ptest xmm4, xmm4
0000705c56fdbe54  jnz 0x0000705C56FDD763
0000705c56fdbe5a  vmovaps xmm9, [rsp+0x70]
0000705c56fdbe60  vpermilpd xmm9, xmm9, 0x00
0000705c56fdbe66  vmovaps xmm4, [rsp+0x90]
0000705c56fdbe6f  movaps xmm7, xmm4
0000705c56fdbe72  mulpd xmm7, xmm9
0000705c56fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000705c56fdbe7c  ptest xmm3, xmm3
0000705c56fdbe81  jnz 0x0000705C56FDD8A4
0000705c56fdbe87  vmovaps xmm9, [rsp+0x50]
0000705c56fdbe8d  vpermilpd xmm9, xmm9, 0x00
0000705c56fdbe93  movaps xmm4, xmm15
0000705c56fdbe97  mulpd xmm4, xmm9
0000705c56fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c56fdbea1  ptest xmm3, xmm3
0000705c56fdbea6  jnz 0x0000705C56FDD9E5
0000705c56fdbeac  lea r12, [rax+0xE0]
0000705c56fdbeb3  movups xmm15, [r13+r12*1]
0000705c56fdbeb9  vmovaps xmm9, [rsp+0x70]
0000705c56fdbebf  vpermilpd xmm9, xmm9, 0x00
0000705c56fdbec5  vmovaps [rsp+0x70], xmm1
0000705c56fdbecb  vmovaps xmm1, [rsp+0x80]
0000705c56fdbed4  vmovaps [rsp+0x80], xmm15
0000705c56fdbedd  movaps xmm3, xmm1
0000705c56fdbee0  mulpd xmm3, xmm9
0000705c56fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000705c56fdbeea  ptest xmm15, xmm15
0000705c56fdbef0  jnz 0x0000705C56FDDB31
0000705c56fdbef6  vmovaps xmm1, [rsp+0xF0]
0000705c56fdbeff  vmovaps xmm15, [rsp+0xF0]
0000705c56fdbf08  por xmm1, xmm15
0000705c56fdbf0d  movaps [r15+0x300], xmm1
0000705c56fdbf15  vmovaps xmm15, [rsp+0xE0]
0000705c56fdbf1e  vmovaps xmm9, [rsp+0xE0]
0000705c56fdbf27  por xmm15, xmm9
0000705c56fdbf2c  movaps [r15+0x190], xmm15
0000705c56fdbf34  vmovaps xmm9, [rsp+0x50]
0000705c56fdbf3a  vpermilpd xmm9, xmm9, 0x00
0000705c56fdbf40  vmovaps [rsp+0x90], xmm1
0000705c56fdbf49  vmovaps [rsp+0xE0], xmm15
0000705c56fdbf52  vmovaps xmm15, [rsp+0x80]
0000705c56fdbf5b  vmovaps [rsp+0x80], xmm14
0000705c56fdbf64  movaps xmm1, xmm15
0000705c56fdbf68  mulpd xmm1, xmm9
0000705c56fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c56fdbf72  ptest xmm14, xmm14
0000705c56fdbf78  jnz 0x0000705C56FDDC72
0000705c56fdbf7e  lea r12, [rax+0x90]
0000705c56fdbf85  movups xmm15, [r13+r12*1]
0000705c56fdbf8b  vmovaps xmm14, [rsp+0xD0]
0000705c56fdbf94  vmovaps xmm9, [rsp+0xD0]
0000705c56fdbf9d  por xmm14, xmm9
0000705c56fdbfa2  movaps [r15+0x1C0], xmm14
0000705c56fdbfaa  vmovaps xmm9, [rsp+0xC0]
0000705c56fdbfb3  vmovaps [rsp+0xD0], xmm1
0000705c56fdbfbc  vmovaps xmm1, [rsp+0xC0]
0000705c56fdbfc5  por xmm9, xmm1
0000705c56fdbfca  movaps [r15+0x200], xmm9
0000705c56fdbfd2  vmovaps [rsp+0xC0], xmm2
0000705c56fdbfdb  vmovaps xmm1, [rsp+0xC0]
0000705c56fdbfe4  por xmm2, xmm1
0000705c56fdbfe8  movaps [r15+0x2D0], xmm2
0000705c56fdbff0  vmovaps [rsp+0xC0], xmm8
0000705c56fdbff9  vmovaps xmm1, [rsp+0xC0]
0000705c56fdc002  por xmm8, xmm1
0000705c56fdc007  movaps [r15+0x2E0], xmm8
0000705c56fdc00f  vmovaps [rsp+0xC0], xmm15
0000705c56fdc018  movaps xmm1, xmm5
0000705c56fdc01b  addpd xmm1, xmm7
0000705c56fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c56fdc024  ptest xmm15, xmm15
0000705c56fdc02a  jnz 0x0000705C56FDDDBE
0000705c56fdc030  vmovaps xmm15, [rsp+0x50]
0000705c56fdc036  vpermilpd xmm15, xmm15, 0x00
0000705c56fdc03c  vmovaps xmm5, [rsp+0xC0]
0000705c56fdc045  vmovaps [rsp+0xC0], xmm1
0000705c56fdc04e  movaps xmm7, xmm5
0000705c56fdc051  mulpd xmm7, xmm15
0000705c56fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000705c56fdc05b  ptest xmm1, xmm1
0000705c56fdc060  jnz 0x0000705C56FDDEFE
0000705c56fdc066  lea r12, [rax+0x80]
0000705c56fdc06d  movups xmm1, [r13+r12*1]
0000705c56fdc073  vmovaps xmm5, [rsp+0x70]
0000705c56fdc079  vmovaps [rsp+0x70], xmm1
0000705c56fdc07f  movaps xmm15, xmm5
0000705c56fdc083  addpd xmm15, xmm3
0000705c56fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fdc08e  ptest xmm1, xmm1
0000705c56fdc093  jnz 0x0000705C56FDE049
0000705c56fdc099  vmovaps xmm5, [rsp+0x80]
0000705c56fdc0a2  movaps xmm1, xmm5
0000705c56fdc0a5  addpd xmm1, xmm4
0000705c56fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000705c56fdc0ae  ptest xmm3, xmm3
0000705c56fdc0b3  jnz 0x0000705C56FDE18B
0000705c56fdc0b9  vmovaps [rsp+0x80], xmm10
0000705c56fdc0c2  vmovaps xmm5, [rsp+0x80]
0000705c56fdc0cb  por xmm10, xmm5
0000705c56fdc0d0  movaps [r15+0x2F0], xmm10
0000705c56fdc0d8  vmovaps xmm5, [rsp+0x50]
0000705c56fdc0de  vpermilpd xmm5, xmm5, 0x00
0000705c56fdc0e4  vmovaps xmm3, [rsp+0x70]
0000705c56fdc0ea  vmovaps [rsp+0x50], xmm1
0000705c56fdc0f0  movaps xmm4, xmm3
0000705c56fdc0f3  mulpd xmm4, xmm5
0000705c56fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c56fdc0fc  ptest xmm1, xmm1
0000705c56fdc101  jnz 0x0000705C56FDE2CB
0000705c56fdc107  lea r12, [rax+0xD0]
0000705c56fdc10e  movups xmm1, [r13+r12*1]
0000705c56fdc114  vmovaps xmm3, [rsp+0xD0]
0000705c56fdc11d  vmovaps [rsp+0x70], xmm1
0000705c56fdc123  movaps xmm5, xmm6
0000705c56fdc126  addpd xmm5, xmm3
0000705c56fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000705c56fdc12f  ptest xmm1, xmm1
0000705c56fdc134  jnz 0x0000705C56FDE415
0000705c56fdc13a  vmovaps xmm1, [rsp+0x60]
0000705c56fdc140  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc146  movaps xmm6, xmm9
0000705c56fdc14a  mulpd xmm6, xmm1
0000705c56fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c56fdc153  ptest xmm3, xmm3
0000705c56fdc158  jnz 0x0000705C56FDE555
0000705c56fdc15e  movaps [r15+0x260], xmm6
0000705c56fdc166  vxorps xmm1, xmm1, xmm1
0000705c56fdc16a  vpbroadcastq xmm1, xmm1
0000705c56fdc16f  movaps [r15+0x1B0], xmm1
0000705c56fdc177  vmovaps xmm1, [rsp+0x60]
0000705c56fdc17d  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc183  vmovaps xmm3, [rsp+0x70]
0000705c56fdc189  vmovaps [rsp+0x70], xmm15
0000705c56fdc18f  movaps xmm9, xmm3
0000705c56fdc193  mulpd xmm9, xmm1
0000705c56fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c56fdc19e  ptest xmm15, xmm15
0000705c56fdc1a4  jnz 0x0000705C56FDE696
0000705c56fdc1aa  lea r12, [rax+0xC0]
0000705c56fdc1b1  movups xmm1, [r13+r12*1]
0000705c56fdc1b7  vmovaps xmm3, [rsp+0xC0]
0000705c56fdc1c0  vmovaps [rsp+0x80], xmm1
0000705c56fdc1c9  movaps xmm15, xmm3
0000705c56fdc1cd  addpd xmm15, xmm7
0000705c56fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fdc1d8  ptest xmm1, xmm1
0000705c56fdc1dd  jnz 0x0000705C56FDE7E2
0000705c56fdc1e3  vmovaps [rsp+0xC0], xmm13
0000705c56fdc1ec  vmovaps xmm1, [rsp+0xC0]
0000705c56fdc1f5  por xmm13, xmm1
0000705c56fdc1fa  movaps [r15+0x270], xmm13
0000705c56fdc202  vmovaps xmm1, [rsp+0xB0]
0000705c56fdc20b  vmovaps xmm7, [rsp+0xB0]
0000705c56fdc214  por xmm1, xmm7
0000705c56fdc218  movaps [r15+0x1A0], xmm1
0000705c56fdc220  vmovaps xmm1, [rsp+0x60]
0000705c56fdc226  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc22c  vmovaps [rsp+0xB0], xmm1
0000705c56fdc235  vmovaps xmm1, [rsp+0x80]
0000705c56fdc23e  vmovaps [rsp+0x80], xmm15
0000705c56fdc247  vmovaps xmm15, [rsp+0xB0]
0000705c56fdc250  vmovaps [rsp+0xB0], xmm14
0000705c56fdc259  movaps xmm3, xmm1
0000705c56fdc25c  mulpd xmm3, xmm15
0000705c56fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000705c56fdc266  ptest xmm14, xmm14
0000705c56fdc26c  jnz 0x0000705C56FDE924
0000705c56fdc272  lea r12, [rax+0x20]
0000705c56fdc276  movups xmm1, [r13+r12*1]
0000705c56fdc27c  movaps [r15+0x110], xmm1
0000705c56fdc284  vmovaps xmm14, [rsp+0x70]
0000705c56fdc28a  vmovaps [rsp+0x70], xmm1
0000705c56fdc290  movaps xmm15, xmm14
0000705c56fdc294  addpd xmm15, xmm4
0000705c56fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c56fdc29f  ptest xmm1, xmm1
0000705c56fdc2a4  jnz 0x0000705C56FDEA6F
0000705c56fdc2aa  vmovaps xmm1, [rsp+0x60]
0000705c56fdc2b0  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc2b6  movaps xmm14, xmm2
0000705c56fdc2ba  mulpd xmm14, xmm1
0000705c56fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000705c56fdc2c5  ptest xmm4, xmm4
0000705c56fdc2ca  jnz 0x0000705C56FDEBB2
0000705c56fdc2d0  vmovaps xmm4, [rsp+0x50]
0000705c56fdc2d6  movaps xmm1, xmm4
0000705c56fdc2d9  addpd xmm1, xmm9
0000705c56fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c56fdc2e3  ptest xmm2, xmm2
0000705c56fdc2e8  jnz 0x0000705C56FDECF4
0000705c56fdc2ee  vmovaps xmm9, [rsp+0x30]
0000705c56fdc2f4  vpermilpd xmm9, xmm9, 0x00
0000705c56fdc2fa  vmovaps xmm2, [rsp+0x70]
0000705c56fdc300  vmovaps [rsp+0x50], xmm1
0000705c56fdc306  movaps xmm4, xmm2
0000705c56fdc309  mulpd xmm4, xmm9
0000705c56fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c56fdc313  ptest xmm1, xmm1
0000705c56fdc318  jnz 0x0000705C56FDEE35
0000705c56fdc31e  vmovaps xmm1, [rsp+0x30]
0000705c56fdc324  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc32a  vmovaps xmm2, [rsp+0x90]
0000705c56fdc333  vmovaps [rsp+0x60], xmm15
0000705c56fdc339  movaps xmm9, xmm2
0000705c56fdc33d  mulpd xmm9, xmm1
0000705c56fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c56fdc348  ptest xmm15, xmm15
0000705c56fdc34e  jnz 0x0000705C56FDEF76
0000705c56fdc354  vmovaps xmm15, [rsp+0x80]
0000705c56fdc35d  movaps xmm1, xmm15
0000705c56fdc361  addpd xmm1, xmm6
0000705c56fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c56fdc36a  ptest xmm2, xmm2
0000705c56fdc36f  jnz 0x0000705C56FDF0B8
0000705c56fdc375  movaps xmm15, xmm5
0000705c56fdc379  addpd xmm15, xmm3
0000705c56fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000705c56fdc384  ptest xmm6, xmm6
0000705c56fdc389  jnz 0x0000705C56FDF1F9
0000705c56fdc38f  vmovaps xmm6, [rsp+0x30]
0000705c56fdc395  vpermilpd xmm6, xmm6, 0x00
0000705c56fdc39b  movaps xmm5, xmm8
0000705c56fdc39f  mulpd xmm5, xmm6
0000705c56fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000705c56fdc3a8  ptest xmm3, xmm3
0000705c56fdc3ad  jnz 0x0000705C56FDF33B
0000705c56fdc3b3  vmovaps xmm8, [rsp+0x30]
0000705c56fdc3b9  vpermilpd xmm8, xmm8, 0x00
0000705c56fdc3bf  movaps xmm6, xmm10
0000705c56fdc3c3  mulpd xmm6, xmm8
0000705c56fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c56fdc3cd  ptest xmm3, xmm3
0000705c56fdc3d2  jnz 0x0000705C56FDF47C
0000705c56fdc3d8  vmovaps xmm8, [rsp+0x60]
0000705c56fdc3de  movaps xmm10, xmm8
0000705c56fdc3e2  addpd xmm10, xmm14
0000705c56fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000705c56fdc3ed  ptest xmm3, xmm3
0000705c56fdc3f2  jnz 0x0000705C56FDF5BE
0000705c56fdc3f8  vmovaps xmm8, [rsp+0x50]
0000705c56fdc3fe  movaps xmm14, xmm8
0000705c56fdc402  addpd xmm14, xmm4
0000705c56fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000705c56fdc40d  ptest xmm3, xmm3
0000705c56fdc412  jnz 0x0000705C56FDF702
0000705c56fdc418  vmovaps xmm8, [rsp+0x40]
0000705c56fdc41e  vpermilpd xmm8, xmm8, 0x00
0000705c56fdc424  movaps xmm4, xmm13
0000705c56fdc428  mulpd xmm4, xmm8
0000705c56fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c56fdc432  ptest xmm3, xmm3
0000705c56fdc437  jnz 0x0000705C56FDF845
0000705c56fdc43d  movaps xmm13, xmm15
0000705c56fdc441  addpd xmm13, xmm9
0000705c56fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000705c56fdc44c  ptest xmm8, xmm8
0000705c56fdc452  jnz 0x0000705C56FDF987
0000705c56fdc458  movaps xmm15, xmm1
0000705c56fdc45c  addpd xmm15, xmm5
0000705c56fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c56fdc467  ptest xmm9, xmm9
0000705c56fdc46d  jnz 0x0000705C56FDFACB
0000705c56fdc473  vmovaps [rsp+0x30], xmm11
0000705c56fdc479  vmovaps xmm1, [rsp+0x30]
0000705c56fdc47f  por xmm11, xmm1
0000705c56fdc484  movaps [r15+0x250], xmm11
0000705c56fdc48c  vmovaps [rsp+0x30], xmm12
0000705c56fdc492  vmovaps xmm1, [rsp+0x30]
0000705c56fdc498  por xmm12, xmm1
0000705c56fdc49d  movaps [r15+0x2A0], xmm12
0000705c56fdc4a5  vmovaps xmm1, [rsp+0xA0]
0000705c56fdc4ae  vmovaps xmm11, [rsp+0xA0]
0000705c56fdc4b7  por xmm1, xmm11
0000705c56fdc4bc  movaps [r15+0x1D0], xmm1
0000705c56fdc4c4  lea r12, [rax+0x40]
0000705c56fdc4c8  movups xmm1, [r13+r12*1]
0000705c56fdc4ce  movaps [r15+0x2C0], xmm1
0000705c56fdc4d6  vmovaps xmm11, [rsp+0x40]
0000705c56fdc4dc  vpermilpd xmm11, xmm11, 0x00
0000705c56fdc4e2  vmovaps xmm8, [rsp+0xE0]
0000705c56fdc4eb  movaps xmm9, xmm8
0000705c56fdc4ef  mulpd xmm9, xmm11
0000705c56fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000705c56fdc4fa  ptest xmm5, xmm5
0000705c56fdc4ff  jnz 0x0000705C56FDFC17
0000705c56fdc505  movaps xmm11, xmm10
0000705c56fdc509  addpd xmm11, xmm6
0000705c56fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000705c56fdc514  ptest xmm8, xmm8
0000705c56fdc51a  jnz 0x0000705C56FDFD5B
0000705c56fdc520  movaps xmm10, xmm14
0000705c56fdc524  addpd xmm10, xmm4
0000705c56fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000705c56fdc52f  ptest xmm8, xmm8
0000705c56fdc535  jnz 0x0000705C56FDFE9E
0000705c56fdc53b  vmovaps xmm14, [rsp+0x40]
0000705c56fdc541  vpermilpd xmm14, xmm14, 0x00
0000705c56fdc547  movaps xmm8, xmm1
0000705c56fdc54b  mulpd xmm8, xmm14
0000705c56fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c56fdc556  ptest xmm6, xmm6
0000705c56fdc55b  jnz 0x0000705C56FDFFE1
0000705c56fdc561  movaps xmm1, [r15+0x2B0]
0000705c56fdc569  vmovaps xmm14, [rsp+0x40]
0000705c56fdc56f  vpermilpd xmm14, xmm14, 0x00
0000705c56fdc575  movaps xmm6, xmm1
0000705c56fdc578  mulpd xmm6, xmm14
0000705c56fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c56fdc582  ptest xmm5, xmm5
0000705c56fdc587  jnz 0x0000705C56FE0124
0000705c56fdc58d  vmovaps xmm1, [rsp+0x10]
0000705c56fdc593  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc599  movaps xmm14, xmm12
0000705c56fdc59d  mulpd xmm14, xmm1
0000705c56fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000705c56fdc5a8  ptest xmm5, xmm5
0000705c56fdc5ad  jnz 0x0000705C56FE0265
0000705c56fdc5b3  movaps xmm1, xmm13
0000705c56fdc5b7  addpd xmm1, xmm9
0000705c56fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c56fdc5c1  ptest xmm12, xmm12
0000705c56fdc5c7  jnz 0x0000705C56FE03A8
0000705c56fdc5cd  vmovaps xmm13, [rsp+0x10]
0000705c56fdc5d3  vpermilpd xmm13, xmm13, 0x00
0000705c56fdc5d9  movaps xmm12, xmm7
0000705c56fdc5dd  mulpd xmm12, xmm13
0000705c56fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c56fdc5e8  ptest xmm9, xmm9
0000705c56fdc5ee  jnz 0x0000705C56FE04EA
0000705c56fdc5f4  movaps xmm13, xmm15
0000705c56fdc5f8  addpd xmm13, xmm8
0000705c56fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000705c56fdc603  ptest xmm9, xmm9
0000705c56fdc609  jnz 0x0000705C56FE062D
0000705c56fdc60f  movaps xmm15, [r15+0x290]
0000705c56fdc617  vmovaps xmm9, [rsp+0x10]
0000705c56fdc61d  vpermilpd xmm9, xmm9, 0x00
0000705c56fdc623  movaps xmm8, xmm15
0000705c56fdc627  mulpd xmm8, xmm9
0000705c56fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c56fdc632  ptest xmm7, xmm7
0000705c56fdc637  jnz 0x0000705C56FE0771
0000705c56fdc63d  movaps xmm15, xmm11
0000705c56fdc641  addpd xmm15, xmm6
0000705c56fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c56fdc64c  ptest xmm9, xmm9
0000705c56fdc652  jnz 0x0000705C56FE08B5
0000705c56fdc658  movaps xmm11, [r15+0x1E0]
0000705c56fdc660  vmovaps xmm9, [rsp+0x10]
0000705c56fdc666  vpermilpd xmm9, xmm9, 0x00
0000705c56fdc66c  movaps xmm7, xmm11
0000705c56fdc670  mulpd xmm7, xmm9
0000705c56fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c56fdc67a  ptest xmm6, xmm6
0000705c56fdc67f  jnz 0x0000705C56FE09F8
0000705c56fdc685  movaps xmm11, xmm10
0000705c56fdc689  addpd xmm11, xmm14
0000705c56fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000705c56fdc694  ptest xmm9, xmm9
0000705c56fdc69a  jnz 0x0000705C56FE0B3A
0000705c56fdc6a0  lea r12, [rax+0x70]
0000705c56fdc6a4  movups xmm14, [r13+r12*1]
0000705c56fdc6aa  movaps [r15+0x240], xmm14
0000705c56fdc6b2  movaps xmm10, xmm1
0000705c56fdc6b6  addpd xmm10, xmm12
0000705c56fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000705c56fdc6c1  ptest xmm9, xmm9
0000705c56fdc6c7  jnz 0x0000705C56FE0C88
0000705c56fdc6cd  movaps [r15+0x170], xmm10
0000705c56fdc6d5  vmovaps xmm1, [rsp+0x20]
0000705c56fdc6db  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc6e1  movaps xmm12, xmm14
0000705c56fdc6e5  mulpd xmm12, xmm1
0000705c56fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c56fdc6f0  ptest xmm9, xmm9
0000705c56fdc6f6  jnz 0x0000705C56FE0DCB
0000705c56fdc6fc  vmovaps xmm1, [rsp+0x20]
0000705c56fdc702  vpermilpd xmm1, xmm1, 0x00
0000705c56fdc708  vmovaps xmm9, [rsp+0xB0]
0000705c56fdc711  movaps xmm14, xmm9
0000705c56fdc715  mulpd xmm14, xmm1
0000705c56fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c56fdc720  ptest xmm6, xmm6
0000705c56fdc725  jnz 0x0000705C56FE0F0E
0000705c56fdc72b  movaps [r15+0x180], xmm14
0000705c56fdc733  movaps xmm1, xmm13
0000705c56fdc737  addpd xmm1, xmm8
0000705c56fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000705c56fdc741  ptest xmm9, xmm9
0000705c56fdc747  jnz 0x0000705C56FE1051
0000705c56fdc74d  movaps [r15+0x210], xmm1
0000705c56fdc755  movups xmm13, [r13+rax*1]
0000705c56fdc75b  lea r12, [rax+0x10]
0000705c56fdc75f  movups xmm9, [r13+r12*1]
0000705c56fdc765  movaps [r15+0x230], xmm9
0000705c56fdc76d  movaps xmm8, xmm15
0000705c56fdc771  addpd xmm8, xmm7
0000705c56fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c56fdc77c  ptest xmm6, xmm6
0000705c56fdc781  jnz 0x0000705C56FE11A7
0000705c56fdc787  movaps [r15+0x130], xmm8
0000705c56fdc78f  vmovaps xmm15, [rsp+0x20]
0000705c56fdc795  vpermilpd xmm15, xmm15, 0x00
0000705c56fdc79b  movaps xmm7, xmm9
0000705c56fdc79f  mulpd xmm7, xmm15
0000705c56fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c56fdc7a9  ptest xmm6, xmm6
0000705c56fdc7ae  jnz 0x0000705C56FE12EA
0000705c56fdc7b4  movaps [r15+0x220], xmm7
0000705c56fdc7bc  vmovaps xmm15, [rsp+0x20]
0000705c56fdc7c2  vpermilpd xmm15, xmm15, 0x00
0000705c56fdc7c8  movaps xmm9, xmm13
0000705c56fdc7cc  mulpd xmm9, xmm15
0000705c56fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c56fdc7d7  ptest xmm6, xmm6
0000705c56fdc7dc  jnz 0x0000705C56FE142C
0000705c56fdc7e2  movaps xmm15, xmm11
0000705c56fdc7e6  addpd xmm15, xmm12
0000705c56fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c56fdc7f1  ptest xmm13, xmm13
0000705c56fdc7f7  jnz 0x0000705C56FE1570
0000705c56fdc7fd  movaps [r15+0x140], xmm15
0000705c56fdc805  movaps xmm13, xmm10
0000705c56fdc809  addpd xmm13, xmm14
0000705c56fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c56fdc814  ptest xmm12, xmm12
0000705c56fdc81a  jnz 0x0000705C56FE16B4
0000705c56fdc820  movaps [r15+0x150], xmm13
0000705c56fdc828  movaps xmm14, xmm1
0000705c56fdc82c  addpd xmm14, xmm7
0000705c56fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000705c56fdc837  ptest xmm12, xmm12
0000705c56fdc83d  jnz 0x0000705C56FE17F8
0000705c56fdc843  movaps [r15+0x160], xmm14
0000705c56fdc84b  movaps xmm1, xmm8
0000705c56fdc84f  addpd xmm1, xmm9
0000705c56fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c56fdc859  ptest xmm12, xmm12
0000705c56fdc85f  jnz 0x0000705C56FE193A
0000705c56fdc865  movaps [r15+0x120], xmm1
0000705c56fdc86d  movups [r13+r14*1], xmm15
0000705c56fdc873  lea rax, [r14+0x10]
0000705c56fdc877  movups [r13+rax*1], xmm13
0000705c56fdc87d  lea rax, [r14+0x20]
0000705c56fdc881  movups [r13+rax*1], xmm14
0000705c56fdc887  lea rax, [r14+0x30]
0000705c56fdc88b  movups [r13+rax*1], xmm1
0000705c56fdc891  mov eax, [r15+0x108]
0000705c56fdc898  sahf
0000705c56fdc899  jnz 0x0000705C56FDC8CB
0000705c56fdc89b  cmp dword ptr [r15+0x318], 0x00
0000705c56fdc8a3  jz 0x0000705C56FDB900
0000705c56fdc8a9  nop [rax+rax*1], ax
0000705c56fdc8b2  nop [rax+rax*1], eax
0000705c56fdc8ba  mov eax, 0x410444
0000705c56fdc8bf  mov [r15+0x100], rax
0000705c56fdc8c6  jmp 0x0000705C56DFE110
0000705c56fdc8cb  cmp dword ptr [r15+0x318], 0x00
0000705c56fdc8d3  jz 0x0000705C56FD57E0
0000705c56fdc8d9  nop [rax+rax*1], ax
0000705c56fdc8e2  nop [rax+rax*1], eax
0000705c56fdc8ea  mov eax, 0x410278
0000705c56fdc8ef  mov [r15+0x100], rax
0000705c56fdc8f6  jmp 0x0000705C56DFE110
0000705c56fdc8fb  int3
0000705c56fdc8fc  call 0x0000705C56EE27E0
0000705c56fdc901  jmp 0x0000705C56FDB9DF
0000705c56fdc906  call 0x0000705C56EE1570
0000705c56fdc90b  jmp 0x0000705C56FDB9E8
0000705c56fdc910  call 0x0000705C56EE27E0
0000705c56fdc915  jmp 0x0000705C56FDBA44
0000705c56fdc91a  call 0x0000705C56EE1570
0000705c56fdc91f  jmp 0x0000705C56FDBA4D
0000705c56fdc924  call 0x0000705C56EE27E0
0000705c56fdc929  jmp 0x0000705C56FDBA90
0000705c56fdc92e  call 0x0000705C56EE1570
0000705c56fdc933  jmp 0x0000705C56FDBA99
0000705c56fdc938  call 0x0000705C56E0DC20
0000705c56fdc93d  jmp 0x0000705C56FDBAD8
0000705c56fdc942  call 0x0000705C56ED59C0
0000705c56fdc947  jmp 0x0000705C56FDBAEB
0000705c56fdc94c  call 0x0000705C56EE0E30
0000705c56fdc951  jmp 0x0000705C56FDBB09
0000705c56fdc956  call 0x0000705C56EDFBC0
0000705c56fdc95b  jmp 0x0000705C56FDBB13
0000705c56fdc960  call 0x0000705C56EDE950
0000705c56fdc965  jmp 0x0000705C56FDBB1D
0000705c56fdc96a  sub rsp, 0x08
0000705c56fdc96e  push rax
0000705c56fdc96f  push rcx
0000705c56fdc970  push rdx
0000705c56fdc971  push rdi
0000705c56fdc972  push rsi
0000705c56fdc973  push r8
0000705c56fdc975  push r9
0000705c56fdc977  push r10
0000705c56fdc979  push r11
0000705c56fdc97b  sub rsp, 0xF0
0000705c56fdc982  vmovaps [rsp], xmm0
0000705c56fdc987  vmovaps [rsp+0x10], xmm1
0000705c56fdc98d  vmovaps [rsp+0x20], xmm2
0000705c56fdc993  vmovaps [rsp+0x30], xmm3
0000705c56fdc999  vmovaps [rsp+0x40], xmm4
0000705c56fdc99f  vmovaps [rsp+0x50], xmm5
0000705c56fdc9a5  vmovaps [rsp+0x60], xmm6
0000705c56fdc9ab  vmovaps [rsp+0x70], xmm7
0000705c56fdc9b1  vmovaps [rsp+0x80], xmm9
0000705c56fdc9ba  vmovaps [rsp+0x90], xmm10
0000705c56fdc9c3  vmovaps [rsp+0xA0], xmm11
0000705c56fdc9cc  vmovaps [rsp+0xB0], xmm12
0000705c56fdc9d5  vmovaps [rsp+0xC0], xmm13
0000705c56fdc9de  vmovaps [rsp+0xD0], xmm14
0000705c56fdc9e7  vmovaps [rsp+0xE0], xmm15
0000705c56fdc9f0  sub rsp, 0x30
0000705c56fdc9f4  movaps [rsp], xmm8
0000705c56fdc9f9  movaps [rsp+0x10], xmm12
0000705c56fdc9ff  movaps [rsp+0x20], xmm15
0000705c56fdca05  lea rdi, [rsp]
0000705c56fdca09  mov esi, 0x00
0000705c56fdca0e  mov rax, 0x5877D3629530
0000705c56fdca18  call rax
0000705c56fdca1a  movaps xmm8, [rsp]
0000705c56fdca1f  add rsp, 0x30
0000705c56fdca23  vmovaps xmm0, [rsp]
0000705c56fdca28  vmovaps xmm1, [rsp+0x10]
0000705c56fdca2e  vmovaps xmm2, [rsp+0x20]
0000705c56fdca34  vmovaps xmm3, [rsp+0x30]
0000705c56fdca3a  vmovaps xmm4, [rsp+0x40]
0000705c56fdca40  vmovaps xmm5, [rsp+0x50]
0000705c56fdca46  vmovaps xmm6, [rsp+0x60]
0000705c56fdca4c  vmovaps xmm7, [rsp+0x70]
0000705c56fdca52  vmovaps xmm9, [rsp+0x80]
0000705c56fdca5b  vmovaps xmm10, [rsp+0x90]
0000705c56fdca64  vmovaps xmm11, [rsp+0xA0]
0000705c56fdca6d  vmovaps xmm12, [rsp+0xB0]
0000705c56fdca76  vmovaps xmm13, [rsp+0xC0]
0000705c56fdca7f  vmovaps xmm14, [rsp+0xD0]
0000705c56fdca88  vmovaps xmm15, [rsp+0xE0]
0000705c56fdca91  add rsp, 0xF0
0000705c56fdca98  pop r11
0000705c56fdca9a  pop r10
0000705c56fdca9c  pop r9
0000705c56fdca9e  pop r8
0000705c56fdcaa0  pop rsi
0000705c56fdcaa1  pop rdi
0000705c56fdcaa2  pop rdx
0000705c56fdcaa3  pop rcx
0000705c56fdcaa4  pop rax
0000705c56fdcaa5  add rsp, 0x08
0000705c56fdcaa9  jmp 0x0000705C56FDBB47
0000705c56fdcaae  sub rsp, 0x08
0000705c56fdcab2  push rax
0000705c56fdcab3  push rcx
0000705c56fdcab4  push rdx
0000705c56fdcab5  push rdi
0000705c56fdcab6  push rsi
0000705c56fdcab7  push r8
0000705c56fdcab9  push r9
0000705c56fdcabb  push r10
0000705c56fdcabd  push r11
0000705c56fdcabf  sub rsp, 0xF0
0000705c56fdcac6  vmovaps [rsp], xmm0
0000705c56fdcacb  vmovaps [rsp+0x10], xmm1
0000705c56fdcad1  vmovaps [rsp+0x20], xmm2
0000705c56fdcad7  vmovaps [rsp+0x30], xmm3
0000705c56fdcadd  vmovaps [rsp+0x40], xmm4
0000705c56fdcae3  vmovaps [rsp+0x50], xmm5
0000705c56fdcae9  vmovaps [rsp+0x60], xmm6
0000705c56fdcaef  vmovaps [rsp+0x70], xmm8
0000705c56fdcaf5  vmovaps [rsp+0x80], xmm9
0000705c56fdcafe  vmovaps [rsp+0x90], xmm10
0000705c56fdcb07  vmovaps [rsp+0xA0], xmm11
0000705c56fdcb10  vmovaps [rsp+0xB0], xmm12
0000705c56fdcb19  vmovaps [rsp+0xC0], xmm13
0000705c56fdcb22  vmovaps [rsp+0xD0], xmm14
0000705c56fdcb2b  vmovaps [rsp+0xE0], xmm15
0000705c56fdcb34  sub rsp, 0x30
0000705c56fdcb38  movaps [rsp], xmm7
0000705c56fdcb3c  movaps [rsp+0x10], xmm9
0000705c56fdcb42  movaps [rsp+0x20], xmm15
0000705c56fdcb48  lea rdi, [rsp]
0000705c56fdcb4c  mov esi, 0x00
0000705c56fdcb51  mov rax, 0x5877D3629530
0000705c56fdcb5b  call rax
0000705c56fdcb5d  movaps xmm7, [rsp]
0000705c56fdcb61  add rsp, 0x30
0000705c56fdcb65  vmovaps xmm0, [rsp]
0000705c56fdcb6a  vmovaps xmm1, [rsp+0x10]
0000705c56fdcb70  vmovaps xmm2, [rsp+0x20]
0000705c56fdcb76  vmovaps xmm3, [rsp+0x30]
0000705c56fdcb7c  vmovaps xmm4, [rsp+0x40]
0000705c56fdcb82  vmovaps xmm5, [rsp+0x50]
0000705c56fdcb88  vmovaps xmm6, [rsp+0x60]
0000705c56fdcb8e  vmovaps xmm8, [rsp+0x70]
0000705c56fdcb94  vmovaps xmm9, [rsp+0x80]
0000705c56fdcb9d  vmovaps xmm10, [rsp+0x90]
0000705c56fdcba6  vmovaps xmm11, [rsp+0xA0]
0000705c56fdcbaf  vmovaps xmm12, [rsp+0xB0]
0000705c56fdcbb8  vmovaps xmm13, [rsp+0xC0]
0000705c56fdcbc1  vmovaps xmm14, [rsp+0xD0]
0000705c56fdcbca  vmovaps xmm15, [rsp+0xE0]
0000705c56fdcbd3  add rsp, 0xF0
0000705c56fdcbda  pop r11
0000705c56fdcbdc  pop r10
0000705c56fdcbde  pop r9
0000705c56fdcbe0  pop r8
0000705c56fdcbe2  pop rsi
0000705c56fdcbe3  pop rdi
0000705c56fdcbe4  pop rdx
0000705c56fdcbe5  pop rcx
0000705c56fdcbe6  pop rax
0000705c56fdcbe7  add rsp, 0x08
0000705c56fdcbeb  jmp 0x0000705C56FDBB75
0000705c56fdcbf0  sub rsp, 0x08
0000705c56fdcbf4  push rax
0000705c56fdcbf5  push rcx
0000705c56fdcbf6  push rdx
0000705c56fdcbf7  push rdi
0000705c56fdcbf8  push rsi
0000705c56fdcbf9  push r8
0000705c56fdcbfb  push r9
0000705c56fdcbfd  push r10
0000705c56fdcbff  push r11
0000705c56fdcc01  sub rsp, 0xF0
0000705c56fdcc08  vmovaps [rsp], xmm0
0000705c56fdcc0d  vmovaps [rsp+0x10], xmm1
0000705c56fdcc13  vmovaps [rsp+0x20], xmm2
0000705c56fdcc19  vmovaps [rsp+0x30], xmm3
0000705c56fdcc1f  vmovaps [rsp+0x40], xmm4
0000705c56fdcc25  vmovaps [rsp+0x50], xmm5
0000705c56fdcc2b  vmovaps [rsp+0x60], xmm6
0000705c56fdcc31  vmovaps [rsp+0x70], xmm7
0000705c56fdcc37  vmovaps [rsp+0x80], xmm8
0000705c56fdcc40  vmovaps [rsp+0x90], xmm10
0000705c56fdcc49  vmovaps [rsp+0xA0], xmm11
0000705c56fdcc52  vmovaps [rsp+0xB0], xmm12
0000705c56fdcc5b  vmovaps [rsp+0xC0], xmm13
0000705c56fdcc64  vmovaps [rsp+0xD0], xmm14
0000705c56fdcc6d  vmovaps [rsp+0xE0], xmm15
0000705c56fdcc76  sub rsp, 0x30
0000705c56fdcc7a  movaps [rsp], xmm9
0000705c56fdcc7f  movaps [rsp+0x10], xmm12
0000705c56fdcc85  movaps [rsp+0x20], xmm10
0000705c56fdcc8b  lea rdi, [rsp]
0000705c56fdcc8f  mov esi, 0x00
0000705c56fdcc94  mov rax, 0x5877D3629530
0000705c56fdcc9e  call rax
0000705c56fdcca0  movaps xmm9, [rsp]
0000705c56fdcca5  add rsp, 0x30
0000705c56fdcca9  vmovaps xmm0, [rsp]
0000705c56fdccae  vmovaps xmm1, [rsp+0x10]
0000705c56fdccb4  vmovaps xmm2, [rsp+0x20]
0000705c56fdccba  vmovaps xmm3, [rsp+0x30]
0000705c56fdccc0  vmovaps xmm4, [rsp+0x40]
0000705c56fdccc6  vmovaps xmm5, [rsp+0x50]
0000705c56fdcccc  vmovaps xmm6, [rsp+0x60]
0000705c56fdccd2  vmovaps xmm7, [rsp+0x70]
0000705c56fdccd8  vmovaps xmm8, [rsp+0x80]
0000705c56fdcce1  vmovaps xmm10, [rsp+0x90]
0000705c56fdccea  vmovaps xmm11, [rsp+0xA0]
0000705c56fdccf3  vmovaps xmm12, [rsp+0xB0]
0000705c56fdccfc  vmovaps xmm13, [rsp+0xC0]
0000705c56fdcd05  vmovaps xmm14, [rsp+0xD0]
0000705c56fdcd0e  vmovaps xmm15, [rsp+0xE0]
0000705c56fdcd17  add rsp, 0xF0
0000705c56fdcd1e  pop r11
0000705c56fdcd20  pop r10
0000705c56fdcd22  pop r9
0000705c56fdcd24  pop r8
0000705c56fdcd26  pop rsi
0000705c56fdcd27  pop rdi
0000705c56fdcd28  pop rdx
0000705c56fdcd29  pop rcx
0000705c56fdcd2a  pop rax
0000705c56fdcd2b  add rsp, 0x08
0000705c56fdcd2f  jmp 0x0000705C56FDBB99
0000705c56fdcd34  sub rsp, 0x08
0000705c56fdcd38  push rax
0000705c56fdcd39  push rcx
0000705c56fdcd3a  push rdx
0000705c56fdcd3b  push rdi
0000705c56fdcd3c  push rsi
0000705c56fdcd3d  push r8
0000705c56fdcd3f  push r9
0000705c56fdcd41  push r10
0000705c56fdcd43  push r11
0000705c56fdcd45  sub rsp, 0xF0
0000705c56fdcd4c  vmovaps [rsp], xmm0
0000705c56fdcd51  vmovaps [rsp+0x10], xmm1
0000705c56fdcd57  vmovaps [rsp+0x20], xmm2
0000705c56fdcd5d  vmovaps [rsp+0x30], xmm3
0000705c56fdcd63  vmovaps [rsp+0x40], xmm4
0000705c56fdcd69  vmovaps [rsp+0x50], xmm5
0000705c56fdcd6f  vmovaps [rsp+0x60], xmm6
0000705c56fdcd75  vmovaps [rsp+0x70], xmm7
0000705c56fdcd7b  vmovaps [rsp+0x80], xmm8
0000705c56fdcd84  vmovaps [rsp+0x90], xmm9
0000705c56fdcd8d  vmovaps [rsp+0xA0], xmm11
0000705c56fdcd96  vmovaps [rsp+0xB0], xmm12
0000705c56fdcd9f  vmovaps [rsp+0xC0], xmm13
0000705c56fdcda8  vmovaps [rsp+0xD0], xmm14
0000705c56fdcdb1  vmovaps [rsp+0xE0], xmm15
0000705c56fdcdba  sub rsp, 0x30
0000705c56fdcdbe  movaps [rsp], xmm10
0000705c56fdcdc3  movaps [rsp+0x10], xmm12
0000705c56fdcdc9  movaps [rsp+0x20], xmm11
0000705c56fdcdcf  lea rdi, [rsp]
0000705c56fdcdd3  mov esi, 0x00
0000705c56fdcdd8  mov rax, 0x5877D3629530
0000705c56fdcde2  call rax
0000705c56fdcde4  movaps xmm10, [rsp]
0000705c56fdcde9  add rsp, 0x30
0000705c56fdcded  vmovaps xmm0, [rsp]
0000705c56fdcdf2  vmovaps xmm1, [rsp+0x10]
0000705c56fdcdf8  vmovaps xmm2, [rsp+0x20]
0000705c56fdcdfe  vmovaps xmm3, [rsp+0x30]
0000705c56fdce04  vmovaps xmm4, [rsp+0x40]
0000705c56fdce0a  vmovaps xmm5, [rsp+0x50]
0000705c56fdce10  vmovaps xmm6, [rsp+0x60]
0000705c56fdce16  vmovaps xmm7, [rsp+0x70]
0000705c56fdce1c  vmovaps xmm8, [rsp+0x80]
0000705c56fdce25  vmovaps xmm9, [rsp+0x90]
0000705c56fdce2e  vmovaps xmm11, [rsp+0xA0]
0000705c56fdce37  vmovaps xmm12, [rsp+0xB0]
0000705c56fdce40  vmovaps xmm13, [rsp+0xC0]
0000705c56fdce49  vmovaps xmm14, [rsp+0xD0]
0000705c56fdce52  vmovaps xmm15, [rsp+0xE0]
0000705c56fdce5b  add rsp, 0xF0
0000705c56fdce62  pop r11
0000705c56fdce64  pop r10
0000705c56fdce66  pop r9
0000705c56fdce68  pop r8
0000705c56fdce6a  pop rsi
0000705c56fdce6b  pop rdi
0000705c56fdce6c  pop rdx
0000705c56fdce6d  pop rcx
0000705c56fdce6e  pop rax
0000705c56fdce6f  add rsp, 0x08
0000705c56fdce73  jmp 0x0000705C56FDBBB3
0000705c56fdce78  sub rsp, 0x08
0000705c56fdce7c  push rax
0000705c56fdce7d  push rcx
0000705c56fdce7e  push rdx
0000705c56fdce7f  push rdi
0000705c56fdce80  push rsi
0000705c56fdce81  push r8
0000705c56fdce83  push r9
0000705c56fdce85  push r10
0000705c56fdce87  push r11
0000705c56fdce89  sub rsp, 0xF0
0000705c56fdce90  vmovaps [rsp], xmm0
0000705c56fdce95  vmovaps [rsp+0x10], xmm1
0000705c56fdce9b  vmovaps [rsp+0x20], xmm2
0000705c56fdcea1  vmovaps [rsp+0x30], xmm3
0000705c56fdcea7  vmovaps [rsp+0x40], xmm4
0000705c56fdcead  vmovaps [rsp+0x50], xmm5
0000705c56fdceb3  vmovaps [rsp+0x60], xmm7
0000705c56fdceb9  vmovaps [rsp+0x70], xmm8
0000705c56fdcebf  vmovaps [rsp+0x80], xmm9
0000705c56fdcec8  vmovaps [rsp+0x90], xmm10
0000705c56fdced1  vmovaps [rsp+0xA0], xmm11
0000705c56fdceda  vmovaps [rsp+0xB0], xmm12
0000705c56fdcee3  vmovaps [rsp+0xC0], xmm13
0000705c56fdceec  vmovaps [rsp+0xD0], xmm14
0000705c56fdcef5  vmovaps [rsp+0xE0], xmm15
0000705c56fdcefe  sub rsp, 0x30
0000705c56fdcf02  movaps [rsp], xmm6
0000705c56fdcf06  movaps [rsp+0x10], xmm12
0000705c56fdcf0c  movaps [rsp+0x20], xmm11
0000705c56fdcf12  lea rdi, [rsp]
0000705c56fdcf16  mov esi, 0x00
0000705c56fdcf1b  mov rax, 0x5877D3629530
0000705c56fdcf25  call rax
0000705c56fdcf27  movaps xmm6, [rsp]
0000705c56fdcf2b  add rsp, 0x30
0000705c56fdcf2f  vmovaps xmm0, [rsp]
0000705c56fdcf34  vmovaps xmm1, [rsp+0x10]
0000705c56fdcf3a  vmovaps xmm2, [rsp+0x20]
0000705c56fdcf40  vmovaps xmm3, [rsp+0x30]
0000705c56fdcf46  vmovaps xmm4, [rsp+0x40]
0000705c56fdcf4c  vmovaps xmm5, [rsp+0x50]
0000705c56fdcf52  vmovaps xmm7, [rsp+0x60]
0000705c56fdcf58  vmovaps xmm8, [rsp+0x70]
0000705c56fdcf5e  vmovaps xmm9, [rsp+0x80]
0000705c56fdcf67  vmovaps xmm10, [rsp+0x90]
0000705c56fdcf70  vmovaps xmm11, [rsp+0xA0]
0000705c56fdcf79  vmovaps xmm12, [rsp+0xB0]
0000705c56fdcf82  vmovaps xmm13, [rsp+0xC0]
0000705c56fdcf8b  vmovaps xmm14, [rsp+0xD0]
0000705c56fdcf94  vmovaps xmm15, [rsp+0xE0]
0000705c56fdcf9d  add rsp, 0xF0
0000705c56fdcfa4  pop r11
0000705c56fdcfa6  pop r10
0000705c56fdcfa8  pop r9
0000705c56fdcfaa  pop r8
0000705c56fdcfac  pop rsi
0000705c56fdcfad  pop rdi
0000705c56fdcfae  pop rdx
0000705c56fdcfaf  pop rcx
0000705c56fdcfb0  pop rax
0000705c56fdcfb1  add rsp, 0x08
0000705c56fdcfb5  jmp 0x0000705C56FDBBD4
0000705c56fdcfba  sub rsp, 0x08
0000705c56fdcfbe  push rax
0000705c56fdcfbf  push rcx
0000705c56fdcfc0  push rdx
0000705c56fdcfc1  push rdi
0000705c56fdcfc2  push rsi
0000705c56fdcfc3  push r8
0000705c56fdcfc5  push r9
0000705c56fdcfc7  push r10
0000705c56fdcfc9  push r11
0000705c56fdcfcb  sub rsp, 0xF0
0000705c56fdcfd2  vmovaps [rsp], xmm0
0000705c56fdcfd7  vmovaps [rsp+0x10], xmm1
0000705c56fdcfdd  vmovaps [rsp+0x20], xmm2
0000705c56fdcfe3  vmovaps [rsp+0x30], xmm4
0000705c56fdcfe9  vmovaps [rsp+0x40], xmm5
0000705c56fdcfef  vmovaps [rsp+0x50], xmm6
0000705c56fdcff5  vmovaps [rsp+0x60], xmm7
0000705c56fdcffb  vmovaps [rsp+0x70], xmm8
0000705c56fdd001  vmovaps [rsp+0x80], xmm9
0000705c56fdd00a  vmovaps [rsp+0x90], xmm10
0000705c56fdd013  vmovaps [rsp+0xA0], xmm11
0000705c56fdd01c  vmovaps [rsp+0xB0], xmm12
0000705c56fdd025  vmovaps [rsp+0xC0], xmm13
0000705c56fdd02e  vmovaps [rsp+0xD0], xmm14
0000705c56fdd037  vmovaps [rsp+0xE0], xmm15
0000705c56fdd040  sub rsp, 0x30
0000705c56fdd044  movaps [rsp], xmm3
0000705c56fdd048  movaps [rsp+0x10], xmm5
0000705c56fdd04d  movaps [rsp+0x20], xmm4
0000705c56fdd052  lea rdi, [rsp]
0000705c56fdd056  mov esi, 0x00
0000705c56fdd05b  mov rax, 0x5877D3629530
0000705c56fdd065  call rax
0000705c56fdd067  movaps xmm3, [rsp]
0000705c56fdd06b  add rsp, 0x30
0000705c56fdd06f  vmovaps xmm0, [rsp]
0000705c56fdd074  vmovaps xmm1, [rsp+0x10]
0000705c56fdd07a  vmovaps xmm2, [rsp+0x20]
0000705c56fdd080  vmovaps xmm4, [rsp+0x30]
0000705c56fdd086  vmovaps xmm5, [rsp+0x40]
0000705c56fdd08c  vmovaps xmm6, [rsp+0x50]
0000705c56fdd092  vmovaps xmm7, [rsp+0x60]
0000705c56fdd098  vmovaps xmm8, [rsp+0x70]
0000705c56fdd09e  vmovaps xmm9, [rsp+0x80]
0000705c56fdd0a7  vmovaps xmm10, [rsp+0x90]
0000705c56fdd0b0  vmovaps xmm11, [rsp+0xA0]
0000705c56fdd0b9  vmovaps xmm12, [rsp+0xB0]
0000705c56fdd0c2  vmovaps xmm13, [rsp+0xC0]
0000705c56fdd0cb  vmovaps xmm14, [rsp+0xD0]
0000705c56fdd0d4  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd0dd  add rsp, 0xF0
0000705c56fdd0e4  pop r11
0000705c56fdd0e6  pop r10
0000705c56fdd0e8  pop r9
0000705c56fdd0ea  pop r8
0000705c56fdd0ec  pop rsi
0000705c56fdd0ed  pop rdi
0000705c56fdd0ee  pop rdx
0000705c56fdd0ef  pop rcx
0000705c56fdd0f0  pop rax
0000705c56fdd0f1  add rsp, 0x08
0000705c56fdd0f5  jmp 0x0000705C56FDBC35
0000705c56fdd0fa  sub rsp, 0x08
0000705c56fdd0fe  push rax
0000705c56fdd0ff  push rcx
0000705c56fdd100  push rdx
0000705c56fdd101  push rdi
0000705c56fdd102  push rsi
0000705c56fdd103  push r8
0000705c56fdd105  push r9
0000705c56fdd107  push r10
0000705c56fdd109  push r11
0000705c56fdd10b  sub rsp, 0xF0
0000705c56fdd112  vmovaps [rsp], xmm0
0000705c56fdd117  vmovaps [rsp+0x10], xmm1
0000705c56fdd11d  vmovaps [rsp+0x20], xmm2
0000705c56fdd123  vmovaps [rsp+0x30], xmm3
0000705c56fdd129  vmovaps [rsp+0x40], xmm4
0000705c56fdd12f  vmovaps [rsp+0x50], xmm6
0000705c56fdd135  vmovaps [rsp+0x60], xmm7
0000705c56fdd13b  vmovaps [rsp+0x70], xmm8
0000705c56fdd141  vmovaps [rsp+0x80], xmm9
0000705c56fdd14a  vmovaps [rsp+0x90], xmm10
0000705c56fdd153  vmovaps [rsp+0xA0], xmm11
0000705c56fdd15c  vmovaps [rsp+0xB0], xmm12
0000705c56fdd165  vmovaps [rsp+0xC0], xmm13
0000705c56fdd16e  vmovaps [rsp+0xD0], xmm14
0000705c56fdd177  vmovaps [rsp+0xE0], xmm15
0000705c56fdd180  sub rsp, 0x30
0000705c56fdd184  movaps [rsp], xmm5
0000705c56fdd188  movaps [rsp+0x10], xmm8
0000705c56fdd18e  movaps [rsp+0x20], xmm15
0000705c56fdd194  lea rdi, [rsp]
0000705c56fdd198  mov esi, 0x00
0000705c56fdd19d  mov rax, 0x5877D3629530
0000705c56fdd1a7  call rax
0000705c56fdd1a9  movaps xmm5, [rsp]
0000705c56fdd1ad  add rsp, 0x30
0000705c56fdd1b1  vmovaps xmm0, [rsp]
0000705c56fdd1b6  vmovaps xmm1, [rsp+0x10]
0000705c56fdd1bc  vmovaps xmm2, [rsp+0x20]
0000705c56fdd1c2  vmovaps xmm3, [rsp+0x30]
0000705c56fdd1c8  vmovaps xmm4, [rsp+0x40]
0000705c56fdd1ce  vmovaps xmm6, [rsp+0x50]
0000705c56fdd1d4  vmovaps xmm7, [rsp+0x60]
0000705c56fdd1da  vmovaps xmm8, [rsp+0x70]
0000705c56fdd1e0  vmovaps xmm9, [rsp+0x80]
0000705c56fdd1e9  vmovaps xmm10, [rsp+0x90]
0000705c56fdd1f2  vmovaps xmm11, [rsp+0xA0]
0000705c56fdd1fb  vmovaps xmm12, [rsp+0xB0]
0000705c56fdd204  vmovaps xmm13, [rsp+0xC0]
0000705c56fdd20d  vmovaps xmm14, [rsp+0xD0]
0000705c56fdd216  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd21f  add rsp, 0xF0
0000705c56fdd226  pop r11
0000705c56fdd228  pop r10
0000705c56fdd22a  pop r9
0000705c56fdd22c  pop r8
0000705c56fdd22e  pop rsi
0000705c56fdd22f  pop rdi
0000705c56fdd230  pop rdx
0000705c56fdd231  pop rcx
0000705c56fdd232  pop rax
0000705c56fdd233  add rsp, 0x08
0000705c56fdd237  jmp 0x0000705C56FDBC73
0000705c56fdd23c  sub rsp, 0x08
0000705c56fdd240  push rax
0000705c56fdd241  push rcx
0000705c56fdd242  push rdx
0000705c56fdd243  push rdi
0000705c56fdd244  push rsi
0000705c56fdd245  push r8
0000705c56fdd247  push r9
0000705c56fdd249  push r10
0000705c56fdd24b  push r11
0000705c56fdd24d  sub rsp, 0xF0
0000705c56fdd254  vmovaps [rsp], xmm0
0000705c56fdd259  vmovaps [rsp+0x10], xmm1
0000705c56fdd25f  vmovaps [rsp+0x20], xmm2
0000705c56fdd265  vmovaps [rsp+0x30], xmm3
0000705c56fdd26b  vmovaps [rsp+0x40], xmm5
0000705c56fdd271  vmovaps [rsp+0x50], xmm6
0000705c56fdd277  vmovaps [rsp+0x60], xmm7
0000705c56fdd27d  vmovaps [rsp+0x70], xmm8
0000705c56fdd283  vmovaps [rsp+0x80], xmm9
0000705c56fdd28c  vmovaps [rsp+0x90], xmm10
0000705c56fdd295  vmovaps [rsp+0xA0], xmm11
0000705c56fdd29e  vmovaps [rsp+0xB0], xmm12
0000705c56fdd2a7  vmovaps [rsp+0xC0], xmm13
0000705c56fdd2b0  vmovaps [rsp+0xD0], xmm14
0000705c56fdd2b9  vmovaps [rsp+0xE0], xmm15
0000705c56fdd2c2  sub rsp, 0x30
0000705c56fdd2c6  movaps [rsp], xmm4
0000705c56fdd2ca  movaps [rsp+0x10], xmm9
0000705c56fdd2d0  movaps [rsp+0x20], xmm8
0000705c56fdd2d6  lea rdi, [rsp]
0000705c56fdd2da  mov esi, 0x00
0000705c56fdd2df  mov rax, 0x5877D3629530
0000705c56fdd2e9  call rax
0000705c56fdd2eb  movaps xmm4, [rsp]
0000705c56fdd2ef  add rsp, 0x30
0000705c56fdd2f3  vmovaps xmm0, [rsp]
0000705c56fdd2f8  vmovaps xmm1, [rsp+0x10]
0000705c56fdd2fe  vmovaps xmm2, [rsp+0x20]
0000705c56fdd304  vmovaps xmm3, [rsp+0x30]
0000705c56fdd30a  vmovaps xmm5, [rsp+0x40]
0000705c56fdd310  vmovaps xmm6, [rsp+0x50]
0000705c56fdd316  vmovaps xmm7, [rsp+0x60]
0000705c56fdd31c  vmovaps xmm8, [rsp+0x70]
0000705c56fdd322  vmovaps xmm9, [rsp+0x80]
0000705c56fdd32b  vmovaps xmm10, [rsp+0x90]
0000705c56fdd334  vmovaps xmm11, [rsp+0xA0]
0000705c56fdd33d  vmovaps xmm12, [rsp+0xB0]
0000705c56fdd346  vmovaps xmm13, [rsp+0xC0]
0000705c56fdd34f  vmovaps xmm14, [rsp+0xD0]
0000705c56fdd358  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd361  add rsp, 0xF0
0000705c56fdd368  pop r11
0000705c56fdd36a  pop r10
0000705c56fdd36c  pop r9
0000705c56fdd36e  pop r8
0000705c56fdd370  pop rsi
0000705c56fdd371  pop rdi
0000705c56fdd372  pop rdx
0000705c56fdd373  pop rcx
0000705c56fdd374  pop rax
0000705c56fdd375  add rsp, 0x08
0000705c56fdd379  jmp 0x0000705C56FDBC94
0000705c56fdd37e  sub rsp, 0x08
0000705c56fdd382  push rax
0000705c56fdd383  push rcx
0000705c56fdd384  push rdx
0000705c56fdd385  push rdi
0000705c56fdd386  push rsi
0000705c56fdd387  push r8
0000705c56fdd389  push r9
0000705c56fdd38b  push r10
0000705c56fdd38d  push r11
0000705c56fdd38f  sub rsp, 0xF0
0000705c56fdd396  vmovaps [rsp], xmm0
0000705c56fdd39b  vmovaps [rsp+0x10], xmm1
0000705c56fdd3a1  vmovaps [rsp+0x20], xmm2
0000705c56fdd3a7  vmovaps [rsp+0x30], xmm3
0000705c56fdd3ad  vmovaps [rsp+0x40], xmm4
0000705c56fdd3b3  vmovaps [rsp+0x50], xmm5
0000705c56fdd3b9  vmovaps [rsp+0x60], xmm6
0000705c56fdd3bf  vmovaps [rsp+0x70], xmm7
0000705c56fdd3c5  vmovaps [rsp+0x80], xmm8
0000705c56fdd3ce  vmovaps [rsp+0x90], xmm10
0000705c56fdd3d7  vmovaps [rsp+0xA0], xmm11
0000705c56fdd3e0  vmovaps [rsp+0xB0], xmm12
0000705c56fdd3e9  vmovaps [rsp+0xC0], xmm13
0000705c56fdd3f2  vmovaps [rsp+0xD0], xmm14
0000705c56fdd3fb  vmovaps [rsp+0xE0], xmm15
0000705c56fdd404  sub rsp, 0x30
0000705c56fdd408  movaps [rsp], xmm9
0000705c56fdd40d  movaps [rsp+0x10], xmm10
0000705c56fdd413  movaps [rsp+0x20], xmm8
0000705c56fdd419  lea rdi, [rsp]
0000705c56fdd41d  mov esi, 0x00
0000705c56fdd422  mov rax, 0x5877D3629530
0000705c56fdd42c  call rax
0000705c56fdd42e  movaps xmm9, [rsp]
0000705c56fdd433  add rsp, 0x30
0000705c56fdd437  vmovaps xmm0, [rsp]
0000705c56fdd43c  vmovaps xmm1, [rsp+0x10]
0000705c56fdd442  vmovaps xmm2, [rsp+0x20]
0000705c56fdd448  vmovaps xmm3, [rsp+0x30]
0000705c56fdd44e  vmovaps xmm4, [rsp+0x40]
0000705c56fdd454  vmovaps xmm5, [rsp+0x50]
0000705c56fdd45a  vmovaps xmm6, [rsp+0x60]
0000705c56fdd460  vmovaps xmm7, [rsp+0x70]
0000705c56fdd466  vmovaps xmm8, [rsp+0x80]
0000705c56fdd46f  vmovaps xmm10, [rsp+0x90]
0000705c56fdd478  vmovaps xmm11, [rsp+0xA0]
0000705c56fdd481  vmovaps xmm12, [rsp+0xB0]
0000705c56fdd48a  vmovaps xmm13, [rsp+0xC0]
0000705c56fdd493  vmovaps xmm14, [rsp+0xD0]
0000705c56fdd49c  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd4a5  add rsp, 0xF0
0000705c56fdd4ac  pop r11
0000705c56fdd4ae  pop r10
0000705c56fdd4b0  pop r9
0000705c56fdd4b2  pop r8
0000705c56fdd4b4  pop rsi
0000705c56fdd4b5  pop rdi
0000705c56fdd4b6  pop rdx
0000705c56fdd4b7  pop rcx
0000705c56fdd4b8  pop rax
0000705c56fdd4b9  add rsp, 0x08
0000705c56fdd4bd  jmp 0x0000705C56FDBCAE
0000705c56fdd4c2  call 0x0000705C56EB52F0
0000705c56fdd4c7  jmp 0x0000705C56FDBDC8
0000705c56fdd4cc  call 0x0000705C56EB52F0
0000705c56fdd4d1  jmp 0x0000705C56FDBDDE
0000705c56fdd4d6  sub rsp, 0x08
0000705c56fdd4da  push rax
0000705c56fdd4db  push rcx
0000705c56fdd4dc  push rdx
0000705c56fdd4dd  push rdi
0000705c56fdd4de  push rsi
0000705c56fdd4df  push r8
0000705c56fdd4e1  push r9
0000705c56fdd4e3  push r10
0000705c56fdd4e5  push r11
0000705c56fdd4e7  sub rsp, 0xF0
0000705c56fdd4ee  vmovaps [rsp], xmm0
0000705c56fdd4f3  vmovaps [rsp+0x10], xmm2
0000705c56fdd4f9  vmovaps [rsp+0x20], xmm3
0000705c56fdd4ff  vmovaps [rsp+0x30], xmm4
0000705c56fdd505  vmovaps [rsp+0x40], xmm5
0000705c56fdd50b  vmovaps [rsp+0x50], xmm6
0000705c56fdd511  vmovaps [rsp+0x60], xmm7
0000705c56fdd517  vmovaps [rsp+0x70], xmm8
0000705c56fdd51d  vmovaps [rsp+0x80], xmm9
0000705c56fdd526  vmovaps [rsp+0x90], xmm10
0000705c56fdd52f  vmovaps [rsp+0xA0], xmm11
0000705c56fdd538  vmovaps [rsp+0xB0], xmm12
0000705c56fdd541  vmovaps [rsp+0xC0], xmm13
0000705c56fdd54a  vmovaps [rsp+0xD0], xmm14
0000705c56fdd553  vmovaps [rsp+0xE0], xmm15
0000705c56fdd55c  sub rsp, 0x30
0000705c56fdd560  movaps [rsp], xmm1
0000705c56fdd564  movaps [rsp+0x10], xmm6
0000705c56fdd569  movaps [rsp+0x20], xmm15
0000705c56fdd56f  lea rdi, [rsp]
0000705c56fdd573  mov esi, 0x00
0000705c56fdd578  mov rax, 0x5877D3629530
0000705c56fdd582  call rax
0000705c56fdd584  movaps xmm1, [rsp]
0000705c56fdd588  add rsp, 0x30
0000705c56fdd58c  vmovaps xmm0, [rsp]
0000705c56fdd591  vmovaps xmm2, [rsp+0x10]
0000705c56fdd597  vmovaps xmm3, [rsp+0x20]
0000705c56fdd59d  vmovaps xmm4, [rsp+0x30]
0000705c56fdd5a3  vmovaps xmm5, [rsp+0x40]
0000705c56fdd5a9  vmovaps xmm6, [rsp+0x50]
0000705c56fdd5af  vmovaps xmm7, [rsp+0x60]
0000705c56fdd5b5  vmovaps xmm8, [rsp+0x70]
0000705c56fdd5bb  vmovaps xmm9, [rsp+0x80]
0000705c56fdd5c4  vmovaps xmm10, [rsp+0x90]
0000705c56fdd5cd  vmovaps xmm11, [rsp+0xA0]
0000705c56fdd5d6  vmovaps xmm12, [rsp+0xB0]
0000705c56fdd5df  vmovaps xmm13, [rsp+0xC0]
0000705c56fdd5e8  vmovaps xmm14, [rsp+0xD0]
0000705c56fdd5f1  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd5fa  add rsp, 0xF0
0000705c56fdd601  pop r11
0000705c56fdd603  pop r10
0000705c56fdd605  pop r9
0000705c56fdd607  pop r8
0000705c56fdd609  pop rsi
0000705c56fdd60a  pop rdi
0000705c56fdd60b  pop rdx
0000705c56fdd60c  pop rcx
0000705c56fdd60d  pop rax
0000705c56fdd60e  add rsp, 0x08
0000705c56fdd612  jmp 0x0000705C56FDBE1B
0000705c56fdd617  call 0x0000705C56EC4620
0000705c56fdd61c  jmp 0x0000705C56FDBE28
0000705c56fdd621  sub rsp, 0x08
0000705c56fdd625  push rax
0000705c56fdd626  push rcx
0000705c56fdd627  push rdx
0000705c56fdd628  push rdi
0000705c56fdd629  push rsi
0000705c56fdd62a  push r8
0000705c56fdd62c  push r9
0000705c56fdd62e  push r10
0000705c56fdd630  push r11
0000705c56fdd632  sub rsp, 0xF0
0000705c56fdd639  vmovaps [rsp], xmm0
0000705c56fdd63e  vmovaps [rsp+0x10], xmm1
0000705c56fdd644  vmovaps [rsp+0x20], xmm2
0000705c56fdd64a  vmovaps [rsp+0x30], xmm3
0000705c56fdd650  vmovaps [rsp+0x40], xmm4
0000705c56fdd656  vmovaps [rsp+0x50], xmm5
0000705c56fdd65c  vmovaps [rsp+0x60], xmm6
0000705c56fdd662  vmovaps [rsp+0x70], xmm7
0000705c56fdd668  vmovaps [rsp+0x80], xmm8
0000705c56fdd671  vmovaps [rsp+0x90], xmm9
0000705c56fdd67a  vmovaps [rsp+0xA0], xmm10
0000705c56fdd683  vmovaps [rsp+0xB0], xmm11
0000705c56fdd68c  vmovaps [rsp+0xC0], xmm12
0000705c56fdd695  vmovaps [rsp+0xD0], xmm13
0000705c56fdd69e  vmovaps [rsp+0xE0], xmm15
0000705c56fdd6a7  sub rsp, 0x30
0000705c56fdd6ab  movaps [rsp], xmm14
0000705c56fdd6b0  movaps [rsp+0x10], xmm4
0000705c56fdd6b5  movaps [rsp+0x20], xmm3
0000705c56fdd6ba  lea rdi, [rsp]
0000705c56fdd6be  mov esi, 0x00
0000705c56fdd6c3  mov rax, 0x5877D3629530
0000705c56fdd6cd  call rax
0000705c56fdd6cf  movaps xmm14, [rsp]
0000705c56fdd6d4  add rsp, 0x30
0000705c56fdd6d8  vmovaps xmm0, [rsp]
0000705c56fdd6dd  vmovaps xmm1, [rsp+0x10]
0000705c56fdd6e3  vmovaps xmm2, [rsp+0x20]
0000705c56fdd6e9  vmovaps xmm3, [rsp+0x30]
0000705c56fdd6ef  vmovaps xmm4, [rsp+0x40]
0000705c56fdd6f5  vmovaps xmm5, [rsp+0x50]
0000705c56fdd6fb  vmovaps xmm6, [rsp+0x60]
0000705c56fdd701  vmovaps xmm7, [rsp+0x70]
0000705c56fdd707  vmovaps xmm8, [rsp+0x80]
0000705c56fdd710  vmovaps xmm9, [rsp+0x90]
0000705c56fdd719  vmovaps xmm10, [rsp+0xA0]
0000705c56fdd722  vmovaps xmm11, [rsp+0xB0]
0000705c56fdd72b  vmovaps xmm12, [rsp+0xC0]
0000705c56fdd734  vmovaps xmm13, [rsp+0xD0]
0000705c56fdd73d  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd746  add rsp, 0xF0
0000705c56fdd74d  pop r11
0000705c56fdd74f  pop r10
0000705c56fdd751  pop r9
0000705c56fdd753  pop r8
0000705c56fdd755  pop rsi
0000705c56fdd756  pop rdi
0000705c56fdd757  pop rdx
0000705c56fdd758  pop rcx
0000705c56fdd759  pop rax
0000705c56fdd75a  add rsp, 0x08
0000705c56fdd75e  jmp 0x0000705C56FDBE42
0000705c56fdd763  sub rsp, 0x08
0000705c56fdd767  push rax
0000705c56fdd768  push rcx
0000705c56fdd769  push rdx
0000705c56fdd76a  push rdi
0000705c56fdd76b  push rsi
0000705c56fdd76c  push r8
0000705c56fdd76e  push r9
0000705c56fdd770  push r10
0000705c56fdd772  push r11
0000705c56fdd774  sub rsp, 0xF0
0000705c56fdd77b  vmovaps [rsp], xmm0
0000705c56fdd780  vmovaps [rsp+0x10], xmm1
0000705c56fdd786  vmovaps [rsp+0x20], xmm2
0000705c56fdd78c  vmovaps [rsp+0x30], xmm3
0000705c56fdd792  vmovaps [rsp+0x40], xmm4
0000705c56fdd798  vmovaps [rsp+0x50], xmm5
0000705c56fdd79e  vmovaps [rsp+0x60], xmm7
0000705c56fdd7a4  vmovaps [rsp+0x70], xmm8
0000705c56fdd7aa  vmovaps [rsp+0x80], xmm9
0000705c56fdd7b3  vmovaps [rsp+0x90], xmm10
0000705c56fdd7bc  vmovaps [rsp+0xA0], xmm11
0000705c56fdd7c5  vmovaps [rsp+0xB0], xmm12
0000705c56fdd7ce  vmovaps [rsp+0xC0], xmm13
0000705c56fdd7d7  vmovaps [rsp+0xD0], xmm14
0000705c56fdd7e0  vmovaps [rsp+0xE0], xmm15
0000705c56fdd7e9  sub rsp, 0x30
0000705c56fdd7ed  movaps [rsp], xmm6
0000705c56fdd7f1  movaps [rsp+0x10], xmm9
0000705c56fdd7f7  movaps [rsp+0x20], xmm7
0000705c56fdd7fc  lea rdi, [rsp]
0000705c56fdd800  mov esi, 0x00
0000705c56fdd805  mov rax, 0x5877D3629530
0000705c56fdd80f  call rax
0000705c56fdd811  movaps xmm6, [rsp]
0000705c56fdd815  add rsp, 0x30
0000705c56fdd819  vmovaps xmm0, [rsp]
0000705c56fdd81e  vmovaps xmm1, [rsp+0x10]
0000705c56fdd824  vmovaps xmm2, [rsp+0x20]
0000705c56fdd82a  vmovaps xmm3, [rsp+0x30]
0000705c56fdd830  vmovaps xmm4, [rsp+0x40]
0000705c56fdd836  vmovaps xmm5, [rsp+0x50]
0000705c56fdd83c  vmovaps xmm7, [rsp+0x60]
0000705c56fdd842  vmovaps xmm8, [rsp+0x70]
0000705c56fdd848  vmovaps xmm9, [rsp+0x80]
0000705c56fdd851  vmovaps xmm10, [rsp+0x90]
0000705c56fdd85a  vmovaps xmm11, [rsp+0xA0]
0000705c56fdd863  vmovaps xmm12, [rsp+0xB0]
0000705c56fdd86c  vmovaps xmm13, [rsp+0xC0]
0000705c56fdd875  vmovaps xmm14, [rsp+0xD0]
0000705c56fdd87e  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd887  add rsp, 0xF0
0000705c56fdd88e  pop r11
0000705c56fdd890  pop r10
0000705c56fdd892  pop r9
0000705c56fdd894  pop r8
0000705c56fdd896  pop rsi
0000705c56fdd897  pop rdi
0000705c56fdd898  pop rdx
0000705c56fdd899  pop rcx
0000705c56fdd89a  pop rax
0000705c56fdd89b  add rsp, 0x08
0000705c56fdd89f  jmp 0x0000705C56FDBE5A
0000705c56fdd8a4  sub rsp, 0x08
0000705c56fdd8a8  push rax
0000705c56fdd8a9  push rcx
0000705c56fdd8aa  push rdx
0000705c56fdd8ab  push rdi
0000705c56fdd8ac  push rsi
0000705c56fdd8ad  push r8
0000705c56fdd8af  push r9
0000705c56fdd8b1  push r10
0000705c56fdd8b3  push r11
0000705c56fdd8b5  sub rsp, 0xF0
0000705c56fdd8bc  vmovaps [rsp], xmm0
0000705c56fdd8c1  vmovaps [rsp+0x10], xmm1
0000705c56fdd8c7  vmovaps [rsp+0x20], xmm2
0000705c56fdd8cd  vmovaps [rsp+0x30], xmm3
0000705c56fdd8d3  vmovaps [rsp+0x40], xmm4
0000705c56fdd8d9  vmovaps [rsp+0x50], xmm5
0000705c56fdd8df  vmovaps [rsp+0x60], xmm6
0000705c56fdd8e5  vmovaps [rsp+0x70], xmm8
0000705c56fdd8eb  vmovaps [rsp+0x80], xmm9
0000705c56fdd8f4  vmovaps [rsp+0x90], xmm10
0000705c56fdd8fd  vmovaps [rsp+0xA0], xmm11
0000705c56fdd906  vmovaps [rsp+0xB0], xmm12
0000705c56fdd90f  vmovaps [rsp+0xC0], xmm13
0000705c56fdd918  vmovaps [rsp+0xD0], xmm14
0000705c56fdd921  vmovaps [rsp+0xE0], xmm15
0000705c56fdd92a  sub rsp, 0x30
0000705c56fdd92e  movaps [rsp], xmm7
0000705c56fdd932  movaps [rsp+0x10], xmm4
0000705c56fdd937  movaps [rsp+0x20], xmm9
0000705c56fdd93d  lea rdi, [rsp]
0000705c56fdd941  mov esi, 0x00
0000705c56fdd946  mov rax, 0x5877D3629530
0000705c56fdd950  call rax
0000705c56fdd952  movaps xmm7, [rsp]
0000705c56fdd956  add rsp, 0x30
0000705c56fdd95a  vmovaps xmm0, [rsp]
0000705c56fdd95f  vmovaps xmm1, [rsp+0x10]
0000705c56fdd965  vmovaps xmm2, [rsp+0x20]
0000705c56fdd96b  vmovaps xmm3, [rsp+0x30]
0000705c56fdd971  vmovaps xmm4, [rsp+0x40]
0000705c56fdd977  vmovaps xmm5, [rsp+0x50]
0000705c56fdd97d  vmovaps xmm6, [rsp+0x60]
0000705c56fdd983  vmovaps xmm8, [rsp+0x70]
0000705c56fdd989  vmovaps xmm9, [rsp+0x80]
0000705c56fdd992  vmovaps xmm10, [rsp+0x90]
0000705c56fdd99b  vmovaps xmm11, [rsp+0xA0]
0000705c56fdd9a4  vmovaps xmm12, [rsp+0xB0]
0000705c56fdd9ad  vmovaps xmm13, [rsp+0xC0]
0000705c56fdd9b6  vmovaps xmm14, [rsp+0xD0]
0000705c56fdd9bf  vmovaps xmm15, [rsp+0xE0]
0000705c56fdd9c8  add rsp, 0xF0
0000705c56fdd9cf  pop r11
0000705c56fdd9d1  pop r10
0000705c56fdd9d3  pop r9
0000705c56fdd9d5  pop r8
0000705c56fdd9d7  pop rsi
0000705c56fdd9d8  pop rdi
0000705c56fdd9d9  pop rdx
0000705c56fdd9da  pop rcx
0000705c56fdd9db  pop rax
0000705c56fdd9dc  add rsp, 0x08
0000705c56fdd9e0  jmp 0x0000705C56FDBE87
0000705c56fdd9e5  sub rsp, 0x08
0000705c56fdd9e9  push rax
0000705c56fdd9ea  push rcx
0000705c56fdd9eb  push rdx
0000705c56fdd9ec  push rdi
0000705c56fdd9ed  push rsi
0000705c56fdd9ee  push r8
0000705c56fdd9f0  push r9
0000705c56fdd9f2  push r10
0000705c56fdd9f4  push r11
0000705c56fdd9f6  sub rsp, 0xF0
0000705c56fdd9fd  vmovaps [rsp], xmm0
0000705c56fdda02  vmovaps [rsp+0x10], xmm1
0000705c56fdda08  vmovaps [rsp+0x20], xmm2
0000705c56fdda0e  vmovaps [rsp+0x30], xmm3
0000705c56fdda14  vmovaps [rsp+0x40], xmm5
0000705c56fdda1a  vmovaps [rsp+0x50], xmm6
0000705c56fdda20  vmovaps [rsp+0x60], xmm7
0000705c56fdda26  vmovaps [rsp+0x70], xmm8
0000705c56fdda2c  vmovaps [rsp+0x80], xmm9
0000705c56fdda35  vmovaps [rsp+0x90], xmm10
0000705c56fdda3e  vmovaps [rsp+0xA0], xmm11
0000705c56fdda47  vmovaps [rsp+0xB0], xmm12
0000705c56fdda50  vmovaps [rsp+0xC0], xmm13
0000705c56fdda59  vmovaps [rsp+0xD0], xmm14
0000705c56fdda62  vmovaps [rsp+0xE0], xmm15
0000705c56fdda6b  sub rsp, 0x30
0000705c56fdda6f  movaps [rsp], xmm4
0000705c56fdda73  movaps [rsp+0x10], xmm15
0000705c56fdda79  movaps [rsp+0x20], xmm9
0000705c56fdda7f  lea rdi, [rsp]
0000705c56fdda83  mov esi, 0x00
0000705c56fdda88  mov rax, 0x5877D3629530
0000705c56fdda92  call rax
0000705c56fdda94  movaps xmm4, [rsp]
0000705c56fdda98  add rsp, 0x30
0000705c56fdda9c  vmovaps xmm0, [rsp]
0000705c56fddaa1  vmovaps xmm1, [rsp+0x10]
0000705c56fddaa7  vmovaps xmm2, [rsp+0x20]
0000705c56fddaad  vmovaps xmm3, [rsp+0x30]
0000705c56fddab3  vmovaps xmm5, [rsp+0x40]
0000705c56fddab9  vmovaps xmm6, [rsp+0x50]
0000705c56fddabf  vmovaps xmm7, [rsp+0x60]
0000705c56fddac5  vmovaps xmm8, [rsp+0x70]
0000705c56fddacb  vmovaps xmm9, [rsp+0x80]
0000705c56fddad4  vmovaps xmm10, [rsp+0x90]
0000705c56fddadd  vmovaps xmm11, [rsp+0xA0]
0000705c56fddae6  vmovaps xmm12, [rsp+0xB0]
0000705c56fddaef  vmovaps xmm13, [rsp+0xC0]
0000705c56fddaf8  vmovaps xmm14, [rsp+0xD0]
0000705c56fddb01  vmovaps xmm15, [rsp+0xE0]
0000705c56fddb0a  add rsp, 0xF0
0000705c56fddb11  pop r11
0000705c56fddb13  pop r10
0000705c56fddb15  pop r9
0000705c56fddb17  pop r8
0000705c56fddb19  pop rsi
0000705c56fddb1a  pop rdi
0000705c56fddb1b  pop rdx
0000705c56fddb1c  pop rcx
0000705c56fddb1d  pop rax
0000705c56fddb1e  add rsp, 0x08
0000705c56fddb22  jmp 0x0000705C56FDBEAC
0000705c56fddb27  call 0x0000705C56EC4620
0000705c56fddb2c  jmp 0x0000705C56FDBEB9
0000705c56fddb31  sub rsp, 0x08
0000705c56fddb35  push rax
0000705c56fddb36  push rcx
0000705c56fddb37  push rdx
0000705c56fddb38  push rdi
0000705c56fddb39  push rsi
0000705c56fddb3a  push r8
0000705c56fddb3c  push r9
0000705c56fddb3e  push r10
0000705c56fddb40  push r11
0000705c56fddb42  sub rsp, 0xF0
0000705c56fddb49  vmovaps [rsp], xmm0
0000705c56fddb4e  vmovaps [rsp+0x10], xmm1
0000705c56fddb54  vmovaps [rsp+0x20], xmm2
0000705c56fddb5a  vmovaps [rsp+0x30], xmm4
0000705c56fddb60  vmovaps [rsp+0x40], xmm5
0000705c56fddb66  vmovaps [rsp+0x50], xmm6
0000705c56fddb6c  vmovaps [rsp+0x60], xmm7
0000705c56fddb72  vmovaps [rsp+0x70], xmm8
0000705c56fddb78  vmovaps [rsp+0x80], xmm9
0000705c56fddb81  vmovaps [rsp+0x90], xmm10
0000705c56fddb8a  vmovaps [rsp+0xA0], xmm11
0000705c56fddb93  vmovaps [rsp+0xB0], xmm12
0000705c56fddb9c  vmovaps [rsp+0xC0], xmm13
0000705c56fddba5  vmovaps [rsp+0xD0], xmm14
0000705c56fddbae  vmovaps [rsp+0xE0], xmm15
0000705c56fddbb7  sub rsp, 0x30
0000705c56fddbbb  movaps [rsp], xmm3
0000705c56fddbbf  movaps [rsp+0x10], xmm1
0000705c56fddbc4  movaps [rsp+0x20], xmm9
0000705c56fddbca  lea rdi, [rsp]
0000705c56fddbce  mov esi, 0x00
0000705c56fddbd3  mov rax, 0x5877D3629530
0000705c56fddbdd  call rax
0000705c56fddbdf  movaps xmm3, [rsp]
0000705c56fddbe3  add rsp, 0x30
0000705c56fddbe7  vmovaps xmm0, [rsp]
0000705c56fddbec  vmovaps xmm1, [rsp+0x10]
0000705c56fddbf2  vmovaps xmm2, [rsp+0x20]
0000705c56fddbf8  vmovaps xmm4, [rsp+0x30]
0000705c56fddbfe  vmovaps xmm5, [rsp+0x40]
0000705c56fddc04  vmovaps xmm6, [rsp+0x50]
0000705c56fddc0a  vmovaps xmm7, [rsp+0x60]
0000705c56fddc10  vmovaps xmm8, [rsp+0x70]
0000705c56fddc16  vmovaps xmm9, [rsp+0x80]
0000705c56fddc1f  vmovaps xmm10, [rsp+0x90]
0000705c56fddc28  vmovaps xmm11, [rsp+0xA0]
0000705c56fddc31  vmovaps xmm12, [rsp+0xB0]
0000705c56fddc3a  vmovaps xmm13, [rsp+0xC0]
0000705c56fddc43  vmovaps xmm14, [rsp+0xD0]
0000705c56fddc4c  vmovaps xmm15, [rsp+0xE0]
0000705c56fddc55  add rsp, 0xF0
0000705c56fddc5c  pop r11
0000705c56fddc5e  pop r10
0000705c56fddc60  pop r9
0000705c56fddc62  pop r8
0000705c56fddc64  pop rsi
0000705c56fddc65  pop rdi
0000705c56fddc66  pop rdx
0000705c56fddc67  pop rcx
0000705c56fddc68  pop rax
0000705c56fddc69  add rsp, 0x08
0000705c56fddc6d  jmp 0x0000705C56FDBEF6
0000705c56fddc72  sub rsp, 0x08
0000705c56fddc76  push rax
0000705c56fddc77  push rcx
0000705c56fddc78  push rdx
0000705c56fddc79  push rdi
0000705c56fddc7a  push rsi
0000705c56fddc7b  push r8
0000705c56fddc7d  push r9
0000705c56fddc7f  push r10
0000705c56fddc81  push r11
0000705c56fddc83  sub rsp, 0xF0
0000705c56fddc8a  vmovaps [rsp], xmm0
0000705c56fddc8f  vmovaps [rsp+0x10], xmm2
0000705c56fddc95  vmovaps [rsp+0x20], xmm3
0000705c56fddc9b  vmovaps [rsp+0x30], xmm4
0000705c56fddca1  vmovaps [rsp+0x40], xmm5
0000705c56fddca7  vmovaps [rsp+0x50], xmm6
0000705c56fddcad  vmovaps [rsp+0x60], xmm7
0000705c56fddcb3  vmovaps [rsp+0x70], xmm8
0000705c56fddcb9  vmovaps [rsp+0x80], xmm9
0000705c56fddcc2  vmovaps [rsp+0x90], xmm10
0000705c56fddccb  vmovaps [rsp+0xA0], xmm11
0000705c56fddcd4  vmovaps [rsp+0xB0], xmm12
0000705c56fddcdd  vmovaps [rsp+0xC0], xmm13
0000705c56fddce6  vmovaps [rsp+0xD0], xmm14
0000705c56fddcef  vmovaps [rsp+0xE0], xmm15
0000705c56fddcf8  sub rsp, 0x30
0000705c56fddcfc  movaps [rsp], xmm1
0000705c56fddd00  movaps [rsp+0x10], xmm15
0000705c56fddd06  movaps [rsp+0x20], xmm9
0000705c56fddd0c  lea rdi, [rsp]
0000705c56fddd10  mov esi, 0x00
0000705c56fddd15  mov rax, 0x5877D3629530
0000705c56fddd1f  call rax
0000705c56fddd21  movaps xmm1, [rsp]
0000705c56fddd25  add rsp, 0x30
0000705c56fddd29  vmovaps xmm0, [rsp]
0000705c56fddd2e  vmovaps xmm2, [rsp+0x10]
0000705c56fddd34  vmovaps xmm3, [rsp+0x20]
0000705c56fddd3a  vmovaps xmm4, [rsp+0x30]
0000705c56fddd40  vmovaps xmm5, [rsp+0x40]
0000705c56fddd46  vmovaps xmm6, [rsp+0x50]
0000705c56fddd4c  vmovaps xmm7, [rsp+0x60]
0000705c56fddd52  vmovaps xmm8, [rsp+0x70]
0000705c56fddd58  vmovaps xmm9, [rsp+0x80]
0000705c56fddd61  vmovaps xmm10, [rsp+0x90]
0000705c56fddd6a  vmovaps xmm11, [rsp+0xA0]
0000705c56fddd73  vmovaps xmm12, [rsp+0xB0]
0000705c56fddd7c  vmovaps xmm13, [rsp+0xC0]
0000705c56fddd85  vmovaps xmm14, [rsp+0xD0]
0000705c56fddd8e  vmovaps xmm15, [rsp+0xE0]
0000705c56fddd97  add rsp, 0xF0
0000705c56fddd9e  pop r11
0000705c56fddda0  pop r10
0000705c56fddda2  pop r9
0000705c56fddda4  pop r8
0000705c56fddda6  pop rsi
0000705c56fddda7  pop rdi
0000705c56fddda8  pop rdx
0000705c56fddda9  pop rcx
0000705c56fdddaa  pop rax
0000705c56fdddab  add rsp, 0x08
0000705c56fdddaf  jmp 0x0000705C56FDBF7E
0000705c56fdddb4  call 0x0000705C56EC4620
0000705c56fdddb9  jmp 0x0000705C56FDBF8B
0000705c56fdddbe  sub rsp, 0x08
0000705c56fdddc2  push rax
0000705c56fdddc3  push rcx
0000705c56fdddc4  push rdx
0000705c56fdddc5  push rdi
0000705c56fdddc6  push rsi
0000705c56fdddc7  push r8
0000705c56fdddc9  push r9
0000705c56fdddcb  push r10
0000705c56fdddcd  push r11
0000705c56fdddcf  sub rsp, 0xF0
0000705c56fdddd6  vmovaps [rsp], xmm0
0000705c56fddddb  vmovaps [rsp+0x10], xmm2
0000705c56fddde1  vmovaps [rsp+0x20], xmm3
0000705c56fddde7  vmovaps [rsp+0x30], xmm4
0000705c56fddded  vmovaps [rsp+0x40], xmm5
0000705c56fdddf3  vmovaps [rsp+0x50], xmm6
0000705c56fdddf9  vmovaps [rsp+0x60], xmm7
0000705c56fdddff  vmovaps [rsp+0x70], xmm8
0000705c56fdde05  vmovaps [rsp+0x80], xmm9
0000705c56fdde0e  vmovaps [rsp+0x90], xmm10
0000705c56fdde17  vmovaps [rsp+0xA0], xmm11
0000705c56fdde20  vmovaps [rsp+0xB0], xmm12
0000705c56fdde29  vmovaps [rsp+0xC0], xmm13
0000705c56fdde32  vmovaps [rsp+0xD0], xmm14
0000705c56fdde3b  vmovaps [rsp+0xE0], xmm15
0000705c56fdde44  sub rsp, 0x30
0000705c56fdde48  movaps [rsp], xmm1
0000705c56fdde4c  movaps [rsp+0x10], xmm5
0000705c56fdde51  movaps [rsp+0x20], xmm7
0000705c56fdde56  lea rdi, [rsp]
0000705c56fdde5a  mov esi, 0x00
0000705c56fdde5f  mov rax, 0x5877D3629530
0000705c56fdde69  call rax
0000705c56fdde6b  movaps xmm1, [rsp]
0000705c56fdde6f  add rsp, 0x30
0000705c56fdde73  vmovaps xmm0, [rsp]
0000705c56fdde78  vmovaps xmm2, [rsp+0x10]
0000705c56fdde7e  vmovaps xmm3, [rsp+0x20]
0000705c56fdde84  vmovaps xmm4, [rsp+0x30]
0000705c56fdde8a  vmovaps xmm5, [rsp+0x40]
0000705c56fdde90  vmovaps xmm6, [rsp+0x50]
0000705c56fdde96  vmovaps xmm7, [rsp+0x60]
0000705c56fdde9c  vmovaps xmm8, [rsp+0x70]
0000705c56fddea2  vmovaps xmm9, [rsp+0x80]
0000705c56fddeab  vmovaps xmm10, [rsp+0x90]
0000705c56fddeb4  vmovaps xmm11, [rsp+0xA0]
0000705c56fddebd  vmovaps xmm12, [rsp+0xB0]
0000705c56fddec6  vmovaps xmm13, [rsp+0xC0]
0000705c56fddecf  vmovaps xmm14, [rsp+0xD0]
0000705c56fdded8  vmovaps xmm15, [rsp+0xE0]
0000705c56fddee1  add rsp, 0xF0
0000705c56fddee8  pop r11
0000705c56fddeea  pop r10
0000705c56fddeec  pop r9
0000705c56fddeee  pop r8
0000705c56fddef0  pop rsi
0000705c56fddef1  pop rdi
0000705c56fddef2  pop rdx
0000705c56fddef3  pop rcx
0000705c56fddef4  pop rax
0000705c56fddef5  add rsp, 0x08
0000705c56fddef9  jmp 0x0000705C56FDC030
0000705c56fddefe  sub rsp, 0x08
0000705c56fddf02  push rax
0000705c56fddf03  push rcx
0000705c56fddf04  push rdx
0000705c56fddf05  push rdi
0000705c56fddf06  push rsi
0000705c56fddf07  push r8
0000705c56fddf09  push r9
0000705c56fddf0b  push r10
0000705c56fddf0d  push r11
0000705c56fddf0f  sub rsp, 0xF0
0000705c56fddf16  vmovaps [rsp], xmm0
0000705c56fddf1b  vmovaps [rsp+0x10], xmm1
0000705c56fddf21  vmovaps [rsp+0x20], xmm2
0000705c56fddf27  vmovaps [rsp+0x30], xmm3
0000705c56fddf2d  vmovaps [rsp+0x40], xmm4
0000705c56fddf33  vmovaps [rsp+0x50], xmm5
0000705c56fddf39  vmovaps [rsp+0x60], xmm6
0000705c56fddf3f  vmovaps [rsp+0x70], xmm8
0000705c56fddf45  vmovaps [rsp+0x80], xmm9
0000705c56fddf4e  vmovaps [rsp+0x90], xmm10
0000705c56fddf57  vmovaps [rsp+0xA0], xmm11
0000705c56fddf60  vmovaps [rsp+0xB0], xmm12
0000705c56fddf69  vmovaps [rsp+0xC0], xmm13
0000705c56fddf72  vmovaps [rsp+0xD0], xmm14
0000705c56fddf7b  vmovaps [rsp+0xE0], xmm15
0000705c56fddf84  sub rsp, 0x30
0000705c56fddf88  movaps [rsp], xmm7
0000705c56fddf8c  movaps [rsp+0x10], xmm5
0000705c56fddf91  movaps [rsp+0x20], xmm15
0000705c56fddf97  lea rdi, [rsp]
0000705c56fddf9b  mov esi, 0x00
0000705c56fddfa0  mov rax, 0x5877D3629530
0000705c56fddfaa  call rax
0000705c56fddfac  movaps xmm7, [rsp]
0000705c56fddfb0  add rsp, 0x30
0000705c56fddfb4  vmovaps xmm0, [rsp]
0000705c56fddfb9  vmovaps xmm1, [rsp+0x10]
0000705c56fddfbf  vmovaps xmm2, [rsp+0x20]
0000705c56fddfc5  vmovaps xmm3, [rsp+0x30]
0000705c56fddfcb  vmovaps xmm4, [rsp+0x40]
0000705c56fddfd1  vmovaps xmm5, [rsp+0x50]
0000705c56fddfd7  vmovaps xmm6, [rsp+0x60]
0000705c56fddfdd  vmovaps xmm8, [rsp+0x70]
0000705c56fddfe3  vmovaps xmm9, [rsp+0x80]
0000705c56fddfec  vmovaps xmm10, [rsp+0x90]
0000705c56fddff5  vmovaps xmm11, [rsp+0xA0]
0000705c56fddffe  vmovaps xmm12, [rsp+0xB0]
0000705c56fde007  vmovaps xmm13, [rsp+0xC0]
0000705c56fde010  vmovaps xmm14, [rsp+0xD0]
0000705c56fde019  vmovaps xmm15, [rsp+0xE0]
0000705c56fde022  add rsp, 0xF0
0000705c56fde029  pop r11
0000705c56fde02b  pop r10
0000705c56fde02d  pop r9
0000705c56fde02f  pop r8
0000705c56fde031  pop rsi
0000705c56fde032  pop rdi
0000705c56fde033  pop rdx
0000705c56fde034  pop rcx
0000705c56fde035  pop rax
0000705c56fde036  add rsp, 0x08
0000705c56fde03a  jmp 0x0000705C56FDC066
0000705c56fde03f  call 0x0000705C56EB52F0
0000705c56fde044  jmp 0x0000705C56FDC073
0000705c56fde049  sub rsp, 0x08
0000705c56fde04d  push rax
0000705c56fde04e  push rcx
0000705c56fde04f  push rdx
0000705c56fde050  push rdi
0000705c56fde051  push rsi
0000705c56fde052  push r8
0000705c56fde054  push r9
0000705c56fde056  push r10
0000705c56fde058  push r11
0000705c56fde05a  sub rsp, 0xF0
0000705c56fde061  vmovaps [rsp], xmm0
0000705c56fde066  vmovaps [rsp+0x10], xmm1
0000705c56fde06c  vmovaps [rsp+0x20], xmm2
0000705c56fde072  vmovaps [rsp+0x30], xmm3
0000705c56fde078  vmovaps [rsp+0x40], xmm4
0000705c56fde07e  vmovaps [rsp+0x50], xmm5
0000705c56fde084  vmovaps [rsp+0x60], xmm6
0000705c56fde08a  vmovaps [rsp+0x70], xmm7
0000705c56fde090  vmovaps [rsp+0x80], xmm8
0000705c56fde099  vmovaps [rsp+0x90], xmm9
0000705c56fde0a2  vmovaps [rsp+0xA0], xmm10
0000705c56fde0ab  vmovaps [rsp+0xB0], xmm11
0000705c56fde0b4  vmovaps [rsp+0xC0], xmm12
0000705c56fde0bd  vmovaps [rsp+0xD0], xmm13
0000705c56fde0c6  vmovaps [rsp+0xE0], xmm14
0000705c56fde0cf  sub rsp, 0x30
0000705c56fde0d3  movaps [rsp], xmm15
0000705c56fde0d8  movaps [rsp+0x10], xmm5
0000705c56fde0dd  movaps [rsp+0x20], xmm3
0000705c56fde0e2  lea rdi, [rsp]
0000705c56fde0e6  mov esi, 0x00
0000705c56fde0eb  mov rax, 0x5877D3629530
0000705c56fde0f5  call rax
0000705c56fde0f7  movaps xmm15, [rsp]
0000705c56fde0fc  add rsp, 0x30
0000705c56fde100  vmovaps xmm0, [rsp]
0000705c56fde105  vmovaps xmm1, [rsp+0x10]
0000705c56fde10b  vmovaps xmm2, [rsp+0x20]
0000705c56fde111  vmovaps xmm3, [rsp+0x30]
0000705c56fde117  vmovaps xmm4, [rsp+0x40]
0000705c56fde11d  vmovaps xmm5, [rsp+0x50]
0000705c56fde123  vmovaps xmm6, [rsp+0x60]
0000705c56fde129  vmovaps xmm7, [rsp+0x70]
0000705c56fde12f  vmovaps xmm8, [rsp+0x80]
0000705c56fde138  vmovaps xmm9, [rsp+0x90]
0000705c56fde141  vmovaps xmm10, [rsp+0xA0]
0000705c56fde14a  vmovaps xmm11, [rsp+0xB0]
0000705c56fde153  vmovaps xmm12, [rsp+0xC0]
0000705c56fde15c  vmovaps xmm13, [rsp+0xD0]
0000705c56fde165  vmovaps xmm14, [rsp+0xE0]
0000705c56fde16e  add rsp, 0xF0
0000705c56fde175  pop r11
0000705c56fde177  pop r10
0000705c56fde179  pop r9
0000705c56fde17b  pop r8
0000705c56fde17d  pop rsi
0000705c56fde17e  pop rdi
0000705c56fde17f  pop rdx
0000705c56fde180  pop rcx
0000705c56fde181  pop rax
0000705c56fde182  add rsp, 0x08
0000705c56fde186  jmp 0x0000705C56FDC099
0000705c56fde18b  sub rsp, 0x08
0000705c56fde18f  push rax
0000705c56fde190  push rcx
0000705c56fde191  push rdx
0000705c56fde192  push rdi
0000705c56fde193  push rsi
0000705c56fde194  push r8
0000705c56fde196  push r9
0000705c56fde198  push r10
0000705c56fde19a  push r11
0000705c56fde19c  sub rsp, 0xF0
0000705c56fde1a3  vmovaps [rsp], xmm0
0000705c56fde1a8  vmovaps [rsp+0x10], xmm2
0000705c56fde1ae  vmovaps [rsp+0x20], xmm3
0000705c56fde1b4  vmovaps [rsp+0x30], xmm4
0000705c56fde1ba  vmovaps [rsp+0x40], xmm5
0000705c56fde1c0  vmovaps [rsp+0x50], xmm6
0000705c56fde1c6  vmovaps [rsp+0x60], xmm7
0000705c56fde1cc  vmovaps [rsp+0x70], xmm8
0000705c56fde1d2  vmovaps [rsp+0x80], xmm9
0000705c56fde1db  vmovaps [rsp+0x90], xmm10
0000705c56fde1e4  vmovaps [rsp+0xA0], xmm11
0000705c56fde1ed  vmovaps [rsp+0xB0], xmm12
0000705c56fde1f6  vmovaps [rsp+0xC0], xmm13
0000705c56fde1ff  vmovaps [rsp+0xD0], xmm14
0000705c56fde208  vmovaps [rsp+0xE0], xmm15
0000705c56fde211  sub rsp, 0x30
0000705c56fde215  movaps [rsp], xmm1
0000705c56fde219  movaps [rsp+0x10], xmm5
0000705c56fde21e  movaps [rsp+0x20], xmm4
0000705c56fde223  lea rdi, [rsp]
0000705c56fde227  mov esi, 0x00
0000705c56fde22c  mov rax, 0x5877D3629530
0000705c56fde236  call rax
0000705c56fde238  movaps xmm1, [rsp]
0000705c56fde23c  add rsp, 0x30
0000705c56fde240  vmovaps xmm0, [rsp]
0000705c56fde245  vmovaps xmm2, [rsp+0x10]
0000705c56fde24b  vmovaps xmm3, [rsp+0x20]
0000705c56fde251  vmovaps xmm4, [rsp+0x30]
0000705c56fde257  vmovaps xmm5, [rsp+0x40]
0000705c56fde25d  vmovaps xmm6, [rsp+0x50]
0000705c56fde263  vmovaps xmm7, [rsp+0x60]
0000705c56fde269  vmovaps xmm8, [rsp+0x70]
0000705c56fde26f  vmovaps xmm9, [rsp+0x80]
0000705c56fde278  vmovaps xmm10, [rsp+0x90]
0000705c56fde281  vmovaps xmm11, [rsp+0xA0]
0000705c56fde28a  vmovaps xmm12, [rsp+0xB0]
0000705c56fde293  vmovaps xmm13, [rsp+0xC0]
0000705c56fde29c  vmovaps xmm14, [rsp+0xD0]
0000705c56fde2a5  vmovaps xmm15, [rsp+0xE0]
0000705c56fde2ae  add rsp, 0xF0
0000705c56fde2b5  pop r11
0000705c56fde2b7  pop r10
0000705c56fde2b9  pop r9
0000705c56fde2bb  pop r8
0000705c56fde2bd  pop rsi
0000705c56fde2be  pop rdi
0000705c56fde2bf  pop rdx
0000705c56fde2c0  pop rcx
0000705c56fde2c1  pop rax
0000705c56fde2c2  add rsp, 0x08
0000705c56fde2c6  jmp 0x0000705C56FDC0B9
0000705c56fde2cb  sub rsp, 0x08
0000705c56fde2cf  push rax
0000705c56fde2d0  push rcx
0000705c56fde2d1  push rdx
0000705c56fde2d2  push rdi
0000705c56fde2d3  push rsi
0000705c56fde2d4  push r8
0000705c56fde2d6  push r9
0000705c56fde2d8  push r10
0000705c56fde2da  push r11
0000705c56fde2dc  sub rsp, 0xF0
0000705c56fde2e3  vmovaps [rsp], xmm0
0000705c56fde2e8  vmovaps [rsp+0x10], xmm1
0000705c56fde2ee  vmovaps [rsp+0x20], xmm2
0000705c56fde2f4  vmovaps [rsp+0x30], xmm3
0000705c56fde2fa  vmovaps [rsp+0x40], xmm5
0000705c56fde300  vmovaps [rsp+0x50], xmm6
0000705c56fde306  vmovaps [rsp+0x60], xmm7
0000705c56fde30c  vmovaps [rsp+0x70], xmm8
0000705c56fde312  vmovaps [rsp+0x80], xmm9
0000705c56fde31b  vmovaps [rsp+0x90], xmm10
0000705c56fde324  vmovaps [rsp+0xA0], xmm11
0000705c56fde32d  vmovaps [rsp+0xB0], xmm12
0000705c56fde336  vmovaps [rsp+0xC0], xmm13
0000705c56fde33f  vmovaps [rsp+0xD0], xmm14
0000705c56fde348  vmovaps [rsp+0xE0], xmm15
0000705c56fde351  sub rsp, 0x30
0000705c56fde355  movaps [rsp], xmm4
0000705c56fde359  movaps [rsp+0x10], xmm3
0000705c56fde35e  movaps [rsp+0x20], xmm5
0000705c56fde363  lea rdi, [rsp]
0000705c56fde367  mov esi, 0x00
0000705c56fde36c  mov rax, 0x5877D3629530
0000705c56fde376  call rax
0000705c56fde378  movaps xmm4, [rsp]
0000705c56fde37c  add rsp, 0x30
0000705c56fde380  vmovaps xmm0, [rsp]
0000705c56fde385  vmovaps xmm1, [rsp+0x10]
0000705c56fde38b  vmovaps xmm2, [rsp+0x20]
0000705c56fde391  vmovaps xmm3, [rsp+0x30]
0000705c56fde397  vmovaps xmm5, [rsp+0x40]
0000705c56fde39d  vmovaps xmm6, [rsp+0x50]
0000705c56fde3a3  vmovaps xmm7, [rsp+0x60]
0000705c56fde3a9  vmovaps xmm8, [rsp+0x70]
0000705c56fde3af  vmovaps xmm9, [rsp+0x80]
0000705c56fde3b8  vmovaps xmm10, [rsp+0x90]
0000705c56fde3c1  vmovaps xmm11, [rsp+0xA0]
0000705c56fde3ca  vmovaps xmm12, [rsp+0xB0]
0000705c56fde3d3  vmovaps xmm13, [rsp+0xC0]
0000705c56fde3dc  vmovaps xmm14, [rsp+0xD0]
0000705c56fde3e5  vmovaps xmm15, [rsp+0xE0]
0000705c56fde3ee  add rsp, 0xF0
0000705c56fde3f5  pop r11
0000705c56fde3f7  pop r10
0000705c56fde3f9  pop r9
0000705c56fde3fb  pop r8
0000705c56fde3fd  pop rsi
0000705c56fde3fe  pop rdi
0000705c56fde3ff  pop rdx
0000705c56fde400  pop rcx
0000705c56fde401  pop rax
0000705c56fde402  add rsp, 0x08
0000705c56fde406  jmp 0x0000705C56FDC107
0000705c56fde40b  call 0x0000705C56EB52F0
0000705c56fde410  jmp 0x0000705C56FDC114
0000705c56fde415  sub rsp, 0x08
0000705c56fde419  push rax
0000705c56fde41a  push rcx
0000705c56fde41b  push rdx
0000705c56fde41c  push rdi
0000705c56fde41d  push rsi
0000705c56fde41e  push r8
0000705c56fde420  push r9
0000705c56fde422  push r10
0000705c56fde424  push r11
0000705c56fde426  sub rsp, 0xF0
0000705c56fde42d  vmovaps [rsp], xmm0
0000705c56fde432  vmovaps [rsp+0x10], xmm1
0000705c56fde438  vmovaps [rsp+0x20], xmm2
0000705c56fde43e  vmovaps [rsp+0x30], xmm3
0000705c56fde444  vmovaps [rsp+0x40], xmm4
0000705c56fde44a  vmovaps [rsp+0x50], xmm6
0000705c56fde450  vmovaps [rsp+0x60], xmm7
0000705c56fde456  vmovaps [rsp+0x70], xmm8
0000705c56fde45c  vmovaps [rsp+0x80], xmm9
0000705c56fde465  vmovaps [rsp+0x90], xmm10
0000705c56fde46e  vmovaps [rsp+0xA0], xmm11
0000705c56fde477  vmovaps [rsp+0xB0], xmm12
0000705c56fde480  vmovaps [rsp+0xC0], xmm13
0000705c56fde489  vmovaps [rsp+0xD0], xmm14
0000705c56fde492  vmovaps [rsp+0xE0], xmm15
0000705c56fde49b  sub rsp, 0x30
0000705c56fde49f  movaps [rsp], xmm5
0000705c56fde4a3  movaps [rsp+0x10], xmm6
0000705c56fde4a8  movaps [rsp+0x20], xmm3
0000705c56fde4ad  lea rdi, [rsp]
0000705c56fde4b1  mov esi, 0x00
0000705c56fde4b6  mov rax, 0x5877D3629530
0000705c56fde4c0  call rax
0000705c56fde4c2  movaps xmm5, [rsp]
0000705c56fde4c6  add rsp, 0x30
0000705c56fde4ca  vmovaps xmm0, [rsp]
0000705c56fde4cf  vmovaps xmm1, [rsp+0x10]
0000705c56fde4d5  vmovaps xmm2, [rsp+0x20]
0000705c56fde4db  vmovaps xmm3, [rsp+0x30]
0000705c56fde4e1  vmovaps xmm4, [rsp+0x40]
0000705c56fde4e7  vmovaps xmm6, [rsp+0x50]
0000705c56fde4ed  vmovaps xmm7, [rsp+0x60]
0000705c56fde4f3  vmovaps xmm8, [rsp+0x70]
0000705c56fde4f9  vmovaps xmm9, [rsp+0x80]
0000705c56fde502  vmovaps xmm10, [rsp+0x90]
0000705c56fde50b  vmovaps xmm11, [rsp+0xA0]
0000705c56fde514  vmovaps xmm12, [rsp+0xB0]
0000705c56fde51d  vmovaps xmm13, [rsp+0xC0]
0000705c56fde526  vmovaps xmm14, [rsp+0xD0]
0000705c56fde52f  vmovaps xmm15, [rsp+0xE0]
0000705c56fde538  add rsp, 0xF0
0000705c56fde53f  pop r11
0000705c56fde541  pop r10
0000705c56fde543  pop r9
0000705c56fde545  pop r8
0000705c56fde547  pop rsi
0000705c56fde548  pop rdi
0000705c56fde549  pop rdx
0000705c56fde54a  pop rcx
0000705c56fde54b  pop rax
0000705c56fde54c  add rsp, 0x08
0000705c56fde550  jmp 0x0000705C56FDC13A
0000705c56fde555  sub rsp, 0x08
0000705c56fde559  push rax
0000705c56fde55a  push rcx
0000705c56fde55b  push rdx
0000705c56fde55c  push rdi
0000705c56fde55d  push rsi
0000705c56fde55e  push r8
0000705c56fde560  push r9
0000705c56fde562  push r10
0000705c56fde564  push r11
0000705c56fde566  sub rsp, 0xF0
0000705c56fde56d  vmovaps [rsp], xmm0
0000705c56fde572  vmovaps [rsp+0x10], xmm1
0000705c56fde578  vmovaps [rsp+0x20], xmm2
0000705c56fde57e  vmovaps [rsp+0x30], xmm3
0000705c56fde584  vmovaps [rsp+0x40], xmm4
0000705c56fde58a  vmovaps [rsp+0x50], xmm5
0000705c56fde590  vmovaps [rsp+0x60], xmm7
0000705c56fde596  vmovaps [rsp+0x70], xmm8
0000705c56fde59c  vmovaps [rsp+0x80], xmm9
0000705c56fde5a5  vmovaps [rsp+0x90], xmm10
0000705c56fde5ae  vmovaps [rsp+0xA0], xmm11
0000705c56fde5b7  vmovaps [rsp+0xB0], xmm12
0000705c56fde5c0  vmovaps [rsp+0xC0], xmm13
0000705c56fde5c9  vmovaps [rsp+0xD0], xmm14
0000705c56fde5d2  vmovaps [rsp+0xE0], xmm15
0000705c56fde5db  sub rsp, 0x30
0000705c56fde5df  movaps [rsp], xmm6
0000705c56fde5e3  movaps [rsp+0x10], xmm9
0000705c56fde5e9  movaps [rsp+0x20], xmm1
0000705c56fde5ee  lea rdi, [rsp]
0000705c56fde5f2  mov esi, 0x00
0000705c56fde5f7  mov rax, 0x5877D3629530
0000705c56fde601  call rax
0000705c56fde603  movaps xmm6, [rsp]
0000705c56fde607  add rsp, 0x30
0000705c56fde60b  vmovaps xmm0, [rsp]
0000705c56fde610  vmovaps xmm1, [rsp+0x10]
0000705c56fde616  vmovaps xmm2, [rsp+0x20]
0000705c56fde61c  vmovaps xmm3, [rsp+0x30]
0000705c56fde622  vmovaps xmm4, [rsp+0x40]
0000705c56fde628  vmovaps xmm5, [rsp+0x50]
0000705c56fde62e  vmovaps xmm7, [rsp+0x60]
0000705c56fde634  vmovaps xmm8, [rsp+0x70]
0000705c56fde63a  vmovaps xmm9, [rsp+0x80]
0000705c56fde643  vmovaps xmm10, [rsp+0x90]
0000705c56fde64c  vmovaps xmm11, [rsp+0xA0]
0000705c56fde655  vmovaps xmm12, [rsp+0xB0]
0000705c56fde65e  vmovaps xmm13, [rsp+0xC0]
0000705c56fde667  vmovaps xmm14, [rsp+0xD0]
0000705c56fde670  vmovaps xmm15, [rsp+0xE0]
0000705c56fde679  add rsp, 0xF0
0000705c56fde680  pop r11
0000705c56fde682  pop r10
0000705c56fde684  pop r9
0000705c56fde686  pop r8
0000705c56fde688  pop rsi
0000705c56fde689  pop rdi
0000705c56fde68a  pop rdx
0000705c56fde68b  pop rcx
0000705c56fde68c  pop rax
0000705c56fde68d  add rsp, 0x08
0000705c56fde691  jmp 0x0000705C56FDC15E
0000705c56fde696  sub rsp, 0x08
0000705c56fde69a  push rax
0000705c56fde69b  push rcx
0000705c56fde69c  push rdx
0000705c56fde69d  push rdi
0000705c56fde69e  push rsi
0000705c56fde69f  push r8
0000705c56fde6a1  push r9
0000705c56fde6a3  push r10
0000705c56fde6a5  push r11
0000705c56fde6a7  sub rsp, 0xF0
0000705c56fde6ae  vmovaps [rsp], xmm0
0000705c56fde6b3  vmovaps [rsp+0x10], xmm1
0000705c56fde6b9  vmovaps [rsp+0x20], xmm2
0000705c56fde6bf  vmovaps [rsp+0x30], xmm3
0000705c56fde6c5  vmovaps [rsp+0x40], xmm4
0000705c56fde6cb  vmovaps [rsp+0x50], xmm5
0000705c56fde6d1  vmovaps [rsp+0x60], xmm6
0000705c56fde6d7  vmovaps [rsp+0x70], xmm7
0000705c56fde6dd  vmovaps [rsp+0x80], xmm8
0000705c56fde6e6  vmovaps [rsp+0x90], xmm10
0000705c56fde6ef  vmovaps [rsp+0xA0], xmm11
0000705c56fde6f8  vmovaps [rsp+0xB0], xmm12
0000705c56fde701  vmovaps [rsp+0xC0], xmm13
0000705c56fde70a  vmovaps [rsp+0xD0], xmm14
0000705c56fde713  vmovaps [rsp+0xE0], xmm15
0000705c56fde71c  sub rsp, 0x30
0000705c56fde720  movaps [rsp], xmm9
0000705c56fde725  movaps [rsp+0x10], xmm3
0000705c56fde72a  movaps [rsp+0x20], xmm1
0000705c56fde72f  lea rdi, [rsp]
0000705c56fde733  mov esi, 0x00
0000705c56fde738  mov rax, 0x5877D3629530
0000705c56fde742  call rax
0000705c56fde744  movaps xmm9, [rsp]
0000705c56fde749  add rsp, 0x30
0000705c56fde74d  vmovaps xmm0, [rsp]
0000705c56fde752  vmovaps xmm1, [rsp+0x10]
0000705c56fde758  vmovaps xmm2, [rsp+0x20]
0000705c56fde75e  vmovaps xmm3, [rsp+0x30]
0000705c56fde764  vmovaps xmm4, [rsp+0x40]
0000705c56fde76a  vmovaps xmm5, [rsp+0x50]
0000705c56fde770  vmovaps xmm6, [rsp+0x60]
0000705c56fde776  vmovaps xmm7, [rsp+0x70]
0000705c56fde77c  vmovaps xmm8, [rsp+0x80]
0000705c56fde785  vmovaps xmm10, [rsp+0x90]
0000705c56fde78e  vmovaps xmm11, [rsp+0xA0]
0000705c56fde797  vmovaps xmm12, [rsp+0xB0]
0000705c56fde7a0  vmovaps xmm13, [rsp+0xC0]
0000705c56fde7a9  vmovaps xmm14, [rsp+0xD0]
0000705c56fde7b2  vmovaps xmm15, [rsp+0xE0]
0000705c56fde7bb  add rsp, 0xF0
0000705c56fde7c2  pop r11
0000705c56fde7c4  pop r10
0000705c56fde7c6  pop r9
0000705c56fde7c8  pop r8
0000705c56fde7ca  pop rsi
0000705c56fde7cb  pop rdi
0000705c56fde7cc  pop rdx
0000705c56fde7cd  pop rcx
0000705c56fde7ce  pop rax
0000705c56fde7cf  add rsp, 0x08
0000705c56fde7d3  jmp 0x0000705C56FDC1AA
0000705c56fde7d8  call 0x0000705C56EB52F0
0000705c56fde7dd  jmp 0x0000705C56FDC1B7
0000705c56fde7e2  sub rsp, 0x08
0000705c56fde7e6  push rax
0000705c56fde7e7  push rcx
0000705c56fde7e8  push rdx
0000705c56fde7e9  push rdi
0000705c56fde7ea  push rsi
0000705c56fde7eb  push r8
0000705c56fde7ed  push r9
0000705c56fde7ef  push r10
0000705c56fde7f1  push r11
0000705c56fde7f3  sub rsp, 0xF0
0000705c56fde7fa  vmovaps [rsp], xmm0
0000705c56fde7ff  vmovaps [rsp+0x10], xmm1
0000705c56fde805  vmovaps [rsp+0x20], xmm2
0000705c56fde80b  vmovaps [rsp+0x30], xmm3
0000705c56fde811  vmovaps [rsp+0x40], xmm4
0000705c56fde817  vmovaps [rsp+0x50], xmm5
0000705c56fde81d  vmovaps [rsp+0x60], xmm6
0000705c56fde823  vmovaps [rsp+0x70], xmm7
0000705c56fde829  vmovaps [rsp+0x80], xmm8
0000705c56fde832  vmovaps [rsp+0x90], xmm9
0000705c56fde83b  vmovaps [rsp+0xA0], xmm10
0000705c56fde844  vmovaps [rsp+0xB0], xmm11
0000705c56fde84d  vmovaps [rsp+0xC0], xmm12
0000705c56fde856  vmovaps [rsp+0xD0], xmm13
0000705c56fde85f  vmovaps [rsp+0xE0], xmm14
0000705c56fde868  sub rsp, 0x30
0000705c56fde86c  movaps [rsp], xmm15
0000705c56fde871  movaps [rsp+0x10], xmm3
0000705c56fde876  movaps [rsp+0x20], xmm7
0000705c56fde87b  lea rdi, [rsp]
0000705c56fde87f  mov esi, 0x00
0000705c56fde884  mov rax, 0x5877D3629530
0000705c56fde88e  call rax
0000705c56fde890  movaps xmm15, [rsp]
0000705c56fde895  add rsp, 0x30
0000705c56fde899  vmovaps xmm0, [rsp]
0000705c56fde89e  vmovaps xmm1, [rsp+0x10]
0000705c56fde8a4  vmovaps xmm2, [rsp+0x20]
0000705c56fde8aa  vmovaps xmm3, [rsp+0x30]
0000705c56fde8b0  vmovaps xmm4, [rsp+0x40]
0000705c56fde8b6  vmovaps xmm5, [rsp+0x50]
0000705c56fde8bc  vmovaps xmm6, [rsp+0x60]
0000705c56fde8c2  vmovaps xmm7, [rsp+0x70]
0000705c56fde8c8  vmovaps xmm8, [rsp+0x80]
0000705c56fde8d1  vmovaps xmm9, [rsp+0x90]
0000705c56fde8da  vmovaps xmm10, [rsp+0xA0]
0000705c56fde8e3  vmovaps xmm11, [rsp+0xB0]
0000705c56fde8ec  vmovaps xmm12, [rsp+0xC0]
0000705c56fde8f5  vmovaps xmm13, [rsp+0xD0]
0000705c56fde8fe  vmovaps xmm14, [rsp+0xE0]
0000705c56fde907  add rsp, 0xF0
0000705c56fde90e  pop r11
0000705c56fde910  pop r10
0000705c56fde912  pop r9
0000705c56fde914  pop r8
0000705c56fde916  pop rsi
0000705c56fde917  pop rdi
0000705c56fde918  pop rdx
0000705c56fde919  pop rcx
0000705c56fde91a  pop rax
0000705c56fde91b  add rsp, 0x08
0000705c56fde91f  jmp 0x0000705C56FDC1E3
0000705c56fde924  sub rsp, 0x08
0000705c56fde928  push rax
0000705c56fde929  push rcx
0000705c56fde92a  push rdx
0000705c56fde92b  push rdi
0000705c56fde92c  push rsi
0000705c56fde92d  push r8
0000705c56fde92f  push r9
0000705c56fde931  push r10
0000705c56fde933  push r11
0000705c56fde935  sub rsp, 0xF0
0000705c56fde93c  vmovaps [rsp], xmm0
0000705c56fde941  vmovaps [rsp+0x10], xmm1
0000705c56fde947  vmovaps [rsp+0x20], xmm2
0000705c56fde94d  vmovaps [rsp+0x30], xmm4
0000705c56fde953  vmovaps [rsp+0x40], xmm5
0000705c56fde959  vmovaps [rsp+0x50], xmm6
0000705c56fde95f  vmovaps [rsp+0x60], xmm7
0000705c56fde965  vmovaps [rsp+0x70], xmm8
0000705c56fde96b  vmovaps [rsp+0x80], xmm9
0000705c56fde974  vmovaps [rsp+0x90], xmm10
0000705c56fde97d  vmovaps [rsp+0xA0], xmm11
0000705c56fde986  vmovaps [rsp+0xB0], xmm12
0000705c56fde98f  vmovaps [rsp+0xC0], xmm13
0000705c56fde998  vmovaps [rsp+0xD0], xmm14
0000705c56fde9a1  vmovaps [rsp+0xE0], xmm15
0000705c56fde9aa  sub rsp, 0x30
0000705c56fde9ae  movaps [rsp], xmm3
0000705c56fde9b2  movaps [rsp+0x10], xmm1
0000705c56fde9b7  movaps [rsp+0x20], xmm15
0000705c56fde9bd  lea rdi, [rsp]
0000705c56fde9c1  mov esi, 0x00
0000705c56fde9c6  mov rax, 0x5877D3629530
0000705c56fde9d0  call rax
0000705c56fde9d2  movaps xmm3, [rsp]
0000705c56fde9d6  add rsp, 0x30
0000705c56fde9da  vmovaps xmm0, [rsp]
0000705c56fde9df  vmovaps xmm1, [rsp+0x10]
0000705c56fde9e5  vmovaps xmm2, [rsp+0x20]
0000705c56fde9eb  vmovaps xmm4, [rsp+0x30]
0000705c56fde9f1  vmovaps xmm5, [rsp+0x40]
0000705c56fde9f7  vmovaps xmm6, [rsp+0x50]
0000705c56fde9fd  vmovaps xmm7, [rsp+0x60]
0000705c56fdea03  vmovaps xmm8, [rsp+0x70]
0000705c56fdea09  vmovaps xmm9, [rsp+0x80]
0000705c56fdea12  vmovaps xmm10, [rsp+0x90]
0000705c56fdea1b  vmovaps xmm11, [rsp+0xA0]
0000705c56fdea24  vmovaps xmm12, [rsp+0xB0]
0000705c56fdea2d  vmovaps xmm13, [rsp+0xC0]
0000705c56fdea36  vmovaps xmm14, [rsp+0xD0]
0000705c56fdea3f  vmovaps xmm15, [rsp+0xE0]
0000705c56fdea48  add rsp, 0xF0
0000705c56fdea4f  pop r11
0000705c56fdea51  pop r10
0000705c56fdea53  pop r9
0000705c56fdea55  pop r8
0000705c56fdea57  pop rsi
0000705c56fdea58  pop rdi
0000705c56fdea59  pop rdx
0000705c56fdea5a  pop rcx
0000705c56fdea5b  pop rax
0000705c56fdea5c  add rsp, 0x08
0000705c56fdea60  jmp 0x0000705C56FDC272
0000705c56fdea65  call 0x0000705C56EB52F0
0000705c56fdea6a  jmp 0x0000705C56FDC27C
0000705c56fdea6f  sub rsp, 0x08
0000705c56fdea73  push rax
0000705c56fdea74  push rcx
0000705c56fdea75  push rdx
0000705c56fdea76  push rdi
0000705c56fdea77  push rsi
0000705c56fdea78  push r8
0000705c56fdea7a  push r9
0000705c56fdea7c  push r10
0000705c56fdea7e  push r11
0000705c56fdea80  sub rsp, 0xF0
0000705c56fdea87  vmovaps [rsp], xmm0
0000705c56fdea8c  vmovaps [rsp+0x10], xmm1
0000705c56fdea92  vmovaps [rsp+0x20], xmm2
0000705c56fdea98  vmovaps [rsp+0x30], xmm3
0000705c56fdea9e  vmovaps [rsp+0x40], xmm4
0000705c56fdeaa4  vmovaps [rsp+0x50], xmm5
0000705c56fdeaaa  vmovaps [rsp+0x60], xmm6
0000705c56fdeab0  vmovaps [rsp+0x70], xmm7
0000705c56fdeab6  vmovaps [rsp+0x80], xmm8
0000705c56fdeabf  vmovaps [rsp+0x90], xmm9
0000705c56fdeac8  vmovaps [rsp+0xA0], xmm10
0000705c56fdead1  vmovaps [rsp+0xB0], xmm11
0000705c56fdeada  vmovaps [rsp+0xC0], xmm12
0000705c56fdeae3  vmovaps [rsp+0xD0], xmm13
0000705c56fdeaec  vmovaps [rsp+0xE0], xmm14
0000705c56fdeaf5  sub rsp, 0x30
0000705c56fdeaf9  movaps [rsp], xmm15
0000705c56fdeafe  movaps [rsp+0x10], xmm14
0000705c56fdeb04  movaps [rsp+0x20], xmm4
0000705c56fdeb09  lea rdi, [rsp]
0000705c56fdeb0d  mov esi, 0x00
0000705c56fdeb12  mov rax, 0x5877D3629530
0000705c56fdeb1c  call rax
0000705c56fdeb1e  movaps xmm15, [rsp]
0000705c56fdeb23  add rsp, 0x30
0000705c56fdeb27  vmovaps xmm0, [rsp]
0000705c56fdeb2c  vmovaps xmm1, [rsp+0x10]
0000705c56fdeb32  vmovaps xmm2, [rsp+0x20]
0000705c56fdeb38  vmovaps xmm3, [rsp+0x30]
0000705c56fdeb3e  vmovaps xmm4, [rsp+0x40]
0000705c56fdeb44  vmovaps xmm5, [rsp+0x50]
0000705c56fdeb4a  vmovaps xmm6, [rsp+0x60]
0000705c56fdeb50  vmovaps xmm7, [rsp+0x70]
0000705c56fdeb56  vmovaps xmm8, [rsp+0x80]
0000705c56fdeb5f  vmovaps xmm9, [rsp+0x90]
0000705c56fdeb68  vmovaps xmm10, [rsp+0xA0]
0000705c56fdeb71  vmovaps xmm11, [rsp+0xB0]
0000705c56fdeb7a  vmovaps xmm12, [rsp+0xC0]
0000705c56fdeb83  vmovaps xmm13, [rsp+0xD0]
0000705c56fdeb8c  vmovaps xmm14, [rsp+0xE0]
0000705c56fdeb95  add rsp, 0xF0
0000705c56fdeb9c  pop r11
0000705c56fdeb9e  pop r10
0000705c56fdeba0  pop r9
0000705c56fdeba2  pop r8
0000705c56fdeba4  pop rsi
0000705c56fdeba5  pop rdi
0000705c56fdeba6  pop rdx
0000705c56fdeba7  pop rcx
0000705c56fdeba8  pop rax
0000705c56fdeba9  add rsp, 0x08
0000705c56fdebad  jmp 0x0000705C56FDC2AA
0000705c56fdebb2  sub rsp, 0x08
0000705c56fdebb6  push rax
0000705c56fdebb7  push rcx
0000705c56fdebb8  push rdx
0000705c56fdebb9  push rdi
0000705c56fdebba  push rsi
0000705c56fdebbb  push r8
0000705c56fdebbd  push r9
0000705c56fdebbf  push r10
0000705c56fdebc1  push r11
0000705c56fdebc3  sub rsp, 0xF0
0000705c56fdebca  vmovaps [rsp], xmm0
0000705c56fdebcf  vmovaps [rsp+0x10], xmm1
0000705c56fdebd5  vmovaps [rsp+0x20], xmm2
0000705c56fdebdb  vmovaps [rsp+0x30], xmm3
0000705c56fdebe1  vmovaps [rsp+0x40], xmm4
0000705c56fdebe7  vmovaps [rsp+0x50], xmm5
0000705c56fdebed  vmovaps [rsp+0x60], xmm6
0000705c56fdebf3  vmovaps [rsp+0x70], xmm7
0000705c56fdebf9  vmovaps [rsp+0x80], xmm8
0000705c56fdec02  vmovaps [rsp+0x90], xmm9
0000705c56fdec0b  vmovaps [rsp+0xA0], xmm10
0000705c56fdec14  vmovaps [rsp+0xB0], xmm11
0000705c56fdec1d  vmovaps [rsp+0xC0], xmm12
0000705c56fdec26  vmovaps [rsp+0xD0], xmm13
0000705c56fdec2f  vmovaps [rsp+0xE0], xmm15
0000705c56fdec38  sub rsp, 0x30
0000705c56fdec3c  movaps [rsp], xmm14
0000705c56fdec41  movaps [rsp+0x10], xmm2
0000705c56fdec46  movaps [rsp+0x20], xmm1
0000705c56fdec4b  lea rdi, [rsp]
0000705c56fdec4f  mov esi, 0x00
0000705c56fdec54  mov rax, 0x5877D3629530
0000705c56fdec5e  call rax
0000705c56fdec60  movaps xmm14, [rsp]
0000705c56fdec65  add rsp, 0x30
0000705c56fdec69  vmovaps xmm0, [rsp]
0000705c56fdec6e  vmovaps xmm1, [rsp+0x10]
0000705c56fdec74  vmovaps xmm2, [rsp+0x20]
0000705c56fdec7a  vmovaps xmm3, [rsp+0x30]
0000705c56fdec80  vmovaps xmm4, [rsp+0x40]
0000705c56fdec86  vmovaps xmm5, [rsp+0x50]
0000705c56fdec8c  vmovaps xmm6, [rsp+0x60]
0000705c56fdec92  vmovaps xmm7, [rsp+0x70]
0000705c56fdec98  vmovaps xmm8, [rsp+0x80]
0000705c56fdeca1  vmovaps xmm9, [rsp+0x90]
0000705c56fdecaa  vmovaps xmm10, [rsp+0xA0]
0000705c56fdecb3  vmovaps xmm11, [rsp+0xB0]
0000705c56fdecbc  vmovaps xmm12, [rsp+0xC0]
0000705c56fdecc5  vmovaps xmm13, [rsp+0xD0]
0000705c56fdecce  vmovaps xmm15, [rsp+0xE0]
0000705c56fdecd7  add rsp, 0xF0
0000705c56fdecde  pop r11
0000705c56fdece0  pop r10
0000705c56fdece2  pop r9
0000705c56fdece4  pop r8
0000705c56fdece6  pop rsi
0000705c56fdece7  pop rdi
0000705c56fdece8  pop rdx
0000705c56fdece9  pop rcx
0000705c56fdecea  pop rax
0000705c56fdeceb  add rsp, 0x08
0000705c56fdecef  jmp 0x0000705C56FDC2D0
0000705c56fdecf4  sub rsp, 0x08
0000705c56fdecf8  push rax
0000705c56fdecf9  push rcx
0000705c56fdecfa  push rdx
0000705c56fdecfb  push rdi
0000705c56fdecfc  push rsi
0000705c56fdecfd  push r8
0000705c56fdecff  push r9
0000705c56fded01  push r10
0000705c56fded03  push r11
0000705c56fded05  sub rsp, 0xF0
0000705c56fded0c  vmovaps [rsp], xmm0
0000705c56fded11  vmovaps [rsp+0x10], xmm2
0000705c56fded17  vmovaps [rsp+0x20], xmm3
0000705c56fded1d  vmovaps [rsp+0x30], xmm4
0000705c56fded23  vmovaps [rsp+0x40], xmm5
0000705c56fded29  vmovaps [rsp+0x50], xmm6
0000705c56fded2f  vmovaps [rsp+0x60], xmm7
0000705c56fded35  vmovaps [rsp+0x70], xmm8
0000705c56fded3b  vmovaps [rsp+0x80], xmm9
0000705c56fded44  vmovaps [rsp+0x90], xmm10
0000705c56fded4d  vmovaps [rsp+0xA0], xmm11
0000705c56fded56  vmovaps [rsp+0xB0], xmm12
0000705c56fded5f  vmovaps [rsp+0xC0], xmm13
0000705c56fded68  vmovaps [rsp+0xD0], xmm14
0000705c56fded71  vmovaps [rsp+0xE0], xmm15
0000705c56fded7a  sub rsp, 0x30
0000705c56fded7e  movaps [rsp], xmm1
0000705c56fded82  movaps [rsp+0x10], xmm4
0000705c56fded87  movaps [rsp+0x20], xmm9
0000705c56fded8d  lea rdi, [rsp]
0000705c56fded91  mov esi, 0x00
0000705c56fded96  mov rax, 0x5877D3629530
0000705c56fdeda0  call rax
0000705c56fdeda2  movaps xmm1, [rsp]
0000705c56fdeda6  add rsp, 0x30
0000705c56fdedaa  vmovaps xmm0, [rsp]
0000705c56fdedaf  vmovaps xmm2, [rsp+0x10]
0000705c56fdedb5  vmovaps xmm3, [rsp+0x20]
0000705c56fdedbb  vmovaps xmm4, [rsp+0x30]
0000705c56fdedc1  vmovaps xmm5, [rsp+0x40]
0000705c56fdedc7  vmovaps xmm6, [rsp+0x50]
0000705c56fdedcd  vmovaps xmm7, [rsp+0x60]
0000705c56fdedd3  vmovaps xmm8, [rsp+0x70]
0000705c56fdedd9  vmovaps xmm9, [rsp+0x80]
0000705c56fdede2  vmovaps xmm10, [rsp+0x90]
0000705c56fdedeb  vmovaps xmm11, [rsp+0xA0]
0000705c56fdedf4  vmovaps xmm12, [rsp+0xB0]
0000705c56fdedfd  vmovaps xmm13, [rsp+0xC0]
0000705c56fdee06  vmovaps xmm14, [rsp+0xD0]
0000705c56fdee0f  vmovaps xmm15, [rsp+0xE0]
0000705c56fdee18  add rsp, 0xF0
0000705c56fdee1f  pop r11
0000705c56fdee21  pop r10
0000705c56fdee23  pop r9
0000705c56fdee25  pop r8
0000705c56fdee27  pop rsi
0000705c56fdee28  pop rdi
0000705c56fdee29  pop rdx
0000705c56fdee2a  pop rcx
0000705c56fdee2b  pop rax
0000705c56fdee2c  add rsp, 0x08
0000705c56fdee30  jmp 0x0000705C56FDC2EE
0000705c56fdee35  sub rsp, 0x08
0000705c56fdee39  push rax
0000705c56fdee3a  push rcx
0000705c56fdee3b  push rdx
0000705c56fdee3c  push rdi
0000705c56fdee3d  push rsi
0000705c56fdee3e  push r8
0000705c56fdee40  push r9
0000705c56fdee42  push r10
0000705c56fdee44  push r11
0000705c56fdee46  sub rsp, 0xF0
0000705c56fdee4d  vmovaps [rsp], xmm0
0000705c56fdee52  vmovaps [rsp+0x10], xmm1
0000705c56fdee58  vmovaps [rsp+0x20], xmm2
0000705c56fdee5e  vmovaps [rsp+0x30], xmm3
0000705c56fdee64  vmovaps [rsp+0x40], xmm5
0000705c56fdee6a  vmovaps [rsp+0x50], xmm6
0000705c56fdee70  vmovaps [rsp+0x60], xmm7
0000705c56fdee76  vmovaps [rsp+0x70], xmm8
0000705c56fdee7c  vmovaps [rsp+0x80], xmm9
0000705c56fdee85  vmovaps [rsp+0x90], xmm10
0000705c56fdee8e  vmovaps [rsp+0xA0], xmm11
0000705c56fdee97  vmovaps [rsp+0xB0], xmm12
0000705c56fdeea0  vmovaps [rsp+0xC0], xmm13
0000705c56fdeea9  vmovaps [rsp+0xD0], xmm14
0000705c56fdeeb2  vmovaps [rsp+0xE0], xmm15
0000705c56fdeebb  sub rsp, 0x30
0000705c56fdeebf  movaps [rsp], xmm4
0000705c56fdeec3  movaps [rsp+0x10], xmm2
0000705c56fdeec8  movaps [rsp+0x20], xmm9
0000705c56fdeece  lea rdi, [rsp]
0000705c56fdeed2  mov esi, 0x00
0000705c56fdeed7  mov rax, 0x5877D3629530
0000705c56fdeee1  call rax
0000705c56fdeee3  movaps xmm4, [rsp]
0000705c56fdeee7  add rsp, 0x30
0000705c56fdeeeb  vmovaps xmm0, [rsp]
0000705c56fdeef0  vmovaps xmm1, [rsp+0x10]
0000705c56fdeef6  vmovaps xmm2, [rsp+0x20]
0000705c56fdeefc  vmovaps xmm3, [rsp+0x30]
0000705c56fdef02  vmovaps xmm5, [rsp+0x40]
0000705c56fdef08  vmovaps xmm6, [rsp+0x50]
0000705c56fdef0e  vmovaps xmm7, [rsp+0x60]
0000705c56fdef14  vmovaps xmm8, [rsp+0x70]
0000705c56fdef1a  vmovaps xmm9, [rsp+0x80]
0000705c56fdef23  vmovaps xmm10, [rsp+0x90]
0000705c56fdef2c  vmovaps xmm11, [rsp+0xA0]
0000705c56fdef35  vmovaps xmm12, [rsp+0xB0]
0000705c56fdef3e  vmovaps xmm13, [rsp+0xC0]
0000705c56fdef47  vmovaps xmm14, [rsp+0xD0]
0000705c56fdef50  vmovaps xmm15, [rsp+0xE0]
0000705c56fdef59  add rsp, 0xF0
0000705c56fdef60  pop r11
0000705c56fdef62  pop r10
0000705c56fdef64  pop r9
0000705c56fdef66  pop r8
0000705c56fdef68  pop rsi
0000705c56fdef69  pop rdi
0000705c56fdef6a  pop rdx
0000705c56fdef6b  pop rcx
0000705c56fdef6c  pop rax
0000705c56fdef6d  add rsp, 0x08
0000705c56fdef71  jmp 0x0000705C56FDC31E
0000705c56fdef76  sub rsp, 0x08
0000705c56fdef7a  push rax
0000705c56fdef7b  push rcx
0000705c56fdef7c  push rdx
0000705c56fdef7d  push rdi
0000705c56fdef7e  push rsi
0000705c56fdef7f  push r8
0000705c56fdef81  push r9
0000705c56fdef83  push r10
0000705c56fdef85  push r11
0000705c56fdef87  sub rsp, 0xF0
0000705c56fdef8e  vmovaps [rsp], xmm0
0000705c56fdef93  vmovaps [rsp+0x10], xmm1
0000705c56fdef99  vmovaps [rsp+0x20], xmm2
0000705c56fdef9f  vmovaps [rsp+0x30], xmm3
0000705c56fdefa5  vmovaps [rsp+0x40], xmm4
0000705c56fdefab  vmovaps [rsp+0x50], xmm5
0000705c56fdefb1  vmovaps [rsp+0x60], xmm6
0000705c56fdefb7  vmovaps [rsp+0x70], xmm7
0000705c56fdefbd  vmovaps [rsp+0x80], xmm8
0000705c56fdefc6  vmovaps [rsp+0x90], xmm10
0000705c56fdefcf  vmovaps [rsp+0xA0], xmm11
0000705c56fdefd8  vmovaps [rsp+0xB0], xmm12
0000705c56fdefe1  vmovaps [rsp+0xC0], xmm13
0000705c56fdefea  vmovaps [rsp+0xD0], xmm14
0000705c56fdeff3  vmovaps [rsp+0xE0], xmm15
0000705c56fdeffc  sub rsp, 0x30
0000705c56fdf000  movaps [rsp], xmm9
0000705c56fdf005  movaps [rsp+0x10], xmm2
0000705c56fdf00a  movaps [rsp+0x20], xmm1
0000705c56fdf00f  lea rdi, [rsp]
0000705c56fdf013  mov esi, 0x00
0000705c56fdf018  mov rax, 0x5877D3629530
0000705c56fdf022  call rax
0000705c56fdf024  movaps xmm9, [rsp]
0000705c56fdf029  add rsp, 0x30
0000705c56fdf02d  vmovaps xmm0, [rsp]
0000705c56fdf032  vmovaps xmm1, [rsp+0x10]
0000705c56fdf038  vmovaps xmm2, [rsp+0x20]
0000705c56fdf03e  vmovaps xmm3, [rsp+0x30]
0000705c56fdf044  vmovaps xmm4, [rsp+0x40]
0000705c56fdf04a  vmovaps xmm5, [rsp+0x50]
0000705c56fdf050  vmovaps xmm6, [rsp+0x60]
0000705c56fdf056  vmovaps xmm7, [rsp+0x70]
0000705c56fdf05c  vmovaps xmm8, [rsp+0x80]
0000705c56fdf065  vmovaps xmm10, [rsp+0x90]
0000705c56fdf06e  vmovaps xmm11, [rsp+0xA0]
0000705c56fdf077  vmovaps xmm12, [rsp+0xB0]
0000705c56fdf080  vmovaps xmm13, [rsp+0xC0]
0000705c56fdf089  vmovaps xmm14, [rsp+0xD0]
0000705c56fdf092  vmovaps xmm15, [rsp+0xE0]
0000705c56fdf09b  add rsp, 0xF0
0000705c56fdf0a2  pop r11
0000705c56fdf0a4  pop r10
0000705c56fdf0a6  pop r9
0000705c56fdf0a8  pop r8
0000705c56fdf0aa  pop rsi
0000705c56fdf0ab  pop rdi
0000705c56fdf0ac  pop rdx
0000705c56fdf0ad  pop rcx
0000705c56fdf0ae  pop rax
0000705c56fdf0af  add rsp, 0x08
0000705c56fdf0b3  jmp 0x0000705C56FDC354
0000705c56fdf0b8  sub rsp, 0x08
0000705c56fdf0bc  push rax
0000705c56fdf0bd  push rcx
0000705c56fdf0be  push rdx
0000705c56fdf0bf  push rdi
0000705c56fdf0c0  push rsi
0000705c56fdf0c1  push r8
0000705c56fdf0c3  push r9
0000705c56fdf0c5  push r10
0000705c56fdf0c7  push r11
0000705c56fdf0c9  sub rsp, 0xF0
0000705c56fdf0d0  vmovaps [rsp], xmm0
0000705c56fdf0d5  vmovaps [rsp+0x10], xmm2
0000705c56fdf0db  vmovaps [rsp+0x20], xmm3
0000705c56fdf0e1  vmovaps [rsp+0x30], xmm4
0000705c56fdf0e7  vmovaps [rsp+0x40], xmm5
0000705c56fdf0ed  vmovaps [rsp+0x50], xmm6
0000705c56fdf0f3  vmovaps [rsp+0x60], xmm7
0000705c56fdf0f9  vmovaps [rsp+0x70], xmm8
0000705c56fdf0ff  vmovaps [rsp+0x80], xmm9
0000705c56fdf108  vmovaps [rsp+0x90], xmm10
0000705c56fdf111  vmovaps [rsp+0xA0], xmm11
0000705c56fdf11a  vmovaps [rsp+0xB0], xmm12
0000705c56fdf123  vmovaps [rsp+0xC0], xmm13
0000705c56fdf12c  vmovaps [rsp+0xD0], xmm14
0000705c56fdf135  vmovaps [rsp+0xE0], xmm15
0000705c56fdf13e  sub rsp, 0x30
0000705c56fdf142  movaps [rsp], xmm1
0000705c56fdf146  movaps [rsp+0x10], xmm15
0000705c56fdf14c  movaps [rsp+0x20], xmm6
0000705c56fdf151  lea rdi, [rsp]
0000705c56fdf155  mov esi, 0x00
0000705c56fdf15a  mov rax, 0x5877D3629530
0000705c56fdf164  call rax
0000705c56fdf166  movaps xmm1, [rsp]
0000705c56fdf16a  add rsp, 0x30
0000705c56fdf16e  vmovaps xmm0, [rsp]
0000705c56fdf173  vmovaps xmm2, [rsp+0x10]
0000705c56fdf179  vmovaps xmm3, [rsp+0x20]
0000705c56fdf17f  vmovaps xmm4, [rsp+0x30]
0000705c56fdf185  vmovaps xmm5, [rsp+0x40]
0000705c56fdf18b  vmovaps xmm6, [rsp+0x50]
0000705c56fdf191  vmovaps xmm7, [rsp+0x60]
0000705c56fdf197  vmovaps xmm8, [rsp+0x70]
0000705c56fdf19d  vmovaps xmm9, [rsp+0x80]
0000705c56fdf1a6  vmovaps xmm10, [rsp+0x90]
0000705c56fdf1af  vmovaps xmm11, [rsp+0xA0]
0000705c56fdf1b8  vmovaps xmm12, [rsp+0xB0]
0000705c56fdf1c1  vmovaps xmm13, [rsp+0xC0]
0000705c56fdf1ca  vmovaps xmm14, [rsp+0xD0]
0000705c56fdf1d3  vmovaps xmm15, [rsp+0xE0]
0000705c56fdf1dc  add rsp, 0xF0
0000705c56fdf1e3  pop r11
0000705c56fdf1e5  pop r10
0000705c56fdf1e7  pop r9
0000705c56fdf1e9  pop r8
0000705c56fdf1eb  pop rsi
0000705c56fdf1ec  pop rdi
0000705c56fdf1ed  pop rdx
0000705c56fdf1ee  pop rcx
0000705c56fdf1ef  pop rax
0000705c56fdf1f0  add rsp, 0x08
0000705c56fdf1f4  jmp 0x0000705C56FDC375
0000705c56fdf1f9  sub rsp, 0x08
0000705c56fdf1fd  push rax
0000705c56fdf1fe  push rcx
0000705c56fdf1ff  push rdx
0000705c56fdf200  push rdi
0000705c56fdf201  push rsi
0000705c56fdf202  push r8
0000705c56fdf204  push r9
0000705c56fdf206  push r10
0000705c56fdf208  push r11
0000705c56fdf20a  sub rsp, 0xF0
0000705c56fdf211  vmovaps [rsp], xmm0
0000705c56fdf216  vmovaps [rsp+0x10], xmm1
0000705c56fdf21c  vmovaps [rsp+0x20], xmm2
0000705c56fdf222  vmovaps [rsp+0x30], xmm3
0000705c56fdf228  vmovaps [rsp+0x40], xmm4
0000705c56fdf22e  vmovaps [rsp+0x50], xmm5
0000705c56fdf234  vmovaps [rsp+0x60], xmm6
0000705c56fdf23a  vmovaps [rsp+0x70], xmm7
0000705c56fdf240  vmovaps [rsp+0x80], xmm8
0000705c56fdf249  vmovaps [rsp+0x90], xmm9
0000705c56fdf252  vmovaps [rsp+0xA0], xmm10
0000705c56fdf25b  vmovaps [rsp+0xB0], xmm11
0000705c56fdf264  vmovaps [rsp+0xC0], xmm12
0000705c56fdf26d  vmovaps [rsp+0xD0], xmm13
0000705c56fdf276  vmovaps [rsp+0xE0], xmm14
0000705c56fdf27f  sub rsp, 0x30
0000705c56fdf283  movaps [rsp], xmm15
0000705c56fdf288  movaps [rsp+0x10], xmm5
0000705c56fdf28d  movaps [rsp+0x20], xmm3
0000705c56fdf292  lea rdi, [rsp]
0000705c56fdf296  mov esi, 0x00
0000705c56fdf29b  mov rax, 0x5877D3629530
0000705c56fdf2a5  call rax
0000705c56fdf2a7  movaps xmm15, [rsp]
0000705c56fdf2ac  add rsp, 0x30
0000705c56fdf2b0  vmovaps xmm0, [rsp]
0000705c56fdf2b5  vmovaps xmm1, [rsp+0x10]
0000705c56fdf2bb  vmovaps xmm2, [rsp+0x20]
0000705c56fdf2c1  vmovaps xmm3, [rsp+0x30]
0000705c56fdf2c7  vmovaps xmm4, [rsp+0x40]
0000705c56fdf2cd  vmovaps xmm5, [rsp+0x50]
0000705c56fdf2d3  vmovaps xmm6, [rsp+0x60]
0000705c56fdf2d9  vmovaps xmm7, [rsp+0x70]
0000705c56fdf2df  vmovaps xmm8, [rsp+0x80]
0000705c56fdf2e8  vmovaps xmm9, [rsp+0x90]
0000705c56fdf2f1  vmovaps xmm10, [rsp+0xA0]
0000705c56fdf2fa  vmovaps xmm11, [rsp+0xB0]
0000705c56fdf303  vmovaps xmm12, [rsp+0xC0]
0000705c56fdf30c  vmovaps xmm13, [rsp+0xD0]
0000705c56fdf315  vmovaps xmm14, [rsp+0xE0]
0000705c56fdf31e  add rsp, 0xF0
0000705c56fdf325  pop r11
0000705c56fdf327  pop r10
0000705c56fdf329  pop r9
0000705c56fdf32b  pop r8
0000705c56fdf32d  pop rsi
0000705c56fdf32e  pop rdi
0000705c56fdf32f  pop rdx
0000705c56fdf330  pop rcx
0000705c56fdf331  pop rax
0000705c56fdf332  add rsp, 0x08
0000705c56fdf336  jmp 0x0000705C56FDC38F
0000705c56fdf33b  sub rsp, 0x08
0000705c56fdf33f  push rax
0000705c56fdf340  push rcx
0000705c56fdf341  push rdx
0000705c56fdf342  push rdi
0000705c56fdf343  push rsi
0000705c56fdf344  push r8
0000705c56fdf346  push r9
0000705c56fdf348  push r10
0000705c56fdf34a  push r11
0000705c56fdf34c  sub rsp, 0xF0
0000705c56fdf353  vmovaps [rsp], xmm0
0000705c56fdf358  vmovaps [rsp+0x10], xmm1
0000705c56fdf35e  vmovaps [rsp+0x20], xmm2
0000705c56fdf364  vmovaps [rsp+0x30], xmm3
0000705c56fdf36a  vmovaps [rsp+0x40], xmm4
0000705c56fdf370  vmovaps [rsp+0x50], xmm6
0000705c56fdf376  vmovaps [rsp+0x60], xmm7
0000705c56fdf37c  vmovaps [rsp+0x70], xmm8
0000705c56fdf382  vmovaps [rsp+0x80], xmm9
0000705c56fdf38b  vmovaps [rsp+0x90], xmm10
0000705c56fdf394  vmovaps [rsp+0xA0], xmm11
0000705c56fdf39d  vmovaps [rsp+0xB0], xmm12
0000705c56fdf3a6  vmovaps [rsp+0xC0], xmm13
0000705c56fdf3af  vmovaps [rsp+0xD0], xmm14
0000705c56fdf3b8  vmovaps [rsp+0xE0], xmm15
0000705c56fdf3c1  sub rsp, 0x30
0000705c56fdf3c5  movaps [rsp], xmm5
0000705c56fdf3c9  movaps [rsp+0x10], xmm8
0000705c56fdf3cf  movaps [rsp+0x20], xmm6
0000705c56fdf3d4  lea rdi, [rsp]
0000705c56fdf3d8  mov esi, 0x00
0000705c56fdf3dd  mov rax, 0x5877D3629530
0000705c56fdf3e7  call rax
0000705c56fdf3e9  movaps xmm5, [rsp]
0000705c56fdf3ed  add rsp, 0x30
0000705c56fdf3f1  vmovaps xmm0, [rsp]
0000705c56fdf3f6  vmovaps xmm1, [rsp+0x10]
0000705c56fdf3fc  vmovaps xmm2, [rsp+0x20]
0000705c56fdf402  vmovaps xmm3, [rsp+0x30]
0000705c56fdf408  vmovaps xmm4, [rsp+0x40]
0000705c56fdf40e  vmovaps xmm6, [rsp+0x50]
0000705c56fdf414  vmovaps xmm7, [rsp+0x60]
0000705c56fdf41a  vmovaps xmm8, [rsp+0x70]
0000705c56fdf420  vmovaps xmm9, [rsp+0x80]
0000705c56fdf429  vmovaps xmm10, [rsp+0x90]
0000705c56fdf432  vmovaps xmm11, [rsp+0xA0]
0000705c56fdf43b  vmovaps xmm12, [rsp+0xB0]
0000705c56fdf444  vmovaps xmm13, [rsp+0xC0]
0000705c56fdf44d  vmovaps xmm14, [rsp+0xD0]
0000705c56fdf456  vmovaps xmm15, [rsp+0xE0]
0000705c56fdf45f  add rsp, 0xF0
0000705c56fdf466  pop r11
0000705c56fdf468  pop r10
0000705c56fdf46a  pop r9
0000705c56fdf46c  pop r8
0000705c56fdf46e  pop rsi
0000705c56fdf46f  pop rdi
0000705c56fdf470  pop rdx
0000705c56fdf471  pop rcx
0000705c56fdf472  pop rax
0000705c56fdf473  add rsp, 0x08
0000705c56fdf477  jmp 0x0000705C56FDC3B3
0000705c56fdf47c  sub rsp, 0x08
0000705c56fdf480  push rax
0000705c56fdf481  push rcx
0000705c56fdf482  push rdx
0000705c56fdf483  push rdi
0000705c56fdf484  push rsi
0000705c56fdf485  push r8
0000705c56fdf487  push r9
0000705c56fdf489  push r10
0000705c56fdf48b  push r11
0000705c56fdf48d  sub rsp, 0xF0
0000705c56fdf494  vmovaps [rsp], xmm0
0000705c56fdf499  vmovaps [rsp+0x10], xmm1
0000705c56fdf49f  vmovaps [rsp+0x20], xmm2
0000705c56fdf4a5  vmovaps [rsp+0x30], xmm3
0000705c56fdf4ab  vmovaps [rsp+0x40], xmm4
0000705c56fdf4b1  vmovaps [rsp+0x50], xmm5
0000705c56fdf4b7  vmovaps [rsp+0x60], xmm7
0000705c56fdf4bd  vmovaps [rsp+0x70], xmm8
0000705c56fdf4c3  vmovaps [rsp+0x80], xmm9
0000705c56fdf4cc  vmovaps [rsp+0x90], xmm10
0000705c56fdf4d5  vmovaps [rsp+0xA0], xmm11
0000705c56fdf4de  vmovaps [rsp+0xB0], xmm12
0000705c56fdf4e7  vmovaps [rsp+0xC0], xmm13
0000705c56fdf4f0  vmovaps [rsp+0xD0], xmm14
0000705c56fdf4f9  vmovaps [rsp+0xE0], xmm15
0000705c56fdf502  sub rsp, 0x30
0000705c56fdf506  movaps [rsp], xmm6
0000705c56fdf50a  movaps [rsp+0x10], xmm10
0000705c56fdf510  movaps [rsp+0x20], xmm8
0000705c56fdf516  lea rdi, [rsp]
0000705c56fdf51a  mov esi, 0x00
0000705c56fdf51f  mov rax, 0x5877D3629530
0000705c56fdf529  call rax
0000705c56fdf52b  movaps xmm6, [rsp]
0000705c56fdf52f  add rsp, 0x30
0000705c56fdf533  vmovaps xmm0, [rsp]
0000705c56fdf538  vmovaps xmm1, [rsp+0x10]
0000705c56fdf53e  vmovaps xmm2, [rsp+0x20]
0000705c56fdf544  vmovaps xmm3, [rsp+0x30]
0000705c56fdf54a  vmovaps xmm4, [rsp+0x40]
0000705c56fdf550  vmovaps xmm5, [rsp+0x50]
0000705c56fdf556  vmovaps xmm7, [rsp+0x60]
0000705c56fdf55c  vmovaps xmm8, [rsp+0x70]
0000705c56fdf562  vmovaps xmm9, [rsp+0x80]
0000705c56fdf56b  vmovaps xmm10, [rsp+0x90]
0000705c56fdf574  vmovaps xmm11, [rsp+0xA0]
0000705c56fdf57d  vmovaps xmm12, [rsp+0xB0]
0000705c56fdf586  vmovaps xmm13, [rsp+0xC0]
0000705c56fdf58f  vmovaps xmm14, [rsp+0xD0]
0000705c56fdf598  vmovaps xmm15, [rsp+0xE0]
0000705c56fdf5a1  add rsp, 0xF0
0000705c56fdf5a8  pop r11
0000705c56fdf5aa  pop r10
0000705c56fdf5ac  pop r9
0000705c56fdf5ae  pop r8
0000705c56fdf5b0  pop rsi
0000705c56fdf5b1  pop rdi
0000705c56fdf5b2  pop rdx
0000705c56fdf5b3  pop rcx
0000705c56fdf5b4  pop rax
0000705c56fdf5b5  add rsp, 0x08
0000705c56fdf5b9  jmp 0x0000705C56FDC3D8
0000705c56fdf5be  sub rsp, 0x08
0000705c56fdf5c2  push rax
0000705c56fdf5c3  push rcx
0000705c56fdf5c4  push rdx
0000705c56fdf5c5  push rdi
0000705c56fdf5c6  push rsi
0000705c56fdf5c7  push r8
0000705c56fdf5c9  push r9
0000705c56fdf5cb  push r10
0000705c56fdf5cd  push r11
0000705c56fdf5cf  sub rsp, 0xF0
0000705c56fdf5d6  vmovaps [rsp], xmm0
0000705c56fdf5db  vmovaps [rsp+0x10], xmm1
0000705c56fdf5e1  vmovaps [rsp+0x20], xmm2
0000705c56fdf5e7  vmovaps [rsp+0x30], xmm3
0000705c56fdf5ed  vmovaps [rsp+0x40], xmm4
0000705c56fdf5f3  vmovaps [rsp+0x50], xmm5
0000705c56fdf5f9  vmovaps [rsp+0x60], xmm6
0000705c56fdf5ff  vmovaps [rsp+0x70], xmm7
0000705c56fdf605  vmovaps [rsp+0x80], xmm8
0000705c56fdf60e  vmovaps [rsp+0x90], xmm9
0000705c56fdf617  vmovaps [rsp+0xA0], xmm11
0000705c56fdf620  vmovaps [rsp+0xB0], xmm12
0000705c56fdf629  vmovaps [rsp+0xC0], xmm13
0000705c56fdf632  vmovaps [rsp+0xD0], xmm14
0000705c56fdf63b  vmovaps [rsp+0xE0], xmm15
0000705c56fdf644  sub rsp, 0x30
0000705c56fdf648  movaps [rsp], xmm10
0000705c56fdf64d  movaps [rsp+0x10], xmm8
0000705c56fdf653  movaps [rsp+0x20], xmm14
0000705c56fdf659  lea rdi, [rsp]
0000705c56fdf65d  mov esi, 0x00
0000705c56fdf662  mov rax, 0x5877D3629530
0000705c56fdf66c  call rax
0000705c56fdf66e  movaps xmm10, [rsp]
0000705c56fdf673  add rsp, 0x30
0000705c56fdf677  vmovaps xmm0, [rsp]
0000705c56fdf67c  vmovaps xmm1, [rsp+0x10]
0000705c56fdf682  vmovaps xmm2, [rsp+0x20]
0000705c56fdf688  vmovaps xmm3, [rsp+0x30]
0000705c56fdf68e  vmovaps xmm4, [rsp+0x40]
0000705c56fdf694  vmovaps xmm5, [rsp+0x50]
0000705c56fdf69a  vmovaps xmm6, [rsp+0x60]
0000705c56fdf6a0  vmovaps xmm7, [rsp+0x70]
0000705c56fdf6a6  vmovaps xmm8, [rsp+0x80]
0000705c56fdf6af  vmovaps xmm9, [rsp+0x90]
0000705c56fdf6b8  vmovaps xmm11, [rsp+0xA0]
0000705c56fdf6c1  vmovaps xmm12, [rsp+0xB0]
0000705c56fdf6ca  vmovaps xmm13, [rsp+0xC0]
0000705c56fdf6d3  vmovaps xmm14, [rsp+0xD0]
0000705c56fdf6dc  vmovaps xmm15, [rsp+0xE0]
0000705c56fdf6e5  add rsp, 0xF0
0000705c56fdf6ec  pop r11
0000705c56fdf6ee  pop r10
0000705c56fdf6f0  pop r9
0000705c56fdf6f2  pop r8
0000705c56fdf6f4  pop rsi
0000705c56fdf6f5  pop rdi
0000705c56fdf6f6  pop rdx
0000705c56fdf6f7  pop rcx
0000705c56fdf6f8  pop rax
0000705c56fdf6f9  add rsp, 0x08
0000705c56fdf6fd  jmp 0x0000705C56FDC3F8
0000705c56fdf702  sub rsp, 0x08
0000705c56fdf706  push rax
0000705c56fdf707  push rcx
0000705c56fdf708  push rdx
0000705c56fdf709  push rdi
0000705c56fdf70a  push rsi
0000705c56fdf70b  push r8
0000705c56fdf70d  push r9
0000705c56fdf70f  push r10
0000705c56fdf711  push r11
0000705c56fdf713  sub rsp, 0xF0
0000705c56fdf71a  vmovaps [rsp], xmm0
0000705c56fdf71f  vmovaps [rsp+0x10], xmm1
0000705c56fdf725  vmovaps [rsp+0x20], xmm2
0000705c56fdf72b  vmovaps [rsp+0x30], xmm3
0000705c56fdf731  vmovaps [rsp+0x40], xmm4
0000705c56fdf737  vmovaps [rsp+0x50], xmm5
0000705c56fdf73d  vmovaps [rsp+0x60], xmm6
0000705c56fdf743  vmovaps [rsp+0x70], xmm7
0000705c56fdf749  vmovaps [rsp+0x80], xmm8
0000705c56fdf752  vmovaps [rsp+0x90], xmm9
0000705c56fdf75b  vmovaps [rsp+0xA0], xmm10
0000705c56fdf764  vmovaps [rsp+0xB0], xmm11
0000705c56fdf76d  vmovaps [rsp+0xC0], xmm12
0000705c56fdf776  vmovaps [rsp+0xD0], xmm13
0000705c56fdf77f  vmovaps [rsp+0xE0], xmm15
0000705c56fdf788  sub rsp, 0x30
0000705c56fdf78c  movaps [rsp], xmm14
0000705c56fdf791  movaps [rsp+0x10], xmm8
0000705c56fdf797  movaps [rsp+0x20], xmm4
0000705c56fdf79c  lea rdi, [rsp]
0000705c56fdf7a0  mov esi, 0x00
0000705c56fdf7a5  mov rax, 0x5877D3629530
0000705c56fdf7af  call rax
0000705c56fdf7b1  movaps xmm14, [rsp]
0000705c56fdf7b6  add rsp, 0x30
0000705c56fdf7ba  vmovaps xmm0, [rsp]
0000705c56fdf7bf  vmovaps xmm1, [rsp+0x10]
0000705c56fdf7c5  vmovaps xmm2, [rsp+0x20]
0000705c56fdf7cb  vmovaps xmm3, [rsp+0x30]
0000705c56fdf7d1  vmovaps xmm4, [rsp+0x40]
0000705c56fdf7d7  vmovaps xmm5, [rsp+0x50]
0000705c56fdf7dd  vmovaps xmm6, [rsp+0x60]
0000705c56fdf7e3  vmovaps xmm7, [rsp+0x70]
0000705c56fdf7e9  vmovaps xmm8, [rsp+0x80]
0000705c56fdf7f2  vmovaps xmm9, [rsp+0x90]
0000705c56fdf7fb  vmovaps xmm10, [rsp+0xA0]
0000705c56fdf804  vmovaps xmm11, [rsp+0xB0]
0000705c56fdf80d  vmovaps xmm12, [rsp+0xC0]
0000705c56fdf816  vmovaps xmm13, [rsp+0xD0]
0000705c56fdf81f  vmovaps xmm15, [rsp+0xE0]
0000705c56fdf828  add rsp, 0xF0
0000705c56fdf82f  pop r11
0000705c56fdf831  pop r10
0000705c56fdf833  pop r9
0000705c56fdf835  pop r8
0000705c56fdf837  pop rsi
0000705c56fdf838  pop rdi
0000705c56fdf839  pop rdx
0000705c56fdf83a  pop rcx
0000705c56fdf83b  pop rax
0000705c56fdf83c  add rsp, 0x08
0000705c56fdf840  jmp 0x0000705C56FDC418
0000705c56fdf845  sub rsp, 0x08
0000705c56fdf849  push rax
0000705c56fdf84a  push rcx
0000705c56fdf84b  push rdx
0000705c56fdf84c  push rdi
0000705c56fdf84d  push rsi
0000705c56fdf84e  push r8
0000705c56fdf850  push r9
0000705c56fdf852  push r10
0000705c56fdf854  push r11
0000705c56fdf856  sub rsp, 0xF0
0000705c56fdf85d  vmovaps [rsp], xmm0
0000705c56fdf862  vmovaps [rsp+0x10], xmm1
0000705c56fdf868  vmovaps [rsp+0x20], xmm2
0000705c56fdf86e  vmovaps [rsp+0x30], xmm3
0000705c56fdf874  vmovaps [rsp+0x40], xmm5
0000705c56fdf87a  vmovaps [rsp+0x50], xmm6
0000705c56fdf880  vmovaps [rsp+0x60], xmm7
0000705c56fdf886  vmovaps [rsp+0x70], xmm8
0000705c56fdf88c  vmovaps [rsp+0x80], xmm9
0000705c56fdf895  vmovaps [rsp+0x90], xmm10
0000705c56fdf89e  vmovaps [rsp+0xA0], xmm11
0000705c56fdf8a7  vmovaps [rsp+0xB0], xmm12
0000705c56fdf8b0  vmovaps [rsp+0xC0], xmm13
0000705c56fdf8b9  vmovaps [rsp+0xD0], xmm14
0000705c56fdf8c2  vmovaps [rsp+0xE0], xmm15
0000705c56fdf8cb  sub rsp, 0x30
0000705c56fdf8cf  movaps [rsp], xmm4
0000705c56fdf8d3  movaps [rsp+0x10], xmm13
0000705c56fdf8d9  movaps [rsp+0x20], xmm8
0000705c56fdf8df  lea rdi, [rsp]
0000705c56fdf8e3  mov esi, 0x00
0000705c56fdf8e8  mov rax, 0x5877D3629530
0000705c56fdf8f2  call rax
0000705c56fdf8f4  movaps xmm4, [rsp]
0000705c56fdf8f8  add rsp, 0x30
0000705c56fdf8fc  vmovaps xmm0, [rsp]
0000705c56fdf901  vmovaps xmm1, [rsp+0x10]
0000705c56fdf907  vmovaps xmm2, [rsp+0x20]
0000705c56fdf90d  vmovaps xmm3, [rsp+0x30]
0000705c56fdf913  vmovaps xmm5, [rsp+0x40]
0000705c56fdf919  vmovaps xmm6, [rsp+0x50]
0000705c56fdf91f  vmovaps xmm7, [rsp+0x60]
0000705c56fdf925  vmovaps xmm8, [rsp+0x70]
0000705c56fdf92b  vmovaps xmm9, [rsp+0x80]
0000705c56fdf934  vmovaps xmm10, [rsp+0x90]
0000705c56fdf93d  vmovaps xmm11, [rsp+0xA0]
0000705c56fdf946  vmovaps xmm12, [rsp+0xB0]
0000705c56fdf94f  vmovaps xmm13, [rsp+0xC0]
0000705c56fdf958  vmovaps xmm14, [rsp+0xD0]
0000705c56fdf961  vmovaps xmm15, [rsp+0xE0]
0000705c56fdf96a  add rsp, 0xF0
0000705c56fdf971  pop r11
0000705c56fdf973  pop r10
0000705c56fdf975  pop r9
0000705c56fdf977  pop r8
0000705c56fdf979  pop rsi
0000705c56fdf97a  pop rdi
0000705c56fdf97b  pop rdx
0000705c56fdf97c  pop rcx
0000705c56fdf97d  pop rax
0000705c56fdf97e  add rsp, 0x08
0000705c56fdf982  jmp 0x0000705C56FDC43D
0000705c56fdf987  sub rsp, 0x08
0000705c56fdf98b  push rax
0000705c56fdf98c  push rcx
0000705c56fdf98d  push rdx
0000705c56fdf98e  push rdi
0000705c56fdf98f  push rsi
0000705c56fdf990  push r8
0000705c56fdf992  push r9
0000705c56fdf994  push r10
0000705c56fdf996  push r11
0000705c56fdf998  sub rsp, 0xF0
0000705c56fdf99f  vmovaps [rsp], xmm0
0000705c56fdf9a4  vmovaps [rsp+0x10], xmm1
0000705c56fdf9aa  vmovaps [rsp+0x20], xmm2
0000705c56fdf9b0  vmovaps [rsp+0x30], xmm3
0000705c56fdf9b6  vmovaps [rsp+0x40], xmm4
0000705c56fdf9bc  vmovaps [rsp+0x50], xmm5
0000705c56fdf9c2  vmovaps [rsp+0x60], xmm6
0000705c56fdf9c8  vmovaps [rsp+0x70], xmm7
0000705c56fdf9ce  vmovaps [rsp+0x80], xmm8
0000705c56fdf9d7  vmovaps [rsp+0x90], xmm9
0000705c56fdf9e0  vmovaps [rsp+0xA0], xmm10
0000705c56fdf9e9  vmovaps [rsp+0xB0], xmm11
0000705c56fdf9f2  vmovaps [rsp+0xC0], xmm12
0000705c56fdf9fb  vmovaps [rsp+0xD0], xmm14
0000705c56fdfa04  vmovaps [rsp+0xE0], xmm15
0000705c56fdfa0d  sub rsp, 0x30
0000705c56fdfa11  movaps [rsp], xmm13
0000705c56fdfa16  movaps [rsp+0x10], xmm15
0000705c56fdfa1c  movaps [rsp+0x20], xmm9
0000705c56fdfa22  lea rdi, [rsp]
0000705c56fdfa26  mov esi, 0x00
0000705c56fdfa2b  mov rax, 0x5877D3629530
0000705c56fdfa35  call rax
0000705c56fdfa37  movaps xmm13, [rsp]
0000705c56fdfa3c  add rsp, 0x30
0000705c56fdfa40  vmovaps xmm0, [rsp]
0000705c56fdfa45  vmovaps xmm1, [rsp+0x10]
0000705c56fdfa4b  vmovaps xmm2, [rsp+0x20]
0000705c56fdfa51  vmovaps xmm3, [rsp+0x30]
0000705c56fdfa57  vmovaps xmm4, [rsp+0x40]
0000705c56fdfa5d  vmovaps xmm5, [rsp+0x50]
0000705c56fdfa63  vmovaps xmm6, [rsp+0x60]
0000705c56fdfa69  vmovaps xmm7, [rsp+0x70]
0000705c56fdfa6f  vmovaps xmm8, [rsp+0x80]
0000705c56fdfa78  vmovaps xmm9, [rsp+0x90]
0000705c56fdfa81  vmovaps xmm10, [rsp+0xA0]
0000705c56fdfa8a  vmovaps xmm11, [rsp+0xB0]
0000705c56fdfa93  vmovaps xmm12, [rsp+0xC0]
0000705c56fdfa9c  vmovaps xmm14, [rsp+0xD0]
0000705c56fdfaa5  vmovaps xmm15, [rsp+0xE0]
0000705c56fdfaae  add rsp, 0xF0
0000705c56fdfab5  pop r11
0000705c56fdfab7  pop r10
0000705c56fdfab9  pop r9
0000705c56fdfabb  pop r8
0000705c56fdfabd  pop rsi
0000705c56fdfabe  pop rdi
0000705c56fdfabf  pop rdx
0000705c56fdfac0  pop rcx
0000705c56fdfac1  pop rax
0000705c56fdfac2  add rsp, 0x08
0000705c56fdfac6  jmp 0x0000705C56FDC458
0000705c56fdfacb  sub rsp, 0x08
0000705c56fdfacf  push rax
0000705c56fdfad0  push rcx
0000705c56fdfad1  push rdx
0000705c56fdfad2  push rdi
0000705c56fdfad3  push rsi
0000705c56fdfad4  push r8
0000705c56fdfad6  push r9
0000705c56fdfad8  push r10
0000705c56fdfada  push r11
0000705c56fdfadc  sub rsp, 0xF0
0000705c56fdfae3  vmovaps [rsp], xmm0
0000705c56fdfae8  vmovaps [rsp+0x10], xmm1
0000705c56fdfaee  vmovaps [rsp+0x20], xmm2
0000705c56fdfaf4  vmovaps [rsp+0x30], xmm3
0000705c56fdfafa  vmovaps [rsp+0x40], xmm4
0000705c56fdfb00  vmovaps [rsp+0x50], xmm5
0000705c56fdfb06  vmovaps [rsp+0x60], xmm6
0000705c56fdfb0c  vmovaps [rsp+0x70], xmm7
0000705c56fdfb12  vmovaps [rsp+0x80], xmm8
0000705c56fdfb1b  vmovaps [rsp+0x90], xmm9
0000705c56fdfb24  vmovaps [rsp+0xA0], xmm10
0000705c56fdfb2d  vmovaps [rsp+0xB0], xmm11
0000705c56fdfb36  vmovaps [rsp+0xC0], xmm12
0000705c56fdfb3f  vmovaps [rsp+0xD0], xmm13
0000705c56fdfb48  vmovaps [rsp+0xE0], xmm14
0000705c56fdfb51  sub rsp, 0x30
0000705c56fdfb55  movaps [rsp], xmm15
0000705c56fdfb5a  movaps [rsp+0x10], xmm1
0000705c56fdfb5f  movaps [rsp+0x20], xmm5
0000705c56fdfb64  lea rdi, [rsp]
0000705c56fdfb68  mov esi, 0x00
0000705c56fdfb6d  mov rax, 0x5877D3629530
0000705c56fdfb77  call rax
0000705c56fdfb79  movaps xmm15, [rsp]
0000705c56fdfb7e  add rsp, 0x30
0000705c56fdfb82  vmovaps xmm0, [rsp]
0000705c56fdfb87  vmovaps xmm1, [rsp+0x10]
0000705c56fdfb8d  vmovaps xmm2, [rsp+0x20]
0000705c56fdfb93  vmovaps xmm3, [rsp+0x30]
0000705c56fdfb99  vmovaps xmm4, [rsp+0x40]
0000705c56fdfb9f  vmovaps xmm5, [rsp+0x50]
0000705c56fdfba5  vmovaps xmm6, [rsp+0x60]
0000705c56fdfbab  vmovaps xmm7, [rsp+0x70]
0000705c56fdfbb1  vmovaps xmm8, [rsp+0x80]
0000705c56fdfbba  vmovaps xmm9, [rsp+0x90]
0000705c56fdfbc3  vmovaps xmm10, [rsp+0xA0]
0000705c56fdfbcc  vmovaps xmm11, [rsp+0xB0]
0000705c56fdfbd5  vmovaps xmm12, [rsp+0xC0]
0000705c56fdfbde  vmovaps xmm13, [rsp+0xD0]
0000705c56fdfbe7  vmovaps xmm14, [rsp+0xE0]
0000705c56fdfbf0  add rsp, 0xF0
0000705c56fdfbf7  pop r11
0000705c56fdfbf9  pop r10
0000705c56fdfbfb  pop r9
0000705c56fdfbfd  pop r8
0000705c56fdfbff  pop rsi
0000705c56fdfc00  pop rdi
0000705c56fdfc01  pop rdx
0000705c56fdfc02  pop rcx
0000705c56fdfc03  pop rax
0000705c56fdfc04  add rsp, 0x08
0000705c56fdfc08  jmp 0x0000705C56FDC473
0000705c56fdfc0d  call 0x0000705C56EB52F0
0000705c56fdfc12  jmp 0x0000705C56FDC4CE
0000705c56fdfc17  sub rsp, 0x08
0000705c56fdfc1b  push rax
0000705c56fdfc1c  push rcx
0000705c56fdfc1d  push rdx
0000705c56fdfc1e  push rdi
0000705c56fdfc1f  push rsi
0000705c56fdfc20  push r8
0000705c56fdfc22  push r9
0000705c56fdfc24  push r10
0000705c56fdfc26  push r11
0000705c56fdfc28  sub rsp, 0xF0
0000705c56fdfc2f  vmovaps [rsp], xmm0
0000705c56fdfc34  vmovaps [rsp+0x10], xmm1
0000705c56fdfc3a  vmovaps [rsp+0x20], xmm2
0000705c56fdfc40  vmovaps [rsp+0x30], xmm3
0000705c56fdfc46  vmovaps [rsp+0x40], xmm4
0000705c56fdfc4c  vmovaps [rsp+0x50], xmm5
0000705c56fdfc52  vmovaps [rsp+0x60], xmm6
0000705c56fdfc58  vmovaps [rsp+0x70], xmm7
0000705c56fdfc5e  vmovaps [rsp+0x80], xmm8
0000705c56fdfc67  vmovaps [rsp+0x90], xmm10
0000705c56fdfc70  vmovaps [rsp+0xA0], xmm11
0000705c56fdfc79  vmovaps [rsp+0xB0], xmm12
0000705c56fdfc82  vmovaps [rsp+0xC0], xmm13
0000705c56fdfc8b  vmovaps [rsp+0xD0], xmm14
0000705c56fdfc94  vmovaps [rsp+0xE0], xmm15
0000705c56fdfc9d  sub rsp, 0x30
0000705c56fdfca1  movaps [rsp], xmm9
0000705c56fdfca6  movaps [rsp+0x10], xmm8
0000705c56fdfcac  movaps [rsp+0x20], xmm11
0000705c56fdfcb2  lea rdi, [rsp]
0000705c56fdfcb6  mov esi, 0x00
0000705c56fdfcbb  mov rax, 0x5877D3629530
0000705c56fdfcc5  call rax
0000705c56fdfcc7  movaps xmm9, [rsp]
0000705c56fdfccc  add rsp, 0x30
0000705c56fdfcd0  vmovaps xmm0, [rsp]
0000705c56fdfcd5  vmovaps xmm1, [rsp+0x10]
0000705c56fdfcdb  vmovaps xmm2, [rsp+0x20]
0000705c56fdfce1  vmovaps xmm3, [rsp+0x30]
0000705c56fdfce7  vmovaps xmm4, [rsp+0x40]
0000705c56fdfced  vmovaps xmm5, [rsp+0x50]
0000705c56fdfcf3  vmovaps xmm6, [rsp+0x60]
0000705c56fdfcf9  vmovaps xmm7, [rsp+0x70]
0000705c56fdfcff  vmovaps xmm8, [rsp+0x80]
0000705c56fdfd08  vmovaps xmm10, [rsp+0x90]
0000705c56fdfd11  vmovaps xmm11, [rsp+0xA0]
0000705c56fdfd1a  vmovaps xmm12, [rsp+0xB0]
0000705c56fdfd23  vmovaps xmm13, [rsp+0xC0]
0000705c56fdfd2c  vmovaps xmm14, [rsp+0xD0]
0000705c56fdfd35  vmovaps xmm15, [rsp+0xE0]
0000705c56fdfd3e  add rsp, 0xF0
0000705c56fdfd45  pop r11
0000705c56fdfd47  pop r10
0000705c56fdfd49  pop r9
0000705c56fdfd4b  pop r8
0000705c56fdfd4d  pop rsi
0000705c56fdfd4e  pop rdi
0000705c56fdfd4f  pop rdx
0000705c56fdfd50  pop rcx
0000705c56fdfd51  pop rax
0000705c56fdfd52  add rsp, 0x08
0000705c56fdfd56  jmp 0x0000705C56FDC505
0000705c56fdfd5b  sub rsp, 0x08
0000705c56fdfd5f  push rax
0000705c56fdfd60  push rcx
0000705c56fdfd61  push rdx
0000705c56fdfd62  push rdi
0000705c56fdfd63  push rsi
0000705c56fdfd64  push r8
0000705c56fdfd66  push r9
0000705c56fdfd68  push r10
0000705c56fdfd6a  push r11
0000705c56fdfd6c  sub rsp, 0xF0
0000705c56fdfd73  vmovaps [rsp], xmm0
0000705c56fdfd78  vmovaps [rsp+0x10], xmm1
0000705c56fdfd7e  vmovaps [rsp+0x20], xmm2
0000705c56fdfd84  vmovaps [rsp+0x30], xmm3
0000705c56fdfd8a  vmovaps [rsp+0x40], xmm4
0000705c56fdfd90  vmovaps [rsp+0x50], xmm5
0000705c56fdfd96  vmovaps [rsp+0x60], xmm6
0000705c56fdfd9c  vmovaps [rsp+0x70], xmm7
0000705c56fdfda2  vmovaps [rsp+0x80], xmm8
0000705c56fdfdab  vmovaps [rsp+0x90], xmm9
0000705c56fdfdb4  vmovaps [rsp+0xA0], xmm10
0000705c56fdfdbd  vmovaps [rsp+0xB0], xmm12
0000705c56fdfdc6  vmovaps [rsp+0xC0], xmm13
0000705c56fdfdcf  vmovaps [rsp+0xD0], xmm14
0000705c56fdfdd8  vmovaps [rsp+0xE0], xmm15
0000705c56fdfde1  sub rsp, 0x30
0000705c56fdfde5  movaps [rsp], xmm11
0000705c56fdfdea  movaps [rsp+0x10], xmm10
0000705c56fdfdf0  movaps [rsp+0x20], xmm6
0000705c56fdfdf5  lea rdi, [rsp]
0000705c56fdfdf9  mov esi, 0x00
0000705c56fdfdfe  mov rax, 0x5877D3629530
0000705c56fdfe08  call rax
0000705c56fdfe0a  movaps xmm11, [rsp]
0000705c56fdfe0f  add rsp, 0x30
0000705c56fdfe13  vmovaps xmm0, [rsp]
0000705c56fdfe18  vmovaps xmm1, [rsp+0x10]
0000705c56fdfe1e  vmovaps xmm2, [rsp+0x20]
0000705c56fdfe24  vmovaps xmm3, [rsp+0x30]
0000705c56fdfe2a  vmovaps xmm4, [rsp+0x40]
0000705c56fdfe30  vmovaps xmm5, [rsp+0x50]
0000705c56fdfe36  vmovaps xmm6, [rsp+0x60]
0000705c56fdfe3c  vmovaps xmm7, [rsp+0x70]
0000705c56fdfe42  vmovaps xmm8, [rsp+0x80]
0000705c56fdfe4b  vmovaps xmm9, [rsp+0x90]
0000705c56fdfe54  vmovaps xmm10, [rsp+0xA0]
0000705c56fdfe5d  vmovaps xmm12, [rsp+0xB0]
0000705c56fdfe66  vmovaps xmm13, [rsp+0xC0]
0000705c56fdfe6f  vmovaps xmm14, [rsp+0xD0]
0000705c56fdfe78  vmovaps xmm15, [rsp+0xE0]
0000705c56fdfe81  add rsp, 0xF0
0000705c56fdfe88  pop r11
0000705c56fdfe8a  pop r10
0000705c56fdfe8c  pop r9
0000705c56fdfe8e  pop r8
0000705c56fdfe90  pop rsi
0000705c56fdfe91  pop rdi
0000705c56fdfe92  pop rdx
0000705c56fdfe93  pop rcx
0000705c56fdfe94  pop rax
0000705c56fdfe95  add rsp, 0x08
0000705c56fdfe99  jmp 0x0000705C56FDC520
0000705c56fdfe9e  sub rsp, 0x08
0000705c56fdfea2  push rax
0000705c56fdfea3  push rcx
0000705c56fdfea4  push rdx
0000705c56fdfea5  push rdi
0000705c56fdfea6  push rsi
0000705c56fdfea7  push r8
0000705c56fdfea9  push r9
0000705c56fdfeab  push r10
0000705c56fdfead  push r11
0000705c56fdfeaf  sub rsp, 0xF0
0000705c56fdfeb6  vmovaps [rsp], xmm0
0000705c56fdfebb  vmovaps [rsp+0x10], xmm1
0000705c56fdfec1  vmovaps [rsp+0x20], xmm2
0000705c56fdfec7  vmovaps [rsp+0x30], xmm3
0000705c56fdfecd  vmovaps [rsp+0x40], xmm4
0000705c56fdfed3  vmovaps [rsp+0x50], xmm5
0000705c56fdfed9  vmovaps [rsp+0x60], xmm6
0000705c56fdfedf  vmovaps [rsp+0x70], xmm7
0000705c56fdfee5  vmovaps [rsp+0x80], xmm8
0000705c56fdfeee  vmovaps [rsp+0x90], xmm9
0000705c56fdfef7  vmovaps [rsp+0xA0], xmm11
0000705c56fdff00  vmovaps [rsp+0xB0], xmm12
0000705c56fdff09  vmovaps [rsp+0xC0], xmm13
0000705c56fdff12  vmovaps [rsp+0xD0], xmm14
0000705c56fdff1b  vmovaps [rsp+0xE0], xmm15
0000705c56fdff24  sub rsp, 0x30
0000705c56fdff28  movaps [rsp], xmm10
0000705c56fdff2d  movaps [rsp+0x10], xmm14
0000705c56fdff33  movaps [rsp+0x20], xmm4
0000705c56fdff38  lea rdi, [rsp]
0000705c56fdff3c  mov esi, 0x00
0000705c56fdff41  mov rax, 0x5877D3629530
0000705c56fdff4b  call rax
0000705c56fdff4d  movaps xmm10, [rsp]
0000705c56fdff52  add rsp, 0x30
0000705c56fdff56  vmovaps xmm0, [rsp]
0000705c56fdff5b  vmovaps xmm1, [rsp+0x10]
0000705c56fdff61  vmovaps xmm2, [rsp+0x20]
0000705c56fdff67  vmovaps xmm3, [rsp+0x30]
0000705c56fdff6d  vmovaps xmm4, [rsp+0x40]
0000705c56fdff73  vmovaps xmm5, [rsp+0x50]
0000705c56fdff79  vmovaps xmm6, [rsp+0x60]
0000705c56fdff7f  vmovaps xmm7, [rsp+0x70]
0000705c56fdff85  vmovaps xmm8, [rsp+0x80]
0000705c56fdff8e  vmovaps xmm9, [rsp+0x90]
0000705c56fdff97  vmovaps xmm11, [rsp+0xA0]
0000705c56fdffa0  vmovaps xmm12, [rsp+0xB0]
0000705c56fdffa9  vmovaps xmm13, [rsp+0xC0]
0000705c56fdffb2  vmovaps xmm14, [rsp+0xD0]
0000705c56fdffbb  vmovaps xmm15, [rsp+0xE0]
0000705c56fdffc4  add rsp, 0xF0
0000705c56fdffcb  pop r11
0000705c56fdffcd  pop r10
0000705c56fdffcf  pop r9
0000705c56fdffd1  pop r8
0000705c56fdffd3  pop rsi
0000705c56fdffd4  pop rdi
0000705c56fdffd5  pop rdx
0000705c56fdffd6  pop rcx
0000705c56fdffd7  pop rax
0000705c56fdffd8  add rsp, 0x08
0000705c56fdffdc  jmp 0x0000705C56FDC53B
0000705c56fdffe1  sub rsp, 0x08
0000705c56fdffe5  push rax
0000705c56fdffe6  push rcx
0000705c56fdffe7  push rdx
0000705c56fdffe8  push rdi
0000705c56fdffe9  push rsi
0000705c56fdffea  push r8
0000705c56fdffec  push r9
0000705c56fdffee  push r10
0000705c56fdfff0  push r11
0000705c56fdfff2  sub rsp, 0xF0
0000705c56fdfff9  vmovaps [rsp], xmm0
0000705c56fdfffe  vmovaps [rsp+0x10], xmm1
0000705c56fe0004  vmovaps [rsp+0x20], xmm2
0000705c56fe000a  vmovaps [rsp+0x30], xmm3
0000705c56fe0010  vmovaps [rsp+0x40], xmm4
0000705c56fe0016  vmovaps [rsp+0x50], xmm5
0000705c56fe001c  vmovaps [rsp+0x60], xmm6
0000705c56fe0022  vmovaps [rsp+0x70], xmm7
0000705c56fe0028  vmovaps [rsp+0x80], xmm9
0000705c56fe0031  vmovaps [rsp+0x90], xmm10
0000705c56fe003a  vmovaps [rsp+0xA0], xmm11
0000705c56fe0043  vmovaps [rsp+0xB0], xmm12
0000705c56fe004c  vmovaps [rsp+0xC0], xmm13
0000705c56fe0055  vmovaps [rsp+0xD0], xmm14
0000705c56fe005e  vmovaps [rsp+0xE0], xmm15
0000705c56fe0067  sub rsp, 0x30
0000705c56fe006b  movaps [rsp], xmm8
0000705c56fe0070  movaps [rsp+0x10], xmm1
0000705c56fe0075  movaps [rsp+0x20], xmm14
0000705c56fe007b  lea rdi, [rsp]
0000705c56fe007f  mov esi, 0x00
0000705c56fe0084  mov rax, 0x5877D3629530
0000705c56fe008e  call rax
0000705c56fe0090  movaps xmm8, [rsp]
0000705c56fe0095  add rsp, 0x30
0000705c56fe0099  vmovaps xmm0, [rsp]
0000705c56fe009e  vmovaps xmm1, [rsp+0x10]
0000705c56fe00a4  vmovaps xmm2, [rsp+0x20]
0000705c56fe00aa  vmovaps xmm3, [rsp+0x30]
0000705c56fe00b0  vmovaps xmm4, [rsp+0x40]
0000705c56fe00b6  vmovaps xmm5, [rsp+0x50]
0000705c56fe00bc  vmovaps xmm6, [rsp+0x60]
0000705c56fe00c2  vmovaps xmm7, [rsp+0x70]
0000705c56fe00c8  vmovaps xmm9, [rsp+0x80]
0000705c56fe00d1  vmovaps xmm10, [rsp+0x90]
0000705c56fe00da  vmovaps xmm11, [rsp+0xA0]
0000705c56fe00e3  vmovaps xmm12, [rsp+0xB0]
0000705c56fe00ec  vmovaps xmm13, [rsp+0xC0]
0000705c56fe00f5  vmovaps xmm14, [rsp+0xD0]
0000705c56fe00fe  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0107  add rsp, 0xF0
0000705c56fe010e  pop r11
0000705c56fe0110  pop r10
0000705c56fe0112  pop r9
0000705c56fe0114  pop r8
0000705c56fe0116  pop rsi
0000705c56fe0117  pop rdi
0000705c56fe0118  pop rdx
0000705c56fe0119  pop rcx
0000705c56fe011a  pop rax
0000705c56fe011b  add rsp, 0x08
0000705c56fe011f  jmp 0x0000705C56FDC561
0000705c56fe0124  sub rsp, 0x08
0000705c56fe0128  push rax
0000705c56fe0129  push rcx
0000705c56fe012a  push rdx
0000705c56fe012b  push rdi
0000705c56fe012c  push rsi
0000705c56fe012d  push r8
0000705c56fe012f  push r9
0000705c56fe0131  push r10
0000705c56fe0133  push r11
0000705c56fe0135  sub rsp, 0xF0
0000705c56fe013c  vmovaps [rsp], xmm0
0000705c56fe0141  vmovaps [rsp+0x10], xmm1
0000705c56fe0147  vmovaps [rsp+0x20], xmm2
0000705c56fe014d  vmovaps [rsp+0x30], xmm3
0000705c56fe0153  vmovaps [rsp+0x40], xmm4
0000705c56fe0159  vmovaps [rsp+0x50], xmm5
0000705c56fe015f  vmovaps [rsp+0x60], xmm7
0000705c56fe0165  vmovaps [rsp+0x70], xmm8
0000705c56fe016b  vmovaps [rsp+0x80], xmm9
0000705c56fe0174  vmovaps [rsp+0x90], xmm10
0000705c56fe017d  vmovaps [rsp+0xA0], xmm11
0000705c56fe0186  vmovaps [rsp+0xB0], xmm12
0000705c56fe018f  vmovaps [rsp+0xC0], xmm13
0000705c56fe0198  vmovaps [rsp+0xD0], xmm14
0000705c56fe01a1  vmovaps [rsp+0xE0], xmm15
0000705c56fe01aa  sub rsp, 0x30
0000705c56fe01ae  movaps [rsp], xmm6
0000705c56fe01b2  movaps [rsp+0x10], xmm1
0000705c56fe01b7  movaps [rsp+0x20], xmm14
0000705c56fe01bd  lea rdi, [rsp]
0000705c56fe01c1  mov esi, 0x00
0000705c56fe01c6  mov rax, 0x5877D3629530
0000705c56fe01d0  call rax
0000705c56fe01d2  movaps xmm6, [rsp]
0000705c56fe01d6  add rsp, 0x30
0000705c56fe01da  vmovaps xmm0, [rsp]
0000705c56fe01df  vmovaps xmm1, [rsp+0x10]
0000705c56fe01e5  vmovaps xmm2, [rsp+0x20]
0000705c56fe01eb  vmovaps xmm3, [rsp+0x30]
0000705c56fe01f1  vmovaps xmm4, [rsp+0x40]
0000705c56fe01f7  vmovaps xmm5, [rsp+0x50]
0000705c56fe01fd  vmovaps xmm7, [rsp+0x60]
0000705c56fe0203  vmovaps xmm8, [rsp+0x70]
0000705c56fe0209  vmovaps xmm9, [rsp+0x80]
0000705c56fe0212  vmovaps xmm10, [rsp+0x90]
0000705c56fe021b  vmovaps xmm11, [rsp+0xA0]
0000705c56fe0224  vmovaps xmm12, [rsp+0xB0]
0000705c56fe022d  vmovaps xmm13, [rsp+0xC0]
0000705c56fe0236  vmovaps xmm14, [rsp+0xD0]
0000705c56fe023f  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0248  add rsp, 0xF0
0000705c56fe024f  pop r11
0000705c56fe0251  pop r10
0000705c56fe0253  pop r9
0000705c56fe0255  pop r8
0000705c56fe0257  pop rsi
0000705c56fe0258  pop rdi
0000705c56fe0259  pop rdx
0000705c56fe025a  pop rcx
0000705c56fe025b  pop rax
0000705c56fe025c  add rsp, 0x08
0000705c56fe0260  jmp 0x0000705C56FDC58D
0000705c56fe0265  sub rsp, 0x08
0000705c56fe0269  push rax
0000705c56fe026a  push rcx
0000705c56fe026b  push rdx
0000705c56fe026c  push rdi
0000705c56fe026d  push rsi
0000705c56fe026e  push r8
0000705c56fe0270  push r9
0000705c56fe0272  push r10
0000705c56fe0274  push r11
0000705c56fe0276  sub rsp, 0xF0
0000705c56fe027d  vmovaps [rsp], xmm0
0000705c56fe0282  vmovaps [rsp+0x10], xmm1
0000705c56fe0288  vmovaps [rsp+0x20], xmm2
0000705c56fe028e  vmovaps [rsp+0x30], xmm3
0000705c56fe0294  vmovaps [rsp+0x40], xmm4
0000705c56fe029a  vmovaps [rsp+0x50], xmm5
0000705c56fe02a0  vmovaps [rsp+0x60], xmm6
0000705c56fe02a6  vmovaps [rsp+0x70], xmm7
0000705c56fe02ac  vmovaps [rsp+0x80], xmm8
0000705c56fe02b5  vmovaps [rsp+0x90], xmm9
0000705c56fe02be  vmovaps [rsp+0xA0], xmm10
0000705c56fe02c7  vmovaps [rsp+0xB0], xmm11
0000705c56fe02d0  vmovaps [rsp+0xC0], xmm12
0000705c56fe02d9  vmovaps [rsp+0xD0], xmm13
0000705c56fe02e2  vmovaps [rsp+0xE0], xmm15
0000705c56fe02eb  sub rsp, 0x30
0000705c56fe02ef  movaps [rsp], xmm14
0000705c56fe02f4  movaps [rsp+0x10], xmm12
0000705c56fe02fa  movaps [rsp+0x20], xmm1
0000705c56fe02ff  lea rdi, [rsp]
0000705c56fe0303  mov esi, 0x00
0000705c56fe0308  mov rax, 0x5877D3629530
0000705c56fe0312  call rax
0000705c56fe0314  movaps xmm14, [rsp]
0000705c56fe0319  add rsp, 0x30
0000705c56fe031d  vmovaps xmm0, [rsp]
0000705c56fe0322  vmovaps xmm1, [rsp+0x10]
0000705c56fe0328  vmovaps xmm2, [rsp+0x20]
0000705c56fe032e  vmovaps xmm3, [rsp+0x30]
0000705c56fe0334  vmovaps xmm4, [rsp+0x40]
0000705c56fe033a  vmovaps xmm5, [rsp+0x50]
0000705c56fe0340  vmovaps xmm6, [rsp+0x60]
0000705c56fe0346  vmovaps xmm7, [rsp+0x70]
0000705c56fe034c  vmovaps xmm8, [rsp+0x80]
0000705c56fe0355  vmovaps xmm9, [rsp+0x90]
0000705c56fe035e  vmovaps xmm10, [rsp+0xA0]
0000705c56fe0367  vmovaps xmm11, [rsp+0xB0]
0000705c56fe0370  vmovaps xmm12, [rsp+0xC0]
0000705c56fe0379  vmovaps xmm13, [rsp+0xD0]
0000705c56fe0382  vmovaps xmm15, [rsp+0xE0]
0000705c56fe038b  add rsp, 0xF0
0000705c56fe0392  pop r11
0000705c56fe0394  pop r10
0000705c56fe0396  pop r9
0000705c56fe0398  pop r8
0000705c56fe039a  pop rsi
0000705c56fe039b  pop rdi
0000705c56fe039c  pop rdx
0000705c56fe039d  pop rcx
0000705c56fe039e  pop rax
0000705c56fe039f  add rsp, 0x08
0000705c56fe03a3  jmp 0x0000705C56FDC5B3
0000705c56fe03a8  sub rsp, 0x08
0000705c56fe03ac  push rax
0000705c56fe03ad  push rcx
0000705c56fe03ae  push rdx
0000705c56fe03af  push rdi
0000705c56fe03b0  push rsi
0000705c56fe03b1  push r8
0000705c56fe03b3  push r9
0000705c56fe03b5  push r10
0000705c56fe03b7  push r11
0000705c56fe03b9  sub rsp, 0xF0
0000705c56fe03c0  vmovaps [rsp], xmm0
0000705c56fe03c5  vmovaps [rsp+0x10], xmm2
0000705c56fe03cb  vmovaps [rsp+0x20], xmm3
0000705c56fe03d1  vmovaps [rsp+0x30], xmm4
0000705c56fe03d7  vmovaps [rsp+0x40], xmm5
0000705c56fe03dd  vmovaps [rsp+0x50], xmm6
0000705c56fe03e3  vmovaps [rsp+0x60], xmm7
0000705c56fe03e9  vmovaps [rsp+0x70], xmm8
0000705c56fe03ef  vmovaps [rsp+0x80], xmm9
0000705c56fe03f8  vmovaps [rsp+0x90], xmm10
0000705c56fe0401  vmovaps [rsp+0xA0], xmm11
0000705c56fe040a  vmovaps [rsp+0xB0], xmm12
0000705c56fe0413  vmovaps [rsp+0xC0], xmm13
0000705c56fe041c  vmovaps [rsp+0xD0], xmm14
0000705c56fe0425  vmovaps [rsp+0xE0], xmm15
0000705c56fe042e  sub rsp, 0x30
0000705c56fe0432  movaps [rsp], xmm1
0000705c56fe0436  movaps [rsp+0x10], xmm13
0000705c56fe043c  movaps [rsp+0x20], xmm9
0000705c56fe0442  lea rdi, [rsp]
0000705c56fe0446  mov esi, 0x00
0000705c56fe044b  mov rax, 0x5877D3629530
0000705c56fe0455  call rax
0000705c56fe0457  movaps xmm1, [rsp]
0000705c56fe045b  add rsp, 0x30
0000705c56fe045f  vmovaps xmm0, [rsp]
0000705c56fe0464  vmovaps xmm2, [rsp+0x10]
0000705c56fe046a  vmovaps xmm3, [rsp+0x20]
0000705c56fe0470  vmovaps xmm4, [rsp+0x30]
0000705c56fe0476  vmovaps xmm5, [rsp+0x40]
0000705c56fe047c  vmovaps xmm6, [rsp+0x50]
0000705c56fe0482  vmovaps xmm7, [rsp+0x60]
0000705c56fe0488  vmovaps xmm8, [rsp+0x70]
0000705c56fe048e  vmovaps xmm9, [rsp+0x80]
0000705c56fe0497  vmovaps xmm10, [rsp+0x90]
0000705c56fe04a0  vmovaps xmm11, [rsp+0xA0]
0000705c56fe04a9  vmovaps xmm12, [rsp+0xB0]
0000705c56fe04b2  vmovaps xmm13, [rsp+0xC0]
0000705c56fe04bb  vmovaps xmm14, [rsp+0xD0]
0000705c56fe04c4  vmovaps xmm15, [rsp+0xE0]
0000705c56fe04cd  add rsp, 0xF0
0000705c56fe04d4  pop r11
0000705c56fe04d6  pop r10
0000705c56fe04d8  pop r9
0000705c56fe04da  pop r8
0000705c56fe04dc  pop rsi
0000705c56fe04dd  pop rdi
0000705c56fe04de  pop rdx
0000705c56fe04df  pop rcx
0000705c56fe04e0  pop rax
0000705c56fe04e1  add rsp, 0x08
0000705c56fe04e5  jmp 0x0000705C56FDC5CD
0000705c56fe04ea  sub rsp, 0x08
0000705c56fe04ee  push rax
0000705c56fe04ef  push rcx
0000705c56fe04f0  push rdx
0000705c56fe04f1  push rdi
0000705c56fe04f2  push rsi
0000705c56fe04f3  push r8
0000705c56fe04f5  push r9
0000705c56fe04f7  push r10
0000705c56fe04f9  push r11
0000705c56fe04fb  sub rsp, 0xF0
0000705c56fe0502  vmovaps [rsp], xmm0
0000705c56fe0507  vmovaps [rsp+0x10], xmm1
0000705c56fe050d  vmovaps [rsp+0x20], xmm2
0000705c56fe0513  vmovaps [rsp+0x30], xmm3
0000705c56fe0519  vmovaps [rsp+0x40], xmm4
0000705c56fe051f  vmovaps [rsp+0x50], xmm5
0000705c56fe0525  vmovaps [rsp+0x60], xmm6
0000705c56fe052b  vmovaps [rsp+0x70], xmm7
0000705c56fe0531  vmovaps [rsp+0x80], xmm8
0000705c56fe053a  vmovaps [rsp+0x90], xmm9
0000705c56fe0543  vmovaps [rsp+0xA0], xmm10
0000705c56fe054c  vmovaps [rsp+0xB0], xmm11
0000705c56fe0555  vmovaps [rsp+0xC0], xmm13
0000705c56fe055e  vmovaps [rsp+0xD0], xmm14
0000705c56fe0567  vmovaps [rsp+0xE0], xmm15
0000705c56fe0570  sub rsp, 0x30
0000705c56fe0574  movaps [rsp], xmm12
0000705c56fe0579  movaps [rsp+0x10], xmm7
0000705c56fe057e  movaps [rsp+0x20], xmm13
0000705c56fe0584  lea rdi, [rsp]
0000705c56fe0588  mov esi, 0x00
0000705c56fe058d  mov rax, 0x5877D3629530
0000705c56fe0597  call rax
0000705c56fe0599  movaps xmm12, [rsp]
0000705c56fe059e  add rsp, 0x30
0000705c56fe05a2  vmovaps xmm0, [rsp]
0000705c56fe05a7  vmovaps xmm1, [rsp+0x10]
0000705c56fe05ad  vmovaps xmm2, [rsp+0x20]
0000705c56fe05b3  vmovaps xmm3, [rsp+0x30]
0000705c56fe05b9  vmovaps xmm4, [rsp+0x40]
0000705c56fe05bf  vmovaps xmm5, [rsp+0x50]
0000705c56fe05c5  vmovaps xmm6, [rsp+0x60]
0000705c56fe05cb  vmovaps xmm7, [rsp+0x70]
0000705c56fe05d1  vmovaps xmm8, [rsp+0x80]
0000705c56fe05da  vmovaps xmm9, [rsp+0x90]
0000705c56fe05e3  vmovaps xmm10, [rsp+0xA0]
0000705c56fe05ec  vmovaps xmm11, [rsp+0xB0]
0000705c56fe05f5  vmovaps xmm13, [rsp+0xC0]
0000705c56fe05fe  vmovaps xmm14, [rsp+0xD0]
0000705c56fe0607  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0610  add rsp, 0xF0
0000705c56fe0617  pop r11
0000705c56fe0619  pop r10
0000705c56fe061b  pop r9
0000705c56fe061d  pop r8
0000705c56fe061f  pop rsi
0000705c56fe0620  pop rdi
0000705c56fe0621  pop rdx
0000705c56fe0622  pop rcx
0000705c56fe0623  pop rax
0000705c56fe0624  add rsp, 0x08
0000705c56fe0628  jmp 0x0000705C56FDC5F4
0000705c56fe062d  sub rsp, 0x08
0000705c56fe0631  push rax
0000705c56fe0632  push rcx
0000705c56fe0633  push rdx
0000705c56fe0634  push rdi
0000705c56fe0635  push rsi
0000705c56fe0636  push r8
0000705c56fe0638  push r9
0000705c56fe063a  push r10
0000705c56fe063c  push r11
0000705c56fe063e  sub rsp, 0xF0
0000705c56fe0645  vmovaps [rsp], xmm0
0000705c56fe064a  vmovaps [rsp+0x10], xmm1
0000705c56fe0650  vmovaps [rsp+0x20], xmm2
0000705c56fe0656  vmovaps [rsp+0x30], xmm3
0000705c56fe065c  vmovaps [rsp+0x40], xmm4
0000705c56fe0662  vmovaps [rsp+0x50], xmm5
0000705c56fe0668  vmovaps [rsp+0x60], xmm6
0000705c56fe066e  vmovaps [rsp+0x70], xmm7
0000705c56fe0674  vmovaps [rsp+0x80], xmm8
0000705c56fe067d  vmovaps [rsp+0x90], xmm9
0000705c56fe0686  vmovaps [rsp+0xA0], xmm10
0000705c56fe068f  vmovaps [rsp+0xB0], xmm11
0000705c56fe0698  vmovaps [rsp+0xC0], xmm12
0000705c56fe06a1  vmovaps [rsp+0xD0], xmm14
0000705c56fe06aa  vmovaps [rsp+0xE0], xmm15
0000705c56fe06b3  sub rsp, 0x30
0000705c56fe06b7  movaps [rsp], xmm13
0000705c56fe06bc  movaps [rsp+0x10], xmm15
0000705c56fe06c2  movaps [rsp+0x20], xmm8
0000705c56fe06c8  lea rdi, [rsp]
0000705c56fe06cc  mov esi, 0x00
0000705c56fe06d1  mov rax, 0x5877D3629530
0000705c56fe06db  call rax
0000705c56fe06dd  movaps xmm13, [rsp]
0000705c56fe06e2  add rsp, 0x30
0000705c56fe06e6  vmovaps xmm0, [rsp]
0000705c56fe06eb  vmovaps xmm1, [rsp+0x10]
0000705c56fe06f1  vmovaps xmm2, [rsp+0x20]
0000705c56fe06f7  vmovaps xmm3, [rsp+0x30]
0000705c56fe06fd  vmovaps xmm4, [rsp+0x40]
0000705c56fe0703  vmovaps xmm5, [rsp+0x50]
0000705c56fe0709  vmovaps xmm6, [rsp+0x60]
0000705c56fe070f  vmovaps xmm7, [rsp+0x70]
0000705c56fe0715  vmovaps xmm8, [rsp+0x80]
0000705c56fe071e  vmovaps xmm9, [rsp+0x90]
0000705c56fe0727  vmovaps xmm10, [rsp+0xA0]
0000705c56fe0730  vmovaps xmm11, [rsp+0xB0]
0000705c56fe0739  vmovaps xmm12, [rsp+0xC0]
0000705c56fe0742  vmovaps xmm14, [rsp+0xD0]
0000705c56fe074b  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0754  add rsp, 0xF0
0000705c56fe075b  pop r11
0000705c56fe075d  pop r10
0000705c56fe075f  pop r9
0000705c56fe0761  pop r8
0000705c56fe0763  pop rsi
0000705c56fe0764  pop rdi
0000705c56fe0765  pop rdx
0000705c56fe0766  pop rcx
0000705c56fe0767  pop rax
0000705c56fe0768  add rsp, 0x08
0000705c56fe076c  jmp 0x0000705C56FDC60F
0000705c56fe0771  sub rsp, 0x08
0000705c56fe0775  push rax
0000705c56fe0776  push rcx
0000705c56fe0777  push rdx
0000705c56fe0778  push rdi
0000705c56fe0779  push rsi
0000705c56fe077a  push r8
0000705c56fe077c  push r9
0000705c56fe077e  push r10
0000705c56fe0780  push r11
0000705c56fe0782  sub rsp, 0xF0
0000705c56fe0789  vmovaps [rsp], xmm0
0000705c56fe078e  vmovaps [rsp+0x10], xmm1
0000705c56fe0794  vmovaps [rsp+0x20], xmm2
0000705c56fe079a  vmovaps [rsp+0x30], xmm3
0000705c56fe07a0  vmovaps [rsp+0x40], xmm4
0000705c56fe07a6  vmovaps [rsp+0x50], xmm5
0000705c56fe07ac  vmovaps [rsp+0x60], xmm6
0000705c56fe07b2  vmovaps [rsp+0x70], xmm7
0000705c56fe07b8  vmovaps [rsp+0x80], xmm9
0000705c56fe07c1  vmovaps [rsp+0x90], xmm10
0000705c56fe07ca  vmovaps [rsp+0xA0], xmm11
0000705c56fe07d3  vmovaps [rsp+0xB0], xmm12
0000705c56fe07dc  vmovaps [rsp+0xC0], xmm13
0000705c56fe07e5  vmovaps [rsp+0xD0], xmm14
0000705c56fe07ee  vmovaps [rsp+0xE0], xmm15
0000705c56fe07f7  sub rsp, 0x30
0000705c56fe07fb  movaps [rsp], xmm8
0000705c56fe0800  movaps [rsp+0x10], xmm15
0000705c56fe0806  movaps [rsp+0x20], xmm9
0000705c56fe080c  lea rdi, [rsp]
0000705c56fe0810  mov esi, 0x00
0000705c56fe0815  mov rax, 0x5877D3629530
0000705c56fe081f  call rax
0000705c56fe0821  movaps xmm8, [rsp]
0000705c56fe0826  add rsp, 0x30
0000705c56fe082a  vmovaps xmm0, [rsp]
0000705c56fe082f  vmovaps xmm1, [rsp+0x10]
0000705c56fe0835  vmovaps xmm2, [rsp+0x20]
0000705c56fe083b  vmovaps xmm3, [rsp+0x30]
0000705c56fe0841  vmovaps xmm4, [rsp+0x40]
0000705c56fe0847  vmovaps xmm5, [rsp+0x50]
0000705c56fe084d  vmovaps xmm6, [rsp+0x60]
0000705c56fe0853  vmovaps xmm7, [rsp+0x70]
0000705c56fe0859  vmovaps xmm9, [rsp+0x80]
0000705c56fe0862  vmovaps xmm10, [rsp+0x90]
0000705c56fe086b  vmovaps xmm11, [rsp+0xA0]
0000705c56fe0874  vmovaps xmm12, [rsp+0xB0]
0000705c56fe087d  vmovaps xmm13, [rsp+0xC0]
0000705c56fe0886  vmovaps xmm14, [rsp+0xD0]
0000705c56fe088f  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0898  add rsp, 0xF0
0000705c56fe089f  pop r11
0000705c56fe08a1  pop r10
0000705c56fe08a3  pop r9
0000705c56fe08a5  pop r8
0000705c56fe08a7  pop rsi
0000705c56fe08a8  pop rdi
0000705c56fe08a9  pop rdx
0000705c56fe08aa  pop rcx
0000705c56fe08ab  pop rax
0000705c56fe08ac  add rsp, 0x08
0000705c56fe08b0  jmp 0x0000705C56FDC63D
0000705c56fe08b5  sub rsp, 0x08
0000705c56fe08b9  push rax
0000705c56fe08ba  push rcx
0000705c56fe08bb  push rdx
0000705c56fe08bc  push rdi
0000705c56fe08bd  push rsi
0000705c56fe08be  push r8
0000705c56fe08c0  push r9
0000705c56fe08c2  push r10
0000705c56fe08c4  push r11
0000705c56fe08c6  sub rsp, 0xF0
0000705c56fe08cd  vmovaps [rsp], xmm0
0000705c56fe08d2  vmovaps [rsp+0x10], xmm1
0000705c56fe08d8  vmovaps [rsp+0x20], xmm2
0000705c56fe08de  vmovaps [rsp+0x30], xmm3
0000705c56fe08e4  vmovaps [rsp+0x40], xmm4
0000705c56fe08ea  vmovaps [rsp+0x50], xmm5
0000705c56fe08f0  vmovaps [rsp+0x60], xmm6
0000705c56fe08f6  vmovaps [rsp+0x70], xmm7
0000705c56fe08fc  vmovaps [rsp+0x80], xmm8
0000705c56fe0905  vmovaps [rsp+0x90], xmm9
0000705c56fe090e  vmovaps [rsp+0xA0], xmm10
0000705c56fe0917  vmovaps [rsp+0xB0], xmm11
0000705c56fe0920  vmovaps [rsp+0xC0], xmm12
0000705c56fe0929  vmovaps [rsp+0xD0], xmm13
0000705c56fe0932  vmovaps [rsp+0xE0], xmm14
0000705c56fe093b  sub rsp, 0x30
0000705c56fe093f  movaps [rsp], xmm15
0000705c56fe0944  movaps [rsp+0x10], xmm11
0000705c56fe094a  movaps [rsp+0x20], xmm6
0000705c56fe094f  lea rdi, [rsp]
0000705c56fe0953  mov esi, 0x00
0000705c56fe0958  mov rax, 0x5877D3629530
0000705c56fe0962  call rax
0000705c56fe0964  movaps xmm15, [rsp]
0000705c56fe0969  add rsp, 0x30
0000705c56fe096d  vmovaps xmm0, [rsp]
0000705c56fe0972  vmovaps xmm1, [rsp+0x10]
0000705c56fe0978  vmovaps xmm2, [rsp+0x20]
0000705c56fe097e  vmovaps xmm3, [rsp+0x30]
0000705c56fe0984  vmovaps xmm4, [rsp+0x40]
0000705c56fe098a  vmovaps xmm5, [rsp+0x50]
0000705c56fe0990  vmovaps xmm6, [rsp+0x60]
0000705c56fe0996  vmovaps xmm7, [rsp+0x70]
0000705c56fe099c  vmovaps xmm8, [rsp+0x80]
0000705c56fe09a5  vmovaps xmm9, [rsp+0x90]
0000705c56fe09ae  vmovaps xmm10, [rsp+0xA0]
0000705c56fe09b7  vmovaps xmm11, [rsp+0xB0]
0000705c56fe09c0  vmovaps xmm12, [rsp+0xC0]
0000705c56fe09c9  vmovaps xmm13, [rsp+0xD0]
0000705c56fe09d2  vmovaps xmm14, [rsp+0xE0]
0000705c56fe09db  add rsp, 0xF0
0000705c56fe09e2  pop r11
0000705c56fe09e4  pop r10
0000705c56fe09e6  pop r9
0000705c56fe09e8  pop r8
0000705c56fe09ea  pop rsi
0000705c56fe09eb  pop rdi
0000705c56fe09ec  pop rdx
0000705c56fe09ed  pop rcx
0000705c56fe09ee  pop rax
0000705c56fe09ef  add rsp, 0x08
0000705c56fe09f3  jmp 0x0000705C56FDC658
0000705c56fe09f8  sub rsp, 0x08
0000705c56fe09fc  push rax
0000705c56fe09fd  push rcx
0000705c56fe09fe  push rdx
0000705c56fe09ff  push rdi
0000705c56fe0a00  push rsi
0000705c56fe0a01  push r8
0000705c56fe0a03  push r9
0000705c56fe0a05  push r10
0000705c56fe0a07  push r11
0000705c56fe0a09  sub rsp, 0xF0
0000705c56fe0a10  vmovaps [rsp], xmm0
0000705c56fe0a15  vmovaps [rsp+0x10], xmm1
0000705c56fe0a1b  vmovaps [rsp+0x20], xmm2
0000705c56fe0a21  vmovaps [rsp+0x30], xmm3
0000705c56fe0a27  vmovaps [rsp+0x40], xmm4
0000705c56fe0a2d  vmovaps [rsp+0x50], xmm5
0000705c56fe0a33  vmovaps [rsp+0x60], xmm6
0000705c56fe0a39  vmovaps [rsp+0x70], xmm8
0000705c56fe0a3f  vmovaps [rsp+0x80], xmm9
0000705c56fe0a48  vmovaps [rsp+0x90], xmm10
0000705c56fe0a51  vmovaps [rsp+0xA0], xmm11
0000705c56fe0a5a  vmovaps [rsp+0xB0], xmm12
0000705c56fe0a63  vmovaps [rsp+0xC0], xmm13
0000705c56fe0a6c  vmovaps [rsp+0xD0], xmm14
0000705c56fe0a75  vmovaps [rsp+0xE0], xmm15
0000705c56fe0a7e  sub rsp, 0x30
0000705c56fe0a82  movaps [rsp], xmm7
0000705c56fe0a86  movaps [rsp+0x10], xmm11
0000705c56fe0a8c  movaps [rsp+0x20], xmm9
0000705c56fe0a92  lea rdi, [rsp]
0000705c56fe0a96  mov esi, 0x00
0000705c56fe0a9b  mov rax, 0x5877D3629530
0000705c56fe0aa5  call rax
0000705c56fe0aa7  movaps xmm7, [rsp]
0000705c56fe0aab  add rsp, 0x30
0000705c56fe0aaf  vmovaps xmm0, [rsp]
0000705c56fe0ab4  vmovaps xmm1, [rsp+0x10]
0000705c56fe0aba  vmovaps xmm2, [rsp+0x20]
0000705c56fe0ac0  vmovaps xmm3, [rsp+0x30]
0000705c56fe0ac6  vmovaps xmm4, [rsp+0x40]
0000705c56fe0acc  vmovaps xmm5, [rsp+0x50]
0000705c56fe0ad2  vmovaps xmm6, [rsp+0x60]
0000705c56fe0ad8  vmovaps xmm8, [rsp+0x70]
0000705c56fe0ade  vmovaps xmm9, [rsp+0x80]
0000705c56fe0ae7  vmovaps xmm10, [rsp+0x90]
0000705c56fe0af0  vmovaps xmm11, [rsp+0xA0]
0000705c56fe0af9  vmovaps xmm12, [rsp+0xB0]
0000705c56fe0b02  vmovaps xmm13, [rsp+0xC0]
0000705c56fe0b0b  vmovaps xmm14, [rsp+0xD0]
0000705c56fe0b14  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0b1d  add rsp, 0xF0
0000705c56fe0b24  pop r11
0000705c56fe0b26  pop r10
0000705c56fe0b28  pop r9
0000705c56fe0b2a  pop r8
0000705c56fe0b2c  pop rsi
0000705c56fe0b2d  pop rdi
0000705c56fe0b2e  pop rdx
0000705c56fe0b2f  pop rcx
0000705c56fe0b30  pop rax
0000705c56fe0b31  add rsp, 0x08
0000705c56fe0b35  jmp 0x0000705C56FDC685
0000705c56fe0b3a  sub rsp, 0x08
0000705c56fe0b3e  push rax
0000705c56fe0b3f  push rcx
0000705c56fe0b40  push rdx
0000705c56fe0b41  push rdi
0000705c56fe0b42  push rsi
0000705c56fe0b43  push r8
0000705c56fe0b45  push r9
0000705c56fe0b47  push r10
0000705c56fe0b49  push r11
0000705c56fe0b4b  sub rsp, 0xF0
0000705c56fe0b52  vmovaps [rsp], xmm0
0000705c56fe0b57  vmovaps [rsp+0x10], xmm1
0000705c56fe0b5d  vmovaps [rsp+0x20], xmm2
0000705c56fe0b63  vmovaps [rsp+0x30], xmm3
0000705c56fe0b69  vmovaps [rsp+0x40], xmm4
0000705c56fe0b6f  vmovaps [rsp+0x50], xmm5
0000705c56fe0b75  vmovaps [rsp+0x60], xmm6
0000705c56fe0b7b  vmovaps [rsp+0x70], xmm7
0000705c56fe0b81  vmovaps [rsp+0x80], xmm8
0000705c56fe0b8a  vmovaps [rsp+0x90], xmm9
0000705c56fe0b93  vmovaps [rsp+0xA0], xmm10
0000705c56fe0b9c  vmovaps [rsp+0xB0], xmm12
0000705c56fe0ba5  vmovaps [rsp+0xC0], xmm13
0000705c56fe0bae  vmovaps [rsp+0xD0], xmm14
0000705c56fe0bb7  vmovaps [rsp+0xE0], xmm15
0000705c56fe0bc0  sub rsp, 0x30
0000705c56fe0bc4  movaps [rsp], xmm11
0000705c56fe0bc9  movaps [rsp+0x10], xmm10
0000705c56fe0bcf  movaps [rsp+0x20], xmm14
0000705c56fe0bd5  lea rdi, [rsp]
0000705c56fe0bd9  mov esi, 0x00
0000705c56fe0bde  mov rax, 0x5877D3629530
0000705c56fe0be8  call rax
0000705c56fe0bea  movaps xmm11, [rsp]
0000705c56fe0bef  add rsp, 0x30
0000705c56fe0bf3  vmovaps xmm0, [rsp]
0000705c56fe0bf8  vmovaps xmm1, [rsp+0x10]
0000705c56fe0bfe  vmovaps xmm2, [rsp+0x20]
0000705c56fe0c04  vmovaps xmm3, [rsp+0x30]
0000705c56fe0c0a  vmovaps xmm4, [rsp+0x40]
0000705c56fe0c10  vmovaps xmm5, [rsp+0x50]
0000705c56fe0c16  vmovaps xmm6, [rsp+0x60]
0000705c56fe0c1c  vmovaps xmm7, [rsp+0x70]
0000705c56fe0c22  vmovaps xmm8, [rsp+0x80]
0000705c56fe0c2b  vmovaps xmm9, [rsp+0x90]
0000705c56fe0c34  vmovaps xmm10, [rsp+0xA0]
0000705c56fe0c3d  vmovaps xmm12, [rsp+0xB0]
0000705c56fe0c46  vmovaps xmm13, [rsp+0xC0]
0000705c56fe0c4f  vmovaps xmm14, [rsp+0xD0]
0000705c56fe0c58  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0c61  add rsp, 0xF0
0000705c56fe0c68  pop r11
0000705c56fe0c6a  pop r10
0000705c56fe0c6c  pop r9
0000705c56fe0c6e  pop r8
0000705c56fe0c70  pop rsi
0000705c56fe0c71  pop rdi
0000705c56fe0c72  pop rdx
0000705c56fe0c73  pop rcx
0000705c56fe0c74  pop rax
0000705c56fe0c75  add rsp, 0x08
0000705c56fe0c79  jmp 0x0000705C56FDC6A0
0000705c56fe0c7e  call 0x0000705C56EC33A0
0000705c56fe0c83  jmp 0x0000705C56FDC6AA
0000705c56fe0c88  sub rsp, 0x08
0000705c56fe0c8c  push rax
0000705c56fe0c8d  push rcx
0000705c56fe0c8e  push rdx
0000705c56fe0c8f  push rdi
0000705c56fe0c90  push rsi
0000705c56fe0c91  push r8
0000705c56fe0c93  push r9
0000705c56fe0c95  push r10
0000705c56fe0c97  push r11
0000705c56fe0c99  sub rsp, 0xF0
0000705c56fe0ca0  vmovaps [rsp], xmm0
0000705c56fe0ca5  vmovaps [rsp+0x10], xmm1
0000705c56fe0cab  vmovaps [rsp+0x20], xmm2
0000705c56fe0cb1  vmovaps [rsp+0x30], xmm3
0000705c56fe0cb7  vmovaps [rsp+0x40], xmm4
0000705c56fe0cbd  vmovaps [rsp+0x50], xmm5
0000705c56fe0cc3  vmovaps [rsp+0x60], xmm6
0000705c56fe0cc9  vmovaps [rsp+0x70], xmm7
0000705c56fe0ccf  vmovaps [rsp+0x80], xmm8
0000705c56fe0cd8  vmovaps [rsp+0x90], xmm9
0000705c56fe0ce1  vmovaps [rsp+0xA0], xmm11
0000705c56fe0cea  vmovaps [rsp+0xB0], xmm12
0000705c56fe0cf3  vmovaps [rsp+0xC0], xmm13
0000705c56fe0cfc  vmovaps [rsp+0xD0], xmm14
0000705c56fe0d05  vmovaps [rsp+0xE0], xmm15
0000705c56fe0d0e  sub rsp, 0x30
0000705c56fe0d12  movaps [rsp], xmm10
0000705c56fe0d17  movaps [rsp+0x10], xmm1
0000705c56fe0d1c  movaps [rsp+0x20], xmm12
0000705c56fe0d22  lea rdi, [rsp]
0000705c56fe0d26  mov esi, 0x00
0000705c56fe0d2b  mov rax, 0x5877D3629530
0000705c56fe0d35  call rax
0000705c56fe0d37  movaps xmm10, [rsp]
0000705c56fe0d3c  add rsp, 0x30
0000705c56fe0d40  vmovaps xmm0, [rsp]
0000705c56fe0d45  vmovaps xmm1, [rsp+0x10]
0000705c56fe0d4b  vmovaps xmm2, [rsp+0x20]
0000705c56fe0d51  vmovaps xmm3, [rsp+0x30]
0000705c56fe0d57  vmovaps xmm4, [rsp+0x40]
0000705c56fe0d5d  vmovaps xmm5, [rsp+0x50]
0000705c56fe0d63  vmovaps xmm6, [rsp+0x60]
0000705c56fe0d69  vmovaps xmm7, [rsp+0x70]
0000705c56fe0d6f  vmovaps xmm8, [rsp+0x80]
0000705c56fe0d78  vmovaps xmm9, [rsp+0x90]
0000705c56fe0d81  vmovaps xmm11, [rsp+0xA0]
0000705c56fe0d8a  vmovaps xmm12, [rsp+0xB0]
0000705c56fe0d93  vmovaps xmm13, [rsp+0xC0]
0000705c56fe0d9c  vmovaps xmm14, [rsp+0xD0]
0000705c56fe0da5  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0dae  add rsp, 0xF0
0000705c56fe0db5  pop r11
0000705c56fe0db7  pop r10
0000705c56fe0db9  pop r9
0000705c56fe0dbb  pop r8
0000705c56fe0dbd  pop rsi
0000705c56fe0dbe  pop rdi
0000705c56fe0dbf  pop rdx
0000705c56fe0dc0  pop rcx
0000705c56fe0dc1  pop rax
0000705c56fe0dc2  add rsp, 0x08
0000705c56fe0dc6  jmp 0x0000705C56FDC6CD
0000705c56fe0dcb  sub rsp, 0x08
0000705c56fe0dcf  push rax
0000705c56fe0dd0  push rcx
0000705c56fe0dd1  push rdx
0000705c56fe0dd2  push rdi
0000705c56fe0dd3  push rsi
0000705c56fe0dd4  push r8
0000705c56fe0dd6  push r9
0000705c56fe0dd8  push r10
0000705c56fe0dda  push r11
0000705c56fe0ddc  sub rsp, 0xF0
0000705c56fe0de3  vmovaps [rsp], xmm0
0000705c56fe0de8  vmovaps [rsp+0x10], xmm1
0000705c56fe0dee  vmovaps [rsp+0x20], xmm2
0000705c56fe0df4  vmovaps [rsp+0x30], xmm3
0000705c56fe0dfa  vmovaps [rsp+0x40], xmm4
0000705c56fe0e00  vmovaps [rsp+0x50], xmm5
0000705c56fe0e06  vmovaps [rsp+0x60], xmm6
0000705c56fe0e0c  vmovaps [rsp+0x70], xmm7
0000705c56fe0e12  vmovaps [rsp+0x80], xmm8
0000705c56fe0e1b  vmovaps [rsp+0x90], xmm9
0000705c56fe0e24  vmovaps [rsp+0xA0], xmm10
0000705c56fe0e2d  vmovaps [rsp+0xB0], xmm11
0000705c56fe0e36  vmovaps [rsp+0xC0], xmm13
0000705c56fe0e3f  vmovaps [rsp+0xD0], xmm14
0000705c56fe0e48  vmovaps [rsp+0xE0], xmm15
0000705c56fe0e51  sub rsp, 0x30
0000705c56fe0e55  movaps [rsp], xmm12
0000705c56fe0e5a  movaps [rsp+0x10], xmm14
0000705c56fe0e60  movaps [rsp+0x20], xmm1
0000705c56fe0e65  lea rdi, [rsp]
0000705c56fe0e69  mov esi, 0x00
0000705c56fe0e6e  mov rax, 0x5877D3629530
0000705c56fe0e78  call rax
0000705c56fe0e7a  movaps xmm12, [rsp]
0000705c56fe0e7f  add rsp, 0x30
0000705c56fe0e83  vmovaps xmm0, [rsp]
0000705c56fe0e88  vmovaps xmm1, [rsp+0x10]
0000705c56fe0e8e  vmovaps xmm2, [rsp+0x20]
0000705c56fe0e94  vmovaps xmm3, [rsp+0x30]
0000705c56fe0e9a  vmovaps xmm4, [rsp+0x40]
0000705c56fe0ea0  vmovaps xmm5, [rsp+0x50]
0000705c56fe0ea6  vmovaps xmm6, [rsp+0x60]
0000705c56fe0eac  vmovaps xmm7, [rsp+0x70]
0000705c56fe0eb2  vmovaps xmm8, [rsp+0x80]
0000705c56fe0ebb  vmovaps xmm9, [rsp+0x90]
0000705c56fe0ec4  vmovaps xmm10, [rsp+0xA0]
0000705c56fe0ecd  vmovaps xmm11, [rsp+0xB0]
0000705c56fe0ed6  vmovaps xmm13, [rsp+0xC0]
0000705c56fe0edf  vmovaps xmm14, [rsp+0xD0]
0000705c56fe0ee8  vmovaps xmm15, [rsp+0xE0]
0000705c56fe0ef1  add rsp, 0xF0
0000705c56fe0ef8  pop r11
0000705c56fe0efa  pop r10
0000705c56fe0efc  pop r9
0000705c56fe0efe  pop r8
0000705c56fe0f00  pop rsi
0000705c56fe0f01  pop rdi
0000705c56fe0f02  pop rdx
0000705c56fe0f03  pop rcx
0000705c56fe0f04  pop rax
0000705c56fe0f05  add rsp, 0x08
0000705c56fe0f09  jmp 0x0000705C56FDC6FC
0000705c56fe0f0e  sub rsp, 0x08
0000705c56fe0f12  push rax
0000705c56fe0f13  push rcx
0000705c56fe0f14  push rdx
0000705c56fe0f15  push rdi
0000705c56fe0f16  push rsi
0000705c56fe0f17  push r8
0000705c56fe0f19  push r9
0000705c56fe0f1b  push r10
0000705c56fe0f1d  push r11
0000705c56fe0f1f  sub rsp, 0xF0
0000705c56fe0f26  vmovaps [rsp], xmm0
0000705c56fe0f2b  vmovaps [rsp+0x10], xmm1
0000705c56fe0f31  vmovaps [rsp+0x20], xmm2
0000705c56fe0f37  vmovaps [rsp+0x30], xmm3
0000705c56fe0f3d  vmovaps [rsp+0x40], xmm4
0000705c56fe0f43  vmovaps [rsp+0x50], xmm5
0000705c56fe0f49  vmovaps [rsp+0x60], xmm6
0000705c56fe0f4f  vmovaps [rsp+0x70], xmm7
0000705c56fe0f55  vmovaps [rsp+0x80], xmm8
0000705c56fe0f5e  vmovaps [rsp+0x90], xmm9
0000705c56fe0f67  vmovaps [rsp+0xA0], xmm10
0000705c56fe0f70  vmovaps [rsp+0xB0], xmm11
0000705c56fe0f79  vmovaps [rsp+0xC0], xmm12
0000705c56fe0f82  vmovaps [rsp+0xD0], xmm13
0000705c56fe0f8b  vmovaps [rsp+0xE0], xmm15
0000705c56fe0f94  sub rsp, 0x30
0000705c56fe0f98  movaps [rsp], xmm14
0000705c56fe0f9d  movaps [rsp+0x10], xmm9
0000705c56fe0fa3  movaps [rsp+0x20], xmm1
0000705c56fe0fa8  lea rdi, [rsp]
0000705c56fe0fac  mov esi, 0x00
0000705c56fe0fb1  mov rax, 0x5877D3629530
0000705c56fe0fbb  call rax
0000705c56fe0fbd  movaps xmm14, [rsp]
0000705c56fe0fc2  add rsp, 0x30
0000705c56fe0fc6  vmovaps xmm0, [rsp]
0000705c56fe0fcb  vmovaps xmm1, [rsp+0x10]
0000705c56fe0fd1  vmovaps xmm2, [rsp+0x20]
0000705c56fe0fd7  vmovaps xmm3, [rsp+0x30]
0000705c56fe0fdd  vmovaps xmm4, [rsp+0x40]
0000705c56fe0fe3  vmovaps xmm5, [rsp+0x50]
0000705c56fe0fe9  vmovaps xmm6, [rsp+0x60]
0000705c56fe0fef  vmovaps xmm7, [rsp+0x70]
0000705c56fe0ff5  vmovaps xmm8, [rsp+0x80]
0000705c56fe0ffe  vmovaps xmm9, [rsp+0x90]
0000705c56fe1007  vmovaps xmm10, [rsp+0xA0]
0000705c56fe1010  vmovaps xmm11, [rsp+0xB0]
0000705c56fe1019  vmovaps xmm12, [rsp+0xC0]
0000705c56fe1022  vmovaps xmm13, [rsp+0xD0]
0000705c56fe102b  vmovaps xmm15, [rsp+0xE0]
0000705c56fe1034  add rsp, 0xF0
0000705c56fe103b  pop r11
0000705c56fe103d  pop r10
0000705c56fe103f  pop r9
0000705c56fe1041  pop r8
0000705c56fe1043  pop rsi
0000705c56fe1044  pop rdi
0000705c56fe1045  pop rdx
0000705c56fe1046  pop rcx
0000705c56fe1047  pop rax
0000705c56fe1048  add rsp, 0x08
0000705c56fe104c  jmp 0x0000705C56FDC72B
0000705c56fe1051  sub rsp, 0x08
0000705c56fe1055  push rax
0000705c56fe1056  push rcx
0000705c56fe1057  push rdx
0000705c56fe1058  push rdi
0000705c56fe1059  push rsi
0000705c56fe105a  push r8
0000705c56fe105c  push r9
0000705c56fe105e  push r10
0000705c56fe1060  push r11
0000705c56fe1062  sub rsp, 0xF0
0000705c56fe1069  vmovaps [rsp], xmm0
0000705c56fe106e  vmovaps [rsp+0x10], xmm2
0000705c56fe1074  vmovaps [rsp+0x20], xmm3
0000705c56fe107a  vmovaps [rsp+0x30], xmm4
0000705c56fe1080  vmovaps [rsp+0x40], xmm5
0000705c56fe1086  vmovaps [rsp+0x50], xmm6
0000705c56fe108c  vmovaps [rsp+0x60], xmm7
0000705c56fe1092  vmovaps [rsp+0x70], xmm8
0000705c56fe1098  vmovaps [rsp+0x80], xmm9
0000705c56fe10a1  vmovaps [rsp+0x90], xmm10
0000705c56fe10aa  vmovaps [rsp+0xA0], xmm11
0000705c56fe10b3  vmovaps [rsp+0xB0], xmm12
0000705c56fe10bc  vmovaps [rsp+0xC0], xmm13
0000705c56fe10c5  vmovaps [rsp+0xD0], xmm14
0000705c56fe10ce  vmovaps [rsp+0xE0], xmm15
0000705c56fe10d7  sub rsp, 0x30
0000705c56fe10db  movaps [rsp], xmm1
0000705c56fe10df  movaps [rsp+0x10], xmm13
0000705c56fe10e5  movaps [rsp+0x20], xmm8
0000705c56fe10eb  lea rdi, [rsp]
0000705c56fe10ef  mov esi, 0x00
0000705c56fe10f4  mov rax, 0x5877D3629530
0000705c56fe10fe  call rax
0000705c56fe1100  movaps xmm1, [rsp]
0000705c56fe1104  add rsp, 0x30
0000705c56fe1108  vmovaps xmm0, [rsp]
0000705c56fe110d  vmovaps xmm2, [rsp+0x10]
0000705c56fe1113  vmovaps xmm3, [rsp+0x20]
0000705c56fe1119  vmovaps xmm4, [rsp+0x30]
0000705c56fe111f  vmovaps xmm5, [rsp+0x40]
0000705c56fe1125  vmovaps xmm6, [rsp+0x50]
0000705c56fe112b  vmovaps xmm7, [rsp+0x60]
0000705c56fe1131  vmovaps xmm8, [rsp+0x70]
0000705c56fe1137  vmovaps xmm9, [rsp+0x80]
0000705c56fe1140  vmovaps xmm10, [rsp+0x90]
0000705c56fe1149  vmovaps xmm11, [rsp+0xA0]
0000705c56fe1152  vmovaps xmm12, [rsp+0xB0]
0000705c56fe115b  vmovaps xmm13, [rsp+0xC0]
0000705c56fe1164  vmovaps xmm14, [rsp+0xD0]
0000705c56fe116d  vmovaps xmm15, [rsp+0xE0]
0000705c56fe1176  add rsp, 0xF0
0000705c56fe117d  pop r11
0000705c56fe117f  pop r10
0000705c56fe1181  pop r9
0000705c56fe1183  pop r8
0000705c56fe1185  pop rsi
0000705c56fe1186  pop rdi
0000705c56fe1187  pop rdx
0000705c56fe1188  pop rcx
0000705c56fe1189  pop rax
0000705c56fe118a  add rsp, 0x08
0000705c56fe118e  jmp 0x0000705C56FDC74D
0000705c56fe1193  call 0x0000705C56E0C260
0000705c56fe1198  jmp 0x0000705C56FDC75B
0000705c56fe119d  call 0x0000705C56EBD750
0000705c56fe11a2  jmp 0x0000705C56FDC765
0000705c56fe11a7  sub rsp, 0x08
0000705c56fe11ab  push rax
0000705c56fe11ac  push rcx
0000705c56fe11ad  push rdx
0000705c56fe11ae  push rdi
0000705c56fe11af  push rsi
0000705c56fe11b0  push r8
0000705c56fe11b2  push r9
0000705c56fe11b4  push r10
0000705c56fe11b6  push r11
0000705c56fe11b8  sub rsp, 0xF0
0000705c56fe11bf  vmovaps [rsp], xmm0
0000705c56fe11c4  vmovaps [rsp+0x10], xmm1
0000705c56fe11ca  vmovaps [rsp+0x20], xmm2
0000705c56fe11d0  vmovaps [rsp+0x30], xmm3
0000705c56fe11d6  vmovaps [rsp+0x40], xmm4
0000705c56fe11dc  vmovaps [rsp+0x50], xmm5
0000705c56fe11e2  vmovaps [rsp+0x60], xmm6
0000705c56fe11e8  vmovaps [rsp+0x70], xmm7
0000705c56fe11ee  vmovaps [rsp+0x80], xmm9
0000705c56fe11f7  vmovaps [rsp+0x90], xmm10
0000705c56fe1200  vmovaps [rsp+0xA0], xmm11
0000705c56fe1209  vmovaps [rsp+0xB0], xmm12
0000705c56fe1212  vmovaps [rsp+0xC0], xmm13
0000705c56fe121b  vmovaps [rsp+0xD0], xmm14
0000705c56fe1224  vmovaps [rsp+0xE0], xmm15
0000705c56fe122d  sub rsp, 0x30
0000705c56fe1231  movaps [rsp], xmm8
0000705c56fe1236  movaps [rsp+0x10], xmm15
0000705c56fe123c  movaps [rsp+0x20], xmm7
0000705c56fe1241  lea rdi, [rsp]
0000705c56fe1245  mov esi, 0x00
0000705c56fe124a  mov rax, 0x5877D3629530
0000705c56fe1254  call rax
0000705c56fe1256  movaps xmm8, [rsp]
0000705c56fe125b  add rsp, 0x30
0000705c56fe125f  vmovaps xmm0, [rsp]
0000705c56fe1264  vmovaps xmm1, [rsp+0x10]
0000705c56fe126a  vmovaps xmm2, [rsp+0x20]
0000705c56fe1270  vmovaps xmm3, [rsp+0x30]
0000705c56fe1276  vmovaps xmm4, [rsp+0x40]
0000705c56fe127c  vmovaps xmm5, [rsp+0x50]
0000705c56fe1282  vmovaps xmm6, [rsp+0x60]
0000705c56fe1288  vmovaps xmm7, [rsp+0x70]
0000705c56fe128e  vmovaps xmm9, [rsp+0x80]
0000705c56fe1297  vmovaps xmm10, [rsp+0x90]
0000705c56fe12a0  vmovaps xmm11, [rsp+0xA0]
0000705c56fe12a9  vmovaps xmm12, [rsp+0xB0]
0000705c56fe12b2  vmovaps xmm13, [rsp+0xC0]
0000705c56fe12bb  vmovaps xmm14, [rsp+0xD0]
0000705c56fe12c4  vmovaps xmm15, [rsp+0xE0]
0000705c56fe12cd  add rsp, 0xF0
0000705c56fe12d4  pop r11
0000705c56fe12d6  pop r10
0000705c56fe12d8  pop r9
0000705c56fe12da  pop r8
0000705c56fe12dc  pop rsi
0000705c56fe12dd  pop rdi
0000705c56fe12de  pop rdx
0000705c56fe12df  pop rcx
0000705c56fe12e0  pop rax
0000705c56fe12e1  add rsp, 0x08
0000705c56fe12e5  jmp 0x0000705C56FDC787
0000705c56fe12ea  sub rsp, 0x08
0000705c56fe12ee  push rax
0000705c56fe12ef  push rcx
0000705c56fe12f0  push rdx
0000705c56fe12f1  push rdi
0000705c56fe12f2  push rsi
0000705c56fe12f3  push r8
0000705c56fe12f5  push r9
0000705c56fe12f7  push r10
0000705c56fe12f9  push r11
0000705c56fe12fb  sub rsp, 0xF0
0000705c56fe1302  vmovaps [rsp], xmm0
0000705c56fe1307  vmovaps [rsp+0x10], xmm1
0000705c56fe130d  vmovaps [rsp+0x20], xmm2
0000705c56fe1313  vmovaps [rsp+0x30], xmm3
0000705c56fe1319  vmovaps [rsp+0x40], xmm4
0000705c56fe131f  vmovaps [rsp+0x50], xmm5
0000705c56fe1325  vmovaps [rsp+0x60], xmm6
0000705c56fe132b  vmovaps [rsp+0x70], xmm8
0000705c56fe1331  vmovaps [rsp+0x80], xmm9
0000705c56fe133a  vmovaps [rsp+0x90], xmm10
0000705c56fe1343  vmovaps [rsp+0xA0], xmm11
0000705c56fe134c  vmovaps [rsp+0xB0], xmm12
0000705c56fe1355  vmovaps [rsp+0xC0], xmm13
0000705c56fe135e  vmovaps [rsp+0xD0], xmm14
0000705c56fe1367  vmovaps [rsp+0xE0], xmm15
0000705c56fe1370  sub rsp, 0x30
0000705c56fe1374  movaps [rsp], xmm7
0000705c56fe1378  movaps [rsp+0x10], xmm9
0000705c56fe137e  movaps [rsp+0x20], xmm15
0000705c56fe1384  lea rdi, [rsp]
0000705c56fe1388  mov esi, 0x00
0000705c56fe138d  mov rax, 0x5877D3629530
0000705c56fe1397  call rax
0000705c56fe1399  movaps xmm7, [rsp]
0000705c56fe139d  add rsp, 0x30
0000705c56fe13a1  vmovaps xmm0, [rsp]
0000705c56fe13a6  vmovaps xmm1, [rsp+0x10]
0000705c56fe13ac  vmovaps xmm2, [rsp+0x20]
0000705c56fe13b2  vmovaps xmm3, [rsp+0x30]
0000705c56fe13b8  vmovaps xmm4, [rsp+0x40]
0000705c56fe13be  vmovaps xmm5, [rsp+0x50]
0000705c56fe13c4  vmovaps xmm6, [rsp+0x60]
0000705c56fe13ca  vmovaps xmm8, [rsp+0x70]
0000705c56fe13d0  vmovaps xmm9, [rsp+0x80]
0000705c56fe13d9  vmovaps xmm10, [rsp+0x90]
0000705c56fe13e2  vmovaps xmm11, [rsp+0xA0]
0000705c56fe13eb  vmovaps xmm12, [rsp+0xB0]
0000705c56fe13f4  vmovaps xmm13, [rsp+0xC0]
0000705c56fe13fd  vmovaps xmm14, [rsp+0xD0]
0000705c56fe1406  vmovaps xmm15, [rsp+0xE0]
0000705c56fe140f  add rsp, 0xF0
0000705c56fe1416  pop r11
0000705c56fe1418  pop r10
0000705c56fe141a  pop r9
0000705c56fe141c  pop r8
0000705c56fe141e  pop rsi
0000705c56fe141f  pop rdi
0000705c56fe1420  pop rdx
0000705c56fe1421  pop rcx
0000705c56fe1422  pop rax
0000705c56fe1423  add rsp, 0x08
0000705c56fe1427  jmp 0x0000705C56FDC7B4
0000705c56fe142c  sub rsp, 0x08
0000705c56fe1430  push rax
0000705c56fe1431  push rcx
0000705c56fe1432  push rdx
0000705c56fe1433  push rdi
0000705c56fe1434  push rsi
0000705c56fe1435  push r8
0000705c56fe1437  push r9
0000705c56fe1439  push r10
0000705c56fe143b  push r11
0000705c56fe143d  sub rsp, 0xF0
0000705c56fe1444  vmovaps [rsp], xmm0
0000705c56fe1449  vmovaps [rsp+0x10], xmm1
0000705c56fe144f  vmovaps [rsp+0x20], xmm2
0000705c56fe1455  vmovaps [rsp+0x30], xmm3
0000705c56fe145b  vmovaps [rsp+0x40], xmm4
0000705c56fe1461  vmovaps [rsp+0x50], xmm5
0000705c56fe1467  vmovaps [rsp+0x60], xmm6
0000705c56fe146d  vmovaps [rsp+0x70], xmm7
0000705c56fe1473  vmovaps [rsp+0x80], xmm8
0000705c56fe147c  vmovaps [rsp+0x90], xmm10
0000705c56fe1485  vmovaps [rsp+0xA0], xmm11
0000705c56fe148e  vmovaps [rsp+0xB0], xmm12
0000705c56fe1497  vmovaps [rsp+0xC0], xmm13
0000705c56fe14a0  vmovaps [rsp+0xD0], xmm14
0000705c56fe14a9  vmovaps [rsp+0xE0], xmm15
0000705c56fe14b2  sub rsp, 0x30
0000705c56fe14b6  movaps [rsp], xmm9
0000705c56fe14bb  movaps [rsp+0x10], xmm13
0000705c56fe14c1  movaps [rsp+0x20], xmm15
0000705c56fe14c7  lea rdi, [rsp]
0000705c56fe14cb  mov esi, 0x00
0000705c56fe14d0  mov rax, 0x5877D3629530
0000705c56fe14da  call rax
0000705c56fe14dc  movaps xmm9, [rsp]
0000705c56fe14e1  add rsp, 0x30
0000705c56fe14e5  vmovaps xmm0, [rsp]
0000705c56fe14ea  vmovaps xmm1, [rsp+0x10]
0000705c56fe14f0  vmovaps xmm2, [rsp+0x20]
0000705c56fe14f6  vmovaps xmm3, [rsp+0x30]
0000705c56fe14fc  vmovaps xmm4, [rsp+0x40]
0000705c56fe1502  vmovaps xmm5, [rsp+0x50]
0000705c56fe1508  vmovaps xmm6, [rsp+0x60]
0000705c56fe150e  vmovaps xmm7, [rsp+0x70]
0000705c56fe1514  vmovaps xmm8, [rsp+0x80]
0000705c56fe151d  vmovaps xmm10, [rsp+0x90]
0000705c56fe1526  vmovaps xmm11, [rsp+0xA0]
0000705c56fe152f  vmovaps xmm12, [rsp+0xB0]
0000705c56fe1538  vmovaps xmm13, [rsp+0xC0]
0000705c56fe1541  vmovaps xmm14, [rsp+0xD0]
0000705c56fe154a  vmovaps xmm15, [rsp+0xE0]
0000705c56fe1553  add rsp, 0xF0
0000705c56fe155a  pop r11
0000705c56fe155c  pop r10
0000705c56fe155e  pop r9
0000705c56fe1560  pop r8
0000705c56fe1562  pop rsi
0000705c56fe1563  pop rdi
0000705c56fe1564  pop rdx
0000705c56fe1565  pop rcx
0000705c56fe1566  pop rax
0000705c56fe1567  add rsp, 0x08
0000705c56fe156b  jmp 0x0000705C56FDC7E2
0000705c56fe1570  sub rsp, 0x08
0000705c56fe1574  push rax
0000705c56fe1575  push rcx
0000705c56fe1576  push rdx
0000705c56fe1577  push rdi
0000705c56fe1578  push rsi
0000705c56fe1579  push r8
0000705c56fe157b  push r9
0000705c56fe157d  push r10
0000705c56fe157f  push r11
0000705c56fe1581  sub rsp, 0xF0
0000705c56fe1588  vmovaps [rsp], xmm0
0000705c56fe158d  vmovaps [rsp+0x10], xmm1
0000705c56fe1593  vmovaps [rsp+0x20], xmm2
0000705c56fe1599  vmovaps [rsp+0x30], xmm3
0000705c56fe159f  vmovaps [rsp+0x40], xmm4
0000705c56fe15a5  vmovaps [rsp+0x50], xmm5
0000705c56fe15ab  vmovaps [rsp+0x60], xmm6
0000705c56fe15b1  vmovaps [rsp+0x70], xmm7
0000705c56fe15b7  vmovaps [rsp+0x80], xmm8
0000705c56fe15c0  vmovaps [rsp+0x90], xmm9
0000705c56fe15c9  vmovaps [rsp+0xA0], xmm10
0000705c56fe15d2  vmovaps [rsp+0xB0], xmm11
0000705c56fe15db  vmovaps [rsp+0xC0], xmm12
0000705c56fe15e4  vmovaps [rsp+0xD0], xmm13
0000705c56fe15ed  vmovaps [rsp+0xE0], xmm14
0000705c56fe15f6  sub rsp, 0x30
0000705c56fe15fa  movaps [rsp], xmm15
0000705c56fe15ff  movaps [rsp+0x10], xmm11
0000705c56fe1605  movaps [rsp+0x20], xmm12
0000705c56fe160b  lea rdi, [rsp]
0000705c56fe160f  mov esi, 0x00
0000705c56fe1614  mov rax, 0x5877D3629530
0000705c56fe161e  call rax
0000705c56fe1620  movaps xmm15, [rsp]
0000705c56fe1625  add rsp, 0x30
0000705c56fe1629  vmovaps xmm0, [rsp]
0000705c56fe162e  vmovaps xmm1, [rsp+0x10]
0000705c56fe1634  vmovaps xmm2, [rsp+0x20]
0000705c56fe163a  vmovaps xmm3, [rsp+0x30]
0000705c56fe1640  vmovaps xmm4, [rsp+0x40]
0000705c56fe1646  vmovaps xmm5, [rsp+0x50]
0000705c56fe164c  vmovaps xmm6, [rsp+0x60]
0000705c56fe1652  vmovaps xmm7, [rsp+0x70]
0000705c56fe1658  vmovaps xmm8, [rsp+0x80]
0000705c56fe1661  vmovaps xmm9, [rsp+0x90]
0000705c56fe166a  vmovaps xmm10, [rsp+0xA0]
0000705c56fe1673  vmovaps xmm11, [rsp+0xB0]
0000705c56fe167c  vmovaps xmm12, [rsp+0xC0]
0000705c56fe1685  vmovaps xmm13, [rsp+0xD0]
0000705c56fe168e  vmovaps xmm14, [rsp+0xE0]
0000705c56fe1697  add rsp, 0xF0
0000705c56fe169e  pop r11
0000705c56fe16a0  pop r10
0000705c56fe16a2  pop r9
0000705c56fe16a4  pop r8
0000705c56fe16a6  pop rsi
0000705c56fe16a7  pop rdi
0000705c56fe16a8  pop rdx
0000705c56fe16a9  pop rcx
0000705c56fe16aa  pop rax
0000705c56fe16ab  add rsp, 0x08
0000705c56fe16af  jmp 0x0000705C56FDC7FD
0000705c56fe16b4  sub rsp, 0x08
0000705c56fe16b8  push rax
0000705c56fe16b9  push rcx
0000705c56fe16ba  push rdx
0000705c56fe16bb  push rdi
0000705c56fe16bc  push rsi
0000705c56fe16bd  push r8
0000705c56fe16bf  push r9
0000705c56fe16c1  push r10
0000705c56fe16c3  push r11
0000705c56fe16c5  sub rsp, 0xF0
0000705c56fe16cc  vmovaps [rsp], xmm0
0000705c56fe16d1  vmovaps [rsp+0x10], xmm1
0000705c56fe16d7  vmovaps [rsp+0x20], xmm2
0000705c56fe16dd  vmovaps [rsp+0x30], xmm3
0000705c56fe16e3  vmovaps [rsp+0x40], xmm4
0000705c56fe16e9  vmovaps [rsp+0x50], xmm5
0000705c56fe16ef  vmovaps [rsp+0x60], xmm6
0000705c56fe16f5  vmovaps [rsp+0x70], xmm7
0000705c56fe16fb  vmovaps [rsp+0x80], xmm8
0000705c56fe1704  vmovaps [rsp+0x90], xmm9
0000705c56fe170d  vmovaps [rsp+0xA0], xmm10
0000705c56fe1716  vmovaps [rsp+0xB0], xmm11
0000705c56fe171f  vmovaps [rsp+0xC0], xmm12
0000705c56fe1728  vmovaps [rsp+0xD0], xmm14
0000705c56fe1731  vmovaps [rsp+0xE0], xmm15
0000705c56fe173a  sub rsp, 0x30
0000705c56fe173e  movaps [rsp], xmm13
0000705c56fe1743  movaps [rsp+0x10], xmm10
0000705c56fe1749  movaps [rsp+0x20], xmm14
0000705c56fe174f  lea rdi, [rsp]
0000705c56fe1753  mov esi, 0x00
0000705c56fe1758  mov rax, 0x5877D3629530
0000705c56fe1762  call rax
0000705c56fe1764  movaps xmm13, [rsp]
0000705c56fe1769  add rsp, 0x30
0000705c56fe176d  vmovaps xmm0, [rsp]
0000705c56fe1772  vmovaps xmm1, [rsp+0x10]
0000705c56fe1778  vmovaps xmm2, [rsp+0x20]
0000705c56fe177e  vmovaps xmm3, [rsp+0x30]
0000705c56fe1784  vmovaps xmm4, [rsp+0x40]
0000705c56fe178a  vmovaps xmm5, [rsp+0x50]
0000705c56fe1790  vmovaps xmm6, [rsp+0x60]
0000705c56fe1796  vmovaps xmm7, [rsp+0x70]
0000705c56fe179c  vmovaps xmm8, [rsp+0x80]
0000705c56fe17a5  vmovaps xmm9, [rsp+0x90]
0000705c56fe17ae  vmovaps xmm10, [rsp+0xA0]
0000705c56fe17b7  vmovaps xmm11, [rsp+0xB0]
0000705c56fe17c0  vmovaps xmm12, [rsp+0xC0]
0000705c56fe17c9  vmovaps xmm14, [rsp+0xD0]
0000705c56fe17d2  vmovaps xmm15, [rsp+0xE0]
0000705c56fe17db  add rsp, 0xF0
0000705c56fe17e2  pop r11
0000705c56fe17e4  pop r10
0000705c56fe17e6  pop r9
0000705c56fe17e8  pop r8
0000705c56fe17ea  pop rsi
0000705c56fe17eb  pop rdi
0000705c56fe17ec  pop rdx
0000705c56fe17ed  pop rcx
0000705c56fe17ee  pop rax
0000705c56fe17ef  add rsp, 0x08
0000705c56fe17f3  jmp 0x0000705C56FDC820
0000705c56fe17f8  sub rsp, 0x08
0000705c56fe17fc  push rax
0000705c56fe17fd  push rcx
0000705c56fe17fe  push rdx
0000705c56fe17ff  push rdi
0000705c56fe1800  push rsi
0000705c56fe1801  push r8
0000705c56fe1803  push r9
0000705c56fe1805  push r10
0000705c56fe1807  push r11
0000705c56fe1809  sub rsp, 0xF0
0000705c56fe1810  vmovaps [rsp], xmm0
0000705c56fe1815  vmovaps [rsp+0x10], xmm1
0000705c56fe181b  vmovaps [rsp+0x20], xmm2
0000705c56fe1821  vmovaps [rsp+0x30], xmm3
0000705c56fe1827  vmovaps [rsp+0x40], xmm4
0000705c56fe182d  vmovaps [rsp+0x50], xmm5
0000705c56fe1833  vmovaps [rsp+0x60], xmm6
0000705c56fe1839  vmovaps [rsp+0x70], xmm7
0000705c56fe183f  vmovaps [rsp+0x80], xmm8
0000705c56fe1848  vmovaps [rsp+0x90], xmm9
0000705c56fe1851  vmovaps [rsp+0xA0], xmm10
0000705c56fe185a  vmovaps [rsp+0xB0], xmm11
0000705c56fe1863  vmovaps [rsp+0xC0], xmm12
0000705c56fe186c  vmovaps [rsp+0xD0], xmm13
0000705c56fe1875  vmovaps [rsp+0xE0], xmm15
0000705c56fe187e  sub rsp, 0x30
0000705c56fe1882  movaps [rsp], xmm14
0000705c56fe1887  movaps [rsp+0x10], xmm1
0000705c56fe188c  movaps [rsp+0x20], xmm7
0000705c56fe1891  lea rdi, [rsp]
0000705c56fe1895  mov esi, 0x00
0000705c56fe189a  mov rax, 0x5877D3629530
0000705c56fe18a4  call rax
0000705c56fe18a6  movaps xmm14, [rsp]
0000705c56fe18ab  add rsp, 0x30
0000705c56fe18af  vmovaps xmm0, [rsp]
0000705c56fe18b4  vmovaps xmm1, [rsp+0x10]
0000705c56fe18ba  vmovaps xmm2, [rsp+0x20]
0000705c56fe18c0  vmovaps xmm3, [rsp+0x30]
0000705c56fe18c6  vmovaps xmm4, [rsp+0x40]
0000705c56fe18cc  vmovaps xmm5, [rsp+0x50]
0000705c56fe18d2  vmovaps xmm6, [rsp+0x60]
0000705c56fe18d8  vmovaps xmm7, [rsp+0x70]
0000705c56fe18de  vmovaps xmm8, [rsp+0x80]
0000705c56fe18e7  vmovaps xmm9, [rsp+0x90]
0000705c56fe18f0  vmovaps xmm10, [rsp+0xA0]
0000705c56fe18f9  vmovaps xmm11, [rsp+0xB0]
0000705c56fe1902  vmovaps xmm12, [rsp+0xC0]
0000705c56fe190b  vmovaps xmm13, [rsp+0xD0]
0000705c56fe1914  vmovaps xmm15, [rsp+0xE0]
0000705c56fe191d  add rsp, 0xF0
0000705c56fe1924  pop r11
0000705c56fe1926  pop r10
0000705c56fe1928  pop r9
0000705c56fe192a  pop r8
0000705c56fe192c  pop rsi
0000705c56fe192d  pop rdi
0000705c56fe192e  pop rdx
0000705c56fe192f  pop rcx
0000705c56fe1930  pop rax
0000705c56fe1931  add rsp, 0x08
0000705c56fe1935  jmp 0x0000705C56FDC843
0000705c56fe193a  sub rsp, 0x08
0000705c56fe193e  push rax
0000705c56fe193f  push rcx
0000705c56fe1940  push rdx
0000705c56fe1941  push rdi
0000705c56fe1942  push rsi
0000705c56fe1943  push r8
0000705c56fe1945  push r9
0000705c56fe1947  push r10
0000705c56fe1949  push r11
0000705c56fe194b  sub rsp, 0xF0
0000705c56fe1952  vmovaps [rsp], xmm0
0000705c56fe1957  vmovaps [rsp+0x10], xmm2
0000705c56fe195d  vmovaps [rsp+0x20], xmm3
0000705c56fe1963  vmovaps [rsp+0x30], xmm4
0000705c56fe1969  vmovaps [rsp+0x40], xmm5
0000705c56fe196f  vmovaps [rsp+0x50], xmm6
0000705c56fe1975  vmovaps [rsp+0x60], xmm7
0000705c56fe197b  vmovaps [rsp+0x70], xmm8
0000705c56fe1981  vmovaps [rsp+0x80], xmm9
0000705c56fe198a  vmovaps [rsp+0x90], xmm10
0000705c56fe1993  vmovaps [rsp+0xA0], xmm11
0000705c56fe199c  vmovaps [rsp+0xB0], xmm12
0000705c56fe19a5  vmovaps [rsp+0xC0], xmm13
0000705c56fe19ae  vmovaps [rsp+0xD0], xmm14
0000705c56fe19b7  vmovaps [rsp+0xE0], xmm15
0000705c56fe19c0  sub rsp, 0x30
0000705c56fe19c4  movaps [rsp], xmm1
0000705c56fe19c8  movaps [rsp+0x10], xmm8
0000705c56fe19ce  movaps [rsp+0x20], xmm9
0000705c56fe19d4  lea rdi, [rsp]
0000705c56fe19d8  mov esi, 0x00
0000705c56fe19dd  mov rax, 0x5877D3629530
0000705c56fe19e7  call rax
0000705c56fe19e9  movaps xmm1, [rsp]
0000705c56fe19ed  add rsp, 0x30
0000705c56fe19f1  vmovaps xmm0, [rsp]
0000705c56fe19f6  vmovaps xmm2, [rsp+0x10]
0000705c56fe19fc  vmovaps xmm3, [rsp+0x20]
0000705c56fe1a02  vmovaps xmm4, [rsp+0x30]
0000705c56fe1a08  vmovaps xmm5, [rsp+0x40]
0000705c56fe1a0e  vmovaps xmm6, [rsp+0x50]
0000705c56fe1a14  vmovaps xmm7, [rsp+0x60]
0000705c56fe1a1a  vmovaps xmm8, [rsp+0x70]
0000705c56fe1a20  vmovaps xmm9, [rsp+0x80]
0000705c56fe1a29  vmovaps xmm10, [rsp+0x90]
0000705c56fe1a32  vmovaps xmm11, [rsp+0xA0]
0000705c56fe1a3b  vmovaps xmm12, [rsp+0xB0]
0000705c56fe1a44  vmovaps xmm13, [rsp+0xC0]
0000705c56fe1a4d  vmovaps xmm14, [rsp+0xD0]
0000705c56fe1a56  vmovaps xmm15, [rsp+0xE0]
0000705c56fe1a5f  add rsp, 0xF0
0000705c56fe1a66  pop r11
0000705c56fe1a68  pop r10
0000705c56fe1a6a  pop r9
0000705c56fe1a6c  pop r8
0000705c56fe1a6e  pop rsi
0000705c56fe1a6f  pop rdi
0000705c56fe1a70  pop rdx
0000705c56fe1a71  pop rcx
0000705c56fe1a72  pop rax
0000705c56fe1a73  add rsp, 0x08
0000705c56fe1a77  jmp 0x0000705C56FDC865
0000705c56fe1a7c  call 0x0000705C56EE5940
0000705c56fe1a81  jmp 0x0000705C56FDC873
0000705c56fe1a86  call 0x0000705C56E0C380
0000705c56fe1a8b  jmp 0x0000705C56FDC87D
0000705c56fe1a90  call 0x0000705C56E0D600
0000705c56fe1a95  jmp 0x0000705C56FDC887
0000705c56fe1a9a  call 0x0000705C56DFF540
0000705c56fe1a9f  jmp 0x0000705C56FDC891
0000705c56fe1aa4  int3
0000705c56fe1aa5  nop [rax+rax*1], ax
0000705c56fe1aae  nop
0000705c56fe1ab0  mov rax, [r15+0xF8]
0000705c56fe1ab7  lea r14, [rax+0x140]
0000705c56fe1abe  mov r12, [r13+r14*1]
0000705c56fe1ac3  mov [r15+0xE8], r12
0000705c56fe1aca  lea r14, [rax+0x130]
0000705c56fe1ad1  mov r12, [r13+r14*1]
0000705c56fe1ad6  lea r14, [rax+0x138]
0000705c56fe1add  mov r11, [r13+r14*1]
0000705c56fe1ae2  movq xmm1, r12
0000705c56fe1ae7  movq xmm15, r11
0000705c56fe1aec  movq xmm1, xmm1
0000705c56fe1af0  movq xmm1, xmm1
0000705c56fe1af4  movaps [r15+0x1A0], xmm1
0000705c56fe1afc  movq xmm15, xmm15
0000705c56fe1b01  movq xmm15, xmm15
0000705c56fe1b06  movaps [r15+0x190], xmm15
0000705c56fe1b0e  lea r14, [rax+0x120]
0000705c56fe1b15  mov r12, [r13+r14*1]
0000705c56fe1b1a  lea r14, [rax+0x128]
0000705c56fe1b21  mov r11, [r13+r14*1]
0000705c56fe1b26  movq xmm1, r12
0000705c56fe1b2b  movq xmm15, r11
0000705c56fe1b30  movq xmm1, xmm1
0000705c56fe1b34  movq xmm1, xmm1
0000705c56fe1b38  movaps [r15+0x1C0], xmm1
0000705c56fe1b40  movq xmm15, xmm15
0000705c56fe1b45  movq xmm15, xmm15
0000705c56fe1b4a  movaps [r15+0x1B0], xmm15
0000705c56fe1b52  lea r14, [rax+0x110]
0000705c56fe1b59  mov r12, [r13+r14*1]
0000705c56fe1b5e  lea r14, [rax+0x118]
0000705c56fe1b65  mov r11, [r13+r14*1]
0000705c56fe1b6a  movq xmm1, r12
0000705c56fe1b6f  movq xmm15, r11
0000705c56fe1b74  movq xmm1, xmm1
0000705c56fe1b78  movq xmm1, xmm1
0000705c56fe1b7c  movaps [r15+0x1E0], xmm1
0000705c56fe1b84  movq xmm15, xmm15
0000705c56fe1b89  movq xmm15, xmm15
0000705c56fe1b8e  movaps [r15+0x1D0], xmm15
0000705c56fe1b96  lea r14, [rax+0x100]
0000705c56fe1b9d  mov r12, [r13+r14*1]
0000705c56fe1ba2  lea r14, [rax+0x108]
0000705c56fe1ba9  mov r11, [r13+r14*1]
0000705c56fe1bae  movq xmm1, r12
0000705c56fe1bb3  movq xmm15, r11
0000705c56fe1bb8  movq xmm1, xmm1
0000705c56fe1bbc  movq xmm1, xmm1
0000705c56fe1bc0  movaps [r15+0x200], xmm1
0000705c56fe1bc8  movq xmm15, xmm15
0000705c56fe1bcd  movq xmm15, xmm15
0000705c56fe1bd2  movaps [r15+0x1F0], xmm15
0000705c56fe1bda  mov qword ptr [r15+0x40], 0x430000
0000705c56fe1be2  mov r14d, 0x430510
0000705c56fe1be8  mov r12, [r13+r14*1]
0000705c56fe1bed  movq xmm1, r12
0000705c56fe1bf2  lea r14, [rax+0x150]
0000705c56fe1bf9  mov [r15+0xF8], r14
0000705c56fe1c00  mov rax, [r15+0x50]
0000705c56fe1c04  movups xmm15, [r13+rax*1]
0000705c56fe1c0a  movaps [r15+0x120], xmm15
0000705c56fe1c12  mov qword ptr [r15+0x48], 0x10
0000705c56fe1c1a  xor eax, eax
0000705c56fe1c1c  mov r14d, 0x10
0000705c56fe1c22  mov r12d, 0x200
0000705c56fe1c28  cmp r14, r12
0000705c56fe1c2b  cmc
0000705c56fe1c2c  lahf
0000705c56fe1c2d  seto al
0000705c56fe1c30  mov [r15+0x108], eax
0000705c56fe1c37  pextrq rax, xmm15, 0x01
0000705c56fe1c3e  movq xmm14, rax
0000705c56fe1c43  movaps [r15+0x130], xmm14
0000705c56fe1c4b  movq rax, xmm1
0000705c56fe1c50  movq r14, xmm15
0000705c56fe1c55  vmovq xmm1, rax
0000705c56fe1c5a  vmovq xmm15, r14
0000705c56fe1c5f  movaps xmm13, xmm1
0000705c56fe1c63  addsd xmm13, xmm15
0000705c56fe1c68  ucomisd xmm13, xmm13
0000705c56fe1c6d  jp 0x0000705C56FE1D86
0000705c56fe1c73  movq xmm13, xmm13
0000705c56fe1c78  movq rax, xmm13
0000705c56fe1c7d  movq r14, xmm14
0000705c56fe1c82  vmovq xmm1, rax
0000705c56fe1c87  vmovq xmm15, r14
0000705c56fe1c8c  movaps xmm14, xmm1
0000705c56fe1c90  addsd xmm14, xmm15
0000705c56fe1c95  ucomisd xmm14, xmm14
0000705c56fe1c9a  jp 0x0000705C56FE1DCE
0000705c56fe1ca0  movq xmm14, xmm14
0000705c56fe1ca5  movaps [r15+0x110], xmm14
0000705c56fe1cad  mov eax, [r15+0x108]
0000705c56fe1cb4  sahf
0000705c56fe1cb5  jnz 0x0000705C56FE1CE7
0000705c56fe1cb7  cmp dword ptr [r15+0x318], 0x00
0000705c56fe1cbf  jz 0x0000705C56FE1FE0
0000705c56fe1cc5  nop [rax+rax*1], ax
0000705c56fe1cce  nop [rax+rax*1], eax
0000705c56fe1cd6  mov eax, 0x410490
0000705c56fe1cdb  mov [r15+0x100], rax
0000705c56fe1ce2  jmp 0x0000705C56DFE110
0000705c56fe1ce7  cmp dword ptr [r15+0x318], 0x00
0000705c56fe1cef  jz 0x0000705C56FE1E20
0000705c56fe1cf5  nop [rax+rax*1], ax
0000705c56fe1cfe  nop [rax+rax*1], eax
0000705c56fe1d06  mov eax, 0x410474
0000705c56fe1d0b  mov [r15+0x100], rax
0000705c56fe1d12  jmp 0x0000705C56DFE110
0000705c56fe1d17  int3
0000705c56fe1d18  call 0x0000705C56EE27E0
0000705c56fe1d1d  jmp 0x0000705C56FE1AC3
0000705c56fe1d22  call 0x0000705C56EE27E0
0000705c56fe1d27  jmp 0x0000705C56FE1AD6
0000705c56fe1d2c  call 0x0000705C56EE1570
0000705c56fe1d31  jmp 0x0000705C56FE1AE2
0000705c56fe1d36  call 0x0000705C56EE27E0
0000705c56fe1d3b  jmp 0x0000705C56FE1B1A
0000705c56fe1d40  call 0x0000705C56EE1570
0000705c56fe1d45  jmp 0x0000705C56FE1B26
0000705c56fe1d4a  call 0x0000705C56EE27E0
0000705c56fe1d4f  jmp 0x0000705C56FE1B5E
0000705c56fe1d54  call 0x0000705C56EE1570
0000705c56fe1d59  jmp 0x0000705C56FE1B6A
0000705c56fe1d5e  call 0x0000705C56EE27E0
0000705c56fe1d63  jmp 0x0000705C56FE1BA2
0000705c56fe1d68  call 0x0000705C56EE1570
0000705c56fe1d6d  jmp 0x0000705C56FE1BAE
0000705c56fe1d72  call 0x0000705C56EE27E0
0000705c56fe1d77  jmp 0x0000705C56FE1BED
0000705c56fe1d7c  call 0x0000705C56E0E760
0000705c56fe1d81  jmp 0x0000705C56FE1C0A
0000705c56fe1d86  ucomisd xmm1, xmm15
0000705c56fe1d8b  jp 0x0000705C56FE1D9A
0000705c56fe1d8d  movaps xmm13, [0x0000705C56BFE060]
0000705c56fe1d95  jmp 0x0000705C56FE1C73
0000705c56fe1d9a  vxorps xmm0, xmm1, xmm15
0000705c56fe1d9f  pextrw eax, xmm0, 0x03
0000705c56fe1da4  and eax, 0x7FF8
0000705c56fe1da9  cmp eax, 0x08
0000705c56fe1dac  jnz 0x0000705C56FE1C73
0000705c56fe1db2  movq rax, xmm15
0000705c56fe1db7  shl rax, 0x0D
0000705c56fe1dbb  jbe 0x0000705C56FE1C73
0000705c56fe1dc1  vorps xmm13, xmm15, [0x0000705C56BFE070]
0000705c56fe1dc9  jmp 0x0000705C56FE1C73
0000705c56fe1dce  ucomisd xmm1, xmm15
0000705c56fe1dd3  jp 0x0000705C56FE1DE2
0000705c56fe1dd5  movaps xmm14, [0x0000705C56BFE060]
0000705c56fe1ddd  jmp 0x0000705C56FE1CA0
0000705c56fe1de2  vxorps xmm0, xmm1, xmm15
0000705c56fe1de7  pextrw eax, xmm0, 0x03
0000705c56fe1dec  and eax, 0x7FF8
0000705c56fe1df1  cmp eax, 0x08
0000705c56fe1df4  jnz 0x0000705C56FE1CA0
0000705c56fe1dfa  movq rax, xmm15
0000705c56fe1dff  shl rax, 0x0D
0000705c56fe1e03  jbe 0x0000705C56FE1CA0
0000705c56fe1e09  vorps xmm14, xmm15, [0x0000705C56BFE070]
0000705c56fe1e11  jmp 0x0000705C56FE1CA0
0000705c56fe1e16  int3
0000705c56fe1e17  nop [rax+rax*1], ax
0000705c56fe1e20  mov rax, [r15+0x48]
0000705c56fe1e24  mov r14, [r15+0x50]
0000705c56fe1e28  lea r12, [r14+rax*1]
0000705c56fe1e2c  movups xmm1, [r13+r12*1]
0000705c56fe1e32  movaps [r15+0x120], xmm1
0000705c56fe1e3a  lea r14, [rax+0x10]
0000705c56fe1e3e  mov [r15+0x48], r14
0000705c56fe1e42  xor eax, eax
0000705c56fe1e44  mov r12d, 0x200
0000705c56fe1e4a  cmp r14, r12
0000705c56fe1e4d  cmc
0000705c56fe1e4e  lahf
0000705c56fe1e4f  seto al
0000705c56fe1e52  mov [r15+0x108], eax
0000705c56fe1e59  pextrq rax, xmm1, 0x01
0000705c56fe1e60  movq xmm15, rax
0000705c56fe1e65  movaps [r15+0x130], xmm15
0000705c56fe1e6d  movaps xmm14, [r15+0x110]
0000705c56fe1e75  movq rax, xmm14
0000705c56fe1e7a  movq r14, xmm1
0000705c56fe1e7f  vmovq xmm1, rax
0000705c56fe1e84  vmovq xmm14, r14
0000705c56fe1e89  movaps xmm13, xmm1
0000705c56fe1e8d  addsd xmm13, xmm14
0000705c56fe1e92  ucomisd xmm13, xmm13
0000705c56fe1e97  jp 0x0000705C56FE1F4C
0000705c56fe1e9d  movq xmm13, xmm13
0000705c56fe1ea2  movq rax, xmm13
0000705c56fe1ea7  movq r14, xmm15
0000705c56fe1eac  vmovq xmm1, rax
0000705c56fe1eb1  vmovq xmm15, r14
0000705c56fe1eb6  movaps xmm14, xmm1
0000705c56fe1eba  addsd xmm14, xmm15
0000705c56fe1ebf  ucomisd xmm14, xmm14
0000705c56fe1ec4  jp 0x0000705C56FE1F94
0000705c56fe1eca  movq xmm14, xmm14
0000705c56fe1ecf  movaps [r15+0x110], xmm14
0000705c56fe1ed7  mov eax, [r15+0x108]
0000705c56fe1ede  sahf
0000705c56fe1edf  jnz 0x0000705C56FE1F11
0000705c56fe1ee1  cmp dword ptr [r15+0x318], 0x00
0000705c56fe1ee9  jz 0x0000705C56FE1FE0
0000705c56fe1eef  nop [rax+rax*1], ax
0000705c56fe1ef8  nop [rax+rax*1], eax
0000705c56fe1f00  mov eax, 0x410490
0000705c56fe1f05  mov [r15+0x100], rax
0000705c56fe1f0c  jmp 0x0000705C56DFE110
0000705c56fe1f11  cmp dword ptr [r15+0x318], 0x00
0000705c56fe1f19  jz 0x0000705C56FE1E20
0000705c56fe1f1f  nop [rax+rax*1], ax
0000705c56fe1f28  nop [rax+rax*1], eax
0000705c56fe1f30  mov eax, 0x410474
0000705c56fe1f35  mov [r15+0x100], rax
0000705c56fe1f3c  jmp 0x0000705C56DFE110
0000705c56fe1f41  int3
0000705c56fe1f42  call 0x0000705C56EB52F0
0000705c56fe1f47  jmp 0x0000705C56FE1E32
0000705c56fe1f4c  ucomisd xmm1, xmm14
0000705c56fe1f51  jp 0x0000705C56FE1F60
0000705c56fe1f53  movaps xmm13, [0x0000705C56BFE060]
0000705c56fe1f5b  jmp 0x0000705C56FE1E9D
0000705c56fe1f60  vxorps xmm0, xmm1, xmm14
0000705c56fe1f65  pextrw eax, xmm0, 0x03
0000705c56fe1f6a  and eax, 0x7FF8
0000705c56fe1f6f  cmp eax, 0x08
0000705c56fe1f72  jnz 0x0000705C56FE1E9D
0000705c56fe1f78  movq rax, xmm14
0000705c56fe1f7d  shl rax, 0x0D
0000705c56fe1f81  jbe 0x0000705C56FE1E9D
0000705c56fe1f87  vorps xmm13, xmm14, [0x0000705C56BFE070]
0000705c56fe1f8f  jmp 0x0000705C56FE1E9D
0000705c56fe1f94  ucomisd xmm1, xmm15
0000705c56fe1f99  jp 0x0000705C56FE1FA8
0000705c56fe1f9b  movaps xmm14, [0x0000705C56BFE060]
0000705c56fe1fa3  jmp 0x0000705C56FE1ECA
0000705c56fe1fa8  vxorps xmm0, xmm1, xmm15
0000705c56fe1fad  pextrw eax, xmm0, 0x03
0000705c56fe1fb2  and eax, 0x7FF8
0000705c56fe1fb7  cmp eax, 0x08
0000705c56fe1fba  jnz 0x0000705C56FE1ECA
0000705c56fe1fc0  movq rax, xmm15
0000705c56fe1fc5  shl rax, 0x0D
0000705c56fe1fc9  jbe 0x0000705C56FE1ECA
0000705c56fe1fcf  vorps xmm14, xmm15, [0x0000705C56BFE070]
0000705c56fe1fd7  jmp 0x0000705C56FE1ECA
0000705c56fe1fdc  int3
0000705c56fe1fdd  nop [rax], eax
0000705c56fe1fe0  mov rax, [r15+0x40]
0000705c56fe1fe4  lea r14, [rax+0x510]
0000705c56fe1feb  movaps xmm1, [r15+0x110]
0000705c56fe1ff3  movq rax, xmm1
0000705c56fe1ff8  mov [r13+r14*1], rax
0000705c56fe1ffd  mov rax, [r15+0xF0]
0000705c56fe2004  mov [r15+0x100], rax
0000705c56fe200b  jmp 0x0000705C56FCE5C0
0000705c56fe2010  int3
0000705c56fe2011  call 0x0000705C56ED5EB0
0000705c56fe2016  jmp 0x0000705C56FE1FFD
0000705c56fe201b  int3
0000705c56fe201c  nop [rax], eax
0000705c56fe2020  mov qword ptr [r15+0x100], 0x04
0000705c56fe202b  mov esi, 0x00
0000705c56fe2030  mov edx, 0x09
0000705c56fe2035  mov rdi, 0x7FFC82156860
0000705c56fe203f  mov rax, 0x5877D34BC970
0000705c56fe2049  call rax
0000705c56fe204b  cmp dword ptr [r15+0x318], 0x00
0000705c56fe2053  jnz 0x0000705C56DFE110
0000705c56fe2059  jmp 0x0000705C56DFE0A0
0000705c56fe205e  int3
0000705c56fe205f  int3
