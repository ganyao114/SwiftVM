000076cd267ce69b  nop [rax+rax*1], eax
000076cd267ce6a0  vmovaps xmm1, [0x000076CD263FE010]
000076cd267ce6a8  movq xmm1, xmm1
000076cd267ce6ac  movaps [r15+0x110], xmm1
000076cd267ce6b4  vmovaps xmm1, [0x000076CD263FE020]
000076cd267ce6bc  movq xmm1, xmm1
000076cd267ce6c0  movaps [r15+0x120], xmm1
000076cd267ce6c8  mov eax, 0x4204C0
000076cd267ce6cd  mov r14, [r13+rax*1]
000076cd267ce6d2  movq xmm1, r14
000076cd267ce6d7  movaps [r15+0x130], xmm1
000076cd267ce6df  vmovaps xmm1, [0x000076CD263FE030]
000076cd267ce6e7  vpbroadcastq xmm1, xmm1
000076cd267ce6ec  movaps [r15+0x140], xmm1
000076cd267ce6f4  mov qword ptr [r15+0x40], 0x02
000076cd267ce6fc  vmovaps xmm15, [0x000076CD263FE040]
000076cd267ce704  movq xmm15, xmm15
000076cd267ce709  movaps [r15+0x150], xmm15
000076cd267ce711  mov qword ptr [r15+0x58], 0x420000
000076cd267ce719  vmovaps xmm15, [0x000076CD263FE050]
000076cd267ce721  vpbroadcastq xmm15, xmm15
000076cd267ce726  movaps [r15+0x160], xmm15
000076cd267ce72e  mov rax, [r15+0x40]
000076cd267ce732  vmovq xmm14, rax
000076cd267ce737  vpbroadcastq xmm14, xmm14
000076cd267ce73c  movaps [r15+0x170], xmm14
000076cd267ce744  mov eax, 0x4204D0
000076cd267ce749  movups xmm13, [r13+rax*1]
000076cd267ce74f  mov qword ptr [r15+0x40], 0x430518
000076cd267ce757  mov qword ptr [r15+0x50], 0x430720
000076cd267ce75f  vpmovqd xmm12, xmm13
000076cd267ce765  pxor xmm11, xmm11
000076cd267ce76a  punpcklqdq xmm12, xmm11
000076cd267ce76f  movaps [r15+0x210], xmm12
000076cd267ce777  movq xmm12, qword ptr [r15+0x120]
000076cd267ce780  movq xmm11, qword ptr [r15+0x130]
000076cd267ce789  psubd xmm12, xmm11
000076cd267ce78e  movq xmm12, xmm12
000076cd267ce793  paddq xmm13, xmm14
000076cd267ce798  movaps [r15+0x180], xmm13
000076cd267ce7a0  movq xmm14, qword ptr [r15+0x150]
000076cd267ce7a9  paddd xmm11, xmm14
000076cd267ce7ae  movq xmm11, xmm11
000076cd267ce7b3  movq xmm11, xmm11
000076cd267ce7b8  movaps [r15+0x130], xmm11
000076cd267ce7c0  pmovzxdq xmm12, xmm12
000076cd267ce7c6  psllq xmm12, 0x00
000076cd267ce7cc  movq xmm14, qword ptr [r15+0x210]
000076cd267ce7d5  movq xmm13, qword ptr [r15+0x110]
000076cd267ce7de  paddd xmm14, xmm13
000076cd267ce7e3  movq xmm14, xmm14
000076cd267ce7e8  vcvtuqq2pd xmm12, xmm12
000076cd267ce7ee  pmovzxdq xmm14, xmm14
000076cd267ce7f4  psllq xmm14, 0x00
000076cd267ce7fa  vcvtuqq2pd xmm14, xmm14
000076cd267ce800  movaps xmm13, xmm12
000076cd267ce804  mulpd xmm13, xmm1
000076cd267ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000076cd267ce80f  ptest xmm11, xmm11
000076cd267ce815  jnz 0x000076CD267CE8FF
000076cd267ce81b  movaps [r15+0x220], xmm13
000076cd267ce823  mov eax, 0x430720
000076cd267ce828  movups [r13+rax*1], xmm13
000076cd267ce82e  movaps xmm1, xmm14
000076cd267ce832  mulpd xmm1, xmm15
000076cd267ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000076cd267ce83c  ptest xmm13, xmm13
000076cd267ce842  jnz 0x000076CD267CEA4C
000076cd267ce848  movaps [r15+0x210], xmm1
000076cd267ce850  mov eax, 0x430518
000076cd267ce855  movups [r13+rax*1], xmm1
000076cd267ce85b  mov qword ptr [r15+0x48], 0x10
000076cd267ce863  xor eax, eax
000076cd267ce865  mov r14d, 0x10
000076cd267ce86b  mov r12d, 0x200
000076cd267ce871  cmp r14, r12
000076cd267ce874  cmc
000076cd267ce875  lahf
000076cd267ce876  seto al
000076cd267ce879  mov [r15+0x108], eax
000076cd267ce880  mov eax, [r15+0x108]
000076cd267ce887  sahf
000076cd267ce888  jnz 0x000076CD267CE8BA
000076cd267ce88a  cmp dword ptr [r15+0x318], 0x00
000076cd267ce892  jz 0x000076CD267CEFF0
000076cd267ce898  nop [rax+rax*1], ax
000076cd267ce8a1  nop [rax+rax*1], eax
000076cd267ce8a9  mov eax, 0x4101EC
000076cd267ce8ae  mov [r15+0x100], rax
000076cd267ce8b5  jmp 0x000076CD265FE110
000076cd267ce8ba  cmp dword ptr [r15+0x318], 0x00
000076cd267ce8c2  jz 0x000076CD267CEBA0
000076cd267ce8c8  nop [rax+rax*1], ax
000076cd267ce8d1  nop [rax+rax*1], eax
000076cd267ce8d9  mov eax, 0x4101AC
000076cd267ce8de  mov [r15+0x100], rax
000076cd267ce8e5  jmp 0x000076CD265FE110
000076cd267ce8ea  int3
000076cd267ce8eb  call 0x000076CD2660DC20
000076cd267ce8f0  jmp 0x000076CD267CE6D2
000076cd267ce8f5  call 0x000076CD2660C260
000076cd267ce8fa  jmp 0x000076CD267CE74F
000076cd267ce8ff  sub rsp, 0x08
000076cd267ce903  push rax
000076cd267ce904  push rcx
000076cd267ce905  push rdx
000076cd267ce906  push rdi
000076cd267ce907  push rsi
000076cd267ce908  push r8
000076cd267ce90a  push r9
000076cd267ce90c  push r10
000076cd267ce90e  push r11
000076cd267ce910  sub rsp, 0xF0
000076cd267ce917  vmovaps [rsp], xmm0
000076cd267ce91c  vmovaps [rsp+0x10], xmm1
000076cd267ce922  vmovaps [rsp+0x20], xmm2
000076cd267ce928  vmovaps [rsp+0x30], xmm3
000076cd267ce92e  vmovaps [rsp+0x40], xmm4
000076cd267ce934  vmovaps [rsp+0x50], xmm5
000076cd267ce93a  vmovaps [rsp+0x60], xmm6
000076cd267ce940  vmovaps [rsp+0x70], xmm7
000076cd267ce946  vmovaps [rsp+0x80], xmm8
000076cd267ce94f  vmovaps [rsp+0x90], xmm9
000076cd267ce958  vmovaps [rsp+0xA0], xmm10
000076cd267ce961  vmovaps [rsp+0xB0], xmm11
000076cd267ce96a  vmovaps [rsp+0xC0], xmm12
000076cd267ce973  vmovaps [rsp+0xD0], xmm14
000076cd267ce97c  vmovaps [rsp+0xE0], xmm15
000076cd267ce985  sub rsp, 0x30
000076cd267ce989  movaps [rsp], xmm13
000076cd267ce98e  movaps [rsp+0x10], xmm12
000076cd267ce994  movaps [rsp+0x20], xmm1
000076cd267ce999  lea rdi, [rsp]
000076cd267ce99d  mov esi, 0x00
000076cd267ce9a2  mov rax, 0x56B8861A9530
000076cd267ce9ac  call rax
000076cd267ce9ae  movaps xmm13, [rsp]
000076cd267ce9b3  add rsp, 0x30
000076cd267ce9b7  vmovaps xmm0, [rsp]
000076cd267ce9bc  vmovaps xmm1, [rsp+0x10]
000076cd267ce9c2  vmovaps xmm2, [rsp+0x20]
000076cd267ce9c8  vmovaps xmm3, [rsp+0x30]
000076cd267ce9ce  vmovaps xmm4, [rsp+0x40]
000076cd267ce9d4  vmovaps xmm5, [rsp+0x50]
000076cd267ce9da  vmovaps xmm6, [rsp+0x60]
000076cd267ce9e0  vmovaps xmm7, [rsp+0x70]
000076cd267ce9e6  vmovaps xmm8, [rsp+0x80]
000076cd267ce9ef  vmovaps xmm9, [rsp+0x90]
000076cd267ce9f8  vmovaps xmm10, [rsp+0xA0]
000076cd267cea01  vmovaps xmm11, [rsp+0xB0]
000076cd267cea0a  vmovaps xmm12, [rsp+0xC0]
000076cd267cea13  vmovaps xmm14, [rsp+0xD0]
000076cd267cea1c  vmovaps xmm15, [rsp+0xE0]
000076cd267cea25  add rsp, 0xF0
000076cd267cea2c  pop r11
000076cd267cea2e  pop r10
000076cd267cea30  pop r9
000076cd267cea32  pop r8
000076cd267cea34  pop rsi
000076cd267cea35  pop rdi
000076cd267cea36  pop rdx
000076cd267cea37  pop rcx
000076cd267cea38  pop rax
000076cd267cea39  add rsp, 0x08
000076cd267cea3d  jmp 0x000076CD267CE81B
000076cd267cea42  call 0x000076CD2660C380
000076cd267cea47  jmp 0x000076CD267CE82E
000076cd267cea4c  sub rsp, 0x08
000076cd267cea50  push rax
000076cd267cea51  push rcx
000076cd267cea52  push rdx
000076cd267cea53  push rdi
000076cd267cea54  push rsi
000076cd267cea55  push r8
000076cd267cea57  push r9
000076cd267cea59  push r10
000076cd267cea5b  push r11
000076cd267cea5d  sub rsp, 0xF0
000076cd267cea64  vmovaps [rsp], xmm0
000076cd267cea69  vmovaps [rsp+0x10], xmm2
000076cd267cea6f  vmovaps [rsp+0x20], xmm3
000076cd267cea75  vmovaps [rsp+0x30], xmm4
000076cd267cea7b  vmovaps [rsp+0x40], xmm5
000076cd267cea81  vmovaps [rsp+0x50], xmm6
000076cd267cea87  vmovaps [rsp+0x60], xmm7
000076cd267cea8d  vmovaps [rsp+0x70], xmm8
000076cd267cea93  vmovaps [rsp+0x80], xmm9
000076cd267cea9c  vmovaps [rsp+0x90], xmm10
000076cd267ceaa5  vmovaps [rsp+0xA0], xmm11
000076cd267ceaae  vmovaps [rsp+0xB0], xmm12
000076cd267ceab7  vmovaps [rsp+0xC0], xmm13
000076cd267ceac0  vmovaps [rsp+0xD0], xmm14
000076cd267ceac9  vmovaps [rsp+0xE0], xmm15
000076cd267cead2  sub rsp, 0x30
000076cd267cead6  movaps [rsp], xmm1
000076cd267ceada  movaps [rsp+0x10], xmm14
000076cd267ceae0  movaps [rsp+0x20], xmm15
000076cd267ceae6  lea rdi, [rsp]
000076cd267ceaea  mov esi, 0x00
000076cd267ceaef  mov rax, 0x56B8861A9530
000076cd267ceaf9  call rax
000076cd267ceafb  movaps xmm1, [rsp]
000076cd267ceaff  add rsp, 0x30
000076cd267ceb03  vmovaps xmm0, [rsp]
000076cd267ceb08  vmovaps xmm2, [rsp+0x10]
000076cd267ceb0e  vmovaps xmm3, [rsp+0x20]
000076cd267ceb14  vmovaps xmm4, [rsp+0x30]
000076cd267ceb1a  vmovaps xmm5, [rsp+0x40]
000076cd267ceb20  vmovaps xmm6, [rsp+0x50]
000076cd267ceb26  vmovaps xmm7, [rsp+0x60]
000076cd267ceb2c  vmovaps xmm8, [rsp+0x70]
000076cd267ceb32  vmovaps xmm9, [rsp+0x80]
000076cd267ceb3b  vmovaps xmm10, [rsp+0x90]
000076cd267ceb44  vmovaps xmm11, [rsp+0xA0]
000076cd267ceb4d  vmovaps xmm12, [rsp+0xB0]
000076cd267ceb56  vmovaps xmm13, [rsp+0xC0]
000076cd267ceb5f  vmovaps xmm14, [rsp+0xD0]
000076cd267ceb68  vmovaps xmm15, [rsp+0xE0]
000076cd267ceb71  add rsp, 0xF0
000076cd267ceb78  pop r11
000076cd267ceb7a  pop r10
000076cd267ceb7c  pop r9
000076cd267ceb7e  pop r8
000076cd267ceb80  pop rsi
000076cd267ceb81  pop rdi
000076cd267ceb82  pop rdx
000076cd267ceb83  pop rcx
000076cd267ceb84  pop rax
000076cd267ceb85  add rsp, 0x08
000076cd267ceb89  jmp 0x000076CD267CE848
000076cd267ceb8e  call 0x000076CD265FF540
000076cd267ceb93  jmp 0x000076CD267CE85B
000076cd267ceb98  int3
000076cd267ceb99  nop [rax], eax
000076cd267ceba0  movaps xmm1, [r15+0x180]
000076cd267ceba8  vpmovqd xmm15, xmm1
000076cd267cebae  pxor xmm14, xmm14
000076cd267cebb3  punpcklqdq xmm15, xmm14
000076cd267cebb8  movaps [r15+0x210], xmm15
000076cd267cebc0  movq xmm15, qword ptr [r15+0x120]
000076cd267cebc9  movq xmm14, qword ptr [r15+0x130]
000076cd267cebd2  psubd xmm15, xmm14
000076cd267cebd7  movq xmm15, xmm15
000076cd267cebdc  movaps xmm13, [r15+0x170]
000076cd267cebe4  paddq xmm1, xmm13
000076cd267cebe9  movaps [r15+0x180], xmm1
000076cd267cebf1  movq xmm1, qword ptr [r15+0x150]
000076cd267cebfa  paddd xmm14, xmm1
000076cd267cebff  movq xmm14, xmm14
000076cd267cec04  movq xmm14, xmm14
000076cd267cec09  movaps [r15+0x130], xmm14
000076cd267cec11  pmovzxdq xmm15, xmm15
000076cd267cec17  psllq xmm15, 0x00
000076cd267cec1d  movq xmm1, qword ptr [r15+0x210]
000076cd267cec26  movq xmm14, qword ptr [r15+0x110]
000076cd267cec2f  paddd xmm1, xmm14
000076cd267cec34  movq xmm1, xmm1
000076cd267cec38  vcvtuqq2pd xmm15, xmm15
000076cd267cec3e  pmovzxdq xmm1, xmm1
000076cd267cec43  psllq xmm1, 0x00
000076cd267cec48  vcvtuqq2pd xmm1, xmm1
000076cd267cec4e  movaps xmm14, [r15+0x140]
000076cd267cec56  movaps xmm13, xmm15
000076cd267cec5a  mulpd xmm13, xmm14
000076cd267cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000076cd267cec65  ptest xmm12, xmm12
000076cd267cec6b  jnz 0x000076CD267CED4E
000076cd267cec71  movaps [r15+0x220], xmm13
000076cd267cec79  mov rax, [r15+0x48]
000076cd267cec7d  mov r14, [r15+0x50]
000076cd267cec81  lea r12, [r14+rax*1]
000076cd267cec85  movups [r13+r12*1], xmm13
000076cd267cec8b  movaps xmm15, [r15+0x160]
000076cd267cec93  movaps xmm14, xmm1
000076cd267cec97  mulpd xmm14, xmm15
000076cd267cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000076cd267ceca2  ptest xmm13, xmm13
000076cd267ceca8  jnz 0x000076CD267CEE9C
000076cd267cecae  movaps [r15+0x210], xmm14
000076cd267cecb6  mov r14, [r15+0x40]
000076cd267cecba  lea r12, [r14+rax*1]
000076cd267cecbe  movups [r13+r12*1], xmm14
000076cd267cecc4  lea r14, [rax+0x10]
000076cd267cecc8  mov [r15+0x48], r14
000076cd267ceccc  xor eax, eax
000076cd267cecce  mov r12d, 0x200
000076cd267cecd4  cmp r14, r12
000076cd267cecd7  cmc
000076cd267cecd8  lahf
000076cd267cecd9  seto al
000076cd267cecdc  mov [r15+0x108], eax
000076cd267cece3  mov eax, [r15+0x108]
000076cd267cecea  sahf
000076cd267ceceb  jnz 0x000076CD267CED1D
000076cd267ceced  cmp dword ptr [r15+0x318], 0x00
000076cd267cecf5  jz 0x000076CD267CEFF0
000076cd267cecfb  nop [rax+rax*1], ax
000076cd267ced04  nop [rax+rax*1], eax
000076cd267ced0c  mov eax, 0x4101EC
000076cd267ced11  mov [r15+0x100], rax
000076cd267ced18  jmp 0x000076CD265FE110
000076cd267ced1d  cmp dword ptr [r15+0x318], 0x00
000076cd267ced25  jz 0x000076CD267CEBA0
000076cd267ced2b  nop [rax+rax*1], ax
000076cd267ced34  nop [rax+rax*1], eax
000076cd267ced3c  mov eax, 0x4101AC
000076cd267ced41  mov [r15+0x100], rax
000076cd267ced48  jmp 0x000076CD265FE110
000076cd267ced4d  int3
000076cd267ced4e  sub rsp, 0x08
000076cd267ced52  push rax
000076cd267ced53  push rcx
000076cd267ced54  push rdx
000076cd267ced55  push rdi
000076cd267ced56  push rsi
000076cd267ced57  push r8
000076cd267ced59  push r9
000076cd267ced5b  push r10
000076cd267ced5d  push r11
000076cd267ced5f  sub rsp, 0xF0
000076cd267ced66  vmovaps [rsp], xmm0
000076cd267ced6b  vmovaps [rsp+0x10], xmm1
000076cd267ced71  vmovaps [rsp+0x20], xmm2
000076cd267ced77  vmovaps [rsp+0x30], xmm3
000076cd267ced7d  vmovaps [rsp+0x40], xmm4
000076cd267ced83  vmovaps [rsp+0x50], xmm5
000076cd267ced89  vmovaps [rsp+0x60], xmm6
000076cd267ced8f  vmovaps [rsp+0x70], xmm7
000076cd267ced95  vmovaps [rsp+0x80], xmm8
000076cd267ced9e  vmovaps [rsp+0x90], xmm9
000076cd267ceda7  vmovaps [rsp+0xA0], xmm10
000076cd267cedb0  vmovaps [rsp+0xB0], xmm11
000076cd267cedb9  vmovaps [rsp+0xC0], xmm12
000076cd267cedc2  vmovaps [rsp+0xD0], xmm14
000076cd267cedcb  vmovaps [rsp+0xE0], xmm15
000076cd267cedd4  sub rsp, 0x30
000076cd267cedd8  movaps [rsp], xmm13
000076cd267ceddd  movaps [rsp+0x10], xmm15
000076cd267cede3  movaps [rsp+0x20], xmm14
000076cd267cede9  lea rdi, [rsp]
000076cd267ceded  mov esi, 0x00
000076cd267cedf2  mov rax, 0x56B8861A9530
000076cd267cedfc  call rax
000076cd267cedfe  movaps xmm13, [rsp]
000076cd267cee03  add rsp, 0x30
000076cd267cee07  vmovaps xmm0, [rsp]
000076cd267cee0c  vmovaps xmm1, [rsp+0x10]
000076cd267cee12  vmovaps xmm2, [rsp+0x20]
000076cd267cee18  vmovaps xmm3, [rsp+0x30]
000076cd267cee1e  vmovaps xmm4, [rsp+0x40]
000076cd267cee24  vmovaps xmm5, [rsp+0x50]
000076cd267cee2a  vmovaps xmm6, [rsp+0x60]
000076cd267cee30  vmovaps xmm7, [rsp+0x70]
000076cd267cee36  vmovaps xmm8, [rsp+0x80]
000076cd267cee3f  vmovaps xmm9, [rsp+0x90]
000076cd267cee48  vmovaps xmm10, [rsp+0xA0]
000076cd267cee51  vmovaps xmm11, [rsp+0xB0]
000076cd267cee5a  vmovaps xmm12, [rsp+0xC0]
000076cd267cee63  vmovaps xmm14, [rsp+0xD0]
000076cd267cee6c  vmovaps xmm15, [rsp+0xE0]
000076cd267cee75  add rsp, 0xF0
000076cd267cee7c  pop r11
000076cd267cee7e  pop r10
000076cd267cee80  pop r9
000076cd267cee82  pop r8
000076cd267cee84  pop rsi
000076cd267cee85  pop rdi
000076cd267cee86  pop rdx
000076cd267cee87  pop rcx
000076cd267cee88  pop rax
000076cd267cee89  add rsp, 0x08
000076cd267cee8d  jmp 0x000076CD267CEC71
000076cd267cee92  call 0x000076CD266C2240
000076cd267cee97  jmp 0x000076CD267CEC8B
000076cd267cee9c  sub rsp, 0x08
000076cd267ceea0  push rax
000076cd267ceea1  push rcx
000076cd267ceea2  push rdx
000076cd267ceea3  push rdi
000076cd267ceea4  push rsi
000076cd267ceea5  push r8
000076cd267ceea7  push r9
000076cd267ceea9  push r10
000076cd267ceeab  push r11
000076cd267ceead  sub rsp, 0xF0
000076cd267ceeb4  vmovaps [rsp], xmm0
000076cd267ceeb9  vmovaps [rsp+0x10], xmm1
000076cd267ceebf  vmovaps [rsp+0x20], xmm2
000076cd267ceec5  vmovaps [rsp+0x30], xmm3
000076cd267ceecb  vmovaps [rsp+0x40], xmm4
000076cd267ceed1  vmovaps [rsp+0x50], xmm5
000076cd267ceed7  vmovaps [rsp+0x60], xmm6
000076cd267ceedd  vmovaps [rsp+0x70], xmm7
000076cd267ceee3  vmovaps [rsp+0x80], xmm8
000076cd267ceeec  vmovaps [rsp+0x90], xmm9
000076cd267ceef5  vmovaps [rsp+0xA0], xmm10
000076cd267ceefe  vmovaps [rsp+0xB0], xmm11
000076cd267cef07  vmovaps [rsp+0xC0], xmm12
000076cd267cef10  vmovaps [rsp+0xD0], xmm13
000076cd267cef19  vmovaps [rsp+0xE0], xmm15
000076cd267cef22  sub rsp, 0x30
000076cd267cef26  movaps [rsp], xmm14
000076cd267cef2b  movaps [rsp+0x10], xmm1
000076cd267cef30  movaps [rsp+0x20], xmm15
000076cd267cef36  lea rdi, [rsp]
000076cd267cef3a  mov esi, 0x00
000076cd267cef3f  mov rax, 0x56B8861A9530
000076cd267cef49  call rax
000076cd267cef4b  movaps xmm14, [rsp]
000076cd267cef50  add rsp, 0x30
000076cd267cef54  vmovaps xmm0, [rsp]
000076cd267cef59  vmovaps xmm1, [rsp+0x10]
000076cd267cef5f  vmovaps xmm2, [rsp+0x20]
000076cd267cef65  vmovaps xmm3, [rsp+0x30]
000076cd267cef6b  vmovaps xmm4, [rsp+0x40]
000076cd267cef71  vmovaps xmm5, [rsp+0x50]
000076cd267cef77  vmovaps xmm6, [rsp+0x60]
000076cd267cef7d  vmovaps xmm7, [rsp+0x70]
000076cd267cef83  vmovaps xmm8, [rsp+0x80]
000076cd267cef8c  vmovaps xmm9, [rsp+0x90]
000076cd267cef95  vmovaps xmm10, [rsp+0xA0]
000076cd267cef9e  vmovaps xmm11, [rsp+0xB0]
000076cd267cefa7  vmovaps xmm12, [rsp+0xC0]
000076cd267cefb0  vmovaps xmm13, [rsp+0xD0]
000076cd267cefb9  vmovaps xmm15, [rsp+0xE0]
000076cd267cefc2  add rsp, 0xF0
000076cd267cefc9  pop r11
000076cd267cefcb  pop r10
000076cd267cefcd  pop r9
000076cd267cefcf  pop r8
000076cd267cefd1  pop rsi
000076cd267cefd2  pop rdi
000076cd267cefd3  pop rdx
000076cd267cefd4  pop rcx
000076cd267cefd5  pop rax
000076cd267cefd6  add rsp, 0x08
000076cd267cefda  jmp 0x000076CD267CECAE
000076cd267cefdf  call 0x000076CD266C34C0
000076cd267cefe4  jmp 0x000076CD267CECC4
000076cd267cefe9  int3
000076cd267cefea  nop [rax+rax*1], ax
000076cd267ceff0  mov rax, [r15+0xF8]
000076cd267ceff7  lea r14, [rax-0x150]
000076cd267ceffe  mov [r15+0xF8], r14
000076cd267cf005  mov rax, [r15+0x50]
000076cd267cf009  lea r12, [rax+0x80]
000076cd267cf010  movups xmm1, [r13+r12*1]
000076cd267cf016  lea r12, [rax+0x90]
000076cd267cf01d  movups xmm15, [r13+r12*1]
000076cd267cf023  mov qword ptr [r15+0x48], 0x00
000076cd267cf02b  lea r12, [rax+0x40]
000076cd267cf02f  movups xmm14, [r13+r12*1]
000076cd267cf035  lea r12, [rax+0x50]
000076cd267cf039  movups xmm13, [r13+r12*1]
000076cd267cf03f  lea r12, [r14+0x120]
000076cd267cf046  movq xmm12, qword ptr [r15+0x1C0]
000076cd267cf04f  movq xmm11, qword ptr [r15+0x1B0]
000076cd267cf058  movq r11, xmm12
000076cd267cf05d  movq r10, xmm11
000076cd267cf062  mov [r13+r12*1], r11
000076cd267cf067  lea r12, [r14+0x128]
000076cd267cf06e  mov [r13+r12*1], r10
000076cd267cf073  vxorps xmm12, xmm12, xmm12
000076cd267cf078  vpbroadcastq xmm12, xmm12
000076cd267cf07d  lea r12, [r14+0x100]
000076cd267cf084  movq xmm11, qword ptr [r15+0x200]
000076cd267cf08d  movq xmm10, qword ptr [r15+0x1F0]
000076cd267cf096  movq r11, xmm11
000076cd267cf09b  movq r10, xmm10
000076cd267cf0a0  mov [r13+r12*1], r11
000076cd267cf0a5  lea r12, [r14+0x108]
000076cd267cf0ac  mov [r13+r12*1], r10
000076cd267cf0b1  lea r12, [r14+0xE0]
000076cd267cf0b8  movups [r13+r12*1], xmm15
000076cd267cf0be  lea r12, [r14+0xF0]
000076cd267cf0c5  movups [r13+r12*1], xmm1
000076cd267cf0cb  lea r12, [rax+0xC0]
000076cd267cf0d2  movups xmm1, [r13+r12*1]
000076cd267cf0d8  lea r12, [rax+0xD0]
000076cd267cf0df  movups xmm15, [r13+r12*1]
000076cd267cf0e5  lea r12, [r14+0x110]
000076cd267cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000076cd267cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000076cd267cf0fe  movq r11, xmm11
000076cd267cf103  movq r10, xmm10
000076cd267cf108  mov [r13+r12*1], r11
000076cd267cf10d  lea r12, [r14+0x118]
000076cd267cf114  mov [r13+r12*1], r10
000076cd267cf119  movups xmm11, [r13+rax*1]
000076cd267cf11f  lea r12, [rax+0x10]
000076cd267cf123  movups xmm10, [r13+r12*1]
000076cd267cf129  lea r12, [r14+0x130]
000076cd267cf130  movq xmm9, qword ptr [r15+0x1A0]
000076cd267cf139  movq xmm8, qword ptr [r15+0x190]
000076cd267cf142  movq r11, xmm9
000076cd267cf147  movq r10, xmm8
000076cd267cf14c  mov [r13+r12*1], r11
000076cd267cf151  lea r12, [r14+0x138]
000076cd267cf158  mov [r13+r12*1], r10
000076cd267cf15d  lea r12, [rax+0x140]
000076cd267cf164  movups xmm9, [r13+r12*1]
000076cd267cf16a  lea r12, [rax+0x150]
000076cd267cf171  movups xmm8, [r13+r12*1]
000076cd267cf177  lea r12, [r14+0xC0]
000076cd267cf17e  movups [r13+r12*1], xmm15
000076cd267cf184  lea r12, [r14+0xD0]
000076cd267cf18b  movups [r13+r12*1], xmm1
000076cd267cf191  lea r12, [rax+0x100]
000076cd267cf198  movups xmm1, [r13+r12*1]
000076cd267cf19e  lea r12, [rax+0x110]
000076cd267cf1a5  movups xmm15, [r13+r12*1]
000076cd267cf1ab  lea r12, [r14+0x140]
000076cd267cf1b2  mov r11, [r15+0xE8]
000076cd267cf1b9  mov [r13+r12*1], r11
000076cd267cf1be  lea r12, [rax+0x180]
000076cd267cf1c5  movups xmm7, [r13+r12*1]
000076cd267cf1cb  lea r12, [rax+0x190]
000076cd267cf1d2  movups xmm6, [r13+r12*1]
000076cd267cf1d8  lea r12, [rax+0x1C0]
000076cd267cf1df  movups xmm5, [r13+r12*1]
000076cd267cf1e5  lea r12, [rax+0x1D0]
000076cd267cf1ec  movups xmm4, [r13+r12*1]
000076cd267cf1f2  lea r12, [r14+0x20]
000076cd267cf1f6  movups [r13+r12*1], xmm1
000076cd267cf1fc  lea r12, [r14+0x30]
000076cd267cf200  movups [r13+r12*1], xmm13
000076cd267cf206  lea r12, [rax+0x60]
000076cd267cf20a  movups xmm1, [r13+r12*1]
000076cd267cf210  lea r12, [rax+0x70]
000076cd267cf214  movups xmm13, [r13+r12*1]
000076cd267cf21a  lea r12, [rax+0x20]
000076cd267cf21e  movups xmm3, [r13+r12*1]
000076cd267cf224  lea r12, [rax+0x30]
000076cd267cf228  movups xmm2, [r13+r12*1]
000076cd267cf22e  movaps [r15+0x1F0], xmm2
000076cd267cf236  lea r12, [r14+0x60]
000076cd267cf23a  movups [r13+r12*1], xmm11
000076cd267cf240  lea r12, [r14+0x70]
000076cd267cf244  movups [r13+r12*1], xmm5
000076cd267cf24a  lea r12, [rax+0xE0]
000076cd267cf251  movups xmm11, [r13+r12*1]
000076cd267cf257  lea r12, [rax+0xF0]
000076cd267cf25e  movups xmm5, [r13+r12*1]
000076cd267cf264  lea r12, [r14+0xA0]
000076cd267cf26b  movups [r13+r12*1], xmm13
000076cd267cf271  lea r12, [r14+0xB0]
000076cd267cf278  movups [r13+r12*1], xmm1
000076cd267cf27e  lea r12, [rax+0xA0]
000076cd267cf285  movups xmm1, [r13+r12*1]
000076cd267cf28b  lea r12, [rax+0xB0]
000076cd267cf292  movups xmm13, [r13+r12*1]
000076cd267cf298  lea r12, [rax+0x120]
000076cd267cf29f  vmovaps [rsp+0x10], xmm1
000076cd267cf2a5  movups xmm1, [r13+r12*1]
000076cd267cf2ab  lea r12, [rax+0x130]
000076cd267cf2b2  vmovaps [rsp+0x20], xmm1
000076cd267cf2b8  movups xmm1, [r13+r12*1]
000076cd267cf2be  lea r12, [rax+0x160]
000076cd267cf2c5  vmovaps [rsp+0x30], xmm1
000076cd267cf2cb  movups xmm1, [r13+r12*1]
000076cd267cf2d1  lea r12, [rax+0x170]
000076cd267cf2d8  vmovaps [rsp+0x40], xmm1
000076cd267cf2de  movups xmm1, [r13+r12*1]
000076cd267cf2e4  movaps [r15+0x2B0], xmm1
000076cd267cf2ec  lea r12, [r14+0x80]
000076cd267cf2f3  movups [r13+r12*1], xmm13
000076cd267cf2f9  lea r12, [r14+0x90]
000076cd267cf300  vmovaps xmm13, [rsp+0x10]
000076cd267cf306  movups [r13+r12*1], xmm13
000076cd267cf30c  lea r12, [rax+0x1A0]
000076cd267cf313  movups xmm13, [r13+r12*1]
000076cd267cf319  lea r12, [rax+0x1B0]
000076cd267cf320  vmovaps [rsp+0x10], xmm1
000076cd267cf326  movups xmm1, [r13+r12*1]
000076cd267cf32c  movaps [r15+0x290], xmm13
000076cd267cf334  movaps [r15+0x1E0], xmm1
000076cd267cf33c  lea r12, [rax+0x1E0]
000076cd267cf343  vmovaps [rsp+0x50], xmm1
000076cd267cf349  movups xmm1, [r13+r12*1]
000076cd267cf34f  lea r12, [rax+0x1F0]
000076cd267cf356  vmovaps [rsp+0x60], xmm1
000076cd267cf35c  movups xmm1, [r13+r12*1]
000076cd267cf362  mov qword ptr [r15+0x50], 0x430920
000076cd267cf36a  lea rax, [r14+0x40]
000076cd267cf36e  vmovaps [rsp+0x70], xmm1
000076cd267cf374  vmovaps xmm1, [rsp+0x40]
000076cd267cf37a  movups [r13+rax*1], xmm1
000076cd267cf380  lea rax, [r14+0x50]
000076cd267cf384  movups [r13+rax*1], xmm10
000076cd267cf38a  vmovaps xmm1, [rsp+0x70]
000076cd267cf390  movups [r13+r14*1], xmm1
000076cd267cf396  lea rax, [r14+0x10]
000076cd267cf39a  vmovaps xmm1, [rsp+0x60]
000076cd267cf3a0  movups [r13+rax*1], xmm1
000076cd267cf3a6  mov rax, [r15+0x40]
000076cd267cf3aa  vmovaps [rsp+0x40], xmm3
000076cd267cf3b0  vmovaps xmm1, [rsp+0x40]
000076cd267cf3b6  por xmm3, xmm1
000076cd267cf3ba  vmovaps [rsp+0x40], xmm6
000076cd267cf3c0  vmovaps xmm10, [rsp+0x40]
000076cd267cf3c6  por xmm6, xmm10
000076cd267cf3cb  lea r12, [rax+0x30]
000076cd267cf3cf  mov r11, [r13+r12*1]
000076cd267cf3d4  lea r12, [rax+0x38]
000076cd267cf3d8  mov r10, [r13+r12*1]
000076cd267cf3dd  movq xmm10, r11
000076cd267cf3e2  vmovaps [rsp+0x40], xmm1
000076cd267cf3e8  movq xmm1, r10
000076cd267cf3ed  movq xmm10, xmm10
000076cd267cf3f2  vmovaps [rsp+0x60], xmm10
000076cd267cf3f8  movq xmm10, xmm10
000076cd267cf3fd  movaps [r15+0x130], xmm10
000076cd267cf405  movq xmm1, xmm1
000076cd267cf409  vmovaps [rsp+0x70], xmm1
000076cd267cf40f  movq xmm1, xmm1
000076cd267cf413  movaps [r15+0x280], xmm1
000076cd267cf41b  vmovaps [rsp+0x80], xmm9
000076cd267cf424  vmovaps xmm1, [rsp+0x80]
000076cd267cf42d  por xmm9, xmm1
000076cd267cf432  lea r12, [rax+0x20]
000076cd267cf436  mov r11, [r13+r12*1]
000076cd267cf43b  lea r12, [rax+0x28]
000076cd267cf43f  mov r10, [r13+r12*1]
000076cd267cf444  movq xmm1, r11
000076cd267cf449  movq xmm10, r10
000076cd267cf44e  movq xmm1, xmm1
000076cd267cf452  vmovaps [rsp+0x80], xmm1
000076cd267cf45b  movq xmm1, xmm1
000076cd267cf45f  movaps [r15+0x150], xmm1
000076cd267cf467  movq xmm10, xmm10
000076cd267cf46c  vmovaps [rsp+0x90], xmm10
000076cd267cf475  movq xmm10, xmm10
000076cd267cf47a  movaps [r15+0x140], xmm10
000076cd267cf482  lea r12, [rax+0x10]
000076cd267cf486  mov r11, [r13+r12*1]
000076cd267cf48b  lea r12, [rax+0x18]
000076cd267cf48f  mov r10, [r13+r12*1]
000076cd267cf494  movq xmm1, r11
000076cd267cf499  movq xmm10, r10
000076cd267cf49e  movq xmm1, xmm1
000076cd267cf4a2  vmovaps [rsp+0xA0], xmm1
000076cd267cf4ab  movq xmm1, xmm1
000076cd267cf4af  movaps [r15+0x170], xmm1
000076cd267cf4b7  movq xmm10, xmm10
000076cd267cf4bc  vmovaps [rsp+0xB0], xmm10
000076cd267cf4c5  movq xmm10, xmm10
000076cd267cf4ca  movaps [r15+0x160], xmm10
000076cd267cf4d2  mov r12, [r13+rax*1]
000076cd267cf4d7  vmovq xmm1, r12
000076cd267cf4dc  vpbroadcastq xmm1, xmm1
000076cd267cf4e1  lea r12, [rax+0x08]
000076cd267cf4e5  mov rax, [r13+r12*1]
000076cd267cf4ea  movq xmm10, rax
000076cd267cf4ef  movaps [r15+0x230], xmm10
000076cd267cf4f7  lea rax, [r14+0x50]
000076cd267cf4fb  movups xmm10, [r13+rax*1]
000076cd267cf501  lea rax, [r14+0x60]
000076cd267cf505  vmovaps [rsp+0xC0], xmm1
000076cd267cf50e  movups xmm1, [r13+rax*1]
000076cd267cf514  lea rax, [r14+0x30]
000076cd267cf518  vmovaps [rsp+0xD0], xmm1
000076cd267cf521  movups xmm1, [r13+rax*1]
000076cd267cf527  mov qword ptr [r15+0x60], 0x430920
000076cd267cf52f  mov qword ptr [r15+0x58], 0x40
000076cd267cf537  vmovaps [rsp+0xE0], xmm1
000076cd267cf540  vmovaps [rsp+0xF0], xmm15
000076cd267cf549  vmovaps xmm15, [rsp+0xC0]
000076cd267cf552  vmovaps [rsp+0xC0], xmm14
000076cd267cf55b  vmovaps xmm14, [rsp+0x40]
000076cd267cf561  vmovaps [rsp+0x40], xmm13
000076cd267cf567  movaps xmm1, xmm15
000076cd267cf56b  mulpd xmm1, xmm14
000076cd267cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000076cd267cf575  ptest xmm13, xmm13
000076cd267cf57b  jnz 0x000076CD267D0682
000076cd267cf581  movq xmm14, qword ptr [r15+0x230]
000076cd267cf58a  vmovaps [rsp+0x100], xmm14
000076cd267cf593  vpermilpd xmm14, xmm14, 0x00
000076cd267cf599  vmovaps [rsp+0x110], xmm1
000076cd267cf5a2  vmovaps xmm1, [rsp+0xE0]
000076cd267cf5ab  vmovaps [rsp+0xE0], xmm15
000076cd267cf5b4  movaps xmm13, xmm1
000076cd267cf5b8  mulpd xmm13, xmm14
000076cd267cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000076cd267cf5c3  ptest xmm15, xmm15
000076cd267cf5c9  jnz 0x000076CD267D07C4
000076cd267cf5cf  vxorps xmm1, xmm1, xmm1
000076cd267cf5d3  vpbroadcastq xmm1, xmm1
000076cd267cf5d8  vmovaps xmm14, [rsp+0xE0]
000076cd267cf5e1  vmovaps [rsp+0xE0], xmm1
000076cd267cf5ea  vmovaps xmm1, [rsp+0xD0]
000076cd267cf5f3  vmovaps [rsp+0xD0], xmm13
000076cd267cf5fc  movaps xmm15, xmm14
000076cd267cf600  mulpd xmm15, xmm1
000076cd267cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000076cd267cf60b  ptest xmm13, xmm13
000076cd267cf611  jnz 0x000076CD267D0907
000076cd267cf617  movaps xmm1, xmm14
000076cd267cf61b  mulpd xmm1, xmm10
000076cd267cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000076cd267cf625  ptest xmm13, xmm13
000076cd267cf62b  jnz 0x000076CD267D0A4A
000076cd267cf631  movaps xmm13, xmm14
000076cd267cf635  mulpd xmm13, xmm2
000076cd267cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000076cd267cf640  ptest xmm10, xmm10
000076cd267cf646  jnz 0x000076CD267D0B8C
000076cd267cf64c  vmovaps [rsp+0x120], xmm7
000076cd267cf655  vmovaps xmm14, [rsp+0x120]
000076cd267cf65e  por xmm7, xmm14
000076cd267cf663  vmovaps xmm14, [rsp+0xC0]
000076cd267cf66c  vmovaps xmm10, [rsp+0xC0]
000076cd267cf675  por xmm14, xmm10
000076cd267cf67a  vmovaps xmm2, [rsp+0x100]
000076cd267cf683  vpermilpd xmm2, xmm2, 0x00
000076cd267cf689  vmovaps [rsp+0xC0], xmm1
000076cd267cf692  vmovaps [rsp+0x120], xmm15
000076cd267cf69b  movaps xmm1, xmm10
000076cd267cf69f  mulpd xmm1, xmm2
000076cd267cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000076cd267cf6a8  ptest xmm15, xmm15
000076cd267cf6ae  jnz 0x000076CD267D0CCF
000076cd267cf6b4  xor eax, eax
000076cd267cf6b6  mov r12d, 0x40
000076cd267cf6bc  mov r11d, 0x200
000076cd267cf6c2  cmp r12, r11
000076cd267cf6c5  cmc
000076cd267cf6c6  lahf
000076cd267cf6c7  seto al
000076cd267cf6ca  mov [r15+0x108], eax
000076cd267cf6d1  vmovaps xmm10, [rsp+0x110]
000076cd267cf6da  vmovaps xmm2, [rsp+0xE0]
000076cd267cf6e3  vmovaps [rsp+0xE0], xmm1
000076cd267cf6ec  movaps xmm15, xmm10
000076cd267cf6f0  addpd xmm15, xmm2
000076cd267cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267cf6fb  ptest xmm1, xmm1
000076cd267cf700  jnz 0x000076CD267D0E10
000076cd267cf706  vmovaps xmm10, [rsp+0x120]
000076cd267cf70f  vmovaps [rsp+0x110], xmm15
000076cd267cf718  movaps xmm1, xmm10
000076cd267cf71c  addpd xmm1, xmm12
000076cd267cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000076cd267cf726  ptest xmm15, xmm15
000076cd267cf72c  jnz 0x000076CD267D0F53
000076cd267cf732  vmovaps xmm10, [rsp+0xC0]
000076cd267cf73b  vmovaps [rsp+0xC0], xmm1
000076cd267cf744  movaps xmm15, xmm10
000076cd267cf748  addpd xmm15, xmm12
000076cd267cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267cf753  ptest xmm1, xmm1
000076cd267cf758  jnz 0x000076CD267D1095
000076cd267cf75e  vmovaps xmm1, [rsp+0x30]
000076cd267cf764  vmovaps xmm12, [rsp+0x30]
000076cd267cf76a  por xmm1, xmm12
000076cd267cf76f  vmovaps xmm12, [rsp+0x20]
000076cd267cf775  vmovaps xmm10, [rsp+0x20]
000076cd267cf77b  por xmm12, xmm10
000076cd267cf780  vmovaps [rsp+0x20], xmm5
000076cd267cf786  vmovaps xmm10, [rsp+0x20]
000076cd267cf78c  por xmm5, xmm10
000076cd267cf791  vmovaps [rsp+0x20], xmm11
000076cd267cf797  vmovaps xmm10, [rsp+0x20]
000076cd267cf79d  por xmm11, xmm10
000076cd267cf7a2  vmovaps [rsp+0x20], xmm4
000076cd267cf7a8  vmovaps xmm10, [rsp+0x20]
000076cd267cf7ae  por xmm4, xmm10
000076cd267cf7b3  vmovaps [rsp+0x20], xmm8
000076cd267cf7b9  vmovaps xmm10, [rsp+0x20]
000076cd267cf7bf  por xmm8, xmm10
000076cd267cf7c4  vmovaps xmm10, [rsp+0xF0]
000076cd267cf7cd  vmovaps [rsp+0x20], xmm1
000076cd267cf7d3  vmovaps xmm1, [rsp+0xF0]
000076cd267cf7dc  por xmm10, xmm1
000076cd267cf7e1  lea rax, [r14+0xA0]
000076cd267cf7e8  movups xmm1, [r13+rax*1]
000076cd267cf7ee  lea rax, [r14+0xB0]
000076cd267cf7f5  vmovaps [rsp+0x30], xmm1
000076cd267cf7fb  movups xmm1, [r13+rax*1]
000076cd267cf801  vmovaps [rsp+0xF0], xmm1
000076cd267cf80a  vmovaps [rsp+0x120], xmm15
000076cd267cf813  movaps xmm1, xmm13
000076cd267cf817  addpd xmm1, xmm2
000076cd267cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000076cd267cf820  ptest xmm15, xmm15
000076cd267cf826  jnz 0x000076CD267D11ED
000076cd267cf82c  lea rax, [r14+0xF0]
000076cd267cf833  movups xmm15, [r13+rax*1]
000076cd267cf839  vmovaps xmm2, [rsp+0xC0]
000076cd267cf842  vmovaps [rsp+0xC0], xmm1
000076cd267cf84b  vmovaps xmm1, [rsp+0xE0]
000076cd267cf854  vmovaps [rsp+0xE0], xmm15
000076cd267cf85d  movaps xmm13, xmm2
000076cd267cf861  addpd xmm13, xmm1
000076cd267cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000076cd267cf86c  ptest xmm15, xmm15
000076cd267cf872  jnz 0x000076CD267D1338
000076cd267cf878  vmovaps xmm15, [rsp+0x120]
000076cd267cf881  vmovaps xmm2, [rsp+0xD0]
000076cd267cf88a  vmovaps [rsp+0xD0], xmm14
000076cd267cf893  movaps xmm1, xmm15
000076cd267cf897  addpd xmm1, xmm2
000076cd267cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000076cd267cf8a0  ptest xmm14, xmm14
000076cd267cf8a6  jnz 0x000076CD267D147A
000076cd267cf8ac  vmovaps xmm15, [rsp+0x100]
000076cd267cf8b5  vpermilpd xmm15, xmm15, 0x00
000076cd267cf8bb  vmovaps xmm2, [rsp+0xF0]
000076cd267cf8c4  vmovaps [rsp+0xF0], xmm1
000076cd267cf8cd  movaps xmm14, xmm2
000076cd267cf8d1  mulpd xmm14, xmm15
000076cd267cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000076cd267cf8dc  ptest xmm1, xmm1
000076cd267cf8e1  jnz 0x000076CD267D15BB
000076cd267cf8e7  vmovaps xmm1, [rsp+0xA0]
000076cd267cf8f0  vpermilpd xmm1, xmm1, 0x00
000076cd267cf8f6  vmovaps xmm2, [rsp+0xE0]
000076cd267cf8ff  vmovaps [rsp+0xE0], xmm14
000076cd267cf908  movaps xmm15, xmm2
000076cd267cf90c  mulpd xmm15, xmm1
000076cd267cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000076cd267cf917  ptest xmm14, xmm14
000076cd267cf91d  jnz 0x000076CD267D16FE
000076cd267cf923  lea rax, [r14+0xE0]
000076cd267cf92a  movups xmm1, [r13+rax*1]
000076cd267cf930  vmovaps xmm14, [rsp+0x100]
000076cd267cf939  vpermilpd xmm14, xmm14, 0x00
000076cd267cf93f  vmovaps [rsp+0x100], xmm1
000076cd267cf948  vmovaps xmm1, [rsp+0x30]
000076cd267cf94e  vmovaps [rsp+0x30], xmm15
000076cd267cf954  movaps xmm2, xmm1
000076cd267cf957  mulpd xmm2, xmm14
000076cd267cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000076cd267cf961  ptest xmm15, xmm15
000076cd267cf967  jnz 0x000076CD267D184A
000076cd267cf96d  vmovaps [rsp+0x120], xmm10
000076cd267cf976  vmovaps xmm1, [rsp+0x120]
000076cd267cf97f  por xmm10, xmm1
000076cd267cf984  movaps [r15+0x300], xmm10
000076cd267cf98c  vmovaps [rsp+0x120], xmm8
000076cd267cf995  vmovaps xmm1, [rsp+0x120]
000076cd267cf99e  por xmm8, xmm1
000076cd267cf9a3  movaps [r15+0x190], xmm8
000076cd267cf9ab  vmovaps xmm1, [rsp+0xA0]
000076cd267cf9b4  vpermilpd xmm1, xmm1, 0x00
000076cd267cf9ba  vmovaps xmm14, [rsp+0x100]
000076cd267cf9c3  vmovaps [rsp+0x100], xmm13
000076cd267cf9cc  movaps xmm15, xmm14
000076cd267cf9d0  mulpd xmm15, xmm1
000076cd267cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000076cd267cf9db  ptest xmm13, xmm13
000076cd267cf9e1  jnz 0x000076CD267D198B
000076cd267cf9e7  lea rax, [r14+0x90]
000076cd267cf9ee  movups xmm1, [r13+rax*1]
000076cd267cf9f4  vmovaps [rsp+0x120], xmm4
000076cd267cf9fd  vmovaps xmm14, [rsp+0x120]
000076cd267cfa06  por xmm4, xmm14
000076cd267cfa0b  movaps [r15+0x1C0], xmm4
000076cd267cfa13  vmovaps [rsp+0x120], xmm11
000076cd267cfa1c  vmovaps xmm14, [rsp+0x120]
000076cd267cfa25  por xmm11, xmm14
000076cd267cfa2a  movaps [r15+0x200], xmm11
000076cd267cfa32  vmovaps [rsp+0x120], xmm5
000076cd267cfa3b  vmovaps xmm14, [rsp+0x120]
000076cd267cfa44  por xmm5, xmm14
000076cd267cfa49  movaps [r15+0x2D0], xmm5
000076cd267cfa51  vmovaps [rsp+0x120], xmm12
000076cd267cfa5a  vmovaps xmm14, [rsp+0x120]
000076cd267cfa63  por xmm12, xmm14
000076cd267cfa68  movaps [r15+0x2E0], xmm12
000076cd267cfa70  vmovaps xmm13, [rsp+0x110]
000076cd267cfa79  vmovaps [rsp+0x110], xmm1
000076cd267cfa82  vmovaps xmm1, [rsp+0xE0]
000076cd267cfa8b  vmovaps [rsp+0xE0], xmm15
000076cd267cfa94  movaps xmm14, xmm13
000076cd267cfa98  addpd xmm14, xmm1
000076cd267cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000076cd267cfaa3  ptest xmm15, xmm15
000076cd267cfaa9  jnz 0x000076CD267D1AD8
000076cd267cfaaf  vmovaps xmm1, [rsp+0xA0]
000076cd267cfab8  vpermilpd xmm1, xmm1, 0x00
000076cd267cfabe  vmovaps xmm13, [rsp+0x110]
000076cd267cfac7  vmovaps [rsp+0x110], xmm14
000076cd267cfad0  movaps xmm15, xmm13
000076cd267cfad4  mulpd xmm15, xmm1
000076cd267cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000076cd267cfadf  ptest xmm14, xmm14
000076cd267cfae5  jnz 0x000076CD267D1C1B
000076cd267cfaeb  lea rax, [r14+0x80]
000076cd267cfaf2  movups xmm1, [r13+rax*1]
000076cd267cfaf8  vmovaps xmm13, [rsp+0xC0]
000076cd267cfb01  vmovaps [rsp+0xC0], xmm1
000076cd267cfb0a  movaps xmm14, xmm13
000076cd267cfb0e  addpd xmm14, xmm2
000076cd267cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000076cd267cfb19  ptest xmm1, xmm1
000076cd267cfb1e  jnz 0x000076CD267D1D68
000076cd267cfb24  vmovaps xmm13, [rsp+0x100]
000076cd267cfb2d  vmovaps xmm2, [rsp+0x30]
000076cd267cfb33  vmovaps [rsp+0x30], xmm15
000076cd267cfb39  movaps xmm1, xmm13
000076cd267cfb3d  addpd xmm1, xmm2
000076cd267cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000076cd267cfb46  ptest xmm15, xmm15
000076cd267cfb4c  jnz 0x000076CD267D1EAB
000076cd267cfb52  vmovaps xmm15, [rsp+0x20]
000076cd267cfb58  vmovaps xmm13, [rsp+0x20]
000076cd267cfb5e  por xmm15, xmm13
000076cd267cfb63  movaps [r15+0x2F0], xmm15
000076cd267cfb6b  vmovaps xmm13, [rsp+0xA0]
000076cd267cfb74  vpermilpd xmm13, xmm13, 0x00
000076cd267cfb7a  vmovaps [rsp+0x20], xmm1
000076cd267cfb80  vmovaps xmm1, [rsp+0xC0]
000076cd267cfb89  vmovaps [rsp+0xA0], xmm15
000076cd267cfb92  movaps xmm2, xmm1
000076cd267cfb95  mulpd xmm2, xmm13
000076cd267cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000076cd267cfb9f  ptest xmm15, xmm15
000076cd267cfba5  jnz 0x000076CD267D1FEC
000076cd267cfbab  lea rax, [r14+0xD0]
000076cd267cfbb2  movups xmm1, [r13+rax*1]
000076cd267cfbb8  vmovaps xmm13, [rsp+0xF0]
000076cd267cfbc1  vmovaps [rsp+0xC0], xmm1
000076cd267cfbca  vmovaps xmm1, [rsp+0xE0]
000076cd267cfbd3  vmovaps [rsp+0xE0], xmm14
000076cd267cfbdc  movaps xmm15, xmm13
000076cd267cfbe0  addpd xmm15, xmm1
000076cd267cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000076cd267cfbeb  ptest xmm14, xmm14
000076cd267cfbf1  jnz 0x000076CD267D2137
000076cd267cfbf7  vmovaps xmm1, [rsp+0xB0]
000076cd267cfc00  vpermilpd xmm1, xmm1, 0x00
000076cd267cfc06  movaps xmm14, xmm11
000076cd267cfc0a  mulpd xmm14, xmm1
000076cd267cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000076cd267cfc15  ptest xmm13, xmm13
000076cd267cfc1b  jnz 0x000076CD267D227A
000076cd267cfc21  movaps [r15+0x260], xmm14
000076cd267cfc29  vxorps xmm1, xmm1, xmm1
000076cd267cfc2d  vpbroadcastq xmm1, xmm1
000076cd267cfc32  movaps [r15+0x1B0], xmm1
000076cd267cfc3a  vmovaps xmm1, [rsp+0xB0]
000076cd267cfc43  vpermilpd xmm1, xmm1, 0x00
000076cd267cfc49  vmovaps xmm11, [rsp+0xC0]
000076cd267cfc52  vmovaps [rsp+0xC0], xmm15
000076cd267cfc5b  movaps xmm13, xmm11
000076cd267cfc5f  mulpd xmm13, xmm1
000076cd267cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000076cd267cfc6a  ptest xmm15, xmm15
000076cd267cfc70  jnz 0x000076CD267D23BD
000076cd267cfc76  lea rax, [r14+0xC0]
000076cd267cfc7d  movups xmm1, [r13+rax*1]
000076cd267cfc83  vmovaps xmm11, [rsp+0x110]
000076cd267cfc8c  vmovaps [rsp+0xF0], xmm1
000076cd267cfc95  vmovaps xmm1, [rsp+0x30]
000076cd267cfc9b  vmovaps [rsp+0x30], xmm14
000076cd267cfca1  movaps xmm15, xmm11
000076cd267cfca5  addpd xmm15, xmm1
000076cd267cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000076cd267cfcb0  ptest xmm14, xmm14
000076cd267cfcb6  jnz 0x000076CD267D250A
000076cd267cfcbc  vmovaps [rsp+0x100], xmm9
000076cd267cfcc5  vmovaps xmm1, [rsp+0x100]
000076cd267cfcce  por xmm9, xmm1
000076cd267cfcd3  movaps [r15+0x270], xmm9
000076cd267cfcdb  vmovaps [rsp+0x100], xmm6
000076cd267cfce4  vmovaps xmm1, [rsp+0x100]
000076cd267cfced  por xmm6, xmm1
000076cd267cfcf1  movaps [r15+0x1A0], xmm6
000076cd267cfcf9  vmovaps xmm14, [rsp+0xB0]
000076cd267cfd02  vpermilpd xmm14, xmm14, 0x00
000076cd267cfd08  vmovaps xmm6, [rsp+0xF0]
000076cd267cfd11  vmovaps [rsp+0xF0], xmm1
000076cd267cfd1a  movaps xmm11, xmm6
000076cd267cfd1e  mulpd xmm11, xmm14
000076cd267cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000076cd267cfd29  ptest xmm1, xmm1
000076cd267cfd2e  jnz 0x000076CD267D264D
000076cd267cfd34  lea rax, [r14+0x20]
000076cd267cfd38  movups xmm1, [r13+rax*1]
000076cd267cfd3e  movaps [r15+0x110], xmm1
000076cd267cfd46  vmovaps xmm6, [rsp+0xE0]
000076cd267cfd4f  vmovaps [rsp+0xE0], xmm1
000076cd267cfd58  movaps xmm14, xmm6
000076cd267cfd5c  addpd xmm14, xmm2
000076cd267cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000076cd267cfd67  ptest xmm1, xmm1
000076cd267cfd6c  jnz 0x000076CD267D279A
000076cd267cfd72  vmovaps xmm1, [rsp+0xB0]
000076cd267cfd7b  vpermilpd xmm1, xmm1, 0x00
000076cd267cfd81  movaps xmm6, xmm5
000076cd267cfd84  mulpd xmm6, xmm1
000076cd267cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000076cd267cfd8d  ptest xmm2, xmm2
000076cd267cfd92  jnz 0x000076CD267D28DC
000076cd267cfd98  vmovaps xmm5, [rsp+0x20]
000076cd267cfd9e  movaps xmm1, xmm5
000076cd267cfda1  addpd xmm1, xmm13
000076cd267cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000076cd267cfdab  ptest xmm2, xmm2
000076cd267cfdb0  jnz 0x000076CD267D2A1C
000076cd267cfdb6  vmovaps xmm13, [rsp+0x80]
000076cd267cfdbf  vpermilpd xmm13, xmm13, 0x00
000076cd267cfdc5  vmovaps xmm2, [rsp+0xE0]
000076cd267cfdce  vmovaps [rsp+0x20], xmm1
000076cd267cfdd4  movaps xmm5, xmm2
000076cd267cfdd7  mulpd xmm5, xmm13
000076cd267cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000076cd267cfde1  ptest xmm1, xmm1
000076cd267cfde6  jnz 0x000076CD267D2B5D
000076cd267cfdec  vmovaps xmm1, [rsp+0x80]
000076cd267cfdf5  vpermilpd xmm1, xmm1, 0x00
000076cd267cfdfb  movaps xmm13, xmm10
000076cd267cfdff  mulpd xmm13, xmm1
000076cd267cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000076cd267cfe0a  ptest xmm2, xmm2
000076cd267cfe0f  jnz 0x000076CD267D2C9E
000076cd267cfe15  vmovaps xmm10, [rsp+0x30]
000076cd267cfe1b  movaps xmm1, xmm15
000076cd267cfe1f  addpd xmm1, xmm10
000076cd267cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000076cd267cfe29  ptest xmm2, xmm2
000076cd267cfe2e  jnz 0x000076CD267D2DE1
000076cd267cfe34  vmovaps xmm10, [rsp+0xC0]
000076cd267cfe3d  movaps xmm15, xmm10
000076cd267cfe41  addpd xmm15, xmm11
000076cd267cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000076cd267cfe4c  ptest xmm2, xmm2
000076cd267cfe51  jnz 0x000076CD267D2F23
000076cd267cfe57  vmovaps xmm11, [rsp+0x80]
000076cd267cfe60  vpermilpd xmm11, xmm11, 0x00
000076cd267cfe66  movaps xmm10, xmm12
000076cd267cfe6a  mulpd xmm10, xmm11
000076cd267cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000076cd267cfe75  ptest xmm2, xmm2
000076cd267cfe7a  jnz 0x000076CD267D3067
000076cd267cfe80  vmovaps xmm12, [rsp+0x80]
000076cd267cfe89  vpermilpd xmm12, xmm12, 0x00
000076cd267cfe8f  vmovaps xmm2, [rsp+0xA0]
000076cd267cfe98  vmovaps [rsp+0x30], xmm1
000076cd267cfe9e  movaps xmm11, xmm2
000076cd267cfea2  mulpd xmm11, xmm12
000076cd267cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000076cd267cfead  ptest xmm1, xmm1
000076cd267cfeb2  jnz 0x000076CD267D31AB
000076cd267cfeb8  movaps xmm1, xmm14
000076cd267cfebc  addpd xmm1, xmm6
000076cd267cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000076cd267cfec5  ptest xmm12, xmm12
000076cd267cfecb  jnz 0x000076CD267D32EE
000076cd267cfed1  vmovaps xmm12, [rsp+0x20]
000076cd267cfed7  movaps xmm14, xmm12
000076cd267cfedb  addpd xmm14, xmm5
000076cd267cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000076cd267cfee6  ptest xmm6, xmm6
000076cd267cfeeb  jnz 0x000076CD267D342F
000076cd267cfef1  vmovaps xmm12, [rsp+0x90]
000076cd267cfefa  vpermilpd xmm12, xmm12, 0x00
000076cd267cff00  movaps xmm6, xmm9
000076cd267cff04  mulpd xmm6, xmm12
000076cd267cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000076cd267cff0e  ptest xmm5, xmm5
000076cd267cff13  jnz 0x000076CD267D3572
000076cd267cff19  movaps xmm12, xmm15
000076cd267cff1d  addpd xmm12, xmm13
000076cd267cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000076cd267cff28  ptest xmm9, xmm9
000076cd267cff2e  jnz 0x000076CD267D36B4
000076cd267cff34  vmovaps xmm13, [rsp+0x30]
000076cd267cff3a  movaps xmm15, xmm13
000076cd267cff3e  addpd xmm15, xmm10
000076cd267cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000076cd267cff49  ptest xmm9, xmm9
000076cd267cff4f  jnz 0x000076CD267D37F8
000076cd267cff55  vmovaps xmm13, [rsp+0xD0]
000076cd267cff5e  vmovaps xmm10, [rsp+0xD0]
000076cd267cff67  por xmm13, xmm10
000076cd267cff6c  movaps [r15+0x250], xmm13
000076cd267cff74  vmovaps [rsp+0x20], xmm7
000076cd267cff7a  vmovaps xmm13, [rsp+0x20]
000076cd267cff80  por xmm7, xmm13
000076cd267cff85  movaps [r15+0x2A0], xmm7
000076cd267cff8d  vmovaps [rsp+0x20], xmm3
000076cd267cff93  vmovaps xmm13, [rsp+0x20]
000076cd267cff99  por xmm3, xmm13
000076cd267cff9e  movaps [r15+0x1D0], xmm3
000076cd267cffa6  lea rax, [r14+0x40]
000076cd267cffaa  movups xmm13, [r13+rax*1]
000076cd267cffb0  movaps [r15+0x2C0], xmm13
000076cd267cffb8  vmovaps xmm10, [rsp+0x90]
000076cd267cffc1  vpermilpd xmm10, xmm10, 0x00
000076cd267cffc7  movaps xmm9, xmm8
000076cd267cffcb  mulpd xmm9, xmm10
000076cd267cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000076cd267cffd6  ptest xmm5, xmm5
000076cd267cffdb  jnz 0x000076CD267D3946
000076cd267cffe1  movaps xmm10, xmm1
000076cd267cffe5  addpd xmm10, xmm11
000076cd267cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000076cd267cfff0  ptest xmm8, xmm8
000076cd267cfff6  jnz 0x000076CD267D3A8A
000076cd267cfffc  movaps xmm1, xmm14
000076cd267d0000  addpd xmm1, xmm6
000076cd267d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000076cd267d0009  ptest xmm11, xmm11
000076cd267d000f  jnz 0x000076CD267D3BCD
000076cd267d0015  vmovaps xmm14, [rsp+0x90]
000076cd267d001e  vpermilpd xmm14, xmm14, 0x00
000076cd267d0024  movaps xmm11, xmm13
000076cd267d0028  mulpd xmm11, xmm14
000076cd267d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000076cd267d0033  ptest xmm8, xmm8
000076cd267d0039  jnz 0x000076CD267D3D0E
000076cd267d003f  vmovaps xmm14, [rsp+0x90]
000076cd267d0048  vpermilpd xmm14, xmm14, 0x00
000076cd267d004e  vmovaps xmm8, [rsp+0x10]
000076cd267d0054  movaps xmm13, xmm8
000076cd267d0058  mulpd xmm13, xmm14
000076cd267d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000076cd267d0063  ptest xmm6, xmm6
000076cd267d0068  jnz 0x000076CD267D3E52
000076cd267d006e  vmovaps xmm14, [rsp+0x60]
000076cd267d0074  vpermilpd xmm14, xmm14, 0x00
000076cd267d007a  movaps xmm8, xmm7
000076cd267d007e  mulpd xmm8, xmm14
000076cd267d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000076cd267d0089  ptest xmm6, xmm6
000076cd267d008e  jnz 0x000076CD267D3F96
000076cd267d0094  movaps xmm14, xmm12
000076cd267d0098  addpd xmm14, xmm9
000076cd267d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000076cd267d00a3  ptest xmm7, xmm7
000076cd267d00a8  jnz 0x000076CD267D40D9
000076cd267d00ae  vmovaps xmm12, [rsp+0x60]
000076cd267d00b4  vpermilpd xmm12, xmm12, 0x00
000076cd267d00ba  vmovaps xmm7, [rsp+0xF0]
000076cd267d00c3  movaps xmm9, xmm7
000076cd267d00c7  mulpd xmm9, xmm12
000076cd267d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000076cd267d00d2  ptest xmm6, xmm6
000076cd267d00d7  jnz 0x000076CD267D421D
000076cd267d00dd  movaps xmm12, xmm15
000076cd267d00e1  addpd xmm12, xmm11
000076cd267d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000076cd267d00ec  ptest xmm7, xmm7
000076cd267d00f1  jnz 0x000076CD267D4360
000076cd267d00f7  vmovaps xmm15, [rsp+0x60]
000076cd267d00fd  vpermilpd xmm15, xmm15, 0x00
000076cd267d0103  vmovaps xmm7, [rsp+0x40]
000076cd267d0109  movaps xmm11, xmm7
000076cd267d010d  mulpd xmm11, xmm15
000076cd267d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000076cd267d0118  ptest xmm6, xmm6
000076cd267d011d  jnz 0x000076CD267D44A4
000076cd267d0123  movaps xmm15, xmm10
000076cd267d0127  addpd xmm15, xmm13
000076cd267d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000076cd267d0132  ptest xmm7, xmm7
000076cd267d0137  jnz 0x000076CD267D45E7
000076cd267d013d  vmovaps xmm13, [rsp+0x60]
000076cd267d0143  vpermilpd xmm13, xmm13, 0x00
000076cd267d0149  vmovaps xmm7, [rsp+0x50]
000076cd267d014f  movaps xmm10, xmm7
000076cd267d0153  mulpd xmm10, xmm13
000076cd267d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000076cd267d015e  ptest xmm6, xmm6
000076cd267d0163  jnz 0x000076CD267D472B
000076cd267d0169  movaps xmm13, xmm1
000076cd267d016d  addpd xmm13, xmm8
000076cd267d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000076cd267d0178  ptest xmm7, xmm7
000076cd267d017d  jnz 0x000076CD267D486E
000076cd267d0183  lea rax, [r14+0x70]
000076cd267d0187  movups xmm1, [r13+rax*1]
000076cd267d018d  movaps [r15+0x240], xmm1
000076cd267d0195  movaps xmm8, xmm14
000076cd267d0199  addpd xmm8, xmm9
000076cd267d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000076cd267d01a4  ptest xmm7, xmm7
000076cd267d01a9  jnz 0x000076CD267D49BB
000076cd267d01af  movaps [r15+0x170], xmm8
000076cd267d01b7  vmovaps xmm14, [rsp+0x70]
000076cd267d01bd  vpermilpd xmm14, xmm14, 0x00
000076cd267d01c3  movaps xmm9, xmm1
000076cd267d01c7  mulpd xmm9, xmm14
000076cd267d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000076cd267d01d2  ptest xmm7, xmm7
000076cd267d01d7  jnz 0x000076CD267D4AFF
000076cd267d01dd  vmovaps xmm1, [rsp+0x70]
000076cd267d01e3  vpermilpd xmm1, xmm1, 0x00
000076cd267d01e9  movaps xmm14, xmm4
000076cd267d01ed  mulpd xmm14, xmm1
000076cd267d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000076cd267d01f8  ptest xmm7, xmm7
000076cd267d01fd  jnz 0x000076CD267D4C42
000076cd267d0203  movaps [r15+0x180], xmm14
000076cd267d020b  movaps xmm1, xmm12
000076cd267d020f  addpd xmm1, xmm11
000076cd267d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000076cd267d0219  ptest xmm7, xmm7
000076cd267d021e  jnz 0x000076CD267D4D84
000076cd267d0224  movaps [r15+0x210], xmm1
000076cd267d022c  movups xmm12, [r13+r14*1]
000076cd267d0232  lea rax, [r14+0x10]
000076cd267d0236  movups xmm11, [r13+rax*1]
000076cd267d023c  movaps [r15+0x230], xmm11
000076cd267d0244  movaps xmm7, xmm15
000076cd267d0248  addpd xmm7, xmm10
000076cd267d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000076cd267d0252  ptest xmm6, xmm6
000076cd267d0257  jnz 0x000076CD267D4EDA
000076cd267d025d  movaps [r15+0x130], xmm7
000076cd267d0265  vmovaps xmm15, [rsp+0x70]
000076cd267d026b  vpermilpd xmm15, xmm15, 0x00
000076cd267d0271  movaps xmm10, xmm11
000076cd267d0275  mulpd xmm10, xmm15
000076cd267d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000076cd267d0280  ptest xmm6, xmm6
000076cd267d0285  jnz 0x000076CD267D501C
000076cd267d028b  movaps [r15+0x220], xmm10
000076cd267d0293  vmovaps xmm15, [rsp+0x70]
000076cd267d0299  vpermilpd xmm15, xmm15, 0x00
000076cd267d029f  movaps xmm11, xmm12
000076cd267d02a3  mulpd xmm11, xmm15
000076cd267d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000076cd267d02ae  ptest xmm6, xmm6
000076cd267d02b3  jnz 0x000076CD267D5160
000076cd267d02b9  movaps xmm15, xmm13
000076cd267d02bd  addpd xmm15, xmm9
000076cd267d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000076cd267d02c8  ptest xmm12, xmm12
000076cd267d02ce  jnz 0x000076CD267D52A4
000076cd267d02d4  movaps [r15+0x140], xmm15
000076cd267d02dc  movaps xmm13, xmm8
000076cd267d02e0  addpd xmm13, xmm14
000076cd267d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000076cd267d02eb  ptest xmm12, xmm12
000076cd267d02f1  jnz 0x000076CD267D53E8
000076cd267d02f7  movaps [r15+0x150], xmm13
000076cd267d02ff  movaps xmm14, xmm1
000076cd267d0303  addpd xmm14, xmm10
000076cd267d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000076cd267d030e  ptest xmm12, xmm12
000076cd267d0314  jnz 0x000076CD267D552C
000076cd267d031a  movaps [r15+0x160], xmm14
000076cd267d0322  movaps xmm1, xmm7
000076cd267d0325  addpd xmm1, xmm11
000076cd267d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000076cd267d032f  ptest xmm12, xmm12
000076cd267d0335  jnz 0x000076CD267D566F
000076cd267d033b  movaps [r15+0x120], xmm1
000076cd267d0343  mov eax, 0x430920
000076cd267d0348  movups [r13+rax*1], xmm15
000076cd267d034e  mov eax, 0x430930
000076cd267d0353  movups [r13+rax*1], xmm13
000076cd267d0359  mov eax, 0x430940
000076cd267d035e  movups [r13+rax*1], xmm14
000076cd267d0364  mov eax, 0x430950
000076cd267d0369  movups [r13+rax*1], xmm1
000076cd267d036f  mov eax, [r15+0x108]
000076cd267d0376  sahf
000076cd267d0377  jnz 0x000076CD267D03A9
000076cd267d0379  cmp dword ptr [r15+0x318], 0x00
000076cd267d0381  jz 0x000076CD267DB900
000076cd267d0387  nop [rax+rax*1], ax
000076cd267d0390  nop [rax+rax*1], eax
000076cd267d0398  mov eax, 0x410444
000076cd267d039d  mov [r15+0x100], rax
000076cd267d03a4  jmp 0x000076CD265FE110
000076cd267d03a9  cmp dword ptr [r15+0x318], 0x00
000076cd267d03b1  jz 0x000076CD267D57E0
000076cd267d03b7  nop [rax+rax*1], ax
000076cd267d03c0  nop [rax+rax*1], eax
000076cd267d03c8  mov eax, 0x410278
000076cd267d03cd  mov [r15+0x100], rax
000076cd267d03d4  jmp 0x000076CD265FE110
000076cd267d03d9  int3
000076cd267d03da  call 0x000076CD266B52F0
000076cd267d03df  jmp 0x000076CD267CF016
000076cd267d03e4  call 0x000076CD266C4620
000076cd267d03e9  jmp 0x000076CD267CF023
000076cd267d03ee  call 0x000076CD266C33A0
000076cd267d03f3  jmp 0x000076CD267CF035
000076cd267d03f8  call 0x000076CD266C2120
000076cd267d03fd  jmp 0x000076CD267CF03F
000076cd267d0402  call 0x000076CD266C0860
000076cd267d0407  jmp 0x000076CD267CF067
000076cd267d040c  call 0x000076CD266BF5F0
000076cd267d0411  jmp 0x000076CD267CF073
000076cd267d0416  call 0x000076CD266C0860
000076cd267d041b  jmp 0x000076CD267CF0A5
000076cd267d0420  call 0x000076CD266BF5F0
000076cd267d0425  jmp 0x000076CD267CF0B1
000076cd267d042a  call 0x000076CD266C4740
000076cd267d042f  jmp 0x000076CD267CF0BE
000076cd267d0434  call 0x000076CD266B5400
000076cd267d0439  jmp 0x000076CD267CF0CB
000076cd267d043e  call 0x000076CD266B52F0
000076cd267d0443  jmp 0x000076CD267CF0D8
000076cd267d0448  call 0x000076CD266C4620
000076cd267d044d  jmp 0x000076CD267CF0E5
000076cd267d0452  call 0x000076CD266C0860
000076cd267d0457  jmp 0x000076CD267CF10D
000076cd267d045c  call 0x000076CD266BF5F0
000076cd267d0461  jmp 0x000076CD267CF119
000076cd267d0466  call 0x000076CD26609D70
000076cd267d046b  jmp 0x000076CD267CF11F
000076cd267d0470  call 0x000076CD266BE9C0
000076cd267d0475  jmp 0x000076CD267CF129
000076cd267d047a  call 0x000076CD266C0860
000076cd267d047f  jmp 0x000076CD267CF151
000076cd267d0484  call 0x000076CD266BF5F0
000076cd267d0489  jmp 0x000076CD267CF15D
000076cd267d048e  call 0x000076CD266BD750
000076cd267d0493  jmp 0x000076CD267CF16A
000076cd267d0498  call 0x000076CD266BC4E0
000076cd267d049d  jmp 0x000076CD267CF177
000076cd267d04a2  call 0x000076CD266C4740
000076cd267d04a7  jmp 0x000076CD267CF184
000076cd267d04ac  call 0x000076CD266B5400
000076cd267d04b1  jmp 0x000076CD267CF191
000076cd267d04b6  call 0x000076CD266B52F0
000076cd267d04bb  jmp 0x000076CD267CF19E
000076cd267d04c0  call 0x000076CD266C4620
000076cd267d04c5  jmp 0x000076CD267CF1AB
000076cd267d04ca  call 0x000076CD266C0860
000076cd267d04cf  jmp 0x000076CD267CF1BE
000076cd267d04d4  call 0x000076CD266BB270
000076cd267d04d9  jmp 0x000076CD267CF1CB
000076cd267d04de  call 0x000076CD266BA000
000076cd267d04e3  jmp 0x000076CD267CF1D8
000076cd267d04e8  call 0x000076CD266B8D90
000076cd267d04ed  jmp 0x000076CD267CF1E5
000076cd267d04f2  call 0x000076CD266B8A20
000076cd267d04f7  jmp 0x000076CD267CF1F2
000076cd267d04fc  call 0x000076CD266B5400
000076cd267d0501  jmp 0x000076CD267CF1FC
000076cd267d0506  call 0x000076CD266C2240
000076cd267d050b  jmp 0x000076CD267CF206
000076cd267d0510  call 0x000076CD266B52F0
000076cd267d0515  jmp 0x000076CD267CF210
000076cd267d051a  call 0x000076CD266C2120
000076cd267d051f  jmp 0x000076CD267CF21A
000076cd267d0524  call 0x000076CD266B77B0
000076cd267d0529  jmp 0x000076CD267CF224
000076cd267d052e  call 0x000076CD266B6550
000076cd267d0533  jmp 0x000076CD267CF22E
000076cd267d0538  call 0x000076CD266BFD50
000076cd267d053d  jmp 0x000076CD267CF240
000076cd267d0542  call 0x000076CD266B8EA0
000076cd267d0547  jmp 0x000076CD267CF24A
000076cd267d054c  call 0x000076CD266BFC30
000076cd267d0551  jmp 0x000076CD267CF257
000076cd267d0556  call 0x000076CD266B8D90
000076cd267d055b  jmp 0x000076CD267CF264
000076cd267d0560  call 0x000076CD266C2240
000076cd267d0565  jmp 0x000076CD267CF271
000076cd267d056a  call 0x000076CD266B5400
000076cd267d056f  jmp 0x000076CD267CF27E
000076cd267d0574  call 0x000076CD266B52F0
000076cd267d0579  jmp 0x000076CD267CF28B
000076cd267d057e  call 0x000076CD266C2120
000076cd267d0583  jmp 0x000076CD267CF298
000076cd267d0588  call 0x000076CD266B52F0
000076cd267d058d  jmp 0x000076CD267CF2AB
000076cd267d0592  call 0x000076CD266B52F0
000076cd267d0597  jmp 0x000076CD267CF2BE
000076cd267d059c  call 0x000076CD266B52F0
000076cd267d05a1  jmp 0x000076CD267CF2D1
000076cd267d05a6  call 0x000076CD266B52F0
000076cd267d05ab  jmp 0x000076CD267CF2E4
000076cd267d05b0  call 0x000076CD266C2240
000076cd267d05b5  jmp 0x000076CD267CF2F9
000076cd267d05ba  call 0x000076CD266C2240
000076cd267d05bf  jmp 0x000076CD267CF30C
000076cd267d05c4  call 0x000076CD266C2120
000076cd267d05c9  jmp 0x000076CD267CF319
000076cd267d05ce  call 0x000076CD266B52F0
000076cd267d05d3  jmp 0x000076CD267CF32C
000076cd267d05d8  call 0x000076CD266B52F0
000076cd267d05dd  jmp 0x000076CD267CF34F
000076cd267d05e2  call 0x000076CD266B52F0
000076cd267d05e7  jmp 0x000076CD267CF362
000076cd267d05ec  call 0x000076CD265FF540
000076cd267d05f1  jmp 0x000076CD267CF380
000076cd267d05f6  call 0x000076CD26608C20
000076cd267d05fb  jmp 0x000076CD267CF38A
000076cd267d0600  call 0x000076CD266D6600
000076cd267d0605  jmp 0x000076CD267CF396
000076cd267d060a  call 0x000076CD265FF540
000076cd267d060f  jmp 0x000076CD267CF3A6
000076cd267d0614  call 0x000076CD266C0370
000076cd267d0619  jmp 0x000076CD267CF3D4
000076cd267d061e  call 0x000076CD266BF100
000076cd267d0623  jmp 0x000076CD267CF3DD
000076cd267d0628  call 0x000076CD266C0370
000076cd267d062d  jmp 0x000076CD267CF43B
000076cd267d0632  call 0x000076CD266BF100
000076cd267d0637  jmp 0x000076CD267CF444
000076cd267d063c  call 0x000076CD266C0370
000076cd267d0641  jmp 0x000076CD267CF48B
000076cd267d0646  call 0x000076CD266BF100
000076cd267d064b  jmp 0x000076CD267CF494
000076cd267d0650  call 0x000076CD2660B720
000076cd267d0655  jmp 0x000076CD267CF4D7
000076cd267d065a  call 0x000076CD266B47C0
000076cd267d065f  jmp 0x000076CD267CF4EA
000076cd267d0664  call 0x000076CD26608B00
000076cd267d0669  jmp 0x000076CD267CF501
000076cd267d066e  call 0x000076CD265FF430
000076cd267d0673  jmp 0x000076CD267CF514
000076cd267d0678  call 0x000076CD265FF430
000076cd267d067d  jmp 0x000076CD267CF527
000076cd267d0682  sub rsp, 0x08
000076cd267d0686  push rax
000076cd267d0687  push rcx
000076cd267d0688  push rdx
000076cd267d0689  push rdi
000076cd267d068a  push rsi
000076cd267d068b  push r8
000076cd267d068d  push r9
000076cd267d068f  push r10
000076cd267d0691  push r11
000076cd267d0693  sub rsp, 0xF0
000076cd267d069a  vmovaps [rsp], xmm0
000076cd267d069f  vmovaps [rsp+0x10], xmm2
000076cd267d06a5  vmovaps [rsp+0x20], xmm3
000076cd267d06ab  vmovaps [rsp+0x30], xmm4
000076cd267d06b1  vmovaps [rsp+0x40], xmm5
000076cd267d06b7  vmovaps [rsp+0x50], xmm6
000076cd267d06bd  vmovaps [rsp+0x60], xmm7
000076cd267d06c3  vmovaps [rsp+0x70], xmm8
000076cd267d06c9  vmovaps [rsp+0x80], xmm9
000076cd267d06d2  vmovaps [rsp+0x90], xmm10
000076cd267d06db  vmovaps [rsp+0xA0], xmm11
000076cd267d06e4  vmovaps [rsp+0xB0], xmm12
000076cd267d06ed  vmovaps [rsp+0xC0], xmm13
000076cd267d06f6  vmovaps [rsp+0xD0], xmm14
000076cd267d06ff  vmovaps [rsp+0xE0], xmm15
000076cd267d0708  sub rsp, 0x30
000076cd267d070c  movaps [rsp], xmm1
000076cd267d0710  movaps [rsp+0x10], xmm15
000076cd267d0716  movaps [rsp+0x20], xmm14
000076cd267d071c  lea rdi, [rsp]
000076cd267d0720  mov esi, 0x00
000076cd267d0725  mov rax, 0x56B8861A9530
000076cd267d072f  call rax
000076cd267d0731  movaps xmm1, [rsp]
000076cd267d0735  add rsp, 0x30
000076cd267d0739  vmovaps xmm0, [rsp]
000076cd267d073e  vmovaps xmm2, [rsp+0x10]
000076cd267d0744  vmovaps xmm3, [rsp+0x20]
000076cd267d074a  vmovaps xmm4, [rsp+0x30]
000076cd267d0750  vmovaps xmm5, [rsp+0x40]
000076cd267d0756  vmovaps xmm6, [rsp+0x50]
000076cd267d075c  vmovaps xmm7, [rsp+0x60]
000076cd267d0762  vmovaps xmm8, [rsp+0x70]
000076cd267d0768  vmovaps xmm9, [rsp+0x80]
000076cd267d0771  vmovaps xmm10, [rsp+0x90]
000076cd267d077a  vmovaps xmm11, [rsp+0xA0]
000076cd267d0783  vmovaps xmm12, [rsp+0xB0]
000076cd267d078c  vmovaps xmm13, [rsp+0xC0]
000076cd267d0795  vmovaps xmm14, [rsp+0xD0]
000076cd267d079e  vmovaps xmm15, [rsp+0xE0]
000076cd267d07a7  add rsp, 0xF0
000076cd267d07ae  pop r11
000076cd267d07b0  pop r10
000076cd267d07b2  pop r9
000076cd267d07b4  pop r8
000076cd267d07b6  pop rsi
000076cd267d07b7  pop rdi
000076cd267d07b8  pop rdx
000076cd267d07b9  pop rcx
000076cd267d07ba  pop rax
000076cd267d07bb  add rsp, 0x08
000076cd267d07bf  jmp 0x000076CD267CF581
000076cd267d07c4  sub rsp, 0x08
000076cd267d07c8  push rax
000076cd267d07c9  push rcx
000076cd267d07ca  push rdx
000076cd267d07cb  push rdi
000076cd267d07cc  push rsi
000076cd267d07cd  push r8
000076cd267d07cf  push r9
000076cd267d07d1  push r10
000076cd267d07d3  push r11
000076cd267d07d5  sub rsp, 0xF0
000076cd267d07dc  vmovaps [rsp], xmm0
000076cd267d07e1  vmovaps [rsp+0x10], xmm1
000076cd267d07e7  vmovaps [rsp+0x20], xmm2
000076cd267d07ed  vmovaps [rsp+0x30], xmm3
000076cd267d07f3  vmovaps [rsp+0x40], xmm4
000076cd267d07f9  vmovaps [rsp+0x50], xmm5
000076cd267d07ff  vmovaps [rsp+0x60], xmm6
000076cd267d0805  vmovaps [rsp+0x70], xmm7
000076cd267d080b  vmovaps [rsp+0x80], xmm8
000076cd267d0814  vmovaps [rsp+0x90], xmm9
000076cd267d081d  vmovaps [rsp+0xA0], xmm10
000076cd267d0826  vmovaps [rsp+0xB0], xmm11
000076cd267d082f  vmovaps [rsp+0xC0], xmm12
000076cd267d0838  vmovaps [rsp+0xD0], xmm14
000076cd267d0841  vmovaps [rsp+0xE0], xmm15
000076cd267d084a  sub rsp, 0x30
000076cd267d084e  movaps [rsp], xmm13
000076cd267d0853  movaps [rsp+0x10], xmm1
000076cd267d0858  movaps [rsp+0x20], xmm14
000076cd267d085e  lea rdi, [rsp]
000076cd267d0862  mov esi, 0x00
000076cd267d0867  mov rax, 0x56B8861A9530
000076cd267d0871  call rax
000076cd267d0873  movaps xmm13, [rsp]
000076cd267d0878  add rsp, 0x30
000076cd267d087c  vmovaps xmm0, [rsp]
000076cd267d0881  vmovaps xmm1, [rsp+0x10]
000076cd267d0887  vmovaps xmm2, [rsp+0x20]
000076cd267d088d  vmovaps xmm3, [rsp+0x30]
000076cd267d0893  vmovaps xmm4, [rsp+0x40]
000076cd267d0899  vmovaps xmm5, [rsp+0x50]
000076cd267d089f  vmovaps xmm6, [rsp+0x60]
000076cd267d08a5  vmovaps xmm7, [rsp+0x70]
000076cd267d08ab  vmovaps xmm8, [rsp+0x80]
000076cd267d08b4  vmovaps xmm9, [rsp+0x90]
000076cd267d08bd  vmovaps xmm10, [rsp+0xA0]
000076cd267d08c6  vmovaps xmm11, [rsp+0xB0]
000076cd267d08cf  vmovaps xmm12, [rsp+0xC0]
000076cd267d08d8  vmovaps xmm14, [rsp+0xD0]
000076cd267d08e1  vmovaps xmm15, [rsp+0xE0]
000076cd267d08ea  add rsp, 0xF0
000076cd267d08f1  pop r11
000076cd267d08f3  pop r10
000076cd267d08f5  pop r9
000076cd267d08f7  pop r8
000076cd267d08f9  pop rsi
000076cd267d08fa  pop rdi
000076cd267d08fb  pop rdx
000076cd267d08fc  pop rcx
000076cd267d08fd  pop rax
000076cd267d08fe  add rsp, 0x08
000076cd267d0902  jmp 0x000076CD267CF5CF
000076cd267d0907  sub rsp, 0x08
000076cd267d090b  push rax
000076cd267d090c  push rcx
000076cd267d090d  push rdx
000076cd267d090e  push rdi
000076cd267d090f  push rsi
000076cd267d0910  push r8
000076cd267d0912  push r9
000076cd267d0914  push r10
000076cd267d0916  push r11
000076cd267d0918  sub rsp, 0xF0
000076cd267d091f  vmovaps [rsp], xmm0
000076cd267d0924  vmovaps [rsp+0x10], xmm1
000076cd267d092a  vmovaps [rsp+0x20], xmm2
000076cd267d0930  vmovaps [rsp+0x30], xmm3
000076cd267d0936  vmovaps [rsp+0x40], xmm4
000076cd267d093c  vmovaps [rsp+0x50], xmm5
000076cd267d0942  vmovaps [rsp+0x60], xmm6
000076cd267d0948  vmovaps [rsp+0x70], xmm7
000076cd267d094e  vmovaps [rsp+0x80], xmm8
000076cd267d0957  vmovaps [rsp+0x90], xmm9
000076cd267d0960  vmovaps [rsp+0xA0], xmm10
000076cd267d0969  vmovaps [rsp+0xB0], xmm11
000076cd267d0972  vmovaps [rsp+0xC0], xmm12
000076cd267d097b  vmovaps [rsp+0xD0], xmm13
000076cd267d0984  vmovaps [rsp+0xE0], xmm14
000076cd267d098d  sub rsp, 0x30
000076cd267d0991  movaps [rsp], xmm15
000076cd267d0996  movaps [rsp+0x10], xmm14
000076cd267d099c  movaps [rsp+0x20], xmm1
000076cd267d09a1  lea rdi, [rsp]
000076cd267d09a5  mov esi, 0x00
000076cd267d09aa  mov rax, 0x56B8861A9530
000076cd267d09b4  call rax
000076cd267d09b6  movaps xmm15, [rsp]
000076cd267d09bb  add rsp, 0x30
000076cd267d09bf  vmovaps xmm0, [rsp]
000076cd267d09c4  vmovaps xmm1, [rsp+0x10]
000076cd267d09ca  vmovaps xmm2, [rsp+0x20]
000076cd267d09d0  vmovaps xmm3, [rsp+0x30]
000076cd267d09d6  vmovaps xmm4, [rsp+0x40]
000076cd267d09dc  vmovaps xmm5, [rsp+0x50]
000076cd267d09e2  vmovaps xmm6, [rsp+0x60]
000076cd267d09e8  vmovaps xmm7, [rsp+0x70]
000076cd267d09ee  vmovaps xmm8, [rsp+0x80]
000076cd267d09f7  vmovaps xmm9, [rsp+0x90]
000076cd267d0a00  vmovaps xmm10, [rsp+0xA0]
000076cd267d0a09  vmovaps xmm11, [rsp+0xB0]
000076cd267d0a12  vmovaps xmm12, [rsp+0xC0]
000076cd267d0a1b  vmovaps xmm13, [rsp+0xD0]
000076cd267d0a24  vmovaps xmm14, [rsp+0xE0]
000076cd267d0a2d  add rsp, 0xF0
000076cd267d0a34  pop r11
000076cd267d0a36  pop r10
000076cd267d0a38  pop r9
000076cd267d0a3a  pop r8
000076cd267d0a3c  pop rsi
000076cd267d0a3d  pop rdi
000076cd267d0a3e  pop rdx
000076cd267d0a3f  pop rcx
000076cd267d0a40  pop rax
000076cd267d0a41  add rsp, 0x08
000076cd267d0a45  jmp 0x000076CD267CF617
000076cd267d0a4a  sub rsp, 0x08
000076cd267d0a4e  push rax
000076cd267d0a4f  push rcx
000076cd267d0a50  push rdx
000076cd267d0a51  push rdi
000076cd267d0a52  push rsi
000076cd267d0a53  push r8
000076cd267d0a55  push r9
000076cd267d0a57  push r10
000076cd267d0a59  push r11
000076cd267d0a5b  sub rsp, 0xF0
000076cd267d0a62  vmovaps [rsp], xmm0
000076cd267d0a67  vmovaps [rsp+0x10], xmm2
000076cd267d0a6d  vmovaps [rsp+0x20], xmm3
000076cd267d0a73  vmovaps [rsp+0x30], xmm4
000076cd267d0a79  vmovaps [rsp+0x40], xmm5
000076cd267d0a7f  vmovaps [rsp+0x50], xmm6
000076cd267d0a85  vmovaps [rsp+0x60], xmm7
000076cd267d0a8b  vmovaps [rsp+0x70], xmm8
000076cd267d0a91  vmovaps [rsp+0x80], xmm9
000076cd267d0a9a  vmovaps [rsp+0x90], xmm10
000076cd267d0aa3  vmovaps [rsp+0xA0], xmm11
000076cd267d0aac  vmovaps [rsp+0xB0], xmm12
000076cd267d0ab5  vmovaps [rsp+0xC0], xmm13
000076cd267d0abe  vmovaps [rsp+0xD0], xmm14
000076cd267d0ac7  vmovaps [rsp+0xE0], xmm15
000076cd267d0ad0  sub rsp, 0x30
000076cd267d0ad4  movaps [rsp], xmm1
000076cd267d0ad8  movaps [rsp+0x10], xmm14
000076cd267d0ade  movaps [rsp+0x20], xmm10
000076cd267d0ae4  lea rdi, [rsp]
000076cd267d0ae8  mov esi, 0x00
000076cd267d0aed  mov rax, 0x56B8861A9530
000076cd267d0af7  call rax
000076cd267d0af9  movaps xmm1, [rsp]
000076cd267d0afd  add rsp, 0x30
000076cd267d0b01  vmovaps xmm0, [rsp]
000076cd267d0b06  vmovaps xmm2, [rsp+0x10]
000076cd267d0b0c  vmovaps xmm3, [rsp+0x20]
000076cd267d0b12  vmovaps xmm4, [rsp+0x30]
000076cd267d0b18  vmovaps xmm5, [rsp+0x40]
000076cd267d0b1e  vmovaps xmm6, [rsp+0x50]
000076cd267d0b24  vmovaps xmm7, [rsp+0x60]
000076cd267d0b2a  vmovaps xmm8, [rsp+0x70]
000076cd267d0b30  vmovaps xmm9, [rsp+0x80]
000076cd267d0b39  vmovaps xmm10, [rsp+0x90]
000076cd267d0b42  vmovaps xmm11, [rsp+0xA0]
000076cd267d0b4b  vmovaps xmm12, [rsp+0xB0]
000076cd267d0b54  vmovaps xmm13, [rsp+0xC0]
000076cd267d0b5d  vmovaps xmm14, [rsp+0xD0]
000076cd267d0b66  vmovaps xmm15, [rsp+0xE0]
000076cd267d0b6f  add rsp, 0xF0
000076cd267d0b76  pop r11
000076cd267d0b78  pop r10
000076cd267d0b7a  pop r9
000076cd267d0b7c  pop r8
000076cd267d0b7e  pop rsi
000076cd267d0b7f  pop rdi
000076cd267d0b80  pop rdx
000076cd267d0b81  pop rcx
000076cd267d0b82  pop rax
000076cd267d0b83  add rsp, 0x08
000076cd267d0b87  jmp 0x000076CD267CF631
000076cd267d0b8c  sub rsp, 0x08
000076cd267d0b90  push rax
000076cd267d0b91  push rcx
000076cd267d0b92  push rdx
000076cd267d0b93  push rdi
000076cd267d0b94  push rsi
000076cd267d0b95  push r8
000076cd267d0b97  push r9
000076cd267d0b99  push r10
000076cd267d0b9b  push r11
000076cd267d0b9d  sub rsp, 0xF0
000076cd267d0ba4  vmovaps [rsp], xmm0
000076cd267d0ba9  vmovaps [rsp+0x10], xmm1
000076cd267d0baf  vmovaps [rsp+0x20], xmm2
000076cd267d0bb5  vmovaps [rsp+0x30], xmm3
000076cd267d0bbb  vmovaps [rsp+0x40], xmm4
000076cd267d0bc1  vmovaps [rsp+0x50], xmm5
000076cd267d0bc7  vmovaps [rsp+0x60], xmm6
000076cd267d0bcd  vmovaps [rsp+0x70], xmm7
000076cd267d0bd3  vmovaps [rsp+0x80], xmm8
000076cd267d0bdc  vmovaps [rsp+0x90], xmm9
000076cd267d0be5  vmovaps [rsp+0xA0], xmm10
000076cd267d0bee  vmovaps [rsp+0xB0], xmm11
000076cd267d0bf7  vmovaps [rsp+0xC0], xmm12
000076cd267d0c00  vmovaps [rsp+0xD0], xmm14
000076cd267d0c09  vmovaps [rsp+0xE0], xmm15
000076cd267d0c12  sub rsp, 0x30
000076cd267d0c16  movaps [rsp], xmm13
000076cd267d0c1b  movaps [rsp+0x10], xmm14
000076cd267d0c21  movaps [rsp+0x20], xmm2
000076cd267d0c26  lea rdi, [rsp]
000076cd267d0c2a  mov esi, 0x00
000076cd267d0c2f  mov rax, 0x56B8861A9530
000076cd267d0c39  call rax
000076cd267d0c3b  movaps xmm13, [rsp]
000076cd267d0c40  add rsp, 0x30
000076cd267d0c44  vmovaps xmm0, [rsp]
000076cd267d0c49  vmovaps xmm1, [rsp+0x10]
000076cd267d0c4f  vmovaps xmm2, [rsp+0x20]
000076cd267d0c55  vmovaps xmm3, [rsp+0x30]
000076cd267d0c5b  vmovaps xmm4, [rsp+0x40]
000076cd267d0c61  vmovaps xmm5, [rsp+0x50]
000076cd267d0c67  vmovaps xmm6, [rsp+0x60]
000076cd267d0c6d  vmovaps xmm7, [rsp+0x70]
000076cd267d0c73  vmovaps xmm8, [rsp+0x80]
000076cd267d0c7c  vmovaps xmm9, [rsp+0x90]
000076cd267d0c85  vmovaps xmm10, [rsp+0xA0]
000076cd267d0c8e  vmovaps xmm11, [rsp+0xB0]
000076cd267d0c97  vmovaps xmm12, [rsp+0xC0]
000076cd267d0ca0  vmovaps xmm14, [rsp+0xD0]
000076cd267d0ca9  vmovaps xmm15, [rsp+0xE0]
000076cd267d0cb2  add rsp, 0xF0
000076cd267d0cb9  pop r11
000076cd267d0cbb  pop r10
000076cd267d0cbd  pop r9
000076cd267d0cbf  pop r8
000076cd267d0cc1  pop rsi
000076cd267d0cc2  pop rdi
000076cd267d0cc3  pop rdx
000076cd267d0cc4  pop rcx
000076cd267d0cc5  pop rax
000076cd267d0cc6  add rsp, 0x08
000076cd267d0cca  jmp 0x000076CD267CF64C
000076cd267d0ccf  sub rsp, 0x08
000076cd267d0cd3  push rax
000076cd267d0cd4  push rcx
000076cd267d0cd5  push rdx
000076cd267d0cd6  push rdi
000076cd267d0cd7  push rsi
000076cd267d0cd8  push r8
000076cd267d0cda  push r9
000076cd267d0cdc  push r10
000076cd267d0cde  push r11
000076cd267d0ce0  sub rsp, 0xF0
000076cd267d0ce7  vmovaps [rsp], xmm0
000076cd267d0cec  vmovaps [rsp+0x10], xmm2
000076cd267d0cf2  vmovaps [rsp+0x20], xmm3
000076cd267d0cf8  vmovaps [rsp+0x30], xmm4
000076cd267d0cfe  vmovaps [rsp+0x40], xmm5
000076cd267d0d04  vmovaps [rsp+0x50], xmm6
000076cd267d0d0a  vmovaps [rsp+0x60], xmm7
000076cd267d0d10  vmovaps [rsp+0x70], xmm8
000076cd267d0d16  vmovaps [rsp+0x80], xmm9
000076cd267d0d1f  vmovaps [rsp+0x90], xmm10
000076cd267d0d28  vmovaps [rsp+0xA0], xmm11
000076cd267d0d31  vmovaps [rsp+0xB0], xmm12
000076cd267d0d3a  vmovaps [rsp+0xC0], xmm13
000076cd267d0d43  vmovaps [rsp+0xD0], xmm14
000076cd267d0d4c  vmovaps [rsp+0xE0], xmm15
000076cd267d0d55  sub rsp, 0x30
000076cd267d0d59  movaps [rsp], xmm1
000076cd267d0d5d  movaps [rsp+0x10], xmm10
000076cd267d0d63  movaps [rsp+0x20], xmm2
000076cd267d0d68  lea rdi, [rsp]
000076cd267d0d6c  mov esi, 0x00
000076cd267d0d71  mov rax, 0x56B8861A9530
000076cd267d0d7b  call rax
000076cd267d0d7d  movaps xmm1, [rsp]
000076cd267d0d81  add rsp, 0x30
000076cd267d0d85  vmovaps xmm0, [rsp]
000076cd267d0d8a  vmovaps xmm2, [rsp+0x10]
000076cd267d0d90  vmovaps xmm3, [rsp+0x20]
000076cd267d0d96  vmovaps xmm4, [rsp+0x30]
000076cd267d0d9c  vmovaps xmm5, [rsp+0x40]
000076cd267d0da2  vmovaps xmm6, [rsp+0x50]
000076cd267d0da8  vmovaps xmm7, [rsp+0x60]
000076cd267d0dae  vmovaps xmm8, [rsp+0x70]
000076cd267d0db4  vmovaps xmm9, [rsp+0x80]
000076cd267d0dbd  vmovaps xmm10, [rsp+0x90]
000076cd267d0dc6  vmovaps xmm11, [rsp+0xA0]
000076cd267d0dcf  vmovaps xmm12, [rsp+0xB0]
000076cd267d0dd8  vmovaps xmm13, [rsp+0xC0]
000076cd267d0de1  vmovaps xmm14, [rsp+0xD0]
000076cd267d0dea  vmovaps xmm15, [rsp+0xE0]
000076cd267d0df3  add rsp, 0xF0
000076cd267d0dfa  pop r11
000076cd267d0dfc  pop r10
000076cd267d0dfe  pop r9
000076cd267d0e00  pop r8
000076cd267d0e02  pop rsi
000076cd267d0e03  pop rdi
000076cd267d0e04  pop rdx
000076cd267d0e05  pop rcx
000076cd267d0e06  pop rax
000076cd267d0e07  add rsp, 0x08
000076cd267d0e0b  jmp 0x000076CD267CF6B4
000076cd267d0e10  sub rsp, 0x08
000076cd267d0e14  push rax
000076cd267d0e15  push rcx
000076cd267d0e16  push rdx
000076cd267d0e17  push rdi
000076cd267d0e18  push rsi
000076cd267d0e19  push r8
000076cd267d0e1b  push r9
000076cd267d0e1d  push r10
000076cd267d0e1f  push r11
000076cd267d0e21  sub rsp, 0xF0
000076cd267d0e28  vmovaps [rsp], xmm0
000076cd267d0e2d  vmovaps [rsp+0x10], xmm1
000076cd267d0e33  vmovaps [rsp+0x20], xmm2
000076cd267d0e39  vmovaps [rsp+0x30], xmm3
000076cd267d0e3f  vmovaps [rsp+0x40], xmm4
000076cd267d0e45  vmovaps [rsp+0x50], xmm5
000076cd267d0e4b  vmovaps [rsp+0x60], xmm6
000076cd267d0e51  vmovaps [rsp+0x70], xmm7
000076cd267d0e57  vmovaps [rsp+0x80], xmm8
000076cd267d0e60  vmovaps [rsp+0x90], xmm9
000076cd267d0e69  vmovaps [rsp+0xA0], xmm10
000076cd267d0e72  vmovaps [rsp+0xB0], xmm11
000076cd267d0e7b  vmovaps [rsp+0xC0], xmm12
000076cd267d0e84  vmovaps [rsp+0xD0], xmm13
000076cd267d0e8d  vmovaps [rsp+0xE0], xmm14
000076cd267d0e96  sub rsp, 0x30
000076cd267d0e9a  movaps [rsp], xmm15
000076cd267d0e9f  movaps [rsp+0x10], xmm10
000076cd267d0ea5  movaps [rsp+0x20], xmm2
000076cd267d0eaa  lea rdi, [rsp]
000076cd267d0eae  mov esi, 0x00
000076cd267d0eb3  mov rax, 0x56B8861A9530
000076cd267d0ebd  call rax
000076cd267d0ebf  movaps xmm15, [rsp]
000076cd267d0ec4  add rsp, 0x30
000076cd267d0ec8  vmovaps xmm0, [rsp]
000076cd267d0ecd  vmovaps xmm1, [rsp+0x10]
000076cd267d0ed3  vmovaps xmm2, [rsp+0x20]
000076cd267d0ed9  vmovaps xmm3, [rsp+0x30]
000076cd267d0edf  vmovaps xmm4, [rsp+0x40]
000076cd267d0ee5  vmovaps xmm5, [rsp+0x50]
000076cd267d0eeb  vmovaps xmm6, [rsp+0x60]
000076cd267d0ef1  vmovaps xmm7, [rsp+0x70]
000076cd267d0ef7  vmovaps xmm8, [rsp+0x80]
000076cd267d0f00  vmovaps xmm9, [rsp+0x90]
000076cd267d0f09  vmovaps xmm10, [rsp+0xA0]
000076cd267d0f12  vmovaps xmm11, [rsp+0xB0]
000076cd267d0f1b  vmovaps xmm12, [rsp+0xC0]
000076cd267d0f24  vmovaps xmm13, [rsp+0xD0]
000076cd267d0f2d  vmovaps xmm14, [rsp+0xE0]
000076cd267d0f36  add rsp, 0xF0
000076cd267d0f3d  pop r11
000076cd267d0f3f  pop r10
000076cd267d0f41  pop r9
000076cd267d0f43  pop r8
000076cd267d0f45  pop rsi
000076cd267d0f46  pop rdi
000076cd267d0f47  pop rdx
000076cd267d0f48  pop rcx
000076cd267d0f49  pop rax
000076cd267d0f4a  add rsp, 0x08
000076cd267d0f4e  jmp 0x000076CD267CF706
000076cd267d0f53  sub rsp, 0x08
000076cd267d0f57  push rax
000076cd267d0f58  push rcx
000076cd267d0f59  push rdx
000076cd267d0f5a  push rdi
000076cd267d0f5b  push rsi
000076cd267d0f5c  push r8
000076cd267d0f5e  push r9
000076cd267d0f60  push r10
000076cd267d0f62  push r11
000076cd267d0f64  sub rsp, 0xF0
000076cd267d0f6b  vmovaps [rsp], xmm0
000076cd267d0f70  vmovaps [rsp+0x10], xmm2
000076cd267d0f76  vmovaps [rsp+0x20], xmm3
000076cd267d0f7c  vmovaps [rsp+0x30], xmm4
000076cd267d0f82  vmovaps [rsp+0x40], xmm5
000076cd267d0f88  vmovaps [rsp+0x50], xmm6
000076cd267d0f8e  vmovaps [rsp+0x60], xmm7
000076cd267d0f94  vmovaps [rsp+0x70], xmm8
000076cd267d0f9a  vmovaps [rsp+0x80], xmm9
000076cd267d0fa3  vmovaps [rsp+0x90], xmm10
000076cd267d0fac  vmovaps [rsp+0xA0], xmm11
000076cd267d0fb5  vmovaps [rsp+0xB0], xmm12
000076cd267d0fbe  vmovaps [rsp+0xC0], xmm13
000076cd267d0fc7  vmovaps [rsp+0xD0], xmm14
000076cd267d0fd0  vmovaps [rsp+0xE0], xmm15
000076cd267d0fd9  sub rsp, 0x30
000076cd267d0fdd  movaps [rsp], xmm1
000076cd267d0fe1  movaps [rsp+0x10], xmm10
000076cd267d0fe7  movaps [rsp+0x20], xmm12
000076cd267d0fed  lea rdi, [rsp]
000076cd267d0ff1  mov esi, 0x00
000076cd267d0ff6  mov rax, 0x56B8861A9530
000076cd267d1000  call rax
000076cd267d1002  movaps xmm1, [rsp]
000076cd267d1006  add rsp, 0x30
000076cd267d100a  vmovaps xmm0, [rsp]
000076cd267d100f  vmovaps xmm2, [rsp+0x10]
000076cd267d1015  vmovaps xmm3, [rsp+0x20]
000076cd267d101b  vmovaps xmm4, [rsp+0x30]
000076cd267d1021  vmovaps xmm5, [rsp+0x40]
000076cd267d1027  vmovaps xmm6, [rsp+0x50]
000076cd267d102d  vmovaps xmm7, [rsp+0x60]
000076cd267d1033  vmovaps xmm8, [rsp+0x70]
000076cd267d1039  vmovaps xmm9, [rsp+0x80]
000076cd267d1042  vmovaps xmm10, [rsp+0x90]
000076cd267d104b  vmovaps xmm11, [rsp+0xA0]
000076cd267d1054  vmovaps xmm12, [rsp+0xB0]
000076cd267d105d  vmovaps xmm13, [rsp+0xC0]
000076cd267d1066  vmovaps xmm14, [rsp+0xD0]
000076cd267d106f  vmovaps xmm15, [rsp+0xE0]
000076cd267d1078  add rsp, 0xF0
000076cd267d107f  pop r11
000076cd267d1081  pop r10
000076cd267d1083  pop r9
000076cd267d1085  pop r8
000076cd267d1087  pop rsi
000076cd267d1088  pop rdi
000076cd267d1089  pop rdx
000076cd267d108a  pop rcx
000076cd267d108b  pop rax
000076cd267d108c  add rsp, 0x08
000076cd267d1090  jmp 0x000076CD267CF732
000076cd267d1095  sub rsp, 0x08
000076cd267d1099  push rax
000076cd267d109a  push rcx
000076cd267d109b  push rdx
000076cd267d109c  push rdi
000076cd267d109d  push rsi
000076cd267d109e  push r8
000076cd267d10a0  push r9
000076cd267d10a2  push r10
000076cd267d10a4  push r11
000076cd267d10a6  sub rsp, 0xF0
000076cd267d10ad  vmovaps [rsp], xmm0
000076cd267d10b2  vmovaps [rsp+0x10], xmm1
000076cd267d10b8  vmovaps [rsp+0x20], xmm2
000076cd267d10be  vmovaps [rsp+0x30], xmm3
000076cd267d10c4  vmovaps [rsp+0x40], xmm4
000076cd267d10ca  vmovaps [rsp+0x50], xmm5
000076cd267d10d0  vmovaps [rsp+0x60], xmm6
000076cd267d10d6  vmovaps [rsp+0x70], xmm7
000076cd267d10dc  vmovaps [rsp+0x80], xmm8
000076cd267d10e5  vmovaps [rsp+0x90], xmm9
000076cd267d10ee  vmovaps [rsp+0xA0], xmm10
000076cd267d10f7  vmovaps [rsp+0xB0], xmm11
000076cd267d1100  vmovaps [rsp+0xC0], xmm12
000076cd267d1109  vmovaps [rsp+0xD0], xmm13
000076cd267d1112  vmovaps [rsp+0xE0], xmm14
000076cd267d111b  sub rsp, 0x30
000076cd267d111f  movaps [rsp], xmm15
000076cd267d1124  movaps [rsp+0x10], xmm10
000076cd267d112a  movaps [rsp+0x20], xmm12
000076cd267d1130  lea rdi, [rsp]
000076cd267d1134  mov esi, 0x00
000076cd267d1139  mov rax, 0x56B8861A9530
000076cd267d1143  call rax
000076cd267d1145  movaps xmm15, [rsp]
000076cd267d114a  add rsp, 0x30
000076cd267d114e  vmovaps xmm0, [rsp]
000076cd267d1153  vmovaps xmm1, [rsp+0x10]
000076cd267d1159  vmovaps xmm2, [rsp+0x20]
000076cd267d115f  vmovaps xmm3, [rsp+0x30]
000076cd267d1165  vmovaps xmm4, [rsp+0x40]
000076cd267d116b  vmovaps xmm5, [rsp+0x50]
000076cd267d1171  vmovaps xmm6, [rsp+0x60]
000076cd267d1177  vmovaps xmm7, [rsp+0x70]
000076cd267d117d  vmovaps xmm8, [rsp+0x80]
000076cd267d1186  vmovaps xmm9, [rsp+0x90]
000076cd267d118f  vmovaps xmm10, [rsp+0xA0]
000076cd267d1198  vmovaps xmm11, [rsp+0xB0]
000076cd267d11a1  vmovaps xmm12, [rsp+0xC0]
000076cd267d11aa  vmovaps xmm13, [rsp+0xD0]
000076cd267d11b3  vmovaps xmm14, [rsp+0xE0]
000076cd267d11bc  add rsp, 0xF0
000076cd267d11c3  pop r11
000076cd267d11c5  pop r10
000076cd267d11c7  pop r9
000076cd267d11c9  pop r8
000076cd267d11cb  pop rsi
000076cd267d11cc  pop rdi
000076cd267d11cd  pop rdx
000076cd267d11ce  pop rcx
000076cd267d11cf  pop rax
000076cd267d11d0  add rsp, 0x08
000076cd267d11d4  jmp 0x000076CD267CF75E
000076cd267d11d9  call 0x000076CD265FF430
000076cd267d11de  jmp 0x000076CD267CF7EE
000076cd267d11e3  call 0x000076CD265FF430
000076cd267d11e8  jmp 0x000076CD267CF801
000076cd267d11ed  sub rsp, 0x08
000076cd267d11f1  push rax
000076cd267d11f2  push rcx
000076cd267d11f3  push rdx
000076cd267d11f4  push rdi
000076cd267d11f5  push rsi
000076cd267d11f6  push r8
000076cd267d11f8  push r9
000076cd267d11fa  push r10
000076cd267d11fc  push r11
000076cd267d11fe  sub rsp, 0xF0
000076cd267d1205  vmovaps [rsp], xmm0
000076cd267d120a  vmovaps [rsp+0x10], xmm2
000076cd267d1210  vmovaps [rsp+0x20], xmm3
000076cd267d1216  vmovaps [rsp+0x30], xmm4
000076cd267d121c  vmovaps [rsp+0x40], xmm5
000076cd267d1222  vmovaps [rsp+0x50], xmm6
000076cd267d1228  vmovaps [rsp+0x60], xmm7
000076cd267d122e  vmovaps [rsp+0x70], xmm8
000076cd267d1234  vmovaps [rsp+0x80], xmm9
000076cd267d123d  vmovaps [rsp+0x90], xmm10
000076cd267d1246  vmovaps [rsp+0xA0], xmm11
000076cd267d124f  vmovaps [rsp+0xB0], xmm12
000076cd267d1258  vmovaps [rsp+0xC0], xmm13
000076cd267d1261  vmovaps [rsp+0xD0], xmm14
000076cd267d126a  vmovaps [rsp+0xE0], xmm15
000076cd267d1273  sub rsp, 0x30
000076cd267d1277  movaps [rsp], xmm1
000076cd267d127b  movaps [rsp+0x10], xmm13
000076cd267d1281  movaps [rsp+0x20], xmm2
000076cd267d1286  lea rdi, [rsp]
000076cd267d128a  mov esi, 0x00
000076cd267d128f  mov rax, 0x56B8861A9530
000076cd267d1299  call rax
000076cd267d129b  movaps xmm1, [rsp]
000076cd267d129f  add rsp, 0x30
000076cd267d12a3  vmovaps xmm0, [rsp]
000076cd267d12a8  vmovaps xmm2, [rsp+0x10]
000076cd267d12ae  vmovaps xmm3, [rsp+0x20]
000076cd267d12b4  vmovaps xmm4, [rsp+0x30]
000076cd267d12ba  vmovaps xmm5, [rsp+0x40]
000076cd267d12c0  vmovaps xmm6, [rsp+0x50]
000076cd267d12c6  vmovaps xmm7, [rsp+0x60]
000076cd267d12cc  vmovaps xmm8, [rsp+0x70]
000076cd267d12d2  vmovaps xmm9, [rsp+0x80]
000076cd267d12db  vmovaps xmm10, [rsp+0x90]
000076cd267d12e4  vmovaps xmm11, [rsp+0xA0]
000076cd267d12ed  vmovaps xmm12, [rsp+0xB0]
000076cd267d12f6  vmovaps xmm13, [rsp+0xC0]
000076cd267d12ff  vmovaps xmm14, [rsp+0xD0]
000076cd267d1308  vmovaps xmm15, [rsp+0xE0]
000076cd267d1311  add rsp, 0xF0
000076cd267d1318  pop r11
000076cd267d131a  pop r10
000076cd267d131c  pop r9
000076cd267d131e  pop r8
000076cd267d1320  pop rsi
000076cd267d1321  pop rdi
000076cd267d1322  pop rdx
000076cd267d1323  pop rcx
000076cd267d1324  pop rax
000076cd267d1325  add rsp, 0x08
000076cd267d1329  jmp 0x000076CD267CF82C
000076cd267d132e  call 0x000076CD2660E760
000076cd267d1333  jmp 0x000076CD267CF839
000076cd267d1338  sub rsp, 0x08
000076cd267d133c  push rax
000076cd267d133d  push rcx
000076cd267d133e  push rdx
000076cd267d133f  push rdi
000076cd267d1340  push rsi
000076cd267d1341  push r8
000076cd267d1343  push r9
000076cd267d1345  push r10
000076cd267d1347  push r11
000076cd267d1349  sub rsp, 0xF0
000076cd267d1350  vmovaps [rsp], xmm0
000076cd267d1355  vmovaps [rsp+0x10], xmm1
000076cd267d135b  vmovaps [rsp+0x20], xmm2
000076cd267d1361  vmovaps [rsp+0x30], xmm3
000076cd267d1367  vmovaps [rsp+0x40], xmm4
000076cd267d136d  vmovaps [rsp+0x50], xmm5
000076cd267d1373  vmovaps [rsp+0x60], xmm6
000076cd267d1379  vmovaps [rsp+0x70], xmm7
000076cd267d137f  vmovaps [rsp+0x80], xmm8
000076cd267d1388  vmovaps [rsp+0x90], xmm9
000076cd267d1391  vmovaps [rsp+0xA0], xmm10
000076cd267d139a  vmovaps [rsp+0xB0], xmm11
000076cd267d13a3  vmovaps [rsp+0xC0], xmm12
000076cd267d13ac  vmovaps [rsp+0xD0], xmm14
000076cd267d13b5  vmovaps [rsp+0xE0], xmm15
000076cd267d13be  sub rsp, 0x30
000076cd267d13c2  movaps [rsp], xmm13
000076cd267d13c7  movaps [rsp+0x10], xmm2
000076cd267d13cc  movaps [rsp+0x20], xmm1
000076cd267d13d1  lea rdi, [rsp]
000076cd267d13d5  mov esi, 0x00
000076cd267d13da  mov rax, 0x56B8861A9530
000076cd267d13e4  call rax
000076cd267d13e6  movaps xmm13, [rsp]
000076cd267d13eb  add rsp, 0x30
000076cd267d13ef  vmovaps xmm0, [rsp]
000076cd267d13f4  vmovaps xmm1, [rsp+0x10]
000076cd267d13fa  vmovaps xmm2, [rsp+0x20]
000076cd267d1400  vmovaps xmm3, [rsp+0x30]
000076cd267d1406  vmovaps xmm4, [rsp+0x40]
000076cd267d140c  vmovaps xmm5, [rsp+0x50]
000076cd267d1412  vmovaps xmm6, [rsp+0x60]
000076cd267d1418  vmovaps xmm7, [rsp+0x70]
000076cd267d141e  vmovaps xmm8, [rsp+0x80]
000076cd267d1427  vmovaps xmm9, [rsp+0x90]
000076cd267d1430  vmovaps xmm10, [rsp+0xA0]
000076cd267d1439  vmovaps xmm11, [rsp+0xB0]
000076cd267d1442  vmovaps xmm12, [rsp+0xC0]
000076cd267d144b  vmovaps xmm14, [rsp+0xD0]
000076cd267d1454  vmovaps xmm15, [rsp+0xE0]
000076cd267d145d  add rsp, 0xF0
000076cd267d1464  pop r11
000076cd267d1466  pop r10
000076cd267d1468  pop r9
000076cd267d146a  pop r8
000076cd267d146c  pop rsi
000076cd267d146d  pop rdi
000076cd267d146e  pop rdx
000076cd267d146f  pop rcx
000076cd267d1470  pop rax
000076cd267d1471  add rsp, 0x08
000076cd267d1475  jmp 0x000076CD267CF878
000076cd267d147a  sub rsp, 0x08
000076cd267d147e  push rax
000076cd267d147f  push rcx
000076cd267d1480  push rdx
000076cd267d1481  push rdi
000076cd267d1482  push rsi
000076cd267d1483  push r8
000076cd267d1485  push r9
000076cd267d1487  push r10
000076cd267d1489  push r11
000076cd267d148b  sub rsp, 0xF0
000076cd267d1492  vmovaps [rsp], xmm0
000076cd267d1497  vmovaps [rsp+0x10], xmm2
000076cd267d149d  vmovaps [rsp+0x20], xmm3
000076cd267d14a3  vmovaps [rsp+0x30], xmm4
000076cd267d14a9  vmovaps [rsp+0x40], xmm5
000076cd267d14af  vmovaps [rsp+0x50], xmm6
000076cd267d14b5  vmovaps [rsp+0x60], xmm7
000076cd267d14bb  vmovaps [rsp+0x70], xmm8
000076cd267d14c1  vmovaps [rsp+0x80], xmm9
000076cd267d14ca  vmovaps [rsp+0x90], xmm10
000076cd267d14d3  vmovaps [rsp+0xA0], xmm11
000076cd267d14dc  vmovaps [rsp+0xB0], xmm12
000076cd267d14e5  vmovaps [rsp+0xC0], xmm13
000076cd267d14ee  vmovaps [rsp+0xD0], xmm14
000076cd267d14f7  vmovaps [rsp+0xE0], xmm15
000076cd267d1500  sub rsp, 0x30
000076cd267d1504  movaps [rsp], xmm1
000076cd267d1508  movaps [rsp+0x10], xmm15
000076cd267d150e  movaps [rsp+0x20], xmm2
000076cd267d1513  lea rdi, [rsp]
000076cd267d1517  mov esi, 0x00
000076cd267d151c  mov rax, 0x56B8861A9530
000076cd267d1526  call rax
000076cd267d1528  movaps xmm1, [rsp]
000076cd267d152c  add rsp, 0x30
000076cd267d1530  vmovaps xmm0, [rsp]
000076cd267d1535  vmovaps xmm2, [rsp+0x10]
000076cd267d153b  vmovaps xmm3, [rsp+0x20]
000076cd267d1541  vmovaps xmm4, [rsp+0x30]
000076cd267d1547  vmovaps xmm5, [rsp+0x40]
000076cd267d154d  vmovaps xmm6, [rsp+0x50]
000076cd267d1553  vmovaps xmm7, [rsp+0x60]
000076cd267d1559  vmovaps xmm8, [rsp+0x70]
000076cd267d155f  vmovaps xmm9, [rsp+0x80]
000076cd267d1568  vmovaps xmm10, [rsp+0x90]
000076cd267d1571  vmovaps xmm11, [rsp+0xA0]
000076cd267d157a  vmovaps xmm12, [rsp+0xB0]
000076cd267d1583  vmovaps xmm13, [rsp+0xC0]
000076cd267d158c  vmovaps xmm14, [rsp+0xD0]
000076cd267d1595  vmovaps xmm15, [rsp+0xE0]
000076cd267d159e  add rsp, 0xF0
000076cd267d15a5  pop r11
000076cd267d15a7  pop r10
000076cd267d15a9  pop r9
000076cd267d15ab  pop r8
000076cd267d15ad  pop rsi
000076cd267d15ae  pop rdi
000076cd267d15af  pop rdx
000076cd267d15b0  pop rcx
000076cd267d15b1  pop rax
000076cd267d15b2  add rsp, 0x08
000076cd267d15b6  jmp 0x000076CD267CF8AC
000076cd267d15bb  sub rsp, 0x08
000076cd267d15bf  push rax
000076cd267d15c0  push rcx
000076cd267d15c1  push rdx
000076cd267d15c2  push rdi
000076cd267d15c3  push rsi
000076cd267d15c4  push r8
000076cd267d15c6  push r9
000076cd267d15c8  push r10
000076cd267d15ca  push r11
000076cd267d15cc  sub rsp, 0xF0
000076cd267d15d3  vmovaps [rsp], xmm0
000076cd267d15d8  vmovaps [rsp+0x10], xmm1
000076cd267d15de  vmovaps [rsp+0x20], xmm2
000076cd267d15e4  vmovaps [rsp+0x30], xmm3
000076cd267d15ea  vmovaps [rsp+0x40], xmm4
000076cd267d15f0  vmovaps [rsp+0x50], xmm5
000076cd267d15f6  vmovaps [rsp+0x60], xmm6
000076cd267d15fc  vmovaps [rsp+0x70], xmm7
000076cd267d1602  vmovaps [rsp+0x80], xmm8
000076cd267d160b  vmovaps [rsp+0x90], xmm9
000076cd267d1614  vmovaps [rsp+0xA0], xmm10
000076cd267d161d  vmovaps [rsp+0xB0], xmm11
000076cd267d1626  vmovaps [rsp+0xC0], xmm12
000076cd267d162f  vmovaps [rsp+0xD0], xmm13
000076cd267d1638  vmovaps [rsp+0xE0], xmm15
000076cd267d1641  sub rsp, 0x30
000076cd267d1645  movaps [rsp], xmm14
000076cd267d164a  movaps [rsp+0x10], xmm2
000076cd267d164f  movaps [rsp+0x20], xmm15
000076cd267d1655  lea rdi, [rsp]
000076cd267d1659  mov esi, 0x00
000076cd267d165e  mov rax, 0x56B8861A9530
000076cd267d1668  call rax
000076cd267d166a  movaps xmm14, [rsp]
000076cd267d166f  add rsp, 0x30
000076cd267d1673  vmovaps xmm0, [rsp]
000076cd267d1678  vmovaps xmm1, [rsp+0x10]
000076cd267d167e  vmovaps xmm2, [rsp+0x20]
000076cd267d1684  vmovaps xmm3, [rsp+0x30]
000076cd267d168a  vmovaps xmm4, [rsp+0x40]
000076cd267d1690  vmovaps xmm5, [rsp+0x50]
000076cd267d1696  vmovaps xmm6, [rsp+0x60]
000076cd267d169c  vmovaps xmm7, [rsp+0x70]
000076cd267d16a2  vmovaps xmm8, [rsp+0x80]
000076cd267d16ab  vmovaps xmm9, [rsp+0x90]
000076cd267d16b4  vmovaps xmm10, [rsp+0xA0]
000076cd267d16bd  vmovaps xmm11, [rsp+0xB0]
000076cd267d16c6  vmovaps xmm12, [rsp+0xC0]
000076cd267d16cf  vmovaps xmm13, [rsp+0xD0]
000076cd267d16d8  vmovaps xmm15, [rsp+0xE0]
000076cd267d16e1  add rsp, 0xF0
000076cd267d16e8  pop r11
000076cd267d16ea  pop r10
000076cd267d16ec  pop r9
000076cd267d16ee  pop r8
000076cd267d16f0  pop rsi
000076cd267d16f1  pop rdi
000076cd267d16f2  pop rdx
000076cd267d16f3  pop rcx
000076cd267d16f4  pop rax
000076cd267d16f5  add rsp, 0x08
000076cd267d16f9  jmp 0x000076CD267CF8E7
000076cd267d16fe  sub rsp, 0x08
000076cd267d1702  push rax
000076cd267d1703  push rcx
000076cd267d1704  push rdx
000076cd267d1705  push rdi
000076cd267d1706  push rsi
000076cd267d1707  push r8
000076cd267d1709  push r9
000076cd267d170b  push r10
000076cd267d170d  push r11
000076cd267d170f  sub rsp, 0xF0
000076cd267d1716  vmovaps [rsp], xmm0
000076cd267d171b  vmovaps [rsp+0x10], xmm1
000076cd267d1721  vmovaps [rsp+0x20], xmm2
000076cd267d1727  vmovaps [rsp+0x30], xmm3
000076cd267d172d  vmovaps [rsp+0x40], xmm4
000076cd267d1733  vmovaps [rsp+0x50], xmm5
000076cd267d1739  vmovaps [rsp+0x60], xmm6
000076cd267d173f  vmovaps [rsp+0x70], xmm7
000076cd267d1745  vmovaps [rsp+0x80], xmm8
000076cd267d174e  vmovaps [rsp+0x90], xmm9
000076cd267d1757  vmovaps [rsp+0xA0], xmm10
000076cd267d1760  vmovaps [rsp+0xB0], xmm11
000076cd267d1769  vmovaps [rsp+0xC0], xmm12
000076cd267d1772  vmovaps [rsp+0xD0], xmm13
000076cd267d177b  vmovaps [rsp+0xE0], xmm14
000076cd267d1784  sub rsp, 0x30
000076cd267d1788  movaps [rsp], xmm15
000076cd267d178d  movaps [rsp+0x10], xmm2
000076cd267d1792  movaps [rsp+0x20], xmm1
000076cd267d1797  lea rdi, [rsp]
000076cd267d179b  mov esi, 0x00
000076cd267d17a0  mov rax, 0x56B8861A9530
000076cd267d17aa  call rax
000076cd267d17ac  movaps xmm15, [rsp]
000076cd267d17b1  add rsp, 0x30
000076cd267d17b5  vmovaps xmm0, [rsp]
000076cd267d17ba  vmovaps xmm1, [rsp+0x10]
000076cd267d17c0  vmovaps xmm2, [rsp+0x20]
000076cd267d17c6  vmovaps xmm3, [rsp+0x30]
000076cd267d17cc  vmovaps xmm4, [rsp+0x40]
000076cd267d17d2  vmovaps xmm5, [rsp+0x50]
000076cd267d17d8  vmovaps xmm6, [rsp+0x60]
000076cd267d17de  vmovaps xmm7, [rsp+0x70]
000076cd267d17e4  vmovaps xmm8, [rsp+0x80]
000076cd267d17ed  vmovaps xmm9, [rsp+0x90]
000076cd267d17f6  vmovaps xmm10, [rsp+0xA0]
000076cd267d17ff  vmovaps xmm11, [rsp+0xB0]
000076cd267d1808  vmovaps xmm12, [rsp+0xC0]
000076cd267d1811  vmovaps xmm13, [rsp+0xD0]
000076cd267d181a  vmovaps xmm14, [rsp+0xE0]
000076cd267d1823  add rsp, 0xF0
000076cd267d182a  pop r11
000076cd267d182c  pop r10
000076cd267d182e  pop r9
000076cd267d1830  pop r8
000076cd267d1832  pop rsi
000076cd267d1833  pop rdi
000076cd267d1834  pop rdx
000076cd267d1835  pop rcx
000076cd267d1836  pop rax
000076cd267d1837  add rsp, 0x08
000076cd267d183b  jmp 0x000076CD267CF923
000076cd267d1840  call 0x000076CD265FF430
000076cd267d1845  jmp 0x000076CD267CF930
000076cd267d184a  sub rsp, 0x08
000076cd267d184e  push rax
000076cd267d184f  push rcx
000076cd267d1850  push rdx
000076cd267d1851  push rdi
000076cd267d1852  push rsi
000076cd267d1853  push r8
000076cd267d1855  push r9
000076cd267d1857  push r10
000076cd267d1859  push r11
000076cd267d185b  sub rsp, 0xF0
000076cd267d1862  vmovaps [rsp], xmm0
000076cd267d1867  vmovaps [rsp+0x10], xmm1
000076cd267d186d  vmovaps [rsp+0x20], xmm3
000076cd267d1873  vmovaps [rsp+0x30], xmm4
000076cd267d1879  vmovaps [rsp+0x40], xmm5
000076cd267d187f  vmovaps [rsp+0x50], xmm6
000076cd267d1885  vmovaps [rsp+0x60], xmm7
000076cd267d188b  vmovaps [rsp+0x70], xmm8
000076cd267d1891  vmovaps [rsp+0x80], xmm9
000076cd267d189a  vmovaps [rsp+0x90], xmm10
000076cd267d18a3  vmovaps [rsp+0xA0], xmm11
000076cd267d18ac  vmovaps [rsp+0xB0], xmm12
000076cd267d18b5  vmovaps [rsp+0xC0], xmm13
000076cd267d18be  vmovaps [rsp+0xD0], xmm14
000076cd267d18c7  vmovaps [rsp+0xE0], xmm15
000076cd267d18d0  sub rsp, 0x30
000076cd267d18d4  movaps [rsp], xmm2
000076cd267d18d8  movaps [rsp+0x10], xmm1
000076cd267d18dd  movaps [rsp+0x20], xmm14
000076cd267d18e3  lea rdi, [rsp]
000076cd267d18e7  mov esi, 0x00
000076cd267d18ec  mov rax, 0x56B8861A9530
000076cd267d18f6  call rax
000076cd267d18f8  movaps xmm2, [rsp]
000076cd267d18fc  add rsp, 0x30
000076cd267d1900  vmovaps xmm0, [rsp]
000076cd267d1905  vmovaps xmm1, [rsp+0x10]
000076cd267d190b  vmovaps xmm3, [rsp+0x20]
000076cd267d1911  vmovaps xmm4, [rsp+0x30]
000076cd267d1917  vmovaps xmm5, [rsp+0x40]
000076cd267d191d  vmovaps xmm6, [rsp+0x50]
000076cd267d1923  vmovaps xmm7, [rsp+0x60]
000076cd267d1929  vmovaps xmm8, [rsp+0x70]
000076cd267d192f  vmovaps xmm9, [rsp+0x80]
000076cd267d1938  vmovaps xmm10, [rsp+0x90]
000076cd267d1941  vmovaps xmm11, [rsp+0xA0]
000076cd267d194a  vmovaps xmm12, [rsp+0xB0]
000076cd267d1953  vmovaps xmm13, [rsp+0xC0]
000076cd267d195c  vmovaps xmm14, [rsp+0xD0]
000076cd267d1965  vmovaps xmm15, [rsp+0xE0]
000076cd267d196e  add rsp, 0xF0
000076cd267d1975  pop r11
000076cd267d1977  pop r10
000076cd267d1979  pop r9
000076cd267d197b  pop r8
000076cd267d197d  pop rsi
000076cd267d197e  pop rdi
000076cd267d197f  pop rdx
000076cd267d1980  pop rcx
000076cd267d1981  pop rax
000076cd267d1982  add rsp, 0x08
000076cd267d1986  jmp 0x000076CD267CF96D
000076cd267d198b  sub rsp, 0x08
000076cd267d198f  push rax
000076cd267d1990  push rcx
000076cd267d1991  push rdx
000076cd267d1992  push rdi
000076cd267d1993  push rsi
000076cd267d1994  push r8
000076cd267d1996  push r9
000076cd267d1998  push r10
000076cd267d199a  push r11
000076cd267d199c  sub rsp, 0xF0
000076cd267d19a3  vmovaps [rsp], xmm0
000076cd267d19a8  vmovaps [rsp+0x10], xmm1
000076cd267d19ae  vmovaps [rsp+0x20], xmm2
000076cd267d19b4  vmovaps [rsp+0x30], xmm3
000076cd267d19ba  vmovaps [rsp+0x40], xmm4
000076cd267d19c0  vmovaps [rsp+0x50], xmm5
000076cd267d19c6  vmovaps [rsp+0x60], xmm6
000076cd267d19cc  vmovaps [rsp+0x70], xmm7
000076cd267d19d2  vmovaps [rsp+0x80], xmm8
000076cd267d19db  vmovaps [rsp+0x90], xmm9
000076cd267d19e4  vmovaps [rsp+0xA0], xmm10
000076cd267d19ed  vmovaps [rsp+0xB0], xmm11
000076cd267d19f6  vmovaps [rsp+0xC0], xmm12
000076cd267d19ff  vmovaps [rsp+0xD0], xmm13
000076cd267d1a08  vmovaps [rsp+0xE0], xmm14
000076cd267d1a11  sub rsp, 0x30
000076cd267d1a15  movaps [rsp], xmm15
000076cd267d1a1a  movaps [rsp+0x10], xmm14
000076cd267d1a20  movaps [rsp+0x20], xmm1
000076cd267d1a25  lea rdi, [rsp]
000076cd267d1a29  mov esi, 0x00
000076cd267d1a2e  mov rax, 0x56B8861A9530
000076cd267d1a38  call rax
000076cd267d1a3a  movaps xmm15, [rsp]
000076cd267d1a3f  add rsp, 0x30
000076cd267d1a43  vmovaps xmm0, [rsp]
000076cd267d1a48  vmovaps xmm1, [rsp+0x10]
000076cd267d1a4e  vmovaps xmm2, [rsp+0x20]
000076cd267d1a54  vmovaps xmm3, [rsp+0x30]
000076cd267d1a5a  vmovaps xmm4, [rsp+0x40]
000076cd267d1a60  vmovaps xmm5, [rsp+0x50]
000076cd267d1a66  vmovaps xmm6, [rsp+0x60]
000076cd267d1a6c  vmovaps xmm7, [rsp+0x70]
000076cd267d1a72  vmovaps xmm8, [rsp+0x80]
000076cd267d1a7b  vmovaps xmm9, [rsp+0x90]
000076cd267d1a84  vmovaps xmm10, [rsp+0xA0]
000076cd267d1a8d  vmovaps xmm11, [rsp+0xB0]
000076cd267d1a96  vmovaps xmm12, [rsp+0xC0]
000076cd267d1a9f  vmovaps xmm13, [rsp+0xD0]
000076cd267d1aa8  vmovaps xmm14, [rsp+0xE0]
000076cd267d1ab1  add rsp, 0xF0
000076cd267d1ab8  pop r11
000076cd267d1aba  pop r10
000076cd267d1abc  pop r9
000076cd267d1abe  pop r8
000076cd267d1ac0  pop rsi
000076cd267d1ac1  pop rdi
000076cd267d1ac2  pop rdx
000076cd267d1ac3  pop rcx
000076cd267d1ac4  pop rax
000076cd267d1ac5  add rsp, 0x08
000076cd267d1ac9  jmp 0x000076CD267CF9E7
000076cd267d1ace  call 0x000076CD265FF430
000076cd267d1ad3  jmp 0x000076CD267CF9F4
000076cd267d1ad8  sub rsp, 0x08
000076cd267d1adc  push rax
000076cd267d1add  push rcx
000076cd267d1ade  push rdx
000076cd267d1adf  push rdi
000076cd267d1ae0  push rsi
000076cd267d1ae1  push r8
000076cd267d1ae3  push r9
000076cd267d1ae5  push r10
000076cd267d1ae7  push r11
000076cd267d1ae9  sub rsp, 0xF0
000076cd267d1af0  vmovaps [rsp], xmm0
000076cd267d1af5  vmovaps [rsp+0x10], xmm1
000076cd267d1afb  vmovaps [rsp+0x20], xmm2
000076cd267d1b01  vmovaps [rsp+0x30], xmm3
000076cd267d1b07  vmovaps [rsp+0x40], xmm4
000076cd267d1b0d  vmovaps [rsp+0x50], xmm5
000076cd267d1b13  vmovaps [rsp+0x60], xmm6
000076cd267d1b19  vmovaps [rsp+0x70], xmm7
000076cd267d1b1f  vmovaps [rsp+0x80], xmm8
000076cd267d1b28  vmovaps [rsp+0x90], xmm9
000076cd267d1b31  vmovaps [rsp+0xA0], xmm10
000076cd267d1b3a  vmovaps [rsp+0xB0], xmm11
000076cd267d1b43  vmovaps [rsp+0xC0], xmm12
000076cd267d1b4c  vmovaps [rsp+0xD0], xmm13
000076cd267d1b55  vmovaps [rsp+0xE0], xmm15
000076cd267d1b5e  sub rsp, 0x30
000076cd267d1b62  movaps [rsp], xmm14
000076cd267d1b67  movaps [rsp+0x10], xmm13
000076cd267d1b6d  movaps [rsp+0x20], xmm1
000076cd267d1b72  lea rdi, [rsp]
000076cd267d1b76  mov esi, 0x00
000076cd267d1b7b  mov rax, 0x56B8861A9530
000076cd267d1b85  call rax
000076cd267d1b87  movaps xmm14, [rsp]
000076cd267d1b8c  add rsp, 0x30
000076cd267d1b90  vmovaps xmm0, [rsp]
000076cd267d1b95  vmovaps xmm1, [rsp+0x10]
000076cd267d1b9b  vmovaps xmm2, [rsp+0x20]
000076cd267d1ba1  vmovaps xmm3, [rsp+0x30]
000076cd267d1ba7  vmovaps xmm4, [rsp+0x40]
000076cd267d1bad  vmovaps xmm5, [rsp+0x50]
000076cd267d1bb3  vmovaps xmm6, [rsp+0x60]
000076cd267d1bb9  vmovaps xmm7, [rsp+0x70]
000076cd267d1bbf  vmovaps xmm8, [rsp+0x80]
000076cd267d1bc8  vmovaps xmm9, [rsp+0x90]
000076cd267d1bd1  vmovaps xmm10, [rsp+0xA0]
000076cd267d1bda  vmovaps xmm11, [rsp+0xB0]
000076cd267d1be3  vmovaps xmm12, [rsp+0xC0]
000076cd267d1bec  vmovaps xmm13, [rsp+0xD0]
000076cd267d1bf5  vmovaps xmm15, [rsp+0xE0]
000076cd267d1bfe  add rsp, 0xF0
000076cd267d1c05  pop r11
000076cd267d1c07  pop r10
000076cd267d1c09  pop r9
000076cd267d1c0b  pop r8
000076cd267d1c0d  pop rsi
000076cd267d1c0e  pop rdi
000076cd267d1c0f  pop rdx
000076cd267d1c10  pop rcx
000076cd267d1c11  pop rax
000076cd267d1c12  add rsp, 0x08
000076cd267d1c16  jmp 0x000076CD267CFAAF
000076cd267d1c1b  sub rsp, 0x08
000076cd267d1c1f  push rax
000076cd267d1c20  push rcx
000076cd267d1c21  push rdx
000076cd267d1c22  push rdi
000076cd267d1c23  push rsi
000076cd267d1c24  push r8
000076cd267d1c26  push r9
000076cd267d1c28  push r10
000076cd267d1c2a  push r11
000076cd267d1c2c  sub rsp, 0xF0
000076cd267d1c33  vmovaps [rsp], xmm0
000076cd267d1c38  vmovaps [rsp+0x10], xmm1
000076cd267d1c3e  vmovaps [rsp+0x20], xmm2
000076cd267d1c44  vmovaps [rsp+0x30], xmm3
000076cd267d1c4a  vmovaps [rsp+0x40], xmm4
000076cd267d1c50  vmovaps [rsp+0x50], xmm5
000076cd267d1c56  vmovaps [rsp+0x60], xmm6
000076cd267d1c5c  vmovaps [rsp+0x70], xmm7
000076cd267d1c62  vmovaps [rsp+0x80], xmm8
000076cd267d1c6b  vmovaps [rsp+0x90], xmm9
000076cd267d1c74  vmovaps [rsp+0xA0], xmm10
000076cd267d1c7d  vmovaps [rsp+0xB0], xmm11
000076cd267d1c86  vmovaps [rsp+0xC0], xmm12
000076cd267d1c8f  vmovaps [rsp+0xD0], xmm13
000076cd267d1c98  vmovaps [rsp+0xE0], xmm14
000076cd267d1ca1  sub rsp, 0x30
000076cd267d1ca5  movaps [rsp], xmm15
000076cd267d1caa  movaps [rsp+0x10], xmm13
000076cd267d1cb0  movaps [rsp+0x20], xmm1
000076cd267d1cb5  lea rdi, [rsp]
000076cd267d1cb9  mov esi, 0x00
000076cd267d1cbe  mov rax, 0x56B8861A9530
000076cd267d1cc8  call rax
000076cd267d1cca  movaps xmm15, [rsp]
000076cd267d1ccf  add rsp, 0x30
000076cd267d1cd3  vmovaps xmm0, [rsp]
000076cd267d1cd8  vmovaps xmm1, [rsp+0x10]
000076cd267d1cde  vmovaps xmm2, [rsp+0x20]
000076cd267d1ce4  vmovaps xmm3, [rsp+0x30]
000076cd267d1cea  vmovaps xmm4, [rsp+0x40]
000076cd267d1cf0  vmovaps xmm5, [rsp+0x50]
000076cd267d1cf6  vmovaps xmm6, [rsp+0x60]
000076cd267d1cfc  vmovaps xmm7, [rsp+0x70]
000076cd267d1d02  vmovaps xmm8, [rsp+0x80]
000076cd267d1d0b  vmovaps xmm9, [rsp+0x90]
000076cd267d1d14  vmovaps xmm10, [rsp+0xA0]
000076cd267d1d1d  vmovaps xmm11, [rsp+0xB0]
000076cd267d1d26  vmovaps xmm12, [rsp+0xC0]
000076cd267d1d2f  vmovaps xmm13, [rsp+0xD0]
000076cd267d1d38  vmovaps xmm14, [rsp+0xE0]
000076cd267d1d41  add rsp, 0xF0
000076cd267d1d48  pop r11
000076cd267d1d4a  pop r10
000076cd267d1d4c  pop r9
000076cd267d1d4e  pop r8
000076cd267d1d50  pop rsi
000076cd267d1d51  pop rdi
000076cd267d1d52  pop rdx
000076cd267d1d53  pop rcx
000076cd267d1d54  pop rax
000076cd267d1d55  add rsp, 0x08
000076cd267d1d59  jmp 0x000076CD267CFAEB
000076cd267d1d5e  call 0x000076CD265FF430
000076cd267d1d63  jmp 0x000076CD267CFAF8
000076cd267d1d68  sub rsp, 0x08
000076cd267d1d6c  push rax
000076cd267d1d6d  push rcx
000076cd267d1d6e  push rdx
000076cd267d1d6f  push rdi
000076cd267d1d70  push rsi
000076cd267d1d71  push r8
000076cd267d1d73  push r9
000076cd267d1d75  push r10
000076cd267d1d77  push r11
000076cd267d1d79  sub rsp, 0xF0
000076cd267d1d80  vmovaps [rsp], xmm0
000076cd267d1d85  vmovaps [rsp+0x10], xmm1
000076cd267d1d8b  vmovaps [rsp+0x20], xmm2
000076cd267d1d91  vmovaps [rsp+0x30], xmm3
000076cd267d1d97  vmovaps [rsp+0x40], xmm4
000076cd267d1d9d  vmovaps [rsp+0x50], xmm5
000076cd267d1da3  vmovaps [rsp+0x60], xmm6
000076cd267d1da9  vmovaps [rsp+0x70], xmm7
000076cd267d1daf  vmovaps [rsp+0x80], xmm8
000076cd267d1db8  vmovaps [rsp+0x90], xmm9
000076cd267d1dc1  vmovaps [rsp+0xA0], xmm10
000076cd267d1dca  vmovaps [rsp+0xB0], xmm11
000076cd267d1dd3  vmovaps [rsp+0xC0], xmm12
000076cd267d1ddc  vmovaps [rsp+0xD0], xmm13
000076cd267d1de5  vmovaps [rsp+0xE0], xmm15
000076cd267d1dee  sub rsp, 0x30
000076cd267d1df2  movaps [rsp], xmm14
000076cd267d1df7  movaps [rsp+0x10], xmm13
000076cd267d1dfd  movaps [rsp+0x20], xmm2
000076cd267d1e02  lea rdi, [rsp]
000076cd267d1e06  mov esi, 0x00
000076cd267d1e0b  mov rax, 0x56B8861A9530
000076cd267d1e15  call rax
000076cd267d1e17  movaps xmm14, [rsp]
000076cd267d1e1c  add rsp, 0x30
000076cd267d1e20  vmovaps xmm0, [rsp]
000076cd267d1e25  vmovaps xmm1, [rsp+0x10]
000076cd267d1e2b  vmovaps xmm2, [rsp+0x20]
000076cd267d1e31  vmovaps xmm3, [rsp+0x30]
000076cd267d1e37  vmovaps xmm4, [rsp+0x40]
000076cd267d1e3d  vmovaps xmm5, [rsp+0x50]
000076cd267d1e43  vmovaps xmm6, [rsp+0x60]
000076cd267d1e49  vmovaps xmm7, [rsp+0x70]
000076cd267d1e4f  vmovaps xmm8, [rsp+0x80]
000076cd267d1e58  vmovaps xmm9, [rsp+0x90]
000076cd267d1e61  vmovaps xmm10, [rsp+0xA0]
000076cd267d1e6a  vmovaps xmm11, [rsp+0xB0]
000076cd267d1e73  vmovaps xmm12, [rsp+0xC0]
000076cd267d1e7c  vmovaps xmm13, [rsp+0xD0]
000076cd267d1e85  vmovaps xmm15, [rsp+0xE0]
000076cd267d1e8e  add rsp, 0xF0
000076cd267d1e95  pop r11
000076cd267d1e97  pop r10
000076cd267d1e99  pop r9
000076cd267d1e9b  pop r8
000076cd267d1e9d  pop rsi
000076cd267d1e9e  pop rdi
000076cd267d1e9f  pop rdx
000076cd267d1ea0  pop rcx
000076cd267d1ea1  pop rax
000076cd267d1ea2  add rsp, 0x08
000076cd267d1ea6  jmp 0x000076CD267CFB24
000076cd267d1eab  sub rsp, 0x08
000076cd267d1eaf  push rax
000076cd267d1eb0  push rcx
000076cd267d1eb1  push rdx
000076cd267d1eb2  push rdi
000076cd267d1eb3  push rsi
000076cd267d1eb4  push r8
000076cd267d1eb6  push r9
000076cd267d1eb8  push r10
000076cd267d1eba  push r11
000076cd267d1ebc  sub rsp, 0xF0
000076cd267d1ec3  vmovaps [rsp], xmm0
000076cd267d1ec8  vmovaps [rsp+0x10], xmm2
000076cd267d1ece  vmovaps [rsp+0x20], xmm3
000076cd267d1ed4  vmovaps [rsp+0x30], xmm4
000076cd267d1eda  vmovaps [rsp+0x40], xmm5
000076cd267d1ee0  vmovaps [rsp+0x50], xmm6
000076cd267d1ee6  vmovaps [rsp+0x60], xmm7
000076cd267d1eec  vmovaps [rsp+0x70], xmm8
000076cd267d1ef2  vmovaps [rsp+0x80], xmm9
000076cd267d1efb  vmovaps [rsp+0x90], xmm10
000076cd267d1f04  vmovaps [rsp+0xA0], xmm11
000076cd267d1f0d  vmovaps [rsp+0xB0], xmm12
000076cd267d1f16  vmovaps [rsp+0xC0], xmm13
000076cd267d1f1f  vmovaps [rsp+0xD0], xmm14
000076cd267d1f28  vmovaps [rsp+0xE0], xmm15
000076cd267d1f31  sub rsp, 0x30
000076cd267d1f35  movaps [rsp], xmm1
000076cd267d1f39  movaps [rsp+0x10], xmm13
000076cd267d1f3f  movaps [rsp+0x20], xmm2
000076cd267d1f44  lea rdi, [rsp]
000076cd267d1f48  mov esi, 0x00
000076cd267d1f4d  mov rax, 0x56B8861A9530
000076cd267d1f57  call rax
000076cd267d1f59  movaps xmm1, [rsp]
000076cd267d1f5d  add rsp, 0x30
000076cd267d1f61  vmovaps xmm0, [rsp]
000076cd267d1f66  vmovaps xmm2, [rsp+0x10]
000076cd267d1f6c  vmovaps xmm3, [rsp+0x20]
000076cd267d1f72  vmovaps xmm4, [rsp+0x30]
000076cd267d1f78  vmovaps xmm5, [rsp+0x40]
000076cd267d1f7e  vmovaps xmm6, [rsp+0x50]
000076cd267d1f84  vmovaps xmm7, [rsp+0x60]
000076cd267d1f8a  vmovaps xmm8, [rsp+0x70]
000076cd267d1f90  vmovaps xmm9, [rsp+0x80]
000076cd267d1f99  vmovaps xmm10, [rsp+0x90]
000076cd267d1fa2  vmovaps xmm11, [rsp+0xA0]
000076cd267d1fab  vmovaps xmm12, [rsp+0xB0]
000076cd267d1fb4  vmovaps xmm13, [rsp+0xC0]
000076cd267d1fbd  vmovaps xmm14, [rsp+0xD0]
000076cd267d1fc6  vmovaps xmm15, [rsp+0xE0]
000076cd267d1fcf  add rsp, 0xF0
000076cd267d1fd6  pop r11
000076cd267d1fd8  pop r10
000076cd267d1fda  pop r9
000076cd267d1fdc  pop r8
000076cd267d1fde  pop rsi
000076cd267d1fdf  pop rdi
000076cd267d1fe0  pop rdx
000076cd267d1fe1  pop rcx
000076cd267d1fe2  pop rax
000076cd267d1fe3  add rsp, 0x08
000076cd267d1fe7  jmp 0x000076CD267CFB52
000076cd267d1fec  sub rsp, 0x08
000076cd267d1ff0  push rax
000076cd267d1ff1  push rcx
000076cd267d1ff2  push rdx
000076cd267d1ff3  push rdi
000076cd267d1ff4  push rsi
000076cd267d1ff5  push r8
000076cd267d1ff7  push r9
000076cd267d1ff9  push r10
000076cd267d1ffb  push r11
000076cd267d1ffd  sub rsp, 0xF0
000076cd267d2004  vmovaps [rsp], xmm0
000076cd267d2009  vmovaps [rsp+0x10], xmm1
000076cd267d200f  vmovaps [rsp+0x20], xmm3
000076cd267d2015  vmovaps [rsp+0x30], xmm4
000076cd267d201b  vmovaps [rsp+0x40], xmm5
000076cd267d2021  vmovaps [rsp+0x50], xmm6
000076cd267d2027  vmovaps [rsp+0x60], xmm7
000076cd267d202d  vmovaps [rsp+0x70], xmm8
000076cd267d2033  vmovaps [rsp+0x80], xmm9
000076cd267d203c  vmovaps [rsp+0x90], xmm10
000076cd267d2045  vmovaps [rsp+0xA0], xmm11
000076cd267d204e  vmovaps [rsp+0xB0], xmm12
000076cd267d2057  vmovaps [rsp+0xC0], xmm13
000076cd267d2060  vmovaps [rsp+0xD0], xmm14
000076cd267d2069  vmovaps [rsp+0xE0], xmm15
000076cd267d2072  sub rsp, 0x30
000076cd267d2076  movaps [rsp], xmm2
000076cd267d207a  movaps [rsp+0x10], xmm1
000076cd267d207f  movaps [rsp+0x20], xmm13
000076cd267d2085  lea rdi, [rsp]
000076cd267d2089  mov esi, 0x00
000076cd267d208e  mov rax, 0x56B8861A9530
000076cd267d2098  call rax
000076cd267d209a  movaps xmm2, [rsp]
000076cd267d209e  add rsp, 0x30
000076cd267d20a2  vmovaps xmm0, [rsp]
000076cd267d20a7  vmovaps xmm1, [rsp+0x10]
000076cd267d20ad  vmovaps xmm3, [rsp+0x20]
000076cd267d20b3  vmovaps xmm4, [rsp+0x30]
000076cd267d20b9  vmovaps xmm5, [rsp+0x40]
000076cd267d20bf  vmovaps xmm6, [rsp+0x50]
000076cd267d20c5  vmovaps xmm7, [rsp+0x60]
000076cd267d20cb  vmovaps xmm8, [rsp+0x70]
000076cd267d20d1  vmovaps xmm9, [rsp+0x80]
000076cd267d20da  vmovaps xmm10, [rsp+0x90]
000076cd267d20e3  vmovaps xmm11, [rsp+0xA0]
000076cd267d20ec  vmovaps xmm12, [rsp+0xB0]
000076cd267d20f5  vmovaps xmm13, [rsp+0xC0]
000076cd267d20fe  vmovaps xmm14, [rsp+0xD0]
000076cd267d2107  vmovaps xmm15, [rsp+0xE0]
000076cd267d2110  add rsp, 0xF0
000076cd267d2117  pop r11
000076cd267d2119  pop r10
000076cd267d211b  pop r9
000076cd267d211d  pop r8
000076cd267d211f  pop rsi
000076cd267d2120  pop rdi
000076cd267d2121  pop rdx
000076cd267d2122  pop rcx
000076cd267d2123  pop rax
000076cd267d2124  add rsp, 0x08
000076cd267d2128  jmp 0x000076CD267CFBAB
000076cd267d212d  call 0x000076CD265FF430
000076cd267d2132  jmp 0x000076CD267CFBB8
000076cd267d2137  sub rsp, 0x08
000076cd267d213b  push rax
000076cd267d213c  push rcx
000076cd267d213d  push rdx
000076cd267d213e  push rdi
000076cd267d213f  push rsi
000076cd267d2140  push r8
000076cd267d2142  push r9
000076cd267d2144  push r10
000076cd267d2146  push r11
000076cd267d2148  sub rsp, 0xF0
000076cd267d214f  vmovaps [rsp], xmm0
000076cd267d2154  vmovaps [rsp+0x10], xmm1
000076cd267d215a  vmovaps [rsp+0x20], xmm2
000076cd267d2160  vmovaps [rsp+0x30], xmm3
000076cd267d2166  vmovaps [rsp+0x40], xmm4
000076cd267d216c  vmovaps [rsp+0x50], xmm5
000076cd267d2172  vmovaps [rsp+0x60], xmm6
000076cd267d2178  vmovaps [rsp+0x70], xmm7
000076cd267d217e  vmovaps [rsp+0x80], xmm8
000076cd267d2187  vmovaps [rsp+0x90], xmm9
000076cd267d2190  vmovaps [rsp+0xA0], xmm10
000076cd267d2199  vmovaps [rsp+0xB0], xmm11
000076cd267d21a2  vmovaps [rsp+0xC0], xmm12
000076cd267d21ab  vmovaps [rsp+0xD0], xmm13
000076cd267d21b4  vmovaps [rsp+0xE0], xmm14
000076cd267d21bd  sub rsp, 0x30
000076cd267d21c1  movaps [rsp], xmm15
000076cd267d21c6  movaps [rsp+0x10], xmm13
000076cd267d21cc  movaps [rsp+0x20], xmm1
000076cd267d21d1  lea rdi, [rsp]
000076cd267d21d5  mov esi, 0x00
000076cd267d21da  mov rax, 0x56B8861A9530
000076cd267d21e4  call rax
000076cd267d21e6  movaps xmm15, [rsp]
000076cd267d21eb  add rsp, 0x30
000076cd267d21ef  vmovaps xmm0, [rsp]
000076cd267d21f4  vmovaps xmm1, [rsp+0x10]
000076cd267d21fa  vmovaps xmm2, [rsp+0x20]
000076cd267d2200  vmovaps xmm3, [rsp+0x30]
000076cd267d2206  vmovaps xmm4, [rsp+0x40]
000076cd267d220c  vmovaps xmm5, [rsp+0x50]
000076cd267d2212  vmovaps xmm6, [rsp+0x60]
000076cd267d2218  vmovaps xmm7, [rsp+0x70]
000076cd267d221e  vmovaps xmm8, [rsp+0x80]
000076cd267d2227  vmovaps xmm9, [rsp+0x90]
000076cd267d2230  vmovaps xmm10, [rsp+0xA0]
000076cd267d2239  vmovaps xmm11, [rsp+0xB0]
000076cd267d2242  vmovaps xmm12, [rsp+0xC0]
000076cd267d224b  vmovaps xmm13, [rsp+0xD0]
000076cd267d2254  vmovaps xmm14, [rsp+0xE0]
000076cd267d225d  add rsp, 0xF0
000076cd267d2264  pop r11
000076cd267d2266  pop r10
000076cd267d2268  pop r9
000076cd267d226a  pop r8
000076cd267d226c  pop rsi
000076cd267d226d  pop rdi
000076cd267d226e  pop rdx
000076cd267d226f  pop rcx
000076cd267d2270  pop rax
000076cd267d2271  add rsp, 0x08
000076cd267d2275  jmp 0x000076CD267CFBF7
000076cd267d227a  sub rsp, 0x08
000076cd267d227e  push rax
000076cd267d227f  push rcx
000076cd267d2280  push rdx
000076cd267d2281  push rdi
000076cd267d2282  push rsi
000076cd267d2283  push r8
000076cd267d2285  push r9
000076cd267d2287  push r10
000076cd267d2289  push r11
000076cd267d228b  sub rsp, 0xF0
000076cd267d2292  vmovaps [rsp], xmm0
000076cd267d2297  vmovaps [rsp+0x10], xmm1
000076cd267d229d  vmovaps [rsp+0x20], xmm2
000076cd267d22a3  vmovaps [rsp+0x30], xmm3
000076cd267d22a9  vmovaps [rsp+0x40], xmm4
000076cd267d22af  vmovaps [rsp+0x50], xmm5
000076cd267d22b5  vmovaps [rsp+0x60], xmm6
000076cd267d22bb  vmovaps [rsp+0x70], xmm7
000076cd267d22c1  vmovaps [rsp+0x80], xmm8
000076cd267d22ca  vmovaps [rsp+0x90], xmm9
000076cd267d22d3  vmovaps [rsp+0xA0], xmm10
000076cd267d22dc  vmovaps [rsp+0xB0], xmm11
000076cd267d22e5  vmovaps [rsp+0xC0], xmm12
000076cd267d22ee  vmovaps [rsp+0xD0], xmm13
000076cd267d22f7  vmovaps [rsp+0xE0], xmm15
000076cd267d2300  sub rsp, 0x30
000076cd267d2304  movaps [rsp], xmm14
000076cd267d2309  movaps [rsp+0x10], xmm11
000076cd267d230f  movaps [rsp+0x20], xmm1
000076cd267d2314  lea rdi, [rsp]
000076cd267d2318  mov esi, 0x00
000076cd267d231d  mov rax, 0x56B8861A9530
000076cd267d2327  call rax
000076cd267d2329  movaps xmm14, [rsp]
000076cd267d232e  add rsp, 0x30
000076cd267d2332  vmovaps xmm0, [rsp]
000076cd267d2337  vmovaps xmm1, [rsp+0x10]
000076cd267d233d  vmovaps xmm2, [rsp+0x20]
000076cd267d2343  vmovaps xmm3, [rsp+0x30]
000076cd267d2349  vmovaps xmm4, [rsp+0x40]
000076cd267d234f  vmovaps xmm5, [rsp+0x50]
000076cd267d2355  vmovaps xmm6, [rsp+0x60]
000076cd267d235b  vmovaps xmm7, [rsp+0x70]
000076cd267d2361  vmovaps xmm8, [rsp+0x80]
000076cd267d236a  vmovaps xmm9, [rsp+0x90]
000076cd267d2373  vmovaps xmm10, [rsp+0xA0]
000076cd267d237c  vmovaps xmm11, [rsp+0xB0]
000076cd267d2385  vmovaps xmm12, [rsp+0xC0]
000076cd267d238e  vmovaps xmm13, [rsp+0xD0]
000076cd267d2397  vmovaps xmm15, [rsp+0xE0]
000076cd267d23a0  add rsp, 0xF0
000076cd267d23a7  pop r11
000076cd267d23a9  pop r10
000076cd267d23ab  pop r9
000076cd267d23ad  pop r8
000076cd267d23af  pop rsi
000076cd267d23b0  pop rdi
000076cd267d23b1  pop rdx
000076cd267d23b2  pop rcx
000076cd267d23b3  pop rax
000076cd267d23b4  add rsp, 0x08
000076cd267d23b8  jmp 0x000076CD267CFC21
000076cd267d23bd  sub rsp, 0x08
000076cd267d23c1  push rax
000076cd267d23c2  push rcx
000076cd267d23c3  push rdx
000076cd267d23c4  push rdi
000076cd267d23c5  push rsi
000076cd267d23c6  push r8
000076cd267d23c8  push r9
000076cd267d23ca  push r10
000076cd267d23cc  push r11
000076cd267d23ce  sub rsp, 0xF0
000076cd267d23d5  vmovaps [rsp], xmm0
000076cd267d23da  vmovaps [rsp+0x10], xmm1
000076cd267d23e0  vmovaps [rsp+0x20], xmm2
000076cd267d23e6  vmovaps [rsp+0x30], xmm3
000076cd267d23ec  vmovaps [rsp+0x40], xmm4
000076cd267d23f2  vmovaps [rsp+0x50], xmm5
000076cd267d23f8  vmovaps [rsp+0x60], xmm6
000076cd267d23fe  vmovaps [rsp+0x70], xmm7
000076cd267d2404  vmovaps [rsp+0x80], xmm8
000076cd267d240d  vmovaps [rsp+0x90], xmm9
000076cd267d2416  vmovaps [rsp+0xA0], xmm10
000076cd267d241f  vmovaps [rsp+0xB0], xmm11
000076cd267d2428  vmovaps [rsp+0xC0], xmm12
000076cd267d2431  vmovaps [rsp+0xD0], xmm14
000076cd267d243a  vmovaps [rsp+0xE0], xmm15
000076cd267d2443  sub rsp, 0x30
000076cd267d2447  movaps [rsp], xmm13
000076cd267d244c  movaps [rsp+0x10], xmm11
000076cd267d2452  movaps [rsp+0x20], xmm1
000076cd267d2457  lea rdi, [rsp]
000076cd267d245b  mov esi, 0x00
000076cd267d2460  mov rax, 0x56B8861A9530
000076cd267d246a  call rax
000076cd267d246c  movaps xmm13, [rsp]
000076cd267d2471  add rsp, 0x30
000076cd267d2475  vmovaps xmm0, [rsp]
000076cd267d247a  vmovaps xmm1, [rsp+0x10]
000076cd267d2480  vmovaps xmm2, [rsp+0x20]
000076cd267d2486  vmovaps xmm3, [rsp+0x30]
000076cd267d248c  vmovaps xmm4, [rsp+0x40]
000076cd267d2492  vmovaps xmm5, [rsp+0x50]
000076cd267d2498  vmovaps xmm6, [rsp+0x60]
000076cd267d249e  vmovaps xmm7, [rsp+0x70]
000076cd267d24a4  vmovaps xmm8, [rsp+0x80]
000076cd267d24ad  vmovaps xmm9, [rsp+0x90]
000076cd267d24b6  vmovaps xmm10, [rsp+0xA0]
000076cd267d24bf  vmovaps xmm11, [rsp+0xB0]
000076cd267d24c8  vmovaps xmm12, [rsp+0xC0]
000076cd267d24d1  vmovaps xmm14, [rsp+0xD0]
000076cd267d24da  vmovaps xmm15, [rsp+0xE0]
000076cd267d24e3  add rsp, 0xF0
000076cd267d24ea  pop r11
000076cd267d24ec  pop r10
000076cd267d24ee  pop r9
000076cd267d24f0  pop r8
000076cd267d24f2  pop rsi
000076cd267d24f3  pop rdi
000076cd267d24f4  pop rdx
000076cd267d24f5  pop rcx
000076cd267d24f6  pop rax
000076cd267d24f7  add rsp, 0x08
000076cd267d24fb  jmp 0x000076CD267CFC76
000076cd267d2500  call 0x000076CD265FF430
000076cd267d2505  jmp 0x000076CD267CFC83
000076cd267d250a  sub rsp, 0x08
000076cd267d250e  push rax
000076cd267d250f  push rcx
000076cd267d2510  push rdx
000076cd267d2511  push rdi
000076cd267d2512  push rsi
000076cd267d2513  push r8
000076cd267d2515  push r9
000076cd267d2517  push r10
000076cd267d2519  push r11
000076cd267d251b  sub rsp, 0xF0
000076cd267d2522  vmovaps [rsp], xmm0
000076cd267d2527  vmovaps [rsp+0x10], xmm1
000076cd267d252d  vmovaps [rsp+0x20], xmm2
000076cd267d2533  vmovaps [rsp+0x30], xmm3
000076cd267d2539  vmovaps [rsp+0x40], xmm4
000076cd267d253f  vmovaps [rsp+0x50], xmm5
000076cd267d2545  vmovaps [rsp+0x60], xmm6
000076cd267d254b  vmovaps [rsp+0x70], xmm7
000076cd267d2551  vmovaps [rsp+0x80], xmm8
000076cd267d255a  vmovaps [rsp+0x90], xmm9
000076cd267d2563  vmovaps [rsp+0xA0], xmm10
000076cd267d256c  vmovaps [rsp+0xB0], xmm11
000076cd267d2575  vmovaps [rsp+0xC0], xmm12
000076cd267d257e  vmovaps [rsp+0xD0], xmm13
000076cd267d2587  vmovaps [rsp+0xE0], xmm14
000076cd267d2590  sub rsp, 0x30
000076cd267d2594  movaps [rsp], xmm15
000076cd267d2599  movaps [rsp+0x10], xmm11
000076cd267d259f  movaps [rsp+0x20], xmm1
000076cd267d25a4  lea rdi, [rsp]
000076cd267d25a8  mov esi, 0x00
000076cd267d25ad  mov rax, 0x56B8861A9530
000076cd267d25b7  call rax
000076cd267d25b9  movaps xmm15, [rsp]
000076cd267d25be  add rsp, 0x30
000076cd267d25c2  vmovaps xmm0, [rsp]
000076cd267d25c7  vmovaps xmm1, [rsp+0x10]
000076cd267d25cd  vmovaps xmm2, [rsp+0x20]
000076cd267d25d3  vmovaps xmm3, [rsp+0x30]
000076cd267d25d9  vmovaps xmm4, [rsp+0x40]
000076cd267d25df  vmovaps xmm5, [rsp+0x50]
000076cd267d25e5  vmovaps xmm6, [rsp+0x60]
000076cd267d25eb  vmovaps xmm7, [rsp+0x70]
000076cd267d25f1  vmovaps xmm8, [rsp+0x80]
000076cd267d25fa  vmovaps xmm9, [rsp+0x90]
000076cd267d2603  vmovaps xmm10, [rsp+0xA0]
000076cd267d260c  vmovaps xmm11, [rsp+0xB0]
000076cd267d2615  vmovaps xmm12, [rsp+0xC0]
000076cd267d261e  vmovaps xmm13, [rsp+0xD0]
000076cd267d2627  vmovaps xmm14, [rsp+0xE0]
000076cd267d2630  add rsp, 0xF0
000076cd267d2637  pop r11
000076cd267d2639  pop r10
000076cd267d263b  pop r9
000076cd267d263d  pop r8
000076cd267d263f  pop rsi
000076cd267d2640  pop rdi
000076cd267d2641  pop rdx
000076cd267d2642  pop rcx
000076cd267d2643  pop rax
000076cd267d2644  add rsp, 0x08
000076cd267d2648  jmp 0x000076CD267CFCBC
000076cd267d264d  sub rsp, 0x08
000076cd267d2651  push rax
000076cd267d2652  push rcx
000076cd267d2653  push rdx
000076cd267d2654  push rdi
000076cd267d2655  push rsi
000076cd267d2656  push r8
000076cd267d2658  push r9
000076cd267d265a  push r10
000076cd267d265c  push r11
000076cd267d265e  sub rsp, 0xF0
000076cd267d2665  vmovaps [rsp], xmm0
000076cd267d266a  vmovaps [rsp+0x10], xmm1
000076cd267d2670  vmovaps [rsp+0x20], xmm2
000076cd267d2676  vmovaps [rsp+0x30], xmm3
000076cd267d267c  vmovaps [rsp+0x40], xmm4
000076cd267d2682  vmovaps [rsp+0x50], xmm5
000076cd267d2688  vmovaps [rsp+0x60], xmm6
000076cd267d268e  vmovaps [rsp+0x70], xmm7
000076cd267d2694  vmovaps [rsp+0x80], xmm8
000076cd267d269d  vmovaps [rsp+0x90], xmm9
000076cd267d26a6  vmovaps [rsp+0xA0], xmm10
000076cd267d26af  vmovaps [rsp+0xB0], xmm12
000076cd267d26b8  vmovaps [rsp+0xC0], xmm13
000076cd267d26c1  vmovaps [rsp+0xD0], xmm14
000076cd267d26ca  vmovaps [rsp+0xE0], xmm15
000076cd267d26d3  sub rsp, 0x30
000076cd267d26d7  movaps [rsp], xmm11
000076cd267d26dc  movaps [rsp+0x10], xmm6
000076cd267d26e1  movaps [rsp+0x20], xmm14
000076cd267d26e7  lea rdi, [rsp]
000076cd267d26eb  mov esi, 0x00
000076cd267d26f0  mov rax, 0x56B8861A9530
000076cd267d26fa  call rax
000076cd267d26fc  movaps xmm11, [rsp]
000076cd267d2701  add rsp, 0x30
000076cd267d2705  vmovaps xmm0, [rsp]
000076cd267d270a  vmovaps xmm1, [rsp+0x10]
000076cd267d2710  vmovaps xmm2, [rsp+0x20]
000076cd267d2716  vmovaps xmm3, [rsp+0x30]
000076cd267d271c  vmovaps xmm4, [rsp+0x40]
000076cd267d2722  vmovaps xmm5, [rsp+0x50]
000076cd267d2728  vmovaps xmm6, [rsp+0x60]
000076cd267d272e  vmovaps xmm7, [rsp+0x70]
000076cd267d2734  vmovaps xmm8, [rsp+0x80]
000076cd267d273d  vmovaps xmm9, [rsp+0x90]
000076cd267d2746  vmovaps xmm10, [rsp+0xA0]
000076cd267d274f  vmovaps xmm12, [rsp+0xB0]
000076cd267d2758  vmovaps xmm13, [rsp+0xC0]
000076cd267d2761  vmovaps xmm14, [rsp+0xD0]
000076cd267d276a  vmovaps xmm15, [rsp+0xE0]
000076cd267d2773  add rsp, 0xF0
000076cd267d277a  pop r11
000076cd267d277c  pop r10
000076cd267d277e  pop r9
000076cd267d2780  pop r8
000076cd267d2782  pop rsi
000076cd267d2783  pop rdi
000076cd267d2784  pop rdx
000076cd267d2785  pop rcx
000076cd267d2786  pop rax
000076cd267d2787  add rsp, 0x08
000076cd267d278b  jmp 0x000076CD267CFD34
000076cd267d2790  call 0x000076CD265FF430
000076cd267d2795  jmp 0x000076CD267CFD3E
000076cd267d279a  sub rsp, 0x08
000076cd267d279e  push rax
000076cd267d279f  push rcx
000076cd267d27a0  push rdx
000076cd267d27a1  push rdi
000076cd267d27a2  push rsi
000076cd267d27a3  push r8
000076cd267d27a5  push r9
000076cd267d27a7  push r10
000076cd267d27a9  push r11
000076cd267d27ab  sub rsp, 0xF0
000076cd267d27b2  vmovaps [rsp], xmm0
000076cd267d27b7  vmovaps [rsp+0x10], xmm1
000076cd267d27bd  vmovaps [rsp+0x20], xmm2
000076cd267d27c3  vmovaps [rsp+0x30], xmm3
000076cd267d27c9  vmovaps [rsp+0x40], xmm4
000076cd267d27cf  vmovaps [rsp+0x50], xmm5
000076cd267d27d5  vmovaps [rsp+0x60], xmm6
000076cd267d27db  vmovaps [rsp+0x70], xmm7
000076cd267d27e1  vmovaps [rsp+0x80], xmm8
000076cd267d27ea  vmovaps [rsp+0x90], xmm9
000076cd267d27f3  vmovaps [rsp+0xA0], xmm10
000076cd267d27fc  vmovaps [rsp+0xB0], xmm11
000076cd267d2805  vmovaps [rsp+0xC0], xmm12
000076cd267d280e  vmovaps [rsp+0xD0], xmm13
000076cd267d2817  vmovaps [rsp+0xE0], xmm15
000076cd267d2820  sub rsp, 0x30
000076cd267d2824  movaps [rsp], xmm14
000076cd267d2829  movaps [rsp+0x10], xmm6
000076cd267d282e  movaps [rsp+0x20], xmm2
000076cd267d2833  lea rdi, [rsp]
000076cd267d2837  mov esi, 0x00
000076cd267d283c  mov rax, 0x56B8861A9530
000076cd267d2846  call rax
000076cd267d2848  movaps xmm14, [rsp]
000076cd267d284d  add rsp, 0x30
000076cd267d2851  vmovaps xmm0, [rsp]
000076cd267d2856  vmovaps xmm1, [rsp+0x10]
000076cd267d285c  vmovaps xmm2, [rsp+0x20]
000076cd267d2862  vmovaps xmm3, [rsp+0x30]
000076cd267d2868  vmovaps xmm4, [rsp+0x40]
000076cd267d286e  vmovaps xmm5, [rsp+0x50]
000076cd267d2874  vmovaps xmm6, [rsp+0x60]
000076cd267d287a  vmovaps xmm7, [rsp+0x70]
000076cd267d2880  vmovaps xmm8, [rsp+0x80]
000076cd267d2889  vmovaps xmm9, [rsp+0x90]
000076cd267d2892  vmovaps xmm10, [rsp+0xA0]
000076cd267d289b  vmovaps xmm11, [rsp+0xB0]
000076cd267d28a4  vmovaps xmm12, [rsp+0xC0]
000076cd267d28ad  vmovaps xmm13, [rsp+0xD0]
000076cd267d28b6  vmovaps xmm15, [rsp+0xE0]
000076cd267d28bf  add rsp, 0xF0
000076cd267d28c6  pop r11
000076cd267d28c8  pop r10
000076cd267d28ca  pop r9
000076cd267d28cc  pop r8
000076cd267d28ce  pop rsi
000076cd267d28cf  pop rdi
000076cd267d28d0  pop rdx
000076cd267d28d1  pop rcx
000076cd267d28d2  pop rax
000076cd267d28d3  add rsp, 0x08
000076cd267d28d7  jmp 0x000076CD267CFD72
000076cd267d28dc  sub rsp, 0x08
000076cd267d28e0  push rax
000076cd267d28e1  push rcx
000076cd267d28e2  push rdx
000076cd267d28e3  push rdi
000076cd267d28e4  push rsi
000076cd267d28e5  push r8
000076cd267d28e7  push r9
000076cd267d28e9  push r10
000076cd267d28eb  push r11
000076cd267d28ed  sub rsp, 0xF0
000076cd267d28f4  vmovaps [rsp], xmm0
000076cd267d28f9  vmovaps [rsp+0x10], xmm1
000076cd267d28ff  vmovaps [rsp+0x20], xmm2
000076cd267d2905  vmovaps [rsp+0x30], xmm3
000076cd267d290b  vmovaps [rsp+0x40], xmm4
000076cd267d2911  vmovaps [rsp+0x50], xmm5
000076cd267d2917  vmovaps [rsp+0x60], xmm7
000076cd267d291d  vmovaps [rsp+0x70], xmm8
000076cd267d2923  vmovaps [rsp+0x80], xmm9
000076cd267d292c  vmovaps [rsp+0x90], xmm10
000076cd267d2935  vmovaps [rsp+0xA0], xmm11
000076cd267d293e  vmovaps [rsp+0xB0], xmm12
000076cd267d2947  vmovaps [rsp+0xC0], xmm13
000076cd267d2950  vmovaps [rsp+0xD0], xmm14
000076cd267d2959  vmovaps [rsp+0xE0], xmm15
000076cd267d2962  sub rsp, 0x30
000076cd267d2966  movaps [rsp], xmm6
000076cd267d296a  movaps [rsp+0x10], xmm5
000076cd267d296f  movaps [rsp+0x20], xmm1
000076cd267d2974  lea rdi, [rsp]
000076cd267d2978  mov esi, 0x00
000076cd267d297d  mov rax, 0x56B8861A9530
000076cd267d2987  call rax
000076cd267d2989  movaps xmm6, [rsp]
000076cd267d298d  add rsp, 0x30
000076cd267d2991  vmovaps xmm0, [rsp]
000076cd267d2996  vmovaps xmm1, [rsp+0x10]
000076cd267d299c  vmovaps xmm2, [rsp+0x20]
000076cd267d29a2  vmovaps xmm3, [rsp+0x30]
000076cd267d29a8  vmovaps xmm4, [rsp+0x40]
000076cd267d29ae  vmovaps xmm5, [rsp+0x50]
000076cd267d29b4  vmovaps xmm7, [rsp+0x60]
000076cd267d29ba  vmovaps xmm8, [rsp+0x70]
000076cd267d29c0  vmovaps xmm9, [rsp+0x80]
000076cd267d29c9  vmovaps xmm10, [rsp+0x90]
000076cd267d29d2  vmovaps xmm11, [rsp+0xA0]
000076cd267d29db  vmovaps xmm12, [rsp+0xB0]
000076cd267d29e4  vmovaps xmm13, [rsp+0xC0]
000076cd267d29ed  vmovaps xmm14, [rsp+0xD0]
000076cd267d29f6  vmovaps xmm15, [rsp+0xE0]
000076cd267d29ff  add rsp, 0xF0
000076cd267d2a06  pop r11
000076cd267d2a08  pop r10
000076cd267d2a0a  pop r9
000076cd267d2a0c  pop r8
000076cd267d2a0e  pop rsi
000076cd267d2a0f  pop rdi
000076cd267d2a10  pop rdx
000076cd267d2a11  pop rcx
000076cd267d2a12  pop rax
000076cd267d2a13  add rsp, 0x08
000076cd267d2a17  jmp 0x000076CD267CFD98
000076cd267d2a1c  sub rsp, 0x08
000076cd267d2a20  push rax
000076cd267d2a21  push rcx
000076cd267d2a22  push rdx
000076cd267d2a23  push rdi
000076cd267d2a24  push rsi
000076cd267d2a25  push r8
000076cd267d2a27  push r9
000076cd267d2a29  push r10
000076cd267d2a2b  push r11
000076cd267d2a2d  sub rsp, 0xF0
000076cd267d2a34  vmovaps [rsp], xmm0
000076cd267d2a39  vmovaps [rsp+0x10], xmm2
000076cd267d2a3f  vmovaps [rsp+0x20], xmm3
000076cd267d2a45  vmovaps [rsp+0x30], xmm4
000076cd267d2a4b  vmovaps [rsp+0x40], xmm5
000076cd267d2a51  vmovaps [rsp+0x50], xmm6
000076cd267d2a57  vmovaps [rsp+0x60], xmm7
000076cd267d2a5d  vmovaps [rsp+0x70], xmm8
000076cd267d2a63  vmovaps [rsp+0x80], xmm9
000076cd267d2a6c  vmovaps [rsp+0x90], xmm10
000076cd267d2a75  vmovaps [rsp+0xA0], xmm11
000076cd267d2a7e  vmovaps [rsp+0xB0], xmm12
000076cd267d2a87  vmovaps [rsp+0xC0], xmm13
000076cd267d2a90  vmovaps [rsp+0xD0], xmm14
000076cd267d2a99  vmovaps [rsp+0xE0], xmm15
000076cd267d2aa2  sub rsp, 0x30
000076cd267d2aa6  movaps [rsp], xmm1
000076cd267d2aaa  movaps [rsp+0x10], xmm5
000076cd267d2aaf  movaps [rsp+0x20], xmm13
000076cd267d2ab5  lea rdi, [rsp]
000076cd267d2ab9  mov esi, 0x00
000076cd267d2abe  mov rax, 0x56B8861A9530
000076cd267d2ac8  call rax
000076cd267d2aca  movaps xmm1, [rsp]
000076cd267d2ace  add rsp, 0x30
000076cd267d2ad2  vmovaps xmm0, [rsp]
000076cd267d2ad7  vmovaps xmm2, [rsp+0x10]
000076cd267d2add  vmovaps xmm3, [rsp+0x20]
000076cd267d2ae3  vmovaps xmm4, [rsp+0x30]
000076cd267d2ae9  vmovaps xmm5, [rsp+0x40]
000076cd267d2aef  vmovaps xmm6, [rsp+0x50]
000076cd267d2af5  vmovaps xmm7, [rsp+0x60]
000076cd267d2afb  vmovaps xmm8, [rsp+0x70]
000076cd267d2b01  vmovaps xmm9, [rsp+0x80]
000076cd267d2b0a  vmovaps xmm10, [rsp+0x90]
000076cd267d2b13  vmovaps xmm11, [rsp+0xA0]
000076cd267d2b1c  vmovaps xmm12, [rsp+0xB0]
000076cd267d2b25  vmovaps xmm13, [rsp+0xC0]
000076cd267d2b2e  vmovaps xmm14, [rsp+0xD0]
000076cd267d2b37  vmovaps xmm15, [rsp+0xE0]
000076cd267d2b40  add rsp, 0xF0
000076cd267d2b47  pop r11
000076cd267d2b49  pop r10
000076cd267d2b4b  pop r9
000076cd267d2b4d  pop r8
000076cd267d2b4f  pop rsi
000076cd267d2b50  pop rdi
000076cd267d2b51  pop rdx
000076cd267d2b52  pop rcx
000076cd267d2b53  pop rax
000076cd267d2b54  add rsp, 0x08
000076cd267d2b58  jmp 0x000076CD267CFDB6
000076cd267d2b5d  sub rsp, 0x08
000076cd267d2b61  push rax
000076cd267d2b62  push rcx
000076cd267d2b63  push rdx
000076cd267d2b64  push rdi
000076cd267d2b65  push rsi
000076cd267d2b66  push r8
000076cd267d2b68  push r9
000076cd267d2b6a  push r10
000076cd267d2b6c  push r11
000076cd267d2b6e  sub rsp, 0xF0
000076cd267d2b75  vmovaps [rsp], xmm0
000076cd267d2b7a  vmovaps [rsp+0x10], xmm1
000076cd267d2b80  vmovaps [rsp+0x20], xmm2
000076cd267d2b86  vmovaps [rsp+0x30], xmm3
000076cd267d2b8c  vmovaps [rsp+0x40], xmm4
000076cd267d2b92  vmovaps [rsp+0x50], xmm6
000076cd267d2b98  vmovaps [rsp+0x60], xmm7
000076cd267d2b9e  vmovaps [rsp+0x70], xmm8
000076cd267d2ba4  vmovaps [rsp+0x80], xmm9
000076cd267d2bad  vmovaps [rsp+0x90], xmm10
000076cd267d2bb6  vmovaps [rsp+0xA0], xmm11
000076cd267d2bbf  vmovaps [rsp+0xB0], xmm12
000076cd267d2bc8  vmovaps [rsp+0xC0], xmm13
000076cd267d2bd1  vmovaps [rsp+0xD0], xmm14
000076cd267d2bda  vmovaps [rsp+0xE0], xmm15
000076cd267d2be3  sub rsp, 0x30
000076cd267d2be7  movaps [rsp], xmm5
000076cd267d2beb  movaps [rsp+0x10], xmm2
000076cd267d2bf0  movaps [rsp+0x20], xmm13
000076cd267d2bf6  lea rdi, [rsp]
000076cd267d2bfa  mov esi, 0x00
000076cd267d2bff  mov rax, 0x56B8861A9530
000076cd267d2c09  call rax
000076cd267d2c0b  movaps xmm5, [rsp]
000076cd267d2c0f  add rsp, 0x30
000076cd267d2c13  vmovaps xmm0, [rsp]
000076cd267d2c18  vmovaps xmm1, [rsp+0x10]
000076cd267d2c1e  vmovaps xmm2, [rsp+0x20]
000076cd267d2c24  vmovaps xmm3, [rsp+0x30]
000076cd267d2c2a  vmovaps xmm4, [rsp+0x40]
000076cd267d2c30  vmovaps xmm6, [rsp+0x50]
000076cd267d2c36  vmovaps xmm7, [rsp+0x60]
000076cd267d2c3c  vmovaps xmm8, [rsp+0x70]
000076cd267d2c42  vmovaps xmm9, [rsp+0x80]
000076cd267d2c4b  vmovaps xmm10, [rsp+0x90]
000076cd267d2c54  vmovaps xmm11, [rsp+0xA0]
000076cd267d2c5d  vmovaps xmm12, [rsp+0xB0]
000076cd267d2c66  vmovaps xmm13, [rsp+0xC0]
000076cd267d2c6f  vmovaps xmm14, [rsp+0xD0]
000076cd267d2c78  vmovaps xmm15, [rsp+0xE0]
000076cd267d2c81  add rsp, 0xF0
000076cd267d2c88  pop r11
000076cd267d2c8a  pop r10
000076cd267d2c8c  pop r9
000076cd267d2c8e  pop r8
000076cd267d2c90  pop rsi
000076cd267d2c91  pop rdi
000076cd267d2c92  pop rdx
000076cd267d2c93  pop rcx
000076cd267d2c94  pop rax
000076cd267d2c95  add rsp, 0x08
000076cd267d2c99  jmp 0x000076CD267CFDEC
000076cd267d2c9e  sub rsp, 0x08
000076cd267d2ca2  push rax
000076cd267d2ca3  push rcx
000076cd267d2ca4  push rdx
000076cd267d2ca5  push rdi
000076cd267d2ca6  push rsi
000076cd267d2ca7  push r8
000076cd267d2ca9  push r9
000076cd267d2cab  push r10
000076cd267d2cad  push r11
000076cd267d2caf  sub rsp, 0xF0
000076cd267d2cb6  vmovaps [rsp], xmm0
000076cd267d2cbb  vmovaps [rsp+0x10], xmm1
000076cd267d2cc1  vmovaps [rsp+0x20], xmm2
000076cd267d2cc7  vmovaps [rsp+0x30], xmm3
000076cd267d2ccd  vmovaps [rsp+0x40], xmm4
000076cd267d2cd3  vmovaps [rsp+0x50], xmm5
000076cd267d2cd9  vmovaps [rsp+0x60], xmm6
000076cd267d2cdf  vmovaps [rsp+0x70], xmm7
000076cd267d2ce5  vmovaps [rsp+0x80], xmm8
000076cd267d2cee  vmovaps [rsp+0x90], xmm9
000076cd267d2cf7  vmovaps [rsp+0xA0], xmm10
000076cd267d2d00  vmovaps [rsp+0xB0], xmm11
000076cd267d2d09  vmovaps [rsp+0xC0], xmm12
000076cd267d2d12  vmovaps [rsp+0xD0], xmm14
000076cd267d2d1b  vmovaps [rsp+0xE0], xmm15
000076cd267d2d24  sub rsp, 0x30
000076cd267d2d28  movaps [rsp], xmm13
000076cd267d2d2d  movaps [rsp+0x10], xmm10
000076cd267d2d33  movaps [rsp+0x20], xmm1
000076cd267d2d38  lea rdi, [rsp]
000076cd267d2d3c  mov esi, 0x00
000076cd267d2d41  mov rax, 0x56B8861A9530
000076cd267d2d4b  call rax
000076cd267d2d4d  movaps xmm13, [rsp]
000076cd267d2d52  add rsp, 0x30
000076cd267d2d56  vmovaps xmm0, [rsp]
000076cd267d2d5b  vmovaps xmm1, [rsp+0x10]
000076cd267d2d61  vmovaps xmm2, [rsp+0x20]
000076cd267d2d67  vmovaps xmm3, [rsp+0x30]
000076cd267d2d6d  vmovaps xmm4, [rsp+0x40]
000076cd267d2d73  vmovaps xmm5, [rsp+0x50]
000076cd267d2d79  vmovaps xmm6, [rsp+0x60]
000076cd267d2d7f  vmovaps xmm7, [rsp+0x70]
000076cd267d2d85  vmovaps xmm8, [rsp+0x80]
000076cd267d2d8e  vmovaps xmm9, [rsp+0x90]
000076cd267d2d97  vmovaps xmm10, [rsp+0xA0]
000076cd267d2da0  vmovaps xmm11, [rsp+0xB0]
000076cd267d2da9  vmovaps xmm12, [rsp+0xC0]
000076cd267d2db2  vmovaps xmm14, [rsp+0xD0]
000076cd267d2dbb  vmovaps xmm15, [rsp+0xE0]
000076cd267d2dc4  add rsp, 0xF0
000076cd267d2dcb  pop r11
000076cd267d2dcd  pop r10
000076cd267d2dcf  pop r9
000076cd267d2dd1  pop r8
000076cd267d2dd3  pop rsi
000076cd267d2dd4  pop rdi
000076cd267d2dd5  pop rdx
000076cd267d2dd6  pop rcx
000076cd267d2dd7  pop rax
000076cd267d2dd8  add rsp, 0x08
000076cd267d2ddc  jmp 0x000076CD267CFE15
000076cd267d2de1  sub rsp, 0x08
000076cd267d2de5  push rax
000076cd267d2de6  push rcx
000076cd267d2de7  push rdx
000076cd267d2de8  push rdi
000076cd267d2de9  push rsi
000076cd267d2dea  push r8
000076cd267d2dec  push r9
000076cd267d2dee  push r10
000076cd267d2df0  push r11
000076cd267d2df2  sub rsp, 0xF0
000076cd267d2df9  vmovaps [rsp], xmm0
000076cd267d2dfe  vmovaps [rsp+0x10], xmm2
000076cd267d2e04  vmovaps [rsp+0x20], xmm3
000076cd267d2e0a  vmovaps [rsp+0x30], xmm4
000076cd267d2e10  vmovaps [rsp+0x40], xmm5
000076cd267d2e16  vmovaps [rsp+0x50], xmm6
000076cd267d2e1c  vmovaps [rsp+0x60], xmm7
000076cd267d2e22  vmovaps [rsp+0x70], xmm8
000076cd267d2e28  vmovaps [rsp+0x80], xmm9
000076cd267d2e31  vmovaps [rsp+0x90], xmm10
000076cd267d2e3a  vmovaps [rsp+0xA0], xmm11
000076cd267d2e43  vmovaps [rsp+0xB0], xmm12
000076cd267d2e4c  vmovaps [rsp+0xC0], xmm13
000076cd267d2e55  vmovaps [rsp+0xD0], xmm14
000076cd267d2e5e  vmovaps [rsp+0xE0], xmm15
000076cd267d2e67  sub rsp, 0x30
000076cd267d2e6b  movaps [rsp], xmm1
000076cd267d2e6f  movaps [rsp+0x10], xmm15
000076cd267d2e75  movaps [rsp+0x20], xmm10
000076cd267d2e7b  lea rdi, [rsp]
000076cd267d2e7f  mov esi, 0x00
000076cd267d2e84  mov rax, 0x56B8861A9530
000076cd267d2e8e  call rax
000076cd267d2e90  movaps xmm1, [rsp]
000076cd267d2e94  add rsp, 0x30
000076cd267d2e98  vmovaps xmm0, [rsp]
000076cd267d2e9d  vmovaps xmm2, [rsp+0x10]
000076cd267d2ea3  vmovaps xmm3, [rsp+0x20]
000076cd267d2ea9  vmovaps xmm4, [rsp+0x30]
000076cd267d2eaf  vmovaps xmm5, [rsp+0x40]
000076cd267d2eb5  vmovaps xmm6, [rsp+0x50]
000076cd267d2ebb  vmovaps xmm7, [rsp+0x60]
000076cd267d2ec1  vmovaps xmm8, [rsp+0x70]
000076cd267d2ec7  vmovaps xmm9, [rsp+0x80]
000076cd267d2ed0  vmovaps xmm10, [rsp+0x90]
000076cd267d2ed9  vmovaps xmm11, [rsp+0xA0]
000076cd267d2ee2  vmovaps xmm12, [rsp+0xB0]
000076cd267d2eeb  vmovaps xmm13, [rsp+0xC0]
000076cd267d2ef4  vmovaps xmm14, [rsp+0xD0]
000076cd267d2efd  vmovaps xmm15, [rsp+0xE0]
000076cd267d2f06  add rsp, 0xF0
000076cd267d2f0d  pop r11
000076cd267d2f0f  pop r10
000076cd267d2f11  pop r9
000076cd267d2f13  pop r8
000076cd267d2f15  pop rsi
000076cd267d2f16  pop rdi
000076cd267d2f17  pop rdx
000076cd267d2f18  pop rcx
000076cd267d2f19  pop rax
000076cd267d2f1a  add rsp, 0x08
000076cd267d2f1e  jmp 0x000076CD267CFE34
000076cd267d2f23  sub rsp, 0x08
000076cd267d2f27  push rax
000076cd267d2f28  push rcx
000076cd267d2f29  push rdx
000076cd267d2f2a  push rdi
000076cd267d2f2b  push rsi
000076cd267d2f2c  push r8
000076cd267d2f2e  push r9
000076cd267d2f30  push r10
000076cd267d2f32  push r11
000076cd267d2f34  sub rsp, 0xF0
000076cd267d2f3b  vmovaps [rsp], xmm0
000076cd267d2f40  vmovaps [rsp+0x10], xmm1
000076cd267d2f46  vmovaps [rsp+0x20], xmm2
000076cd267d2f4c  vmovaps [rsp+0x30], xmm3
000076cd267d2f52  vmovaps [rsp+0x40], xmm4
000076cd267d2f58  vmovaps [rsp+0x50], xmm5
000076cd267d2f5e  vmovaps [rsp+0x60], xmm6
000076cd267d2f64  vmovaps [rsp+0x70], xmm7
000076cd267d2f6a  vmovaps [rsp+0x80], xmm8
000076cd267d2f73  vmovaps [rsp+0x90], xmm9
000076cd267d2f7c  vmovaps [rsp+0xA0], xmm10
000076cd267d2f85  vmovaps [rsp+0xB0], xmm11
000076cd267d2f8e  vmovaps [rsp+0xC0], xmm12
000076cd267d2f97  vmovaps [rsp+0xD0], xmm13
000076cd267d2fa0  vmovaps [rsp+0xE0], xmm14
000076cd267d2fa9  sub rsp, 0x30
000076cd267d2fad  movaps [rsp], xmm15
000076cd267d2fb2  movaps [rsp+0x10], xmm10
000076cd267d2fb8  movaps [rsp+0x20], xmm11
000076cd267d2fbe  lea rdi, [rsp]
000076cd267d2fc2  mov esi, 0x00
000076cd267d2fc7  mov rax, 0x56B8861A9530
000076cd267d2fd1  call rax
000076cd267d2fd3  movaps xmm15, [rsp]
000076cd267d2fd8  add rsp, 0x30
000076cd267d2fdc  vmovaps xmm0, [rsp]
000076cd267d2fe1  vmovaps xmm1, [rsp+0x10]
000076cd267d2fe7  vmovaps xmm2, [rsp+0x20]
000076cd267d2fed  vmovaps xmm3, [rsp+0x30]
000076cd267d2ff3  vmovaps xmm4, [rsp+0x40]
000076cd267d2ff9  vmovaps xmm5, [rsp+0x50]
000076cd267d2fff  vmovaps xmm6, [rsp+0x60]
000076cd267d3005  vmovaps xmm7, [rsp+0x70]
000076cd267d300b  vmovaps xmm8, [rsp+0x80]
000076cd267d3014  vmovaps xmm9, [rsp+0x90]
000076cd267d301d  vmovaps xmm10, [rsp+0xA0]
000076cd267d3026  vmovaps xmm11, [rsp+0xB0]
000076cd267d302f  vmovaps xmm12, [rsp+0xC0]
000076cd267d3038  vmovaps xmm13, [rsp+0xD0]
000076cd267d3041  vmovaps xmm14, [rsp+0xE0]
000076cd267d304a  add rsp, 0xF0
000076cd267d3051  pop r11
000076cd267d3053  pop r10
000076cd267d3055  pop r9
000076cd267d3057  pop r8
000076cd267d3059  pop rsi
000076cd267d305a  pop rdi
000076cd267d305b  pop rdx
000076cd267d305c  pop rcx
000076cd267d305d  pop rax
000076cd267d305e  add rsp, 0x08
000076cd267d3062  jmp 0x000076CD267CFE57
000076cd267d3067  sub rsp, 0x08
000076cd267d306b  push rax
000076cd267d306c  push rcx
000076cd267d306d  push rdx
000076cd267d306e  push rdi
000076cd267d306f  push rsi
000076cd267d3070  push r8
000076cd267d3072  push r9
000076cd267d3074  push r10
000076cd267d3076  push r11
000076cd267d3078  sub rsp, 0xF0
000076cd267d307f  vmovaps [rsp], xmm0
000076cd267d3084  vmovaps [rsp+0x10], xmm1
000076cd267d308a  vmovaps [rsp+0x20], xmm2
000076cd267d3090  vmovaps [rsp+0x30], xmm3
000076cd267d3096  vmovaps [rsp+0x40], xmm4
000076cd267d309c  vmovaps [rsp+0x50], xmm5
000076cd267d30a2  vmovaps [rsp+0x60], xmm6
000076cd267d30a8  vmovaps [rsp+0x70], xmm7
000076cd267d30ae  vmovaps [rsp+0x80], xmm8
000076cd267d30b7  vmovaps [rsp+0x90], xmm9
000076cd267d30c0  vmovaps [rsp+0xA0], xmm11
000076cd267d30c9  vmovaps [rsp+0xB0], xmm12
000076cd267d30d2  vmovaps [rsp+0xC0], xmm13
000076cd267d30db  vmovaps [rsp+0xD0], xmm14
000076cd267d30e4  vmovaps [rsp+0xE0], xmm15
000076cd267d30ed  sub rsp, 0x30
000076cd267d30f1  movaps [rsp], xmm10
000076cd267d30f6  movaps [rsp+0x10], xmm12
000076cd267d30fc  movaps [rsp+0x20], xmm11
000076cd267d3102  lea rdi, [rsp]
000076cd267d3106  mov esi, 0x00
000076cd267d310b  mov rax, 0x56B8861A9530
000076cd267d3115  call rax
000076cd267d3117  movaps xmm10, [rsp]
000076cd267d311c  add rsp, 0x30
000076cd267d3120  vmovaps xmm0, [rsp]
000076cd267d3125  vmovaps xmm1, [rsp+0x10]
000076cd267d312b  vmovaps xmm2, [rsp+0x20]
000076cd267d3131  vmovaps xmm3, [rsp+0x30]
000076cd267d3137  vmovaps xmm4, [rsp+0x40]
000076cd267d313d  vmovaps xmm5, [rsp+0x50]
000076cd267d3143  vmovaps xmm6, [rsp+0x60]
000076cd267d3149  vmovaps xmm7, [rsp+0x70]
000076cd267d314f  vmovaps xmm8, [rsp+0x80]
000076cd267d3158  vmovaps xmm9, [rsp+0x90]
000076cd267d3161  vmovaps xmm11, [rsp+0xA0]
000076cd267d316a  vmovaps xmm12, [rsp+0xB0]
000076cd267d3173  vmovaps xmm13, [rsp+0xC0]
000076cd267d317c  vmovaps xmm14, [rsp+0xD0]
000076cd267d3185  vmovaps xmm15, [rsp+0xE0]
000076cd267d318e  add rsp, 0xF0
000076cd267d3195  pop r11
000076cd267d3197  pop r10
000076cd267d3199  pop r9
000076cd267d319b  pop r8
000076cd267d319d  pop rsi
000076cd267d319e  pop rdi
000076cd267d319f  pop rdx
000076cd267d31a0  pop rcx
000076cd267d31a1  pop rax
000076cd267d31a2  add rsp, 0x08
000076cd267d31a6  jmp 0x000076CD267CFE80
000076cd267d31ab  sub rsp, 0x08
000076cd267d31af  push rax
000076cd267d31b0  push rcx
000076cd267d31b1  push rdx
000076cd267d31b2  push rdi
000076cd267d31b3  push rsi
000076cd267d31b4  push r8
000076cd267d31b6  push r9
000076cd267d31b8  push r10
000076cd267d31ba  push r11
000076cd267d31bc  sub rsp, 0xF0
000076cd267d31c3  vmovaps [rsp], xmm0
000076cd267d31c8  vmovaps [rsp+0x10], xmm1
000076cd267d31ce  vmovaps [rsp+0x20], xmm2
000076cd267d31d4  vmovaps [rsp+0x30], xmm3
000076cd267d31da  vmovaps [rsp+0x40], xmm4
000076cd267d31e0  vmovaps [rsp+0x50], xmm5
000076cd267d31e6  vmovaps [rsp+0x60], xmm6
000076cd267d31ec  vmovaps [rsp+0x70], xmm7
000076cd267d31f2  vmovaps [rsp+0x80], xmm8
000076cd267d31fb  vmovaps [rsp+0x90], xmm9
000076cd267d3204  vmovaps [rsp+0xA0], xmm10
000076cd267d320d  vmovaps [rsp+0xB0], xmm12
000076cd267d3216  vmovaps [rsp+0xC0], xmm13
000076cd267d321f  vmovaps [rsp+0xD0], xmm14
000076cd267d3228  vmovaps [rsp+0xE0], xmm15
000076cd267d3231  sub rsp, 0x30
000076cd267d3235  movaps [rsp], xmm11
000076cd267d323a  movaps [rsp+0x10], xmm2
000076cd267d323f  movaps [rsp+0x20], xmm12
000076cd267d3245  lea rdi, [rsp]
000076cd267d3249  mov esi, 0x00
000076cd267d324e  mov rax, 0x56B8861A9530
000076cd267d3258  call rax
000076cd267d325a  movaps xmm11, [rsp]
000076cd267d325f  add rsp, 0x30
000076cd267d3263  vmovaps xmm0, [rsp]
000076cd267d3268  vmovaps xmm1, [rsp+0x10]
000076cd267d326e  vmovaps xmm2, [rsp+0x20]
000076cd267d3274  vmovaps xmm3, [rsp+0x30]
000076cd267d327a  vmovaps xmm4, [rsp+0x40]
000076cd267d3280  vmovaps xmm5, [rsp+0x50]
000076cd267d3286  vmovaps xmm6, [rsp+0x60]
000076cd267d328c  vmovaps xmm7, [rsp+0x70]
000076cd267d3292  vmovaps xmm8, [rsp+0x80]
000076cd267d329b  vmovaps xmm9, [rsp+0x90]
000076cd267d32a4  vmovaps xmm10, [rsp+0xA0]
000076cd267d32ad  vmovaps xmm12, [rsp+0xB0]
000076cd267d32b6  vmovaps xmm13, [rsp+0xC0]
000076cd267d32bf  vmovaps xmm14, [rsp+0xD0]
000076cd267d32c8  vmovaps xmm15, [rsp+0xE0]
000076cd267d32d1  add rsp, 0xF0
000076cd267d32d8  pop r11
000076cd267d32da  pop r10
000076cd267d32dc  pop r9
000076cd267d32de  pop r8
000076cd267d32e0  pop rsi
000076cd267d32e1  pop rdi
000076cd267d32e2  pop rdx
000076cd267d32e3  pop rcx
000076cd267d32e4  pop rax
000076cd267d32e5  add rsp, 0x08
000076cd267d32e9  jmp 0x000076CD267CFEB8
000076cd267d32ee  sub rsp, 0x08
000076cd267d32f2  push rax
000076cd267d32f3  push rcx
000076cd267d32f4  push rdx
000076cd267d32f5  push rdi
000076cd267d32f6  push rsi
000076cd267d32f7  push r8
000076cd267d32f9  push r9
000076cd267d32fb  push r10
000076cd267d32fd  push r11
000076cd267d32ff  sub rsp, 0xF0
000076cd267d3306  vmovaps [rsp], xmm0
000076cd267d330b  vmovaps [rsp+0x10], xmm2
000076cd267d3311  vmovaps [rsp+0x20], xmm3
000076cd267d3317  vmovaps [rsp+0x30], xmm4
000076cd267d331d  vmovaps [rsp+0x40], xmm5
000076cd267d3323  vmovaps [rsp+0x50], xmm6
000076cd267d3329  vmovaps [rsp+0x60], xmm7
000076cd267d332f  vmovaps [rsp+0x70], xmm8
000076cd267d3335  vmovaps [rsp+0x80], xmm9
000076cd267d333e  vmovaps [rsp+0x90], xmm10
000076cd267d3347  vmovaps [rsp+0xA0], xmm11
000076cd267d3350  vmovaps [rsp+0xB0], xmm12
000076cd267d3359  vmovaps [rsp+0xC0], xmm13
000076cd267d3362  vmovaps [rsp+0xD0], xmm14
000076cd267d336b  vmovaps [rsp+0xE0], xmm15
000076cd267d3374  sub rsp, 0x30
000076cd267d3378  movaps [rsp], xmm1
000076cd267d337c  movaps [rsp+0x10], xmm14
000076cd267d3382  movaps [rsp+0x20], xmm6
000076cd267d3387  lea rdi, [rsp]
000076cd267d338b  mov esi, 0x00
000076cd267d3390  mov rax, 0x56B8861A9530
000076cd267d339a  call rax
000076cd267d339c  movaps xmm1, [rsp]
000076cd267d33a0  add rsp, 0x30
000076cd267d33a4  vmovaps xmm0, [rsp]
000076cd267d33a9  vmovaps xmm2, [rsp+0x10]
000076cd267d33af  vmovaps xmm3, [rsp+0x20]
000076cd267d33b5  vmovaps xmm4, [rsp+0x30]
000076cd267d33bb  vmovaps xmm5, [rsp+0x40]
000076cd267d33c1  vmovaps xmm6, [rsp+0x50]
000076cd267d33c7  vmovaps xmm7, [rsp+0x60]
000076cd267d33cd  vmovaps xmm8, [rsp+0x70]
000076cd267d33d3  vmovaps xmm9, [rsp+0x80]
000076cd267d33dc  vmovaps xmm10, [rsp+0x90]
000076cd267d33e5  vmovaps xmm11, [rsp+0xA0]
000076cd267d33ee  vmovaps xmm12, [rsp+0xB0]
000076cd267d33f7  vmovaps xmm13, [rsp+0xC0]
000076cd267d3400  vmovaps xmm14, [rsp+0xD0]
000076cd267d3409  vmovaps xmm15, [rsp+0xE0]
000076cd267d3412  add rsp, 0xF0
000076cd267d3419  pop r11
000076cd267d341b  pop r10
000076cd267d341d  pop r9
000076cd267d341f  pop r8
000076cd267d3421  pop rsi
000076cd267d3422  pop rdi
000076cd267d3423  pop rdx
000076cd267d3424  pop rcx
000076cd267d3425  pop rax
000076cd267d3426  add rsp, 0x08
000076cd267d342a  jmp 0x000076CD267CFED1
000076cd267d342f  sub rsp, 0x08
000076cd267d3433  push rax
000076cd267d3434  push rcx
000076cd267d3435  push rdx
000076cd267d3436  push rdi
000076cd267d3437  push rsi
000076cd267d3438  push r8
000076cd267d343a  push r9
000076cd267d343c  push r10
000076cd267d343e  push r11
000076cd267d3440  sub rsp, 0xF0
000076cd267d3447  vmovaps [rsp], xmm0
000076cd267d344c  vmovaps [rsp+0x10], xmm1
000076cd267d3452  vmovaps [rsp+0x20], xmm2
000076cd267d3458  vmovaps [rsp+0x30], xmm3
000076cd267d345e  vmovaps [rsp+0x40], xmm4
000076cd267d3464  vmovaps [rsp+0x50], xmm5
000076cd267d346a  vmovaps [rsp+0x60], xmm6
000076cd267d3470  vmovaps [rsp+0x70], xmm7
000076cd267d3476  vmovaps [rsp+0x80], xmm8
000076cd267d347f  vmovaps [rsp+0x90], xmm9
000076cd267d3488  vmovaps [rsp+0xA0], xmm10
000076cd267d3491  vmovaps [rsp+0xB0], xmm11
000076cd267d349a  vmovaps [rsp+0xC0], xmm12
000076cd267d34a3  vmovaps [rsp+0xD0], xmm13
000076cd267d34ac  vmovaps [rsp+0xE0], xmm15
000076cd267d34b5  sub rsp, 0x30
000076cd267d34b9  movaps [rsp], xmm14
000076cd267d34be  movaps [rsp+0x10], xmm12
000076cd267d34c4  movaps [rsp+0x20], xmm5
000076cd267d34c9  lea rdi, [rsp]
000076cd267d34cd  mov esi, 0x00
000076cd267d34d2  mov rax, 0x56B8861A9530
000076cd267d34dc  call rax
000076cd267d34de  movaps xmm14, [rsp]
000076cd267d34e3  add rsp, 0x30
000076cd267d34e7  vmovaps xmm0, [rsp]
000076cd267d34ec  vmovaps xmm1, [rsp+0x10]
000076cd267d34f2  vmovaps xmm2, [rsp+0x20]
000076cd267d34f8  vmovaps xmm3, [rsp+0x30]
000076cd267d34fe  vmovaps xmm4, [rsp+0x40]
000076cd267d3504  vmovaps xmm5, [rsp+0x50]
000076cd267d350a  vmovaps xmm6, [rsp+0x60]
000076cd267d3510  vmovaps xmm7, [rsp+0x70]
000076cd267d3516  vmovaps xmm8, [rsp+0x80]
000076cd267d351f  vmovaps xmm9, [rsp+0x90]
000076cd267d3528  vmovaps xmm10, [rsp+0xA0]
000076cd267d3531  vmovaps xmm11, [rsp+0xB0]
000076cd267d353a  vmovaps xmm12, [rsp+0xC0]
000076cd267d3543  vmovaps xmm13, [rsp+0xD0]
000076cd267d354c  vmovaps xmm15, [rsp+0xE0]
000076cd267d3555  add rsp, 0xF0
000076cd267d355c  pop r11
000076cd267d355e  pop r10
000076cd267d3560  pop r9
000076cd267d3562  pop r8
000076cd267d3564  pop rsi
000076cd267d3565  pop rdi
000076cd267d3566  pop rdx
000076cd267d3567  pop rcx
000076cd267d3568  pop rax
000076cd267d3569  add rsp, 0x08
000076cd267d356d  jmp 0x000076CD267CFEF1
000076cd267d3572  sub rsp, 0x08
000076cd267d3576  push rax
000076cd267d3577  push rcx
000076cd267d3578  push rdx
000076cd267d3579  push rdi
000076cd267d357a  push rsi
000076cd267d357b  push r8
000076cd267d357d  push r9
000076cd267d357f  push r10
000076cd267d3581  push r11
000076cd267d3583  sub rsp, 0xF0
000076cd267d358a  vmovaps [rsp], xmm0
000076cd267d358f  vmovaps [rsp+0x10], xmm1
000076cd267d3595  vmovaps [rsp+0x20], xmm2
000076cd267d359b  vmovaps [rsp+0x30], xmm3
000076cd267d35a1  vmovaps [rsp+0x40], xmm4
000076cd267d35a7  vmovaps [rsp+0x50], xmm5
000076cd267d35ad  vmovaps [rsp+0x60], xmm7
000076cd267d35b3  vmovaps [rsp+0x70], xmm8
000076cd267d35b9  vmovaps [rsp+0x80], xmm9
000076cd267d35c2  vmovaps [rsp+0x90], xmm10
000076cd267d35cb  vmovaps [rsp+0xA0], xmm11
000076cd267d35d4  vmovaps [rsp+0xB0], xmm12
000076cd267d35dd  vmovaps [rsp+0xC0], xmm13
000076cd267d35e6  vmovaps [rsp+0xD0], xmm14
000076cd267d35ef  vmovaps [rsp+0xE0], xmm15
000076cd267d35f8  sub rsp, 0x30
000076cd267d35fc  movaps [rsp], xmm6
000076cd267d3600  movaps [rsp+0x10], xmm9
000076cd267d3606  movaps [rsp+0x20], xmm12
000076cd267d360c  lea rdi, [rsp]
000076cd267d3610  mov esi, 0x00
000076cd267d3615  mov rax, 0x56B8861A9530
000076cd267d361f  call rax
000076cd267d3621  movaps xmm6, [rsp]
000076cd267d3625  add rsp, 0x30
000076cd267d3629  vmovaps xmm0, [rsp]
000076cd267d362e  vmovaps xmm1, [rsp+0x10]
000076cd267d3634  vmovaps xmm2, [rsp+0x20]
000076cd267d363a  vmovaps xmm3, [rsp+0x30]
000076cd267d3640  vmovaps xmm4, [rsp+0x40]
000076cd267d3646  vmovaps xmm5, [rsp+0x50]
000076cd267d364c  vmovaps xmm7, [rsp+0x60]
000076cd267d3652  vmovaps xmm8, [rsp+0x70]
000076cd267d3658  vmovaps xmm9, [rsp+0x80]
000076cd267d3661  vmovaps xmm10, [rsp+0x90]
000076cd267d366a  vmovaps xmm11, [rsp+0xA0]
000076cd267d3673  vmovaps xmm12, [rsp+0xB0]
000076cd267d367c  vmovaps xmm13, [rsp+0xC0]
000076cd267d3685  vmovaps xmm14, [rsp+0xD0]
000076cd267d368e  vmovaps xmm15, [rsp+0xE0]
000076cd267d3697  add rsp, 0xF0
000076cd267d369e  pop r11
000076cd267d36a0  pop r10
000076cd267d36a2  pop r9
000076cd267d36a4  pop r8
000076cd267d36a6  pop rsi
000076cd267d36a7  pop rdi
000076cd267d36a8  pop rdx
000076cd267d36a9  pop rcx
000076cd267d36aa  pop rax
000076cd267d36ab  add rsp, 0x08
000076cd267d36af  jmp 0x000076CD267CFF19
000076cd267d36b4  sub rsp, 0x08
000076cd267d36b8  push rax
000076cd267d36b9  push rcx
000076cd267d36ba  push rdx
000076cd267d36bb  push rdi
000076cd267d36bc  push rsi
000076cd267d36bd  push r8
000076cd267d36bf  push r9
000076cd267d36c1  push r10
000076cd267d36c3  push r11
000076cd267d36c5  sub rsp, 0xF0
000076cd267d36cc  vmovaps [rsp], xmm0
000076cd267d36d1  vmovaps [rsp+0x10], xmm1
000076cd267d36d7  vmovaps [rsp+0x20], xmm2
000076cd267d36dd  vmovaps [rsp+0x30], xmm3
000076cd267d36e3  vmovaps [rsp+0x40], xmm4
000076cd267d36e9  vmovaps [rsp+0x50], xmm5
000076cd267d36ef  vmovaps [rsp+0x60], xmm6
000076cd267d36f5  vmovaps [rsp+0x70], xmm7
000076cd267d36fb  vmovaps [rsp+0x80], xmm8
000076cd267d3704  vmovaps [rsp+0x90], xmm9
000076cd267d370d  vmovaps [rsp+0xA0], xmm10
000076cd267d3716  vmovaps [rsp+0xB0], xmm11
000076cd267d371f  vmovaps [rsp+0xC0], xmm13
000076cd267d3728  vmovaps [rsp+0xD0], xmm14
000076cd267d3731  vmovaps [rsp+0xE0], xmm15
000076cd267d373a  sub rsp, 0x30
000076cd267d373e  movaps [rsp], xmm12
000076cd267d3743  movaps [rsp+0x10], xmm15
000076cd267d3749  movaps [rsp+0x20], xmm13
000076cd267d374f  lea rdi, [rsp]
000076cd267d3753  mov esi, 0x00
000076cd267d3758  mov rax, 0x56B8861A9530
000076cd267d3762  call rax
000076cd267d3764  movaps xmm12, [rsp]
000076cd267d3769  add rsp, 0x30
000076cd267d376d  vmovaps xmm0, [rsp]
000076cd267d3772  vmovaps xmm1, [rsp+0x10]
000076cd267d3778  vmovaps xmm2, [rsp+0x20]
000076cd267d377e  vmovaps xmm3, [rsp+0x30]
000076cd267d3784  vmovaps xmm4, [rsp+0x40]
000076cd267d378a  vmovaps xmm5, [rsp+0x50]
000076cd267d3790  vmovaps xmm6, [rsp+0x60]
000076cd267d3796  vmovaps xmm7, [rsp+0x70]
000076cd267d379c  vmovaps xmm8, [rsp+0x80]
000076cd267d37a5  vmovaps xmm9, [rsp+0x90]
000076cd267d37ae  vmovaps xmm10, [rsp+0xA0]
000076cd267d37b7  vmovaps xmm11, [rsp+0xB0]
000076cd267d37c0  vmovaps xmm13, [rsp+0xC0]
000076cd267d37c9  vmovaps xmm14, [rsp+0xD0]
000076cd267d37d2  vmovaps xmm15, [rsp+0xE0]
000076cd267d37db  add rsp, 0xF0
000076cd267d37e2  pop r11
000076cd267d37e4  pop r10
000076cd267d37e6  pop r9
000076cd267d37e8  pop r8
000076cd267d37ea  pop rsi
000076cd267d37eb  pop rdi
000076cd267d37ec  pop rdx
000076cd267d37ed  pop rcx
000076cd267d37ee  pop rax
000076cd267d37ef  add rsp, 0x08
000076cd267d37f3  jmp 0x000076CD267CFF34
000076cd267d37f8  sub rsp, 0x08
000076cd267d37fc  push rax
000076cd267d37fd  push rcx
000076cd267d37fe  push rdx
000076cd267d37ff  push rdi
000076cd267d3800  push rsi
000076cd267d3801  push r8
000076cd267d3803  push r9
000076cd267d3805  push r10
000076cd267d3807  push r11
000076cd267d3809  sub rsp, 0xF0
000076cd267d3810  vmovaps [rsp], xmm0
000076cd267d3815  vmovaps [rsp+0x10], xmm1
000076cd267d381b  vmovaps [rsp+0x20], xmm2
000076cd267d3821  vmovaps [rsp+0x30], xmm3
000076cd267d3827  vmovaps [rsp+0x40], xmm4
000076cd267d382d  vmovaps [rsp+0x50], xmm5
000076cd267d3833  vmovaps [rsp+0x60], xmm6
000076cd267d3839  vmovaps [rsp+0x70], xmm7
000076cd267d383f  vmovaps [rsp+0x80], xmm8
000076cd267d3848  vmovaps [rsp+0x90], xmm9
000076cd267d3851  vmovaps [rsp+0xA0], xmm10
000076cd267d385a  vmovaps [rsp+0xB0], xmm11
000076cd267d3863  vmovaps [rsp+0xC0], xmm12
000076cd267d386c  vmovaps [rsp+0xD0], xmm13
000076cd267d3875  vmovaps [rsp+0xE0], xmm14
000076cd267d387e  sub rsp, 0x30
000076cd267d3882  movaps [rsp], xmm15
000076cd267d3887  movaps [rsp+0x10], xmm13
000076cd267d388d  movaps [rsp+0x20], xmm10
000076cd267d3893  lea rdi, [rsp]
000076cd267d3897  mov esi, 0x00
000076cd267d389c  mov rax, 0x56B8861A9530
000076cd267d38a6  call rax
000076cd267d38a8  movaps xmm15, [rsp]
000076cd267d38ad  add rsp, 0x30
000076cd267d38b1  vmovaps xmm0, [rsp]
000076cd267d38b6  vmovaps xmm1, [rsp+0x10]
000076cd267d38bc  vmovaps xmm2, [rsp+0x20]
000076cd267d38c2  vmovaps xmm3, [rsp+0x30]
000076cd267d38c8  vmovaps xmm4, [rsp+0x40]
000076cd267d38ce  vmovaps xmm5, [rsp+0x50]
000076cd267d38d4  vmovaps xmm6, [rsp+0x60]
000076cd267d38da  vmovaps xmm7, [rsp+0x70]
000076cd267d38e0  vmovaps xmm8, [rsp+0x80]
000076cd267d38e9  vmovaps xmm9, [rsp+0x90]
000076cd267d38f2  vmovaps xmm10, [rsp+0xA0]
000076cd267d38fb  vmovaps xmm11, [rsp+0xB0]
000076cd267d3904  vmovaps xmm12, [rsp+0xC0]
000076cd267d390d  vmovaps xmm13, [rsp+0xD0]
000076cd267d3916  vmovaps xmm14, [rsp+0xE0]
000076cd267d391f  add rsp, 0xF0
000076cd267d3926  pop r11
000076cd267d3928  pop r10
000076cd267d392a  pop r9
000076cd267d392c  pop r8
000076cd267d392e  pop rsi
000076cd267d392f  pop rdi
000076cd267d3930  pop rdx
000076cd267d3931  pop rcx
000076cd267d3932  pop rax
000076cd267d3933  add rsp, 0x08
000076cd267d3937  jmp 0x000076CD267CFF55
000076cd267d393c  call 0x000076CD2660C260
000076cd267d3941  jmp 0x000076CD267CFFB0
000076cd267d3946  sub rsp, 0x08
000076cd267d394a  push rax
000076cd267d394b  push rcx
000076cd267d394c  push rdx
000076cd267d394d  push rdi
000076cd267d394e  push rsi
000076cd267d394f  push r8
000076cd267d3951  push r9
000076cd267d3953  push r10
000076cd267d3955  push r11
000076cd267d3957  sub rsp, 0xF0
000076cd267d395e  vmovaps [rsp], xmm0
000076cd267d3963  vmovaps [rsp+0x10], xmm1
000076cd267d3969  vmovaps [rsp+0x20], xmm2
000076cd267d396f  vmovaps [rsp+0x30], xmm3
000076cd267d3975  vmovaps [rsp+0x40], xmm4
000076cd267d397b  vmovaps [rsp+0x50], xmm5
000076cd267d3981  vmovaps [rsp+0x60], xmm6
000076cd267d3987  vmovaps [rsp+0x70], xmm7
000076cd267d398d  vmovaps [rsp+0x80], xmm8
000076cd267d3996  vmovaps [rsp+0x90], xmm10
000076cd267d399f  vmovaps [rsp+0xA0], xmm11
000076cd267d39a8  vmovaps [rsp+0xB0], xmm12
000076cd267d39b1  vmovaps [rsp+0xC0], xmm13
000076cd267d39ba  vmovaps [rsp+0xD0], xmm14
000076cd267d39c3  vmovaps [rsp+0xE0], xmm15
000076cd267d39cc  sub rsp, 0x30
000076cd267d39d0  movaps [rsp], xmm9
000076cd267d39d5  movaps [rsp+0x10], xmm8
000076cd267d39db  movaps [rsp+0x20], xmm10
000076cd267d39e1  lea rdi, [rsp]
000076cd267d39e5  mov esi, 0x00
000076cd267d39ea  mov rax, 0x56B8861A9530
000076cd267d39f4  call rax
000076cd267d39f6  movaps xmm9, [rsp]
000076cd267d39fb  add rsp, 0x30
000076cd267d39ff  vmovaps xmm0, [rsp]
000076cd267d3a04  vmovaps xmm1, [rsp+0x10]
000076cd267d3a0a  vmovaps xmm2, [rsp+0x20]
000076cd267d3a10  vmovaps xmm3, [rsp+0x30]
000076cd267d3a16  vmovaps xmm4, [rsp+0x40]
000076cd267d3a1c  vmovaps xmm5, [rsp+0x50]
000076cd267d3a22  vmovaps xmm6, [rsp+0x60]
000076cd267d3a28  vmovaps xmm7, [rsp+0x70]
000076cd267d3a2e  vmovaps xmm8, [rsp+0x80]
000076cd267d3a37  vmovaps xmm10, [rsp+0x90]
000076cd267d3a40  vmovaps xmm11, [rsp+0xA0]
000076cd267d3a49  vmovaps xmm12, [rsp+0xB0]
000076cd267d3a52  vmovaps xmm13, [rsp+0xC0]
000076cd267d3a5b  vmovaps xmm14, [rsp+0xD0]
000076cd267d3a64  vmovaps xmm15, [rsp+0xE0]
000076cd267d3a6d  add rsp, 0xF0
000076cd267d3a74  pop r11
000076cd267d3a76  pop r10
000076cd267d3a78  pop r9
000076cd267d3a7a  pop r8
000076cd267d3a7c  pop rsi
000076cd267d3a7d  pop rdi
000076cd267d3a7e  pop rdx
000076cd267d3a7f  pop rcx
000076cd267d3a80  pop rax
000076cd267d3a81  add rsp, 0x08
000076cd267d3a85  jmp 0x000076CD267CFFE1
000076cd267d3a8a  sub rsp, 0x08
000076cd267d3a8e  push rax
000076cd267d3a8f  push rcx
000076cd267d3a90  push rdx
000076cd267d3a91  push rdi
000076cd267d3a92  push rsi
000076cd267d3a93  push r8
000076cd267d3a95  push r9
000076cd267d3a97  push r10
000076cd267d3a99  push r11
000076cd267d3a9b  sub rsp, 0xF0
000076cd267d3aa2  vmovaps [rsp], xmm0
000076cd267d3aa7  vmovaps [rsp+0x10], xmm1
000076cd267d3aad  vmovaps [rsp+0x20], xmm2
000076cd267d3ab3  vmovaps [rsp+0x30], xmm3
000076cd267d3ab9  vmovaps [rsp+0x40], xmm4
000076cd267d3abf  vmovaps [rsp+0x50], xmm5
000076cd267d3ac5  vmovaps [rsp+0x60], xmm6
000076cd267d3acb  vmovaps [rsp+0x70], xmm7
000076cd267d3ad1  vmovaps [rsp+0x80], xmm8
000076cd267d3ada  vmovaps [rsp+0x90], xmm9
000076cd267d3ae3  vmovaps [rsp+0xA0], xmm11
000076cd267d3aec  vmovaps [rsp+0xB0], xmm12
000076cd267d3af5  vmovaps [rsp+0xC0], xmm13
000076cd267d3afe  vmovaps [rsp+0xD0], xmm14
000076cd267d3b07  vmovaps [rsp+0xE0], xmm15
000076cd267d3b10  sub rsp, 0x30
000076cd267d3b14  movaps [rsp], xmm10
000076cd267d3b19  movaps [rsp+0x10], xmm1
000076cd267d3b1e  movaps [rsp+0x20], xmm11
000076cd267d3b24  lea rdi, [rsp]
000076cd267d3b28  mov esi, 0x00
000076cd267d3b2d  mov rax, 0x56B8861A9530
000076cd267d3b37  call rax
000076cd267d3b39  movaps xmm10, [rsp]
000076cd267d3b3e  add rsp, 0x30
000076cd267d3b42  vmovaps xmm0, [rsp]
000076cd267d3b47  vmovaps xmm1, [rsp+0x10]
000076cd267d3b4d  vmovaps xmm2, [rsp+0x20]
000076cd267d3b53  vmovaps xmm3, [rsp+0x30]
000076cd267d3b59  vmovaps xmm4, [rsp+0x40]
000076cd267d3b5f  vmovaps xmm5, [rsp+0x50]
000076cd267d3b65  vmovaps xmm6, [rsp+0x60]
000076cd267d3b6b  vmovaps xmm7, [rsp+0x70]
000076cd267d3b71  vmovaps xmm8, [rsp+0x80]
000076cd267d3b7a  vmovaps xmm9, [rsp+0x90]
000076cd267d3b83  vmovaps xmm11, [rsp+0xA0]
000076cd267d3b8c  vmovaps xmm12, [rsp+0xB0]
000076cd267d3b95  vmovaps xmm13, [rsp+0xC0]
000076cd267d3b9e  vmovaps xmm14, [rsp+0xD0]
000076cd267d3ba7  vmovaps xmm15, [rsp+0xE0]
000076cd267d3bb0  add rsp, 0xF0
000076cd267d3bb7  pop r11
000076cd267d3bb9  pop r10
000076cd267d3bbb  pop r9
000076cd267d3bbd  pop r8
000076cd267d3bbf  pop rsi
000076cd267d3bc0  pop rdi
000076cd267d3bc1  pop rdx
000076cd267d3bc2  pop rcx
000076cd267d3bc3  pop rax
000076cd267d3bc4  add rsp, 0x08
000076cd267d3bc8  jmp 0x000076CD267CFFFC
000076cd267d3bcd  sub rsp, 0x08
000076cd267d3bd1  push rax
000076cd267d3bd2  push rcx
000076cd267d3bd3  push rdx
000076cd267d3bd4  push rdi
000076cd267d3bd5  push rsi
000076cd267d3bd6  push r8
000076cd267d3bd8  push r9
000076cd267d3bda  push r10
000076cd267d3bdc  push r11
000076cd267d3bde  sub rsp, 0xF0
000076cd267d3be5  vmovaps [rsp], xmm0
000076cd267d3bea  vmovaps [rsp+0x10], xmm2
000076cd267d3bf0  vmovaps [rsp+0x20], xmm3
000076cd267d3bf6  vmovaps [rsp+0x30], xmm4
000076cd267d3bfc  vmovaps [rsp+0x40], xmm5
000076cd267d3c02  vmovaps [rsp+0x50], xmm6
000076cd267d3c08  vmovaps [rsp+0x60], xmm7
000076cd267d3c0e  vmovaps [rsp+0x70], xmm8
000076cd267d3c14  vmovaps [rsp+0x80], xmm9
000076cd267d3c1d  vmovaps [rsp+0x90], xmm10
000076cd267d3c26  vmovaps [rsp+0xA0], xmm11
000076cd267d3c2f  vmovaps [rsp+0xB0], xmm12
000076cd267d3c38  vmovaps [rsp+0xC0], xmm13
000076cd267d3c41  vmovaps [rsp+0xD0], xmm14
000076cd267d3c4a  vmovaps [rsp+0xE0], xmm15
000076cd267d3c53  sub rsp, 0x30
000076cd267d3c57  movaps [rsp], xmm1
000076cd267d3c5b  movaps [rsp+0x10], xmm14
000076cd267d3c61  movaps [rsp+0x20], xmm6
000076cd267d3c66  lea rdi, [rsp]
000076cd267d3c6a  mov esi, 0x00
000076cd267d3c6f  mov rax, 0x56B8861A9530
000076cd267d3c79  call rax
000076cd267d3c7b  movaps xmm1, [rsp]
000076cd267d3c7f  add rsp, 0x30
000076cd267d3c83  vmovaps xmm0, [rsp]
000076cd267d3c88  vmovaps xmm2, [rsp+0x10]
000076cd267d3c8e  vmovaps xmm3, [rsp+0x20]
000076cd267d3c94  vmovaps xmm4, [rsp+0x30]
000076cd267d3c9a  vmovaps xmm5, [rsp+0x40]
000076cd267d3ca0  vmovaps xmm6, [rsp+0x50]
000076cd267d3ca6  vmovaps xmm7, [rsp+0x60]
000076cd267d3cac  vmovaps xmm8, [rsp+0x70]
000076cd267d3cb2  vmovaps xmm9, [rsp+0x80]
000076cd267d3cbb  vmovaps xmm10, [rsp+0x90]
000076cd267d3cc4  vmovaps xmm11, [rsp+0xA0]
000076cd267d3ccd  vmovaps xmm12, [rsp+0xB0]
000076cd267d3cd6  vmovaps xmm13, [rsp+0xC0]
000076cd267d3cdf  vmovaps xmm14, [rsp+0xD0]
000076cd267d3ce8  vmovaps xmm15, [rsp+0xE0]
000076cd267d3cf1  add rsp, 0xF0
000076cd267d3cf8  pop r11
000076cd267d3cfa  pop r10
000076cd267d3cfc  pop r9
000076cd267d3cfe  pop r8
000076cd267d3d00  pop rsi
000076cd267d3d01  pop rdi
000076cd267d3d02  pop rdx
000076cd267d3d03  pop rcx
000076cd267d3d04  pop rax
000076cd267d3d05  add rsp, 0x08
000076cd267d3d09  jmp 0x000076CD267D0015
000076cd267d3d0e  sub rsp, 0x08
000076cd267d3d12  push rax
000076cd267d3d13  push rcx
000076cd267d3d14  push rdx
000076cd267d3d15  push rdi
000076cd267d3d16  push rsi
000076cd267d3d17  push r8
000076cd267d3d19  push r9
000076cd267d3d1b  push r10
000076cd267d3d1d  push r11
000076cd267d3d1f  sub rsp, 0xF0
000076cd267d3d26  vmovaps [rsp], xmm0
000076cd267d3d2b  vmovaps [rsp+0x10], xmm1
000076cd267d3d31  vmovaps [rsp+0x20], xmm2
000076cd267d3d37  vmovaps [rsp+0x30], xmm3
000076cd267d3d3d  vmovaps [rsp+0x40], xmm4
000076cd267d3d43  vmovaps [rsp+0x50], xmm5
000076cd267d3d49  vmovaps [rsp+0x60], xmm6
000076cd267d3d4f  vmovaps [rsp+0x70], xmm7
000076cd267d3d55  vmovaps [rsp+0x80], xmm8
000076cd267d3d5e  vmovaps [rsp+0x90], xmm9
000076cd267d3d67  vmovaps [rsp+0xA0], xmm10
000076cd267d3d70  vmovaps [rsp+0xB0], xmm12
000076cd267d3d79  vmovaps [rsp+0xC0], xmm13
000076cd267d3d82  vmovaps [rsp+0xD0], xmm14
000076cd267d3d8b  vmovaps [rsp+0xE0], xmm15
000076cd267d3d94  sub rsp, 0x30
000076cd267d3d98  movaps [rsp], xmm11
000076cd267d3d9d  movaps [rsp+0x10], xmm13
000076cd267d3da3  movaps [rsp+0x20], xmm14
000076cd267d3da9  lea rdi, [rsp]
000076cd267d3dad  mov esi, 0x00
000076cd267d3db2  mov rax, 0x56B8861A9530
000076cd267d3dbc  call rax
000076cd267d3dbe  movaps xmm11, [rsp]
000076cd267d3dc3  add rsp, 0x30
000076cd267d3dc7  vmovaps xmm0, [rsp]
000076cd267d3dcc  vmovaps xmm1, [rsp+0x10]
000076cd267d3dd2  vmovaps xmm2, [rsp+0x20]
000076cd267d3dd8  vmovaps xmm3, [rsp+0x30]
000076cd267d3dde  vmovaps xmm4, [rsp+0x40]
000076cd267d3de4  vmovaps xmm5, [rsp+0x50]
000076cd267d3dea  vmovaps xmm6, [rsp+0x60]
000076cd267d3df0  vmovaps xmm7, [rsp+0x70]
000076cd267d3df6  vmovaps xmm8, [rsp+0x80]
000076cd267d3dff  vmovaps xmm9, [rsp+0x90]
000076cd267d3e08  vmovaps xmm10, [rsp+0xA0]
000076cd267d3e11  vmovaps xmm12, [rsp+0xB0]
000076cd267d3e1a  vmovaps xmm13, [rsp+0xC0]
000076cd267d3e23  vmovaps xmm14, [rsp+0xD0]
000076cd267d3e2c  vmovaps xmm15, [rsp+0xE0]
000076cd267d3e35  add rsp, 0xF0
000076cd267d3e3c  pop r11
000076cd267d3e3e  pop r10
000076cd267d3e40  pop r9
000076cd267d3e42  pop r8
000076cd267d3e44  pop rsi
000076cd267d3e45  pop rdi
000076cd267d3e46  pop rdx
000076cd267d3e47  pop rcx
000076cd267d3e48  pop rax
000076cd267d3e49  add rsp, 0x08
000076cd267d3e4d  jmp 0x000076CD267D003F
000076cd267d3e52  sub rsp, 0x08
000076cd267d3e56  push rax
000076cd267d3e57  push rcx
000076cd267d3e58  push rdx
000076cd267d3e59  push rdi
000076cd267d3e5a  push rsi
000076cd267d3e5b  push r8
000076cd267d3e5d  push r9
000076cd267d3e5f  push r10
000076cd267d3e61  push r11
000076cd267d3e63  sub rsp, 0xF0
000076cd267d3e6a  vmovaps [rsp], xmm0
000076cd267d3e6f  vmovaps [rsp+0x10], xmm1
000076cd267d3e75  vmovaps [rsp+0x20], xmm2
000076cd267d3e7b  vmovaps [rsp+0x30], xmm3
000076cd267d3e81  vmovaps [rsp+0x40], xmm4
000076cd267d3e87  vmovaps [rsp+0x50], xmm5
000076cd267d3e8d  vmovaps [rsp+0x60], xmm6
000076cd267d3e93  vmovaps [rsp+0x70], xmm7
000076cd267d3e99  vmovaps [rsp+0x80], xmm8
000076cd267d3ea2  vmovaps [rsp+0x90], xmm9
000076cd267d3eab  vmovaps [rsp+0xA0], xmm10
000076cd267d3eb4  vmovaps [rsp+0xB0], xmm11
000076cd267d3ebd  vmovaps [rsp+0xC0], xmm12
000076cd267d3ec6  vmovaps [rsp+0xD0], xmm14
000076cd267d3ecf  vmovaps [rsp+0xE0], xmm15
000076cd267d3ed8  sub rsp, 0x30
000076cd267d3edc  movaps [rsp], xmm13
000076cd267d3ee1  movaps [rsp+0x10], xmm8
000076cd267d3ee7  movaps [rsp+0x20], xmm14
000076cd267d3eed  lea rdi, [rsp]
000076cd267d3ef1  mov esi, 0x00
000076cd267d3ef6  mov rax, 0x56B8861A9530
000076cd267d3f00  call rax
000076cd267d3f02  movaps xmm13, [rsp]
000076cd267d3f07  add rsp, 0x30
000076cd267d3f0b  vmovaps xmm0, [rsp]
000076cd267d3f10  vmovaps xmm1, [rsp+0x10]
000076cd267d3f16  vmovaps xmm2, [rsp+0x20]
000076cd267d3f1c  vmovaps xmm3, [rsp+0x30]
000076cd267d3f22  vmovaps xmm4, [rsp+0x40]
000076cd267d3f28  vmovaps xmm5, [rsp+0x50]
000076cd267d3f2e  vmovaps xmm6, [rsp+0x60]
000076cd267d3f34  vmovaps xmm7, [rsp+0x70]
000076cd267d3f3a  vmovaps xmm8, [rsp+0x80]
000076cd267d3f43  vmovaps xmm9, [rsp+0x90]
000076cd267d3f4c  vmovaps xmm10, [rsp+0xA0]
000076cd267d3f55  vmovaps xmm11, [rsp+0xB0]
000076cd267d3f5e  vmovaps xmm12, [rsp+0xC0]
000076cd267d3f67  vmovaps xmm14, [rsp+0xD0]
000076cd267d3f70  vmovaps xmm15, [rsp+0xE0]
000076cd267d3f79  add rsp, 0xF0
000076cd267d3f80  pop r11
000076cd267d3f82  pop r10
000076cd267d3f84  pop r9
000076cd267d3f86  pop r8
000076cd267d3f88  pop rsi
000076cd267d3f89  pop rdi
000076cd267d3f8a  pop rdx
000076cd267d3f8b  pop rcx
000076cd267d3f8c  pop rax
000076cd267d3f8d  add rsp, 0x08
000076cd267d3f91  jmp 0x000076CD267D006E
000076cd267d3f96  sub rsp, 0x08
000076cd267d3f9a  push rax
000076cd267d3f9b  push rcx
000076cd267d3f9c  push rdx
000076cd267d3f9d  push rdi
000076cd267d3f9e  push rsi
000076cd267d3f9f  push r8
000076cd267d3fa1  push r9
000076cd267d3fa3  push r10
000076cd267d3fa5  push r11
000076cd267d3fa7  sub rsp, 0xF0
000076cd267d3fae  vmovaps [rsp], xmm0
000076cd267d3fb3  vmovaps [rsp+0x10], xmm1
000076cd267d3fb9  vmovaps [rsp+0x20], xmm2
000076cd267d3fbf  vmovaps [rsp+0x30], xmm3
000076cd267d3fc5  vmovaps [rsp+0x40], xmm4
000076cd267d3fcb  vmovaps [rsp+0x50], xmm5
000076cd267d3fd1  vmovaps [rsp+0x60], xmm6
000076cd267d3fd7  vmovaps [rsp+0x70], xmm7
000076cd267d3fdd  vmovaps [rsp+0x80], xmm9
000076cd267d3fe6  vmovaps [rsp+0x90], xmm10
000076cd267d3fef  vmovaps [rsp+0xA0], xmm11
000076cd267d3ff8  vmovaps [rsp+0xB0], xmm12
000076cd267d4001  vmovaps [rsp+0xC0], xmm13
000076cd267d400a  vmovaps [rsp+0xD0], xmm14
000076cd267d4013  vmovaps [rsp+0xE0], xmm15
000076cd267d401c  sub rsp, 0x30
000076cd267d4020  movaps [rsp], xmm8
000076cd267d4025  movaps [rsp+0x10], xmm7
000076cd267d402a  movaps [rsp+0x20], xmm14
000076cd267d4030  lea rdi, [rsp]
000076cd267d4034  mov esi, 0x00
000076cd267d4039  mov rax, 0x56B8861A9530
000076cd267d4043  call rax
000076cd267d4045  movaps xmm8, [rsp]
000076cd267d404a  add rsp, 0x30
000076cd267d404e  vmovaps xmm0, [rsp]
000076cd267d4053  vmovaps xmm1, [rsp+0x10]
000076cd267d4059  vmovaps xmm2, [rsp+0x20]
000076cd267d405f  vmovaps xmm3, [rsp+0x30]
000076cd267d4065  vmovaps xmm4, [rsp+0x40]
000076cd267d406b  vmovaps xmm5, [rsp+0x50]
000076cd267d4071  vmovaps xmm6, [rsp+0x60]
000076cd267d4077  vmovaps xmm7, [rsp+0x70]
000076cd267d407d  vmovaps xmm9, [rsp+0x80]
000076cd267d4086  vmovaps xmm10, [rsp+0x90]
000076cd267d408f  vmovaps xmm11, [rsp+0xA0]
000076cd267d4098  vmovaps xmm12, [rsp+0xB0]
000076cd267d40a1  vmovaps xmm13, [rsp+0xC0]
000076cd267d40aa  vmovaps xmm14, [rsp+0xD0]
000076cd267d40b3  vmovaps xmm15, [rsp+0xE0]
000076cd267d40bc  add rsp, 0xF0
000076cd267d40c3  pop r11
000076cd267d40c5  pop r10
000076cd267d40c7  pop r9
000076cd267d40c9  pop r8
000076cd267d40cb  pop rsi
000076cd267d40cc  pop rdi
000076cd267d40cd  pop rdx
000076cd267d40ce  pop rcx
000076cd267d40cf  pop rax
000076cd267d40d0  add rsp, 0x08
000076cd267d40d4  jmp 0x000076CD267D0094
000076cd267d40d9  sub rsp, 0x08
000076cd267d40dd  push rax
000076cd267d40de  push rcx
000076cd267d40df  push rdx
000076cd267d40e0  push rdi
000076cd267d40e1  push rsi
000076cd267d40e2  push r8
000076cd267d40e4  push r9
000076cd267d40e6  push r10
000076cd267d40e8  push r11
000076cd267d40ea  sub rsp, 0xF0
000076cd267d40f1  vmovaps [rsp], xmm0
000076cd267d40f6  vmovaps [rsp+0x10], xmm1
000076cd267d40fc  vmovaps [rsp+0x20], xmm2
000076cd267d4102  vmovaps [rsp+0x30], xmm3
000076cd267d4108  vmovaps [rsp+0x40], xmm4
000076cd267d410e  vmovaps [rsp+0x50], xmm5
000076cd267d4114  vmovaps [rsp+0x60], xmm6
000076cd267d411a  vmovaps [rsp+0x70], xmm7
000076cd267d4120  vmovaps [rsp+0x80], xmm8
000076cd267d4129  vmovaps [rsp+0x90], xmm9
000076cd267d4132  vmovaps [rsp+0xA0], xmm10
000076cd267d413b  vmovaps [rsp+0xB0], xmm11
000076cd267d4144  vmovaps [rsp+0xC0], xmm12
000076cd267d414d  vmovaps [rsp+0xD0], xmm13
000076cd267d4156  vmovaps [rsp+0xE0], xmm15
000076cd267d415f  sub rsp, 0x30
000076cd267d4163  movaps [rsp], xmm14
000076cd267d4168  movaps [rsp+0x10], xmm12
000076cd267d416e  movaps [rsp+0x20], xmm9
000076cd267d4174  lea rdi, [rsp]
000076cd267d4178  mov esi, 0x00
000076cd267d417d  mov rax, 0x56B8861A9530
000076cd267d4187  call rax
000076cd267d4189  movaps xmm14, [rsp]
000076cd267d418e  add rsp, 0x30
000076cd267d4192  vmovaps xmm0, [rsp]
000076cd267d4197  vmovaps xmm1, [rsp+0x10]
000076cd267d419d  vmovaps xmm2, [rsp+0x20]
000076cd267d41a3  vmovaps xmm3, [rsp+0x30]
000076cd267d41a9  vmovaps xmm4, [rsp+0x40]
000076cd267d41af  vmovaps xmm5, [rsp+0x50]
000076cd267d41b5  vmovaps xmm6, [rsp+0x60]
000076cd267d41bb  vmovaps xmm7, [rsp+0x70]
000076cd267d41c1  vmovaps xmm8, [rsp+0x80]
000076cd267d41ca  vmovaps xmm9, [rsp+0x90]
000076cd267d41d3  vmovaps xmm10, [rsp+0xA0]
000076cd267d41dc  vmovaps xmm11, [rsp+0xB0]
000076cd267d41e5  vmovaps xmm12, [rsp+0xC0]
000076cd267d41ee  vmovaps xmm13, [rsp+0xD0]
000076cd267d41f7  vmovaps xmm15, [rsp+0xE0]
000076cd267d4200  add rsp, 0xF0
000076cd267d4207  pop r11
000076cd267d4209  pop r10
000076cd267d420b  pop r9
000076cd267d420d  pop r8
000076cd267d420f  pop rsi
000076cd267d4210  pop rdi
000076cd267d4211  pop rdx
000076cd267d4212  pop rcx
000076cd267d4213  pop rax
000076cd267d4214  add rsp, 0x08
000076cd267d4218  jmp 0x000076CD267D00AE
000076cd267d421d  sub rsp, 0x08
000076cd267d4221  push rax
000076cd267d4222  push rcx
000076cd267d4223  push rdx
000076cd267d4224  push rdi
000076cd267d4225  push rsi
000076cd267d4226  push r8
000076cd267d4228  push r9
000076cd267d422a  push r10
000076cd267d422c  push r11
000076cd267d422e  sub rsp, 0xF0
000076cd267d4235  vmovaps [rsp], xmm0
000076cd267d423a  vmovaps [rsp+0x10], xmm1
000076cd267d4240  vmovaps [rsp+0x20], xmm2
000076cd267d4246  vmovaps [rsp+0x30], xmm3
000076cd267d424c  vmovaps [rsp+0x40], xmm4
000076cd267d4252  vmovaps [rsp+0x50], xmm5
000076cd267d4258  vmovaps [rsp+0x60], xmm6
000076cd267d425e  vmovaps [rsp+0x70], xmm7
000076cd267d4264  vmovaps [rsp+0x80], xmm8
000076cd267d426d  vmovaps [rsp+0x90], xmm10
000076cd267d4276  vmovaps [rsp+0xA0], xmm11
000076cd267d427f  vmovaps [rsp+0xB0], xmm12
000076cd267d4288  vmovaps [rsp+0xC0], xmm13
000076cd267d4291  vmovaps [rsp+0xD0], xmm14
000076cd267d429a  vmovaps [rsp+0xE0], xmm15
000076cd267d42a3  sub rsp, 0x30
000076cd267d42a7  movaps [rsp], xmm9
000076cd267d42ac  movaps [rsp+0x10], xmm7
000076cd267d42b1  movaps [rsp+0x20], xmm12
000076cd267d42b7  lea rdi, [rsp]
000076cd267d42bb  mov esi, 0x00
000076cd267d42c0  mov rax, 0x56B8861A9530
000076cd267d42ca  call rax
000076cd267d42cc  movaps xmm9, [rsp]
000076cd267d42d1  add rsp, 0x30
000076cd267d42d5  vmovaps xmm0, [rsp]
000076cd267d42da  vmovaps xmm1, [rsp+0x10]
000076cd267d42e0  vmovaps xmm2, [rsp+0x20]
000076cd267d42e6  vmovaps xmm3, [rsp+0x30]
000076cd267d42ec  vmovaps xmm4, [rsp+0x40]
000076cd267d42f2  vmovaps xmm5, [rsp+0x50]
000076cd267d42f8  vmovaps xmm6, [rsp+0x60]
000076cd267d42fe  vmovaps xmm7, [rsp+0x70]
000076cd267d4304  vmovaps xmm8, [rsp+0x80]
000076cd267d430d  vmovaps xmm10, [rsp+0x90]
000076cd267d4316  vmovaps xmm11, [rsp+0xA0]
000076cd267d431f  vmovaps xmm12, [rsp+0xB0]
000076cd267d4328  vmovaps xmm13, [rsp+0xC0]
000076cd267d4331  vmovaps xmm14, [rsp+0xD0]
000076cd267d433a  vmovaps xmm15, [rsp+0xE0]
000076cd267d4343  add rsp, 0xF0
000076cd267d434a  pop r11
000076cd267d434c  pop r10
000076cd267d434e  pop r9
000076cd267d4350  pop r8
000076cd267d4352  pop rsi
000076cd267d4353  pop rdi
000076cd267d4354  pop rdx
000076cd267d4355  pop rcx
000076cd267d4356  pop rax
000076cd267d4357  add rsp, 0x08
000076cd267d435b  jmp 0x000076CD267D00DD
000076cd267d4360  sub rsp, 0x08
000076cd267d4364  push rax
000076cd267d4365  push rcx
000076cd267d4366  push rdx
000076cd267d4367  push rdi
000076cd267d4368  push rsi
000076cd267d4369  push r8
000076cd267d436b  push r9
000076cd267d436d  push r10
000076cd267d436f  push r11
000076cd267d4371  sub rsp, 0xF0
000076cd267d4378  vmovaps [rsp], xmm0
000076cd267d437d  vmovaps [rsp+0x10], xmm1
000076cd267d4383  vmovaps [rsp+0x20], xmm2
000076cd267d4389  vmovaps [rsp+0x30], xmm3
000076cd267d438f  vmovaps [rsp+0x40], xmm4
000076cd267d4395  vmovaps [rsp+0x50], xmm5
000076cd267d439b  vmovaps [rsp+0x60], xmm6
000076cd267d43a1  vmovaps [rsp+0x70], xmm7
000076cd267d43a7  vmovaps [rsp+0x80], xmm8
000076cd267d43b0  vmovaps [rsp+0x90], xmm9
000076cd267d43b9  vmovaps [rsp+0xA0], xmm10
000076cd267d43c2  vmovaps [rsp+0xB0], xmm11
000076cd267d43cb  vmovaps [rsp+0xC0], xmm13
000076cd267d43d4  vmovaps [rsp+0xD0], xmm14
000076cd267d43dd  vmovaps [rsp+0xE0], xmm15
000076cd267d43e6  sub rsp, 0x30
000076cd267d43ea  movaps [rsp], xmm12
000076cd267d43ef  movaps [rsp+0x10], xmm15
000076cd267d43f5  movaps [rsp+0x20], xmm11
000076cd267d43fb  lea rdi, [rsp]
000076cd267d43ff  mov esi, 0x00
000076cd267d4404  mov rax, 0x56B8861A9530
000076cd267d440e  call rax
000076cd267d4410  movaps xmm12, [rsp]
000076cd267d4415  add rsp, 0x30
000076cd267d4419  vmovaps xmm0, [rsp]
000076cd267d441e  vmovaps xmm1, [rsp+0x10]
000076cd267d4424  vmovaps xmm2, [rsp+0x20]
000076cd267d442a  vmovaps xmm3, [rsp+0x30]
000076cd267d4430  vmovaps xmm4, [rsp+0x40]
000076cd267d4436  vmovaps xmm5, [rsp+0x50]
000076cd267d443c  vmovaps xmm6, [rsp+0x60]
000076cd267d4442  vmovaps xmm7, [rsp+0x70]
000076cd267d4448  vmovaps xmm8, [rsp+0x80]
000076cd267d4451  vmovaps xmm9, [rsp+0x90]
000076cd267d445a  vmovaps xmm10, [rsp+0xA0]
000076cd267d4463  vmovaps xmm11, [rsp+0xB0]
000076cd267d446c  vmovaps xmm13, [rsp+0xC0]
000076cd267d4475  vmovaps xmm14, [rsp+0xD0]
000076cd267d447e  vmovaps xmm15, [rsp+0xE0]
000076cd267d4487  add rsp, 0xF0
000076cd267d448e  pop r11
000076cd267d4490  pop r10
000076cd267d4492  pop r9
000076cd267d4494  pop r8
000076cd267d4496  pop rsi
000076cd267d4497  pop rdi
000076cd267d4498  pop rdx
000076cd267d4499  pop rcx
000076cd267d449a  pop rax
000076cd267d449b  add rsp, 0x08
000076cd267d449f  jmp 0x000076CD267D00F7
000076cd267d44a4  sub rsp, 0x08
000076cd267d44a8  push rax
000076cd267d44a9  push rcx
000076cd267d44aa  push rdx
000076cd267d44ab  push rdi
000076cd267d44ac  push rsi
000076cd267d44ad  push r8
000076cd267d44af  push r9
000076cd267d44b1  push r10
000076cd267d44b3  push r11
000076cd267d44b5  sub rsp, 0xF0
000076cd267d44bc  vmovaps [rsp], xmm0
000076cd267d44c1  vmovaps [rsp+0x10], xmm1
000076cd267d44c7  vmovaps [rsp+0x20], xmm2
000076cd267d44cd  vmovaps [rsp+0x30], xmm3
000076cd267d44d3  vmovaps [rsp+0x40], xmm4
000076cd267d44d9  vmovaps [rsp+0x50], xmm5
000076cd267d44df  vmovaps [rsp+0x60], xmm6
000076cd267d44e5  vmovaps [rsp+0x70], xmm7
000076cd267d44eb  vmovaps [rsp+0x80], xmm8
000076cd267d44f4  vmovaps [rsp+0x90], xmm9
000076cd267d44fd  vmovaps [rsp+0xA0], xmm10
000076cd267d4506  vmovaps [rsp+0xB0], xmm12
000076cd267d450f  vmovaps [rsp+0xC0], xmm13
000076cd267d4518  vmovaps [rsp+0xD0], xmm14
000076cd267d4521  vmovaps [rsp+0xE0], xmm15
000076cd267d452a  sub rsp, 0x30
000076cd267d452e  movaps [rsp], xmm11
000076cd267d4533  movaps [rsp+0x10], xmm7
000076cd267d4538  movaps [rsp+0x20], xmm15
000076cd267d453e  lea rdi, [rsp]
000076cd267d4542  mov esi, 0x00
000076cd267d4547  mov rax, 0x56B8861A9530
000076cd267d4551  call rax
000076cd267d4553  movaps xmm11, [rsp]
000076cd267d4558  add rsp, 0x30
000076cd267d455c  vmovaps xmm0, [rsp]
000076cd267d4561  vmovaps xmm1, [rsp+0x10]
000076cd267d4567  vmovaps xmm2, [rsp+0x20]
000076cd267d456d  vmovaps xmm3, [rsp+0x30]
000076cd267d4573  vmovaps xmm4, [rsp+0x40]
000076cd267d4579  vmovaps xmm5, [rsp+0x50]
000076cd267d457f  vmovaps xmm6, [rsp+0x60]
000076cd267d4585  vmovaps xmm7, [rsp+0x70]
000076cd267d458b  vmovaps xmm8, [rsp+0x80]
000076cd267d4594  vmovaps xmm9, [rsp+0x90]
000076cd267d459d  vmovaps xmm10, [rsp+0xA0]
000076cd267d45a6  vmovaps xmm12, [rsp+0xB0]
000076cd267d45af  vmovaps xmm13, [rsp+0xC0]
000076cd267d45b8  vmovaps xmm14, [rsp+0xD0]
000076cd267d45c1  vmovaps xmm15, [rsp+0xE0]
000076cd267d45ca  add rsp, 0xF0
000076cd267d45d1  pop r11
000076cd267d45d3  pop r10
000076cd267d45d5  pop r9
000076cd267d45d7  pop r8
000076cd267d45d9  pop rsi
000076cd267d45da  pop rdi
000076cd267d45db  pop rdx
000076cd267d45dc  pop rcx
000076cd267d45dd  pop rax
000076cd267d45de  add rsp, 0x08
000076cd267d45e2  jmp 0x000076CD267D0123
000076cd267d45e7  sub rsp, 0x08
000076cd267d45eb  push rax
000076cd267d45ec  push rcx
000076cd267d45ed  push rdx
000076cd267d45ee  push rdi
000076cd267d45ef  push rsi
000076cd267d45f0  push r8
000076cd267d45f2  push r9
000076cd267d45f4  push r10
000076cd267d45f6  push r11
000076cd267d45f8  sub rsp, 0xF0
000076cd267d45ff  vmovaps [rsp], xmm0
000076cd267d4604  vmovaps [rsp+0x10], xmm1
000076cd267d460a  vmovaps [rsp+0x20], xmm2
000076cd267d4610  vmovaps [rsp+0x30], xmm3
000076cd267d4616  vmovaps [rsp+0x40], xmm4
000076cd267d461c  vmovaps [rsp+0x50], xmm5
000076cd267d4622  vmovaps [rsp+0x60], xmm6
000076cd267d4628  vmovaps [rsp+0x70], xmm7
000076cd267d462e  vmovaps [rsp+0x80], xmm8
000076cd267d4637  vmovaps [rsp+0x90], xmm9
000076cd267d4640  vmovaps [rsp+0xA0], xmm10
000076cd267d4649  vmovaps [rsp+0xB0], xmm11
000076cd267d4652  vmovaps [rsp+0xC0], xmm12
000076cd267d465b  vmovaps [rsp+0xD0], xmm13
000076cd267d4664  vmovaps [rsp+0xE0], xmm14
000076cd267d466d  sub rsp, 0x30
000076cd267d4671  movaps [rsp], xmm15
000076cd267d4676  movaps [rsp+0x10], xmm10
000076cd267d467c  movaps [rsp+0x20], xmm13
000076cd267d4682  lea rdi, [rsp]
000076cd267d4686  mov esi, 0x00
000076cd267d468b  mov rax, 0x56B8861A9530
000076cd267d4695  call rax
000076cd267d4697  movaps xmm15, [rsp]
000076cd267d469c  add rsp, 0x30
000076cd267d46a0  vmovaps xmm0, [rsp]
000076cd267d46a5  vmovaps xmm1, [rsp+0x10]
000076cd267d46ab  vmovaps xmm2, [rsp+0x20]
000076cd267d46b1  vmovaps xmm3, [rsp+0x30]
000076cd267d46b7  vmovaps xmm4, [rsp+0x40]
000076cd267d46bd  vmovaps xmm5, [rsp+0x50]
000076cd267d46c3  vmovaps xmm6, [rsp+0x60]
000076cd267d46c9  vmovaps xmm7, [rsp+0x70]
000076cd267d46cf  vmovaps xmm8, [rsp+0x80]
000076cd267d46d8  vmovaps xmm9, [rsp+0x90]
000076cd267d46e1  vmovaps xmm10, [rsp+0xA0]
000076cd267d46ea  vmovaps xmm11, [rsp+0xB0]
000076cd267d46f3  vmovaps xmm12, [rsp+0xC0]
000076cd267d46fc  vmovaps xmm13, [rsp+0xD0]
000076cd267d4705  vmovaps xmm14, [rsp+0xE0]
000076cd267d470e  add rsp, 0xF0
000076cd267d4715  pop r11
000076cd267d4717  pop r10
000076cd267d4719  pop r9
000076cd267d471b  pop r8
000076cd267d471d  pop rsi
000076cd267d471e  pop rdi
000076cd267d471f  pop rdx
000076cd267d4720  pop rcx
000076cd267d4721  pop rax
000076cd267d4722  add rsp, 0x08
000076cd267d4726  jmp 0x000076CD267D013D
000076cd267d472b  sub rsp, 0x08
000076cd267d472f  push rax
000076cd267d4730  push rcx
000076cd267d4731  push rdx
000076cd267d4732  push rdi
000076cd267d4733  push rsi
000076cd267d4734  push r8
000076cd267d4736  push r9
000076cd267d4738  push r10
000076cd267d473a  push r11
000076cd267d473c  sub rsp, 0xF0
000076cd267d4743  vmovaps [rsp], xmm0
000076cd267d4748  vmovaps [rsp+0x10], xmm1
000076cd267d474e  vmovaps [rsp+0x20], xmm2
000076cd267d4754  vmovaps [rsp+0x30], xmm3
000076cd267d475a  vmovaps [rsp+0x40], xmm4
000076cd267d4760  vmovaps [rsp+0x50], xmm5
000076cd267d4766  vmovaps [rsp+0x60], xmm6
000076cd267d476c  vmovaps [rsp+0x70], xmm7
000076cd267d4772  vmovaps [rsp+0x80], xmm8
000076cd267d477b  vmovaps [rsp+0x90], xmm9
000076cd267d4784  vmovaps [rsp+0xA0], xmm11
000076cd267d478d  vmovaps [rsp+0xB0], xmm12
000076cd267d4796  vmovaps [rsp+0xC0], xmm13
000076cd267d479f  vmovaps [rsp+0xD0], xmm14
000076cd267d47a8  vmovaps [rsp+0xE0], xmm15
000076cd267d47b1  sub rsp, 0x30
000076cd267d47b5  movaps [rsp], xmm10
000076cd267d47ba  movaps [rsp+0x10], xmm7
000076cd267d47bf  movaps [rsp+0x20], xmm13
000076cd267d47c5  lea rdi, [rsp]
000076cd267d47c9  mov esi, 0x00
000076cd267d47ce  mov rax, 0x56B8861A9530
000076cd267d47d8  call rax
000076cd267d47da  movaps xmm10, [rsp]
000076cd267d47df  add rsp, 0x30
000076cd267d47e3  vmovaps xmm0, [rsp]
000076cd267d47e8  vmovaps xmm1, [rsp+0x10]
000076cd267d47ee  vmovaps xmm2, [rsp+0x20]
000076cd267d47f4  vmovaps xmm3, [rsp+0x30]
000076cd267d47fa  vmovaps xmm4, [rsp+0x40]
000076cd267d4800  vmovaps xmm5, [rsp+0x50]
000076cd267d4806  vmovaps xmm6, [rsp+0x60]
000076cd267d480c  vmovaps xmm7, [rsp+0x70]
000076cd267d4812  vmovaps xmm8, [rsp+0x80]
000076cd267d481b  vmovaps xmm9, [rsp+0x90]
000076cd267d4824  vmovaps xmm11, [rsp+0xA0]
000076cd267d482d  vmovaps xmm12, [rsp+0xB0]
000076cd267d4836  vmovaps xmm13, [rsp+0xC0]
000076cd267d483f  vmovaps xmm14, [rsp+0xD0]
000076cd267d4848  vmovaps xmm15, [rsp+0xE0]
000076cd267d4851  add rsp, 0xF0
000076cd267d4858  pop r11
000076cd267d485a  pop r10
000076cd267d485c  pop r9
000076cd267d485e  pop r8
000076cd267d4860  pop rsi
000076cd267d4861  pop rdi
000076cd267d4862  pop rdx
000076cd267d4863  pop rcx
000076cd267d4864  pop rax
000076cd267d4865  add rsp, 0x08
000076cd267d4869  jmp 0x000076CD267D0169
000076cd267d486e  sub rsp, 0x08
000076cd267d4872  push rax
000076cd267d4873  push rcx
000076cd267d4874  push rdx
000076cd267d4875  push rdi
000076cd267d4876  push rsi
000076cd267d4877  push r8
000076cd267d4879  push r9
000076cd267d487b  push r10
000076cd267d487d  push r11
000076cd267d487f  sub rsp, 0xF0
000076cd267d4886  vmovaps [rsp], xmm0
000076cd267d488b  vmovaps [rsp+0x10], xmm1
000076cd267d4891  vmovaps [rsp+0x20], xmm2
000076cd267d4897  vmovaps [rsp+0x30], xmm3
000076cd267d489d  vmovaps [rsp+0x40], xmm4
000076cd267d48a3  vmovaps [rsp+0x50], xmm5
000076cd267d48a9  vmovaps [rsp+0x60], xmm6
000076cd267d48af  vmovaps [rsp+0x70], xmm7
000076cd267d48b5  vmovaps [rsp+0x80], xmm8
000076cd267d48be  vmovaps [rsp+0x90], xmm9
000076cd267d48c7  vmovaps [rsp+0xA0], xmm10
000076cd267d48d0  vmovaps [rsp+0xB0], xmm11
000076cd267d48d9  vmovaps [rsp+0xC0], xmm12
000076cd267d48e2  vmovaps [rsp+0xD0], xmm14
000076cd267d48eb  vmovaps [rsp+0xE0], xmm15
000076cd267d48f4  sub rsp, 0x30
000076cd267d48f8  movaps [rsp], xmm13
000076cd267d48fd  movaps [rsp+0x10], xmm1
000076cd267d4902  movaps [rsp+0x20], xmm8
000076cd267d4908  lea rdi, [rsp]
000076cd267d490c  mov esi, 0x00
000076cd267d4911  mov rax, 0x56B8861A9530
000076cd267d491b  call rax
000076cd267d491d  movaps xmm13, [rsp]
000076cd267d4922  add rsp, 0x30
000076cd267d4926  vmovaps xmm0, [rsp]
000076cd267d492b  vmovaps xmm1, [rsp+0x10]
000076cd267d4931  vmovaps xmm2, [rsp+0x20]
000076cd267d4937  vmovaps xmm3, [rsp+0x30]
000076cd267d493d  vmovaps xmm4, [rsp+0x40]
000076cd267d4943  vmovaps xmm5, [rsp+0x50]
000076cd267d4949  vmovaps xmm6, [rsp+0x60]
000076cd267d494f  vmovaps xmm7, [rsp+0x70]
000076cd267d4955  vmovaps xmm8, [rsp+0x80]
000076cd267d495e  vmovaps xmm9, [rsp+0x90]
000076cd267d4967  vmovaps xmm10, [rsp+0xA0]
000076cd267d4970  vmovaps xmm11, [rsp+0xB0]
000076cd267d4979  vmovaps xmm12, [rsp+0xC0]
000076cd267d4982  vmovaps xmm14, [rsp+0xD0]
000076cd267d498b  vmovaps xmm15, [rsp+0xE0]
000076cd267d4994  add rsp, 0xF0
000076cd267d499b  pop r11
000076cd267d499d  pop r10
000076cd267d499f  pop r9
000076cd267d49a1  pop r8
000076cd267d49a3  pop rsi
000076cd267d49a4  pop rdi
000076cd267d49a5  pop rdx
000076cd267d49a6  pop rcx
000076cd267d49a7  pop rax
000076cd267d49a8  add rsp, 0x08
000076cd267d49ac  jmp 0x000076CD267D0183
000076cd267d49b1  call 0x000076CD265FF430
000076cd267d49b6  jmp 0x000076CD267D018D
000076cd267d49bb  sub rsp, 0x08
000076cd267d49bf  push rax
000076cd267d49c0  push rcx
000076cd267d49c1  push rdx
000076cd267d49c2  push rdi
000076cd267d49c3  push rsi
000076cd267d49c4  push r8
000076cd267d49c6  push r9
000076cd267d49c8  push r10
000076cd267d49ca  push r11
000076cd267d49cc  sub rsp, 0xF0
000076cd267d49d3  vmovaps [rsp], xmm0
000076cd267d49d8  vmovaps [rsp+0x10], xmm1
000076cd267d49de  vmovaps [rsp+0x20], xmm2
000076cd267d49e4  vmovaps [rsp+0x30], xmm3
000076cd267d49ea  vmovaps [rsp+0x40], xmm4
000076cd267d49f0  vmovaps [rsp+0x50], xmm5
000076cd267d49f6  vmovaps [rsp+0x60], xmm6
000076cd267d49fc  vmovaps [rsp+0x70], xmm7
000076cd267d4a02  vmovaps [rsp+0x80], xmm9
000076cd267d4a0b  vmovaps [rsp+0x90], xmm10
000076cd267d4a14  vmovaps [rsp+0xA0], xmm11
000076cd267d4a1d  vmovaps [rsp+0xB0], xmm12
000076cd267d4a26  vmovaps [rsp+0xC0], xmm13
000076cd267d4a2f  vmovaps [rsp+0xD0], xmm14
000076cd267d4a38  vmovaps [rsp+0xE0], xmm15
000076cd267d4a41  sub rsp, 0x30
000076cd267d4a45  movaps [rsp], xmm8
000076cd267d4a4a  movaps [rsp+0x10], xmm14
000076cd267d4a50  movaps [rsp+0x20], xmm9
000076cd267d4a56  lea rdi, [rsp]
000076cd267d4a5a  mov esi, 0x00
000076cd267d4a5f  mov rax, 0x56B8861A9530
000076cd267d4a69  call rax
000076cd267d4a6b  movaps xmm8, [rsp]
000076cd267d4a70  add rsp, 0x30
000076cd267d4a74  vmovaps xmm0, [rsp]
000076cd267d4a79  vmovaps xmm1, [rsp+0x10]
000076cd267d4a7f  vmovaps xmm2, [rsp+0x20]
000076cd267d4a85  vmovaps xmm3, [rsp+0x30]
000076cd267d4a8b  vmovaps xmm4, [rsp+0x40]
000076cd267d4a91  vmovaps xmm5, [rsp+0x50]
000076cd267d4a97  vmovaps xmm6, [rsp+0x60]
000076cd267d4a9d  vmovaps xmm7, [rsp+0x70]
000076cd267d4aa3  vmovaps xmm9, [rsp+0x80]
000076cd267d4aac  vmovaps xmm10, [rsp+0x90]
000076cd267d4ab5  vmovaps xmm11, [rsp+0xA0]
000076cd267d4abe  vmovaps xmm12, [rsp+0xB0]
000076cd267d4ac7  vmovaps xmm13, [rsp+0xC0]
000076cd267d4ad0  vmovaps xmm14, [rsp+0xD0]
000076cd267d4ad9  vmovaps xmm15, [rsp+0xE0]
000076cd267d4ae2  add rsp, 0xF0
000076cd267d4ae9  pop r11
000076cd267d4aeb  pop r10
000076cd267d4aed  pop r9
000076cd267d4aef  pop r8
000076cd267d4af1  pop rsi
000076cd267d4af2  pop rdi
000076cd267d4af3  pop rdx
000076cd267d4af4  pop rcx
000076cd267d4af5  pop rax
000076cd267d4af6  add rsp, 0x08
000076cd267d4afa  jmp 0x000076CD267D01AF
000076cd267d4aff  sub rsp, 0x08
000076cd267d4b03  push rax
000076cd267d4b04  push rcx
000076cd267d4b05  push rdx
000076cd267d4b06  push rdi
000076cd267d4b07  push rsi
000076cd267d4b08  push r8
000076cd267d4b0a  push r9
000076cd267d4b0c  push r10
000076cd267d4b0e  push r11
000076cd267d4b10  sub rsp, 0xF0
000076cd267d4b17  vmovaps [rsp], xmm0
000076cd267d4b1c  vmovaps [rsp+0x10], xmm1
000076cd267d4b22  vmovaps [rsp+0x20], xmm2
000076cd267d4b28  vmovaps [rsp+0x30], xmm3
000076cd267d4b2e  vmovaps [rsp+0x40], xmm4
000076cd267d4b34  vmovaps [rsp+0x50], xmm5
000076cd267d4b3a  vmovaps [rsp+0x60], xmm6
000076cd267d4b40  vmovaps [rsp+0x70], xmm7
000076cd267d4b46  vmovaps [rsp+0x80], xmm8
000076cd267d4b4f  vmovaps [rsp+0x90], xmm10
000076cd267d4b58  vmovaps [rsp+0xA0], xmm11
000076cd267d4b61  vmovaps [rsp+0xB0], xmm12
000076cd267d4b6a  vmovaps [rsp+0xC0], xmm13
000076cd267d4b73  vmovaps [rsp+0xD0], xmm14
000076cd267d4b7c  vmovaps [rsp+0xE0], xmm15
000076cd267d4b85  sub rsp, 0x30
000076cd267d4b89  movaps [rsp], xmm9
000076cd267d4b8e  movaps [rsp+0x10], xmm1
000076cd267d4b93  movaps [rsp+0x20], xmm14
000076cd267d4b99  lea rdi, [rsp]
000076cd267d4b9d  mov esi, 0x00
000076cd267d4ba2  mov rax, 0x56B8861A9530
000076cd267d4bac  call rax
000076cd267d4bae  movaps xmm9, [rsp]
000076cd267d4bb3  add rsp, 0x30
000076cd267d4bb7  vmovaps xmm0, [rsp]
000076cd267d4bbc  vmovaps xmm1, [rsp+0x10]
000076cd267d4bc2  vmovaps xmm2, [rsp+0x20]
000076cd267d4bc8  vmovaps xmm3, [rsp+0x30]
000076cd267d4bce  vmovaps xmm4, [rsp+0x40]
000076cd267d4bd4  vmovaps xmm5, [rsp+0x50]
000076cd267d4bda  vmovaps xmm6, [rsp+0x60]
000076cd267d4be0  vmovaps xmm7, [rsp+0x70]
000076cd267d4be6  vmovaps xmm8, [rsp+0x80]
000076cd267d4bef  vmovaps xmm10, [rsp+0x90]
000076cd267d4bf8  vmovaps xmm11, [rsp+0xA0]
000076cd267d4c01  vmovaps xmm12, [rsp+0xB0]
000076cd267d4c0a  vmovaps xmm13, [rsp+0xC0]
000076cd267d4c13  vmovaps xmm14, [rsp+0xD0]
000076cd267d4c1c  vmovaps xmm15, [rsp+0xE0]
000076cd267d4c25  add rsp, 0xF0
000076cd267d4c2c  pop r11
000076cd267d4c2e  pop r10
000076cd267d4c30  pop r9
000076cd267d4c32  pop r8
000076cd267d4c34  pop rsi
000076cd267d4c35  pop rdi
000076cd267d4c36  pop rdx
000076cd267d4c37  pop rcx
000076cd267d4c38  pop rax
000076cd267d4c39  add rsp, 0x08
000076cd267d4c3d  jmp 0x000076CD267D01DD
000076cd267d4c42  sub rsp, 0x08
000076cd267d4c46  push rax
000076cd267d4c47  push rcx
000076cd267d4c48  push rdx
000076cd267d4c49  push rdi
000076cd267d4c4a  push rsi
000076cd267d4c4b  push r8
000076cd267d4c4d  push r9
000076cd267d4c4f  push r10
000076cd267d4c51  push r11
000076cd267d4c53  sub rsp, 0xF0
000076cd267d4c5a  vmovaps [rsp], xmm0
000076cd267d4c5f  vmovaps [rsp+0x10], xmm1
000076cd267d4c65  vmovaps [rsp+0x20], xmm2
000076cd267d4c6b  vmovaps [rsp+0x30], xmm3
000076cd267d4c71  vmovaps [rsp+0x40], xmm4
000076cd267d4c77  vmovaps [rsp+0x50], xmm5
000076cd267d4c7d  vmovaps [rsp+0x60], xmm6
000076cd267d4c83  vmovaps [rsp+0x70], xmm7
000076cd267d4c89  vmovaps [rsp+0x80], xmm8
000076cd267d4c92  vmovaps [rsp+0x90], xmm9
000076cd267d4c9b  vmovaps [rsp+0xA0], xmm10
000076cd267d4ca4  vmovaps [rsp+0xB0], xmm11
000076cd267d4cad  vmovaps [rsp+0xC0], xmm12
000076cd267d4cb6  vmovaps [rsp+0xD0], xmm13
000076cd267d4cbf  vmovaps [rsp+0xE0], xmm15
000076cd267d4cc8  sub rsp, 0x30
000076cd267d4ccc  movaps [rsp], xmm14
000076cd267d4cd1  movaps [rsp+0x10], xmm4
000076cd267d4cd6  movaps [rsp+0x20], xmm1
000076cd267d4cdb  lea rdi, [rsp]
000076cd267d4cdf  mov esi, 0x00
000076cd267d4ce4  mov rax, 0x56B8861A9530
000076cd267d4cee  call rax
000076cd267d4cf0  movaps xmm14, [rsp]
000076cd267d4cf5  add rsp, 0x30
000076cd267d4cf9  vmovaps xmm0, [rsp]
000076cd267d4cfe  vmovaps xmm1, [rsp+0x10]
000076cd267d4d04  vmovaps xmm2, [rsp+0x20]
000076cd267d4d0a  vmovaps xmm3, [rsp+0x30]
000076cd267d4d10  vmovaps xmm4, [rsp+0x40]
000076cd267d4d16  vmovaps xmm5, [rsp+0x50]
000076cd267d4d1c  vmovaps xmm6, [rsp+0x60]
000076cd267d4d22  vmovaps xmm7, [rsp+0x70]
000076cd267d4d28  vmovaps xmm8, [rsp+0x80]
000076cd267d4d31  vmovaps xmm9, [rsp+0x90]
000076cd267d4d3a  vmovaps xmm10, [rsp+0xA0]
000076cd267d4d43  vmovaps xmm11, [rsp+0xB0]
000076cd267d4d4c  vmovaps xmm12, [rsp+0xC0]
000076cd267d4d55  vmovaps xmm13, [rsp+0xD0]
000076cd267d4d5e  vmovaps xmm15, [rsp+0xE0]
000076cd267d4d67  add rsp, 0xF0
000076cd267d4d6e  pop r11
000076cd267d4d70  pop r10
000076cd267d4d72  pop r9
000076cd267d4d74  pop r8
000076cd267d4d76  pop rsi
000076cd267d4d77  pop rdi
000076cd267d4d78  pop rdx
000076cd267d4d79  pop rcx
000076cd267d4d7a  pop rax
000076cd267d4d7b  add rsp, 0x08
000076cd267d4d7f  jmp 0x000076CD267D0203
000076cd267d4d84  sub rsp, 0x08
000076cd267d4d88  push rax
000076cd267d4d89  push rcx
000076cd267d4d8a  push rdx
000076cd267d4d8b  push rdi
000076cd267d4d8c  push rsi
000076cd267d4d8d  push r8
000076cd267d4d8f  push r9
000076cd267d4d91  push r10
000076cd267d4d93  push r11
000076cd267d4d95  sub rsp, 0xF0
000076cd267d4d9c  vmovaps [rsp], xmm0
000076cd267d4da1  vmovaps [rsp+0x10], xmm2
000076cd267d4da7  vmovaps [rsp+0x20], xmm3
000076cd267d4dad  vmovaps [rsp+0x30], xmm4
000076cd267d4db3  vmovaps [rsp+0x40], xmm5
000076cd267d4db9  vmovaps [rsp+0x50], xmm6
000076cd267d4dbf  vmovaps [rsp+0x60], xmm7
000076cd267d4dc5  vmovaps [rsp+0x70], xmm8
000076cd267d4dcb  vmovaps [rsp+0x80], xmm9
000076cd267d4dd4  vmovaps [rsp+0x90], xmm10
000076cd267d4ddd  vmovaps [rsp+0xA0], xmm11
000076cd267d4de6  vmovaps [rsp+0xB0], xmm12
000076cd267d4def  vmovaps [rsp+0xC0], xmm13
000076cd267d4df8  vmovaps [rsp+0xD0], xmm14
000076cd267d4e01  vmovaps [rsp+0xE0], xmm15
000076cd267d4e0a  sub rsp, 0x30
000076cd267d4e0e  movaps [rsp], xmm1
000076cd267d4e12  movaps [rsp+0x10], xmm12
000076cd267d4e18  movaps [rsp+0x20], xmm11
000076cd267d4e1e  lea rdi, [rsp]
000076cd267d4e22  mov esi, 0x00
000076cd267d4e27  mov rax, 0x56B8861A9530
000076cd267d4e31  call rax
000076cd267d4e33  movaps xmm1, [rsp]
000076cd267d4e37  add rsp, 0x30
000076cd267d4e3b  vmovaps xmm0, [rsp]
000076cd267d4e40  vmovaps xmm2, [rsp+0x10]
000076cd267d4e46  vmovaps xmm3, [rsp+0x20]
000076cd267d4e4c  vmovaps xmm4, [rsp+0x30]
000076cd267d4e52  vmovaps xmm5, [rsp+0x40]
000076cd267d4e58  vmovaps xmm6, [rsp+0x50]
000076cd267d4e5e  vmovaps xmm7, [rsp+0x60]
000076cd267d4e64  vmovaps xmm8, [rsp+0x70]
000076cd267d4e6a  vmovaps xmm9, [rsp+0x80]
000076cd267d4e73  vmovaps xmm10, [rsp+0x90]
000076cd267d4e7c  vmovaps xmm11, [rsp+0xA0]
000076cd267d4e85  vmovaps xmm12, [rsp+0xB0]
000076cd267d4e8e  vmovaps xmm13, [rsp+0xC0]
000076cd267d4e97  vmovaps xmm14, [rsp+0xD0]
000076cd267d4ea0  vmovaps xmm15, [rsp+0xE0]
000076cd267d4ea9  add rsp, 0xF0
000076cd267d4eb0  pop r11
000076cd267d4eb2  pop r10
000076cd267d4eb4  pop r9
000076cd267d4eb6  pop r8
000076cd267d4eb8  pop rsi
000076cd267d4eb9  pop rdi
000076cd267d4eba  pop rdx
000076cd267d4ebb  pop rcx
000076cd267d4ebc  pop rax
000076cd267d4ebd  add rsp, 0x08
000076cd267d4ec1  jmp 0x000076CD267D0224
000076cd267d4ec6  call 0x000076CD266E20A0
000076cd267d4ecb  jmp 0x000076CD267D0232
000076cd267d4ed0  call 0x000076CD26609D70
000076cd267d4ed5  jmp 0x000076CD267D023C
000076cd267d4eda  sub rsp, 0x08
000076cd267d4ede  push rax
000076cd267d4edf  push rcx
000076cd267d4ee0  push rdx
000076cd267d4ee1  push rdi
000076cd267d4ee2  push rsi
000076cd267d4ee3  push r8
000076cd267d4ee5  push r9
000076cd267d4ee7  push r10
000076cd267d4ee9  push r11
000076cd267d4eeb  sub rsp, 0xF0
000076cd267d4ef2  vmovaps [rsp], xmm0
000076cd267d4ef7  vmovaps [rsp+0x10], xmm1
000076cd267d4efd  vmovaps [rsp+0x20], xmm2
000076cd267d4f03  vmovaps [rsp+0x30], xmm3
000076cd267d4f09  vmovaps [rsp+0x40], xmm4
000076cd267d4f0f  vmovaps [rsp+0x50], xmm5
000076cd267d4f15  vmovaps [rsp+0x60], xmm6
000076cd267d4f1b  vmovaps [rsp+0x70], xmm8
000076cd267d4f21  vmovaps [rsp+0x80], xmm9
000076cd267d4f2a  vmovaps [rsp+0x90], xmm10
000076cd267d4f33  vmovaps [rsp+0xA0], xmm11
000076cd267d4f3c  vmovaps [rsp+0xB0], xmm12
000076cd267d4f45  vmovaps [rsp+0xC0], xmm13
000076cd267d4f4e  vmovaps [rsp+0xD0], xmm14
000076cd267d4f57  vmovaps [rsp+0xE0], xmm15
000076cd267d4f60  sub rsp, 0x30
000076cd267d4f64  movaps [rsp], xmm7
000076cd267d4f68  movaps [rsp+0x10], xmm15
000076cd267d4f6e  movaps [rsp+0x20], xmm10
000076cd267d4f74  lea rdi, [rsp]
000076cd267d4f78  mov esi, 0x00
000076cd267d4f7d  mov rax, 0x56B8861A9530
000076cd267d4f87  call rax
000076cd267d4f89  movaps xmm7, [rsp]
000076cd267d4f8d  add rsp, 0x30
000076cd267d4f91  vmovaps xmm0, [rsp]
000076cd267d4f96  vmovaps xmm1, [rsp+0x10]
000076cd267d4f9c  vmovaps xmm2, [rsp+0x20]
000076cd267d4fa2  vmovaps xmm3, [rsp+0x30]
000076cd267d4fa8  vmovaps xmm4, [rsp+0x40]
000076cd267d4fae  vmovaps xmm5, [rsp+0x50]
000076cd267d4fb4  vmovaps xmm6, [rsp+0x60]
000076cd267d4fba  vmovaps xmm8, [rsp+0x70]
000076cd267d4fc0  vmovaps xmm9, [rsp+0x80]
000076cd267d4fc9  vmovaps xmm10, [rsp+0x90]
000076cd267d4fd2  vmovaps xmm11, [rsp+0xA0]
000076cd267d4fdb  vmovaps xmm12, [rsp+0xB0]
000076cd267d4fe4  vmovaps xmm13, [rsp+0xC0]
000076cd267d4fed  vmovaps xmm14, [rsp+0xD0]
000076cd267d4ff6  vmovaps xmm15, [rsp+0xE0]
000076cd267d4fff  add rsp, 0xF0
000076cd267d5006  pop r11
000076cd267d5008  pop r10
000076cd267d500a  pop r9
000076cd267d500c  pop r8
000076cd267d500e  pop rsi
000076cd267d500f  pop rdi
000076cd267d5010  pop rdx
000076cd267d5011  pop rcx
000076cd267d5012  pop rax
000076cd267d5013  add rsp, 0x08
000076cd267d5017  jmp 0x000076CD267D025D
000076cd267d501c  sub rsp, 0x08
000076cd267d5020  push rax
000076cd267d5021  push rcx
000076cd267d5022  push rdx
000076cd267d5023  push rdi
000076cd267d5024  push rsi
000076cd267d5025  push r8
000076cd267d5027  push r9
000076cd267d5029  push r10
000076cd267d502b  push r11
000076cd267d502d  sub rsp, 0xF0
000076cd267d5034  vmovaps [rsp], xmm0
000076cd267d5039  vmovaps [rsp+0x10], xmm1
000076cd267d503f  vmovaps [rsp+0x20], xmm2
000076cd267d5045  vmovaps [rsp+0x30], xmm3
000076cd267d504b  vmovaps [rsp+0x40], xmm4
000076cd267d5051  vmovaps [rsp+0x50], xmm5
000076cd267d5057  vmovaps [rsp+0x60], xmm6
000076cd267d505d  vmovaps [rsp+0x70], xmm7
000076cd267d5063  vmovaps [rsp+0x80], xmm8
000076cd267d506c  vmovaps [rsp+0x90], xmm9
000076cd267d5075  vmovaps [rsp+0xA0], xmm11
000076cd267d507e  vmovaps [rsp+0xB0], xmm12
000076cd267d5087  vmovaps [rsp+0xC0], xmm13
000076cd267d5090  vmovaps [rsp+0xD0], xmm14
000076cd267d5099  vmovaps [rsp+0xE0], xmm15
000076cd267d50a2  sub rsp, 0x30
000076cd267d50a6  movaps [rsp], xmm10
000076cd267d50ab  movaps [rsp+0x10], xmm11
000076cd267d50b1  movaps [rsp+0x20], xmm15
000076cd267d50b7  lea rdi, [rsp]
000076cd267d50bb  mov esi, 0x00
000076cd267d50c0  mov rax, 0x56B8861A9530
000076cd267d50ca  call rax
000076cd267d50cc  movaps xmm10, [rsp]
000076cd267d50d1  add rsp, 0x30
000076cd267d50d5  vmovaps xmm0, [rsp]
000076cd267d50da  vmovaps xmm1, [rsp+0x10]
000076cd267d50e0  vmovaps xmm2, [rsp+0x20]
000076cd267d50e6  vmovaps xmm3, [rsp+0x30]
000076cd267d50ec  vmovaps xmm4, [rsp+0x40]
000076cd267d50f2  vmovaps xmm5, [rsp+0x50]
000076cd267d50f8  vmovaps xmm6, [rsp+0x60]
000076cd267d50fe  vmovaps xmm7, [rsp+0x70]
000076cd267d5104  vmovaps xmm8, [rsp+0x80]
000076cd267d510d  vmovaps xmm9, [rsp+0x90]
000076cd267d5116  vmovaps xmm11, [rsp+0xA0]
000076cd267d511f  vmovaps xmm12, [rsp+0xB0]
000076cd267d5128  vmovaps xmm13, [rsp+0xC0]
000076cd267d5131  vmovaps xmm14, [rsp+0xD0]
000076cd267d513a  vmovaps xmm15, [rsp+0xE0]
000076cd267d5143  add rsp, 0xF0
000076cd267d514a  pop r11
000076cd267d514c  pop r10
000076cd267d514e  pop r9
000076cd267d5150  pop r8
000076cd267d5152  pop rsi
000076cd267d5153  pop rdi
000076cd267d5154  pop rdx
000076cd267d5155  pop rcx
000076cd267d5156  pop rax
000076cd267d5157  add rsp, 0x08
000076cd267d515b  jmp 0x000076CD267D028B
000076cd267d5160  sub rsp, 0x08
000076cd267d5164  push rax
000076cd267d5165  push rcx
000076cd267d5166  push rdx
000076cd267d5167  push rdi
000076cd267d5168  push rsi
000076cd267d5169  push r8
000076cd267d516b  push r9
000076cd267d516d  push r10
000076cd267d516f  push r11
000076cd267d5171  sub rsp, 0xF0
000076cd267d5178  vmovaps [rsp], xmm0
000076cd267d517d  vmovaps [rsp+0x10], xmm1
000076cd267d5183  vmovaps [rsp+0x20], xmm2
000076cd267d5189  vmovaps [rsp+0x30], xmm3
000076cd267d518f  vmovaps [rsp+0x40], xmm4
000076cd267d5195  vmovaps [rsp+0x50], xmm5
000076cd267d519b  vmovaps [rsp+0x60], xmm6
000076cd267d51a1  vmovaps [rsp+0x70], xmm7
000076cd267d51a7  vmovaps [rsp+0x80], xmm8
000076cd267d51b0  vmovaps [rsp+0x90], xmm9
000076cd267d51b9  vmovaps [rsp+0xA0], xmm10
000076cd267d51c2  vmovaps [rsp+0xB0], xmm12
000076cd267d51cb  vmovaps [rsp+0xC0], xmm13
000076cd267d51d4  vmovaps [rsp+0xD0], xmm14
000076cd267d51dd  vmovaps [rsp+0xE0], xmm15
000076cd267d51e6  sub rsp, 0x30
000076cd267d51ea  movaps [rsp], xmm11
000076cd267d51ef  movaps [rsp+0x10], xmm12
000076cd267d51f5  movaps [rsp+0x20], xmm15
000076cd267d51fb  lea rdi, [rsp]
000076cd267d51ff  mov esi, 0x00
000076cd267d5204  mov rax, 0x56B8861A9530
000076cd267d520e  call rax
000076cd267d5210  movaps xmm11, [rsp]
000076cd267d5215  add rsp, 0x30
000076cd267d5219  vmovaps xmm0, [rsp]
000076cd267d521e  vmovaps xmm1, [rsp+0x10]
000076cd267d5224  vmovaps xmm2, [rsp+0x20]
000076cd267d522a  vmovaps xmm3, [rsp+0x30]
000076cd267d5230  vmovaps xmm4, [rsp+0x40]
000076cd267d5236  vmovaps xmm5, [rsp+0x50]
000076cd267d523c  vmovaps xmm6, [rsp+0x60]
000076cd267d5242  vmovaps xmm7, [rsp+0x70]
000076cd267d5248  vmovaps xmm8, [rsp+0x80]
000076cd267d5251  vmovaps xmm9, [rsp+0x90]
000076cd267d525a  vmovaps xmm10, [rsp+0xA0]
000076cd267d5263  vmovaps xmm12, [rsp+0xB0]
000076cd267d526c  vmovaps xmm13, [rsp+0xC0]
000076cd267d5275  vmovaps xmm14, [rsp+0xD0]
000076cd267d527e  vmovaps xmm15, [rsp+0xE0]
000076cd267d5287  add rsp, 0xF0
000076cd267d528e  pop r11
000076cd267d5290  pop r10
000076cd267d5292  pop r9
000076cd267d5294  pop r8
000076cd267d5296  pop rsi
000076cd267d5297  pop rdi
000076cd267d5298  pop rdx
000076cd267d5299  pop rcx
000076cd267d529a  pop rax
000076cd267d529b  add rsp, 0x08
000076cd267d529f  jmp 0x000076CD267D02B9
000076cd267d52a4  sub rsp, 0x08
000076cd267d52a8  push rax
000076cd267d52a9  push rcx
000076cd267d52aa  push rdx
000076cd267d52ab  push rdi
000076cd267d52ac  push rsi
000076cd267d52ad  push r8
000076cd267d52af  push r9
000076cd267d52b1  push r10
000076cd267d52b3  push r11
000076cd267d52b5  sub rsp, 0xF0
000076cd267d52bc  vmovaps [rsp], xmm0
000076cd267d52c1  vmovaps [rsp+0x10], xmm1
000076cd267d52c7  vmovaps [rsp+0x20], xmm2
000076cd267d52cd  vmovaps [rsp+0x30], xmm3
000076cd267d52d3  vmovaps [rsp+0x40], xmm4
000076cd267d52d9  vmovaps [rsp+0x50], xmm5
000076cd267d52df  vmovaps [rsp+0x60], xmm6
000076cd267d52e5  vmovaps [rsp+0x70], xmm7
000076cd267d52eb  vmovaps [rsp+0x80], xmm8
000076cd267d52f4  vmovaps [rsp+0x90], xmm9
000076cd267d52fd  vmovaps [rsp+0xA0], xmm10
000076cd267d5306  vmovaps [rsp+0xB0], xmm11
000076cd267d530f  vmovaps [rsp+0xC0], xmm12
000076cd267d5318  vmovaps [rsp+0xD0], xmm13
000076cd267d5321  vmovaps [rsp+0xE0], xmm14
000076cd267d532a  sub rsp, 0x30
000076cd267d532e  movaps [rsp], xmm15
000076cd267d5333  movaps [rsp+0x10], xmm13
000076cd267d5339  movaps [rsp+0x20], xmm9
000076cd267d533f  lea rdi, [rsp]
000076cd267d5343  mov esi, 0x00
000076cd267d5348  mov rax, 0x56B8861A9530
000076cd267d5352  call rax
000076cd267d5354  movaps xmm15, [rsp]
000076cd267d5359  add rsp, 0x30
000076cd267d535d  vmovaps xmm0, [rsp]
000076cd267d5362  vmovaps xmm1, [rsp+0x10]
000076cd267d5368  vmovaps xmm2, [rsp+0x20]
000076cd267d536e  vmovaps xmm3, [rsp+0x30]
000076cd267d5374  vmovaps xmm4, [rsp+0x40]
000076cd267d537a  vmovaps xmm5, [rsp+0x50]
000076cd267d5380  vmovaps xmm6, [rsp+0x60]
000076cd267d5386  vmovaps xmm7, [rsp+0x70]
000076cd267d538c  vmovaps xmm8, [rsp+0x80]
000076cd267d5395  vmovaps xmm9, [rsp+0x90]
000076cd267d539e  vmovaps xmm10, [rsp+0xA0]
000076cd267d53a7  vmovaps xmm11, [rsp+0xB0]
000076cd267d53b0  vmovaps xmm12, [rsp+0xC0]
000076cd267d53b9  vmovaps xmm13, [rsp+0xD0]
000076cd267d53c2  vmovaps xmm14, [rsp+0xE0]
000076cd267d53cb  add rsp, 0xF0
000076cd267d53d2  pop r11
000076cd267d53d4  pop r10
000076cd267d53d6  pop r9
000076cd267d53d8  pop r8
000076cd267d53da  pop rsi
000076cd267d53db  pop rdi
000076cd267d53dc  pop rdx
000076cd267d53dd  pop rcx
000076cd267d53de  pop rax
000076cd267d53df  add rsp, 0x08
000076cd267d53e3  jmp 0x000076CD267D02D4
000076cd267d53e8  sub rsp, 0x08
000076cd267d53ec  push rax
000076cd267d53ed  push rcx
000076cd267d53ee  push rdx
000076cd267d53ef  push rdi
000076cd267d53f0  push rsi
000076cd267d53f1  push r8
000076cd267d53f3  push r9
000076cd267d53f5  push r10
000076cd267d53f7  push r11
000076cd267d53f9  sub rsp, 0xF0
000076cd267d5400  vmovaps [rsp], xmm0
000076cd267d5405  vmovaps [rsp+0x10], xmm1
000076cd267d540b  vmovaps [rsp+0x20], xmm2
000076cd267d5411  vmovaps [rsp+0x30], xmm3
000076cd267d5417  vmovaps [rsp+0x40], xmm4
000076cd267d541d  vmovaps [rsp+0x50], xmm5
000076cd267d5423  vmovaps [rsp+0x60], xmm6
000076cd267d5429  vmovaps [rsp+0x70], xmm7
000076cd267d542f  vmovaps [rsp+0x80], xmm8
000076cd267d5438  vmovaps [rsp+0x90], xmm9
000076cd267d5441  vmovaps [rsp+0xA0], xmm10
000076cd267d544a  vmovaps [rsp+0xB0], xmm11
000076cd267d5453  vmovaps [rsp+0xC0], xmm12
000076cd267d545c  vmovaps [rsp+0xD0], xmm14
000076cd267d5465  vmovaps [rsp+0xE0], xmm15
000076cd267d546e  sub rsp, 0x30
000076cd267d5472  movaps [rsp], xmm13
000076cd267d5477  movaps [rsp+0x10], xmm8
000076cd267d547d  movaps [rsp+0x20], xmm14
000076cd267d5483  lea rdi, [rsp]
000076cd267d5487  mov esi, 0x00
000076cd267d548c  mov rax, 0x56B8861A9530
000076cd267d5496  call rax
000076cd267d5498  movaps xmm13, [rsp]
000076cd267d549d  add rsp, 0x30
000076cd267d54a1  vmovaps xmm0, [rsp]
000076cd267d54a6  vmovaps xmm1, [rsp+0x10]
000076cd267d54ac  vmovaps xmm2, [rsp+0x20]
000076cd267d54b2  vmovaps xmm3, [rsp+0x30]
000076cd267d54b8  vmovaps xmm4, [rsp+0x40]
000076cd267d54be  vmovaps xmm5, [rsp+0x50]
000076cd267d54c4  vmovaps xmm6, [rsp+0x60]
000076cd267d54ca  vmovaps xmm7, [rsp+0x70]
000076cd267d54d0  vmovaps xmm8, [rsp+0x80]
000076cd267d54d9  vmovaps xmm9, [rsp+0x90]
000076cd267d54e2  vmovaps xmm10, [rsp+0xA0]
000076cd267d54eb  vmovaps xmm11, [rsp+0xB0]
000076cd267d54f4  vmovaps xmm12, [rsp+0xC0]
000076cd267d54fd  vmovaps xmm14, [rsp+0xD0]
000076cd267d5506  vmovaps xmm15, [rsp+0xE0]
000076cd267d550f  add rsp, 0xF0
000076cd267d5516  pop r11
000076cd267d5518  pop r10
000076cd267d551a  pop r9
000076cd267d551c  pop r8
000076cd267d551e  pop rsi
000076cd267d551f  pop rdi
000076cd267d5520  pop rdx
000076cd267d5521  pop rcx
000076cd267d5522  pop rax
000076cd267d5523  add rsp, 0x08
000076cd267d5527  jmp 0x000076CD267D02F7
000076cd267d552c  sub rsp, 0x08
000076cd267d5530  push rax
000076cd267d5531  push rcx
000076cd267d5532  push rdx
000076cd267d5533  push rdi
000076cd267d5534  push rsi
000076cd267d5535  push r8
000076cd267d5537  push r9
000076cd267d5539  push r10
000076cd267d553b  push r11
000076cd267d553d  sub rsp, 0xF0
000076cd267d5544  vmovaps [rsp], xmm0
000076cd267d5549  vmovaps [rsp+0x10], xmm1
000076cd267d554f  vmovaps [rsp+0x20], xmm2
000076cd267d5555  vmovaps [rsp+0x30], xmm3
000076cd267d555b  vmovaps [rsp+0x40], xmm4
000076cd267d5561  vmovaps [rsp+0x50], xmm5
000076cd267d5567  vmovaps [rsp+0x60], xmm6
000076cd267d556d  vmovaps [rsp+0x70], xmm7
000076cd267d5573  vmovaps [rsp+0x80], xmm8
000076cd267d557c  vmovaps [rsp+0x90], xmm9
000076cd267d5585  vmovaps [rsp+0xA0], xmm10
000076cd267d558e  vmovaps [rsp+0xB0], xmm11
000076cd267d5597  vmovaps [rsp+0xC0], xmm12
000076cd267d55a0  vmovaps [rsp+0xD0], xmm13
000076cd267d55a9  vmovaps [rsp+0xE0], xmm15
000076cd267d55b2  sub rsp, 0x30
000076cd267d55b6  movaps [rsp], xmm14
000076cd267d55bb  movaps [rsp+0x10], xmm1
000076cd267d55c0  movaps [rsp+0x20], xmm10
000076cd267d55c6  lea rdi, [rsp]
000076cd267d55ca  mov esi, 0x00
000076cd267d55cf  mov rax, 0x56B8861A9530
000076cd267d55d9  call rax
000076cd267d55db  movaps xmm14, [rsp]
000076cd267d55e0  add rsp, 0x30
000076cd267d55e4  vmovaps xmm0, [rsp]
000076cd267d55e9  vmovaps xmm1, [rsp+0x10]
000076cd267d55ef  vmovaps xmm2, [rsp+0x20]
000076cd267d55f5  vmovaps xmm3, [rsp+0x30]
000076cd267d55fb  vmovaps xmm4, [rsp+0x40]
000076cd267d5601  vmovaps xmm5, [rsp+0x50]
000076cd267d5607  vmovaps xmm6, [rsp+0x60]
000076cd267d560d  vmovaps xmm7, [rsp+0x70]
000076cd267d5613  vmovaps xmm8, [rsp+0x80]
000076cd267d561c  vmovaps xmm9, [rsp+0x90]
000076cd267d5625  vmovaps xmm10, [rsp+0xA0]
000076cd267d562e  vmovaps xmm11, [rsp+0xB0]
000076cd267d5637  vmovaps xmm12, [rsp+0xC0]
000076cd267d5640  vmovaps xmm13, [rsp+0xD0]
000076cd267d5649  vmovaps xmm15, [rsp+0xE0]
000076cd267d5652  add rsp, 0xF0
000076cd267d5659  pop r11
000076cd267d565b  pop r10
000076cd267d565d  pop r9
000076cd267d565f  pop r8
000076cd267d5661  pop rsi
000076cd267d5662  pop rdi
000076cd267d5663  pop rdx
000076cd267d5664  pop rcx
000076cd267d5665  pop rax
000076cd267d5666  add rsp, 0x08
000076cd267d566a  jmp 0x000076CD267D031A
000076cd267d566f  sub rsp, 0x08
000076cd267d5673  push rax
000076cd267d5674  push rcx
000076cd267d5675  push rdx
000076cd267d5676  push rdi
000076cd267d5677  push rsi
000076cd267d5678  push r8
000076cd267d567a  push r9
000076cd267d567c  push r10
000076cd267d567e  push r11
000076cd267d5680  sub rsp, 0xF0
000076cd267d5687  vmovaps [rsp], xmm0
000076cd267d568c  vmovaps [rsp+0x10], xmm2
000076cd267d5692  vmovaps [rsp+0x20], xmm3
000076cd267d5698  vmovaps [rsp+0x30], xmm4
000076cd267d569e  vmovaps [rsp+0x40], xmm5
000076cd267d56a4  vmovaps [rsp+0x50], xmm6
000076cd267d56aa  vmovaps [rsp+0x60], xmm7
000076cd267d56b0  vmovaps [rsp+0x70], xmm8
000076cd267d56b6  vmovaps [rsp+0x80], xmm9
000076cd267d56bf  vmovaps [rsp+0x90], xmm10
000076cd267d56c8  vmovaps [rsp+0xA0], xmm11
000076cd267d56d1  vmovaps [rsp+0xB0], xmm12
000076cd267d56da  vmovaps [rsp+0xC0], xmm13
000076cd267d56e3  vmovaps [rsp+0xD0], xmm14
000076cd267d56ec  vmovaps [rsp+0xE0], xmm15
000076cd267d56f5  sub rsp, 0x30
000076cd267d56f9  movaps [rsp], xmm1
000076cd267d56fd  movaps [rsp+0x10], xmm7
000076cd267d5702  movaps [rsp+0x20], xmm11
000076cd267d5708  lea rdi, [rsp]
000076cd267d570c  mov esi, 0x00
000076cd267d5711  mov rax, 0x56B8861A9530
000076cd267d571b  call rax
000076cd267d571d  movaps xmm1, [rsp]
000076cd267d5721  add rsp, 0x30
000076cd267d5725  vmovaps xmm0, [rsp]
000076cd267d572a  vmovaps xmm2, [rsp+0x10]
000076cd267d5730  vmovaps xmm3, [rsp+0x20]
000076cd267d5736  vmovaps xmm4, [rsp+0x30]
000076cd267d573c  vmovaps xmm5, [rsp+0x40]
000076cd267d5742  vmovaps xmm6, [rsp+0x50]
000076cd267d5748  vmovaps xmm7, [rsp+0x60]
000076cd267d574e  vmovaps xmm8, [rsp+0x70]
000076cd267d5754  vmovaps xmm9, [rsp+0x80]
000076cd267d575d  vmovaps xmm10, [rsp+0x90]
000076cd267d5766  vmovaps xmm11, [rsp+0xA0]
000076cd267d576f  vmovaps xmm12, [rsp+0xB0]
000076cd267d5778  vmovaps xmm13, [rsp+0xC0]
000076cd267d5781  vmovaps xmm14, [rsp+0xD0]
000076cd267d578a  vmovaps xmm15, [rsp+0xE0]
000076cd267d5793  add rsp, 0xF0
000076cd267d579a  pop r11
000076cd267d579c  pop r10
000076cd267d579e  pop r9
000076cd267d57a0  pop r8
000076cd267d57a2  pop rsi
000076cd267d57a3  pop rdi
000076cd267d57a4  pop rdx
000076cd267d57a5  pop rcx
000076cd267d57a6  pop rax
000076cd267d57a7  add rsp, 0x08
000076cd267d57ab  jmp 0x000076CD267D033B
000076cd267d57b0  call 0x000076CD2660E880
000076cd267d57b5  jmp 0x000076CD267D034E
000076cd267d57ba  call 0x000076CD2660C380
000076cd267d57bf  jmp 0x000076CD267D0359
000076cd267d57c4  call 0x000076CD2660D600
000076cd267d57c9  jmp 0x000076CD267D0364
000076cd267d57ce  call 0x000076CD265FF540
000076cd267d57d3  jmp 0x000076CD267D036F
000076cd267d57d8  int3
000076cd267d57d9  nop [rax], eax
000076cd267d57e0  mov rax, [r15+0x40]
000076cd267d57e4  mov r14, [r15+0x58]
000076cd267d57e8  lea r12, [rax+r14*1]
000076cd267d57ec  movaps xmm1, [r15+0x1D0]
000076cd267d57f4  vmovaps [rsp+0x10], xmm1
000076cd267d57fa  vmovaps xmm15, [rsp+0x10]
000076cd267d5800  por xmm1, xmm15
000076cd267d5805  movaps xmm14, [r15+0x1A0]
000076cd267d580d  vmovaps [rsp+0x10], xmm14
000076cd267d5813  vmovaps xmm13, [rsp+0x10]
000076cd267d5819  por xmm14, xmm13
000076cd267d581e  lea rax, [r12+0x30]
000076cd267d5823  mov r11, [r13+rax*1]
000076cd267d5828  lea rax, [r12+0x38]
000076cd267d582d  mov r10, [r13+rax*1]
000076cd267d5832  movq xmm13, r11
000076cd267d5837  movq xmm12, r10
000076cd267d583c  movq xmm13, xmm13
000076cd267d5841  vmovaps [rsp+0x10], xmm13
000076cd267d5847  movq xmm13, xmm13
000076cd267d584c  movaps [r15+0x130], xmm13
000076cd267d5854  movq xmm12, xmm12
000076cd267d5859  vmovaps [rsp+0x20], xmm12
000076cd267d585f  movq xmm12, xmm12
000076cd267d5864  movaps [r15+0x280], xmm12
000076cd267d586c  movaps xmm13, [r15+0x270]
000076cd267d5874  vmovaps [rsp+0x30], xmm13
000076cd267d587a  vmovaps xmm12, [rsp+0x30]
000076cd267d5880  por xmm13, xmm12
000076cd267d5885  lea rax, [r12+0x20]
000076cd267d588a  mov r11, [r13+rax*1]
000076cd267d588f  lea rax, [r12+0x28]
000076cd267d5894  mov r10, [r13+rax*1]
000076cd267d5899  movq xmm12, r11
000076cd267d589e  movq xmm11, r10
000076cd267d58a3  movq xmm12, xmm12
000076cd267d58a8  vmovaps [rsp+0x30], xmm12
000076cd267d58ae  movq xmm12, xmm12
000076cd267d58b3  movaps [r15+0x150], xmm12
000076cd267d58bb  movq xmm11, xmm11
000076cd267d58c0  vmovaps [rsp+0x40], xmm11
000076cd267d58c6  movq xmm11, xmm11
000076cd267d58cb  movaps [r15+0x140], xmm11
000076cd267d58d3  lea rax, [r12+0x10]
000076cd267d58d8  mov r11, [r13+rax*1]
000076cd267d58dd  lea rax, [r12+0x18]
000076cd267d58e2  mov r10, [r13+rax*1]
000076cd267d58e7  movq xmm12, r11
000076cd267d58ec  movq xmm11, r10
000076cd267d58f1  movq xmm12, xmm12
000076cd267d58f6  vmovaps [rsp+0x50], xmm12
000076cd267d58fc  movq xmm12, xmm12
000076cd267d5901  movaps [r15+0x170], xmm12
000076cd267d5909  movq xmm11, xmm11
000076cd267d590e  vmovaps [rsp+0x60], xmm11
000076cd267d5914  movq xmm11, xmm11
000076cd267d5919  movaps [r15+0x160], xmm11
000076cd267d5921  mov rax, [r13+r12*1]
000076cd267d5926  vmovq xmm12, rax
000076cd267d592b  vpbroadcastq xmm12, xmm12
000076cd267d5930  lea rax, [r12+0x08]
000076cd267d5935  mov r12, [r13+rax*1]
000076cd267d593a  movq xmm11, r12
000076cd267d593f  movaps [r15+0x230], xmm11
000076cd267d5947  mov rax, [r15+0xF8]
000076cd267d594e  lea r12, [rax+0x50]
000076cd267d5952  movups xmm11, [r13+r12*1]
000076cd267d5958  lea r12, [rax+0x60]
000076cd267d595c  movups xmm10, [r13+r12*1]
000076cd267d5962  lea r12, [rax+0x30]
000076cd267d5966  movups xmm9, [r13+r12*1]
000076cd267d596c  mov r12, [r15+0x50]
000076cd267d5970  lea r11, [r12+r14*1]
000076cd267d5974  mov [r15+0x60], r11
000076cd267d5978  lea r12, [r14+0x40]
000076cd267d597c  mov [r15+0x58], r12
000076cd267d5980  movaps xmm8, xmm12
000076cd267d5984  mulpd xmm8, xmm15
000076cd267d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000076cd267d598f  ptest xmm7, xmm7
000076cd267d5994  jnz 0x000076CD267D67B7
000076cd267d599a  movq xmm15, qword ptr [r15+0x230]
000076cd267d59a3  vmovaps [rsp+0x70], xmm15
000076cd267d59a9  vpermilpd xmm15, xmm15, 0x00
000076cd267d59af  movaps xmm7, xmm9
000076cd267d59b3  mulpd xmm7, xmm15
000076cd267d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000076cd267d59bd  ptest xmm6, xmm6
000076cd267d59c2  jnz 0x000076CD267D68FB
000076cd267d59c8  vxorps xmm15, xmm15, xmm15
000076cd267d59cd  vpbroadcastq xmm15, xmm15
000076cd267d59d2  movaps xmm9, xmm12
000076cd267d59d6  mulpd xmm9, xmm10
000076cd267d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000076cd267d59e1  ptest xmm6, xmm6
000076cd267d59e6  jnz 0x000076CD267D6A3D
000076cd267d59ec  movaps xmm10, xmm12
000076cd267d59f0  mulpd xmm10, xmm11
000076cd267d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000076cd267d59fb  ptest xmm6, xmm6
000076cd267d5a00  jnz 0x000076CD267D6B81
000076cd267d5a06  movaps xmm11, [r15+0x1F0]
000076cd267d5a0e  movaps xmm6, xmm12
000076cd267d5a12  mulpd xmm6, xmm11
000076cd267d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000076cd267d5a1c  ptest xmm5, xmm5
000076cd267d5a21  jnz 0x000076CD267D6CC5
000076cd267d5a27  movaps xmm12, [r15+0x2A0]
000076cd267d5a2f  vmovaps [rsp+0x80], xmm12
000076cd267d5a38  vmovaps xmm11, [rsp+0x80]
000076cd267d5a41  por xmm12, xmm11
000076cd267d5a46  movaps xmm11, [r15+0x250]
000076cd267d5a4e  vmovaps [rsp+0x80], xmm11
000076cd267d5a57  vmovaps xmm5, [rsp+0x80]
000076cd267d5a60  por xmm11, xmm5
000076cd267d5a65  vmovaps xmm4, [rsp+0x70]
000076cd267d5a6b  vpermilpd xmm4, xmm4, 0x00
000076cd267d5a71  movaps xmm3, xmm5
000076cd267d5a74  mulpd xmm3, xmm4
000076cd267d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000076cd267d5a7d  ptest xmm2, xmm2
000076cd267d5a82  jnz 0x000076CD267D6E07
000076cd267d5a88  mov [rsp+0x80], rax
000076cd267d5a90  xor eax, eax
000076cd267d5a92  mov r14d, 0x200
000076cd267d5a98  cmp r12, r14
000076cd267d5a9b  cmc
000076cd267d5a9c  lahf
000076cd267d5a9d  seto al
000076cd267d5aa0  mov [r15+0x108], eax
000076cd267d5aa7  movaps xmm5, xmm8
000076cd267d5aab  addpd xmm5, xmm15
000076cd267d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000076cd267d5ab5  ptest xmm4, xmm4
000076cd267d5aba  jnz 0x000076CD267D6F47
000076cd267d5ac0  movaps xmm8, [r15+0x1B0]
000076cd267d5ac8  movaps xmm4, xmm9
000076cd267d5acc  addpd xmm4, xmm8
000076cd267d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000076cd267d5ad6  ptest xmm2, xmm2
000076cd267d5adb  jnz 0x000076CD267D7089
000076cd267d5ae1  movaps xmm9, xmm10
000076cd267d5ae5  addpd xmm9, xmm8
000076cd267d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000076cd267d5af0  ptest xmm2, xmm2
000076cd267d5af5  jnz 0x000076CD267D71CB
000076cd267d5afb  movaps xmm10, [r15+0x2F0]
000076cd267d5b03  vmovaps [rsp+0x90], xmm10
000076cd267d5b0c  vmovaps xmm8, [rsp+0x90]
000076cd267d5b15  por xmm10, xmm8
000076cd267d5b1a  movaps xmm8, [r15+0x2E0]
000076cd267d5b22  vmovaps [rsp+0x90], xmm8
000076cd267d5b2b  vmovaps xmm2, [rsp+0x90]
000076cd267d5b34  por xmm8, xmm2
000076cd267d5b39  movaps xmm2, [r15+0x2D0]
000076cd267d5b41  vmovaps [rsp+0x90], xmm2
000076cd267d5b4a  vmovaps [rsp+0xA0], xmm1
000076cd267d5b53  vmovaps xmm1, [rsp+0x90]
000076cd267d5b5c  por xmm2, xmm1
000076cd267d5b60  movaps xmm1, [r15+0x200]
000076cd267d5b68  vmovaps [rsp+0x90], xmm1
000076cd267d5b71  vmovaps [rsp+0xB0], xmm15
000076cd267d5b7a  vmovaps xmm15, [rsp+0x90]
000076cd267d5b83  por xmm1, xmm15
000076cd267d5b88  movaps xmm15, [r15+0x1C0]
000076cd267d5b90  vmovaps [rsp+0x90], xmm15
000076cd267d5b99  vmovaps [rsp+0xC0], xmm1
000076cd267d5ba2  vmovaps xmm1, [rsp+0x90]
000076cd267d5bab  por xmm15, xmm1
000076cd267d5bb0  movaps xmm1, [r15+0x190]
000076cd267d5bb8  vmovaps [rsp+0x90], xmm1
000076cd267d5bc1  vmovaps [rsp+0xD0], xmm15
000076cd267d5bca  vmovaps xmm15, [rsp+0x90]
000076cd267d5bd3  por xmm1, xmm15
000076cd267d5bd8  movaps xmm15, [r15+0x300]
000076cd267d5be0  vmovaps [rsp+0x90], xmm15
000076cd267d5be9  vmovaps [rsp+0xE0], xmm1
000076cd267d5bf2  vmovaps xmm1, [rsp+0x90]
000076cd267d5bfb  por xmm15, xmm1
000076cd267d5c00  mov rax, [rsp+0x80]
000076cd267d5c08  lea r14, [rax+0xA0]
000076cd267d5c0f  movups xmm1, [r13+r14*1]
000076cd267d5c15  lea r14, [rax+0xB0]
000076cd267d5c1c  vmovaps [rsp+0x80], xmm1
000076cd267d5c25  movups xmm1, [r13+r14*1]
000076cd267d5c2b  vmovaps [rsp+0x90], xmm1
000076cd267d5c34  vmovaps [rsp+0xF0], xmm15
000076cd267d5c3d  vmovaps xmm15, [rsp+0xB0]
000076cd267d5c46  vmovaps [rsp+0xB0], xmm14
000076cd267d5c4f  movaps xmm1, xmm6
000076cd267d5c52  addpd xmm1, xmm15
000076cd267d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000076cd267d5c5c  ptest xmm14, xmm14
000076cd267d5c62  jnz 0x000076CD267D7323
000076cd267d5c68  lea r14, [rax+0xF0]
000076cd267d5c6f  movups xmm15, [r13+r14*1]
000076cd267d5c75  movaps xmm14, xmm4
000076cd267d5c79  addpd xmm14, xmm3
000076cd267d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000076cd267d5c84  ptest xmm6, xmm6
000076cd267d5c89  jnz 0x000076CD267D746E
000076cd267d5c8f  movaps xmm6, xmm9
000076cd267d5c93  addpd xmm6, xmm7
000076cd267d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000076cd267d5c9c  ptest xmm4, xmm4
000076cd267d5ca1  jnz 0x000076CD267D75B0
000076cd267d5ca7  vmovaps xmm9, [rsp+0x70]
000076cd267d5cad  vpermilpd xmm9, xmm9, 0x00
000076cd267d5cb3  vmovaps xmm4, [rsp+0x90]
000076cd267d5cbc  movaps xmm7, xmm4
000076cd267d5cbf  mulpd xmm7, xmm9
000076cd267d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000076cd267d5cc9  ptest xmm3, xmm3
000076cd267d5cce  jnz 0x000076CD267D76F1
000076cd267d5cd4  vmovaps xmm9, [rsp+0x50]
000076cd267d5cda  vpermilpd xmm9, xmm9, 0x00
000076cd267d5ce0  movaps xmm4, xmm15
000076cd267d5ce4  mulpd xmm4, xmm9
000076cd267d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000076cd267d5cee  ptest xmm3, xmm3
000076cd267d5cf3  jnz 0x000076CD267D7832
000076cd267d5cf9  lea r14, [rax+0xE0]
000076cd267d5d00  movups xmm15, [r13+r14*1]
000076cd267d5d06  vmovaps xmm9, [rsp+0x70]
000076cd267d5d0c  vpermilpd xmm9, xmm9, 0x00
000076cd267d5d12  vmovaps [rsp+0x70], xmm1
000076cd267d5d18  vmovaps xmm1, [rsp+0x80]
000076cd267d5d21  vmovaps [rsp+0x80], xmm15
000076cd267d5d2a  movaps xmm3, xmm1
000076cd267d5d2d  mulpd xmm3, xmm9
000076cd267d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000076cd267d5d37  ptest xmm15, xmm15
000076cd267d5d3d  jnz 0x000076CD267D797E
000076cd267d5d43  vmovaps xmm1, [rsp+0xF0]
000076cd267d5d4c  vmovaps xmm15, [rsp+0xF0]
000076cd267d5d55  por xmm1, xmm15
000076cd267d5d5a  movaps [r15+0x300], xmm1
000076cd267d5d62  vmovaps xmm15, [rsp+0xE0]
000076cd267d5d6b  vmovaps xmm9, [rsp+0xE0]
000076cd267d5d74  por xmm15, xmm9
000076cd267d5d79  movaps [r15+0x190], xmm15
000076cd267d5d81  vmovaps xmm9, [rsp+0x50]
000076cd267d5d87  vpermilpd xmm9, xmm9, 0x00
000076cd267d5d8d  vmovaps [rsp+0x90], xmm1
000076cd267d5d96  vmovaps [rsp+0xE0], xmm15
000076cd267d5d9f  vmovaps xmm15, [rsp+0x80]
000076cd267d5da8  vmovaps [rsp+0x80], xmm14
000076cd267d5db1  movaps xmm1, xmm15
000076cd267d5db5  mulpd xmm1, xmm9
000076cd267d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000076cd267d5dbf  ptest xmm14, xmm14
000076cd267d5dc5  jnz 0x000076CD267D7ABF
000076cd267d5dcb  lea r14, [rax+0x90]
000076cd267d5dd2  movups xmm15, [r13+r14*1]
000076cd267d5dd8  vmovaps xmm14, [rsp+0xD0]
000076cd267d5de1  vmovaps xmm9, [rsp+0xD0]
000076cd267d5dea  por xmm14, xmm9
000076cd267d5def  movaps [r15+0x1C0], xmm14
000076cd267d5df7  vmovaps xmm9, [rsp+0xC0]
000076cd267d5e00  vmovaps [rsp+0xD0], xmm1
000076cd267d5e09  vmovaps xmm1, [rsp+0xC0]
000076cd267d5e12  por xmm9, xmm1
000076cd267d5e17  movaps [r15+0x200], xmm9
000076cd267d5e1f  vmovaps [rsp+0xC0], xmm2
000076cd267d5e28  vmovaps xmm1, [rsp+0xC0]
000076cd267d5e31  por xmm2, xmm1
000076cd267d5e35  movaps [r15+0x2D0], xmm2
000076cd267d5e3d  vmovaps [rsp+0xC0], xmm8
000076cd267d5e46  vmovaps xmm1, [rsp+0xC0]
000076cd267d5e4f  por xmm8, xmm1
000076cd267d5e54  movaps [r15+0x2E0], xmm8
000076cd267d5e5c  vmovaps [rsp+0xC0], xmm15
000076cd267d5e65  movaps xmm1, xmm5
000076cd267d5e68  addpd xmm1, xmm7
000076cd267d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000076cd267d5e71  ptest xmm15, xmm15
000076cd267d5e77  jnz 0x000076CD267D7C0B
000076cd267d5e7d  vmovaps xmm15, [rsp+0x50]
000076cd267d5e83  vpermilpd xmm15, xmm15, 0x00
000076cd267d5e89  vmovaps xmm5, [rsp+0xC0]
000076cd267d5e92  vmovaps [rsp+0xC0], xmm1
000076cd267d5e9b  movaps xmm7, xmm5
000076cd267d5e9e  mulpd xmm7, xmm15
000076cd267d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000076cd267d5ea8  ptest xmm1, xmm1
000076cd267d5ead  jnz 0x000076CD267D7D4B
000076cd267d5eb3  lea r14, [rax+0x80]
000076cd267d5eba  movups xmm1, [r13+r14*1]
000076cd267d5ec0  vmovaps xmm5, [rsp+0x70]
000076cd267d5ec6  vmovaps [rsp+0x70], xmm1
000076cd267d5ecc  movaps xmm15, xmm5
000076cd267d5ed0  addpd xmm15, xmm3
000076cd267d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267d5edb  ptest xmm1, xmm1
000076cd267d5ee0  jnz 0x000076CD267D7E96
000076cd267d5ee6  vmovaps xmm5, [rsp+0x80]
000076cd267d5eef  movaps xmm1, xmm5
000076cd267d5ef2  addpd xmm1, xmm4
000076cd267d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000076cd267d5efb  ptest xmm3, xmm3
000076cd267d5f00  jnz 0x000076CD267D7FD8
000076cd267d5f06  vmovaps [rsp+0x80], xmm10
000076cd267d5f0f  vmovaps xmm5, [rsp+0x80]
000076cd267d5f18  por xmm10, xmm5
000076cd267d5f1d  movaps [r15+0x2F0], xmm10
000076cd267d5f25  vmovaps xmm5, [rsp+0x50]
000076cd267d5f2b  vpermilpd xmm5, xmm5, 0x00
000076cd267d5f31  vmovaps xmm3, [rsp+0x70]
000076cd267d5f37  vmovaps [rsp+0x50], xmm1
000076cd267d5f3d  movaps xmm4, xmm3
000076cd267d5f40  mulpd xmm4, xmm5
000076cd267d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000076cd267d5f49  ptest xmm1, xmm1
000076cd267d5f4e  jnz 0x000076CD267D8118
000076cd267d5f54  lea r14, [rax+0xD0]
000076cd267d5f5b  movups xmm1, [r13+r14*1]
000076cd267d5f61  vmovaps xmm3, [rsp+0xD0]
000076cd267d5f6a  vmovaps [rsp+0x70], xmm1
000076cd267d5f70  movaps xmm5, xmm6
000076cd267d5f73  addpd xmm5, xmm3
000076cd267d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000076cd267d5f7c  ptest xmm1, xmm1
000076cd267d5f81  jnz 0x000076CD267D8262
000076cd267d5f87  vmovaps xmm1, [rsp+0x60]
000076cd267d5f8d  vpermilpd xmm1, xmm1, 0x00
000076cd267d5f93  movaps xmm6, xmm9
000076cd267d5f97  mulpd xmm6, xmm1
000076cd267d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000076cd267d5fa0  ptest xmm3, xmm3
000076cd267d5fa5  jnz 0x000076CD267D83A2
000076cd267d5fab  movaps [r15+0x260], xmm6
000076cd267d5fb3  vxorps xmm1, xmm1, xmm1
000076cd267d5fb7  vpbroadcastq xmm1, xmm1
000076cd267d5fbc  movaps [r15+0x1B0], xmm1
000076cd267d5fc4  vmovaps xmm1, [rsp+0x60]
000076cd267d5fca  vpermilpd xmm1, xmm1, 0x00
000076cd267d5fd0  vmovaps xmm3, [rsp+0x70]
000076cd267d5fd6  vmovaps [rsp+0x70], xmm15
000076cd267d5fdc  movaps xmm9, xmm3
000076cd267d5fe0  mulpd xmm9, xmm1
000076cd267d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000076cd267d5feb  ptest xmm15, xmm15
000076cd267d5ff1  jnz 0x000076CD267D84E3
000076cd267d5ff7  lea r14, [rax+0xC0]
000076cd267d5ffe  movups xmm1, [r13+r14*1]
000076cd267d6004  vmovaps xmm3, [rsp+0xC0]
000076cd267d600d  vmovaps [rsp+0x80], xmm1
000076cd267d6016  movaps xmm15, xmm3
000076cd267d601a  addpd xmm15, xmm7
000076cd267d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267d6025  ptest xmm1, xmm1
000076cd267d602a  jnz 0x000076CD267D862F
000076cd267d6030  vmovaps [rsp+0xC0], xmm13
000076cd267d6039  vmovaps xmm1, [rsp+0xC0]
000076cd267d6042  por xmm13, xmm1
000076cd267d6047  movaps [r15+0x270], xmm13
000076cd267d604f  vmovaps xmm1, [rsp+0xB0]
000076cd267d6058  vmovaps xmm7, [rsp+0xB0]
000076cd267d6061  por xmm1, xmm7
000076cd267d6065  movaps [r15+0x1A0], xmm1
000076cd267d606d  vmovaps xmm1, [rsp+0x60]
000076cd267d6073  vpermilpd xmm1, xmm1, 0x00
000076cd267d6079  vmovaps [rsp+0xB0], xmm1
000076cd267d6082  vmovaps xmm1, [rsp+0x80]
000076cd267d608b  vmovaps [rsp+0x80], xmm15
000076cd267d6094  vmovaps xmm15, [rsp+0xB0]
000076cd267d609d  vmovaps [rsp+0xB0], xmm14
000076cd267d60a6  movaps xmm3, xmm1
000076cd267d60a9  mulpd xmm3, xmm15
000076cd267d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000076cd267d60b3  ptest xmm14, xmm14
000076cd267d60b9  jnz 0x000076CD267D8771
000076cd267d60bf  lea r14, [rax+0x20]
000076cd267d60c3  movups xmm1, [r13+r14*1]
000076cd267d60c9  movaps [r15+0x110], xmm1
000076cd267d60d1  vmovaps xmm14, [rsp+0x70]
000076cd267d60d7  vmovaps [rsp+0x70], xmm1
000076cd267d60dd  movaps xmm15, xmm14
000076cd267d60e1  addpd xmm15, xmm4
000076cd267d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267d60ec  ptest xmm1, xmm1
000076cd267d60f1  jnz 0x000076CD267D88BC
000076cd267d60f7  vmovaps xmm1, [rsp+0x60]
000076cd267d60fd  vpermilpd xmm1, xmm1, 0x00
000076cd267d6103  movaps xmm14, xmm2
000076cd267d6107  mulpd xmm14, xmm1
000076cd267d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000076cd267d6112  ptest xmm4, xmm4
000076cd267d6117  jnz 0x000076CD267D89FF
000076cd267d611d  vmovaps xmm4, [rsp+0x50]
000076cd267d6123  movaps xmm1, xmm4
000076cd267d6126  addpd xmm1, xmm9
000076cd267d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000076cd267d6130  ptest xmm2, xmm2
000076cd267d6135  jnz 0x000076CD267D8B41
000076cd267d613b  vmovaps xmm9, [rsp+0x30]
000076cd267d6141  vpermilpd xmm9, xmm9, 0x00
000076cd267d6147  vmovaps xmm2, [rsp+0x70]
000076cd267d614d  vmovaps [rsp+0x50], xmm1
000076cd267d6153  movaps xmm4, xmm2
000076cd267d6156  mulpd xmm4, xmm9
000076cd267d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000076cd267d6160  ptest xmm1, xmm1
000076cd267d6165  jnz 0x000076CD267D8C82
000076cd267d616b  vmovaps xmm1, [rsp+0x30]
000076cd267d6171  vpermilpd xmm1, xmm1, 0x00
000076cd267d6177  vmovaps xmm2, [rsp+0x90]
000076cd267d6180  vmovaps [rsp+0x60], xmm15
000076cd267d6186  movaps xmm9, xmm2
000076cd267d618a  mulpd xmm9, xmm1
000076cd267d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000076cd267d6195  ptest xmm15, xmm15
000076cd267d619b  jnz 0x000076CD267D8DC3
000076cd267d61a1  vmovaps xmm15, [rsp+0x80]
000076cd267d61aa  movaps xmm1, xmm15
000076cd267d61ae  addpd xmm1, xmm6
000076cd267d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000076cd267d61b7  ptest xmm2, xmm2
000076cd267d61bc  jnz 0x000076CD267D8F05
000076cd267d61c2  movaps xmm15, xmm5
000076cd267d61c6  addpd xmm15, xmm3
000076cd267d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000076cd267d61d1  ptest xmm6, xmm6
000076cd267d61d6  jnz 0x000076CD267D9046
000076cd267d61dc  vmovaps xmm6, [rsp+0x30]
000076cd267d61e2  vpermilpd xmm6, xmm6, 0x00
000076cd267d61e8  movaps xmm5, xmm8
000076cd267d61ec  mulpd xmm5, xmm6
000076cd267d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000076cd267d61f5  ptest xmm3, xmm3
000076cd267d61fa  jnz 0x000076CD267D9188
000076cd267d6200  vmovaps xmm8, [rsp+0x30]
000076cd267d6206  vpermilpd xmm8, xmm8, 0x00
000076cd267d620c  movaps xmm6, xmm10
000076cd267d6210  mulpd xmm6, xmm8
000076cd267d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000076cd267d621a  ptest xmm3, xmm3
000076cd267d621f  jnz 0x000076CD267D92C9
000076cd267d6225  vmovaps xmm8, [rsp+0x60]
000076cd267d622b  movaps xmm10, xmm8
000076cd267d622f  addpd xmm10, xmm14
000076cd267d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000076cd267d623a  ptest xmm3, xmm3
000076cd267d623f  jnz 0x000076CD267D940B
000076cd267d6245  vmovaps xmm8, [rsp+0x50]
000076cd267d624b  movaps xmm14, xmm8
000076cd267d624f  addpd xmm14, xmm4
000076cd267d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000076cd267d625a  ptest xmm3, xmm3
000076cd267d625f  jnz 0x000076CD267D954F
000076cd267d6265  vmovaps xmm8, [rsp+0x40]
000076cd267d626b  vpermilpd xmm8, xmm8, 0x00
000076cd267d6271  movaps xmm4, xmm13
000076cd267d6275  mulpd xmm4, xmm8
000076cd267d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000076cd267d627f  ptest xmm3, xmm3
000076cd267d6284  jnz 0x000076CD267D9692
000076cd267d628a  movaps xmm13, xmm15
000076cd267d628e  addpd xmm13, xmm9
000076cd267d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000076cd267d6299  ptest xmm8, xmm8
000076cd267d629f  jnz 0x000076CD267D97D4
000076cd267d62a5  movaps xmm15, xmm1
000076cd267d62a9  addpd xmm15, xmm5
000076cd267d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000076cd267d62b4  ptest xmm9, xmm9
000076cd267d62ba  jnz 0x000076CD267D9918
000076cd267d62c0  vmovaps [rsp+0x30], xmm11
000076cd267d62c6  vmovaps xmm1, [rsp+0x30]
000076cd267d62cc  por xmm11, xmm1
000076cd267d62d1  movaps [r15+0x250], xmm11
000076cd267d62d9  vmovaps [rsp+0x30], xmm12
000076cd267d62df  vmovaps xmm1, [rsp+0x30]
000076cd267d62e5  por xmm12, xmm1
000076cd267d62ea  movaps [r15+0x2A0], xmm12
000076cd267d62f2  vmovaps xmm1, [rsp+0xA0]
000076cd267d62fb  vmovaps xmm11, [rsp+0xA0]
000076cd267d6304  por xmm1, xmm11
000076cd267d6309  movaps [r15+0x1D0], xmm1
000076cd267d6311  lea r14, [rax+0x40]
000076cd267d6315  movups xmm1, [r13+r14*1]
000076cd267d631b  movaps [r15+0x2C0], xmm1
000076cd267d6323  vmovaps xmm11, [rsp+0x40]
000076cd267d6329  vpermilpd xmm11, xmm11, 0x00
000076cd267d632f  vmovaps xmm8, [rsp+0xE0]
000076cd267d6338  movaps xmm9, xmm8
000076cd267d633c  mulpd xmm9, xmm11
000076cd267d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000076cd267d6347  ptest xmm5, xmm5
000076cd267d634c  jnz 0x000076CD267D9A64
000076cd267d6352  movaps xmm11, xmm10
000076cd267d6356  addpd xmm11, xmm6
000076cd267d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000076cd267d6361  ptest xmm8, xmm8
000076cd267d6367  jnz 0x000076CD267D9BA8
000076cd267d636d  movaps xmm10, xmm14
000076cd267d6371  addpd xmm10, xmm4
000076cd267d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000076cd267d637c  ptest xmm8, xmm8
000076cd267d6382  jnz 0x000076CD267D9CEB
000076cd267d6388  vmovaps xmm14, [rsp+0x40]
000076cd267d638e  vpermilpd xmm14, xmm14, 0x00
000076cd267d6394  movaps xmm8, xmm1
000076cd267d6398  mulpd xmm8, xmm14
000076cd267d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000076cd267d63a3  ptest xmm6, xmm6
000076cd267d63a8  jnz 0x000076CD267D9E2E
000076cd267d63ae  movaps xmm1, [r15+0x2B0]
000076cd267d63b6  vmovaps xmm14, [rsp+0x40]
000076cd267d63bc  vpermilpd xmm14, xmm14, 0x00
000076cd267d63c2  movaps xmm6, xmm1
000076cd267d63c5  mulpd xmm6, xmm14
000076cd267d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000076cd267d63cf  ptest xmm5, xmm5
000076cd267d63d4  jnz 0x000076CD267D9F71
000076cd267d63da  vmovaps xmm1, [rsp+0x10]
000076cd267d63e0  vpermilpd xmm1, xmm1, 0x00
000076cd267d63e6  movaps xmm14, xmm12
000076cd267d63ea  mulpd xmm14, xmm1
000076cd267d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000076cd267d63f5  ptest xmm5, xmm5
000076cd267d63fa  jnz 0x000076CD267DA0B2
000076cd267d6400  movaps xmm1, xmm13
000076cd267d6404  addpd xmm1, xmm9
000076cd267d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000076cd267d640e  ptest xmm12, xmm12
000076cd267d6414  jnz 0x000076CD267DA1F5
000076cd267d641a  vmovaps xmm13, [rsp+0x10]
000076cd267d6420  vpermilpd xmm13, xmm13, 0x00
000076cd267d6426  movaps xmm12, xmm7
000076cd267d642a  mulpd xmm12, xmm13
000076cd267d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000076cd267d6435  ptest xmm9, xmm9
000076cd267d643b  jnz 0x000076CD267DA337
000076cd267d6441  movaps xmm13, xmm15
000076cd267d6445  addpd xmm13, xmm8
000076cd267d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000076cd267d6450  ptest xmm9, xmm9
000076cd267d6456  jnz 0x000076CD267DA47A
000076cd267d645c  movaps xmm15, [r15+0x290]
000076cd267d6464  vmovaps xmm9, [rsp+0x10]
000076cd267d646a  vpermilpd xmm9, xmm9, 0x00
000076cd267d6470  movaps xmm8, xmm15
000076cd267d6474  mulpd xmm8, xmm9
000076cd267d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000076cd267d647f  ptest xmm7, xmm7
000076cd267d6484  jnz 0x000076CD267DA5BE
000076cd267d648a  movaps xmm15, xmm11
000076cd267d648e  addpd xmm15, xmm6
000076cd267d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000076cd267d6499  ptest xmm9, xmm9
000076cd267d649f  jnz 0x000076CD267DA702
000076cd267d64a5  movaps xmm11, [r15+0x1E0]
000076cd267d64ad  vmovaps xmm9, [rsp+0x10]
000076cd267d64b3  vpermilpd xmm9, xmm9, 0x00
000076cd267d64b9  movaps xmm7, xmm11
000076cd267d64bd  mulpd xmm7, xmm9
000076cd267d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000076cd267d64c7  ptest xmm6, xmm6
000076cd267d64cc  jnz 0x000076CD267DA845
000076cd267d64d2  movaps xmm11, xmm10
000076cd267d64d6  addpd xmm11, xmm14
000076cd267d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000076cd267d64e1  ptest xmm9, xmm9
000076cd267d64e7  jnz 0x000076CD267DA987
000076cd267d64ed  lea r14, [rax+0x70]
000076cd267d64f1  movups xmm14, [r13+r14*1]
000076cd267d64f7  movaps [r15+0x240], xmm14
000076cd267d64ff  movaps xmm10, xmm1
000076cd267d6503  addpd xmm10, xmm12
000076cd267d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000076cd267d650e  ptest xmm9, xmm9
000076cd267d6514  jnz 0x000076CD267DAAD5
000076cd267d651a  movaps [r15+0x170], xmm10
000076cd267d6522  vmovaps xmm1, [rsp+0x20]
000076cd267d6528  vpermilpd xmm1, xmm1, 0x00
000076cd267d652e  movaps xmm12, xmm14
000076cd267d6532  mulpd xmm12, xmm1
000076cd267d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000076cd267d653d  ptest xmm9, xmm9
000076cd267d6543  jnz 0x000076CD267DAC18
000076cd267d6549  vmovaps xmm1, [rsp+0x20]
000076cd267d654f  vpermilpd xmm1, xmm1, 0x00
000076cd267d6555  vmovaps xmm9, [rsp+0xB0]
000076cd267d655e  movaps xmm14, xmm9
000076cd267d6562  mulpd xmm14, xmm1
000076cd267d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000076cd267d656d  ptest xmm6, xmm6
000076cd267d6572  jnz 0x000076CD267DAD5B
000076cd267d6578  movaps [r15+0x180], xmm14
000076cd267d6580  movaps xmm1, xmm13
000076cd267d6584  addpd xmm1, xmm8
000076cd267d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000076cd267d658e  ptest xmm9, xmm9
000076cd267d6594  jnz 0x000076CD267DAE9E
000076cd267d659a  movaps [r15+0x210], xmm1
000076cd267d65a2  movups xmm13, [r13+rax*1]
000076cd267d65a8  lea r14, [rax+0x10]
000076cd267d65ac  movups xmm9, [r13+r14*1]
000076cd267d65b2  movaps [r15+0x230], xmm9
000076cd267d65ba  movaps xmm8, xmm15
000076cd267d65be  addpd xmm8, xmm7
000076cd267d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000076cd267d65c9  ptest xmm6, xmm6
000076cd267d65ce  jnz 0x000076CD267DAFF4
000076cd267d65d4  movaps [r15+0x130], xmm8
000076cd267d65dc  vmovaps xmm15, [rsp+0x20]
000076cd267d65e2  vpermilpd xmm15, xmm15, 0x00
000076cd267d65e8  movaps xmm7, xmm9
000076cd267d65ec  mulpd xmm7, xmm15
000076cd267d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000076cd267d65f6  ptest xmm6, xmm6
000076cd267d65fb  jnz 0x000076CD267DB137
000076cd267d6601  movaps [r15+0x220], xmm7
000076cd267d6609  vmovaps xmm15, [rsp+0x20]
000076cd267d660f  vpermilpd xmm15, xmm15, 0x00
000076cd267d6615  movaps xmm9, xmm13
000076cd267d6619  mulpd xmm9, xmm15
000076cd267d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000076cd267d6624  ptest xmm6, xmm6
000076cd267d6629  jnz 0x000076CD267DB279
000076cd267d662f  movaps xmm15, xmm11
000076cd267d6633  addpd xmm15, xmm12
000076cd267d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000076cd267d663e  ptest xmm13, xmm13
000076cd267d6644  jnz 0x000076CD267DB3BD
000076cd267d664a  movaps [r15+0x140], xmm15
000076cd267d6652  movaps xmm13, xmm10
000076cd267d6656  addpd xmm13, xmm14
000076cd267d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000076cd267d6661  ptest xmm12, xmm12
000076cd267d6667  jnz 0x000076CD267DB501
000076cd267d666d  movaps [r15+0x150], xmm13
000076cd267d6675  movaps xmm14, xmm1
000076cd267d6679  addpd xmm14, xmm7
000076cd267d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000076cd267d6684  ptest xmm12, xmm12
000076cd267d668a  jnz 0x000076CD267DB645
000076cd267d6690  movaps [r15+0x160], xmm14
000076cd267d6698  movaps xmm1, xmm8
000076cd267d669c  addpd xmm1, xmm9
000076cd267d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000076cd267d66a6  ptest xmm12, xmm12
000076cd267d66ac  jnz 0x000076CD267DB787
000076cd267d66b2  movaps [r15+0x120], xmm1
000076cd267d66ba  movups [r13+r11*1], xmm15
000076cd267d66c0  lea rax, [r11+0x10]
000076cd267d66c4  movups [r13+rax*1], xmm13
000076cd267d66ca  lea rax, [r11+0x20]
000076cd267d66ce  movups [r13+rax*1], xmm14
000076cd267d66d4  lea rax, [r11+0x30]
000076cd267d66d8  movups [r13+rax*1], xmm1
000076cd267d66de  mov eax, [r15+0x108]
000076cd267d66e5  sahf
000076cd267d66e6  jnz 0x000076CD267D6718
000076cd267d66e8  cmp dword ptr [r15+0x318], 0x00
000076cd267d66f0  jz 0x000076CD267DB900
000076cd267d66f6  nop [rax+rax*1], ax
000076cd267d66ff  nop [rax+rax*1], eax
000076cd267d6707  mov eax, 0x410444
000076cd267d670c  mov [r15+0x100], rax
000076cd267d6713  jmp 0x000076CD265FE110
000076cd267d6718  cmp dword ptr [r15+0x318], 0x00
000076cd267d6720  jz 0x000076CD267D57E0
000076cd267d6726  nop [rax+rax*1], ax
000076cd267d672f  nop [rax+rax*1], eax
000076cd267d6737  mov eax, 0x410278
000076cd267d673c  mov [r15+0x100], rax
000076cd267d6743  jmp 0x000076CD265FE110
000076cd267d6748  int3
000076cd267d6749  call 0x000076CD2660A4B0
000076cd267d674e  jmp 0x000076CD267D5828
000076cd267d6753  call 0x000076CD26609240
000076cd267d6758  jmp 0x000076CD267D5832
000076cd267d675d  call 0x000076CD2660A4B0
000076cd267d6762  jmp 0x000076CD267D588F
000076cd267d6767  call 0x000076CD26609240
000076cd267d676c  jmp 0x000076CD267D5899
000076cd267d6771  call 0x000076CD2660A4B0
000076cd267d6776  jmp 0x000076CD267D58DD
000076cd267d677b  call 0x000076CD26609240
000076cd267d6780  jmp 0x000076CD267D58E7
000076cd267d6785  call 0x000076CD266B47C0
000076cd267d678a  jmp 0x000076CD267D5926
000076cd267d678f  call 0x000076CD2660B720
000076cd267d6794  jmp 0x000076CD267D593A
000076cd267d6799  call 0x000076CD266BFC30
000076cd267d679e  jmp 0x000076CD267D5958
000076cd267d67a3  call 0x000076CD266BE9C0
000076cd267d67a8  jmp 0x000076CD267D5962
000076cd267d67ad  call 0x000076CD266BD750
000076cd267d67b2  jmp 0x000076CD267D596C
000076cd267d67b7  sub rsp, 0x08
000076cd267d67bb  push rax
000076cd267d67bc  push rcx
000076cd267d67bd  push rdx
000076cd267d67be  push rdi
000076cd267d67bf  push rsi
000076cd267d67c0  push r8
000076cd267d67c2  push r9
000076cd267d67c4  push r10
000076cd267d67c6  push r11
000076cd267d67c8  sub rsp, 0xF0
000076cd267d67cf  vmovaps [rsp], xmm0
000076cd267d67d4  vmovaps [rsp+0x10], xmm1
000076cd267d67da  vmovaps [rsp+0x20], xmm2
000076cd267d67e0  vmovaps [rsp+0x30], xmm3
000076cd267d67e6  vmovaps [rsp+0x40], xmm4
000076cd267d67ec  vmovaps [rsp+0x50], xmm5
000076cd267d67f2  vmovaps [rsp+0x60], xmm6
000076cd267d67f8  vmovaps [rsp+0x70], xmm7
000076cd267d67fe  vmovaps [rsp+0x80], xmm9
000076cd267d6807  vmovaps [rsp+0x90], xmm10
000076cd267d6810  vmovaps [rsp+0xA0], xmm11
000076cd267d6819  vmovaps [rsp+0xB0], xmm12
000076cd267d6822  vmovaps [rsp+0xC0], xmm13
000076cd267d682b  vmovaps [rsp+0xD0], xmm14
000076cd267d6834  vmovaps [rsp+0xE0], xmm15
000076cd267d683d  sub rsp, 0x30
000076cd267d6841  movaps [rsp], xmm8
000076cd267d6846  movaps [rsp+0x10], xmm12
000076cd267d684c  movaps [rsp+0x20], xmm15
000076cd267d6852  lea rdi, [rsp]
000076cd267d6856  mov esi, 0x00
000076cd267d685b  mov rax, 0x56B8861A9530
000076cd267d6865  call rax
000076cd267d6867  movaps xmm8, [rsp]
000076cd267d686c  add rsp, 0x30
000076cd267d6870  vmovaps xmm0, [rsp]
000076cd267d6875  vmovaps xmm1, [rsp+0x10]
000076cd267d687b  vmovaps xmm2, [rsp+0x20]
000076cd267d6881  vmovaps xmm3, [rsp+0x30]
000076cd267d6887  vmovaps xmm4, [rsp+0x40]
000076cd267d688d  vmovaps xmm5, [rsp+0x50]
000076cd267d6893  vmovaps xmm6, [rsp+0x60]
000076cd267d6899  vmovaps xmm7, [rsp+0x70]
000076cd267d689f  vmovaps xmm9, [rsp+0x80]
000076cd267d68a8  vmovaps xmm10, [rsp+0x90]
000076cd267d68b1  vmovaps xmm11, [rsp+0xA0]
000076cd267d68ba  vmovaps xmm12, [rsp+0xB0]
000076cd267d68c3  vmovaps xmm13, [rsp+0xC0]
000076cd267d68cc  vmovaps xmm14, [rsp+0xD0]
000076cd267d68d5  vmovaps xmm15, [rsp+0xE0]
000076cd267d68de  add rsp, 0xF0
000076cd267d68e5  pop r11
000076cd267d68e7  pop r10
000076cd267d68e9  pop r9
000076cd267d68eb  pop r8
000076cd267d68ed  pop rsi
000076cd267d68ee  pop rdi
000076cd267d68ef  pop rdx
000076cd267d68f0  pop rcx
000076cd267d68f1  pop rax
000076cd267d68f2  add rsp, 0x08
000076cd267d68f6  jmp 0x000076CD267D599A
000076cd267d68fb  sub rsp, 0x08
000076cd267d68ff  push rax
000076cd267d6900  push rcx
000076cd267d6901  push rdx
000076cd267d6902  push rdi
000076cd267d6903  push rsi
000076cd267d6904  push r8
000076cd267d6906  push r9
000076cd267d6908  push r10
000076cd267d690a  push r11
000076cd267d690c  sub rsp, 0xF0
000076cd267d6913  vmovaps [rsp], xmm0
000076cd267d6918  vmovaps [rsp+0x10], xmm1
000076cd267d691e  vmovaps [rsp+0x20], xmm2
000076cd267d6924  vmovaps [rsp+0x30], xmm3
000076cd267d692a  vmovaps [rsp+0x40], xmm4
000076cd267d6930  vmovaps [rsp+0x50], xmm5
000076cd267d6936  vmovaps [rsp+0x60], xmm6
000076cd267d693c  vmovaps [rsp+0x70], xmm8
000076cd267d6942  vmovaps [rsp+0x80], xmm9
000076cd267d694b  vmovaps [rsp+0x90], xmm10
000076cd267d6954  vmovaps [rsp+0xA0], xmm11
000076cd267d695d  vmovaps [rsp+0xB0], xmm12
000076cd267d6966  vmovaps [rsp+0xC0], xmm13
000076cd267d696f  vmovaps [rsp+0xD0], xmm14
000076cd267d6978  vmovaps [rsp+0xE0], xmm15
000076cd267d6981  sub rsp, 0x30
000076cd267d6985  movaps [rsp], xmm7
000076cd267d6989  movaps [rsp+0x10], xmm9
000076cd267d698f  movaps [rsp+0x20], xmm15
000076cd267d6995  lea rdi, [rsp]
000076cd267d6999  mov esi, 0x00
000076cd267d699e  mov rax, 0x56B8861A9530
000076cd267d69a8  call rax
000076cd267d69aa  movaps xmm7, [rsp]
000076cd267d69ae  add rsp, 0x30
000076cd267d69b2  vmovaps xmm0, [rsp]
000076cd267d69b7  vmovaps xmm1, [rsp+0x10]
000076cd267d69bd  vmovaps xmm2, [rsp+0x20]
000076cd267d69c3  vmovaps xmm3, [rsp+0x30]
000076cd267d69c9  vmovaps xmm4, [rsp+0x40]
000076cd267d69cf  vmovaps xmm5, [rsp+0x50]
000076cd267d69d5  vmovaps xmm6, [rsp+0x60]
000076cd267d69db  vmovaps xmm8, [rsp+0x70]
000076cd267d69e1  vmovaps xmm9, [rsp+0x80]
000076cd267d69ea  vmovaps xmm10, [rsp+0x90]
000076cd267d69f3  vmovaps xmm11, [rsp+0xA0]
000076cd267d69fc  vmovaps xmm12, [rsp+0xB0]
000076cd267d6a05  vmovaps xmm13, [rsp+0xC0]
000076cd267d6a0e  vmovaps xmm14, [rsp+0xD0]
000076cd267d6a17  vmovaps xmm15, [rsp+0xE0]
000076cd267d6a20  add rsp, 0xF0
000076cd267d6a27  pop r11
000076cd267d6a29  pop r10
000076cd267d6a2b  pop r9
000076cd267d6a2d  pop r8
000076cd267d6a2f  pop rsi
000076cd267d6a30  pop rdi
000076cd267d6a31  pop rdx
000076cd267d6a32  pop rcx
000076cd267d6a33  pop rax
000076cd267d6a34  add rsp, 0x08
000076cd267d6a38  jmp 0x000076CD267D59C8
000076cd267d6a3d  sub rsp, 0x08
000076cd267d6a41  push rax
000076cd267d6a42  push rcx
000076cd267d6a43  push rdx
000076cd267d6a44  push rdi
000076cd267d6a45  push rsi
000076cd267d6a46  push r8
000076cd267d6a48  push r9
000076cd267d6a4a  push r10
000076cd267d6a4c  push r11
000076cd267d6a4e  sub rsp, 0xF0
000076cd267d6a55  vmovaps [rsp], xmm0
000076cd267d6a5a  vmovaps [rsp+0x10], xmm1
000076cd267d6a60  vmovaps [rsp+0x20], xmm2
000076cd267d6a66  vmovaps [rsp+0x30], xmm3
000076cd267d6a6c  vmovaps [rsp+0x40], xmm4
000076cd267d6a72  vmovaps [rsp+0x50], xmm5
000076cd267d6a78  vmovaps [rsp+0x60], xmm6
000076cd267d6a7e  vmovaps [rsp+0x70], xmm7
000076cd267d6a84  vmovaps [rsp+0x80], xmm8
000076cd267d6a8d  vmovaps [rsp+0x90], xmm10
000076cd267d6a96  vmovaps [rsp+0xA0], xmm11
000076cd267d6a9f  vmovaps [rsp+0xB0], xmm12
000076cd267d6aa8  vmovaps [rsp+0xC0], xmm13
000076cd267d6ab1  vmovaps [rsp+0xD0], xmm14
000076cd267d6aba  vmovaps [rsp+0xE0], xmm15
000076cd267d6ac3  sub rsp, 0x30
000076cd267d6ac7  movaps [rsp], xmm9
000076cd267d6acc  movaps [rsp+0x10], xmm12
000076cd267d6ad2  movaps [rsp+0x20], xmm10
000076cd267d6ad8  lea rdi, [rsp]
000076cd267d6adc  mov esi, 0x00
000076cd267d6ae1  mov rax, 0x56B8861A9530
000076cd267d6aeb  call rax
000076cd267d6aed  movaps xmm9, [rsp]
000076cd267d6af2  add rsp, 0x30
000076cd267d6af6  vmovaps xmm0, [rsp]
000076cd267d6afb  vmovaps xmm1, [rsp+0x10]
000076cd267d6b01  vmovaps xmm2, [rsp+0x20]
000076cd267d6b07  vmovaps xmm3, [rsp+0x30]
000076cd267d6b0d  vmovaps xmm4, [rsp+0x40]
000076cd267d6b13  vmovaps xmm5, [rsp+0x50]
000076cd267d6b19  vmovaps xmm6, [rsp+0x60]
000076cd267d6b1f  vmovaps xmm7, [rsp+0x70]
000076cd267d6b25  vmovaps xmm8, [rsp+0x80]
000076cd267d6b2e  vmovaps xmm10, [rsp+0x90]
000076cd267d6b37  vmovaps xmm11, [rsp+0xA0]
000076cd267d6b40  vmovaps xmm12, [rsp+0xB0]
000076cd267d6b49  vmovaps xmm13, [rsp+0xC0]
000076cd267d6b52  vmovaps xmm14, [rsp+0xD0]
000076cd267d6b5b  vmovaps xmm15, [rsp+0xE0]
000076cd267d6b64  add rsp, 0xF0
000076cd267d6b6b  pop r11
000076cd267d6b6d  pop r10
000076cd267d6b6f  pop r9
000076cd267d6b71  pop r8
000076cd267d6b73  pop rsi
000076cd267d6b74  pop rdi
000076cd267d6b75  pop rdx
000076cd267d6b76  pop rcx
000076cd267d6b77  pop rax
000076cd267d6b78  add rsp, 0x08
000076cd267d6b7c  jmp 0x000076CD267D59EC
000076cd267d6b81  sub rsp, 0x08
000076cd267d6b85  push rax
000076cd267d6b86  push rcx
000076cd267d6b87  push rdx
000076cd267d6b88  push rdi
000076cd267d6b89  push rsi
000076cd267d6b8a  push r8
000076cd267d6b8c  push r9
000076cd267d6b8e  push r10
000076cd267d6b90  push r11
000076cd267d6b92  sub rsp, 0xF0
000076cd267d6b99  vmovaps [rsp], xmm0
000076cd267d6b9e  vmovaps [rsp+0x10], xmm1
000076cd267d6ba4  vmovaps [rsp+0x20], xmm2
000076cd267d6baa  vmovaps [rsp+0x30], xmm3
000076cd267d6bb0  vmovaps [rsp+0x40], xmm4
000076cd267d6bb6  vmovaps [rsp+0x50], xmm5
000076cd267d6bbc  vmovaps [rsp+0x60], xmm6
000076cd267d6bc2  vmovaps [rsp+0x70], xmm7
000076cd267d6bc8  vmovaps [rsp+0x80], xmm8
000076cd267d6bd1  vmovaps [rsp+0x90], xmm9
000076cd267d6bda  vmovaps [rsp+0xA0], xmm11
000076cd267d6be3  vmovaps [rsp+0xB0], xmm12
000076cd267d6bec  vmovaps [rsp+0xC0], xmm13
000076cd267d6bf5  vmovaps [rsp+0xD0], xmm14
000076cd267d6bfe  vmovaps [rsp+0xE0], xmm15
000076cd267d6c07  sub rsp, 0x30
000076cd267d6c0b  movaps [rsp], xmm10
000076cd267d6c10  movaps [rsp+0x10], xmm12
000076cd267d6c16  movaps [rsp+0x20], xmm11
000076cd267d6c1c  lea rdi, [rsp]
000076cd267d6c20  mov esi, 0x00
000076cd267d6c25  mov rax, 0x56B8861A9530
000076cd267d6c2f  call rax
000076cd267d6c31  movaps xmm10, [rsp]
000076cd267d6c36  add rsp, 0x30
000076cd267d6c3a  vmovaps xmm0, [rsp]
000076cd267d6c3f  vmovaps xmm1, [rsp+0x10]
000076cd267d6c45  vmovaps xmm2, [rsp+0x20]
000076cd267d6c4b  vmovaps xmm3, [rsp+0x30]
000076cd267d6c51  vmovaps xmm4, [rsp+0x40]
000076cd267d6c57  vmovaps xmm5, [rsp+0x50]
000076cd267d6c5d  vmovaps xmm6, [rsp+0x60]
000076cd267d6c63  vmovaps xmm7, [rsp+0x70]
000076cd267d6c69  vmovaps xmm8, [rsp+0x80]
000076cd267d6c72  vmovaps xmm9, [rsp+0x90]
000076cd267d6c7b  vmovaps xmm11, [rsp+0xA0]
000076cd267d6c84  vmovaps xmm12, [rsp+0xB0]
000076cd267d6c8d  vmovaps xmm13, [rsp+0xC0]
000076cd267d6c96  vmovaps xmm14, [rsp+0xD0]
000076cd267d6c9f  vmovaps xmm15, [rsp+0xE0]
000076cd267d6ca8  add rsp, 0xF0
000076cd267d6caf  pop r11
000076cd267d6cb1  pop r10
000076cd267d6cb3  pop r9
000076cd267d6cb5  pop r8
000076cd267d6cb7  pop rsi
000076cd267d6cb8  pop rdi
000076cd267d6cb9  pop rdx
000076cd267d6cba  pop rcx
000076cd267d6cbb  pop rax
000076cd267d6cbc  add rsp, 0x08
000076cd267d6cc0  jmp 0x000076CD267D5A06
000076cd267d6cc5  sub rsp, 0x08
000076cd267d6cc9  push rax
000076cd267d6cca  push rcx
000076cd267d6ccb  push rdx
000076cd267d6ccc  push rdi
000076cd267d6ccd  push rsi
000076cd267d6cce  push r8
000076cd267d6cd0  push r9
000076cd267d6cd2  push r10
000076cd267d6cd4  push r11
000076cd267d6cd6  sub rsp, 0xF0
000076cd267d6cdd  vmovaps [rsp], xmm0
000076cd267d6ce2  vmovaps [rsp+0x10], xmm1
000076cd267d6ce8  vmovaps [rsp+0x20], xmm2
000076cd267d6cee  vmovaps [rsp+0x30], xmm3
000076cd267d6cf4  vmovaps [rsp+0x40], xmm4
000076cd267d6cfa  vmovaps [rsp+0x50], xmm5
000076cd267d6d00  vmovaps [rsp+0x60], xmm7
000076cd267d6d06  vmovaps [rsp+0x70], xmm8
000076cd267d6d0c  vmovaps [rsp+0x80], xmm9
000076cd267d6d15  vmovaps [rsp+0x90], xmm10
000076cd267d6d1e  vmovaps [rsp+0xA0], xmm11
000076cd267d6d27  vmovaps [rsp+0xB0], xmm12
000076cd267d6d30  vmovaps [rsp+0xC0], xmm13
000076cd267d6d39  vmovaps [rsp+0xD0], xmm14
000076cd267d6d42  vmovaps [rsp+0xE0], xmm15
000076cd267d6d4b  sub rsp, 0x30
000076cd267d6d4f  movaps [rsp], xmm6
000076cd267d6d53  movaps [rsp+0x10], xmm12
000076cd267d6d59  movaps [rsp+0x20], xmm11
000076cd267d6d5f  lea rdi, [rsp]
000076cd267d6d63  mov esi, 0x00
000076cd267d6d68  mov rax, 0x56B8861A9530
000076cd267d6d72  call rax
000076cd267d6d74  movaps xmm6, [rsp]
000076cd267d6d78  add rsp, 0x30
000076cd267d6d7c  vmovaps xmm0, [rsp]
000076cd267d6d81  vmovaps xmm1, [rsp+0x10]
000076cd267d6d87  vmovaps xmm2, [rsp+0x20]
000076cd267d6d8d  vmovaps xmm3, [rsp+0x30]
000076cd267d6d93  vmovaps xmm4, [rsp+0x40]
000076cd267d6d99  vmovaps xmm5, [rsp+0x50]
000076cd267d6d9f  vmovaps xmm7, [rsp+0x60]
000076cd267d6da5  vmovaps xmm8, [rsp+0x70]
000076cd267d6dab  vmovaps xmm9, [rsp+0x80]
000076cd267d6db4  vmovaps xmm10, [rsp+0x90]
000076cd267d6dbd  vmovaps xmm11, [rsp+0xA0]
000076cd267d6dc6  vmovaps xmm12, [rsp+0xB0]
000076cd267d6dcf  vmovaps xmm13, [rsp+0xC0]
000076cd267d6dd8  vmovaps xmm14, [rsp+0xD0]
000076cd267d6de1  vmovaps xmm15, [rsp+0xE0]
000076cd267d6dea  add rsp, 0xF0
000076cd267d6df1  pop r11
000076cd267d6df3  pop r10
000076cd267d6df5  pop r9
000076cd267d6df7  pop r8
000076cd267d6df9  pop rsi
000076cd267d6dfa  pop rdi
000076cd267d6dfb  pop rdx
000076cd267d6dfc  pop rcx
000076cd267d6dfd  pop rax
000076cd267d6dfe  add rsp, 0x08
000076cd267d6e02  jmp 0x000076CD267D5A27
000076cd267d6e07  sub rsp, 0x08
000076cd267d6e0b  push rax
000076cd267d6e0c  push rcx
000076cd267d6e0d  push rdx
000076cd267d6e0e  push rdi
000076cd267d6e0f  push rsi
000076cd267d6e10  push r8
000076cd267d6e12  push r9
000076cd267d6e14  push r10
000076cd267d6e16  push r11
000076cd267d6e18  sub rsp, 0xF0
000076cd267d6e1f  vmovaps [rsp], xmm0
000076cd267d6e24  vmovaps [rsp+0x10], xmm1
000076cd267d6e2a  vmovaps [rsp+0x20], xmm2
000076cd267d6e30  vmovaps [rsp+0x30], xmm4
000076cd267d6e36  vmovaps [rsp+0x40], xmm5
000076cd267d6e3c  vmovaps [rsp+0x50], xmm6
000076cd267d6e42  vmovaps [rsp+0x60], xmm7
000076cd267d6e48  vmovaps [rsp+0x70], xmm8
000076cd267d6e4e  vmovaps [rsp+0x80], xmm9
000076cd267d6e57  vmovaps [rsp+0x90], xmm10
000076cd267d6e60  vmovaps [rsp+0xA0], xmm11
000076cd267d6e69  vmovaps [rsp+0xB0], xmm12
000076cd267d6e72  vmovaps [rsp+0xC0], xmm13
000076cd267d6e7b  vmovaps [rsp+0xD0], xmm14
000076cd267d6e84  vmovaps [rsp+0xE0], xmm15
000076cd267d6e8d  sub rsp, 0x30
000076cd267d6e91  movaps [rsp], xmm3
000076cd267d6e95  movaps [rsp+0x10], xmm5
000076cd267d6e9a  movaps [rsp+0x20], xmm4
000076cd267d6e9f  lea rdi, [rsp]
000076cd267d6ea3  mov esi, 0x00
000076cd267d6ea8  mov rax, 0x56B8861A9530
000076cd267d6eb2  call rax
000076cd267d6eb4  movaps xmm3, [rsp]
000076cd267d6eb8  add rsp, 0x30
000076cd267d6ebc  vmovaps xmm0, [rsp]
000076cd267d6ec1  vmovaps xmm1, [rsp+0x10]
000076cd267d6ec7  vmovaps xmm2, [rsp+0x20]
000076cd267d6ecd  vmovaps xmm4, [rsp+0x30]
000076cd267d6ed3  vmovaps xmm5, [rsp+0x40]
000076cd267d6ed9  vmovaps xmm6, [rsp+0x50]
000076cd267d6edf  vmovaps xmm7, [rsp+0x60]
000076cd267d6ee5  vmovaps xmm8, [rsp+0x70]
000076cd267d6eeb  vmovaps xmm9, [rsp+0x80]
000076cd267d6ef4  vmovaps xmm10, [rsp+0x90]
000076cd267d6efd  vmovaps xmm11, [rsp+0xA0]
000076cd267d6f06  vmovaps xmm12, [rsp+0xB0]
000076cd267d6f0f  vmovaps xmm13, [rsp+0xC0]
000076cd267d6f18  vmovaps xmm14, [rsp+0xD0]
000076cd267d6f21  vmovaps xmm15, [rsp+0xE0]
000076cd267d6f2a  add rsp, 0xF0
000076cd267d6f31  pop r11
000076cd267d6f33  pop r10
000076cd267d6f35  pop r9
000076cd267d6f37  pop r8
000076cd267d6f39  pop rsi
000076cd267d6f3a  pop rdi
000076cd267d6f3b  pop rdx
000076cd267d6f3c  pop rcx
000076cd267d6f3d  pop rax
000076cd267d6f3e  add rsp, 0x08
000076cd267d6f42  jmp 0x000076CD267D5A88
000076cd267d6f47  sub rsp, 0x08
000076cd267d6f4b  push rax
000076cd267d6f4c  push rcx
000076cd267d6f4d  push rdx
000076cd267d6f4e  push rdi
000076cd267d6f4f  push rsi
000076cd267d6f50  push r8
000076cd267d6f52  push r9
000076cd267d6f54  push r10
000076cd267d6f56  push r11
000076cd267d6f58  sub rsp, 0xF0
000076cd267d6f5f  vmovaps [rsp], xmm0
000076cd267d6f64  vmovaps [rsp+0x10], xmm1
000076cd267d6f6a  vmovaps [rsp+0x20], xmm2
000076cd267d6f70  vmovaps [rsp+0x30], xmm3
000076cd267d6f76  vmovaps [rsp+0x40], xmm4
000076cd267d6f7c  vmovaps [rsp+0x50], xmm6
000076cd267d6f82  vmovaps [rsp+0x60], xmm7
000076cd267d6f88  vmovaps [rsp+0x70], xmm8
000076cd267d6f8e  vmovaps [rsp+0x80], xmm9
000076cd267d6f97  vmovaps [rsp+0x90], xmm10
000076cd267d6fa0  vmovaps [rsp+0xA0], xmm11
000076cd267d6fa9  vmovaps [rsp+0xB0], xmm12
000076cd267d6fb2  vmovaps [rsp+0xC0], xmm13
000076cd267d6fbb  vmovaps [rsp+0xD0], xmm14
000076cd267d6fc4  vmovaps [rsp+0xE0], xmm15
000076cd267d6fcd  sub rsp, 0x30
000076cd267d6fd1  movaps [rsp], xmm5
000076cd267d6fd5  movaps [rsp+0x10], xmm8
000076cd267d6fdb  movaps [rsp+0x20], xmm15
000076cd267d6fe1  lea rdi, [rsp]
000076cd267d6fe5  mov esi, 0x00
000076cd267d6fea  mov rax, 0x56B8861A9530
000076cd267d6ff4  call rax
000076cd267d6ff6  movaps xmm5, [rsp]
000076cd267d6ffa  add rsp, 0x30
000076cd267d6ffe  vmovaps xmm0, [rsp]
000076cd267d7003  vmovaps xmm1, [rsp+0x10]
000076cd267d7009  vmovaps xmm2, [rsp+0x20]
000076cd267d700f  vmovaps xmm3, [rsp+0x30]
000076cd267d7015  vmovaps xmm4, [rsp+0x40]
000076cd267d701b  vmovaps xmm6, [rsp+0x50]
000076cd267d7021  vmovaps xmm7, [rsp+0x60]
000076cd267d7027  vmovaps xmm8, [rsp+0x70]
000076cd267d702d  vmovaps xmm9, [rsp+0x80]
000076cd267d7036  vmovaps xmm10, [rsp+0x90]
000076cd267d703f  vmovaps xmm11, [rsp+0xA0]
000076cd267d7048  vmovaps xmm12, [rsp+0xB0]
000076cd267d7051  vmovaps xmm13, [rsp+0xC0]
000076cd267d705a  vmovaps xmm14, [rsp+0xD0]
000076cd267d7063  vmovaps xmm15, [rsp+0xE0]
000076cd267d706c  add rsp, 0xF0
000076cd267d7073  pop r11
000076cd267d7075  pop r10
000076cd267d7077  pop r9
000076cd267d7079  pop r8
000076cd267d707b  pop rsi
000076cd267d707c  pop rdi
000076cd267d707d  pop rdx
000076cd267d707e  pop rcx
000076cd267d707f  pop rax
000076cd267d7080  add rsp, 0x08
000076cd267d7084  jmp 0x000076CD267D5AC0
000076cd267d7089  sub rsp, 0x08
000076cd267d708d  push rax
000076cd267d708e  push rcx
000076cd267d708f  push rdx
000076cd267d7090  push rdi
000076cd267d7091  push rsi
000076cd267d7092  push r8
000076cd267d7094  push r9
000076cd267d7096  push r10
000076cd267d7098  push r11
000076cd267d709a  sub rsp, 0xF0
000076cd267d70a1  vmovaps [rsp], xmm0
000076cd267d70a6  vmovaps [rsp+0x10], xmm1
000076cd267d70ac  vmovaps [rsp+0x20], xmm2
000076cd267d70b2  vmovaps [rsp+0x30], xmm3
000076cd267d70b8  vmovaps [rsp+0x40], xmm5
000076cd267d70be  vmovaps [rsp+0x50], xmm6
000076cd267d70c4  vmovaps [rsp+0x60], xmm7
000076cd267d70ca  vmovaps [rsp+0x70], xmm8
000076cd267d70d0  vmovaps [rsp+0x80], xmm9
000076cd267d70d9  vmovaps [rsp+0x90], xmm10
000076cd267d70e2  vmovaps [rsp+0xA0], xmm11
000076cd267d70eb  vmovaps [rsp+0xB0], xmm12
000076cd267d70f4  vmovaps [rsp+0xC0], xmm13
000076cd267d70fd  vmovaps [rsp+0xD0], xmm14
000076cd267d7106  vmovaps [rsp+0xE0], xmm15
000076cd267d710f  sub rsp, 0x30
000076cd267d7113  movaps [rsp], xmm4
000076cd267d7117  movaps [rsp+0x10], xmm9
000076cd267d711d  movaps [rsp+0x20], xmm8
000076cd267d7123  lea rdi, [rsp]
000076cd267d7127  mov esi, 0x00
000076cd267d712c  mov rax, 0x56B8861A9530
000076cd267d7136  call rax
000076cd267d7138  movaps xmm4, [rsp]
000076cd267d713c  add rsp, 0x30
000076cd267d7140  vmovaps xmm0, [rsp]
000076cd267d7145  vmovaps xmm1, [rsp+0x10]
000076cd267d714b  vmovaps xmm2, [rsp+0x20]
000076cd267d7151  vmovaps xmm3, [rsp+0x30]
000076cd267d7157  vmovaps xmm5, [rsp+0x40]
000076cd267d715d  vmovaps xmm6, [rsp+0x50]
000076cd267d7163  vmovaps xmm7, [rsp+0x60]
000076cd267d7169  vmovaps xmm8, [rsp+0x70]
000076cd267d716f  vmovaps xmm9, [rsp+0x80]
000076cd267d7178  vmovaps xmm10, [rsp+0x90]
000076cd267d7181  vmovaps xmm11, [rsp+0xA0]
000076cd267d718a  vmovaps xmm12, [rsp+0xB0]
000076cd267d7193  vmovaps xmm13, [rsp+0xC0]
000076cd267d719c  vmovaps xmm14, [rsp+0xD0]
000076cd267d71a5  vmovaps xmm15, [rsp+0xE0]
000076cd267d71ae  add rsp, 0xF0
000076cd267d71b5  pop r11
000076cd267d71b7  pop r10
000076cd267d71b9  pop r9
000076cd267d71bb  pop r8
000076cd267d71bd  pop rsi
000076cd267d71be  pop rdi
000076cd267d71bf  pop rdx
000076cd267d71c0  pop rcx
000076cd267d71c1  pop rax
000076cd267d71c2  add rsp, 0x08
000076cd267d71c6  jmp 0x000076CD267D5AE1
000076cd267d71cb  sub rsp, 0x08
000076cd267d71cf  push rax
000076cd267d71d0  push rcx
000076cd267d71d1  push rdx
000076cd267d71d2  push rdi
000076cd267d71d3  push rsi
000076cd267d71d4  push r8
000076cd267d71d6  push r9
000076cd267d71d8  push r10
000076cd267d71da  push r11
000076cd267d71dc  sub rsp, 0xF0
000076cd267d71e3  vmovaps [rsp], xmm0
000076cd267d71e8  vmovaps [rsp+0x10], xmm1
000076cd267d71ee  vmovaps [rsp+0x20], xmm2
000076cd267d71f4  vmovaps [rsp+0x30], xmm3
000076cd267d71fa  vmovaps [rsp+0x40], xmm4
000076cd267d7200  vmovaps [rsp+0x50], xmm5
000076cd267d7206  vmovaps [rsp+0x60], xmm6
000076cd267d720c  vmovaps [rsp+0x70], xmm7
000076cd267d7212  vmovaps [rsp+0x80], xmm8
000076cd267d721b  vmovaps [rsp+0x90], xmm10
000076cd267d7224  vmovaps [rsp+0xA0], xmm11
000076cd267d722d  vmovaps [rsp+0xB0], xmm12
000076cd267d7236  vmovaps [rsp+0xC0], xmm13
000076cd267d723f  vmovaps [rsp+0xD0], xmm14
000076cd267d7248  vmovaps [rsp+0xE0], xmm15
000076cd267d7251  sub rsp, 0x30
000076cd267d7255  movaps [rsp], xmm9
000076cd267d725a  movaps [rsp+0x10], xmm10
000076cd267d7260  movaps [rsp+0x20], xmm8
000076cd267d7266  lea rdi, [rsp]
000076cd267d726a  mov esi, 0x00
000076cd267d726f  mov rax, 0x56B8861A9530
000076cd267d7279  call rax
000076cd267d727b  movaps xmm9, [rsp]
000076cd267d7280  add rsp, 0x30
000076cd267d7284  vmovaps xmm0, [rsp]
000076cd267d7289  vmovaps xmm1, [rsp+0x10]
000076cd267d728f  vmovaps xmm2, [rsp+0x20]
000076cd267d7295  vmovaps xmm3, [rsp+0x30]
000076cd267d729b  vmovaps xmm4, [rsp+0x40]
000076cd267d72a1  vmovaps xmm5, [rsp+0x50]
000076cd267d72a7  vmovaps xmm6, [rsp+0x60]
000076cd267d72ad  vmovaps xmm7, [rsp+0x70]
000076cd267d72b3  vmovaps xmm8, [rsp+0x80]
000076cd267d72bc  vmovaps xmm10, [rsp+0x90]
000076cd267d72c5  vmovaps xmm11, [rsp+0xA0]
000076cd267d72ce  vmovaps xmm12, [rsp+0xB0]
000076cd267d72d7  vmovaps xmm13, [rsp+0xC0]
000076cd267d72e0  vmovaps xmm14, [rsp+0xD0]
000076cd267d72e9  vmovaps xmm15, [rsp+0xE0]
000076cd267d72f2  add rsp, 0xF0
000076cd267d72f9  pop r11
000076cd267d72fb  pop r10
000076cd267d72fd  pop r9
000076cd267d72ff  pop r8
000076cd267d7301  pop rsi
000076cd267d7302  pop rdi
000076cd267d7303  pop rdx
000076cd267d7304  pop rcx
000076cd267d7305  pop rax
000076cd267d7306  add rsp, 0x08
000076cd267d730a  jmp 0x000076CD267D5AFB
000076cd267d730f  call 0x000076CD266D64F0
000076cd267d7314  jmp 0x000076CD267D5C15
000076cd267d7319  call 0x000076CD266D64F0
000076cd267d731e  jmp 0x000076CD267D5C2B
000076cd267d7323  sub rsp, 0x08
000076cd267d7327  push rax
000076cd267d7328  push rcx
000076cd267d7329  push rdx
000076cd267d732a  push rdi
000076cd267d732b  push rsi
000076cd267d732c  push r8
000076cd267d732e  push r9
000076cd267d7330  push r10
000076cd267d7332  push r11
000076cd267d7334  sub rsp, 0xF0
000076cd267d733b  vmovaps [rsp], xmm0
000076cd267d7340  vmovaps [rsp+0x10], xmm2
000076cd267d7346  vmovaps [rsp+0x20], xmm3
000076cd267d734c  vmovaps [rsp+0x30], xmm4
000076cd267d7352  vmovaps [rsp+0x40], xmm5
000076cd267d7358  vmovaps [rsp+0x50], xmm6
000076cd267d735e  vmovaps [rsp+0x60], xmm7
000076cd267d7364  vmovaps [rsp+0x70], xmm8
000076cd267d736a  vmovaps [rsp+0x80], xmm9
000076cd267d7373  vmovaps [rsp+0x90], xmm10
000076cd267d737c  vmovaps [rsp+0xA0], xmm11
000076cd267d7385  vmovaps [rsp+0xB0], xmm12
000076cd267d738e  vmovaps [rsp+0xC0], xmm13
000076cd267d7397  vmovaps [rsp+0xD0], xmm14
000076cd267d73a0  vmovaps [rsp+0xE0], xmm15
000076cd267d73a9  sub rsp, 0x30
000076cd267d73ad  movaps [rsp], xmm1
000076cd267d73b1  movaps [rsp+0x10], xmm6
000076cd267d73b6  movaps [rsp+0x20], xmm15
000076cd267d73bc  lea rdi, [rsp]
000076cd267d73c0  mov esi, 0x00
000076cd267d73c5  mov rax, 0x56B8861A9530
000076cd267d73cf  call rax
000076cd267d73d1  movaps xmm1, [rsp]
000076cd267d73d5  add rsp, 0x30
000076cd267d73d9  vmovaps xmm0, [rsp]
000076cd267d73de  vmovaps xmm2, [rsp+0x10]
000076cd267d73e4  vmovaps xmm3, [rsp+0x20]
000076cd267d73ea  vmovaps xmm4, [rsp+0x30]
000076cd267d73f0  vmovaps xmm5, [rsp+0x40]
000076cd267d73f6  vmovaps xmm6, [rsp+0x50]
000076cd267d73fc  vmovaps xmm7, [rsp+0x60]
000076cd267d7402  vmovaps xmm8, [rsp+0x70]
000076cd267d7408  vmovaps xmm9, [rsp+0x80]
000076cd267d7411  vmovaps xmm10, [rsp+0x90]
000076cd267d741a  vmovaps xmm11, [rsp+0xA0]
000076cd267d7423  vmovaps xmm12, [rsp+0xB0]
000076cd267d742c  vmovaps xmm13, [rsp+0xC0]
000076cd267d7435  vmovaps xmm14, [rsp+0xD0]
000076cd267d743e  vmovaps xmm15, [rsp+0xE0]
000076cd267d7447  add rsp, 0xF0
000076cd267d744e  pop r11
000076cd267d7450  pop r10
000076cd267d7452  pop r9
000076cd267d7454  pop r8
000076cd267d7456  pop rsi
000076cd267d7457  pop rdi
000076cd267d7458  pop rdx
000076cd267d7459  pop rcx
000076cd267d745a  pop rax
000076cd267d745b  add rsp, 0x08
000076cd267d745f  jmp 0x000076CD267D5C68
000076cd267d7464  call 0x000076CD266E5820
000076cd267d7469  jmp 0x000076CD267D5C75
000076cd267d746e  sub rsp, 0x08
000076cd267d7472  push rax
000076cd267d7473  push rcx
000076cd267d7474  push rdx
000076cd267d7475  push rdi
000076cd267d7476  push rsi
000076cd267d7477  push r8
000076cd267d7479  push r9
000076cd267d747b  push r10
000076cd267d747d  push r11
000076cd267d747f  sub rsp, 0xF0
000076cd267d7486  vmovaps [rsp], xmm0
000076cd267d748b  vmovaps [rsp+0x10], xmm1
000076cd267d7491  vmovaps [rsp+0x20], xmm2
000076cd267d7497  vmovaps [rsp+0x30], xmm3
000076cd267d749d  vmovaps [rsp+0x40], xmm4
000076cd267d74a3  vmovaps [rsp+0x50], xmm5
000076cd267d74a9  vmovaps [rsp+0x60], xmm6
000076cd267d74af  vmovaps [rsp+0x70], xmm7
000076cd267d74b5  vmovaps [rsp+0x80], xmm8
000076cd267d74be  vmovaps [rsp+0x90], xmm9
000076cd267d74c7  vmovaps [rsp+0xA0], xmm10
000076cd267d74d0  vmovaps [rsp+0xB0], xmm11
000076cd267d74d9  vmovaps [rsp+0xC0], xmm12
000076cd267d74e2  vmovaps [rsp+0xD0], xmm13
000076cd267d74eb  vmovaps [rsp+0xE0], xmm15
000076cd267d74f4  sub rsp, 0x30
000076cd267d74f8  movaps [rsp], xmm14
000076cd267d74fd  movaps [rsp+0x10], xmm4
000076cd267d7502  movaps [rsp+0x20], xmm3
000076cd267d7507  lea rdi, [rsp]
000076cd267d750b  mov esi, 0x00
000076cd267d7510  mov rax, 0x56B8861A9530
000076cd267d751a  call rax
000076cd267d751c  movaps xmm14, [rsp]
000076cd267d7521  add rsp, 0x30
000076cd267d7525  vmovaps xmm0, [rsp]
000076cd267d752a  vmovaps xmm1, [rsp+0x10]
000076cd267d7530  vmovaps xmm2, [rsp+0x20]
000076cd267d7536  vmovaps xmm3, [rsp+0x30]
000076cd267d753c  vmovaps xmm4, [rsp+0x40]
000076cd267d7542  vmovaps xmm5, [rsp+0x50]
000076cd267d7548  vmovaps xmm6, [rsp+0x60]
000076cd267d754e  vmovaps xmm7, [rsp+0x70]
000076cd267d7554  vmovaps xmm8, [rsp+0x80]
000076cd267d755d  vmovaps xmm9, [rsp+0x90]
000076cd267d7566  vmovaps xmm10, [rsp+0xA0]
000076cd267d756f  vmovaps xmm11, [rsp+0xB0]
000076cd267d7578  vmovaps xmm12, [rsp+0xC0]
000076cd267d7581  vmovaps xmm13, [rsp+0xD0]
000076cd267d758a  vmovaps xmm15, [rsp+0xE0]
000076cd267d7593  add rsp, 0xF0
000076cd267d759a  pop r11
000076cd267d759c  pop r10
000076cd267d759e  pop r9
000076cd267d75a0  pop r8
000076cd267d75a2  pop rsi
000076cd267d75a3  pop rdi
000076cd267d75a4  pop rdx
000076cd267d75a5  pop rcx
000076cd267d75a6  pop rax
000076cd267d75a7  add rsp, 0x08
000076cd267d75ab  jmp 0x000076CD267D5C8F
000076cd267d75b0  sub rsp, 0x08
000076cd267d75b4  push rax
000076cd267d75b5  push rcx
000076cd267d75b6  push rdx
000076cd267d75b7  push rdi
000076cd267d75b8  push rsi
000076cd267d75b9  push r8
000076cd267d75bb  push r9
000076cd267d75bd  push r10
000076cd267d75bf  push r11
000076cd267d75c1  sub rsp, 0xF0
000076cd267d75c8  vmovaps [rsp], xmm0
000076cd267d75cd  vmovaps [rsp+0x10], xmm1
000076cd267d75d3  vmovaps [rsp+0x20], xmm2
000076cd267d75d9  vmovaps [rsp+0x30], xmm3
000076cd267d75df  vmovaps [rsp+0x40], xmm4
000076cd267d75e5  vmovaps [rsp+0x50], xmm5
000076cd267d75eb  vmovaps [rsp+0x60], xmm7
000076cd267d75f1  vmovaps [rsp+0x70], xmm8
000076cd267d75f7  vmovaps [rsp+0x80], xmm9
000076cd267d7600  vmovaps [rsp+0x90], xmm10
000076cd267d7609  vmovaps [rsp+0xA0], xmm11
000076cd267d7612  vmovaps [rsp+0xB0], xmm12
000076cd267d761b  vmovaps [rsp+0xC0], xmm13
000076cd267d7624  vmovaps [rsp+0xD0], xmm14
000076cd267d762d  vmovaps [rsp+0xE0], xmm15
000076cd267d7636  sub rsp, 0x30
000076cd267d763a  movaps [rsp], xmm6
000076cd267d763e  movaps [rsp+0x10], xmm9
000076cd267d7644  movaps [rsp+0x20], xmm7
000076cd267d7649  lea rdi, [rsp]
000076cd267d764d  mov esi, 0x00
000076cd267d7652  mov rax, 0x56B8861A9530
000076cd267d765c  call rax
000076cd267d765e  movaps xmm6, [rsp]
000076cd267d7662  add rsp, 0x30
000076cd267d7666  vmovaps xmm0, [rsp]
000076cd267d766b  vmovaps xmm1, [rsp+0x10]
000076cd267d7671  vmovaps xmm2, [rsp+0x20]
000076cd267d7677  vmovaps xmm3, [rsp+0x30]
000076cd267d767d  vmovaps xmm4, [rsp+0x40]
000076cd267d7683  vmovaps xmm5, [rsp+0x50]
000076cd267d7689  vmovaps xmm7, [rsp+0x60]
000076cd267d768f  vmovaps xmm8, [rsp+0x70]
000076cd267d7695  vmovaps xmm9, [rsp+0x80]
000076cd267d769e  vmovaps xmm10, [rsp+0x90]
000076cd267d76a7  vmovaps xmm11, [rsp+0xA0]
000076cd267d76b0  vmovaps xmm12, [rsp+0xB0]
000076cd267d76b9  vmovaps xmm13, [rsp+0xC0]
000076cd267d76c2  vmovaps xmm14, [rsp+0xD0]
000076cd267d76cb  vmovaps xmm15, [rsp+0xE0]
000076cd267d76d4  add rsp, 0xF0
000076cd267d76db  pop r11
000076cd267d76dd  pop r10
000076cd267d76df  pop r9
000076cd267d76e1  pop r8
000076cd267d76e3  pop rsi
000076cd267d76e4  pop rdi
000076cd267d76e5  pop rdx
000076cd267d76e6  pop rcx
000076cd267d76e7  pop rax
000076cd267d76e8  add rsp, 0x08
000076cd267d76ec  jmp 0x000076CD267D5CA7
000076cd267d76f1  sub rsp, 0x08
000076cd267d76f5  push rax
000076cd267d76f6  push rcx
000076cd267d76f7  push rdx
000076cd267d76f8  push rdi
000076cd267d76f9  push rsi
000076cd267d76fa  push r8
000076cd267d76fc  push r9
000076cd267d76fe  push r10
000076cd267d7700  push r11
000076cd267d7702  sub rsp, 0xF0
000076cd267d7709  vmovaps [rsp], xmm0
000076cd267d770e  vmovaps [rsp+0x10], xmm1
000076cd267d7714  vmovaps [rsp+0x20], xmm2
000076cd267d771a  vmovaps [rsp+0x30], xmm3
000076cd267d7720  vmovaps [rsp+0x40], xmm4
000076cd267d7726  vmovaps [rsp+0x50], xmm5
000076cd267d772c  vmovaps [rsp+0x60], xmm6
000076cd267d7732  vmovaps [rsp+0x70], xmm8
000076cd267d7738  vmovaps [rsp+0x80], xmm9
000076cd267d7741  vmovaps [rsp+0x90], xmm10
000076cd267d774a  vmovaps [rsp+0xA0], xmm11
000076cd267d7753  vmovaps [rsp+0xB0], xmm12
000076cd267d775c  vmovaps [rsp+0xC0], xmm13
000076cd267d7765  vmovaps [rsp+0xD0], xmm14
000076cd267d776e  vmovaps [rsp+0xE0], xmm15
000076cd267d7777  sub rsp, 0x30
000076cd267d777b  movaps [rsp], xmm7
000076cd267d777f  movaps [rsp+0x10], xmm4
000076cd267d7784  movaps [rsp+0x20], xmm9
000076cd267d778a  lea rdi, [rsp]
000076cd267d778e  mov esi, 0x00
000076cd267d7793  mov rax, 0x56B8861A9530
000076cd267d779d  call rax
000076cd267d779f  movaps xmm7, [rsp]
000076cd267d77a3  add rsp, 0x30
000076cd267d77a7  vmovaps xmm0, [rsp]
000076cd267d77ac  vmovaps xmm1, [rsp+0x10]
000076cd267d77b2  vmovaps xmm2, [rsp+0x20]
000076cd267d77b8  vmovaps xmm3, [rsp+0x30]
000076cd267d77be  vmovaps xmm4, [rsp+0x40]
000076cd267d77c4  vmovaps xmm5, [rsp+0x50]
000076cd267d77ca  vmovaps xmm6, [rsp+0x60]
000076cd267d77d0  vmovaps xmm8, [rsp+0x70]
000076cd267d77d6  vmovaps xmm9, [rsp+0x80]
000076cd267d77df  vmovaps xmm10, [rsp+0x90]
000076cd267d77e8  vmovaps xmm11, [rsp+0xA0]
000076cd267d77f1  vmovaps xmm12, [rsp+0xB0]
000076cd267d77fa  vmovaps xmm13, [rsp+0xC0]
000076cd267d7803  vmovaps xmm14, [rsp+0xD0]
000076cd267d780c  vmovaps xmm15, [rsp+0xE0]
000076cd267d7815  add rsp, 0xF0
000076cd267d781c  pop r11
000076cd267d781e  pop r10
000076cd267d7820  pop r9
000076cd267d7822  pop r8
000076cd267d7824  pop rsi
000076cd267d7825  pop rdi
000076cd267d7826  pop rdx
000076cd267d7827  pop rcx
000076cd267d7828  pop rax
000076cd267d7829  add rsp, 0x08
000076cd267d782d  jmp 0x000076CD267D5CD4
000076cd267d7832  sub rsp, 0x08
000076cd267d7836  push rax
000076cd267d7837  push rcx
000076cd267d7838  push rdx
000076cd267d7839  push rdi
000076cd267d783a  push rsi
000076cd267d783b  push r8
000076cd267d783d  push r9
000076cd267d783f  push r10
000076cd267d7841  push r11
000076cd267d7843  sub rsp, 0xF0
000076cd267d784a  vmovaps [rsp], xmm0
000076cd267d784f  vmovaps [rsp+0x10], xmm1
000076cd267d7855  vmovaps [rsp+0x20], xmm2
000076cd267d785b  vmovaps [rsp+0x30], xmm3
000076cd267d7861  vmovaps [rsp+0x40], xmm5
000076cd267d7867  vmovaps [rsp+0x50], xmm6
000076cd267d786d  vmovaps [rsp+0x60], xmm7
000076cd267d7873  vmovaps [rsp+0x70], xmm8
000076cd267d7879  vmovaps [rsp+0x80], xmm9
000076cd267d7882  vmovaps [rsp+0x90], xmm10
000076cd267d788b  vmovaps [rsp+0xA0], xmm11
000076cd267d7894  vmovaps [rsp+0xB0], xmm12
000076cd267d789d  vmovaps [rsp+0xC0], xmm13
000076cd267d78a6  vmovaps [rsp+0xD0], xmm14
000076cd267d78af  vmovaps [rsp+0xE0], xmm15
000076cd267d78b8  sub rsp, 0x30
000076cd267d78bc  movaps [rsp], xmm4
000076cd267d78c0  movaps [rsp+0x10], xmm15
000076cd267d78c6  movaps [rsp+0x20], xmm9
000076cd267d78cc  lea rdi, [rsp]
000076cd267d78d0  mov esi, 0x00
000076cd267d78d5  mov rax, 0x56B8861A9530
000076cd267d78df  call rax
000076cd267d78e1  movaps xmm4, [rsp]
000076cd267d78e5  add rsp, 0x30
000076cd267d78e9  vmovaps xmm0, [rsp]
000076cd267d78ee  vmovaps xmm1, [rsp+0x10]
000076cd267d78f4  vmovaps xmm2, [rsp+0x20]
000076cd267d78fa  vmovaps xmm3, [rsp+0x30]
000076cd267d7900  vmovaps xmm5, [rsp+0x40]
000076cd267d7906  vmovaps xmm6, [rsp+0x50]
000076cd267d790c  vmovaps xmm7, [rsp+0x60]
000076cd267d7912  vmovaps xmm8, [rsp+0x70]
000076cd267d7918  vmovaps xmm9, [rsp+0x80]
000076cd267d7921  vmovaps xmm10, [rsp+0x90]
000076cd267d792a  vmovaps xmm11, [rsp+0xA0]
000076cd267d7933  vmovaps xmm12, [rsp+0xB0]
000076cd267d793c  vmovaps xmm13, [rsp+0xC0]
000076cd267d7945  vmovaps xmm14, [rsp+0xD0]
000076cd267d794e  vmovaps xmm15, [rsp+0xE0]
000076cd267d7957  add rsp, 0xF0
000076cd267d795e  pop r11
000076cd267d7960  pop r10
000076cd267d7962  pop r9
000076cd267d7964  pop r8
000076cd267d7966  pop rsi
000076cd267d7967  pop rdi
000076cd267d7968  pop rdx
000076cd267d7969  pop rcx
000076cd267d796a  pop rax
000076cd267d796b  add rsp, 0x08
000076cd267d796f  jmp 0x000076CD267D5CF9
000076cd267d7974  call 0x000076CD266E5820
000076cd267d7979  jmp 0x000076CD267D5D06
000076cd267d797e  sub rsp, 0x08
000076cd267d7982  push rax
000076cd267d7983  push rcx
000076cd267d7984  push rdx
000076cd267d7985  push rdi
000076cd267d7986  push rsi
000076cd267d7987  push r8
000076cd267d7989  push r9
000076cd267d798b  push r10
000076cd267d798d  push r11
000076cd267d798f  sub rsp, 0xF0
000076cd267d7996  vmovaps [rsp], xmm0
000076cd267d799b  vmovaps [rsp+0x10], xmm1
000076cd267d79a1  vmovaps [rsp+0x20], xmm2
000076cd267d79a7  vmovaps [rsp+0x30], xmm4
000076cd267d79ad  vmovaps [rsp+0x40], xmm5
000076cd267d79b3  vmovaps [rsp+0x50], xmm6
000076cd267d79b9  vmovaps [rsp+0x60], xmm7
000076cd267d79bf  vmovaps [rsp+0x70], xmm8
000076cd267d79c5  vmovaps [rsp+0x80], xmm9
000076cd267d79ce  vmovaps [rsp+0x90], xmm10
000076cd267d79d7  vmovaps [rsp+0xA0], xmm11
000076cd267d79e0  vmovaps [rsp+0xB0], xmm12
000076cd267d79e9  vmovaps [rsp+0xC0], xmm13
000076cd267d79f2  vmovaps [rsp+0xD0], xmm14
000076cd267d79fb  vmovaps [rsp+0xE0], xmm15
000076cd267d7a04  sub rsp, 0x30
000076cd267d7a08  movaps [rsp], xmm3
000076cd267d7a0c  movaps [rsp+0x10], xmm1
000076cd267d7a11  movaps [rsp+0x20], xmm9
000076cd267d7a17  lea rdi, [rsp]
000076cd267d7a1b  mov esi, 0x00
000076cd267d7a20  mov rax, 0x56B8861A9530
000076cd267d7a2a  call rax
000076cd267d7a2c  movaps xmm3, [rsp]
000076cd267d7a30  add rsp, 0x30
000076cd267d7a34  vmovaps xmm0, [rsp]
000076cd267d7a39  vmovaps xmm1, [rsp+0x10]
000076cd267d7a3f  vmovaps xmm2, [rsp+0x20]
000076cd267d7a45  vmovaps xmm4, [rsp+0x30]
000076cd267d7a4b  vmovaps xmm5, [rsp+0x40]
000076cd267d7a51  vmovaps xmm6, [rsp+0x50]
000076cd267d7a57  vmovaps xmm7, [rsp+0x60]
000076cd267d7a5d  vmovaps xmm8, [rsp+0x70]
000076cd267d7a63  vmovaps xmm9, [rsp+0x80]
000076cd267d7a6c  vmovaps xmm10, [rsp+0x90]
000076cd267d7a75  vmovaps xmm11, [rsp+0xA0]
000076cd267d7a7e  vmovaps xmm12, [rsp+0xB0]
000076cd267d7a87  vmovaps xmm13, [rsp+0xC0]
000076cd267d7a90  vmovaps xmm14, [rsp+0xD0]
000076cd267d7a99  vmovaps xmm15, [rsp+0xE0]
000076cd267d7aa2  add rsp, 0xF0
000076cd267d7aa9  pop r11
000076cd267d7aab  pop r10
000076cd267d7aad  pop r9
000076cd267d7aaf  pop r8
000076cd267d7ab1  pop rsi
000076cd267d7ab2  pop rdi
000076cd267d7ab3  pop rdx
000076cd267d7ab4  pop rcx
000076cd267d7ab5  pop rax
000076cd267d7ab6  add rsp, 0x08
000076cd267d7aba  jmp 0x000076CD267D5D43
000076cd267d7abf  sub rsp, 0x08
000076cd267d7ac3  push rax
000076cd267d7ac4  push rcx
000076cd267d7ac5  push rdx
000076cd267d7ac6  push rdi
000076cd267d7ac7  push rsi
000076cd267d7ac8  push r8
000076cd267d7aca  push r9
000076cd267d7acc  push r10
000076cd267d7ace  push r11
000076cd267d7ad0  sub rsp, 0xF0
000076cd267d7ad7  vmovaps [rsp], xmm0
000076cd267d7adc  vmovaps [rsp+0x10], xmm2
000076cd267d7ae2  vmovaps [rsp+0x20], xmm3
000076cd267d7ae8  vmovaps [rsp+0x30], xmm4
000076cd267d7aee  vmovaps [rsp+0x40], xmm5
000076cd267d7af4  vmovaps [rsp+0x50], xmm6
000076cd267d7afa  vmovaps [rsp+0x60], xmm7
000076cd267d7b00  vmovaps [rsp+0x70], xmm8
000076cd267d7b06  vmovaps [rsp+0x80], xmm9
000076cd267d7b0f  vmovaps [rsp+0x90], xmm10
000076cd267d7b18  vmovaps [rsp+0xA0], xmm11
000076cd267d7b21  vmovaps [rsp+0xB0], xmm12
000076cd267d7b2a  vmovaps [rsp+0xC0], xmm13
000076cd267d7b33  vmovaps [rsp+0xD0], xmm14
000076cd267d7b3c  vmovaps [rsp+0xE0], xmm15
000076cd267d7b45  sub rsp, 0x30
000076cd267d7b49  movaps [rsp], xmm1
000076cd267d7b4d  movaps [rsp+0x10], xmm15
000076cd267d7b53  movaps [rsp+0x20], xmm9
000076cd267d7b59  lea rdi, [rsp]
000076cd267d7b5d  mov esi, 0x00
000076cd267d7b62  mov rax, 0x56B8861A9530
000076cd267d7b6c  call rax
000076cd267d7b6e  movaps xmm1, [rsp]
000076cd267d7b72  add rsp, 0x30
000076cd267d7b76  vmovaps xmm0, [rsp]
000076cd267d7b7b  vmovaps xmm2, [rsp+0x10]
000076cd267d7b81  vmovaps xmm3, [rsp+0x20]
000076cd267d7b87  vmovaps xmm4, [rsp+0x30]
000076cd267d7b8d  vmovaps xmm5, [rsp+0x40]
000076cd267d7b93  vmovaps xmm6, [rsp+0x50]
000076cd267d7b99  vmovaps xmm7, [rsp+0x60]
000076cd267d7b9f  vmovaps xmm8, [rsp+0x70]
000076cd267d7ba5  vmovaps xmm9, [rsp+0x80]
000076cd267d7bae  vmovaps xmm10, [rsp+0x90]
000076cd267d7bb7  vmovaps xmm11, [rsp+0xA0]
000076cd267d7bc0  vmovaps xmm12, [rsp+0xB0]
000076cd267d7bc9  vmovaps xmm13, [rsp+0xC0]
000076cd267d7bd2  vmovaps xmm14, [rsp+0xD0]
000076cd267d7bdb  vmovaps xmm15, [rsp+0xE0]
000076cd267d7be4  add rsp, 0xF0
000076cd267d7beb  pop r11
000076cd267d7bed  pop r10
000076cd267d7bef  pop r9
000076cd267d7bf1  pop r8
000076cd267d7bf3  pop rsi
000076cd267d7bf4  pop rdi
000076cd267d7bf5  pop rdx
000076cd267d7bf6  pop rcx
000076cd267d7bf7  pop rax
000076cd267d7bf8  add rsp, 0x08
000076cd267d7bfc  jmp 0x000076CD267D5DCB
000076cd267d7c01  call 0x000076CD266E5820
000076cd267d7c06  jmp 0x000076CD267D5DD8
000076cd267d7c0b  sub rsp, 0x08
000076cd267d7c0f  push rax
000076cd267d7c10  push rcx
000076cd267d7c11  push rdx
000076cd267d7c12  push rdi
000076cd267d7c13  push rsi
000076cd267d7c14  push r8
000076cd267d7c16  push r9
000076cd267d7c18  push r10
000076cd267d7c1a  push r11
000076cd267d7c1c  sub rsp, 0xF0
000076cd267d7c23  vmovaps [rsp], xmm0
000076cd267d7c28  vmovaps [rsp+0x10], xmm2
000076cd267d7c2e  vmovaps [rsp+0x20], xmm3
000076cd267d7c34  vmovaps [rsp+0x30], xmm4
000076cd267d7c3a  vmovaps [rsp+0x40], xmm5
000076cd267d7c40  vmovaps [rsp+0x50], xmm6
000076cd267d7c46  vmovaps [rsp+0x60], xmm7
000076cd267d7c4c  vmovaps [rsp+0x70], xmm8
000076cd267d7c52  vmovaps [rsp+0x80], xmm9
000076cd267d7c5b  vmovaps [rsp+0x90], xmm10
000076cd267d7c64  vmovaps [rsp+0xA0], xmm11
000076cd267d7c6d  vmovaps [rsp+0xB0], xmm12
000076cd267d7c76  vmovaps [rsp+0xC0], xmm13
000076cd267d7c7f  vmovaps [rsp+0xD0], xmm14
000076cd267d7c88  vmovaps [rsp+0xE0], xmm15
000076cd267d7c91  sub rsp, 0x30
000076cd267d7c95  movaps [rsp], xmm1
000076cd267d7c99  movaps [rsp+0x10], xmm5
000076cd267d7c9e  movaps [rsp+0x20], xmm7
000076cd267d7ca3  lea rdi, [rsp]
000076cd267d7ca7  mov esi, 0x00
000076cd267d7cac  mov rax, 0x56B8861A9530
000076cd267d7cb6  call rax
000076cd267d7cb8  movaps xmm1, [rsp]
000076cd267d7cbc  add rsp, 0x30
000076cd267d7cc0  vmovaps xmm0, [rsp]
000076cd267d7cc5  vmovaps xmm2, [rsp+0x10]
000076cd267d7ccb  vmovaps xmm3, [rsp+0x20]
000076cd267d7cd1  vmovaps xmm4, [rsp+0x30]
000076cd267d7cd7  vmovaps xmm5, [rsp+0x40]
000076cd267d7cdd  vmovaps xmm6, [rsp+0x50]
000076cd267d7ce3  vmovaps xmm7, [rsp+0x60]
000076cd267d7ce9  vmovaps xmm8, [rsp+0x70]
000076cd267d7cef  vmovaps xmm9, [rsp+0x80]
000076cd267d7cf8  vmovaps xmm10, [rsp+0x90]
000076cd267d7d01  vmovaps xmm11, [rsp+0xA0]
000076cd267d7d0a  vmovaps xmm12, [rsp+0xB0]
000076cd267d7d13  vmovaps xmm13, [rsp+0xC0]
000076cd267d7d1c  vmovaps xmm14, [rsp+0xD0]
000076cd267d7d25  vmovaps xmm15, [rsp+0xE0]
000076cd267d7d2e  add rsp, 0xF0
000076cd267d7d35  pop r11
000076cd267d7d37  pop r10
000076cd267d7d39  pop r9
000076cd267d7d3b  pop r8
000076cd267d7d3d  pop rsi
000076cd267d7d3e  pop rdi
000076cd267d7d3f  pop rdx
000076cd267d7d40  pop rcx
000076cd267d7d41  pop rax
000076cd267d7d42  add rsp, 0x08
000076cd267d7d46  jmp 0x000076CD267D5E7D
000076cd267d7d4b  sub rsp, 0x08
000076cd267d7d4f  push rax
000076cd267d7d50  push rcx
000076cd267d7d51  push rdx
000076cd267d7d52  push rdi
000076cd267d7d53  push rsi
000076cd267d7d54  push r8
000076cd267d7d56  push r9
000076cd267d7d58  push r10
000076cd267d7d5a  push r11
000076cd267d7d5c  sub rsp, 0xF0
000076cd267d7d63  vmovaps [rsp], xmm0
000076cd267d7d68  vmovaps [rsp+0x10], xmm1
000076cd267d7d6e  vmovaps [rsp+0x20], xmm2
000076cd267d7d74  vmovaps [rsp+0x30], xmm3
000076cd267d7d7a  vmovaps [rsp+0x40], xmm4
000076cd267d7d80  vmovaps [rsp+0x50], xmm5
000076cd267d7d86  vmovaps [rsp+0x60], xmm6
000076cd267d7d8c  vmovaps [rsp+0x70], xmm8
000076cd267d7d92  vmovaps [rsp+0x80], xmm9
000076cd267d7d9b  vmovaps [rsp+0x90], xmm10
000076cd267d7da4  vmovaps [rsp+0xA0], xmm11
000076cd267d7dad  vmovaps [rsp+0xB0], xmm12
000076cd267d7db6  vmovaps [rsp+0xC0], xmm13
000076cd267d7dbf  vmovaps [rsp+0xD0], xmm14
000076cd267d7dc8  vmovaps [rsp+0xE0], xmm15
000076cd267d7dd1  sub rsp, 0x30
000076cd267d7dd5  movaps [rsp], xmm7
000076cd267d7dd9  movaps [rsp+0x10], xmm5
000076cd267d7dde  movaps [rsp+0x20], xmm15
000076cd267d7de4  lea rdi, [rsp]
000076cd267d7de8  mov esi, 0x00
000076cd267d7ded  mov rax, 0x56B8861A9530
000076cd267d7df7  call rax
000076cd267d7df9  movaps xmm7, [rsp]
000076cd267d7dfd  add rsp, 0x30
000076cd267d7e01  vmovaps xmm0, [rsp]
000076cd267d7e06  vmovaps xmm1, [rsp+0x10]
000076cd267d7e0c  vmovaps xmm2, [rsp+0x20]
000076cd267d7e12  vmovaps xmm3, [rsp+0x30]
000076cd267d7e18  vmovaps xmm4, [rsp+0x40]
000076cd267d7e1e  vmovaps xmm5, [rsp+0x50]
000076cd267d7e24  vmovaps xmm6, [rsp+0x60]
000076cd267d7e2a  vmovaps xmm8, [rsp+0x70]
000076cd267d7e30  vmovaps xmm9, [rsp+0x80]
000076cd267d7e39  vmovaps xmm10, [rsp+0x90]
000076cd267d7e42  vmovaps xmm11, [rsp+0xA0]
000076cd267d7e4b  vmovaps xmm12, [rsp+0xB0]
000076cd267d7e54  vmovaps xmm13, [rsp+0xC0]
000076cd267d7e5d  vmovaps xmm14, [rsp+0xD0]
000076cd267d7e66  vmovaps xmm15, [rsp+0xE0]
000076cd267d7e6f  add rsp, 0xF0
000076cd267d7e76  pop r11
000076cd267d7e78  pop r10
000076cd267d7e7a  pop r9
000076cd267d7e7c  pop r8
000076cd267d7e7e  pop rsi
000076cd267d7e7f  pop rdi
000076cd267d7e80  pop rdx
000076cd267d7e81  pop rcx
000076cd267d7e82  pop rax
000076cd267d7e83  add rsp, 0x08
000076cd267d7e87  jmp 0x000076CD267D5EB3
000076cd267d7e8c  call 0x000076CD266D64F0
000076cd267d7e91  jmp 0x000076CD267D5EC0
000076cd267d7e96  sub rsp, 0x08
000076cd267d7e9a  push rax
000076cd267d7e9b  push rcx
000076cd267d7e9c  push rdx
000076cd267d7e9d  push rdi
000076cd267d7e9e  push rsi
000076cd267d7e9f  push r8
000076cd267d7ea1  push r9
000076cd267d7ea3  push r10
000076cd267d7ea5  push r11
000076cd267d7ea7  sub rsp, 0xF0
000076cd267d7eae  vmovaps [rsp], xmm0
000076cd267d7eb3  vmovaps [rsp+0x10], xmm1
000076cd267d7eb9  vmovaps [rsp+0x20], xmm2
000076cd267d7ebf  vmovaps [rsp+0x30], xmm3
000076cd267d7ec5  vmovaps [rsp+0x40], xmm4
000076cd267d7ecb  vmovaps [rsp+0x50], xmm5
000076cd267d7ed1  vmovaps [rsp+0x60], xmm6
000076cd267d7ed7  vmovaps [rsp+0x70], xmm7
000076cd267d7edd  vmovaps [rsp+0x80], xmm8
000076cd267d7ee6  vmovaps [rsp+0x90], xmm9
000076cd267d7eef  vmovaps [rsp+0xA0], xmm10
000076cd267d7ef8  vmovaps [rsp+0xB0], xmm11
000076cd267d7f01  vmovaps [rsp+0xC0], xmm12
000076cd267d7f0a  vmovaps [rsp+0xD0], xmm13
000076cd267d7f13  vmovaps [rsp+0xE0], xmm14
000076cd267d7f1c  sub rsp, 0x30
000076cd267d7f20  movaps [rsp], xmm15
000076cd267d7f25  movaps [rsp+0x10], xmm5
000076cd267d7f2a  movaps [rsp+0x20], xmm3
000076cd267d7f2f  lea rdi, [rsp]
000076cd267d7f33  mov esi, 0x00
000076cd267d7f38  mov rax, 0x56B8861A9530
000076cd267d7f42  call rax
000076cd267d7f44  movaps xmm15, [rsp]
000076cd267d7f49  add rsp, 0x30
000076cd267d7f4d  vmovaps xmm0, [rsp]
000076cd267d7f52  vmovaps xmm1, [rsp+0x10]
000076cd267d7f58  vmovaps xmm2, [rsp+0x20]
000076cd267d7f5e  vmovaps xmm3, [rsp+0x30]
000076cd267d7f64  vmovaps xmm4, [rsp+0x40]
000076cd267d7f6a  vmovaps xmm5, [rsp+0x50]
000076cd267d7f70  vmovaps xmm6, [rsp+0x60]
000076cd267d7f76  vmovaps xmm7, [rsp+0x70]
000076cd267d7f7c  vmovaps xmm8, [rsp+0x80]
000076cd267d7f85  vmovaps xmm9, [rsp+0x90]
000076cd267d7f8e  vmovaps xmm10, [rsp+0xA0]
000076cd267d7f97  vmovaps xmm11, [rsp+0xB0]
000076cd267d7fa0  vmovaps xmm12, [rsp+0xC0]
000076cd267d7fa9  vmovaps xmm13, [rsp+0xD0]
000076cd267d7fb2  vmovaps xmm14, [rsp+0xE0]
000076cd267d7fbb  add rsp, 0xF0
000076cd267d7fc2  pop r11
000076cd267d7fc4  pop r10
000076cd267d7fc6  pop r9
000076cd267d7fc8  pop r8
000076cd267d7fca  pop rsi
000076cd267d7fcb  pop rdi
000076cd267d7fcc  pop rdx
000076cd267d7fcd  pop rcx
000076cd267d7fce  pop rax
000076cd267d7fcf  add rsp, 0x08
000076cd267d7fd3  jmp 0x000076CD267D5EE6
000076cd267d7fd8  sub rsp, 0x08
000076cd267d7fdc  push rax
000076cd267d7fdd  push rcx
000076cd267d7fde  push rdx
000076cd267d7fdf  push rdi
000076cd267d7fe0  push rsi
000076cd267d7fe1  push r8
000076cd267d7fe3  push r9
000076cd267d7fe5  push r10
000076cd267d7fe7  push r11
000076cd267d7fe9  sub rsp, 0xF0
000076cd267d7ff0  vmovaps [rsp], xmm0
000076cd267d7ff5  vmovaps [rsp+0x10], xmm2
000076cd267d7ffb  vmovaps [rsp+0x20], xmm3
000076cd267d8001  vmovaps [rsp+0x30], xmm4
000076cd267d8007  vmovaps [rsp+0x40], xmm5
000076cd267d800d  vmovaps [rsp+0x50], xmm6
000076cd267d8013  vmovaps [rsp+0x60], xmm7
000076cd267d8019  vmovaps [rsp+0x70], xmm8
000076cd267d801f  vmovaps [rsp+0x80], xmm9
000076cd267d8028  vmovaps [rsp+0x90], xmm10
000076cd267d8031  vmovaps [rsp+0xA0], xmm11
000076cd267d803a  vmovaps [rsp+0xB0], xmm12
000076cd267d8043  vmovaps [rsp+0xC0], xmm13
000076cd267d804c  vmovaps [rsp+0xD0], xmm14
000076cd267d8055  vmovaps [rsp+0xE0], xmm15
000076cd267d805e  sub rsp, 0x30
000076cd267d8062  movaps [rsp], xmm1
000076cd267d8066  movaps [rsp+0x10], xmm5
000076cd267d806b  movaps [rsp+0x20], xmm4
000076cd267d8070  lea rdi, [rsp]
000076cd267d8074  mov esi, 0x00
000076cd267d8079  mov rax, 0x56B8861A9530
000076cd267d8083  call rax
000076cd267d8085  movaps xmm1, [rsp]
000076cd267d8089  add rsp, 0x30
000076cd267d808d  vmovaps xmm0, [rsp]
000076cd267d8092  vmovaps xmm2, [rsp+0x10]
000076cd267d8098  vmovaps xmm3, [rsp+0x20]
000076cd267d809e  vmovaps xmm4, [rsp+0x30]
000076cd267d80a4  vmovaps xmm5, [rsp+0x40]
000076cd267d80aa  vmovaps xmm6, [rsp+0x50]
000076cd267d80b0  vmovaps xmm7, [rsp+0x60]
000076cd267d80b6  vmovaps xmm8, [rsp+0x70]
000076cd267d80bc  vmovaps xmm9, [rsp+0x80]
000076cd267d80c5  vmovaps xmm10, [rsp+0x90]
000076cd267d80ce  vmovaps xmm11, [rsp+0xA0]
000076cd267d80d7  vmovaps xmm12, [rsp+0xB0]
000076cd267d80e0  vmovaps xmm13, [rsp+0xC0]
000076cd267d80e9  vmovaps xmm14, [rsp+0xD0]
000076cd267d80f2  vmovaps xmm15, [rsp+0xE0]
000076cd267d80fb  add rsp, 0xF0
000076cd267d8102  pop r11
000076cd267d8104  pop r10
000076cd267d8106  pop r9
000076cd267d8108  pop r8
000076cd267d810a  pop rsi
000076cd267d810b  pop rdi
000076cd267d810c  pop rdx
000076cd267d810d  pop rcx
000076cd267d810e  pop rax
000076cd267d810f  add rsp, 0x08
000076cd267d8113  jmp 0x000076CD267D5F06
000076cd267d8118  sub rsp, 0x08
000076cd267d811c  push rax
000076cd267d811d  push rcx
000076cd267d811e  push rdx
000076cd267d811f  push rdi
000076cd267d8120  push rsi
000076cd267d8121  push r8
000076cd267d8123  push r9
000076cd267d8125  push r10
000076cd267d8127  push r11
000076cd267d8129  sub rsp, 0xF0
000076cd267d8130  vmovaps [rsp], xmm0
000076cd267d8135  vmovaps [rsp+0x10], xmm1
000076cd267d813b  vmovaps [rsp+0x20], xmm2
000076cd267d8141  vmovaps [rsp+0x30], xmm3
000076cd267d8147  vmovaps [rsp+0x40], xmm5
000076cd267d814d  vmovaps [rsp+0x50], xmm6
000076cd267d8153  vmovaps [rsp+0x60], xmm7
000076cd267d8159  vmovaps [rsp+0x70], xmm8
000076cd267d815f  vmovaps [rsp+0x80], xmm9
000076cd267d8168  vmovaps [rsp+0x90], xmm10
000076cd267d8171  vmovaps [rsp+0xA0], xmm11
000076cd267d817a  vmovaps [rsp+0xB0], xmm12
000076cd267d8183  vmovaps [rsp+0xC0], xmm13
000076cd267d818c  vmovaps [rsp+0xD0], xmm14
000076cd267d8195  vmovaps [rsp+0xE0], xmm15
000076cd267d819e  sub rsp, 0x30
000076cd267d81a2  movaps [rsp], xmm4
000076cd267d81a6  movaps [rsp+0x10], xmm3
000076cd267d81ab  movaps [rsp+0x20], xmm5
000076cd267d81b0  lea rdi, [rsp]
000076cd267d81b4  mov esi, 0x00
000076cd267d81b9  mov rax, 0x56B8861A9530
000076cd267d81c3  call rax
000076cd267d81c5  movaps xmm4, [rsp]
000076cd267d81c9  add rsp, 0x30
000076cd267d81cd  vmovaps xmm0, [rsp]
000076cd267d81d2  vmovaps xmm1, [rsp+0x10]
000076cd267d81d8  vmovaps xmm2, [rsp+0x20]
000076cd267d81de  vmovaps xmm3, [rsp+0x30]
000076cd267d81e4  vmovaps xmm5, [rsp+0x40]
000076cd267d81ea  vmovaps xmm6, [rsp+0x50]
000076cd267d81f0  vmovaps xmm7, [rsp+0x60]
000076cd267d81f6  vmovaps xmm8, [rsp+0x70]
000076cd267d81fc  vmovaps xmm9, [rsp+0x80]
000076cd267d8205  vmovaps xmm10, [rsp+0x90]
000076cd267d820e  vmovaps xmm11, [rsp+0xA0]
000076cd267d8217  vmovaps xmm12, [rsp+0xB0]
000076cd267d8220  vmovaps xmm13, [rsp+0xC0]
000076cd267d8229  vmovaps xmm14, [rsp+0xD0]
000076cd267d8232  vmovaps xmm15, [rsp+0xE0]
000076cd267d823b  add rsp, 0xF0
000076cd267d8242  pop r11
000076cd267d8244  pop r10
000076cd267d8246  pop r9
000076cd267d8248  pop r8
000076cd267d824a  pop rsi
000076cd267d824b  pop rdi
000076cd267d824c  pop rdx
000076cd267d824d  pop rcx
000076cd267d824e  pop rax
000076cd267d824f  add rsp, 0x08
000076cd267d8253  jmp 0x000076CD267D5F54
000076cd267d8258  call 0x000076CD266D64F0
000076cd267d825d  jmp 0x000076CD267D5F61
000076cd267d8262  sub rsp, 0x08
000076cd267d8266  push rax
000076cd267d8267  push rcx
000076cd267d8268  push rdx
000076cd267d8269  push rdi
000076cd267d826a  push rsi
000076cd267d826b  push r8
000076cd267d826d  push r9
000076cd267d826f  push r10
000076cd267d8271  push r11
000076cd267d8273  sub rsp, 0xF0
000076cd267d827a  vmovaps [rsp], xmm0
000076cd267d827f  vmovaps [rsp+0x10], xmm1
000076cd267d8285  vmovaps [rsp+0x20], xmm2
000076cd267d828b  vmovaps [rsp+0x30], xmm3
000076cd267d8291  vmovaps [rsp+0x40], xmm4
000076cd267d8297  vmovaps [rsp+0x50], xmm6
000076cd267d829d  vmovaps [rsp+0x60], xmm7
000076cd267d82a3  vmovaps [rsp+0x70], xmm8
000076cd267d82a9  vmovaps [rsp+0x80], xmm9
000076cd267d82b2  vmovaps [rsp+0x90], xmm10
000076cd267d82bb  vmovaps [rsp+0xA0], xmm11
000076cd267d82c4  vmovaps [rsp+0xB0], xmm12
000076cd267d82cd  vmovaps [rsp+0xC0], xmm13
000076cd267d82d6  vmovaps [rsp+0xD0], xmm14
000076cd267d82df  vmovaps [rsp+0xE0], xmm15
000076cd267d82e8  sub rsp, 0x30
000076cd267d82ec  movaps [rsp], xmm5
000076cd267d82f0  movaps [rsp+0x10], xmm6
000076cd267d82f5  movaps [rsp+0x20], xmm3
000076cd267d82fa  lea rdi, [rsp]
000076cd267d82fe  mov esi, 0x00
000076cd267d8303  mov rax, 0x56B8861A9530
000076cd267d830d  call rax
000076cd267d830f  movaps xmm5, [rsp]
000076cd267d8313  add rsp, 0x30
000076cd267d8317  vmovaps xmm0, [rsp]
000076cd267d831c  vmovaps xmm1, [rsp+0x10]
000076cd267d8322  vmovaps xmm2, [rsp+0x20]
000076cd267d8328  vmovaps xmm3, [rsp+0x30]
000076cd267d832e  vmovaps xmm4, [rsp+0x40]
000076cd267d8334  vmovaps xmm6, [rsp+0x50]
000076cd267d833a  vmovaps xmm7, [rsp+0x60]
000076cd267d8340  vmovaps xmm8, [rsp+0x70]
000076cd267d8346  vmovaps xmm9, [rsp+0x80]
000076cd267d834f  vmovaps xmm10, [rsp+0x90]
000076cd267d8358  vmovaps xmm11, [rsp+0xA0]
000076cd267d8361  vmovaps xmm12, [rsp+0xB0]
000076cd267d836a  vmovaps xmm13, [rsp+0xC0]
000076cd267d8373  vmovaps xmm14, [rsp+0xD0]
000076cd267d837c  vmovaps xmm15, [rsp+0xE0]
000076cd267d8385  add rsp, 0xF0
000076cd267d838c  pop r11
000076cd267d838e  pop r10
000076cd267d8390  pop r9
000076cd267d8392  pop r8
000076cd267d8394  pop rsi
000076cd267d8395  pop rdi
000076cd267d8396  pop rdx
000076cd267d8397  pop rcx
000076cd267d8398  pop rax
000076cd267d8399  add rsp, 0x08
000076cd267d839d  jmp 0x000076CD267D5F87
000076cd267d83a2  sub rsp, 0x08
000076cd267d83a6  push rax
000076cd267d83a7  push rcx
000076cd267d83a8  push rdx
000076cd267d83a9  push rdi
000076cd267d83aa  push rsi
000076cd267d83ab  push r8
000076cd267d83ad  push r9
000076cd267d83af  push r10
000076cd267d83b1  push r11
000076cd267d83b3  sub rsp, 0xF0
000076cd267d83ba  vmovaps [rsp], xmm0
000076cd267d83bf  vmovaps [rsp+0x10], xmm1
000076cd267d83c5  vmovaps [rsp+0x20], xmm2
000076cd267d83cb  vmovaps [rsp+0x30], xmm3
000076cd267d83d1  vmovaps [rsp+0x40], xmm4
000076cd267d83d7  vmovaps [rsp+0x50], xmm5
000076cd267d83dd  vmovaps [rsp+0x60], xmm7
000076cd267d83e3  vmovaps [rsp+0x70], xmm8
000076cd267d83e9  vmovaps [rsp+0x80], xmm9
000076cd267d83f2  vmovaps [rsp+0x90], xmm10
000076cd267d83fb  vmovaps [rsp+0xA0], xmm11
000076cd267d8404  vmovaps [rsp+0xB0], xmm12
000076cd267d840d  vmovaps [rsp+0xC0], xmm13
000076cd267d8416  vmovaps [rsp+0xD0], xmm14
000076cd267d841f  vmovaps [rsp+0xE0], xmm15
000076cd267d8428  sub rsp, 0x30
000076cd267d842c  movaps [rsp], xmm6
000076cd267d8430  movaps [rsp+0x10], xmm9
000076cd267d8436  movaps [rsp+0x20], xmm1
000076cd267d843b  lea rdi, [rsp]
000076cd267d843f  mov esi, 0x00
000076cd267d8444  mov rax, 0x56B8861A9530
000076cd267d844e  call rax
000076cd267d8450  movaps xmm6, [rsp]
000076cd267d8454  add rsp, 0x30
000076cd267d8458  vmovaps xmm0, [rsp]
000076cd267d845d  vmovaps xmm1, [rsp+0x10]
000076cd267d8463  vmovaps xmm2, [rsp+0x20]
000076cd267d8469  vmovaps xmm3, [rsp+0x30]
000076cd267d846f  vmovaps xmm4, [rsp+0x40]
000076cd267d8475  vmovaps xmm5, [rsp+0x50]
000076cd267d847b  vmovaps xmm7, [rsp+0x60]
000076cd267d8481  vmovaps xmm8, [rsp+0x70]
000076cd267d8487  vmovaps xmm9, [rsp+0x80]
000076cd267d8490  vmovaps xmm10, [rsp+0x90]
000076cd267d8499  vmovaps xmm11, [rsp+0xA0]
000076cd267d84a2  vmovaps xmm12, [rsp+0xB0]
000076cd267d84ab  vmovaps xmm13, [rsp+0xC0]
000076cd267d84b4  vmovaps xmm14, [rsp+0xD0]
000076cd267d84bd  vmovaps xmm15, [rsp+0xE0]
000076cd267d84c6  add rsp, 0xF0
000076cd267d84cd  pop r11
000076cd267d84cf  pop r10
000076cd267d84d1  pop r9
000076cd267d84d3  pop r8
000076cd267d84d5  pop rsi
000076cd267d84d6  pop rdi
000076cd267d84d7  pop rdx
000076cd267d84d8  pop rcx
000076cd267d84d9  pop rax
000076cd267d84da  add rsp, 0x08
000076cd267d84de  jmp 0x000076CD267D5FAB
000076cd267d84e3  sub rsp, 0x08
000076cd267d84e7  push rax
000076cd267d84e8  push rcx
000076cd267d84e9  push rdx
000076cd267d84ea  push rdi
000076cd267d84eb  push rsi
000076cd267d84ec  push r8
000076cd267d84ee  push r9
000076cd267d84f0  push r10
000076cd267d84f2  push r11
000076cd267d84f4  sub rsp, 0xF0
000076cd267d84fb  vmovaps [rsp], xmm0
000076cd267d8500  vmovaps [rsp+0x10], xmm1
000076cd267d8506  vmovaps [rsp+0x20], xmm2
000076cd267d850c  vmovaps [rsp+0x30], xmm3
000076cd267d8512  vmovaps [rsp+0x40], xmm4
000076cd267d8518  vmovaps [rsp+0x50], xmm5
000076cd267d851e  vmovaps [rsp+0x60], xmm6
000076cd267d8524  vmovaps [rsp+0x70], xmm7
000076cd267d852a  vmovaps [rsp+0x80], xmm8
000076cd267d8533  vmovaps [rsp+0x90], xmm10
000076cd267d853c  vmovaps [rsp+0xA0], xmm11
000076cd267d8545  vmovaps [rsp+0xB0], xmm12
000076cd267d854e  vmovaps [rsp+0xC0], xmm13
000076cd267d8557  vmovaps [rsp+0xD0], xmm14
000076cd267d8560  vmovaps [rsp+0xE0], xmm15
000076cd267d8569  sub rsp, 0x30
000076cd267d856d  movaps [rsp], xmm9
000076cd267d8572  movaps [rsp+0x10], xmm3
000076cd267d8577  movaps [rsp+0x20], xmm1
000076cd267d857c  lea rdi, [rsp]
000076cd267d8580  mov esi, 0x00
000076cd267d8585  mov rax, 0x56B8861A9530
000076cd267d858f  call rax
000076cd267d8591  movaps xmm9, [rsp]
000076cd267d8596  add rsp, 0x30
000076cd267d859a  vmovaps xmm0, [rsp]
000076cd267d859f  vmovaps xmm1, [rsp+0x10]
000076cd267d85a5  vmovaps xmm2, [rsp+0x20]
000076cd267d85ab  vmovaps xmm3, [rsp+0x30]
000076cd267d85b1  vmovaps xmm4, [rsp+0x40]
000076cd267d85b7  vmovaps xmm5, [rsp+0x50]
000076cd267d85bd  vmovaps xmm6, [rsp+0x60]
000076cd267d85c3  vmovaps xmm7, [rsp+0x70]
000076cd267d85c9  vmovaps xmm8, [rsp+0x80]
000076cd267d85d2  vmovaps xmm10, [rsp+0x90]
000076cd267d85db  vmovaps xmm11, [rsp+0xA0]
000076cd267d85e4  vmovaps xmm12, [rsp+0xB0]
000076cd267d85ed  vmovaps xmm13, [rsp+0xC0]
000076cd267d85f6  vmovaps xmm14, [rsp+0xD0]
000076cd267d85ff  vmovaps xmm15, [rsp+0xE0]
000076cd267d8608  add rsp, 0xF0
000076cd267d860f  pop r11
000076cd267d8611  pop r10
000076cd267d8613  pop r9
000076cd267d8615  pop r8
000076cd267d8617  pop rsi
000076cd267d8618  pop rdi
000076cd267d8619  pop rdx
000076cd267d861a  pop rcx
000076cd267d861b  pop rax
000076cd267d861c  add rsp, 0x08
000076cd267d8620  jmp 0x000076CD267D5FF7
000076cd267d8625  call 0x000076CD266D64F0
000076cd267d862a  jmp 0x000076CD267D6004
000076cd267d862f  sub rsp, 0x08
000076cd267d8633  push rax
000076cd267d8634  push rcx
000076cd267d8635  push rdx
000076cd267d8636  push rdi
000076cd267d8637  push rsi
000076cd267d8638  push r8
000076cd267d863a  push r9
000076cd267d863c  push r10
000076cd267d863e  push r11
000076cd267d8640  sub rsp, 0xF0
000076cd267d8647  vmovaps [rsp], xmm0
000076cd267d864c  vmovaps [rsp+0x10], xmm1
000076cd267d8652  vmovaps [rsp+0x20], xmm2
000076cd267d8658  vmovaps [rsp+0x30], xmm3
000076cd267d865e  vmovaps [rsp+0x40], xmm4
000076cd267d8664  vmovaps [rsp+0x50], xmm5
000076cd267d866a  vmovaps [rsp+0x60], xmm6
000076cd267d8670  vmovaps [rsp+0x70], xmm7
000076cd267d8676  vmovaps [rsp+0x80], xmm8
000076cd267d867f  vmovaps [rsp+0x90], xmm9
000076cd267d8688  vmovaps [rsp+0xA0], xmm10
000076cd267d8691  vmovaps [rsp+0xB0], xmm11
000076cd267d869a  vmovaps [rsp+0xC0], xmm12
000076cd267d86a3  vmovaps [rsp+0xD0], xmm13
000076cd267d86ac  vmovaps [rsp+0xE0], xmm14
000076cd267d86b5  sub rsp, 0x30
000076cd267d86b9  movaps [rsp], xmm15
000076cd267d86be  movaps [rsp+0x10], xmm3
000076cd267d86c3  movaps [rsp+0x20], xmm7
000076cd267d86c8  lea rdi, [rsp]
000076cd267d86cc  mov esi, 0x00
000076cd267d86d1  mov rax, 0x56B8861A9530
000076cd267d86db  call rax
000076cd267d86dd  movaps xmm15, [rsp]
000076cd267d86e2  add rsp, 0x30
000076cd267d86e6  vmovaps xmm0, [rsp]
000076cd267d86eb  vmovaps xmm1, [rsp+0x10]
000076cd267d86f1  vmovaps xmm2, [rsp+0x20]
000076cd267d86f7  vmovaps xmm3, [rsp+0x30]
000076cd267d86fd  vmovaps xmm4, [rsp+0x40]
000076cd267d8703  vmovaps xmm5, [rsp+0x50]
000076cd267d8709  vmovaps xmm6, [rsp+0x60]
000076cd267d870f  vmovaps xmm7, [rsp+0x70]
000076cd267d8715  vmovaps xmm8, [rsp+0x80]
000076cd267d871e  vmovaps xmm9, [rsp+0x90]
000076cd267d8727  vmovaps xmm10, [rsp+0xA0]
000076cd267d8730  vmovaps xmm11, [rsp+0xB0]
000076cd267d8739  vmovaps xmm12, [rsp+0xC0]
000076cd267d8742  vmovaps xmm13, [rsp+0xD0]
000076cd267d874b  vmovaps xmm14, [rsp+0xE0]
000076cd267d8754  add rsp, 0xF0
000076cd267d875b  pop r11
000076cd267d875d  pop r10
000076cd267d875f  pop r9
000076cd267d8761  pop r8
000076cd267d8763  pop rsi
000076cd267d8764  pop rdi
000076cd267d8765  pop rdx
000076cd267d8766  pop rcx
000076cd267d8767  pop rax
000076cd267d8768  add rsp, 0x08
000076cd267d876c  jmp 0x000076CD267D6030
000076cd267d8771  sub rsp, 0x08
000076cd267d8775  push rax
000076cd267d8776  push rcx
000076cd267d8777  push rdx
000076cd267d8778  push rdi
000076cd267d8779  push rsi
000076cd267d877a  push r8
000076cd267d877c  push r9
000076cd267d877e  push r10
000076cd267d8780  push r11
000076cd267d8782  sub rsp, 0xF0
000076cd267d8789  vmovaps [rsp], xmm0
000076cd267d878e  vmovaps [rsp+0x10], xmm1
000076cd267d8794  vmovaps [rsp+0x20], xmm2
000076cd267d879a  vmovaps [rsp+0x30], xmm4
000076cd267d87a0  vmovaps [rsp+0x40], xmm5
000076cd267d87a6  vmovaps [rsp+0x50], xmm6
000076cd267d87ac  vmovaps [rsp+0x60], xmm7
000076cd267d87b2  vmovaps [rsp+0x70], xmm8
000076cd267d87b8  vmovaps [rsp+0x80], xmm9
000076cd267d87c1  vmovaps [rsp+0x90], xmm10
000076cd267d87ca  vmovaps [rsp+0xA0], xmm11
000076cd267d87d3  vmovaps [rsp+0xB0], xmm12
000076cd267d87dc  vmovaps [rsp+0xC0], xmm13
000076cd267d87e5  vmovaps [rsp+0xD0], xmm14
000076cd267d87ee  vmovaps [rsp+0xE0], xmm15
000076cd267d87f7  sub rsp, 0x30
000076cd267d87fb  movaps [rsp], xmm3
000076cd267d87ff  movaps [rsp+0x10], xmm1
000076cd267d8804  movaps [rsp+0x20], xmm15
000076cd267d880a  lea rdi, [rsp]
000076cd267d880e  mov esi, 0x00
000076cd267d8813  mov rax, 0x56B8861A9530
000076cd267d881d  call rax
000076cd267d881f  movaps xmm3, [rsp]
000076cd267d8823  add rsp, 0x30
000076cd267d8827  vmovaps xmm0, [rsp]
000076cd267d882c  vmovaps xmm1, [rsp+0x10]
000076cd267d8832  vmovaps xmm2, [rsp+0x20]
000076cd267d8838  vmovaps xmm4, [rsp+0x30]
000076cd267d883e  vmovaps xmm5, [rsp+0x40]
000076cd267d8844  vmovaps xmm6, [rsp+0x50]
000076cd267d884a  vmovaps xmm7, [rsp+0x60]
000076cd267d8850  vmovaps xmm8, [rsp+0x70]
000076cd267d8856  vmovaps xmm9, [rsp+0x80]
000076cd267d885f  vmovaps xmm10, [rsp+0x90]
000076cd267d8868  vmovaps xmm11, [rsp+0xA0]
000076cd267d8871  vmovaps xmm12, [rsp+0xB0]
000076cd267d887a  vmovaps xmm13, [rsp+0xC0]
000076cd267d8883  vmovaps xmm14, [rsp+0xD0]
000076cd267d888c  vmovaps xmm15, [rsp+0xE0]
000076cd267d8895  add rsp, 0xF0
000076cd267d889c  pop r11
000076cd267d889e  pop r10
000076cd267d88a0  pop r9
000076cd267d88a2  pop r8
000076cd267d88a4  pop rsi
000076cd267d88a5  pop rdi
000076cd267d88a6  pop rdx
000076cd267d88a7  pop rcx
000076cd267d88a8  pop rax
000076cd267d88a9  add rsp, 0x08
000076cd267d88ad  jmp 0x000076CD267D60BF
000076cd267d88b2  call 0x000076CD266D64F0
000076cd267d88b7  jmp 0x000076CD267D60C9
000076cd267d88bc  sub rsp, 0x08
000076cd267d88c0  push rax
000076cd267d88c1  push rcx
000076cd267d88c2  push rdx
000076cd267d88c3  push rdi
000076cd267d88c4  push rsi
000076cd267d88c5  push r8
000076cd267d88c7  push r9
000076cd267d88c9  push r10
000076cd267d88cb  push r11
000076cd267d88cd  sub rsp, 0xF0
000076cd267d88d4  vmovaps [rsp], xmm0
000076cd267d88d9  vmovaps [rsp+0x10], xmm1
000076cd267d88df  vmovaps [rsp+0x20], xmm2
000076cd267d88e5  vmovaps [rsp+0x30], xmm3
000076cd267d88eb  vmovaps [rsp+0x40], xmm4
000076cd267d88f1  vmovaps [rsp+0x50], xmm5
000076cd267d88f7  vmovaps [rsp+0x60], xmm6
000076cd267d88fd  vmovaps [rsp+0x70], xmm7
000076cd267d8903  vmovaps [rsp+0x80], xmm8
000076cd267d890c  vmovaps [rsp+0x90], xmm9
000076cd267d8915  vmovaps [rsp+0xA0], xmm10
000076cd267d891e  vmovaps [rsp+0xB0], xmm11
000076cd267d8927  vmovaps [rsp+0xC0], xmm12
000076cd267d8930  vmovaps [rsp+0xD0], xmm13
000076cd267d8939  vmovaps [rsp+0xE0], xmm14
000076cd267d8942  sub rsp, 0x30
000076cd267d8946  movaps [rsp], xmm15
000076cd267d894b  movaps [rsp+0x10], xmm14
000076cd267d8951  movaps [rsp+0x20], xmm4
000076cd267d8956  lea rdi, [rsp]
000076cd267d895a  mov esi, 0x00
000076cd267d895f  mov rax, 0x56B8861A9530
000076cd267d8969  call rax
000076cd267d896b  movaps xmm15, [rsp]
000076cd267d8970  add rsp, 0x30
000076cd267d8974  vmovaps xmm0, [rsp]
000076cd267d8979  vmovaps xmm1, [rsp+0x10]
000076cd267d897f  vmovaps xmm2, [rsp+0x20]
000076cd267d8985  vmovaps xmm3, [rsp+0x30]
000076cd267d898b  vmovaps xmm4, [rsp+0x40]
000076cd267d8991  vmovaps xmm5, [rsp+0x50]
000076cd267d8997  vmovaps xmm6, [rsp+0x60]
000076cd267d899d  vmovaps xmm7, [rsp+0x70]
000076cd267d89a3  vmovaps xmm8, [rsp+0x80]
000076cd267d89ac  vmovaps xmm9, [rsp+0x90]
000076cd267d89b5  vmovaps xmm10, [rsp+0xA0]
000076cd267d89be  vmovaps xmm11, [rsp+0xB0]
000076cd267d89c7  vmovaps xmm12, [rsp+0xC0]
000076cd267d89d0  vmovaps xmm13, [rsp+0xD0]
000076cd267d89d9  vmovaps xmm14, [rsp+0xE0]
000076cd267d89e2  add rsp, 0xF0
000076cd267d89e9  pop r11
000076cd267d89eb  pop r10
000076cd267d89ed  pop r9
000076cd267d89ef  pop r8
000076cd267d89f1  pop rsi
000076cd267d89f2  pop rdi
000076cd267d89f3  pop rdx
000076cd267d89f4  pop rcx
000076cd267d89f5  pop rax
000076cd267d89f6  add rsp, 0x08
000076cd267d89fa  jmp 0x000076CD267D60F7
000076cd267d89ff  sub rsp, 0x08
000076cd267d8a03  push rax
000076cd267d8a04  push rcx
000076cd267d8a05  push rdx
000076cd267d8a06  push rdi
000076cd267d8a07  push rsi
000076cd267d8a08  push r8
000076cd267d8a0a  push r9
000076cd267d8a0c  push r10
000076cd267d8a0e  push r11
000076cd267d8a10  sub rsp, 0xF0
000076cd267d8a17  vmovaps [rsp], xmm0
000076cd267d8a1c  vmovaps [rsp+0x10], xmm1
000076cd267d8a22  vmovaps [rsp+0x20], xmm2
000076cd267d8a28  vmovaps [rsp+0x30], xmm3
000076cd267d8a2e  vmovaps [rsp+0x40], xmm4
000076cd267d8a34  vmovaps [rsp+0x50], xmm5
000076cd267d8a3a  vmovaps [rsp+0x60], xmm6
000076cd267d8a40  vmovaps [rsp+0x70], xmm7
000076cd267d8a46  vmovaps [rsp+0x80], xmm8
000076cd267d8a4f  vmovaps [rsp+0x90], xmm9
000076cd267d8a58  vmovaps [rsp+0xA0], xmm10
000076cd267d8a61  vmovaps [rsp+0xB0], xmm11
000076cd267d8a6a  vmovaps [rsp+0xC0], xmm12
000076cd267d8a73  vmovaps [rsp+0xD0], xmm13
000076cd267d8a7c  vmovaps [rsp+0xE0], xmm15
000076cd267d8a85  sub rsp, 0x30
000076cd267d8a89  movaps [rsp], xmm14
000076cd267d8a8e  movaps [rsp+0x10], xmm2
000076cd267d8a93  movaps [rsp+0x20], xmm1
000076cd267d8a98  lea rdi, [rsp]
000076cd267d8a9c  mov esi, 0x00
000076cd267d8aa1  mov rax, 0x56B8861A9530
000076cd267d8aab  call rax
000076cd267d8aad  movaps xmm14, [rsp]
000076cd267d8ab2  add rsp, 0x30
000076cd267d8ab6  vmovaps xmm0, [rsp]
000076cd267d8abb  vmovaps xmm1, [rsp+0x10]
000076cd267d8ac1  vmovaps xmm2, [rsp+0x20]
000076cd267d8ac7  vmovaps xmm3, [rsp+0x30]
000076cd267d8acd  vmovaps xmm4, [rsp+0x40]
000076cd267d8ad3  vmovaps xmm5, [rsp+0x50]
000076cd267d8ad9  vmovaps xmm6, [rsp+0x60]
000076cd267d8adf  vmovaps xmm7, [rsp+0x70]
000076cd267d8ae5  vmovaps xmm8, [rsp+0x80]
000076cd267d8aee  vmovaps xmm9, [rsp+0x90]
000076cd267d8af7  vmovaps xmm10, [rsp+0xA0]
000076cd267d8b00  vmovaps xmm11, [rsp+0xB0]
000076cd267d8b09  vmovaps xmm12, [rsp+0xC0]
000076cd267d8b12  vmovaps xmm13, [rsp+0xD0]
000076cd267d8b1b  vmovaps xmm15, [rsp+0xE0]
000076cd267d8b24  add rsp, 0xF0
000076cd267d8b2b  pop r11
000076cd267d8b2d  pop r10
000076cd267d8b2f  pop r9
000076cd267d8b31  pop r8
000076cd267d8b33  pop rsi
000076cd267d8b34  pop rdi
000076cd267d8b35  pop rdx
000076cd267d8b36  pop rcx
000076cd267d8b37  pop rax
000076cd267d8b38  add rsp, 0x08
000076cd267d8b3c  jmp 0x000076CD267D611D
000076cd267d8b41  sub rsp, 0x08
000076cd267d8b45  push rax
000076cd267d8b46  push rcx
000076cd267d8b47  push rdx
000076cd267d8b48  push rdi
000076cd267d8b49  push rsi
000076cd267d8b4a  push r8
000076cd267d8b4c  push r9
000076cd267d8b4e  push r10
000076cd267d8b50  push r11
000076cd267d8b52  sub rsp, 0xF0
000076cd267d8b59  vmovaps [rsp], xmm0
000076cd267d8b5e  vmovaps [rsp+0x10], xmm2
000076cd267d8b64  vmovaps [rsp+0x20], xmm3
000076cd267d8b6a  vmovaps [rsp+0x30], xmm4
000076cd267d8b70  vmovaps [rsp+0x40], xmm5
000076cd267d8b76  vmovaps [rsp+0x50], xmm6
000076cd267d8b7c  vmovaps [rsp+0x60], xmm7
000076cd267d8b82  vmovaps [rsp+0x70], xmm8
000076cd267d8b88  vmovaps [rsp+0x80], xmm9
000076cd267d8b91  vmovaps [rsp+0x90], xmm10
000076cd267d8b9a  vmovaps [rsp+0xA0], xmm11
000076cd267d8ba3  vmovaps [rsp+0xB0], xmm12
000076cd267d8bac  vmovaps [rsp+0xC0], xmm13
000076cd267d8bb5  vmovaps [rsp+0xD0], xmm14
000076cd267d8bbe  vmovaps [rsp+0xE0], xmm15
000076cd267d8bc7  sub rsp, 0x30
000076cd267d8bcb  movaps [rsp], xmm1
000076cd267d8bcf  movaps [rsp+0x10], xmm4
000076cd267d8bd4  movaps [rsp+0x20], xmm9
000076cd267d8bda  lea rdi, [rsp]
000076cd267d8bde  mov esi, 0x00
000076cd267d8be3  mov rax, 0x56B8861A9530
000076cd267d8bed  call rax
000076cd267d8bef  movaps xmm1, [rsp]
000076cd267d8bf3  add rsp, 0x30
000076cd267d8bf7  vmovaps xmm0, [rsp]
000076cd267d8bfc  vmovaps xmm2, [rsp+0x10]
000076cd267d8c02  vmovaps xmm3, [rsp+0x20]
000076cd267d8c08  vmovaps xmm4, [rsp+0x30]
000076cd267d8c0e  vmovaps xmm5, [rsp+0x40]
000076cd267d8c14  vmovaps xmm6, [rsp+0x50]
000076cd267d8c1a  vmovaps xmm7, [rsp+0x60]
000076cd267d8c20  vmovaps xmm8, [rsp+0x70]
000076cd267d8c26  vmovaps xmm9, [rsp+0x80]
000076cd267d8c2f  vmovaps xmm10, [rsp+0x90]
000076cd267d8c38  vmovaps xmm11, [rsp+0xA0]
000076cd267d8c41  vmovaps xmm12, [rsp+0xB0]
000076cd267d8c4a  vmovaps xmm13, [rsp+0xC0]
000076cd267d8c53  vmovaps xmm14, [rsp+0xD0]
000076cd267d8c5c  vmovaps xmm15, [rsp+0xE0]
000076cd267d8c65  add rsp, 0xF0
000076cd267d8c6c  pop r11
000076cd267d8c6e  pop r10
000076cd267d8c70  pop r9
000076cd267d8c72  pop r8
000076cd267d8c74  pop rsi
000076cd267d8c75  pop rdi
000076cd267d8c76  pop rdx
000076cd267d8c77  pop rcx
000076cd267d8c78  pop rax
000076cd267d8c79  add rsp, 0x08
000076cd267d8c7d  jmp 0x000076CD267D613B
000076cd267d8c82  sub rsp, 0x08
000076cd267d8c86  push rax
000076cd267d8c87  push rcx
000076cd267d8c88  push rdx
000076cd267d8c89  push rdi
000076cd267d8c8a  push rsi
000076cd267d8c8b  push r8
000076cd267d8c8d  push r9
000076cd267d8c8f  push r10
000076cd267d8c91  push r11
000076cd267d8c93  sub rsp, 0xF0
000076cd267d8c9a  vmovaps [rsp], xmm0
000076cd267d8c9f  vmovaps [rsp+0x10], xmm1
000076cd267d8ca5  vmovaps [rsp+0x20], xmm2
000076cd267d8cab  vmovaps [rsp+0x30], xmm3
000076cd267d8cb1  vmovaps [rsp+0x40], xmm5
000076cd267d8cb7  vmovaps [rsp+0x50], xmm6
000076cd267d8cbd  vmovaps [rsp+0x60], xmm7
000076cd267d8cc3  vmovaps [rsp+0x70], xmm8
000076cd267d8cc9  vmovaps [rsp+0x80], xmm9
000076cd267d8cd2  vmovaps [rsp+0x90], xmm10
000076cd267d8cdb  vmovaps [rsp+0xA0], xmm11
000076cd267d8ce4  vmovaps [rsp+0xB0], xmm12
000076cd267d8ced  vmovaps [rsp+0xC0], xmm13
000076cd267d8cf6  vmovaps [rsp+0xD0], xmm14
000076cd267d8cff  vmovaps [rsp+0xE0], xmm15
000076cd267d8d08  sub rsp, 0x30
000076cd267d8d0c  movaps [rsp], xmm4
000076cd267d8d10  movaps [rsp+0x10], xmm2
000076cd267d8d15  movaps [rsp+0x20], xmm9
000076cd267d8d1b  lea rdi, [rsp]
000076cd267d8d1f  mov esi, 0x00
000076cd267d8d24  mov rax, 0x56B8861A9530
000076cd267d8d2e  call rax
000076cd267d8d30  movaps xmm4, [rsp]
000076cd267d8d34  add rsp, 0x30
000076cd267d8d38  vmovaps xmm0, [rsp]
000076cd267d8d3d  vmovaps xmm1, [rsp+0x10]
000076cd267d8d43  vmovaps xmm2, [rsp+0x20]
000076cd267d8d49  vmovaps xmm3, [rsp+0x30]
000076cd267d8d4f  vmovaps xmm5, [rsp+0x40]
000076cd267d8d55  vmovaps xmm6, [rsp+0x50]
000076cd267d8d5b  vmovaps xmm7, [rsp+0x60]
000076cd267d8d61  vmovaps xmm8, [rsp+0x70]
000076cd267d8d67  vmovaps xmm9, [rsp+0x80]
000076cd267d8d70  vmovaps xmm10, [rsp+0x90]
000076cd267d8d79  vmovaps xmm11, [rsp+0xA0]
000076cd267d8d82  vmovaps xmm12, [rsp+0xB0]
000076cd267d8d8b  vmovaps xmm13, [rsp+0xC0]
000076cd267d8d94  vmovaps xmm14, [rsp+0xD0]
000076cd267d8d9d  vmovaps xmm15, [rsp+0xE0]
000076cd267d8da6  add rsp, 0xF0
000076cd267d8dad  pop r11
000076cd267d8daf  pop r10
000076cd267d8db1  pop r9
000076cd267d8db3  pop r8
000076cd267d8db5  pop rsi
000076cd267d8db6  pop rdi
000076cd267d8db7  pop rdx
000076cd267d8db8  pop rcx
000076cd267d8db9  pop rax
000076cd267d8dba  add rsp, 0x08
000076cd267d8dbe  jmp 0x000076CD267D616B
000076cd267d8dc3  sub rsp, 0x08
000076cd267d8dc7  push rax
000076cd267d8dc8  push rcx
000076cd267d8dc9  push rdx
000076cd267d8dca  push rdi
000076cd267d8dcb  push rsi
000076cd267d8dcc  push r8
000076cd267d8dce  push r9
000076cd267d8dd0  push r10
000076cd267d8dd2  push r11
000076cd267d8dd4  sub rsp, 0xF0
000076cd267d8ddb  vmovaps [rsp], xmm0
000076cd267d8de0  vmovaps [rsp+0x10], xmm1
000076cd267d8de6  vmovaps [rsp+0x20], xmm2
000076cd267d8dec  vmovaps [rsp+0x30], xmm3
000076cd267d8df2  vmovaps [rsp+0x40], xmm4
000076cd267d8df8  vmovaps [rsp+0x50], xmm5
000076cd267d8dfe  vmovaps [rsp+0x60], xmm6
000076cd267d8e04  vmovaps [rsp+0x70], xmm7
000076cd267d8e0a  vmovaps [rsp+0x80], xmm8
000076cd267d8e13  vmovaps [rsp+0x90], xmm10
000076cd267d8e1c  vmovaps [rsp+0xA0], xmm11
000076cd267d8e25  vmovaps [rsp+0xB0], xmm12
000076cd267d8e2e  vmovaps [rsp+0xC0], xmm13
000076cd267d8e37  vmovaps [rsp+0xD0], xmm14
000076cd267d8e40  vmovaps [rsp+0xE0], xmm15
000076cd267d8e49  sub rsp, 0x30
000076cd267d8e4d  movaps [rsp], xmm9
000076cd267d8e52  movaps [rsp+0x10], xmm2
000076cd267d8e57  movaps [rsp+0x20], xmm1
000076cd267d8e5c  lea rdi, [rsp]
000076cd267d8e60  mov esi, 0x00
000076cd267d8e65  mov rax, 0x56B8861A9530
000076cd267d8e6f  call rax
000076cd267d8e71  movaps xmm9, [rsp]
000076cd267d8e76  add rsp, 0x30
000076cd267d8e7a  vmovaps xmm0, [rsp]
000076cd267d8e7f  vmovaps xmm1, [rsp+0x10]
000076cd267d8e85  vmovaps xmm2, [rsp+0x20]
000076cd267d8e8b  vmovaps xmm3, [rsp+0x30]
000076cd267d8e91  vmovaps xmm4, [rsp+0x40]
000076cd267d8e97  vmovaps xmm5, [rsp+0x50]
000076cd267d8e9d  vmovaps xmm6, [rsp+0x60]
000076cd267d8ea3  vmovaps xmm7, [rsp+0x70]
000076cd267d8ea9  vmovaps xmm8, [rsp+0x80]
000076cd267d8eb2  vmovaps xmm10, [rsp+0x90]
000076cd267d8ebb  vmovaps xmm11, [rsp+0xA0]
000076cd267d8ec4  vmovaps xmm12, [rsp+0xB0]
000076cd267d8ecd  vmovaps xmm13, [rsp+0xC0]
000076cd267d8ed6  vmovaps xmm14, [rsp+0xD0]
000076cd267d8edf  vmovaps xmm15, [rsp+0xE0]
000076cd267d8ee8  add rsp, 0xF0
000076cd267d8eef  pop r11
000076cd267d8ef1  pop r10
000076cd267d8ef3  pop r9
000076cd267d8ef5  pop r8
000076cd267d8ef7  pop rsi
000076cd267d8ef8  pop rdi
000076cd267d8ef9  pop rdx
000076cd267d8efa  pop rcx
000076cd267d8efb  pop rax
000076cd267d8efc  add rsp, 0x08
000076cd267d8f00  jmp 0x000076CD267D61A1
000076cd267d8f05  sub rsp, 0x08
000076cd267d8f09  push rax
000076cd267d8f0a  push rcx
000076cd267d8f0b  push rdx
000076cd267d8f0c  push rdi
000076cd267d8f0d  push rsi
000076cd267d8f0e  push r8
000076cd267d8f10  push r9
000076cd267d8f12  push r10
000076cd267d8f14  push r11
000076cd267d8f16  sub rsp, 0xF0
000076cd267d8f1d  vmovaps [rsp], xmm0
000076cd267d8f22  vmovaps [rsp+0x10], xmm2
000076cd267d8f28  vmovaps [rsp+0x20], xmm3
000076cd267d8f2e  vmovaps [rsp+0x30], xmm4
000076cd267d8f34  vmovaps [rsp+0x40], xmm5
000076cd267d8f3a  vmovaps [rsp+0x50], xmm6
000076cd267d8f40  vmovaps [rsp+0x60], xmm7
000076cd267d8f46  vmovaps [rsp+0x70], xmm8
000076cd267d8f4c  vmovaps [rsp+0x80], xmm9
000076cd267d8f55  vmovaps [rsp+0x90], xmm10
000076cd267d8f5e  vmovaps [rsp+0xA0], xmm11
000076cd267d8f67  vmovaps [rsp+0xB0], xmm12
000076cd267d8f70  vmovaps [rsp+0xC0], xmm13
000076cd267d8f79  vmovaps [rsp+0xD0], xmm14
000076cd267d8f82  vmovaps [rsp+0xE0], xmm15
000076cd267d8f8b  sub rsp, 0x30
000076cd267d8f8f  movaps [rsp], xmm1
000076cd267d8f93  movaps [rsp+0x10], xmm15
000076cd267d8f99  movaps [rsp+0x20], xmm6
000076cd267d8f9e  lea rdi, [rsp]
000076cd267d8fa2  mov esi, 0x00
000076cd267d8fa7  mov rax, 0x56B8861A9530
000076cd267d8fb1  call rax
000076cd267d8fb3  movaps xmm1, [rsp]
000076cd267d8fb7  add rsp, 0x30
000076cd267d8fbb  vmovaps xmm0, [rsp]
000076cd267d8fc0  vmovaps xmm2, [rsp+0x10]
000076cd267d8fc6  vmovaps xmm3, [rsp+0x20]
000076cd267d8fcc  vmovaps xmm4, [rsp+0x30]
000076cd267d8fd2  vmovaps xmm5, [rsp+0x40]
000076cd267d8fd8  vmovaps xmm6, [rsp+0x50]
000076cd267d8fde  vmovaps xmm7, [rsp+0x60]
000076cd267d8fe4  vmovaps xmm8, [rsp+0x70]
000076cd267d8fea  vmovaps xmm9, [rsp+0x80]
000076cd267d8ff3  vmovaps xmm10, [rsp+0x90]
000076cd267d8ffc  vmovaps xmm11, [rsp+0xA0]
000076cd267d9005  vmovaps xmm12, [rsp+0xB0]
000076cd267d900e  vmovaps xmm13, [rsp+0xC0]
000076cd267d9017  vmovaps xmm14, [rsp+0xD0]
000076cd267d9020  vmovaps xmm15, [rsp+0xE0]
000076cd267d9029  add rsp, 0xF0
000076cd267d9030  pop r11
000076cd267d9032  pop r10
000076cd267d9034  pop r9
000076cd267d9036  pop r8
000076cd267d9038  pop rsi
000076cd267d9039  pop rdi
000076cd267d903a  pop rdx
000076cd267d903b  pop rcx
000076cd267d903c  pop rax
000076cd267d903d  add rsp, 0x08
000076cd267d9041  jmp 0x000076CD267D61C2
000076cd267d9046  sub rsp, 0x08
000076cd267d904a  push rax
000076cd267d904b  push rcx
000076cd267d904c  push rdx
000076cd267d904d  push rdi
000076cd267d904e  push rsi
000076cd267d904f  push r8
000076cd267d9051  push r9
000076cd267d9053  push r10
000076cd267d9055  push r11
000076cd267d9057  sub rsp, 0xF0
000076cd267d905e  vmovaps [rsp], xmm0
000076cd267d9063  vmovaps [rsp+0x10], xmm1
000076cd267d9069  vmovaps [rsp+0x20], xmm2
000076cd267d906f  vmovaps [rsp+0x30], xmm3
000076cd267d9075  vmovaps [rsp+0x40], xmm4
000076cd267d907b  vmovaps [rsp+0x50], xmm5
000076cd267d9081  vmovaps [rsp+0x60], xmm6
000076cd267d9087  vmovaps [rsp+0x70], xmm7
000076cd267d908d  vmovaps [rsp+0x80], xmm8
000076cd267d9096  vmovaps [rsp+0x90], xmm9
000076cd267d909f  vmovaps [rsp+0xA0], xmm10
000076cd267d90a8  vmovaps [rsp+0xB0], xmm11
000076cd267d90b1  vmovaps [rsp+0xC0], xmm12
000076cd267d90ba  vmovaps [rsp+0xD0], xmm13
000076cd267d90c3  vmovaps [rsp+0xE0], xmm14
000076cd267d90cc  sub rsp, 0x30
000076cd267d90d0  movaps [rsp], xmm15
000076cd267d90d5  movaps [rsp+0x10], xmm5
000076cd267d90da  movaps [rsp+0x20], xmm3
000076cd267d90df  lea rdi, [rsp]
000076cd267d90e3  mov esi, 0x00
000076cd267d90e8  mov rax, 0x56B8861A9530
000076cd267d90f2  call rax
000076cd267d90f4  movaps xmm15, [rsp]
000076cd267d90f9  add rsp, 0x30
000076cd267d90fd  vmovaps xmm0, [rsp]
000076cd267d9102  vmovaps xmm1, [rsp+0x10]
000076cd267d9108  vmovaps xmm2, [rsp+0x20]
000076cd267d910e  vmovaps xmm3, [rsp+0x30]
000076cd267d9114  vmovaps xmm4, [rsp+0x40]
000076cd267d911a  vmovaps xmm5, [rsp+0x50]
000076cd267d9120  vmovaps xmm6, [rsp+0x60]
000076cd267d9126  vmovaps xmm7, [rsp+0x70]
000076cd267d912c  vmovaps xmm8, [rsp+0x80]
000076cd267d9135  vmovaps xmm9, [rsp+0x90]
000076cd267d913e  vmovaps xmm10, [rsp+0xA0]
000076cd267d9147  vmovaps xmm11, [rsp+0xB0]
000076cd267d9150  vmovaps xmm12, [rsp+0xC0]
000076cd267d9159  vmovaps xmm13, [rsp+0xD0]
000076cd267d9162  vmovaps xmm14, [rsp+0xE0]
000076cd267d916b  add rsp, 0xF0
000076cd267d9172  pop r11
000076cd267d9174  pop r10
000076cd267d9176  pop r9
000076cd267d9178  pop r8
000076cd267d917a  pop rsi
000076cd267d917b  pop rdi
000076cd267d917c  pop rdx
000076cd267d917d  pop rcx
000076cd267d917e  pop rax
000076cd267d917f  add rsp, 0x08
000076cd267d9183  jmp 0x000076CD267D61DC
000076cd267d9188  sub rsp, 0x08
000076cd267d918c  push rax
000076cd267d918d  push rcx
000076cd267d918e  push rdx
000076cd267d918f  push rdi
000076cd267d9190  push rsi
000076cd267d9191  push r8
000076cd267d9193  push r9
000076cd267d9195  push r10
000076cd267d9197  push r11
000076cd267d9199  sub rsp, 0xF0
000076cd267d91a0  vmovaps [rsp], xmm0
000076cd267d91a5  vmovaps [rsp+0x10], xmm1
000076cd267d91ab  vmovaps [rsp+0x20], xmm2
000076cd267d91b1  vmovaps [rsp+0x30], xmm3
000076cd267d91b7  vmovaps [rsp+0x40], xmm4
000076cd267d91bd  vmovaps [rsp+0x50], xmm6
000076cd267d91c3  vmovaps [rsp+0x60], xmm7
000076cd267d91c9  vmovaps [rsp+0x70], xmm8
000076cd267d91cf  vmovaps [rsp+0x80], xmm9
000076cd267d91d8  vmovaps [rsp+0x90], xmm10
000076cd267d91e1  vmovaps [rsp+0xA0], xmm11
000076cd267d91ea  vmovaps [rsp+0xB0], xmm12
000076cd267d91f3  vmovaps [rsp+0xC0], xmm13
000076cd267d91fc  vmovaps [rsp+0xD0], xmm14
000076cd267d9205  vmovaps [rsp+0xE0], xmm15
000076cd267d920e  sub rsp, 0x30
000076cd267d9212  movaps [rsp], xmm5
000076cd267d9216  movaps [rsp+0x10], xmm8
000076cd267d921c  movaps [rsp+0x20], xmm6
000076cd267d9221  lea rdi, [rsp]
000076cd267d9225  mov esi, 0x00
000076cd267d922a  mov rax, 0x56B8861A9530
000076cd267d9234  call rax
000076cd267d9236  movaps xmm5, [rsp]
000076cd267d923a  add rsp, 0x30
000076cd267d923e  vmovaps xmm0, [rsp]
000076cd267d9243  vmovaps xmm1, [rsp+0x10]
000076cd267d9249  vmovaps xmm2, [rsp+0x20]
000076cd267d924f  vmovaps xmm3, [rsp+0x30]
000076cd267d9255  vmovaps xmm4, [rsp+0x40]
000076cd267d925b  vmovaps xmm6, [rsp+0x50]
000076cd267d9261  vmovaps xmm7, [rsp+0x60]
000076cd267d9267  vmovaps xmm8, [rsp+0x70]
000076cd267d926d  vmovaps xmm9, [rsp+0x80]
000076cd267d9276  vmovaps xmm10, [rsp+0x90]
000076cd267d927f  vmovaps xmm11, [rsp+0xA0]
000076cd267d9288  vmovaps xmm12, [rsp+0xB0]
000076cd267d9291  vmovaps xmm13, [rsp+0xC0]
000076cd267d929a  vmovaps xmm14, [rsp+0xD0]
000076cd267d92a3  vmovaps xmm15, [rsp+0xE0]
000076cd267d92ac  add rsp, 0xF0
000076cd267d92b3  pop r11
000076cd267d92b5  pop r10
000076cd267d92b7  pop r9
000076cd267d92b9  pop r8
000076cd267d92bb  pop rsi
000076cd267d92bc  pop rdi
000076cd267d92bd  pop rdx
000076cd267d92be  pop rcx
000076cd267d92bf  pop rax
000076cd267d92c0  add rsp, 0x08
000076cd267d92c4  jmp 0x000076CD267D6200
000076cd267d92c9  sub rsp, 0x08
000076cd267d92cd  push rax
000076cd267d92ce  push rcx
000076cd267d92cf  push rdx
000076cd267d92d0  push rdi
000076cd267d92d1  push rsi
000076cd267d92d2  push r8
000076cd267d92d4  push r9
000076cd267d92d6  push r10
000076cd267d92d8  push r11
000076cd267d92da  sub rsp, 0xF0
000076cd267d92e1  vmovaps [rsp], xmm0
000076cd267d92e6  vmovaps [rsp+0x10], xmm1
000076cd267d92ec  vmovaps [rsp+0x20], xmm2
000076cd267d92f2  vmovaps [rsp+0x30], xmm3
000076cd267d92f8  vmovaps [rsp+0x40], xmm4
000076cd267d92fe  vmovaps [rsp+0x50], xmm5
000076cd267d9304  vmovaps [rsp+0x60], xmm7
000076cd267d930a  vmovaps [rsp+0x70], xmm8
000076cd267d9310  vmovaps [rsp+0x80], xmm9
000076cd267d9319  vmovaps [rsp+0x90], xmm10
000076cd267d9322  vmovaps [rsp+0xA0], xmm11
000076cd267d932b  vmovaps [rsp+0xB0], xmm12
000076cd267d9334  vmovaps [rsp+0xC0], xmm13
000076cd267d933d  vmovaps [rsp+0xD0], xmm14
000076cd267d9346  vmovaps [rsp+0xE0], xmm15
000076cd267d934f  sub rsp, 0x30
000076cd267d9353  movaps [rsp], xmm6
000076cd267d9357  movaps [rsp+0x10], xmm10
000076cd267d935d  movaps [rsp+0x20], xmm8
000076cd267d9363  lea rdi, [rsp]
000076cd267d9367  mov esi, 0x00
000076cd267d936c  mov rax, 0x56B8861A9530
000076cd267d9376  call rax
000076cd267d9378  movaps xmm6, [rsp]
000076cd267d937c  add rsp, 0x30
000076cd267d9380  vmovaps xmm0, [rsp]
000076cd267d9385  vmovaps xmm1, [rsp+0x10]
000076cd267d938b  vmovaps xmm2, [rsp+0x20]
000076cd267d9391  vmovaps xmm3, [rsp+0x30]
000076cd267d9397  vmovaps xmm4, [rsp+0x40]
000076cd267d939d  vmovaps xmm5, [rsp+0x50]
000076cd267d93a3  vmovaps xmm7, [rsp+0x60]
000076cd267d93a9  vmovaps xmm8, [rsp+0x70]
000076cd267d93af  vmovaps xmm9, [rsp+0x80]
000076cd267d93b8  vmovaps xmm10, [rsp+0x90]
000076cd267d93c1  vmovaps xmm11, [rsp+0xA0]
000076cd267d93ca  vmovaps xmm12, [rsp+0xB0]
000076cd267d93d3  vmovaps xmm13, [rsp+0xC0]
000076cd267d93dc  vmovaps xmm14, [rsp+0xD0]
000076cd267d93e5  vmovaps xmm15, [rsp+0xE0]
000076cd267d93ee  add rsp, 0xF0
000076cd267d93f5  pop r11
000076cd267d93f7  pop r10
000076cd267d93f9  pop r9
000076cd267d93fb  pop r8
000076cd267d93fd  pop rsi
000076cd267d93fe  pop rdi
000076cd267d93ff  pop rdx
000076cd267d9400  pop rcx
000076cd267d9401  pop rax
000076cd267d9402  add rsp, 0x08
000076cd267d9406  jmp 0x000076CD267D6225
000076cd267d940b  sub rsp, 0x08
000076cd267d940f  push rax
000076cd267d9410  push rcx
000076cd267d9411  push rdx
000076cd267d9412  push rdi
000076cd267d9413  push rsi
000076cd267d9414  push r8
000076cd267d9416  push r9
000076cd267d9418  push r10
000076cd267d941a  push r11
000076cd267d941c  sub rsp, 0xF0
000076cd267d9423  vmovaps [rsp], xmm0
000076cd267d9428  vmovaps [rsp+0x10], xmm1
000076cd267d942e  vmovaps [rsp+0x20], xmm2
000076cd267d9434  vmovaps [rsp+0x30], xmm3
000076cd267d943a  vmovaps [rsp+0x40], xmm4
000076cd267d9440  vmovaps [rsp+0x50], xmm5
000076cd267d9446  vmovaps [rsp+0x60], xmm6
000076cd267d944c  vmovaps [rsp+0x70], xmm7
000076cd267d9452  vmovaps [rsp+0x80], xmm8
000076cd267d945b  vmovaps [rsp+0x90], xmm9
000076cd267d9464  vmovaps [rsp+0xA0], xmm11
000076cd267d946d  vmovaps [rsp+0xB0], xmm12
000076cd267d9476  vmovaps [rsp+0xC0], xmm13
000076cd267d947f  vmovaps [rsp+0xD0], xmm14
000076cd267d9488  vmovaps [rsp+0xE0], xmm15
000076cd267d9491  sub rsp, 0x30
000076cd267d9495  movaps [rsp], xmm10
000076cd267d949a  movaps [rsp+0x10], xmm8
000076cd267d94a0  movaps [rsp+0x20], xmm14
000076cd267d94a6  lea rdi, [rsp]
000076cd267d94aa  mov esi, 0x00
000076cd267d94af  mov rax, 0x56B8861A9530
000076cd267d94b9  call rax
000076cd267d94bb  movaps xmm10, [rsp]
000076cd267d94c0  add rsp, 0x30
000076cd267d94c4  vmovaps xmm0, [rsp]
000076cd267d94c9  vmovaps xmm1, [rsp+0x10]
000076cd267d94cf  vmovaps xmm2, [rsp+0x20]
000076cd267d94d5  vmovaps xmm3, [rsp+0x30]
000076cd267d94db  vmovaps xmm4, [rsp+0x40]
000076cd267d94e1  vmovaps xmm5, [rsp+0x50]
000076cd267d94e7  vmovaps xmm6, [rsp+0x60]
000076cd267d94ed  vmovaps xmm7, [rsp+0x70]
000076cd267d94f3  vmovaps xmm8, [rsp+0x80]
000076cd267d94fc  vmovaps xmm9, [rsp+0x90]
000076cd267d9505  vmovaps xmm11, [rsp+0xA0]
000076cd267d950e  vmovaps xmm12, [rsp+0xB0]
000076cd267d9517  vmovaps xmm13, [rsp+0xC0]
000076cd267d9520  vmovaps xmm14, [rsp+0xD0]
000076cd267d9529  vmovaps xmm15, [rsp+0xE0]
000076cd267d9532  add rsp, 0xF0
000076cd267d9539  pop r11
000076cd267d953b  pop r10
000076cd267d953d  pop r9
000076cd267d953f  pop r8
000076cd267d9541  pop rsi
000076cd267d9542  pop rdi
000076cd267d9543  pop rdx
000076cd267d9544  pop rcx
000076cd267d9545  pop rax
000076cd267d9546  add rsp, 0x08
000076cd267d954a  jmp 0x000076CD267D6245
000076cd267d954f  sub rsp, 0x08
000076cd267d9553  push rax
000076cd267d9554  push rcx
000076cd267d9555  push rdx
000076cd267d9556  push rdi
000076cd267d9557  push rsi
000076cd267d9558  push r8
000076cd267d955a  push r9
000076cd267d955c  push r10
000076cd267d955e  push r11
000076cd267d9560  sub rsp, 0xF0
000076cd267d9567  vmovaps [rsp], xmm0
000076cd267d956c  vmovaps [rsp+0x10], xmm1
000076cd267d9572  vmovaps [rsp+0x20], xmm2
000076cd267d9578  vmovaps [rsp+0x30], xmm3
000076cd267d957e  vmovaps [rsp+0x40], xmm4
000076cd267d9584  vmovaps [rsp+0x50], xmm5
000076cd267d958a  vmovaps [rsp+0x60], xmm6
000076cd267d9590  vmovaps [rsp+0x70], xmm7
000076cd267d9596  vmovaps [rsp+0x80], xmm8
000076cd267d959f  vmovaps [rsp+0x90], xmm9
000076cd267d95a8  vmovaps [rsp+0xA0], xmm10
000076cd267d95b1  vmovaps [rsp+0xB0], xmm11
000076cd267d95ba  vmovaps [rsp+0xC0], xmm12
000076cd267d95c3  vmovaps [rsp+0xD0], xmm13
000076cd267d95cc  vmovaps [rsp+0xE0], xmm15
000076cd267d95d5  sub rsp, 0x30
000076cd267d95d9  movaps [rsp], xmm14
000076cd267d95de  movaps [rsp+0x10], xmm8
000076cd267d95e4  movaps [rsp+0x20], xmm4
000076cd267d95e9  lea rdi, [rsp]
000076cd267d95ed  mov esi, 0x00
000076cd267d95f2  mov rax, 0x56B8861A9530
000076cd267d95fc  call rax
000076cd267d95fe  movaps xmm14, [rsp]
000076cd267d9603  add rsp, 0x30
000076cd267d9607  vmovaps xmm0, [rsp]
000076cd267d960c  vmovaps xmm1, [rsp+0x10]
000076cd267d9612  vmovaps xmm2, [rsp+0x20]
000076cd267d9618  vmovaps xmm3, [rsp+0x30]
000076cd267d961e  vmovaps xmm4, [rsp+0x40]
000076cd267d9624  vmovaps xmm5, [rsp+0x50]
000076cd267d962a  vmovaps xmm6, [rsp+0x60]
000076cd267d9630  vmovaps xmm7, [rsp+0x70]
000076cd267d9636  vmovaps xmm8, [rsp+0x80]
000076cd267d963f  vmovaps xmm9, [rsp+0x90]
000076cd267d9648  vmovaps xmm10, [rsp+0xA0]
000076cd267d9651  vmovaps xmm11, [rsp+0xB0]
000076cd267d965a  vmovaps xmm12, [rsp+0xC0]
000076cd267d9663  vmovaps xmm13, [rsp+0xD0]
000076cd267d966c  vmovaps xmm15, [rsp+0xE0]
000076cd267d9675  add rsp, 0xF0
000076cd267d967c  pop r11
000076cd267d967e  pop r10
000076cd267d9680  pop r9
000076cd267d9682  pop r8
000076cd267d9684  pop rsi
000076cd267d9685  pop rdi
000076cd267d9686  pop rdx
000076cd267d9687  pop rcx
000076cd267d9688  pop rax
000076cd267d9689  add rsp, 0x08
000076cd267d968d  jmp 0x000076CD267D6265
000076cd267d9692  sub rsp, 0x08
000076cd267d9696  push rax
000076cd267d9697  push rcx
000076cd267d9698  push rdx
000076cd267d9699  push rdi
000076cd267d969a  push rsi
000076cd267d969b  push r8
000076cd267d969d  push r9
000076cd267d969f  push r10
000076cd267d96a1  push r11
000076cd267d96a3  sub rsp, 0xF0
000076cd267d96aa  vmovaps [rsp], xmm0
000076cd267d96af  vmovaps [rsp+0x10], xmm1
000076cd267d96b5  vmovaps [rsp+0x20], xmm2
000076cd267d96bb  vmovaps [rsp+0x30], xmm3
000076cd267d96c1  vmovaps [rsp+0x40], xmm5
000076cd267d96c7  vmovaps [rsp+0x50], xmm6
000076cd267d96cd  vmovaps [rsp+0x60], xmm7
000076cd267d96d3  vmovaps [rsp+0x70], xmm8
000076cd267d96d9  vmovaps [rsp+0x80], xmm9
000076cd267d96e2  vmovaps [rsp+0x90], xmm10
000076cd267d96eb  vmovaps [rsp+0xA0], xmm11
000076cd267d96f4  vmovaps [rsp+0xB0], xmm12
000076cd267d96fd  vmovaps [rsp+0xC0], xmm13
000076cd267d9706  vmovaps [rsp+0xD0], xmm14
000076cd267d970f  vmovaps [rsp+0xE0], xmm15
000076cd267d9718  sub rsp, 0x30
000076cd267d971c  movaps [rsp], xmm4
000076cd267d9720  movaps [rsp+0x10], xmm13
000076cd267d9726  movaps [rsp+0x20], xmm8
000076cd267d972c  lea rdi, [rsp]
000076cd267d9730  mov esi, 0x00
000076cd267d9735  mov rax, 0x56B8861A9530
000076cd267d973f  call rax
000076cd267d9741  movaps xmm4, [rsp]
000076cd267d9745  add rsp, 0x30
000076cd267d9749  vmovaps xmm0, [rsp]
000076cd267d974e  vmovaps xmm1, [rsp+0x10]
000076cd267d9754  vmovaps xmm2, [rsp+0x20]
000076cd267d975a  vmovaps xmm3, [rsp+0x30]
000076cd267d9760  vmovaps xmm5, [rsp+0x40]
000076cd267d9766  vmovaps xmm6, [rsp+0x50]
000076cd267d976c  vmovaps xmm7, [rsp+0x60]
000076cd267d9772  vmovaps xmm8, [rsp+0x70]
000076cd267d9778  vmovaps xmm9, [rsp+0x80]
000076cd267d9781  vmovaps xmm10, [rsp+0x90]
000076cd267d978a  vmovaps xmm11, [rsp+0xA0]
000076cd267d9793  vmovaps xmm12, [rsp+0xB0]
000076cd267d979c  vmovaps xmm13, [rsp+0xC0]
000076cd267d97a5  vmovaps xmm14, [rsp+0xD0]
000076cd267d97ae  vmovaps xmm15, [rsp+0xE0]
000076cd267d97b7  add rsp, 0xF0
000076cd267d97be  pop r11
000076cd267d97c0  pop r10
000076cd267d97c2  pop r9
000076cd267d97c4  pop r8
000076cd267d97c6  pop rsi
000076cd267d97c7  pop rdi
000076cd267d97c8  pop rdx
000076cd267d97c9  pop rcx
000076cd267d97ca  pop rax
000076cd267d97cb  add rsp, 0x08
000076cd267d97cf  jmp 0x000076CD267D628A
000076cd267d97d4  sub rsp, 0x08
000076cd267d97d8  push rax
000076cd267d97d9  push rcx
000076cd267d97da  push rdx
000076cd267d97db  push rdi
000076cd267d97dc  push rsi
000076cd267d97dd  push r8
000076cd267d97df  push r9
000076cd267d97e1  push r10
000076cd267d97e3  push r11
000076cd267d97e5  sub rsp, 0xF0
000076cd267d97ec  vmovaps [rsp], xmm0
000076cd267d97f1  vmovaps [rsp+0x10], xmm1
000076cd267d97f7  vmovaps [rsp+0x20], xmm2
000076cd267d97fd  vmovaps [rsp+0x30], xmm3
000076cd267d9803  vmovaps [rsp+0x40], xmm4
000076cd267d9809  vmovaps [rsp+0x50], xmm5
000076cd267d980f  vmovaps [rsp+0x60], xmm6
000076cd267d9815  vmovaps [rsp+0x70], xmm7
000076cd267d981b  vmovaps [rsp+0x80], xmm8
000076cd267d9824  vmovaps [rsp+0x90], xmm9
000076cd267d982d  vmovaps [rsp+0xA0], xmm10
000076cd267d9836  vmovaps [rsp+0xB0], xmm11
000076cd267d983f  vmovaps [rsp+0xC0], xmm12
000076cd267d9848  vmovaps [rsp+0xD0], xmm14
000076cd267d9851  vmovaps [rsp+0xE0], xmm15
000076cd267d985a  sub rsp, 0x30
000076cd267d985e  movaps [rsp], xmm13
000076cd267d9863  movaps [rsp+0x10], xmm15
000076cd267d9869  movaps [rsp+0x20], xmm9
000076cd267d986f  lea rdi, [rsp]
000076cd267d9873  mov esi, 0x00
000076cd267d9878  mov rax, 0x56B8861A9530
000076cd267d9882  call rax
000076cd267d9884  movaps xmm13, [rsp]
000076cd267d9889  add rsp, 0x30
000076cd267d988d  vmovaps xmm0, [rsp]
000076cd267d9892  vmovaps xmm1, [rsp+0x10]
000076cd267d9898  vmovaps xmm2, [rsp+0x20]
000076cd267d989e  vmovaps xmm3, [rsp+0x30]
000076cd267d98a4  vmovaps xmm4, [rsp+0x40]
000076cd267d98aa  vmovaps xmm5, [rsp+0x50]
000076cd267d98b0  vmovaps xmm6, [rsp+0x60]
000076cd267d98b6  vmovaps xmm7, [rsp+0x70]
000076cd267d98bc  vmovaps xmm8, [rsp+0x80]
000076cd267d98c5  vmovaps xmm9, [rsp+0x90]
000076cd267d98ce  vmovaps xmm10, [rsp+0xA0]
000076cd267d98d7  vmovaps xmm11, [rsp+0xB0]
000076cd267d98e0  vmovaps xmm12, [rsp+0xC0]
000076cd267d98e9  vmovaps xmm14, [rsp+0xD0]
000076cd267d98f2  vmovaps xmm15, [rsp+0xE0]
000076cd267d98fb  add rsp, 0xF0
000076cd267d9902  pop r11
000076cd267d9904  pop r10
000076cd267d9906  pop r9
000076cd267d9908  pop r8
000076cd267d990a  pop rsi
000076cd267d990b  pop rdi
000076cd267d990c  pop rdx
000076cd267d990d  pop rcx
000076cd267d990e  pop rax
000076cd267d990f  add rsp, 0x08
000076cd267d9913  jmp 0x000076CD267D62A5
000076cd267d9918  sub rsp, 0x08
000076cd267d991c  push rax
000076cd267d991d  push rcx
000076cd267d991e  push rdx
000076cd267d991f  push rdi
000076cd267d9920  push rsi
000076cd267d9921  push r8
000076cd267d9923  push r9
000076cd267d9925  push r10
000076cd267d9927  push r11
000076cd267d9929  sub rsp, 0xF0
000076cd267d9930  vmovaps [rsp], xmm0
000076cd267d9935  vmovaps [rsp+0x10], xmm1
000076cd267d993b  vmovaps [rsp+0x20], xmm2
000076cd267d9941  vmovaps [rsp+0x30], xmm3
000076cd267d9947  vmovaps [rsp+0x40], xmm4
000076cd267d994d  vmovaps [rsp+0x50], xmm5
000076cd267d9953  vmovaps [rsp+0x60], xmm6
000076cd267d9959  vmovaps [rsp+0x70], xmm7
000076cd267d995f  vmovaps [rsp+0x80], xmm8
000076cd267d9968  vmovaps [rsp+0x90], xmm9
000076cd267d9971  vmovaps [rsp+0xA0], xmm10
000076cd267d997a  vmovaps [rsp+0xB0], xmm11
000076cd267d9983  vmovaps [rsp+0xC0], xmm12
000076cd267d998c  vmovaps [rsp+0xD0], xmm13
000076cd267d9995  vmovaps [rsp+0xE0], xmm14
000076cd267d999e  sub rsp, 0x30
000076cd267d99a2  movaps [rsp], xmm15
000076cd267d99a7  movaps [rsp+0x10], xmm1
000076cd267d99ac  movaps [rsp+0x20], xmm5
000076cd267d99b1  lea rdi, [rsp]
000076cd267d99b5  mov esi, 0x00
000076cd267d99ba  mov rax, 0x56B8861A9530
000076cd267d99c4  call rax
000076cd267d99c6  movaps xmm15, [rsp]
000076cd267d99cb  add rsp, 0x30
000076cd267d99cf  vmovaps xmm0, [rsp]
000076cd267d99d4  vmovaps xmm1, [rsp+0x10]
000076cd267d99da  vmovaps xmm2, [rsp+0x20]
000076cd267d99e0  vmovaps xmm3, [rsp+0x30]
000076cd267d99e6  vmovaps xmm4, [rsp+0x40]
000076cd267d99ec  vmovaps xmm5, [rsp+0x50]
000076cd267d99f2  vmovaps xmm6, [rsp+0x60]
000076cd267d99f8  vmovaps xmm7, [rsp+0x70]
000076cd267d99fe  vmovaps xmm8, [rsp+0x80]
000076cd267d9a07  vmovaps xmm9, [rsp+0x90]
000076cd267d9a10  vmovaps xmm10, [rsp+0xA0]
000076cd267d9a19  vmovaps xmm11, [rsp+0xB0]
000076cd267d9a22  vmovaps xmm12, [rsp+0xC0]
000076cd267d9a2b  vmovaps xmm13, [rsp+0xD0]
000076cd267d9a34  vmovaps xmm14, [rsp+0xE0]
000076cd267d9a3d  add rsp, 0xF0
000076cd267d9a44  pop r11
000076cd267d9a46  pop r10
000076cd267d9a48  pop r9
000076cd267d9a4a  pop r8
000076cd267d9a4c  pop rsi
000076cd267d9a4d  pop rdi
000076cd267d9a4e  pop rdx
000076cd267d9a4f  pop rcx
000076cd267d9a50  pop rax
000076cd267d9a51  add rsp, 0x08
000076cd267d9a55  jmp 0x000076CD267D62C0
000076cd267d9a5a  call 0x000076CD266D64F0
000076cd267d9a5f  jmp 0x000076CD267D631B
000076cd267d9a64  sub rsp, 0x08
000076cd267d9a68  push rax
000076cd267d9a69  push rcx
000076cd267d9a6a  push rdx
000076cd267d9a6b  push rdi
000076cd267d9a6c  push rsi
000076cd267d9a6d  push r8
000076cd267d9a6f  push r9
000076cd267d9a71  push r10
000076cd267d9a73  push r11
000076cd267d9a75  sub rsp, 0xF0
000076cd267d9a7c  vmovaps [rsp], xmm0
000076cd267d9a81  vmovaps [rsp+0x10], xmm1
000076cd267d9a87  vmovaps [rsp+0x20], xmm2
000076cd267d9a8d  vmovaps [rsp+0x30], xmm3
000076cd267d9a93  vmovaps [rsp+0x40], xmm4
000076cd267d9a99  vmovaps [rsp+0x50], xmm5
000076cd267d9a9f  vmovaps [rsp+0x60], xmm6
000076cd267d9aa5  vmovaps [rsp+0x70], xmm7
000076cd267d9aab  vmovaps [rsp+0x80], xmm8
000076cd267d9ab4  vmovaps [rsp+0x90], xmm10
000076cd267d9abd  vmovaps [rsp+0xA0], xmm11
000076cd267d9ac6  vmovaps [rsp+0xB0], xmm12
000076cd267d9acf  vmovaps [rsp+0xC0], xmm13
000076cd267d9ad8  vmovaps [rsp+0xD0], xmm14
000076cd267d9ae1  vmovaps [rsp+0xE0], xmm15
000076cd267d9aea  sub rsp, 0x30
000076cd267d9aee  movaps [rsp], xmm9
000076cd267d9af3  movaps [rsp+0x10], xmm8
000076cd267d9af9  movaps [rsp+0x20], xmm11
000076cd267d9aff  lea rdi, [rsp]
000076cd267d9b03  mov esi, 0x00
000076cd267d9b08  mov rax, 0x56B8861A9530
000076cd267d9b12  call rax
000076cd267d9b14  movaps xmm9, [rsp]
000076cd267d9b19  add rsp, 0x30
000076cd267d9b1d  vmovaps xmm0, [rsp]
000076cd267d9b22  vmovaps xmm1, [rsp+0x10]
000076cd267d9b28  vmovaps xmm2, [rsp+0x20]
000076cd267d9b2e  vmovaps xmm3, [rsp+0x30]
000076cd267d9b34  vmovaps xmm4, [rsp+0x40]
000076cd267d9b3a  vmovaps xmm5, [rsp+0x50]
000076cd267d9b40  vmovaps xmm6, [rsp+0x60]
000076cd267d9b46  vmovaps xmm7, [rsp+0x70]
000076cd267d9b4c  vmovaps xmm8, [rsp+0x80]
000076cd267d9b55  vmovaps xmm10, [rsp+0x90]
000076cd267d9b5e  vmovaps xmm11, [rsp+0xA0]
000076cd267d9b67  vmovaps xmm12, [rsp+0xB0]
000076cd267d9b70  vmovaps xmm13, [rsp+0xC0]
000076cd267d9b79  vmovaps xmm14, [rsp+0xD0]
000076cd267d9b82  vmovaps xmm15, [rsp+0xE0]
000076cd267d9b8b  add rsp, 0xF0
000076cd267d9b92  pop r11
000076cd267d9b94  pop r10
000076cd267d9b96  pop r9
000076cd267d9b98  pop r8
000076cd267d9b9a  pop rsi
000076cd267d9b9b  pop rdi
000076cd267d9b9c  pop rdx
000076cd267d9b9d  pop rcx
000076cd267d9b9e  pop rax
000076cd267d9b9f  add rsp, 0x08
000076cd267d9ba3  jmp 0x000076CD267D6352
000076cd267d9ba8  sub rsp, 0x08
000076cd267d9bac  push rax
000076cd267d9bad  push rcx
000076cd267d9bae  push rdx
000076cd267d9baf  push rdi
000076cd267d9bb0  push rsi
000076cd267d9bb1  push r8
000076cd267d9bb3  push r9
000076cd267d9bb5  push r10
000076cd267d9bb7  push r11
000076cd267d9bb9  sub rsp, 0xF0
000076cd267d9bc0  vmovaps [rsp], xmm0
000076cd267d9bc5  vmovaps [rsp+0x10], xmm1
000076cd267d9bcb  vmovaps [rsp+0x20], xmm2
000076cd267d9bd1  vmovaps [rsp+0x30], xmm3
000076cd267d9bd7  vmovaps [rsp+0x40], xmm4
000076cd267d9bdd  vmovaps [rsp+0x50], xmm5
000076cd267d9be3  vmovaps [rsp+0x60], xmm6
000076cd267d9be9  vmovaps [rsp+0x70], xmm7
000076cd267d9bef  vmovaps [rsp+0x80], xmm8
000076cd267d9bf8  vmovaps [rsp+0x90], xmm9
000076cd267d9c01  vmovaps [rsp+0xA0], xmm10
000076cd267d9c0a  vmovaps [rsp+0xB0], xmm12
000076cd267d9c13  vmovaps [rsp+0xC0], xmm13
000076cd267d9c1c  vmovaps [rsp+0xD0], xmm14
000076cd267d9c25  vmovaps [rsp+0xE0], xmm15
000076cd267d9c2e  sub rsp, 0x30
000076cd267d9c32  movaps [rsp], xmm11
000076cd267d9c37  movaps [rsp+0x10], xmm10
000076cd267d9c3d  movaps [rsp+0x20], xmm6
000076cd267d9c42  lea rdi, [rsp]
000076cd267d9c46  mov esi, 0x00
000076cd267d9c4b  mov rax, 0x56B8861A9530
000076cd267d9c55  call rax
000076cd267d9c57  movaps xmm11, [rsp]
000076cd267d9c5c  add rsp, 0x30
000076cd267d9c60  vmovaps xmm0, [rsp]
000076cd267d9c65  vmovaps xmm1, [rsp+0x10]
000076cd267d9c6b  vmovaps xmm2, [rsp+0x20]
000076cd267d9c71  vmovaps xmm3, [rsp+0x30]
000076cd267d9c77  vmovaps xmm4, [rsp+0x40]
000076cd267d9c7d  vmovaps xmm5, [rsp+0x50]
000076cd267d9c83  vmovaps xmm6, [rsp+0x60]
000076cd267d9c89  vmovaps xmm7, [rsp+0x70]
000076cd267d9c8f  vmovaps xmm8, [rsp+0x80]
000076cd267d9c98  vmovaps xmm9, [rsp+0x90]
000076cd267d9ca1  vmovaps xmm10, [rsp+0xA0]
000076cd267d9caa  vmovaps xmm12, [rsp+0xB0]
000076cd267d9cb3  vmovaps xmm13, [rsp+0xC0]
000076cd267d9cbc  vmovaps xmm14, [rsp+0xD0]
000076cd267d9cc5  vmovaps xmm15, [rsp+0xE0]
000076cd267d9cce  add rsp, 0xF0
000076cd267d9cd5  pop r11
000076cd267d9cd7  pop r10
000076cd267d9cd9  pop r9
000076cd267d9cdb  pop r8
000076cd267d9cdd  pop rsi
000076cd267d9cde  pop rdi
000076cd267d9cdf  pop rdx
000076cd267d9ce0  pop rcx
000076cd267d9ce1  pop rax
000076cd267d9ce2  add rsp, 0x08
000076cd267d9ce6  jmp 0x000076CD267D636D
000076cd267d9ceb  sub rsp, 0x08
000076cd267d9cef  push rax
000076cd267d9cf0  push rcx
000076cd267d9cf1  push rdx
000076cd267d9cf2  push rdi
000076cd267d9cf3  push rsi
000076cd267d9cf4  push r8
000076cd267d9cf6  push r9
000076cd267d9cf8  push r10
000076cd267d9cfa  push r11
000076cd267d9cfc  sub rsp, 0xF0
000076cd267d9d03  vmovaps [rsp], xmm0
000076cd267d9d08  vmovaps [rsp+0x10], xmm1
000076cd267d9d0e  vmovaps [rsp+0x20], xmm2
000076cd267d9d14  vmovaps [rsp+0x30], xmm3
000076cd267d9d1a  vmovaps [rsp+0x40], xmm4
000076cd267d9d20  vmovaps [rsp+0x50], xmm5
000076cd267d9d26  vmovaps [rsp+0x60], xmm6
000076cd267d9d2c  vmovaps [rsp+0x70], xmm7
000076cd267d9d32  vmovaps [rsp+0x80], xmm8
000076cd267d9d3b  vmovaps [rsp+0x90], xmm9
000076cd267d9d44  vmovaps [rsp+0xA0], xmm11
000076cd267d9d4d  vmovaps [rsp+0xB0], xmm12
000076cd267d9d56  vmovaps [rsp+0xC0], xmm13
000076cd267d9d5f  vmovaps [rsp+0xD0], xmm14
000076cd267d9d68  vmovaps [rsp+0xE0], xmm15
000076cd267d9d71  sub rsp, 0x30
000076cd267d9d75  movaps [rsp], xmm10
000076cd267d9d7a  movaps [rsp+0x10], xmm14
000076cd267d9d80  movaps [rsp+0x20], xmm4
000076cd267d9d85  lea rdi, [rsp]
000076cd267d9d89  mov esi, 0x00
000076cd267d9d8e  mov rax, 0x56B8861A9530
000076cd267d9d98  call rax
000076cd267d9d9a  movaps xmm10, [rsp]
000076cd267d9d9f  add rsp, 0x30
000076cd267d9da3  vmovaps xmm0, [rsp]
000076cd267d9da8  vmovaps xmm1, [rsp+0x10]
000076cd267d9dae  vmovaps xmm2, [rsp+0x20]
000076cd267d9db4  vmovaps xmm3, [rsp+0x30]
000076cd267d9dba  vmovaps xmm4, [rsp+0x40]
000076cd267d9dc0  vmovaps xmm5, [rsp+0x50]
000076cd267d9dc6  vmovaps xmm6, [rsp+0x60]
000076cd267d9dcc  vmovaps xmm7, [rsp+0x70]
000076cd267d9dd2  vmovaps xmm8, [rsp+0x80]
000076cd267d9ddb  vmovaps xmm9, [rsp+0x90]
000076cd267d9de4  vmovaps xmm11, [rsp+0xA0]
000076cd267d9ded  vmovaps xmm12, [rsp+0xB0]
000076cd267d9df6  vmovaps xmm13, [rsp+0xC0]
000076cd267d9dff  vmovaps xmm14, [rsp+0xD0]
000076cd267d9e08  vmovaps xmm15, [rsp+0xE0]
000076cd267d9e11  add rsp, 0xF0
000076cd267d9e18  pop r11
000076cd267d9e1a  pop r10
000076cd267d9e1c  pop r9
000076cd267d9e1e  pop r8
000076cd267d9e20  pop rsi
000076cd267d9e21  pop rdi
000076cd267d9e22  pop rdx
000076cd267d9e23  pop rcx
000076cd267d9e24  pop rax
000076cd267d9e25  add rsp, 0x08
000076cd267d9e29  jmp 0x000076CD267D6388
000076cd267d9e2e  sub rsp, 0x08
000076cd267d9e32  push rax
000076cd267d9e33  push rcx
000076cd267d9e34  push rdx
000076cd267d9e35  push rdi
000076cd267d9e36  push rsi
000076cd267d9e37  push r8
000076cd267d9e39  push r9
000076cd267d9e3b  push r10
000076cd267d9e3d  push r11
000076cd267d9e3f  sub rsp, 0xF0
000076cd267d9e46  vmovaps [rsp], xmm0
000076cd267d9e4b  vmovaps [rsp+0x10], xmm1
000076cd267d9e51  vmovaps [rsp+0x20], xmm2
000076cd267d9e57  vmovaps [rsp+0x30], xmm3
000076cd267d9e5d  vmovaps [rsp+0x40], xmm4
000076cd267d9e63  vmovaps [rsp+0x50], xmm5
000076cd267d9e69  vmovaps [rsp+0x60], xmm6
000076cd267d9e6f  vmovaps [rsp+0x70], xmm7
000076cd267d9e75  vmovaps [rsp+0x80], xmm9
000076cd267d9e7e  vmovaps [rsp+0x90], xmm10
000076cd267d9e87  vmovaps [rsp+0xA0], xmm11
000076cd267d9e90  vmovaps [rsp+0xB0], xmm12
000076cd267d9e99  vmovaps [rsp+0xC0], xmm13
000076cd267d9ea2  vmovaps [rsp+0xD0], xmm14
000076cd267d9eab  vmovaps [rsp+0xE0], xmm15
000076cd267d9eb4  sub rsp, 0x30
000076cd267d9eb8  movaps [rsp], xmm8
000076cd267d9ebd  movaps [rsp+0x10], xmm1
000076cd267d9ec2  movaps [rsp+0x20], xmm14
000076cd267d9ec8  lea rdi, [rsp]
000076cd267d9ecc  mov esi, 0x00
000076cd267d9ed1  mov rax, 0x56B8861A9530
000076cd267d9edb  call rax
000076cd267d9edd  movaps xmm8, [rsp]
000076cd267d9ee2  add rsp, 0x30
000076cd267d9ee6  vmovaps xmm0, [rsp]
000076cd267d9eeb  vmovaps xmm1, [rsp+0x10]
000076cd267d9ef1  vmovaps xmm2, [rsp+0x20]
000076cd267d9ef7  vmovaps xmm3, [rsp+0x30]
000076cd267d9efd  vmovaps xmm4, [rsp+0x40]
000076cd267d9f03  vmovaps xmm5, [rsp+0x50]
000076cd267d9f09  vmovaps xmm6, [rsp+0x60]
000076cd267d9f0f  vmovaps xmm7, [rsp+0x70]
000076cd267d9f15  vmovaps xmm9, [rsp+0x80]
000076cd267d9f1e  vmovaps xmm10, [rsp+0x90]
000076cd267d9f27  vmovaps xmm11, [rsp+0xA0]
000076cd267d9f30  vmovaps xmm12, [rsp+0xB0]
000076cd267d9f39  vmovaps xmm13, [rsp+0xC0]
000076cd267d9f42  vmovaps xmm14, [rsp+0xD0]
000076cd267d9f4b  vmovaps xmm15, [rsp+0xE0]
000076cd267d9f54  add rsp, 0xF0
000076cd267d9f5b  pop r11
000076cd267d9f5d  pop r10
000076cd267d9f5f  pop r9
000076cd267d9f61  pop r8
000076cd267d9f63  pop rsi
000076cd267d9f64  pop rdi
000076cd267d9f65  pop rdx
000076cd267d9f66  pop rcx
000076cd267d9f67  pop rax
000076cd267d9f68  add rsp, 0x08
000076cd267d9f6c  jmp 0x000076CD267D63AE
000076cd267d9f71  sub rsp, 0x08
000076cd267d9f75  push rax
000076cd267d9f76  push rcx
000076cd267d9f77  push rdx
000076cd267d9f78  push rdi
000076cd267d9f79  push rsi
000076cd267d9f7a  push r8
000076cd267d9f7c  push r9
000076cd267d9f7e  push r10
000076cd267d9f80  push r11
000076cd267d9f82  sub rsp, 0xF0
000076cd267d9f89  vmovaps [rsp], xmm0
000076cd267d9f8e  vmovaps [rsp+0x10], xmm1
000076cd267d9f94  vmovaps [rsp+0x20], xmm2
000076cd267d9f9a  vmovaps [rsp+0x30], xmm3
000076cd267d9fa0  vmovaps [rsp+0x40], xmm4
000076cd267d9fa6  vmovaps [rsp+0x50], xmm5
000076cd267d9fac  vmovaps [rsp+0x60], xmm7
000076cd267d9fb2  vmovaps [rsp+0x70], xmm8
000076cd267d9fb8  vmovaps [rsp+0x80], xmm9
000076cd267d9fc1  vmovaps [rsp+0x90], xmm10
000076cd267d9fca  vmovaps [rsp+0xA0], xmm11
000076cd267d9fd3  vmovaps [rsp+0xB0], xmm12
000076cd267d9fdc  vmovaps [rsp+0xC0], xmm13
000076cd267d9fe5  vmovaps [rsp+0xD0], xmm14
000076cd267d9fee  vmovaps [rsp+0xE0], xmm15
000076cd267d9ff7  sub rsp, 0x30
000076cd267d9ffb  movaps [rsp], xmm6
000076cd267d9fff  movaps [rsp+0x10], xmm1
000076cd267da004  movaps [rsp+0x20], xmm14
000076cd267da00a  lea rdi, [rsp]
000076cd267da00e  mov esi, 0x00
000076cd267da013  mov rax, 0x56B8861A9530
000076cd267da01d  call rax
000076cd267da01f  movaps xmm6, [rsp]
000076cd267da023  add rsp, 0x30
000076cd267da027  vmovaps xmm0, [rsp]
000076cd267da02c  vmovaps xmm1, [rsp+0x10]
000076cd267da032  vmovaps xmm2, [rsp+0x20]
000076cd267da038  vmovaps xmm3, [rsp+0x30]
000076cd267da03e  vmovaps xmm4, [rsp+0x40]
000076cd267da044  vmovaps xmm5, [rsp+0x50]
000076cd267da04a  vmovaps xmm7, [rsp+0x60]
000076cd267da050  vmovaps xmm8, [rsp+0x70]
000076cd267da056  vmovaps xmm9, [rsp+0x80]
000076cd267da05f  vmovaps xmm10, [rsp+0x90]
000076cd267da068  vmovaps xmm11, [rsp+0xA0]
000076cd267da071  vmovaps xmm12, [rsp+0xB0]
000076cd267da07a  vmovaps xmm13, [rsp+0xC0]
000076cd267da083  vmovaps xmm14, [rsp+0xD0]
000076cd267da08c  vmovaps xmm15, [rsp+0xE0]
000076cd267da095  add rsp, 0xF0
000076cd267da09c  pop r11
000076cd267da09e  pop r10
000076cd267da0a0  pop r9
000076cd267da0a2  pop r8
000076cd267da0a4  pop rsi
000076cd267da0a5  pop rdi
000076cd267da0a6  pop rdx
000076cd267da0a7  pop rcx
000076cd267da0a8  pop rax
000076cd267da0a9  add rsp, 0x08
000076cd267da0ad  jmp 0x000076CD267D63DA
000076cd267da0b2  sub rsp, 0x08
000076cd267da0b6  push rax
000076cd267da0b7  push rcx
000076cd267da0b8  push rdx
000076cd267da0b9  push rdi
000076cd267da0ba  push rsi
000076cd267da0bb  push r8
000076cd267da0bd  push r9
000076cd267da0bf  push r10
000076cd267da0c1  push r11
000076cd267da0c3  sub rsp, 0xF0
000076cd267da0ca  vmovaps [rsp], xmm0
000076cd267da0cf  vmovaps [rsp+0x10], xmm1
000076cd267da0d5  vmovaps [rsp+0x20], xmm2
000076cd267da0db  vmovaps [rsp+0x30], xmm3
000076cd267da0e1  vmovaps [rsp+0x40], xmm4
000076cd267da0e7  vmovaps [rsp+0x50], xmm5
000076cd267da0ed  vmovaps [rsp+0x60], xmm6
000076cd267da0f3  vmovaps [rsp+0x70], xmm7
000076cd267da0f9  vmovaps [rsp+0x80], xmm8
000076cd267da102  vmovaps [rsp+0x90], xmm9
000076cd267da10b  vmovaps [rsp+0xA0], xmm10
000076cd267da114  vmovaps [rsp+0xB0], xmm11
000076cd267da11d  vmovaps [rsp+0xC0], xmm12
000076cd267da126  vmovaps [rsp+0xD0], xmm13
000076cd267da12f  vmovaps [rsp+0xE0], xmm15
000076cd267da138  sub rsp, 0x30
000076cd267da13c  movaps [rsp], xmm14
000076cd267da141  movaps [rsp+0x10], xmm12
000076cd267da147  movaps [rsp+0x20], xmm1
000076cd267da14c  lea rdi, [rsp]
000076cd267da150  mov esi, 0x00
000076cd267da155  mov rax, 0x56B8861A9530
000076cd267da15f  call rax
000076cd267da161  movaps xmm14, [rsp]
000076cd267da166  add rsp, 0x30
000076cd267da16a  vmovaps xmm0, [rsp]
000076cd267da16f  vmovaps xmm1, [rsp+0x10]
000076cd267da175  vmovaps xmm2, [rsp+0x20]
000076cd267da17b  vmovaps xmm3, [rsp+0x30]
000076cd267da181  vmovaps xmm4, [rsp+0x40]
000076cd267da187  vmovaps xmm5, [rsp+0x50]
000076cd267da18d  vmovaps xmm6, [rsp+0x60]
000076cd267da193  vmovaps xmm7, [rsp+0x70]
000076cd267da199  vmovaps xmm8, [rsp+0x80]
000076cd267da1a2  vmovaps xmm9, [rsp+0x90]
000076cd267da1ab  vmovaps xmm10, [rsp+0xA0]
000076cd267da1b4  vmovaps xmm11, [rsp+0xB0]
000076cd267da1bd  vmovaps xmm12, [rsp+0xC0]
000076cd267da1c6  vmovaps xmm13, [rsp+0xD0]
000076cd267da1cf  vmovaps xmm15, [rsp+0xE0]
000076cd267da1d8  add rsp, 0xF0
000076cd267da1df  pop r11
000076cd267da1e1  pop r10
000076cd267da1e3  pop r9
000076cd267da1e5  pop r8
000076cd267da1e7  pop rsi
000076cd267da1e8  pop rdi
000076cd267da1e9  pop rdx
000076cd267da1ea  pop rcx
000076cd267da1eb  pop rax
000076cd267da1ec  add rsp, 0x08
000076cd267da1f0  jmp 0x000076CD267D6400
000076cd267da1f5  sub rsp, 0x08
000076cd267da1f9  push rax
000076cd267da1fa  push rcx
000076cd267da1fb  push rdx
000076cd267da1fc  push rdi
000076cd267da1fd  push rsi
000076cd267da1fe  push r8
000076cd267da200  push r9
000076cd267da202  push r10
000076cd267da204  push r11
000076cd267da206  sub rsp, 0xF0
000076cd267da20d  vmovaps [rsp], xmm0
000076cd267da212  vmovaps [rsp+0x10], xmm2
000076cd267da218  vmovaps [rsp+0x20], xmm3
000076cd267da21e  vmovaps [rsp+0x30], xmm4
000076cd267da224  vmovaps [rsp+0x40], xmm5
000076cd267da22a  vmovaps [rsp+0x50], xmm6
000076cd267da230  vmovaps [rsp+0x60], xmm7
000076cd267da236  vmovaps [rsp+0x70], xmm8
000076cd267da23c  vmovaps [rsp+0x80], xmm9
000076cd267da245  vmovaps [rsp+0x90], xmm10
000076cd267da24e  vmovaps [rsp+0xA0], xmm11
000076cd267da257  vmovaps [rsp+0xB0], xmm12
000076cd267da260  vmovaps [rsp+0xC0], xmm13
000076cd267da269  vmovaps [rsp+0xD0], xmm14
000076cd267da272  vmovaps [rsp+0xE0], xmm15
000076cd267da27b  sub rsp, 0x30
000076cd267da27f  movaps [rsp], xmm1
000076cd267da283  movaps [rsp+0x10], xmm13
000076cd267da289  movaps [rsp+0x20], xmm9
000076cd267da28f  lea rdi, [rsp]
000076cd267da293  mov esi, 0x00
000076cd267da298  mov rax, 0x56B8861A9530
000076cd267da2a2  call rax
000076cd267da2a4  movaps xmm1, [rsp]
000076cd267da2a8  add rsp, 0x30
000076cd267da2ac  vmovaps xmm0, [rsp]
000076cd267da2b1  vmovaps xmm2, [rsp+0x10]
000076cd267da2b7  vmovaps xmm3, [rsp+0x20]
000076cd267da2bd  vmovaps xmm4, [rsp+0x30]
000076cd267da2c3  vmovaps xmm5, [rsp+0x40]
000076cd267da2c9  vmovaps xmm6, [rsp+0x50]
000076cd267da2cf  vmovaps xmm7, [rsp+0x60]
000076cd267da2d5  vmovaps xmm8, [rsp+0x70]
000076cd267da2db  vmovaps xmm9, [rsp+0x80]
000076cd267da2e4  vmovaps xmm10, [rsp+0x90]
000076cd267da2ed  vmovaps xmm11, [rsp+0xA0]
000076cd267da2f6  vmovaps xmm12, [rsp+0xB0]
000076cd267da2ff  vmovaps xmm13, [rsp+0xC0]
000076cd267da308  vmovaps xmm14, [rsp+0xD0]
000076cd267da311  vmovaps xmm15, [rsp+0xE0]
000076cd267da31a  add rsp, 0xF0
000076cd267da321  pop r11
000076cd267da323  pop r10
000076cd267da325  pop r9
000076cd267da327  pop r8
000076cd267da329  pop rsi
000076cd267da32a  pop rdi
000076cd267da32b  pop rdx
000076cd267da32c  pop rcx
000076cd267da32d  pop rax
000076cd267da32e  add rsp, 0x08
000076cd267da332  jmp 0x000076CD267D641A
000076cd267da337  sub rsp, 0x08
000076cd267da33b  push rax
000076cd267da33c  push rcx
000076cd267da33d  push rdx
000076cd267da33e  push rdi
000076cd267da33f  push rsi
000076cd267da340  push r8
000076cd267da342  push r9
000076cd267da344  push r10
000076cd267da346  push r11
000076cd267da348  sub rsp, 0xF0
000076cd267da34f  vmovaps [rsp], xmm0
000076cd267da354  vmovaps [rsp+0x10], xmm1
000076cd267da35a  vmovaps [rsp+0x20], xmm2
000076cd267da360  vmovaps [rsp+0x30], xmm3
000076cd267da366  vmovaps [rsp+0x40], xmm4
000076cd267da36c  vmovaps [rsp+0x50], xmm5
000076cd267da372  vmovaps [rsp+0x60], xmm6
000076cd267da378  vmovaps [rsp+0x70], xmm7
000076cd267da37e  vmovaps [rsp+0x80], xmm8
000076cd267da387  vmovaps [rsp+0x90], xmm9
000076cd267da390  vmovaps [rsp+0xA0], xmm10
000076cd267da399  vmovaps [rsp+0xB0], xmm11
000076cd267da3a2  vmovaps [rsp+0xC0], xmm13
000076cd267da3ab  vmovaps [rsp+0xD0], xmm14
000076cd267da3b4  vmovaps [rsp+0xE0], xmm15
000076cd267da3bd  sub rsp, 0x30
000076cd267da3c1  movaps [rsp], xmm12
000076cd267da3c6  movaps [rsp+0x10], xmm7
000076cd267da3cb  movaps [rsp+0x20], xmm13
000076cd267da3d1  lea rdi, [rsp]
000076cd267da3d5  mov esi, 0x00
000076cd267da3da  mov rax, 0x56B8861A9530
000076cd267da3e4  call rax
000076cd267da3e6  movaps xmm12, [rsp]
000076cd267da3eb  add rsp, 0x30
000076cd267da3ef  vmovaps xmm0, [rsp]
000076cd267da3f4  vmovaps xmm1, [rsp+0x10]
000076cd267da3fa  vmovaps xmm2, [rsp+0x20]
000076cd267da400  vmovaps xmm3, [rsp+0x30]
000076cd267da406  vmovaps xmm4, [rsp+0x40]
000076cd267da40c  vmovaps xmm5, [rsp+0x50]
000076cd267da412  vmovaps xmm6, [rsp+0x60]
000076cd267da418  vmovaps xmm7, [rsp+0x70]
000076cd267da41e  vmovaps xmm8, [rsp+0x80]
000076cd267da427  vmovaps xmm9, [rsp+0x90]
000076cd267da430  vmovaps xmm10, [rsp+0xA0]
000076cd267da439  vmovaps xmm11, [rsp+0xB0]
000076cd267da442  vmovaps xmm13, [rsp+0xC0]
000076cd267da44b  vmovaps xmm14, [rsp+0xD0]
000076cd267da454  vmovaps xmm15, [rsp+0xE0]
000076cd267da45d  add rsp, 0xF0
000076cd267da464  pop r11
000076cd267da466  pop r10
000076cd267da468  pop r9
000076cd267da46a  pop r8
000076cd267da46c  pop rsi
000076cd267da46d  pop rdi
000076cd267da46e  pop rdx
000076cd267da46f  pop rcx
000076cd267da470  pop rax
000076cd267da471  add rsp, 0x08
000076cd267da475  jmp 0x000076CD267D6441
000076cd267da47a  sub rsp, 0x08
000076cd267da47e  push rax
000076cd267da47f  push rcx
000076cd267da480  push rdx
000076cd267da481  push rdi
000076cd267da482  push rsi
000076cd267da483  push r8
000076cd267da485  push r9
000076cd267da487  push r10
000076cd267da489  push r11
000076cd267da48b  sub rsp, 0xF0
000076cd267da492  vmovaps [rsp], xmm0
000076cd267da497  vmovaps [rsp+0x10], xmm1
000076cd267da49d  vmovaps [rsp+0x20], xmm2
000076cd267da4a3  vmovaps [rsp+0x30], xmm3
000076cd267da4a9  vmovaps [rsp+0x40], xmm4
000076cd267da4af  vmovaps [rsp+0x50], xmm5
000076cd267da4b5  vmovaps [rsp+0x60], xmm6
000076cd267da4bb  vmovaps [rsp+0x70], xmm7
000076cd267da4c1  vmovaps [rsp+0x80], xmm8
000076cd267da4ca  vmovaps [rsp+0x90], xmm9
000076cd267da4d3  vmovaps [rsp+0xA0], xmm10
000076cd267da4dc  vmovaps [rsp+0xB0], xmm11
000076cd267da4e5  vmovaps [rsp+0xC0], xmm12
000076cd267da4ee  vmovaps [rsp+0xD0], xmm14
000076cd267da4f7  vmovaps [rsp+0xE0], xmm15
000076cd267da500  sub rsp, 0x30
000076cd267da504  movaps [rsp], xmm13
000076cd267da509  movaps [rsp+0x10], xmm15
000076cd267da50f  movaps [rsp+0x20], xmm8
000076cd267da515  lea rdi, [rsp]
000076cd267da519  mov esi, 0x00
000076cd267da51e  mov rax, 0x56B8861A9530
000076cd267da528  call rax
000076cd267da52a  movaps xmm13, [rsp]
000076cd267da52f  add rsp, 0x30
000076cd267da533  vmovaps xmm0, [rsp]
000076cd267da538  vmovaps xmm1, [rsp+0x10]
000076cd267da53e  vmovaps xmm2, [rsp+0x20]
000076cd267da544  vmovaps xmm3, [rsp+0x30]
000076cd267da54a  vmovaps xmm4, [rsp+0x40]
000076cd267da550  vmovaps xmm5, [rsp+0x50]
000076cd267da556  vmovaps xmm6, [rsp+0x60]
000076cd267da55c  vmovaps xmm7, [rsp+0x70]
000076cd267da562  vmovaps xmm8, [rsp+0x80]
000076cd267da56b  vmovaps xmm9, [rsp+0x90]
000076cd267da574  vmovaps xmm10, [rsp+0xA0]
000076cd267da57d  vmovaps xmm11, [rsp+0xB0]
000076cd267da586  vmovaps xmm12, [rsp+0xC0]
000076cd267da58f  vmovaps xmm14, [rsp+0xD0]
000076cd267da598  vmovaps xmm15, [rsp+0xE0]
000076cd267da5a1  add rsp, 0xF0
000076cd267da5a8  pop r11
000076cd267da5aa  pop r10
000076cd267da5ac  pop r9
000076cd267da5ae  pop r8
000076cd267da5b0  pop rsi
000076cd267da5b1  pop rdi
000076cd267da5b2  pop rdx
000076cd267da5b3  pop rcx
000076cd267da5b4  pop rax
000076cd267da5b5  add rsp, 0x08
000076cd267da5b9  jmp 0x000076CD267D645C
000076cd267da5be  sub rsp, 0x08
000076cd267da5c2  push rax
000076cd267da5c3  push rcx
000076cd267da5c4  push rdx
000076cd267da5c5  push rdi
000076cd267da5c6  push rsi
000076cd267da5c7  push r8
000076cd267da5c9  push r9
000076cd267da5cb  push r10
000076cd267da5cd  push r11
000076cd267da5cf  sub rsp, 0xF0
000076cd267da5d6  vmovaps [rsp], xmm0
000076cd267da5db  vmovaps [rsp+0x10], xmm1
000076cd267da5e1  vmovaps [rsp+0x20], xmm2
000076cd267da5e7  vmovaps [rsp+0x30], xmm3
000076cd267da5ed  vmovaps [rsp+0x40], xmm4
000076cd267da5f3  vmovaps [rsp+0x50], xmm5
000076cd267da5f9  vmovaps [rsp+0x60], xmm6
000076cd267da5ff  vmovaps [rsp+0x70], xmm7
000076cd267da605  vmovaps [rsp+0x80], xmm9
000076cd267da60e  vmovaps [rsp+0x90], xmm10
000076cd267da617  vmovaps [rsp+0xA0], xmm11
000076cd267da620  vmovaps [rsp+0xB0], xmm12
000076cd267da629  vmovaps [rsp+0xC0], xmm13
000076cd267da632  vmovaps [rsp+0xD0], xmm14
000076cd267da63b  vmovaps [rsp+0xE0], xmm15
000076cd267da644  sub rsp, 0x30
000076cd267da648  movaps [rsp], xmm8
000076cd267da64d  movaps [rsp+0x10], xmm15
000076cd267da653  movaps [rsp+0x20], xmm9
000076cd267da659  lea rdi, [rsp]
000076cd267da65d  mov esi, 0x00
000076cd267da662  mov rax, 0x56B8861A9530
000076cd267da66c  call rax
000076cd267da66e  movaps xmm8, [rsp]
000076cd267da673  add rsp, 0x30
000076cd267da677  vmovaps xmm0, [rsp]
000076cd267da67c  vmovaps xmm1, [rsp+0x10]
000076cd267da682  vmovaps xmm2, [rsp+0x20]
000076cd267da688  vmovaps xmm3, [rsp+0x30]
000076cd267da68e  vmovaps xmm4, [rsp+0x40]
000076cd267da694  vmovaps xmm5, [rsp+0x50]
000076cd267da69a  vmovaps xmm6, [rsp+0x60]
000076cd267da6a0  vmovaps xmm7, [rsp+0x70]
000076cd267da6a6  vmovaps xmm9, [rsp+0x80]
000076cd267da6af  vmovaps xmm10, [rsp+0x90]
000076cd267da6b8  vmovaps xmm11, [rsp+0xA0]
000076cd267da6c1  vmovaps xmm12, [rsp+0xB0]
000076cd267da6ca  vmovaps xmm13, [rsp+0xC0]
000076cd267da6d3  vmovaps xmm14, [rsp+0xD0]
000076cd267da6dc  vmovaps xmm15, [rsp+0xE0]
000076cd267da6e5  add rsp, 0xF0
000076cd267da6ec  pop r11
000076cd267da6ee  pop r10
000076cd267da6f0  pop r9
000076cd267da6f2  pop r8
000076cd267da6f4  pop rsi
000076cd267da6f5  pop rdi
000076cd267da6f6  pop rdx
000076cd267da6f7  pop rcx
000076cd267da6f8  pop rax
000076cd267da6f9  add rsp, 0x08
000076cd267da6fd  jmp 0x000076CD267D648A
000076cd267da702  sub rsp, 0x08
000076cd267da706  push rax
000076cd267da707  push rcx
000076cd267da708  push rdx
000076cd267da709  push rdi
000076cd267da70a  push rsi
000076cd267da70b  push r8
000076cd267da70d  push r9
000076cd267da70f  push r10
000076cd267da711  push r11
000076cd267da713  sub rsp, 0xF0
000076cd267da71a  vmovaps [rsp], xmm0
000076cd267da71f  vmovaps [rsp+0x10], xmm1
000076cd267da725  vmovaps [rsp+0x20], xmm2
000076cd267da72b  vmovaps [rsp+0x30], xmm3
000076cd267da731  vmovaps [rsp+0x40], xmm4
000076cd267da737  vmovaps [rsp+0x50], xmm5
000076cd267da73d  vmovaps [rsp+0x60], xmm6
000076cd267da743  vmovaps [rsp+0x70], xmm7
000076cd267da749  vmovaps [rsp+0x80], xmm8
000076cd267da752  vmovaps [rsp+0x90], xmm9
000076cd267da75b  vmovaps [rsp+0xA0], xmm10
000076cd267da764  vmovaps [rsp+0xB0], xmm11
000076cd267da76d  vmovaps [rsp+0xC0], xmm12
000076cd267da776  vmovaps [rsp+0xD0], xmm13
000076cd267da77f  vmovaps [rsp+0xE0], xmm14
000076cd267da788  sub rsp, 0x30
000076cd267da78c  movaps [rsp], xmm15
000076cd267da791  movaps [rsp+0x10], xmm11
000076cd267da797  movaps [rsp+0x20], xmm6
000076cd267da79c  lea rdi, [rsp]
000076cd267da7a0  mov esi, 0x00
000076cd267da7a5  mov rax, 0x56B8861A9530
000076cd267da7af  call rax
000076cd267da7b1  movaps xmm15, [rsp]
000076cd267da7b6  add rsp, 0x30
000076cd267da7ba  vmovaps xmm0, [rsp]
000076cd267da7bf  vmovaps xmm1, [rsp+0x10]
000076cd267da7c5  vmovaps xmm2, [rsp+0x20]
000076cd267da7cb  vmovaps xmm3, [rsp+0x30]
000076cd267da7d1  vmovaps xmm4, [rsp+0x40]
000076cd267da7d7  vmovaps xmm5, [rsp+0x50]
000076cd267da7dd  vmovaps xmm6, [rsp+0x60]
000076cd267da7e3  vmovaps xmm7, [rsp+0x70]
000076cd267da7e9  vmovaps xmm8, [rsp+0x80]
000076cd267da7f2  vmovaps xmm9, [rsp+0x90]
000076cd267da7fb  vmovaps xmm10, [rsp+0xA0]
000076cd267da804  vmovaps xmm11, [rsp+0xB0]
000076cd267da80d  vmovaps xmm12, [rsp+0xC0]
000076cd267da816  vmovaps xmm13, [rsp+0xD0]
000076cd267da81f  vmovaps xmm14, [rsp+0xE0]
000076cd267da828  add rsp, 0xF0
000076cd267da82f  pop r11
000076cd267da831  pop r10
000076cd267da833  pop r9
000076cd267da835  pop r8
000076cd267da837  pop rsi
000076cd267da838  pop rdi
000076cd267da839  pop rdx
000076cd267da83a  pop rcx
000076cd267da83b  pop rax
000076cd267da83c  add rsp, 0x08
000076cd267da840  jmp 0x000076CD267D64A5
000076cd267da845  sub rsp, 0x08
000076cd267da849  push rax
000076cd267da84a  push rcx
000076cd267da84b  push rdx
000076cd267da84c  push rdi
000076cd267da84d  push rsi
000076cd267da84e  push r8
000076cd267da850  push r9
000076cd267da852  push r10
000076cd267da854  push r11
000076cd267da856  sub rsp, 0xF0
000076cd267da85d  vmovaps [rsp], xmm0
000076cd267da862  vmovaps [rsp+0x10], xmm1
000076cd267da868  vmovaps [rsp+0x20], xmm2
000076cd267da86e  vmovaps [rsp+0x30], xmm3
000076cd267da874  vmovaps [rsp+0x40], xmm4
000076cd267da87a  vmovaps [rsp+0x50], xmm5
000076cd267da880  vmovaps [rsp+0x60], xmm6
000076cd267da886  vmovaps [rsp+0x70], xmm8
000076cd267da88c  vmovaps [rsp+0x80], xmm9
000076cd267da895  vmovaps [rsp+0x90], xmm10
000076cd267da89e  vmovaps [rsp+0xA0], xmm11
000076cd267da8a7  vmovaps [rsp+0xB0], xmm12
000076cd267da8b0  vmovaps [rsp+0xC0], xmm13
000076cd267da8b9  vmovaps [rsp+0xD0], xmm14
000076cd267da8c2  vmovaps [rsp+0xE0], xmm15
000076cd267da8cb  sub rsp, 0x30
000076cd267da8cf  movaps [rsp], xmm7
000076cd267da8d3  movaps [rsp+0x10], xmm11
000076cd267da8d9  movaps [rsp+0x20], xmm9
000076cd267da8df  lea rdi, [rsp]
000076cd267da8e3  mov esi, 0x00
000076cd267da8e8  mov rax, 0x56B8861A9530
000076cd267da8f2  call rax
000076cd267da8f4  movaps xmm7, [rsp]
000076cd267da8f8  add rsp, 0x30
000076cd267da8fc  vmovaps xmm0, [rsp]
000076cd267da901  vmovaps xmm1, [rsp+0x10]
000076cd267da907  vmovaps xmm2, [rsp+0x20]
000076cd267da90d  vmovaps xmm3, [rsp+0x30]
000076cd267da913  vmovaps xmm4, [rsp+0x40]
000076cd267da919  vmovaps xmm5, [rsp+0x50]
000076cd267da91f  vmovaps xmm6, [rsp+0x60]
000076cd267da925  vmovaps xmm8, [rsp+0x70]
000076cd267da92b  vmovaps xmm9, [rsp+0x80]
000076cd267da934  vmovaps xmm10, [rsp+0x90]
000076cd267da93d  vmovaps xmm11, [rsp+0xA0]
000076cd267da946  vmovaps xmm12, [rsp+0xB0]
000076cd267da94f  vmovaps xmm13, [rsp+0xC0]
000076cd267da958  vmovaps xmm14, [rsp+0xD0]
000076cd267da961  vmovaps xmm15, [rsp+0xE0]
000076cd267da96a  add rsp, 0xF0
000076cd267da971  pop r11
000076cd267da973  pop r10
000076cd267da975  pop r9
000076cd267da977  pop r8
000076cd267da979  pop rsi
000076cd267da97a  pop rdi
000076cd267da97b  pop rdx
000076cd267da97c  pop rcx
000076cd267da97d  pop rax
000076cd267da97e  add rsp, 0x08
000076cd267da982  jmp 0x000076CD267D64D2
000076cd267da987  sub rsp, 0x08
000076cd267da98b  push rax
000076cd267da98c  push rcx
000076cd267da98d  push rdx
000076cd267da98e  push rdi
000076cd267da98f  push rsi
000076cd267da990  push r8
000076cd267da992  push r9
000076cd267da994  push r10
000076cd267da996  push r11
000076cd267da998  sub rsp, 0xF0
000076cd267da99f  vmovaps [rsp], xmm0
000076cd267da9a4  vmovaps [rsp+0x10], xmm1
000076cd267da9aa  vmovaps [rsp+0x20], xmm2
000076cd267da9b0  vmovaps [rsp+0x30], xmm3
000076cd267da9b6  vmovaps [rsp+0x40], xmm4
000076cd267da9bc  vmovaps [rsp+0x50], xmm5
000076cd267da9c2  vmovaps [rsp+0x60], xmm6
000076cd267da9c8  vmovaps [rsp+0x70], xmm7
000076cd267da9ce  vmovaps [rsp+0x80], xmm8
000076cd267da9d7  vmovaps [rsp+0x90], xmm9
000076cd267da9e0  vmovaps [rsp+0xA0], xmm10
000076cd267da9e9  vmovaps [rsp+0xB0], xmm12
000076cd267da9f2  vmovaps [rsp+0xC0], xmm13
000076cd267da9fb  vmovaps [rsp+0xD0], xmm14
000076cd267daa04  vmovaps [rsp+0xE0], xmm15
000076cd267daa0d  sub rsp, 0x30
000076cd267daa11  movaps [rsp], xmm11
000076cd267daa16  movaps [rsp+0x10], xmm10
000076cd267daa1c  movaps [rsp+0x20], xmm14
000076cd267daa22  lea rdi, [rsp]
000076cd267daa26  mov esi, 0x00
000076cd267daa2b  mov rax, 0x56B8861A9530
000076cd267daa35  call rax
000076cd267daa37  movaps xmm11, [rsp]
000076cd267daa3c  add rsp, 0x30
000076cd267daa40  vmovaps xmm0, [rsp]
000076cd267daa45  vmovaps xmm1, [rsp+0x10]
000076cd267daa4b  vmovaps xmm2, [rsp+0x20]
000076cd267daa51  vmovaps xmm3, [rsp+0x30]
000076cd267daa57  vmovaps xmm4, [rsp+0x40]
000076cd267daa5d  vmovaps xmm5, [rsp+0x50]
000076cd267daa63  vmovaps xmm6, [rsp+0x60]
000076cd267daa69  vmovaps xmm7, [rsp+0x70]
000076cd267daa6f  vmovaps xmm8, [rsp+0x80]
000076cd267daa78  vmovaps xmm9, [rsp+0x90]
000076cd267daa81  vmovaps xmm10, [rsp+0xA0]
000076cd267daa8a  vmovaps xmm12, [rsp+0xB0]
000076cd267daa93  vmovaps xmm13, [rsp+0xC0]
000076cd267daa9c  vmovaps xmm14, [rsp+0xD0]
000076cd267daaa5  vmovaps xmm15, [rsp+0xE0]
000076cd267daaae  add rsp, 0xF0
000076cd267daab5  pop r11
000076cd267daab7  pop r10
000076cd267daab9  pop r9
000076cd267daabb  pop r8
000076cd267daabd  pop rsi
000076cd267daabe  pop rdi
000076cd267daabf  pop rdx
000076cd267daac0  pop rcx
000076cd267daac1  pop rax
000076cd267daac2  add rsp, 0x08
000076cd267daac6  jmp 0x000076CD267D64ED
000076cd267daacb  call 0x000076CD266E45A0
000076cd267daad0  jmp 0x000076CD267D64F7
000076cd267daad5  sub rsp, 0x08
000076cd267daad9  push rax
000076cd267daada  push rcx
000076cd267daadb  push rdx
000076cd267daadc  push rdi
000076cd267daadd  push rsi
000076cd267daade  push r8
000076cd267daae0  push r9
000076cd267daae2  push r10
000076cd267daae4  push r11
000076cd267daae6  sub rsp, 0xF0
000076cd267daaed  vmovaps [rsp], xmm0
000076cd267daaf2  vmovaps [rsp+0x10], xmm1
000076cd267daaf8  vmovaps [rsp+0x20], xmm2
000076cd267daafe  vmovaps [rsp+0x30], xmm3
000076cd267dab04  vmovaps [rsp+0x40], xmm4
000076cd267dab0a  vmovaps [rsp+0x50], xmm5
000076cd267dab10  vmovaps [rsp+0x60], xmm6
000076cd267dab16  vmovaps [rsp+0x70], xmm7
000076cd267dab1c  vmovaps [rsp+0x80], xmm8
000076cd267dab25  vmovaps [rsp+0x90], xmm9
000076cd267dab2e  vmovaps [rsp+0xA0], xmm11
000076cd267dab37  vmovaps [rsp+0xB0], xmm12
000076cd267dab40  vmovaps [rsp+0xC0], xmm13
000076cd267dab49  vmovaps [rsp+0xD0], xmm14
000076cd267dab52  vmovaps [rsp+0xE0], xmm15
000076cd267dab5b  sub rsp, 0x30
000076cd267dab5f  movaps [rsp], xmm10
000076cd267dab64  movaps [rsp+0x10], xmm1
000076cd267dab69  movaps [rsp+0x20], xmm12
000076cd267dab6f  lea rdi, [rsp]
000076cd267dab73  mov esi, 0x00
000076cd267dab78  mov rax, 0x56B8861A9530
000076cd267dab82  call rax
000076cd267dab84  movaps xmm10, [rsp]
000076cd267dab89  add rsp, 0x30
000076cd267dab8d  vmovaps xmm0, [rsp]
000076cd267dab92  vmovaps xmm1, [rsp+0x10]
000076cd267dab98  vmovaps xmm2, [rsp+0x20]
000076cd267dab9e  vmovaps xmm3, [rsp+0x30]
000076cd267daba4  vmovaps xmm4, [rsp+0x40]
000076cd267dabaa  vmovaps xmm5, [rsp+0x50]
000076cd267dabb0  vmovaps xmm6, [rsp+0x60]
000076cd267dabb6  vmovaps xmm7, [rsp+0x70]
000076cd267dabbc  vmovaps xmm8, [rsp+0x80]
000076cd267dabc5  vmovaps xmm9, [rsp+0x90]
000076cd267dabce  vmovaps xmm11, [rsp+0xA0]
000076cd267dabd7  vmovaps xmm12, [rsp+0xB0]
000076cd267dabe0  vmovaps xmm13, [rsp+0xC0]
000076cd267dabe9  vmovaps xmm14, [rsp+0xD0]
000076cd267dabf2  vmovaps xmm15, [rsp+0xE0]
000076cd267dabfb  add rsp, 0xF0
000076cd267dac02  pop r11
000076cd267dac04  pop r10
000076cd267dac06  pop r9
000076cd267dac08  pop r8
000076cd267dac0a  pop rsi
000076cd267dac0b  pop rdi
000076cd267dac0c  pop rdx
000076cd267dac0d  pop rcx
000076cd267dac0e  pop rax
000076cd267dac0f  add rsp, 0x08
000076cd267dac13  jmp 0x000076CD267D651A
000076cd267dac18  sub rsp, 0x08
000076cd267dac1c  push rax
000076cd267dac1d  push rcx
000076cd267dac1e  push rdx
000076cd267dac1f  push rdi
000076cd267dac20  push rsi
000076cd267dac21  push r8
000076cd267dac23  push r9
000076cd267dac25  push r10
000076cd267dac27  push r11
000076cd267dac29  sub rsp, 0xF0
000076cd267dac30  vmovaps [rsp], xmm0
000076cd267dac35  vmovaps [rsp+0x10], xmm1
000076cd267dac3b  vmovaps [rsp+0x20], xmm2
000076cd267dac41  vmovaps [rsp+0x30], xmm3
000076cd267dac47  vmovaps [rsp+0x40], xmm4
000076cd267dac4d  vmovaps [rsp+0x50], xmm5
000076cd267dac53  vmovaps [rsp+0x60], xmm6
000076cd267dac59  vmovaps [rsp+0x70], xmm7
000076cd267dac5f  vmovaps [rsp+0x80], xmm8
000076cd267dac68  vmovaps [rsp+0x90], xmm9
000076cd267dac71  vmovaps [rsp+0xA0], xmm10
000076cd267dac7a  vmovaps [rsp+0xB0], xmm11
000076cd267dac83  vmovaps [rsp+0xC0], xmm13
000076cd267dac8c  vmovaps [rsp+0xD0], xmm14
000076cd267dac95  vmovaps [rsp+0xE0], xmm15
000076cd267dac9e  sub rsp, 0x30
000076cd267daca2  movaps [rsp], xmm12
000076cd267daca7  movaps [rsp+0x10], xmm14
000076cd267dacad  movaps [rsp+0x20], xmm1
000076cd267dacb2  lea rdi, [rsp]
000076cd267dacb6  mov esi, 0x00
000076cd267dacbb  mov rax, 0x56B8861A9530
000076cd267dacc5  call rax
000076cd267dacc7  movaps xmm12, [rsp]
000076cd267daccc  add rsp, 0x30
000076cd267dacd0  vmovaps xmm0, [rsp]
000076cd267dacd5  vmovaps xmm1, [rsp+0x10]
000076cd267dacdb  vmovaps xmm2, [rsp+0x20]
000076cd267dace1  vmovaps xmm3, [rsp+0x30]
000076cd267dace7  vmovaps xmm4, [rsp+0x40]
000076cd267daced  vmovaps xmm5, [rsp+0x50]
000076cd267dacf3  vmovaps xmm6, [rsp+0x60]
000076cd267dacf9  vmovaps xmm7, [rsp+0x70]
000076cd267dacff  vmovaps xmm8, [rsp+0x80]
000076cd267dad08  vmovaps xmm9, [rsp+0x90]
000076cd267dad11  vmovaps xmm10, [rsp+0xA0]
000076cd267dad1a  vmovaps xmm11, [rsp+0xB0]
000076cd267dad23  vmovaps xmm13, [rsp+0xC0]
000076cd267dad2c  vmovaps xmm14, [rsp+0xD0]
000076cd267dad35  vmovaps xmm15, [rsp+0xE0]
000076cd267dad3e  add rsp, 0xF0
000076cd267dad45  pop r11
000076cd267dad47  pop r10
000076cd267dad49  pop r9
000076cd267dad4b  pop r8
000076cd267dad4d  pop rsi
000076cd267dad4e  pop rdi
000076cd267dad4f  pop rdx
000076cd267dad50  pop rcx
000076cd267dad51  pop rax
000076cd267dad52  add rsp, 0x08
000076cd267dad56  jmp 0x000076CD267D6549
000076cd267dad5b  sub rsp, 0x08
000076cd267dad5f  push rax
000076cd267dad60  push rcx
000076cd267dad61  push rdx
000076cd267dad62  push rdi
000076cd267dad63  push rsi
000076cd267dad64  push r8
000076cd267dad66  push r9
000076cd267dad68  push r10
000076cd267dad6a  push r11
000076cd267dad6c  sub rsp, 0xF0
000076cd267dad73  vmovaps [rsp], xmm0
000076cd267dad78  vmovaps [rsp+0x10], xmm1
000076cd267dad7e  vmovaps [rsp+0x20], xmm2
000076cd267dad84  vmovaps [rsp+0x30], xmm3
000076cd267dad8a  vmovaps [rsp+0x40], xmm4
000076cd267dad90  vmovaps [rsp+0x50], xmm5
000076cd267dad96  vmovaps [rsp+0x60], xmm6
000076cd267dad9c  vmovaps [rsp+0x70], xmm7
000076cd267dada2  vmovaps [rsp+0x80], xmm8
000076cd267dadab  vmovaps [rsp+0x90], xmm9
000076cd267dadb4  vmovaps [rsp+0xA0], xmm10
000076cd267dadbd  vmovaps [rsp+0xB0], xmm11
000076cd267dadc6  vmovaps [rsp+0xC0], xmm12
000076cd267dadcf  vmovaps [rsp+0xD0], xmm13
000076cd267dadd8  vmovaps [rsp+0xE0], xmm15
000076cd267dade1  sub rsp, 0x30
000076cd267dade5  movaps [rsp], xmm14
000076cd267dadea  movaps [rsp+0x10], xmm9
000076cd267dadf0  movaps [rsp+0x20], xmm1
000076cd267dadf5  lea rdi, [rsp]
000076cd267dadf9  mov esi, 0x00
000076cd267dadfe  mov rax, 0x56B8861A9530
000076cd267dae08  call rax
000076cd267dae0a  movaps xmm14, [rsp]
000076cd267dae0f  add rsp, 0x30
000076cd267dae13  vmovaps xmm0, [rsp]
000076cd267dae18  vmovaps xmm1, [rsp+0x10]
000076cd267dae1e  vmovaps xmm2, [rsp+0x20]
000076cd267dae24  vmovaps xmm3, [rsp+0x30]
000076cd267dae2a  vmovaps xmm4, [rsp+0x40]
000076cd267dae30  vmovaps xmm5, [rsp+0x50]
000076cd267dae36  vmovaps xmm6, [rsp+0x60]
000076cd267dae3c  vmovaps xmm7, [rsp+0x70]
000076cd267dae42  vmovaps xmm8, [rsp+0x80]
000076cd267dae4b  vmovaps xmm9, [rsp+0x90]
000076cd267dae54  vmovaps xmm10, [rsp+0xA0]
000076cd267dae5d  vmovaps xmm11, [rsp+0xB0]
000076cd267dae66  vmovaps xmm12, [rsp+0xC0]
000076cd267dae6f  vmovaps xmm13, [rsp+0xD0]
000076cd267dae78  vmovaps xmm15, [rsp+0xE0]
000076cd267dae81  add rsp, 0xF0
000076cd267dae88  pop r11
000076cd267dae8a  pop r10
000076cd267dae8c  pop r9
000076cd267dae8e  pop r8
000076cd267dae90  pop rsi
000076cd267dae91  pop rdi
000076cd267dae92  pop rdx
000076cd267dae93  pop rcx
000076cd267dae94  pop rax
000076cd267dae95  add rsp, 0x08
000076cd267dae99  jmp 0x000076CD267D6578
000076cd267dae9e  sub rsp, 0x08
000076cd267daea2  push rax
000076cd267daea3  push rcx
000076cd267daea4  push rdx
000076cd267daea5  push rdi
000076cd267daea6  push rsi
000076cd267daea7  push r8
000076cd267daea9  push r9
000076cd267daeab  push r10
000076cd267daead  push r11
000076cd267daeaf  sub rsp, 0xF0
000076cd267daeb6  vmovaps [rsp], xmm0
000076cd267daebb  vmovaps [rsp+0x10], xmm2
000076cd267daec1  vmovaps [rsp+0x20], xmm3
000076cd267daec7  vmovaps [rsp+0x30], xmm4
000076cd267daecd  vmovaps [rsp+0x40], xmm5
000076cd267daed3  vmovaps [rsp+0x50], xmm6
000076cd267daed9  vmovaps [rsp+0x60], xmm7
000076cd267daedf  vmovaps [rsp+0x70], xmm8
000076cd267daee5  vmovaps [rsp+0x80], xmm9
000076cd267daeee  vmovaps [rsp+0x90], xmm10
000076cd267daef7  vmovaps [rsp+0xA0], xmm11
000076cd267daf00  vmovaps [rsp+0xB0], xmm12
000076cd267daf09  vmovaps [rsp+0xC0], xmm13
000076cd267daf12  vmovaps [rsp+0xD0], xmm14
000076cd267daf1b  vmovaps [rsp+0xE0], xmm15
000076cd267daf24  sub rsp, 0x30
000076cd267daf28  movaps [rsp], xmm1
000076cd267daf2c  movaps [rsp+0x10], xmm13
000076cd267daf32  movaps [rsp+0x20], xmm8
000076cd267daf38  lea rdi, [rsp]
000076cd267daf3c  mov esi, 0x00
000076cd267daf41  mov rax, 0x56B8861A9530
000076cd267daf4b  call rax
000076cd267daf4d  movaps xmm1, [rsp]
000076cd267daf51  add rsp, 0x30
000076cd267daf55  vmovaps xmm0, [rsp]
000076cd267daf5a  vmovaps xmm2, [rsp+0x10]
000076cd267daf60  vmovaps xmm3, [rsp+0x20]
000076cd267daf66  vmovaps xmm4, [rsp+0x30]
000076cd267daf6c  vmovaps xmm5, [rsp+0x40]
000076cd267daf72  vmovaps xmm6, [rsp+0x50]
000076cd267daf78  vmovaps xmm7, [rsp+0x60]
000076cd267daf7e  vmovaps xmm8, [rsp+0x70]
000076cd267daf84  vmovaps xmm9, [rsp+0x80]
000076cd267daf8d  vmovaps xmm10, [rsp+0x90]
000076cd267daf96  vmovaps xmm11, [rsp+0xA0]
000076cd267daf9f  vmovaps xmm12, [rsp+0xB0]
000076cd267dafa8  vmovaps xmm13, [rsp+0xC0]
000076cd267dafb1  vmovaps xmm14, [rsp+0xD0]
000076cd267dafba  vmovaps xmm15, [rsp+0xE0]
000076cd267dafc3  add rsp, 0xF0
000076cd267dafca  pop r11
000076cd267dafcc  pop r10
000076cd267dafce  pop r9
000076cd267dafd0  pop r8
000076cd267dafd2  pop rsi
000076cd267dafd3  pop rdi
000076cd267dafd4  pop rdx
000076cd267dafd5  pop rcx
000076cd267dafd6  pop rax
000076cd267dafd7  add rsp, 0x08
000076cd267dafdb  jmp 0x000076CD267D659A
000076cd267dafe0  call 0x000076CD2660C260
000076cd267dafe5  jmp 0x000076CD267D65A8
000076cd267dafea  call 0x000076CD266DE950
000076cd267dafef  jmp 0x000076CD267D65B2
000076cd267daff4  sub rsp, 0x08
000076cd267daff8  push rax
000076cd267daff9  push rcx
000076cd267daffa  push rdx
000076cd267daffb  push rdi
000076cd267daffc  push rsi
000076cd267daffd  push r8
000076cd267dafff  push r9
000076cd267db001  push r10
000076cd267db003  push r11
000076cd267db005  sub rsp, 0xF0
000076cd267db00c  vmovaps [rsp], xmm0
000076cd267db011  vmovaps [rsp+0x10], xmm1
000076cd267db017  vmovaps [rsp+0x20], xmm2
000076cd267db01d  vmovaps [rsp+0x30], xmm3
000076cd267db023  vmovaps [rsp+0x40], xmm4
000076cd267db029  vmovaps [rsp+0x50], xmm5
000076cd267db02f  vmovaps [rsp+0x60], xmm6
000076cd267db035  vmovaps [rsp+0x70], xmm7
000076cd267db03b  vmovaps [rsp+0x80], xmm9
000076cd267db044  vmovaps [rsp+0x90], xmm10
000076cd267db04d  vmovaps [rsp+0xA0], xmm11
000076cd267db056  vmovaps [rsp+0xB0], xmm12
000076cd267db05f  vmovaps [rsp+0xC0], xmm13
000076cd267db068  vmovaps [rsp+0xD0], xmm14
000076cd267db071  vmovaps [rsp+0xE0], xmm15
000076cd267db07a  sub rsp, 0x30
000076cd267db07e  movaps [rsp], xmm8
000076cd267db083  movaps [rsp+0x10], xmm15
000076cd267db089  movaps [rsp+0x20], xmm7
000076cd267db08e  lea rdi, [rsp]
000076cd267db092  mov esi, 0x00
000076cd267db097  mov rax, 0x56B8861A9530
000076cd267db0a1  call rax
000076cd267db0a3  movaps xmm8, [rsp]
000076cd267db0a8  add rsp, 0x30
000076cd267db0ac  vmovaps xmm0, [rsp]
000076cd267db0b1  vmovaps xmm1, [rsp+0x10]
000076cd267db0b7  vmovaps xmm2, [rsp+0x20]
000076cd267db0bd  vmovaps xmm3, [rsp+0x30]
000076cd267db0c3  vmovaps xmm4, [rsp+0x40]
000076cd267db0c9  vmovaps xmm5, [rsp+0x50]
000076cd267db0cf  vmovaps xmm6, [rsp+0x60]
000076cd267db0d5  vmovaps xmm7, [rsp+0x70]
000076cd267db0db  vmovaps xmm9, [rsp+0x80]
000076cd267db0e4  vmovaps xmm10, [rsp+0x90]
000076cd267db0ed  vmovaps xmm11, [rsp+0xA0]
000076cd267db0f6  vmovaps xmm12, [rsp+0xB0]
000076cd267db0ff  vmovaps xmm13, [rsp+0xC0]
000076cd267db108  vmovaps xmm14, [rsp+0xD0]
000076cd267db111  vmovaps xmm15, [rsp+0xE0]
000076cd267db11a  add rsp, 0xF0
000076cd267db121  pop r11
000076cd267db123  pop r10
000076cd267db125  pop r9
000076cd267db127  pop r8
000076cd267db129  pop rsi
000076cd267db12a  pop rdi
000076cd267db12b  pop rdx
000076cd267db12c  pop rcx
000076cd267db12d  pop rax
000076cd267db12e  add rsp, 0x08
000076cd267db132  jmp 0x000076CD267D65D4
000076cd267db137  sub rsp, 0x08
000076cd267db13b  push rax
000076cd267db13c  push rcx
000076cd267db13d  push rdx
000076cd267db13e  push rdi
000076cd267db13f  push rsi
000076cd267db140  push r8
000076cd267db142  push r9
000076cd267db144  push r10
000076cd267db146  push r11
000076cd267db148  sub rsp, 0xF0
000076cd267db14f  vmovaps [rsp], xmm0
000076cd267db154  vmovaps [rsp+0x10], xmm1
000076cd267db15a  vmovaps [rsp+0x20], xmm2
000076cd267db160  vmovaps [rsp+0x30], xmm3
000076cd267db166  vmovaps [rsp+0x40], xmm4
000076cd267db16c  vmovaps [rsp+0x50], xmm5
000076cd267db172  vmovaps [rsp+0x60], xmm6
000076cd267db178  vmovaps [rsp+0x70], xmm8
000076cd267db17e  vmovaps [rsp+0x80], xmm9
000076cd267db187  vmovaps [rsp+0x90], xmm10
000076cd267db190  vmovaps [rsp+0xA0], xmm11
000076cd267db199  vmovaps [rsp+0xB0], xmm12
000076cd267db1a2  vmovaps [rsp+0xC0], xmm13
000076cd267db1ab  vmovaps [rsp+0xD0], xmm14
000076cd267db1b4  vmovaps [rsp+0xE0], xmm15
000076cd267db1bd  sub rsp, 0x30
000076cd267db1c1  movaps [rsp], xmm7
000076cd267db1c5  movaps [rsp+0x10], xmm9
000076cd267db1cb  movaps [rsp+0x20], xmm15
000076cd267db1d1  lea rdi, [rsp]
000076cd267db1d5  mov esi, 0x00
000076cd267db1da  mov rax, 0x56B8861A9530
000076cd267db1e4  call rax
000076cd267db1e6  movaps xmm7, [rsp]
000076cd267db1ea  add rsp, 0x30
000076cd267db1ee  vmovaps xmm0, [rsp]
000076cd267db1f3  vmovaps xmm1, [rsp+0x10]
000076cd267db1f9  vmovaps xmm2, [rsp+0x20]
000076cd267db1ff  vmovaps xmm3, [rsp+0x30]
000076cd267db205  vmovaps xmm4, [rsp+0x40]
000076cd267db20b  vmovaps xmm5, [rsp+0x50]
000076cd267db211  vmovaps xmm6, [rsp+0x60]
000076cd267db217  vmovaps xmm8, [rsp+0x70]
000076cd267db21d  vmovaps xmm9, [rsp+0x80]
000076cd267db226  vmovaps xmm10, [rsp+0x90]
000076cd267db22f  vmovaps xmm11, [rsp+0xA0]
000076cd267db238  vmovaps xmm12, [rsp+0xB0]
000076cd267db241  vmovaps xmm13, [rsp+0xC0]
000076cd267db24a  vmovaps xmm14, [rsp+0xD0]
000076cd267db253  vmovaps xmm15, [rsp+0xE0]
000076cd267db25c  add rsp, 0xF0
000076cd267db263  pop r11
000076cd267db265  pop r10
000076cd267db267  pop r9
000076cd267db269  pop r8
000076cd267db26b  pop rsi
000076cd267db26c  pop rdi
000076cd267db26d  pop rdx
000076cd267db26e  pop rcx
000076cd267db26f  pop rax
000076cd267db270  add rsp, 0x08
000076cd267db274  jmp 0x000076CD267D6601
000076cd267db279  sub rsp, 0x08
000076cd267db27d  push rax
000076cd267db27e  push rcx
000076cd267db27f  push rdx
000076cd267db280  push rdi
000076cd267db281  push rsi
000076cd267db282  push r8
000076cd267db284  push r9
000076cd267db286  push r10
000076cd267db288  push r11
000076cd267db28a  sub rsp, 0xF0
000076cd267db291  vmovaps [rsp], xmm0
000076cd267db296  vmovaps [rsp+0x10], xmm1
000076cd267db29c  vmovaps [rsp+0x20], xmm2
000076cd267db2a2  vmovaps [rsp+0x30], xmm3
000076cd267db2a8  vmovaps [rsp+0x40], xmm4
000076cd267db2ae  vmovaps [rsp+0x50], xmm5
000076cd267db2b4  vmovaps [rsp+0x60], xmm6
000076cd267db2ba  vmovaps [rsp+0x70], xmm7
000076cd267db2c0  vmovaps [rsp+0x80], xmm8
000076cd267db2c9  vmovaps [rsp+0x90], xmm10
000076cd267db2d2  vmovaps [rsp+0xA0], xmm11
000076cd267db2db  vmovaps [rsp+0xB0], xmm12
000076cd267db2e4  vmovaps [rsp+0xC0], xmm13
000076cd267db2ed  vmovaps [rsp+0xD0], xmm14
000076cd267db2f6  vmovaps [rsp+0xE0], xmm15
000076cd267db2ff  sub rsp, 0x30
000076cd267db303  movaps [rsp], xmm9
000076cd267db308  movaps [rsp+0x10], xmm13
000076cd267db30e  movaps [rsp+0x20], xmm15
000076cd267db314  lea rdi, [rsp]
000076cd267db318  mov esi, 0x00
000076cd267db31d  mov rax, 0x56B8861A9530
000076cd267db327  call rax
000076cd267db329  movaps xmm9, [rsp]
000076cd267db32e  add rsp, 0x30
000076cd267db332  vmovaps xmm0, [rsp]
000076cd267db337  vmovaps xmm1, [rsp+0x10]
000076cd267db33d  vmovaps xmm2, [rsp+0x20]
000076cd267db343  vmovaps xmm3, [rsp+0x30]
000076cd267db349  vmovaps xmm4, [rsp+0x40]
000076cd267db34f  vmovaps xmm5, [rsp+0x50]
000076cd267db355  vmovaps xmm6, [rsp+0x60]
000076cd267db35b  vmovaps xmm7, [rsp+0x70]
000076cd267db361  vmovaps xmm8, [rsp+0x80]
000076cd267db36a  vmovaps xmm10, [rsp+0x90]
000076cd267db373  vmovaps xmm11, [rsp+0xA0]
000076cd267db37c  vmovaps xmm12, [rsp+0xB0]
000076cd267db385  vmovaps xmm13, [rsp+0xC0]
000076cd267db38e  vmovaps xmm14, [rsp+0xD0]
000076cd267db397  vmovaps xmm15, [rsp+0xE0]
000076cd267db3a0  add rsp, 0xF0
000076cd267db3a7  pop r11
000076cd267db3a9  pop r10
000076cd267db3ab  pop r9
000076cd267db3ad  pop r8
000076cd267db3af  pop rsi
000076cd267db3b0  pop rdi
000076cd267db3b1  pop rdx
000076cd267db3b2  pop rcx
000076cd267db3b3  pop rax
000076cd267db3b4  add rsp, 0x08
000076cd267db3b8  jmp 0x000076CD267D662F
000076cd267db3bd  sub rsp, 0x08
000076cd267db3c1  push rax
000076cd267db3c2  push rcx
000076cd267db3c3  push rdx
000076cd267db3c4  push rdi
000076cd267db3c5  push rsi
000076cd267db3c6  push r8
000076cd267db3c8  push r9
000076cd267db3ca  push r10
000076cd267db3cc  push r11
000076cd267db3ce  sub rsp, 0xF0
000076cd267db3d5  vmovaps [rsp], xmm0
000076cd267db3da  vmovaps [rsp+0x10], xmm1
000076cd267db3e0  vmovaps [rsp+0x20], xmm2
000076cd267db3e6  vmovaps [rsp+0x30], xmm3
000076cd267db3ec  vmovaps [rsp+0x40], xmm4
000076cd267db3f2  vmovaps [rsp+0x50], xmm5
000076cd267db3f8  vmovaps [rsp+0x60], xmm6
000076cd267db3fe  vmovaps [rsp+0x70], xmm7
000076cd267db404  vmovaps [rsp+0x80], xmm8
000076cd267db40d  vmovaps [rsp+0x90], xmm9
000076cd267db416  vmovaps [rsp+0xA0], xmm10
000076cd267db41f  vmovaps [rsp+0xB0], xmm11
000076cd267db428  vmovaps [rsp+0xC0], xmm12
000076cd267db431  vmovaps [rsp+0xD0], xmm13
000076cd267db43a  vmovaps [rsp+0xE0], xmm14
000076cd267db443  sub rsp, 0x30
000076cd267db447  movaps [rsp], xmm15
000076cd267db44c  movaps [rsp+0x10], xmm11
000076cd267db452  movaps [rsp+0x20], xmm12
000076cd267db458  lea rdi, [rsp]
000076cd267db45c  mov esi, 0x00
000076cd267db461  mov rax, 0x56B8861A9530
000076cd267db46b  call rax
000076cd267db46d  movaps xmm15, [rsp]
000076cd267db472  add rsp, 0x30
000076cd267db476  vmovaps xmm0, [rsp]
000076cd267db47b  vmovaps xmm1, [rsp+0x10]
000076cd267db481  vmovaps xmm2, [rsp+0x20]
000076cd267db487  vmovaps xmm3, [rsp+0x30]
000076cd267db48d  vmovaps xmm4, [rsp+0x40]
000076cd267db493  vmovaps xmm5, [rsp+0x50]
000076cd267db499  vmovaps xmm6, [rsp+0x60]
000076cd267db49f  vmovaps xmm7, [rsp+0x70]
000076cd267db4a5  vmovaps xmm8, [rsp+0x80]
000076cd267db4ae  vmovaps xmm9, [rsp+0x90]
000076cd267db4b7  vmovaps xmm10, [rsp+0xA0]
000076cd267db4c0  vmovaps xmm11, [rsp+0xB0]
000076cd267db4c9  vmovaps xmm12, [rsp+0xC0]
000076cd267db4d2  vmovaps xmm13, [rsp+0xD0]
000076cd267db4db  vmovaps xmm14, [rsp+0xE0]
000076cd267db4e4  add rsp, 0xF0
000076cd267db4eb  pop r11
000076cd267db4ed  pop r10
000076cd267db4ef  pop r9
000076cd267db4f1  pop r8
000076cd267db4f3  pop rsi
000076cd267db4f4  pop rdi
000076cd267db4f5  pop rdx
000076cd267db4f6  pop rcx
000076cd267db4f7  pop rax
000076cd267db4f8  add rsp, 0x08
000076cd267db4fc  jmp 0x000076CD267D664A
000076cd267db501  sub rsp, 0x08
000076cd267db505  push rax
000076cd267db506  push rcx
000076cd267db507  push rdx
000076cd267db508  push rdi
000076cd267db509  push rsi
000076cd267db50a  push r8
000076cd267db50c  push r9
000076cd267db50e  push r10
000076cd267db510  push r11
000076cd267db512  sub rsp, 0xF0
000076cd267db519  vmovaps [rsp], xmm0
000076cd267db51e  vmovaps [rsp+0x10], xmm1
000076cd267db524  vmovaps [rsp+0x20], xmm2
000076cd267db52a  vmovaps [rsp+0x30], xmm3
000076cd267db530  vmovaps [rsp+0x40], xmm4
000076cd267db536  vmovaps [rsp+0x50], xmm5
000076cd267db53c  vmovaps [rsp+0x60], xmm6
000076cd267db542  vmovaps [rsp+0x70], xmm7
000076cd267db548  vmovaps [rsp+0x80], xmm8
000076cd267db551  vmovaps [rsp+0x90], xmm9
000076cd267db55a  vmovaps [rsp+0xA0], xmm10
000076cd267db563  vmovaps [rsp+0xB0], xmm11
000076cd267db56c  vmovaps [rsp+0xC0], xmm12
000076cd267db575  vmovaps [rsp+0xD0], xmm14
000076cd267db57e  vmovaps [rsp+0xE0], xmm15
000076cd267db587  sub rsp, 0x30
000076cd267db58b  movaps [rsp], xmm13
000076cd267db590  movaps [rsp+0x10], xmm10
000076cd267db596  movaps [rsp+0x20], xmm14
000076cd267db59c  lea rdi, [rsp]
000076cd267db5a0  mov esi, 0x00
000076cd267db5a5  mov rax, 0x56B8861A9530
000076cd267db5af  call rax
000076cd267db5b1  movaps xmm13, [rsp]
000076cd267db5b6  add rsp, 0x30
000076cd267db5ba  vmovaps xmm0, [rsp]
000076cd267db5bf  vmovaps xmm1, [rsp+0x10]
000076cd267db5c5  vmovaps xmm2, [rsp+0x20]
000076cd267db5cb  vmovaps xmm3, [rsp+0x30]
000076cd267db5d1  vmovaps xmm4, [rsp+0x40]
000076cd267db5d7  vmovaps xmm5, [rsp+0x50]
000076cd267db5dd  vmovaps xmm6, [rsp+0x60]
000076cd267db5e3  vmovaps xmm7, [rsp+0x70]
000076cd267db5e9  vmovaps xmm8, [rsp+0x80]
000076cd267db5f2  vmovaps xmm9, [rsp+0x90]
000076cd267db5fb  vmovaps xmm10, [rsp+0xA0]
000076cd267db604  vmovaps xmm11, [rsp+0xB0]
000076cd267db60d  vmovaps xmm12, [rsp+0xC0]
000076cd267db616  vmovaps xmm14, [rsp+0xD0]
000076cd267db61f  vmovaps xmm15, [rsp+0xE0]
000076cd267db628  add rsp, 0xF0
000076cd267db62f  pop r11
000076cd267db631  pop r10
000076cd267db633  pop r9
000076cd267db635  pop r8
000076cd267db637  pop rsi
000076cd267db638  pop rdi
000076cd267db639  pop rdx
000076cd267db63a  pop rcx
000076cd267db63b  pop rax
000076cd267db63c  add rsp, 0x08
000076cd267db640  jmp 0x000076CD267D666D
000076cd267db645  sub rsp, 0x08
000076cd267db649  push rax
000076cd267db64a  push rcx
000076cd267db64b  push rdx
000076cd267db64c  push rdi
000076cd267db64d  push rsi
000076cd267db64e  push r8
000076cd267db650  push r9
000076cd267db652  push r10
000076cd267db654  push r11
000076cd267db656  sub rsp, 0xF0
000076cd267db65d  vmovaps [rsp], xmm0
000076cd267db662  vmovaps [rsp+0x10], xmm1
000076cd267db668  vmovaps [rsp+0x20], xmm2
000076cd267db66e  vmovaps [rsp+0x30], xmm3
000076cd267db674  vmovaps [rsp+0x40], xmm4
000076cd267db67a  vmovaps [rsp+0x50], xmm5
000076cd267db680  vmovaps [rsp+0x60], xmm6
000076cd267db686  vmovaps [rsp+0x70], xmm7
000076cd267db68c  vmovaps [rsp+0x80], xmm8
000076cd267db695  vmovaps [rsp+0x90], xmm9
000076cd267db69e  vmovaps [rsp+0xA0], xmm10
000076cd267db6a7  vmovaps [rsp+0xB0], xmm11
000076cd267db6b0  vmovaps [rsp+0xC0], xmm12
000076cd267db6b9  vmovaps [rsp+0xD0], xmm13
000076cd267db6c2  vmovaps [rsp+0xE0], xmm15
000076cd267db6cb  sub rsp, 0x30
000076cd267db6cf  movaps [rsp], xmm14
000076cd267db6d4  movaps [rsp+0x10], xmm1
000076cd267db6d9  movaps [rsp+0x20], xmm7
000076cd267db6de  lea rdi, [rsp]
000076cd267db6e2  mov esi, 0x00
000076cd267db6e7  mov rax, 0x56B8861A9530
000076cd267db6f1  call rax
000076cd267db6f3  movaps xmm14, [rsp]
000076cd267db6f8  add rsp, 0x30
000076cd267db6fc  vmovaps xmm0, [rsp]
000076cd267db701  vmovaps xmm1, [rsp+0x10]
000076cd267db707  vmovaps xmm2, [rsp+0x20]
000076cd267db70d  vmovaps xmm3, [rsp+0x30]
000076cd267db713  vmovaps xmm4, [rsp+0x40]
000076cd267db719  vmovaps xmm5, [rsp+0x50]
000076cd267db71f  vmovaps xmm6, [rsp+0x60]
000076cd267db725  vmovaps xmm7, [rsp+0x70]
000076cd267db72b  vmovaps xmm8, [rsp+0x80]
000076cd267db734  vmovaps xmm9, [rsp+0x90]
000076cd267db73d  vmovaps xmm10, [rsp+0xA0]
000076cd267db746  vmovaps xmm11, [rsp+0xB0]
000076cd267db74f  vmovaps xmm12, [rsp+0xC0]
000076cd267db758  vmovaps xmm13, [rsp+0xD0]
000076cd267db761  vmovaps xmm15, [rsp+0xE0]
000076cd267db76a  add rsp, 0xF0
000076cd267db771  pop r11
000076cd267db773  pop r10
000076cd267db775  pop r9
000076cd267db777  pop r8
000076cd267db779  pop rsi
000076cd267db77a  pop rdi
000076cd267db77b  pop rdx
000076cd267db77c  pop rcx
000076cd267db77d  pop rax
000076cd267db77e  add rsp, 0x08
000076cd267db782  jmp 0x000076CD267D6690
000076cd267db787  sub rsp, 0x08
000076cd267db78b  push rax
000076cd267db78c  push rcx
000076cd267db78d  push rdx
000076cd267db78e  push rdi
000076cd267db78f  push rsi
000076cd267db790  push r8
000076cd267db792  push r9
000076cd267db794  push r10
000076cd267db796  push r11
000076cd267db798  sub rsp, 0xF0
000076cd267db79f  vmovaps [rsp], xmm0
000076cd267db7a4  vmovaps [rsp+0x10], xmm2
000076cd267db7aa  vmovaps [rsp+0x20], xmm3
000076cd267db7b0  vmovaps [rsp+0x30], xmm4
000076cd267db7b6  vmovaps [rsp+0x40], xmm5
000076cd267db7bc  vmovaps [rsp+0x50], xmm6
000076cd267db7c2  vmovaps [rsp+0x60], xmm7
000076cd267db7c8  vmovaps [rsp+0x70], xmm8
000076cd267db7ce  vmovaps [rsp+0x80], xmm9
000076cd267db7d7  vmovaps [rsp+0x90], xmm10
000076cd267db7e0  vmovaps [rsp+0xA0], xmm11
000076cd267db7e9  vmovaps [rsp+0xB0], xmm12
000076cd267db7f2  vmovaps [rsp+0xC0], xmm13
000076cd267db7fb  vmovaps [rsp+0xD0], xmm14
000076cd267db804  vmovaps [rsp+0xE0], xmm15
000076cd267db80d  sub rsp, 0x30
000076cd267db811  movaps [rsp], xmm1
000076cd267db815  movaps [rsp+0x10], xmm8
000076cd267db81b  movaps [rsp+0x20], xmm9
000076cd267db821  lea rdi, [rsp]
000076cd267db825  mov esi, 0x00
000076cd267db82a  mov rax, 0x56B8861A9530
000076cd267db834  call rax
000076cd267db836  movaps xmm1, [rsp]
000076cd267db83a  add rsp, 0x30
000076cd267db83e  vmovaps xmm0, [rsp]
000076cd267db843  vmovaps xmm2, [rsp+0x10]
000076cd267db849  vmovaps xmm3, [rsp+0x20]
000076cd267db84f  vmovaps xmm4, [rsp+0x30]
000076cd267db855  vmovaps xmm5, [rsp+0x40]
000076cd267db85b  vmovaps xmm6, [rsp+0x50]
000076cd267db861  vmovaps xmm7, [rsp+0x60]
000076cd267db867  vmovaps xmm8, [rsp+0x70]
000076cd267db86d  vmovaps xmm9, [rsp+0x80]
000076cd267db876  vmovaps xmm10, [rsp+0x90]
000076cd267db87f  vmovaps xmm11, [rsp+0xA0]
000076cd267db888  vmovaps xmm12, [rsp+0xB0]
000076cd267db891  vmovaps xmm13, [rsp+0xC0]
000076cd267db89a  vmovaps xmm14, [rsp+0xD0]
000076cd267db8a3  vmovaps xmm15, [rsp+0xE0]
000076cd267db8ac  add rsp, 0xF0
000076cd267db8b3  pop r11
000076cd267db8b5  pop r10
000076cd267db8b7  pop r9
000076cd267db8b9  pop r8
000076cd267db8bb  pop rsi
000076cd267db8bc  pop rdi
000076cd267db8bd  pop rdx
000076cd267db8be  pop rcx
000076cd267db8bf  pop rax
000076cd267db8c0  add rsp, 0x08
000076cd267db8c4  jmp 0x000076CD267D66B2
000076cd267db8c9  call 0x000076CD266B3E40
000076cd267db8ce  jmp 0x000076CD267D66C0
000076cd267db8d3  call 0x000076CD2660C380
000076cd267db8d8  jmp 0x000076CD267D66CA
000076cd267db8dd  call 0x000076CD2660D600
000076cd267db8e2  jmp 0x000076CD267D66D4
000076cd267db8e7  call 0x000076CD265FF540
000076cd267db8ec  jmp 0x000076CD267D66DE
000076cd267db8f1  int3
000076cd267db8f2  nop [rax+rax*1], ax
000076cd267db8fb  nop [rax+rax*1], eax
000076cd267db900  mov eax, [r15+0x48]
000076cd267db904  lea r14d, [eax+0x01]
000076cd267db909  mov [rsp+0x10], r14d
000076cd267db90e  mov r14d, r14d
000076cd267db911  mov [r15+0x48], r14
000076cd267db915  xor eax, eax
000076cd267db917  mov r14d, [rsp+0x10]
000076cd267db91c  cmp r14d, 0x1F4
000076cd267db923  cmc
000076cd267db924  lahf
000076cd267db925  seto al
000076cd267db928  mov [r15+0x108], eax
000076cd267db92f  mov eax, [r15+0x108]
000076cd267db936  sahf
000076cd267db937  jnz 0x000076CD267DB969
000076cd267db939  cmp dword ptr [r15+0x318], 0x00
000076cd267db941  jz 0x000076CD267E1AB0
000076cd267db947  nop [rax+rax*1], ax
000076cd267db950  nop [rax+rax*1], eax
000076cd267db958  mov eax, 0x410450
000076cd267db95d  mov [r15+0x100], rax
000076cd267db964  jmp 0x000076CD265FE110
000076cd267db969  cmp dword ptr [r15+0x318], 0x00
000076cd267db971  jz 0x000076CD267DB9A0
000076cd267db977  nop [rax+rax*1], ax
000076cd267db980  nop [rax+rax*1], eax
000076cd267db988  mov eax, 0x410274
000076cd267db98d  mov [r15+0x100], rax
000076cd267db994  jmp 0x000076CD265FE110
000076cd267db999  int3
000076cd267db99a  int3
000076cd267db99b  nop [rax+rax*1], eax
000076cd267db9a0  mov rax, [r15+0x40]
000076cd267db9a4  movaps xmm1, [r15+0x1D0]
000076cd267db9ac  vmovaps [rsp+0x10], xmm1
000076cd267db9b2  vmovaps xmm15, [rsp+0x10]
000076cd267db9b8  por xmm1, xmm15
000076cd267db9bd  movaps xmm14, [r15+0x1A0]
000076cd267db9c5  vmovaps [rsp+0x10], xmm14
000076cd267db9cb  vmovaps xmm13, [rsp+0x10]
000076cd267db9d1  por xmm14, xmm13
000076cd267db9d6  lea r14, [rax+0x30]
000076cd267db9da  mov r12, [r13+r14*1]
000076cd267db9df  lea r14, [rax+0x38]
000076cd267db9e3  mov r11, [r13+r14*1]
000076cd267db9e8  movq xmm13, r12
000076cd267db9ed  movq xmm12, r11
000076cd267db9f2  movq xmm13, xmm13
000076cd267db9f7  vmovaps [rsp+0x10], xmm13
000076cd267db9fd  movq xmm13, xmm13
000076cd267dba02  movaps [r15+0x130], xmm13
000076cd267dba0a  movq xmm12, xmm12
000076cd267dba0f  vmovaps [rsp+0x20], xmm12
000076cd267dba15  movq xmm12, xmm12
000076cd267dba1a  movaps [r15+0x280], xmm12
000076cd267dba22  movaps xmm13, [r15+0x270]
000076cd267dba2a  vmovaps [rsp+0x30], xmm13
000076cd267dba30  vmovaps xmm12, [rsp+0x30]
000076cd267dba36  por xmm13, xmm12
000076cd267dba3b  lea r14, [rax+0x20]
000076cd267dba3f  mov r12, [r13+r14*1]
000076cd267dba44  lea r14, [rax+0x28]
000076cd267dba48  mov r11, [r13+r14*1]
000076cd267dba4d  movq xmm12, r12
000076cd267dba52  movq xmm11, r11
000076cd267dba57  movq xmm12, xmm12
000076cd267dba5c  vmovaps [rsp+0x30], xmm12
000076cd267dba62  movq xmm12, xmm12
000076cd267dba67  movaps [r15+0x150], xmm12
000076cd267dba6f  movq xmm11, xmm11
000076cd267dba74  vmovaps [rsp+0x40], xmm11
000076cd267dba7a  movq xmm11, xmm11
000076cd267dba7f  movaps [r15+0x140], xmm11
000076cd267dba87  lea r14, [rax+0x10]
000076cd267dba8b  mov r12, [r13+r14*1]
000076cd267dba90  lea r14, [rax+0x18]
000076cd267dba94  mov r11, [r13+r14*1]
000076cd267dba99  movq xmm12, r12
000076cd267dba9e  movq xmm11, r11
000076cd267dbaa3  movq xmm12, xmm12
000076cd267dbaa8  vmovaps [rsp+0x50], xmm12
000076cd267dbaae  movq xmm12, xmm12
000076cd267dbab3  movaps [r15+0x170], xmm12
000076cd267dbabb  movq xmm11, xmm11
000076cd267dbac0  vmovaps [rsp+0x60], xmm11
000076cd267dbac6  movq xmm11, xmm11
000076cd267dbacb  movaps [r15+0x160], xmm11
000076cd267dbad3  mov r14, [r13+rax*1]
000076cd267dbad8  vmovq xmm12, r14
000076cd267dbadd  vpbroadcastq xmm12, xmm12
000076cd267dbae2  lea r14, [rax+0x08]
000076cd267dbae6  mov rax, [r13+r14*1]
000076cd267dbaeb  movq xmm11, rax
000076cd267dbaf0  movaps [r15+0x230], xmm11
000076cd267dbaf8  mov rax, [r15+0xF8]
000076cd267dbaff  lea r14, [rax+0x50]
000076cd267dbb03  movups xmm11, [r13+r14*1]
000076cd267dbb09  lea r14, [rax+0x60]
000076cd267dbb0d  movups xmm10, [r13+r14*1]
000076cd267dbb13  lea r14, [rax+0x30]
000076cd267dbb17  movups xmm9, [r13+r14*1]
000076cd267dbb1d  mov r14, [r15+0x50]
000076cd267dbb21  mov [r15+0x60], r14
000076cd267dbb25  mov qword ptr [r15+0x58], 0x40
000076cd267dbb2d  movaps xmm8, xmm12
000076cd267dbb31  mulpd xmm8, xmm15
000076cd267dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000076cd267dbb3c  ptest xmm7, xmm7
000076cd267dbb41  jnz 0x000076CD267DC96A
000076cd267dbb47  movq xmm15, qword ptr [r15+0x230]
000076cd267dbb50  vmovaps [rsp+0x70], xmm15
000076cd267dbb56  vpermilpd xmm15, xmm15, 0x00
000076cd267dbb5c  movaps xmm7, xmm9
000076cd267dbb60  mulpd xmm7, xmm15
000076cd267dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000076cd267dbb6a  ptest xmm6, xmm6
000076cd267dbb6f  jnz 0x000076CD267DCAAE
000076cd267dbb75  vxorps xmm15, xmm15, xmm15
000076cd267dbb7a  vpbroadcastq xmm15, xmm15
000076cd267dbb7f  movaps xmm9, xmm12
000076cd267dbb83  mulpd xmm9, xmm10
000076cd267dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000076cd267dbb8e  ptest xmm6, xmm6
000076cd267dbb93  jnz 0x000076CD267DCBF0
000076cd267dbb99  movaps xmm10, xmm12
000076cd267dbb9d  mulpd xmm10, xmm11
000076cd267dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000076cd267dbba8  ptest xmm6, xmm6
000076cd267dbbad  jnz 0x000076CD267DCD34
000076cd267dbbb3  movaps xmm11, [r15+0x1F0]
000076cd267dbbbb  movaps xmm6, xmm12
000076cd267dbbbf  mulpd xmm6, xmm11
000076cd267dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000076cd267dbbc9  ptest xmm5, xmm5
000076cd267dbbce  jnz 0x000076CD267DCE78
000076cd267dbbd4  movaps xmm12, [r15+0x2A0]
000076cd267dbbdc  vmovaps [rsp+0x80], xmm12
000076cd267dbbe5  vmovaps xmm11, [rsp+0x80]
000076cd267dbbee  por xmm12, xmm11
000076cd267dbbf3  movaps xmm11, [r15+0x250]
000076cd267dbbfb  vmovaps [rsp+0x80], xmm11
000076cd267dbc04  vmovaps xmm5, [rsp+0x80]
000076cd267dbc0d  por xmm11, xmm5
000076cd267dbc12  vmovaps xmm4, [rsp+0x70]
000076cd267dbc18  vpermilpd xmm4, xmm4, 0x00
000076cd267dbc1e  movaps xmm3, xmm5
000076cd267dbc21  mulpd xmm3, xmm4
000076cd267dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000076cd267dbc2a  ptest xmm2, xmm2
000076cd267dbc2f  jnz 0x000076CD267DCFBA
000076cd267dbc35  mov [rsp+0x80], rax
000076cd267dbc3d  xor eax, eax
000076cd267dbc3f  mov r12d, 0x40
000076cd267dbc45  mov r11d, 0x200
000076cd267dbc4b  cmp r12, r11
000076cd267dbc4e  cmc
000076cd267dbc4f  lahf
000076cd267dbc50  seto al
000076cd267dbc53  mov [r15+0x108], eax
000076cd267dbc5a  movaps xmm5, xmm8
000076cd267dbc5e  addpd xmm5, xmm15
000076cd267dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000076cd267dbc68  ptest xmm4, xmm4
000076cd267dbc6d  jnz 0x000076CD267DD0FA
000076cd267dbc73  movaps xmm8, [r15+0x1B0]
000076cd267dbc7b  movaps xmm4, xmm9
000076cd267dbc7f  addpd xmm4, xmm8
000076cd267dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000076cd267dbc89  ptest xmm2, xmm2
000076cd267dbc8e  jnz 0x000076CD267DD23C
000076cd267dbc94  movaps xmm9, xmm10
000076cd267dbc98  addpd xmm9, xmm8
000076cd267dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000076cd267dbca3  ptest xmm2, xmm2
000076cd267dbca8  jnz 0x000076CD267DD37E
000076cd267dbcae  movaps xmm10, [r15+0x2F0]
000076cd267dbcb6  vmovaps [rsp+0x90], xmm10
000076cd267dbcbf  vmovaps xmm8, [rsp+0x90]
000076cd267dbcc8  por xmm10, xmm8
000076cd267dbccd  movaps xmm8, [r15+0x2E0]
000076cd267dbcd5  vmovaps [rsp+0x90], xmm8
000076cd267dbcde  vmovaps xmm2, [rsp+0x90]
000076cd267dbce7  por xmm8, xmm2
000076cd267dbcec  movaps xmm2, [r15+0x2D0]
000076cd267dbcf4  vmovaps [rsp+0x90], xmm2
000076cd267dbcfd  vmovaps [rsp+0xA0], xmm1
000076cd267dbd06  vmovaps xmm1, [rsp+0x90]
000076cd267dbd0f  por xmm2, xmm1
000076cd267dbd13  movaps xmm1, [r15+0x200]
000076cd267dbd1b  vmovaps [rsp+0x90], xmm1
000076cd267dbd24  vmovaps [rsp+0xB0], xmm15
000076cd267dbd2d  vmovaps xmm15, [rsp+0x90]
000076cd267dbd36  por xmm1, xmm15
000076cd267dbd3b  movaps xmm15, [r15+0x1C0]
000076cd267dbd43  vmovaps [rsp+0x90], xmm15
000076cd267dbd4c  vmovaps [rsp+0xC0], xmm1
000076cd267dbd55  vmovaps xmm1, [rsp+0x90]
000076cd267dbd5e  por xmm15, xmm1
000076cd267dbd63  movaps xmm1, [r15+0x190]
000076cd267dbd6b  vmovaps [rsp+0x90], xmm1
000076cd267dbd74  vmovaps [rsp+0xD0], xmm15
000076cd267dbd7d  vmovaps xmm15, [rsp+0x90]
000076cd267dbd86  por xmm1, xmm15
000076cd267dbd8b  movaps xmm15, [r15+0x300]
000076cd267dbd93  vmovaps [rsp+0x90], xmm15
000076cd267dbd9c  vmovaps [rsp+0xE0], xmm1
000076cd267dbda5  vmovaps xmm1, [rsp+0x90]
000076cd267dbdae  por xmm15, xmm1
000076cd267dbdb3  mov rax, [rsp+0x80]
000076cd267dbdbb  lea r12, [rax+0xA0]
000076cd267dbdc2  movups xmm1, [r13+r12*1]
000076cd267dbdc8  lea r12, [rax+0xB0]
000076cd267dbdcf  vmovaps [rsp+0x80], xmm1
000076cd267dbdd8  movups xmm1, [r13+r12*1]
000076cd267dbdde  vmovaps [rsp+0x90], xmm1
000076cd267dbde7  vmovaps [rsp+0xF0], xmm15
000076cd267dbdf0  vmovaps xmm15, [rsp+0xB0]
000076cd267dbdf9  vmovaps [rsp+0xB0], xmm14
000076cd267dbe02  movaps xmm1, xmm6
000076cd267dbe05  addpd xmm1, xmm15
000076cd267dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000076cd267dbe0f  ptest xmm14, xmm14
000076cd267dbe15  jnz 0x000076CD267DD4D6
000076cd267dbe1b  lea r12, [rax+0xF0]
000076cd267dbe22  movups xmm15, [r13+r12*1]
000076cd267dbe28  movaps xmm14, xmm4
000076cd267dbe2c  addpd xmm14, xmm3
000076cd267dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000076cd267dbe37  ptest xmm6, xmm6
000076cd267dbe3c  jnz 0x000076CD267DD621
000076cd267dbe42  movaps xmm6, xmm9
000076cd267dbe46  addpd xmm6, xmm7
000076cd267dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000076cd267dbe4f  ptest xmm4, xmm4
000076cd267dbe54  jnz 0x000076CD267DD763
000076cd267dbe5a  vmovaps xmm9, [rsp+0x70]
000076cd267dbe60  vpermilpd xmm9, xmm9, 0x00
000076cd267dbe66  vmovaps xmm4, [rsp+0x90]
000076cd267dbe6f  movaps xmm7, xmm4
000076cd267dbe72  mulpd xmm7, xmm9
000076cd267dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000076cd267dbe7c  ptest xmm3, xmm3
000076cd267dbe81  jnz 0x000076CD267DD8A4
000076cd267dbe87  vmovaps xmm9, [rsp+0x50]
000076cd267dbe8d  vpermilpd xmm9, xmm9, 0x00
000076cd267dbe93  movaps xmm4, xmm15
000076cd267dbe97  mulpd xmm4, xmm9
000076cd267dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000076cd267dbea1  ptest xmm3, xmm3
000076cd267dbea6  jnz 0x000076CD267DD9E5
000076cd267dbeac  lea r12, [rax+0xE0]
000076cd267dbeb3  movups xmm15, [r13+r12*1]
000076cd267dbeb9  vmovaps xmm9, [rsp+0x70]
000076cd267dbebf  vpermilpd xmm9, xmm9, 0x00
000076cd267dbec5  vmovaps [rsp+0x70], xmm1
000076cd267dbecb  vmovaps xmm1, [rsp+0x80]
000076cd267dbed4  vmovaps [rsp+0x80], xmm15
000076cd267dbedd  movaps xmm3, xmm1
000076cd267dbee0  mulpd xmm3, xmm9
000076cd267dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000076cd267dbeea  ptest xmm15, xmm15
000076cd267dbef0  jnz 0x000076CD267DDB31
000076cd267dbef6  vmovaps xmm1, [rsp+0xF0]
000076cd267dbeff  vmovaps xmm15, [rsp+0xF0]
000076cd267dbf08  por xmm1, xmm15
000076cd267dbf0d  movaps [r15+0x300], xmm1
000076cd267dbf15  vmovaps xmm15, [rsp+0xE0]
000076cd267dbf1e  vmovaps xmm9, [rsp+0xE0]
000076cd267dbf27  por xmm15, xmm9
000076cd267dbf2c  movaps [r15+0x190], xmm15
000076cd267dbf34  vmovaps xmm9, [rsp+0x50]
000076cd267dbf3a  vpermilpd xmm9, xmm9, 0x00
000076cd267dbf40  vmovaps [rsp+0x90], xmm1
000076cd267dbf49  vmovaps [rsp+0xE0], xmm15
000076cd267dbf52  vmovaps xmm15, [rsp+0x80]
000076cd267dbf5b  vmovaps [rsp+0x80], xmm14
000076cd267dbf64  movaps xmm1, xmm15
000076cd267dbf68  mulpd xmm1, xmm9
000076cd267dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000076cd267dbf72  ptest xmm14, xmm14
000076cd267dbf78  jnz 0x000076CD267DDC72
000076cd267dbf7e  lea r12, [rax+0x90]
000076cd267dbf85  movups xmm15, [r13+r12*1]
000076cd267dbf8b  vmovaps xmm14, [rsp+0xD0]
000076cd267dbf94  vmovaps xmm9, [rsp+0xD0]
000076cd267dbf9d  por xmm14, xmm9
000076cd267dbfa2  movaps [r15+0x1C0], xmm14
000076cd267dbfaa  vmovaps xmm9, [rsp+0xC0]
000076cd267dbfb3  vmovaps [rsp+0xD0], xmm1
000076cd267dbfbc  vmovaps xmm1, [rsp+0xC0]
000076cd267dbfc5  por xmm9, xmm1
000076cd267dbfca  movaps [r15+0x200], xmm9
000076cd267dbfd2  vmovaps [rsp+0xC0], xmm2
000076cd267dbfdb  vmovaps xmm1, [rsp+0xC0]
000076cd267dbfe4  por xmm2, xmm1
000076cd267dbfe8  movaps [r15+0x2D0], xmm2
000076cd267dbff0  vmovaps [rsp+0xC0], xmm8
000076cd267dbff9  vmovaps xmm1, [rsp+0xC0]
000076cd267dc002  por xmm8, xmm1
000076cd267dc007  movaps [r15+0x2E0], xmm8
000076cd267dc00f  vmovaps [rsp+0xC0], xmm15
000076cd267dc018  movaps xmm1, xmm5
000076cd267dc01b  addpd xmm1, xmm7
000076cd267dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000076cd267dc024  ptest xmm15, xmm15
000076cd267dc02a  jnz 0x000076CD267DDDBE
000076cd267dc030  vmovaps xmm15, [rsp+0x50]
000076cd267dc036  vpermilpd xmm15, xmm15, 0x00
000076cd267dc03c  vmovaps xmm5, [rsp+0xC0]
000076cd267dc045  vmovaps [rsp+0xC0], xmm1
000076cd267dc04e  movaps xmm7, xmm5
000076cd267dc051  mulpd xmm7, xmm15
000076cd267dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000076cd267dc05b  ptest xmm1, xmm1
000076cd267dc060  jnz 0x000076CD267DDEFE
000076cd267dc066  lea r12, [rax+0x80]
000076cd267dc06d  movups xmm1, [r13+r12*1]
000076cd267dc073  vmovaps xmm5, [rsp+0x70]
000076cd267dc079  vmovaps [rsp+0x70], xmm1
000076cd267dc07f  movaps xmm15, xmm5
000076cd267dc083  addpd xmm15, xmm3
000076cd267dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267dc08e  ptest xmm1, xmm1
000076cd267dc093  jnz 0x000076CD267DE049
000076cd267dc099  vmovaps xmm5, [rsp+0x80]
000076cd267dc0a2  movaps xmm1, xmm5
000076cd267dc0a5  addpd xmm1, xmm4
000076cd267dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000076cd267dc0ae  ptest xmm3, xmm3
000076cd267dc0b3  jnz 0x000076CD267DE18B
000076cd267dc0b9  vmovaps [rsp+0x80], xmm10
000076cd267dc0c2  vmovaps xmm5, [rsp+0x80]
000076cd267dc0cb  por xmm10, xmm5
000076cd267dc0d0  movaps [r15+0x2F0], xmm10
000076cd267dc0d8  vmovaps xmm5, [rsp+0x50]
000076cd267dc0de  vpermilpd xmm5, xmm5, 0x00
000076cd267dc0e4  vmovaps xmm3, [rsp+0x70]
000076cd267dc0ea  vmovaps [rsp+0x50], xmm1
000076cd267dc0f0  movaps xmm4, xmm3
000076cd267dc0f3  mulpd xmm4, xmm5
000076cd267dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000076cd267dc0fc  ptest xmm1, xmm1
000076cd267dc101  jnz 0x000076CD267DE2CB
000076cd267dc107  lea r12, [rax+0xD0]
000076cd267dc10e  movups xmm1, [r13+r12*1]
000076cd267dc114  vmovaps xmm3, [rsp+0xD0]
000076cd267dc11d  vmovaps [rsp+0x70], xmm1
000076cd267dc123  movaps xmm5, xmm6
000076cd267dc126  addpd xmm5, xmm3
000076cd267dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000076cd267dc12f  ptest xmm1, xmm1
000076cd267dc134  jnz 0x000076CD267DE415
000076cd267dc13a  vmovaps xmm1, [rsp+0x60]
000076cd267dc140  vpermilpd xmm1, xmm1, 0x00
000076cd267dc146  movaps xmm6, xmm9
000076cd267dc14a  mulpd xmm6, xmm1
000076cd267dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000076cd267dc153  ptest xmm3, xmm3
000076cd267dc158  jnz 0x000076CD267DE555
000076cd267dc15e  movaps [r15+0x260], xmm6
000076cd267dc166  vxorps xmm1, xmm1, xmm1
000076cd267dc16a  vpbroadcastq xmm1, xmm1
000076cd267dc16f  movaps [r15+0x1B0], xmm1
000076cd267dc177  vmovaps xmm1, [rsp+0x60]
000076cd267dc17d  vpermilpd xmm1, xmm1, 0x00
000076cd267dc183  vmovaps xmm3, [rsp+0x70]
000076cd267dc189  vmovaps [rsp+0x70], xmm15
000076cd267dc18f  movaps xmm9, xmm3
000076cd267dc193  mulpd xmm9, xmm1
000076cd267dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000076cd267dc19e  ptest xmm15, xmm15
000076cd267dc1a4  jnz 0x000076CD267DE696
000076cd267dc1aa  lea r12, [rax+0xC0]
000076cd267dc1b1  movups xmm1, [r13+r12*1]
000076cd267dc1b7  vmovaps xmm3, [rsp+0xC0]
000076cd267dc1c0  vmovaps [rsp+0x80], xmm1
000076cd267dc1c9  movaps xmm15, xmm3
000076cd267dc1cd  addpd xmm15, xmm7
000076cd267dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267dc1d8  ptest xmm1, xmm1
000076cd267dc1dd  jnz 0x000076CD267DE7E2
000076cd267dc1e3  vmovaps [rsp+0xC0], xmm13
000076cd267dc1ec  vmovaps xmm1, [rsp+0xC0]
000076cd267dc1f5  por xmm13, xmm1
000076cd267dc1fa  movaps [r15+0x270], xmm13
000076cd267dc202  vmovaps xmm1, [rsp+0xB0]
000076cd267dc20b  vmovaps xmm7, [rsp+0xB0]
000076cd267dc214  por xmm1, xmm7
000076cd267dc218  movaps [r15+0x1A0], xmm1
000076cd267dc220  vmovaps xmm1, [rsp+0x60]
000076cd267dc226  vpermilpd xmm1, xmm1, 0x00
000076cd267dc22c  vmovaps [rsp+0xB0], xmm1
000076cd267dc235  vmovaps xmm1, [rsp+0x80]
000076cd267dc23e  vmovaps [rsp+0x80], xmm15
000076cd267dc247  vmovaps xmm15, [rsp+0xB0]
000076cd267dc250  vmovaps [rsp+0xB0], xmm14
000076cd267dc259  movaps xmm3, xmm1
000076cd267dc25c  mulpd xmm3, xmm15
000076cd267dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000076cd267dc266  ptest xmm14, xmm14
000076cd267dc26c  jnz 0x000076CD267DE924
000076cd267dc272  lea r12, [rax+0x20]
000076cd267dc276  movups xmm1, [r13+r12*1]
000076cd267dc27c  movaps [r15+0x110], xmm1
000076cd267dc284  vmovaps xmm14, [rsp+0x70]
000076cd267dc28a  vmovaps [rsp+0x70], xmm1
000076cd267dc290  movaps xmm15, xmm14
000076cd267dc294  addpd xmm15, xmm4
000076cd267dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000076cd267dc29f  ptest xmm1, xmm1
000076cd267dc2a4  jnz 0x000076CD267DEA6F
000076cd267dc2aa  vmovaps xmm1, [rsp+0x60]
000076cd267dc2b0  vpermilpd xmm1, xmm1, 0x00
000076cd267dc2b6  movaps xmm14, xmm2
000076cd267dc2ba  mulpd xmm14, xmm1
000076cd267dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000076cd267dc2c5  ptest xmm4, xmm4
000076cd267dc2ca  jnz 0x000076CD267DEBB2
000076cd267dc2d0  vmovaps xmm4, [rsp+0x50]
000076cd267dc2d6  movaps xmm1, xmm4
000076cd267dc2d9  addpd xmm1, xmm9
000076cd267dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000076cd267dc2e3  ptest xmm2, xmm2
000076cd267dc2e8  jnz 0x000076CD267DECF4
000076cd267dc2ee  vmovaps xmm9, [rsp+0x30]
000076cd267dc2f4  vpermilpd xmm9, xmm9, 0x00
000076cd267dc2fa  vmovaps xmm2, [rsp+0x70]
000076cd267dc300  vmovaps [rsp+0x50], xmm1
000076cd267dc306  movaps xmm4, xmm2
000076cd267dc309  mulpd xmm4, xmm9
000076cd267dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000076cd267dc313  ptest xmm1, xmm1
000076cd267dc318  jnz 0x000076CD267DEE35
000076cd267dc31e  vmovaps xmm1, [rsp+0x30]
000076cd267dc324  vpermilpd xmm1, xmm1, 0x00
000076cd267dc32a  vmovaps xmm2, [rsp+0x90]
000076cd267dc333  vmovaps [rsp+0x60], xmm15
000076cd267dc339  movaps xmm9, xmm2
000076cd267dc33d  mulpd xmm9, xmm1
000076cd267dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000076cd267dc348  ptest xmm15, xmm15
000076cd267dc34e  jnz 0x000076CD267DEF76
000076cd267dc354  vmovaps xmm15, [rsp+0x80]
000076cd267dc35d  movaps xmm1, xmm15
000076cd267dc361  addpd xmm1, xmm6
000076cd267dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000076cd267dc36a  ptest xmm2, xmm2
000076cd267dc36f  jnz 0x000076CD267DF0B8
000076cd267dc375  movaps xmm15, xmm5
000076cd267dc379  addpd xmm15, xmm3
000076cd267dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000076cd267dc384  ptest xmm6, xmm6
000076cd267dc389  jnz 0x000076CD267DF1F9
000076cd267dc38f  vmovaps xmm6, [rsp+0x30]
000076cd267dc395  vpermilpd xmm6, xmm6, 0x00
000076cd267dc39b  movaps xmm5, xmm8
000076cd267dc39f  mulpd xmm5, xmm6
000076cd267dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000076cd267dc3a8  ptest xmm3, xmm3
000076cd267dc3ad  jnz 0x000076CD267DF33B
000076cd267dc3b3  vmovaps xmm8, [rsp+0x30]
000076cd267dc3b9  vpermilpd xmm8, xmm8, 0x00
000076cd267dc3bf  movaps xmm6, xmm10
000076cd267dc3c3  mulpd xmm6, xmm8
000076cd267dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000076cd267dc3cd  ptest xmm3, xmm3
000076cd267dc3d2  jnz 0x000076CD267DF47C
000076cd267dc3d8  vmovaps xmm8, [rsp+0x60]
000076cd267dc3de  movaps xmm10, xmm8
000076cd267dc3e2  addpd xmm10, xmm14
000076cd267dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000076cd267dc3ed  ptest xmm3, xmm3
000076cd267dc3f2  jnz 0x000076CD267DF5BE
000076cd267dc3f8  vmovaps xmm8, [rsp+0x50]
000076cd267dc3fe  movaps xmm14, xmm8
000076cd267dc402  addpd xmm14, xmm4
000076cd267dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000076cd267dc40d  ptest xmm3, xmm3
000076cd267dc412  jnz 0x000076CD267DF702
000076cd267dc418  vmovaps xmm8, [rsp+0x40]
000076cd267dc41e  vpermilpd xmm8, xmm8, 0x00
000076cd267dc424  movaps xmm4, xmm13
000076cd267dc428  mulpd xmm4, xmm8
000076cd267dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000076cd267dc432  ptest xmm3, xmm3
000076cd267dc437  jnz 0x000076CD267DF845
000076cd267dc43d  movaps xmm13, xmm15
000076cd267dc441  addpd xmm13, xmm9
000076cd267dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000076cd267dc44c  ptest xmm8, xmm8
000076cd267dc452  jnz 0x000076CD267DF987
000076cd267dc458  movaps xmm15, xmm1
000076cd267dc45c  addpd xmm15, xmm5
000076cd267dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000076cd267dc467  ptest xmm9, xmm9
000076cd267dc46d  jnz 0x000076CD267DFACB
000076cd267dc473  vmovaps [rsp+0x30], xmm11
000076cd267dc479  vmovaps xmm1, [rsp+0x30]
000076cd267dc47f  por xmm11, xmm1
000076cd267dc484  movaps [r15+0x250], xmm11
000076cd267dc48c  vmovaps [rsp+0x30], xmm12
000076cd267dc492  vmovaps xmm1, [rsp+0x30]
000076cd267dc498  por xmm12, xmm1
000076cd267dc49d  movaps [r15+0x2A0], xmm12
000076cd267dc4a5  vmovaps xmm1, [rsp+0xA0]
000076cd267dc4ae  vmovaps xmm11, [rsp+0xA0]
000076cd267dc4b7  por xmm1, xmm11
000076cd267dc4bc  movaps [r15+0x1D0], xmm1
000076cd267dc4c4  lea r12, [rax+0x40]
000076cd267dc4c8  movups xmm1, [r13+r12*1]
000076cd267dc4ce  movaps [r15+0x2C0], xmm1
000076cd267dc4d6  vmovaps xmm11, [rsp+0x40]
000076cd267dc4dc  vpermilpd xmm11, xmm11, 0x00
000076cd267dc4e2  vmovaps xmm8, [rsp+0xE0]
000076cd267dc4eb  movaps xmm9, xmm8
000076cd267dc4ef  mulpd xmm9, xmm11
000076cd267dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000076cd267dc4fa  ptest xmm5, xmm5
000076cd267dc4ff  jnz 0x000076CD267DFC17
000076cd267dc505  movaps xmm11, xmm10
000076cd267dc509  addpd xmm11, xmm6
000076cd267dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000076cd267dc514  ptest xmm8, xmm8
000076cd267dc51a  jnz 0x000076CD267DFD5B
000076cd267dc520  movaps xmm10, xmm14
000076cd267dc524  addpd xmm10, xmm4
000076cd267dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000076cd267dc52f  ptest xmm8, xmm8
000076cd267dc535  jnz 0x000076CD267DFE9E
000076cd267dc53b  vmovaps xmm14, [rsp+0x40]
000076cd267dc541  vpermilpd xmm14, xmm14, 0x00
000076cd267dc547  movaps xmm8, xmm1
000076cd267dc54b  mulpd xmm8, xmm14
000076cd267dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000076cd267dc556  ptest xmm6, xmm6
000076cd267dc55b  jnz 0x000076CD267DFFE1
000076cd267dc561  movaps xmm1, [r15+0x2B0]
000076cd267dc569  vmovaps xmm14, [rsp+0x40]
000076cd267dc56f  vpermilpd xmm14, xmm14, 0x00
000076cd267dc575  movaps xmm6, xmm1
000076cd267dc578  mulpd xmm6, xmm14
000076cd267dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000076cd267dc582  ptest xmm5, xmm5
000076cd267dc587  jnz 0x000076CD267E0124
000076cd267dc58d  vmovaps xmm1, [rsp+0x10]
000076cd267dc593  vpermilpd xmm1, xmm1, 0x00
000076cd267dc599  movaps xmm14, xmm12
000076cd267dc59d  mulpd xmm14, xmm1
000076cd267dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000076cd267dc5a8  ptest xmm5, xmm5
000076cd267dc5ad  jnz 0x000076CD267E0265
000076cd267dc5b3  movaps xmm1, xmm13
000076cd267dc5b7  addpd xmm1, xmm9
000076cd267dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000076cd267dc5c1  ptest xmm12, xmm12
000076cd267dc5c7  jnz 0x000076CD267E03A8
000076cd267dc5cd  vmovaps xmm13, [rsp+0x10]
000076cd267dc5d3  vpermilpd xmm13, xmm13, 0x00
000076cd267dc5d9  movaps xmm12, xmm7
000076cd267dc5dd  mulpd xmm12, xmm13
000076cd267dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000076cd267dc5e8  ptest xmm9, xmm9
000076cd267dc5ee  jnz 0x000076CD267E04EA
000076cd267dc5f4  movaps xmm13, xmm15
000076cd267dc5f8  addpd xmm13, xmm8
000076cd267dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000076cd267dc603  ptest xmm9, xmm9
000076cd267dc609  jnz 0x000076CD267E062D
000076cd267dc60f  movaps xmm15, [r15+0x290]
000076cd267dc617  vmovaps xmm9, [rsp+0x10]
000076cd267dc61d  vpermilpd xmm9, xmm9, 0x00
000076cd267dc623  movaps xmm8, xmm15
000076cd267dc627  mulpd xmm8, xmm9
000076cd267dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000076cd267dc632  ptest xmm7, xmm7
000076cd267dc637  jnz 0x000076CD267E0771
000076cd267dc63d  movaps xmm15, xmm11
000076cd267dc641  addpd xmm15, xmm6
000076cd267dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000076cd267dc64c  ptest xmm9, xmm9
000076cd267dc652  jnz 0x000076CD267E08B5
000076cd267dc658  movaps xmm11, [r15+0x1E0]
000076cd267dc660  vmovaps xmm9, [rsp+0x10]
000076cd267dc666  vpermilpd xmm9, xmm9, 0x00
000076cd267dc66c  movaps xmm7, xmm11
000076cd267dc670  mulpd xmm7, xmm9
000076cd267dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000076cd267dc67a  ptest xmm6, xmm6
000076cd267dc67f  jnz 0x000076CD267E09F8
000076cd267dc685  movaps xmm11, xmm10
000076cd267dc689  addpd xmm11, xmm14
000076cd267dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000076cd267dc694  ptest xmm9, xmm9
000076cd267dc69a  jnz 0x000076CD267E0B3A
000076cd267dc6a0  lea r12, [rax+0x70]
000076cd267dc6a4  movups xmm14, [r13+r12*1]
000076cd267dc6aa  movaps [r15+0x240], xmm14
000076cd267dc6b2  movaps xmm10, xmm1
000076cd267dc6b6  addpd xmm10, xmm12
000076cd267dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000076cd267dc6c1  ptest xmm9, xmm9
000076cd267dc6c7  jnz 0x000076CD267E0C88
000076cd267dc6cd  movaps [r15+0x170], xmm10
000076cd267dc6d5  vmovaps xmm1, [rsp+0x20]
000076cd267dc6db  vpermilpd xmm1, xmm1, 0x00
000076cd267dc6e1  movaps xmm12, xmm14
000076cd267dc6e5  mulpd xmm12, xmm1
000076cd267dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000076cd267dc6f0  ptest xmm9, xmm9
000076cd267dc6f6  jnz 0x000076CD267E0DCB
000076cd267dc6fc  vmovaps xmm1, [rsp+0x20]
000076cd267dc702  vpermilpd xmm1, xmm1, 0x00
000076cd267dc708  vmovaps xmm9, [rsp+0xB0]
000076cd267dc711  movaps xmm14, xmm9
000076cd267dc715  mulpd xmm14, xmm1
000076cd267dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000076cd267dc720  ptest xmm6, xmm6
000076cd267dc725  jnz 0x000076CD267E0F0E
000076cd267dc72b  movaps [r15+0x180], xmm14
000076cd267dc733  movaps xmm1, xmm13
000076cd267dc737  addpd xmm1, xmm8
000076cd267dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000076cd267dc741  ptest xmm9, xmm9
000076cd267dc747  jnz 0x000076CD267E1051
000076cd267dc74d  movaps [r15+0x210], xmm1
000076cd267dc755  movups xmm13, [r13+rax*1]
000076cd267dc75b  lea r12, [rax+0x10]
000076cd267dc75f  movups xmm9, [r13+r12*1]
000076cd267dc765  movaps [r15+0x230], xmm9
000076cd267dc76d  movaps xmm8, xmm15
000076cd267dc771  addpd xmm8, xmm7
000076cd267dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000076cd267dc77c  ptest xmm6, xmm6
000076cd267dc781  jnz 0x000076CD267E11A7
000076cd267dc787  movaps [r15+0x130], xmm8
000076cd267dc78f  vmovaps xmm15, [rsp+0x20]
000076cd267dc795  vpermilpd xmm15, xmm15, 0x00
000076cd267dc79b  movaps xmm7, xmm9
000076cd267dc79f  mulpd xmm7, xmm15
000076cd267dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000076cd267dc7a9  ptest xmm6, xmm6
000076cd267dc7ae  jnz 0x000076CD267E12EA
000076cd267dc7b4  movaps [r15+0x220], xmm7
000076cd267dc7bc  vmovaps xmm15, [rsp+0x20]
000076cd267dc7c2  vpermilpd xmm15, xmm15, 0x00
000076cd267dc7c8  movaps xmm9, xmm13
000076cd267dc7cc  mulpd xmm9, xmm15
000076cd267dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000076cd267dc7d7  ptest xmm6, xmm6
000076cd267dc7dc  jnz 0x000076CD267E142C
000076cd267dc7e2  movaps xmm15, xmm11
000076cd267dc7e6  addpd xmm15, xmm12
000076cd267dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000076cd267dc7f1  ptest xmm13, xmm13
000076cd267dc7f7  jnz 0x000076CD267E1570
000076cd267dc7fd  movaps [r15+0x140], xmm15
000076cd267dc805  movaps xmm13, xmm10
000076cd267dc809  addpd xmm13, xmm14
000076cd267dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000076cd267dc814  ptest xmm12, xmm12
000076cd267dc81a  jnz 0x000076CD267E16B4
000076cd267dc820  movaps [r15+0x150], xmm13
000076cd267dc828  movaps xmm14, xmm1
000076cd267dc82c  addpd xmm14, xmm7
000076cd267dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000076cd267dc837  ptest xmm12, xmm12
000076cd267dc83d  jnz 0x000076CD267E17F8
000076cd267dc843  movaps [r15+0x160], xmm14
000076cd267dc84b  movaps xmm1, xmm8
000076cd267dc84f  addpd xmm1, xmm9
000076cd267dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000076cd267dc859  ptest xmm12, xmm12
000076cd267dc85f  jnz 0x000076CD267E193A
000076cd267dc865  movaps [r15+0x120], xmm1
000076cd267dc86d  movups [r13+r14*1], xmm15
000076cd267dc873  lea rax, [r14+0x10]
000076cd267dc877  movups [r13+rax*1], xmm13
000076cd267dc87d  lea rax, [r14+0x20]
000076cd267dc881  movups [r13+rax*1], xmm14
000076cd267dc887  lea rax, [r14+0x30]
000076cd267dc88b  movups [r13+rax*1], xmm1
000076cd267dc891  mov eax, [r15+0x108]
000076cd267dc898  sahf
000076cd267dc899  jnz 0x000076CD267DC8CB
000076cd267dc89b  cmp dword ptr [r15+0x318], 0x00
000076cd267dc8a3  jz 0x000076CD267DB900
000076cd267dc8a9  nop [rax+rax*1], ax
000076cd267dc8b2  nop [rax+rax*1], eax
000076cd267dc8ba  mov eax, 0x410444
000076cd267dc8bf  mov [r15+0x100], rax
000076cd267dc8c6  jmp 0x000076CD265FE110
000076cd267dc8cb  cmp dword ptr [r15+0x318], 0x00
000076cd267dc8d3  jz 0x000076CD267D57E0
000076cd267dc8d9  nop [rax+rax*1], ax
000076cd267dc8e2  nop [rax+rax*1], eax
000076cd267dc8ea  mov eax, 0x410278
000076cd267dc8ef  mov [r15+0x100], rax
000076cd267dc8f6  jmp 0x000076CD265FE110
000076cd267dc8fb  int3
000076cd267dc8fc  call 0x000076CD266E27E0
000076cd267dc901  jmp 0x000076CD267DB9DF
000076cd267dc906  call 0x000076CD266E1570
000076cd267dc90b  jmp 0x000076CD267DB9E8
000076cd267dc910  call 0x000076CD266E27E0
000076cd267dc915  jmp 0x000076CD267DBA44
000076cd267dc91a  call 0x000076CD266E1570
000076cd267dc91f  jmp 0x000076CD267DBA4D
000076cd267dc924  call 0x000076CD266E27E0
000076cd267dc929  jmp 0x000076CD267DBA90
000076cd267dc92e  call 0x000076CD266E1570
000076cd267dc933  jmp 0x000076CD267DBA99
000076cd267dc938  call 0x000076CD2660DC20
000076cd267dc93d  jmp 0x000076CD267DBAD8
000076cd267dc942  call 0x000076CD266D59C0
000076cd267dc947  jmp 0x000076CD267DBAEB
000076cd267dc94c  call 0x000076CD266E0E30
000076cd267dc951  jmp 0x000076CD267DBB09
000076cd267dc956  call 0x000076CD266DFBC0
000076cd267dc95b  jmp 0x000076CD267DBB13
000076cd267dc960  call 0x000076CD266DE950
000076cd267dc965  jmp 0x000076CD267DBB1D
000076cd267dc96a  sub rsp, 0x08
000076cd267dc96e  push rax
000076cd267dc96f  push rcx
000076cd267dc970  push rdx
000076cd267dc971  push rdi
000076cd267dc972  push rsi
000076cd267dc973  push r8
000076cd267dc975  push r9
000076cd267dc977  push r10
000076cd267dc979  push r11
000076cd267dc97b  sub rsp, 0xF0
000076cd267dc982  vmovaps [rsp], xmm0
000076cd267dc987  vmovaps [rsp+0x10], xmm1
000076cd267dc98d  vmovaps [rsp+0x20], xmm2
000076cd267dc993  vmovaps [rsp+0x30], xmm3
000076cd267dc999  vmovaps [rsp+0x40], xmm4
000076cd267dc99f  vmovaps [rsp+0x50], xmm5
000076cd267dc9a5  vmovaps [rsp+0x60], xmm6
000076cd267dc9ab  vmovaps [rsp+0x70], xmm7
000076cd267dc9b1  vmovaps [rsp+0x80], xmm9
000076cd267dc9ba  vmovaps [rsp+0x90], xmm10
000076cd267dc9c3  vmovaps [rsp+0xA0], xmm11
000076cd267dc9cc  vmovaps [rsp+0xB0], xmm12
000076cd267dc9d5  vmovaps [rsp+0xC0], xmm13
000076cd267dc9de  vmovaps [rsp+0xD0], xmm14
000076cd267dc9e7  vmovaps [rsp+0xE0], xmm15
000076cd267dc9f0  sub rsp, 0x30
000076cd267dc9f4  movaps [rsp], xmm8
000076cd267dc9f9  movaps [rsp+0x10], xmm12
000076cd267dc9ff  movaps [rsp+0x20], xmm15
000076cd267dca05  lea rdi, [rsp]
000076cd267dca09  mov esi, 0x00
000076cd267dca0e  mov rax, 0x56B8861A9530
000076cd267dca18  call rax
000076cd267dca1a  movaps xmm8, [rsp]
000076cd267dca1f  add rsp, 0x30
000076cd267dca23  vmovaps xmm0, [rsp]
000076cd267dca28  vmovaps xmm1, [rsp+0x10]
000076cd267dca2e  vmovaps xmm2, [rsp+0x20]
000076cd267dca34  vmovaps xmm3, [rsp+0x30]
000076cd267dca3a  vmovaps xmm4, [rsp+0x40]
000076cd267dca40  vmovaps xmm5, [rsp+0x50]
000076cd267dca46  vmovaps xmm6, [rsp+0x60]
000076cd267dca4c  vmovaps xmm7, [rsp+0x70]
000076cd267dca52  vmovaps xmm9, [rsp+0x80]
000076cd267dca5b  vmovaps xmm10, [rsp+0x90]
000076cd267dca64  vmovaps xmm11, [rsp+0xA0]
000076cd267dca6d  vmovaps xmm12, [rsp+0xB0]
000076cd267dca76  vmovaps xmm13, [rsp+0xC0]
000076cd267dca7f  vmovaps xmm14, [rsp+0xD0]
000076cd267dca88  vmovaps xmm15, [rsp+0xE0]
000076cd267dca91  add rsp, 0xF0
000076cd267dca98  pop r11
000076cd267dca9a  pop r10
000076cd267dca9c  pop r9
000076cd267dca9e  pop r8
000076cd267dcaa0  pop rsi
000076cd267dcaa1  pop rdi
000076cd267dcaa2  pop rdx
000076cd267dcaa3  pop rcx
000076cd267dcaa4  pop rax
000076cd267dcaa5  add rsp, 0x08
000076cd267dcaa9  jmp 0x000076CD267DBB47
000076cd267dcaae  sub rsp, 0x08
000076cd267dcab2  push rax
000076cd267dcab3  push rcx
000076cd267dcab4  push rdx
000076cd267dcab5  push rdi
000076cd267dcab6  push rsi
000076cd267dcab7  push r8
000076cd267dcab9  push r9
000076cd267dcabb  push r10
000076cd267dcabd  push r11
000076cd267dcabf  sub rsp, 0xF0
000076cd267dcac6  vmovaps [rsp], xmm0
000076cd267dcacb  vmovaps [rsp+0x10], xmm1
000076cd267dcad1  vmovaps [rsp+0x20], xmm2
000076cd267dcad7  vmovaps [rsp+0x30], xmm3
000076cd267dcadd  vmovaps [rsp+0x40], xmm4
000076cd267dcae3  vmovaps [rsp+0x50], xmm5
000076cd267dcae9  vmovaps [rsp+0x60], xmm6
000076cd267dcaef  vmovaps [rsp+0x70], xmm8
000076cd267dcaf5  vmovaps [rsp+0x80], xmm9
000076cd267dcafe  vmovaps [rsp+0x90], xmm10
000076cd267dcb07  vmovaps [rsp+0xA0], xmm11
000076cd267dcb10  vmovaps [rsp+0xB0], xmm12
000076cd267dcb19  vmovaps [rsp+0xC0], xmm13
000076cd267dcb22  vmovaps [rsp+0xD0], xmm14
000076cd267dcb2b  vmovaps [rsp+0xE0], xmm15
000076cd267dcb34  sub rsp, 0x30
000076cd267dcb38  movaps [rsp], xmm7
000076cd267dcb3c  movaps [rsp+0x10], xmm9
000076cd267dcb42  movaps [rsp+0x20], xmm15
000076cd267dcb48  lea rdi, [rsp]
000076cd267dcb4c  mov esi, 0x00
000076cd267dcb51  mov rax, 0x56B8861A9530
000076cd267dcb5b  call rax
000076cd267dcb5d  movaps xmm7, [rsp]
000076cd267dcb61  add rsp, 0x30
000076cd267dcb65  vmovaps xmm0, [rsp]
000076cd267dcb6a  vmovaps xmm1, [rsp+0x10]
000076cd267dcb70  vmovaps xmm2, [rsp+0x20]
000076cd267dcb76  vmovaps xmm3, [rsp+0x30]
000076cd267dcb7c  vmovaps xmm4, [rsp+0x40]
000076cd267dcb82  vmovaps xmm5, [rsp+0x50]
000076cd267dcb88  vmovaps xmm6, [rsp+0x60]
000076cd267dcb8e  vmovaps xmm8, [rsp+0x70]
000076cd267dcb94  vmovaps xmm9, [rsp+0x80]
000076cd267dcb9d  vmovaps xmm10, [rsp+0x90]
000076cd267dcba6  vmovaps xmm11, [rsp+0xA0]
000076cd267dcbaf  vmovaps xmm12, [rsp+0xB0]
000076cd267dcbb8  vmovaps xmm13, [rsp+0xC0]
000076cd267dcbc1  vmovaps xmm14, [rsp+0xD0]
000076cd267dcbca  vmovaps xmm15, [rsp+0xE0]
000076cd267dcbd3  add rsp, 0xF0
000076cd267dcbda  pop r11
000076cd267dcbdc  pop r10
000076cd267dcbde  pop r9
000076cd267dcbe0  pop r8
000076cd267dcbe2  pop rsi
000076cd267dcbe3  pop rdi
000076cd267dcbe4  pop rdx
000076cd267dcbe5  pop rcx
000076cd267dcbe6  pop rax
000076cd267dcbe7  add rsp, 0x08
000076cd267dcbeb  jmp 0x000076CD267DBB75
000076cd267dcbf0  sub rsp, 0x08
000076cd267dcbf4  push rax
000076cd267dcbf5  push rcx
000076cd267dcbf6  push rdx
000076cd267dcbf7  push rdi
000076cd267dcbf8  push rsi
000076cd267dcbf9  push r8
000076cd267dcbfb  push r9
000076cd267dcbfd  push r10
000076cd267dcbff  push r11
000076cd267dcc01  sub rsp, 0xF0
000076cd267dcc08  vmovaps [rsp], xmm0
000076cd267dcc0d  vmovaps [rsp+0x10], xmm1
000076cd267dcc13  vmovaps [rsp+0x20], xmm2
000076cd267dcc19  vmovaps [rsp+0x30], xmm3
000076cd267dcc1f  vmovaps [rsp+0x40], xmm4
000076cd267dcc25  vmovaps [rsp+0x50], xmm5
000076cd267dcc2b  vmovaps [rsp+0x60], xmm6
000076cd267dcc31  vmovaps [rsp+0x70], xmm7
000076cd267dcc37  vmovaps [rsp+0x80], xmm8
000076cd267dcc40  vmovaps [rsp+0x90], xmm10
000076cd267dcc49  vmovaps [rsp+0xA0], xmm11
000076cd267dcc52  vmovaps [rsp+0xB0], xmm12
000076cd267dcc5b  vmovaps [rsp+0xC0], xmm13
000076cd267dcc64  vmovaps [rsp+0xD0], xmm14
000076cd267dcc6d  vmovaps [rsp+0xE0], xmm15
000076cd267dcc76  sub rsp, 0x30
000076cd267dcc7a  movaps [rsp], xmm9
000076cd267dcc7f  movaps [rsp+0x10], xmm12
000076cd267dcc85  movaps [rsp+0x20], xmm10
000076cd267dcc8b  lea rdi, [rsp]
000076cd267dcc8f  mov esi, 0x00
000076cd267dcc94  mov rax, 0x56B8861A9530
000076cd267dcc9e  call rax
000076cd267dcca0  movaps xmm9, [rsp]
000076cd267dcca5  add rsp, 0x30
000076cd267dcca9  vmovaps xmm0, [rsp]
000076cd267dccae  vmovaps xmm1, [rsp+0x10]
000076cd267dccb4  vmovaps xmm2, [rsp+0x20]
000076cd267dccba  vmovaps xmm3, [rsp+0x30]
000076cd267dccc0  vmovaps xmm4, [rsp+0x40]
000076cd267dccc6  vmovaps xmm5, [rsp+0x50]
000076cd267dcccc  vmovaps xmm6, [rsp+0x60]
000076cd267dccd2  vmovaps xmm7, [rsp+0x70]
000076cd267dccd8  vmovaps xmm8, [rsp+0x80]
000076cd267dcce1  vmovaps xmm10, [rsp+0x90]
000076cd267dccea  vmovaps xmm11, [rsp+0xA0]
000076cd267dccf3  vmovaps xmm12, [rsp+0xB0]
000076cd267dccfc  vmovaps xmm13, [rsp+0xC0]
000076cd267dcd05  vmovaps xmm14, [rsp+0xD0]
000076cd267dcd0e  vmovaps xmm15, [rsp+0xE0]
000076cd267dcd17  add rsp, 0xF0
000076cd267dcd1e  pop r11
000076cd267dcd20  pop r10
000076cd267dcd22  pop r9
000076cd267dcd24  pop r8
000076cd267dcd26  pop rsi
000076cd267dcd27  pop rdi
000076cd267dcd28  pop rdx
000076cd267dcd29  pop rcx
000076cd267dcd2a  pop rax
000076cd267dcd2b  add rsp, 0x08
000076cd267dcd2f  jmp 0x000076CD267DBB99
000076cd267dcd34  sub rsp, 0x08
000076cd267dcd38  push rax
000076cd267dcd39  push rcx
000076cd267dcd3a  push rdx
000076cd267dcd3b  push rdi
000076cd267dcd3c  push rsi
000076cd267dcd3d  push r8
000076cd267dcd3f  push r9
000076cd267dcd41  push r10
000076cd267dcd43  push r11
000076cd267dcd45  sub rsp, 0xF0
000076cd267dcd4c  vmovaps [rsp], xmm0
000076cd267dcd51  vmovaps [rsp+0x10], xmm1
000076cd267dcd57  vmovaps [rsp+0x20], xmm2
000076cd267dcd5d  vmovaps [rsp+0x30], xmm3
000076cd267dcd63  vmovaps [rsp+0x40], xmm4
000076cd267dcd69  vmovaps [rsp+0x50], xmm5
000076cd267dcd6f  vmovaps [rsp+0x60], xmm6
000076cd267dcd75  vmovaps [rsp+0x70], xmm7
000076cd267dcd7b  vmovaps [rsp+0x80], xmm8
000076cd267dcd84  vmovaps [rsp+0x90], xmm9
000076cd267dcd8d  vmovaps [rsp+0xA0], xmm11
000076cd267dcd96  vmovaps [rsp+0xB0], xmm12
000076cd267dcd9f  vmovaps [rsp+0xC0], xmm13
000076cd267dcda8  vmovaps [rsp+0xD0], xmm14
000076cd267dcdb1  vmovaps [rsp+0xE0], xmm15
000076cd267dcdba  sub rsp, 0x30
000076cd267dcdbe  movaps [rsp], xmm10
000076cd267dcdc3  movaps [rsp+0x10], xmm12
000076cd267dcdc9  movaps [rsp+0x20], xmm11
000076cd267dcdcf  lea rdi, [rsp]
000076cd267dcdd3  mov esi, 0x00
000076cd267dcdd8  mov rax, 0x56B8861A9530
000076cd267dcde2  call rax
000076cd267dcde4  movaps xmm10, [rsp]
000076cd267dcde9  add rsp, 0x30
000076cd267dcded  vmovaps xmm0, [rsp]
000076cd267dcdf2  vmovaps xmm1, [rsp+0x10]
000076cd267dcdf8  vmovaps xmm2, [rsp+0x20]
000076cd267dcdfe  vmovaps xmm3, [rsp+0x30]
000076cd267dce04  vmovaps xmm4, [rsp+0x40]
000076cd267dce0a  vmovaps xmm5, [rsp+0x50]
000076cd267dce10  vmovaps xmm6, [rsp+0x60]
000076cd267dce16  vmovaps xmm7, [rsp+0x70]
000076cd267dce1c  vmovaps xmm8, [rsp+0x80]
000076cd267dce25  vmovaps xmm9, [rsp+0x90]
000076cd267dce2e  vmovaps xmm11, [rsp+0xA0]
000076cd267dce37  vmovaps xmm12, [rsp+0xB0]
000076cd267dce40  vmovaps xmm13, [rsp+0xC0]
000076cd267dce49  vmovaps xmm14, [rsp+0xD0]
000076cd267dce52  vmovaps xmm15, [rsp+0xE0]
000076cd267dce5b  add rsp, 0xF0
000076cd267dce62  pop r11
000076cd267dce64  pop r10
000076cd267dce66  pop r9
000076cd267dce68  pop r8
000076cd267dce6a  pop rsi
000076cd267dce6b  pop rdi
000076cd267dce6c  pop rdx
000076cd267dce6d  pop rcx
000076cd267dce6e  pop rax
000076cd267dce6f  add rsp, 0x08
000076cd267dce73  jmp 0x000076CD267DBBB3
000076cd267dce78  sub rsp, 0x08
000076cd267dce7c  push rax
000076cd267dce7d  push rcx
000076cd267dce7e  push rdx
000076cd267dce7f  push rdi
000076cd267dce80  push rsi
000076cd267dce81  push r8
000076cd267dce83  push r9
000076cd267dce85  push r10
000076cd267dce87  push r11
000076cd267dce89  sub rsp, 0xF0
000076cd267dce90  vmovaps [rsp], xmm0
000076cd267dce95  vmovaps [rsp+0x10], xmm1
000076cd267dce9b  vmovaps [rsp+0x20], xmm2
000076cd267dcea1  vmovaps [rsp+0x30], xmm3
000076cd267dcea7  vmovaps [rsp+0x40], xmm4
000076cd267dcead  vmovaps [rsp+0x50], xmm5
000076cd267dceb3  vmovaps [rsp+0x60], xmm7
000076cd267dceb9  vmovaps [rsp+0x70], xmm8
000076cd267dcebf  vmovaps [rsp+0x80], xmm9
000076cd267dcec8  vmovaps [rsp+0x90], xmm10
000076cd267dced1  vmovaps [rsp+0xA0], xmm11
000076cd267dceda  vmovaps [rsp+0xB0], xmm12
000076cd267dcee3  vmovaps [rsp+0xC0], xmm13
000076cd267dceec  vmovaps [rsp+0xD0], xmm14
000076cd267dcef5  vmovaps [rsp+0xE0], xmm15
000076cd267dcefe  sub rsp, 0x30
000076cd267dcf02  movaps [rsp], xmm6
000076cd267dcf06  movaps [rsp+0x10], xmm12
000076cd267dcf0c  movaps [rsp+0x20], xmm11
000076cd267dcf12  lea rdi, [rsp]
000076cd267dcf16  mov esi, 0x00
000076cd267dcf1b  mov rax, 0x56B8861A9530
000076cd267dcf25  call rax
000076cd267dcf27  movaps xmm6, [rsp]
000076cd267dcf2b  add rsp, 0x30
000076cd267dcf2f  vmovaps xmm0, [rsp]
000076cd267dcf34  vmovaps xmm1, [rsp+0x10]
000076cd267dcf3a  vmovaps xmm2, [rsp+0x20]
000076cd267dcf40  vmovaps xmm3, [rsp+0x30]
000076cd267dcf46  vmovaps xmm4, [rsp+0x40]
000076cd267dcf4c  vmovaps xmm5, [rsp+0x50]
000076cd267dcf52  vmovaps xmm7, [rsp+0x60]
000076cd267dcf58  vmovaps xmm8, [rsp+0x70]
000076cd267dcf5e  vmovaps xmm9, [rsp+0x80]
000076cd267dcf67  vmovaps xmm10, [rsp+0x90]
000076cd267dcf70  vmovaps xmm11, [rsp+0xA0]
000076cd267dcf79  vmovaps xmm12, [rsp+0xB0]
000076cd267dcf82  vmovaps xmm13, [rsp+0xC0]
000076cd267dcf8b  vmovaps xmm14, [rsp+0xD0]
000076cd267dcf94  vmovaps xmm15, [rsp+0xE0]
000076cd267dcf9d  add rsp, 0xF0
000076cd267dcfa4  pop r11
000076cd267dcfa6  pop r10
000076cd267dcfa8  pop r9
000076cd267dcfaa  pop r8
000076cd267dcfac  pop rsi
000076cd267dcfad  pop rdi
000076cd267dcfae  pop rdx
000076cd267dcfaf  pop rcx
000076cd267dcfb0  pop rax
000076cd267dcfb1  add rsp, 0x08
000076cd267dcfb5  jmp 0x000076CD267DBBD4
000076cd267dcfba  sub rsp, 0x08
000076cd267dcfbe  push rax
000076cd267dcfbf  push rcx
000076cd267dcfc0  push rdx
000076cd267dcfc1  push rdi
000076cd267dcfc2  push rsi
000076cd267dcfc3  push r8
000076cd267dcfc5  push r9
000076cd267dcfc7  push r10
000076cd267dcfc9  push r11
000076cd267dcfcb  sub rsp, 0xF0
000076cd267dcfd2  vmovaps [rsp], xmm0
000076cd267dcfd7  vmovaps [rsp+0x10], xmm1
000076cd267dcfdd  vmovaps [rsp+0x20], xmm2
000076cd267dcfe3  vmovaps [rsp+0x30], xmm4
000076cd267dcfe9  vmovaps [rsp+0x40], xmm5
000076cd267dcfef  vmovaps [rsp+0x50], xmm6
000076cd267dcff5  vmovaps [rsp+0x60], xmm7
000076cd267dcffb  vmovaps [rsp+0x70], xmm8
000076cd267dd001  vmovaps [rsp+0x80], xmm9
000076cd267dd00a  vmovaps [rsp+0x90], xmm10
000076cd267dd013  vmovaps [rsp+0xA0], xmm11
000076cd267dd01c  vmovaps [rsp+0xB0], xmm12
000076cd267dd025  vmovaps [rsp+0xC0], xmm13
000076cd267dd02e  vmovaps [rsp+0xD0], xmm14
000076cd267dd037  vmovaps [rsp+0xE0], xmm15
000076cd267dd040  sub rsp, 0x30
000076cd267dd044  movaps [rsp], xmm3
000076cd267dd048  movaps [rsp+0x10], xmm5
000076cd267dd04d  movaps [rsp+0x20], xmm4
000076cd267dd052  lea rdi, [rsp]
000076cd267dd056  mov esi, 0x00
000076cd267dd05b  mov rax, 0x56B8861A9530
000076cd267dd065  call rax
000076cd267dd067  movaps xmm3, [rsp]
000076cd267dd06b  add rsp, 0x30
000076cd267dd06f  vmovaps xmm0, [rsp]
000076cd267dd074  vmovaps xmm1, [rsp+0x10]
000076cd267dd07a  vmovaps xmm2, [rsp+0x20]
000076cd267dd080  vmovaps xmm4, [rsp+0x30]
000076cd267dd086  vmovaps xmm5, [rsp+0x40]
000076cd267dd08c  vmovaps xmm6, [rsp+0x50]
000076cd267dd092  vmovaps xmm7, [rsp+0x60]
000076cd267dd098  vmovaps xmm8, [rsp+0x70]
000076cd267dd09e  vmovaps xmm9, [rsp+0x80]
000076cd267dd0a7  vmovaps xmm10, [rsp+0x90]
000076cd267dd0b0  vmovaps xmm11, [rsp+0xA0]
000076cd267dd0b9  vmovaps xmm12, [rsp+0xB0]
000076cd267dd0c2  vmovaps xmm13, [rsp+0xC0]
000076cd267dd0cb  vmovaps xmm14, [rsp+0xD0]
000076cd267dd0d4  vmovaps xmm15, [rsp+0xE0]
000076cd267dd0dd  add rsp, 0xF0
000076cd267dd0e4  pop r11
000076cd267dd0e6  pop r10
000076cd267dd0e8  pop r9
000076cd267dd0ea  pop r8
000076cd267dd0ec  pop rsi
000076cd267dd0ed  pop rdi
000076cd267dd0ee  pop rdx
000076cd267dd0ef  pop rcx
000076cd267dd0f0  pop rax
000076cd267dd0f1  add rsp, 0x08
000076cd267dd0f5  jmp 0x000076CD267DBC35
000076cd267dd0fa  sub rsp, 0x08
000076cd267dd0fe  push rax
000076cd267dd0ff  push rcx
000076cd267dd100  push rdx
000076cd267dd101  push rdi
000076cd267dd102  push rsi
000076cd267dd103  push r8
000076cd267dd105  push r9
000076cd267dd107  push r10
000076cd267dd109  push r11
000076cd267dd10b  sub rsp, 0xF0
000076cd267dd112  vmovaps [rsp], xmm0
000076cd267dd117  vmovaps [rsp+0x10], xmm1
000076cd267dd11d  vmovaps [rsp+0x20], xmm2
000076cd267dd123  vmovaps [rsp+0x30], xmm3
000076cd267dd129  vmovaps [rsp+0x40], xmm4
000076cd267dd12f  vmovaps [rsp+0x50], xmm6
000076cd267dd135  vmovaps [rsp+0x60], xmm7
000076cd267dd13b  vmovaps [rsp+0x70], xmm8
000076cd267dd141  vmovaps [rsp+0x80], xmm9
000076cd267dd14a  vmovaps [rsp+0x90], xmm10
000076cd267dd153  vmovaps [rsp+0xA0], xmm11
000076cd267dd15c  vmovaps [rsp+0xB0], xmm12
000076cd267dd165  vmovaps [rsp+0xC0], xmm13
000076cd267dd16e  vmovaps [rsp+0xD0], xmm14
000076cd267dd177  vmovaps [rsp+0xE0], xmm15
000076cd267dd180  sub rsp, 0x30
000076cd267dd184  movaps [rsp], xmm5
000076cd267dd188  movaps [rsp+0x10], xmm8
000076cd267dd18e  movaps [rsp+0x20], xmm15
000076cd267dd194  lea rdi, [rsp]
000076cd267dd198  mov esi, 0x00
000076cd267dd19d  mov rax, 0x56B8861A9530
000076cd267dd1a7  call rax
000076cd267dd1a9  movaps xmm5, [rsp]
000076cd267dd1ad  add rsp, 0x30
000076cd267dd1b1  vmovaps xmm0, [rsp]
000076cd267dd1b6  vmovaps xmm1, [rsp+0x10]
000076cd267dd1bc  vmovaps xmm2, [rsp+0x20]
000076cd267dd1c2  vmovaps xmm3, [rsp+0x30]
000076cd267dd1c8  vmovaps xmm4, [rsp+0x40]
000076cd267dd1ce  vmovaps xmm6, [rsp+0x50]
000076cd267dd1d4  vmovaps xmm7, [rsp+0x60]
000076cd267dd1da  vmovaps xmm8, [rsp+0x70]
000076cd267dd1e0  vmovaps xmm9, [rsp+0x80]
000076cd267dd1e9  vmovaps xmm10, [rsp+0x90]
000076cd267dd1f2  vmovaps xmm11, [rsp+0xA0]
000076cd267dd1fb  vmovaps xmm12, [rsp+0xB0]
000076cd267dd204  vmovaps xmm13, [rsp+0xC0]
000076cd267dd20d  vmovaps xmm14, [rsp+0xD0]
000076cd267dd216  vmovaps xmm15, [rsp+0xE0]
000076cd267dd21f  add rsp, 0xF0
000076cd267dd226  pop r11
000076cd267dd228  pop r10
000076cd267dd22a  pop r9
000076cd267dd22c  pop r8
000076cd267dd22e  pop rsi
000076cd267dd22f  pop rdi
000076cd267dd230  pop rdx
000076cd267dd231  pop rcx
000076cd267dd232  pop rax
000076cd267dd233  add rsp, 0x08
000076cd267dd237  jmp 0x000076CD267DBC73
000076cd267dd23c  sub rsp, 0x08
000076cd267dd240  push rax
000076cd267dd241  push rcx
000076cd267dd242  push rdx
000076cd267dd243  push rdi
000076cd267dd244  push rsi
000076cd267dd245  push r8
000076cd267dd247  push r9
000076cd267dd249  push r10
000076cd267dd24b  push r11
000076cd267dd24d  sub rsp, 0xF0
000076cd267dd254  vmovaps [rsp], xmm0
000076cd267dd259  vmovaps [rsp+0x10], xmm1
000076cd267dd25f  vmovaps [rsp+0x20], xmm2
000076cd267dd265  vmovaps [rsp+0x30], xmm3
000076cd267dd26b  vmovaps [rsp+0x40], xmm5
000076cd267dd271  vmovaps [rsp+0x50], xmm6
000076cd267dd277  vmovaps [rsp+0x60], xmm7
000076cd267dd27d  vmovaps [rsp+0x70], xmm8
000076cd267dd283  vmovaps [rsp+0x80], xmm9
000076cd267dd28c  vmovaps [rsp+0x90], xmm10
000076cd267dd295  vmovaps [rsp+0xA0], xmm11
000076cd267dd29e  vmovaps [rsp+0xB0], xmm12
000076cd267dd2a7  vmovaps [rsp+0xC0], xmm13
000076cd267dd2b0  vmovaps [rsp+0xD0], xmm14
000076cd267dd2b9  vmovaps [rsp+0xE0], xmm15
000076cd267dd2c2  sub rsp, 0x30
000076cd267dd2c6  movaps [rsp], xmm4
000076cd267dd2ca  movaps [rsp+0x10], xmm9
000076cd267dd2d0  movaps [rsp+0x20], xmm8
000076cd267dd2d6  lea rdi, [rsp]
000076cd267dd2da  mov esi, 0x00
000076cd267dd2df  mov rax, 0x56B8861A9530
000076cd267dd2e9  call rax
000076cd267dd2eb  movaps xmm4, [rsp]
000076cd267dd2ef  add rsp, 0x30
000076cd267dd2f3  vmovaps xmm0, [rsp]
000076cd267dd2f8  vmovaps xmm1, [rsp+0x10]
000076cd267dd2fe  vmovaps xmm2, [rsp+0x20]
000076cd267dd304  vmovaps xmm3, [rsp+0x30]
000076cd267dd30a  vmovaps xmm5, [rsp+0x40]
000076cd267dd310  vmovaps xmm6, [rsp+0x50]
000076cd267dd316  vmovaps xmm7, [rsp+0x60]
000076cd267dd31c  vmovaps xmm8, [rsp+0x70]
000076cd267dd322  vmovaps xmm9, [rsp+0x80]
000076cd267dd32b  vmovaps xmm10, [rsp+0x90]
000076cd267dd334  vmovaps xmm11, [rsp+0xA0]
000076cd267dd33d  vmovaps xmm12, [rsp+0xB0]
000076cd267dd346  vmovaps xmm13, [rsp+0xC0]
000076cd267dd34f  vmovaps xmm14, [rsp+0xD0]
000076cd267dd358  vmovaps xmm15, [rsp+0xE0]
000076cd267dd361  add rsp, 0xF0
000076cd267dd368  pop r11
000076cd267dd36a  pop r10
000076cd267dd36c  pop r9
000076cd267dd36e  pop r8
000076cd267dd370  pop rsi
000076cd267dd371  pop rdi
000076cd267dd372  pop rdx
000076cd267dd373  pop rcx
000076cd267dd374  pop rax
000076cd267dd375  add rsp, 0x08
000076cd267dd379  jmp 0x000076CD267DBC94
000076cd267dd37e  sub rsp, 0x08
000076cd267dd382  push rax
000076cd267dd383  push rcx
000076cd267dd384  push rdx
000076cd267dd385  push rdi
000076cd267dd386  push rsi
000076cd267dd387  push r8
000076cd267dd389  push r9
000076cd267dd38b  push r10
000076cd267dd38d  push r11
000076cd267dd38f  sub rsp, 0xF0
000076cd267dd396  vmovaps [rsp], xmm0
000076cd267dd39b  vmovaps [rsp+0x10], xmm1
000076cd267dd3a1  vmovaps [rsp+0x20], xmm2
000076cd267dd3a7  vmovaps [rsp+0x30], xmm3
000076cd267dd3ad  vmovaps [rsp+0x40], xmm4
000076cd267dd3b3  vmovaps [rsp+0x50], xmm5
000076cd267dd3b9  vmovaps [rsp+0x60], xmm6
000076cd267dd3bf  vmovaps [rsp+0x70], xmm7
000076cd267dd3c5  vmovaps [rsp+0x80], xmm8
000076cd267dd3ce  vmovaps [rsp+0x90], xmm10
000076cd267dd3d7  vmovaps [rsp+0xA0], xmm11
000076cd267dd3e0  vmovaps [rsp+0xB0], xmm12
000076cd267dd3e9  vmovaps [rsp+0xC0], xmm13
000076cd267dd3f2  vmovaps [rsp+0xD0], xmm14
000076cd267dd3fb  vmovaps [rsp+0xE0], xmm15
000076cd267dd404  sub rsp, 0x30
000076cd267dd408  movaps [rsp], xmm9
000076cd267dd40d  movaps [rsp+0x10], xmm10
000076cd267dd413  movaps [rsp+0x20], xmm8
000076cd267dd419  lea rdi, [rsp]
000076cd267dd41d  mov esi, 0x00
000076cd267dd422  mov rax, 0x56B8861A9530
000076cd267dd42c  call rax
000076cd267dd42e  movaps xmm9, [rsp]
000076cd267dd433  add rsp, 0x30
000076cd267dd437  vmovaps xmm0, [rsp]
000076cd267dd43c  vmovaps xmm1, [rsp+0x10]
000076cd267dd442  vmovaps xmm2, [rsp+0x20]
000076cd267dd448  vmovaps xmm3, [rsp+0x30]
000076cd267dd44e  vmovaps xmm4, [rsp+0x40]
000076cd267dd454  vmovaps xmm5, [rsp+0x50]
000076cd267dd45a  vmovaps xmm6, [rsp+0x60]
000076cd267dd460  vmovaps xmm7, [rsp+0x70]
000076cd267dd466  vmovaps xmm8, [rsp+0x80]
000076cd267dd46f  vmovaps xmm10, [rsp+0x90]
000076cd267dd478  vmovaps xmm11, [rsp+0xA0]
000076cd267dd481  vmovaps xmm12, [rsp+0xB0]
000076cd267dd48a  vmovaps xmm13, [rsp+0xC0]
000076cd267dd493  vmovaps xmm14, [rsp+0xD0]
000076cd267dd49c  vmovaps xmm15, [rsp+0xE0]
000076cd267dd4a5  add rsp, 0xF0
000076cd267dd4ac  pop r11
000076cd267dd4ae  pop r10
000076cd267dd4b0  pop r9
000076cd267dd4b2  pop r8
000076cd267dd4b4  pop rsi
000076cd267dd4b5  pop rdi
000076cd267dd4b6  pop rdx
000076cd267dd4b7  pop rcx
000076cd267dd4b8  pop rax
000076cd267dd4b9  add rsp, 0x08
000076cd267dd4bd  jmp 0x000076CD267DBCAE
000076cd267dd4c2  call 0x000076CD266B52F0
000076cd267dd4c7  jmp 0x000076CD267DBDC8
000076cd267dd4cc  call 0x000076CD266B52F0
000076cd267dd4d1  jmp 0x000076CD267DBDDE
000076cd267dd4d6  sub rsp, 0x08
000076cd267dd4da  push rax
000076cd267dd4db  push rcx
000076cd267dd4dc  push rdx
000076cd267dd4dd  push rdi
000076cd267dd4de  push rsi
000076cd267dd4df  push r8
000076cd267dd4e1  push r9
000076cd267dd4e3  push r10
000076cd267dd4e5  push r11
000076cd267dd4e7  sub rsp, 0xF0
000076cd267dd4ee  vmovaps [rsp], xmm0
000076cd267dd4f3  vmovaps [rsp+0x10], xmm2
000076cd267dd4f9  vmovaps [rsp+0x20], xmm3
000076cd267dd4ff  vmovaps [rsp+0x30], xmm4
000076cd267dd505  vmovaps [rsp+0x40], xmm5
000076cd267dd50b  vmovaps [rsp+0x50], xmm6
000076cd267dd511  vmovaps [rsp+0x60], xmm7
000076cd267dd517  vmovaps [rsp+0x70], xmm8
000076cd267dd51d  vmovaps [rsp+0x80], xmm9
000076cd267dd526  vmovaps [rsp+0x90], xmm10
000076cd267dd52f  vmovaps [rsp+0xA0], xmm11
000076cd267dd538  vmovaps [rsp+0xB0], xmm12
000076cd267dd541  vmovaps [rsp+0xC0], xmm13
000076cd267dd54a  vmovaps [rsp+0xD0], xmm14
000076cd267dd553  vmovaps [rsp+0xE0], xmm15
000076cd267dd55c  sub rsp, 0x30
000076cd267dd560  movaps [rsp], xmm1
000076cd267dd564  movaps [rsp+0x10], xmm6
000076cd267dd569  movaps [rsp+0x20], xmm15
000076cd267dd56f  lea rdi, [rsp]
000076cd267dd573  mov esi, 0x00
000076cd267dd578  mov rax, 0x56B8861A9530
000076cd267dd582  call rax
000076cd267dd584  movaps xmm1, [rsp]
000076cd267dd588  add rsp, 0x30
000076cd267dd58c  vmovaps xmm0, [rsp]
000076cd267dd591  vmovaps xmm2, [rsp+0x10]
000076cd267dd597  vmovaps xmm3, [rsp+0x20]
000076cd267dd59d  vmovaps xmm4, [rsp+0x30]
000076cd267dd5a3  vmovaps xmm5, [rsp+0x40]
000076cd267dd5a9  vmovaps xmm6, [rsp+0x50]
000076cd267dd5af  vmovaps xmm7, [rsp+0x60]
000076cd267dd5b5  vmovaps xmm8, [rsp+0x70]
000076cd267dd5bb  vmovaps xmm9, [rsp+0x80]
000076cd267dd5c4  vmovaps xmm10, [rsp+0x90]
000076cd267dd5cd  vmovaps xmm11, [rsp+0xA0]
000076cd267dd5d6  vmovaps xmm12, [rsp+0xB0]
000076cd267dd5df  vmovaps xmm13, [rsp+0xC0]
000076cd267dd5e8  vmovaps xmm14, [rsp+0xD0]
000076cd267dd5f1  vmovaps xmm15, [rsp+0xE0]
000076cd267dd5fa  add rsp, 0xF0
000076cd267dd601  pop r11
000076cd267dd603  pop r10
000076cd267dd605  pop r9
000076cd267dd607  pop r8
000076cd267dd609  pop rsi
000076cd267dd60a  pop rdi
000076cd267dd60b  pop rdx
000076cd267dd60c  pop rcx
000076cd267dd60d  pop rax
000076cd267dd60e  add rsp, 0x08
000076cd267dd612  jmp 0x000076CD267DBE1B
000076cd267dd617  call 0x000076CD266C4620
000076cd267dd61c  jmp 0x000076CD267DBE28
000076cd267dd621  sub rsp, 0x08
000076cd267dd625  push rax
000076cd267dd626  push rcx
000076cd267dd627  push rdx
000076cd267dd628  push rdi
000076cd267dd629  push rsi
000076cd267dd62a  push r8
000076cd267dd62c  push r9
000076cd267dd62e  push r10
000076cd267dd630  push r11
000076cd267dd632  sub rsp, 0xF0
000076cd267dd639  vmovaps [rsp], xmm0
000076cd267dd63e  vmovaps [rsp+0x10], xmm1
000076cd267dd644  vmovaps [rsp+0x20], xmm2
000076cd267dd64a  vmovaps [rsp+0x30], xmm3
000076cd267dd650  vmovaps [rsp+0x40], xmm4
000076cd267dd656  vmovaps [rsp+0x50], xmm5
000076cd267dd65c  vmovaps [rsp+0x60], xmm6
000076cd267dd662  vmovaps [rsp+0x70], xmm7
000076cd267dd668  vmovaps [rsp+0x80], xmm8
000076cd267dd671  vmovaps [rsp+0x90], xmm9
000076cd267dd67a  vmovaps [rsp+0xA0], xmm10
000076cd267dd683  vmovaps [rsp+0xB0], xmm11
000076cd267dd68c  vmovaps [rsp+0xC0], xmm12
000076cd267dd695  vmovaps [rsp+0xD0], xmm13
000076cd267dd69e  vmovaps [rsp+0xE0], xmm15
000076cd267dd6a7  sub rsp, 0x30
000076cd267dd6ab  movaps [rsp], xmm14
000076cd267dd6b0  movaps [rsp+0x10], xmm4
000076cd267dd6b5  movaps [rsp+0x20], xmm3
000076cd267dd6ba  lea rdi, [rsp]
000076cd267dd6be  mov esi, 0x00
000076cd267dd6c3  mov rax, 0x56B8861A9530
000076cd267dd6cd  call rax
000076cd267dd6cf  movaps xmm14, [rsp]
000076cd267dd6d4  add rsp, 0x30
000076cd267dd6d8  vmovaps xmm0, [rsp]
000076cd267dd6dd  vmovaps xmm1, [rsp+0x10]
000076cd267dd6e3  vmovaps xmm2, [rsp+0x20]
000076cd267dd6e9  vmovaps xmm3, [rsp+0x30]
000076cd267dd6ef  vmovaps xmm4, [rsp+0x40]
000076cd267dd6f5  vmovaps xmm5, [rsp+0x50]
000076cd267dd6fb  vmovaps xmm6, [rsp+0x60]
000076cd267dd701  vmovaps xmm7, [rsp+0x70]
000076cd267dd707  vmovaps xmm8, [rsp+0x80]
000076cd267dd710  vmovaps xmm9, [rsp+0x90]
000076cd267dd719  vmovaps xmm10, [rsp+0xA0]
000076cd267dd722  vmovaps xmm11, [rsp+0xB0]
000076cd267dd72b  vmovaps xmm12, [rsp+0xC0]
000076cd267dd734  vmovaps xmm13, [rsp+0xD0]
000076cd267dd73d  vmovaps xmm15, [rsp+0xE0]
000076cd267dd746  add rsp, 0xF0
000076cd267dd74d  pop r11
000076cd267dd74f  pop r10
000076cd267dd751  pop r9
000076cd267dd753  pop r8
000076cd267dd755  pop rsi
000076cd267dd756  pop rdi
000076cd267dd757  pop rdx
000076cd267dd758  pop rcx
000076cd267dd759  pop rax
000076cd267dd75a  add rsp, 0x08
000076cd267dd75e  jmp 0x000076CD267DBE42
000076cd267dd763  sub rsp, 0x08
000076cd267dd767  push rax
000076cd267dd768  push rcx
000076cd267dd769  push rdx
000076cd267dd76a  push rdi
000076cd267dd76b  push rsi
000076cd267dd76c  push r8
000076cd267dd76e  push r9
000076cd267dd770  push r10
000076cd267dd772  push r11
000076cd267dd774  sub rsp, 0xF0
000076cd267dd77b  vmovaps [rsp], xmm0
000076cd267dd780  vmovaps [rsp+0x10], xmm1
000076cd267dd786  vmovaps [rsp+0x20], xmm2
000076cd267dd78c  vmovaps [rsp+0x30], xmm3
000076cd267dd792  vmovaps [rsp+0x40], xmm4
000076cd267dd798  vmovaps [rsp+0x50], xmm5
000076cd267dd79e  vmovaps [rsp+0x60], xmm7
000076cd267dd7a4  vmovaps [rsp+0x70], xmm8
000076cd267dd7aa  vmovaps [rsp+0x80], xmm9
000076cd267dd7b3  vmovaps [rsp+0x90], xmm10
000076cd267dd7bc  vmovaps [rsp+0xA0], xmm11
000076cd267dd7c5  vmovaps [rsp+0xB0], xmm12
000076cd267dd7ce  vmovaps [rsp+0xC0], xmm13
000076cd267dd7d7  vmovaps [rsp+0xD0], xmm14
000076cd267dd7e0  vmovaps [rsp+0xE0], xmm15
000076cd267dd7e9  sub rsp, 0x30
000076cd267dd7ed  movaps [rsp], xmm6
000076cd267dd7f1  movaps [rsp+0x10], xmm9
000076cd267dd7f7  movaps [rsp+0x20], xmm7
000076cd267dd7fc  lea rdi, [rsp]
000076cd267dd800  mov esi, 0x00
000076cd267dd805  mov rax, 0x56B8861A9530
000076cd267dd80f  call rax
000076cd267dd811  movaps xmm6, [rsp]
000076cd267dd815  add rsp, 0x30
000076cd267dd819  vmovaps xmm0, [rsp]
000076cd267dd81e  vmovaps xmm1, [rsp+0x10]
000076cd267dd824  vmovaps xmm2, [rsp+0x20]
000076cd267dd82a  vmovaps xmm3, [rsp+0x30]
000076cd267dd830  vmovaps xmm4, [rsp+0x40]
000076cd267dd836  vmovaps xmm5, [rsp+0x50]
000076cd267dd83c  vmovaps xmm7, [rsp+0x60]
000076cd267dd842  vmovaps xmm8, [rsp+0x70]
000076cd267dd848  vmovaps xmm9, [rsp+0x80]
000076cd267dd851  vmovaps xmm10, [rsp+0x90]
000076cd267dd85a  vmovaps xmm11, [rsp+0xA0]
000076cd267dd863  vmovaps xmm12, [rsp+0xB0]
000076cd267dd86c  vmovaps xmm13, [rsp+0xC0]
000076cd267dd875  vmovaps xmm14, [rsp+0xD0]
000076cd267dd87e  vmovaps xmm15, [rsp+0xE0]
000076cd267dd887  add rsp, 0xF0
000076cd267dd88e  pop r11
000076cd267dd890  pop r10
000076cd267dd892  pop r9
000076cd267dd894  pop r8
000076cd267dd896  pop rsi
000076cd267dd897  pop rdi
000076cd267dd898  pop rdx
000076cd267dd899  pop rcx
000076cd267dd89a  pop rax
000076cd267dd89b  add rsp, 0x08
000076cd267dd89f  jmp 0x000076CD267DBE5A
000076cd267dd8a4  sub rsp, 0x08
000076cd267dd8a8  push rax
000076cd267dd8a9  push rcx
000076cd267dd8aa  push rdx
000076cd267dd8ab  push rdi
000076cd267dd8ac  push rsi
000076cd267dd8ad  push r8
000076cd267dd8af  push r9
000076cd267dd8b1  push r10
000076cd267dd8b3  push r11
000076cd267dd8b5  sub rsp, 0xF0
000076cd267dd8bc  vmovaps [rsp], xmm0
000076cd267dd8c1  vmovaps [rsp+0x10], xmm1
000076cd267dd8c7  vmovaps [rsp+0x20], xmm2
000076cd267dd8cd  vmovaps [rsp+0x30], xmm3
000076cd267dd8d3  vmovaps [rsp+0x40], xmm4
000076cd267dd8d9  vmovaps [rsp+0x50], xmm5
000076cd267dd8df  vmovaps [rsp+0x60], xmm6
000076cd267dd8e5  vmovaps [rsp+0x70], xmm8
000076cd267dd8eb  vmovaps [rsp+0x80], xmm9
000076cd267dd8f4  vmovaps [rsp+0x90], xmm10
000076cd267dd8fd  vmovaps [rsp+0xA0], xmm11
000076cd267dd906  vmovaps [rsp+0xB0], xmm12
000076cd267dd90f  vmovaps [rsp+0xC0], xmm13
000076cd267dd918  vmovaps [rsp+0xD0], xmm14
000076cd267dd921  vmovaps [rsp+0xE0], xmm15
000076cd267dd92a  sub rsp, 0x30
000076cd267dd92e  movaps [rsp], xmm7
000076cd267dd932  movaps [rsp+0x10], xmm4
000076cd267dd937  movaps [rsp+0x20], xmm9
000076cd267dd93d  lea rdi, [rsp]
000076cd267dd941  mov esi, 0x00
000076cd267dd946  mov rax, 0x56B8861A9530
000076cd267dd950  call rax
000076cd267dd952  movaps xmm7, [rsp]
000076cd267dd956  add rsp, 0x30
000076cd267dd95a  vmovaps xmm0, [rsp]
000076cd267dd95f  vmovaps xmm1, [rsp+0x10]
000076cd267dd965  vmovaps xmm2, [rsp+0x20]
000076cd267dd96b  vmovaps xmm3, [rsp+0x30]
000076cd267dd971  vmovaps xmm4, [rsp+0x40]
000076cd267dd977  vmovaps xmm5, [rsp+0x50]
000076cd267dd97d  vmovaps xmm6, [rsp+0x60]
000076cd267dd983  vmovaps xmm8, [rsp+0x70]
000076cd267dd989  vmovaps xmm9, [rsp+0x80]
000076cd267dd992  vmovaps xmm10, [rsp+0x90]
000076cd267dd99b  vmovaps xmm11, [rsp+0xA0]
000076cd267dd9a4  vmovaps xmm12, [rsp+0xB0]
000076cd267dd9ad  vmovaps xmm13, [rsp+0xC0]
000076cd267dd9b6  vmovaps xmm14, [rsp+0xD0]
000076cd267dd9bf  vmovaps xmm15, [rsp+0xE0]
000076cd267dd9c8  add rsp, 0xF0
000076cd267dd9cf  pop r11
000076cd267dd9d1  pop r10
000076cd267dd9d3  pop r9
000076cd267dd9d5  pop r8
000076cd267dd9d7  pop rsi
000076cd267dd9d8  pop rdi
000076cd267dd9d9  pop rdx
000076cd267dd9da  pop rcx
000076cd267dd9db  pop rax
000076cd267dd9dc  add rsp, 0x08
000076cd267dd9e0  jmp 0x000076CD267DBE87
000076cd267dd9e5  sub rsp, 0x08
000076cd267dd9e9  push rax
000076cd267dd9ea  push rcx
000076cd267dd9eb  push rdx
000076cd267dd9ec  push rdi
000076cd267dd9ed  push rsi
000076cd267dd9ee  push r8
000076cd267dd9f0  push r9
000076cd267dd9f2  push r10
000076cd267dd9f4  push r11
000076cd267dd9f6  sub rsp, 0xF0
000076cd267dd9fd  vmovaps [rsp], xmm0
000076cd267dda02  vmovaps [rsp+0x10], xmm1
000076cd267dda08  vmovaps [rsp+0x20], xmm2
000076cd267dda0e  vmovaps [rsp+0x30], xmm3
000076cd267dda14  vmovaps [rsp+0x40], xmm5
000076cd267dda1a  vmovaps [rsp+0x50], xmm6
000076cd267dda20  vmovaps [rsp+0x60], xmm7
000076cd267dda26  vmovaps [rsp+0x70], xmm8
000076cd267dda2c  vmovaps [rsp+0x80], xmm9
000076cd267dda35  vmovaps [rsp+0x90], xmm10
000076cd267dda3e  vmovaps [rsp+0xA0], xmm11
000076cd267dda47  vmovaps [rsp+0xB0], xmm12
000076cd267dda50  vmovaps [rsp+0xC0], xmm13
000076cd267dda59  vmovaps [rsp+0xD0], xmm14
000076cd267dda62  vmovaps [rsp+0xE0], xmm15
000076cd267dda6b  sub rsp, 0x30
000076cd267dda6f  movaps [rsp], xmm4
000076cd267dda73  movaps [rsp+0x10], xmm15
000076cd267dda79  movaps [rsp+0x20], xmm9
000076cd267dda7f  lea rdi, [rsp]
000076cd267dda83  mov esi, 0x00
000076cd267dda88  mov rax, 0x56B8861A9530
000076cd267dda92  call rax
000076cd267dda94  movaps xmm4, [rsp]
000076cd267dda98  add rsp, 0x30
000076cd267dda9c  vmovaps xmm0, [rsp]
000076cd267ddaa1  vmovaps xmm1, [rsp+0x10]
000076cd267ddaa7  vmovaps xmm2, [rsp+0x20]
000076cd267ddaad  vmovaps xmm3, [rsp+0x30]
000076cd267ddab3  vmovaps xmm5, [rsp+0x40]
000076cd267ddab9  vmovaps xmm6, [rsp+0x50]
000076cd267ddabf  vmovaps xmm7, [rsp+0x60]
000076cd267ddac5  vmovaps xmm8, [rsp+0x70]
000076cd267ddacb  vmovaps xmm9, [rsp+0x80]
000076cd267ddad4  vmovaps xmm10, [rsp+0x90]
000076cd267ddadd  vmovaps xmm11, [rsp+0xA0]
000076cd267ddae6  vmovaps xmm12, [rsp+0xB0]
000076cd267ddaef  vmovaps xmm13, [rsp+0xC0]
000076cd267ddaf8  vmovaps xmm14, [rsp+0xD0]
000076cd267ddb01  vmovaps xmm15, [rsp+0xE0]
000076cd267ddb0a  add rsp, 0xF0
000076cd267ddb11  pop r11
000076cd267ddb13  pop r10
000076cd267ddb15  pop r9
000076cd267ddb17  pop r8
000076cd267ddb19  pop rsi
000076cd267ddb1a  pop rdi
000076cd267ddb1b  pop rdx
000076cd267ddb1c  pop rcx
000076cd267ddb1d  pop rax
000076cd267ddb1e  add rsp, 0x08
000076cd267ddb22  jmp 0x000076CD267DBEAC
000076cd267ddb27  call 0x000076CD266C4620
000076cd267ddb2c  jmp 0x000076CD267DBEB9
000076cd267ddb31  sub rsp, 0x08
000076cd267ddb35  push rax
000076cd267ddb36  push rcx
000076cd267ddb37  push rdx
000076cd267ddb38  push rdi
000076cd267ddb39  push rsi
000076cd267ddb3a  push r8
000076cd267ddb3c  push r9
000076cd267ddb3e  push r10
000076cd267ddb40  push r11
000076cd267ddb42  sub rsp, 0xF0
000076cd267ddb49  vmovaps [rsp], xmm0
000076cd267ddb4e  vmovaps [rsp+0x10], xmm1
000076cd267ddb54  vmovaps [rsp+0x20], xmm2
000076cd267ddb5a  vmovaps [rsp+0x30], xmm4
000076cd267ddb60  vmovaps [rsp+0x40], xmm5
000076cd267ddb66  vmovaps [rsp+0x50], xmm6
000076cd267ddb6c  vmovaps [rsp+0x60], xmm7
000076cd267ddb72  vmovaps [rsp+0x70], xmm8
000076cd267ddb78  vmovaps [rsp+0x80], xmm9
000076cd267ddb81  vmovaps [rsp+0x90], xmm10
000076cd267ddb8a  vmovaps [rsp+0xA0], xmm11
000076cd267ddb93  vmovaps [rsp+0xB0], xmm12
000076cd267ddb9c  vmovaps [rsp+0xC0], xmm13
000076cd267ddba5  vmovaps [rsp+0xD0], xmm14
000076cd267ddbae  vmovaps [rsp+0xE0], xmm15
000076cd267ddbb7  sub rsp, 0x30
000076cd267ddbbb  movaps [rsp], xmm3
000076cd267ddbbf  movaps [rsp+0x10], xmm1
000076cd267ddbc4  movaps [rsp+0x20], xmm9
000076cd267ddbca  lea rdi, [rsp]
000076cd267ddbce  mov esi, 0x00
000076cd267ddbd3  mov rax, 0x56B8861A9530
000076cd267ddbdd  call rax
000076cd267ddbdf  movaps xmm3, [rsp]
000076cd267ddbe3  add rsp, 0x30
000076cd267ddbe7  vmovaps xmm0, [rsp]
000076cd267ddbec  vmovaps xmm1, [rsp+0x10]
000076cd267ddbf2  vmovaps xmm2, [rsp+0x20]
000076cd267ddbf8  vmovaps xmm4, [rsp+0x30]
000076cd267ddbfe  vmovaps xmm5, [rsp+0x40]
000076cd267ddc04  vmovaps xmm6, [rsp+0x50]
000076cd267ddc0a  vmovaps xmm7, [rsp+0x60]
000076cd267ddc10  vmovaps xmm8, [rsp+0x70]
000076cd267ddc16  vmovaps xmm9, [rsp+0x80]
000076cd267ddc1f  vmovaps xmm10, [rsp+0x90]
000076cd267ddc28  vmovaps xmm11, [rsp+0xA0]
000076cd267ddc31  vmovaps xmm12, [rsp+0xB0]
000076cd267ddc3a  vmovaps xmm13, [rsp+0xC0]
000076cd267ddc43  vmovaps xmm14, [rsp+0xD0]
000076cd267ddc4c  vmovaps xmm15, [rsp+0xE0]
000076cd267ddc55  add rsp, 0xF0
000076cd267ddc5c  pop r11
000076cd267ddc5e  pop r10
000076cd267ddc60  pop r9
000076cd267ddc62  pop r8
000076cd267ddc64  pop rsi
000076cd267ddc65  pop rdi
000076cd267ddc66  pop rdx
000076cd267ddc67  pop rcx
000076cd267ddc68  pop rax
000076cd267ddc69  add rsp, 0x08
000076cd267ddc6d  jmp 0x000076CD267DBEF6
000076cd267ddc72  sub rsp, 0x08
000076cd267ddc76  push rax
000076cd267ddc77  push rcx
000076cd267ddc78  push rdx
000076cd267ddc79  push rdi
000076cd267ddc7a  push rsi
000076cd267ddc7b  push r8
000076cd267ddc7d  push r9
000076cd267ddc7f  push r10
000076cd267ddc81  push r11
000076cd267ddc83  sub rsp, 0xF0
000076cd267ddc8a  vmovaps [rsp], xmm0
000076cd267ddc8f  vmovaps [rsp+0x10], xmm2
000076cd267ddc95  vmovaps [rsp+0x20], xmm3
000076cd267ddc9b  vmovaps [rsp+0x30], xmm4
000076cd267ddca1  vmovaps [rsp+0x40], xmm5
000076cd267ddca7  vmovaps [rsp+0x50], xmm6
000076cd267ddcad  vmovaps [rsp+0x60], xmm7
000076cd267ddcb3  vmovaps [rsp+0x70], xmm8
000076cd267ddcb9  vmovaps [rsp+0x80], xmm9
000076cd267ddcc2  vmovaps [rsp+0x90], xmm10
000076cd267ddccb  vmovaps [rsp+0xA0], xmm11
000076cd267ddcd4  vmovaps [rsp+0xB0], xmm12
000076cd267ddcdd  vmovaps [rsp+0xC0], xmm13
000076cd267ddce6  vmovaps [rsp+0xD0], xmm14
000076cd267ddcef  vmovaps [rsp+0xE0], xmm15
000076cd267ddcf8  sub rsp, 0x30
000076cd267ddcfc  movaps [rsp], xmm1
000076cd267ddd00  movaps [rsp+0x10], xmm15
000076cd267ddd06  movaps [rsp+0x20], xmm9
000076cd267ddd0c  lea rdi, [rsp]
000076cd267ddd10  mov esi, 0x00
000076cd267ddd15  mov rax, 0x56B8861A9530
000076cd267ddd1f  call rax
000076cd267ddd21  movaps xmm1, [rsp]
000076cd267ddd25  add rsp, 0x30
000076cd267ddd29  vmovaps xmm0, [rsp]
000076cd267ddd2e  vmovaps xmm2, [rsp+0x10]
000076cd267ddd34  vmovaps xmm3, [rsp+0x20]
000076cd267ddd3a  vmovaps xmm4, [rsp+0x30]
000076cd267ddd40  vmovaps xmm5, [rsp+0x40]
000076cd267ddd46  vmovaps xmm6, [rsp+0x50]
000076cd267ddd4c  vmovaps xmm7, [rsp+0x60]
000076cd267ddd52  vmovaps xmm8, [rsp+0x70]
000076cd267ddd58  vmovaps xmm9, [rsp+0x80]
000076cd267ddd61  vmovaps xmm10, [rsp+0x90]
000076cd267ddd6a  vmovaps xmm11, [rsp+0xA0]
000076cd267ddd73  vmovaps xmm12, [rsp+0xB0]
000076cd267ddd7c  vmovaps xmm13, [rsp+0xC0]
000076cd267ddd85  vmovaps xmm14, [rsp+0xD0]
000076cd267ddd8e  vmovaps xmm15, [rsp+0xE0]
000076cd267ddd97  add rsp, 0xF0
000076cd267ddd9e  pop r11
000076cd267ddda0  pop r10
000076cd267ddda2  pop r9
000076cd267ddda4  pop r8
000076cd267ddda6  pop rsi
000076cd267ddda7  pop rdi
000076cd267ddda8  pop rdx
000076cd267ddda9  pop rcx
000076cd267dddaa  pop rax
000076cd267dddab  add rsp, 0x08
000076cd267dddaf  jmp 0x000076CD267DBF7E
000076cd267dddb4  call 0x000076CD266C4620
000076cd267dddb9  jmp 0x000076CD267DBF8B
000076cd267dddbe  sub rsp, 0x08
000076cd267dddc2  push rax
000076cd267dddc3  push rcx
000076cd267dddc4  push rdx
000076cd267dddc5  push rdi
000076cd267dddc6  push rsi
000076cd267dddc7  push r8
000076cd267dddc9  push r9
000076cd267dddcb  push r10
000076cd267dddcd  push r11
000076cd267dddcf  sub rsp, 0xF0
000076cd267dddd6  vmovaps [rsp], xmm0
000076cd267ddddb  vmovaps [rsp+0x10], xmm2
000076cd267ddde1  vmovaps [rsp+0x20], xmm3
000076cd267ddde7  vmovaps [rsp+0x30], xmm4
000076cd267ddded  vmovaps [rsp+0x40], xmm5
000076cd267dddf3  vmovaps [rsp+0x50], xmm6
000076cd267dddf9  vmovaps [rsp+0x60], xmm7
000076cd267dddff  vmovaps [rsp+0x70], xmm8
000076cd267dde05  vmovaps [rsp+0x80], xmm9
000076cd267dde0e  vmovaps [rsp+0x90], xmm10
000076cd267dde17  vmovaps [rsp+0xA0], xmm11
000076cd267dde20  vmovaps [rsp+0xB0], xmm12
000076cd267dde29  vmovaps [rsp+0xC0], xmm13
000076cd267dde32  vmovaps [rsp+0xD0], xmm14
000076cd267dde3b  vmovaps [rsp+0xE0], xmm15
000076cd267dde44  sub rsp, 0x30
000076cd267dde48  movaps [rsp], xmm1
000076cd267dde4c  movaps [rsp+0x10], xmm5
000076cd267dde51  movaps [rsp+0x20], xmm7
000076cd267dde56  lea rdi, [rsp]
000076cd267dde5a  mov esi, 0x00
000076cd267dde5f  mov rax, 0x56B8861A9530
000076cd267dde69  call rax
000076cd267dde6b  movaps xmm1, [rsp]
000076cd267dde6f  add rsp, 0x30
000076cd267dde73  vmovaps xmm0, [rsp]
000076cd267dde78  vmovaps xmm2, [rsp+0x10]
000076cd267dde7e  vmovaps xmm3, [rsp+0x20]
000076cd267dde84  vmovaps xmm4, [rsp+0x30]
000076cd267dde8a  vmovaps xmm5, [rsp+0x40]
000076cd267dde90  vmovaps xmm6, [rsp+0x50]
000076cd267dde96  vmovaps xmm7, [rsp+0x60]
000076cd267dde9c  vmovaps xmm8, [rsp+0x70]
000076cd267ddea2  vmovaps xmm9, [rsp+0x80]
000076cd267ddeab  vmovaps xmm10, [rsp+0x90]
000076cd267ddeb4  vmovaps xmm11, [rsp+0xA0]
000076cd267ddebd  vmovaps xmm12, [rsp+0xB0]
000076cd267ddec6  vmovaps xmm13, [rsp+0xC0]
000076cd267ddecf  vmovaps xmm14, [rsp+0xD0]
000076cd267dded8  vmovaps xmm15, [rsp+0xE0]
000076cd267ddee1  add rsp, 0xF0
000076cd267ddee8  pop r11
000076cd267ddeea  pop r10
000076cd267ddeec  pop r9
000076cd267ddeee  pop r8
000076cd267ddef0  pop rsi
000076cd267ddef1  pop rdi
000076cd267ddef2  pop rdx
000076cd267ddef3  pop rcx
000076cd267ddef4  pop rax
000076cd267ddef5  add rsp, 0x08
000076cd267ddef9  jmp 0x000076CD267DC030
000076cd267ddefe  sub rsp, 0x08
000076cd267ddf02  push rax
000076cd267ddf03  push rcx
000076cd267ddf04  push rdx
000076cd267ddf05  push rdi
000076cd267ddf06  push rsi
000076cd267ddf07  push r8
000076cd267ddf09  push r9
000076cd267ddf0b  push r10
000076cd267ddf0d  push r11
000076cd267ddf0f  sub rsp, 0xF0
000076cd267ddf16  vmovaps [rsp], xmm0
000076cd267ddf1b  vmovaps [rsp+0x10], xmm1
000076cd267ddf21  vmovaps [rsp+0x20], xmm2
000076cd267ddf27  vmovaps [rsp+0x30], xmm3
000076cd267ddf2d  vmovaps [rsp+0x40], xmm4
000076cd267ddf33  vmovaps [rsp+0x50], xmm5
000076cd267ddf39  vmovaps [rsp+0x60], xmm6
000076cd267ddf3f  vmovaps [rsp+0x70], xmm8
000076cd267ddf45  vmovaps [rsp+0x80], xmm9
000076cd267ddf4e  vmovaps [rsp+0x90], xmm10
000076cd267ddf57  vmovaps [rsp+0xA0], xmm11
000076cd267ddf60  vmovaps [rsp+0xB0], xmm12
000076cd267ddf69  vmovaps [rsp+0xC0], xmm13
000076cd267ddf72  vmovaps [rsp+0xD0], xmm14
000076cd267ddf7b  vmovaps [rsp+0xE0], xmm15
000076cd267ddf84  sub rsp, 0x30
000076cd267ddf88  movaps [rsp], xmm7
000076cd267ddf8c  movaps [rsp+0x10], xmm5
000076cd267ddf91  movaps [rsp+0x20], xmm15
000076cd267ddf97  lea rdi, [rsp]
000076cd267ddf9b  mov esi, 0x00
000076cd267ddfa0  mov rax, 0x56B8861A9530
000076cd267ddfaa  call rax
000076cd267ddfac  movaps xmm7, [rsp]
000076cd267ddfb0  add rsp, 0x30
000076cd267ddfb4  vmovaps xmm0, [rsp]
000076cd267ddfb9  vmovaps xmm1, [rsp+0x10]
000076cd267ddfbf  vmovaps xmm2, [rsp+0x20]
000076cd267ddfc5  vmovaps xmm3, [rsp+0x30]
000076cd267ddfcb  vmovaps xmm4, [rsp+0x40]
000076cd267ddfd1  vmovaps xmm5, [rsp+0x50]
000076cd267ddfd7  vmovaps xmm6, [rsp+0x60]
000076cd267ddfdd  vmovaps xmm8, [rsp+0x70]
000076cd267ddfe3  vmovaps xmm9, [rsp+0x80]
000076cd267ddfec  vmovaps xmm10, [rsp+0x90]
000076cd267ddff5  vmovaps xmm11, [rsp+0xA0]
000076cd267ddffe  vmovaps xmm12, [rsp+0xB0]
000076cd267de007  vmovaps xmm13, [rsp+0xC0]
000076cd267de010  vmovaps xmm14, [rsp+0xD0]
000076cd267de019  vmovaps xmm15, [rsp+0xE0]
000076cd267de022  add rsp, 0xF0
000076cd267de029  pop r11
000076cd267de02b  pop r10
000076cd267de02d  pop r9
000076cd267de02f  pop r8
000076cd267de031  pop rsi
000076cd267de032  pop rdi
000076cd267de033  pop rdx
000076cd267de034  pop rcx
000076cd267de035  pop rax
000076cd267de036  add rsp, 0x08
000076cd267de03a  jmp 0x000076CD267DC066
000076cd267de03f  call 0x000076CD266B52F0
000076cd267de044  jmp 0x000076CD267DC073
000076cd267de049  sub rsp, 0x08
000076cd267de04d  push rax
000076cd267de04e  push rcx
000076cd267de04f  push rdx
000076cd267de050  push rdi
000076cd267de051  push rsi
000076cd267de052  push r8
000076cd267de054  push r9
000076cd267de056  push r10
000076cd267de058  push r11
000076cd267de05a  sub rsp, 0xF0
000076cd267de061  vmovaps [rsp], xmm0
000076cd267de066  vmovaps [rsp+0x10], xmm1
000076cd267de06c  vmovaps [rsp+0x20], xmm2
000076cd267de072  vmovaps [rsp+0x30], xmm3
000076cd267de078  vmovaps [rsp+0x40], xmm4
000076cd267de07e  vmovaps [rsp+0x50], xmm5
000076cd267de084  vmovaps [rsp+0x60], xmm6
000076cd267de08a  vmovaps [rsp+0x70], xmm7
000076cd267de090  vmovaps [rsp+0x80], xmm8
000076cd267de099  vmovaps [rsp+0x90], xmm9
000076cd267de0a2  vmovaps [rsp+0xA0], xmm10
000076cd267de0ab  vmovaps [rsp+0xB0], xmm11
000076cd267de0b4  vmovaps [rsp+0xC0], xmm12
000076cd267de0bd  vmovaps [rsp+0xD0], xmm13
000076cd267de0c6  vmovaps [rsp+0xE0], xmm14
000076cd267de0cf  sub rsp, 0x30
000076cd267de0d3  movaps [rsp], xmm15
000076cd267de0d8  movaps [rsp+0x10], xmm5
000076cd267de0dd  movaps [rsp+0x20], xmm3
000076cd267de0e2  lea rdi, [rsp]
000076cd267de0e6  mov esi, 0x00
000076cd267de0eb  mov rax, 0x56B8861A9530
000076cd267de0f5  call rax
000076cd267de0f7  movaps xmm15, [rsp]
000076cd267de0fc  add rsp, 0x30
000076cd267de100  vmovaps xmm0, [rsp]
000076cd267de105  vmovaps xmm1, [rsp+0x10]
000076cd267de10b  vmovaps xmm2, [rsp+0x20]
000076cd267de111  vmovaps xmm3, [rsp+0x30]
000076cd267de117  vmovaps xmm4, [rsp+0x40]
000076cd267de11d  vmovaps xmm5, [rsp+0x50]
000076cd267de123  vmovaps xmm6, [rsp+0x60]
000076cd267de129  vmovaps xmm7, [rsp+0x70]
000076cd267de12f  vmovaps xmm8, [rsp+0x80]
000076cd267de138  vmovaps xmm9, [rsp+0x90]
000076cd267de141  vmovaps xmm10, [rsp+0xA0]
000076cd267de14a  vmovaps xmm11, [rsp+0xB0]
000076cd267de153  vmovaps xmm12, [rsp+0xC0]
000076cd267de15c  vmovaps xmm13, [rsp+0xD0]
000076cd267de165  vmovaps xmm14, [rsp+0xE0]
000076cd267de16e  add rsp, 0xF0
000076cd267de175  pop r11
000076cd267de177  pop r10
000076cd267de179  pop r9
000076cd267de17b  pop r8
000076cd267de17d  pop rsi
000076cd267de17e  pop rdi
000076cd267de17f  pop rdx
000076cd267de180  pop rcx
000076cd267de181  pop rax
000076cd267de182  add rsp, 0x08
000076cd267de186  jmp 0x000076CD267DC099
000076cd267de18b  sub rsp, 0x08
000076cd267de18f  push rax
000076cd267de190  push rcx
000076cd267de191  push rdx
000076cd267de192  push rdi
000076cd267de193  push rsi
000076cd267de194  push r8
000076cd267de196  push r9
000076cd267de198  push r10
000076cd267de19a  push r11
000076cd267de19c  sub rsp, 0xF0
000076cd267de1a3  vmovaps [rsp], xmm0
000076cd267de1a8  vmovaps [rsp+0x10], xmm2
000076cd267de1ae  vmovaps [rsp+0x20], xmm3
000076cd267de1b4  vmovaps [rsp+0x30], xmm4
000076cd267de1ba  vmovaps [rsp+0x40], xmm5
000076cd267de1c0  vmovaps [rsp+0x50], xmm6
000076cd267de1c6  vmovaps [rsp+0x60], xmm7
000076cd267de1cc  vmovaps [rsp+0x70], xmm8
000076cd267de1d2  vmovaps [rsp+0x80], xmm9
000076cd267de1db  vmovaps [rsp+0x90], xmm10
000076cd267de1e4  vmovaps [rsp+0xA0], xmm11
000076cd267de1ed  vmovaps [rsp+0xB0], xmm12
000076cd267de1f6  vmovaps [rsp+0xC0], xmm13
000076cd267de1ff  vmovaps [rsp+0xD0], xmm14
000076cd267de208  vmovaps [rsp+0xE0], xmm15
000076cd267de211  sub rsp, 0x30
000076cd267de215  movaps [rsp], xmm1
000076cd267de219  movaps [rsp+0x10], xmm5
000076cd267de21e  movaps [rsp+0x20], xmm4
000076cd267de223  lea rdi, [rsp]
000076cd267de227  mov esi, 0x00
000076cd267de22c  mov rax, 0x56B8861A9530
000076cd267de236  call rax
000076cd267de238  movaps xmm1, [rsp]
000076cd267de23c  add rsp, 0x30
000076cd267de240  vmovaps xmm0, [rsp]
000076cd267de245  vmovaps xmm2, [rsp+0x10]
000076cd267de24b  vmovaps xmm3, [rsp+0x20]
000076cd267de251  vmovaps xmm4, [rsp+0x30]
000076cd267de257  vmovaps xmm5, [rsp+0x40]
000076cd267de25d  vmovaps xmm6, [rsp+0x50]
000076cd267de263  vmovaps xmm7, [rsp+0x60]
000076cd267de269  vmovaps xmm8, [rsp+0x70]
000076cd267de26f  vmovaps xmm9, [rsp+0x80]
000076cd267de278  vmovaps xmm10, [rsp+0x90]
000076cd267de281  vmovaps xmm11, [rsp+0xA0]
000076cd267de28a  vmovaps xmm12, [rsp+0xB0]
000076cd267de293  vmovaps xmm13, [rsp+0xC0]
000076cd267de29c  vmovaps xmm14, [rsp+0xD0]
000076cd267de2a5  vmovaps xmm15, [rsp+0xE0]
000076cd267de2ae  add rsp, 0xF0
000076cd267de2b5  pop r11
000076cd267de2b7  pop r10
000076cd267de2b9  pop r9
000076cd267de2bb  pop r8
000076cd267de2bd  pop rsi
000076cd267de2be  pop rdi
000076cd267de2bf  pop rdx
000076cd267de2c0  pop rcx
000076cd267de2c1  pop rax
000076cd267de2c2  add rsp, 0x08
000076cd267de2c6  jmp 0x000076CD267DC0B9
000076cd267de2cb  sub rsp, 0x08
000076cd267de2cf  push rax
000076cd267de2d0  push rcx
000076cd267de2d1  push rdx
000076cd267de2d2  push rdi
000076cd267de2d3  push rsi
000076cd267de2d4  push r8
000076cd267de2d6  push r9
000076cd267de2d8  push r10
000076cd267de2da  push r11
000076cd267de2dc  sub rsp, 0xF0
000076cd267de2e3  vmovaps [rsp], xmm0
000076cd267de2e8  vmovaps [rsp+0x10], xmm1
000076cd267de2ee  vmovaps [rsp+0x20], xmm2
000076cd267de2f4  vmovaps [rsp+0x30], xmm3
000076cd267de2fa  vmovaps [rsp+0x40], xmm5
000076cd267de300  vmovaps [rsp+0x50], xmm6
000076cd267de306  vmovaps [rsp+0x60], xmm7
000076cd267de30c  vmovaps [rsp+0x70], xmm8
000076cd267de312  vmovaps [rsp+0x80], xmm9
000076cd267de31b  vmovaps [rsp+0x90], xmm10
000076cd267de324  vmovaps [rsp+0xA0], xmm11
000076cd267de32d  vmovaps [rsp+0xB0], xmm12
000076cd267de336  vmovaps [rsp+0xC0], xmm13
000076cd267de33f  vmovaps [rsp+0xD0], xmm14
000076cd267de348  vmovaps [rsp+0xE0], xmm15
000076cd267de351  sub rsp, 0x30
000076cd267de355  movaps [rsp], xmm4
000076cd267de359  movaps [rsp+0x10], xmm3
000076cd267de35e  movaps [rsp+0x20], xmm5
000076cd267de363  lea rdi, [rsp]
000076cd267de367  mov esi, 0x00
000076cd267de36c  mov rax, 0x56B8861A9530
000076cd267de376  call rax
000076cd267de378  movaps xmm4, [rsp]
000076cd267de37c  add rsp, 0x30
000076cd267de380  vmovaps xmm0, [rsp]
000076cd267de385  vmovaps xmm1, [rsp+0x10]
000076cd267de38b  vmovaps xmm2, [rsp+0x20]
000076cd267de391  vmovaps xmm3, [rsp+0x30]
000076cd267de397  vmovaps xmm5, [rsp+0x40]
000076cd267de39d  vmovaps xmm6, [rsp+0x50]
000076cd267de3a3  vmovaps xmm7, [rsp+0x60]
000076cd267de3a9  vmovaps xmm8, [rsp+0x70]
000076cd267de3af  vmovaps xmm9, [rsp+0x80]
000076cd267de3b8  vmovaps xmm10, [rsp+0x90]
000076cd267de3c1  vmovaps xmm11, [rsp+0xA0]
000076cd267de3ca  vmovaps xmm12, [rsp+0xB0]
000076cd267de3d3  vmovaps xmm13, [rsp+0xC0]
000076cd267de3dc  vmovaps xmm14, [rsp+0xD0]
000076cd267de3e5  vmovaps xmm15, [rsp+0xE0]
000076cd267de3ee  add rsp, 0xF0
000076cd267de3f5  pop r11
000076cd267de3f7  pop r10
000076cd267de3f9  pop r9
000076cd267de3fb  pop r8
000076cd267de3fd  pop rsi
000076cd267de3fe  pop rdi
000076cd267de3ff  pop rdx
000076cd267de400  pop rcx
000076cd267de401  pop rax
000076cd267de402  add rsp, 0x08
000076cd267de406  jmp 0x000076CD267DC107
000076cd267de40b  call 0x000076CD266B52F0
000076cd267de410  jmp 0x000076CD267DC114
000076cd267de415  sub rsp, 0x08
000076cd267de419  push rax
000076cd267de41a  push rcx
000076cd267de41b  push rdx
000076cd267de41c  push rdi
000076cd267de41d  push rsi
000076cd267de41e  push r8
000076cd267de420  push r9
000076cd267de422  push r10
000076cd267de424  push r11
000076cd267de426  sub rsp, 0xF0
000076cd267de42d  vmovaps [rsp], xmm0
000076cd267de432  vmovaps [rsp+0x10], xmm1
000076cd267de438  vmovaps [rsp+0x20], xmm2
000076cd267de43e  vmovaps [rsp+0x30], xmm3
000076cd267de444  vmovaps [rsp+0x40], xmm4
000076cd267de44a  vmovaps [rsp+0x50], xmm6
000076cd267de450  vmovaps [rsp+0x60], xmm7
000076cd267de456  vmovaps [rsp+0x70], xmm8
000076cd267de45c  vmovaps [rsp+0x80], xmm9
000076cd267de465  vmovaps [rsp+0x90], xmm10
000076cd267de46e  vmovaps [rsp+0xA0], xmm11
000076cd267de477  vmovaps [rsp+0xB0], xmm12
000076cd267de480  vmovaps [rsp+0xC0], xmm13
000076cd267de489  vmovaps [rsp+0xD0], xmm14
000076cd267de492  vmovaps [rsp+0xE0], xmm15
000076cd267de49b  sub rsp, 0x30
000076cd267de49f  movaps [rsp], xmm5
000076cd267de4a3  movaps [rsp+0x10], xmm6
000076cd267de4a8  movaps [rsp+0x20], xmm3
000076cd267de4ad  lea rdi, [rsp]
000076cd267de4b1  mov esi, 0x00
000076cd267de4b6  mov rax, 0x56B8861A9530
000076cd267de4c0  call rax
000076cd267de4c2  movaps xmm5, [rsp]
000076cd267de4c6  add rsp, 0x30
000076cd267de4ca  vmovaps xmm0, [rsp]
000076cd267de4cf  vmovaps xmm1, [rsp+0x10]
000076cd267de4d5  vmovaps xmm2, [rsp+0x20]
000076cd267de4db  vmovaps xmm3, [rsp+0x30]
000076cd267de4e1  vmovaps xmm4, [rsp+0x40]
000076cd267de4e7  vmovaps xmm6, [rsp+0x50]
000076cd267de4ed  vmovaps xmm7, [rsp+0x60]
000076cd267de4f3  vmovaps xmm8, [rsp+0x70]
000076cd267de4f9  vmovaps xmm9, [rsp+0x80]
000076cd267de502  vmovaps xmm10, [rsp+0x90]
000076cd267de50b  vmovaps xmm11, [rsp+0xA0]
000076cd267de514  vmovaps xmm12, [rsp+0xB0]
000076cd267de51d  vmovaps xmm13, [rsp+0xC0]
000076cd267de526  vmovaps xmm14, [rsp+0xD0]
000076cd267de52f  vmovaps xmm15, [rsp+0xE0]
000076cd267de538  add rsp, 0xF0
000076cd267de53f  pop r11
000076cd267de541  pop r10
000076cd267de543  pop r9
000076cd267de545  pop r8
000076cd267de547  pop rsi
000076cd267de548  pop rdi
000076cd267de549  pop rdx
000076cd267de54a  pop rcx
000076cd267de54b  pop rax
000076cd267de54c  add rsp, 0x08
000076cd267de550  jmp 0x000076CD267DC13A
000076cd267de555  sub rsp, 0x08
000076cd267de559  push rax
000076cd267de55a  push rcx
000076cd267de55b  push rdx
000076cd267de55c  push rdi
000076cd267de55d  push rsi
000076cd267de55e  push r8
000076cd267de560  push r9
000076cd267de562  push r10
000076cd267de564  push r11
000076cd267de566  sub rsp, 0xF0
000076cd267de56d  vmovaps [rsp], xmm0
000076cd267de572  vmovaps [rsp+0x10], xmm1
000076cd267de578  vmovaps [rsp+0x20], xmm2
000076cd267de57e  vmovaps [rsp+0x30], xmm3
000076cd267de584  vmovaps [rsp+0x40], xmm4
000076cd267de58a  vmovaps [rsp+0x50], xmm5
000076cd267de590  vmovaps [rsp+0x60], xmm7
000076cd267de596  vmovaps [rsp+0x70], xmm8
000076cd267de59c  vmovaps [rsp+0x80], xmm9
000076cd267de5a5  vmovaps [rsp+0x90], xmm10
000076cd267de5ae  vmovaps [rsp+0xA0], xmm11
000076cd267de5b7  vmovaps [rsp+0xB0], xmm12
000076cd267de5c0  vmovaps [rsp+0xC0], xmm13
000076cd267de5c9  vmovaps [rsp+0xD0], xmm14
000076cd267de5d2  vmovaps [rsp+0xE0], xmm15
000076cd267de5db  sub rsp, 0x30
000076cd267de5df  movaps [rsp], xmm6
000076cd267de5e3  movaps [rsp+0x10], xmm9
000076cd267de5e9  movaps [rsp+0x20], xmm1
000076cd267de5ee  lea rdi, [rsp]
000076cd267de5f2  mov esi, 0x00
000076cd267de5f7  mov rax, 0x56B8861A9530
000076cd267de601  call rax
000076cd267de603  movaps xmm6, [rsp]
000076cd267de607  add rsp, 0x30
000076cd267de60b  vmovaps xmm0, [rsp]
000076cd267de610  vmovaps xmm1, [rsp+0x10]
000076cd267de616  vmovaps xmm2, [rsp+0x20]
000076cd267de61c  vmovaps xmm3, [rsp+0x30]
000076cd267de622  vmovaps xmm4, [rsp+0x40]
000076cd267de628  vmovaps xmm5, [rsp+0x50]
000076cd267de62e  vmovaps xmm7, [rsp+0x60]
000076cd267de634  vmovaps xmm8, [rsp+0x70]
000076cd267de63a  vmovaps xmm9, [rsp+0x80]
000076cd267de643  vmovaps xmm10, [rsp+0x90]
000076cd267de64c  vmovaps xmm11, [rsp+0xA0]
000076cd267de655  vmovaps xmm12, [rsp+0xB0]
000076cd267de65e  vmovaps xmm13, [rsp+0xC0]
000076cd267de667  vmovaps xmm14, [rsp+0xD0]
000076cd267de670  vmovaps xmm15, [rsp+0xE0]
000076cd267de679  add rsp, 0xF0
000076cd267de680  pop r11
000076cd267de682  pop r10
000076cd267de684  pop r9
000076cd267de686  pop r8
000076cd267de688  pop rsi
000076cd267de689  pop rdi
000076cd267de68a  pop rdx
000076cd267de68b  pop rcx
000076cd267de68c  pop rax
000076cd267de68d  add rsp, 0x08
000076cd267de691  jmp 0x000076CD267DC15E
000076cd267de696  sub rsp, 0x08
000076cd267de69a  push rax
000076cd267de69b  push rcx
000076cd267de69c  push rdx
000076cd267de69d  push rdi
000076cd267de69e  push rsi
000076cd267de69f  push r8
000076cd267de6a1  push r9
000076cd267de6a3  push r10
000076cd267de6a5  push r11
000076cd267de6a7  sub rsp, 0xF0
000076cd267de6ae  vmovaps [rsp], xmm0
000076cd267de6b3  vmovaps [rsp+0x10], xmm1
000076cd267de6b9  vmovaps [rsp+0x20], xmm2
000076cd267de6bf  vmovaps [rsp+0x30], xmm3
000076cd267de6c5  vmovaps [rsp+0x40], xmm4
000076cd267de6cb  vmovaps [rsp+0x50], xmm5
000076cd267de6d1  vmovaps [rsp+0x60], xmm6
000076cd267de6d7  vmovaps [rsp+0x70], xmm7
000076cd267de6dd  vmovaps [rsp+0x80], xmm8
000076cd267de6e6  vmovaps [rsp+0x90], xmm10
000076cd267de6ef  vmovaps [rsp+0xA0], xmm11
000076cd267de6f8  vmovaps [rsp+0xB0], xmm12
000076cd267de701  vmovaps [rsp+0xC0], xmm13
000076cd267de70a  vmovaps [rsp+0xD0], xmm14
000076cd267de713  vmovaps [rsp+0xE0], xmm15
000076cd267de71c  sub rsp, 0x30
000076cd267de720  movaps [rsp], xmm9
000076cd267de725  movaps [rsp+0x10], xmm3
000076cd267de72a  movaps [rsp+0x20], xmm1
000076cd267de72f  lea rdi, [rsp]
000076cd267de733  mov esi, 0x00
000076cd267de738  mov rax, 0x56B8861A9530
000076cd267de742  call rax
000076cd267de744  movaps xmm9, [rsp]
000076cd267de749  add rsp, 0x30
000076cd267de74d  vmovaps xmm0, [rsp]
000076cd267de752  vmovaps xmm1, [rsp+0x10]
000076cd267de758  vmovaps xmm2, [rsp+0x20]
000076cd267de75e  vmovaps xmm3, [rsp+0x30]
000076cd267de764  vmovaps xmm4, [rsp+0x40]
000076cd267de76a  vmovaps xmm5, [rsp+0x50]
000076cd267de770  vmovaps xmm6, [rsp+0x60]
000076cd267de776  vmovaps xmm7, [rsp+0x70]
000076cd267de77c  vmovaps xmm8, [rsp+0x80]
000076cd267de785  vmovaps xmm10, [rsp+0x90]
000076cd267de78e  vmovaps xmm11, [rsp+0xA0]
000076cd267de797  vmovaps xmm12, [rsp+0xB0]
000076cd267de7a0  vmovaps xmm13, [rsp+0xC0]
000076cd267de7a9  vmovaps xmm14, [rsp+0xD0]
000076cd267de7b2  vmovaps xmm15, [rsp+0xE0]
000076cd267de7bb  add rsp, 0xF0
000076cd267de7c2  pop r11
000076cd267de7c4  pop r10
000076cd267de7c6  pop r9
000076cd267de7c8  pop r8
000076cd267de7ca  pop rsi
000076cd267de7cb  pop rdi
000076cd267de7cc  pop rdx
000076cd267de7cd  pop rcx
000076cd267de7ce  pop rax
000076cd267de7cf  add rsp, 0x08
000076cd267de7d3  jmp 0x000076CD267DC1AA
000076cd267de7d8  call 0x000076CD266B52F0
000076cd267de7dd  jmp 0x000076CD267DC1B7
000076cd267de7e2  sub rsp, 0x08
000076cd267de7e6  push rax
000076cd267de7e7  push rcx
000076cd267de7e8  push rdx
000076cd267de7e9  push rdi
000076cd267de7ea  push rsi
000076cd267de7eb  push r8
000076cd267de7ed  push r9
000076cd267de7ef  push r10
000076cd267de7f1  push r11
000076cd267de7f3  sub rsp, 0xF0
000076cd267de7fa  vmovaps [rsp], xmm0
000076cd267de7ff  vmovaps [rsp+0x10], xmm1
000076cd267de805  vmovaps [rsp+0x20], xmm2
000076cd267de80b  vmovaps [rsp+0x30], xmm3
000076cd267de811  vmovaps [rsp+0x40], xmm4
000076cd267de817  vmovaps [rsp+0x50], xmm5
000076cd267de81d  vmovaps [rsp+0x60], xmm6
000076cd267de823  vmovaps [rsp+0x70], xmm7
000076cd267de829  vmovaps [rsp+0x80], xmm8
000076cd267de832  vmovaps [rsp+0x90], xmm9
000076cd267de83b  vmovaps [rsp+0xA0], xmm10
000076cd267de844  vmovaps [rsp+0xB0], xmm11
000076cd267de84d  vmovaps [rsp+0xC0], xmm12
000076cd267de856  vmovaps [rsp+0xD0], xmm13
000076cd267de85f  vmovaps [rsp+0xE0], xmm14
000076cd267de868  sub rsp, 0x30
000076cd267de86c  movaps [rsp], xmm15
000076cd267de871  movaps [rsp+0x10], xmm3
000076cd267de876  movaps [rsp+0x20], xmm7
000076cd267de87b  lea rdi, [rsp]
000076cd267de87f  mov esi, 0x00
000076cd267de884  mov rax, 0x56B8861A9530
000076cd267de88e  call rax
000076cd267de890  movaps xmm15, [rsp]
000076cd267de895  add rsp, 0x30
000076cd267de899  vmovaps xmm0, [rsp]
000076cd267de89e  vmovaps xmm1, [rsp+0x10]
000076cd267de8a4  vmovaps xmm2, [rsp+0x20]
000076cd267de8aa  vmovaps xmm3, [rsp+0x30]
000076cd267de8b0  vmovaps xmm4, [rsp+0x40]
000076cd267de8b6  vmovaps xmm5, [rsp+0x50]
000076cd267de8bc  vmovaps xmm6, [rsp+0x60]
000076cd267de8c2  vmovaps xmm7, [rsp+0x70]
000076cd267de8c8  vmovaps xmm8, [rsp+0x80]
000076cd267de8d1  vmovaps xmm9, [rsp+0x90]
000076cd267de8da  vmovaps xmm10, [rsp+0xA0]
000076cd267de8e3  vmovaps xmm11, [rsp+0xB0]
000076cd267de8ec  vmovaps xmm12, [rsp+0xC0]
000076cd267de8f5  vmovaps xmm13, [rsp+0xD0]
000076cd267de8fe  vmovaps xmm14, [rsp+0xE0]
000076cd267de907  add rsp, 0xF0
000076cd267de90e  pop r11
000076cd267de910  pop r10
000076cd267de912  pop r9
000076cd267de914  pop r8
000076cd267de916  pop rsi
000076cd267de917  pop rdi
000076cd267de918  pop rdx
000076cd267de919  pop rcx
000076cd267de91a  pop rax
000076cd267de91b  add rsp, 0x08
000076cd267de91f  jmp 0x000076CD267DC1E3
000076cd267de924  sub rsp, 0x08
000076cd267de928  push rax
000076cd267de929  push rcx
000076cd267de92a  push rdx
000076cd267de92b  push rdi
000076cd267de92c  push rsi
000076cd267de92d  push r8
000076cd267de92f  push r9
000076cd267de931  push r10
000076cd267de933  push r11
000076cd267de935  sub rsp, 0xF0
000076cd267de93c  vmovaps [rsp], xmm0
000076cd267de941  vmovaps [rsp+0x10], xmm1
000076cd267de947  vmovaps [rsp+0x20], xmm2
000076cd267de94d  vmovaps [rsp+0x30], xmm4
000076cd267de953  vmovaps [rsp+0x40], xmm5
000076cd267de959  vmovaps [rsp+0x50], xmm6
000076cd267de95f  vmovaps [rsp+0x60], xmm7
000076cd267de965  vmovaps [rsp+0x70], xmm8
000076cd267de96b  vmovaps [rsp+0x80], xmm9
000076cd267de974  vmovaps [rsp+0x90], xmm10
000076cd267de97d  vmovaps [rsp+0xA0], xmm11
000076cd267de986  vmovaps [rsp+0xB0], xmm12
000076cd267de98f  vmovaps [rsp+0xC0], xmm13
000076cd267de998  vmovaps [rsp+0xD0], xmm14
000076cd267de9a1  vmovaps [rsp+0xE0], xmm15
000076cd267de9aa  sub rsp, 0x30
000076cd267de9ae  movaps [rsp], xmm3
000076cd267de9b2  movaps [rsp+0x10], xmm1
000076cd267de9b7  movaps [rsp+0x20], xmm15
000076cd267de9bd  lea rdi, [rsp]
000076cd267de9c1  mov esi, 0x00
000076cd267de9c6  mov rax, 0x56B8861A9530
000076cd267de9d0  call rax
000076cd267de9d2  movaps xmm3, [rsp]
000076cd267de9d6  add rsp, 0x30
000076cd267de9da  vmovaps xmm0, [rsp]
000076cd267de9df  vmovaps xmm1, [rsp+0x10]
000076cd267de9e5  vmovaps xmm2, [rsp+0x20]
000076cd267de9eb  vmovaps xmm4, [rsp+0x30]
000076cd267de9f1  vmovaps xmm5, [rsp+0x40]
000076cd267de9f7  vmovaps xmm6, [rsp+0x50]
000076cd267de9fd  vmovaps xmm7, [rsp+0x60]
000076cd267dea03  vmovaps xmm8, [rsp+0x70]
000076cd267dea09  vmovaps xmm9, [rsp+0x80]
000076cd267dea12  vmovaps xmm10, [rsp+0x90]
000076cd267dea1b  vmovaps xmm11, [rsp+0xA0]
000076cd267dea24  vmovaps xmm12, [rsp+0xB0]
000076cd267dea2d  vmovaps xmm13, [rsp+0xC0]
000076cd267dea36  vmovaps xmm14, [rsp+0xD0]
000076cd267dea3f  vmovaps xmm15, [rsp+0xE0]
000076cd267dea48  add rsp, 0xF0
000076cd267dea4f  pop r11
000076cd267dea51  pop r10
000076cd267dea53  pop r9
000076cd267dea55  pop r8
000076cd267dea57  pop rsi
000076cd267dea58  pop rdi
000076cd267dea59  pop rdx
000076cd267dea5a  pop rcx
000076cd267dea5b  pop rax
000076cd267dea5c  add rsp, 0x08
000076cd267dea60  jmp 0x000076CD267DC272
000076cd267dea65  call 0x000076CD266B52F0
000076cd267dea6a  jmp 0x000076CD267DC27C
000076cd267dea6f  sub rsp, 0x08
000076cd267dea73  push rax
000076cd267dea74  push rcx
000076cd267dea75  push rdx
000076cd267dea76  push rdi
000076cd267dea77  push rsi
000076cd267dea78  push r8
000076cd267dea7a  push r9
000076cd267dea7c  push r10
000076cd267dea7e  push r11
000076cd267dea80  sub rsp, 0xF0
000076cd267dea87  vmovaps [rsp], xmm0
000076cd267dea8c  vmovaps [rsp+0x10], xmm1
000076cd267dea92  vmovaps [rsp+0x20], xmm2
000076cd267dea98  vmovaps [rsp+0x30], xmm3
000076cd267dea9e  vmovaps [rsp+0x40], xmm4
000076cd267deaa4  vmovaps [rsp+0x50], xmm5
000076cd267deaaa  vmovaps [rsp+0x60], xmm6
000076cd267deab0  vmovaps [rsp+0x70], xmm7
000076cd267deab6  vmovaps [rsp+0x80], xmm8
000076cd267deabf  vmovaps [rsp+0x90], xmm9
000076cd267deac8  vmovaps [rsp+0xA0], xmm10
000076cd267dead1  vmovaps [rsp+0xB0], xmm11
000076cd267deada  vmovaps [rsp+0xC0], xmm12
000076cd267deae3  vmovaps [rsp+0xD0], xmm13
000076cd267deaec  vmovaps [rsp+0xE0], xmm14
000076cd267deaf5  sub rsp, 0x30
000076cd267deaf9  movaps [rsp], xmm15
000076cd267deafe  movaps [rsp+0x10], xmm14
000076cd267deb04  movaps [rsp+0x20], xmm4
000076cd267deb09  lea rdi, [rsp]
000076cd267deb0d  mov esi, 0x00
000076cd267deb12  mov rax, 0x56B8861A9530
000076cd267deb1c  call rax
000076cd267deb1e  movaps xmm15, [rsp]
000076cd267deb23  add rsp, 0x30
000076cd267deb27  vmovaps xmm0, [rsp]
000076cd267deb2c  vmovaps xmm1, [rsp+0x10]
000076cd267deb32  vmovaps xmm2, [rsp+0x20]
000076cd267deb38  vmovaps xmm3, [rsp+0x30]
000076cd267deb3e  vmovaps xmm4, [rsp+0x40]
000076cd267deb44  vmovaps xmm5, [rsp+0x50]
000076cd267deb4a  vmovaps xmm6, [rsp+0x60]
000076cd267deb50  vmovaps xmm7, [rsp+0x70]
000076cd267deb56  vmovaps xmm8, [rsp+0x80]
000076cd267deb5f  vmovaps xmm9, [rsp+0x90]
000076cd267deb68  vmovaps xmm10, [rsp+0xA0]
000076cd267deb71  vmovaps xmm11, [rsp+0xB0]
000076cd267deb7a  vmovaps xmm12, [rsp+0xC0]
000076cd267deb83  vmovaps xmm13, [rsp+0xD0]
000076cd267deb8c  vmovaps xmm14, [rsp+0xE0]
000076cd267deb95  add rsp, 0xF0
000076cd267deb9c  pop r11
000076cd267deb9e  pop r10
000076cd267deba0  pop r9
000076cd267deba2  pop r8
000076cd267deba4  pop rsi
000076cd267deba5  pop rdi
000076cd267deba6  pop rdx
000076cd267deba7  pop rcx
000076cd267deba8  pop rax
000076cd267deba9  add rsp, 0x08
000076cd267debad  jmp 0x000076CD267DC2AA
000076cd267debb2  sub rsp, 0x08
000076cd267debb6  push rax
000076cd267debb7  push rcx
000076cd267debb8  push rdx
000076cd267debb9  push rdi
000076cd267debba  push rsi
000076cd267debbb  push r8
000076cd267debbd  push r9
000076cd267debbf  push r10
000076cd267debc1  push r11
000076cd267debc3  sub rsp, 0xF0
000076cd267debca  vmovaps [rsp], xmm0
000076cd267debcf  vmovaps [rsp+0x10], xmm1
000076cd267debd5  vmovaps [rsp+0x20], xmm2
000076cd267debdb  vmovaps [rsp+0x30], xmm3
000076cd267debe1  vmovaps [rsp+0x40], xmm4
000076cd267debe7  vmovaps [rsp+0x50], xmm5
000076cd267debed  vmovaps [rsp+0x60], xmm6
000076cd267debf3  vmovaps [rsp+0x70], xmm7
000076cd267debf9  vmovaps [rsp+0x80], xmm8
000076cd267dec02  vmovaps [rsp+0x90], xmm9
000076cd267dec0b  vmovaps [rsp+0xA0], xmm10
000076cd267dec14  vmovaps [rsp+0xB0], xmm11
000076cd267dec1d  vmovaps [rsp+0xC0], xmm12
000076cd267dec26  vmovaps [rsp+0xD0], xmm13
000076cd267dec2f  vmovaps [rsp+0xE0], xmm15
000076cd267dec38  sub rsp, 0x30
000076cd267dec3c  movaps [rsp], xmm14
000076cd267dec41  movaps [rsp+0x10], xmm2
000076cd267dec46  movaps [rsp+0x20], xmm1
000076cd267dec4b  lea rdi, [rsp]
000076cd267dec4f  mov esi, 0x00
000076cd267dec54  mov rax, 0x56B8861A9530
000076cd267dec5e  call rax
000076cd267dec60  movaps xmm14, [rsp]
000076cd267dec65  add rsp, 0x30
000076cd267dec69  vmovaps xmm0, [rsp]
000076cd267dec6e  vmovaps xmm1, [rsp+0x10]
000076cd267dec74  vmovaps xmm2, [rsp+0x20]
000076cd267dec7a  vmovaps xmm3, [rsp+0x30]
000076cd267dec80  vmovaps xmm4, [rsp+0x40]
000076cd267dec86  vmovaps xmm5, [rsp+0x50]
000076cd267dec8c  vmovaps xmm6, [rsp+0x60]
000076cd267dec92  vmovaps xmm7, [rsp+0x70]
000076cd267dec98  vmovaps xmm8, [rsp+0x80]
000076cd267deca1  vmovaps xmm9, [rsp+0x90]
000076cd267decaa  vmovaps xmm10, [rsp+0xA0]
000076cd267decb3  vmovaps xmm11, [rsp+0xB0]
000076cd267decbc  vmovaps xmm12, [rsp+0xC0]
000076cd267decc5  vmovaps xmm13, [rsp+0xD0]
000076cd267decce  vmovaps xmm15, [rsp+0xE0]
000076cd267decd7  add rsp, 0xF0
000076cd267decde  pop r11
000076cd267dece0  pop r10
000076cd267dece2  pop r9
000076cd267dece4  pop r8
000076cd267dece6  pop rsi
000076cd267dece7  pop rdi
000076cd267dece8  pop rdx
000076cd267dece9  pop rcx
000076cd267decea  pop rax
000076cd267deceb  add rsp, 0x08
000076cd267decef  jmp 0x000076CD267DC2D0
000076cd267decf4  sub rsp, 0x08
000076cd267decf8  push rax
000076cd267decf9  push rcx
000076cd267decfa  push rdx
000076cd267decfb  push rdi
000076cd267decfc  push rsi
000076cd267decfd  push r8
000076cd267decff  push r9
000076cd267ded01  push r10
000076cd267ded03  push r11
000076cd267ded05  sub rsp, 0xF0
000076cd267ded0c  vmovaps [rsp], xmm0
000076cd267ded11  vmovaps [rsp+0x10], xmm2
000076cd267ded17  vmovaps [rsp+0x20], xmm3
000076cd267ded1d  vmovaps [rsp+0x30], xmm4
000076cd267ded23  vmovaps [rsp+0x40], xmm5
000076cd267ded29  vmovaps [rsp+0x50], xmm6
000076cd267ded2f  vmovaps [rsp+0x60], xmm7
000076cd267ded35  vmovaps [rsp+0x70], xmm8
000076cd267ded3b  vmovaps [rsp+0x80], xmm9
000076cd267ded44  vmovaps [rsp+0x90], xmm10
000076cd267ded4d  vmovaps [rsp+0xA0], xmm11
000076cd267ded56  vmovaps [rsp+0xB0], xmm12
000076cd267ded5f  vmovaps [rsp+0xC0], xmm13
000076cd267ded68  vmovaps [rsp+0xD0], xmm14
000076cd267ded71  vmovaps [rsp+0xE0], xmm15
000076cd267ded7a  sub rsp, 0x30
000076cd267ded7e  movaps [rsp], xmm1
000076cd267ded82  movaps [rsp+0x10], xmm4
000076cd267ded87  movaps [rsp+0x20], xmm9
000076cd267ded8d  lea rdi, [rsp]
000076cd267ded91  mov esi, 0x00
000076cd267ded96  mov rax, 0x56B8861A9530
000076cd267deda0  call rax
000076cd267deda2  movaps xmm1, [rsp]
000076cd267deda6  add rsp, 0x30
000076cd267dedaa  vmovaps xmm0, [rsp]
000076cd267dedaf  vmovaps xmm2, [rsp+0x10]
000076cd267dedb5  vmovaps xmm3, [rsp+0x20]
000076cd267dedbb  vmovaps xmm4, [rsp+0x30]
000076cd267dedc1  vmovaps xmm5, [rsp+0x40]
000076cd267dedc7  vmovaps xmm6, [rsp+0x50]
000076cd267dedcd  vmovaps xmm7, [rsp+0x60]
000076cd267dedd3  vmovaps xmm8, [rsp+0x70]
000076cd267dedd9  vmovaps xmm9, [rsp+0x80]
000076cd267dede2  vmovaps xmm10, [rsp+0x90]
000076cd267dedeb  vmovaps xmm11, [rsp+0xA0]
000076cd267dedf4  vmovaps xmm12, [rsp+0xB0]
000076cd267dedfd  vmovaps xmm13, [rsp+0xC0]
000076cd267dee06  vmovaps xmm14, [rsp+0xD0]
000076cd267dee0f  vmovaps xmm15, [rsp+0xE0]
000076cd267dee18  add rsp, 0xF0
000076cd267dee1f  pop r11
000076cd267dee21  pop r10
000076cd267dee23  pop r9
000076cd267dee25  pop r8
000076cd267dee27  pop rsi
000076cd267dee28  pop rdi
000076cd267dee29  pop rdx
000076cd267dee2a  pop rcx
000076cd267dee2b  pop rax
000076cd267dee2c  add rsp, 0x08
000076cd267dee30  jmp 0x000076CD267DC2EE
000076cd267dee35  sub rsp, 0x08
000076cd267dee39  push rax
000076cd267dee3a  push rcx
000076cd267dee3b  push rdx
000076cd267dee3c  push rdi
000076cd267dee3d  push rsi
000076cd267dee3e  push r8
000076cd267dee40  push r9
000076cd267dee42  push r10
000076cd267dee44  push r11
000076cd267dee46  sub rsp, 0xF0
000076cd267dee4d  vmovaps [rsp], xmm0
000076cd267dee52  vmovaps [rsp+0x10], xmm1
000076cd267dee58  vmovaps [rsp+0x20], xmm2
000076cd267dee5e  vmovaps [rsp+0x30], xmm3
000076cd267dee64  vmovaps [rsp+0x40], xmm5
000076cd267dee6a  vmovaps [rsp+0x50], xmm6
000076cd267dee70  vmovaps [rsp+0x60], xmm7
000076cd267dee76  vmovaps [rsp+0x70], xmm8
000076cd267dee7c  vmovaps [rsp+0x80], xmm9
000076cd267dee85  vmovaps [rsp+0x90], xmm10
000076cd267dee8e  vmovaps [rsp+0xA0], xmm11
000076cd267dee97  vmovaps [rsp+0xB0], xmm12
000076cd267deea0  vmovaps [rsp+0xC0], xmm13
000076cd267deea9  vmovaps [rsp+0xD0], xmm14
000076cd267deeb2  vmovaps [rsp+0xE0], xmm15
000076cd267deebb  sub rsp, 0x30
000076cd267deebf  movaps [rsp], xmm4
000076cd267deec3  movaps [rsp+0x10], xmm2
000076cd267deec8  movaps [rsp+0x20], xmm9
000076cd267deece  lea rdi, [rsp]
000076cd267deed2  mov esi, 0x00
000076cd267deed7  mov rax, 0x56B8861A9530
000076cd267deee1  call rax
000076cd267deee3  movaps xmm4, [rsp]
000076cd267deee7  add rsp, 0x30
000076cd267deeeb  vmovaps xmm0, [rsp]
000076cd267deef0  vmovaps xmm1, [rsp+0x10]
000076cd267deef6  vmovaps xmm2, [rsp+0x20]
000076cd267deefc  vmovaps xmm3, [rsp+0x30]
000076cd267def02  vmovaps xmm5, [rsp+0x40]
000076cd267def08  vmovaps xmm6, [rsp+0x50]
000076cd267def0e  vmovaps xmm7, [rsp+0x60]
000076cd267def14  vmovaps xmm8, [rsp+0x70]
000076cd267def1a  vmovaps xmm9, [rsp+0x80]
000076cd267def23  vmovaps xmm10, [rsp+0x90]
000076cd267def2c  vmovaps xmm11, [rsp+0xA0]
000076cd267def35  vmovaps xmm12, [rsp+0xB0]
000076cd267def3e  vmovaps xmm13, [rsp+0xC0]
000076cd267def47  vmovaps xmm14, [rsp+0xD0]
000076cd267def50  vmovaps xmm15, [rsp+0xE0]
000076cd267def59  add rsp, 0xF0
000076cd267def60  pop r11
000076cd267def62  pop r10
000076cd267def64  pop r9
000076cd267def66  pop r8
000076cd267def68  pop rsi
000076cd267def69  pop rdi
000076cd267def6a  pop rdx
000076cd267def6b  pop rcx
000076cd267def6c  pop rax
000076cd267def6d  add rsp, 0x08
000076cd267def71  jmp 0x000076CD267DC31E
000076cd267def76  sub rsp, 0x08
000076cd267def7a  push rax
000076cd267def7b  push rcx
000076cd267def7c  push rdx
000076cd267def7d  push rdi
000076cd267def7e  push rsi
000076cd267def7f  push r8
000076cd267def81  push r9
000076cd267def83  push r10
000076cd267def85  push r11
000076cd267def87  sub rsp, 0xF0
000076cd267def8e  vmovaps [rsp], xmm0
000076cd267def93  vmovaps [rsp+0x10], xmm1
000076cd267def99  vmovaps [rsp+0x20], xmm2
000076cd267def9f  vmovaps [rsp+0x30], xmm3
000076cd267defa5  vmovaps [rsp+0x40], xmm4
000076cd267defab  vmovaps [rsp+0x50], xmm5
000076cd267defb1  vmovaps [rsp+0x60], xmm6
000076cd267defb7  vmovaps [rsp+0x70], xmm7
000076cd267defbd  vmovaps [rsp+0x80], xmm8
000076cd267defc6  vmovaps [rsp+0x90], xmm10
000076cd267defcf  vmovaps [rsp+0xA0], xmm11
000076cd267defd8  vmovaps [rsp+0xB0], xmm12
000076cd267defe1  vmovaps [rsp+0xC0], xmm13
000076cd267defea  vmovaps [rsp+0xD0], xmm14
000076cd267deff3  vmovaps [rsp+0xE0], xmm15
000076cd267deffc  sub rsp, 0x30
000076cd267df000  movaps [rsp], xmm9
000076cd267df005  movaps [rsp+0x10], xmm2
000076cd267df00a  movaps [rsp+0x20], xmm1
000076cd267df00f  lea rdi, [rsp]
000076cd267df013  mov esi, 0x00
000076cd267df018  mov rax, 0x56B8861A9530
000076cd267df022  call rax
000076cd267df024  movaps xmm9, [rsp]
000076cd267df029  add rsp, 0x30
000076cd267df02d  vmovaps xmm0, [rsp]
000076cd267df032  vmovaps xmm1, [rsp+0x10]
000076cd267df038  vmovaps xmm2, [rsp+0x20]
000076cd267df03e  vmovaps xmm3, [rsp+0x30]
000076cd267df044  vmovaps xmm4, [rsp+0x40]
000076cd267df04a  vmovaps xmm5, [rsp+0x50]
000076cd267df050  vmovaps xmm6, [rsp+0x60]
000076cd267df056  vmovaps xmm7, [rsp+0x70]
000076cd267df05c  vmovaps xmm8, [rsp+0x80]
000076cd267df065  vmovaps xmm10, [rsp+0x90]
000076cd267df06e  vmovaps xmm11, [rsp+0xA0]
000076cd267df077  vmovaps xmm12, [rsp+0xB0]
000076cd267df080  vmovaps xmm13, [rsp+0xC0]
000076cd267df089  vmovaps xmm14, [rsp+0xD0]
000076cd267df092  vmovaps xmm15, [rsp+0xE0]
000076cd267df09b  add rsp, 0xF0
000076cd267df0a2  pop r11
000076cd267df0a4  pop r10
000076cd267df0a6  pop r9
000076cd267df0a8  pop r8
000076cd267df0aa  pop rsi
000076cd267df0ab  pop rdi
000076cd267df0ac  pop rdx
000076cd267df0ad  pop rcx
000076cd267df0ae  pop rax
000076cd267df0af  add rsp, 0x08
000076cd267df0b3  jmp 0x000076CD267DC354
000076cd267df0b8  sub rsp, 0x08
000076cd267df0bc  push rax
000076cd267df0bd  push rcx
000076cd267df0be  push rdx
000076cd267df0bf  push rdi
000076cd267df0c0  push rsi
000076cd267df0c1  push r8
000076cd267df0c3  push r9
000076cd267df0c5  push r10
000076cd267df0c7  push r11
000076cd267df0c9  sub rsp, 0xF0
000076cd267df0d0  vmovaps [rsp], xmm0
000076cd267df0d5  vmovaps [rsp+0x10], xmm2
000076cd267df0db  vmovaps [rsp+0x20], xmm3
000076cd267df0e1  vmovaps [rsp+0x30], xmm4
000076cd267df0e7  vmovaps [rsp+0x40], xmm5
000076cd267df0ed  vmovaps [rsp+0x50], xmm6
000076cd267df0f3  vmovaps [rsp+0x60], xmm7
000076cd267df0f9  vmovaps [rsp+0x70], xmm8
000076cd267df0ff  vmovaps [rsp+0x80], xmm9
000076cd267df108  vmovaps [rsp+0x90], xmm10
000076cd267df111  vmovaps [rsp+0xA0], xmm11
000076cd267df11a  vmovaps [rsp+0xB0], xmm12
000076cd267df123  vmovaps [rsp+0xC0], xmm13
000076cd267df12c  vmovaps [rsp+0xD0], xmm14
000076cd267df135  vmovaps [rsp+0xE0], xmm15
000076cd267df13e  sub rsp, 0x30
000076cd267df142  movaps [rsp], xmm1
000076cd267df146  movaps [rsp+0x10], xmm15
000076cd267df14c  movaps [rsp+0x20], xmm6
000076cd267df151  lea rdi, [rsp]
000076cd267df155  mov esi, 0x00
000076cd267df15a  mov rax, 0x56B8861A9530
000076cd267df164  call rax
000076cd267df166  movaps xmm1, [rsp]
000076cd267df16a  add rsp, 0x30
000076cd267df16e  vmovaps xmm0, [rsp]
000076cd267df173  vmovaps xmm2, [rsp+0x10]
000076cd267df179  vmovaps xmm3, [rsp+0x20]
000076cd267df17f  vmovaps xmm4, [rsp+0x30]
000076cd267df185  vmovaps xmm5, [rsp+0x40]
000076cd267df18b  vmovaps xmm6, [rsp+0x50]
000076cd267df191  vmovaps xmm7, [rsp+0x60]
000076cd267df197  vmovaps xmm8, [rsp+0x70]
000076cd267df19d  vmovaps xmm9, [rsp+0x80]
000076cd267df1a6  vmovaps xmm10, [rsp+0x90]
000076cd267df1af  vmovaps xmm11, [rsp+0xA0]
000076cd267df1b8  vmovaps xmm12, [rsp+0xB0]
000076cd267df1c1  vmovaps xmm13, [rsp+0xC0]
000076cd267df1ca  vmovaps xmm14, [rsp+0xD0]
000076cd267df1d3  vmovaps xmm15, [rsp+0xE0]
000076cd267df1dc  add rsp, 0xF0
000076cd267df1e3  pop r11
000076cd267df1e5  pop r10
000076cd267df1e7  pop r9
000076cd267df1e9  pop r8
000076cd267df1eb  pop rsi
000076cd267df1ec  pop rdi
000076cd267df1ed  pop rdx
000076cd267df1ee  pop rcx
000076cd267df1ef  pop rax
000076cd267df1f0  add rsp, 0x08
000076cd267df1f4  jmp 0x000076CD267DC375
000076cd267df1f9  sub rsp, 0x08
000076cd267df1fd  push rax
000076cd267df1fe  push rcx
000076cd267df1ff  push rdx
000076cd267df200  push rdi
000076cd267df201  push rsi
000076cd267df202  push r8
000076cd267df204  push r9
000076cd267df206  push r10
000076cd267df208  push r11
000076cd267df20a  sub rsp, 0xF0
000076cd267df211  vmovaps [rsp], xmm0
000076cd267df216  vmovaps [rsp+0x10], xmm1
000076cd267df21c  vmovaps [rsp+0x20], xmm2
000076cd267df222  vmovaps [rsp+0x30], xmm3
000076cd267df228  vmovaps [rsp+0x40], xmm4
000076cd267df22e  vmovaps [rsp+0x50], xmm5
000076cd267df234  vmovaps [rsp+0x60], xmm6
000076cd267df23a  vmovaps [rsp+0x70], xmm7
000076cd267df240  vmovaps [rsp+0x80], xmm8
000076cd267df249  vmovaps [rsp+0x90], xmm9
000076cd267df252  vmovaps [rsp+0xA0], xmm10
000076cd267df25b  vmovaps [rsp+0xB0], xmm11
000076cd267df264  vmovaps [rsp+0xC0], xmm12
000076cd267df26d  vmovaps [rsp+0xD0], xmm13
000076cd267df276  vmovaps [rsp+0xE0], xmm14
000076cd267df27f  sub rsp, 0x30
000076cd267df283  movaps [rsp], xmm15
000076cd267df288  movaps [rsp+0x10], xmm5
000076cd267df28d  movaps [rsp+0x20], xmm3
000076cd267df292  lea rdi, [rsp]
000076cd267df296  mov esi, 0x00
000076cd267df29b  mov rax, 0x56B8861A9530
000076cd267df2a5  call rax
000076cd267df2a7  movaps xmm15, [rsp]
000076cd267df2ac  add rsp, 0x30
000076cd267df2b0  vmovaps xmm0, [rsp]
000076cd267df2b5  vmovaps xmm1, [rsp+0x10]
000076cd267df2bb  vmovaps xmm2, [rsp+0x20]
000076cd267df2c1  vmovaps xmm3, [rsp+0x30]
000076cd267df2c7  vmovaps xmm4, [rsp+0x40]
000076cd267df2cd  vmovaps xmm5, [rsp+0x50]
000076cd267df2d3  vmovaps xmm6, [rsp+0x60]
000076cd267df2d9  vmovaps xmm7, [rsp+0x70]
000076cd267df2df  vmovaps xmm8, [rsp+0x80]
000076cd267df2e8  vmovaps xmm9, [rsp+0x90]
000076cd267df2f1  vmovaps xmm10, [rsp+0xA0]
000076cd267df2fa  vmovaps xmm11, [rsp+0xB0]
000076cd267df303  vmovaps xmm12, [rsp+0xC0]
000076cd267df30c  vmovaps xmm13, [rsp+0xD0]
000076cd267df315  vmovaps xmm14, [rsp+0xE0]
000076cd267df31e  add rsp, 0xF0
000076cd267df325  pop r11
000076cd267df327  pop r10
000076cd267df329  pop r9
000076cd267df32b  pop r8
000076cd267df32d  pop rsi
000076cd267df32e  pop rdi
000076cd267df32f  pop rdx
000076cd267df330  pop rcx
000076cd267df331  pop rax
000076cd267df332  add rsp, 0x08
000076cd267df336  jmp 0x000076CD267DC38F
000076cd267df33b  sub rsp, 0x08
000076cd267df33f  push rax
000076cd267df340  push rcx
000076cd267df341  push rdx
000076cd267df342  push rdi
000076cd267df343  push rsi
000076cd267df344  push r8
000076cd267df346  push r9
000076cd267df348  push r10
000076cd267df34a  push r11
000076cd267df34c  sub rsp, 0xF0
000076cd267df353  vmovaps [rsp], xmm0
000076cd267df358  vmovaps [rsp+0x10], xmm1
000076cd267df35e  vmovaps [rsp+0x20], xmm2
000076cd267df364  vmovaps [rsp+0x30], xmm3
000076cd267df36a  vmovaps [rsp+0x40], xmm4
000076cd267df370  vmovaps [rsp+0x50], xmm6
000076cd267df376  vmovaps [rsp+0x60], xmm7
000076cd267df37c  vmovaps [rsp+0x70], xmm8
000076cd267df382  vmovaps [rsp+0x80], xmm9
000076cd267df38b  vmovaps [rsp+0x90], xmm10
000076cd267df394  vmovaps [rsp+0xA0], xmm11
000076cd267df39d  vmovaps [rsp+0xB0], xmm12
000076cd267df3a6  vmovaps [rsp+0xC0], xmm13
000076cd267df3af  vmovaps [rsp+0xD0], xmm14
000076cd267df3b8  vmovaps [rsp+0xE0], xmm15
000076cd267df3c1  sub rsp, 0x30
000076cd267df3c5  movaps [rsp], xmm5
000076cd267df3c9  movaps [rsp+0x10], xmm8
000076cd267df3cf  movaps [rsp+0x20], xmm6
000076cd267df3d4  lea rdi, [rsp]
000076cd267df3d8  mov esi, 0x00
000076cd267df3dd  mov rax, 0x56B8861A9530
000076cd267df3e7  call rax
000076cd267df3e9  movaps xmm5, [rsp]
000076cd267df3ed  add rsp, 0x30
000076cd267df3f1  vmovaps xmm0, [rsp]
000076cd267df3f6  vmovaps xmm1, [rsp+0x10]
000076cd267df3fc  vmovaps xmm2, [rsp+0x20]
000076cd267df402  vmovaps xmm3, [rsp+0x30]
000076cd267df408  vmovaps xmm4, [rsp+0x40]
000076cd267df40e  vmovaps xmm6, [rsp+0x50]
000076cd267df414  vmovaps xmm7, [rsp+0x60]
000076cd267df41a  vmovaps xmm8, [rsp+0x70]
000076cd267df420  vmovaps xmm9, [rsp+0x80]
000076cd267df429  vmovaps xmm10, [rsp+0x90]
000076cd267df432  vmovaps xmm11, [rsp+0xA0]
000076cd267df43b  vmovaps xmm12, [rsp+0xB0]
000076cd267df444  vmovaps xmm13, [rsp+0xC0]
000076cd267df44d  vmovaps xmm14, [rsp+0xD0]
000076cd267df456  vmovaps xmm15, [rsp+0xE0]
000076cd267df45f  add rsp, 0xF0
000076cd267df466  pop r11
000076cd267df468  pop r10
000076cd267df46a  pop r9
000076cd267df46c  pop r8
000076cd267df46e  pop rsi
000076cd267df46f  pop rdi
000076cd267df470  pop rdx
000076cd267df471  pop rcx
000076cd267df472  pop rax
000076cd267df473  add rsp, 0x08
000076cd267df477  jmp 0x000076CD267DC3B3
000076cd267df47c  sub rsp, 0x08
000076cd267df480  push rax
000076cd267df481  push rcx
000076cd267df482  push rdx
000076cd267df483  push rdi
000076cd267df484  push rsi
000076cd267df485  push r8
000076cd267df487  push r9
000076cd267df489  push r10
000076cd267df48b  push r11
000076cd267df48d  sub rsp, 0xF0
000076cd267df494  vmovaps [rsp], xmm0
000076cd267df499  vmovaps [rsp+0x10], xmm1
000076cd267df49f  vmovaps [rsp+0x20], xmm2
000076cd267df4a5  vmovaps [rsp+0x30], xmm3
000076cd267df4ab  vmovaps [rsp+0x40], xmm4
000076cd267df4b1  vmovaps [rsp+0x50], xmm5
000076cd267df4b7  vmovaps [rsp+0x60], xmm7
000076cd267df4bd  vmovaps [rsp+0x70], xmm8
000076cd267df4c3  vmovaps [rsp+0x80], xmm9
000076cd267df4cc  vmovaps [rsp+0x90], xmm10
000076cd267df4d5  vmovaps [rsp+0xA0], xmm11
000076cd267df4de  vmovaps [rsp+0xB0], xmm12
000076cd267df4e7  vmovaps [rsp+0xC0], xmm13
000076cd267df4f0  vmovaps [rsp+0xD0], xmm14
000076cd267df4f9  vmovaps [rsp+0xE0], xmm15
000076cd267df502  sub rsp, 0x30
000076cd267df506  movaps [rsp], xmm6
000076cd267df50a  movaps [rsp+0x10], xmm10
000076cd267df510  movaps [rsp+0x20], xmm8
000076cd267df516  lea rdi, [rsp]
000076cd267df51a  mov esi, 0x00
000076cd267df51f  mov rax, 0x56B8861A9530
000076cd267df529  call rax
000076cd267df52b  movaps xmm6, [rsp]
000076cd267df52f  add rsp, 0x30
000076cd267df533  vmovaps xmm0, [rsp]
000076cd267df538  vmovaps xmm1, [rsp+0x10]
000076cd267df53e  vmovaps xmm2, [rsp+0x20]
000076cd267df544  vmovaps xmm3, [rsp+0x30]
000076cd267df54a  vmovaps xmm4, [rsp+0x40]
000076cd267df550  vmovaps xmm5, [rsp+0x50]
000076cd267df556  vmovaps xmm7, [rsp+0x60]
000076cd267df55c  vmovaps xmm8, [rsp+0x70]
000076cd267df562  vmovaps xmm9, [rsp+0x80]
000076cd267df56b  vmovaps xmm10, [rsp+0x90]
000076cd267df574  vmovaps xmm11, [rsp+0xA0]
000076cd267df57d  vmovaps xmm12, [rsp+0xB0]
000076cd267df586  vmovaps xmm13, [rsp+0xC0]
000076cd267df58f  vmovaps xmm14, [rsp+0xD0]
000076cd267df598  vmovaps xmm15, [rsp+0xE0]
000076cd267df5a1  add rsp, 0xF0
000076cd267df5a8  pop r11
000076cd267df5aa  pop r10
000076cd267df5ac  pop r9
000076cd267df5ae  pop r8
000076cd267df5b0  pop rsi
000076cd267df5b1  pop rdi
000076cd267df5b2  pop rdx
000076cd267df5b3  pop rcx
000076cd267df5b4  pop rax
000076cd267df5b5  add rsp, 0x08
000076cd267df5b9  jmp 0x000076CD267DC3D8
000076cd267df5be  sub rsp, 0x08
000076cd267df5c2  push rax
000076cd267df5c3  push rcx
000076cd267df5c4  push rdx
000076cd267df5c5  push rdi
000076cd267df5c6  push rsi
000076cd267df5c7  push r8
000076cd267df5c9  push r9
000076cd267df5cb  push r10
000076cd267df5cd  push r11
000076cd267df5cf  sub rsp, 0xF0
000076cd267df5d6  vmovaps [rsp], xmm0
000076cd267df5db  vmovaps [rsp+0x10], xmm1
000076cd267df5e1  vmovaps [rsp+0x20], xmm2
000076cd267df5e7  vmovaps [rsp+0x30], xmm3
000076cd267df5ed  vmovaps [rsp+0x40], xmm4
000076cd267df5f3  vmovaps [rsp+0x50], xmm5
000076cd267df5f9  vmovaps [rsp+0x60], xmm6
000076cd267df5ff  vmovaps [rsp+0x70], xmm7
000076cd267df605  vmovaps [rsp+0x80], xmm8
000076cd267df60e  vmovaps [rsp+0x90], xmm9
000076cd267df617  vmovaps [rsp+0xA0], xmm11
000076cd267df620  vmovaps [rsp+0xB0], xmm12
000076cd267df629  vmovaps [rsp+0xC0], xmm13
000076cd267df632  vmovaps [rsp+0xD0], xmm14
000076cd267df63b  vmovaps [rsp+0xE0], xmm15
000076cd267df644  sub rsp, 0x30
000076cd267df648  movaps [rsp], xmm10
000076cd267df64d  movaps [rsp+0x10], xmm8
000076cd267df653  movaps [rsp+0x20], xmm14
000076cd267df659  lea rdi, [rsp]
000076cd267df65d  mov esi, 0x00
000076cd267df662  mov rax, 0x56B8861A9530
000076cd267df66c  call rax
000076cd267df66e  movaps xmm10, [rsp]
000076cd267df673  add rsp, 0x30
000076cd267df677  vmovaps xmm0, [rsp]
000076cd267df67c  vmovaps xmm1, [rsp+0x10]
000076cd267df682  vmovaps xmm2, [rsp+0x20]
000076cd267df688  vmovaps xmm3, [rsp+0x30]
000076cd267df68e  vmovaps xmm4, [rsp+0x40]
000076cd267df694  vmovaps xmm5, [rsp+0x50]
000076cd267df69a  vmovaps xmm6, [rsp+0x60]
000076cd267df6a0  vmovaps xmm7, [rsp+0x70]
000076cd267df6a6  vmovaps xmm8, [rsp+0x80]
000076cd267df6af  vmovaps xmm9, [rsp+0x90]
000076cd267df6b8  vmovaps xmm11, [rsp+0xA0]
000076cd267df6c1  vmovaps xmm12, [rsp+0xB0]
000076cd267df6ca  vmovaps xmm13, [rsp+0xC0]
000076cd267df6d3  vmovaps xmm14, [rsp+0xD0]
000076cd267df6dc  vmovaps xmm15, [rsp+0xE0]
000076cd267df6e5  add rsp, 0xF0
000076cd267df6ec  pop r11
000076cd267df6ee  pop r10
000076cd267df6f0  pop r9
000076cd267df6f2  pop r8
000076cd267df6f4  pop rsi
000076cd267df6f5  pop rdi
000076cd267df6f6  pop rdx
000076cd267df6f7  pop rcx
000076cd267df6f8  pop rax
000076cd267df6f9  add rsp, 0x08
000076cd267df6fd  jmp 0x000076CD267DC3F8
000076cd267df702  sub rsp, 0x08
000076cd267df706  push rax
000076cd267df707  push rcx
000076cd267df708  push rdx
000076cd267df709  push rdi
000076cd267df70a  push rsi
000076cd267df70b  push r8
000076cd267df70d  push r9
000076cd267df70f  push r10
000076cd267df711  push r11
000076cd267df713  sub rsp, 0xF0
000076cd267df71a  vmovaps [rsp], xmm0
000076cd267df71f  vmovaps [rsp+0x10], xmm1
000076cd267df725  vmovaps [rsp+0x20], xmm2
000076cd267df72b  vmovaps [rsp+0x30], xmm3
000076cd267df731  vmovaps [rsp+0x40], xmm4
000076cd267df737  vmovaps [rsp+0x50], xmm5
000076cd267df73d  vmovaps [rsp+0x60], xmm6
000076cd267df743  vmovaps [rsp+0x70], xmm7
000076cd267df749  vmovaps [rsp+0x80], xmm8
000076cd267df752  vmovaps [rsp+0x90], xmm9
000076cd267df75b  vmovaps [rsp+0xA0], xmm10
000076cd267df764  vmovaps [rsp+0xB0], xmm11
000076cd267df76d  vmovaps [rsp+0xC0], xmm12
000076cd267df776  vmovaps [rsp+0xD0], xmm13
000076cd267df77f  vmovaps [rsp+0xE0], xmm15
000076cd267df788  sub rsp, 0x30
000076cd267df78c  movaps [rsp], xmm14
000076cd267df791  movaps [rsp+0x10], xmm8
000076cd267df797  movaps [rsp+0x20], xmm4
000076cd267df79c  lea rdi, [rsp]
000076cd267df7a0  mov esi, 0x00
000076cd267df7a5  mov rax, 0x56B8861A9530
000076cd267df7af  call rax
000076cd267df7b1  movaps xmm14, [rsp]
000076cd267df7b6  add rsp, 0x30
000076cd267df7ba  vmovaps xmm0, [rsp]
000076cd267df7bf  vmovaps xmm1, [rsp+0x10]
000076cd267df7c5  vmovaps xmm2, [rsp+0x20]
000076cd267df7cb  vmovaps xmm3, [rsp+0x30]
000076cd267df7d1  vmovaps xmm4, [rsp+0x40]
000076cd267df7d7  vmovaps xmm5, [rsp+0x50]
000076cd267df7dd  vmovaps xmm6, [rsp+0x60]
000076cd267df7e3  vmovaps xmm7, [rsp+0x70]
000076cd267df7e9  vmovaps xmm8, [rsp+0x80]
000076cd267df7f2  vmovaps xmm9, [rsp+0x90]
000076cd267df7fb  vmovaps xmm10, [rsp+0xA0]
000076cd267df804  vmovaps xmm11, [rsp+0xB0]
000076cd267df80d  vmovaps xmm12, [rsp+0xC0]
000076cd267df816  vmovaps xmm13, [rsp+0xD0]
000076cd267df81f  vmovaps xmm15, [rsp+0xE0]
000076cd267df828  add rsp, 0xF0
000076cd267df82f  pop r11
000076cd267df831  pop r10
000076cd267df833  pop r9
000076cd267df835  pop r8
000076cd267df837  pop rsi
000076cd267df838  pop rdi
000076cd267df839  pop rdx
000076cd267df83a  pop rcx
000076cd267df83b  pop rax
000076cd267df83c  add rsp, 0x08
000076cd267df840  jmp 0x000076CD267DC418
000076cd267df845  sub rsp, 0x08
000076cd267df849  push rax
000076cd267df84a  push rcx
000076cd267df84b  push rdx
000076cd267df84c  push rdi
000076cd267df84d  push rsi
000076cd267df84e  push r8
000076cd267df850  push r9
000076cd267df852  push r10
000076cd267df854  push r11
000076cd267df856  sub rsp, 0xF0
000076cd267df85d  vmovaps [rsp], xmm0
000076cd267df862  vmovaps [rsp+0x10], xmm1
000076cd267df868  vmovaps [rsp+0x20], xmm2
000076cd267df86e  vmovaps [rsp+0x30], xmm3
000076cd267df874  vmovaps [rsp+0x40], xmm5
000076cd267df87a  vmovaps [rsp+0x50], xmm6
000076cd267df880  vmovaps [rsp+0x60], xmm7
000076cd267df886  vmovaps [rsp+0x70], xmm8
000076cd267df88c  vmovaps [rsp+0x80], xmm9
000076cd267df895  vmovaps [rsp+0x90], xmm10
000076cd267df89e  vmovaps [rsp+0xA0], xmm11
000076cd267df8a7  vmovaps [rsp+0xB0], xmm12
000076cd267df8b0  vmovaps [rsp+0xC0], xmm13
000076cd267df8b9  vmovaps [rsp+0xD0], xmm14
000076cd267df8c2  vmovaps [rsp+0xE0], xmm15
000076cd267df8cb  sub rsp, 0x30
000076cd267df8cf  movaps [rsp], xmm4
000076cd267df8d3  movaps [rsp+0x10], xmm13
000076cd267df8d9  movaps [rsp+0x20], xmm8
000076cd267df8df  lea rdi, [rsp]
000076cd267df8e3  mov esi, 0x00
000076cd267df8e8  mov rax, 0x56B8861A9530
000076cd267df8f2  call rax
000076cd267df8f4  movaps xmm4, [rsp]
000076cd267df8f8  add rsp, 0x30
000076cd267df8fc  vmovaps xmm0, [rsp]
000076cd267df901  vmovaps xmm1, [rsp+0x10]
000076cd267df907  vmovaps xmm2, [rsp+0x20]
000076cd267df90d  vmovaps xmm3, [rsp+0x30]
000076cd267df913  vmovaps xmm5, [rsp+0x40]
000076cd267df919  vmovaps xmm6, [rsp+0x50]
000076cd267df91f  vmovaps xmm7, [rsp+0x60]
000076cd267df925  vmovaps xmm8, [rsp+0x70]
000076cd267df92b  vmovaps xmm9, [rsp+0x80]
000076cd267df934  vmovaps xmm10, [rsp+0x90]
000076cd267df93d  vmovaps xmm11, [rsp+0xA0]
000076cd267df946  vmovaps xmm12, [rsp+0xB0]
000076cd267df94f  vmovaps xmm13, [rsp+0xC0]
000076cd267df958  vmovaps xmm14, [rsp+0xD0]
000076cd267df961  vmovaps xmm15, [rsp+0xE0]
000076cd267df96a  add rsp, 0xF0
000076cd267df971  pop r11
000076cd267df973  pop r10
000076cd267df975  pop r9
000076cd267df977  pop r8
000076cd267df979  pop rsi
000076cd267df97a  pop rdi
000076cd267df97b  pop rdx
000076cd267df97c  pop rcx
000076cd267df97d  pop rax
000076cd267df97e  add rsp, 0x08
000076cd267df982  jmp 0x000076CD267DC43D
000076cd267df987  sub rsp, 0x08
000076cd267df98b  push rax
000076cd267df98c  push rcx
000076cd267df98d  push rdx
000076cd267df98e  push rdi
000076cd267df98f  push rsi
000076cd267df990  push r8
000076cd267df992  push r9
000076cd267df994  push r10
000076cd267df996  push r11
000076cd267df998  sub rsp, 0xF0
000076cd267df99f  vmovaps [rsp], xmm0
000076cd267df9a4  vmovaps [rsp+0x10], xmm1
000076cd267df9aa  vmovaps [rsp+0x20], xmm2
000076cd267df9b0  vmovaps [rsp+0x30], xmm3
000076cd267df9b6  vmovaps [rsp+0x40], xmm4
000076cd267df9bc  vmovaps [rsp+0x50], xmm5
000076cd267df9c2  vmovaps [rsp+0x60], xmm6
000076cd267df9c8  vmovaps [rsp+0x70], xmm7
000076cd267df9ce  vmovaps [rsp+0x80], xmm8
000076cd267df9d7  vmovaps [rsp+0x90], xmm9
000076cd267df9e0  vmovaps [rsp+0xA0], xmm10
000076cd267df9e9  vmovaps [rsp+0xB0], xmm11
000076cd267df9f2  vmovaps [rsp+0xC0], xmm12
000076cd267df9fb  vmovaps [rsp+0xD0], xmm14
000076cd267dfa04  vmovaps [rsp+0xE0], xmm15
000076cd267dfa0d  sub rsp, 0x30
000076cd267dfa11  movaps [rsp], xmm13
000076cd267dfa16  movaps [rsp+0x10], xmm15
000076cd267dfa1c  movaps [rsp+0x20], xmm9
000076cd267dfa22  lea rdi, [rsp]
000076cd267dfa26  mov esi, 0x00
000076cd267dfa2b  mov rax, 0x56B8861A9530
000076cd267dfa35  call rax
000076cd267dfa37  movaps xmm13, [rsp]
000076cd267dfa3c  add rsp, 0x30
000076cd267dfa40  vmovaps xmm0, [rsp]
000076cd267dfa45  vmovaps xmm1, [rsp+0x10]
000076cd267dfa4b  vmovaps xmm2, [rsp+0x20]
000076cd267dfa51  vmovaps xmm3, [rsp+0x30]
000076cd267dfa57  vmovaps xmm4, [rsp+0x40]
000076cd267dfa5d  vmovaps xmm5, [rsp+0x50]
000076cd267dfa63  vmovaps xmm6, [rsp+0x60]
000076cd267dfa69  vmovaps xmm7, [rsp+0x70]
000076cd267dfa6f  vmovaps xmm8, [rsp+0x80]
000076cd267dfa78  vmovaps xmm9, [rsp+0x90]
000076cd267dfa81  vmovaps xmm10, [rsp+0xA0]
000076cd267dfa8a  vmovaps xmm11, [rsp+0xB0]
000076cd267dfa93  vmovaps xmm12, [rsp+0xC0]
000076cd267dfa9c  vmovaps xmm14, [rsp+0xD0]
000076cd267dfaa5  vmovaps xmm15, [rsp+0xE0]
000076cd267dfaae  add rsp, 0xF0
000076cd267dfab5  pop r11
000076cd267dfab7  pop r10
000076cd267dfab9  pop r9
000076cd267dfabb  pop r8
000076cd267dfabd  pop rsi
000076cd267dfabe  pop rdi
000076cd267dfabf  pop rdx
000076cd267dfac0  pop rcx
000076cd267dfac1  pop rax
000076cd267dfac2  add rsp, 0x08
000076cd267dfac6  jmp 0x000076CD267DC458
000076cd267dfacb  sub rsp, 0x08
000076cd267dfacf  push rax
000076cd267dfad0  push rcx
000076cd267dfad1  push rdx
000076cd267dfad2  push rdi
000076cd267dfad3  push rsi
000076cd267dfad4  push r8
000076cd267dfad6  push r9
000076cd267dfad8  push r10
000076cd267dfada  push r11
000076cd267dfadc  sub rsp, 0xF0
000076cd267dfae3  vmovaps [rsp], xmm0
000076cd267dfae8  vmovaps [rsp+0x10], xmm1
000076cd267dfaee  vmovaps [rsp+0x20], xmm2
000076cd267dfaf4  vmovaps [rsp+0x30], xmm3
000076cd267dfafa  vmovaps [rsp+0x40], xmm4
000076cd267dfb00  vmovaps [rsp+0x50], xmm5
000076cd267dfb06  vmovaps [rsp+0x60], xmm6
000076cd267dfb0c  vmovaps [rsp+0x70], xmm7
000076cd267dfb12  vmovaps [rsp+0x80], xmm8
000076cd267dfb1b  vmovaps [rsp+0x90], xmm9
000076cd267dfb24  vmovaps [rsp+0xA0], xmm10
000076cd267dfb2d  vmovaps [rsp+0xB0], xmm11
000076cd267dfb36  vmovaps [rsp+0xC0], xmm12
000076cd267dfb3f  vmovaps [rsp+0xD0], xmm13
000076cd267dfb48  vmovaps [rsp+0xE0], xmm14
000076cd267dfb51  sub rsp, 0x30
000076cd267dfb55  movaps [rsp], xmm15
000076cd267dfb5a  movaps [rsp+0x10], xmm1
000076cd267dfb5f  movaps [rsp+0x20], xmm5
000076cd267dfb64  lea rdi, [rsp]
000076cd267dfb68  mov esi, 0x00
000076cd267dfb6d  mov rax, 0x56B8861A9530
000076cd267dfb77  call rax
000076cd267dfb79  movaps xmm15, [rsp]
000076cd267dfb7e  add rsp, 0x30
000076cd267dfb82  vmovaps xmm0, [rsp]
000076cd267dfb87  vmovaps xmm1, [rsp+0x10]
000076cd267dfb8d  vmovaps xmm2, [rsp+0x20]
000076cd267dfb93  vmovaps xmm3, [rsp+0x30]
000076cd267dfb99  vmovaps xmm4, [rsp+0x40]
000076cd267dfb9f  vmovaps xmm5, [rsp+0x50]
000076cd267dfba5  vmovaps xmm6, [rsp+0x60]
000076cd267dfbab  vmovaps xmm7, [rsp+0x70]
000076cd267dfbb1  vmovaps xmm8, [rsp+0x80]
000076cd267dfbba  vmovaps xmm9, [rsp+0x90]
000076cd267dfbc3  vmovaps xmm10, [rsp+0xA0]
000076cd267dfbcc  vmovaps xmm11, [rsp+0xB0]
000076cd267dfbd5  vmovaps xmm12, [rsp+0xC0]
000076cd267dfbde  vmovaps xmm13, [rsp+0xD0]
000076cd267dfbe7  vmovaps xmm14, [rsp+0xE0]
000076cd267dfbf0  add rsp, 0xF0
000076cd267dfbf7  pop r11
000076cd267dfbf9  pop r10
000076cd267dfbfb  pop r9
000076cd267dfbfd  pop r8
000076cd267dfbff  pop rsi
000076cd267dfc00  pop rdi
000076cd267dfc01  pop rdx
000076cd267dfc02  pop rcx
000076cd267dfc03  pop rax
000076cd267dfc04  add rsp, 0x08
000076cd267dfc08  jmp 0x000076CD267DC473
000076cd267dfc0d  call 0x000076CD266B52F0
000076cd267dfc12  jmp 0x000076CD267DC4CE
000076cd267dfc17  sub rsp, 0x08
000076cd267dfc1b  push rax
000076cd267dfc1c  push rcx
000076cd267dfc1d  push rdx
000076cd267dfc1e  push rdi
000076cd267dfc1f  push rsi
000076cd267dfc20  push r8
000076cd267dfc22  push r9
000076cd267dfc24  push r10
000076cd267dfc26  push r11
000076cd267dfc28  sub rsp, 0xF0
000076cd267dfc2f  vmovaps [rsp], xmm0
000076cd267dfc34  vmovaps [rsp+0x10], xmm1
000076cd267dfc3a  vmovaps [rsp+0x20], xmm2
000076cd267dfc40  vmovaps [rsp+0x30], xmm3
000076cd267dfc46  vmovaps [rsp+0x40], xmm4
000076cd267dfc4c  vmovaps [rsp+0x50], xmm5
000076cd267dfc52  vmovaps [rsp+0x60], xmm6
000076cd267dfc58  vmovaps [rsp+0x70], xmm7
000076cd267dfc5e  vmovaps [rsp+0x80], xmm8
000076cd267dfc67  vmovaps [rsp+0x90], xmm10
000076cd267dfc70  vmovaps [rsp+0xA0], xmm11
000076cd267dfc79  vmovaps [rsp+0xB0], xmm12
000076cd267dfc82  vmovaps [rsp+0xC0], xmm13
000076cd267dfc8b  vmovaps [rsp+0xD0], xmm14
000076cd267dfc94  vmovaps [rsp+0xE0], xmm15
000076cd267dfc9d  sub rsp, 0x30
000076cd267dfca1  movaps [rsp], xmm9
000076cd267dfca6  movaps [rsp+0x10], xmm8
000076cd267dfcac  movaps [rsp+0x20], xmm11
000076cd267dfcb2  lea rdi, [rsp]
000076cd267dfcb6  mov esi, 0x00
000076cd267dfcbb  mov rax, 0x56B8861A9530
000076cd267dfcc5  call rax
000076cd267dfcc7  movaps xmm9, [rsp]
000076cd267dfccc  add rsp, 0x30
000076cd267dfcd0  vmovaps xmm0, [rsp]
000076cd267dfcd5  vmovaps xmm1, [rsp+0x10]
000076cd267dfcdb  vmovaps xmm2, [rsp+0x20]
000076cd267dfce1  vmovaps xmm3, [rsp+0x30]
000076cd267dfce7  vmovaps xmm4, [rsp+0x40]
000076cd267dfced  vmovaps xmm5, [rsp+0x50]
000076cd267dfcf3  vmovaps xmm6, [rsp+0x60]
000076cd267dfcf9  vmovaps xmm7, [rsp+0x70]
000076cd267dfcff  vmovaps xmm8, [rsp+0x80]
000076cd267dfd08  vmovaps xmm10, [rsp+0x90]
000076cd267dfd11  vmovaps xmm11, [rsp+0xA0]
000076cd267dfd1a  vmovaps xmm12, [rsp+0xB0]
000076cd267dfd23  vmovaps xmm13, [rsp+0xC0]
000076cd267dfd2c  vmovaps xmm14, [rsp+0xD0]
000076cd267dfd35  vmovaps xmm15, [rsp+0xE0]
000076cd267dfd3e  add rsp, 0xF0
000076cd267dfd45  pop r11
000076cd267dfd47  pop r10
000076cd267dfd49  pop r9
000076cd267dfd4b  pop r8
000076cd267dfd4d  pop rsi
000076cd267dfd4e  pop rdi
000076cd267dfd4f  pop rdx
000076cd267dfd50  pop rcx
000076cd267dfd51  pop rax
000076cd267dfd52  add rsp, 0x08
000076cd267dfd56  jmp 0x000076CD267DC505
000076cd267dfd5b  sub rsp, 0x08
000076cd267dfd5f  push rax
000076cd267dfd60  push rcx
000076cd267dfd61  push rdx
000076cd267dfd62  push rdi
000076cd267dfd63  push rsi
000076cd267dfd64  push r8
000076cd267dfd66  push r9
000076cd267dfd68  push r10
000076cd267dfd6a  push r11
000076cd267dfd6c  sub rsp, 0xF0
000076cd267dfd73  vmovaps [rsp], xmm0
000076cd267dfd78  vmovaps [rsp+0x10], xmm1
000076cd267dfd7e  vmovaps [rsp+0x20], xmm2
000076cd267dfd84  vmovaps [rsp+0x30], xmm3
000076cd267dfd8a  vmovaps [rsp+0x40], xmm4
000076cd267dfd90  vmovaps [rsp+0x50], xmm5
000076cd267dfd96  vmovaps [rsp+0x60], xmm6
000076cd267dfd9c  vmovaps [rsp+0x70], xmm7
000076cd267dfda2  vmovaps [rsp+0x80], xmm8
000076cd267dfdab  vmovaps [rsp+0x90], xmm9
000076cd267dfdb4  vmovaps [rsp+0xA0], xmm10
000076cd267dfdbd  vmovaps [rsp+0xB0], xmm12
000076cd267dfdc6  vmovaps [rsp+0xC0], xmm13
000076cd267dfdcf  vmovaps [rsp+0xD0], xmm14
000076cd267dfdd8  vmovaps [rsp+0xE0], xmm15
000076cd267dfde1  sub rsp, 0x30
000076cd267dfde5  movaps [rsp], xmm11
000076cd267dfdea  movaps [rsp+0x10], xmm10
000076cd267dfdf0  movaps [rsp+0x20], xmm6
000076cd267dfdf5  lea rdi, [rsp]
000076cd267dfdf9  mov esi, 0x00
000076cd267dfdfe  mov rax, 0x56B8861A9530
000076cd267dfe08  call rax
000076cd267dfe0a  movaps xmm11, [rsp]
000076cd267dfe0f  add rsp, 0x30
000076cd267dfe13  vmovaps xmm0, [rsp]
000076cd267dfe18  vmovaps xmm1, [rsp+0x10]
000076cd267dfe1e  vmovaps xmm2, [rsp+0x20]
000076cd267dfe24  vmovaps xmm3, [rsp+0x30]
000076cd267dfe2a  vmovaps xmm4, [rsp+0x40]
000076cd267dfe30  vmovaps xmm5, [rsp+0x50]
000076cd267dfe36  vmovaps xmm6, [rsp+0x60]
000076cd267dfe3c  vmovaps xmm7, [rsp+0x70]
000076cd267dfe42  vmovaps xmm8, [rsp+0x80]
000076cd267dfe4b  vmovaps xmm9, [rsp+0x90]
000076cd267dfe54  vmovaps xmm10, [rsp+0xA0]
000076cd267dfe5d  vmovaps xmm12, [rsp+0xB0]
000076cd267dfe66  vmovaps xmm13, [rsp+0xC0]
000076cd267dfe6f  vmovaps xmm14, [rsp+0xD0]
000076cd267dfe78  vmovaps xmm15, [rsp+0xE0]
000076cd267dfe81  add rsp, 0xF0
000076cd267dfe88  pop r11
000076cd267dfe8a  pop r10
000076cd267dfe8c  pop r9
000076cd267dfe8e  pop r8
000076cd267dfe90  pop rsi
000076cd267dfe91  pop rdi
000076cd267dfe92  pop rdx
000076cd267dfe93  pop rcx
000076cd267dfe94  pop rax
000076cd267dfe95  add rsp, 0x08
000076cd267dfe99  jmp 0x000076CD267DC520
000076cd267dfe9e  sub rsp, 0x08
000076cd267dfea2  push rax
000076cd267dfea3  push rcx
000076cd267dfea4  push rdx
000076cd267dfea5  push rdi
000076cd267dfea6  push rsi
000076cd267dfea7  push r8
000076cd267dfea9  push r9
000076cd267dfeab  push r10
000076cd267dfead  push r11
000076cd267dfeaf  sub rsp, 0xF0
000076cd267dfeb6  vmovaps [rsp], xmm0
000076cd267dfebb  vmovaps [rsp+0x10], xmm1
000076cd267dfec1  vmovaps [rsp+0x20], xmm2
000076cd267dfec7  vmovaps [rsp+0x30], xmm3
000076cd267dfecd  vmovaps [rsp+0x40], xmm4
000076cd267dfed3  vmovaps [rsp+0x50], xmm5
000076cd267dfed9  vmovaps [rsp+0x60], xmm6
000076cd267dfedf  vmovaps [rsp+0x70], xmm7
000076cd267dfee5  vmovaps [rsp+0x80], xmm8
000076cd267dfeee  vmovaps [rsp+0x90], xmm9
000076cd267dfef7  vmovaps [rsp+0xA0], xmm11
000076cd267dff00  vmovaps [rsp+0xB0], xmm12
000076cd267dff09  vmovaps [rsp+0xC0], xmm13
000076cd267dff12  vmovaps [rsp+0xD0], xmm14
000076cd267dff1b  vmovaps [rsp+0xE0], xmm15
000076cd267dff24  sub rsp, 0x30
000076cd267dff28  movaps [rsp], xmm10
000076cd267dff2d  movaps [rsp+0x10], xmm14
000076cd267dff33  movaps [rsp+0x20], xmm4
000076cd267dff38  lea rdi, [rsp]
000076cd267dff3c  mov esi, 0x00
000076cd267dff41  mov rax, 0x56B8861A9530
000076cd267dff4b  call rax
000076cd267dff4d  movaps xmm10, [rsp]
000076cd267dff52  add rsp, 0x30
000076cd267dff56  vmovaps xmm0, [rsp]
000076cd267dff5b  vmovaps xmm1, [rsp+0x10]
000076cd267dff61  vmovaps xmm2, [rsp+0x20]
000076cd267dff67  vmovaps xmm3, [rsp+0x30]
000076cd267dff6d  vmovaps xmm4, [rsp+0x40]
000076cd267dff73  vmovaps xmm5, [rsp+0x50]
000076cd267dff79  vmovaps xmm6, [rsp+0x60]
000076cd267dff7f  vmovaps xmm7, [rsp+0x70]
000076cd267dff85  vmovaps xmm8, [rsp+0x80]
000076cd267dff8e  vmovaps xmm9, [rsp+0x90]
000076cd267dff97  vmovaps xmm11, [rsp+0xA0]
000076cd267dffa0  vmovaps xmm12, [rsp+0xB0]
000076cd267dffa9  vmovaps xmm13, [rsp+0xC0]
000076cd267dffb2  vmovaps xmm14, [rsp+0xD0]
000076cd267dffbb  vmovaps xmm15, [rsp+0xE0]
000076cd267dffc4  add rsp, 0xF0
000076cd267dffcb  pop r11
000076cd267dffcd  pop r10
000076cd267dffcf  pop r9
000076cd267dffd1  pop r8
000076cd267dffd3  pop rsi
000076cd267dffd4  pop rdi
000076cd267dffd5  pop rdx
000076cd267dffd6  pop rcx
000076cd267dffd7  pop rax
000076cd267dffd8  add rsp, 0x08
000076cd267dffdc  jmp 0x000076CD267DC53B
000076cd267dffe1  sub rsp, 0x08
000076cd267dffe5  push rax
000076cd267dffe6  push rcx
000076cd267dffe7  push rdx
000076cd267dffe8  push rdi
000076cd267dffe9  push rsi
000076cd267dffea  push r8
000076cd267dffec  push r9
000076cd267dffee  push r10
000076cd267dfff0  push r11
000076cd267dfff2  sub rsp, 0xF0
000076cd267dfff9  vmovaps [rsp], xmm0
000076cd267dfffe  vmovaps [rsp+0x10], xmm1
000076cd267e0004  vmovaps [rsp+0x20], xmm2
000076cd267e000a  vmovaps [rsp+0x30], xmm3
000076cd267e0010  vmovaps [rsp+0x40], xmm4
000076cd267e0016  vmovaps [rsp+0x50], xmm5
000076cd267e001c  vmovaps [rsp+0x60], xmm6
000076cd267e0022  vmovaps [rsp+0x70], xmm7
000076cd267e0028  vmovaps [rsp+0x80], xmm9
000076cd267e0031  vmovaps [rsp+0x90], xmm10
000076cd267e003a  vmovaps [rsp+0xA0], xmm11
000076cd267e0043  vmovaps [rsp+0xB0], xmm12
000076cd267e004c  vmovaps [rsp+0xC0], xmm13
000076cd267e0055  vmovaps [rsp+0xD0], xmm14
000076cd267e005e  vmovaps [rsp+0xE0], xmm15
000076cd267e0067  sub rsp, 0x30
000076cd267e006b  movaps [rsp], xmm8
000076cd267e0070  movaps [rsp+0x10], xmm1
000076cd267e0075  movaps [rsp+0x20], xmm14
000076cd267e007b  lea rdi, [rsp]
000076cd267e007f  mov esi, 0x00
000076cd267e0084  mov rax, 0x56B8861A9530
000076cd267e008e  call rax
000076cd267e0090  movaps xmm8, [rsp]
000076cd267e0095  add rsp, 0x30
000076cd267e0099  vmovaps xmm0, [rsp]
000076cd267e009e  vmovaps xmm1, [rsp+0x10]
000076cd267e00a4  vmovaps xmm2, [rsp+0x20]
000076cd267e00aa  vmovaps xmm3, [rsp+0x30]
000076cd267e00b0  vmovaps xmm4, [rsp+0x40]
000076cd267e00b6  vmovaps xmm5, [rsp+0x50]
000076cd267e00bc  vmovaps xmm6, [rsp+0x60]
000076cd267e00c2  vmovaps xmm7, [rsp+0x70]
000076cd267e00c8  vmovaps xmm9, [rsp+0x80]
000076cd267e00d1  vmovaps xmm10, [rsp+0x90]
000076cd267e00da  vmovaps xmm11, [rsp+0xA0]
000076cd267e00e3  vmovaps xmm12, [rsp+0xB0]
000076cd267e00ec  vmovaps xmm13, [rsp+0xC0]
000076cd267e00f5  vmovaps xmm14, [rsp+0xD0]
000076cd267e00fe  vmovaps xmm15, [rsp+0xE0]
000076cd267e0107  add rsp, 0xF0
000076cd267e010e  pop r11
000076cd267e0110  pop r10
000076cd267e0112  pop r9
000076cd267e0114  pop r8
000076cd267e0116  pop rsi
000076cd267e0117  pop rdi
000076cd267e0118  pop rdx
000076cd267e0119  pop rcx
000076cd267e011a  pop rax
000076cd267e011b  add rsp, 0x08
000076cd267e011f  jmp 0x000076CD267DC561
000076cd267e0124  sub rsp, 0x08
000076cd267e0128  push rax
000076cd267e0129  push rcx
000076cd267e012a  push rdx
000076cd267e012b  push rdi
000076cd267e012c  push rsi
000076cd267e012d  push r8
000076cd267e012f  push r9
000076cd267e0131  push r10
000076cd267e0133  push r11
000076cd267e0135  sub rsp, 0xF0
000076cd267e013c  vmovaps [rsp], xmm0
000076cd267e0141  vmovaps [rsp+0x10], xmm1
000076cd267e0147  vmovaps [rsp+0x20], xmm2
000076cd267e014d  vmovaps [rsp+0x30], xmm3
000076cd267e0153  vmovaps [rsp+0x40], xmm4
000076cd267e0159  vmovaps [rsp+0x50], xmm5
000076cd267e015f  vmovaps [rsp+0x60], xmm7
000076cd267e0165  vmovaps [rsp+0x70], xmm8
000076cd267e016b  vmovaps [rsp+0x80], xmm9
000076cd267e0174  vmovaps [rsp+0x90], xmm10
000076cd267e017d  vmovaps [rsp+0xA0], xmm11
000076cd267e0186  vmovaps [rsp+0xB0], xmm12
000076cd267e018f  vmovaps [rsp+0xC0], xmm13
000076cd267e0198  vmovaps [rsp+0xD0], xmm14
000076cd267e01a1  vmovaps [rsp+0xE0], xmm15
000076cd267e01aa  sub rsp, 0x30
000076cd267e01ae  movaps [rsp], xmm6
000076cd267e01b2  movaps [rsp+0x10], xmm1
000076cd267e01b7  movaps [rsp+0x20], xmm14
000076cd267e01bd  lea rdi, [rsp]
000076cd267e01c1  mov esi, 0x00
000076cd267e01c6  mov rax, 0x56B8861A9530
000076cd267e01d0  call rax
000076cd267e01d2  movaps xmm6, [rsp]
000076cd267e01d6  add rsp, 0x30
000076cd267e01da  vmovaps xmm0, [rsp]
000076cd267e01df  vmovaps xmm1, [rsp+0x10]
000076cd267e01e5  vmovaps xmm2, [rsp+0x20]
000076cd267e01eb  vmovaps xmm3, [rsp+0x30]
000076cd267e01f1  vmovaps xmm4, [rsp+0x40]
000076cd267e01f7  vmovaps xmm5, [rsp+0x50]
000076cd267e01fd  vmovaps xmm7, [rsp+0x60]
000076cd267e0203  vmovaps xmm8, [rsp+0x70]
000076cd267e0209  vmovaps xmm9, [rsp+0x80]
000076cd267e0212  vmovaps xmm10, [rsp+0x90]
000076cd267e021b  vmovaps xmm11, [rsp+0xA0]
000076cd267e0224  vmovaps xmm12, [rsp+0xB0]
000076cd267e022d  vmovaps xmm13, [rsp+0xC0]
000076cd267e0236  vmovaps xmm14, [rsp+0xD0]
000076cd267e023f  vmovaps xmm15, [rsp+0xE0]
000076cd267e0248  add rsp, 0xF0
000076cd267e024f  pop r11
000076cd267e0251  pop r10
000076cd267e0253  pop r9
000076cd267e0255  pop r8
000076cd267e0257  pop rsi
000076cd267e0258  pop rdi
000076cd267e0259  pop rdx
000076cd267e025a  pop rcx
000076cd267e025b  pop rax
000076cd267e025c  add rsp, 0x08
000076cd267e0260  jmp 0x000076CD267DC58D
000076cd267e0265  sub rsp, 0x08
000076cd267e0269  push rax
000076cd267e026a  push rcx
000076cd267e026b  push rdx
000076cd267e026c  push rdi
000076cd267e026d  push rsi
000076cd267e026e  push r8
000076cd267e0270  push r9
000076cd267e0272  push r10
000076cd267e0274  push r11
000076cd267e0276  sub rsp, 0xF0
000076cd267e027d  vmovaps [rsp], xmm0
000076cd267e0282  vmovaps [rsp+0x10], xmm1
000076cd267e0288  vmovaps [rsp+0x20], xmm2
000076cd267e028e  vmovaps [rsp+0x30], xmm3
000076cd267e0294  vmovaps [rsp+0x40], xmm4
000076cd267e029a  vmovaps [rsp+0x50], xmm5
000076cd267e02a0  vmovaps [rsp+0x60], xmm6
000076cd267e02a6  vmovaps [rsp+0x70], xmm7
000076cd267e02ac  vmovaps [rsp+0x80], xmm8
000076cd267e02b5  vmovaps [rsp+0x90], xmm9
000076cd267e02be  vmovaps [rsp+0xA0], xmm10
000076cd267e02c7  vmovaps [rsp+0xB0], xmm11
000076cd267e02d0  vmovaps [rsp+0xC0], xmm12
000076cd267e02d9  vmovaps [rsp+0xD0], xmm13
000076cd267e02e2  vmovaps [rsp+0xE0], xmm15
000076cd267e02eb  sub rsp, 0x30
000076cd267e02ef  movaps [rsp], xmm14
000076cd267e02f4  movaps [rsp+0x10], xmm12
000076cd267e02fa  movaps [rsp+0x20], xmm1
000076cd267e02ff  lea rdi, [rsp]
000076cd267e0303  mov esi, 0x00
000076cd267e0308  mov rax, 0x56B8861A9530
000076cd267e0312  call rax
000076cd267e0314  movaps xmm14, [rsp]
000076cd267e0319  add rsp, 0x30
000076cd267e031d  vmovaps xmm0, [rsp]
000076cd267e0322  vmovaps xmm1, [rsp+0x10]
000076cd267e0328  vmovaps xmm2, [rsp+0x20]
000076cd267e032e  vmovaps xmm3, [rsp+0x30]
000076cd267e0334  vmovaps xmm4, [rsp+0x40]
000076cd267e033a  vmovaps xmm5, [rsp+0x50]
000076cd267e0340  vmovaps xmm6, [rsp+0x60]
000076cd267e0346  vmovaps xmm7, [rsp+0x70]
000076cd267e034c  vmovaps xmm8, [rsp+0x80]
000076cd267e0355  vmovaps xmm9, [rsp+0x90]
000076cd267e035e  vmovaps xmm10, [rsp+0xA0]
000076cd267e0367  vmovaps xmm11, [rsp+0xB0]
000076cd267e0370  vmovaps xmm12, [rsp+0xC0]
000076cd267e0379  vmovaps xmm13, [rsp+0xD0]
000076cd267e0382  vmovaps xmm15, [rsp+0xE0]
000076cd267e038b  add rsp, 0xF0
000076cd267e0392  pop r11
000076cd267e0394  pop r10
000076cd267e0396  pop r9
000076cd267e0398  pop r8
000076cd267e039a  pop rsi
000076cd267e039b  pop rdi
000076cd267e039c  pop rdx
000076cd267e039d  pop rcx
000076cd267e039e  pop rax
000076cd267e039f  add rsp, 0x08
000076cd267e03a3  jmp 0x000076CD267DC5B3
000076cd267e03a8  sub rsp, 0x08
000076cd267e03ac  push rax
000076cd267e03ad  push rcx
000076cd267e03ae  push rdx
000076cd267e03af  push rdi
000076cd267e03b0  push rsi
000076cd267e03b1  push r8
000076cd267e03b3  push r9
000076cd267e03b5  push r10
000076cd267e03b7  push r11
000076cd267e03b9  sub rsp, 0xF0
000076cd267e03c0  vmovaps [rsp], xmm0
000076cd267e03c5  vmovaps [rsp+0x10], xmm2
000076cd267e03cb  vmovaps [rsp+0x20], xmm3
000076cd267e03d1  vmovaps [rsp+0x30], xmm4
000076cd267e03d7  vmovaps [rsp+0x40], xmm5
000076cd267e03dd  vmovaps [rsp+0x50], xmm6
000076cd267e03e3  vmovaps [rsp+0x60], xmm7
000076cd267e03e9  vmovaps [rsp+0x70], xmm8
000076cd267e03ef  vmovaps [rsp+0x80], xmm9
000076cd267e03f8  vmovaps [rsp+0x90], xmm10
000076cd267e0401  vmovaps [rsp+0xA0], xmm11
000076cd267e040a  vmovaps [rsp+0xB0], xmm12
000076cd267e0413  vmovaps [rsp+0xC0], xmm13
000076cd267e041c  vmovaps [rsp+0xD0], xmm14
000076cd267e0425  vmovaps [rsp+0xE0], xmm15
000076cd267e042e  sub rsp, 0x30
000076cd267e0432  movaps [rsp], xmm1
000076cd267e0436  movaps [rsp+0x10], xmm13
000076cd267e043c  movaps [rsp+0x20], xmm9
000076cd267e0442  lea rdi, [rsp]
000076cd267e0446  mov esi, 0x00
000076cd267e044b  mov rax, 0x56B8861A9530
000076cd267e0455  call rax
000076cd267e0457  movaps xmm1, [rsp]
000076cd267e045b  add rsp, 0x30
000076cd267e045f  vmovaps xmm0, [rsp]
000076cd267e0464  vmovaps xmm2, [rsp+0x10]
000076cd267e046a  vmovaps xmm3, [rsp+0x20]
000076cd267e0470  vmovaps xmm4, [rsp+0x30]
000076cd267e0476  vmovaps xmm5, [rsp+0x40]
000076cd267e047c  vmovaps xmm6, [rsp+0x50]
000076cd267e0482  vmovaps xmm7, [rsp+0x60]
000076cd267e0488  vmovaps xmm8, [rsp+0x70]
000076cd267e048e  vmovaps xmm9, [rsp+0x80]
000076cd267e0497  vmovaps xmm10, [rsp+0x90]
000076cd267e04a0  vmovaps xmm11, [rsp+0xA0]
000076cd267e04a9  vmovaps xmm12, [rsp+0xB0]
000076cd267e04b2  vmovaps xmm13, [rsp+0xC0]
000076cd267e04bb  vmovaps xmm14, [rsp+0xD0]
000076cd267e04c4  vmovaps xmm15, [rsp+0xE0]
000076cd267e04cd  add rsp, 0xF0
000076cd267e04d4  pop r11
000076cd267e04d6  pop r10
000076cd267e04d8  pop r9
000076cd267e04da  pop r8
000076cd267e04dc  pop rsi
000076cd267e04dd  pop rdi
000076cd267e04de  pop rdx
000076cd267e04df  pop rcx
000076cd267e04e0  pop rax
000076cd267e04e1  add rsp, 0x08
000076cd267e04e5  jmp 0x000076CD267DC5CD
000076cd267e04ea  sub rsp, 0x08
000076cd267e04ee  push rax
000076cd267e04ef  push rcx
000076cd267e04f0  push rdx
000076cd267e04f1  push rdi
000076cd267e04f2  push rsi
000076cd267e04f3  push r8
000076cd267e04f5  push r9
000076cd267e04f7  push r10
000076cd267e04f9  push r11
000076cd267e04fb  sub rsp, 0xF0
000076cd267e0502  vmovaps [rsp], xmm0
000076cd267e0507  vmovaps [rsp+0x10], xmm1
000076cd267e050d  vmovaps [rsp+0x20], xmm2
000076cd267e0513  vmovaps [rsp+0x30], xmm3
000076cd267e0519  vmovaps [rsp+0x40], xmm4
000076cd267e051f  vmovaps [rsp+0x50], xmm5
000076cd267e0525  vmovaps [rsp+0x60], xmm6
000076cd267e052b  vmovaps [rsp+0x70], xmm7
000076cd267e0531  vmovaps [rsp+0x80], xmm8
000076cd267e053a  vmovaps [rsp+0x90], xmm9
000076cd267e0543  vmovaps [rsp+0xA0], xmm10
000076cd267e054c  vmovaps [rsp+0xB0], xmm11
000076cd267e0555  vmovaps [rsp+0xC0], xmm13
000076cd267e055e  vmovaps [rsp+0xD0], xmm14
000076cd267e0567  vmovaps [rsp+0xE0], xmm15
000076cd267e0570  sub rsp, 0x30
000076cd267e0574  movaps [rsp], xmm12
000076cd267e0579  movaps [rsp+0x10], xmm7
000076cd267e057e  movaps [rsp+0x20], xmm13
000076cd267e0584  lea rdi, [rsp]
000076cd267e0588  mov esi, 0x00
000076cd267e058d  mov rax, 0x56B8861A9530
000076cd267e0597  call rax
000076cd267e0599  movaps xmm12, [rsp]
000076cd267e059e  add rsp, 0x30
000076cd267e05a2  vmovaps xmm0, [rsp]
000076cd267e05a7  vmovaps xmm1, [rsp+0x10]
000076cd267e05ad  vmovaps xmm2, [rsp+0x20]
000076cd267e05b3  vmovaps xmm3, [rsp+0x30]
000076cd267e05b9  vmovaps xmm4, [rsp+0x40]
000076cd267e05bf  vmovaps xmm5, [rsp+0x50]
000076cd267e05c5  vmovaps xmm6, [rsp+0x60]
000076cd267e05cb  vmovaps xmm7, [rsp+0x70]
000076cd267e05d1  vmovaps xmm8, [rsp+0x80]
000076cd267e05da  vmovaps xmm9, [rsp+0x90]
000076cd267e05e3  vmovaps xmm10, [rsp+0xA0]
000076cd267e05ec  vmovaps xmm11, [rsp+0xB0]
000076cd267e05f5  vmovaps xmm13, [rsp+0xC0]
000076cd267e05fe  vmovaps xmm14, [rsp+0xD0]
000076cd267e0607  vmovaps xmm15, [rsp+0xE0]
000076cd267e0610  add rsp, 0xF0
000076cd267e0617  pop r11
000076cd267e0619  pop r10
000076cd267e061b  pop r9
000076cd267e061d  pop r8
000076cd267e061f  pop rsi
000076cd267e0620  pop rdi
000076cd267e0621  pop rdx
000076cd267e0622  pop rcx
000076cd267e0623  pop rax
000076cd267e0624  add rsp, 0x08
000076cd267e0628  jmp 0x000076CD267DC5F4
000076cd267e062d  sub rsp, 0x08
000076cd267e0631  push rax
000076cd267e0632  push rcx
000076cd267e0633  push rdx
000076cd267e0634  push rdi
000076cd267e0635  push rsi
000076cd267e0636  push r8
000076cd267e0638  push r9
000076cd267e063a  push r10
000076cd267e063c  push r11
000076cd267e063e  sub rsp, 0xF0
000076cd267e0645  vmovaps [rsp], xmm0
000076cd267e064a  vmovaps [rsp+0x10], xmm1
000076cd267e0650  vmovaps [rsp+0x20], xmm2
000076cd267e0656  vmovaps [rsp+0x30], xmm3
000076cd267e065c  vmovaps [rsp+0x40], xmm4
000076cd267e0662  vmovaps [rsp+0x50], xmm5
000076cd267e0668  vmovaps [rsp+0x60], xmm6
000076cd267e066e  vmovaps [rsp+0x70], xmm7
000076cd267e0674  vmovaps [rsp+0x80], xmm8
000076cd267e067d  vmovaps [rsp+0x90], xmm9
000076cd267e0686  vmovaps [rsp+0xA0], xmm10
000076cd267e068f  vmovaps [rsp+0xB0], xmm11
000076cd267e0698  vmovaps [rsp+0xC0], xmm12
000076cd267e06a1  vmovaps [rsp+0xD0], xmm14
000076cd267e06aa  vmovaps [rsp+0xE0], xmm15
000076cd267e06b3  sub rsp, 0x30
000076cd267e06b7  movaps [rsp], xmm13
000076cd267e06bc  movaps [rsp+0x10], xmm15
000076cd267e06c2  movaps [rsp+0x20], xmm8
000076cd267e06c8  lea rdi, [rsp]
000076cd267e06cc  mov esi, 0x00
000076cd267e06d1  mov rax, 0x56B8861A9530
000076cd267e06db  call rax
000076cd267e06dd  movaps xmm13, [rsp]
000076cd267e06e2  add rsp, 0x30
000076cd267e06e6  vmovaps xmm0, [rsp]
000076cd267e06eb  vmovaps xmm1, [rsp+0x10]
000076cd267e06f1  vmovaps xmm2, [rsp+0x20]
000076cd267e06f7  vmovaps xmm3, [rsp+0x30]
000076cd267e06fd  vmovaps xmm4, [rsp+0x40]
000076cd267e0703  vmovaps xmm5, [rsp+0x50]
000076cd267e0709  vmovaps xmm6, [rsp+0x60]
000076cd267e070f  vmovaps xmm7, [rsp+0x70]
000076cd267e0715  vmovaps xmm8, [rsp+0x80]
000076cd267e071e  vmovaps xmm9, [rsp+0x90]
000076cd267e0727  vmovaps xmm10, [rsp+0xA0]
000076cd267e0730  vmovaps xmm11, [rsp+0xB0]
000076cd267e0739  vmovaps xmm12, [rsp+0xC0]
000076cd267e0742  vmovaps xmm14, [rsp+0xD0]
000076cd267e074b  vmovaps xmm15, [rsp+0xE0]
000076cd267e0754  add rsp, 0xF0
000076cd267e075b  pop r11
000076cd267e075d  pop r10
000076cd267e075f  pop r9
000076cd267e0761  pop r8
000076cd267e0763  pop rsi
000076cd267e0764  pop rdi
000076cd267e0765  pop rdx
000076cd267e0766  pop rcx
000076cd267e0767  pop rax
000076cd267e0768  add rsp, 0x08
000076cd267e076c  jmp 0x000076CD267DC60F
000076cd267e0771  sub rsp, 0x08
000076cd267e0775  push rax
000076cd267e0776  push rcx
000076cd267e0777  push rdx
000076cd267e0778  push rdi
000076cd267e0779  push rsi
000076cd267e077a  push r8
000076cd267e077c  push r9
000076cd267e077e  push r10
000076cd267e0780  push r11
000076cd267e0782  sub rsp, 0xF0
000076cd267e0789  vmovaps [rsp], xmm0
000076cd267e078e  vmovaps [rsp+0x10], xmm1
000076cd267e0794  vmovaps [rsp+0x20], xmm2
000076cd267e079a  vmovaps [rsp+0x30], xmm3
000076cd267e07a0  vmovaps [rsp+0x40], xmm4
000076cd267e07a6  vmovaps [rsp+0x50], xmm5
000076cd267e07ac  vmovaps [rsp+0x60], xmm6
000076cd267e07b2  vmovaps [rsp+0x70], xmm7
000076cd267e07b8  vmovaps [rsp+0x80], xmm9
000076cd267e07c1  vmovaps [rsp+0x90], xmm10
000076cd267e07ca  vmovaps [rsp+0xA0], xmm11
000076cd267e07d3  vmovaps [rsp+0xB0], xmm12
000076cd267e07dc  vmovaps [rsp+0xC0], xmm13
000076cd267e07e5  vmovaps [rsp+0xD0], xmm14
000076cd267e07ee  vmovaps [rsp+0xE0], xmm15
000076cd267e07f7  sub rsp, 0x30
000076cd267e07fb  movaps [rsp], xmm8
000076cd267e0800  movaps [rsp+0x10], xmm15
000076cd267e0806  movaps [rsp+0x20], xmm9
000076cd267e080c  lea rdi, [rsp]
000076cd267e0810  mov esi, 0x00
000076cd267e0815  mov rax, 0x56B8861A9530
000076cd267e081f  call rax
000076cd267e0821  movaps xmm8, [rsp]
000076cd267e0826  add rsp, 0x30
000076cd267e082a  vmovaps xmm0, [rsp]
000076cd267e082f  vmovaps xmm1, [rsp+0x10]
000076cd267e0835  vmovaps xmm2, [rsp+0x20]
000076cd267e083b  vmovaps xmm3, [rsp+0x30]
000076cd267e0841  vmovaps xmm4, [rsp+0x40]
000076cd267e0847  vmovaps xmm5, [rsp+0x50]
000076cd267e084d  vmovaps xmm6, [rsp+0x60]
000076cd267e0853  vmovaps xmm7, [rsp+0x70]
000076cd267e0859  vmovaps xmm9, [rsp+0x80]
000076cd267e0862  vmovaps xmm10, [rsp+0x90]
000076cd267e086b  vmovaps xmm11, [rsp+0xA0]
000076cd267e0874  vmovaps xmm12, [rsp+0xB0]
000076cd267e087d  vmovaps xmm13, [rsp+0xC0]
000076cd267e0886  vmovaps xmm14, [rsp+0xD0]
000076cd267e088f  vmovaps xmm15, [rsp+0xE0]
000076cd267e0898  add rsp, 0xF0
000076cd267e089f  pop r11
000076cd267e08a1  pop r10
000076cd267e08a3  pop r9
000076cd267e08a5  pop r8
000076cd267e08a7  pop rsi
000076cd267e08a8  pop rdi
000076cd267e08a9  pop rdx
000076cd267e08aa  pop rcx
000076cd267e08ab  pop rax
000076cd267e08ac  add rsp, 0x08
000076cd267e08b0  jmp 0x000076CD267DC63D
000076cd267e08b5  sub rsp, 0x08
000076cd267e08b9  push rax
000076cd267e08ba  push rcx
000076cd267e08bb  push rdx
000076cd267e08bc  push rdi
000076cd267e08bd  push rsi
000076cd267e08be  push r8
000076cd267e08c0  push r9
000076cd267e08c2  push r10
000076cd267e08c4  push r11
000076cd267e08c6  sub rsp, 0xF0
000076cd267e08cd  vmovaps [rsp], xmm0
000076cd267e08d2  vmovaps [rsp+0x10], xmm1
000076cd267e08d8  vmovaps [rsp+0x20], xmm2
000076cd267e08de  vmovaps [rsp+0x30], xmm3
000076cd267e08e4  vmovaps [rsp+0x40], xmm4
000076cd267e08ea  vmovaps [rsp+0x50], xmm5
000076cd267e08f0  vmovaps [rsp+0x60], xmm6
000076cd267e08f6  vmovaps [rsp+0x70], xmm7
000076cd267e08fc  vmovaps [rsp+0x80], xmm8
000076cd267e0905  vmovaps [rsp+0x90], xmm9
000076cd267e090e  vmovaps [rsp+0xA0], xmm10
000076cd267e0917  vmovaps [rsp+0xB0], xmm11
000076cd267e0920  vmovaps [rsp+0xC0], xmm12
000076cd267e0929  vmovaps [rsp+0xD0], xmm13
000076cd267e0932  vmovaps [rsp+0xE0], xmm14
000076cd267e093b  sub rsp, 0x30
000076cd267e093f  movaps [rsp], xmm15
000076cd267e0944  movaps [rsp+0x10], xmm11
000076cd267e094a  movaps [rsp+0x20], xmm6
000076cd267e094f  lea rdi, [rsp]
000076cd267e0953  mov esi, 0x00
000076cd267e0958  mov rax, 0x56B8861A9530
000076cd267e0962  call rax
000076cd267e0964  movaps xmm15, [rsp]
000076cd267e0969  add rsp, 0x30
000076cd267e096d  vmovaps xmm0, [rsp]
000076cd267e0972  vmovaps xmm1, [rsp+0x10]
000076cd267e0978  vmovaps xmm2, [rsp+0x20]
000076cd267e097e  vmovaps xmm3, [rsp+0x30]
000076cd267e0984  vmovaps xmm4, [rsp+0x40]
000076cd267e098a  vmovaps xmm5, [rsp+0x50]
000076cd267e0990  vmovaps xmm6, [rsp+0x60]
000076cd267e0996  vmovaps xmm7, [rsp+0x70]
000076cd267e099c  vmovaps xmm8, [rsp+0x80]
000076cd267e09a5  vmovaps xmm9, [rsp+0x90]
000076cd267e09ae  vmovaps xmm10, [rsp+0xA0]
000076cd267e09b7  vmovaps xmm11, [rsp+0xB0]
000076cd267e09c0  vmovaps xmm12, [rsp+0xC0]
000076cd267e09c9  vmovaps xmm13, [rsp+0xD0]
000076cd267e09d2  vmovaps xmm14, [rsp+0xE0]
000076cd267e09db  add rsp, 0xF0
000076cd267e09e2  pop r11
000076cd267e09e4  pop r10
000076cd267e09e6  pop r9
000076cd267e09e8  pop r8
000076cd267e09ea  pop rsi
000076cd267e09eb  pop rdi
000076cd267e09ec  pop rdx
000076cd267e09ed  pop rcx
000076cd267e09ee  pop rax
000076cd267e09ef  add rsp, 0x08
000076cd267e09f3  jmp 0x000076CD267DC658
000076cd267e09f8  sub rsp, 0x08
000076cd267e09fc  push rax
000076cd267e09fd  push rcx
000076cd267e09fe  push rdx
000076cd267e09ff  push rdi
000076cd267e0a00  push rsi
000076cd267e0a01  push r8
000076cd267e0a03  push r9
000076cd267e0a05  push r10
000076cd267e0a07  push r11
000076cd267e0a09  sub rsp, 0xF0
000076cd267e0a10  vmovaps [rsp], xmm0
000076cd267e0a15  vmovaps [rsp+0x10], xmm1
000076cd267e0a1b  vmovaps [rsp+0x20], xmm2
000076cd267e0a21  vmovaps [rsp+0x30], xmm3
000076cd267e0a27  vmovaps [rsp+0x40], xmm4
000076cd267e0a2d  vmovaps [rsp+0x50], xmm5
000076cd267e0a33  vmovaps [rsp+0x60], xmm6
000076cd267e0a39  vmovaps [rsp+0x70], xmm8
000076cd267e0a3f  vmovaps [rsp+0x80], xmm9
000076cd267e0a48  vmovaps [rsp+0x90], xmm10
000076cd267e0a51  vmovaps [rsp+0xA0], xmm11
000076cd267e0a5a  vmovaps [rsp+0xB0], xmm12
000076cd267e0a63  vmovaps [rsp+0xC0], xmm13
000076cd267e0a6c  vmovaps [rsp+0xD0], xmm14
000076cd267e0a75  vmovaps [rsp+0xE0], xmm15
000076cd267e0a7e  sub rsp, 0x30
000076cd267e0a82  movaps [rsp], xmm7
000076cd267e0a86  movaps [rsp+0x10], xmm11
000076cd267e0a8c  movaps [rsp+0x20], xmm9
000076cd267e0a92  lea rdi, [rsp]
000076cd267e0a96  mov esi, 0x00
000076cd267e0a9b  mov rax, 0x56B8861A9530
000076cd267e0aa5  call rax
000076cd267e0aa7  movaps xmm7, [rsp]
000076cd267e0aab  add rsp, 0x30
000076cd267e0aaf  vmovaps xmm0, [rsp]
000076cd267e0ab4  vmovaps xmm1, [rsp+0x10]
000076cd267e0aba  vmovaps xmm2, [rsp+0x20]
000076cd267e0ac0  vmovaps xmm3, [rsp+0x30]
000076cd267e0ac6  vmovaps xmm4, [rsp+0x40]
000076cd267e0acc  vmovaps xmm5, [rsp+0x50]
000076cd267e0ad2  vmovaps xmm6, [rsp+0x60]
000076cd267e0ad8  vmovaps xmm8, [rsp+0x70]
000076cd267e0ade  vmovaps xmm9, [rsp+0x80]
000076cd267e0ae7  vmovaps xmm10, [rsp+0x90]
000076cd267e0af0  vmovaps xmm11, [rsp+0xA0]
000076cd267e0af9  vmovaps xmm12, [rsp+0xB0]
000076cd267e0b02  vmovaps xmm13, [rsp+0xC0]
000076cd267e0b0b  vmovaps xmm14, [rsp+0xD0]
000076cd267e0b14  vmovaps xmm15, [rsp+0xE0]
000076cd267e0b1d  add rsp, 0xF0
000076cd267e0b24  pop r11
000076cd267e0b26  pop r10
000076cd267e0b28  pop r9
000076cd267e0b2a  pop r8
000076cd267e0b2c  pop rsi
000076cd267e0b2d  pop rdi
000076cd267e0b2e  pop rdx
000076cd267e0b2f  pop rcx
000076cd267e0b30  pop rax
000076cd267e0b31  add rsp, 0x08
000076cd267e0b35  jmp 0x000076CD267DC685
000076cd267e0b3a  sub rsp, 0x08
000076cd267e0b3e  push rax
000076cd267e0b3f  push rcx
000076cd267e0b40  push rdx
000076cd267e0b41  push rdi
000076cd267e0b42  push rsi
000076cd267e0b43  push r8
000076cd267e0b45  push r9
000076cd267e0b47  push r10
000076cd267e0b49  push r11
000076cd267e0b4b  sub rsp, 0xF0
000076cd267e0b52  vmovaps [rsp], xmm0
000076cd267e0b57  vmovaps [rsp+0x10], xmm1
000076cd267e0b5d  vmovaps [rsp+0x20], xmm2
000076cd267e0b63  vmovaps [rsp+0x30], xmm3
000076cd267e0b69  vmovaps [rsp+0x40], xmm4
000076cd267e0b6f  vmovaps [rsp+0x50], xmm5
000076cd267e0b75  vmovaps [rsp+0x60], xmm6
000076cd267e0b7b  vmovaps [rsp+0x70], xmm7
000076cd267e0b81  vmovaps [rsp+0x80], xmm8
000076cd267e0b8a  vmovaps [rsp+0x90], xmm9
000076cd267e0b93  vmovaps [rsp+0xA0], xmm10
000076cd267e0b9c  vmovaps [rsp+0xB0], xmm12
000076cd267e0ba5  vmovaps [rsp+0xC0], xmm13
000076cd267e0bae  vmovaps [rsp+0xD0], xmm14
000076cd267e0bb7  vmovaps [rsp+0xE0], xmm15
000076cd267e0bc0  sub rsp, 0x30
000076cd267e0bc4  movaps [rsp], xmm11
000076cd267e0bc9  movaps [rsp+0x10], xmm10
000076cd267e0bcf  movaps [rsp+0x20], xmm14
000076cd267e0bd5  lea rdi, [rsp]
000076cd267e0bd9  mov esi, 0x00
000076cd267e0bde  mov rax, 0x56B8861A9530
000076cd267e0be8  call rax
000076cd267e0bea  movaps xmm11, [rsp]
000076cd267e0bef  add rsp, 0x30
000076cd267e0bf3  vmovaps xmm0, [rsp]
000076cd267e0bf8  vmovaps xmm1, [rsp+0x10]
000076cd267e0bfe  vmovaps xmm2, [rsp+0x20]
000076cd267e0c04  vmovaps xmm3, [rsp+0x30]
000076cd267e0c0a  vmovaps xmm4, [rsp+0x40]
000076cd267e0c10  vmovaps xmm5, [rsp+0x50]
000076cd267e0c16  vmovaps xmm6, [rsp+0x60]
000076cd267e0c1c  vmovaps xmm7, [rsp+0x70]
000076cd267e0c22  vmovaps xmm8, [rsp+0x80]
000076cd267e0c2b  vmovaps xmm9, [rsp+0x90]
000076cd267e0c34  vmovaps xmm10, [rsp+0xA0]
000076cd267e0c3d  vmovaps xmm12, [rsp+0xB0]
000076cd267e0c46  vmovaps xmm13, [rsp+0xC0]
000076cd267e0c4f  vmovaps xmm14, [rsp+0xD0]
000076cd267e0c58  vmovaps xmm15, [rsp+0xE0]
000076cd267e0c61  add rsp, 0xF0
000076cd267e0c68  pop r11
000076cd267e0c6a  pop r10
000076cd267e0c6c  pop r9
000076cd267e0c6e  pop r8
000076cd267e0c70  pop rsi
000076cd267e0c71  pop rdi
000076cd267e0c72  pop rdx
000076cd267e0c73  pop rcx
000076cd267e0c74  pop rax
000076cd267e0c75  add rsp, 0x08
000076cd267e0c79  jmp 0x000076CD267DC6A0
000076cd267e0c7e  call 0x000076CD266C33A0
000076cd267e0c83  jmp 0x000076CD267DC6AA
000076cd267e0c88  sub rsp, 0x08
000076cd267e0c8c  push rax
000076cd267e0c8d  push rcx
000076cd267e0c8e  push rdx
000076cd267e0c8f  push rdi
000076cd267e0c90  push rsi
000076cd267e0c91  push r8
000076cd267e0c93  push r9
000076cd267e0c95  push r10
000076cd267e0c97  push r11
000076cd267e0c99  sub rsp, 0xF0
000076cd267e0ca0  vmovaps [rsp], xmm0
000076cd267e0ca5  vmovaps [rsp+0x10], xmm1
000076cd267e0cab  vmovaps [rsp+0x20], xmm2
000076cd267e0cb1  vmovaps [rsp+0x30], xmm3
000076cd267e0cb7  vmovaps [rsp+0x40], xmm4
000076cd267e0cbd  vmovaps [rsp+0x50], xmm5
000076cd267e0cc3  vmovaps [rsp+0x60], xmm6
000076cd267e0cc9  vmovaps [rsp+0x70], xmm7
000076cd267e0ccf  vmovaps [rsp+0x80], xmm8
000076cd267e0cd8  vmovaps [rsp+0x90], xmm9
000076cd267e0ce1  vmovaps [rsp+0xA0], xmm11
000076cd267e0cea  vmovaps [rsp+0xB0], xmm12
000076cd267e0cf3  vmovaps [rsp+0xC0], xmm13
000076cd267e0cfc  vmovaps [rsp+0xD0], xmm14
000076cd267e0d05  vmovaps [rsp+0xE0], xmm15
000076cd267e0d0e  sub rsp, 0x30
000076cd267e0d12  movaps [rsp], xmm10
000076cd267e0d17  movaps [rsp+0x10], xmm1
000076cd267e0d1c  movaps [rsp+0x20], xmm12
000076cd267e0d22  lea rdi, [rsp]
000076cd267e0d26  mov esi, 0x00
000076cd267e0d2b  mov rax, 0x56B8861A9530
000076cd267e0d35  call rax
000076cd267e0d37  movaps xmm10, [rsp]
000076cd267e0d3c  add rsp, 0x30
000076cd267e0d40  vmovaps xmm0, [rsp]
000076cd267e0d45  vmovaps xmm1, [rsp+0x10]
000076cd267e0d4b  vmovaps xmm2, [rsp+0x20]
000076cd267e0d51  vmovaps xmm3, [rsp+0x30]
000076cd267e0d57  vmovaps xmm4, [rsp+0x40]
000076cd267e0d5d  vmovaps xmm5, [rsp+0x50]
000076cd267e0d63  vmovaps xmm6, [rsp+0x60]
000076cd267e0d69  vmovaps xmm7, [rsp+0x70]
000076cd267e0d6f  vmovaps xmm8, [rsp+0x80]
000076cd267e0d78  vmovaps xmm9, [rsp+0x90]
000076cd267e0d81  vmovaps xmm11, [rsp+0xA0]
000076cd267e0d8a  vmovaps xmm12, [rsp+0xB0]
000076cd267e0d93  vmovaps xmm13, [rsp+0xC0]
000076cd267e0d9c  vmovaps xmm14, [rsp+0xD0]
000076cd267e0da5  vmovaps xmm15, [rsp+0xE0]
000076cd267e0dae  add rsp, 0xF0
000076cd267e0db5  pop r11
000076cd267e0db7  pop r10
000076cd267e0db9  pop r9
000076cd267e0dbb  pop r8
000076cd267e0dbd  pop rsi
000076cd267e0dbe  pop rdi
000076cd267e0dbf  pop rdx
000076cd267e0dc0  pop rcx
000076cd267e0dc1  pop rax
000076cd267e0dc2  add rsp, 0x08
000076cd267e0dc6  jmp 0x000076CD267DC6CD
000076cd267e0dcb  sub rsp, 0x08
000076cd267e0dcf  push rax
000076cd267e0dd0  push rcx
000076cd267e0dd1  push rdx
000076cd267e0dd2  push rdi
000076cd267e0dd3  push rsi
000076cd267e0dd4  push r8
000076cd267e0dd6  push r9
000076cd267e0dd8  push r10
000076cd267e0dda  push r11
000076cd267e0ddc  sub rsp, 0xF0
000076cd267e0de3  vmovaps [rsp], xmm0
000076cd267e0de8  vmovaps [rsp+0x10], xmm1
000076cd267e0dee  vmovaps [rsp+0x20], xmm2
000076cd267e0df4  vmovaps [rsp+0x30], xmm3
000076cd267e0dfa  vmovaps [rsp+0x40], xmm4
000076cd267e0e00  vmovaps [rsp+0x50], xmm5
000076cd267e0e06  vmovaps [rsp+0x60], xmm6
000076cd267e0e0c  vmovaps [rsp+0x70], xmm7
000076cd267e0e12  vmovaps [rsp+0x80], xmm8
000076cd267e0e1b  vmovaps [rsp+0x90], xmm9
000076cd267e0e24  vmovaps [rsp+0xA0], xmm10
000076cd267e0e2d  vmovaps [rsp+0xB0], xmm11
000076cd267e0e36  vmovaps [rsp+0xC0], xmm13
000076cd267e0e3f  vmovaps [rsp+0xD0], xmm14
000076cd267e0e48  vmovaps [rsp+0xE0], xmm15
000076cd267e0e51  sub rsp, 0x30
000076cd267e0e55  movaps [rsp], xmm12
000076cd267e0e5a  movaps [rsp+0x10], xmm14
000076cd267e0e60  movaps [rsp+0x20], xmm1
000076cd267e0e65  lea rdi, [rsp]
000076cd267e0e69  mov esi, 0x00
000076cd267e0e6e  mov rax, 0x56B8861A9530
000076cd267e0e78  call rax
000076cd267e0e7a  movaps xmm12, [rsp]
000076cd267e0e7f  add rsp, 0x30
000076cd267e0e83  vmovaps xmm0, [rsp]
000076cd267e0e88  vmovaps xmm1, [rsp+0x10]
000076cd267e0e8e  vmovaps xmm2, [rsp+0x20]
000076cd267e0e94  vmovaps xmm3, [rsp+0x30]
000076cd267e0e9a  vmovaps xmm4, [rsp+0x40]
000076cd267e0ea0  vmovaps xmm5, [rsp+0x50]
000076cd267e0ea6  vmovaps xmm6, [rsp+0x60]
000076cd267e0eac  vmovaps xmm7, [rsp+0x70]
000076cd267e0eb2  vmovaps xmm8, [rsp+0x80]
000076cd267e0ebb  vmovaps xmm9, [rsp+0x90]
000076cd267e0ec4  vmovaps xmm10, [rsp+0xA0]
000076cd267e0ecd  vmovaps xmm11, [rsp+0xB0]
000076cd267e0ed6  vmovaps xmm13, [rsp+0xC0]
000076cd267e0edf  vmovaps xmm14, [rsp+0xD0]
000076cd267e0ee8  vmovaps xmm15, [rsp+0xE0]
000076cd267e0ef1  add rsp, 0xF0
000076cd267e0ef8  pop r11
000076cd267e0efa  pop r10
000076cd267e0efc  pop r9
000076cd267e0efe  pop r8
000076cd267e0f00  pop rsi
000076cd267e0f01  pop rdi
000076cd267e0f02  pop rdx
000076cd267e0f03  pop rcx
000076cd267e0f04  pop rax
000076cd267e0f05  add rsp, 0x08
000076cd267e0f09  jmp 0x000076CD267DC6FC
000076cd267e0f0e  sub rsp, 0x08
000076cd267e0f12  push rax
000076cd267e0f13  push rcx
000076cd267e0f14  push rdx
000076cd267e0f15  push rdi
000076cd267e0f16  push rsi
000076cd267e0f17  push r8
000076cd267e0f19  push r9
000076cd267e0f1b  push r10
000076cd267e0f1d  push r11
000076cd267e0f1f  sub rsp, 0xF0
000076cd267e0f26  vmovaps [rsp], xmm0
000076cd267e0f2b  vmovaps [rsp+0x10], xmm1
000076cd267e0f31  vmovaps [rsp+0x20], xmm2
000076cd267e0f37  vmovaps [rsp+0x30], xmm3
000076cd267e0f3d  vmovaps [rsp+0x40], xmm4
000076cd267e0f43  vmovaps [rsp+0x50], xmm5
000076cd267e0f49  vmovaps [rsp+0x60], xmm6
000076cd267e0f4f  vmovaps [rsp+0x70], xmm7
000076cd267e0f55  vmovaps [rsp+0x80], xmm8
000076cd267e0f5e  vmovaps [rsp+0x90], xmm9
000076cd267e0f67  vmovaps [rsp+0xA0], xmm10
000076cd267e0f70  vmovaps [rsp+0xB0], xmm11
000076cd267e0f79  vmovaps [rsp+0xC0], xmm12
000076cd267e0f82  vmovaps [rsp+0xD0], xmm13
000076cd267e0f8b  vmovaps [rsp+0xE0], xmm15
000076cd267e0f94  sub rsp, 0x30
000076cd267e0f98  movaps [rsp], xmm14
000076cd267e0f9d  movaps [rsp+0x10], xmm9
000076cd267e0fa3  movaps [rsp+0x20], xmm1
000076cd267e0fa8  lea rdi, [rsp]
000076cd267e0fac  mov esi, 0x00
000076cd267e0fb1  mov rax, 0x56B8861A9530
000076cd267e0fbb  call rax
000076cd267e0fbd  movaps xmm14, [rsp]
000076cd267e0fc2  add rsp, 0x30
000076cd267e0fc6  vmovaps xmm0, [rsp]
000076cd267e0fcb  vmovaps xmm1, [rsp+0x10]
000076cd267e0fd1  vmovaps xmm2, [rsp+0x20]
000076cd267e0fd7  vmovaps xmm3, [rsp+0x30]
000076cd267e0fdd  vmovaps xmm4, [rsp+0x40]
000076cd267e0fe3  vmovaps xmm5, [rsp+0x50]
000076cd267e0fe9  vmovaps xmm6, [rsp+0x60]
000076cd267e0fef  vmovaps xmm7, [rsp+0x70]
000076cd267e0ff5  vmovaps xmm8, [rsp+0x80]
000076cd267e0ffe  vmovaps xmm9, [rsp+0x90]
000076cd267e1007  vmovaps xmm10, [rsp+0xA0]
000076cd267e1010  vmovaps xmm11, [rsp+0xB0]
000076cd267e1019  vmovaps xmm12, [rsp+0xC0]
000076cd267e1022  vmovaps xmm13, [rsp+0xD0]
000076cd267e102b  vmovaps xmm15, [rsp+0xE0]
000076cd267e1034  add rsp, 0xF0
000076cd267e103b  pop r11
000076cd267e103d  pop r10
000076cd267e103f  pop r9
000076cd267e1041  pop r8
000076cd267e1043  pop rsi
000076cd267e1044  pop rdi
000076cd267e1045  pop rdx
000076cd267e1046  pop rcx
000076cd267e1047  pop rax
000076cd267e1048  add rsp, 0x08
000076cd267e104c  jmp 0x000076CD267DC72B
000076cd267e1051  sub rsp, 0x08
000076cd267e1055  push rax
000076cd267e1056  push rcx
000076cd267e1057  push rdx
000076cd267e1058  push rdi
000076cd267e1059  push rsi
000076cd267e105a  push r8
000076cd267e105c  push r9
000076cd267e105e  push r10
000076cd267e1060  push r11
000076cd267e1062  sub rsp, 0xF0
000076cd267e1069  vmovaps [rsp], xmm0
000076cd267e106e  vmovaps [rsp+0x10], xmm2
000076cd267e1074  vmovaps [rsp+0x20], xmm3
000076cd267e107a  vmovaps [rsp+0x30], xmm4
000076cd267e1080  vmovaps [rsp+0x40], xmm5
000076cd267e1086  vmovaps [rsp+0x50], xmm6
000076cd267e108c  vmovaps [rsp+0x60], xmm7
000076cd267e1092  vmovaps [rsp+0x70], xmm8
000076cd267e1098  vmovaps [rsp+0x80], xmm9
000076cd267e10a1  vmovaps [rsp+0x90], xmm10
000076cd267e10aa  vmovaps [rsp+0xA0], xmm11
000076cd267e10b3  vmovaps [rsp+0xB0], xmm12
000076cd267e10bc  vmovaps [rsp+0xC0], xmm13
000076cd267e10c5  vmovaps [rsp+0xD0], xmm14
000076cd267e10ce  vmovaps [rsp+0xE0], xmm15
000076cd267e10d7  sub rsp, 0x30
000076cd267e10db  movaps [rsp], xmm1
000076cd267e10df  movaps [rsp+0x10], xmm13
000076cd267e10e5  movaps [rsp+0x20], xmm8
000076cd267e10eb  lea rdi, [rsp]
000076cd267e10ef  mov esi, 0x00
000076cd267e10f4  mov rax, 0x56B8861A9530
000076cd267e10fe  call rax
000076cd267e1100  movaps xmm1, [rsp]
000076cd267e1104  add rsp, 0x30
000076cd267e1108  vmovaps xmm0, [rsp]
000076cd267e110d  vmovaps xmm2, [rsp+0x10]
000076cd267e1113  vmovaps xmm3, [rsp+0x20]
000076cd267e1119  vmovaps xmm4, [rsp+0x30]
000076cd267e111f  vmovaps xmm5, [rsp+0x40]
000076cd267e1125  vmovaps xmm6, [rsp+0x50]
000076cd267e112b  vmovaps xmm7, [rsp+0x60]
000076cd267e1131  vmovaps xmm8, [rsp+0x70]
000076cd267e1137  vmovaps xmm9, [rsp+0x80]
000076cd267e1140  vmovaps xmm10, [rsp+0x90]
000076cd267e1149  vmovaps xmm11, [rsp+0xA0]
000076cd267e1152  vmovaps xmm12, [rsp+0xB0]
000076cd267e115b  vmovaps xmm13, [rsp+0xC0]
000076cd267e1164  vmovaps xmm14, [rsp+0xD0]
000076cd267e116d  vmovaps xmm15, [rsp+0xE0]
000076cd267e1176  add rsp, 0xF0
000076cd267e117d  pop r11
000076cd267e117f  pop r10
000076cd267e1181  pop r9
000076cd267e1183  pop r8
000076cd267e1185  pop rsi
000076cd267e1186  pop rdi
000076cd267e1187  pop rdx
000076cd267e1188  pop rcx
000076cd267e1189  pop rax
000076cd267e118a  add rsp, 0x08
000076cd267e118e  jmp 0x000076CD267DC74D
000076cd267e1193  call 0x000076CD2660C260
000076cd267e1198  jmp 0x000076CD267DC75B
000076cd267e119d  call 0x000076CD266BD750
000076cd267e11a2  jmp 0x000076CD267DC765
000076cd267e11a7  sub rsp, 0x08
000076cd267e11ab  push rax
000076cd267e11ac  push rcx
000076cd267e11ad  push rdx
000076cd267e11ae  push rdi
000076cd267e11af  push rsi
000076cd267e11b0  push r8
000076cd267e11b2  push r9
000076cd267e11b4  push r10
000076cd267e11b6  push r11
000076cd267e11b8  sub rsp, 0xF0
000076cd267e11bf  vmovaps [rsp], xmm0
000076cd267e11c4  vmovaps [rsp+0x10], xmm1
000076cd267e11ca  vmovaps [rsp+0x20], xmm2
000076cd267e11d0  vmovaps [rsp+0x30], xmm3
000076cd267e11d6  vmovaps [rsp+0x40], xmm4
000076cd267e11dc  vmovaps [rsp+0x50], xmm5
000076cd267e11e2  vmovaps [rsp+0x60], xmm6
000076cd267e11e8  vmovaps [rsp+0x70], xmm7
000076cd267e11ee  vmovaps [rsp+0x80], xmm9
000076cd267e11f7  vmovaps [rsp+0x90], xmm10
000076cd267e1200  vmovaps [rsp+0xA0], xmm11
000076cd267e1209  vmovaps [rsp+0xB0], xmm12
000076cd267e1212  vmovaps [rsp+0xC0], xmm13
000076cd267e121b  vmovaps [rsp+0xD0], xmm14
000076cd267e1224  vmovaps [rsp+0xE0], xmm15
000076cd267e122d  sub rsp, 0x30
000076cd267e1231  movaps [rsp], xmm8
000076cd267e1236  movaps [rsp+0x10], xmm15
000076cd267e123c  movaps [rsp+0x20], xmm7
000076cd267e1241  lea rdi, [rsp]
000076cd267e1245  mov esi, 0x00
000076cd267e124a  mov rax, 0x56B8861A9530
000076cd267e1254  call rax
000076cd267e1256  movaps xmm8, [rsp]
000076cd267e125b  add rsp, 0x30
000076cd267e125f  vmovaps xmm0, [rsp]
000076cd267e1264  vmovaps xmm1, [rsp+0x10]
000076cd267e126a  vmovaps xmm2, [rsp+0x20]
000076cd267e1270  vmovaps xmm3, [rsp+0x30]
000076cd267e1276  vmovaps xmm4, [rsp+0x40]
000076cd267e127c  vmovaps xmm5, [rsp+0x50]
000076cd267e1282  vmovaps xmm6, [rsp+0x60]
000076cd267e1288  vmovaps xmm7, [rsp+0x70]
000076cd267e128e  vmovaps xmm9, [rsp+0x80]
000076cd267e1297  vmovaps xmm10, [rsp+0x90]
000076cd267e12a0  vmovaps xmm11, [rsp+0xA0]
000076cd267e12a9  vmovaps xmm12, [rsp+0xB0]
000076cd267e12b2  vmovaps xmm13, [rsp+0xC0]
000076cd267e12bb  vmovaps xmm14, [rsp+0xD0]
000076cd267e12c4  vmovaps xmm15, [rsp+0xE0]
000076cd267e12cd  add rsp, 0xF0
000076cd267e12d4  pop r11
000076cd267e12d6  pop r10
000076cd267e12d8  pop r9
000076cd267e12da  pop r8
000076cd267e12dc  pop rsi
000076cd267e12dd  pop rdi
000076cd267e12de  pop rdx
000076cd267e12df  pop rcx
000076cd267e12e0  pop rax
000076cd267e12e1  add rsp, 0x08
000076cd267e12e5  jmp 0x000076CD267DC787
000076cd267e12ea  sub rsp, 0x08
000076cd267e12ee  push rax
000076cd267e12ef  push rcx
000076cd267e12f0  push rdx
000076cd267e12f1  push rdi
000076cd267e12f2  push rsi
000076cd267e12f3  push r8
000076cd267e12f5  push r9
000076cd267e12f7  push r10
000076cd267e12f9  push r11
000076cd267e12fb  sub rsp, 0xF0
000076cd267e1302  vmovaps [rsp], xmm0
000076cd267e1307  vmovaps [rsp+0x10], xmm1
000076cd267e130d  vmovaps [rsp+0x20], xmm2
000076cd267e1313  vmovaps [rsp+0x30], xmm3
000076cd267e1319  vmovaps [rsp+0x40], xmm4
000076cd267e131f  vmovaps [rsp+0x50], xmm5
000076cd267e1325  vmovaps [rsp+0x60], xmm6
000076cd267e132b  vmovaps [rsp+0x70], xmm8
000076cd267e1331  vmovaps [rsp+0x80], xmm9
000076cd267e133a  vmovaps [rsp+0x90], xmm10
000076cd267e1343  vmovaps [rsp+0xA0], xmm11
000076cd267e134c  vmovaps [rsp+0xB0], xmm12
000076cd267e1355  vmovaps [rsp+0xC0], xmm13
000076cd267e135e  vmovaps [rsp+0xD0], xmm14
000076cd267e1367  vmovaps [rsp+0xE0], xmm15
000076cd267e1370  sub rsp, 0x30
000076cd267e1374  movaps [rsp], xmm7
000076cd267e1378  movaps [rsp+0x10], xmm9
000076cd267e137e  movaps [rsp+0x20], xmm15
000076cd267e1384  lea rdi, [rsp]
000076cd267e1388  mov esi, 0x00
000076cd267e138d  mov rax, 0x56B8861A9530
000076cd267e1397  call rax
000076cd267e1399  movaps xmm7, [rsp]
000076cd267e139d  add rsp, 0x30
000076cd267e13a1  vmovaps xmm0, [rsp]
000076cd267e13a6  vmovaps xmm1, [rsp+0x10]
000076cd267e13ac  vmovaps xmm2, [rsp+0x20]
000076cd267e13b2  vmovaps xmm3, [rsp+0x30]
000076cd267e13b8  vmovaps xmm4, [rsp+0x40]
000076cd267e13be  vmovaps xmm5, [rsp+0x50]
000076cd267e13c4  vmovaps xmm6, [rsp+0x60]
000076cd267e13ca  vmovaps xmm8, [rsp+0x70]
000076cd267e13d0  vmovaps xmm9, [rsp+0x80]
000076cd267e13d9  vmovaps xmm10, [rsp+0x90]
000076cd267e13e2  vmovaps xmm11, [rsp+0xA0]
000076cd267e13eb  vmovaps xmm12, [rsp+0xB0]
000076cd267e13f4  vmovaps xmm13, [rsp+0xC0]
000076cd267e13fd  vmovaps xmm14, [rsp+0xD0]
000076cd267e1406  vmovaps xmm15, [rsp+0xE0]
000076cd267e140f  add rsp, 0xF0
000076cd267e1416  pop r11
000076cd267e1418  pop r10
000076cd267e141a  pop r9
000076cd267e141c  pop r8
000076cd267e141e  pop rsi
000076cd267e141f  pop rdi
000076cd267e1420  pop rdx
000076cd267e1421  pop rcx
000076cd267e1422  pop rax
000076cd267e1423  add rsp, 0x08
000076cd267e1427  jmp 0x000076CD267DC7B4
000076cd267e142c  sub rsp, 0x08
000076cd267e1430  push rax
000076cd267e1431  push rcx
000076cd267e1432  push rdx
000076cd267e1433  push rdi
000076cd267e1434  push rsi
000076cd267e1435  push r8
000076cd267e1437  push r9
000076cd267e1439  push r10
000076cd267e143b  push r11
000076cd267e143d  sub rsp, 0xF0
000076cd267e1444  vmovaps [rsp], xmm0
000076cd267e1449  vmovaps [rsp+0x10], xmm1
000076cd267e144f  vmovaps [rsp+0x20], xmm2
000076cd267e1455  vmovaps [rsp+0x30], xmm3
000076cd267e145b  vmovaps [rsp+0x40], xmm4
000076cd267e1461  vmovaps [rsp+0x50], xmm5
000076cd267e1467  vmovaps [rsp+0x60], xmm6
000076cd267e146d  vmovaps [rsp+0x70], xmm7
000076cd267e1473  vmovaps [rsp+0x80], xmm8
000076cd267e147c  vmovaps [rsp+0x90], xmm10
000076cd267e1485  vmovaps [rsp+0xA0], xmm11
000076cd267e148e  vmovaps [rsp+0xB0], xmm12
000076cd267e1497  vmovaps [rsp+0xC0], xmm13
000076cd267e14a0  vmovaps [rsp+0xD0], xmm14
000076cd267e14a9  vmovaps [rsp+0xE0], xmm15
000076cd267e14b2  sub rsp, 0x30
000076cd267e14b6  movaps [rsp], xmm9
000076cd267e14bb  movaps [rsp+0x10], xmm13
000076cd267e14c1  movaps [rsp+0x20], xmm15
000076cd267e14c7  lea rdi, [rsp]
000076cd267e14cb  mov esi, 0x00
000076cd267e14d0  mov rax, 0x56B8861A9530
000076cd267e14da  call rax
000076cd267e14dc  movaps xmm9, [rsp]
000076cd267e14e1  add rsp, 0x30
000076cd267e14e5  vmovaps xmm0, [rsp]
000076cd267e14ea  vmovaps xmm1, [rsp+0x10]
000076cd267e14f0  vmovaps xmm2, [rsp+0x20]
000076cd267e14f6  vmovaps xmm3, [rsp+0x30]
000076cd267e14fc  vmovaps xmm4, [rsp+0x40]
000076cd267e1502  vmovaps xmm5, [rsp+0x50]
000076cd267e1508  vmovaps xmm6, [rsp+0x60]
000076cd267e150e  vmovaps xmm7, [rsp+0x70]
000076cd267e1514  vmovaps xmm8, [rsp+0x80]
000076cd267e151d  vmovaps xmm10, [rsp+0x90]
000076cd267e1526  vmovaps xmm11, [rsp+0xA0]
000076cd267e152f  vmovaps xmm12, [rsp+0xB0]
000076cd267e1538  vmovaps xmm13, [rsp+0xC0]
000076cd267e1541  vmovaps xmm14, [rsp+0xD0]
000076cd267e154a  vmovaps xmm15, [rsp+0xE0]
000076cd267e1553  add rsp, 0xF0
000076cd267e155a  pop r11
000076cd267e155c  pop r10
000076cd267e155e  pop r9
000076cd267e1560  pop r8
000076cd267e1562  pop rsi
000076cd267e1563  pop rdi
000076cd267e1564  pop rdx
000076cd267e1565  pop rcx
000076cd267e1566  pop rax
000076cd267e1567  add rsp, 0x08
000076cd267e156b  jmp 0x000076CD267DC7E2
000076cd267e1570  sub rsp, 0x08
000076cd267e1574  push rax
000076cd267e1575  push rcx
000076cd267e1576  push rdx
000076cd267e1577  push rdi
000076cd267e1578  push rsi
000076cd267e1579  push r8
000076cd267e157b  push r9
000076cd267e157d  push r10
000076cd267e157f  push r11
000076cd267e1581  sub rsp, 0xF0
000076cd267e1588  vmovaps [rsp], xmm0
000076cd267e158d  vmovaps [rsp+0x10], xmm1
000076cd267e1593  vmovaps [rsp+0x20], xmm2
000076cd267e1599  vmovaps [rsp+0x30], xmm3
000076cd267e159f  vmovaps [rsp+0x40], xmm4
000076cd267e15a5  vmovaps [rsp+0x50], xmm5
000076cd267e15ab  vmovaps [rsp+0x60], xmm6
000076cd267e15b1  vmovaps [rsp+0x70], xmm7
000076cd267e15b7  vmovaps [rsp+0x80], xmm8
000076cd267e15c0  vmovaps [rsp+0x90], xmm9
000076cd267e15c9  vmovaps [rsp+0xA0], xmm10
000076cd267e15d2  vmovaps [rsp+0xB0], xmm11
000076cd267e15db  vmovaps [rsp+0xC0], xmm12
000076cd267e15e4  vmovaps [rsp+0xD0], xmm13
000076cd267e15ed  vmovaps [rsp+0xE0], xmm14
000076cd267e15f6  sub rsp, 0x30
000076cd267e15fa  movaps [rsp], xmm15
000076cd267e15ff  movaps [rsp+0x10], xmm11
000076cd267e1605  movaps [rsp+0x20], xmm12
000076cd267e160b  lea rdi, [rsp]
000076cd267e160f  mov esi, 0x00
000076cd267e1614  mov rax, 0x56B8861A9530
000076cd267e161e  call rax
000076cd267e1620  movaps xmm15, [rsp]
000076cd267e1625  add rsp, 0x30
000076cd267e1629  vmovaps xmm0, [rsp]
000076cd267e162e  vmovaps xmm1, [rsp+0x10]
000076cd267e1634  vmovaps xmm2, [rsp+0x20]
000076cd267e163a  vmovaps xmm3, [rsp+0x30]
000076cd267e1640  vmovaps xmm4, [rsp+0x40]
000076cd267e1646  vmovaps xmm5, [rsp+0x50]
000076cd267e164c  vmovaps xmm6, [rsp+0x60]
000076cd267e1652  vmovaps xmm7, [rsp+0x70]
000076cd267e1658  vmovaps xmm8, [rsp+0x80]
000076cd267e1661  vmovaps xmm9, [rsp+0x90]
000076cd267e166a  vmovaps xmm10, [rsp+0xA0]
000076cd267e1673  vmovaps xmm11, [rsp+0xB0]
000076cd267e167c  vmovaps xmm12, [rsp+0xC0]
000076cd267e1685  vmovaps xmm13, [rsp+0xD0]
000076cd267e168e  vmovaps xmm14, [rsp+0xE0]
000076cd267e1697  add rsp, 0xF0
000076cd267e169e  pop r11
000076cd267e16a0  pop r10
000076cd267e16a2  pop r9
000076cd267e16a4  pop r8
000076cd267e16a6  pop rsi
000076cd267e16a7  pop rdi
000076cd267e16a8  pop rdx
000076cd267e16a9  pop rcx
000076cd267e16aa  pop rax
000076cd267e16ab  add rsp, 0x08
000076cd267e16af  jmp 0x000076CD267DC7FD
000076cd267e16b4  sub rsp, 0x08
000076cd267e16b8  push rax
000076cd267e16b9  push rcx
000076cd267e16ba  push rdx
000076cd267e16bb  push rdi
000076cd267e16bc  push rsi
000076cd267e16bd  push r8
000076cd267e16bf  push r9
000076cd267e16c1  push r10
000076cd267e16c3  push r11
000076cd267e16c5  sub rsp, 0xF0
000076cd267e16cc  vmovaps [rsp], xmm0
000076cd267e16d1  vmovaps [rsp+0x10], xmm1
000076cd267e16d7  vmovaps [rsp+0x20], xmm2
000076cd267e16dd  vmovaps [rsp+0x30], xmm3
000076cd267e16e3  vmovaps [rsp+0x40], xmm4
000076cd267e16e9  vmovaps [rsp+0x50], xmm5
000076cd267e16ef  vmovaps [rsp+0x60], xmm6
000076cd267e16f5  vmovaps [rsp+0x70], xmm7
000076cd267e16fb  vmovaps [rsp+0x80], xmm8
000076cd267e1704  vmovaps [rsp+0x90], xmm9
000076cd267e170d  vmovaps [rsp+0xA0], xmm10
000076cd267e1716  vmovaps [rsp+0xB0], xmm11
000076cd267e171f  vmovaps [rsp+0xC0], xmm12
000076cd267e1728  vmovaps [rsp+0xD0], xmm14
000076cd267e1731  vmovaps [rsp+0xE0], xmm15
000076cd267e173a  sub rsp, 0x30
000076cd267e173e  movaps [rsp], xmm13
000076cd267e1743  movaps [rsp+0x10], xmm10
000076cd267e1749  movaps [rsp+0x20], xmm14
000076cd267e174f  lea rdi, [rsp]
000076cd267e1753  mov esi, 0x00
000076cd267e1758  mov rax, 0x56B8861A9530
000076cd267e1762  call rax
000076cd267e1764  movaps xmm13, [rsp]
000076cd267e1769  add rsp, 0x30
000076cd267e176d  vmovaps xmm0, [rsp]
000076cd267e1772  vmovaps xmm1, [rsp+0x10]
000076cd267e1778  vmovaps xmm2, [rsp+0x20]
000076cd267e177e  vmovaps xmm3, [rsp+0x30]
000076cd267e1784  vmovaps xmm4, [rsp+0x40]
000076cd267e178a  vmovaps xmm5, [rsp+0x50]
000076cd267e1790  vmovaps xmm6, [rsp+0x60]
000076cd267e1796  vmovaps xmm7, [rsp+0x70]
000076cd267e179c  vmovaps xmm8, [rsp+0x80]
000076cd267e17a5  vmovaps xmm9, [rsp+0x90]
000076cd267e17ae  vmovaps xmm10, [rsp+0xA0]
000076cd267e17b7  vmovaps xmm11, [rsp+0xB0]
000076cd267e17c0  vmovaps xmm12, [rsp+0xC0]
000076cd267e17c9  vmovaps xmm14, [rsp+0xD0]
000076cd267e17d2  vmovaps xmm15, [rsp+0xE0]
000076cd267e17db  add rsp, 0xF0
000076cd267e17e2  pop r11
000076cd267e17e4  pop r10
000076cd267e17e6  pop r9
000076cd267e17e8  pop r8
000076cd267e17ea  pop rsi
000076cd267e17eb  pop rdi
000076cd267e17ec  pop rdx
000076cd267e17ed  pop rcx
000076cd267e17ee  pop rax
000076cd267e17ef  add rsp, 0x08
000076cd267e17f3  jmp 0x000076CD267DC820
000076cd267e17f8  sub rsp, 0x08
000076cd267e17fc  push rax
000076cd267e17fd  push rcx
000076cd267e17fe  push rdx
000076cd267e17ff  push rdi
000076cd267e1800  push rsi
000076cd267e1801  push r8
000076cd267e1803  push r9
000076cd267e1805  push r10
000076cd267e1807  push r11
000076cd267e1809  sub rsp, 0xF0
000076cd267e1810  vmovaps [rsp], xmm0
000076cd267e1815  vmovaps [rsp+0x10], xmm1
000076cd267e181b  vmovaps [rsp+0x20], xmm2
000076cd267e1821  vmovaps [rsp+0x30], xmm3
000076cd267e1827  vmovaps [rsp+0x40], xmm4
000076cd267e182d  vmovaps [rsp+0x50], xmm5
000076cd267e1833  vmovaps [rsp+0x60], xmm6
000076cd267e1839  vmovaps [rsp+0x70], xmm7
000076cd267e183f  vmovaps [rsp+0x80], xmm8
000076cd267e1848  vmovaps [rsp+0x90], xmm9
000076cd267e1851  vmovaps [rsp+0xA0], xmm10
000076cd267e185a  vmovaps [rsp+0xB0], xmm11
000076cd267e1863  vmovaps [rsp+0xC0], xmm12
000076cd267e186c  vmovaps [rsp+0xD0], xmm13
000076cd267e1875  vmovaps [rsp+0xE0], xmm15
000076cd267e187e  sub rsp, 0x30
000076cd267e1882  movaps [rsp], xmm14
000076cd267e1887  movaps [rsp+0x10], xmm1
000076cd267e188c  movaps [rsp+0x20], xmm7
000076cd267e1891  lea rdi, [rsp]
000076cd267e1895  mov esi, 0x00
000076cd267e189a  mov rax, 0x56B8861A9530
000076cd267e18a4  call rax
000076cd267e18a6  movaps xmm14, [rsp]
000076cd267e18ab  add rsp, 0x30
000076cd267e18af  vmovaps xmm0, [rsp]
000076cd267e18b4  vmovaps xmm1, [rsp+0x10]
000076cd267e18ba  vmovaps xmm2, [rsp+0x20]
000076cd267e18c0  vmovaps xmm3, [rsp+0x30]
000076cd267e18c6  vmovaps xmm4, [rsp+0x40]
000076cd267e18cc  vmovaps xmm5, [rsp+0x50]
000076cd267e18d2  vmovaps xmm6, [rsp+0x60]
000076cd267e18d8  vmovaps xmm7, [rsp+0x70]
000076cd267e18de  vmovaps xmm8, [rsp+0x80]
000076cd267e18e7  vmovaps xmm9, [rsp+0x90]
000076cd267e18f0  vmovaps xmm10, [rsp+0xA0]
000076cd267e18f9  vmovaps xmm11, [rsp+0xB0]
000076cd267e1902  vmovaps xmm12, [rsp+0xC0]
000076cd267e190b  vmovaps xmm13, [rsp+0xD0]
000076cd267e1914  vmovaps xmm15, [rsp+0xE0]
000076cd267e191d  add rsp, 0xF0
000076cd267e1924  pop r11
000076cd267e1926  pop r10
000076cd267e1928  pop r9
000076cd267e192a  pop r8
000076cd267e192c  pop rsi
000076cd267e192d  pop rdi
000076cd267e192e  pop rdx
000076cd267e192f  pop rcx
000076cd267e1930  pop rax
000076cd267e1931  add rsp, 0x08
000076cd267e1935  jmp 0x000076CD267DC843
000076cd267e193a  sub rsp, 0x08
000076cd267e193e  push rax
000076cd267e193f  push rcx
000076cd267e1940  push rdx
000076cd267e1941  push rdi
000076cd267e1942  push rsi
000076cd267e1943  push r8
000076cd267e1945  push r9
000076cd267e1947  push r10
000076cd267e1949  push r11
000076cd267e194b  sub rsp, 0xF0
000076cd267e1952  vmovaps [rsp], xmm0
000076cd267e1957  vmovaps [rsp+0x10], xmm2
000076cd267e195d  vmovaps [rsp+0x20], xmm3
000076cd267e1963  vmovaps [rsp+0x30], xmm4
000076cd267e1969  vmovaps [rsp+0x40], xmm5
000076cd267e196f  vmovaps [rsp+0x50], xmm6
000076cd267e1975  vmovaps [rsp+0x60], xmm7
000076cd267e197b  vmovaps [rsp+0x70], xmm8
000076cd267e1981  vmovaps [rsp+0x80], xmm9
000076cd267e198a  vmovaps [rsp+0x90], xmm10
000076cd267e1993  vmovaps [rsp+0xA0], xmm11
000076cd267e199c  vmovaps [rsp+0xB0], xmm12
000076cd267e19a5  vmovaps [rsp+0xC0], xmm13
000076cd267e19ae  vmovaps [rsp+0xD0], xmm14
000076cd267e19b7  vmovaps [rsp+0xE0], xmm15
000076cd267e19c0  sub rsp, 0x30
000076cd267e19c4  movaps [rsp], xmm1
000076cd267e19c8  movaps [rsp+0x10], xmm8
000076cd267e19ce  movaps [rsp+0x20], xmm9
000076cd267e19d4  lea rdi, [rsp]
000076cd267e19d8  mov esi, 0x00
000076cd267e19dd  mov rax, 0x56B8861A9530
000076cd267e19e7  call rax
000076cd267e19e9  movaps xmm1, [rsp]
000076cd267e19ed  add rsp, 0x30
000076cd267e19f1  vmovaps xmm0, [rsp]
000076cd267e19f6  vmovaps xmm2, [rsp+0x10]
000076cd267e19fc  vmovaps xmm3, [rsp+0x20]
000076cd267e1a02  vmovaps xmm4, [rsp+0x30]
000076cd267e1a08  vmovaps xmm5, [rsp+0x40]
000076cd267e1a0e  vmovaps xmm6, [rsp+0x50]
000076cd267e1a14  vmovaps xmm7, [rsp+0x60]
000076cd267e1a1a  vmovaps xmm8, [rsp+0x70]
000076cd267e1a20  vmovaps xmm9, [rsp+0x80]
000076cd267e1a29  vmovaps xmm10, [rsp+0x90]
000076cd267e1a32  vmovaps xmm11, [rsp+0xA0]
000076cd267e1a3b  vmovaps xmm12, [rsp+0xB0]
000076cd267e1a44  vmovaps xmm13, [rsp+0xC0]
000076cd267e1a4d  vmovaps xmm14, [rsp+0xD0]
000076cd267e1a56  vmovaps xmm15, [rsp+0xE0]
000076cd267e1a5f  add rsp, 0xF0
000076cd267e1a66  pop r11
000076cd267e1a68  pop r10
000076cd267e1a6a  pop r9
000076cd267e1a6c  pop r8
000076cd267e1a6e  pop rsi
000076cd267e1a6f  pop rdi
000076cd267e1a70  pop rdx
000076cd267e1a71  pop rcx
000076cd267e1a72  pop rax
000076cd267e1a73  add rsp, 0x08
000076cd267e1a77  jmp 0x000076CD267DC865
000076cd267e1a7c  call 0x000076CD266E5940
000076cd267e1a81  jmp 0x000076CD267DC873
000076cd267e1a86  call 0x000076CD2660C380
000076cd267e1a8b  jmp 0x000076CD267DC87D
000076cd267e1a90  call 0x000076CD2660D600
000076cd267e1a95  jmp 0x000076CD267DC887
000076cd267e1a9a  call 0x000076CD265FF540
000076cd267e1a9f  jmp 0x000076CD267DC891
000076cd267e1aa4  int3
000076cd267e1aa5  nop [rax+rax*1], ax
000076cd267e1aae  nop
000076cd267e1ab0  mov rax, [r15+0xF8]
000076cd267e1ab7  lea r14, [rax+0x140]
000076cd267e1abe  mov r12, [r13+r14*1]
000076cd267e1ac3  mov [r15+0xE8], r12
000076cd267e1aca  lea r14, [rax+0x130]
000076cd267e1ad1  mov r12, [r13+r14*1]
000076cd267e1ad6  lea r14, [rax+0x138]
000076cd267e1add  mov r11, [r13+r14*1]
000076cd267e1ae2  movq xmm1, r12
000076cd267e1ae7  movq xmm15, r11
000076cd267e1aec  movq xmm1, xmm1
000076cd267e1af0  movq xmm1, xmm1
000076cd267e1af4  movaps [r15+0x1A0], xmm1
000076cd267e1afc  movq xmm15, xmm15
000076cd267e1b01  movq xmm15, xmm15
000076cd267e1b06  movaps [r15+0x190], xmm15
000076cd267e1b0e  lea r14, [rax+0x120]
000076cd267e1b15  mov r12, [r13+r14*1]
000076cd267e1b1a  lea r14, [rax+0x128]
000076cd267e1b21  mov r11, [r13+r14*1]
000076cd267e1b26  movq xmm1, r12
000076cd267e1b2b  movq xmm15, r11
000076cd267e1b30  movq xmm1, xmm1
000076cd267e1b34  movq xmm1, xmm1
000076cd267e1b38  movaps [r15+0x1C0], xmm1
000076cd267e1b40  movq xmm15, xmm15
000076cd267e1b45  movq xmm15, xmm15
000076cd267e1b4a  movaps [r15+0x1B0], xmm15
000076cd267e1b52  lea r14, [rax+0x110]
000076cd267e1b59  mov r12, [r13+r14*1]
000076cd267e1b5e  lea r14, [rax+0x118]
000076cd267e1b65  mov r11, [r13+r14*1]
000076cd267e1b6a  movq xmm1, r12
000076cd267e1b6f  movq xmm15, r11
000076cd267e1b74  movq xmm1, xmm1
000076cd267e1b78  movq xmm1, xmm1
000076cd267e1b7c  movaps [r15+0x1E0], xmm1
000076cd267e1b84  movq xmm15, xmm15
000076cd267e1b89  movq xmm15, xmm15
000076cd267e1b8e  movaps [r15+0x1D0], xmm15
000076cd267e1b96  lea r14, [rax+0x100]
000076cd267e1b9d  mov r12, [r13+r14*1]
000076cd267e1ba2  lea r14, [rax+0x108]
000076cd267e1ba9  mov r11, [r13+r14*1]
000076cd267e1bae  movq xmm1, r12
000076cd267e1bb3  movq xmm15, r11
000076cd267e1bb8  movq xmm1, xmm1
000076cd267e1bbc  movq xmm1, xmm1
000076cd267e1bc0  movaps [r15+0x200], xmm1
000076cd267e1bc8  movq xmm15, xmm15
000076cd267e1bcd  movq xmm15, xmm15
000076cd267e1bd2  movaps [r15+0x1F0], xmm15
000076cd267e1bda  mov qword ptr [r15+0x40], 0x430000
000076cd267e1be2  mov r14d, 0x430510
000076cd267e1be8  mov r12, [r13+r14*1]
000076cd267e1bed  movq xmm1, r12
000076cd267e1bf2  lea r14, [rax+0x150]
000076cd267e1bf9  mov [r15+0xF8], r14
000076cd267e1c00  mov rax, [r15+0x50]
000076cd267e1c04  movups xmm15, [r13+rax*1]
000076cd267e1c0a  movaps [r15+0x120], xmm15
000076cd267e1c12  mov qword ptr [r15+0x48], 0x10
000076cd267e1c1a  xor eax, eax
000076cd267e1c1c  mov r14d, 0x10
000076cd267e1c22  mov r12d, 0x200
000076cd267e1c28  cmp r14, r12
000076cd267e1c2b  cmc
000076cd267e1c2c  lahf
000076cd267e1c2d  seto al
000076cd267e1c30  mov [r15+0x108], eax
000076cd267e1c37  pextrq rax, xmm15, 0x01
000076cd267e1c3e  movq xmm14, rax
000076cd267e1c43  movaps [r15+0x130], xmm14
000076cd267e1c4b  movq rax, xmm1
000076cd267e1c50  movq r14, xmm15
000076cd267e1c55  vmovq xmm1, rax
000076cd267e1c5a  vmovq xmm15, r14
000076cd267e1c5f  movaps xmm13, xmm1
000076cd267e1c63  addsd xmm13, xmm15
000076cd267e1c68  ucomisd xmm13, xmm13
000076cd267e1c6d  jp 0x000076CD267E1D86
000076cd267e1c73  movq xmm13, xmm13
000076cd267e1c78  movq rax, xmm13
000076cd267e1c7d  movq r14, xmm14
000076cd267e1c82  vmovq xmm1, rax
000076cd267e1c87  vmovq xmm15, r14
000076cd267e1c8c  movaps xmm14, xmm1
000076cd267e1c90  addsd xmm14, xmm15
000076cd267e1c95  ucomisd xmm14, xmm14
000076cd267e1c9a  jp 0x000076CD267E1DCE
000076cd267e1ca0  movq xmm14, xmm14
000076cd267e1ca5  movaps [r15+0x110], xmm14
000076cd267e1cad  mov eax, [r15+0x108]
000076cd267e1cb4  sahf
000076cd267e1cb5  jnz 0x000076CD267E1CE7
000076cd267e1cb7  cmp dword ptr [r15+0x318], 0x00
000076cd267e1cbf  jz 0x000076CD267E1FE0
000076cd267e1cc5  nop [rax+rax*1], ax
000076cd267e1cce  nop [rax+rax*1], eax
000076cd267e1cd6  mov eax, 0x410490
000076cd267e1cdb  mov [r15+0x100], rax
000076cd267e1ce2  jmp 0x000076CD265FE110
000076cd267e1ce7  cmp dword ptr [r15+0x318], 0x00
000076cd267e1cef  jz 0x000076CD267E1E20
000076cd267e1cf5  nop [rax+rax*1], ax
000076cd267e1cfe  nop [rax+rax*1], eax
000076cd267e1d06  mov eax, 0x410474
000076cd267e1d0b  mov [r15+0x100], rax
000076cd267e1d12  jmp 0x000076CD265FE110
000076cd267e1d17  int3
000076cd267e1d18  call 0x000076CD266E27E0
000076cd267e1d1d  jmp 0x000076CD267E1AC3
000076cd267e1d22  call 0x000076CD266E27E0
000076cd267e1d27  jmp 0x000076CD267E1AD6
000076cd267e1d2c  call 0x000076CD266E1570
000076cd267e1d31  jmp 0x000076CD267E1AE2
000076cd267e1d36  call 0x000076CD266E27E0
000076cd267e1d3b  jmp 0x000076CD267E1B1A
000076cd267e1d40  call 0x000076CD266E1570
000076cd267e1d45  jmp 0x000076CD267E1B26
000076cd267e1d4a  call 0x000076CD266E27E0
000076cd267e1d4f  jmp 0x000076CD267E1B5E
000076cd267e1d54  call 0x000076CD266E1570
000076cd267e1d59  jmp 0x000076CD267E1B6A
000076cd267e1d5e  call 0x000076CD266E27E0
000076cd267e1d63  jmp 0x000076CD267E1BA2
000076cd267e1d68  call 0x000076CD266E1570
000076cd267e1d6d  jmp 0x000076CD267E1BAE
000076cd267e1d72  call 0x000076CD266E27E0
000076cd267e1d77  jmp 0x000076CD267E1BED
000076cd267e1d7c  call 0x000076CD2660E760
000076cd267e1d81  jmp 0x000076CD267E1C0A
000076cd267e1d86  ucomisd xmm1, xmm15
000076cd267e1d8b  jp 0x000076CD267E1D9A
000076cd267e1d8d  movaps xmm13, [0x000076CD263FE060]
000076cd267e1d95  jmp 0x000076CD267E1C73
000076cd267e1d9a  vxorps xmm0, xmm1, xmm15
000076cd267e1d9f  pextrw eax, xmm0, 0x03
000076cd267e1da4  and eax, 0x7FF8
000076cd267e1da9  cmp eax, 0x08
000076cd267e1dac  jnz 0x000076CD267E1C73
000076cd267e1db2  movq rax, xmm15
000076cd267e1db7  shl rax, 0x0D
000076cd267e1dbb  jbe 0x000076CD267E1C73
000076cd267e1dc1  vorps xmm13, xmm15, [0x000076CD263FE070]
000076cd267e1dc9  jmp 0x000076CD267E1C73
000076cd267e1dce  ucomisd xmm1, xmm15
000076cd267e1dd3  jp 0x000076CD267E1DE2
000076cd267e1dd5  movaps xmm14, [0x000076CD263FE060]
000076cd267e1ddd  jmp 0x000076CD267E1CA0
000076cd267e1de2  vxorps xmm0, xmm1, xmm15
000076cd267e1de7  pextrw eax, xmm0, 0x03
000076cd267e1dec  and eax, 0x7FF8
000076cd267e1df1  cmp eax, 0x08
000076cd267e1df4  jnz 0x000076CD267E1CA0
000076cd267e1dfa  movq rax, xmm15
000076cd267e1dff  shl rax, 0x0D
000076cd267e1e03  jbe 0x000076CD267E1CA0
000076cd267e1e09  vorps xmm14, xmm15, [0x000076CD263FE070]
000076cd267e1e11  jmp 0x000076CD267E1CA0
000076cd267e1e16  int3
000076cd267e1e17  nop [rax+rax*1], ax
000076cd267e1e20  mov rax, [r15+0x48]
000076cd267e1e24  mov r14, [r15+0x50]
000076cd267e1e28  lea r12, [r14+rax*1]
000076cd267e1e2c  movups xmm1, [r13+r12*1]
000076cd267e1e32  movaps [r15+0x120], xmm1
000076cd267e1e3a  lea r14, [rax+0x10]
000076cd267e1e3e  mov [r15+0x48], r14
000076cd267e1e42  xor eax, eax
000076cd267e1e44  mov r12d, 0x200
000076cd267e1e4a  cmp r14, r12
000076cd267e1e4d  cmc
000076cd267e1e4e  lahf
000076cd267e1e4f  seto al
000076cd267e1e52  mov [r15+0x108], eax
000076cd267e1e59  pextrq rax, xmm1, 0x01
000076cd267e1e60  movq xmm15, rax
000076cd267e1e65  movaps [r15+0x130], xmm15
000076cd267e1e6d  movaps xmm14, [r15+0x110]
000076cd267e1e75  movq rax, xmm14
000076cd267e1e7a  movq r14, xmm1
000076cd267e1e7f  vmovq xmm1, rax
000076cd267e1e84  vmovq xmm14, r14
000076cd267e1e89  movaps xmm13, xmm1
000076cd267e1e8d  addsd xmm13, xmm14
000076cd267e1e92  ucomisd xmm13, xmm13
000076cd267e1e97  jp 0x000076CD267E1F4C
000076cd267e1e9d  movq xmm13, xmm13
000076cd267e1ea2  movq rax, xmm13
000076cd267e1ea7  movq r14, xmm15
000076cd267e1eac  vmovq xmm1, rax
000076cd267e1eb1  vmovq xmm15, r14
000076cd267e1eb6  movaps xmm14, xmm1
000076cd267e1eba  addsd xmm14, xmm15
000076cd267e1ebf  ucomisd xmm14, xmm14
000076cd267e1ec4  jp 0x000076CD267E1F94
000076cd267e1eca  movq xmm14, xmm14
000076cd267e1ecf  movaps [r15+0x110], xmm14
000076cd267e1ed7  mov eax, [r15+0x108]
000076cd267e1ede  sahf
000076cd267e1edf  jnz 0x000076CD267E1F11
000076cd267e1ee1  cmp dword ptr [r15+0x318], 0x00
000076cd267e1ee9  jz 0x000076CD267E1FE0
000076cd267e1eef  nop [rax+rax*1], ax
000076cd267e1ef8  nop [rax+rax*1], eax
000076cd267e1f00  mov eax, 0x410490
000076cd267e1f05  mov [r15+0x100], rax
000076cd267e1f0c  jmp 0x000076CD265FE110
000076cd267e1f11  cmp dword ptr [r15+0x318], 0x00
000076cd267e1f19  jz 0x000076CD267E1E20
000076cd267e1f1f  nop [rax+rax*1], ax
000076cd267e1f28  nop [rax+rax*1], eax
000076cd267e1f30  mov eax, 0x410474
000076cd267e1f35  mov [r15+0x100], rax
000076cd267e1f3c  jmp 0x000076CD265FE110
000076cd267e1f41  int3
000076cd267e1f42  call 0x000076CD266B52F0
000076cd267e1f47  jmp 0x000076CD267E1E32
000076cd267e1f4c  ucomisd xmm1, xmm14
000076cd267e1f51  jp 0x000076CD267E1F60
000076cd267e1f53  movaps xmm13, [0x000076CD263FE060]
000076cd267e1f5b  jmp 0x000076CD267E1E9D
000076cd267e1f60  vxorps xmm0, xmm1, xmm14
000076cd267e1f65  pextrw eax, xmm0, 0x03
000076cd267e1f6a  and eax, 0x7FF8
000076cd267e1f6f  cmp eax, 0x08
000076cd267e1f72  jnz 0x000076CD267E1E9D
000076cd267e1f78  movq rax, xmm14
000076cd267e1f7d  shl rax, 0x0D
000076cd267e1f81  jbe 0x000076CD267E1E9D
000076cd267e1f87  vorps xmm13, xmm14, [0x000076CD263FE070]
000076cd267e1f8f  jmp 0x000076CD267E1E9D
000076cd267e1f94  ucomisd xmm1, xmm15
000076cd267e1f99  jp 0x000076CD267E1FA8
000076cd267e1f9b  movaps xmm14, [0x000076CD263FE060]
000076cd267e1fa3  jmp 0x000076CD267E1ECA
000076cd267e1fa8  vxorps xmm0, xmm1, xmm15
000076cd267e1fad  pextrw eax, xmm0, 0x03
000076cd267e1fb2  and eax, 0x7FF8
000076cd267e1fb7  cmp eax, 0x08
000076cd267e1fba  jnz 0x000076CD267E1ECA
000076cd267e1fc0  movq rax, xmm15
000076cd267e1fc5  shl rax, 0x0D
000076cd267e1fc9  jbe 0x000076CD267E1ECA
000076cd267e1fcf  vorps xmm14, xmm15, [0x000076CD263FE070]
000076cd267e1fd7  jmp 0x000076CD267E1ECA
000076cd267e1fdc  int3
000076cd267e1fdd  nop [rax], eax
000076cd267e1fe0  mov rax, [r15+0x40]
000076cd267e1fe4  lea r14, [rax+0x510]
000076cd267e1feb  movaps xmm1, [r15+0x110]
000076cd267e1ff3  movq rax, xmm1
000076cd267e1ff8  mov [r13+r14*1], rax
000076cd267e1ffd  mov rax, [r15+0xF0]
000076cd267e2004  mov [r15+0x100], rax
000076cd267e200b  jmp 0x000076CD267CE5C0
000076cd267e2010  int3
000076cd267e2011  call 0x000076CD266D5EB0
000076cd267e2016  jmp 0x000076CD267E1FFD
000076cd267e201b  int3
000076cd267e201c  nop [rax], eax
000076cd267e2020  mov qword ptr [r15+0x100], 0x04
000076cd267e202b  mov esi, 0x00
000076cd267e2030  mov edx, 0x09
000076cd267e2035  mov rdi, 0x7FFE8401DE60
000076cd267e203f  mov rax, 0x56B88603C970
000076cd267e2049  call rax
000076cd267e204b  cmp dword ptr [r15+0x318], 0x00
000076cd267e2053  jnz 0x000076CD265FE110
000076cd267e2059  jmp 0x000076CD265FE0A0
000076cd267e205e  int3
000076cd267e205f  int3
