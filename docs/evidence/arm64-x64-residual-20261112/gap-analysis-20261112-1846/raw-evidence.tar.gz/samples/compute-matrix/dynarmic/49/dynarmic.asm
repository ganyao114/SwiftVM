000076e4393ce69b  nop [rax+rax*1], eax
000076e4393ce6a0  vmovaps xmm1, [0x000076E438FFE010]
000076e4393ce6a8  movq xmm1, xmm1
000076e4393ce6ac  movaps [r15+0x110], xmm1
000076e4393ce6b4  vmovaps xmm1, [0x000076E438FFE020]
000076e4393ce6bc  movq xmm1, xmm1
000076e4393ce6c0  movaps [r15+0x120], xmm1
000076e4393ce6c8  mov eax, 0x4204C0
000076e4393ce6cd  mov r14, [r13+rax*1]
000076e4393ce6d2  movq xmm1, r14
000076e4393ce6d7  movaps [r15+0x130], xmm1
000076e4393ce6df  vmovaps xmm1, [0x000076E438FFE030]
000076e4393ce6e7  vpbroadcastq xmm1, xmm1
000076e4393ce6ec  movaps [r15+0x140], xmm1
000076e4393ce6f4  mov qword ptr [r15+0x40], 0x02
000076e4393ce6fc  vmovaps xmm15, [0x000076E438FFE040]
000076e4393ce704  movq xmm15, xmm15
000076e4393ce709  movaps [r15+0x150], xmm15
000076e4393ce711  mov qword ptr [r15+0x58], 0x420000
000076e4393ce719  vmovaps xmm15, [0x000076E438FFE050]
000076e4393ce721  vpbroadcastq xmm15, xmm15
000076e4393ce726  movaps [r15+0x160], xmm15
000076e4393ce72e  mov rax, [r15+0x40]
000076e4393ce732  vmovq xmm14, rax
000076e4393ce737  vpbroadcastq xmm14, xmm14
000076e4393ce73c  movaps [r15+0x170], xmm14
000076e4393ce744  mov eax, 0x4204D0
000076e4393ce749  movups xmm13, [r13+rax*1]
000076e4393ce74f  mov qword ptr [r15+0x40], 0x430518
000076e4393ce757  mov qword ptr [r15+0x50], 0x430720
000076e4393ce75f  vpmovqd xmm12, xmm13
000076e4393ce765  pxor xmm11, xmm11
000076e4393ce76a  punpcklqdq xmm12, xmm11
000076e4393ce76f  movaps [r15+0x210], xmm12
000076e4393ce777  movq xmm12, qword ptr [r15+0x120]
000076e4393ce780  movq xmm11, qword ptr [r15+0x130]
000076e4393ce789  psubd xmm12, xmm11
000076e4393ce78e  movq xmm12, xmm12
000076e4393ce793  paddq xmm13, xmm14
000076e4393ce798  movaps [r15+0x180], xmm13
000076e4393ce7a0  movq xmm14, qword ptr [r15+0x150]
000076e4393ce7a9  paddd xmm11, xmm14
000076e4393ce7ae  movq xmm11, xmm11
000076e4393ce7b3  movq xmm11, xmm11
000076e4393ce7b8  movaps [r15+0x130], xmm11
000076e4393ce7c0  pmovzxdq xmm12, xmm12
000076e4393ce7c6  psllq xmm12, 0x00
000076e4393ce7cc  movq xmm14, qword ptr [r15+0x210]
000076e4393ce7d5  movq xmm13, qword ptr [r15+0x110]
000076e4393ce7de  paddd xmm14, xmm13
000076e4393ce7e3  movq xmm14, xmm14
000076e4393ce7e8  vcvtuqq2pd xmm12, xmm12
000076e4393ce7ee  pmovzxdq xmm14, xmm14
000076e4393ce7f4  psllq xmm14, 0x00
000076e4393ce7fa  vcvtuqq2pd xmm14, xmm14
000076e4393ce800  movaps xmm13, xmm12
000076e4393ce804  mulpd xmm13, xmm1
000076e4393ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000076e4393ce80f  ptest xmm11, xmm11
000076e4393ce815  jnz 0x000076E4393CE8FF
000076e4393ce81b  movaps [r15+0x220], xmm13
000076e4393ce823  mov eax, 0x430720
000076e4393ce828  movups [r13+rax*1], xmm13
000076e4393ce82e  movaps xmm1, xmm14
000076e4393ce832  mulpd xmm1, xmm15
000076e4393ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000076e4393ce83c  ptest xmm13, xmm13
000076e4393ce842  jnz 0x000076E4393CEA4C
000076e4393ce848  movaps [r15+0x210], xmm1
000076e4393ce850  mov eax, 0x430518
000076e4393ce855  movups [r13+rax*1], xmm1
000076e4393ce85b  mov qword ptr [r15+0x48], 0x10
000076e4393ce863  xor eax, eax
000076e4393ce865  mov r14d, 0x10
000076e4393ce86b  mov r12d, 0x200
000076e4393ce871  cmp r14, r12
000076e4393ce874  cmc
000076e4393ce875  lahf
000076e4393ce876  seto al
000076e4393ce879  mov [r15+0x108], eax
000076e4393ce880  mov eax, [r15+0x108]
000076e4393ce887  sahf
000076e4393ce888  jnz 0x000076E4393CE8BA
000076e4393ce88a  cmp dword ptr [r15+0x318], 0x00
000076e4393ce892  jz 0x000076E4393CEFF0
000076e4393ce898  nop [rax+rax*1], ax
000076e4393ce8a1  nop [rax+rax*1], eax
000076e4393ce8a9  mov eax, 0x4101EC
000076e4393ce8ae  mov [r15+0x100], rax
000076e4393ce8b5  jmp 0x000076E4391FE110
000076e4393ce8ba  cmp dword ptr [r15+0x318], 0x00
000076e4393ce8c2  jz 0x000076E4393CEBA0
000076e4393ce8c8  nop [rax+rax*1], ax
000076e4393ce8d1  nop [rax+rax*1], eax
000076e4393ce8d9  mov eax, 0x4101AC
000076e4393ce8de  mov [r15+0x100], rax
000076e4393ce8e5  jmp 0x000076E4391FE110
000076e4393ce8ea  int3
000076e4393ce8eb  call 0x000076E43920DC20
000076e4393ce8f0  jmp 0x000076E4393CE6D2
000076e4393ce8f5  call 0x000076E43920C260
000076e4393ce8fa  jmp 0x000076E4393CE74F
000076e4393ce8ff  sub rsp, 0x08
000076e4393ce903  push rax
000076e4393ce904  push rcx
000076e4393ce905  push rdx
000076e4393ce906  push rdi
000076e4393ce907  push rsi
000076e4393ce908  push r8
000076e4393ce90a  push r9
000076e4393ce90c  push r10
000076e4393ce90e  push r11
000076e4393ce910  sub rsp, 0xF0
000076e4393ce917  vmovaps [rsp], xmm0
000076e4393ce91c  vmovaps [rsp+0x10], xmm1
000076e4393ce922  vmovaps [rsp+0x20], xmm2
000076e4393ce928  vmovaps [rsp+0x30], xmm3
000076e4393ce92e  vmovaps [rsp+0x40], xmm4
000076e4393ce934  vmovaps [rsp+0x50], xmm5
000076e4393ce93a  vmovaps [rsp+0x60], xmm6
000076e4393ce940  vmovaps [rsp+0x70], xmm7
000076e4393ce946  vmovaps [rsp+0x80], xmm8
000076e4393ce94f  vmovaps [rsp+0x90], xmm9
000076e4393ce958  vmovaps [rsp+0xA0], xmm10
000076e4393ce961  vmovaps [rsp+0xB0], xmm11
000076e4393ce96a  vmovaps [rsp+0xC0], xmm12
000076e4393ce973  vmovaps [rsp+0xD0], xmm14
000076e4393ce97c  vmovaps [rsp+0xE0], xmm15
000076e4393ce985  sub rsp, 0x30
000076e4393ce989  movaps [rsp], xmm13
000076e4393ce98e  movaps [rsp+0x10], xmm12
000076e4393ce994  movaps [rsp+0x20], xmm1
000076e4393ce999  lea rdi, [rsp]
000076e4393ce99d  mov esi, 0x00
000076e4393ce9a2  mov rax, 0x63DBDEB43530
000076e4393ce9ac  call rax
000076e4393ce9ae  movaps xmm13, [rsp]
000076e4393ce9b3  add rsp, 0x30
000076e4393ce9b7  vmovaps xmm0, [rsp]
000076e4393ce9bc  vmovaps xmm1, [rsp+0x10]
000076e4393ce9c2  vmovaps xmm2, [rsp+0x20]
000076e4393ce9c8  vmovaps xmm3, [rsp+0x30]
000076e4393ce9ce  vmovaps xmm4, [rsp+0x40]
000076e4393ce9d4  vmovaps xmm5, [rsp+0x50]
000076e4393ce9da  vmovaps xmm6, [rsp+0x60]
000076e4393ce9e0  vmovaps xmm7, [rsp+0x70]
000076e4393ce9e6  vmovaps xmm8, [rsp+0x80]
000076e4393ce9ef  vmovaps xmm9, [rsp+0x90]
000076e4393ce9f8  vmovaps xmm10, [rsp+0xA0]
000076e4393cea01  vmovaps xmm11, [rsp+0xB0]
000076e4393cea0a  vmovaps xmm12, [rsp+0xC0]
000076e4393cea13  vmovaps xmm14, [rsp+0xD0]
000076e4393cea1c  vmovaps xmm15, [rsp+0xE0]
000076e4393cea25  add rsp, 0xF0
000076e4393cea2c  pop r11
000076e4393cea2e  pop r10
000076e4393cea30  pop r9
000076e4393cea32  pop r8
000076e4393cea34  pop rsi
000076e4393cea35  pop rdi
000076e4393cea36  pop rdx
000076e4393cea37  pop rcx
000076e4393cea38  pop rax
000076e4393cea39  add rsp, 0x08
000076e4393cea3d  jmp 0x000076E4393CE81B
000076e4393cea42  call 0x000076E43920C380
000076e4393cea47  jmp 0x000076E4393CE82E
000076e4393cea4c  sub rsp, 0x08
000076e4393cea50  push rax
000076e4393cea51  push rcx
000076e4393cea52  push rdx
000076e4393cea53  push rdi
000076e4393cea54  push rsi
000076e4393cea55  push r8
000076e4393cea57  push r9
000076e4393cea59  push r10
000076e4393cea5b  push r11
000076e4393cea5d  sub rsp, 0xF0
000076e4393cea64  vmovaps [rsp], xmm0
000076e4393cea69  vmovaps [rsp+0x10], xmm2
000076e4393cea6f  vmovaps [rsp+0x20], xmm3
000076e4393cea75  vmovaps [rsp+0x30], xmm4
000076e4393cea7b  vmovaps [rsp+0x40], xmm5
000076e4393cea81  vmovaps [rsp+0x50], xmm6
000076e4393cea87  vmovaps [rsp+0x60], xmm7
000076e4393cea8d  vmovaps [rsp+0x70], xmm8
000076e4393cea93  vmovaps [rsp+0x80], xmm9
000076e4393cea9c  vmovaps [rsp+0x90], xmm10
000076e4393ceaa5  vmovaps [rsp+0xA0], xmm11
000076e4393ceaae  vmovaps [rsp+0xB0], xmm12
000076e4393ceab7  vmovaps [rsp+0xC0], xmm13
000076e4393ceac0  vmovaps [rsp+0xD0], xmm14
000076e4393ceac9  vmovaps [rsp+0xE0], xmm15
000076e4393cead2  sub rsp, 0x30
000076e4393cead6  movaps [rsp], xmm1
000076e4393ceada  movaps [rsp+0x10], xmm14
000076e4393ceae0  movaps [rsp+0x20], xmm15
000076e4393ceae6  lea rdi, [rsp]
000076e4393ceaea  mov esi, 0x00
000076e4393ceaef  mov rax, 0x63DBDEB43530
000076e4393ceaf9  call rax
000076e4393ceafb  movaps xmm1, [rsp]
000076e4393ceaff  add rsp, 0x30
000076e4393ceb03  vmovaps xmm0, [rsp]
000076e4393ceb08  vmovaps xmm2, [rsp+0x10]
000076e4393ceb0e  vmovaps xmm3, [rsp+0x20]
000076e4393ceb14  vmovaps xmm4, [rsp+0x30]
000076e4393ceb1a  vmovaps xmm5, [rsp+0x40]
000076e4393ceb20  vmovaps xmm6, [rsp+0x50]
000076e4393ceb26  vmovaps xmm7, [rsp+0x60]
000076e4393ceb2c  vmovaps xmm8, [rsp+0x70]
000076e4393ceb32  vmovaps xmm9, [rsp+0x80]
000076e4393ceb3b  vmovaps xmm10, [rsp+0x90]
000076e4393ceb44  vmovaps xmm11, [rsp+0xA0]
000076e4393ceb4d  vmovaps xmm12, [rsp+0xB0]
000076e4393ceb56  vmovaps xmm13, [rsp+0xC0]
000076e4393ceb5f  vmovaps xmm14, [rsp+0xD0]
000076e4393ceb68  vmovaps xmm15, [rsp+0xE0]
000076e4393ceb71  add rsp, 0xF0
000076e4393ceb78  pop r11
000076e4393ceb7a  pop r10
000076e4393ceb7c  pop r9
000076e4393ceb7e  pop r8
000076e4393ceb80  pop rsi
000076e4393ceb81  pop rdi
000076e4393ceb82  pop rdx
000076e4393ceb83  pop rcx
000076e4393ceb84  pop rax
000076e4393ceb85  add rsp, 0x08
000076e4393ceb89  jmp 0x000076E4393CE848
000076e4393ceb8e  call 0x000076E4391FF540
000076e4393ceb93  jmp 0x000076E4393CE85B
000076e4393ceb98  int3
000076e4393ceb99  nop [rax], eax
000076e4393ceba0  movaps xmm1, [r15+0x180]
000076e4393ceba8  vpmovqd xmm15, xmm1
000076e4393cebae  pxor xmm14, xmm14
000076e4393cebb3  punpcklqdq xmm15, xmm14
000076e4393cebb8  movaps [r15+0x210], xmm15
000076e4393cebc0  movq xmm15, qword ptr [r15+0x120]
000076e4393cebc9  movq xmm14, qword ptr [r15+0x130]
000076e4393cebd2  psubd xmm15, xmm14
000076e4393cebd7  movq xmm15, xmm15
000076e4393cebdc  movaps xmm13, [r15+0x170]
000076e4393cebe4  paddq xmm1, xmm13
000076e4393cebe9  movaps [r15+0x180], xmm1
000076e4393cebf1  movq xmm1, qword ptr [r15+0x150]
000076e4393cebfa  paddd xmm14, xmm1
000076e4393cebff  movq xmm14, xmm14
000076e4393cec04  movq xmm14, xmm14
000076e4393cec09  movaps [r15+0x130], xmm14
000076e4393cec11  pmovzxdq xmm15, xmm15
000076e4393cec17  psllq xmm15, 0x00
000076e4393cec1d  movq xmm1, qword ptr [r15+0x210]
000076e4393cec26  movq xmm14, qword ptr [r15+0x110]
000076e4393cec2f  paddd xmm1, xmm14
000076e4393cec34  movq xmm1, xmm1
000076e4393cec38  vcvtuqq2pd xmm15, xmm15
000076e4393cec3e  pmovzxdq xmm1, xmm1
000076e4393cec43  psllq xmm1, 0x00
000076e4393cec48  vcvtuqq2pd xmm1, xmm1
000076e4393cec4e  movaps xmm14, [r15+0x140]
000076e4393cec56  movaps xmm13, xmm15
000076e4393cec5a  mulpd xmm13, xmm14
000076e4393cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000076e4393cec65  ptest xmm12, xmm12
000076e4393cec6b  jnz 0x000076E4393CED4E
000076e4393cec71  movaps [r15+0x220], xmm13
000076e4393cec79  mov rax, [r15+0x48]
000076e4393cec7d  mov r14, [r15+0x50]
000076e4393cec81  lea r12, [r14+rax*1]
000076e4393cec85  movups [r13+r12*1], xmm13
000076e4393cec8b  movaps xmm15, [r15+0x160]
000076e4393cec93  movaps xmm14, xmm1
000076e4393cec97  mulpd xmm14, xmm15
000076e4393cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000076e4393ceca2  ptest xmm13, xmm13
000076e4393ceca8  jnz 0x000076E4393CEE9C
000076e4393cecae  movaps [r15+0x210], xmm14
000076e4393cecb6  mov r14, [r15+0x40]
000076e4393cecba  lea r12, [r14+rax*1]
000076e4393cecbe  movups [r13+r12*1], xmm14
000076e4393cecc4  lea r14, [rax+0x10]
000076e4393cecc8  mov [r15+0x48], r14
000076e4393ceccc  xor eax, eax
000076e4393cecce  mov r12d, 0x200
000076e4393cecd4  cmp r14, r12
000076e4393cecd7  cmc
000076e4393cecd8  lahf
000076e4393cecd9  seto al
000076e4393cecdc  mov [r15+0x108], eax
000076e4393cece3  mov eax, [r15+0x108]
000076e4393cecea  sahf
000076e4393ceceb  jnz 0x000076E4393CED1D
000076e4393ceced  cmp dword ptr [r15+0x318], 0x00
000076e4393cecf5  jz 0x000076E4393CEFF0
000076e4393cecfb  nop [rax+rax*1], ax
000076e4393ced04  nop [rax+rax*1], eax
000076e4393ced0c  mov eax, 0x4101EC
000076e4393ced11  mov [r15+0x100], rax
000076e4393ced18  jmp 0x000076E4391FE110
000076e4393ced1d  cmp dword ptr [r15+0x318], 0x00
000076e4393ced25  jz 0x000076E4393CEBA0
000076e4393ced2b  nop [rax+rax*1], ax
000076e4393ced34  nop [rax+rax*1], eax
000076e4393ced3c  mov eax, 0x4101AC
000076e4393ced41  mov [r15+0x100], rax
000076e4393ced48  jmp 0x000076E4391FE110
000076e4393ced4d  int3
000076e4393ced4e  sub rsp, 0x08
000076e4393ced52  push rax
000076e4393ced53  push rcx
000076e4393ced54  push rdx
000076e4393ced55  push rdi
000076e4393ced56  push rsi
000076e4393ced57  push r8
000076e4393ced59  push r9
000076e4393ced5b  push r10
000076e4393ced5d  push r11
000076e4393ced5f  sub rsp, 0xF0
000076e4393ced66  vmovaps [rsp], xmm0
000076e4393ced6b  vmovaps [rsp+0x10], xmm1
000076e4393ced71  vmovaps [rsp+0x20], xmm2
000076e4393ced77  vmovaps [rsp+0x30], xmm3
000076e4393ced7d  vmovaps [rsp+0x40], xmm4
000076e4393ced83  vmovaps [rsp+0x50], xmm5
000076e4393ced89  vmovaps [rsp+0x60], xmm6
000076e4393ced8f  vmovaps [rsp+0x70], xmm7
000076e4393ced95  vmovaps [rsp+0x80], xmm8
000076e4393ced9e  vmovaps [rsp+0x90], xmm9
000076e4393ceda7  vmovaps [rsp+0xA0], xmm10
000076e4393cedb0  vmovaps [rsp+0xB0], xmm11
000076e4393cedb9  vmovaps [rsp+0xC0], xmm12
000076e4393cedc2  vmovaps [rsp+0xD0], xmm14
000076e4393cedcb  vmovaps [rsp+0xE0], xmm15
000076e4393cedd4  sub rsp, 0x30
000076e4393cedd8  movaps [rsp], xmm13
000076e4393ceddd  movaps [rsp+0x10], xmm15
000076e4393cede3  movaps [rsp+0x20], xmm14
000076e4393cede9  lea rdi, [rsp]
000076e4393ceded  mov esi, 0x00
000076e4393cedf2  mov rax, 0x63DBDEB43530
000076e4393cedfc  call rax
000076e4393cedfe  movaps xmm13, [rsp]
000076e4393cee03  add rsp, 0x30
000076e4393cee07  vmovaps xmm0, [rsp]
000076e4393cee0c  vmovaps xmm1, [rsp+0x10]
000076e4393cee12  vmovaps xmm2, [rsp+0x20]
000076e4393cee18  vmovaps xmm3, [rsp+0x30]
000076e4393cee1e  vmovaps xmm4, [rsp+0x40]
000076e4393cee24  vmovaps xmm5, [rsp+0x50]
000076e4393cee2a  vmovaps xmm6, [rsp+0x60]
000076e4393cee30  vmovaps xmm7, [rsp+0x70]
000076e4393cee36  vmovaps xmm8, [rsp+0x80]
000076e4393cee3f  vmovaps xmm9, [rsp+0x90]
000076e4393cee48  vmovaps xmm10, [rsp+0xA0]
000076e4393cee51  vmovaps xmm11, [rsp+0xB0]
000076e4393cee5a  vmovaps xmm12, [rsp+0xC0]
000076e4393cee63  vmovaps xmm14, [rsp+0xD0]
000076e4393cee6c  vmovaps xmm15, [rsp+0xE0]
000076e4393cee75  add rsp, 0xF0
000076e4393cee7c  pop r11
000076e4393cee7e  pop r10
000076e4393cee80  pop r9
000076e4393cee82  pop r8
000076e4393cee84  pop rsi
000076e4393cee85  pop rdi
000076e4393cee86  pop rdx
000076e4393cee87  pop rcx
000076e4393cee88  pop rax
000076e4393cee89  add rsp, 0x08
000076e4393cee8d  jmp 0x000076E4393CEC71
000076e4393cee92  call 0x000076E4392C2240
000076e4393cee97  jmp 0x000076E4393CEC8B
000076e4393cee9c  sub rsp, 0x08
000076e4393ceea0  push rax
000076e4393ceea1  push rcx
000076e4393ceea2  push rdx
000076e4393ceea3  push rdi
000076e4393ceea4  push rsi
000076e4393ceea5  push r8
000076e4393ceea7  push r9
000076e4393ceea9  push r10
000076e4393ceeab  push r11
000076e4393ceead  sub rsp, 0xF0
000076e4393ceeb4  vmovaps [rsp], xmm0
000076e4393ceeb9  vmovaps [rsp+0x10], xmm1
000076e4393ceebf  vmovaps [rsp+0x20], xmm2
000076e4393ceec5  vmovaps [rsp+0x30], xmm3
000076e4393ceecb  vmovaps [rsp+0x40], xmm4
000076e4393ceed1  vmovaps [rsp+0x50], xmm5
000076e4393ceed7  vmovaps [rsp+0x60], xmm6
000076e4393ceedd  vmovaps [rsp+0x70], xmm7
000076e4393ceee3  vmovaps [rsp+0x80], xmm8
000076e4393ceeec  vmovaps [rsp+0x90], xmm9
000076e4393ceef5  vmovaps [rsp+0xA0], xmm10
000076e4393ceefe  vmovaps [rsp+0xB0], xmm11
000076e4393cef07  vmovaps [rsp+0xC0], xmm12
000076e4393cef10  vmovaps [rsp+0xD0], xmm13
000076e4393cef19  vmovaps [rsp+0xE0], xmm15
000076e4393cef22  sub rsp, 0x30
000076e4393cef26  movaps [rsp], xmm14
000076e4393cef2b  movaps [rsp+0x10], xmm1
000076e4393cef30  movaps [rsp+0x20], xmm15
000076e4393cef36  lea rdi, [rsp]
000076e4393cef3a  mov esi, 0x00
000076e4393cef3f  mov rax, 0x63DBDEB43530
000076e4393cef49  call rax
000076e4393cef4b  movaps xmm14, [rsp]
000076e4393cef50  add rsp, 0x30
000076e4393cef54  vmovaps xmm0, [rsp]
000076e4393cef59  vmovaps xmm1, [rsp+0x10]
000076e4393cef5f  vmovaps xmm2, [rsp+0x20]
000076e4393cef65  vmovaps xmm3, [rsp+0x30]
000076e4393cef6b  vmovaps xmm4, [rsp+0x40]
000076e4393cef71  vmovaps xmm5, [rsp+0x50]
000076e4393cef77  vmovaps xmm6, [rsp+0x60]
000076e4393cef7d  vmovaps xmm7, [rsp+0x70]
000076e4393cef83  vmovaps xmm8, [rsp+0x80]
000076e4393cef8c  vmovaps xmm9, [rsp+0x90]
000076e4393cef95  vmovaps xmm10, [rsp+0xA0]
000076e4393cef9e  vmovaps xmm11, [rsp+0xB0]
000076e4393cefa7  vmovaps xmm12, [rsp+0xC0]
000076e4393cefb0  vmovaps xmm13, [rsp+0xD0]
000076e4393cefb9  vmovaps xmm15, [rsp+0xE0]
000076e4393cefc2  add rsp, 0xF0
000076e4393cefc9  pop r11
000076e4393cefcb  pop r10
000076e4393cefcd  pop r9
000076e4393cefcf  pop r8
000076e4393cefd1  pop rsi
000076e4393cefd2  pop rdi
000076e4393cefd3  pop rdx
000076e4393cefd4  pop rcx
000076e4393cefd5  pop rax
000076e4393cefd6  add rsp, 0x08
000076e4393cefda  jmp 0x000076E4393CECAE
000076e4393cefdf  call 0x000076E4392C34C0
000076e4393cefe4  jmp 0x000076E4393CECC4
000076e4393cefe9  int3
000076e4393cefea  nop [rax+rax*1], ax
000076e4393ceff0  mov rax, [r15+0xF8]
000076e4393ceff7  lea r14, [rax-0x150]
000076e4393ceffe  mov [r15+0xF8], r14
000076e4393cf005  mov rax, [r15+0x50]
000076e4393cf009  lea r12, [rax+0x80]
000076e4393cf010  movups xmm1, [r13+r12*1]
000076e4393cf016  lea r12, [rax+0x90]
000076e4393cf01d  movups xmm15, [r13+r12*1]
000076e4393cf023  mov qword ptr [r15+0x48], 0x00
000076e4393cf02b  lea r12, [rax+0x40]
000076e4393cf02f  movups xmm14, [r13+r12*1]
000076e4393cf035  lea r12, [rax+0x50]
000076e4393cf039  movups xmm13, [r13+r12*1]
000076e4393cf03f  lea r12, [r14+0x120]
000076e4393cf046  movq xmm12, qword ptr [r15+0x1C0]
000076e4393cf04f  movq xmm11, qword ptr [r15+0x1B0]
000076e4393cf058  movq r11, xmm12
000076e4393cf05d  movq r10, xmm11
000076e4393cf062  mov [r13+r12*1], r11
000076e4393cf067  lea r12, [r14+0x128]
000076e4393cf06e  mov [r13+r12*1], r10
000076e4393cf073  vxorps xmm12, xmm12, xmm12
000076e4393cf078  vpbroadcastq xmm12, xmm12
000076e4393cf07d  lea r12, [r14+0x100]
000076e4393cf084  movq xmm11, qword ptr [r15+0x200]
000076e4393cf08d  movq xmm10, qword ptr [r15+0x1F0]
000076e4393cf096  movq r11, xmm11
000076e4393cf09b  movq r10, xmm10
000076e4393cf0a0  mov [r13+r12*1], r11
000076e4393cf0a5  lea r12, [r14+0x108]
000076e4393cf0ac  mov [r13+r12*1], r10
000076e4393cf0b1  lea r12, [r14+0xE0]
000076e4393cf0b8  movups [r13+r12*1], xmm15
000076e4393cf0be  lea r12, [r14+0xF0]
000076e4393cf0c5  movups [r13+r12*1], xmm1
000076e4393cf0cb  lea r12, [rax+0xC0]
000076e4393cf0d2  movups xmm1, [r13+r12*1]
000076e4393cf0d8  lea r12, [rax+0xD0]
000076e4393cf0df  movups xmm15, [r13+r12*1]
000076e4393cf0e5  lea r12, [r14+0x110]
000076e4393cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000076e4393cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000076e4393cf0fe  movq r11, xmm11
000076e4393cf103  movq r10, xmm10
000076e4393cf108  mov [r13+r12*1], r11
000076e4393cf10d  lea r12, [r14+0x118]
000076e4393cf114  mov [r13+r12*1], r10
000076e4393cf119  movups xmm11, [r13+rax*1]
000076e4393cf11f  lea r12, [rax+0x10]
000076e4393cf123  movups xmm10, [r13+r12*1]
000076e4393cf129  lea r12, [r14+0x130]
000076e4393cf130  movq xmm9, qword ptr [r15+0x1A0]
000076e4393cf139  movq xmm8, qword ptr [r15+0x190]
000076e4393cf142  movq r11, xmm9
000076e4393cf147  movq r10, xmm8
000076e4393cf14c  mov [r13+r12*1], r11
000076e4393cf151  lea r12, [r14+0x138]
000076e4393cf158  mov [r13+r12*1], r10
000076e4393cf15d  lea r12, [rax+0x140]
000076e4393cf164  movups xmm9, [r13+r12*1]
000076e4393cf16a  lea r12, [rax+0x150]
000076e4393cf171  movups xmm8, [r13+r12*1]
000076e4393cf177  lea r12, [r14+0xC0]
000076e4393cf17e  movups [r13+r12*1], xmm15
000076e4393cf184  lea r12, [r14+0xD0]
000076e4393cf18b  movups [r13+r12*1], xmm1
000076e4393cf191  lea r12, [rax+0x100]
000076e4393cf198  movups xmm1, [r13+r12*1]
000076e4393cf19e  lea r12, [rax+0x110]
000076e4393cf1a5  movups xmm15, [r13+r12*1]
000076e4393cf1ab  lea r12, [r14+0x140]
000076e4393cf1b2  mov r11, [r15+0xE8]
000076e4393cf1b9  mov [r13+r12*1], r11
000076e4393cf1be  lea r12, [rax+0x180]
000076e4393cf1c5  movups xmm7, [r13+r12*1]
000076e4393cf1cb  lea r12, [rax+0x190]
000076e4393cf1d2  movups xmm6, [r13+r12*1]
000076e4393cf1d8  lea r12, [rax+0x1C0]
000076e4393cf1df  movups xmm5, [r13+r12*1]
000076e4393cf1e5  lea r12, [rax+0x1D0]
000076e4393cf1ec  movups xmm4, [r13+r12*1]
000076e4393cf1f2  lea r12, [r14+0x20]
000076e4393cf1f6  movups [r13+r12*1], xmm1
000076e4393cf1fc  lea r12, [r14+0x30]
000076e4393cf200  movups [r13+r12*1], xmm13
000076e4393cf206  lea r12, [rax+0x60]
000076e4393cf20a  movups xmm1, [r13+r12*1]
000076e4393cf210  lea r12, [rax+0x70]
000076e4393cf214  movups xmm13, [r13+r12*1]
000076e4393cf21a  lea r12, [rax+0x20]
000076e4393cf21e  movups xmm3, [r13+r12*1]
000076e4393cf224  lea r12, [rax+0x30]
000076e4393cf228  movups xmm2, [r13+r12*1]
000076e4393cf22e  movaps [r15+0x1F0], xmm2
000076e4393cf236  lea r12, [r14+0x60]
000076e4393cf23a  movups [r13+r12*1], xmm11
000076e4393cf240  lea r12, [r14+0x70]
000076e4393cf244  movups [r13+r12*1], xmm5
000076e4393cf24a  lea r12, [rax+0xE0]
000076e4393cf251  movups xmm11, [r13+r12*1]
000076e4393cf257  lea r12, [rax+0xF0]
000076e4393cf25e  movups xmm5, [r13+r12*1]
000076e4393cf264  lea r12, [r14+0xA0]
000076e4393cf26b  movups [r13+r12*1], xmm13
000076e4393cf271  lea r12, [r14+0xB0]
000076e4393cf278  movups [r13+r12*1], xmm1
000076e4393cf27e  lea r12, [rax+0xA0]
000076e4393cf285  movups xmm1, [r13+r12*1]
000076e4393cf28b  lea r12, [rax+0xB0]
000076e4393cf292  movups xmm13, [r13+r12*1]
000076e4393cf298  lea r12, [rax+0x120]
000076e4393cf29f  vmovaps [rsp+0x10], xmm1
000076e4393cf2a5  movups xmm1, [r13+r12*1]
000076e4393cf2ab  lea r12, [rax+0x130]
000076e4393cf2b2  vmovaps [rsp+0x20], xmm1
000076e4393cf2b8  movups xmm1, [r13+r12*1]
000076e4393cf2be  lea r12, [rax+0x160]
000076e4393cf2c5  vmovaps [rsp+0x30], xmm1
000076e4393cf2cb  movups xmm1, [r13+r12*1]
000076e4393cf2d1  lea r12, [rax+0x170]
000076e4393cf2d8  vmovaps [rsp+0x40], xmm1
000076e4393cf2de  movups xmm1, [r13+r12*1]
000076e4393cf2e4  movaps [r15+0x2B0], xmm1
000076e4393cf2ec  lea r12, [r14+0x80]
000076e4393cf2f3  movups [r13+r12*1], xmm13
000076e4393cf2f9  lea r12, [r14+0x90]
000076e4393cf300  vmovaps xmm13, [rsp+0x10]
000076e4393cf306  movups [r13+r12*1], xmm13
000076e4393cf30c  lea r12, [rax+0x1A0]
000076e4393cf313  movups xmm13, [r13+r12*1]
000076e4393cf319  lea r12, [rax+0x1B0]
000076e4393cf320  vmovaps [rsp+0x10], xmm1
000076e4393cf326  movups xmm1, [r13+r12*1]
000076e4393cf32c  movaps [r15+0x290], xmm13
000076e4393cf334  movaps [r15+0x1E0], xmm1
000076e4393cf33c  lea r12, [rax+0x1E0]
000076e4393cf343  vmovaps [rsp+0x50], xmm1
000076e4393cf349  movups xmm1, [r13+r12*1]
000076e4393cf34f  lea r12, [rax+0x1F0]
000076e4393cf356  vmovaps [rsp+0x60], xmm1
000076e4393cf35c  movups xmm1, [r13+r12*1]
000076e4393cf362  mov qword ptr [r15+0x50], 0x430920
000076e4393cf36a  lea rax, [r14+0x40]
000076e4393cf36e  vmovaps [rsp+0x70], xmm1
000076e4393cf374  vmovaps xmm1, [rsp+0x40]
000076e4393cf37a  movups [r13+rax*1], xmm1
000076e4393cf380  lea rax, [r14+0x50]
000076e4393cf384  movups [r13+rax*1], xmm10
000076e4393cf38a  vmovaps xmm1, [rsp+0x70]
000076e4393cf390  movups [r13+r14*1], xmm1
000076e4393cf396  lea rax, [r14+0x10]
000076e4393cf39a  vmovaps xmm1, [rsp+0x60]
000076e4393cf3a0  movups [r13+rax*1], xmm1
000076e4393cf3a6  mov rax, [r15+0x40]
000076e4393cf3aa  vmovaps [rsp+0x40], xmm3
000076e4393cf3b0  vmovaps xmm1, [rsp+0x40]
000076e4393cf3b6  por xmm3, xmm1
000076e4393cf3ba  vmovaps [rsp+0x40], xmm6
000076e4393cf3c0  vmovaps xmm10, [rsp+0x40]
000076e4393cf3c6  por xmm6, xmm10
000076e4393cf3cb  lea r12, [rax+0x30]
000076e4393cf3cf  mov r11, [r13+r12*1]
000076e4393cf3d4  lea r12, [rax+0x38]
000076e4393cf3d8  mov r10, [r13+r12*1]
000076e4393cf3dd  movq xmm10, r11
000076e4393cf3e2  vmovaps [rsp+0x40], xmm1
000076e4393cf3e8  movq xmm1, r10
000076e4393cf3ed  movq xmm10, xmm10
000076e4393cf3f2  vmovaps [rsp+0x60], xmm10
000076e4393cf3f8  movq xmm10, xmm10
000076e4393cf3fd  movaps [r15+0x130], xmm10
000076e4393cf405  movq xmm1, xmm1
000076e4393cf409  vmovaps [rsp+0x70], xmm1
000076e4393cf40f  movq xmm1, xmm1
000076e4393cf413  movaps [r15+0x280], xmm1
000076e4393cf41b  vmovaps [rsp+0x80], xmm9
000076e4393cf424  vmovaps xmm1, [rsp+0x80]
000076e4393cf42d  por xmm9, xmm1
000076e4393cf432  lea r12, [rax+0x20]
000076e4393cf436  mov r11, [r13+r12*1]
000076e4393cf43b  lea r12, [rax+0x28]
000076e4393cf43f  mov r10, [r13+r12*1]
000076e4393cf444  movq xmm1, r11
000076e4393cf449  movq xmm10, r10
000076e4393cf44e  movq xmm1, xmm1
000076e4393cf452  vmovaps [rsp+0x80], xmm1
000076e4393cf45b  movq xmm1, xmm1
000076e4393cf45f  movaps [r15+0x150], xmm1
000076e4393cf467  movq xmm10, xmm10
000076e4393cf46c  vmovaps [rsp+0x90], xmm10
000076e4393cf475  movq xmm10, xmm10
000076e4393cf47a  movaps [r15+0x140], xmm10
000076e4393cf482  lea r12, [rax+0x10]
000076e4393cf486  mov r11, [r13+r12*1]
000076e4393cf48b  lea r12, [rax+0x18]
000076e4393cf48f  mov r10, [r13+r12*1]
000076e4393cf494  movq xmm1, r11
000076e4393cf499  movq xmm10, r10
000076e4393cf49e  movq xmm1, xmm1
000076e4393cf4a2  vmovaps [rsp+0xA0], xmm1
000076e4393cf4ab  movq xmm1, xmm1
000076e4393cf4af  movaps [r15+0x170], xmm1
000076e4393cf4b7  movq xmm10, xmm10
000076e4393cf4bc  vmovaps [rsp+0xB0], xmm10
000076e4393cf4c5  movq xmm10, xmm10
000076e4393cf4ca  movaps [r15+0x160], xmm10
000076e4393cf4d2  mov r12, [r13+rax*1]
000076e4393cf4d7  vmovq xmm1, r12
000076e4393cf4dc  vpbroadcastq xmm1, xmm1
000076e4393cf4e1  lea r12, [rax+0x08]
000076e4393cf4e5  mov rax, [r13+r12*1]
000076e4393cf4ea  movq xmm10, rax
000076e4393cf4ef  movaps [r15+0x230], xmm10
000076e4393cf4f7  lea rax, [r14+0x50]
000076e4393cf4fb  movups xmm10, [r13+rax*1]
000076e4393cf501  lea rax, [r14+0x60]
000076e4393cf505  vmovaps [rsp+0xC0], xmm1
000076e4393cf50e  movups xmm1, [r13+rax*1]
000076e4393cf514  lea rax, [r14+0x30]
000076e4393cf518  vmovaps [rsp+0xD0], xmm1
000076e4393cf521  movups xmm1, [r13+rax*1]
000076e4393cf527  mov qword ptr [r15+0x60], 0x430920
000076e4393cf52f  mov qword ptr [r15+0x58], 0x40
000076e4393cf537  vmovaps [rsp+0xE0], xmm1
000076e4393cf540  vmovaps [rsp+0xF0], xmm15
000076e4393cf549  vmovaps xmm15, [rsp+0xC0]
000076e4393cf552  vmovaps [rsp+0xC0], xmm14
000076e4393cf55b  vmovaps xmm14, [rsp+0x40]
000076e4393cf561  vmovaps [rsp+0x40], xmm13
000076e4393cf567  movaps xmm1, xmm15
000076e4393cf56b  mulpd xmm1, xmm14
000076e4393cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000076e4393cf575  ptest xmm13, xmm13
000076e4393cf57b  jnz 0x000076E4393D0682
000076e4393cf581  movq xmm14, qword ptr [r15+0x230]
000076e4393cf58a  vmovaps [rsp+0x100], xmm14
000076e4393cf593  vpermilpd xmm14, xmm14, 0x00
000076e4393cf599  vmovaps [rsp+0x110], xmm1
000076e4393cf5a2  vmovaps xmm1, [rsp+0xE0]
000076e4393cf5ab  vmovaps [rsp+0xE0], xmm15
000076e4393cf5b4  movaps xmm13, xmm1
000076e4393cf5b8  mulpd xmm13, xmm14
000076e4393cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000076e4393cf5c3  ptest xmm15, xmm15
000076e4393cf5c9  jnz 0x000076E4393D07C4
000076e4393cf5cf  vxorps xmm1, xmm1, xmm1
000076e4393cf5d3  vpbroadcastq xmm1, xmm1
000076e4393cf5d8  vmovaps xmm14, [rsp+0xE0]
000076e4393cf5e1  vmovaps [rsp+0xE0], xmm1
000076e4393cf5ea  vmovaps xmm1, [rsp+0xD0]
000076e4393cf5f3  vmovaps [rsp+0xD0], xmm13
000076e4393cf5fc  movaps xmm15, xmm14
000076e4393cf600  mulpd xmm15, xmm1
000076e4393cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000076e4393cf60b  ptest xmm13, xmm13
000076e4393cf611  jnz 0x000076E4393D0907
000076e4393cf617  movaps xmm1, xmm14
000076e4393cf61b  mulpd xmm1, xmm10
000076e4393cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000076e4393cf625  ptest xmm13, xmm13
000076e4393cf62b  jnz 0x000076E4393D0A4A
000076e4393cf631  movaps xmm13, xmm14
000076e4393cf635  mulpd xmm13, xmm2
000076e4393cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000076e4393cf640  ptest xmm10, xmm10
000076e4393cf646  jnz 0x000076E4393D0B8C
000076e4393cf64c  vmovaps [rsp+0x120], xmm7
000076e4393cf655  vmovaps xmm14, [rsp+0x120]
000076e4393cf65e  por xmm7, xmm14
000076e4393cf663  vmovaps xmm14, [rsp+0xC0]
000076e4393cf66c  vmovaps xmm10, [rsp+0xC0]
000076e4393cf675  por xmm14, xmm10
000076e4393cf67a  vmovaps xmm2, [rsp+0x100]
000076e4393cf683  vpermilpd xmm2, xmm2, 0x00
000076e4393cf689  vmovaps [rsp+0xC0], xmm1
000076e4393cf692  vmovaps [rsp+0x120], xmm15
000076e4393cf69b  movaps xmm1, xmm10
000076e4393cf69f  mulpd xmm1, xmm2
000076e4393cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000076e4393cf6a8  ptest xmm15, xmm15
000076e4393cf6ae  jnz 0x000076E4393D0CCF
000076e4393cf6b4  xor eax, eax
000076e4393cf6b6  mov r12d, 0x40
000076e4393cf6bc  mov r11d, 0x200
000076e4393cf6c2  cmp r12, r11
000076e4393cf6c5  cmc
000076e4393cf6c6  lahf
000076e4393cf6c7  seto al
000076e4393cf6ca  mov [r15+0x108], eax
000076e4393cf6d1  vmovaps xmm10, [rsp+0x110]
000076e4393cf6da  vmovaps xmm2, [rsp+0xE0]
000076e4393cf6e3  vmovaps [rsp+0xE0], xmm1
000076e4393cf6ec  movaps xmm15, xmm10
000076e4393cf6f0  addpd xmm15, xmm2
000076e4393cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393cf6fb  ptest xmm1, xmm1
000076e4393cf700  jnz 0x000076E4393D0E10
000076e4393cf706  vmovaps xmm10, [rsp+0x120]
000076e4393cf70f  vmovaps [rsp+0x110], xmm15
000076e4393cf718  movaps xmm1, xmm10
000076e4393cf71c  addpd xmm1, xmm12
000076e4393cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000076e4393cf726  ptest xmm15, xmm15
000076e4393cf72c  jnz 0x000076E4393D0F53
000076e4393cf732  vmovaps xmm10, [rsp+0xC0]
000076e4393cf73b  vmovaps [rsp+0xC0], xmm1
000076e4393cf744  movaps xmm15, xmm10
000076e4393cf748  addpd xmm15, xmm12
000076e4393cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393cf753  ptest xmm1, xmm1
000076e4393cf758  jnz 0x000076E4393D1095
000076e4393cf75e  vmovaps xmm1, [rsp+0x30]
000076e4393cf764  vmovaps xmm12, [rsp+0x30]
000076e4393cf76a  por xmm1, xmm12
000076e4393cf76f  vmovaps xmm12, [rsp+0x20]
000076e4393cf775  vmovaps xmm10, [rsp+0x20]
000076e4393cf77b  por xmm12, xmm10
000076e4393cf780  vmovaps [rsp+0x20], xmm5
000076e4393cf786  vmovaps xmm10, [rsp+0x20]
000076e4393cf78c  por xmm5, xmm10
000076e4393cf791  vmovaps [rsp+0x20], xmm11
000076e4393cf797  vmovaps xmm10, [rsp+0x20]
000076e4393cf79d  por xmm11, xmm10
000076e4393cf7a2  vmovaps [rsp+0x20], xmm4
000076e4393cf7a8  vmovaps xmm10, [rsp+0x20]
000076e4393cf7ae  por xmm4, xmm10
000076e4393cf7b3  vmovaps [rsp+0x20], xmm8
000076e4393cf7b9  vmovaps xmm10, [rsp+0x20]
000076e4393cf7bf  por xmm8, xmm10
000076e4393cf7c4  vmovaps xmm10, [rsp+0xF0]
000076e4393cf7cd  vmovaps [rsp+0x20], xmm1
000076e4393cf7d3  vmovaps xmm1, [rsp+0xF0]
000076e4393cf7dc  por xmm10, xmm1
000076e4393cf7e1  lea rax, [r14+0xA0]
000076e4393cf7e8  movups xmm1, [r13+rax*1]
000076e4393cf7ee  lea rax, [r14+0xB0]
000076e4393cf7f5  vmovaps [rsp+0x30], xmm1
000076e4393cf7fb  movups xmm1, [r13+rax*1]
000076e4393cf801  vmovaps [rsp+0xF0], xmm1
000076e4393cf80a  vmovaps [rsp+0x120], xmm15
000076e4393cf813  movaps xmm1, xmm13
000076e4393cf817  addpd xmm1, xmm2
000076e4393cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000076e4393cf820  ptest xmm15, xmm15
000076e4393cf826  jnz 0x000076E4393D11ED
000076e4393cf82c  lea rax, [r14+0xF0]
000076e4393cf833  movups xmm15, [r13+rax*1]
000076e4393cf839  vmovaps xmm2, [rsp+0xC0]
000076e4393cf842  vmovaps [rsp+0xC0], xmm1
000076e4393cf84b  vmovaps xmm1, [rsp+0xE0]
000076e4393cf854  vmovaps [rsp+0xE0], xmm15
000076e4393cf85d  movaps xmm13, xmm2
000076e4393cf861  addpd xmm13, xmm1
000076e4393cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000076e4393cf86c  ptest xmm15, xmm15
000076e4393cf872  jnz 0x000076E4393D1338
000076e4393cf878  vmovaps xmm15, [rsp+0x120]
000076e4393cf881  vmovaps xmm2, [rsp+0xD0]
000076e4393cf88a  vmovaps [rsp+0xD0], xmm14
000076e4393cf893  movaps xmm1, xmm15
000076e4393cf897  addpd xmm1, xmm2
000076e4393cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000076e4393cf8a0  ptest xmm14, xmm14
000076e4393cf8a6  jnz 0x000076E4393D147A
000076e4393cf8ac  vmovaps xmm15, [rsp+0x100]
000076e4393cf8b5  vpermilpd xmm15, xmm15, 0x00
000076e4393cf8bb  vmovaps xmm2, [rsp+0xF0]
000076e4393cf8c4  vmovaps [rsp+0xF0], xmm1
000076e4393cf8cd  movaps xmm14, xmm2
000076e4393cf8d1  mulpd xmm14, xmm15
000076e4393cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000076e4393cf8dc  ptest xmm1, xmm1
000076e4393cf8e1  jnz 0x000076E4393D15BB
000076e4393cf8e7  vmovaps xmm1, [rsp+0xA0]
000076e4393cf8f0  vpermilpd xmm1, xmm1, 0x00
000076e4393cf8f6  vmovaps xmm2, [rsp+0xE0]
000076e4393cf8ff  vmovaps [rsp+0xE0], xmm14
000076e4393cf908  movaps xmm15, xmm2
000076e4393cf90c  mulpd xmm15, xmm1
000076e4393cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000076e4393cf917  ptest xmm14, xmm14
000076e4393cf91d  jnz 0x000076E4393D16FE
000076e4393cf923  lea rax, [r14+0xE0]
000076e4393cf92a  movups xmm1, [r13+rax*1]
000076e4393cf930  vmovaps xmm14, [rsp+0x100]
000076e4393cf939  vpermilpd xmm14, xmm14, 0x00
000076e4393cf93f  vmovaps [rsp+0x100], xmm1
000076e4393cf948  vmovaps xmm1, [rsp+0x30]
000076e4393cf94e  vmovaps [rsp+0x30], xmm15
000076e4393cf954  movaps xmm2, xmm1
000076e4393cf957  mulpd xmm2, xmm14
000076e4393cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000076e4393cf961  ptest xmm15, xmm15
000076e4393cf967  jnz 0x000076E4393D184A
000076e4393cf96d  vmovaps [rsp+0x120], xmm10
000076e4393cf976  vmovaps xmm1, [rsp+0x120]
000076e4393cf97f  por xmm10, xmm1
000076e4393cf984  movaps [r15+0x300], xmm10
000076e4393cf98c  vmovaps [rsp+0x120], xmm8
000076e4393cf995  vmovaps xmm1, [rsp+0x120]
000076e4393cf99e  por xmm8, xmm1
000076e4393cf9a3  movaps [r15+0x190], xmm8
000076e4393cf9ab  vmovaps xmm1, [rsp+0xA0]
000076e4393cf9b4  vpermilpd xmm1, xmm1, 0x00
000076e4393cf9ba  vmovaps xmm14, [rsp+0x100]
000076e4393cf9c3  vmovaps [rsp+0x100], xmm13
000076e4393cf9cc  movaps xmm15, xmm14
000076e4393cf9d0  mulpd xmm15, xmm1
000076e4393cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000076e4393cf9db  ptest xmm13, xmm13
000076e4393cf9e1  jnz 0x000076E4393D198B
000076e4393cf9e7  lea rax, [r14+0x90]
000076e4393cf9ee  movups xmm1, [r13+rax*1]
000076e4393cf9f4  vmovaps [rsp+0x120], xmm4
000076e4393cf9fd  vmovaps xmm14, [rsp+0x120]
000076e4393cfa06  por xmm4, xmm14
000076e4393cfa0b  movaps [r15+0x1C0], xmm4
000076e4393cfa13  vmovaps [rsp+0x120], xmm11
000076e4393cfa1c  vmovaps xmm14, [rsp+0x120]
000076e4393cfa25  por xmm11, xmm14
000076e4393cfa2a  movaps [r15+0x200], xmm11
000076e4393cfa32  vmovaps [rsp+0x120], xmm5
000076e4393cfa3b  vmovaps xmm14, [rsp+0x120]
000076e4393cfa44  por xmm5, xmm14
000076e4393cfa49  movaps [r15+0x2D0], xmm5
000076e4393cfa51  vmovaps [rsp+0x120], xmm12
000076e4393cfa5a  vmovaps xmm14, [rsp+0x120]
000076e4393cfa63  por xmm12, xmm14
000076e4393cfa68  movaps [r15+0x2E0], xmm12
000076e4393cfa70  vmovaps xmm13, [rsp+0x110]
000076e4393cfa79  vmovaps [rsp+0x110], xmm1
000076e4393cfa82  vmovaps xmm1, [rsp+0xE0]
000076e4393cfa8b  vmovaps [rsp+0xE0], xmm15
000076e4393cfa94  movaps xmm14, xmm13
000076e4393cfa98  addpd xmm14, xmm1
000076e4393cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000076e4393cfaa3  ptest xmm15, xmm15
000076e4393cfaa9  jnz 0x000076E4393D1AD8
000076e4393cfaaf  vmovaps xmm1, [rsp+0xA0]
000076e4393cfab8  vpermilpd xmm1, xmm1, 0x00
000076e4393cfabe  vmovaps xmm13, [rsp+0x110]
000076e4393cfac7  vmovaps [rsp+0x110], xmm14
000076e4393cfad0  movaps xmm15, xmm13
000076e4393cfad4  mulpd xmm15, xmm1
000076e4393cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000076e4393cfadf  ptest xmm14, xmm14
000076e4393cfae5  jnz 0x000076E4393D1C1B
000076e4393cfaeb  lea rax, [r14+0x80]
000076e4393cfaf2  movups xmm1, [r13+rax*1]
000076e4393cfaf8  vmovaps xmm13, [rsp+0xC0]
000076e4393cfb01  vmovaps [rsp+0xC0], xmm1
000076e4393cfb0a  movaps xmm14, xmm13
000076e4393cfb0e  addpd xmm14, xmm2
000076e4393cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000076e4393cfb19  ptest xmm1, xmm1
000076e4393cfb1e  jnz 0x000076E4393D1D68
000076e4393cfb24  vmovaps xmm13, [rsp+0x100]
000076e4393cfb2d  vmovaps xmm2, [rsp+0x30]
000076e4393cfb33  vmovaps [rsp+0x30], xmm15
000076e4393cfb39  movaps xmm1, xmm13
000076e4393cfb3d  addpd xmm1, xmm2
000076e4393cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000076e4393cfb46  ptest xmm15, xmm15
000076e4393cfb4c  jnz 0x000076E4393D1EAB
000076e4393cfb52  vmovaps xmm15, [rsp+0x20]
000076e4393cfb58  vmovaps xmm13, [rsp+0x20]
000076e4393cfb5e  por xmm15, xmm13
000076e4393cfb63  movaps [r15+0x2F0], xmm15
000076e4393cfb6b  vmovaps xmm13, [rsp+0xA0]
000076e4393cfb74  vpermilpd xmm13, xmm13, 0x00
000076e4393cfb7a  vmovaps [rsp+0x20], xmm1
000076e4393cfb80  vmovaps xmm1, [rsp+0xC0]
000076e4393cfb89  vmovaps [rsp+0xA0], xmm15
000076e4393cfb92  movaps xmm2, xmm1
000076e4393cfb95  mulpd xmm2, xmm13
000076e4393cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000076e4393cfb9f  ptest xmm15, xmm15
000076e4393cfba5  jnz 0x000076E4393D1FEC
000076e4393cfbab  lea rax, [r14+0xD0]
000076e4393cfbb2  movups xmm1, [r13+rax*1]
000076e4393cfbb8  vmovaps xmm13, [rsp+0xF0]
000076e4393cfbc1  vmovaps [rsp+0xC0], xmm1
000076e4393cfbca  vmovaps xmm1, [rsp+0xE0]
000076e4393cfbd3  vmovaps [rsp+0xE0], xmm14
000076e4393cfbdc  movaps xmm15, xmm13
000076e4393cfbe0  addpd xmm15, xmm1
000076e4393cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000076e4393cfbeb  ptest xmm14, xmm14
000076e4393cfbf1  jnz 0x000076E4393D2137
000076e4393cfbf7  vmovaps xmm1, [rsp+0xB0]
000076e4393cfc00  vpermilpd xmm1, xmm1, 0x00
000076e4393cfc06  movaps xmm14, xmm11
000076e4393cfc0a  mulpd xmm14, xmm1
000076e4393cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000076e4393cfc15  ptest xmm13, xmm13
000076e4393cfc1b  jnz 0x000076E4393D227A
000076e4393cfc21  movaps [r15+0x260], xmm14
000076e4393cfc29  vxorps xmm1, xmm1, xmm1
000076e4393cfc2d  vpbroadcastq xmm1, xmm1
000076e4393cfc32  movaps [r15+0x1B0], xmm1
000076e4393cfc3a  vmovaps xmm1, [rsp+0xB0]
000076e4393cfc43  vpermilpd xmm1, xmm1, 0x00
000076e4393cfc49  vmovaps xmm11, [rsp+0xC0]
000076e4393cfc52  vmovaps [rsp+0xC0], xmm15
000076e4393cfc5b  movaps xmm13, xmm11
000076e4393cfc5f  mulpd xmm13, xmm1
000076e4393cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000076e4393cfc6a  ptest xmm15, xmm15
000076e4393cfc70  jnz 0x000076E4393D23BD
000076e4393cfc76  lea rax, [r14+0xC0]
000076e4393cfc7d  movups xmm1, [r13+rax*1]
000076e4393cfc83  vmovaps xmm11, [rsp+0x110]
000076e4393cfc8c  vmovaps [rsp+0xF0], xmm1
000076e4393cfc95  vmovaps xmm1, [rsp+0x30]
000076e4393cfc9b  vmovaps [rsp+0x30], xmm14
000076e4393cfca1  movaps xmm15, xmm11
000076e4393cfca5  addpd xmm15, xmm1
000076e4393cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000076e4393cfcb0  ptest xmm14, xmm14
000076e4393cfcb6  jnz 0x000076E4393D250A
000076e4393cfcbc  vmovaps [rsp+0x100], xmm9
000076e4393cfcc5  vmovaps xmm1, [rsp+0x100]
000076e4393cfcce  por xmm9, xmm1
000076e4393cfcd3  movaps [r15+0x270], xmm9
000076e4393cfcdb  vmovaps [rsp+0x100], xmm6
000076e4393cfce4  vmovaps xmm1, [rsp+0x100]
000076e4393cfced  por xmm6, xmm1
000076e4393cfcf1  movaps [r15+0x1A0], xmm6
000076e4393cfcf9  vmovaps xmm14, [rsp+0xB0]
000076e4393cfd02  vpermilpd xmm14, xmm14, 0x00
000076e4393cfd08  vmovaps xmm6, [rsp+0xF0]
000076e4393cfd11  vmovaps [rsp+0xF0], xmm1
000076e4393cfd1a  movaps xmm11, xmm6
000076e4393cfd1e  mulpd xmm11, xmm14
000076e4393cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000076e4393cfd29  ptest xmm1, xmm1
000076e4393cfd2e  jnz 0x000076E4393D264D
000076e4393cfd34  lea rax, [r14+0x20]
000076e4393cfd38  movups xmm1, [r13+rax*1]
000076e4393cfd3e  movaps [r15+0x110], xmm1
000076e4393cfd46  vmovaps xmm6, [rsp+0xE0]
000076e4393cfd4f  vmovaps [rsp+0xE0], xmm1
000076e4393cfd58  movaps xmm14, xmm6
000076e4393cfd5c  addpd xmm14, xmm2
000076e4393cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000076e4393cfd67  ptest xmm1, xmm1
000076e4393cfd6c  jnz 0x000076E4393D279A
000076e4393cfd72  vmovaps xmm1, [rsp+0xB0]
000076e4393cfd7b  vpermilpd xmm1, xmm1, 0x00
000076e4393cfd81  movaps xmm6, xmm5
000076e4393cfd84  mulpd xmm6, xmm1
000076e4393cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000076e4393cfd8d  ptest xmm2, xmm2
000076e4393cfd92  jnz 0x000076E4393D28DC
000076e4393cfd98  vmovaps xmm5, [rsp+0x20]
000076e4393cfd9e  movaps xmm1, xmm5
000076e4393cfda1  addpd xmm1, xmm13
000076e4393cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000076e4393cfdab  ptest xmm2, xmm2
000076e4393cfdb0  jnz 0x000076E4393D2A1C
000076e4393cfdb6  vmovaps xmm13, [rsp+0x80]
000076e4393cfdbf  vpermilpd xmm13, xmm13, 0x00
000076e4393cfdc5  vmovaps xmm2, [rsp+0xE0]
000076e4393cfdce  vmovaps [rsp+0x20], xmm1
000076e4393cfdd4  movaps xmm5, xmm2
000076e4393cfdd7  mulpd xmm5, xmm13
000076e4393cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000076e4393cfde1  ptest xmm1, xmm1
000076e4393cfde6  jnz 0x000076E4393D2B5D
000076e4393cfdec  vmovaps xmm1, [rsp+0x80]
000076e4393cfdf5  vpermilpd xmm1, xmm1, 0x00
000076e4393cfdfb  movaps xmm13, xmm10
000076e4393cfdff  mulpd xmm13, xmm1
000076e4393cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000076e4393cfe0a  ptest xmm2, xmm2
000076e4393cfe0f  jnz 0x000076E4393D2C9E
000076e4393cfe15  vmovaps xmm10, [rsp+0x30]
000076e4393cfe1b  movaps xmm1, xmm15
000076e4393cfe1f  addpd xmm1, xmm10
000076e4393cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000076e4393cfe29  ptest xmm2, xmm2
000076e4393cfe2e  jnz 0x000076E4393D2DE1
000076e4393cfe34  vmovaps xmm10, [rsp+0xC0]
000076e4393cfe3d  movaps xmm15, xmm10
000076e4393cfe41  addpd xmm15, xmm11
000076e4393cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000076e4393cfe4c  ptest xmm2, xmm2
000076e4393cfe51  jnz 0x000076E4393D2F23
000076e4393cfe57  vmovaps xmm11, [rsp+0x80]
000076e4393cfe60  vpermilpd xmm11, xmm11, 0x00
000076e4393cfe66  movaps xmm10, xmm12
000076e4393cfe6a  mulpd xmm10, xmm11
000076e4393cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000076e4393cfe75  ptest xmm2, xmm2
000076e4393cfe7a  jnz 0x000076E4393D3067
000076e4393cfe80  vmovaps xmm12, [rsp+0x80]
000076e4393cfe89  vpermilpd xmm12, xmm12, 0x00
000076e4393cfe8f  vmovaps xmm2, [rsp+0xA0]
000076e4393cfe98  vmovaps [rsp+0x30], xmm1
000076e4393cfe9e  movaps xmm11, xmm2
000076e4393cfea2  mulpd xmm11, xmm12
000076e4393cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000076e4393cfead  ptest xmm1, xmm1
000076e4393cfeb2  jnz 0x000076E4393D31AB
000076e4393cfeb8  movaps xmm1, xmm14
000076e4393cfebc  addpd xmm1, xmm6
000076e4393cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000076e4393cfec5  ptest xmm12, xmm12
000076e4393cfecb  jnz 0x000076E4393D32EE
000076e4393cfed1  vmovaps xmm12, [rsp+0x20]
000076e4393cfed7  movaps xmm14, xmm12
000076e4393cfedb  addpd xmm14, xmm5
000076e4393cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000076e4393cfee6  ptest xmm6, xmm6
000076e4393cfeeb  jnz 0x000076E4393D342F
000076e4393cfef1  vmovaps xmm12, [rsp+0x90]
000076e4393cfefa  vpermilpd xmm12, xmm12, 0x00
000076e4393cff00  movaps xmm6, xmm9
000076e4393cff04  mulpd xmm6, xmm12
000076e4393cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000076e4393cff0e  ptest xmm5, xmm5
000076e4393cff13  jnz 0x000076E4393D3572
000076e4393cff19  movaps xmm12, xmm15
000076e4393cff1d  addpd xmm12, xmm13
000076e4393cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000076e4393cff28  ptest xmm9, xmm9
000076e4393cff2e  jnz 0x000076E4393D36B4
000076e4393cff34  vmovaps xmm13, [rsp+0x30]
000076e4393cff3a  movaps xmm15, xmm13
000076e4393cff3e  addpd xmm15, xmm10
000076e4393cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000076e4393cff49  ptest xmm9, xmm9
000076e4393cff4f  jnz 0x000076E4393D37F8
000076e4393cff55  vmovaps xmm13, [rsp+0xD0]
000076e4393cff5e  vmovaps xmm10, [rsp+0xD0]
000076e4393cff67  por xmm13, xmm10
000076e4393cff6c  movaps [r15+0x250], xmm13
000076e4393cff74  vmovaps [rsp+0x20], xmm7
000076e4393cff7a  vmovaps xmm13, [rsp+0x20]
000076e4393cff80  por xmm7, xmm13
000076e4393cff85  movaps [r15+0x2A0], xmm7
000076e4393cff8d  vmovaps [rsp+0x20], xmm3
000076e4393cff93  vmovaps xmm13, [rsp+0x20]
000076e4393cff99  por xmm3, xmm13
000076e4393cff9e  movaps [r15+0x1D0], xmm3
000076e4393cffa6  lea rax, [r14+0x40]
000076e4393cffaa  movups xmm13, [r13+rax*1]
000076e4393cffb0  movaps [r15+0x2C0], xmm13
000076e4393cffb8  vmovaps xmm10, [rsp+0x90]
000076e4393cffc1  vpermilpd xmm10, xmm10, 0x00
000076e4393cffc7  movaps xmm9, xmm8
000076e4393cffcb  mulpd xmm9, xmm10
000076e4393cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000076e4393cffd6  ptest xmm5, xmm5
000076e4393cffdb  jnz 0x000076E4393D3946
000076e4393cffe1  movaps xmm10, xmm1
000076e4393cffe5  addpd xmm10, xmm11
000076e4393cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000076e4393cfff0  ptest xmm8, xmm8
000076e4393cfff6  jnz 0x000076E4393D3A8A
000076e4393cfffc  movaps xmm1, xmm14
000076e4393d0000  addpd xmm1, xmm6
000076e4393d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000076e4393d0009  ptest xmm11, xmm11
000076e4393d000f  jnz 0x000076E4393D3BCD
000076e4393d0015  vmovaps xmm14, [rsp+0x90]
000076e4393d001e  vpermilpd xmm14, xmm14, 0x00
000076e4393d0024  movaps xmm11, xmm13
000076e4393d0028  mulpd xmm11, xmm14
000076e4393d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000076e4393d0033  ptest xmm8, xmm8
000076e4393d0039  jnz 0x000076E4393D3D0E
000076e4393d003f  vmovaps xmm14, [rsp+0x90]
000076e4393d0048  vpermilpd xmm14, xmm14, 0x00
000076e4393d004e  vmovaps xmm8, [rsp+0x10]
000076e4393d0054  movaps xmm13, xmm8
000076e4393d0058  mulpd xmm13, xmm14
000076e4393d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000076e4393d0063  ptest xmm6, xmm6
000076e4393d0068  jnz 0x000076E4393D3E52
000076e4393d006e  vmovaps xmm14, [rsp+0x60]
000076e4393d0074  vpermilpd xmm14, xmm14, 0x00
000076e4393d007a  movaps xmm8, xmm7
000076e4393d007e  mulpd xmm8, xmm14
000076e4393d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000076e4393d0089  ptest xmm6, xmm6
000076e4393d008e  jnz 0x000076E4393D3F96
000076e4393d0094  movaps xmm14, xmm12
000076e4393d0098  addpd xmm14, xmm9
000076e4393d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000076e4393d00a3  ptest xmm7, xmm7
000076e4393d00a8  jnz 0x000076E4393D40D9
000076e4393d00ae  vmovaps xmm12, [rsp+0x60]
000076e4393d00b4  vpermilpd xmm12, xmm12, 0x00
000076e4393d00ba  vmovaps xmm7, [rsp+0xF0]
000076e4393d00c3  movaps xmm9, xmm7
000076e4393d00c7  mulpd xmm9, xmm12
000076e4393d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000076e4393d00d2  ptest xmm6, xmm6
000076e4393d00d7  jnz 0x000076E4393D421D
000076e4393d00dd  movaps xmm12, xmm15
000076e4393d00e1  addpd xmm12, xmm11
000076e4393d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000076e4393d00ec  ptest xmm7, xmm7
000076e4393d00f1  jnz 0x000076E4393D4360
000076e4393d00f7  vmovaps xmm15, [rsp+0x60]
000076e4393d00fd  vpermilpd xmm15, xmm15, 0x00
000076e4393d0103  vmovaps xmm7, [rsp+0x40]
000076e4393d0109  movaps xmm11, xmm7
000076e4393d010d  mulpd xmm11, xmm15
000076e4393d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000076e4393d0118  ptest xmm6, xmm6
000076e4393d011d  jnz 0x000076E4393D44A4
000076e4393d0123  movaps xmm15, xmm10
000076e4393d0127  addpd xmm15, xmm13
000076e4393d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000076e4393d0132  ptest xmm7, xmm7
000076e4393d0137  jnz 0x000076E4393D45E7
000076e4393d013d  vmovaps xmm13, [rsp+0x60]
000076e4393d0143  vpermilpd xmm13, xmm13, 0x00
000076e4393d0149  vmovaps xmm7, [rsp+0x50]
000076e4393d014f  movaps xmm10, xmm7
000076e4393d0153  mulpd xmm10, xmm13
000076e4393d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000076e4393d015e  ptest xmm6, xmm6
000076e4393d0163  jnz 0x000076E4393D472B
000076e4393d0169  movaps xmm13, xmm1
000076e4393d016d  addpd xmm13, xmm8
000076e4393d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000076e4393d0178  ptest xmm7, xmm7
000076e4393d017d  jnz 0x000076E4393D486E
000076e4393d0183  lea rax, [r14+0x70]
000076e4393d0187  movups xmm1, [r13+rax*1]
000076e4393d018d  movaps [r15+0x240], xmm1
000076e4393d0195  movaps xmm8, xmm14
000076e4393d0199  addpd xmm8, xmm9
000076e4393d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000076e4393d01a4  ptest xmm7, xmm7
000076e4393d01a9  jnz 0x000076E4393D49BB
000076e4393d01af  movaps [r15+0x170], xmm8
000076e4393d01b7  vmovaps xmm14, [rsp+0x70]
000076e4393d01bd  vpermilpd xmm14, xmm14, 0x00
000076e4393d01c3  movaps xmm9, xmm1
000076e4393d01c7  mulpd xmm9, xmm14
000076e4393d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000076e4393d01d2  ptest xmm7, xmm7
000076e4393d01d7  jnz 0x000076E4393D4AFF
000076e4393d01dd  vmovaps xmm1, [rsp+0x70]
000076e4393d01e3  vpermilpd xmm1, xmm1, 0x00
000076e4393d01e9  movaps xmm14, xmm4
000076e4393d01ed  mulpd xmm14, xmm1
000076e4393d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000076e4393d01f8  ptest xmm7, xmm7
000076e4393d01fd  jnz 0x000076E4393D4C42
000076e4393d0203  movaps [r15+0x180], xmm14
000076e4393d020b  movaps xmm1, xmm12
000076e4393d020f  addpd xmm1, xmm11
000076e4393d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000076e4393d0219  ptest xmm7, xmm7
000076e4393d021e  jnz 0x000076E4393D4D84
000076e4393d0224  movaps [r15+0x210], xmm1
000076e4393d022c  movups xmm12, [r13+r14*1]
000076e4393d0232  lea rax, [r14+0x10]
000076e4393d0236  movups xmm11, [r13+rax*1]
000076e4393d023c  movaps [r15+0x230], xmm11
000076e4393d0244  movaps xmm7, xmm15
000076e4393d0248  addpd xmm7, xmm10
000076e4393d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000076e4393d0252  ptest xmm6, xmm6
000076e4393d0257  jnz 0x000076E4393D4EDA
000076e4393d025d  movaps [r15+0x130], xmm7
000076e4393d0265  vmovaps xmm15, [rsp+0x70]
000076e4393d026b  vpermilpd xmm15, xmm15, 0x00
000076e4393d0271  movaps xmm10, xmm11
000076e4393d0275  mulpd xmm10, xmm15
000076e4393d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000076e4393d0280  ptest xmm6, xmm6
000076e4393d0285  jnz 0x000076E4393D501C
000076e4393d028b  movaps [r15+0x220], xmm10
000076e4393d0293  vmovaps xmm15, [rsp+0x70]
000076e4393d0299  vpermilpd xmm15, xmm15, 0x00
000076e4393d029f  movaps xmm11, xmm12
000076e4393d02a3  mulpd xmm11, xmm15
000076e4393d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000076e4393d02ae  ptest xmm6, xmm6
000076e4393d02b3  jnz 0x000076E4393D5160
000076e4393d02b9  movaps xmm15, xmm13
000076e4393d02bd  addpd xmm15, xmm9
000076e4393d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000076e4393d02c8  ptest xmm12, xmm12
000076e4393d02ce  jnz 0x000076E4393D52A4
000076e4393d02d4  movaps [r15+0x140], xmm15
000076e4393d02dc  movaps xmm13, xmm8
000076e4393d02e0  addpd xmm13, xmm14
000076e4393d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000076e4393d02eb  ptest xmm12, xmm12
000076e4393d02f1  jnz 0x000076E4393D53E8
000076e4393d02f7  movaps [r15+0x150], xmm13
000076e4393d02ff  movaps xmm14, xmm1
000076e4393d0303  addpd xmm14, xmm10
000076e4393d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000076e4393d030e  ptest xmm12, xmm12
000076e4393d0314  jnz 0x000076E4393D552C
000076e4393d031a  movaps [r15+0x160], xmm14
000076e4393d0322  movaps xmm1, xmm7
000076e4393d0325  addpd xmm1, xmm11
000076e4393d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000076e4393d032f  ptest xmm12, xmm12
000076e4393d0335  jnz 0x000076E4393D566F
000076e4393d033b  movaps [r15+0x120], xmm1
000076e4393d0343  mov eax, 0x430920
000076e4393d0348  movups [r13+rax*1], xmm15
000076e4393d034e  mov eax, 0x430930
000076e4393d0353  movups [r13+rax*1], xmm13
000076e4393d0359  mov eax, 0x430940
000076e4393d035e  movups [r13+rax*1], xmm14
000076e4393d0364  mov eax, 0x430950
000076e4393d0369  movups [r13+rax*1], xmm1
000076e4393d036f  mov eax, [r15+0x108]
000076e4393d0376  sahf
000076e4393d0377  jnz 0x000076E4393D03A9
000076e4393d0379  cmp dword ptr [r15+0x318], 0x00
000076e4393d0381  jz 0x000076E4393DB900
000076e4393d0387  nop [rax+rax*1], ax
000076e4393d0390  nop [rax+rax*1], eax
000076e4393d0398  mov eax, 0x410444
000076e4393d039d  mov [r15+0x100], rax
000076e4393d03a4  jmp 0x000076E4391FE110
000076e4393d03a9  cmp dword ptr [r15+0x318], 0x00
000076e4393d03b1  jz 0x000076E4393D57E0
000076e4393d03b7  nop [rax+rax*1], ax
000076e4393d03c0  nop [rax+rax*1], eax
000076e4393d03c8  mov eax, 0x410278
000076e4393d03cd  mov [r15+0x100], rax
000076e4393d03d4  jmp 0x000076E4391FE110
000076e4393d03d9  int3
000076e4393d03da  call 0x000076E4392B52F0
000076e4393d03df  jmp 0x000076E4393CF016
000076e4393d03e4  call 0x000076E4392C4620
000076e4393d03e9  jmp 0x000076E4393CF023
000076e4393d03ee  call 0x000076E4392C33A0
000076e4393d03f3  jmp 0x000076E4393CF035
000076e4393d03f8  call 0x000076E4392C2120
000076e4393d03fd  jmp 0x000076E4393CF03F
000076e4393d0402  call 0x000076E4392C0860
000076e4393d0407  jmp 0x000076E4393CF067
000076e4393d040c  call 0x000076E4392BF5F0
000076e4393d0411  jmp 0x000076E4393CF073
000076e4393d0416  call 0x000076E4392C0860
000076e4393d041b  jmp 0x000076E4393CF0A5
000076e4393d0420  call 0x000076E4392BF5F0
000076e4393d0425  jmp 0x000076E4393CF0B1
000076e4393d042a  call 0x000076E4392C4740
000076e4393d042f  jmp 0x000076E4393CF0BE
000076e4393d0434  call 0x000076E4392B5400
000076e4393d0439  jmp 0x000076E4393CF0CB
000076e4393d043e  call 0x000076E4392B52F0
000076e4393d0443  jmp 0x000076E4393CF0D8
000076e4393d0448  call 0x000076E4392C4620
000076e4393d044d  jmp 0x000076E4393CF0E5
000076e4393d0452  call 0x000076E4392C0860
000076e4393d0457  jmp 0x000076E4393CF10D
000076e4393d045c  call 0x000076E4392BF5F0
000076e4393d0461  jmp 0x000076E4393CF119
000076e4393d0466  call 0x000076E439209D70
000076e4393d046b  jmp 0x000076E4393CF11F
000076e4393d0470  call 0x000076E4392BE9C0
000076e4393d0475  jmp 0x000076E4393CF129
000076e4393d047a  call 0x000076E4392C0860
000076e4393d047f  jmp 0x000076E4393CF151
000076e4393d0484  call 0x000076E4392BF5F0
000076e4393d0489  jmp 0x000076E4393CF15D
000076e4393d048e  call 0x000076E4392BD750
000076e4393d0493  jmp 0x000076E4393CF16A
000076e4393d0498  call 0x000076E4392BC4E0
000076e4393d049d  jmp 0x000076E4393CF177
000076e4393d04a2  call 0x000076E4392C4740
000076e4393d04a7  jmp 0x000076E4393CF184
000076e4393d04ac  call 0x000076E4392B5400
000076e4393d04b1  jmp 0x000076E4393CF191
000076e4393d04b6  call 0x000076E4392B52F0
000076e4393d04bb  jmp 0x000076E4393CF19E
000076e4393d04c0  call 0x000076E4392C4620
000076e4393d04c5  jmp 0x000076E4393CF1AB
000076e4393d04ca  call 0x000076E4392C0860
000076e4393d04cf  jmp 0x000076E4393CF1BE
000076e4393d04d4  call 0x000076E4392BB270
000076e4393d04d9  jmp 0x000076E4393CF1CB
000076e4393d04de  call 0x000076E4392BA000
000076e4393d04e3  jmp 0x000076E4393CF1D8
000076e4393d04e8  call 0x000076E4392B8D90
000076e4393d04ed  jmp 0x000076E4393CF1E5
000076e4393d04f2  call 0x000076E4392B8A20
000076e4393d04f7  jmp 0x000076E4393CF1F2
000076e4393d04fc  call 0x000076E4392B5400
000076e4393d0501  jmp 0x000076E4393CF1FC
000076e4393d0506  call 0x000076E4392C2240
000076e4393d050b  jmp 0x000076E4393CF206
000076e4393d0510  call 0x000076E4392B52F0
000076e4393d0515  jmp 0x000076E4393CF210
000076e4393d051a  call 0x000076E4392C2120
000076e4393d051f  jmp 0x000076E4393CF21A
000076e4393d0524  call 0x000076E4392B77B0
000076e4393d0529  jmp 0x000076E4393CF224
000076e4393d052e  call 0x000076E4392B6550
000076e4393d0533  jmp 0x000076E4393CF22E
000076e4393d0538  call 0x000076E4392BFD50
000076e4393d053d  jmp 0x000076E4393CF240
000076e4393d0542  call 0x000076E4392B8EA0
000076e4393d0547  jmp 0x000076E4393CF24A
000076e4393d054c  call 0x000076E4392BFC30
000076e4393d0551  jmp 0x000076E4393CF257
000076e4393d0556  call 0x000076E4392B8D90
000076e4393d055b  jmp 0x000076E4393CF264
000076e4393d0560  call 0x000076E4392C2240
000076e4393d0565  jmp 0x000076E4393CF271
000076e4393d056a  call 0x000076E4392B5400
000076e4393d056f  jmp 0x000076E4393CF27E
000076e4393d0574  call 0x000076E4392B52F0
000076e4393d0579  jmp 0x000076E4393CF28B
000076e4393d057e  call 0x000076E4392C2120
000076e4393d0583  jmp 0x000076E4393CF298
000076e4393d0588  call 0x000076E4392B52F0
000076e4393d058d  jmp 0x000076E4393CF2AB
000076e4393d0592  call 0x000076E4392B52F0
000076e4393d0597  jmp 0x000076E4393CF2BE
000076e4393d059c  call 0x000076E4392B52F0
000076e4393d05a1  jmp 0x000076E4393CF2D1
000076e4393d05a6  call 0x000076E4392B52F0
000076e4393d05ab  jmp 0x000076E4393CF2E4
000076e4393d05b0  call 0x000076E4392C2240
000076e4393d05b5  jmp 0x000076E4393CF2F9
000076e4393d05ba  call 0x000076E4392C2240
000076e4393d05bf  jmp 0x000076E4393CF30C
000076e4393d05c4  call 0x000076E4392C2120
000076e4393d05c9  jmp 0x000076E4393CF319
000076e4393d05ce  call 0x000076E4392B52F0
000076e4393d05d3  jmp 0x000076E4393CF32C
000076e4393d05d8  call 0x000076E4392B52F0
000076e4393d05dd  jmp 0x000076E4393CF34F
000076e4393d05e2  call 0x000076E4392B52F0
000076e4393d05e7  jmp 0x000076E4393CF362
000076e4393d05ec  call 0x000076E4391FF540
000076e4393d05f1  jmp 0x000076E4393CF380
000076e4393d05f6  call 0x000076E439208C20
000076e4393d05fb  jmp 0x000076E4393CF38A
000076e4393d0600  call 0x000076E4392D6600
000076e4393d0605  jmp 0x000076E4393CF396
000076e4393d060a  call 0x000076E4391FF540
000076e4393d060f  jmp 0x000076E4393CF3A6
000076e4393d0614  call 0x000076E4392C0370
000076e4393d0619  jmp 0x000076E4393CF3D4
000076e4393d061e  call 0x000076E4392BF100
000076e4393d0623  jmp 0x000076E4393CF3DD
000076e4393d0628  call 0x000076E4392C0370
000076e4393d062d  jmp 0x000076E4393CF43B
000076e4393d0632  call 0x000076E4392BF100
000076e4393d0637  jmp 0x000076E4393CF444
000076e4393d063c  call 0x000076E4392C0370
000076e4393d0641  jmp 0x000076E4393CF48B
000076e4393d0646  call 0x000076E4392BF100
000076e4393d064b  jmp 0x000076E4393CF494
000076e4393d0650  call 0x000076E43920B720
000076e4393d0655  jmp 0x000076E4393CF4D7
000076e4393d065a  call 0x000076E4392B47C0
000076e4393d065f  jmp 0x000076E4393CF4EA
000076e4393d0664  call 0x000076E439208B00
000076e4393d0669  jmp 0x000076E4393CF501
000076e4393d066e  call 0x000076E4391FF430
000076e4393d0673  jmp 0x000076E4393CF514
000076e4393d0678  call 0x000076E4391FF430
000076e4393d067d  jmp 0x000076E4393CF527
000076e4393d0682  sub rsp, 0x08
000076e4393d0686  push rax
000076e4393d0687  push rcx
000076e4393d0688  push rdx
000076e4393d0689  push rdi
000076e4393d068a  push rsi
000076e4393d068b  push r8
000076e4393d068d  push r9
000076e4393d068f  push r10
000076e4393d0691  push r11
000076e4393d0693  sub rsp, 0xF0
000076e4393d069a  vmovaps [rsp], xmm0
000076e4393d069f  vmovaps [rsp+0x10], xmm2
000076e4393d06a5  vmovaps [rsp+0x20], xmm3
000076e4393d06ab  vmovaps [rsp+0x30], xmm4
000076e4393d06b1  vmovaps [rsp+0x40], xmm5
000076e4393d06b7  vmovaps [rsp+0x50], xmm6
000076e4393d06bd  vmovaps [rsp+0x60], xmm7
000076e4393d06c3  vmovaps [rsp+0x70], xmm8
000076e4393d06c9  vmovaps [rsp+0x80], xmm9
000076e4393d06d2  vmovaps [rsp+0x90], xmm10
000076e4393d06db  vmovaps [rsp+0xA0], xmm11
000076e4393d06e4  vmovaps [rsp+0xB0], xmm12
000076e4393d06ed  vmovaps [rsp+0xC0], xmm13
000076e4393d06f6  vmovaps [rsp+0xD0], xmm14
000076e4393d06ff  vmovaps [rsp+0xE0], xmm15
000076e4393d0708  sub rsp, 0x30
000076e4393d070c  movaps [rsp], xmm1
000076e4393d0710  movaps [rsp+0x10], xmm15
000076e4393d0716  movaps [rsp+0x20], xmm14
000076e4393d071c  lea rdi, [rsp]
000076e4393d0720  mov esi, 0x00
000076e4393d0725  mov rax, 0x63DBDEB43530
000076e4393d072f  call rax
000076e4393d0731  movaps xmm1, [rsp]
000076e4393d0735  add rsp, 0x30
000076e4393d0739  vmovaps xmm0, [rsp]
000076e4393d073e  vmovaps xmm2, [rsp+0x10]
000076e4393d0744  vmovaps xmm3, [rsp+0x20]
000076e4393d074a  vmovaps xmm4, [rsp+0x30]
000076e4393d0750  vmovaps xmm5, [rsp+0x40]
000076e4393d0756  vmovaps xmm6, [rsp+0x50]
000076e4393d075c  vmovaps xmm7, [rsp+0x60]
000076e4393d0762  vmovaps xmm8, [rsp+0x70]
000076e4393d0768  vmovaps xmm9, [rsp+0x80]
000076e4393d0771  vmovaps xmm10, [rsp+0x90]
000076e4393d077a  vmovaps xmm11, [rsp+0xA0]
000076e4393d0783  vmovaps xmm12, [rsp+0xB0]
000076e4393d078c  vmovaps xmm13, [rsp+0xC0]
000076e4393d0795  vmovaps xmm14, [rsp+0xD0]
000076e4393d079e  vmovaps xmm15, [rsp+0xE0]
000076e4393d07a7  add rsp, 0xF0
000076e4393d07ae  pop r11
000076e4393d07b0  pop r10
000076e4393d07b2  pop r9
000076e4393d07b4  pop r8
000076e4393d07b6  pop rsi
000076e4393d07b7  pop rdi
000076e4393d07b8  pop rdx
000076e4393d07b9  pop rcx
000076e4393d07ba  pop rax
000076e4393d07bb  add rsp, 0x08
000076e4393d07bf  jmp 0x000076E4393CF581
000076e4393d07c4  sub rsp, 0x08
000076e4393d07c8  push rax
000076e4393d07c9  push rcx
000076e4393d07ca  push rdx
000076e4393d07cb  push rdi
000076e4393d07cc  push rsi
000076e4393d07cd  push r8
000076e4393d07cf  push r9
000076e4393d07d1  push r10
000076e4393d07d3  push r11
000076e4393d07d5  sub rsp, 0xF0
000076e4393d07dc  vmovaps [rsp], xmm0
000076e4393d07e1  vmovaps [rsp+0x10], xmm1
000076e4393d07e7  vmovaps [rsp+0x20], xmm2
000076e4393d07ed  vmovaps [rsp+0x30], xmm3
000076e4393d07f3  vmovaps [rsp+0x40], xmm4
000076e4393d07f9  vmovaps [rsp+0x50], xmm5
000076e4393d07ff  vmovaps [rsp+0x60], xmm6
000076e4393d0805  vmovaps [rsp+0x70], xmm7
000076e4393d080b  vmovaps [rsp+0x80], xmm8
000076e4393d0814  vmovaps [rsp+0x90], xmm9
000076e4393d081d  vmovaps [rsp+0xA0], xmm10
000076e4393d0826  vmovaps [rsp+0xB0], xmm11
000076e4393d082f  vmovaps [rsp+0xC0], xmm12
000076e4393d0838  vmovaps [rsp+0xD0], xmm14
000076e4393d0841  vmovaps [rsp+0xE0], xmm15
000076e4393d084a  sub rsp, 0x30
000076e4393d084e  movaps [rsp], xmm13
000076e4393d0853  movaps [rsp+0x10], xmm1
000076e4393d0858  movaps [rsp+0x20], xmm14
000076e4393d085e  lea rdi, [rsp]
000076e4393d0862  mov esi, 0x00
000076e4393d0867  mov rax, 0x63DBDEB43530
000076e4393d0871  call rax
000076e4393d0873  movaps xmm13, [rsp]
000076e4393d0878  add rsp, 0x30
000076e4393d087c  vmovaps xmm0, [rsp]
000076e4393d0881  vmovaps xmm1, [rsp+0x10]
000076e4393d0887  vmovaps xmm2, [rsp+0x20]
000076e4393d088d  vmovaps xmm3, [rsp+0x30]
000076e4393d0893  vmovaps xmm4, [rsp+0x40]
000076e4393d0899  vmovaps xmm5, [rsp+0x50]
000076e4393d089f  vmovaps xmm6, [rsp+0x60]
000076e4393d08a5  vmovaps xmm7, [rsp+0x70]
000076e4393d08ab  vmovaps xmm8, [rsp+0x80]
000076e4393d08b4  vmovaps xmm9, [rsp+0x90]
000076e4393d08bd  vmovaps xmm10, [rsp+0xA0]
000076e4393d08c6  vmovaps xmm11, [rsp+0xB0]
000076e4393d08cf  vmovaps xmm12, [rsp+0xC0]
000076e4393d08d8  vmovaps xmm14, [rsp+0xD0]
000076e4393d08e1  vmovaps xmm15, [rsp+0xE0]
000076e4393d08ea  add rsp, 0xF0
000076e4393d08f1  pop r11
000076e4393d08f3  pop r10
000076e4393d08f5  pop r9
000076e4393d08f7  pop r8
000076e4393d08f9  pop rsi
000076e4393d08fa  pop rdi
000076e4393d08fb  pop rdx
000076e4393d08fc  pop rcx
000076e4393d08fd  pop rax
000076e4393d08fe  add rsp, 0x08
000076e4393d0902  jmp 0x000076E4393CF5CF
000076e4393d0907  sub rsp, 0x08
000076e4393d090b  push rax
000076e4393d090c  push rcx
000076e4393d090d  push rdx
000076e4393d090e  push rdi
000076e4393d090f  push rsi
000076e4393d0910  push r8
000076e4393d0912  push r9
000076e4393d0914  push r10
000076e4393d0916  push r11
000076e4393d0918  sub rsp, 0xF0
000076e4393d091f  vmovaps [rsp], xmm0
000076e4393d0924  vmovaps [rsp+0x10], xmm1
000076e4393d092a  vmovaps [rsp+0x20], xmm2
000076e4393d0930  vmovaps [rsp+0x30], xmm3
000076e4393d0936  vmovaps [rsp+0x40], xmm4
000076e4393d093c  vmovaps [rsp+0x50], xmm5
000076e4393d0942  vmovaps [rsp+0x60], xmm6
000076e4393d0948  vmovaps [rsp+0x70], xmm7
000076e4393d094e  vmovaps [rsp+0x80], xmm8
000076e4393d0957  vmovaps [rsp+0x90], xmm9
000076e4393d0960  vmovaps [rsp+0xA0], xmm10
000076e4393d0969  vmovaps [rsp+0xB0], xmm11
000076e4393d0972  vmovaps [rsp+0xC0], xmm12
000076e4393d097b  vmovaps [rsp+0xD0], xmm13
000076e4393d0984  vmovaps [rsp+0xE0], xmm14
000076e4393d098d  sub rsp, 0x30
000076e4393d0991  movaps [rsp], xmm15
000076e4393d0996  movaps [rsp+0x10], xmm14
000076e4393d099c  movaps [rsp+0x20], xmm1
000076e4393d09a1  lea rdi, [rsp]
000076e4393d09a5  mov esi, 0x00
000076e4393d09aa  mov rax, 0x63DBDEB43530
000076e4393d09b4  call rax
000076e4393d09b6  movaps xmm15, [rsp]
000076e4393d09bb  add rsp, 0x30
000076e4393d09bf  vmovaps xmm0, [rsp]
000076e4393d09c4  vmovaps xmm1, [rsp+0x10]
000076e4393d09ca  vmovaps xmm2, [rsp+0x20]
000076e4393d09d0  vmovaps xmm3, [rsp+0x30]
000076e4393d09d6  vmovaps xmm4, [rsp+0x40]
000076e4393d09dc  vmovaps xmm5, [rsp+0x50]
000076e4393d09e2  vmovaps xmm6, [rsp+0x60]
000076e4393d09e8  vmovaps xmm7, [rsp+0x70]
000076e4393d09ee  vmovaps xmm8, [rsp+0x80]
000076e4393d09f7  vmovaps xmm9, [rsp+0x90]
000076e4393d0a00  vmovaps xmm10, [rsp+0xA0]
000076e4393d0a09  vmovaps xmm11, [rsp+0xB0]
000076e4393d0a12  vmovaps xmm12, [rsp+0xC0]
000076e4393d0a1b  vmovaps xmm13, [rsp+0xD0]
000076e4393d0a24  vmovaps xmm14, [rsp+0xE0]
000076e4393d0a2d  add rsp, 0xF0
000076e4393d0a34  pop r11
000076e4393d0a36  pop r10
000076e4393d0a38  pop r9
000076e4393d0a3a  pop r8
000076e4393d0a3c  pop rsi
000076e4393d0a3d  pop rdi
000076e4393d0a3e  pop rdx
000076e4393d0a3f  pop rcx
000076e4393d0a40  pop rax
000076e4393d0a41  add rsp, 0x08
000076e4393d0a45  jmp 0x000076E4393CF617
000076e4393d0a4a  sub rsp, 0x08
000076e4393d0a4e  push rax
000076e4393d0a4f  push rcx
000076e4393d0a50  push rdx
000076e4393d0a51  push rdi
000076e4393d0a52  push rsi
000076e4393d0a53  push r8
000076e4393d0a55  push r9
000076e4393d0a57  push r10
000076e4393d0a59  push r11
000076e4393d0a5b  sub rsp, 0xF0
000076e4393d0a62  vmovaps [rsp], xmm0
000076e4393d0a67  vmovaps [rsp+0x10], xmm2
000076e4393d0a6d  vmovaps [rsp+0x20], xmm3
000076e4393d0a73  vmovaps [rsp+0x30], xmm4
000076e4393d0a79  vmovaps [rsp+0x40], xmm5
000076e4393d0a7f  vmovaps [rsp+0x50], xmm6
000076e4393d0a85  vmovaps [rsp+0x60], xmm7
000076e4393d0a8b  vmovaps [rsp+0x70], xmm8
000076e4393d0a91  vmovaps [rsp+0x80], xmm9
000076e4393d0a9a  vmovaps [rsp+0x90], xmm10
000076e4393d0aa3  vmovaps [rsp+0xA0], xmm11
000076e4393d0aac  vmovaps [rsp+0xB0], xmm12
000076e4393d0ab5  vmovaps [rsp+0xC0], xmm13
000076e4393d0abe  vmovaps [rsp+0xD0], xmm14
000076e4393d0ac7  vmovaps [rsp+0xE0], xmm15
000076e4393d0ad0  sub rsp, 0x30
000076e4393d0ad4  movaps [rsp], xmm1
000076e4393d0ad8  movaps [rsp+0x10], xmm14
000076e4393d0ade  movaps [rsp+0x20], xmm10
000076e4393d0ae4  lea rdi, [rsp]
000076e4393d0ae8  mov esi, 0x00
000076e4393d0aed  mov rax, 0x63DBDEB43530
000076e4393d0af7  call rax
000076e4393d0af9  movaps xmm1, [rsp]
000076e4393d0afd  add rsp, 0x30
000076e4393d0b01  vmovaps xmm0, [rsp]
000076e4393d0b06  vmovaps xmm2, [rsp+0x10]
000076e4393d0b0c  vmovaps xmm3, [rsp+0x20]
000076e4393d0b12  vmovaps xmm4, [rsp+0x30]
000076e4393d0b18  vmovaps xmm5, [rsp+0x40]
000076e4393d0b1e  vmovaps xmm6, [rsp+0x50]
000076e4393d0b24  vmovaps xmm7, [rsp+0x60]
000076e4393d0b2a  vmovaps xmm8, [rsp+0x70]
000076e4393d0b30  vmovaps xmm9, [rsp+0x80]
000076e4393d0b39  vmovaps xmm10, [rsp+0x90]
000076e4393d0b42  vmovaps xmm11, [rsp+0xA0]
000076e4393d0b4b  vmovaps xmm12, [rsp+0xB0]
000076e4393d0b54  vmovaps xmm13, [rsp+0xC0]
000076e4393d0b5d  vmovaps xmm14, [rsp+0xD0]
000076e4393d0b66  vmovaps xmm15, [rsp+0xE0]
000076e4393d0b6f  add rsp, 0xF0
000076e4393d0b76  pop r11
000076e4393d0b78  pop r10
000076e4393d0b7a  pop r9
000076e4393d0b7c  pop r8
000076e4393d0b7e  pop rsi
000076e4393d0b7f  pop rdi
000076e4393d0b80  pop rdx
000076e4393d0b81  pop rcx
000076e4393d0b82  pop rax
000076e4393d0b83  add rsp, 0x08
000076e4393d0b87  jmp 0x000076E4393CF631
000076e4393d0b8c  sub rsp, 0x08
000076e4393d0b90  push rax
000076e4393d0b91  push rcx
000076e4393d0b92  push rdx
000076e4393d0b93  push rdi
000076e4393d0b94  push rsi
000076e4393d0b95  push r8
000076e4393d0b97  push r9
000076e4393d0b99  push r10
000076e4393d0b9b  push r11
000076e4393d0b9d  sub rsp, 0xF0
000076e4393d0ba4  vmovaps [rsp], xmm0
000076e4393d0ba9  vmovaps [rsp+0x10], xmm1
000076e4393d0baf  vmovaps [rsp+0x20], xmm2
000076e4393d0bb5  vmovaps [rsp+0x30], xmm3
000076e4393d0bbb  vmovaps [rsp+0x40], xmm4
000076e4393d0bc1  vmovaps [rsp+0x50], xmm5
000076e4393d0bc7  vmovaps [rsp+0x60], xmm6
000076e4393d0bcd  vmovaps [rsp+0x70], xmm7
000076e4393d0bd3  vmovaps [rsp+0x80], xmm8
000076e4393d0bdc  vmovaps [rsp+0x90], xmm9
000076e4393d0be5  vmovaps [rsp+0xA0], xmm10
000076e4393d0bee  vmovaps [rsp+0xB0], xmm11
000076e4393d0bf7  vmovaps [rsp+0xC0], xmm12
000076e4393d0c00  vmovaps [rsp+0xD0], xmm14
000076e4393d0c09  vmovaps [rsp+0xE0], xmm15
000076e4393d0c12  sub rsp, 0x30
000076e4393d0c16  movaps [rsp], xmm13
000076e4393d0c1b  movaps [rsp+0x10], xmm14
000076e4393d0c21  movaps [rsp+0x20], xmm2
000076e4393d0c26  lea rdi, [rsp]
000076e4393d0c2a  mov esi, 0x00
000076e4393d0c2f  mov rax, 0x63DBDEB43530
000076e4393d0c39  call rax
000076e4393d0c3b  movaps xmm13, [rsp]
000076e4393d0c40  add rsp, 0x30
000076e4393d0c44  vmovaps xmm0, [rsp]
000076e4393d0c49  vmovaps xmm1, [rsp+0x10]
000076e4393d0c4f  vmovaps xmm2, [rsp+0x20]
000076e4393d0c55  vmovaps xmm3, [rsp+0x30]
000076e4393d0c5b  vmovaps xmm4, [rsp+0x40]
000076e4393d0c61  vmovaps xmm5, [rsp+0x50]
000076e4393d0c67  vmovaps xmm6, [rsp+0x60]
000076e4393d0c6d  vmovaps xmm7, [rsp+0x70]
000076e4393d0c73  vmovaps xmm8, [rsp+0x80]
000076e4393d0c7c  vmovaps xmm9, [rsp+0x90]
000076e4393d0c85  vmovaps xmm10, [rsp+0xA0]
000076e4393d0c8e  vmovaps xmm11, [rsp+0xB0]
000076e4393d0c97  vmovaps xmm12, [rsp+0xC0]
000076e4393d0ca0  vmovaps xmm14, [rsp+0xD0]
000076e4393d0ca9  vmovaps xmm15, [rsp+0xE0]
000076e4393d0cb2  add rsp, 0xF0
000076e4393d0cb9  pop r11
000076e4393d0cbb  pop r10
000076e4393d0cbd  pop r9
000076e4393d0cbf  pop r8
000076e4393d0cc1  pop rsi
000076e4393d0cc2  pop rdi
000076e4393d0cc3  pop rdx
000076e4393d0cc4  pop rcx
000076e4393d0cc5  pop rax
000076e4393d0cc6  add rsp, 0x08
000076e4393d0cca  jmp 0x000076E4393CF64C
000076e4393d0ccf  sub rsp, 0x08
000076e4393d0cd3  push rax
000076e4393d0cd4  push rcx
000076e4393d0cd5  push rdx
000076e4393d0cd6  push rdi
000076e4393d0cd7  push rsi
000076e4393d0cd8  push r8
000076e4393d0cda  push r9
000076e4393d0cdc  push r10
000076e4393d0cde  push r11
000076e4393d0ce0  sub rsp, 0xF0
000076e4393d0ce7  vmovaps [rsp], xmm0
000076e4393d0cec  vmovaps [rsp+0x10], xmm2
000076e4393d0cf2  vmovaps [rsp+0x20], xmm3
000076e4393d0cf8  vmovaps [rsp+0x30], xmm4
000076e4393d0cfe  vmovaps [rsp+0x40], xmm5
000076e4393d0d04  vmovaps [rsp+0x50], xmm6
000076e4393d0d0a  vmovaps [rsp+0x60], xmm7
000076e4393d0d10  vmovaps [rsp+0x70], xmm8
000076e4393d0d16  vmovaps [rsp+0x80], xmm9
000076e4393d0d1f  vmovaps [rsp+0x90], xmm10
000076e4393d0d28  vmovaps [rsp+0xA0], xmm11
000076e4393d0d31  vmovaps [rsp+0xB0], xmm12
000076e4393d0d3a  vmovaps [rsp+0xC0], xmm13
000076e4393d0d43  vmovaps [rsp+0xD0], xmm14
000076e4393d0d4c  vmovaps [rsp+0xE0], xmm15
000076e4393d0d55  sub rsp, 0x30
000076e4393d0d59  movaps [rsp], xmm1
000076e4393d0d5d  movaps [rsp+0x10], xmm10
000076e4393d0d63  movaps [rsp+0x20], xmm2
000076e4393d0d68  lea rdi, [rsp]
000076e4393d0d6c  mov esi, 0x00
000076e4393d0d71  mov rax, 0x63DBDEB43530
000076e4393d0d7b  call rax
000076e4393d0d7d  movaps xmm1, [rsp]
000076e4393d0d81  add rsp, 0x30
000076e4393d0d85  vmovaps xmm0, [rsp]
000076e4393d0d8a  vmovaps xmm2, [rsp+0x10]
000076e4393d0d90  vmovaps xmm3, [rsp+0x20]
000076e4393d0d96  vmovaps xmm4, [rsp+0x30]
000076e4393d0d9c  vmovaps xmm5, [rsp+0x40]
000076e4393d0da2  vmovaps xmm6, [rsp+0x50]
000076e4393d0da8  vmovaps xmm7, [rsp+0x60]
000076e4393d0dae  vmovaps xmm8, [rsp+0x70]
000076e4393d0db4  vmovaps xmm9, [rsp+0x80]
000076e4393d0dbd  vmovaps xmm10, [rsp+0x90]
000076e4393d0dc6  vmovaps xmm11, [rsp+0xA0]
000076e4393d0dcf  vmovaps xmm12, [rsp+0xB0]
000076e4393d0dd8  vmovaps xmm13, [rsp+0xC0]
000076e4393d0de1  vmovaps xmm14, [rsp+0xD0]
000076e4393d0dea  vmovaps xmm15, [rsp+0xE0]
000076e4393d0df3  add rsp, 0xF0
000076e4393d0dfa  pop r11
000076e4393d0dfc  pop r10
000076e4393d0dfe  pop r9
000076e4393d0e00  pop r8
000076e4393d0e02  pop rsi
000076e4393d0e03  pop rdi
000076e4393d0e04  pop rdx
000076e4393d0e05  pop rcx
000076e4393d0e06  pop rax
000076e4393d0e07  add rsp, 0x08
000076e4393d0e0b  jmp 0x000076E4393CF6B4
000076e4393d0e10  sub rsp, 0x08
000076e4393d0e14  push rax
000076e4393d0e15  push rcx
000076e4393d0e16  push rdx
000076e4393d0e17  push rdi
000076e4393d0e18  push rsi
000076e4393d0e19  push r8
000076e4393d0e1b  push r9
000076e4393d0e1d  push r10
000076e4393d0e1f  push r11
000076e4393d0e21  sub rsp, 0xF0
000076e4393d0e28  vmovaps [rsp], xmm0
000076e4393d0e2d  vmovaps [rsp+0x10], xmm1
000076e4393d0e33  vmovaps [rsp+0x20], xmm2
000076e4393d0e39  vmovaps [rsp+0x30], xmm3
000076e4393d0e3f  vmovaps [rsp+0x40], xmm4
000076e4393d0e45  vmovaps [rsp+0x50], xmm5
000076e4393d0e4b  vmovaps [rsp+0x60], xmm6
000076e4393d0e51  vmovaps [rsp+0x70], xmm7
000076e4393d0e57  vmovaps [rsp+0x80], xmm8
000076e4393d0e60  vmovaps [rsp+0x90], xmm9
000076e4393d0e69  vmovaps [rsp+0xA0], xmm10
000076e4393d0e72  vmovaps [rsp+0xB0], xmm11
000076e4393d0e7b  vmovaps [rsp+0xC0], xmm12
000076e4393d0e84  vmovaps [rsp+0xD0], xmm13
000076e4393d0e8d  vmovaps [rsp+0xE0], xmm14
000076e4393d0e96  sub rsp, 0x30
000076e4393d0e9a  movaps [rsp], xmm15
000076e4393d0e9f  movaps [rsp+0x10], xmm10
000076e4393d0ea5  movaps [rsp+0x20], xmm2
000076e4393d0eaa  lea rdi, [rsp]
000076e4393d0eae  mov esi, 0x00
000076e4393d0eb3  mov rax, 0x63DBDEB43530
000076e4393d0ebd  call rax
000076e4393d0ebf  movaps xmm15, [rsp]
000076e4393d0ec4  add rsp, 0x30
000076e4393d0ec8  vmovaps xmm0, [rsp]
000076e4393d0ecd  vmovaps xmm1, [rsp+0x10]
000076e4393d0ed3  vmovaps xmm2, [rsp+0x20]
000076e4393d0ed9  vmovaps xmm3, [rsp+0x30]
000076e4393d0edf  vmovaps xmm4, [rsp+0x40]
000076e4393d0ee5  vmovaps xmm5, [rsp+0x50]
000076e4393d0eeb  vmovaps xmm6, [rsp+0x60]
000076e4393d0ef1  vmovaps xmm7, [rsp+0x70]
000076e4393d0ef7  vmovaps xmm8, [rsp+0x80]
000076e4393d0f00  vmovaps xmm9, [rsp+0x90]
000076e4393d0f09  vmovaps xmm10, [rsp+0xA0]
000076e4393d0f12  vmovaps xmm11, [rsp+0xB0]
000076e4393d0f1b  vmovaps xmm12, [rsp+0xC0]
000076e4393d0f24  vmovaps xmm13, [rsp+0xD0]
000076e4393d0f2d  vmovaps xmm14, [rsp+0xE0]
000076e4393d0f36  add rsp, 0xF0
000076e4393d0f3d  pop r11
000076e4393d0f3f  pop r10
000076e4393d0f41  pop r9
000076e4393d0f43  pop r8
000076e4393d0f45  pop rsi
000076e4393d0f46  pop rdi
000076e4393d0f47  pop rdx
000076e4393d0f48  pop rcx
000076e4393d0f49  pop rax
000076e4393d0f4a  add rsp, 0x08
000076e4393d0f4e  jmp 0x000076E4393CF706
000076e4393d0f53  sub rsp, 0x08
000076e4393d0f57  push rax
000076e4393d0f58  push rcx
000076e4393d0f59  push rdx
000076e4393d0f5a  push rdi
000076e4393d0f5b  push rsi
000076e4393d0f5c  push r8
000076e4393d0f5e  push r9
000076e4393d0f60  push r10
000076e4393d0f62  push r11
000076e4393d0f64  sub rsp, 0xF0
000076e4393d0f6b  vmovaps [rsp], xmm0
000076e4393d0f70  vmovaps [rsp+0x10], xmm2
000076e4393d0f76  vmovaps [rsp+0x20], xmm3
000076e4393d0f7c  vmovaps [rsp+0x30], xmm4
000076e4393d0f82  vmovaps [rsp+0x40], xmm5
000076e4393d0f88  vmovaps [rsp+0x50], xmm6
000076e4393d0f8e  vmovaps [rsp+0x60], xmm7
000076e4393d0f94  vmovaps [rsp+0x70], xmm8
000076e4393d0f9a  vmovaps [rsp+0x80], xmm9
000076e4393d0fa3  vmovaps [rsp+0x90], xmm10
000076e4393d0fac  vmovaps [rsp+0xA0], xmm11
000076e4393d0fb5  vmovaps [rsp+0xB0], xmm12
000076e4393d0fbe  vmovaps [rsp+0xC0], xmm13
000076e4393d0fc7  vmovaps [rsp+0xD0], xmm14
000076e4393d0fd0  vmovaps [rsp+0xE0], xmm15
000076e4393d0fd9  sub rsp, 0x30
000076e4393d0fdd  movaps [rsp], xmm1
000076e4393d0fe1  movaps [rsp+0x10], xmm10
000076e4393d0fe7  movaps [rsp+0x20], xmm12
000076e4393d0fed  lea rdi, [rsp]
000076e4393d0ff1  mov esi, 0x00
000076e4393d0ff6  mov rax, 0x63DBDEB43530
000076e4393d1000  call rax
000076e4393d1002  movaps xmm1, [rsp]
000076e4393d1006  add rsp, 0x30
000076e4393d100a  vmovaps xmm0, [rsp]
000076e4393d100f  vmovaps xmm2, [rsp+0x10]
000076e4393d1015  vmovaps xmm3, [rsp+0x20]
000076e4393d101b  vmovaps xmm4, [rsp+0x30]
000076e4393d1021  vmovaps xmm5, [rsp+0x40]
000076e4393d1027  vmovaps xmm6, [rsp+0x50]
000076e4393d102d  vmovaps xmm7, [rsp+0x60]
000076e4393d1033  vmovaps xmm8, [rsp+0x70]
000076e4393d1039  vmovaps xmm9, [rsp+0x80]
000076e4393d1042  vmovaps xmm10, [rsp+0x90]
000076e4393d104b  vmovaps xmm11, [rsp+0xA0]
000076e4393d1054  vmovaps xmm12, [rsp+0xB0]
000076e4393d105d  vmovaps xmm13, [rsp+0xC0]
000076e4393d1066  vmovaps xmm14, [rsp+0xD0]
000076e4393d106f  vmovaps xmm15, [rsp+0xE0]
000076e4393d1078  add rsp, 0xF0
000076e4393d107f  pop r11
000076e4393d1081  pop r10
000076e4393d1083  pop r9
000076e4393d1085  pop r8
000076e4393d1087  pop rsi
000076e4393d1088  pop rdi
000076e4393d1089  pop rdx
000076e4393d108a  pop rcx
000076e4393d108b  pop rax
000076e4393d108c  add rsp, 0x08
000076e4393d1090  jmp 0x000076E4393CF732
000076e4393d1095  sub rsp, 0x08
000076e4393d1099  push rax
000076e4393d109a  push rcx
000076e4393d109b  push rdx
000076e4393d109c  push rdi
000076e4393d109d  push rsi
000076e4393d109e  push r8
000076e4393d10a0  push r9
000076e4393d10a2  push r10
000076e4393d10a4  push r11
000076e4393d10a6  sub rsp, 0xF0
000076e4393d10ad  vmovaps [rsp], xmm0
000076e4393d10b2  vmovaps [rsp+0x10], xmm1
000076e4393d10b8  vmovaps [rsp+0x20], xmm2
000076e4393d10be  vmovaps [rsp+0x30], xmm3
000076e4393d10c4  vmovaps [rsp+0x40], xmm4
000076e4393d10ca  vmovaps [rsp+0x50], xmm5
000076e4393d10d0  vmovaps [rsp+0x60], xmm6
000076e4393d10d6  vmovaps [rsp+0x70], xmm7
000076e4393d10dc  vmovaps [rsp+0x80], xmm8
000076e4393d10e5  vmovaps [rsp+0x90], xmm9
000076e4393d10ee  vmovaps [rsp+0xA0], xmm10
000076e4393d10f7  vmovaps [rsp+0xB0], xmm11
000076e4393d1100  vmovaps [rsp+0xC0], xmm12
000076e4393d1109  vmovaps [rsp+0xD0], xmm13
000076e4393d1112  vmovaps [rsp+0xE0], xmm14
000076e4393d111b  sub rsp, 0x30
000076e4393d111f  movaps [rsp], xmm15
000076e4393d1124  movaps [rsp+0x10], xmm10
000076e4393d112a  movaps [rsp+0x20], xmm12
000076e4393d1130  lea rdi, [rsp]
000076e4393d1134  mov esi, 0x00
000076e4393d1139  mov rax, 0x63DBDEB43530
000076e4393d1143  call rax
000076e4393d1145  movaps xmm15, [rsp]
000076e4393d114a  add rsp, 0x30
000076e4393d114e  vmovaps xmm0, [rsp]
000076e4393d1153  vmovaps xmm1, [rsp+0x10]
000076e4393d1159  vmovaps xmm2, [rsp+0x20]
000076e4393d115f  vmovaps xmm3, [rsp+0x30]
000076e4393d1165  vmovaps xmm4, [rsp+0x40]
000076e4393d116b  vmovaps xmm5, [rsp+0x50]
000076e4393d1171  vmovaps xmm6, [rsp+0x60]
000076e4393d1177  vmovaps xmm7, [rsp+0x70]
000076e4393d117d  vmovaps xmm8, [rsp+0x80]
000076e4393d1186  vmovaps xmm9, [rsp+0x90]
000076e4393d118f  vmovaps xmm10, [rsp+0xA0]
000076e4393d1198  vmovaps xmm11, [rsp+0xB0]
000076e4393d11a1  vmovaps xmm12, [rsp+0xC0]
000076e4393d11aa  vmovaps xmm13, [rsp+0xD0]
000076e4393d11b3  vmovaps xmm14, [rsp+0xE0]
000076e4393d11bc  add rsp, 0xF0
000076e4393d11c3  pop r11
000076e4393d11c5  pop r10
000076e4393d11c7  pop r9
000076e4393d11c9  pop r8
000076e4393d11cb  pop rsi
000076e4393d11cc  pop rdi
000076e4393d11cd  pop rdx
000076e4393d11ce  pop rcx
000076e4393d11cf  pop rax
000076e4393d11d0  add rsp, 0x08
000076e4393d11d4  jmp 0x000076E4393CF75E
000076e4393d11d9  call 0x000076E4391FF430
000076e4393d11de  jmp 0x000076E4393CF7EE
000076e4393d11e3  call 0x000076E4391FF430
000076e4393d11e8  jmp 0x000076E4393CF801
000076e4393d11ed  sub rsp, 0x08
000076e4393d11f1  push rax
000076e4393d11f2  push rcx
000076e4393d11f3  push rdx
000076e4393d11f4  push rdi
000076e4393d11f5  push rsi
000076e4393d11f6  push r8
000076e4393d11f8  push r9
000076e4393d11fa  push r10
000076e4393d11fc  push r11
000076e4393d11fe  sub rsp, 0xF0
000076e4393d1205  vmovaps [rsp], xmm0
000076e4393d120a  vmovaps [rsp+0x10], xmm2
000076e4393d1210  vmovaps [rsp+0x20], xmm3
000076e4393d1216  vmovaps [rsp+0x30], xmm4
000076e4393d121c  vmovaps [rsp+0x40], xmm5
000076e4393d1222  vmovaps [rsp+0x50], xmm6
000076e4393d1228  vmovaps [rsp+0x60], xmm7
000076e4393d122e  vmovaps [rsp+0x70], xmm8
000076e4393d1234  vmovaps [rsp+0x80], xmm9
000076e4393d123d  vmovaps [rsp+0x90], xmm10
000076e4393d1246  vmovaps [rsp+0xA0], xmm11
000076e4393d124f  vmovaps [rsp+0xB0], xmm12
000076e4393d1258  vmovaps [rsp+0xC0], xmm13
000076e4393d1261  vmovaps [rsp+0xD0], xmm14
000076e4393d126a  vmovaps [rsp+0xE0], xmm15
000076e4393d1273  sub rsp, 0x30
000076e4393d1277  movaps [rsp], xmm1
000076e4393d127b  movaps [rsp+0x10], xmm13
000076e4393d1281  movaps [rsp+0x20], xmm2
000076e4393d1286  lea rdi, [rsp]
000076e4393d128a  mov esi, 0x00
000076e4393d128f  mov rax, 0x63DBDEB43530
000076e4393d1299  call rax
000076e4393d129b  movaps xmm1, [rsp]
000076e4393d129f  add rsp, 0x30
000076e4393d12a3  vmovaps xmm0, [rsp]
000076e4393d12a8  vmovaps xmm2, [rsp+0x10]
000076e4393d12ae  vmovaps xmm3, [rsp+0x20]
000076e4393d12b4  vmovaps xmm4, [rsp+0x30]
000076e4393d12ba  vmovaps xmm5, [rsp+0x40]
000076e4393d12c0  vmovaps xmm6, [rsp+0x50]
000076e4393d12c6  vmovaps xmm7, [rsp+0x60]
000076e4393d12cc  vmovaps xmm8, [rsp+0x70]
000076e4393d12d2  vmovaps xmm9, [rsp+0x80]
000076e4393d12db  vmovaps xmm10, [rsp+0x90]
000076e4393d12e4  vmovaps xmm11, [rsp+0xA0]
000076e4393d12ed  vmovaps xmm12, [rsp+0xB0]
000076e4393d12f6  vmovaps xmm13, [rsp+0xC0]
000076e4393d12ff  vmovaps xmm14, [rsp+0xD0]
000076e4393d1308  vmovaps xmm15, [rsp+0xE0]
000076e4393d1311  add rsp, 0xF0
000076e4393d1318  pop r11
000076e4393d131a  pop r10
000076e4393d131c  pop r9
000076e4393d131e  pop r8
000076e4393d1320  pop rsi
000076e4393d1321  pop rdi
000076e4393d1322  pop rdx
000076e4393d1323  pop rcx
000076e4393d1324  pop rax
000076e4393d1325  add rsp, 0x08
000076e4393d1329  jmp 0x000076E4393CF82C
000076e4393d132e  call 0x000076E43920E760
000076e4393d1333  jmp 0x000076E4393CF839
000076e4393d1338  sub rsp, 0x08
000076e4393d133c  push rax
000076e4393d133d  push rcx
000076e4393d133e  push rdx
000076e4393d133f  push rdi
000076e4393d1340  push rsi
000076e4393d1341  push r8
000076e4393d1343  push r9
000076e4393d1345  push r10
000076e4393d1347  push r11
000076e4393d1349  sub rsp, 0xF0
000076e4393d1350  vmovaps [rsp], xmm0
000076e4393d1355  vmovaps [rsp+0x10], xmm1
000076e4393d135b  vmovaps [rsp+0x20], xmm2
000076e4393d1361  vmovaps [rsp+0x30], xmm3
000076e4393d1367  vmovaps [rsp+0x40], xmm4
000076e4393d136d  vmovaps [rsp+0x50], xmm5
000076e4393d1373  vmovaps [rsp+0x60], xmm6
000076e4393d1379  vmovaps [rsp+0x70], xmm7
000076e4393d137f  vmovaps [rsp+0x80], xmm8
000076e4393d1388  vmovaps [rsp+0x90], xmm9
000076e4393d1391  vmovaps [rsp+0xA0], xmm10
000076e4393d139a  vmovaps [rsp+0xB0], xmm11
000076e4393d13a3  vmovaps [rsp+0xC0], xmm12
000076e4393d13ac  vmovaps [rsp+0xD0], xmm14
000076e4393d13b5  vmovaps [rsp+0xE0], xmm15
000076e4393d13be  sub rsp, 0x30
000076e4393d13c2  movaps [rsp], xmm13
000076e4393d13c7  movaps [rsp+0x10], xmm2
000076e4393d13cc  movaps [rsp+0x20], xmm1
000076e4393d13d1  lea rdi, [rsp]
000076e4393d13d5  mov esi, 0x00
000076e4393d13da  mov rax, 0x63DBDEB43530
000076e4393d13e4  call rax
000076e4393d13e6  movaps xmm13, [rsp]
000076e4393d13eb  add rsp, 0x30
000076e4393d13ef  vmovaps xmm0, [rsp]
000076e4393d13f4  vmovaps xmm1, [rsp+0x10]
000076e4393d13fa  vmovaps xmm2, [rsp+0x20]
000076e4393d1400  vmovaps xmm3, [rsp+0x30]
000076e4393d1406  vmovaps xmm4, [rsp+0x40]
000076e4393d140c  vmovaps xmm5, [rsp+0x50]
000076e4393d1412  vmovaps xmm6, [rsp+0x60]
000076e4393d1418  vmovaps xmm7, [rsp+0x70]
000076e4393d141e  vmovaps xmm8, [rsp+0x80]
000076e4393d1427  vmovaps xmm9, [rsp+0x90]
000076e4393d1430  vmovaps xmm10, [rsp+0xA0]
000076e4393d1439  vmovaps xmm11, [rsp+0xB0]
000076e4393d1442  vmovaps xmm12, [rsp+0xC0]
000076e4393d144b  vmovaps xmm14, [rsp+0xD0]
000076e4393d1454  vmovaps xmm15, [rsp+0xE0]
000076e4393d145d  add rsp, 0xF0
000076e4393d1464  pop r11
000076e4393d1466  pop r10
000076e4393d1468  pop r9
000076e4393d146a  pop r8
000076e4393d146c  pop rsi
000076e4393d146d  pop rdi
000076e4393d146e  pop rdx
000076e4393d146f  pop rcx
000076e4393d1470  pop rax
000076e4393d1471  add rsp, 0x08
000076e4393d1475  jmp 0x000076E4393CF878
000076e4393d147a  sub rsp, 0x08
000076e4393d147e  push rax
000076e4393d147f  push rcx
000076e4393d1480  push rdx
000076e4393d1481  push rdi
000076e4393d1482  push rsi
000076e4393d1483  push r8
000076e4393d1485  push r9
000076e4393d1487  push r10
000076e4393d1489  push r11
000076e4393d148b  sub rsp, 0xF0
000076e4393d1492  vmovaps [rsp], xmm0
000076e4393d1497  vmovaps [rsp+0x10], xmm2
000076e4393d149d  vmovaps [rsp+0x20], xmm3
000076e4393d14a3  vmovaps [rsp+0x30], xmm4
000076e4393d14a9  vmovaps [rsp+0x40], xmm5
000076e4393d14af  vmovaps [rsp+0x50], xmm6
000076e4393d14b5  vmovaps [rsp+0x60], xmm7
000076e4393d14bb  vmovaps [rsp+0x70], xmm8
000076e4393d14c1  vmovaps [rsp+0x80], xmm9
000076e4393d14ca  vmovaps [rsp+0x90], xmm10
000076e4393d14d3  vmovaps [rsp+0xA0], xmm11
000076e4393d14dc  vmovaps [rsp+0xB0], xmm12
000076e4393d14e5  vmovaps [rsp+0xC0], xmm13
000076e4393d14ee  vmovaps [rsp+0xD0], xmm14
000076e4393d14f7  vmovaps [rsp+0xE0], xmm15
000076e4393d1500  sub rsp, 0x30
000076e4393d1504  movaps [rsp], xmm1
000076e4393d1508  movaps [rsp+0x10], xmm15
000076e4393d150e  movaps [rsp+0x20], xmm2
000076e4393d1513  lea rdi, [rsp]
000076e4393d1517  mov esi, 0x00
000076e4393d151c  mov rax, 0x63DBDEB43530
000076e4393d1526  call rax
000076e4393d1528  movaps xmm1, [rsp]
000076e4393d152c  add rsp, 0x30
000076e4393d1530  vmovaps xmm0, [rsp]
000076e4393d1535  vmovaps xmm2, [rsp+0x10]
000076e4393d153b  vmovaps xmm3, [rsp+0x20]
000076e4393d1541  vmovaps xmm4, [rsp+0x30]
000076e4393d1547  vmovaps xmm5, [rsp+0x40]
000076e4393d154d  vmovaps xmm6, [rsp+0x50]
000076e4393d1553  vmovaps xmm7, [rsp+0x60]
000076e4393d1559  vmovaps xmm8, [rsp+0x70]
000076e4393d155f  vmovaps xmm9, [rsp+0x80]
000076e4393d1568  vmovaps xmm10, [rsp+0x90]
000076e4393d1571  vmovaps xmm11, [rsp+0xA0]
000076e4393d157a  vmovaps xmm12, [rsp+0xB0]
000076e4393d1583  vmovaps xmm13, [rsp+0xC0]
000076e4393d158c  vmovaps xmm14, [rsp+0xD0]
000076e4393d1595  vmovaps xmm15, [rsp+0xE0]
000076e4393d159e  add rsp, 0xF0
000076e4393d15a5  pop r11
000076e4393d15a7  pop r10
000076e4393d15a9  pop r9
000076e4393d15ab  pop r8
000076e4393d15ad  pop rsi
000076e4393d15ae  pop rdi
000076e4393d15af  pop rdx
000076e4393d15b0  pop rcx
000076e4393d15b1  pop rax
000076e4393d15b2  add rsp, 0x08
000076e4393d15b6  jmp 0x000076E4393CF8AC
000076e4393d15bb  sub rsp, 0x08
000076e4393d15bf  push rax
000076e4393d15c0  push rcx
000076e4393d15c1  push rdx
000076e4393d15c2  push rdi
000076e4393d15c3  push rsi
000076e4393d15c4  push r8
000076e4393d15c6  push r9
000076e4393d15c8  push r10
000076e4393d15ca  push r11
000076e4393d15cc  sub rsp, 0xF0
000076e4393d15d3  vmovaps [rsp], xmm0
000076e4393d15d8  vmovaps [rsp+0x10], xmm1
000076e4393d15de  vmovaps [rsp+0x20], xmm2
000076e4393d15e4  vmovaps [rsp+0x30], xmm3
000076e4393d15ea  vmovaps [rsp+0x40], xmm4
000076e4393d15f0  vmovaps [rsp+0x50], xmm5
000076e4393d15f6  vmovaps [rsp+0x60], xmm6
000076e4393d15fc  vmovaps [rsp+0x70], xmm7
000076e4393d1602  vmovaps [rsp+0x80], xmm8
000076e4393d160b  vmovaps [rsp+0x90], xmm9
000076e4393d1614  vmovaps [rsp+0xA0], xmm10
000076e4393d161d  vmovaps [rsp+0xB0], xmm11
000076e4393d1626  vmovaps [rsp+0xC0], xmm12
000076e4393d162f  vmovaps [rsp+0xD0], xmm13
000076e4393d1638  vmovaps [rsp+0xE0], xmm15
000076e4393d1641  sub rsp, 0x30
000076e4393d1645  movaps [rsp], xmm14
000076e4393d164a  movaps [rsp+0x10], xmm2
000076e4393d164f  movaps [rsp+0x20], xmm15
000076e4393d1655  lea rdi, [rsp]
000076e4393d1659  mov esi, 0x00
000076e4393d165e  mov rax, 0x63DBDEB43530
000076e4393d1668  call rax
000076e4393d166a  movaps xmm14, [rsp]
000076e4393d166f  add rsp, 0x30
000076e4393d1673  vmovaps xmm0, [rsp]
000076e4393d1678  vmovaps xmm1, [rsp+0x10]
000076e4393d167e  vmovaps xmm2, [rsp+0x20]
000076e4393d1684  vmovaps xmm3, [rsp+0x30]
000076e4393d168a  vmovaps xmm4, [rsp+0x40]
000076e4393d1690  vmovaps xmm5, [rsp+0x50]
000076e4393d1696  vmovaps xmm6, [rsp+0x60]
000076e4393d169c  vmovaps xmm7, [rsp+0x70]
000076e4393d16a2  vmovaps xmm8, [rsp+0x80]
000076e4393d16ab  vmovaps xmm9, [rsp+0x90]
000076e4393d16b4  vmovaps xmm10, [rsp+0xA0]
000076e4393d16bd  vmovaps xmm11, [rsp+0xB0]
000076e4393d16c6  vmovaps xmm12, [rsp+0xC0]
000076e4393d16cf  vmovaps xmm13, [rsp+0xD0]
000076e4393d16d8  vmovaps xmm15, [rsp+0xE0]
000076e4393d16e1  add rsp, 0xF0
000076e4393d16e8  pop r11
000076e4393d16ea  pop r10
000076e4393d16ec  pop r9
000076e4393d16ee  pop r8
000076e4393d16f0  pop rsi
000076e4393d16f1  pop rdi
000076e4393d16f2  pop rdx
000076e4393d16f3  pop rcx
000076e4393d16f4  pop rax
000076e4393d16f5  add rsp, 0x08
000076e4393d16f9  jmp 0x000076E4393CF8E7
000076e4393d16fe  sub rsp, 0x08
000076e4393d1702  push rax
000076e4393d1703  push rcx
000076e4393d1704  push rdx
000076e4393d1705  push rdi
000076e4393d1706  push rsi
000076e4393d1707  push r8
000076e4393d1709  push r9
000076e4393d170b  push r10
000076e4393d170d  push r11
000076e4393d170f  sub rsp, 0xF0
000076e4393d1716  vmovaps [rsp], xmm0
000076e4393d171b  vmovaps [rsp+0x10], xmm1
000076e4393d1721  vmovaps [rsp+0x20], xmm2
000076e4393d1727  vmovaps [rsp+0x30], xmm3
000076e4393d172d  vmovaps [rsp+0x40], xmm4
000076e4393d1733  vmovaps [rsp+0x50], xmm5
000076e4393d1739  vmovaps [rsp+0x60], xmm6
000076e4393d173f  vmovaps [rsp+0x70], xmm7
000076e4393d1745  vmovaps [rsp+0x80], xmm8
000076e4393d174e  vmovaps [rsp+0x90], xmm9
000076e4393d1757  vmovaps [rsp+0xA0], xmm10
000076e4393d1760  vmovaps [rsp+0xB0], xmm11
000076e4393d1769  vmovaps [rsp+0xC0], xmm12
000076e4393d1772  vmovaps [rsp+0xD0], xmm13
000076e4393d177b  vmovaps [rsp+0xE0], xmm14
000076e4393d1784  sub rsp, 0x30
000076e4393d1788  movaps [rsp], xmm15
000076e4393d178d  movaps [rsp+0x10], xmm2
000076e4393d1792  movaps [rsp+0x20], xmm1
000076e4393d1797  lea rdi, [rsp]
000076e4393d179b  mov esi, 0x00
000076e4393d17a0  mov rax, 0x63DBDEB43530
000076e4393d17aa  call rax
000076e4393d17ac  movaps xmm15, [rsp]
000076e4393d17b1  add rsp, 0x30
000076e4393d17b5  vmovaps xmm0, [rsp]
000076e4393d17ba  vmovaps xmm1, [rsp+0x10]
000076e4393d17c0  vmovaps xmm2, [rsp+0x20]
000076e4393d17c6  vmovaps xmm3, [rsp+0x30]
000076e4393d17cc  vmovaps xmm4, [rsp+0x40]
000076e4393d17d2  vmovaps xmm5, [rsp+0x50]
000076e4393d17d8  vmovaps xmm6, [rsp+0x60]
000076e4393d17de  vmovaps xmm7, [rsp+0x70]
000076e4393d17e4  vmovaps xmm8, [rsp+0x80]
000076e4393d17ed  vmovaps xmm9, [rsp+0x90]
000076e4393d17f6  vmovaps xmm10, [rsp+0xA0]
000076e4393d17ff  vmovaps xmm11, [rsp+0xB0]
000076e4393d1808  vmovaps xmm12, [rsp+0xC0]
000076e4393d1811  vmovaps xmm13, [rsp+0xD0]
000076e4393d181a  vmovaps xmm14, [rsp+0xE0]
000076e4393d1823  add rsp, 0xF0
000076e4393d182a  pop r11
000076e4393d182c  pop r10
000076e4393d182e  pop r9
000076e4393d1830  pop r8
000076e4393d1832  pop rsi
000076e4393d1833  pop rdi
000076e4393d1834  pop rdx
000076e4393d1835  pop rcx
000076e4393d1836  pop rax
000076e4393d1837  add rsp, 0x08
000076e4393d183b  jmp 0x000076E4393CF923
000076e4393d1840  call 0x000076E4391FF430
000076e4393d1845  jmp 0x000076E4393CF930
000076e4393d184a  sub rsp, 0x08
000076e4393d184e  push rax
000076e4393d184f  push rcx
000076e4393d1850  push rdx
000076e4393d1851  push rdi
000076e4393d1852  push rsi
000076e4393d1853  push r8
000076e4393d1855  push r9
000076e4393d1857  push r10
000076e4393d1859  push r11
000076e4393d185b  sub rsp, 0xF0
000076e4393d1862  vmovaps [rsp], xmm0
000076e4393d1867  vmovaps [rsp+0x10], xmm1
000076e4393d186d  vmovaps [rsp+0x20], xmm3
000076e4393d1873  vmovaps [rsp+0x30], xmm4
000076e4393d1879  vmovaps [rsp+0x40], xmm5
000076e4393d187f  vmovaps [rsp+0x50], xmm6
000076e4393d1885  vmovaps [rsp+0x60], xmm7
000076e4393d188b  vmovaps [rsp+0x70], xmm8
000076e4393d1891  vmovaps [rsp+0x80], xmm9
000076e4393d189a  vmovaps [rsp+0x90], xmm10
000076e4393d18a3  vmovaps [rsp+0xA0], xmm11
000076e4393d18ac  vmovaps [rsp+0xB0], xmm12
000076e4393d18b5  vmovaps [rsp+0xC0], xmm13
000076e4393d18be  vmovaps [rsp+0xD0], xmm14
000076e4393d18c7  vmovaps [rsp+0xE0], xmm15
000076e4393d18d0  sub rsp, 0x30
000076e4393d18d4  movaps [rsp], xmm2
000076e4393d18d8  movaps [rsp+0x10], xmm1
000076e4393d18dd  movaps [rsp+0x20], xmm14
000076e4393d18e3  lea rdi, [rsp]
000076e4393d18e7  mov esi, 0x00
000076e4393d18ec  mov rax, 0x63DBDEB43530
000076e4393d18f6  call rax
000076e4393d18f8  movaps xmm2, [rsp]
000076e4393d18fc  add rsp, 0x30
000076e4393d1900  vmovaps xmm0, [rsp]
000076e4393d1905  vmovaps xmm1, [rsp+0x10]
000076e4393d190b  vmovaps xmm3, [rsp+0x20]
000076e4393d1911  vmovaps xmm4, [rsp+0x30]
000076e4393d1917  vmovaps xmm5, [rsp+0x40]
000076e4393d191d  vmovaps xmm6, [rsp+0x50]
000076e4393d1923  vmovaps xmm7, [rsp+0x60]
000076e4393d1929  vmovaps xmm8, [rsp+0x70]
000076e4393d192f  vmovaps xmm9, [rsp+0x80]
000076e4393d1938  vmovaps xmm10, [rsp+0x90]
000076e4393d1941  vmovaps xmm11, [rsp+0xA0]
000076e4393d194a  vmovaps xmm12, [rsp+0xB0]
000076e4393d1953  vmovaps xmm13, [rsp+0xC0]
000076e4393d195c  vmovaps xmm14, [rsp+0xD0]
000076e4393d1965  vmovaps xmm15, [rsp+0xE0]
000076e4393d196e  add rsp, 0xF0
000076e4393d1975  pop r11
000076e4393d1977  pop r10
000076e4393d1979  pop r9
000076e4393d197b  pop r8
000076e4393d197d  pop rsi
000076e4393d197e  pop rdi
000076e4393d197f  pop rdx
000076e4393d1980  pop rcx
000076e4393d1981  pop rax
000076e4393d1982  add rsp, 0x08
000076e4393d1986  jmp 0x000076E4393CF96D
000076e4393d198b  sub rsp, 0x08
000076e4393d198f  push rax
000076e4393d1990  push rcx
000076e4393d1991  push rdx
000076e4393d1992  push rdi
000076e4393d1993  push rsi
000076e4393d1994  push r8
000076e4393d1996  push r9
000076e4393d1998  push r10
000076e4393d199a  push r11
000076e4393d199c  sub rsp, 0xF0
000076e4393d19a3  vmovaps [rsp], xmm0
000076e4393d19a8  vmovaps [rsp+0x10], xmm1
000076e4393d19ae  vmovaps [rsp+0x20], xmm2
000076e4393d19b4  vmovaps [rsp+0x30], xmm3
000076e4393d19ba  vmovaps [rsp+0x40], xmm4
000076e4393d19c0  vmovaps [rsp+0x50], xmm5
000076e4393d19c6  vmovaps [rsp+0x60], xmm6
000076e4393d19cc  vmovaps [rsp+0x70], xmm7
000076e4393d19d2  vmovaps [rsp+0x80], xmm8
000076e4393d19db  vmovaps [rsp+0x90], xmm9
000076e4393d19e4  vmovaps [rsp+0xA0], xmm10
000076e4393d19ed  vmovaps [rsp+0xB0], xmm11
000076e4393d19f6  vmovaps [rsp+0xC0], xmm12
000076e4393d19ff  vmovaps [rsp+0xD0], xmm13
000076e4393d1a08  vmovaps [rsp+0xE0], xmm14
000076e4393d1a11  sub rsp, 0x30
000076e4393d1a15  movaps [rsp], xmm15
000076e4393d1a1a  movaps [rsp+0x10], xmm14
000076e4393d1a20  movaps [rsp+0x20], xmm1
000076e4393d1a25  lea rdi, [rsp]
000076e4393d1a29  mov esi, 0x00
000076e4393d1a2e  mov rax, 0x63DBDEB43530
000076e4393d1a38  call rax
000076e4393d1a3a  movaps xmm15, [rsp]
000076e4393d1a3f  add rsp, 0x30
000076e4393d1a43  vmovaps xmm0, [rsp]
000076e4393d1a48  vmovaps xmm1, [rsp+0x10]
000076e4393d1a4e  vmovaps xmm2, [rsp+0x20]
000076e4393d1a54  vmovaps xmm3, [rsp+0x30]
000076e4393d1a5a  vmovaps xmm4, [rsp+0x40]
000076e4393d1a60  vmovaps xmm5, [rsp+0x50]
000076e4393d1a66  vmovaps xmm6, [rsp+0x60]
000076e4393d1a6c  vmovaps xmm7, [rsp+0x70]
000076e4393d1a72  vmovaps xmm8, [rsp+0x80]
000076e4393d1a7b  vmovaps xmm9, [rsp+0x90]
000076e4393d1a84  vmovaps xmm10, [rsp+0xA0]
000076e4393d1a8d  vmovaps xmm11, [rsp+0xB0]
000076e4393d1a96  vmovaps xmm12, [rsp+0xC0]
000076e4393d1a9f  vmovaps xmm13, [rsp+0xD0]
000076e4393d1aa8  vmovaps xmm14, [rsp+0xE0]
000076e4393d1ab1  add rsp, 0xF0
000076e4393d1ab8  pop r11
000076e4393d1aba  pop r10
000076e4393d1abc  pop r9
000076e4393d1abe  pop r8
000076e4393d1ac0  pop rsi
000076e4393d1ac1  pop rdi
000076e4393d1ac2  pop rdx
000076e4393d1ac3  pop rcx
000076e4393d1ac4  pop rax
000076e4393d1ac5  add rsp, 0x08
000076e4393d1ac9  jmp 0x000076E4393CF9E7
000076e4393d1ace  call 0x000076E4391FF430
000076e4393d1ad3  jmp 0x000076E4393CF9F4
000076e4393d1ad8  sub rsp, 0x08
000076e4393d1adc  push rax
000076e4393d1add  push rcx
000076e4393d1ade  push rdx
000076e4393d1adf  push rdi
000076e4393d1ae0  push rsi
000076e4393d1ae1  push r8
000076e4393d1ae3  push r9
000076e4393d1ae5  push r10
000076e4393d1ae7  push r11
000076e4393d1ae9  sub rsp, 0xF0
000076e4393d1af0  vmovaps [rsp], xmm0
000076e4393d1af5  vmovaps [rsp+0x10], xmm1
000076e4393d1afb  vmovaps [rsp+0x20], xmm2
000076e4393d1b01  vmovaps [rsp+0x30], xmm3
000076e4393d1b07  vmovaps [rsp+0x40], xmm4
000076e4393d1b0d  vmovaps [rsp+0x50], xmm5
000076e4393d1b13  vmovaps [rsp+0x60], xmm6
000076e4393d1b19  vmovaps [rsp+0x70], xmm7
000076e4393d1b1f  vmovaps [rsp+0x80], xmm8
000076e4393d1b28  vmovaps [rsp+0x90], xmm9
000076e4393d1b31  vmovaps [rsp+0xA0], xmm10
000076e4393d1b3a  vmovaps [rsp+0xB0], xmm11
000076e4393d1b43  vmovaps [rsp+0xC0], xmm12
000076e4393d1b4c  vmovaps [rsp+0xD0], xmm13
000076e4393d1b55  vmovaps [rsp+0xE0], xmm15
000076e4393d1b5e  sub rsp, 0x30
000076e4393d1b62  movaps [rsp], xmm14
000076e4393d1b67  movaps [rsp+0x10], xmm13
000076e4393d1b6d  movaps [rsp+0x20], xmm1
000076e4393d1b72  lea rdi, [rsp]
000076e4393d1b76  mov esi, 0x00
000076e4393d1b7b  mov rax, 0x63DBDEB43530
000076e4393d1b85  call rax
000076e4393d1b87  movaps xmm14, [rsp]
000076e4393d1b8c  add rsp, 0x30
000076e4393d1b90  vmovaps xmm0, [rsp]
000076e4393d1b95  vmovaps xmm1, [rsp+0x10]
000076e4393d1b9b  vmovaps xmm2, [rsp+0x20]
000076e4393d1ba1  vmovaps xmm3, [rsp+0x30]
000076e4393d1ba7  vmovaps xmm4, [rsp+0x40]
000076e4393d1bad  vmovaps xmm5, [rsp+0x50]
000076e4393d1bb3  vmovaps xmm6, [rsp+0x60]
000076e4393d1bb9  vmovaps xmm7, [rsp+0x70]
000076e4393d1bbf  vmovaps xmm8, [rsp+0x80]
000076e4393d1bc8  vmovaps xmm9, [rsp+0x90]
000076e4393d1bd1  vmovaps xmm10, [rsp+0xA0]
000076e4393d1bda  vmovaps xmm11, [rsp+0xB0]
000076e4393d1be3  vmovaps xmm12, [rsp+0xC0]
000076e4393d1bec  vmovaps xmm13, [rsp+0xD0]
000076e4393d1bf5  vmovaps xmm15, [rsp+0xE0]
000076e4393d1bfe  add rsp, 0xF0
000076e4393d1c05  pop r11
000076e4393d1c07  pop r10
000076e4393d1c09  pop r9
000076e4393d1c0b  pop r8
000076e4393d1c0d  pop rsi
000076e4393d1c0e  pop rdi
000076e4393d1c0f  pop rdx
000076e4393d1c10  pop rcx
000076e4393d1c11  pop rax
000076e4393d1c12  add rsp, 0x08
000076e4393d1c16  jmp 0x000076E4393CFAAF
000076e4393d1c1b  sub rsp, 0x08
000076e4393d1c1f  push rax
000076e4393d1c20  push rcx
000076e4393d1c21  push rdx
000076e4393d1c22  push rdi
000076e4393d1c23  push rsi
000076e4393d1c24  push r8
000076e4393d1c26  push r9
000076e4393d1c28  push r10
000076e4393d1c2a  push r11
000076e4393d1c2c  sub rsp, 0xF0
000076e4393d1c33  vmovaps [rsp], xmm0
000076e4393d1c38  vmovaps [rsp+0x10], xmm1
000076e4393d1c3e  vmovaps [rsp+0x20], xmm2
000076e4393d1c44  vmovaps [rsp+0x30], xmm3
000076e4393d1c4a  vmovaps [rsp+0x40], xmm4
000076e4393d1c50  vmovaps [rsp+0x50], xmm5
000076e4393d1c56  vmovaps [rsp+0x60], xmm6
000076e4393d1c5c  vmovaps [rsp+0x70], xmm7
000076e4393d1c62  vmovaps [rsp+0x80], xmm8
000076e4393d1c6b  vmovaps [rsp+0x90], xmm9
000076e4393d1c74  vmovaps [rsp+0xA0], xmm10
000076e4393d1c7d  vmovaps [rsp+0xB0], xmm11
000076e4393d1c86  vmovaps [rsp+0xC0], xmm12
000076e4393d1c8f  vmovaps [rsp+0xD0], xmm13
000076e4393d1c98  vmovaps [rsp+0xE0], xmm14
000076e4393d1ca1  sub rsp, 0x30
000076e4393d1ca5  movaps [rsp], xmm15
000076e4393d1caa  movaps [rsp+0x10], xmm13
000076e4393d1cb0  movaps [rsp+0x20], xmm1
000076e4393d1cb5  lea rdi, [rsp]
000076e4393d1cb9  mov esi, 0x00
000076e4393d1cbe  mov rax, 0x63DBDEB43530
000076e4393d1cc8  call rax
000076e4393d1cca  movaps xmm15, [rsp]
000076e4393d1ccf  add rsp, 0x30
000076e4393d1cd3  vmovaps xmm0, [rsp]
000076e4393d1cd8  vmovaps xmm1, [rsp+0x10]
000076e4393d1cde  vmovaps xmm2, [rsp+0x20]
000076e4393d1ce4  vmovaps xmm3, [rsp+0x30]
000076e4393d1cea  vmovaps xmm4, [rsp+0x40]
000076e4393d1cf0  vmovaps xmm5, [rsp+0x50]
000076e4393d1cf6  vmovaps xmm6, [rsp+0x60]
000076e4393d1cfc  vmovaps xmm7, [rsp+0x70]
000076e4393d1d02  vmovaps xmm8, [rsp+0x80]
000076e4393d1d0b  vmovaps xmm9, [rsp+0x90]
000076e4393d1d14  vmovaps xmm10, [rsp+0xA0]
000076e4393d1d1d  vmovaps xmm11, [rsp+0xB0]
000076e4393d1d26  vmovaps xmm12, [rsp+0xC0]
000076e4393d1d2f  vmovaps xmm13, [rsp+0xD0]
000076e4393d1d38  vmovaps xmm14, [rsp+0xE0]
000076e4393d1d41  add rsp, 0xF0
000076e4393d1d48  pop r11
000076e4393d1d4a  pop r10
000076e4393d1d4c  pop r9
000076e4393d1d4e  pop r8
000076e4393d1d50  pop rsi
000076e4393d1d51  pop rdi
000076e4393d1d52  pop rdx
000076e4393d1d53  pop rcx
000076e4393d1d54  pop rax
000076e4393d1d55  add rsp, 0x08
000076e4393d1d59  jmp 0x000076E4393CFAEB
000076e4393d1d5e  call 0x000076E4391FF430
000076e4393d1d63  jmp 0x000076E4393CFAF8
000076e4393d1d68  sub rsp, 0x08
000076e4393d1d6c  push rax
000076e4393d1d6d  push rcx
000076e4393d1d6e  push rdx
000076e4393d1d6f  push rdi
000076e4393d1d70  push rsi
000076e4393d1d71  push r8
000076e4393d1d73  push r9
000076e4393d1d75  push r10
000076e4393d1d77  push r11
000076e4393d1d79  sub rsp, 0xF0
000076e4393d1d80  vmovaps [rsp], xmm0
000076e4393d1d85  vmovaps [rsp+0x10], xmm1
000076e4393d1d8b  vmovaps [rsp+0x20], xmm2
000076e4393d1d91  vmovaps [rsp+0x30], xmm3
000076e4393d1d97  vmovaps [rsp+0x40], xmm4
000076e4393d1d9d  vmovaps [rsp+0x50], xmm5
000076e4393d1da3  vmovaps [rsp+0x60], xmm6
000076e4393d1da9  vmovaps [rsp+0x70], xmm7
000076e4393d1daf  vmovaps [rsp+0x80], xmm8
000076e4393d1db8  vmovaps [rsp+0x90], xmm9
000076e4393d1dc1  vmovaps [rsp+0xA0], xmm10
000076e4393d1dca  vmovaps [rsp+0xB0], xmm11
000076e4393d1dd3  vmovaps [rsp+0xC0], xmm12
000076e4393d1ddc  vmovaps [rsp+0xD0], xmm13
000076e4393d1de5  vmovaps [rsp+0xE0], xmm15
000076e4393d1dee  sub rsp, 0x30
000076e4393d1df2  movaps [rsp], xmm14
000076e4393d1df7  movaps [rsp+0x10], xmm13
000076e4393d1dfd  movaps [rsp+0x20], xmm2
000076e4393d1e02  lea rdi, [rsp]
000076e4393d1e06  mov esi, 0x00
000076e4393d1e0b  mov rax, 0x63DBDEB43530
000076e4393d1e15  call rax
000076e4393d1e17  movaps xmm14, [rsp]
000076e4393d1e1c  add rsp, 0x30
000076e4393d1e20  vmovaps xmm0, [rsp]
000076e4393d1e25  vmovaps xmm1, [rsp+0x10]
000076e4393d1e2b  vmovaps xmm2, [rsp+0x20]
000076e4393d1e31  vmovaps xmm3, [rsp+0x30]
000076e4393d1e37  vmovaps xmm4, [rsp+0x40]
000076e4393d1e3d  vmovaps xmm5, [rsp+0x50]
000076e4393d1e43  vmovaps xmm6, [rsp+0x60]
000076e4393d1e49  vmovaps xmm7, [rsp+0x70]
000076e4393d1e4f  vmovaps xmm8, [rsp+0x80]
000076e4393d1e58  vmovaps xmm9, [rsp+0x90]
000076e4393d1e61  vmovaps xmm10, [rsp+0xA0]
000076e4393d1e6a  vmovaps xmm11, [rsp+0xB0]
000076e4393d1e73  vmovaps xmm12, [rsp+0xC0]
000076e4393d1e7c  vmovaps xmm13, [rsp+0xD0]
000076e4393d1e85  vmovaps xmm15, [rsp+0xE0]
000076e4393d1e8e  add rsp, 0xF0
000076e4393d1e95  pop r11
000076e4393d1e97  pop r10
000076e4393d1e99  pop r9
000076e4393d1e9b  pop r8
000076e4393d1e9d  pop rsi
000076e4393d1e9e  pop rdi
000076e4393d1e9f  pop rdx
000076e4393d1ea0  pop rcx
000076e4393d1ea1  pop rax
000076e4393d1ea2  add rsp, 0x08
000076e4393d1ea6  jmp 0x000076E4393CFB24
000076e4393d1eab  sub rsp, 0x08
000076e4393d1eaf  push rax
000076e4393d1eb0  push rcx
000076e4393d1eb1  push rdx
000076e4393d1eb2  push rdi
000076e4393d1eb3  push rsi
000076e4393d1eb4  push r8
000076e4393d1eb6  push r9
000076e4393d1eb8  push r10
000076e4393d1eba  push r11
000076e4393d1ebc  sub rsp, 0xF0
000076e4393d1ec3  vmovaps [rsp], xmm0
000076e4393d1ec8  vmovaps [rsp+0x10], xmm2
000076e4393d1ece  vmovaps [rsp+0x20], xmm3
000076e4393d1ed4  vmovaps [rsp+0x30], xmm4
000076e4393d1eda  vmovaps [rsp+0x40], xmm5
000076e4393d1ee0  vmovaps [rsp+0x50], xmm6
000076e4393d1ee6  vmovaps [rsp+0x60], xmm7
000076e4393d1eec  vmovaps [rsp+0x70], xmm8
000076e4393d1ef2  vmovaps [rsp+0x80], xmm9
000076e4393d1efb  vmovaps [rsp+0x90], xmm10
000076e4393d1f04  vmovaps [rsp+0xA0], xmm11
000076e4393d1f0d  vmovaps [rsp+0xB0], xmm12
000076e4393d1f16  vmovaps [rsp+0xC0], xmm13
000076e4393d1f1f  vmovaps [rsp+0xD0], xmm14
000076e4393d1f28  vmovaps [rsp+0xE0], xmm15
000076e4393d1f31  sub rsp, 0x30
000076e4393d1f35  movaps [rsp], xmm1
000076e4393d1f39  movaps [rsp+0x10], xmm13
000076e4393d1f3f  movaps [rsp+0x20], xmm2
000076e4393d1f44  lea rdi, [rsp]
000076e4393d1f48  mov esi, 0x00
000076e4393d1f4d  mov rax, 0x63DBDEB43530
000076e4393d1f57  call rax
000076e4393d1f59  movaps xmm1, [rsp]
000076e4393d1f5d  add rsp, 0x30
000076e4393d1f61  vmovaps xmm0, [rsp]
000076e4393d1f66  vmovaps xmm2, [rsp+0x10]
000076e4393d1f6c  vmovaps xmm3, [rsp+0x20]
000076e4393d1f72  vmovaps xmm4, [rsp+0x30]
000076e4393d1f78  vmovaps xmm5, [rsp+0x40]
000076e4393d1f7e  vmovaps xmm6, [rsp+0x50]
000076e4393d1f84  vmovaps xmm7, [rsp+0x60]
000076e4393d1f8a  vmovaps xmm8, [rsp+0x70]
000076e4393d1f90  vmovaps xmm9, [rsp+0x80]
000076e4393d1f99  vmovaps xmm10, [rsp+0x90]
000076e4393d1fa2  vmovaps xmm11, [rsp+0xA0]
000076e4393d1fab  vmovaps xmm12, [rsp+0xB0]
000076e4393d1fb4  vmovaps xmm13, [rsp+0xC0]
000076e4393d1fbd  vmovaps xmm14, [rsp+0xD0]
000076e4393d1fc6  vmovaps xmm15, [rsp+0xE0]
000076e4393d1fcf  add rsp, 0xF0
000076e4393d1fd6  pop r11
000076e4393d1fd8  pop r10
000076e4393d1fda  pop r9
000076e4393d1fdc  pop r8
000076e4393d1fde  pop rsi
000076e4393d1fdf  pop rdi
000076e4393d1fe0  pop rdx
000076e4393d1fe1  pop rcx
000076e4393d1fe2  pop rax
000076e4393d1fe3  add rsp, 0x08
000076e4393d1fe7  jmp 0x000076E4393CFB52
000076e4393d1fec  sub rsp, 0x08
000076e4393d1ff0  push rax
000076e4393d1ff1  push rcx
000076e4393d1ff2  push rdx
000076e4393d1ff3  push rdi
000076e4393d1ff4  push rsi
000076e4393d1ff5  push r8
000076e4393d1ff7  push r9
000076e4393d1ff9  push r10
000076e4393d1ffb  push r11
000076e4393d1ffd  sub rsp, 0xF0
000076e4393d2004  vmovaps [rsp], xmm0
000076e4393d2009  vmovaps [rsp+0x10], xmm1
000076e4393d200f  vmovaps [rsp+0x20], xmm3
000076e4393d2015  vmovaps [rsp+0x30], xmm4
000076e4393d201b  vmovaps [rsp+0x40], xmm5
000076e4393d2021  vmovaps [rsp+0x50], xmm6
000076e4393d2027  vmovaps [rsp+0x60], xmm7
000076e4393d202d  vmovaps [rsp+0x70], xmm8
000076e4393d2033  vmovaps [rsp+0x80], xmm9
000076e4393d203c  vmovaps [rsp+0x90], xmm10
000076e4393d2045  vmovaps [rsp+0xA0], xmm11
000076e4393d204e  vmovaps [rsp+0xB0], xmm12
000076e4393d2057  vmovaps [rsp+0xC0], xmm13
000076e4393d2060  vmovaps [rsp+0xD0], xmm14
000076e4393d2069  vmovaps [rsp+0xE0], xmm15
000076e4393d2072  sub rsp, 0x30
000076e4393d2076  movaps [rsp], xmm2
000076e4393d207a  movaps [rsp+0x10], xmm1
000076e4393d207f  movaps [rsp+0x20], xmm13
000076e4393d2085  lea rdi, [rsp]
000076e4393d2089  mov esi, 0x00
000076e4393d208e  mov rax, 0x63DBDEB43530
000076e4393d2098  call rax
000076e4393d209a  movaps xmm2, [rsp]
000076e4393d209e  add rsp, 0x30
000076e4393d20a2  vmovaps xmm0, [rsp]
000076e4393d20a7  vmovaps xmm1, [rsp+0x10]
000076e4393d20ad  vmovaps xmm3, [rsp+0x20]
000076e4393d20b3  vmovaps xmm4, [rsp+0x30]
000076e4393d20b9  vmovaps xmm5, [rsp+0x40]
000076e4393d20bf  vmovaps xmm6, [rsp+0x50]
000076e4393d20c5  vmovaps xmm7, [rsp+0x60]
000076e4393d20cb  vmovaps xmm8, [rsp+0x70]
000076e4393d20d1  vmovaps xmm9, [rsp+0x80]
000076e4393d20da  vmovaps xmm10, [rsp+0x90]
000076e4393d20e3  vmovaps xmm11, [rsp+0xA0]
000076e4393d20ec  vmovaps xmm12, [rsp+0xB0]
000076e4393d20f5  vmovaps xmm13, [rsp+0xC0]
000076e4393d20fe  vmovaps xmm14, [rsp+0xD0]
000076e4393d2107  vmovaps xmm15, [rsp+0xE0]
000076e4393d2110  add rsp, 0xF0
000076e4393d2117  pop r11
000076e4393d2119  pop r10
000076e4393d211b  pop r9
000076e4393d211d  pop r8
000076e4393d211f  pop rsi
000076e4393d2120  pop rdi
000076e4393d2121  pop rdx
000076e4393d2122  pop rcx
000076e4393d2123  pop rax
000076e4393d2124  add rsp, 0x08
000076e4393d2128  jmp 0x000076E4393CFBAB
000076e4393d212d  call 0x000076E4391FF430
000076e4393d2132  jmp 0x000076E4393CFBB8
000076e4393d2137  sub rsp, 0x08
000076e4393d213b  push rax
000076e4393d213c  push rcx
000076e4393d213d  push rdx
000076e4393d213e  push rdi
000076e4393d213f  push rsi
000076e4393d2140  push r8
000076e4393d2142  push r9
000076e4393d2144  push r10
000076e4393d2146  push r11
000076e4393d2148  sub rsp, 0xF0
000076e4393d214f  vmovaps [rsp], xmm0
000076e4393d2154  vmovaps [rsp+0x10], xmm1
000076e4393d215a  vmovaps [rsp+0x20], xmm2
000076e4393d2160  vmovaps [rsp+0x30], xmm3
000076e4393d2166  vmovaps [rsp+0x40], xmm4
000076e4393d216c  vmovaps [rsp+0x50], xmm5
000076e4393d2172  vmovaps [rsp+0x60], xmm6
000076e4393d2178  vmovaps [rsp+0x70], xmm7
000076e4393d217e  vmovaps [rsp+0x80], xmm8
000076e4393d2187  vmovaps [rsp+0x90], xmm9
000076e4393d2190  vmovaps [rsp+0xA0], xmm10
000076e4393d2199  vmovaps [rsp+0xB0], xmm11
000076e4393d21a2  vmovaps [rsp+0xC0], xmm12
000076e4393d21ab  vmovaps [rsp+0xD0], xmm13
000076e4393d21b4  vmovaps [rsp+0xE0], xmm14
000076e4393d21bd  sub rsp, 0x30
000076e4393d21c1  movaps [rsp], xmm15
000076e4393d21c6  movaps [rsp+0x10], xmm13
000076e4393d21cc  movaps [rsp+0x20], xmm1
000076e4393d21d1  lea rdi, [rsp]
000076e4393d21d5  mov esi, 0x00
000076e4393d21da  mov rax, 0x63DBDEB43530
000076e4393d21e4  call rax
000076e4393d21e6  movaps xmm15, [rsp]
000076e4393d21eb  add rsp, 0x30
000076e4393d21ef  vmovaps xmm0, [rsp]
000076e4393d21f4  vmovaps xmm1, [rsp+0x10]
000076e4393d21fa  vmovaps xmm2, [rsp+0x20]
000076e4393d2200  vmovaps xmm3, [rsp+0x30]
000076e4393d2206  vmovaps xmm4, [rsp+0x40]
000076e4393d220c  vmovaps xmm5, [rsp+0x50]
000076e4393d2212  vmovaps xmm6, [rsp+0x60]
000076e4393d2218  vmovaps xmm7, [rsp+0x70]
000076e4393d221e  vmovaps xmm8, [rsp+0x80]
000076e4393d2227  vmovaps xmm9, [rsp+0x90]
000076e4393d2230  vmovaps xmm10, [rsp+0xA0]
000076e4393d2239  vmovaps xmm11, [rsp+0xB0]
000076e4393d2242  vmovaps xmm12, [rsp+0xC0]
000076e4393d224b  vmovaps xmm13, [rsp+0xD0]
000076e4393d2254  vmovaps xmm14, [rsp+0xE0]
000076e4393d225d  add rsp, 0xF0
000076e4393d2264  pop r11
000076e4393d2266  pop r10
000076e4393d2268  pop r9
000076e4393d226a  pop r8
000076e4393d226c  pop rsi
000076e4393d226d  pop rdi
000076e4393d226e  pop rdx
000076e4393d226f  pop rcx
000076e4393d2270  pop rax
000076e4393d2271  add rsp, 0x08
000076e4393d2275  jmp 0x000076E4393CFBF7
000076e4393d227a  sub rsp, 0x08
000076e4393d227e  push rax
000076e4393d227f  push rcx
000076e4393d2280  push rdx
000076e4393d2281  push rdi
000076e4393d2282  push rsi
000076e4393d2283  push r8
000076e4393d2285  push r9
000076e4393d2287  push r10
000076e4393d2289  push r11
000076e4393d228b  sub rsp, 0xF0
000076e4393d2292  vmovaps [rsp], xmm0
000076e4393d2297  vmovaps [rsp+0x10], xmm1
000076e4393d229d  vmovaps [rsp+0x20], xmm2
000076e4393d22a3  vmovaps [rsp+0x30], xmm3
000076e4393d22a9  vmovaps [rsp+0x40], xmm4
000076e4393d22af  vmovaps [rsp+0x50], xmm5
000076e4393d22b5  vmovaps [rsp+0x60], xmm6
000076e4393d22bb  vmovaps [rsp+0x70], xmm7
000076e4393d22c1  vmovaps [rsp+0x80], xmm8
000076e4393d22ca  vmovaps [rsp+0x90], xmm9
000076e4393d22d3  vmovaps [rsp+0xA0], xmm10
000076e4393d22dc  vmovaps [rsp+0xB0], xmm11
000076e4393d22e5  vmovaps [rsp+0xC0], xmm12
000076e4393d22ee  vmovaps [rsp+0xD0], xmm13
000076e4393d22f7  vmovaps [rsp+0xE0], xmm15
000076e4393d2300  sub rsp, 0x30
000076e4393d2304  movaps [rsp], xmm14
000076e4393d2309  movaps [rsp+0x10], xmm11
000076e4393d230f  movaps [rsp+0x20], xmm1
000076e4393d2314  lea rdi, [rsp]
000076e4393d2318  mov esi, 0x00
000076e4393d231d  mov rax, 0x63DBDEB43530
000076e4393d2327  call rax
000076e4393d2329  movaps xmm14, [rsp]
000076e4393d232e  add rsp, 0x30
000076e4393d2332  vmovaps xmm0, [rsp]
000076e4393d2337  vmovaps xmm1, [rsp+0x10]
000076e4393d233d  vmovaps xmm2, [rsp+0x20]
000076e4393d2343  vmovaps xmm3, [rsp+0x30]
000076e4393d2349  vmovaps xmm4, [rsp+0x40]
000076e4393d234f  vmovaps xmm5, [rsp+0x50]
000076e4393d2355  vmovaps xmm6, [rsp+0x60]
000076e4393d235b  vmovaps xmm7, [rsp+0x70]
000076e4393d2361  vmovaps xmm8, [rsp+0x80]
000076e4393d236a  vmovaps xmm9, [rsp+0x90]
000076e4393d2373  vmovaps xmm10, [rsp+0xA0]
000076e4393d237c  vmovaps xmm11, [rsp+0xB0]
000076e4393d2385  vmovaps xmm12, [rsp+0xC0]
000076e4393d238e  vmovaps xmm13, [rsp+0xD0]
000076e4393d2397  vmovaps xmm15, [rsp+0xE0]
000076e4393d23a0  add rsp, 0xF0
000076e4393d23a7  pop r11
000076e4393d23a9  pop r10
000076e4393d23ab  pop r9
000076e4393d23ad  pop r8
000076e4393d23af  pop rsi
000076e4393d23b0  pop rdi
000076e4393d23b1  pop rdx
000076e4393d23b2  pop rcx
000076e4393d23b3  pop rax
000076e4393d23b4  add rsp, 0x08
000076e4393d23b8  jmp 0x000076E4393CFC21
000076e4393d23bd  sub rsp, 0x08
000076e4393d23c1  push rax
000076e4393d23c2  push rcx
000076e4393d23c3  push rdx
000076e4393d23c4  push rdi
000076e4393d23c5  push rsi
000076e4393d23c6  push r8
000076e4393d23c8  push r9
000076e4393d23ca  push r10
000076e4393d23cc  push r11
000076e4393d23ce  sub rsp, 0xF0
000076e4393d23d5  vmovaps [rsp], xmm0
000076e4393d23da  vmovaps [rsp+0x10], xmm1
000076e4393d23e0  vmovaps [rsp+0x20], xmm2
000076e4393d23e6  vmovaps [rsp+0x30], xmm3
000076e4393d23ec  vmovaps [rsp+0x40], xmm4
000076e4393d23f2  vmovaps [rsp+0x50], xmm5
000076e4393d23f8  vmovaps [rsp+0x60], xmm6
000076e4393d23fe  vmovaps [rsp+0x70], xmm7
000076e4393d2404  vmovaps [rsp+0x80], xmm8
000076e4393d240d  vmovaps [rsp+0x90], xmm9
000076e4393d2416  vmovaps [rsp+0xA0], xmm10
000076e4393d241f  vmovaps [rsp+0xB0], xmm11
000076e4393d2428  vmovaps [rsp+0xC0], xmm12
000076e4393d2431  vmovaps [rsp+0xD0], xmm14
000076e4393d243a  vmovaps [rsp+0xE0], xmm15
000076e4393d2443  sub rsp, 0x30
000076e4393d2447  movaps [rsp], xmm13
000076e4393d244c  movaps [rsp+0x10], xmm11
000076e4393d2452  movaps [rsp+0x20], xmm1
000076e4393d2457  lea rdi, [rsp]
000076e4393d245b  mov esi, 0x00
000076e4393d2460  mov rax, 0x63DBDEB43530
000076e4393d246a  call rax
000076e4393d246c  movaps xmm13, [rsp]
000076e4393d2471  add rsp, 0x30
000076e4393d2475  vmovaps xmm0, [rsp]
000076e4393d247a  vmovaps xmm1, [rsp+0x10]
000076e4393d2480  vmovaps xmm2, [rsp+0x20]
000076e4393d2486  vmovaps xmm3, [rsp+0x30]
000076e4393d248c  vmovaps xmm4, [rsp+0x40]
000076e4393d2492  vmovaps xmm5, [rsp+0x50]
000076e4393d2498  vmovaps xmm6, [rsp+0x60]
000076e4393d249e  vmovaps xmm7, [rsp+0x70]
000076e4393d24a4  vmovaps xmm8, [rsp+0x80]
000076e4393d24ad  vmovaps xmm9, [rsp+0x90]
000076e4393d24b6  vmovaps xmm10, [rsp+0xA0]
000076e4393d24bf  vmovaps xmm11, [rsp+0xB0]
000076e4393d24c8  vmovaps xmm12, [rsp+0xC0]
000076e4393d24d1  vmovaps xmm14, [rsp+0xD0]
000076e4393d24da  vmovaps xmm15, [rsp+0xE0]
000076e4393d24e3  add rsp, 0xF0
000076e4393d24ea  pop r11
000076e4393d24ec  pop r10
000076e4393d24ee  pop r9
000076e4393d24f0  pop r8
000076e4393d24f2  pop rsi
000076e4393d24f3  pop rdi
000076e4393d24f4  pop rdx
000076e4393d24f5  pop rcx
000076e4393d24f6  pop rax
000076e4393d24f7  add rsp, 0x08
000076e4393d24fb  jmp 0x000076E4393CFC76
000076e4393d2500  call 0x000076E4391FF430
000076e4393d2505  jmp 0x000076E4393CFC83
000076e4393d250a  sub rsp, 0x08
000076e4393d250e  push rax
000076e4393d250f  push rcx
000076e4393d2510  push rdx
000076e4393d2511  push rdi
000076e4393d2512  push rsi
000076e4393d2513  push r8
000076e4393d2515  push r9
000076e4393d2517  push r10
000076e4393d2519  push r11
000076e4393d251b  sub rsp, 0xF0
000076e4393d2522  vmovaps [rsp], xmm0
000076e4393d2527  vmovaps [rsp+0x10], xmm1
000076e4393d252d  vmovaps [rsp+0x20], xmm2
000076e4393d2533  vmovaps [rsp+0x30], xmm3
000076e4393d2539  vmovaps [rsp+0x40], xmm4
000076e4393d253f  vmovaps [rsp+0x50], xmm5
000076e4393d2545  vmovaps [rsp+0x60], xmm6
000076e4393d254b  vmovaps [rsp+0x70], xmm7
000076e4393d2551  vmovaps [rsp+0x80], xmm8
000076e4393d255a  vmovaps [rsp+0x90], xmm9
000076e4393d2563  vmovaps [rsp+0xA0], xmm10
000076e4393d256c  vmovaps [rsp+0xB0], xmm11
000076e4393d2575  vmovaps [rsp+0xC0], xmm12
000076e4393d257e  vmovaps [rsp+0xD0], xmm13
000076e4393d2587  vmovaps [rsp+0xE0], xmm14
000076e4393d2590  sub rsp, 0x30
000076e4393d2594  movaps [rsp], xmm15
000076e4393d2599  movaps [rsp+0x10], xmm11
000076e4393d259f  movaps [rsp+0x20], xmm1
000076e4393d25a4  lea rdi, [rsp]
000076e4393d25a8  mov esi, 0x00
000076e4393d25ad  mov rax, 0x63DBDEB43530
000076e4393d25b7  call rax
000076e4393d25b9  movaps xmm15, [rsp]
000076e4393d25be  add rsp, 0x30
000076e4393d25c2  vmovaps xmm0, [rsp]
000076e4393d25c7  vmovaps xmm1, [rsp+0x10]
000076e4393d25cd  vmovaps xmm2, [rsp+0x20]
000076e4393d25d3  vmovaps xmm3, [rsp+0x30]
000076e4393d25d9  vmovaps xmm4, [rsp+0x40]
000076e4393d25df  vmovaps xmm5, [rsp+0x50]
000076e4393d25e5  vmovaps xmm6, [rsp+0x60]
000076e4393d25eb  vmovaps xmm7, [rsp+0x70]
000076e4393d25f1  vmovaps xmm8, [rsp+0x80]
000076e4393d25fa  vmovaps xmm9, [rsp+0x90]
000076e4393d2603  vmovaps xmm10, [rsp+0xA0]
000076e4393d260c  vmovaps xmm11, [rsp+0xB0]
000076e4393d2615  vmovaps xmm12, [rsp+0xC0]
000076e4393d261e  vmovaps xmm13, [rsp+0xD0]
000076e4393d2627  vmovaps xmm14, [rsp+0xE0]
000076e4393d2630  add rsp, 0xF0
000076e4393d2637  pop r11
000076e4393d2639  pop r10
000076e4393d263b  pop r9
000076e4393d263d  pop r8
000076e4393d263f  pop rsi
000076e4393d2640  pop rdi
000076e4393d2641  pop rdx
000076e4393d2642  pop rcx
000076e4393d2643  pop rax
000076e4393d2644  add rsp, 0x08
000076e4393d2648  jmp 0x000076E4393CFCBC
000076e4393d264d  sub rsp, 0x08
000076e4393d2651  push rax
000076e4393d2652  push rcx
000076e4393d2653  push rdx
000076e4393d2654  push rdi
000076e4393d2655  push rsi
000076e4393d2656  push r8
000076e4393d2658  push r9
000076e4393d265a  push r10
000076e4393d265c  push r11
000076e4393d265e  sub rsp, 0xF0
000076e4393d2665  vmovaps [rsp], xmm0
000076e4393d266a  vmovaps [rsp+0x10], xmm1
000076e4393d2670  vmovaps [rsp+0x20], xmm2
000076e4393d2676  vmovaps [rsp+0x30], xmm3
000076e4393d267c  vmovaps [rsp+0x40], xmm4
000076e4393d2682  vmovaps [rsp+0x50], xmm5
000076e4393d2688  vmovaps [rsp+0x60], xmm6
000076e4393d268e  vmovaps [rsp+0x70], xmm7
000076e4393d2694  vmovaps [rsp+0x80], xmm8
000076e4393d269d  vmovaps [rsp+0x90], xmm9
000076e4393d26a6  vmovaps [rsp+0xA0], xmm10
000076e4393d26af  vmovaps [rsp+0xB0], xmm12
000076e4393d26b8  vmovaps [rsp+0xC0], xmm13
000076e4393d26c1  vmovaps [rsp+0xD0], xmm14
000076e4393d26ca  vmovaps [rsp+0xE0], xmm15
000076e4393d26d3  sub rsp, 0x30
000076e4393d26d7  movaps [rsp], xmm11
000076e4393d26dc  movaps [rsp+0x10], xmm6
000076e4393d26e1  movaps [rsp+0x20], xmm14
000076e4393d26e7  lea rdi, [rsp]
000076e4393d26eb  mov esi, 0x00
000076e4393d26f0  mov rax, 0x63DBDEB43530
000076e4393d26fa  call rax
000076e4393d26fc  movaps xmm11, [rsp]
000076e4393d2701  add rsp, 0x30
000076e4393d2705  vmovaps xmm0, [rsp]
000076e4393d270a  vmovaps xmm1, [rsp+0x10]
000076e4393d2710  vmovaps xmm2, [rsp+0x20]
000076e4393d2716  vmovaps xmm3, [rsp+0x30]
000076e4393d271c  vmovaps xmm4, [rsp+0x40]
000076e4393d2722  vmovaps xmm5, [rsp+0x50]
000076e4393d2728  vmovaps xmm6, [rsp+0x60]
000076e4393d272e  vmovaps xmm7, [rsp+0x70]
000076e4393d2734  vmovaps xmm8, [rsp+0x80]
000076e4393d273d  vmovaps xmm9, [rsp+0x90]
000076e4393d2746  vmovaps xmm10, [rsp+0xA0]
000076e4393d274f  vmovaps xmm12, [rsp+0xB0]
000076e4393d2758  vmovaps xmm13, [rsp+0xC0]
000076e4393d2761  vmovaps xmm14, [rsp+0xD0]
000076e4393d276a  vmovaps xmm15, [rsp+0xE0]
000076e4393d2773  add rsp, 0xF0
000076e4393d277a  pop r11
000076e4393d277c  pop r10
000076e4393d277e  pop r9
000076e4393d2780  pop r8
000076e4393d2782  pop rsi
000076e4393d2783  pop rdi
000076e4393d2784  pop rdx
000076e4393d2785  pop rcx
000076e4393d2786  pop rax
000076e4393d2787  add rsp, 0x08
000076e4393d278b  jmp 0x000076E4393CFD34
000076e4393d2790  call 0x000076E4391FF430
000076e4393d2795  jmp 0x000076E4393CFD3E
000076e4393d279a  sub rsp, 0x08
000076e4393d279e  push rax
000076e4393d279f  push rcx
000076e4393d27a0  push rdx
000076e4393d27a1  push rdi
000076e4393d27a2  push rsi
000076e4393d27a3  push r8
000076e4393d27a5  push r9
000076e4393d27a7  push r10
000076e4393d27a9  push r11
000076e4393d27ab  sub rsp, 0xF0
000076e4393d27b2  vmovaps [rsp], xmm0
000076e4393d27b7  vmovaps [rsp+0x10], xmm1
000076e4393d27bd  vmovaps [rsp+0x20], xmm2
000076e4393d27c3  vmovaps [rsp+0x30], xmm3
000076e4393d27c9  vmovaps [rsp+0x40], xmm4
000076e4393d27cf  vmovaps [rsp+0x50], xmm5
000076e4393d27d5  vmovaps [rsp+0x60], xmm6
000076e4393d27db  vmovaps [rsp+0x70], xmm7
000076e4393d27e1  vmovaps [rsp+0x80], xmm8
000076e4393d27ea  vmovaps [rsp+0x90], xmm9
000076e4393d27f3  vmovaps [rsp+0xA0], xmm10
000076e4393d27fc  vmovaps [rsp+0xB0], xmm11
000076e4393d2805  vmovaps [rsp+0xC0], xmm12
000076e4393d280e  vmovaps [rsp+0xD0], xmm13
000076e4393d2817  vmovaps [rsp+0xE0], xmm15
000076e4393d2820  sub rsp, 0x30
000076e4393d2824  movaps [rsp], xmm14
000076e4393d2829  movaps [rsp+0x10], xmm6
000076e4393d282e  movaps [rsp+0x20], xmm2
000076e4393d2833  lea rdi, [rsp]
000076e4393d2837  mov esi, 0x00
000076e4393d283c  mov rax, 0x63DBDEB43530
000076e4393d2846  call rax
000076e4393d2848  movaps xmm14, [rsp]
000076e4393d284d  add rsp, 0x30
000076e4393d2851  vmovaps xmm0, [rsp]
000076e4393d2856  vmovaps xmm1, [rsp+0x10]
000076e4393d285c  vmovaps xmm2, [rsp+0x20]
000076e4393d2862  vmovaps xmm3, [rsp+0x30]
000076e4393d2868  vmovaps xmm4, [rsp+0x40]
000076e4393d286e  vmovaps xmm5, [rsp+0x50]
000076e4393d2874  vmovaps xmm6, [rsp+0x60]
000076e4393d287a  vmovaps xmm7, [rsp+0x70]
000076e4393d2880  vmovaps xmm8, [rsp+0x80]
000076e4393d2889  vmovaps xmm9, [rsp+0x90]
000076e4393d2892  vmovaps xmm10, [rsp+0xA0]
000076e4393d289b  vmovaps xmm11, [rsp+0xB0]
000076e4393d28a4  vmovaps xmm12, [rsp+0xC0]
000076e4393d28ad  vmovaps xmm13, [rsp+0xD0]
000076e4393d28b6  vmovaps xmm15, [rsp+0xE0]
000076e4393d28bf  add rsp, 0xF0
000076e4393d28c6  pop r11
000076e4393d28c8  pop r10
000076e4393d28ca  pop r9
000076e4393d28cc  pop r8
000076e4393d28ce  pop rsi
000076e4393d28cf  pop rdi
000076e4393d28d0  pop rdx
000076e4393d28d1  pop rcx
000076e4393d28d2  pop rax
000076e4393d28d3  add rsp, 0x08
000076e4393d28d7  jmp 0x000076E4393CFD72
000076e4393d28dc  sub rsp, 0x08
000076e4393d28e0  push rax
000076e4393d28e1  push rcx
000076e4393d28e2  push rdx
000076e4393d28e3  push rdi
000076e4393d28e4  push rsi
000076e4393d28e5  push r8
000076e4393d28e7  push r9
000076e4393d28e9  push r10
000076e4393d28eb  push r11
000076e4393d28ed  sub rsp, 0xF0
000076e4393d28f4  vmovaps [rsp], xmm0
000076e4393d28f9  vmovaps [rsp+0x10], xmm1
000076e4393d28ff  vmovaps [rsp+0x20], xmm2
000076e4393d2905  vmovaps [rsp+0x30], xmm3
000076e4393d290b  vmovaps [rsp+0x40], xmm4
000076e4393d2911  vmovaps [rsp+0x50], xmm5
000076e4393d2917  vmovaps [rsp+0x60], xmm7
000076e4393d291d  vmovaps [rsp+0x70], xmm8
000076e4393d2923  vmovaps [rsp+0x80], xmm9
000076e4393d292c  vmovaps [rsp+0x90], xmm10
000076e4393d2935  vmovaps [rsp+0xA0], xmm11
000076e4393d293e  vmovaps [rsp+0xB0], xmm12
000076e4393d2947  vmovaps [rsp+0xC0], xmm13
000076e4393d2950  vmovaps [rsp+0xD0], xmm14
000076e4393d2959  vmovaps [rsp+0xE0], xmm15
000076e4393d2962  sub rsp, 0x30
000076e4393d2966  movaps [rsp], xmm6
000076e4393d296a  movaps [rsp+0x10], xmm5
000076e4393d296f  movaps [rsp+0x20], xmm1
000076e4393d2974  lea rdi, [rsp]
000076e4393d2978  mov esi, 0x00
000076e4393d297d  mov rax, 0x63DBDEB43530
000076e4393d2987  call rax
000076e4393d2989  movaps xmm6, [rsp]
000076e4393d298d  add rsp, 0x30
000076e4393d2991  vmovaps xmm0, [rsp]
000076e4393d2996  vmovaps xmm1, [rsp+0x10]
000076e4393d299c  vmovaps xmm2, [rsp+0x20]
000076e4393d29a2  vmovaps xmm3, [rsp+0x30]
000076e4393d29a8  vmovaps xmm4, [rsp+0x40]
000076e4393d29ae  vmovaps xmm5, [rsp+0x50]
000076e4393d29b4  vmovaps xmm7, [rsp+0x60]
000076e4393d29ba  vmovaps xmm8, [rsp+0x70]
000076e4393d29c0  vmovaps xmm9, [rsp+0x80]
000076e4393d29c9  vmovaps xmm10, [rsp+0x90]
000076e4393d29d2  vmovaps xmm11, [rsp+0xA0]
000076e4393d29db  vmovaps xmm12, [rsp+0xB0]
000076e4393d29e4  vmovaps xmm13, [rsp+0xC0]
000076e4393d29ed  vmovaps xmm14, [rsp+0xD0]
000076e4393d29f6  vmovaps xmm15, [rsp+0xE0]
000076e4393d29ff  add rsp, 0xF0
000076e4393d2a06  pop r11
000076e4393d2a08  pop r10
000076e4393d2a0a  pop r9
000076e4393d2a0c  pop r8
000076e4393d2a0e  pop rsi
000076e4393d2a0f  pop rdi
000076e4393d2a10  pop rdx
000076e4393d2a11  pop rcx
000076e4393d2a12  pop rax
000076e4393d2a13  add rsp, 0x08
000076e4393d2a17  jmp 0x000076E4393CFD98
000076e4393d2a1c  sub rsp, 0x08
000076e4393d2a20  push rax
000076e4393d2a21  push rcx
000076e4393d2a22  push rdx
000076e4393d2a23  push rdi
000076e4393d2a24  push rsi
000076e4393d2a25  push r8
000076e4393d2a27  push r9
000076e4393d2a29  push r10
000076e4393d2a2b  push r11
000076e4393d2a2d  sub rsp, 0xF0
000076e4393d2a34  vmovaps [rsp], xmm0
000076e4393d2a39  vmovaps [rsp+0x10], xmm2
000076e4393d2a3f  vmovaps [rsp+0x20], xmm3
000076e4393d2a45  vmovaps [rsp+0x30], xmm4
000076e4393d2a4b  vmovaps [rsp+0x40], xmm5
000076e4393d2a51  vmovaps [rsp+0x50], xmm6
000076e4393d2a57  vmovaps [rsp+0x60], xmm7
000076e4393d2a5d  vmovaps [rsp+0x70], xmm8
000076e4393d2a63  vmovaps [rsp+0x80], xmm9
000076e4393d2a6c  vmovaps [rsp+0x90], xmm10
000076e4393d2a75  vmovaps [rsp+0xA0], xmm11
000076e4393d2a7e  vmovaps [rsp+0xB0], xmm12
000076e4393d2a87  vmovaps [rsp+0xC0], xmm13
000076e4393d2a90  vmovaps [rsp+0xD0], xmm14
000076e4393d2a99  vmovaps [rsp+0xE0], xmm15
000076e4393d2aa2  sub rsp, 0x30
000076e4393d2aa6  movaps [rsp], xmm1
000076e4393d2aaa  movaps [rsp+0x10], xmm5
000076e4393d2aaf  movaps [rsp+0x20], xmm13
000076e4393d2ab5  lea rdi, [rsp]
000076e4393d2ab9  mov esi, 0x00
000076e4393d2abe  mov rax, 0x63DBDEB43530
000076e4393d2ac8  call rax
000076e4393d2aca  movaps xmm1, [rsp]
000076e4393d2ace  add rsp, 0x30
000076e4393d2ad2  vmovaps xmm0, [rsp]
000076e4393d2ad7  vmovaps xmm2, [rsp+0x10]
000076e4393d2add  vmovaps xmm3, [rsp+0x20]
000076e4393d2ae3  vmovaps xmm4, [rsp+0x30]
000076e4393d2ae9  vmovaps xmm5, [rsp+0x40]
000076e4393d2aef  vmovaps xmm6, [rsp+0x50]
000076e4393d2af5  vmovaps xmm7, [rsp+0x60]
000076e4393d2afb  vmovaps xmm8, [rsp+0x70]
000076e4393d2b01  vmovaps xmm9, [rsp+0x80]
000076e4393d2b0a  vmovaps xmm10, [rsp+0x90]
000076e4393d2b13  vmovaps xmm11, [rsp+0xA0]
000076e4393d2b1c  vmovaps xmm12, [rsp+0xB0]
000076e4393d2b25  vmovaps xmm13, [rsp+0xC0]
000076e4393d2b2e  vmovaps xmm14, [rsp+0xD0]
000076e4393d2b37  vmovaps xmm15, [rsp+0xE0]
000076e4393d2b40  add rsp, 0xF0
000076e4393d2b47  pop r11
000076e4393d2b49  pop r10
000076e4393d2b4b  pop r9
000076e4393d2b4d  pop r8
000076e4393d2b4f  pop rsi
000076e4393d2b50  pop rdi
000076e4393d2b51  pop rdx
000076e4393d2b52  pop rcx
000076e4393d2b53  pop rax
000076e4393d2b54  add rsp, 0x08
000076e4393d2b58  jmp 0x000076E4393CFDB6
000076e4393d2b5d  sub rsp, 0x08
000076e4393d2b61  push rax
000076e4393d2b62  push rcx
000076e4393d2b63  push rdx
000076e4393d2b64  push rdi
000076e4393d2b65  push rsi
000076e4393d2b66  push r8
000076e4393d2b68  push r9
000076e4393d2b6a  push r10
000076e4393d2b6c  push r11
000076e4393d2b6e  sub rsp, 0xF0
000076e4393d2b75  vmovaps [rsp], xmm0
000076e4393d2b7a  vmovaps [rsp+0x10], xmm1
000076e4393d2b80  vmovaps [rsp+0x20], xmm2
000076e4393d2b86  vmovaps [rsp+0x30], xmm3
000076e4393d2b8c  vmovaps [rsp+0x40], xmm4
000076e4393d2b92  vmovaps [rsp+0x50], xmm6
000076e4393d2b98  vmovaps [rsp+0x60], xmm7
000076e4393d2b9e  vmovaps [rsp+0x70], xmm8
000076e4393d2ba4  vmovaps [rsp+0x80], xmm9
000076e4393d2bad  vmovaps [rsp+0x90], xmm10
000076e4393d2bb6  vmovaps [rsp+0xA0], xmm11
000076e4393d2bbf  vmovaps [rsp+0xB0], xmm12
000076e4393d2bc8  vmovaps [rsp+0xC0], xmm13
000076e4393d2bd1  vmovaps [rsp+0xD0], xmm14
000076e4393d2bda  vmovaps [rsp+0xE0], xmm15
000076e4393d2be3  sub rsp, 0x30
000076e4393d2be7  movaps [rsp], xmm5
000076e4393d2beb  movaps [rsp+0x10], xmm2
000076e4393d2bf0  movaps [rsp+0x20], xmm13
000076e4393d2bf6  lea rdi, [rsp]
000076e4393d2bfa  mov esi, 0x00
000076e4393d2bff  mov rax, 0x63DBDEB43530
000076e4393d2c09  call rax
000076e4393d2c0b  movaps xmm5, [rsp]
000076e4393d2c0f  add rsp, 0x30
000076e4393d2c13  vmovaps xmm0, [rsp]
000076e4393d2c18  vmovaps xmm1, [rsp+0x10]
000076e4393d2c1e  vmovaps xmm2, [rsp+0x20]
000076e4393d2c24  vmovaps xmm3, [rsp+0x30]
000076e4393d2c2a  vmovaps xmm4, [rsp+0x40]
000076e4393d2c30  vmovaps xmm6, [rsp+0x50]
000076e4393d2c36  vmovaps xmm7, [rsp+0x60]
000076e4393d2c3c  vmovaps xmm8, [rsp+0x70]
000076e4393d2c42  vmovaps xmm9, [rsp+0x80]
000076e4393d2c4b  vmovaps xmm10, [rsp+0x90]
000076e4393d2c54  vmovaps xmm11, [rsp+0xA0]
000076e4393d2c5d  vmovaps xmm12, [rsp+0xB0]
000076e4393d2c66  vmovaps xmm13, [rsp+0xC0]
000076e4393d2c6f  vmovaps xmm14, [rsp+0xD0]
000076e4393d2c78  vmovaps xmm15, [rsp+0xE0]
000076e4393d2c81  add rsp, 0xF0
000076e4393d2c88  pop r11
000076e4393d2c8a  pop r10
000076e4393d2c8c  pop r9
000076e4393d2c8e  pop r8
000076e4393d2c90  pop rsi
000076e4393d2c91  pop rdi
000076e4393d2c92  pop rdx
000076e4393d2c93  pop rcx
000076e4393d2c94  pop rax
000076e4393d2c95  add rsp, 0x08
000076e4393d2c99  jmp 0x000076E4393CFDEC
000076e4393d2c9e  sub rsp, 0x08
000076e4393d2ca2  push rax
000076e4393d2ca3  push rcx
000076e4393d2ca4  push rdx
000076e4393d2ca5  push rdi
000076e4393d2ca6  push rsi
000076e4393d2ca7  push r8
000076e4393d2ca9  push r9
000076e4393d2cab  push r10
000076e4393d2cad  push r11
000076e4393d2caf  sub rsp, 0xF0
000076e4393d2cb6  vmovaps [rsp], xmm0
000076e4393d2cbb  vmovaps [rsp+0x10], xmm1
000076e4393d2cc1  vmovaps [rsp+0x20], xmm2
000076e4393d2cc7  vmovaps [rsp+0x30], xmm3
000076e4393d2ccd  vmovaps [rsp+0x40], xmm4
000076e4393d2cd3  vmovaps [rsp+0x50], xmm5
000076e4393d2cd9  vmovaps [rsp+0x60], xmm6
000076e4393d2cdf  vmovaps [rsp+0x70], xmm7
000076e4393d2ce5  vmovaps [rsp+0x80], xmm8
000076e4393d2cee  vmovaps [rsp+0x90], xmm9
000076e4393d2cf7  vmovaps [rsp+0xA0], xmm10
000076e4393d2d00  vmovaps [rsp+0xB0], xmm11
000076e4393d2d09  vmovaps [rsp+0xC0], xmm12
000076e4393d2d12  vmovaps [rsp+0xD0], xmm14
000076e4393d2d1b  vmovaps [rsp+0xE0], xmm15
000076e4393d2d24  sub rsp, 0x30
000076e4393d2d28  movaps [rsp], xmm13
000076e4393d2d2d  movaps [rsp+0x10], xmm10
000076e4393d2d33  movaps [rsp+0x20], xmm1
000076e4393d2d38  lea rdi, [rsp]
000076e4393d2d3c  mov esi, 0x00
000076e4393d2d41  mov rax, 0x63DBDEB43530
000076e4393d2d4b  call rax
000076e4393d2d4d  movaps xmm13, [rsp]
000076e4393d2d52  add rsp, 0x30
000076e4393d2d56  vmovaps xmm0, [rsp]
000076e4393d2d5b  vmovaps xmm1, [rsp+0x10]
000076e4393d2d61  vmovaps xmm2, [rsp+0x20]
000076e4393d2d67  vmovaps xmm3, [rsp+0x30]
000076e4393d2d6d  vmovaps xmm4, [rsp+0x40]
000076e4393d2d73  vmovaps xmm5, [rsp+0x50]
000076e4393d2d79  vmovaps xmm6, [rsp+0x60]
000076e4393d2d7f  vmovaps xmm7, [rsp+0x70]
000076e4393d2d85  vmovaps xmm8, [rsp+0x80]
000076e4393d2d8e  vmovaps xmm9, [rsp+0x90]
000076e4393d2d97  vmovaps xmm10, [rsp+0xA0]
000076e4393d2da0  vmovaps xmm11, [rsp+0xB0]
000076e4393d2da9  vmovaps xmm12, [rsp+0xC0]
000076e4393d2db2  vmovaps xmm14, [rsp+0xD0]
000076e4393d2dbb  vmovaps xmm15, [rsp+0xE0]
000076e4393d2dc4  add rsp, 0xF0
000076e4393d2dcb  pop r11
000076e4393d2dcd  pop r10
000076e4393d2dcf  pop r9
000076e4393d2dd1  pop r8
000076e4393d2dd3  pop rsi
000076e4393d2dd4  pop rdi
000076e4393d2dd5  pop rdx
000076e4393d2dd6  pop rcx
000076e4393d2dd7  pop rax
000076e4393d2dd8  add rsp, 0x08
000076e4393d2ddc  jmp 0x000076E4393CFE15
000076e4393d2de1  sub rsp, 0x08
000076e4393d2de5  push rax
000076e4393d2de6  push rcx
000076e4393d2de7  push rdx
000076e4393d2de8  push rdi
000076e4393d2de9  push rsi
000076e4393d2dea  push r8
000076e4393d2dec  push r9
000076e4393d2dee  push r10
000076e4393d2df0  push r11
000076e4393d2df2  sub rsp, 0xF0
000076e4393d2df9  vmovaps [rsp], xmm0
000076e4393d2dfe  vmovaps [rsp+0x10], xmm2
000076e4393d2e04  vmovaps [rsp+0x20], xmm3
000076e4393d2e0a  vmovaps [rsp+0x30], xmm4
000076e4393d2e10  vmovaps [rsp+0x40], xmm5
000076e4393d2e16  vmovaps [rsp+0x50], xmm6
000076e4393d2e1c  vmovaps [rsp+0x60], xmm7
000076e4393d2e22  vmovaps [rsp+0x70], xmm8
000076e4393d2e28  vmovaps [rsp+0x80], xmm9
000076e4393d2e31  vmovaps [rsp+0x90], xmm10
000076e4393d2e3a  vmovaps [rsp+0xA0], xmm11
000076e4393d2e43  vmovaps [rsp+0xB0], xmm12
000076e4393d2e4c  vmovaps [rsp+0xC0], xmm13
000076e4393d2e55  vmovaps [rsp+0xD0], xmm14
000076e4393d2e5e  vmovaps [rsp+0xE0], xmm15
000076e4393d2e67  sub rsp, 0x30
000076e4393d2e6b  movaps [rsp], xmm1
000076e4393d2e6f  movaps [rsp+0x10], xmm15
000076e4393d2e75  movaps [rsp+0x20], xmm10
000076e4393d2e7b  lea rdi, [rsp]
000076e4393d2e7f  mov esi, 0x00
000076e4393d2e84  mov rax, 0x63DBDEB43530
000076e4393d2e8e  call rax
000076e4393d2e90  movaps xmm1, [rsp]
000076e4393d2e94  add rsp, 0x30
000076e4393d2e98  vmovaps xmm0, [rsp]
000076e4393d2e9d  vmovaps xmm2, [rsp+0x10]
000076e4393d2ea3  vmovaps xmm3, [rsp+0x20]
000076e4393d2ea9  vmovaps xmm4, [rsp+0x30]
000076e4393d2eaf  vmovaps xmm5, [rsp+0x40]
000076e4393d2eb5  vmovaps xmm6, [rsp+0x50]
000076e4393d2ebb  vmovaps xmm7, [rsp+0x60]
000076e4393d2ec1  vmovaps xmm8, [rsp+0x70]
000076e4393d2ec7  vmovaps xmm9, [rsp+0x80]
000076e4393d2ed0  vmovaps xmm10, [rsp+0x90]
000076e4393d2ed9  vmovaps xmm11, [rsp+0xA0]
000076e4393d2ee2  vmovaps xmm12, [rsp+0xB0]
000076e4393d2eeb  vmovaps xmm13, [rsp+0xC0]
000076e4393d2ef4  vmovaps xmm14, [rsp+0xD0]
000076e4393d2efd  vmovaps xmm15, [rsp+0xE0]
000076e4393d2f06  add rsp, 0xF0
000076e4393d2f0d  pop r11
000076e4393d2f0f  pop r10
000076e4393d2f11  pop r9
000076e4393d2f13  pop r8
000076e4393d2f15  pop rsi
000076e4393d2f16  pop rdi
000076e4393d2f17  pop rdx
000076e4393d2f18  pop rcx
000076e4393d2f19  pop rax
000076e4393d2f1a  add rsp, 0x08
000076e4393d2f1e  jmp 0x000076E4393CFE34
000076e4393d2f23  sub rsp, 0x08
000076e4393d2f27  push rax
000076e4393d2f28  push rcx
000076e4393d2f29  push rdx
000076e4393d2f2a  push rdi
000076e4393d2f2b  push rsi
000076e4393d2f2c  push r8
000076e4393d2f2e  push r9
000076e4393d2f30  push r10
000076e4393d2f32  push r11
000076e4393d2f34  sub rsp, 0xF0
000076e4393d2f3b  vmovaps [rsp], xmm0
000076e4393d2f40  vmovaps [rsp+0x10], xmm1
000076e4393d2f46  vmovaps [rsp+0x20], xmm2
000076e4393d2f4c  vmovaps [rsp+0x30], xmm3
000076e4393d2f52  vmovaps [rsp+0x40], xmm4
000076e4393d2f58  vmovaps [rsp+0x50], xmm5
000076e4393d2f5e  vmovaps [rsp+0x60], xmm6
000076e4393d2f64  vmovaps [rsp+0x70], xmm7
000076e4393d2f6a  vmovaps [rsp+0x80], xmm8
000076e4393d2f73  vmovaps [rsp+0x90], xmm9
000076e4393d2f7c  vmovaps [rsp+0xA0], xmm10
000076e4393d2f85  vmovaps [rsp+0xB0], xmm11
000076e4393d2f8e  vmovaps [rsp+0xC0], xmm12
000076e4393d2f97  vmovaps [rsp+0xD0], xmm13
000076e4393d2fa0  vmovaps [rsp+0xE0], xmm14
000076e4393d2fa9  sub rsp, 0x30
000076e4393d2fad  movaps [rsp], xmm15
000076e4393d2fb2  movaps [rsp+0x10], xmm10
000076e4393d2fb8  movaps [rsp+0x20], xmm11
000076e4393d2fbe  lea rdi, [rsp]
000076e4393d2fc2  mov esi, 0x00
000076e4393d2fc7  mov rax, 0x63DBDEB43530
000076e4393d2fd1  call rax
000076e4393d2fd3  movaps xmm15, [rsp]
000076e4393d2fd8  add rsp, 0x30
000076e4393d2fdc  vmovaps xmm0, [rsp]
000076e4393d2fe1  vmovaps xmm1, [rsp+0x10]
000076e4393d2fe7  vmovaps xmm2, [rsp+0x20]
000076e4393d2fed  vmovaps xmm3, [rsp+0x30]
000076e4393d2ff3  vmovaps xmm4, [rsp+0x40]
000076e4393d2ff9  vmovaps xmm5, [rsp+0x50]
000076e4393d2fff  vmovaps xmm6, [rsp+0x60]
000076e4393d3005  vmovaps xmm7, [rsp+0x70]
000076e4393d300b  vmovaps xmm8, [rsp+0x80]
000076e4393d3014  vmovaps xmm9, [rsp+0x90]
000076e4393d301d  vmovaps xmm10, [rsp+0xA0]
000076e4393d3026  vmovaps xmm11, [rsp+0xB0]
000076e4393d302f  vmovaps xmm12, [rsp+0xC0]
000076e4393d3038  vmovaps xmm13, [rsp+0xD0]
000076e4393d3041  vmovaps xmm14, [rsp+0xE0]
000076e4393d304a  add rsp, 0xF0
000076e4393d3051  pop r11
000076e4393d3053  pop r10
000076e4393d3055  pop r9
000076e4393d3057  pop r8
000076e4393d3059  pop rsi
000076e4393d305a  pop rdi
000076e4393d305b  pop rdx
000076e4393d305c  pop rcx
000076e4393d305d  pop rax
000076e4393d305e  add rsp, 0x08
000076e4393d3062  jmp 0x000076E4393CFE57
000076e4393d3067  sub rsp, 0x08
000076e4393d306b  push rax
000076e4393d306c  push rcx
000076e4393d306d  push rdx
000076e4393d306e  push rdi
000076e4393d306f  push rsi
000076e4393d3070  push r8
000076e4393d3072  push r9
000076e4393d3074  push r10
000076e4393d3076  push r11
000076e4393d3078  sub rsp, 0xF0
000076e4393d307f  vmovaps [rsp], xmm0
000076e4393d3084  vmovaps [rsp+0x10], xmm1
000076e4393d308a  vmovaps [rsp+0x20], xmm2
000076e4393d3090  vmovaps [rsp+0x30], xmm3
000076e4393d3096  vmovaps [rsp+0x40], xmm4
000076e4393d309c  vmovaps [rsp+0x50], xmm5
000076e4393d30a2  vmovaps [rsp+0x60], xmm6
000076e4393d30a8  vmovaps [rsp+0x70], xmm7
000076e4393d30ae  vmovaps [rsp+0x80], xmm8
000076e4393d30b7  vmovaps [rsp+0x90], xmm9
000076e4393d30c0  vmovaps [rsp+0xA0], xmm11
000076e4393d30c9  vmovaps [rsp+0xB0], xmm12
000076e4393d30d2  vmovaps [rsp+0xC0], xmm13
000076e4393d30db  vmovaps [rsp+0xD0], xmm14
000076e4393d30e4  vmovaps [rsp+0xE0], xmm15
000076e4393d30ed  sub rsp, 0x30
000076e4393d30f1  movaps [rsp], xmm10
000076e4393d30f6  movaps [rsp+0x10], xmm12
000076e4393d30fc  movaps [rsp+0x20], xmm11
000076e4393d3102  lea rdi, [rsp]
000076e4393d3106  mov esi, 0x00
000076e4393d310b  mov rax, 0x63DBDEB43530
000076e4393d3115  call rax
000076e4393d3117  movaps xmm10, [rsp]
000076e4393d311c  add rsp, 0x30
000076e4393d3120  vmovaps xmm0, [rsp]
000076e4393d3125  vmovaps xmm1, [rsp+0x10]
000076e4393d312b  vmovaps xmm2, [rsp+0x20]
000076e4393d3131  vmovaps xmm3, [rsp+0x30]
000076e4393d3137  vmovaps xmm4, [rsp+0x40]
000076e4393d313d  vmovaps xmm5, [rsp+0x50]
000076e4393d3143  vmovaps xmm6, [rsp+0x60]
000076e4393d3149  vmovaps xmm7, [rsp+0x70]
000076e4393d314f  vmovaps xmm8, [rsp+0x80]
000076e4393d3158  vmovaps xmm9, [rsp+0x90]
000076e4393d3161  vmovaps xmm11, [rsp+0xA0]
000076e4393d316a  vmovaps xmm12, [rsp+0xB0]
000076e4393d3173  vmovaps xmm13, [rsp+0xC0]
000076e4393d317c  vmovaps xmm14, [rsp+0xD0]
000076e4393d3185  vmovaps xmm15, [rsp+0xE0]
000076e4393d318e  add rsp, 0xF0
000076e4393d3195  pop r11
000076e4393d3197  pop r10
000076e4393d3199  pop r9
000076e4393d319b  pop r8
000076e4393d319d  pop rsi
000076e4393d319e  pop rdi
000076e4393d319f  pop rdx
000076e4393d31a0  pop rcx
000076e4393d31a1  pop rax
000076e4393d31a2  add rsp, 0x08
000076e4393d31a6  jmp 0x000076E4393CFE80
000076e4393d31ab  sub rsp, 0x08
000076e4393d31af  push rax
000076e4393d31b0  push rcx
000076e4393d31b1  push rdx
000076e4393d31b2  push rdi
000076e4393d31b3  push rsi
000076e4393d31b4  push r8
000076e4393d31b6  push r9
000076e4393d31b8  push r10
000076e4393d31ba  push r11
000076e4393d31bc  sub rsp, 0xF0
000076e4393d31c3  vmovaps [rsp], xmm0
000076e4393d31c8  vmovaps [rsp+0x10], xmm1
000076e4393d31ce  vmovaps [rsp+0x20], xmm2
000076e4393d31d4  vmovaps [rsp+0x30], xmm3
000076e4393d31da  vmovaps [rsp+0x40], xmm4
000076e4393d31e0  vmovaps [rsp+0x50], xmm5
000076e4393d31e6  vmovaps [rsp+0x60], xmm6
000076e4393d31ec  vmovaps [rsp+0x70], xmm7
000076e4393d31f2  vmovaps [rsp+0x80], xmm8
000076e4393d31fb  vmovaps [rsp+0x90], xmm9
000076e4393d3204  vmovaps [rsp+0xA0], xmm10
000076e4393d320d  vmovaps [rsp+0xB0], xmm12
000076e4393d3216  vmovaps [rsp+0xC0], xmm13
000076e4393d321f  vmovaps [rsp+0xD0], xmm14
000076e4393d3228  vmovaps [rsp+0xE0], xmm15
000076e4393d3231  sub rsp, 0x30
000076e4393d3235  movaps [rsp], xmm11
000076e4393d323a  movaps [rsp+0x10], xmm2
000076e4393d323f  movaps [rsp+0x20], xmm12
000076e4393d3245  lea rdi, [rsp]
000076e4393d3249  mov esi, 0x00
000076e4393d324e  mov rax, 0x63DBDEB43530
000076e4393d3258  call rax
000076e4393d325a  movaps xmm11, [rsp]
000076e4393d325f  add rsp, 0x30
000076e4393d3263  vmovaps xmm0, [rsp]
000076e4393d3268  vmovaps xmm1, [rsp+0x10]
000076e4393d326e  vmovaps xmm2, [rsp+0x20]
000076e4393d3274  vmovaps xmm3, [rsp+0x30]
000076e4393d327a  vmovaps xmm4, [rsp+0x40]
000076e4393d3280  vmovaps xmm5, [rsp+0x50]
000076e4393d3286  vmovaps xmm6, [rsp+0x60]
000076e4393d328c  vmovaps xmm7, [rsp+0x70]
000076e4393d3292  vmovaps xmm8, [rsp+0x80]
000076e4393d329b  vmovaps xmm9, [rsp+0x90]
000076e4393d32a4  vmovaps xmm10, [rsp+0xA0]
000076e4393d32ad  vmovaps xmm12, [rsp+0xB0]
000076e4393d32b6  vmovaps xmm13, [rsp+0xC0]
000076e4393d32bf  vmovaps xmm14, [rsp+0xD0]
000076e4393d32c8  vmovaps xmm15, [rsp+0xE0]
000076e4393d32d1  add rsp, 0xF0
000076e4393d32d8  pop r11
000076e4393d32da  pop r10
000076e4393d32dc  pop r9
000076e4393d32de  pop r8
000076e4393d32e0  pop rsi
000076e4393d32e1  pop rdi
000076e4393d32e2  pop rdx
000076e4393d32e3  pop rcx
000076e4393d32e4  pop rax
000076e4393d32e5  add rsp, 0x08
000076e4393d32e9  jmp 0x000076E4393CFEB8
000076e4393d32ee  sub rsp, 0x08
000076e4393d32f2  push rax
000076e4393d32f3  push rcx
000076e4393d32f4  push rdx
000076e4393d32f5  push rdi
000076e4393d32f6  push rsi
000076e4393d32f7  push r8
000076e4393d32f9  push r9
000076e4393d32fb  push r10
000076e4393d32fd  push r11
000076e4393d32ff  sub rsp, 0xF0
000076e4393d3306  vmovaps [rsp], xmm0
000076e4393d330b  vmovaps [rsp+0x10], xmm2
000076e4393d3311  vmovaps [rsp+0x20], xmm3
000076e4393d3317  vmovaps [rsp+0x30], xmm4
000076e4393d331d  vmovaps [rsp+0x40], xmm5
000076e4393d3323  vmovaps [rsp+0x50], xmm6
000076e4393d3329  vmovaps [rsp+0x60], xmm7
000076e4393d332f  vmovaps [rsp+0x70], xmm8
000076e4393d3335  vmovaps [rsp+0x80], xmm9
000076e4393d333e  vmovaps [rsp+0x90], xmm10
000076e4393d3347  vmovaps [rsp+0xA0], xmm11
000076e4393d3350  vmovaps [rsp+0xB0], xmm12
000076e4393d3359  vmovaps [rsp+0xC0], xmm13
000076e4393d3362  vmovaps [rsp+0xD0], xmm14
000076e4393d336b  vmovaps [rsp+0xE0], xmm15
000076e4393d3374  sub rsp, 0x30
000076e4393d3378  movaps [rsp], xmm1
000076e4393d337c  movaps [rsp+0x10], xmm14
000076e4393d3382  movaps [rsp+0x20], xmm6
000076e4393d3387  lea rdi, [rsp]
000076e4393d338b  mov esi, 0x00
000076e4393d3390  mov rax, 0x63DBDEB43530
000076e4393d339a  call rax
000076e4393d339c  movaps xmm1, [rsp]
000076e4393d33a0  add rsp, 0x30
000076e4393d33a4  vmovaps xmm0, [rsp]
000076e4393d33a9  vmovaps xmm2, [rsp+0x10]
000076e4393d33af  vmovaps xmm3, [rsp+0x20]
000076e4393d33b5  vmovaps xmm4, [rsp+0x30]
000076e4393d33bb  vmovaps xmm5, [rsp+0x40]
000076e4393d33c1  vmovaps xmm6, [rsp+0x50]
000076e4393d33c7  vmovaps xmm7, [rsp+0x60]
000076e4393d33cd  vmovaps xmm8, [rsp+0x70]
000076e4393d33d3  vmovaps xmm9, [rsp+0x80]
000076e4393d33dc  vmovaps xmm10, [rsp+0x90]
000076e4393d33e5  vmovaps xmm11, [rsp+0xA0]
000076e4393d33ee  vmovaps xmm12, [rsp+0xB0]
000076e4393d33f7  vmovaps xmm13, [rsp+0xC0]
000076e4393d3400  vmovaps xmm14, [rsp+0xD0]
000076e4393d3409  vmovaps xmm15, [rsp+0xE0]
000076e4393d3412  add rsp, 0xF0
000076e4393d3419  pop r11
000076e4393d341b  pop r10
000076e4393d341d  pop r9
000076e4393d341f  pop r8
000076e4393d3421  pop rsi
000076e4393d3422  pop rdi
000076e4393d3423  pop rdx
000076e4393d3424  pop rcx
000076e4393d3425  pop rax
000076e4393d3426  add rsp, 0x08
000076e4393d342a  jmp 0x000076E4393CFED1
000076e4393d342f  sub rsp, 0x08
000076e4393d3433  push rax
000076e4393d3434  push rcx
000076e4393d3435  push rdx
000076e4393d3436  push rdi
000076e4393d3437  push rsi
000076e4393d3438  push r8
000076e4393d343a  push r9
000076e4393d343c  push r10
000076e4393d343e  push r11
000076e4393d3440  sub rsp, 0xF0
000076e4393d3447  vmovaps [rsp], xmm0
000076e4393d344c  vmovaps [rsp+0x10], xmm1
000076e4393d3452  vmovaps [rsp+0x20], xmm2
000076e4393d3458  vmovaps [rsp+0x30], xmm3
000076e4393d345e  vmovaps [rsp+0x40], xmm4
000076e4393d3464  vmovaps [rsp+0x50], xmm5
000076e4393d346a  vmovaps [rsp+0x60], xmm6
000076e4393d3470  vmovaps [rsp+0x70], xmm7
000076e4393d3476  vmovaps [rsp+0x80], xmm8
000076e4393d347f  vmovaps [rsp+0x90], xmm9
000076e4393d3488  vmovaps [rsp+0xA0], xmm10
000076e4393d3491  vmovaps [rsp+0xB0], xmm11
000076e4393d349a  vmovaps [rsp+0xC0], xmm12
000076e4393d34a3  vmovaps [rsp+0xD0], xmm13
000076e4393d34ac  vmovaps [rsp+0xE0], xmm15
000076e4393d34b5  sub rsp, 0x30
000076e4393d34b9  movaps [rsp], xmm14
000076e4393d34be  movaps [rsp+0x10], xmm12
000076e4393d34c4  movaps [rsp+0x20], xmm5
000076e4393d34c9  lea rdi, [rsp]
000076e4393d34cd  mov esi, 0x00
000076e4393d34d2  mov rax, 0x63DBDEB43530
000076e4393d34dc  call rax
000076e4393d34de  movaps xmm14, [rsp]
000076e4393d34e3  add rsp, 0x30
000076e4393d34e7  vmovaps xmm0, [rsp]
000076e4393d34ec  vmovaps xmm1, [rsp+0x10]
000076e4393d34f2  vmovaps xmm2, [rsp+0x20]
000076e4393d34f8  vmovaps xmm3, [rsp+0x30]
000076e4393d34fe  vmovaps xmm4, [rsp+0x40]
000076e4393d3504  vmovaps xmm5, [rsp+0x50]
000076e4393d350a  vmovaps xmm6, [rsp+0x60]
000076e4393d3510  vmovaps xmm7, [rsp+0x70]
000076e4393d3516  vmovaps xmm8, [rsp+0x80]
000076e4393d351f  vmovaps xmm9, [rsp+0x90]
000076e4393d3528  vmovaps xmm10, [rsp+0xA0]
000076e4393d3531  vmovaps xmm11, [rsp+0xB0]
000076e4393d353a  vmovaps xmm12, [rsp+0xC0]
000076e4393d3543  vmovaps xmm13, [rsp+0xD0]
000076e4393d354c  vmovaps xmm15, [rsp+0xE0]
000076e4393d3555  add rsp, 0xF0
000076e4393d355c  pop r11
000076e4393d355e  pop r10
000076e4393d3560  pop r9
000076e4393d3562  pop r8
000076e4393d3564  pop rsi
000076e4393d3565  pop rdi
000076e4393d3566  pop rdx
000076e4393d3567  pop rcx
000076e4393d3568  pop rax
000076e4393d3569  add rsp, 0x08
000076e4393d356d  jmp 0x000076E4393CFEF1
000076e4393d3572  sub rsp, 0x08
000076e4393d3576  push rax
000076e4393d3577  push rcx
000076e4393d3578  push rdx
000076e4393d3579  push rdi
000076e4393d357a  push rsi
000076e4393d357b  push r8
000076e4393d357d  push r9
000076e4393d357f  push r10
000076e4393d3581  push r11
000076e4393d3583  sub rsp, 0xF0
000076e4393d358a  vmovaps [rsp], xmm0
000076e4393d358f  vmovaps [rsp+0x10], xmm1
000076e4393d3595  vmovaps [rsp+0x20], xmm2
000076e4393d359b  vmovaps [rsp+0x30], xmm3
000076e4393d35a1  vmovaps [rsp+0x40], xmm4
000076e4393d35a7  vmovaps [rsp+0x50], xmm5
000076e4393d35ad  vmovaps [rsp+0x60], xmm7
000076e4393d35b3  vmovaps [rsp+0x70], xmm8
000076e4393d35b9  vmovaps [rsp+0x80], xmm9
000076e4393d35c2  vmovaps [rsp+0x90], xmm10
000076e4393d35cb  vmovaps [rsp+0xA0], xmm11
000076e4393d35d4  vmovaps [rsp+0xB0], xmm12
000076e4393d35dd  vmovaps [rsp+0xC0], xmm13
000076e4393d35e6  vmovaps [rsp+0xD0], xmm14
000076e4393d35ef  vmovaps [rsp+0xE0], xmm15
000076e4393d35f8  sub rsp, 0x30
000076e4393d35fc  movaps [rsp], xmm6
000076e4393d3600  movaps [rsp+0x10], xmm9
000076e4393d3606  movaps [rsp+0x20], xmm12
000076e4393d360c  lea rdi, [rsp]
000076e4393d3610  mov esi, 0x00
000076e4393d3615  mov rax, 0x63DBDEB43530
000076e4393d361f  call rax
000076e4393d3621  movaps xmm6, [rsp]
000076e4393d3625  add rsp, 0x30
000076e4393d3629  vmovaps xmm0, [rsp]
000076e4393d362e  vmovaps xmm1, [rsp+0x10]
000076e4393d3634  vmovaps xmm2, [rsp+0x20]
000076e4393d363a  vmovaps xmm3, [rsp+0x30]
000076e4393d3640  vmovaps xmm4, [rsp+0x40]
000076e4393d3646  vmovaps xmm5, [rsp+0x50]
000076e4393d364c  vmovaps xmm7, [rsp+0x60]
000076e4393d3652  vmovaps xmm8, [rsp+0x70]
000076e4393d3658  vmovaps xmm9, [rsp+0x80]
000076e4393d3661  vmovaps xmm10, [rsp+0x90]
000076e4393d366a  vmovaps xmm11, [rsp+0xA0]
000076e4393d3673  vmovaps xmm12, [rsp+0xB0]
000076e4393d367c  vmovaps xmm13, [rsp+0xC0]
000076e4393d3685  vmovaps xmm14, [rsp+0xD0]
000076e4393d368e  vmovaps xmm15, [rsp+0xE0]
000076e4393d3697  add rsp, 0xF0
000076e4393d369e  pop r11
000076e4393d36a0  pop r10
000076e4393d36a2  pop r9
000076e4393d36a4  pop r8
000076e4393d36a6  pop rsi
000076e4393d36a7  pop rdi
000076e4393d36a8  pop rdx
000076e4393d36a9  pop rcx
000076e4393d36aa  pop rax
000076e4393d36ab  add rsp, 0x08
000076e4393d36af  jmp 0x000076E4393CFF19
000076e4393d36b4  sub rsp, 0x08
000076e4393d36b8  push rax
000076e4393d36b9  push rcx
000076e4393d36ba  push rdx
000076e4393d36bb  push rdi
000076e4393d36bc  push rsi
000076e4393d36bd  push r8
000076e4393d36bf  push r9
000076e4393d36c1  push r10
000076e4393d36c3  push r11
000076e4393d36c5  sub rsp, 0xF0
000076e4393d36cc  vmovaps [rsp], xmm0
000076e4393d36d1  vmovaps [rsp+0x10], xmm1
000076e4393d36d7  vmovaps [rsp+0x20], xmm2
000076e4393d36dd  vmovaps [rsp+0x30], xmm3
000076e4393d36e3  vmovaps [rsp+0x40], xmm4
000076e4393d36e9  vmovaps [rsp+0x50], xmm5
000076e4393d36ef  vmovaps [rsp+0x60], xmm6
000076e4393d36f5  vmovaps [rsp+0x70], xmm7
000076e4393d36fb  vmovaps [rsp+0x80], xmm8
000076e4393d3704  vmovaps [rsp+0x90], xmm9
000076e4393d370d  vmovaps [rsp+0xA0], xmm10
000076e4393d3716  vmovaps [rsp+0xB0], xmm11
000076e4393d371f  vmovaps [rsp+0xC0], xmm13
000076e4393d3728  vmovaps [rsp+0xD0], xmm14
000076e4393d3731  vmovaps [rsp+0xE0], xmm15
000076e4393d373a  sub rsp, 0x30
000076e4393d373e  movaps [rsp], xmm12
000076e4393d3743  movaps [rsp+0x10], xmm15
000076e4393d3749  movaps [rsp+0x20], xmm13
000076e4393d374f  lea rdi, [rsp]
000076e4393d3753  mov esi, 0x00
000076e4393d3758  mov rax, 0x63DBDEB43530
000076e4393d3762  call rax
000076e4393d3764  movaps xmm12, [rsp]
000076e4393d3769  add rsp, 0x30
000076e4393d376d  vmovaps xmm0, [rsp]
000076e4393d3772  vmovaps xmm1, [rsp+0x10]
000076e4393d3778  vmovaps xmm2, [rsp+0x20]
000076e4393d377e  vmovaps xmm3, [rsp+0x30]
000076e4393d3784  vmovaps xmm4, [rsp+0x40]
000076e4393d378a  vmovaps xmm5, [rsp+0x50]
000076e4393d3790  vmovaps xmm6, [rsp+0x60]
000076e4393d3796  vmovaps xmm7, [rsp+0x70]
000076e4393d379c  vmovaps xmm8, [rsp+0x80]
000076e4393d37a5  vmovaps xmm9, [rsp+0x90]
000076e4393d37ae  vmovaps xmm10, [rsp+0xA0]
000076e4393d37b7  vmovaps xmm11, [rsp+0xB0]
000076e4393d37c0  vmovaps xmm13, [rsp+0xC0]
000076e4393d37c9  vmovaps xmm14, [rsp+0xD0]
000076e4393d37d2  vmovaps xmm15, [rsp+0xE0]
000076e4393d37db  add rsp, 0xF0
000076e4393d37e2  pop r11
000076e4393d37e4  pop r10
000076e4393d37e6  pop r9
000076e4393d37e8  pop r8
000076e4393d37ea  pop rsi
000076e4393d37eb  pop rdi
000076e4393d37ec  pop rdx
000076e4393d37ed  pop rcx
000076e4393d37ee  pop rax
000076e4393d37ef  add rsp, 0x08
000076e4393d37f3  jmp 0x000076E4393CFF34
000076e4393d37f8  sub rsp, 0x08
000076e4393d37fc  push rax
000076e4393d37fd  push rcx
000076e4393d37fe  push rdx
000076e4393d37ff  push rdi
000076e4393d3800  push rsi
000076e4393d3801  push r8
000076e4393d3803  push r9
000076e4393d3805  push r10
000076e4393d3807  push r11
000076e4393d3809  sub rsp, 0xF0
000076e4393d3810  vmovaps [rsp], xmm0
000076e4393d3815  vmovaps [rsp+0x10], xmm1
000076e4393d381b  vmovaps [rsp+0x20], xmm2
000076e4393d3821  vmovaps [rsp+0x30], xmm3
000076e4393d3827  vmovaps [rsp+0x40], xmm4
000076e4393d382d  vmovaps [rsp+0x50], xmm5
000076e4393d3833  vmovaps [rsp+0x60], xmm6
000076e4393d3839  vmovaps [rsp+0x70], xmm7
000076e4393d383f  vmovaps [rsp+0x80], xmm8
000076e4393d3848  vmovaps [rsp+0x90], xmm9
000076e4393d3851  vmovaps [rsp+0xA0], xmm10
000076e4393d385a  vmovaps [rsp+0xB0], xmm11
000076e4393d3863  vmovaps [rsp+0xC0], xmm12
000076e4393d386c  vmovaps [rsp+0xD0], xmm13
000076e4393d3875  vmovaps [rsp+0xE0], xmm14
000076e4393d387e  sub rsp, 0x30
000076e4393d3882  movaps [rsp], xmm15
000076e4393d3887  movaps [rsp+0x10], xmm13
000076e4393d388d  movaps [rsp+0x20], xmm10
000076e4393d3893  lea rdi, [rsp]
000076e4393d3897  mov esi, 0x00
000076e4393d389c  mov rax, 0x63DBDEB43530
000076e4393d38a6  call rax
000076e4393d38a8  movaps xmm15, [rsp]
000076e4393d38ad  add rsp, 0x30
000076e4393d38b1  vmovaps xmm0, [rsp]
000076e4393d38b6  vmovaps xmm1, [rsp+0x10]
000076e4393d38bc  vmovaps xmm2, [rsp+0x20]
000076e4393d38c2  vmovaps xmm3, [rsp+0x30]
000076e4393d38c8  vmovaps xmm4, [rsp+0x40]
000076e4393d38ce  vmovaps xmm5, [rsp+0x50]
000076e4393d38d4  vmovaps xmm6, [rsp+0x60]
000076e4393d38da  vmovaps xmm7, [rsp+0x70]
000076e4393d38e0  vmovaps xmm8, [rsp+0x80]
000076e4393d38e9  vmovaps xmm9, [rsp+0x90]
000076e4393d38f2  vmovaps xmm10, [rsp+0xA0]
000076e4393d38fb  vmovaps xmm11, [rsp+0xB0]
000076e4393d3904  vmovaps xmm12, [rsp+0xC0]
000076e4393d390d  vmovaps xmm13, [rsp+0xD0]
000076e4393d3916  vmovaps xmm14, [rsp+0xE0]
000076e4393d391f  add rsp, 0xF0
000076e4393d3926  pop r11
000076e4393d3928  pop r10
000076e4393d392a  pop r9
000076e4393d392c  pop r8
000076e4393d392e  pop rsi
000076e4393d392f  pop rdi
000076e4393d3930  pop rdx
000076e4393d3931  pop rcx
000076e4393d3932  pop rax
000076e4393d3933  add rsp, 0x08
000076e4393d3937  jmp 0x000076E4393CFF55
000076e4393d393c  call 0x000076E43920C260
000076e4393d3941  jmp 0x000076E4393CFFB0
000076e4393d3946  sub rsp, 0x08
000076e4393d394a  push rax
000076e4393d394b  push rcx
000076e4393d394c  push rdx
000076e4393d394d  push rdi
000076e4393d394e  push rsi
000076e4393d394f  push r8
000076e4393d3951  push r9
000076e4393d3953  push r10
000076e4393d3955  push r11
000076e4393d3957  sub rsp, 0xF0
000076e4393d395e  vmovaps [rsp], xmm0
000076e4393d3963  vmovaps [rsp+0x10], xmm1
000076e4393d3969  vmovaps [rsp+0x20], xmm2
000076e4393d396f  vmovaps [rsp+0x30], xmm3
000076e4393d3975  vmovaps [rsp+0x40], xmm4
000076e4393d397b  vmovaps [rsp+0x50], xmm5
000076e4393d3981  vmovaps [rsp+0x60], xmm6
000076e4393d3987  vmovaps [rsp+0x70], xmm7
000076e4393d398d  vmovaps [rsp+0x80], xmm8
000076e4393d3996  vmovaps [rsp+0x90], xmm10
000076e4393d399f  vmovaps [rsp+0xA0], xmm11
000076e4393d39a8  vmovaps [rsp+0xB0], xmm12
000076e4393d39b1  vmovaps [rsp+0xC0], xmm13
000076e4393d39ba  vmovaps [rsp+0xD0], xmm14
000076e4393d39c3  vmovaps [rsp+0xE0], xmm15
000076e4393d39cc  sub rsp, 0x30
000076e4393d39d0  movaps [rsp], xmm9
000076e4393d39d5  movaps [rsp+0x10], xmm8
000076e4393d39db  movaps [rsp+0x20], xmm10
000076e4393d39e1  lea rdi, [rsp]
000076e4393d39e5  mov esi, 0x00
000076e4393d39ea  mov rax, 0x63DBDEB43530
000076e4393d39f4  call rax
000076e4393d39f6  movaps xmm9, [rsp]
000076e4393d39fb  add rsp, 0x30
000076e4393d39ff  vmovaps xmm0, [rsp]
000076e4393d3a04  vmovaps xmm1, [rsp+0x10]
000076e4393d3a0a  vmovaps xmm2, [rsp+0x20]
000076e4393d3a10  vmovaps xmm3, [rsp+0x30]
000076e4393d3a16  vmovaps xmm4, [rsp+0x40]
000076e4393d3a1c  vmovaps xmm5, [rsp+0x50]
000076e4393d3a22  vmovaps xmm6, [rsp+0x60]
000076e4393d3a28  vmovaps xmm7, [rsp+0x70]
000076e4393d3a2e  vmovaps xmm8, [rsp+0x80]
000076e4393d3a37  vmovaps xmm10, [rsp+0x90]
000076e4393d3a40  vmovaps xmm11, [rsp+0xA0]
000076e4393d3a49  vmovaps xmm12, [rsp+0xB0]
000076e4393d3a52  vmovaps xmm13, [rsp+0xC0]
000076e4393d3a5b  vmovaps xmm14, [rsp+0xD0]
000076e4393d3a64  vmovaps xmm15, [rsp+0xE0]
000076e4393d3a6d  add rsp, 0xF0
000076e4393d3a74  pop r11
000076e4393d3a76  pop r10
000076e4393d3a78  pop r9
000076e4393d3a7a  pop r8
000076e4393d3a7c  pop rsi
000076e4393d3a7d  pop rdi
000076e4393d3a7e  pop rdx
000076e4393d3a7f  pop rcx
000076e4393d3a80  pop rax
000076e4393d3a81  add rsp, 0x08
000076e4393d3a85  jmp 0x000076E4393CFFE1
000076e4393d3a8a  sub rsp, 0x08
000076e4393d3a8e  push rax
000076e4393d3a8f  push rcx
000076e4393d3a90  push rdx
000076e4393d3a91  push rdi
000076e4393d3a92  push rsi
000076e4393d3a93  push r8
000076e4393d3a95  push r9
000076e4393d3a97  push r10
000076e4393d3a99  push r11
000076e4393d3a9b  sub rsp, 0xF0
000076e4393d3aa2  vmovaps [rsp], xmm0
000076e4393d3aa7  vmovaps [rsp+0x10], xmm1
000076e4393d3aad  vmovaps [rsp+0x20], xmm2
000076e4393d3ab3  vmovaps [rsp+0x30], xmm3
000076e4393d3ab9  vmovaps [rsp+0x40], xmm4
000076e4393d3abf  vmovaps [rsp+0x50], xmm5
000076e4393d3ac5  vmovaps [rsp+0x60], xmm6
000076e4393d3acb  vmovaps [rsp+0x70], xmm7
000076e4393d3ad1  vmovaps [rsp+0x80], xmm8
000076e4393d3ada  vmovaps [rsp+0x90], xmm9
000076e4393d3ae3  vmovaps [rsp+0xA0], xmm11
000076e4393d3aec  vmovaps [rsp+0xB0], xmm12
000076e4393d3af5  vmovaps [rsp+0xC0], xmm13
000076e4393d3afe  vmovaps [rsp+0xD0], xmm14
000076e4393d3b07  vmovaps [rsp+0xE0], xmm15
000076e4393d3b10  sub rsp, 0x30
000076e4393d3b14  movaps [rsp], xmm10
000076e4393d3b19  movaps [rsp+0x10], xmm1
000076e4393d3b1e  movaps [rsp+0x20], xmm11
000076e4393d3b24  lea rdi, [rsp]
000076e4393d3b28  mov esi, 0x00
000076e4393d3b2d  mov rax, 0x63DBDEB43530
000076e4393d3b37  call rax
000076e4393d3b39  movaps xmm10, [rsp]
000076e4393d3b3e  add rsp, 0x30
000076e4393d3b42  vmovaps xmm0, [rsp]
000076e4393d3b47  vmovaps xmm1, [rsp+0x10]
000076e4393d3b4d  vmovaps xmm2, [rsp+0x20]
000076e4393d3b53  vmovaps xmm3, [rsp+0x30]
000076e4393d3b59  vmovaps xmm4, [rsp+0x40]
000076e4393d3b5f  vmovaps xmm5, [rsp+0x50]
000076e4393d3b65  vmovaps xmm6, [rsp+0x60]
000076e4393d3b6b  vmovaps xmm7, [rsp+0x70]
000076e4393d3b71  vmovaps xmm8, [rsp+0x80]
000076e4393d3b7a  vmovaps xmm9, [rsp+0x90]
000076e4393d3b83  vmovaps xmm11, [rsp+0xA0]
000076e4393d3b8c  vmovaps xmm12, [rsp+0xB0]
000076e4393d3b95  vmovaps xmm13, [rsp+0xC0]
000076e4393d3b9e  vmovaps xmm14, [rsp+0xD0]
000076e4393d3ba7  vmovaps xmm15, [rsp+0xE0]
000076e4393d3bb0  add rsp, 0xF0
000076e4393d3bb7  pop r11
000076e4393d3bb9  pop r10
000076e4393d3bbb  pop r9
000076e4393d3bbd  pop r8
000076e4393d3bbf  pop rsi
000076e4393d3bc0  pop rdi
000076e4393d3bc1  pop rdx
000076e4393d3bc2  pop rcx
000076e4393d3bc3  pop rax
000076e4393d3bc4  add rsp, 0x08
000076e4393d3bc8  jmp 0x000076E4393CFFFC
000076e4393d3bcd  sub rsp, 0x08
000076e4393d3bd1  push rax
000076e4393d3bd2  push rcx
000076e4393d3bd3  push rdx
000076e4393d3bd4  push rdi
000076e4393d3bd5  push rsi
000076e4393d3bd6  push r8
000076e4393d3bd8  push r9
000076e4393d3bda  push r10
000076e4393d3bdc  push r11
000076e4393d3bde  sub rsp, 0xF0
000076e4393d3be5  vmovaps [rsp], xmm0
000076e4393d3bea  vmovaps [rsp+0x10], xmm2
000076e4393d3bf0  vmovaps [rsp+0x20], xmm3
000076e4393d3bf6  vmovaps [rsp+0x30], xmm4
000076e4393d3bfc  vmovaps [rsp+0x40], xmm5
000076e4393d3c02  vmovaps [rsp+0x50], xmm6
000076e4393d3c08  vmovaps [rsp+0x60], xmm7
000076e4393d3c0e  vmovaps [rsp+0x70], xmm8
000076e4393d3c14  vmovaps [rsp+0x80], xmm9
000076e4393d3c1d  vmovaps [rsp+0x90], xmm10
000076e4393d3c26  vmovaps [rsp+0xA0], xmm11
000076e4393d3c2f  vmovaps [rsp+0xB0], xmm12
000076e4393d3c38  vmovaps [rsp+0xC0], xmm13
000076e4393d3c41  vmovaps [rsp+0xD0], xmm14
000076e4393d3c4a  vmovaps [rsp+0xE0], xmm15
000076e4393d3c53  sub rsp, 0x30
000076e4393d3c57  movaps [rsp], xmm1
000076e4393d3c5b  movaps [rsp+0x10], xmm14
000076e4393d3c61  movaps [rsp+0x20], xmm6
000076e4393d3c66  lea rdi, [rsp]
000076e4393d3c6a  mov esi, 0x00
000076e4393d3c6f  mov rax, 0x63DBDEB43530
000076e4393d3c79  call rax
000076e4393d3c7b  movaps xmm1, [rsp]
000076e4393d3c7f  add rsp, 0x30
000076e4393d3c83  vmovaps xmm0, [rsp]
000076e4393d3c88  vmovaps xmm2, [rsp+0x10]
000076e4393d3c8e  vmovaps xmm3, [rsp+0x20]
000076e4393d3c94  vmovaps xmm4, [rsp+0x30]
000076e4393d3c9a  vmovaps xmm5, [rsp+0x40]
000076e4393d3ca0  vmovaps xmm6, [rsp+0x50]
000076e4393d3ca6  vmovaps xmm7, [rsp+0x60]
000076e4393d3cac  vmovaps xmm8, [rsp+0x70]
000076e4393d3cb2  vmovaps xmm9, [rsp+0x80]
000076e4393d3cbb  vmovaps xmm10, [rsp+0x90]
000076e4393d3cc4  vmovaps xmm11, [rsp+0xA0]
000076e4393d3ccd  vmovaps xmm12, [rsp+0xB0]
000076e4393d3cd6  vmovaps xmm13, [rsp+0xC0]
000076e4393d3cdf  vmovaps xmm14, [rsp+0xD0]
000076e4393d3ce8  vmovaps xmm15, [rsp+0xE0]
000076e4393d3cf1  add rsp, 0xF0
000076e4393d3cf8  pop r11
000076e4393d3cfa  pop r10
000076e4393d3cfc  pop r9
000076e4393d3cfe  pop r8
000076e4393d3d00  pop rsi
000076e4393d3d01  pop rdi
000076e4393d3d02  pop rdx
000076e4393d3d03  pop rcx
000076e4393d3d04  pop rax
000076e4393d3d05  add rsp, 0x08
000076e4393d3d09  jmp 0x000076E4393D0015
000076e4393d3d0e  sub rsp, 0x08
000076e4393d3d12  push rax
000076e4393d3d13  push rcx
000076e4393d3d14  push rdx
000076e4393d3d15  push rdi
000076e4393d3d16  push rsi
000076e4393d3d17  push r8
000076e4393d3d19  push r9
000076e4393d3d1b  push r10
000076e4393d3d1d  push r11
000076e4393d3d1f  sub rsp, 0xF0
000076e4393d3d26  vmovaps [rsp], xmm0
000076e4393d3d2b  vmovaps [rsp+0x10], xmm1
000076e4393d3d31  vmovaps [rsp+0x20], xmm2
000076e4393d3d37  vmovaps [rsp+0x30], xmm3
000076e4393d3d3d  vmovaps [rsp+0x40], xmm4
000076e4393d3d43  vmovaps [rsp+0x50], xmm5
000076e4393d3d49  vmovaps [rsp+0x60], xmm6
000076e4393d3d4f  vmovaps [rsp+0x70], xmm7
000076e4393d3d55  vmovaps [rsp+0x80], xmm8
000076e4393d3d5e  vmovaps [rsp+0x90], xmm9
000076e4393d3d67  vmovaps [rsp+0xA0], xmm10
000076e4393d3d70  vmovaps [rsp+0xB0], xmm12
000076e4393d3d79  vmovaps [rsp+0xC0], xmm13
000076e4393d3d82  vmovaps [rsp+0xD0], xmm14
000076e4393d3d8b  vmovaps [rsp+0xE0], xmm15
000076e4393d3d94  sub rsp, 0x30
000076e4393d3d98  movaps [rsp], xmm11
000076e4393d3d9d  movaps [rsp+0x10], xmm13
000076e4393d3da3  movaps [rsp+0x20], xmm14
000076e4393d3da9  lea rdi, [rsp]
000076e4393d3dad  mov esi, 0x00
000076e4393d3db2  mov rax, 0x63DBDEB43530
000076e4393d3dbc  call rax
000076e4393d3dbe  movaps xmm11, [rsp]
000076e4393d3dc3  add rsp, 0x30
000076e4393d3dc7  vmovaps xmm0, [rsp]
000076e4393d3dcc  vmovaps xmm1, [rsp+0x10]
000076e4393d3dd2  vmovaps xmm2, [rsp+0x20]
000076e4393d3dd8  vmovaps xmm3, [rsp+0x30]
000076e4393d3dde  vmovaps xmm4, [rsp+0x40]
000076e4393d3de4  vmovaps xmm5, [rsp+0x50]
000076e4393d3dea  vmovaps xmm6, [rsp+0x60]
000076e4393d3df0  vmovaps xmm7, [rsp+0x70]
000076e4393d3df6  vmovaps xmm8, [rsp+0x80]
000076e4393d3dff  vmovaps xmm9, [rsp+0x90]
000076e4393d3e08  vmovaps xmm10, [rsp+0xA0]
000076e4393d3e11  vmovaps xmm12, [rsp+0xB0]
000076e4393d3e1a  vmovaps xmm13, [rsp+0xC0]
000076e4393d3e23  vmovaps xmm14, [rsp+0xD0]
000076e4393d3e2c  vmovaps xmm15, [rsp+0xE0]
000076e4393d3e35  add rsp, 0xF0
000076e4393d3e3c  pop r11
000076e4393d3e3e  pop r10
000076e4393d3e40  pop r9
000076e4393d3e42  pop r8
000076e4393d3e44  pop rsi
000076e4393d3e45  pop rdi
000076e4393d3e46  pop rdx
000076e4393d3e47  pop rcx
000076e4393d3e48  pop rax
000076e4393d3e49  add rsp, 0x08
000076e4393d3e4d  jmp 0x000076E4393D003F
000076e4393d3e52  sub rsp, 0x08
000076e4393d3e56  push rax
000076e4393d3e57  push rcx
000076e4393d3e58  push rdx
000076e4393d3e59  push rdi
000076e4393d3e5a  push rsi
000076e4393d3e5b  push r8
000076e4393d3e5d  push r9
000076e4393d3e5f  push r10
000076e4393d3e61  push r11
000076e4393d3e63  sub rsp, 0xF0
000076e4393d3e6a  vmovaps [rsp], xmm0
000076e4393d3e6f  vmovaps [rsp+0x10], xmm1
000076e4393d3e75  vmovaps [rsp+0x20], xmm2
000076e4393d3e7b  vmovaps [rsp+0x30], xmm3
000076e4393d3e81  vmovaps [rsp+0x40], xmm4
000076e4393d3e87  vmovaps [rsp+0x50], xmm5
000076e4393d3e8d  vmovaps [rsp+0x60], xmm6
000076e4393d3e93  vmovaps [rsp+0x70], xmm7
000076e4393d3e99  vmovaps [rsp+0x80], xmm8
000076e4393d3ea2  vmovaps [rsp+0x90], xmm9
000076e4393d3eab  vmovaps [rsp+0xA0], xmm10
000076e4393d3eb4  vmovaps [rsp+0xB0], xmm11
000076e4393d3ebd  vmovaps [rsp+0xC0], xmm12
000076e4393d3ec6  vmovaps [rsp+0xD0], xmm14
000076e4393d3ecf  vmovaps [rsp+0xE0], xmm15
000076e4393d3ed8  sub rsp, 0x30
000076e4393d3edc  movaps [rsp], xmm13
000076e4393d3ee1  movaps [rsp+0x10], xmm8
000076e4393d3ee7  movaps [rsp+0x20], xmm14
000076e4393d3eed  lea rdi, [rsp]
000076e4393d3ef1  mov esi, 0x00
000076e4393d3ef6  mov rax, 0x63DBDEB43530
000076e4393d3f00  call rax
000076e4393d3f02  movaps xmm13, [rsp]
000076e4393d3f07  add rsp, 0x30
000076e4393d3f0b  vmovaps xmm0, [rsp]
000076e4393d3f10  vmovaps xmm1, [rsp+0x10]
000076e4393d3f16  vmovaps xmm2, [rsp+0x20]
000076e4393d3f1c  vmovaps xmm3, [rsp+0x30]
000076e4393d3f22  vmovaps xmm4, [rsp+0x40]
000076e4393d3f28  vmovaps xmm5, [rsp+0x50]
000076e4393d3f2e  vmovaps xmm6, [rsp+0x60]
000076e4393d3f34  vmovaps xmm7, [rsp+0x70]
000076e4393d3f3a  vmovaps xmm8, [rsp+0x80]
000076e4393d3f43  vmovaps xmm9, [rsp+0x90]
000076e4393d3f4c  vmovaps xmm10, [rsp+0xA0]
000076e4393d3f55  vmovaps xmm11, [rsp+0xB0]
000076e4393d3f5e  vmovaps xmm12, [rsp+0xC0]
000076e4393d3f67  vmovaps xmm14, [rsp+0xD0]
000076e4393d3f70  vmovaps xmm15, [rsp+0xE0]
000076e4393d3f79  add rsp, 0xF0
000076e4393d3f80  pop r11
000076e4393d3f82  pop r10
000076e4393d3f84  pop r9
000076e4393d3f86  pop r8
000076e4393d3f88  pop rsi
000076e4393d3f89  pop rdi
000076e4393d3f8a  pop rdx
000076e4393d3f8b  pop rcx
000076e4393d3f8c  pop rax
000076e4393d3f8d  add rsp, 0x08
000076e4393d3f91  jmp 0x000076E4393D006E
000076e4393d3f96  sub rsp, 0x08
000076e4393d3f9a  push rax
000076e4393d3f9b  push rcx
000076e4393d3f9c  push rdx
000076e4393d3f9d  push rdi
000076e4393d3f9e  push rsi
000076e4393d3f9f  push r8
000076e4393d3fa1  push r9
000076e4393d3fa3  push r10
000076e4393d3fa5  push r11
000076e4393d3fa7  sub rsp, 0xF0
000076e4393d3fae  vmovaps [rsp], xmm0
000076e4393d3fb3  vmovaps [rsp+0x10], xmm1
000076e4393d3fb9  vmovaps [rsp+0x20], xmm2
000076e4393d3fbf  vmovaps [rsp+0x30], xmm3
000076e4393d3fc5  vmovaps [rsp+0x40], xmm4
000076e4393d3fcb  vmovaps [rsp+0x50], xmm5
000076e4393d3fd1  vmovaps [rsp+0x60], xmm6
000076e4393d3fd7  vmovaps [rsp+0x70], xmm7
000076e4393d3fdd  vmovaps [rsp+0x80], xmm9
000076e4393d3fe6  vmovaps [rsp+0x90], xmm10
000076e4393d3fef  vmovaps [rsp+0xA0], xmm11
000076e4393d3ff8  vmovaps [rsp+0xB0], xmm12
000076e4393d4001  vmovaps [rsp+0xC0], xmm13
000076e4393d400a  vmovaps [rsp+0xD0], xmm14
000076e4393d4013  vmovaps [rsp+0xE0], xmm15
000076e4393d401c  sub rsp, 0x30
000076e4393d4020  movaps [rsp], xmm8
000076e4393d4025  movaps [rsp+0x10], xmm7
000076e4393d402a  movaps [rsp+0x20], xmm14
000076e4393d4030  lea rdi, [rsp]
000076e4393d4034  mov esi, 0x00
000076e4393d4039  mov rax, 0x63DBDEB43530
000076e4393d4043  call rax
000076e4393d4045  movaps xmm8, [rsp]
000076e4393d404a  add rsp, 0x30
000076e4393d404e  vmovaps xmm0, [rsp]
000076e4393d4053  vmovaps xmm1, [rsp+0x10]
000076e4393d4059  vmovaps xmm2, [rsp+0x20]
000076e4393d405f  vmovaps xmm3, [rsp+0x30]
000076e4393d4065  vmovaps xmm4, [rsp+0x40]
000076e4393d406b  vmovaps xmm5, [rsp+0x50]
000076e4393d4071  vmovaps xmm6, [rsp+0x60]
000076e4393d4077  vmovaps xmm7, [rsp+0x70]
000076e4393d407d  vmovaps xmm9, [rsp+0x80]
000076e4393d4086  vmovaps xmm10, [rsp+0x90]
000076e4393d408f  vmovaps xmm11, [rsp+0xA0]
000076e4393d4098  vmovaps xmm12, [rsp+0xB0]
000076e4393d40a1  vmovaps xmm13, [rsp+0xC0]
000076e4393d40aa  vmovaps xmm14, [rsp+0xD0]
000076e4393d40b3  vmovaps xmm15, [rsp+0xE0]
000076e4393d40bc  add rsp, 0xF0
000076e4393d40c3  pop r11
000076e4393d40c5  pop r10
000076e4393d40c7  pop r9
000076e4393d40c9  pop r8
000076e4393d40cb  pop rsi
000076e4393d40cc  pop rdi
000076e4393d40cd  pop rdx
000076e4393d40ce  pop rcx
000076e4393d40cf  pop rax
000076e4393d40d0  add rsp, 0x08
000076e4393d40d4  jmp 0x000076E4393D0094
000076e4393d40d9  sub rsp, 0x08
000076e4393d40dd  push rax
000076e4393d40de  push rcx
000076e4393d40df  push rdx
000076e4393d40e0  push rdi
000076e4393d40e1  push rsi
000076e4393d40e2  push r8
000076e4393d40e4  push r9
000076e4393d40e6  push r10
000076e4393d40e8  push r11
000076e4393d40ea  sub rsp, 0xF0
000076e4393d40f1  vmovaps [rsp], xmm0
000076e4393d40f6  vmovaps [rsp+0x10], xmm1
000076e4393d40fc  vmovaps [rsp+0x20], xmm2
000076e4393d4102  vmovaps [rsp+0x30], xmm3
000076e4393d4108  vmovaps [rsp+0x40], xmm4
000076e4393d410e  vmovaps [rsp+0x50], xmm5
000076e4393d4114  vmovaps [rsp+0x60], xmm6
000076e4393d411a  vmovaps [rsp+0x70], xmm7
000076e4393d4120  vmovaps [rsp+0x80], xmm8
000076e4393d4129  vmovaps [rsp+0x90], xmm9
000076e4393d4132  vmovaps [rsp+0xA0], xmm10
000076e4393d413b  vmovaps [rsp+0xB0], xmm11
000076e4393d4144  vmovaps [rsp+0xC0], xmm12
000076e4393d414d  vmovaps [rsp+0xD0], xmm13
000076e4393d4156  vmovaps [rsp+0xE0], xmm15
000076e4393d415f  sub rsp, 0x30
000076e4393d4163  movaps [rsp], xmm14
000076e4393d4168  movaps [rsp+0x10], xmm12
000076e4393d416e  movaps [rsp+0x20], xmm9
000076e4393d4174  lea rdi, [rsp]
000076e4393d4178  mov esi, 0x00
000076e4393d417d  mov rax, 0x63DBDEB43530
000076e4393d4187  call rax
000076e4393d4189  movaps xmm14, [rsp]
000076e4393d418e  add rsp, 0x30
000076e4393d4192  vmovaps xmm0, [rsp]
000076e4393d4197  vmovaps xmm1, [rsp+0x10]
000076e4393d419d  vmovaps xmm2, [rsp+0x20]
000076e4393d41a3  vmovaps xmm3, [rsp+0x30]
000076e4393d41a9  vmovaps xmm4, [rsp+0x40]
000076e4393d41af  vmovaps xmm5, [rsp+0x50]
000076e4393d41b5  vmovaps xmm6, [rsp+0x60]
000076e4393d41bb  vmovaps xmm7, [rsp+0x70]
000076e4393d41c1  vmovaps xmm8, [rsp+0x80]
000076e4393d41ca  vmovaps xmm9, [rsp+0x90]
000076e4393d41d3  vmovaps xmm10, [rsp+0xA0]
000076e4393d41dc  vmovaps xmm11, [rsp+0xB0]
000076e4393d41e5  vmovaps xmm12, [rsp+0xC0]
000076e4393d41ee  vmovaps xmm13, [rsp+0xD0]
000076e4393d41f7  vmovaps xmm15, [rsp+0xE0]
000076e4393d4200  add rsp, 0xF0
000076e4393d4207  pop r11
000076e4393d4209  pop r10
000076e4393d420b  pop r9
000076e4393d420d  pop r8
000076e4393d420f  pop rsi
000076e4393d4210  pop rdi
000076e4393d4211  pop rdx
000076e4393d4212  pop rcx
000076e4393d4213  pop rax
000076e4393d4214  add rsp, 0x08
000076e4393d4218  jmp 0x000076E4393D00AE
000076e4393d421d  sub rsp, 0x08
000076e4393d4221  push rax
000076e4393d4222  push rcx
000076e4393d4223  push rdx
000076e4393d4224  push rdi
000076e4393d4225  push rsi
000076e4393d4226  push r8
000076e4393d4228  push r9
000076e4393d422a  push r10
000076e4393d422c  push r11
000076e4393d422e  sub rsp, 0xF0
000076e4393d4235  vmovaps [rsp], xmm0
000076e4393d423a  vmovaps [rsp+0x10], xmm1
000076e4393d4240  vmovaps [rsp+0x20], xmm2
000076e4393d4246  vmovaps [rsp+0x30], xmm3
000076e4393d424c  vmovaps [rsp+0x40], xmm4
000076e4393d4252  vmovaps [rsp+0x50], xmm5
000076e4393d4258  vmovaps [rsp+0x60], xmm6
000076e4393d425e  vmovaps [rsp+0x70], xmm7
000076e4393d4264  vmovaps [rsp+0x80], xmm8
000076e4393d426d  vmovaps [rsp+0x90], xmm10
000076e4393d4276  vmovaps [rsp+0xA0], xmm11
000076e4393d427f  vmovaps [rsp+0xB0], xmm12
000076e4393d4288  vmovaps [rsp+0xC0], xmm13
000076e4393d4291  vmovaps [rsp+0xD0], xmm14
000076e4393d429a  vmovaps [rsp+0xE0], xmm15
000076e4393d42a3  sub rsp, 0x30
000076e4393d42a7  movaps [rsp], xmm9
000076e4393d42ac  movaps [rsp+0x10], xmm7
000076e4393d42b1  movaps [rsp+0x20], xmm12
000076e4393d42b7  lea rdi, [rsp]
000076e4393d42bb  mov esi, 0x00
000076e4393d42c0  mov rax, 0x63DBDEB43530
000076e4393d42ca  call rax
000076e4393d42cc  movaps xmm9, [rsp]
000076e4393d42d1  add rsp, 0x30
000076e4393d42d5  vmovaps xmm0, [rsp]
000076e4393d42da  vmovaps xmm1, [rsp+0x10]
000076e4393d42e0  vmovaps xmm2, [rsp+0x20]
000076e4393d42e6  vmovaps xmm3, [rsp+0x30]
000076e4393d42ec  vmovaps xmm4, [rsp+0x40]
000076e4393d42f2  vmovaps xmm5, [rsp+0x50]
000076e4393d42f8  vmovaps xmm6, [rsp+0x60]
000076e4393d42fe  vmovaps xmm7, [rsp+0x70]
000076e4393d4304  vmovaps xmm8, [rsp+0x80]
000076e4393d430d  vmovaps xmm10, [rsp+0x90]
000076e4393d4316  vmovaps xmm11, [rsp+0xA0]
000076e4393d431f  vmovaps xmm12, [rsp+0xB0]
000076e4393d4328  vmovaps xmm13, [rsp+0xC0]
000076e4393d4331  vmovaps xmm14, [rsp+0xD0]
000076e4393d433a  vmovaps xmm15, [rsp+0xE0]
000076e4393d4343  add rsp, 0xF0
000076e4393d434a  pop r11
000076e4393d434c  pop r10
000076e4393d434e  pop r9
000076e4393d4350  pop r8
000076e4393d4352  pop rsi
000076e4393d4353  pop rdi
000076e4393d4354  pop rdx
000076e4393d4355  pop rcx
000076e4393d4356  pop rax
000076e4393d4357  add rsp, 0x08
000076e4393d435b  jmp 0x000076E4393D00DD
000076e4393d4360  sub rsp, 0x08
000076e4393d4364  push rax
000076e4393d4365  push rcx
000076e4393d4366  push rdx
000076e4393d4367  push rdi
000076e4393d4368  push rsi
000076e4393d4369  push r8
000076e4393d436b  push r9
000076e4393d436d  push r10
000076e4393d436f  push r11
000076e4393d4371  sub rsp, 0xF0
000076e4393d4378  vmovaps [rsp], xmm0
000076e4393d437d  vmovaps [rsp+0x10], xmm1
000076e4393d4383  vmovaps [rsp+0x20], xmm2
000076e4393d4389  vmovaps [rsp+0x30], xmm3
000076e4393d438f  vmovaps [rsp+0x40], xmm4
000076e4393d4395  vmovaps [rsp+0x50], xmm5
000076e4393d439b  vmovaps [rsp+0x60], xmm6
000076e4393d43a1  vmovaps [rsp+0x70], xmm7
000076e4393d43a7  vmovaps [rsp+0x80], xmm8
000076e4393d43b0  vmovaps [rsp+0x90], xmm9
000076e4393d43b9  vmovaps [rsp+0xA0], xmm10
000076e4393d43c2  vmovaps [rsp+0xB0], xmm11
000076e4393d43cb  vmovaps [rsp+0xC0], xmm13
000076e4393d43d4  vmovaps [rsp+0xD0], xmm14
000076e4393d43dd  vmovaps [rsp+0xE0], xmm15
000076e4393d43e6  sub rsp, 0x30
000076e4393d43ea  movaps [rsp], xmm12
000076e4393d43ef  movaps [rsp+0x10], xmm15
000076e4393d43f5  movaps [rsp+0x20], xmm11
000076e4393d43fb  lea rdi, [rsp]
000076e4393d43ff  mov esi, 0x00
000076e4393d4404  mov rax, 0x63DBDEB43530
000076e4393d440e  call rax
000076e4393d4410  movaps xmm12, [rsp]
000076e4393d4415  add rsp, 0x30
000076e4393d4419  vmovaps xmm0, [rsp]
000076e4393d441e  vmovaps xmm1, [rsp+0x10]
000076e4393d4424  vmovaps xmm2, [rsp+0x20]
000076e4393d442a  vmovaps xmm3, [rsp+0x30]
000076e4393d4430  vmovaps xmm4, [rsp+0x40]
000076e4393d4436  vmovaps xmm5, [rsp+0x50]
000076e4393d443c  vmovaps xmm6, [rsp+0x60]
000076e4393d4442  vmovaps xmm7, [rsp+0x70]
000076e4393d4448  vmovaps xmm8, [rsp+0x80]
000076e4393d4451  vmovaps xmm9, [rsp+0x90]
000076e4393d445a  vmovaps xmm10, [rsp+0xA0]
000076e4393d4463  vmovaps xmm11, [rsp+0xB0]
000076e4393d446c  vmovaps xmm13, [rsp+0xC0]
000076e4393d4475  vmovaps xmm14, [rsp+0xD0]
000076e4393d447e  vmovaps xmm15, [rsp+0xE0]
000076e4393d4487  add rsp, 0xF0
000076e4393d448e  pop r11
000076e4393d4490  pop r10
000076e4393d4492  pop r9
000076e4393d4494  pop r8
000076e4393d4496  pop rsi
000076e4393d4497  pop rdi
000076e4393d4498  pop rdx
000076e4393d4499  pop rcx
000076e4393d449a  pop rax
000076e4393d449b  add rsp, 0x08
000076e4393d449f  jmp 0x000076E4393D00F7
000076e4393d44a4  sub rsp, 0x08
000076e4393d44a8  push rax
000076e4393d44a9  push rcx
000076e4393d44aa  push rdx
000076e4393d44ab  push rdi
000076e4393d44ac  push rsi
000076e4393d44ad  push r8
000076e4393d44af  push r9
000076e4393d44b1  push r10
000076e4393d44b3  push r11
000076e4393d44b5  sub rsp, 0xF0
000076e4393d44bc  vmovaps [rsp], xmm0
000076e4393d44c1  vmovaps [rsp+0x10], xmm1
000076e4393d44c7  vmovaps [rsp+0x20], xmm2
000076e4393d44cd  vmovaps [rsp+0x30], xmm3
000076e4393d44d3  vmovaps [rsp+0x40], xmm4
000076e4393d44d9  vmovaps [rsp+0x50], xmm5
000076e4393d44df  vmovaps [rsp+0x60], xmm6
000076e4393d44e5  vmovaps [rsp+0x70], xmm7
000076e4393d44eb  vmovaps [rsp+0x80], xmm8
000076e4393d44f4  vmovaps [rsp+0x90], xmm9
000076e4393d44fd  vmovaps [rsp+0xA0], xmm10
000076e4393d4506  vmovaps [rsp+0xB0], xmm12
000076e4393d450f  vmovaps [rsp+0xC0], xmm13
000076e4393d4518  vmovaps [rsp+0xD0], xmm14
000076e4393d4521  vmovaps [rsp+0xE0], xmm15
000076e4393d452a  sub rsp, 0x30
000076e4393d452e  movaps [rsp], xmm11
000076e4393d4533  movaps [rsp+0x10], xmm7
000076e4393d4538  movaps [rsp+0x20], xmm15
000076e4393d453e  lea rdi, [rsp]
000076e4393d4542  mov esi, 0x00
000076e4393d4547  mov rax, 0x63DBDEB43530
000076e4393d4551  call rax
000076e4393d4553  movaps xmm11, [rsp]
000076e4393d4558  add rsp, 0x30
000076e4393d455c  vmovaps xmm0, [rsp]
000076e4393d4561  vmovaps xmm1, [rsp+0x10]
000076e4393d4567  vmovaps xmm2, [rsp+0x20]
000076e4393d456d  vmovaps xmm3, [rsp+0x30]
000076e4393d4573  vmovaps xmm4, [rsp+0x40]
000076e4393d4579  vmovaps xmm5, [rsp+0x50]
000076e4393d457f  vmovaps xmm6, [rsp+0x60]
000076e4393d4585  vmovaps xmm7, [rsp+0x70]
000076e4393d458b  vmovaps xmm8, [rsp+0x80]
000076e4393d4594  vmovaps xmm9, [rsp+0x90]
000076e4393d459d  vmovaps xmm10, [rsp+0xA0]
000076e4393d45a6  vmovaps xmm12, [rsp+0xB0]
000076e4393d45af  vmovaps xmm13, [rsp+0xC0]
000076e4393d45b8  vmovaps xmm14, [rsp+0xD0]
000076e4393d45c1  vmovaps xmm15, [rsp+0xE0]
000076e4393d45ca  add rsp, 0xF0
000076e4393d45d1  pop r11
000076e4393d45d3  pop r10
000076e4393d45d5  pop r9
000076e4393d45d7  pop r8
000076e4393d45d9  pop rsi
000076e4393d45da  pop rdi
000076e4393d45db  pop rdx
000076e4393d45dc  pop rcx
000076e4393d45dd  pop rax
000076e4393d45de  add rsp, 0x08
000076e4393d45e2  jmp 0x000076E4393D0123
000076e4393d45e7  sub rsp, 0x08
000076e4393d45eb  push rax
000076e4393d45ec  push rcx
000076e4393d45ed  push rdx
000076e4393d45ee  push rdi
000076e4393d45ef  push rsi
000076e4393d45f0  push r8
000076e4393d45f2  push r9
000076e4393d45f4  push r10
000076e4393d45f6  push r11
000076e4393d45f8  sub rsp, 0xF0
000076e4393d45ff  vmovaps [rsp], xmm0
000076e4393d4604  vmovaps [rsp+0x10], xmm1
000076e4393d460a  vmovaps [rsp+0x20], xmm2
000076e4393d4610  vmovaps [rsp+0x30], xmm3
000076e4393d4616  vmovaps [rsp+0x40], xmm4
000076e4393d461c  vmovaps [rsp+0x50], xmm5
000076e4393d4622  vmovaps [rsp+0x60], xmm6
000076e4393d4628  vmovaps [rsp+0x70], xmm7
000076e4393d462e  vmovaps [rsp+0x80], xmm8
000076e4393d4637  vmovaps [rsp+0x90], xmm9
000076e4393d4640  vmovaps [rsp+0xA0], xmm10
000076e4393d4649  vmovaps [rsp+0xB0], xmm11
000076e4393d4652  vmovaps [rsp+0xC0], xmm12
000076e4393d465b  vmovaps [rsp+0xD0], xmm13
000076e4393d4664  vmovaps [rsp+0xE0], xmm14
000076e4393d466d  sub rsp, 0x30
000076e4393d4671  movaps [rsp], xmm15
000076e4393d4676  movaps [rsp+0x10], xmm10
000076e4393d467c  movaps [rsp+0x20], xmm13
000076e4393d4682  lea rdi, [rsp]
000076e4393d4686  mov esi, 0x00
000076e4393d468b  mov rax, 0x63DBDEB43530
000076e4393d4695  call rax
000076e4393d4697  movaps xmm15, [rsp]
000076e4393d469c  add rsp, 0x30
000076e4393d46a0  vmovaps xmm0, [rsp]
000076e4393d46a5  vmovaps xmm1, [rsp+0x10]
000076e4393d46ab  vmovaps xmm2, [rsp+0x20]
000076e4393d46b1  vmovaps xmm3, [rsp+0x30]
000076e4393d46b7  vmovaps xmm4, [rsp+0x40]
000076e4393d46bd  vmovaps xmm5, [rsp+0x50]
000076e4393d46c3  vmovaps xmm6, [rsp+0x60]
000076e4393d46c9  vmovaps xmm7, [rsp+0x70]
000076e4393d46cf  vmovaps xmm8, [rsp+0x80]
000076e4393d46d8  vmovaps xmm9, [rsp+0x90]
000076e4393d46e1  vmovaps xmm10, [rsp+0xA0]
000076e4393d46ea  vmovaps xmm11, [rsp+0xB0]
000076e4393d46f3  vmovaps xmm12, [rsp+0xC0]
000076e4393d46fc  vmovaps xmm13, [rsp+0xD0]
000076e4393d4705  vmovaps xmm14, [rsp+0xE0]
000076e4393d470e  add rsp, 0xF0
000076e4393d4715  pop r11
000076e4393d4717  pop r10
000076e4393d4719  pop r9
000076e4393d471b  pop r8
000076e4393d471d  pop rsi
000076e4393d471e  pop rdi
000076e4393d471f  pop rdx
000076e4393d4720  pop rcx
000076e4393d4721  pop rax
000076e4393d4722  add rsp, 0x08
000076e4393d4726  jmp 0x000076E4393D013D
000076e4393d472b  sub rsp, 0x08
000076e4393d472f  push rax
000076e4393d4730  push rcx
000076e4393d4731  push rdx
000076e4393d4732  push rdi
000076e4393d4733  push rsi
000076e4393d4734  push r8
000076e4393d4736  push r9
000076e4393d4738  push r10
000076e4393d473a  push r11
000076e4393d473c  sub rsp, 0xF0
000076e4393d4743  vmovaps [rsp], xmm0
000076e4393d4748  vmovaps [rsp+0x10], xmm1
000076e4393d474e  vmovaps [rsp+0x20], xmm2
000076e4393d4754  vmovaps [rsp+0x30], xmm3
000076e4393d475a  vmovaps [rsp+0x40], xmm4
000076e4393d4760  vmovaps [rsp+0x50], xmm5
000076e4393d4766  vmovaps [rsp+0x60], xmm6
000076e4393d476c  vmovaps [rsp+0x70], xmm7
000076e4393d4772  vmovaps [rsp+0x80], xmm8
000076e4393d477b  vmovaps [rsp+0x90], xmm9
000076e4393d4784  vmovaps [rsp+0xA0], xmm11
000076e4393d478d  vmovaps [rsp+0xB0], xmm12
000076e4393d4796  vmovaps [rsp+0xC0], xmm13
000076e4393d479f  vmovaps [rsp+0xD0], xmm14
000076e4393d47a8  vmovaps [rsp+0xE0], xmm15
000076e4393d47b1  sub rsp, 0x30
000076e4393d47b5  movaps [rsp], xmm10
000076e4393d47ba  movaps [rsp+0x10], xmm7
000076e4393d47bf  movaps [rsp+0x20], xmm13
000076e4393d47c5  lea rdi, [rsp]
000076e4393d47c9  mov esi, 0x00
000076e4393d47ce  mov rax, 0x63DBDEB43530
000076e4393d47d8  call rax
000076e4393d47da  movaps xmm10, [rsp]
000076e4393d47df  add rsp, 0x30
000076e4393d47e3  vmovaps xmm0, [rsp]
000076e4393d47e8  vmovaps xmm1, [rsp+0x10]
000076e4393d47ee  vmovaps xmm2, [rsp+0x20]
000076e4393d47f4  vmovaps xmm3, [rsp+0x30]
000076e4393d47fa  vmovaps xmm4, [rsp+0x40]
000076e4393d4800  vmovaps xmm5, [rsp+0x50]
000076e4393d4806  vmovaps xmm6, [rsp+0x60]
000076e4393d480c  vmovaps xmm7, [rsp+0x70]
000076e4393d4812  vmovaps xmm8, [rsp+0x80]
000076e4393d481b  vmovaps xmm9, [rsp+0x90]
000076e4393d4824  vmovaps xmm11, [rsp+0xA0]
000076e4393d482d  vmovaps xmm12, [rsp+0xB0]
000076e4393d4836  vmovaps xmm13, [rsp+0xC0]
000076e4393d483f  vmovaps xmm14, [rsp+0xD0]
000076e4393d4848  vmovaps xmm15, [rsp+0xE0]
000076e4393d4851  add rsp, 0xF0
000076e4393d4858  pop r11
000076e4393d485a  pop r10
000076e4393d485c  pop r9
000076e4393d485e  pop r8
000076e4393d4860  pop rsi
000076e4393d4861  pop rdi
000076e4393d4862  pop rdx
000076e4393d4863  pop rcx
000076e4393d4864  pop rax
000076e4393d4865  add rsp, 0x08
000076e4393d4869  jmp 0x000076E4393D0169
000076e4393d486e  sub rsp, 0x08
000076e4393d4872  push rax
000076e4393d4873  push rcx
000076e4393d4874  push rdx
000076e4393d4875  push rdi
000076e4393d4876  push rsi
000076e4393d4877  push r8
000076e4393d4879  push r9
000076e4393d487b  push r10
000076e4393d487d  push r11
000076e4393d487f  sub rsp, 0xF0
000076e4393d4886  vmovaps [rsp], xmm0
000076e4393d488b  vmovaps [rsp+0x10], xmm1
000076e4393d4891  vmovaps [rsp+0x20], xmm2
000076e4393d4897  vmovaps [rsp+0x30], xmm3
000076e4393d489d  vmovaps [rsp+0x40], xmm4
000076e4393d48a3  vmovaps [rsp+0x50], xmm5
000076e4393d48a9  vmovaps [rsp+0x60], xmm6
000076e4393d48af  vmovaps [rsp+0x70], xmm7
000076e4393d48b5  vmovaps [rsp+0x80], xmm8
000076e4393d48be  vmovaps [rsp+0x90], xmm9
000076e4393d48c7  vmovaps [rsp+0xA0], xmm10
000076e4393d48d0  vmovaps [rsp+0xB0], xmm11
000076e4393d48d9  vmovaps [rsp+0xC0], xmm12
000076e4393d48e2  vmovaps [rsp+0xD0], xmm14
000076e4393d48eb  vmovaps [rsp+0xE0], xmm15
000076e4393d48f4  sub rsp, 0x30
000076e4393d48f8  movaps [rsp], xmm13
000076e4393d48fd  movaps [rsp+0x10], xmm1
000076e4393d4902  movaps [rsp+0x20], xmm8
000076e4393d4908  lea rdi, [rsp]
000076e4393d490c  mov esi, 0x00
000076e4393d4911  mov rax, 0x63DBDEB43530
000076e4393d491b  call rax
000076e4393d491d  movaps xmm13, [rsp]
000076e4393d4922  add rsp, 0x30
000076e4393d4926  vmovaps xmm0, [rsp]
000076e4393d492b  vmovaps xmm1, [rsp+0x10]
000076e4393d4931  vmovaps xmm2, [rsp+0x20]
000076e4393d4937  vmovaps xmm3, [rsp+0x30]
000076e4393d493d  vmovaps xmm4, [rsp+0x40]
000076e4393d4943  vmovaps xmm5, [rsp+0x50]
000076e4393d4949  vmovaps xmm6, [rsp+0x60]
000076e4393d494f  vmovaps xmm7, [rsp+0x70]
000076e4393d4955  vmovaps xmm8, [rsp+0x80]
000076e4393d495e  vmovaps xmm9, [rsp+0x90]
000076e4393d4967  vmovaps xmm10, [rsp+0xA0]
000076e4393d4970  vmovaps xmm11, [rsp+0xB0]
000076e4393d4979  vmovaps xmm12, [rsp+0xC0]
000076e4393d4982  vmovaps xmm14, [rsp+0xD0]
000076e4393d498b  vmovaps xmm15, [rsp+0xE0]
000076e4393d4994  add rsp, 0xF0
000076e4393d499b  pop r11
000076e4393d499d  pop r10
000076e4393d499f  pop r9
000076e4393d49a1  pop r8
000076e4393d49a3  pop rsi
000076e4393d49a4  pop rdi
000076e4393d49a5  pop rdx
000076e4393d49a6  pop rcx
000076e4393d49a7  pop rax
000076e4393d49a8  add rsp, 0x08
000076e4393d49ac  jmp 0x000076E4393D0183
000076e4393d49b1  call 0x000076E4391FF430
000076e4393d49b6  jmp 0x000076E4393D018D
000076e4393d49bb  sub rsp, 0x08
000076e4393d49bf  push rax
000076e4393d49c0  push rcx
000076e4393d49c1  push rdx
000076e4393d49c2  push rdi
000076e4393d49c3  push rsi
000076e4393d49c4  push r8
000076e4393d49c6  push r9
000076e4393d49c8  push r10
000076e4393d49ca  push r11
000076e4393d49cc  sub rsp, 0xF0
000076e4393d49d3  vmovaps [rsp], xmm0
000076e4393d49d8  vmovaps [rsp+0x10], xmm1
000076e4393d49de  vmovaps [rsp+0x20], xmm2
000076e4393d49e4  vmovaps [rsp+0x30], xmm3
000076e4393d49ea  vmovaps [rsp+0x40], xmm4
000076e4393d49f0  vmovaps [rsp+0x50], xmm5
000076e4393d49f6  vmovaps [rsp+0x60], xmm6
000076e4393d49fc  vmovaps [rsp+0x70], xmm7
000076e4393d4a02  vmovaps [rsp+0x80], xmm9
000076e4393d4a0b  vmovaps [rsp+0x90], xmm10
000076e4393d4a14  vmovaps [rsp+0xA0], xmm11
000076e4393d4a1d  vmovaps [rsp+0xB0], xmm12
000076e4393d4a26  vmovaps [rsp+0xC0], xmm13
000076e4393d4a2f  vmovaps [rsp+0xD0], xmm14
000076e4393d4a38  vmovaps [rsp+0xE0], xmm15
000076e4393d4a41  sub rsp, 0x30
000076e4393d4a45  movaps [rsp], xmm8
000076e4393d4a4a  movaps [rsp+0x10], xmm14
000076e4393d4a50  movaps [rsp+0x20], xmm9
000076e4393d4a56  lea rdi, [rsp]
000076e4393d4a5a  mov esi, 0x00
000076e4393d4a5f  mov rax, 0x63DBDEB43530
000076e4393d4a69  call rax
000076e4393d4a6b  movaps xmm8, [rsp]
000076e4393d4a70  add rsp, 0x30
000076e4393d4a74  vmovaps xmm0, [rsp]
000076e4393d4a79  vmovaps xmm1, [rsp+0x10]
000076e4393d4a7f  vmovaps xmm2, [rsp+0x20]
000076e4393d4a85  vmovaps xmm3, [rsp+0x30]
000076e4393d4a8b  vmovaps xmm4, [rsp+0x40]
000076e4393d4a91  vmovaps xmm5, [rsp+0x50]
000076e4393d4a97  vmovaps xmm6, [rsp+0x60]
000076e4393d4a9d  vmovaps xmm7, [rsp+0x70]
000076e4393d4aa3  vmovaps xmm9, [rsp+0x80]
000076e4393d4aac  vmovaps xmm10, [rsp+0x90]
000076e4393d4ab5  vmovaps xmm11, [rsp+0xA0]
000076e4393d4abe  vmovaps xmm12, [rsp+0xB0]
000076e4393d4ac7  vmovaps xmm13, [rsp+0xC0]
000076e4393d4ad0  vmovaps xmm14, [rsp+0xD0]
000076e4393d4ad9  vmovaps xmm15, [rsp+0xE0]
000076e4393d4ae2  add rsp, 0xF0
000076e4393d4ae9  pop r11
000076e4393d4aeb  pop r10
000076e4393d4aed  pop r9
000076e4393d4aef  pop r8
000076e4393d4af1  pop rsi
000076e4393d4af2  pop rdi
000076e4393d4af3  pop rdx
000076e4393d4af4  pop rcx
000076e4393d4af5  pop rax
000076e4393d4af6  add rsp, 0x08
000076e4393d4afa  jmp 0x000076E4393D01AF
000076e4393d4aff  sub rsp, 0x08
000076e4393d4b03  push rax
000076e4393d4b04  push rcx
000076e4393d4b05  push rdx
000076e4393d4b06  push rdi
000076e4393d4b07  push rsi
000076e4393d4b08  push r8
000076e4393d4b0a  push r9
000076e4393d4b0c  push r10
000076e4393d4b0e  push r11
000076e4393d4b10  sub rsp, 0xF0
000076e4393d4b17  vmovaps [rsp], xmm0
000076e4393d4b1c  vmovaps [rsp+0x10], xmm1
000076e4393d4b22  vmovaps [rsp+0x20], xmm2
000076e4393d4b28  vmovaps [rsp+0x30], xmm3
000076e4393d4b2e  vmovaps [rsp+0x40], xmm4
000076e4393d4b34  vmovaps [rsp+0x50], xmm5
000076e4393d4b3a  vmovaps [rsp+0x60], xmm6
000076e4393d4b40  vmovaps [rsp+0x70], xmm7
000076e4393d4b46  vmovaps [rsp+0x80], xmm8
000076e4393d4b4f  vmovaps [rsp+0x90], xmm10
000076e4393d4b58  vmovaps [rsp+0xA0], xmm11
000076e4393d4b61  vmovaps [rsp+0xB0], xmm12
000076e4393d4b6a  vmovaps [rsp+0xC0], xmm13
000076e4393d4b73  vmovaps [rsp+0xD0], xmm14
000076e4393d4b7c  vmovaps [rsp+0xE0], xmm15
000076e4393d4b85  sub rsp, 0x30
000076e4393d4b89  movaps [rsp], xmm9
000076e4393d4b8e  movaps [rsp+0x10], xmm1
000076e4393d4b93  movaps [rsp+0x20], xmm14
000076e4393d4b99  lea rdi, [rsp]
000076e4393d4b9d  mov esi, 0x00
000076e4393d4ba2  mov rax, 0x63DBDEB43530
000076e4393d4bac  call rax
000076e4393d4bae  movaps xmm9, [rsp]
000076e4393d4bb3  add rsp, 0x30
000076e4393d4bb7  vmovaps xmm0, [rsp]
000076e4393d4bbc  vmovaps xmm1, [rsp+0x10]
000076e4393d4bc2  vmovaps xmm2, [rsp+0x20]
000076e4393d4bc8  vmovaps xmm3, [rsp+0x30]
000076e4393d4bce  vmovaps xmm4, [rsp+0x40]
000076e4393d4bd4  vmovaps xmm5, [rsp+0x50]
000076e4393d4bda  vmovaps xmm6, [rsp+0x60]
000076e4393d4be0  vmovaps xmm7, [rsp+0x70]
000076e4393d4be6  vmovaps xmm8, [rsp+0x80]
000076e4393d4bef  vmovaps xmm10, [rsp+0x90]
000076e4393d4bf8  vmovaps xmm11, [rsp+0xA0]
000076e4393d4c01  vmovaps xmm12, [rsp+0xB0]
000076e4393d4c0a  vmovaps xmm13, [rsp+0xC0]
000076e4393d4c13  vmovaps xmm14, [rsp+0xD0]
000076e4393d4c1c  vmovaps xmm15, [rsp+0xE0]
000076e4393d4c25  add rsp, 0xF0
000076e4393d4c2c  pop r11
000076e4393d4c2e  pop r10
000076e4393d4c30  pop r9
000076e4393d4c32  pop r8
000076e4393d4c34  pop rsi
000076e4393d4c35  pop rdi
000076e4393d4c36  pop rdx
000076e4393d4c37  pop rcx
000076e4393d4c38  pop rax
000076e4393d4c39  add rsp, 0x08
000076e4393d4c3d  jmp 0x000076E4393D01DD
000076e4393d4c42  sub rsp, 0x08
000076e4393d4c46  push rax
000076e4393d4c47  push rcx
000076e4393d4c48  push rdx
000076e4393d4c49  push rdi
000076e4393d4c4a  push rsi
000076e4393d4c4b  push r8
000076e4393d4c4d  push r9
000076e4393d4c4f  push r10
000076e4393d4c51  push r11
000076e4393d4c53  sub rsp, 0xF0
000076e4393d4c5a  vmovaps [rsp], xmm0
000076e4393d4c5f  vmovaps [rsp+0x10], xmm1
000076e4393d4c65  vmovaps [rsp+0x20], xmm2
000076e4393d4c6b  vmovaps [rsp+0x30], xmm3
000076e4393d4c71  vmovaps [rsp+0x40], xmm4
000076e4393d4c77  vmovaps [rsp+0x50], xmm5
000076e4393d4c7d  vmovaps [rsp+0x60], xmm6
000076e4393d4c83  vmovaps [rsp+0x70], xmm7
000076e4393d4c89  vmovaps [rsp+0x80], xmm8
000076e4393d4c92  vmovaps [rsp+0x90], xmm9
000076e4393d4c9b  vmovaps [rsp+0xA0], xmm10
000076e4393d4ca4  vmovaps [rsp+0xB0], xmm11
000076e4393d4cad  vmovaps [rsp+0xC0], xmm12
000076e4393d4cb6  vmovaps [rsp+0xD0], xmm13
000076e4393d4cbf  vmovaps [rsp+0xE0], xmm15
000076e4393d4cc8  sub rsp, 0x30
000076e4393d4ccc  movaps [rsp], xmm14
000076e4393d4cd1  movaps [rsp+0x10], xmm4
000076e4393d4cd6  movaps [rsp+0x20], xmm1
000076e4393d4cdb  lea rdi, [rsp]
000076e4393d4cdf  mov esi, 0x00
000076e4393d4ce4  mov rax, 0x63DBDEB43530
000076e4393d4cee  call rax
000076e4393d4cf0  movaps xmm14, [rsp]
000076e4393d4cf5  add rsp, 0x30
000076e4393d4cf9  vmovaps xmm0, [rsp]
000076e4393d4cfe  vmovaps xmm1, [rsp+0x10]
000076e4393d4d04  vmovaps xmm2, [rsp+0x20]
000076e4393d4d0a  vmovaps xmm3, [rsp+0x30]
000076e4393d4d10  vmovaps xmm4, [rsp+0x40]
000076e4393d4d16  vmovaps xmm5, [rsp+0x50]
000076e4393d4d1c  vmovaps xmm6, [rsp+0x60]
000076e4393d4d22  vmovaps xmm7, [rsp+0x70]
000076e4393d4d28  vmovaps xmm8, [rsp+0x80]
000076e4393d4d31  vmovaps xmm9, [rsp+0x90]
000076e4393d4d3a  vmovaps xmm10, [rsp+0xA0]
000076e4393d4d43  vmovaps xmm11, [rsp+0xB0]
000076e4393d4d4c  vmovaps xmm12, [rsp+0xC0]
000076e4393d4d55  vmovaps xmm13, [rsp+0xD0]
000076e4393d4d5e  vmovaps xmm15, [rsp+0xE0]
000076e4393d4d67  add rsp, 0xF0
000076e4393d4d6e  pop r11
000076e4393d4d70  pop r10
000076e4393d4d72  pop r9
000076e4393d4d74  pop r8
000076e4393d4d76  pop rsi
000076e4393d4d77  pop rdi
000076e4393d4d78  pop rdx
000076e4393d4d79  pop rcx
000076e4393d4d7a  pop rax
000076e4393d4d7b  add rsp, 0x08
000076e4393d4d7f  jmp 0x000076E4393D0203
000076e4393d4d84  sub rsp, 0x08
000076e4393d4d88  push rax
000076e4393d4d89  push rcx
000076e4393d4d8a  push rdx
000076e4393d4d8b  push rdi
000076e4393d4d8c  push rsi
000076e4393d4d8d  push r8
000076e4393d4d8f  push r9
000076e4393d4d91  push r10
000076e4393d4d93  push r11
000076e4393d4d95  sub rsp, 0xF0
000076e4393d4d9c  vmovaps [rsp], xmm0
000076e4393d4da1  vmovaps [rsp+0x10], xmm2
000076e4393d4da7  vmovaps [rsp+0x20], xmm3
000076e4393d4dad  vmovaps [rsp+0x30], xmm4
000076e4393d4db3  vmovaps [rsp+0x40], xmm5
000076e4393d4db9  vmovaps [rsp+0x50], xmm6
000076e4393d4dbf  vmovaps [rsp+0x60], xmm7
000076e4393d4dc5  vmovaps [rsp+0x70], xmm8
000076e4393d4dcb  vmovaps [rsp+0x80], xmm9
000076e4393d4dd4  vmovaps [rsp+0x90], xmm10
000076e4393d4ddd  vmovaps [rsp+0xA0], xmm11
000076e4393d4de6  vmovaps [rsp+0xB0], xmm12
000076e4393d4def  vmovaps [rsp+0xC0], xmm13
000076e4393d4df8  vmovaps [rsp+0xD0], xmm14
000076e4393d4e01  vmovaps [rsp+0xE0], xmm15
000076e4393d4e0a  sub rsp, 0x30
000076e4393d4e0e  movaps [rsp], xmm1
000076e4393d4e12  movaps [rsp+0x10], xmm12
000076e4393d4e18  movaps [rsp+0x20], xmm11
000076e4393d4e1e  lea rdi, [rsp]
000076e4393d4e22  mov esi, 0x00
000076e4393d4e27  mov rax, 0x63DBDEB43530
000076e4393d4e31  call rax
000076e4393d4e33  movaps xmm1, [rsp]
000076e4393d4e37  add rsp, 0x30
000076e4393d4e3b  vmovaps xmm0, [rsp]
000076e4393d4e40  vmovaps xmm2, [rsp+0x10]
000076e4393d4e46  vmovaps xmm3, [rsp+0x20]
000076e4393d4e4c  vmovaps xmm4, [rsp+0x30]
000076e4393d4e52  vmovaps xmm5, [rsp+0x40]
000076e4393d4e58  vmovaps xmm6, [rsp+0x50]
000076e4393d4e5e  vmovaps xmm7, [rsp+0x60]
000076e4393d4e64  vmovaps xmm8, [rsp+0x70]
000076e4393d4e6a  vmovaps xmm9, [rsp+0x80]
000076e4393d4e73  vmovaps xmm10, [rsp+0x90]
000076e4393d4e7c  vmovaps xmm11, [rsp+0xA0]
000076e4393d4e85  vmovaps xmm12, [rsp+0xB0]
000076e4393d4e8e  vmovaps xmm13, [rsp+0xC0]
000076e4393d4e97  vmovaps xmm14, [rsp+0xD0]
000076e4393d4ea0  vmovaps xmm15, [rsp+0xE0]
000076e4393d4ea9  add rsp, 0xF0
000076e4393d4eb0  pop r11
000076e4393d4eb2  pop r10
000076e4393d4eb4  pop r9
000076e4393d4eb6  pop r8
000076e4393d4eb8  pop rsi
000076e4393d4eb9  pop rdi
000076e4393d4eba  pop rdx
000076e4393d4ebb  pop rcx
000076e4393d4ebc  pop rax
000076e4393d4ebd  add rsp, 0x08
000076e4393d4ec1  jmp 0x000076E4393D0224
000076e4393d4ec6  call 0x000076E4392E20A0
000076e4393d4ecb  jmp 0x000076E4393D0232
000076e4393d4ed0  call 0x000076E439209D70
000076e4393d4ed5  jmp 0x000076E4393D023C
000076e4393d4eda  sub rsp, 0x08
000076e4393d4ede  push rax
000076e4393d4edf  push rcx
000076e4393d4ee0  push rdx
000076e4393d4ee1  push rdi
000076e4393d4ee2  push rsi
000076e4393d4ee3  push r8
000076e4393d4ee5  push r9
000076e4393d4ee7  push r10
000076e4393d4ee9  push r11
000076e4393d4eeb  sub rsp, 0xF0
000076e4393d4ef2  vmovaps [rsp], xmm0
000076e4393d4ef7  vmovaps [rsp+0x10], xmm1
000076e4393d4efd  vmovaps [rsp+0x20], xmm2
000076e4393d4f03  vmovaps [rsp+0x30], xmm3
000076e4393d4f09  vmovaps [rsp+0x40], xmm4
000076e4393d4f0f  vmovaps [rsp+0x50], xmm5
000076e4393d4f15  vmovaps [rsp+0x60], xmm6
000076e4393d4f1b  vmovaps [rsp+0x70], xmm8
000076e4393d4f21  vmovaps [rsp+0x80], xmm9
000076e4393d4f2a  vmovaps [rsp+0x90], xmm10
000076e4393d4f33  vmovaps [rsp+0xA0], xmm11
000076e4393d4f3c  vmovaps [rsp+0xB0], xmm12
000076e4393d4f45  vmovaps [rsp+0xC0], xmm13
000076e4393d4f4e  vmovaps [rsp+0xD0], xmm14
000076e4393d4f57  vmovaps [rsp+0xE0], xmm15
000076e4393d4f60  sub rsp, 0x30
000076e4393d4f64  movaps [rsp], xmm7
000076e4393d4f68  movaps [rsp+0x10], xmm15
000076e4393d4f6e  movaps [rsp+0x20], xmm10
000076e4393d4f74  lea rdi, [rsp]
000076e4393d4f78  mov esi, 0x00
000076e4393d4f7d  mov rax, 0x63DBDEB43530
000076e4393d4f87  call rax
000076e4393d4f89  movaps xmm7, [rsp]
000076e4393d4f8d  add rsp, 0x30
000076e4393d4f91  vmovaps xmm0, [rsp]
000076e4393d4f96  vmovaps xmm1, [rsp+0x10]
000076e4393d4f9c  vmovaps xmm2, [rsp+0x20]
000076e4393d4fa2  vmovaps xmm3, [rsp+0x30]
000076e4393d4fa8  vmovaps xmm4, [rsp+0x40]
000076e4393d4fae  vmovaps xmm5, [rsp+0x50]
000076e4393d4fb4  vmovaps xmm6, [rsp+0x60]
000076e4393d4fba  vmovaps xmm8, [rsp+0x70]
000076e4393d4fc0  vmovaps xmm9, [rsp+0x80]
000076e4393d4fc9  vmovaps xmm10, [rsp+0x90]
000076e4393d4fd2  vmovaps xmm11, [rsp+0xA0]
000076e4393d4fdb  vmovaps xmm12, [rsp+0xB0]
000076e4393d4fe4  vmovaps xmm13, [rsp+0xC0]
000076e4393d4fed  vmovaps xmm14, [rsp+0xD0]
000076e4393d4ff6  vmovaps xmm15, [rsp+0xE0]
000076e4393d4fff  add rsp, 0xF0
000076e4393d5006  pop r11
000076e4393d5008  pop r10
000076e4393d500a  pop r9
000076e4393d500c  pop r8
000076e4393d500e  pop rsi
000076e4393d500f  pop rdi
000076e4393d5010  pop rdx
000076e4393d5011  pop rcx
000076e4393d5012  pop rax
000076e4393d5013  add rsp, 0x08
000076e4393d5017  jmp 0x000076E4393D025D
000076e4393d501c  sub rsp, 0x08
000076e4393d5020  push rax
000076e4393d5021  push rcx
000076e4393d5022  push rdx
000076e4393d5023  push rdi
000076e4393d5024  push rsi
000076e4393d5025  push r8
000076e4393d5027  push r9
000076e4393d5029  push r10
000076e4393d502b  push r11
000076e4393d502d  sub rsp, 0xF0
000076e4393d5034  vmovaps [rsp], xmm0
000076e4393d5039  vmovaps [rsp+0x10], xmm1
000076e4393d503f  vmovaps [rsp+0x20], xmm2
000076e4393d5045  vmovaps [rsp+0x30], xmm3
000076e4393d504b  vmovaps [rsp+0x40], xmm4
000076e4393d5051  vmovaps [rsp+0x50], xmm5
000076e4393d5057  vmovaps [rsp+0x60], xmm6
000076e4393d505d  vmovaps [rsp+0x70], xmm7
000076e4393d5063  vmovaps [rsp+0x80], xmm8
000076e4393d506c  vmovaps [rsp+0x90], xmm9
000076e4393d5075  vmovaps [rsp+0xA0], xmm11
000076e4393d507e  vmovaps [rsp+0xB0], xmm12
000076e4393d5087  vmovaps [rsp+0xC0], xmm13
000076e4393d5090  vmovaps [rsp+0xD0], xmm14
000076e4393d5099  vmovaps [rsp+0xE0], xmm15
000076e4393d50a2  sub rsp, 0x30
000076e4393d50a6  movaps [rsp], xmm10
000076e4393d50ab  movaps [rsp+0x10], xmm11
000076e4393d50b1  movaps [rsp+0x20], xmm15
000076e4393d50b7  lea rdi, [rsp]
000076e4393d50bb  mov esi, 0x00
000076e4393d50c0  mov rax, 0x63DBDEB43530
000076e4393d50ca  call rax
000076e4393d50cc  movaps xmm10, [rsp]
000076e4393d50d1  add rsp, 0x30
000076e4393d50d5  vmovaps xmm0, [rsp]
000076e4393d50da  vmovaps xmm1, [rsp+0x10]
000076e4393d50e0  vmovaps xmm2, [rsp+0x20]
000076e4393d50e6  vmovaps xmm3, [rsp+0x30]
000076e4393d50ec  vmovaps xmm4, [rsp+0x40]
000076e4393d50f2  vmovaps xmm5, [rsp+0x50]
000076e4393d50f8  vmovaps xmm6, [rsp+0x60]
000076e4393d50fe  vmovaps xmm7, [rsp+0x70]
000076e4393d5104  vmovaps xmm8, [rsp+0x80]
000076e4393d510d  vmovaps xmm9, [rsp+0x90]
000076e4393d5116  vmovaps xmm11, [rsp+0xA0]
000076e4393d511f  vmovaps xmm12, [rsp+0xB0]
000076e4393d5128  vmovaps xmm13, [rsp+0xC0]
000076e4393d5131  vmovaps xmm14, [rsp+0xD0]
000076e4393d513a  vmovaps xmm15, [rsp+0xE0]
000076e4393d5143  add rsp, 0xF0
000076e4393d514a  pop r11
000076e4393d514c  pop r10
000076e4393d514e  pop r9
000076e4393d5150  pop r8
000076e4393d5152  pop rsi
000076e4393d5153  pop rdi
000076e4393d5154  pop rdx
000076e4393d5155  pop rcx
000076e4393d5156  pop rax
000076e4393d5157  add rsp, 0x08
000076e4393d515b  jmp 0x000076E4393D028B
000076e4393d5160  sub rsp, 0x08
000076e4393d5164  push rax
000076e4393d5165  push rcx
000076e4393d5166  push rdx
000076e4393d5167  push rdi
000076e4393d5168  push rsi
000076e4393d5169  push r8
000076e4393d516b  push r9
000076e4393d516d  push r10
000076e4393d516f  push r11
000076e4393d5171  sub rsp, 0xF0
000076e4393d5178  vmovaps [rsp], xmm0
000076e4393d517d  vmovaps [rsp+0x10], xmm1
000076e4393d5183  vmovaps [rsp+0x20], xmm2
000076e4393d5189  vmovaps [rsp+0x30], xmm3
000076e4393d518f  vmovaps [rsp+0x40], xmm4
000076e4393d5195  vmovaps [rsp+0x50], xmm5
000076e4393d519b  vmovaps [rsp+0x60], xmm6
000076e4393d51a1  vmovaps [rsp+0x70], xmm7
000076e4393d51a7  vmovaps [rsp+0x80], xmm8
000076e4393d51b0  vmovaps [rsp+0x90], xmm9
000076e4393d51b9  vmovaps [rsp+0xA0], xmm10
000076e4393d51c2  vmovaps [rsp+0xB0], xmm12
000076e4393d51cb  vmovaps [rsp+0xC0], xmm13
000076e4393d51d4  vmovaps [rsp+0xD0], xmm14
000076e4393d51dd  vmovaps [rsp+0xE0], xmm15
000076e4393d51e6  sub rsp, 0x30
000076e4393d51ea  movaps [rsp], xmm11
000076e4393d51ef  movaps [rsp+0x10], xmm12
000076e4393d51f5  movaps [rsp+0x20], xmm15
000076e4393d51fb  lea rdi, [rsp]
000076e4393d51ff  mov esi, 0x00
000076e4393d5204  mov rax, 0x63DBDEB43530
000076e4393d520e  call rax
000076e4393d5210  movaps xmm11, [rsp]
000076e4393d5215  add rsp, 0x30
000076e4393d5219  vmovaps xmm0, [rsp]
000076e4393d521e  vmovaps xmm1, [rsp+0x10]
000076e4393d5224  vmovaps xmm2, [rsp+0x20]
000076e4393d522a  vmovaps xmm3, [rsp+0x30]
000076e4393d5230  vmovaps xmm4, [rsp+0x40]
000076e4393d5236  vmovaps xmm5, [rsp+0x50]
000076e4393d523c  vmovaps xmm6, [rsp+0x60]
000076e4393d5242  vmovaps xmm7, [rsp+0x70]
000076e4393d5248  vmovaps xmm8, [rsp+0x80]
000076e4393d5251  vmovaps xmm9, [rsp+0x90]
000076e4393d525a  vmovaps xmm10, [rsp+0xA0]
000076e4393d5263  vmovaps xmm12, [rsp+0xB0]
000076e4393d526c  vmovaps xmm13, [rsp+0xC0]
000076e4393d5275  vmovaps xmm14, [rsp+0xD0]
000076e4393d527e  vmovaps xmm15, [rsp+0xE0]
000076e4393d5287  add rsp, 0xF0
000076e4393d528e  pop r11
000076e4393d5290  pop r10
000076e4393d5292  pop r9
000076e4393d5294  pop r8
000076e4393d5296  pop rsi
000076e4393d5297  pop rdi
000076e4393d5298  pop rdx
000076e4393d5299  pop rcx
000076e4393d529a  pop rax
000076e4393d529b  add rsp, 0x08
000076e4393d529f  jmp 0x000076E4393D02B9
000076e4393d52a4  sub rsp, 0x08
000076e4393d52a8  push rax
000076e4393d52a9  push rcx
000076e4393d52aa  push rdx
000076e4393d52ab  push rdi
000076e4393d52ac  push rsi
000076e4393d52ad  push r8
000076e4393d52af  push r9
000076e4393d52b1  push r10
000076e4393d52b3  push r11
000076e4393d52b5  sub rsp, 0xF0
000076e4393d52bc  vmovaps [rsp], xmm0
000076e4393d52c1  vmovaps [rsp+0x10], xmm1
000076e4393d52c7  vmovaps [rsp+0x20], xmm2
000076e4393d52cd  vmovaps [rsp+0x30], xmm3
000076e4393d52d3  vmovaps [rsp+0x40], xmm4
000076e4393d52d9  vmovaps [rsp+0x50], xmm5
000076e4393d52df  vmovaps [rsp+0x60], xmm6
000076e4393d52e5  vmovaps [rsp+0x70], xmm7
000076e4393d52eb  vmovaps [rsp+0x80], xmm8
000076e4393d52f4  vmovaps [rsp+0x90], xmm9
000076e4393d52fd  vmovaps [rsp+0xA0], xmm10
000076e4393d5306  vmovaps [rsp+0xB0], xmm11
000076e4393d530f  vmovaps [rsp+0xC0], xmm12
000076e4393d5318  vmovaps [rsp+0xD0], xmm13
000076e4393d5321  vmovaps [rsp+0xE0], xmm14
000076e4393d532a  sub rsp, 0x30
000076e4393d532e  movaps [rsp], xmm15
000076e4393d5333  movaps [rsp+0x10], xmm13
000076e4393d5339  movaps [rsp+0x20], xmm9
000076e4393d533f  lea rdi, [rsp]
000076e4393d5343  mov esi, 0x00
000076e4393d5348  mov rax, 0x63DBDEB43530
000076e4393d5352  call rax
000076e4393d5354  movaps xmm15, [rsp]
000076e4393d5359  add rsp, 0x30
000076e4393d535d  vmovaps xmm0, [rsp]
000076e4393d5362  vmovaps xmm1, [rsp+0x10]
000076e4393d5368  vmovaps xmm2, [rsp+0x20]
000076e4393d536e  vmovaps xmm3, [rsp+0x30]
000076e4393d5374  vmovaps xmm4, [rsp+0x40]
000076e4393d537a  vmovaps xmm5, [rsp+0x50]
000076e4393d5380  vmovaps xmm6, [rsp+0x60]
000076e4393d5386  vmovaps xmm7, [rsp+0x70]
000076e4393d538c  vmovaps xmm8, [rsp+0x80]
000076e4393d5395  vmovaps xmm9, [rsp+0x90]
000076e4393d539e  vmovaps xmm10, [rsp+0xA0]
000076e4393d53a7  vmovaps xmm11, [rsp+0xB0]
000076e4393d53b0  vmovaps xmm12, [rsp+0xC0]
000076e4393d53b9  vmovaps xmm13, [rsp+0xD0]
000076e4393d53c2  vmovaps xmm14, [rsp+0xE0]
000076e4393d53cb  add rsp, 0xF0
000076e4393d53d2  pop r11
000076e4393d53d4  pop r10
000076e4393d53d6  pop r9
000076e4393d53d8  pop r8
000076e4393d53da  pop rsi
000076e4393d53db  pop rdi
000076e4393d53dc  pop rdx
000076e4393d53dd  pop rcx
000076e4393d53de  pop rax
000076e4393d53df  add rsp, 0x08
000076e4393d53e3  jmp 0x000076E4393D02D4
000076e4393d53e8  sub rsp, 0x08
000076e4393d53ec  push rax
000076e4393d53ed  push rcx
000076e4393d53ee  push rdx
000076e4393d53ef  push rdi
000076e4393d53f0  push rsi
000076e4393d53f1  push r8
000076e4393d53f3  push r9
000076e4393d53f5  push r10
000076e4393d53f7  push r11
000076e4393d53f9  sub rsp, 0xF0
000076e4393d5400  vmovaps [rsp], xmm0
000076e4393d5405  vmovaps [rsp+0x10], xmm1
000076e4393d540b  vmovaps [rsp+0x20], xmm2
000076e4393d5411  vmovaps [rsp+0x30], xmm3
000076e4393d5417  vmovaps [rsp+0x40], xmm4
000076e4393d541d  vmovaps [rsp+0x50], xmm5
000076e4393d5423  vmovaps [rsp+0x60], xmm6
000076e4393d5429  vmovaps [rsp+0x70], xmm7
000076e4393d542f  vmovaps [rsp+0x80], xmm8
000076e4393d5438  vmovaps [rsp+0x90], xmm9
000076e4393d5441  vmovaps [rsp+0xA0], xmm10
000076e4393d544a  vmovaps [rsp+0xB0], xmm11
000076e4393d5453  vmovaps [rsp+0xC0], xmm12
000076e4393d545c  vmovaps [rsp+0xD0], xmm14
000076e4393d5465  vmovaps [rsp+0xE0], xmm15
000076e4393d546e  sub rsp, 0x30
000076e4393d5472  movaps [rsp], xmm13
000076e4393d5477  movaps [rsp+0x10], xmm8
000076e4393d547d  movaps [rsp+0x20], xmm14
000076e4393d5483  lea rdi, [rsp]
000076e4393d5487  mov esi, 0x00
000076e4393d548c  mov rax, 0x63DBDEB43530
000076e4393d5496  call rax
000076e4393d5498  movaps xmm13, [rsp]
000076e4393d549d  add rsp, 0x30
000076e4393d54a1  vmovaps xmm0, [rsp]
000076e4393d54a6  vmovaps xmm1, [rsp+0x10]
000076e4393d54ac  vmovaps xmm2, [rsp+0x20]
000076e4393d54b2  vmovaps xmm3, [rsp+0x30]
000076e4393d54b8  vmovaps xmm4, [rsp+0x40]
000076e4393d54be  vmovaps xmm5, [rsp+0x50]
000076e4393d54c4  vmovaps xmm6, [rsp+0x60]
000076e4393d54ca  vmovaps xmm7, [rsp+0x70]
000076e4393d54d0  vmovaps xmm8, [rsp+0x80]
000076e4393d54d9  vmovaps xmm9, [rsp+0x90]
000076e4393d54e2  vmovaps xmm10, [rsp+0xA0]
000076e4393d54eb  vmovaps xmm11, [rsp+0xB0]
000076e4393d54f4  vmovaps xmm12, [rsp+0xC0]
000076e4393d54fd  vmovaps xmm14, [rsp+0xD0]
000076e4393d5506  vmovaps xmm15, [rsp+0xE0]
000076e4393d550f  add rsp, 0xF0
000076e4393d5516  pop r11
000076e4393d5518  pop r10
000076e4393d551a  pop r9
000076e4393d551c  pop r8
000076e4393d551e  pop rsi
000076e4393d551f  pop rdi
000076e4393d5520  pop rdx
000076e4393d5521  pop rcx
000076e4393d5522  pop rax
000076e4393d5523  add rsp, 0x08
000076e4393d5527  jmp 0x000076E4393D02F7
000076e4393d552c  sub rsp, 0x08
000076e4393d5530  push rax
000076e4393d5531  push rcx
000076e4393d5532  push rdx
000076e4393d5533  push rdi
000076e4393d5534  push rsi
000076e4393d5535  push r8
000076e4393d5537  push r9
000076e4393d5539  push r10
000076e4393d553b  push r11
000076e4393d553d  sub rsp, 0xF0
000076e4393d5544  vmovaps [rsp], xmm0
000076e4393d5549  vmovaps [rsp+0x10], xmm1
000076e4393d554f  vmovaps [rsp+0x20], xmm2
000076e4393d5555  vmovaps [rsp+0x30], xmm3
000076e4393d555b  vmovaps [rsp+0x40], xmm4
000076e4393d5561  vmovaps [rsp+0x50], xmm5
000076e4393d5567  vmovaps [rsp+0x60], xmm6
000076e4393d556d  vmovaps [rsp+0x70], xmm7
000076e4393d5573  vmovaps [rsp+0x80], xmm8
000076e4393d557c  vmovaps [rsp+0x90], xmm9
000076e4393d5585  vmovaps [rsp+0xA0], xmm10
000076e4393d558e  vmovaps [rsp+0xB0], xmm11
000076e4393d5597  vmovaps [rsp+0xC0], xmm12
000076e4393d55a0  vmovaps [rsp+0xD0], xmm13
000076e4393d55a9  vmovaps [rsp+0xE0], xmm15
000076e4393d55b2  sub rsp, 0x30
000076e4393d55b6  movaps [rsp], xmm14
000076e4393d55bb  movaps [rsp+0x10], xmm1
000076e4393d55c0  movaps [rsp+0x20], xmm10
000076e4393d55c6  lea rdi, [rsp]
000076e4393d55ca  mov esi, 0x00
000076e4393d55cf  mov rax, 0x63DBDEB43530
000076e4393d55d9  call rax
000076e4393d55db  movaps xmm14, [rsp]
000076e4393d55e0  add rsp, 0x30
000076e4393d55e4  vmovaps xmm0, [rsp]
000076e4393d55e9  vmovaps xmm1, [rsp+0x10]
000076e4393d55ef  vmovaps xmm2, [rsp+0x20]
000076e4393d55f5  vmovaps xmm3, [rsp+0x30]
000076e4393d55fb  vmovaps xmm4, [rsp+0x40]
000076e4393d5601  vmovaps xmm5, [rsp+0x50]
000076e4393d5607  vmovaps xmm6, [rsp+0x60]
000076e4393d560d  vmovaps xmm7, [rsp+0x70]
000076e4393d5613  vmovaps xmm8, [rsp+0x80]
000076e4393d561c  vmovaps xmm9, [rsp+0x90]
000076e4393d5625  vmovaps xmm10, [rsp+0xA0]
000076e4393d562e  vmovaps xmm11, [rsp+0xB0]
000076e4393d5637  vmovaps xmm12, [rsp+0xC0]
000076e4393d5640  vmovaps xmm13, [rsp+0xD0]
000076e4393d5649  vmovaps xmm15, [rsp+0xE0]
000076e4393d5652  add rsp, 0xF0
000076e4393d5659  pop r11
000076e4393d565b  pop r10
000076e4393d565d  pop r9
000076e4393d565f  pop r8
000076e4393d5661  pop rsi
000076e4393d5662  pop rdi
000076e4393d5663  pop rdx
000076e4393d5664  pop rcx
000076e4393d5665  pop rax
000076e4393d5666  add rsp, 0x08
000076e4393d566a  jmp 0x000076E4393D031A
000076e4393d566f  sub rsp, 0x08
000076e4393d5673  push rax
000076e4393d5674  push rcx
000076e4393d5675  push rdx
000076e4393d5676  push rdi
000076e4393d5677  push rsi
000076e4393d5678  push r8
000076e4393d567a  push r9
000076e4393d567c  push r10
000076e4393d567e  push r11
000076e4393d5680  sub rsp, 0xF0
000076e4393d5687  vmovaps [rsp], xmm0
000076e4393d568c  vmovaps [rsp+0x10], xmm2
000076e4393d5692  vmovaps [rsp+0x20], xmm3
000076e4393d5698  vmovaps [rsp+0x30], xmm4
000076e4393d569e  vmovaps [rsp+0x40], xmm5
000076e4393d56a4  vmovaps [rsp+0x50], xmm6
000076e4393d56aa  vmovaps [rsp+0x60], xmm7
000076e4393d56b0  vmovaps [rsp+0x70], xmm8
000076e4393d56b6  vmovaps [rsp+0x80], xmm9
000076e4393d56bf  vmovaps [rsp+0x90], xmm10
000076e4393d56c8  vmovaps [rsp+0xA0], xmm11
000076e4393d56d1  vmovaps [rsp+0xB0], xmm12
000076e4393d56da  vmovaps [rsp+0xC0], xmm13
000076e4393d56e3  vmovaps [rsp+0xD0], xmm14
000076e4393d56ec  vmovaps [rsp+0xE0], xmm15
000076e4393d56f5  sub rsp, 0x30
000076e4393d56f9  movaps [rsp], xmm1
000076e4393d56fd  movaps [rsp+0x10], xmm7
000076e4393d5702  movaps [rsp+0x20], xmm11
000076e4393d5708  lea rdi, [rsp]
000076e4393d570c  mov esi, 0x00
000076e4393d5711  mov rax, 0x63DBDEB43530
000076e4393d571b  call rax
000076e4393d571d  movaps xmm1, [rsp]
000076e4393d5721  add rsp, 0x30
000076e4393d5725  vmovaps xmm0, [rsp]
000076e4393d572a  vmovaps xmm2, [rsp+0x10]
000076e4393d5730  vmovaps xmm3, [rsp+0x20]
000076e4393d5736  vmovaps xmm4, [rsp+0x30]
000076e4393d573c  vmovaps xmm5, [rsp+0x40]
000076e4393d5742  vmovaps xmm6, [rsp+0x50]
000076e4393d5748  vmovaps xmm7, [rsp+0x60]
000076e4393d574e  vmovaps xmm8, [rsp+0x70]
000076e4393d5754  vmovaps xmm9, [rsp+0x80]
000076e4393d575d  vmovaps xmm10, [rsp+0x90]
000076e4393d5766  vmovaps xmm11, [rsp+0xA0]
000076e4393d576f  vmovaps xmm12, [rsp+0xB0]
000076e4393d5778  vmovaps xmm13, [rsp+0xC0]
000076e4393d5781  vmovaps xmm14, [rsp+0xD0]
000076e4393d578a  vmovaps xmm15, [rsp+0xE0]
000076e4393d5793  add rsp, 0xF0
000076e4393d579a  pop r11
000076e4393d579c  pop r10
000076e4393d579e  pop r9
000076e4393d57a0  pop r8
000076e4393d57a2  pop rsi
000076e4393d57a3  pop rdi
000076e4393d57a4  pop rdx
000076e4393d57a5  pop rcx
000076e4393d57a6  pop rax
000076e4393d57a7  add rsp, 0x08
000076e4393d57ab  jmp 0x000076E4393D033B
000076e4393d57b0  call 0x000076E43920E880
000076e4393d57b5  jmp 0x000076E4393D034E
000076e4393d57ba  call 0x000076E43920C380
000076e4393d57bf  jmp 0x000076E4393D0359
000076e4393d57c4  call 0x000076E43920D600
000076e4393d57c9  jmp 0x000076E4393D0364
000076e4393d57ce  call 0x000076E4391FF540
000076e4393d57d3  jmp 0x000076E4393D036F
000076e4393d57d8  int3
000076e4393d57d9  nop [rax], eax
000076e4393d57e0  mov rax, [r15+0x40]
000076e4393d57e4  mov r14, [r15+0x58]
000076e4393d57e8  lea r12, [rax+r14*1]
000076e4393d57ec  movaps xmm1, [r15+0x1D0]
000076e4393d57f4  vmovaps [rsp+0x10], xmm1
000076e4393d57fa  vmovaps xmm15, [rsp+0x10]
000076e4393d5800  por xmm1, xmm15
000076e4393d5805  movaps xmm14, [r15+0x1A0]
000076e4393d580d  vmovaps [rsp+0x10], xmm14
000076e4393d5813  vmovaps xmm13, [rsp+0x10]
000076e4393d5819  por xmm14, xmm13
000076e4393d581e  lea rax, [r12+0x30]
000076e4393d5823  mov r11, [r13+rax*1]
000076e4393d5828  lea rax, [r12+0x38]
000076e4393d582d  mov r10, [r13+rax*1]
000076e4393d5832  movq xmm13, r11
000076e4393d5837  movq xmm12, r10
000076e4393d583c  movq xmm13, xmm13
000076e4393d5841  vmovaps [rsp+0x10], xmm13
000076e4393d5847  movq xmm13, xmm13
000076e4393d584c  movaps [r15+0x130], xmm13
000076e4393d5854  movq xmm12, xmm12
000076e4393d5859  vmovaps [rsp+0x20], xmm12
000076e4393d585f  movq xmm12, xmm12
000076e4393d5864  movaps [r15+0x280], xmm12
000076e4393d586c  movaps xmm13, [r15+0x270]
000076e4393d5874  vmovaps [rsp+0x30], xmm13
000076e4393d587a  vmovaps xmm12, [rsp+0x30]
000076e4393d5880  por xmm13, xmm12
000076e4393d5885  lea rax, [r12+0x20]
000076e4393d588a  mov r11, [r13+rax*1]
000076e4393d588f  lea rax, [r12+0x28]
000076e4393d5894  mov r10, [r13+rax*1]
000076e4393d5899  movq xmm12, r11
000076e4393d589e  movq xmm11, r10
000076e4393d58a3  movq xmm12, xmm12
000076e4393d58a8  vmovaps [rsp+0x30], xmm12
000076e4393d58ae  movq xmm12, xmm12
000076e4393d58b3  movaps [r15+0x150], xmm12
000076e4393d58bb  movq xmm11, xmm11
000076e4393d58c0  vmovaps [rsp+0x40], xmm11
000076e4393d58c6  movq xmm11, xmm11
000076e4393d58cb  movaps [r15+0x140], xmm11
000076e4393d58d3  lea rax, [r12+0x10]
000076e4393d58d8  mov r11, [r13+rax*1]
000076e4393d58dd  lea rax, [r12+0x18]
000076e4393d58e2  mov r10, [r13+rax*1]
000076e4393d58e7  movq xmm12, r11
000076e4393d58ec  movq xmm11, r10
000076e4393d58f1  movq xmm12, xmm12
000076e4393d58f6  vmovaps [rsp+0x50], xmm12
000076e4393d58fc  movq xmm12, xmm12
000076e4393d5901  movaps [r15+0x170], xmm12
000076e4393d5909  movq xmm11, xmm11
000076e4393d590e  vmovaps [rsp+0x60], xmm11
000076e4393d5914  movq xmm11, xmm11
000076e4393d5919  movaps [r15+0x160], xmm11
000076e4393d5921  mov rax, [r13+r12*1]
000076e4393d5926  vmovq xmm12, rax
000076e4393d592b  vpbroadcastq xmm12, xmm12
000076e4393d5930  lea rax, [r12+0x08]
000076e4393d5935  mov r12, [r13+rax*1]
000076e4393d593a  movq xmm11, r12
000076e4393d593f  movaps [r15+0x230], xmm11
000076e4393d5947  mov rax, [r15+0xF8]
000076e4393d594e  lea r12, [rax+0x50]
000076e4393d5952  movups xmm11, [r13+r12*1]
000076e4393d5958  lea r12, [rax+0x60]
000076e4393d595c  movups xmm10, [r13+r12*1]
000076e4393d5962  lea r12, [rax+0x30]
000076e4393d5966  movups xmm9, [r13+r12*1]
000076e4393d596c  mov r12, [r15+0x50]
000076e4393d5970  lea r11, [r12+r14*1]
000076e4393d5974  mov [r15+0x60], r11
000076e4393d5978  lea r12, [r14+0x40]
000076e4393d597c  mov [r15+0x58], r12
000076e4393d5980  movaps xmm8, xmm12
000076e4393d5984  mulpd xmm8, xmm15
000076e4393d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000076e4393d598f  ptest xmm7, xmm7
000076e4393d5994  jnz 0x000076E4393D67B7
000076e4393d599a  movq xmm15, qword ptr [r15+0x230]
000076e4393d59a3  vmovaps [rsp+0x70], xmm15
000076e4393d59a9  vpermilpd xmm15, xmm15, 0x00
000076e4393d59af  movaps xmm7, xmm9
000076e4393d59b3  mulpd xmm7, xmm15
000076e4393d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000076e4393d59bd  ptest xmm6, xmm6
000076e4393d59c2  jnz 0x000076E4393D68FB
000076e4393d59c8  vxorps xmm15, xmm15, xmm15
000076e4393d59cd  vpbroadcastq xmm15, xmm15
000076e4393d59d2  movaps xmm9, xmm12
000076e4393d59d6  mulpd xmm9, xmm10
000076e4393d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000076e4393d59e1  ptest xmm6, xmm6
000076e4393d59e6  jnz 0x000076E4393D6A3D
000076e4393d59ec  movaps xmm10, xmm12
000076e4393d59f0  mulpd xmm10, xmm11
000076e4393d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000076e4393d59fb  ptest xmm6, xmm6
000076e4393d5a00  jnz 0x000076E4393D6B81
000076e4393d5a06  movaps xmm11, [r15+0x1F0]
000076e4393d5a0e  movaps xmm6, xmm12
000076e4393d5a12  mulpd xmm6, xmm11
000076e4393d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000076e4393d5a1c  ptest xmm5, xmm5
000076e4393d5a21  jnz 0x000076E4393D6CC5
000076e4393d5a27  movaps xmm12, [r15+0x2A0]
000076e4393d5a2f  vmovaps [rsp+0x80], xmm12
000076e4393d5a38  vmovaps xmm11, [rsp+0x80]
000076e4393d5a41  por xmm12, xmm11
000076e4393d5a46  movaps xmm11, [r15+0x250]
000076e4393d5a4e  vmovaps [rsp+0x80], xmm11
000076e4393d5a57  vmovaps xmm5, [rsp+0x80]
000076e4393d5a60  por xmm11, xmm5
000076e4393d5a65  vmovaps xmm4, [rsp+0x70]
000076e4393d5a6b  vpermilpd xmm4, xmm4, 0x00
000076e4393d5a71  movaps xmm3, xmm5
000076e4393d5a74  mulpd xmm3, xmm4
000076e4393d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000076e4393d5a7d  ptest xmm2, xmm2
000076e4393d5a82  jnz 0x000076E4393D6E07
000076e4393d5a88  mov [rsp+0x80], rax
000076e4393d5a90  xor eax, eax
000076e4393d5a92  mov r14d, 0x200
000076e4393d5a98  cmp r12, r14
000076e4393d5a9b  cmc
000076e4393d5a9c  lahf
000076e4393d5a9d  seto al
000076e4393d5aa0  mov [r15+0x108], eax
000076e4393d5aa7  movaps xmm5, xmm8
000076e4393d5aab  addpd xmm5, xmm15
000076e4393d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000076e4393d5ab5  ptest xmm4, xmm4
000076e4393d5aba  jnz 0x000076E4393D6F47
000076e4393d5ac0  movaps xmm8, [r15+0x1B0]
000076e4393d5ac8  movaps xmm4, xmm9
000076e4393d5acc  addpd xmm4, xmm8
000076e4393d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000076e4393d5ad6  ptest xmm2, xmm2
000076e4393d5adb  jnz 0x000076E4393D7089
000076e4393d5ae1  movaps xmm9, xmm10
000076e4393d5ae5  addpd xmm9, xmm8
000076e4393d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000076e4393d5af0  ptest xmm2, xmm2
000076e4393d5af5  jnz 0x000076E4393D71CB
000076e4393d5afb  movaps xmm10, [r15+0x2F0]
000076e4393d5b03  vmovaps [rsp+0x90], xmm10
000076e4393d5b0c  vmovaps xmm8, [rsp+0x90]
000076e4393d5b15  por xmm10, xmm8
000076e4393d5b1a  movaps xmm8, [r15+0x2E0]
000076e4393d5b22  vmovaps [rsp+0x90], xmm8
000076e4393d5b2b  vmovaps xmm2, [rsp+0x90]
000076e4393d5b34  por xmm8, xmm2
000076e4393d5b39  movaps xmm2, [r15+0x2D0]
000076e4393d5b41  vmovaps [rsp+0x90], xmm2
000076e4393d5b4a  vmovaps [rsp+0xA0], xmm1
000076e4393d5b53  vmovaps xmm1, [rsp+0x90]
000076e4393d5b5c  por xmm2, xmm1
000076e4393d5b60  movaps xmm1, [r15+0x200]
000076e4393d5b68  vmovaps [rsp+0x90], xmm1
000076e4393d5b71  vmovaps [rsp+0xB0], xmm15
000076e4393d5b7a  vmovaps xmm15, [rsp+0x90]
000076e4393d5b83  por xmm1, xmm15
000076e4393d5b88  movaps xmm15, [r15+0x1C0]
000076e4393d5b90  vmovaps [rsp+0x90], xmm15
000076e4393d5b99  vmovaps [rsp+0xC0], xmm1
000076e4393d5ba2  vmovaps xmm1, [rsp+0x90]
000076e4393d5bab  por xmm15, xmm1
000076e4393d5bb0  movaps xmm1, [r15+0x190]
000076e4393d5bb8  vmovaps [rsp+0x90], xmm1
000076e4393d5bc1  vmovaps [rsp+0xD0], xmm15
000076e4393d5bca  vmovaps xmm15, [rsp+0x90]
000076e4393d5bd3  por xmm1, xmm15
000076e4393d5bd8  movaps xmm15, [r15+0x300]
000076e4393d5be0  vmovaps [rsp+0x90], xmm15
000076e4393d5be9  vmovaps [rsp+0xE0], xmm1
000076e4393d5bf2  vmovaps xmm1, [rsp+0x90]
000076e4393d5bfb  por xmm15, xmm1
000076e4393d5c00  mov rax, [rsp+0x80]
000076e4393d5c08  lea r14, [rax+0xA0]
000076e4393d5c0f  movups xmm1, [r13+r14*1]
000076e4393d5c15  lea r14, [rax+0xB0]
000076e4393d5c1c  vmovaps [rsp+0x80], xmm1
000076e4393d5c25  movups xmm1, [r13+r14*1]
000076e4393d5c2b  vmovaps [rsp+0x90], xmm1
000076e4393d5c34  vmovaps [rsp+0xF0], xmm15
000076e4393d5c3d  vmovaps xmm15, [rsp+0xB0]
000076e4393d5c46  vmovaps [rsp+0xB0], xmm14
000076e4393d5c4f  movaps xmm1, xmm6
000076e4393d5c52  addpd xmm1, xmm15
000076e4393d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000076e4393d5c5c  ptest xmm14, xmm14
000076e4393d5c62  jnz 0x000076E4393D7323
000076e4393d5c68  lea r14, [rax+0xF0]
000076e4393d5c6f  movups xmm15, [r13+r14*1]
000076e4393d5c75  movaps xmm14, xmm4
000076e4393d5c79  addpd xmm14, xmm3
000076e4393d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000076e4393d5c84  ptest xmm6, xmm6
000076e4393d5c89  jnz 0x000076E4393D746E
000076e4393d5c8f  movaps xmm6, xmm9
000076e4393d5c93  addpd xmm6, xmm7
000076e4393d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000076e4393d5c9c  ptest xmm4, xmm4
000076e4393d5ca1  jnz 0x000076E4393D75B0
000076e4393d5ca7  vmovaps xmm9, [rsp+0x70]
000076e4393d5cad  vpermilpd xmm9, xmm9, 0x00
000076e4393d5cb3  vmovaps xmm4, [rsp+0x90]
000076e4393d5cbc  movaps xmm7, xmm4
000076e4393d5cbf  mulpd xmm7, xmm9
000076e4393d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000076e4393d5cc9  ptest xmm3, xmm3
000076e4393d5cce  jnz 0x000076E4393D76F1
000076e4393d5cd4  vmovaps xmm9, [rsp+0x50]
000076e4393d5cda  vpermilpd xmm9, xmm9, 0x00
000076e4393d5ce0  movaps xmm4, xmm15
000076e4393d5ce4  mulpd xmm4, xmm9
000076e4393d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000076e4393d5cee  ptest xmm3, xmm3
000076e4393d5cf3  jnz 0x000076E4393D7832
000076e4393d5cf9  lea r14, [rax+0xE0]
000076e4393d5d00  movups xmm15, [r13+r14*1]
000076e4393d5d06  vmovaps xmm9, [rsp+0x70]
000076e4393d5d0c  vpermilpd xmm9, xmm9, 0x00
000076e4393d5d12  vmovaps [rsp+0x70], xmm1
000076e4393d5d18  vmovaps xmm1, [rsp+0x80]
000076e4393d5d21  vmovaps [rsp+0x80], xmm15
000076e4393d5d2a  movaps xmm3, xmm1
000076e4393d5d2d  mulpd xmm3, xmm9
000076e4393d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000076e4393d5d37  ptest xmm15, xmm15
000076e4393d5d3d  jnz 0x000076E4393D797E
000076e4393d5d43  vmovaps xmm1, [rsp+0xF0]
000076e4393d5d4c  vmovaps xmm15, [rsp+0xF0]
000076e4393d5d55  por xmm1, xmm15
000076e4393d5d5a  movaps [r15+0x300], xmm1
000076e4393d5d62  vmovaps xmm15, [rsp+0xE0]
000076e4393d5d6b  vmovaps xmm9, [rsp+0xE0]
000076e4393d5d74  por xmm15, xmm9
000076e4393d5d79  movaps [r15+0x190], xmm15
000076e4393d5d81  vmovaps xmm9, [rsp+0x50]
000076e4393d5d87  vpermilpd xmm9, xmm9, 0x00
000076e4393d5d8d  vmovaps [rsp+0x90], xmm1
000076e4393d5d96  vmovaps [rsp+0xE0], xmm15
000076e4393d5d9f  vmovaps xmm15, [rsp+0x80]
000076e4393d5da8  vmovaps [rsp+0x80], xmm14
000076e4393d5db1  movaps xmm1, xmm15
000076e4393d5db5  mulpd xmm1, xmm9
000076e4393d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000076e4393d5dbf  ptest xmm14, xmm14
000076e4393d5dc5  jnz 0x000076E4393D7ABF
000076e4393d5dcb  lea r14, [rax+0x90]
000076e4393d5dd2  movups xmm15, [r13+r14*1]
000076e4393d5dd8  vmovaps xmm14, [rsp+0xD0]
000076e4393d5de1  vmovaps xmm9, [rsp+0xD0]
000076e4393d5dea  por xmm14, xmm9
000076e4393d5def  movaps [r15+0x1C0], xmm14
000076e4393d5df7  vmovaps xmm9, [rsp+0xC0]
000076e4393d5e00  vmovaps [rsp+0xD0], xmm1
000076e4393d5e09  vmovaps xmm1, [rsp+0xC0]
000076e4393d5e12  por xmm9, xmm1
000076e4393d5e17  movaps [r15+0x200], xmm9
000076e4393d5e1f  vmovaps [rsp+0xC0], xmm2
000076e4393d5e28  vmovaps xmm1, [rsp+0xC0]
000076e4393d5e31  por xmm2, xmm1
000076e4393d5e35  movaps [r15+0x2D0], xmm2
000076e4393d5e3d  vmovaps [rsp+0xC0], xmm8
000076e4393d5e46  vmovaps xmm1, [rsp+0xC0]
000076e4393d5e4f  por xmm8, xmm1
000076e4393d5e54  movaps [r15+0x2E0], xmm8
000076e4393d5e5c  vmovaps [rsp+0xC0], xmm15
000076e4393d5e65  movaps xmm1, xmm5
000076e4393d5e68  addpd xmm1, xmm7
000076e4393d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000076e4393d5e71  ptest xmm15, xmm15
000076e4393d5e77  jnz 0x000076E4393D7C0B
000076e4393d5e7d  vmovaps xmm15, [rsp+0x50]
000076e4393d5e83  vpermilpd xmm15, xmm15, 0x00
000076e4393d5e89  vmovaps xmm5, [rsp+0xC0]
000076e4393d5e92  vmovaps [rsp+0xC0], xmm1
000076e4393d5e9b  movaps xmm7, xmm5
000076e4393d5e9e  mulpd xmm7, xmm15
000076e4393d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000076e4393d5ea8  ptest xmm1, xmm1
000076e4393d5ead  jnz 0x000076E4393D7D4B
000076e4393d5eb3  lea r14, [rax+0x80]
000076e4393d5eba  movups xmm1, [r13+r14*1]
000076e4393d5ec0  vmovaps xmm5, [rsp+0x70]
000076e4393d5ec6  vmovaps [rsp+0x70], xmm1
000076e4393d5ecc  movaps xmm15, xmm5
000076e4393d5ed0  addpd xmm15, xmm3
000076e4393d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393d5edb  ptest xmm1, xmm1
000076e4393d5ee0  jnz 0x000076E4393D7E96
000076e4393d5ee6  vmovaps xmm5, [rsp+0x80]
000076e4393d5eef  movaps xmm1, xmm5
000076e4393d5ef2  addpd xmm1, xmm4
000076e4393d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000076e4393d5efb  ptest xmm3, xmm3
000076e4393d5f00  jnz 0x000076E4393D7FD8
000076e4393d5f06  vmovaps [rsp+0x80], xmm10
000076e4393d5f0f  vmovaps xmm5, [rsp+0x80]
000076e4393d5f18  por xmm10, xmm5
000076e4393d5f1d  movaps [r15+0x2F0], xmm10
000076e4393d5f25  vmovaps xmm5, [rsp+0x50]
000076e4393d5f2b  vpermilpd xmm5, xmm5, 0x00
000076e4393d5f31  vmovaps xmm3, [rsp+0x70]
000076e4393d5f37  vmovaps [rsp+0x50], xmm1
000076e4393d5f3d  movaps xmm4, xmm3
000076e4393d5f40  mulpd xmm4, xmm5
000076e4393d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000076e4393d5f49  ptest xmm1, xmm1
000076e4393d5f4e  jnz 0x000076E4393D8118
000076e4393d5f54  lea r14, [rax+0xD0]
000076e4393d5f5b  movups xmm1, [r13+r14*1]
000076e4393d5f61  vmovaps xmm3, [rsp+0xD0]
000076e4393d5f6a  vmovaps [rsp+0x70], xmm1
000076e4393d5f70  movaps xmm5, xmm6
000076e4393d5f73  addpd xmm5, xmm3
000076e4393d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000076e4393d5f7c  ptest xmm1, xmm1
000076e4393d5f81  jnz 0x000076E4393D8262
000076e4393d5f87  vmovaps xmm1, [rsp+0x60]
000076e4393d5f8d  vpermilpd xmm1, xmm1, 0x00
000076e4393d5f93  movaps xmm6, xmm9
000076e4393d5f97  mulpd xmm6, xmm1
000076e4393d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000076e4393d5fa0  ptest xmm3, xmm3
000076e4393d5fa5  jnz 0x000076E4393D83A2
000076e4393d5fab  movaps [r15+0x260], xmm6
000076e4393d5fb3  vxorps xmm1, xmm1, xmm1
000076e4393d5fb7  vpbroadcastq xmm1, xmm1
000076e4393d5fbc  movaps [r15+0x1B0], xmm1
000076e4393d5fc4  vmovaps xmm1, [rsp+0x60]
000076e4393d5fca  vpermilpd xmm1, xmm1, 0x00
000076e4393d5fd0  vmovaps xmm3, [rsp+0x70]
000076e4393d5fd6  vmovaps [rsp+0x70], xmm15
000076e4393d5fdc  movaps xmm9, xmm3
000076e4393d5fe0  mulpd xmm9, xmm1
000076e4393d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000076e4393d5feb  ptest xmm15, xmm15
000076e4393d5ff1  jnz 0x000076E4393D84E3
000076e4393d5ff7  lea r14, [rax+0xC0]
000076e4393d5ffe  movups xmm1, [r13+r14*1]
000076e4393d6004  vmovaps xmm3, [rsp+0xC0]
000076e4393d600d  vmovaps [rsp+0x80], xmm1
000076e4393d6016  movaps xmm15, xmm3
000076e4393d601a  addpd xmm15, xmm7
000076e4393d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393d6025  ptest xmm1, xmm1
000076e4393d602a  jnz 0x000076E4393D862F
000076e4393d6030  vmovaps [rsp+0xC0], xmm13
000076e4393d6039  vmovaps xmm1, [rsp+0xC0]
000076e4393d6042  por xmm13, xmm1
000076e4393d6047  movaps [r15+0x270], xmm13
000076e4393d604f  vmovaps xmm1, [rsp+0xB0]
000076e4393d6058  vmovaps xmm7, [rsp+0xB0]
000076e4393d6061  por xmm1, xmm7
000076e4393d6065  movaps [r15+0x1A0], xmm1
000076e4393d606d  vmovaps xmm1, [rsp+0x60]
000076e4393d6073  vpermilpd xmm1, xmm1, 0x00
000076e4393d6079  vmovaps [rsp+0xB0], xmm1
000076e4393d6082  vmovaps xmm1, [rsp+0x80]
000076e4393d608b  vmovaps [rsp+0x80], xmm15
000076e4393d6094  vmovaps xmm15, [rsp+0xB0]
000076e4393d609d  vmovaps [rsp+0xB0], xmm14
000076e4393d60a6  movaps xmm3, xmm1
000076e4393d60a9  mulpd xmm3, xmm15
000076e4393d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000076e4393d60b3  ptest xmm14, xmm14
000076e4393d60b9  jnz 0x000076E4393D8771
000076e4393d60bf  lea r14, [rax+0x20]
000076e4393d60c3  movups xmm1, [r13+r14*1]
000076e4393d60c9  movaps [r15+0x110], xmm1
000076e4393d60d1  vmovaps xmm14, [rsp+0x70]
000076e4393d60d7  vmovaps [rsp+0x70], xmm1
000076e4393d60dd  movaps xmm15, xmm14
000076e4393d60e1  addpd xmm15, xmm4
000076e4393d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393d60ec  ptest xmm1, xmm1
000076e4393d60f1  jnz 0x000076E4393D88BC
000076e4393d60f7  vmovaps xmm1, [rsp+0x60]
000076e4393d60fd  vpermilpd xmm1, xmm1, 0x00
000076e4393d6103  movaps xmm14, xmm2
000076e4393d6107  mulpd xmm14, xmm1
000076e4393d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000076e4393d6112  ptest xmm4, xmm4
000076e4393d6117  jnz 0x000076E4393D89FF
000076e4393d611d  vmovaps xmm4, [rsp+0x50]
000076e4393d6123  movaps xmm1, xmm4
000076e4393d6126  addpd xmm1, xmm9
000076e4393d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000076e4393d6130  ptest xmm2, xmm2
000076e4393d6135  jnz 0x000076E4393D8B41
000076e4393d613b  vmovaps xmm9, [rsp+0x30]
000076e4393d6141  vpermilpd xmm9, xmm9, 0x00
000076e4393d6147  vmovaps xmm2, [rsp+0x70]
000076e4393d614d  vmovaps [rsp+0x50], xmm1
000076e4393d6153  movaps xmm4, xmm2
000076e4393d6156  mulpd xmm4, xmm9
000076e4393d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000076e4393d6160  ptest xmm1, xmm1
000076e4393d6165  jnz 0x000076E4393D8C82
000076e4393d616b  vmovaps xmm1, [rsp+0x30]
000076e4393d6171  vpermilpd xmm1, xmm1, 0x00
000076e4393d6177  vmovaps xmm2, [rsp+0x90]
000076e4393d6180  vmovaps [rsp+0x60], xmm15
000076e4393d6186  movaps xmm9, xmm2
000076e4393d618a  mulpd xmm9, xmm1
000076e4393d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000076e4393d6195  ptest xmm15, xmm15
000076e4393d619b  jnz 0x000076E4393D8DC3
000076e4393d61a1  vmovaps xmm15, [rsp+0x80]
000076e4393d61aa  movaps xmm1, xmm15
000076e4393d61ae  addpd xmm1, xmm6
000076e4393d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000076e4393d61b7  ptest xmm2, xmm2
000076e4393d61bc  jnz 0x000076E4393D8F05
000076e4393d61c2  movaps xmm15, xmm5
000076e4393d61c6  addpd xmm15, xmm3
000076e4393d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000076e4393d61d1  ptest xmm6, xmm6
000076e4393d61d6  jnz 0x000076E4393D9046
000076e4393d61dc  vmovaps xmm6, [rsp+0x30]
000076e4393d61e2  vpermilpd xmm6, xmm6, 0x00
000076e4393d61e8  movaps xmm5, xmm8
000076e4393d61ec  mulpd xmm5, xmm6
000076e4393d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000076e4393d61f5  ptest xmm3, xmm3
000076e4393d61fa  jnz 0x000076E4393D9188
000076e4393d6200  vmovaps xmm8, [rsp+0x30]
000076e4393d6206  vpermilpd xmm8, xmm8, 0x00
000076e4393d620c  movaps xmm6, xmm10
000076e4393d6210  mulpd xmm6, xmm8
000076e4393d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000076e4393d621a  ptest xmm3, xmm3
000076e4393d621f  jnz 0x000076E4393D92C9
000076e4393d6225  vmovaps xmm8, [rsp+0x60]
000076e4393d622b  movaps xmm10, xmm8
000076e4393d622f  addpd xmm10, xmm14
000076e4393d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000076e4393d623a  ptest xmm3, xmm3
000076e4393d623f  jnz 0x000076E4393D940B
000076e4393d6245  vmovaps xmm8, [rsp+0x50]
000076e4393d624b  movaps xmm14, xmm8
000076e4393d624f  addpd xmm14, xmm4
000076e4393d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000076e4393d625a  ptest xmm3, xmm3
000076e4393d625f  jnz 0x000076E4393D954F
000076e4393d6265  vmovaps xmm8, [rsp+0x40]
000076e4393d626b  vpermilpd xmm8, xmm8, 0x00
000076e4393d6271  movaps xmm4, xmm13
000076e4393d6275  mulpd xmm4, xmm8
000076e4393d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000076e4393d627f  ptest xmm3, xmm3
000076e4393d6284  jnz 0x000076E4393D9692
000076e4393d628a  movaps xmm13, xmm15
000076e4393d628e  addpd xmm13, xmm9
000076e4393d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000076e4393d6299  ptest xmm8, xmm8
000076e4393d629f  jnz 0x000076E4393D97D4
000076e4393d62a5  movaps xmm15, xmm1
000076e4393d62a9  addpd xmm15, xmm5
000076e4393d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000076e4393d62b4  ptest xmm9, xmm9
000076e4393d62ba  jnz 0x000076E4393D9918
000076e4393d62c0  vmovaps [rsp+0x30], xmm11
000076e4393d62c6  vmovaps xmm1, [rsp+0x30]
000076e4393d62cc  por xmm11, xmm1
000076e4393d62d1  movaps [r15+0x250], xmm11
000076e4393d62d9  vmovaps [rsp+0x30], xmm12
000076e4393d62df  vmovaps xmm1, [rsp+0x30]
000076e4393d62e5  por xmm12, xmm1
000076e4393d62ea  movaps [r15+0x2A0], xmm12
000076e4393d62f2  vmovaps xmm1, [rsp+0xA0]
000076e4393d62fb  vmovaps xmm11, [rsp+0xA0]
000076e4393d6304  por xmm1, xmm11
000076e4393d6309  movaps [r15+0x1D0], xmm1
000076e4393d6311  lea r14, [rax+0x40]
000076e4393d6315  movups xmm1, [r13+r14*1]
000076e4393d631b  movaps [r15+0x2C0], xmm1
000076e4393d6323  vmovaps xmm11, [rsp+0x40]
000076e4393d6329  vpermilpd xmm11, xmm11, 0x00
000076e4393d632f  vmovaps xmm8, [rsp+0xE0]
000076e4393d6338  movaps xmm9, xmm8
000076e4393d633c  mulpd xmm9, xmm11
000076e4393d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000076e4393d6347  ptest xmm5, xmm5
000076e4393d634c  jnz 0x000076E4393D9A64
000076e4393d6352  movaps xmm11, xmm10
000076e4393d6356  addpd xmm11, xmm6
000076e4393d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000076e4393d6361  ptest xmm8, xmm8
000076e4393d6367  jnz 0x000076E4393D9BA8
000076e4393d636d  movaps xmm10, xmm14
000076e4393d6371  addpd xmm10, xmm4
000076e4393d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000076e4393d637c  ptest xmm8, xmm8
000076e4393d6382  jnz 0x000076E4393D9CEB
000076e4393d6388  vmovaps xmm14, [rsp+0x40]
000076e4393d638e  vpermilpd xmm14, xmm14, 0x00
000076e4393d6394  movaps xmm8, xmm1
000076e4393d6398  mulpd xmm8, xmm14
000076e4393d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000076e4393d63a3  ptest xmm6, xmm6
000076e4393d63a8  jnz 0x000076E4393D9E2E
000076e4393d63ae  movaps xmm1, [r15+0x2B0]
000076e4393d63b6  vmovaps xmm14, [rsp+0x40]
000076e4393d63bc  vpermilpd xmm14, xmm14, 0x00
000076e4393d63c2  movaps xmm6, xmm1
000076e4393d63c5  mulpd xmm6, xmm14
000076e4393d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000076e4393d63cf  ptest xmm5, xmm5
000076e4393d63d4  jnz 0x000076E4393D9F71
000076e4393d63da  vmovaps xmm1, [rsp+0x10]
000076e4393d63e0  vpermilpd xmm1, xmm1, 0x00
000076e4393d63e6  movaps xmm14, xmm12
000076e4393d63ea  mulpd xmm14, xmm1
000076e4393d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000076e4393d63f5  ptest xmm5, xmm5
000076e4393d63fa  jnz 0x000076E4393DA0B2
000076e4393d6400  movaps xmm1, xmm13
000076e4393d6404  addpd xmm1, xmm9
000076e4393d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000076e4393d640e  ptest xmm12, xmm12
000076e4393d6414  jnz 0x000076E4393DA1F5
000076e4393d641a  vmovaps xmm13, [rsp+0x10]
000076e4393d6420  vpermilpd xmm13, xmm13, 0x00
000076e4393d6426  movaps xmm12, xmm7
000076e4393d642a  mulpd xmm12, xmm13
000076e4393d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000076e4393d6435  ptest xmm9, xmm9
000076e4393d643b  jnz 0x000076E4393DA337
000076e4393d6441  movaps xmm13, xmm15
000076e4393d6445  addpd xmm13, xmm8
000076e4393d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000076e4393d6450  ptest xmm9, xmm9
000076e4393d6456  jnz 0x000076E4393DA47A
000076e4393d645c  movaps xmm15, [r15+0x290]
000076e4393d6464  vmovaps xmm9, [rsp+0x10]
000076e4393d646a  vpermilpd xmm9, xmm9, 0x00
000076e4393d6470  movaps xmm8, xmm15
000076e4393d6474  mulpd xmm8, xmm9
000076e4393d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000076e4393d647f  ptest xmm7, xmm7
000076e4393d6484  jnz 0x000076E4393DA5BE
000076e4393d648a  movaps xmm15, xmm11
000076e4393d648e  addpd xmm15, xmm6
000076e4393d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000076e4393d6499  ptest xmm9, xmm9
000076e4393d649f  jnz 0x000076E4393DA702
000076e4393d64a5  movaps xmm11, [r15+0x1E0]
000076e4393d64ad  vmovaps xmm9, [rsp+0x10]
000076e4393d64b3  vpermilpd xmm9, xmm9, 0x00
000076e4393d64b9  movaps xmm7, xmm11
000076e4393d64bd  mulpd xmm7, xmm9
000076e4393d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000076e4393d64c7  ptest xmm6, xmm6
000076e4393d64cc  jnz 0x000076E4393DA845
000076e4393d64d2  movaps xmm11, xmm10
000076e4393d64d6  addpd xmm11, xmm14
000076e4393d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000076e4393d64e1  ptest xmm9, xmm9
000076e4393d64e7  jnz 0x000076E4393DA987
000076e4393d64ed  lea r14, [rax+0x70]
000076e4393d64f1  movups xmm14, [r13+r14*1]
000076e4393d64f7  movaps [r15+0x240], xmm14
000076e4393d64ff  movaps xmm10, xmm1
000076e4393d6503  addpd xmm10, xmm12
000076e4393d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000076e4393d650e  ptest xmm9, xmm9
000076e4393d6514  jnz 0x000076E4393DAAD5
000076e4393d651a  movaps [r15+0x170], xmm10
000076e4393d6522  vmovaps xmm1, [rsp+0x20]
000076e4393d6528  vpermilpd xmm1, xmm1, 0x00
000076e4393d652e  movaps xmm12, xmm14
000076e4393d6532  mulpd xmm12, xmm1
000076e4393d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000076e4393d653d  ptest xmm9, xmm9
000076e4393d6543  jnz 0x000076E4393DAC18
000076e4393d6549  vmovaps xmm1, [rsp+0x20]
000076e4393d654f  vpermilpd xmm1, xmm1, 0x00
000076e4393d6555  vmovaps xmm9, [rsp+0xB0]
000076e4393d655e  movaps xmm14, xmm9
000076e4393d6562  mulpd xmm14, xmm1
000076e4393d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000076e4393d656d  ptest xmm6, xmm6
000076e4393d6572  jnz 0x000076E4393DAD5B
000076e4393d6578  movaps [r15+0x180], xmm14
000076e4393d6580  movaps xmm1, xmm13
000076e4393d6584  addpd xmm1, xmm8
000076e4393d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000076e4393d658e  ptest xmm9, xmm9
000076e4393d6594  jnz 0x000076E4393DAE9E
000076e4393d659a  movaps [r15+0x210], xmm1
000076e4393d65a2  movups xmm13, [r13+rax*1]
000076e4393d65a8  lea r14, [rax+0x10]
000076e4393d65ac  movups xmm9, [r13+r14*1]
000076e4393d65b2  movaps [r15+0x230], xmm9
000076e4393d65ba  movaps xmm8, xmm15
000076e4393d65be  addpd xmm8, xmm7
000076e4393d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000076e4393d65c9  ptest xmm6, xmm6
000076e4393d65ce  jnz 0x000076E4393DAFF4
000076e4393d65d4  movaps [r15+0x130], xmm8
000076e4393d65dc  vmovaps xmm15, [rsp+0x20]
000076e4393d65e2  vpermilpd xmm15, xmm15, 0x00
000076e4393d65e8  movaps xmm7, xmm9
000076e4393d65ec  mulpd xmm7, xmm15
000076e4393d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000076e4393d65f6  ptest xmm6, xmm6
000076e4393d65fb  jnz 0x000076E4393DB137
000076e4393d6601  movaps [r15+0x220], xmm7
000076e4393d6609  vmovaps xmm15, [rsp+0x20]
000076e4393d660f  vpermilpd xmm15, xmm15, 0x00
000076e4393d6615  movaps xmm9, xmm13
000076e4393d6619  mulpd xmm9, xmm15
000076e4393d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000076e4393d6624  ptest xmm6, xmm6
000076e4393d6629  jnz 0x000076E4393DB279
000076e4393d662f  movaps xmm15, xmm11
000076e4393d6633  addpd xmm15, xmm12
000076e4393d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000076e4393d663e  ptest xmm13, xmm13
000076e4393d6644  jnz 0x000076E4393DB3BD
000076e4393d664a  movaps [r15+0x140], xmm15
000076e4393d6652  movaps xmm13, xmm10
000076e4393d6656  addpd xmm13, xmm14
000076e4393d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000076e4393d6661  ptest xmm12, xmm12
000076e4393d6667  jnz 0x000076E4393DB501
000076e4393d666d  movaps [r15+0x150], xmm13
000076e4393d6675  movaps xmm14, xmm1
000076e4393d6679  addpd xmm14, xmm7
000076e4393d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000076e4393d6684  ptest xmm12, xmm12
000076e4393d668a  jnz 0x000076E4393DB645
000076e4393d6690  movaps [r15+0x160], xmm14
000076e4393d6698  movaps xmm1, xmm8
000076e4393d669c  addpd xmm1, xmm9
000076e4393d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000076e4393d66a6  ptest xmm12, xmm12
000076e4393d66ac  jnz 0x000076E4393DB787
000076e4393d66b2  movaps [r15+0x120], xmm1
000076e4393d66ba  movups [r13+r11*1], xmm15
000076e4393d66c0  lea rax, [r11+0x10]
000076e4393d66c4  movups [r13+rax*1], xmm13
000076e4393d66ca  lea rax, [r11+0x20]
000076e4393d66ce  movups [r13+rax*1], xmm14
000076e4393d66d4  lea rax, [r11+0x30]
000076e4393d66d8  movups [r13+rax*1], xmm1
000076e4393d66de  mov eax, [r15+0x108]
000076e4393d66e5  sahf
000076e4393d66e6  jnz 0x000076E4393D6718
000076e4393d66e8  cmp dword ptr [r15+0x318], 0x00
000076e4393d66f0  jz 0x000076E4393DB900
000076e4393d66f6  nop [rax+rax*1], ax
000076e4393d66ff  nop [rax+rax*1], eax
000076e4393d6707  mov eax, 0x410444
000076e4393d670c  mov [r15+0x100], rax
000076e4393d6713  jmp 0x000076E4391FE110
000076e4393d6718  cmp dword ptr [r15+0x318], 0x00
000076e4393d6720  jz 0x000076E4393D57E0
000076e4393d6726  nop [rax+rax*1], ax
000076e4393d672f  nop [rax+rax*1], eax
000076e4393d6737  mov eax, 0x410278
000076e4393d673c  mov [r15+0x100], rax
000076e4393d6743  jmp 0x000076E4391FE110
000076e4393d6748  int3
000076e4393d6749  call 0x000076E43920A4B0
000076e4393d674e  jmp 0x000076E4393D5828
000076e4393d6753  call 0x000076E439209240
000076e4393d6758  jmp 0x000076E4393D5832
000076e4393d675d  call 0x000076E43920A4B0
000076e4393d6762  jmp 0x000076E4393D588F
000076e4393d6767  call 0x000076E439209240
000076e4393d676c  jmp 0x000076E4393D5899
000076e4393d6771  call 0x000076E43920A4B0
000076e4393d6776  jmp 0x000076E4393D58DD
000076e4393d677b  call 0x000076E439209240
000076e4393d6780  jmp 0x000076E4393D58E7
000076e4393d6785  call 0x000076E4392B47C0
000076e4393d678a  jmp 0x000076E4393D5926
000076e4393d678f  call 0x000076E43920B720
000076e4393d6794  jmp 0x000076E4393D593A
000076e4393d6799  call 0x000076E4392BFC30
000076e4393d679e  jmp 0x000076E4393D5958
000076e4393d67a3  call 0x000076E4392BE9C0
000076e4393d67a8  jmp 0x000076E4393D5962
000076e4393d67ad  call 0x000076E4392BD750
000076e4393d67b2  jmp 0x000076E4393D596C
000076e4393d67b7  sub rsp, 0x08
000076e4393d67bb  push rax
000076e4393d67bc  push rcx
000076e4393d67bd  push rdx
000076e4393d67be  push rdi
000076e4393d67bf  push rsi
000076e4393d67c0  push r8
000076e4393d67c2  push r9
000076e4393d67c4  push r10
000076e4393d67c6  push r11
000076e4393d67c8  sub rsp, 0xF0
000076e4393d67cf  vmovaps [rsp], xmm0
000076e4393d67d4  vmovaps [rsp+0x10], xmm1
000076e4393d67da  vmovaps [rsp+0x20], xmm2
000076e4393d67e0  vmovaps [rsp+0x30], xmm3
000076e4393d67e6  vmovaps [rsp+0x40], xmm4
000076e4393d67ec  vmovaps [rsp+0x50], xmm5
000076e4393d67f2  vmovaps [rsp+0x60], xmm6
000076e4393d67f8  vmovaps [rsp+0x70], xmm7
000076e4393d67fe  vmovaps [rsp+0x80], xmm9
000076e4393d6807  vmovaps [rsp+0x90], xmm10
000076e4393d6810  vmovaps [rsp+0xA0], xmm11
000076e4393d6819  vmovaps [rsp+0xB0], xmm12
000076e4393d6822  vmovaps [rsp+0xC0], xmm13
000076e4393d682b  vmovaps [rsp+0xD0], xmm14
000076e4393d6834  vmovaps [rsp+0xE0], xmm15
000076e4393d683d  sub rsp, 0x30
000076e4393d6841  movaps [rsp], xmm8
000076e4393d6846  movaps [rsp+0x10], xmm12
000076e4393d684c  movaps [rsp+0x20], xmm15
000076e4393d6852  lea rdi, [rsp]
000076e4393d6856  mov esi, 0x00
000076e4393d685b  mov rax, 0x63DBDEB43530
000076e4393d6865  call rax
000076e4393d6867  movaps xmm8, [rsp]
000076e4393d686c  add rsp, 0x30
000076e4393d6870  vmovaps xmm0, [rsp]
000076e4393d6875  vmovaps xmm1, [rsp+0x10]
000076e4393d687b  vmovaps xmm2, [rsp+0x20]
000076e4393d6881  vmovaps xmm3, [rsp+0x30]
000076e4393d6887  vmovaps xmm4, [rsp+0x40]
000076e4393d688d  vmovaps xmm5, [rsp+0x50]
000076e4393d6893  vmovaps xmm6, [rsp+0x60]
000076e4393d6899  vmovaps xmm7, [rsp+0x70]
000076e4393d689f  vmovaps xmm9, [rsp+0x80]
000076e4393d68a8  vmovaps xmm10, [rsp+0x90]
000076e4393d68b1  vmovaps xmm11, [rsp+0xA0]
000076e4393d68ba  vmovaps xmm12, [rsp+0xB0]
000076e4393d68c3  vmovaps xmm13, [rsp+0xC0]
000076e4393d68cc  vmovaps xmm14, [rsp+0xD0]
000076e4393d68d5  vmovaps xmm15, [rsp+0xE0]
000076e4393d68de  add rsp, 0xF0
000076e4393d68e5  pop r11
000076e4393d68e7  pop r10
000076e4393d68e9  pop r9
000076e4393d68eb  pop r8
000076e4393d68ed  pop rsi
000076e4393d68ee  pop rdi
000076e4393d68ef  pop rdx
000076e4393d68f0  pop rcx
000076e4393d68f1  pop rax
000076e4393d68f2  add rsp, 0x08
000076e4393d68f6  jmp 0x000076E4393D599A
000076e4393d68fb  sub rsp, 0x08
000076e4393d68ff  push rax
000076e4393d6900  push rcx
000076e4393d6901  push rdx
000076e4393d6902  push rdi
000076e4393d6903  push rsi
000076e4393d6904  push r8
000076e4393d6906  push r9
000076e4393d6908  push r10
000076e4393d690a  push r11
000076e4393d690c  sub rsp, 0xF0
000076e4393d6913  vmovaps [rsp], xmm0
000076e4393d6918  vmovaps [rsp+0x10], xmm1
000076e4393d691e  vmovaps [rsp+0x20], xmm2
000076e4393d6924  vmovaps [rsp+0x30], xmm3
000076e4393d692a  vmovaps [rsp+0x40], xmm4
000076e4393d6930  vmovaps [rsp+0x50], xmm5
000076e4393d6936  vmovaps [rsp+0x60], xmm6
000076e4393d693c  vmovaps [rsp+0x70], xmm8
000076e4393d6942  vmovaps [rsp+0x80], xmm9
000076e4393d694b  vmovaps [rsp+0x90], xmm10
000076e4393d6954  vmovaps [rsp+0xA0], xmm11
000076e4393d695d  vmovaps [rsp+0xB0], xmm12
000076e4393d6966  vmovaps [rsp+0xC0], xmm13
000076e4393d696f  vmovaps [rsp+0xD0], xmm14
000076e4393d6978  vmovaps [rsp+0xE0], xmm15
000076e4393d6981  sub rsp, 0x30
000076e4393d6985  movaps [rsp], xmm7
000076e4393d6989  movaps [rsp+0x10], xmm9
000076e4393d698f  movaps [rsp+0x20], xmm15
000076e4393d6995  lea rdi, [rsp]
000076e4393d6999  mov esi, 0x00
000076e4393d699e  mov rax, 0x63DBDEB43530
000076e4393d69a8  call rax
000076e4393d69aa  movaps xmm7, [rsp]
000076e4393d69ae  add rsp, 0x30
000076e4393d69b2  vmovaps xmm0, [rsp]
000076e4393d69b7  vmovaps xmm1, [rsp+0x10]
000076e4393d69bd  vmovaps xmm2, [rsp+0x20]
000076e4393d69c3  vmovaps xmm3, [rsp+0x30]
000076e4393d69c9  vmovaps xmm4, [rsp+0x40]
000076e4393d69cf  vmovaps xmm5, [rsp+0x50]
000076e4393d69d5  vmovaps xmm6, [rsp+0x60]
000076e4393d69db  vmovaps xmm8, [rsp+0x70]
000076e4393d69e1  vmovaps xmm9, [rsp+0x80]
000076e4393d69ea  vmovaps xmm10, [rsp+0x90]
000076e4393d69f3  vmovaps xmm11, [rsp+0xA0]
000076e4393d69fc  vmovaps xmm12, [rsp+0xB0]
000076e4393d6a05  vmovaps xmm13, [rsp+0xC0]
000076e4393d6a0e  vmovaps xmm14, [rsp+0xD0]
000076e4393d6a17  vmovaps xmm15, [rsp+0xE0]
000076e4393d6a20  add rsp, 0xF0
000076e4393d6a27  pop r11
000076e4393d6a29  pop r10
000076e4393d6a2b  pop r9
000076e4393d6a2d  pop r8
000076e4393d6a2f  pop rsi
000076e4393d6a30  pop rdi
000076e4393d6a31  pop rdx
000076e4393d6a32  pop rcx
000076e4393d6a33  pop rax
000076e4393d6a34  add rsp, 0x08
000076e4393d6a38  jmp 0x000076E4393D59C8
000076e4393d6a3d  sub rsp, 0x08
000076e4393d6a41  push rax
000076e4393d6a42  push rcx
000076e4393d6a43  push rdx
000076e4393d6a44  push rdi
000076e4393d6a45  push rsi
000076e4393d6a46  push r8
000076e4393d6a48  push r9
000076e4393d6a4a  push r10
000076e4393d6a4c  push r11
000076e4393d6a4e  sub rsp, 0xF0
000076e4393d6a55  vmovaps [rsp], xmm0
000076e4393d6a5a  vmovaps [rsp+0x10], xmm1
000076e4393d6a60  vmovaps [rsp+0x20], xmm2
000076e4393d6a66  vmovaps [rsp+0x30], xmm3
000076e4393d6a6c  vmovaps [rsp+0x40], xmm4
000076e4393d6a72  vmovaps [rsp+0x50], xmm5
000076e4393d6a78  vmovaps [rsp+0x60], xmm6
000076e4393d6a7e  vmovaps [rsp+0x70], xmm7
000076e4393d6a84  vmovaps [rsp+0x80], xmm8
000076e4393d6a8d  vmovaps [rsp+0x90], xmm10
000076e4393d6a96  vmovaps [rsp+0xA0], xmm11
000076e4393d6a9f  vmovaps [rsp+0xB0], xmm12
000076e4393d6aa8  vmovaps [rsp+0xC0], xmm13
000076e4393d6ab1  vmovaps [rsp+0xD0], xmm14
000076e4393d6aba  vmovaps [rsp+0xE0], xmm15
000076e4393d6ac3  sub rsp, 0x30
000076e4393d6ac7  movaps [rsp], xmm9
000076e4393d6acc  movaps [rsp+0x10], xmm12
000076e4393d6ad2  movaps [rsp+0x20], xmm10
000076e4393d6ad8  lea rdi, [rsp]
000076e4393d6adc  mov esi, 0x00
000076e4393d6ae1  mov rax, 0x63DBDEB43530
000076e4393d6aeb  call rax
000076e4393d6aed  movaps xmm9, [rsp]
000076e4393d6af2  add rsp, 0x30
000076e4393d6af6  vmovaps xmm0, [rsp]
000076e4393d6afb  vmovaps xmm1, [rsp+0x10]
000076e4393d6b01  vmovaps xmm2, [rsp+0x20]
000076e4393d6b07  vmovaps xmm3, [rsp+0x30]
000076e4393d6b0d  vmovaps xmm4, [rsp+0x40]
000076e4393d6b13  vmovaps xmm5, [rsp+0x50]
000076e4393d6b19  vmovaps xmm6, [rsp+0x60]
000076e4393d6b1f  vmovaps xmm7, [rsp+0x70]
000076e4393d6b25  vmovaps xmm8, [rsp+0x80]
000076e4393d6b2e  vmovaps xmm10, [rsp+0x90]
000076e4393d6b37  vmovaps xmm11, [rsp+0xA0]
000076e4393d6b40  vmovaps xmm12, [rsp+0xB0]
000076e4393d6b49  vmovaps xmm13, [rsp+0xC0]
000076e4393d6b52  vmovaps xmm14, [rsp+0xD0]
000076e4393d6b5b  vmovaps xmm15, [rsp+0xE0]
000076e4393d6b64  add rsp, 0xF0
000076e4393d6b6b  pop r11
000076e4393d6b6d  pop r10
000076e4393d6b6f  pop r9
000076e4393d6b71  pop r8
000076e4393d6b73  pop rsi
000076e4393d6b74  pop rdi
000076e4393d6b75  pop rdx
000076e4393d6b76  pop rcx
000076e4393d6b77  pop rax
000076e4393d6b78  add rsp, 0x08
000076e4393d6b7c  jmp 0x000076E4393D59EC
000076e4393d6b81  sub rsp, 0x08
000076e4393d6b85  push rax
000076e4393d6b86  push rcx
000076e4393d6b87  push rdx
000076e4393d6b88  push rdi
000076e4393d6b89  push rsi
000076e4393d6b8a  push r8
000076e4393d6b8c  push r9
000076e4393d6b8e  push r10
000076e4393d6b90  push r11
000076e4393d6b92  sub rsp, 0xF0
000076e4393d6b99  vmovaps [rsp], xmm0
000076e4393d6b9e  vmovaps [rsp+0x10], xmm1
000076e4393d6ba4  vmovaps [rsp+0x20], xmm2
000076e4393d6baa  vmovaps [rsp+0x30], xmm3
000076e4393d6bb0  vmovaps [rsp+0x40], xmm4
000076e4393d6bb6  vmovaps [rsp+0x50], xmm5
000076e4393d6bbc  vmovaps [rsp+0x60], xmm6
000076e4393d6bc2  vmovaps [rsp+0x70], xmm7
000076e4393d6bc8  vmovaps [rsp+0x80], xmm8
000076e4393d6bd1  vmovaps [rsp+0x90], xmm9
000076e4393d6bda  vmovaps [rsp+0xA0], xmm11
000076e4393d6be3  vmovaps [rsp+0xB0], xmm12
000076e4393d6bec  vmovaps [rsp+0xC0], xmm13
000076e4393d6bf5  vmovaps [rsp+0xD0], xmm14
000076e4393d6bfe  vmovaps [rsp+0xE0], xmm15
000076e4393d6c07  sub rsp, 0x30
000076e4393d6c0b  movaps [rsp], xmm10
000076e4393d6c10  movaps [rsp+0x10], xmm12
000076e4393d6c16  movaps [rsp+0x20], xmm11
000076e4393d6c1c  lea rdi, [rsp]
000076e4393d6c20  mov esi, 0x00
000076e4393d6c25  mov rax, 0x63DBDEB43530
000076e4393d6c2f  call rax
000076e4393d6c31  movaps xmm10, [rsp]
000076e4393d6c36  add rsp, 0x30
000076e4393d6c3a  vmovaps xmm0, [rsp]
000076e4393d6c3f  vmovaps xmm1, [rsp+0x10]
000076e4393d6c45  vmovaps xmm2, [rsp+0x20]
000076e4393d6c4b  vmovaps xmm3, [rsp+0x30]
000076e4393d6c51  vmovaps xmm4, [rsp+0x40]
000076e4393d6c57  vmovaps xmm5, [rsp+0x50]
000076e4393d6c5d  vmovaps xmm6, [rsp+0x60]
000076e4393d6c63  vmovaps xmm7, [rsp+0x70]
000076e4393d6c69  vmovaps xmm8, [rsp+0x80]
000076e4393d6c72  vmovaps xmm9, [rsp+0x90]
000076e4393d6c7b  vmovaps xmm11, [rsp+0xA0]
000076e4393d6c84  vmovaps xmm12, [rsp+0xB0]
000076e4393d6c8d  vmovaps xmm13, [rsp+0xC0]
000076e4393d6c96  vmovaps xmm14, [rsp+0xD0]
000076e4393d6c9f  vmovaps xmm15, [rsp+0xE0]
000076e4393d6ca8  add rsp, 0xF0
000076e4393d6caf  pop r11
000076e4393d6cb1  pop r10
000076e4393d6cb3  pop r9
000076e4393d6cb5  pop r8
000076e4393d6cb7  pop rsi
000076e4393d6cb8  pop rdi
000076e4393d6cb9  pop rdx
000076e4393d6cba  pop rcx
000076e4393d6cbb  pop rax
000076e4393d6cbc  add rsp, 0x08
000076e4393d6cc0  jmp 0x000076E4393D5A06
000076e4393d6cc5  sub rsp, 0x08
000076e4393d6cc9  push rax
000076e4393d6cca  push rcx
000076e4393d6ccb  push rdx
000076e4393d6ccc  push rdi
000076e4393d6ccd  push rsi
000076e4393d6cce  push r8
000076e4393d6cd0  push r9
000076e4393d6cd2  push r10
000076e4393d6cd4  push r11
000076e4393d6cd6  sub rsp, 0xF0
000076e4393d6cdd  vmovaps [rsp], xmm0
000076e4393d6ce2  vmovaps [rsp+0x10], xmm1
000076e4393d6ce8  vmovaps [rsp+0x20], xmm2
000076e4393d6cee  vmovaps [rsp+0x30], xmm3
000076e4393d6cf4  vmovaps [rsp+0x40], xmm4
000076e4393d6cfa  vmovaps [rsp+0x50], xmm5
000076e4393d6d00  vmovaps [rsp+0x60], xmm7
000076e4393d6d06  vmovaps [rsp+0x70], xmm8
000076e4393d6d0c  vmovaps [rsp+0x80], xmm9
000076e4393d6d15  vmovaps [rsp+0x90], xmm10
000076e4393d6d1e  vmovaps [rsp+0xA0], xmm11
000076e4393d6d27  vmovaps [rsp+0xB0], xmm12
000076e4393d6d30  vmovaps [rsp+0xC0], xmm13
000076e4393d6d39  vmovaps [rsp+0xD0], xmm14
000076e4393d6d42  vmovaps [rsp+0xE0], xmm15
000076e4393d6d4b  sub rsp, 0x30
000076e4393d6d4f  movaps [rsp], xmm6
000076e4393d6d53  movaps [rsp+0x10], xmm12
000076e4393d6d59  movaps [rsp+0x20], xmm11
000076e4393d6d5f  lea rdi, [rsp]
000076e4393d6d63  mov esi, 0x00
000076e4393d6d68  mov rax, 0x63DBDEB43530
000076e4393d6d72  call rax
000076e4393d6d74  movaps xmm6, [rsp]
000076e4393d6d78  add rsp, 0x30
000076e4393d6d7c  vmovaps xmm0, [rsp]
000076e4393d6d81  vmovaps xmm1, [rsp+0x10]
000076e4393d6d87  vmovaps xmm2, [rsp+0x20]
000076e4393d6d8d  vmovaps xmm3, [rsp+0x30]
000076e4393d6d93  vmovaps xmm4, [rsp+0x40]
000076e4393d6d99  vmovaps xmm5, [rsp+0x50]
000076e4393d6d9f  vmovaps xmm7, [rsp+0x60]
000076e4393d6da5  vmovaps xmm8, [rsp+0x70]
000076e4393d6dab  vmovaps xmm9, [rsp+0x80]
000076e4393d6db4  vmovaps xmm10, [rsp+0x90]
000076e4393d6dbd  vmovaps xmm11, [rsp+0xA0]
000076e4393d6dc6  vmovaps xmm12, [rsp+0xB0]
000076e4393d6dcf  vmovaps xmm13, [rsp+0xC0]
000076e4393d6dd8  vmovaps xmm14, [rsp+0xD0]
000076e4393d6de1  vmovaps xmm15, [rsp+0xE0]
000076e4393d6dea  add rsp, 0xF0
000076e4393d6df1  pop r11
000076e4393d6df3  pop r10
000076e4393d6df5  pop r9
000076e4393d6df7  pop r8
000076e4393d6df9  pop rsi
000076e4393d6dfa  pop rdi
000076e4393d6dfb  pop rdx
000076e4393d6dfc  pop rcx
000076e4393d6dfd  pop rax
000076e4393d6dfe  add rsp, 0x08
000076e4393d6e02  jmp 0x000076E4393D5A27
000076e4393d6e07  sub rsp, 0x08
000076e4393d6e0b  push rax
000076e4393d6e0c  push rcx
000076e4393d6e0d  push rdx
000076e4393d6e0e  push rdi
000076e4393d6e0f  push rsi
000076e4393d6e10  push r8
000076e4393d6e12  push r9
000076e4393d6e14  push r10
000076e4393d6e16  push r11
000076e4393d6e18  sub rsp, 0xF0
000076e4393d6e1f  vmovaps [rsp], xmm0
000076e4393d6e24  vmovaps [rsp+0x10], xmm1
000076e4393d6e2a  vmovaps [rsp+0x20], xmm2
000076e4393d6e30  vmovaps [rsp+0x30], xmm4
000076e4393d6e36  vmovaps [rsp+0x40], xmm5
000076e4393d6e3c  vmovaps [rsp+0x50], xmm6
000076e4393d6e42  vmovaps [rsp+0x60], xmm7
000076e4393d6e48  vmovaps [rsp+0x70], xmm8
000076e4393d6e4e  vmovaps [rsp+0x80], xmm9
000076e4393d6e57  vmovaps [rsp+0x90], xmm10
000076e4393d6e60  vmovaps [rsp+0xA0], xmm11
000076e4393d6e69  vmovaps [rsp+0xB0], xmm12
000076e4393d6e72  vmovaps [rsp+0xC0], xmm13
000076e4393d6e7b  vmovaps [rsp+0xD0], xmm14
000076e4393d6e84  vmovaps [rsp+0xE0], xmm15
000076e4393d6e8d  sub rsp, 0x30
000076e4393d6e91  movaps [rsp], xmm3
000076e4393d6e95  movaps [rsp+0x10], xmm5
000076e4393d6e9a  movaps [rsp+0x20], xmm4
000076e4393d6e9f  lea rdi, [rsp]
000076e4393d6ea3  mov esi, 0x00
000076e4393d6ea8  mov rax, 0x63DBDEB43530
000076e4393d6eb2  call rax
000076e4393d6eb4  movaps xmm3, [rsp]
000076e4393d6eb8  add rsp, 0x30
000076e4393d6ebc  vmovaps xmm0, [rsp]
000076e4393d6ec1  vmovaps xmm1, [rsp+0x10]
000076e4393d6ec7  vmovaps xmm2, [rsp+0x20]
000076e4393d6ecd  vmovaps xmm4, [rsp+0x30]
000076e4393d6ed3  vmovaps xmm5, [rsp+0x40]
000076e4393d6ed9  vmovaps xmm6, [rsp+0x50]
000076e4393d6edf  vmovaps xmm7, [rsp+0x60]
000076e4393d6ee5  vmovaps xmm8, [rsp+0x70]
000076e4393d6eeb  vmovaps xmm9, [rsp+0x80]
000076e4393d6ef4  vmovaps xmm10, [rsp+0x90]
000076e4393d6efd  vmovaps xmm11, [rsp+0xA0]
000076e4393d6f06  vmovaps xmm12, [rsp+0xB0]
000076e4393d6f0f  vmovaps xmm13, [rsp+0xC0]
000076e4393d6f18  vmovaps xmm14, [rsp+0xD0]
000076e4393d6f21  vmovaps xmm15, [rsp+0xE0]
000076e4393d6f2a  add rsp, 0xF0
000076e4393d6f31  pop r11
000076e4393d6f33  pop r10
000076e4393d6f35  pop r9
000076e4393d6f37  pop r8
000076e4393d6f39  pop rsi
000076e4393d6f3a  pop rdi
000076e4393d6f3b  pop rdx
000076e4393d6f3c  pop rcx
000076e4393d6f3d  pop rax
000076e4393d6f3e  add rsp, 0x08
000076e4393d6f42  jmp 0x000076E4393D5A88
000076e4393d6f47  sub rsp, 0x08
000076e4393d6f4b  push rax
000076e4393d6f4c  push rcx
000076e4393d6f4d  push rdx
000076e4393d6f4e  push rdi
000076e4393d6f4f  push rsi
000076e4393d6f50  push r8
000076e4393d6f52  push r9
000076e4393d6f54  push r10
000076e4393d6f56  push r11
000076e4393d6f58  sub rsp, 0xF0
000076e4393d6f5f  vmovaps [rsp], xmm0
000076e4393d6f64  vmovaps [rsp+0x10], xmm1
000076e4393d6f6a  vmovaps [rsp+0x20], xmm2
000076e4393d6f70  vmovaps [rsp+0x30], xmm3
000076e4393d6f76  vmovaps [rsp+0x40], xmm4
000076e4393d6f7c  vmovaps [rsp+0x50], xmm6
000076e4393d6f82  vmovaps [rsp+0x60], xmm7
000076e4393d6f88  vmovaps [rsp+0x70], xmm8
000076e4393d6f8e  vmovaps [rsp+0x80], xmm9
000076e4393d6f97  vmovaps [rsp+0x90], xmm10
000076e4393d6fa0  vmovaps [rsp+0xA0], xmm11
000076e4393d6fa9  vmovaps [rsp+0xB0], xmm12
000076e4393d6fb2  vmovaps [rsp+0xC0], xmm13
000076e4393d6fbb  vmovaps [rsp+0xD0], xmm14
000076e4393d6fc4  vmovaps [rsp+0xE0], xmm15
000076e4393d6fcd  sub rsp, 0x30
000076e4393d6fd1  movaps [rsp], xmm5
000076e4393d6fd5  movaps [rsp+0x10], xmm8
000076e4393d6fdb  movaps [rsp+0x20], xmm15
000076e4393d6fe1  lea rdi, [rsp]
000076e4393d6fe5  mov esi, 0x00
000076e4393d6fea  mov rax, 0x63DBDEB43530
000076e4393d6ff4  call rax
000076e4393d6ff6  movaps xmm5, [rsp]
000076e4393d6ffa  add rsp, 0x30
000076e4393d6ffe  vmovaps xmm0, [rsp]
000076e4393d7003  vmovaps xmm1, [rsp+0x10]
000076e4393d7009  vmovaps xmm2, [rsp+0x20]
000076e4393d700f  vmovaps xmm3, [rsp+0x30]
000076e4393d7015  vmovaps xmm4, [rsp+0x40]
000076e4393d701b  vmovaps xmm6, [rsp+0x50]
000076e4393d7021  vmovaps xmm7, [rsp+0x60]
000076e4393d7027  vmovaps xmm8, [rsp+0x70]
000076e4393d702d  vmovaps xmm9, [rsp+0x80]
000076e4393d7036  vmovaps xmm10, [rsp+0x90]
000076e4393d703f  vmovaps xmm11, [rsp+0xA0]
000076e4393d7048  vmovaps xmm12, [rsp+0xB0]
000076e4393d7051  vmovaps xmm13, [rsp+0xC0]
000076e4393d705a  vmovaps xmm14, [rsp+0xD0]
000076e4393d7063  vmovaps xmm15, [rsp+0xE0]
000076e4393d706c  add rsp, 0xF0
000076e4393d7073  pop r11
000076e4393d7075  pop r10
000076e4393d7077  pop r9
000076e4393d7079  pop r8
000076e4393d707b  pop rsi
000076e4393d707c  pop rdi
000076e4393d707d  pop rdx
000076e4393d707e  pop rcx
000076e4393d707f  pop rax
000076e4393d7080  add rsp, 0x08
000076e4393d7084  jmp 0x000076E4393D5AC0
000076e4393d7089  sub rsp, 0x08
000076e4393d708d  push rax
000076e4393d708e  push rcx
000076e4393d708f  push rdx
000076e4393d7090  push rdi
000076e4393d7091  push rsi
000076e4393d7092  push r8
000076e4393d7094  push r9
000076e4393d7096  push r10
000076e4393d7098  push r11
000076e4393d709a  sub rsp, 0xF0
000076e4393d70a1  vmovaps [rsp], xmm0
000076e4393d70a6  vmovaps [rsp+0x10], xmm1
000076e4393d70ac  vmovaps [rsp+0x20], xmm2
000076e4393d70b2  vmovaps [rsp+0x30], xmm3
000076e4393d70b8  vmovaps [rsp+0x40], xmm5
000076e4393d70be  vmovaps [rsp+0x50], xmm6
000076e4393d70c4  vmovaps [rsp+0x60], xmm7
000076e4393d70ca  vmovaps [rsp+0x70], xmm8
000076e4393d70d0  vmovaps [rsp+0x80], xmm9
000076e4393d70d9  vmovaps [rsp+0x90], xmm10
000076e4393d70e2  vmovaps [rsp+0xA0], xmm11
000076e4393d70eb  vmovaps [rsp+0xB0], xmm12
000076e4393d70f4  vmovaps [rsp+0xC0], xmm13
000076e4393d70fd  vmovaps [rsp+0xD0], xmm14
000076e4393d7106  vmovaps [rsp+0xE0], xmm15
000076e4393d710f  sub rsp, 0x30
000076e4393d7113  movaps [rsp], xmm4
000076e4393d7117  movaps [rsp+0x10], xmm9
000076e4393d711d  movaps [rsp+0x20], xmm8
000076e4393d7123  lea rdi, [rsp]
000076e4393d7127  mov esi, 0x00
000076e4393d712c  mov rax, 0x63DBDEB43530
000076e4393d7136  call rax
000076e4393d7138  movaps xmm4, [rsp]
000076e4393d713c  add rsp, 0x30
000076e4393d7140  vmovaps xmm0, [rsp]
000076e4393d7145  vmovaps xmm1, [rsp+0x10]
000076e4393d714b  vmovaps xmm2, [rsp+0x20]
000076e4393d7151  vmovaps xmm3, [rsp+0x30]
000076e4393d7157  vmovaps xmm5, [rsp+0x40]
000076e4393d715d  vmovaps xmm6, [rsp+0x50]
000076e4393d7163  vmovaps xmm7, [rsp+0x60]
000076e4393d7169  vmovaps xmm8, [rsp+0x70]
000076e4393d716f  vmovaps xmm9, [rsp+0x80]
000076e4393d7178  vmovaps xmm10, [rsp+0x90]
000076e4393d7181  vmovaps xmm11, [rsp+0xA0]
000076e4393d718a  vmovaps xmm12, [rsp+0xB0]
000076e4393d7193  vmovaps xmm13, [rsp+0xC0]
000076e4393d719c  vmovaps xmm14, [rsp+0xD0]
000076e4393d71a5  vmovaps xmm15, [rsp+0xE0]
000076e4393d71ae  add rsp, 0xF0
000076e4393d71b5  pop r11
000076e4393d71b7  pop r10
000076e4393d71b9  pop r9
000076e4393d71bb  pop r8
000076e4393d71bd  pop rsi
000076e4393d71be  pop rdi
000076e4393d71bf  pop rdx
000076e4393d71c0  pop rcx
000076e4393d71c1  pop rax
000076e4393d71c2  add rsp, 0x08
000076e4393d71c6  jmp 0x000076E4393D5AE1
000076e4393d71cb  sub rsp, 0x08
000076e4393d71cf  push rax
000076e4393d71d0  push rcx
000076e4393d71d1  push rdx
000076e4393d71d2  push rdi
000076e4393d71d3  push rsi
000076e4393d71d4  push r8
000076e4393d71d6  push r9
000076e4393d71d8  push r10
000076e4393d71da  push r11
000076e4393d71dc  sub rsp, 0xF0
000076e4393d71e3  vmovaps [rsp], xmm0
000076e4393d71e8  vmovaps [rsp+0x10], xmm1
000076e4393d71ee  vmovaps [rsp+0x20], xmm2
000076e4393d71f4  vmovaps [rsp+0x30], xmm3
000076e4393d71fa  vmovaps [rsp+0x40], xmm4
000076e4393d7200  vmovaps [rsp+0x50], xmm5
000076e4393d7206  vmovaps [rsp+0x60], xmm6
000076e4393d720c  vmovaps [rsp+0x70], xmm7
000076e4393d7212  vmovaps [rsp+0x80], xmm8
000076e4393d721b  vmovaps [rsp+0x90], xmm10
000076e4393d7224  vmovaps [rsp+0xA0], xmm11
000076e4393d722d  vmovaps [rsp+0xB0], xmm12
000076e4393d7236  vmovaps [rsp+0xC0], xmm13
000076e4393d723f  vmovaps [rsp+0xD0], xmm14
000076e4393d7248  vmovaps [rsp+0xE0], xmm15
000076e4393d7251  sub rsp, 0x30
000076e4393d7255  movaps [rsp], xmm9
000076e4393d725a  movaps [rsp+0x10], xmm10
000076e4393d7260  movaps [rsp+0x20], xmm8
000076e4393d7266  lea rdi, [rsp]
000076e4393d726a  mov esi, 0x00
000076e4393d726f  mov rax, 0x63DBDEB43530
000076e4393d7279  call rax
000076e4393d727b  movaps xmm9, [rsp]
000076e4393d7280  add rsp, 0x30
000076e4393d7284  vmovaps xmm0, [rsp]
000076e4393d7289  vmovaps xmm1, [rsp+0x10]
000076e4393d728f  vmovaps xmm2, [rsp+0x20]
000076e4393d7295  vmovaps xmm3, [rsp+0x30]
000076e4393d729b  vmovaps xmm4, [rsp+0x40]
000076e4393d72a1  vmovaps xmm5, [rsp+0x50]
000076e4393d72a7  vmovaps xmm6, [rsp+0x60]
000076e4393d72ad  vmovaps xmm7, [rsp+0x70]
000076e4393d72b3  vmovaps xmm8, [rsp+0x80]
000076e4393d72bc  vmovaps xmm10, [rsp+0x90]
000076e4393d72c5  vmovaps xmm11, [rsp+0xA0]
000076e4393d72ce  vmovaps xmm12, [rsp+0xB0]
000076e4393d72d7  vmovaps xmm13, [rsp+0xC0]
000076e4393d72e0  vmovaps xmm14, [rsp+0xD0]
000076e4393d72e9  vmovaps xmm15, [rsp+0xE0]
000076e4393d72f2  add rsp, 0xF0
000076e4393d72f9  pop r11
000076e4393d72fb  pop r10
000076e4393d72fd  pop r9
000076e4393d72ff  pop r8
000076e4393d7301  pop rsi
000076e4393d7302  pop rdi
000076e4393d7303  pop rdx
000076e4393d7304  pop rcx
000076e4393d7305  pop rax
000076e4393d7306  add rsp, 0x08
000076e4393d730a  jmp 0x000076E4393D5AFB
000076e4393d730f  call 0x000076E4392D64F0
000076e4393d7314  jmp 0x000076E4393D5C15
000076e4393d7319  call 0x000076E4392D64F0
000076e4393d731e  jmp 0x000076E4393D5C2B
000076e4393d7323  sub rsp, 0x08
000076e4393d7327  push rax
000076e4393d7328  push rcx
000076e4393d7329  push rdx
000076e4393d732a  push rdi
000076e4393d732b  push rsi
000076e4393d732c  push r8
000076e4393d732e  push r9
000076e4393d7330  push r10
000076e4393d7332  push r11
000076e4393d7334  sub rsp, 0xF0
000076e4393d733b  vmovaps [rsp], xmm0
000076e4393d7340  vmovaps [rsp+0x10], xmm2
000076e4393d7346  vmovaps [rsp+0x20], xmm3
000076e4393d734c  vmovaps [rsp+0x30], xmm4
000076e4393d7352  vmovaps [rsp+0x40], xmm5
000076e4393d7358  vmovaps [rsp+0x50], xmm6
000076e4393d735e  vmovaps [rsp+0x60], xmm7
000076e4393d7364  vmovaps [rsp+0x70], xmm8
000076e4393d736a  vmovaps [rsp+0x80], xmm9
000076e4393d7373  vmovaps [rsp+0x90], xmm10
000076e4393d737c  vmovaps [rsp+0xA0], xmm11
000076e4393d7385  vmovaps [rsp+0xB0], xmm12
000076e4393d738e  vmovaps [rsp+0xC0], xmm13
000076e4393d7397  vmovaps [rsp+0xD0], xmm14
000076e4393d73a0  vmovaps [rsp+0xE0], xmm15
000076e4393d73a9  sub rsp, 0x30
000076e4393d73ad  movaps [rsp], xmm1
000076e4393d73b1  movaps [rsp+0x10], xmm6
000076e4393d73b6  movaps [rsp+0x20], xmm15
000076e4393d73bc  lea rdi, [rsp]
000076e4393d73c0  mov esi, 0x00
000076e4393d73c5  mov rax, 0x63DBDEB43530
000076e4393d73cf  call rax
000076e4393d73d1  movaps xmm1, [rsp]
000076e4393d73d5  add rsp, 0x30
000076e4393d73d9  vmovaps xmm0, [rsp]
000076e4393d73de  vmovaps xmm2, [rsp+0x10]
000076e4393d73e4  vmovaps xmm3, [rsp+0x20]
000076e4393d73ea  vmovaps xmm4, [rsp+0x30]
000076e4393d73f0  vmovaps xmm5, [rsp+0x40]
000076e4393d73f6  vmovaps xmm6, [rsp+0x50]
000076e4393d73fc  vmovaps xmm7, [rsp+0x60]
000076e4393d7402  vmovaps xmm8, [rsp+0x70]
000076e4393d7408  vmovaps xmm9, [rsp+0x80]
000076e4393d7411  vmovaps xmm10, [rsp+0x90]
000076e4393d741a  vmovaps xmm11, [rsp+0xA0]
000076e4393d7423  vmovaps xmm12, [rsp+0xB0]
000076e4393d742c  vmovaps xmm13, [rsp+0xC0]
000076e4393d7435  vmovaps xmm14, [rsp+0xD0]
000076e4393d743e  vmovaps xmm15, [rsp+0xE0]
000076e4393d7447  add rsp, 0xF0
000076e4393d744e  pop r11
000076e4393d7450  pop r10
000076e4393d7452  pop r9
000076e4393d7454  pop r8
000076e4393d7456  pop rsi
000076e4393d7457  pop rdi
000076e4393d7458  pop rdx
000076e4393d7459  pop rcx
000076e4393d745a  pop rax
000076e4393d745b  add rsp, 0x08
000076e4393d745f  jmp 0x000076E4393D5C68
000076e4393d7464  call 0x000076E4392E5820
000076e4393d7469  jmp 0x000076E4393D5C75
000076e4393d746e  sub rsp, 0x08
000076e4393d7472  push rax
000076e4393d7473  push rcx
000076e4393d7474  push rdx
000076e4393d7475  push rdi
000076e4393d7476  push rsi
000076e4393d7477  push r8
000076e4393d7479  push r9
000076e4393d747b  push r10
000076e4393d747d  push r11
000076e4393d747f  sub rsp, 0xF0
000076e4393d7486  vmovaps [rsp], xmm0
000076e4393d748b  vmovaps [rsp+0x10], xmm1
000076e4393d7491  vmovaps [rsp+0x20], xmm2
000076e4393d7497  vmovaps [rsp+0x30], xmm3
000076e4393d749d  vmovaps [rsp+0x40], xmm4
000076e4393d74a3  vmovaps [rsp+0x50], xmm5
000076e4393d74a9  vmovaps [rsp+0x60], xmm6
000076e4393d74af  vmovaps [rsp+0x70], xmm7
000076e4393d74b5  vmovaps [rsp+0x80], xmm8
000076e4393d74be  vmovaps [rsp+0x90], xmm9
000076e4393d74c7  vmovaps [rsp+0xA0], xmm10
000076e4393d74d0  vmovaps [rsp+0xB0], xmm11
000076e4393d74d9  vmovaps [rsp+0xC0], xmm12
000076e4393d74e2  vmovaps [rsp+0xD0], xmm13
000076e4393d74eb  vmovaps [rsp+0xE0], xmm15
000076e4393d74f4  sub rsp, 0x30
000076e4393d74f8  movaps [rsp], xmm14
000076e4393d74fd  movaps [rsp+0x10], xmm4
000076e4393d7502  movaps [rsp+0x20], xmm3
000076e4393d7507  lea rdi, [rsp]
000076e4393d750b  mov esi, 0x00
000076e4393d7510  mov rax, 0x63DBDEB43530
000076e4393d751a  call rax
000076e4393d751c  movaps xmm14, [rsp]
000076e4393d7521  add rsp, 0x30
000076e4393d7525  vmovaps xmm0, [rsp]
000076e4393d752a  vmovaps xmm1, [rsp+0x10]
000076e4393d7530  vmovaps xmm2, [rsp+0x20]
000076e4393d7536  vmovaps xmm3, [rsp+0x30]
000076e4393d753c  vmovaps xmm4, [rsp+0x40]
000076e4393d7542  vmovaps xmm5, [rsp+0x50]
000076e4393d7548  vmovaps xmm6, [rsp+0x60]
000076e4393d754e  vmovaps xmm7, [rsp+0x70]
000076e4393d7554  vmovaps xmm8, [rsp+0x80]
000076e4393d755d  vmovaps xmm9, [rsp+0x90]
000076e4393d7566  vmovaps xmm10, [rsp+0xA0]
000076e4393d756f  vmovaps xmm11, [rsp+0xB0]
000076e4393d7578  vmovaps xmm12, [rsp+0xC0]
000076e4393d7581  vmovaps xmm13, [rsp+0xD0]
000076e4393d758a  vmovaps xmm15, [rsp+0xE0]
000076e4393d7593  add rsp, 0xF0
000076e4393d759a  pop r11
000076e4393d759c  pop r10
000076e4393d759e  pop r9
000076e4393d75a0  pop r8
000076e4393d75a2  pop rsi
000076e4393d75a3  pop rdi
000076e4393d75a4  pop rdx
000076e4393d75a5  pop rcx
000076e4393d75a6  pop rax
000076e4393d75a7  add rsp, 0x08
000076e4393d75ab  jmp 0x000076E4393D5C8F
000076e4393d75b0  sub rsp, 0x08
000076e4393d75b4  push rax
000076e4393d75b5  push rcx
000076e4393d75b6  push rdx
000076e4393d75b7  push rdi
000076e4393d75b8  push rsi
000076e4393d75b9  push r8
000076e4393d75bb  push r9
000076e4393d75bd  push r10
000076e4393d75bf  push r11
000076e4393d75c1  sub rsp, 0xF0
000076e4393d75c8  vmovaps [rsp], xmm0
000076e4393d75cd  vmovaps [rsp+0x10], xmm1
000076e4393d75d3  vmovaps [rsp+0x20], xmm2
000076e4393d75d9  vmovaps [rsp+0x30], xmm3
000076e4393d75df  vmovaps [rsp+0x40], xmm4
000076e4393d75e5  vmovaps [rsp+0x50], xmm5
000076e4393d75eb  vmovaps [rsp+0x60], xmm7
000076e4393d75f1  vmovaps [rsp+0x70], xmm8
000076e4393d75f7  vmovaps [rsp+0x80], xmm9
000076e4393d7600  vmovaps [rsp+0x90], xmm10
000076e4393d7609  vmovaps [rsp+0xA0], xmm11
000076e4393d7612  vmovaps [rsp+0xB0], xmm12
000076e4393d761b  vmovaps [rsp+0xC0], xmm13
000076e4393d7624  vmovaps [rsp+0xD0], xmm14
000076e4393d762d  vmovaps [rsp+0xE0], xmm15
000076e4393d7636  sub rsp, 0x30
000076e4393d763a  movaps [rsp], xmm6
000076e4393d763e  movaps [rsp+0x10], xmm9
000076e4393d7644  movaps [rsp+0x20], xmm7
000076e4393d7649  lea rdi, [rsp]
000076e4393d764d  mov esi, 0x00
000076e4393d7652  mov rax, 0x63DBDEB43530
000076e4393d765c  call rax
000076e4393d765e  movaps xmm6, [rsp]
000076e4393d7662  add rsp, 0x30
000076e4393d7666  vmovaps xmm0, [rsp]
000076e4393d766b  vmovaps xmm1, [rsp+0x10]
000076e4393d7671  vmovaps xmm2, [rsp+0x20]
000076e4393d7677  vmovaps xmm3, [rsp+0x30]
000076e4393d767d  vmovaps xmm4, [rsp+0x40]
000076e4393d7683  vmovaps xmm5, [rsp+0x50]
000076e4393d7689  vmovaps xmm7, [rsp+0x60]
000076e4393d768f  vmovaps xmm8, [rsp+0x70]
000076e4393d7695  vmovaps xmm9, [rsp+0x80]
000076e4393d769e  vmovaps xmm10, [rsp+0x90]
000076e4393d76a7  vmovaps xmm11, [rsp+0xA0]
000076e4393d76b0  vmovaps xmm12, [rsp+0xB0]
000076e4393d76b9  vmovaps xmm13, [rsp+0xC0]
000076e4393d76c2  vmovaps xmm14, [rsp+0xD0]
000076e4393d76cb  vmovaps xmm15, [rsp+0xE0]
000076e4393d76d4  add rsp, 0xF0
000076e4393d76db  pop r11
000076e4393d76dd  pop r10
000076e4393d76df  pop r9
000076e4393d76e1  pop r8
000076e4393d76e3  pop rsi
000076e4393d76e4  pop rdi
000076e4393d76e5  pop rdx
000076e4393d76e6  pop rcx
000076e4393d76e7  pop rax
000076e4393d76e8  add rsp, 0x08
000076e4393d76ec  jmp 0x000076E4393D5CA7
000076e4393d76f1  sub rsp, 0x08
000076e4393d76f5  push rax
000076e4393d76f6  push rcx
000076e4393d76f7  push rdx
000076e4393d76f8  push rdi
000076e4393d76f9  push rsi
000076e4393d76fa  push r8
000076e4393d76fc  push r9
000076e4393d76fe  push r10
000076e4393d7700  push r11
000076e4393d7702  sub rsp, 0xF0
000076e4393d7709  vmovaps [rsp], xmm0
000076e4393d770e  vmovaps [rsp+0x10], xmm1
000076e4393d7714  vmovaps [rsp+0x20], xmm2
000076e4393d771a  vmovaps [rsp+0x30], xmm3
000076e4393d7720  vmovaps [rsp+0x40], xmm4
000076e4393d7726  vmovaps [rsp+0x50], xmm5
000076e4393d772c  vmovaps [rsp+0x60], xmm6
000076e4393d7732  vmovaps [rsp+0x70], xmm8
000076e4393d7738  vmovaps [rsp+0x80], xmm9
000076e4393d7741  vmovaps [rsp+0x90], xmm10
000076e4393d774a  vmovaps [rsp+0xA0], xmm11
000076e4393d7753  vmovaps [rsp+0xB0], xmm12
000076e4393d775c  vmovaps [rsp+0xC0], xmm13
000076e4393d7765  vmovaps [rsp+0xD0], xmm14
000076e4393d776e  vmovaps [rsp+0xE0], xmm15
000076e4393d7777  sub rsp, 0x30
000076e4393d777b  movaps [rsp], xmm7
000076e4393d777f  movaps [rsp+0x10], xmm4
000076e4393d7784  movaps [rsp+0x20], xmm9
000076e4393d778a  lea rdi, [rsp]
000076e4393d778e  mov esi, 0x00
000076e4393d7793  mov rax, 0x63DBDEB43530
000076e4393d779d  call rax
000076e4393d779f  movaps xmm7, [rsp]
000076e4393d77a3  add rsp, 0x30
000076e4393d77a7  vmovaps xmm0, [rsp]
000076e4393d77ac  vmovaps xmm1, [rsp+0x10]
000076e4393d77b2  vmovaps xmm2, [rsp+0x20]
000076e4393d77b8  vmovaps xmm3, [rsp+0x30]
000076e4393d77be  vmovaps xmm4, [rsp+0x40]
000076e4393d77c4  vmovaps xmm5, [rsp+0x50]
000076e4393d77ca  vmovaps xmm6, [rsp+0x60]
000076e4393d77d0  vmovaps xmm8, [rsp+0x70]
000076e4393d77d6  vmovaps xmm9, [rsp+0x80]
000076e4393d77df  vmovaps xmm10, [rsp+0x90]
000076e4393d77e8  vmovaps xmm11, [rsp+0xA0]
000076e4393d77f1  vmovaps xmm12, [rsp+0xB0]
000076e4393d77fa  vmovaps xmm13, [rsp+0xC0]
000076e4393d7803  vmovaps xmm14, [rsp+0xD0]
000076e4393d780c  vmovaps xmm15, [rsp+0xE0]
000076e4393d7815  add rsp, 0xF0
000076e4393d781c  pop r11
000076e4393d781e  pop r10
000076e4393d7820  pop r9
000076e4393d7822  pop r8
000076e4393d7824  pop rsi
000076e4393d7825  pop rdi
000076e4393d7826  pop rdx
000076e4393d7827  pop rcx
000076e4393d7828  pop rax
000076e4393d7829  add rsp, 0x08
000076e4393d782d  jmp 0x000076E4393D5CD4
000076e4393d7832  sub rsp, 0x08
000076e4393d7836  push rax
000076e4393d7837  push rcx
000076e4393d7838  push rdx
000076e4393d7839  push rdi
000076e4393d783a  push rsi
000076e4393d783b  push r8
000076e4393d783d  push r9
000076e4393d783f  push r10
000076e4393d7841  push r11
000076e4393d7843  sub rsp, 0xF0
000076e4393d784a  vmovaps [rsp], xmm0
000076e4393d784f  vmovaps [rsp+0x10], xmm1
000076e4393d7855  vmovaps [rsp+0x20], xmm2
000076e4393d785b  vmovaps [rsp+0x30], xmm3
000076e4393d7861  vmovaps [rsp+0x40], xmm5
000076e4393d7867  vmovaps [rsp+0x50], xmm6
000076e4393d786d  vmovaps [rsp+0x60], xmm7
000076e4393d7873  vmovaps [rsp+0x70], xmm8
000076e4393d7879  vmovaps [rsp+0x80], xmm9
000076e4393d7882  vmovaps [rsp+0x90], xmm10
000076e4393d788b  vmovaps [rsp+0xA0], xmm11
000076e4393d7894  vmovaps [rsp+0xB0], xmm12
000076e4393d789d  vmovaps [rsp+0xC0], xmm13
000076e4393d78a6  vmovaps [rsp+0xD0], xmm14
000076e4393d78af  vmovaps [rsp+0xE0], xmm15
000076e4393d78b8  sub rsp, 0x30
000076e4393d78bc  movaps [rsp], xmm4
000076e4393d78c0  movaps [rsp+0x10], xmm15
000076e4393d78c6  movaps [rsp+0x20], xmm9
000076e4393d78cc  lea rdi, [rsp]
000076e4393d78d0  mov esi, 0x00
000076e4393d78d5  mov rax, 0x63DBDEB43530
000076e4393d78df  call rax
000076e4393d78e1  movaps xmm4, [rsp]
000076e4393d78e5  add rsp, 0x30
000076e4393d78e9  vmovaps xmm0, [rsp]
000076e4393d78ee  vmovaps xmm1, [rsp+0x10]
000076e4393d78f4  vmovaps xmm2, [rsp+0x20]
000076e4393d78fa  vmovaps xmm3, [rsp+0x30]
000076e4393d7900  vmovaps xmm5, [rsp+0x40]
000076e4393d7906  vmovaps xmm6, [rsp+0x50]
000076e4393d790c  vmovaps xmm7, [rsp+0x60]
000076e4393d7912  vmovaps xmm8, [rsp+0x70]
000076e4393d7918  vmovaps xmm9, [rsp+0x80]
000076e4393d7921  vmovaps xmm10, [rsp+0x90]
000076e4393d792a  vmovaps xmm11, [rsp+0xA0]
000076e4393d7933  vmovaps xmm12, [rsp+0xB0]
000076e4393d793c  vmovaps xmm13, [rsp+0xC0]
000076e4393d7945  vmovaps xmm14, [rsp+0xD0]
000076e4393d794e  vmovaps xmm15, [rsp+0xE0]
000076e4393d7957  add rsp, 0xF0
000076e4393d795e  pop r11
000076e4393d7960  pop r10
000076e4393d7962  pop r9
000076e4393d7964  pop r8
000076e4393d7966  pop rsi
000076e4393d7967  pop rdi
000076e4393d7968  pop rdx
000076e4393d7969  pop rcx
000076e4393d796a  pop rax
000076e4393d796b  add rsp, 0x08
000076e4393d796f  jmp 0x000076E4393D5CF9
000076e4393d7974  call 0x000076E4392E5820
000076e4393d7979  jmp 0x000076E4393D5D06
000076e4393d797e  sub rsp, 0x08
000076e4393d7982  push rax
000076e4393d7983  push rcx
000076e4393d7984  push rdx
000076e4393d7985  push rdi
000076e4393d7986  push rsi
000076e4393d7987  push r8
000076e4393d7989  push r9
000076e4393d798b  push r10
000076e4393d798d  push r11
000076e4393d798f  sub rsp, 0xF0
000076e4393d7996  vmovaps [rsp], xmm0
000076e4393d799b  vmovaps [rsp+0x10], xmm1
000076e4393d79a1  vmovaps [rsp+0x20], xmm2
000076e4393d79a7  vmovaps [rsp+0x30], xmm4
000076e4393d79ad  vmovaps [rsp+0x40], xmm5
000076e4393d79b3  vmovaps [rsp+0x50], xmm6
000076e4393d79b9  vmovaps [rsp+0x60], xmm7
000076e4393d79bf  vmovaps [rsp+0x70], xmm8
000076e4393d79c5  vmovaps [rsp+0x80], xmm9
000076e4393d79ce  vmovaps [rsp+0x90], xmm10
000076e4393d79d7  vmovaps [rsp+0xA0], xmm11
000076e4393d79e0  vmovaps [rsp+0xB0], xmm12
000076e4393d79e9  vmovaps [rsp+0xC0], xmm13
000076e4393d79f2  vmovaps [rsp+0xD0], xmm14
000076e4393d79fb  vmovaps [rsp+0xE0], xmm15
000076e4393d7a04  sub rsp, 0x30
000076e4393d7a08  movaps [rsp], xmm3
000076e4393d7a0c  movaps [rsp+0x10], xmm1
000076e4393d7a11  movaps [rsp+0x20], xmm9
000076e4393d7a17  lea rdi, [rsp]
000076e4393d7a1b  mov esi, 0x00
000076e4393d7a20  mov rax, 0x63DBDEB43530
000076e4393d7a2a  call rax
000076e4393d7a2c  movaps xmm3, [rsp]
000076e4393d7a30  add rsp, 0x30
000076e4393d7a34  vmovaps xmm0, [rsp]
000076e4393d7a39  vmovaps xmm1, [rsp+0x10]
000076e4393d7a3f  vmovaps xmm2, [rsp+0x20]
000076e4393d7a45  vmovaps xmm4, [rsp+0x30]
000076e4393d7a4b  vmovaps xmm5, [rsp+0x40]
000076e4393d7a51  vmovaps xmm6, [rsp+0x50]
000076e4393d7a57  vmovaps xmm7, [rsp+0x60]
000076e4393d7a5d  vmovaps xmm8, [rsp+0x70]
000076e4393d7a63  vmovaps xmm9, [rsp+0x80]
000076e4393d7a6c  vmovaps xmm10, [rsp+0x90]
000076e4393d7a75  vmovaps xmm11, [rsp+0xA0]
000076e4393d7a7e  vmovaps xmm12, [rsp+0xB0]
000076e4393d7a87  vmovaps xmm13, [rsp+0xC0]
000076e4393d7a90  vmovaps xmm14, [rsp+0xD0]
000076e4393d7a99  vmovaps xmm15, [rsp+0xE0]
000076e4393d7aa2  add rsp, 0xF0
000076e4393d7aa9  pop r11
000076e4393d7aab  pop r10
000076e4393d7aad  pop r9
000076e4393d7aaf  pop r8
000076e4393d7ab1  pop rsi
000076e4393d7ab2  pop rdi
000076e4393d7ab3  pop rdx
000076e4393d7ab4  pop rcx
000076e4393d7ab5  pop rax
000076e4393d7ab6  add rsp, 0x08
000076e4393d7aba  jmp 0x000076E4393D5D43
000076e4393d7abf  sub rsp, 0x08
000076e4393d7ac3  push rax
000076e4393d7ac4  push rcx
000076e4393d7ac5  push rdx
000076e4393d7ac6  push rdi
000076e4393d7ac7  push rsi
000076e4393d7ac8  push r8
000076e4393d7aca  push r9
000076e4393d7acc  push r10
000076e4393d7ace  push r11
000076e4393d7ad0  sub rsp, 0xF0
000076e4393d7ad7  vmovaps [rsp], xmm0
000076e4393d7adc  vmovaps [rsp+0x10], xmm2
000076e4393d7ae2  vmovaps [rsp+0x20], xmm3
000076e4393d7ae8  vmovaps [rsp+0x30], xmm4
000076e4393d7aee  vmovaps [rsp+0x40], xmm5
000076e4393d7af4  vmovaps [rsp+0x50], xmm6
000076e4393d7afa  vmovaps [rsp+0x60], xmm7
000076e4393d7b00  vmovaps [rsp+0x70], xmm8
000076e4393d7b06  vmovaps [rsp+0x80], xmm9
000076e4393d7b0f  vmovaps [rsp+0x90], xmm10
000076e4393d7b18  vmovaps [rsp+0xA0], xmm11
000076e4393d7b21  vmovaps [rsp+0xB0], xmm12
000076e4393d7b2a  vmovaps [rsp+0xC0], xmm13
000076e4393d7b33  vmovaps [rsp+0xD0], xmm14
000076e4393d7b3c  vmovaps [rsp+0xE0], xmm15
000076e4393d7b45  sub rsp, 0x30
000076e4393d7b49  movaps [rsp], xmm1
000076e4393d7b4d  movaps [rsp+0x10], xmm15
000076e4393d7b53  movaps [rsp+0x20], xmm9
000076e4393d7b59  lea rdi, [rsp]
000076e4393d7b5d  mov esi, 0x00
000076e4393d7b62  mov rax, 0x63DBDEB43530
000076e4393d7b6c  call rax
000076e4393d7b6e  movaps xmm1, [rsp]
000076e4393d7b72  add rsp, 0x30
000076e4393d7b76  vmovaps xmm0, [rsp]
000076e4393d7b7b  vmovaps xmm2, [rsp+0x10]
000076e4393d7b81  vmovaps xmm3, [rsp+0x20]
000076e4393d7b87  vmovaps xmm4, [rsp+0x30]
000076e4393d7b8d  vmovaps xmm5, [rsp+0x40]
000076e4393d7b93  vmovaps xmm6, [rsp+0x50]
000076e4393d7b99  vmovaps xmm7, [rsp+0x60]
000076e4393d7b9f  vmovaps xmm8, [rsp+0x70]
000076e4393d7ba5  vmovaps xmm9, [rsp+0x80]
000076e4393d7bae  vmovaps xmm10, [rsp+0x90]
000076e4393d7bb7  vmovaps xmm11, [rsp+0xA0]
000076e4393d7bc0  vmovaps xmm12, [rsp+0xB0]
000076e4393d7bc9  vmovaps xmm13, [rsp+0xC0]
000076e4393d7bd2  vmovaps xmm14, [rsp+0xD0]
000076e4393d7bdb  vmovaps xmm15, [rsp+0xE0]
000076e4393d7be4  add rsp, 0xF0
000076e4393d7beb  pop r11
000076e4393d7bed  pop r10
000076e4393d7bef  pop r9
000076e4393d7bf1  pop r8
000076e4393d7bf3  pop rsi
000076e4393d7bf4  pop rdi
000076e4393d7bf5  pop rdx
000076e4393d7bf6  pop rcx
000076e4393d7bf7  pop rax
000076e4393d7bf8  add rsp, 0x08
000076e4393d7bfc  jmp 0x000076E4393D5DCB
000076e4393d7c01  call 0x000076E4392E5820
000076e4393d7c06  jmp 0x000076E4393D5DD8
000076e4393d7c0b  sub rsp, 0x08
000076e4393d7c0f  push rax
000076e4393d7c10  push rcx
000076e4393d7c11  push rdx
000076e4393d7c12  push rdi
000076e4393d7c13  push rsi
000076e4393d7c14  push r8
000076e4393d7c16  push r9
000076e4393d7c18  push r10
000076e4393d7c1a  push r11
000076e4393d7c1c  sub rsp, 0xF0
000076e4393d7c23  vmovaps [rsp], xmm0
000076e4393d7c28  vmovaps [rsp+0x10], xmm2
000076e4393d7c2e  vmovaps [rsp+0x20], xmm3
000076e4393d7c34  vmovaps [rsp+0x30], xmm4
000076e4393d7c3a  vmovaps [rsp+0x40], xmm5
000076e4393d7c40  vmovaps [rsp+0x50], xmm6
000076e4393d7c46  vmovaps [rsp+0x60], xmm7
000076e4393d7c4c  vmovaps [rsp+0x70], xmm8
000076e4393d7c52  vmovaps [rsp+0x80], xmm9
000076e4393d7c5b  vmovaps [rsp+0x90], xmm10
000076e4393d7c64  vmovaps [rsp+0xA0], xmm11
000076e4393d7c6d  vmovaps [rsp+0xB0], xmm12
000076e4393d7c76  vmovaps [rsp+0xC0], xmm13
000076e4393d7c7f  vmovaps [rsp+0xD0], xmm14
000076e4393d7c88  vmovaps [rsp+0xE0], xmm15
000076e4393d7c91  sub rsp, 0x30
000076e4393d7c95  movaps [rsp], xmm1
000076e4393d7c99  movaps [rsp+0x10], xmm5
000076e4393d7c9e  movaps [rsp+0x20], xmm7
000076e4393d7ca3  lea rdi, [rsp]
000076e4393d7ca7  mov esi, 0x00
000076e4393d7cac  mov rax, 0x63DBDEB43530
000076e4393d7cb6  call rax
000076e4393d7cb8  movaps xmm1, [rsp]
000076e4393d7cbc  add rsp, 0x30
000076e4393d7cc0  vmovaps xmm0, [rsp]
000076e4393d7cc5  vmovaps xmm2, [rsp+0x10]
000076e4393d7ccb  vmovaps xmm3, [rsp+0x20]
000076e4393d7cd1  vmovaps xmm4, [rsp+0x30]
000076e4393d7cd7  vmovaps xmm5, [rsp+0x40]
000076e4393d7cdd  vmovaps xmm6, [rsp+0x50]
000076e4393d7ce3  vmovaps xmm7, [rsp+0x60]
000076e4393d7ce9  vmovaps xmm8, [rsp+0x70]
000076e4393d7cef  vmovaps xmm9, [rsp+0x80]
000076e4393d7cf8  vmovaps xmm10, [rsp+0x90]
000076e4393d7d01  vmovaps xmm11, [rsp+0xA0]
000076e4393d7d0a  vmovaps xmm12, [rsp+0xB0]
000076e4393d7d13  vmovaps xmm13, [rsp+0xC0]
000076e4393d7d1c  vmovaps xmm14, [rsp+0xD0]
000076e4393d7d25  vmovaps xmm15, [rsp+0xE0]
000076e4393d7d2e  add rsp, 0xF0
000076e4393d7d35  pop r11
000076e4393d7d37  pop r10
000076e4393d7d39  pop r9
000076e4393d7d3b  pop r8
000076e4393d7d3d  pop rsi
000076e4393d7d3e  pop rdi
000076e4393d7d3f  pop rdx
000076e4393d7d40  pop rcx
000076e4393d7d41  pop rax
000076e4393d7d42  add rsp, 0x08
000076e4393d7d46  jmp 0x000076E4393D5E7D
000076e4393d7d4b  sub rsp, 0x08
000076e4393d7d4f  push rax
000076e4393d7d50  push rcx
000076e4393d7d51  push rdx
000076e4393d7d52  push rdi
000076e4393d7d53  push rsi
000076e4393d7d54  push r8
000076e4393d7d56  push r9
000076e4393d7d58  push r10
000076e4393d7d5a  push r11
000076e4393d7d5c  sub rsp, 0xF0
000076e4393d7d63  vmovaps [rsp], xmm0
000076e4393d7d68  vmovaps [rsp+0x10], xmm1
000076e4393d7d6e  vmovaps [rsp+0x20], xmm2
000076e4393d7d74  vmovaps [rsp+0x30], xmm3
000076e4393d7d7a  vmovaps [rsp+0x40], xmm4
000076e4393d7d80  vmovaps [rsp+0x50], xmm5
000076e4393d7d86  vmovaps [rsp+0x60], xmm6
000076e4393d7d8c  vmovaps [rsp+0x70], xmm8
000076e4393d7d92  vmovaps [rsp+0x80], xmm9
000076e4393d7d9b  vmovaps [rsp+0x90], xmm10
000076e4393d7da4  vmovaps [rsp+0xA0], xmm11
000076e4393d7dad  vmovaps [rsp+0xB0], xmm12
000076e4393d7db6  vmovaps [rsp+0xC0], xmm13
000076e4393d7dbf  vmovaps [rsp+0xD0], xmm14
000076e4393d7dc8  vmovaps [rsp+0xE0], xmm15
000076e4393d7dd1  sub rsp, 0x30
000076e4393d7dd5  movaps [rsp], xmm7
000076e4393d7dd9  movaps [rsp+0x10], xmm5
000076e4393d7dde  movaps [rsp+0x20], xmm15
000076e4393d7de4  lea rdi, [rsp]
000076e4393d7de8  mov esi, 0x00
000076e4393d7ded  mov rax, 0x63DBDEB43530
000076e4393d7df7  call rax
000076e4393d7df9  movaps xmm7, [rsp]
000076e4393d7dfd  add rsp, 0x30
000076e4393d7e01  vmovaps xmm0, [rsp]
000076e4393d7e06  vmovaps xmm1, [rsp+0x10]
000076e4393d7e0c  vmovaps xmm2, [rsp+0x20]
000076e4393d7e12  vmovaps xmm3, [rsp+0x30]
000076e4393d7e18  vmovaps xmm4, [rsp+0x40]
000076e4393d7e1e  vmovaps xmm5, [rsp+0x50]
000076e4393d7e24  vmovaps xmm6, [rsp+0x60]
000076e4393d7e2a  vmovaps xmm8, [rsp+0x70]
000076e4393d7e30  vmovaps xmm9, [rsp+0x80]
000076e4393d7e39  vmovaps xmm10, [rsp+0x90]
000076e4393d7e42  vmovaps xmm11, [rsp+0xA0]
000076e4393d7e4b  vmovaps xmm12, [rsp+0xB0]
000076e4393d7e54  vmovaps xmm13, [rsp+0xC0]
000076e4393d7e5d  vmovaps xmm14, [rsp+0xD0]
000076e4393d7e66  vmovaps xmm15, [rsp+0xE0]
000076e4393d7e6f  add rsp, 0xF0
000076e4393d7e76  pop r11
000076e4393d7e78  pop r10
000076e4393d7e7a  pop r9
000076e4393d7e7c  pop r8
000076e4393d7e7e  pop rsi
000076e4393d7e7f  pop rdi
000076e4393d7e80  pop rdx
000076e4393d7e81  pop rcx
000076e4393d7e82  pop rax
000076e4393d7e83  add rsp, 0x08
000076e4393d7e87  jmp 0x000076E4393D5EB3
000076e4393d7e8c  call 0x000076E4392D64F0
000076e4393d7e91  jmp 0x000076E4393D5EC0
000076e4393d7e96  sub rsp, 0x08
000076e4393d7e9a  push rax
000076e4393d7e9b  push rcx
000076e4393d7e9c  push rdx
000076e4393d7e9d  push rdi
000076e4393d7e9e  push rsi
000076e4393d7e9f  push r8
000076e4393d7ea1  push r9
000076e4393d7ea3  push r10
000076e4393d7ea5  push r11
000076e4393d7ea7  sub rsp, 0xF0
000076e4393d7eae  vmovaps [rsp], xmm0
000076e4393d7eb3  vmovaps [rsp+0x10], xmm1
000076e4393d7eb9  vmovaps [rsp+0x20], xmm2
000076e4393d7ebf  vmovaps [rsp+0x30], xmm3
000076e4393d7ec5  vmovaps [rsp+0x40], xmm4
000076e4393d7ecb  vmovaps [rsp+0x50], xmm5
000076e4393d7ed1  vmovaps [rsp+0x60], xmm6
000076e4393d7ed7  vmovaps [rsp+0x70], xmm7
000076e4393d7edd  vmovaps [rsp+0x80], xmm8
000076e4393d7ee6  vmovaps [rsp+0x90], xmm9
000076e4393d7eef  vmovaps [rsp+0xA0], xmm10
000076e4393d7ef8  vmovaps [rsp+0xB0], xmm11
000076e4393d7f01  vmovaps [rsp+0xC0], xmm12
000076e4393d7f0a  vmovaps [rsp+0xD0], xmm13
000076e4393d7f13  vmovaps [rsp+0xE0], xmm14
000076e4393d7f1c  sub rsp, 0x30
000076e4393d7f20  movaps [rsp], xmm15
000076e4393d7f25  movaps [rsp+0x10], xmm5
000076e4393d7f2a  movaps [rsp+0x20], xmm3
000076e4393d7f2f  lea rdi, [rsp]
000076e4393d7f33  mov esi, 0x00
000076e4393d7f38  mov rax, 0x63DBDEB43530
000076e4393d7f42  call rax
000076e4393d7f44  movaps xmm15, [rsp]
000076e4393d7f49  add rsp, 0x30
000076e4393d7f4d  vmovaps xmm0, [rsp]
000076e4393d7f52  vmovaps xmm1, [rsp+0x10]
000076e4393d7f58  vmovaps xmm2, [rsp+0x20]
000076e4393d7f5e  vmovaps xmm3, [rsp+0x30]
000076e4393d7f64  vmovaps xmm4, [rsp+0x40]
000076e4393d7f6a  vmovaps xmm5, [rsp+0x50]
000076e4393d7f70  vmovaps xmm6, [rsp+0x60]
000076e4393d7f76  vmovaps xmm7, [rsp+0x70]
000076e4393d7f7c  vmovaps xmm8, [rsp+0x80]
000076e4393d7f85  vmovaps xmm9, [rsp+0x90]
000076e4393d7f8e  vmovaps xmm10, [rsp+0xA0]
000076e4393d7f97  vmovaps xmm11, [rsp+0xB0]
000076e4393d7fa0  vmovaps xmm12, [rsp+0xC0]
000076e4393d7fa9  vmovaps xmm13, [rsp+0xD0]
000076e4393d7fb2  vmovaps xmm14, [rsp+0xE0]
000076e4393d7fbb  add rsp, 0xF0
000076e4393d7fc2  pop r11
000076e4393d7fc4  pop r10
000076e4393d7fc6  pop r9
000076e4393d7fc8  pop r8
000076e4393d7fca  pop rsi
000076e4393d7fcb  pop rdi
000076e4393d7fcc  pop rdx
000076e4393d7fcd  pop rcx
000076e4393d7fce  pop rax
000076e4393d7fcf  add rsp, 0x08
000076e4393d7fd3  jmp 0x000076E4393D5EE6
000076e4393d7fd8  sub rsp, 0x08
000076e4393d7fdc  push rax
000076e4393d7fdd  push rcx
000076e4393d7fde  push rdx
000076e4393d7fdf  push rdi
000076e4393d7fe0  push rsi
000076e4393d7fe1  push r8
000076e4393d7fe3  push r9
000076e4393d7fe5  push r10
000076e4393d7fe7  push r11
000076e4393d7fe9  sub rsp, 0xF0
000076e4393d7ff0  vmovaps [rsp], xmm0
000076e4393d7ff5  vmovaps [rsp+0x10], xmm2
000076e4393d7ffb  vmovaps [rsp+0x20], xmm3
000076e4393d8001  vmovaps [rsp+0x30], xmm4
000076e4393d8007  vmovaps [rsp+0x40], xmm5
000076e4393d800d  vmovaps [rsp+0x50], xmm6
000076e4393d8013  vmovaps [rsp+0x60], xmm7
000076e4393d8019  vmovaps [rsp+0x70], xmm8
000076e4393d801f  vmovaps [rsp+0x80], xmm9
000076e4393d8028  vmovaps [rsp+0x90], xmm10
000076e4393d8031  vmovaps [rsp+0xA0], xmm11
000076e4393d803a  vmovaps [rsp+0xB0], xmm12
000076e4393d8043  vmovaps [rsp+0xC0], xmm13
000076e4393d804c  vmovaps [rsp+0xD0], xmm14
000076e4393d8055  vmovaps [rsp+0xE0], xmm15
000076e4393d805e  sub rsp, 0x30
000076e4393d8062  movaps [rsp], xmm1
000076e4393d8066  movaps [rsp+0x10], xmm5
000076e4393d806b  movaps [rsp+0x20], xmm4
000076e4393d8070  lea rdi, [rsp]
000076e4393d8074  mov esi, 0x00
000076e4393d8079  mov rax, 0x63DBDEB43530
000076e4393d8083  call rax
000076e4393d8085  movaps xmm1, [rsp]
000076e4393d8089  add rsp, 0x30
000076e4393d808d  vmovaps xmm0, [rsp]
000076e4393d8092  vmovaps xmm2, [rsp+0x10]
000076e4393d8098  vmovaps xmm3, [rsp+0x20]
000076e4393d809e  vmovaps xmm4, [rsp+0x30]
000076e4393d80a4  vmovaps xmm5, [rsp+0x40]
000076e4393d80aa  vmovaps xmm6, [rsp+0x50]
000076e4393d80b0  vmovaps xmm7, [rsp+0x60]
000076e4393d80b6  vmovaps xmm8, [rsp+0x70]
000076e4393d80bc  vmovaps xmm9, [rsp+0x80]
000076e4393d80c5  vmovaps xmm10, [rsp+0x90]
000076e4393d80ce  vmovaps xmm11, [rsp+0xA0]
000076e4393d80d7  vmovaps xmm12, [rsp+0xB0]
000076e4393d80e0  vmovaps xmm13, [rsp+0xC0]
000076e4393d80e9  vmovaps xmm14, [rsp+0xD0]
000076e4393d80f2  vmovaps xmm15, [rsp+0xE0]
000076e4393d80fb  add rsp, 0xF0
000076e4393d8102  pop r11
000076e4393d8104  pop r10
000076e4393d8106  pop r9
000076e4393d8108  pop r8
000076e4393d810a  pop rsi
000076e4393d810b  pop rdi
000076e4393d810c  pop rdx
000076e4393d810d  pop rcx
000076e4393d810e  pop rax
000076e4393d810f  add rsp, 0x08
000076e4393d8113  jmp 0x000076E4393D5F06
000076e4393d8118  sub rsp, 0x08
000076e4393d811c  push rax
000076e4393d811d  push rcx
000076e4393d811e  push rdx
000076e4393d811f  push rdi
000076e4393d8120  push rsi
000076e4393d8121  push r8
000076e4393d8123  push r9
000076e4393d8125  push r10
000076e4393d8127  push r11
000076e4393d8129  sub rsp, 0xF0
000076e4393d8130  vmovaps [rsp], xmm0
000076e4393d8135  vmovaps [rsp+0x10], xmm1
000076e4393d813b  vmovaps [rsp+0x20], xmm2
000076e4393d8141  vmovaps [rsp+0x30], xmm3
000076e4393d8147  vmovaps [rsp+0x40], xmm5
000076e4393d814d  vmovaps [rsp+0x50], xmm6
000076e4393d8153  vmovaps [rsp+0x60], xmm7
000076e4393d8159  vmovaps [rsp+0x70], xmm8
000076e4393d815f  vmovaps [rsp+0x80], xmm9
000076e4393d8168  vmovaps [rsp+0x90], xmm10
000076e4393d8171  vmovaps [rsp+0xA0], xmm11
000076e4393d817a  vmovaps [rsp+0xB0], xmm12
000076e4393d8183  vmovaps [rsp+0xC0], xmm13
000076e4393d818c  vmovaps [rsp+0xD0], xmm14
000076e4393d8195  vmovaps [rsp+0xE0], xmm15
000076e4393d819e  sub rsp, 0x30
000076e4393d81a2  movaps [rsp], xmm4
000076e4393d81a6  movaps [rsp+0x10], xmm3
000076e4393d81ab  movaps [rsp+0x20], xmm5
000076e4393d81b0  lea rdi, [rsp]
000076e4393d81b4  mov esi, 0x00
000076e4393d81b9  mov rax, 0x63DBDEB43530
000076e4393d81c3  call rax
000076e4393d81c5  movaps xmm4, [rsp]
000076e4393d81c9  add rsp, 0x30
000076e4393d81cd  vmovaps xmm0, [rsp]
000076e4393d81d2  vmovaps xmm1, [rsp+0x10]
000076e4393d81d8  vmovaps xmm2, [rsp+0x20]
000076e4393d81de  vmovaps xmm3, [rsp+0x30]
000076e4393d81e4  vmovaps xmm5, [rsp+0x40]
000076e4393d81ea  vmovaps xmm6, [rsp+0x50]
000076e4393d81f0  vmovaps xmm7, [rsp+0x60]
000076e4393d81f6  vmovaps xmm8, [rsp+0x70]
000076e4393d81fc  vmovaps xmm9, [rsp+0x80]
000076e4393d8205  vmovaps xmm10, [rsp+0x90]
000076e4393d820e  vmovaps xmm11, [rsp+0xA0]
000076e4393d8217  vmovaps xmm12, [rsp+0xB0]
000076e4393d8220  vmovaps xmm13, [rsp+0xC0]
000076e4393d8229  vmovaps xmm14, [rsp+0xD0]
000076e4393d8232  vmovaps xmm15, [rsp+0xE0]
000076e4393d823b  add rsp, 0xF0
000076e4393d8242  pop r11
000076e4393d8244  pop r10
000076e4393d8246  pop r9
000076e4393d8248  pop r8
000076e4393d824a  pop rsi
000076e4393d824b  pop rdi
000076e4393d824c  pop rdx
000076e4393d824d  pop rcx
000076e4393d824e  pop rax
000076e4393d824f  add rsp, 0x08
000076e4393d8253  jmp 0x000076E4393D5F54
000076e4393d8258  call 0x000076E4392D64F0
000076e4393d825d  jmp 0x000076E4393D5F61
000076e4393d8262  sub rsp, 0x08
000076e4393d8266  push rax
000076e4393d8267  push rcx
000076e4393d8268  push rdx
000076e4393d8269  push rdi
000076e4393d826a  push rsi
000076e4393d826b  push r8
000076e4393d826d  push r9
000076e4393d826f  push r10
000076e4393d8271  push r11
000076e4393d8273  sub rsp, 0xF0
000076e4393d827a  vmovaps [rsp], xmm0
000076e4393d827f  vmovaps [rsp+0x10], xmm1
000076e4393d8285  vmovaps [rsp+0x20], xmm2
000076e4393d828b  vmovaps [rsp+0x30], xmm3
000076e4393d8291  vmovaps [rsp+0x40], xmm4
000076e4393d8297  vmovaps [rsp+0x50], xmm6
000076e4393d829d  vmovaps [rsp+0x60], xmm7
000076e4393d82a3  vmovaps [rsp+0x70], xmm8
000076e4393d82a9  vmovaps [rsp+0x80], xmm9
000076e4393d82b2  vmovaps [rsp+0x90], xmm10
000076e4393d82bb  vmovaps [rsp+0xA0], xmm11
000076e4393d82c4  vmovaps [rsp+0xB0], xmm12
000076e4393d82cd  vmovaps [rsp+0xC0], xmm13
000076e4393d82d6  vmovaps [rsp+0xD0], xmm14
000076e4393d82df  vmovaps [rsp+0xE0], xmm15
000076e4393d82e8  sub rsp, 0x30
000076e4393d82ec  movaps [rsp], xmm5
000076e4393d82f0  movaps [rsp+0x10], xmm6
000076e4393d82f5  movaps [rsp+0x20], xmm3
000076e4393d82fa  lea rdi, [rsp]
000076e4393d82fe  mov esi, 0x00
000076e4393d8303  mov rax, 0x63DBDEB43530
000076e4393d830d  call rax
000076e4393d830f  movaps xmm5, [rsp]
000076e4393d8313  add rsp, 0x30
000076e4393d8317  vmovaps xmm0, [rsp]
000076e4393d831c  vmovaps xmm1, [rsp+0x10]
000076e4393d8322  vmovaps xmm2, [rsp+0x20]
000076e4393d8328  vmovaps xmm3, [rsp+0x30]
000076e4393d832e  vmovaps xmm4, [rsp+0x40]
000076e4393d8334  vmovaps xmm6, [rsp+0x50]
000076e4393d833a  vmovaps xmm7, [rsp+0x60]
000076e4393d8340  vmovaps xmm8, [rsp+0x70]
000076e4393d8346  vmovaps xmm9, [rsp+0x80]
000076e4393d834f  vmovaps xmm10, [rsp+0x90]
000076e4393d8358  vmovaps xmm11, [rsp+0xA0]
000076e4393d8361  vmovaps xmm12, [rsp+0xB0]
000076e4393d836a  vmovaps xmm13, [rsp+0xC0]
000076e4393d8373  vmovaps xmm14, [rsp+0xD0]
000076e4393d837c  vmovaps xmm15, [rsp+0xE0]
000076e4393d8385  add rsp, 0xF0
000076e4393d838c  pop r11
000076e4393d838e  pop r10
000076e4393d8390  pop r9
000076e4393d8392  pop r8
000076e4393d8394  pop rsi
000076e4393d8395  pop rdi
000076e4393d8396  pop rdx
000076e4393d8397  pop rcx
000076e4393d8398  pop rax
000076e4393d8399  add rsp, 0x08
000076e4393d839d  jmp 0x000076E4393D5F87
000076e4393d83a2  sub rsp, 0x08
000076e4393d83a6  push rax
000076e4393d83a7  push rcx
000076e4393d83a8  push rdx
000076e4393d83a9  push rdi
000076e4393d83aa  push rsi
000076e4393d83ab  push r8
000076e4393d83ad  push r9
000076e4393d83af  push r10
000076e4393d83b1  push r11
000076e4393d83b3  sub rsp, 0xF0
000076e4393d83ba  vmovaps [rsp], xmm0
000076e4393d83bf  vmovaps [rsp+0x10], xmm1
000076e4393d83c5  vmovaps [rsp+0x20], xmm2
000076e4393d83cb  vmovaps [rsp+0x30], xmm3
000076e4393d83d1  vmovaps [rsp+0x40], xmm4
000076e4393d83d7  vmovaps [rsp+0x50], xmm5
000076e4393d83dd  vmovaps [rsp+0x60], xmm7
000076e4393d83e3  vmovaps [rsp+0x70], xmm8
000076e4393d83e9  vmovaps [rsp+0x80], xmm9
000076e4393d83f2  vmovaps [rsp+0x90], xmm10
000076e4393d83fb  vmovaps [rsp+0xA0], xmm11
000076e4393d8404  vmovaps [rsp+0xB0], xmm12
000076e4393d840d  vmovaps [rsp+0xC0], xmm13
000076e4393d8416  vmovaps [rsp+0xD0], xmm14
000076e4393d841f  vmovaps [rsp+0xE0], xmm15
000076e4393d8428  sub rsp, 0x30
000076e4393d842c  movaps [rsp], xmm6
000076e4393d8430  movaps [rsp+0x10], xmm9
000076e4393d8436  movaps [rsp+0x20], xmm1
000076e4393d843b  lea rdi, [rsp]
000076e4393d843f  mov esi, 0x00
000076e4393d8444  mov rax, 0x63DBDEB43530
000076e4393d844e  call rax
000076e4393d8450  movaps xmm6, [rsp]
000076e4393d8454  add rsp, 0x30
000076e4393d8458  vmovaps xmm0, [rsp]
000076e4393d845d  vmovaps xmm1, [rsp+0x10]
000076e4393d8463  vmovaps xmm2, [rsp+0x20]
000076e4393d8469  vmovaps xmm3, [rsp+0x30]
000076e4393d846f  vmovaps xmm4, [rsp+0x40]
000076e4393d8475  vmovaps xmm5, [rsp+0x50]
000076e4393d847b  vmovaps xmm7, [rsp+0x60]
000076e4393d8481  vmovaps xmm8, [rsp+0x70]
000076e4393d8487  vmovaps xmm9, [rsp+0x80]
000076e4393d8490  vmovaps xmm10, [rsp+0x90]
000076e4393d8499  vmovaps xmm11, [rsp+0xA0]
000076e4393d84a2  vmovaps xmm12, [rsp+0xB0]
000076e4393d84ab  vmovaps xmm13, [rsp+0xC0]
000076e4393d84b4  vmovaps xmm14, [rsp+0xD0]
000076e4393d84bd  vmovaps xmm15, [rsp+0xE0]
000076e4393d84c6  add rsp, 0xF0
000076e4393d84cd  pop r11
000076e4393d84cf  pop r10
000076e4393d84d1  pop r9
000076e4393d84d3  pop r8
000076e4393d84d5  pop rsi
000076e4393d84d6  pop rdi
000076e4393d84d7  pop rdx
000076e4393d84d8  pop rcx
000076e4393d84d9  pop rax
000076e4393d84da  add rsp, 0x08
000076e4393d84de  jmp 0x000076E4393D5FAB
000076e4393d84e3  sub rsp, 0x08
000076e4393d84e7  push rax
000076e4393d84e8  push rcx
000076e4393d84e9  push rdx
000076e4393d84ea  push rdi
000076e4393d84eb  push rsi
000076e4393d84ec  push r8
000076e4393d84ee  push r9
000076e4393d84f0  push r10
000076e4393d84f2  push r11
000076e4393d84f4  sub rsp, 0xF0
000076e4393d84fb  vmovaps [rsp], xmm0
000076e4393d8500  vmovaps [rsp+0x10], xmm1
000076e4393d8506  vmovaps [rsp+0x20], xmm2
000076e4393d850c  vmovaps [rsp+0x30], xmm3
000076e4393d8512  vmovaps [rsp+0x40], xmm4
000076e4393d8518  vmovaps [rsp+0x50], xmm5
000076e4393d851e  vmovaps [rsp+0x60], xmm6
000076e4393d8524  vmovaps [rsp+0x70], xmm7
000076e4393d852a  vmovaps [rsp+0x80], xmm8
000076e4393d8533  vmovaps [rsp+0x90], xmm10
000076e4393d853c  vmovaps [rsp+0xA0], xmm11
000076e4393d8545  vmovaps [rsp+0xB0], xmm12
000076e4393d854e  vmovaps [rsp+0xC0], xmm13
000076e4393d8557  vmovaps [rsp+0xD0], xmm14
000076e4393d8560  vmovaps [rsp+0xE0], xmm15
000076e4393d8569  sub rsp, 0x30
000076e4393d856d  movaps [rsp], xmm9
000076e4393d8572  movaps [rsp+0x10], xmm3
000076e4393d8577  movaps [rsp+0x20], xmm1
000076e4393d857c  lea rdi, [rsp]
000076e4393d8580  mov esi, 0x00
000076e4393d8585  mov rax, 0x63DBDEB43530
000076e4393d858f  call rax
000076e4393d8591  movaps xmm9, [rsp]
000076e4393d8596  add rsp, 0x30
000076e4393d859a  vmovaps xmm0, [rsp]
000076e4393d859f  vmovaps xmm1, [rsp+0x10]
000076e4393d85a5  vmovaps xmm2, [rsp+0x20]
000076e4393d85ab  vmovaps xmm3, [rsp+0x30]
000076e4393d85b1  vmovaps xmm4, [rsp+0x40]
000076e4393d85b7  vmovaps xmm5, [rsp+0x50]
000076e4393d85bd  vmovaps xmm6, [rsp+0x60]
000076e4393d85c3  vmovaps xmm7, [rsp+0x70]
000076e4393d85c9  vmovaps xmm8, [rsp+0x80]
000076e4393d85d2  vmovaps xmm10, [rsp+0x90]
000076e4393d85db  vmovaps xmm11, [rsp+0xA0]
000076e4393d85e4  vmovaps xmm12, [rsp+0xB0]
000076e4393d85ed  vmovaps xmm13, [rsp+0xC0]
000076e4393d85f6  vmovaps xmm14, [rsp+0xD0]
000076e4393d85ff  vmovaps xmm15, [rsp+0xE0]
000076e4393d8608  add rsp, 0xF0
000076e4393d860f  pop r11
000076e4393d8611  pop r10
000076e4393d8613  pop r9
000076e4393d8615  pop r8
000076e4393d8617  pop rsi
000076e4393d8618  pop rdi
000076e4393d8619  pop rdx
000076e4393d861a  pop rcx
000076e4393d861b  pop rax
000076e4393d861c  add rsp, 0x08
000076e4393d8620  jmp 0x000076E4393D5FF7
000076e4393d8625  call 0x000076E4392D64F0
000076e4393d862a  jmp 0x000076E4393D6004
000076e4393d862f  sub rsp, 0x08
000076e4393d8633  push rax
000076e4393d8634  push rcx
000076e4393d8635  push rdx
000076e4393d8636  push rdi
000076e4393d8637  push rsi
000076e4393d8638  push r8
000076e4393d863a  push r9
000076e4393d863c  push r10
000076e4393d863e  push r11
000076e4393d8640  sub rsp, 0xF0
000076e4393d8647  vmovaps [rsp], xmm0
000076e4393d864c  vmovaps [rsp+0x10], xmm1
000076e4393d8652  vmovaps [rsp+0x20], xmm2
000076e4393d8658  vmovaps [rsp+0x30], xmm3
000076e4393d865e  vmovaps [rsp+0x40], xmm4
000076e4393d8664  vmovaps [rsp+0x50], xmm5
000076e4393d866a  vmovaps [rsp+0x60], xmm6
000076e4393d8670  vmovaps [rsp+0x70], xmm7
000076e4393d8676  vmovaps [rsp+0x80], xmm8
000076e4393d867f  vmovaps [rsp+0x90], xmm9
000076e4393d8688  vmovaps [rsp+0xA0], xmm10
000076e4393d8691  vmovaps [rsp+0xB0], xmm11
000076e4393d869a  vmovaps [rsp+0xC0], xmm12
000076e4393d86a3  vmovaps [rsp+0xD0], xmm13
000076e4393d86ac  vmovaps [rsp+0xE0], xmm14
000076e4393d86b5  sub rsp, 0x30
000076e4393d86b9  movaps [rsp], xmm15
000076e4393d86be  movaps [rsp+0x10], xmm3
000076e4393d86c3  movaps [rsp+0x20], xmm7
000076e4393d86c8  lea rdi, [rsp]
000076e4393d86cc  mov esi, 0x00
000076e4393d86d1  mov rax, 0x63DBDEB43530
000076e4393d86db  call rax
000076e4393d86dd  movaps xmm15, [rsp]
000076e4393d86e2  add rsp, 0x30
000076e4393d86e6  vmovaps xmm0, [rsp]
000076e4393d86eb  vmovaps xmm1, [rsp+0x10]
000076e4393d86f1  vmovaps xmm2, [rsp+0x20]
000076e4393d86f7  vmovaps xmm3, [rsp+0x30]
000076e4393d86fd  vmovaps xmm4, [rsp+0x40]
000076e4393d8703  vmovaps xmm5, [rsp+0x50]
000076e4393d8709  vmovaps xmm6, [rsp+0x60]
000076e4393d870f  vmovaps xmm7, [rsp+0x70]
000076e4393d8715  vmovaps xmm8, [rsp+0x80]
000076e4393d871e  vmovaps xmm9, [rsp+0x90]
000076e4393d8727  vmovaps xmm10, [rsp+0xA0]
000076e4393d8730  vmovaps xmm11, [rsp+0xB0]
000076e4393d8739  vmovaps xmm12, [rsp+0xC0]
000076e4393d8742  vmovaps xmm13, [rsp+0xD0]
000076e4393d874b  vmovaps xmm14, [rsp+0xE0]
000076e4393d8754  add rsp, 0xF0
000076e4393d875b  pop r11
000076e4393d875d  pop r10
000076e4393d875f  pop r9
000076e4393d8761  pop r8
000076e4393d8763  pop rsi
000076e4393d8764  pop rdi
000076e4393d8765  pop rdx
000076e4393d8766  pop rcx
000076e4393d8767  pop rax
000076e4393d8768  add rsp, 0x08
000076e4393d876c  jmp 0x000076E4393D6030
000076e4393d8771  sub rsp, 0x08
000076e4393d8775  push rax
000076e4393d8776  push rcx
000076e4393d8777  push rdx
000076e4393d8778  push rdi
000076e4393d8779  push rsi
000076e4393d877a  push r8
000076e4393d877c  push r9
000076e4393d877e  push r10
000076e4393d8780  push r11
000076e4393d8782  sub rsp, 0xF0
000076e4393d8789  vmovaps [rsp], xmm0
000076e4393d878e  vmovaps [rsp+0x10], xmm1
000076e4393d8794  vmovaps [rsp+0x20], xmm2
000076e4393d879a  vmovaps [rsp+0x30], xmm4
000076e4393d87a0  vmovaps [rsp+0x40], xmm5
000076e4393d87a6  vmovaps [rsp+0x50], xmm6
000076e4393d87ac  vmovaps [rsp+0x60], xmm7
000076e4393d87b2  vmovaps [rsp+0x70], xmm8
000076e4393d87b8  vmovaps [rsp+0x80], xmm9
000076e4393d87c1  vmovaps [rsp+0x90], xmm10
000076e4393d87ca  vmovaps [rsp+0xA0], xmm11
000076e4393d87d3  vmovaps [rsp+0xB0], xmm12
000076e4393d87dc  vmovaps [rsp+0xC0], xmm13
000076e4393d87e5  vmovaps [rsp+0xD0], xmm14
000076e4393d87ee  vmovaps [rsp+0xE0], xmm15
000076e4393d87f7  sub rsp, 0x30
000076e4393d87fb  movaps [rsp], xmm3
000076e4393d87ff  movaps [rsp+0x10], xmm1
000076e4393d8804  movaps [rsp+0x20], xmm15
000076e4393d880a  lea rdi, [rsp]
000076e4393d880e  mov esi, 0x00
000076e4393d8813  mov rax, 0x63DBDEB43530
000076e4393d881d  call rax
000076e4393d881f  movaps xmm3, [rsp]
000076e4393d8823  add rsp, 0x30
000076e4393d8827  vmovaps xmm0, [rsp]
000076e4393d882c  vmovaps xmm1, [rsp+0x10]
000076e4393d8832  vmovaps xmm2, [rsp+0x20]
000076e4393d8838  vmovaps xmm4, [rsp+0x30]
000076e4393d883e  vmovaps xmm5, [rsp+0x40]
000076e4393d8844  vmovaps xmm6, [rsp+0x50]
000076e4393d884a  vmovaps xmm7, [rsp+0x60]
000076e4393d8850  vmovaps xmm8, [rsp+0x70]
000076e4393d8856  vmovaps xmm9, [rsp+0x80]
000076e4393d885f  vmovaps xmm10, [rsp+0x90]
000076e4393d8868  vmovaps xmm11, [rsp+0xA0]
000076e4393d8871  vmovaps xmm12, [rsp+0xB0]
000076e4393d887a  vmovaps xmm13, [rsp+0xC0]
000076e4393d8883  vmovaps xmm14, [rsp+0xD0]
000076e4393d888c  vmovaps xmm15, [rsp+0xE0]
000076e4393d8895  add rsp, 0xF0
000076e4393d889c  pop r11
000076e4393d889e  pop r10
000076e4393d88a0  pop r9
000076e4393d88a2  pop r8
000076e4393d88a4  pop rsi
000076e4393d88a5  pop rdi
000076e4393d88a6  pop rdx
000076e4393d88a7  pop rcx
000076e4393d88a8  pop rax
000076e4393d88a9  add rsp, 0x08
000076e4393d88ad  jmp 0x000076E4393D60BF
000076e4393d88b2  call 0x000076E4392D64F0
000076e4393d88b7  jmp 0x000076E4393D60C9
000076e4393d88bc  sub rsp, 0x08
000076e4393d88c0  push rax
000076e4393d88c1  push rcx
000076e4393d88c2  push rdx
000076e4393d88c3  push rdi
000076e4393d88c4  push rsi
000076e4393d88c5  push r8
000076e4393d88c7  push r9
000076e4393d88c9  push r10
000076e4393d88cb  push r11
000076e4393d88cd  sub rsp, 0xF0
000076e4393d88d4  vmovaps [rsp], xmm0
000076e4393d88d9  vmovaps [rsp+0x10], xmm1
000076e4393d88df  vmovaps [rsp+0x20], xmm2
000076e4393d88e5  vmovaps [rsp+0x30], xmm3
000076e4393d88eb  vmovaps [rsp+0x40], xmm4
000076e4393d88f1  vmovaps [rsp+0x50], xmm5
000076e4393d88f7  vmovaps [rsp+0x60], xmm6
000076e4393d88fd  vmovaps [rsp+0x70], xmm7
000076e4393d8903  vmovaps [rsp+0x80], xmm8
000076e4393d890c  vmovaps [rsp+0x90], xmm9
000076e4393d8915  vmovaps [rsp+0xA0], xmm10
000076e4393d891e  vmovaps [rsp+0xB0], xmm11
000076e4393d8927  vmovaps [rsp+0xC0], xmm12
000076e4393d8930  vmovaps [rsp+0xD0], xmm13
000076e4393d8939  vmovaps [rsp+0xE0], xmm14
000076e4393d8942  sub rsp, 0x30
000076e4393d8946  movaps [rsp], xmm15
000076e4393d894b  movaps [rsp+0x10], xmm14
000076e4393d8951  movaps [rsp+0x20], xmm4
000076e4393d8956  lea rdi, [rsp]
000076e4393d895a  mov esi, 0x00
000076e4393d895f  mov rax, 0x63DBDEB43530
000076e4393d8969  call rax
000076e4393d896b  movaps xmm15, [rsp]
000076e4393d8970  add rsp, 0x30
000076e4393d8974  vmovaps xmm0, [rsp]
000076e4393d8979  vmovaps xmm1, [rsp+0x10]
000076e4393d897f  vmovaps xmm2, [rsp+0x20]
000076e4393d8985  vmovaps xmm3, [rsp+0x30]
000076e4393d898b  vmovaps xmm4, [rsp+0x40]
000076e4393d8991  vmovaps xmm5, [rsp+0x50]
000076e4393d8997  vmovaps xmm6, [rsp+0x60]
000076e4393d899d  vmovaps xmm7, [rsp+0x70]
000076e4393d89a3  vmovaps xmm8, [rsp+0x80]
000076e4393d89ac  vmovaps xmm9, [rsp+0x90]
000076e4393d89b5  vmovaps xmm10, [rsp+0xA0]
000076e4393d89be  vmovaps xmm11, [rsp+0xB0]
000076e4393d89c7  vmovaps xmm12, [rsp+0xC0]
000076e4393d89d0  vmovaps xmm13, [rsp+0xD0]
000076e4393d89d9  vmovaps xmm14, [rsp+0xE0]
000076e4393d89e2  add rsp, 0xF0
000076e4393d89e9  pop r11
000076e4393d89eb  pop r10
000076e4393d89ed  pop r9
000076e4393d89ef  pop r8
000076e4393d89f1  pop rsi
000076e4393d89f2  pop rdi
000076e4393d89f3  pop rdx
000076e4393d89f4  pop rcx
000076e4393d89f5  pop rax
000076e4393d89f6  add rsp, 0x08
000076e4393d89fa  jmp 0x000076E4393D60F7
000076e4393d89ff  sub rsp, 0x08
000076e4393d8a03  push rax
000076e4393d8a04  push rcx
000076e4393d8a05  push rdx
000076e4393d8a06  push rdi
000076e4393d8a07  push rsi
000076e4393d8a08  push r8
000076e4393d8a0a  push r9
000076e4393d8a0c  push r10
000076e4393d8a0e  push r11
000076e4393d8a10  sub rsp, 0xF0
000076e4393d8a17  vmovaps [rsp], xmm0
000076e4393d8a1c  vmovaps [rsp+0x10], xmm1
000076e4393d8a22  vmovaps [rsp+0x20], xmm2
000076e4393d8a28  vmovaps [rsp+0x30], xmm3
000076e4393d8a2e  vmovaps [rsp+0x40], xmm4
000076e4393d8a34  vmovaps [rsp+0x50], xmm5
000076e4393d8a3a  vmovaps [rsp+0x60], xmm6
000076e4393d8a40  vmovaps [rsp+0x70], xmm7
000076e4393d8a46  vmovaps [rsp+0x80], xmm8
000076e4393d8a4f  vmovaps [rsp+0x90], xmm9
000076e4393d8a58  vmovaps [rsp+0xA0], xmm10
000076e4393d8a61  vmovaps [rsp+0xB0], xmm11
000076e4393d8a6a  vmovaps [rsp+0xC0], xmm12
000076e4393d8a73  vmovaps [rsp+0xD0], xmm13
000076e4393d8a7c  vmovaps [rsp+0xE0], xmm15
000076e4393d8a85  sub rsp, 0x30
000076e4393d8a89  movaps [rsp], xmm14
000076e4393d8a8e  movaps [rsp+0x10], xmm2
000076e4393d8a93  movaps [rsp+0x20], xmm1
000076e4393d8a98  lea rdi, [rsp]
000076e4393d8a9c  mov esi, 0x00
000076e4393d8aa1  mov rax, 0x63DBDEB43530
000076e4393d8aab  call rax
000076e4393d8aad  movaps xmm14, [rsp]
000076e4393d8ab2  add rsp, 0x30
000076e4393d8ab6  vmovaps xmm0, [rsp]
000076e4393d8abb  vmovaps xmm1, [rsp+0x10]
000076e4393d8ac1  vmovaps xmm2, [rsp+0x20]
000076e4393d8ac7  vmovaps xmm3, [rsp+0x30]
000076e4393d8acd  vmovaps xmm4, [rsp+0x40]
000076e4393d8ad3  vmovaps xmm5, [rsp+0x50]
000076e4393d8ad9  vmovaps xmm6, [rsp+0x60]
000076e4393d8adf  vmovaps xmm7, [rsp+0x70]
000076e4393d8ae5  vmovaps xmm8, [rsp+0x80]
000076e4393d8aee  vmovaps xmm9, [rsp+0x90]
000076e4393d8af7  vmovaps xmm10, [rsp+0xA0]
000076e4393d8b00  vmovaps xmm11, [rsp+0xB0]
000076e4393d8b09  vmovaps xmm12, [rsp+0xC0]
000076e4393d8b12  vmovaps xmm13, [rsp+0xD0]
000076e4393d8b1b  vmovaps xmm15, [rsp+0xE0]
000076e4393d8b24  add rsp, 0xF0
000076e4393d8b2b  pop r11
000076e4393d8b2d  pop r10
000076e4393d8b2f  pop r9
000076e4393d8b31  pop r8
000076e4393d8b33  pop rsi
000076e4393d8b34  pop rdi
000076e4393d8b35  pop rdx
000076e4393d8b36  pop rcx
000076e4393d8b37  pop rax
000076e4393d8b38  add rsp, 0x08
000076e4393d8b3c  jmp 0x000076E4393D611D
000076e4393d8b41  sub rsp, 0x08
000076e4393d8b45  push rax
000076e4393d8b46  push rcx
000076e4393d8b47  push rdx
000076e4393d8b48  push rdi
000076e4393d8b49  push rsi
000076e4393d8b4a  push r8
000076e4393d8b4c  push r9
000076e4393d8b4e  push r10
000076e4393d8b50  push r11
000076e4393d8b52  sub rsp, 0xF0
000076e4393d8b59  vmovaps [rsp], xmm0
000076e4393d8b5e  vmovaps [rsp+0x10], xmm2
000076e4393d8b64  vmovaps [rsp+0x20], xmm3
000076e4393d8b6a  vmovaps [rsp+0x30], xmm4
000076e4393d8b70  vmovaps [rsp+0x40], xmm5
000076e4393d8b76  vmovaps [rsp+0x50], xmm6
000076e4393d8b7c  vmovaps [rsp+0x60], xmm7
000076e4393d8b82  vmovaps [rsp+0x70], xmm8
000076e4393d8b88  vmovaps [rsp+0x80], xmm9
000076e4393d8b91  vmovaps [rsp+0x90], xmm10
000076e4393d8b9a  vmovaps [rsp+0xA0], xmm11
000076e4393d8ba3  vmovaps [rsp+0xB0], xmm12
000076e4393d8bac  vmovaps [rsp+0xC0], xmm13
000076e4393d8bb5  vmovaps [rsp+0xD0], xmm14
000076e4393d8bbe  vmovaps [rsp+0xE0], xmm15
000076e4393d8bc7  sub rsp, 0x30
000076e4393d8bcb  movaps [rsp], xmm1
000076e4393d8bcf  movaps [rsp+0x10], xmm4
000076e4393d8bd4  movaps [rsp+0x20], xmm9
000076e4393d8bda  lea rdi, [rsp]
000076e4393d8bde  mov esi, 0x00
000076e4393d8be3  mov rax, 0x63DBDEB43530
000076e4393d8bed  call rax
000076e4393d8bef  movaps xmm1, [rsp]
000076e4393d8bf3  add rsp, 0x30
000076e4393d8bf7  vmovaps xmm0, [rsp]
000076e4393d8bfc  vmovaps xmm2, [rsp+0x10]
000076e4393d8c02  vmovaps xmm3, [rsp+0x20]
000076e4393d8c08  vmovaps xmm4, [rsp+0x30]
000076e4393d8c0e  vmovaps xmm5, [rsp+0x40]
000076e4393d8c14  vmovaps xmm6, [rsp+0x50]
000076e4393d8c1a  vmovaps xmm7, [rsp+0x60]
000076e4393d8c20  vmovaps xmm8, [rsp+0x70]
000076e4393d8c26  vmovaps xmm9, [rsp+0x80]
000076e4393d8c2f  vmovaps xmm10, [rsp+0x90]
000076e4393d8c38  vmovaps xmm11, [rsp+0xA0]
000076e4393d8c41  vmovaps xmm12, [rsp+0xB0]
000076e4393d8c4a  vmovaps xmm13, [rsp+0xC0]
000076e4393d8c53  vmovaps xmm14, [rsp+0xD0]
000076e4393d8c5c  vmovaps xmm15, [rsp+0xE0]
000076e4393d8c65  add rsp, 0xF0
000076e4393d8c6c  pop r11
000076e4393d8c6e  pop r10
000076e4393d8c70  pop r9
000076e4393d8c72  pop r8
000076e4393d8c74  pop rsi
000076e4393d8c75  pop rdi
000076e4393d8c76  pop rdx
000076e4393d8c77  pop rcx
000076e4393d8c78  pop rax
000076e4393d8c79  add rsp, 0x08
000076e4393d8c7d  jmp 0x000076E4393D613B
000076e4393d8c82  sub rsp, 0x08
000076e4393d8c86  push rax
000076e4393d8c87  push rcx
000076e4393d8c88  push rdx
000076e4393d8c89  push rdi
000076e4393d8c8a  push rsi
000076e4393d8c8b  push r8
000076e4393d8c8d  push r9
000076e4393d8c8f  push r10
000076e4393d8c91  push r11
000076e4393d8c93  sub rsp, 0xF0
000076e4393d8c9a  vmovaps [rsp], xmm0
000076e4393d8c9f  vmovaps [rsp+0x10], xmm1
000076e4393d8ca5  vmovaps [rsp+0x20], xmm2
000076e4393d8cab  vmovaps [rsp+0x30], xmm3
000076e4393d8cb1  vmovaps [rsp+0x40], xmm5
000076e4393d8cb7  vmovaps [rsp+0x50], xmm6
000076e4393d8cbd  vmovaps [rsp+0x60], xmm7
000076e4393d8cc3  vmovaps [rsp+0x70], xmm8
000076e4393d8cc9  vmovaps [rsp+0x80], xmm9
000076e4393d8cd2  vmovaps [rsp+0x90], xmm10
000076e4393d8cdb  vmovaps [rsp+0xA0], xmm11
000076e4393d8ce4  vmovaps [rsp+0xB0], xmm12
000076e4393d8ced  vmovaps [rsp+0xC0], xmm13
000076e4393d8cf6  vmovaps [rsp+0xD0], xmm14
000076e4393d8cff  vmovaps [rsp+0xE0], xmm15
000076e4393d8d08  sub rsp, 0x30
000076e4393d8d0c  movaps [rsp], xmm4
000076e4393d8d10  movaps [rsp+0x10], xmm2
000076e4393d8d15  movaps [rsp+0x20], xmm9
000076e4393d8d1b  lea rdi, [rsp]
000076e4393d8d1f  mov esi, 0x00
000076e4393d8d24  mov rax, 0x63DBDEB43530
000076e4393d8d2e  call rax
000076e4393d8d30  movaps xmm4, [rsp]
000076e4393d8d34  add rsp, 0x30
000076e4393d8d38  vmovaps xmm0, [rsp]
000076e4393d8d3d  vmovaps xmm1, [rsp+0x10]
000076e4393d8d43  vmovaps xmm2, [rsp+0x20]
000076e4393d8d49  vmovaps xmm3, [rsp+0x30]
000076e4393d8d4f  vmovaps xmm5, [rsp+0x40]
000076e4393d8d55  vmovaps xmm6, [rsp+0x50]
000076e4393d8d5b  vmovaps xmm7, [rsp+0x60]
000076e4393d8d61  vmovaps xmm8, [rsp+0x70]
000076e4393d8d67  vmovaps xmm9, [rsp+0x80]
000076e4393d8d70  vmovaps xmm10, [rsp+0x90]
000076e4393d8d79  vmovaps xmm11, [rsp+0xA0]
000076e4393d8d82  vmovaps xmm12, [rsp+0xB0]
000076e4393d8d8b  vmovaps xmm13, [rsp+0xC0]
000076e4393d8d94  vmovaps xmm14, [rsp+0xD0]
000076e4393d8d9d  vmovaps xmm15, [rsp+0xE0]
000076e4393d8da6  add rsp, 0xF0
000076e4393d8dad  pop r11
000076e4393d8daf  pop r10
000076e4393d8db1  pop r9
000076e4393d8db3  pop r8
000076e4393d8db5  pop rsi
000076e4393d8db6  pop rdi
000076e4393d8db7  pop rdx
000076e4393d8db8  pop rcx
000076e4393d8db9  pop rax
000076e4393d8dba  add rsp, 0x08
000076e4393d8dbe  jmp 0x000076E4393D616B
000076e4393d8dc3  sub rsp, 0x08
000076e4393d8dc7  push rax
000076e4393d8dc8  push rcx
000076e4393d8dc9  push rdx
000076e4393d8dca  push rdi
000076e4393d8dcb  push rsi
000076e4393d8dcc  push r8
000076e4393d8dce  push r9
000076e4393d8dd0  push r10
000076e4393d8dd2  push r11
000076e4393d8dd4  sub rsp, 0xF0
000076e4393d8ddb  vmovaps [rsp], xmm0
000076e4393d8de0  vmovaps [rsp+0x10], xmm1
000076e4393d8de6  vmovaps [rsp+0x20], xmm2
000076e4393d8dec  vmovaps [rsp+0x30], xmm3
000076e4393d8df2  vmovaps [rsp+0x40], xmm4
000076e4393d8df8  vmovaps [rsp+0x50], xmm5
000076e4393d8dfe  vmovaps [rsp+0x60], xmm6
000076e4393d8e04  vmovaps [rsp+0x70], xmm7
000076e4393d8e0a  vmovaps [rsp+0x80], xmm8
000076e4393d8e13  vmovaps [rsp+0x90], xmm10
000076e4393d8e1c  vmovaps [rsp+0xA0], xmm11
000076e4393d8e25  vmovaps [rsp+0xB0], xmm12
000076e4393d8e2e  vmovaps [rsp+0xC0], xmm13
000076e4393d8e37  vmovaps [rsp+0xD0], xmm14
000076e4393d8e40  vmovaps [rsp+0xE0], xmm15
000076e4393d8e49  sub rsp, 0x30
000076e4393d8e4d  movaps [rsp], xmm9
000076e4393d8e52  movaps [rsp+0x10], xmm2
000076e4393d8e57  movaps [rsp+0x20], xmm1
000076e4393d8e5c  lea rdi, [rsp]
000076e4393d8e60  mov esi, 0x00
000076e4393d8e65  mov rax, 0x63DBDEB43530
000076e4393d8e6f  call rax
000076e4393d8e71  movaps xmm9, [rsp]
000076e4393d8e76  add rsp, 0x30
000076e4393d8e7a  vmovaps xmm0, [rsp]
000076e4393d8e7f  vmovaps xmm1, [rsp+0x10]
000076e4393d8e85  vmovaps xmm2, [rsp+0x20]
000076e4393d8e8b  vmovaps xmm3, [rsp+0x30]
000076e4393d8e91  vmovaps xmm4, [rsp+0x40]
000076e4393d8e97  vmovaps xmm5, [rsp+0x50]
000076e4393d8e9d  vmovaps xmm6, [rsp+0x60]
000076e4393d8ea3  vmovaps xmm7, [rsp+0x70]
000076e4393d8ea9  vmovaps xmm8, [rsp+0x80]
000076e4393d8eb2  vmovaps xmm10, [rsp+0x90]
000076e4393d8ebb  vmovaps xmm11, [rsp+0xA0]
000076e4393d8ec4  vmovaps xmm12, [rsp+0xB0]
000076e4393d8ecd  vmovaps xmm13, [rsp+0xC0]
000076e4393d8ed6  vmovaps xmm14, [rsp+0xD0]
000076e4393d8edf  vmovaps xmm15, [rsp+0xE0]
000076e4393d8ee8  add rsp, 0xF0
000076e4393d8eef  pop r11
000076e4393d8ef1  pop r10
000076e4393d8ef3  pop r9
000076e4393d8ef5  pop r8
000076e4393d8ef7  pop rsi
000076e4393d8ef8  pop rdi
000076e4393d8ef9  pop rdx
000076e4393d8efa  pop rcx
000076e4393d8efb  pop rax
000076e4393d8efc  add rsp, 0x08
000076e4393d8f00  jmp 0x000076E4393D61A1
000076e4393d8f05  sub rsp, 0x08
000076e4393d8f09  push rax
000076e4393d8f0a  push rcx
000076e4393d8f0b  push rdx
000076e4393d8f0c  push rdi
000076e4393d8f0d  push rsi
000076e4393d8f0e  push r8
000076e4393d8f10  push r9
000076e4393d8f12  push r10
000076e4393d8f14  push r11
000076e4393d8f16  sub rsp, 0xF0
000076e4393d8f1d  vmovaps [rsp], xmm0
000076e4393d8f22  vmovaps [rsp+0x10], xmm2
000076e4393d8f28  vmovaps [rsp+0x20], xmm3
000076e4393d8f2e  vmovaps [rsp+0x30], xmm4
000076e4393d8f34  vmovaps [rsp+0x40], xmm5
000076e4393d8f3a  vmovaps [rsp+0x50], xmm6
000076e4393d8f40  vmovaps [rsp+0x60], xmm7
000076e4393d8f46  vmovaps [rsp+0x70], xmm8
000076e4393d8f4c  vmovaps [rsp+0x80], xmm9
000076e4393d8f55  vmovaps [rsp+0x90], xmm10
000076e4393d8f5e  vmovaps [rsp+0xA0], xmm11
000076e4393d8f67  vmovaps [rsp+0xB0], xmm12
000076e4393d8f70  vmovaps [rsp+0xC0], xmm13
000076e4393d8f79  vmovaps [rsp+0xD0], xmm14
000076e4393d8f82  vmovaps [rsp+0xE0], xmm15
000076e4393d8f8b  sub rsp, 0x30
000076e4393d8f8f  movaps [rsp], xmm1
000076e4393d8f93  movaps [rsp+0x10], xmm15
000076e4393d8f99  movaps [rsp+0x20], xmm6
000076e4393d8f9e  lea rdi, [rsp]
000076e4393d8fa2  mov esi, 0x00
000076e4393d8fa7  mov rax, 0x63DBDEB43530
000076e4393d8fb1  call rax
000076e4393d8fb3  movaps xmm1, [rsp]
000076e4393d8fb7  add rsp, 0x30
000076e4393d8fbb  vmovaps xmm0, [rsp]
000076e4393d8fc0  vmovaps xmm2, [rsp+0x10]
000076e4393d8fc6  vmovaps xmm3, [rsp+0x20]
000076e4393d8fcc  vmovaps xmm4, [rsp+0x30]
000076e4393d8fd2  vmovaps xmm5, [rsp+0x40]
000076e4393d8fd8  vmovaps xmm6, [rsp+0x50]
000076e4393d8fde  vmovaps xmm7, [rsp+0x60]
000076e4393d8fe4  vmovaps xmm8, [rsp+0x70]
000076e4393d8fea  vmovaps xmm9, [rsp+0x80]
000076e4393d8ff3  vmovaps xmm10, [rsp+0x90]
000076e4393d8ffc  vmovaps xmm11, [rsp+0xA0]
000076e4393d9005  vmovaps xmm12, [rsp+0xB0]
000076e4393d900e  vmovaps xmm13, [rsp+0xC0]
000076e4393d9017  vmovaps xmm14, [rsp+0xD0]
000076e4393d9020  vmovaps xmm15, [rsp+0xE0]
000076e4393d9029  add rsp, 0xF0
000076e4393d9030  pop r11
000076e4393d9032  pop r10
000076e4393d9034  pop r9
000076e4393d9036  pop r8
000076e4393d9038  pop rsi
000076e4393d9039  pop rdi
000076e4393d903a  pop rdx
000076e4393d903b  pop rcx
000076e4393d903c  pop rax
000076e4393d903d  add rsp, 0x08
000076e4393d9041  jmp 0x000076E4393D61C2
000076e4393d9046  sub rsp, 0x08
000076e4393d904a  push rax
000076e4393d904b  push rcx
000076e4393d904c  push rdx
000076e4393d904d  push rdi
000076e4393d904e  push rsi
000076e4393d904f  push r8
000076e4393d9051  push r9
000076e4393d9053  push r10
000076e4393d9055  push r11
000076e4393d9057  sub rsp, 0xF0
000076e4393d905e  vmovaps [rsp], xmm0
000076e4393d9063  vmovaps [rsp+0x10], xmm1
000076e4393d9069  vmovaps [rsp+0x20], xmm2
000076e4393d906f  vmovaps [rsp+0x30], xmm3
000076e4393d9075  vmovaps [rsp+0x40], xmm4
000076e4393d907b  vmovaps [rsp+0x50], xmm5
000076e4393d9081  vmovaps [rsp+0x60], xmm6
000076e4393d9087  vmovaps [rsp+0x70], xmm7
000076e4393d908d  vmovaps [rsp+0x80], xmm8
000076e4393d9096  vmovaps [rsp+0x90], xmm9
000076e4393d909f  vmovaps [rsp+0xA0], xmm10
000076e4393d90a8  vmovaps [rsp+0xB0], xmm11
000076e4393d90b1  vmovaps [rsp+0xC0], xmm12
000076e4393d90ba  vmovaps [rsp+0xD0], xmm13
000076e4393d90c3  vmovaps [rsp+0xE0], xmm14
000076e4393d90cc  sub rsp, 0x30
000076e4393d90d0  movaps [rsp], xmm15
000076e4393d90d5  movaps [rsp+0x10], xmm5
000076e4393d90da  movaps [rsp+0x20], xmm3
000076e4393d90df  lea rdi, [rsp]
000076e4393d90e3  mov esi, 0x00
000076e4393d90e8  mov rax, 0x63DBDEB43530
000076e4393d90f2  call rax
000076e4393d90f4  movaps xmm15, [rsp]
000076e4393d90f9  add rsp, 0x30
000076e4393d90fd  vmovaps xmm0, [rsp]
000076e4393d9102  vmovaps xmm1, [rsp+0x10]
000076e4393d9108  vmovaps xmm2, [rsp+0x20]
000076e4393d910e  vmovaps xmm3, [rsp+0x30]
000076e4393d9114  vmovaps xmm4, [rsp+0x40]
000076e4393d911a  vmovaps xmm5, [rsp+0x50]
000076e4393d9120  vmovaps xmm6, [rsp+0x60]
000076e4393d9126  vmovaps xmm7, [rsp+0x70]
000076e4393d912c  vmovaps xmm8, [rsp+0x80]
000076e4393d9135  vmovaps xmm9, [rsp+0x90]
000076e4393d913e  vmovaps xmm10, [rsp+0xA0]
000076e4393d9147  vmovaps xmm11, [rsp+0xB0]
000076e4393d9150  vmovaps xmm12, [rsp+0xC0]
000076e4393d9159  vmovaps xmm13, [rsp+0xD0]
000076e4393d9162  vmovaps xmm14, [rsp+0xE0]
000076e4393d916b  add rsp, 0xF0
000076e4393d9172  pop r11
000076e4393d9174  pop r10
000076e4393d9176  pop r9
000076e4393d9178  pop r8
000076e4393d917a  pop rsi
000076e4393d917b  pop rdi
000076e4393d917c  pop rdx
000076e4393d917d  pop rcx
000076e4393d917e  pop rax
000076e4393d917f  add rsp, 0x08
000076e4393d9183  jmp 0x000076E4393D61DC
000076e4393d9188  sub rsp, 0x08
000076e4393d918c  push rax
000076e4393d918d  push rcx
000076e4393d918e  push rdx
000076e4393d918f  push rdi
000076e4393d9190  push rsi
000076e4393d9191  push r8
000076e4393d9193  push r9
000076e4393d9195  push r10
000076e4393d9197  push r11
000076e4393d9199  sub rsp, 0xF0
000076e4393d91a0  vmovaps [rsp], xmm0
000076e4393d91a5  vmovaps [rsp+0x10], xmm1
000076e4393d91ab  vmovaps [rsp+0x20], xmm2
000076e4393d91b1  vmovaps [rsp+0x30], xmm3
000076e4393d91b7  vmovaps [rsp+0x40], xmm4
000076e4393d91bd  vmovaps [rsp+0x50], xmm6
000076e4393d91c3  vmovaps [rsp+0x60], xmm7
000076e4393d91c9  vmovaps [rsp+0x70], xmm8
000076e4393d91cf  vmovaps [rsp+0x80], xmm9
000076e4393d91d8  vmovaps [rsp+0x90], xmm10
000076e4393d91e1  vmovaps [rsp+0xA0], xmm11
000076e4393d91ea  vmovaps [rsp+0xB0], xmm12
000076e4393d91f3  vmovaps [rsp+0xC0], xmm13
000076e4393d91fc  vmovaps [rsp+0xD0], xmm14
000076e4393d9205  vmovaps [rsp+0xE0], xmm15
000076e4393d920e  sub rsp, 0x30
000076e4393d9212  movaps [rsp], xmm5
000076e4393d9216  movaps [rsp+0x10], xmm8
000076e4393d921c  movaps [rsp+0x20], xmm6
000076e4393d9221  lea rdi, [rsp]
000076e4393d9225  mov esi, 0x00
000076e4393d922a  mov rax, 0x63DBDEB43530
000076e4393d9234  call rax
000076e4393d9236  movaps xmm5, [rsp]
000076e4393d923a  add rsp, 0x30
000076e4393d923e  vmovaps xmm0, [rsp]
000076e4393d9243  vmovaps xmm1, [rsp+0x10]
000076e4393d9249  vmovaps xmm2, [rsp+0x20]
000076e4393d924f  vmovaps xmm3, [rsp+0x30]
000076e4393d9255  vmovaps xmm4, [rsp+0x40]
000076e4393d925b  vmovaps xmm6, [rsp+0x50]
000076e4393d9261  vmovaps xmm7, [rsp+0x60]
000076e4393d9267  vmovaps xmm8, [rsp+0x70]
000076e4393d926d  vmovaps xmm9, [rsp+0x80]
000076e4393d9276  vmovaps xmm10, [rsp+0x90]
000076e4393d927f  vmovaps xmm11, [rsp+0xA0]
000076e4393d9288  vmovaps xmm12, [rsp+0xB0]
000076e4393d9291  vmovaps xmm13, [rsp+0xC0]
000076e4393d929a  vmovaps xmm14, [rsp+0xD0]
000076e4393d92a3  vmovaps xmm15, [rsp+0xE0]
000076e4393d92ac  add rsp, 0xF0
000076e4393d92b3  pop r11
000076e4393d92b5  pop r10
000076e4393d92b7  pop r9
000076e4393d92b9  pop r8
000076e4393d92bb  pop rsi
000076e4393d92bc  pop rdi
000076e4393d92bd  pop rdx
000076e4393d92be  pop rcx
000076e4393d92bf  pop rax
000076e4393d92c0  add rsp, 0x08
000076e4393d92c4  jmp 0x000076E4393D6200
000076e4393d92c9  sub rsp, 0x08
000076e4393d92cd  push rax
000076e4393d92ce  push rcx
000076e4393d92cf  push rdx
000076e4393d92d0  push rdi
000076e4393d92d1  push rsi
000076e4393d92d2  push r8
000076e4393d92d4  push r9
000076e4393d92d6  push r10
000076e4393d92d8  push r11
000076e4393d92da  sub rsp, 0xF0
000076e4393d92e1  vmovaps [rsp], xmm0
000076e4393d92e6  vmovaps [rsp+0x10], xmm1
000076e4393d92ec  vmovaps [rsp+0x20], xmm2
000076e4393d92f2  vmovaps [rsp+0x30], xmm3
000076e4393d92f8  vmovaps [rsp+0x40], xmm4
000076e4393d92fe  vmovaps [rsp+0x50], xmm5
000076e4393d9304  vmovaps [rsp+0x60], xmm7
000076e4393d930a  vmovaps [rsp+0x70], xmm8
000076e4393d9310  vmovaps [rsp+0x80], xmm9
000076e4393d9319  vmovaps [rsp+0x90], xmm10
000076e4393d9322  vmovaps [rsp+0xA0], xmm11
000076e4393d932b  vmovaps [rsp+0xB0], xmm12
000076e4393d9334  vmovaps [rsp+0xC0], xmm13
000076e4393d933d  vmovaps [rsp+0xD0], xmm14
000076e4393d9346  vmovaps [rsp+0xE0], xmm15
000076e4393d934f  sub rsp, 0x30
000076e4393d9353  movaps [rsp], xmm6
000076e4393d9357  movaps [rsp+0x10], xmm10
000076e4393d935d  movaps [rsp+0x20], xmm8
000076e4393d9363  lea rdi, [rsp]
000076e4393d9367  mov esi, 0x00
000076e4393d936c  mov rax, 0x63DBDEB43530
000076e4393d9376  call rax
000076e4393d9378  movaps xmm6, [rsp]
000076e4393d937c  add rsp, 0x30
000076e4393d9380  vmovaps xmm0, [rsp]
000076e4393d9385  vmovaps xmm1, [rsp+0x10]
000076e4393d938b  vmovaps xmm2, [rsp+0x20]
000076e4393d9391  vmovaps xmm3, [rsp+0x30]
000076e4393d9397  vmovaps xmm4, [rsp+0x40]
000076e4393d939d  vmovaps xmm5, [rsp+0x50]
000076e4393d93a3  vmovaps xmm7, [rsp+0x60]
000076e4393d93a9  vmovaps xmm8, [rsp+0x70]
000076e4393d93af  vmovaps xmm9, [rsp+0x80]
000076e4393d93b8  vmovaps xmm10, [rsp+0x90]
000076e4393d93c1  vmovaps xmm11, [rsp+0xA0]
000076e4393d93ca  vmovaps xmm12, [rsp+0xB0]
000076e4393d93d3  vmovaps xmm13, [rsp+0xC0]
000076e4393d93dc  vmovaps xmm14, [rsp+0xD0]
000076e4393d93e5  vmovaps xmm15, [rsp+0xE0]
000076e4393d93ee  add rsp, 0xF0
000076e4393d93f5  pop r11
000076e4393d93f7  pop r10
000076e4393d93f9  pop r9
000076e4393d93fb  pop r8
000076e4393d93fd  pop rsi
000076e4393d93fe  pop rdi
000076e4393d93ff  pop rdx
000076e4393d9400  pop rcx
000076e4393d9401  pop rax
000076e4393d9402  add rsp, 0x08
000076e4393d9406  jmp 0x000076E4393D6225
000076e4393d940b  sub rsp, 0x08
000076e4393d940f  push rax
000076e4393d9410  push rcx
000076e4393d9411  push rdx
000076e4393d9412  push rdi
000076e4393d9413  push rsi
000076e4393d9414  push r8
000076e4393d9416  push r9
000076e4393d9418  push r10
000076e4393d941a  push r11
000076e4393d941c  sub rsp, 0xF0
000076e4393d9423  vmovaps [rsp], xmm0
000076e4393d9428  vmovaps [rsp+0x10], xmm1
000076e4393d942e  vmovaps [rsp+0x20], xmm2
000076e4393d9434  vmovaps [rsp+0x30], xmm3
000076e4393d943a  vmovaps [rsp+0x40], xmm4
000076e4393d9440  vmovaps [rsp+0x50], xmm5
000076e4393d9446  vmovaps [rsp+0x60], xmm6
000076e4393d944c  vmovaps [rsp+0x70], xmm7
000076e4393d9452  vmovaps [rsp+0x80], xmm8
000076e4393d945b  vmovaps [rsp+0x90], xmm9
000076e4393d9464  vmovaps [rsp+0xA0], xmm11
000076e4393d946d  vmovaps [rsp+0xB0], xmm12
000076e4393d9476  vmovaps [rsp+0xC0], xmm13
000076e4393d947f  vmovaps [rsp+0xD0], xmm14
000076e4393d9488  vmovaps [rsp+0xE0], xmm15
000076e4393d9491  sub rsp, 0x30
000076e4393d9495  movaps [rsp], xmm10
000076e4393d949a  movaps [rsp+0x10], xmm8
000076e4393d94a0  movaps [rsp+0x20], xmm14
000076e4393d94a6  lea rdi, [rsp]
000076e4393d94aa  mov esi, 0x00
000076e4393d94af  mov rax, 0x63DBDEB43530
000076e4393d94b9  call rax
000076e4393d94bb  movaps xmm10, [rsp]
000076e4393d94c0  add rsp, 0x30
000076e4393d94c4  vmovaps xmm0, [rsp]
000076e4393d94c9  vmovaps xmm1, [rsp+0x10]
000076e4393d94cf  vmovaps xmm2, [rsp+0x20]
000076e4393d94d5  vmovaps xmm3, [rsp+0x30]
000076e4393d94db  vmovaps xmm4, [rsp+0x40]
000076e4393d94e1  vmovaps xmm5, [rsp+0x50]
000076e4393d94e7  vmovaps xmm6, [rsp+0x60]
000076e4393d94ed  vmovaps xmm7, [rsp+0x70]
000076e4393d94f3  vmovaps xmm8, [rsp+0x80]
000076e4393d94fc  vmovaps xmm9, [rsp+0x90]
000076e4393d9505  vmovaps xmm11, [rsp+0xA0]
000076e4393d950e  vmovaps xmm12, [rsp+0xB0]
000076e4393d9517  vmovaps xmm13, [rsp+0xC0]
000076e4393d9520  vmovaps xmm14, [rsp+0xD0]
000076e4393d9529  vmovaps xmm15, [rsp+0xE0]
000076e4393d9532  add rsp, 0xF0
000076e4393d9539  pop r11
000076e4393d953b  pop r10
000076e4393d953d  pop r9
000076e4393d953f  pop r8
000076e4393d9541  pop rsi
000076e4393d9542  pop rdi
000076e4393d9543  pop rdx
000076e4393d9544  pop rcx
000076e4393d9545  pop rax
000076e4393d9546  add rsp, 0x08
000076e4393d954a  jmp 0x000076E4393D6245
000076e4393d954f  sub rsp, 0x08
000076e4393d9553  push rax
000076e4393d9554  push rcx
000076e4393d9555  push rdx
000076e4393d9556  push rdi
000076e4393d9557  push rsi
000076e4393d9558  push r8
000076e4393d955a  push r9
000076e4393d955c  push r10
000076e4393d955e  push r11
000076e4393d9560  sub rsp, 0xF0
000076e4393d9567  vmovaps [rsp], xmm0
000076e4393d956c  vmovaps [rsp+0x10], xmm1
000076e4393d9572  vmovaps [rsp+0x20], xmm2
000076e4393d9578  vmovaps [rsp+0x30], xmm3
000076e4393d957e  vmovaps [rsp+0x40], xmm4
000076e4393d9584  vmovaps [rsp+0x50], xmm5
000076e4393d958a  vmovaps [rsp+0x60], xmm6
000076e4393d9590  vmovaps [rsp+0x70], xmm7
000076e4393d9596  vmovaps [rsp+0x80], xmm8
000076e4393d959f  vmovaps [rsp+0x90], xmm9
000076e4393d95a8  vmovaps [rsp+0xA0], xmm10
000076e4393d95b1  vmovaps [rsp+0xB0], xmm11
000076e4393d95ba  vmovaps [rsp+0xC0], xmm12
000076e4393d95c3  vmovaps [rsp+0xD0], xmm13
000076e4393d95cc  vmovaps [rsp+0xE0], xmm15
000076e4393d95d5  sub rsp, 0x30
000076e4393d95d9  movaps [rsp], xmm14
000076e4393d95de  movaps [rsp+0x10], xmm8
000076e4393d95e4  movaps [rsp+0x20], xmm4
000076e4393d95e9  lea rdi, [rsp]
000076e4393d95ed  mov esi, 0x00
000076e4393d95f2  mov rax, 0x63DBDEB43530
000076e4393d95fc  call rax
000076e4393d95fe  movaps xmm14, [rsp]
000076e4393d9603  add rsp, 0x30
000076e4393d9607  vmovaps xmm0, [rsp]
000076e4393d960c  vmovaps xmm1, [rsp+0x10]
000076e4393d9612  vmovaps xmm2, [rsp+0x20]
000076e4393d9618  vmovaps xmm3, [rsp+0x30]
000076e4393d961e  vmovaps xmm4, [rsp+0x40]
000076e4393d9624  vmovaps xmm5, [rsp+0x50]
000076e4393d962a  vmovaps xmm6, [rsp+0x60]
000076e4393d9630  vmovaps xmm7, [rsp+0x70]
000076e4393d9636  vmovaps xmm8, [rsp+0x80]
000076e4393d963f  vmovaps xmm9, [rsp+0x90]
000076e4393d9648  vmovaps xmm10, [rsp+0xA0]
000076e4393d9651  vmovaps xmm11, [rsp+0xB0]
000076e4393d965a  vmovaps xmm12, [rsp+0xC0]
000076e4393d9663  vmovaps xmm13, [rsp+0xD0]
000076e4393d966c  vmovaps xmm15, [rsp+0xE0]
000076e4393d9675  add rsp, 0xF0
000076e4393d967c  pop r11
000076e4393d967e  pop r10
000076e4393d9680  pop r9
000076e4393d9682  pop r8
000076e4393d9684  pop rsi
000076e4393d9685  pop rdi
000076e4393d9686  pop rdx
000076e4393d9687  pop rcx
000076e4393d9688  pop rax
000076e4393d9689  add rsp, 0x08
000076e4393d968d  jmp 0x000076E4393D6265
000076e4393d9692  sub rsp, 0x08
000076e4393d9696  push rax
000076e4393d9697  push rcx
000076e4393d9698  push rdx
000076e4393d9699  push rdi
000076e4393d969a  push rsi
000076e4393d969b  push r8
000076e4393d969d  push r9
000076e4393d969f  push r10
000076e4393d96a1  push r11
000076e4393d96a3  sub rsp, 0xF0
000076e4393d96aa  vmovaps [rsp], xmm0
000076e4393d96af  vmovaps [rsp+0x10], xmm1
000076e4393d96b5  vmovaps [rsp+0x20], xmm2
000076e4393d96bb  vmovaps [rsp+0x30], xmm3
000076e4393d96c1  vmovaps [rsp+0x40], xmm5
000076e4393d96c7  vmovaps [rsp+0x50], xmm6
000076e4393d96cd  vmovaps [rsp+0x60], xmm7
000076e4393d96d3  vmovaps [rsp+0x70], xmm8
000076e4393d96d9  vmovaps [rsp+0x80], xmm9
000076e4393d96e2  vmovaps [rsp+0x90], xmm10
000076e4393d96eb  vmovaps [rsp+0xA0], xmm11
000076e4393d96f4  vmovaps [rsp+0xB0], xmm12
000076e4393d96fd  vmovaps [rsp+0xC0], xmm13
000076e4393d9706  vmovaps [rsp+0xD0], xmm14
000076e4393d970f  vmovaps [rsp+0xE0], xmm15
000076e4393d9718  sub rsp, 0x30
000076e4393d971c  movaps [rsp], xmm4
000076e4393d9720  movaps [rsp+0x10], xmm13
000076e4393d9726  movaps [rsp+0x20], xmm8
000076e4393d972c  lea rdi, [rsp]
000076e4393d9730  mov esi, 0x00
000076e4393d9735  mov rax, 0x63DBDEB43530
000076e4393d973f  call rax
000076e4393d9741  movaps xmm4, [rsp]
000076e4393d9745  add rsp, 0x30
000076e4393d9749  vmovaps xmm0, [rsp]
000076e4393d974e  vmovaps xmm1, [rsp+0x10]
000076e4393d9754  vmovaps xmm2, [rsp+0x20]
000076e4393d975a  vmovaps xmm3, [rsp+0x30]
000076e4393d9760  vmovaps xmm5, [rsp+0x40]
000076e4393d9766  vmovaps xmm6, [rsp+0x50]
000076e4393d976c  vmovaps xmm7, [rsp+0x60]
000076e4393d9772  vmovaps xmm8, [rsp+0x70]
000076e4393d9778  vmovaps xmm9, [rsp+0x80]
000076e4393d9781  vmovaps xmm10, [rsp+0x90]
000076e4393d978a  vmovaps xmm11, [rsp+0xA0]
000076e4393d9793  vmovaps xmm12, [rsp+0xB0]
000076e4393d979c  vmovaps xmm13, [rsp+0xC0]
000076e4393d97a5  vmovaps xmm14, [rsp+0xD0]
000076e4393d97ae  vmovaps xmm15, [rsp+0xE0]
000076e4393d97b7  add rsp, 0xF0
000076e4393d97be  pop r11
000076e4393d97c0  pop r10
000076e4393d97c2  pop r9
000076e4393d97c4  pop r8
000076e4393d97c6  pop rsi
000076e4393d97c7  pop rdi
000076e4393d97c8  pop rdx
000076e4393d97c9  pop rcx
000076e4393d97ca  pop rax
000076e4393d97cb  add rsp, 0x08
000076e4393d97cf  jmp 0x000076E4393D628A
000076e4393d97d4  sub rsp, 0x08
000076e4393d97d8  push rax
000076e4393d97d9  push rcx
000076e4393d97da  push rdx
000076e4393d97db  push rdi
000076e4393d97dc  push rsi
000076e4393d97dd  push r8
000076e4393d97df  push r9
000076e4393d97e1  push r10
000076e4393d97e3  push r11
000076e4393d97e5  sub rsp, 0xF0
000076e4393d97ec  vmovaps [rsp], xmm0
000076e4393d97f1  vmovaps [rsp+0x10], xmm1
000076e4393d97f7  vmovaps [rsp+0x20], xmm2
000076e4393d97fd  vmovaps [rsp+0x30], xmm3
000076e4393d9803  vmovaps [rsp+0x40], xmm4
000076e4393d9809  vmovaps [rsp+0x50], xmm5
000076e4393d980f  vmovaps [rsp+0x60], xmm6
000076e4393d9815  vmovaps [rsp+0x70], xmm7
000076e4393d981b  vmovaps [rsp+0x80], xmm8
000076e4393d9824  vmovaps [rsp+0x90], xmm9
000076e4393d982d  vmovaps [rsp+0xA0], xmm10
000076e4393d9836  vmovaps [rsp+0xB0], xmm11
000076e4393d983f  vmovaps [rsp+0xC0], xmm12
000076e4393d9848  vmovaps [rsp+0xD0], xmm14
000076e4393d9851  vmovaps [rsp+0xE0], xmm15
000076e4393d985a  sub rsp, 0x30
000076e4393d985e  movaps [rsp], xmm13
000076e4393d9863  movaps [rsp+0x10], xmm15
000076e4393d9869  movaps [rsp+0x20], xmm9
000076e4393d986f  lea rdi, [rsp]
000076e4393d9873  mov esi, 0x00
000076e4393d9878  mov rax, 0x63DBDEB43530
000076e4393d9882  call rax
000076e4393d9884  movaps xmm13, [rsp]
000076e4393d9889  add rsp, 0x30
000076e4393d988d  vmovaps xmm0, [rsp]
000076e4393d9892  vmovaps xmm1, [rsp+0x10]
000076e4393d9898  vmovaps xmm2, [rsp+0x20]
000076e4393d989e  vmovaps xmm3, [rsp+0x30]
000076e4393d98a4  vmovaps xmm4, [rsp+0x40]
000076e4393d98aa  vmovaps xmm5, [rsp+0x50]
000076e4393d98b0  vmovaps xmm6, [rsp+0x60]
000076e4393d98b6  vmovaps xmm7, [rsp+0x70]
000076e4393d98bc  vmovaps xmm8, [rsp+0x80]
000076e4393d98c5  vmovaps xmm9, [rsp+0x90]
000076e4393d98ce  vmovaps xmm10, [rsp+0xA0]
000076e4393d98d7  vmovaps xmm11, [rsp+0xB0]
000076e4393d98e0  vmovaps xmm12, [rsp+0xC0]
000076e4393d98e9  vmovaps xmm14, [rsp+0xD0]
000076e4393d98f2  vmovaps xmm15, [rsp+0xE0]
000076e4393d98fb  add rsp, 0xF0
000076e4393d9902  pop r11
000076e4393d9904  pop r10
000076e4393d9906  pop r9
000076e4393d9908  pop r8
000076e4393d990a  pop rsi
000076e4393d990b  pop rdi
000076e4393d990c  pop rdx
000076e4393d990d  pop rcx
000076e4393d990e  pop rax
000076e4393d990f  add rsp, 0x08
000076e4393d9913  jmp 0x000076E4393D62A5
000076e4393d9918  sub rsp, 0x08
000076e4393d991c  push rax
000076e4393d991d  push rcx
000076e4393d991e  push rdx
000076e4393d991f  push rdi
000076e4393d9920  push rsi
000076e4393d9921  push r8
000076e4393d9923  push r9
000076e4393d9925  push r10
000076e4393d9927  push r11
000076e4393d9929  sub rsp, 0xF0
000076e4393d9930  vmovaps [rsp], xmm0
000076e4393d9935  vmovaps [rsp+0x10], xmm1
000076e4393d993b  vmovaps [rsp+0x20], xmm2
000076e4393d9941  vmovaps [rsp+0x30], xmm3
000076e4393d9947  vmovaps [rsp+0x40], xmm4
000076e4393d994d  vmovaps [rsp+0x50], xmm5
000076e4393d9953  vmovaps [rsp+0x60], xmm6
000076e4393d9959  vmovaps [rsp+0x70], xmm7
000076e4393d995f  vmovaps [rsp+0x80], xmm8
000076e4393d9968  vmovaps [rsp+0x90], xmm9
000076e4393d9971  vmovaps [rsp+0xA0], xmm10
000076e4393d997a  vmovaps [rsp+0xB0], xmm11
000076e4393d9983  vmovaps [rsp+0xC0], xmm12
000076e4393d998c  vmovaps [rsp+0xD0], xmm13
000076e4393d9995  vmovaps [rsp+0xE0], xmm14
000076e4393d999e  sub rsp, 0x30
000076e4393d99a2  movaps [rsp], xmm15
000076e4393d99a7  movaps [rsp+0x10], xmm1
000076e4393d99ac  movaps [rsp+0x20], xmm5
000076e4393d99b1  lea rdi, [rsp]
000076e4393d99b5  mov esi, 0x00
000076e4393d99ba  mov rax, 0x63DBDEB43530
000076e4393d99c4  call rax
000076e4393d99c6  movaps xmm15, [rsp]
000076e4393d99cb  add rsp, 0x30
000076e4393d99cf  vmovaps xmm0, [rsp]
000076e4393d99d4  vmovaps xmm1, [rsp+0x10]
000076e4393d99da  vmovaps xmm2, [rsp+0x20]
000076e4393d99e0  vmovaps xmm3, [rsp+0x30]
000076e4393d99e6  vmovaps xmm4, [rsp+0x40]
000076e4393d99ec  vmovaps xmm5, [rsp+0x50]
000076e4393d99f2  vmovaps xmm6, [rsp+0x60]
000076e4393d99f8  vmovaps xmm7, [rsp+0x70]
000076e4393d99fe  vmovaps xmm8, [rsp+0x80]
000076e4393d9a07  vmovaps xmm9, [rsp+0x90]
000076e4393d9a10  vmovaps xmm10, [rsp+0xA0]
000076e4393d9a19  vmovaps xmm11, [rsp+0xB0]
000076e4393d9a22  vmovaps xmm12, [rsp+0xC0]
000076e4393d9a2b  vmovaps xmm13, [rsp+0xD0]
000076e4393d9a34  vmovaps xmm14, [rsp+0xE0]
000076e4393d9a3d  add rsp, 0xF0
000076e4393d9a44  pop r11
000076e4393d9a46  pop r10
000076e4393d9a48  pop r9
000076e4393d9a4a  pop r8
000076e4393d9a4c  pop rsi
000076e4393d9a4d  pop rdi
000076e4393d9a4e  pop rdx
000076e4393d9a4f  pop rcx
000076e4393d9a50  pop rax
000076e4393d9a51  add rsp, 0x08
000076e4393d9a55  jmp 0x000076E4393D62C0
000076e4393d9a5a  call 0x000076E4392D64F0
000076e4393d9a5f  jmp 0x000076E4393D631B
000076e4393d9a64  sub rsp, 0x08
000076e4393d9a68  push rax
000076e4393d9a69  push rcx
000076e4393d9a6a  push rdx
000076e4393d9a6b  push rdi
000076e4393d9a6c  push rsi
000076e4393d9a6d  push r8
000076e4393d9a6f  push r9
000076e4393d9a71  push r10
000076e4393d9a73  push r11
000076e4393d9a75  sub rsp, 0xF0
000076e4393d9a7c  vmovaps [rsp], xmm0
000076e4393d9a81  vmovaps [rsp+0x10], xmm1
000076e4393d9a87  vmovaps [rsp+0x20], xmm2
000076e4393d9a8d  vmovaps [rsp+0x30], xmm3
000076e4393d9a93  vmovaps [rsp+0x40], xmm4
000076e4393d9a99  vmovaps [rsp+0x50], xmm5
000076e4393d9a9f  vmovaps [rsp+0x60], xmm6
000076e4393d9aa5  vmovaps [rsp+0x70], xmm7
000076e4393d9aab  vmovaps [rsp+0x80], xmm8
000076e4393d9ab4  vmovaps [rsp+0x90], xmm10
000076e4393d9abd  vmovaps [rsp+0xA0], xmm11
000076e4393d9ac6  vmovaps [rsp+0xB0], xmm12
000076e4393d9acf  vmovaps [rsp+0xC0], xmm13
000076e4393d9ad8  vmovaps [rsp+0xD0], xmm14
000076e4393d9ae1  vmovaps [rsp+0xE0], xmm15
000076e4393d9aea  sub rsp, 0x30
000076e4393d9aee  movaps [rsp], xmm9
000076e4393d9af3  movaps [rsp+0x10], xmm8
000076e4393d9af9  movaps [rsp+0x20], xmm11
000076e4393d9aff  lea rdi, [rsp]
000076e4393d9b03  mov esi, 0x00
000076e4393d9b08  mov rax, 0x63DBDEB43530
000076e4393d9b12  call rax
000076e4393d9b14  movaps xmm9, [rsp]
000076e4393d9b19  add rsp, 0x30
000076e4393d9b1d  vmovaps xmm0, [rsp]
000076e4393d9b22  vmovaps xmm1, [rsp+0x10]
000076e4393d9b28  vmovaps xmm2, [rsp+0x20]
000076e4393d9b2e  vmovaps xmm3, [rsp+0x30]
000076e4393d9b34  vmovaps xmm4, [rsp+0x40]
000076e4393d9b3a  vmovaps xmm5, [rsp+0x50]
000076e4393d9b40  vmovaps xmm6, [rsp+0x60]
000076e4393d9b46  vmovaps xmm7, [rsp+0x70]
000076e4393d9b4c  vmovaps xmm8, [rsp+0x80]
000076e4393d9b55  vmovaps xmm10, [rsp+0x90]
000076e4393d9b5e  vmovaps xmm11, [rsp+0xA0]
000076e4393d9b67  vmovaps xmm12, [rsp+0xB0]
000076e4393d9b70  vmovaps xmm13, [rsp+0xC0]
000076e4393d9b79  vmovaps xmm14, [rsp+0xD0]
000076e4393d9b82  vmovaps xmm15, [rsp+0xE0]
000076e4393d9b8b  add rsp, 0xF0
000076e4393d9b92  pop r11
000076e4393d9b94  pop r10
000076e4393d9b96  pop r9
000076e4393d9b98  pop r8
000076e4393d9b9a  pop rsi
000076e4393d9b9b  pop rdi
000076e4393d9b9c  pop rdx
000076e4393d9b9d  pop rcx
000076e4393d9b9e  pop rax
000076e4393d9b9f  add rsp, 0x08
000076e4393d9ba3  jmp 0x000076E4393D6352
000076e4393d9ba8  sub rsp, 0x08
000076e4393d9bac  push rax
000076e4393d9bad  push rcx
000076e4393d9bae  push rdx
000076e4393d9baf  push rdi
000076e4393d9bb0  push rsi
000076e4393d9bb1  push r8
000076e4393d9bb3  push r9
000076e4393d9bb5  push r10
000076e4393d9bb7  push r11
000076e4393d9bb9  sub rsp, 0xF0
000076e4393d9bc0  vmovaps [rsp], xmm0
000076e4393d9bc5  vmovaps [rsp+0x10], xmm1
000076e4393d9bcb  vmovaps [rsp+0x20], xmm2
000076e4393d9bd1  vmovaps [rsp+0x30], xmm3
000076e4393d9bd7  vmovaps [rsp+0x40], xmm4
000076e4393d9bdd  vmovaps [rsp+0x50], xmm5
000076e4393d9be3  vmovaps [rsp+0x60], xmm6
000076e4393d9be9  vmovaps [rsp+0x70], xmm7
000076e4393d9bef  vmovaps [rsp+0x80], xmm8
000076e4393d9bf8  vmovaps [rsp+0x90], xmm9
000076e4393d9c01  vmovaps [rsp+0xA0], xmm10
000076e4393d9c0a  vmovaps [rsp+0xB0], xmm12
000076e4393d9c13  vmovaps [rsp+0xC0], xmm13
000076e4393d9c1c  vmovaps [rsp+0xD0], xmm14
000076e4393d9c25  vmovaps [rsp+0xE0], xmm15
000076e4393d9c2e  sub rsp, 0x30
000076e4393d9c32  movaps [rsp], xmm11
000076e4393d9c37  movaps [rsp+0x10], xmm10
000076e4393d9c3d  movaps [rsp+0x20], xmm6
000076e4393d9c42  lea rdi, [rsp]
000076e4393d9c46  mov esi, 0x00
000076e4393d9c4b  mov rax, 0x63DBDEB43530
000076e4393d9c55  call rax
000076e4393d9c57  movaps xmm11, [rsp]
000076e4393d9c5c  add rsp, 0x30
000076e4393d9c60  vmovaps xmm0, [rsp]
000076e4393d9c65  vmovaps xmm1, [rsp+0x10]
000076e4393d9c6b  vmovaps xmm2, [rsp+0x20]
000076e4393d9c71  vmovaps xmm3, [rsp+0x30]
000076e4393d9c77  vmovaps xmm4, [rsp+0x40]
000076e4393d9c7d  vmovaps xmm5, [rsp+0x50]
000076e4393d9c83  vmovaps xmm6, [rsp+0x60]
000076e4393d9c89  vmovaps xmm7, [rsp+0x70]
000076e4393d9c8f  vmovaps xmm8, [rsp+0x80]
000076e4393d9c98  vmovaps xmm9, [rsp+0x90]
000076e4393d9ca1  vmovaps xmm10, [rsp+0xA0]
000076e4393d9caa  vmovaps xmm12, [rsp+0xB0]
000076e4393d9cb3  vmovaps xmm13, [rsp+0xC0]
000076e4393d9cbc  vmovaps xmm14, [rsp+0xD0]
000076e4393d9cc5  vmovaps xmm15, [rsp+0xE0]
000076e4393d9cce  add rsp, 0xF0
000076e4393d9cd5  pop r11
000076e4393d9cd7  pop r10
000076e4393d9cd9  pop r9
000076e4393d9cdb  pop r8
000076e4393d9cdd  pop rsi
000076e4393d9cde  pop rdi
000076e4393d9cdf  pop rdx
000076e4393d9ce0  pop rcx
000076e4393d9ce1  pop rax
000076e4393d9ce2  add rsp, 0x08
000076e4393d9ce6  jmp 0x000076E4393D636D
000076e4393d9ceb  sub rsp, 0x08
000076e4393d9cef  push rax
000076e4393d9cf0  push rcx
000076e4393d9cf1  push rdx
000076e4393d9cf2  push rdi
000076e4393d9cf3  push rsi
000076e4393d9cf4  push r8
000076e4393d9cf6  push r9
000076e4393d9cf8  push r10
000076e4393d9cfa  push r11
000076e4393d9cfc  sub rsp, 0xF0
000076e4393d9d03  vmovaps [rsp], xmm0
000076e4393d9d08  vmovaps [rsp+0x10], xmm1
000076e4393d9d0e  vmovaps [rsp+0x20], xmm2
000076e4393d9d14  vmovaps [rsp+0x30], xmm3
000076e4393d9d1a  vmovaps [rsp+0x40], xmm4
000076e4393d9d20  vmovaps [rsp+0x50], xmm5
000076e4393d9d26  vmovaps [rsp+0x60], xmm6
000076e4393d9d2c  vmovaps [rsp+0x70], xmm7
000076e4393d9d32  vmovaps [rsp+0x80], xmm8
000076e4393d9d3b  vmovaps [rsp+0x90], xmm9
000076e4393d9d44  vmovaps [rsp+0xA0], xmm11
000076e4393d9d4d  vmovaps [rsp+0xB0], xmm12
000076e4393d9d56  vmovaps [rsp+0xC0], xmm13
000076e4393d9d5f  vmovaps [rsp+0xD0], xmm14
000076e4393d9d68  vmovaps [rsp+0xE0], xmm15
000076e4393d9d71  sub rsp, 0x30
000076e4393d9d75  movaps [rsp], xmm10
000076e4393d9d7a  movaps [rsp+0x10], xmm14
000076e4393d9d80  movaps [rsp+0x20], xmm4
000076e4393d9d85  lea rdi, [rsp]
000076e4393d9d89  mov esi, 0x00
000076e4393d9d8e  mov rax, 0x63DBDEB43530
000076e4393d9d98  call rax
000076e4393d9d9a  movaps xmm10, [rsp]
000076e4393d9d9f  add rsp, 0x30
000076e4393d9da3  vmovaps xmm0, [rsp]
000076e4393d9da8  vmovaps xmm1, [rsp+0x10]
000076e4393d9dae  vmovaps xmm2, [rsp+0x20]
000076e4393d9db4  vmovaps xmm3, [rsp+0x30]
000076e4393d9dba  vmovaps xmm4, [rsp+0x40]
000076e4393d9dc0  vmovaps xmm5, [rsp+0x50]
000076e4393d9dc6  vmovaps xmm6, [rsp+0x60]
000076e4393d9dcc  vmovaps xmm7, [rsp+0x70]
000076e4393d9dd2  vmovaps xmm8, [rsp+0x80]
000076e4393d9ddb  vmovaps xmm9, [rsp+0x90]
000076e4393d9de4  vmovaps xmm11, [rsp+0xA0]
000076e4393d9ded  vmovaps xmm12, [rsp+0xB0]
000076e4393d9df6  vmovaps xmm13, [rsp+0xC0]
000076e4393d9dff  vmovaps xmm14, [rsp+0xD0]
000076e4393d9e08  vmovaps xmm15, [rsp+0xE0]
000076e4393d9e11  add rsp, 0xF0
000076e4393d9e18  pop r11
000076e4393d9e1a  pop r10
000076e4393d9e1c  pop r9
000076e4393d9e1e  pop r8
000076e4393d9e20  pop rsi
000076e4393d9e21  pop rdi
000076e4393d9e22  pop rdx
000076e4393d9e23  pop rcx
000076e4393d9e24  pop rax
000076e4393d9e25  add rsp, 0x08
000076e4393d9e29  jmp 0x000076E4393D6388
000076e4393d9e2e  sub rsp, 0x08
000076e4393d9e32  push rax
000076e4393d9e33  push rcx
000076e4393d9e34  push rdx
000076e4393d9e35  push rdi
000076e4393d9e36  push rsi
000076e4393d9e37  push r8
000076e4393d9e39  push r9
000076e4393d9e3b  push r10
000076e4393d9e3d  push r11
000076e4393d9e3f  sub rsp, 0xF0
000076e4393d9e46  vmovaps [rsp], xmm0
000076e4393d9e4b  vmovaps [rsp+0x10], xmm1
000076e4393d9e51  vmovaps [rsp+0x20], xmm2
000076e4393d9e57  vmovaps [rsp+0x30], xmm3
000076e4393d9e5d  vmovaps [rsp+0x40], xmm4
000076e4393d9e63  vmovaps [rsp+0x50], xmm5
000076e4393d9e69  vmovaps [rsp+0x60], xmm6
000076e4393d9e6f  vmovaps [rsp+0x70], xmm7
000076e4393d9e75  vmovaps [rsp+0x80], xmm9
000076e4393d9e7e  vmovaps [rsp+0x90], xmm10
000076e4393d9e87  vmovaps [rsp+0xA0], xmm11
000076e4393d9e90  vmovaps [rsp+0xB0], xmm12
000076e4393d9e99  vmovaps [rsp+0xC0], xmm13
000076e4393d9ea2  vmovaps [rsp+0xD0], xmm14
000076e4393d9eab  vmovaps [rsp+0xE0], xmm15
000076e4393d9eb4  sub rsp, 0x30
000076e4393d9eb8  movaps [rsp], xmm8
000076e4393d9ebd  movaps [rsp+0x10], xmm1
000076e4393d9ec2  movaps [rsp+0x20], xmm14
000076e4393d9ec8  lea rdi, [rsp]
000076e4393d9ecc  mov esi, 0x00
000076e4393d9ed1  mov rax, 0x63DBDEB43530
000076e4393d9edb  call rax
000076e4393d9edd  movaps xmm8, [rsp]
000076e4393d9ee2  add rsp, 0x30
000076e4393d9ee6  vmovaps xmm0, [rsp]
000076e4393d9eeb  vmovaps xmm1, [rsp+0x10]
000076e4393d9ef1  vmovaps xmm2, [rsp+0x20]
000076e4393d9ef7  vmovaps xmm3, [rsp+0x30]
000076e4393d9efd  vmovaps xmm4, [rsp+0x40]
000076e4393d9f03  vmovaps xmm5, [rsp+0x50]
000076e4393d9f09  vmovaps xmm6, [rsp+0x60]
000076e4393d9f0f  vmovaps xmm7, [rsp+0x70]
000076e4393d9f15  vmovaps xmm9, [rsp+0x80]
000076e4393d9f1e  vmovaps xmm10, [rsp+0x90]
000076e4393d9f27  vmovaps xmm11, [rsp+0xA0]
000076e4393d9f30  vmovaps xmm12, [rsp+0xB0]
000076e4393d9f39  vmovaps xmm13, [rsp+0xC0]
000076e4393d9f42  vmovaps xmm14, [rsp+0xD0]
000076e4393d9f4b  vmovaps xmm15, [rsp+0xE0]
000076e4393d9f54  add rsp, 0xF0
000076e4393d9f5b  pop r11
000076e4393d9f5d  pop r10
000076e4393d9f5f  pop r9
000076e4393d9f61  pop r8
000076e4393d9f63  pop rsi
000076e4393d9f64  pop rdi
000076e4393d9f65  pop rdx
000076e4393d9f66  pop rcx
000076e4393d9f67  pop rax
000076e4393d9f68  add rsp, 0x08
000076e4393d9f6c  jmp 0x000076E4393D63AE
000076e4393d9f71  sub rsp, 0x08
000076e4393d9f75  push rax
000076e4393d9f76  push rcx
000076e4393d9f77  push rdx
000076e4393d9f78  push rdi
000076e4393d9f79  push rsi
000076e4393d9f7a  push r8
000076e4393d9f7c  push r9
000076e4393d9f7e  push r10
000076e4393d9f80  push r11
000076e4393d9f82  sub rsp, 0xF0
000076e4393d9f89  vmovaps [rsp], xmm0
000076e4393d9f8e  vmovaps [rsp+0x10], xmm1
000076e4393d9f94  vmovaps [rsp+0x20], xmm2
000076e4393d9f9a  vmovaps [rsp+0x30], xmm3
000076e4393d9fa0  vmovaps [rsp+0x40], xmm4
000076e4393d9fa6  vmovaps [rsp+0x50], xmm5
000076e4393d9fac  vmovaps [rsp+0x60], xmm7
000076e4393d9fb2  vmovaps [rsp+0x70], xmm8
000076e4393d9fb8  vmovaps [rsp+0x80], xmm9
000076e4393d9fc1  vmovaps [rsp+0x90], xmm10
000076e4393d9fca  vmovaps [rsp+0xA0], xmm11
000076e4393d9fd3  vmovaps [rsp+0xB0], xmm12
000076e4393d9fdc  vmovaps [rsp+0xC0], xmm13
000076e4393d9fe5  vmovaps [rsp+0xD0], xmm14
000076e4393d9fee  vmovaps [rsp+0xE0], xmm15
000076e4393d9ff7  sub rsp, 0x30
000076e4393d9ffb  movaps [rsp], xmm6
000076e4393d9fff  movaps [rsp+0x10], xmm1
000076e4393da004  movaps [rsp+0x20], xmm14
000076e4393da00a  lea rdi, [rsp]
000076e4393da00e  mov esi, 0x00
000076e4393da013  mov rax, 0x63DBDEB43530
000076e4393da01d  call rax
000076e4393da01f  movaps xmm6, [rsp]
000076e4393da023  add rsp, 0x30
000076e4393da027  vmovaps xmm0, [rsp]
000076e4393da02c  vmovaps xmm1, [rsp+0x10]
000076e4393da032  vmovaps xmm2, [rsp+0x20]
000076e4393da038  vmovaps xmm3, [rsp+0x30]
000076e4393da03e  vmovaps xmm4, [rsp+0x40]
000076e4393da044  vmovaps xmm5, [rsp+0x50]
000076e4393da04a  vmovaps xmm7, [rsp+0x60]
000076e4393da050  vmovaps xmm8, [rsp+0x70]
000076e4393da056  vmovaps xmm9, [rsp+0x80]
000076e4393da05f  vmovaps xmm10, [rsp+0x90]
000076e4393da068  vmovaps xmm11, [rsp+0xA0]
000076e4393da071  vmovaps xmm12, [rsp+0xB0]
000076e4393da07a  vmovaps xmm13, [rsp+0xC0]
000076e4393da083  vmovaps xmm14, [rsp+0xD0]
000076e4393da08c  vmovaps xmm15, [rsp+0xE0]
000076e4393da095  add rsp, 0xF0
000076e4393da09c  pop r11
000076e4393da09e  pop r10
000076e4393da0a0  pop r9
000076e4393da0a2  pop r8
000076e4393da0a4  pop rsi
000076e4393da0a5  pop rdi
000076e4393da0a6  pop rdx
000076e4393da0a7  pop rcx
000076e4393da0a8  pop rax
000076e4393da0a9  add rsp, 0x08
000076e4393da0ad  jmp 0x000076E4393D63DA
000076e4393da0b2  sub rsp, 0x08
000076e4393da0b6  push rax
000076e4393da0b7  push rcx
000076e4393da0b8  push rdx
000076e4393da0b9  push rdi
000076e4393da0ba  push rsi
000076e4393da0bb  push r8
000076e4393da0bd  push r9
000076e4393da0bf  push r10
000076e4393da0c1  push r11
000076e4393da0c3  sub rsp, 0xF0
000076e4393da0ca  vmovaps [rsp], xmm0
000076e4393da0cf  vmovaps [rsp+0x10], xmm1
000076e4393da0d5  vmovaps [rsp+0x20], xmm2
000076e4393da0db  vmovaps [rsp+0x30], xmm3
000076e4393da0e1  vmovaps [rsp+0x40], xmm4
000076e4393da0e7  vmovaps [rsp+0x50], xmm5
000076e4393da0ed  vmovaps [rsp+0x60], xmm6
000076e4393da0f3  vmovaps [rsp+0x70], xmm7
000076e4393da0f9  vmovaps [rsp+0x80], xmm8
000076e4393da102  vmovaps [rsp+0x90], xmm9
000076e4393da10b  vmovaps [rsp+0xA0], xmm10
000076e4393da114  vmovaps [rsp+0xB0], xmm11
000076e4393da11d  vmovaps [rsp+0xC0], xmm12
000076e4393da126  vmovaps [rsp+0xD0], xmm13
000076e4393da12f  vmovaps [rsp+0xE0], xmm15
000076e4393da138  sub rsp, 0x30
000076e4393da13c  movaps [rsp], xmm14
000076e4393da141  movaps [rsp+0x10], xmm12
000076e4393da147  movaps [rsp+0x20], xmm1
000076e4393da14c  lea rdi, [rsp]
000076e4393da150  mov esi, 0x00
000076e4393da155  mov rax, 0x63DBDEB43530
000076e4393da15f  call rax
000076e4393da161  movaps xmm14, [rsp]
000076e4393da166  add rsp, 0x30
000076e4393da16a  vmovaps xmm0, [rsp]
000076e4393da16f  vmovaps xmm1, [rsp+0x10]
000076e4393da175  vmovaps xmm2, [rsp+0x20]
000076e4393da17b  vmovaps xmm3, [rsp+0x30]
000076e4393da181  vmovaps xmm4, [rsp+0x40]
000076e4393da187  vmovaps xmm5, [rsp+0x50]
000076e4393da18d  vmovaps xmm6, [rsp+0x60]
000076e4393da193  vmovaps xmm7, [rsp+0x70]
000076e4393da199  vmovaps xmm8, [rsp+0x80]
000076e4393da1a2  vmovaps xmm9, [rsp+0x90]
000076e4393da1ab  vmovaps xmm10, [rsp+0xA0]
000076e4393da1b4  vmovaps xmm11, [rsp+0xB0]
000076e4393da1bd  vmovaps xmm12, [rsp+0xC0]
000076e4393da1c6  vmovaps xmm13, [rsp+0xD0]
000076e4393da1cf  vmovaps xmm15, [rsp+0xE0]
000076e4393da1d8  add rsp, 0xF0
000076e4393da1df  pop r11
000076e4393da1e1  pop r10
000076e4393da1e3  pop r9
000076e4393da1e5  pop r8
000076e4393da1e7  pop rsi
000076e4393da1e8  pop rdi
000076e4393da1e9  pop rdx
000076e4393da1ea  pop rcx
000076e4393da1eb  pop rax
000076e4393da1ec  add rsp, 0x08
000076e4393da1f0  jmp 0x000076E4393D6400
000076e4393da1f5  sub rsp, 0x08
000076e4393da1f9  push rax
000076e4393da1fa  push rcx
000076e4393da1fb  push rdx
000076e4393da1fc  push rdi
000076e4393da1fd  push rsi
000076e4393da1fe  push r8
000076e4393da200  push r9
000076e4393da202  push r10
000076e4393da204  push r11
000076e4393da206  sub rsp, 0xF0
000076e4393da20d  vmovaps [rsp], xmm0
000076e4393da212  vmovaps [rsp+0x10], xmm2
000076e4393da218  vmovaps [rsp+0x20], xmm3
000076e4393da21e  vmovaps [rsp+0x30], xmm4
000076e4393da224  vmovaps [rsp+0x40], xmm5
000076e4393da22a  vmovaps [rsp+0x50], xmm6
000076e4393da230  vmovaps [rsp+0x60], xmm7
000076e4393da236  vmovaps [rsp+0x70], xmm8
000076e4393da23c  vmovaps [rsp+0x80], xmm9
000076e4393da245  vmovaps [rsp+0x90], xmm10
000076e4393da24e  vmovaps [rsp+0xA0], xmm11
000076e4393da257  vmovaps [rsp+0xB0], xmm12
000076e4393da260  vmovaps [rsp+0xC0], xmm13
000076e4393da269  vmovaps [rsp+0xD0], xmm14
000076e4393da272  vmovaps [rsp+0xE0], xmm15
000076e4393da27b  sub rsp, 0x30
000076e4393da27f  movaps [rsp], xmm1
000076e4393da283  movaps [rsp+0x10], xmm13
000076e4393da289  movaps [rsp+0x20], xmm9
000076e4393da28f  lea rdi, [rsp]
000076e4393da293  mov esi, 0x00
000076e4393da298  mov rax, 0x63DBDEB43530
000076e4393da2a2  call rax
000076e4393da2a4  movaps xmm1, [rsp]
000076e4393da2a8  add rsp, 0x30
000076e4393da2ac  vmovaps xmm0, [rsp]
000076e4393da2b1  vmovaps xmm2, [rsp+0x10]
000076e4393da2b7  vmovaps xmm3, [rsp+0x20]
000076e4393da2bd  vmovaps xmm4, [rsp+0x30]
000076e4393da2c3  vmovaps xmm5, [rsp+0x40]
000076e4393da2c9  vmovaps xmm6, [rsp+0x50]
000076e4393da2cf  vmovaps xmm7, [rsp+0x60]
000076e4393da2d5  vmovaps xmm8, [rsp+0x70]
000076e4393da2db  vmovaps xmm9, [rsp+0x80]
000076e4393da2e4  vmovaps xmm10, [rsp+0x90]
000076e4393da2ed  vmovaps xmm11, [rsp+0xA0]
000076e4393da2f6  vmovaps xmm12, [rsp+0xB0]
000076e4393da2ff  vmovaps xmm13, [rsp+0xC0]
000076e4393da308  vmovaps xmm14, [rsp+0xD0]
000076e4393da311  vmovaps xmm15, [rsp+0xE0]
000076e4393da31a  add rsp, 0xF0
000076e4393da321  pop r11
000076e4393da323  pop r10
000076e4393da325  pop r9
000076e4393da327  pop r8
000076e4393da329  pop rsi
000076e4393da32a  pop rdi
000076e4393da32b  pop rdx
000076e4393da32c  pop rcx
000076e4393da32d  pop rax
000076e4393da32e  add rsp, 0x08
000076e4393da332  jmp 0x000076E4393D641A
000076e4393da337  sub rsp, 0x08
000076e4393da33b  push rax
000076e4393da33c  push rcx
000076e4393da33d  push rdx
000076e4393da33e  push rdi
000076e4393da33f  push rsi
000076e4393da340  push r8
000076e4393da342  push r9
000076e4393da344  push r10
000076e4393da346  push r11
000076e4393da348  sub rsp, 0xF0
000076e4393da34f  vmovaps [rsp], xmm0
000076e4393da354  vmovaps [rsp+0x10], xmm1
000076e4393da35a  vmovaps [rsp+0x20], xmm2
000076e4393da360  vmovaps [rsp+0x30], xmm3
000076e4393da366  vmovaps [rsp+0x40], xmm4
000076e4393da36c  vmovaps [rsp+0x50], xmm5
000076e4393da372  vmovaps [rsp+0x60], xmm6
000076e4393da378  vmovaps [rsp+0x70], xmm7
000076e4393da37e  vmovaps [rsp+0x80], xmm8
000076e4393da387  vmovaps [rsp+0x90], xmm9
000076e4393da390  vmovaps [rsp+0xA0], xmm10
000076e4393da399  vmovaps [rsp+0xB0], xmm11
000076e4393da3a2  vmovaps [rsp+0xC0], xmm13
000076e4393da3ab  vmovaps [rsp+0xD0], xmm14
000076e4393da3b4  vmovaps [rsp+0xE0], xmm15
000076e4393da3bd  sub rsp, 0x30
000076e4393da3c1  movaps [rsp], xmm12
000076e4393da3c6  movaps [rsp+0x10], xmm7
000076e4393da3cb  movaps [rsp+0x20], xmm13
000076e4393da3d1  lea rdi, [rsp]
000076e4393da3d5  mov esi, 0x00
000076e4393da3da  mov rax, 0x63DBDEB43530
000076e4393da3e4  call rax
000076e4393da3e6  movaps xmm12, [rsp]
000076e4393da3eb  add rsp, 0x30
000076e4393da3ef  vmovaps xmm0, [rsp]
000076e4393da3f4  vmovaps xmm1, [rsp+0x10]
000076e4393da3fa  vmovaps xmm2, [rsp+0x20]
000076e4393da400  vmovaps xmm3, [rsp+0x30]
000076e4393da406  vmovaps xmm4, [rsp+0x40]
000076e4393da40c  vmovaps xmm5, [rsp+0x50]
000076e4393da412  vmovaps xmm6, [rsp+0x60]
000076e4393da418  vmovaps xmm7, [rsp+0x70]
000076e4393da41e  vmovaps xmm8, [rsp+0x80]
000076e4393da427  vmovaps xmm9, [rsp+0x90]
000076e4393da430  vmovaps xmm10, [rsp+0xA0]
000076e4393da439  vmovaps xmm11, [rsp+0xB0]
000076e4393da442  vmovaps xmm13, [rsp+0xC0]
000076e4393da44b  vmovaps xmm14, [rsp+0xD0]
000076e4393da454  vmovaps xmm15, [rsp+0xE0]
000076e4393da45d  add rsp, 0xF0
000076e4393da464  pop r11
000076e4393da466  pop r10
000076e4393da468  pop r9
000076e4393da46a  pop r8
000076e4393da46c  pop rsi
000076e4393da46d  pop rdi
000076e4393da46e  pop rdx
000076e4393da46f  pop rcx
000076e4393da470  pop rax
000076e4393da471  add rsp, 0x08
000076e4393da475  jmp 0x000076E4393D6441
000076e4393da47a  sub rsp, 0x08
000076e4393da47e  push rax
000076e4393da47f  push rcx
000076e4393da480  push rdx
000076e4393da481  push rdi
000076e4393da482  push rsi
000076e4393da483  push r8
000076e4393da485  push r9
000076e4393da487  push r10
000076e4393da489  push r11
000076e4393da48b  sub rsp, 0xF0
000076e4393da492  vmovaps [rsp], xmm0
000076e4393da497  vmovaps [rsp+0x10], xmm1
000076e4393da49d  vmovaps [rsp+0x20], xmm2
000076e4393da4a3  vmovaps [rsp+0x30], xmm3
000076e4393da4a9  vmovaps [rsp+0x40], xmm4
000076e4393da4af  vmovaps [rsp+0x50], xmm5
000076e4393da4b5  vmovaps [rsp+0x60], xmm6
000076e4393da4bb  vmovaps [rsp+0x70], xmm7
000076e4393da4c1  vmovaps [rsp+0x80], xmm8
000076e4393da4ca  vmovaps [rsp+0x90], xmm9
000076e4393da4d3  vmovaps [rsp+0xA0], xmm10
000076e4393da4dc  vmovaps [rsp+0xB0], xmm11
000076e4393da4e5  vmovaps [rsp+0xC0], xmm12
000076e4393da4ee  vmovaps [rsp+0xD0], xmm14
000076e4393da4f7  vmovaps [rsp+0xE0], xmm15
000076e4393da500  sub rsp, 0x30
000076e4393da504  movaps [rsp], xmm13
000076e4393da509  movaps [rsp+0x10], xmm15
000076e4393da50f  movaps [rsp+0x20], xmm8
000076e4393da515  lea rdi, [rsp]
000076e4393da519  mov esi, 0x00
000076e4393da51e  mov rax, 0x63DBDEB43530
000076e4393da528  call rax
000076e4393da52a  movaps xmm13, [rsp]
000076e4393da52f  add rsp, 0x30
000076e4393da533  vmovaps xmm0, [rsp]
000076e4393da538  vmovaps xmm1, [rsp+0x10]
000076e4393da53e  vmovaps xmm2, [rsp+0x20]
000076e4393da544  vmovaps xmm3, [rsp+0x30]
000076e4393da54a  vmovaps xmm4, [rsp+0x40]
000076e4393da550  vmovaps xmm5, [rsp+0x50]
000076e4393da556  vmovaps xmm6, [rsp+0x60]
000076e4393da55c  vmovaps xmm7, [rsp+0x70]
000076e4393da562  vmovaps xmm8, [rsp+0x80]
000076e4393da56b  vmovaps xmm9, [rsp+0x90]
000076e4393da574  vmovaps xmm10, [rsp+0xA0]
000076e4393da57d  vmovaps xmm11, [rsp+0xB0]
000076e4393da586  vmovaps xmm12, [rsp+0xC0]
000076e4393da58f  vmovaps xmm14, [rsp+0xD0]
000076e4393da598  vmovaps xmm15, [rsp+0xE0]
000076e4393da5a1  add rsp, 0xF0
000076e4393da5a8  pop r11
000076e4393da5aa  pop r10
000076e4393da5ac  pop r9
000076e4393da5ae  pop r8
000076e4393da5b0  pop rsi
000076e4393da5b1  pop rdi
000076e4393da5b2  pop rdx
000076e4393da5b3  pop rcx
000076e4393da5b4  pop rax
000076e4393da5b5  add rsp, 0x08
000076e4393da5b9  jmp 0x000076E4393D645C
000076e4393da5be  sub rsp, 0x08
000076e4393da5c2  push rax
000076e4393da5c3  push rcx
000076e4393da5c4  push rdx
000076e4393da5c5  push rdi
000076e4393da5c6  push rsi
000076e4393da5c7  push r8
000076e4393da5c9  push r9
000076e4393da5cb  push r10
000076e4393da5cd  push r11
000076e4393da5cf  sub rsp, 0xF0
000076e4393da5d6  vmovaps [rsp], xmm0
000076e4393da5db  vmovaps [rsp+0x10], xmm1
000076e4393da5e1  vmovaps [rsp+0x20], xmm2
000076e4393da5e7  vmovaps [rsp+0x30], xmm3
000076e4393da5ed  vmovaps [rsp+0x40], xmm4
000076e4393da5f3  vmovaps [rsp+0x50], xmm5
000076e4393da5f9  vmovaps [rsp+0x60], xmm6
000076e4393da5ff  vmovaps [rsp+0x70], xmm7
000076e4393da605  vmovaps [rsp+0x80], xmm9
000076e4393da60e  vmovaps [rsp+0x90], xmm10
000076e4393da617  vmovaps [rsp+0xA0], xmm11
000076e4393da620  vmovaps [rsp+0xB0], xmm12
000076e4393da629  vmovaps [rsp+0xC0], xmm13
000076e4393da632  vmovaps [rsp+0xD0], xmm14
000076e4393da63b  vmovaps [rsp+0xE0], xmm15
000076e4393da644  sub rsp, 0x30
000076e4393da648  movaps [rsp], xmm8
000076e4393da64d  movaps [rsp+0x10], xmm15
000076e4393da653  movaps [rsp+0x20], xmm9
000076e4393da659  lea rdi, [rsp]
000076e4393da65d  mov esi, 0x00
000076e4393da662  mov rax, 0x63DBDEB43530
000076e4393da66c  call rax
000076e4393da66e  movaps xmm8, [rsp]
000076e4393da673  add rsp, 0x30
000076e4393da677  vmovaps xmm0, [rsp]
000076e4393da67c  vmovaps xmm1, [rsp+0x10]
000076e4393da682  vmovaps xmm2, [rsp+0x20]
000076e4393da688  vmovaps xmm3, [rsp+0x30]
000076e4393da68e  vmovaps xmm4, [rsp+0x40]
000076e4393da694  vmovaps xmm5, [rsp+0x50]
000076e4393da69a  vmovaps xmm6, [rsp+0x60]
000076e4393da6a0  vmovaps xmm7, [rsp+0x70]
000076e4393da6a6  vmovaps xmm9, [rsp+0x80]
000076e4393da6af  vmovaps xmm10, [rsp+0x90]
000076e4393da6b8  vmovaps xmm11, [rsp+0xA0]
000076e4393da6c1  vmovaps xmm12, [rsp+0xB0]
000076e4393da6ca  vmovaps xmm13, [rsp+0xC0]
000076e4393da6d3  vmovaps xmm14, [rsp+0xD0]
000076e4393da6dc  vmovaps xmm15, [rsp+0xE0]
000076e4393da6e5  add rsp, 0xF0
000076e4393da6ec  pop r11
000076e4393da6ee  pop r10
000076e4393da6f0  pop r9
000076e4393da6f2  pop r8
000076e4393da6f4  pop rsi
000076e4393da6f5  pop rdi
000076e4393da6f6  pop rdx
000076e4393da6f7  pop rcx
000076e4393da6f8  pop rax
000076e4393da6f9  add rsp, 0x08
000076e4393da6fd  jmp 0x000076E4393D648A
000076e4393da702  sub rsp, 0x08
000076e4393da706  push rax
000076e4393da707  push rcx
000076e4393da708  push rdx
000076e4393da709  push rdi
000076e4393da70a  push rsi
000076e4393da70b  push r8
000076e4393da70d  push r9
000076e4393da70f  push r10
000076e4393da711  push r11
000076e4393da713  sub rsp, 0xF0
000076e4393da71a  vmovaps [rsp], xmm0
000076e4393da71f  vmovaps [rsp+0x10], xmm1
000076e4393da725  vmovaps [rsp+0x20], xmm2
000076e4393da72b  vmovaps [rsp+0x30], xmm3
000076e4393da731  vmovaps [rsp+0x40], xmm4
000076e4393da737  vmovaps [rsp+0x50], xmm5
000076e4393da73d  vmovaps [rsp+0x60], xmm6
000076e4393da743  vmovaps [rsp+0x70], xmm7
000076e4393da749  vmovaps [rsp+0x80], xmm8
000076e4393da752  vmovaps [rsp+0x90], xmm9
000076e4393da75b  vmovaps [rsp+0xA0], xmm10
000076e4393da764  vmovaps [rsp+0xB0], xmm11
000076e4393da76d  vmovaps [rsp+0xC0], xmm12
000076e4393da776  vmovaps [rsp+0xD0], xmm13
000076e4393da77f  vmovaps [rsp+0xE0], xmm14
000076e4393da788  sub rsp, 0x30
000076e4393da78c  movaps [rsp], xmm15
000076e4393da791  movaps [rsp+0x10], xmm11
000076e4393da797  movaps [rsp+0x20], xmm6
000076e4393da79c  lea rdi, [rsp]
000076e4393da7a0  mov esi, 0x00
000076e4393da7a5  mov rax, 0x63DBDEB43530
000076e4393da7af  call rax
000076e4393da7b1  movaps xmm15, [rsp]
000076e4393da7b6  add rsp, 0x30
000076e4393da7ba  vmovaps xmm0, [rsp]
000076e4393da7bf  vmovaps xmm1, [rsp+0x10]
000076e4393da7c5  vmovaps xmm2, [rsp+0x20]
000076e4393da7cb  vmovaps xmm3, [rsp+0x30]
000076e4393da7d1  vmovaps xmm4, [rsp+0x40]
000076e4393da7d7  vmovaps xmm5, [rsp+0x50]
000076e4393da7dd  vmovaps xmm6, [rsp+0x60]
000076e4393da7e3  vmovaps xmm7, [rsp+0x70]
000076e4393da7e9  vmovaps xmm8, [rsp+0x80]
000076e4393da7f2  vmovaps xmm9, [rsp+0x90]
000076e4393da7fb  vmovaps xmm10, [rsp+0xA0]
000076e4393da804  vmovaps xmm11, [rsp+0xB0]
000076e4393da80d  vmovaps xmm12, [rsp+0xC0]
000076e4393da816  vmovaps xmm13, [rsp+0xD0]
000076e4393da81f  vmovaps xmm14, [rsp+0xE0]
000076e4393da828  add rsp, 0xF0
000076e4393da82f  pop r11
000076e4393da831  pop r10
000076e4393da833  pop r9
000076e4393da835  pop r8
000076e4393da837  pop rsi
000076e4393da838  pop rdi
000076e4393da839  pop rdx
000076e4393da83a  pop rcx
000076e4393da83b  pop rax
000076e4393da83c  add rsp, 0x08
000076e4393da840  jmp 0x000076E4393D64A5
000076e4393da845  sub rsp, 0x08
000076e4393da849  push rax
000076e4393da84a  push rcx
000076e4393da84b  push rdx
000076e4393da84c  push rdi
000076e4393da84d  push rsi
000076e4393da84e  push r8
000076e4393da850  push r9
000076e4393da852  push r10
000076e4393da854  push r11
000076e4393da856  sub rsp, 0xF0
000076e4393da85d  vmovaps [rsp], xmm0
000076e4393da862  vmovaps [rsp+0x10], xmm1
000076e4393da868  vmovaps [rsp+0x20], xmm2
000076e4393da86e  vmovaps [rsp+0x30], xmm3
000076e4393da874  vmovaps [rsp+0x40], xmm4
000076e4393da87a  vmovaps [rsp+0x50], xmm5
000076e4393da880  vmovaps [rsp+0x60], xmm6
000076e4393da886  vmovaps [rsp+0x70], xmm8
000076e4393da88c  vmovaps [rsp+0x80], xmm9
000076e4393da895  vmovaps [rsp+0x90], xmm10
000076e4393da89e  vmovaps [rsp+0xA0], xmm11
000076e4393da8a7  vmovaps [rsp+0xB0], xmm12
000076e4393da8b0  vmovaps [rsp+0xC0], xmm13
000076e4393da8b9  vmovaps [rsp+0xD0], xmm14
000076e4393da8c2  vmovaps [rsp+0xE0], xmm15
000076e4393da8cb  sub rsp, 0x30
000076e4393da8cf  movaps [rsp], xmm7
000076e4393da8d3  movaps [rsp+0x10], xmm11
000076e4393da8d9  movaps [rsp+0x20], xmm9
000076e4393da8df  lea rdi, [rsp]
000076e4393da8e3  mov esi, 0x00
000076e4393da8e8  mov rax, 0x63DBDEB43530
000076e4393da8f2  call rax
000076e4393da8f4  movaps xmm7, [rsp]
000076e4393da8f8  add rsp, 0x30
000076e4393da8fc  vmovaps xmm0, [rsp]
000076e4393da901  vmovaps xmm1, [rsp+0x10]
000076e4393da907  vmovaps xmm2, [rsp+0x20]
000076e4393da90d  vmovaps xmm3, [rsp+0x30]
000076e4393da913  vmovaps xmm4, [rsp+0x40]
000076e4393da919  vmovaps xmm5, [rsp+0x50]
000076e4393da91f  vmovaps xmm6, [rsp+0x60]
000076e4393da925  vmovaps xmm8, [rsp+0x70]
000076e4393da92b  vmovaps xmm9, [rsp+0x80]
000076e4393da934  vmovaps xmm10, [rsp+0x90]
000076e4393da93d  vmovaps xmm11, [rsp+0xA0]
000076e4393da946  vmovaps xmm12, [rsp+0xB0]
000076e4393da94f  vmovaps xmm13, [rsp+0xC0]
000076e4393da958  vmovaps xmm14, [rsp+0xD0]
000076e4393da961  vmovaps xmm15, [rsp+0xE0]
000076e4393da96a  add rsp, 0xF0
000076e4393da971  pop r11
000076e4393da973  pop r10
000076e4393da975  pop r9
000076e4393da977  pop r8
000076e4393da979  pop rsi
000076e4393da97a  pop rdi
000076e4393da97b  pop rdx
000076e4393da97c  pop rcx
000076e4393da97d  pop rax
000076e4393da97e  add rsp, 0x08
000076e4393da982  jmp 0x000076E4393D64D2
000076e4393da987  sub rsp, 0x08
000076e4393da98b  push rax
000076e4393da98c  push rcx
000076e4393da98d  push rdx
000076e4393da98e  push rdi
000076e4393da98f  push rsi
000076e4393da990  push r8
000076e4393da992  push r9
000076e4393da994  push r10
000076e4393da996  push r11
000076e4393da998  sub rsp, 0xF0
000076e4393da99f  vmovaps [rsp], xmm0
000076e4393da9a4  vmovaps [rsp+0x10], xmm1
000076e4393da9aa  vmovaps [rsp+0x20], xmm2
000076e4393da9b0  vmovaps [rsp+0x30], xmm3
000076e4393da9b6  vmovaps [rsp+0x40], xmm4
000076e4393da9bc  vmovaps [rsp+0x50], xmm5
000076e4393da9c2  vmovaps [rsp+0x60], xmm6
000076e4393da9c8  vmovaps [rsp+0x70], xmm7
000076e4393da9ce  vmovaps [rsp+0x80], xmm8
000076e4393da9d7  vmovaps [rsp+0x90], xmm9
000076e4393da9e0  vmovaps [rsp+0xA0], xmm10
000076e4393da9e9  vmovaps [rsp+0xB0], xmm12
000076e4393da9f2  vmovaps [rsp+0xC0], xmm13
000076e4393da9fb  vmovaps [rsp+0xD0], xmm14
000076e4393daa04  vmovaps [rsp+0xE0], xmm15
000076e4393daa0d  sub rsp, 0x30
000076e4393daa11  movaps [rsp], xmm11
000076e4393daa16  movaps [rsp+0x10], xmm10
000076e4393daa1c  movaps [rsp+0x20], xmm14
000076e4393daa22  lea rdi, [rsp]
000076e4393daa26  mov esi, 0x00
000076e4393daa2b  mov rax, 0x63DBDEB43530
000076e4393daa35  call rax
000076e4393daa37  movaps xmm11, [rsp]
000076e4393daa3c  add rsp, 0x30
000076e4393daa40  vmovaps xmm0, [rsp]
000076e4393daa45  vmovaps xmm1, [rsp+0x10]
000076e4393daa4b  vmovaps xmm2, [rsp+0x20]
000076e4393daa51  vmovaps xmm3, [rsp+0x30]
000076e4393daa57  vmovaps xmm4, [rsp+0x40]
000076e4393daa5d  vmovaps xmm5, [rsp+0x50]
000076e4393daa63  vmovaps xmm6, [rsp+0x60]
000076e4393daa69  vmovaps xmm7, [rsp+0x70]
000076e4393daa6f  vmovaps xmm8, [rsp+0x80]
000076e4393daa78  vmovaps xmm9, [rsp+0x90]
000076e4393daa81  vmovaps xmm10, [rsp+0xA0]
000076e4393daa8a  vmovaps xmm12, [rsp+0xB0]
000076e4393daa93  vmovaps xmm13, [rsp+0xC0]
000076e4393daa9c  vmovaps xmm14, [rsp+0xD0]
000076e4393daaa5  vmovaps xmm15, [rsp+0xE0]
000076e4393daaae  add rsp, 0xF0
000076e4393daab5  pop r11
000076e4393daab7  pop r10
000076e4393daab9  pop r9
000076e4393daabb  pop r8
000076e4393daabd  pop rsi
000076e4393daabe  pop rdi
000076e4393daabf  pop rdx
000076e4393daac0  pop rcx
000076e4393daac1  pop rax
000076e4393daac2  add rsp, 0x08
000076e4393daac6  jmp 0x000076E4393D64ED
000076e4393daacb  call 0x000076E4392E45A0
000076e4393daad0  jmp 0x000076E4393D64F7
000076e4393daad5  sub rsp, 0x08
000076e4393daad9  push rax
000076e4393daada  push rcx
000076e4393daadb  push rdx
000076e4393daadc  push rdi
000076e4393daadd  push rsi
000076e4393daade  push r8
000076e4393daae0  push r9
000076e4393daae2  push r10
000076e4393daae4  push r11
000076e4393daae6  sub rsp, 0xF0
000076e4393daaed  vmovaps [rsp], xmm0
000076e4393daaf2  vmovaps [rsp+0x10], xmm1
000076e4393daaf8  vmovaps [rsp+0x20], xmm2
000076e4393daafe  vmovaps [rsp+0x30], xmm3
000076e4393dab04  vmovaps [rsp+0x40], xmm4
000076e4393dab0a  vmovaps [rsp+0x50], xmm5
000076e4393dab10  vmovaps [rsp+0x60], xmm6
000076e4393dab16  vmovaps [rsp+0x70], xmm7
000076e4393dab1c  vmovaps [rsp+0x80], xmm8
000076e4393dab25  vmovaps [rsp+0x90], xmm9
000076e4393dab2e  vmovaps [rsp+0xA0], xmm11
000076e4393dab37  vmovaps [rsp+0xB0], xmm12
000076e4393dab40  vmovaps [rsp+0xC0], xmm13
000076e4393dab49  vmovaps [rsp+0xD0], xmm14
000076e4393dab52  vmovaps [rsp+0xE0], xmm15
000076e4393dab5b  sub rsp, 0x30
000076e4393dab5f  movaps [rsp], xmm10
000076e4393dab64  movaps [rsp+0x10], xmm1
000076e4393dab69  movaps [rsp+0x20], xmm12
000076e4393dab6f  lea rdi, [rsp]
000076e4393dab73  mov esi, 0x00
000076e4393dab78  mov rax, 0x63DBDEB43530
000076e4393dab82  call rax
000076e4393dab84  movaps xmm10, [rsp]
000076e4393dab89  add rsp, 0x30
000076e4393dab8d  vmovaps xmm0, [rsp]
000076e4393dab92  vmovaps xmm1, [rsp+0x10]
000076e4393dab98  vmovaps xmm2, [rsp+0x20]
000076e4393dab9e  vmovaps xmm3, [rsp+0x30]
000076e4393daba4  vmovaps xmm4, [rsp+0x40]
000076e4393dabaa  vmovaps xmm5, [rsp+0x50]
000076e4393dabb0  vmovaps xmm6, [rsp+0x60]
000076e4393dabb6  vmovaps xmm7, [rsp+0x70]
000076e4393dabbc  vmovaps xmm8, [rsp+0x80]
000076e4393dabc5  vmovaps xmm9, [rsp+0x90]
000076e4393dabce  vmovaps xmm11, [rsp+0xA0]
000076e4393dabd7  vmovaps xmm12, [rsp+0xB0]
000076e4393dabe0  vmovaps xmm13, [rsp+0xC0]
000076e4393dabe9  vmovaps xmm14, [rsp+0xD0]
000076e4393dabf2  vmovaps xmm15, [rsp+0xE0]
000076e4393dabfb  add rsp, 0xF0
000076e4393dac02  pop r11
000076e4393dac04  pop r10
000076e4393dac06  pop r9
000076e4393dac08  pop r8
000076e4393dac0a  pop rsi
000076e4393dac0b  pop rdi
000076e4393dac0c  pop rdx
000076e4393dac0d  pop rcx
000076e4393dac0e  pop rax
000076e4393dac0f  add rsp, 0x08
000076e4393dac13  jmp 0x000076E4393D651A
000076e4393dac18  sub rsp, 0x08
000076e4393dac1c  push rax
000076e4393dac1d  push rcx
000076e4393dac1e  push rdx
000076e4393dac1f  push rdi
000076e4393dac20  push rsi
000076e4393dac21  push r8
000076e4393dac23  push r9
000076e4393dac25  push r10
000076e4393dac27  push r11
000076e4393dac29  sub rsp, 0xF0
000076e4393dac30  vmovaps [rsp], xmm0
000076e4393dac35  vmovaps [rsp+0x10], xmm1
000076e4393dac3b  vmovaps [rsp+0x20], xmm2
000076e4393dac41  vmovaps [rsp+0x30], xmm3
000076e4393dac47  vmovaps [rsp+0x40], xmm4
000076e4393dac4d  vmovaps [rsp+0x50], xmm5
000076e4393dac53  vmovaps [rsp+0x60], xmm6
000076e4393dac59  vmovaps [rsp+0x70], xmm7
000076e4393dac5f  vmovaps [rsp+0x80], xmm8
000076e4393dac68  vmovaps [rsp+0x90], xmm9
000076e4393dac71  vmovaps [rsp+0xA0], xmm10
000076e4393dac7a  vmovaps [rsp+0xB0], xmm11
000076e4393dac83  vmovaps [rsp+0xC0], xmm13
000076e4393dac8c  vmovaps [rsp+0xD0], xmm14
000076e4393dac95  vmovaps [rsp+0xE0], xmm15
000076e4393dac9e  sub rsp, 0x30
000076e4393daca2  movaps [rsp], xmm12
000076e4393daca7  movaps [rsp+0x10], xmm14
000076e4393dacad  movaps [rsp+0x20], xmm1
000076e4393dacb2  lea rdi, [rsp]
000076e4393dacb6  mov esi, 0x00
000076e4393dacbb  mov rax, 0x63DBDEB43530
000076e4393dacc5  call rax
000076e4393dacc7  movaps xmm12, [rsp]
000076e4393daccc  add rsp, 0x30
000076e4393dacd0  vmovaps xmm0, [rsp]
000076e4393dacd5  vmovaps xmm1, [rsp+0x10]
000076e4393dacdb  vmovaps xmm2, [rsp+0x20]
000076e4393dace1  vmovaps xmm3, [rsp+0x30]
000076e4393dace7  vmovaps xmm4, [rsp+0x40]
000076e4393daced  vmovaps xmm5, [rsp+0x50]
000076e4393dacf3  vmovaps xmm6, [rsp+0x60]
000076e4393dacf9  vmovaps xmm7, [rsp+0x70]
000076e4393dacff  vmovaps xmm8, [rsp+0x80]
000076e4393dad08  vmovaps xmm9, [rsp+0x90]
000076e4393dad11  vmovaps xmm10, [rsp+0xA0]
000076e4393dad1a  vmovaps xmm11, [rsp+0xB0]
000076e4393dad23  vmovaps xmm13, [rsp+0xC0]
000076e4393dad2c  vmovaps xmm14, [rsp+0xD0]
000076e4393dad35  vmovaps xmm15, [rsp+0xE0]
000076e4393dad3e  add rsp, 0xF0
000076e4393dad45  pop r11
000076e4393dad47  pop r10
000076e4393dad49  pop r9
000076e4393dad4b  pop r8
000076e4393dad4d  pop rsi
000076e4393dad4e  pop rdi
000076e4393dad4f  pop rdx
000076e4393dad50  pop rcx
000076e4393dad51  pop rax
000076e4393dad52  add rsp, 0x08
000076e4393dad56  jmp 0x000076E4393D6549
000076e4393dad5b  sub rsp, 0x08
000076e4393dad5f  push rax
000076e4393dad60  push rcx
000076e4393dad61  push rdx
000076e4393dad62  push rdi
000076e4393dad63  push rsi
000076e4393dad64  push r8
000076e4393dad66  push r9
000076e4393dad68  push r10
000076e4393dad6a  push r11
000076e4393dad6c  sub rsp, 0xF0
000076e4393dad73  vmovaps [rsp], xmm0
000076e4393dad78  vmovaps [rsp+0x10], xmm1
000076e4393dad7e  vmovaps [rsp+0x20], xmm2
000076e4393dad84  vmovaps [rsp+0x30], xmm3
000076e4393dad8a  vmovaps [rsp+0x40], xmm4
000076e4393dad90  vmovaps [rsp+0x50], xmm5
000076e4393dad96  vmovaps [rsp+0x60], xmm6
000076e4393dad9c  vmovaps [rsp+0x70], xmm7
000076e4393dada2  vmovaps [rsp+0x80], xmm8
000076e4393dadab  vmovaps [rsp+0x90], xmm9
000076e4393dadb4  vmovaps [rsp+0xA0], xmm10
000076e4393dadbd  vmovaps [rsp+0xB0], xmm11
000076e4393dadc6  vmovaps [rsp+0xC0], xmm12
000076e4393dadcf  vmovaps [rsp+0xD0], xmm13
000076e4393dadd8  vmovaps [rsp+0xE0], xmm15
000076e4393dade1  sub rsp, 0x30
000076e4393dade5  movaps [rsp], xmm14
000076e4393dadea  movaps [rsp+0x10], xmm9
000076e4393dadf0  movaps [rsp+0x20], xmm1
000076e4393dadf5  lea rdi, [rsp]
000076e4393dadf9  mov esi, 0x00
000076e4393dadfe  mov rax, 0x63DBDEB43530
000076e4393dae08  call rax
000076e4393dae0a  movaps xmm14, [rsp]
000076e4393dae0f  add rsp, 0x30
000076e4393dae13  vmovaps xmm0, [rsp]
000076e4393dae18  vmovaps xmm1, [rsp+0x10]
000076e4393dae1e  vmovaps xmm2, [rsp+0x20]
000076e4393dae24  vmovaps xmm3, [rsp+0x30]
000076e4393dae2a  vmovaps xmm4, [rsp+0x40]
000076e4393dae30  vmovaps xmm5, [rsp+0x50]
000076e4393dae36  vmovaps xmm6, [rsp+0x60]
000076e4393dae3c  vmovaps xmm7, [rsp+0x70]
000076e4393dae42  vmovaps xmm8, [rsp+0x80]
000076e4393dae4b  vmovaps xmm9, [rsp+0x90]
000076e4393dae54  vmovaps xmm10, [rsp+0xA0]
000076e4393dae5d  vmovaps xmm11, [rsp+0xB0]
000076e4393dae66  vmovaps xmm12, [rsp+0xC0]
000076e4393dae6f  vmovaps xmm13, [rsp+0xD0]
000076e4393dae78  vmovaps xmm15, [rsp+0xE0]
000076e4393dae81  add rsp, 0xF0
000076e4393dae88  pop r11
000076e4393dae8a  pop r10
000076e4393dae8c  pop r9
000076e4393dae8e  pop r8
000076e4393dae90  pop rsi
000076e4393dae91  pop rdi
000076e4393dae92  pop rdx
000076e4393dae93  pop rcx
000076e4393dae94  pop rax
000076e4393dae95  add rsp, 0x08
000076e4393dae99  jmp 0x000076E4393D6578
000076e4393dae9e  sub rsp, 0x08
000076e4393daea2  push rax
000076e4393daea3  push rcx
000076e4393daea4  push rdx
000076e4393daea5  push rdi
000076e4393daea6  push rsi
000076e4393daea7  push r8
000076e4393daea9  push r9
000076e4393daeab  push r10
000076e4393daead  push r11
000076e4393daeaf  sub rsp, 0xF0
000076e4393daeb6  vmovaps [rsp], xmm0
000076e4393daebb  vmovaps [rsp+0x10], xmm2
000076e4393daec1  vmovaps [rsp+0x20], xmm3
000076e4393daec7  vmovaps [rsp+0x30], xmm4
000076e4393daecd  vmovaps [rsp+0x40], xmm5
000076e4393daed3  vmovaps [rsp+0x50], xmm6
000076e4393daed9  vmovaps [rsp+0x60], xmm7
000076e4393daedf  vmovaps [rsp+0x70], xmm8
000076e4393daee5  vmovaps [rsp+0x80], xmm9
000076e4393daeee  vmovaps [rsp+0x90], xmm10
000076e4393daef7  vmovaps [rsp+0xA0], xmm11
000076e4393daf00  vmovaps [rsp+0xB0], xmm12
000076e4393daf09  vmovaps [rsp+0xC0], xmm13
000076e4393daf12  vmovaps [rsp+0xD0], xmm14
000076e4393daf1b  vmovaps [rsp+0xE0], xmm15
000076e4393daf24  sub rsp, 0x30
000076e4393daf28  movaps [rsp], xmm1
000076e4393daf2c  movaps [rsp+0x10], xmm13
000076e4393daf32  movaps [rsp+0x20], xmm8
000076e4393daf38  lea rdi, [rsp]
000076e4393daf3c  mov esi, 0x00
000076e4393daf41  mov rax, 0x63DBDEB43530
000076e4393daf4b  call rax
000076e4393daf4d  movaps xmm1, [rsp]
000076e4393daf51  add rsp, 0x30
000076e4393daf55  vmovaps xmm0, [rsp]
000076e4393daf5a  vmovaps xmm2, [rsp+0x10]
000076e4393daf60  vmovaps xmm3, [rsp+0x20]
000076e4393daf66  vmovaps xmm4, [rsp+0x30]
000076e4393daf6c  vmovaps xmm5, [rsp+0x40]
000076e4393daf72  vmovaps xmm6, [rsp+0x50]
000076e4393daf78  vmovaps xmm7, [rsp+0x60]
000076e4393daf7e  vmovaps xmm8, [rsp+0x70]
000076e4393daf84  vmovaps xmm9, [rsp+0x80]
000076e4393daf8d  vmovaps xmm10, [rsp+0x90]
000076e4393daf96  vmovaps xmm11, [rsp+0xA0]
000076e4393daf9f  vmovaps xmm12, [rsp+0xB0]
000076e4393dafa8  vmovaps xmm13, [rsp+0xC0]
000076e4393dafb1  vmovaps xmm14, [rsp+0xD0]
000076e4393dafba  vmovaps xmm15, [rsp+0xE0]
000076e4393dafc3  add rsp, 0xF0
000076e4393dafca  pop r11
000076e4393dafcc  pop r10
000076e4393dafce  pop r9
000076e4393dafd0  pop r8
000076e4393dafd2  pop rsi
000076e4393dafd3  pop rdi
000076e4393dafd4  pop rdx
000076e4393dafd5  pop rcx
000076e4393dafd6  pop rax
000076e4393dafd7  add rsp, 0x08
000076e4393dafdb  jmp 0x000076E4393D659A
000076e4393dafe0  call 0x000076E43920C260
000076e4393dafe5  jmp 0x000076E4393D65A8
000076e4393dafea  call 0x000076E4392DE950
000076e4393dafef  jmp 0x000076E4393D65B2
000076e4393daff4  sub rsp, 0x08
000076e4393daff8  push rax
000076e4393daff9  push rcx
000076e4393daffa  push rdx
000076e4393daffb  push rdi
000076e4393daffc  push rsi
000076e4393daffd  push r8
000076e4393dafff  push r9
000076e4393db001  push r10
000076e4393db003  push r11
000076e4393db005  sub rsp, 0xF0
000076e4393db00c  vmovaps [rsp], xmm0
000076e4393db011  vmovaps [rsp+0x10], xmm1
000076e4393db017  vmovaps [rsp+0x20], xmm2
000076e4393db01d  vmovaps [rsp+0x30], xmm3
000076e4393db023  vmovaps [rsp+0x40], xmm4
000076e4393db029  vmovaps [rsp+0x50], xmm5
000076e4393db02f  vmovaps [rsp+0x60], xmm6
000076e4393db035  vmovaps [rsp+0x70], xmm7
000076e4393db03b  vmovaps [rsp+0x80], xmm9
000076e4393db044  vmovaps [rsp+0x90], xmm10
000076e4393db04d  vmovaps [rsp+0xA0], xmm11
000076e4393db056  vmovaps [rsp+0xB0], xmm12
000076e4393db05f  vmovaps [rsp+0xC0], xmm13
000076e4393db068  vmovaps [rsp+0xD0], xmm14
000076e4393db071  vmovaps [rsp+0xE0], xmm15
000076e4393db07a  sub rsp, 0x30
000076e4393db07e  movaps [rsp], xmm8
000076e4393db083  movaps [rsp+0x10], xmm15
000076e4393db089  movaps [rsp+0x20], xmm7
000076e4393db08e  lea rdi, [rsp]
000076e4393db092  mov esi, 0x00
000076e4393db097  mov rax, 0x63DBDEB43530
000076e4393db0a1  call rax
000076e4393db0a3  movaps xmm8, [rsp]
000076e4393db0a8  add rsp, 0x30
000076e4393db0ac  vmovaps xmm0, [rsp]
000076e4393db0b1  vmovaps xmm1, [rsp+0x10]
000076e4393db0b7  vmovaps xmm2, [rsp+0x20]
000076e4393db0bd  vmovaps xmm3, [rsp+0x30]
000076e4393db0c3  vmovaps xmm4, [rsp+0x40]
000076e4393db0c9  vmovaps xmm5, [rsp+0x50]
000076e4393db0cf  vmovaps xmm6, [rsp+0x60]
000076e4393db0d5  vmovaps xmm7, [rsp+0x70]
000076e4393db0db  vmovaps xmm9, [rsp+0x80]
000076e4393db0e4  vmovaps xmm10, [rsp+0x90]
000076e4393db0ed  vmovaps xmm11, [rsp+0xA0]
000076e4393db0f6  vmovaps xmm12, [rsp+0xB0]
000076e4393db0ff  vmovaps xmm13, [rsp+0xC0]
000076e4393db108  vmovaps xmm14, [rsp+0xD0]
000076e4393db111  vmovaps xmm15, [rsp+0xE0]
000076e4393db11a  add rsp, 0xF0
000076e4393db121  pop r11
000076e4393db123  pop r10
000076e4393db125  pop r9
000076e4393db127  pop r8
000076e4393db129  pop rsi
000076e4393db12a  pop rdi
000076e4393db12b  pop rdx
000076e4393db12c  pop rcx
000076e4393db12d  pop rax
000076e4393db12e  add rsp, 0x08
000076e4393db132  jmp 0x000076E4393D65D4
000076e4393db137  sub rsp, 0x08
000076e4393db13b  push rax
000076e4393db13c  push rcx
000076e4393db13d  push rdx
000076e4393db13e  push rdi
000076e4393db13f  push rsi
000076e4393db140  push r8
000076e4393db142  push r9
000076e4393db144  push r10
000076e4393db146  push r11
000076e4393db148  sub rsp, 0xF0
000076e4393db14f  vmovaps [rsp], xmm0
000076e4393db154  vmovaps [rsp+0x10], xmm1
000076e4393db15a  vmovaps [rsp+0x20], xmm2
000076e4393db160  vmovaps [rsp+0x30], xmm3
000076e4393db166  vmovaps [rsp+0x40], xmm4
000076e4393db16c  vmovaps [rsp+0x50], xmm5
000076e4393db172  vmovaps [rsp+0x60], xmm6
000076e4393db178  vmovaps [rsp+0x70], xmm8
000076e4393db17e  vmovaps [rsp+0x80], xmm9
000076e4393db187  vmovaps [rsp+0x90], xmm10
000076e4393db190  vmovaps [rsp+0xA0], xmm11
000076e4393db199  vmovaps [rsp+0xB0], xmm12
000076e4393db1a2  vmovaps [rsp+0xC0], xmm13
000076e4393db1ab  vmovaps [rsp+0xD0], xmm14
000076e4393db1b4  vmovaps [rsp+0xE0], xmm15
000076e4393db1bd  sub rsp, 0x30
000076e4393db1c1  movaps [rsp], xmm7
000076e4393db1c5  movaps [rsp+0x10], xmm9
000076e4393db1cb  movaps [rsp+0x20], xmm15
000076e4393db1d1  lea rdi, [rsp]
000076e4393db1d5  mov esi, 0x00
000076e4393db1da  mov rax, 0x63DBDEB43530
000076e4393db1e4  call rax
000076e4393db1e6  movaps xmm7, [rsp]
000076e4393db1ea  add rsp, 0x30
000076e4393db1ee  vmovaps xmm0, [rsp]
000076e4393db1f3  vmovaps xmm1, [rsp+0x10]
000076e4393db1f9  vmovaps xmm2, [rsp+0x20]
000076e4393db1ff  vmovaps xmm3, [rsp+0x30]
000076e4393db205  vmovaps xmm4, [rsp+0x40]
000076e4393db20b  vmovaps xmm5, [rsp+0x50]
000076e4393db211  vmovaps xmm6, [rsp+0x60]
000076e4393db217  vmovaps xmm8, [rsp+0x70]
000076e4393db21d  vmovaps xmm9, [rsp+0x80]
000076e4393db226  vmovaps xmm10, [rsp+0x90]
000076e4393db22f  vmovaps xmm11, [rsp+0xA0]
000076e4393db238  vmovaps xmm12, [rsp+0xB0]
000076e4393db241  vmovaps xmm13, [rsp+0xC0]
000076e4393db24a  vmovaps xmm14, [rsp+0xD0]
000076e4393db253  vmovaps xmm15, [rsp+0xE0]
000076e4393db25c  add rsp, 0xF0
000076e4393db263  pop r11
000076e4393db265  pop r10
000076e4393db267  pop r9
000076e4393db269  pop r8
000076e4393db26b  pop rsi
000076e4393db26c  pop rdi
000076e4393db26d  pop rdx
000076e4393db26e  pop rcx
000076e4393db26f  pop rax
000076e4393db270  add rsp, 0x08
000076e4393db274  jmp 0x000076E4393D6601
000076e4393db279  sub rsp, 0x08
000076e4393db27d  push rax
000076e4393db27e  push rcx
000076e4393db27f  push rdx
000076e4393db280  push rdi
000076e4393db281  push rsi
000076e4393db282  push r8
000076e4393db284  push r9
000076e4393db286  push r10
000076e4393db288  push r11
000076e4393db28a  sub rsp, 0xF0
000076e4393db291  vmovaps [rsp], xmm0
000076e4393db296  vmovaps [rsp+0x10], xmm1
000076e4393db29c  vmovaps [rsp+0x20], xmm2
000076e4393db2a2  vmovaps [rsp+0x30], xmm3
000076e4393db2a8  vmovaps [rsp+0x40], xmm4
000076e4393db2ae  vmovaps [rsp+0x50], xmm5
000076e4393db2b4  vmovaps [rsp+0x60], xmm6
000076e4393db2ba  vmovaps [rsp+0x70], xmm7
000076e4393db2c0  vmovaps [rsp+0x80], xmm8
000076e4393db2c9  vmovaps [rsp+0x90], xmm10
000076e4393db2d2  vmovaps [rsp+0xA0], xmm11
000076e4393db2db  vmovaps [rsp+0xB0], xmm12
000076e4393db2e4  vmovaps [rsp+0xC0], xmm13
000076e4393db2ed  vmovaps [rsp+0xD0], xmm14
000076e4393db2f6  vmovaps [rsp+0xE0], xmm15
000076e4393db2ff  sub rsp, 0x30
000076e4393db303  movaps [rsp], xmm9
000076e4393db308  movaps [rsp+0x10], xmm13
000076e4393db30e  movaps [rsp+0x20], xmm15
000076e4393db314  lea rdi, [rsp]
000076e4393db318  mov esi, 0x00
000076e4393db31d  mov rax, 0x63DBDEB43530
000076e4393db327  call rax
000076e4393db329  movaps xmm9, [rsp]
000076e4393db32e  add rsp, 0x30
000076e4393db332  vmovaps xmm0, [rsp]
000076e4393db337  vmovaps xmm1, [rsp+0x10]
000076e4393db33d  vmovaps xmm2, [rsp+0x20]
000076e4393db343  vmovaps xmm3, [rsp+0x30]
000076e4393db349  vmovaps xmm4, [rsp+0x40]
000076e4393db34f  vmovaps xmm5, [rsp+0x50]
000076e4393db355  vmovaps xmm6, [rsp+0x60]
000076e4393db35b  vmovaps xmm7, [rsp+0x70]
000076e4393db361  vmovaps xmm8, [rsp+0x80]
000076e4393db36a  vmovaps xmm10, [rsp+0x90]
000076e4393db373  vmovaps xmm11, [rsp+0xA0]
000076e4393db37c  vmovaps xmm12, [rsp+0xB0]
000076e4393db385  vmovaps xmm13, [rsp+0xC0]
000076e4393db38e  vmovaps xmm14, [rsp+0xD0]
000076e4393db397  vmovaps xmm15, [rsp+0xE0]
000076e4393db3a0  add rsp, 0xF0
000076e4393db3a7  pop r11
000076e4393db3a9  pop r10
000076e4393db3ab  pop r9
000076e4393db3ad  pop r8
000076e4393db3af  pop rsi
000076e4393db3b0  pop rdi
000076e4393db3b1  pop rdx
000076e4393db3b2  pop rcx
000076e4393db3b3  pop rax
000076e4393db3b4  add rsp, 0x08
000076e4393db3b8  jmp 0x000076E4393D662F
000076e4393db3bd  sub rsp, 0x08
000076e4393db3c1  push rax
000076e4393db3c2  push rcx
000076e4393db3c3  push rdx
000076e4393db3c4  push rdi
000076e4393db3c5  push rsi
000076e4393db3c6  push r8
000076e4393db3c8  push r9
000076e4393db3ca  push r10
000076e4393db3cc  push r11
000076e4393db3ce  sub rsp, 0xF0
000076e4393db3d5  vmovaps [rsp], xmm0
000076e4393db3da  vmovaps [rsp+0x10], xmm1
000076e4393db3e0  vmovaps [rsp+0x20], xmm2
000076e4393db3e6  vmovaps [rsp+0x30], xmm3
000076e4393db3ec  vmovaps [rsp+0x40], xmm4
000076e4393db3f2  vmovaps [rsp+0x50], xmm5
000076e4393db3f8  vmovaps [rsp+0x60], xmm6
000076e4393db3fe  vmovaps [rsp+0x70], xmm7
000076e4393db404  vmovaps [rsp+0x80], xmm8
000076e4393db40d  vmovaps [rsp+0x90], xmm9
000076e4393db416  vmovaps [rsp+0xA0], xmm10
000076e4393db41f  vmovaps [rsp+0xB0], xmm11
000076e4393db428  vmovaps [rsp+0xC0], xmm12
000076e4393db431  vmovaps [rsp+0xD0], xmm13
000076e4393db43a  vmovaps [rsp+0xE0], xmm14
000076e4393db443  sub rsp, 0x30
000076e4393db447  movaps [rsp], xmm15
000076e4393db44c  movaps [rsp+0x10], xmm11
000076e4393db452  movaps [rsp+0x20], xmm12
000076e4393db458  lea rdi, [rsp]
000076e4393db45c  mov esi, 0x00
000076e4393db461  mov rax, 0x63DBDEB43530
000076e4393db46b  call rax
000076e4393db46d  movaps xmm15, [rsp]
000076e4393db472  add rsp, 0x30
000076e4393db476  vmovaps xmm0, [rsp]
000076e4393db47b  vmovaps xmm1, [rsp+0x10]
000076e4393db481  vmovaps xmm2, [rsp+0x20]
000076e4393db487  vmovaps xmm3, [rsp+0x30]
000076e4393db48d  vmovaps xmm4, [rsp+0x40]
000076e4393db493  vmovaps xmm5, [rsp+0x50]
000076e4393db499  vmovaps xmm6, [rsp+0x60]
000076e4393db49f  vmovaps xmm7, [rsp+0x70]
000076e4393db4a5  vmovaps xmm8, [rsp+0x80]
000076e4393db4ae  vmovaps xmm9, [rsp+0x90]
000076e4393db4b7  vmovaps xmm10, [rsp+0xA0]
000076e4393db4c0  vmovaps xmm11, [rsp+0xB0]
000076e4393db4c9  vmovaps xmm12, [rsp+0xC0]
000076e4393db4d2  vmovaps xmm13, [rsp+0xD0]
000076e4393db4db  vmovaps xmm14, [rsp+0xE0]
000076e4393db4e4  add rsp, 0xF0
000076e4393db4eb  pop r11
000076e4393db4ed  pop r10
000076e4393db4ef  pop r9
000076e4393db4f1  pop r8
000076e4393db4f3  pop rsi
000076e4393db4f4  pop rdi
000076e4393db4f5  pop rdx
000076e4393db4f6  pop rcx
000076e4393db4f7  pop rax
000076e4393db4f8  add rsp, 0x08
000076e4393db4fc  jmp 0x000076E4393D664A
000076e4393db501  sub rsp, 0x08
000076e4393db505  push rax
000076e4393db506  push rcx
000076e4393db507  push rdx
000076e4393db508  push rdi
000076e4393db509  push rsi
000076e4393db50a  push r8
000076e4393db50c  push r9
000076e4393db50e  push r10
000076e4393db510  push r11
000076e4393db512  sub rsp, 0xF0
000076e4393db519  vmovaps [rsp], xmm0
000076e4393db51e  vmovaps [rsp+0x10], xmm1
000076e4393db524  vmovaps [rsp+0x20], xmm2
000076e4393db52a  vmovaps [rsp+0x30], xmm3
000076e4393db530  vmovaps [rsp+0x40], xmm4
000076e4393db536  vmovaps [rsp+0x50], xmm5
000076e4393db53c  vmovaps [rsp+0x60], xmm6
000076e4393db542  vmovaps [rsp+0x70], xmm7
000076e4393db548  vmovaps [rsp+0x80], xmm8
000076e4393db551  vmovaps [rsp+0x90], xmm9
000076e4393db55a  vmovaps [rsp+0xA0], xmm10
000076e4393db563  vmovaps [rsp+0xB0], xmm11
000076e4393db56c  vmovaps [rsp+0xC0], xmm12
000076e4393db575  vmovaps [rsp+0xD0], xmm14
000076e4393db57e  vmovaps [rsp+0xE0], xmm15
000076e4393db587  sub rsp, 0x30
000076e4393db58b  movaps [rsp], xmm13
000076e4393db590  movaps [rsp+0x10], xmm10
000076e4393db596  movaps [rsp+0x20], xmm14
000076e4393db59c  lea rdi, [rsp]
000076e4393db5a0  mov esi, 0x00
000076e4393db5a5  mov rax, 0x63DBDEB43530
000076e4393db5af  call rax
000076e4393db5b1  movaps xmm13, [rsp]
000076e4393db5b6  add rsp, 0x30
000076e4393db5ba  vmovaps xmm0, [rsp]
000076e4393db5bf  vmovaps xmm1, [rsp+0x10]
000076e4393db5c5  vmovaps xmm2, [rsp+0x20]
000076e4393db5cb  vmovaps xmm3, [rsp+0x30]
000076e4393db5d1  vmovaps xmm4, [rsp+0x40]
000076e4393db5d7  vmovaps xmm5, [rsp+0x50]
000076e4393db5dd  vmovaps xmm6, [rsp+0x60]
000076e4393db5e3  vmovaps xmm7, [rsp+0x70]
000076e4393db5e9  vmovaps xmm8, [rsp+0x80]
000076e4393db5f2  vmovaps xmm9, [rsp+0x90]
000076e4393db5fb  vmovaps xmm10, [rsp+0xA0]
000076e4393db604  vmovaps xmm11, [rsp+0xB0]
000076e4393db60d  vmovaps xmm12, [rsp+0xC0]
000076e4393db616  vmovaps xmm14, [rsp+0xD0]
000076e4393db61f  vmovaps xmm15, [rsp+0xE0]
000076e4393db628  add rsp, 0xF0
000076e4393db62f  pop r11
000076e4393db631  pop r10
000076e4393db633  pop r9
000076e4393db635  pop r8
000076e4393db637  pop rsi
000076e4393db638  pop rdi
000076e4393db639  pop rdx
000076e4393db63a  pop rcx
000076e4393db63b  pop rax
000076e4393db63c  add rsp, 0x08
000076e4393db640  jmp 0x000076E4393D666D
000076e4393db645  sub rsp, 0x08
000076e4393db649  push rax
000076e4393db64a  push rcx
000076e4393db64b  push rdx
000076e4393db64c  push rdi
000076e4393db64d  push rsi
000076e4393db64e  push r8
000076e4393db650  push r9
000076e4393db652  push r10
000076e4393db654  push r11
000076e4393db656  sub rsp, 0xF0
000076e4393db65d  vmovaps [rsp], xmm0
000076e4393db662  vmovaps [rsp+0x10], xmm1
000076e4393db668  vmovaps [rsp+0x20], xmm2
000076e4393db66e  vmovaps [rsp+0x30], xmm3
000076e4393db674  vmovaps [rsp+0x40], xmm4
000076e4393db67a  vmovaps [rsp+0x50], xmm5
000076e4393db680  vmovaps [rsp+0x60], xmm6
000076e4393db686  vmovaps [rsp+0x70], xmm7
000076e4393db68c  vmovaps [rsp+0x80], xmm8
000076e4393db695  vmovaps [rsp+0x90], xmm9
000076e4393db69e  vmovaps [rsp+0xA0], xmm10
000076e4393db6a7  vmovaps [rsp+0xB0], xmm11
000076e4393db6b0  vmovaps [rsp+0xC0], xmm12
000076e4393db6b9  vmovaps [rsp+0xD0], xmm13
000076e4393db6c2  vmovaps [rsp+0xE0], xmm15
000076e4393db6cb  sub rsp, 0x30
000076e4393db6cf  movaps [rsp], xmm14
000076e4393db6d4  movaps [rsp+0x10], xmm1
000076e4393db6d9  movaps [rsp+0x20], xmm7
000076e4393db6de  lea rdi, [rsp]
000076e4393db6e2  mov esi, 0x00
000076e4393db6e7  mov rax, 0x63DBDEB43530
000076e4393db6f1  call rax
000076e4393db6f3  movaps xmm14, [rsp]
000076e4393db6f8  add rsp, 0x30
000076e4393db6fc  vmovaps xmm0, [rsp]
000076e4393db701  vmovaps xmm1, [rsp+0x10]
000076e4393db707  vmovaps xmm2, [rsp+0x20]
000076e4393db70d  vmovaps xmm3, [rsp+0x30]
000076e4393db713  vmovaps xmm4, [rsp+0x40]
000076e4393db719  vmovaps xmm5, [rsp+0x50]
000076e4393db71f  vmovaps xmm6, [rsp+0x60]
000076e4393db725  vmovaps xmm7, [rsp+0x70]
000076e4393db72b  vmovaps xmm8, [rsp+0x80]
000076e4393db734  vmovaps xmm9, [rsp+0x90]
000076e4393db73d  vmovaps xmm10, [rsp+0xA0]
000076e4393db746  vmovaps xmm11, [rsp+0xB0]
000076e4393db74f  vmovaps xmm12, [rsp+0xC0]
000076e4393db758  vmovaps xmm13, [rsp+0xD0]
000076e4393db761  vmovaps xmm15, [rsp+0xE0]
000076e4393db76a  add rsp, 0xF0
000076e4393db771  pop r11
000076e4393db773  pop r10
000076e4393db775  pop r9
000076e4393db777  pop r8
000076e4393db779  pop rsi
000076e4393db77a  pop rdi
000076e4393db77b  pop rdx
000076e4393db77c  pop rcx
000076e4393db77d  pop rax
000076e4393db77e  add rsp, 0x08
000076e4393db782  jmp 0x000076E4393D6690
000076e4393db787  sub rsp, 0x08
000076e4393db78b  push rax
000076e4393db78c  push rcx
000076e4393db78d  push rdx
000076e4393db78e  push rdi
000076e4393db78f  push rsi
000076e4393db790  push r8
000076e4393db792  push r9
000076e4393db794  push r10
000076e4393db796  push r11
000076e4393db798  sub rsp, 0xF0
000076e4393db79f  vmovaps [rsp], xmm0
000076e4393db7a4  vmovaps [rsp+0x10], xmm2
000076e4393db7aa  vmovaps [rsp+0x20], xmm3
000076e4393db7b0  vmovaps [rsp+0x30], xmm4
000076e4393db7b6  vmovaps [rsp+0x40], xmm5
000076e4393db7bc  vmovaps [rsp+0x50], xmm6
000076e4393db7c2  vmovaps [rsp+0x60], xmm7
000076e4393db7c8  vmovaps [rsp+0x70], xmm8
000076e4393db7ce  vmovaps [rsp+0x80], xmm9
000076e4393db7d7  vmovaps [rsp+0x90], xmm10
000076e4393db7e0  vmovaps [rsp+0xA0], xmm11
000076e4393db7e9  vmovaps [rsp+0xB0], xmm12
000076e4393db7f2  vmovaps [rsp+0xC0], xmm13
000076e4393db7fb  vmovaps [rsp+0xD0], xmm14
000076e4393db804  vmovaps [rsp+0xE0], xmm15
000076e4393db80d  sub rsp, 0x30
000076e4393db811  movaps [rsp], xmm1
000076e4393db815  movaps [rsp+0x10], xmm8
000076e4393db81b  movaps [rsp+0x20], xmm9
000076e4393db821  lea rdi, [rsp]
000076e4393db825  mov esi, 0x00
000076e4393db82a  mov rax, 0x63DBDEB43530
000076e4393db834  call rax
000076e4393db836  movaps xmm1, [rsp]
000076e4393db83a  add rsp, 0x30
000076e4393db83e  vmovaps xmm0, [rsp]
000076e4393db843  vmovaps xmm2, [rsp+0x10]
000076e4393db849  vmovaps xmm3, [rsp+0x20]
000076e4393db84f  vmovaps xmm4, [rsp+0x30]
000076e4393db855  vmovaps xmm5, [rsp+0x40]
000076e4393db85b  vmovaps xmm6, [rsp+0x50]
000076e4393db861  vmovaps xmm7, [rsp+0x60]
000076e4393db867  vmovaps xmm8, [rsp+0x70]
000076e4393db86d  vmovaps xmm9, [rsp+0x80]
000076e4393db876  vmovaps xmm10, [rsp+0x90]
000076e4393db87f  vmovaps xmm11, [rsp+0xA0]
000076e4393db888  vmovaps xmm12, [rsp+0xB0]
000076e4393db891  vmovaps xmm13, [rsp+0xC0]
000076e4393db89a  vmovaps xmm14, [rsp+0xD0]
000076e4393db8a3  vmovaps xmm15, [rsp+0xE0]
000076e4393db8ac  add rsp, 0xF0
000076e4393db8b3  pop r11
000076e4393db8b5  pop r10
000076e4393db8b7  pop r9
000076e4393db8b9  pop r8
000076e4393db8bb  pop rsi
000076e4393db8bc  pop rdi
000076e4393db8bd  pop rdx
000076e4393db8be  pop rcx
000076e4393db8bf  pop rax
000076e4393db8c0  add rsp, 0x08
000076e4393db8c4  jmp 0x000076E4393D66B2
000076e4393db8c9  call 0x000076E4392B3E40
000076e4393db8ce  jmp 0x000076E4393D66C0
000076e4393db8d3  call 0x000076E43920C380
000076e4393db8d8  jmp 0x000076E4393D66CA
000076e4393db8dd  call 0x000076E43920D600
000076e4393db8e2  jmp 0x000076E4393D66D4
000076e4393db8e7  call 0x000076E4391FF540
000076e4393db8ec  jmp 0x000076E4393D66DE
000076e4393db8f1  int3
000076e4393db8f2  nop [rax+rax*1], ax
000076e4393db8fb  nop [rax+rax*1], eax
000076e4393db900  mov eax, [r15+0x48]
000076e4393db904  lea r14d, [eax+0x01]
000076e4393db909  mov [rsp+0x10], r14d
000076e4393db90e  mov r14d, r14d
000076e4393db911  mov [r15+0x48], r14
000076e4393db915  xor eax, eax
000076e4393db917  mov r14d, [rsp+0x10]
000076e4393db91c  cmp r14d, 0x1F4
000076e4393db923  cmc
000076e4393db924  lahf
000076e4393db925  seto al
000076e4393db928  mov [r15+0x108], eax
000076e4393db92f  mov eax, [r15+0x108]
000076e4393db936  sahf
000076e4393db937  jnz 0x000076E4393DB969
000076e4393db939  cmp dword ptr [r15+0x318], 0x00
000076e4393db941  jz 0x000076E4393E1AB0
000076e4393db947  nop [rax+rax*1], ax
000076e4393db950  nop [rax+rax*1], eax
000076e4393db958  mov eax, 0x410450
000076e4393db95d  mov [r15+0x100], rax
000076e4393db964  jmp 0x000076E4391FE110
000076e4393db969  cmp dword ptr [r15+0x318], 0x00
000076e4393db971  jz 0x000076E4393DB9A0
000076e4393db977  nop [rax+rax*1], ax
000076e4393db980  nop [rax+rax*1], eax
000076e4393db988  mov eax, 0x410274
000076e4393db98d  mov [r15+0x100], rax
000076e4393db994  jmp 0x000076E4391FE110
000076e4393db999  int3
000076e4393db99a  int3
000076e4393db99b  nop [rax+rax*1], eax
000076e4393db9a0  mov rax, [r15+0x40]
000076e4393db9a4  movaps xmm1, [r15+0x1D0]
000076e4393db9ac  vmovaps [rsp+0x10], xmm1
000076e4393db9b2  vmovaps xmm15, [rsp+0x10]
000076e4393db9b8  por xmm1, xmm15
000076e4393db9bd  movaps xmm14, [r15+0x1A0]
000076e4393db9c5  vmovaps [rsp+0x10], xmm14
000076e4393db9cb  vmovaps xmm13, [rsp+0x10]
000076e4393db9d1  por xmm14, xmm13
000076e4393db9d6  lea r14, [rax+0x30]
000076e4393db9da  mov r12, [r13+r14*1]
000076e4393db9df  lea r14, [rax+0x38]
000076e4393db9e3  mov r11, [r13+r14*1]
000076e4393db9e8  movq xmm13, r12
000076e4393db9ed  movq xmm12, r11
000076e4393db9f2  movq xmm13, xmm13
000076e4393db9f7  vmovaps [rsp+0x10], xmm13
000076e4393db9fd  movq xmm13, xmm13
000076e4393dba02  movaps [r15+0x130], xmm13
000076e4393dba0a  movq xmm12, xmm12
000076e4393dba0f  vmovaps [rsp+0x20], xmm12
000076e4393dba15  movq xmm12, xmm12
000076e4393dba1a  movaps [r15+0x280], xmm12
000076e4393dba22  movaps xmm13, [r15+0x270]
000076e4393dba2a  vmovaps [rsp+0x30], xmm13
000076e4393dba30  vmovaps xmm12, [rsp+0x30]
000076e4393dba36  por xmm13, xmm12
000076e4393dba3b  lea r14, [rax+0x20]
000076e4393dba3f  mov r12, [r13+r14*1]
000076e4393dba44  lea r14, [rax+0x28]
000076e4393dba48  mov r11, [r13+r14*1]
000076e4393dba4d  movq xmm12, r12
000076e4393dba52  movq xmm11, r11
000076e4393dba57  movq xmm12, xmm12
000076e4393dba5c  vmovaps [rsp+0x30], xmm12
000076e4393dba62  movq xmm12, xmm12
000076e4393dba67  movaps [r15+0x150], xmm12
000076e4393dba6f  movq xmm11, xmm11
000076e4393dba74  vmovaps [rsp+0x40], xmm11
000076e4393dba7a  movq xmm11, xmm11
000076e4393dba7f  movaps [r15+0x140], xmm11
000076e4393dba87  lea r14, [rax+0x10]
000076e4393dba8b  mov r12, [r13+r14*1]
000076e4393dba90  lea r14, [rax+0x18]
000076e4393dba94  mov r11, [r13+r14*1]
000076e4393dba99  movq xmm12, r12
000076e4393dba9e  movq xmm11, r11
000076e4393dbaa3  movq xmm12, xmm12
000076e4393dbaa8  vmovaps [rsp+0x50], xmm12
000076e4393dbaae  movq xmm12, xmm12
000076e4393dbab3  movaps [r15+0x170], xmm12
000076e4393dbabb  movq xmm11, xmm11
000076e4393dbac0  vmovaps [rsp+0x60], xmm11
000076e4393dbac6  movq xmm11, xmm11
000076e4393dbacb  movaps [r15+0x160], xmm11
000076e4393dbad3  mov r14, [r13+rax*1]
000076e4393dbad8  vmovq xmm12, r14
000076e4393dbadd  vpbroadcastq xmm12, xmm12
000076e4393dbae2  lea r14, [rax+0x08]
000076e4393dbae6  mov rax, [r13+r14*1]
000076e4393dbaeb  movq xmm11, rax
000076e4393dbaf0  movaps [r15+0x230], xmm11
000076e4393dbaf8  mov rax, [r15+0xF8]
000076e4393dbaff  lea r14, [rax+0x50]
000076e4393dbb03  movups xmm11, [r13+r14*1]
000076e4393dbb09  lea r14, [rax+0x60]
000076e4393dbb0d  movups xmm10, [r13+r14*1]
000076e4393dbb13  lea r14, [rax+0x30]
000076e4393dbb17  movups xmm9, [r13+r14*1]
000076e4393dbb1d  mov r14, [r15+0x50]
000076e4393dbb21  mov [r15+0x60], r14
000076e4393dbb25  mov qword ptr [r15+0x58], 0x40
000076e4393dbb2d  movaps xmm8, xmm12
000076e4393dbb31  mulpd xmm8, xmm15
000076e4393dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000076e4393dbb3c  ptest xmm7, xmm7
000076e4393dbb41  jnz 0x000076E4393DC96A
000076e4393dbb47  movq xmm15, qword ptr [r15+0x230]
000076e4393dbb50  vmovaps [rsp+0x70], xmm15
000076e4393dbb56  vpermilpd xmm15, xmm15, 0x00
000076e4393dbb5c  movaps xmm7, xmm9
000076e4393dbb60  mulpd xmm7, xmm15
000076e4393dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000076e4393dbb6a  ptest xmm6, xmm6
000076e4393dbb6f  jnz 0x000076E4393DCAAE
000076e4393dbb75  vxorps xmm15, xmm15, xmm15
000076e4393dbb7a  vpbroadcastq xmm15, xmm15
000076e4393dbb7f  movaps xmm9, xmm12
000076e4393dbb83  mulpd xmm9, xmm10
000076e4393dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000076e4393dbb8e  ptest xmm6, xmm6
000076e4393dbb93  jnz 0x000076E4393DCBF0
000076e4393dbb99  movaps xmm10, xmm12
000076e4393dbb9d  mulpd xmm10, xmm11
000076e4393dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000076e4393dbba8  ptest xmm6, xmm6
000076e4393dbbad  jnz 0x000076E4393DCD34
000076e4393dbbb3  movaps xmm11, [r15+0x1F0]
000076e4393dbbbb  movaps xmm6, xmm12
000076e4393dbbbf  mulpd xmm6, xmm11
000076e4393dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000076e4393dbbc9  ptest xmm5, xmm5
000076e4393dbbce  jnz 0x000076E4393DCE78
000076e4393dbbd4  movaps xmm12, [r15+0x2A0]
000076e4393dbbdc  vmovaps [rsp+0x80], xmm12
000076e4393dbbe5  vmovaps xmm11, [rsp+0x80]
000076e4393dbbee  por xmm12, xmm11
000076e4393dbbf3  movaps xmm11, [r15+0x250]
000076e4393dbbfb  vmovaps [rsp+0x80], xmm11
000076e4393dbc04  vmovaps xmm5, [rsp+0x80]
000076e4393dbc0d  por xmm11, xmm5
000076e4393dbc12  vmovaps xmm4, [rsp+0x70]
000076e4393dbc18  vpermilpd xmm4, xmm4, 0x00
000076e4393dbc1e  movaps xmm3, xmm5
000076e4393dbc21  mulpd xmm3, xmm4
000076e4393dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000076e4393dbc2a  ptest xmm2, xmm2
000076e4393dbc2f  jnz 0x000076E4393DCFBA
000076e4393dbc35  mov [rsp+0x80], rax
000076e4393dbc3d  xor eax, eax
000076e4393dbc3f  mov r12d, 0x40
000076e4393dbc45  mov r11d, 0x200
000076e4393dbc4b  cmp r12, r11
000076e4393dbc4e  cmc
000076e4393dbc4f  lahf
000076e4393dbc50  seto al
000076e4393dbc53  mov [r15+0x108], eax
000076e4393dbc5a  movaps xmm5, xmm8
000076e4393dbc5e  addpd xmm5, xmm15
000076e4393dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000076e4393dbc68  ptest xmm4, xmm4
000076e4393dbc6d  jnz 0x000076E4393DD0FA
000076e4393dbc73  movaps xmm8, [r15+0x1B0]
000076e4393dbc7b  movaps xmm4, xmm9
000076e4393dbc7f  addpd xmm4, xmm8
000076e4393dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000076e4393dbc89  ptest xmm2, xmm2
000076e4393dbc8e  jnz 0x000076E4393DD23C
000076e4393dbc94  movaps xmm9, xmm10
000076e4393dbc98  addpd xmm9, xmm8
000076e4393dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000076e4393dbca3  ptest xmm2, xmm2
000076e4393dbca8  jnz 0x000076E4393DD37E
000076e4393dbcae  movaps xmm10, [r15+0x2F0]
000076e4393dbcb6  vmovaps [rsp+0x90], xmm10
000076e4393dbcbf  vmovaps xmm8, [rsp+0x90]
000076e4393dbcc8  por xmm10, xmm8
000076e4393dbccd  movaps xmm8, [r15+0x2E0]
000076e4393dbcd5  vmovaps [rsp+0x90], xmm8
000076e4393dbcde  vmovaps xmm2, [rsp+0x90]
000076e4393dbce7  por xmm8, xmm2
000076e4393dbcec  movaps xmm2, [r15+0x2D0]
000076e4393dbcf4  vmovaps [rsp+0x90], xmm2
000076e4393dbcfd  vmovaps [rsp+0xA0], xmm1
000076e4393dbd06  vmovaps xmm1, [rsp+0x90]
000076e4393dbd0f  por xmm2, xmm1
000076e4393dbd13  movaps xmm1, [r15+0x200]
000076e4393dbd1b  vmovaps [rsp+0x90], xmm1
000076e4393dbd24  vmovaps [rsp+0xB0], xmm15
000076e4393dbd2d  vmovaps xmm15, [rsp+0x90]
000076e4393dbd36  por xmm1, xmm15
000076e4393dbd3b  movaps xmm15, [r15+0x1C0]
000076e4393dbd43  vmovaps [rsp+0x90], xmm15
000076e4393dbd4c  vmovaps [rsp+0xC0], xmm1
000076e4393dbd55  vmovaps xmm1, [rsp+0x90]
000076e4393dbd5e  por xmm15, xmm1
000076e4393dbd63  movaps xmm1, [r15+0x190]
000076e4393dbd6b  vmovaps [rsp+0x90], xmm1
000076e4393dbd74  vmovaps [rsp+0xD0], xmm15
000076e4393dbd7d  vmovaps xmm15, [rsp+0x90]
000076e4393dbd86  por xmm1, xmm15
000076e4393dbd8b  movaps xmm15, [r15+0x300]
000076e4393dbd93  vmovaps [rsp+0x90], xmm15
000076e4393dbd9c  vmovaps [rsp+0xE0], xmm1
000076e4393dbda5  vmovaps xmm1, [rsp+0x90]
000076e4393dbdae  por xmm15, xmm1
000076e4393dbdb3  mov rax, [rsp+0x80]
000076e4393dbdbb  lea r12, [rax+0xA0]
000076e4393dbdc2  movups xmm1, [r13+r12*1]
000076e4393dbdc8  lea r12, [rax+0xB0]
000076e4393dbdcf  vmovaps [rsp+0x80], xmm1
000076e4393dbdd8  movups xmm1, [r13+r12*1]
000076e4393dbdde  vmovaps [rsp+0x90], xmm1
000076e4393dbde7  vmovaps [rsp+0xF0], xmm15
000076e4393dbdf0  vmovaps xmm15, [rsp+0xB0]
000076e4393dbdf9  vmovaps [rsp+0xB0], xmm14
000076e4393dbe02  movaps xmm1, xmm6
000076e4393dbe05  addpd xmm1, xmm15
000076e4393dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000076e4393dbe0f  ptest xmm14, xmm14
000076e4393dbe15  jnz 0x000076E4393DD4D6
000076e4393dbe1b  lea r12, [rax+0xF0]
000076e4393dbe22  movups xmm15, [r13+r12*1]
000076e4393dbe28  movaps xmm14, xmm4
000076e4393dbe2c  addpd xmm14, xmm3
000076e4393dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000076e4393dbe37  ptest xmm6, xmm6
000076e4393dbe3c  jnz 0x000076E4393DD621
000076e4393dbe42  movaps xmm6, xmm9
000076e4393dbe46  addpd xmm6, xmm7
000076e4393dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000076e4393dbe4f  ptest xmm4, xmm4
000076e4393dbe54  jnz 0x000076E4393DD763
000076e4393dbe5a  vmovaps xmm9, [rsp+0x70]
000076e4393dbe60  vpermilpd xmm9, xmm9, 0x00
000076e4393dbe66  vmovaps xmm4, [rsp+0x90]
000076e4393dbe6f  movaps xmm7, xmm4
000076e4393dbe72  mulpd xmm7, xmm9
000076e4393dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000076e4393dbe7c  ptest xmm3, xmm3
000076e4393dbe81  jnz 0x000076E4393DD8A4
000076e4393dbe87  vmovaps xmm9, [rsp+0x50]
000076e4393dbe8d  vpermilpd xmm9, xmm9, 0x00
000076e4393dbe93  movaps xmm4, xmm15
000076e4393dbe97  mulpd xmm4, xmm9
000076e4393dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000076e4393dbea1  ptest xmm3, xmm3
000076e4393dbea6  jnz 0x000076E4393DD9E5
000076e4393dbeac  lea r12, [rax+0xE0]
000076e4393dbeb3  movups xmm15, [r13+r12*1]
000076e4393dbeb9  vmovaps xmm9, [rsp+0x70]
000076e4393dbebf  vpermilpd xmm9, xmm9, 0x00
000076e4393dbec5  vmovaps [rsp+0x70], xmm1
000076e4393dbecb  vmovaps xmm1, [rsp+0x80]
000076e4393dbed4  vmovaps [rsp+0x80], xmm15
000076e4393dbedd  movaps xmm3, xmm1
000076e4393dbee0  mulpd xmm3, xmm9
000076e4393dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000076e4393dbeea  ptest xmm15, xmm15
000076e4393dbef0  jnz 0x000076E4393DDB31
000076e4393dbef6  vmovaps xmm1, [rsp+0xF0]
000076e4393dbeff  vmovaps xmm15, [rsp+0xF0]
000076e4393dbf08  por xmm1, xmm15
000076e4393dbf0d  movaps [r15+0x300], xmm1
000076e4393dbf15  vmovaps xmm15, [rsp+0xE0]
000076e4393dbf1e  vmovaps xmm9, [rsp+0xE0]
000076e4393dbf27  por xmm15, xmm9
000076e4393dbf2c  movaps [r15+0x190], xmm15
000076e4393dbf34  vmovaps xmm9, [rsp+0x50]
000076e4393dbf3a  vpermilpd xmm9, xmm9, 0x00
000076e4393dbf40  vmovaps [rsp+0x90], xmm1
000076e4393dbf49  vmovaps [rsp+0xE0], xmm15
000076e4393dbf52  vmovaps xmm15, [rsp+0x80]
000076e4393dbf5b  vmovaps [rsp+0x80], xmm14
000076e4393dbf64  movaps xmm1, xmm15
000076e4393dbf68  mulpd xmm1, xmm9
000076e4393dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000076e4393dbf72  ptest xmm14, xmm14
000076e4393dbf78  jnz 0x000076E4393DDC72
000076e4393dbf7e  lea r12, [rax+0x90]
000076e4393dbf85  movups xmm15, [r13+r12*1]
000076e4393dbf8b  vmovaps xmm14, [rsp+0xD0]
000076e4393dbf94  vmovaps xmm9, [rsp+0xD0]
000076e4393dbf9d  por xmm14, xmm9
000076e4393dbfa2  movaps [r15+0x1C0], xmm14
000076e4393dbfaa  vmovaps xmm9, [rsp+0xC0]
000076e4393dbfb3  vmovaps [rsp+0xD0], xmm1
000076e4393dbfbc  vmovaps xmm1, [rsp+0xC0]
000076e4393dbfc5  por xmm9, xmm1
000076e4393dbfca  movaps [r15+0x200], xmm9
000076e4393dbfd2  vmovaps [rsp+0xC0], xmm2
000076e4393dbfdb  vmovaps xmm1, [rsp+0xC0]
000076e4393dbfe4  por xmm2, xmm1
000076e4393dbfe8  movaps [r15+0x2D0], xmm2
000076e4393dbff0  vmovaps [rsp+0xC0], xmm8
000076e4393dbff9  vmovaps xmm1, [rsp+0xC0]
000076e4393dc002  por xmm8, xmm1
000076e4393dc007  movaps [r15+0x2E0], xmm8
000076e4393dc00f  vmovaps [rsp+0xC0], xmm15
000076e4393dc018  movaps xmm1, xmm5
000076e4393dc01b  addpd xmm1, xmm7
000076e4393dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000076e4393dc024  ptest xmm15, xmm15
000076e4393dc02a  jnz 0x000076E4393DDDBE
000076e4393dc030  vmovaps xmm15, [rsp+0x50]
000076e4393dc036  vpermilpd xmm15, xmm15, 0x00
000076e4393dc03c  vmovaps xmm5, [rsp+0xC0]
000076e4393dc045  vmovaps [rsp+0xC0], xmm1
000076e4393dc04e  movaps xmm7, xmm5
000076e4393dc051  mulpd xmm7, xmm15
000076e4393dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000076e4393dc05b  ptest xmm1, xmm1
000076e4393dc060  jnz 0x000076E4393DDEFE
000076e4393dc066  lea r12, [rax+0x80]
000076e4393dc06d  movups xmm1, [r13+r12*1]
000076e4393dc073  vmovaps xmm5, [rsp+0x70]
000076e4393dc079  vmovaps [rsp+0x70], xmm1
000076e4393dc07f  movaps xmm15, xmm5
000076e4393dc083  addpd xmm15, xmm3
000076e4393dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393dc08e  ptest xmm1, xmm1
000076e4393dc093  jnz 0x000076E4393DE049
000076e4393dc099  vmovaps xmm5, [rsp+0x80]
000076e4393dc0a2  movaps xmm1, xmm5
000076e4393dc0a5  addpd xmm1, xmm4
000076e4393dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000076e4393dc0ae  ptest xmm3, xmm3
000076e4393dc0b3  jnz 0x000076E4393DE18B
000076e4393dc0b9  vmovaps [rsp+0x80], xmm10
000076e4393dc0c2  vmovaps xmm5, [rsp+0x80]
000076e4393dc0cb  por xmm10, xmm5
000076e4393dc0d0  movaps [r15+0x2F0], xmm10
000076e4393dc0d8  vmovaps xmm5, [rsp+0x50]
000076e4393dc0de  vpermilpd xmm5, xmm5, 0x00
000076e4393dc0e4  vmovaps xmm3, [rsp+0x70]
000076e4393dc0ea  vmovaps [rsp+0x50], xmm1
000076e4393dc0f0  movaps xmm4, xmm3
000076e4393dc0f3  mulpd xmm4, xmm5
000076e4393dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000076e4393dc0fc  ptest xmm1, xmm1
000076e4393dc101  jnz 0x000076E4393DE2CB
000076e4393dc107  lea r12, [rax+0xD0]
000076e4393dc10e  movups xmm1, [r13+r12*1]
000076e4393dc114  vmovaps xmm3, [rsp+0xD0]
000076e4393dc11d  vmovaps [rsp+0x70], xmm1
000076e4393dc123  movaps xmm5, xmm6
000076e4393dc126  addpd xmm5, xmm3
000076e4393dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000076e4393dc12f  ptest xmm1, xmm1
000076e4393dc134  jnz 0x000076E4393DE415
000076e4393dc13a  vmovaps xmm1, [rsp+0x60]
000076e4393dc140  vpermilpd xmm1, xmm1, 0x00
000076e4393dc146  movaps xmm6, xmm9
000076e4393dc14a  mulpd xmm6, xmm1
000076e4393dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000076e4393dc153  ptest xmm3, xmm3
000076e4393dc158  jnz 0x000076E4393DE555
000076e4393dc15e  movaps [r15+0x260], xmm6
000076e4393dc166  vxorps xmm1, xmm1, xmm1
000076e4393dc16a  vpbroadcastq xmm1, xmm1
000076e4393dc16f  movaps [r15+0x1B0], xmm1
000076e4393dc177  vmovaps xmm1, [rsp+0x60]
000076e4393dc17d  vpermilpd xmm1, xmm1, 0x00
000076e4393dc183  vmovaps xmm3, [rsp+0x70]
000076e4393dc189  vmovaps [rsp+0x70], xmm15
000076e4393dc18f  movaps xmm9, xmm3
000076e4393dc193  mulpd xmm9, xmm1
000076e4393dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000076e4393dc19e  ptest xmm15, xmm15
000076e4393dc1a4  jnz 0x000076E4393DE696
000076e4393dc1aa  lea r12, [rax+0xC0]
000076e4393dc1b1  movups xmm1, [r13+r12*1]
000076e4393dc1b7  vmovaps xmm3, [rsp+0xC0]
000076e4393dc1c0  vmovaps [rsp+0x80], xmm1
000076e4393dc1c9  movaps xmm15, xmm3
000076e4393dc1cd  addpd xmm15, xmm7
000076e4393dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393dc1d8  ptest xmm1, xmm1
000076e4393dc1dd  jnz 0x000076E4393DE7E2
000076e4393dc1e3  vmovaps [rsp+0xC0], xmm13
000076e4393dc1ec  vmovaps xmm1, [rsp+0xC0]
000076e4393dc1f5  por xmm13, xmm1
000076e4393dc1fa  movaps [r15+0x270], xmm13
000076e4393dc202  vmovaps xmm1, [rsp+0xB0]
000076e4393dc20b  vmovaps xmm7, [rsp+0xB0]
000076e4393dc214  por xmm1, xmm7
000076e4393dc218  movaps [r15+0x1A0], xmm1
000076e4393dc220  vmovaps xmm1, [rsp+0x60]
000076e4393dc226  vpermilpd xmm1, xmm1, 0x00
000076e4393dc22c  vmovaps [rsp+0xB0], xmm1
000076e4393dc235  vmovaps xmm1, [rsp+0x80]
000076e4393dc23e  vmovaps [rsp+0x80], xmm15
000076e4393dc247  vmovaps xmm15, [rsp+0xB0]
000076e4393dc250  vmovaps [rsp+0xB0], xmm14
000076e4393dc259  movaps xmm3, xmm1
000076e4393dc25c  mulpd xmm3, xmm15
000076e4393dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000076e4393dc266  ptest xmm14, xmm14
000076e4393dc26c  jnz 0x000076E4393DE924
000076e4393dc272  lea r12, [rax+0x20]
000076e4393dc276  movups xmm1, [r13+r12*1]
000076e4393dc27c  movaps [r15+0x110], xmm1
000076e4393dc284  vmovaps xmm14, [rsp+0x70]
000076e4393dc28a  vmovaps [rsp+0x70], xmm1
000076e4393dc290  movaps xmm15, xmm14
000076e4393dc294  addpd xmm15, xmm4
000076e4393dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000076e4393dc29f  ptest xmm1, xmm1
000076e4393dc2a4  jnz 0x000076E4393DEA6F
000076e4393dc2aa  vmovaps xmm1, [rsp+0x60]
000076e4393dc2b0  vpermilpd xmm1, xmm1, 0x00
000076e4393dc2b6  movaps xmm14, xmm2
000076e4393dc2ba  mulpd xmm14, xmm1
000076e4393dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000076e4393dc2c5  ptest xmm4, xmm4
000076e4393dc2ca  jnz 0x000076E4393DEBB2
000076e4393dc2d0  vmovaps xmm4, [rsp+0x50]
000076e4393dc2d6  movaps xmm1, xmm4
000076e4393dc2d9  addpd xmm1, xmm9
000076e4393dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000076e4393dc2e3  ptest xmm2, xmm2
000076e4393dc2e8  jnz 0x000076E4393DECF4
000076e4393dc2ee  vmovaps xmm9, [rsp+0x30]
000076e4393dc2f4  vpermilpd xmm9, xmm9, 0x00
000076e4393dc2fa  vmovaps xmm2, [rsp+0x70]
000076e4393dc300  vmovaps [rsp+0x50], xmm1
000076e4393dc306  movaps xmm4, xmm2
000076e4393dc309  mulpd xmm4, xmm9
000076e4393dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000076e4393dc313  ptest xmm1, xmm1
000076e4393dc318  jnz 0x000076E4393DEE35
000076e4393dc31e  vmovaps xmm1, [rsp+0x30]
000076e4393dc324  vpermilpd xmm1, xmm1, 0x00
000076e4393dc32a  vmovaps xmm2, [rsp+0x90]
000076e4393dc333  vmovaps [rsp+0x60], xmm15
000076e4393dc339  movaps xmm9, xmm2
000076e4393dc33d  mulpd xmm9, xmm1
000076e4393dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000076e4393dc348  ptest xmm15, xmm15
000076e4393dc34e  jnz 0x000076E4393DEF76
000076e4393dc354  vmovaps xmm15, [rsp+0x80]
000076e4393dc35d  movaps xmm1, xmm15
000076e4393dc361  addpd xmm1, xmm6
000076e4393dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000076e4393dc36a  ptest xmm2, xmm2
000076e4393dc36f  jnz 0x000076E4393DF0B8
000076e4393dc375  movaps xmm15, xmm5
000076e4393dc379  addpd xmm15, xmm3
000076e4393dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000076e4393dc384  ptest xmm6, xmm6
000076e4393dc389  jnz 0x000076E4393DF1F9
000076e4393dc38f  vmovaps xmm6, [rsp+0x30]
000076e4393dc395  vpermilpd xmm6, xmm6, 0x00
000076e4393dc39b  movaps xmm5, xmm8
000076e4393dc39f  mulpd xmm5, xmm6
000076e4393dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000076e4393dc3a8  ptest xmm3, xmm3
000076e4393dc3ad  jnz 0x000076E4393DF33B
000076e4393dc3b3  vmovaps xmm8, [rsp+0x30]
000076e4393dc3b9  vpermilpd xmm8, xmm8, 0x00
000076e4393dc3bf  movaps xmm6, xmm10
000076e4393dc3c3  mulpd xmm6, xmm8
000076e4393dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000076e4393dc3cd  ptest xmm3, xmm3
000076e4393dc3d2  jnz 0x000076E4393DF47C
000076e4393dc3d8  vmovaps xmm8, [rsp+0x60]
000076e4393dc3de  movaps xmm10, xmm8
000076e4393dc3e2  addpd xmm10, xmm14
000076e4393dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000076e4393dc3ed  ptest xmm3, xmm3
000076e4393dc3f2  jnz 0x000076E4393DF5BE
000076e4393dc3f8  vmovaps xmm8, [rsp+0x50]
000076e4393dc3fe  movaps xmm14, xmm8
000076e4393dc402  addpd xmm14, xmm4
000076e4393dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000076e4393dc40d  ptest xmm3, xmm3
000076e4393dc412  jnz 0x000076E4393DF702
000076e4393dc418  vmovaps xmm8, [rsp+0x40]
000076e4393dc41e  vpermilpd xmm8, xmm8, 0x00
000076e4393dc424  movaps xmm4, xmm13
000076e4393dc428  mulpd xmm4, xmm8
000076e4393dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000076e4393dc432  ptest xmm3, xmm3
000076e4393dc437  jnz 0x000076E4393DF845
000076e4393dc43d  movaps xmm13, xmm15
000076e4393dc441  addpd xmm13, xmm9
000076e4393dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000076e4393dc44c  ptest xmm8, xmm8
000076e4393dc452  jnz 0x000076E4393DF987
000076e4393dc458  movaps xmm15, xmm1
000076e4393dc45c  addpd xmm15, xmm5
000076e4393dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000076e4393dc467  ptest xmm9, xmm9
000076e4393dc46d  jnz 0x000076E4393DFACB
000076e4393dc473  vmovaps [rsp+0x30], xmm11
000076e4393dc479  vmovaps xmm1, [rsp+0x30]
000076e4393dc47f  por xmm11, xmm1
000076e4393dc484  movaps [r15+0x250], xmm11
000076e4393dc48c  vmovaps [rsp+0x30], xmm12
000076e4393dc492  vmovaps xmm1, [rsp+0x30]
000076e4393dc498  por xmm12, xmm1
000076e4393dc49d  movaps [r15+0x2A0], xmm12
000076e4393dc4a5  vmovaps xmm1, [rsp+0xA0]
000076e4393dc4ae  vmovaps xmm11, [rsp+0xA0]
000076e4393dc4b7  por xmm1, xmm11
000076e4393dc4bc  movaps [r15+0x1D0], xmm1
000076e4393dc4c4  lea r12, [rax+0x40]
000076e4393dc4c8  movups xmm1, [r13+r12*1]
000076e4393dc4ce  movaps [r15+0x2C0], xmm1
000076e4393dc4d6  vmovaps xmm11, [rsp+0x40]
000076e4393dc4dc  vpermilpd xmm11, xmm11, 0x00
000076e4393dc4e2  vmovaps xmm8, [rsp+0xE0]
000076e4393dc4eb  movaps xmm9, xmm8
000076e4393dc4ef  mulpd xmm9, xmm11
000076e4393dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000076e4393dc4fa  ptest xmm5, xmm5
000076e4393dc4ff  jnz 0x000076E4393DFC17
000076e4393dc505  movaps xmm11, xmm10
000076e4393dc509  addpd xmm11, xmm6
000076e4393dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000076e4393dc514  ptest xmm8, xmm8
000076e4393dc51a  jnz 0x000076E4393DFD5B
000076e4393dc520  movaps xmm10, xmm14
000076e4393dc524  addpd xmm10, xmm4
000076e4393dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000076e4393dc52f  ptest xmm8, xmm8
000076e4393dc535  jnz 0x000076E4393DFE9E
000076e4393dc53b  vmovaps xmm14, [rsp+0x40]
000076e4393dc541  vpermilpd xmm14, xmm14, 0x00
000076e4393dc547  movaps xmm8, xmm1
000076e4393dc54b  mulpd xmm8, xmm14
000076e4393dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000076e4393dc556  ptest xmm6, xmm6
000076e4393dc55b  jnz 0x000076E4393DFFE1
000076e4393dc561  movaps xmm1, [r15+0x2B0]
000076e4393dc569  vmovaps xmm14, [rsp+0x40]
000076e4393dc56f  vpermilpd xmm14, xmm14, 0x00
000076e4393dc575  movaps xmm6, xmm1
000076e4393dc578  mulpd xmm6, xmm14
000076e4393dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000076e4393dc582  ptest xmm5, xmm5
000076e4393dc587  jnz 0x000076E4393E0124
000076e4393dc58d  vmovaps xmm1, [rsp+0x10]
000076e4393dc593  vpermilpd xmm1, xmm1, 0x00
000076e4393dc599  movaps xmm14, xmm12
000076e4393dc59d  mulpd xmm14, xmm1
000076e4393dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000076e4393dc5a8  ptest xmm5, xmm5
000076e4393dc5ad  jnz 0x000076E4393E0265
000076e4393dc5b3  movaps xmm1, xmm13
000076e4393dc5b7  addpd xmm1, xmm9
000076e4393dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000076e4393dc5c1  ptest xmm12, xmm12
000076e4393dc5c7  jnz 0x000076E4393E03A8
000076e4393dc5cd  vmovaps xmm13, [rsp+0x10]
000076e4393dc5d3  vpermilpd xmm13, xmm13, 0x00
000076e4393dc5d9  movaps xmm12, xmm7
000076e4393dc5dd  mulpd xmm12, xmm13
000076e4393dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000076e4393dc5e8  ptest xmm9, xmm9
000076e4393dc5ee  jnz 0x000076E4393E04EA
000076e4393dc5f4  movaps xmm13, xmm15
000076e4393dc5f8  addpd xmm13, xmm8
000076e4393dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000076e4393dc603  ptest xmm9, xmm9
000076e4393dc609  jnz 0x000076E4393E062D
000076e4393dc60f  movaps xmm15, [r15+0x290]
000076e4393dc617  vmovaps xmm9, [rsp+0x10]
000076e4393dc61d  vpermilpd xmm9, xmm9, 0x00
000076e4393dc623  movaps xmm8, xmm15
000076e4393dc627  mulpd xmm8, xmm9
000076e4393dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000076e4393dc632  ptest xmm7, xmm7
000076e4393dc637  jnz 0x000076E4393E0771
000076e4393dc63d  movaps xmm15, xmm11
000076e4393dc641  addpd xmm15, xmm6
000076e4393dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000076e4393dc64c  ptest xmm9, xmm9
000076e4393dc652  jnz 0x000076E4393E08B5
000076e4393dc658  movaps xmm11, [r15+0x1E0]
000076e4393dc660  vmovaps xmm9, [rsp+0x10]
000076e4393dc666  vpermilpd xmm9, xmm9, 0x00
000076e4393dc66c  movaps xmm7, xmm11
000076e4393dc670  mulpd xmm7, xmm9
000076e4393dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000076e4393dc67a  ptest xmm6, xmm6
000076e4393dc67f  jnz 0x000076E4393E09F8
000076e4393dc685  movaps xmm11, xmm10
000076e4393dc689  addpd xmm11, xmm14
000076e4393dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000076e4393dc694  ptest xmm9, xmm9
000076e4393dc69a  jnz 0x000076E4393E0B3A
000076e4393dc6a0  lea r12, [rax+0x70]
000076e4393dc6a4  movups xmm14, [r13+r12*1]
000076e4393dc6aa  movaps [r15+0x240], xmm14
000076e4393dc6b2  movaps xmm10, xmm1
000076e4393dc6b6  addpd xmm10, xmm12
000076e4393dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000076e4393dc6c1  ptest xmm9, xmm9
000076e4393dc6c7  jnz 0x000076E4393E0C88
000076e4393dc6cd  movaps [r15+0x170], xmm10
000076e4393dc6d5  vmovaps xmm1, [rsp+0x20]
000076e4393dc6db  vpermilpd xmm1, xmm1, 0x00
000076e4393dc6e1  movaps xmm12, xmm14
000076e4393dc6e5  mulpd xmm12, xmm1
000076e4393dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000076e4393dc6f0  ptest xmm9, xmm9
000076e4393dc6f6  jnz 0x000076E4393E0DCB
000076e4393dc6fc  vmovaps xmm1, [rsp+0x20]
000076e4393dc702  vpermilpd xmm1, xmm1, 0x00
000076e4393dc708  vmovaps xmm9, [rsp+0xB0]
000076e4393dc711  movaps xmm14, xmm9
000076e4393dc715  mulpd xmm14, xmm1
000076e4393dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000076e4393dc720  ptest xmm6, xmm6
000076e4393dc725  jnz 0x000076E4393E0F0E
000076e4393dc72b  movaps [r15+0x180], xmm14
000076e4393dc733  movaps xmm1, xmm13
000076e4393dc737  addpd xmm1, xmm8
000076e4393dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000076e4393dc741  ptest xmm9, xmm9
000076e4393dc747  jnz 0x000076E4393E1051
000076e4393dc74d  movaps [r15+0x210], xmm1
000076e4393dc755  movups xmm13, [r13+rax*1]
000076e4393dc75b  lea r12, [rax+0x10]
000076e4393dc75f  movups xmm9, [r13+r12*1]
000076e4393dc765  movaps [r15+0x230], xmm9
000076e4393dc76d  movaps xmm8, xmm15
000076e4393dc771  addpd xmm8, xmm7
000076e4393dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000076e4393dc77c  ptest xmm6, xmm6
000076e4393dc781  jnz 0x000076E4393E11A7
000076e4393dc787  movaps [r15+0x130], xmm8
000076e4393dc78f  vmovaps xmm15, [rsp+0x20]
000076e4393dc795  vpermilpd xmm15, xmm15, 0x00
000076e4393dc79b  movaps xmm7, xmm9
000076e4393dc79f  mulpd xmm7, xmm15
000076e4393dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000076e4393dc7a9  ptest xmm6, xmm6
000076e4393dc7ae  jnz 0x000076E4393E12EA
000076e4393dc7b4  movaps [r15+0x220], xmm7
000076e4393dc7bc  vmovaps xmm15, [rsp+0x20]
000076e4393dc7c2  vpermilpd xmm15, xmm15, 0x00
000076e4393dc7c8  movaps xmm9, xmm13
000076e4393dc7cc  mulpd xmm9, xmm15
000076e4393dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000076e4393dc7d7  ptest xmm6, xmm6
000076e4393dc7dc  jnz 0x000076E4393E142C
000076e4393dc7e2  movaps xmm15, xmm11
000076e4393dc7e6  addpd xmm15, xmm12
000076e4393dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000076e4393dc7f1  ptest xmm13, xmm13
000076e4393dc7f7  jnz 0x000076E4393E1570
000076e4393dc7fd  movaps [r15+0x140], xmm15
000076e4393dc805  movaps xmm13, xmm10
000076e4393dc809  addpd xmm13, xmm14
000076e4393dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000076e4393dc814  ptest xmm12, xmm12
000076e4393dc81a  jnz 0x000076E4393E16B4
000076e4393dc820  movaps [r15+0x150], xmm13
000076e4393dc828  movaps xmm14, xmm1
000076e4393dc82c  addpd xmm14, xmm7
000076e4393dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000076e4393dc837  ptest xmm12, xmm12
000076e4393dc83d  jnz 0x000076E4393E17F8
000076e4393dc843  movaps [r15+0x160], xmm14
000076e4393dc84b  movaps xmm1, xmm8
000076e4393dc84f  addpd xmm1, xmm9
000076e4393dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000076e4393dc859  ptest xmm12, xmm12
000076e4393dc85f  jnz 0x000076E4393E193A
000076e4393dc865  movaps [r15+0x120], xmm1
000076e4393dc86d  movups [r13+r14*1], xmm15
000076e4393dc873  lea rax, [r14+0x10]
000076e4393dc877  movups [r13+rax*1], xmm13
000076e4393dc87d  lea rax, [r14+0x20]
000076e4393dc881  movups [r13+rax*1], xmm14
000076e4393dc887  lea rax, [r14+0x30]
000076e4393dc88b  movups [r13+rax*1], xmm1
000076e4393dc891  mov eax, [r15+0x108]
000076e4393dc898  sahf
000076e4393dc899  jnz 0x000076E4393DC8CB
000076e4393dc89b  cmp dword ptr [r15+0x318], 0x00
000076e4393dc8a3  jz 0x000076E4393DB900
000076e4393dc8a9  nop [rax+rax*1], ax
000076e4393dc8b2  nop [rax+rax*1], eax
000076e4393dc8ba  mov eax, 0x410444
000076e4393dc8bf  mov [r15+0x100], rax
000076e4393dc8c6  jmp 0x000076E4391FE110
000076e4393dc8cb  cmp dword ptr [r15+0x318], 0x00
000076e4393dc8d3  jz 0x000076E4393D57E0
000076e4393dc8d9  nop [rax+rax*1], ax
000076e4393dc8e2  nop [rax+rax*1], eax
000076e4393dc8ea  mov eax, 0x410278
000076e4393dc8ef  mov [r15+0x100], rax
000076e4393dc8f6  jmp 0x000076E4391FE110
000076e4393dc8fb  int3
000076e4393dc8fc  call 0x000076E4392E27E0
000076e4393dc901  jmp 0x000076E4393DB9DF
000076e4393dc906  call 0x000076E4392E1570
000076e4393dc90b  jmp 0x000076E4393DB9E8
000076e4393dc910  call 0x000076E4392E27E0
000076e4393dc915  jmp 0x000076E4393DBA44
000076e4393dc91a  call 0x000076E4392E1570
000076e4393dc91f  jmp 0x000076E4393DBA4D
000076e4393dc924  call 0x000076E4392E27E0
000076e4393dc929  jmp 0x000076E4393DBA90
000076e4393dc92e  call 0x000076E4392E1570
000076e4393dc933  jmp 0x000076E4393DBA99
000076e4393dc938  call 0x000076E43920DC20
000076e4393dc93d  jmp 0x000076E4393DBAD8
000076e4393dc942  call 0x000076E4392D59C0
000076e4393dc947  jmp 0x000076E4393DBAEB
000076e4393dc94c  call 0x000076E4392E0E30
000076e4393dc951  jmp 0x000076E4393DBB09
000076e4393dc956  call 0x000076E4392DFBC0
000076e4393dc95b  jmp 0x000076E4393DBB13
000076e4393dc960  call 0x000076E4392DE950
000076e4393dc965  jmp 0x000076E4393DBB1D
000076e4393dc96a  sub rsp, 0x08
000076e4393dc96e  push rax
000076e4393dc96f  push rcx
000076e4393dc970  push rdx
000076e4393dc971  push rdi
000076e4393dc972  push rsi
000076e4393dc973  push r8
000076e4393dc975  push r9
000076e4393dc977  push r10
000076e4393dc979  push r11
000076e4393dc97b  sub rsp, 0xF0
000076e4393dc982  vmovaps [rsp], xmm0
000076e4393dc987  vmovaps [rsp+0x10], xmm1
000076e4393dc98d  vmovaps [rsp+0x20], xmm2
000076e4393dc993  vmovaps [rsp+0x30], xmm3
000076e4393dc999  vmovaps [rsp+0x40], xmm4
000076e4393dc99f  vmovaps [rsp+0x50], xmm5
000076e4393dc9a5  vmovaps [rsp+0x60], xmm6
000076e4393dc9ab  vmovaps [rsp+0x70], xmm7
000076e4393dc9b1  vmovaps [rsp+0x80], xmm9
000076e4393dc9ba  vmovaps [rsp+0x90], xmm10
000076e4393dc9c3  vmovaps [rsp+0xA0], xmm11
000076e4393dc9cc  vmovaps [rsp+0xB0], xmm12
000076e4393dc9d5  vmovaps [rsp+0xC0], xmm13
000076e4393dc9de  vmovaps [rsp+0xD0], xmm14
000076e4393dc9e7  vmovaps [rsp+0xE0], xmm15
000076e4393dc9f0  sub rsp, 0x30
000076e4393dc9f4  movaps [rsp], xmm8
000076e4393dc9f9  movaps [rsp+0x10], xmm12
000076e4393dc9ff  movaps [rsp+0x20], xmm15
000076e4393dca05  lea rdi, [rsp]
000076e4393dca09  mov esi, 0x00
000076e4393dca0e  mov rax, 0x63DBDEB43530
000076e4393dca18  call rax
000076e4393dca1a  movaps xmm8, [rsp]
000076e4393dca1f  add rsp, 0x30
000076e4393dca23  vmovaps xmm0, [rsp]
000076e4393dca28  vmovaps xmm1, [rsp+0x10]
000076e4393dca2e  vmovaps xmm2, [rsp+0x20]
000076e4393dca34  vmovaps xmm3, [rsp+0x30]
000076e4393dca3a  vmovaps xmm4, [rsp+0x40]
000076e4393dca40  vmovaps xmm5, [rsp+0x50]
000076e4393dca46  vmovaps xmm6, [rsp+0x60]
000076e4393dca4c  vmovaps xmm7, [rsp+0x70]
000076e4393dca52  vmovaps xmm9, [rsp+0x80]
000076e4393dca5b  vmovaps xmm10, [rsp+0x90]
000076e4393dca64  vmovaps xmm11, [rsp+0xA0]
000076e4393dca6d  vmovaps xmm12, [rsp+0xB0]
000076e4393dca76  vmovaps xmm13, [rsp+0xC0]
000076e4393dca7f  vmovaps xmm14, [rsp+0xD0]
000076e4393dca88  vmovaps xmm15, [rsp+0xE0]
000076e4393dca91  add rsp, 0xF0
000076e4393dca98  pop r11
000076e4393dca9a  pop r10
000076e4393dca9c  pop r9
000076e4393dca9e  pop r8
000076e4393dcaa0  pop rsi
000076e4393dcaa1  pop rdi
000076e4393dcaa2  pop rdx
000076e4393dcaa3  pop rcx
000076e4393dcaa4  pop rax
000076e4393dcaa5  add rsp, 0x08
000076e4393dcaa9  jmp 0x000076E4393DBB47
000076e4393dcaae  sub rsp, 0x08
000076e4393dcab2  push rax
000076e4393dcab3  push rcx
000076e4393dcab4  push rdx
000076e4393dcab5  push rdi
000076e4393dcab6  push rsi
000076e4393dcab7  push r8
000076e4393dcab9  push r9
000076e4393dcabb  push r10
000076e4393dcabd  push r11
000076e4393dcabf  sub rsp, 0xF0
000076e4393dcac6  vmovaps [rsp], xmm0
000076e4393dcacb  vmovaps [rsp+0x10], xmm1
000076e4393dcad1  vmovaps [rsp+0x20], xmm2
000076e4393dcad7  vmovaps [rsp+0x30], xmm3
000076e4393dcadd  vmovaps [rsp+0x40], xmm4
000076e4393dcae3  vmovaps [rsp+0x50], xmm5
000076e4393dcae9  vmovaps [rsp+0x60], xmm6
000076e4393dcaef  vmovaps [rsp+0x70], xmm8
000076e4393dcaf5  vmovaps [rsp+0x80], xmm9
000076e4393dcafe  vmovaps [rsp+0x90], xmm10
000076e4393dcb07  vmovaps [rsp+0xA0], xmm11
000076e4393dcb10  vmovaps [rsp+0xB0], xmm12
000076e4393dcb19  vmovaps [rsp+0xC0], xmm13
000076e4393dcb22  vmovaps [rsp+0xD0], xmm14
000076e4393dcb2b  vmovaps [rsp+0xE0], xmm15
000076e4393dcb34  sub rsp, 0x30
000076e4393dcb38  movaps [rsp], xmm7
000076e4393dcb3c  movaps [rsp+0x10], xmm9
000076e4393dcb42  movaps [rsp+0x20], xmm15
000076e4393dcb48  lea rdi, [rsp]
000076e4393dcb4c  mov esi, 0x00
000076e4393dcb51  mov rax, 0x63DBDEB43530
000076e4393dcb5b  call rax
000076e4393dcb5d  movaps xmm7, [rsp]
000076e4393dcb61  add rsp, 0x30
000076e4393dcb65  vmovaps xmm0, [rsp]
000076e4393dcb6a  vmovaps xmm1, [rsp+0x10]
000076e4393dcb70  vmovaps xmm2, [rsp+0x20]
000076e4393dcb76  vmovaps xmm3, [rsp+0x30]
000076e4393dcb7c  vmovaps xmm4, [rsp+0x40]
000076e4393dcb82  vmovaps xmm5, [rsp+0x50]
000076e4393dcb88  vmovaps xmm6, [rsp+0x60]
000076e4393dcb8e  vmovaps xmm8, [rsp+0x70]
000076e4393dcb94  vmovaps xmm9, [rsp+0x80]
000076e4393dcb9d  vmovaps xmm10, [rsp+0x90]
000076e4393dcba6  vmovaps xmm11, [rsp+0xA0]
000076e4393dcbaf  vmovaps xmm12, [rsp+0xB0]
000076e4393dcbb8  vmovaps xmm13, [rsp+0xC0]
000076e4393dcbc1  vmovaps xmm14, [rsp+0xD0]
000076e4393dcbca  vmovaps xmm15, [rsp+0xE0]
000076e4393dcbd3  add rsp, 0xF0
000076e4393dcbda  pop r11
000076e4393dcbdc  pop r10
000076e4393dcbde  pop r9
000076e4393dcbe0  pop r8
000076e4393dcbe2  pop rsi
000076e4393dcbe3  pop rdi
000076e4393dcbe4  pop rdx
000076e4393dcbe5  pop rcx
000076e4393dcbe6  pop rax
000076e4393dcbe7  add rsp, 0x08
000076e4393dcbeb  jmp 0x000076E4393DBB75
000076e4393dcbf0  sub rsp, 0x08
000076e4393dcbf4  push rax
000076e4393dcbf5  push rcx
000076e4393dcbf6  push rdx
000076e4393dcbf7  push rdi
000076e4393dcbf8  push rsi
000076e4393dcbf9  push r8
000076e4393dcbfb  push r9
000076e4393dcbfd  push r10
000076e4393dcbff  push r11
000076e4393dcc01  sub rsp, 0xF0
000076e4393dcc08  vmovaps [rsp], xmm0
000076e4393dcc0d  vmovaps [rsp+0x10], xmm1
000076e4393dcc13  vmovaps [rsp+0x20], xmm2
000076e4393dcc19  vmovaps [rsp+0x30], xmm3
000076e4393dcc1f  vmovaps [rsp+0x40], xmm4
000076e4393dcc25  vmovaps [rsp+0x50], xmm5
000076e4393dcc2b  vmovaps [rsp+0x60], xmm6
000076e4393dcc31  vmovaps [rsp+0x70], xmm7
000076e4393dcc37  vmovaps [rsp+0x80], xmm8
000076e4393dcc40  vmovaps [rsp+0x90], xmm10
000076e4393dcc49  vmovaps [rsp+0xA0], xmm11
000076e4393dcc52  vmovaps [rsp+0xB0], xmm12
000076e4393dcc5b  vmovaps [rsp+0xC0], xmm13
000076e4393dcc64  vmovaps [rsp+0xD0], xmm14
000076e4393dcc6d  vmovaps [rsp+0xE0], xmm15
000076e4393dcc76  sub rsp, 0x30
000076e4393dcc7a  movaps [rsp], xmm9
000076e4393dcc7f  movaps [rsp+0x10], xmm12
000076e4393dcc85  movaps [rsp+0x20], xmm10
000076e4393dcc8b  lea rdi, [rsp]
000076e4393dcc8f  mov esi, 0x00
000076e4393dcc94  mov rax, 0x63DBDEB43530
000076e4393dcc9e  call rax
000076e4393dcca0  movaps xmm9, [rsp]
000076e4393dcca5  add rsp, 0x30
000076e4393dcca9  vmovaps xmm0, [rsp]
000076e4393dccae  vmovaps xmm1, [rsp+0x10]
000076e4393dccb4  vmovaps xmm2, [rsp+0x20]
000076e4393dccba  vmovaps xmm3, [rsp+0x30]
000076e4393dccc0  vmovaps xmm4, [rsp+0x40]
000076e4393dccc6  vmovaps xmm5, [rsp+0x50]
000076e4393dcccc  vmovaps xmm6, [rsp+0x60]
000076e4393dccd2  vmovaps xmm7, [rsp+0x70]
000076e4393dccd8  vmovaps xmm8, [rsp+0x80]
000076e4393dcce1  vmovaps xmm10, [rsp+0x90]
000076e4393dccea  vmovaps xmm11, [rsp+0xA0]
000076e4393dccf3  vmovaps xmm12, [rsp+0xB0]
000076e4393dccfc  vmovaps xmm13, [rsp+0xC0]
000076e4393dcd05  vmovaps xmm14, [rsp+0xD0]
000076e4393dcd0e  vmovaps xmm15, [rsp+0xE0]
000076e4393dcd17  add rsp, 0xF0
000076e4393dcd1e  pop r11
000076e4393dcd20  pop r10
000076e4393dcd22  pop r9
000076e4393dcd24  pop r8
000076e4393dcd26  pop rsi
000076e4393dcd27  pop rdi
000076e4393dcd28  pop rdx
000076e4393dcd29  pop rcx
000076e4393dcd2a  pop rax
000076e4393dcd2b  add rsp, 0x08
000076e4393dcd2f  jmp 0x000076E4393DBB99
000076e4393dcd34  sub rsp, 0x08
000076e4393dcd38  push rax
000076e4393dcd39  push rcx
000076e4393dcd3a  push rdx
000076e4393dcd3b  push rdi
000076e4393dcd3c  push rsi
000076e4393dcd3d  push r8
000076e4393dcd3f  push r9
000076e4393dcd41  push r10
000076e4393dcd43  push r11
000076e4393dcd45  sub rsp, 0xF0
000076e4393dcd4c  vmovaps [rsp], xmm0
000076e4393dcd51  vmovaps [rsp+0x10], xmm1
000076e4393dcd57  vmovaps [rsp+0x20], xmm2
000076e4393dcd5d  vmovaps [rsp+0x30], xmm3
000076e4393dcd63  vmovaps [rsp+0x40], xmm4
000076e4393dcd69  vmovaps [rsp+0x50], xmm5
000076e4393dcd6f  vmovaps [rsp+0x60], xmm6
000076e4393dcd75  vmovaps [rsp+0x70], xmm7
000076e4393dcd7b  vmovaps [rsp+0x80], xmm8
000076e4393dcd84  vmovaps [rsp+0x90], xmm9
000076e4393dcd8d  vmovaps [rsp+0xA0], xmm11
000076e4393dcd96  vmovaps [rsp+0xB0], xmm12
000076e4393dcd9f  vmovaps [rsp+0xC0], xmm13
000076e4393dcda8  vmovaps [rsp+0xD0], xmm14
000076e4393dcdb1  vmovaps [rsp+0xE0], xmm15
000076e4393dcdba  sub rsp, 0x30
000076e4393dcdbe  movaps [rsp], xmm10
000076e4393dcdc3  movaps [rsp+0x10], xmm12
000076e4393dcdc9  movaps [rsp+0x20], xmm11
000076e4393dcdcf  lea rdi, [rsp]
000076e4393dcdd3  mov esi, 0x00
000076e4393dcdd8  mov rax, 0x63DBDEB43530
000076e4393dcde2  call rax
000076e4393dcde4  movaps xmm10, [rsp]
000076e4393dcde9  add rsp, 0x30
000076e4393dcded  vmovaps xmm0, [rsp]
000076e4393dcdf2  vmovaps xmm1, [rsp+0x10]
000076e4393dcdf8  vmovaps xmm2, [rsp+0x20]
000076e4393dcdfe  vmovaps xmm3, [rsp+0x30]
000076e4393dce04  vmovaps xmm4, [rsp+0x40]
000076e4393dce0a  vmovaps xmm5, [rsp+0x50]
000076e4393dce10  vmovaps xmm6, [rsp+0x60]
000076e4393dce16  vmovaps xmm7, [rsp+0x70]
000076e4393dce1c  vmovaps xmm8, [rsp+0x80]
000076e4393dce25  vmovaps xmm9, [rsp+0x90]
000076e4393dce2e  vmovaps xmm11, [rsp+0xA0]
000076e4393dce37  vmovaps xmm12, [rsp+0xB0]
000076e4393dce40  vmovaps xmm13, [rsp+0xC0]
000076e4393dce49  vmovaps xmm14, [rsp+0xD0]
000076e4393dce52  vmovaps xmm15, [rsp+0xE0]
000076e4393dce5b  add rsp, 0xF0
000076e4393dce62  pop r11
000076e4393dce64  pop r10
000076e4393dce66  pop r9
000076e4393dce68  pop r8
000076e4393dce6a  pop rsi
000076e4393dce6b  pop rdi
000076e4393dce6c  pop rdx
000076e4393dce6d  pop rcx
000076e4393dce6e  pop rax
000076e4393dce6f  add rsp, 0x08
000076e4393dce73  jmp 0x000076E4393DBBB3
000076e4393dce78  sub rsp, 0x08
000076e4393dce7c  push rax
000076e4393dce7d  push rcx
000076e4393dce7e  push rdx
000076e4393dce7f  push rdi
000076e4393dce80  push rsi
000076e4393dce81  push r8
000076e4393dce83  push r9
000076e4393dce85  push r10
000076e4393dce87  push r11
000076e4393dce89  sub rsp, 0xF0
000076e4393dce90  vmovaps [rsp], xmm0
000076e4393dce95  vmovaps [rsp+0x10], xmm1
000076e4393dce9b  vmovaps [rsp+0x20], xmm2
000076e4393dcea1  vmovaps [rsp+0x30], xmm3
000076e4393dcea7  vmovaps [rsp+0x40], xmm4
000076e4393dcead  vmovaps [rsp+0x50], xmm5
000076e4393dceb3  vmovaps [rsp+0x60], xmm7
000076e4393dceb9  vmovaps [rsp+0x70], xmm8
000076e4393dcebf  vmovaps [rsp+0x80], xmm9
000076e4393dcec8  vmovaps [rsp+0x90], xmm10
000076e4393dced1  vmovaps [rsp+0xA0], xmm11
000076e4393dceda  vmovaps [rsp+0xB0], xmm12
000076e4393dcee3  vmovaps [rsp+0xC0], xmm13
000076e4393dceec  vmovaps [rsp+0xD0], xmm14
000076e4393dcef5  vmovaps [rsp+0xE0], xmm15
000076e4393dcefe  sub rsp, 0x30
000076e4393dcf02  movaps [rsp], xmm6
000076e4393dcf06  movaps [rsp+0x10], xmm12
000076e4393dcf0c  movaps [rsp+0x20], xmm11
000076e4393dcf12  lea rdi, [rsp]
000076e4393dcf16  mov esi, 0x00
000076e4393dcf1b  mov rax, 0x63DBDEB43530
000076e4393dcf25  call rax
000076e4393dcf27  movaps xmm6, [rsp]
000076e4393dcf2b  add rsp, 0x30
000076e4393dcf2f  vmovaps xmm0, [rsp]
000076e4393dcf34  vmovaps xmm1, [rsp+0x10]
000076e4393dcf3a  vmovaps xmm2, [rsp+0x20]
000076e4393dcf40  vmovaps xmm3, [rsp+0x30]
000076e4393dcf46  vmovaps xmm4, [rsp+0x40]
000076e4393dcf4c  vmovaps xmm5, [rsp+0x50]
000076e4393dcf52  vmovaps xmm7, [rsp+0x60]
000076e4393dcf58  vmovaps xmm8, [rsp+0x70]
000076e4393dcf5e  vmovaps xmm9, [rsp+0x80]
000076e4393dcf67  vmovaps xmm10, [rsp+0x90]
000076e4393dcf70  vmovaps xmm11, [rsp+0xA0]
000076e4393dcf79  vmovaps xmm12, [rsp+0xB0]
000076e4393dcf82  vmovaps xmm13, [rsp+0xC0]
000076e4393dcf8b  vmovaps xmm14, [rsp+0xD0]
000076e4393dcf94  vmovaps xmm15, [rsp+0xE0]
000076e4393dcf9d  add rsp, 0xF0
000076e4393dcfa4  pop r11
000076e4393dcfa6  pop r10
000076e4393dcfa8  pop r9
000076e4393dcfaa  pop r8
000076e4393dcfac  pop rsi
000076e4393dcfad  pop rdi
000076e4393dcfae  pop rdx
000076e4393dcfaf  pop rcx
000076e4393dcfb0  pop rax
000076e4393dcfb1  add rsp, 0x08
000076e4393dcfb5  jmp 0x000076E4393DBBD4
000076e4393dcfba  sub rsp, 0x08
000076e4393dcfbe  push rax
000076e4393dcfbf  push rcx
000076e4393dcfc0  push rdx
000076e4393dcfc1  push rdi
000076e4393dcfc2  push rsi
000076e4393dcfc3  push r8
000076e4393dcfc5  push r9
000076e4393dcfc7  push r10
000076e4393dcfc9  push r11
000076e4393dcfcb  sub rsp, 0xF0
000076e4393dcfd2  vmovaps [rsp], xmm0
000076e4393dcfd7  vmovaps [rsp+0x10], xmm1
000076e4393dcfdd  vmovaps [rsp+0x20], xmm2
000076e4393dcfe3  vmovaps [rsp+0x30], xmm4
000076e4393dcfe9  vmovaps [rsp+0x40], xmm5
000076e4393dcfef  vmovaps [rsp+0x50], xmm6
000076e4393dcff5  vmovaps [rsp+0x60], xmm7
000076e4393dcffb  vmovaps [rsp+0x70], xmm8
000076e4393dd001  vmovaps [rsp+0x80], xmm9
000076e4393dd00a  vmovaps [rsp+0x90], xmm10
000076e4393dd013  vmovaps [rsp+0xA0], xmm11
000076e4393dd01c  vmovaps [rsp+0xB0], xmm12
000076e4393dd025  vmovaps [rsp+0xC0], xmm13
000076e4393dd02e  vmovaps [rsp+0xD0], xmm14
000076e4393dd037  vmovaps [rsp+0xE0], xmm15
000076e4393dd040  sub rsp, 0x30
000076e4393dd044  movaps [rsp], xmm3
000076e4393dd048  movaps [rsp+0x10], xmm5
000076e4393dd04d  movaps [rsp+0x20], xmm4
000076e4393dd052  lea rdi, [rsp]
000076e4393dd056  mov esi, 0x00
000076e4393dd05b  mov rax, 0x63DBDEB43530
000076e4393dd065  call rax
000076e4393dd067  movaps xmm3, [rsp]
000076e4393dd06b  add rsp, 0x30
000076e4393dd06f  vmovaps xmm0, [rsp]
000076e4393dd074  vmovaps xmm1, [rsp+0x10]
000076e4393dd07a  vmovaps xmm2, [rsp+0x20]
000076e4393dd080  vmovaps xmm4, [rsp+0x30]
000076e4393dd086  vmovaps xmm5, [rsp+0x40]
000076e4393dd08c  vmovaps xmm6, [rsp+0x50]
000076e4393dd092  vmovaps xmm7, [rsp+0x60]
000076e4393dd098  vmovaps xmm8, [rsp+0x70]
000076e4393dd09e  vmovaps xmm9, [rsp+0x80]
000076e4393dd0a7  vmovaps xmm10, [rsp+0x90]
000076e4393dd0b0  vmovaps xmm11, [rsp+0xA0]
000076e4393dd0b9  vmovaps xmm12, [rsp+0xB0]
000076e4393dd0c2  vmovaps xmm13, [rsp+0xC0]
000076e4393dd0cb  vmovaps xmm14, [rsp+0xD0]
000076e4393dd0d4  vmovaps xmm15, [rsp+0xE0]
000076e4393dd0dd  add rsp, 0xF0
000076e4393dd0e4  pop r11
000076e4393dd0e6  pop r10
000076e4393dd0e8  pop r9
000076e4393dd0ea  pop r8
000076e4393dd0ec  pop rsi
000076e4393dd0ed  pop rdi
000076e4393dd0ee  pop rdx
000076e4393dd0ef  pop rcx
000076e4393dd0f0  pop rax
000076e4393dd0f1  add rsp, 0x08
000076e4393dd0f5  jmp 0x000076E4393DBC35
000076e4393dd0fa  sub rsp, 0x08
000076e4393dd0fe  push rax
000076e4393dd0ff  push rcx
000076e4393dd100  push rdx
000076e4393dd101  push rdi
000076e4393dd102  push rsi
000076e4393dd103  push r8
000076e4393dd105  push r9
000076e4393dd107  push r10
000076e4393dd109  push r11
000076e4393dd10b  sub rsp, 0xF0
000076e4393dd112  vmovaps [rsp], xmm0
000076e4393dd117  vmovaps [rsp+0x10], xmm1
000076e4393dd11d  vmovaps [rsp+0x20], xmm2
000076e4393dd123  vmovaps [rsp+0x30], xmm3
000076e4393dd129  vmovaps [rsp+0x40], xmm4
000076e4393dd12f  vmovaps [rsp+0x50], xmm6
000076e4393dd135  vmovaps [rsp+0x60], xmm7
000076e4393dd13b  vmovaps [rsp+0x70], xmm8
000076e4393dd141  vmovaps [rsp+0x80], xmm9
000076e4393dd14a  vmovaps [rsp+0x90], xmm10
000076e4393dd153  vmovaps [rsp+0xA0], xmm11
000076e4393dd15c  vmovaps [rsp+0xB0], xmm12
000076e4393dd165  vmovaps [rsp+0xC0], xmm13
000076e4393dd16e  vmovaps [rsp+0xD0], xmm14
000076e4393dd177  vmovaps [rsp+0xE0], xmm15
000076e4393dd180  sub rsp, 0x30
000076e4393dd184  movaps [rsp], xmm5
000076e4393dd188  movaps [rsp+0x10], xmm8
000076e4393dd18e  movaps [rsp+0x20], xmm15
000076e4393dd194  lea rdi, [rsp]
000076e4393dd198  mov esi, 0x00
000076e4393dd19d  mov rax, 0x63DBDEB43530
000076e4393dd1a7  call rax
000076e4393dd1a9  movaps xmm5, [rsp]
000076e4393dd1ad  add rsp, 0x30
000076e4393dd1b1  vmovaps xmm0, [rsp]
000076e4393dd1b6  vmovaps xmm1, [rsp+0x10]
000076e4393dd1bc  vmovaps xmm2, [rsp+0x20]
000076e4393dd1c2  vmovaps xmm3, [rsp+0x30]
000076e4393dd1c8  vmovaps xmm4, [rsp+0x40]
000076e4393dd1ce  vmovaps xmm6, [rsp+0x50]
000076e4393dd1d4  vmovaps xmm7, [rsp+0x60]
000076e4393dd1da  vmovaps xmm8, [rsp+0x70]
000076e4393dd1e0  vmovaps xmm9, [rsp+0x80]
000076e4393dd1e9  vmovaps xmm10, [rsp+0x90]
000076e4393dd1f2  vmovaps xmm11, [rsp+0xA0]
000076e4393dd1fb  vmovaps xmm12, [rsp+0xB0]
000076e4393dd204  vmovaps xmm13, [rsp+0xC0]
000076e4393dd20d  vmovaps xmm14, [rsp+0xD0]
000076e4393dd216  vmovaps xmm15, [rsp+0xE0]
000076e4393dd21f  add rsp, 0xF0
000076e4393dd226  pop r11
000076e4393dd228  pop r10
000076e4393dd22a  pop r9
000076e4393dd22c  pop r8
000076e4393dd22e  pop rsi
000076e4393dd22f  pop rdi
000076e4393dd230  pop rdx
000076e4393dd231  pop rcx
000076e4393dd232  pop rax
000076e4393dd233  add rsp, 0x08
000076e4393dd237  jmp 0x000076E4393DBC73
000076e4393dd23c  sub rsp, 0x08
000076e4393dd240  push rax
000076e4393dd241  push rcx
000076e4393dd242  push rdx
000076e4393dd243  push rdi
000076e4393dd244  push rsi
000076e4393dd245  push r8
000076e4393dd247  push r9
000076e4393dd249  push r10
000076e4393dd24b  push r11
000076e4393dd24d  sub rsp, 0xF0
000076e4393dd254  vmovaps [rsp], xmm0
000076e4393dd259  vmovaps [rsp+0x10], xmm1
000076e4393dd25f  vmovaps [rsp+0x20], xmm2
000076e4393dd265  vmovaps [rsp+0x30], xmm3
000076e4393dd26b  vmovaps [rsp+0x40], xmm5
000076e4393dd271  vmovaps [rsp+0x50], xmm6
000076e4393dd277  vmovaps [rsp+0x60], xmm7
000076e4393dd27d  vmovaps [rsp+0x70], xmm8
000076e4393dd283  vmovaps [rsp+0x80], xmm9
000076e4393dd28c  vmovaps [rsp+0x90], xmm10
000076e4393dd295  vmovaps [rsp+0xA0], xmm11
000076e4393dd29e  vmovaps [rsp+0xB0], xmm12
000076e4393dd2a7  vmovaps [rsp+0xC0], xmm13
000076e4393dd2b0  vmovaps [rsp+0xD0], xmm14
000076e4393dd2b9  vmovaps [rsp+0xE0], xmm15
000076e4393dd2c2  sub rsp, 0x30
000076e4393dd2c6  movaps [rsp], xmm4
000076e4393dd2ca  movaps [rsp+0x10], xmm9
000076e4393dd2d0  movaps [rsp+0x20], xmm8
000076e4393dd2d6  lea rdi, [rsp]
000076e4393dd2da  mov esi, 0x00
000076e4393dd2df  mov rax, 0x63DBDEB43530
000076e4393dd2e9  call rax
000076e4393dd2eb  movaps xmm4, [rsp]
000076e4393dd2ef  add rsp, 0x30
000076e4393dd2f3  vmovaps xmm0, [rsp]
000076e4393dd2f8  vmovaps xmm1, [rsp+0x10]
000076e4393dd2fe  vmovaps xmm2, [rsp+0x20]
000076e4393dd304  vmovaps xmm3, [rsp+0x30]
000076e4393dd30a  vmovaps xmm5, [rsp+0x40]
000076e4393dd310  vmovaps xmm6, [rsp+0x50]
000076e4393dd316  vmovaps xmm7, [rsp+0x60]
000076e4393dd31c  vmovaps xmm8, [rsp+0x70]
000076e4393dd322  vmovaps xmm9, [rsp+0x80]
000076e4393dd32b  vmovaps xmm10, [rsp+0x90]
000076e4393dd334  vmovaps xmm11, [rsp+0xA0]
000076e4393dd33d  vmovaps xmm12, [rsp+0xB0]
000076e4393dd346  vmovaps xmm13, [rsp+0xC0]
000076e4393dd34f  vmovaps xmm14, [rsp+0xD0]
000076e4393dd358  vmovaps xmm15, [rsp+0xE0]
000076e4393dd361  add rsp, 0xF0
000076e4393dd368  pop r11
000076e4393dd36a  pop r10
000076e4393dd36c  pop r9
000076e4393dd36e  pop r8
000076e4393dd370  pop rsi
000076e4393dd371  pop rdi
000076e4393dd372  pop rdx
000076e4393dd373  pop rcx
000076e4393dd374  pop rax
000076e4393dd375  add rsp, 0x08
000076e4393dd379  jmp 0x000076E4393DBC94
000076e4393dd37e  sub rsp, 0x08
000076e4393dd382  push rax
000076e4393dd383  push rcx
000076e4393dd384  push rdx
000076e4393dd385  push rdi
000076e4393dd386  push rsi
000076e4393dd387  push r8
000076e4393dd389  push r9
000076e4393dd38b  push r10
000076e4393dd38d  push r11
000076e4393dd38f  sub rsp, 0xF0
000076e4393dd396  vmovaps [rsp], xmm0
000076e4393dd39b  vmovaps [rsp+0x10], xmm1
000076e4393dd3a1  vmovaps [rsp+0x20], xmm2
000076e4393dd3a7  vmovaps [rsp+0x30], xmm3
000076e4393dd3ad  vmovaps [rsp+0x40], xmm4
000076e4393dd3b3  vmovaps [rsp+0x50], xmm5
000076e4393dd3b9  vmovaps [rsp+0x60], xmm6
000076e4393dd3bf  vmovaps [rsp+0x70], xmm7
000076e4393dd3c5  vmovaps [rsp+0x80], xmm8
000076e4393dd3ce  vmovaps [rsp+0x90], xmm10
000076e4393dd3d7  vmovaps [rsp+0xA0], xmm11
000076e4393dd3e0  vmovaps [rsp+0xB0], xmm12
000076e4393dd3e9  vmovaps [rsp+0xC0], xmm13
000076e4393dd3f2  vmovaps [rsp+0xD0], xmm14
000076e4393dd3fb  vmovaps [rsp+0xE0], xmm15
000076e4393dd404  sub rsp, 0x30
000076e4393dd408  movaps [rsp], xmm9
000076e4393dd40d  movaps [rsp+0x10], xmm10
000076e4393dd413  movaps [rsp+0x20], xmm8
000076e4393dd419  lea rdi, [rsp]
000076e4393dd41d  mov esi, 0x00
000076e4393dd422  mov rax, 0x63DBDEB43530
000076e4393dd42c  call rax
000076e4393dd42e  movaps xmm9, [rsp]
000076e4393dd433  add rsp, 0x30
000076e4393dd437  vmovaps xmm0, [rsp]
000076e4393dd43c  vmovaps xmm1, [rsp+0x10]
000076e4393dd442  vmovaps xmm2, [rsp+0x20]
000076e4393dd448  vmovaps xmm3, [rsp+0x30]
000076e4393dd44e  vmovaps xmm4, [rsp+0x40]
000076e4393dd454  vmovaps xmm5, [rsp+0x50]
000076e4393dd45a  vmovaps xmm6, [rsp+0x60]
000076e4393dd460  vmovaps xmm7, [rsp+0x70]
000076e4393dd466  vmovaps xmm8, [rsp+0x80]
000076e4393dd46f  vmovaps xmm10, [rsp+0x90]
000076e4393dd478  vmovaps xmm11, [rsp+0xA0]
000076e4393dd481  vmovaps xmm12, [rsp+0xB0]
000076e4393dd48a  vmovaps xmm13, [rsp+0xC0]
000076e4393dd493  vmovaps xmm14, [rsp+0xD0]
000076e4393dd49c  vmovaps xmm15, [rsp+0xE0]
000076e4393dd4a5  add rsp, 0xF0
000076e4393dd4ac  pop r11
000076e4393dd4ae  pop r10
000076e4393dd4b0  pop r9
000076e4393dd4b2  pop r8
000076e4393dd4b4  pop rsi
000076e4393dd4b5  pop rdi
000076e4393dd4b6  pop rdx
000076e4393dd4b7  pop rcx
000076e4393dd4b8  pop rax
000076e4393dd4b9  add rsp, 0x08
000076e4393dd4bd  jmp 0x000076E4393DBCAE
000076e4393dd4c2  call 0x000076E4392B52F0
000076e4393dd4c7  jmp 0x000076E4393DBDC8
000076e4393dd4cc  call 0x000076E4392B52F0
000076e4393dd4d1  jmp 0x000076E4393DBDDE
000076e4393dd4d6  sub rsp, 0x08
000076e4393dd4da  push rax
000076e4393dd4db  push rcx
000076e4393dd4dc  push rdx
000076e4393dd4dd  push rdi
000076e4393dd4de  push rsi
000076e4393dd4df  push r8
000076e4393dd4e1  push r9
000076e4393dd4e3  push r10
000076e4393dd4e5  push r11
000076e4393dd4e7  sub rsp, 0xF0
000076e4393dd4ee  vmovaps [rsp], xmm0
000076e4393dd4f3  vmovaps [rsp+0x10], xmm2
000076e4393dd4f9  vmovaps [rsp+0x20], xmm3
000076e4393dd4ff  vmovaps [rsp+0x30], xmm4
000076e4393dd505  vmovaps [rsp+0x40], xmm5
000076e4393dd50b  vmovaps [rsp+0x50], xmm6
000076e4393dd511  vmovaps [rsp+0x60], xmm7
000076e4393dd517  vmovaps [rsp+0x70], xmm8
000076e4393dd51d  vmovaps [rsp+0x80], xmm9
000076e4393dd526  vmovaps [rsp+0x90], xmm10
000076e4393dd52f  vmovaps [rsp+0xA0], xmm11
000076e4393dd538  vmovaps [rsp+0xB0], xmm12
000076e4393dd541  vmovaps [rsp+0xC0], xmm13
000076e4393dd54a  vmovaps [rsp+0xD0], xmm14
000076e4393dd553  vmovaps [rsp+0xE0], xmm15
000076e4393dd55c  sub rsp, 0x30
000076e4393dd560  movaps [rsp], xmm1
000076e4393dd564  movaps [rsp+0x10], xmm6
000076e4393dd569  movaps [rsp+0x20], xmm15
000076e4393dd56f  lea rdi, [rsp]
000076e4393dd573  mov esi, 0x00
000076e4393dd578  mov rax, 0x63DBDEB43530
000076e4393dd582  call rax
000076e4393dd584  movaps xmm1, [rsp]
000076e4393dd588  add rsp, 0x30
000076e4393dd58c  vmovaps xmm0, [rsp]
000076e4393dd591  vmovaps xmm2, [rsp+0x10]
000076e4393dd597  vmovaps xmm3, [rsp+0x20]
000076e4393dd59d  vmovaps xmm4, [rsp+0x30]
000076e4393dd5a3  vmovaps xmm5, [rsp+0x40]
000076e4393dd5a9  vmovaps xmm6, [rsp+0x50]
000076e4393dd5af  vmovaps xmm7, [rsp+0x60]
000076e4393dd5b5  vmovaps xmm8, [rsp+0x70]
000076e4393dd5bb  vmovaps xmm9, [rsp+0x80]
000076e4393dd5c4  vmovaps xmm10, [rsp+0x90]
000076e4393dd5cd  vmovaps xmm11, [rsp+0xA0]
000076e4393dd5d6  vmovaps xmm12, [rsp+0xB0]
000076e4393dd5df  vmovaps xmm13, [rsp+0xC0]
000076e4393dd5e8  vmovaps xmm14, [rsp+0xD0]
000076e4393dd5f1  vmovaps xmm15, [rsp+0xE0]
000076e4393dd5fa  add rsp, 0xF0
000076e4393dd601  pop r11
000076e4393dd603  pop r10
000076e4393dd605  pop r9
000076e4393dd607  pop r8
000076e4393dd609  pop rsi
000076e4393dd60a  pop rdi
000076e4393dd60b  pop rdx
000076e4393dd60c  pop rcx
000076e4393dd60d  pop rax
000076e4393dd60e  add rsp, 0x08
000076e4393dd612  jmp 0x000076E4393DBE1B
000076e4393dd617  call 0x000076E4392C4620
000076e4393dd61c  jmp 0x000076E4393DBE28
000076e4393dd621  sub rsp, 0x08
000076e4393dd625  push rax
000076e4393dd626  push rcx
000076e4393dd627  push rdx
000076e4393dd628  push rdi
000076e4393dd629  push rsi
000076e4393dd62a  push r8
000076e4393dd62c  push r9
000076e4393dd62e  push r10
000076e4393dd630  push r11
000076e4393dd632  sub rsp, 0xF0
000076e4393dd639  vmovaps [rsp], xmm0
000076e4393dd63e  vmovaps [rsp+0x10], xmm1
000076e4393dd644  vmovaps [rsp+0x20], xmm2
000076e4393dd64a  vmovaps [rsp+0x30], xmm3
000076e4393dd650  vmovaps [rsp+0x40], xmm4
000076e4393dd656  vmovaps [rsp+0x50], xmm5
000076e4393dd65c  vmovaps [rsp+0x60], xmm6
000076e4393dd662  vmovaps [rsp+0x70], xmm7
000076e4393dd668  vmovaps [rsp+0x80], xmm8
000076e4393dd671  vmovaps [rsp+0x90], xmm9
000076e4393dd67a  vmovaps [rsp+0xA0], xmm10
000076e4393dd683  vmovaps [rsp+0xB0], xmm11
000076e4393dd68c  vmovaps [rsp+0xC0], xmm12
000076e4393dd695  vmovaps [rsp+0xD0], xmm13
000076e4393dd69e  vmovaps [rsp+0xE0], xmm15
000076e4393dd6a7  sub rsp, 0x30
000076e4393dd6ab  movaps [rsp], xmm14
000076e4393dd6b0  movaps [rsp+0x10], xmm4
000076e4393dd6b5  movaps [rsp+0x20], xmm3
000076e4393dd6ba  lea rdi, [rsp]
000076e4393dd6be  mov esi, 0x00
000076e4393dd6c3  mov rax, 0x63DBDEB43530
000076e4393dd6cd  call rax
000076e4393dd6cf  movaps xmm14, [rsp]
000076e4393dd6d4  add rsp, 0x30
000076e4393dd6d8  vmovaps xmm0, [rsp]
000076e4393dd6dd  vmovaps xmm1, [rsp+0x10]
000076e4393dd6e3  vmovaps xmm2, [rsp+0x20]
000076e4393dd6e9  vmovaps xmm3, [rsp+0x30]
000076e4393dd6ef  vmovaps xmm4, [rsp+0x40]
000076e4393dd6f5  vmovaps xmm5, [rsp+0x50]
000076e4393dd6fb  vmovaps xmm6, [rsp+0x60]
000076e4393dd701  vmovaps xmm7, [rsp+0x70]
000076e4393dd707  vmovaps xmm8, [rsp+0x80]
000076e4393dd710  vmovaps xmm9, [rsp+0x90]
000076e4393dd719  vmovaps xmm10, [rsp+0xA0]
000076e4393dd722  vmovaps xmm11, [rsp+0xB0]
000076e4393dd72b  vmovaps xmm12, [rsp+0xC0]
000076e4393dd734  vmovaps xmm13, [rsp+0xD0]
000076e4393dd73d  vmovaps xmm15, [rsp+0xE0]
000076e4393dd746  add rsp, 0xF0
000076e4393dd74d  pop r11
000076e4393dd74f  pop r10
000076e4393dd751  pop r9
000076e4393dd753  pop r8
000076e4393dd755  pop rsi
000076e4393dd756  pop rdi
000076e4393dd757  pop rdx
000076e4393dd758  pop rcx
000076e4393dd759  pop rax
000076e4393dd75a  add rsp, 0x08
000076e4393dd75e  jmp 0x000076E4393DBE42
000076e4393dd763  sub rsp, 0x08
000076e4393dd767  push rax
000076e4393dd768  push rcx
000076e4393dd769  push rdx
000076e4393dd76a  push rdi
000076e4393dd76b  push rsi
000076e4393dd76c  push r8
000076e4393dd76e  push r9
000076e4393dd770  push r10
000076e4393dd772  push r11
000076e4393dd774  sub rsp, 0xF0
000076e4393dd77b  vmovaps [rsp], xmm0
000076e4393dd780  vmovaps [rsp+0x10], xmm1
000076e4393dd786  vmovaps [rsp+0x20], xmm2
000076e4393dd78c  vmovaps [rsp+0x30], xmm3
000076e4393dd792  vmovaps [rsp+0x40], xmm4
000076e4393dd798  vmovaps [rsp+0x50], xmm5
000076e4393dd79e  vmovaps [rsp+0x60], xmm7
000076e4393dd7a4  vmovaps [rsp+0x70], xmm8
000076e4393dd7aa  vmovaps [rsp+0x80], xmm9
000076e4393dd7b3  vmovaps [rsp+0x90], xmm10
000076e4393dd7bc  vmovaps [rsp+0xA0], xmm11
000076e4393dd7c5  vmovaps [rsp+0xB0], xmm12
000076e4393dd7ce  vmovaps [rsp+0xC0], xmm13
000076e4393dd7d7  vmovaps [rsp+0xD0], xmm14
000076e4393dd7e0  vmovaps [rsp+0xE0], xmm15
000076e4393dd7e9  sub rsp, 0x30
000076e4393dd7ed  movaps [rsp], xmm6
000076e4393dd7f1  movaps [rsp+0x10], xmm9
000076e4393dd7f7  movaps [rsp+0x20], xmm7
000076e4393dd7fc  lea rdi, [rsp]
000076e4393dd800  mov esi, 0x00
000076e4393dd805  mov rax, 0x63DBDEB43530
000076e4393dd80f  call rax
000076e4393dd811  movaps xmm6, [rsp]
000076e4393dd815  add rsp, 0x30
000076e4393dd819  vmovaps xmm0, [rsp]
000076e4393dd81e  vmovaps xmm1, [rsp+0x10]
000076e4393dd824  vmovaps xmm2, [rsp+0x20]
000076e4393dd82a  vmovaps xmm3, [rsp+0x30]
000076e4393dd830  vmovaps xmm4, [rsp+0x40]
000076e4393dd836  vmovaps xmm5, [rsp+0x50]
000076e4393dd83c  vmovaps xmm7, [rsp+0x60]
000076e4393dd842  vmovaps xmm8, [rsp+0x70]
000076e4393dd848  vmovaps xmm9, [rsp+0x80]
000076e4393dd851  vmovaps xmm10, [rsp+0x90]
000076e4393dd85a  vmovaps xmm11, [rsp+0xA0]
000076e4393dd863  vmovaps xmm12, [rsp+0xB0]
000076e4393dd86c  vmovaps xmm13, [rsp+0xC0]
000076e4393dd875  vmovaps xmm14, [rsp+0xD0]
000076e4393dd87e  vmovaps xmm15, [rsp+0xE0]
000076e4393dd887  add rsp, 0xF0
000076e4393dd88e  pop r11
000076e4393dd890  pop r10
000076e4393dd892  pop r9
000076e4393dd894  pop r8
000076e4393dd896  pop rsi
000076e4393dd897  pop rdi
000076e4393dd898  pop rdx
000076e4393dd899  pop rcx
000076e4393dd89a  pop rax
000076e4393dd89b  add rsp, 0x08
000076e4393dd89f  jmp 0x000076E4393DBE5A
000076e4393dd8a4  sub rsp, 0x08
000076e4393dd8a8  push rax
000076e4393dd8a9  push rcx
000076e4393dd8aa  push rdx
000076e4393dd8ab  push rdi
000076e4393dd8ac  push rsi
000076e4393dd8ad  push r8
000076e4393dd8af  push r9
000076e4393dd8b1  push r10
000076e4393dd8b3  push r11
000076e4393dd8b5  sub rsp, 0xF0
000076e4393dd8bc  vmovaps [rsp], xmm0
000076e4393dd8c1  vmovaps [rsp+0x10], xmm1
000076e4393dd8c7  vmovaps [rsp+0x20], xmm2
000076e4393dd8cd  vmovaps [rsp+0x30], xmm3
000076e4393dd8d3  vmovaps [rsp+0x40], xmm4
000076e4393dd8d9  vmovaps [rsp+0x50], xmm5
000076e4393dd8df  vmovaps [rsp+0x60], xmm6
000076e4393dd8e5  vmovaps [rsp+0x70], xmm8
000076e4393dd8eb  vmovaps [rsp+0x80], xmm9
000076e4393dd8f4  vmovaps [rsp+0x90], xmm10
000076e4393dd8fd  vmovaps [rsp+0xA0], xmm11
000076e4393dd906  vmovaps [rsp+0xB0], xmm12
000076e4393dd90f  vmovaps [rsp+0xC0], xmm13
000076e4393dd918  vmovaps [rsp+0xD0], xmm14
000076e4393dd921  vmovaps [rsp+0xE0], xmm15
000076e4393dd92a  sub rsp, 0x30
000076e4393dd92e  movaps [rsp], xmm7
000076e4393dd932  movaps [rsp+0x10], xmm4
000076e4393dd937  movaps [rsp+0x20], xmm9
000076e4393dd93d  lea rdi, [rsp]
000076e4393dd941  mov esi, 0x00
000076e4393dd946  mov rax, 0x63DBDEB43530
000076e4393dd950  call rax
000076e4393dd952  movaps xmm7, [rsp]
000076e4393dd956  add rsp, 0x30
000076e4393dd95a  vmovaps xmm0, [rsp]
000076e4393dd95f  vmovaps xmm1, [rsp+0x10]
000076e4393dd965  vmovaps xmm2, [rsp+0x20]
000076e4393dd96b  vmovaps xmm3, [rsp+0x30]
000076e4393dd971  vmovaps xmm4, [rsp+0x40]
000076e4393dd977  vmovaps xmm5, [rsp+0x50]
000076e4393dd97d  vmovaps xmm6, [rsp+0x60]
000076e4393dd983  vmovaps xmm8, [rsp+0x70]
000076e4393dd989  vmovaps xmm9, [rsp+0x80]
000076e4393dd992  vmovaps xmm10, [rsp+0x90]
000076e4393dd99b  vmovaps xmm11, [rsp+0xA0]
000076e4393dd9a4  vmovaps xmm12, [rsp+0xB0]
000076e4393dd9ad  vmovaps xmm13, [rsp+0xC0]
000076e4393dd9b6  vmovaps xmm14, [rsp+0xD0]
000076e4393dd9bf  vmovaps xmm15, [rsp+0xE0]
000076e4393dd9c8  add rsp, 0xF0
000076e4393dd9cf  pop r11
000076e4393dd9d1  pop r10
000076e4393dd9d3  pop r9
000076e4393dd9d5  pop r8
000076e4393dd9d7  pop rsi
000076e4393dd9d8  pop rdi
000076e4393dd9d9  pop rdx
000076e4393dd9da  pop rcx
000076e4393dd9db  pop rax
000076e4393dd9dc  add rsp, 0x08
000076e4393dd9e0  jmp 0x000076E4393DBE87
000076e4393dd9e5  sub rsp, 0x08
000076e4393dd9e9  push rax
000076e4393dd9ea  push rcx
000076e4393dd9eb  push rdx
000076e4393dd9ec  push rdi
000076e4393dd9ed  push rsi
000076e4393dd9ee  push r8
000076e4393dd9f0  push r9
000076e4393dd9f2  push r10
000076e4393dd9f4  push r11
000076e4393dd9f6  sub rsp, 0xF0
000076e4393dd9fd  vmovaps [rsp], xmm0
000076e4393dda02  vmovaps [rsp+0x10], xmm1
000076e4393dda08  vmovaps [rsp+0x20], xmm2
000076e4393dda0e  vmovaps [rsp+0x30], xmm3
000076e4393dda14  vmovaps [rsp+0x40], xmm5
000076e4393dda1a  vmovaps [rsp+0x50], xmm6
000076e4393dda20  vmovaps [rsp+0x60], xmm7
000076e4393dda26  vmovaps [rsp+0x70], xmm8
000076e4393dda2c  vmovaps [rsp+0x80], xmm9
000076e4393dda35  vmovaps [rsp+0x90], xmm10
000076e4393dda3e  vmovaps [rsp+0xA0], xmm11
000076e4393dda47  vmovaps [rsp+0xB0], xmm12
000076e4393dda50  vmovaps [rsp+0xC0], xmm13
000076e4393dda59  vmovaps [rsp+0xD0], xmm14
000076e4393dda62  vmovaps [rsp+0xE0], xmm15
000076e4393dda6b  sub rsp, 0x30
000076e4393dda6f  movaps [rsp], xmm4
000076e4393dda73  movaps [rsp+0x10], xmm15
000076e4393dda79  movaps [rsp+0x20], xmm9
000076e4393dda7f  lea rdi, [rsp]
000076e4393dda83  mov esi, 0x00
000076e4393dda88  mov rax, 0x63DBDEB43530
000076e4393dda92  call rax
000076e4393dda94  movaps xmm4, [rsp]
000076e4393dda98  add rsp, 0x30
000076e4393dda9c  vmovaps xmm0, [rsp]
000076e4393ddaa1  vmovaps xmm1, [rsp+0x10]
000076e4393ddaa7  vmovaps xmm2, [rsp+0x20]
000076e4393ddaad  vmovaps xmm3, [rsp+0x30]
000076e4393ddab3  vmovaps xmm5, [rsp+0x40]
000076e4393ddab9  vmovaps xmm6, [rsp+0x50]
000076e4393ddabf  vmovaps xmm7, [rsp+0x60]
000076e4393ddac5  vmovaps xmm8, [rsp+0x70]
000076e4393ddacb  vmovaps xmm9, [rsp+0x80]
000076e4393ddad4  vmovaps xmm10, [rsp+0x90]
000076e4393ddadd  vmovaps xmm11, [rsp+0xA0]
000076e4393ddae6  vmovaps xmm12, [rsp+0xB0]
000076e4393ddaef  vmovaps xmm13, [rsp+0xC0]
000076e4393ddaf8  vmovaps xmm14, [rsp+0xD0]
000076e4393ddb01  vmovaps xmm15, [rsp+0xE0]
000076e4393ddb0a  add rsp, 0xF0
000076e4393ddb11  pop r11
000076e4393ddb13  pop r10
000076e4393ddb15  pop r9
000076e4393ddb17  pop r8
000076e4393ddb19  pop rsi
000076e4393ddb1a  pop rdi
000076e4393ddb1b  pop rdx
000076e4393ddb1c  pop rcx
000076e4393ddb1d  pop rax
000076e4393ddb1e  add rsp, 0x08
000076e4393ddb22  jmp 0x000076E4393DBEAC
000076e4393ddb27  call 0x000076E4392C4620
000076e4393ddb2c  jmp 0x000076E4393DBEB9
000076e4393ddb31  sub rsp, 0x08
000076e4393ddb35  push rax
000076e4393ddb36  push rcx
000076e4393ddb37  push rdx
000076e4393ddb38  push rdi
000076e4393ddb39  push rsi
000076e4393ddb3a  push r8
000076e4393ddb3c  push r9
000076e4393ddb3e  push r10
000076e4393ddb40  push r11
000076e4393ddb42  sub rsp, 0xF0
000076e4393ddb49  vmovaps [rsp], xmm0
000076e4393ddb4e  vmovaps [rsp+0x10], xmm1
000076e4393ddb54  vmovaps [rsp+0x20], xmm2
000076e4393ddb5a  vmovaps [rsp+0x30], xmm4
000076e4393ddb60  vmovaps [rsp+0x40], xmm5
000076e4393ddb66  vmovaps [rsp+0x50], xmm6
000076e4393ddb6c  vmovaps [rsp+0x60], xmm7
000076e4393ddb72  vmovaps [rsp+0x70], xmm8
000076e4393ddb78  vmovaps [rsp+0x80], xmm9
000076e4393ddb81  vmovaps [rsp+0x90], xmm10
000076e4393ddb8a  vmovaps [rsp+0xA0], xmm11
000076e4393ddb93  vmovaps [rsp+0xB0], xmm12
000076e4393ddb9c  vmovaps [rsp+0xC0], xmm13
000076e4393ddba5  vmovaps [rsp+0xD0], xmm14
000076e4393ddbae  vmovaps [rsp+0xE0], xmm15
000076e4393ddbb7  sub rsp, 0x30
000076e4393ddbbb  movaps [rsp], xmm3
000076e4393ddbbf  movaps [rsp+0x10], xmm1
000076e4393ddbc4  movaps [rsp+0x20], xmm9
000076e4393ddbca  lea rdi, [rsp]
000076e4393ddbce  mov esi, 0x00
000076e4393ddbd3  mov rax, 0x63DBDEB43530
000076e4393ddbdd  call rax
000076e4393ddbdf  movaps xmm3, [rsp]
000076e4393ddbe3  add rsp, 0x30
000076e4393ddbe7  vmovaps xmm0, [rsp]
000076e4393ddbec  vmovaps xmm1, [rsp+0x10]
000076e4393ddbf2  vmovaps xmm2, [rsp+0x20]
000076e4393ddbf8  vmovaps xmm4, [rsp+0x30]
000076e4393ddbfe  vmovaps xmm5, [rsp+0x40]
000076e4393ddc04  vmovaps xmm6, [rsp+0x50]
000076e4393ddc0a  vmovaps xmm7, [rsp+0x60]
000076e4393ddc10  vmovaps xmm8, [rsp+0x70]
000076e4393ddc16  vmovaps xmm9, [rsp+0x80]
000076e4393ddc1f  vmovaps xmm10, [rsp+0x90]
000076e4393ddc28  vmovaps xmm11, [rsp+0xA0]
000076e4393ddc31  vmovaps xmm12, [rsp+0xB0]
000076e4393ddc3a  vmovaps xmm13, [rsp+0xC0]
000076e4393ddc43  vmovaps xmm14, [rsp+0xD0]
000076e4393ddc4c  vmovaps xmm15, [rsp+0xE0]
000076e4393ddc55  add rsp, 0xF0
000076e4393ddc5c  pop r11
000076e4393ddc5e  pop r10
000076e4393ddc60  pop r9
000076e4393ddc62  pop r8
000076e4393ddc64  pop rsi
000076e4393ddc65  pop rdi
000076e4393ddc66  pop rdx
000076e4393ddc67  pop rcx
000076e4393ddc68  pop rax
000076e4393ddc69  add rsp, 0x08
000076e4393ddc6d  jmp 0x000076E4393DBEF6
000076e4393ddc72  sub rsp, 0x08
000076e4393ddc76  push rax
000076e4393ddc77  push rcx
000076e4393ddc78  push rdx
000076e4393ddc79  push rdi
000076e4393ddc7a  push rsi
000076e4393ddc7b  push r8
000076e4393ddc7d  push r9
000076e4393ddc7f  push r10
000076e4393ddc81  push r11
000076e4393ddc83  sub rsp, 0xF0
000076e4393ddc8a  vmovaps [rsp], xmm0
000076e4393ddc8f  vmovaps [rsp+0x10], xmm2
000076e4393ddc95  vmovaps [rsp+0x20], xmm3
000076e4393ddc9b  vmovaps [rsp+0x30], xmm4
000076e4393ddca1  vmovaps [rsp+0x40], xmm5
000076e4393ddca7  vmovaps [rsp+0x50], xmm6
000076e4393ddcad  vmovaps [rsp+0x60], xmm7
000076e4393ddcb3  vmovaps [rsp+0x70], xmm8
000076e4393ddcb9  vmovaps [rsp+0x80], xmm9
000076e4393ddcc2  vmovaps [rsp+0x90], xmm10
000076e4393ddccb  vmovaps [rsp+0xA0], xmm11
000076e4393ddcd4  vmovaps [rsp+0xB0], xmm12
000076e4393ddcdd  vmovaps [rsp+0xC0], xmm13
000076e4393ddce6  vmovaps [rsp+0xD0], xmm14
000076e4393ddcef  vmovaps [rsp+0xE0], xmm15
000076e4393ddcf8  sub rsp, 0x30
000076e4393ddcfc  movaps [rsp], xmm1
000076e4393ddd00  movaps [rsp+0x10], xmm15
000076e4393ddd06  movaps [rsp+0x20], xmm9
000076e4393ddd0c  lea rdi, [rsp]
000076e4393ddd10  mov esi, 0x00
000076e4393ddd15  mov rax, 0x63DBDEB43530
000076e4393ddd1f  call rax
000076e4393ddd21  movaps xmm1, [rsp]
000076e4393ddd25  add rsp, 0x30
000076e4393ddd29  vmovaps xmm0, [rsp]
000076e4393ddd2e  vmovaps xmm2, [rsp+0x10]
000076e4393ddd34  vmovaps xmm3, [rsp+0x20]
000076e4393ddd3a  vmovaps xmm4, [rsp+0x30]
000076e4393ddd40  vmovaps xmm5, [rsp+0x40]
000076e4393ddd46  vmovaps xmm6, [rsp+0x50]
000076e4393ddd4c  vmovaps xmm7, [rsp+0x60]
000076e4393ddd52  vmovaps xmm8, [rsp+0x70]
000076e4393ddd58  vmovaps xmm9, [rsp+0x80]
000076e4393ddd61  vmovaps xmm10, [rsp+0x90]
000076e4393ddd6a  vmovaps xmm11, [rsp+0xA0]
000076e4393ddd73  vmovaps xmm12, [rsp+0xB0]
000076e4393ddd7c  vmovaps xmm13, [rsp+0xC0]
000076e4393ddd85  vmovaps xmm14, [rsp+0xD0]
000076e4393ddd8e  vmovaps xmm15, [rsp+0xE0]
000076e4393ddd97  add rsp, 0xF0
000076e4393ddd9e  pop r11
000076e4393ddda0  pop r10
000076e4393ddda2  pop r9
000076e4393ddda4  pop r8
000076e4393ddda6  pop rsi
000076e4393ddda7  pop rdi
000076e4393ddda8  pop rdx
000076e4393ddda9  pop rcx
000076e4393dddaa  pop rax
000076e4393dddab  add rsp, 0x08
000076e4393dddaf  jmp 0x000076E4393DBF7E
000076e4393dddb4  call 0x000076E4392C4620
000076e4393dddb9  jmp 0x000076E4393DBF8B
000076e4393dddbe  sub rsp, 0x08
000076e4393dddc2  push rax
000076e4393dddc3  push rcx
000076e4393dddc4  push rdx
000076e4393dddc5  push rdi
000076e4393dddc6  push rsi
000076e4393dddc7  push r8
000076e4393dddc9  push r9
000076e4393dddcb  push r10
000076e4393dddcd  push r11
000076e4393dddcf  sub rsp, 0xF0
000076e4393dddd6  vmovaps [rsp], xmm0
000076e4393ddddb  vmovaps [rsp+0x10], xmm2
000076e4393ddde1  vmovaps [rsp+0x20], xmm3
000076e4393ddde7  vmovaps [rsp+0x30], xmm4
000076e4393ddded  vmovaps [rsp+0x40], xmm5
000076e4393dddf3  vmovaps [rsp+0x50], xmm6
000076e4393dddf9  vmovaps [rsp+0x60], xmm7
000076e4393dddff  vmovaps [rsp+0x70], xmm8
000076e4393dde05  vmovaps [rsp+0x80], xmm9
000076e4393dde0e  vmovaps [rsp+0x90], xmm10
000076e4393dde17  vmovaps [rsp+0xA0], xmm11
000076e4393dde20  vmovaps [rsp+0xB0], xmm12
000076e4393dde29  vmovaps [rsp+0xC0], xmm13
000076e4393dde32  vmovaps [rsp+0xD0], xmm14
000076e4393dde3b  vmovaps [rsp+0xE0], xmm15
000076e4393dde44  sub rsp, 0x30
000076e4393dde48  movaps [rsp], xmm1
000076e4393dde4c  movaps [rsp+0x10], xmm5
000076e4393dde51  movaps [rsp+0x20], xmm7
000076e4393dde56  lea rdi, [rsp]
000076e4393dde5a  mov esi, 0x00
000076e4393dde5f  mov rax, 0x63DBDEB43530
000076e4393dde69  call rax
000076e4393dde6b  movaps xmm1, [rsp]
000076e4393dde6f  add rsp, 0x30
000076e4393dde73  vmovaps xmm0, [rsp]
000076e4393dde78  vmovaps xmm2, [rsp+0x10]
000076e4393dde7e  vmovaps xmm3, [rsp+0x20]
000076e4393dde84  vmovaps xmm4, [rsp+0x30]
000076e4393dde8a  vmovaps xmm5, [rsp+0x40]
000076e4393dde90  vmovaps xmm6, [rsp+0x50]
000076e4393dde96  vmovaps xmm7, [rsp+0x60]
000076e4393dde9c  vmovaps xmm8, [rsp+0x70]
000076e4393ddea2  vmovaps xmm9, [rsp+0x80]
000076e4393ddeab  vmovaps xmm10, [rsp+0x90]
000076e4393ddeb4  vmovaps xmm11, [rsp+0xA0]
000076e4393ddebd  vmovaps xmm12, [rsp+0xB0]
000076e4393ddec6  vmovaps xmm13, [rsp+0xC0]
000076e4393ddecf  vmovaps xmm14, [rsp+0xD0]
000076e4393dded8  vmovaps xmm15, [rsp+0xE0]
000076e4393ddee1  add rsp, 0xF0
000076e4393ddee8  pop r11
000076e4393ddeea  pop r10
000076e4393ddeec  pop r9
000076e4393ddeee  pop r8
000076e4393ddef0  pop rsi
000076e4393ddef1  pop rdi
000076e4393ddef2  pop rdx
000076e4393ddef3  pop rcx
000076e4393ddef4  pop rax
000076e4393ddef5  add rsp, 0x08
000076e4393ddef9  jmp 0x000076E4393DC030
000076e4393ddefe  sub rsp, 0x08
000076e4393ddf02  push rax
000076e4393ddf03  push rcx
000076e4393ddf04  push rdx
000076e4393ddf05  push rdi
000076e4393ddf06  push rsi
000076e4393ddf07  push r8
000076e4393ddf09  push r9
000076e4393ddf0b  push r10
000076e4393ddf0d  push r11
000076e4393ddf0f  sub rsp, 0xF0
000076e4393ddf16  vmovaps [rsp], xmm0
000076e4393ddf1b  vmovaps [rsp+0x10], xmm1
000076e4393ddf21  vmovaps [rsp+0x20], xmm2
000076e4393ddf27  vmovaps [rsp+0x30], xmm3
000076e4393ddf2d  vmovaps [rsp+0x40], xmm4
000076e4393ddf33  vmovaps [rsp+0x50], xmm5
000076e4393ddf39  vmovaps [rsp+0x60], xmm6
000076e4393ddf3f  vmovaps [rsp+0x70], xmm8
000076e4393ddf45  vmovaps [rsp+0x80], xmm9
000076e4393ddf4e  vmovaps [rsp+0x90], xmm10
000076e4393ddf57  vmovaps [rsp+0xA0], xmm11
000076e4393ddf60  vmovaps [rsp+0xB0], xmm12
000076e4393ddf69  vmovaps [rsp+0xC0], xmm13
000076e4393ddf72  vmovaps [rsp+0xD0], xmm14
000076e4393ddf7b  vmovaps [rsp+0xE0], xmm15
000076e4393ddf84  sub rsp, 0x30
000076e4393ddf88  movaps [rsp], xmm7
000076e4393ddf8c  movaps [rsp+0x10], xmm5
000076e4393ddf91  movaps [rsp+0x20], xmm15
000076e4393ddf97  lea rdi, [rsp]
000076e4393ddf9b  mov esi, 0x00
000076e4393ddfa0  mov rax, 0x63DBDEB43530
000076e4393ddfaa  call rax
000076e4393ddfac  movaps xmm7, [rsp]
000076e4393ddfb0  add rsp, 0x30
000076e4393ddfb4  vmovaps xmm0, [rsp]
000076e4393ddfb9  vmovaps xmm1, [rsp+0x10]
000076e4393ddfbf  vmovaps xmm2, [rsp+0x20]
000076e4393ddfc5  vmovaps xmm3, [rsp+0x30]
000076e4393ddfcb  vmovaps xmm4, [rsp+0x40]
000076e4393ddfd1  vmovaps xmm5, [rsp+0x50]
000076e4393ddfd7  vmovaps xmm6, [rsp+0x60]
000076e4393ddfdd  vmovaps xmm8, [rsp+0x70]
000076e4393ddfe3  vmovaps xmm9, [rsp+0x80]
000076e4393ddfec  vmovaps xmm10, [rsp+0x90]
000076e4393ddff5  vmovaps xmm11, [rsp+0xA0]
000076e4393ddffe  vmovaps xmm12, [rsp+0xB0]
000076e4393de007  vmovaps xmm13, [rsp+0xC0]
000076e4393de010  vmovaps xmm14, [rsp+0xD0]
000076e4393de019  vmovaps xmm15, [rsp+0xE0]
000076e4393de022  add rsp, 0xF0
000076e4393de029  pop r11
000076e4393de02b  pop r10
000076e4393de02d  pop r9
000076e4393de02f  pop r8
000076e4393de031  pop rsi
000076e4393de032  pop rdi
000076e4393de033  pop rdx
000076e4393de034  pop rcx
000076e4393de035  pop rax
000076e4393de036  add rsp, 0x08
000076e4393de03a  jmp 0x000076E4393DC066
000076e4393de03f  call 0x000076E4392B52F0
000076e4393de044  jmp 0x000076E4393DC073
000076e4393de049  sub rsp, 0x08
000076e4393de04d  push rax
000076e4393de04e  push rcx
000076e4393de04f  push rdx
000076e4393de050  push rdi
000076e4393de051  push rsi
000076e4393de052  push r8
000076e4393de054  push r9
000076e4393de056  push r10
000076e4393de058  push r11
000076e4393de05a  sub rsp, 0xF0
000076e4393de061  vmovaps [rsp], xmm0
000076e4393de066  vmovaps [rsp+0x10], xmm1
000076e4393de06c  vmovaps [rsp+0x20], xmm2
000076e4393de072  vmovaps [rsp+0x30], xmm3
000076e4393de078  vmovaps [rsp+0x40], xmm4
000076e4393de07e  vmovaps [rsp+0x50], xmm5
000076e4393de084  vmovaps [rsp+0x60], xmm6
000076e4393de08a  vmovaps [rsp+0x70], xmm7
000076e4393de090  vmovaps [rsp+0x80], xmm8
000076e4393de099  vmovaps [rsp+0x90], xmm9
000076e4393de0a2  vmovaps [rsp+0xA0], xmm10
000076e4393de0ab  vmovaps [rsp+0xB0], xmm11
000076e4393de0b4  vmovaps [rsp+0xC0], xmm12
000076e4393de0bd  vmovaps [rsp+0xD0], xmm13
000076e4393de0c6  vmovaps [rsp+0xE0], xmm14
000076e4393de0cf  sub rsp, 0x30
000076e4393de0d3  movaps [rsp], xmm15
000076e4393de0d8  movaps [rsp+0x10], xmm5
000076e4393de0dd  movaps [rsp+0x20], xmm3
000076e4393de0e2  lea rdi, [rsp]
000076e4393de0e6  mov esi, 0x00
000076e4393de0eb  mov rax, 0x63DBDEB43530
000076e4393de0f5  call rax
000076e4393de0f7  movaps xmm15, [rsp]
000076e4393de0fc  add rsp, 0x30
000076e4393de100  vmovaps xmm0, [rsp]
000076e4393de105  vmovaps xmm1, [rsp+0x10]
000076e4393de10b  vmovaps xmm2, [rsp+0x20]
000076e4393de111  vmovaps xmm3, [rsp+0x30]
000076e4393de117  vmovaps xmm4, [rsp+0x40]
000076e4393de11d  vmovaps xmm5, [rsp+0x50]
000076e4393de123  vmovaps xmm6, [rsp+0x60]
000076e4393de129  vmovaps xmm7, [rsp+0x70]
000076e4393de12f  vmovaps xmm8, [rsp+0x80]
000076e4393de138  vmovaps xmm9, [rsp+0x90]
000076e4393de141  vmovaps xmm10, [rsp+0xA0]
000076e4393de14a  vmovaps xmm11, [rsp+0xB0]
000076e4393de153  vmovaps xmm12, [rsp+0xC0]
000076e4393de15c  vmovaps xmm13, [rsp+0xD0]
000076e4393de165  vmovaps xmm14, [rsp+0xE0]
000076e4393de16e  add rsp, 0xF0
000076e4393de175  pop r11
000076e4393de177  pop r10
000076e4393de179  pop r9
000076e4393de17b  pop r8
000076e4393de17d  pop rsi
000076e4393de17e  pop rdi
000076e4393de17f  pop rdx
000076e4393de180  pop rcx
000076e4393de181  pop rax
000076e4393de182  add rsp, 0x08
000076e4393de186  jmp 0x000076E4393DC099
000076e4393de18b  sub rsp, 0x08
000076e4393de18f  push rax
000076e4393de190  push rcx
000076e4393de191  push rdx
000076e4393de192  push rdi
000076e4393de193  push rsi
000076e4393de194  push r8
000076e4393de196  push r9
000076e4393de198  push r10
000076e4393de19a  push r11
000076e4393de19c  sub rsp, 0xF0
000076e4393de1a3  vmovaps [rsp], xmm0
000076e4393de1a8  vmovaps [rsp+0x10], xmm2
000076e4393de1ae  vmovaps [rsp+0x20], xmm3
000076e4393de1b4  vmovaps [rsp+0x30], xmm4
000076e4393de1ba  vmovaps [rsp+0x40], xmm5
000076e4393de1c0  vmovaps [rsp+0x50], xmm6
000076e4393de1c6  vmovaps [rsp+0x60], xmm7
000076e4393de1cc  vmovaps [rsp+0x70], xmm8
000076e4393de1d2  vmovaps [rsp+0x80], xmm9
000076e4393de1db  vmovaps [rsp+0x90], xmm10
000076e4393de1e4  vmovaps [rsp+0xA0], xmm11
000076e4393de1ed  vmovaps [rsp+0xB0], xmm12
000076e4393de1f6  vmovaps [rsp+0xC0], xmm13
000076e4393de1ff  vmovaps [rsp+0xD0], xmm14
000076e4393de208  vmovaps [rsp+0xE0], xmm15
000076e4393de211  sub rsp, 0x30
000076e4393de215  movaps [rsp], xmm1
000076e4393de219  movaps [rsp+0x10], xmm5
000076e4393de21e  movaps [rsp+0x20], xmm4
000076e4393de223  lea rdi, [rsp]
000076e4393de227  mov esi, 0x00
000076e4393de22c  mov rax, 0x63DBDEB43530
000076e4393de236  call rax
000076e4393de238  movaps xmm1, [rsp]
000076e4393de23c  add rsp, 0x30
000076e4393de240  vmovaps xmm0, [rsp]
000076e4393de245  vmovaps xmm2, [rsp+0x10]
000076e4393de24b  vmovaps xmm3, [rsp+0x20]
000076e4393de251  vmovaps xmm4, [rsp+0x30]
000076e4393de257  vmovaps xmm5, [rsp+0x40]
000076e4393de25d  vmovaps xmm6, [rsp+0x50]
000076e4393de263  vmovaps xmm7, [rsp+0x60]
000076e4393de269  vmovaps xmm8, [rsp+0x70]
000076e4393de26f  vmovaps xmm9, [rsp+0x80]
000076e4393de278  vmovaps xmm10, [rsp+0x90]
000076e4393de281  vmovaps xmm11, [rsp+0xA0]
000076e4393de28a  vmovaps xmm12, [rsp+0xB0]
000076e4393de293  vmovaps xmm13, [rsp+0xC0]
000076e4393de29c  vmovaps xmm14, [rsp+0xD0]
000076e4393de2a5  vmovaps xmm15, [rsp+0xE0]
000076e4393de2ae  add rsp, 0xF0
000076e4393de2b5  pop r11
000076e4393de2b7  pop r10
000076e4393de2b9  pop r9
000076e4393de2bb  pop r8
000076e4393de2bd  pop rsi
000076e4393de2be  pop rdi
000076e4393de2bf  pop rdx
000076e4393de2c0  pop rcx
000076e4393de2c1  pop rax
000076e4393de2c2  add rsp, 0x08
000076e4393de2c6  jmp 0x000076E4393DC0B9
000076e4393de2cb  sub rsp, 0x08
000076e4393de2cf  push rax
000076e4393de2d0  push rcx
000076e4393de2d1  push rdx
000076e4393de2d2  push rdi
000076e4393de2d3  push rsi
000076e4393de2d4  push r8
000076e4393de2d6  push r9
000076e4393de2d8  push r10
000076e4393de2da  push r11
000076e4393de2dc  sub rsp, 0xF0
000076e4393de2e3  vmovaps [rsp], xmm0
000076e4393de2e8  vmovaps [rsp+0x10], xmm1
000076e4393de2ee  vmovaps [rsp+0x20], xmm2
000076e4393de2f4  vmovaps [rsp+0x30], xmm3
000076e4393de2fa  vmovaps [rsp+0x40], xmm5
000076e4393de300  vmovaps [rsp+0x50], xmm6
000076e4393de306  vmovaps [rsp+0x60], xmm7
000076e4393de30c  vmovaps [rsp+0x70], xmm8
000076e4393de312  vmovaps [rsp+0x80], xmm9
000076e4393de31b  vmovaps [rsp+0x90], xmm10
000076e4393de324  vmovaps [rsp+0xA0], xmm11
000076e4393de32d  vmovaps [rsp+0xB0], xmm12
000076e4393de336  vmovaps [rsp+0xC0], xmm13
000076e4393de33f  vmovaps [rsp+0xD0], xmm14
000076e4393de348  vmovaps [rsp+0xE0], xmm15
000076e4393de351  sub rsp, 0x30
000076e4393de355  movaps [rsp], xmm4
000076e4393de359  movaps [rsp+0x10], xmm3
000076e4393de35e  movaps [rsp+0x20], xmm5
000076e4393de363  lea rdi, [rsp]
000076e4393de367  mov esi, 0x00
000076e4393de36c  mov rax, 0x63DBDEB43530
000076e4393de376  call rax
000076e4393de378  movaps xmm4, [rsp]
000076e4393de37c  add rsp, 0x30
000076e4393de380  vmovaps xmm0, [rsp]
000076e4393de385  vmovaps xmm1, [rsp+0x10]
000076e4393de38b  vmovaps xmm2, [rsp+0x20]
000076e4393de391  vmovaps xmm3, [rsp+0x30]
000076e4393de397  vmovaps xmm5, [rsp+0x40]
000076e4393de39d  vmovaps xmm6, [rsp+0x50]
000076e4393de3a3  vmovaps xmm7, [rsp+0x60]
000076e4393de3a9  vmovaps xmm8, [rsp+0x70]
000076e4393de3af  vmovaps xmm9, [rsp+0x80]
000076e4393de3b8  vmovaps xmm10, [rsp+0x90]
000076e4393de3c1  vmovaps xmm11, [rsp+0xA0]
000076e4393de3ca  vmovaps xmm12, [rsp+0xB0]
000076e4393de3d3  vmovaps xmm13, [rsp+0xC0]
000076e4393de3dc  vmovaps xmm14, [rsp+0xD0]
000076e4393de3e5  vmovaps xmm15, [rsp+0xE0]
000076e4393de3ee  add rsp, 0xF0
000076e4393de3f5  pop r11
000076e4393de3f7  pop r10
000076e4393de3f9  pop r9
000076e4393de3fb  pop r8
000076e4393de3fd  pop rsi
000076e4393de3fe  pop rdi
000076e4393de3ff  pop rdx
000076e4393de400  pop rcx
000076e4393de401  pop rax
000076e4393de402  add rsp, 0x08
000076e4393de406  jmp 0x000076E4393DC107
000076e4393de40b  call 0x000076E4392B52F0
000076e4393de410  jmp 0x000076E4393DC114
000076e4393de415  sub rsp, 0x08
000076e4393de419  push rax
000076e4393de41a  push rcx
000076e4393de41b  push rdx
000076e4393de41c  push rdi
000076e4393de41d  push rsi
000076e4393de41e  push r8
000076e4393de420  push r9
000076e4393de422  push r10
000076e4393de424  push r11
000076e4393de426  sub rsp, 0xF0
000076e4393de42d  vmovaps [rsp], xmm0
000076e4393de432  vmovaps [rsp+0x10], xmm1
000076e4393de438  vmovaps [rsp+0x20], xmm2
000076e4393de43e  vmovaps [rsp+0x30], xmm3
000076e4393de444  vmovaps [rsp+0x40], xmm4
000076e4393de44a  vmovaps [rsp+0x50], xmm6
000076e4393de450  vmovaps [rsp+0x60], xmm7
000076e4393de456  vmovaps [rsp+0x70], xmm8
000076e4393de45c  vmovaps [rsp+0x80], xmm9
000076e4393de465  vmovaps [rsp+0x90], xmm10
000076e4393de46e  vmovaps [rsp+0xA0], xmm11
000076e4393de477  vmovaps [rsp+0xB0], xmm12
000076e4393de480  vmovaps [rsp+0xC0], xmm13
000076e4393de489  vmovaps [rsp+0xD0], xmm14
000076e4393de492  vmovaps [rsp+0xE0], xmm15
000076e4393de49b  sub rsp, 0x30
000076e4393de49f  movaps [rsp], xmm5
000076e4393de4a3  movaps [rsp+0x10], xmm6
000076e4393de4a8  movaps [rsp+0x20], xmm3
000076e4393de4ad  lea rdi, [rsp]
000076e4393de4b1  mov esi, 0x00
000076e4393de4b6  mov rax, 0x63DBDEB43530
000076e4393de4c0  call rax
000076e4393de4c2  movaps xmm5, [rsp]
000076e4393de4c6  add rsp, 0x30
000076e4393de4ca  vmovaps xmm0, [rsp]
000076e4393de4cf  vmovaps xmm1, [rsp+0x10]
000076e4393de4d5  vmovaps xmm2, [rsp+0x20]
000076e4393de4db  vmovaps xmm3, [rsp+0x30]
000076e4393de4e1  vmovaps xmm4, [rsp+0x40]
000076e4393de4e7  vmovaps xmm6, [rsp+0x50]
000076e4393de4ed  vmovaps xmm7, [rsp+0x60]
000076e4393de4f3  vmovaps xmm8, [rsp+0x70]
000076e4393de4f9  vmovaps xmm9, [rsp+0x80]
000076e4393de502  vmovaps xmm10, [rsp+0x90]
000076e4393de50b  vmovaps xmm11, [rsp+0xA0]
000076e4393de514  vmovaps xmm12, [rsp+0xB0]
000076e4393de51d  vmovaps xmm13, [rsp+0xC0]
000076e4393de526  vmovaps xmm14, [rsp+0xD0]
000076e4393de52f  vmovaps xmm15, [rsp+0xE0]
000076e4393de538  add rsp, 0xF0
000076e4393de53f  pop r11
000076e4393de541  pop r10
000076e4393de543  pop r9
000076e4393de545  pop r8
000076e4393de547  pop rsi
000076e4393de548  pop rdi
000076e4393de549  pop rdx
000076e4393de54a  pop rcx
000076e4393de54b  pop rax
000076e4393de54c  add rsp, 0x08
000076e4393de550  jmp 0x000076E4393DC13A
000076e4393de555  sub rsp, 0x08
000076e4393de559  push rax
000076e4393de55a  push rcx
000076e4393de55b  push rdx
000076e4393de55c  push rdi
000076e4393de55d  push rsi
000076e4393de55e  push r8
000076e4393de560  push r9
000076e4393de562  push r10
000076e4393de564  push r11
000076e4393de566  sub rsp, 0xF0
000076e4393de56d  vmovaps [rsp], xmm0
000076e4393de572  vmovaps [rsp+0x10], xmm1
000076e4393de578  vmovaps [rsp+0x20], xmm2
000076e4393de57e  vmovaps [rsp+0x30], xmm3
000076e4393de584  vmovaps [rsp+0x40], xmm4
000076e4393de58a  vmovaps [rsp+0x50], xmm5
000076e4393de590  vmovaps [rsp+0x60], xmm7
000076e4393de596  vmovaps [rsp+0x70], xmm8
000076e4393de59c  vmovaps [rsp+0x80], xmm9
000076e4393de5a5  vmovaps [rsp+0x90], xmm10
000076e4393de5ae  vmovaps [rsp+0xA0], xmm11
000076e4393de5b7  vmovaps [rsp+0xB0], xmm12
000076e4393de5c0  vmovaps [rsp+0xC0], xmm13
000076e4393de5c9  vmovaps [rsp+0xD0], xmm14
000076e4393de5d2  vmovaps [rsp+0xE0], xmm15
000076e4393de5db  sub rsp, 0x30
000076e4393de5df  movaps [rsp], xmm6
000076e4393de5e3  movaps [rsp+0x10], xmm9
000076e4393de5e9  movaps [rsp+0x20], xmm1
000076e4393de5ee  lea rdi, [rsp]
000076e4393de5f2  mov esi, 0x00
000076e4393de5f7  mov rax, 0x63DBDEB43530
000076e4393de601  call rax
000076e4393de603  movaps xmm6, [rsp]
000076e4393de607  add rsp, 0x30
000076e4393de60b  vmovaps xmm0, [rsp]
000076e4393de610  vmovaps xmm1, [rsp+0x10]
000076e4393de616  vmovaps xmm2, [rsp+0x20]
000076e4393de61c  vmovaps xmm3, [rsp+0x30]
000076e4393de622  vmovaps xmm4, [rsp+0x40]
000076e4393de628  vmovaps xmm5, [rsp+0x50]
000076e4393de62e  vmovaps xmm7, [rsp+0x60]
000076e4393de634  vmovaps xmm8, [rsp+0x70]
000076e4393de63a  vmovaps xmm9, [rsp+0x80]
000076e4393de643  vmovaps xmm10, [rsp+0x90]
000076e4393de64c  vmovaps xmm11, [rsp+0xA0]
000076e4393de655  vmovaps xmm12, [rsp+0xB0]
000076e4393de65e  vmovaps xmm13, [rsp+0xC0]
000076e4393de667  vmovaps xmm14, [rsp+0xD0]
000076e4393de670  vmovaps xmm15, [rsp+0xE0]
000076e4393de679  add rsp, 0xF0
000076e4393de680  pop r11
000076e4393de682  pop r10
000076e4393de684  pop r9
000076e4393de686  pop r8
000076e4393de688  pop rsi
000076e4393de689  pop rdi
000076e4393de68a  pop rdx
000076e4393de68b  pop rcx
000076e4393de68c  pop rax
000076e4393de68d  add rsp, 0x08
000076e4393de691  jmp 0x000076E4393DC15E
000076e4393de696  sub rsp, 0x08
000076e4393de69a  push rax
000076e4393de69b  push rcx
000076e4393de69c  push rdx
000076e4393de69d  push rdi
000076e4393de69e  push rsi
000076e4393de69f  push r8
000076e4393de6a1  push r9
000076e4393de6a3  push r10
000076e4393de6a5  push r11
000076e4393de6a7  sub rsp, 0xF0
000076e4393de6ae  vmovaps [rsp], xmm0
000076e4393de6b3  vmovaps [rsp+0x10], xmm1
000076e4393de6b9  vmovaps [rsp+0x20], xmm2
000076e4393de6bf  vmovaps [rsp+0x30], xmm3
000076e4393de6c5  vmovaps [rsp+0x40], xmm4
000076e4393de6cb  vmovaps [rsp+0x50], xmm5
000076e4393de6d1  vmovaps [rsp+0x60], xmm6
000076e4393de6d7  vmovaps [rsp+0x70], xmm7
000076e4393de6dd  vmovaps [rsp+0x80], xmm8
000076e4393de6e6  vmovaps [rsp+0x90], xmm10
000076e4393de6ef  vmovaps [rsp+0xA0], xmm11
000076e4393de6f8  vmovaps [rsp+0xB0], xmm12
000076e4393de701  vmovaps [rsp+0xC0], xmm13
000076e4393de70a  vmovaps [rsp+0xD0], xmm14
000076e4393de713  vmovaps [rsp+0xE0], xmm15
000076e4393de71c  sub rsp, 0x30
000076e4393de720  movaps [rsp], xmm9
000076e4393de725  movaps [rsp+0x10], xmm3
000076e4393de72a  movaps [rsp+0x20], xmm1
000076e4393de72f  lea rdi, [rsp]
000076e4393de733  mov esi, 0x00
000076e4393de738  mov rax, 0x63DBDEB43530
000076e4393de742  call rax
000076e4393de744  movaps xmm9, [rsp]
000076e4393de749  add rsp, 0x30
000076e4393de74d  vmovaps xmm0, [rsp]
000076e4393de752  vmovaps xmm1, [rsp+0x10]
000076e4393de758  vmovaps xmm2, [rsp+0x20]
000076e4393de75e  vmovaps xmm3, [rsp+0x30]
000076e4393de764  vmovaps xmm4, [rsp+0x40]
000076e4393de76a  vmovaps xmm5, [rsp+0x50]
000076e4393de770  vmovaps xmm6, [rsp+0x60]
000076e4393de776  vmovaps xmm7, [rsp+0x70]
000076e4393de77c  vmovaps xmm8, [rsp+0x80]
000076e4393de785  vmovaps xmm10, [rsp+0x90]
000076e4393de78e  vmovaps xmm11, [rsp+0xA0]
000076e4393de797  vmovaps xmm12, [rsp+0xB0]
000076e4393de7a0  vmovaps xmm13, [rsp+0xC0]
000076e4393de7a9  vmovaps xmm14, [rsp+0xD0]
000076e4393de7b2  vmovaps xmm15, [rsp+0xE0]
000076e4393de7bb  add rsp, 0xF0
000076e4393de7c2  pop r11
000076e4393de7c4  pop r10
000076e4393de7c6  pop r9
000076e4393de7c8  pop r8
000076e4393de7ca  pop rsi
000076e4393de7cb  pop rdi
000076e4393de7cc  pop rdx
000076e4393de7cd  pop rcx
000076e4393de7ce  pop rax
000076e4393de7cf  add rsp, 0x08
000076e4393de7d3  jmp 0x000076E4393DC1AA
000076e4393de7d8  call 0x000076E4392B52F0
000076e4393de7dd  jmp 0x000076E4393DC1B7
000076e4393de7e2  sub rsp, 0x08
000076e4393de7e6  push rax
000076e4393de7e7  push rcx
000076e4393de7e8  push rdx
000076e4393de7e9  push rdi
000076e4393de7ea  push rsi
000076e4393de7eb  push r8
000076e4393de7ed  push r9
000076e4393de7ef  push r10
000076e4393de7f1  push r11
000076e4393de7f3  sub rsp, 0xF0
000076e4393de7fa  vmovaps [rsp], xmm0
000076e4393de7ff  vmovaps [rsp+0x10], xmm1
000076e4393de805  vmovaps [rsp+0x20], xmm2
000076e4393de80b  vmovaps [rsp+0x30], xmm3
000076e4393de811  vmovaps [rsp+0x40], xmm4
000076e4393de817  vmovaps [rsp+0x50], xmm5
000076e4393de81d  vmovaps [rsp+0x60], xmm6
000076e4393de823  vmovaps [rsp+0x70], xmm7
000076e4393de829  vmovaps [rsp+0x80], xmm8
000076e4393de832  vmovaps [rsp+0x90], xmm9
000076e4393de83b  vmovaps [rsp+0xA0], xmm10
000076e4393de844  vmovaps [rsp+0xB0], xmm11
000076e4393de84d  vmovaps [rsp+0xC0], xmm12
000076e4393de856  vmovaps [rsp+0xD0], xmm13
000076e4393de85f  vmovaps [rsp+0xE0], xmm14
000076e4393de868  sub rsp, 0x30
000076e4393de86c  movaps [rsp], xmm15
000076e4393de871  movaps [rsp+0x10], xmm3
000076e4393de876  movaps [rsp+0x20], xmm7
000076e4393de87b  lea rdi, [rsp]
000076e4393de87f  mov esi, 0x00
000076e4393de884  mov rax, 0x63DBDEB43530
000076e4393de88e  call rax
000076e4393de890  movaps xmm15, [rsp]
000076e4393de895  add rsp, 0x30
000076e4393de899  vmovaps xmm0, [rsp]
000076e4393de89e  vmovaps xmm1, [rsp+0x10]
000076e4393de8a4  vmovaps xmm2, [rsp+0x20]
000076e4393de8aa  vmovaps xmm3, [rsp+0x30]
000076e4393de8b0  vmovaps xmm4, [rsp+0x40]
000076e4393de8b6  vmovaps xmm5, [rsp+0x50]
000076e4393de8bc  vmovaps xmm6, [rsp+0x60]
000076e4393de8c2  vmovaps xmm7, [rsp+0x70]
000076e4393de8c8  vmovaps xmm8, [rsp+0x80]
000076e4393de8d1  vmovaps xmm9, [rsp+0x90]
000076e4393de8da  vmovaps xmm10, [rsp+0xA0]
000076e4393de8e3  vmovaps xmm11, [rsp+0xB0]
000076e4393de8ec  vmovaps xmm12, [rsp+0xC0]
000076e4393de8f5  vmovaps xmm13, [rsp+0xD0]
000076e4393de8fe  vmovaps xmm14, [rsp+0xE0]
000076e4393de907  add rsp, 0xF0
000076e4393de90e  pop r11
000076e4393de910  pop r10
000076e4393de912  pop r9
000076e4393de914  pop r8
000076e4393de916  pop rsi
000076e4393de917  pop rdi
000076e4393de918  pop rdx
000076e4393de919  pop rcx
000076e4393de91a  pop rax
000076e4393de91b  add rsp, 0x08
000076e4393de91f  jmp 0x000076E4393DC1E3
000076e4393de924  sub rsp, 0x08
000076e4393de928  push rax
000076e4393de929  push rcx
000076e4393de92a  push rdx
000076e4393de92b  push rdi
000076e4393de92c  push rsi
000076e4393de92d  push r8
000076e4393de92f  push r9
000076e4393de931  push r10
000076e4393de933  push r11
000076e4393de935  sub rsp, 0xF0
000076e4393de93c  vmovaps [rsp], xmm0
000076e4393de941  vmovaps [rsp+0x10], xmm1
000076e4393de947  vmovaps [rsp+0x20], xmm2
000076e4393de94d  vmovaps [rsp+0x30], xmm4
000076e4393de953  vmovaps [rsp+0x40], xmm5
000076e4393de959  vmovaps [rsp+0x50], xmm6
000076e4393de95f  vmovaps [rsp+0x60], xmm7
000076e4393de965  vmovaps [rsp+0x70], xmm8
000076e4393de96b  vmovaps [rsp+0x80], xmm9
000076e4393de974  vmovaps [rsp+0x90], xmm10
000076e4393de97d  vmovaps [rsp+0xA0], xmm11
000076e4393de986  vmovaps [rsp+0xB0], xmm12
000076e4393de98f  vmovaps [rsp+0xC0], xmm13
000076e4393de998  vmovaps [rsp+0xD0], xmm14
000076e4393de9a1  vmovaps [rsp+0xE0], xmm15
000076e4393de9aa  sub rsp, 0x30
000076e4393de9ae  movaps [rsp], xmm3
000076e4393de9b2  movaps [rsp+0x10], xmm1
000076e4393de9b7  movaps [rsp+0x20], xmm15
000076e4393de9bd  lea rdi, [rsp]
000076e4393de9c1  mov esi, 0x00
000076e4393de9c6  mov rax, 0x63DBDEB43530
000076e4393de9d0  call rax
000076e4393de9d2  movaps xmm3, [rsp]
000076e4393de9d6  add rsp, 0x30
000076e4393de9da  vmovaps xmm0, [rsp]
000076e4393de9df  vmovaps xmm1, [rsp+0x10]
000076e4393de9e5  vmovaps xmm2, [rsp+0x20]
000076e4393de9eb  vmovaps xmm4, [rsp+0x30]
000076e4393de9f1  vmovaps xmm5, [rsp+0x40]
000076e4393de9f7  vmovaps xmm6, [rsp+0x50]
000076e4393de9fd  vmovaps xmm7, [rsp+0x60]
000076e4393dea03  vmovaps xmm8, [rsp+0x70]
000076e4393dea09  vmovaps xmm9, [rsp+0x80]
000076e4393dea12  vmovaps xmm10, [rsp+0x90]
000076e4393dea1b  vmovaps xmm11, [rsp+0xA0]
000076e4393dea24  vmovaps xmm12, [rsp+0xB0]
000076e4393dea2d  vmovaps xmm13, [rsp+0xC0]
000076e4393dea36  vmovaps xmm14, [rsp+0xD0]
000076e4393dea3f  vmovaps xmm15, [rsp+0xE0]
000076e4393dea48  add rsp, 0xF0
000076e4393dea4f  pop r11
000076e4393dea51  pop r10
000076e4393dea53  pop r9
000076e4393dea55  pop r8
000076e4393dea57  pop rsi
000076e4393dea58  pop rdi
000076e4393dea59  pop rdx
000076e4393dea5a  pop rcx
000076e4393dea5b  pop rax
000076e4393dea5c  add rsp, 0x08
000076e4393dea60  jmp 0x000076E4393DC272
000076e4393dea65  call 0x000076E4392B52F0
000076e4393dea6a  jmp 0x000076E4393DC27C
000076e4393dea6f  sub rsp, 0x08
000076e4393dea73  push rax
000076e4393dea74  push rcx
000076e4393dea75  push rdx
000076e4393dea76  push rdi
000076e4393dea77  push rsi
000076e4393dea78  push r8
000076e4393dea7a  push r9
000076e4393dea7c  push r10
000076e4393dea7e  push r11
000076e4393dea80  sub rsp, 0xF0
000076e4393dea87  vmovaps [rsp], xmm0
000076e4393dea8c  vmovaps [rsp+0x10], xmm1
000076e4393dea92  vmovaps [rsp+0x20], xmm2
000076e4393dea98  vmovaps [rsp+0x30], xmm3
000076e4393dea9e  vmovaps [rsp+0x40], xmm4
000076e4393deaa4  vmovaps [rsp+0x50], xmm5
000076e4393deaaa  vmovaps [rsp+0x60], xmm6
000076e4393deab0  vmovaps [rsp+0x70], xmm7
000076e4393deab6  vmovaps [rsp+0x80], xmm8
000076e4393deabf  vmovaps [rsp+0x90], xmm9
000076e4393deac8  vmovaps [rsp+0xA0], xmm10
000076e4393dead1  vmovaps [rsp+0xB0], xmm11
000076e4393deada  vmovaps [rsp+0xC0], xmm12
000076e4393deae3  vmovaps [rsp+0xD0], xmm13
000076e4393deaec  vmovaps [rsp+0xE0], xmm14
000076e4393deaf5  sub rsp, 0x30
000076e4393deaf9  movaps [rsp], xmm15
000076e4393deafe  movaps [rsp+0x10], xmm14
000076e4393deb04  movaps [rsp+0x20], xmm4
000076e4393deb09  lea rdi, [rsp]
000076e4393deb0d  mov esi, 0x00
000076e4393deb12  mov rax, 0x63DBDEB43530
000076e4393deb1c  call rax
000076e4393deb1e  movaps xmm15, [rsp]
000076e4393deb23  add rsp, 0x30
000076e4393deb27  vmovaps xmm0, [rsp]
000076e4393deb2c  vmovaps xmm1, [rsp+0x10]
000076e4393deb32  vmovaps xmm2, [rsp+0x20]
000076e4393deb38  vmovaps xmm3, [rsp+0x30]
000076e4393deb3e  vmovaps xmm4, [rsp+0x40]
000076e4393deb44  vmovaps xmm5, [rsp+0x50]
000076e4393deb4a  vmovaps xmm6, [rsp+0x60]
000076e4393deb50  vmovaps xmm7, [rsp+0x70]
000076e4393deb56  vmovaps xmm8, [rsp+0x80]
000076e4393deb5f  vmovaps xmm9, [rsp+0x90]
000076e4393deb68  vmovaps xmm10, [rsp+0xA0]
000076e4393deb71  vmovaps xmm11, [rsp+0xB0]
000076e4393deb7a  vmovaps xmm12, [rsp+0xC0]
000076e4393deb83  vmovaps xmm13, [rsp+0xD0]
000076e4393deb8c  vmovaps xmm14, [rsp+0xE0]
000076e4393deb95  add rsp, 0xF0
000076e4393deb9c  pop r11
000076e4393deb9e  pop r10
000076e4393deba0  pop r9
000076e4393deba2  pop r8
000076e4393deba4  pop rsi
000076e4393deba5  pop rdi
000076e4393deba6  pop rdx
000076e4393deba7  pop rcx
000076e4393deba8  pop rax
000076e4393deba9  add rsp, 0x08
000076e4393debad  jmp 0x000076E4393DC2AA
000076e4393debb2  sub rsp, 0x08
000076e4393debb6  push rax
000076e4393debb7  push rcx
000076e4393debb8  push rdx
000076e4393debb9  push rdi
000076e4393debba  push rsi
000076e4393debbb  push r8
000076e4393debbd  push r9
000076e4393debbf  push r10
000076e4393debc1  push r11
000076e4393debc3  sub rsp, 0xF0
000076e4393debca  vmovaps [rsp], xmm0
000076e4393debcf  vmovaps [rsp+0x10], xmm1
000076e4393debd5  vmovaps [rsp+0x20], xmm2
000076e4393debdb  vmovaps [rsp+0x30], xmm3
000076e4393debe1  vmovaps [rsp+0x40], xmm4
000076e4393debe7  vmovaps [rsp+0x50], xmm5
000076e4393debed  vmovaps [rsp+0x60], xmm6
000076e4393debf3  vmovaps [rsp+0x70], xmm7
000076e4393debf9  vmovaps [rsp+0x80], xmm8
000076e4393dec02  vmovaps [rsp+0x90], xmm9
000076e4393dec0b  vmovaps [rsp+0xA0], xmm10
000076e4393dec14  vmovaps [rsp+0xB0], xmm11
000076e4393dec1d  vmovaps [rsp+0xC0], xmm12
000076e4393dec26  vmovaps [rsp+0xD0], xmm13
000076e4393dec2f  vmovaps [rsp+0xE0], xmm15
000076e4393dec38  sub rsp, 0x30
000076e4393dec3c  movaps [rsp], xmm14
000076e4393dec41  movaps [rsp+0x10], xmm2
000076e4393dec46  movaps [rsp+0x20], xmm1
000076e4393dec4b  lea rdi, [rsp]
000076e4393dec4f  mov esi, 0x00
000076e4393dec54  mov rax, 0x63DBDEB43530
000076e4393dec5e  call rax
000076e4393dec60  movaps xmm14, [rsp]
000076e4393dec65  add rsp, 0x30
000076e4393dec69  vmovaps xmm0, [rsp]
000076e4393dec6e  vmovaps xmm1, [rsp+0x10]
000076e4393dec74  vmovaps xmm2, [rsp+0x20]
000076e4393dec7a  vmovaps xmm3, [rsp+0x30]
000076e4393dec80  vmovaps xmm4, [rsp+0x40]
000076e4393dec86  vmovaps xmm5, [rsp+0x50]
000076e4393dec8c  vmovaps xmm6, [rsp+0x60]
000076e4393dec92  vmovaps xmm7, [rsp+0x70]
000076e4393dec98  vmovaps xmm8, [rsp+0x80]
000076e4393deca1  vmovaps xmm9, [rsp+0x90]
000076e4393decaa  vmovaps xmm10, [rsp+0xA0]
000076e4393decb3  vmovaps xmm11, [rsp+0xB0]
000076e4393decbc  vmovaps xmm12, [rsp+0xC0]
000076e4393decc5  vmovaps xmm13, [rsp+0xD0]
000076e4393decce  vmovaps xmm15, [rsp+0xE0]
000076e4393decd7  add rsp, 0xF0
000076e4393decde  pop r11
000076e4393dece0  pop r10
000076e4393dece2  pop r9
000076e4393dece4  pop r8
000076e4393dece6  pop rsi
000076e4393dece7  pop rdi
000076e4393dece8  pop rdx
000076e4393dece9  pop rcx
000076e4393decea  pop rax
000076e4393deceb  add rsp, 0x08
000076e4393decef  jmp 0x000076E4393DC2D0
000076e4393decf4  sub rsp, 0x08
000076e4393decf8  push rax
000076e4393decf9  push rcx
000076e4393decfa  push rdx
000076e4393decfb  push rdi
000076e4393decfc  push rsi
000076e4393decfd  push r8
000076e4393decff  push r9
000076e4393ded01  push r10
000076e4393ded03  push r11
000076e4393ded05  sub rsp, 0xF0
000076e4393ded0c  vmovaps [rsp], xmm0
000076e4393ded11  vmovaps [rsp+0x10], xmm2
000076e4393ded17  vmovaps [rsp+0x20], xmm3
000076e4393ded1d  vmovaps [rsp+0x30], xmm4
000076e4393ded23  vmovaps [rsp+0x40], xmm5
000076e4393ded29  vmovaps [rsp+0x50], xmm6
000076e4393ded2f  vmovaps [rsp+0x60], xmm7
000076e4393ded35  vmovaps [rsp+0x70], xmm8
000076e4393ded3b  vmovaps [rsp+0x80], xmm9
000076e4393ded44  vmovaps [rsp+0x90], xmm10
000076e4393ded4d  vmovaps [rsp+0xA0], xmm11
000076e4393ded56  vmovaps [rsp+0xB0], xmm12
000076e4393ded5f  vmovaps [rsp+0xC0], xmm13
000076e4393ded68  vmovaps [rsp+0xD0], xmm14
000076e4393ded71  vmovaps [rsp+0xE0], xmm15
000076e4393ded7a  sub rsp, 0x30
000076e4393ded7e  movaps [rsp], xmm1
000076e4393ded82  movaps [rsp+0x10], xmm4
000076e4393ded87  movaps [rsp+0x20], xmm9
000076e4393ded8d  lea rdi, [rsp]
000076e4393ded91  mov esi, 0x00
000076e4393ded96  mov rax, 0x63DBDEB43530
000076e4393deda0  call rax
000076e4393deda2  movaps xmm1, [rsp]
000076e4393deda6  add rsp, 0x30
000076e4393dedaa  vmovaps xmm0, [rsp]
000076e4393dedaf  vmovaps xmm2, [rsp+0x10]
000076e4393dedb5  vmovaps xmm3, [rsp+0x20]
000076e4393dedbb  vmovaps xmm4, [rsp+0x30]
000076e4393dedc1  vmovaps xmm5, [rsp+0x40]
000076e4393dedc7  vmovaps xmm6, [rsp+0x50]
000076e4393dedcd  vmovaps xmm7, [rsp+0x60]
000076e4393dedd3  vmovaps xmm8, [rsp+0x70]
000076e4393dedd9  vmovaps xmm9, [rsp+0x80]
000076e4393dede2  vmovaps xmm10, [rsp+0x90]
000076e4393dedeb  vmovaps xmm11, [rsp+0xA0]
000076e4393dedf4  vmovaps xmm12, [rsp+0xB0]
000076e4393dedfd  vmovaps xmm13, [rsp+0xC0]
000076e4393dee06  vmovaps xmm14, [rsp+0xD0]
000076e4393dee0f  vmovaps xmm15, [rsp+0xE0]
000076e4393dee18  add rsp, 0xF0
000076e4393dee1f  pop r11
000076e4393dee21  pop r10
000076e4393dee23  pop r9
000076e4393dee25  pop r8
000076e4393dee27  pop rsi
000076e4393dee28  pop rdi
000076e4393dee29  pop rdx
000076e4393dee2a  pop rcx
000076e4393dee2b  pop rax
000076e4393dee2c  add rsp, 0x08
000076e4393dee30  jmp 0x000076E4393DC2EE
000076e4393dee35  sub rsp, 0x08
000076e4393dee39  push rax
000076e4393dee3a  push rcx
000076e4393dee3b  push rdx
000076e4393dee3c  push rdi
000076e4393dee3d  push rsi
000076e4393dee3e  push r8
000076e4393dee40  push r9
000076e4393dee42  push r10
000076e4393dee44  push r11
000076e4393dee46  sub rsp, 0xF0
000076e4393dee4d  vmovaps [rsp], xmm0
000076e4393dee52  vmovaps [rsp+0x10], xmm1
000076e4393dee58  vmovaps [rsp+0x20], xmm2
000076e4393dee5e  vmovaps [rsp+0x30], xmm3
000076e4393dee64  vmovaps [rsp+0x40], xmm5
000076e4393dee6a  vmovaps [rsp+0x50], xmm6
000076e4393dee70  vmovaps [rsp+0x60], xmm7
000076e4393dee76  vmovaps [rsp+0x70], xmm8
000076e4393dee7c  vmovaps [rsp+0x80], xmm9
000076e4393dee85  vmovaps [rsp+0x90], xmm10
000076e4393dee8e  vmovaps [rsp+0xA0], xmm11
000076e4393dee97  vmovaps [rsp+0xB0], xmm12
000076e4393deea0  vmovaps [rsp+0xC0], xmm13
000076e4393deea9  vmovaps [rsp+0xD0], xmm14
000076e4393deeb2  vmovaps [rsp+0xE0], xmm15
000076e4393deebb  sub rsp, 0x30
000076e4393deebf  movaps [rsp], xmm4
000076e4393deec3  movaps [rsp+0x10], xmm2
000076e4393deec8  movaps [rsp+0x20], xmm9
000076e4393deece  lea rdi, [rsp]
000076e4393deed2  mov esi, 0x00
000076e4393deed7  mov rax, 0x63DBDEB43530
000076e4393deee1  call rax
000076e4393deee3  movaps xmm4, [rsp]
000076e4393deee7  add rsp, 0x30
000076e4393deeeb  vmovaps xmm0, [rsp]
000076e4393deef0  vmovaps xmm1, [rsp+0x10]
000076e4393deef6  vmovaps xmm2, [rsp+0x20]
000076e4393deefc  vmovaps xmm3, [rsp+0x30]
000076e4393def02  vmovaps xmm5, [rsp+0x40]
000076e4393def08  vmovaps xmm6, [rsp+0x50]
000076e4393def0e  vmovaps xmm7, [rsp+0x60]
000076e4393def14  vmovaps xmm8, [rsp+0x70]
000076e4393def1a  vmovaps xmm9, [rsp+0x80]
000076e4393def23  vmovaps xmm10, [rsp+0x90]
000076e4393def2c  vmovaps xmm11, [rsp+0xA0]
000076e4393def35  vmovaps xmm12, [rsp+0xB0]
000076e4393def3e  vmovaps xmm13, [rsp+0xC0]
000076e4393def47  vmovaps xmm14, [rsp+0xD0]
000076e4393def50  vmovaps xmm15, [rsp+0xE0]
000076e4393def59  add rsp, 0xF0
000076e4393def60  pop r11
000076e4393def62  pop r10
000076e4393def64  pop r9
000076e4393def66  pop r8
000076e4393def68  pop rsi
000076e4393def69  pop rdi
000076e4393def6a  pop rdx
000076e4393def6b  pop rcx
000076e4393def6c  pop rax
000076e4393def6d  add rsp, 0x08
000076e4393def71  jmp 0x000076E4393DC31E
000076e4393def76  sub rsp, 0x08
000076e4393def7a  push rax
000076e4393def7b  push rcx
000076e4393def7c  push rdx
000076e4393def7d  push rdi
000076e4393def7e  push rsi
000076e4393def7f  push r8
000076e4393def81  push r9
000076e4393def83  push r10
000076e4393def85  push r11
000076e4393def87  sub rsp, 0xF0
000076e4393def8e  vmovaps [rsp], xmm0
000076e4393def93  vmovaps [rsp+0x10], xmm1
000076e4393def99  vmovaps [rsp+0x20], xmm2
000076e4393def9f  vmovaps [rsp+0x30], xmm3
000076e4393defa5  vmovaps [rsp+0x40], xmm4
000076e4393defab  vmovaps [rsp+0x50], xmm5
000076e4393defb1  vmovaps [rsp+0x60], xmm6
000076e4393defb7  vmovaps [rsp+0x70], xmm7
000076e4393defbd  vmovaps [rsp+0x80], xmm8
000076e4393defc6  vmovaps [rsp+0x90], xmm10
000076e4393defcf  vmovaps [rsp+0xA0], xmm11
000076e4393defd8  vmovaps [rsp+0xB0], xmm12
000076e4393defe1  vmovaps [rsp+0xC0], xmm13
000076e4393defea  vmovaps [rsp+0xD0], xmm14
000076e4393deff3  vmovaps [rsp+0xE0], xmm15
000076e4393deffc  sub rsp, 0x30
000076e4393df000  movaps [rsp], xmm9
000076e4393df005  movaps [rsp+0x10], xmm2
000076e4393df00a  movaps [rsp+0x20], xmm1
000076e4393df00f  lea rdi, [rsp]
000076e4393df013  mov esi, 0x00
000076e4393df018  mov rax, 0x63DBDEB43530
000076e4393df022  call rax
000076e4393df024  movaps xmm9, [rsp]
000076e4393df029  add rsp, 0x30
000076e4393df02d  vmovaps xmm0, [rsp]
000076e4393df032  vmovaps xmm1, [rsp+0x10]
000076e4393df038  vmovaps xmm2, [rsp+0x20]
000076e4393df03e  vmovaps xmm3, [rsp+0x30]
000076e4393df044  vmovaps xmm4, [rsp+0x40]
000076e4393df04a  vmovaps xmm5, [rsp+0x50]
000076e4393df050  vmovaps xmm6, [rsp+0x60]
000076e4393df056  vmovaps xmm7, [rsp+0x70]
000076e4393df05c  vmovaps xmm8, [rsp+0x80]
000076e4393df065  vmovaps xmm10, [rsp+0x90]
000076e4393df06e  vmovaps xmm11, [rsp+0xA0]
000076e4393df077  vmovaps xmm12, [rsp+0xB0]
000076e4393df080  vmovaps xmm13, [rsp+0xC0]
000076e4393df089  vmovaps xmm14, [rsp+0xD0]
000076e4393df092  vmovaps xmm15, [rsp+0xE0]
000076e4393df09b  add rsp, 0xF0
000076e4393df0a2  pop r11
000076e4393df0a4  pop r10
000076e4393df0a6  pop r9
000076e4393df0a8  pop r8
000076e4393df0aa  pop rsi
000076e4393df0ab  pop rdi
000076e4393df0ac  pop rdx
000076e4393df0ad  pop rcx
000076e4393df0ae  pop rax
000076e4393df0af  add rsp, 0x08
000076e4393df0b3  jmp 0x000076E4393DC354
000076e4393df0b8  sub rsp, 0x08
000076e4393df0bc  push rax
000076e4393df0bd  push rcx
000076e4393df0be  push rdx
000076e4393df0bf  push rdi
000076e4393df0c0  push rsi
000076e4393df0c1  push r8
000076e4393df0c3  push r9
000076e4393df0c5  push r10
000076e4393df0c7  push r11
000076e4393df0c9  sub rsp, 0xF0
000076e4393df0d0  vmovaps [rsp], xmm0
000076e4393df0d5  vmovaps [rsp+0x10], xmm2
000076e4393df0db  vmovaps [rsp+0x20], xmm3
000076e4393df0e1  vmovaps [rsp+0x30], xmm4
000076e4393df0e7  vmovaps [rsp+0x40], xmm5
000076e4393df0ed  vmovaps [rsp+0x50], xmm6
000076e4393df0f3  vmovaps [rsp+0x60], xmm7
000076e4393df0f9  vmovaps [rsp+0x70], xmm8
000076e4393df0ff  vmovaps [rsp+0x80], xmm9
000076e4393df108  vmovaps [rsp+0x90], xmm10
000076e4393df111  vmovaps [rsp+0xA0], xmm11
000076e4393df11a  vmovaps [rsp+0xB0], xmm12
000076e4393df123  vmovaps [rsp+0xC0], xmm13
000076e4393df12c  vmovaps [rsp+0xD0], xmm14
000076e4393df135  vmovaps [rsp+0xE0], xmm15
000076e4393df13e  sub rsp, 0x30
000076e4393df142  movaps [rsp], xmm1
000076e4393df146  movaps [rsp+0x10], xmm15
000076e4393df14c  movaps [rsp+0x20], xmm6
000076e4393df151  lea rdi, [rsp]
000076e4393df155  mov esi, 0x00
000076e4393df15a  mov rax, 0x63DBDEB43530
000076e4393df164  call rax
000076e4393df166  movaps xmm1, [rsp]
000076e4393df16a  add rsp, 0x30
000076e4393df16e  vmovaps xmm0, [rsp]
000076e4393df173  vmovaps xmm2, [rsp+0x10]
000076e4393df179  vmovaps xmm3, [rsp+0x20]
000076e4393df17f  vmovaps xmm4, [rsp+0x30]
000076e4393df185  vmovaps xmm5, [rsp+0x40]
000076e4393df18b  vmovaps xmm6, [rsp+0x50]
000076e4393df191  vmovaps xmm7, [rsp+0x60]
000076e4393df197  vmovaps xmm8, [rsp+0x70]
000076e4393df19d  vmovaps xmm9, [rsp+0x80]
000076e4393df1a6  vmovaps xmm10, [rsp+0x90]
000076e4393df1af  vmovaps xmm11, [rsp+0xA0]
000076e4393df1b8  vmovaps xmm12, [rsp+0xB0]
000076e4393df1c1  vmovaps xmm13, [rsp+0xC0]
000076e4393df1ca  vmovaps xmm14, [rsp+0xD0]
000076e4393df1d3  vmovaps xmm15, [rsp+0xE0]
000076e4393df1dc  add rsp, 0xF0
000076e4393df1e3  pop r11
000076e4393df1e5  pop r10
000076e4393df1e7  pop r9
000076e4393df1e9  pop r8
000076e4393df1eb  pop rsi
000076e4393df1ec  pop rdi
000076e4393df1ed  pop rdx
000076e4393df1ee  pop rcx
000076e4393df1ef  pop rax
000076e4393df1f0  add rsp, 0x08
000076e4393df1f4  jmp 0x000076E4393DC375
000076e4393df1f9  sub rsp, 0x08
000076e4393df1fd  push rax
000076e4393df1fe  push rcx
000076e4393df1ff  push rdx
000076e4393df200  push rdi
000076e4393df201  push rsi
000076e4393df202  push r8
000076e4393df204  push r9
000076e4393df206  push r10
000076e4393df208  push r11
000076e4393df20a  sub rsp, 0xF0
000076e4393df211  vmovaps [rsp], xmm0
000076e4393df216  vmovaps [rsp+0x10], xmm1
000076e4393df21c  vmovaps [rsp+0x20], xmm2
000076e4393df222  vmovaps [rsp+0x30], xmm3
000076e4393df228  vmovaps [rsp+0x40], xmm4
000076e4393df22e  vmovaps [rsp+0x50], xmm5
000076e4393df234  vmovaps [rsp+0x60], xmm6
000076e4393df23a  vmovaps [rsp+0x70], xmm7
000076e4393df240  vmovaps [rsp+0x80], xmm8
000076e4393df249  vmovaps [rsp+0x90], xmm9
000076e4393df252  vmovaps [rsp+0xA0], xmm10
000076e4393df25b  vmovaps [rsp+0xB0], xmm11
000076e4393df264  vmovaps [rsp+0xC0], xmm12
000076e4393df26d  vmovaps [rsp+0xD0], xmm13
000076e4393df276  vmovaps [rsp+0xE0], xmm14
000076e4393df27f  sub rsp, 0x30
000076e4393df283  movaps [rsp], xmm15
000076e4393df288  movaps [rsp+0x10], xmm5
000076e4393df28d  movaps [rsp+0x20], xmm3
000076e4393df292  lea rdi, [rsp]
000076e4393df296  mov esi, 0x00
000076e4393df29b  mov rax, 0x63DBDEB43530
000076e4393df2a5  call rax
000076e4393df2a7  movaps xmm15, [rsp]
000076e4393df2ac  add rsp, 0x30
000076e4393df2b0  vmovaps xmm0, [rsp]
000076e4393df2b5  vmovaps xmm1, [rsp+0x10]
000076e4393df2bb  vmovaps xmm2, [rsp+0x20]
000076e4393df2c1  vmovaps xmm3, [rsp+0x30]
000076e4393df2c7  vmovaps xmm4, [rsp+0x40]
000076e4393df2cd  vmovaps xmm5, [rsp+0x50]
000076e4393df2d3  vmovaps xmm6, [rsp+0x60]
000076e4393df2d9  vmovaps xmm7, [rsp+0x70]
000076e4393df2df  vmovaps xmm8, [rsp+0x80]
000076e4393df2e8  vmovaps xmm9, [rsp+0x90]
000076e4393df2f1  vmovaps xmm10, [rsp+0xA0]
000076e4393df2fa  vmovaps xmm11, [rsp+0xB0]
000076e4393df303  vmovaps xmm12, [rsp+0xC0]
000076e4393df30c  vmovaps xmm13, [rsp+0xD0]
000076e4393df315  vmovaps xmm14, [rsp+0xE0]
000076e4393df31e  add rsp, 0xF0
000076e4393df325  pop r11
000076e4393df327  pop r10
000076e4393df329  pop r9
000076e4393df32b  pop r8
000076e4393df32d  pop rsi
000076e4393df32e  pop rdi
000076e4393df32f  pop rdx
000076e4393df330  pop rcx
000076e4393df331  pop rax
000076e4393df332  add rsp, 0x08
000076e4393df336  jmp 0x000076E4393DC38F
000076e4393df33b  sub rsp, 0x08
000076e4393df33f  push rax
000076e4393df340  push rcx
000076e4393df341  push rdx
000076e4393df342  push rdi
000076e4393df343  push rsi
000076e4393df344  push r8
000076e4393df346  push r9
000076e4393df348  push r10
000076e4393df34a  push r11
000076e4393df34c  sub rsp, 0xF0
000076e4393df353  vmovaps [rsp], xmm0
000076e4393df358  vmovaps [rsp+0x10], xmm1
000076e4393df35e  vmovaps [rsp+0x20], xmm2
000076e4393df364  vmovaps [rsp+0x30], xmm3
000076e4393df36a  vmovaps [rsp+0x40], xmm4
000076e4393df370  vmovaps [rsp+0x50], xmm6
000076e4393df376  vmovaps [rsp+0x60], xmm7
000076e4393df37c  vmovaps [rsp+0x70], xmm8
000076e4393df382  vmovaps [rsp+0x80], xmm9
000076e4393df38b  vmovaps [rsp+0x90], xmm10
000076e4393df394  vmovaps [rsp+0xA0], xmm11
000076e4393df39d  vmovaps [rsp+0xB0], xmm12
000076e4393df3a6  vmovaps [rsp+0xC0], xmm13
000076e4393df3af  vmovaps [rsp+0xD0], xmm14
000076e4393df3b8  vmovaps [rsp+0xE0], xmm15
000076e4393df3c1  sub rsp, 0x30
000076e4393df3c5  movaps [rsp], xmm5
000076e4393df3c9  movaps [rsp+0x10], xmm8
000076e4393df3cf  movaps [rsp+0x20], xmm6
000076e4393df3d4  lea rdi, [rsp]
000076e4393df3d8  mov esi, 0x00
000076e4393df3dd  mov rax, 0x63DBDEB43530
000076e4393df3e7  call rax
000076e4393df3e9  movaps xmm5, [rsp]
000076e4393df3ed  add rsp, 0x30
000076e4393df3f1  vmovaps xmm0, [rsp]
000076e4393df3f6  vmovaps xmm1, [rsp+0x10]
000076e4393df3fc  vmovaps xmm2, [rsp+0x20]
000076e4393df402  vmovaps xmm3, [rsp+0x30]
000076e4393df408  vmovaps xmm4, [rsp+0x40]
000076e4393df40e  vmovaps xmm6, [rsp+0x50]
000076e4393df414  vmovaps xmm7, [rsp+0x60]
000076e4393df41a  vmovaps xmm8, [rsp+0x70]
000076e4393df420  vmovaps xmm9, [rsp+0x80]
000076e4393df429  vmovaps xmm10, [rsp+0x90]
000076e4393df432  vmovaps xmm11, [rsp+0xA0]
000076e4393df43b  vmovaps xmm12, [rsp+0xB0]
000076e4393df444  vmovaps xmm13, [rsp+0xC0]
000076e4393df44d  vmovaps xmm14, [rsp+0xD0]
000076e4393df456  vmovaps xmm15, [rsp+0xE0]
000076e4393df45f  add rsp, 0xF0
000076e4393df466  pop r11
000076e4393df468  pop r10
000076e4393df46a  pop r9
000076e4393df46c  pop r8
000076e4393df46e  pop rsi
000076e4393df46f  pop rdi
000076e4393df470  pop rdx
000076e4393df471  pop rcx
000076e4393df472  pop rax
000076e4393df473  add rsp, 0x08
000076e4393df477  jmp 0x000076E4393DC3B3
000076e4393df47c  sub rsp, 0x08
000076e4393df480  push rax
000076e4393df481  push rcx
000076e4393df482  push rdx
000076e4393df483  push rdi
000076e4393df484  push rsi
000076e4393df485  push r8
000076e4393df487  push r9
000076e4393df489  push r10
000076e4393df48b  push r11
000076e4393df48d  sub rsp, 0xF0
000076e4393df494  vmovaps [rsp], xmm0
000076e4393df499  vmovaps [rsp+0x10], xmm1
000076e4393df49f  vmovaps [rsp+0x20], xmm2
000076e4393df4a5  vmovaps [rsp+0x30], xmm3
000076e4393df4ab  vmovaps [rsp+0x40], xmm4
000076e4393df4b1  vmovaps [rsp+0x50], xmm5
000076e4393df4b7  vmovaps [rsp+0x60], xmm7
000076e4393df4bd  vmovaps [rsp+0x70], xmm8
000076e4393df4c3  vmovaps [rsp+0x80], xmm9
000076e4393df4cc  vmovaps [rsp+0x90], xmm10
000076e4393df4d5  vmovaps [rsp+0xA0], xmm11
000076e4393df4de  vmovaps [rsp+0xB0], xmm12
000076e4393df4e7  vmovaps [rsp+0xC0], xmm13
000076e4393df4f0  vmovaps [rsp+0xD0], xmm14
000076e4393df4f9  vmovaps [rsp+0xE0], xmm15
000076e4393df502  sub rsp, 0x30
000076e4393df506  movaps [rsp], xmm6
000076e4393df50a  movaps [rsp+0x10], xmm10
000076e4393df510  movaps [rsp+0x20], xmm8
000076e4393df516  lea rdi, [rsp]
000076e4393df51a  mov esi, 0x00
000076e4393df51f  mov rax, 0x63DBDEB43530
000076e4393df529  call rax
000076e4393df52b  movaps xmm6, [rsp]
000076e4393df52f  add rsp, 0x30
000076e4393df533  vmovaps xmm0, [rsp]
000076e4393df538  vmovaps xmm1, [rsp+0x10]
000076e4393df53e  vmovaps xmm2, [rsp+0x20]
000076e4393df544  vmovaps xmm3, [rsp+0x30]
000076e4393df54a  vmovaps xmm4, [rsp+0x40]
000076e4393df550  vmovaps xmm5, [rsp+0x50]
000076e4393df556  vmovaps xmm7, [rsp+0x60]
000076e4393df55c  vmovaps xmm8, [rsp+0x70]
000076e4393df562  vmovaps xmm9, [rsp+0x80]
000076e4393df56b  vmovaps xmm10, [rsp+0x90]
000076e4393df574  vmovaps xmm11, [rsp+0xA0]
000076e4393df57d  vmovaps xmm12, [rsp+0xB0]
000076e4393df586  vmovaps xmm13, [rsp+0xC0]
000076e4393df58f  vmovaps xmm14, [rsp+0xD0]
000076e4393df598  vmovaps xmm15, [rsp+0xE0]
000076e4393df5a1  add rsp, 0xF0
000076e4393df5a8  pop r11
000076e4393df5aa  pop r10
000076e4393df5ac  pop r9
000076e4393df5ae  pop r8
000076e4393df5b0  pop rsi
000076e4393df5b1  pop rdi
000076e4393df5b2  pop rdx
000076e4393df5b3  pop rcx
000076e4393df5b4  pop rax
000076e4393df5b5  add rsp, 0x08
000076e4393df5b9  jmp 0x000076E4393DC3D8
000076e4393df5be  sub rsp, 0x08
000076e4393df5c2  push rax
000076e4393df5c3  push rcx
000076e4393df5c4  push rdx
000076e4393df5c5  push rdi
000076e4393df5c6  push rsi
000076e4393df5c7  push r8
000076e4393df5c9  push r9
000076e4393df5cb  push r10
000076e4393df5cd  push r11
000076e4393df5cf  sub rsp, 0xF0
000076e4393df5d6  vmovaps [rsp], xmm0
000076e4393df5db  vmovaps [rsp+0x10], xmm1
000076e4393df5e1  vmovaps [rsp+0x20], xmm2
000076e4393df5e7  vmovaps [rsp+0x30], xmm3
000076e4393df5ed  vmovaps [rsp+0x40], xmm4
000076e4393df5f3  vmovaps [rsp+0x50], xmm5
000076e4393df5f9  vmovaps [rsp+0x60], xmm6
000076e4393df5ff  vmovaps [rsp+0x70], xmm7
000076e4393df605  vmovaps [rsp+0x80], xmm8
000076e4393df60e  vmovaps [rsp+0x90], xmm9
000076e4393df617  vmovaps [rsp+0xA0], xmm11
000076e4393df620  vmovaps [rsp+0xB0], xmm12
000076e4393df629  vmovaps [rsp+0xC0], xmm13
000076e4393df632  vmovaps [rsp+0xD0], xmm14
000076e4393df63b  vmovaps [rsp+0xE0], xmm15
000076e4393df644  sub rsp, 0x30
000076e4393df648  movaps [rsp], xmm10
000076e4393df64d  movaps [rsp+0x10], xmm8
000076e4393df653  movaps [rsp+0x20], xmm14
000076e4393df659  lea rdi, [rsp]
000076e4393df65d  mov esi, 0x00
000076e4393df662  mov rax, 0x63DBDEB43530
000076e4393df66c  call rax
000076e4393df66e  movaps xmm10, [rsp]
000076e4393df673  add rsp, 0x30
000076e4393df677  vmovaps xmm0, [rsp]
000076e4393df67c  vmovaps xmm1, [rsp+0x10]
000076e4393df682  vmovaps xmm2, [rsp+0x20]
000076e4393df688  vmovaps xmm3, [rsp+0x30]
000076e4393df68e  vmovaps xmm4, [rsp+0x40]
000076e4393df694  vmovaps xmm5, [rsp+0x50]
000076e4393df69a  vmovaps xmm6, [rsp+0x60]
000076e4393df6a0  vmovaps xmm7, [rsp+0x70]
000076e4393df6a6  vmovaps xmm8, [rsp+0x80]
000076e4393df6af  vmovaps xmm9, [rsp+0x90]
000076e4393df6b8  vmovaps xmm11, [rsp+0xA0]
000076e4393df6c1  vmovaps xmm12, [rsp+0xB0]
000076e4393df6ca  vmovaps xmm13, [rsp+0xC0]
000076e4393df6d3  vmovaps xmm14, [rsp+0xD0]
000076e4393df6dc  vmovaps xmm15, [rsp+0xE0]
000076e4393df6e5  add rsp, 0xF0
000076e4393df6ec  pop r11
000076e4393df6ee  pop r10
000076e4393df6f0  pop r9
000076e4393df6f2  pop r8
000076e4393df6f4  pop rsi
000076e4393df6f5  pop rdi
000076e4393df6f6  pop rdx
000076e4393df6f7  pop rcx
000076e4393df6f8  pop rax
000076e4393df6f9  add rsp, 0x08
000076e4393df6fd  jmp 0x000076E4393DC3F8
000076e4393df702  sub rsp, 0x08
000076e4393df706  push rax
000076e4393df707  push rcx
000076e4393df708  push rdx
000076e4393df709  push rdi
000076e4393df70a  push rsi
000076e4393df70b  push r8
000076e4393df70d  push r9
000076e4393df70f  push r10
000076e4393df711  push r11
000076e4393df713  sub rsp, 0xF0
000076e4393df71a  vmovaps [rsp], xmm0
000076e4393df71f  vmovaps [rsp+0x10], xmm1
000076e4393df725  vmovaps [rsp+0x20], xmm2
000076e4393df72b  vmovaps [rsp+0x30], xmm3
000076e4393df731  vmovaps [rsp+0x40], xmm4
000076e4393df737  vmovaps [rsp+0x50], xmm5
000076e4393df73d  vmovaps [rsp+0x60], xmm6
000076e4393df743  vmovaps [rsp+0x70], xmm7
000076e4393df749  vmovaps [rsp+0x80], xmm8
000076e4393df752  vmovaps [rsp+0x90], xmm9
000076e4393df75b  vmovaps [rsp+0xA0], xmm10
000076e4393df764  vmovaps [rsp+0xB0], xmm11
000076e4393df76d  vmovaps [rsp+0xC0], xmm12
000076e4393df776  vmovaps [rsp+0xD0], xmm13
000076e4393df77f  vmovaps [rsp+0xE0], xmm15
000076e4393df788  sub rsp, 0x30
000076e4393df78c  movaps [rsp], xmm14
000076e4393df791  movaps [rsp+0x10], xmm8
000076e4393df797  movaps [rsp+0x20], xmm4
000076e4393df79c  lea rdi, [rsp]
000076e4393df7a0  mov esi, 0x00
000076e4393df7a5  mov rax, 0x63DBDEB43530
000076e4393df7af  call rax
000076e4393df7b1  movaps xmm14, [rsp]
000076e4393df7b6  add rsp, 0x30
000076e4393df7ba  vmovaps xmm0, [rsp]
000076e4393df7bf  vmovaps xmm1, [rsp+0x10]
000076e4393df7c5  vmovaps xmm2, [rsp+0x20]
000076e4393df7cb  vmovaps xmm3, [rsp+0x30]
000076e4393df7d1  vmovaps xmm4, [rsp+0x40]
000076e4393df7d7  vmovaps xmm5, [rsp+0x50]
000076e4393df7dd  vmovaps xmm6, [rsp+0x60]
000076e4393df7e3  vmovaps xmm7, [rsp+0x70]
000076e4393df7e9  vmovaps xmm8, [rsp+0x80]
000076e4393df7f2  vmovaps xmm9, [rsp+0x90]
000076e4393df7fb  vmovaps xmm10, [rsp+0xA0]
000076e4393df804  vmovaps xmm11, [rsp+0xB0]
000076e4393df80d  vmovaps xmm12, [rsp+0xC0]
000076e4393df816  vmovaps xmm13, [rsp+0xD0]
000076e4393df81f  vmovaps xmm15, [rsp+0xE0]
000076e4393df828  add rsp, 0xF0
000076e4393df82f  pop r11
000076e4393df831  pop r10
000076e4393df833  pop r9
000076e4393df835  pop r8
000076e4393df837  pop rsi
000076e4393df838  pop rdi
000076e4393df839  pop rdx
000076e4393df83a  pop rcx
000076e4393df83b  pop rax
000076e4393df83c  add rsp, 0x08
000076e4393df840  jmp 0x000076E4393DC418
000076e4393df845  sub rsp, 0x08
000076e4393df849  push rax
000076e4393df84a  push rcx
000076e4393df84b  push rdx
000076e4393df84c  push rdi
000076e4393df84d  push rsi
000076e4393df84e  push r8
000076e4393df850  push r9
000076e4393df852  push r10
000076e4393df854  push r11
000076e4393df856  sub rsp, 0xF0
000076e4393df85d  vmovaps [rsp], xmm0
000076e4393df862  vmovaps [rsp+0x10], xmm1
000076e4393df868  vmovaps [rsp+0x20], xmm2
000076e4393df86e  vmovaps [rsp+0x30], xmm3
000076e4393df874  vmovaps [rsp+0x40], xmm5
000076e4393df87a  vmovaps [rsp+0x50], xmm6
000076e4393df880  vmovaps [rsp+0x60], xmm7
000076e4393df886  vmovaps [rsp+0x70], xmm8
000076e4393df88c  vmovaps [rsp+0x80], xmm9
000076e4393df895  vmovaps [rsp+0x90], xmm10
000076e4393df89e  vmovaps [rsp+0xA0], xmm11
000076e4393df8a7  vmovaps [rsp+0xB0], xmm12
000076e4393df8b0  vmovaps [rsp+0xC0], xmm13
000076e4393df8b9  vmovaps [rsp+0xD0], xmm14
000076e4393df8c2  vmovaps [rsp+0xE0], xmm15
000076e4393df8cb  sub rsp, 0x30
000076e4393df8cf  movaps [rsp], xmm4
000076e4393df8d3  movaps [rsp+0x10], xmm13
000076e4393df8d9  movaps [rsp+0x20], xmm8
000076e4393df8df  lea rdi, [rsp]
000076e4393df8e3  mov esi, 0x00
000076e4393df8e8  mov rax, 0x63DBDEB43530
000076e4393df8f2  call rax
000076e4393df8f4  movaps xmm4, [rsp]
000076e4393df8f8  add rsp, 0x30
000076e4393df8fc  vmovaps xmm0, [rsp]
000076e4393df901  vmovaps xmm1, [rsp+0x10]
000076e4393df907  vmovaps xmm2, [rsp+0x20]
000076e4393df90d  vmovaps xmm3, [rsp+0x30]
000076e4393df913  vmovaps xmm5, [rsp+0x40]
000076e4393df919  vmovaps xmm6, [rsp+0x50]
000076e4393df91f  vmovaps xmm7, [rsp+0x60]
000076e4393df925  vmovaps xmm8, [rsp+0x70]
000076e4393df92b  vmovaps xmm9, [rsp+0x80]
000076e4393df934  vmovaps xmm10, [rsp+0x90]
000076e4393df93d  vmovaps xmm11, [rsp+0xA0]
000076e4393df946  vmovaps xmm12, [rsp+0xB0]
000076e4393df94f  vmovaps xmm13, [rsp+0xC0]
000076e4393df958  vmovaps xmm14, [rsp+0xD0]
000076e4393df961  vmovaps xmm15, [rsp+0xE0]
000076e4393df96a  add rsp, 0xF0
000076e4393df971  pop r11
000076e4393df973  pop r10
000076e4393df975  pop r9
000076e4393df977  pop r8
000076e4393df979  pop rsi
000076e4393df97a  pop rdi
000076e4393df97b  pop rdx
000076e4393df97c  pop rcx
000076e4393df97d  pop rax
000076e4393df97e  add rsp, 0x08
000076e4393df982  jmp 0x000076E4393DC43D
000076e4393df987  sub rsp, 0x08
000076e4393df98b  push rax
000076e4393df98c  push rcx
000076e4393df98d  push rdx
000076e4393df98e  push rdi
000076e4393df98f  push rsi
000076e4393df990  push r8
000076e4393df992  push r9
000076e4393df994  push r10
000076e4393df996  push r11
000076e4393df998  sub rsp, 0xF0
000076e4393df99f  vmovaps [rsp], xmm0
000076e4393df9a4  vmovaps [rsp+0x10], xmm1
000076e4393df9aa  vmovaps [rsp+0x20], xmm2
000076e4393df9b0  vmovaps [rsp+0x30], xmm3
000076e4393df9b6  vmovaps [rsp+0x40], xmm4
000076e4393df9bc  vmovaps [rsp+0x50], xmm5
000076e4393df9c2  vmovaps [rsp+0x60], xmm6
000076e4393df9c8  vmovaps [rsp+0x70], xmm7
000076e4393df9ce  vmovaps [rsp+0x80], xmm8
000076e4393df9d7  vmovaps [rsp+0x90], xmm9
000076e4393df9e0  vmovaps [rsp+0xA0], xmm10
000076e4393df9e9  vmovaps [rsp+0xB0], xmm11
000076e4393df9f2  vmovaps [rsp+0xC0], xmm12
000076e4393df9fb  vmovaps [rsp+0xD0], xmm14
000076e4393dfa04  vmovaps [rsp+0xE0], xmm15
000076e4393dfa0d  sub rsp, 0x30
000076e4393dfa11  movaps [rsp], xmm13
000076e4393dfa16  movaps [rsp+0x10], xmm15
000076e4393dfa1c  movaps [rsp+0x20], xmm9
000076e4393dfa22  lea rdi, [rsp]
000076e4393dfa26  mov esi, 0x00
000076e4393dfa2b  mov rax, 0x63DBDEB43530
000076e4393dfa35  call rax
000076e4393dfa37  movaps xmm13, [rsp]
000076e4393dfa3c  add rsp, 0x30
000076e4393dfa40  vmovaps xmm0, [rsp]
000076e4393dfa45  vmovaps xmm1, [rsp+0x10]
000076e4393dfa4b  vmovaps xmm2, [rsp+0x20]
000076e4393dfa51  vmovaps xmm3, [rsp+0x30]
000076e4393dfa57  vmovaps xmm4, [rsp+0x40]
000076e4393dfa5d  vmovaps xmm5, [rsp+0x50]
000076e4393dfa63  vmovaps xmm6, [rsp+0x60]
000076e4393dfa69  vmovaps xmm7, [rsp+0x70]
000076e4393dfa6f  vmovaps xmm8, [rsp+0x80]
000076e4393dfa78  vmovaps xmm9, [rsp+0x90]
000076e4393dfa81  vmovaps xmm10, [rsp+0xA0]
000076e4393dfa8a  vmovaps xmm11, [rsp+0xB0]
000076e4393dfa93  vmovaps xmm12, [rsp+0xC0]
000076e4393dfa9c  vmovaps xmm14, [rsp+0xD0]
000076e4393dfaa5  vmovaps xmm15, [rsp+0xE0]
000076e4393dfaae  add rsp, 0xF0
000076e4393dfab5  pop r11
000076e4393dfab7  pop r10
000076e4393dfab9  pop r9
000076e4393dfabb  pop r8
000076e4393dfabd  pop rsi
000076e4393dfabe  pop rdi
000076e4393dfabf  pop rdx
000076e4393dfac0  pop rcx
000076e4393dfac1  pop rax
000076e4393dfac2  add rsp, 0x08
000076e4393dfac6  jmp 0x000076E4393DC458
000076e4393dfacb  sub rsp, 0x08
000076e4393dfacf  push rax
000076e4393dfad0  push rcx
000076e4393dfad1  push rdx
000076e4393dfad2  push rdi
000076e4393dfad3  push rsi
000076e4393dfad4  push r8
000076e4393dfad6  push r9
000076e4393dfad8  push r10
000076e4393dfada  push r11
000076e4393dfadc  sub rsp, 0xF0
000076e4393dfae3  vmovaps [rsp], xmm0
000076e4393dfae8  vmovaps [rsp+0x10], xmm1
000076e4393dfaee  vmovaps [rsp+0x20], xmm2
000076e4393dfaf4  vmovaps [rsp+0x30], xmm3
000076e4393dfafa  vmovaps [rsp+0x40], xmm4
000076e4393dfb00  vmovaps [rsp+0x50], xmm5
000076e4393dfb06  vmovaps [rsp+0x60], xmm6
000076e4393dfb0c  vmovaps [rsp+0x70], xmm7
000076e4393dfb12  vmovaps [rsp+0x80], xmm8
000076e4393dfb1b  vmovaps [rsp+0x90], xmm9
000076e4393dfb24  vmovaps [rsp+0xA0], xmm10
000076e4393dfb2d  vmovaps [rsp+0xB0], xmm11
000076e4393dfb36  vmovaps [rsp+0xC0], xmm12
000076e4393dfb3f  vmovaps [rsp+0xD0], xmm13
000076e4393dfb48  vmovaps [rsp+0xE0], xmm14
000076e4393dfb51  sub rsp, 0x30
000076e4393dfb55  movaps [rsp], xmm15
000076e4393dfb5a  movaps [rsp+0x10], xmm1
000076e4393dfb5f  movaps [rsp+0x20], xmm5
000076e4393dfb64  lea rdi, [rsp]
000076e4393dfb68  mov esi, 0x00
000076e4393dfb6d  mov rax, 0x63DBDEB43530
000076e4393dfb77  call rax
000076e4393dfb79  movaps xmm15, [rsp]
000076e4393dfb7e  add rsp, 0x30
000076e4393dfb82  vmovaps xmm0, [rsp]
000076e4393dfb87  vmovaps xmm1, [rsp+0x10]
000076e4393dfb8d  vmovaps xmm2, [rsp+0x20]
000076e4393dfb93  vmovaps xmm3, [rsp+0x30]
000076e4393dfb99  vmovaps xmm4, [rsp+0x40]
000076e4393dfb9f  vmovaps xmm5, [rsp+0x50]
000076e4393dfba5  vmovaps xmm6, [rsp+0x60]
000076e4393dfbab  vmovaps xmm7, [rsp+0x70]
000076e4393dfbb1  vmovaps xmm8, [rsp+0x80]
000076e4393dfbba  vmovaps xmm9, [rsp+0x90]
000076e4393dfbc3  vmovaps xmm10, [rsp+0xA0]
000076e4393dfbcc  vmovaps xmm11, [rsp+0xB0]
000076e4393dfbd5  vmovaps xmm12, [rsp+0xC0]
000076e4393dfbde  vmovaps xmm13, [rsp+0xD0]
000076e4393dfbe7  vmovaps xmm14, [rsp+0xE0]
000076e4393dfbf0  add rsp, 0xF0
000076e4393dfbf7  pop r11
000076e4393dfbf9  pop r10
000076e4393dfbfb  pop r9
000076e4393dfbfd  pop r8
000076e4393dfbff  pop rsi
000076e4393dfc00  pop rdi
000076e4393dfc01  pop rdx
000076e4393dfc02  pop rcx
000076e4393dfc03  pop rax
000076e4393dfc04  add rsp, 0x08
000076e4393dfc08  jmp 0x000076E4393DC473
000076e4393dfc0d  call 0x000076E4392B52F0
000076e4393dfc12  jmp 0x000076E4393DC4CE
000076e4393dfc17  sub rsp, 0x08
000076e4393dfc1b  push rax
000076e4393dfc1c  push rcx
000076e4393dfc1d  push rdx
000076e4393dfc1e  push rdi
000076e4393dfc1f  push rsi
000076e4393dfc20  push r8
000076e4393dfc22  push r9
000076e4393dfc24  push r10
000076e4393dfc26  push r11
000076e4393dfc28  sub rsp, 0xF0
000076e4393dfc2f  vmovaps [rsp], xmm0
000076e4393dfc34  vmovaps [rsp+0x10], xmm1
000076e4393dfc3a  vmovaps [rsp+0x20], xmm2
000076e4393dfc40  vmovaps [rsp+0x30], xmm3
000076e4393dfc46  vmovaps [rsp+0x40], xmm4
000076e4393dfc4c  vmovaps [rsp+0x50], xmm5
000076e4393dfc52  vmovaps [rsp+0x60], xmm6
000076e4393dfc58  vmovaps [rsp+0x70], xmm7
000076e4393dfc5e  vmovaps [rsp+0x80], xmm8
000076e4393dfc67  vmovaps [rsp+0x90], xmm10
000076e4393dfc70  vmovaps [rsp+0xA0], xmm11
000076e4393dfc79  vmovaps [rsp+0xB0], xmm12
000076e4393dfc82  vmovaps [rsp+0xC0], xmm13
000076e4393dfc8b  vmovaps [rsp+0xD0], xmm14
000076e4393dfc94  vmovaps [rsp+0xE0], xmm15
000076e4393dfc9d  sub rsp, 0x30
000076e4393dfca1  movaps [rsp], xmm9
000076e4393dfca6  movaps [rsp+0x10], xmm8
000076e4393dfcac  movaps [rsp+0x20], xmm11
000076e4393dfcb2  lea rdi, [rsp]
000076e4393dfcb6  mov esi, 0x00
000076e4393dfcbb  mov rax, 0x63DBDEB43530
000076e4393dfcc5  call rax
000076e4393dfcc7  movaps xmm9, [rsp]
000076e4393dfccc  add rsp, 0x30
000076e4393dfcd0  vmovaps xmm0, [rsp]
000076e4393dfcd5  vmovaps xmm1, [rsp+0x10]
000076e4393dfcdb  vmovaps xmm2, [rsp+0x20]
000076e4393dfce1  vmovaps xmm3, [rsp+0x30]
000076e4393dfce7  vmovaps xmm4, [rsp+0x40]
000076e4393dfced  vmovaps xmm5, [rsp+0x50]
000076e4393dfcf3  vmovaps xmm6, [rsp+0x60]
000076e4393dfcf9  vmovaps xmm7, [rsp+0x70]
000076e4393dfcff  vmovaps xmm8, [rsp+0x80]
000076e4393dfd08  vmovaps xmm10, [rsp+0x90]
000076e4393dfd11  vmovaps xmm11, [rsp+0xA0]
000076e4393dfd1a  vmovaps xmm12, [rsp+0xB0]
000076e4393dfd23  vmovaps xmm13, [rsp+0xC0]
000076e4393dfd2c  vmovaps xmm14, [rsp+0xD0]
000076e4393dfd35  vmovaps xmm15, [rsp+0xE0]
000076e4393dfd3e  add rsp, 0xF0
000076e4393dfd45  pop r11
000076e4393dfd47  pop r10
000076e4393dfd49  pop r9
000076e4393dfd4b  pop r8
000076e4393dfd4d  pop rsi
000076e4393dfd4e  pop rdi
000076e4393dfd4f  pop rdx
000076e4393dfd50  pop rcx
000076e4393dfd51  pop rax
000076e4393dfd52  add rsp, 0x08
000076e4393dfd56  jmp 0x000076E4393DC505
000076e4393dfd5b  sub rsp, 0x08
000076e4393dfd5f  push rax
000076e4393dfd60  push rcx
000076e4393dfd61  push rdx
000076e4393dfd62  push rdi
000076e4393dfd63  push rsi
000076e4393dfd64  push r8
000076e4393dfd66  push r9
000076e4393dfd68  push r10
000076e4393dfd6a  push r11
000076e4393dfd6c  sub rsp, 0xF0
000076e4393dfd73  vmovaps [rsp], xmm0
000076e4393dfd78  vmovaps [rsp+0x10], xmm1
000076e4393dfd7e  vmovaps [rsp+0x20], xmm2
000076e4393dfd84  vmovaps [rsp+0x30], xmm3
000076e4393dfd8a  vmovaps [rsp+0x40], xmm4
000076e4393dfd90  vmovaps [rsp+0x50], xmm5
000076e4393dfd96  vmovaps [rsp+0x60], xmm6
000076e4393dfd9c  vmovaps [rsp+0x70], xmm7
000076e4393dfda2  vmovaps [rsp+0x80], xmm8
000076e4393dfdab  vmovaps [rsp+0x90], xmm9
000076e4393dfdb4  vmovaps [rsp+0xA0], xmm10
000076e4393dfdbd  vmovaps [rsp+0xB0], xmm12
000076e4393dfdc6  vmovaps [rsp+0xC0], xmm13
000076e4393dfdcf  vmovaps [rsp+0xD0], xmm14
000076e4393dfdd8  vmovaps [rsp+0xE0], xmm15
000076e4393dfde1  sub rsp, 0x30
000076e4393dfde5  movaps [rsp], xmm11
000076e4393dfdea  movaps [rsp+0x10], xmm10
000076e4393dfdf0  movaps [rsp+0x20], xmm6
000076e4393dfdf5  lea rdi, [rsp]
000076e4393dfdf9  mov esi, 0x00
000076e4393dfdfe  mov rax, 0x63DBDEB43530
000076e4393dfe08  call rax
000076e4393dfe0a  movaps xmm11, [rsp]
000076e4393dfe0f  add rsp, 0x30
000076e4393dfe13  vmovaps xmm0, [rsp]
000076e4393dfe18  vmovaps xmm1, [rsp+0x10]
000076e4393dfe1e  vmovaps xmm2, [rsp+0x20]
000076e4393dfe24  vmovaps xmm3, [rsp+0x30]
000076e4393dfe2a  vmovaps xmm4, [rsp+0x40]
000076e4393dfe30  vmovaps xmm5, [rsp+0x50]
000076e4393dfe36  vmovaps xmm6, [rsp+0x60]
000076e4393dfe3c  vmovaps xmm7, [rsp+0x70]
000076e4393dfe42  vmovaps xmm8, [rsp+0x80]
000076e4393dfe4b  vmovaps xmm9, [rsp+0x90]
000076e4393dfe54  vmovaps xmm10, [rsp+0xA0]
000076e4393dfe5d  vmovaps xmm12, [rsp+0xB0]
000076e4393dfe66  vmovaps xmm13, [rsp+0xC0]
000076e4393dfe6f  vmovaps xmm14, [rsp+0xD0]
000076e4393dfe78  vmovaps xmm15, [rsp+0xE0]
000076e4393dfe81  add rsp, 0xF0
000076e4393dfe88  pop r11
000076e4393dfe8a  pop r10
000076e4393dfe8c  pop r9
000076e4393dfe8e  pop r8
000076e4393dfe90  pop rsi
000076e4393dfe91  pop rdi
000076e4393dfe92  pop rdx
000076e4393dfe93  pop rcx
000076e4393dfe94  pop rax
000076e4393dfe95  add rsp, 0x08
000076e4393dfe99  jmp 0x000076E4393DC520
000076e4393dfe9e  sub rsp, 0x08
000076e4393dfea2  push rax
000076e4393dfea3  push rcx
000076e4393dfea4  push rdx
000076e4393dfea5  push rdi
000076e4393dfea6  push rsi
000076e4393dfea7  push r8
000076e4393dfea9  push r9
000076e4393dfeab  push r10
000076e4393dfead  push r11
000076e4393dfeaf  sub rsp, 0xF0
000076e4393dfeb6  vmovaps [rsp], xmm0
000076e4393dfebb  vmovaps [rsp+0x10], xmm1
000076e4393dfec1  vmovaps [rsp+0x20], xmm2
000076e4393dfec7  vmovaps [rsp+0x30], xmm3
000076e4393dfecd  vmovaps [rsp+0x40], xmm4
000076e4393dfed3  vmovaps [rsp+0x50], xmm5
000076e4393dfed9  vmovaps [rsp+0x60], xmm6
000076e4393dfedf  vmovaps [rsp+0x70], xmm7
000076e4393dfee5  vmovaps [rsp+0x80], xmm8
000076e4393dfeee  vmovaps [rsp+0x90], xmm9
000076e4393dfef7  vmovaps [rsp+0xA0], xmm11
000076e4393dff00  vmovaps [rsp+0xB0], xmm12
000076e4393dff09  vmovaps [rsp+0xC0], xmm13
000076e4393dff12  vmovaps [rsp+0xD0], xmm14
000076e4393dff1b  vmovaps [rsp+0xE0], xmm15
000076e4393dff24  sub rsp, 0x30
000076e4393dff28  movaps [rsp], xmm10
000076e4393dff2d  movaps [rsp+0x10], xmm14
000076e4393dff33  movaps [rsp+0x20], xmm4
000076e4393dff38  lea rdi, [rsp]
000076e4393dff3c  mov esi, 0x00
000076e4393dff41  mov rax, 0x63DBDEB43530
000076e4393dff4b  call rax
000076e4393dff4d  movaps xmm10, [rsp]
000076e4393dff52  add rsp, 0x30
000076e4393dff56  vmovaps xmm0, [rsp]
000076e4393dff5b  vmovaps xmm1, [rsp+0x10]
000076e4393dff61  vmovaps xmm2, [rsp+0x20]
000076e4393dff67  vmovaps xmm3, [rsp+0x30]
000076e4393dff6d  vmovaps xmm4, [rsp+0x40]
000076e4393dff73  vmovaps xmm5, [rsp+0x50]
000076e4393dff79  vmovaps xmm6, [rsp+0x60]
000076e4393dff7f  vmovaps xmm7, [rsp+0x70]
000076e4393dff85  vmovaps xmm8, [rsp+0x80]
000076e4393dff8e  vmovaps xmm9, [rsp+0x90]
000076e4393dff97  vmovaps xmm11, [rsp+0xA0]
000076e4393dffa0  vmovaps xmm12, [rsp+0xB0]
000076e4393dffa9  vmovaps xmm13, [rsp+0xC0]
000076e4393dffb2  vmovaps xmm14, [rsp+0xD0]
000076e4393dffbb  vmovaps xmm15, [rsp+0xE0]
000076e4393dffc4  add rsp, 0xF0
000076e4393dffcb  pop r11
000076e4393dffcd  pop r10
000076e4393dffcf  pop r9
000076e4393dffd1  pop r8
000076e4393dffd3  pop rsi
000076e4393dffd4  pop rdi
000076e4393dffd5  pop rdx
000076e4393dffd6  pop rcx
000076e4393dffd7  pop rax
000076e4393dffd8  add rsp, 0x08
000076e4393dffdc  jmp 0x000076E4393DC53B
000076e4393dffe1  sub rsp, 0x08
000076e4393dffe5  push rax
000076e4393dffe6  push rcx
000076e4393dffe7  push rdx
000076e4393dffe8  push rdi
000076e4393dffe9  push rsi
000076e4393dffea  push r8
000076e4393dffec  push r9
000076e4393dffee  push r10
000076e4393dfff0  push r11
000076e4393dfff2  sub rsp, 0xF0
000076e4393dfff9  vmovaps [rsp], xmm0
000076e4393dfffe  vmovaps [rsp+0x10], xmm1
000076e4393e0004  vmovaps [rsp+0x20], xmm2
000076e4393e000a  vmovaps [rsp+0x30], xmm3
000076e4393e0010  vmovaps [rsp+0x40], xmm4
000076e4393e0016  vmovaps [rsp+0x50], xmm5
000076e4393e001c  vmovaps [rsp+0x60], xmm6
000076e4393e0022  vmovaps [rsp+0x70], xmm7
000076e4393e0028  vmovaps [rsp+0x80], xmm9
000076e4393e0031  vmovaps [rsp+0x90], xmm10
000076e4393e003a  vmovaps [rsp+0xA0], xmm11
000076e4393e0043  vmovaps [rsp+0xB0], xmm12
000076e4393e004c  vmovaps [rsp+0xC0], xmm13
000076e4393e0055  vmovaps [rsp+0xD0], xmm14
000076e4393e005e  vmovaps [rsp+0xE0], xmm15
000076e4393e0067  sub rsp, 0x30
000076e4393e006b  movaps [rsp], xmm8
000076e4393e0070  movaps [rsp+0x10], xmm1
000076e4393e0075  movaps [rsp+0x20], xmm14
000076e4393e007b  lea rdi, [rsp]
000076e4393e007f  mov esi, 0x00
000076e4393e0084  mov rax, 0x63DBDEB43530
000076e4393e008e  call rax
000076e4393e0090  movaps xmm8, [rsp]
000076e4393e0095  add rsp, 0x30
000076e4393e0099  vmovaps xmm0, [rsp]
000076e4393e009e  vmovaps xmm1, [rsp+0x10]
000076e4393e00a4  vmovaps xmm2, [rsp+0x20]
000076e4393e00aa  vmovaps xmm3, [rsp+0x30]
000076e4393e00b0  vmovaps xmm4, [rsp+0x40]
000076e4393e00b6  vmovaps xmm5, [rsp+0x50]
000076e4393e00bc  vmovaps xmm6, [rsp+0x60]
000076e4393e00c2  vmovaps xmm7, [rsp+0x70]
000076e4393e00c8  vmovaps xmm9, [rsp+0x80]
000076e4393e00d1  vmovaps xmm10, [rsp+0x90]
000076e4393e00da  vmovaps xmm11, [rsp+0xA0]
000076e4393e00e3  vmovaps xmm12, [rsp+0xB0]
000076e4393e00ec  vmovaps xmm13, [rsp+0xC0]
000076e4393e00f5  vmovaps xmm14, [rsp+0xD0]
000076e4393e00fe  vmovaps xmm15, [rsp+0xE0]
000076e4393e0107  add rsp, 0xF0
000076e4393e010e  pop r11
000076e4393e0110  pop r10
000076e4393e0112  pop r9
000076e4393e0114  pop r8
000076e4393e0116  pop rsi
000076e4393e0117  pop rdi
000076e4393e0118  pop rdx
000076e4393e0119  pop rcx
000076e4393e011a  pop rax
000076e4393e011b  add rsp, 0x08
000076e4393e011f  jmp 0x000076E4393DC561
000076e4393e0124  sub rsp, 0x08
000076e4393e0128  push rax
000076e4393e0129  push rcx
000076e4393e012a  push rdx
000076e4393e012b  push rdi
000076e4393e012c  push rsi
000076e4393e012d  push r8
000076e4393e012f  push r9
000076e4393e0131  push r10
000076e4393e0133  push r11
000076e4393e0135  sub rsp, 0xF0
000076e4393e013c  vmovaps [rsp], xmm0
000076e4393e0141  vmovaps [rsp+0x10], xmm1
000076e4393e0147  vmovaps [rsp+0x20], xmm2
000076e4393e014d  vmovaps [rsp+0x30], xmm3
000076e4393e0153  vmovaps [rsp+0x40], xmm4
000076e4393e0159  vmovaps [rsp+0x50], xmm5
000076e4393e015f  vmovaps [rsp+0x60], xmm7
000076e4393e0165  vmovaps [rsp+0x70], xmm8
000076e4393e016b  vmovaps [rsp+0x80], xmm9
000076e4393e0174  vmovaps [rsp+0x90], xmm10
000076e4393e017d  vmovaps [rsp+0xA0], xmm11
000076e4393e0186  vmovaps [rsp+0xB0], xmm12
000076e4393e018f  vmovaps [rsp+0xC0], xmm13
000076e4393e0198  vmovaps [rsp+0xD0], xmm14
000076e4393e01a1  vmovaps [rsp+0xE0], xmm15
000076e4393e01aa  sub rsp, 0x30
000076e4393e01ae  movaps [rsp], xmm6
000076e4393e01b2  movaps [rsp+0x10], xmm1
000076e4393e01b7  movaps [rsp+0x20], xmm14
000076e4393e01bd  lea rdi, [rsp]
000076e4393e01c1  mov esi, 0x00
000076e4393e01c6  mov rax, 0x63DBDEB43530
000076e4393e01d0  call rax
000076e4393e01d2  movaps xmm6, [rsp]
000076e4393e01d6  add rsp, 0x30
000076e4393e01da  vmovaps xmm0, [rsp]
000076e4393e01df  vmovaps xmm1, [rsp+0x10]
000076e4393e01e5  vmovaps xmm2, [rsp+0x20]
000076e4393e01eb  vmovaps xmm3, [rsp+0x30]
000076e4393e01f1  vmovaps xmm4, [rsp+0x40]
000076e4393e01f7  vmovaps xmm5, [rsp+0x50]
000076e4393e01fd  vmovaps xmm7, [rsp+0x60]
000076e4393e0203  vmovaps xmm8, [rsp+0x70]
000076e4393e0209  vmovaps xmm9, [rsp+0x80]
000076e4393e0212  vmovaps xmm10, [rsp+0x90]
000076e4393e021b  vmovaps xmm11, [rsp+0xA0]
000076e4393e0224  vmovaps xmm12, [rsp+0xB0]
000076e4393e022d  vmovaps xmm13, [rsp+0xC0]
000076e4393e0236  vmovaps xmm14, [rsp+0xD0]
000076e4393e023f  vmovaps xmm15, [rsp+0xE0]
000076e4393e0248  add rsp, 0xF0
000076e4393e024f  pop r11
000076e4393e0251  pop r10
000076e4393e0253  pop r9
000076e4393e0255  pop r8
000076e4393e0257  pop rsi
000076e4393e0258  pop rdi
000076e4393e0259  pop rdx
000076e4393e025a  pop rcx
000076e4393e025b  pop rax
000076e4393e025c  add rsp, 0x08
000076e4393e0260  jmp 0x000076E4393DC58D
000076e4393e0265  sub rsp, 0x08
000076e4393e0269  push rax
000076e4393e026a  push rcx
000076e4393e026b  push rdx
000076e4393e026c  push rdi
000076e4393e026d  push rsi
000076e4393e026e  push r8
000076e4393e0270  push r9
000076e4393e0272  push r10
000076e4393e0274  push r11
000076e4393e0276  sub rsp, 0xF0
000076e4393e027d  vmovaps [rsp], xmm0
000076e4393e0282  vmovaps [rsp+0x10], xmm1
000076e4393e0288  vmovaps [rsp+0x20], xmm2
000076e4393e028e  vmovaps [rsp+0x30], xmm3
000076e4393e0294  vmovaps [rsp+0x40], xmm4
000076e4393e029a  vmovaps [rsp+0x50], xmm5
000076e4393e02a0  vmovaps [rsp+0x60], xmm6
000076e4393e02a6  vmovaps [rsp+0x70], xmm7
000076e4393e02ac  vmovaps [rsp+0x80], xmm8
000076e4393e02b5  vmovaps [rsp+0x90], xmm9
000076e4393e02be  vmovaps [rsp+0xA0], xmm10
000076e4393e02c7  vmovaps [rsp+0xB0], xmm11
000076e4393e02d0  vmovaps [rsp+0xC0], xmm12
000076e4393e02d9  vmovaps [rsp+0xD0], xmm13
000076e4393e02e2  vmovaps [rsp+0xE0], xmm15
000076e4393e02eb  sub rsp, 0x30
000076e4393e02ef  movaps [rsp], xmm14
000076e4393e02f4  movaps [rsp+0x10], xmm12
000076e4393e02fa  movaps [rsp+0x20], xmm1
000076e4393e02ff  lea rdi, [rsp]
000076e4393e0303  mov esi, 0x00
000076e4393e0308  mov rax, 0x63DBDEB43530
000076e4393e0312  call rax
000076e4393e0314  movaps xmm14, [rsp]
000076e4393e0319  add rsp, 0x30
000076e4393e031d  vmovaps xmm0, [rsp]
000076e4393e0322  vmovaps xmm1, [rsp+0x10]
000076e4393e0328  vmovaps xmm2, [rsp+0x20]
000076e4393e032e  vmovaps xmm3, [rsp+0x30]
000076e4393e0334  vmovaps xmm4, [rsp+0x40]
000076e4393e033a  vmovaps xmm5, [rsp+0x50]
000076e4393e0340  vmovaps xmm6, [rsp+0x60]
000076e4393e0346  vmovaps xmm7, [rsp+0x70]
000076e4393e034c  vmovaps xmm8, [rsp+0x80]
000076e4393e0355  vmovaps xmm9, [rsp+0x90]
000076e4393e035e  vmovaps xmm10, [rsp+0xA0]
000076e4393e0367  vmovaps xmm11, [rsp+0xB0]
000076e4393e0370  vmovaps xmm12, [rsp+0xC0]
000076e4393e0379  vmovaps xmm13, [rsp+0xD0]
000076e4393e0382  vmovaps xmm15, [rsp+0xE0]
000076e4393e038b  add rsp, 0xF0
000076e4393e0392  pop r11
000076e4393e0394  pop r10
000076e4393e0396  pop r9
000076e4393e0398  pop r8
000076e4393e039a  pop rsi
000076e4393e039b  pop rdi
000076e4393e039c  pop rdx
000076e4393e039d  pop rcx
000076e4393e039e  pop rax
000076e4393e039f  add rsp, 0x08
000076e4393e03a3  jmp 0x000076E4393DC5B3
000076e4393e03a8  sub rsp, 0x08
000076e4393e03ac  push rax
000076e4393e03ad  push rcx
000076e4393e03ae  push rdx
000076e4393e03af  push rdi
000076e4393e03b0  push rsi
000076e4393e03b1  push r8
000076e4393e03b3  push r9
000076e4393e03b5  push r10
000076e4393e03b7  push r11
000076e4393e03b9  sub rsp, 0xF0
000076e4393e03c0  vmovaps [rsp], xmm0
000076e4393e03c5  vmovaps [rsp+0x10], xmm2
000076e4393e03cb  vmovaps [rsp+0x20], xmm3
000076e4393e03d1  vmovaps [rsp+0x30], xmm4
000076e4393e03d7  vmovaps [rsp+0x40], xmm5
000076e4393e03dd  vmovaps [rsp+0x50], xmm6
000076e4393e03e3  vmovaps [rsp+0x60], xmm7
000076e4393e03e9  vmovaps [rsp+0x70], xmm8
000076e4393e03ef  vmovaps [rsp+0x80], xmm9
000076e4393e03f8  vmovaps [rsp+0x90], xmm10
000076e4393e0401  vmovaps [rsp+0xA0], xmm11
000076e4393e040a  vmovaps [rsp+0xB0], xmm12
000076e4393e0413  vmovaps [rsp+0xC0], xmm13
000076e4393e041c  vmovaps [rsp+0xD0], xmm14
000076e4393e0425  vmovaps [rsp+0xE0], xmm15
000076e4393e042e  sub rsp, 0x30
000076e4393e0432  movaps [rsp], xmm1
000076e4393e0436  movaps [rsp+0x10], xmm13
000076e4393e043c  movaps [rsp+0x20], xmm9
000076e4393e0442  lea rdi, [rsp]
000076e4393e0446  mov esi, 0x00
000076e4393e044b  mov rax, 0x63DBDEB43530
000076e4393e0455  call rax
000076e4393e0457  movaps xmm1, [rsp]
000076e4393e045b  add rsp, 0x30
000076e4393e045f  vmovaps xmm0, [rsp]
000076e4393e0464  vmovaps xmm2, [rsp+0x10]
000076e4393e046a  vmovaps xmm3, [rsp+0x20]
000076e4393e0470  vmovaps xmm4, [rsp+0x30]
000076e4393e0476  vmovaps xmm5, [rsp+0x40]
000076e4393e047c  vmovaps xmm6, [rsp+0x50]
000076e4393e0482  vmovaps xmm7, [rsp+0x60]
000076e4393e0488  vmovaps xmm8, [rsp+0x70]
000076e4393e048e  vmovaps xmm9, [rsp+0x80]
000076e4393e0497  vmovaps xmm10, [rsp+0x90]
000076e4393e04a0  vmovaps xmm11, [rsp+0xA0]
000076e4393e04a9  vmovaps xmm12, [rsp+0xB0]
000076e4393e04b2  vmovaps xmm13, [rsp+0xC0]
000076e4393e04bb  vmovaps xmm14, [rsp+0xD0]
000076e4393e04c4  vmovaps xmm15, [rsp+0xE0]
000076e4393e04cd  add rsp, 0xF0
000076e4393e04d4  pop r11
000076e4393e04d6  pop r10
000076e4393e04d8  pop r9
000076e4393e04da  pop r8
000076e4393e04dc  pop rsi
000076e4393e04dd  pop rdi
000076e4393e04de  pop rdx
000076e4393e04df  pop rcx
000076e4393e04e0  pop rax
000076e4393e04e1  add rsp, 0x08
000076e4393e04e5  jmp 0x000076E4393DC5CD
000076e4393e04ea  sub rsp, 0x08
000076e4393e04ee  push rax
000076e4393e04ef  push rcx
000076e4393e04f0  push rdx
000076e4393e04f1  push rdi
000076e4393e04f2  push rsi
000076e4393e04f3  push r8
000076e4393e04f5  push r9
000076e4393e04f7  push r10
000076e4393e04f9  push r11
000076e4393e04fb  sub rsp, 0xF0
000076e4393e0502  vmovaps [rsp], xmm0
000076e4393e0507  vmovaps [rsp+0x10], xmm1
000076e4393e050d  vmovaps [rsp+0x20], xmm2
000076e4393e0513  vmovaps [rsp+0x30], xmm3
000076e4393e0519  vmovaps [rsp+0x40], xmm4
000076e4393e051f  vmovaps [rsp+0x50], xmm5
000076e4393e0525  vmovaps [rsp+0x60], xmm6
000076e4393e052b  vmovaps [rsp+0x70], xmm7
000076e4393e0531  vmovaps [rsp+0x80], xmm8
000076e4393e053a  vmovaps [rsp+0x90], xmm9
000076e4393e0543  vmovaps [rsp+0xA0], xmm10
000076e4393e054c  vmovaps [rsp+0xB0], xmm11
000076e4393e0555  vmovaps [rsp+0xC0], xmm13
000076e4393e055e  vmovaps [rsp+0xD0], xmm14
000076e4393e0567  vmovaps [rsp+0xE0], xmm15
000076e4393e0570  sub rsp, 0x30
000076e4393e0574  movaps [rsp], xmm12
000076e4393e0579  movaps [rsp+0x10], xmm7
000076e4393e057e  movaps [rsp+0x20], xmm13
000076e4393e0584  lea rdi, [rsp]
000076e4393e0588  mov esi, 0x00
000076e4393e058d  mov rax, 0x63DBDEB43530
000076e4393e0597  call rax
000076e4393e0599  movaps xmm12, [rsp]
000076e4393e059e  add rsp, 0x30
000076e4393e05a2  vmovaps xmm0, [rsp]
000076e4393e05a7  vmovaps xmm1, [rsp+0x10]
000076e4393e05ad  vmovaps xmm2, [rsp+0x20]
000076e4393e05b3  vmovaps xmm3, [rsp+0x30]
000076e4393e05b9  vmovaps xmm4, [rsp+0x40]
000076e4393e05bf  vmovaps xmm5, [rsp+0x50]
000076e4393e05c5  vmovaps xmm6, [rsp+0x60]
000076e4393e05cb  vmovaps xmm7, [rsp+0x70]
000076e4393e05d1  vmovaps xmm8, [rsp+0x80]
000076e4393e05da  vmovaps xmm9, [rsp+0x90]
000076e4393e05e3  vmovaps xmm10, [rsp+0xA0]
000076e4393e05ec  vmovaps xmm11, [rsp+0xB0]
000076e4393e05f5  vmovaps xmm13, [rsp+0xC0]
000076e4393e05fe  vmovaps xmm14, [rsp+0xD0]
000076e4393e0607  vmovaps xmm15, [rsp+0xE0]
000076e4393e0610  add rsp, 0xF0
000076e4393e0617  pop r11
000076e4393e0619  pop r10
000076e4393e061b  pop r9
000076e4393e061d  pop r8
000076e4393e061f  pop rsi
000076e4393e0620  pop rdi
000076e4393e0621  pop rdx
000076e4393e0622  pop rcx
000076e4393e0623  pop rax
000076e4393e0624  add rsp, 0x08
000076e4393e0628  jmp 0x000076E4393DC5F4
000076e4393e062d  sub rsp, 0x08
000076e4393e0631  push rax
000076e4393e0632  push rcx
000076e4393e0633  push rdx
000076e4393e0634  push rdi
000076e4393e0635  push rsi
000076e4393e0636  push r8
000076e4393e0638  push r9
000076e4393e063a  push r10
000076e4393e063c  push r11
000076e4393e063e  sub rsp, 0xF0
000076e4393e0645  vmovaps [rsp], xmm0
000076e4393e064a  vmovaps [rsp+0x10], xmm1
000076e4393e0650  vmovaps [rsp+0x20], xmm2
000076e4393e0656  vmovaps [rsp+0x30], xmm3
000076e4393e065c  vmovaps [rsp+0x40], xmm4
000076e4393e0662  vmovaps [rsp+0x50], xmm5
000076e4393e0668  vmovaps [rsp+0x60], xmm6
000076e4393e066e  vmovaps [rsp+0x70], xmm7
000076e4393e0674  vmovaps [rsp+0x80], xmm8
000076e4393e067d  vmovaps [rsp+0x90], xmm9
000076e4393e0686  vmovaps [rsp+0xA0], xmm10
000076e4393e068f  vmovaps [rsp+0xB0], xmm11
000076e4393e0698  vmovaps [rsp+0xC0], xmm12
000076e4393e06a1  vmovaps [rsp+0xD0], xmm14
000076e4393e06aa  vmovaps [rsp+0xE0], xmm15
000076e4393e06b3  sub rsp, 0x30
000076e4393e06b7  movaps [rsp], xmm13
000076e4393e06bc  movaps [rsp+0x10], xmm15
000076e4393e06c2  movaps [rsp+0x20], xmm8
000076e4393e06c8  lea rdi, [rsp]
000076e4393e06cc  mov esi, 0x00
000076e4393e06d1  mov rax, 0x63DBDEB43530
000076e4393e06db  call rax
000076e4393e06dd  movaps xmm13, [rsp]
000076e4393e06e2  add rsp, 0x30
000076e4393e06e6  vmovaps xmm0, [rsp]
000076e4393e06eb  vmovaps xmm1, [rsp+0x10]
000076e4393e06f1  vmovaps xmm2, [rsp+0x20]
000076e4393e06f7  vmovaps xmm3, [rsp+0x30]
000076e4393e06fd  vmovaps xmm4, [rsp+0x40]
000076e4393e0703  vmovaps xmm5, [rsp+0x50]
000076e4393e0709  vmovaps xmm6, [rsp+0x60]
000076e4393e070f  vmovaps xmm7, [rsp+0x70]
000076e4393e0715  vmovaps xmm8, [rsp+0x80]
000076e4393e071e  vmovaps xmm9, [rsp+0x90]
000076e4393e0727  vmovaps xmm10, [rsp+0xA0]
000076e4393e0730  vmovaps xmm11, [rsp+0xB0]
000076e4393e0739  vmovaps xmm12, [rsp+0xC0]
000076e4393e0742  vmovaps xmm14, [rsp+0xD0]
000076e4393e074b  vmovaps xmm15, [rsp+0xE0]
000076e4393e0754  add rsp, 0xF0
000076e4393e075b  pop r11
000076e4393e075d  pop r10
000076e4393e075f  pop r9
000076e4393e0761  pop r8
000076e4393e0763  pop rsi
000076e4393e0764  pop rdi
000076e4393e0765  pop rdx
000076e4393e0766  pop rcx
000076e4393e0767  pop rax
000076e4393e0768  add rsp, 0x08
000076e4393e076c  jmp 0x000076E4393DC60F
000076e4393e0771  sub rsp, 0x08
000076e4393e0775  push rax
000076e4393e0776  push rcx
000076e4393e0777  push rdx
000076e4393e0778  push rdi
000076e4393e0779  push rsi
000076e4393e077a  push r8
000076e4393e077c  push r9
000076e4393e077e  push r10
000076e4393e0780  push r11
000076e4393e0782  sub rsp, 0xF0
000076e4393e0789  vmovaps [rsp], xmm0
000076e4393e078e  vmovaps [rsp+0x10], xmm1
000076e4393e0794  vmovaps [rsp+0x20], xmm2
000076e4393e079a  vmovaps [rsp+0x30], xmm3
000076e4393e07a0  vmovaps [rsp+0x40], xmm4
000076e4393e07a6  vmovaps [rsp+0x50], xmm5
000076e4393e07ac  vmovaps [rsp+0x60], xmm6
000076e4393e07b2  vmovaps [rsp+0x70], xmm7
000076e4393e07b8  vmovaps [rsp+0x80], xmm9
000076e4393e07c1  vmovaps [rsp+0x90], xmm10
000076e4393e07ca  vmovaps [rsp+0xA0], xmm11
000076e4393e07d3  vmovaps [rsp+0xB0], xmm12
000076e4393e07dc  vmovaps [rsp+0xC0], xmm13
000076e4393e07e5  vmovaps [rsp+0xD0], xmm14
000076e4393e07ee  vmovaps [rsp+0xE0], xmm15
000076e4393e07f7  sub rsp, 0x30
000076e4393e07fb  movaps [rsp], xmm8
000076e4393e0800  movaps [rsp+0x10], xmm15
000076e4393e0806  movaps [rsp+0x20], xmm9
000076e4393e080c  lea rdi, [rsp]
000076e4393e0810  mov esi, 0x00
000076e4393e0815  mov rax, 0x63DBDEB43530
000076e4393e081f  call rax
000076e4393e0821  movaps xmm8, [rsp]
000076e4393e0826  add rsp, 0x30
000076e4393e082a  vmovaps xmm0, [rsp]
000076e4393e082f  vmovaps xmm1, [rsp+0x10]
000076e4393e0835  vmovaps xmm2, [rsp+0x20]
000076e4393e083b  vmovaps xmm3, [rsp+0x30]
000076e4393e0841  vmovaps xmm4, [rsp+0x40]
000076e4393e0847  vmovaps xmm5, [rsp+0x50]
000076e4393e084d  vmovaps xmm6, [rsp+0x60]
000076e4393e0853  vmovaps xmm7, [rsp+0x70]
000076e4393e0859  vmovaps xmm9, [rsp+0x80]
000076e4393e0862  vmovaps xmm10, [rsp+0x90]
000076e4393e086b  vmovaps xmm11, [rsp+0xA0]
000076e4393e0874  vmovaps xmm12, [rsp+0xB0]
000076e4393e087d  vmovaps xmm13, [rsp+0xC0]
000076e4393e0886  vmovaps xmm14, [rsp+0xD0]
000076e4393e088f  vmovaps xmm15, [rsp+0xE0]
000076e4393e0898  add rsp, 0xF0
000076e4393e089f  pop r11
000076e4393e08a1  pop r10
000076e4393e08a3  pop r9
000076e4393e08a5  pop r8
000076e4393e08a7  pop rsi
000076e4393e08a8  pop rdi
000076e4393e08a9  pop rdx
000076e4393e08aa  pop rcx
000076e4393e08ab  pop rax
000076e4393e08ac  add rsp, 0x08
000076e4393e08b0  jmp 0x000076E4393DC63D
000076e4393e08b5  sub rsp, 0x08
000076e4393e08b9  push rax
000076e4393e08ba  push rcx
000076e4393e08bb  push rdx
000076e4393e08bc  push rdi
000076e4393e08bd  push rsi
000076e4393e08be  push r8
000076e4393e08c0  push r9
000076e4393e08c2  push r10
000076e4393e08c4  push r11
000076e4393e08c6  sub rsp, 0xF0
000076e4393e08cd  vmovaps [rsp], xmm0
000076e4393e08d2  vmovaps [rsp+0x10], xmm1
000076e4393e08d8  vmovaps [rsp+0x20], xmm2
000076e4393e08de  vmovaps [rsp+0x30], xmm3
000076e4393e08e4  vmovaps [rsp+0x40], xmm4
000076e4393e08ea  vmovaps [rsp+0x50], xmm5
000076e4393e08f0  vmovaps [rsp+0x60], xmm6
000076e4393e08f6  vmovaps [rsp+0x70], xmm7
000076e4393e08fc  vmovaps [rsp+0x80], xmm8
000076e4393e0905  vmovaps [rsp+0x90], xmm9
000076e4393e090e  vmovaps [rsp+0xA0], xmm10
000076e4393e0917  vmovaps [rsp+0xB0], xmm11
000076e4393e0920  vmovaps [rsp+0xC0], xmm12
000076e4393e0929  vmovaps [rsp+0xD0], xmm13
000076e4393e0932  vmovaps [rsp+0xE0], xmm14
000076e4393e093b  sub rsp, 0x30
000076e4393e093f  movaps [rsp], xmm15
000076e4393e0944  movaps [rsp+0x10], xmm11
000076e4393e094a  movaps [rsp+0x20], xmm6
000076e4393e094f  lea rdi, [rsp]
000076e4393e0953  mov esi, 0x00
000076e4393e0958  mov rax, 0x63DBDEB43530
000076e4393e0962  call rax
000076e4393e0964  movaps xmm15, [rsp]
000076e4393e0969  add rsp, 0x30
000076e4393e096d  vmovaps xmm0, [rsp]
000076e4393e0972  vmovaps xmm1, [rsp+0x10]
000076e4393e0978  vmovaps xmm2, [rsp+0x20]
000076e4393e097e  vmovaps xmm3, [rsp+0x30]
000076e4393e0984  vmovaps xmm4, [rsp+0x40]
000076e4393e098a  vmovaps xmm5, [rsp+0x50]
000076e4393e0990  vmovaps xmm6, [rsp+0x60]
000076e4393e0996  vmovaps xmm7, [rsp+0x70]
000076e4393e099c  vmovaps xmm8, [rsp+0x80]
000076e4393e09a5  vmovaps xmm9, [rsp+0x90]
000076e4393e09ae  vmovaps xmm10, [rsp+0xA0]
000076e4393e09b7  vmovaps xmm11, [rsp+0xB0]
000076e4393e09c0  vmovaps xmm12, [rsp+0xC0]
000076e4393e09c9  vmovaps xmm13, [rsp+0xD0]
000076e4393e09d2  vmovaps xmm14, [rsp+0xE0]
000076e4393e09db  add rsp, 0xF0
000076e4393e09e2  pop r11
000076e4393e09e4  pop r10
000076e4393e09e6  pop r9
000076e4393e09e8  pop r8
000076e4393e09ea  pop rsi
000076e4393e09eb  pop rdi
000076e4393e09ec  pop rdx
000076e4393e09ed  pop rcx
000076e4393e09ee  pop rax
000076e4393e09ef  add rsp, 0x08
000076e4393e09f3  jmp 0x000076E4393DC658
000076e4393e09f8  sub rsp, 0x08
000076e4393e09fc  push rax
000076e4393e09fd  push rcx
000076e4393e09fe  push rdx
000076e4393e09ff  push rdi
000076e4393e0a00  push rsi
000076e4393e0a01  push r8
000076e4393e0a03  push r9
000076e4393e0a05  push r10
000076e4393e0a07  push r11
000076e4393e0a09  sub rsp, 0xF0
000076e4393e0a10  vmovaps [rsp], xmm0
000076e4393e0a15  vmovaps [rsp+0x10], xmm1
000076e4393e0a1b  vmovaps [rsp+0x20], xmm2
000076e4393e0a21  vmovaps [rsp+0x30], xmm3
000076e4393e0a27  vmovaps [rsp+0x40], xmm4
000076e4393e0a2d  vmovaps [rsp+0x50], xmm5
000076e4393e0a33  vmovaps [rsp+0x60], xmm6
000076e4393e0a39  vmovaps [rsp+0x70], xmm8
000076e4393e0a3f  vmovaps [rsp+0x80], xmm9
000076e4393e0a48  vmovaps [rsp+0x90], xmm10
000076e4393e0a51  vmovaps [rsp+0xA0], xmm11
000076e4393e0a5a  vmovaps [rsp+0xB0], xmm12
000076e4393e0a63  vmovaps [rsp+0xC0], xmm13
000076e4393e0a6c  vmovaps [rsp+0xD0], xmm14
000076e4393e0a75  vmovaps [rsp+0xE0], xmm15
000076e4393e0a7e  sub rsp, 0x30
000076e4393e0a82  movaps [rsp], xmm7
000076e4393e0a86  movaps [rsp+0x10], xmm11
000076e4393e0a8c  movaps [rsp+0x20], xmm9
000076e4393e0a92  lea rdi, [rsp]
000076e4393e0a96  mov esi, 0x00
000076e4393e0a9b  mov rax, 0x63DBDEB43530
000076e4393e0aa5  call rax
000076e4393e0aa7  movaps xmm7, [rsp]
000076e4393e0aab  add rsp, 0x30
000076e4393e0aaf  vmovaps xmm0, [rsp]
000076e4393e0ab4  vmovaps xmm1, [rsp+0x10]
000076e4393e0aba  vmovaps xmm2, [rsp+0x20]
000076e4393e0ac0  vmovaps xmm3, [rsp+0x30]
000076e4393e0ac6  vmovaps xmm4, [rsp+0x40]
000076e4393e0acc  vmovaps xmm5, [rsp+0x50]
000076e4393e0ad2  vmovaps xmm6, [rsp+0x60]
000076e4393e0ad8  vmovaps xmm8, [rsp+0x70]
000076e4393e0ade  vmovaps xmm9, [rsp+0x80]
000076e4393e0ae7  vmovaps xmm10, [rsp+0x90]
000076e4393e0af0  vmovaps xmm11, [rsp+0xA0]
000076e4393e0af9  vmovaps xmm12, [rsp+0xB0]
000076e4393e0b02  vmovaps xmm13, [rsp+0xC0]
000076e4393e0b0b  vmovaps xmm14, [rsp+0xD0]
000076e4393e0b14  vmovaps xmm15, [rsp+0xE0]
000076e4393e0b1d  add rsp, 0xF0
000076e4393e0b24  pop r11
000076e4393e0b26  pop r10
000076e4393e0b28  pop r9
000076e4393e0b2a  pop r8
000076e4393e0b2c  pop rsi
000076e4393e0b2d  pop rdi
000076e4393e0b2e  pop rdx
000076e4393e0b2f  pop rcx
000076e4393e0b30  pop rax
000076e4393e0b31  add rsp, 0x08
000076e4393e0b35  jmp 0x000076E4393DC685
000076e4393e0b3a  sub rsp, 0x08
000076e4393e0b3e  push rax
000076e4393e0b3f  push rcx
000076e4393e0b40  push rdx
000076e4393e0b41  push rdi
000076e4393e0b42  push rsi
000076e4393e0b43  push r8
000076e4393e0b45  push r9
000076e4393e0b47  push r10
000076e4393e0b49  push r11
000076e4393e0b4b  sub rsp, 0xF0
000076e4393e0b52  vmovaps [rsp], xmm0
000076e4393e0b57  vmovaps [rsp+0x10], xmm1
000076e4393e0b5d  vmovaps [rsp+0x20], xmm2
000076e4393e0b63  vmovaps [rsp+0x30], xmm3
000076e4393e0b69  vmovaps [rsp+0x40], xmm4
000076e4393e0b6f  vmovaps [rsp+0x50], xmm5
000076e4393e0b75  vmovaps [rsp+0x60], xmm6
000076e4393e0b7b  vmovaps [rsp+0x70], xmm7
000076e4393e0b81  vmovaps [rsp+0x80], xmm8
000076e4393e0b8a  vmovaps [rsp+0x90], xmm9
000076e4393e0b93  vmovaps [rsp+0xA0], xmm10
000076e4393e0b9c  vmovaps [rsp+0xB0], xmm12
000076e4393e0ba5  vmovaps [rsp+0xC0], xmm13
000076e4393e0bae  vmovaps [rsp+0xD0], xmm14
000076e4393e0bb7  vmovaps [rsp+0xE0], xmm15
000076e4393e0bc0  sub rsp, 0x30
000076e4393e0bc4  movaps [rsp], xmm11
000076e4393e0bc9  movaps [rsp+0x10], xmm10
000076e4393e0bcf  movaps [rsp+0x20], xmm14
000076e4393e0bd5  lea rdi, [rsp]
000076e4393e0bd9  mov esi, 0x00
000076e4393e0bde  mov rax, 0x63DBDEB43530
000076e4393e0be8  call rax
000076e4393e0bea  movaps xmm11, [rsp]
000076e4393e0bef  add rsp, 0x30
000076e4393e0bf3  vmovaps xmm0, [rsp]
000076e4393e0bf8  vmovaps xmm1, [rsp+0x10]
000076e4393e0bfe  vmovaps xmm2, [rsp+0x20]
000076e4393e0c04  vmovaps xmm3, [rsp+0x30]
000076e4393e0c0a  vmovaps xmm4, [rsp+0x40]
000076e4393e0c10  vmovaps xmm5, [rsp+0x50]
000076e4393e0c16  vmovaps xmm6, [rsp+0x60]
000076e4393e0c1c  vmovaps xmm7, [rsp+0x70]
000076e4393e0c22  vmovaps xmm8, [rsp+0x80]
000076e4393e0c2b  vmovaps xmm9, [rsp+0x90]
000076e4393e0c34  vmovaps xmm10, [rsp+0xA0]
000076e4393e0c3d  vmovaps xmm12, [rsp+0xB0]
000076e4393e0c46  vmovaps xmm13, [rsp+0xC0]
000076e4393e0c4f  vmovaps xmm14, [rsp+0xD0]
000076e4393e0c58  vmovaps xmm15, [rsp+0xE0]
000076e4393e0c61  add rsp, 0xF0
000076e4393e0c68  pop r11
000076e4393e0c6a  pop r10
000076e4393e0c6c  pop r9
000076e4393e0c6e  pop r8
000076e4393e0c70  pop rsi
000076e4393e0c71  pop rdi
000076e4393e0c72  pop rdx
000076e4393e0c73  pop rcx
000076e4393e0c74  pop rax
000076e4393e0c75  add rsp, 0x08
000076e4393e0c79  jmp 0x000076E4393DC6A0
000076e4393e0c7e  call 0x000076E4392C33A0
000076e4393e0c83  jmp 0x000076E4393DC6AA
000076e4393e0c88  sub rsp, 0x08
000076e4393e0c8c  push rax
000076e4393e0c8d  push rcx
000076e4393e0c8e  push rdx
000076e4393e0c8f  push rdi
000076e4393e0c90  push rsi
000076e4393e0c91  push r8
000076e4393e0c93  push r9
000076e4393e0c95  push r10
000076e4393e0c97  push r11
000076e4393e0c99  sub rsp, 0xF0
000076e4393e0ca0  vmovaps [rsp], xmm0
000076e4393e0ca5  vmovaps [rsp+0x10], xmm1
000076e4393e0cab  vmovaps [rsp+0x20], xmm2
000076e4393e0cb1  vmovaps [rsp+0x30], xmm3
000076e4393e0cb7  vmovaps [rsp+0x40], xmm4
000076e4393e0cbd  vmovaps [rsp+0x50], xmm5
000076e4393e0cc3  vmovaps [rsp+0x60], xmm6
000076e4393e0cc9  vmovaps [rsp+0x70], xmm7
000076e4393e0ccf  vmovaps [rsp+0x80], xmm8
000076e4393e0cd8  vmovaps [rsp+0x90], xmm9
000076e4393e0ce1  vmovaps [rsp+0xA0], xmm11
000076e4393e0cea  vmovaps [rsp+0xB0], xmm12
000076e4393e0cf3  vmovaps [rsp+0xC0], xmm13
000076e4393e0cfc  vmovaps [rsp+0xD0], xmm14
000076e4393e0d05  vmovaps [rsp+0xE0], xmm15
000076e4393e0d0e  sub rsp, 0x30
000076e4393e0d12  movaps [rsp], xmm10
000076e4393e0d17  movaps [rsp+0x10], xmm1
000076e4393e0d1c  movaps [rsp+0x20], xmm12
000076e4393e0d22  lea rdi, [rsp]
000076e4393e0d26  mov esi, 0x00
000076e4393e0d2b  mov rax, 0x63DBDEB43530
000076e4393e0d35  call rax
000076e4393e0d37  movaps xmm10, [rsp]
000076e4393e0d3c  add rsp, 0x30
000076e4393e0d40  vmovaps xmm0, [rsp]
000076e4393e0d45  vmovaps xmm1, [rsp+0x10]
000076e4393e0d4b  vmovaps xmm2, [rsp+0x20]
000076e4393e0d51  vmovaps xmm3, [rsp+0x30]
000076e4393e0d57  vmovaps xmm4, [rsp+0x40]
000076e4393e0d5d  vmovaps xmm5, [rsp+0x50]
000076e4393e0d63  vmovaps xmm6, [rsp+0x60]
000076e4393e0d69  vmovaps xmm7, [rsp+0x70]
000076e4393e0d6f  vmovaps xmm8, [rsp+0x80]
000076e4393e0d78  vmovaps xmm9, [rsp+0x90]
000076e4393e0d81  vmovaps xmm11, [rsp+0xA0]
000076e4393e0d8a  vmovaps xmm12, [rsp+0xB0]
000076e4393e0d93  vmovaps xmm13, [rsp+0xC0]
000076e4393e0d9c  vmovaps xmm14, [rsp+0xD0]
000076e4393e0da5  vmovaps xmm15, [rsp+0xE0]
000076e4393e0dae  add rsp, 0xF0
000076e4393e0db5  pop r11
000076e4393e0db7  pop r10
000076e4393e0db9  pop r9
000076e4393e0dbb  pop r8
000076e4393e0dbd  pop rsi
000076e4393e0dbe  pop rdi
000076e4393e0dbf  pop rdx
000076e4393e0dc0  pop rcx
000076e4393e0dc1  pop rax
000076e4393e0dc2  add rsp, 0x08
000076e4393e0dc6  jmp 0x000076E4393DC6CD
000076e4393e0dcb  sub rsp, 0x08
000076e4393e0dcf  push rax
000076e4393e0dd0  push rcx
000076e4393e0dd1  push rdx
000076e4393e0dd2  push rdi
000076e4393e0dd3  push rsi
000076e4393e0dd4  push r8
000076e4393e0dd6  push r9
000076e4393e0dd8  push r10
000076e4393e0dda  push r11
000076e4393e0ddc  sub rsp, 0xF0
000076e4393e0de3  vmovaps [rsp], xmm0
000076e4393e0de8  vmovaps [rsp+0x10], xmm1
000076e4393e0dee  vmovaps [rsp+0x20], xmm2
000076e4393e0df4  vmovaps [rsp+0x30], xmm3
000076e4393e0dfa  vmovaps [rsp+0x40], xmm4
000076e4393e0e00  vmovaps [rsp+0x50], xmm5
000076e4393e0e06  vmovaps [rsp+0x60], xmm6
000076e4393e0e0c  vmovaps [rsp+0x70], xmm7
000076e4393e0e12  vmovaps [rsp+0x80], xmm8
000076e4393e0e1b  vmovaps [rsp+0x90], xmm9
000076e4393e0e24  vmovaps [rsp+0xA0], xmm10
000076e4393e0e2d  vmovaps [rsp+0xB0], xmm11
000076e4393e0e36  vmovaps [rsp+0xC0], xmm13
000076e4393e0e3f  vmovaps [rsp+0xD0], xmm14
000076e4393e0e48  vmovaps [rsp+0xE0], xmm15
000076e4393e0e51  sub rsp, 0x30
000076e4393e0e55  movaps [rsp], xmm12
000076e4393e0e5a  movaps [rsp+0x10], xmm14
000076e4393e0e60  movaps [rsp+0x20], xmm1
000076e4393e0e65  lea rdi, [rsp]
000076e4393e0e69  mov esi, 0x00
000076e4393e0e6e  mov rax, 0x63DBDEB43530
000076e4393e0e78  call rax
000076e4393e0e7a  movaps xmm12, [rsp]
000076e4393e0e7f  add rsp, 0x30
000076e4393e0e83  vmovaps xmm0, [rsp]
000076e4393e0e88  vmovaps xmm1, [rsp+0x10]
000076e4393e0e8e  vmovaps xmm2, [rsp+0x20]
000076e4393e0e94  vmovaps xmm3, [rsp+0x30]
000076e4393e0e9a  vmovaps xmm4, [rsp+0x40]
000076e4393e0ea0  vmovaps xmm5, [rsp+0x50]
000076e4393e0ea6  vmovaps xmm6, [rsp+0x60]
000076e4393e0eac  vmovaps xmm7, [rsp+0x70]
000076e4393e0eb2  vmovaps xmm8, [rsp+0x80]
000076e4393e0ebb  vmovaps xmm9, [rsp+0x90]
000076e4393e0ec4  vmovaps xmm10, [rsp+0xA0]
000076e4393e0ecd  vmovaps xmm11, [rsp+0xB0]
000076e4393e0ed6  vmovaps xmm13, [rsp+0xC0]
000076e4393e0edf  vmovaps xmm14, [rsp+0xD0]
000076e4393e0ee8  vmovaps xmm15, [rsp+0xE0]
000076e4393e0ef1  add rsp, 0xF0
000076e4393e0ef8  pop r11
000076e4393e0efa  pop r10
000076e4393e0efc  pop r9
000076e4393e0efe  pop r8
000076e4393e0f00  pop rsi
000076e4393e0f01  pop rdi
000076e4393e0f02  pop rdx
000076e4393e0f03  pop rcx
000076e4393e0f04  pop rax
000076e4393e0f05  add rsp, 0x08
000076e4393e0f09  jmp 0x000076E4393DC6FC
000076e4393e0f0e  sub rsp, 0x08
000076e4393e0f12  push rax
000076e4393e0f13  push rcx
000076e4393e0f14  push rdx
000076e4393e0f15  push rdi
000076e4393e0f16  push rsi
000076e4393e0f17  push r8
000076e4393e0f19  push r9
000076e4393e0f1b  push r10
000076e4393e0f1d  push r11
000076e4393e0f1f  sub rsp, 0xF0
000076e4393e0f26  vmovaps [rsp], xmm0
000076e4393e0f2b  vmovaps [rsp+0x10], xmm1
000076e4393e0f31  vmovaps [rsp+0x20], xmm2
000076e4393e0f37  vmovaps [rsp+0x30], xmm3
000076e4393e0f3d  vmovaps [rsp+0x40], xmm4
000076e4393e0f43  vmovaps [rsp+0x50], xmm5
000076e4393e0f49  vmovaps [rsp+0x60], xmm6
000076e4393e0f4f  vmovaps [rsp+0x70], xmm7
000076e4393e0f55  vmovaps [rsp+0x80], xmm8
000076e4393e0f5e  vmovaps [rsp+0x90], xmm9
000076e4393e0f67  vmovaps [rsp+0xA0], xmm10
000076e4393e0f70  vmovaps [rsp+0xB0], xmm11
000076e4393e0f79  vmovaps [rsp+0xC0], xmm12
000076e4393e0f82  vmovaps [rsp+0xD0], xmm13
000076e4393e0f8b  vmovaps [rsp+0xE0], xmm15
000076e4393e0f94  sub rsp, 0x30
000076e4393e0f98  movaps [rsp], xmm14
000076e4393e0f9d  movaps [rsp+0x10], xmm9
000076e4393e0fa3  movaps [rsp+0x20], xmm1
000076e4393e0fa8  lea rdi, [rsp]
000076e4393e0fac  mov esi, 0x00
000076e4393e0fb1  mov rax, 0x63DBDEB43530
000076e4393e0fbb  call rax
000076e4393e0fbd  movaps xmm14, [rsp]
000076e4393e0fc2  add rsp, 0x30
000076e4393e0fc6  vmovaps xmm0, [rsp]
000076e4393e0fcb  vmovaps xmm1, [rsp+0x10]
000076e4393e0fd1  vmovaps xmm2, [rsp+0x20]
000076e4393e0fd7  vmovaps xmm3, [rsp+0x30]
000076e4393e0fdd  vmovaps xmm4, [rsp+0x40]
000076e4393e0fe3  vmovaps xmm5, [rsp+0x50]
000076e4393e0fe9  vmovaps xmm6, [rsp+0x60]
000076e4393e0fef  vmovaps xmm7, [rsp+0x70]
000076e4393e0ff5  vmovaps xmm8, [rsp+0x80]
000076e4393e0ffe  vmovaps xmm9, [rsp+0x90]
000076e4393e1007  vmovaps xmm10, [rsp+0xA0]
000076e4393e1010  vmovaps xmm11, [rsp+0xB0]
000076e4393e1019  vmovaps xmm12, [rsp+0xC0]
000076e4393e1022  vmovaps xmm13, [rsp+0xD0]
000076e4393e102b  vmovaps xmm15, [rsp+0xE0]
000076e4393e1034  add rsp, 0xF0
000076e4393e103b  pop r11
000076e4393e103d  pop r10
000076e4393e103f  pop r9
000076e4393e1041  pop r8
000076e4393e1043  pop rsi
000076e4393e1044  pop rdi
000076e4393e1045  pop rdx
000076e4393e1046  pop rcx
000076e4393e1047  pop rax
000076e4393e1048  add rsp, 0x08
000076e4393e104c  jmp 0x000076E4393DC72B
000076e4393e1051  sub rsp, 0x08
000076e4393e1055  push rax
000076e4393e1056  push rcx
000076e4393e1057  push rdx
000076e4393e1058  push rdi
000076e4393e1059  push rsi
000076e4393e105a  push r8
000076e4393e105c  push r9
000076e4393e105e  push r10
000076e4393e1060  push r11
000076e4393e1062  sub rsp, 0xF0
000076e4393e1069  vmovaps [rsp], xmm0
000076e4393e106e  vmovaps [rsp+0x10], xmm2
000076e4393e1074  vmovaps [rsp+0x20], xmm3
000076e4393e107a  vmovaps [rsp+0x30], xmm4
000076e4393e1080  vmovaps [rsp+0x40], xmm5
000076e4393e1086  vmovaps [rsp+0x50], xmm6
000076e4393e108c  vmovaps [rsp+0x60], xmm7
000076e4393e1092  vmovaps [rsp+0x70], xmm8
000076e4393e1098  vmovaps [rsp+0x80], xmm9
000076e4393e10a1  vmovaps [rsp+0x90], xmm10
000076e4393e10aa  vmovaps [rsp+0xA0], xmm11
000076e4393e10b3  vmovaps [rsp+0xB0], xmm12
000076e4393e10bc  vmovaps [rsp+0xC0], xmm13
000076e4393e10c5  vmovaps [rsp+0xD0], xmm14
000076e4393e10ce  vmovaps [rsp+0xE0], xmm15
000076e4393e10d7  sub rsp, 0x30
000076e4393e10db  movaps [rsp], xmm1
000076e4393e10df  movaps [rsp+0x10], xmm13
000076e4393e10e5  movaps [rsp+0x20], xmm8
000076e4393e10eb  lea rdi, [rsp]
000076e4393e10ef  mov esi, 0x00
000076e4393e10f4  mov rax, 0x63DBDEB43530
000076e4393e10fe  call rax
000076e4393e1100  movaps xmm1, [rsp]
000076e4393e1104  add rsp, 0x30
000076e4393e1108  vmovaps xmm0, [rsp]
000076e4393e110d  vmovaps xmm2, [rsp+0x10]
000076e4393e1113  vmovaps xmm3, [rsp+0x20]
000076e4393e1119  vmovaps xmm4, [rsp+0x30]
000076e4393e111f  vmovaps xmm5, [rsp+0x40]
000076e4393e1125  vmovaps xmm6, [rsp+0x50]
000076e4393e112b  vmovaps xmm7, [rsp+0x60]
000076e4393e1131  vmovaps xmm8, [rsp+0x70]
000076e4393e1137  vmovaps xmm9, [rsp+0x80]
000076e4393e1140  vmovaps xmm10, [rsp+0x90]
000076e4393e1149  vmovaps xmm11, [rsp+0xA0]
000076e4393e1152  vmovaps xmm12, [rsp+0xB0]
000076e4393e115b  vmovaps xmm13, [rsp+0xC0]
000076e4393e1164  vmovaps xmm14, [rsp+0xD0]
000076e4393e116d  vmovaps xmm15, [rsp+0xE0]
000076e4393e1176  add rsp, 0xF0
000076e4393e117d  pop r11
000076e4393e117f  pop r10
000076e4393e1181  pop r9
000076e4393e1183  pop r8
000076e4393e1185  pop rsi
000076e4393e1186  pop rdi
000076e4393e1187  pop rdx
000076e4393e1188  pop rcx
000076e4393e1189  pop rax
000076e4393e118a  add rsp, 0x08
000076e4393e118e  jmp 0x000076E4393DC74D
000076e4393e1193  call 0x000076E43920C260
000076e4393e1198  jmp 0x000076E4393DC75B
000076e4393e119d  call 0x000076E4392BD750
000076e4393e11a2  jmp 0x000076E4393DC765
000076e4393e11a7  sub rsp, 0x08
000076e4393e11ab  push rax
000076e4393e11ac  push rcx
000076e4393e11ad  push rdx
000076e4393e11ae  push rdi
000076e4393e11af  push rsi
000076e4393e11b0  push r8
000076e4393e11b2  push r9
000076e4393e11b4  push r10
000076e4393e11b6  push r11
000076e4393e11b8  sub rsp, 0xF0
000076e4393e11bf  vmovaps [rsp], xmm0
000076e4393e11c4  vmovaps [rsp+0x10], xmm1
000076e4393e11ca  vmovaps [rsp+0x20], xmm2
000076e4393e11d0  vmovaps [rsp+0x30], xmm3
000076e4393e11d6  vmovaps [rsp+0x40], xmm4
000076e4393e11dc  vmovaps [rsp+0x50], xmm5
000076e4393e11e2  vmovaps [rsp+0x60], xmm6
000076e4393e11e8  vmovaps [rsp+0x70], xmm7
000076e4393e11ee  vmovaps [rsp+0x80], xmm9
000076e4393e11f7  vmovaps [rsp+0x90], xmm10
000076e4393e1200  vmovaps [rsp+0xA0], xmm11
000076e4393e1209  vmovaps [rsp+0xB0], xmm12
000076e4393e1212  vmovaps [rsp+0xC0], xmm13
000076e4393e121b  vmovaps [rsp+0xD0], xmm14
000076e4393e1224  vmovaps [rsp+0xE0], xmm15
000076e4393e122d  sub rsp, 0x30
000076e4393e1231  movaps [rsp], xmm8
000076e4393e1236  movaps [rsp+0x10], xmm15
000076e4393e123c  movaps [rsp+0x20], xmm7
000076e4393e1241  lea rdi, [rsp]
000076e4393e1245  mov esi, 0x00
000076e4393e124a  mov rax, 0x63DBDEB43530
000076e4393e1254  call rax
000076e4393e1256  movaps xmm8, [rsp]
000076e4393e125b  add rsp, 0x30
000076e4393e125f  vmovaps xmm0, [rsp]
000076e4393e1264  vmovaps xmm1, [rsp+0x10]
000076e4393e126a  vmovaps xmm2, [rsp+0x20]
000076e4393e1270  vmovaps xmm3, [rsp+0x30]
000076e4393e1276  vmovaps xmm4, [rsp+0x40]
000076e4393e127c  vmovaps xmm5, [rsp+0x50]
000076e4393e1282  vmovaps xmm6, [rsp+0x60]
000076e4393e1288  vmovaps xmm7, [rsp+0x70]
000076e4393e128e  vmovaps xmm9, [rsp+0x80]
000076e4393e1297  vmovaps xmm10, [rsp+0x90]
000076e4393e12a0  vmovaps xmm11, [rsp+0xA0]
000076e4393e12a9  vmovaps xmm12, [rsp+0xB0]
000076e4393e12b2  vmovaps xmm13, [rsp+0xC0]
000076e4393e12bb  vmovaps xmm14, [rsp+0xD0]
000076e4393e12c4  vmovaps xmm15, [rsp+0xE0]
000076e4393e12cd  add rsp, 0xF0
000076e4393e12d4  pop r11
000076e4393e12d6  pop r10
000076e4393e12d8  pop r9
000076e4393e12da  pop r8
000076e4393e12dc  pop rsi
000076e4393e12dd  pop rdi
000076e4393e12de  pop rdx
000076e4393e12df  pop rcx
000076e4393e12e0  pop rax
000076e4393e12e1  add rsp, 0x08
000076e4393e12e5  jmp 0x000076E4393DC787
000076e4393e12ea  sub rsp, 0x08
000076e4393e12ee  push rax
000076e4393e12ef  push rcx
000076e4393e12f0  push rdx
000076e4393e12f1  push rdi
000076e4393e12f2  push rsi
000076e4393e12f3  push r8
000076e4393e12f5  push r9
000076e4393e12f7  push r10
000076e4393e12f9  push r11
000076e4393e12fb  sub rsp, 0xF0
000076e4393e1302  vmovaps [rsp], xmm0
000076e4393e1307  vmovaps [rsp+0x10], xmm1
000076e4393e130d  vmovaps [rsp+0x20], xmm2
000076e4393e1313  vmovaps [rsp+0x30], xmm3
000076e4393e1319  vmovaps [rsp+0x40], xmm4
000076e4393e131f  vmovaps [rsp+0x50], xmm5
000076e4393e1325  vmovaps [rsp+0x60], xmm6
000076e4393e132b  vmovaps [rsp+0x70], xmm8
000076e4393e1331  vmovaps [rsp+0x80], xmm9
000076e4393e133a  vmovaps [rsp+0x90], xmm10
000076e4393e1343  vmovaps [rsp+0xA0], xmm11
000076e4393e134c  vmovaps [rsp+0xB0], xmm12
000076e4393e1355  vmovaps [rsp+0xC0], xmm13
000076e4393e135e  vmovaps [rsp+0xD0], xmm14
000076e4393e1367  vmovaps [rsp+0xE0], xmm15
000076e4393e1370  sub rsp, 0x30
000076e4393e1374  movaps [rsp], xmm7
000076e4393e1378  movaps [rsp+0x10], xmm9
000076e4393e137e  movaps [rsp+0x20], xmm15
000076e4393e1384  lea rdi, [rsp]
000076e4393e1388  mov esi, 0x00
000076e4393e138d  mov rax, 0x63DBDEB43530
000076e4393e1397  call rax
000076e4393e1399  movaps xmm7, [rsp]
000076e4393e139d  add rsp, 0x30
000076e4393e13a1  vmovaps xmm0, [rsp]
000076e4393e13a6  vmovaps xmm1, [rsp+0x10]
000076e4393e13ac  vmovaps xmm2, [rsp+0x20]
000076e4393e13b2  vmovaps xmm3, [rsp+0x30]
000076e4393e13b8  vmovaps xmm4, [rsp+0x40]
000076e4393e13be  vmovaps xmm5, [rsp+0x50]
000076e4393e13c4  vmovaps xmm6, [rsp+0x60]
000076e4393e13ca  vmovaps xmm8, [rsp+0x70]
000076e4393e13d0  vmovaps xmm9, [rsp+0x80]
000076e4393e13d9  vmovaps xmm10, [rsp+0x90]
000076e4393e13e2  vmovaps xmm11, [rsp+0xA0]
000076e4393e13eb  vmovaps xmm12, [rsp+0xB0]
000076e4393e13f4  vmovaps xmm13, [rsp+0xC0]
000076e4393e13fd  vmovaps xmm14, [rsp+0xD0]
000076e4393e1406  vmovaps xmm15, [rsp+0xE0]
000076e4393e140f  add rsp, 0xF0
000076e4393e1416  pop r11
000076e4393e1418  pop r10
000076e4393e141a  pop r9
000076e4393e141c  pop r8
000076e4393e141e  pop rsi
000076e4393e141f  pop rdi
000076e4393e1420  pop rdx
000076e4393e1421  pop rcx
000076e4393e1422  pop rax
000076e4393e1423  add rsp, 0x08
000076e4393e1427  jmp 0x000076E4393DC7B4
000076e4393e142c  sub rsp, 0x08
000076e4393e1430  push rax
000076e4393e1431  push rcx
000076e4393e1432  push rdx
000076e4393e1433  push rdi
000076e4393e1434  push rsi
000076e4393e1435  push r8
000076e4393e1437  push r9
000076e4393e1439  push r10
000076e4393e143b  push r11
000076e4393e143d  sub rsp, 0xF0
000076e4393e1444  vmovaps [rsp], xmm0
000076e4393e1449  vmovaps [rsp+0x10], xmm1
000076e4393e144f  vmovaps [rsp+0x20], xmm2
000076e4393e1455  vmovaps [rsp+0x30], xmm3
000076e4393e145b  vmovaps [rsp+0x40], xmm4
000076e4393e1461  vmovaps [rsp+0x50], xmm5
000076e4393e1467  vmovaps [rsp+0x60], xmm6
000076e4393e146d  vmovaps [rsp+0x70], xmm7
000076e4393e1473  vmovaps [rsp+0x80], xmm8
000076e4393e147c  vmovaps [rsp+0x90], xmm10
000076e4393e1485  vmovaps [rsp+0xA0], xmm11
000076e4393e148e  vmovaps [rsp+0xB0], xmm12
000076e4393e1497  vmovaps [rsp+0xC0], xmm13
000076e4393e14a0  vmovaps [rsp+0xD0], xmm14
000076e4393e14a9  vmovaps [rsp+0xE0], xmm15
000076e4393e14b2  sub rsp, 0x30
000076e4393e14b6  movaps [rsp], xmm9
000076e4393e14bb  movaps [rsp+0x10], xmm13
000076e4393e14c1  movaps [rsp+0x20], xmm15
000076e4393e14c7  lea rdi, [rsp]
000076e4393e14cb  mov esi, 0x00
000076e4393e14d0  mov rax, 0x63DBDEB43530
000076e4393e14da  call rax
000076e4393e14dc  movaps xmm9, [rsp]
000076e4393e14e1  add rsp, 0x30
000076e4393e14e5  vmovaps xmm0, [rsp]
000076e4393e14ea  vmovaps xmm1, [rsp+0x10]
000076e4393e14f0  vmovaps xmm2, [rsp+0x20]
000076e4393e14f6  vmovaps xmm3, [rsp+0x30]
000076e4393e14fc  vmovaps xmm4, [rsp+0x40]
000076e4393e1502  vmovaps xmm5, [rsp+0x50]
000076e4393e1508  vmovaps xmm6, [rsp+0x60]
000076e4393e150e  vmovaps xmm7, [rsp+0x70]
000076e4393e1514  vmovaps xmm8, [rsp+0x80]
000076e4393e151d  vmovaps xmm10, [rsp+0x90]
000076e4393e1526  vmovaps xmm11, [rsp+0xA0]
000076e4393e152f  vmovaps xmm12, [rsp+0xB0]
000076e4393e1538  vmovaps xmm13, [rsp+0xC0]
000076e4393e1541  vmovaps xmm14, [rsp+0xD0]
000076e4393e154a  vmovaps xmm15, [rsp+0xE0]
000076e4393e1553  add rsp, 0xF0
000076e4393e155a  pop r11
000076e4393e155c  pop r10
000076e4393e155e  pop r9
000076e4393e1560  pop r8
000076e4393e1562  pop rsi
000076e4393e1563  pop rdi
000076e4393e1564  pop rdx
000076e4393e1565  pop rcx
000076e4393e1566  pop rax
000076e4393e1567  add rsp, 0x08
000076e4393e156b  jmp 0x000076E4393DC7E2
000076e4393e1570  sub rsp, 0x08
000076e4393e1574  push rax
000076e4393e1575  push rcx
000076e4393e1576  push rdx
000076e4393e1577  push rdi
000076e4393e1578  push rsi
000076e4393e1579  push r8
000076e4393e157b  push r9
000076e4393e157d  push r10
000076e4393e157f  push r11
000076e4393e1581  sub rsp, 0xF0
000076e4393e1588  vmovaps [rsp], xmm0
000076e4393e158d  vmovaps [rsp+0x10], xmm1
000076e4393e1593  vmovaps [rsp+0x20], xmm2
000076e4393e1599  vmovaps [rsp+0x30], xmm3
000076e4393e159f  vmovaps [rsp+0x40], xmm4
000076e4393e15a5  vmovaps [rsp+0x50], xmm5
000076e4393e15ab  vmovaps [rsp+0x60], xmm6
000076e4393e15b1  vmovaps [rsp+0x70], xmm7
000076e4393e15b7  vmovaps [rsp+0x80], xmm8
000076e4393e15c0  vmovaps [rsp+0x90], xmm9
000076e4393e15c9  vmovaps [rsp+0xA0], xmm10
000076e4393e15d2  vmovaps [rsp+0xB0], xmm11
000076e4393e15db  vmovaps [rsp+0xC0], xmm12
000076e4393e15e4  vmovaps [rsp+0xD0], xmm13
000076e4393e15ed  vmovaps [rsp+0xE0], xmm14
000076e4393e15f6  sub rsp, 0x30
000076e4393e15fa  movaps [rsp], xmm15
000076e4393e15ff  movaps [rsp+0x10], xmm11
000076e4393e1605  movaps [rsp+0x20], xmm12
000076e4393e160b  lea rdi, [rsp]
000076e4393e160f  mov esi, 0x00
000076e4393e1614  mov rax, 0x63DBDEB43530
000076e4393e161e  call rax
000076e4393e1620  movaps xmm15, [rsp]
000076e4393e1625  add rsp, 0x30
000076e4393e1629  vmovaps xmm0, [rsp]
000076e4393e162e  vmovaps xmm1, [rsp+0x10]
000076e4393e1634  vmovaps xmm2, [rsp+0x20]
000076e4393e163a  vmovaps xmm3, [rsp+0x30]
000076e4393e1640  vmovaps xmm4, [rsp+0x40]
000076e4393e1646  vmovaps xmm5, [rsp+0x50]
000076e4393e164c  vmovaps xmm6, [rsp+0x60]
000076e4393e1652  vmovaps xmm7, [rsp+0x70]
000076e4393e1658  vmovaps xmm8, [rsp+0x80]
000076e4393e1661  vmovaps xmm9, [rsp+0x90]
000076e4393e166a  vmovaps xmm10, [rsp+0xA0]
000076e4393e1673  vmovaps xmm11, [rsp+0xB0]
000076e4393e167c  vmovaps xmm12, [rsp+0xC0]
000076e4393e1685  vmovaps xmm13, [rsp+0xD0]
000076e4393e168e  vmovaps xmm14, [rsp+0xE0]
000076e4393e1697  add rsp, 0xF0
000076e4393e169e  pop r11
000076e4393e16a0  pop r10
000076e4393e16a2  pop r9
000076e4393e16a4  pop r8
000076e4393e16a6  pop rsi
000076e4393e16a7  pop rdi
000076e4393e16a8  pop rdx
000076e4393e16a9  pop rcx
000076e4393e16aa  pop rax
000076e4393e16ab  add rsp, 0x08
000076e4393e16af  jmp 0x000076E4393DC7FD
000076e4393e16b4  sub rsp, 0x08
000076e4393e16b8  push rax
000076e4393e16b9  push rcx
000076e4393e16ba  push rdx
000076e4393e16bb  push rdi
000076e4393e16bc  push rsi
000076e4393e16bd  push r8
000076e4393e16bf  push r9
000076e4393e16c1  push r10
000076e4393e16c3  push r11
000076e4393e16c5  sub rsp, 0xF0
000076e4393e16cc  vmovaps [rsp], xmm0
000076e4393e16d1  vmovaps [rsp+0x10], xmm1
000076e4393e16d7  vmovaps [rsp+0x20], xmm2
000076e4393e16dd  vmovaps [rsp+0x30], xmm3
000076e4393e16e3  vmovaps [rsp+0x40], xmm4
000076e4393e16e9  vmovaps [rsp+0x50], xmm5
000076e4393e16ef  vmovaps [rsp+0x60], xmm6
000076e4393e16f5  vmovaps [rsp+0x70], xmm7
000076e4393e16fb  vmovaps [rsp+0x80], xmm8
000076e4393e1704  vmovaps [rsp+0x90], xmm9
000076e4393e170d  vmovaps [rsp+0xA0], xmm10
000076e4393e1716  vmovaps [rsp+0xB0], xmm11
000076e4393e171f  vmovaps [rsp+0xC0], xmm12
000076e4393e1728  vmovaps [rsp+0xD0], xmm14
000076e4393e1731  vmovaps [rsp+0xE0], xmm15
000076e4393e173a  sub rsp, 0x30
000076e4393e173e  movaps [rsp], xmm13
000076e4393e1743  movaps [rsp+0x10], xmm10
000076e4393e1749  movaps [rsp+0x20], xmm14
000076e4393e174f  lea rdi, [rsp]
000076e4393e1753  mov esi, 0x00
000076e4393e1758  mov rax, 0x63DBDEB43530
000076e4393e1762  call rax
000076e4393e1764  movaps xmm13, [rsp]
000076e4393e1769  add rsp, 0x30
000076e4393e176d  vmovaps xmm0, [rsp]
000076e4393e1772  vmovaps xmm1, [rsp+0x10]
000076e4393e1778  vmovaps xmm2, [rsp+0x20]
000076e4393e177e  vmovaps xmm3, [rsp+0x30]
000076e4393e1784  vmovaps xmm4, [rsp+0x40]
000076e4393e178a  vmovaps xmm5, [rsp+0x50]
000076e4393e1790  vmovaps xmm6, [rsp+0x60]
000076e4393e1796  vmovaps xmm7, [rsp+0x70]
000076e4393e179c  vmovaps xmm8, [rsp+0x80]
000076e4393e17a5  vmovaps xmm9, [rsp+0x90]
000076e4393e17ae  vmovaps xmm10, [rsp+0xA0]
000076e4393e17b7  vmovaps xmm11, [rsp+0xB0]
000076e4393e17c0  vmovaps xmm12, [rsp+0xC0]
000076e4393e17c9  vmovaps xmm14, [rsp+0xD0]
000076e4393e17d2  vmovaps xmm15, [rsp+0xE0]
000076e4393e17db  add rsp, 0xF0
000076e4393e17e2  pop r11
000076e4393e17e4  pop r10
000076e4393e17e6  pop r9
000076e4393e17e8  pop r8
000076e4393e17ea  pop rsi
000076e4393e17eb  pop rdi
000076e4393e17ec  pop rdx
000076e4393e17ed  pop rcx
000076e4393e17ee  pop rax
000076e4393e17ef  add rsp, 0x08
000076e4393e17f3  jmp 0x000076E4393DC820
000076e4393e17f8  sub rsp, 0x08
000076e4393e17fc  push rax
000076e4393e17fd  push rcx
000076e4393e17fe  push rdx
000076e4393e17ff  push rdi
000076e4393e1800  push rsi
000076e4393e1801  push r8
000076e4393e1803  push r9
000076e4393e1805  push r10
000076e4393e1807  push r11
000076e4393e1809  sub rsp, 0xF0
000076e4393e1810  vmovaps [rsp], xmm0
000076e4393e1815  vmovaps [rsp+0x10], xmm1
000076e4393e181b  vmovaps [rsp+0x20], xmm2
000076e4393e1821  vmovaps [rsp+0x30], xmm3
000076e4393e1827  vmovaps [rsp+0x40], xmm4
000076e4393e182d  vmovaps [rsp+0x50], xmm5
000076e4393e1833  vmovaps [rsp+0x60], xmm6
000076e4393e1839  vmovaps [rsp+0x70], xmm7
000076e4393e183f  vmovaps [rsp+0x80], xmm8
000076e4393e1848  vmovaps [rsp+0x90], xmm9
000076e4393e1851  vmovaps [rsp+0xA0], xmm10
000076e4393e185a  vmovaps [rsp+0xB0], xmm11
000076e4393e1863  vmovaps [rsp+0xC0], xmm12
000076e4393e186c  vmovaps [rsp+0xD0], xmm13
000076e4393e1875  vmovaps [rsp+0xE0], xmm15
000076e4393e187e  sub rsp, 0x30
000076e4393e1882  movaps [rsp], xmm14
000076e4393e1887  movaps [rsp+0x10], xmm1
000076e4393e188c  movaps [rsp+0x20], xmm7
000076e4393e1891  lea rdi, [rsp]
000076e4393e1895  mov esi, 0x00
000076e4393e189a  mov rax, 0x63DBDEB43530
000076e4393e18a4  call rax
000076e4393e18a6  movaps xmm14, [rsp]
000076e4393e18ab  add rsp, 0x30
000076e4393e18af  vmovaps xmm0, [rsp]
000076e4393e18b4  vmovaps xmm1, [rsp+0x10]
000076e4393e18ba  vmovaps xmm2, [rsp+0x20]
000076e4393e18c0  vmovaps xmm3, [rsp+0x30]
000076e4393e18c6  vmovaps xmm4, [rsp+0x40]
000076e4393e18cc  vmovaps xmm5, [rsp+0x50]
000076e4393e18d2  vmovaps xmm6, [rsp+0x60]
000076e4393e18d8  vmovaps xmm7, [rsp+0x70]
000076e4393e18de  vmovaps xmm8, [rsp+0x80]
000076e4393e18e7  vmovaps xmm9, [rsp+0x90]
000076e4393e18f0  vmovaps xmm10, [rsp+0xA0]
000076e4393e18f9  vmovaps xmm11, [rsp+0xB0]
000076e4393e1902  vmovaps xmm12, [rsp+0xC0]
000076e4393e190b  vmovaps xmm13, [rsp+0xD0]
000076e4393e1914  vmovaps xmm15, [rsp+0xE0]
000076e4393e191d  add rsp, 0xF0
000076e4393e1924  pop r11
000076e4393e1926  pop r10
000076e4393e1928  pop r9
000076e4393e192a  pop r8
000076e4393e192c  pop rsi
000076e4393e192d  pop rdi
000076e4393e192e  pop rdx
000076e4393e192f  pop rcx
000076e4393e1930  pop rax
000076e4393e1931  add rsp, 0x08
000076e4393e1935  jmp 0x000076E4393DC843
000076e4393e193a  sub rsp, 0x08
000076e4393e193e  push rax
000076e4393e193f  push rcx
000076e4393e1940  push rdx
000076e4393e1941  push rdi
000076e4393e1942  push rsi
000076e4393e1943  push r8
000076e4393e1945  push r9
000076e4393e1947  push r10
000076e4393e1949  push r11
000076e4393e194b  sub rsp, 0xF0
000076e4393e1952  vmovaps [rsp], xmm0
000076e4393e1957  vmovaps [rsp+0x10], xmm2
000076e4393e195d  vmovaps [rsp+0x20], xmm3
000076e4393e1963  vmovaps [rsp+0x30], xmm4
000076e4393e1969  vmovaps [rsp+0x40], xmm5
000076e4393e196f  vmovaps [rsp+0x50], xmm6
000076e4393e1975  vmovaps [rsp+0x60], xmm7
000076e4393e197b  vmovaps [rsp+0x70], xmm8
000076e4393e1981  vmovaps [rsp+0x80], xmm9
000076e4393e198a  vmovaps [rsp+0x90], xmm10
000076e4393e1993  vmovaps [rsp+0xA0], xmm11
000076e4393e199c  vmovaps [rsp+0xB0], xmm12
000076e4393e19a5  vmovaps [rsp+0xC0], xmm13
000076e4393e19ae  vmovaps [rsp+0xD0], xmm14
000076e4393e19b7  vmovaps [rsp+0xE0], xmm15
000076e4393e19c0  sub rsp, 0x30
000076e4393e19c4  movaps [rsp], xmm1
000076e4393e19c8  movaps [rsp+0x10], xmm8
000076e4393e19ce  movaps [rsp+0x20], xmm9
000076e4393e19d4  lea rdi, [rsp]
000076e4393e19d8  mov esi, 0x00
000076e4393e19dd  mov rax, 0x63DBDEB43530
000076e4393e19e7  call rax
000076e4393e19e9  movaps xmm1, [rsp]
000076e4393e19ed  add rsp, 0x30
000076e4393e19f1  vmovaps xmm0, [rsp]
000076e4393e19f6  vmovaps xmm2, [rsp+0x10]
000076e4393e19fc  vmovaps xmm3, [rsp+0x20]
000076e4393e1a02  vmovaps xmm4, [rsp+0x30]
000076e4393e1a08  vmovaps xmm5, [rsp+0x40]
000076e4393e1a0e  vmovaps xmm6, [rsp+0x50]
000076e4393e1a14  vmovaps xmm7, [rsp+0x60]
000076e4393e1a1a  vmovaps xmm8, [rsp+0x70]
000076e4393e1a20  vmovaps xmm9, [rsp+0x80]
000076e4393e1a29  vmovaps xmm10, [rsp+0x90]
000076e4393e1a32  vmovaps xmm11, [rsp+0xA0]
000076e4393e1a3b  vmovaps xmm12, [rsp+0xB0]
000076e4393e1a44  vmovaps xmm13, [rsp+0xC0]
000076e4393e1a4d  vmovaps xmm14, [rsp+0xD0]
000076e4393e1a56  vmovaps xmm15, [rsp+0xE0]
000076e4393e1a5f  add rsp, 0xF0
000076e4393e1a66  pop r11
000076e4393e1a68  pop r10
000076e4393e1a6a  pop r9
000076e4393e1a6c  pop r8
000076e4393e1a6e  pop rsi
000076e4393e1a6f  pop rdi
000076e4393e1a70  pop rdx
000076e4393e1a71  pop rcx
000076e4393e1a72  pop rax
000076e4393e1a73  add rsp, 0x08
000076e4393e1a77  jmp 0x000076E4393DC865
000076e4393e1a7c  call 0x000076E4392E5940
000076e4393e1a81  jmp 0x000076E4393DC873
000076e4393e1a86  call 0x000076E43920C380
000076e4393e1a8b  jmp 0x000076E4393DC87D
000076e4393e1a90  call 0x000076E43920D600
000076e4393e1a95  jmp 0x000076E4393DC887
000076e4393e1a9a  call 0x000076E4391FF540
000076e4393e1a9f  jmp 0x000076E4393DC891
000076e4393e1aa4  int3
000076e4393e1aa5  nop [rax+rax*1], ax
000076e4393e1aae  nop
000076e4393e1ab0  mov rax, [r15+0xF8]
000076e4393e1ab7  lea r14, [rax+0x140]
000076e4393e1abe  mov r12, [r13+r14*1]
000076e4393e1ac3  mov [r15+0xE8], r12
000076e4393e1aca  lea r14, [rax+0x130]
000076e4393e1ad1  mov r12, [r13+r14*1]
000076e4393e1ad6  lea r14, [rax+0x138]
000076e4393e1add  mov r11, [r13+r14*1]
000076e4393e1ae2  movq xmm1, r12
000076e4393e1ae7  movq xmm15, r11
000076e4393e1aec  movq xmm1, xmm1
000076e4393e1af0  movq xmm1, xmm1
000076e4393e1af4  movaps [r15+0x1A0], xmm1
000076e4393e1afc  movq xmm15, xmm15
000076e4393e1b01  movq xmm15, xmm15
000076e4393e1b06  movaps [r15+0x190], xmm15
000076e4393e1b0e  lea r14, [rax+0x120]
000076e4393e1b15  mov r12, [r13+r14*1]
000076e4393e1b1a  lea r14, [rax+0x128]
000076e4393e1b21  mov r11, [r13+r14*1]
000076e4393e1b26  movq xmm1, r12
000076e4393e1b2b  movq xmm15, r11
000076e4393e1b30  movq xmm1, xmm1
000076e4393e1b34  movq xmm1, xmm1
000076e4393e1b38  movaps [r15+0x1C0], xmm1
000076e4393e1b40  movq xmm15, xmm15
000076e4393e1b45  movq xmm15, xmm15
000076e4393e1b4a  movaps [r15+0x1B0], xmm15
000076e4393e1b52  lea r14, [rax+0x110]
000076e4393e1b59  mov r12, [r13+r14*1]
000076e4393e1b5e  lea r14, [rax+0x118]
000076e4393e1b65  mov r11, [r13+r14*1]
000076e4393e1b6a  movq xmm1, r12
000076e4393e1b6f  movq xmm15, r11
000076e4393e1b74  movq xmm1, xmm1
000076e4393e1b78  movq xmm1, xmm1
000076e4393e1b7c  movaps [r15+0x1E0], xmm1
000076e4393e1b84  movq xmm15, xmm15
000076e4393e1b89  movq xmm15, xmm15
000076e4393e1b8e  movaps [r15+0x1D0], xmm15
000076e4393e1b96  lea r14, [rax+0x100]
000076e4393e1b9d  mov r12, [r13+r14*1]
000076e4393e1ba2  lea r14, [rax+0x108]
000076e4393e1ba9  mov r11, [r13+r14*1]
000076e4393e1bae  movq xmm1, r12
000076e4393e1bb3  movq xmm15, r11
000076e4393e1bb8  movq xmm1, xmm1
000076e4393e1bbc  movq xmm1, xmm1
000076e4393e1bc0  movaps [r15+0x200], xmm1
000076e4393e1bc8  movq xmm15, xmm15
000076e4393e1bcd  movq xmm15, xmm15
000076e4393e1bd2  movaps [r15+0x1F0], xmm15
000076e4393e1bda  mov qword ptr [r15+0x40], 0x430000
000076e4393e1be2  mov r14d, 0x430510
000076e4393e1be8  mov r12, [r13+r14*1]
000076e4393e1bed  movq xmm1, r12
000076e4393e1bf2  lea r14, [rax+0x150]
000076e4393e1bf9  mov [r15+0xF8], r14
000076e4393e1c00  mov rax, [r15+0x50]
000076e4393e1c04  movups xmm15, [r13+rax*1]
000076e4393e1c0a  movaps [r15+0x120], xmm15
000076e4393e1c12  mov qword ptr [r15+0x48], 0x10
000076e4393e1c1a  xor eax, eax
000076e4393e1c1c  mov r14d, 0x10
000076e4393e1c22  mov r12d, 0x200
000076e4393e1c28  cmp r14, r12
000076e4393e1c2b  cmc
000076e4393e1c2c  lahf
000076e4393e1c2d  seto al
000076e4393e1c30  mov [r15+0x108], eax
000076e4393e1c37  pextrq rax, xmm15, 0x01
000076e4393e1c3e  movq xmm14, rax
000076e4393e1c43  movaps [r15+0x130], xmm14
000076e4393e1c4b  movq rax, xmm1
000076e4393e1c50  movq r14, xmm15
000076e4393e1c55  vmovq xmm1, rax
000076e4393e1c5a  vmovq xmm15, r14
000076e4393e1c5f  movaps xmm13, xmm1
000076e4393e1c63  addsd xmm13, xmm15
000076e4393e1c68  ucomisd xmm13, xmm13
000076e4393e1c6d  jp 0x000076E4393E1D86
000076e4393e1c73  movq xmm13, xmm13
000076e4393e1c78  movq rax, xmm13
000076e4393e1c7d  movq r14, xmm14
000076e4393e1c82  vmovq xmm1, rax
000076e4393e1c87  vmovq xmm15, r14
000076e4393e1c8c  movaps xmm14, xmm1
000076e4393e1c90  addsd xmm14, xmm15
000076e4393e1c95  ucomisd xmm14, xmm14
000076e4393e1c9a  jp 0x000076E4393E1DCE
000076e4393e1ca0  movq xmm14, xmm14
000076e4393e1ca5  movaps [r15+0x110], xmm14
000076e4393e1cad  mov eax, [r15+0x108]
000076e4393e1cb4  sahf
000076e4393e1cb5  jnz 0x000076E4393E1CE7
000076e4393e1cb7  cmp dword ptr [r15+0x318], 0x00
000076e4393e1cbf  jz 0x000076E4393E1FE0
000076e4393e1cc5  nop [rax+rax*1], ax
000076e4393e1cce  nop [rax+rax*1], eax
000076e4393e1cd6  mov eax, 0x410490
000076e4393e1cdb  mov [r15+0x100], rax
000076e4393e1ce2  jmp 0x000076E4391FE110
000076e4393e1ce7  cmp dword ptr [r15+0x318], 0x00
000076e4393e1cef  jz 0x000076E4393E1E20
000076e4393e1cf5  nop [rax+rax*1], ax
000076e4393e1cfe  nop [rax+rax*1], eax
000076e4393e1d06  mov eax, 0x410474
000076e4393e1d0b  mov [r15+0x100], rax
000076e4393e1d12  jmp 0x000076E4391FE110
000076e4393e1d17  int3
000076e4393e1d18  call 0x000076E4392E27E0
000076e4393e1d1d  jmp 0x000076E4393E1AC3
000076e4393e1d22  call 0x000076E4392E27E0
000076e4393e1d27  jmp 0x000076E4393E1AD6
000076e4393e1d2c  call 0x000076E4392E1570
000076e4393e1d31  jmp 0x000076E4393E1AE2
000076e4393e1d36  call 0x000076E4392E27E0
000076e4393e1d3b  jmp 0x000076E4393E1B1A
000076e4393e1d40  call 0x000076E4392E1570
000076e4393e1d45  jmp 0x000076E4393E1B26
000076e4393e1d4a  call 0x000076E4392E27E0
000076e4393e1d4f  jmp 0x000076E4393E1B5E
000076e4393e1d54  call 0x000076E4392E1570
000076e4393e1d59  jmp 0x000076E4393E1B6A
000076e4393e1d5e  call 0x000076E4392E27E0
000076e4393e1d63  jmp 0x000076E4393E1BA2
000076e4393e1d68  call 0x000076E4392E1570
000076e4393e1d6d  jmp 0x000076E4393E1BAE
000076e4393e1d72  call 0x000076E4392E27E0
000076e4393e1d77  jmp 0x000076E4393E1BED
000076e4393e1d7c  call 0x000076E43920E760
000076e4393e1d81  jmp 0x000076E4393E1C0A
000076e4393e1d86  ucomisd xmm1, xmm15
000076e4393e1d8b  jp 0x000076E4393E1D9A
000076e4393e1d8d  movaps xmm13, [0x000076E438FFE060]
000076e4393e1d95  jmp 0x000076E4393E1C73
000076e4393e1d9a  vxorps xmm0, xmm1, xmm15
000076e4393e1d9f  pextrw eax, xmm0, 0x03
000076e4393e1da4  and eax, 0x7FF8
000076e4393e1da9  cmp eax, 0x08
000076e4393e1dac  jnz 0x000076E4393E1C73
000076e4393e1db2  movq rax, xmm15
000076e4393e1db7  shl rax, 0x0D
000076e4393e1dbb  jbe 0x000076E4393E1C73
000076e4393e1dc1  vorps xmm13, xmm15, [0x000076E438FFE070]
000076e4393e1dc9  jmp 0x000076E4393E1C73
000076e4393e1dce  ucomisd xmm1, xmm15
000076e4393e1dd3  jp 0x000076E4393E1DE2
000076e4393e1dd5  movaps xmm14, [0x000076E438FFE060]
000076e4393e1ddd  jmp 0x000076E4393E1CA0
000076e4393e1de2  vxorps xmm0, xmm1, xmm15
000076e4393e1de7  pextrw eax, xmm0, 0x03
000076e4393e1dec  and eax, 0x7FF8
000076e4393e1df1  cmp eax, 0x08
000076e4393e1df4  jnz 0x000076E4393E1CA0
000076e4393e1dfa  movq rax, xmm15
000076e4393e1dff  shl rax, 0x0D
000076e4393e1e03  jbe 0x000076E4393E1CA0
000076e4393e1e09  vorps xmm14, xmm15, [0x000076E438FFE070]
000076e4393e1e11  jmp 0x000076E4393E1CA0
000076e4393e1e16  int3
000076e4393e1e17  nop [rax+rax*1], ax
000076e4393e1e20  mov rax, [r15+0x48]
000076e4393e1e24  mov r14, [r15+0x50]
000076e4393e1e28  lea r12, [r14+rax*1]
000076e4393e1e2c  movups xmm1, [r13+r12*1]
000076e4393e1e32  movaps [r15+0x120], xmm1
000076e4393e1e3a  lea r14, [rax+0x10]
000076e4393e1e3e  mov [r15+0x48], r14
000076e4393e1e42  xor eax, eax
000076e4393e1e44  mov r12d, 0x200
000076e4393e1e4a  cmp r14, r12
000076e4393e1e4d  cmc
000076e4393e1e4e  lahf
000076e4393e1e4f  seto al
000076e4393e1e52  mov [r15+0x108], eax
000076e4393e1e59  pextrq rax, xmm1, 0x01
000076e4393e1e60  movq xmm15, rax
000076e4393e1e65  movaps [r15+0x130], xmm15
000076e4393e1e6d  movaps xmm14, [r15+0x110]
000076e4393e1e75  movq rax, xmm14
000076e4393e1e7a  movq r14, xmm1
000076e4393e1e7f  vmovq xmm1, rax
000076e4393e1e84  vmovq xmm14, r14
000076e4393e1e89  movaps xmm13, xmm1
000076e4393e1e8d  addsd xmm13, xmm14
000076e4393e1e92  ucomisd xmm13, xmm13
000076e4393e1e97  jp 0x000076E4393E1F4C
000076e4393e1e9d  movq xmm13, xmm13
000076e4393e1ea2  movq rax, xmm13
000076e4393e1ea7  movq r14, xmm15
000076e4393e1eac  vmovq xmm1, rax
000076e4393e1eb1  vmovq xmm15, r14
000076e4393e1eb6  movaps xmm14, xmm1
000076e4393e1eba  addsd xmm14, xmm15
000076e4393e1ebf  ucomisd xmm14, xmm14
000076e4393e1ec4  jp 0x000076E4393E1F94
000076e4393e1eca  movq xmm14, xmm14
000076e4393e1ecf  movaps [r15+0x110], xmm14
000076e4393e1ed7  mov eax, [r15+0x108]
000076e4393e1ede  sahf
000076e4393e1edf  jnz 0x000076E4393E1F11
000076e4393e1ee1  cmp dword ptr [r15+0x318], 0x00
000076e4393e1ee9  jz 0x000076E4393E1FE0
000076e4393e1eef  nop [rax+rax*1], ax
000076e4393e1ef8  nop [rax+rax*1], eax
000076e4393e1f00  mov eax, 0x410490
000076e4393e1f05  mov [r15+0x100], rax
000076e4393e1f0c  jmp 0x000076E4391FE110
000076e4393e1f11  cmp dword ptr [r15+0x318], 0x00
000076e4393e1f19  jz 0x000076E4393E1E20
000076e4393e1f1f  nop [rax+rax*1], ax
000076e4393e1f28  nop [rax+rax*1], eax
000076e4393e1f30  mov eax, 0x410474
000076e4393e1f35  mov [r15+0x100], rax
000076e4393e1f3c  jmp 0x000076E4391FE110
000076e4393e1f41  int3
000076e4393e1f42  call 0x000076E4392B52F0
000076e4393e1f47  jmp 0x000076E4393E1E32
000076e4393e1f4c  ucomisd xmm1, xmm14
000076e4393e1f51  jp 0x000076E4393E1F60
000076e4393e1f53  movaps xmm13, [0x000076E438FFE060]
000076e4393e1f5b  jmp 0x000076E4393E1E9D
000076e4393e1f60  vxorps xmm0, xmm1, xmm14
000076e4393e1f65  pextrw eax, xmm0, 0x03
000076e4393e1f6a  and eax, 0x7FF8
000076e4393e1f6f  cmp eax, 0x08
000076e4393e1f72  jnz 0x000076E4393E1E9D
000076e4393e1f78  movq rax, xmm14
000076e4393e1f7d  shl rax, 0x0D
000076e4393e1f81  jbe 0x000076E4393E1E9D
000076e4393e1f87  vorps xmm13, xmm14, [0x000076E438FFE070]
000076e4393e1f8f  jmp 0x000076E4393E1E9D
000076e4393e1f94  ucomisd xmm1, xmm15
000076e4393e1f99  jp 0x000076E4393E1FA8
000076e4393e1f9b  movaps xmm14, [0x000076E438FFE060]
000076e4393e1fa3  jmp 0x000076E4393E1ECA
000076e4393e1fa8  vxorps xmm0, xmm1, xmm15
000076e4393e1fad  pextrw eax, xmm0, 0x03
000076e4393e1fb2  and eax, 0x7FF8
000076e4393e1fb7  cmp eax, 0x08
000076e4393e1fba  jnz 0x000076E4393E1ECA
000076e4393e1fc0  movq rax, xmm15
000076e4393e1fc5  shl rax, 0x0D
000076e4393e1fc9  jbe 0x000076E4393E1ECA
000076e4393e1fcf  vorps xmm14, xmm15, [0x000076E438FFE070]
000076e4393e1fd7  jmp 0x000076E4393E1ECA
000076e4393e1fdc  int3
000076e4393e1fdd  nop [rax], eax
000076e4393e1fe0  mov rax, [r15+0x40]
000076e4393e1fe4  lea r14, [rax+0x510]
000076e4393e1feb  movaps xmm1, [r15+0x110]
000076e4393e1ff3  movq rax, xmm1
000076e4393e1ff8  mov [r13+r14*1], rax
000076e4393e1ffd  mov rax, [r15+0xF0]
000076e4393e2004  mov [r15+0x100], rax
000076e4393e200b  jmp 0x000076E4393CE5C0
000076e4393e2010  int3
000076e4393e2011  call 0x000076E4392D5EB0
000076e4393e2016  jmp 0x000076E4393E1FFD
000076e4393e201b  int3
000076e4393e201c  nop [rax], eax
000076e4393e2020  mov qword ptr [r15+0x100], 0x04
000076e4393e202b  mov esi, 0x00
000076e4393e2030  mov edx, 0x09
000076e4393e2035  mov rdi, 0x7FFD4C735C60
000076e4393e203f  mov rax, 0x63DBDE9D6970
000076e4393e2049  call rax
000076e4393e204b  cmp dword ptr [r15+0x318], 0x00
000076e4393e2053  jnz 0x000076E4391FE110
000076e4393e2059  jmp 0x000076E4391FE0A0
000076e4393e205e  int3
000076e4393e205f  int3
