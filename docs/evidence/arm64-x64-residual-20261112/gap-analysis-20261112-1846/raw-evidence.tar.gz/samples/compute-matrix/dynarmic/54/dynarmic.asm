00007d20d97ce69b  nop [rax+rax*1], eax
00007d20d97ce6a0  vmovaps xmm1, [0x00007D20D93FE010]
00007d20d97ce6a8  movq xmm1, xmm1
00007d20d97ce6ac  movaps [r15+0x110], xmm1
00007d20d97ce6b4  vmovaps xmm1, [0x00007D20D93FE020]
00007d20d97ce6bc  movq xmm1, xmm1
00007d20d97ce6c0  movaps [r15+0x120], xmm1
00007d20d97ce6c8  mov eax, 0x4204C0
00007d20d97ce6cd  mov r14, [r13+rax*1]
00007d20d97ce6d2  movq xmm1, r14
00007d20d97ce6d7  movaps [r15+0x130], xmm1
00007d20d97ce6df  vmovaps xmm1, [0x00007D20D93FE030]
00007d20d97ce6e7  vpbroadcastq xmm1, xmm1
00007d20d97ce6ec  movaps [r15+0x140], xmm1
00007d20d97ce6f4  mov qword ptr [r15+0x40], 0x02
00007d20d97ce6fc  vmovaps xmm15, [0x00007D20D93FE040]
00007d20d97ce704  movq xmm15, xmm15
00007d20d97ce709  movaps [r15+0x150], xmm15
00007d20d97ce711  mov qword ptr [r15+0x58], 0x420000
00007d20d97ce719  vmovaps xmm15, [0x00007D20D93FE050]
00007d20d97ce721  vpbroadcastq xmm15, xmm15
00007d20d97ce726  movaps [r15+0x160], xmm15
00007d20d97ce72e  mov rax, [r15+0x40]
00007d20d97ce732  vmovq xmm14, rax
00007d20d97ce737  vpbroadcastq xmm14, xmm14
00007d20d97ce73c  movaps [r15+0x170], xmm14
00007d20d97ce744  mov eax, 0x4204D0
00007d20d97ce749  movups xmm13, [r13+rax*1]
00007d20d97ce74f  mov qword ptr [r15+0x40], 0x430518
00007d20d97ce757  mov qword ptr [r15+0x50], 0x430720
00007d20d97ce75f  vpmovqd xmm12, xmm13
00007d20d97ce765  pxor xmm11, xmm11
00007d20d97ce76a  punpcklqdq xmm12, xmm11
00007d20d97ce76f  movaps [r15+0x210], xmm12
00007d20d97ce777  movq xmm12, qword ptr [r15+0x120]
00007d20d97ce780  movq xmm11, qword ptr [r15+0x130]
00007d20d97ce789  psubd xmm12, xmm11
00007d20d97ce78e  movq xmm12, xmm12
00007d20d97ce793  paddq xmm13, xmm14
00007d20d97ce798  movaps [r15+0x180], xmm13
00007d20d97ce7a0  movq xmm14, qword ptr [r15+0x150]
00007d20d97ce7a9  paddd xmm11, xmm14
00007d20d97ce7ae  movq xmm11, xmm11
00007d20d97ce7b3  movq xmm11, xmm11
00007d20d97ce7b8  movaps [r15+0x130], xmm11
00007d20d97ce7c0  pmovzxdq xmm12, xmm12
00007d20d97ce7c6  psllq xmm12, 0x00
00007d20d97ce7cc  movq xmm14, qword ptr [r15+0x210]
00007d20d97ce7d5  movq xmm13, qword ptr [r15+0x110]
00007d20d97ce7de  paddd xmm14, xmm13
00007d20d97ce7e3  movq xmm14, xmm14
00007d20d97ce7e8  vcvtuqq2pd xmm12, xmm12
00007d20d97ce7ee  pmovzxdq xmm14, xmm14
00007d20d97ce7f4  psllq xmm14, 0x00
00007d20d97ce7fa  vcvtuqq2pd xmm14, xmm14
00007d20d97ce800  movaps xmm13, xmm12
00007d20d97ce804  mulpd xmm13, xmm1
00007d20d97ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007d20d97ce80f  ptest xmm11, xmm11
00007d20d97ce815  jnz 0x00007D20D97CE8FF
00007d20d97ce81b  movaps [r15+0x220], xmm13
00007d20d97ce823  mov eax, 0x430720
00007d20d97ce828  movups [r13+rax*1], xmm13
00007d20d97ce82e  movaps xmm1, xmm14
00007d20d97ce832  mulpd xmm1, xmm15
00007d20d97ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007d20d97ce83c  ptest xmm13, xmm13
00007d20d97ce842  jnz 0x00007D20D97CEA4C
00007d20d97ce848  movaps [r15+0x210], xmm1
00007d20d97ce850  mov eax, 0x430518
00007d20d97ce855  movups [r13+rax*1], xmm1
00007d20d97ce85b  mov qword ptr [r15+0x48], 0x10
00007d20d97ce863  xor eax, eax
00007d20d97ce865  mov r14d, 0x10
00007d20d97ce86b  mov r12d, 0x200
00007d20d97ce871  cmp r14, r12
00007d20d97ce874  cmc
00007d20d97ce875  lahf
00007d20d97ce876  seto al
00007d20d97ce879  mov [r15+0x108], eax
00007d20d97ce880  mov eax, [r15+0x108]
00007d20d97ce887  sahf
00007d20d97ce888  jnz 0x00007D20D97CE8BA
00007d20d97ce88a  cmp dword ptr [r15+0x318], 0x00
00007d20d97ce892  jz 0x00007D20D97CEFF0
00007d20d97ce898  nop [rax+rax*1], ax
00007d20d97ce8a1  nop [rax+rax*1], eax
00007d20d97ce8a9  mov eax, 0x4101EC
00007d20d97ce8ae  mov [r15+0x100], rax
00007d20d97ce8b5  jmp 0x00007D20D95FE110
00007d20d97ce8ba  cmp dword ptr [r15+0x318], 0x00
00007d20d97ce8c2  jz 0x00007D20D97CEBA0
00007d20d97ce8c8  nop [rax+rax*1], ax
00007d20d97ce8d1  nop [rax+rax*1], eax
00007d20d97ce8d9  mov eax, 0x4101AC
00007d20d97ce8de  mov [r15+0x100], rax
00007d20d97ce8e5  jmp 0x00007D20D95FE110
00007d20d97ce8ea  int3
00007d20d97ce8eb  call 0x00007D20D960DC20
00007d20d97ce8f0  jmp 0x00007D20D97CE6D2
00007d20d97ce8f5  call 0x00007D20D960C260
00007d20d97ce8fa  jmp 0x00007D20D97CE74F
00007d20d97ce8ff  sub rsp, 0x08
00007d20d97ce903  push rax
00007d20d97ce904  push rcx
00007d20d97ce905  push rdx
00007d20d97ce906  push rdi
00007d20d97ce907  push rsi
00007d20d97ce908  push r8
00007d20d97ce90a  push r9
00007d20d97ce90c  push r10
00007d20d97ce90e  push r11
00007d20d97ce910  sub rsp, 0xF0
00007d20d97ce917  vmovaps [rsp], xmm0
00007d20d97ce91c  vmovaps [rsp+0x10], xmm1
00007d20d97ce922  vmovaps [rsp+0x20], xmm2
00007d20d97ce928  vmovaps [rsp+0x30], xmm3
00007d20d97ce92e  vmovaps [rsp+0x40], xmm4
00007d20d97ce934  vmovaps [rsp+0x50], xmm5
00007d20d97ce93a  vmovaps [rsp+0x60], xmm6
00007d20d97ce940  vmovaps [rsp+0x70], xmm7
00007d20d97ce946  vmovaps [rsp+0x80], xmm8
00007d20d97ce94f  vmovaps [rsp+0x90], xmm9
00007d20d97ce958  vmovaps [rsp+0xA0], xmm10
00007d20d97ce961  vmovaps [rsp+0xB0], xmm11
00007d20d97ce96a  vmovaps [rsp+0xC0], xmm12
00007d20d97ce973  vmovaps [rsp+0xD0], xmm14
00007d20d97ce97c  vmovaps [rsp+0xE0], xmm15
00007d20d97ce985  sub rsp, 0x30
00007d20d97ce989  movaps [rsp], xmm13
00007d20d97ce98e  movaps [rsp+0x10], xmm12
00007d20d97ce994  movaps [rsp+0x20], xmm1
00007d20d97ce999  lea rdi, [rsp]
00007d20d97ce99d  mov esi, 0x00
00007d20d97ce9a2  mov rax, 0x5EFBF4CF6530
00007d20d97ce9ac  call rax
00007d20d97ce9ae  movaps xmm13, [rsp]
00007d20d97ce9b3  add rsp, 0x30
00007d20d97ce9b7  vmovaps xmm0, [rsp]
00007d20d97ce9bc  vmovaps xmm1, [rsp+0x10]
00007d20d97ce9c2  vmovaps xmm2, [rsp+0x20]
00007d20d97ce9c8  vmovaps xmm3, [rsp+0x30]
00007d20d97ce9ce  vmovaps xmm4, [rsp+0x40]
00007d20d97ce9d4  vmovaps xmm5, [rsp+0x50]
00007d20d97ce9da  vmovaps xmm6, [rsp+0x60]
00007d20d97ce9e0  vmovaps xmm7, [rsp+0x70]
00007d20d97ce9e6  vmovaps xmm8, [rsp+0x80]
00007d20d97ce9ef  vmovaps xmm9, [rsp+0x90]
00007d20d97ce9f8  vmovaps xmm10, [rsp+0xA0]
00007d20d97cea01  vmovaps xmm11, [rsp+0xB0]
00007d20d97cea0a  vmovaps xmm12, [rsp+0xC0]
00007d20d97cea13  vmovaps xmm14, [rsp+0xD0]
00007d20d97cea1c  vmovaps xmm15, [rsp+0xE0]
00007d20d97cea25  add rsp, 0xF0
00007d20d97cea2c  pop r11
00007d20d97cea2e  pop r10
00007d20d97cea30  pop r9
00007d20d97cea32  pop r8
00007d20d97cea34  pop rsi
00007d20d97cea35  pop rdi
00007d20d97cea36  pop rdx
00007d20d97cea37  pop rcx
00007d20d97cea38  pop rax
00007d20d97cea39  add rsp, 0x08
00007d20d97cea3d  jmp 0x00007D20D97CE81B
00007d20d97cea42  call 0x00007D20D960C380
00007d20d97cea47  jmp 0x00007D20D97CE82E
00007d20d97cea4c  sub rsp, 0x08
00007d20d97cea50  push rax
00007d20d97cea51  push rcx
00007d20d97cea52  push rdx
00007d20d97cea53  push rdi
00007d20d97cea54  push rsi
00007d20d97cea55  push r8
00007d20d97cea57  push r9
00007d20d97cea59  push r10
00007d20d97cea5b  push r11
00007d20d97cea5d  sub rsp, 0xF0
00007d20d97cea64  vmovaps [rsp], xmm0
00007d20d97cea69  vmovaps [rsp+0x10], xmm2
00007d20d97cea6f  vmovaps [rsp+0x20], xmm3
00007d20d97cea75  vmovaps [rsp+0x30], xmm4
00007d20d97cea7b  vmovaps [rsp+0x40], xmm5
00007d20d97cea81  vmovaps [rsp+0x50], xmm6
00007d20d97cea87  vmovaps [rsp+0x60], xmm7
00007d20d97cea8d  vmovaps [rsp+0x70], xmm8
00007d20d97cea93  vmovaps [rsp+0x80], xmm9
00007d20d97cea9c  vmovaps [rsp+0x90], xmm10
00007d20d97ceaa5  vmovaps [rsp+0xA0], xmm11
00007d20d97ceaae  vmovaps [rsp+0xB0], xmm12
00007d20d97ceab7  vmovaps [rsp+0xC0], xmm13
00007d20d97ceac0  vmovaps [rsp+0xD0], xmm14
00007d20d97ceac9  vmovaps [rsp+0xE0], xmm15
00007d20d97cead2  sub rsp, 0x30
00007d20d97cead6  movaps [rsp], xmm1
00007d20d97ceada  movaps [rsp+0x10], xmm14
00007d20d97ceae0  movaps [rsp+0x20], xmm15
00007d20d97ceae6  lea rdi, [rsp]
00007d20d97ceaea  mov esi, 0x00
00007d20d97ceaef  mov rax, 0x5EFBF4CF6530
00007d20d97ceaf9  call rax
00007d20d97ceafb  movaps xmm1, [rsp]
00007d20d97ceaff  add rsp, 0x30
00007d20d97ceb03  vmovaps xmm0, [rsp]
00007d20d97ceb08  vmovaps xmm2, [rsp+0x10]
00007d20d97ceb0e  vmovaps xmm3, [rsp+0x20]
00007d20d97ceb14  vmovaps xmm4, [rsp+0x30]
00007d20d97ceb1a  vmovaps xmm5, [rsp+0x40]
00007d20d97ceb20  vmovaps xmm6, [rsp+0x50]
00007d20d97ceb26  vmovaps xmm7, [rsp+0x60]
00007d20d97ceb2c  vmovaps xmm8, [rsp+0x70]
00007d20d97ceb32  vmovaps xmm9, [rsp+0x80]
00007d20d97ceb3b  vmovaps xmm10, [rsp+0x90]
00007d20d97ceb44  vmovaps xmm11, [rsp+0xA0]
00007d20d97ceb4d  vmovaps xmm12, [rsp+0xB0]
00007d20d97ceb56  vmovaps xmm13, [rsp+0xC0]
00007d20d97ceb5f  vmovaps xmm14, [rsp+0xD0]
00007d20d97ceb68  vmovaps xmm15, [rsp+0xE0]
00007d20d97ceb71  add rsp, 0xF0
00007d20d97ceb78  pop r11
00007d20d97ceb7a  pop r10
00007d20d97ceb7c  pop r9
00007d20d97ceb7e  pop r8
00007d20d97ceb80  pop rsi
00007d20d97ceb81  pop rdi
00007d20d97ceb82  pop rdx
00007d20d97ceb83  pop rcx
00007d20d97ceb84  pop rax
00007d20d97ceb85  add rsp, 0x08
00007d20d97ceb89  jmp 0x00007D20D97CE848
00007d20d97ceb8e  call 0x00007D20D95FF540
00007d20d97ceb93  jmp 0x00007D20D97CE85B
00007d20d97ceb98  int3
00007d20d97ceb99  nop [rax], eax
00007d20d97ceba0  movaps xmm1, [r15+0x180]
00007d20d97ceba8  vpmovqd xmm15, xmm1
00007d20d97cebae  pxor xmm14, xmm14
00007d20d97cebb3  punpcklqdq xmm15, xmm14
00007d20d97cebb8  movaps [r15+0x210], xmm15
00007d20d97cebc0  movq xmm15, qword ptr [r15+0x120]
00007d20d97cebc9  movq xmm14, qword ptr [r15+0x130]
00007d20d97cebd2  psubd xmm15, xmm14
00007d20d97cebd7  movq xmm15, xmm15
00007d20d97cebdc  movaps xmm13, [r15+0x170]
00007d20d97cebe4  paddq xmm1, xmm13
00007d20d97cebe9  movaps [r15+0x180], xmm1
00007d20d97cebf1  movq xmm1, qword ptr [r15+0x150]
00007d20d97cebfa  paddd xmm14, xmm1
00007d20d97cebff  movq xmm14, xmm14
00007d20d97cec04  movq xmm14, xmm14
00007d20d97cec09  movaps [r15+0x130], xmm14
00007d20d97cec11  pmovzxdq xmm15, xmm15
00007d20d97cec17  psllq xmm15, 0x00
00007d20d97cec1d  movq xmm1, qword ptr [r15+0x210]
00007d20d97cec26  movq xmm14, qword ptr [r15+0x110]
00007d20d97cec2f  paddd xmm1, xmm14
00007d20d97cec34  movq xmm1, xmm1
00007d20d97cec38  vcvtuqq2pd xmm15, xmm15
00007d20d97cec3e  pmovzxdq xmm1, xmm1
00007d20d97cec43  psllq xmm1, 0x00
00007d20d97cec48  vcvtuqq2pd xmm1, xmm1
00007d20d97cec4e  movaps xmm14, [r15+0x140]
00007d20d97cec56  movaps xmm13, xmm15
00007d20d97cec5a  mulpd xmm13, xmm14
00007d20d97cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d20d97cec65  ptest xmm12, xmm12
00007d20d97cec6b  jnz 0x00007D20D97CED4E
00007d20d97cec71  movaps [r15+0x220], xmm13
00007d20d97cec79  mov rax, [r15+0x48]
00007d20d97cec7d  mov r14, [r15+0x50]
00007d20d97cec81  lea r12, [r14+rax*1]
00007d20d97cec85  movups [r13+r12*1], xmm13
00007d20d97cec8b  movaps xmm15, [r15+0x160]
00007d20d97cec93  movaps xmm14, xmm1
00007d20d97cec97  mulpd xmm14, xmm15
00007d20d97cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007d20d97ceca2  ptest xmm13, xmm13
00007d20d97ceca8  jnz 0x00007D20D97CEE9C
00007d20d97cecae  movaps [r15+0x210], xmm14
00007d20d97cecb6  mov r14, [r15+0x40]
00007d20d97cecba  lea r12, [r14+rax*1]
00007d20d97cecbe  movups [r13+r12*1], xmm14
00007d20d97cecc4  lea r14, [rax+0x10]
00007d20d97cecc8  mov [r15+0x48], r14
00007d20d97ceccc  xor eax, eax
00007d20d97cecce  mov r12d, 0x200
00007d20d97cecd4  cmp r14, r12
00007d20d97cecd7  cmc
00007d20d97cecd8  lahf
00007d20d97cecd9  seto al
00007d20d97cecdc  mov [r15+0x108], eax
00007d20d97cece3  mov eax, [r15+0x108]
00007d20d97cecea  sahf
00007d20d97ceceb  jnz 0x00007D20D97CED1D
00007d20d97ceced  cmp dword ptr [r15+0x318], 0x00
00007d20d97cecf5  jz 0x00007D20D97CEFF0
00007d20d97cecfb  nop [rax+rax*1], ax
00007d20d97ced04  nop [rax+rax*1], eax
00007d20d97ced0c  mov eax, 0x4101EC
00007d20d97ced11  mov [r15+0x100], rax
00007d20d97ced18  jmp 0x00007D20D95FE110
00007d20d97ced1d  cmp dword ptr [r15+0x318], 0x00
00007d20d97ced25  jz 0x00007D20D97CEBA0
00007d20d97ced2b  nop [rax+rax*1], ax
00007d20d97ced34  nop [rax+rax*1], eax
00007d20d97ced3c  mov eax, 0x4101AC
00007d20d97ced41  mov [r15+0x100], rax
00007d20d97ced48  jmp 0x00007D20D95FE110
00007d20d97ced4d  int3
00007d20d97ced4e  sub rsp, 0x08
00007d20d97ced52  push rax
00007d20d97ced53  push rcx
00007d20d97ced54  push rdx
00007d20d97ced55  push rdi
00007d20d97ced56  push rsi
00007d20d97ced57  push r8
00007d20d97ced59  push r9
00007d20d97ced5b  push r10
00007d20d97ced5d  push r11
00007d20d97ced5f  sub rsp, 0xF0
00007d20d97ced66  vmovaps [rsp], xmm0
00007d20d97ced6b  vmovaps [rsp+0x10], xmm1
00007d20d97ced71  vmovaps [rsp+0x20], xmm2
00007d20d97ced77  vmovaps [rsp+0x30], xmm3
00007d20d97ced7d  vmovaps [rsp+0x40], xmm4
00007d20d97ced83  vmovaps [rsp+0x50], xmm5
00007d20d97ced89  vmovaps [rsp+0x60], xmm6
00007d20d97ced8f  vmovaps [rsp+0x70], xmm7
00007d20d97ced95  vmovaps [rsp+0x80], xmm8
00007d20d97ced9e  vmovaps [rsp+0x90], xmm9
00007d20d97ceda7  vmovaps [rsp+0xA0], xmm10
00007d20d97cedb0  vmovaps [rsp+0xB0], xmm11
00007d20d97cedb9  vmovaps [rsp+0xC0], xmm12
00007d20d97cedc2  vmovaps [rsp+0xD0], xmm14
00007d20d97cedcb  vmovaps [rsp+0xE0], xmm15
00007d20d97cedd4  sub rsp, 0x30
00007d20d97cedd8  movaps [rsp], xmm13
00007d20d97ceddd  movaps [rsp+0x10], xmm15
00007d20d97cede3  movaps [rsp+0x20], xmm14
00007d20d97cede9  lea rdi, [rsp]
00007d20d97ceded  mov esi, 0x00
00007d20d97cedf2  mov rax, 0x5EFBF4CF6530
00007d20d97cedfc  call rax
00007d20d97cedfe  movaps xmm13, [rsp]
00007d20d97cee03  add rsp, 0x30
00007d20d97cee07  vmovaps xmm0, [rsp]
00007d20d97cee0c  vmovaps xmm1, [rsp+0x10]
00007d20d97cee12  vmovaps xmm2, [rsp+0x20]
00007d20d97cee18  vmovaps xmm3, [rsp+0x30]
00007d20d97cee1e  vmovaps xmm4, [rsp+0x40]
00007d20d97cee24  vmovaps xmm5, [rsp+0x50]
00007d20d97cee2a  vmovaps xmm6, [rsp+0x60]
00007d20d97cee30  vmovaps xmm7, [rsp+0x70]
00007d20d97cee36  vmovaps xmm8, [rsp+0x80]
00007d20d97cee3f  vmovaps xmm9, [rsp+0x90]
00007d20d97cee48  vmovaps xmm10, [rsp+0xA0]
00007d20d97cee51  vmovaps xmm11, [rsp+0xB0]
00007d20d97cee5a  vmovaps xmm12, [rsp+0xC0]
00007d20d97cee63  vmovaps xmm14, [rsp+0xD0]
00007d20d97cee6c  vmovaps xmm15, [rsp+0xE0]
00007d20d97cee75  add rsp, 0xF0
00007d20d97cee7c  pop r11
00007d20d97cee7e  pop r10
00007d20d97cee80  pop r9
00007d20d97cee82  pop r8
00007d20d97cee84  pop rsi
00007d20d97cee85  pop rdi
00007d20d97cee86  pop rdx
00007d20d97cee87  pop rcx
00007d20d97cee88  pop rax
00007d20d97cee89  add rsp, 0x08
00007d20d97cee8d  jmp 0x00007D20D97CEC71
00007d20d97cee92  call 0x00007D20D96C2240
00007d20d97cee97  jmp 0x00007D20D97CEC8B
00007d20d97cee9c  sub rsp, 0x08
00007d20d97ceea0  push rax
00007d20d97ceea1  push rcx
00007d20d97ceea2  push rdx
00007d20d97ceea3  push rdi
00007d20d97ceea4  push rsi
00007d20d97ceea5  push r8
00007d20d97ceea7  push r9
00007d20d97ceea9  push r10
00007d20d97ceeab  push r11
00007d20d97ceead  sub rsp, 0xF0
00007d20d97ceeb4  vmovaps [rsp], xmm0
00007d20d97ceeb9  vmovaps [rsp+0x10], xmm1
00007d20d97ceebf  vmovaps [rsp+0x20], xmm2
00007d20d97ceec5  vmovaps [rsp+0x30], xmm3
00007d20d97ceecb  vmovaps [rsp+0x40], xmm4
00007d20d97ceed1  vmovaps [rsp+0x50], xmm5
00007d20d97ceed7  vmovaps [rsp+0x60], xmm6
00007d20d97ceedd  vmovaps [rsp+0x70], xmm7
00007d20d97ceee3  vmovaps [rsp+0x80], xmm8
00007d20d97ceeec  vmovaps [rsp+0x90], xmm9
00007d20d97ceef5  vmovaps [rsp+0xA0], xmm10
00007d20d97ceefe  vmovaps [rsp+0xB0], xmm11
00007d20d97cef07  vmovaps [rsp+0xC0], xmm12
00007d20d97cef10  vmovaps [rsp+0xD0], xmm13
00007d20d97cef19  vmovaps [rsp+0xE0], xmm15
00007d20d97cef22  sub rsp, 0x30
00007d20d97cef26  movaps [rsp], xmm14
00007d20d97cef2b  movaps [rsp+0x10], xmm1
00007d20d97cef30  movaps [rsp+0x20], xmm15
00007d20d97cef36  lea rdi, [rsp]
00007d20d97cef3a  mov esi, 0x00
00007d20d97cef3f  mov rax, 0x5EFBF4CF6530
00007d20d97cef49  call rax
00007d20d97cef4b  movaps xmm14, [rsp]
00007d20d97cef50  add rsp, 0x30
00007d20d97cef54  vmovaps xmm0, [rsp]
00007d20d97cef59  vmovaps xmm1, [rsp+0x10]
00007d20d97cef5f  vmovaps xmm2, [rsp+0x20]
00007d20d97cef65  vmovaps xmm3, [rsp+0x30]
00007d20d97cef6b  vmovaps xmm4, [rsp+0x40]
00007d20d97cef71  vmovaps xmm5, [rsp+0x50]
00007d20d97cef77  vmovaps xmm6, [rsp+0x60]
00007d20d97cef7d  vmovaps xmm7, [rsp+0x70]
00007d20d97cef83  vmovaps xmm8, [rsp+0x80]
00007d20d97cef8c  vmovaps xmm9, [rsp+0x90]
00007d20d97cef95  vmovaps xmm10, [rsp+0xA0]
00007d20d97cef9e  vmovaps xmm11, [rsp+0xB0]
00007d20d97cefa7  vmovaps xmm12, [rsp+0xC0]
00007d20d97cefb0  vmovaps xmm13, [rsp+0xD0]
00007d20d97cefb9  vmovaps xmm15, [rsp+0xE0]
00007d20d97cefc2  add rsp, 0xF0
00007d20d97cefc9  pop r11
00007d20d97cefcb  pop r10
00007d20d97cefcd  pop r9
00007d20d97cefcf  pop r8
00007d20d97cefd1  pop rsi
00007d20d97cefd2  pop rdi
00007d20d97cefd3  pop rdx
00007d20d97cefd4  pop rcx
00007d20d97cefd5  pop rax
00007d20d97cefd6  add rsp, 0x08
00007d20d97cefda  jmp 0x00007D20D97CECAE
00007d20d97cefdf  call 0x00007D20D96C34C0
00007d20d97cefe4  jmp 0x00007D20D97CECC4
00007d20d97cefe9  int3
00007d20d97cefea  nop [rax+rax*1], ax
00007d20d97ceff0  mov rax, [r15+0xF8]
00007d20d97ceff7  lea r14, [rax-0x150]
00007d20d97ceffe  mov [r15+0xF8], r14
00007d20d97cf005  mov rax, [r15+0x50]
00007d20d97cf009  lea r12, [rax+0x80]
00007d20d97cf010  movups xmm1, [r13+r12*1]
00007d20d97cf016  lea r12, [rax+0x90]
00007d20d97cf01d  movups xmm15, [r13+r12*1]
00007d20d97cf023  mov qword ptr [r15+0x48], 0x00
00007d20d97cf02b  lea r12, [rax+0x40]
00007d20d97cf02f  movups xmm14, [r13+r12*1]
00007d20d97cf035  lea r12, [rax+0x50]
00007d20d97cf039  movups xmm13, [r13+r12*1]
00007d20d97cf03f  lea r12, [r14+0x120]
00007d20d97cf046  movq xmm12, qword ptr [r15+0x1C0]
00007d20d97cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007d20d97cf058  movq r11, xmm12
00007d20d97cf05d  movq r10, xmm11
00007d20d97cf062  mov [r13+r12*1], r11
00007d20d97cf067  lea r12, [r14+0x128]
00007d20d97cf06e  mov [r13+r12*1], r10
00007d20d97cf073  vxorps xmm12, xmm12, xmm12
00007d20d97cf078  vpbroadcastq xmm12, xmm12
00007d20d97cf07d  lea r12, [r14+0x100]
00007d20d97cf084  movq xmm11, qword ptr [r15+0x200]
00007d20d97cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007d20d97cf096  movq r11, xmm11
00007d20d97cf09b  movq r10, xmm10
00007d20d97cf0a0  mov [r13+r12*1], r11
00007d20d97cf0a5  lea r12, [r14+0x108]
00007d20d97cf0ac  mov [r13+r12*1], r10
00007d20d97cf0b1  lea r12, [r14+0xE0]
00007d20d97cf0b8  movups [r13+r12*1], xmm15
00007d20d97cf0be  lea r12, [r14+0xF0]
00007d20d97cf0c5  movups [r13+r12*1], xmm1
00007d20d97cf0cb  lea r12, [rax+0xC0]
00007d20d97cf0d2  movups xmm1, [r13+r12*1]
00007d20d97cf0d8  lea r12, [rax+0xD0]
00007d20d97cf0df  movups xmm15, [r13+r12*1]
00007d20d97cf0e5  lea r12, [r14+0x110]
00007d20d97cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007d20d97cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007d20d97cf0fe  movq r11, xmm11
00007d20d97cf103  movq r10, xmm10
00007d20d97cf108  mov [r13+r12*1], r11
00007d20d97cf10d  lea r12, [r14+0x118]
00007d20d97cf114  mov [r13+r12*1], r10
00007d20d97cf119  movups xmm11, [r13+rax*1]
00007d20d97cf11f  lea r12, [rax+0x10]
00007d20d97cf123  movups xmm10, [r13+r12*1]
00007d20d97cf129  lea r12, [r14+0x130]
00007d20d97cf130  movq xmm9, qword ptr [r15+0x1A0]
00007d20d97cf139  movq xmm8, qword ptr [r15+0x190]
00007d20d97cf142  movq r11, xmm9
00007d20d97cf147  movq r10, xmm8
00007d20d97cf14c  mov [r13+r12*1], r11
00007d20d97cf151  lea r12, [r14+0x138]
00007d20d97cf158  mov [r13+r12*1], r10
00007d20d97cf15d  lea r12, [rax+0x140]
00007d20d97cf164  movups xmm9, [r13+r12*1]
00007d20d97cf16a  lea r12, [rax+0x150]
00007d20d97cf171  movups xmm8, [r13+r12*1]
00007d20d97cf177  lea r12, [r14+0xC0]
00007d20d97cf17e  movups [r13+r12*1], xmm15
00007d20d97cf184  lea r12, [r14+0xD0]
00007d20d97cf18b  movups [r13+r12*1], xmm1
00007d20d97cf191  lea r12, [rax+0x100]
00007d20d97cf198  movups xmm1, [r13+r12*1]
00007d20d97cf19e  lea r12, [rax+0x110]
00007d20d97cf1a5  movups xmm15, [r13+r12*1]
00007d20d97cf1ab  lea r12, [r14+0x140]
00007d20d97cf1b2  mov r11, [r15+0xE8]
00007d20d97cf1b9  mov [r13+r12*1], r11
00007d20d97cf1be  lea r12, [rax+0x180]
00007d20d97cf1c5  movups xmm7, [r13+r12*1]
00007d20d97cf1cb  lea r12, [rax+0x190]
00007d20d97cf1d2  movups xmm6, [r13+r12*1]
00007d20d97cf1d8  lea r12, [rax+0x1C0]
00007d20d97cf1df  movups xmm5, [r13+r12*1]
00007d20d97cf1e5  lea r12, [rax+0x1D0]
00007d20d97cf1ec  movups xmm4, [r13+r12*1]
00007d20d97cf1f2  lea r12, [r14+0x20]
00007d20d97cf1f6  movups [r13+r12*1], xmm1
00007d20d97cf1fc  lea r12, [r14+0x30]
00007d20d97cf200  movups [r13+r12*1], xmm13
00007d20d97cf206  lea r12, [rax+0x60]
00007d20d97cf20a  movups xmm1, [r13+r12*1]
00007d20d97cf210  lea r12, [rax+0x70]
00007d20d97cf214  movups xmm13, [r13+r12*1]
00007d20d97cf21a  lea r12, [rax+0x20]
00007d20d97cf21e  movups xmm3, [r13+r12*1]
00007d20d97cf224  lea r12, [rax+0x30]
00007d20d97cf228  movups xmm2, [r13+r12*1]
00007d20d97cf22e  movaps [r15+0x1F0], xmm2
00007d20d97cf236  lea r12, [r14+0x60]
00007d20d97cf23a  movups [r13+r12*1], xmm11
00007d20d97cf240  lea r12, [r14+0x70]
00007d20d97cf244  movups [r13+r12*1], xmm5
00007d20d97cf24a  lea r12, [rax+0xE0]
00007d20d97cf251  movups xmm11, [r13+r12*1]
00007d20d97cf257  lea r12, [rax+0xF0]
00007d20d97cf25e  movups xmm5, [r13+r12*1]
00007d20d97cf264  lea r12, [r14+0xA0]
00007d20d97cf26b  movups [r13+r12*1], xmm13
00007d20d97cf271  lea r12, [r14+0xB0]
00007d20d97cf278  movups [r13+r12*1], xmm1
00007d20d97cf27e  lea r12, [rax+0xA0]
00007d20d97cf285  movups xmm1, [r13+r12*1]
00007d20d97cf28b  lea r12, [rax+0xB0]
00007d20d97cf292  movups xmm13, [r13+r12*1]
00007d20d97cf298  lea r12, [rax+0x120]
00007d20d97cf29f  vmovaps [rsp+0x10], xmm1
00007d20d97cf2a5  movups xmm1, [r13+r12*1]
00007d20d97cf2ab  lea r12, [rax+0x130]
00007d20d97cf2b2  vmovaps [rsp+0x20], xmm1
00007d20d97cf2b8  movups xmm1, [r13+r12*1]
00007d20d97cf2be  lea r12, [rax+0x160]
00007d20d97cf2c5  vmovaps [rsp+0x30], xmm1
00007d20d97cf2cb  movups xmm1, [r13+r12*1]
00007d20d97cf2d1  lea r12, [rax+0x170]
00007d20d97cf2d8  vmovaps [rsp+0x40], xmm1
00007d20d97cf2de  movups xmm1, [r13+r12*1]
00007d20d97cf2e4  movaps [r15+0x2B0], xmm1
00007d20d97cf2ec  lea r12, [r14+0x80]
00007d20d97cf2f3  movups [r13+r12*1], xmm13
00007d20d97cf2f9  lea r12, [r14+0x90]
00007d20d97cf300  vmovaps xmm13, [rsp+0x10]
00007d20d97cf306  movups [r13+r12*1], xmm13
00007d20d97cf30c  lea r12, [rax+0x1A0]
00007d20d97cf313  movups xmm13, [r13+r12*1]
00007d20d97cf319  lea r12, [rax+0x1B0]
00007d20d97cf320  vmovaps [rsp+0x10], xmm1
00007d20d97cf326  movups xmm1, [r13+r12*1]
00007d20d97cf32c  movaps [r15+0x290], xmm13
00007d20d97cf334  movaps [r15+0x1E0], xmm1
00007d20d97cf33c  lea r12, [rax+0x1E0]
00007d20d97cf343  vmovaps [rsp+0x50], xmm1
00007d20d97cf349  movups xmm1, [r13+r12*1]
00007d20d97cf34f  lea r12, [rax+0x1F0]
00007d20d97cf356  vmovaps [rsp+0x60], xmm1
00007d20d97cf35c  movups xmm1, [r13+r12*1]
00007d20d97cf362  mov qword ptr [r15+0x50], 0x430920
00007d20d97cf36a  lea rax, [r14+0x40]
00007d20d97cf36e  vmovaps [rsp+0x70], xmm1
00007d20d97cf374  vmovaps xmm1, [rsp+0x40]
00007d20d97cf37a  movups [r13+rax*1], xmm1
00007d20d97cf380  lea rax, [r14+0x50]
00007d20d97cf384  movups [r13+rax*1], xmm10
00007d20d97cf38a  vmovaps xmm1, [rsp+0x70]
00007d20d97cf390  movups [r13+r14*1], xmm1
00007d20d97cf396  lea rax, [r14+0x10]
00007d20d97cf39a  vmovaps xmm1, [rsp+0x60]
00007d20d97cf3a0  movups [r13+rax*1], xmm1
00007d20d97cf3a6  mov rax, [r15+0x40]
00007d20d97cf3aa  vmovaps [rsp+0x40], xmm3
00007d20d97cf3b0  vmovaps xmm1, [rsp+0x40]
00007d20d97cf3b6  por xmm3, xmm1
00007d20d97cf3ba  vmovaps [rsp+0x40], xmm6
00007d20d97cf3c0  vmovaps xmm10, [rsp+0x40]
00007d20d97cf3c6  por xmm6, xmm10
00007d20d97cf3cb  lea r12, [rax+0x30]
00007d20d97cf3cf  mov r11, [r13+r12*1]
00007d20d97cf3d4  lea r12, [rax+0x38]
00007d20d97cf3d8  mov r10, [r13+r12*1]
00007d20d97cf3dd  movq xmm10, r11
00007d20d97cf3e2  vmovaps [rsp+0x40], xmm1
00007d20d97cf3e8  movq xmm1, r10
00007d20d97cf3ed  movq xmm10, xmm10
00007d20d97cf3f2  vmovaps [rsp+0x60], xmm10
00007d20d97cf3f8  movq xmm10, xmm10
00007d20d97cf3fd  movaps [r15+0x130], xmm10
00007d20d97cf405  movq xmm1, xmm1
00007d20d97cf409  vmovaps [rsp+0x70], xmm1
00007d20d97cf40f  movq xmm1, xmm1
00007d20d97cf413  movaps [r15+0x280], xmm1
00007d20d97cf41b  vmovaps [rsp+0x80], xmm9
00007d20d97cf424  vmovaps xmm1, [rsp+0x80]
00007d20d97cf42d  por xmm9, xmm1
00007d20d97cf432  lea r12, [rax+0x20]
00007d20d97cf436  mov r11, [r13+r12*1]
00007d20d97cf43b  lea r12, [rax+0x28]
00007d20d97cf43f  mov r10, [r13+r12*1]
00007d20d97cf444  movq xmm1, r11
00007d20d97cf449  movq xmm10, r10
00007d20d97cf44e  movq xmm1, xmm1
00007d20d97cf452  vmovaps [rsp+0x80], xmm1
00007d20d97cf45b  movq xmm1, xmm1
00007d20d97cf45f  movaps [r15+0x150], xmm1
00007d20d97cf467  movq xmm10, xmm10
00007d20d97cf46c  vmovaps [rsp+0x90], xmm10
00007d20d97cf475  movq xmm10, xmm10
00007d20d97cf47a  movaps [r15+0x140], xmm10
00007d20d97cf482  lea r12, [rax+0x10]
00007d20d97cf486  mov r11, [r13+r12*1]
00007d20d97cf48b  lea r12, [rax+0x18]
00007d20d97cf48f  mov r10, [r13+r12*1]
00007d20d97cf494  movq xmm1, r11
00007d20d97cf499  movq xmm10, r10
00007d20d97cf49e  movq xmm1, xmm1
00007d20d97cf4a2  vmovaps [rsp+0xA0], xmm1
00007d20d97cf4ab  movq xmm1, xmm1
00007d20d97cf4af  movaps [r15+0x170], xmm1
00007d20d97cf4b7  movq xmm10, xmm10
00007d20d97cf4bc  vmovaps [rsp+0xB0], xmm10
00007d20d97cf4c5  movq xmm10, xmm10
00007d20d97cf4ca  movaps [r15+0x160], xmm10
00007d20d97cf4d2  mov r12, [r13+rax*1]
00007d20d97cf4d7  vmovq xmm1, r12
00007d20d97cf4dc  vpbroadcastq xmm1, xmm1
00007d20d97cf4e1  lea r12, [rax+0x08]
00007d20d97cf4e5  mov rax, [r13+r12*1]
00007d20d97cf4ea  movq xmm10, rax
00007d20d97cf4ef  movaps [r15+0x230], xmm10
00007d20d97cf4f7  lea rax, [r14+0x50]
00007d20d97cf4fb  movups xmm10, [r13+rax*1]
00007d20d97cf501  lea rax, [r14+0x60]
00007d20d97cf505  vmovaps [rsp+0xC0], xmm1
00007d20d97cf50e  movups xmm1, [r13+rax*1]
00007d20d97cf514  lea rax, [r14+0x30]
00007d20d97cf518  vmovaps [rsp+0xD0], xmm1
00007d20d97cf521  movups xmm1, [r13+rax*1]
00007d20d97cf527  mov qword ptr [r15+0x60], 0x430920
00007d20d97cf52f  mov qword ptr [r15+0x58], 0x40
00007d20d97cf537  vmovaps [rsp+0xE0], xmm1
00007d20d97cf540  vmovaps [rsp+0xF0], xmm15
00007d20d97cf549  vmovaps xmm15, [rsp+0xC0]
00007d20d97cf552  vmovaps [rsp+0xC0], xmm14
00007d20d97cf55b  vmovaps xmm14, [rsp+0x40]
00007d20d97cf561  vmovaps [rsp+0x40], xmm13
00007d20d97cf567  movaps xmm1, xmm15
00007d20d97cf56b  mulpd xmm1, xmm14
00007d20d97cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007d20d97cf575  ptest xmm13, xmm13
00007d20d97cf57b  jnz 0x00007D20D97D0682
00007d20d97cf581  movq xmm14, qword ptr [r15+0x230]
00007d20d97cf58a  vmovaps [rsp+0x100], xmm14
00007d20d97cf593  vpermilpd xmm14, xmm14, 0x00
00007d20d97cf599  vmovaps [rsp+0x110], xmm1
00007d20d97cf5a2  vmovaps xmm1, [rsp+0xE0]
00007d20d97cf5ab  vmovaps [rsp+0xE0], xmm15
00007d20d97cf5b4  movaps xmm13, xmm1
00007d20d97cf5b8  mulpd xmm13, xmm14
00007d20d97cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007d20d97cf5c3  ptest xmm15, xmm15
00007d20d97cf5c9  jnz 0x00007D20D97D07C4
00007d20d97cf5cf  vxorps xmm1, xmm1, xmm1
00007d20d97cf5d3  vpbroadcastq xmm1, xmm1
00007d20d97cf5d8  vmovaps xmm14, [rsp+0xE0]
00007d20d97cf5e1  vmovaps [rsp+0xE0], xmm1
00007d20d97cf5ea  vmovaps xmm1, [rsp+0xD0]
00007d20d97cf5f3  vmovaps [rsp+0xD0], xmm13
00007d20d97cf5fc  movaps xmm15, xmm14
00007d20d97cf600  mulpd xmm15, xmm1
00007d20d97cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007d20d97cf60b  ptest xmm13, xmm13
00007d20d97cf611  jnz 0x00007D20D97D0907
00007d20d97cf617  movaps xmm1, xmm14
00007d20d97cf61b  mulpd xmm1, xmm10
00007d20d97cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007d20d97cf625  ptest xmm13, xmm13
00007d20d97cf62b  jnz 0x00007D20D97D0A4A
00007d20d97cf631  movaps xmm13, xmm14
00007d20d97cf635  mulpd xmm13, xmm2
00007d20d97cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007d20d97cf640  ptest xmm10, xmm10
00007d20d97cf646  jnz 0x00007D20D97D0B8C
00007d20d97cf64c  vmovaps [rsp+0x120], xmm7
00007d20d97cf655  vmovaps xmm14, [rsp+0x120]
00007d20d97cf65e  por xmm7, xmm14
00007d20d97cf663  vmovaps xmm14, [rsp+0xC0]
00007d20d97cf66c  vmovaps xmm10, [rsp+0xC0]
00007d20d97cf675  por xmm14, xmm10
00007d20d97cf67a  vmovaps xmm2, [rsp+0x100]
00007d20d97cf683  vpermilpd xmm2, xmm2, 0x00
00007d20d97cf689  vmovaps [rsp+0xC0], xmm1
00007d20d97cf692  vmovaps [rsp+0x120], xmm15
00007d20d97cf69b  movaps xmm1, xmm10
00007d20d97cf69f  mulpd xmm1, xmm2
00007d20d97cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007d20d97cf6a8  ptest xmm15, xmm15
00007d20d97cf6ae  jnz 0x00007D20D97D0CCF
00007d20d97cf6b4  xor eax, eax
00007d20d97cf6b6  mov r12d, 0x40
00007d20d97cf6bc  mov r11d, 0x200
00007d20d97cf6c2  cmp r12, r11
00007d20d97cf6c5  cmc
00007d20d97cf6c6  lahf
00007d20d97cf6c7  seto al
00007d20d97cf6ca  mov [r15+0x108], eax
00007d20d97cf6d1  vmovaps xmm10, [rsp+0x110]
00007d20d97cf6da  vmovaps xmm2, [rsp+0xE0]
00007d20d97cf6e3  vmovaps [rsp+0xE0], xmm1
00007d20d97cf6ec  movaps xmm15, xmm10
00007d20d97cf6f0  addpd xmm15, xmm2
00007d20d97cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97cf6fb  ptest xmm1, xmm1
00007d20d97cf700  jnz 0x00007D20D97D0E10
00007d20d97cf706  vmovaps xmm10, [rsp+0x120]
00007d20d97cf70f  vmovaps [rsp+0x110], xmm15
00007d20d97cf718  movaps xmm1, xmm10
00007d20d97cf71c  addpd xmm1, xmm12
00007d20d97cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007d20d97cf726  ptest xmm15, xmm15
00007d20d97cf72c  jnz 0x00007D20D97D0F53
00007d20d97cf732  vmovaps xmm10, [rsp+0xC0]
00007d20d97cf73b  vmovaps [rsp+0xC0], xmm1
00007d20d97cf744  movaps xmm15, xmm10
00007d20d97cf748  addpd xmm15, xmm12
00007d20d97cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97cf753  ptest xmm1, xmm1
00007d20d97cf758  jnz 0x00007D20D97D1095
00007d20d97cf75e  vmovaps xmm1, [rsp+0x30]
00007d20d97cf764  vmovaps xmm12, [rsp+0x30]
00007d20d97cf76a  por xmm1, xmm12
00007d20d97cf76f  vmovaps xmm12, [rsp+0x20]
00007d20d97cf775  vmovaps xmm10, [rsp+0x20]
00007d20d97cf77b  por xmm12, xmm10
00007d20d97cf780  vmovaps [rsp+0x20], xmm5
00007d20d97cf786  vmovaps xmm10, [rsp+0x20]
00007d20d97cf78c  por xmm5, xmm10
00007d20d97cf791  vmovaps [rsp+0x20], xmm11
00007d20d97cf797  vmovaps xmm10, [rsp+0x20]
00007d20d97cf79d  por xmm11, xmm10
00007d20d97cf7a2  vmovaps [rsp+0x20], xmm4
00007d20d97cf7a8  vmovaps xmm10, [rsp+0x20]
00007d20d97cf7ae  por xmm4, xmm10
00007d20d97cf7b3  vmovaps [rsp+0x20], xmm8
00007d20d97cf7b9  vmovaps xmm10, [rsp+0x20]
00007d20d97cf7bf  por xmm8, xmm10
00007d20d97cf7c4  vmovaps xmm10, [rsp+0xF0]
00007d20d97cf7cd  vmovaps [rsp+0x20], xmm1
00007d20d97cf7d3  vmovaps xmm1, [rsp+0xF0]
00007d20d97cf7dc  por xmm10, xmm1
00007d20d97cf7e1  lea rax, [r14+0xA0]
00007d20d97cf7e8  movups xmm1, [r13+rax*1]
00007d20d97cf7ee  lea rax, [r14+0xB0]
00007d20d97cf7f5  vmovaps [rsp+0x30], xmm1
00007d20d97cf7fb  movups xmm1, [r13+rax*1]
00007d20d97cf801  vmovaps [rsp+0xF0], xmm1
00007d20d97cf80a  vmovaps [rsp+0x120], xmm15
00007d20d97cf813  movaps xmm1, xmm13
00007d20d97cf817  addpd xmm1, xmm2
00007d20d97cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d20d97cf820  ptest xmm15, xmm15
00007d20d97cf826  jnz 0x00007D20D97D11ED
00007d20d97cf82c  lea rax, [r14+0xF0]
00007d20d97cf833  movups xmm15, [r13+rax*1]
00007d20d97cf839  vmovaps xmm2, [rsp+0xC0]
00007d20d97cf842  vmovaps [rsp+0xC0], xmm1
00007d20d97cf84b  vmovaps xmm1, [rsp+0xE0]
00007d20d97cf854  vmovaps [rsp+0xE0], xmm15
00007d20d97cf85d  movaps xmm13, xmm2
00007d20d97cf861  addpd xmm13, xmm1
00007d20d97cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007d20d97cf86c  ptest xmm15, xmm15
00007d20d97cf872  jnz 0x00007D20D97D1338
00007d20d97cf878  vmovaps xmm15, [rsp+0x120]
00007d20d97cf881  vmovaps xmm2, [rsp+0xD0]
00007d20d97cf88a  vmovaps [rsp+0xD0], xmm14
00007d20d97cf893  movaps xmm1, xmm15
00007d20d97cf897  addpd xmm1, xmm2
00007d20d97cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007d20d97cf8a0  ptest xmm14, xmm14
00007d20d97cf8a6  jnz 0x00007D20D97D147A
00007d20d97cf8ac  vmovaps xmm15, [rsp+0x100]
00007d20d97cf8b5  vpermilpd xmm15, xmm15, 0x00
00007d20d97cf8bb  vmovaps xmm2, [rsp+0xF0]
00007d20d97cf8c4  vmovaps [rsp+0xF0], xmm1
00007d20d97cf8cd  movaps xmm14, xmm2
00007d20d97cf8d1  mulpd xmm14, xmm15
00007d20d97cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007d20d97cf8dc  ptest xmm1, xmm1
00007d20d97cf8e1  jnz 0x00007D20D97D15BB
00007d20d97cf8e7  vmovaps xmm1, [rsp+0xA0]
00007d20d97cf8f0  vpermilpd xmm1, xmm1, 0x00
00007d20d97cf8f6  vmovaps xmm2, [rsp+0xE0]
00007d20d97cf8ff  vmovaps [rsp+0xE0], xmm14
00007d20d97cf908  movaps xmm15, xmm2
00007d20d97cf90c  mulpd xmm15, xmm1
00007d20d97cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007d20d97cf917  ptest xmm14, xmm14
00007d20d97cf91d  jnz 0x00007D20D97D16FE
00007d20d97cf923  lea rax, [r14+0xE0]
00007d20d97cf92a  movups xmm1, [r13+rax*1]
00007d20d97cf930  vmovaps xmm14, [rsp+0x100]
00007d20d97cf939  vpermilpd xmm14, xmm14, 0x00
00007d20d97cf93f  vmovaps [rsp+0x100], xmm1
00007d20d97cf948  vmovaps xmm1, [rsp+0x30]
00007d20d97cf94e  vmovaps [rsp+0x30], xmm15
00007d20d97cf954  movaps xmm2, xmm1
00007d20d97cf957  mulpd xmm2, xmm14
00007d20d97cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007d20d97cf961  ptest xmm15, xmm15
00007d20d97cf967  jnz 0x00007D20D97D184A
00007d20d97cf96d  vmovaps [rsp+0x120], xmm10
00007d20d97cf976  vmovaps xmm1, [rsp+0x120]
00007d20d97cf97f  por xmm10, xmm1
00007d20d97cf984  movaps [r15+0x300], xmm10
00007d20d97cf98c  vmovaps [rsp+0x120], xmm8
00007d20d97cf995  vmovaps xmm1, [rsp+0x120]
00007d20d97cf99e  por xmm8, xmm1
00007d20d97cf9a3  movaps [r15+0x190], xmm8
00007d20d97cf9ab  vmovaps xmm1, [rsp+0xA0]
00007d20d97cf9b4  vpermilpd xmm1, xmm1, 0x00
00007d20d97cf9ba  vmovaps xmm14, [rsp+0x100]
00007d20d97cf9c3  vmovaps [rsp+0x100], xmm13
00007d20d97cf9cc  movaps xmm15, xmm14
00007d20d97cf9d0  mulpd xmm15, xmm1
00007d20d97cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007d20d97cf9db  ptest xmm13, xmm13
00007d20d97cf9e1  jnz 0x00007D20D97D198B
00007d20d97cf9e7  lea rax, [r14+0x90]
00007d20d97cf9ee  movups xmm1, [r13+rax*1]
00007d20d97cf9f4  vmovaps [rsp+0x120], xmm4
00007d20d97cf9fd  vmovaps xmm14, [rsp+0x120]
00007d20d97cfa06  por xmm4, xmm14
00007d20d97cfa0b  movaps [r15+0x1C0], xmm4
00007d20d97cfa13  vmovaps [rsp+0x120], xmm11
00007d20d97cfa1c  vmovaps xmm14, [rsp+0x120]
00007d20d97cfa25  por xmm11, xmm14
00007d20d97cfa2a  movaps [r15+0x200], xmm11
00007d20d97cfa32  vmovaps [rsp+0x120], xmm5
00007d20d97cfa3b  vmovaps xmm14, [rsp+0x120]
00007d20d97cfa44  por xmm5, xmm14
00007d20d97cfa49  movaps [r15+0x2D0], xmm5
00007d20d97cfa51  vmovaps [rsp+0x120], xmm12
00007d20d97cfa5a  vmovaps xmm14, [rsp+0x120]
00007d20d97cfa63  por xmm12, xmm14
00007d20d97cfa68  movaps [r15+0x2E0], xmm12
00007d20d97cfa70  vmovaps xmm13, [rsp+0x110]
00007d20d97cfa79  vmovaps [rsp+0x110], xmm1
00007d20d97cfa82  vmovaps xmm1, [rsp+0xE0]
00007d20d97cfa8b  vmovaps [rsp+0xE0], xmm15
00007d20d97cfa94  movaps xmm14, xmm13
00007d20d97cfa98  addpd xmm14, xmm1
00007d20d97cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007d20d97cfaa3  ptest xmm15, xmm15
00007d20d97cfaa9  jnz 0x00007D20D97D1AD8
00007d20d97cfaaf  vmovaps xmm1, [rsp+0xA0]
00007d20d97cfab8  vpermilpd xmm1, xmm1, 0x00
00007d20d97cfabe  vmovaps xmm13, [rsp+0x110]
00007d20d97cfac7  vmovaps [rsp+0x110], xmm14
00007d20d97cfad0  movaps xmm15, xmm13
00007d20d97cfad4  mulpd xmm15, xmm1
00007d20d97cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007d20d97cfadf  ptest xmm14, xmm14
00007d20d97cfae5  jnz 0x00007D20D97D1C1B
00007d20d97cfaeb  lea rax, [r14+0x80]
00007d20d97cfaf2  movups xmm1, [r13+rax*1]
00007d20d97cfaf8  vmovaps xmm13, [rsp+0xC0]
00007d20d97cfb01  vmovaps [rsp+0xC0], xmm1
00007d20d97cfb0a  movaps xmm14, xmm13
00007d20d97cfb0e  addpd xmm14, xmm2
00007d20d97cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007d20d97cfb19  ptest xmm1, xmm1
00007d20d97cfb1e  jnz 0x00007D20D97D1D68
00007d20d97cfb24  vmovaps xmm13, [rsp+0x100]
00007d20d97cfb2d  vmovaps xmm2, [rsp+0x30]
00007d20d97cfb33  vmovaps [rsp+0x30], xmm15
00007d20d97cfb39  movaps xmm1, xmm13
00007d20d97cfb3d  addpd xmm1, xmm2
00007d20d97cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007d20d97cfb46  ptest xmm15, xmm15
00007d20d97cfb4c  jnz 0x00007D20D97D1EAB
00007d20d97cfb52  vmovaps xmm15, [rsp+0x20]
00007d20d97cfb58  vmovaps xmm13, [rsp+0x20]
00007d20d97cfb5e  por xmm15, xmm13
00007d20d97cfb63  movaps [r15+0x2F0], xmm15
00007d20d97cfb6b  vmovaps xmm13, [rsp+0xA0]
00007d20d97cfb74  vpermilpd xmm13, xmm13, 0x00
00007d20d97cfb7a  vmovaps [rsp+0x20], xmm1
00007d20d97cfb80  vmovaps xmm1, [rsp+0xC0]
00007d20d97cfb89  vmovaps [rsp+0xA0], xmm15
00007d20d97cfb92  movaps xmm2, xmm1
00007d20d97cfb95  mulpd xmm2, xmm13
00007d20d97cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d20d97cfb9f  ptest xmm15, xmm15
00007d20d97cfba5  jnz 0x00007D20D97D1FEC
00007d20d97cfbab  lea rax, [r14+0xD0]
00007d20d97cfbb2  movups xmm1, [r13+rax*1]
00007d20d97cfbb8  vmovaps xmm13, [rsp+0xF0]
00007d20d97cfbc1  vmovaps [rsp+0xC0], xmm1
00007d20d97cfbca  vmovaps xmm1, [rsp+0xE0]
00007d20d97cfbd3  vmovaps [rsp+0xE0], xmm14
00007d20d97cfbdc  movaps xmm15, xmm13
00007d20d97cfbe0  addpd xmm15, xmm1
00007d20d97cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007d20d97cfbeb  ptest xmm14, xmm14
00007d20d97cfbf1  jnz 0x00007D20D97D2137
00007d20d97cfbf7  vmovaps xmm1, [rsp+0xB0]
00007d20d97cfc00  vpermilpd xmm1, xmm1, 0x00
00007d20d97cfc06  movaps xmm14, xmm11
00007d20d97cfc0a  mulpd xmm14, xmm1
00007d20d97cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007d20d97cfc15  ptest xmm13, xmm13
00007d20d97cfc1b  jnz 0x00007D20D97D227A
00007d20d97cfc21  movaps [r15+0x260], xmm14
00007d20d97cfc29  vxorps xmm1, xmm1, xmm1
00007d20d97cfc2d  vpbroadcastq xmm1, xmm1
00007d20d97cfc32  movaps [r15+0x1B0], xmm1
00007d20d97cfc3a  vmovaps xmm1, [rsp+0xB0]
00007d20d97cfc43  vpermilpd xmm1, xmm1, 0x00
00007d20d97cfc49  vmovaps xmm11, [rsp+0xC0]
00007d20d97cfc52  vmovaps [rsp+0xC0], xmm15
00007d20d97cfc5b  movaps xmm13, xmm11
00007d20d97cfc5f  mulpd xmm13, xmm1
00007d20d97cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007d20d97cfc6a  ptest xmm15, xmm15
00007d20d97cfc70  jnz 0x00007D20D97D23BD
00007d20d97cfc76  lea rax, [r14+0xC0]
00007d20d97cfc7d  movups xmm1, [r13+rax*1]
00007d20d97cfc83  vmovaps xmm11, [rsp+0x110]
00007d20d97cfc8c  vmovaps [rsp+0xF0], xmm1
00007d20d97cfc95  vmovaps xmm1, [rsp+0x30]
00007d20d97cfc9b  vmovaps [rsp+0x30], xmm14
00007d20d97cfca1  movaps xmm15, xmm11
00007d20d97cfca5  addpd xmm15, xmm1
00007d20d97cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007d20d97cfcb0  ptest xmm14, xmm14
00007d20d97cfcb6  jnz 0x00007D20D97D250A
00007d20d97cfcbc  vmovaps [rsp+0x100], xmm9
00007d20d97cfcc5  vmovaps xmm1, [rsp+0x100]
00007d20d97cfcce  por xmm9, xmm1
00007d20d97cfcd3  movaps [r15+0x270], xmm9
00007d20d97cfcdb  vmovaps [rsp+0x100], xmm6
00007d20d97cfce4  vmovaps xmm1, [rsp+0x100]
00007d20d97cfced  por xmm6, xmm1
00007d20d97cfcf1  movaps [r15+0x1A0], xmm6
00007d20d97cfcf9  vmovaps xmm14, [rsp+0xB0]
00007d20d97cfd02  vpermilpd xmm14, xmm14, 0x00
00007d20d97cfd08  vmovaps xmm6, [rsp+0xF0]
00007d20d97cfd11  vmovaps [rsp+0xF0], xmm1
00007d20d97cfd1a  movaps xmm11, xmm6
00007d20d97cfd1e  mulpd xmm11, xmm14
00007d20d97cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007d20d97cfd29  ptest xmm1, xmm1
00007d20d97cfd2e  jnz 0x00007D20D97D264D
00007d20d97cfd34  lea rax, [r14+0x20]
00007d20d97cfd38  movups xmm1, [r13+rax*1]
00007d20d97cfd3e  movaps [r15+0x110], xmm1
00007d20d97cfd46  vmovaps xmm6, [rsp+0xE0]
00007d20d97cfd4f  vmovaps [rsp+0xE0], xmm1
00007d20d97cfd58  movaps xmm14, xmm6
00007d20d97cfd5c  addpd xmm14, xmm2
00007d20d97cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007d20d97cfd67  ptest xmm1, xmm1
00007d20d97cfd6c  jnz 0x00007D20D97D279A
00007d20d97cfd72  vmovaps xmm1, [rsp+0xB0]
00007d20d97cfd7b  vpermilpd xmm1, xmm1, 0x00
00007d20d97cfd81  movaps xmm6, xmm5
00007d20d97cfd84  mulpd xmm6, xmm1
00007d20d97cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007d20d97cfd8d  ptest xmm2, xmm2
00007d20d97cfd92  jnz 0x00007D20D97D28DC
00007d20d97cfd98  vmovaps xmm5, [rsp+0x20]
00007d20d97cfd9e  movaps xmm1, xmm5
00007d20d97cfda1  addpd xmm1, xmm13
00007d20d97cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007d20d97cfdab  ptest xmm2, xmm2
00007d20d97cfdb0  jnz 0x00007D20D97D2A1C
00007d20d97cfdb6  vmovaps xmm13, [rsp+0x80]
00007d20d97cfdbf  vpermilpd xmm13, xmm13, 0x00
00007d20d97cfdc5  vmovaps xmm2, [rsp+0xE0]
00007d20d97cfdce  vmovaps [rsp+0x20], xmm1
00007d20d97cfdd4  movaps xmm5, xmm2
00007d20d97cfdd7  mulpd xmm5, xmm13
00007d20d97cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007d20d97cfde1  ptest xmm1, xmm1
00007d20d97cfde6  jnz 0x00007D20D97D2B5D
00007d20d97cfdec  vmovaps xmm1, [rsp+0x80]
00007d20d97cfdf5  vpermilpd xmm1, xmm1, 0x00
00007d20d97cfdfb  movaps xmm13, xmm10
00007d20d97cfdff  mulpd xmm13, xmm1
00007d20d97cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007d20d97cfe0a  ptest xmm2, xmm2
00007d20d97cfe0f  jnz 0x00007D20D97D2C9E
00007d20d97cfe15  vmovaps xmm10, [rsp+0x30]
00007d20d97cfe1b  movaps xmm1, xmm15
00007d20d97cfe1f  addpd xmm1, xmm10
00007d20d97cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007d20d97cfe29  ptest xmm2, xmm2
00007d20d97cfe2e  jnz 0x00007D20D97D2DE1
00007d20d97cfe34  vmovaps xmm10, [rsp+0xC0]
00007d20d97cfe3d  movaps xmm15, xmm10
00007d20d97cfe41  addpd xmm15, xmm11
00007d20d97cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007d20d97cfe4c  ptest xmm2, xmm2
00007d20d97cfe51  jnz 0x00007D20D97D2F23
00007d20d97cfe57  vmovaps xmm11, [rsp+0x80]
00007d20d97cfe60  vpermilpd xmm11, xmm11, 0x00
00007d20d97cfe66  movaps xmm10, xmm12
00007d20d97cfe6a  mulpd xmm10, xmm11
00007d20d97cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007d20d97cfe75  ptest xmm2, xmm2
00007d20d97cfe7a  jnz 0x00007D20D97D3067
00007d20d97cfe80  vmovaps xmm12, [rsp+0x80]
00007d20d97cfe89  vpermilpd xmm12, xmm12, 0x00
00007d20d97cfe8f  vmovaps xmm2, [rsp+0xA0]
00007d20d97cfe98  vmovaps [rsp+0x30], xmm1
00007d20d97cfe9e  movaps xmm11, xmm2
00007d20d97cfea2  mulpd xmm11, xmm12
00007d20d97cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007d20d97cfead  ptest xmm1, xmm1
00007d20d97cfeb2  jnz 0x00007D20D97D31AB
00007d20d97cfeb8  movaps xmm1, xmm14
00007d20d97cfebc  addpd xmm1, xmm6
00007d20d97cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007d20d97cfec5  ptest xmm12, xmm12
00007d20d97cfecb  jnz 0x00007D20D97D32EE
00007d20d97cfed1  vmovaps xmm12, [rsp+0x20]
00007d20d97cfed7  movaps xmm14, xmm12
00007d20d97cfedb  addpd xmm14, xmm5
00007d20d97cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007d20d97cfee6  ptest xmm6, xmm6
00007d20d97cfeeb  jnz 0x00007D20D97D342F
00007d20d97cfef1  vmovaps xmm12, [rsp+0x90]
00007d20d97cfefa  vpermilpd xmm12, xmm12, 0x00
00007d20d97cff00  movaps xmm6, xmm9
00007d20d97cff04  mulpd xmm6, xmm12
00007d20d97cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007d20d97cff0e  ptest xmm5, xmm5
00007d20d97cff13  jnz 0x00007D20D97D3572
00007d20d97cff19  movaps xmm12, xmm15
00007d20d97cff1d  addpd xmm12, xmm13
00007d20d97cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007d20d97cff28  ptest xmm9, xmm9
00007d20d97cff2e  jnz 0x00007D20D97D36B4
00007d20d97cff34  vmovaps xmm13, [rsp+0x30]
00007d20d97cff3a  movaps xmm15, xmm13
00007d20d97cff3e  addpd xmm15, xmm10
00007d20d97cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007d20d97cff49  ptest xmm9, xmm9
00007d20d97cff4f  jnz 0x00007D20D97D37F8
00007d20d97cff55  vmovaps xmm13, [rsp+0xD0]
00007d20d97cff5e  vmovaps xmm10, [rsp+0xD0]
00007d20d97cff67  por xmm13, xmm10
00007d20d97cff6c  movaps [r15+0x250], xmm13
00007d20d97cff74  vmovaps [rsp+0x20], xmm7
00007d20d97cff7a  vmovaps xmm13, [rsp+0x20]
00007d20d97cff80  por xmm7, xmm13
00007d20d97cff85  movaps [r15+0x2A0], xmm7
00007d20d97cff8d  vmovaps [rsp+0x20], xmm3
00007d20d97cff93  vmovaps xmm13, [rsp+0x20]
00007d20d97cff99  por xmm3, xmm13
00007d20d97cff9e  movaps [r15+0x1D0], xmm3
00007d20d97cffa6  lea rax, [r14+0x40]
00007d20d97cffaa  movups xmm13, [r13+rax*1]
00007d20d97cffb0  movaps [r15+0x2C0], xmm13
00007d20d97cffb8  vmovaps xmm10, [rsp+0x90]
00007d20d97cffc1  vpermilpd xmm10, xmm10, 0x00
00007d20d97cffc7  movaps xmm9, xmm8
00007d20d97cffcb  mulpd xmm9, xmm10
00007d20d97cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007d20d97cffd6  ptest xmm5, xmm5
00007d20d97cffdb  jnz 0x00007D20D97D3946
00007d20d97cffe1  movaps xmm10, xmm1
00007d20d97cffe5  addpd xmm10, xmm11
00007d20d97cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007d20d97cfff0  ptest xmm8, xmm8
00007d20d97cfff6  jnz 0x00007D20D97D3A8A
00007d20d97cfffc  movaps xmm1, xmm14
00007d20d97d0000  addpd xmm1, xmm6
00007d20d97d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007d20d97d0009  ptest xmm11, xmm11
00007d20d97d000f  jnz 0x00007D20D97D3BCD
00007d20d97d0015  vmovaps xmm14, [rsp+0x90]
00007d20d97d001e  vpermilpd xmm14, xmm14, 0x00
00007d20d97d0024  movaps xmm11, xmm13
00007d20d97d0028  mulpd xmm11, xmm14
00007d20d97d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007d20d97d0033  ptest xmm8, xmm8
00007d20d97d0039  jnz 0x00007D20D97D3D0E
00007d20d97d003f  vmovaps xmm14, [rsp+0x90]
00007d20d97d0048  vpermilpd xmm14, xmm14, 0x00
00007d20d97d004e  vmovaps xmm8, [rsp+0x10]
00007d20d97d0054  movaps xmm13, xmm8
00007d20d97d0058  mulpd xmm13, xmm14
00007d20d97d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007d20d97d0063  ptest xmm6, xmm6
00007d20d97d0068  jnz 0x00007D20D97D3E52
00007d20d97d006e  vmovaps xmm14, [rsp+0x60]
00007d20d97d0074  vpermilpd xmm14, xmm14, 0x00
00007d20d97d007a  movaps xmm8, xmm7
00007d20d97d007e  mulpd xmm8, xmm14
00007d20d97d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007d20d97d0089  ptest xmm6, xmm6
00007d20d97d008e  jnz 0x00007D20D97D3F96
00007d20d97d0094  movaps xmm14, xmm12
00007d20d97d0098  addpd xmm14, xmm9
00007d20d97d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007d20d97d00a3  ptest xmm7, xmm7
00007d20d97d00a8  jnz 0x00007D20D97D40D9
00007d20d97d00ae  vmovaps xmm12, [rsp+0x60]
00007d20d97d00b4  vpermilpd xmm12, xmm12, 0x00
00007d20d97d00ba  vmovaps xmm7, [rsp+0xF0]
00007d20d97d00c3  movaps xmm9, xmm7
00007d20d97d00c7  mulpd xmm9, xmm12
00007d20d97d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007d20d97d00d2  ptest xmm6, xmm6
00007d20d97d00d7  jnz 0x00007D20D97D421D
00007d20d97d00dd  movaps xmm12, xmm15
00007d20d97d00e1  addpd xmm12, xmm11
00007d20d97d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007d20d97d00ec  ptest xmm7, xmm7
00007d20d97d00f1  jnz 0x00007D20D97D4360
00007d20d97d00f7  vmovaps xmm15, [rsp+0x60]
00007d20d97d00fd  vpermilpd xmm15, xmm15, 0x00
00007d20d97d0103  vmovaps xmm7, [rsp+0x40]
00007d20d97d0109  movaps xmm11, xmm7
00007d20d97d010d  mulpd xmm11, xmm15
00007d20d97d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007d20d97d0118  ptest xmm6, xmm6
00007d20d97d011d  jnz 0x00007D20D97D44A4
00007d20d97d0123  movaps xmm15, xmm10
00007d20d97d0127  addpd xmm15, xmm13
00007d20d97d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007d20d97d0132  ptest xmm7, xmm7
00007d20d97d0137  jnz 0x00007D20D97D45E7
00007d20d97d013d  vmovaps xmm13, [rsp+0x60]
00007d20d97d0143  vpermilpd xmm13, xmm13, 0x00
00007d20d97d0149  vmovaps xmm7, [rsp+0x50]
00007d20d97d014f  movaps xmm10, xmm7
00007d20d97d0153  mulpd xmm10, xmm13
00007d20d97d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007d20d97d015e  ptest xmm6, xmm6
00007d20d97d0163  jnz 0x00007D20D97D472B
00007d20d97d0169  movaps xmm13, xmm1
00007d20d97d016d  addpd xmm13, xmm8
00007d20d97d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007d20d97d0178  ptest xmm7, xmm7
00007d20d97d017d  jnz 0x00007D20D97D486E
00007d20d97d0183  lea rax, [r14+0x70]
00007d20d97d0187  movups xmm1, [r13+rax*1]
00007d20d97d018d  movaps [r15+0x240], xmm1
00007d20d97d0195  movaps xmm8, xmm14
00007d20d97d0199  addpd xmm8, xmm9
00007d20d97d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007d20d97d01a4  ptest xmm7, xmm7
00007d20d97d01a9  jnz 0x00007D20D97D49BB
00007d20d97d01af  movaps [r15+0x170], xmm8
00007d20d97d01b7  vmovaps xmm14, [rsp+0x70]
00007d20d97d01bd  vpermilpd xmm14, xmm14, 0x00
00007d20d97d01c3  movaps xmm9, xmm1
00007d20d97d01c7  mulpd xmm9, xmm14
00007d20d97d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007d20d97d01d2  ptest xmm7, xmm7
00007d20d97d01d7  jnz 0x00007D20D97D4AFF
00007d20d97d01dd  vmovaps xmm1, [rsp+0x70]
00007d20d97d01e3  vpermilpd xmm1, xmm1, 0x00
00007d20d97d01e9  movaps xmm14, xmm4
00007d20d97d01ed  mulpd xmm14, xmm1
00007d20d97d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007d20d97d01f8  ptest xmm7, xmm7
00007d20d97d01fd  jnz 0x00007D20D97D4C42
00007d20d97d0203  movaps [r15+0x180], xmm14
00007d20d97d020b  movaps xmm1, xmm12
00007d20d97d020f  addpd xmm1, xmm11
00007d20d97d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007d20d97d0219  ptest xmm7, xmm7
00007d20d97d021e  jnz 0x00007D20D97D4D84
00007d20d97d0224  movaps [r15+0x210], xmm1
00007d20d97d022c  movups xmm12, [r13+r14*1]
00007d20d97d0232  lea rax, [r14+0x10]
00007d20d97d0236  movups xmm11, [r13+rax*1]
00007d20d97d023c  movaps [r15+0x230], xmm11
00007d20d97d0244  movaps xmm7, xmm15
00007d20d97d0248  addpd xmm7, xmm10
00007d20d97d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007d20d97d0252  ptest xmm6, xmm6
00007d20d97d0257  jnz 0x00007D20D97D4EDA
00007d20d97d025d  movaps [r15+0x130], xmm7
00007d20d97d0265  vmovaps xmm15, [rsp+0x70]
00007d20d97d026b  vpermilpd xmm15, xmm15, 0x00
00007d20d97d0271  movaps xmm10, xmm11
00007d20d97d0275  mulpd xmm10, xmm15
00007d20d97d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007d20d97d0280  ptest xmm6, xmm6
00007d20d97d0285  jnz 0x00007D20D97D501C
00007d20d97d028b  movaps [r15+0x220], xmm10
00007d20d97d0293  vmovaps xmm15, [rsp+0x70]
00007d20d97d0299  vpermilpd xmm15, xmm15, 0x00
00007d20d97d029f  movaps xmm11, xmm12
00007d20d97d02a3  mulpd xmm11, xmm15
00007d20d97d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007d20d97d02ae  ptest xmm6, xmm6
00007d20d97d02b3  jnz 0x00007D20D97D5160
00007d20d97d02b9  movaps xmm15, xmm13
00007d20d97d02bd  addpd xmm15, xmm9
00007d20d97d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007d20d97d02c8  ptest xmm12, xmm12
00007d20d97d02ce  jnz 0x00007D20D97D52A4
00007d20d97d02d4  movaps [r15+0x140], xmm15
00007d20d97d02dc  movaps xmm13, xmm8
00007d20d97d02e0  addpd xmm13, xmm14
00007d20d97d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007d20d97d02eb  ptest xmm12, xmm12
00007d20d97d02f1  jnz 0x00007D20D97D53E8
00007d20d97d02f7  movaps [r15+0x150], xmm13
00007d20d97d02ff  movaps xmm14, xmm1
00007d20d97d0303  addpd xmm14, xmm10
00007d20d97d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007d20d97d030e  ptest xmm12, xmm12
00007d20d97d0314  jnz 0x00007D20D97D552C
00007d20d97d031a  movaps [r15+0x160], xmm14
00007d20d97d0322  movaps xmm1, xmm7
00007d20d97d0325  addpd xmm1, xmm11
00007d20d97d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007d20d97d032f  ptest xmm12, xmm12
00007d20d97d0335  jnz 0x00007D20D97D566F
00007d20d97d033b  movaps [r15+0x120], xmm1
00007d20d97d0343  mov eax, 0x430920
00007d20d97d0348  movups [r13+rax*1], xmm15
00007d20d97d034e  mov eax, 0x430930
00007d20d97d0353  movups [r13+rax*1], xmm13
00007d20d97d0359  mov eax, 0x430940
00007d20d97d035e  movups [r13+rax*1], xmm14
00007d20d97d0364  mov eax, 0x430950
00007d20d97d0369  movups [r13+rax*1], xmm1
00007d20d97d036f  mov eax, [r15+0x108]
00007d20d97d0376  sahf
00007d20d97d0377  jnz 0x00007D20D97D03A9
00007d20d97d0379  cmp dword ptr [r15+0x318], 0x00
00007d20d97d0381  jz 0x00007D20D97DB900
00007d20d97d0387  nop [rax+rax*1], ax
00007d20d97d0390  nop [rax+rax*1], eax
00007d20d97d0398  mov eax, 0x410444
00007d20d97d039d  mov [r15+0x100], rax
00007d20d97d03a4  jmp 0x00007D20D95FE110
00007d20d97d03a9  cmp dword ptr [r15+0x318], 0x00
00007d20d97d03b1  jz 0x00007D20D97D57E0
00007d20d97d03b7  nop [rax+rax*1], ax
00007d20d97d03c0  nop [rax+rax*1], eax
00007d20d97d03c8  mov eax, 0x410278
00007d20d97d03cd  mov [r15+0x100], rax
00007d20d97d03d4  jmp 0x00007D20D95FE110
00007d20d97d03d9  int3
00007d20d97d03da  call 0x00007D20D96B52F0
00007d20d97d03df  jmp 0x00007D20D97CF016
00007d20d97d03e4  call 0x00007D20D96C4620
00007d20d97d03e9  jmp 0x00007D20D97CF023
00007d20d97d03ee  call 0x00007D20D96C33A0
00007d20d97d03f3  jmp 0x00007D20D97CF035
00007d20d97d03f8  call 0x00007D20D96C2120
00007d20d97d03fd  jmp 0x00007D20D97CF03F
00007d20d97d0402  call 0x00007D20D96C0860
00007d20d97d0407  jmp 0x00007D20D97CF067
00007d20d97d040c  call 0x00007D20D96BF5F0
00007d20d97d0411  jmp 0x00007D20D97CF073
00007d20d97d0416  call 0x00007D20D96C0860
00007d20d97d041b  jmp 0x00007D20D97CF0A5
00007d20d97d0420  call 0x00007D20D96BF5F0
00007d20d97d0425  jmp 0x00007D20D97CF0B1
00007d20d97d042a  call 0x00007D20D96C4740
00007d20d97d042f  jmp 0x00007D20D97CF0BE
00007d20d97d0434  call 0x00007D20D96B5400
00007d20d97d0439  jmp 0x00007D20D97CF0CB
00007d20d97d043e  call 0x00007D20D96B52F0
00007d20d97d0443  jmp 0x00007D20D97CF0D8
00007d20d97d0448  call 0x00007D20D96C4620
00007d20d97d044d  jmp 0x00007D20D97CF0E5
00007d20d97d0452  call 0x00007D20D96C0860
00007d20d97d0457  jmp 0x00007D20D97CF10D
00007d20d97d045c  call 0x00007D20D96BF5F0
00007d20d97d0461  jmp 0x00007D20D97CF119
00007d20d97d0466  call 0x00007D20D9609D70
00007d20d97d046b  jmp 0x00007D20D97CF11F
00007d20d97d0470  call 0x00007D20D96BE9C0
00007d20d97d0475  jmp 0x00007D20D97CF129
00007d20d97d047a  call 0x00007D20D96C0860
00007d20d97d047f  jmp 0x00007D20D97CF151
00007d20d97d0484  call 0x00007D20D96BF5F0
00007d20d97d0489  jmp 0x00007D20D97CF15D
00007d20d97d048e  call 0x00007D20D96BD750
00007d20d97d0493  jmp 0x00007D20D97CF16A
00007d20d97d0498  call 0x00007D20D96BC4E0
00007d20d97d049d  jmp 0x00007D20D97CF177
00007d20d97d04a2  call 0x00007D20D96C4740
00007d20d97d04a7  jmp 0x00007D20D97CF184
00007d20d97d04ac  call 0x00007D20D96B5400
00007d20d97d04b1  jmp 0x00007D20D97CF191
00007d20d97d04b6  call 0x00007D20D96B52F0
00007d20d97d04bb  jmp 0x00007D20D97CF19E
00007d20d97d04c0  call 0x00007D20D96C4620
00007d20d97d04c5  jmp 0x00007D20D97CF1AB
00007d20d97d04ca  call 0x00007D20D96C0860
00007d20d97d04cf  jmp 0x00007D20D97CF1BE
00007d20d97d04d4  call 0x00007D20D96BB270
00007d20d97d04d9  jmp 0x00007D20D97CF1CB
00007d20d97d04de  call 0x00007D20D96BA000
00007d20d97d04e3  jmp 0x00007D20D97CF1D8
00007d20d97d04e8  call 0x00007D20D96B8D90
00007d20d97d04ed  jmp 0x00007D20D97CF1E5
00007d20d97d04f2  call 0x00007D20D96B8A20
00007d20d97d04f7  jmp 0x00007D20D97CF1F2
00007d20d97d04fc  call 0x00007D20D96B5400
00007d20d97d0501  jmp 0x00007D20D97CF1FC
00007d20d97d0506  call 0x00007D20D96C2240
00007d20d97d050b  jmp 0x00007D20D97CF206
00007d20d97d0510  call 0x00007D20D96B52F0
00007d20d97d0515  jmp 0x00007D20D97CF210
00007d20d97d051a  call 0x00007D20D96C2120
00007d20d97d051f  jmp 0x00007D20D97CF21A
00007d20d97d0524  call 0x00007D20D96B77B0
00007d20d97d0529  jmp 0x00007D20D97CF224
00007d20d97d052e  call 0x00007D20D96B6550
00007d20d97d0533  jmp 0x00007D20D97CF22E
00007d20d97d0538  call 0x00007D20D96BFD50
00007d20d97d053d  jmp 0x00007D20D97CF240
00007d20d97d0542  call 0x00007D20D96B8EA0
00007d20d97d0547  jmp 0x00007D20D97CF24A
00007d20d97d054c  call 0x00007D20D96BFC30
00007d20d97d0551  jmp 0x00007D20D97CF257
00007d20d97d0556  call 0x00007D20D96B8D90
00007d20d97d055b  jmp 0x00007D20D97CF264
00007d20d97d0560  call 0x00007D20D96C2240
00007d20d97d0565  jmp 0x00007D20D97CF271
00007d20d97d056a  call 0x00007D20D96B5400
00007d20d97d056f  jmp 0x00007D20D97CF27E
00007d20d97d0574  call 0x00007D20D96B52F0
00007d20d97d0579  jmp 0x00007D20D97CF28B
00007d20d97d057e  call 0x00007D20D96C2120
00007d20d97d0583  jmp 0x00007D20D97CF298
00007d20d97d0588  call 0x00007D20D96B52F0
00007d20d97d058d  jmp 0x00007D20D97CF2AB
00007d20d97d0592  call 0x00007D20D96B52F0
00007d20d97d0597  jmp 0x00007D20D97CF2BE
00007d20d97d059c  call 0x00007D20D96B52F0
00007d20d97d05a1  jmp 0x00007D20D97CF2D1
00007d20d97d05a6  call 0x00007D20D96B52F0
00007d20d97d05ab  jmp 0x00007D20D97CF2E4
00007d20d97d05b0  call 0x00007D20D96C2240
00007d20d97d05b5  jmp 0x00007D20D97CF2F9
00007d20d97d05ba  call 0x00007D20D96C2240
00007d20d97d05bf  jmp 0x00007D20D97CF30C
00007d20d97d05c4  call 0x00007D20D96C2120
00007d20d97d05c9  jmp 0x00007D20D97CF319
00007d20d97d05ce  call 0x00007D20D96B52F0
00007d20d97d05d3  jmp 0x00007D20D97CF32C
00007d20d97d05d8  call 0x00007D20D96B52F0
00007d20d97d05dd  jmp 0x00007D20D97CF34F
00007d20d97d05e2  call 0x00007D20D96B52F0
00007d20d97d05e7  jmp 0x00007D20D97CF362
00007d20d97d05ec  call 0x00007D20D95FF540
00007d20d97d05f1  jmp 0x00007D20D97CF380
00007d20d97d05f6  call 0x00007D20D9608C20
00007d20d97d05fb  jmp 0x00007D20D97CF38A
00007d20d97d0600  call 0x00007D20D96D6600
00007d20d97d0605  jmp 0x00007D20D97CF396
00007d20d97d060a  call 0x00007D20D95FF540
00007d20d97d060f  jmp 0x00007D20D97CF3A6
00007d20d97d0614  call 0x00007D20D96C0370
00007d20d97d0619  jmp 0x00007D20D97CF3D4
00007d20d97d061e  call 0x00007D20D96BF100
00007d20d97d0623  jmp 0x00007D20D97CF3DD
00007d20d97d0628  call 0x00007D20D96C0370
00007d20d97d062d  jmp 0x00007D20D97CF43B
00007d20d97d0632  call 0x00007D20D96BF100
00007d20d97d0637  jmp 0x00007D20D97CF444
00007d20d97d063c  call 0x00007D20D96C0370
00007d20d97d0641  jmp 0x00007D20D97CF48B
00007d20d97d0646  call 0x00007D20D96BF100
00007d20d97d064b  jmp 0x00007D20D97CF494
00007d20d97d0650  call 0x00007D20D960B720
00007d20d97d0655  jmp 0x00007D20D97CF4D7
00007d20d97d065a  call 0x00007D20D96B47C0
00007d20d97d065f  jmp 0x00007D20D97CF4EA
00007d20d97d0664  call 0x00007D20D9608B00
00007d20d97d0669  jmp 0x00007D20D97CF501
00007d20d97d066e  call 0x00007D20D95FF430
00007d20d97d0673  jmp 0x00007D20D97CF514
00007d20d97d0678  call 0x00007D20D95FF430
00007d20d97d067d  jmp 0x00007D20D97CF527
00007d20d97d0682  sub rsp, 0x08
00007d20d97d0686  push rax
00007d20d97d0687  push rcx
00007d20d97d0688  push rdx
00007d20d97d0689  push rdi
00007d20d97d068a  push rsi
00007d20d97d068b  push r8
00007d20d97d068d  push r9
00007d20d97d068f  push r10
00007d20d97d0691  push r11
00007d20d97d0693  sub rsp, 0xF0
00007d20d97d069a  vmovaps [rsp], xmm0
00007d20d97d069f  vmovaps [rsp+0x10], xmm2
00007d20d97d06a5  vmovaps [rsp+0x20], xmm3
00007d20d97d06ab  vmovaps [rsp+0x30], xmm4
00007d20d97d06b1  vmovaps [rsp+0x40], xmm5
00007d20d97d06b7  vmovaps [rsp+0x50], xmm6
00007d20d97d06bd  vmovaps [rsp+0x60], xmm7
00007d20d97d06c3  vmovaps [rsp+0x70], xmm8
00007d20d97d06c9  vmovaps [rsp+0x80], xmm9
00007d20d97d06d2  vmovaps [rsp+0x90], xmm10
00007d20d97d06db  vmovaps [rsp+0xA0], xmm11
00007d20d97d06e4  vmovaps [rsp+0xB0], xmm12
00007d20d97d06ed  vmovaps [rsp+0xC0], xmm13
00007d20d97d06f6  vmovaps [rsp+0xD0], xmm14
00007d20d97d06ff  vmovaps [rsp+0xE0], xmm15
00007d20d97d0708  sub rsp, 0x30
00007d20d97d070c  movaps [rsp], xmm1
00007d20d97d0710  movaps [rsp+0x10], xmm15
00007d20d97d0716  movaps [rsp+0x20], xmm14
00007d20d97d071c  lea rdi, [rsp]
00007d20d97d0720  mov esi, 0x00
00007d20d97d0725  mov rax, 0x5EFBF4CF6530
00007d20d97d072f  call rax
00007d20d97d0731  movaps xmm1, [rsp]
00007d20d97d0735  add rsp, 0x30
00007d20d97d0739  vmovaps xmm0, [rsp]
00007d20d97d073e  vmovaps xmm2, [rsp+0x10]
00007d20d97d0744  vmovaps xmm3, [rsp+0x20]
00007d20d97d074a  vmovaps xmm4, [rsp+0x30]
00007d20d97d0750  vmovaps xmm5, [rsp+0x40]
00007d20d97d0756  vmovaps xmm6, [rsp+0x50]
00007d20d97d075c  vmovaps xmm7, [rsp+0x60]
00007d20d97d0762  vmovaps xmm8, [rsp+0x70]
00007d20d97d0768  vmovaps xmm9, [rsp+0x80]
00007d20d97d0771  vmovaps xmm10, [rsp+0x90]
00007d20d97d077a  vmovaps xmm11, [rsp+0xA0]
00007d20d97d0783  vmovaps xmm12, [rsp+0xB0]
00007d20d97d078c  vmovaps xmm13, [rsp+0xC0]
00007d20d97d0795  vmovaps xmm14, [rsp+0xD0]
00007d20d97d079e  vmovaps xmm15, [rsp+0xE0]
00007d20d97d07a7  add rsp, 0xF0
00007d20d97d07ae  pop r11
00007d20d97d07b0  pop r10
00007d20d97d07b2  pop r9
00007d20d97d07b4  pop r8
00007d20d97d07b6  pop rsi
00007d20d97d07b7  pop rdi
00007d20d97d07b8  pop rdx
00007d20d97d07b9  pop rcx
00007d20d97d07ba  pop rax
00007d20d97d07bb  add rsp, 0x08
00007d20d97d07bf  jmp 0x00007D20D97CF581
00007d20d97d07c4  sub rsp, 0x08
00007d20d97d07c8  push rax
00007d20d97d07c9  push rcx
00007d20d97d07ca  push rdx
00007d20d97d07cb  push rdi
00007d20d97d07cc  push rsi
00007d20d97d07cd  push r8
00007d20d97d07cf  push r9
00007d20d97d07d1  push r10
00007d20d97d07d3  push r11
00007d20d97d07d5  sub rsp, 0xF0
00007d20d97d07dc  vmovaps [rsp], xmm0
00007d20d97d07e1  vmovaps [rsp+0x10], xmm1
00007d20d97d07e7  vmovaps [rsp+0x20], xmm2
00007d20d97d07ed  vmovaps [rsp+0x30], xmm3
00007d20d97d07f3  vmovaps [rsp+0x40], xmm4
00007d20d97d07f9  vmovaps [rsp+0x50], xmm5
00007d20d97d07ff  vmovaps [rsp+0x60], xmm6
00007d20d97d0805  vmovaps [rsp+0x70], xmm7
00007d20d97d080b  vmovaps [rsp+0x80], xmm8
00007d20d97d0814  vmovaps [rsp+0x90], xmm9
00007d20d97d081d  vmovaps [rsp+0xA0], xmm10
00007d20d97d0826  vmovaps [rsp+0xB0], xmm11
00007d20d97d082f  vmovaps [rsp+0xC0], xmm12
00007d20d97d0838  vmovaps [rsp+0xD0], xmm14
00007d20d97d0841  vmovaps [rsp+0xE0], xmm15
00007d20d97d084a  sub rsp, 0x30
00007d20d97d084e  movaps [rsp], xmm13
00007d20d97d0853  movaps [rsp+0x10], xmm1
00007d20d97d0858  movaps [rsp+0x20], xmm14
00007d20d97d085e  lea rdi, [rsp]
00007d20d97d0862  mov esi, 0x00
00007d20d97d0867  mov rax, 0x5EFBF4CF6530
00007d20d97d0871  call rax
00007d20d97d0873  movaps xmm13, [rsp]
00007d20d97d0878  add rsp, 0x30
00007d20d97d087c  vmovaps xmm0, [rsp]
00007d20d97d0881  vmovaps xmm1, [rsp+0x10]
00007d20d97d0887  vmovaps xmm2, [rsp+0x20]
00007d20d97d088d  vmovaps xmm3, [rsp+0x30]
00007d20d97d0893  vmovaps xmm4, [rsp+0x40]
00007d20d97d0899  vmovaps xmm5, [rsp+0x50]
00007d20d97d089f  vmovaps xmm6, [rsp+0x60]
00007d20d97d08a5  vmovaps xmm7, [rsp+0x70]
00007d20d97d08ab  vmovaps xmm8, [rsp+0x80]
00007d20d97d08b4  vmovaps xmm9, [rsp+0x90]
00007d20d97d08bd  vmovaps xmm10, [rsp+0xA0]
00007d20d97d08c6  vmovaps xmm11, [rsp+0xB0]
00007d20d97d08cf  vmovaps xmm12, [rsp+0xC0]
00007d20d97d08d8  vmovaps xmm14, [rsp+0xD0]
00007d20d97d08e1  vmovaps xmm15, [rsp+0xE0]
00007d20d97d08ea  add rsp, 0xF0
00007d20d97d08f1  pop r11
00007d20d97d08f3  pop r10
00007d20d97d08f5  pop r9
00007d20d97d08f7  pop r8
00007d20d97d08f9  pop rsi
00007d20d97d08fa  pop rdi
00007d20d97d08fb  pop rdx
00007d20d97d08fc  pop rcx
00007d20d97d08fd  pop rax
00007d20d97d08fe  add rsp, 0x08
00007d20d97d0902  jmp 0x00007D20D97CF5CF
00007d20d97d0907  sub rsp, 0x08
00007d20d97d090b  push rax
00007d20d97d090c  push rcx
00007d20d97d090d  push rdx
00007d20d97d090e  push rdi
00007d20d97d090f  push rsi
00007d20d97d0910  push r8
00007d20d97d0912  push r9
00007d20d97d0914  push r10
00007d20d97d0916  push r11
00007d20d97d0918  sub rsp, 0xF0
00007d20d97d091f  vmovaps [rsp], xmm0
00007d20d97d0924  vmovaps [rsp+0x10], xmm1
00007d20d97d092a  vmovaps [rsp+0x20], xmm2
00007d20d97d0930  vmovaps [rsp+0x30], xmm3
00007d20d97d0936  vmovaps [rsp+0x40], xmm4
00007d20d97d093c  vmovaps [rsp+0x50], xmm5
00007d20d97d0942  vmovaps [rsp+0x60], xmm6
00007d20d97d0948  vmovaps [rsp+0x70], xmm7
00007d20d97d094e  vmovaps [rsp+0x80], xmm8
00007d20d97d0957  vmovaps [rsp+0x90], xmm9
00007d20d97d0960  vmovaps [rsp+0xA0], xmm10
00007d20d97d0969  vmovaps [rsp+0xB0], xmm11
00007d20d97d0972  vmovaps [rsp+0xC0], xmm12
00007d20d97d097b  vmovaps [rsp+0xD0], xmm13
00007d20d97d0984  vmovaps [rsp+0xE0], xmm14
00007d20d97d098d  sub rsp, 0x30
00007d20d97d0991  movaps [rsp], xmm15
00007d20d97d0996  movaps [rsp+0x10], xmm14
00007d20d97d099c  movaps [rsp+0x20], xmm1
00007d20d97d09a1  lea rdi, [rsp]
00007d20d97d09a5  mov esi, 0x00
00007d20d97d09aa  mov rax, 0x5EFBF4CF6530
00007d20d97d09b4  call rax
00007d20d97d09b6  movaps xmm15, [rsp]
00007d20d97d09bb  add rsp, 0x30
00007d20d97d09bf  vmovaps xmm0, [rsp]
00007d20d97d09c4  vmovaps xmm1, [rsp+0x10]
00007d20d97d09ca  vmovaps xmm2, [rsp+0x20]
00007d20d97d09d0  vmovaps xmm3, [rsp+0x30]
00007d20d97d09d6  vmovaps xmm4, [rsp+0x40]
00007d20d97d09dc  vmovaps xmm5, [rsp+0x50]
00007d20d97d09e2  vmovaps xmm6, [rsp+0x60]
00007d20d97d09e8  vmovaps xmm7, [rsp+0x70]
00007d20d97d09ee  vmovaps xmm8, [rsp+0x80]
00007d20d97d09f7  vmovaps xmm9, [rsp+0x90]
00007d20d97d0a00  vmovaps xmm10, [rsp+0xA0]
00007d20d97d0a09  vmovaps xmm11, [rsp+0xB0]
00007d20d97d0a12  vmovaps xmm12, [rsp+0xC0]
00007d20d97d0a1b  vmovaps xmm13, [rsp+0xD0]
00007d20d97d0a24  vmovaps xmm14, [rsp+0xE0]
00007d20d97d0a2d  add rsp, 0xF0
00007d20d97d0a34  pop r11
00007d20d97d0a36  pop r10
00007d20d97d0a38  pop r9
00007d20d97d0a3a  pop r8
00007d20d97d0a3c  pop rsi
00007d20d97d0a3d  pop rdi
00007d20d97d0a3e  pop rdx
00007d20d97d0a3f  pop rcx
00007d20d97d0a40  pop rax
00007d20d97d0a41  add rsp, 0x08
00007d20d97d0a45  jmp 0x00007D20D97CF617
00007d20d97d0a4a  sub rsp, 0x08
00007d20d97d0a4e  push rax
00007d20d97d0a4f  push rcx
00007d20d97d0a50  push rdx
00007d20d97d0a51  push rdi
00007d20d97d0a52  push rsi
00007d20d97d0a53  push r8
00007d20d97d0a55  push r9
00007d20d97d0a57  push r10
00007d20d97d0a59  push r11
00007d20d97d0a5b  sub rsp, 0xF0
00007d20d97d0a62  vmovaps [rsp], xmm0
00007d20d97d0a67  vmovaps [rsp+0x10], xmm2
00007d20d97d0a6d  vmovaps [rsp+0x20], xmm3
00007d20d97d0a73  vmovaps [rsp+0x30], xmm4
00007d20d97d0a79  vmovaps [rsp+0x40], xmm5
00007d20d97d0a7f  vmovaps [rsp+0x50], xmm6
00007d20d97d0a85  vmovaps [rsp+0x60], xmm7
00007d20d97d0a8b  vmovaps [rsp+0x70], xmm8
00007d20d97d0a91  vmovaps [rsp+0x80], xmm9
00007d20d97d0a9a  vmovaps [rsp+0x90], xmm10
00007d20d97d0aa3  vmovaps [rsp+0xA0], xmm11
00007d20d97d0aac  vmovaps [rsp+0xB0], xmm12
00007d20d97d0ab5  vmovaps [rsp+0xC0], xmm13
00007d20d97d0abe  vmovaps [rsp+0xD0], xmm14
00007d20d97d0ac7  vmovaps [rsp+0xE0], xmm15
00007d20d97d0ad0  sub rsp, 0x30
00007d20d97d0ad4  movaps [rsp], xmm1
00007d20d97d0ad8  movaps [rsp+0x10], xmm14
00007d20d97d0ade  movaps [rsp+0x20], xmm10
00007d20d97d0ae4  lea rdi, [rsp]
00007d20d97d0ae8  mov esi, 0x00
00007d20d97d0aed  mov rax, 0x5EFBF4CF6530
00007d20d97d0af7  call rax
00007d20d97d0af9  movaps xmm1, [rsp]
00007d20d97d0afd  add rsp, 0x30
00007d20d97d0b01  vmovaps xmm0, [rsp]
00007d20d97d0b06  vmovaps xmm2, [rsp+0x10]
00007d20d97d0b0c  vmovaps xmm3, [rsp+0x20]
00007d20d97d0b12  vmovaps xmm4, [rsp+0x30]
00007d20d97d0b18  vmovaps xmm5, [rsp+0x40]
00007d20d97d0b1e  vmovaps xmm6, [rsp+0x50]
00007d20d97d0b24  vmovaps xmm7, [rsp+0x60]
00007d20d97d0b2a  vmovaps xmm8, [rsp+0x70]
00007d20d97d0b30  vmovaps xmm9, [rsp+0x80]
00007d20d97d0b39  vmovaps xmm10, [rsp+0x90]
00007d20d97d0b42  vmovaps xmm11, [rsp+0xA0]
00007d20d97d0b4b  vmovaps xmm12, [rsp+0xB0]
00007d20d97d0b54  vmovaps xmm13, [rsp+0xC0]
00007d20d97d0b5d  vmovaps xmm14, [rsp+0xD0]
00007d20d97d0b66  vmovaps xmm15, [rsp+0xE0]
00007d20d97d0b6f  add rsp, 0xF0
00007d20d97d0b76  pop r11
00007d20d97d0b78  pop r10
00007d20d97d0b7a  pop r9
00007d20d97d0b7c  pop r8
00007d20d97d0b7e  pop rsi
00007d20d97d0b7f  pop rdi
00007d20d97d0b80  pop rdx
00007d20d97d0b81  pop rcx
00007d20d97d0b82  pop rax
00007d20d97d0b83  add rsp, 0x08
00007d20d97d0b87  jmp 0x00007D20D97CF631
00007d20d97d0b8c  sub rsp, 0x08
00007d20d97d0b90  push rax
00007d20d97d0b91  push rcx
00007d20d97d0b92  push rdx
00007d20d97d0b93  push rdi
00007d20d97d0b94  push rsi
00007d20d97d0b95  push r8
00007d20d97d0b97  push r9
00007d20d97d0b99  push r10
00007d20d97d0b9b  push r11
00007d20d97d0b9d  sub rsp, 0xF0
00007d20d97d0ba4  vmovaps [rsp], xmm0
00007d20d97d0ba9  vmovaps [rsp+0x10], xmm1
00007d20d97d0baf  vmovaps [rsp+0x20], xmm2
00007d20d97d0bb5  vmovaps [rsp+0x30], xmm3
00007d20d97d0bbb  vmovaps [rsp+0x40], xmm4
00007d20d97d0bc1  vmovaps [rsp+0x50], xmm5
00007d20d97d0bc7  vmovaps [rsp+0x60], xmm6
00007d20d97d0bcd  vmovaps [rsp+0x70], xmm7
00007d20d97d0bd3  vmovaps [rsp+0x80], xmm8
00007d20d97d0bdc  vmovaps [rsp+0x90], xmm9
00007d20d97d0be5  vmovaps [rsp+0xA0], xmm10
00007d20d97d0bee  vmovaps [rsp+0xB0], xmm11
00007d20d97d0bf7  vmovaps [rsp+0xC0], xmm12
00007d20d97d0c00  vmovaps [rsp+0xD0], xmm14
00007d20d97d0c09  vmovaps [rsp+0xE0], xmm15
00007d20d97d0c12  sub rsp, 0x30
00007d20d97d0c16  movaps [rsp], xmm13
00007d20d97d0c1b  movaps [rsp+0x10], xmm14
00007d20d97d0c21  movaps [rsp+0x20], xmm2
00007d20d97d0c26  lea rdi, [rsp]
00007d20d97d0c2a  mov esi, 0x00
00007d20d97d0c2f  mov rax, 0x5EFBF4CF6530
00007d20d97d0c39  call rax
00007d20d97d0c3b  movaps xmm13, [rsp]
00007d20d97d0c40  add rsp, 0x30
00007d20d97d0c44  vmovaps xmm0, [rsp]
00007d20d97d0c49  vmovaps xmm1, [rsp+0x10]
00007d20d97d0c4f  vmovaps xmm2, [rsp+0x20]
00007d20d97d0c55  vmovaps xmm3, [rsp+0x30]
00007d20d97d0c5b  vmovaps xmm4, [rsp+0x40]
00007d20d97d0c61  vmovaps xmm5, [rsp+0x50]
00007d20d97d0c67  vmovaps xmm6, [rsp+0x60]
00007d20d97d0c6d  vmovaps xmm7, [rsp+0x70]
00007d20d97d0c73  vmovaps xmm8, [rsp+0x80]
00007d20d97d0c7c  vmovaps xmm9, [rsp+0x90]
00007d20d97d0c85  vmovaps xmm10, [rsp+0xA0]
00007d20d97d0c8e  vmovaps xmm11, [rsp+0xB0]
00007d20d97d0c97  vmovaps xmm12, [rsp+0xC0]
00007d20d97d0ca0  vmovaps xmm14, [rsp+0xD0]
00007d20d97d0ca9  vmovaps xmm15, [rsp+0xE0]
00007d20d97d0cb2  add rsp, 0xF0
00007d20d97d0cb9  pop r11
00007d20d97d0cbb  pop r10
00007d20d97d0cbd  pop r9
00007d20d97d0cbf  pop r8
00007d20d97d0cc1  pop rsi
00007d20d97d0cc2  pop rdi
00007d20d97d0cc3  pop rdx
00007d20d97d0cc4  pop rcx
00007d20d97d0cc5  pop rax
00007d20d97d0cc6  add rsp, 0x08
00007d20d97d0cca  jmp 0x00007D20D97CF64C
00007d20d97d0ccf  sub rsp, 0x08
00007d20d97d0cd3  push rax
00007d20d97d0cd4  push rcx
00007d20d97d0cd5  push rdx
00007d20d97d0cd6  push rdi
00007d20d97d0cd7  push rsi
00007d20d97d0cd8  push r8
00007d20d97d0cda  push r9
00007d20d97d0cdc  push r10
00007d20d97d0cde  push r11
00007d20d97d0ce0  sub rsp, 0xF0
00007d20d97d0ce7  vmovaps [rsp], xmm0
00007d20d97d0cec  vmovaps [rsp+0x10], xmm2
00007d20d97d0cf2  vmovaps [rsp+0x20], xmm3
00007d20d97d0cf8  vmovaps [rsp+0x30], xmm4
00007d20d97d0cfe  vmovaps [rsp+0x40], xmm5
00007d20d97d0d04  vmovaps [rsp+0x50], xmm6
00007d20d97d0d0a  vmovaps [rsp+0x60], xmm7
00007d20d97d0d10  vmovaps [rsp+0x70], xmm8
00007d20d97d0d16  vmovaps [rsp+0x80], xmm9
00007d20d97d0d1f  vmovaps [rsp+0x90], xmm10
00007d20d97d0d28  vmovaps [rsp+0xA0], xmm11
00007d20d97d0d31  vmovaps [rsp+0xB0], xmm12
00007d20d97d0d3a  vmovaps [rsp+0xC0], xmm13
00007d20d97d0d43  vmovaps [rsp+0xD0], xmm14
00007d20d97d0d4c  vmovaps [rsp+0xE0], xmm15
00007d20d97d0d55  sub rsp, 0x30
00007d20d97d0d59  movaps [rsp], xmm1
00007d20d97d0d5d  movaps [rsp+0x10], xmm10
00007d20d97d0d63  movaps [rsp+0x20], xmm2
00007d20d97d0d68  lea rdi, [rsp]
00007d20d97d0d6c  mov esi, 0x00
00007d20d97d0d71  mov rax, 0x5EFBF4CF6530
00007d20d97d0d7b  call rax
00007d20d97d0d7d  movaps xmm1, [rsp]
00007d20d97d0d81  add rsp, 0x30
00007d20d97d0d85  vmovaps xmm0, [rsp]
00007d20d97d0d8a  vmovaps xmm2, [rsp+0x10]
00007d20d97d0d90  vmovaps xmm3, [rsp+0x20]
00007d20d97d0d96  vmovaps xmm4, [rsp+0x30]
00007d20d97d0d9c  vmovaps xmm5, [rsp+0x40]
00007d20d97d0da2  vmovaps xmm6, [rsp+0x50]
00007d20d97d0da8  vmovaps xmm7, [rsp+0x60]
00007d20d97d0dae  vmovaps xmm8, [rsp+0x70]
00007d20d97d0db4  vmovaps xmm9, [rsp+0x80]
00007d20d97d0dbd  vmovaps xmm10, [rsp+0x90]
00007d20d97d0dc6  vmovaps xmm11, [rsp+0xA0]
00007d20d97d0dcf  vmovaps xmm12, [rsp+0xB0]
00007d20d97d0dd8  vmovaps xmm13, [rsp+0xC0]
00007d20d97d0de1  vmovaps xmm14, [rsp+0xD0]
00007d20d97d0dea  vmovaps xmm15, [rsp+0xE0]
00007d20d97d0df3  add rsp, 0xF0
00007d20d97d0dfa  pop r11
00007d20d97d0dfc  pop r10
00007d20d97d0dfe  pop r9
00007d20d97d0e00  pop r8
00007d20d97d0e02  pop rsi
00007d20d97d0e03  pop rdi
00007d20d97d0e04  pop rdx
00007d20d97d0e05  pop rcx
00007d20d97d0e06  pop rax
00007d20d97d0e07  add rsp, 0x08
00007d20d97d0e0b  jmp 0x00007D20D97CF6B4
00007d20d97d0e10  sub rsp, 0x08
00007d20d97d0e14  push rax
00007d20d97d0e15  push rcx
00007d20d97d0e16  push rdx
00007d20d97d0e17  push rdi
00007d20d97d0e18  push rsi
00007d20d97d0e19  push r8
00007d20d97d0e1b  push r9
00007d20d97d0e1d  push r10
00007d20d97d0e1f  push r11
00007d20d97d0e21  sub rsp, 0xF0
00007d20d97d0e28  vmovaps [rsp], xmm0
00007d20d97d0e2d  vmovaps [rsp+0x10], xmm1
00007d20d97d0e33  vmovaps [rsp+0x20], xmm2
00007d20d97d0e39  vmovaps [rsp+0x30], xmm3
00007d20d97d0e3f  vmovaps [rsp+0x40], xmm4
00007d20d97d0e45  vmovaps [rsp+0x50], xmm5
00007d20d97d0e4b  vmovaps [rsp+0x60], xmm6
00007d20d97d0e51  vmovaps [rsp+0x70], xmm7
00007d20d97d0e57  vmovaps [rsp+0x80], xmm8
00007d20d97d0e60  vmovaps [rsp+0x90], xmm9
00007d20d97d0e69  vmovaps [rsp+0xA0], xmm10
00007d20d97d0e72  vmovaps [rsp+0xB0], xmm11
00007d20d97d0e7b  vmovaps [rsp+0xC0], xmm12
00007d20d97d0e84  vmovaps [rsp+0xD0], xmm13
00007d20d97d0e8d  vmovaps [rsp+0xE0], xmm14
00007d20d97d0e96  sub rsp, 0x30
00007d20d97d0e9a  movaps [rsp], xmm15
00007d20d97d0e9f  movaps [rsp+0x10], xmm10
00007d20d97d0ea5  movaps [rsp+0x20], xmm2
00007d20d97d0eaa  lea rdi, [rsp]
00007d20d97d0eae  mov esi, 0x00
00007d20d97d0eb3  mov rax, 0x5EFBF4CF6530
00007d20d97d0ebd  call rax
00007d20d97d0ebf  movaps xmm15, [rsp]
00007d20d97d0ec4  add rsp, 0x30
00007d20d97d0ec8  vmovaps xmm0, [rsp]
00007d20d97d0ecd  vmovaps xmm1, [rsp+0x10]
00007d20d97d0ed3  vmovaps xmm2, [rsp+0x20]
00007d20d97d0ed9  vmovaps xmm3, [rsp+0x30]
00007d20d97d0edf  vmovaps xmm4, [rsp+0x40]
00007d20d97d0ee5  vmovaps xmm5, [rsp+0x50]
00007d20d97d0eeb  vmovaps xmm6, [rsp+0x60]
00007d20d97d0ef1  vmovaps xmm7, [rsp+0x70]
00007d20d97d0ef7  vmovaps xmm8, [rsp+0x80]
00007d20d97d0f00  vmovaps xmm9, [rsp+0x90]
00007d20d97d0f09  vmovaps xmm10, [rsp+0xA0]
00007d20d97d0f12  vmovaps xmm11, [rsp+0xB0]
00007d20d97d0f1b  vmovaps xmm12, [rsp+0xC0]
00007d20d97d0f24  vmovaps xmm13, [rsp+0xD0]
00007d20d97d0f2d  vmovaps xmm14, [rsp+0xE0]
00007d20d97d0f36  add rsp, 0xF0
00007d20d97d0f3d  pop r11
00007d20d97d0f3f  pop r10
00007d20d97d0f41  pop r9
00007d20d97d0f43  pop r8
00007d20d97d0f45  pop rsi
00007d20d97d0f46  pop rdi
00007d20d97d0f47  pop rdx
00007d20d97d0f48  pop rcx
00007d20d97d0f49  pop rax
00007d20d97d0f4a  add rsp, 0x08
00007d20d97d0f4e  jmp 0x00007D20D97CF706
00007d20d97d0f53  sub rsp, 0x08
00007d20d97d0f57  push rax
00007d20d97d0f58  push rcx
00007d20d97d0f59  push rdx
00007d20d97d0f5a  push rdi
00007d20d97d0f5b  push rsi
00007d20d97d0f5c  push r8
00007d20d97d0f5e  push r9
00007d20d97d0f60  push r10
00007d20d97d0f62  push r11
00007d20d97d0f64  sub rsp, 0xF0
00007d20d97d0f6b  vmovaps [rsp], xmm0
00007d20d97d0f70  vmovaps [rsp+0x10], xmm2
00007d20d97d0f76  vmovaps [rsp+0x20], xmm3
00007d20d97d0f7c  vmovaps [rsp+0x30], xmm4
00007d20d97d0f82  vmovaps [rsp+0x40], xmm5
00007d20d97d0f88  vmovaps [rsp+0x50], xmm6
00007d20d97d0f8e  vmovaps [rsp+0x60], xmm7
00007d20d97d0f94  vmovaps [rsp+0x70], xmm8
00007d20d97d0f9a  vmovaps [rsp+0x80], xmm9
00007d20d97d0fa3  vmovaps [rsp+0x90], xmm10
00007d20d97d0fac  vmovaps [rsp+0xA0], xmm11
00007d20d97d0fb5  vmovaps [rsp+0xB0], xmm12
00007d20d97d0fbe  vmovaps [rsp+0xC0], xmm13
00007d20d97d0fc7  vmovaps [rsp+0xD0], xmm14
00007d20d97d0fd0  vmovaps [rsp+0xE0], xmm15
00007d20d97d0fd9  sub rsp, 0x30
00007d20d97d0fdd  movaps [rsp], xmm1
00007d20d97d0fe1  movaps [rsp+0x10], xmm10
00007d20d97d0fe7  movaps [rsp+0x20], xmm12
00007d20d97d0fed  lea rdi, [rsp]
00007d20d97d0ff1  mov esi, 0x00
00007d20d97d0ff6  mov rax, 0x5EFBF4CF6530
00007d20d97d1000  call rax
00007d20d97d1002  movaps xmm1, [rsp]
00007d20d97d1006  add rsp, 0x30
00007d20d97d100a  vmovaps xmm0, [rsp]
00007d20d97d100f  vmovaps xmm2, [rsp+0x10]
00007d20d97d1015  vmovaps xmm3, [rsp+0x20]
00007d20d97d101b  vmovaps xmm4, [rsp+0x30]
00007d20d97d1021  vmovaps xmm5, [rsp+0x40]
00007d20d97d1027  vmovaps xmm6, [rsp+0x50]
00007d20d97d102d  vmovaps xmm7, [rsp+0x60]
00007d20d97d1033  vmovaps xmm8, [rsp+0x70]
00007d20d97d1039  vmovaps xmm9, [rsp+0x80]
00007d20d97d1042  vmovaps xmm10, [rsp+0x90]
00007d20d97d104b  vmovaps xmm11, [rsp+0xA0]
00007d20d97d1054  vmovaps xmm12, [rsp+0xB0]
00007d20d97d105d  vmovaps xmm13, [rsp+0xC0]
00007d20d97d1066  vmovaps xmm14, [rsp+0xD0]
00007d20d97d106f  vmovaps xmm15, [rsp+0xE0]
00007d20d97d1078  add rsp, 0xF0
00007d20d97d107f  pop r11
00007d20d97d1081  pop r10
00007d20d97d1083  pop r9
00007d20d97d1085  pop r8
00007d20d97d1087  pop rsi
00007d20d97d1088  pop rdi
00007d20d97d1089  pop rdx
00007d20d97d108a  pop rcx
00007d20d97d108b  pop rax
00007d20d97d108c  add rsp, 0x08
00007d20d97d1090  jmp 0x00007D20D97CF732
00007d20d97d1095  sub rsp, 0x08
00007d20d97d1099  push rax
00007d20d97d109a  push rcx
00007d20d97d109b  push rdx
00007d20d97d109c  push rdi
00007d20d97d109d  push rsi
00007d20d97d109e  push r8
00007d20d97d10a0  push r9
00007d20d97d10a2  push r10
00007d20d97d10a4  push r11
00007d20d97d10a6  sub rsp, 0xF0
00007d20d97d10ad  vmovaps [rsp], xmm0
00007d20d97d10b2  vmovaps [rsp+0x10], xmm1
00007d20d97d10b8  vmovaps [rsp+0x20], xmm2
00007d20d97d10be  vmovaps [rsp+0x30], xmm3
00007d20d97d10c4  vmovaps [rsp+0x40], xmm4
00007d20d97d10ca  vmovaps [rsp+0x50], xmm5
00007d20d97d10d0  vmovaps [rsp+0x60], xmm6
00007d20d97d10d6  vmovaps [rsp+0x70], xmm7
00007d20d97d10dc  vmovaps [rsp+0x80], xmm8
00007d20d97d10e5  vmovaps [rsp+0x90], xmm9
00007d20d97d10ee  vmovaps [rsp+0xA0], xmm10
00007d20d97d10f7  vmovaps [rsp+0xB0], xmm11
00007d20d97d1100  vmovaps [rsp+0xC0], xmm12
00007d20d97d1109  vmovaps [rsp+0xD0], xmm13
00007d20d97d1112  vmovaps [rsp+0xE0], xmm14
00007d20d97d111b  sub rsp, 0x30
00007d20d97d111f  movaps [rsp], xmm15
00007d20d97d1124  movaps [rsp+0x10], xmm10
00007d20d97d112a  movaps [rsp+0x20], xmm12
00007d20d97d1130  lea rdi, [rsp]
00007d20d97d1134  mov esi, 0x00
00007d20d97d1139  mov rax, 0x5EFBF4CF6530
00007d20d97d1143  call rax
00007d20d97d1145  movaps xmm15, [rsp]
00007d20d97d114a  add rsp, 0x30
00007d20d97d114e  vmovaps xmm0, [rsp]
00007d20d97d1153  vmovaps xmm1, [rsp+0x10]
00007d20d97d1159  vmovaps xmm2, [rsp+0x20]
00007d20d97d115f  vmovaps xmm3, [rsp+0x30]
00007d20d97d1165  vmovaps xmm4, [rsp+0x40]
00007d20d97d116b  vmovaps xmm5, [rsp+0x50]
00007d20d97d1171  vmovaps xmm6, [rsp+0x60]
00007d20d97d1177  vmovaps xmm7, [rsp+0x70]
00007d20d97d117d  vmovaps xmm8, [rsp+0x80]
00007d20d97d1186  vmovaps xmm9, [rsp+0x90]
00007d20d97d118f  vmovaps xmm10, [rsp+0xA0]
00007d20d97d1198  vmovaps xmm11, [rsp+0xB0]
00007d20d97d11a1  vmovaps xmm12, [rsp+0xC0]
00007d20d97d11aa  vmovaps xmm13, [rsp+0xD0]
00007d20d97d11b3  vmovaps xmm14, [rsp+0xE0]
00007d20d97d11bc  add rsp, 0xF0
00007d20d97d11c3  pop r11
00007d20d97d11c5  pop r10
00007d20d97d11c7  pop r9
00007d20d97d11c9  pop r8
00007d20d97d11cb  pop rsi
00007d20d97d11cc  pop rdi
00007d20d97d11cd  pop rdx
00007d20d97d11ce  pop rcx
00007d20d97d11cf  pop rax
00007d20d97d11d0  add rsp, 0x08
00007d20d97d11d4  jmp 0x00007D20D97CF75E
00007d20d97d11d9  call 0x00007D20D95FF430
00007d20d97d11de  jmp 0x00007D20D97CF7EE
00007d20d97d11e3  call 0x00007D20D95FF430
00007d20d97d11e8  jmp 0x00007D20D97CF801
00007d20d97d11ed  sub rsp, 0x08
00007d20d97d11f1  push rax
00007d20d97d11f2  push rcx
00007d20d97d11f3  push rdx
00007d20d97d11f4  push rdi
00007d20d97d11f5  push rsi
00007d20d97d11f6  push r8
00007d20d97d11f8  push r9
00007d20d97d11fa  push r10
00007d20d97d11fc  push r11
00007d20d97d11fe  sub rsp, 0xF0
00007d20d97d1205  vmovaps [rsp], xmm0
00007d20d97d120a  vmovaps [rsp+0x10], xmm2
00007d20d97d1210  vmovaps [rsp+0x20], xmm3
00007d20d97d1216  vmovaps [rsp+0x30], xmm4
00007d20d97d121c  vmovaps [rsp+0x40], xmm5
00007d20d97d1222  vmovaps [rsp+0x50], xmm6
00007d20d97d1228  vmovaps [rsp+0x60], xmm7
00007d20d97d122e  vmovaps [rsp+0x70], xmm8
00007d20d97d1234  vmovaps [rsp+0x80], xmm9
00007d20d97d123d  vmovaps [rsp+0x90], xmm10
00007d20d97d1246  vmovaps [rsp+0xA0], xmm11
00007d20d97d124f  vmovaps [rsp+0xB0], xmm12
00007d20d97d1258  vmovaps [rsp+0xC0], xmm13
00007d20d97d1261  vmovaps [rsp+0xD0], xmm14
00007d20d97d126a  vmovaps [rsp+0xE0], xmm15
00007d20d97d1273  sub rsp, 0x30
00007d20d97d1277  movaps [rsp], xmm1
00007d20d97d127b  movaps [rsp+0x10], xmm13
00007d20d97d1281  movaps [rsp+0x20], xmm2
00007d20d97d1286  lea rdi, [rsp]
00007d20d97d128a  mov esi, 0x00
00007d20d97d128f  mov rax, 0x5EFBF4CF6530
00007d20d97d1299  call rax
00007d20d97d129b  movaps xmm1, [rsp]
00007d20d97d129f  add rsp, 0x30
00007d20d97d12a3  vmovaps xmm0, [rsp]
00007d20d97d12a8  vmovaps xmm2, [rsp+0x10]
00007d20d97d12ae  vmovaps xmm3, [rsp+0x20]
00007d20d97d12b4  vmovaps xmm4, [rsp+0x30]
00007d20d97d12ba  vmovaps xmm5, [rsp+0x40]
00007d20d97d12c0  vmovaps xmm6, [rsp+0x50]
00007d20d97d12c6  vmovaps xmm7, [rsp+0x60]
00007d20d97d12cc  vmovaps xmm8, [rsp+0x70]
00007d20d97d12d2  vmovaps xmm9, [rsp+0x80]
00007d20d97d12db  vmovaps xmm10, [rsp+0x90]
00007d20d97d12e4  vmovaps xmm11, [rsp+0xA0]
00007d20d97d12ed  vmovaps xmm12, [rsp+0xB0]
00007d20d97d12f6  vmovaps xmm13, [rsp+0xC0]
00007d20d97d12ff  vmovaps xmm14, [rsp+0xD0]
00007d20d97d1308  vmovaps xmm15, [rsp+0xE0]
00007d20d97d1311  add rsp, 0xF0
00007d20d97d1318  pop r11
00007d20d97d131a  pop r10
00007d20d97d131c  pop r9
00007d20d97d131e  pop r8
00007d20d97d1320  pop rsi
00007d20d97d1321  pop rdi
00007d20d97d1322  pop rdx
00007d20d97d1323  pop rcx
00007d20d97d1324  pop rax
00007d20d97d1325  add rsp, 0x08
00007d20d97d1329  jmp 0x00007D20D97CF82C
00007d20d97d132e  call 0x00007D20D960E760
00007d20d97d1333  jmp 0x00007D20D97CF839
00007d20d97d1338  sub rsp, 0x08
00007d20d97d133c  push rax
00007d20d97d133d  push rcx
00007d20d97d133e  push rdx
00007d20d97d133f  push rdi
00007d20d97d1340  push rsi
00007d20d97d1341  push r8
00007d20d97d1343  push r9
00007d20d97d1345  push r10
00007d20d97d1347  push r11
00007d20d97d1349  sub rsp, 0xF0
00007d20d97d1350  vmovaps [rsp], xmm0
00007d20d97d1355  vmovaps [rsp+0x10], xmm1
00007d20d97d135b  vmovaps [rsp+0x20], xmm2
00007d20d97d1361  vmovaps [rsp+0x30], xmm3
00007d20d97d1367  vmovaps [rsp+0x40], xmm4
00007d20d97d136d  vmovaps [rsp+0x50], xmm5
00007d20d97d1373  vmovaps [rsp+0x60], xmm6
00007d20d97d1379  vmovaps [rsp+0x70], xmm7
00007d20d97d137f  vmovaps [rsp+0x80], xmm8
00007d20d97d1388  vmovaps [rsp+0x90], xmm9
00007d20d97d1391  vmovaps [rsp+0xA0], xmm10
00007d20d97d139a  vmovaps [rsp+0xB0], xmm11
00007d20d97d13a3  vmovaps [rsp+0xC0], xmm12
00007d20d97d13ac  vmovaps [rsp+0xD0], xmm14
00007d20d97d13b5  vmovaps [rsp+0xE0], xmm15
00007d20d97d13be  sub rsp, 0x30
00007d20d97d13c2  movaps [rsp], xmm13
00007d20d97d13c7  movaps [rsp+0x10], xmm2
00007d20d97d13cc  movaps [rsp+0x20], xmm1
00007d20d97d13d1  lea rdi, [rsp]
00007d20d97d13d5  mov esi, 0x00
00007d20d97d13da  mov rax, 0x5EFBF4CF6530
00007d20d97d13e4  call rax
00007d20d97d13e6  movaps xmm13, [rsp]
00007d20d97d13eb  add rsp, 0x30
00007d20d97d13ef  vmovaps xmm0, [rsp]
00007d20d97d13f4  vmovaps xmm1, [rsp+0x10]
00007d20d97d13fa  vmovaps xmm2, [rsp+0x20]
00007d20d97d1400  vmovaps xmm3, [rsp+0x30]
00007d20d97d1406  vmovaps xmm4, [rsp+0x40]
00007d20d97d140c  vmovaps xmm5, [rsp+0x50]
00007d20d97d1412  vmovaps xmm6, [rsp+0x60]
00007d20d97d1418  vmovaps xmm7, [rsp+0x70]
00007d20d97d141e  vmovaps xmm8, [rsp+0x80]
00007d20d97d1427  vmovaps xmm9, [rsp+0x90]
00007d20d97d1430  vmovaps xmm10, [rsp+0xA0]
00007d20d97d1439  vmovaps xmm11, [rsp+0xB0]
00007d20d97d1442  vmovaps xmm12, [rsp+0xC0]
00007d20d97d144b  vmovaps xmm14, [rsp+0xD0]
00007d20d97d1454  vmovaps xmm15, [rsp+0xE0]
00007d20d97d145d  add rsp, 0xF0
00007d20d97d1464  pop r11
00007d20d97d1466  pop r10
00007d20d97d1468  pop r9
00007d20d97d146a  pop r8
00007d20d97d146c  pop rsi
00007d20d97d146d  pop rdi
00007d20d97d146e  pop rdx
00007d20d97d146f  pop rcx
00007d20d97d1470  pop rax
00007d20d97d1471  add rsp, 0x08
00007d20d97d1475  jmp 0x00007D20D97CF878
00007d20d97d147a  sub rsp, 0x08
00007d20d97d147e  push rax
00007d20d97d147f  push rcx
00007d20d97d1480  push rdx
00007d20d97d1481  push rdi
00007d20d97d1482  push rsi
00007d20d97d1483  push r8
00007d20d97d1485  push r9
00007d20d97d1487  push r10
00007d20d97d1489  push r11
00007d20d97d148b  sub rsp, 0xF0
00007d20d97d1492  vmovaps [rsp], xmm0
00007d20d97d1497  vmovaps [rsp+0x10], xmm2
00007d20d97d149d  vmovaps [rsp+0x20], xmm3
00007d20d97d14a3  vmovaps [rsp+0x30], xmm4
00007d20d97d14a9  vmovaps [rsp+0x40], xmm5
00007d20d97d14af  vmovaps [rsp+0x50], xmm6
00007d20d97d14b5  vmovaps [rsp+0x60], xmm7
00007d20d97d14bb  vmovaps [rsp+0x70], xmm8
00007d20d97d14c1  vmovaps [rsp+0x80], xmm9
00007d20d97d14ca  vmovaps [rsp+0x90], xmm10
00007d20d97d14d3  vmovaps [rsp+0xA0], xmm11
00007d20d97d14dc  vmovaps [rsp+0xB0], xmm12
00007d20d97d14e5  vmovaps [rsp+0xC0], xmm13
00007d20d97d14ee  vmovaps [rsp+0xD0], xmm14
00007d20d97d14f7  vmovaps [rsp+0xE0], xmm15
00007d20d97d1500  sub rsp, 0x30
00007d20d97d1504  movaps [rsp], xmm1
00007d20d97d1508  movaps [rsp+0x10], xmm15
00007d20d97d150e  movaps [rsp+0x20], xmm2
00007d20d97d1513  lea rdi, [rsp]
00007d20d97d1517  mov esi, 0x00
00007d20d97d151c  mov rax, 0x5EFBF4CF6530
00007d20d97d1526  call rax
00007d20d97d1528  movaps xmm1, [rsp]
00007d20d97d152c  add rsp, 0x30
00007d20d97d1530  vmovaps xmm0, [rsp]
00007d20d97d1535  vmovaps xmm2, [rsp+0x10]
00007d20d97d153b  vmovaps xmm3, [rsp+0x20]
00007d20d97d1541  vmovaps xmm4, [rsp+0x30]
00007d20d97d1547  vmovaps xmm5, [rsp+0x40]
00007d20d97d154d  vmovaps xmm6, [rsp+0x50]
00007d20d97d1553  vmovaps xmm7, [rsp+0x60]
00007d20d97d1559  vmovaps xmm8, [rsp+0x70]
00007d20d97d155f  vmovaps xmm9, [rsp+0x80]
00007d20d97d1568  vmovaps xmm10, [rsp+0x90]
00007d20d97d1571  vmovaps xmm11, [rsp+0xA0]
00007d20d97d157a  vmovaps xmm12, [rsp+0xB0]
00007d20d97d1583  vmovaps xmm13, [rsp+0xC0]
00007d20d97d158c  vmovaps xmm14, [rsp+0xD0]
00007d20d97d1595  vmovaps xmm15, [rsp+0xE0]
00007d20d97d159e  add rsp, 0xF0
00007d20d97d15a5  pop r11
00007d20d97d15a7  pop r10
00007d20d97d15a9  pop r9
00007d20d97d15ab  pop r8
00007d20d97d15ad  pop rsi
00007d20d97d15ae  pop rdi
00007d20d97d15af  pop rdx
00007d20d97d15b0  pop rcx
00007d20d97d15b1  pop rax
00007d20d97d15b2  add rsp, 0x08
00007d20d97d15b6  jmp 0x00007D20D97CF8AC
00007d20d97d15bb  sub rsp, 0x08
00007d20d97d15bf  push rax
00007d20d97d15c0  push rcx
00007d20d97d15c1  push rdx
00007d20d97d15c2  push rdi
00007d20d97d15c3  push rsi
00007d20d97d15c4  push r8
00007d20d97d15c6  push r9
00007d20d97d15c8  push r10
00007d20d97d15ca  push r11
00007d20d97d15cc  sub rsp, 0xF0
00007d20d97d15d3  vmovaps [rsp], xmm0
00007d20d97d15d8  vmovaps [rsp+0x10], xmm1
00007d20d97d15de  vmovaps [rsp+0x20], xmm2
00007d20d97d15e4  vmovaps [rsp+0x30], xmm3
00007d20d97d15ea  vmovaps [rsp+0x40], xmm4
00007d20d97d15f0  vmovaps [rsp+0x50], xmm5
00007d20d97d15f6  vmovaps [rsp+0x60], xmm6
00007d20d97d15fc  vmovaps [rsp+0x70], xmm7
00007d20d97d1602  vmovaps [rsp+0x80], xmm8
00007d20d97d160b  vmovaps [rsp+0x90], xmm9
00007d20d97d1614  vmovaps [rsp+0xA0], xmm10
00007d20d97d161d  vmovaps [rsp+0xB0], xmm11
00007d20d97d1626  vmovaps [rsp+0xC0], xmm12
00007d20d97d162f  vmovaps [rsp+0xD0], xmm13
00007d20d97d1638  vmovaps [rsp+0xE0], xmm15
00007d20d97d1641  sub rsp, 0x30
00007d20d97d1645  movaps [rsp], xmm14
00007d20d97d164a  movaps [rsp+0x10], xmm2
00007d20d97d164f  movaps [rsp+0x20], xmm15
00007d20d97d1655  lea rdi, [rsp]
00007d20d97d1659  mov esi, 0x00
00007d20d97d165e  mov rax, 0x5EFBF4CF6530
00007d20d97d1668  call rax
00007d20d97d166a  movaps xmm14, [rsp]
00007d20d97d166f  add rsp, 0x30
00007d20d97d1673  vmovaps xmm0, [rsp]
00007d20d97d1678  vmovaps xmm1, [rsp+0x10]
00007d20d97d167e  vmovaps xmm2, [rsp+0x20]
00007d20d97d1684  vmovaps xmm3, [rsp+0x30]
00007d20d97d168a  vmovaps xmm4, [rsp+0x40]
00007d20d97d1690  vmovaps xmm5, [rsp+0x50]
00007d20d97d1696  vmovaps xmm6, [rsp+0x60]
00007d20d97d169c  vmovaps xmm7, [rsp+0x70]
00007d20d97d16a2  vmovaps xmm8, [rsp+0x80]
00007d20d97d16ab  vmovaps xmm9, [rsp+0x90]
00007d20d97d16b4  vmovaps xmm10, [rsp+0xA0]
00007d20d97d16bd  vmovaps xmm11, [rsp+0xB0]
00007d20d97d16c6  vmovaps xmm12, [rsp+0xC0]
00007d20d97d16cf  vmovaps xmm13, [rsp+0xD0]
00007d20d97d16d8  vmovaps xmm15, [rsp+0xE0]
00007d20d97d16e1  add rsp, 0xF0
00007d20d97d16e8  pop r11
00007d20d97d16ea  pop r10
00007d20d97d16ec  pop r9
00007d20d97d16ee  pop r8
00007d20d97d16f0  pop rsi
00007d20d97d16f1  pop rdi
00007d20d97d16f2  pop rdx
00007d20d97d16f3  pop rcx
00007d20d97d16f4  pop rax
00007d20d97d16f5  add rsp, 0x08
00007d20d97d16f9  jmp 0x00007D20D97CF8E7
00007d20d97d16fe  sub rsp, 0x08
00007d20d97d1702  push rax
00007d20d97d1703  push rcx
00007d20d97d1704  push rdx
00007d20d97d1705  push rdi
00007d20d97d1706  push rsi
00007d20d97d1707  push r8
00007d20d97d1709  push r9
00007d20d97d170b  push r10
00007d20d97d170d  push r11
00007d20d97d170f  sub rsp, 0xF0
00007d20d97d1716  vmovaps [rsp], xmm0
00007d20d97d171b  vmovaps [rsp+0x10], xmm1
00007d20d97d1721  vmovaps [rsp+0x20], xmm2
00007d20d97d1727  vmovaps [rsp+0x30], xmm3
00007d20d97d172d  vmovaps [rsp+0x40], xmm4
00007d20d97d1733  vmovaps [rsp+0x50], xmm5
00007d20d97d1739  vmovaps [rsp+0x60], xmm6
00007d20d97d173f  vmovaps [rsp+0x70], xmm7
00007d20d97d1745  vmovaps [rsp+0x80], xmm8
00007d20d97d174e  vmovaps [rsp+0x90], xmm9
00007d20d97d1757  vmovaps [rsp+0xA0], xmm10
00007d20d97d1760  vmovaps [rsp+0xB0], xmm11
00007d20d97d1769  vmovaps [rsp+0xC0], xmm12
00007d20d97d1772  vmovaps [rsp+0xD0], xmm13
00007d20d97d177b  vmovaps [rsp+0xE0], xmm14
00007d20d97d1784  sub rsp, 0x30
00007d20d97d1788  movaps [rsp], xmm15
00007d20d97d178d  movaps [rsp+0x10], xmm2
00007d20d97d1792  movaps [rsp+0x20], xmm1
00007d20d97d1797  lea rdi, [rsp]
00007d20d97d179b  mov esi, 0x00
00007d20d97d17a0  mov rax, 0x5EFBF4CF6530
00007d20d97d17aa  call rax
00007d20d97d17ac  movaps xmm15, [rsp]
00007d20d97d17b1  add rsp, 0x30
00007d20d97d17b5  vmovaps xmm0, [rsp]
00007d20d97d17ba  vmovaps xmm1, [rsp+0x10]
00007d20d97d17c0  vmovaps xmm2, [rsp+0x20]
00007d20d97d17c6  vmovaps xmm3, [rsp+0x30]
00007d20d97d17cc  vmovaps xmm4, [rsp+0x40]
00007d20d97d17d2  vmovaps xmm5, [rsp+0x50]
00007d20d97d17d8  vmovaps xmm6, [rsp+0x60]
00007d20d97d17de  vmovaps xmm7, [rsp+0x70]
00007d20d97d17e4  vmovaps xmm8, [rsp+0x80]
00007d20d97d17ed  vmovaps xmm9, [rsp+0x90]
00007d20d97d17f6  vmovaps xmm10, [rsp+0xA0]
00007d20d97d17ff  vmovaps xmm11, [rsp+0xB0]
00007d20d97d1808  vmovaps xmm12, [rsp+0xC0]
00007d20d97d1811  vmovaps xmm13, [rsp+0xD0]
00007d20d97d181a  vmovaps xmm14, [rsp+0xE0]
00007d20d97d1823  add rsp, 0xF0
00007d20d97d182a  pop r11
00007d20d97d182c  pop r10
00007d20d97d182e  pop r9
00007d20d97d1830  pop r8
00007d20d97d1832  pop rsi
00007d20d97d1833  pop rdi
00007d20d97d1834  pop rdx
00007d20d97d1835  pop rcx
00007d20d97d1836  pop rax
00007d20d97d1837  add rsp, 0x08
00007d20d97d183b  jmp 0x00007D20D97CF923
00007d20d97d1840  call 0x00007D20D95FF430
00007d20d97d1845  jmp 0x00007D20D97CF930
00007d20d97d184a  sub rsp, 0x08
00007d20d97d184e  push rax
00007d20d97d184f  push rcx
00007d20d97d1850  push rdx
00007d20d97d1851  push rdi
00007d20d97d1852  push rsi
00007d20d97d1853  push r8
00007d20d97d1855  push r9
00007d20d97d1857  push r10
00007d20d97d1859  push r11
00007d20d97d185b  sub rsp, 0xF0
00007d20d97d1862  vmovaps [rsp], xmm0
00007d20d97d1867  vmovaps [rsp+0x10], xmm1
00007d20d97d186d  vmovaps [rsp+0x20], xmm3
00007d20d97d1873  vmovaps [rsp+0x30], xmm4
00007d20d97d1879  vmovaps [rsp+0x40], xmm5
00007d20d97d187f  vmovaps [rsp+0x50], xmm6
00007d20d97d1885  vmovaps [rsp+0x60], xmm7
00007d20d97d188b  vmovaps [rsp+0x70], xmm8
00007d20d97d1891  vmovaps [rsp+0x80], xmm9
00007d20d97d189a  vmovaps [rsp+0x90], xmm10
00007d20d97d18a3  vmovaps [rsp+0xA0], xmm11
00007d20d97d18ac  vmovaps [rsp+0xB0], xmm12
00007d20d97d18b5  vmovaps [rsp+0xC0], xmm13
00007d20d97d18be  vmovaps [rsp+0xD0], xmm14
00007d20d97d18c7  vmovaps [rsp+0xE0], xmm15
00007d20d97d18d0  sub rsp, 0x30
00007d20d97d18d4  movaps [rsp], xmm2
00007d20d97d18d8  movaps [rsp+0x10], xmm1
00007d20d97d18dd  movaps [rsp+0x20], xmm14
00007d20d97d18e3  lea rdi, [rsp]
00007d20d97d18e7  mov esi, 0x00
00007d20d97d18ec  mov rax, 0x5EFBF4CF6530
00007d20d97d18f6  call rax
00007d20d97d18f8  movaps xmm2, [rsp]
00007d20d97d18fc  add rsp, 0x30
00007d20d97d1900  vmovaps xmm0, [rsp]
00007d20d97d1905  vmovaps xmm1, [rsp+0x10]
00007d20d97d190b  vmovaps xmm3, [rsp+0x20]
00007d20d97d1911  vmovaps xmm4, [rsp+0x30]
00007d20d97d1917  vmovaps xmm5, [rsp+0x40]
00007d20d97d191d  vmovaps xmm6, [rsp+0x50]
00007d20d97d1923  vmovaps xmm7, [rsp+0x60]
00007d20d97d1929  vmovaps xmm8, [rsp+0x70]
00007d20d97d192f  vmovaps xmm9, [rsp+0x80]
00007d20d97d1938  vmovaps xmm10, [rsp+0x90]
00007d20d97d1941  vmovaps xmm11, [rsp+0xA0]
00007d20d97d194a  vmovaps xmm12, [rsp+0xB0]
00007d20d97d1953  vmovaps xmm13, [rsp+0xC0]
00007d20d97d195c  vmovaps xmm14, [rsp+0xD0]
00007d20d97d1965  vmovaps xmm15, [rsp+0xE0]
00007d20d97d196e  add rsp, 0xF0
00007d20d97d1975  pop r11
00007d20d97d1977  pop r10
00007d20d97d1979  pop r9
00007d20d97d197b  pop r8
00007d20d97d197d  pop rsi
00007d20d97d197e  pop rdi
00007d20d97d197f  pop rdx
00007d20d97d1980  pop rcx
00007d20d97d1981  pop rax
00007d20d97d1982  add rsp, 0x08
00007d20d97d1986  jmp 0x00007D20D97CF96D
00007d20d97d198b  sub rsp, 0x08
00007d20d97d198f  push rax
00007d20d97d1990  push rcx
00007d20d97d1991  push rdx
00007d20d97d1992  push rdi
00007d20d97d1993  push rsi
00007d20d97d1994  push r8
00007d20d97d1996  push r9
00007d20d97d1998  push r10
00007d20d97d199a  push r11
00007d20d97d199c  sub rsp, 0xF0
00007d20d97d19a3  vmovaps [rsp], xmm0
00007d20d97d19a8  vmovaps [rsp+0x10], xmm1
00007d20d97d19ae  vmovaps [rsp+0x20], xmm2
00007d20d97d19b4  vmovaps [rsp+0x30], xmm3
00007d20d97d19ba  vmovaps [rsp+0x40], xmm4
00007d20d97d19c0  vmovaps [rsp+0x50], xmm5
00007d20d97d19c6  vmovaps [rsp+0x60], xmm6
00007d20d97d19cc  vmovaps [rsp+0x70], xmm7
00007d20d97d19d2  vmovaps [rsp+0x80], xmm8
00007d20d97d19db  vmovaps [rsp+0x90], xmm9
00007d20d97d19e4  vmovaps [rsp+0xA0], xmm10
00007d20d97d19ed  vmovaps [rsp+0xB0], xmm11
00007d20d97d19f6  vmovaps [rsp+0xC0], xmm12
00007d20d97d19ff  vmovaps [rsp+0xD0], xmm13
00007d20d97d1a08  vmovaps [rsp+0xE0], xmm14
00007d20d97d1a11  sub rsp, 0x30
00007d20d97d1a15  movaps [rsp], xmm15
00007d20d97d1a1a  movaps [rsp+0x10], xmm14
00007d20d97d1a20  movaps [rsp+0x20], xmm1
00007d20d97d1a25  lea rdi, [rsp]
00007d20d97d1a29  mov esi, 0x00
00007d20d97d1a2e  mov rax, 0x5EFBF4CF6530
00007d20d97d1a38  call rax
00007d20d97d1a3a  movaps xmm15, [rsp]
00007d20d97d1a3f  add rsp, 0x30
00007d20d97d1a43  vmovaps xmm0, [rsp]
00007d20d97d1a48  vmovaps xmm1, [rsp+0x10]
00007d20d97d1a4e  vmovaps xmm2, [rsp+0x20]
00007d20d97d1a54  vmovaps xmm3, [rsp+0x30]
00007d20d97d1a5a  vmovaps xmm4, [rsp+0x40]
00007d20d97d1a60  vmovaps xmm5, [rsp+0x50]
00007d20d97d1a66  vmovaps xmm6, [rsp+0x60]
00007d20d97d1a6c  vmovaps xmm7, [rsp+0x70]
00007d20d97d1a72  vmovaps xmm8, [rsp+0x80]
00007d20d97d1a7b  vmovaps xmm9, [rsp+0x90]
00007d20d97d1a84  vmovaps xmm10, [rsp+0xA0]
00007d20d97d1a8d  vmovaps xmm11, [rsp+0xB0]
00007d20d97d1a96  vmovaps xmm12, [rsp+0xC0]
00007d20d97d1a9f  vmovaps xmm13, [rsp+0xD0]
00007d20d97d1aa8  vmovaps xmm14, [rsp+0xE0]
00007d20d97d1ab1  add rsp, 0xF0
00007d20d97d1ab8  pop r11
00007d20d97d1aba  pop r10
00007d20d97d1abc  pop r9
00007d20d97d1abe  pop r8
00007d20d97d1ac0  pop rsi
00007d20d97d1ac1  pop rdi
00007d20d97d1ac2  pop rdx
00007d20d97d1ac3  pop rcx
00007d20d97d1ac4  pop rax
00007d20d97d1ac5  add rsp, 0x08
00007d20d97d1ac9  jmp 0x00007D20D97CF9E7
00007d20d97d1ace  call 0x00007D20D95FF430
00007d20d97d1ad3  jmp 0x00007D20D97CF9F4
00007d20d97d1ad8  sub rsp, 0x08
00007d20d97d1adc  push rax
00007d20d97d1add  push rcx
00007d20d97d1ade  push rdx
00007d20d97d1adf  push rdi
00007d20d97d1ae0  push rsi
00007d20d97d1ae1  push r8
00007d20d97d1ae3  push r9
00007d20d97d1ae5  push r10
00007d20d97d1ae7  push r11
00007d20d97d1ae9  sub rsp, 0xF0
00007d20d97d1af0  vmovaps [rsp], xmm0
00007d20d97d1af5  vmovaps [rsp+0x10], xmm1
00007d20d97d1afb  vmovaps [rsp+0x20], xmm2
00007d20d97d1b01  vmovaps [rsp+0x30], xmm3
00007d20d97d1b07  vmovaps [rsp+0x40], xmm4
00007d20d97d1b0d  vmovaps [rsp+0x50], xmm5
00007d20d97d1b13  vmovaps [rsp+0x60], xmm6
00007d20d97d1b19  vmovaps [rsp+0x70], xmm7
00007d20d97d1b1f  vmovaps [rsp+0x80], xmm8
00007d20d97d1b28  vmovaps [rsp+0x90], xmm9
00007d20d97d1b31  vmovaps [rsp+0xA0], xmm10
00007d20d97d1b3a  vmovaps [rsp+0xB0], xmm11
00007d20d97d1b43  vmovaps [rsp+0xC0], xmm12
00007d20d97d1b4c  vmovaps [rsp+0xD0], xmm13
00007d20d97d1b55  vmovaps [rsp+0xE0], xmm15
00007d20d97d1b5e  sub rsp, 0x30
00007d20d97d1b62  movaps [rsp], xmm14
00007d20d97d1b67  movaps [rsp+0x10], xmm13
00007d20d97d1b6d  movaps [rsp+0x20], xmm1
00007d20d97d1b72  lea rdi, [rsp]
00007d20d97d1b76  mov esi, 0x00
00007d20d97d1b7b  mov rax, 0x5EFBF4CF6530
00007d20d97d1b85  call rax
00007d20d97d1b87  movaps xmm14, [rsp]
00007d20d97d1b8c  add rsp, 0x30
00007d20d97d1b90  vmovaps xmm0, [rsp]
00007d20d97d1b95  vmovaps xmm1, [rsp+0x10]
00007d20d97d1b9b  vmovaps xmm2, [rsp+0x20]
00007d20d97d1ba1  vmovaps xmm3, [rsp+0x30]
00007d20d97d1ba7  vmovaps xmm4, [rsp+0x40]
00007d20d97d1bad  vmovaps xmm5, [rsp+0x50]
00007d20d97d1bb3  vmovaps xmm6, [rsp+0x60]
00007d20d97d1bb9  vmovaps xmm7, [rsp+0x70]
00007d20d97d1bbf  vmovaps xmm8, [rsp+0x80]
00007d20d97d1bc8  vmovaps xmm9, [rsp+0x90]
00007d20d97d1bd1  vmovaps xmm10, [rsp+0xA0]
00007d20d97d1bda  vmovaps xmm11, [rsp+0xB0]
00007d20d97d1be3  vmovaps xmm12, [rsp+0xC0]
00007d20d97d1bec  vmovaps xmm13, [rsp+0xD0]
00007d20d97d1bf5  vmovaps xmm15, [rsp+0xE0]
00007d20d97d1bfe  add rsp, 0xF0
00007d20d97d1c05  pop r11
00007d20d97d1c07  pop r10
00007d20d97d1c09  pop r9
00007d20d97d1c0b  pop r8
00007d20d97d1c0d  pop rsi
00007d20d97d1c0e  pop rdi
00007d20d97d1c0f  pop rdx
00007d20d97d1c10  pop rcx
00007d20d97d1c11  pop rax
00007d20d97d1c12  add rsp, 0x08
00007d20d97d1c16  jmp 0x00007D20D97CFAAF
00007d20d97d1c1b  sub rsp, 0x08
00007d20d97d1c1f  push rax
00007d20d97d1c20  push rcx
00007d20d97d1c21  push rdx
00007d20d97d1c22  push rdi
00007d20d97d1c23  push rsi
00007d20d97d1c24  push r8
00007d20d97d1c26  push r9
00007d20d97d1c28  push r10
00007d20d97d1c2a  push r11
00007d20d97d1c2c  sub rsp, 0xF0
00007d20d97d1c33  vmovaps [rsp], xmm0
00007d20d97d1c38  vmovaps [rsp+0x10], xmm1
00007d20d97d1c3e  vmovaps [rsp+0x20], xmm2
00007d20d97d1c44  vmovaps [rsp+0x30], xmm3
00007d20d97d1c4a  vmovaps [rsp+0x40], xmm4
00007d20d97d1c50  vmovaps [rsp+0x50], xmm5
00007d20d97d1c56  vmovaps [rsp+0x60], xmm6
00007d20d97d1c5c  vmovaps [rsp+0x70], xmm7
00007d20d97d1c62  vmovaps [rsp+0x80], xmm8
00007d20d97d1c6b  vmovaps [rsp+0x90], xmm9
00007d20d97d1c74  vmovaps [rsp+0xA0], xmm10
00007d20d97d1c7d  vmovaps [rsp+0xB0], xmm11
00007d20d97d1c86  vmovaps [rsp+0xC0], xmm12
00007d20d97d1c8f  vmovaps [rsp+0xD0], xmm13
00007d20d97d1c98  vmovaps [rsp+0xE0], xmm14
00007d20d97d1ca1  sub rsp, 0x30
00007d20d97d1ca5  movaps [rsp], xmm15
00007d20d97d1caa  movaps [rsp+0x10], xmm13
00007d20d97d1cb0  movaps [rsp+0x20], xmm1
00007d20d97d1cb5  lea rdi, [rsp]
00007d20d97d1cb9  mov esi, 0x00
00007d20d97d1cbe  mov rax, 0x5EFBF4CF6530
00007d20d97d1cc8  call rax
00007d20d97d1cca  movaps xmm15, [rsp]
00007d20d97d1ccf  add rsp, 0x30
00007d20d97d1cd3  vmovaps xmm0, [rsp]
00007d20d97d1cd8  vmovaps xmm1, [rsp+0x10]
00007d20d97d1cde  vmovaps xmm2, [rsp+0x20]
00007d20d97d1ce4  vmovaps xmm3, [rsp+0x30]
00007d20d97d1cea  vmovaps xmm4, [rsp+0x40]
00007d20d97d1cf0  vmovaps xmm5, [rsp+0x50]
00007d20d97d1cf6  vmovaps xmm6, [rsp+0x60]
00007d20d97d1cfc  vmovaps xmm7, [rsp+0x70]
00007d20d97d1d02  vmovaps xmm8, [rsp+0x80]
00007d20d97d1d0b  vmovaps xmm9, [rsp+0x90]
00007d20d97d1d14  vmovaps xmm10, [rsp+0xA0]
00007d20d97d1d1d  vmovaps xmm11, [rsp+0xB0]
00007d20d97d1d26  vmovaps xmm12, [rsp+0xC0]
00007d20d97d1d2f  vmovaps xmm13, [rsp+0xD0]
00007d20d97d1d38  vmovaps xmm14, [rsp+0xE0]
00007d20d97d1d41  add rsp, 0xF0
00007d20d97d1d48  pop r11
00007d20d97d1d4a  pop r10
00007d20d97d1d4c  pop r9
00007d20d97d1d4e  pop r8
00007d20d97d1d50  pop rsi
00007d20d97d1d51  pop rdi
00007d20d97d1d52  pop rdx
00007d20d97d1d53  pop rcx
00007d20d97d1d54  pop rax
00007d20d97d1d55  add rsp, 0x08
00007d20d97d1d59  jmp 0x00007D20D97CFAEB
00007d20d97d1d5e  call 0x00007D20D95FF430
00007d20d97d1d63  jmp 0x00007D20D97CFAF8
00007d20d97d1d68  sub rsp, 0x08
00007d20d97d1d6c  push rax
00007d20d97d1d6d  push rcx
00007d20d97d1d6e  push rdx
00007d20d97d1d6f  push rdi
00007d20d97d1d70  push rsi
00007d20d97d1d71  push r8
00007d20d97d1d73  push r9
00007d20d97d1d75  push r10
00007d20d97d1d77  push r11
00007d20d97d1d79  sub rsp, 0xF0
00007d20d97d1d80  vmovaps [rsp], xmm0
00007d20d97d1d85  vmovaps [rsp+0x10], xmm1
00007d20d97d1d8b  vmovaps [rsp+0x20], xmm2
00007d20d97d1d91  vmovaps [rsp+0x30], xmm3
00007d20d97d1d97  vmovaps [rsp+0x40], xmm4
00007d20d97d1d9d  vmovaps [rsp+0x50], xmm5
00007d20d97d1da3  vmovaps [rsp+0x60], xmm6
00007d20d97d1da9  vmovaps [rsp+0x70], xmm7
00007d20d97d1daf  vmovaps [rsp+0x80], xmm8
00007d20d97d1db8  vmovaps [rsp+0x90], xmm9
00007d20d97d1dc1  vmovaps [rsp+0xA0], xmm10
00007d20d97d1dca  vmovaps [rsp+0xB0], xmm11
00007d20d97d1dd3  vmovaps [rsp+0xC0], xmm12
00007d20d97d1ddc  vmovaps [rsp+0xD0], xmm13
00007d20d97d1de5  vmovaps [rsp+0xE0], xmm15
00007d20d97d1dee  sub rsp, 0x30
00007d20d97d1df2  movaps [rsp], xmm14
00007d20d97d1df7  movaps [rsp+0x10], xmm13
00007d20d97d1dfd  movaps [rsp+0x20], xmm2
00007d20d97d1e02  lea rdi, [rsp]
00007d20d97d1e06  mov esi, 0x00
00007d20d97d1e0b  mov rax, 0x5EFBF4CF6530
00007d20d97d1e15  call rax
00007d20d97d1e17  movaps xmm14, [rsp]
00007d20d97d1e1c  add rsp, 0x30
00007d20d97d1e20  vmovaps xmm0, [rsp]
00007d20d97d1e25  vmovaps xmm1, [rsp+0x10]
00007d20d97d1e2b  vmovaps xmm2, [rsp+0x20]
00007d20d97d1e31  vmovaps xmm3, [rsp+0x30]
00007d20d97d1e37  vmovaps xmm4, [rsp+0x40]
00007d20d97d1e3d  vmovaps xmm5, [rsp+0x50]
00007d20d97d1e43  vmovaps xmm6, [rsp+0x60]
00007d20d97d1e49  vmovaps xmm7, [rsp+0x70]
00007d20d97d1e4f  vmovaps xmm8, [rsp+0x80]
00007d20d97d1e58  vmovaps xmm9, [rsp+0x90]
00007d20d97d1e61  vmovaps xmm10, [rsp+0xA0]
00007d20d97d1e6a  vmovaps xmm11, [rsp+0xB0]
00007d20d97d1e73  vmovaps xmm12, [rsp+0xC0]
00007d20d97d1e7c  vmovaps xmm13, [rsp+0xD0]
00007d20d97d1e85  vmovaps xmm15, [rsp+0xE0]
00007d20d97d1e8e  add rsp, 0xF0
00007d20d97d1e95  pop r11
00007d20d97d1e97  pop r10
00007d20d97d1e99  pop r9
00007d20d97d1e9b  pop r8
00007d20d97d1e9d  pop rsi
00007d20d97d1e9e  pop rdi
00007d20d97d1e9f  pop rdx
00007d20d97d1ea0  pop rcx
00007d20d97d1ea1  pop rax
00007d20d97d1ea2  add rsp, 0x08
00007d20d97d1ea6  jmp 0x00007D20D97CFB24
00007d20d97d1eab  sub rsp, 0x08
00007d20d97d1eaf  push rax
00007d20d97d1eb0  push rcx
00007d20d97d1eb1  push rdx
00007d20d97d1eb2  push rdi
00007d20d97d1eb3  push rsi
00007d20d97d1eb4  push r8
00007d20d97d1eb6  push r9
00007d20d97d1eb8  push r10
00007d20d97d1eba  push r11
00007d20d97d1ebc  sub rsp, 0xF0
00007d20d97d1ec3  vmovaps [rsp], xmm0
00007d20d97d1ec8  vmovaps [rsp+0x10], xmm2
00007d20d97d1ece  vmovaps [rsp+0x20], xmm3
00007d20d97d1ed4  vmovaps [rsp+0x30], xmm4
00007d20d97d1eda  vmovaps [rsp+0x40], xmm5
00007d20d97d1ee0  vmovaps [rsp+0x50], xmm6
00007d20d97d1ee6  vmovaps [rsp+0x60], xmm7
00007d20d97d1eec  vmovaps [rsp+0x70], xmm8
00007d20d97d1ef2  vmovaps [rsp+0x80], xmm9
00007d20d97d1efb  vmovaps [rsp+0x90], xmm10
00007d20d97d1f04  vmovaps [rsp+0xA0], xmm11
00007d20d97d1f0d  vmovaps [rsp+0xB0], xmm12
00007d20d97d1f16  vmovaps [rsp+0xC0], xmm13
00007d20d97d1f1f  vmovaps [rsp+0xD0], xmm14
00007d20d97d1f28  vmovaps [rsp+0xE0], xmm15
00007d20d97d1f31  sub rsp, 0x30
00007d20d97d1f35  movaps [rsp], xmm1
00007d20d97d1f39  movaps [rsp+0x10], xmm13
00007d20d97d1f3f  movaps [rsp+0x20], xmm2
00007d20d97d1f44  lea rdi, [rsp]
00007d20d97d1f48  mov esi, 0x00
00007d20d97d1f4d  mov rax, 0x5EFBF4CF6530
00007d20d97d1f57  call rax
00007d20d97d1f59  movaps xmm1, [rsp]
00007d20d97d1f5d  add rsp, 0x30
00007d20d97d1f61  vmovaps xmm0, [rsp]
00007d20d97d1f66  vmovaps xmm2, [rsp+0x10]
00007d20d97d1f6c  vmovaps xmm3, [rsp+0x20]
00007d20d97d1f72  vmovaps xmm4, [rsp+0x30]
00007d20d97d1f78  vmovaps xmm5, [rsp+0x40]
00007d20d97d1f7e  vmovaps xmm6, [rsp+0x50]
00007d20d97d1f84  vmovaps xmm7, [rsp+0x60]
00007d20d97d1f8a  vmovaps xmm8, [rsp+0x70]
00007d20d97d1f90  vmovaps xmm9, [rsp+0x80]
00007d20d97d1f99  vmovaps xmm10, [rsp+0x90]
00007d20d97d1fa2  vmovaps xmm11, [rsp+0xA0]
00007d20d97d1fab  vmovaps xmm12, [rsp+0xB0]
00007d20d97d1fb4  vmovaps xmm13, [rsp+0xC0]
00007d20d97d1fbd  vmovaps xmm14, [rsp+0xD0]
00007d20d97d1fc6  vmovaps xmm15, [rsp+0xE0]
00007d20d97d1fcf  add rsp, 0xF0
00007d20d97d1fd6  pop r11
00007d20d97d1fd8  pop r10
00007d20d97d1fda  pop r9
00007d20d97d1fdc  pop r8
00007d20d97d1fde  pop rsi
00007d20d97d1fdf  pop rdi
00007d20d97d1fe0  pop rdx
00007d20d97d1fe1  pop rcx
00007d20d97d1fe2  pop rax
00007d20d97d1fe3  add rsp, 0x08
00007d20d97d1fe7  jmp 0x00007D20D97CFB52
00007d20d97d1fec  sub rsp, 0x08
00007d20d97d1ff0  push rax
00007d20d97d1ff1  push rcx
00007d20d97d1ff2  push rdx
00007d20d97d1ff3  push rdi
00007d20d97d1ff4  push rsi
00007d20d97d1ff5  push r8
00007d20d97d1ff7  push r9
00007d20d97d1ff9  push r10
00007d20d97d1ffb  push r11
00007d20d97d1ffd  sub rsp, 0xF0
00007d20d97d2004  vmovaps [rsp], xmm0
00007d20d97d2009  vmovaps [rsp+0x10], xmm1
00007d20d97d200f  vmovaps [rsp+0x20], xmm3
00007d20d97d2015  vmovaps [rsp+0x30], xmm4
00007d20d97d201b  vmovaps [rsp+0x40], xmm5
00007d20d97d2021  vmovaps [rsp+0x50], xmm6
00007d20d97d2027  vmovaps [rsp+0x60], xmm7
00007d20d97d202d  vmovaps [rsp+0x70], xmm8
00007d20d97d2033  vmovaps [rsp+0x80], xmm9
00007d20d97d203c  vmovaps [rsp+0x90], xmm10
00007d20d97d2045  vmovaps [rsp+0xA0], xmm11
00007d20d97d204e  vmovaps [rsp+0xB0], xmm12
00007d20d97d2057  vmovaps [rsp+0xC0], xmm13
00007d20d97d2060  vmovaps [rsp+0xD0], xmm14
00007d20d97d2069  vmovaps [rsp+0xE0], xmm15
00007d20d97d2072  sub rsp, 0x30
00007d20d97d2076  movaps [rsp], xmm2
00007d20d97d207a  movaps [rsp+0x10], xmm1
00007d20d97d207f  movaps [rsp+0x20], xmm13
00007d20d97d2085  lea rdi, [rsp]
00007d20d97d2089  mov esi, 0x00
00007d20d97d208e  mov rax, 0x5EFBF4CF6530
00007d20d97d2098  call rax
00007d20d97d209a  movaps xmm2, [rsp]
00007d20d97d209e  add rsp, 0x30
00007d20d97d20a2  vmovaps xmm0, [rsp]
00007d20d97d20a7  vmovaps xmm1, [rsp+0x10]
00007d20d97d20ad  vmovaps xmm3, [rsp+0x20]
00007d20d97d20b3  vmovaps xmm4, [rsp+0x30]
00007d20d97d20b9  vmovaps xmm5, [rsp+0x40]
00007d20d97d20bf  vmovaps xmm6, [rsp+0x50]
00007d20d97d20c5  vmovaps xmm7, [rsp+0x60]
00007d20d97d20cb  vmovaps xmm8, [rsp+0x70]
00007d20d97d20d1  vmovaps xmm9, [rsp+0x80]
00007d20d97d20da  vmovaps xmm10, [rsp+0x90]
00007d20d97d20e3  vmovaps xmm11, [rsp+0xA0]
00007d20d97d20ec  vmovaps xmm12, [rsp+0xB0]
00007d20d97d20f5  vmovaps xmm13, [rsp+0xC0]
00007d20d97d20fe  vmovaps xmm14, [rsp+0xD0]
00007d20d97d2107  vmovaps xmm15, [rsp+0xE0]
00007d20d97d2110  add rsp, 0xF0
00007d20d97d2117  pop r11
00007d20d97d2119  pop r10
00007d20d97d211b  pop r9
00007d20d97d211d  pop r8
00007d20d97d211f  pop rsi
00007d20d97d2120  pop rdi
00007d20d97d2121  pop rdx
00007d20d97d2122  pop rcx
00007d20d97d2123  pop rax
00007d20d97d2124  add rsp, 0x08
00007d20d97d2128  jmp 0x00007D20D97CFBAB
00007d20d97d212d  call 0x00007D20D95FF430
00007d20d97d2132  jmp 0x00007D20D97CFBB8
00007d20d97d2137  sub rsp, 0x08
00007d20d97d213b  push rax
00007d20d97d213c  push rcx
00007d20d97d213d  push rdx
00007d20d97d213e  push rdi
00007d20d97d213f  push rsi
00007d20d97d2140  push r8
00007d20d97d2142  push r9
00007d20d97d2144  push r10
00007d20d97d2146  push r11
00007d20d97d2148  sub rsp, 0xF0
00007d20d97d214f  vmovaps [rsp], xmm0
00007d20d97d2154  vmovaps [rsp+0x10], xmm1
00007d20d97d215a  vmovaps [rsp+0x20], xmm2
00007d20d97d2160  vmovaps [rsp+0x30], xmm3
00007d20d97d2166  vmovaps [rsp+0x40], xmm4
00007d20d97d216c  vmovaps [rsp+0x50], xmm5
00007d20d97d2172  vmovaps [rsp+0x60], xmm6
00007d20d97d2178  vmovaps [rsp+0x70], xmm7
00007d20d97d217e  vmovaps [rsp+0x80], xmm8
00007d20d97d2187  vmovaps [rsp+0x90], xmm9
00007d20d97d2190  vmovaps [rsp+0xA0], xmm10
00007d20d97d2199  vmovaps [rsp+0xB0], xmm11
00007d20d97d21a2  vmovaps [rsp+0xC0], xmm12
00007d20d97d21ab  vmovaps [rsp+0xD0], xmm13
00007d20d97d21b4  vmovaps [rsp+0xE0], xmm14
00007d20d97d21bd  sub rsp, 0x30
00007d20d97d21c1  movaps [rsp], xmm15
00007d20d97d21c6  movaps [rsp+0x10], xmm13
00007d20d97d21cc  movaps [rsp+0x20], xmm1
00007d20d97d21d1  lea rdi, [rsp]
00007d20d97d21d5  mov esi, 0x00
00007d20d97d21da  mov rax, 0x5EFBF4CF6530
00007d20d97d21e4  call rax
00007d20d97d21e6  movaps xmm15, [rsp]
00007d20d97d21eb  add rsp, 0x30
00007d20d97d21ef  vmovaps xmm0, [rsp]
00007d20d97d21f4  vmovaps xmm1, [rsp+0x10]
00007d20d97d21fa  vmovaps xmm2, [rsp+0x20]
00007d20d97d2200  vmovaps xmm3, [rsp+0x30]
00007d20d97d2206  vmovaps xmm4, [rsp+0x40]
00007d20d97d220c  vmovaps xmm5, [rsp+0x50]
00007d20d97d2212  vmovaps xmm6, [rsp+0x60]
00007d20d97d2218  vmovaps xmm7, [rsp+0x70]
00007d20d97d221e  vmovaps xmm8, [rsp+0x80]
00007d20d97d2227  vmovaps xmm9, [rsp+0x90]
00007d20d97d2230  vmovaps xmm10, [rsp+0xA0]
00007d20d97d2239  vmovaps xmm11, [rsp+0xB0]
00007d20d97d2242  vmovaps xmm12, [rsp+0xC0]
00007d20d97d224b  vmovaps xmm13, [rsp+0xD0]
00007d20d97d2254  vmovaps xmm14, [rsp+0xE0]
00007d20d97d225d  add rsp, 0xF0
00007d20d97d2264  pop r11
00007d20d97d2266  pop r10
00007d20d97d2268  pop r9
00007d20d97d226a  pop r8
00007d20d97d226c  pop rsi
00007d20d97d226d  pop rdi
00007d20d97d226e  pop rdx
00007d20d97d226f  pop rcx
00007d20d97d2270  pop rax
00007d20d97d2271  add rsp, 0x08
00007d20d97d2275  jmp 0x00007D20D97CFBF7
00007d20d97d227a  sub rsp, 0x08
00007d20d97d227e  push rax
00007d20d97d227f  push rcx
00007d20d97d2280  push rdx
00007d20d97d2281  push rdi
00007d20d97d2282  push rsi
00007d20d97d2283  push r8
00007d20d97d2285  push r9
00007d20d97d2287  push r10
00007d20d97d2289  push r11
00007d20d97d228b  sub rsp, 0xF0
00007d20d97d2292  vmovaps [rsp], xmm0
00007d20d97d2297  vmovaps [rsp+0x10], xmm1
00007d20d97d229d  vmovaps [rsp+0x20], xmm2
00007d20d97d22a3  vmovaps [rsp+0x30], xmm3
00007d20d97d22a9  vmovaps [rsp+0x40], xmm4
00007d20d97d22af  vmovaps [rsp+0x50], xmm5
00007d20d97d22b5  vmovaps [rsp+0x60], xmm6
00007d20d97d22bb  vmovaps [rsp+0x70], xmm7
00007d20d97d22c1  vmovaps [rsp+0x80], xmm8
00007d20d97d22ca  vmovaps [rsp+0x90], xmm9
00007d20d97d22d3  vmovaps [rsp+0xA0], xmm10
00007d20d97d22dc  vmovaps [rsp+0xB0], xmm11
00007d20d97d22e5  vmovaps [rsp+0xC0], xmm12
00007d20d97d22ee  vmovaps [rsp+0xD0], xmm13
00007d20d97d22f7  vmovaps [rsp+0xE0], xmm15
00007d20d97d2300  sub rsp, 0x30
00007d20d97d2304  movaps [rsp], xmm14
00007d20d97d2309  movaps [rsp+0x10], xmm11
00007d20d97d230f  movaps [rsp+0x20], xmm1
00007d20d97d2314  lea rdi, [rsp]
00007d20d97d2318  mov esi, 0x00
00007d20d97d231d  mov rax, 0x5EFBF4CF6530
00007d20d97d2327  call rax
00007d20d97d2329  movaps xmm14, [rsp]
00007d20d97d232e  add rsp, 0x30
00007d20d97d2332  vmovaps xmm0, [rsp]
00007d20d97d2337  vmovaps xmm1, [rsp+0x10]
00007d20d97d233d  vmovaps xmm2, [rsp+0x20]
00007d20d97d2343  vmovaps xmm3, [rsp+0x30]
00007d20d97d2349  vmovaps xmm4, [rsp+0x40]
00007d20d97d234f  vmovaps xmm5, [rsp+0x50]
00007d20d97d2355  vmovaps xmm6, [rsp+0x60]
00007d20d97d235b  vmovaps xmm7, [rsp+0x70]
00007d20d97d2361  vmovaps xmm8, [rsp+0x80]
00007d20d97d236a  vmovaps xmm9, [rsp+0x90]
00007d20d97d2373  vmovaps xmm10, [rsp+0xA0]
00007d20d97d237c  vmovaps xmm11, [rsp+0xB0]
00007d20d97d2385  vmovaps xmm12, [rsp+0xC0]
00007d20d97d238e  vmovaps xmm13, [rsp+0xD0]
00007d20d97d2397  vmovaps xmm15, [rsp+0xE0]
00007d20d97d23a0  add rsp, 0xF0
00007d20d97d23a7  pop r11
00007d20d97d23a9  pop r10
00007d20d97d23ab  pop r9
00007d20d97d23ad  pop r8
00007d20d97d23af  pop rsi
00007d20d97d23b0  pop rdi
00007d20d97d23b1  pop rdx
00007d20d97d23b2  pop rcx
00007d20d97d23b3  pop rax
00007d20d97d23b4  add rsp, 0x08
00007d20d97d23b8  jmp 0x00007D20D97CFC21
00007d20d97d23bd  sub rsp, 0x08
00007d20d97d23c1  push rax
00007d20d97d23c2  push rcx
00007d20d97d23c3  push rdx
00007d20d97d23c4  push rdi
00007d20d97d23c5  push rsi
00007d20d97d23c6  push r8
00007d20d97d23c8  push r9
00007d20d97d23ca  push r10
00007d20d97d23cc  push r11
00007d20d97d23ce  sub rsp, 0xF0
00007d20d97d23d5  vmovaps [rsp], xmm0
00007d20d97d23da  vmovaps [rsp+0x10], xmm1
00007d20d97d23e0  vmovaps [rsp+0x20], xmm2
00007d20d97d23e6  vmovaps [rsp+0x30], xmm3
00007d20d97d23ec  vmovaps [rsp+0x40], xmm4
00007d20d97d23f2  vmovaps [rsp+0x50], xmm5
00007d20d97d23f8  vmovaps [rsp+0x60], xmm6
00007d20d97d23fe  vmovaps [rsp+0x70], xmm7
00007d20d97d2404  vmovaps [rsp+0x80], xmm8
00007d20d97d240d  vmovaps [rsp+0x90], xmm9
00007d20d97d2416  vmovaps [rsp+0xA0], xmm10
00007d20d97d241f  vmovaps [rsp+0xB0], xmm11
00007d20d97d2428  vmovaps [rsp+0xC0], xmm12
00007d20d97d2431  vmovaps [rsp+0xD0], xmm14
00007d20d97d243a  vmovaps [rsp+0xE0], xmm15
00007d20d97d2443  sub rsp, 0x30
00007d20d97d2447  movaps [rsp], xmm13
00007d20d97d244c  movaps [rsp+0x10], xmm11
00007d20d97d2452  movaps [rsp+0x20], xmm1
00007d20d97d2457  lea rdi, [rsp]
00007d20d97d245b  mov esi, 0x00
00007d20d97d2460  mov rax, 0x5EFBF4CF6530
00007d20d97d246a  call rax
00007d20d97d246c  movaps xmm13, [rsp]
00007d20d97d2471  add rsp, 0x30
00007d20d97d2475  vmovaps xmm0, [rsp]
00007d20d97d247a  vmovaps xmm1, [rsp+0x10]
00007d20d97d2480  vmovaps xmm2, [rsp+0x20]
00007d20d97d2486  vmovaps xmm3, [rsp+0x30]
00007d20d97d248c  vmovaps xmm4, [rsp+0x40]
00007d20d97d2492  vmovaps xmm5, [rsp+0x50]
00007d20d97d2498  vmovaps xmm6, [rsp+0x60]
00007d20d97d249e  vmovaps xmm7, [rsp+0x70]
00007d20d97d24a4  vmovaps xmm8, [rsp+0x80]
00007d20d97d24ad  vmovaps xmm9, [rsp+0x90]
00007d20d97d24b6  vmovaps xmm10, [rsp+0xA0]
00007d20d97d24bf  vmovaps xmm11, [rsp+0xB0]
00007d20d97d24c8  vmovaps xmm12, [rsp+0xC0]
00007d20d97d24d1  vmovaps xmm14, [rsp+0xD0]
00007d20d97d24da  vmovaps xmm15, [rsp+0xE0]
00007d20d97d24e3  add rsp, 0xF0
00007d20d97d24ea  pop r11
00007d20d97d24ec  pop r10
00007d20d97d24ee  pop r9
00007d20d97d24f0  pop r8
00007d20d97d24f2  pop rsi
00007d20d97d24f3  pop rdi
00007d20d97d24f4  pop rdx
00007d20d97d24f5  pop rcx
00007d20d97d24f6  pop rax
00007d20d97d24f7  add rsp, 0x08
00007d20d97d24fb  jmp 0x00007D20D97CFC76
00007d20d97d2500  call 0x00007D20D95FF430
00007d20d97d2505  jmp 0x00007D20D97CFC83
00007d20d97d250a  sub rsp, 0x08
00007d20d97d250e  push rax
00007d20d97d250f  push rcx
00007d20d97d2510  push rdx
00007d20d97d2511  push rdi
00007d20d97d2512  push rsi
00007d20d97d2513  push r8
00007d20d97d2515  push r9
00007d20d97d2517  push r10
00007d20d97d2519  push r11
00007d20d97d251b  sub rsp, 0xF0
00007d20d97d2522  vmovaps [rsp], xmm0
00007d20d97d2527  vmovaps [rsp+0x10], xmm1
00007d20d97d252d  vmovaps [rsp+0x20], xmm2
00007d20d97d2533  vmovaps [rsp+0x30], xmm3
00007d20d97d2539  vmovaps [rsp+0x40], xmm4
00007d20d97d253f  vmovaps [rsp+0x50], xmm5
00007d20d97d2545  vmovaps [rsp+0x60], xmm6
00007d20d97d254b  vmovaps [rsp+0x70], xmm7
00007d20d97d2551  vmovaps [rsp+0x80], xmm8
00007d20d97d255a  vmovaps [rsp+0x90], xmm9
00007d20d97d2563  vmovaps [rsp+0xA0], xmm10
00007d20d97d256c  vmovaps [rsp+0xB0], xmm11
00007d20d97d2575  vmovaps [rsp+0xC0], xmm12
00007d20d97d257e  vmovaps [rsp+0xD0], xmm13
00007d20d97d2587  vmovaps [rsp+0xE0], xmm14
00007d20d97d2590  sub rsp, 0x30
00007d20d97d2594  movaps [rsp], xmm15
00007d20d97d2599  movaps [rsp+0x10], xmm11
00007d20d97d259f  movaps [rsp+0x20], xmm1
00007d20d97d25a4  lea rdi, [rsp]
00007d20d97d25a8  mov esi, 0x00
00007d20d97d25ad  mov rax, 0x5EFBF4CF6530
00007d20d97d25b7  call rax
00007d20d97d25b9  movaps xmm15, [rsp]
00007d20d97d25be  add rsp, 0x30
00007d20d97d25c2  vmovaps xmm0, [rsp]
00007d20d97d25c7  vmovaps xmm1, [rsp+0x10]
00007d20d97d25cd  vmovaps xmm2, [rsp+0x20]
00007d20d97d25d3  vmovaps xmm3, [rsp+0x30]
00007d20d97d25d9  vmovaps xmm4, [rsp+0x40]
00007d20d97d25df  vmovaps xmm5, [rsp+0x50]
00007d20d97d25e5  vmovaps xmm6, [rsp+0x60]
00007d20d97d25eb  vmovaps xmm7, [rsp+0x70]
00007d20d97d25f1  vmovaps xmm8, [rsp+0x80]
00007d20d97d25fa  vmovaps xmm9, [rsp+0x90]
00007d20d97d2603  vmovaps xmm10, [rsp+0xA0]
00007d20d97d260c  vmovaps xmm11, [rsp+0xB0]
00007d20d97d2615  vmovaps xmm12, [rsp+0xC0]
00007d20d97d261e  vmovaps xmm13, [rsp+0xD0]
00007d20d97d2627  vmovaps xmm14, [rsp+0xE0]
00007d20d97d2630  add rsp, 0xF0
00007d20d97d2637  pop r11
00007d20d97d2639  pop r10
00007d20d97d263b  pop r9
00007d20d97d263d  pop r8
00007d20d97d263f  pop rsi
00007d20d97d2640  pop rdi
00007d20d97d2641  pop rdx
00007d20d97d2642  pop rcx
00007d20d97d2643  pop rax
00007d20d97d2644  add rsp, 0x08
00007d20d97d2648  jmp 0x00007D20D97CFCBC
00007d20d97d264d  sub rsp, 0x08
00007d20d97d2651  push rax
00007d20d97d2652  push rcx
00007d20d97d2653  push rdx
00007d20d97d2654  push rdi
00007d20d97d2655  push rsi
00007d20d97d2656  push r8
00007d20d97d2658  push r9
00007d20d97d265a  push r10
00007d20d97d265c  push r11
00007d20d97d265e  sub rsp, 0xF0
00007d20d97d2665  vmovaps [rsp], xmm0
00007d20d97d266a  vmovaps [rsp+0x10], xmm1
00007d20d97d2670  vmovaps [rsp+0x20], xmm2
00007d20d97d2676  vmovaps [rsp+0x30], xmm3
00007d20d97d267c  vmovaps [rsp+0x40], xmm4
00007d20d97d2682  vmovaps [rsp+0x50], xmm5
00007d20d97d2688  vmovaps [rsp+0x60], xmm6
00007d20d97d268e  vmovaps [rsp+0x70], xmm7
00007d20d97d2694  vmovaps [rsp+0x80], xmm8
00007d20d97d269d  vmovaps [rsp+0x90], xmm9
00007d20d97d26a6  vmovaps [rsp+0xA0], xmm10
00007d20d97d26af  vmovaps [rsp+0xB0], xmm12
00007d20d97d26b8  vmovaps [rsp+0xC0], xmm13
00007d20d97d26c1  vmovaps [rsp+0xD0], xmm14
00007d20d97d26ca  vmovaps [rsp+0xE0], xmm15
00007d20d97d26d3  sub rsp, 0x30
00007d20d97d26d7  movaps [rsp], xmm11
00007d20d97d26dc  movaps [rsp+0x10], xmm6
00007d20d97d26e1  movaps [rsp+0x20], xmm14
00007d20d97d26e7  lea rdi, [rsp]
00007d20d97d26eb  mov esi, 0x00
00007d20d97d26f0  mov rax, 0x5EFBF4CF6530
00007d20d97d26fa  call rax
00007d20d97d26fc  movaps xmm11, [rsp]
00007d20d97d2701  add rsp, 0x30
00007d20d97d2705  vmovaps xmm0, [rsp]
00007d20d97d270a  vmovaps xmm1, [rsp+0x10]
00007d20d97d2710  vmovaps xmm2, [rsp+0x20]
00007d20d97d2716  vmovaps xmm3, [rsp+0x30]
00007d20d97d271c  vmovaps xmm4, [rsp+0x40]
00007d20d97d2722  vmovaps xmm5, [rsp+0x50]
00007d20d97d2728  vmovaps xmm6, [rsp+0x60]
00007d20d97d272e  vmovaps xmm7, [rsp+0x70]
00007d20d97d2734  vmovaps xmm8, [rsp+0x80]
00007d20d97d273d  vmovaps xmm9, [rsp+0x90]
00007d20d97d2746  vmovaps xmm10, [rsp+0xA0]
00007d20d97d274f  vmovaps xmm12, [rsp+0xB0]
00007d20d97d2758  vmovaps xmm13, [rsp+0xC0]
00007d20d97d2761  vmovaps xmm14, [rsp+0xD0]
00007d20d97d276a  vmovaps xmm15, [rsp+0xE0]
00007d20d97d2773  add rsp, 0xF0
00007d20d97d277a  pop r11
00007d20d97d277c  pop r10
00007d20d97d277e  pop r9
00007d20d97d2780  pop r8
00007d20d97d2782  pop rsi
00007d20d97d2783  pop rdi
00007d20d97d2784  pop rdx
00007d20d97d2785  pop rcx
00007d20d97d2786  pop rax
00007d20d97d2787  add rsp, 0x08
00007d20d97d278b  jmp 0x00007D20D97CFD34
00007d20d97d2790  call 0x00007D20D95FF430
00007d20d97d2795  jmp 0x00007D20D97CFD3E
00007d20d97d279a  sub rsp, 0x08
00007d20d97d279e  push rax
00007d20d97d279f  push rcx
00007d20d97d27a0  push rdx
00007d20d97d27a1  push rdi
00007d20d97d27a2  push rsi
00007d20d97d27a3  push r8
00007d20d97d27a5  push r9
00007d20d97d27a7  push r10
00007d20d97d27a9  push r11
00007d20d97d27ab  sub rsp, 0xF0
00007d20d97d27b2  vmovaps [rsp], xmm0
00007d20d97d27b7  vmovaps [rsp+0x10], xmm1
00007d20d97d27bd  vmovaps [rsp+0x20], xmm2
00007d20d97d27c3  vmovaps [rsp+0x30], xmm3
00007d20d97d27c9  vmovaps [rsp+0x40], xmm4
00007d20d97d27cf  vmovaps [rsp+0x50], xmm5
00007d20d97d27d5  vmovaps [rsp+0x60], xmm6
00007d20d97d27db  vmovaps [rsp+0x70], xmm7
00007d20d97d27e1  vmovaps [rsp+0x80], xmm8
00007d20d97d27ea  vmovaps [rsp+0x90], xmm9
00007d20d97d27f3  vmovaps [rsp+0xA0], xmm10
00007d20d97d27fc  vmovaps [rsp+0xB0], xmm11
00007d20d97d2805  vmovaps [rsp+0xC0], xmm12
00007d20d97d280e  vmovaps [rsp+0xD0], xmm13
00007d20d97d2817  vmovaps [rsp+0xE0], xmm15
00007d20d97d2820  sub rsp, 0x30
00007d20d97d2824  movaps [rsp], xmm14
00007d20d97d2829  movaps [rsp+0x10], xmm6
00007d20d97d282e  movaps [rsp+0x20], xmm2
00007d20d97d2833  lea rdi, [rsp]
00007d20d97d2837  mov esi, 0x00
00007d20d97d283c  mov rax, 0x5EFBF4CF6530
00007d20d97d2846  call rax
00007d20d97d2848  movaps xmm14, [rsp]
00007d20d97d284d  add rsp, 0x30
00007d20d97d2851  vmovaps xmm0, [rsp]
00007d20d97d2856  vmovaps xmm1, [rsp+0x10]
00007d20d97d285c  vmovaps xmm2, [rsp+0x20]
00007d20d97d2862  vmovaps xmm3, [rsp+0x30]
00007d20d97d2868  vmovaps xmm4, [rsp+0x40]
00007d20d97d286e  vmovaps xmm5, [rsp+0x50]
00007d20d97d2874  vmovaps xmm6, [rsp+0x60]
00007d20d97d287a  vmovaps xmm7, [rsp+0x70]
00007d20d97d2880  vmovaps xmm8, [rsp+0x80]
00007d20d97d2889  vmovaps xmm9, [rsp+0x90]
00007d20d97d2892  vmovaps xmm10, [rsp+0xA0]
00007d20d97d289b  vmovaps xmm11, [rsp+0xB0]
00007d20d97d28a4  vmovaps xmm12, [rsp+0xC0]
00007d20d97d28ad  vmovaps xmm13, [rsp+0xD0]
00007d20d97d28b6  vmovaps xmm15, [rsp+0xE0]
00007d20d97d28bf  add rsp, 0xF0
00007d20d97d28c6  pop r11
00007d20d97d28c8  pop r10
00007d20d97d28ca  pop r9
00007d20d97d28cc  pop r8
00007d20d97d28ce  pop rsi
00007d20d97d28cf  pop rdi
00007d20d97d28d0  pop rdx
00007d20d97d28d1  pop rcx
00007d20d97d28d2  pop rax
00007d20d97d28d3  add rsp, 0x08
00007d20d97d28d7  jmp 0x00007D20D97CFD72
00007d20d97d28dc  sub rsp, 0x08
00007d20d97d28e0  push rax
00007d20d97d28e1  push rcx
00007d20d97d28e2  push rdx
00007d20d97d28e3  push rdi
00007d20d97d28e4  push rsi
00007d20d97d28e5  push r8
00007d20d97d28e7  push r9
00007d20d97d28e9  push r10
00007d20d97d28eb  push r11
00007d20d97d28ed  sub rsp, 0xF0
00007d20d97d28f4  vmovaps [rsp], xmm0
00007d20d97d28f9  vmovaps [rsp+0x10], xmm1
00007d20d97d28ff  vmovaps [rsp+0x20], xmm2
00007d20d97d2905  vmovaps [rsp+0x30], xmm3
00007d20d97d290b  vmovaps [rsp+0x40], xmm4
00007d20d97d2911  vmovaps [rsp+0x50], xmm5
00007d20d97d2917  vmovaps [rsp+0x60], xmm7
00007d20d97d291d  vmovaps [rsp+0x70], xmm8
00007d20d97d2923  vmovaps [rsp+0x80], xmm9
00007d20d97d292c  vmovaps [rsp+0x90], xmm10
00007d20d97d2935  vmovaps [rsp+0xA0], xmm11
00007d20d97d293e  vmovaps [rsp+0xB0], xmm12
00007d20d97d2947  vmovaps [rsp+0xC0], xmm13
00007d20d97d2950  vmovaps [rsp+0xD0], xmm14
00007d20d97d2959  vmovaps [rsp+0xE0], xmm15
00007d20d97d2962  sub rsp, 0x30
00007d20d97d2966  movaps [rsp], xmm6
00007d20d97d296a  movaps [rsp+0x10], xmm5
00007d20d97d296f  movaps [rsp+0x20], xmm1
00007d20d97d2974  lea rdi, [rsp]
00007d20d97d2978  mov esi, 0x00
00007d20d97d297d  mov rax, 0x5EFBF4CF6530
00007d20d97d2987  call rax
00007d20d97d2989  movaps xmm6, [rsp]
00007d20d97d298d  add rsp, 0x30
00007d20d97d2991  vmovaps xmm0, [rsp]
00007d20d97d2996  vmovaps xmm1, [rsp+0x10]
00007d20d97d299c  vmovaps xmm2, [rsp+0x20]
00007d20d97d29a2  vmovaps xmm3, [rsp+0x30]
00007d20d97d29a8  vmovaps xmm4, [rsp+0x40]
00007d20d97d29ae  vmovaps xmm5, [rsp+0x50]
00007d20d97d29b4  vmovaps xmm7, [rsp+0x60]
00007d20d97d29ba  vmovaps xmm8, [rsp+0x70]
00007d20d97d29c0  vmovaps xmm9, [rsp+0x80]
00007d20d97d29c9  vmovaps xmm10, [rsp+0x90]
00007d20d97d29d2  vmovaps xmm11, [rsp+0xA0]
00007d20d97d29db  vmovaps xmm12, [rsp+0xB0]
00007d20d97d29e4  vmovaps xmm13, [rsp+0xC0]
00007d20d97d29ed  vmovaps xmm14, [rsp+0xD0]
00007d20d97d29f6  vmovaps xmm15, [rsp+0xE0]
00007d20d97d29ff  add rsp, 0xF0
00007d20d97d2a06  pop r11
00007d20d97d2a08  pop r10
00007d20d97d2a0a  pop r9
00007d20d97d2a0c  pop r8
00007d20d97d2a0e  pop rsi
00007d20d97d2a0f  pop rdi
00007d20d97d2a10  pop rdx
00007d20d97d2a11  pop rcx
00007d20d97d2a12  pop rax
00007d20d97d2a13  add rsp, 0x08
00007d20d97d2a17  jmp 0x00007D20D97CFD98
00007d20d97d2a1c  sub rsp, 0x08
00007d20d97d2a20  push rax
00007d20d97d2a21  push rcx
00007d20d97d2a22  push rdx
00007d20d97d2a23  push rdi
00007d20d97d2a24  push rsi
00007d20d97d2a25  push r8
00007d20d97d2a27  push r9
00007d20d97d2a29  push r10
00007d20d97d2a2b  push r11
00007d20d97d2a2d  sub rsp, 0xF0
00007d20d97d2a34  vmovaps [rsp], xmm0
00007d20d97d2a39  vmovaps [rsp+0x10], xmm2
00007d20d97d2a3f  vmovaps [rsp+0x20], xmm3
00007d20d97d2a45  vmovaps [rsp+0x30], xmm4
00007d20d97d2a4b  vmovaps [rsp+0x40], xmm5
00007d20d97d2a51  vmovaps [rsp+0x50], xmm6
00007d20d97d2a57  vmovaps [rsp+0x60], xmm7
00007d20d97d2a5d  vmovaps [rsp+0x70], xmm8
00007d20d97d2a63  vmovaps [rsp+0x80], xmm9
00007d20d97d2a6c  vmovaps [rsp+0x90], xmm10
00007d20d97d2a75  vmovaps [rsp+0xA0], xmm11
00007d20d97d2a7e  vmovaps [rsp+0xB0], xmm12
00007d20d97d2a87  vmovaps [rsp+0xC0], xmm13
00007d20d97d2a90  vmovaps [rsp+0xD0], xmm14
00007d20d97d2a99  vmovaps [rsp+0xE0], xmm15
00007d20d97d2aa2  sub rsp, 0x30
00007d20d97d2aa6  movaps [rsp], xmm1
00007d20d97d2aaa  movaps [rsp+0x10], xmm5
00007d20d97d2aaf  movaps [rsp+0x20], xmm13
00007d20d97d2ab5  lea rdi, [rsp]
00007d20d97d2ab9  mov esi, 0x00
00007d20d97d2abe  mov rax, 0x5EFBF4CF6530
00007d20d97d2ac8  call rax
00007d20d97d2aca  movaps xmm1, [rsp]
00007d20d97d2ace  add rsp, 0x30
00007d20d97d2ad2  vmovaps xmm0, [rsp]
00007d20d97d2ad7  vmovaps xmm2, [rsp+0x10]
00007d20d97d2add  vmovaps xmm3, [rsp+0x20]
00007d20d97d2ae3  vmovaps xmm4, [rsp+0x30]
00007d20d97d2ae9  vmovaps xmm5, [rsp+0x40]
00007d20d97d2aef  vmovaps xmm6, [rsp+0x50]
00007d20d97d2af5  vmovaps xmm7, [rsp+0x60]
00007d20d97d2afb  vmovaps xmm8, [rsp+0x70]
00007d20d97d2b01  vmovaps xmm9, [rsp+0x80]
00007d20d97d2b0a  vmovaps xmm10, [rsp+0x90]
00007d20d97d2b13  vmovaps xmm11, [rsp+0xA0]
00007d20d97d2b1c  vmovaps xmm12, [rsp+0xB0]
00007d20d97d2b25  vmovaps xmm13, [rsp+0xC0]
00007d20d97d2b2e  vmovaps xmm14, [rsp+0xD0]
00007d20d97d2b37  vmovaps xmm15, [rsp+0xE0]
00007d20d97d2b40  add rsp, 0xF0
00007d20d97d2b47  pop r11
00007d20d97d2b49  pop r10
00007d20d97d2b4b  pop r9
00007d20d97d2b4d  pop r8
00007d20d97d2b4f  pop rsi
00007d20d97d2b50  pop rdi
00007d20d97d2b51  pop rdx
00007d20d97d2b52  pop rcx
00007d20d97d2b53  pop rax
00007d20d97d2b54  add rsp, 0x08
00007d20d97d2b58  jmp 0x00007D20D97CFDB6
00007d20d97d2b5d  sub rsp, 0x08
00007d20d97d2b61  push rax
00007d20d97d2b62  push rcx
00007d20d97d2b63  push rdx
00007d20d97d2b64  push rdi
00007d20d97d2b65  push rsi
00007d20d97d2b66  push r8
00007d20d97d2b68  push r9
00007d20d97d2b6a  push r10
00007d20d97d2b6c  push r11
00007d20d97d2b6e  sub rsp, 0xF0
00007d20d97d2b75  vmovaps [rsp], xmm0
00007d20d97d2b7a  vmovaps [rsp+0x10], xmm1
00007d20d97d2b80  vmovaps [rsp+0x20], xmm2
00007d20d97d2b86  vmovaps [rsp+0x30], xmm3
00007d20d97d2b8c  vmovaps [rsp+0x40], xmm4
00007d20d97d2b92  vmovaps [rsp+0x50], xmm6
00007d20d97d2b98  vmovaps [rsp+0x60], xmm7
00007d20d97d2b9e  vmovaps [rsp+0x70], xmm8
00007d20d97d2ba4  vmovaps [rsp+0x80], xmm9
00007d20d97d2bad  vmovaps [rsp+0x90], xmm10
00007d20d97d2bb6  vmovaps [rsp+0xA0], xmm11
00007d20d97d2bbf  vmovaps [rsp+0xB0], xmm12
00007d20d97d2bc8  vmovaps [rsp+0xC0], xmm13
00007d20d97d2bd1  vmovaps [rsp+0xD0], xmm14
00007d20d97d2bda  vmovaps [rsp+0xE0], xmm15
00007d20d97d2be3  sub rsp, 0x30
00007d20d97d2be7  movaps [rsp], xmm5
00007d20d97d2beb  movaps [rsp+0x10], xmm2
00007d20d97d2bf0  movaps [rsp+0x20], xmm13
00007d20d97d2bf6  lea rdi, [rsp]
00007d20d97d2bfa  mov esi, 0x00
00007d20d97d2bff  mov rax, 0x5EFBF4CF6530
00007d20d97d2c09  call rax
00007d20d97d2c0b  movaps xmm5, [rsp]
00007d20d97d2c0f  add rsp, 0x30
00007d20d97d2c13  vmovaps xmm0, [rsp]
00007d20d97d2c18  vmovaps xmm1, [rsp+0x10]
00007d20d97d2c1e  vmovaps xmm2, [rsp+0x20]
00007d20d97d2c24  vmovaps xmm3, [rsp+0x30]
00007d20d97d2c2a  vmovaps xmm4, [rsp+0x40]
00007d20d97d2c30  vmovaps xmm6, [rsp+0x50]
00007d20d97d2c36  vmovaps xmm7, [rsp+0x60]
00007d20d97d2c3c  vmovaps xmm8, [rsp+0x70]
00007d20d97d2c42  vmovaps xmm9, [rsp+0x80]
00007d20d97d2c4b  vmovaps xmm10, [rsp+0x90]
00007d20d97d2c54  vmovaps xmm11, [rsp+0xA0]
00007d20d97d2c5d  vmovaps xmm12, [rsp+0xB0]
00007d20d97d2c66  vmovaps xmm13, [rsp+0xC0]
00007d20d97d2c6f  vmovaps xmm14, [rsp+0xD0]
00007d20d97d2c78  vmovaps xmm15, [rsp+0xE0]
00007d20d97d2c81  add rsp, 0xF0
00007d20d97d2c88  pop r11
00007d20d97d2c8a  pop r10
00007d20d97d2c8c  pop r9
00007d20d97d2c8e  pop r8
00007d20d97d2c90  pop rsi
00007d20d97d2c91  pop rdi
00007d20d97d2c92  pop rdx
00007d20d97d2c93  pop rcx
00007d20d97d2c94  pop rax
00007d20d97d2c95  add rsp, 0x08
00007d20d97d2c99  jmp 0x00007D20D97CFDEC
00007d20d97d2c9e  sub rsp, 0x08
00007d20d97d2ca2  push rax
00007d20d97d2ca3  push rcx
00007d20d97d2ca4  push rdx
00007d20d97d2ca5  push rdi
00007d20d97d2ca6  push rsi
00007d20d97d2ca7  push r8
00007d20d97d2ca9  push r9
00007d20d97d2cab  push r10
00007d20d97d2cad  push r11
00007d20d97d2caf  sub rsp, 0xF0
00007d20d97d2cb6  vmovaps [rsp], xmm0
00007d20d97d2cbb  vmovaps [rsp+0x10], xmm1
00007d20d97d2cc1  vmovaps [rsp+0x20], xmm2
00007d20d97d2cc7  vmovaps [rsp+0x30], xmm3
00007d20d97d2ccd  vmovaps [rsp+0x40], xmm4
00007d20d97d2cd3  vmovaps [rsp+0x50], xmm5
00007d20d97d2cd9  vmovaps [rsp+0x60], xmm6
00007d20d97d2cdf  vmovaps [rsp+0x70], xmm7
00007d20d97d2ce5  vmovaps [rsp+0x80], xmm8
00007d20d97d2cee  vmovaps [rsp+0x90], xmm9
00007d20d97d2cf7  vmovaps [rsp+0xA0], xmm10
00007d20d97d2d00  vmovaps [rsp+0xB0], xmm11
00007d20d97d2d09  vmovaps [rsp+0xC0], xmm12
00007d20d97d2d12  vmovaps [rsp+0xD0], xmm14
00007d20d97d2d1b  vmovaps [rsp+0xE0], xmm15
00007d20d97d2d24  sub rsp, 0x30
00007d20d97d2d28  movaps [rsp], xmm13
00007d20d97d2d2d  movaps [rsp+0x10], xmm10
00007d20d97d2d33  movaps [rsp+0x20], xmm1
00007d20d97d2d38  lea rdi, [rsp]
00007d20d97d2d3c  mov esi, 0x00
00007d20d97d2d41  mov rax, 0x5EFBF4CF6530
00007d20d97d2d4b  call rax
00007d20d97d2d4d  movaps xmm13, [rsp]
00007d20d97d2d52  add rsp, 0x30
00007d20d97d2d56  vmovaps xmm0, [rsp]
00007d20d97d2d5b  vmovaps xmm1, [rsp+0x10]
00007d20d97d2d61  vmovaps xmm2, [rsp+0x20]
00007d20d97d2d67  vmovaps xmm3, [rsp+0x30]
00007d20d97d2d6d  vmovaps xmm4, [rsp+0x40]
00007d20d97d2d73  vmovaps xmm5, [rsp+0x50]
00007d20d97d2d79  vmovaps xmm6, [rsp+0x60]
00007d20d97d2d7f  vmovaps xmm7, [rsp+0x70]
00007d20d97d2d85  vmovaps xmm8, [rsp+0x80]
00007d20d97d2d8e  vmovaps xmm9, [rsp+0x90]
00007d20d97d2d97  vmovaps xmm10, [rsp+0xA0]
00007d20d97d2da0  vmovaps xmm11, [rsp+0xB0]
00007d20d97d2da9  vmovaps xmm12, [rsp+0xC0]
00007d20d97d2db2  vmovaps xmm14, [rsp+0xD0]
00007d20d97d2dbb  vmovaps xmm15, [rsp+0xE0]
00007d20d97d2dc4  add rsp, 0xF0
00007d20d97d2dcb  pop r11
00007d20d97d2dcd  pop r10
00007d20d97d2dcf  pop r9
00007d20d97d2dd1  pop r8
00007d20d97d2dd3  pop rsi
00007d20d97d2dd4  pop rdi
00007d20d97d2dd5  pop rdx
00007d20d97d2dd6  pop rcx
00007d20d97d2dd7  pop rax
00007d20d97d2dd8  add rsp, 0x08
00007d20d97d2ddc  jmp 0x00007D20D97CFE15
00007d20d97d2de1  sub rsp, 0x08
00007d20d97d2de5  push rax
00007d20d97d2de6  push rcx
00007d20d97d2de7  push rdx
00007d20d97d2de8  push rdi
00007d20d97d2de9  push rsi
00007d20d97d2dea  push r8
00007d20d97d2dec  push r9
00007d20d97d2dee  push r10
00007d20d97d2df0  push r11
00007d20d97d2df2  sub rsp, 0xF0
00007d20d97d2df9  vmovaps [rsp], xmm0
00007d20d97d2dfe  vmovaps [rsp+0x10], xmm2
00007d20d97d2e04  vmovaps [rsp+0x20], xmm3
00007d20d97d2e0a  vmovaps [rsp+0x30], xmm4
00007d20d97d2e10  vmovaps [rsp+0x40], xmm5
00007d20d97d2e16  vmovaps [rsp+0x50], xmm6
00007d20d97d2e1c  vmovaps [rsp+0x60], xmm7
00007d20d97d2e22  vmovaps [rsp+0x70], xmm8
00007d20d97d2e28  vmovaps [rsp+0x80], xmm9
00007d20d97d2e31  vmovaps [rsp+0x90], xmm10
00007d20d97d2e3a  vmovaps [rsp+0xA0], xmm11
00007d20d97d2e43  vmovaps [rsp+0xB0], xmm12
00007d20d97d2e4c  vmovaps [rsp+0xC0], xmm13
00007d20d97d2e55  vmovaps [rsp+0xD0], xmm14
00007d20d97d2e5e  vmovaps [rsp+0xE0], xmm15
00007d20d97d2e67  sub rsp, 0x30
00007d20d97d2e6b  movaps [rsp], xmm1
00007d20d97d2e6f  movaps [rsp+0x10], xmm15
00007d20d97d2e75  movaps [rsp+0x20], xmm10
00007d20d97d2e7b  lea rdi, [rsp]
00007d20d97d2e7f  mov esi, 0x00
00007d20d97d2e84  mov rax, 0x5EFBF4CF6530
00007d20d97d2e8e  call rax
00007d20d97d2e90  movaps xmm1, [rsp]
00007d20d97d2e94  add rsp, 0x30
00007d20d97d2e98  vmovaps xmm0, [rsp]
00007d20d97d2e9d  vmovaps xmm2, [rsp+0x10]
00007d20d97d2ea3  vmovaps xmm3, [rsp+0x20]
00007d20d97d2ea9  vmovaps xmm4, [rsp+0x30]
00007d20d97d2eaf  vmovaps xmm5, [rsp+0x40]
00007d20d97d2eb5  vmovaps xmm6, [rsp+0x50]
00007d20d97d2ebb  vmovaps xmm7, [rsp+0x60]
00007d20d97d2ec1  vmovaps xmm8, [rsp+0x70]
00007d20d97d2ec7  vmovaps xmm9, [rsp+0x80]
00007d20d97d2ed0  vmovaps xmm10, [rsp+0x90]
00007d20d97d2ed9  vmovaps xmm11, [rsp+0xA0]
00007d20d97d2ee2  vmovaps xmm12, [rsp+0xB0]
00007d20d97d2eeb  vmovaps xmm13, [rsp+0xC0]
00007d20d97d2ef4  vmovaps xmm14, [rsp+0xD0]
00007d20d97d2efd  vmovaps xmm15, [rsp+0xE0]
00007d20d97d2f06  add rsp, 0xF0
00007d20d97d2f0d  pop r11
00007d20d97d2f0f  pop r10
00007d20d97d2f11  pop r9
00007d20d97d2f13  pop r8
00007d20d97d2f15  pop rsi
00007d20d97d2f16  pop rdi
00007d20d97d2f17  pop rdx
00007d20d97d2f18  pop rcx
00007d20d97d2f19  pop rax
00007d20d97d2f1a  add rsp, 0x08
00007d20d97d2f1e  jmp 0x00007D20D97CFE34
00007d20d97d2f23  sub rsp, 0x08
00007d20d97d2f27  push rax
00007d20d97d2f28  push rcx
00007d20d97d2f29  push rdx
00007d20d97d2f2a  push rdi
00007d20d97d2f2b  push rsi
00007d20d97d2f2c  push r8
00007d20d97d2f2e  push r9
00007d20d97d2f30  push r10
00007d20d97d2f32  push r11
00007d20d97d2f34  sub rsp, 0xF0
00007d20d97d2f3b  vmovaps [rsp], xmm0
00007d20d97d2f40  vmovaps [rsp+0x10], xmm1
00007d20d97d2f46  vmovaps [rsp+0x20], xmm2
00007d20d97d2f4c  vmovaps [rsp+0x30], xmm3
00007d20d97d2f52  vmovaps [rsp+0x40], xmm4
00007d20d97d2f58  vmovaps [rsp+0x50], xmm5
00007d20d97d2f5e  vmovaps [rsp+0x60], xmm6
00007d20d97d2f64  vmovaps [rsp+0x70], xmm7
00007d20d97d2f6a  vmovaps [rsp+0x80], xmm8
00007d20d97d2f73  vmovaps [rsp+0x90], xmm9
00007d20d97d2f7c  vmovaps [rsp+0xA0], xmm10
00007d20d97d2f85  vmovaps [rsp+0xB0], xmm11
00007d20d97d2f8e  vmovaps [rsp+0xC0], xmm12
00007d20d97d2f97  vmovaps [rsp+0xD0], xmm13
00007d20d97d2fa0  vmovaps [rsp+0xE0], xmm14
00007d20d97d2fa9  sub rsp, 0x30
00007d20d97d2fad  movaps [rsp], xmm15
00007d20d97d2fb2  movaps [rsp+0x10], xmm10
00007d20d97d2fb8  movaps [rsp+0x20], xmm11
00007d20d97d2fbe  lea rdi, [rsp]
00007d20d97d2fc2  mov esi, 0x00
00007d20d97d2fc7  mov rax, 0x5EFBF4CF6530
00007d20d97d2fd1  call rax
00007d20d97d2fd3  movaps xmm15, [rsp]
00007d20d97d2fd8  add rsp, 0x30
00007d20d97d2fdc  vmovaps xmm0, [rsp]
00007d20d97d2fe1  vmovaps xmm1, [rsp+0x10]
00007d20d97d2fe7  vmovaps xmm2, [rsp+0x20]
00007d20d97d2fed  vmovaps xmm3, [rsp+0x30]
00007d20d97d2ff3  vmovaps xmm4, [rsp+0x40]
00007d20d97d2ff9  vmovaps xmm5, [rsp+0x50]
00007d20d97d2fff  vmovaps xmm6, [rsp+0x60]
00007d20d97d3005  vmovaps xmm7, [rsp+0x70]
00007d20d97d300b  vmovaps xmm8, [rsp+0x80]
00007d20d97d3014  vmovaps xmm9, [rsp+0x90]
00007d20d97d301d  vmovaps xmm10, [rsp+0xA0]
00007d20d97d3026  vmovaps xmm11, [rsp+0xB0]
00007d20d97d302f  vmovaps xmm12, [rsp+0xC0]
00007d20d97d3038  vmovaps xmm13, [rsp+0xD0]
00007d20d97d3041  vmovaps xmm14, [rsp+0xE0]
00007d20d97d304a  add rsp, 0xF0
00007d20d97d3051  pop r11
00007d20d97d3053  pop r10
00007d20d97d3055  pop r9
00007d20d97d3057  pop r8
00007d20d97d3059  pop rsi
00007d20d97d305a  pop rdi
00007d20d97d305b  pop rdx
00007d20d97d305c  pop rcx
00007d20d97d305d  pop rax
00007d20d97d305e  add rsp, 0x08
00007d20d97d3062  jmp 0x00007D20D97CFE57
00007d20d97d3067  sub rsp, 0x08
00007d20d97d306b  push rax
00007d20d97d306c  push rcx
00007d20d97d306d  push rdx
00007d20d97d306e  push rdi
00007d20d97d306f  push rsi
00007d20d97d3070  push r8
00007d20d97d3072  push r9
00007d20d97d3074  push r10
00007d20d97d3076  push r11
00007d20d97d3078  sub rsp, 0xF0
00007d20d97d307f  vmovaps [rsp], xmm0
00007d20d97d3084  vmovaps [rsp+0x10], xmm1
00007d20d97d308a  vmovaps [rsp+0x20], xmm2
00007d20d97d3090  vmovaps [rsp+0x30], xmm3
00007d20d97d3096  vmovaps [rsp+0x40], xmm4
00007d20d97d309c  vmovaps [rsp+0x50], xmm5
00007d20d97d30a2  vmovaps [rsp+0x60], xmm6
00007d20d97d30a8  vmovaps [rsp+0x70], xmm7
00007d20d97d30ae  vmovaps [rsp+0x80], xmm8
00007d20d97d30b7  vmovaps [rsp+0x90], xmm9
00007d20d97d30c0  vmovaps [rsp+0xA0], xmm11
00007d20d97d30c9  vmovaps [rsp+0xB0], xmm12
00007d20d97d30d2  vmovaps [rsp+0xC0], xmm13
00007d20d97d30db  vmovaps [rsp+0xD0], xmm14
00007d20d97d30e4  vmovaps [rsp+0xE0], xmm15
00007d20d97d30ed  sub rsp, 0x30
00007d20d97d30f1  movaps [rsp], xmm10
00007d20d97d30f6  movaps [rsp+0x10], xmm12
00007d20d97d30fc  movaps [rsp+0x20], xmm11
00007d20d97d3102  lea rdi, [rsp]
00007d20d97d3106  mov esi, 0x00
00007d20d97d310b  mov rax, 0x5EFBF4CF6530
00007d20d97d3115  call rax
00007d20d97d3117  movaps xmm10, [rsp]
00007d20d97d311c  add rsp, 0x30
00007d20d97d3120  vmovaps xmm0, [rsp]
00007d20d97d3125  vmovaps xmm1, [rsp+0x10]
00007d20d97d312b  vmovaps xmm2, [rsp+0x20]
00007d20d97d3131  vmovaps xmm3, [rsp+0x30]
00007d20d97d3137  vmovaps xmm4, [rsp+0x40]
00007d20d97d313d  vmovaps xmm5, [rsp+0x50]
00007d20d97d3143  vmovaps xmm6, [rsp+0x60]
00007d20d97d3149  vmovaps xmm7, [rsp+0x70]
00007d20d97d314f  vmovaps xmm8, [rsp+0x80]
00007d20d97d3158  vmovaps xmm9, [rsp+0x90]
00007d20d97d3161  vmovaps xmm11, [rsp+0xA0]
00007d20d97d316a  vmovaps xmm12, [rsp+0xB0]
00007d20d97d3173  vmovaps xmm13, [rsp+0xC0]
00007d20d97d317c  vmovaps xmm14, [rsp+0xD0]
00007d20d97d3185  vmovaps xmm15, [rsp+0xE0]
00007d20d97d318e  add rsp, 0xF0
00007d20d97d3195  pop r11
00007d20d97d3197  pop r10
00007d20d97d3199  pop r9
00007d20d97d319b  pop r8
00007d20d97d319d  pop rsi
00007d20d97d319e  pop rdi
00007d20d97d319f  pop rdx
00007d20d97d31a0  pop rcx
00007d20d97d31a1  pop rax
00007d20d97d31a2  add rsp, 0x08
00007d20d97d31a6  jmp 0x00007D20D97CFE80
00007d20d97d31ab  sub rsp, 0x08
00007d20d97d31af  push rax
00007d20d97d31b0  push rcx
00007d20d97d31b1  push rdx
00007d20d97d31b2  push rdi
00007d20d97d31b3  push rsi
00007d20d97d31b4  push r8
00007d20d97d31b6  push r9
00007d20d97d31b8  push r10
00007d20d97d31ba  push r11
00007d20d97d31bc  sub rsp, 0xF0
00007d20d97d31c3  vmovaps [rsp], xmm0
00007d20d97d31c8  vmovaps [rsp+0x10], xmm1
00007d20d97d31ce  vmovaps [rsp+0x20], xmm2
00007d20d97d31d4  vmovaps [rsp+0x30], xmm3
00007d20d97d31da  vmovaps [rsp+0x40], xmm4
00007d20d97d31e0  vmovaps [rsp+0x50], xmm5
00007d20d97d31e6  vmovaps [rsp+0x60], xmm6
00007d20d97d31ec  vmovaps [rsp+0x70], xmm7
00007d20d97d31f2  vmovaps [rsp+0x80], xmm8
00007d20d97d31fb  vmovaps [rsp+0x90], xmm9
00007d20d97d3204  vmovaps [rsp+0xA0], xmm10
00007d20d97d320d  vmovaps [rsp+0xB0], xmm12
00007d20d97d3216  vmovaps [rsp+0xC0], xmm13
00007d20d97d321f  vmovaps [rsp+0xD0], xmm14
00007d20d97d3228  vmovaps [rsp+0xE0], xmm15
00007d20d97d3231  sub rsp, 0x30
00007d20d97d3235  movaps [rsp], xmm11
00007d20d97d323a  movaps [rsp+0x10], xmm2
00007d20d97d323f  movaps [rsp+0x20], xmm12
00007d20d97d3245  lea rdi, [rsp]
00007d20d97d3249  mov esi, 0x00
00007d20d97d324e  mov rax, 0x5EFBF4CF6530
00007d20d97d3258  call rax
00007d20d97d325a  movaps xmm11, [rsp]
00007d20d97d325f  add rsp, 0x30
00007d20d97d3263  vmovaps xmm0, [rsp]
00007d20d97d3268  vmovaps xmm1, [rsp+0x10]
00007d20d97d326e  vmovaps xmm2, [rsp+0x20]
00007d20d97d3274  vmovaps xmm3, [rsp+0x30]
00007d20d97d327a  vmovaps xmm4, [rsp+0x40]
00007d20d97d3280  vmovaps xmm5, [rsp+0x50]
00007d20d97d3286  vmovaps xmm6, [rsp+0x60]
00007d20d97d328c  vmovaps xmm7, [rsp+0x70]
00007d20d97d3292  vmovaps xmm8, [rsp+0x80]
00007d20d97d329b  vmovaps xmm9, [rsp+0x90]
00007d20d97d32a4  vmovaps xmm10, [rsp+0xA0]
00007d20d97d32ad  vmovaps xmm12, [rsp+0xB0]
00007d20d97d32b6  vmovaps xmm13, [rsp+0xC0]
00007d20d97d32bf  vmovaps xmm14, [rsp+0xD0]
00007d20d97d32c8  vmovaps xmm15, [rsp+0xE0]
00007d20d97d32d1  add rsp, 0xF0
00007d20d97d32d8  pop r11
00007d20d97d32da  pop r10
00007d20d97d32dc  pop r9
00007d20d97d32de  pop r8
00007d20d97d32e0  pop rsi
00007d20d97d32e1  pop rdi
00007d20d97d32e2  pop rdx
00007d20d97d32e3  pop rcx
00007d20d97d32e4  pop rax
00007d20d97d32e5  add rsp, 0x08
00007d20d97d32e9  jmp 0x00007D20D97CFEB8
00007d20d97d32ee  sub rsp, 0x08
00007d20d97d32f2  push rax
00007d20d97d32f3  push rcx
00007d20d97d32f4  push rdx
00007d20d97d32f5  push rdi
00007d20d97d32f6  push rsi
00007d20d97d32f7  push r8
00007d20d97d32f9  push r9
00007d20d97d32fb  push r10
00007d20d97d32fd  push r11
00007d20d97d32ff  sub rsp, 0xF0
00007d20d97d3306  vmovaps [rsp], xmm0
00007d20d97d330b  vmovaps [rsp+0x10], xmm2
00007d20d97d3311  vmovaps [rsp+0x20], xmm3
00007d20d97d3317  vmovaps [rsp+0x30], xmm4
00007d20d97d331d  vmovaps [rsp+0x40], xmm5
00007d20d97d3323  vmovaps [rsp+0x50], xmm6
00007d20d97d3329  vmovaps [rsp+0x60], xmm7
00007d20d97d332f  vmovaps [rsp+0x70], xmm8
00007d20d97d3335  vmovaps [rsp+0x80], xmm9
00007d20d97d333e  vmovaps [rsp+0x90], xmm10
00007d20d97d3347  vmovaps [rsp+0xA0], xmm11
00007d20d97d3350  vmovaps [rsp+0xB0], xmm12
00007d20d97d3359  vmovaps [rsp+0xC0], xmm13
00007d20d97d3362  vmovaps [rsp+0xD0], xmm14
00007d20d97d336b  vmovaps [rsp+0xE0], xmm15
00007d20d97d3374  sub rsp, 0x30
00007d20d97d3378  movaps [rsp], xmm1
00007d20d97d337c  movaps [rsp+0x10], xmm14
00007d20d97d3382  movaps [rsp+0x20], xmm6
00007d20d97d3387  lea rdi, [rsp]
00007d20d97d338b  mov esi, 0x00
00007d20d97d3390  mov rax, 0x5EFBF4CF6530
00007d20d97d339a  call rax
00007d20d97d339c  movaps xmm1, [rsp]
00007d20d97d33a0  add rsp, 0x30
00007d20d97d33a4  vmovaps xmm0, [rsp]
00007d20d97d33a9  vmovaps xmm2, [rsp+0x10]
00007d20d97d33af  vmovaps xmm3, [rsp+0x20]
00007d20d97d33b5  vmovaps xmm4, [rsp+0x30]
00007d20d97d33bb  vmovaps xmm5, [rsp+0x40]
00007d20d97d33c1  vmovaps xmm6, [rsp+0x50]
00007d20d97d33c7  vmovaps xmm7, [rsp+0x60]
00007d20d97d33cd  vmovaps xmm8, [rsp+0x70]
00007d20d97d33d3  vmovaps xmm9, [rsp+0x80]
00007d20d97d33dc  vmovaps xmm10, [rsp+0x90]
00007d20d97d33e5  vmovaps xmm11, [rsp+0xA0]
00007d20d97d33ee  vmovaps xmm12, [rsp+0xB0]
00007d20d97d33f7  vmovaps xmm13, [rsp+0xC0]
00007d20d97d3400  vmovaps xmm14, [rsp+0xD0]
00007d20d97d3409  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3412  add rsp, 0xF0
00007d20d97d3419  pop r11
00007d20d97d341b  pop r10
00007d20d97d341d  pop r9
00007d20d97d341f  pop r8
00007d20d97d3421  pop rsi
00007d20d97d3422  pop rdi
00007d20d97d3423  pop rdx
00007d20d97d3424  pop rcx
00007d20d97d3425  pop rax
00007d20d97d3426  add rsp, 0x08
00007d20d97d342a  jmp 0x00007D20D97CFED1
00007d20d97d342f  sub rsp, 0x08
00007d20d97d3433  push rax
00007d20d97d3434  push rcx
00007d20d97d3435  push rdx
00007d20d97d3436  push rdi
00007d20d97d3437  push rsi
00007d20d97d3438  push r8
00007d20d97d343a  push r9
00007d20d97d343c  push r10
00007d20d97d343e  push r11
00007d20d97d3440  sub rsp, 0xF0
00007d20d97d3447  vmovaps [rsp], xmm0
00007d20d97d344c  vmovaps [rsp+0x10], xmm1
00007d20d97d3452  vmovaps [rsp+0x20], xmm2
00007d20d97d3458  vmovaps [rsp+0x30], xmm3
00007d20d97d345e  vmovaps [rsp+0x40], xmm4
00007d20d97d3464  vmovaps [rsp+0x50], xmm5
00007d20d97d346a  vmovaps [rsp+0x60], xmm6
00007d20d97d3470  vmovaps [rsp+0x70], xmm7
00007d20d97d3476  vmovaps [rsp+0x80], xmm8
00007d20d97d347f  vmovaps [rsp+0x90], xmm9
00007d20d97d3488  vmovaps [rsp+0xA0], xmm10
00007d20d97d3491  vmovaps [rsp+0xB0], xmm11
00007d20d97d349a  vmovaps [rsp+0xC0], xmm12
00007d20d97d34a3  vmovaps [rsp+0xD0], xmm13
00007d20d97d34ac  vmovaps [rsp+0xE0], xmm15
00007d20d97d34b5  sub rsp, 0x30
00007d20d97d34b9  movaps [rsp], xmm14
00007d20d97d34be  movaps [rsp+0x10], xmm12
00007d20d97d34c4  movaps [rsp+0x20], xmm5
00007d20d97d34c9  lea rdi, [rsp]
00007d20d97d34cd  mov esi, 0x00
00007d20d97d34d2  mov rax, 0x5EFBF4CF6530
00007d20d97d34dc  call rax
00007d20d97d34de  movaps xmm14, [rsp]
00007d20d97d34e3  add rsp, 0x30
00007d20d97d34e7  vmovaps xmm0, [rsp]
00007d20d97d34ec  vmovaps xmm1, [rsp+0x10]
00007d20d97d34f2  vmovaps xmm2, [rsp+0x20]
00007d20d97d34f8  vmovaps xmm3, [rsp+0x30]
00007d20d97d34fe  vmovaps xmm4, [rsp+0x40]
00007d20d97d3504  vmovaps xmm5, [rsp+0x50]
00007d20d97d350a  vmovaps xmm6, [rsp+0x60]
00007d20d97d3510  vmovaps xmm7, [rsp+0x70]
00007d20d97d3516  vmovaps xmm8, [rsp+0x80]
00007d20d97d351f  vmovaps xmm9, [rsp+0x90]
00007d20d97d3528  vmovaps xmm10, [rsp+0xA0]
00007d20d97d3531  vmovaps xmm11, [rsp+0xB0]
00007d20d97d353a  vmovaps xmm12, [rsp+0xC0]
00007d20d97d3543  vmovaps xmm13, [rsp+0xD0]
00007d20d97d354c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3555  add rsp, 0xF0
00007d20d97d355c  pop r11
00007d20d97d355e  pop r10
00007d20d97d3560  pop r9
00007d20d97d3562  pop r8
00007d20d97d3564  pop rsi
00007d20d97d3565  pop rdi
00007d20d97d3566  pop rdx
00007d20d97d3567  pop rcx
00007d20d97d3568  pop rax
00007d20d97d3569  add rsp, 0x08
00007d20d97d356d  jmp 0x00007D20D97CFEF1
00007d20d97d3572  sub rsp, 0x08
00007d20d97d3576  push rax
00007d20d97d3577  push rcx
00007d20d97d3578  push rdx
00007d20d97d3579  push rdi
00007d20d97d357a  push rsi
00007d20d97d357b  push r8
00007d20d97d357d  push r9
00007d20d97d357f  push r10
00007d20d97d3581  push r11
00007d20d97d3583  sub rsp, 0xF0
00007d20d97d358a  vmovaps [rsp], xmm0
00007d20d97d358f  vmovaps [rsp+0x10], xmm1
00007d20d97d3595  vmovaps [rsp+0x20], xmm2
00007d20d97d359b  vmovaps [rsp+0x30], xmm3
00007d20d97d35a1  vmovaps [rsp+0x40], xmm4
00007d20d97d35a7  vmovaps [rsp+0x50], xmm5
00007d20d97d35ad  vmovaps [rsp+0x60], xmm7
00007d20d97d35b3  vmovaps [rsp+0x70], xmm8
00007d20d97d35b9  vmovaps [rsp+0x80], xmm9
00007d20d97d35c2  vmovaps [rsp+0x90], xmm10
00007d20d97d35cb  vmovaps [rsp+0xA0], xmm11
00007d20d97d35d4  vmovaps [rsp+0xB0], xmm12
00007d20d97d35dd  vmovaps [rsp+0xC0], xmm13
00007d20d97d35e6  vmovaps [rsp+0xD0], xmm14
00007d20d97d35ef  vmovaps [rsp+0xE0], xmm15
00007d20d97d35f8  sub rsp, 0x30
00007d20d97d35fc  movaps [rsp], xmm6
00007d20d97d3600  movaps [rsp+0x10], xmm9
00007d20d97d3606  movaps [rsp+0x20], xmm12
00007d20d97d360c  lea rdi, [rsp]
00007d20d97d3610  mov esi, 0x00
00007d20d97d3615  mov rax, 0x5EFBF4CF6530
00007d20d97d361f  call rax
00007d20d97d3621  movaps xmm6, [rsp]
00007d20d97d3625  add rsp, 0x30
00007d20d97d3629  vmovaps xmm0, [rsp]
00007d20d97d362e  vmovaps xmm1, [rsp+0x10]
00007d20d97d3634  vmovaps xmm2, [rsp+0x20]
00007d20d97d363a  vmovaps xmm3, [rsp+0x30]
00007d20d97d3640  vmovaps xmm4, [rsp+0x40]
00007d20d97d3646  vmovaps xmm5, [rsp+0x50]
00007d20d97d364c  vmovaps xmm7, [rsp+0x60]
00007d20d97d3652  vmovaps xmm8, [rsp+0x70]
00007d20d97d3658  vmovaps xmm9, [rsp+0x80]
00007d20d97d3661  vmovaps xmm10, [rsp+0x90]
00007d20d97d366a  vmovaps xmm11, [rsp+0xA0]
00007d20d97d3673  vmovaps xmm12, [rsp+0xB0]
00007d20d97d367c  vmovaps xmm13, [rsp+0xC0]
00007d20d97d3685  vmovaps xmm14, [rsp+0xD0]
00007d20d97d368e  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3697  add rsp, 0xF0
00007d20d97d369e  pop r11
00007d20d97d36a0  pop r10
00007d20d97d36a2  pop r9
00007d20d97d36a4  pop r8
00007d20d97d36a6  pop rsi
00007d20d97d36a7  pop rdi
00007d20d97d36a8  pop rdx
00007d20d97d36a9  pop rcx
00007d20d97d36aa  pop rax
00007d20d97d36ab  add rsp, 0x08
00007d20d97d36af  jmp 0x00007D20D97CFF19
00007d20d97d36b4  sub rsp, 0x08
00007d20d97d36b8  push rax
00007d20d97d36b9  push rcx
00007d20d97d36ba  push rdx
00007d20d97d36bb  push rdi
00007d20d97d36bc  push rsi
00007d20d97d36bd  push r8
00007d20d97d36bf  push r9
00007d20d97d36c1  push r10
00007d20d97d36c3  push r11
00007d20d97d36c5  sub rsp, 0xF0
00007d20d97d36cc  vmovaps [rsp], xmm0
00007d20d97d36d1  vmovaps [rsp+0x10], xmm1
00007d20d97d36d7  vmovaps [rsp+0x20], xmm2
00007d20d97d36dd  vmovaps [rsp+0x30], xmm3
00007d20d97d36e3  vmovaps [rsp+0x40], xmm4
00007d20d97d36e9  vmovaps [rsp+0x50], xmm5
00007d20d97d36ef  vmovaps [rsp+0x60], xmm6
00007d20d97d36f5  vmovaps [rsp+0x70], xmm7
00007d20d97d36fb  vmovaps [rsp+0x80], xmm8
00007d20d97d3704  vmovaps [rsp+0x90], xmm9
00007d20d97d370d  vmovaps [rsp+0xA0], xmm10
00007d20d97d3716  vmovaps [rsp+0xB0], xmm11
00007d20d97d371f  vmovaps [rsp+0xC0], xmm13
00007d20d97d3728  vmovaps [rsp+0xD0], xmm14
00007d20d97d3731  vmovaps [rsp+0xE0], xmm15
00007d20d97d373a  sub rsp, 0x30
00007d20d97d373e  movaps [rsp], xmm12
00007d20d97d3743  movaps [rsp+0x10], xmm15
00007d20d97d3749  movaps [rsp+0x20], xmm13
00007d20d97d374f  lea rdi, [rsp]
00007d20d97d3753  mov esi, 0x00
00007d20d97d3758  mov rax, 0x5EFBF4CF6530
00007d20d97d3762  call rax
00007d20d97d3764  movaps xmm12, [rsp]
00007d20d97d3769  add rsp, 0x30
00007d20d97d376d  vmovaps xmm0, [rsp]
00007d20d97d3772  vmovaps xmm1, [rsp+0x10]
00007d20d97d3778  vmovaps xmm2, [rsp+0x20]
00007d20d97d377e  vmovaps xmm3, [rsp+0x30]
00007d20d97d3784  vmovaps xmm4, [rsp+0x40]
00007d20d97d378a  vmovaps xmm5, [rsp+0x50]
00007d20d97d3790  vmovaps xmm6, [rsp+0x60]
00007d20d97d3796  vmovaps xmm7, [rsp+0x70]
00007d20d97d379c  vmovaps xmm8, [rsp+0x80]
00007d20d97d37a5  vmovaps xmm9, [rsp+0x90]
00007d20d97d37ae  vmovaps xmm10, [rsp+0xA0]
00007d20d97d37b7  vmovaps xmm11, [rsp+0xB0]
00007d20d97d37c0  vmovaps xmm13, [rsp+0xC0]
00007d20d97d37c9  vmovaps xmm14, [rsp+0xD0]
00007d20d97d37d2  vmovaps xmm15, [rsp+0xE0]
00007d20d97d37db  add rsp, 0xF0
00007d20d97d37e2  pop r11
00007d20d97d37e4  pop r10
00007d20d97d37e6  pop r9
00007d20d97d37e8  pop r8
00007d20d97d37ea  pop rsi
00007d20d97d37eb  pop rdi
00007d20d97d37ec  pop rdx
00007d20d97d37ed  pop rcx
00007d20d97d37ee  pop rax
00007d20d97d37ef  add rsp, 0x08
00007d20d97d37f3  jmp 0x00007D20D97CFF34
00007d20d97d37f8  sub rsp, 0x08
00007d20d97d37fc  push rax
00007d20d97d37fd  push rcx
00007d20d97d37fe  push rdx
00007d20d97d37ff  push rdi
00007d20d97d3800  push rsi
00007d20d97d3801  push r8
00007d20d97d3803  push r9
00007d20d97d3805  push r10
00007d20d97d3807  push r11
00007d20d97d3809  sub rsp, 0xF0
00007d20d97d3810  vmovaps [rsp], xmm0
00007d20d97d3815  vmovaps [rsp+0x10], xmm1
00007d20d97d381b  vmovaps [rsp+0x20], xmm2
00007d20d97d3821  vmovaps [rsp+0x30], xmm3
00007d20d97d3827  vmovaps [rsp+0x40], xmm4
00007d20d97d382d  vmovaps [rsp+0x50], xmm5
00007d20d97d3833  vmovaps [rsp+0x60], xmm6
00007d20d97d3839  vmovaps [rsp+0x70], xmm7
00007d20d97d383f  vmovaps [rsp+0x80], xmm8
00007d20d97d3848  vmovaps [rsp+0x90], xmm9
00007d20d97d3851  vmovaps [rsp+0xA0], xmm10
00007d20d97d385a  vmovaps [rsp+0xB0], xmm11
00007d20d97d3863  vmovaps [rsp+0xC0], xmm12
00007d20d97d386c  vmovaps [rsp+0xD0], xmm13
00007d20d97d3875  vmovaps [rsp+0xE0], xmm14
00007d20d97d387e  sub rsp, 0x30
00007d20d97d3882  movaps [rsp], xmm15
00007d20d97d3887  movaps [rsp+0x10], xmm13
00007d20d97d388d  movaps [rsp+0x20], xmm10
00007d20d97d3893  lea rdi, [rsp]
00007d20d97d3897  mov esi, 0x00
00007d20d97d389c  mov rax, 0x5EFBF4CF6530
00007d20d97d38a6  call rax
00007d20d97d38a8  movaps xmm15, [rsp]
00007d20d97d38ad  add rsp, 0x30
00007d20d97d38b1  vmovaps xmm0, [rsp]
00007d20d97d38b6  vmovaps xmm1, [rsp+0x10]
00007d20d97d38bc  vmovaps xmm2, [rsp+0x20]
00007d20d97d38c2  vmovaps xmm3, [rsp+0x30]
00007d20d97d38c8  vmovaps xmm4, [rsp+0x40]
00007d20d97d38ce  vmovaps xmm5, [rsp+0x50]
00007d20d97d38d4  vmovaps xmm6, [rsp+0x60]
00007d20d97d38da  vmovaps xmm7, [rsp+0x70]
00007d20d97d38e0  vmovaps xmm8, [rsp+0x80]
00007d20d97d38e9  vmovaps xmm9, [rsp+0x90]
00007d20d97d38f2  vmovaps xmm10, [rsp+0xA0]
00007d20d97d38fb  vmovaps xmm11, [rsp+0xB0]
00007d20d97d3904  vmovaps xmm12, [rsp+0xC0]
00007d20d97d390d  vmovaps xmm13, [rsp+0xD0]
00007d20d97d3916  vmovaps xmm14, [rsp+0xE0]
00007d20d97d391f  add rsp, 0xF0
00007d20d97d3926  pop r11
00007d20d97d3928  pop r10
00007d20d97d392a  pop r9
00007d20d97d392c  pop r8
00007d20d97d392e  pop rsi
00007d20d97d392f  pop rdi
00007d20d97d3930  pop rdx
00007d20d97d3931  pop rcx
00007d20d97d3932  pop rax
00007d20d97d3933  add rsp, 0x08
00007d20d97d3937  jmp 0x00007D20D97CFF55
00007d20d97d393c  call 0x00007D20D960C260
00007d20d97d3941  jmp 0x00007D20D97CFFB0
00007d20d97d3946  sub rsp, 0x08
00007d20d97d394a  push rax
00007d20d97d394b  push rcx
00007d20d97d394c  push rdx
00007d20d97d394d  push rdi
00007d20d97d394e  push rsi
00007d20d97d394f  push r8
00007d20d97d3951  push r9
00007d20d97d3953  push r10
00007d20d97d3955  push r11
00007d20d97d3957  sub rsp, 0xF0
00007d20d97d395e  vmovaps [rsp], xmm0
00007d20d97d3963  vmovaps [rsp+0x10], xmm1
00007d20d97d3969  vmovaps [rsp+0x20], xmm2
00007d20d97d396f  vmovaps [rsp+0x30], xmm3
00007d20d97d3975  vmovaps [rsp+0x40], xmm4
00007d20d97d397b  vmovaps [rsp+0x50], xmm5
00007d20d97d3981  vmovaps [rsp+0x60], xmm6
00007d20d97d3987  vmovaps [rsp+0x70], xmm7
00007d20d97d398d  vmovaps [rsp+0x80], xmm8
00007d20d97d3996  vmovaps [rsp+0x90], xmm10
00007d20d97d399f  vmovaps [rsp+0xA0], xmm11
00007d20d97d39a8  vmovaps [rsp+0xB0], xmm12
00007d20d97d39b1  vmovaps [rsp+0xC0], xmm13
00007d20d97d39ba  vmovaps [rsp+0xD0], xmm14
00007d20d97d39c3  vmovaps [rsp+0xE0], xmm15
00007d20d97d39cc  sub rsp, 0x30
00007d20d97d39d0  movaps [rsp], xmm9
00007d20d97d39d5  movaps [rsp+0x10], xmm8
00007d20d97d39db  movaps [rsp+0x20], xmm10
00007d20d97d39e1  lea rdi, [rsp]
00007d20d97d39e5  mov esi, 0x00
00007d20d97d39ea  mov rax, 0x5EFBF4CF6530
00007d20d97d39f4  call rax
00007d20d97d39f6  movaps xmm9, [rsp]
00007d20d97d39fb  add rsp, 0x30
00007d20d97d39ff  vmovaps xmm0, [rsp]
00007d20d97d3a04  vmovaps xmm1, [rsp+0x10]
00007d20d97d3a0a  vmovaps xmm2, [rsp+0x20]
00007d20d97d3a10  vmovaps xmm3, [rsp+0x30]
00007d20d97d3a16  vmovaps xmm4, [rsp+0x40]
00007d20d97d3a1c  vmovaps xmm5, [rsp+0x50]
00007d20d97d3a22  vmovaps xmm6, [rsp+0x60]
00007d20d97d3a28  vmovaps xmm7, [rsp+0x70]
00007d20d97d3a2e  vmovaps xmm8, [rsp+0x80]
00007d20d97d3a37  vmovaps xmm10, [rsp+0x90]
00007d20d97d3a40  vmovaps xmm11, [rsp+0xA0]
00007d20d97d3a49  vmovaps xmm12, [rsp+0xB0]
00007d20d97d3a52  vmovaps xmm13, [rsp+0xC0]
00007d20d97d3a5b  vmovaps xmm14, [rsp+0xD0]
00007d20d97d3a64  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3a6d  add rsp, 0xF0
00007d20d97d3a74  pop r11
00007d20d97d3a76  pop r10
00007d20d97d3a78  pop r9
00007d20d97d3a7a  pop r8
00007d20d97d3a7c  pop rsi
00007d20d97d3a7d  pop rdi
00007d20d97d3a7e  pop rdx
00007d20d97d3a7f  pop rcx
00007d20d97d3a80  pop rax
00007d20d97d3a81  add rsp, 0x08
00007d20d97d3a85  jmp 0x00007D20D97CFFE1
00007d20d97d3a8a  sub rsp, 0x08
00007d20d97d3a8e  push rax
00007d20d97d3a8f  push rcx
00007d20d97d3a90  push rdx
00007d20d97d3a91  push rdi
00007d20d97d3a92  push rsi
00007d20d97d3a93  push r8
00007d20d97d3a95  push r9
00007d20d97d3a97  push r10
00007d20d97d3a99  push r11
00007d20d97d3a9b  sub rsp, 0xF0
00007d20d97d3aa2  vmovaps [rsp], xmm0
00007d20d97d3aa7  vmovaps [rsp+0x10], xmm1
00007d20d97d3aad  vmovaps [rsp+0x20], xmm2
00007d20d97d3ab3  vmovaps [rsp+0x30], xmm3
00007d20d97d3ab9  vmovaps [rsp+0x40], xmm4
00007d20d97d3abf  vmovaps [rsp+0x50], xmm5
00007d20d97d3ac5  vmovaps [rsp+0x60], xmm6
00007d20d97d3acb  vmovaps [rsp+0x70], xmm7
00007d20d97d3ad1  vmovaps [rsp+0x80], xmm8
00007d20d97d3ada  vmovaps [rsp+0x90], xmm9
00007d20d97d3ae3  vmovaps [rsp+0xA0], xmm11
00007d20d97d3aec  vmovaps [rsp+0xB0], xmm12
00007d20d97d3af5  vmovaps [rsp+0xC0], xmm13
00007d20d97d3afe  vmovaps [rsp+0xD0], xmm14
00007d20d97d3b07  vmovaps [rsp+0xE0], xmm15
00007d20d97d3b10  sub rsp, 0x30
00007d20d97d3b14  movaps [rsp], xmm10
00007d20d97d3b19  movaps [rsp+0x10], xmm1
00007d20d97d3b1e  movaps [rsp+0x20], xmm11
00007d20d97d3b24  lea rdi, [rsp]
00007d20d97d3b28  mov esi, 0x00
00007d20d97d3b2d  mov rax, 0x5EFBF4CF6530
00007d20d97d3b37  call rax
00007d20d97d3b39  movaps xmm10, [rsp]
00007d20d97d3b3e  add rsp, 0x30
00007d20d97d3b42  vmovaps xmm0, [rsp]
00007d20d97d3b47  vmovaps xmm1, [rsp+0x10]
00007d20d97d3b4d  vmovaps xmm2, [rsp+0x20]
00007d20d97d3b53  vmovaps xmm3, [rsp+0x30]
00007d20d97d3b59  vmovaps xmm4, [rsp+0x40]
00007d20d97d3b5f  vmovaps xmm5, [rsp+0x50]
00007d20d97d3b65  vmovaps xmm6, [rsp+0x60]
00007d20d97d3b6b  vmovaps xmm7, [rsp+0x70]
00007d20d97d3b71  vmovaps xmm8, [rsp+0x80]
00007d20d97d3b7a  vmovaps xmm9, [rsp+0x90]
00007d20d97d3b83  vmovaps xmm11, [rsp+0xA0]
00007d20d97d3b8c  vmovaps xmm12, [rsp+0xB0]
00007d20d97d3b95  vmovaps xmm13, [rsp+0xC0]
00007d20d97d3b9e  vmovaps xmm14, [rsp+0xD0]
00007d20d97d3ba7  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3bb0  add rsp, 0xF0
00007d20d97d3bb7  pop r11
00007d20d97d3bb9  pop r10
00007d20d97d3bbb  pop r9
00007d20d97d3bbd  pop r8
00007d20d97d3bbf  pop rsi
00007d20d97d3bc0  pop rdi
00007d20d97d3bc1  pop rdx
00007d20d97d3bc2  pop rcx
00007d20d97d3bc3  pop rax
00007d20d97d3bc4  add rsp, 0x08
00007d20d97d3bc8  jmp 0x00007D20D97CFFFC
00007d20d97d3bcd  sub rsp, 0x08
00007d20d97d3bd1  push rax
00007d20d97d3bd2  push rcx
00007d20d97d3bd3  push rdx
00007d20d97d3bd4  push rdi
00007d20d97d3bd5  push rsi
00007d20d97d3bd6  push r8
00007d20d97d3bd8  push r9
00007d20d97d3bda  push r10
00007d20d97d3bdc  push r11
00007d20d97d3bde  sub rsp, 0xF0
00007d20d97d3be5  vmovaps [rsp], xmm0
00007d20d97d3bea  vmovaps [rsp+0x10], xmm2
00007d20d97d3bf0  vmovaps [rsp+0x20], xmm3
00007d20d97d3bf6  vmovaps [rsp+0x30], xmm4
00007d20d97d3bfc  vmovaps [rsp+0x40], xmm5
00007d20d97d3c02  vmovaps [rsp+0x50], xmm6
00007d20d97d3c08  vmovaps [rsp+0x60], xmm7
00007d20d97d3c0e  vmovaps [rsp+0x70], xmm8
00007d20d97d3c14  vmovaps [rsp+0x80], xmm9
00007d20d97d3c1d  vmovaps [rsp+0x90], xmm10
00007d20d97d3c26  vmovaps [rsp+0xA0], xmm11
00007d20d97d3c2f  vmovaps [rsp+0xB0], xmm12
00007d20d97d3c38  vmovaps [rsp+0xC0], xmm13
00007d20d97d3c41  vmovaps [rsp+0xD0], xmm14
00007d20d97d3c4a  vmovaps [rsp+0xE0], xmm15
00007d20d97d3c53  sub rsp, 0x30
00007d20d97d3c57  movaps [rsp], xmm1
00007d20d97d3c5b  movaps [rsp+0x10], xmm14
00007d20d97d3c61  movaps [rsp+0x20], xmm6
00007d20d97d3c66  lea rdi, [rsp]
00007d20d97d3c6a  mov esi, 0x00
00007d20d97d3c6f  mov rax, 0x5EFBF4CF6530
00007d20d97d3c79  call rax
00007d20d97d3c7b  movaps xmm1, [rsp]
00007d20d97d3c7f  add rsp, 0x30
00007d20d97d3c83  vmovaps xmm0, [rsp]
00007d20d97d3c88  vmovaps xmm2, [rsp+0x10]
00007d20d97d3c8e  vmovaps xmm3, [rsp+0x20]
00007d20d97d3c94  vmovaps xmm4, [rsp+0x30]
00007d20d97d3c9a  vmovaps xmm5, [rsp+0x40]
00007d20d97d3ca0  vmovaps xmm6, [rsp+0x50]
00007d20d97d3ca6  vmovaps xmm7, [rsp+0x60]
00007d20d97d3cac  vmovaps xmm8, [rsp+0x70]
00007d20d97d3cb2  vmovaps xmm9, [rsp+0x80]
00007d20d97d3cbb  vmovaps xmm10, [rsp+0x90]
00007d20d97d3cc4  vmovaps xmm11, [rsp+0xA0]
00007d20d97d3ccd  vmovaps xmm12, [rsp+0xB0]
00007d20d97d3cd6  vmovaps xmm13, [rsp+0xC0]
00007d20d97d3cdf  vmovaps xmm14, [rsp+0xD0]
00007d20d97d3ce8  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3cf1  add rsp, 0xF0
00007d20d97d3cf8  pop r11
00007d20d97d3cfa  pop r10
00007d20d97d3cfc  pop r9
00007d20d97d3cfe  pop r8
00007d20d97d3d00  pop rsi
00007d20d97d3d01  pop rdi
00007d20d97d3d02  pop rdx
00007d20d97d3d03  pop rcx
00007d20d97d3d04  pop rax
00007d20d97d3d05  add rsp, 0x08
00007d20d97d3d09  jmp 0x00007D20D97D0015
00007d20d97d3d0e  sub rsp, 0x08
00007d20d97d3d12  push rax
00007d20d97d3d13  push rcx
00007d20d97d3d14  push rdx
00007d20d97d3d15  push rdi
00007d20d97d3d16  push rsi
00007d20d97d3d17  push r8
00007d20d97d3d19  push r9
00007d20d97d3d1b  push r10
00007d20d97d3d1d  push r11
00007d20d97d3d1f  sub rsp, 0xF0
00007d20d97d3d26  vmovaps [rsp], xmm0
00007d20d97d3d2b  vmovaps [rsp+0x10], xmm1
00007d20d97d3d31  vmovaps [rsp+0x20], xmm2
00007d20d97d3d37  vmovaps [rsp+0x30], xmm3
00007d20d97d3d3d  vmovaps [rsp+0x40], xmm4
00007d20d97d3d43  vmovaps [rsp+0x50], xmm5
00007d20d97d3d49  vmovaps [rsp+0x60], xmm6
00007d20d97d3d4f  vmovaps [rsp+0x70], xmm7
00007d20d97d3d55  vmovaps [rsp+0x80], xmm8
00007d20d97d3d5e  vmovaps [rsp+0x90], xmm9
00007d20d97d3d67  vmovaps [rsp+0xA0], xmm10
00007d20d97d3d70  vmovaps [rsp+0xB0], xmm12
00007d20d97d3d79  vmovaps [rsp+0xC0], xmm13
00007d20d97d3d82  vmovaps [rsp+0xD0], xmm14
00007d20d97d3d8b  vmovaps [rsp+0xE0], xmm15
00007d20d97d3d94  sub rsp, 0x30
00007d20d97d3d98  movaps [rsp], xmm11
00007d20d97d3d9d  movaps [rsp+0x10], xmm13
00007d20d97d3da3  movaps [rsp+0x20], xmm14
00007d20d97d3da9  lea rdi, [rsp]
00007d20d97d3dad  mov esi, 0x00
00007d20d97d3db2  mov rax, 0x5EFBF4CF6530
00007d20d97d3dbc  call rax
00007d20d97d3dbe  movaps xmm11, [rsp]
00007d20d97d3dc3  add rsp, 0x30
00007d20d97d3dc7  vmovaps xmm0, [rsp]
00007d20d97d3dcc  vmovaps xmm1, [rsp+0x10]
00007d20d97d3dd2  vmovaps xmm2, [rsp+0x20]
00007d20d97d3dd8  vmovaps xmm3, [rsp+0x30]
00007d20d97d3dde  vmovaps xmm4, [rsp+0x40]
00007d20d97d3de4  vmovaps xmm5, [rsp+0x50]
00007d20d97d3dea  vmovaps xmm6, [rsp+0x60]
00007d20d97d3df0  vmovaps xmm7, [rsp+0x70]
00007d20d97d3df6  vmovaps xmm8, [rsp+0x80]
00007d20d97d3dff  vmovaps xmm9, [rsp+0x90]
00007d20d97d3e08  vmovaps xmm10, [rsp+0xA0]
00007d20d97d3e11  vmovaps xmm12, [rsp+0xB0]
00007d20d97d3e1a  vmovaps xmm13, [rsp+0xC0]
00007d20d97d3e23  vmovaps xmm14, [rsp+0xD0]
00007d20d97d3e2c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3e35  add rsp, 0xF0
00007d20d97d3e3c  pop r11
00007d20d97d3e3e  pop r10
00007d20d97d3e40  pop r9
00007d20d97d3e42  pop r8
00007d20d97d3e44  pop rsi
00007d20d97d3e45  pop rdi
00007d20d97d3e46  pop rdx
00007d20d97d3e47  pop rcx
00007d20d97d3e48  pop rax
00007d20d97d3e49  add rsp, 0x08
00007d20d97d3e4d  jmp 0x00007D20D97D003F
00007d20d97d3e52  sub rsp, 0x08
00007d20d97d3e56  push rax
00007d20d97d3e57  push rcx
00007d20d97d3e58  push rdx
00007d20d97d3e59  push rdi
00007d20d97d3e5a  push rsi
00007d20d97d3e5b  push r8
00007d20d97d3e5d  push r9
00007d20d97d3e5f  push r10
00007d20d97d3e61  push r11
00007d20d97d3e63  sub rsp, 0xF0
00007d20d97d3e6a  vmovaps [rsp], xmm0
00007d20d97d3e6f  vmovaps [rsp+0x10], xmm1
00007d20d97d3e75  vmovaps [rsp+0x20], xmm2
00007d20d97d3e7b  vmovaps [rsp+0x30], xmm3
00007d20d97d3e81  vmovaps [rsp+0x40], xmm4
00007d20d97d3e87  vmovaps [rsp+0x50], xmm5
00007d20d97d3e8d  vmovaps [rsp+0x60], xmm6
00007d20d97d3e93  vmovaps [rsp+0x70], xmm7
00007d20d97d3e99  vmovaps [rsp+0x80], xmm8
00007d20d97d3ea2  vmovaps [rsp+0x90], xmm9
00007d20d97d3eab  vmovaps [rsp+0xA0], xmm10
00007d20d97d3eb4  vmovaps [rsp+0xB0], xmm11
00007d20d97d3ebd  vmovaps [rsp+0xC0], xmm12
00007d20d97d3ec6  vmovaps [rsp+0xD0], xmm14
00007d20d97d3ecf  vmovaps [rsp+0xE0], xmm15
00007d20d97d3ed8  sub rsp, 0x30
00007d20d97d3edc  movaps [rsp], xmm13
00007d20d97d3ee1  movaps [rsp+0x10], xmm8
00007d20d97d3ee7  movaps [rsp+0x20], xmm14
00007d20d97d3eed  lea rdi, [rsp]
00007d20d97d3ef1  mov esi, 0x00
00007d20d97d3ef6  mov rax, 0x5EFBF4CF6530
00007d20d97d3f00  call rax
00007d20d97d3f02  movaps xmm13, [rsp]
00007d20d97d3f07  add rsp, 0x30
00007d20d97d3f0b  vmovaps xmm0, [rsp]
00007d20d97d3f10  vmovaps xmm1, [rsp+0x10]
00007d20d97d3f16  vmovaps xmm2, [rsp+0x20]
00007d20d97d3f1c  vmovaps xmm3, [rsp+0x30]
00007d20d97d3f22  vmovaps xmm4, [rsp+0x40]
00007d20d97d3f28  vmovaps xmm5, [rsp+0x50]
00007d20d97d3f2e  vmovaps xmm6, [rsp+0x60]
00007d20d97d3f34  vmovaps xmm7, [rsp+0x70]
00007d20d97d3f3a  vmovaps xmm8, [rsp+0x80]
00007d20d97d3f43  vmovaps xmm9, [rsp+0x90]
00007d20d97d3f4c  vmovaps xmm10, [rsp+0xA0]
00007d20d97d3f55  vmovaps xmm11, [rsp+0xB0]
00007d20d97d3f5e  vmovaps xmm12, [rsp+0xC0]
00007d20d97d3f67  vmovaps xmm14, [rsp+0xD0]
00007d20d97d3f70  vmovaps xmm15, [rsp+0xE0]
00007d20d97d3f79  add rsp, 0xF0
00007d20d97d3f80  pop r11
00007d20d97d3f82  pop r10
00007d20d97d3f84  pop r9
00007d20d97d3f86  pop r8
00007d20d97d3f88  pop rsi
00007d20d97d3f89  pop rdi
00007d20d97d3f8a  pop rdx
00007d20d97d3f8b  pop rcx
00007d20d97d3f8c  pop rax
00007d20d97d3f8d  add rsp, 0x08
00007d20d97d3f91  jmp 0x00007D20D97D006E
00007d20d97d3f96  sub rsp, 0x08
00007d20d97d3f9a  push rax
00007d20d97d3f9b  push rcx
00007d20d97d3f9c  push rdx
00007d20d97d3f9d  push rdi
00007d20d97d3f9e  push rsi
00007d20d97d3f9f  push r8
00007d20d97d3fa1  push r9
00007d20d97d3fa3  push r10
00007d20d97d3fa5  push r11
00007d20d97d3fa7  sub rsp, 0xF0
00007d20d97d3fae  vmovaps [rsp], xmm0
00007d20d97d3fb3  vmovaps [rsp+0x10], xmm1
00007d20d97d3fb9  vmovaps [rsp+0x20], xmm2
00007d20d97d3fbf  vmovaps [rsp+0x30], xmm3
00007d20d97d3fc5  vmovaps [rsp+0x40], xmm4
00007d20d97d3fcb  vmovaps [rsp+0x50], xmm5
00007d20d97d3fd1  vmovaps [rsp+0x60], xmm6
00007d20d97d3fd7  vmovaps [rsp+0x70], xmm7
00007d20d97d3fdd  vmovaps [rsp+0x80], xmm9
00007d20d97d3fe6  vmovaps [rsp+0x90], xmm10
00007d20d97d3fef  vmovaps [rsp+0xA0], xmm11
00007d20d97d3ff8  vmovaps [rsp+0xB0], xmm12
00007d20d97d4001  vmovaps [rsp+0xC0], xmm13
00007d20d97d400a  vmovaps [rsp+0xD0], xmm14
00007d20d97d4013  vmovaps [rsp+0xE0], xmm15
00007d20d97d401c  sub rsp, 0x30
00007d20d97d4020  movaps [rsp], xmm8
00007d20d97d4025  movaps [rsp+0x10], xmm7
00007d20d97d402a  movaps [rsp+0x20], xmm14
00007d20d97d4030  lea rdi, [rsp]
00007d20d97d4034  mov esi, 0x00
00007d20d97d4039  mov rax, 0x5EFBF4CF6530
00007d20d97d4043  call rax
00007d20d97d4045  movaps xmm8, [rsp]
00007d20d97d404a  add rsp, 0x30
00007d20d97d404e  vmovaps xmm0, [rsp]
00007d20d97d4053  vmovaps xmm1, [rsp+0x10]
00007d20d97d4059  vmovaps xmm2, [rsp+0x20]
00007d20d97d405f  vmovaps xmm3, [rsp+0x30]
00007d20d97d4065  vmovaps xmm4, [rsp+0x40]
00007d20d97d406b  vmovaps xmm5, [rsp+0x50]
00007d20d97d4071  vmovaps xmm6, [rsp+0x60]
00007d20d97d4077  vmovaps xmm7, [rsp+0x70]
00007d20d97d407d  vmovaps xmm9, [rsp+0x80]
00007d20d97d4086  vmovaps xmm10, [rsp+0x90]
00007d20d97d408f  vmovaps xmm11, [rsp+0xA0]
00007d20d97d4098  vmovaps xmm12, [rsp+0xB0]
00007d20d97d40a1  vmovaps xmm13, [rsp+0xC0]
00007d20d97d40aa  vmovaps xmm14, [rsp+0xD0]
00007d20d97d40b3  vmovaps xmm15, [rsp+0xE0]
00007d20d97d40bc  add rsp, 0xF0
00007d20d97d40c3  pop r11
00007d20d97d40c5  pop r10
00007d20d97d40c7  pop r9
00007d20d97d40c9  pop r8
00007d20d97d40cb  pop rsi
00007d20d97d40cc  pop rdi
00007d20d97d40cd  pop rdx
00007d20d97d40ce  pop rcx
00007d20d97d40cf  pop rax
00007d20d97d40d0  add rsp, 0x08
00007d20d97d40d4  jmp 0x00007D20D97D0094
00007d20d97d40d9  sub rsp, 0x08
00007d20d97d40dd  push rax
00007d20d97d40de  push rcx
00007d20d97d40df  push rdx
00007d20d97d40e0  push rdi
00007d20d97d40e1  push rsi
00007d20d97d40e2  push r8
00007d20d97d40e4  push r9
00007d20d97d40e6  push r10
00007d20d97d40e8  push r11
00007d20d97d40ea  sub rsp, 0xF0
00007d20d97d40f1  vmovaps [rsp], xmm0
00007d20d97d40f6  vmovaps [rsp+0x10], xmm1
00007d20d97d40fc  vmovaps [rsp+0x20], xmm2
00007d20d97d4102  vmovaps [rsp+0x30], xmm3
00007d20d97d4108  vmovaps [rsp+0x40], xmm4
00007d20d97d410e  vmovaps [rsp+0x50], xmm5
00007d20d97d4114  vmovaps [rsp+0x60], xmm6
00007d20d97d411a  vmovaps [rsp+0x70], xmm7
00007d20d97d4120  vmovaps [rsp+0x80], xmm8
00007d20d97d4129  vmovaps [rsp+0x90], xmm9
00007d20d97d4132  vmovaps [rsp+0xA0], xmm10
00007d20d97d413b  vmovaps [rsp+0xB0], xmm11
00007d20d97d4144  vmovaps [rsp+0xC0], xmm12
00007d20d97d414d  vmovaps [rsp+0xD0], xmm13
00007d20d97d4156  vmovaps [rsp+0xE0], xmm15
00007d20d97d415f  sub rsp, 0x30
00007d20d97d4163  movaps [rsp], xmm14
00007d20d97d4168  movaps [rsp+0x10], xmm12
00007d20d97d416e  movaps [rsp+0x20], xmm9
00007d20d97d4174  lea rdi, [rsp]
00007d20d97d4178  mov esi, 0x00
00007d20d97d417d  mov rax, 0x5EFBF4CF6530
00007d20d97d4187  call rax
00007d20d97d4189  movaps xmm14, [rsp]
00007d20d97d418e  add rsp, 0x30
00007d20d97d4192  vmovaps xmm0, [rsp]
00007d20d97d4197  vmovaps xmm1, [rsp+0x10]
00007d20d97d419d  vmovaps xmm2, [rsp+0x20]
00007d20d97d41a3  vmovaps xmm3, [rsp+0x30]
00007d20d97d41a9  vmovaps xmm4, [rsp+0x40]
00007d20d97d41af  vmovaps xmm5, [rsp+0x50]
00007d20d97d41b5  vmovaps xmm6, [rsp+0x60]
00007d20d97d41bb  vmovaps xmm7, [rsp+0x70]
00007d20d97d41c1  vmovaps xmm8, [rsp+0x80]
00007d20d97d41ca  vmovaps xmm9, [rsp+0x90]
00007d20d97d41d3  vmovaps xmm10, [rsp+0xA0]
00007d20d97d41dc  vmovaps xmm11, [rsp+0xB0]
00007d20d97d41e5  vmovaps xmm12, [rsp+0xC0]
00007d20d97d41ee  vmovaps xmm13, [rsp+0xD0]
00007d20d97d41f7  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4200  add rsp, 0xF0
00007d20d97d4207  pop r11
00007d20d97d4209  pop r10
00007d20d97d420b  pop r9
00007d20d97d420d  pop r8
00007d20d97d420f  pop rsi
00007d20d97d4210  pop rdi
00007d20d97d4211  pop rdx
00007d20d97d4212  pop rcx
00007d20d97d4213  pop rax
00007d20d97d4214  add rsp, 0x08
00007d20d97d4218  jmp 0x00007D20D97D00AE
00007d20d97d421d  sub rsp, 0x08
00007d20d97d4221  push rax
00007d20d97d4222  push rcx
00007d20d97d4223  push rdx
00007d20d97d4224  push rdi
00007d20d97d4225  push rsi
00007d20d97d4226  push r8
00007d20d97d4228  push r9
00007d20d97d422a  push r10
00007d20d97d422c  push r11
00007d20d97d422e  sub rsp, 0xF0
00007d20d97d4235  vmovaps [rsp], xmm0
00007d20d97d423a  vmovaps [rsp+0x10], xmm1
00007d20d97d4240  vmovaps [rsp+0x20], xmm2
00007d20d97d4246  vmovaps [rsp+0x30], xmm3
00007d20d97d424c  vmovaps [rsp+0x40], xmm4
00007d20d97d4252  vmovaps [rsp+0x50], xmm5
00007d20d97d4258  vmovaps [rsp+0x60], xmm6
00007d20d97d425e  vmovaps [rsp+0x70], xmm7
00007d20d97d4264  vmovaps [rsp+0x80], xmm8
00007d20d97d426d  vmovaps [rsp+0x90], xmm10
00007d20d97d4276  vmovaps [rsp+0xA0], xmm11
00007d20d97d427f  vmovaps [rsp+0xB0], xmm12
00007d20d97d4288  vmovaps [rsp+0xC0], xmm13
00007d20d97d4291  vmovaps [rsp+0xD0], xmm14
00007d20d97d429a  vmovaps [rsp+0xE0], xmm15
00007d20d97d42a3  sub rsp, 0x30
00007d20d97d42a7  movaps [rsp], xmm9
00007d20d97d42ac  movaps [rsp+0x10], xmm7
00007d20d97d42b1  movaps [rsp+0x20], xmm12
00007d20d97d42b7  lea rdi, [rsp]
00007d20d97d42bb  mov esi, 0x00
00007d20d97d42c0  mov rax, 0x5EFBF4CF6530
00007d20d97d42ca  call rax
00007d20d97d42cc  movaps xmm9, [rsp]
00007d20d97d42d1  add rsp, 0x30
00007d20d97d42d5  vmovaps xmm0, [rsp]
00007d20d97d42da  vmovaps xmm1, [rsp+0x10]
00007d20d97d42e0  vmovaps xmm2, [rsp+0x20]
00007d20d97d42e6  vmovaps xmm3, [rsp+0x30]
00007d20d97d42ec  vmovaps xmm4, [rsp+0x40]
00007d20d97d42f2  vmovaps xmm5, [rsp+0x50]
00007d20d97d42f8  vmovaps xmm6, [rsp+0x60]
00007d20d97d42fe  vmovaps xmm7, [rsp+0x70]
00007d20d97d4304  vmovaps xmm8, [rsp+0x80]
00007d20d97d430d  vmovaps xmm10, [rsp+0x90]
00007d20d97d4316  vmovaps xmm11, [rsp+0xA0]
00007d20d97d431f  vmovaps xmm12, [rsp+0xB0]
00007d20d97d4328  vmovaps xmm13, [rsp+0xC0]
00007d20d97d4331  vmovaps xmm14, [rsp+0xD0]
00007d20d97d433a  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4343  add rsp, 0xF0
00007d20d97d434a  pop r11
00007d20d97d434c  pop r10
00007d20d97d434e  pop r9
00007d20d97d4350  pop r8
00007d20d97d4352  pop rsi
00007d20d97d4353  pop rdi
00007d20d97d4354  pop rdx
00007d20d97d4355  pop rcx
00007d20d97d4356  pop rax
00007d20d97d4357  add rsp, 0x08
00007d20d97d435b  jmp 0x00007D20D97D00DD
00007d20d97d4360  sub rsp, 0x08
00007d20d97d4364  push rax
00007d20d97d4365  push rcx
00007d20d97d4366  push rdx
00007d20d97d4367  push rdi
00007d20d97d4368  push rsi
00007d20d97d4369  push r8
00007d20d97d436b  push r9
00007d20d97d436d  push r10
00007d20d97d436f  push r11
00007d20d97d4371  sub rsp, 0xF0
00007d20d97d4378  vmovaps [rsp], xmm0
00007d20d97d437d  vmovaps [rsp+0x10], xmm1
00007d20d97d4383  vmovaps [rsp+0x20], xmm2
00007d20d97d4389  vmovaps [rsp+0x30], xmm3
00007d20d97d438f  vmovaps [rsp+0x40], xmm4
00007d20d97d4395  vmovaps [rsp+0x50], xmm5
00007d20d97d439b  vmovaps [rsp+0x60], xmm6
00007d20d97d43a1  vmovaps [rsp+0x70], xmm7
00007d20d97d43a7  vmovaps [rsp+0x80], xmm8
00007d20d97d43b0  vmovaps [rsp+0x90], xmm9
00007d20d97d43b9  vmovaps [rsp+0xA0], xmm10
00007d20d97d43c2  vmovaps [rsp+0xB0], xmm11
00007d20d97d43cb  vmovaps [rsp+0xC0], xmm13
00007d20d97d43d4  vmovaps [rsp+0xD0], xmm14
00007d20d97d43dd  vmovaps [rsp+0xE0], xmm15
00007d20d97d43e6  sub rsp, 0x30
00007d20d97d43ea  movaps [rsp], xmm12
00007d20d97d43ef  movaps [rsp+0x10], xmm15
00007d20d97d43f5  movaps [rsp+0x20], xmm11
00007d20d97d43fb  lea rdi, [rsp]
00007d20d97d43ff  mov esi, 0x00
00007d20d97d4404  mov rax, 0x5EFBF4CF6530
00007d20d97d440e  call rax
00007d20d97d4410  movaps xmm12, [rsp]
00007d20d97d4415  add rsp, 0x30
00007d20d97d4419  vmovaps xmm0, [rsp]
00007d20d97d441e  vmovaps xmm1, [rsp+0x10]
00007d20d97d4424  vmovaps xmm2, [rsp+0x20]
00007d20d97d442a  vmovaps xmm3, [rsp+0x30]
00007d20d97d4430  vmovaps xmm4, [rsp+0x40]
00007d20d97d4436  vmovaps xmm5, [rsp+0x50]
00007d20d97d443c  vmovaps xmm6, [rsp+0x60]
00007d20d97d4442  vmovaps xmm7, [rsp+0x70]
00007d20d97d4448  vmovaps xmm8, [rsp+0x80]
00007d20d97d4451  vmovaps xmm9, [rsp+0x90]
00007d20d97d445a  vmovaps xmm10, [rsp+0xA0]
00007d20d97d4463  vmovaps xmm11, [rsp+0xB0]
00007d20d97d446c  vmovaps xmm13, [rsp+0xC0]
00007d20d97d4475  vmovaps xmm14, [rsp+0xD0]
00007d20d97d447e  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4487  add rsp, 0xF0
00007d20d97d448e  pop r11
00007d20d97d4490  pop r10
00007d20d97d4492  pop r9
00007d20d97d4494  pop r8
00007d20d97d4496  pop rsi
00007d20d97d4497  pop rdi
00007d20d97d4498  pop rdx
00007d20d97d4499  pop rcx
00007d20d97d449a  pop rax
00007d20d97d449b  add rsp, 0x08
00007d20d97d449f  jmp 0x00007D20D97D00F7
00007d20d97d44a4  sub rsp, 0x08
00007d20d97d44a8  push rax
00007d20d97d44a9  push rcx
00007d20d97d44aa  push rdx
00007d20d97d44ab  push rdi
00007d20d97d44ac  push rsi
00007d20d97d44ad  push r8
00007d20d97d44af  push r9
00007d20d97d44b1  push r10
00007d20d97d44b3  push r11
00007d20d97d44b5  sub rsp, 0xF0
00007d20d97d44bc  vmovaps [rsp], xmm0
00007d20d97d44c1  vmovaps [rsp+0x10], xmm1
00007d20d97d44c7  vmovaps [rsp+0x20], xmm2
00007d20d97d44cd  vmovaps [rsp+0x30], xmm3
00007d20d97d44d3  vmovaps [rsp+0x40], xmm4
00007d20d97d44d9  vmovaps [rsp+0x50], xmm5
00007d20d97d44df  vmovaps [rsp+0x60], xmm6
00007d20d97d44e5  vmovaps [rsp+0x70], xmm7
00007d20d97d44eb  vmovaps [rsp+0x80], xmm8
00007d20d97d44f4  vmovaps [rsp+0x90], xmm9
00007d20d97d44fd  vmovaps [rsp+0xA0], xmm10
00007d20d97d4506  vmovaps [rsp+0xB0], xmm12
00007d20d97d450f  vmovaps [rsp+0xC0], xmm13
00007d20d97d4518  vmovaps [rsp+0xD0], xmm14
00007d20d97d4521  vmovaps [rsp+0xE0], xmm15
00007d20d97d452a  sub rsp, 0x30
00007d20d97d452e  movaps [rsp], xmm11
00007d20d97d4533  movaps [rsp+0x10], xmm7
00007d20d97d4538  movaps [rsp+0x20], xmm15
00007d20d97d453e  lea rdi, [rsp]
00007d20d97d4542  mov esi, 0x00
00007d20d97d4547  mov rax, 0x5EFBF4CF6530
00007d20d97d4551  call rax
00007d20d97d4553  movaps xmm11, [rsp]
00007d20d97d4558  add rsp, 0x30
00007d20d97d455c  vmovaps xmm0, [rsp]
00007d20d97d4561  vmovaps xmm1, [rsp+0x10]
00007d20d97d4567  vmovaps xmm2, [rsp+0x20]
00007d20d97d456d  vmovaps xmm3, [rsp+0x30]
00007d20d97d4573  vmovaps xmm4, [rsp+0x40]
00007d20d97d4579  vmovaps xmm5, [rsp+0x50]
00007d20d97d457f  vmovaps xmm6, [rsp+0x60]
00007d20d97d4585  vmovaps xmm7, [rsp+0x70]
00007d20d97d458b  vmovaps xmm8, [rsp+0x80]
00007d20d97d4594  vmovaps xmm9, [rsp+0x90]
00007d20d97d459d  vmovaps xmm10, [rsp+0xA0]
00007d20d97d45a6  vmovaps xmm12, [rsp+0xB0]
00007d20d97d45af  vmovaps xmm13, [rsp+0xC0]
00007d20d97d45b8  vmovaps xmm14, [rsp+0xD0]
00007d20d97d45c1  vmovaps xmm15, [rsp+0xE0]
00007d20d97d45ca  add rsp, 0xF0
00007d20d97d45d1  pop r11
00007d20d97d45d3  pop r10
00007d20d97d45d5  pop r9
00007d20d97d45d7  pop r8
00007d20d97d45d9  pop rsi
00007d20d97d45da  pop rdi
00007d20d97d45db  pop rdx
00007d20d97d45dc  pop rcx
00007d20d97d45dd  pop rax
00007d20d97d45de  add rsp, 0x08
00007d20d97d45e2  jmp 0x00007D20D97D0123
00007d20d97d45e7  sub rsp, 0x08
00007d20d97d45eb  push rax
00007d20d97d45ec  push rcx
00007d20d97d45ed  push rdx
00007d20d97d45ee  push rdi
00007d20d97d45ef  push rsi
00007d20d97d45f0  push r8
00007d20d97d45f2  push r9
00007d20d97d45f4  push r10
00007d20d97d45f6  push r11
00007d20d97d45f8  sub rsp, 0xF0
00007d20d97d45ff  vmovaps [rsp], xmm0
00007d20d97d4604  vmovaps [rsp+0x10], xmm1
00007d20d97d460a  vmovaps [rsp+0x20], xmm2
00007d20d97d4610  vmovaps [rsp+0x30], xmm3
00007d20d97d4616  vmovaps [rsp+0x40], xmm4
00007d20d97d461c  vmovaps [rsp+0x50], xmm5
00007d20d97d4622  vmovaps [rsp+0x60], xmm6
00007d20d97d4628  vmovaps [rsp+0x70], xmm7
00007d20d97d462e  vmovaps [rsp+0x80], xmm8
00007d20d97d4637  vmovaps [rsp+0x90], xmm9
00007d20d97d4640  vmovaps [rsp+0xA0], xmm10
00007d20d97d4649  vmovaps [rsp+0xB0], xmm11
00007d20d97d4652  vmovaps [rsp+0xC0], xmm12
00007d20d97d465b  vmovaps [rsp+0xD0], xmm13
00007d20d97d4664  vmovaps [rsp+0xE0], xmm14
00007d20d97d466d  sub rsp, 0x30
00007d20d97d4671  movaps [rsp], xmm15
00007d20d97d4676  movaps [rsp+0x10], xmm10
00007d20d97d467c  movaps [rsp+0x20], xmm13
00007d20d97d4682  lea rdi, [rsp]
00007d20d97d4686  mov esi, 0x00
00007d20d97d468b  mov rax, 0x5EFBF4CF6530
00007d20d97d4695  call rax
00007d20d97d4697  movaps xmm15, [rsp]
00007d20d97d469c  add rsp, 0x30
00007d20d97d46a0  vmovaps xmm0, [rsp]
00007d20d97d46a5  vmovaps xmm1, [rsp+0x10]
00007d20d97d46ab  vmovaps xmm2, [rsp+0x20]
00007d20d97d46b1  vmovaps xmm3, [rsp+0x30]
00007d20d97d46b7  vmovaps xmm4, [rsp+0x40]
00007d20d97d46bd  vmovaps xmm5, [rsp+0x50]
00007d20d97d46c3  vmovaps xmm6, [rsp+0x60]
00007d20d97d46c9  vmovaps xmm7, [rsp+0x70]
00007d20d97d46cf  vmovaps xmm8, [rsp+0x80]
00007d20d97d46d8  vmovaps xmm9, [rsp+0x90]
00007d20d97d46e1  vmovaps xmm10, [rsp+0xA0]
00007d20d97d46ea  vmovaps xmm11, [rsp+0xB0]
00007d20d97d46f3  vmovaps xmm12, [rsp+0xC0]
00007d20d97d46fc  vmovaps xmm13, [rsp+0xD0]
00007d20d97d4705  vmovaps xmm14, [rsp+0xE0]
00007d20d97d470e  add rsp, 0xF0
00007d20d97d4715  pop r11
00007d20d97d4717  pop r10
00007d20d97d4719  pop r9
00007d20d97d471b  pop r8
00007d20d97d471d  pop rsi
00007d20d97d471e  pop rdi
00007d20d97d471f  pop rdx
00007d20d97d4720  pop rcx
00007d20d97d4721  pop rax
00007d20d97d4722  add rsp, 0x08
00007d20d97d4726  jmp 0x00007D20D97D013D
00007d20d97d472b  sub rsp, 0x08
00007d20d97d472f  push rax
00007d20d97d4730  push rcx
00007d20d97d4731  push rdx
00007d20d97d4732  push rdi
00007d20d97d4733  push rsi
00007d20d97d4734  push r8
00007d20d97d4736  push r9
00007d20d97d4738  push r10
00007d20d97d473a  push r11
00007d20d97d473c  sub rsp, 0xF0
00007d20d97d4743  vmovaps [rsp], xmm0
00007d20d97d4748  vmovaps [rsp+0x10], xmm1
00007d20d97d474e  vmovaps [rsp+0x20], xmm2
00007d20d97d4754  vmovaps [rsp+0x30], xmm3
00007d20d97d475a  vmovaps [rsp+0x40], xmm4
00007d20d97d4760  vmovaps [rsp+0x50], xmm5
00007d20d97d4766  vmovaps [rsp+0x60], xmm6
00007d20d97d476c  vmovaps [rsp+0x70], xmm7
00007d20d97d4772  vmovaps [rsp+0x80], xmm8
00007d20d97d477b  vmovaps [rsp+0x90], xmm9
00007d20d97d4784  vmovaps [rsp+0xA0], xmm11
00007d20d97d478d  vmovaps [rsp+0xB0], xmm12
00007d20d97d4796  vmovaps [rsp+0xC0], xmm13
00007d20d97d479f  vmovaps [rsp+0xD0], xmm14
00007d20d97d47a8  vmovaps [rsp+0xE0], xmm15
00007d20d97d47b1  sub rsp, 0x30
00007d20d97d47b5  movaps [rsp], xmm10
00007d20d97d47ba  movaps [rsp+0x10], xmm7
00007d20d97d47bf  movaps [rsp+0x20], xmm13
00007d20d97d47c5  lea rdi, [rsp]
00007d20d97d47c9  mov esi, 0x00
00007d20d97d47ce  mov rax, 0x5EFBF4CF6530
00007d20d97d47d8  call rax
00007d20d97d47da  movaps xmm10, [rsp]
00007d20d97d47df  add rsp, 0x30
00007d20d97d47e3  vmovaps xmm0, [rsp]
00007d20d97d47e8  vmovaps xmm1, [rsp+0x10]
00007d20d97d47ee  vmovaps xmm2, [rsp+0x20]
00007d20d97d47f4  vmovaps xmm3, [rsp+0x30]
00007d20d97d47fa  vmovaps xmm4, [rsp+0x40]
00007d20d97d4800  vmovaps xmm5, [rsp+0x50]
00007d20d97d4806  vmovaps xmm6, [rsp+0x60]
00007d20d97d480c  vmovaps xmm7, [rsp+0x70]
00007d20d97d4812  vmovaps xmm8, [rsp+0x80]
00007d20d97d481b  vmovaps xmm9, [rsp+0x90]
00007d20d97d4824  vmovaps xmm11, [rsp+0xA0]
00007d20d97d482d  vmovaps xmm12, [rsp+0xB0]
00007d20d97d4836  vmovaps xmm13, [rsp+0xC0]
00007d20d97d483f  vmovaps xmm14, [rsp+0xD0]
00007d20d97d4848  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4851  add rsp, 0xF0
00007d20d97d4858  pop r11
00007d20d97d485a  pop r10
00007d20d97d485c  pop r9
00007d20d97d485e  pop r8
00007d20d97d4860  pop rsi
00007d20d97d4861  pop rdi
00007d20d97d4862  pop rdx
00007d20d97d4863  pop rcx
00007d20d97d4864  pop rax
00007d20d97d4865  add rsp, 0x08
00007d20d97d4869  jmp 0x00007D20D97D0169
00007d20d97d486e  sub rsp, 0x08
00007d20d97d4872  push rax
00007d20d97d4873  push rcx
00007d20d97d4874  push rdx
00007d20d97d4875  push rdi
00007d20d97d4876  push rsi
00007d20d97d4877  push r8
00007d20d97d4879  push r9
00007d20d97d487b  push r10
00007d20d97d487d  push r11
00007d20d97d487f  sub rsp, 0xF0
00007d20d97d4886  vmovaps [rsp], xmm0
00007d20d97d488b  vmovaps [rsp+0x10], xmm1
00007d20d97d4891  vmovaps [rsp+0x20], xmm2
00007d20d97d4897  vmovaps [rsp+0x30], xmm3
00007d20d97d489d  vmovaps [rsp+0x40], xmm4
00007d20d97d48a3  vmovaps [rsp+0x50], xmm5
00007d20d97d48a9  vmovaps [rsp+0x60], xmm6
00007d20d97d48af  vmovaps [rsp+0x70], xmm7
00007d20d97d48b5  vmovaps [rsp+0x80], xmm8
00007d20d97d48be  vmovaps [rsp+0x90], xmm9
00007d20d97d48c7  vmovaps [rsp+0xA0], xmm10
00007d20d97d48d0  vmovaps [rsp+0xB0], xmm11
00007d20d97d48d9  vmovaps [rsp+0xC0], xmm12
00007d20d97d48e2  vmovaps [rsp+0xD0], xmm14
00007d20d97d48eb  vmovaps [rsp+0xE0], xmm15
00007d20d97d48f4  sub rsp, 0x30
00007d20d97d48f8  movaps [rsp], xmm13
00007d20d97d48fd  movaps [rsp+0x10], xmm1
00007d20d97d4902  movaps [rsp+0x20], xmm8
00007d20d97d4908  lea rdi, [rsp]
00007d20d97d490c  mov esi, 0x00
00007d20d97d4911  mov rax, 0x5EFBF4CF6530
00007d20d97d491b  call rax
00007d20d97d491d  movaps xmm13, [rsp]
00007d20d97d4922  add rsp, 0x30
00007d20d97d4926  vmovaps xmm0, [rsp]
00007d20d97d492b  vmovaps xmm1, [rsp+0x10]
00007d20d97d4931  vmovaps xmm2, [rsp+0x20]
00007d20d97d4937  vmovaps xmm3, [rsp+0x30]
00007d20d97d493d  vmovaps xmm4, [rsp+0x40]
00007d20d97d4943  vmovaps xmm5, [rsp+0x50]
00007d20d97d4949  vmovaps xmm6, [rsp+0x60]
00007d20d97d494f  vmovaps xmm7, [rsp+0x70]
00007d20d97d4955  vmovaps xmm8, [rsp+0x80]
00007d20d97d495e  vmovaps xmm9, [rsp+0x90]
00007d20d97d4967  vmovaps xmm10, [rsp+0xA0]
00007d20d97d4970  vmovaps xmm11, [rsp+0xB0]
00007d20d97d4979  vmovaps xmm12, [rsp+0xC0]
00007d20d97d4982  vmovaps xmm14, [rsp+0xD0]
00007d20d97d498b  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4994  add rsp, 0xF0
00007d20d97d499b  pop r11
00007d20d97d499d  pop r10
00007d20d97d499f  pop r9
00007d20d97d49a1  pop r8
00007d20d97d49a3  pop rsi
00007d20d97d49a4  pop rdi
00007d20d97d49a5  pop rdx
00007d20d97d49a6  pop rcx
00007d20d97d49a7  pop rax
00007d20d97d49a8  add rsp, 0x08
00007d20d97d49ac  jmp 0x00007D20D97D0183
00007d20d97d49b1  call 0x00007D20D95FF430
00007d20d97d49b6  jmp 0x00007D20D97D018D
00007d20d97d49bb  sub rsp, 0x08
00007d20d97d49bf  push rax
00007d20d97d49c0  push rcx
00007d20d97d49c1  push rdx
00007d20d97d49c2  push rdi
00007d20d97d49c3  push rsi
00007d20d97d49c4  push r8
00007d20d97d49c6  push r9
00007d20d97d49c8  push r10
00007d20d97d49ca  push r11
00007d20d97d49cc  sub rsp, 0xF0
00007d20d97d49d3  vmovaps [rsp], xmm0
00007d20d97d49d8  vmovaps [rsp+0x10], xmm1
00007d20d97d49de  vmovaps [rsp+0x20], xmm2
00007d20d97d49e4  vmovaps [rsp+0x30], xmm3
00007d20d97d49ea  vmovaps [rsp+0x40], xmm4
00007d20d97d49f0  vmovaps [rsp+0x50], xmm5
00007d20d97d49f6  vmovaps [rsp+0x60], xmm6
00007d20d97d49fc  vmovaps [rsp+0x70], xmm7
00007d20d97d4a02  vmovaps [rsp+0x80], xmm9
00007d20d97d4a0b  vmovaps [rsp+0x90], xmm10
00007d20d97d4a14  vmovaps [rsp+0xA0], xmm11
00007d20d97d4a1d  vmovaps [rsp+0xB0], xmm12
00007d20d97d4a26  vmovaps [rsp+0xC0], xmm13
00007d20d97d4a2f  vmovaps [rsp+0xD0], xmm14
00007d20d97d4a38  vmovaps [rsp+0xE0], xmm15
00007d20d97d4a41  sub rsp, 0x30
00007d20d97d4a45  movaps [rsp], xmm8
00007d20d97d4a4a  movaps [rsp+0x10], xmm14
00007d20d97d4a50  movaps [rsp+0x20], xmm9
00007d20d97d4a56  lea rdi, [rsp]
00007d20d97d4a5a  mov esi, 0x00
00007d20d97d4a5f  mov rax, 0x5EFBF4CF6530
00007d20d97d4a69  call rax
00007d20d97d4a6b  movaps xmm8, [rsp]
00007d20d97d4a70  add rsp, 0x30
00007d20d97d4a74  vmovaps xmm0, [rsp]
00007d20d97d4a79  vmovaps xmm1, [rsp+0x10]
00007d20d97d4a7f  vmovaps xmm2, [rsp+0x20]
00007d20d97d4a85  vmovaps xmm3, [rsp+0x30]
00007d20d97d4a8b  vmovaps xmm4, [rsp+0x40]
00007d20d97d4a91  vmovaps xmm5, [rsp+0x50]
00007d20d97d4a97  vmovaps xmm6, [rsp+0x60]
00007d20d97d4a9d  vmovaps xmm7, [rsp+0x70]
00007d20d97d4aa3  vmovaps xmm9, [rsp+0x80]
00007d20d97d4aac  vmovaps xmm10, [rsp+0x90]
00007d20d97d4ab5  vmovaps xmm11, [rsp+0xA0]
00007d20d97d4abe  vmovaps xmm12, [rsp+0xB0]
00007d20d97d4ac7  vmovaps xmm13, [rsp+0xC0]
00007d20d97d4ad0  vmovaps xmm14, [rsp+0xD0]
00007d20d97d4ad9  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4ae2  add rsp, 0xF0
00007d20d97d4ae9  pop r11
00007d20d97d4aeb  pop r10
00007d20d97d4aed  pop r9
00007d20d97d4aef  pop r8
00007d20d97d4af1  pop rsi
00007d20d97d4af2  pop rdi
00007d20d97d4af3  pop rdx
00007d20d97d4af4  pop rcx
00007d20d97d4af5  pop rax
00007d20d97d4af6  add rsp, 0x08
00007d20d97d4afa  jmp 0x00007D20D97D01AF
00007d20d97d4aff  sub rsp, 0x08
00007d20d97d4b03  push rax
00007d20d97d4b04  push rcx
00007d20d97d4b05  push rdx
00007d20d97d4b06  push rdi
00007d20d97d4b07  push rsi
00007d20d97d4b08  push r8
00007d20d97d4b0a  push r9
00007d20d97d4b0c  push r10
00007d20d97d4b0e  push r11
00007d20d97d4b10  sub rsp, 0xF0
00007d20d97d4b17  vmovaps [rsp], xmm0
00007d20d97d4b1c  vmovaps [rsp+0x10], xmm1
00007d20d97d4b22  vmovaps [rsp+0x20], xmm2
00007d20d97d4b28  vmovaps [rsp+0x30], xmm3
00007d20d97d4b2e  vmovaps [rsp+0x40], xmm4
00007d20d97d4b34  vmovaps [rsp+0x50], xmm5
00007d20d97d4b3a  vmovaps [rsp+0x60], xmm6
00007d20d97d4b40  vmovaps [rsp+0x70], xmm7
00007d20d97d4b46  vmovaps [rsp+0x80], xmm8
00007d20d97d4b4f  vmovaps [rsp+0x90], xmm10
00007d20d97d4b58  vmovaps [rsp+0xA0], xmm11
00007d20d97d4b61  vmovaps [rsp+0xB0], xmm12
00007d20d97d4b6a  vmovaps [rsp+0xC0], xmm13
00007d20d97d4b73  vmovaps [rsp+0xD0], xmm14
00007d20d97d4b7c  vmovaps [rsp+0xE0], xmm15
00007d20d97d4b85  sub rsp, 0x30
00007d20d97d4b89  movaps [rsp], xmm9
00007d20d97d4b8e  movaps [rsp+0x10], xmm1
00007d20d97d4b93  movaps [rsp+0x20], xmm14
00007d20d97d4b99  lea rdi, [rsp]
00007d20d97d4b9d  mov esi, 0x00
00007d20d97d4ba2  mov rax, 0x5EFBF4CF6530
00007d20d97d4bac  call rax
00007d20d97d4bae  movaps xmm9, [rsp]
00007d20d97d4bb3  add rsp, 0x30
00007d20d97d4bb7  vmovaps xmm0, [rsp]
00007d20d97d4bbc  vmovaps xmm1, [rsp+0x10]
00007d20d97d4bc2  vmovaps xmm2, [rsp+0x20]
00007d20d97d4bc8  vmovaps xmm3, [rsp+0x30]
00007d20d97d4bce  vmovaps xmm4, [rsp+0x40]
00007d20d97d4bd4  vmovaps xmm5, [rsp+0x50]
00007d20d97d4bda  vmovaps xmm6, [rsp+0x60]
00007d20d97d4be0  vmovaps xmm7, [rsp+0x70]
00007d20d97d4be6  vmovaps xmm8, [rsp+0x80]
00007d20d97d4bef  vmovaps xmm10, [rsp+0x90]
00007d20d97d4bf8  vmovaps xmm11, [rsp+0xA0]
00007d20d97d4c01  vmovaps xmm12, [rsp+0xB0]
00007d20d97d4c0a  vmovaps xmm13, [rsp+0xC0]
00007d20d97d4c13  vmovaps xmm14, [rsp+0xD0]
00007d20d97d4c1c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4c25  add rsp, 0xF0
00007d20d97d4c2c  pop r11
00007d20d97d4c2e  pop r10
00007d20d97d4c30  pop r9
00007d20d97d4c32  pop r8
00007d20d97d4c34  pop rsi
00007d20d97d4c35  pop rdi
00007d20d97d4c36  pop rdx
00007d20d97d4c37  pop rcx
00007d20d97d4c38  pop rax
00007d20d97d4c39  add rsp, 0x08
00007d20d97d4c3d  jmp 0x00007D20D97D01DD
00007d20d97d4c42  sub rsp, 0x08
00007d20d97d4c46  push rax
00007d20d97d4c47  push rcx
00007d20d97d4c48  push rdx
00007d20d97d4c49  push rdi
00007d20d97d4c4a  push rsi
00007d20d97d4c4b  push r8
00007d20d97d4c4d  push r9
00007d20d97d4c4f  push r10
00007d20d97d4c51  push r11
00007d20d97d4c53  sub rsp, 0xF0
00007d20d97d4c5a  vmovaps [rsp], xmm0
00007d20d97d4c5f  vmovaps [rsp+0x10], xmm1
00007d20d97d4c65  vmovaps [rsp+0x20], xmm2
00007d20d97d4c6b  vmovaps [rsp+0x30], xmm3
00007d20d97d4c71  vmovaps [rsp+0x40], xmm4
00007d20d97d4c77  vmovaps [rsp+0x50], xmm5
00007d20d97d4c7d  vmovaps [rsp+0x60], xmm6
00007d20d97d4c83  vmovaps [rsp+0x70], xmm7
00007d20d97d4c89  vmovaps [rsp+0x80], xmm8
00007d20d97d4c92  vmovaps [rsp+0x90], xmm9
00007d20d97d4c9b  vmovaps [rsp+0xA0], xmm10
00007d20d97d4ca4  vmovaps [rsp+0xB0], xmm11
00007d20d97d4cad  vmovaps [rsp+0xC0], xmm12
00007d20d97d4cb6  vmovaps [rsp+0xD0], xmm13
00007d20d97d4cbf  vmovaps [rsp+0xE0], xmm15
00007d20d97d4cc8  sub rsp, 0x30
00007d20d97d4ccc  movaps [rsp], xmm14
00007d20d97d4cd1  movaps [rsp+0x10], xmm4
00007d20d97d4cd6  movaps [rsp+0x20], xmm1
00007d20d97d4cdb  lea rdi, [rsp]
00007d20d97d4cdf  mov esi, 0x00
00007d20d97d4ce4  mov rax, 0x5EFBF4CF6530
00007d20d97d4cee  call rax
00007d20d97d4cf0  movaps xmm14, [rsp]
00007d20d97d4cf5  add rsp, 0x30
00007d20d97d4cf9  vmovaps xmm0, [rsp]
00007d20d97d4cfe  vmovaps xmm1, [rsp+0x10]
00007d20d97d4d04  vmovaps xmm2, [rsp+0x20]
00007d20d97d4d0a  vmovaps xmm3, [rsp+0x30]
00007d20d97d4d10  vmovaps xmm4, [rsp+0x40]
00007d20d97d4d16  vmovaps xmm5, [rsp+0x50]
00007d20d97d4d1c  vmovaps xmm6, [rsp+0x60]
00007d20d97d4d22  vmovaps xmm7, [rsp+0x70]
00007d20d97d4d28  vmovaps xmm8, [rsp+0x80]
00007d20d97d4d31  vmovaps xmm9, [rsp+0x90]
00007d20d97d4d3a  vmovaps xmm10, [rsp+0xA0]
00007d20d97d4d43  vmovaps xmm11, [rsp+0xB0]
00007d20d97d4d4c  vmovaps xmm12, [rsp+0xC0]
00007d20d97d4d55  vmovaps xmm13, [rsp+0xD0]
00007d20d97d4d5e  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4d67  add rsp, 0xF0
00007d20d97d4d6e  pop r11
00007d20d97d4d70  pop r10
00007d20d97d4d72  pop r9
00007d20d97d4d74  pop r8
00007d20d97d4d76  pop rsi
00007d20d97d4d77  pop rdi
00007d20d97d4d78  pop rdx
00007d20d97d4d79  pop rcx
00007d20d97d4d7a  pop rax
00007d20d97d4d7b  add rsp, 0x08
00007d20d97d4d7f  jmp 0x00007D20D97D0203
00007d20d97d4d84  sub rsp, 0x08
00007d20d97d4d88  push rax
00007d20d97d4d89  push rcx
00007d20d97d4d8a  push rdx
00007d20d97d4d8b  push rdi
00007d20d97d4d8c  push rsi
00007d20d97d4d8d  push r8
00007d20d97d4d8f  push r9
00007d20d97d4d91  push r10
00007d20d97d4d93  push r11
00007d20d97d4d95  sub rsp, 0xF0
00007d20d97d4d9c  vmovaps [rsp], xmm0
00007d20d97d4da1  vmovaps [rsp+0x10], xmm2
00007d20d97d4da7  vmovaps [rsp+0x20], xmm3
00007d20d97d4dad  vmovaps [rsp+0x30], xmm4
00007d20d97d4db3  vmovaps [rsp+0x40], xmm5
00007d20d97d4db9  vmovaps [rsp+0x50], xmm6
00007d20d97d4dbf  vmovaps [rsp+0x60], xmm7
00007d20d97d4dc5  vmovaps [rsp+0x70], xmm8
00007d20d97d4dcb  vmovaps [rsp+0x80], xmm9
00007d20d97d4dd4  vmovaps [rsp+0x90], xmm10
00007d20d97d4ddd  vmovaps [rsp+0xA0], xmm11
00007d20d97d4de6  vmovaps [rsp+0xB0], xmm12
00007d20d97d4def  vmovaps [rsp+0xC0], xmm13
00007d20d97d4df8  vmovaps [rsp+0xD0], xmm14
00007d20d97d4e01  vmovaps [rsp+0xE0], xmm15
00007d20d97d4e0a  sub rsp, 0x30
00007d20d97d4e0e  movaps [rsp], xmm1
00007d20d97d4e12  movaps [rsp+0x10], xmm12
00007d20d97d4e18  movaps [rsp+0x20], xmm11
00007d20d97d4e1e  lea rdi, [rsp]
00007d20d97d4e22  mov esi, 0x00
00007d20d97d4e27  mov rax, 0x5EFBF4CF6530
00007d20d97d4e31  call rax
00007d20d97d4e33  movaps xmm1, [rsp]
00007d20d97d4e37  add rsp, 0x30
00007d20d97d4e3b  vmovaps xmm0, [rsp]
00007d20d97d4e40  vmovaps xmm2, [rsp+0x10]
00007d20d97d4e46  vmovaps xmm3, [rsp+0x20]
00007d20d97d4e4c  vmovaps xmm4, [rsp+0x30]
00007d20d97d4e52  vmovaps xmm5, [rsp+0x40]
00007d20d97d4e58  vmovaps xmm6, [rsp+0x50]
00007d20d97d4e5e  vmovaps xmm7, [rsp+0x60]
00007d20d97d4e64  vmovaps xmm8, [rsp+0x70]
00007d20d97d4e6a  vmovaps xmm9, [rsp+0x80]
00007d20d97d4e73  vmovaps xmm10, [rsp+0x90]
00007d20d97d4e7c  vmovaps xmm11, [rsp+0xA0]
00007d20d97d4e85  vmovaps xmm12, [rsp+0xB0]
00007d20d97d4e8e  vmovaps xmm13, [rsp+0xC0]
00007d20d97d4e97  vmovaps xmm14, [rsp+0xD0]
00007d20d97d4ea0  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4ea9  add rsp, 0xF0
00007d20d97d4eb0  pop r11
00007d20d97d4eb2  pop r10
00007d20d97d4eb4  pop r9
00007d20d97d4eb6  pop r8
00007d20d97d4eb8  pop rsi
00007d20d97d4eb9  pop rdi
00007d20d97d4eba  pop rdx
00007d20d97d4ebb  pop rcx
00007d20d97d4ebc  pop rax
00007d20d97d4ebd  add rsp, 0x08
00007d20d97d4ec1  jmp 0x00007D20D97D0224
00007d20d97d4ec6  call 0x00007D20D96E20A0
00007d20d97d4ecb  jmp 0x00007D20D97D0232
00007d20d97d4ed0  call 0x00007D20D9609D70
00007d20d97d4ed5  jmp 0x00007D20D97D023C
00007d20d97d4eda  sub rsp, 0x08
00007d20d97d4ede  push rax
00007d20d97d4edf  push rcx
00007d20d97d4ee0  push rdx
00007d20d97d4ee1  push rdi
00007d20d97d4ee2  push rsi
00007d20d97d4ee3  push r8
00007d20d97d4ee5  push r9
00007d20d97d4ee7  push r10
00007d20d97d4ee9  push r11
00007d20d97d4eeb  sub rsp, 0xF0
00007d20d97d4ef2  vmovaps [rsp], xmm0
00007d20d97d4ef7  vmovaps [rsp+0x10], xmm1
00007d20d97d4efd  vmovaps [rsp+0x20], xmm2
00007d20d97d4f03  vmovaps [rsp+0x30], xmm3
00007d20d97d4f09  vmovaps [rsp+0x40], xmm4
00007d20d97d4f0f  vmovaps [rsp+0x50], xmm5
00007d20d97d4f15  vmovaps [rsp+0x60], xmm6
00007d20d97d4f1b  vmovaps [rsp+0x70], xmm8
00007d20d97d4f21  vmovaps [rsp+0x80], xmm9
00007d20d97d4f2a  vmovaps [rsp+0x90], xmm10
00007d20d97d4f33  vmovaps [rsp+0xA0], xmm11
00007d20d97d4f3c  vmovaps [rsp+0xB0], xmm12
00007d20d97d4f45  vmovaps [rsp+0xC0], xmm13
00007d20d97d4f4e  vmovaps [rsp+0xD0], xmm14
00007d20d97d4f57  vmovaps [rsp+0xE0], xmm15
00007d20d97d4f60  sub rsp, 0x30
00007d20d97d4f64  movaps [rsp], xmm7
00007d20d97d4f68  movaps [rsp+0x10], xmm15
00007d20d97d4f6e  movaps [rsp+0x20], xmm10
00007d20d97d4f74  lea rdi, [rsp]
00007d20d97d4f78  mov esi, 0x00
00007d20d97d4f7d  mov rax, 0x5EFBF4CF6530
00007d20d97d4f87  call rax
00007d20d97d4f89  movaps xmm7, [rsp]
00007d20d97d4f8d  add rsp, 0x30
00007d20d97d4f91  vmovaps xmm0, [rsp]
00007d20d97d4f96  vmovaps xmm1, [rsp+0x10]
00007d20d97d4f9c  vmovaps xmm2, [rsp+0x20]
00007d20d97d4fa2  vmovaps xmm3, [rsp+0x30]
00007d20d97d4fa8  vmovaps xmm4, [rsp+0x40]
00007d20d97d4fae  vmovaps xmm5, [rsp+0x50]
00007d20d97d4fb4  vmovaps xmm6, [rsp+0x60]
00007d20d97d4fba  vmovaps xmm8, [rsp+0x70]
00007d20d97d4fc0  vmovaps xmm9, [rsp+0x80]
00007d20d97d4fc9  vmovaps xmm10, [rsp+0x90]
00007d20d97d4fd2  vmovaps xmm11, [rsp+0xA0]
00007d20d97d4fdb  vmovaps xmm12, [rsp+0xB0]
00007d20d97d4fe4  vmovaps xmm13, [rsp+0xC0]
00007d20d97d4fed  vmovaps xmm14, [rsp+0xD0]
00007d20d97d4ff6  vmovaps xmm15, [rsp+0xE0]
00007d20d97d4fff  add rsp, 0xF0
00007d20d97d5006  pop r11
00007d20d97d5008  pop r10
00007d20d97d500a  pop r9
00007d20d97d500c  pop r8
00007d20d97d500e  pop rsi
00007d20d97d500f  pop rdi
00007d20d97d5010  pop rdx
00007d20d97d5011  pop rcx
00007d20d97d5012  pop rax
00007d20d97d5013  add rsp, 0x08
00007d20d97d5017  jmp 0x00007D20D97D025D
00007d20d97d501c  sub rsp, 0x08
00007d20d97d5020  push rax
00007d20d97d5021  push rcx
00007d20d97d5022  push rdx
00007d20d97d5023  push rdi
00007d20d97d5024  push rsi
00007d20d97d5025  push r8
00007d20d97d5027  push r9
00007d20d97d5029  push r10
00007d20d97d502b  push r11
00007d20d97d502d  sub rsp, 0xF0
00007d20d97d5034  vmovaps [rsp], xmm0
00007d20d97d5039  vmovaps [rsp+0x10], xmm1
00007d20d97d503f  vmovaps [rsp+0x20], xmm2
00007d20d97d5045  vmovaps [rsp+0x30], xmm3
00007d20d97d504b  vmovaps [rsp+0x40], xmm4
00007d20d97d5051  vmovaps [rsp+0x50], xmm5
00007d20d97d5057  vmovaps [rsp+0x60], xmm6
00007d20d97d505d  vmovaps [rsp+0x70], xmm7
00007d20d97d5063  vmovaps [rsp+0x80], xmm8
00007d20d97d506c  vmovaps [rsp+0x90], xmm9
00007d20d97d5075  vmovaps [rsp+0xA0], xmm11
00007d20d97d507e  vmovaps [rsp+0xB0], xmm12
00007d20d97d5087  vmovaps [rsp+0xC0], xmm13
00007d20d97d5090  vmovaps [rsp+0xD0], xmm14
00007d20d97d5099  vmovaps [rsp+0xE0], xmm15
00007d20d97d50a2  sub rsp, 0x30
00007d20d97d50a6  movaps [rsp], xmm10
00007d20d97d50ab  movaps [rsp+0x10], xmm11
00007d20d97d50b1  movaps [rsp+0x20], xmm15
00007d20d97d50b7  lea rdi, [rsp]
00007d20d97d50bb  mov esi, 0x00
00007d20d97d50c0  mov rax, 0x5EFBF4CF6530
00007d20d97d50ca  call rax
00007d20d97d50cc  movaps xmm10, [rsp]
00007d20d97d50d1  add rsp, 0x30
00007d20d97d50d5  vmovaps xmm0, [rsp]
00007d20d97d50da  vmovaps xmm1, [rsp+0x10]
00007d20d97d50e0  vmovaps xmm2, [rsp+0x20]
00007d20d97d50e6  vmovaps xmm3, [rsp+0x30]
00007d20d97d50ec  vmovaps xmm4, [rsp+0x40]
00007d20d97d50f2  vmovaps xmm5, [rsp+0x50]
00007d20d97d50f8  vmovaps xmm6, [rsp+0x60]
00007d20d97d50fe  vmovaps xmm7, [rsp+0x70]
00007d20d97d5104  vmovaps xmm8, [rsp+0x80]
00007d20d97d510d  vmovaps xmm9, [rsp+0x90]
00007d20d97d5116  vmovaps xmm11, [rsp+0xA0]
00007d20d97d511f  vmovaps xmm12, [rsp+0xB0]
00007d20d97d5128  vmovaps xmm13, [rsp+0xC0]
00007d20d97d5131  vmovaps xmm14, [rsp+0xD0]
00007d20d97d513a  vmovaps xmm15, [rsp+0xE0]
00007d20d97d5143  add rsp, 0xF0
00007d20d97d514a  pop r11
00007d20d97d514c  pop r10
00007d20d97d514e  pop r9
00007d20d97d5150  pop r8
00007d20d97d5152  pop rsi
00007d20d97d5153  pop rdi
00007d20d97d5154  pop rdx
00007d20d97d5155  pop rcx
00007d20d97d5156  pop rax
00007d20d97d5157  add rsp, 0x08
00007d20d97d515b  jmp 0x00007D20D97D028B
00007d20d97d5160  sub rsp, 0x08
00007d20d97d5164  push rax
00007d20d97d5165  push rcx
00007d20d97d5166  push rdx
00007d20d97d5167  push rdi
00007d20d97d5168  push rsi
00007d20d97d5169  push r8
00007d20d97d516b  push r9
00007d20d97d516d  push r10
00007d20d97d516f  push r11
00007d20d97d5171  sub rsp, 0xF0
00007d20d97d5178  vmovaps [rsp], xmm0
00007d20d97d517d  vmovaps [rsp+0x10], xmm1
00007d20d97d5183  vmovaps [rsp+0x20], xmm2
00007d20d97d5189  vmovaps [rsp+0x30], xmm3
00007d20d97d518f  vmovaps [rsp+0x40], xmm4
00007d20d97d5195  vmovaps [rsp+0x50], xmm5
00007d20d97d519b  vmovaps [rsp+0x60], xmm6
00007d20d97d51a1  vmovaps [rsp+0x70], xmm7
00007d20d97d51a7  vmovaps [rsp+0x80], xmm8
00007d20d97d51b0  vmovaps [rsp+0x90], xmm9
00007d20d97d51b9  vmovaps [rsp+0xA0], xmm10
00007d20d97d51c2  vmovaps [rsp+0xB0], xmm12
00007d20d97d51cb  vmovaps [rsp+0xC0], xmm13
00007d20d97d51d4  vmovaps [rsp+0xD0], xmm14
00007d20d97d51dd  vmovaps [rsp+0xE0], xmm15
00007d20d97d51e6  sub rsp, 0x30
00007d20d97d51ea  movaps [rsp], xmm11
00007d20d97d51ef  movaps [rsp+0x10], xmm12
00007d20d97d51f5  movaps [rsp+0x20], xmm15
00007d20d97d51fb  lea rdi, [rsp]
00007d20d97d51ff  mov esi, 0x00
00007d20d97d5204  mov rax, 0x5EFBF4CF6530
00007d20d97d520e  call rax
00007d20d97d5210  movaps xmm11, [rsp]
00007d20d97d5215  add rsp, 0x30
00007d20d97d5219  vmovaps xmm0, [rsp]
00007d20d97d521e  vmovaps xmm1, [rsp+0x10]
00007d20d97d5224  vmovaps xmm2, [rsp+0x20]
00007d20d97d522a  vmovaps xmm3, [rsp+0x30]
00007d20d97d5230  vmovaps xmm4, [rsp+0x40]
00007d20d97d5236  vmovaps xmm5, [rsp+0x50]
00007d20d97d523c  vmovaps xmm6, [rsp+0x60]
00007d20d97d5242  vmovaps xmm7, [rsp+0x70]
00007d20d97d5248  vmovaps xmm8, [rsp+0x80]
00007d20d97d5251  vmovaps xmm9, [rsp+0x90]
00007d20d97d525a  vmovaps xmm10, [rsp+0xA0]
00007d20d97d5263  vmovaps xmm12, [rsp+0xB0]
00007d20d97d526c  vmovaps xmm13, [rsp+0xC0]
00007d20d97d5275  vmovaps xmm14, [rsp+0xD0]
00007d20d97d527e  vmovaps xmm15, [rsp+0xE0]
00007d20d97d5287  add rsp, 0xF0
00007d20d97d528e  pop r11
00007d20d97d5290  pop r10
00007d20d97d5292  pop r9
00007d20d97d5294  pop r8
00007d20d97d5296  pop rsi
00007d20d97d5297  pop rdi
00007d20d97d5298  pop rdx
00007d20d97d5299  pop rcx
00007d20d97d529a  pop rax
00007d20d97d529b  add rsp, 0x08
00007d20d97d529f  jmp 0x00007D20D97D02B9
00007d20d97d52a4  sub rsp, 0x08
00007d20d97d52a8  push rax
00007d20d97d52a9  push rcx
00007d20d97d52aa  push rdx
00007d20d97d52ab  push rdi
00007d20d97d52ac  push rsi
00007d20d97d52ad  push r8
00007d20d97d52af  push r9
00007d20d97d52b1  push r10
00007d20d97d52b3  push r11
00007d20d97d52b5  sub rsp, 0xF0
00007d20d97d52bc  vmovaps [rsp], xmm0
00007d20d97d52c1  vmovaps [rsp+0x10], xmm1
00007d20d97d52c7  vmovaps [rsp+0x20], xmm2
00007d20d97d52cd  vmovaps [rsp+0x30], xmm3
00007d20d97d52d3  vmovaps [rsp+0x40], xmm4
00007d20d97d52d9  vmovaps [rsp+0x50], xmm5
00007d20d97d52df  vmovaps [rsp+0x60], xmm6
00007d20d97d52e5  vmovaps [rsp+0x70], xmm7
00007d20d97d52eb  vmovaps [rsp+0x80], xmm8
00007d20d97d52f4  vmovaps [rsp+0x90], xmm9
00007d20d97d52fd  vmovaps [rsp+0xA0], xmm10
00007d20d97d5306  vmovaps [rsp+0xB0], xmm11
00007d20d97d530f  vmovaps [rsp+0xC0], xmm12
00007d20d97d5318  vmovaps [rsp+0xD0], xmm13
00007d20d97d5321  vmovaps [rsp+0xE0], xmm14
00007d20d97d532a  sub rsp, 0x30
00007d20d97d532e  movaps [rsp], xmm15
00007d20d97d5333  movaps [rsp+0x10], xmm13
00007d20d97d5339  movaps [rsp+0x20], xmm9
00007d20d97d533f  lea rdi, [rsp]
00007d20d97d5343  mov esi, 0x00
00007d20d97d5348  mov rax, 0x5EFBF4CF6530
00007d20d97d5352  call rax
00007d20d97d5354  movaps xmm15, [rsp]
00007d20d97d5359  add rsp, 0x30
00007d20d97d535d  vmovaps xmm0, [rsp]
00007d20d97d5362  vmovaps xmm1, [rsp+0x10]
00007d20d97d5368  vmovaps xmm2, [rsp+0x20]
00007d20d97d536e  vmovaps xmm3, [rsp+0x30]
00007d20d97d5374  vmovaps xmm4, [rsp+0x40]
00007d20d97d537a  vmovaps xmm5, [rsp+0x50]
00007d20d97d5380  vmovaps xmm6, [rsp+0x60]
00007d20d97d5386  vmovaps xmm7, [rsp+0x70]
00007d20d97d538c  vmovaps xmm8, [rsp+0x80]
00007d20d97d5395  vmovaps xmm9, [rsp+0x90]
00007d20d97d539e  vmovaps xmm10, [rsp+0xA0]
00007d20d97d53a7  vmovaps xmm11, [rsp+0xB0]
00007d20d97d53b0  vmovaps xmm12, [rsp+0xC0]
00007d20d97d53b9  vmovaps xmm13, [rsp+0xD0]
00007d20d97d53c2  vmovaps xmm14, [rsp+0xE0]
00007d20d97d53cb  add rsp, 0xF0
00007d20d97d53d2  pop r11
00007d20d97d53d4  pop r10
00007d20d97d53d6  pop r9
00007d20d97d53d8  pop r8
00007d20d97d53da  pop rsi
00007d20d97d53db  pop rdi
00007d20d97d53dc  pop rdx
00007d20d97d53dd  pop rcx
00007d20d97d53de  pop rax
00007d20d97d53df  add rsp, 0x08
00007d20d97d53e3  jmp 0x00007D20D97D02D4
00007d20d97d53e8  sub rsp, 0x08
00007d20d97d53ec  push rax
00007d20d97d53ed  push rcx
00007d20d97d53ee  push rdx
00007d20d97d53ef  push rdi
00007d20d97d53f0  push rsi
00007d20d97d53f1  push r8
00007d20d97d53f3  push r9
00007d20d97d53f5  push r10
00007d20d97d53f7  push r11
00007d20d97d53f9  sub rsp, 0xF0
00007d20d97d5400  vmovaps [rsp], xmm0
00007d20d97d5405  vmovaps [rsp+0x10], xmm1
00007d20d97d540b  vmovaps [rsp+0x20], xmm2
00007d20d97d5411  vmovaps [rsp+0x30], xmm3
00007d20d97d5417  vmovaps [rsp+0x40], xmm4
00007d20d97d541d  vmovaps [rsp+0x50], xmm5
00007d20d97d5423  vmovaps [rsp+0x60], xmm6
00007d20d97d5429  vmovaps [rsp+0x70], xmm7
00007d20d97d542f  vmovaps [rsp+0x80], xmm8
00007d20d97d5438  vmovaps [rsp+0x90], xmm9
00007d20d97d5441  vmovaps [rsp+0xA0], xmm10
00007d20d97d544a  vmovaps [rsp+0xB0], xmm11
00007d20d97d5453  vmovaps [rsp+0xC0], xmm12
00007d20d97d545c  vmovaps [rsp+0xD0], xmm14
00007d20d97d5465  vmovaps [rsp+0xE0], xmm15
00007d20d97d546e  sub rsp, 0x30
00007d20d97d5472  movaps [rsp], xmm13
00007d20d97d5477  movaps [rsp+0x10], xmm8
00007d20d97d547d  movaps [rsp+0x20], xmm14
00007d20d97d5483  lea rdi, [rsp]
00007d20d97d5487  mov esi, 0x00
00007d20d97d548c  mov rax, 0x5EFBF4CF6530
00007d20d97d5496  call rax
00007d20d97d5498  movaps xmm13, [rsp]
00007d20d97d549d  add rsp, 0x30
00007d20d97d54a1  vmovaps xmm0, [rsp]
00007d20d97d54a6  vmovaps xmm1, [rsp+0x10]
00007d20d97d54ac  vmovaps xmm2, [rsp+0x20]
00007d20d97d54b2  vmovaps xmm3, [rsp+0x30]
00007d20d97d54b8  vmovaps xmm4, [rsp+0x40]
00007d20d97d54be  vmovaps xmm5, [rsp+0x50]
00007d20d97d54c4  vmovaps xmm6, [rsp+0x60]
00007d20d97d54ca  vmovaps xmm7, [rsp+0x70]
00007d20d97d54d0  vmovaps xmm8, [rsp+0x80]
00007d20d97d54d9  vmovaps xmm9, [rsp+0x90]
00007d20d97d54e2  vmovaps xmm10, [rsp+0xA0]
00007d20d97d54eb  vmovaps xmm11, [rsp+0xB0]
00007d20d97d54f4  vmovaps xmm12, [rsp+0xC0]
00007d20d97d54fd  vmovaps xmm14, [rsp+0xD0]
00007d20d97d5506  vmovaps xmm15, [rsp+0xE0]
00007d20d97d550f  add rsp, 0xF0
00007d20d97d5516  pop r11
00007d20d97d5518  pop r10
00007d20d97d551a  pop r9
00007d20d97d551c  pop r8
00007d20d97d551e  pop rsi
00007d20d97d551f  pop rdi
00007d20d97d5520  pop rdx
00007d20d97d5521  pop rcx
00007d20d97d5522  pop rax
00007d20d97d5523  add rsp, 0x08
00007d20d97d5527  jmp 0x00007D20D97D02F7
00007d20d97d552c  sub rsp, 0x08
00007d20d97d5530  push rax
00007d20d97d5531  push rcx
00007d20d97d5532  push rdx
00007d20d97d5533  push rdi
00007d20d97d5534  push rsi
00007d20d97d5535  push r8
00007d20d97d5537  push r9
00007d20d97d5539  push r10
00007d20d97d553b  push r11
00007d20d97d553d  sub rsp, 0xF0
00007d20d97d5544  vmovaps [rsp], xmm0
00007d20d97d5549  vmovaps [rsp+0x10], xmm1
00007d20d97d554f  vmovaps [rsp+0x20], xmm2
00007d20d97d5555  vmovaps [rsp+0x30], xmm3
00007d20d97d555b  vmovaps [rsp+0x40], xmm4
00007d20d97d5561  vmovaps [rsp+0x50], xmm5
00007d20d97d5567  vmovaps [rsp+0x60], xmm6
00007d20d97d556d  vmovaps [rsp+0x70], xmm7
00007d20d97d5573  vmovaps [rsp+0x80], xmm8
00007d20d97d557c  vmovaps [rsp+0x90], xmm9
00007d20d97d5585  vmovaps [rsp+0xA0], xmm10
00007d20d97d558e  vmovaps [rsp+0xB0], xmm11
00007d20d97d5597  vmovaps [rsp+0xC0], xmm12
00007d20d97d55a0  vmovaps [rsp+0xD0], xmm13
00007d20d97d55a9  vmovaps [rsp+0xE0], xmm15
00007d20d97d55b2  sub rsp, 0x30
00007d20d97d55b6  movaps [rsp], xmm14
00007d20d97d55bb  movaps [rsp+0x10], xmm1
00007d20d97d55c0  movaps [rsp+0x20], xmm10
00007d20d97d55c6  lea rdi, [rsp]
00007d20d97d55ca  mov esi, 0x00
00007d20d97d55cf  mov rax, 0x5EFBF4CF6530
00007d20d97d55d9  call rax
00007d20d97d55db  movaps xmm14, [rsp]
00007d20d97d55e0  add rsp, 0x30
00007d20d97d55e4  vmovaps xmm0, [rsp]
00007d20d97d55e9  vmovaps xmm1, [rsp+0x10]
00007d20d97d55ef  vmovaps xmm2, [rsp+0x20]
00007d20d97d55f5  vmovaps xmm3, [rsp+0x30]
00007d20d97d55fb  vmovaps xmm4, [rsp+0x40]
00007d20d97d5601  vmovaps xmm5, [rsp+0x50]
00007d20d97d5607  vmovaps xmm6, [rsp+0x60]
00007d20d97d560d  vmovaps xmm7, [rsp+0x70]
00007d20d97d5613  vmovaps xmm8, [rsp+0x80]
00007d20d97d561c  vmovaps xmm9, [rsp+0x90]
00007d20d97d5625  vmovaps xmm10, [rsp+0xA0]
00007d20d97d562e  vmovaps xmm11, [rsp+0xB0]
00007d20d97d5637  vmovaps xmm12, [rsp+0xC0]
00007d20d97d5640  vmovaps xmm13, [rsp+0xD0]
00007d20d97d5649  vmovaps xmm15, [rsp+0xE0]
00007d20d97d5652  add rsp, 0xF0
00007d20d97d5659  pop r11
00007d20d97d565b  pop r10
00007d20d97d565d  pop r9
00007d20d97d565f  pop r8
00007d20d97d5661  pop rsi
00007d20d97d5662  pop rdi
00007d20d97d5663  pop rdx
00007d20d97d5664  pop rcx
00007d20d97d5665  pop rax
00007d20d97d5666  add rsp, 0x08
00007d20d97d566a  jmp 0x00007D20D97D031A
00007d20d97d566f  sub rsp, 0x08
00007d20d97d5673  push rax
00007d20d97d5674  push rcx
00007d20d97d5675  push rdx
00007d20d97d5676  push rdi
00007d20d97d5677  push rsi
00007d20d97d5678  push r8
00007d20d97d567a  push r9
00007d20d97d567c  push r10
00007d20d97d567e  push r11
00007d20d97d5680  sub rsp, 0xF0
00007d20d97d5687  vmovaps [rsp], xmm0
00007d20d97d568c  vmovaps [rsp+0x10], xmm2
00007d20d97d5692  vmovaps [rsp+0x20], xmm3
00007d20d97d5698  vmovaps [rsp+0x30], xmm4
00007d20d97d569e  vmovaps [rsp+0x40], xmm5
00007d20d97d56a4  vmovaps [rsp+0x50], xmm6
00007d20d97d56aa  vmovaps [rsp+0x60], xmm7
00007d20d97d56b0  vmovaps [rsp+0x70], xmm8
00007d20d97d56b6  vmovaps [rsp+0x80], xmm9
00007d20d97d56bf  vmovaps [rsp+0x90], xmm10
00007d20d97d56c8  vmovaps [rsp+0xA0], xmm11
00007d20d97d56d1  vmovaps [rsp+0xB0], xmm12
00007d20d97d56da  vmovaps [rsp+0xC0], xmm13
00007d20d97d56e3  vmovaps [rsp+0xD0], xmm14
00007d20d97d56ec  vmovaps [rsp+0xE0], xmm15
00007d20d97d56f5  sub rsp, 0x30
00007d20d97d56f9  movaps [rsp], xmm1
00007d20d97d56fd  movaps [rsp+0x10], xmm7
00007d20d97d5702  movaps [rsp+0x20], xmm11
00007d20d97d5708  lea rdi, [rsp]
00007d20d97d570c  mov esi, 0x00
00007d20d97d5711  mov rax, 0x5EFBF4CF6530
00007d20d97d571b  call rax
00007d20d97d571d  movaps xmm1, [rsp]
00007d20d97d5721  add rsp, 0x30
00007d20d97d5725  vmovaps xmm0, [rsp]
00007d20d97d572a  vmovaps xmm2, [rsp+0x10]
00007d20d97d5730  vmovaps xmm3, [rsp+0x20]
00007d20d97d5736  vmovaps xmm4, [rsp+0x30]
00007d20d97d573c  vmovaps xmm5, [rsp+0x40]
00007d20d97d5742  vmovaps xmm6, [rsp+0x50]
00007d20d97d5748  vmovaps xmm7, [rsp+0x60]
00007d20d97d574e  vmovaps xmm8, [rsp+0x70]
00007d20d97d5754  vmovaps xmm9, [rsp+0x80]
00007d20d97d575d  vmovaps xmm10, [rsp+0x90]
00007d20d97d5766  vmovaps xmm11, [rsp+0xA0]
00007d20d97d576f  vmovaps xmm12, [rsp+0xB0]
00007d20d97d5778  vmovaps xmm13, [rsp+0xC0]
00007d20d97d5781  vmovaps xmm14, [rsp+0xD0]
00007d20d97d578a  vmovaps xmm15, [rsp+0xE0]
00007d20d97d5793  add rsp, 0xF0
00007d20d97d579a  pop r11
00007d20d97d579c  pop r10
00007d20d97d579e  pop r9
00007d20d97d57a0  pop r8
00007d20d97d57a2  pop rsi
00007d20d97d57a3  pop rdi
00007d20d97d57a4  pop rdx
00007d20d97d57a5  pop rcx
00007d20d97d57a6  pop rax
00007d20d97d57a7  add rsp, 0x08
00007d20d97d57ab  jmp 0x00007D20D97D033B
00007d20d97d57b0  call 0x00007D20D960E880
00007d20d97d57b5  jmp 0x00007D20D97D034E
00007d20d97d57ba  call 0x00007D20D960C380
00007d20d97d57bf  jmp 0x00007D20D97D0359
00007d20d97d57c4  call 0x00007D20D960D600
00007d20d97d57c9  jmp 0x00007D20D97D0364
00007d20d97d57ce  call 0x00007D20D95FF540
00007d20d97d57d3  jmp 0x00007D20D97D036F
00007d20d97d57d8  int3
00007d20d97d57d9  nop [rax], eax
00007d20d97d57e0  mov rax, [r15+0x40]
00007d20d97d57e4  mov r14, [r15+0x58]
00007d20d97d57e8  lea r12, [rax+r14*1]
00007d20d97d57ec  movaps xmm1, [r15+0x1D0]
00007d20d97d57f4  vmovaps [rsp+0x10], xmm1
00007d20d97d57fa  vmovaps xmm15, [rsp+0x10]
00007d20d97d5800  por xmm1, xmm15
00007d20d97d5805  movaps xmm14, [r15+0x1A0]
00007d20d97d580d  vmovaps [rsp+0x10], xmm14
00007d20d97d5813  vmovaps xmm13, [rsp+0x10]
00007d20d97d5819  por xmm14, xmm13
00007d20d97d581e  lea rax, [r12+0x30]
00007d20d97d5823  mov r11, [r13+rax*1]
00007d20d97d5828  lea rax, [r12+0x38]
00007d20d97d582d  mov r10, [r13+rax*1]
00007d20d97d5832  movq xmm13, r11
00007d20d97d5837  movq xmm12, r10
00007d20d97d583c  movq xmm13, xmm13
00007d20d97d5841  vmovaps [rsp+0x10], xmm13
00007d20d97d5847  movq xmm13, xmm13
00007d20d97d584c  movaps [r15+0x130], xmm13
00007d20d97d5854  movq xmm12, xmm12
00007d20d97d5859  vmovaps [rsp+0x20], xmm12
00007d20d97d585f  movq xmm12, xmm12
00007d20d97d5864  movaps [r15+0x280], xmm12
00007d20d97d586c  movaps xmm13, [r15+0x270]
00007d20d97d5874  vmovaps [rsp+0x30], xmm13
00007d20d97d587a  vmovaps xmm12, [rsp+0x30]
00007d20d97d5880  por xmm13, xmm12
00007d20d97d5885  lea rax, [r12+0x20]
00007d20d97d588a  mov r11, [r13+rax*1]
00007d20d97d588f  lea rax, [r12+0x28]
00007d20d97d5894  mov r10, [r13+rax*1]
00007d20d97d5899  movq xmm12, r11
00007d20d97d589e  movq xmm11, r10
00007d20d97d58a3  movq xmm12, xmm12
00007d20d97d58a8  vmovaps [rsp+0x30], xmm12
00007d20d97d58ae  movq xmm12, xmm12
00007d20d97d58b3  movaps [r15+0x150], xmm12
00007d20d97d58bb  movq xmm11, xmm11
00007d20d97d58c0  vmovaps [rsp+0x40], xmm11
00007d20d97d58c6  movq xmm11, xmm11
00007d20d97d58cb  movaps [r15+0x140], xmm11
00007d20d97d58d3  lea rax, [r12+0x10]
00007d20d97d58d8  mov r11, [r13+rax*1]
00007d20d97d58dd  lea rax, [r12+0x18]
00007d20d97d58e2  mov r10, [r13+rax*1]
00007d20d97d58e7  movq xmm12, r11
00007d20d97d58ec  movq xmm11, r10
00007d20d97d58f1  movq xmm12, xmm12
00007d20d97d58f6  vmovaps [rsp+0x50], xmm12
00007d20d97d58fc  movq xmm12, xmm12
00007d20d97d5901  movaps [r15+0x170], xmm12
00007d20d97d5909  movq xmm11, xmm11
00007d20d97d590e  vmovaps [rsp+0x60], xmm11
00007d20d97d5914  movq xmm11, xmm11
00007d20d97d5919  movaps [r15+0x160], xmm11
00007d20d97d5921  mov rax, [r13+r12*1]
00007d20d97d5926  vmovq xmm12, rax
00007d20d97d592b  vpbroadcastq xmm12, xmm12
00007d20d97d5930  lea rax, [r12+0x08]
00007d20d97d5935  mov r12, [r13+rax*1]
00007d20d97d593a  movq xmm11, r12
00007d20d97d593f  movaps [r15+0x230], xmm11
00007d20d97d5947  mov rax, [r15+0xF8]
00007d20d97d594e  lea r12, [rax+0x50]
00007d20d97d5952  movups xmm11, [r13+r12*1]
00007d20d97d5958  lea r12, [rax+0x60]
00007d20d97d595c  movups xmm10, [r13+r12*1]
00007d20d97d5962  lea r12, [rax+0x30]
00007d20d97d5966  movups xmm9, [r13+r12*1]
00007d20d97d596c  mov r12, [r15+0x50]
00007d20d97d5970  lea r11, [r12+r14*1]
00007d20d97d5974  mov [r15+0x60], r11
00007d20d97d5978  lea r12, [r14+0x40]
00007d20d97d597c  mov [r15+0x58], r12
00007d20d97d5980  movaps xmm8, xmm12
00007d20d97d5984  mulpd xmm8, xmm15
00007d20d97d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007d20d97d598f  ptest xmm7, xmm7
00007d20d97d5994  jnz 0x00007D20D97D67B7
00007d20d97d599a  movq xmm15, qword ptr [r15+0x230]
00007d20d97d59a3  vmovaps [rsp+0x70], xmm15
00007d20d97d59a9  vpermilpd xmm15, xmm15, 0x00
00007d20d97d59af  movaps xmm7, xmm9
00007d20d97d59b3  mulpd xmm7, xmm15
00007d20d97d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007d20d97d59bd  ptest xmm6, xmm6
00007d20d97d59c2  jnz 0x00007D20D97D68FB
00007d20d97d59c8  vxorps xmm15, xmm15, xmm15
00007d20d97d59cd  vpbroadcastq xmm15, xmm15
00007d20d97d59d2  movaps xmm9, xmm12
00007d20d97d59d6  mulpd xmm9, xmm10
00007d20d97d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007d20d97d59e1  ptest xmm6, xmm6
00007d20d97d59e6  jnz 0x00007D20D97D6A3D
00007d20d97d59ec  movaps xmm10, xmm12
00007d20d97d59f0  mulpd xmm10, xmm11
00007d20d97d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d20d97d59fb  ptest xmm6, xmm6
00007d20d97d5a00  jnz 0x00007D20D97D6B81
00007d20d97d5a06  movaps xmm11, [r15+0x1F0]
00007d20d97d5a0e  movaps xmm6, xmm12
00007d20d97d5a12  mulpd xmm6, xmm11
00007d20d97d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007d20d97d5a1c  ptest xmm5, xmm5
00007d20d97d5a21  jnz 0x00007D20D97D6CC5
00007d20d97d5a27  movaps xmm12, [r15+0x2A0]
00007d20d97d5a2f  vmovaps [rsp+0x80], xmm12
00007d20d97d5a38  vmovaps xmm11, [rsp+0x80]
00007d20d97d5a41  por xmm12, xmm11
00007d20d97d5a46  movaps xmm11, [r15+0x250]
00007d20d97d5a4e  vmovaps [rsp+0x80], xmm11
00007d20d97d5a57  vmovaps xmm5, [rsp+0x80]
00007d20d97d5a60  por xmm11, xmm5
00007d20d97d5a65  vmovaps xmm4, [rsp+0x70]
00007d20d97d5a6b  vpermilpd xmm4, xmm4, 0x00
00007d20d97d5a71  movaps xmm3, xmm5
00007d20d97d5a74  mulpd xmm3, xmm4
00007d20d97d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007d20d97d5a7d  ptest xmm2, xmm2
00007d20d97d5a82  jnz 0x00007D20D97D6E07
00007d20d97d5a88  mov [rsp+0x80], rax
00007d20d97d5a90  xor eax, eax
00007d20d97d5a92  mov r14d, 0x200
00007d20d97d5a98  cmp r12, r14
00007d20d97d5a9b  cmc
00007d20d97d5a9c  lahf
00007d20d97d5a9d  seto al
00007d20d97d5aa0  mov [r15+0x108], eax
00007d20d97d5aa7  movaps xmm5, xmm8
00007d20d97d5aab  addpd xmm5, xmm15
00007d20d97d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007d20d97d5ab5  ptest xmm4, xmm4
00007d20d97d5aba  jnz 0x00007D20D97D6F47
00007d20d97d5ac0  movaps xmm8, [r15+0x1B0]
00007d20d97d5ac8  movaps xmm4, xmm9
00007d20d97d5acc  addpd xmm4, xmm8
00007d20d97d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d20d97d5ad6  ptest xmm2, xmm2
00007d20d97d5adb  jnz 0x00007D20D97D7089
00007d20d97d5ae1  movaps xmm9, xmm10
00007d20d97d5ae5  addpd xmm9, xmm8
00007d20d97d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007d20d97d5af0  ptest xmm2, xmm2
00007d20d97d5af5  jnz 0x00007D20D97D71CB
00007d20d97d5afb  movaps xmm10, [r15+0x2F0]
00007d20d97d5b03  vmovaps [rsp+0x90], xmm10
00007d20d97d5b0c  vmovaps xmm8, [rsp+0x90]
00007d20d97d5b15  por xmm10, xmm8
00007d20d97d5b1a  movaps xmm8, [r15+0x2E0]
00007d20d97d5b22  vmovaps [rsp+0x90], xmm8
00007d20d97d5b2b  vmovaps xmm2, [rsp+0x90]
00007d20d97d5b34  por xmm8, xmm2
00007d20d97d5b39  movaps xmm2, [r15+0x2D0]
00007d20d97d5b41  vmovaps [rsp+0x90], xmm2
00007d20d97d5b4a  vmovaps [rsp+0xA0], xmm1
00007d20d97d5b53  vmovaps xmm1, [rsp+0x90]
00007d20d97d5b5c  por xmm2, xmm1
00007d20d97d5b60  movaps xmm1, [r15+0x200]
00007d20d97d5b68  vmovaps [rsp+0x90], xmm1
00007d20d97d5b71  vmovaps [rsp+0xB0], xmm15
00007d20d97d5b7a  vmovaps xmm15, [rsp+0x90]
00007d20d97d5b83  por xmm1, xmm15
00007d20d97d5b88  movaps xmm15, [r15+0x1C0]
00007d20d97d5b90  vmovaps [rsp+0x90], xmm15
00007d20d97d5b99  vmovaps [rsp+0xC0], xmm1
00007d20d97d5ba2  vmovaps xmm1, [rsp+0x90]
00007d20d97d5bab  por xmm15, xmm1
00007d20d97d5bb0  movaps xmm1, [r15+0x190]
00007d20d97d5bb8  vmovaps [rsp+0x90], xmm1
00007d20d97d5bc1  vmovaps [rsp+0xD0], xmm15
00007d20d97d5bca  vmovaps xmm15, [rsp+0x90]
00007d20d97d5bd3  por xmm1, xmm15
00007d20d97d5bd8  movaps xmm15, [r15+0x300]
00007d20d97d5be0  vmovaps [rsp+0x90], xmm15
00007d20d97d5be9  vmovaps [rsp+0xE0], xmm1
00007d20d97d5bf2  vmovaps xmm1, [rsp+0x90]
00007d20d97d5bfb  por xmm15, xmm1
00007d20d97d5c00  mov rax, [rsp+0x80]
00007d20d97d5c08  lea r14, [rax+0xA0]
00007d20d97d5c0f  movups xmm1, [r13+r14*1]
00007d20d97d5c15  lea r14, [rax+0xB0]
00007d20d97d5c1c  vmovaps [rsp+0x80], xmm1
00007d20d97d5c25  movups xmm1, [r13+r14*1]
00007d20d97d5c2b  vmovaps [rsp+0x90], xmm1
00007d20d97d5c34  vmovaps [rsp+0xF0], xmm15
00007d20d97d5c3d  vmovaps xmm15, [rsp+0xB0]
00007d20d97d5c46  vmovaps [rsp+0xB0], xmm14
00007d20d97d5c4f  movaps xmm1, xmm6
00007d20d97d5c52  addpd xmm1, xmm15
00007d20d97d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007d20d97d5c5c  ptest xmm14, xmm14
00007d20d97d5c62  jnz 0x00007D20D97D7323
00007d20d97d5c68  lea r14, [rax+0xF0]
00007d20d97d5c6f  movups xmm15, [r13+r14*1]
00007d20d97d5c75  movaps xmm14, xmm4
00007d20d97d5c79  addpd xmm14, xmm3
00007d20d97d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d20d97d5c84  ptest xmm6, xmm6
00007d20d97d5c89  jnz 0x00007D20D97D746E
00007d20d97d5c8f  movaps xmm6, xmm9
00007d20d97d5c93  addpd xmm6, xmm7
00007d20d97d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007d20d97d5c9c  ptest xmm4, xmm4
00007d20d97d5ca1  jnz 0x00007D20D97D75B0
00007d20d97d5ca7  vmovaps xmm9, [rsp+0x70]
00007d20d97d5cad  vpermilpd xmm9, xmm9, 0x00
00007d20d97d5cb3  vmovaps xmm4, [rsp+0x90]
00007d20d97d5cbc  movaps xmm7, xmm4
00007d20d97d5cbf  mulpd xmm7, xmm9
00007d20d97d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d20d97d5cc9  ptest xmm3, xmm3
00007d20d97d5cce  jnz 0x00007D20D97D76F1
00007d20d97d5cd4  vmovaps xmm9, [rsp+0x50]
00007d20d97d5cda  vpermilpd xmm9, xmm9, 0x00
00007d20d97d5ce0  movaps xmm4, xmm15
00007d20d97d5ce4  mulpd xmm4, xmm9
00007d20d97d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d20d97d5cee  ptest xmm3, xmm3
00007d20d97d5cf3  jnz 0x00007D20D97D7832
00007d20d97d5cf9  lea r14, [rax+0xE0]
00007d20d97d5d00  movups xmm15, [r13+r14*1]
00007d20d97d5d06  vmovaps xmm9, [rsp+0x70]
00007d20d97d5d0c  vpermilpd xmm9, xmm9, 0x00
00007d20d97d5d12  vmovaps [rsp+0x70], xmm1
00007d20d97d5d18  vmovaps xmm1, [rsp+0x80]
00007d20d97d5d21  vmovaps [rsp+0x80], xmm15
00007d20d97d5d2a  movaps xmm3, xmm1
00007d20d97d5d2d  mulpd xmm3, xmm9
00007d20d97d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007d20d97d5d37  ptest xmm15, xmm15
00007d20d97d5d3d  jnz 0x00007D20D97D797E
00007d20d97d5d43  vmovaps xmm1, [rsp+0xF0]
00007d20d97d5d4c  vmovaps xmm15, [rsp+0xF0]
00007d20d97d5d55  por xmm1, xmm15
00007d20d97d5d5a  movaps [r15+0x300], xmm1
00007d20d97d5d62  vmovaps xmm15, [rsp+0xE0]
00007d20d97d5d6b  vmovaps xmm9, [rsp+0xE0]
00007d20d97d5d74  por xmm15, xmm9
00007d20d97d5d79  movaps [r15+0x190], xmm15
00007d20d97d5d81  vmovaps xmm9, [rsp+0x50]
00007d20d97d5d87  vpermilpd xmm9, xmm9, 0x00
00007d20d97d5d8d  vmovaps [rsp+0x90], xmm1
00007d20d97d5d96  vmovaps [rsp+0xE0], xmm15
00007d20d97d5d9f  vmovaps xmm15, [rsp+0x80]
00007d20d97d5da8  vmovaps [rsp+0x80], xmm14
00007d20d97d5db1  movaps xmm1, xmm15
00007d20d97d5db5  mulpd xmm1, xmm9
00007d20d97d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007d20d97d5dbf  ptest xmm14, xmm14
00007d20d97d5dc5  jnz 0x00007D20D97D7ABF
00007d20d97d5dcb  lea r14, [rax+0x90]
00007d20d97d5dd2  movups xmm15, [r13+r14*1]
00007d20d97d5dd8  vmovaps xmm14, [rsp+0xD0]
00007d20d97d5de1  vmovaps xmm9, [rsp+0xD0]
00007d20d97d5dea  por xmm14, xmm9
00007d20d97d5def  movaps [r15+0x1C0], xmm14
00007d20d97d5df7  vmovaps xmm9, [rsp+0xC0]
00007d20d97d5e00  vmovaps [rsp+0xD0], xmm1
00007d20d97d5e09  vmovaps xmm1, [rsp+0xC0]
00007d20d97d5e12  por xmm9, xmm1
00007d20d97d5e17  movaps [r15+0x200], xmm9
00007d20d97d5e1f  vmovaps [rsp+0xC0], xmm2
00007d20d97d5e28  vmovaps xmm1, [rsp+0xC0]
00007d20d97d5e31  por xmm2, xmm1
00007d20d97d5e35  movaps [r15+0x2D0], xmm2
00007d20d97d5e3d  vmovaps [rsp+0xC0], xmm8
00007d20d97d5e46  vmovaps xmm1, [rsp+0xC0]
00007d20d97d5e4f  por xmm8, xmm1
00007d20d97d5e54  movaps [r15+0x2E0], xmm8
00007d20d97d5e5c  vmovaps [rsp+0xC0], xmm15
00007d20d97d5e65  movaps xmm1, xmm5
00007d20d97d5e68  addpd xmm1, xmm7
00007d20d97d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d20d97d5e71  ptest xmm15, xmm15
00007d20d97d5e77  jnz 0x00007D20D97D7C0B
00007d20d97d5e7d  vmovaps xmm15, [rsp+0x50]
00007d20d97d5e83  vpermilpd xmm15, xmm15, 0x00
00007d20d97d5e89  vmovaps xmm5, [rsp+0xC0]
00007d20d97d5e92  vmovaps [rsp+0xC0], xmm1
00007d20d97d5e9b  movaps xmm7, xmm5
00007d20d97d5e9e  mulpd xmm7, xmm15
00007d20d97d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007d20d97d5ea8  ptest xmm1, xmm1
00007d20d97d5ead  jnz 0x00007D20D97D7D4B
00007d20d97d5eb3  lea r14, [rax+0x80]
00007d20d97d5eba  movups xmm1, [r13+r14*1]
00007d20d97d5ec0  vmovaps xmm5, [rsp+0x70]
00007d20d97d5ec6  vmovaps [rsp+0x70], xmm1
00007d20d97d5ecc  movaps xmm15, xmm5
00007d20d97d5ed0  addpd xmm15, xmm3
00007d20d97d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97d5edb  ptest xmm1, xmm1
00007d20d97d5ee0  jnz 0x00007D20D97D7E96
00007d20d97d5ee6  vmovaps xmm5, [rsp+0x80]
00007d20d97d5eef  movaps xmm1, xmm5
00007d20d97d5ef2  addpd xmm1, xmm4
00007d20d97d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d20d97d5efb  ptest xmm3, xmm3
00007d20d97d5f00  jnz 0x00007D20D97D7FD8
00007d20d97d5f06  vmovaps [rsp+0x80], xmm10
00007d20d97d5f0f  vmovaps xmm5, [rsp+0x80]
00007d20d97d5f18  por xmm10, xmm5
00007d20d97d5f1d  movaps [r15+0x2F0], xmm10
00007d20d97d5f25  vmovaps xmm5, [rsp+0x50]
00007d20d97d5f2b  vpermilpd xmm5, xmm5, 0x00
00007d20d97d5f31  vmovaps xmm3, [rsp+0x70]
00007d20d97d5f37  vmovaps [rsp+0x50], xmm1
00007d20d97d5f3d  movaps xmm4, xmm3
00007d20d97d5f40  mulpd xmm4, xmm5
00007d20d97d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007d20d97d5f49  ptest xmm1, xmm1
00007d20d97d5f4e  jnz 0x00007D20D97D8118
00007d20d97d5f54  lea r14, [rax+0xD0]
00007d20d97d5f5b  movups xmm1, [r13+r14*1]
00007d20d97d5f61  vmovaps xmm3, [rsp+0xD0]
00007d20d97d5f6a  vmovaps [rsp+0x70], xmm1
00007d20d97d5f70  movaps xmm5, xmm6
00007d20d97d5f73  addpd xmm5, xmm3
00007d20d97d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007d20d97d5f7c  ptest xmm1, xmm1
00007d20d97d5f81  jnz 0x00007D20D97D8262
00007d20d97d5f87  vmovaps xmm1, [rsp+0x60]
00007d20d97d5f8d  vpermilpd xmm1, xmm1, 0x00
00007d20d97d5f93  movaps xmm6, xmm9
00007d20d97d5f97  mulpd xmm6, xmm1
00007d20d97d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d20d97d5fa0  ptest xmm3, xmm3
00007d20d97d5fa5  jnz 0x00007D20D97D83A2
00007d20d97d5fab  movaps [r15+0x260], xmm6
00007d20d97d5fb3  vxorps xmm1, xmm1, xmm1
00007d20d97d5fb7  vpbroadcastq xmm1, xmm1
00007d20d97d5fbc  movaps [r15+0x1B0], xmm1
00007d20d97d5fc4  vmovaps xmm1, [rsp+0x60]
00007d20d97d5fca  vpermilpd xmm1, xmm1, 0x00
00007d20d97d5fd0  vmovaps xmm3, [rsp+0x70]
00007d20d97d5fd6  vmovaps [rsp+0x70], xmm15
00007d20d97d5fdc  movaps xmm9, xmm3
00007d20d97d5fe0  mulpd xmm9, xmm1
00007d20d97d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d20d97d5feb  ptest xmm15, xmm15
00007d20d97d5ff1  jnz 0x00007D20D97D84E3
00007d20d97d5ff7  lea r14, [rax+0xC0]
00007d20d97d5ffe  movups xmm1, [r13+r14*1]
00007d20d97d6004  vmovaps xmm3, [rsp+0xC0]
00007d20d97d600d  vmovaps [rsp+0x80], xmm1
00007d20d97d6016  movaps xmm15, xmm3
00007d20d97d601a  addpd xmm15, xmm7
00007d20d97d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97d6025  ptest xmm1, xmm1
00007d20d97d602a  jnz 0x00007D20D97D862F
00007d20d97d6030  vmovaps [rsp+0xC0], xmm13
00007d20d97d6039  vmovaps xmm1, [rsp+0xC0]
00007d20d97d6042  por xmm13, xmm1
00007d20d97d6047  movaps [r15+0x270], xmm13
00007d20d97d604f  vmovaps xmm1, [rsp+0xB0]
00007d20d97d6058  vmovaps xmm7, [rsp+0xB0]
00007d20d97d6061  por xmm1, xmm7
00007d20d97d6065  movaps [r15+0x1A0], xmm1
00007d20d97d606d  vmovaps xmm1, [rsp+0x60]
00007d20d97d6073  vpermilpd xmm1, xmm1, 0x00
00007d20d97d6079  vmovaps [rsp+0xB0], xmm1
00007d20d97d6082  vmovaps xmm1, [rsp+0x80]
00007d20d97d608b  vmovaps [rsp+0x80], xmm15
00007d20d97d6094  vmovaps xmm15, [rsp+0xB0]
00007d20d97d609d  vmovaps [rsp+0xB0], xmm14
00007d20d97d60a6  movaps xmm3, xmm1
00007d20d97d60a9  mulpd xmm3, xmm15
00007d20d97d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007d20d97d60b3  ptest xmm14, xmm14
00007d20d97d60b9  jnz 0x00007D20D97D8771
00007d20d97d60bf  lea r14, [rax+0x20]
00007d20d97d60c3  movups xmm1, [r13+r14*1]
00007d20d97d60c9  movaps [r15+0x110], xmm1
00007d20d97d60d1  vmovaps xmm14, [rsp+0x70]
00007d20d97d60d7  vmovaps [rsp+0x70], xmm1
00007d20d97d60dd  movaps xmm15, xmm14
00007d20d97d60e1  addpd xmm15, xmm4
00007d20d97d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97d60ec  ptest xmm1, xmm1
00007d20d97d60f1  jnz 0x00007D20D97D88BC
00007d20d97d60f7  vmovaps xmm1, [rsp+0x60]
00007d20d97d60fd  vpermilpd xmm1, xmm1, 0x00
00007d20d97d6103  movaps xmm14, xmm2
00007d20d97d6107  mulpd xmm14, xmm1
00007d20d97d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007d20d97d6112  ptest xmm4, xmm4
00007d20d97d6117  jnz 0x00007D20D97D89FF
00007d20d97d611d  vmovaps xmm4, [rsp+0x50]
00007d20d97d6123  movaps xmm1, xmm4
00007d20d97d6126  addpd xmm1, xmm9
00007d20d97d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d20d97d6130  ptest xmm2, xmm2
00007d20d97d6135  jnz 0x00007D20D97D8B41
00007d20d97d613b  vmovaps xmm9, [rsp+0x30]
00007d20d97d6141  vpermilpd xmm9, xmm9, 0x00
00007d20d97d6147  vmovaps xmm2, [rsp+0x70]
00007d20d97d614d  vmovaps [rsp+0x50], xmm1
00007d20d97d6153  movaps xmm4, xmm2
00007d20d97d6156  mulpd xmm4, xmm9
00007d20d97d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d20d97d6160  ptest xmm1, xmm1
00007d20d97d6165  jnz 0x00007D20D97D8C82
00007d20d97d616b  vmovaps xmm1, [rsp+0x30]
00007d20d97d6171  vpermilpd xmm1, xmm1, 0x00
00007d20d97d6177  vmovaps xmm2, [rsp+0x90]
00007d20d97d6180  vmovaps [rsp+0x60], xmm15
00007d20d97d6186  movaps xmm9, xmm2
00007d20d97d618a  mulpd xmm9, xmm1
00007d20d97d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d20d97d6195  ptest xmm15, xmm15
00007d20d97d619b  jnz 0x00007D20D97D8DC3
00007d20d97d61a1  vmovaps xmm15, [rsp+0x80]
00007d20d97d61aa  movaps xmm1, xmm15
00007d20d97d61ae  addpd xmm1, xmm6
00007d20d97d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007d20d97d61b7  ptest xmm2, xmm2
00007d20d97d61bc  jnz 0x00007D20D97D8F05
00007d20d97d61c2  movaps xmm15, xmm5
00007d20d97d61c6  addpd xmm15, xmm3
00007d20d97d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007d20d97d61d1  ptest xmm6, xmm6
00007d20d97d61d6  jnz 0x00007D20D97D9046
00007d20d97d61dc  vmovaps xmm6, [rsp+0x30]
00007d20d97d61e2  vpermilpd xmm6, xmm6, 0x00
00007d20d97d61e8  movaps xmm5, xmm8
00007d20d97d61ec  mulpd xmm5, xmm6
00007d20d97d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d20d97d61f5  ptest xmm3, xmm3
00007d20d97d61fa  jnz 0x00007D20D97D9188
00007d20d97d6200  vmovaps xmm8, [rsp+0x30]
00007d20d97d6206  vpermilpd xmm8, xmm8, 0x00
00007d20d97d620c  movaps xmm6, xmm10
00007d20d97d6210  mulpd xmm6, xmm8
00007d20d97d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007d20d97d621a  ptest xmm3, xmm3
00007d20d97d621f  jnz 0x00007D20D97D92C9
00007d20d97d6225  vmovaps xmm8, [rsp+0x60]
00007d20d97d622b  movaps xmm10, xmm8
00007d20d97d622f  addpd xmm10, xmm14
00007d20d97d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007d20d97d623a  ptest xmm3, xmm3
00007d20d97d623f  jnz 0x00007D20D97D940B
00007d20d97d6245  vmovaps xmm8, [rsp+0x50]
00007d20d97d624b  movaps xmm14, xmm8
00007d20d97d624f  addpd xmm14, xmm4
00007d20d97d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007d20d97d625a  ptest xmm3, xmm3
00007d20d97d625f  jnz 0x00007D20D97D954F
00007d20d97d6265  vmovaps xmm8, [rsp+0x40]
00007d20d97d626b  vpermilpd xmm8, xmm8, 0x00
00007d20d97d6271  movaps xmm4, xmm13
00007d20d97d6275  mulpd xmm4, xmm8
00007d20d97d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d20d97d627f  ptest xmm3, xmm3
00007d20d97d6284  jnz 0x00007D20D97D9692
00007d20d97d628a  movaps xmm13, xmm15
00007d20d97d628e  addpd xmm13, xmm9
00007d20d97d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007d20d97d6299  ptest xmm8, xmm8
00007d20d97d629f  jnz 0x00007D20D97D97D4
00007d20d97d62a5  movaps xmm15, xmm1
00007d20d97d62a9  addpd xmm15, xmm5
00007d20d97d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007d20d97d62b4  ptest xmm9, xmm9
00007d20d97d62ba  jnz 0x00007D20D97D9918
00007d20d97d62c0  vmovaps [rsp+0x30], xmm11
00007d20d97d62c6  vmovaps xmm1, [rsp+0x30]
00007d20d97d62cc  por xmm11, xmm1
00007d20d97d62d1  movaps [r15+0x250], xmm11
00007d20d97d62d9  vmovaps [rsp+0x30], xmm12
00007d20d97d62df  vmovaps xmm1, [rsp+0x30]
00007d20d97d62e5  por xmm12, xmm1
00007d20d97d62ea  movaps [r15+0x2A0], xmm12
00007d20d97d62f2  vmovaps xmm1, [rsp+0xA0]
00007d20d97d62fb  vmovaps xmm11, [rsp+0xA0]
00007d20d97d6304  por xmm1, xmm11
00007d20d97d6309  movaps [r15+0x1D0], xmm1
00007d20d97d6311  lea r14, [rax+0x40]
00007d20d97d6315  movups xmm1, [r13+r14*1]
00007d20d97d631b  movaps [r15+0x2C0], xmm1
00007d20d97d6323  vmovaps xmm11, [rsp+0x40]
00007d20d97d6329  vpermilpd xmm11, xmm11, 0x00
00007d20d97d632f  vmovaps xmm8, [rsp+0xE0]
00007d20d97d6338  movaps xmm9, xmm8
00007d20d97d633c  mulpd xmm9, xmm11
00007d20d97d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007d20d97d6347  ptest xmm5, xmm5
00007d20d97d634c  jnz 0x00007D20D97D9A64
00007d20d97d6352  movaps xmm11, xmm10
00007d20d97d6356  addpd xmm11, xmm6
00007d20d97d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d20d97d6361  ptest xmm8, xmm8
00007d20d97d6367  jnz 0x00007D20D97D9BA8
00007d20d97d636d  movaps xmm10, xmm14
00007d20d97d6371  addpd xmm10, xmm4
00007d20d97d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007d20d97d637c  ptest xmm8, xmm8
00007d20d97d6382  jnz 0x00007D20D97D9CEB
00007d20d97d6388  vmovaps xmm14, [rsp+0x40]
00007d20d97d638e  vpermilpd xmm14, xmm14, 0x00
00007d20d97d6394  movaps xmm8, xmm1
00007d20d97d6398  mulpd xmm8, xmm14
00007d20d97d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d20d97d63a3  ptest xmm6, xmm6
00007d20d97d63a8  jnz 0x00007D20D97D9E2E
00007d20d97d63ae  movaps xmm1, [r15+0x2B0]
00007d20d97d63b6  vmovaps xmm14, [rsp+0x40]
00007d20d97d63bc  vpermilpd xmm14, xmm14, 0x00
00007d20d97d63c2  movaps xmm6, xmm1
00007d20d97d63c5  mulpd xmm6, xmm14
00007d20d97d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007d20d97d63cf  ptest xmm5, xmm5
00007d20d97d63d4  jnz 0x00007D20D97D9F71
00007d20d97d63da  vmovaps xmm1, [rsp+0x10]
00007d20d97d63e0  vpermilpd xmm1, xmm1, 0x00
00007d20d97d63e6  movaps xmm14, xmm12
00007d20d97d63ea  mulpd xmm14, xmm1
00007d20d97d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007d20d97d63f5  ptest xmm5, xmm5
00007d20d97d63fa  jnz 0x00007D20D97DA0B2
00007d20d97d6400  movaps xmm1, xmm13
00007d20d97d6404  addpd xmm1, xmm9
00007d20d97d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007d20d97d640e  ptest xmm12, xmm12
00007d20d97d6414  jnz 0x00007D20D97DA1F5
00007d20d97d641a  vmovaps xmm13, [rsp+0x10]
00007d20d97d6420  vpermilpd xmm13, xmm13, 0x00
00007d20d97d6426  movaps xmm12, xmm7
00007d20d97d642a  mulpd xmm12, xmm13
00007d20d97d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d20d97d6435  ptest xmm9, xmm9
00007d20d97d643b  jnz 0x00007D20D97DA337
00007d20d97d6441  movaps xmm13, xmm15
00007d20d97d6445  addpd xmm13, xmm8
00007d20d97d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d20d97d6450  ptest xmm9, xmm9
00007d20d97d6456  jnz 0x00007D20D97DA47A
00007d20d97d645c  movaps xmm15, [r15+0x290]
00007d20d97d6464  vmovaps xmm9, [rsp+0x10]
00007d20d97d646a  vpermilpd xmm9, xmm9, 0x00
00007d20d97d6470  movaps xmm8, xmm15
00007d20d97d6474  mulpd xmm8, xmm9
00007d20d97d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007d20d97d647f  ptest xmm7, xmm7
00007d20d97d6484  jnz 0x00007D20D97DA5BE
00007d20d97d648a  movaps xmm15, xmm11
00007d20d97d648e  addpd xmm15, xmm6
00007d20d97d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007d20d97d6499  ptest xmm9, xmm9
00007d20d97d649f  jnz 0x00007D20D97DA702
00007d20d97d64a5  movaps xmm11, [r15+0x1E0]
00007d20d97d64ad  vmovaps xmm9, [rsp+0x10]
00007d20d97d64b3  vpermilpd xmm9, xmm9, 0x00
00007d20d97d64b9  movaps xmm7, xmm11
00007d20d97d64bd  mulpd xmm7, xmm9
00007d20d97d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d20d97d64c7  ptest xmm6, xmm6
00007d20d97d64cc  jnz 0x00007D20D97DA845
00007d20d97d64d2  movaps xmm11, xmm10
00007d20d97d64d6  addpd xmm11, xmm14
00007d20d97d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007d20d97d64e1  ptest xmm9, xmm9
00007d20d97d64e7  jnz 0x00007D20D97DA987
00007d20d97d64ed  lea r14, [rax+0x70]
00007d20d97d64f1  movups xmm14, [r13+r14*1]
00007d20d97d64f7  movaps [r15+0x240], xmm14
00007d20d97d64ff  movaps xmm10, xmm1
00007d20d97d6503  addpd xmm10, xmm12
00007d20d97d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007d20d97d650e  ptest xmm9, xmm9
00007d20d97d6514  jnz 0x00007D20D97DAAD5
00007d20d97d651a  movaps [r15+0x170], xmm10
00007d20d97d6522  vmovaps xmm1, [rsp+0x20]
00007d20d97d6528  vpermilpd xmm1, xmm1, 0x00
00007d20d97d652e  movaps xmm12, xmm14
00007d20d97d6532  mulpd xmm12, xmm1
00007d20d97d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007d20d97d653d  ptest xmm9, xmm9
00007d20d97d6543  jnz 0x00007D20D97DAC18
00007d20d97d6549  vmovaps xmm1, [rsp+0x20]
00007d20d97d654f  vpermilpd xmm1, xmm1, 0x00
00007d20d97d6555  vmovaps xmm9, [rsp+0xB0]
00007d20d97d655e  movaps xmm14, xmm9
00007d20d97d6562  mulpd xmm14, xmm1
00007d20d97d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007d20d97d656d  ptest xmm6, xmm6
00007d20d97d6572  jnz 0x00007D20D97DAD5B
00007d20d97d6578  movaps [r15+0x180], xmm14
00007d20d97d6580  movaps xmm1, xmm13
00007d20d97d6584  addpd xmm1, xmm8
00007d20d97d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007d20d97d658e  ptest xmm9, xmm9
00007d20d97d6594  jnz 0x00007D20D97DAE9E
00007d20d97d659a  movaps [r15+0x210], xmm1
00007d20d97d65a2  movups xmm13, [r13+rax*1]
00007d20d97d65a8  lea r14, [rax+0x10]
00007d20d97d65ac  movups xmm9, [r13+r14*1]
00007d20d97d65b2  movaps [r15+0x230], xmm9
00007d20d97d65ba  movaps xmm8, xmm15
00007d20d97d65be  addpd xmm8, xmm7
00007d20d97d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d20d97d65c9  ptest xmm6, xmm6
00007d20d97d65ce  jnz 0x00007D20D97DAFF4
00007d20d97d65d4  movaps [r15+0x130], xmm8
00007d20d97d65dc  vmovaps xmm15, [rsp+0x20]
00007d20d97d65e2  vpermilpd xmm15, xmm15, 0x00
00007d20d97d65e8  movaps xmm7, xmm9
00007d20d97d65ec  mulpd xmm7, xmm15
00007d20d97d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d20d97d65f6  ptest xmm6, xmm6
00007d20d97d65fb  jnz 0x00007D20D97DB137
00007d20d97d6601  movaps [r15+0x220], xmm7
00007d20d97d6609  vmovaps xmm15, [rsp+0x20]
00007d20d97d660f  vpermilpd xmm15, xmm15, 0x00
00007d20d97d6615  movaps xmm9, xmm13
00007d20d97d6619  mulpd xmm9, xmm15
00007d20d97d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007d20d97d6624  ptest xmm6, xmm6
00007d20d97d6629  jnz 0x00007D20D97DB279
00007d20d97d662f  movaps xmm15, xmm11
00007d20d97d6633  addpd xmm15, xmm12
00007d20d97d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007d20d97d663e  ptest xmm13, xmm13
00007d20d97d6644  jnz 0x00007D20D97DB3BD
00007d20d97d664a  movaps [r15+0x140], xmm15
00007d20d97d6652  movaps xmm13, xmm10
00007d20d97d6656  addpd xmm13, xmm14
00007d20d97d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d20d97d6661  ptest xmm12, xmm12
00007d20d97d6667  jnz 0x00007D20D97DB501
00007d20d97d666d  movaps [r15+0x150], xmm13
00007d20d97d6675  movaps xmm14, xmm1
00007d20d97d6679  addpd xmm14, xmm7
00007d20d97d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d20d97d6684  ptest xmm12, xmm12
00007d20d97d668a  jnz 0x00007D20D97DB645
00007d20d97d6690  movaps [r15+0x160], xmm14
00007d20d97d6698  movaps xmm1, xmm8
00007d20d97d669c  addpd xmm1, xmm9
00007d20d97d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007d20d97d66a6  ptest xmm12, xmm12
00007d20d97d66ac  jnz 0x00007D20D97DB787
00007d20d97d66b2  movaps [r15+0x120], xmm1
00007d20d97d66ba  movups [r13+r11*1], xmm15
00007d20d97d66c0  lea rax, [r11+0x10]
00007d20d97d66c4  movups [r13+rax*1], xmm13
00007d20d97d66ca  lea rax, [r11+0x20]
00007d20d97d66ce  movups [r13+rax*1], xmm14
00007d20d97d66d4  lea rax, [r11+0x30]
00007d20d97d66d8  movups [r13+rax*1], xmm1
00007d20d97d66de  mov eax, [r15+0x108]
00007d20d97d66e5  sahf
00007d20d97d66e6  jnz 0x00007D20D97D6718
00007d20d97d66e8  cmp dword ptr [r15+0x318], 0x00
00007d20d97d66f0  jz 0x00007D20D97DB900
00007d20d97d66f6  nop [rax+rax*1], ax
00007d20d97d66ff  nop [rax+rax*1], eax
00007d20d97d6707  mov eax, 0x410444
00007d20d97d670c  mov [r15+0x100], rax
00007d20d97d6713  jmp 0x00007D20D95FE110
00007d20d97d6718  cmp dword ptr [r15+0x318], 0x00
00007d20d97d6720  jz 0x00007D20D97D57E0
00007d20d97d6726  nop [rax+rax*1], ax
00007d20d97d672f  nop [rax+rax*1], eax
00007d20d97d6737  mov eax, 0x410278
00007d20d97d673c  mov [r15+0x100], rax
00007d20d97d6743  jmp 0x00007D20D95FE110
00007d20d97d6748  int3
00007d20d97d6749  call 0x00007D20D960A4B0
00007d20d97d674e  jmp 0x00007D20D97D5828
00007d20d97d6753  call 0x00007D20D9609240
00007d20d97d6758  jmp 0x00007D20D97D5832
00007d20d97d675d  call 0x00007D20D960A4B0
00007d20d97d6762  jmp 0x00007D20D97D588F
00007d20d97d6767  call 0x00007D20D9609240
00007d20d97d676c  jmp 0x00007D20D97D5899
00007d20d97d6771  call 0x00007D20D960A4B0
00007d20d97d6776  jmp 0x00007D20D97D58DD
00007d20d97d677b  call 0x00007D20D9609240
00007d20d97d6780  jmp 0x00007D20D97D58E7
00007d20d97d6785  call 0x00007D20D96B47C0
00007d20d97d678a  jmp 0x00007D20D97D5926
00007d20d97d678f  call 0x00007D20D960B720
00007d20d97d6794  jmp 0x00007D20D97D593A
00007d20d97d6799  call 0x00007D20D96BFC30
00007d20d97d679e  jmp 0x00007D20D97D5958
00007d20d97d67a3  call 0x00007D20D96BE9C0
00007d20d97d67a8  jmp 0x00007D20D97D5962
00007d20d97d67ad  call 0x00007D20D96BD750
00007d20d97d67b2  jmp 0x00007D20D97D596C
00007d20d97d67b7  sub rsp, 0x08
00007d20d97d67bb  push rax
00007d20d97d67bc  push rcx
00007d20d97d67bd  push rdx
00007d20d97d67be  push rdi
00007d20d97d67bf  push rsi
00007d20d97d67c0  push r8
00007d20d97d67c2  push r9
00007d20d97d67c4  push r10
00007d20d97d67c6  push r11
00007d20d97d67c8  sub rsp, 0xF0
00007d20d97d67cf  vmovaps [rsp], xmm0
00007d20d97d67d4  vmovaps [rsp+0x10], xmm1
00007d20d97d67da  vmovaps [rsp+0x20], xmm2
00007d20d97d67e0  vmovaps [rsp+0x30], xmm3
00007d20d97d67e6  vmovaps [rsp+0x40], xmm4
00007d20d97d67ec  vmovaps [rsp+0x50], xmm5
00007d20d97d67f2  vmovaps [rsp+0x60], xmm6
00007d20d97d67f8  vmovaps [rsp+0x70], xmm7
00007d20d97d67fe  vmovaps [rsp+0x80], xmm9
00007d20d97d6807  vmovaps [rsp+0x90], xmm10
00007d20d97d6810  vmovaps [rsp+0xA0], xmm11
00007d20d97d6819  vmovaps [rsp+0xB0], xmm12
00007d20d97d6822  vmovaps [rsp+0xC0], xmm13
00007d20d97d682b  vmovaps [rsp+0xD0], xmm14
00007d20d97d6834  vmovaps [rsp+0xE0], xmm15
00007d20d97d683d  sub rsp, 0x30
00007d20d97d6841  movaps [rsp], xmm8
00007d20d97d6846  movaps [rsp+0x10], xmm12
00007d20d97d684c  movaps [rsp+0x20], xmm15
00007d20d97d6852  lea rdi, [rsp]
00007d20d97d6856  mov esi, 0x00
00007d20d97d685b  mov rax, 0x5EFBF4CF6530
00007d20d97d6865  call rax
00007d20d97d6867  movaps xmm8, [rsp]
00007d20d97d686c  add rsp, 0x30
00007d20d97d6870  vmovaps xmm0, [rsp]
00007d20d97d6875  vmovaps xmm1, [rsp+0x10]
00007d20d97d687b  vmovaps xmm2, [rsp+0x20]
00007d20d97d6881  vmovaps xmm3, [rsp+0x30]
00007d20d97d6887  vmovaps xmm4, [rsp+0x40]
00007d20d97d688d  vmovaps xmm5, [rsp+0x50]
00007d20d97d6893  vmovaps xmm6, [rsp+0x60]
00007d20d97d6899  vmovaps xmm7, [rsp+0x70]
00007d20d97d689f  vmovaps xmm9, [rsp+0x80]
00007d20d97d68a8  vmovaps xmm10, [rsp+0x90]
00007d20d97d68b1  vmovaps xmm11, [rsp+0xA0]
00007d20d97d68ba  vmovaps xmm12, [rsp+0xB0]
00007d20d97d68c3  vmovaps xmm13, [rsp+0xC0]
00007d20d97d68cc  vmovaps xmm14, [rsp+0xD0]
00007d20d97d68d5  vmovaps xmm15, [rsp+0xE0]
00007d20d97d68de  add rsp, 0xF0
00007d20d97d68e5  pop r11
00007d20d97d68e7  pop r10
00007d20d97d68e9  pop r9
00007d20d97d68eb  pop r8
00007d20d97d68ed  pop rsi
00007d20d97d68ee  pop rdi
00007d20d97d68ef  pop rdx
00007d20d97d68f0  pop rcx
00007d20d97d68f1  pop rax
00007d20d97d68f2  add rsp, 0x08
00007d20d97d68f6  jmp 0x00007D20D97D599A
00007d20d97d68fb  sub rsp, 0x08
00007d20d97d68ff  push rax
00007d20d97d6900  push rcx
00007d20d97d6901  push rdx
00007d20d97d6902  push rdi
00007d20d97d6903  push rsi
00007d20d97d6904  push r8
00007d20d97d6906  push r9
00007d20d97d6908  push r10
00007d20d97d690a  push r11
00007d20d97d690c  sub rsp, 0xF0
00007d20d97d6913  vmovaps [rsp], xmm0
00007d20d97d6918  vmovaps [rsp+0x10], xmm1
00007d20d97d691e  vmovaps [rsp+0x20], xmm2
00007d20d97d6924  vmovaps [rsp+0x30], xmm3
00007d20d97d692a  vmovaps [rsp+0x40], xmm4
00007d20d97d6930  vmovaps [rsp+0x50], xmm5
00007d20d97d6936  vmovaps [rsp+0x60], xmm6
00007d20d97d693c  vmovaps [rsp+0x70], xmm8
00007d20d97d6942  vmovaps [rsp+0x80], xmm9
00007d20d97d694b  vmovaps [rsp+0x90], xmm10
00007d20d97d6954  vmovaps [rsp+0xA0], xmm11
00007d20d97d695d  vmovaps [rsp+0xB0], xmm12
00007d20d97d6966  vmovaps [rsp+0xC0], xmm13
00007d20d97d696f  vmovaps [rsp+0xD0], xmm14
00007d20d97d6978  vmovaps [rsp+0xE0], xmm15
00007d20d97d6981  sub rsp, 0x30
00007d20d97d6985  movaps [rsp], xmm7
00007d20d97d6989  movaps [rsp+0x10], xmm9
00007d20d97d698f  movaps [rsp+0x20], xmm15
00007d20d97d6995  lea rdi, [rsp]
00007d20d97d6999  mov esi, 0x00
00007d20d97d699e  mov rax, 0x5EFBF4CF6530
00007d20d97d69a8  call rax
00007d20d97d69aa  movaps xmm7, [rsp]
00007d20d97d69ae  add rsp, 0x30
00007d20d97d69b2  vmovaps xmm0, [rsp]
00007d20d97d69b7  vmovaps xmm1, [rsp+0x10]
00007d20d97d69bd  vmovaps xmm2, [rsp+0x20]
00007d20d97d69c3  vmovaps xmm3, [rsp+0x30]
00007d20d97d69c9  vmovaps xmm4, [rsp+0x40]
00007d20d97d69cf  vmovaps xmm5, [rsp+0x50]
00007d20d97d69d5  vmovaps xmm6, [rsp+0x60]
00007d20d97d69db  vmovaps xmm8, [rsp+0x70]
00007d20d97d69e1  vmovaps xmm9, [rsp+0x80]
00007d20d97d69ea  vmovaps xmm10, [rsp+0x90]
00007d20d97d69f3  vmovaps xmm11, [rsp+0xA0]
00007d20d97d69fc  vmovaps xmm12, [rsp+0xB0]
00007d20d97d6a05  vmovaps xmm13, [rsp+0xC0]
00007d20d97d6a0e  vmovaps xmm14, [rsp+0xD0]
00007d20d97d6a17  vmovaps xmm15, [rsp+0xE0]
00007d20d97d6a20  add rsp, 0xF0
00007d20d97d6a27  pop r11
00007d20d97d6a29  pop r10
00007d20d97d6a2b  pop r9
00007d20d97d6a2d  pop r8
00007d20d97d6a2f  pop rsi
00007d20d97d6a30  pop rdi
00007d20d97d6a31  pop rdx
00007d20d97d6a32  pop rcx
00007d20d97d6a33  pop rax
00007d20d97d6a34  add rsp, 0x08
00007d20d97d6a38  jmp 0x00007D20D97D59C8
00007d20d97d6a3d  sub rsp, 0x08
00007d20d97d6a41  push rax
00007d20d97d6a42  push rcx
00007d20d97d6a43  push rdx
00007d20d97d6a44  push rdi
00007d20d97d6a45  push rsi
00007d20d97d6a46  push r8
00007d20d97d6a48  push r9
00007d20d97d6a4a  push r10
00007d20d97d6a4c  push r11
00007d20d97d6a4e  sub rsp, 0xF0
00007d20d97d6a55  vmovaps [rsp], xmm0
00007d20d97d6a5a  vmovaps [rsp+0x10], xmm1
00007d20d97d6a60  vmovaps [rsp+0x20], xmm2
00007d20d97d6a66  vmovaps [rsp+0x30], xmm3
00007d20d97d6a6c  vmovaps [rsp+0x40], xmm4
00007d20d97d6a72  vmovaps [rsp+0x50], xmm5
00007d20d97d6a78  vmovaps [rsp+0x60], xmm6
00007d20d97d6a7e  vmovaps [rsp+0x70], xmm7
00007d20d97d6a84  vmovaps [rsp+0x80], xmm8
00007d20d97d6a8d  vmovaps [rsp+0x90], xmm10
00007d20d97d6a96  vmovaps [rsp+0xA0], xmm11
00007d20d97d6a9f  vmovaps [rsp+0xB0], xmm12
00007d20d97d6aa8  vmovaps [rsp+0xC0], xmm13
00007d20d97d6ab1  vmovaps [rsp+0xD0], xmm14
00007d20d97d6aba  vmovaps [rsp+0xE0], xmm15
00007d20d97d6ac3  sub rsp, 0x30
00007d20d97d6ac7  movaps [rsp], xmm9
00007d20d97d6acc  movaps [rsp+0x10], xmm12
00007d20d97d6ad2  movaps [rsp+0x20], xmm10
00007d20d97d6ad8  lea rdi, [rsp]
00007d20d97d6adc  mov esi, 0x00
00007d20d97d6ae1  mov rax, 0x5EFBF4CF6530
00007d20d97d6aeb  call rax
00007d20d97d6aed  movaps xmm9, [rsp]
00007d20d97d6af2  add rsp, 0x30
00007d20d97d6af6  vmovaps xmm0, [rsp]
00007d20d97d6afb  vmovaps xmm1, [rsp+0x10]
00007d20d97d6b01  vmovaps xmm2, [rsp+0x20]
00007d20d97d6b07  vmovaps xmm3, [rsp+0x30]
00007d20d97d6b0d  vmovaps xmm4, [rsp+0x40]
00007d20d97d6b13  vmovaps xmm5, [rsp+0x50]
00007d20d97d6b19  vmovaps xmm6, [rsp+0x60]
00007d20d97d6b1f  vmovaps xmm7, [rsp+0x70]
00007d20d97d6b25  vmovaps xmm8, [rsp+0x80]
00007d20d97d6b2e  vmovaps xmm10, [rsp+0x90]
00007d20d97d6b37  vmovaps xmm11, [rsp+0xA0]
00007d20d97d6b40  vmovaps xmm12, [rsp+0xB0]
00007d20d97d6b49  vmovaps xmm13, [rsp+0xC0]
00007d20d97d6b52  vmovaps xmm14, [rsp+0xD0]
00007d20d97d6b5b  vmovaps xmm15, [rsp+0xE0]
00007d20d97d6b64  add rsp, 0xF0
00007d20d97d6b6b  pop r11
00007d20d97d6b6d  pop r10
00007d20d97d6b6f  pop r9
00007d20d97d6b71  pop r8
00007d20d97d6b73  pop rsi
00007d20d97d6b74  pop rdi
00007d20d97d6b75  pop rdx
00007d20d97d6b76  pop rcx
00007d20d97d6b77  pop rax
00007d20d97d6b78  add rsp, 0x08
00007d20d97d6b7c  jmp 0x00007D20D97D59EC
00007d20d97d6b81  sub rsp, 0x08
00007d20d97d6b85  push rax
00007d20d97d6b86  push rcx
00007d20d97d6b87  push rdx
00007d20d97d6b88  push rdi
00007d20d97d6b89  push rsi
00007d20d97d6b8a  push r8
00007d20d97d6b8c  push r9
00007d20d97d6b8e  push r10
00007d20d97d6b90  push r11
00007d20d97d6b92  sub rsp, 0xF0
00007d20d97d6b99  vmovaps [rsp], xmm0
00007d20d97d6b9e  vmovaps [rsp+0x10], xmm1
00007d20d97d6ba4  vmovaps [rsp+0x20], xmm2
00007d20d97d6baa  vmovaps [rsp+0x30], xmm3
00007d20d97d6bb0  vmovaps [rsp+0x40], xmm4
00007d20d97d6bb6  vmovaps [rsp+0x50], xmm5
00007d20d97d6bbc  vmovaps [rsp+0x60], xmm6
00007d20d97d6bc2  vmovaps [rsp+0x70], xmm7
00007d20d97d6bc8  vmovaps [rsp+0x80], xmm8
00007d20d97d6bd1  vmovaps [rsp+0x90], xmm9
00007d20d97d6bda  vmovaps [rsp+0xA0], xmm11
00007d20d97d6be3  vmovaps [rsp+0xB0], xmm12
00007d20d97d6bec  vmovaps [rsp+0xC0], xmm13
00007d20d97d6bf5  vmovaps [rsp+0xD0], xmm14
00007d20d97d6bfe  vmovaps [rsp+0xE0], xmm15
00007d20d97d6c07  sub rsp, 0x30
00007d20d97d6c0b  movaps [rsp], xmm10
00007d20d97d6c10  movaps [rsp+0x10], xmm12
00007d20d97d6c16  movaps [rsp+0x20], xmm11
00007d20d97d6c1c  lea rdi, [rsp]
00007d20d97d6c20  mov esi, 0x00
00007d20d97d6c25  mov rax, 0x5EFBF4CF6530
00007d20d97d6c2f  call rax
00007d20d97d6c31  movaps xmm10, [rsp]
00007d20d97d6c36  add rsp, 0x30
00007d20d97d6c3a  vmovaps xmm0, [rsp]
00007d20d97d6c3f  vmovaps xmm1, [rsp+0x10]
00007d20d97d6c45  vmovaps xmm2, [rsp+0x20]
00007d20d97d6c4b  vmovaps xmm3, [rsp+0x30]
00007d20d97d6c51  vmovaps xmm4, [rsp+0x40]
00007d20d97d6c57  vmovaps xmm5, [rsp+0x50]
00007d20d97d6c5d  vmovaps xmm6, [rsp+0x60]
00007d20d97d6c63  vmovaps xmm7, [rsp+0x70]
00007d20d97d6c69  vmovaps xmm8, [rsp+0x80]
00007d20d97d6c72  vmovaps xmm9, [rsp+0x90]
00007d20d97d6c7b  vmovaps xmm11, [rsp+0xA0]
00007d20d97d6c84  vmovaps xmm12, [rsp+0xB0]
00007d20d97d6c8d  vmovaps xmm13, [rsp+0xC0]
00007d20d97d6c96  vmovaps xmm14, [rsp+0xD0]
00007d20d97d6c9f  vmovaps xmm15, [rsp+0xE0]
00007d20d97d6ca8  add rsp, 0xF0
00007d20d97d6caf  pop r11
00007d20d97d6cb1  pop r10
00007d20d97d6cb3  pop r9
00007d20d97d6cb5  pop r8
00007d20d97d6cb7  pop rsi
00007d20d97d6cb8  pop rdi
00007d20d97d6cb9  pop rdx
00007d20d97d6cba  pop rcx
00007d20d97d6cbb  pop rax
00007d20d97d6cbc  add rsp, 0x08
00007d20d97d6cc0  jmp 0x00007D20D97D5A06
00007d20d97d6cc5  sub rsp, 0x08
00007d20d97d6cc9  push rax
00007d20d97d6cca  push rcx
00007d20d97d6ccb  push rdx
00007d20d97d6ccc  push rdi
00007d20d97d6ccd  push rsi
00007d20d97d6cce  push r8
00007d20d97d6cd0  push r9
00007d20d97d6cd2  push r10
00007d20d97d6cd4  push r11
00007d20d97d6cd6  sub rsp, 0xF0
00007d20d97d6cdd  vmovaps [rsp], xmm0
00007d20d97d6ce2  vmovaps [rsp+0x10], xmm1
00007d20d97d6ce8  vmovaps [rsp+0x20], xmm2
00007d20d97d6cee  vmovaps [rsp+0x30], xmm3
00007d20d97d6cf4  vmovaps [rsp+0x40], xmm4
00007d20d97d6cfa  vmovaps [rsp+0x50], xmm5
00007d20d97d6d00  vmovaps [rsp+0x60], xmm7
00007d20d97d6d06  vmovaps [rsp+0x70], xmm8
00007d20d97d6d0c  vmovaps [rsp+0x80], xmm9
00007d20d97d6d15  vmovaps [rsp+0x90], xmm10
00007d20d97d6d1e  vmovaps [rsp+0xA0], xmm11
00007d20d97d6d27  vmovaps [rsp+0xB0], xmm12
00007d20d97d6d30  vmovaps [rsp+0xC0], xmm13
00007d20d97d6d39  vmovaps [rsp+0xD0], xmm14
00007d20d97d6d42  vmovaps [rsp+0xE0], xmm15
00007d20d97d6d4b  sub rsp, 0x30
00007d20d97d6d4f  movaps [rsp], xmm6
00007d20d97d6d53  movaps [rsp+0x10], xmm12
00007d20d97d6d59  movaps [rsp+0x20], xmm11
00007d20d97d6d5f  lea rdi, [rsp]
00007d20d97d6d63  mov esi, 0x00
00007d20d97d6d68  mov rax, 0x5EFBF4CF6530
00007d20d97d6d72  call rax
00007d20d97d6d74  movaps xmm6, [rsp]
00007d20d97d6d78  add rsp, 0x30
00007d20d97d6d7c  vmovaps xmm0, [rsp]
00007d20d97d6d81  vmovaps xmm1, [rsp+0x10]
00007d20d97d6d87  vmovaps xmm2, [rsp+0x20]
00007d20d97d6d8d  vmovaps xmm3, [rsp+0x30]
00007d20d97d6d93  vmovaps xmm4, [rsp+0x40]
00007d20d97d6d99  vmovaps xmm5, [rsp+0x50]
00007d20d97d6d9f  vmovaps xmm7, [rsp+0x60]
00007d20d97d6da5  vmovaps xmm8, [rsp+0x70]
00007d20d97d6dab  vmovaps xmm9, [rsp+0x80]
00007d20d97d6db4  vmovaps xmm10, [rsp+0x90]
00007d20d97d6dbd  vmovaps xmm11, [rsp+0xA0]
00007d20d97d6dc6  vmovaps xmm12, [rsp+0xB0]
00007d20d97d6dcf  vmovaps xmm13, [rsp+0xC0]
00007d20d97d6dd8  vmovaps xmm14, [rsp+0xD0]
00007d20d97d6de1  vmovaps xmm15, [rsp+0xE0]
00007d20d97d6dea  add rsp, 0xF0
00007d20d97d6df1  pop r11
00007d20d97d6df3  pop r10
00007d20d97d6df5  pop r9
00007d20d97d6df7  pop r8
00007d20d97d6df9  pop rsi
00007d20d97d6dfa  pop rdi
00007d20d97d6dfb  pop rdx
00007d20d97d6dfc  pop rcx
00007d20d97d6dfd  pop rax
00007d20d97d6dfe  add rsp, 0x08
00007d20d97d6e02  jmp 0x00007D20D97D5A27
00007d20d97d6e07  sub rsp, 0x08
00007d20d97d6e0b  push rax
00007d20d97d6e0c  push rcx
00007d20d97d6e0d  push rdx
00007d20d97d6e0e  push rdi
00007d20d97d6e0f  push rsi
00007d20d97d6e10  push r8
00007d20d97d6e12  push r9
00007d20d97d6e14  push r10
00007d20d97d6e16  push r11
00007d20d97d6e18  sub rsp, 0xF0
00007d20d97d6e1f  vmovaps [rsp], xmm0
00007d20d97d6e24  vmovaps [rsp+0x10], xmm1
00007d20d97d6e2a  vmovaps [rsp+0x20], xmm2
00007d20d97d6e30  vmovaps [rsp+0x30], xmm4
00007d20d97d6e36  vmovaps [rsp+0x40], xmm5
00007d20d97d6e3c  vmovaps [rsp+0x50], xmm6
00007d20d97d6e42  vmovaps [rsp+0x60], xmm7
00007d20d97d6e48  vmovaps [rsp+0x70], xmm8
00007d20d97d6e4e  vmovaps [rsp+0x80], xmm9
00007d20d97d6e57  vmovaps [rsp+0x90], xmm10
00007d20d97d6e60  vmovaps [rsp+0xA0], xmm11
00007d20d97d6e69  vmovaps [rsp+0xB0], xmm12
00007d20d97d6e72  vmovaps [rsp+0xC0], xmm13
00007d20d97d6e7b  vmovaps [rsp+0xD0], xmm14
00007d20d97d6e84  vmovaps [rsp+0xE0], xmm15
00007d20d97d6e8d  sub rsp, 0x30
00007d20d97d6e91  movaps [rsp], xmm3
00007d20d97d6e95  movaps [rsp+0x10], xmm5
00007d20d97d6e9a  movaps [rsp+0x20], xmm4
00007d20d97d6e9f  lea rdi, [rsp]
00007d20d97d6ea3  mov esi, 0x00
00007d20d97d6ea8  mov rax, 0x5EFBF4CF6530
00007d20d97d6eb2  call rax
00007d20d97d6eb4  movaps xmm3, [rsp]
00007d20d97d6eb8  add rsp, 0x30
00007d20d97d6ebc  vmovaps xmm0, [rsp]
00007d20d97d6ec1  vmovaps xmm1, [rsp+0x10]
00007d20d97d6ec7  vmovaps xmm2, [rsp+0x20]
00007d20d97d6ecd  vmovaps xmm4, [rsp+0x30]
00007d20d97d6ed3  vmovaps xmm5, [rsp+0x40]
00007d20d97d6ed9  vmovaps xmm6, [rsp+0x50]
00007d20d97d6edf  vmovaps xmm7, [rsp+0x60]
00007d20d97d6ee5  vmovaps xmm8, [rsp+0x70]
00007d20d97d6eeb  vmovaps xmm9, [rsp+0x80]
00007d20d97d6ef4  vmovaps xmm10, [rsp+0x90]
00007d20d97d6efd  vmovaps xmm11, [rsp+0xA0]
00007d20d97d6f06  vmovaps xmm12, [rsp+0xB0]
00007d20d97d6f0f  vmovaps xmm13, [rsp+0xC0]
00007d20d97d6f18  vmovaps xmm14, [rsp+0xD0]
00007d20d97d6f21  vmovaps xmm15, [rsp+0xE0]
00007d20d97d6f2a  add rsp, 0xF0
00007d20d97d6f31  pop r11
00007d20d97d6f33  pop r10
00007d20d97d6f35  pop r9
00007d20d97d6f37  pop r8
00007d20d97d6f39  pop rsi
00007d20d97d6f3a  pop rdi
00007d20d97d6f3b  pop rdx
00007d20d97d6f3c  pop rcx
00007d20d97d6f3d  pop rax
00007d20d97d6f3e  add rsp, 0x08
00007d20d97d6f42  jmp 0x00007D20D97D5A88
00007d20d97d6f47  sub rsp, 0x08
00007d20d97d6f4b  push rax
00007d20d97d6f4c  push rcx
00007d20d97d6f4d  push rdx
00007d20d97d6f4e  push rdi
00007d20d97d6f4f  push rsi
00007d20d97d6f50  push r8
00007d20d97d6f52  push r9
00007d20d97d6f54  push r10
00007d20d97d6f56  push r11
00007d20d97d6f58  sub rsp, 0xF0
00007d20d97d6f5f  vmovaps [rsp], xmm0
00007d20d97d6f64  vmovaps [rsp+0x10], xmm1
00007d20d97d6f6a  vmovaps [rsp+0x20], xmm2
00007d20d97d6f70  vmovaps [rsp+0x30], xmm3
00007d20d97d6f76  vmovaps [rsp+0x40], xmm4
00007d20d97d6f7c  vmovaps [rsp+0x50], xmm6
00007d20d97d6f82  vmovaps [rsp+0x60], xmm7
00007d20d97d6f88  vmovaps [rsp+0x70], xmm8
00007d20d97d6f8e  vmovaps [rsp+0x80], xmm9
00007d20d97d6f97  vmovaps [rsp+0x90], xmm10
00007d20d97d6fa0  vmovaps [rsp+0xA0], xmm11
00007d20d97d6fa9  vmovaps [rsp+0xB0], xmm12
00007d20d97d6fb2  vmovaps [rsp+0xC0], xmm13
00007d20d97d6fbb  vmovaps [rsp+0xD0], xmm14
00007d20d97d6fc4  vmovaps [rsp+0xE0], xmm15
00007d20d97d6fcd  sub rsp, 0x30
00007d20d97d6fd1  movaps [rsp], xmm5
00007d20d97d6fd5  movaps [rsp+0x10], xmm8
00007d20d97d6fdb  movaps [rsp+0x20], xmm15
00007d20d97d6fe1  lea rdi, [rsp]
00007d20d97d6fe5  mov esi, 0x00
00007d20d97d6fea  mov rax, 0x5EFBF4CF6530
00007d20d97d6ff4  call rax
00007d20d97d6ff6  movaps xmm5, [rsp]
00007d20d97d6ffa  add rsp, 0x30
00007d20d97d6ffe  vmovaps xmm0, [rsp]
00007d20d97d7003  vmovaps xmm1, [rsp+0x10]
00007d20d97d7009  vmovaps xmm2, [rsp+0x20]
00007d20d97d700f  vmovaps xmm3, [rsp+0x30]
00007d20d97d7015  vmovaps xmm4, [rsp+0x40]
00007d20d97d701b  vmovaps xmm6, [rsp+0x50]
00007d20d97d7021  vmovaps xmm7, [rsp+0x60]
00007d20d97d7027  vmovaps xmm8, [rsp+0x70]
00007d20d97d702d  vmovaps xmm9, [rsp+0x80]
00007d20d97d7036  vmovaps xmm10, [rsp+0x90]
00007d20d97d703f  vmovaps xmm11, [rsp+0xA0]
00007d20d97d7048  vmovaps xmm12, [rsp+0xB0]
00007d20d97d7051  vmovaps xmm13, [rsp+0xC0]
00007d20d97d705a  vmovaps xmm14, [rsp+0xD0]
00007d20d97d7063  vmovaps xmm15, [rsp+0xE0]
00007d20d97d706c  add rsp, 0xF0
00007d20d97d7073  pop r11
00007d20d97d7075  pop r10
00007d20d97d7077  pop r9
00007d20d97d7079  pop r8
00007d20d97d707b  pop rsi
00007d20d97d707c  pop rdi
00007d20d97d707d  pop rdx
00007d20d97d707e  pop rcx
00007d20d97d707f  pop rax
00007d20d97d7080  add rsp, 0x08
00007d20d97d7084  jmp 0x00007D20D97D5AC0
00007d20d97d7089  sub rsp, 0x08
00007d20d97d708d  push rax
00007d20d97d708e  push rcx
00007d20d97d708f  push rdx
00007d20d97d7090  push rdi
00007d20d97d7091  push rsi
00007d20d97d7092  push r8
00007d20d97d7094  push r9
00007d20d97d7096  push r10
00007d20d97d7098  push r11
00007d20d97d709a  sub rsp, 0xF0
00007d20d97d70a1  vmovaps [rsp], xmm0
00007d20d97d70a6  vmovaps [rsp+0x10], xmm1
00007d20d97d70ac  vmovaps [rsp+0x20], xmm2
00007d20d97d70b2  vmovaps [rsp+0x30], xmm3
00007d20d97d70b8  vmovaps [rsp+0x40], xmm5
00007d20d97d70be  vmovaps [rsp+0x50], xmm6
00007d20d97d70c4  vmovaps [rsp+0x60], xmm7
00007d20d97d70ca  vmovaps [rsp+0x70], xmm8
00007d20d97d70d0  vmovaps [rsp+0x80], xmm9
00007d20d97d70d9  vmovaps [rsp+0x90], xmm10
00007d20d97d70e2  vmovaps [rsp+0xA0], xmm11
00007d20d97d70eb  vmovaps [rsp+0xB0], xmm12
00007d20d97d70f4  vmovaps [rsp+0xC0], xmm13
00007d20d97d70fd  vmovaps [rsp+0xD0], xmm14
00007d20d97d7106  vmovaps [rsp+0xE0], xmm15
00007d20d97d710f  sub rsp, 0x30
00007d20d97d7113  movaps [rsp], xmm4
00007d20d97d7117  movaps [rsp+0x10], xmm9
00007d20d97d711d  movaps [rsp+0x20], xmm8
00007d20d97d7123  lea rdi, [rsp]
00007d20d97d7127  mov esi, 0x00
00007d20d97d712c  mov rax, 0x5EFBF4CF6530
00007d20d97d7136  call rax
00007d20d97d7138  movaps xmm4, [rsp]
00007d20d97d713c  add rsp, 0x30
00007d20d97d7140  vmovaps xmm0, [rsp]
00007d20d97d7145  vmovaps xmm1, [rsp+0x10]
00007d20d97d714b  vmovaps xmm2, [rsp+0x20]
00007d20d97d7151  vmovaps xmm3, [rsp+0x30]
00007d20d97d7157  vmovaps xmm5, [rsp+0x40]
00007d20d97d715d  vmovaps xmm6, [rsp+0x50]
00007d20d97d7163  vmovaps xmm7, [rsp+0x60]
00007d20d97d7169  vmovaps xmm8, [rsp+0x70]
00007d20d97d716f  vmovaps xmm9, [rsp+0x80]
00007d20d97d7178  vmovaps xmm10, [rsp+0x90]
00007d20d97d7181  vmovaps xmm11, [rsp+0xA0]
00007d20d97d718a  vmovaps xmm12, [rsp+0xB0]
00007d20d97d7193  vmovaps xmm13, [rsp+0xC0]
00007d20d97d719c  vmovaps xmm14, [rsp+0xD0]
00007d20d97d71a5  vmovaps xmm15, [rsp+0xE0]
00007d20d97d71ae  add rsp, 0xF0
00007d20d97d71b5  pop r11
00007d20d97d71b7  pop r10
00007d20d97d71b9  pop r9
00007d20d97d71bb  pop r8
00007d20d97d71bd  pop rsi
00007d20d97d71be  pop rdi
00007d20d97d71bf  pop rdx
00007d20d97d71c0  pop rcx
00007d20d97d71c1  pop rax
00007d20d97d71c2  add rsp, 0x08
00007d20d97d71c6  jmp 0x00007D20D97D5AE1
00007d20d97d71cb  sub rsp, 0x08
00007d20d97d71cf  push rax
00007d20d97d71d0  push rcx
00007d20d97d71d1  push rdx
00007d20d97d71d2  push rdi
00007d20d97d71d3  push rsi
00007d20d97d71d4  push r8
00007d20d97d71d6  push r9
00007d20d97d71d8  push r10
00007d20d97d71da  push r11
00007d20d97d71dc  sub rsp, 0xF0
00007d20d97d71e3  vmovaps [rsp], xmm0
00007d20d97d71e8  vmovaps [rsp+0x10], xmm1
00007d20d97d71ee  vmovaps [rsp+0x20], xmm2
00007d20d97d71f4  vmovaps [rsp+0x30], xmm3
00007d20d97d71fa  vmovaps [rsp+0x40], xmm4
00007d20d97d7200  vmovaps [rsp+0x50], xmm5
00007d20d97d7206  vmovaps [rsp+0x60], xmm6
00007d20d97d720c  vmovaps [rsp+0x70], xmm7
00007d20d97d7212  vmovaps [rsp+0x80], xmm8
00007d20d97d721b  vmovaps [rsp+0x90], xmm10
00007d20d97d7224  vmovaps [rsp+0xA0], xmm11
00007d20d97d722d  vmovaps [rsp+0xB0], xmm12
00007d20d97d7236  vmovaps [rsp+0xC0], xmm13
00007d20d97d723f  vmovaps [rsp+0xD0], xmm14
00007d20d97d7248  vmovaps [rsp+0xE0], xmm15
00007d20d97d7251  sub rsp, 0x30
00007d20d97d7255  movaps [rsp], xmm9
00007d20d97d725a  movaps [rsp+0x10], xmm10
00007d20d97d7260  movaps [rsp+0x20], xmm8
00007d20d97d7266  lea rdi, [rsp]
00007d20d97d726a  mov esi, 0x00
00007d20d97d726f  mov rax, 0x5EFBF4CF6530
00007d20d97d7279  call rax
00007d20d97d727b  movaps xmm9, [rsp]
00007d20d97d7280  add rsp, 0x30
00007d20d97d7284  vmovaps xmm0, [rsp]
00007d20d97d7289  vmovaps xmm1, [rsp+0x10]
00007d20d97d728f  vmovaps xmm2, [rsp+0x20]
00007d20d97d7295  vmovaps xmm3, [rsp+0x30]
00007d20d97d729b  vmovaps xmm4, [rsp+0x40]
00007d20d97d72a1  vmovaps xmm5, [rsp+0x50]
00007d20d97d72a7  vmovaps xmm6, [rsp+0x60]
00007d20d97d72ad  vmovaps xmm7, [rsp+0x70]
00007d20d97d72b3  vmovaps xmm8, [rsp+0x80]
00007d20d97d72bc  vmovaps xmm10, [rsp+0x90]
00007d20d97d72c5  vmovaps xmm11, [rsp+0xA0]
00007d20d97d72ce  vmovaps xmm12, [rsp+0xB0]
00007d20d97d72d7  vmovaps xmm13, [rsp+0xC0]
00007d20d97d72e0  vmovaps xmm14, [rsp+0xD0]
00007d20d97d72e9  vmovaps xmm15, [rsp+0xE0]
00007d20d97d72f2  add rsp, 0xF0
00007d20d97d72f9  pop r11
00007d20d97d72fb  pop r10
00007d20d97d72fd  pop r9
00007d20d97d72ff  pop r8
00007d20d97d7301  pop rsi
00007d20d97d7302  pop rdi
00007d20d97d7303  pop rdx
00007d20d97d7304  pop rcx
00007d20d97d7305  pop rax
00007d20d97d7306  add rsp, 0x08
00007d20d97d730a  jmp 0x00007D20D97D5AFB
00007d20d97d730f  call 0x00007D20D96D64F0
00007d20d97d7314  jmp 0x00007D20D97D5C15
00007d20d97d7319  call 0x00007D20D96D64F0
00007d20d97d731e  jmp 0x00007D20D97D5C2B
00007d20d97d7323  sub rsp, 0x08
00007d20d97d7327  push rax
00007d20d97d7328  push rcx
00007d20d97d7329  push rdx
00007d20d97d732a  push rdi
00007d20d97d732b  push rsi
00007d20d97d732c  push r8
00007d20d97d732e  push r9
00007d20d97d7330  push r10
00007d20d97d7332  push r11
00007d20d97d7334  sub rsp, 0xF0
00007d20d97d733b  vmovaps [rsp], xmm0
00007d20d97d7340  vmovaps [rsp+0x10], xmm2
00007d20d97d7346  vmovaps [rsp+0x20], xmm3
00007d20d97d734c  vmovaps [rsp+0x30], xmm4
00007d20d97d7352  vmovaps [rsp+0x40], xmm5
00007d20d97d7358  vmovaps [rsp+0x50], xmm6
00007d20d97d735e  vmovaps [rsp+0x60], xmm7
00007d20d97d7364  vmovaps [rsp+0x70], xmm8
00007d20d97d736a  vmovaps [rsp+0x80], xmm9
00007d20d97d7373  vmovaps [rsp+0x90], xmm10
00007d20d97d737c  vmovaps [rsp+0xA0], xmm11
00007d20d97d7385  vmovaps [rsp+0xB0], xmm12
00007d20d97d738e  vmovaps [rsp+0xC0], xmm13
00007d20d97d7397  vmovaps [rsp+0xD0], xmm14
00007d20d97d73a0  vmovaps [rsp+0xE0], xmm15
00007d20d97d73a9  sub rsp, 0x30
00007d20d97d73ad  movaps [rsp], xmm1
00007d20d97d73b1  movaps [rsp+0x10], xmm6
00007d20d97d73b6  movaps [rsp+0x20], xmm15
00007d20d97d73bc  lea rdi, [rsp]
00007d20d97d73c0  mov esi, 0x00
00007d20d97d73c5  mov rax, 0x5EFBF4CF6530
00007d20d97d73cf  call rax
00007d20d97d73d1  movaps xmm1, [rsp]
00007d20d97d73d5  add rsp, 0x30
00007d20d97d73d9  vmovaps xmm0, [rsp]
00007d20d97d73de  vmovaps xmm2, [rsp+0x10]
00007d20d97d73e4  vmovaps xmm3, [rsp+0x20]
00007d20d97d73ea  vmovaps xmm4, [rsp+0x30]
00007d20d97d73f0  vmovaps xmm5, [rsp+0x40]
00007d20d97d73f6  vmovaps xmm6, [rsp+0x50]
00007d20d97d73fc  vmovaps xmm7, [rsp+0x60]
00007d20d97d7402  vmovaps xmm8, [rsp+0x70]
00007d20d97d7408  vmovaps xmm9, [rsp+0x80]
00007d20d97d7411  vmovaps xmm10, [rsp+0x90]
00007d20d97d741a  vmovaps xmm11, [rsp+0xA0]
00007d20d97d7423  vmovaps xmm12, [rsp+0xB0]
00007d20d97d742c  vmovaps xmm13, [rsp+0xC0]
00007d20d97d7435  vmovaps xmm14, [rsp+0xD0]
00007d20d97d743e  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7447  add rsp, 0xF0
00007d20d97d744e  pop r11
00007d20d97d7450  pop r10
00007d20d97d7452  pop r9
00007d20d97d7454  pop r8
00007d20d97d7456  pop rsi
00007d20d97d7457  pop rdi
00007d20d97d7458  pop rdx
00007d20d97d7459  pop rcx
00007d20d97d745a  pop rax
00007d20d97d745b  add rsp, 0x08
00007d20d97d745f  jmp 0x00007D20D97D5C68
00007d20d97d7464  call 0x00007D20D96E5820
00007d20d97d7469  jmp 0x00007D20D97D5C75
00007d20d97d746e  sub rsp, 0x08
00007d20d97d7472  push rax
00007d20d97d7473  push rcx
00007d20d97d7474  push rdx
00007d20d97d7475  push rdi
00007d20d97d7476  push rsi
00007d20d97d7477  push r8
00007d20d97d7479  push r9
00007d20d97d747b  push r10
00007d20d97d747d  push r11
00007d20d97d747f  sub rsp, 0xF0
00007d20d97d7486  vmovaps [rsp], xmm0
00007d20d97d748b  vmovaps [rsp+0x10], xmm1
00007d20d97d7491  vmovaps [rsp+0x20], xmm2
00007d20d97d7497  vmovaps [rsp+0x30], xmm3
00007d20d97d749d  vmovaps [rsp+0x40], xmm4
00007d20d97d74a3  vmovaps [rsp+0x50], xmm5
00007d20d97d74a9  vmovaps [rsp+0x60], xmm6
00007d20d97d74af  vmovaps [rsp+0x70], xmm7
00007d20d97d74b5  vmovaps [rsp+0x80], xmm8
00007d20d97d74be  vmovaps [rsp+0x90], xmm9
00007d20d97d74c7  vmovaps [rsp+0xA0], xmm10
00007d20d97d74d0  vmovaps [rsp+0xB0], xmm11
00007d20d97d74d9  vmovaps [rsp+0xC0], xmm12
00007d20d97d74e2  vmovaps [rsp+0xD0], xmm13
00007d20d97d74eb  vmovaps [rsp+0xE0], xmm15
00007d20d97d74f4  sub rsp, 0x30
00007d20d97d74f8  movaps [rsp], xmm14
00007d20d97d74fd  movaps [rsp+0x10], xmm4
00007d20d97d7502  movaps [rsp+0x20], xmm3
00007d20d97d7507  lea rdi, [rsp]
00007d20d97d750b  mov esi, 0x00
00007d20d97d7510  mov rax, 0x5EFBF4CF6530
00007d20d97d751a  call rax
00007d20d97d751c  movaps xmm14, [rsp]
00007d20d97d7521  add rsp, 0x30
00007d20d97d7525  vmovaps xmm0, [rsp]
00007d20d97d752a  vmovaps xmm1, [rsp+0x10]
00007d20d97d7530  vmovaps xmm2, [rsp+0x20]
00007d20d97d7536  vmovaps xmm3, [rsp+0x30]
00007d20d97d753c  vmovaps xmm4, [rsp+0x40]
00007d20d97d7542  vmovaps xmm5, [rsp+0x50]
00007d20d97d7548  vmovaps xmm6, [rsp+0x60]
00007d20d97d754e  vmovaps xmm7, [rsp+0x70]
00007d20d97d7554  vmovaps xmm8, [rsp+0x80]
00007d20d97d755d  vmovaps xmm9, [rsp+0x90]
00007d20d97d7566  vmovaps xmm10, [rsp+0xA0]
00007d20d97d756f  vmovaps xmm11, [rsp+0xB0]
00007d20d97d7578  vmovaps xmm12, [rsp+0xC0]
00007d20d97d7581  vmovaps xmm13, [rsp+0xD0]
00007d20d97d758a  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7593  add rsp, 0xF0
00007d20d97d759a  pop r11
00007d20d97d759c  pop r10
00007d20d97d759e  pop r9
00007d20d97d75a0  pop r8
00007d20d97d75a2  pop rsi
00007d20d97d75a3  pop rdi
00007d20d97d75a4  pop rdx
00007d20d97d75a5  pop rcx
00007d20d97d75a6  pop rax
00007d20d97d75a7  add rsp, 0x08
00007d20d97d75ab  jmp 0x00007D20D97D5C8F
00007d20d97d75b0  sub rsp, 0x08
00007d20d97d75b4  push rax
00007d20d97d75b5  push rcx
00007d20d97d75b6  push rdx
00007d20d97d75b7  push rdi
00007d20d97d75b8  push rsi
00007d20d97d75b9  push r8
00007d20d97d75bb  push r9
00007d20d97d75bd  push r10
00007d20d97d75bf  push r11
00007d20d97d75c1  sub rsp, 0xF0
00007d20d97d75c8  vmovaps [rsp], xmm0
00007d20d97d75cd  vmovaps [rsp+0x10], xmm1
00007d20d97d75d3  vmovaps [rsp+0x20], xmm2
00007d20d97d75d9  vmovaps [rsp+0x30], xmm3
00007d20d97d75df  vmovaps [rsp+0x40], xmm4
00007d20d97d75e5  vmovaps [rsp+0x50], xmm5
00007d20d97d75eb  vmovaps [rsp+0x60], xmm7
00007d20d97d75f1  vmovaps [rsp+0x70], xmm8
00007d20d97d75f7  vmovaps [rsp+0x80], xmm9
00007d20d97d7600  vmovaps [rsp+0x90], xmm10
00007d20d97d7609  vmovaps [rsp+0xA0], xmm11
00007d20d97d7612  vmovaps [rsp+0xB0], xmm12
00007d20d97d761b  vmovaps [rsp+0xC0], xmm13
00007d20d97d7624  vmovaps [rsp+0xD0], xmm14
00007d20d97d762d  vmovaps [rsp+0xE0], xmm15
00007d20d97d7636  sub rsp, 0x30
00007d20d97d763a  movaps [rsp], xmm6
00007d20d97d763e  movaps [rsp+0x10], xmm9
00007d20d97d7644  movaps [rsp+0x20], xmm7
00007d20d97d7649  lea rdi, [rsp]
00007d20d97d764d  mov esi, 0x00
00007d20d97d7652  mov rax, 0x5EFBF4CF6530
00007d20d97d765c  call rax
00007d20d97d765e  movaps xmm6, [rsp]
00007d20d97d7662  add rsp, 0x30
00007d20d97d7666  vmovaps xmm0, [rsp]
00007d20d97d766b  vmovaps xmm1, [rsp+0x10]
00007d20d97d7671  vmovaps xmm2, [rsp+0x20]
00007d20d97d7677  vmovaps xmm3, [rsp+0x30]
00007d20d97d767d  vmovaps xmm4, [rsp+0x40]
00007d20d97d7683  vmovaps xmm5, [rsp+0x50]
00007d20d97d7689  vmovaps xmm7, [rsp+0x60]
00007d20d97d768f  vmovaps xmm8, [rsp+0x70]
00007d20d97d7695  vmovaps xmm9, [rsp+0x80]
00007d20d97d769e  vmovaps xmm10, [rsp+0x90]
00007d20d97d76a7  vmovaps xmm11, [rsp+0xA0]
00007d20d97d76b0  vmovaps xmm12, [rsp+0xB0]
00007d20d97d76b9  vmovaps xmm13, [rsp+0xC0]
00007d20d97d76c2  vmovaps xmm14, [rsp+0xD0]
00007d20d97d76cb  vmovaps xmm15, [rsp+0xE0]
00007d20d97d76d4  add rsp, 0xF0
00007d20d97d76db  pop r11
00007d20d97d76dd  pop r10
00007d20d97d76df  pop r9
00007d20d97d76e1  pop r8
00007d20d97d76e3  pop rsi
00007d20d97d76e4  pop rdi
00007d20d97d76e5  pop rdx
00007d20d97d76e6  pop rcx
00007d20d97d76e7  pop rax
00007d20d97d76e8  add rsp, 0x08
00007d20d97d76ec  jmp 0x00007D20D97D5CA7
00007d20d97d76f1  sub rsp, 0x08
00007d20d97d76f5  push rax
00007d20d97d76f6  push rcx
00007d20d97d76f7  push rdx
00007d20d97d76f8  push rdi
00007d20d97d76f9  push rsi
00007d20d97d76fa  push r8
00007d20d97d76fc  push r9
00007d20d97d76fe  push r10
00007d20d97d7700  push r11
00007d20d97d7702  sub rsp, 0xF0
00007d20d97d7709  vmovaps [rsp], xmm0
00007d20d97d770e  vmovaps [rsp+0x10], xmm1
00007d20d97d7714  vmovaps [rsp+0x20], xmm2
00007d20d97d771a  vmovaps [rsp+0x30], xmm3
00007d20d97d7720  vmovaps [rsp+0x40], xmm4
00007d20d97d7726  vmovaps [rsp+0x50], xmm5
00007d20d97d772c  vmovaps [rsp+0x60], xmm6
00007d20d97d7732  vmovaps [rsp+0x70], xmm8
00007d20d97d7738  vmovaps [rsp+0x80], xmm9
00007d20d97d7741  vmovaps [rsp+0x90], xmm10
00007d20d97d774a  vmovaps [rsp+0xA0], xmm11
00007d20d97d7753  vmovaps [rsp+0xB0], xmm12
00007d20d97d775c  vmovaps [rsp+0xC0], xmm13
00007d20d97d7765  vmovaps [rsp+0xD0], xmm14
00007d20d97d776e  vmovaps [rsp+0xE0], xmm15
00007d20d97d7777  sub rsp, 0x30
00007d20d97d777b  movaps [rsp], xmm7
00007d20d97d777f  movaps [rsp+0x10], xmm4
00007d20d97d7784  movaps [rsp+0x20], xmm9
00007d20d97d778a  lea rdi, [rsp]
00007d20d97d778e  mov esi, 0x00
00007d20d97d7793  mov rax, 0x5EFBF4CF6530
00007d20d97d779d  call rax
00007d20d97d779f  movaps xmm7, [rsp]
00007d20d97d77a3  add rsp, 0x30
00007d20d97d77a7  vmovaps xmm0, [rsp]
00007d20d97d77ac  vmovaps xmm1, [rsp+0x10]
00007d20d97d77b2  vmovaps xmm2, [rsp+0x20]
00007d20d97d77b8  vmovaps xmm3, [rsp+0x30]
00007d20d97d77be  vmovaps xmm4, [rsp+0x40]
00007d20d97d77c4  vmovaps xmm5, [rsp+0x50]
00007d20d97d77ca  vmovaps xmm6, [rsp+0x60]
00007d20d97d77d0  vmovaps xmm8, [rsp+0x70]
00007d20d97d77d6  vmovaps xmm9, [rsp+0x80]
00007d20d97d77df  vmovaps xmm10, [rsp+0x90]
00007d20d97d77e8  vmovaps xmm11, [rsp+0xA0]
00007d20d97d77f1  vmovaps xmm12, [rsp+0xB0]
00007d20d97d77fa  vmovaps xmm13, [rsp+0xC0]
00007d20d97d7803  vmovaps xmm14, [rsp+0xD0]
00007d20d97d780c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7815  add rsp, 0xF0
00007d20d97d781c  pop r11
00007d20d97d781e  pop r10
00007d20d97d7820  pop r9
00007d20d97d7822  pop r8
00007d20d97d7824  pop rsi
00007d20d97d7825  pop rdi
00007d20d97d7826  pop rdx
00007d20d97d7827  pop rcx
00007d20d97d7828  pop rax
00007d20d97d7829  add rsp, 0x08
00007d20d97d782d  jmp 0x00007D20D97D5CD4
00007d20d97d7832  sub rsp, 0x08
00007d20d97d7836  push rax
00007d20d97d7837  push rcx
00007d20d97d7838  push rdx
00007d20d97d7839  push rdi
00007d20d97d783a  push rsi
00007d20d97d783b  push r8
00007d20d97d783d  push r9
00007d20d97d783f  push r10
00007d20d97d7841  push r11
00007d20d97d7843  sub rsp, 0xF0
00007d20d97d784a  vmovaps [rsp], xmm0
00007d20d97d784f  vmovaps [rsp+0x10], xmm1
00007d20d97d7855  vmovaps [rsp+0x20], xmm2
00007d20d97d785b  vmovaps [rsp+0x30], xmm3
00007d20d97d7861  vmovaps [rsp+0x40], xmm5
00007d20d97d7867  vmovaps [rsp+0x50], xmm6
00007d20d97d786d  vmovaps [rsp+0x60], xmm7
00007d20d97d7873  vmovaps [rsp+0x70], xmm8
00007d20d97d7879  vmovaps [rsp+0x80], xmm9
00007d20d97d7882  vmovaps [rsp+0x90], xmm10
00007d20d97d788b  vmovaps [rsp+0xA0], xmm11
00007d20d97d7894  vmovaps [rsp+0xB0], xmm12
00007d20d97d789d  vmovaps [rsp+0xC0], xmm13
00007d20d97d78a6  vmovaps [rsp+0xD0], xmm14
00007d20d97d78af  vmovaps [rsp+0xE0], xmm15
00007d20d97d78b8  sub rsp, 0x30
00007d20d97d78bc  movaps [rsp], xmm4
00007d20d97d78c0  movaps [rsp+0x10], xmm15
00007d20d97d78c6  movaps [rsp+0x20], xmm9
00007d20d97d78cc  lea rdi, [rsp]
00007d20d97d78d0  mov esi, 0x00
00007d20d97d78d5  mov rax, 0x5EFBF4CF6530
00007d20d97d78df  call rax
00007d20d97d78e1  movaps xmm4, [rsp]
00007d20d97d78e5  add rsp, 0x30
00007d20d97d78e9  vmovaps xmm0, [rsp]
00007d20d97d78ee  vmovaps xmm1, [rsp+0x10]
00007d20d97d78f4  vmovaps xmm2, [rsp+0x20]
00007d20d97d78fa  vmovaps xmm3, [rsp+0x30]
00007d20d97d7900  vmovaps xmm5, [rsp+0x40]
00007d20d97d7906  vmovaps xmm6, [rsp+0x50]
00007d20d97d790c  vmovaps xmm7, [rsp+0x60]
00007d20d97d7912  vmovaps xmm8, [rsp+0x70]
00007d20d97d7918  vmovaps xmm9, [rsp+0x80]
00007d20d97d7921  vmovaps xmm10, [rsp+0x90]
00007d20d97d792a  vmovaps xmm11, [rsp+0xA0]
00007d20d97d7933  vmovaps xmm12, [rsp+0xB0]
00007d20d97d793c  vmovaps xmm13, [rsp+0xC0]
00007d20d97d7945  vmovaps xmm14, [rsp+0xD0]
00007d20d97d794e  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7957  add rsp, 0xF0
00007d20d97d795e  pop r11
00007d20d97d7960  pop r10
00007d20d97d7962  pop r9
00007d20d97d7964  pop r8
00007d20d97d7966  pop rsi
00007d20d97d7967  pop rdi
00007d20d97d7968  pop rdx
00007d20d97d7969  pop rcx
00007d20d97d796a  pop rax
00007d20d97d796b  add rsp, 0x08
00007d20d97d796f  jmp 0x00007D20D97D5CF9
00007d20d97d7974  call 0x00007D20D96E5820
00007d20d97d7979  jmp 0x00007D20D97D5D06
00007d20d97d797e  sub rsp, 0x08
00007d20d97d7982  push rax
00007d20d97d7983  push rcx
00007d20d97d7984  push rdx
00007d20d97d7985  push rdi
00007d20d97d7986  push rsi
00007d20d97d7987  push r8
00007d20d97d7989  push r9
00007d20d97d798b  push r10
00007d20d97d798d  push r11
00007d20d97d798f  sub rsp, 0xF0
00007d20d97d7996  vmovaps [rsp], xmm0
00007d20d97d799b  vmovaps [rsp+0x10], xmm1
00007d20d97d79a1  vmovaps [rsp+0x20], xmm2
00007d20d97d79a7  vmovaps [rsp+0x30], xmm4
00007d20d97d79ad  vmovaps [rsp+0x40], xmm5
00007d20d97d79b3  vmovaps [rsp+0x50], xmm6
00007d20d97d79b9  vmovaps [rsp+0x60], xmm7
00007d20d97d79bf  vmovaps [rsp+0x70], xmm8
00007d20d97d79c5  vmovaps [rsp+0x80], xmm9
00007d20d97d79ce  vmovaps [rsp+0x90], xmm10
00007d20d97d79d7  vmovaps [rsp+0xA0], xmm11
00007d20d97d79e0  vmovaps [rsp+0xB0], xmm12
00007d20d97d79e9  vmovaps [rsp+0xC0], xmm13
00007d20d97d79f2  vmovaps [rsp+0xD0], xmm14
00007d20d97d79fb  vmovaps [rsp+0xE0], xmm15
00007d20d97d7a04  sub rsp, 0x30
00007d20d97d7a08  movaps [rsp], xmm3
00007d20d97d7a0c  movaps [rsp+0x10], xmm1
00007d20d97d7a11  movaps [rsp+0x20], xmm9
00007d20d97d7a17  lea rdi, [rsp]
00007d20d97d7a1b  mov esi, 0x00
00007d20d97d7a20  mov rax, 0x5EFBF4CF6530
00007d20d97d7a2a  call rax
00007d20d97d7a2c  movaps xmm3, [rsp]
00007d20d97d7a30  add rsp, 0x30
00007d20d97d7a34  vmovaps xmm0, [rsp]
00007d20d97d7a39  vmovaps xmm1, [rsp+0x10]
00007d20d97d7a3f  vmovaps xmm2, [rsp+0x20]
00007d20d97d7a45  vmovaps xmm4, [rsp+0x30]
00007d20d97d7a4b  vmovaps xmm5, [rsp+0x40]
00007d20d97d7a51  vmovaps xmm6, [rsp+0x50]
00007d20d97d7a57  vmovaps xmm7, [rsp+0x60]
00007d20d97d7a5d  vmovaps xmm8, [rsp+0x70]
00007d20d97d7a63  vmovaps xmm9, [rsp+0x80]
00007d20d97d7a6c  vmovaps xmm10, [rsp+0x90]
00007d20d97d7a75  vmovaps xmm11, [rsp+0xA0]
00007d20d97d7a7e  vmovaps xmm12, [rsp+0xB0]
00007d20d97d7a87  vmovaps xmm13, [rsp+0xC0]
00007d20d97d7a90  vmovaps xmm14, [rsp+0xD0]
00007d20d97d7a99  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7aa2  add rsp, 0xF0
00007d20d97d7aa9  pop r11
00007d20d97d7aab  pop r10
00007d20d97d7aad  pop r9
00007d20d97d7aaf  pop r8
00007d20d97d7ab1  pop rsi
00007d20d97d7ab2  pop rdi
00007d20d97d7ab3  pop rdx
00007d20d97d7ab4  pop rcx
00007d20d97d7ab5  pop rax
00007d20d97d7ab6  add rsp, 0x08
00007d20d97d7aba  jmp 0x00007D20D97D5D43
00007d20d97d7abf  sub rsp, 0x08
00007d20d97d7ac3  push rax
00007d20d97d7ac4  push rcx
00007d20d97d7ac5  push rdx
00007d20d97d7ac6  push rdi
00007d20d97d7ac7  push rsi
00007d20d97d7ac8  push r8
00007d20d97d7aca  push r9
00007d20d97d7acc  push r10
00007d20d97d7ace  push r11
00007d20d97d7ad0  sub rsp, 0xF0
00007d20d97d7ad7  vmovaps [rsp], xmm0
00007d20d97d7adc  vmovaps [rsp+0x10], xmm2
00007d20d97d7ae2  vmovaps [rsp+0x20], xmm3
00007d20d97d7ae8  vmovaps [rsp+0x30], xmm4
00007d20d97d7aee  vmovaps [rsp+0x40], xmm5
00007d20d97d7af4  vmovaps [rsp+0x50], xmm6
00007d20d97d7afa  vmovaps [rsp+0x60], xmm7
00007d20d97d7b00  vmovaps [rsp+0x70], xmm8
00007d20d97d7b06  vmovaps [rsp+0x80], xmm9
00007d20d97d7b0f  vmovaps [rsp+0x90], xmm10
00007d20d97d7b18  vmovaps [rsp+0xA0], xmm11
00007d20d97d7b21  vmovaps [rsp+0xB0], xmm12
00007d20d97d7b2a  vmovaps [rsp+0xC0], xmm13
00007d20d97d7b33  vmovaps [rsp+0xD0], xmm14
00007d20d97d7b3c  vmovaps [rsp+0xE0], xmm15
00007d20d97d7b45  sub rsp, 0x30
00007d20d97d7b49  movaps [rsp], xmm1
00007d20d97d7b4d  movaps [rsp+0x10], xmm15
00007d20d97d7b53  movaps [rsp+0x20], xmm9
00007d20d97d7b59  lea rdi, [rsp]
00007d20d97d7b5d  mov esi, 0x00
00007d20d97d7b62  mov rax, 0x5EFBF4CF6530
00007d20d97d7b6c  call rax
00007d20d97d7b6e  movaps xmm1, [rsp]
00007d20d97d7b72  add rsp, 0x30
00007d20d97d7b76  vmovaps xmm0, [rsp]
00007d20d97d7b7b  vmovaps xmm2, [rsp+0x10]
00007d20d97d7b81  vmovaps xmm3, [rsp+0x20]
00007d20d97d7b87  vmovaps xmm4, [rsp+0x30]
00007d20d97d7b8d  vmovaps xmm5, [rsp+0x40]
00007d20d97d7b93  vmovaps xmm6, [rsp+0x50]
00007d20d97d7b99  vmovaps xmm7, [rsp+0x60]
00007d20d97d7b9f  vmovaps xmm8, [rsp+0x70]
00007d20d97d7ba5  vmovaps xmm9, [rsp+0x80]
00007d20d97d7bae  vmovaps xmm10, [rsp+0x90]
00007d20d97d7bb7  vmovaps xmm11, [rsp+0xA0]
00007d20d97d7bc0  vmovaps xmm12, [rsp+0xB0]
00007d20d97d7bc9  vmovaps xmm13, [rsp+0xC0]
00007d20d97d7bd2  vmovaps xmm14, [rsp+0xD0]
00007d20d97d7bdb  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7be4  add rsp, 0xF0
00007d20d97d7beb  pop r11
00007d20d97d7bed  pop r10
00007d20d97d7bef  pop r9
00007d20d97d7bf1  pop r8
00007d20d97d7bf3  pop rsi
00007d20d97d7bf4  pop rdi
00007d20d97d7bf5  pop rdx
00007d20d97d7bf6  pop rcx
00007d20d97d7bf7  pop rax
00007d20d97d7bf8  add rsp, 0x08
00007d20d97d7bfc  jmp 0x00007D20D97D5DCB
00007d20d97d7c01  call 0x00007D20D96E5820
00007d20d97d7c06  jmp 0x00007D20D97D5DD8
00007d20d97d7c0b  sub rsp, 0x08
00007d20d97d7c0f  push rax
00007d20d97d7c10  push rcx
00007d20d97d7c11  push rdx
00007d20d97d7c12  push rdi
00007d20d97d7c13  push rsi
00007d20d97d7c14  push r8
00007d20d97d7c16  push r9
00007d20d97d7c18  push r10
00007d20d97d7c1a  push r11
00007d20d97d7c1c  sub rsp, 0xF0
00007d20d97d7c23  vmovaps [rsp], xmm0
00007d20d97d7c28  vmovaps [rsp+0x10], xmm2
00007d20d97d7c2e  vmovaps [rsp+0x20], xmm3
00007d20d97d7c34  vmovaps [rsp+0x30], xmm4
00007d20d97d7c3a  vmovaps [rsp+0x40], xmm5
00007d20d97d7c40  vmovaps [rsp+0x50], xmm6
00007d20d97d7c46  vmovaps [rsp+0x60], xmm7
00007d20d97d7c4c  vmovaps [rsp+0x70], xmm8
00007d20d97d7c52  vmovaps [rsp+0x80], xmm9
00007d20d97d7c5b  vmovaps [rsp+0x90], xmm10
00007d20d97d7c64  vmovaps [rsp+0xA0], xmm11
00007d20d97d7c6d  vmovaps [rsp+0xB0], xmm12
00007d20d97d7c76  vmovaps [rsp+0xC0], xmm13
00007d20d97d7c7f  vmovaps [rsp+0xD0], xmm14
00007d20d97d7c88  vmovaps [rsp+0xE0], xmm15
00007d20d97d7c91  sub rsp, 0x30
00007d20d97d7c95  movaps [rsp], xmm1
00007d20d97d7c99  movaps [rsp+0x10], xmm5
00007d20d97d7c9e  movaps [rsp+0x20], xmm7
00007d20d97d7ca3  lea rdi, [rsp]
00007d20d97d7ca7  mov esi, 0x00
00007d20d97d7cac  mov rax, 0x5EFBF4CF6530
00007d20d97d7cb6  call rax
00007d20d97d7cb8  movaps xmm1, [rsp]
00007d20d97d7cbc  add rsp, 0x30
00007d20d97d7cc0  vmovaps xmm0, [rsp]
00007d20d97d7cc5  vmovaps xmm2, [rsp+0x10]
00007d20d97d7ccb  vmovaps xmm3, [rsp+0x20]
00007d20d97d7cd1  vmovaps xmm4, [rsp+0x30]
00007d20d97d7cd7  vmovaps xmm5, [rsp+0x40]
00007d20d97d7cdd  vmovaps xmm6, [rsp+0x50]
00007d20d97d7ce3  vmovaps xmm7, [rsp+0x60]
00007d20d97d7ce9  vmovaps xmm8, [rsp+0x70]
00007d20d97d7cef  vmovaps xmm9, [rsp+0x80]
00007d20d97d7cf8  vmovaps xmm10, [rsp+0x90]
00007d20d97d7d01  vmovaps xmm11, [rsp+0xA0]
00007d20d97d7d0a  vmovaps xmm12, [rsp+0xB0]
00007d20d97d7d13  vmovaps xmm13, [rsp+0xC0]
00007d20d97d7d1c  vmovaps xmm14, [rsp+0xD0]
00007d20d97d7d25  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7d2e  add rsp, 0xF0
00007d20d97d7d35  pop r11
00007d20d97d7d37  pop r10
00007d20d97d7d39  pop r9
00007d20d97d7d3b  pop r8
00007d20d97d7d3d  pop rsi
00007d20d97d7d3e  pop rdi
00007d20d97d7d3f  pop rdx
00007d20d97d7d40  pop rcx
00007d20d97d7d41  pop rax
00007d20d97d7d42  add rsp, 0x08
00007d20d97d7d46  jmp 0x00007D20D97D5E7D
00007d20d97d7d4b  sub rsp, 0x08
00007d20d97d7d4f  push rax
00007d20d97d7d50  push rcx
00007d20d97d7d51  push rdx
00007d20d97d7d52  push rdi
00007d20d97d7d53  push rsi
00007d20d97d7d54  push r8
00007d20d97d7d56  push r9
00007d20d97d7d58  push r10
00007d20d97d7d5a  push r11
00007d20d97d7d5c  sub rsp, 0xF0
00007d20d97d7d63  vmovaps [rsp], xmm0
00007d20d97d7d68  vmovaps [rsp+0x10], xmm1
00007d20d97d7d6e  vmovaps [rsp+0x20], xmm2
00007d20d97d7d74  vmovaps [rsp+0x30], xmm3
00007d20d97d7d7a  vmovaps [rsp+0x40], xmm4
00007d20d97d7d80  vmovaps [rsp+0x50], xmm5
00007d20d97d7d86  vmovaps [rsp+0x60], xmm6
00007d20d97d7d8c  vmovaps [rsp+0x70], xmm8
00007d20d97d7d92  vmovaps [rsp+0x80], xmm9
00007d20d97d7d9b  vmovaps [rsp+0x90], xmm10
00007d20d97d7da4  vmovaps [rsp+0xA0], xmm11
00007d20d97d7dad  vmovaps [rsp+0xB0], xmm12
00007d20d97d7db6  vmovaps [rsp+0xC0], xmm13
00007d20d97d7dbf  vmovaps [rsp+0xD0], xmm14
00007d20d97d7dc8  vmovaps [rsp+0xE0], xmm15
00007d20d97d7dd1  sub rsp, 0x30
00007d20d97d7dd5  movaps [rsp], xmm7
00007d20d97d7dd9  movaps [rsp+0x10], xmm5
00007d20d97d7dde  movaps [rsp+0x20], xmm15
00007d20d97d7de4  lea rdi, [rsp]
00007d20d97d7de8  mov esi, 0x00
00007d20d97d7ded  mov rax, 0x5EFBF4CF6530
00007d20d97d7df7  call rax
00007d20d97d7df9  movaps xmm7, [rsp]
00007d20d97d7dfd  add rsp, 0x30
00007d20d97d7e01  vmovaps xmm0, [rsp]
00007d20d97d7e06  vmovaps xmm1, [rsp+0x10]
00007d20d97d7e0c  vmovaps xmm2, [rsp+0x20]
00007d20d97d7e12  vmovaps xmm3, [rsp+0x30]
00007d20d97d7e18  vmovaps xmm4, [rsp+0x40]
00007d20d97d7e1e  vmovaps xmm5, [rsp+0x50]
00007d20d97d7e24  vmovaps xmm6, [rsp+0x60]
00007d20d97d7e2a  vmovaps xmm8, [rsp+0x70]
00007d20d97d7e30  vmovaps xmm9, [rsp+0x80]
00007d20d97d7e39  vmovaps xmm10, [rsp+0x90]
00007d20d97d7e42  vmovaps xmm11, [rsp+0xA0]
00007d20d97d7e4b  vmovaps xmm12, [rsp+0xB0]
00007d20d97d7e54  vmovaps xmm13, [rsp+0xC0]
00007d20d97d7e5d  vmovaps xmm14, [rsp+0xD0]
00007d20d97d7e66  vmovaps xmm15, [rsp+0xE0]
00007d20d97d7e6f  add rsp, 0xF0
00007d20d97d7e76  pop r11
00007d20d97d7e78  pop r10
00007d20d97d7e7a  pop r9
00007d20d97d7e7c  pop r8
00007d20d97d7e7e  pop rsi
00007d20d97d7e7f  pop rdi
00007d20d97d7e80  pop rdx
00007d20d97d7e81  pop rcx
00007d20d97d7e82  pop rax
00007d20d97d7e83  add rsp, 0x08
00007d20d97d7e87  jmp 0x00007D20D97D5EB3
00007d20d97d7e8c  call 0x00007D20D96D64F0
00007d20d97d7e91  jmp 0x00007D20D97D5EC0
00007d20d97d7e96  sub rsp, 0x08
00007d20d97d7e9a  push rax
00007d20d97d7e9b  push rcx
00007d20d97d7e9c  push rdx
00007d20d97d7e9d  push rdi
00007d20d97d7e9e  push rsi
00007d20d97d7e9f  push r8
00007d20d97d7ea1  push r9
00007d20d97d7ea3  push r10
00007d20d97d7ea5  push r11
00007d20d97d7ea7  sub rsp, 0xF0
00007d20d97d7eae  vmovaps [rsp], xmm0
00007d20d97d7eb3  vmovaps [rsp+0x10], xmm1
00007d20d97d7eb9  vmovaps [rsp+0x20], xmm2
00007d20d97d7ebf  vmovaps [rsp+0x30], xmm3
00007d20d97d7ec5  vmovaps [rsp+0x40], xmm4
00007d20d97d7ecb  vmovaps [rsp+0x50], xmm5
00007d20d97d7ed1  vmovaps [rsp+0x60], xmm6
00007d20d97d7ed7  vmovaps [rsp+0x70], xmm7
00007d20d97d7edd  vmovaps [rsp+0x80], xmm8
00007d20d97d7ee6  vmovaps [rsp+0x90], xmm9
00007d20d97d7eef  vmovaps [rsp+0xA0], xmm10
00007d20d97d7ef8  vmovaps [rsp+0xB0], xmm11
00007d20d97d7f01  vmovaps [rsp+0xC0], xmm12
00007d20d97d7f0a  vmovaps [rsp+0xD0], xmm13
00007d20d97d7f13  vmovaps [rsp+0xE0], xmm14
00007d20d97d7f1c  sub rsp, 0x30
00007d20d97d7f20  movaps [rsp], xmm15
00007d20d97d7f25  movaps [rsp+0x10], xmm5
00007d20d97d7f2a  movaps [rsp+0x20], xmm3
00007d20d97d7f2f  lea rdi, [rsp]
00007d20d97d7f33  mov esi, 0x00
00007d20d97d7f38  mov rax, 0x5EFBF4CF6530
00007d20d97d7f42  call rax
00007d20d97d7f44  movaps xmm15, [rsp]
00007d20d97d7f49  add rsp, 0x30
00007d20d97d7f4d  vmovaps xmm0, [rsp]
00007d20d97d7f52  vmovaps xmm1, [rsp+0x10]
00007d20d97d7f58  vmovaps xmm2, [rsp+0x20]
00007d20d97d7f5e  vmovaps xmm3, [rsp+0x30]
00007d20d97d7f64  vmovaps xmm4, [rsp+0x40]
00007d20d97d7f6a  vmovaps xmm5, [rsp+0x50]
00007d20d97d7f70  vmovaps xmm6, [rsp+0x60]
00007d20d97d7f76  vmovaps xmm7, [rsp+0x70]
00007d20d97d7f7c  vmovaps xmm8, [rsp+0x80]
00007d20d97d7f85  vmovaps xmm9, [rsp+0x90]
00007d20d97d7f8e  vmovaps xmm10, [rsp+0xA0]
00007d20d97d7f97  vmovaps xmm11, [rsp+0xB0]
00007d20d97d7fa0  vmovaps xmm12, [rsp+0xC0]
00007d20d97d7fa9  vmovaps xmm13, [rsp+0xD0]
00007d20d97d7fb2  vmovaps xmm14, [rsp+0xE0]
00007d20d97d7fbb  add rsp, 0xF0
00007d20d97d7fc2  pop r11
00007d20d97d7fc4  pop r10
00007d20d97d7fc6  pop r9
00007d20d97d7fc8  pop r8
00007d20d97d7fca  pop rsi
00007d20d97d7fcb  pop rdi
00007d20d97d7fcc  pop rdx
00007d20d97d7fcd  pop rcx
00007d20d97d7fce  pop rax
00007d20d97d7fcf  add rsp, 0x08
00007d20d97d7fd3  jmp 0x00007D20D97D5EE6
00007d20d97d7fd8  sub rsp, 0x08
00007d20d97d7fdc  push rax
00007d20d97d7fdd  push rcx
00007d20d97d7fde  push rdx
00007d20d97d7fdf  push rdi
00007d20d97d7fe0  push rsi
00007d20d97d7fe1  push r8
00007d20d97d7fe3  push r9
00007d20d97d7fe5  push r10
00007d20d97d7fe7  push r11
00007d20d97d7fe9  sub rsp, 0xF0
00007d20d97d7ff0  vmovaps [rsp], xmm0
00007d20d97d7ff5  vmovaps [rsp+0x10], xmm2
00007d20d97d7ffb  vmovaps [rsp+0x20], xmm3
00007d20d97d8001  vmovaps [rsp+0x30], xmm4
00007d20d97d8007  vmovaps [rsp+0x40], xmm5
00007d20d97d800d  vmovaps [rsp+0x50], xmm6
00007d20d97d8013  vmovaps [rsp+0x60], xmm7
00007d20d97d8019  vmovaps [rsp+0x70], xmm8
00007d20d97d801f  vmovaps [rsp+0x80], xmm9
00007d20d97d8028  vmovaps [rsp+0x90], xmm10
00007d20d97d8031  vmovaps [rsp+0xA0], xmm11
00007d20d97d803a  vmovaps [rsp+0xB0], xmm12
00007d20d97d8043  vmovaps [rsp+0xC0], xmm13
00007d20d97d804c  vmovaps [rsp+0xD0], xmm14
00007d20d97d8055  vmovaps [rsp+0xE0], xmm15
00007d20d97d805e  sub rsp, 0x30
00007d20d97d8062  movaps [rsp], xmm1
00007d20d97d8066  movaps [rsp+0x10], xmm5
00007d20d97d806b  movaps [rsp+0x20], xmm4
00007d20d97d8070  lea rdi, [rsp]
00007d20d97d8074  mov esi, 0x00
00007d20d97d8079  mov rax, 0x5EFBF4CF6530
00007d20d97d8083  call rax
00007d20d97d8085  movaps xmm1, [rsp]
00007d20d97d8089  add rsp, 0x30
00007d20d97d808d  vmovaps xmm0, [rsp]
00007d20d97d8092  vmovaps xmm2, [rsp+0x10]
00007d20d97d8098  vmovaps xmm3, [rsp+0x20]
00007d20d97d809e  vmovaps xmm4, [rsp+0x30]
00007d20d97d80a4  vmovaps xmm5, [rsp+0x40]
00007d20d97d80aa  vmovaps xmm6, [rsp+0x50]
00007d20d97d80b0  vmovaps xmm7, [rsp+0x60]
00007d20d97d80b6  vmovaps xmm8, [rsp+0x70]
00007d20d97d80bc  vmovaps xmm9, [rsp+0x80]
00007d20d97d80c5  vmovaps xmm10, [rsp+0x90]
00007d20d97d80ce  vmovaps xmm11, [rsp+0xA0]
00007d20d97d80d7  vmovaps xmm12, [rsp+0xB0]
00007d20d97d80e0  vmovaps xmm13, [rsp+0xC0]
00007d20d97d80e9  vmovaps xmm14, [rsp+0xD0]
00007d20d97d80f2  vmovaps xmm15, [rsp+0xE0]
00007d20d97d80fb  add rsp, 0xF0
00007d20d97d8102  pop r11
00007d20d97d8104  pop r10
00007d20d97d8106  pop r9
00007d20d97d8108  pop r8
00007d20d97d810a  pop rsi
00007d20d97d810b  pop rdi
00007d20d97d810c  pop rdx
00007d20d97d810d  pop rcx
00007d20d97d810e  pop rax
00007d20d97d810f  add rsp, 0x08
00007d20d97d8113  jmp 0x00007D20D97D5F06
00007d20d97d8118  sub rsp, 0x08
00007d20d97d811c  push rax
00007d20d97d811d  push rcx
00007d20d97d811e  push rdx
00007d20d97d811f  push rdi
00007d20d97d8120  push rsi
00007d20d97d8121  push r8
00007d20d97d8123  push r9
00007d20d97d8125  push r10
00007d20d97d8127  push r11
00007d20d97d8129  sub rsp, 0xF0
00007d20d97d8130  vmovaps [rsp], xmm0
00007d20d97d8135  vmovaps [rsp+0x10], xmm1
00007d20d97d813b  vmovaps [rsp+0x20], xmm2
00007d20d97d8141  vmovaps [rsp+0x30], xmm3
00007d20d97d8147  vmovaps [rsp+0x40], xmm5
00007d20d97d814d  vmovaps [rsp+0x50], xmm6
00007d20d97d8153  vmovaps [rsp+0x60], xmm7
00007d20d97d8159  vmovaps [rsp+0x70], xmm8
00007d20d97d815f  vmovaps [rsp+0x80], xmm9
00007d20d97d8168  vmovaps [rsp+0x90], xmm10
00007d20d97d8171  vmovaps [rsp+0xA0], xmm11
00007d20d97d817a  vmovaps [rsp+0xB0], xmm12
00007d20d97d8183  vmovaps [rsp+0xC0], xmm13
00007d20d97d818c  vmovaps [rsp+0xD0], xmm14
00007d20d97d8195  vmovaps [rsp+0xE0], xmm15
00007d20d97d819e  sub rsp, 0x30
00007d20d97d81a2  movaps [rsp], xmm4
00007d20d97d81a6  movaps [rsp+0x10], xmm3
00007d20d97d81ab  movaps [rsp+0x20], xmm5
00007d20d97d81b0  lea rdi, [rsp]
00007d20d97d81b4  mov esi, 0x00
00007d20d97d81b9  mov rax, 0x5EFBF4CF6530
00007d20d97d81c3  call rax
00007d20d97d81c5  movaps xmm4, [rsp]
00007d20d97d81c9  add rsp, 0x30
00007d20d97d81cd  vmovaps xmm0, [rsp]
00007d20d97d81d2  vmovaps xmm1, [rsp+0x10]
00007d20d97d81d8  vmovaps xmm2, [rsp+0x20]
00007d20d97d81de  vmovaps xmm3, [rsp+0x30]
00007d20d97d81e4  vmovaps xmm5, [rsp+0x40]
00007d20d97d81ea  vmovaps xmm6, [rsp+0x50]
00007d20d97d81f0  vmovaps xmm7, [rsp+0x60]
00007d20d97d81f6  vmovaps xmm8, [rsp+0x70]
00007d20d97d81fc  vmovaps xmm9, [rsp+0x80]
00007d20d97d8205  vmovaps xmm10, [rsp+0x90]
00007d20d97d820e  vmovaps xmm11, [rsp+0xA0]
00007d20d97d8217  vmovaps xmm12, [rsp+0xB0]
00007d20d97d8220  vmovaps xmm13, [rsp+0xC0]
00007d20d97d8229  vmovaps xmm14, [rsp+0xD0]
00007d20d97d8232  vmovaps xmm15, [rsp+0xE0]
00007d20d97d823b  add rsp, 0xF0
00007d20d97d8242  pop r11
00007d20d97d8244  pop r10
00007d20d97d8246  pop r9
00007d20d97d8248  pop r8
00007d20d97d824a  pop rsi
00007d20d97d824b  pop rdi
00007d20d97d824c  pop rdx
00007d20d97d824d  pop rcx
00007d20d97d824e  pop rax
00007d20d97d824f  add rsp, 0x08
00007d20d97d8253  jmp 0x00007D20D97D5F54
00007d20d97d8258  call 0x00007D20D96D64F0
00007d20d97d825d  jmp 0x00007D20D97D5F61
00007d20d97d8262  sub rsp, 0x08
00007d20d97d8266  push rax
00007d20d97d8267  push rcx
00007d20d97d8268  push rdx
00007d20d97d8269  push rdi
00007d20d97d826a  push rsi
00007d20d97d826b  push r8
00007d20d97d826d  push r9
00007d20d97d826f  push r10
00007d20d97d8271  push r11
00007d20d97d8273  sub rsp, 0xF0
00007d20d97d827a  vmovaps [rsp], xmm0
00007d20d97d827f  vmovaps [rsp+0x10], xmm1
00007d20d97d8285  vmovaps [rsp+0x20], xmm2
00007d20d97d828b  vmovaps [rsp+0x30], xmm3
00007d20d97d8291  vmovaps [rsp+0x40], xmm4
00007d20d97d8297  vmovaps [rsp+0x50], xmm6
00007d20d97d829d  vmovaps [rsp+0x60], xmm7
00007d20d97d82a3  vmovaps [rsp+0x70], xmm8
00007d20d97d82a9  vmovaps [rsp+0x80], xmm9
00007d20d97d82b2  vmovaps [rsp+0x90], xmm10
00007d20d97d82bb  vmovaps [rsp+0xA0], xmm11
00007d20d97d82c4  vmovaps [rsp+0xB0], xmm12
00007d20d97d82cd  vmovaps [rsp+0xC0], xmm13
00007d20d97d82d6  vmovaps [rsp+0xD0], xmm14
00007d20d97d82df  vmovaps [rsp+0xE0], xmm15
00007d20d97d82e8  sub rsp, 0x30
00007d20d97d82ec  movaps [rsp], xmm5
00007d20d97d82f0  movaps [rsp+0x10], xmm6
00007d20d97d82f5  movaps [rsp+0x20], xmm3
00007d20d97d82fa  lea rdi, [rsp]
00007d20d97d82fe  mov esi, 0x00
00007d20d97d8303  mov rax, 0x5EFBF4CF6530
00007d20d97d830d  call rax
00007d20d97d830f  movaps xmm5, [rsp]
00007d20d97d8313  add rsp, 0x30
00007d20d97d8317  vmovaps xmm0, [rsp]
00007d20d97d831c  vmovaps xmm1, [rsp+0x10]
00007d20d97d8322  vmovaps xmm2, [rsp+0x20]
00007d20d97d8328  vmovaps xmm3, [rsp+0x30]
00007d20d97d832e  vmovaps xmm4, [rsp+0x40]
00007d20d97d8334  vmovaps xmm6, [rsp+0x50]
00007d20d97d833a  vmovaps xmm7, [rsp+0x60]
00007d20d97d8340  vmovaps xmm8, [rsp+0x70]
00007d20d97d8346  vmovaps xmm9, [rsp+0x80]
00007d20d97d834f  vmovaps xmm10, [rsp+0x90]
00007d20d97d8358  vmovaps xmm11, [rsp+0xA0]
00007d20d97d8361  vmovaps xmm12, [rsp+0xB0]
00007d20d97d836a  vmovaps xmm13, [rsp+0xC0]
00007d20d97d8373  vmovaps xmm14, [rsp+0xD0]
00007d20d97d837c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d8385  add rsp, 0xF0
00007d20d97d838c  pop r11
00007d20d97d838e  pop r10
00007d20d97d8390  pop r9
00007d20d97d8392  pop r8
00007d20d97d8394  pop rsi
00007d20d97d8395  pop rdi
00007d20d97d8396  pop rdx
00007d20d97d8397  pop rcx
00007d20d97d8398  pop rax
00007d20d97d8399  add rsp, 0x08
00007d20d97d839d  jmp 0x00007D20D97D5F87
00007d20d97d83a2  sub rsp, 0x08
00007d20d97d83a6  push rax
00007d20d97d83a7  push rcx
00007d20d97d83a8  push rdx
00007d20d97d83a9  push rdi
00007d20d97d83aa  push rsi
00007d20d97d83ab  push r8
00007d20d97d83ad  push r9
00007d20d97d83af  push r10
00007d20d97d83b1  push r11
00007d20d97d83b3  sub rsp, 0xF0
00007d20d97d83ba  vmovaps [rsp], xmm0
00007d20d97d83bf  vmovaps [rsp+0x10], xmm1
00007d20d97d83c5  vmovaps [rsp+0x20], xmm2
00007d20d97d83cb  vmovaps [rsp+0x30], xmm3
00007d20d97d83d1  vmovaps [rsp+0x40], xmm4
00007d20d97d83d7  vmovaps [rsp+0x50], xmm5
00007d20d97d83dd  vmovaps [rsp+0x60], xmm7
00007d20d97d83e3  vmovaps [rsp+0x70], xmm8
00007d20d97d83e9  vmovaps [rsp+0x80], xmm9
00007d20d97d83f2  vmovaps [rsp+0x90], xmm10
00007d20d97d83fb  vmovaps [rsp+0xA0], xmm11
00007d20d97d8404  vmovaps [rsp+0xB0], xmm12
00007d20d97d840d  vmovaps [rsp+0xC0], xmm13
00007d20d97d8416  vmovaps [rsp+0xD0], xmm14
00007d20d97d841f  vmovaps [rsp+0xE0], xmm15
00007d20d97d8428  sub rsp, 0x30
00007d20d97d842c  movaps [rsp], xmm6
00007d20d97d8430  movaps [rsp+0x10], xmm9
00007d20d97d8436  movaps [rsp+0x20], xmm1
00007d20d97d843b  lea rdi, [rsp]
00007d20d97d843f  mov esi, 0x00
00007d20d97d8444  mov rax, 0x5EFBF4CF6530
00007d20d97d844e  call rax
00007d20d97d8450  movaps xmm6, [rsp]
00007d20d97d8454  add rsp, 0x30
00007d20d97d8458  vmovaps xmm0, [rsp]
00007d20d97d845d  vmovaps xmm1, [rsp+0x10]
00007d20d97d8463  vmovaps xmm2, [rsp+0x20]
00007d20d97d8469  vmovaps xmm3, [rsp+0x30]
00007d20d97d846f  vmovaps xmm4, [rsp+0x40]
00007d20d97d8475  vmovaps xmm5, [rsp+0x50]
00007d20d97d847b  vmovaps xmm7, [rsp+0x60]
00007d20d97d8481  vmovaps xmm8, [rsp+0x70]
00007d20d97d8487  vmovaps xmm9, [rsp+0x80]
00007d20d97d8490  vmovaps xmm10, [rsp+0x90]
00007d20d97d8499  vmovaps xmm11, [rsp+0xA0]
00007d20d97d84a2  vmovaps xmm12, [rsp+0xB0]
00007d20d97d84ab  vmovaps xmm13, [rsp+0xC0]
00007d20d97d84b4  vmovaps xmm14, [rsp+0xD0]
00007d20d97d84bd  vmovaps xmm15, [rsp+0xE0]
00007d20d97d84c6  add rsp, 0xF0
00007d20d97d84cd  pop r11
00007d20d97d84cf  pop r10
00007d20d97d84d1  pop r9
00007d20d97d84d3  pop r8
00007d20d97d84d5  pop rsi
00007d20d97d84d6  pop rdi
00007d20d97d84d7  pop rdx
00007d20d97d84d8  pop rcx
00007d20d97d84d9  pop rax
00007d20d97d84da  add rsp, 0x08
00007d20d97d84de  jmp 0x00007D20D97D5FAB
00007d20d97d84e3  sub rsp, 0x08
00007d20d97d84e7  push rax
00007d20d97d84e8  push rcx
00007d20d97d84e9  push rdx
00007d20d97d84ea  push rdi
00007d20d97d84eb  push rsi
00007d20d97d84ec  push r8
00007d20d97d84ee  push r9
00007d20d97d84f0  push r10
00007d20d97d84f2  push r11
00007d20d97d84f4  sub rsp, 0xF0
00007d20d97d84fb  vmovaps [rsp], xmm0
00007d20d97d8500  vmovaps [rsp+0x10], xmm1
00007d20d97d8506  vmovaps [rsp+0x20], xmm2
00007d20d97d850c  vmovaps [rsp+0x30], xmm3
00007d20d97d8512  vmovaps [rsp+0x40], xmm4
00007d20d97d8518  vmovaps [rsp+0x50], xmm5
00007d20d97d851e  vmovaps [rsp+0x60], xmm6
00007d20d97d8524  vmovaps [rsp+0x70], xmm7
00007d20d97d852a  vmovaps [rsp+0x80], xmm8
00007d20d97d8533  vmovaps [rsp+0x90], xmm10
00007d20d97d853c  vmovaps [rsp+0xA0], xmm11
00007d20d97d8545  vmovaps [rsp+0xB0], xmm12
00007d20d97d854e  vmovaps [rsp+0xC0], xmm13
00007d20d97d8557  vmovaps [rsp+0xD0], xmm14
00007d20d97d8560  vmovaps [rsp+0xE0], xmm15
00007d20d97d8569  sub rsp, 0x30
00007d20d97d856d  movaps [rsp], xmm9
00007d20d97d8572  movaps [rsp+0x10], xmm3
00007d20d97d8577  movaps [rsp+0x20], xmm1
00007d20d97d857c  lea rdi, [rsp]
00007d20d97d8580  mov esi, 0x00
00007d20d97d8585  mov rax, 0x5EFBF4CF6530
00007d20d97d858f  call rax
00007d20d97d8591  movaps xmm9, [rsp]
00007d20d97d8596  add rsp, 0x30
00007d20d97d859a  vmovaps xmm0, [rsp]
00007d20d97d859f  vmovaps xmm1, [rsp+0x10]
00007d20d97d85a5  vmovaps xmm2, [rsp+0x20]
00007d20d97d85ab  vmovaps xmm3, [rsp+0x30]
00007d20d97d85b1  vmovaps xmm4, [rsp+0x40]
00007d20d97d85b7  vmovaps xmm5, [rsp+0x50]
00007d20d97d85bd  vmovaps xmm6, [rsp+0x60]
00007d20d97d85c3  vmovaps xmm7, [rsp+0x70]
00007d20d97d85c9  vmovaps xmm8, [rsp+0x80]
00007d20d97d85d2  vmovaps xmm10, [rsp+0x90]
00007d20d97d85db  vmovaps xmm11, [rsp+0xA0]
00007d20d97d85e4  vmovaps xmm12, [rsp+0xB0]
00007d20d97d85ed  vmovaps xmm13, [rsp+0xC0]
00007d20d97d85f6  vmovaps xmm14, [rsp+0xD0]
00007d20d97d85ff  vmovaps xmm15, [rsp+0xE0]
00007d20d97d8608  add rsp, 0xF0
00007d20d97d860f  pop r11
00007d20d97d8611  pop r10
00007d20d97d8613  pop r9
00007d20d97d8615  pop r8
00007d20d97d8617  pop rsi
00007d20d97d8618  pop rdi
00007d20d97d8619  pop rdx
00007d20d97d861a  pop rcx
00007d20d97d861b  pop rax
00007d20d97d861c  add rsp, 0x08
00007d20d97d8620  jmp 0x00007D20D97D5FF7
00007d20d97d8625  call 0x00007D20D96D64F0
00007d20d97d862a  jmp 0x00007D20D97D6004
00007d20d97d862f  sub rsp, 0x08
00007d20d97d8633  push rax
00007d20d97d8634  push rcx
00007d20d97d8635  push rdx
00007d20d97d8636  push rdi
00007d20d97d8637  push rsi
00007d20d97d8638  push r8
00007d20d97d863a  push r9
00007d20d97d863c  push r10
00007d20d97d863e  push r11
00007d20d97d8640  sub rsp, 0xF0
00007d20d97d8647  vmovaps [rsp], xmm0
00007d20d97d864c  vmovaps [rsp+0x10], xmm1
00007d20d97d8652  vmovaps [rsp+0x20], xmm2
00007d20d97d8658  vmovaps [rsp+0x30], xmm3
00007d20d97d865e  vmovaps [rsp+0x40], xmm4
00007d20d97d8664  vmovaps [rsp+0x50], xmm5
00007d20d97d866a  vmovaps [rsp+0x60], xmm6
00007d20d97d8670  vmovaps [rsp+0x70], xmm7
00007d20d97d8676  vmovaps [rsp+0x80], xmm8
00007d20d97d867f  vmovaps [rsp+0x90], xmm9
00007d20d97d8688  vmovaps [rsp+0xA0], xmm10
00007d20d97d8691  vmovaps [rsp+0xB0], xmm11
00007d20d97d869a  vmovaps [rsp+0xC0], xmm12
00007d20d97d86a3  vmovaps [rsp+0xD0], xmm13
00007d20d97d86ac  vmovaps [rsp+0xE0], xmm14
00007d20d97d86b5  sub rsp, 0x30
00007d20d97d86b9  movaps [rsp], xmm15
00007d20d97d86be  movaps [rsp+0x10], xmm3
00007d20d97d86c3  movaps [rsp+0x20], xmm7
00007d20d97d86c8  lea rdi, [rsp]
00007d20d97d86cc  mov esi, 0x00
00007d20d97d86d1  mov rax, 0x5EFBF4CF6530
00007d20d97d86db  call rax
00007d20d97d86dd  movaps xmm15, [rsp]
00007d20d97d86e2  add rsp, 0x30
00007d20d97d86e6  vmovaps xmm0, [rsp]
00007d20d97d86eb  vmovaps xmm1, [rsp+0x10]
00007d20d97d86f1  vmovaps xmm2, [rsp+0x20]
00007d20d97d86f7  vmovaps xmm3, [rsp+0x30]
00007d20d97d86fd  vmovaps xmm4, [rsp+0x40]
00007d20d97d8703  vmovaps xmm5, [rsp+0x50]
00007d20d97d8709  vmovaps xmm6, [rsp+0x60]
00007d20d97d870f  vmovaps xmm7, [rsp+0x70]
00007d20d97d8715  vmovaps xmm8, [rsp+0x80]
00007d20d97d871e  vmovaps xmm9, [rsp+0x90]
00007d20d97d8727  vmovaps xmm10, [rsp+0xA0]
00007d20d97d8730  vmovaps xmm11, [rsp+0xB0]
00007d20d97d8739  vmovaps xmm12, [rsp+0xC0]
00007d20d97d8742  vmovaps xmm13, [rsp+0xD0]
00007d20d97d874b  vmovaps xmm14, [rsp+0xE0]
00007d20d97d8754  add rsp, 0xF0
00007d20d97d875b  pop r11
00007d20d97d875d  pop r10
00007d20d97d875f  pop r9
00007d20d97d8761  pop r8
00007d20d97d8763  pop rsi
00007d20d97d8764  pop rdi
00007d20d97d8765  pop rdx
00007d20d97d8766  pop rcx
00007d20d97d8767  pop rax
00007d20d97d8768  add rsp, 0x08
00007d20d97d876c  jmp 0x00007D20D97D6030
00007d20d97d8771  sub rsp, 0x08
00007d20d97d8775  push rax
00007d20d97d8776  push rcx
00007d20d97d8777  push rdx
00007d20d97d8778  push rdi
00007d20d97d8779  push rsi
00007d20d97d877a  push r8
00007d20d97d877c  push r9
00007d20d97d877e  push r10
00007d20d97d8780  push r11
00007d20d97d8782  sub rsp, 0xF0
00007d20d97d8789  vmovaps [rsp], xmm0
00007d20d97d878e  vmovaps [rsp+0x10], xmm1
00007d20d97d8794  vmovaps [rsp+0x20], xmm2
00007d20d97d879a  vmovaps [rsp+0x30], xmm4
00007d20d97d87a0  vmovaps [rsp+0x40], xmm5
00007d20d97d87a6  vmovaps [rsp+0x50], xmm6
00007d20d97d87ac  vmovaps [rsp+0x60], xmm7
00007d20d97d87b2  vmovaps [rsp+0x70], xmm8
00007d20d97d87b8  vmovaps [rsp+0x80], xmm9
00007d20d97d87c1  vmovaps [rsp+0x90], xmm10
00007d20d97d87ca  vmovaps [rsp+0xA0], xmm11
00007d20d97d87d3  vmovaps [rsp+0xB0], xmm12
00007d20d97d87dc  vmovaps [rsp+0xC0], xmm13
00007d20d97d87e5  vmovaps [rsp+0xD0], xmm14
00007d20d97d87ee  vmovaps [rsp+0xE0], xmm15
00007d20d97d87f7  sub rsp, 0x30
00007d20d97d87fb  movaps [rsp], xmm3
00007d20d97d87ff  movaps [rsp+0x10], xmm1
00007d20d97d8804  movaps [rsp+0x20], xmm15
00007d20d97d880a  lea rdi, [rsp]
00007d20d97d880e  mov esi, 0x00
00007d20d97d8813  mov rax, 0x5EFBF4CF6530
00007d20d97d881d  call rax
00007d20d97d881f  movaps xmm3, [rsp]
00007d20d97d8823  add rsp, 0x30
00007d20d97d8827  vmovaps xmm0, [rsp]
00007d20d97d882c  vmovaps xmm1, [rsp+0x10]
00007d20d97d8832  vmovaps xmm2, [rsp+0x20]
00007d20d97d8838  vmovaps xmm4, [rsp+0x30]
00007d20d97d883e  vmovaps xmm5, [rsp+0x40]
00007d20d97d8844  vmovaps xmm6, [rsp+0x50]
00007d20d97d884a  vmovaps xmm7, [rsp+0x60]
00007d20d97d8850  vmovaps xmm8, [rsp+0x70]
00007d20d97d8856  vmovaps xmm9, [rsp+0x80]
00007d20d97d885f  vmovaps xmm10, [rsp+0x90]
00007d20d97d8868  vmovaps xmm11, [rsp+0xA0]
00007d20d97d8871  vmovaps xmm12, [rsp+0xB0]
00007d20d97d887a  vmovaps xmm13, [rsp+0xC0]
00007d20d97d8883  vmovaps xmm14, [rsp+0xD0]
00007d20d97d888c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d8895  add rsp, 0xF0
00007d20d97d889c  pop r11
00007d20d97d889e  pop r10
00007d20d97d88a0  pop r9
00007d20d97d88a2  pop r8
00007d20d97d88a4  pop rsi
00007d20d97d88a5  pop rdi
00007d20d97d88a6  pop rdx
00007d20d97d88a7  pop rcx
00007d20d97d88a8  pop rax
00007d20d97d88a9  add rsp, 0x08
00007d20d97d88ad  jmp 0x00007D20D97D60BF
00007d20d97d88b2  call 0x00007D20D96D64F0
00007d20d97d88b7  jmp 0x00007D20D97D60C9
00007d20d97d88bc  sub rsp, 0x08
00007d20d97d88c0  push rax
00007d20d97d88c1  push rcx
00007d20d97d88c2  push rdx
00007d20d97d88c3  push rdi
00007d20d97d88c4  push rsi
00007d20d97d88c5  push r8
00007d20d97d88c7  push r9
00007d20d97d88c9  push r10
00007d20d97d88cb  push r11
00007d20d97d88cd  sub rsp, 0xF0
00007d20d97d88d4  vmovaps [rsp], xmm0
00007d20d97d88d9  vmovaps [rsp+0x10], xmm1
00007d20d97d88df  vmovaps [rsp+0x20], xmm2
00007d20d97d88e5  vmovaps [rsp+0x30], xmm3
00007d20d97d88eb  vmovaps [rsp+0x40], xmm4
00007d20d97d88f1  vmovaps [rsp+0x50], xmm5
00007d20d97d88f7  vmovaps [rsp+0x60], xmm6
00007d20d97d88fd  vmovaps [rsp+0x70], xmm7
00007d20d97d8903  vmovaps [rsp+0x80], xmm8
00007d20d97d890c  vmovaps [rsp+0x90], xmm9
00007d20d97d8915  vmovaps [rsp+0xA0], xmm10
00007d20d97d891e  vmovaps [rsp+0xB0], xmm11
00007d20d97d8927  vmovaps [rsp+0xC0], xmm12
00007d20d97d8930  vmovaps [rsp+0xD0], xmm13
00007d20d97d8939  vmovaps [rsp+0xE0], xmm14
00007d20d97d8942  sub rsp, 0x30
00007d20d97d8946  movaps [rsp], xmm15
00007d20d97d894b  movaps [rsp+0x10], xmm14
00007d20d97d8951  movaps [rsp+0x20], xmm4
00007d20d97d8956  lea rdi, [rsp]
00007d20d97d895a  mov esi, 0x00
00007d20d97d895f  mov rax, 0x5EFBF4CF6530
00007d20d97d8969  call rax
00007d20d97d896b  movaps xmm15, [rsp]
00007d20d97d8970  add rsp, 0x30
00007d20d97d8974  vmovaps xmm0, [rsp]
00007d20d97d8979  vmovaps xmm1, [rsp+0x10]
00007d20d97d897f  vmovaps xmm2, [rsp+0x20]
00007d20d97d8985  vmovaps xmm3, [rsp+0x30]
00007d20d97d898b  vmovaps xmm4, [rsp+0x40]
00007d20d97d8991  vmovaps xmm5, [rsp+0x50]
00007d20d97d8997  vmovaps xmm6, [rsp+0x60]
00007d20d97d899d  vmovaps xmm7, [rsp+0x70]
00007d20d97d89a3  vmovaps xmm8, [rsp+0x80]
00007d20d97d89ac  vmovaps xmm9, [rsp+0x90]
00007d20d97d89b5  vmovaps xmm10, [rsp+0xA0]
00007d20d97d89be  vmovaps xmm11, [rsp+0xB0]
00007d20d97d89c7  vmovaps xmm12, [rsp+0xC0]
00007d20d97d89d0  vmovaps xmm13, [rsp+0xD0]
00007d20d97d89d9  vmovaps xmm14, [rsp+0xE0]
00007d20d97d89e2  add rsp, 0xF0
00007d20d97d89e9  pop r11
00007d20d97d89eb  pop r10
00007d20d97d89ed  pop r9
00007d20d97d89ef  pop r8
00007d20d97d89f1  pop rsi
00007d20d97d89f2  pop rdi
00007d20d97d89f3  pop rdx
00007d20d97d89f4  pop rcx
00007d20d97d89f5  pop rax
00007d20d97d89f6  add rsp, 0x08
00007d20d97d89fa  jmp 0x00007D20D97D60F7
00007d20d97d89ff  sub rsp, 0x08
00007d20d97d8a03  push rax
00007d20d97d8a04  push rcx
00007d20d97d8a05  push rdx
00007d20d97d8a06  push rdi
00007d20d97d8a07  push rsi
00007d20d97d8a08  push r8
00007d20d97d8a0a  push r9
00007d20d97d8a0c  push r10
00007d20d97d8a0e  push r11
00007d20d97d8a10  sub rsp, 0xF0
00007d20d97d8a17  vmovaps [rsp], xmm0
00007d20d97d8a1c  vmovaps [rsp+0x10], xmm1
00007d20d97d8a22  vmovaps [rsp+0x20], xmm2
00007d20d97d8a28  vmovaps [rsp+0x30], xmm3
00007d20d97d8a2e  vmovaps [rsp+0x40], xmm4
00007d20d97d8a34  vmovaps [rsp+0x50], xmm5
00007d20d97d8a3a  vmovaps [rsp+0x60], xmm6
00007d20d97d8a40  vmovaps [rsp+0x70], xmm7
00007d20d97d8a46  vmovaps [rsp+0x80], xmm8
00007d20d97d8a4f  vmovaps [rsp+0x90], xmm9
00007d20d97d8a58  vmovaps [rsp+0xA0], xmm10
00007d20d97d8a61  vmovaps [rsp+0xB0], xmm11
00007d20d97d8a6a  vmovaps [rsp+0xC0], xmm12
00007d20d97d8a73  vmovaps [rsp+0xD0], xmm13
00007d20d97d8a7c  vmovaps [rsp+0xE0], xmm15
00007d20d97d8a85  sub rsp, 0x30
00007d20d97d8a89  movaps [rsp], xmm14
00007d20d97d8a8e  movaps [rsp+0x10], xmm2
00007d20d97d8a93  movaps [rsp+0x20], xmm1
00007d20d97d8a98  lea rdi, [rsp]
00007d20d97d8a9c  mov esi, 0x00
00007d20d97d8aa1  mov rax, 0x5EFBF4CF6530
00007d20d97d8aab  call rax
00007d20d97d8aad  movaps xmm14, [rsp]
00007d20d97d8ab2  add rsp, 0x30
00007d20d97d8ab6  vmovaps xmm0, [rsp]
00007d20d97d8abb  vmovaps xmm1, [rsp+0x10]
00007d20d97d8ac1  vmovaps xmm2, [rsp+0x20]
00007d20d97d8ac7  vmovaps xmm3, [rsp+0x30]
00007d20d97d8acd  vmovaps xmm4, [rsp+0x40]
00007d20d97d8ad3  vmovaps xmm5, [rsp+0x50]
00007d20d97d8ad9  vmovaps xmm6, [rsp+0x60]
00007d20d97d8adf  vmovaps xmm7, [rsp+0x70]
00007d20d97d8ae5  vmovaps xmm8, [rsp+0x80]
00007d20d97d8aee  vmovaps xmm9, [rsp+0x90]
00007d20d97d8af7  vmovaps xmm10, [rsp+0xA0]
00007d20d97d8b00  vmovaps xmm11, [rsp+0xB0]
00007d20d97d8b09  vmovaps xmm12, [rsp+0xC0]
00007d20d97d8b12  vmovaps xmm13, [rsp+0xD0]
00007d20d97d8b1b  vmovaps xmm15, [rsp+0xE0]
00007d20d97d8b24  add rsp, 0xF0
00007d20d97d8b2b  pop r11
00007d20d97d8b2d  pop r10
00007d20d97d8b2f  pop r9
00007d20d97d8b31  pop r8
00007d20d97d8b33  pop rsi
00007d20d97d8b34  pop rdi
00007d20d97d8b35  pop rdx
00007d20d97d8b36  pop rcx
00007d20d97d8b37  pop rax
00007d20d97d8b38  add rsp, 0x08
00007d20d97d8b3c  jmp 0x00007D20D97D611D
00007d20d97d8b41  sub rsp, 0x08
00007d20d97d8b45  push rax
00007d20d97d8b46  push rcx
00007d20d97d8b47  push rdx
00007d20d97d8b48  push rdi
00007d20d97d8b49  push rsi
00007d20d97d8b4a  push r8
00007d20d97d8b4c  push r9
00007d20d97d8b4e  push r10
00007d20d97d8b50  push r11
00007d20d97d8b52  sub rsp, 0xF0
00007d20d97d8b59  vmovaps [rsp], xmm0
00007d20d97d8b5e  vmovaps [rsp+0x10], xmm2
00007d20d97d8b64  vmovaps [rsp+0x20], xmm3
00007d20d97d8b6a  vmovaps [rsp+0x30], xmm4
00007d20d97d8b70  vmovaps [rsp+0x40], xmm5
00007d20d97d8b76  vmovaps [rsp+0x50], xmm6
00007d20d97d8b7c  vmovaps [rsp+0x60], xmm7
00007d20d97d8b82  vmovaps [rsp+0x70], xmm8
00007d20d97d8b88  vmovaps [rsp+0x80], xmm9
00007d20d97d8b91  vmovaps [rsp+0x90], xmm10
00007d20d97d8b9a  vmovaps [rsp+0xA0], xmm11
00007d20d97d8ba3  vmovaps [rsp+0xB0], xmm12
00007d20d97d8bac  vmovaps [rsp+0xC0], xmm13
00007d20d97d8bb5  vmovaps [rsp+0xD0], xmm14
00007d20d97d8bbe  vmovaps [rsp+0xE0], xmm15
00007d20d97d8bc7  sub rsp, 0x30
00007d20d97d8bcb  movaps [rsp], xmm1
00007d20d97d8bcf  movaps [rsp+0x10], xmm4
00007d20d97d8bd4  movaps [rsp+0x20], xmm9
00007d20d97d8bda  lea rdi, [rsp]
00007d20d97d8bde  mov esi, 0x00
00007d20d97d8be3  mov rax, 0x5EFBF4CF6530
00007d20d97d8bed  call rax
00007d20d97d8bef  movaps xmm1, [rsp]
00007d20d97d8bf3  add rsp, 0x30
00007d20d97d8bf7  vmovaps xmm0, [rsp]
00007d20d97d8bfc  vmovaps xmm2, [rsp+0x10]
00007d20d97d8c02  vmovaps xmm3, [rsp+0x20]
00007d20d97d8c08  vmovaps xmm4, [rsp+0x30]
00007d20d97d8c0e  vmovaps xmm5, [rsp+0x40]
00007d20d97d8c14  vmovaps xmm6, [rsp+0x50]
00007d20d97d8c1a  vmovaps xmm7, [rsp+0x60]
00007d20d97d8c20  vmovaps xmm8, [rsp+0x70]
00007d20d97d8c26  vmovaps xmm9, [rsp+0x80]
00007d20d97d8c2f  vmovaps xmm10, [rsp+0x90]
00007d20d97d8c38  vmovaps xmm11, [rsp+0xA0]
00007d20d97d8c41  vmovaps xmm12, [rsp+0xB0]
00007d20d97d8c4a  vmovaps xmm13, [rsp+0xC0]
00007d20d97d8c53  vmovaps xmm14, [rsp+0xD0]
00007d20d97d8c5c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d8c65  add rsp, 0xF0
00007d20d97d8c6c  pop r11
00007d20d97d8c6e  pop r10
00007d20d97d8c70  pop r9
00007d20d97d8c72  pop r8
00007d20d97d8c74  pop rsi
00007d20d97d8c75  pop rdi
00007d20d97d8c76  pop rdx
00007d20d97d8c77  pop rcx
00007d20d97d8c78  pop rax
00007d20d97d8c79  add rsp, 0x08
00007d20d97d8c7d  jmp 0x00007D20D97D613B
00007d20d97d8c82  sub rsp, 0x08
00007d20d97d8c86  push rax
00007d20d97d8c87  push rcx
00007d20d97d8c88  push rdx
00007d20d97d8c89  push rdi
00007d20d97d8c8a  push rsi
00007d20d97d8c8b  push r8
00007d20d97d8c8d  push r9
00007d20d97d8c8f  push r10
00007d20d97d8c91  push r11
00007d20d97d8c93  sub rsp, 0xF0
00007d20d97d8c9a  vmovaps [rsp], xmm0
00007d20d97d8c9f  vmovaps [rsp+0x10], xmm1
00007d20d97d8ca5  vmovaps [rsp+0x20], xmm2
00007d20d97d8cab  vmovaps [rsp+0x30], xmm3
00007d20d97d8cb1  vmovaps [rsp+0x40], xmm5
00007d20d97d8cb7  vmovaps [rsp+0x50], xmm6
00007d20d97d8cbd  vmovaps [rsp+0x60], xmm7
00007d20d97d8cc3  vmovaps [rsp+0x70], xmm8
00007d20d97d8cc9  vmovaps [rsp+0x80], xmm9
00007d20d97d8cd2  vmovaps [rsp+0x90], xmm10
00007d20d97d8cdb  vmovaps [rsp+0xA0], xmm11
00007d20d97d8ce4  vmovaps [rsp+0xB0], xmm12
00007d20d97d8ced  vmovaps [rsp+0xC0], xmm13
00007d20d97d8cf6  vmovaps [rsp+0xD0], xmm14
00007d20d97d8cff  vmovaps [rsp+0xE0], xmm15
00007d20d97d8d08  sub rsp, 0x30
00007d20d97d8d0c  movaps [rsp], xmm4
00007d20d97d8d10  movaps [rsp+0x10], xmm2
00007d20d97d8d15  movaps [rsp+0x20], xmm9
00007d20d97d8d1b  lea rdi, [rsp]
00007d20d97d8d1f  mov esi, 0x00
00007d20d97d8d24  mov rax, 0x5EFBF4CF6530
00007d20d97d8d2e  call rax
00007d20d97d8d30  movaps xmm4, [rsp]
00007d20d97d8d34  add rsp, 0x30
00007d20d97d8d38  vmovaps xmm0, [rsp]
00007d20d97d8d3d  vmovaps xmm1, [rsp+0x10]
00007d20d97d8d43  vmovaps xmm2, [rsp+0x20]
00007d20d97d8d49  vmovaps xmm3, [rsp+0x30]
00007d20d97d8d4f  vmovaps xmm5, [rsp+0x40]
00007d20d97d8d55  vmovaps xmm6, [rsp+0x50]
00007d20d97d8d5b  vmovaps xmm7, [rsp+0x60]
00007d20d97d8d61  vmovaps xmm8, [rsp+0x70]
00007d20d97d8d67  vmovaps xmm9, [rsp+0x80]
00007d20d97d8d70  vmovaps xmm10, [rsp+0x90]
00007d20d97d8d79  vmovaps xmm11, [rsp+0xA0]
00007d20d97d8d82  vmovaps xmm12, [rsp+0xB0]
00007d20d97d8d8b  vmovaps xmm13, [rsp+0xC0]
00007d20d97d8d94  vmovaps xmm14, [rsp+0xD0]
00007d20d97d8d9d  vmovaps xmm15, [rsp+0xE0]
00007d20d97d8da6  add rsp, 0xF0
00007d20d97d8dad  pop r11
00007d20d97d8daf  pop r10
00007d20d97d8db1  pop r9
00007d20d97d8db3  pop r8
00007d20d97d8db5  pop rsi
00007d20d97d8db6  pop rdi
00007d20d97d8db7  pop rdx
00007d20d97d8db8  pop rcx
00007d20d97d8db9  pop rax
00007d20d97d8dba  add rsp, 0x08
00007d20d97d8dbe  jmp 0x00007D20D97D616B
00007d20d97d8dc3  sub rsp, 0x08
00007d20d97d8dc7  push rax
00007d20d97d8dc8  push rcx
00007d20d97d8dc9  push rdx
00007d20d97d8dca  push rdi
00007d20d97d8dcb  push rsi
00007d20d97d8dcc  push r8
00007d20d97d8dce  push r9
00007d20d97d8dd0  push r10
00007d20d97d8dd2  push r11
00007d20d97d8dd4  sub rsp, 0xF0
00007d20d97d8ddb  vmovaps [rsp], xmm0
00007d20d97d8de0  vmovaps [rsp+0x10], xmm1
00007d20d97d8de6  vmovaps [rsp+0x20], xmm2
00007d20d97d8dec  vmovaps [rsp+0x30], xmm3
00007d20d97d8df2  vmovaps [rsp+0x40], xmm4
00007d20d97d8df8  vmovaps [rsp+0x50], xmm5
00007d20d97d8dfe  vmovaps [rsp+0x60], xmm6
00007d20d97d8e04  vmovaps [rsp+0x70], xmm7
00007d20d97d8e0a  vmovaps [rsp+0x80], xmm8
00007d20d97d8e13  vmovaps [rsp+0x90], xmm10
00007d20d97d8e1c  vmovaps [rsp+0xA0], xmm11
00007d20d97d8e25  vmovaps [rsp+0xB0], xmm12
00007d20d97d8e2e  vmovaps [rsp+0xC0], xmm13
00007d20d97d8e37  vmovaps [rsp+0xD0], xmm14
00007d20d97d8e40  vmovaps [rsp+0xE0], xmm15
00007d20d97d8e49  sub rsp, 0x30
00007d20d97d8e4d  movaps [rsp], xmm9
00007d20d97d8e52  movaps [rsp+0x10], xmm2
00007d20d97d8e57  movaps [rsp+0x20], xmm1
00007d20d97d8e5c  lea rdi, [rsp]
00007d20d97d8e60  mov esi, 0x00
00007d20d97d8e65  mov rax, 0x5EFBF4CF6530
00007d20d97d8e6f  call rax
00007d20d97d8e71  movaps xmm9, [rsp]
00007d20d97d8e76  add rsp, 0x30
00007d20d97d8e7a  vmovaps xmm0, [rsp]
00007d20d97d8e7f  vmovaps xmm1, [rsp+0x10]
00007d20d97d8e85  vmovaps xmm2, [rsp+0x20]
00007d20d97d8e8b  vmovaps xmm3, [rsp+0x30]
00007d20d97d8e91  vmovaps xmm4, [rsp+0x40]
00007d20d97d8e97  vmovaps xmm5, [rsp+0x50]
00007d20d97d8e9d  vmovaps xmm6, [rsp+0x60]
00007d20d97d8ea3  vmovaps xmm7, [rsp+0x70]
00007d20d97d8ea9  vmovaps xmm8, [rsp+0x80]
00007d20d97d8eb2  vmovaps xmm10, [rsp+0x90]
00007d20d97d8ebb  vmovaps xmm11, [rsp+0xA0]
00007d20d97d8ec4  vmovaps xmm12, [rsp+0xB0]
00007d20d97d8ecd  vmovaps xmm13, [rsp+0xC0]
00007d20d97d8ed6  vmovaps xmm14, [rsp+0xD0]
00007d20d97d8edf  vmovaps xmm15, [rsp+0xE0]
00007d20d97d8ee8  add rsp, 0xF0
00007d20d97d8eef  pop r11
00007d20d97d8ef1  pop r10
00007d20d97d8ef3  pop r9
00007d20d97d8ef5  pop r8
00007d20d97d8ef7  pop rsi
00007d20d97d8ef8  pop rdi
00007d20d97d8ef9  pop rdx
00007d20d97d8efa  pop rcx
00007d20d97d8efb  pop rax
00007d20d97d8efc  add rsp, 0x08
00007d20d97d8f00  jmp 0x00007D20D97D61A1
00007d20d97d8f05  sub rsp, 0x08
00007d20d97d8f09  push rax
00007d20d97d8f0a  push rcx
00007d20d97d8f0b  push rdx
00007d20d97d8f0c  push rdi
00007d20d97d8f0d  push rsi
00007d20d97d8f0e  push r8
00007d20d97d8f10  push r9
00007d20d97d8f12  push r10
00007d20d97d8f14  push r11
00007d20d97d8f16  sub rsp, 0xF0
00007d20d97d8f1d  vmovaps [rsp], xmm0
00007d20d97d8f22  vmovaps [rsp+0x10], xmm2
00007d20d97d8f28  vmovaps [rsp+0x20], xmm3
00007d20d97d8f2e  vmovaps [rsp+0x30], xmm4
00007d20d97d8f34  vmovaps [rsp+0x40], xmm5
00007d20d97d8f3a  vmovaps [rsp+0x50], xmm6
00007d20d97d8f40  vmovaps [rsp+0x60], xmm7
00007d20d97d8f46  vmovaps [rsp+0x70], xmm8
00007d20d97d8f4c  vmovaps [rsp+0x80], xmm9
00007d20d97d8f55  vmovaps [rsp+0x90], xmm10
00007d20d97d8f5e  vmovaps [rsp+0xA0], xmm11
00007d20d97d8f67  vmovaps [rsp+0xB0], xmm12
00007d20d97d8f70  vmovaps [rsp+0xC0], xmm13
00007d20d97d8f79  vmovaps [rsp+0xD0], xmm14
00007d20d97d8f82  vmovaps [rsp+0xE0], xmm15
00007d20d97d8f8b  sub rsp, 0x30
00007d20d97d8f8f  movaps [rsp], xmm1
00007d20d97d8f93  movaps [rsp+0x10], xmm15
00007d20d97d8f99  movaps [rsp+0x20], xmm6
00007d20d97d8f9e  lea rdi, [rsp]
00007d20d97d8fa2  mov esi, 0x00
00007d20d97d8fa7  mov rax, 0x5EFBF4CF6530
00007d20d97d8fb1  call rax
00007d20d97d8fb3  movaps xmm1, [rsp]
00007d20d97d8fb7  add rsp, 0x30
00007d20d97d8fbb  vmovaps xmm0, [rsp]
00007d20d97d8fc0  vmovaps xmm2, [rsp+0x10]
00007d20d97d8fc6  vmovaps xmm3, [rsp+0x20]
00007d20d97d8fcc  vmovaps xmm4, [rsp+0x30]
00007d20d97d8fd2  vmovaps xmm5, [rsp+0x40]
00007d20d97d8fd8  vmovaps xmm6, [rsp+0x50]
00007d20d97d8fde  vmovaps xmm7, [rsp+0x60]
00007d20d97d8fe4  vmovaps xmm8, [rsp+0x70]
00007d20d97d8fea  vmovaps xmm9, [rsp+0x80]
00007d20d97d8ff3  vmovaps xmm10, [rsp+0x90]
00007d20d97d8ffc  vmovaps xmm11, [rsp+0xA0]
00007d20d97d9005  vmovaps xmm12, [rsp+0xB0]
00007d20d97d900e  vmovaps xmm13, [rsp+0xC0]
00007d20d97d9017  vmovaps xmm14, [rsp+0xD0]
00007d20d97d9020  vmovaps xmm15, [rsp+0xE0]
00007d20d97d9029  add rsp, 0xF0
00007d20d97d9030  pop r11
00007d20d97d9032  pop r10
00007d20d97d9034  pop r9
00007d20d97d9036  pop r8
00007d20d97d9038  pop rsi
00007d20d97d9039  pop rdi
00007d20d97d903a  pop rdx
00007d20d97d903b  pop rcx
00007d20d97d903c  pop rax
00007d20d97d903d  add rsp, 0x08
00007d20d97d9041  jmp 0x00007D20D97D61C2
00007d20d97d9046  sub rsp, 0x08
00007d20d97d904a  push rax
00007d20d97d904b  push rcx
00007d20d97d904c  push rdx
00007d20d97d904d  push rdi
00007d20d97d904e  push rsi
00007d20d97d904f  push r8
00007d20d97d9051  push r9
00007d20d97d9053  push r10
00007d20d97d9055  push r11
00007d20d97d9057  sub rsp, 0xF0
00007d20d97d905e  vmovaps [rsp], xmm0
00007d20d97d9063  vmovaps [rsp+0x10], xmm1
00007d20d97d9069  vmovaps [rsp+0x20], xmm2
00007d20d97d906f  vmovaps [rsp+0x30], xmm3
00007d20d97d9075  vmovaps [rsp+0x40], xmm4
00007d20d97d907b  vmovaps [rsp+0x50], xmm5
00007d20d97d9081  vmovaps [rsp+0x60], xmm6
00007d20d97d9087  vmovaps [rsp+0x70], xmm7
00007d20d97d908d  vmovaps [rsp+0x80], xmm8
00007d20d97d9096  vmovaps [rsp+0x90], xmm9
00007d20d97d909f  vmovaps [rsp+0xA0], xmm10
00007d20d97d90a8  vmovaps [rsp+0xB0], xmm11
00007d20d97d90b1  vmovaps [rsp+0xC0], xmm12
00007d20d97d90ba  vmovaps [rsp+0xD0], xmm13
00007d20d97d90c3  vmovaps [rsp+0xE0], xmm14
00007d20d97d90cc  sub rsp, 0x30
00007d20d97d90d0  movaps [rsp], xmm15
00007d20d97d90d5  movaps [rsp+0x10], xmm5
00007d20d97d90da  movaps [rsp+0x20], xmm3
00007d20d97d90df  lea rdi, [rsp]
00007d20d97d90e3  mov esi, 0x00
00007d20d97d90e8  mov rax, 0x5EFBF4CF6530
00007d20d97d90f2  call rax
00007d20d97d90f4  movaps xmm15, [rsp]
00007d20d97d90f9  add rsp, 0x30
00007d20d97d90fd  vmovaps xmm0, [rsp]
00007d20d97d9102  vmovaps xmm1, [rsp+0x10]
00007d20d97d9108  vmovaps xmm2, [rsp+0x20]
00007d20d97d910e  vmovaps xmm3, [rsp+0x30]
00007d20d97d9114  vmovaps xmm4, [rsp+0x40]
00007d20d97d911a  vmovaps xmm5, [rsp+0x50]
00007d20d97d9120  vmovaps xmm6, [rsp+0x60]
00007d20d97d9126  vmovaps xmm7, [rsp+0x70]
00007d20d97d912c  vmovaps xmm8, [rsp+0x80]
00007d20d97d9135  vmovaps xmm9, [rsp+0x90]
00007d20d97d913e  vmovaps xmm10, [rsp+0xA0]
00007d20d97d9147  vmovaps xmm11, [rsp+0xB0]
00007d20d97d9150  vmovaps xmm12, [rsp+0xC0]
00007d20d97d9159  vmovaps xmm13, [rsp+0xD0]
00007d20d97d9162  vmovaps xmm14, [rsp+0xE0]
00007d20d97d916b  add rsp, 0xF0
00007d20d97d9172  pop r11
00007d20d97d9174  pop r10
00007d20d97d9176  pop r9
00007d20d97d9178  pop r8
00007d20d97d917a  pop rsi
00007d20d97d917b  pop rdi
00007d20d97d917c  pop rdx
00007d20d97d917d  pop rcx
00007d20d97d917e  pop rax
00007d20d97d917f  add rsp, 0x08
00007d20d97d9183  jmp 0x00007D20D97D61DC
00007d20d97d9188  sub rsp, 0x08
00007d20d97d918c  push rax
00007d20d97d918d  push rcx
00007d20d97d918e  push rdx
00007d20d97d918f  push rdi
00007d20d97d9190  push rsi
00007d20d97d9191  push r8
00007d20d97d9193  push r9
00007d20d97d9195  push r10
00007d20d97d9197  push r11
00007d20d97d9199  sub rsp, 0xF0
00007d20d97d91a0  vmovaps [rsp], xmm0
00007d20d97d91a5  vmovaps [rsp+0x10], xmm1
00007d20d97d91ab  vmovaps [rsp+0x20], xmm2
00007d20d97d91b1  vmovaps [rsp+0x30], xmm3
00007d20d97d91b7  vmovaps [rsp+0x40], xmm4
00007d20d97d91bd  vmovaps [rsp+0x50], xmm6
00007d20d97d91c3  vmovaps [rsp+0x60], xmm7
00007d20d97d91c9  vmovaps [rsp+0x70], xmm8
00007d20d97d91cf  vmovaps [rsp+0x80], xmm9
00007d20d97d91d8  vmovaps [rsp+0x90], xmm10
00007d20d97d91e1  vmovaps [rsp+0xA0], xmm11
00007d20d97d91ea  vmovaps [rsp+0xB0], xmm12
00007d20d97d91f3  vmovaps [rsp+0xC0], xmm13
00007d20d97d91fc  vmovaps [rsp+0xD0], xmm14
00007d20d97d9205  vmovaps [rsp+0xE0], xmm15
00007d20d97d920e  sub rsp, 0x30
00007d20d97d9212  movaps [rsp], xmm5
00007d20d97d9216  movaps [rsp+0x10], xmm8
00007d20d97d921c  movaps [rsp+0x20], xmm6
00007d20d97d9221  lea rdi, [rsp]
00007d20d97d9225  mov esi, 0x00
00007d20d97d922a  mov rax, 0x5EFBF4CF6530
00007d20d97d9234  call rax
00007d20d97d9236  movaps xmm5, [rsp]
00007d20d97d923a  add rsp, 0x30
00007d20d97d923e  vmovaps xmm0, [rsp]
00007d20d97d9243  vmovaps xmm1, [rsp+0x10]
00007d20d97d9249  vmovaps xmm2, [rsp+0x20]
00007d20d97d924f  vmovaps xmm3, [rsp+0x30]
00007d20d97d9255  vmovaps xmm4, [rsp+0x40]
00007d20d97d925b  vmovaps xmm6, [rsp+0x50]
00007d20d97d9261  vmovaps xmm7, [rsp+0x60]
00007d20d97d9267  vmovaps xmm8, [rsp+0x70]
00007d20d97d926d  vmovaps xmm9, [rsp+0x80]
00007d20d97d9276  vmovaps xmm10, [rsp+0x90]
00007d20d97d927f  vmovaps xmm11, [rsp+0xA0]
00007d20d97d9288  vmovaps xmm12, [rsp+0xB0]
00007d20d97d9291  vmovaps xmm13, [rsp+0xC0]
00007d20d97d929a  vmovaps xmm14, [rsp+0xD0]
00007d20d97d92a3  vmovaps xmm15, [rsp+0xE0]
00007d20d97d92ac  add rsp, 0xF0
00007d20d97d92b3  pop r11
00007d20d97d92b5  pop r10
00007d20d97d92b7  pop r9
00007d20d97d92b9  pop r8
00007d20d97d92bb  pop rsi
00007d20d97d92bc  pop rdi
00007d20d97d92bd  pop rdx
00007d20d97d92be  pop rcx
00007d20d97d92bf  pop rax
00007d20d97d92c0  add rsp, 0x08
00007d20d97d92c4  jmp 0x00007D20D97D6200
00007d20d97d92c9  sub rsp, 0x08
00007d20d97d92cd  push rax
00007d20d97d92ce  push rcx
00007d20d97d92cf  push rdx
00007d20d97d92d0  push rdi
00007d20d97d92d1  push rsi
00007d20d97d92d2  push r8
00007d20d97d92d4  push r9
00007d20d97d92d6  push r10
00007d20d97d92d8  push r11
00007d20d97d92da  sub rsp, 0xF0
00007d20d97d92e1  vmovaps [rsp], xmm0
00007d20d97d92e6  vmovaps [rsp+0x10], xmm1
00007d20d97d92ec  vmovaps [rsp+0x20], xmm2
00007d20d97d92f2  vmovaps [rsp+0x30], xmm3
00007d20d97d92f8  vmovaps [rsp+0x40], xmm4
00007d20d97d92fe  vmovaps [rsp+0x50], xmm5
00007d20d97d9304  vmovaps [rsp+0x60], xmm7
00007d20d97d930a  vmovaps [rsp+0x70], xmm8
00007d20d97d9310  vmovaps [rsp+0x80], xmm9
00007d20d97d9319  vmovaps [rsp+0x90], xmm10
00007d20d97d9322  vmovaps [rsp+0xA0], xmm11
00007d20d97d932b  vmovaps [rsp+0xB0], xmm12
00007d20d97d9334  vmovaps [rsp+0xC0], xmm13
00007d20d97d933d  vmovaps [rsp+0xD0], xmm14
00007d20d97d9346  vmovaps [rsp+0xE0], xmm15
00007d20d97d934f  sub rsp, 0x30
00007d20d97d9353  movaps [rsp], xmm6
00007d20d97d9357  movaps [rsp+0x10], xmm10
00007d20d97d935d  movaps [rsp+0x20], xmm8
00007d20d97d9363  lea rdi, [rsp]
00007d20d97d9367  mov esi, 0x00
00007d20d97d936c  mov rax, 0x5EFBF4CF6530
00007d20d97d9376  call rax
00007d20d97d9378  movaps xmm6, [rsp]
00007d20d97d937c  add rsp, 0x30
00007d20d97d9380  vmovaps xmm0, [rsp]
00007d20d97d9385  vmovaps xmm1, [rsp+0x10]
00007d20d97d938b  vmovaps xmm2, [rsp+0x20]
00007d20d97d9391  vmovaps xmm3, [rsp+0x30]
00007d20d97d9397  vmovaps xmm4, [rsp+0x40]
00007d20d97d939d  vmovaps xmm5, [rsp+0x50]
00007d20d97d93a3  vmovaps xmm7, [rsp+0x60]
00007d20d97d93a9  vmovaps xmm8, [rsp+0x70]
00007d20d97d93af  vmovaps xmm9, [rsp+0x80]
00007d20d97d93b8  vmovaps xmm10, [rsp+0x90]
00007d20d97d93c1  vmovaps xmm11, [rsp+0xA0]
00007d20d97d93ca  vmovaps xmm12, [rsp+0xB0]
00007d20d97d93d3  vmovaps xmm13, [rsp+0xC0]
00007d20d97d93dc  vmovaps xmm14, [rsp+0xD0]
00007d20d97d93e5  vmovaps xmm15, [rsp+0xE0]
00007d20d97d93ee  add rsp, 0xF0
00007d20d97d93f5  pop r11
00007d20d97d93f7  pop r10
00007d20d97d93f9  pop r9
00007d20d97d93fb  pop r8
00007d20d97d93fd  pop rsi
00007d20d97d93fe  pop rdi
00007d20d97d93ff  pop rdx
00007d20d97d9400  pop rcx
00007d20d97d9401  pop rax
00007d20d97d9402  add rsp, 0x08
00007d20d97d9406  jmp 0x00007D20D97D6225
00007d20d97d940b  sub rsp, 0x08
00007d20d97d940f  push rax
00007d20d97d9410  push rcx
00007d20d97d9411  push rdx
00007d20d97d9412  push rdi
00007d20d97d9413  push rsi
00007d20d97d9414  push r8
00007d20d97d9416  push r9
00007d20d97d9418  push r10
00007d20d97d941a  push r11
00007d20d97d941c  sub rsp, 0xF0
00007d20d97d9423  vmovaps [rsp], xmm0
00007d20d97d9428  vmovaps [rsp+0x10], xmm1
00007d20d97d942e  vmovaps [rsp+0x20], xmm2
00007d20d97d9434  vmovaps [rsp+0x30], xmm3
00007d20d97d943a  vmovaps [rsp+0x40], xmm4
00007d20d97d9440  vmovaps [rsp+0x50], xmm5
00007d20d97d9446  vmovaps [rsp+0x60], xmm6
00007d20d97d944c  vmovaps [rsp+0x70], xmm7
00007d20d97d9452  vmovaps [rsp+0x80], xmm8
00007d20d97d945b  vmovaps [rsp+0x90], xmm9
00007d20d97d9464  vmovaps [rsp+0xA0], xmm11
00007d20d97d946d  vmovaps [rsp+0xB0], xmm12
00007d20d97d9476  vmovaps [rsp+0xC0], xmm13
00007d20d97d947f  vmovaps [rsp+0xD0], xmm14
00007d20d97d9488  vmovaps [rsp+0xE0], xmm15
00007d20d97d9491  sub rsp, 0x30
00007d20d97d9495  movaps [rsp], xmm10
00007d20d97d949a  movaps [rsp+0x10], xmm8
00007d20d97d94a0  movaps [rsp+0x20], xmm14
00007d20d97d94a6  lea rdi, [rsp]
00007d20d97d94aa  mov esi, 0x00
00007d20d97d94af  mov rax, 0x5EFBF4CF6530
00007d20d97d94b9  call rax
00007d20d97d94bb  movaps xmm10, [rsp]
00007d20d97d94c0  add rsp, 0x30
00007d20d97d94c4  vmovaps xmm0, [rsp]
00007d20d97d94c9  vmovaps xmm1, [rsp+0x10]
00007d20d97d94cf  vmovaps xmm2, [rsp+0x20]
00007d20d97d94d5  vmovaps xmm3, [rsp+0x30]
00007d20d97d94db  vmovaps xmm4, [rsp+0x40]
00007d20d97d94e1  vmovaps xmm5, [rsp+0x50]
00007d20d97d94e7  vmovaps xmm6, [rsp+0x60]
00007d20d97d94ed  vmovaps xmm7, [rsp+0x70]
00007d20d97d94f3  vmovaps xmm8, [rsp+0x80]
00007d20d97d94fc  vmovaps xmm9, [rsp+0x90]
00007d20d97d9505  vmovaps xmm11, [rsp+0xA0]
00007d20d97d950e  vmovaps xmm12, [rsp+0xB0]
00007d20d97d9517  vmovaps xmm13, [rsp+0xC0]
00007d20d97d9520  vmovaps xmm14, [rsp+0xD0]
00007d20d97d9529  vmovaps xmm15, [rsp+0xE0]
00007d20d97d9532  add rsp, 0xF0
00007d20d97d9539  pop r11
00007d20d97d953b  pop r10
00007d20d97d953d  pop r9
00007d20d97d953f  pop r8
00007d20d97d9541  pop rsi
00007d20d97d9542  pop rdi
00007d20d97d9543  pop rdx
00007d20d97d9544  pop rcx
00007d20d97d9545  pop rax
00007d20d97d9546  add rsp, 0x08
00007d20d97d954a  jmp 0x00007D20D97D6245
00007d20d97d954f  sub rsp, 0x08
00007d20d97d9553  push rax
00007d20d97d9554  push rcx
00007d20d97d9555  push rdx
00007d20d97d9556  push rdi
00007d20d97d9557  push rsi
00007d20d97d9558  push r8
00007d20d97d955a  push r9
00007d20d97d955c  push r10
00007d20d97d955e  push r11
00007d20d97d9560  sub rsp, 0xF0
00007d20d97d9567  vmovaps [rsp], xmm0
00007d20d97d956c  vmovaps [rsp+0x10], xmm1
00007d20d97d9572  vmovaps [rsp+0x20], xmm2
00007d20d97d9578  vmovaps [rsp+0x30], xmm3
00007d20d97d957e  vmovaps [rsp+0x40], xmm4
00007d20d97d9584  vmovaps [rsp+0x50], xmm5
00007d20d97d958a  vmovaps [rsp+0x60], xmm6
00007d20d97d9590  vmovaps [rsp+0x70], xmm7
00007d20d97d9596  vmovaps [rsp+0x80], xmm8
00007d20d97d959f  vmovaps [rsp+0x90], xmm9
00007d20d97d95a8  vmovaps [rsp+0xA0], xmm10
00007d20d97d95b1  vmovaps [rsp+0xB0], xmm11
00007d20d97d95ba  vmovaps [rsp+0xC0], xmm12
00007d20d97d95c3  vmovaps [rsp+0xD0], xmm13
00007d20d97d95cc  vmovaps [rsp+0xE0], xmm15
00007d20d97d95d5  sub rsp, 0x30
00007d20d97d95d9  movaps [rsp], xmm14
00007d20d97d95de  movaps [rsp+0x10], xmm8
00007d20d97d95e4  movaps [rsp+0x20], xmm4
00007d20d97d95e9  lea rdi, [rsp]
00007d20d97d95ed  mov esi, 0x00
00007d20d97d95f2  mov rax, 0x5EFBF4CF6530
00007d20d97d95fc  call rax
00007d20d97d95fe  movaps xmm14, [rsp]
00007d20d97d9603  add rsp, 0x30
00007d20d97d9607  vmovaps xmm0, [rsp]
00007d20d97d960c  vmovaps xmm1, [rsp+0x10]
00007d20d97d9612  vmovaps xmm2, [rsp+0x20]
00007d20d97d9618  vmovaps xmm3, [rsp+0x30]
00007d20d97d961e  vmovaps xmm4, [rsp+0x40]
00007d20d97d9624  vmovaps xmm5, [rsp+0x50]
00007d20d97d962a  vmovaps xmm6, [rsp+0x60]
00007d20d97d9630  vmovaps xmm7, [rsp+0x70]
00007d20d97d9636  vmovaps xmm8, [rsp+0x80]
00007d20d97d963f  vmovaps xmm9, [rsp+0x90]
00007d20d97d9648  vmovaps xmm10, [rsp+0xA0]
00007d20d97d9651  vmovaps xmm11, [rsp+0xB0]
00007d20d97d965a  vmovaps xmm12, [rsp+0xC0]
00007d20d97d9663  vmovaps xmm13, [rsp+0xD0]
00007d20d97d966c  vmovaps xmm15, [rsp+0xE0]
00007d20d97d9675  add rsp, 0xF0
00007d20d97d967c  pop r11
00007d20d97d967e  pop r10
00007d20d97d9680  pop r9
00007d20d97d9682  pop r8
00007d20d97d9684  pop rsi
00007d20d97d9685  pop rdi
00007d20d97d9686  pop rdx
00007d20d97d9687  pop rcx
00007d20d97d9688  pop rax
00007d20d97d9689  add rsp, 0x08
00007d20d97d968d  jmp 0x00007D20D97D6265
00007d20d97d9692  sub rsp, 0x08
00007d20d97d9696  push rax
00007d20d97d9697  push rcx
00007d20d97d9698  push rdx
00007d20d97d9699  push rdi
00007d20d97d969a  push rsi
00007d20d97d969b  push r8
00007d20d97d969d  push r9
00007d20d97d969f  push r10
00007d20d97d96a1  push r11
00007d20d97d96a3  sub rsp, 0xF0
00007d20d97d96aa  vmovaps [rsp], xmm0
00007d20d97d96af  vmovaps [rsp+0x10], xmm1
00007d20d97d96b5  vmovaps [rsp+0x20], xmm2
00007d20d97d96bb  vmovaps [rsp+0x30], xmm3
00007d20d97d96c1  vmovaps [rsp+0x40], xmm5
00007d20d97d96c7  vmovaps [rsp+0x50], xmm6
00007d20d97d96cd  vmovaps [rsp+0x60], xmm7
00007d20d97d96d3  vmovaps [rsp+0x70], xmm8
00007d20d97d96d9  vmovaps [rsp+0x80], xmm9
00007d20d97d96e2  vmovaps [rsp+0x90], xmm10
00007d20d97d96eb  vmovaps [rsp+0xA0], xmm11
00007d20d97d96f4  vmovaps [rsp+0xB0], xmm12
00007d20d97d96fd  vmovaps [rsp+0xC0], xmm13
00007d20d97d9706  vmovaps [rsp+0xD0], xmm14
00007d20d97d970f  vmovaps [rsp+0xE0], xmm15
00007d20d97d9718  sub rsp, 0x30
00007d20d97d971c  movaps [rsp], xmm4
00007d20d97d9720  movaps [rsp+0x10], xmm13
00007d20d97d9726  movaps [rsp+0x20], xmm8
00007d20d97d972c  lea rdi, [rsp]
00007d20d97d9730  mov esi, 0x00
00007d20d97d9735  mov rax, 0x5EFBF4CF6530
00007d20d97d973f  call rax
00007d20d97d9741  movaps xmm4, [rsp]
00007d20d97d9745  add rsp, 0x30
00007d20d97d9749  vmovaps xmm0, [rsp]
00007d20d97d974e  vmovaps xmm1, [rsp+0x10]
00007d20d97d9754  vmovaps xmm2, [rsp+0x20]
00007d20d97d975a  vmovaps xmm3, [rsp+0x30]
00007d20d97d9760  vmovaps xmm5, [rsp+0x40]
00007d20d97d9766  vmovaps xmm6, [rsp+0x50]
00007d20d97d976c  vmovaps xmm7, [rsp+0x60]
00007d20d97d9772  vmovaps xmm8, [rsp+0x70]
00007d20d97d9778  vmovaps xmm9, [rsp+0x80]
00007d20d97d9781  vmovaps xmm10, [rsp+0x90]
00007d20d97d978a  vmovaps xmm11, [rsp+0xA0]
00007d20d97d9793  vmovaps xmm12, [rsp+0xB0]
00007d20d97d979c  vmovaps xmm13, [rsp+0xC0]
00007d20d97d97a5  vmovaps xmm14, [rsp+0xD0]
00007d20d97d97ae  vmovaps xmm15, [rsp+0xE0]
00007d20d97d97b7  add rsp, 0xF0
00007d20d97d97be  pop r11
00007d20d97d97c0  pop r10
00007d20d97d97c2  pop r9
00007d20d97d97c4  pop r8
00007d20d97d97c6  pop rsi
00007d20d97d97c7  pop rdi
00007d20d97d97c8  pop rdx
00007d20d97d97c9  pop rcx
00007d20d97d97ca  pop rax
00007d20d97d97cb  add rsp, 0x08
00007d20d97d97cf  jmp 0x00007D20D97D628A
00007d20d97d97d4  sub rsp, 0x08
00007d20d97d97d8  push rax
00007d20d97d97d9  push rcx
00007d20d97d97da  push rdx
00007d20d97d97db  push rdi
00007d20d97d97dc  push rsi
00007d20d97d97dd  push r8
00007d20d97d97df  push r9
00007d20d97d97e1  push r10
00007d20d97d97e3  push r11
00007d20d97d97e5  sub rsp, 0xF0
00007d20d97d97ec  vmovaps [rsp], xmm0
00007d20d97d97f1  vmovaps [rsp+0x10], xmm1
00007d20d97d97f7  vmovaps [rsp+0x20], xmm2
00007d20d97d97fd  vmovaps [rsp+0x30], xmm3
00007d20d97d9803  vmovaps [rsp+0x40], xmm4
00007d20d97d9809  vmovaps [rsp+0x50], xmm5
00007d20d97d980f  vmovaps [rsp+0x60], xmm6
00007d20d97d9815  vmovaps [rsp+0x70], xmm7
00007d20d97d981b  vmovaps [rsp+0x80], xmm8
00007d20d97d9824  vmovaps [rsp+0x90], xmm9
00007d20d97d982d  vmovaps [rsp+0xA0], xmm10
00007d20d97d9836  vmovaps [rsp+0xB0], xmm11
00007d20d97d983f  vmovaps [rsp+0xC0], xmm12
00007d20d97d9848  vmovaps [rsp+0xD0], xmm14
00007d20d97d9851  vmovaps [rsp+0xE0], xmm15
00007d20d97d985a  sub rsp, 0x30
00007d20d97d985e  movaps [rsp], xmm13
00007d20d97d9863  movaps [rsp+0x10], xmm15
00007d20d97d9869  movaps [rsp+0x20], xmm9
00007d20d97d986f  lea rdi, [rsp]
00007d20d97d9873  mov esi, 0x00
00007d20d97d9878  mov rax, 0x5EFBF4CF6530
00007d20d97d9882  call rax
00007d20d97d9884  movaps xmm13, [rsp]
00007d20d97d9889  add rsp, 0x30
00007d20d97d988d  vmovaps xmm0, [rsp]
00007d20d97d9892  vmovaps xmm1, [rsp+0x10]
00007d20d97d9898  vmovaps xmm2, [rsp+0x20]
00007d20d97d989e  vmovaps xmm3, [rsp+0x30]
00007d20d97d98a4  vmovaps xmm4, [rsp+0x40]
00007d20d97d98aa  vmovaps xmm5, [rsp+0x50]
00007d20d97d98b0  vmovaps xmm6, [rsp+0x60]
00007d20d97d98b6  vmovaps xmm7, [rsp+0x70]
00007d20d97d98bc  vmovaps xmm8, [rsp+0x80]
00007d20d97d98c5  vmovaps xmm9, [rsp+0x90]
00007d20d97d98ce  vmovaps xmm10, [rsp+0xA0]
00007d20d97d98d7  vmovaps xmm11, [rsp+0xB0]
00007d20d97d98e0  vmovaps xmm12, [rsp+0xC0]
00007d20d97d98e9  vmovaps xmm14, [rsp+0xD0]
00007d20d97d98f2  vmovaps xmm15, [rsp+0xE0]
00007d20d97d98fb  add rsp, 0xF0
00007d20d97d9902  pop r11
00007d20d97d9904  pop r10
00007d20d97d9906  pop r9
00007d20d97d9908  pop r8
00007d20d97d990a  pop rsi
00007d20d97d990b  pop rdi
00007d20d97d990c  pop rdx
00007d20d97d990d  pop rcx
00007d20d97d990e  pop rax
00007d20d97d990f  add rsp, 0x08
00007d20d97d9913  jmp 0x00007D20D97D62A5
00007d20d97d9918  sub rsp, 0x08
00007d20d97d991c  push rax
00007d20d97d991d  push rcx
00007d20d97d991e  push rdx
00007d20d97d991f  push rdi
00007d20d97d9920  push rsi
00007d20d97d9921  push r8
00007d20d97d9923  push r9
00007d20d97d9925  push r10
00007d20d97d9927  push r11
00007d20d97d9929  sub rsp, 0xF0
00007d20d97d9930  vmovaps [rsp], xmm0
00007d20d97d9935  vmovaps [rsp+0x10], xmm1
00007d20d97d993b  vmovaps [rsp+0x20], xmm2
00007d20d97d9941  vmovaps [rsp+0x30], xmm3
00007d20d97d9947  vmovaps [rsp+0x40], xmm4
00007d20d97d994d  vmovaps [rsp+0x50], xmm5
00007d20d97d9953  vmovaps [rsp+0x60], xmm6
00007d20d97d9959  vmovaps [rsp+0x70], xmm7
00007d20d97d995f  vmovaps [rsp+0x80], xmm8
00007d20d97d9968  vmovaps [rsp+0x90], xmm9
00007d20d97d9971  vmovaps [rsp+0xA0], xmm10
00007d20d97d997a  vmovaps [rsp+0xB0], xmm11
00007d20d97d9983  vmovaps [rsp+0xC0], xmm12
00007d20d97d998c  vmovaps [rsp+0xD0], xmm13
00007d20d97d9995  vmovaps [rsp+0xE0], xmm14
00007d20d97d999e  sub rsp, 0x30
00007d20d97d99a2  movaps [rsp], xmm15
00007d20d97d99a7  movaps [rsp+0x10], xmm1
00007d20d97d99ac  movaps [rsp+0x20], xmm5
00007d20d97d99b1  lea rdi, [rsp]
00007d20d97d99b5  mov esi, 0x00
00007d20d97d99ba  mov rax, 0x5EFBF4CF6530
00007d20d97d99c4  call rax
00007d20d97d99c6  movaps xmm15, [rsp]
00007d20d97d99cb  add rsp, 0x30
00007d20d97d99cf  vmovaps xmm0, [rsp]
00007d20d97d99d4  vmovaps xmm1, [rsp+0x10]
00007d20d97d99da  vmovaps xmm2, [rsp+0x20]
00007d20d97d99e0  vmovaps xmm3, [rsp+0x30]
00007d20d97d99e6  vmovaps xmm4, [rsp+0x40]
00007d20d97d99ec  vmovaps xmm5, [rsp+0x50]
00007d20d97d99f2  vmovaps xmm6, [rsp+0x60]
00007d20d97d99f8  vmovaps xmm7, [rsp+0x70]
00007d20d97d99fe  vmovaps xmm8, [rsp+0x80]
00007d20d97d9a07  vmovaps xmm9, [rsp+0x90]
00007d20d97d9a10  vmovaps xmm10, [rsp+0xA0]
00007d20d97d9a19  vmovaps xmm11, [rsp+0xB0]
00007d20d97d9a22  vmovaps xmm12, [rsp+0xC0]
00007d20d97d9a2b  vmovaps xmm13, [rsp+0xD0]
00007d20d97d9a34  vmovaps xmm14, [rsp+0xE0]
00007d20d97d9a3d  add rsp, 0xF0
00007d20d97d9a44  pop r11
00007d20d97d9a46  pop r10
00007d20d97d9a48  pop r9
00007d20d97d9a4a  pop r8
00007d20d97d9a4c  pop rsi
00007d20d97d9a4d  pop rdi
00007d20d97d9a4e  pop rdx
00007d20d97d9a4f  pop rcx
00007d20d97d9a50  pop rax
00007d20d97d9a51  add rsp, 0x08
00007d20d97d9a55  jmp 0x00007D20D97D62C0
00007d20d97d9a5a  call 0x00007D20D96D64F0
00007d20d97d9a5f  jmp 0x00007D20D97D631B
00007d20d97d9a64  sub rsp, 0x08
00007d20d97d9a68  push rax
00007d20d97d9a69  push rcx
00007d20d97d9a6a  push rdx
00007d20d97d9a6b  push rdi
00007d20d97d9a6c  push rsi
00007d20d97d9a6d  push r8
00007d20d97d9a6f  push r9
00007d20d97d9a71  push r10
00007d20d97d9a73  push r11
00007d20d97d9a75  sub rsp, 0xF0
00007d20d97d9a7c  vmovaps [rsp], xmm0
00007d20d97d9a81  vmovaps [rsp+0x10], xmm1
00007d20d97d9a87  vmovaps [rsp+0x20], xmm2
00007d20d97d9a8d  vmovaps [rsp+0x30], xmm3
00007d20d97d9a93  vmovaps [rsp+0x40], xmm4
00007d20d97d9a99  vmovaps [rsp+0x50], xmm5
00007d20d97d9a9f  vmovaps [rsp+0x60], xmm6
00007d20d97d9aa5  vmovaps [rsp+0x70], xmm7
00007d20d97d9aab  vmovaps [rsp+0x80], xmm8
00007d20d97d9ab4  vmovaps [rsp+0x90], xmm10
00007d20d97d9abd  vmovaps [rsp+0xA0], xmm11
00007d20d97d9ac6  vmovaps [rsp+0xB0], xmm12
00007d20d97d9acf  vmovaps [rsp+0xC0], xmm13
00007d20d97d9ad8  vmovaps [rsp+0xD0], xmm14
00007d20d97d9ae1  vmovaps [rsp+0xE0], xmm15
00007d20d97d9aea  sub rsp, 0x30
00007d20d97d9aee  movaps [rsp], xmm9
00007d20d97d9af3  movaps [rsp+0x10], xmm8
00007d20d97d9af9  movaps [rsp+0x20], xmm11
00007d20d97d9aff  lea rdi, [rsp]
00007d20d97d9b03  mov esi, 0x00
00007d20d97d9b08  mov rax, 0x5EFBF4CF6530
00007d20d97d9b12  call rax
00007d20d97d9b14  movaps xmm9, [rsp]
00007d20d97d9b19  add rsp, 0x30
00007d20d97d9b1d  vmovaps xmm0, [rsp]
00007d20d97d9b22  vmovaps xmm1, [rsp+0x10]
00007d20d97d9b28  vmovaps xmm2, [rsp+0x20]
00007d20d97d9b2e  vmovaps xmm3, [rsp+0x30]
00007d20d97d9b34  vmovaps xmm4, [rsp+0x40]
00007d20d97d9b3a  vmovaps xmm5, [rsp+0x50]
00007d20d97d9b40  vmovaps xmm6, [rsp+0x60]
00007d20d97d9b46  vmovaps xmm7, [rsp+0x70]
00007d20d97d9b4c  vmovaps xmm8, [rsp+0x80]
00007d20d97d9b55  vmovaps xmm10, [rsp+0x90]
00007d20d97d9b5e  vmovaps xmm11, [rsp+0xA0]
00007d20d97d9b67  vmovaps xmm12, [rsp+0xB0]
00007d20d97d9b70  vmovaps xmm13, [rsp+0xC0]
00007d20d97d9b79  vmovaps xmm14, [rsp+0xD0]
00007d20d97d9b82  vmovaps xmm15, [rsp+0xE0]
00007d20d97d9b8b  add rsp, 0xF0
00007d20d97d9b92  pop r11
00007d20d97d9b94  pop r10
00007d20d97d9b96  pop r9
00007d20d97d9b98  pop r8
00007d20d97d9b9a  pop rsi
00007d20d97d9b9b  pop rdi
00007d20d97d9b9c  pop rdx
00007d20d97d9b9d  pop rcx
00007d20d97d9b9e  pop rax
00007d20d97d9b9f  add rsp, 0x08
00007d20d97d9ba3  jmp 0x00007D20D97D6352
00007d20d97d9ba8  sub rsp, 0x08
00007d20d97d9bac  push rax
00007d20d97d9bad  push rcx
00007d20d97d9bae  push rdx
00007d20d97d9baf  push rdi
00007d20d97d9bb0  push rsi
00007d20d97d9bb1  push r8
00007d20d97d9bb3  push r9
00007d20d97d9bb5  push r10
00007d20d97d9bb7  push r11
00007d20d97d9bb9  sub rsp, 0xF0
00007d20d97d9bc0  vmovaps [rsp], xmm0
00007d20d97d9bc5  vmovaps [rsp+0x10], xmm1
00007d20d97d9bcb  vmovaps [rsp+0x20], xmm2
00007d20d97d9bd1  vmovaps [rsp+0x30], xmm3
00007d20d97d9bd7  vmovaps [rsp+0x40], xmm4
00007d20d97d9bdd  vmovaps [rsp+0x50], xmm5
00007d20d97d9be3  vmovaps [rsp+0x60], xmm6
00007d20d97d9be9  vmovaps [rsp+0x70], xmm7
00007d20d97d9bef  vmovaps [rsp+0x80], xmm8
00007d20d97d9bf8  vmovaps [rsp+0x90], xmm9
00007d20d97d9c01  vmovaps [rsp+0xA0], xmm10
00007d20d97d9c0a  vmovaps [rsp+0xB0], xmm12
00007d20d97d9c13  vmovaps [rsp+0xC0], xmm13
00007d20d97d9c1c  vmovaps [rsp+0xD0], xmm14
00007d20d97d9c25  vmovaps [rsp+0xE0], xmm15
00007d20d97d9c2e  sub rsp, 0x30
00007d20d97d9c32  movaps [rsp], xmm11
00007d20d97d9c37  movaps [rsp+0x10], xmm10
00007d20d97d9c3d  movaps [rsp+0x20], xmm6
00007d20d97d9c42  lea rdi, [rsp]
00007d20d97d9c46  mov esi, 0x00
00007d20d97d9c4b  mov rax, 0x5EFBF4CF6530
00007d20d97d9c55  call rax
00007d20d97d9c57  movaps xmm11, [rsp]
00007d20d97d9c5c  add rsp, 0x30
00007d20d97d9c60  vmovaps xmm0, [rsp]
00007d20d97d9c65  vmovaps xmm1, [rsp+0x10]
00007d20d97d9c6b  vmovaps xmm2, [rsp+0x20]
00007d20d97d9c71  vmovaps xmm3, [rsp+0x30]
00007d20d97d9c77  vmovaps xmm4, [rsp+0x40]
00007d20d97d9c7d  vmovaps xmm5, [rsp+0x50]
00007d20d97d9c83  vmovaps xmm6, [rsp+0x60]
00007d20d97d9c89  vmovaps xmm7, [rsp+0x70]
00007d20d97d9c8f  vmovaps xmm8, [rsp+0x80]
00007d20d97d9c98  vmovaps xmm9, [rsp+0x90]
00007d20d97d9ca1  vmovaps xmm10, [rsp+0xA0]
00007d20d97d9caa  vmovaps xmm12, [rsp+0xB0]
00007d20d97d9cb3  vmovaps xmm13, [rsp+0xC0]
00007d20d97d9cbc  vmovaps xmm14, [rsp+0xD0]
00007d20d97d9cc5  vmovaps xmm15, [rsp+0xE0]
00007d20d97d9cce  add rsp, 0xF0
00007d20d97d9cd5  pop r11
00007d20d97d9cd7  pop r10
00007d20d97d9cd9  pop r9
00007d20d97d9cdb  pop r8
00007d20d97d9cdd  pop rsi
00007d20d97d9cde  pop rdi
00007d20d97d9cdf  pop rdx
00007d20d97d9ce0  pop rcx
00007d20d97d9ce1  pop rax
00007d20d97d9ce2  add rsp, 0x08
00007d20d97d9ce6  jmp 0x00007D20D97D636D
00007d20d97d9ceb  sub rsp, 0x08
00007d20d97d9cef  push rax
00007d20d97d9cf0  push rcx
00007d20d97d9cf1  push rdx
00007d20d97d9cf2  push rdi
00007d20d97d9cf3  push rsi
00007d20d97d9cf4  push r8
00007d20d97d9cf6  push r9
00007d20d97d9cf8  push r10
00007d20d97d9cfa  push r11
00007d20d97d9cfc  sub rsp, 0xF0
00007d20d97d9d03  vmovaps [rsp], xmm0
00007d20d97d9d08  vmovaps [rsp+0x10], xmm1
00007d20d97d9d0e  vmovaps [rsp+0x20], xmm2
00007d20d97d9d14  vmovaps [rsp+0x30], xmm3
00007d20d97d9d1a  vmovaps [rsp+0x40], xmm4
00007d20d97d9d20  vmovaps [rsp+0x50], xmm5
00007d20d97d9d26  vmovaps [rsp+0x60], xmm6
00007d20d97d9d2c  vmovaps [rsp+0x70], xmm7
00007d20d97d9d32  vmovaps [rsp+0x80], xmm8
00007d20d97d9d3b  vmovaps [rsp+0x90], xmm9
00007d20d97d9d44  vmovaps [rsp+0xA0], xmm11
00007d20d97d9d4d  vmovaps [rsp+0xB0], xmm12
00007d20d97d9d56  vmovaps [rsp+0xC0], xmm13
00007d20d97d9d5f  vmovaps [rsp+0xD0], xmm14
00007d20d97d9d68  vmovaps [rsp+0xE0], xmm15
00007d20d97d9d71  sub rsp, 0x30
00007d20d97d9d75  movaps [rsp], xmm10
00007d20d97d9d7a  movaps [rsp+0x10], xmm14
00007d20d97d9d80  movaps [rsp+0x20], xmm4
00007d20d97d9d85  lea rdi, [rsp]
00007d20d97d9d89  mov esi, 0x00
00007d20d97d9d8e  mov rax, 0x5EFBF4CF6530
00007d20d97d9d98  call rax
00007d20d97d9d9a  movaps xmm10, [rsp]
00007d20d97d9d9f  add rsp, 0x30
00007d20d97d9da3  vmovaps xmm0, [rsp]
00007d20d97d9da8  vmovaps xmm1, [rsp+0x10]
00007d20d97d9dae  vmovaps xmm2, [rsp+0x20]
00007d20d97d9db4  vmovaps xmm3, [rsp+0x30]
00007d20d97d9dba  vmovaps xmm4, [rsp+0x40]
00007d20d97d9dc0  vmovaps xmm5, [rsp+0x50]
00007d20d97d9dc6  vmovaps xmm6, [rsp+0x60]
00007d20d97d9dcc  vmovaps xmm7, [rsp+0x70]
00007d20d97d9dd2  vmovaps xmm8, [rsp+0x80]
00007d20d97d9ddb  vmovaps xmm9, [rsp+0x90]
00007d20d97d9de4  vmovaps xmm11, [rsp+0xA0]
00007d20d97d9ded  vmovaps xmm12, [rsp+0xB0]
00007d20d97d9df6  vmovaps xmm13, [rsp+0xC0]
00007d20d97d9dff  vmovaps xmm14, [rsp+0xD0]
00007d20d97d9e08  vmovaps xmm15, [rsp+0xE0]
00007d20d97d9e11  add rsp, 0xF0
00007d20d97d9e18  pop r11
00007d20d97d9e1a  pop r10
00007d20d97d9e1c  pop r9
00007d20d97d9e1e  pop r8
00007d20d97d9e20  pop rsi
00007d20d97d9e21  pop rdi
00007d20d97d9e22  pop rdx
00007d20d97d9e23  pop rcx
00007d20d97d9e24  pop rax
00007d20d97d9e25  add rsp, 0x08
00007d20d97d9e29  jmp 0x00007D20D97D6388
00007d20d97d9e2e  sub rsp, 0x08
00007d20d97d9e32  push rax
00007d20d97d9e33  push rcx
00007d20d97d9e34  push rdx
00007d20d97d9e35  push rdi
00007d20d97d9e36  push rsi
00007d20d97d9e37  push r8
00007d20d97d9e39  push r9
00007d20d97d9e3b  push r10
00007d20d97d9e3d  push r11
00007d20d97d9e3f  sub rsp, 0xF0
00007d20d97d9e46  vmovaps [rsp], xmm0
00007d20d97d9e4b  vmovaps [rsp+0x10], xmm1
00007d20d97d9e51  vmovaps [rsp+0x20], xmm2
00007d20d97d9e57  vmovaps [rsp+0x30], xmm3
00007d20d97d9e5d  vmovaps [rsp+0x40], xmm4
00007d20d97d9e63  vmovaps [rsp+0x50], xmm5
00007d20d97d9e69  vmovaps [rsp+0x60], xmm6
00007d20d97d9e6f  vmovaps [rsp+0x70], xmm7
00007d20d97d9e75  vmovaps [rsp+0x80], xmm9
00007d20d97d9e7e  vmovaps [rsp+0x90], xmm10
00007d20d97d9e87  vmovaps [rsp+0xA0], xmm11
00007d20d97d9e90  vmovaps [rsp+0xB0], xmm12
00007d20d97d9e99  vmovaps [rsp+0xC0], xmm13
00007d20d97d9ea2  vmovaps [rsp+0xD0], xmm14
00007d20d97d9eab  vmovaps [rsp+0xE0], xmm15
00007d20d97d9eb4  sub rsp, 0x30
00007d20d97d9eb8  movaps [rsp], xmm8
00007d20d97d9ebd  movaps [rsp+0x10], xmm1
00007d20d97d9ec2  movaps [rsp+0x20], xmm14
00007d20d97d9ec8  lea rdi, [rsp]
00007d20d97d9ecc  mov esi, 0x00
00007d20d97d9ed1  mov rax, 0x5EFBF4CF6530
00007d20d97d9edb  call rax
00007d20d97d9edd  movaps xmm8, [rsp]
00007d20d97d9ee2  add rsp, 0x30
00007d20d97d9ee6  vmovaps xmm0, [rsp]
00007d20d97d9eeb  vmovaps xmm1, [rsp+0x10]
00007d20d97d9ef1  vmovaps xmm2, [rsp+0x20]
00007d20d97d9ef7  vmovaps xmm3, [rsp+0x30]
00007d20d97d9efd  vmovaps xmm4, [rsp+0x40]
00007d20d97d9f03  vmovaps xmm5, [rsp+0x50]
00007d20d97d9f09  vmovaps xmm6, [rsp+0x60]
00007d20d97d9f0f  vmovaps xmm7, [rsp+0x70]
00007d20d97d9f15  vmovaps xmm9, [rsp+0x80]
00007d20d97d9f1e  vmovaps xmm10, [rsp+0x90]
00007d20d97d9f27  vmovaps xmm11, [rsp+0xA0]
00007d20d97d9f30  vmovaps xmm12, [rsp+0xB0]
00007d20d97d9f39  vmovaps xmm13, [rsp+0xC0]
00007d20d97d9f42  vmovaps xmm14, [rsp+0xD0]
00007d20d97d9f4b  vmovaps xmm15, [rsp+0xE0]
00007d20d97d9f54  add rsp, 0xF0
00007d20d97d9f5b  pop r11
00007d20d97d9f5d  pop r10
00007d20d97d9f5f  pop r9
00007d20d97d9f61  pop r8
00007d20d97d9f63  pop rsi
00007d20d97d9f64  pop rdi
00007d20d97d9f65  pop rdx
00007d20d97d9f66  pop rcx
00007d20d97d9f67  pop rax
00007d20d97d9f68  add rsp, 0x08
00007d20d97d9f6c  jmp 0x00007D20D97D63AE
00007d20d97d9f71  sub rsp, 0x08
00007d20d97d9f75  push rax
00007d20d97d9f76  push rcx
00007d20d97d9f77  push rdx
00007d20d97d9f78  push rdi
00007d20d97d9f79  push rsi
00007d20d97d9f7a  push r8
00007d20d97d9f7c  push r9
00007d20d97d9f7e  push r10
00007d20d97d9f80  push r11
00007d20d97d9f82  sub rsp, 0xF0
00007d20d97d9f89  vmovaps [rsp], xmm0
00007d20d97d9f8e  vmovaps [rsp+0x10], xmm1
00007d20d97d9f94  vmovaps [rsp+0x20], xmm2
00007d20d97d9f9a  vmovaps [rsp+0x30], xmm3
00007d20d97d9fa0  vmovaps [rsp+0x40], xmm4
00007d20d97d9fa6  vmovaps [rsp+0x50], xmm5
00007d20d97d9fac  vmovaps [rsp+0x60], xmm7
00007d20d97d9fb2  vmovaps [rsp+0x70], xmm8
00007d20d97d9fb8  vmovaps [rsp+0x80], xmm9
00007d20d97d9fc1  vmovaps [rsp+0x90], xmm10
00007d20d97d9fca  vmovaps [rsp+0xA0], xmm11
00007d20d97d9fd3  vmovaps [rsp+0xB0], xmm12
00007d20d97d9fdc  vmovaps [rsp+0xC0], xmm13
00007d20d97d9fe5  vmovaps [rsp+0xD0], xmm14
00007d20d97d9fee  vmovaps [rsp+0xE0], xmm15
00007d20d97d9ff7  sub rsp, 0x30
00007d20d97d9ffb  movaps [rsp], xmm6
00007d20d97d9fff  movaps [rsp+0x10], xmm1
00007d20d97da004  movaps [rsp+0x20], xmm14
00007d20d97da00a  lea rdi, [rsp]
00007d20d97da00e  mov esi, 0x00
00007d20d97da013  mov rax, 0x5EFBF4CF6530
00007d20d97da01d  call rax
00007d20d97da01f  movaps xmm6, [rsp]
00007d20d97da023  add rsp, 0x30
00007d20d97da027  vmovaps xmm0, [rsp]
00007d20d97da02c  vmovaps xmm1, [rsp+0x10]
00007d20d97da032  vmovaps xmm2, [rsp+0x20]
00007d20d97da038  vmovaps xmm3, [rsp+0x30]
00007d20d97da03e  vmovaps xmm4, [rsp+0x40]
00007d20d97da044  vmovaps xmm5, [rsp+0x50]
00007d20d97da04a  vmovaps xmm7, [rsp+0x60]
00007d20d97da050  vmovaps xmm8, [rsp+0x70]
00007d20d97da056  vmovaps xmm9, [rsp+0x80]
00007d20d97da05f  vmovaps xmm10, [rsp+0x90]
00007d20d97da068  vmovaps xmm11, [rsp+0xA0]
00007d20d97da071  vmovaps xmm12, [rsp+0xB0]
00007d20d97da07a  vmovaps xmm13, [rsp+0xC0]
00007d20d97da083  vmovaps xmm14, [rsp+0xD0]
00007d20d97da08c  vmovaps xmm15, [rsp+0xE0]
00007d20d97da095  add rsp, 0xF0
00007d20d97da09c  pop r11
00007d20d97da09e  pop r10
00007d20d97da0a0  pop r9
00007d20d97da0a2  pop r8
00007d20d97da0a4  pop rsi
00007d20d97da0a5  pop rdi
00007d20d97da0a6  pop rdx
00007d20d97da0a7  pop rcx
00007d20d97da0a8  pop rax
00007d20d97da0a9  add rsp, 0x08
00007d20d97da0ad  jmp 0x00007D20D97D63DA
00007d20d97da0b2  sub rsp, 0x08
00007d20d97da0b6  push rax
00007d20d97da0b7  push rcx
00007d20d97da0b8  push rdx
00007d20d97da0b9  push rdi
00007d20d97da0ba  push rsi
00007d20d97da0bb  push r8
00007d20d97da0bd  push r9
00007d20d97da0bf  push r10
00007d20d97da0c1  push r11
00007d20d97da0c3  sub rsp, 0xF0
00007d20d97da0ca  vmovaps [rsp], xmm0
00007d20d97da0cf  vmovaps [rsp+0x10], xmm1
00007d20d97da0d5  vmovaps [rsp+0x20], xmm2
00007d20d97da0db  vmovaps [rsp+0x30], xmm3
00007d20d97da0e1  vmovaps [rsp+0x40], xmm4
00007d20d97da0e7  vmovaps [rsp+0x50], xmm5
00007d20d97da0ed  vmovaps [rsp+0x60], xmm6
00007d20d97da0f3  vmovaps [rsp+0x70], xmm7
00007d20d97da0f9  vmovaps [rsp+0x80], xmm8
00007d20d97da102  vmovaps [rsp+0x90], xmm9
00007d20d97da10b  vmovaps [rsp+0xA0], xmm10
00007d20d97da114  vmovaps [rsp+0xB0], xmm11
00007d20d97da11d  vmovaps [rsp+0xC0], xmm12
00007d20d97da126  vmovaps [rsp+0xD0], xmm13
00007d20d97da12f  vmovaps [rsp+0xE0], xmm15
00007d20d97da138  sub rsp, 0x30
00007d20d97da13c  movaps [rsp], xmm14
00007d20d97da141  movaps [rsp+0x10], xmm12
00007d20d97da147  movaps [rsp+0x20], xmm1
00007d20d97da14c  lea rdi, [rsp]
00007d20d97da150  mov esi, 0x00
00007d20d97da155  mov rax, 0x5EFBF4CF6530
00007d20d97da15f  call rax
00007d20d97da161  movaps xmm14, [rsp]
00007d20d97da166  add rsp, 0x30
00007d20d97da16a  vmovaps xmm0, [rsp]
00007d20d97da16f  vmovaps xmm1, [rsp+0x10]
00007d20d97da175  vmovaps xmm2, [rsp+0x20]
00007d20d97da17b  vmovaps xmm3, [rsp+0x30]
00007d20d97da181  vmovaps xmm4, [rsp+0x40]
00007d20d97da187  vmovaps xmm5, [rsp+0x50]
00007d20d97da18d  vmovaps xmm6, [rsp+0x60]
00007d20d97da193  vmovaps xmm7, [rsp+0x70]
00007d20d97da199  vmovaps xmm8, [rsp+0x80]
00007d20d97da1a2  vmovaps xmm9, [rsp+0x90]
00007d20d97da1ab  vmovaps xmm10, [rsp+0xA0]
00007d20d97da1b4  vmovaps xmm11, [rsp+0xB0]
00007d20d97da1bd  vmovaps xmm12, [rsp+0xC0]
00007d20d97da1c6  vmovaps xmm13, [rsp+0xD0]
00007d20d97da1cf  vmovaps xmm15, [rsp+0xE0]
00007d20d97da1d8  add rsp, 0xF0
00007d20d97da1df  pop r11
00007d20d97da1e1  pop r10
00007d20d97da1e3  pop r9
00007d20d97da1e5  pop r8
00007d20d97da1e7  pop rsi
00007d20d97da1e8  pop rdi
00007d20d97da1e9  pop rdx
00007d20d97da1ea  pop rcx
00007d20d97da1eb  pop rax
00007d20d97da1ec  add rsp, 0x08
00007d20d97da1f0  jmp 0x00007D20D97D6400
00007d20d97da1f5  sub rsp, 0x08
00007d20d97da1f9  push rax
00007d20d97da1fa  push rcx
00007d20d97da1fb  push rdx
00007d20d97da1fc  push rdi
00007d20d97da1fd  push rsi
00007d20d97da1fe  push r8
00007d20d97da200  push r9
00007d20d97da202  push r10
00007d20d97da204  push r11
00007d20d97da206  sub rsp, 0xF0
00007d20d97da20d  vmovaps [rsp], xmm0
00007d20d97da212  vmovaps [rsp+0x10], xmm2
00007d20d97da218  vmovaps [rsp+0x20], xmm3
00007d20d97da21e  vmovaps [rsp+0x30], xmm4
00007d20d97da224  vmovaps [rsp+0x40], xmm5
00007d20d97da22a  vmovaps [rsp+0x50], xmm6
00007d20d97da230  vmovaps [rsp+0x60], xmm7
00007d20d97da236  vmovaps [rsp+0x70], xmm8
00007d20d97da23c  vmovaps [rsp+0x80], xmm9
00007d20d97da245  vmovaps [rsp+0x90], xmm10
00007d20d97da24e  vmovaps [rsp+0xA0], xmm11
00007d20d97da257  vmovaps [rsp+0xB0], xmm12
00007d20d97da260  vmovaps [rsp+0xC0], xmm13
00007d20d97da269  vmovaps [rsp+0xD0], xmm14
00007d20d97da272  vmovaps [rsp+0xE0], xmm15
00007d20d97da27b  sub rsp, 0x30
00007d20d97da27f  movaps [rsp], xmm1
00007d20d97da283  movaps [rsp+0x10], xmm13
00007d20d97da289  movaps [rsp+0x20], xmm9
00007d20d97da28f  lea rdi, [rsp]
00007d20d97da293  mov esi, 0x00
00007d20d97da298  mov rax, 0x5EFBF4CF6530
00007d20d97da2a2  call rax
00007d20d97da2a4  movaps xmm1, [rsp]
00007d20d97da2a8  add rsp, 0x30
00007d20d97da2ac  vmovaps xmm0, [rsp]
00007d20d97da2b1  vmovaps xmm2, [rsp+0x10]
00007d20d97da2b7  vmovaps xmm3, [rsp+0x20]
00007d20d97da2bd  vmovaps xmm4, [rsp+0x30]
00007d20d97da2c3  vmovaps xmm5, [rsp+0x40]
00007d20d97da2c9  vmovaps xmm6, [rsp+0x50]
00007d20d97da2cf  vmovaps xmm7, [rsp+0x60]
00007d20d97da2d5  vmovaps xmm8, [rsp+0x70]
00007d20d97da2db  vmovaps xmm9, [rsp+0x80]
00007d20d97da2e4  vmovaps xmm10, [rsp+0x90]
00007d20d97da2ed  vmovaps xmm11, [rsp+0xA0]
00007d20d97da2f6  vmovaps xmm12, [rsp+0xB0]
00007d20d97da2ff  vmovaps xmm13, [rsp+0xC0]
00007d20d97da308  vmovaps xmm14, [rsp+0xD0]
00007d20d97da311  vmovaps xmm15, [rsp+0xE0]
00007d20d97da31a  add rsp, 0xF0
00007d20d97da321  pop r11
00007d20d97da323  pop r10
00007d20d97da325  pop r9
00007d20d97da327  pop r8
00007d20d97da329  pop rsi
00007d20d97da32a  pop rdi
00007d20d97da32b  pop rdx
00007d20d97da32c  pop rcx
00007d20d97da32d  pop rax
00007d20d97da32e  add rsp, 0x08
00007d20d97da332  jmp 0x00007D20D97D641A
00007d20d97da337  sub rsp, 0x08
00007d20d97da33b  push rax
00007d20d97da33c  push rcx
00007d20d97da33d  push rdx
00007d20d97da33e  push rdi
00007d20d97da33f  push rsi
00007d20d97da340  push r8
00007d20d97da342  push r9
00007d20d97da344  push r10
00007d20d97da346  push r11
00007d20d97da348  sub rsp, 0xF0
00007d20d97da34f  vmovaps [rsp], xmm0
00007d20d97da354  vmovaps [rsp+0x10], xmm1
00007d20d97da35a  vmovaps [rsp+0x20], xmm2
00007d20d97da360  vmovaps [rsp+0x30], xmm3
00007d20d97da366  vmovaps [rsp+0x40], xmm4
00007d20d97da36c  vmovaps [rsp+0x50], xmm5
00007d20d97da372  vmovaps [rsp+0x60], xmm6
00007d20d97da378  vmovaps [rsp+0x70], xmm7
00007d20d97da37e  vmovaps [rsp+0x80], xmm8
00007d20d97da387  vmovaps [rsp+0x90], xmm9
00007d20d97da390  vmovaps [rsp+0xA0], xmm10
00007d20d97da399  vmovaps [rsp+0xB0], xmm11
00007d20d97da3a2  vmovaps [rsp+0xC0], xmm13
00007d20d97da3ab  vmovaps [rsp+0xD0], xmm14
00007d20d97da3b4  vmovaps [rsp+0xE0], xmm15
00007d20d97da3bd  sub rsp, 0x30
00007d20d97da3c1  movaps [rsp], xmm12
00007d20d97da3c6  movaps [rsp+0x10], xmm7
00007d20d97da3cb  movaps [rsp+0x20], xmm13
00007d20d97da3d1  lea rdi, [rsp]
00007d20d97da3d5  mov esi, 0x00
00007d20d97da3da  mov rax, 0x5EFBF4CF6530
00007d20d97da3e4  call rax
00007d20d97da3e6  movaps xmm12, [rsp]
00007d20d97da3eb  add rsp, 0x30
00007d20d97da3ef  vmovaps xmm0, [rsp]
00007d20d97da3f4  vmovaps xmm1, [rsp+0x10]
00007d20d97da3fa  vmovaps xmm2, [rsp+0x20]
00007d20d97da400  vmovaps xmm3, [rsp+0x30]
00007d20d97da406  vmovaps xmm4, [rsp+0x40]
00007d20d97da40c  vmovaps xmm5, [rsp+0x50]
00007d20d97da412  vmovaps xmm6, [rsp+0x60]
00007d20d97da418  vmovaps xmm7, [rsp+0x70]
00007d20d97da41e  vmovaps xmm8, [rsp+0x80]
00007d20d97da427  vmovaps xmm9, [rsp+0x90]
00007d20d97da430  vmovaps xmm10, [rsp+0xA0]
00007d20d97da439  vmovaps xmm11, [rsp+0xB0]
00007d20d97da442  vmovaps xmm13, [rsp+0xC0]
00007d20d97da44b  vmovaps xmm14, [rsp+0xD0]
00007d20d97da454  vmovaps xmm15, [rsp+0xE0]
00007d20d97da45d  add rsp, 0xF0
00007d20d97da464  pop r11
00007d20d97da466  pop r10
00007d20d97da468  pop r9
00007d20d97da46a  pop r8
00007d20d97da46c  pop rsi
00007d20d97da46d  pop rdi
00007d20d97da46e  pop rdx
00007d20d97da46f  pop rcx
00007d20d97da470  pop rax
00007d20d97da471  add rsp, 0x08
00007d20d97da475  jmp 0x00007D20D97D6441
00007d20d97da47a  sub rsp, 0x08
00007d20d97da47e  push rax
00007d20d97da47f  push rcx
00007d20d97da480  push rdx
00007d20d97da481  push rdi
00007d20d97da482  push rsi
00007d20d97da483  push r8
00007d20d97da485  push r9
00007d20d97da487  push r10
00007d20d97da489  push r11
00007d20d97da48b  sub rsp, 0xF0
00007d20d97da492  vmovaps [rsp], xmm0
00007d20d97da497  vmovaps [rsp+0x10], xmm1
00007d20d97da49d  vmovaps [rsp+0x20], xmm2
00007d20d97da4a3  vmovaps [rsp+0x30], xmm3
00007d20d97da4a9  vmovaps [rsp+0x40], xmm4
00007d20d97da4af  vmovaps [rsp+0x50], xmm5
00007d20d97da4b5  vmovaps [rsp+0x60], xmm6
00007d20d97da4bb  vmovaps [rsp+0x70], xmm7
00007d20d97da4c1  vmovaps [rsp+0x80], xmm8
00007d20d97da4ca  vmovaps [rsp+0x90], xmm9
00007d20d97da4d3  vmovaps [rsp+0xA0], xmm10
00007d20d97da4dc  vmovaps [rsp+0xB0], xmm11
00007d20d97da4e5  vmovaps [rsp+0xC0], xmm12
00007d20d97da4ee  vmovaps [rsp+0xD0], xmm14
00007d20d97da4f7  vmovaps [rsp+0xE0], xmm15
00007d20d97da500  sub rsp, 0x30
00007d20d97da504  movaps [rsp], xmm13
00007d20d97da509  movaps [rsp+0x10], xmm15
00007d20d97da50f  movaps [rsp+0x20], xmm8
00007d20d97da515  lea rdi, [rsp]
00007d20d97da519  mov esi, 0x00
00007d20d97da51e  mov rax, 0x5EFBF4CF6530
00007d20d97da528  call rax
00007d20d97da52a  movaps xmm13, [rsp]
00007d20d97da52f  add rsp, 0x30
00007d20d97da533  vmovaps xmm0, [rsp]
00007d20d97da538  vmovaps xmm1, [rsp+0x10]
00007d20d97da53e  vmovaps xmm2, [rsp+0x20]
00007d20d97da544  vmovaps xmm3, [rsp+0x30]
00007d20d97da54a  vmovaps xmm4, [rsp+0x40]
00007d20d97da550  vmovaps xmm5, [rsp+0x50]
00007d20d97da556  vmovaps xmm6, [rsp+0x60]
00007d20d97da55c  vmovaps xmm7, [rsp+0x70]
00007d20d97da562  vmovaps xmm8, [rsp+0x80]
00007d20d97da56b  vmovaps xmm9, [rsp+0x90]
00007d20d97da574  vmovaps xmm10, [rsp+0xA0]
00007d20d97da57d  vmovaps xmm11, [rsp+0xB0]
00007d20d97da586  vmovaps xmm12, [rsp+0xC0]
00007d20d97da58f  vmovaps xmm14, [rsp+0xD0]
00007d20d97da598  vmovaps xmm15, [rsp+0xE0]
00007d20d97da5a1  add rsp, 0xF0
00007d20d97da5a8  pop r11
00007d20d97da5aa  pop r10
00007d20d97da5ac  pop r9
00007d20d97da5ae  pop r8
00007d20d97da5b0  pop rsi
00007d20d97da5b1  pop rdi
00007d20d97da5b2  pop rdx
00007d20d97da5b3  pop rcx
00007d20d97da5b4  pop rax
00007d20d97da5b5  add rsp, 0x08
00007d20d97da5b9  jmp 0x00007D20D97D645C
00007d20d97da5be  sub rsp, 0x08
00007d20d97da5c2  push rax
00007d20d97da5c3  push rcx
00007d20d97da5c4  push rdx
00007d20d97da5c5  push rdi
00007d20d97da5c6  push rsi
00007d20d97da5c7  push r8
00007d20d97da5c9  push r9
00007d20d97da5cb  push r10
00007d20d97da5cd  push r11
00007d20d97da5cf  sub rsp, 0xF0
00007d20d97da5d6  vmovaps [rsp], xmm0
00007d20d97da5db  vmovaps [rsp+0x10], xmm1
00007d20d97da5e1  vmovaps [rsp+0x20], xmm2
00007d20d97da5e7  vmovaps [rsp+0x30], xmm3
00007d20d97da5ed  vmovaps [rsp+0x40], xmm4
00007d20d97da5f3  vmovaps [rsp+0x50], xmm5
00007d20d97da5f9  vmovaps [rsp+0x60], xmm6
00007d20d97da5ff  vmovaps [rsp+0x70], xmm7
00007d20d97da605  vmovaps [rsp+0x80], xmm9
00007d20d97da60e  vmovaps [rsp+0x90], xmm10
00007d20d97da617  vmovaps [rsp+0xA0], xmm11
00007d20d97da620  vmovaps [rsp+0xB0], xmm12
00007d20d97da629  vmovaps [rsp+0xC0], xmm13
00007d20d97da632  vmovaps [rsp+0xD0], xmm14
00007d20d97da63b  vmovaps [rsp+0xE0], xmm15
00007d20d97da644  sub rsp, 0x30
00007d20d97da648  movaps [rsp], xmm8
00007d20d97da64d  movaps [rsp+0x10], xmm15
00007d20d97da653  movaps [rsp+0x20], xmm9
00007d20d97da659  lea rdi, [rsp]
00007d20d97da65d  mov esi, 0x00
00007d20d97da662  mov rax, 0x5EFBF4CF6530
00007d20d97da66c  call rax
00007d20d97da66e  movaps xmm8, [rsp]
00007d20d97da673  add rsp, 0x30
00007d20d97da677  vmovaps xmm0, [rsp]
00007d20d97da67c  vmovaps xmm1, [rsp+0x10]
00007d20d97da682  vmovaps xmm2, [rsp+0x20]
00007d20d97da688  vmovaps xmm3, [rsp+0x30]
00007d20d97da68e  vmovaps xmm4, [rsp+0x40]
00007d20d97da694  vmovaps xmm5, [rsp+0x50]
00007d20d97da69a  vmovaps xmm6, [rsp+0x60]
00007d20d97da6a0  vmovaps xmm7, [rsp+0x70]
00007d20d97da6a6  vmovaps xmm9, [rsp+0x80]
00007d20d97da6af  vmovaps xmm10, [rsp+0x90]
00007d20d97da6b8  vmovaps xmm11, [rsp+0xA0]
00007d20d97da6c1  vmovaps xmm12, [rsp+0xB0]
00007d20d97da6ca  vmovaps xmm13, [rsp+0xC0]
00007d20d97da6d3  vmovaps xmm14, [rsp+0xD0]
00007d20d97da6dc  vmovaps xmm15, [rsp+0xE0]
00007d20d97da6e5  add rsp, 0xF0
00007d20d97da6ec  pop r11
00007d20d97da6ee  pop r10
00007d20d97da6f0  pop r9
00007d20d97da6f2  pop r8
00007d20d97da6f4  pop rsi
00007d20d97da6f5  pop rdi
00007d20d97da6f6  pop rdx
00007d20d97da6f7  pop rcx
00007d20d97da6f8  pop rax
00007d20d97da6f9  add rsp, 0x08
00007d20d97da6fd  jmp 0x00007D20D97D648A
00007d20d97da702  sub rsp, 0x08
00007d20d97da706  push rax
00007d20d97da707  push rcx
00007d20d97da708  push rdx
00007d20d97da709  push rdi
00007d20d97da70a  push rsi
00007d20d97da70b  push r8
00007d20d97da70d  push r9
00007d20d97da70f  push r10
00007d20d97da711  push r11
00007d20d97da713  sub rsp, 0xF0
00007d20d97da71a  vmovaps [rsp], xmm0
00007d20d97da71f  vmovaps [rsp+0x10], xmm1
00007d20d97da725  vmovaps [rsp+0x20], xmm2
00007d20d97da72b  vmovaps [rsp+0x30], xmm3
00007d20d97da731  vmovaps [rsp+0x40], xmm4
00007d20d97da737  vmovaps [rsp+0x50], xmm5
00007d20d97da73d  vmovaps [rsp+0x60], xmm6
00007d20d97da743  vmovaps [rsp+0x70], xmm7
00007d20d97da749  vmovaps [rsp+0x80], xmm8
00007d20d97da752  vmovaps [rsp+0x90], xmm9
00007d20d97da75b  vmovaps [rsp+0xA0], xmm10
00007d20d97da764  vmovaps [rsp+0xB0], xmm11
00007d20d97da76d  vmovaps [rsp+0xC0], xmm12
00007d20d97da776  vmovaps [rsp+0xD0], xmm13
00007d20d97da77f  vmovaps [rsp+0xE0], xmm14
00007d20d97da788  sub rsp, 0x30
00007d20d97da78c  movaps [rsp], xmm15
00007d20d97da791  movaps [rsp+0x10], xmm11
00007d20d97da797  movaps [rsp+0x20], xmm6
00007d20d97da79c  lea rdi, [rsp]
00007d20d97da7a0  mov esi, 0x00
00007d20d97da7a5  mov rax, 0x5EFBF4CF6530
00007d20d97da7af  call rax
00007d20d97da7b1  movaps xmm15, [rsp]
00007d20d97da7b6  add rsp, 0x30
00007d20d97da7ba  vmovaps xmm0, [rsp]
00007d20d97da7bf  vmovaps xmm1, [rsp+0x10]
00007d20d97da7c5  vmovaps xmm2, [rsp+0x20]
00007d20d97da7cb  vmovaps xmm3, [rsp+0x30]
00007d20d97da7d1  vmovaps xmm4, [rsp+0x40]
00007d20d97da7d7  vmovaps xmm5, [rsp+0x50]
00007d20d97da7dd  vmovaps xmm6, [rsp+0x60]
00007d20d97da7e3  vmovaps xmm7, [rsp+0x70]
00007d20d97da7e9  vmovaps xmm8, [rsp+0x80]
00007d20d97da7f2  vmovaps xmm9, [rsp+0x90]
00007d20d97da7fb  vmovaps xmm10, [rsp+0xA0]
00007d20d97da804  vmovaps xmm11, [rsp+0xB0]
00007d20d97da80d  vmovaps xmm12, [rsp+0xC0]
00007d20d97da816  vmovaps xmm13, [rsp+0xD0]
00007d20d97da81f  vmovaps xmm14, [rsp+0xE0]
00007d20d97da828  add rsp, 0xF0
00007d20d97da82f  pop r11
00007d20d97da831  pop r10
00007d20d97da833  pop r9
00007d20d97da835  pop r8
00007d20d97da837  pop rsi
00007d20d97da838  pop rdi
00007d20d97da839  pop rdx
00007d20d97da83a  pop rcx
00007d20d97da83b  pop rax
00007d20d97da83c  add rsp, 0x08
00007d20d97da840  jmp 0x00007D20D97D64A5
00007d20d97da845  sub rsp, 0x08
00007d20d97da849  push rax
00007d20d97da84a  push rcx
00007d20d97da84b  push rdx
00007d20d97da84c  push rdi
00007d20d97da84d  push rsi
00007d20d97da84e  push r8
00007d20d97da850  push r9
00007d20d97da852  push r10
00007d20d97da854  push r11
00007d20d97da856  sub rsp, 0xF0
00007d20d97da85d  vmovaps [rsp], xmm0
00007d20d97da862  vmovaps [rsp+0x10], xmm1
00007d20d97da868  vmovaps [rsp+0x20], xmm2
00007d20d97da86e  vmovaps [rsp+0x30], xmm3
00007d20d97da874  vmovaps [rsp+0x40], xmm4
00007d20d97da87a  vmovaps [rsp+0x50], xmm5
00007d20d97da880  vmovaps [rsp+0x60], xmm6
00007d20d97da886  vmovaps [rsp+0x70], xmm8
00007d20d97da88c  vmovaps [rsp+0x80], xmm9
00007d20d97da895  vmovaps [rsp+0x90], xmm10
00007d20d97da89e  vmovaps [rsp+0xA0], xmm11
00007d20d97da8a7  vmovaps [rsp+0xB0], xmm12
00007d20d97da8b0  vmovaps [rsp+0xC0], xmm13
00007d20d97da8b9  vmovaps [rsp+0xD0], xmm14
00007d20d97da8c2  vmovaps [rsp+0xE0], xmm15
00007d20d97da8cb  sub rsp, 0x30
00007d20d97da8cf  movaps [rsp], xmm7
00007d20d97da8d3  movaps [rsp+0x10], xmm11
00007d20d97da8d9  movaps [rsp+0x20], xmm9
00007d20d97da8df  lea rdi, [rsp]
00007d20d97da8e3  mov esi, 0x00
00007d20d97da8e8  mov rax, 0x5EFBF4CF6530
00007d20d97da8f2  call rax
00007d20d97da8f4  movaps xmm7, [rsp]
00007d20d97da8f8  add rsp, 0x30
00007d20d97da8fc  vmovaps xmm0, [rsp]
00007d20d97da901  vmovaps xmm1, [rsp+0x10]
00007d20d97da907  vmovaps xmm2, [rsp+0x20]
00007d20d97da90d  vmovaps xmm3, [rsp+0x30]
00007d20d97da913  vmovaps xmm4, [rsp+0x40]
00007d20d97da919  vmovaps xmm5, [rsp+0x50]
00007d20d97da91f  vmovaps xmm6, [rsp+0x60]
00007d20d97da925  vmovaps xmm8, [rsp+0x70]
00007d20d97da92b  vmovaps xmm9, [rsp+0x80]
00007d20d97da934  vmovaps xmm10, [rsp+0x90]
00007d20d97da93d  vmovaps xmm11, [rsp+0xA0]
00007d20d97da946  vmovaps xmm12, [rsp+0xB0]
00007d20d97da94f  vmovaps xmm13, [rsp+0xC0]
00007d20d97da958  vmovaps xmm14, [rsp+0xD0]
00007d20d97da961  vmovaps xmm15, [rsp+0xE0]
00007d20d97da96a  add rsp, 0xF0
00007d20d97da971  pop r11
00007d20d97da973  pop r10
00007d20d97da975  pop r9
00007d20d97da977  pop r8
00007d20d97da979  pop rsi
00007d20d97da97a  pop rdi
00007d20d97da97b  pop rdx
00007d20d97da97c  pop rcx
00007d20d97da97d  pop rax
00007d20d97da97e  add rsp, 0x08
00007d20d97da982  jmp 0x00007D20D97D64D2
00007d20d97da987  sub rsp, 0x08
00007d20d97da98b  push rax
00007d20d97da98c  push rcx
00007d20d97da98d  push rdx
00007d20d97da98e  push rdi
00007d20d97da98f  push rsi
00007d20d97da990  push r8
00007d20d97da992  push r9
00007d20d97da994  push r10
00007d20d97da996  push r11
00007d20d97da998  sub rsp, 0xF0
00007d20d97da99f  vmovaps [rsp], xmm0
00007d20d97da9a4  vmovaps [rsp+0x10], xmm1
00007d20d97da9aa  vmovaps [rsp+0x20], xmm2
00007d20d97da9b0  vmovaps [rsp+0x30], xmm3
00007d20d97da9b6  vmovaps [rsp+0x40], xmm4
00007d20d97da9bc  vmovaps [rsp+0x50], xmm5
00007d20d97da9c2  vmovaps [rsp+0x60], xmm6
00007d20d97da9c8  vmovaps [rsp+0x70], xmm7
00007d20d97da9ce  vmovaps [rsp+0x80], xmm8
00007d20d97da9d7  vmovaps [rsp+0x90], xmm9
00007d20d97da9e0  vmovaps [rsp+0xA0], xmm10
00007d20d97da9e9  vmovaps [rsp+0xB0], xmm12
00007d20d97da9f2  vmovaps [rsp+0xC0], xmm13
00007d20d97da9fb  vmovaps [rsp+0xD0], xmm14
00007d20d97daa04  vmovaps [rsp+0xE0], xmm15
00007d20d97daa0d  sub rsp, 0x30
00007d20d97daa11  movaps [rsp], xmm11
00007d20d97daa16  movaps [rsp+0x10], xmm10
00007d20d97daa1c  movaps [rsp+0x20], xmm14
00007d20d97daa22  lea rdi, [rsp]
00007d20d97daa26  mov esi, 0x00
00007d20d97daa2b  mov rax, 0x5EFBF4CF6530
00007d20d97daa35  call rax
00007d20d97daa37  movaps xmm11, [rsp]
00007d20d97daa3c  add rsp, 0x30
00007d20d97daa40  vmovaps xmm0, [rsp]
00007d20d97daa45  vmovaps xmm1, [rsp+0x10]
00007d20d97daa4b  vmovaps xmm2, [rsp+0x20]
00007d20d97daa51  vmovaps xmm3, [rsp+0x30]
00007d20d97daa57  vmovaps xmm4, [rsp+0x40]
00007d20d97daa5d  vmovaps xmm5, [rsp+0x50]
00007d20d97daa63  vmovaps xmm6, [rsp+0x60]
00007d20d97daa69  vmovaps xmm7, [rsp+0x70]
00007d20d97daa6f  vmovaps xmm8, [rsp+0x80]
00007d20d97daa78  vmovaps xmm9, [rsp+0x90]
00007d20d97daa81  vmovaps xmm10, [rsp+0xA0]
00007d20d97daa8a  vmovaps xmm12, [rsp+0xB0]
00007d20d97daa93  vmovaps xmm13, [rsp+0xC0]
00007d20d97daa9c  vmovaps xmm14, [rsp+0xD0]
00007d20d97daaa5  vmovaps xmm15, [rsp+0xE0]
00007d20d97daaae  add rsp, 0xF0
00007d20d97daab5  pop r11
00007d20d97daab7  pop r10
00007d20d97daab9  pop r9
00007d20d97daabb  pop r8
00007d20d97daabd  pop rsi
00007d20d97daabe  pop rdi
00007d20d97daabf  pop rdx
00007d20d97daac0  pop rcx
00007d20d97daac1  pop rax
00007d20d97daac2  add rsp, 0x08
00007d20d97daac6  jmp 0x00007D20D97D64ED
00007d20d97daacb  call 0x00007D20D96E45A0
00007d20d97daad0  jmp 0x00007D20D97D64F7
00007d20d97daad5  sub rsp, 0x08
00007d20d97daad9  push rax
00007d20d97daada  push rcx
00007d20d97daadb  push rdx
00007d20d97daadc  push rdi
00007d20d97daadd  push rsi
00007d20d97daade  push r8
00007d20d97daae0  push r9
00007d20d97daae2  push r10
00007d20d97daae4  push r11
00007d20d97daae6  sub rsp, 0xF0
00007d20d97daaed  vmovaps [rsp], xmm0
00007d20d97daaf2  vmovaps [rsp+0x10], xmm1
00007d20d97daaf8  vmovaps [rsp+0x20], xmm2
00007d20d97daafe  vmovaps [rsp+0x30], xmm3
00007d20d97dab04  vmovaps [rsp+0x40], xmm4
00007d20d97dab0a  vmovaps [rsp+0x50], xmm5
00007d20d97dab10  vmovaps [rsp+0x60], xmm6
00007d20d97dab16  vmovaps [rsp+0x70], xmm7
00007d20d97dab1c  vmovaps [rsp+0x80], xmm8
00007d20d97dab25  vmovaps [rsp+0x90], xmm9
00007d20d97dab2e  vmovaps [rsp+0xA0], xmm11
00007d20d97dab37  vmovaps [rsp+0xB0], xmm12
00007d20d97dab40  vmovaps [rsp+0xC0], xmm13
00007d20d97dab49  vmovaps [rsp+0xD0], xmm14
00007d20d97dab52  vmovaps [rsp+0xE0], xmm15
00007d20d97dab5b  sub rsp, 0x30
00007d20d97dab5f  movaps [rsp], xmm10
00007d20d97dab64  movaps [rsp+0x10], xmm1
00007d20d97dab69  movaps [rsp+0x20], xmm12
00007d20d97dab6f  lea rdi, [rsp]
00007d20d97dab73  mov esi, 0x00
00007d20d97dab78  mov rax, 0x5EFBF4CF6530
00007d20d97dab82  call rax
00007d20d97dab84  movaps xmm10, [rsp]
00007d20d97dab89  add rsp, 0x30
00007d20d97dab8d  vmovaps xmm0, [rsp]
00007d20d97dab92  vmovaps xmm1, [rsp+0x10]
00007d20d97dab98  vmovaps xmm2, [rsp+0x20]
00007d20d97dab9e  vmovaps xmm3, [rsp+0x30]
00007d20d97daba4  vmovaps xmm4, [rsp+0x40]
00007d20d97dabaa  vmovaps xmm5, [rsp+0x50]
00007d20d97dabb0  vmovaps xmm6, [rsp+0x60]
00007d20d97dabb6  vmovaps xmm7, [rsp+0x70]
00007d20d97dabbc  vmovaps xmm8, [rsp+0x80]
00007d20d97dabc5  vmovaps xmm9, [rsp+0x90]
00007d20d97dabce  vmovaps xmm11, [rsp+0xA0]
00007d20d97dabd7  vmovaps xmm12, [rsp+0xB0]
00007d20d97dabe0  vmovaps xmm13, [rsp+0xC0]
00007d20d97dabe9  vmovaps xmm14, [rsp+0xD0]
00007d20d97dabf2  vmovaps xmm15, [rsp+0xE0]
00007d20d97dabfb  add rsp, 0xF0
00007d20d97dac02  pop r11
00007d20d97dac04  pop r10
00007d20d97dac06  pop r9
00007d20d97dac08  pop r8
00007d20d97dac0a  pop rsi
00007d20d97dac0b  pop rdi
00007d20d97dac0c  pop rdx
00007d20d97dac0d  pop rcx
00007d20d97dac0e  pop rax
00007d20d97dac0f  add rsp, 0x08
00007d20d97dac13  jmp 0x00007D20D97D651A
00007d20d97dac18  sub rsp, 0x08
00007d20d97dac1c  push rax
00007d20d97dac1d  push rcx
00007d20d97dac1e  push rdx
00007d20d97dac1f  push rdi
00007d20d97dac20  push rsi
00007d20d97dac21  push r8
00007d20d97dac23  push r9
00007d20d97dac25  push r10
00007d20d97dac27  push r11
00007d20d97dac29  sub rsp, 0xF0
00007d20d97dac30  vmovaps [rsp], xmm0
00007d20d97dac35  vmovaps [rsp+0x10], xmm1
00007d20d97dac3b  vmovaps [rsp+0x20], xmm2
00007d20d97dac41  vmovaps [rsp+0x30], xmm3
00007d20d97dac47  vmovaps [rsp+0x40], xmm4
00007d20d97dac4d  vmovaps [rsp+0x50], xmm5
00007d20d97dac53  vmovaps [rsp+0x60], xmm6
00007d20d97dac59  vmovaps [rsp+0x70], xmm7
00007d20d97dac5f  vmovaps [rsp+0x80], xmm8
00007d20d97dac68  vmovaps [rsp+0x90], xmm9
00007d20d97dac71  vmovaps [rsp+0xA0], xmm10
00007d20d97dac7a  vmovaps [rsp+0xB0], xmm11
00007d20d97dac83  vmovaps [rsp+0xC0], xmm13
00007d20d97dac8c  vmovaps [rsp+0xD0], xmm14
00007d20d97dac95  vmovaps [rsp+0xE0], xmm15
00007d20d97dac9e  sub rsp, 0x30
00007d20d97daca2  movaps [rsp], xmm12
00007d20d97daca7  movaps [rsp+0x10], xmm14
00007d20d97dacad  movaps [rsp+0x20], xmm1
00007d20d97dacb2  lea rdi, [rsp]
00007d20d97dacb6  mov esi, 0x00
00007d20d97dacbb  mov rax, 0x5EFBF4CF6530
00007d20d97dacc5  call rax
00007d20d97dacc7  movaps xmm12, [rsp]
00007d20d97daccc  add rsp, 0x30
00007d20d97dacd0  vmovaps xmm0, [rsp]
00007d20d97dacd5  vmovaps xmm1, [rsp+0x10]
00007d20d97dacdb  vmovaps xmm2, [rsp+0x20]
00007d20d97dace1  vmovaps xmm3, [rsp+0x30]
00007d20d97dace7  vmovaps xmm4, [rsp+0x40]
00007d20d97daced  vmovaps xmm5, [rsp+0x50]
00007d20d97dacf3  vmovaps xmm6, [rsp+0x60]
00007d20d97dacf9  vmovaps xmm7, [rsp+0x70]
00007d20d97dacff  vmovaps xmm8, [rsp+0x80]
00007d20d97dad08  vmovaps xmm9, [rsp+0x90]
00007d20d97dad11  vmovaps xmm10, [rsp+0xA0]
00007d20d97dad1a  vmovaps xmm11, [rsp+0xB0]
00007d20d97dad23  vmovaps xmm13, [rsp+0xC0]
00007d20d97dad2c  vmovaps xmm14, [rsp+0xD0]
00007d20d97dad35  vmovaps xmm15, [rsp+0xE0]
00007d20d97dad3e  add rsp, 0xF0
00007d20d97dad45  pop r11
00007d20d97dad47  pop r10
00007d20d97dad49  pop r9
00007d20d97dad4b  pop r8
00007d20d97dad4d  pop rsi
00007d20d97dad4e  pop rdi
00007d20d97dad4f  pop rdx
00007d20d97dad50  pop rcx
00007d20d97dad51  pop rax
00007d20d97dad52  add rsp, 0x08
00007d20d97dad56  jmp 0x00007D20D97D6549
00007d20d97dad5b  sub rsp, 0x08
00007d20d97dad5f  push rax
00007d20d97dad60  push rcx
00007d20d97dad61  push rdx
00007d20d97dad62  push rdi
00007d20d97dad63  push rsi
00007d20d97dad64  push r8
00007d20d97dad66  push r9
00007d20d97dad68  push r10
00007d20d97dad6a  push r11
00007d20d97dad6c  sub rsp, 0xF0
00007d20d97dad73  vmovaps [rsp], xmm0
00007d20d97dad78  vmovaps [rsp+0x10], xmm1
00007d20d97dad7e  vmovaps [rsp+0x20], xmm2
00007d20d97dad84  vmovaps [rsp+0x30], xmm3
00007d20d97dad8a  vmovaps [rsp+0x40], xmm4
00007d20d97dad90  vmovaps [rsp+0x50], xmm5
00007d20d97dad96  vmovaps [rsp+0x60], xmm6
00007d20d97dad9c  vmovaps [rsp+0x70], xmm7
00007d20d97dada2  vmovaps [rsp+0x80], xmm8
00007d20d97dadab  vmovaps [rsp+0x90], xmm9
00007d20d97dadb4  vmovaps [rsp+0xA0], xmm10
00007d20d97dadbd  vmovaps [rsp+0xB0], xmm11
00007d20d97dadc6  vmovaps [rsp+0xC0], xmm12
00007d20d97dadcf  vmovaps [rsp+0xD0], xmm13
00007d20d97dadd8  vmovaps [rsp+0xE0], xmm15
00007d20d97dade1  sub rsp, 0x30
00007d20d97dade5  movaps [rsp], xmm14
00007d20d97dadea  movaps [rsp+0x10], xmm9
00007d20d97dadf0  movaps [rsp+0x20], xmm1
00007d20d97dadf5  lea rdi, [rsp]
00007d20d97dadf9  mov esi, 0x00
00007d20d97dadfe  mov rax, 0x5EFBF4CF6530
00007d20d97dae08  call rax
00007d20d97dae0a  movaps xmm14, [rsp]
00007d20d97dae0f  add rsp, 0x30
00007d20d97dae13  vmovaps xmm0, [rsp]
00007d20d97dae18  vmovaps xmm1, [rsp+0x10]
00007d20d97dae1e  vmovaps xmm2, [rsp+0x20]
00007d20d97dae24  vmovaps xmm3, [rsp+0x30]
00007d20d97dae2a  vmovaps xmm4, [rsp+0x40]
00007d20d97dae30  vmovaps xmm5, [rsp+0x50]
00007d20d97dae36  vmovaps xmm6, [rsp+0x60]
00007d20d97dae3c  vmovaps xmm7, [rsp+0x70]
00007d20d97dae42  vmovaps xmm8, [rsp+0x80]
00007d20d97dae4b  vmovaps xmm9, [rsp+0x90]
00007d20d97dae54  vmovaps xmm10, [rsp+0xA0]
00007d20d97dae5d  vmovaps xmm11, [rsp+0xB0]
00007d20d97dae66  vmovaps xmm12, [rsp+0xC0]
00007d20d97dae6f  vmovaps xmm13, [rsp+0xD0]
00007d20d97dae78  vmovaps xmm15, [rsp+0xE0]
00007d20d97dae81  add rsp, 0xF0
00007d20d97dae88  pop r11
00007d20d97dae8a  pop r10
00007d20d97dae8c  pop r9
00007d20d97dae8e  pop r8
00007d20d97dae90  pop rsi
00007d20d97dae91  pop rdi
00007d20d97dae92  pop rdx
00007d20d97dae93  pop rcx
00007d20d97dae94  pop rax
00007d20d97dae95  add rsp, 0x08
00007d20d97dae99  jmp 0x00007D20D97D6578
00007d20d97dae9e  sub rsp, 0x08
00007d20d97daea2  push rax
00007d20d97daea3  push rcx
00007d20d97daea4  push rdx
00007d20d97daea5  push rdi
00007d20d97daea6  push rsi
00007d20d97daea7  push r8
00007d20d97daea9  push r9
00007d20d97daeab  push r10
00007d20d97daead  push r11
00007d20d97daeaf  sub rsp, 0xF0
00007d20d97daeb6  vmovaps [rsp], xmm0
00007d20d97daebb  vmovaps [rsp+0x10], xmm2
00007d20d97daec1  vmovaps [rsp+0x20], xmm3
00007d20d97daec7  vmovaps [rsp+0x30], xmm4
00007d20d97daecd  vmovaps [rsp+0x40], xmm5
00007d20d97daed3  vmovaps [rsp+0x50], xmm6
00007d20d97daed9  vmovaps [rsp+0x60], xmm7
00007d20d97daedf  vmovaps [rsp+0x70], xmm8
00007d20d97daee5  vmovaps [rsp+0x80], xmm9
00007d20d97daeee  vmovaps [rsp+0x90], xmm10
00007d20d97daef7  vmovaps [rsp+0xA0], xmm11
00007d20d97daf00  vmovaps [rsp+0xB0], xmm12
00007d20d97daf09  vmovaps [rsp+0xC0], xmm13
00007d20d97daf12  vmovaps [rsp+0xD0], xmm14
00007d20d97daf1b  vmovaps [rsp+0xE0], xmm15
00007d20d97daf24  sub rsp, 0x30
00007d20d97daf28  movaps [rsp], xmm1
00007d20d97daf2c  movaps [rsp+0x10], xmm13
00007d20d97daf32  movaps [rsp+0x20], xmm8
00007d20d97daf38  lea rdi, [rsp]
00007d20d97daf3c  mov esi, 0x00
00007d20d97daf41  mov rax, 0x5EFBF4CF6530
00007d20d97daf4b  call rax
00007d20d97daf4d  movaps xmm1, [rsp]
00007d20d97daf51  add rsp, 0x30
00007d20d97daf55  vmovaps xmm0, [rsp]
00007d20d97daf5a  vmovaps xmm2, [rsp+0x10]
00007d20d97daf60  vmovaps xmm3, [rsp+0x20]
00007d20d97daf66  vmovaps xmm4, [rsp+0x30]
00007d20d97daf6c  vmovaps xmm5, [rsp+0x40]
00007d20d97daf72  vmovaps xmm6, [rsp+0x50]
00007d20d97daf78  vmovaps xmm7, [rsp+0x60]
00007d20d97daf7e  vmovaps xmm8, [rsp+0x70]
00007d20d97daf84  vmovaps xmm9, [rsp+0x80]
00007d20d97daf8d  vmovaps xmm10, [rsp+0x90]
00007d20d97daf96  vmovaps xmm11, [rsp+0xA0]
00007d20d97daf9f  vmovaps xmm12, [rsp+0xB0]
00007d20d97dafa8  vmovaps xmm13, [rsp+0xC0]
00007d20d97dafb1  vmovaps xmm14, [rsp+0xD0]
00007d20d97dafba  vmovaps xmm15, [rsp+0xE0]
00007d20d97dafc3  add rsp, 0xF0
00007d20d97dafca  pop r11
00007d20d97dafcc  pop r10
00007d20d97dafce  pop r9
00007d20d97dafd0  pop r8
00007d20d97dafd2  pop rsi
00007d20d97dafd3  pop rdi
00007d20d97dafd4  pop rdx
00007d20d97dafd5  pop rcx
00007d20d97dafd6  pop rax
00007d20d97dafd7  add rsp, 0x08
00007d20d97dafdb  jmp 0x00007D20D97D659A
00007d20d97dafe0  call 0x00007D20D960C260
00007d20d97dafe5  jmp 0x00007D20D97D65A8
00007d20d97dafea  call 0x00007D20D96DE950
00007d20d97dafef  jmp 0x00007D20D97D65B2
00007d20d97daff4  sub rsp, 0x08
00007d20d97daff8  push rax
00007d20d97daff9  push rcx
00007d20d97daffa  push rdx
00007d20d97daffb  push rdi
00007d20d97daffc  push rsi
00007d20d97daffd  push r8
00007d20d97dafff  push r9
00007d20d97db001  push r10
00007d20d97db003  push r11
00007d20d97db005  sub rsp, 0xF0
00007d20d97db00c  vmovaps [rsp], xmm0
00007d20d97db011  vmovaps [rsp+0x10], xmm1
00007d20d97db017  vmovaps [rsp+0x20], xmm2
00007d20d97db01d  vmovaps [rsp+0x30], xmm3
00007d20d97db023  vmovaps [rsp+0x40], xmm4
00007d20d97db029  vmovaps [rsp+0x50], xmm5
00007d20d97db02f  vmovaps [rsp+0x60], xmm6
00007d20d97db035  vmovaps [rsp+0x70], xmm7
00007d20d97db03b  vmovaps [rsp+0x80], xmm9
00007d20d97db044  vmovaps [rsp+0x90], xmm10
00007d20d97db04d  vmovaps [rsp+0xA0], xmm11
00007d20d97db056  vmovaps [rsp+0xB0], xmm12
00007d20d97db05f  vmovaps [rsp+0xC0], xmm13
00007d20d97db068  vmovaps [rsp+0xD0], xmm14
00007d20d97db071  vmovaps [rsp+0xE0], xmm15
00007d20d97db07a  sub rsp, 0x30
00007d20d97db07e  movaps [rsp], xmm8
00007d20d97db083  movaps [rsp+0x10], xmm15
00007d20d97db089  movaps [rsp+0x20], xmm7
00007d20d97db08e  lea rdi, [rsp]
00007d20d97db092  mov esi, 0x00
00007d20d97db097  mov rax, 0x5EFBF4CF6530
00007d20d97db0a1  call rax
00007d20d97db0a3  movaps xmm8, [rsp]
00007d20d97db0a8  add rsp, 0x30
00007d20d97db0ac  vmovaps xmm0, [rsp]
00007d20d97db0b1  vmovaps xmm1, [rsp+0x10]
00007d20d97db0b7  vmovaps xmm2, [rsp+0x20]
00007d20d97db0bd  vmovaps xmm3, [rsp+0x30]
00007d20d97db0c3  vmovaps xmm4, [rsp+0x40]
00007d20d97db0c9  vmovaps xmm5, [rsp+0x50]
00007d20d97db0cf  vmovaps xmm6, [rsp+0x60]
00007d20d97db0d5  vmovaps xmm7, [rsp+0x70]
00007d20d97db0db  vmovaps xmm9, [rsp+0x80]
00007d20d97db0e4  vmovaps xmm10, [rsp+0x90]
00007d20d97db0ed  vmovaps xmm11, [rsp+0xA0]
00007d20d97db0f6  vmovaps xmm12, [rsp+0xB0]
00007d20d97db0ff  vmovaps xmm13, [rsp+0xC0]
00007d20d97db108  vmovaps xmm14, [rsp+0xD0]
00007d20d97db111  vmovaps xmm15, [rsp+0xE0]
00007d20d97db11a  add rsp, 0xF0
00007d20d97db121  pop r11
00007d20d97db123  pop r10
00007d20d97db125  pop r9
00007d20d97db127  pop r8
00007d20d97db129  pop rsi
00007d20d97db12a  pop rdi
00007d20d97db12b  pop rdx
00007d20d97db12c  pop rcx
00007d20d97db12d  pop rax
00007d20d97db12e  add rsp, 0x08
00007d20d97db132  jmp 0x00007D20D97D65D4
00007d20d97db137  sub rsp, 0x08
00007d20d97db13b  push rax
00007d20d97db13c  push rcx
00007d20d97db13d  push rdx
00007d20d97db13e  push rdi
00007d20d97db13f  push rsi
00007d20d97db140  push r8
00007d20d97db142  push r9
00007d20d97db144  push r10
00007d20d97db146  push r11
00007d20d97db148  sub rsp, 0xF0
00007d20d97db14f  vmovaps [rsp], xmm0
00007d20d97db154  vmovaps [rsp+0x10], xmm1
00007d20d97db15a  vmovaps [rsp+0x20], xmm2
00007d20d97db160  vmovaps [rsp+0x30], xmm3
00007d20d97db166  vmovaps [rsp+0x40], xmm4
00007d20d97db16c  vmovaps [rsp+0x50], xmm5
00007d20d97db172  vmovaps [rsp+0x60], xmm6
00007d20d97db178  vmovaps [rsp+0x70], xmm8
00007d20d97db17e  vmovaps [rsp+0x80], xmm9
00007d20d97db187  vmovaps [rsp+0x90], xmm10
00007d20d97db190  vmovaps [rsp+0xA0], xmm11
00007d20d97db199  vmovaps [rsp+0xB0], xmm12
00007d20d97db1a2  vmovaps [rsp+0xC0], xmm13
00007d20d97db1ab  vmovaps [rsp+0xD0], xmm14
00007d20d97db1b4  vmovaps [rsp+0xE0], xmm15
00007d20d97db1bd  sub rsp, 0x30
00007d20d97db1c1  movaps [rsp], xmm7
00007d20d97db1c5  movaps [rsp+0x10], xmm9
00007d20d97db1cb  movaps [rsp+0x20], xmm15
00007d20d97db1d1  lea rdi, [rsp]
00007d20d97db1d5  mov esi, 0x00
00007d20d97db1da  mov rax, 0x5EFBF4CF6530
00007d20d97db1e4  call rax
00007d20d97db1e6  movaps xmm7, [rsp]
00007d20d97db1ea  add rsp, 0x30
00007d20d97db1ee  vmovaps xmm0, [rsp]
00007d20d97db1f3  vmovaps xmm1, [rsp+0x10]
00007d20d97db1f9  vmovaps xmm2, [rsp+0x20]
00007d20d97db1ff  vmovaps xmm3, [rsp+0x30]
00007d20d97db205  vmovaps xmm4, [rsp+0x40]
00007d20d97db20b  vmovaps xmm5, [rsp+0x50]
00007d20d97db211  vmovaps xmm6, [rsp+0x60]
00007d20d97db217  vmovaps xmm8, [rsp+0x70]
00007d20d97db21d  vmovaps xmm9, [rsp+0x80]
00007d20d97db226  vmovaps xmm10, [rsp+0x90]
00007d20d97db22f  vmovaps xmm11, [rsp+0xA0]
00007d20d97db238  vmovaps xmm12, [rsp+0xB0]
00007d20d97db241  vmovaps xmm13, [rsp+0xC0]
00007d20d97db24a  vmovaps xmm14, [rsp+0xD0]
00007d20d97db253  vmovaps xmm15, [rsp+0xE0]
00007d20d97db25c  add rsp, 0xF0
00007d20d97db263  pop r11
00007d20d97db265  pop r10
00007d20d97db267  pop r9
00007d20d97db269  pop r8
00007d20d97db26b  pop rsi
00007d20d97db26c  pop rdi
00007d20d97db26d  pop rdx
00007d20d97db26e  pop rcx
00007d20d97db26f  pop rax
00007d20d97db270  add rsp, 0x08
00007d20d97db274  jmp 0x00007D20D97D6601
00007d20d97db279  sub rsp, 0x08
00007d20d97db27d  push rax
00007d20d97db27e  push rcx
00007d20d97db27f  push rdx
00007d20d97db280  push rdi
00007d20d97db281  push rsi
00007d20d97db282  push r8
00007d20d97db284  push r9
00007d20d97db286  push r10
00007d20d97db288  push r11
00007d20d97db28a  sub rsp, 0xF0
00007d20d97db291  vmovaps [rsp], xmm0
00007d20d97db296  vmovaps [rsp+0x10], xmm1
00007d20d97db29c  vmovaps [rsp+0x20], xmm2
00007d20d97db2a2  vmovaps [rsp+0x30], xmm3
00007d20d97db2a8  vmovaps [rsp+0x40], xmm4
00007d20d97db2ae  vmovaps [rsp+0x50], xmm5
00007d20d97db2b4  vmovaps [rsp+0x60], xmm6
00007d20d97db2ba  vmovaps [rsp+0x70], xmm7
00007d20d97db2c0  vmovaps [rsp+0x80], xmm8
00007d20d97db2c9  vmovaps [rsp+0x90], xmm10
00007d20d97db2d2  vmovaps [rsp+0xA0], xmm11
00007d20d97db2db  vmovaps [rsp+0xB0], xmm12
00007d20d97db2e4  vmovaps [rsp+0xC0], xmm13
00007d20d97db2ed  vmovaps [rsp+0xD0], xmm14
00007d20d97db2f6  vmovaps [rsp+0xE0], xmm15
00007d20d97db2ff  sub rsp, 0x30
00007d20d97db303  movaps [rsp], xmm9
00007d20d97db308  movaps [rsp+0x10], xmm13
00007d20d97db30e  movaps [rsp+0x20], xmm15
00007d20d97db314  lea rdi, [rsp]
00007d20d97db318  mov esi, 0x00
00007d20d97db31d  mov rax, 0x5EFBF4CF6530
00007d20d97db327  call rax
00007d20d97db329  movaps xmm9, [rsp]
00007d20d97db32e  add rsp, 0x30
00007d20d97db332  vmovaps xmm0, [rsp]
00007d20d97db337  vmovaps xmm1, [rsp+0x10]
00007d20d97db33d  vmovaps xmm2, [rsp+0x20]
00007d20d97db343  vmovaps xmm3, [rsp+0x30]
00007d20d97db349  vmovaps xmm4, [rsp+0x40]
00007d20d97db34f  vmovaps xmm5, [rsp+0x50]
00007d20d97db355  vmovaps xmm6, [rsp+0x60]
00007d20d97db35b  vmovaps xmm7, [rsp+0x70]
00007d20d97db361  vmovaps xmm8, [rsp+0x80]
00007d20d97db36a  vmovaps xmm10, [rsp+0x90]
00007d20d97db373  vmovaps xmm11, [rsp+0xA0]
00007d20d97db37c  vmovaps xmm12, [rsp+0xB0]
00007d20d97db385  vmovaps xmm13, [rsp+0xC0]
00007d20d97db38e  vmovaps xmm14, [rsp+0xD0]
00007d20d97db397  vmovaps xmm15, [rsp+0xE0]
00007d20d97db3a0  add rsp, 0xF0
00007d20d97db3a7  pop r11
00007d20d97db3a9  pop r10
00007d20d97db3ab  pop r9
00007d20d97db3ad  pop r8
00007d20d97db3af  pop rsi
00007d20d97db3b0  pop rdi
00007d20d97db3b1  pop rdx
00007d20d97db3b2  pop rcx
00007d20d97db3b3  pop rax
00007d20d97db3b4  add rsp, 0x08
00007d20d97db3b8  jmp 0x00007D20D97D662F
00007d20d97db3bd  sub rsp, 0x08
00007d20d97db3c1  push rax
00007d20d97db3c2  push rcx
00007d20d97db3c3  push rdx
00007d20d97db3c4  push rdi
00007d20d97db3c5  push rsi
00007d20d97db3c6  push r8
00007d20d97db3c8  push r9
00007d20d97db3ca  push r10
00007d20d97db3cc  push r11
00007d20d97db3ce  sub rsp, 0xF0
00007d20d97db3d5  vmovaps [rsp], xmm0
00007d20d97db3da  vmovaps [rsp+0x10], xmm1
00007d20d97db3e0  vmovaps [rsp+0x20], xmm2
00007d20d97db3e6  vmovaps [rsp+0x30], xmm3
00007d20d97db3ec  vmovaps [rsp+0x40], xmm4
00007d20d97db3f2  vmovaps [rsp+0x50], xmm5
00007d20d97db3f8  vmovaps [rsp+0x60], xmm6
00007d20d97db3fe  vmovaps [rsp+0x70], xmm7
00007d20d97db404  vmovaps [rsp+0x80], xmm8
00007d20d97db40d  vmovaps [rsp+0x90], xmm9
00007d20d97db416  vmovaps [rsp+0xA0], xmm10
00007d20d97db41f  vmovaps [rsp+0xB0], xmm11
00007d20d97db428  vmovaps [rsp+0xC0], xmm12
00007d20d97db431  vmovaps [rsp+0xD0], xmm13
00007d20d97db43a  vmovaps [rsp+0xE0], xmm14
00007d20d97db443  sub rsp, 0x30
00007d20d97db447  movaps [rsp], xmm15
00007d20d97db44c  movaps [rsp+0x10], xmm11
00007d20d97db452  movaps [rsp+0x20], xmm12
00007d20d97db458  lea rdi, [rsp]
00007d20d97db45c  mov esi, 0x00
00007d20d97db461  mov rax, 0x5EFBF4CF6530
00007d20d97db46b  call rax
00007d20d97db46d  movaps xmm15, [rsp]
00007d20d97db472  add rsp, 0x30
00007d20d97db476  vmovaps xmm0, [rsp]
00007d20d97db47b  vmovaps xmm1, [rsp+0x10]
00007d20d97db481  vmovaps xmm2, [rsp+0x20]
00007d20d97db487  vmovaps xmm3, [rsp+0x30]
00007d20d97db48d  vmovaps xmm4, [rsp+0x40]
00007d20d97db493  vmovaps xmm5, [rsp+0x50]
00007d20d97db499  vmovaps xmm6, [rsp+0x60]
00007d20d97db49f  vmovaps xmm7, [rsp+0x70]
00007d20d97db4a5  vmovaps xmm8, [rsp+0x80]
00007d20d97db4ae  vmovaps xmm9, [rsp+0x90]
00007d20d97db4b7  vmovaps xmm10, [rsp+0xA0]
00007d20d97db4c0  vmovaps xmm11, [rsp+0xB0]
00007d20d97db4c9  vmovaps xmm12, [rsp+0xC0]
00007d20d97db4d2  vmovaps xmm13, [rsp+0xD0]
00007d20d97db4db  vmovaps xmm14, [rsp+0xE0]
00007d20d97db4e4  add rsp, 0xF0
00007d20d97db4eb  pop r11
00007d20d97db4ed  pop r10
00007d20d97db4ef  pop r9
00007d20d97db4f1  pop r8
00007d20d97db4f3  pop rsi
00007d20d97db4f4  pop rdi
00007d20d97db4f5  pop rdx
00007d20d97db4f6  pop rcx
00007d20d97db4f7  pop rax
00007d20d97db4f8  add rsp, 0x08
00007d20d97db4fc  jmp 0x00007D20D97D664A
00007d20d97db501  sub rsp, 0x08
00007d20d97db505  push rax
00007d20d97db506  push rcx
00007d20d97db507  push rdx
00007d20d97db508  push rdi
00007d20d97db509  push rsi
00007d20d97db50a  push r8
00007d20d97db50c  push r9
00007d20d97db50e  push r10
00007d20d97db510  push r11
00007d20d97db512  sub rsp, 0xF0
00007d20d97db519  vmovaps [rsp], xmm0
00007d20d97db51e  vmovaps [rsp+0x10], xmm1
00007d20d97db524  vmovaps [rsp+0x20], xmm2
00007d20d97db52a  vmovaps [rsp+0x30], xmm3
00007d20d97db530  vmovaps [rsp+0x40], xmm4
00007d20d97db536  vmovaps [rsp+0x50], xmm5
00007d20d97db53c  vmovaps [rsp+0x60], xmm6
00007d20d97db542  vmovaps [rsp+0x70], xmm7
00007d20d97db548  vmovaps [rsp+0x80], xmm8
00007d20d97db551  vmovaps [rsp+0x90], xmm9
00007d20d97db55a  vmovaps [rsp+0xA0], xmm10
00007d20d97db563  vmovaps [rsp+0xB0], xmm11
00007d20d97db56c  vmovaps [rsp+0xC0], xmm12
00007d20d97db575  vmovaps [rsp+0xD0], xmm14
00007d20d97db57e  vmovaps [rsp+0xE0], xmm15
00007d20d97db587  sub rsp, 0x30
00007d20d97db58b  movaps [rsp], xmm13
00007d20d97db590  movaps [rsp+0x10], xmm10
00007d20d97db596  movaps [rsp+0x20], xmm14
00007d20d97db59c  lea rdi, [rsp]
00007d20d97db5a0  mov esi, 0x00
00007d20d97db5a5  mov rax, 0x5EFBF4CF6530
00007d20d97db5af  call rax
00007d20d97db5b1  movaps xmm13, [rsp]
00007d20d97db5b6  add rsp, 0x30
00007d20d97db5ba  vmovaps xmm0, [rsp]
00007d20d97db5bf  vmovaps xmm1, [rsp+0x10]
00007d20d97db5c5  vmovaps xmm2, [rsp+0x20]
00007d20d97db5cb  vmovaps xmm3, [rsp+0x30]
00007d20d97db5d1  vmovaps xmm4, [rsp+0x40]
00007d20d97db5d7  vmovaps xmm5, [rsp+0x50]
00007d20d97db5dd  vmovaps xmm6, [rsp+0x60]
00007d20d97db5e3  vmovaps xmm7, [rsp+0x70]
00007d20d97db5e9  vmovaps xmm8, [rsp+0x80]
00007d20d97db5f2  vmovaps xmm9, [rsp+0x90]
00007d20d97db5fb  vmovaps xmm10, [rsp+0xA0]
00007d20d97db604  vmovaps xmm11, [rsp+0xB0]
00007d20d97db60d  vmovaps xmm12, [rsp+0xC0]
00007d20d97db616  vmovaps xmm14, [rsp+0xD0]
00007d20d97db61f  vmovaps xmm15, [rsp+0xE0]
00007d20d97db628  add rsp, 0xF0
00007d20d97db62f  pop r11
00007d20d97db631  pop r10
00007d20d97db633  pop r9
00007d20d97db635  pop r8
00007d20d97db637  pop rsi
00007d20d97db638  pop rdi
00007d20d97db639  pop rdx
00007d20d97db63a  pop rcx
00007d20d97db63b  pop rax
00007d20d97db63c  add rsp, 0x08
00007d20d97db640  jmp 0x00007D20D97D666D
00007d20d97db645  sub rsp, 0x08
00007d20d97db649  push rax
00007d20d97db64a  push rcx
00007d20d97db64b  push rdx
00007d20d97db64c  push rdi
00007d20d97db64d  push rsi
00007d20d97db64e  push r8
00007d20d97db650  push r9
00007d20d97db652  push r10
00007d20d97db654  push r11
00007d20d97db656  sub rsp, 0xF0
00007d20d97db65d  vmovaps [rsp], xmm0
00007d20d97db662  vmovaps [rsp+0x10], xmm1
00007d20d97db668  vmovaps [rsp+0x20], xmm2
00007d20d97db66e  vmovaps [rsp+0x30], xmm3
00007d20d97db674  vmovaps [rsp+0x40], xmm4
00007d20d97db67a  vmovaps [rsp+0x50], xmm5
00007d20d97db680  vmovaps [rsp+0x60], xmm6
00007d20d97db686  vmovaps [rsp+0x70], xmm7
00007d20d97db68c  vmovaps [rsp+0x80], xmm8
00007d20d97db695  vmovaps [rsp+0x90], xmm9
00007d20d97db69e  vmovaps [rsp+0xA0], xmm10
00007d20d97db6a7  vmovaps [rsp+0xB0], xmm11
00007d20d97db6b0  vmovaps [rsp+0xC0], xmm12
00007d20d97db6b9  vmovaps [rsp+0xD0], xmm13
00007d20d97db6c2  vmovaps [rsp+0xE0], xmm15
00007d20d97db6cb  sub rsp, 0x30
00007d20d97db6cf  movaps [rsp], xmm14
00007d20d97db6d4  movaps [rsp+0x10], xmm1
00007d20d97db6d9  movaps [rsp+0x20], xmm7
00007d20d97db6de  lea rdi, [rsp]
00007d20d97db6e2  mov esi, 0x00
00007d20d97db6e7  mov rax, 0x5EFBF4CF6530
00007d20d97db6f1  call rax
00007d20d97db6f3  movaps xmm14, [rsp]
00007d20d97db6f8  add rsp, 0x30
00007d20d97db6fc  vmovaps xmm0, [rsp]
00007d20d97db701  vmovaps xmm1, [rsp+0x10]
00007d20d97db707  vmovaps xmm2, [rsp+0x20]
00007d20d97db70d  vmovaps xmm3, [rsp+0x30]
00007d20d97db713  vmovaps xmm4, [rsp+0x40]
00007d20d97db719  vmovaps xmm5, [rsp+0x50]
00007d20d97db71f  vmovaps xmm6, [rsp+0x60]
00007d20d97db725  vmovaps xmm7, [rsp+0x70]
00007d20d97db72b  vmovaps xmm8, [rsp+0x80]
00007d20d97db734  vmovaps xmm9, [rsp+0x90]
00007d20d97db73d  vmovaps xmm10, [rsp+0xA0]
00007d20d97db746  vmovaps xmm11, [rsp+0xB0]
00007d20d97db74f  vmovaps xmm12, [rsp+0xC0]
00007d20d97db758  vmovaps xmm13, [rsp+0xD0]
00007d20d97db761  vmovaps xmm15, [rsp+0xE0]
00007d20d97db76a  add rsp, 0xF0
00007d20d97db771  pop r11
00007d20d97db773  pop r10
00007d20d97db775  pop r9
00007d20d97db777  pop r8
00007d20d97db779  pop rsi
00007d20d97db77a  pop rdi
00007d20d97db77b  pop rdx
00007d20d97db77c  pop rcx
00007d20d97db77d  pop rax
00007d20d97db77e  add rsp, 0x08
00007d20d97db782  jmp 0x00007D20D97D6690
00007d20d97db787  sub rsp, 0x08
00007d20d97db78b  push rax
00007d20d97db78c  push rcx
00007d20d97db78d  push rdx
00007d20d97db78e  push rdi
00007d20d97db78f  push rsi
00007d20d97db790  push r8
00007d20d97db792  push r9
00007d20d97db794  push r10
00007d20d97db796  push r11
00007d20d97db798  sub rsp, 0xF0
00007d20d97db79f  vmovaps [rsp], xmm0
00007d20d97db7a4  vmovaps [rsp+0x10], xmm2
00007d20d97db7aa  vmovaps [rsp+0x20], xmm3
00007d20d97db7b0  vmovaps [rsp+0x30], xmm4
00007d20d97db7b6  vmovaps [rsp+0x40], xmm5
00007d20d97db7bc  vmovaps [rsp+0x50], xmm6
00007d20d97db7c2  vmovaps [rsp+0x60], xmm7
00007d20d97db7c8  vmovaps [rsp+0x70], xmm8
00007d20d97db7ce  vmovaps [rsp+0x80], xmm9
00007d20d97db7d7  vmovaps [rsp+0x90], xmm10
00007d20d97db7e0  vmovaps [rsp+0xA0], xmm11
00007d20d97db7e9  vmovaps [rsp+0xB0], xmm12
00007d20d97db7f2  vmovaps [rsp+0xC0], xmm13
00007d20d97db7fb  vmovaps [rsp+0xD0], xmm14
00007d20d97db804  vmovaps [rsp+0xE0], xmm15
00007d20d97db80d  sub rsp, 0x30
00007d20d97db811  movaps [rsp], xmm1
00007d20d97db815  movaps [rsp+0x10], xmm8
00007d20d97db81b  movaps [rsp+0x20], xmm9
00007d20d97db821  lea rdi, [rsp]
00007d20d97db825  mov esi, 0x00
00007d20d97db82a  mov rax, 0x5EFBF4CF6530
00007d20d97db834  call rax
00007d20d97db836  movaps xmm1, [rsp]
00007d20d97db83a  add rsp, 0x30
00007d20d97db83e  vmovaps xmm0, [rsp]
00007d20d97db843  vmovaps xmm2, [rsp+0x10]
00007d20d97db849  vmovaps xmm3, [rsp+0x20]
00007d20d97db84f  vmovaps xmm4, [rsp+0x30]
00007d20d97db855  vmovaps xmm5, [rsp+0x40]
00007d20d97db85b  vmovaps xmm6, [rsp+0x50]
00007d20d97db861  vmovaps xmm7, [rsp+0x60]
00007d20d97db867  vmovaps xmm8, [rsp+0x70]
00007d20d97db86d  vmovaps xmm9, [rsp+0x80]
00007d20d97db876  vmovaps xmm10, [rsp+0x90]
00007d20d97db87f  vmovaps xmm11, [rsp+0xA0]
00007d20d97db888  vmovaps xmm12, [rsp+0xB0]
00007d20d97db891  vmovaps xmm13, [rsp+0xC0]
00007d20d97db89a  vmovaps xmm14, [rsp+0xD0]
00007d20d97db8a3  vmovaps xmm15, [rsp+0xE0]
00007d20d97db8ac  add rsp, 0xF0
00007d20d97db8b3  pop r11
00007d20d97db8b5  pop r10
00007d20d97db8b7  pop r9
00007d20d97db8b9  pop r8
00007d20d97db8bb  pop rsi
00007d20d97db8bc  pop rdi
00007d20d97db8bd  pop rdx
00007d20d97db8be  pop rcx
00007d20d97db8bf  pop rax
00007d20d97db8c0  add rsp, 0x08
00007d20d97db8c4  jmp 0x00007D20D97D66B2
00007d20d97db8c9  call 0x00007D20D96B3E40
00007d20d97db8ce  jmp 0x00007D20D97D66C0
00007d20d97db8d3  call 0x00007D20D960C380
00007d20d97db8d8  jmp 0x00007D20D97D66CA
00007d20d97db8dd  call 0x00007D20D960D600
00007d20d97db8e2  jmp 0x00007D20D97D66D4
00007d20d97db8e7  call 0x00007D20D95FF540
00007d20d97db8ec  jmp 0x00007D20D97D66DE
00007d20d97db8f1  int3
00007d20d97db8f2  nop [rax+rax*1], ax
00007d20d97db8fb  nop [rax+rax*1], eax
00007d20d97db900  mov eax, [r15+0x48]
00007d20d97db904  lea r14d, [eax+0x01]
00007d20d97db909  mov [rsp+0x10], r14d
00007d20d97db90e  mov r14d, r14d
00007d20d97db911  mov [r15+0x48], r14
00007d20d97db915  xor eax, eax
00007d20d97db917  mov r14d, [rsp+0x10]
00007d20d97db91c  cmp r14d, 0x1F4
00007d20d97db923  cmc
00007d20d97db924  lahf
00007d20d97db925  seto al
00007d20d97db928  mov [r15+0x108], eax
00007d20d97db92f  mov eax, [r15+0x108]
00007d20d97db936  sahf
00007d20d97db937  jnz 0x00007D20D97DB969
00007d20d97db939  cmp dword ptr [r15+0x318], 0x00
00007d20d97db941  jz 0x00007D20D97E1AB0
00007d20d97db947  nop [rax+rax*1], ax
00007d20d97db950  nop [rax+rax*1], eax
00007d20d97db958  mov eax, 0x410450
00007d20d97db95d  mov [r15+0x100], rax
00007d20d97db964  jmp 0x00007D20D95FE110
00007d20d97db969  cmp dword ptr [r15+0x318], 0x00
00007d20d97db971  jz 0x00007D20D97DB9A0
00007d20d97db977  nop [rax+rax*1], ax
00007d20d97db980  nop [rax+rax*1], eax
00007d20d97db988  mov eax, 0x410274
00007d20d97db98d  mov [r15+0x100], rax
00007d20d97db994  jmp 0x00007D20D95FE110
00007d20d97db999  int3
00007d20d97db99a  int3
00007d20d97db99b  nop [rax+rax*1], eax
00007d20d97db9a0  mov rax, [r15+0x40]
00007d20d97db9a4  movaps xmm1, [r15+0x1D0]
00007d20d97db9ac  vmovaps [rsp+0x10], xmm1
00007d20d97db9b2  vmovaps xmm15, [rsp+0x10]
00007d20d97db9b8  por xmm1, xmm15
00007d20d97db9bd  movaps xmm14, [r15+0x1A0]
00007d20d97db9c5  vmovaps [rsp+0x10], xmm14
00007d20d97db9cb  vmovaps xmm13, [rsp+0x10]
00007d20d97db9d1  por xmm14, xmm13
00007d20d97db9d6  lea r14, [rax+0x30]
00007d20d97db9da  mov r12, [r13+r14*1]
00007d20d97db9df  lea r14, [rax+0x38]
00007d20d97db9e3  mov r11, [r13+r14*1]
00007d20d97db9e8  movq xmm13, r12
00007d20d97db9ed  movq xmm12, r11
00007d20d97db9f2  movq xmm13, xmm13
00007d20d97db9f7  vmovaps [rsp+0x10], xmm13
00007d20d97db9fd  movq xmm13, xmm13
00007d20d97dba02  movaps [r15+0x130], xmm13
00007d20d97dba0a  movq xmm12, xmm12
00007d20d97dba0f  vmovaps [rsp+0x20], xmm12
00007d20d97dba15  movq xmm12, xmm12
00007d20d97dba1a  movaps [r15+0x280], xmm12
00007d20d97dba22  movaps xmm13, [r15+0x270]
00007d20d97dba2a  vmovaps [rsp+0x30], xmm13
00007d20d97dba30  vmovaps xmm12, [rsp+0x30]
00007d20d97dba36  por xmm13, xmm12
00007d20d97dba3b  lea r14, [rax+0x20]
00007d20d97dba3f  mov r12, [r13+r14*1]
00007d20d97dba44  lea r14, [rax+0x28]
00007d20d97dba48  mov r11, [r13+r14*1]
00007d20d97dba4d  movq xmm12, r12
00007d20d97dba52  movq xmm11, r11
00007d20d97dba57  movq xmm12, xmm12
00007d20d97dba5c  vmovaps [rsp+0x30], xmm12
00007d20d97dba62  movq xmm12, xmm12
00007d20d97dba67  movaps [r15+0x150], xmm12
00007d20d97dba6f  movq xmm11, xmm11
00007d20d97dba74  vmovaps [rsp+0x40], xmm11
00007d20d97dba7a  movq xmm11, xmm11
00007d20d97dba7f  movaps [r15+0x140], xmm11
00007d20d97dba87  lea r14, [rax+0x10]
00007d20d97dba8b  mov r12, [r13+r14*1]
00007d20d97dba90  lea r14, [rax+0x18]
00007d20d97dba94  mov r11, [r13+r14*1]
00007d20d97dba99  movq xmm12, r12
00007d20d97dba9e  movq xmm11, r11
00007d20d97dbaa3  movq xmm12, xmm12
00007d20d97dbaa8  vmovaps [rsp+0x50], xmm12
00007d20d97dbaae  movq xmm12, xmm12
00007d20d97dbab3  movaps [r15+0x170], xmm12
00007d20d97dbabb  movq xmm11, xmm11
00007d20d97dbac0  vmovaps [rsp+0x60], xmm11
00007d20d97dbac6  movq xmm11, xmm11
00007d20d97dbacb  movaps [r15+0x160], xmm11
00007d20d97dbad3  mov r14, [r13+rax*1]
00007d20d97dbad8  vmovq xmm12, r14
00007d20d97dbadd  vpbroadcastq xmm12, xmm12
00007d20d97dbae2  lea r14, [rax+0x08]
00007d20d97dbae6  mov rax, [r13+r14*1]
00007d20d97dbaeb  movq xmm11, rax
00007d20d97dbaf0  movaps [r15+0x230], xmm11
00007d20d97dbaf8  mov rax, [r15+0xF8]
00007d20d97dbaff  lea r14, [rax+0x50]
00007d20d97dbb03  movups xmm11, [r13+r14*1]
00007d20d97dbb09  lea r14, [rax+0x60]
00007d20d97dbb0d  movups xmm10, [r13+r14*1]
00007d20d97dbb13  lea r14, [rax+0x30]
00007d20d97dbb17  movups xmm9, [r13+r14*1]
00007d20d97dbb1d  mov r14, [r15+0x50]
00007d20d97dbb21  mov [r15+0x60], r14
00007d20d97dbb25  mov qword ptr [r15+0x58], 0x40
00007d20d97dbb2d  movaps xmm8, xmm12
00007d20d97dbb31  mulpd xmm8, xmm15
00007d20d97dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007d20d97dbb3c  ptest xmm7, xmm7
00007d20d97dbb41  jnz 0x00007D20D97DC96A
00007d20d97dbb47  movq xmm15, qword ptr [r15+0x230]
00007d20d97dbb50  vmovaps [rsp+0x70], xmm15
00007d20d97dbb56  vpermilpd xmm15, xmm15, 0x00
00007d20d97dbb5c  movaps xmm7, xmm9
00007d20d97dbb60  mulpd xmm7, xmm15
00007d20d97dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007d20d97dbb6a  ptest xmm6, xmm6
00007d20d97dbb6f  jnz 0x00007D20D97DCAAE
00007d20d97dbb75  vxorps xmm15, xmm15, xmm15
00007d20d97dbb7a  vpbroadcastq xmm15, xmm15
00007d20d97dbb7f  movaps xmm9, xmm12
00007d20d97dbb83  mulpd xmm9, xmm10
00007d20d97dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007d20d97dbb8e  ptest xmm6, xmm6
00007d20d97dbb93  jnz 0x00007D20D97DCBF0
00007d20d97dbb99  movaps xmm10, xmm12
00007d20d97dbb9d  mulpd xmm10, xmm11
00007d20d97dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007d20d97dbba8  ptest xmm6, xmm6
00007d20d97dbbad  jnz 0x00007D20D97DCD34
00007d20d97dbbb3  movaps xmm11, [r15+0x1F0]
00007d20d97dbbbb  movaps xmm6, xmm12
00007d20d97dbbbf  mulpd xmm6, xmm11
00007d20d97dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d20d97dbbc9  ptest xmm5, xmm5
00007d20d97dbbce  jnz 0x00007D20D97DCE78
00007d20d97dbbd4  movaps xmm12, [r15+0x2A0]
00007d20d97dbbdc  vmovaps [rsp+0x80], xmm12
00007d20d97dbbe5  vmovaps xmm11, [rsp+0x80]
00007d20d97dbbee  por xmm12, xmm11
00007d20d97dbbf3  movaps xmm11, [r15+0x250]
00007d20d97dbbfb  vmovaps [rsp+0x80], xmm11
00007d20d97dbc04  vmovaps xmm5, [rsp+0x80]
00007d20d97dbc0d  por xmm11, xmm5
00007d20d97dbc12  vmovaps xmm4, [rsp+0x70]
00007d20d97dbc18  vpermilpd xmm4, xmm4, 0x00
00007d20d97dbc1e  movaps xmm3, xmm5
00007d20d97dbc21  mulpd xmm3, xmm4
00007d20d97dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007d20d97dbc2a  ptest xmm2, xmm2
00007d20d97dbc2f  jnz 0x00007D20D97DCFBA
00007d20d97dbc35  mov [rsp+0x80], rax
00007d20d97dbc3d  xor eax, eax
00007d20d97dbc3f  mov r12d, 0x40
00007d20d97dbc45  mov r11d, 0x200
00007d20d97dbc4b  cmp r12, r11
00007d20d97dbc4e  cmc
00007d20d97dbc4f  lahf
00007d20d97dbc50  seto al
00007d20d97dbc53  mov [r15+0x108], eax
00007d20d97dbc5a  movaps xmm5, xmm8
00007d20d97dbc5e  addpd xmm5, xmm15
00007d20d97dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007d20d97dbc68  ptest xmm4, xmm4
00007d20d97dbc6d  jnz 0x00007D20D97DD0FA
00007d20d97dbc73  movaps xmm8, [r15+0x1B0]
00007d20d97dbc7b  movaps xmm4, xmm9
00007d20d97dbc7f  addpd xmm4, xmm8
00007d20d97dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007d20d97dbc89  ptest xmm2, xmm2
00007d20d97dbc8e  jnz 0x00007D20D97DD23C
00007d20d97dbc94  movaps xmm9, xmm10
00007d20d97dbc98  addpd xmm9, xmm8
00007d20d97dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d20d97dbca3  ptest xmm2, xmm2
00007d20d97dbca8  jnz 0x00007D20D97DD37E
00007d20d97dbcae  movaps xmm10, [r15+0x2F0]
00007d20d97dbcb6  vmovaps [rsp+0x90], xmm10
00007d20d97dbcbf  vmovaps xmm8, [rsp+0x90]
00007d20d97dbcc8  por xmm10, xmm8
00007d20d97dbccd  movaps xmm8, [r15+0x2E0]
00007d20d97dbcd5  vmovaps [rsp+0x90], xmm8
00007d20d97dbcde  vmovaps xmm2, [rsp+0x90]
00007d20d97dbce7  por xmm8, xmm2
00007d20d97dbcec  movaps xmm2, [r15+0x2D0]
00007d20d97dbcf4  vmovaps [rsp+0x90], xmm2
00007d20d97dbcfd  vmovaps [rsp+0xA0], xmm1
00007d20d97dbd06  vmovaps xmm1, [rsp+0x90]
00007d20d97dbd0f  por xmm2, xmm1
00007d20d97dbd13  movaps xmm1, [r15+0x200]
00007d20d97dbd1b  vmovaps [rsp+0x90], xmm1
00007d20d97dbd24  vmovaps [rsp+0xB0], xmm15
00007d20d97dbd2d  vmovaps xmm15, [rsp+0x90]
00007d20d97dbd36  por xmm1, xmm15
00007d20d97dbd3b  movaps xmm15, [r15+0x1C0]
00007d20d97dbd43  vmovaps [rsp+0x90], xmm15
00007d20d97dbd4c  vmovaps [rsp+0xC0], xmm1
00007d20d97dbd55  vmovaps xmm1, [rsp+0x90]
00007d20d97dbd5e  por xmm15, xmm1
00007d20d97dbd63  movaps xmm1, [r15+0x190]
00007d20d97dbd6b  vmovaps [rsp+0x90], xmm1
00007d20d97dbd74  vmovaps [rsp+0xD0], xmm15
00007d20d97dbd7d  vmovaps xmm15, [rsp+0x90]
00007d20d97dbd86  por xmm1, xmm15
00007d20d97dbd8b  movaps xmm15, [r15+0x300]
00007d20d97dbd93  vmovaps [rsp+0x90], xmm15
00007d20d97dbd9c  vmovaps [rsp+0xE0], xmm1
00007d20d97dbda5  vmovaps xmm1, [rsp+0x90]
00007d20d97dbdae  por xmm15, xmm1
00007d20d97dbdb3  mov rax, [rsp+0x80]
00007d20d97dbdbb  lea r12, [rax+0xA0]
00007d20d97dbdc2  movups xmm1, [r13+r12*1]
00007d20d97dbdc8  lea r12, [rax+0xB0]
00007d20d97dbdcf  vmovaps [rsp+0x80], xmm1
00007d20d97dbdd8  movups xmm1, [r13+r12*1]
00007d20d97dbdde  vmovaps [rsp+0x90], xmm1
00007d20d97dbde7  vmovaps [rsp+0xF0], xmm15
00007d20d97dbdf0  vmovaps xmm15, [rsp+0xB0]
00007d20d97dbdf9  vmovaps [rsp+0xB0], xmm14
00007d20d97dbe02  movaps xmm1, xmm6
00007d20d97dbe05  addpd xmm1, xmm15
00007d20d97dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d20d97dbe0f  ptest xmm14, xmm14
00007d20d97dbe15  jnz 0x00007D20D97DD4D6
00007d20d97dbe1b  lea r12, [rax+0xF0]
00007d20d97dbe22  movups xmm15, [r13+r12*1]
00007d20d97dbe28  movaps xmm14, xmm4
00007d20d97dbe2c  addpd xmm14, xmm3
00007d20d97dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007d20d97dbe37  ptest xmm6, xmm6
00007d20d97dbe3c  jnz 0x00007D20D97DD621
00007d20d97dbe42  movaps xmm6, xmm9
00007d20d97dbe46  addpd xmm6, xmm7
00007d20d97dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d20d97dbe4f  ptest xmm4, xmm4
00007d20d97dbe54  jnz 0x00007D20D97DD763
00007d20d97dbe5a  vmovaps xmm9, [rsp+0x70]
00007d20d97dbe60  vpermilpd xmm9, xmm9, 0x00
00007d20d97dbe66  vmovaps xmm4, [rsp+0x90]
00007d20d97dbe6f  movaps xmm7, xmm4
00007d20d97dbe72  mulpd xmm7, xmm9
00007d20d97dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007d20d97dbe7c  ptest xmm3, xmm3
00007d20d97dbe81  jnz 0x00007D20D97DD8A4
00007d20d97dbe87  vmovaps xmm9, [rsp+0x50]
00007d20d97dbe8d  vpermilpd xmm9, xmm9, 0x00
00007d20d97dbe93  movaps xmm4, xmm15
00007d20d97dbe97  mulpd xmm4, xmm9
00007d20d97dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d20d97dbea1  ptest xmm3, xmm3
00007d20d97dbea6  jnz 0x00007D20D97DD9E5
00007d20d97dbeac  lea r12, [rax+0xE0]
00007d20d97dbeb3  movups xmm15, [r13+r12*1]
00007d20d97dbeb9  vmovaps xmm9, [rsp+0x70]
00007d20d97dbebf  vpermilpd xmm9, xmm9, 0x00
00007d20d97dbec5  vmovaps [rsp+0x70], xmm1
00007d20d97dbecb  vmovaps xmm1, [rsp+0x80]
00007d20d97dbed4  vmovaps [rsp+0x80], xmm15
00007d20d97dbedd  movaps xmm3, xmm1
00007d20d97dbee0  mulpd xmm3, xmm9
00007d20d97dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d20d97dbeea  ptest xmm15, xmm15
00007d20d97dbef0  jnz 0x00007D20D97DDB31
00007d20d97dbef6  vmovaps xmm1, [rsp+0xF0]
00007d20d97dbeff  vmovaps xmm15, [rsp+0xF0]
00007d20d97dbf08  por xmm1, xmm15
00007d20d97dbf0d  movaps [r15+0x300], xmm1
00007d20d97dbf15  vmovaps xmm15, [rsp+0xE0]
00007d20d97dbf1e  vmovaps xmm9, [rsp+0xE0]
00007d20d97dbf27  por xmm15, xmm9
00007d20d97dbf2c  movaps [r15+0x190], xmm15
00007d20d97dbf34  vmovaps xmm9, [rsp+0x50]
00007d20d97dbf3a  vpermilpd xmm9, xmm9, 0x00
00007d20d97dbf40  vmovaps [rsp+0x90], xmm1
00007d20d97dbf49  vmovaps [rsp+0xE0], xmm15
00007d20d97dbf52  vmovaps xmm15, [rsp+0x80]
00007d20d97dbf5b  vmovaps [rsp+0x80], xmm14
00007d20d97dbf64  movaps xmm1, xmm15
00007d20d97dbf68  mulpd xmm1, xmm9
00007d20d97dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d20d97dbf72  ptest xmm14, xmm14
00007d20d97dbf78  jnz 0x00007D20D97DDC72
00007d20d97dbf7e  lea r12, [rax+0x90]
00007d20d97dbf85  movups xmm15, [r13+r12*1]
00007d20d97dbf8b  vmovaps xmm14, [rsp+0xD0]
00007d20d97dbf94  vmovaps xmm9, [rsp+0xD0]
00007d20d97dbf9d  por xmm14, xmm9
00007d20d97dbfa2  movaps [r15+0x1C0], xmm14
00007d20d97dbfaa  vmovaps xmm9, [rsp+0xC0]
00007d20d97dbfb3  vmovaps [rsp+0xD0], xmm1
00007d20d97dbfbc  vmovaps xmm1, [rsp+0xC0]
00007d20d97dbfc5  por xmm9, xmm1
00007d20d97dbfca  movaps [r15+0x200], xmm9
00007d20d97dbfd2  vmovaps [rsp+0xC0], xmm2
00007d20d97dbfdb  vmovaps xmm1, [rsp+0xC0]
00007d20d97dbfe4  por xmm2, xmm1
00007d20d97dbfe8  movaps [r15+0x2D0], xmm2
00007d20d97dbff0  vmovaps [rsp+0xC0], xmm8
00007d20d97dbff9  vmovaps xmm1, [rsp+0xC0]
00007d20d97dc002  por xmm8, xmm1
00007d20d97dc007  movaps [r15+0x2E0], xmm8
00007d20d97dc00f  vmovaps [rsp+0xC0], xmm15
00007d20d97dc018  movaps xmm1, xmm5
00007d20d97dc01b  addpd xmm1, xmm7
00007d20d97dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007d20d97dc024  ptest xmm15, xmm15
00007d20d97dc02a  jnz 0x00007D20D97DDDBE
00007d20d97dc030  vmovaps xmm15, [rsp+0x50]
00007d20d97dc036  vpermilpd xmm15, xmm15, 0x00
00007d20d97dc03c  vmovaps xmm5, [rsp+0xC0]
00007d20d97dc045  vmovaps [rsp+0xC0], xmm1
00007d20d97dc04e  movaps xmm7, xmm5
00007d20d97dc051  mulpd xmm7, xmm15
00007d20d97dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007d20d97dc05b  ptest xmm1, xmm1
00007d20d97dc060  jnz 0x00007D20D97DDEFE
00007d20d97dc066  lea r12, [rax+0x80]
00007d20d97dc06d  movups xmm1, [r13+r12*1]
00007d20d97dc073  vmovaps xmm5, [rsp+0x70]
00007d20d97dc079  vmovaps [rsp+0x70], xmm1
00007d20d97dc07f  movaps xmm15, xmm5
00007d20d97dc083  addpd xmm15, xmm3
00007d20d97dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97dc08e  ptest xmm1, xmm1
00007d20d97dc093  jnz 0x00007D20D97DE049
00007d20d97dc099  vmovaps xmm5, [rsp+0x80]
00007d20d97dc0a2  movaps xmm1, xmm5
00007d20d97dc0a5  addpd xmm1, xmm4
00007d20d97dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007d20d97dc0ae  ptest xmm3, xmm3
00007d20d97dc0b3  jnz 0x00007D20D97DE18B
00007d20d97dc0b9  vmovaps [rsp+0x80], xmm10
00007d20d97dc0c2  vmovaps xmm5, [rsp+0x80]
00007d20d97dc0cb  por xmm10, xmm5
00007d20d97dc0d0  movaps [r15+0x2F0], xmm10
00007d20d97dc0d8  vmovaps xmm5, [rsp+0x50]
00007d20d97dc0de  vpermilpd xmm5, xmm5, 0x00
00007d20d97dc0e4  vmovaps xmm3, [rsp+0x70]
00007d20d97dc0ea  vmovaps [rsp+0x50], xmm1
00007d20d97dc0f0  movaps xmm4, xmm3
00007d20d97dc0f3  mulpd xmm4, xmm5
00007d20d97dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d20d97dc0fc  ptest xmm1, xmm1
00007d20d97dc101  jnz 0x00007D20D97DE2CB
00007d20d97dc107  lea r12, [rax+0xD0]
00007d20d97dc10e  movups xmm1, [r13+r12*1]
00007d20d97dc114  vmovaps xmm3, [rsp+0xD0]
00007d20d97dc11d  vmovaps [rsp+0x70], xmm1
00007d20d97dc123  movaps xmm5, xmm6
00007d20d97dc126  addpd xmm5, xmm3
00007d20d97dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d20d97dc12f  ptest xmm1, xmm1
00007d20d97dc134  jnz 0x00007D20D97DE415
00007d20d97dc13a  vmovaps xmm1, [rsp+0x60]
00007d20d97dc140  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc146  movaps xmm6, xmm9
00007d20d97dc14a  mulpd xmm6, xmm1
00007d20d97dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d20d97dc153  ptest xmm3, xmm3
00007d20d97dc158  jnz 0x00007D20D97DE555
00007d20d97dc15e  movaps [r15+0x260], xmm6
00007d20d97dc166  vxorps xmm1, xmm1, xmm1
00007d20d97dc16a  vpbroadcastq xmm1, xmm1
00007d20d97dc16f  movaps [r15+0x1B0], xmm1
00007d20d97dc177  vmovaps xmm1, [rsp+0x60]
00007d20d97dc17d  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc183  vmovaps xmm3, [rsp+0x70]
00007d20d97dc189  vmovaps [rsp+0x70], xmm15
00007d20d97dc18f  movaps xmm9, xmm3
00007d20d97dc193  mulpd xmm9, xmm1
00007d20d97dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007d20d97dc19e  ptest xmm15, xmm15
00007d20d97dc1a4  jnz 0x00007D20D97DE696
00007d20d97dc1aa  lea r12, [rax+0xC0]
00007d20d97dc1b1  movups xmm1, [r13+r12*1]
00007d20d97dc1b7  vmovaps xmm3, [rsp+0xC0]
00007d20d97dc1c0  vmovaps [rsp+0x80], xmm1
00007d20d97dc1c9  movaps xmm15, xmm3
00007d20d97dc1cd  addpd xmm15, xmm7
00007d20d97dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97dc1d8  ptest xmm1, xmm1
00007d20d97dc1dd  jnz 0x00007D20D97DE7E2
00007d20d97dc1e3  vmovaps [rsp+0xC0], xmm13
00007d20d97dc1ec  vmovaps xmm1, [rsp+0xC0]
00007d20d97dc1f5  por xmm13, xmm1
00007d20d97dc1fa  movaps [r15+0x270], xmm13
00007d20d97dc202  vmovaps xmm1, [rsp+0xB0]
00007d20d97dc20b  vmovaps xmm7, [rsp+0xB0]
00007d20d97dc214  por xmm1, xmm7
00007d20d97dc218  movaps [r15+0x1A0], xmm1
00007d20d97dc220  vmovaps xmm1, [rsp+0x60]
00007d20d97dc226  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc22c  vmovaps [rsp+0xB0], xmm1
00007d20d97dc235  vmovaps xmm1, [rsp+0x80]
00007d20d97dc23e  vmovaps [rsp+0x80], xmm15
00007d20d97dc247  vmovaps xmm15, [rsp+0xB0]
00007d20d97dc250  vmovaps [rsp+0xB0], xmm14
00007d20d97dc259  movaps xmm3, xmm1
00007d20d97dc25c  mulpd xmm3, xmm15
00007d20d97dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007d20d97dc266  ptest xmm14, xmm14
00007d20d97dc26c  jnz 0x00007D20D97DE924
00007d20d97dc272  lea r12, [rax+0x20]
00007d20d97dc276  movups xmm1, [r13+r12*1]
00007d20d97dc27c  movaps [r15+0x110], xmm1
00007d20d97dc284  vmovaps xmm14, [rsp+0x70]
00007d20d97dc28a  vmovaps [rsp+0x70], xmm1
00007d20d97dc290  movaps xmm15, xmm14
00007d20d97dc294  addpd xmm15, xmm4
00007d20d97dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007d20d97dc29f  ptest xmm1, xmm1
00007d20d97dc2a4  jnz 0x00007D20D97DEA6F
00007d20d97dc2aa  vmovaps xmm1, [rsp+0x60]
00007d20d97dc2b0  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc2b6  movaps xmm14, xmm2
00007d20d97dc2ba  mulpd xmm14, xmm1
00007d20d97dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007d20d97dc2c5  ptest xmm4, xmm4
00007d20d97dc2ca  jnz 0x00007D20D97DEBB2
00007d20d97dc2d0  vmovaps xmm4, [rsp+0x50]
00007d20d97dc2d6  movaps xmm1, xmm4
00007d20d97dc2d9  addpd xmm1, xmm9
00007d20d97dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007d20d97dc2e3  ptest xmm2, xmm2
00007d20d97dc2e8  jnz 0x00007D20D97DECF4
00007d20d97dc2ee  vmovaps xmm9, [rsp+0x30]
00007d20d97dc2f4  vpermilpd xmm9, xmm9, 0x00
00007d20d97dc2fa  vmovaps xmm2, [rsp+0x70]
00007d20d97dc300  vmovaps [rsp+0x50], xmm1
00007d20d97dc306  movaps xmm4, xmm2
00007d20d97dc309  mulpd xmm4, xmm9
00007d20d97dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007d20d97dc313  ptest xmm1, xmm1
00007d20d97dc318  jnz 0x00007D20D97DEE35
00007d20d97dc31e  vmovaps xmm1, [rsp+0x30]
00007d20d97dc324  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc32a  vmovaps xmm2, [rsp+0x90]
00007d20d97dc333  vmovaps [rsp+0x60], xmm15
00007d20d97dc339  movaps xmm9, xmm2
00007d20d97dc33d  mulpd xmm9, xmm1
00007d20d97dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007d20d97dc348  ptest xmm15, xmm15
00007d20d97dc34e  jnz 0x00007D20D97DEF76
00007d20d97dc354  vmovaps xmm15, [rsp+0x80]
00007d20d97dc35d  movaps xmm1, xmm15
00007d20d97dc361  addpd xmm1, xmm6
00007d20d97dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007d20d97dc36a  ptest xmm2, xmm2
00007d20d97dc36f  jnz 0x00007D20D97DF0B8
00007d20d97dc375  movaps xmm15, xmm5
00007d20d97dc379  addpd xmm15, xmm3
00007d20d97dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d20d97dc384  ptest xmm6, xmm6
00007d20d97dc389  jnz 0x00007D20D97DF1F9
00007d20d97dc38f  vmovaps xmm6, [rsp+0x30]
00007d20d97dc395  vpermilpd xmm6, xmm6, 0x00
00007d20d97dc39b  movaps xmm5, xmm8
00007d20d97dc39f  mulpd xmm5, xmm6
00007d20d97dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007d20d97dc3a8  ptest xmm3, xmm3
00007d20d97dc3ad  jnz 0x00007D20D97DF33B
00007d20d97dc3b3  vmovaps xmm8, [rsp+0x30]
00007d20d97dc3b9  vpermilpd xmm8, xmm8, 0x00
00007d20d97dc3bf  movaps xmm6, xmm10
00007d20d97dc3c3  mulpd xmm6, xmm8
00007d20d97dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d20d97dc3cd  ptest xmm3, xmm3
00007d20d97dc3d2  jnz 0x00007D20D97DF47C
00007d20d97dc3d8  vmovaps xmm8, [rsp+0x60]
00007d20d97dc3de  movaps xmm10, xmm8
00007d20d97dc3e2  addpd xmm10, xmm14
00007d20d97dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d20d97dc3ed  ptest xmm3, xmm3
00007d20d97dc3f2  jnz 0x00007D20D97DF5BE
00007d20d97dc3f8  vmovaps xmm8, [rsp+0x50]
00007d20d97dc3fe  movaps xmm14, xmm8
00007d20d97dc402  addpd xmm14, xmm4
00007d20d97dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007d20d97dc40d  ptest xmm3, xmm3
00007d20d97dc412  jnz 0x00007D20D97DF702
00007d20d97dc418  vmovaps xmm8, [rsp+0x40]
00007d20d97dc41e  vpermilpd xmm8, xmm8, 0x00
00007d20d97dc424  movaps xmm4, xmm13
00007d20d97dc428  mulpd xmm4, xmm8
00007d20d97dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d20d97dc432  ptest xmm3, xmm3
00007d20d97dc437  jnz 0x00007D20D97DF845
00007d20d97dc43d  movaps xmm13, xmm15
00007d20d97dc441  addpd xmm13, xmm9
00007d20d97dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007d20d97dc44c  ptest xmm8, xmm8
00007d20d97dc452  jnz 0x00007D20D97DF987
00007d20d97dc458  movaps xmm15, xmm1
00007d20d97dc45c  addpd xmm15, xmm5
00007d20d97dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007d20d97dc467  ptest xmm9, xmm9
00007d20d97dc46d  jnz 0x00007D20D97DFACB
00007d20d97dc473  vmovaps [rsp+0x30], xmm11
00007d20d97dc479  vmovaps xmm1, [rsp+0x30]
00007d20d97dc47f  por xmm11, xmm1
00007d20d97dc484  movaps [r15+0x250], xmm11
00007d20d97dc48c  vmovaps [rsp+0x30], xmm12
00007d20d97dc492  vmovaps xmm1, [rsp+0x30]
00007d20d97dc498  por xmm12, xmm1
00007d20d97dc49d  movaps [r15+0x2A0], xmm12
00007d20d97dc4a5  vmovaps xmm1, [rsp+0xA0]
00007d20d97dc4ae  vmovaps xmm11, [rsp+0xA0]
00007d20d97dc4b7  por xmm1, xmm11
00007d20d97dc4bc  movaps [r15+0x1D0], xmm1
00007d20d97dc4c4  lea r12, [rax+0x40]
00007d20d97dc4c8  movups xmm1, [r13+r12*1]
00007d20d97dc4ce  movaps [r15+0x2C0], xmm1
00007d20d97dc4d6  vmovaps xmm11, [rsp+0x40]
00007d20d97dc4dc  vpermilpd xmm11, xmm11, 0x00
00007d20d97dc4e2  vmovaps xmm8, [rsp+0xE0]
00007d20d97dc4eb  movaps xmm9, xmm8
00007d20d97dc4ef  mulpd xmm9, xmm11
00007d20d97dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d20d97dc4fa  ptest xmm5, xmm5
00007d20d97dc4ff  jnz 0x00007D20D97DFC17
00007d20d97dc505  movaps xmm11, xmm10
00007d20d97dc509  addpd xmm11, xmm6
00007d20d97dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007d20d97dc514  ptest xmm8, xmm8
00007d20d97dc51a  jnz 0x00007D20D97DFD5B
00007d20d97dc520  movaps xmm10, xmm14
00007d20d97dc524  addpd xmm10, xmm4
00007d20d97dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007d20d97dc52f  ptest xmm8, xmm8
00007d20d97dc535  jnz 0x00007D20D97DFE9E
00007d20d97dc53b  vmovaps xmm14, [rsp+0x40]
00007d20d97dc541  vpermilpd xmm14, xmm14, 0x00
00007d20d97dc547  movaps xmm8, xmm1
00007d20d97dc54b  mulpd xmm8, xmm14
00007d20d97dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007d20d97dc556  ptest xmm6, xmm6
00007d20d97dc55b  jnz 0x00007D20D97DFFE1
00007d20d97dc561  movaps xmm1, [r15+0x2B0]
00007d20d97dc569  vmovaps xmm14, [rsp+0x40]
00007d20d97dc56f  vpermilpd xmm14, xmm14, 0x00
00007d20d97dc575  movaps xmm6, xmm1
00007d20d97dc578  mulpd xmm6, xmm14
00007d20d97dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d20d97dc582  ptest xmm5, xmm5
00007d20d97dc587  jnz 0x00007D20D97E0124
00007d20d97dc58d  vmovaps xmm1, [rsp+0x10]
00007d20d97dc593  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc599  movaps xmm14, xmm12
00007d20d97dc59d  mulpd xmm14, xmm1
00007d20d97dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007d20d97dc5a8  ptest xmm5, xmm5
00007d20d97dc5ad  jnz 0x00007D20D97E0265
00007d20d97dc5b3  movaps xmm1, xmm13
00007d20d97dc5b7  addpd xmm1, xmm9
00007d20d97dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007d20d97dc5c1  ptest xmm12, xmm12
00007d20d97dc5c7  jnz 0x00007D20D97E03A8
00007d20d97dc5cd  vmovaps xmm13, [rsp+0x10]
00007d20d97dc5d3  vpermilpd xmm13, xmm13, 0x00
00007d20d97dc5d9  movaps xmm12, xmm7
00007d20d97dc5dd  mulpd xmm12, xmm13
00007d20d97dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d20d97dc5e8  ptest xmm9, xmm9
00007d20d97dc5ee  jnz 0x00007D20D97E04EA
00007d20d97dc5f4  movaps xmm13, xmm15
00007d20d97dc5f8  addpd xmm13, xmm8
00007d20d97dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d20d97dc603  ptest xmm9, xmm9
00007d20d97dc609  jnz 0x00007D20D97E062D
00007d20d97dc60f  movaps xmm15, [r15+0x290]
00007d20d97dc617  vmovaps xmm9, [rsp+0x10]
00007d20d97dc61d  vpermilpd xmm9, xmm9, 0x00
00007d20d97dc623  movaps xmm8, xmm15
00007d20d97dc627  mulpd xmm8, xmm9
00007d20d97dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d20d97dc632  ptest xmm7, xmm7
00007d20d97dc637  jnz 0x00007D20D97E0771
00007d20d97dc63d  movaps xmm15, xmm11
00007d20d97dc641  addpd xmm15, xmm6
00007d20d97dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007d20d97dc64c  ptest xmm9, xmm9
00007d20d97dc652  jnz 0x00007D20D97E08B5
00007d20d97dc658  movaps xmm11, [r15+0x1E0]
00007d20d97dc660  vmovaps xmm9, [rsp+0x10]
00007d20d97dc666  vpermilpd xmm9, xmm9, 0x00
00007d20d97dc66c  movaps xmm7, xmm11
00007d20d97dc670  mulpd xmm7, xmm9
00007d20d97dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007d20d97dc67a  ptest xmm6, xmm6
00007d20d97dc67f  jnz 0x00007D20D97E09F8
00007d20d97dc685  movaps xmm11, xmm10
00007d20d97dc689  addpd xmm11, xmm14
00007d20d97dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d20d97dc694  ptest xmm9, xmm9
00007d20d97dc69a  jnz 0x00007D20D97E0B3A
00007d20d97dc6a0  lea r12, [rax+0x70]
00007d20d97dc6a4  movups xmm14, [r13+r12*1]
00007d20d97dc6aa  movaps [r15+0x240], xmm14
00007d20d97dc6b2  movaps xmm10, xmm1
00007d20d97dc6b6  addpd xmm10, xmm12
00007d20d97dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007d20d97dc6c1  ptest xmm9, xmm9
00007d20d97dc6c7  jnz 0x00007D20D97E0C88
00007d20d97dc6cd  movaps [r15+0x170], xmm10
00007d20d97dc6d5  vmovaps xmm1, [rsp+0x20]
00007d20d97dc6db  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc6e1  movaps xmm12, xmm14
00007d20d97dc6e5  mulpd xmm12, xmm1
00007d20d97dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007d20d97dc6f0  ptest xmm9, xmm9
00007d20d97dc6f6  jnz 0x00007D20D97E0DCB
00007d20d97dc6fc  vmovaps xmm1, [rsp+0x20]
00007d20d97dc702  vpermilpd xmm1, xmm1, 0x00
00007d20d97dc708  vmovaps xmm9, [rsp+0xB0]
00007d20d97dc711  movaps xmm14, xmm9
00007d20d97dc715  mulpd xmm14, xmm1
00007d20d97dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007d20d97dc720  ptest xmm6, xmm6
00007d20d97dc725  jnz 0x00007D20D97E0F0E
00007d20d97dc72b  movaps [r15+0x180], xmm14
00007d20d97dc733  movaps xmm1, xmm13
00007d20d97dc737  addpd xmm1, xmm8
00007d20d97dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d20d97dc741  ptest xmm9, xmm9
00007d20d97dc747  jnz 0x00007D20D97E1051
00007d20d97dc74d  movaps [r15+0x210], xmm1
00007d20d97dc755  movups xmm13, [r13+rax*1]
00007d20d97dc75b  lea r12, [rax+0x10]
00007d20d97dc75f  movups xmm9, [r13+r12*1]
00007d20d97dc765  movaps [r15+0x230], xmm9
00007d20d97dc76d  movaps xmm8, xmm15
00007d20d97dc771  addpd xmm8, xmm7
00007d20d97dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007d20d97dc77c  ptest xmm6, xmm6
00007d20d97dc781  jnz 0x00007D20D97E11A7
00007d20d97dc787  movaps [r15+0x130], xmm8
00007d20d97dc78f  vmovaps xmm15, [rsp+0x20]
00007d20d97dc795  vpermilpd xmm15, xmm15, 0x00
00007d20d97dc79b  movaps xmm7, xmm9
00007d20d97dc79f  mulpd xmm7, xmm15
00007d20d97dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007d20d97dc7a9  ptest xmm6, xmm6
00007d20d97dc7ae  jnz 0x00007D20D97E12EA
00007d20d97dc7b4  movaps [r15+0x220], xmm7
00007d20d97dc7bc  vmovaps xmm15, [rsp+0x20]
00007d20d97dc7c2  vpermilpd xmm15, xmm15, 0x00
00007d20d97dc7c8  movaps xmm9, xmm13
00007d20d97dc7cc  mulpd xmm9, xmm15
00007d20d97dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d20d97dc7d7  ptest xmm6, xmm6
00007d20d97dc7dc  jnz 0x00007D20D97E142C
00007d20d97dc7e2  movaps xmm15, xmm11
00007d20d97dc7e6  addpd xmm15, xmm12
00007d20d97dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d20d97dc7f1  ptest xmm13, xmm13
00007d20d97dc7f7  jnz 0x00007D20D97E1570
00007d20d97dc7fd  movaps [r15+0x140], xmm15
00007d20d97dc805  movaps xmm13, xmm10
00007d20d97dc809  addpd xmm13, xmm14
00007d20d97dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007d20d97dc814  ptest xmm12, xmm12
00007d20d97dc81a  jnz 0x00007D20D97E16B4
00007d20d97dc820  movaps [r15+0x150], xmm13
00007d20d97dc828  movaps xmm14, xmm1
00007d20d97dc82c  addpd xmm14, xmm7
00007d20d97dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007d20d97dc837  ptest xmm12, xmm12
00007d20d97dc83d  jnz 0x00007D20D97E17F8
00007d20d97dc843  movaps [r15+0x160], xmm14
00007d20d97dc84b  movaps xmm1, xmm8
00007d20d97dc84f  addpd xmm1, xmm9
00007d20d97dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007d20d97dc859  ptest xmm12, xmm12
00007d20d97dc85f  jnz 0x00007D20D97E193A
00007d20d97dc865  movaps [r15+0x120], xmm1
00007d20d97dc86d  movups [r13+r14*1], xmm15
00007d20d97dc873  lea rax, [r14+0x10]
00007d20d97dc877  movups [r13+rax*1], xmm13
00007d20d97dc87d  lea rax, [r14+0x20]
00007d20d97dc881  movups [r13+rax*1], xmm14
00007d20d97dc887  lea rax, [r14+0x30]
00007d20d97dc88b  movups [r13+rax*1], xmm1
00007d20d97dc891  mov eax, [r15+0x108]
00007d20d97dc898  sahf
00007d20d97dc899  jnz 0x00007D20D97DC8CB
00007d20d97dc89b  cmp dword ptr [r15+0x318], 0x00
00007d20d97dc8a3  jz 0x00007D20D97DB900
00007d20d97dc8a9  nop [rax+rax*1], ax
00007d20d97dc8b2  nop [rax+rax*1], eax
00007d20d97dc8ba  mov eax, 0x410444
00007d20d97dc8bf  mov [r15+0x100], rax
00007d20d97dc8c6  jmp 0x00007D20D95FE110
00007d20d97dc8cb  cmp dword ptr [r15+0x318], 0x00
00007d20d97dc8d3  jz 0x00007D20D97D57E0
00007d20d97dc8d9  nop [rax+rax*1], ax
00007d20d97dc8e2  nop [rax+rax*1], eax
00007d20d97dc8ea  mov eax, 0x410278
00007d20d97dc8ef  mov [r15+0x100], rax
00007d20d97dc8f6  jmp 0x00007D20D95FE110
00007d20d97dc8fb  int3
00007d20d97dc8fc  call 0x00007D20D96E27E0
00007d20d97dc901  jmp 0x00007D20D97DB9DF
00007d20d97dc906  call 0x00007D20D96E1570
00007d20d97dc90b  jmp 0x00007D20D97DB9E8
00007d20d97dc910  call 0x00007D20D96E27E0
00007d20d97dc915  jmp 0x00007D20D97DBA44
00007d20d97dc91a  call 0x00007D20D96E1570
00007d20d97dc91f  jmp 0x00007D20D97DBA4D
00007d20d97dc924  call 0x00007D20D96E27E0
00007d20d97dc929  jmp 0x00007D20D97DBA90
00007d20d97dc92e  call 0x00007D20D96E1570
00007d20d97dc933  jmp 0x00007D20D97DBA99
00007d20d97dc938  call 0x00007D20D960DC20
00007d20d97dc93d  jmp 0x00007D20D97DBAD8
00007d20d97dc942  call 0x00007D20D96D59C0
00007d20d97dc947  jmp 0x00007D20D97DBAEB
00007d20d97dc94c  call 0x00007D20D96E0E30
00007d20d97dc951  jmp 0x00007D20D97DBB09
00007d20d97dc956  call 0x00007D20D96DFBC0
00007d20d97dc95b  jmp 0x00007D20D97DBB13
00007d20d97dc960  call 0x00007D20D96DE950
00007d20d97dc965  jmp 0x00007D20D97DBB1D
00007d20d97dc96a  sub rsp, 0x08
00007d20d97dc96e  push rax
00007d20d97dc96f  push rcx
00007d20d97dc970  push rdx
00007d20d97dc971  push rdi
00007d20d97dc972  push rsi
00007d20d97dc973  push r8
00007d20d97dc975  push r9
00007d20d97dc977  push r10
00007d20d97dc979  push r11
00007d20d97dc97b  sub rsp, 0xF0
00007d20d97dc982  vmovaps [rsp], xmm0
00007d20d97dc987  vmovaps [rsp+0x10], xmm1
00007d20d97dc98d  vmovaps [rsp+0x20], xmm2
00007d20d97dc993  vmovaps [rsp+0x30], xmm3
00007d20d97dc999  vmovaps [rsp+0x40], xmm4
00007d20d97dc99f  vmovaps [rsp+0x50], xmm5
00007d20d97dc9a5  vmovaps [rsp+0x60], xmm6
00007d20d97dc9ab  vmovaps [rsp+0x70], xmm7
00007d20d97dc9b1  vmovaps [rsp+0x80], xmm9
00007d20d97dc9ba  vmovaps [rsp+0x90], xmm10
00007d20d97dc9c3  vmovaps [rsp+0xA0], xmm11
00007d20d97dc9cc  vmovaps [rsp+0xB0], xmm12
00007d20d97dc9d5  vmovaps [rsp+0xC0], xmm13
00007d20d97dc9de  vmovaps [rsp+0xD0], xmm14
00007d20d97dc9e7  vmovaps [rsp+0xE0], xmm15
00007d20d97dc9f0  sub rsp, 0x30
00007d20d97dc9f4  movaps [rsp], xmm8
00007d20d97dc9f9  movaps [rsp+0x10], xmm12
00007d20d97dc9ff  movaps [rsp+0x20], xmm15
00007d20d97dca05  lea rdi, [rsp]
00007d20d97dca09  mov esi, 0x00
00007d20d97dca0e  mov rax, 0x5EFBF4CF6530
00007d20d97dca18  call rax
00007d20d97dca1a  movaps xmm8, [rsp]
00007d20d97dca1f  add rsp, 0x30
00007d20d97dca23  vmovaps xmm0, [rsp]
00007d20d97dca28  vmovaps xmm1, [rsp+0x10]
00007d20d97dca2e  vmovaps xmm2, [rsp+0x20]
00007d20d97dca34  vmovaps xmm3, [rsp+0x30]
00007d20d97dca3a  vmovaps xmm4, [rsp+0x40]
00007d20d97dca40  vmovaps xmm5, [rsp+0x50]
00007d20d97dca46  vmovaps xmm6, [rsp+0x60]
00007d20d97dca4c  vmovaps xmm7, [rsp+0x70]
00007d20d97dca52  vmovaps xmm9, [rsp+0x80]
00007d20d97dca5b  vmovaps xmm10, [rsp+0x90]
00007d20d97dca64  vmovaps xmm11, [rsp+0xA0]
00007d20d97dca6d  vmovaps xmm12, [rsp+0xB0]
00007d20d97dca76  vmovaps xmm13, [rsp+0xC0]
00007d20d97dca7f  vmovaps xmm14, [rsp+0xD0]
00007d20d97dca88  vmovaps xmm15, [rsp+0xE0]
00007d20d97dca91  add rsp, 0xF0
00007d20d97dca98  pop r11
00007d20d97dca9a  pop r10
00007d20d97dca9c  pop r9
00007d20d97dca9e  pop r8
00007d20d97dcaa0  pop rsi
00007d20d97dcaa1  pop rdi
00007d20d97dcaa2  pop rdx
00007d20d97dcaa3  pop rcx
00007d20d97dcaa4  pop rax
00007d20d97dcaa5  add rsp, 0x08
00007d20d97dcaa9  jmp 0x00007D20D97DBB47
00007d20d97dcaae  sub rsp, 0x08
00007d20d97dcab2  push rax
00007d20d97dcab3  push rcx
00007d20d97dcab4  push rdx
00007d20d97dcab5  push rdi
00007d20d97dcab6  push rsi
00007d20d97dcab7  push r8
00007d20d97dcab9  push r9
00007d20d97dcabb  push r10
00007d20d97dcabd  push r11
00007d20d97dcabf  sub rsp, 0xF0
00007d20d97dcac6  vmovaps [rsp], xmm0
00007d20d97dcacb  vmovaps [rsp+0x10], xmm1
00007d20d97dcad1  vmovaps [rsp+0x20], xmm2
00007d20d97dcad7  vmovaps [rsp+0x30], xmm3
00007d20d97dcadd  vmovaps [rsp+0x40], xmm4
00007d20d97dcae3  vmovaps [rsp+0x50], xmm5
00007d20d97dcae9  vmovaps [rsp+0x60], xmm6
00007d20d97dcaef  vmovaps [rsp+0x70], xmm8
00007d20d97dcaf5  vmovaps [rsp+0x80], xmm9
00007d20d97dcafe  vmovaps [rsp+0x90], xmm10
00007d20d97dcb07  vmovaps [rsp+0xA0], xmm11
00007d20d97dcb10  vmovaps [rsp+0xB0], xmm12
00007d20d97dcb19  vmovaps [rsp+0xC0], xmm13
00007d20d97dcb22  vmovaps [rsp+0xD0], xmm14
00007d20d97dcb2b  vmovaps [rsp+0xE0], xmm15
00007d20d97dcb34  sub rsp, 0x30
00007d20d97dcb38  movaps [rsp], xmm7
00007d20d97dcb3c  movaps [rsp+0x10], xmm9
00007d20d97dcb42  movaps [rsp+0x20], xmm15
00007d20d97dcb48  lea rdi, [rsp]
00007d20d97dcb4c  mov esi, 0x00
00007d20d97dcb51  mov rax, 0x5EFBF4CF6530
00007d20d97dcb5b  call rax
00007d20d97dcb5d  movaps xmm7, [rsp]
00007d20d97dcb61  add rsp, 0x30
00007d20d97dcb65  vmovaps xmm0, [rsp]
00007d20d97dcb6a  vmovaps xmm1, [rsp+0x10]
00007d20d97dcb70  vmovaps xmm2, [rsp+0x20]
00007d20d97dcb76  vmovaps xmm3, [rsp+0x30]
00007d20d97dcb7c  vmovaps xmm4, [rsp+0x40]
00007d20d97dcb82  vmovaps xmm5, [rsp+0x50]
00007d20d97dcb88  vmovaps xmm6, [rsp+0x60]
00007d20d97dcb8e  vmovaps xmm8, [rsp+0x70]
00007d20d97dcb94  vmovaps xmm9, [rsp+0x80]
00007d20d97dcb9d  vmovaps xmm10, [rsp+0x90]
00007d20d97dcba6  vmovaps xmm11, [rsp+0xA0]
00007d20d97dcbaf  vmovaps xmm12, [rsp+0xB0]
00007d20d97dcbb8  vmovaps xmm13, [rsp+0xC0]
00007d20d97dcbc1  vmovaps xmm14, [rsp+0xD0]
00007d20d97dcbca  vmovaps xmm15, [rsp+0xE0]
00007d20d97dcbd3  add rsp, 0xF0
00007d20d97dcbda  pop r11
00007d20d97dcbdc  pop r10
00007d20d97dcbde  pop r9
00007d20d97dcbe0  pop r8
00007d20d97dcbe2  pop rsi
00007d20d97dcbe3  pop rdi
00007d20d97dcbe4  pop rdx
00007d20d97dcbe5  pop rcx
00007d20d97dcbe6  pop rax
00007d20d97dcbe7  add rsp, 0x08
00007d20d97dcbeb  jmp 0x00007D20D97DBB75
00007d20d97dcbf0  sub rsp, 0x08
00007d20d97dcbf4  push rax
00007d20d97dcbf5  push rcx
00007d20d97dcbf6  push rdx
00007d20d97dcbf7  push rdi
00007d20d97dcbf8  push rsi
00007d20d97dcbf9  push r8
00007d20d97dcbfb  push r9
00007d20d97dcbfd  push r10
00007d20d97dcbff  push r11
00007d20d97dcc01  sub rsp, 0xF0
00007d20d97dcc08  vmovaps [rsp], xmm0
00007d20d97dcc0d  vmovaps [rsp+0x10], xmm1
00007d20d97dcc13  vmovaps [rsp+0x20], xmm2
00007d20d97dcc19  vmovaps [rsp+0x30], xmm3
00007d20d97dcc1f  vmovaps [rsp+0x40], xmm4
00007d20d97dcc25  vmovaps [rsp+0x50], xmm5
00007d20d97dcc2b  vmovaps [rsp+0x60], xmm6
00007d20d97dcc31  vmovaps [rsp+0x70], xmm7
00007d20d97dcc37  vmovaps [rsp+0x80], xmm8
00007d20d97dcc40  vmovaps [rsp+0x90], xmm10
00007d20d97dcc49  vmovaps [rsp+0xA0], xmm11
00007d20d97dcc52  vmovaps [rsp+0xB0], xmm12
00007d20d97dcc5b  vmovaps [rsp+0xC0], xmm13
00007d20d97dcc64  vmovaps [rsp+0xD0], xmm14
00007d20d97dcc6d  vmovaps [rsp+0xE0], xmm15
00007d20d97dcc76  sub rsp, 0x30
00007d20d97dcc7a  movaps [rsp], xmm9
00007d20d97dcc7f  movaps [rsp+0x10], xmm12
00007d20d97dcc85  movaps [rsp+0x20], xmm10
00007d20d97dcc8b  lea rdi, [rsp]
00007d20d97dcc8f  mov esi, 0x00
00007d20d97dcc94  mov rax, 0x5EFBF4CF6530
00007d20d97dcc9e  call rax
00007d20d97dcca0  movaps xmm9, [rsp]
00007d20d97dcca5  add rsp, 0x30
00007d20d97dcca9  vmovaps xmm0, [rsp]
00007d20d97dccae  vmovaps xmm1, [rsp+0x10]
00007d20d97dccb4  vmovaps xmm2, [rsp+0x20]
00007d20d97dccba  vmovaps xmm3, [rsp+0x30]
00007d20d97dccc0  vmovaps xmm4, [rsp+0x40]
00007d20d97dccc6  vmovaps xmm5, [rsp+0x50]
00007d20d97dcccc  vmovaps xmm6, [rsp+0x60]
00007d20d97dccd2  vmovaps xmm7, [rsp+0x70]
00007d20d97dccd8  vmovaps xmm8, [rsp+0x80]
00007d20d97dcce1  vmovaps xmm10, [rsp+0x90]
00007d20d97dccea  vmovaps xmm11, [rsp+0xA0]
00007d20d97dccf3  vmovaps xmm12, [rsp+0xB0]
00007d20d97dccfc  vmovaps xmm13, [rsp+0xC0]
00007d20d97dcd05  vmovaps xmm14, [rsp+0xD0]
00007d20d97dcd0e  vmovaps xmm15, [rsp+0xE0]
00007d20d97dcd17  add rsp, 0xF0
00007d20d97dcd1e  pop r11
00007d20d97dcd20  pop r10
00007d20d97dcd22  pop r9
00007d20d97dcd24  pop r8
00007d20d97dcd26  pop rsi
00007d20d97dcd27  pop rdi
00007d20d97dcd28  pop rdx
00007d20d97dcd29  pop rcx
00007d20d97dcd2a  pop rax
00007d20d97dcd2b  add rsp, 0x08
00007d20d97dcd2f  jmp 0x00007D20D97DBB99
00007d20d97dcd34  sub rsp, 0x08
00007d20d97dcd38  push rax
00007d20d97dcd39  push rcx
00007d20d97dcd3a  push rdx
00007d20d97dcd3b  push rdi
00007d20d97dcd3c  push rsi
00007d20d97dcd3d  push r8
00007d20d97dcd3f  push r9
00007d20d97dcd41  push r10
00007d20d97dcd43  push r11
00007d20d97dcd45  sub rsp, 0xF0
00007d20d97dcd4c  vmovaps [rsp], xmm0
00007d20d97dcd51  vmovaps [rsp+0x10], xmm1
00007d20d97dcd57  vmovaps [rsp+0x20], xmm2
00007d20d97dcd5d  vmovaps [rsp+0x30], xmm3
00007d20d97dcd63  vmovaps [rsp+0x40], xmm4
00007d20d97dcd69  vmovaps [rsp+0x50], xmm5
00007d20d97dcd6f  vmovaps [rsp+0x60], xmm6
00007d20d97dcd75  vmovaps [rsp+0x70], xmm7
00007d20d97dcd7b  vmovaps [rsp+0x80], xmm8
00007d20d97dcd84  vmovaps [rsp+0x90], xmm9
00007d20d97dcd8d  vmovaps [rsp+0xA0], xmm11
00007d20d97dcd96  vmovaps [rsp+0xB0], xmm12
00007d20d97dcd9f  vmovaps [rsp+0xC0], xmm13
00007d20d97dcda8  vmovaps [rsp+0xD0], xmm14
00007d20d97dcdb1  vmovaps [rsp+0xE0], xmm15
00007d20d97dcdba  sub rsp, 0x30
00007d20d97dcdbe  movaps [rsp], xmm10
00007d20d97dcdc3  movaps [rsp+0x10], xmm12
00007d20d97dcdc9  movaps [rsp+0x20], xmm11
00007d20d97dcdcf  lea rdi, [rsp]
00007d20d97dcdd3  mov esi, 0x00
00007d20d97dcdd8  mov rax, 0x5EFBF4CF6530
00007d20d97dcde2  call rax
00007d20d97dcde4  movaps xmm10, [rsp]
00007d20d97dcde9  add rsp, 0x30
00007d20d97dcded  vmovaps xmm0, [rsp]
00007d20d97dcdf2  vmovaps xmm1, [rsp+0x10]
00007d20d97dcdf8  vmovaps xmm2, [rsp+0x20]
00007d20d97dcdfe  vmovaps xmm3, [rsp+0x30]
00007d20d97dce04  vmovaps xmm4, [rsp+0x40]
00007d20d97dce0a  vmovaps xmm5, [rsp+0x50]
00007d20d97dce10  vmovaps xmm6, [rsp+0x60]
00007d20d97dce16  vmovaps xmm7, [rsp+0x70]
00007d20d97dce1c  vmovaps xmm8, [rsp+0x80]
00007d20d97dce25  vmovaps xmm9, [rsp+0x90]
00007d20d97dce2e  vmovaps xmm11, [rsp+0xA0]
00007d20d97dce37  vmovaps xmm12, [rsp+0xB0]
00007d20d97dce40  vmovaps xmm13, [rsp+0xC0]
00007d20d97dce49  vmovaps xmm14, [rsp+0xD0]
00007d20d97dce52  vmovaps xmm15, [rsp+0xE0]
00007d20d97dce5b  add rsp, 0xF0
00007d20d97dce62  pop r11
00007d20d97dce64  pop r10
00007d20d97dce66  pop r9
00007d20d97dce68  pop r8
00007d20d97dce6a  pop rsi
00007d20d97dce6b  pop rdi
00007d20d97dce6c  pop rdx
00007d20d97dce6d  pop rcx
00007d20d97dce6e  pop rax
00007d20d97dce6f  add rsp, 0x08
00007d20d97dce73  jmp 0x00007D20D97DBBB3
00007d20d97dce78  sub rsp, 0x08
00007d20d97dce7c  push rax
00007d20d97dce7d  push rcx
00007d20d97dce7e  push rdx
00007d20d97dce7f  push rdi
00007d20d97dce80  push rsi
00007d20d97dce81  push r8
00007d20d97dce83  push r9
00007d20d97dce85  push r10
00007d20d97dce87  push r11
00007d20d97dce89  sub rsp, 0xF0
00007d20d97dce90  vmovaps [rsp], xmm0
00007d20d97dce95  vmovaps [rsp+0x10], xmm1
00007d20d97dce9b  vmovaps [rsp+0x20], xmm2
00007d20d97dcea1  vmovaps [rsp+0x30], xmm3
00007d20d97dcea7  vmovaps [rsp+0x40], xmm4
00007d20d97dcead  vmovaps [rsp+0x50], xmm5
00007d20d97dceb3  vmovaps [rsp+0x60], xmm7
00007d20d97dceb9  vmovaps [rsp+0x70], xmm8
00007d20d97dcebf  vmovaps [rsp+0x80], xmm9
00007d20d97dcec8  vmovaps [rsp+0x90], xmm10
00007d20d97dced1  vmovaps [rsp+0xA0], xmm11
00007d20d97dceda  vmovaps [rsp+0xB0], xmm12
00007d20d97dcee3  vmovaps [rsp+0xC0], xmm13
00007d20d97dceec  vmovaps [rsp+0xD0], xmm14
00007d20d97dcef5  vmovaps [rsp+0xE0], xmm15
00007d20d97dcefe  sub rsp, 0x30
00007d20d97dcf02  movaps [rsp], xmm6
00007d20d97dcf06  movaps [rsp+0x10], xmm12
00007d20d97dcf0c  movaps [rsp+0x20], xmm11
00007d20d97dcf12  lea rdi, [rsp]
00007d20d97dcf16  mov esi, 0x00
00007d20d97dcf1b  mov rax, 0x5EFBF4CF6530
00007d20d97dcf25  call rax
00007d20d97dcf27  movaps xmm6, [rsp]
00007d20d97dcf2b  add rsp, 0x30
00007d20d97dcf2f  vmovaps xmm0, [rsp]
00007d20d97dcf34  vmovaps xmm1, [rsp+0x10]
00007d20d97dcf3a  vmovaps xmm2, [rsp+0x20]
00007d20d97dcf40  vmovaps xmm3, [rsp+0x30]
00007d20d97dcf46  vmovaps xmm4, [rsp+0x40]
00007d20d97dcf4c  vmovaps xmm5, [rsp+0x50]
00007d20d97dcf52  vmovaps xmm7, [rsp+0x60]
00007d20d97dcf58  vmovaps xmm8, [rsp+0x70]
00007d20d97dcf5e  vmovaps xmm9, [rsp+0x80]
00007d20d97dcf67  vmovaps xmm10, [rsp+0x90]
00007d20d97dcf70  vmovaps xmm11, [rsp+0xA0]
00007d20d97dcf79  vmovaps xmm12, [rsp+0xB0]
00007d20d97dcf82  vmovaps xmm13, [rsp+0xC0]
00007d20d97dcf8b  vmovaps xmm14, [rsp+0xD0]
00007d20d97dcf94  vmovaps xmm15, [rsp+0xE0]
00007d20d97dcf9d  add rsp, 0xF0
00007d20d97dcfa4  pop r11
00007d20d97dcfa6  pop r10
00007d20d97dcfa8  pop r9
00007d20d97dcfaa  pop r8
00007d20d97dcfac  pop rsi
00007d20d97dcfad  pop rdi
00007d20d97dcfae  pop rdx
00007d20d97dcfaf  pop rcx
00007d20d97dcfb0  pop rax
00007d20d97dcfb1  add rsp, 0x08
00007d20d97dcfb5  jmp 0x00007D20D97DBBD4
00007d20d97dcfba  sub rsp, 0x08
00007d20d97dcfbe  push rax
00007d20d97dcfbf  push rcx
00007d20d97dcfc0  push rdx
00007d20d97dcfc1  push rdi
00007d20d97dcfc2  push rsi
00007d20d97dcfc3  push r8
00007d20d97dcfc5  push r9
00007d20d97dcfc7  push r10
00007d20d97dcfc9  push r11
00007d20d97dcfcb  sub rsp, 0xF0
00007d20d97dcfd2  vmovaps [rsp], xmm0
00007d20d97dcfd7  vmovaps [rsp+0x10], xmm1
00007d20d97dcfdd  vmovaps [rsp+0x20], xmm2
00007d20d97dcfe3  vmovaps [rsp+0x30], xmm4
00007d20d97dcfe9  vmovaps [rsp+0x40], xmm5
00007d20d97dcfef  vmovaps [rsp+0x50], xmm6
00007d20d97dcff5  vmovaps [rsp+0x60], xmm7
00007d20d97dcffb  vmovaps [rsp+0x70], xmm8
00007d20d97dd001  vmovaps [rsp+0x80], xmm9
00007d20d97dd00a  vmovaps [rsp+0x90], xmm10
00007d20d97dd013  vmovaps [rsp+0xA0], xmm11
00007d20d97dd01c  vmovaps [rsp+0xB0], xmm12
00007d20d97dd025  vmovaps [rsp+0xC0], xmm13
00007d20d97dd02e  vmovaps [rsp+0xD0], xmm14
00007d20d97dd037  vmovaps [rsp+0xE0], xmm15
00007d20d97dd040  sub rsp, 0x30
00007d20d97dd044  movaps [rsp], xmm3
00007d20d97dd048  movaps [rsp+0x10], xmm5
00007d20d97dd04d  movaps [rsp+0x20], xmm4
00007d20d97dd052  lea rdi, [rsp]
00007d20d97dd056  mov esi, 0x00
00007d20d97dd05b  mov rax, 0x5EFBF4CF6530
00007d20d97dd065  call rax
00007d20d97dd067  movaps xmm3, [rsp]
00007d20d97dd06b  add rsp, 0x30
00007d20d97dd06f  vmovaps xmm0, [rsp]
00007d20d97dd074  vmovaps xmm1, [rsp+0x10]
00007d20d97dd07a  vmovaps xmm2, [rsp+0x20]
00007d20d97dd080  vmovaps xmm4, [rsp+0x30]
00007d20d97dd086  vmovaps xmm5, [rsp+0x40]
00007d20d97dd08c  vmovaps xmm6, [rsp+0x50]
00007d20d97dd092  vmovaps xmm7, [rsp+0x60]
00007d20d97dd098  vmovaps xmm8, [rsp+0x70]
00007d20d97dd09e  vmovaps xmm9, [rsp+0x80]
00007d20d97dd0a7  vmovaps xmm10, [rsp+0x90]
00007d20d97dd0b0  vmovaps xmm11, [rsp+0xA0]
00007d20d97dd0b9  vmovaps xmm12, [rsp+0xB0]
00007d20d97dd0c2  vmovaps xmm13, [rsp+0xC0]
00007d20d97dd0cb  vmovaps xmm14, [rsp+0xD0]
00007d20d97dd0d4  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd0dd  add rsp, 0xF0
00007d20d97dd0e4  pop r11
00007d20d97dd0e6  pop r10
00007d20d97dd0e8  pop r9
00007d20d97dd0ea  pop r8
00007d20d97dd0ec  pop rsi
00007d20d97dd0ed  pop rdi
00007d20d97dd0ee  pop rdx
00007d20d97dd0ef  pop rcx
00007d20d97dd0f0  pop rax
00007d20d97dd0f1  add rsp, 0x08
00007d20d97dd0f5  jmp 0x00007D20D97DBC35
00007d20d97dd0fa  sub rsp, 0x08
00007d20d97dd0fe  push rax
00007d20d97dd0ff  push rcx
00007d20d97dd100  push rdx
00007d20d97dd101  push rdi
00007d20d97dd102  push rsi
00007d20d97dd103  push r8
00007d20d97dd105  push r9
00007d20d97dd107  push r10
00007d20d97dd109  push r11
00007d20d97dd10b  sub rsp, 0xF0
00007d20d97dd112  vmovaps [rsp], xmm0
00007d20d97dd117  vmovaps [rsp+0x10], xmm1
00007d20d97dd11d  vmovaps [rsp+0x20], xmm2
00007d20d97dd123  vmovaps [rsp+0x30], xmm3
00007d20d97dd129  vmovaps [rsp+0x40], xmm4
00007d20d97dd12f  vmovaps [rsp+0x50], xmm6
00007d20d97dd135  vmovaps [rsp+0x60], xmm7
00007d20d97dd13b  vmovaps [rsp+0x70], xmm8
00007d20d97dd141  vmovaps [rsp+0x80], xmm9
00007d20d97dd14a  vmovaps [rsp+0x90], xmm10
00007d20d97dd153  vmovaps [rsp+0xA0], xmm11
00007d20d97dd15c  vmovaps [rsp+0xB0], xmm12
00007d20d97dd165  vmovaps [rsp+0xC0], xmm13
00007d20d97dd16e  vmovaps [rsp+0xD0], xmm14
00007d20d97dd177  vmovaps [rsp+0xE0], xmm15
00007d20d97dd180  sub rsp, 0x30
00007d20d97dd184  movaps [rsp], xmm5
00007d20d97dd188  movaps [rsp+0x10], xmm8
00007d20d97dd18e  movaps [rsp+0x20], xmm15
00007d20d97dd194  lea rdi, [rsp]
00007d20d97dd198  mov esi, 0x00
00007d20d97dd19d  mov rax, 0x5EFBF4CF6530
00007d20d97dd1a7  call rax
00007d20d97dd1a9  movaps xmm5, [rsp]
00007d20d97dd1ad  add rsp, 0x30
00007d20d97dd1b1  vmovaps xmm0, [rsp]
00007d20d97dd1b6  vmovaps xmm1, [rsp+0x10]
00007d20d97dd1bc  vmovaps xmm2, [rsp+0x20]
00007d20d97dd1c2  vmovaps xmm3, [rsp+0x30]
00007d20d97dd1c8  vmovaps xmm4, [rsp+0x40]
00007d20d97dd1ce  vmovaps xmm6, [rsp+0x50]
00007d20d97dd1d4  vmovaps xmm7, [rsp+0x60]
00007d20d97dd1da  vmovaps xmm8, [rsp+0x70]
00007d20d97dd1e0  vmovaps xmm9, [rsp+0x80]
00007d20d97dd1e9  vmovaps xmm10, [rsp+0x90]
00007d20d97dd1f2  vmovaps xmm11, [rsp+0xA0]
00007d20d97dd1fb  vmovaps xmm12, [rsp+0xB0]
00007d20d97dd204  vmovaps xmm13, [rsp+0xC0]
00007d20d97dd20d  vmovaps xmm14, [rsp+0xD0]
00007d20d97dd216  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd21f  add rsp, 0xF0
00007d20d97dd226  pop r11
00007d20d97dd228  pop r10
00007d20d97dd22a  pop r9
00007d20d97dd22c  pop r8
00007d20d97dd22e  pop rsi
00007d20d97dd22f  pop rdi
00007d20d97dd230  pop rdx
00007d20d97dd231  pop rcx
00007d20d97dd232  pop rax
00007d20d97dd233  add rsp, 0x08
00007d20d97dd237  jmp 0x00007D20D97DBC73
00007d20d97dd23c  sub rsp, 0x08
00007d20d97dd240  push rax
00007d20d97dd241  push rcx
00007d20d97dd242  push rdx
00007d20d97dd243  push rdi
00007d20d97dd244  push rsi
00007d20d97dd245  push r8
00007d20d97dd247  push r9
00007d20d97dd249  push r10
00007d20d97dd24b  push r11
00007d20d97dd24d  sub rsp, 0xF0
00007d20d97dd254  vmovaps [rsp], xmm0
00007d20d97dd259  vmovaps [rsp+0x10], xmm1
00007d20d97dd25f  vmovaps [rsp+0x20], xmm2
00007d20d97dd265  vmovaps [rsp+0x30], xmm3
00007d20d97dd26b  vmovaps [rsp+0x40], xmm5
00007d20d97dd271  vmovaps [rsp+0x50], xmm6
00007d20d97dd277  vmovaps [rsp+0x60], xmm7
00007d20d97dd27d  vmovaps [rsp+0x70], xmm8
00007d20d97dd283  vmovaps [rsp+0x80], xmm9
00007d20d97dd28c  vmovaps [rsp+0x90], xmm10
00007d20d97dd295  vmovaps [rsp+0xA0], xmm11
00007d20d97dd29e  vmovaps [rsp+0xB0], xmm12
00007d20d97dd2a7  vmovaps [rsp+0xC0], xmm13
00007d20d97dd2b0  vmovaps [rsp+0xD0], xmm14
00007d20d97dd2b9  vmovaps [rsp+0xE0], xmm15
00007d20d97dd2c2  sub rsp, 0x30
00007d20d97dd2c6  movaps [rsp], xmm4
00007d20d97dd2ca  movaps [rsp+0x10], xmm9
00007d20d97dd2d0  movaps [rsp+0x20], xmm8
00007d20d97dd2d6  lea rdi, [rsp]
00007d20d97dd2da  mov esi, 0x00
00007d20d97dd2df  mov rax, 0x5EFBF4CF6530
00007d20d97dd2e9  call rax
00007d20d97dd2eb  movaps xmm4, [rsp]
00007d20d97dd2ef  add rsp, 0x30
00007d20d97dd2f3  vmovaps xmm0, [rsp]
00007d20d97dd2f8  vmovaps xmm1, [rsp+0x10]
00007d20d97dd2fe  vmovaps xmm2, [rsp+0x20]
00007d20d97dd304  vmovaps xmm3, [rsp+0x30]
00007d20d97dd30a  vmovaps xmm5, [rsp+0x40]
00007d20d97dd310  vmovaps xmm6, [rsp+0x50]
00007d20d97dd316  vmovaps xmm7, [rsp+0x60]
00007d20d97dd31c  vmovaps xmm8, [rsp+0x70]
00007d20d97dd322  vmovaps xmm9, [rsp+0x80]
00007d20d97dd32b  vmovaps xmm10, [rsp+0x90]
00007d20d97dd334  vmovaps xmm11, [rsp+0xA0]
00007d20d97dd33d  vmovaps xmm12, [rsp+0xB0]
00007d20d97dd346  vmovaps xmm13, [rsp+0xC0]
00007d20d97dd34f  vmovaps xmm14, [rsp+0xD0]
00007d20d97dd358  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd361  add rsp, 0xF0
00007d20d97dd368  pop r11
00007d20d97dd36a  pop r10
00007d20d97dd36c  pop r9
00007d20d97dd36e  pop r8
00007d20d97dd370  pop rsi
00007d20d97dd371  pop rdi
00007d20d97dd372  pop rdx
00007d20d97dd373  pop rcx
00007d20d97dd374  pop rax
00007d20d97dd375  add rsp, 0x08
00007d20d97dd379  jmp 0x00007D20D97DBC94
00007d20d97dd37e  sub rsp, 0x08
00007d20d97dd382  push rax
00007d20d97dd383  push rcx
00007d20d97dd384  push rdx
00007d20d97dd385  push rdi
00007d20d97dd386  push rsi
00007d20d97dd387  push r8
00007d20d97dd389  push r9
00007d20d97dd38b  push r10
00007d20d97dd38d  push r11
00007d20d97dd38f  sub rsp, 0xF0
00007d20d97dd396  vmovaps [rsp], xmm0
00007d20d97dd39b  vmovaps [rsp+0x10], xmm1
00007d20d97dd3a1  vmovaps [rsp+0x20], xmm2
00007d20d97dd3a7  vmovaps [rsp+0x30], xmm3
00007d20d97dd3ad  vmovaps [rsp+0x40], xmm4
00007d20d97dd3b3  vmovaps [rsp+0x50], xmm5
00007d20d97dd3b9  vmovaps [rsp+0x60], xmm6
00007d20d97dd3bf  vmovaps [rsp+0x70], xmm7
00007d20d97dd3c5  vmovaps [rsp+0x80], xmm8
00007d20d97dd3ce  vmovaps [rsp+0x90], xmm10
00007d20d97dd3d7  vmovaps [rsp+0xA0], xmm11
00007d20d97dd3e0  vmovaps [rsp+0xB0], xmm12
00007d20d97dd3e9  vmovaps [rsp+0xC0], xmm13
00007d20d97dd3f2  vmovaps [rsp+0xD0], xmm14
00007d20d97dd3fb  vmovaps [rsp+0xE0], xmm15
00007d20d97dd404  sub rsp, 0x30
00007d20d97dd408  movaps [rsp], xmm9
00007d20d97dd40d  movaps [rsp+0x10], xmm10
00007d20d97dd413  movaps [rsp+0x20], xmm8
00007d20d97dd419  lea rdi, [rsp]
00007d20d97dd41d  mov esi, 0x00
00007d20d97dd422  mov rax, 0x5EFBF4CF6530
00007d20d97dd42c  call rax
00007d20d97dd42e  movaps xmm9, [rsp]
00007d20d97dd433  add rsp, 0x30
00007d20d97dd437  vmovaps xmm0, [rsp]
00007d20d97dd43c  vmovaps xmm1, [rsp+0x10]
00007d20d97dd442  vmovaps xmm2, [rsp+0x20]
00007d20d97dd448  vmovaps xmm3, [rsp+0x30]
00007d20d97dd44e  vmovaps xmm4, [rsp+0x40]
00007d20d97dd454  vmovaps xmm5, [rsp+0x50]
00007d20d97dd45a  vmovaps xmm6, [rsp+0x60]
00007d20d97dd460  vmovaps xmm7, [rsp+0x70]
00007d20d97dd466  vmovaps xmm8, [rsp+0x80]
00007d20d97dd46f  vmovaps xmm10, [rsp+0x90]
00007d20d97dd478  vmovaps xmm11, [rsp+0xA0]
00007d20d97dd481  vmovaps xmm12, [rsp+0xB0]
00007d20d97dd48a  vmovaps xmm13, [rsp+0xC0]
00007d20d97dd493  vmovaps xmm14, [rsp+0xD0]
00007d20d97dd49c  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd4a5  add rsp, 0xF0
00007d20d97dd4ac  pop r11
00007d20d97dd4ae  pop r10
00007d20d97dd4b0  pop r9
00007d20d97dd4b2  pop r8
00007d20d97dd4b4  pop rsi
00007d20d97dd4b5  pop rdi
00007d20d97dd4b6  pop rdx
00007d20d97dd4b7  pop rcx
00007d20d97dd4b8  pop rax
00007d20d97dd4b9  add rsp, 0x08
00007d20d97dd4bd  jmp 0x00007D20D97DBCAE
00007d20d97dd4c2  call 0x00007D20D96B52F0
00007d20d97dd4c7  jmp 0x00007D20D97DBDC8
00007d20d97dd4cc  call 0x00007D20D96B52F0
00007d20d97dd4d1  jmp 0x00007D20D97DBDDE
00007d20d97dd4d6  sub rsp, 0x08
00007d20d97dd4da  push rax
00007d20d97dd4db  push rcx
00007d20d97dd4dc  push rdx
00007d20d97dd4dd  push rdi
00007d20d97dd4de  push rsi
00007d20d97dd4df  push r8
00007d20d97dd4e1  push r9
00007d20d97dd4e3  push r10
00007d20d97dd4e5  push r11
00007d20d97dd4e7  sub rsp, 0xF0
00007d20d97dd4ee  vmovaps [rsp], xmm0
00007d20d97dd4f3  vmovaps [rsp+0x10], xmm2
00007d20d97dd4f9  vmovaps [rsp+0x20], xmm3
00007d20d97dd4ff  vmovaps [rsp+0x30], xmm4
00007d20d97dd505  vmovaps [rsp+0x40], xmm5
00007d20d97dd50b  vmovaps [rsp+0x50], xmm6
00007d20d97dd511  vmovaps [rsp+0x60], xmm7
00007d20d97dd517  vmovaps [rsp+0x70], xmm8
00007d20d97dd51d  vmovaps [rsp+0x80], xmm9
00007d20d97dd526  vmovaps [rsp+0x90], xmm10
00007d20d97dd52f  vmovaps [rsp+0xA0], xmm11
00007d20d97dd538  vmovaps [rsp+0xB0], xmm12
00007d20d97dd541  vmovaps [rsp+0xC0], xmm13
00007d20d97dd54a  vmovaps [rsp+0xD0], xmm14
00007d20d97dd553  vmovaps [rsp+0xE0], xmm15
00007d20d97dd55c  sub rsp, 0x30
00007d20d97dd560  movaps [rsp], xmm1
00007d20d97dd564  movaps [rsp+0x10], xmm6
00007d20d97dd569  movaps [rsp+0x20], xmm15
00007d20d97dd56f  lea rdi, [rsp]
00007d20d97dd573  mov esi, 0x00
00007d20d97dd578  mov rax, 0x5EFBF4CF6530
00007d20d97dd582  call rax
00007d20d97dd584  movaps xmm1, [rsp]
00007d20d97dd588  add rsp, 0x30
00007d20d97dd58c  vmovaps xmm0, [rsp]
00007d20d97dd591  vmovaps xmm2, [rsp+0x10]
00007d20d97dd597  vmovaps xmm3, [rsp+0x20]
00007d20d97dd59d  vmovaps xmm4, [rsp+0x30]
00007d20d97dd5a3  vmovaps xmm5, [rsp+0x40]
00007d20d97dd5a9  vmovaps xmm6, [rsp+0x50]
00007d20d97dd5af  vmovaps xmm7, [rsp+0x60]
00007d20d97dd5b5  vmovaps xmm8, [rsp+0x70]
00007d20d97dd5bb  vmovaps xmm9, [rsp+0x80]
00007d20d97dd5c4  vmovaps xmm10, [rsp+0x90]
00007d20d97dd5cd  vmovaps xmm11, [rsp+0xA0]
00007d20d97dd5d6  vmovaps xmm12, [rsp+0xB0]
00007d20d97dd5df  vmovaps xmm13, [rsp+0xC0]
00007d20d97dd5e8  vmovaps xmm14, [rsp+0xD0]
00007d20d97dd5f1  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd5fa  add rsp, 0xF0
00007d20d97dd601  pop r11
00007d20d97dd603  pop r10
00007d20d97dd605  pop r9
00007d20d97dd607  pop r8
00007d20d97dd609  pop rsi
00007d20d97dd60a  pop rdi
00007d20d97dd60b  pop rdx
00007d20d97dd60c  pop rcx
00007d20d97dd60d  pop rax
00007d20d97dd60e  add rsp, 0x08
00007d20d97dd612  jmp 0x00007D20D97DBE1B
00007d20d97dd617  call 0x00007D20D96C4620
00007d20d97dd61c  jmp 0x00007D20D97DBE28
00007d20d97dd621  sub rsp, 0x08
00007d20d97dd625  push rax
00007d20d97dd626  push rcx
00007d20d97dd627  push rdx
00007d20d97dd628  push rdi
00007d20d97dd629  push rsi
00007d20d97dd62a  push r8
00007d20d97dd62c  push r9
00007d20d97dd62e  push r10
00007d20d97dd630  push r11
00007d20d97dd632  sub rsp, 0xF0
00007d20d97dd639  vmovaps [rsp], xmm0
00007d20d97dd63e  vmovaps [rsp+0x10], xmm1
00007d20d97dd644  vmovaps [rsp+0x20], xmm2
00007d20d97dd64a  vmovaps [rsp+0x30], xmm3
00007d20d97dd650  vmovaps [rsp+0x40], xmm4
00007d20d97dd656  vmovaps [rsp+0x50], xmm5
00007d20d97dd65c  vmovaps [rsp+0x60], xmm6
00007d20d97dd662  vmovaps [rsp+0x70], xmm7
00007d20d97dd668  vmovaps [rsp+0x80], xmm8
00007d20d97dd671  vmovaps [rsp+0x90], xmm9
00007d20d97dd67a  vmovaps [rsp+0xA0], xmm10
00007d20d97dd683  vmovaps [rsp+0xB0], xmm11
00007d20d97dd68c  vmovaps [rsp+0xC0], xmm12
00007d20d97dd695  vmovaps [rsp+0xD0], xmm13
00007d20d97dd69e  vmovaps [rsp+0xE0], xmm15
00007d20d97dd6a7  sub rsp, 0x30
00007d20d97dd6ab  movaps [rsp], xmm14
00007d20d97dd6b0  movaps [rsp+0x10], xmm4
00007d20d97dd6b5  movaps [rsp+0x20], xmm3
00007d20d97dd6ba  lea rdi, [rsp]
00007d20d97dd6be  mov esi, 0x00
00007d20d97dd6c3  mov rax, 0x5EFBF4CF6530
00007d20d97dd6cd  call rax
00007d20d97dd6cf  movaps xmm14, [rsp]
00007d20d97dd6d4  add rsp, 0x30
00007d20d97dd6d8  vmovaps xmm0, [rsp]
00007d20d97dd6dd  vmovaps xmm1, [rsp+0x10]
00007d20d97dd6e3  vmovaps xmm2, [rsp+0x20]
00007d20d97dd6e9  vmovaps xmm3, [rsp+0x30]
00007d20d97dd6ef  vmovaps xmm4, [rsp+0x40]
00007d20d97dd6f5  vmovaps xmm5, [rsp+0x50]
00007d20d97dd6fb  vmovaps xmm6, [rsp+0x60]
00007d20d97dd701  vmovaps xmm7, [rsp+0x70]
00007d20d97dd707  vmovaps xmm8, [rsp+0x80]
00007d20d97dd710  vmovaps xmm9, [rsp+0x90]
00007d20d97dd719  vmovaps xmm10, [rsp+0xA0]
00007d20d97dd722  vmovaps xmm11, [rsp+0xB0]
00007d20d97dd72b  vmovaps xmm12, [rsp+0xC0]
00007d20d97dd734  vmovaps xmm13, [rsp+0xD0]
00007d20d97dd73d  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd746  add rsp, 0xF0
00007d20d97dd74d  pop r11
00007d20d97dd74f  pop r10
00007d20d97dd751  pop r9
00007d20d97dd753  pop r8
00007d20d97dd755  pop rsi
00007d20d97dd756  pop rdi
00007d20d97dd757  pop rdx
00007d20d97dd758  pop rcx
00007d20d97dd759  pop rax
00007d20d97dd75a  add rsp, 0x08
00007d20d97dd75e  jmp 0x00007D20D97DBE42
00007d20d97dd763  sub rsp, 0x08
00007d20d97dd767  push rax
00007d20d97dd768  push rcx
00007d20d97dd769  push rdx
00007d20d97dd76a  push rdi
00007d20d97dd76b  push rsi
00007d20d97dd76c  push r8
00007d20d97dd76e  push r9
00007d20d97dd770  push r10
00007d20d97dd772  push r11
00007d20d97dd774  sub rsp, 0xF0
00007d20d97dd77b  vmovaps [rsp], xmm0
00007d20d97dd780  vmovaps [rsp+0x10], xmm1
00007d20d97dd786  vmovaps [rsp+0x20], xmm2
00007d20d97dd78c  vmovaps [rsp+0x30], xmm3
00007d20d97dd792  vmovaps [rsp+0x40], xmm4
00007d20d97dd798  vmovaps [rsp+0x50], xmm5
00007d20d97dd79e  vmovaps [rsp+0x60], xmm7
00007d20d97dd7a4  vmovaps [rsp+0x70], xmm8
00007d20d97dd7aa  vmovaps [rsp+0x80], xmm9
00007d20d97dd7b3  vmovaps [rsp+0x90], xmm10
00007d20d97dd7bc  vmovaps [rsp+0xA0], xmm11
00007d20d97dd7c5  vmovaps [rsp+0xB0], xmm12
00007d20d97dd7ce  vmovaps [rsp+0xC0], xmm13
00007d20d97dd7d7  vmovaps [rsp+0xD0], xmm14
00007d20d97dd7e0  vmovaps [rsp+0xE0], xmm15
00007d20d97dd7e9  sub rsp, 0x30
00007d20d97dd7ed  movaps [rsp], xmm6
00007d20d97dd7f1  movaps [rsp+0x10], xmm9
00007d20d97dd7f7  movaps [rsp+0x20], xmm7
00007d20d97dd7fc  lea rdi, [rsp]
00007d20d97dd800  mov esi, 0x00
00007d20d97dd805  mov rax, 0x5EFBF4CF6530
00007d20d97dd80f  call rax
00007d20d97dd811  movaps xmm6, [rsp]
00007d20d97dd815  add rsp, 0x30
00007d20d97dd819  vmovaps xmm0, [rsp]
00007d20d97dd81e  vmovaps xmm1, [rsp+0x10]
00007d20d97dd824  vmovaps xmm2, [rsp+0x20]
00007d20d97dd82a  vmovaps xmm3, [rsp+0x30]
00007d20d97dd830  vmovaps xmm4, [rsp+0x40]
00007d20d97dd836  vmovaps xmm5, [rsp+0x50]
00007d20d97dd83c  vmovaps xmm7, [rsp+0x60]
00007d20d97dd842  vmovaps xmm8, [rsp+0x70]
00007d20d97dd848  vmovaps xmm9, [rsp+0x80]
00007d20d97dd851  vmovaps xmm10, [rsp+0x90]
00007d20d97dd85a  vmovaps xmm11, [rsp+0xA0]
00007d20d97dd863  vmovaps xmm12, [rsp+0xB0]
00007d20d97dd86c  vmovaps xmm13, [rsp+0xC0]
00007d20d97dd875  vmovaps xmm14, [rsp+0xD0]
00007d20d97dd87e  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd887  add rsp, 0xF0
00007d20d97dd88e  pop r11
00007d20d97dd890  pop r10
00007d20d97dd892  pop r9
00007d20d97dd894  pop r8
00007d20d97dd896  pop rsi
00007d20d97dd897  pop rdi
00007d20d97dd898  pop rdx
00007d20d97dd899  pop rcx
00007d20d97dd89a  pop rax
00007d20d97dd89b  add rsp, 0x08
00007d20d97dd89f  jmp 0x00007D20D97DBE5A
00007d20d97dd8a4  sub rsp, 0x08
00007d20d97dd8a8  push rax
00007d20d97dd8a9  push rcx
00007d20d97dd8aa  push rdx
00007d20d97dd8ab  push rdi
00007d20d97dd8ac  push rsi
00007d20d97dd8ad  push r8
00007d20d97dd8af  push r9
00007d20d97dd8b1  push r10
00007d20d97dd8b3  push r11
00007d20d97dd8b5  sub rsp, 0xF0
00007d20d97dd8bc  vmovaps [rsp], xmm0
00007d20d97dd8c1  vmovaps [rsp+0x10], xmm1
00007d20d97dd8c7  vmovaps [rsp+0x20], xmm2
00007d20d97dd8cd  vmovaps [rsp+0x30], xmm3
00007d20d97dd8d3  vmovaps [rsp+0x40], xmm4
00007d20d97dd8d9  vmovaps [rsp+0x50], xmm5
00007d20d97dd8df  vmovaps [rsp+0x60], xmm6
00007d20d97dd8e5  vmovaps [rsp+0x70], xmm8
00007d20d97dd8eb  vmovaps [rsp+0x80], xmm9
00007d20d97dd8f4  vmovaps [rsp+0x90], xmm10
00007d20d97dd8fd  vmovaps [rsp+0xA0], xmm11
00007d20d97dd906  vmovaps [rsp+0xB0], xmm12
00007d20d97dd90f  vmovaps [rsp+0xC0], xmm13
00007d20d97dd918  vmovaps [rsp+0xD0], xmm14
00007d20d97dd921  vmovaps [rsp+0xE0], xmm15
00007d20d97dd92a  sub rsp, 0x30
00007d20d97dd92e  movaps [rsp], xmm7
00007d20d97dd932  movaps [rsp+0x10], xmm4
00007d20d97dd937  movaps [rsp+0x20], xmm9
00007d20d97dd93d  lea rdi, [rsp]
00007d20d97dd941  mov esi, 0x00
00007d20d97dd946  mov rax, 0x5EFBF4CF6530
00007d20d97dd950  call rax
00007d20d97dd952  movaps xmm7, [rsp]
00007d20d97dd956  add rsp, 0x30
00007d20d97dd95a  vmovaps xmm0, [rsp]
00007d20d97dd95f  vmovaps xmm1, [rsp+0x10]
00007d20d97dd965  vmovaps xmm2, [rsp+0x20]
00007d20d97dd96b  vmovaps xmm3, [rsp+0x30]
00007d20d97dd971  vmovaps xmm4, [rsp+0x40]
00007d20d97dd977  vmovaps xmm5, [rsp+0x50]
00007d20d97dd97d  vmovaps xmm6, [rsp+0x60]
00007d20d97dd983  vmovaps xmm8, [rsp+0x70]
00007d20d97dd989  vmovaps xmm9, [rsp+0x80]
00007d20d97dd992  vmovaps xmm10, [rsp+0x90]
00007d20d97dd99b  vmovaps xmm11, [rsp+0xA0]
00007d20d97dd9a4  vmovaps xmm12, [rsp+0xB0]
00007d20d97dd9ad  vmovaps xmm13, [rsp+0xC0]
00007d20d97dd9b6  vmovaps xmm14, [rsp+0xD0]
00007d20d97dd9bf  vmovaps xmm15, [rsp+0xE0]
00007d20d97dd9c8  add rsp, 0xF0
00007d20d97dd9cf  pop r11
00007d20d97dd9d1  pop r10
00007d20d97dd9d3  pop r9
00007d20d97dd9d5  pop r8
00007d20d97dd9d7  pop rsi
00007d20d97dd9d8  pop rdi
00007d20d97dd9d9  pop rdx
00007d20d97dd9da  pop rcx
00007d20d97dd9db  pop rax
00007d20d97dd9dc  add rsp, 0x08
00007d20d97dd9e0  jmp 0x00007D20D97DBE87
00007d20d97dd9e5  sub rsp, 0x08
00007d20d97dd9e9  push rax
00007d20d97dd9ea  push rcx
00007d20d97dd9eb  push rdx
00007d20d97dd9ec  push rdi
00007d20d97dd9ed  push rsi
00007d20d97dd9ee  push r8
00007d20d97dd9f0  push r9
00007d20d97dd9f2  push r10
00007d20d97dd9f4  push r11
00007d20d97dd9f6  sub rsp, 0xF0
00007d20d97dd9fd  vmovaps [rsp], xmm0
00007d20d97dda02  vmovaps [rsp+0x10], xmm1
00007d20d97dda08  vmovaps [rsp+0x20], xmm2
00007d20d97dda0e  vmovaps [rsp+0x30], xmm3
00007d20d97dda14  vmovaps [rsp+0x40], xmm5
00007d20d97dda1a  vmovaps [rsp+0x50], xmm6
00007d20d97dda20  vmovaps [rsp+0x60], xmm7
00007d20d97dda26  vmovaps [rsp+0x70], xmm8
00007d20d97dda2c  vmovaps [rsp+0x80], xmm9
00007d20d97dda35  vmovaps [rsp+0x90], xmm10
00007d20d97dda3e  vmovaps [rsp+0xA0], xmm11
00007d20d97dda47  vmovaps [rsp+0xB0], xmm12
00007d20d97dda50  vmovaps [rsp+0xC0], xmm13
00007d20d97dda59  vmovaps [rsp+0xD0], xmm14
00007d20d97dda62  vmovaps [rsp+0xE0], xmm15
00007d20d97dda6b  sub rsp, 0x30
00007d20d97dda6f  movaps [rsp], xmm4
00007d20d97dda73  movaps [rsp+0x10], xmm15
00007d20d97dda79  movaps [rsp+0x20], xmm9
00007d20d97dda7f  lea rdi, [rsp]
00007d20d97dda83  mov esi, 0x00
00007d20d97dda88  mov rax, 0x5EFBF4CF6530
00007d20d97dda92  call rax
00007d20d97dda94  movaps xmm4, [rsp]
00007d20d97dda98  add rsp, 0x30
00007d20d97dda9c  vmovaps xmm0, [rsp]
00007d20d97ddaa1  vmovaps xmm1, [rsp+0x10]
00007d20d97ddaa7  vmovaps xmm2, [rsp+0x20]
00007d20d97ddaad  vmovaps xmm3, [rsp+0x30]
00007d20d97ddab3  vmovaps xmm5, [rsp+0x40]
00007d20d97ddab9  vmovaps xmm6, [rsp+0x50]
00007d20d97ddabf  vmovaps xmm7, [rsp+0x60]
00007d20d97ddac5  vmovaps xmm8, [rsp+0x70]
00007d20d97ddacb  vmovaps xmm9, [rsp+0x80]
00007d20d97ddad4  vmovaps xmm10, [rsp+0x90]
00007d20d97ddadd  vmovaps xmm11, [rsp+0xA0]
00007d20d97ddae6  vmovaps xmm12, [rsp+0xB0]
00007d20d97ddaef  vmovaps xmm13, [rsp+0xC0]
00007d20d97ddaf8  vmovaps xmm14, [rsp+0xD0]
00007d20d97ddb01  vmovaps xmm15, [rsp+0xE0]
00007d20d97ddb0a  add rsp, 0xF0
00007d20d97ddb11  pop r11
00007d20d97ddb13  pop r10
00007d20d97ddb15  pop r9
00007d20d97ddb17  pop r8
00007d20d97ddb19  pop rsi
00007d20d97ddb1a  pop rdi
00007d20d97ddb1b  pop rdx
00007d20d97ddb1c  pop rcx
00007d20d97ddb1d  pop rax
00007d20d97ddb1e  add rsp, 0x08
00007d20d97ddb22  jmp 0x00007D20D97DBEAC
00007d20d97ddb27  call 0x00007D20D96C4620
00007d20d97ddb2c  jmp 0x00007D20D97DBEB9
00007d20d97ddb31  sub rsp, 0x08
00007d20d97ddb35  push rax
00007d20d97ddb36  push rcx
00007d20d97ddb37  push rdx
00007d20d97ddb38  push rdi
00007d20d97ddb39  push rsi
00007d20d97ddb3a  push r8
00007d20d97ddb3c  push r9
00007d20d97ddb3e  push r10
00007d20d97ddb40  push r11
00007d20d97ddb42  sub rsp, 0xF0
00007d20d97ddb49  vmovaps [rsp], xmm0
00007d20d97ddb4e  vmovaps [rsp+0x10], xmm1
00007d20d97ddb54  vmovaps [rsp+0x20], xmm2
00007d20d97ddb5a  vmovaps [rsp+0x30], xmm4
00007d20d97ddb60  vmovaps [rsp+0x40], xmm5
00007d20d97ddb66  vmovaps [rsp+0x50], xmm6
00007d20d97ddb6c  vmovaps [rsp+0x60], xmm7
00007d20d97ddb72  vmovaps [rsp+0x70], xmm8
00007d20d97ddb78  vmovaps [rsp+0x80], xmm9
00007d20d97ddb81  vmovaps [rsp+0x90], xmm10
00007d20d97ddb8a  vmovaps [rsp+0xA0], xmm11
00007d20d97ddb93  vmovaps [rsp+0xB0], xmm12
00007d20d97ddb9c  vmovaps [rsp+0xC0], xmm13
00007d20d97ddba5  vmovaps [rsp+0xD0], xmm14
00007d20d97ddbae  vmovaps [rsp+0xE0], xmm15
00007d20d97ddbb7  sub rsp, 0x30
00007d20d97ddbbb  movaps [rsp], xmm3
00007d20d97ddbbf  movaps [rsp+0x10], xmm1
00007d20d97ddbc4  movaps [rsp+0x20], xmm9
00007d20d97ddbca  lea rdi, [rsp]
00007d20d97ddbce  mov esi, 0x00
00007d20d97ddbd3  mov rax, 0x5EFBF4CF6530
00007d20d97ddbdd  call rax
00007d20d97ddbdf  movaps xmm3, [rsp]
00007d20d97ddbe3  add rsp, 0x30
00007d20d97ddbe7  vmovaps xmm0, [rsp]
00007d20d97ddbec  vmovaps xmm1, [rsp+0x10]
00007d20d97ddbf2  vmovaps xmm2, [rsp+0x20]
00007d20d97ddbf8  vmovaps xmm4, [rsp+0x30]
00007d20d97ddbfe  vmovaps xmm5, [rsp+0x40]
00007d20d97ddc04  vmovaps xmm6, [rsp+0x50]
00007d20d97ddc0a  vmovaps xmm7, [rsp+0x60]
00007d20d97ddc10  vmovaps xmm8, [rsp+0x70]
00007d20d97ddc16  vmovaps xmm9, [rsp+0x80]
00007d20d97ddc1f  vmovaps xmm10, [rsp+0x90]
00007d20d97ddc28  vmovaps xmm11, [rsp+0xA0]
00007d20d97ddc31  vmovaps xmm12, [rsp+0xB0]
00007d20d97ddc3a  vmovaps xmm13, [rsp+0xC0]
00007d20d97ddc43  vmovaps xmm14, [rsp+0xD0]
00007d20d97ddc4c  vmovaps xmm15, [rsp+0xE0]
00007d20d97ddc55  add rsp, 0xF0
00007d20d97ddc5c  pop r11
00007d20d97ddc5e  pop r10
00007d20d97ddc60  pop r9
00007d20d97ddc62  pop r8
00007d20d97ddc64  pop rsi
00007d20d97ddc65  pop rdi
00007d20d97ddc66  pop rdx
00007d20d97ddc67  pop rcx
00007d20d97ddc68  pop rax
00007d20d97ddc69  add rsp, 0x08
00007d20d97ddc6d  jmp 0x00007D20D97DBEF6
00007d20d97ddc72  sub rsp, 0x08
00007d20d97ddc76  push rax
00007d20d97ddc77  push rcx
00007d20d97ddc78  push rdx
00007d20d97ddc79  push rdi
00007d20d97ddc7a  push rsi
00007d20d97ddc7b  push r8
00007d20d97ddc7d  push r9
00007d20d97ddc7f  push r10
00007d20d97ddc81  push r11
00007d20d97ddc83  sub rsp, 0xF0
00007d20d97ddc8a  vmovaps [rsp], xmm0
00007d20d97ddc8f  vmovaps [rsp+0x10], xmm2
00007d20d97ddc95  vmovaps [rsp+0x20], xmm3
00007d20d97ddc9b  vmovaps [rsp+0x30], xmm4
00007d20d97ddca1  vmovaps [rsp+0x40], xmm5
00007d20d97ddca7  vmovaps [rsp+0x50], xmm6
00007d20d97ddcad  vmovaps [rsp+0x60], xmm7
00007d20d97ddcb3  vmovaps [rsp+0x70], xmm8
00007d20d97ddcb9  vmovaps [rsp+0x80], xmm9
00007d20d97ddcc2  vmovaps [rsp+0x90], xmm10
00007d20d97ddccb  vmovaps [rsp+0xA0], xmm11
00007d20d97ddcd4  vmovaps [rsp+0xB0], xmm12
00007d20d97ddcdd  vmovaps [rsp+0xC0], xmm13
00007d20d97ddce6  vmovaps [rsp+0xD0], xmm14
00007d20d97ddcef  vmovaps [rsp+0xE0], xmm15
00007d20d97ddcf8  sub rsp, 0x30
00007d20d97ddcfc  movaps [rsp], xmm1
00007d20d97ddd00  movaps [rsp+0x10], xmm15
00007d20d97ddd06  movaps [rsp+0x20], xmm9
00007d20d97ddd0c  lea rdi, [rsp]
00007d20d97ddd10  mov esi, 0x00
00007d20d97ddd15  mov rax, 0x5EFBF4CF6530
00007d20d97ddd1f  call rax
00007d20d97ddd21  movaps xmm1, [rsp]
00007d20d97ddd25  add rsp, 0x30
00007d20d97ddd29  vmovaps xmm0, [rsp]
00007d20d97ddd2e  vmovaps xmm2, [rsp+0x10]
00007d20d97ddd34  vmovaps xmm3, [rsp+0x20]
00007d20d97ddd3a  vmovaps xmm4, [rsp+0x30]
00007d20d97ddd40  vmovaps xmm5, [rsp+0x40]
00007d20d97ddd46  vmovaps xmm6, [rsp+0x50]
00007d20d97ddd4c  vmovaps xmm7, [rsp+0x60]
00007d20d97ddd52  vmovaps xmm8, [rsp+0x70]
00007d20d97ddd58  vmovaps xmm9, [rsp+0x80]
00007d20d97ddd61  vmovaps xmm10, [rsp+0x90]
00007d20d97ddd6a  vmovaps xmm11, [rsp+0xA0]
00007d20d97ddd73  vmovaps xmm12, [rsp+0xB0]
00007d20d97ddd7c  vmovaps xmm13, [rsp+0xC0]
00007d20d97ddd85  vmovaps xmm14, [rsp+0xD0]
00007d20d97ddd8e  vmovaps xmm15, [rsp+0xE0]
00007d20d97ddd97  add rsp, 0xF0
00007d20d97ddd9e  pop r11
00007d20d97ddda0  pop r10
00007d20d97ddda2  pop r9
00007d20d97ddda4  pop r8
00007d20d97ddda6  pop rsi
00007d20d97ddda7  pop rdi
00007d20d97ddda8  pop rdx
00007d20d97ddda9  pop rcx
00007d20d97dddaa  pop rax
00007d20d97dddab  add rsp, 0x08
00007d20d97dddaf  jmp 0x00007D20D97DBF7E
00007d20d97dddb4  call 0x00007D20D96C4620
00007d20d97dddb9  jmp 0x00007D20D97DBF8B
00007d20d97dddbe  sub rsp, 0x08
00007d20d97dddc2  push rax
00007d20d97dddc3  push rcx
00007d20d97dddc4  push rdx
00007d20d97dddc5  push rdi
00007d20d97dddc6  push rsi
00007d20d97dddc7  push r8
00007d20d97dddc9  push r9
00007d20d97dddcb  push r10
00007d20d97dddcd  push r11
00007d20d97dddcf  sub rsp, 0xF0
00007d20d97dddd6  vmovaps [rsp], xmm0
00007d20d97ddddb  vmovaps [rsp+0x10], xmm2
00007d20d97ddde1  vmovaps [rsp+0x20], xmm3
00007d20d97ddde7  vmovaps [rsp+0x30], xmm4
00007d20d97ddded  vmovaps [rsp+0x40], xmm5
00007d20d97dddf3  vmovaps [rsp+0x50], xmm6
00007d20d97dddf9  vmovaps [rsp+0x60], xmm7
00007d20d97dddff  vmovaps [rsp+0x70], xmm8
00007d20d97dde05  vmovaps [rsp+0x80], xmm9
00007d20d97dde0e  vmovaps [rsp+0x90], xmm10
00007d20d97dde17  vmovaps [rsp+0xA0], xmm11
00007d20d97dde20  vmovaps [rsp+0xB0], xmm12
00007d20d97dde29  vmovaps [rsp+0xC0], xmm13
00007d20d97dde32  vmovaps [rsp+0xD0], xmm14
00007d20d97dde3b  vmovaps [rsp+0xE0], xmm15
00007d20d97dde44  sub rsp, 0x30
00007d20d97dde48  movaps [rsp], xmm1
00007d20d97dde4c  movaps [rsp+0x10], xmm5
00007d20d97dde51  movaps [rsp+0x20], xmm7
00007d20d97dde56  lea rdi, [rsp]
00007d20d97dde5a  mov esi, 0x00
00007d20d97dde5f  mov rax, 0x5EFBF4CF6530
00007d20d97dde69  call rax
00007d20d97dde6b  movaps xmm1, [rsp]
00007d20d97dde6f  add rsp, 0x30
00007d20d97dde73  vmovaps xmm0, [rsp]
00007d20d97dde78  vmovaps xmm2, [rsp+0x10]
00007d20d97dde7e  vmovaps xmm3, [rsp+0x20]
00007d20d97dde84  vmovaps xmm4, [rsp+0x30]
00007d20d97dde8a  vmovaps xmm5, [rsp+0x40]
00007d20d97dde90  vmovaps xmm6, [rsp+0x50]
00007d20d97dde96  vmovaps xmm7, [rsp+0x60]
00007d20d97dde9c  vmovaps xmm8, [rsp+0x70]
00007d20d97ddea2  vmovaps xmm9, [rsp+0x80]
00007d20d97ddeab  vmovaps xmm10, [rsp+0x90]
00007d20d97ddeb4  vmovaps xmm11, [rsp+0xA0]
00007d20d97ddebd  vmovaps xmm12, [rsp+0xB0]
00007d20d97ddec6  vmovaps xmm13, [rsp+0xC0]
00007d20d97ddecf  vmovaps xmm14, [rsp+0xD0]
00007d20d97dded8  vmovaps xmm15, [rsp+0xE0]
00007d20d97ddee1  add rsp, 0xF0
00007d20d97ddee8  pop r11
00007d20d97ddeea  pop r10
00007d20d97ddeec  pop r9
00007d20d97ddeee  pop r8
00007d20d97ddef0  pop rsi
00007d20d97ddef1  pop rdi
00007d20d97ddef2  pop rdx
00007d20d97ddef3  pop rcx
00007d20d97ddef4  pop rax
00007d20d97ddef5  add rsp, 0x08
00007d20d97ddef9  jmp 0x00007D20D97DC030
00007d20d97ddefe  sub rsp, 0x08
00007d20d97ddf02  push rax
00007d20d97ddf03  push rcx
00007d20d97ddf04  push rdx
00007d20d97ddf05  push rdi
00007d20d97ddf06  push rsi
00007d20d97ddf07  push r8
00007d20d97ddf09  push r9
00007d20d97ddf0b  push r10
00007d20d97ddf0d  push r11
00007d20d97ddf0f  sub rsp, 0xF0
00007d20d97ddf16  vmovaps [rsp], xmm0
00007d20d97ddf1b  vmovaps [rsp+0x10], xmm1
00007d20d97ddf21  vmovaps [rsp+0x20], xmm2
00007d20d97ddf27  vmovaps [rsp+0x30], xmm3
00007d20d97ddf2d  vmovaps [rsp+0x40], xmm4
00007d20d97ddf33  vmovaps [rsp+0x50], xmm5
00007d20d97ddf39  vmovaps [rsp+0x60], xmm6
00007d20d97ddf3f  vmovaps [rsp+0x70], xmm8
00007d20d97ddf45  vmovaps [rsp+0x80], xmm9
00007d20d97ddf4e  vmovaps [rsp+0x90], xmm10
00007d20d97ddf57  vmovaps [rsp+0xA0], xmm11
00007d20d97ddf60  vmovaps [rsp+0xB0], xmm12
00007d20d97ddf69  vmovaps [rsp+0xC0], xmm13
00007d20d97ddf72  vmovaps [rsp+0xD0], xmm14
00007d20d97ddf7b  vmovaps [rsp+0xE0], xmm15
00007d20d97ddf84  sub rsp, 0x30
00007d20d97ddf88  movaps [rsp], xmm7
00007d20d97ddf8c  movaps [rsp+0x10], xmm5
00007d20d97ddf91  movaps [rsp+0x20], xmm15
00007d20d97ddf97  lea rdi, [rsp]
00007d20d97ddf9b  mov esi, 0x00
00007d20d97ddfa0  mov rax, 0x5EFBF4CF6530
00007d20d97ddfaa  call rax
00007d20d97ddfac  movaps xmm7, [rsp]
00007d20d97ddfb0  add rsp, 0x30
00007d20d97ddfb4  vmovaps xmm0, [rsp]
00007d20d97ddfb9  vmovaps xmm1, [rsp+0x10]
00007d20d97ddfbf  vmovaps xmm2, [rsp+0x20]
00007d20d97ddfc5  vmovaps xmm3, [rsp+0x30]
00007d20d97ddfcb  vmovaps xmm4, [rsp+0x40]
00007d20d97ddfd1  vmovaps xmm5, [rsp+0x50]
00007d20d97ddfd7  vmovaps xmm6, [rsp+0x60]
00007d20d97ddfdd  vmovaps xmm8, [rsp+0x70]
00007d20d97ddfe3  vmovaps xmm9, [rsp+0x80]
00007d20d97ddfec  vmovaps xmm10, [rsp+0x90]
00007d20d97ddff5  vmovaps xmm11, [rsp+0xA0]
00007d20d97ddffe  vmovaps xmm12, [rsp+0xB0]
00007d20d97de007  vmovaps xmm13, [rsp+0xC0]
00007d20d97de010  vmovaps xmm14, [rsp+0xD0]
00007d20d97de019  vmovaps xmm15, [rsp+0xE0]
00007d20d97de022  add rsp, 0xF0
00007d20d97de029  pop r11
00007d20d97de02b  pop r10
00007d20d97de02d  pop r9
00007d20d97de02f  pop r8
00007d20d97de031  pop rsi
00007d20d97de032  pop rdi
00007d20d97de033  pop rdx
00007d20d97de034  pop rcx
00007d20d97de035  pop rax
00007d20d97de036  add rsp, 0x08
00007d20d97de03a  jmp 0x00007D20D97DC066
00007d20d97de03f  call 0x00007D20D96B52F0
00007d20d97de044  jmp 0x00007D20D97DC073
00007d20d97de049  sub rsp, 0x08
00007d20d97de04d  push rax
00007d20d97de04e  push rcx
00007d20d97de04f  push rdx
00007d20d97de050  push rdi
00007d20d97de051  push rsi
00007d20d97de052  push r8
00007d20d97de054  push r9
00007d20d97de056  push r10
00007d20d97de058  push r11
00007d20d97de05a  sub rsp, 0xF0
00007d20d97de061  vmovaps [rsp], xmm0
00007d20d97de066  vmovaps [rsp+0x10], xmm1
00007d20d97de06c  vmovaps [rsp+0x20], xmm2
00007d20d97de072  vmovaps [rsp+0x30], xmm3
00007d20d97de078  vmovaps [rsp+0x40], xmm4
00007d20d97de07e  vmovaps [rsp+0x50], xmm5
00007d20d97de084  vmovaps [rsp+0x60], xmm6
00007d20d97de08a  vmovaps [rsp+0x70], xmm7
00007d20d97de090  vmovaps [rsp+0x80], xmm8
00007d20d97de099  vmovaps [rsp+0x90], xmm9
00007d20d97de0a2  vmovaps [rsp+0xA0], xmm10
00007d20d97de0ab  vmovaps [rsp+0xB0], xmm11
00007d20d97de0b4  vmovaps [rsp+0xC0], xmm12
00007d20d97de0bd  vmovaps [rsp+0xD0], xmm13
00007d20d97de0c6  vmovaps [rsp+0xE0], xmm14
00007d20d97de0cf  sub rsp, 0x30
00007d20d97de0d3  movaps [rsp], xmm15
00007d20d97de0d8  movaps [rsp+0x10], xmm5
00007d20d97de0dd  movaps [rsp+0x20], xmm3
00007d20d97de0e2  lea rdi, [rsp]
00007d20d97de0e6  mov esi, 0x00
00007d20d97de0eb  mov rax, 0x5EFBF4CF6530
00007d20d97de0f5  call rax
00007d20d97de0f7  movaps xmm15, [rsp]
00007d20d97de0fc  add rsp, 0x30
00007d20d97de100  vmovaps xmm0, [rsp]
00007d20d97de105  vmovaps xmm1, [rsp+0x10]
00007d20d97de10b  vmovaps xmm2, [rsp+0x20]
00007d20d97de111  vmovaps xmm3, [rsp+0x30]
00007d20d97de117  vmovaps xmm4, [rsp+0x40]
00007d20d97de11d  vmovaps xmm5, [rsp+0x50]
00007d20d97de123  vmovaps xmm6, [rsp+0x60]
00007d20d97de129  vmovaps xmm7, [rsp+0x70]
00007d20d97de12f  vmovaps xmm8, [rsp+0x80]
00007d20d97de138  vmovaps xmm9, [rsp+0x90]
00007d20d97de141  vmovaps xmm10, [rsp+0xA0]
00007d20d97de14a  vmovaps xmm11, [rsp+0xB0]
00007d20d97de153  vmovaps xmm12, [rsp+0xC0]
00007d20d97de15c  vmovaps xmm13, [rsp+0xD0]
00007d20d97de165  vmovaps xmm14, [rsp+0xE0]
00007d20d97de16e  add rsp, 0xF0
00007d20d97de175  pop r11
00007d20d97de177  pop r10
00007d20d97de179  pop r9
00007d20d97de17b  pop r8
00007d20d97de17d  pop rsi
00007d20d97de17e  pop rdi
00007d20d97de17f  pop rdx
00007d20d97de180  pop rcx
00007d20d97de181  pop rax
00007d20d97de182  add rsp, 0x08
00007d20d97de186  jmp 0x00007D20D97DC099
00007d20d97de18b  sub rsp, 0x08
00007d20d97de18f  push rax
00007d20d97de190  push rcx
00007d20d97de191  push rdx
00007d20d97de192  push rdi
00007d20d97de193  push rsi
00007d20d97de194  push r8
00007d20d97de196  push r9
00007d20d97de198  push r10
00007d20d97de19a  push r11
00007d20d97de19c  sub rsp, 0xF0
00007d20d97de1a3  vmovaps [rsp], xmm0
00007d20d97de1a8  vmovaps [rsp+0x10], xmm2
00007d20d97de1ae  vmovaps [rsp+0x20], xmm3
00007d20d97de1b4  vmovaps [rsp+0x30], xmm4
00007d20d97de1ba  vmovaps [rsp+0x40], xmm5
00007d20d97de1c0  vmovaps [rsp+0x50], xmm6
00007d20d97de1c6  vmovaps [rsp+0x60], xmm7
00007d20d97de1cc  vmovaps [rsp+0x70], xmm8
00007d20d97de1d2  vmovaps [rsp+0x80], xmm9
00007d20d97de1db  vmovaps [rsp+0x90], xmm10
00007d20d97de1e4  vmovaps [rsp+0xA0], xmm11
00007d20d97de1ed  vmovaps [rsp+0xB0], xmm12
00007d20d97de1f6  vmovaps [rsp+0xC0], xmm13
00007d20d97de1ff  vmovaps [rsp+0xD0], xmm14
00007d20d97de208  vmovaps [rsp+0xE0], xmm15
00007d20d97de211  sub rsp, 0x30
00007d20d97de215  movaps [rsp], xmm1
00007d20d97de219  movaps [rsp+0x10], xmm5
00007d20d97de21e  movaps [rsp+0x20], xmm4
00007d20d97de223  lea rdi, [rsp]
00007d20d97de227  mov esi, 0x00
00007d20d97de22c  mov rax, 0x5EFBF4CF6530
00007d20d97de236  call rax
00007d20d97de238  movaps xmm1, [rsp]
00007d20d97de23c  add rsp, 0x30
00007d20d97de240  vmovaps xmm0, [rsp]
00007d20d97de245  vmovaps xmm2, [rsp+0x10]
00007d20d97de24b  vmovaps xmm3, [rsp+0x20]
00007d20d97de251  vmovaps xmm4, [rsp+0x30]
00007d20d97de257  vmovaps xmm5, [rsp+0x40]
00007d20d97de25d  vmovaps xmm6, [rsp+0x50]
00007d20d97de263  vmovaps xmm7, [rsp+0x60]
00007d20d97de269  vmovaps xmm8, [rsp+0x70]
00007d20d97de26f  vmovaps xmm9, [rsp+0x80]
00007d20d97de278  vmovaps xmm10, [rsp+0x90]
00007d20d97de281  vmovaps xmm11, [rsp+0xA0]
00007d20d97de28a  vmovaps xmm12, [rsp+0xB0]
00007d20d97de293  vmovaps xmm13, [rsp+0xC0]
00007d20d97de29c  vmovaps xmm14, [rsp+0xD0]
00007d20d97de2a5  vmovaps xmm15, [rsp+0xE0]
00007d20d97de2ae  add rsp, 0xF0
00007d20d97de2b5  pop r11
00007d20d97de2b7  pop r10
00007d20d97de2b9  pop r9
00007d20d97de2bb  pop r8
00007d20d97de2bd  pop rsi
00007d20d97de2be  pop rdi
00007d20d97de2bf  pop rdx
00007d20d97de2c0  pop rcx
00007d20d97de2c1  pop rax
00007d20d97de2c2  add rsp, 0x08
00007d20d97de2c6  jmp 0x00007D20D97DC0B9
00007d20d97de2cb  sub rsp, 0x08
00007d20d97de2cf  push rax
00007d20d97de2d0  push rcx
00007d20d97de2d1  push rdx
00007d20d97de2d2  push rdi
00007d20d97de2d3  push rsi
00007d20d97de2d4  push r8
00007d20d97de2d6  push r9
00007d20d97de2d8  push r10
00007d20d97de2da  push r11
00007d20d97de2dc  sub rsp, 0xF0
00007d20d97de2e3  vmovaps [rsp], xmm0
00007d20d97de2e8  vmovaps [rsp+0x10], xmm1
00007d20d97de2ee  vmovaps [rsp+0x20], xmm2
00007d20d97de2f4  vmovaps [rsp+0x30], xmm3
00007d20d97de2fa  vmovaps [rsp+0x40], xmm5
00007d20d97de300  vmovaps [rsp+0x50], xmm6
00007d20d97de306  vmovaps [rsp+0x60], xmm7
00007d20d97de30c  vmovaps [rsp+0x70], xmm8
00007d20d97de312  vmovaps [rsp+0x80], xmm9
00007d20d97de31b  vmovaps [rsp+0x90], xmm10
00007d20d97de324  vmovaps [rsp+0xA0], xmm11
00007d20d97de32d  vmovaps [rsp+0xB0], xmm12
00007d20d97de336  vmovaps [rsp+0xC0], xmm13
00007d20d97de33f  vmovaps [rsp+0xD0], xmm14
00007d20d97de348  vmovaps [rsp+0xE0], xmm15
00007d20d97de351  sub rsp, 0x30
00007d20d97de355  movaps [rsp], xmm4
00007d20d97de359  movaps [rsp+0x10], xmm3
00007d20d97de35e  movaps [rsp+0x20], xmm5
00007d20d97de363  lea rdi, [rsp]
00007d20d97de367  mov esi, 0x00
00007d20d97de36c  mov rax, 0x5EFBF4CF6530
00007d20d97de376  call rax
00007d20d97de378  movaps xmm4, [rsp]
00007d20d97de37c  add rsp, 0x30
00007d20d97de380  vmovaps xmm0, [rsp]
00007d20d97de385  vmovaps xmm1, [rsp+0x10]
00007d20d97de38b  vmovaps xmm2, [rsp+0x20]
00007d20d97de391  vmovaps xmm3, [rsp+0x30]
00007d20d97de397  vmovaps xmm5, [rsp+0x40]
00007d20d97de39d  vmovaps xmm6, [rsp+0x50]
00007d20d97de3a3  vmovaps xmm7, [rsp+0x60]
00007d20d97de3a9  vmovaps xmm8, [rsp+0x70]
00007d20d97de3af  vmovaps xmm9, [rsp+0x80]
00007d20d97de3b8  vmovaps xmm10, [rsp+0x90]
00007d20d97de3c1  vmovaps xmm11, [rsp+0xA0]
00007d20d97de3ca  vmovaps xmm12, [rsp+0xB0]
00007d20d97de3d3  vmovaps xmm13, [rsp+0xC0]
00007d20d97de3dc  vmovaps xmm14, [rsp+0xD0]
00007d20d97de3e5  vmovaps xmm15, [rsp+0xE0]
00007d20d97de3ee  add rsp, 0xF0
00007d20d97de3f5  pop r11
00007d20d97de3f7  pop r10
00007d20d97de3f9  pop r9
00007d20d97de3fb  pop r8
00007d20d97de3fd  pop rsi
00007d20d97de3fe  pop rdi
00007d20d97de3ff  pop rdx
00007d20d97de400  pop rcx
00007d20d97de401  pop rax
00007d20d97de402  add rsp, 0x08
00007d20d97de406  jmp 0x00007D20D97DC107
00007d20d97de40b  call 0x00007D20D96B52F0
00007d20d97de410  jmp 0x00007D20D97DC114
00007d20d97de415  sub rsp, 0x08
00007d20d97de419  push rax
00007d20d97de41a  push rcx
00007d20d97de41b  push rdx
00007d20d97de41c  push rdi
00007d20d97de41d  push rsi
00007d20d97de41e  push r8
00007d20d97de420  push r9
00007d20d97de422  push r10
00007d20d97de424  push r11
00007d20d97de426  sub rsp, 0xF0
00007d20d97de42d  vmovaps [rsp], xmm0
00007d20d97de432  vmovaps [rsp+0x10], xmm1
00007d20d97de438  vmovaps [rsp+0x20], xmm2
00007d20d97de43e  vmovaps [rsp+0x30], xmm3
00007d20d97de444  vmovaps [rsp+0x40], xmm4
00007d20d97de44a  vmovaps [rsp+0x50], xmm6
00007d20d97de450  vmovaps [rsp+0x60], xmm7
00007d20d97de456  vmovaps [rsp+0x70], xmm8
00007d20d97de45c  vmovaps [rsp+0x80], xmm9
00007d20d97de465  vmovaps [rsp+0x90], xmm10
00007d20d97de46e  vmovaps [rsp+0xA0], xmm11
00007d20d97de477  vmovaps [rsp+0xB0], xmm12
00007d20d97de480  vmovaps [rsp+0xC0], xmm13
00007d20d97de489  vmovaps [rsp+0xD0], xmm14
00007d20d97de492  vmovaps [rsp+0xE0], xmm15
00007d20d97de49b  sub rsp, 0x30
00007d20d97de49f  movaps [rsp], xmm5
00007d20d97de4a3  movaps [rsp+0x10], xmm6
00007d20d97de4a8  movaps [rsp+0x20], xmm3
00007d20d97de4ad  lea rdi, [rsp]
00007d20d97de4b1  mov esi, 0x00
00007d20d97de4b6  mov rax, 0x5EFBF4CF6530
00007d20d97de4c0  call rax
00007d20d97de4c2  movaps xmm5, [rsp]
00007d20d97de4c6  add rsp, 0x30
00007d20d97de4ca  vmovaps xmm0, [rsp]
00007d20d97de4cf  vmovaps xmm1, [rsp+0x10]
00007d20d97de4d5  vmovaps xmm2, [rsp+0x20]
00007d20d97de4db  vmovaps xmm3, [rsp+0x30]
00007d20d97de4e1  vmovaps xmm4, [rsp+0x40]
00007d20d97de4e7  vmovaps xmm6, [rsp+0x50]
00007d20d97de4ed  vmovaps xmm7, [rsp+0x60]
00007d20d97de4f3  vmovaps xmm8, [rsp+0x70]
00007d20d97de4f9  vmovaps xmm9, [rsp+0x80]
00007d20d97de502  vmovaps xmm10, [rsp+0x90]
00007d20d97de50b  vmovaps xmm11, [rsp+0xA0]
00007d20d97de514  vmovaps xmm12, [rsp+0xB0]
00007d20d97de51d  vmovaps xmm13, [rsp+0xC0]
00007d20d97de526  vmovaps xmm14, [rsp+0xD0]
00007d20d97de52f  vmovaps xmm15, [rsp+0xE0]
00007d20d97de538  add rsp, 0xF0
00007d20d97de53f  pop r11
00007d20d97de541  pop r10
00007d20d97de543  pop r9
00007d20d97de545  pop r8
00007d20d97de547  pop rsi
00007d20d97de548  pop rdi
00007d20d97de549  pop rdx
00007d20d97de54a  pop rcx
00007d20d97de54b  pop rax
00007d20d97de54c  add rsp, 0x08
00007d20d97de550  jmp 0x00007D20D97DC13A
00007d20d97de555  sub rsp, 0x08
00007d20d97de559  push rax
00007d20d97de55a  push rcx
00007d20d97de55b  push rdx
00007d20d97de55c  push rdi
00007d20d97de55d  push rsi
00007d20d97de55e  push r8
00007d20d97de560  push r9
00007d20d97de562  push r10
00007d20d97de564  push r11
00007d20d97de566  sub rsp, 0xF0
00007d20d97de56d  vmovaps [rsp], xmm0
00007d20d97de572  vmovaps [rsp+0x10], xmm1
00007d20d97de578  vmovaps [rsp+0x20], xmm2
00007d20d97de57e  vmovaps [rsp+0x30], xmm3
00007d20d97de584  vmovaps [rsp+0x40], xmm4
00007d20d97de58a  vmovaps [rsp+0x50], xmm5
00007d20d97de590  vmovaps [rsp+0x60], xmm7
00007d20d97de596  vmovaps [rsp+0x70], xmm8
00007d20d97de59c  vmovaps [rsp+0x80], xmm9
00007d20d97de5a5  vmovaps [rsp+0x90], xmm10
00007d20d97de5ae  vmovaps [rsp+0xA0], xmm11
00007d20d97de5b7  vmovaps [rsp+0xB0], xmm12
00007d20d97de5c0  vmovaps [rsp+0xC0], xmm13
00007d20d97de5c9  vmovaps [rsp+0xD0], xmm14
00007d20d97de5d2  vmovaps [rsp+0xE0], xmm15
00007d20d97de5db  sub rsp, 0x30
00007d20d97de5df  movaps [rsp], xmm6
00007d20d97de5e3  movaps [rsp+0x10], xmm9
00007d20d97de5e9  movaps [rsp+0x20], xmm1
00007d20d97de5ee  lea rdi, [rsp]
00007d20d97de5f2  mov esi, 0x00
00007d20d97de5f7  mov rax, 0x5EFBF4CF6530
00007d20d97de601  call rax
00007d20d97de603  movaps xmm6, [rsp]
00007d20d97de607  add rsp, 0x30
00007d20d97de60b  vmovaps xmm0, [rsp]
00007d20d97de610  vmovaps xmm1, [rsp+0x10]
00007d20d97de616  vmovaps xmm2, [rsp+0x20]
00007d20d97de61c  vmovaps xmm3, [rsp+0x30]
00007d20d97de622  vmovaps xmm4, [rsp+0x40]
00007d20d97de628  vmovaps xmm5, [rsp+0x50]
00007d20d97de62e  vmovaps xmm7, [rsp+0x60]
00007d20d97de634  vmovaps xmm8, [rsp+0x70]
00007d20d97de63a  vmovaps xmm9, [rsp+0x80]
00007d20d97de643  vmovaps xmm10, [rsp+0x90]
00007d20d97de64c  vmovaps xmm11, [rsp+0xA0]
00007d20d97de655  vmovaps xmm12, [rsp+0xB0]
00007d20d97de65e  vmovaps xmm13, [rsp+0xC0]
00007d20d97de667  vmovaps xmm14, [rsp+0xD0]
00007d20d97de670  vmovaps xmm15, [rsp+0xE0]
00007d20d97de679  add rsp, 0xF0
00007d20d97de680  pop r11
00007d20d97de682  pop r10
00007d20d97de684  pop r9
00007d20d97de686  pop r8
00007d20d97de688  pop rsi
00007d20d97de689  pop rdi
00007d20d97de68a  pop rdx
00007d20d97de68b  pop rcx
00007d20d97de68c  pop rax
00007d20d97de68d  add rsp, 0x08
00007d20d97de691  jmp 0x00007D20D97DC15E
00007d20d97de696  sub rsp, 0x08
00007d20d97de69a  push rax
00007d20d97de69b  push rcx
00007d20d97de69c  push rdx
00007d20d97de69d  push rdi
00007d20d97de69e  push rsi
00007d20d97de69f  push r8
00007d20d97de6a1  push r9
00007d20d97de6a3  push r10
00007d20d97de6a5  push r11
00007d20d97de6a7  sub rsp, 0xF0
00007d20d97de6ae  vmovaps [rsp], xmm0
00007d20d97de6b3  vmovaps [rsp+0x10], xmm1
00007d20d97de6b9  vmovaps [rsp+0x20], xmm2
00007d20d97de6bf  vmovaps [rsp+0x30], xmm3
00007d20d97de6c5  vmovaps [rsp+0x40], xmm4
00007d20d97de6cb  vmovaps [rsp+0x50], xmm5
00007d20d97de6d1  vmovaps [rsp+0x60], xmm6
00007d20d97de6d7  vmovaps [rsp+0x70], xmm7
00007d20d97de6dd  vmovaps [rsp+0x80], xmm8
00007d20d97de6e6  vmovaps [rsp+0x90], xmm10
00007d20d97de6ef  vmovaps [rsp+0xA0], xmm11
00007d20d97de6f8  vmovaps [rsp+0xB0], xmm12
00007d20d97de701  vmovaps [rsp+0xC0], xmm13
00007d20d97de70a  vmovaps [rsp+0xD0], xmm14
00007d20d97de713  vmovaps [rsp+0xE0], xmm15
00007d20d97de71c  sub rsp, 0x30
00007d20d97de720  movaps [rsp], xmm9
00007d20d97de725  movaps [rsp+0x10], xmm3
00007d20d97de72a  movaps [rsp+0x20], xmm1
00007d20d97de72f  lea rdi, [rsp]
00007d20d97de733  mov esi, 0x00
00007d20d97de738  mov rax, 0x5EFBF4CF6530
00007d20d97de742  call rax
00007d20d97de744  movaps xmm9, [rsp]
00007d20d97de749  add rsp, 0x30
00007d20d97de74d  vmovaps xmm0, [rsp]
00007d20d97de752  vmovaps xmm1, [rsp+0x10]
00007d20d97de758  vmovaps xmm2, [rsp+0x20]
00007d20d97de75e  vmovaps xmm3, [rsp+0x30]
00007d20d97de764  vmovaps xmm4, [rsp+0x40]
00007d20d97de76a  vmovaps xmm5, [rsp+0x50]
00007d20d97de770  vmovaps xmm6, [rsp+0x60]
00007d20d97de776  vmovaps xmm7, [rsp+0x70]
00007d20d97de77c  vmovaps xmm8, [rsp+0x80]
00007d20d97de785  vmovaps xmm10, [rsp+0x90]
00007d20d97de78e  vmovaps xmm11, [rsp+0xA0]
00007d20d97de797  vmovaps xmm12, [rsp+0xB0]
00007d20d97de7a0  vmovaps xmm13, [rsp+0xC0]
00007d20d97de7a9  vmovaps xmm14, [rsp+0xD0]
00007d20d97de7b2  vmovaps xmm15, [rsp+0xE0]
00007d20d97de7bb  add rsp, 0xF0
00007d20d97de7c2  pop r11
00007d20d97de7c4  pop r10
00007d20d97de7c6  pop r9
00007d20d97de7c8  pop r8
00007d20d97de7ca  pop rsi
00007d20d97de7cb  pop rdi
00007d20d97de7cc  pop rdx
00007d20d97de7cd  pop rcx
00007d20d97de7ce  pop rax
00007d20d97de7cf  add rsp, 0x08
00007d20d97de7d3  jmp 0x00007D20D97DC1AA
00007d20d97de7d8  call 0x00007D20D96B52F0
00007d20d97de7dd  jmp 0x00007D20D97DC1B7
00007d20d97de7e2  sub rsp, 0x08
00007d20d97de7e6  push rax
00007d20d97de7e7  push rcx
00007d20d97de7e8  push rdx
00007d20d97de7e9  push rdi
00007d20d97de7ea  push rsi
00007d20d97de7eb  push r8
00007d20d97de7ed  push r9
00007d20d97de7ef  push r10
00007d20d97de7f1  push r11
00007d20d97de7f3  sub rsp, 0xF0
00007d20d97de7fa  vmovaps [rsp], xmm0
00007d20d97de7ff  vmovaps [rsp+0x10], xmm1
00007d20d97de805  vmovaps [rsp+0x20], xmm2
00007d20d97de80b  vmovaps [rsp+0x30], xmm3
00007d20d97de811  vmovaps [rsp+0x40], xmm4
00007d20d97de817  vmovaps [rsp+0x50], xmm5
00007d20d97de81d  vmovaps [rsp+0x60], xmm6
00007d20d97de823  vmovaps [rsp+0x70], xmm7
00007d20d97de829  vmovaps [rsp+0x80], xmm8
00007d20d97de832  vmovaps [rsp+0x90], xmm9
00007d20d97de83b  vmovaps [rsp+0xA0], xmm10
00007d20d97de844  vmovaps [rsp+0xB0], xmm11
00007d20d97de84d  vmovaps [rsp+0xC0], xmm12
00007d20d97de856  vmovaps [rsp+0xD0], xmm13
00007d20d97de85f  vmovaps [rsp+0xE0], xmm14
00007d20d97de868  sub rsp, 0x30
00007d20d97de86c  movaps [rsp], xmm15
00007d20d97de871  movaps [rsp+0x10], xmm3
00007d20d97de876  movaps [rsp+0x20], xmm7
00007d20d97de87b  lea rdi, [rsp]
00007d20d97de87f  mov esi, 0x00
00007d20d97de884  mov rax, 0x5EFBF4CF6530
00007d20d97de88e  call rax
00007d20d97de890  movaps xmm15, [rsp]
00007d20d97de895  add rsp, 0x30
00007d20d97de899  vmovaps xmm0, [rsp]
00007d20d97de89e  vmovaps xmm1, [rsp+0x10]
00007d20d97de8a4  vmovaps xmm2, [rsp+0x20]
00007d20d97de8aa  vmovaps xmm3, [rsp+0x30]
00007d20d97de8b0  vmovaps xmm4, [rsp+0x40]
00007d20d97de8b6  vmovaps xmm5, [rsp+0x50]
00007d20d97de8bc  vmovaps xmm6, [rsp+0x60]
00007d20d97de8c2  vmovaps xmm7, [rsp+0x70]
00007d20d97de8c8  vmovaps xmm8, [rsp+0x80]
00007d20d97de8d1  vmovaps xmm9, [rsp+0x90]
00007d20d97de8da  vmovaps xmm10, [rsp+0xA0]
00007d20d97de8e3  vmovaps xmm11, [rsp+0xB0]
00007d20d97de8ec  vmovaps xmm12, [rsp+0xC0]
00007d20d97de8f5  vmovaps xmm13, [rsp+0xD0]
00007d20d97de8fe  vmovaps xmm14, [rsp+0xE0]
00007d20d97de907  add rsp, 0xF0
00007d20d97de90e  pop r11
00007d20d97de910  pop r10
00007d20d97de912  pop r9
00007d20d97de914  pop r8
00007d20d97de916  pop rsi
00007d20d97de917  pop rdi
00007d20d97de918  pop rdx
00007d20d97de919  pop rcx
00007d20d97de91a  pop rax
00007d20d97de91b  add rsp, 0x08
00007d20d97de91f  jmp 0x00007D20D97DC1E3
00007d20d97de924  sub rsp, 0x08
00007d20d97de928  push rax
00007d20d97de929  push rcx
00007d20d97de92a  push rdx
00007d20d97de92b  push rdi
00007d20d97de92c  push rsi
00007d20d97de92d  push r8
00007d20d97de92f  push r9
00007d20d97de931  push r10
00007d20d97de933  push r11
00007d20d97de935  sub rsp, 0xF0
00007d20d97de93c  vmovaps [rsp], xmm0
00007d20d97de941  vmovaps [rsp+0x10], xmm1
00007d20d97de947  vmovaps [rsp+0x20], xmm2
00007d20d97de94d  vmovaps [rsp+0x30], xmm4
00007d20d97de953  vmovaps [rsp+0x40], xmm5
00007d20d97de959  vmovaps [rsp+0x50], xmm6
00007d20d97de95f  vmovaps [rsp+0x60], xmm7
00007d20d97de965  vmovaps [rsp+0x70], xmm8
00007d20d97de96b  vmovaps [rsp+0x80], xmm9
00007d20d97de974  vmovaps [rsp+0x90], xmm10
00007d20d97de97d  vmovaps [rsp+0xA0], xmm11
00007d20d97de986  vmovaps [rsp+0xB0], xmm12
00007d20d97de98f  vmovaps [rsp+0xC0], xmm13
00007d20d97de998  vmovaps [rsp+0xD0], xmm14
00007d20d97de9a1  vmovaps [rsp+0xE0], xmm15
00007d20d97de9aa  sub rsp, 0x30
00007d20d97de9ae  movaps [rsp], xmm3
00007d20d97de9b2  movaps [rsp+0x10], xmm1
00007d20d97de9b7  movaps [rsp+0x20], xmm15
00007d20d97de9bd  lea rdi, [rsp]
00007d20d97de9c1  mov esi, 0x00
00007d20d97de9c6  mov rax, 0x5EFBF4CF6530
00007d20d97de9d0  call rax
00007d20d97de9d2  movaps xmm3, [rsp]
00007d20d97de9d6  add rsp, 0x30
00007d20d97de9da  vmovaps xmm0, [rsp]
00007d20d97de9df  vmovaps xmm1, [rsp+0x10]
00007d20d97de9e5  vmovaps xmm2, [rsp+0x20]
00007d20d97de9eb  vmovaps xmm4, [rsp+0x30]
00007d20d97de9f1  vmovaps xmm5, [rsp+0x40]
00007d20d97de9f7  vmovaps xmm6, [rsp+0x50]
00007d20d97de9fd  vmovaps xmm7, [rsp+0x60]
00007d20d97dea03  vmovaps xmm8, [rsp+0x70]
00007d20d97dea09  vmovaps xmm9, [rsp+0x80]
00007d20d97dea12  vmovaps xmm10, [rsp+0x90]
00007d20d97dea1b  vmovaps xmm11, [rsp+0xA0]
00007d20d97dea24  vmovaps xmm12, [rsp+0xB0]
00007d20d97dea2d  vmovaps xmm13, [rsp+0xC0]
00007d20d97dea36  vmovaps xmm14, [rsp+0xD0]
00007d20d97dea3f  vmovaps xmm15, [rsp+0xE0]
00007d20d97dea48  add rsp, 0xF0
00007d20d97dea4f  pop r11
00007d20d97dea51  pop r10
00007d20d97dea53  pop r9
00007d20d97dea55  pop r8
00007d20d97dea57  pop rsi
00007d20d97dea58  pop rdi
00007d20d97dea59  pop rdx
00007d20d97dea5a  pop rcx
00007d20d97dea5b  pop rax
00007d20d97dea5c  add rsp, 0x08
00007d20d97dea60  jmp 0x00007D20D97DC272
00007d20d97dea65  call 0x00007D20D96B52F0
00007d20d97dea6a  jmp 0x00007D20D97DC27C
00007d20d97dea6f  sub rsp, 0x08
00007d20d97dea73  push rax
00007d20d97dea74  push rcx
00007d20d97dea75  push rdx
00007d20d97dea76  push rdi
00007d20d97dea77  push rsi
00007d20d97dea78  push r8
00007d20d97dea7a  push r9
00007d20d97dea7c  push r10
00007d20d97dea7e  push r11
00007d20d97dea80  sub rsp, 0xF0
00007d20d97dea87  vmovaps [rsp], xmm0
00007d20d97dea8c  vmovaps [rsp+0x10], xmm1
00007d20d97dea92  vmovaps [rsp+0x20], xmm2
00007d20d97dea98  vmovaps [rsp+0x30], xmm3
00007d20d97dea9e  vmovaps [rsp+0x40], xmm4
00007d20d97deaa4  vmovaps [rsp+0x50], xmm5
00007d20d97deaaa  vmovaps [rsp+0x60], xmm6
00007d20d97deab0  vmovaps [rsp+0x70], xmm7
00007d20d97deab6  vmovaps [rsp+0x80], xmm8
00007d20d97deabf  vmovaps [rsp+0x90], xmm9
00007d20d97deac8  vmovaps [rsp+0xA0], xmm10
00007d20d97dead1  vmovaps [rsp+0xB0], xmm11
00007d20d97deada  vmovaps [rsp+0xC0], xmm12
00007d20d97deae3  vmovaps [rsp+0xD0], xmm13
00007d20d97deaec  vmovaps [rsp+0xE0], xmm14
00007d20d97deaf5  sub rsp, 0x30
00007d20d97deaf9  movaps [rsp], xmm15
00007d20d97deafe  movaps [rsp+0x10], xmm14
00007d20d97deb04  movaps [rsp+0x20], xmm4
00007d20d97deb09  lea rdi, [rsp]
00007d20d97deb0d  mov esi, 0x00
00007d20d97deb12  mov rax, 0x5EFBF4CF6530
00007d20d97deb1c  call rax
00007d20d97deb1e  movaps xmm15, [rsp]
00007d20d97deb23  add rsp, 0x30
00007d20d97deb27  vmovaps xmm0, [rsp]
00007d20d97deb2c  vmovaps xmm1, [rsp+0x10]
00007d20d97deb32  vmovaps xmm2, [rsp+0x20]
00007d20d97deb38  vmovaps xmm3, [rsp+0x30]
00007d20d97deb3e  vmovaps xmm4, [rsp+0x40]
00007d20d97deb44  vmovaps xmm5, [rsp+0x50]
00007d20d97deb4a  vmovaps xmm6, [rsp+0x60]
00007d20d97deb50  vmovaps xmm7, [rsp+0x70]
00007d20d97deb56  vmovaps xmm8, [rsp+0x80]
00007d20d97deb5f  vmovaps xmm9, [rsp+0x90]
00007d20d97deb68  vmovaps xmm10, [rsp+0xA0]
00007d20d97deb71  vmovaps xmm11, [rsp+0xB0]
00007d20d97deb7a  vmovaps xmm12, [rsp+0xC0]
00007d20d97deb83  vmovaps xmm13, [rsp+0xD0]
00007d20d97deb8c  vmovaps xmm14, [rsp+0xE0]
00007d20d97deb95  add rsp, 0xF0
00007d20d97deb9c  pop r11
00007d20d97deb9e  pop r10
00007d20d97deba0  pop r9
00007d20d97deba2  pop r8
00007d20d97deba4  pop rsi
00007d20d97deba5  pop rdi
00007d20d97deba6  pop rdx
00007d20d97deba7  pop rcx
00007d20d97deba8  pop rax
00007d20d97deba9  add rsp, 0x08
00007d20d97debad  jmp 0x00007D20D97DC2AA
00007d20d97debb2  sub rsp, 0x08
00007d20d97debb6  push rax
00007d20d97debb7  push rcx
00007d20d97debb8  push rdx
00007d20d97debb9  push rdi
00007d20d97debba  push rsi
00007d20d97debbb  push r8
00007d20d97debbd  push r9
00007d20d97debbf  push r10
00007d20d97debc1  push r11
00007d20d97debc3  sub rsp, 0xF0
00007d20d97debca  vmovaps [rsp], xmm0
00007d20d97debcf  vmovaps [rsp+0x10], xmm1
00007d20d97debd5  vmovaps [rsp+0x20], xmm2
00007d20d97debdb  vmovaps [rsp+0x30], xmm3
00007d20d97debe1  vmovaps [rsp+0x40], xmm4
00007d20d97debe7  vmovaps [rsp+0x50], xmm5
00007d20d97debed  vmovaps [rsp+0x60], xmm6
00007d20d97debf3  vmovaps [rsp+0x70], xmm7
00007d20d97debf9  vmovaps [rsp+0x80], xmm8
00007d20d97dec02  vmovaps [rsp+0x90], xmm9
00007d20d97dec0b  vmovaps [rsp+0xA0], xmm10
00007d20d97dec14  vmovaps [rsp+0xB0], xmm11
00007d20d97dec1d  vmovaps [rsp+0xC0], xmm12
00007d20d97dec26  vmovaps [rsp+0xD0], xmm13
00007d20d97dec2f  vmovaps [rsp+0xE0], xmm15
00007d20d97dec38  sub rsp, 0x30
00007d20d97dec3c  movaps [rsp], xmm14
00007d20d97dec41  movaps [rsp+0x10], xmm2
00007d20d97dec46  movaps [rsp+0x20], xmm1
00007d20d97dec4b  lea rdi, [rsp]
00007d20d97dec4f  mov esi, 0x00
00007d20d97dec54  mov rax, 0x5EFBF4CF6530
00007d20d97dec5e  call rax
00007d20d97dec60  movaps xmm14, [rsp]
00007d20d97dec65  add rsp, 0x30
00007d20d97dec69  vmovaps xmm0, [rsp]
00007d20d97dec6e  vmovaps xmm1, [rsp+0x10]
00007d20d97dec74  vmovaps xmm2, [rsp+0x20]
00007d20d97dec7a  vmovaps xmm3, [rsp+0x30]
00007d20d97dec80  vmovaps xmm4, [rsp+0x40]
00007d20d97dec86  vmovaps xmm5, [rsp+0x50]
00007d20d97dec8c  vmovaps xmm6, [rsp+0x60]
00007d20d97dec92  vmovaps xmm7, [rsp+0x70]
00007d20d97dec98  vmovaps xmm8, [rsp+0x80]
00007d20d97deca1  vmovaps xmm9, [rsp+0x90]
00007d20d97decaa  vmovaps xmm10, [rsp+0xA0]
00007d20d97decb3  vmovaps xmm11, [rsp+0xB0]
00007d20d97decbc  vmovaps xmm12, [rsp+0xC0]
00007d20d97decc5  vmovaps xmm13, [rsp+0xD0]
00007d20d97decce  vmovaps xmm15, [rsp+0xE0]
00007d20d97decd7  add rsp, 0xF0
00007d20d97decde  pop r11
00007d20d97dece0  pop r10
00007d20d97dece2  pop r9
00007d20d97dece4  pop r8
00007d20d97dece6  pop rsi
00007d20d97dece7  pop rdi
00007d20d97dece8  pop rdx
00007d20d97dece9  pop rcx
00007d20d97decea  pop rax
00007d20d97deceb  add rsp, 0x08
00007d20d97decef  jmp 0x00007D20D97DC2D0
00007d20d97decf4  sub rsp, 0x08
00007d20d97decf8  push rax
00007d20d97decf9  push rcx
00007d20d97decfa  push rdx
00007d20d97decfb  push rdi
00007d20d97decfc  push rsi
00007d20d97decfd  push r8
00007d20d97decff  push r9
00007d20d97ded01  push r10
00007d20d97ded03  push r11
00007d20d97ded05  sub rsp, 0xF0
00007d20d97ded0c  vmovaps [rsp], xmm0
00007d20d97ded11  vmovaps [rsp+0x10], xmm2
00007d20d97ded17  vmovaps [rsp+0x20], xmm3
00007d20d97ded1d  vmovaps [rsp+0x30], xmm4
00007d20d97ded23  vmovaps [rsp+0x40], xmm5
00007d20d97ded29  vmovaps [rsp+0x50], xmm6
00007d20d97ded2f  vmovaps [rsp+0x60], xmm7
00007d20d97ded35  vmovaps [rsp+0x70], xmm8
00007d20d97ded3b  vmovaps [rsp+0x80], xmm9
00007d20d97ded44  vmovaps [rsp+0x90], xmm10
00007d20d97ded4d  vmovaps [rsp+0xA0], xmm11
00007d20d97ded56  vmovaps [rsp+0xB0], xmm12
00007d20d97ded5f  vmovaps [rsp+0xC0], xmm13
00007d20d97ded68  vmovaps [rsp+0xD0], xmm14
00007d20d97ded71  vmovaps [rsp+0xE0], xmm15
00007d20d97ded7a  sub rsp, 0x30
00007d20d97ded7e  movaps [rsp], xmm1
00007d20d97ded82  movaps [rsp+0x10], xmm4
00007d20d97ded87  movaps [rsp+0x20], xmm9
00007d20d97ded8d  lea rdi, [rsp]
00007d20d97ded91  mov esi, 0x00
00007d20d97ded96  mov rax, 0x5EFBF4CF6530
00007d20d97deda0  call rax
00007d20d97deda2  movaps xmm1, [rsp]
00007d20d97deda6  add rsp, 0x30
00007d20d97dedaa  vmovaps xmm0, [rsp]
00007d20d97dedaf  vmovaps xmm2, [rsp+0x10]
00007d20d97dedb5  vmovaps xmm3, [rsp+0x20]
00007d20d97dedbb  vmovaps xmm4, [rsp+0x30]
00007d20d97dedc1  vmovaps xmm5, [rsp+0x40]
00007d20d97dedc7  vmovaps xmm6, [rsp+0x50]
00007d20d97dedcd  vmovaps xmm7, [rsp+0x60]
00007d20d97dedd3  vmovaps xmm8, [rsp+0x70]
00007d20d97dedd9  vmovaps xmm9, [rsp+0x80]
00007d20d97dede2  vmovaps xmm10, [rsp+0x90]
00007d20d97dedeb  vmovaps xmm11, [rsp+0xA0]
00007d20d97dedf4  vmovaps xmm12, [rsp+0xB0]
00007d20d97dedfd  vmovaps xmm13, [rsp+0xC0]
00007d20d97dee06  vmovaps xmm14, [rsp+0xD0]
00007d20d97dee0f  vmovaps xmm15, [rsp+0xE0]
00007d20d97dee18  add rsp, 0xF0
00007d20d97dee1f  pop r11
00007d20d97dee21  pop r10
00007d20d97dee23  pop r9
00007d20d97dee25  pop r8
00007d20d97dee27  pop rsi
00007d20d97dee28  pop rdi
00007d20d97dee29  pop rdx
00007d20d97dee2a  pop rcx
00007d20d97dee2b  pop rax
00007d20d97dee2c  add rsp, 0x08
00007d20d97dee30  jmp 0x00007D20D97DC2EE
00007d20d97dee35  sub rsp, 0x08
00007d20d97dee39  push rax
00007d20d97dee3a  push rcx
00007d20d97dee3b  push rdx
00007d20d97dee3c  push rdi
00007d20d97dee3d  push rsi
00007d20d97dee3e  push r8
00007d20d97dee40  push r9
00007d20d97dee42  push r10
00007d20d97dee44  push r11
00007d20d97dee46  sub rsp, 0xF0
00007d20d97dee4d  vmovaps [rsp], xmm0
00007d20d97dee52  vmovaps [rsp+0x10], xmm1
00007d20d97dee58  vmovaps [rsp+0x20], xmm2
00007d20d97dee5e  vmovaps [rsp+0x30], xmm3
00007d20d97dee64  vmovaps [rsp+0x40], xmm5
00007d20d97dee6a  vmovaps [rsp+0x50], xmm6
00007d20d97dee70  vmovaps [rsp+0x60], xmm7
00007d20d97dee76  vmovaps [rsp+0x70], xmm8
00007d20d97dee7c  vmovaps [rsp+0x80], xmm9
00007d20d97dee85  vmovaps [rsp+0x90], xmm10
00007d20d97dee8e  vmovaps [rsp+0xA0], xmm11
00007d20d97dee97  vmovaps [rsp+0xB0], xmm12
00007d20d97deea0  vmovaps [rsp+0xC0], xmm13
00007d20d97deea9  vmovaps [rsp+0xD0], xmm14
00007d20d97deeb2  vmovaps [rsp+0xE0], xmm15
00007d20d97deebb  sub rsp, 0x30
00007d20d97deebf  movaps [rsp], xmm4
00007d20d97deec3  movaps [rsp+0x10], xmm2
00007d20d97deec8  movaps [rsp+0x20], xmm9
00007d20d97deece  lea rdi, [rsp]
00007d20d97deed2  mov esi, 0x00
00007d20d97deed7  mov rax, 0x5EFBF4CF6530
00007d20d97deee1  call rax
00007d20d97deee3  movaps xmm4, [rsp]
00007d20d97deee7  add rsp, 0x30
00007d20d97deeeb  vmovaps xmm0, [rsp]
00007d20d97deef0  vmovaps xmm1, [rsp+0x10]
00007d20d97deef6  vmovaps xmm2, [rsp+0x20]
00007d20d97deefc  vmovaps xmm3, [rsp+0x30]
00007d20d97def02  vmovaps xmm5, [rsp+0x40]
00007d20d97def08  vmovaps xmm6, [rsp+0x50]
00007d20d97def0e  vmovaps xmm7, [rsp+0x60]
00007d20d97def14  vmovaps xmm8, [rsp+0x70]
00007d20d97def1a  vmovaps xmm9, [rsp+0x80]
00007d20d97def23  vmovaps xmm10, [rsp+0x90]
00007d20d97def2c  vmovaps xmm11, [rsp+0xA0]
00007d20d97def35  vmovaps xmm12, [rsp+0xB0]
00007d20d97def3e  vmovaps xmm13, [rsp+0xC0]
00007d20d97def47  vmovaps xmm14, [rsp+0xD0]
00007d20d97def50  vmovaps xmm15, [rsp+0xE0]
00007d20d97def59  add rsp, 0xF0
00007d20d97def60  pop r11
00007d20d97def62  pop r10
00007d20d97def64  pop r9
00007d20d97def66  pop r8
00007d20d97def68  pop rsi
00007d20d97def69  pop rdi
00007d20d97def6a  pop rdx
00007d20d97def6b  pop rcx
00007d20d97def6c  pop rax
00007d20d97def6d  add rsp, 0x08
00007d20d97def71  jmp 0x00007D20D97DC31E
00007d20d97def76  sub rsp, 0x08
00007d20d97def7a  push rax
00007d20d97def7b  push rcx
00007d20d97def7c  push rdx
00007d20d97def7d  push rdi
00007d20d97def7e  push rsi
00007d20d97def7f  push r8
00007d20d97def81  push r9
00007d20d97def83  push r10
00007d20d97def85  push r11
00007d20d97def87  sub rsp, 0xF0
00007d20d97def8e  vmovaps [rsp], xmm0
00007d20d97def93  vmovaps [rsp+0x10], xmm1
00007d20d97def99  vmovaps [rsp+0x20], xmm2
00007d20d97def9f  vmovaps [rsp+0x30], xmm3
00007d20d97defa5  vmovaps [rsp+0x40], xmm4
00007d20d97defab  vmovaps [rsp+0x50], xmm5
00007d20d97defb1  vmovaps [rsp+0x60], xmm6
00007d20d97defb7  vmovaps [rsp+0x70], xmm7
00007d20d97defbd  vmovaps [rsp+0x80], xmm8
00007d20d97defc6  vmovaps [rsp+0x90], xmm10
00007d20d97defcf  vmovaps [rsp+0xA0], xmm11
00007d20d97defd8  vmovaps [rsp+0xB0], xmm12
00007d20d97defe1  vmovaps [rsp+0xC0], xmm13
00007d20d97defea  vmovaps [rsp+0xD0], xmm14
00007d20d97deff3  vmovaps [rsp+0xE0], xmm15
00007d20d97deffc  sub rsp, 0x30
00007d20d97df000  movaps [rsp], xmm9
00007d20d97df005  movaps [rsp+0x10], xmm2
00007d20d97df00a  movaps [rsp+0x20], xmm1
00007d20d97df00f  lea rdi, [rsp]
00007d20d97df013  mov esi, 0x00
00007d20d97df018  mov rax, 0x5EFBF4CF6530
00007d20d97df022  call rax
00007d20d97df024  movaps xmm9, [rsp]
00007d20d97df029  add rsp, 0x30
00007d20d97df02d  vmovaps xmm0, [rsp]
00007d20d97df032  vmovaps xmm1, [rsp+0x10]
00007d20d97df038  vmovaps xmm2, [rsp+0x20]
00007d20d97df03e  vmovaps xmm3, [rsp+0x30]
00007d20d97df044  vmovaps xmm4, [rsp+0x40]
00007d20d97df04a  vmovaps xmm5, [rsp+0x50]
00007d20d97df050  vmovaps xmm6, [rsp+0x60]
00007d20d97df056  vmovaps xmm7, [rsp+0x70]
00007d20d97df05c  vmovaps xmm8, [rsp+0x80]
00007d20d97df065  vmovaps xmm10, [rsp+0x90]
00007d20d97df06e  vmovaps xmm11, [rsp+0xA0]
00007d20d97df077  vmovaps xmm12, [rsp+0xB0]
00007d20d97df080  vmovaps xmm13, [rsp+0xC0]
00007d20d97df089  vmovaps xmm14, [rsp+0xD0]
00007d20d97df092  vmovaps xmm15, [rsp+0xE0]
00007d20d97df09b  add rsp, 0xF0
00007d20d97df0a2  pop r11
00007d20d97df0a4  pop r10
00007d20d97df0a6  pop r9
00007d20d97df0a8  pop r8
00007d20d97df0aa  pop rsi
00007d20d97df0ab  pop rdi
00007d20d97df0ac  pop rdx
00007d20d97df0ad  pop rcx
00007d20d97df0ae  pop rax
00007d20d97df0af  add rsp, 0x08
00007d20d97df0b3  jmp 0x00007D20D97DC354
00007d20d97df0b8  sub rsp, 0x08
00007d20d97df0bc  push rax
00007d20d97df0bd  push rcx
00007d20d97df0be  push rdx
00007d20d97df0bf  push rdi
00007d20d97df0c0  push rsi
00007d20d97df0c1  push r8
00007d20d97df0c3  push r9
00007d20d97df0c5  push r10
00007d20d97df0c7  push r11
00007d20d97df0c9  sub rsp, 0xF0
00007d20d97df0d0  vmovaps [rsp], xmm0
00007d20d97df0d5  vmovaps [rsp+0x10], xmm2
00007d20d97df0db  vmovaps [rsp+0x20], xmm3
00007d20d97df0e1  vmovaps [rsp+0x30], xmm4
00007d20d97df0e7  vmovaps [rsp+0x40], xmm5
00007d20d97df0ed  vmovaps [rsp+0x50], xmm6
00007d20d97df0f3  vmovaps [rsp+0x60], xmm7
00007d20d97df0f9  vmovaps [rsp+0x70], xmm8
00007d20d97df0ff  vmovaps [rsp+0x80], xmm9
00007d20d97df108  vmovaps [rsp+0x90], xmm10
00007d20d97df111  vmovaps [rsp+0xA0], xmm11
00007d20d97df11a  vmovaps [rsp+0xB0], xmm12
00007d20d97df123  vmovaps [rsp+0xC0], xmm13
00007d20d97df12c  vmovaps [rsp+0xD0], xmm14
00007d20d97df135  vmovaps [rsp+0xE0], xmm15
00007d20d97df13e  sub rsp, 0x30
00007d20d97df142  movaps [rsp], xmm1
00007d20d97df146  movaps [rsp+0x10], xmm15
00007d20d97df14c  movaps [rsp+0x20], xmm6
00007d20d97df151  lea rdi, [rsp]
00007d20d97df155  mov esi, 0x00
00007d20d97df15a  mov rax, 0x5EFBF4CF6530
00007d20d97df164  call rax
00007d20d97df166  movaps xmm1, [rsp]
00007d20d97df16a  add rsp, 0x30
00007d20d97df16e  vmovaps xmm0, [rsp]
00007d20d97df173  vmovaps xmm2, [rsp+0x10]
00007d20d97df179  vmovaps xmm3, [rsp+0x20]
00007d20d97df17f  vmovaps xmm4, [rsp+0x30]
00007d20d97df185  vmovaps xmm5, [rsp+0x40]
00007d20d97df18b  vmovaps xmm6, [rsp+0x50]
00007d20d97df191  vmovaps xmm7, [rsp+0x60]
00007d20d97df197  vmovaps xmm8, [rsp+0x70]
00007d20d97df19d  vmovaps xmm9, [rsp+0x80]
00007d20d97df1a6  vmovaps xmm10, [rsp+0x90]
00007d20d97df1af  vmovaps xmm11, [rsp+0xA0]
00007d20d97df1b8  vmovaps xmm12, [rsp+0xB0]
00007d20d97df1c1  vmovaps xmm13, [rsp+0xC0]
00007d20d97df1ca  vmovaps xmm14, [rsp+0xD0]
00007d20d97df1d3  vmovaps xmm15, [rsp+0xE0]
00007d20d97df1dc  add rsp, 0xF0
00007d20d97df1e3  pop r11
00007d20d97df1e5  pop r10
00007d20d97df1e7  pop r9
00007d20d97df1e9  pop r8
00007d20d97df1eb  pop rsi
00007d20d97df1ec  pop rdi
00007d20d97df1ed  pop rdx
00007d20d97df1ee  pop rcx
00007d20d97df1ef  pop rax
00007d20d97df1f0  add rsp, 0x08
00007d20d97df1f4  jmp 0x00007D20D97DC375
00007d20d97df1f9  sub rsp, 0x08
00007d20d97df1fd  push rax
00007d20d97df1fe  push rcx
00007d20d97df1ff  push rdx
00007d20d97df200  push rdi
00007d20d97df201  push rsi
00007d20d97df202  push r8
00007d20d97df204  push r9
00007d20d97df206  push r10
00007d20d97df208  push r11
00007d20d97df20a  sub rsp, 0xF0
00007d20d97df211  vmovaps [rsp], xmm0
00007d20d97df216  vmovaps [rsp+0x10], xmm1
00007d20d97df21c  vmovaps [rsp+0x20], xmm2
00007d20d97df222  vmovaps [rsp+0x30], xmm3
00007d20d97df228  vmovaps [rsp+0x40], xmm4
00007d20d97df22e  vmovaps [rsp+0x50], xmm5
00007d20d97df234  vmovaps [rsp+0x60], xmm6
00007d20d97df23a  vmovaps [rsp+0x70], xmm7
00007d20d97df240  vmovaps [rsp+0x80], xmm8
00007d20d97df249  vmovaps [rsp+0x90], xmm9
00007d20d97df252  vmovaps [rsp+0xA0], xmm10
00007d20d97df25b  vmovaps [rsp+0xB0], xmm11
00007d20d97df264  vmovaps [rsp+0xC0], xmm12
00007d20d97df26d  vmovaps [rsp+0xD0], xmm13
00007d20d97df276  vmovaps [rsp+0xE0], xmm14
00007d20d97df27f  sub rsp, 0x30
00007d20d97df283  movaps [rsp], xmm15
00007d20d97df288  movaps [rsp+0x10], xmm5
00007d20d97df28d  movaps [rsp+0x20], xmm3
00007d20d97df292  lea rdi, [rsp]
00007d20d97df296  mov esi, 0x00
00007d20d97df29b  mov rax, 0x5EFBF4CF6530
00007d20d97df2a5  call rax
00007d20d97df2a7  movaps xmm15, [rsp]
00007d20d97df2ac  add rsp, 0x30
00007d20d97df2b0  vmovaps xmm0, [rsp]
00007d20d97df2b5  vmovaps xmm1, [rsp+0x10]
00007d20d97df2bb  vmovaps xmm2, [rsp+0x20]
00007d20d97df2c1  vmovaps xmm3, [rsp+0x30]
00007d20d97df2c7  vmovaps xmm4, [rsp+0x40]
00007d20d97df2cd  vmovaps xmm5, [rsp+0x50]
00007d20d97df2d3  vmovaps xmm6, [rsp+0x60]
00007d20d97df2d9  vmovaps xmm7, [rsp+0x70]
00007d20d97df2df  vmovaps xmm8, [rsp+0x80]
00007d20d97df2e8  vmovaps xmm9, [rsp+0x90]
00007d20d97df2f1  vmovaps xmm10, [rsp+0xA0]
00007d20d97df2fa  vmovaps xmm11, [rsp+0xB0]
00007d20d97df303  vmovaps xmm12, [rsp+0xC0]
00007d20d97df30c  vmovaps xmm13, [rsp+0xD0]
00007d20d97df315  vmovaps xmm14, [rsp+0xE0]
00007d20d97df31e  add rsp, 0xF0
00007d20d97df325  pop r11
00007d20d97df327  pop r10
00007d20d97df329  pop r9
00007d20d97df32b  pop r8
00007d20d97df32d  pop rsi
00007d20d97df32e  pop rdi
00007d20d97df32f  pop rdx
00007d20d97df330  pop rcx
00007d20d97df331  pop rax
00007d20d97df332  add rsp, 0x08
00007d20d97df336  jmp 0x00007D20D97DC38F
00007d20d97df33b  sub rsp, 0x08
00007d20d97df33f  push rax
00007d20d97df340  push rcx
00007d20d97df341  push rdx
00007d20d97df342  push rdi
00007d20d97df343  push rsi
00007d20d97df344  push r8
00007d20d97df346  push r9
00007d20d97df348  push r10
00007d20d97df34a  push r11
00007d20d97df34c  sub rsp, 0xF0
00007d20d97df353  vmovaps [rsp], xmm0
00007d20d97df358  vmovaps [rsp+0x10], xmm1
00007d20d97df35e  vmovaps [rsp+0x20], xmm2
00007d20d97df364  vmovaps [rsp+0x30], xmm3
00007d20d97df36a  vmovaps [rsp+0x40], xmm4
00007d20d97df370  vmovaps [rsp+0x50], xmm6
00007d20d97df376  vmovaps [rsp+0x60], xmm7
00007d20d97df37c  vmovaps [rsp+0x70], xmm8
00007d20d97df382  vmovaps [rsp+0x80], xmm9
00007d20d97df38b  vmovaps [rsp+0x90], xmm10
00007d20d97df394  vmovaps [rsp+0xA0], xmm11
00007d20d97df39d  vmovaps [rsp+0xB0], xmm12
00007d20d97df3a6  vmovaps [rsp+0xC0], xmm13
00007d20d97df3af  vmovaps [rsp+0xD0], xmm14
00007d20d97df3b8  vmovaps [rsp+0xE0], xmm15
00007d20d97df3c1  sub rsp, 0x30
00007d20d97df3c5  movaps [rsp], xmm5
00007d20d97df3c9  movaps [rsp+0x10], xmm8
00007d20d97df3cf  movaps [rsp+0x20], xmm6
00007d20d97df3d4  lea rdi, [rsp]
00007d20d97df3d8  mov esi, 0x00
00007d20d97df3dd  mov rax, 0x5EFBF4CF6530
00007d20d97df3e7  call rax
00007d20d97df3e9  movaps xmm5, [rsp]
00007d20d97df3ed  add rsp, 0x30
00007d20d97df3f1  vmovaps xmm0, [rsp]
00007d20d97df3f6  vmovaps xmm1, [rsp+0x10]
00007d20d97df3fc  vmovaps xmm2, [rsp+0x20]
00007d20d97df402  vmovaps xmm3, [rsp+0x30]
00007d20d97df408  vmovaps xmm4, [rsp+0x40]
00007d20d97df40e  vmovaps xmm6, [rsp+0x50]
00007d20d97df414  vmovaps xmm7, [rsp+0x60]
00007d20d97df41a  vmovaps xmm8, [rsp+0x70]
00007d20d97df420  vmovaps xmm9, [rsp+0x80]
00007d20d97df429  vmovaps xmm10, [rsp+0x90]
00007d20d97df432  vmovaps xmm11, [rsp+0xA0]
00007d20d97df43b  vmovaps xmm12, [rsp+0xB0]
00007d20d97df444  vmovaps xmm13, [rsp+0xC0]
00007d20d97df44d  vmovaps xmm14, [rsp+0xD0]
00007d20d97df456  vmovaps xmm15, [rsp+0xE0]
00007d20d97df45f  add rsp, 0xF0
00007d20d97df466  pop r11
00007d20d97df468  pop r10
00007d20d97df46a  pop r9
00007d20d97df46c  pop r8
00007d20d97df46e  pop rsi
00007d20d97df46f  pop rdi
00007d20d97df470  pop rdx
00007d20d97df471  pop rcx
00007d20d97df472  pop rax
00007d20d97df473  add rsp, 0x08
00007d20d97df477  jmp 0x00007D20D97DC3B3
00007d20d97df47c  sub rsp, 0x08
00007d20d97df480  push rax
00007d20d97df481  push rcx
00007d20d97df482  push rdx
00007d20d97df483  push rdi
00007d20d97df484  push rsi
00007d20d97df485  push r8
00007d20d97df487  push r9
00007d20d97df489  push r10
00007d20d97df48b  push r11
00007d20d97df48d  sub rsp, 0xF0
00007d20d97df494  vmovaps [rsp], xmm0
00007d20d97df499  vmovaps [rsp+0x10], xmm1
00007d20d97df49f  vmovaps [rsp+0x20], xmm2
00007d20d97df4a5  vmovaps [rsp+0x30], xmm3
00007d20d97df4ab  vmovaps [rsp+0x40], xmm4
00007d20d97df4b1  vmovaps [rsp+0x50], xmm5
00007d20d97df4b7  vmovaps [rsp+0x60], xmm7
00007d20d97df4bd  vmovaps [rsp+0x70], xmm8
00007d20d97df4c3  vmovaps [rsp+0x80], xmm9
00007d20d97df4cc  vmovaps [rsp+0x90], xmm10
00007d20d97df4d5  vmovaps [rsp+0xA0], xmm11
00007d20d97df4de  vmovaps [rsp+0xB0], xmm12
00007d20d97df4e7  vmovaps [rsp+0xC0], xmm13
00007d20d97df4f0  vmovaps [rsp+0xD0], xmm14
00007d20d97df4f9  vmovaps [rsp+0xE0], xmm15
00007d20d97df502  sub rsp, 0x30
00007d20d97df506  movaps [rsp], xmm6
00007d20d97df50a  movaps [rsp+0x10], xmm10
00007d20d97df510  movaps [rsp+0x20], xmm8
00007d20d97df516  lea rdi, [rsp]
00007d20d97df51a  mov esi, 0x00
00007d20d97df51f  mov rax, 0x5EFBF4CF6530
00007d20d97df529  call rax
00007d20d97df52b  movaps xmm6, [rsp]
00007d20d97df52f  add rsp, 0x30
00007d20d97df533  vmovaps xmm0, [rsp]
00007d20d97df538  vmovaps xmm1, [rsp+0x10]
00007d20d97df53e  vmovaps xmm2, [rsp+0x20]
00007d20d97df544  vmovaps xmm3, [rsp+0x30]
00007d20d97df54a  vmovaps xmm4, [rsp+0x40]
00007d20d97df550  vmovaps xmm5, [rsp+0x50]
00007d20d97df556  vmovaps xmm7, [rsp+0x60]
00007d20d97df55c  vmovaps xmm8, [rsp+0x70]
00007d20d97df562  vmovaps xmm9, [rsp+0x80]
00007d20d97df56b  vmovaps xmm10, [rsp+0x90]
00007d20d97df574  vmovaps xmm11, [rsp+0xA0]
00007d20d97df57d  vmovaps xmm12, [rsp+0xB0]
00007d20d97df586  vmovaps xmm13, [rsp+0xC0]
00007d20d97df58f  vmovaps xmm14, [rsp+0xD0]
00007d20d97df598  vmovaps xmm15, [rsp+0xE0]
00007d20d97df5a1  add rsp, 0xF0
00007d20d97df5a8  pop r11
00007d20d97df5aa  pop r10
00007d20d97df5ac  pop r9
00007d20d97df5ae  pop r8
00007d20d97df5b0  pop rsi
00007d20d97df5b1  pop rdi
00007d20d97df5b2  pop rdx
00007d20d97df5b3  pop rcx
00007d20d97df5b4  pop rax
00007d20d97df5b5  add rsp, 0x08
00007d20d97df5b9  jmp 0x00007D20D97DC3D8
00007d20d97df5be  sub rsp, 0x08
00007d20d97df5c2  push rax
00007d20d97df5c3  push rcx
00007d20d97df5c4  push rdx
00007d20d97df5c5  push rdi
00007d20d97df5c6  push rsi
00007d20d97df5c7  push r8
00007d20d97df5c9  push r9
00007d20d97df5cb  push r10
00007d20d97df5cd  push r11
00007d20d97df5cf  sub rsp, 0xF0
00007d20d97df5d6  vmovaps [rsp], xmm0
00007d20d97df5db  vmovaps [rsp+0x10], xmm1
00007d20d97df5e1  vmovaps [rsp+0x20], xmm2
00007d20d97df5e7  vmovaps [rsp+0x30], xmm3
00007d20d97df5ed  vmovaps [rsp+0x40], xmm4
00007d20d97df5f3  vmovaps [rsp+0x50], xmm5
00007d20d97df5f9  vmovaps [rsp+0x60], xmm6
00007d20d97df5ff  vmovaps [rsp+0x70], xmm7
00007d20d97df605  vmovaps [rsp+0x80], xmm8
00007d20d97df60e  vmovaps [rsp+0x90], xmm9
00007d20d97df617  vmovaps [rsp+0xA0], xmm11
00007d20d97df620  vmovaps [rsp+0xB0], xmm12
00007d20d97df629  vmovaps [rsp+0xC0], xmm13
00007d20d97df632  vmovaps [rsp+0xD0], xmm14
00007d20d97df63b  vmovaps [rsp+0xE0], xmm15
00007d20d97df644  sub rsp, 0x30
00007d20d97df648  movaps [rsp], xmm10
00007d20d97df64d  movaps [rsp+0x10], xmm8
00007d20d97df653  movaps [rsp+0x20], xmm14
00007d20d97df659  lea rdi, [rsp]
00007d20d97df65d  mov esi, 0x00
00007d20d97df662  mov rax, 0x5EFBF4CF6530
00007d20d97df66c  call rax
00007d20d97df66e  movaps xmm10, [rsp]
00007d20d97df673  add rsp, 0x30
00007d20d97df677  vmovaps xmm0, [rsp]
00007d20d97df67c  vmovaps xmm1, [rsp+0x10]
00007d20d97df682  vmovaps xmm2, [rsp+0x20]
00007d20d97df688  vmovaps xmm3, [rsp+0x30]
00007d20d97df68e  vmovaps xmm4, [rsp+0x40]
00007d20d97df694  vmovaps xmm5, [rsp+0x50]
00007d20d97df69a  vmovaps xmm6, [rsp+0x60]
00007d20d97df6a0  vmovaps xmm7, [rsp+0x70]
00007d20d97df6a6  vmovaps xmm8, [rsp+0x80]
00007d20d97df6af  vmovaps xmm9, [rsp+0x90]
00007d20d97df6b8  vmovaps xmm11, [rsp+0xA0]
00007d20d97df6c1  vmovaps xmm12, [rsp+0xB0]
00007d20d97df6ca  vmovaps xmm13, [rsp+0xC0]
00007d20d97df6d3  vmovaps xmm14, [rsp+0xD0]
00007d20d97df6dc  vmovaps xmm15, [rsp+0xE0]
00007d20d97df6e5  add rsp, 0xF0
00007d20d97df6ec  pop r11
00007d20d97df6ee  pop r10
00007d20d97df6f0  pop r9
00007d20d97df6f2  pop r8
00007d20d97df6f4  pop rsi
00007d20d97df6f5  pop rdi
00007d20d97df6f6  pop rdx
00007d20d97df6f7  pop rcx
00007d20d97df6f8  pop rax
00007d20d97df6f9  add rsp, 0x08
00007d20d97df6fd  jmp 0x00007D20D97DC3F8
00007d20d97df702  sub rsp, 0x08
00007d20d97df706  push rax
00007d20d97df707  push rcx
00007d20d97df708  push rdx
00007d20d97df709  push rdi
00007d20d97df70a  push rsi
00007d20d97df70b  push r8
00007d20d97df70d  push r9
00007d20d97df70f  push r10
00007d20d97df711  push r11
00007d20d97df713  sub rsp, 0xF0
00007d20d97df71a  vmovaps [rsp], xmm0
00007d20d97df71f  vmovaps [rsp+0x10], xmm1
00007d20d97df725  vmovaps [rsp+0x20], xmm2
00007d20d97df72b  vmovaps [rsp+0x30], xmm3
00007d20d97df731  vmovaps [rsp+0x40], xmm4
00007d20d97df737  vmovaps [rsp+0x50], xmm5
00007d20d97df73d  vmovaps [rsp+0x60], xmm6
00007d20d97df743  vmovaps [rsp+0x70], xmm7
00007d20d97df749  vmovaps [rsp+0x80], xmm8
00007d20d97df752  vmovaps [rsp+0x90], xmm9
00007d20d97df75b  vmovaps [rsp+0xA0], xmm10
00007d20d97df764  vmovaps [rsp+0xB0], xmm11
00007d20d97df76d  vmovaps [rsp+0xC0], xmm12
00007d20d97df776  vmovaps [rsp+0xD0], xmm13
00007d20d97df77f  vmovaps [rsp+0xE0], xmm15
00007d20d97df788  sub rsp, 0x30
00007d20d97df78c  movaps [rsp], xmm14
00007d20d97df791  movaps [rsp+0x10], xmm8
00007d20d97df797  movaps [rsp+0x20], xmm4
00007d20d97df79c  lea rdi, [rsp]
00007d20d97df7a0  mov esi, 0x00
00007d20d97df7a5  mov rax, 0x5EFBF4CF6530
00007d20d97df7af  call rax
00007d20d97df7b1  movaps xmm14, [rsp]
00007d20d97df7b6  add rsp, 0x30
00007d20d97df7ba  vmovaps xmm0, [rsp]
00007d20d97df7bf  vmovaps xmm1, [rsp+0x10]
00007d20d97df7c5  vmovaps xmm2, [rsp+0x20]
00007d20d97df7cb  vmovaps xmm3, [rsp+0x30]
00007d20d97df7d1  vmovaps xmm4, [rsp+0x40]
00007d20d97df7d7  vmovaps xmm5, [rsp+0x50]
00007d20d97df7dd  vmovaps xmm6, [rsp+0x60]
00007d20d97df7e3  vmovaps xmm7, [rsp+0x70]
00007d20d97df7e9  vmovaps xmm8, [rsp+0x80]
00007d20d97df7f2  vmovaps xmm9, [rsp+0x90]
00007d20d97df7fb  vmovaps xmm10, [rsp+0xA0]
00007d20d97df804  vmovaps xmm11, [rsp+0xB0]
00007d20d97df80d  vmovaps xmm12, [rsp+0xC0]
00007d20d97df816  vmovaps xmm13, [rsp+0xD0]
00007d20d97df81f  vmovaps xmm15, [rsp+0xE0]
00007d20d97df828  add rsp, 0xF0
00007d20d97df82f  pop r11
00007d20d97df831  pop r10
00007d20d97df833  pop r9
00007d20d97df835  pop r8
00007d20d97df837  pop rsi
00007d20d97df838  pop rdi
00007d20d97df839  pop rdx
00007d20d97df83a  pop rcx
00007d20d97df83b  pop rax
00007d20d97df83c  add rsp, 0x08
00007d20d97df840  jmp 0x00007D20D97DC418
00007d20d97df845  sub rsp, 0x08
00007d20d97df849  push rax
00007d20d97df84a  push rcx
00007d20d97df84b  push rdx
00007d20d97df84c  push rdi
00007d20d97df84d  push rsi
00007d20d97df84e  push r8
00007d20d97df850  push r9
00007d20d97df852  push r10
00007d20d97df854  push r11
00007d20d97df856  sub rsp, 0xF0
00007d20d97df85d  vmovaps [rsp], xmm0
00007d20d97df862  vmovaps [rsp+0x10], xmm1
00007d20d97df868  vmovaps [rsp+0x20], xmm2
00007d20d97df86e  vmovaps [rsp+0x30], xmm3
00007d20d97df874  vmovaps [rsp+0x40], xmm5
00007d20d97df87a  vmovaps [rsp+0x50], xmm6
00007d20d97df880  vmovaps [rsp+0x60], xmm7
00007d20d97df886  vmovaps [rsp+0x70], xmm8
00007d20d97df88c  vmovaps [rsp+0x80], xmm9
00007d20d97df895  vmovaps [rsp+0x90], xmm10
00007d20d97df89e  vmovaps [rsp+0xA0], xmm11
00007d20d97df8a7  vmovaps [rsp+0xB0], xmm12
00007d20d97df8b0  vmovaps [rsp+0xC0], xmm13
00007d20d97df8b9  vmovaps [rsp+0xD0], xmm14
00007d20d97df8c2  vmovaps [rsp+0xE0], xmm15
00007d20d97df8cb  sub rsp, 0x30
00007d20d97df8cf  movaps [rsp], xmm4
00007d20d97df8d3  movaps [rsp+0x10], xmm13
00007d20d97df8d9  movaps [rsp+0x20], xmm8
00007d20d97df8df  lea rdi, [rsp]
00007d20d97df8e3  mov esi, 0x00
00007d20d97df8e8  mov rax, 0x5EFBF4CF6530
00007d20d97df8f2  call rax
00007d20d97df8f4  movaps xmm4, [rsp]
00007d20d97df8f8  add rsp, 0x30
00007d20d97df8fc  vmovaps xmm0, [rsp]
00007d20d97df901  vmovaps xmm1, [rsp+0x10]
00007d20d97df907  vmovaps xmm2, [rsp+0x20]
00007d20d97df90d  vmovaps xmm3, [rsp+0x30]
00007d20d97df913  vmovaps xmm5, [rsp+0x40]
00007d20d97df919  vmovaps xmm6, [rsp+0x50]
00007d20d97df91f  vmovaps xmm7, [rsp+0x60]
00007d20d97df925  vmovaps xmm8, [rsp+0x70]
00007d20d97df92b  vmovaps xmm9, [rsp+0x80]
00007d20d97df934  vmovaps xmm10, [rsp+0x90]
00007d20d97df93d  vmovaps xmm11, [rsp+0xA0]
00007d20d97df946  vmovaps xmm12, [rsp+0xB0]
00007d20d97df94f  vmovaps xmm13, [rsp+0xC0]
00007d20d97df958  vmovaps xmm14, [rsp+0xD0]
00007d20d97df961  vmovaps xmm15, [rsp+0xE0]
00007d20d97df96a  add rsp, 0xF0
00007d20d97df971  pop r11
00007d20d97df973  pop r10
00007d20d97df975  pop r9
00007d20d97df977  pop r8
00007d20d97df979  pop rsi
00007d20d97df97a  pop rdi
00007d20d97df97b  pop rdx
00007d20d97df97c  pop rcx
00007d20d97df97d  pop rax
00007d20d97df97e  add rsp, 0x08
00007d20d97df982  jmp 0x00007D20D97DC43D
00007d20d97df987  sub rsp, 0x08
00007d20d97df98b  push rax
00007d20d97df98c  push rcx
00007d20d97df98d  push rdx
00007d20d97df98e  push rdi
00007d20d97df98f  push rsi
00007d20d97df990  push r8
00007d20d97df992  push r9
00007d20d97df994  push r10
00007d20d97df996  push r11
00007d20d97df998  sub rsp, 0xF0
00007d20d97df99f  vmovaps [rsp], xmm0
00007d20d97df9a4  vmovaps [rsp+0x10], xmm1
00007d20d97df9aa  vmovaps [rsp+0x20], xmm2
00007d20d97df9b0  vmovaps [rsp+0x30], xmm3
00007d20d97df9b6  vmovaps [rsp+0x40], xmm4
00007d20d97df9bc  vmovaps [rsp+0x50], xmm5
00007d20d97df9c2  vmovaps [rsp+0x60], xmm6
00007d20d97df9c8  vmovaps [rsp+0x70], xmm7
00007d20d97df9ce  vmovaps [rsp+0x80], xmm8
00007d20d97df9d7  vmovaps [rsp+0x90], xmm9
00007d20d97df9e0  vmovaps [rsp+0xA0], xmm10
00007d20d97df9e9  vmovaps [rsp+0xB0], xmm11
00007d20d97df9f2  vmovaps [rsp+0xC0], xmm12
00007d20d97df9fb  vmovaps [rsp+0xD0], xmm14
00007d20d97dfa04  vmovaps [rsp+0xE0], xmm15
00007d20d97dfa0d  sub rsp, 0x30
00007d20d97dfa11  movaps [rsp], xmm13
00007d20d97dfa16  movaps [rsp+0x10], xmm15
00007d20d97dfa1c  movaps [rsp+0x20], xmm9
00007d20d97dfa22  lea rdi, [rsp]
00007d20d97dfa26  mov esi, 0x00
00007d20d97dfa2b  mov rax, 0x5EFBF4CF6530
00007d20d97dfa35  call rax
00007d20d97dfa37  movaps xmm13, [rsp]
00007d20d97dfa3c  add rsp, 0x30
00007d20d97dfa40  vmovaps xmm0, [rsp]
00007d20d97dfa45  vmovaps xmm1, [rsp+0x10]
00007d20d97dfa4b  vmovaps xmm2, [rsp+0x20]
00007d20d97dfa51  vmovaps xmm3, [rsp+0x30]
00007d20d97dfa57  vmovaps xmm4, [rsp+0x40]
00007d20d97dfa5d  vmovaps xmm5, [rsp+0x50]
00007d20d97dfa63  vmovaps xmm6, [rsp+0x60]
00007d20d97dfa69  vmovaps xmm7, [rsp+0x70]
00007d20d97dfa6f  vmovaps xmm8, [rsp+0x80]
00007d20d97dfa78  vmovaps xmm9, [rsp+0x90]
00007d20d97dfa81  vmovaps xmm10, [rsp+0xA0]
00007d20d97dfa8a  vmovaps xmm11, [rsp+0xB0]
00007d20d97dfa93  vmovaps xmm12, [rsp+0xC0]
00007d20d97dfa9c  vmovaps xmm14, [rsp+0xD0]
00007d20d97dfaa5  vmovaps xmm15, [rsp+0xE0]
00007d20d97dfaae  add rsp, 0xF0
00007d20d97dfab5  pop r11
00007d20d97dfab7  pop r10
00007d20d97dfab9  pop r9
00007d20d97dfabb  pop r8
00007d20d97dfabd  pop rsi
00007d20d97dfabe  pop rdi
00007d20d97dfabf  pop rdx
00007d20d97dfac0  pop rcx
00007d20d97dfac1  pop rax
00007d20d97dfac2  add rsp, 0x08
00007d20d97dfac6  jmp 0x00007D20D97DC458
00007d20d97dfacb  sub rsp, 0x08
00007d20d97dfacf  push rax
00007d20d97dfad0  push rcx
00007d20d97dfad1  push rdx
00007d20d97dfad2  push rdi
00007d20d97dfad3  push rsi
00007d20d97dfad4  push r8
00007d20d97dfad6  push r9
00007d20d97dfad8  push r10
00007d20d97dfada  push r11
00007d20d97dfadc  sub rsp, 0xF0
00007d20d97dfae3  vmovaps [rsp], xmm0
00007d20d97dfae8  vmovaps [rsp+0x10], xmm1
00007d20d97dfaee  vmovaps [rsp+0x20], xmm2
00007d20d97dfaf4  vmovaps [rsp+0x30], xmm3
00007d20d97dfafa  vmovaps [rsp+0x40], xmm4
00007d20d97dfb00  vmovaps [rsp+0x50], xmm5
00007d20d97dfb06  vmovaps [rsp+0x60], xmm6
00007d20d97dfb0c  vmovaps [rsp+0x70], xmm7
00007d20d97dfb12  vmovaps [rsp+0x80], xmm8
00007d20d97dfb1b  vmovaps [rsp+0x90], xmm9
00007d20d97dfb24  vmovaps [rsp+0xA0], xmm10
00007d20d97dfb2d  vmovaps [rsp+0xB0], xmm11
00007d20d97dfb36  vmovaps [rsp+0xC0], xmm12
00007d20d97dfb3f  vmovaps [rsp+0xD0], xmm13
00007d20d97dfb48  vmovaps [rsp+0xE0], xmm14
00007d20d97dfb51  sub rsp, 0x30
00007d20d97dfb55  movaps [rsp], xmm15
00007d20d97dfb5a  movaps [rsp+0x10], xmm1
00007d20d97dfb5f  movaps [rsp+0x20], xmm5
00007d20d97dfb64  lea rdi, [rsp]
00007d20d97dfb68  mov esi, 0x00
00007d20d97dfb6d  mov rax, 0x5EFBF4CF6530
00007d20d97dfb77  call rax
00007d20d97dfb79  movaps xmm15, [rsp]
00007d20d97dfb7e  add rsp, 0x30
00007d20d97dfb82  vmovaps xmm0, [rsp]
00007d20d97dfb87  vmovaps xmm1, [rsp+0x10]
00007d20d97dfb8d  vmovaps xmm2, [rsp+0x20]
00007d20d97dfb93  vmovaps xmm3, [rsp+0x30]
00007d20d97dfb99  vmovaps xmm4, [rsp+0x40]
00007d20d97dfb9f  vmovaps xmm5, [rsp+0x50]
00007d20d97dfba5  vmovaps xmm6, [rsp+0x60]
00007d20d97dfbab  vmovaps xmm7, [rsp+0x70]
00007d20d97dfbb1  vmovaps xmm8, [rsp+0x80]
00007d20d97dfbba  vmovaps xmm9, [rsp+0x90]
00007d20d97dfbc3  vmovaps xmm10, [rsp+0xA0]
00007d20d97dfbcc  vmovaps xmm11, [rsp+0xB0]
00007d20d97dfbd5  vmovaps xmm12, [rsp+0xC0]
00007d20d97dfbde  vmovaps xmm13, [rsp+0xD0]
00007d20d97dfbe7  vmovaps xmm14, [rsp+0xE0]
00007d20d97dfbf0  add rsp, 0xF0
00007d20d97dfbf7  pop r11
00007d20d97dfbf9  pop r10
00007d20d97dfbfb  pop r9
00007d20d97dfbfd  pop r8
00007d20d97dfbff  pop rsi
00007d20d97dfc00  pop rdi
00007d20d97dfc01  pop rdx
00007d20d97dfc02  pop rcx
00007d20d97dfc03  pop rax
00007d20d97dfc04  add rsp, 0x08
00007d20d97dfc08  jmp 0x00007D20D97DC473
00007d20d97dfc0d  call 0x00007D20D96B52F0
00007d20d97dfc12  jmp 0x00007D20D97DC4CE
00007d20d97dfc17  sub rsp, 0x08
00007d20d97dfc1b  push rax
00007d20d97dfc1c  push rcx
00007d20d97dfc1d  push rdx
00007d20d97dfc1e  push rdi
00007d20d97dfc1f  push rsi
00007d20d97dfc20  push r8
00007d20d97dfc22  push r9
00007d20d97dfc24  push r10
00007d20d97dfc26  push r11
00007d20d97dfc28  sub rsp, 0xF0
00007d20d97dfc2f  vmovaps [rsp], xmm0
00007d20d97dfc34  vmovaps [rsp+0x10], xmm1
00007d20d97dfc3a  vmovaps [rsp+0x20], xmm2
00007d20d97dfc40  vmovaps [rsp+0x30], xmm3
00007d20d97dfc46  vmovaps [rsp+0x40], xmm4
00007d20d97dfc4c  vmovaps [rsp+0x50], xmm5
00007d20d97dfc52  vmovaps [rsp+0x60], xmm6
00007d20d97dfc58  vmovaps [rsp+0x70], xmm7
00007d20d97dfc5e  vmovaps [rsp+0x80], xmm8
00007d20d97dfc67  vmovaps [rsp+0x90], xmm10
00007d20d97dfc70  vmovaps [rsp+0xA0], xmm11
00007d20d97dfc79  vmovaps [rsp+0xB0], xmm12
00007d20d97dfc82  vmovaps [rsp+0xC0], xmm13
00007d20d97dfc8b  vmovaps [rsp+0xD0], xmm14
00007d20d97dfc94  vmovaps [rsp+0xE0], xmm15
00007d20d97dfc9d  sub rsp, 0x30
00007d20d97dfca1  movaps [rsp], xmm9
00007d20d97dfca6  movaps [rsp+0x10], xmm8
00007d20d97dfcac  movaps [rsp+0x20], xmm11
00007d20d97dfcb2  lea rdi, [rsp]
00007d20d97dfcb6  mov esi, 0x00
00007d20d97dfcbb  mov rax, 0x5EFBF4CF6530
00007d20d97dfcc5  call rax
00007d20d97dfcc7  movaps xmm9, [rsp]
00007d20d97dfccc  add rsp, 0x30
00007d20d97dfcd0  vmovaps xmm0, [rsp]
00007d20d97dfcd5  vmovaps xmm1, [rsp+0x10]
00007d20d97dfcdb  vmovaps xmm2, [rsp+0x20]
00007d20d97dfce1  vmovaps xmm3, [rsp+0x30]
00007d20d97dfce7  vmovaps xmm4, [rsp+0x40]
00007d20d97dfced  vmovaps xmm5, [rsp+0x50]
00007d20d97dfcf3  vmovaps xmm6, [rsp+0x60]
00007d20d97dfcf9  vmovaps xmm7, [rsp+0x70]
00007d20d97dfcff  vmovaps xmm8, [rsp+0x80]
00007d20d97dfd08  vmovaps xmm10, [rsp+0x90]
00007d20d97dfd11  vmovaps xmm11, [rsp+0xA0]
00007d20d97dfd1a  vmovaps xmm12, [rsp+0xB0]
00007d20d97dfd23  vmovaps xmm13, [rsp+0xC0]
00007d20d97dfd2c  vmovaps xmm14, [rsp+0xD0]
00007d20d97dfd35  vmovaps xmm15, [rsp+0xE0]
00007d20d97dfd3e  add rsp, 0xF0
00007d20d97dfd45  pop r11
00007d20d97dfd47  pop r10
00007d20d97dfd49  pop r9
00007d20d97dfd4b  pop r8
00007d20d97dfd4d  pop rsi
00007d20d97dfd4e  pop rdi
00007d20d97dfd4f  pop rdx
00007d20d97dfd50  pop rcx
00007d20d97dfd51  pop rax
00007d20d97dfd52  add rsp, 0x08
00007d20d97dfd56  jmp 0x00007D20D97DC505
00007d20d97dfd5b  sub rsp, 0x08
00007d20d97dfd5f  push rax
00007d20d97dfd60  push rcx
00007d20d97dfd61  push rdx
00007d20d97dfd62  push rdi
00007d20d97dfd63  push rsi
00007d20d97dfd64  push r8
00007d20d97dfd66  push r9
00007d20d97dfd68  push r10
00007d20d97dfd6a  push r11
00007d20d97dfd6c  sub rsp, 0xF0
00007d20d97dfd73  vmovaps [rsp], xmm0
00007d20d97dfd78  vmovaps [rsp+0x10], xmm1
00007d20d97dfd7e  vmovaps [rsp+0x20], xmm2
00007d20d97dfd84  vmovaps [rsp+0x30], xmm3
00007d20d97dfd8a  vmovaps [rsp+0x40], xmm4
00007d20d97dfd90  vmovaps [rsp+0x50], xmm5
00007d20d97dfd96  vmovaps [rsp+0x60], xmm6
00007d20d97dfd9c  vmovaps [rsp+0x70], xmm7
00007d20d97dfda2  vmovaps [rsp+0x80], xmm8
00007d20d97dfdab  vmovaps [rsp+0x90], xmm9
00007d20d97dfdb4  vmovaps [rsp+0xA0], xmm10
00007d20d97dfdbd  vmovaps [rsp+0xB0], xmm12
00007d20d97dfdc6  vmovaps [rsp+0xC0], xmm13
00007d20d97dfdcf  vmovaps [rsp+0xD0], xmm14
00007d20d97dfdd8  vmovaps [rsp+0xE0], xmm15
00007d20d97dfde1  sub rsp, 0x30
00007d20d97dfde5  movaps [rsp], xmm11
00007d20d97dfdea  movaps [rsp+0x10], xmm10
00007d20d97dfdf0  movaps [rsp+0x20], xmm6
00007d20d97dfdf5  lea rdi, [rsp]
00007d20d97dfdf9  mov esi, 0x00
00007d20d97dfdfe  mov rax, 0x5EFBF4CF6530
00007d20d97dfe08  call rax
00007d20d97dfe0a  movaps xmm11, [rsp]
00007d20d97dfe0f  add rsp, 0x30
00007d20d97dfe13  vmovaps xmm0, [rsp]
00007d20d97dfe18  vmovaps xmm1, [rsp+0x10]
00007d20d97dfe1e  vmovaps xmm2, [rsp+0x20]
00007d20d97dfe24  vmovaps xmm3, [rsp+0x30]
00007d20d97dfe2a  vmovaps xmm4, [rsp+0x40]
00007d20d97dfe30  vmovaps xmm5, [rsp+0x50]
00007d20d97dfe36  vmovaps xmm6, [rsp+0x60]
00007d20d97dfe3c  vmovaps xmm7, [rsp+0x70]
00007d20d97dfe42  vmovaps xmm8, [rsp+0x80]
00007d20d97dfe4b  vmovaps xmm9, [rsp+0x90]
00007d20d97dfe54  vmovaps xmm10, [rsp+0xA0]
00007d20d97dfe5d  vmovaps xmm12, [rsp+0xB0]
00007d20d97dfe66  vmovaps xmm13, [rsp+0xC0]
00007d20d97dfe6f  vmovaps xmm14, [rsp+0xD0]
00007d20d97dfe78  vmovaps xmm15, [rsp+0xE0]
00007d20d97dfe81  add rsp, 0xF0
00007d20d97dfe88  pop r11
00007d20d97dfe8a  pop r10
00007d20d97dfe8c  pop r9
00007d20d97dfe8e  pop r8
00007d20d97dfe90  pop rsi
00007d20d97dfe91  pop rdi
00007d20d97dfe92  pop rdx
00007d20d97dfe93  pop rcx
00007d20d97dfe94  pop rax
00007d20d97dfe95  add rsp, 0x08
00007d20d97dfe99  jmp 0x00007D20D97DC520
00007d20d97dfe9e  sub rsp, 0x08
00007d20d97dfea2  push rax
00007d20d97dfea3  push rcx
00007d20d97dfea4  push rdx
00007d20d97dfea5  push rdi
00007d20d97dfea6  push rsi
00007d20d97dfea7  push r8
00007d20d97dfea9  push r9
00007d20d97dfeab  push r10
00007d20d97dfead  push r11
00007d20d97dfeaf  sub rsp, 0xF0
00007d20d97dfeb6  vmovaps [rsp], xmm0
00007d20d97dfebb  vmovaps [rsp+0x10], xmm1
00007d20d97dfec1  vmovaps [rsp+0x20], xmm2
00007d20d97dfec7  vmovaps [rsp+0x30], xmm3
00007d20d97dfecd  vmovaps [rsp+0x40], xmm4
00007d20d97dfed3  vmovaps [rsp+0x50], xmm5
00007d20d97dfed9  vmovaps [rsp+0x60], xmm6
00007d20d97dfedf  vmovaps [rsp+0x70], xmm7
00007d20d97dfee5  vmovaps [rsp+0x80], xmm8
00007d20d97dfeee  vmovaps [rsp+0x90], xmm9
00007d20d97dfef7  vmovaps [rsp+0xA0], xmm11
00007d20d97dff00  vmovaps [rsp+0xB0], xmm12
00007d20d97dff09  vmovaps [rsp+0xC0], xmm13
00007d20d97dff12  vmovaps [rsp+0xD0], xmm14
00007d20d97dff1b  vmovaps [rsp+0xE0], xmm15
00007d20d97dff24  sub rsp, 0x30
00007d20d97dff28  movaps [rsp], xmm10
00007d20d97dff2d  movaps [rsp+0x10], xmm14
00007d20d97dff33  movaps [rsp+0x20], xmm4
00007d20d97dff38  lea rdi, [rsp]
00007d20d97dff3c  mov esi, 0x00
00007d20d97dff41  mov rax, 0x5EFBF4CF6530
00007d20d97dff4b  call rax
00007d20d97dff4d  movaps xmm10, [rsp]
00007d20d97dff52  add rsp, 0x30
00007d20d97dff56  vmovaps xmm0, [rsp]
00007d20d97dff5b  vmovaps xmm1, [rsp+0x10]
00007d20d97dff61  vmovaps xmm2, [rsp+0x20]
00007d20d97dff67  vmovaps xmm3, [rsp+0x30]
00007d20d97dff6d  vmovaps xmm4, [rsp+0x40]
00007d20d97dff73  vmovaps xmm5, [rsp+0x50]
00007d20d97dff79  vmovaps xmm6, [rsp+0x60]
00007d20d97dff7f  vmovaps xmm7, [rsp+0x70]
00007d20d97dff85  vmovaps xmm8, [rsp+0x80]
00007d20d97dff8e  vmovaps xmm9, [rsp+0x90]
00007d20d97dff97  vmovaps xmm11, [rsp+0xA0]
00007d20d97dffa0  vmovaps xmm12, [rsp+0xB0]
00007d20d97dffa9  vmovaps xmm13, [rsp+0xC0]
00007d20d97dffb2  vmovaps xmm14, [rsp+0xD0]
00007d20d97dffbb  vmovaps xmm15, [rsp+0xE0]
00007d20d97dffc4  add rsp, 0xF0
00007d20d97dffcb  pop r11
00007d20d97dffcd  pop r10
00007d20d97dffcf  pop r9
00007d20d97dffd1  pop r8
00007d20d97dffd3  pop rsi
00007d20d97dffd4  pop rdi
00007d20d97dffd5  pop rdx
00007d20d97dffd6  pop rcx
00007d20d97dffd7  pop rax
00007d20d97dffd8  add rsp, 0x08
00007d20d97dffdc  jmp 0x00007D20D97DC53B
00007d20d97dffe1  sub rsp, 0x08
00007d20d97dffe5  push rax
00007d20d97dffe6  push rcx
00007d20d97dffe7  push rdx
00007d20d97dffe8  push rdi
00007d20d97dffe9  push rsi
00007d20d97dffea  push r8
00007d20d97dffec  push r9
00007d20d97dffee  push r10
00007d20d97dfff0  push r11
00007d20d97dfff2  sub rsp, 0xF0
00007d20d97dfff9  vmovaps [rsp], xmm0
00007d20d97dfffe  vmovaps [rsp+0x10], xmm1
00007d20d97e0004  vmovaps [rsp+0x20], xmm2
00007d20d97e000a  vmovaps [rsp+0x30], xmm3
00007d20d97e0010  vmovaps [rsp+0x40], xmm4
00007d20d97e0016  vmovaps [rsp+0x50], xmm5
00007d20d97e001c  vmovaps [rsp+0x60], xmm6
00007d20d97e0022  vmovaps [rsp+0x70], xmm7
00007d20d97e0028  vmovaps [rsp+0x80], xmm9
00007d20d97e0031  vmovaps [rsp+0x90], xmm10
00007d20d97e003a  vmovaps [rsp+0xA0], xmm11
00007d20d97e0043  vmovaps [rsp+0xB0], xmm12
00007d20d97e004c  vmovaps [rsp+0xC0], xmm13
00007d20d97e0055  vmovaps [rsp+0xD0], xmm14
00007d20d97e005e  vmovaps [rsp+0xE0], xmm15
00007d20d97e0067  sub rsp, 0x30
00007d20d97e006b  movaps [rsp], xmm8
00007d20d97e0070  movaps [rsp+0x10], xmm1
00007d20d97e0075  movaps [rsp+0x20], xmm14
00007d20d97e007b  lea rdi, [rsp]
00007d20d97e007f  mov esi, 0x00
00007d20d97e0084  mov rax, 0x5EFBF4CF6530
00007d20d97e008e  call rax
00007d20d97e0090  movaps xmm8, [rsp]
00007d20d97e0095  add rsp, 0x30
00007d20d97e0099  vmovaps xmm0, [rsp]
00007d20d97e009e  vmovaps xmm1, [rsp+0x10]
00007d20d97e00a4  vmovaps xmm2, [rsp+0x20]
00007d20d97e00aa  vmovaps xmm3, [rsp+0x30]
00007d20d97e00b0  vmovaps xmm4, [rsp+0x40]
00007d20d97e00b6  vmovaps xmm5, [rsp+0x50]
00007d20d97e00bc  vmovaps xmm6, [rsp+0x60]
00007d20d97e00c2  vmovaps xmm7, [rsp+0x70]
00007d20d97e00c8  vmovaps xmm9, [rsp+0x80]
00007d20d97e00d1  vmovaps xmm10, [rsp+0x90]
00007d20d97e00da  vmovaps xmm11, [rsp+0xA0]
00007d20d97e00e3  vmovaps xmm12, [rsp+0xB0]
00007d20d97e00ec  vmovaps xmm13, [rsp+0xC0]
00007d20d97e00f5  vmovaps xmm14, [rsp+0xD0]
00007d20d97e00fe  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0107  add rsp, 0xF0
00007d20d97e010e  pop r11
00007d20d97e0110  pop r10
00007d20d97e0112  pop r9
00007d20d97e0114  pop r8
00007d20d97e0116  pop rsi
00007d20d97e0117  pop rdi
00007d20d97e0118  pop rdx
00007d20d97e0119  pop rcx
00007d20d97e011a  pop rax
00007d20d97e011b  add rsp, 0x08
00007d20d97e011f  jmp 0x00007D20D97DC561
00007d20d97e0124  sub rsp, 0x08
00007d20d97e0128  push rax
00007d20d97e0129  push rcx
00007d20d97e012a  push rdx
00007d20d97e012b  push rdi
00007d20d97e012c  push rsi
00007d20d97e012d  push r8
00007d20d97e012f  push r9
00007d20d97e0131  push r10
00007d20d97e0133  push r11
00007d20d97e0135  sub rsp, 0xF0
00007d20d97e013c  vmovaps [rsp], xmm0
00007d20d97e0141  vmovaps [rsp+0x10], xmm1
00007d20d97e0147  vmovaps [rsp+0x20], xmm2
00007d20d97e014d  vmovaps [rsp+0x30], xmm3
00007d20d97e0153  vmovaps [rsp+0x40], xmm4
00007d20d97e0159  vmovaps [rsp+0x50], xmm5
00007d20d97e015f  vmovaps [rsp+0x60], xmm7
00007d20d97e0165  vmovaps [rsp+0x70], xmm8
00007d20d97e016b  vmovaps [rsp+0x80], xmm9
00007d20d97e0174  vmovaps [rsp+0x90], xmm10
00007d20d97e017d  vmovaps [rsp+0xA0], xmm11
00007d20d97e0186  vmovaps [rsp+0xB0], xmm12
00007d20d97e018f  vmovaps [rsp+0xC0], xmm13
00007d20d97e0198  vmovaps [rsp+0xD0], xmm14
00007d20d97e01a1  vmovaps [rsp+0xE0], xmm15
00007d20d97e01aa  sub rsp, 0x30
00007d20d97e01ae  movaps [rsp], xmm6
00007d20d97e01b2  movaps [rsp+0x10], xmm1
00007d20d97e01b7  movaps [rsp+0x20], xmm14
00007d20d97e01bd  lea rdi, [rsp]
00007d20d97e01c1  mov esi, 0x00
00007d20d97e01c6  mov rax, 0x5EFBF4CF6530
00007d20d97e01d0  call rax
00007d20d97e01d2  movaps xmm6, [rsp]
00007d20d97e01d6  add rsp, 0x30
00007d20d97e01da  vmovaps xmm0, [rsp]
00007d20d97e01df  vmovaps xmm1, [rsp+0x10]
00007d20d97e01e5  vmovaps xmm2, [rsp+0x20]
00007d20d97e01eb  vmovaps xmm3, [rsp+0x30]
00007d20d97e01f1  vmovaps xmm4, [rsp+0x40]
00007d20d97e01f7  vmovaps xmm5, [rsp+0x50]
00007d20d97e01fd  vmovaps xmm7, [rsp+0x60]
00007d20d97e0203  vmovaps xmm8, [rsp+0x70]
00007d20d97e0209  vmovaps xmm9, [rsp+0x80]
00007d20d97e0212  vmovaps xmm10, [rsp+0x90]
00007d20d97e021b  vmovaps xmm11, [rsp+0xA0]
00007d20d97e0224  vmovaps xmm12, [rsp+0xB0]
00007d20d97e022d  vmovaps xmm13, [rsp+0xC0]
00007d20d97e0236  vmovaps xmm14, [rsp+0xD0]
00007d20d97e023f  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0248  add rsp, 0xF0
00007d20d97e024f  pop r11
00007d20d97e0251  pop r10
00007d20d97e0253  pop r9
00007d20d97e0255  pop r8
00007d20d97e0257  pop rsi
00007d20d97e0258  pop rdi
00007d20d97e0259  pop rdx
00007d20d97e025a  pop rcx
00007d20d97e025b  pop rax
00007d20d97e025c  add rsp, 0x08
00007d20d97e0260  jmp 0x00007D20D97DC58D
00007d20d97e0265  sub rsp, 0x08
00007d20d97e0269  push rax
00007d20d97e026a  push rcx
00007d20d97e026b  push rdx
00007d20d97e026c  push rdi
00007d20d97e026d  push rsi
00007d20d97e026e  push r8
00007d20d97e0270  push r9
00007d20d97e0272  push r10
00007d20d97e0274  push r11
00007d20d97e0276  sub rsp, 0xF0
00007d20d97e027d  vmovaps [rsp], xmm0
00007d20d97e0282  vmovaps [rsp+0x10], xmm1
00007d20d97e0288  vmovaps [rsp+0x20], xmm2
00007d20d97e028e  vmovaps [rsp+0x30], xmm3
00007d20d97e0294  vmovaps [rsp+0x40], xmm4
00007d20d97e029a  vmovaps [rsp+0x50], xmm5
00007d20d97e02a0  vmovaps [rsp+0x60], xmm6
00007d20d97e02a6  vmovaps [rsp+0x70], xmm7
00007d20d97e02ac  vmovaps [rsp+0x80], xmm8
00007d20d97e02b5  vmovaps [rsp+0x90], xmm9
00007d20d97e02be  vmovaps [rsp+0xA0], xmm10
00007d20d97e02c7  vmovaps [rsp+0xB0], xmm11
00007d20d97e02d0  vmovaps [rsp+0xC0], xmm12
00007d20d97e02d9  vmovaps [rsp+0xD0], xmm13
00007d20d97e02e2  vmovaps [rsp+0xE0], xmm15
00007d20d97e02eb  sub rsp, 0x30
00007d20d97e02ef  movaps [rsp], xmm14
00007d20d97e02f4  movaps [rsp+0x10], xmm12
00007d20d97e02fa  movaps [rsp+0x20], xmm1
00007d20d97e02ff  lea rdi, [rsp]
00007d20d97e0303  mov esi, 0x00
00007d20d97e0308  mov rax, 0x5EFBF4CF6530
00007d20d97e0312  call rax
00007d20d97e0314  movaps xmm14, [rsp]
00007d20d97e0319  add rsp, 0x30
00007d20d97e031d  vmovaps xmm0, [rsp]
00007d20d97e0322  vmovaps xmm1, [rsp+0x10]
00007d20d97e0328  vmovaps xmm2, [rsp+0x20]
00007d20d97e032e  vmovaps xmm3, [rsp+0x30]
00007d20d97e0334  vmovaps xmm4, [rsp+0x40]
00007d20d97e033a  vmovaps xmm5, [rsp+0x50]
00007d20d97e0340  vmovaps xmm6, [rsp+0x60]
00007d20d97e0346  vmovaps xmm7, [rsp+0x70]
00007d20d97e034c  vmovaps xmm8, [rsp+0x80]
00007d20d97e0355  vmovaps xmm9, [rsp+0x90]
00007d20d97e035e  vmovaps xmm10, [rsp+0xA0]
00007d20d97e0367  vmovaps xmm11, [rsp+0xB0]
00007d20d97e0370  vmovaps xmm12, [rsp+0xC0]
00007d20d97e0379  vmovaps xmm13, [rsp+0xD0]
00007d20d97e0382  vmovaps xmm15, [rsp+0xE0]
00007d20d97e038b  add rsp, 0xF0
00007d20d97e0392  pop r11
00007d20d97e0394  pop r10
00007d20d97e0396  pop r9
00007d20d97e0398  pop r8
00007d20d97e039a  pop rsi
00007d20d97e039b  pop rdi
00007d20d97e039c  pop rdx
00007d20d97e039d  pop rcx
00007d20d97e039e  pop rax
00007d20d97e039f  add rsp, 0x08
00007d20d97e03a3  jmp 0x00007D20D97DC5B3
00007d20d97e03a8  sub rsp, 0x08
00007d20d97e03ac  push rax
00007d20d97e03ad  push rcx
00007d20d97e03ae  push rdx
00007d20d97e03af  push rdi
00007d20d97e03b0  push rsi
00007d20d97e03b1  push r8
00007d20d97e03b3  push r9
00007d20d97e03b5  push r10
00007d20d97e03b7  push r11
00007d20d97e03b9  sub rsp, 0xF0
00007d20d97e03c0  vmovaps [rsp], xmm0
00007d20d97e03c5  vmovaps [rsp+0x10], xmm2
00007d20d97e03cb  vmovaps [rsp+0x20], xmm3
00007d20d97e03d1  vmovaps [rsp+0x30], xmm4
00007d20d97e03d7  vmovaps [rsp+0x40], xmm5
00007d20d97e03dd  vmovaps [rsp+0x50], xmm6
00007d20d97e03e3  vmovaps [rsp+0x60], xmm7
00007d20d97e03e9  vmovaps [rsp+0x70], xmm8
00007d20d97e03ef  vmovaps [rsp+0x80], xmm9
00007d20d97e03f8  vmovaps [rsp+0x90], xmm10
00007d20d97e0401  vmovaps [rsp+0xA0], xmm11
00007d20d97e040a  vmovaps [rsp+0xB0], xmm12
00007d20d97e0413  vmovaps [rsp+0xC0], xmm13
00007d20d97e041c  vmovaps [rsp+0xD0], xmm14
00007d20d97e0425  vmovaps [rsp+0xE0], xmm15
00007d20d97e042e  sub rsp, 0x30
00007d20d97e0432  movaps [rsp], xmm1
00007d20d97e0436  movaps [rsp+0x10], xmm13
00007d20d97e043c  movaps [rsp+0x20], xmm9
00007d20d97e0442  lea rdi, [rsp]
00007d20d97e0446  mov esi, 0x00
00007d20d97e044b  mov rax, 0x5EFBF4CF6530
00007d20d97e0455  call rax
00007d20d97e0457  movaps xmm1, [rsp]
00007d20d97e045b  add rsp, 0x30
00007d20d97e045f  vmovaps xmm0, [rsp]
00007d20d97e0464  vmovaps xmm2, [rsp+0x10]
00007d20d97e046a  vmovaps xmm3, [rsp+0x20]
00007d20d97e0470  vmovaps xmm4, [rsp+0x30]
00007d20d97e0476  vmovaps xmm5, [rsp+0x40]
00007d20d97e047c  vmovaps xmm6, [rsp+0x50]
00007d20d97e0482  vmovaps xmm7, [rsp+0x60]
00007d20d97e0488  vmovaps xmm8, [rsp+0x70]
00007d20d97e048e  vmovaps xmm9, [rsp+0x80]
00007d20d97e0497  vmovaps xmm10, [rsp+0x90]
00007d20d97e04a0  vmovaps xmm11, [rsp+0xA0]
00007d20d97e04a9  vmovaps xmm12, [rsp+0xB0]
00007d20d97e04b2  vmovaps xmm13, [rsp+0xC0]
00007d20d97e04bb  vmovaps xmm14, [rsp+0xD0]
00007d20d97e04c4  vmovaps xmm15, [rsp+0xE0]
00007d20d97e04cd  add rsp, 0xF0
00007d20d97e04d4  pop r11
00007d20d97e04d6  pop r10
00007d20d97e04d8  pop r9
00007d20d97e04da  pop r8
00007d20d97e04dc  pop rsi
00007d20d97e04dd  pop rdi
00007d20d97e04de  pop rdx
00007d20d97e04df  pop rcx
00007d20d97e04e0  pop rax
00007d20d97e04e1  add rsp, 0x08
00007d20d97e04e5  jmp 0x00007D20D97DC5CD
00007d20d97e04ea  sub rsp, 0x08
00007d20d97e04ee  push rax
00007d20d97e04ef  push rcx
00007d20d97e04f0  push rdx
00007d20d97e04f1  push rdi
00007d20d97e04f2  push rsi
00007d20d97e04f3  push r8
00007d20d97e04f5  push r9
00007d20d97e04f7  push r10
00007d20d97e04f9  push r11
00007d20d97e04fb  sub rsp, 0xF0
00007d20d97e0502  vmovaps [rsp], xmm0
00007d20d97e0507  vmovaps [rsp+0x10], xmm1
00007d20d97e050d  vmovaps [rsp+0x20], xmm2
00007d20d97e0513  vmovaps [rsp+0x30], xmm3
00007d20d97e0519  vmovaps [rsp+0x40], xmm4
00007d20d97e051f  vmovaps [rsp+0x50], xmm5
00007d20d97e0525  vmovaps [rsp+0x60], xmm6
00007d20d97e052b  vmovaps [rsp+0x70], xmm7
00007d20d97e0531  vmovaps [rsp+0x80], xmm8
00007d20d97e053a  vmovaps [rsp+0x90], xmm9
00007d20d97e0543  vmovaps [rsp+0xA0], xmm10
00007d20d97e054c  vmovaps [rsp+0xB0], xmm11
00007d20d97e0555  vmovaps [rsp+0xC0], xmm13
00007d20d97e055e  vmovaps [rsp+0xD0], xmm14
00007d20d97e0567  vmovaps [rsp+0xE0], xmm15
00007d20d97e0570  sub rsp, 0x30
00007d20d97e0574  movaps [rsp], xmm12
00007d20d97e0579  movaps [rsp+0x10], xmm7
00007d20d97e057e  movaps [rsp+0x20], xmm13
00007d20d97e0584  lea rdi, [rsp]
00007d20d97e0588  mov esi, 0x00
00007d20d97e058d  mov rax, 0x5EFBF4CF6530
00007d20d97e0597  call rax
00007d20d97e0599  movaps xmm12, [rsp]
00007d20d97e059e  add rsp, 0x30
00007d20d97e05a2  vmovaps xmm0, [rsp]
00007d20d97e05a7  vmovaps xmm1, [rsp+0x10]
00007d20d97e05ad  vmovaps xmm2, [rsp+0x20]
00007d20d97e05b3  vmovaps xmm3, [rsp+0x30]
00007d20d97e05b9  vmovaps xmm4, [rsp+0x40]
00007d20d97e05bf  vmovaps xmm5, [rsp+0x50]
00007d20d97e05c5  vmovaps xmm6, [rsp+0x60]
00007d20d97e05cb  vmovaps xmm7, [rsp+0x70]
00007d20d97e05d1  vmovaps xmm8, [rsp+0x80]
00007d20d97e05da  vmovaps xmm9, [rsp+0x90]
00007d20d97e05e3  vmovaps xmm10, [rsp+0xA0]
00007d20d97e05ec  vmovaps xmm11, [rsp+0xB0]
00007d20d97e05f5  vmovaps xmm13, [rsp+0xC0]
00007d20d97e05fe  vmovaps xmm14, [rsp+0xD0]
00007d20d97e0607  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0610  add rsp, 0xF0
00007d20d97e0617  pop r11
00007d20d97e0619  pop r10
00007d20d97e061b  pop r9
00007d20d97e061d  pop r8
00007d20d97e061f  pop rsi
00007d20d97e0620  pop rdi
00007d20d97e0621  pop rdx
00007d20d97e0622  pop rcx
00007d20d97e0623  pop rax
00007d20d97e0624  add rsp, 0x08
00007d20d97e0628  jmp 0x00007D20D97DC5F4
00007d20d97e062d  sub rsp, 0x08
00007d20d97e0631  push rax
00007d20d97e0632  push rcx
00007d20d97e0633  push rdx
00007d20d97e0634  push rdi
00007d20d97e0635  push rsi
00007d20d97e0636  push r8
00007d20d97e0638  push r9
00007d20d97e063a  push r10
00007d20d97e063c  push r11
00007d20d97e063e  sub rsp, 0xF0
00007d20d97e0645  vmovaps [rsp], xmm0
00007d20d97e064a  vmovaps [rsp+0x10], xmm1
00007d20d97e0650  vmovaps [rsp+0x20], xmm2
00007d20d97e0656  vmovaps [rsp+0x30], xmm3
00007d20d97e065c  vmovaps [rsp+0x40], xmm4
00007d20d97e0662  vmovaps [rsp+0x50], xmm5
00007d20d97e0668  vmovaps [rsp+0x60], xmm6
00007d20d97e066e  vmovaps [rsp+0x70], xmm7
00007d20d97e0674  vmovaps [rsp+0x80], xmm8
00007d20d97e067d  vmovaps [rsp+0x90], xmm9
00007d20d97e0686  vmovaps [rsp+0xA0], xmm10
00007d20d97e068f  vmovaps [rsp+0xB0], xmm11
00007d20d97e0698  vmovaps [rsp+0xC0], xmm12
00007d20d97e06a1  vmovaps [rsp+0xD0], xmm14
00007d20d97e06aa  vmovaps [rsp+0xE0], xmm15
00007d20d97e06b3  sub rsp, 0x30
00007d20d97e06b7  movaps [rsp], xmm13
00007d20d97e06bc  movaps [rsp+0x10], xmm15
00007d20d97e06c2  movaps [rsp+0x20], xmm8
00007d20d97e06c8  lea rdi, [rsp]
00007d20d97e06cc  mov esi, 0x00
00007d20d97e06d1  mov rax, 0x5EFBF4CF6530
00007d20d97e06db  call rax
00007d20d97e06dd  movaps xmm13, [rsp]
00007d20d97e06e2  add rsp, 0x30
00007d20d97e06e6  vmovaps xmm0, [rsp]
00007d20d97e06eb  vmovaps xmm1, [rsp+0x10]
00007d20d97e06f1  vmovaps xmm2, [rsp+0x20]
00007d20d97e06f7  vmovaps xmm3, [rsp+0x30]
00007d20d97e06fd  vmovaps xmm4, [rsp+0x40]
00007d20d97e0703  vmovaps xmm5, [rsp+0x50]
00007d20d97e0709  vmovaps xmm6, [rsp+0x60]
00007d20d97e070f  vmovaps xmm7, [rsp+0x70]
00007d20d97e0715  vmovaps xmm8, [rsp+0x80]
00007d20d97e071e  vmovaps xmm9, [rsp+0x90]
00007d20d97e0727  vmovaps xmm10, [rsp+0xA0]
00007d20d97e0730  vmovaps xmm11, [rsp+0xB0]
00007d20d97e0739  vmovaps xmm12, [rsp+0xC0]
00007d20d97e0742  vmovaps xmm14, [rsp+0xD0]
00007d20d97e074b  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0754  add rsp, 0xF0
00007d20d97e075b  pop r11
00007d20d97e075d  pop r10
00007d20d97e075f  pop r9
00007d20d97e0761  pop r8
00007d20d97e0763  pop rsi
00007d20d97e0764  pop rdi
00007d20d97e0765  pop rdx
00007d20d97e0766  pop rcx
00007d20d97e0767  pop rax
00007d20d97e0768  add rsp, 0x08
00007d20d97e076c  jmp 0x00007D20D97DC60F
00007d20d97e0771  sub rsp, 0x08
00007d20d97e0775  push rax
00007d20d97e0776  push rcx
00007d20d97e0777  push rdx
00007d20d97e0778  push rdi
00007d20d97e0779  push rsi
00007d20d97e077a  push r8
00007d20d97e077c  push r9
00007d20d97e077e  push r10
00007d20d97e0780  push r11
00007d20d97e0782  sub rsp, 0xF0
00007d20d97e0789  vmovaps [rsp], xmm0
00007d20d97e078e  vmovaps [rsp+0x10], xmm1
00007d20d97e0794  vmovaps [rsp+0x20], xmm2
00007d20d97e079a  vmovaps [rsp+0x30], xmm3
00007d20d97e07a0  vmovaps [rsp+0x40], xmm4
00007d20d97e07a6  vmovaps [rsp+0x50], xmm5
00007d20d97e07ac  vmovaps [rsp+0x60], xmm6
00007d20d97e07b2  vmovaps [rsp+0x70], xmm7
00007d20d97e07b8  vmovaps [rsp+0x80], xmm9
00007d20d97e07c1  vmovaps [rsp+0x90], xmm10
00007d20d97e07ca  vmovaps [rsp+0xA0], xmm11
00007d20d97e07d3  vmovaps [rsp+0xB0], xmm12
00007d20d97e07dc  vmovaps [rsp+0xC0], xmm13
00007d20d97e07e5  vmovaps [rsp+0xD0], xmm14
00007d20d97e07ee  vmovaps [rsp+0xE0], xmm15
00007d20d97e07f7  sub rsp, 0x30
00007d20d97e07fb  movaps [rsp], xmm8
00007d20d97e0800  movaps [rsp+0x10], xmm15
00007d20d97e0806  movaps [rsp+0x20], xmm9
00007d20d97e080c  lea rdi, [rsp]
00007d20d97e0810  mov esi, 0x00
00007d20d97e0815  mov rax, 0x5EFBF4CF6530
00007d20d97e081f  call rax
00007d20d97e0821  movaps xmm8, [rsp]
00007d20d97e0826  add rsp, 0x30
00007d20d97e082a  vmovaps xmm0, [rsp]
00007d20d97e082f  vmovaps xmm1, [rsp+0x10]
00007d20d97e0835  vmovaps xmm2, [rsp+0x20]
00007d20d97e083b  vmovaps xmm3, [rsp+0x30]
00007d20d97e0841  vmovaps xmm4, [rsp+0x40]
00007d20d97e0847  vmovaps xmm5, [rsp+0x50]
00007d20d97e084d  vmovaps xmm6, [rsp+0x60]
00007d20d97e0853  vmovaps xmm7, [rsp+0x70]
00007d20d97e0859  vmovaps xmm9, [rsp+0x80]
00007d20d97e0862  vmovaps xmm10, [rsp+0x90]
00007d20d97e086b  vmovaps xmm11, [rsp+0xA0]
00007d20d97e0874  vmovaps xmm12, [rsp+0xB0]
00007d20d97e087d  vmovaps xmm13, [rsp+0xC0]
00007d20d97e0886  vmovaps xmm14, [rsp+0xD0]
00007d20d97e088f  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0898  add rsp, 0xF0
00007d20d97e089f  pop r11
00007d20d97e08a1  pop r10
00007d20d97e08a3  pop r9
00007d20d97e08a5  pop r8
00007d20d97e08a7  pop rsi
00007d20d97e08a8  pop rdi
00007d20d97e08a9  pop rdx
00007d20d97e08aa  pop rcx
00007d20d97e08ab  pop rax
00007d20d97e08ac  add rsp, 0x08
00007d20d97e08b0  jmp 0x00007D20D97DC63D
00007d20d97e08b5  sub rsp, 0x08
00007d20d97e08b9  push rax
00007d20d97e08ba  push rcx
00007d20d97e08bb  push rdx
00007d20d97e08bc  push rdi
00007d20d97e08bd  push rsi
00007d20d97e08be  push r8
00007d20d97e08c0  push r9
00007d20d97e08c2  push r10
00007d20d97e08c4  push r11
00007d20d97e08c6  sub rsp, 0xF0
00007d20d97e08cd  vmovaps [rsp], xmm0
00007d20d97e08d2  vmovaps [rsp+0x10], xmm1
00007d20d97e08d8  vmovaps [rsp+0x20], xmm2
00007d20d97e08de  vmovaps [rsp+0x30], xmm3
00007d20d97e08e4  vmovaps [rsp+0x40], xmm4
00007d20d97e08ea  vmovaps [rsp+0x50], xmm5
00007d20d97e08f0  vmovaps [rsp+0x60], xmm6
00007d20d97e08f6  vmovaps [rsp+0x70], xmm7
00007d20d97e08fc  vmovaps [rsp+0x80], xmm8
00007d20d97e0905  vmovaps [rsp+0x90], xmm9
00007d20d97e090e  vmovaps [rsp+0xA0], xmm10
00007d20d97e0917  vmovaps [rsp+0xB0], xmm11
00007d20d97e0920  vmovaps [rsp+0xC0], xmm12
00007d20d97e0929  vmovaps [rsp+0xD0], xmm13
00007d20d97e0932  vmovaps [rsp+0xE0], xmm14
00007d20d97e093b  sub rsp, 0x30
00007d20d97e093f  movaps [rsp], xmm15
00007d20d97e0944  movaps [rsp+0x10], xmm11
00007d20d97e094a  movaps [rsp+0x20], xmm6
00007d20d97e094f  lea rdi, [rsp]
00007d20d97e0953  mov esi, 0x00
00007d20d97e0958  mov rax, 0x5EFBF4CF6530
00007d20d97e0962  call rax
00007d20d97e0964  movaps xmm15, [rsp]
00007d20d97e0969  add rsp, 0x30
00007d20d97e096d  vmovaps xmm0, [rsp]
00007d20d97e0972  vmovaps xmm1, [rsp+0x10]
00007d20d97e0978  vmovaps xmm2, [rsp+0x20]
00007d20d97e097e  vmovaps xmm3, [rsp+0x30]
00007d20d97e0984  vmovaps xmm4, [rsp+0x40]
00007d20d97e098a  vmovaps xmm5, [rsp+0x50]
00007d20d97e0990  vmovaps xmm6, [rsp+0x60]
00007d20d97e0996  vmovaps xmm7, [rsp+0x70]
00007d20d97e099c  vmovaps xmm8, [rsp+0x80]
00007d20d97e09a5  vmovaps xmm9, [rsp+0x90]
00007d20d97e09ae  vmovaps xmm10, [rsp+0xA0]
00007d20d97e09b7  vmovaps xmm11, [rsp+0xB0]
00007d20d97e09c0  vmovaps xmm12, [rsp+0xC0]
00007d20d97e09c9  vmovaps xmm13, [rsp+0xD0]
00007d20d97e09d2  vmovaps xmm14, [rsp+0xE0]
00007d20d97e09db  add rsp, 0xF0
00007d20d97e09e2  pop r11
00007d20d97e09e4  pop r10
00007d20d97e09e6  pop r9
00007d20d97e09e8  pop r8
00007d20d97e09ea  pop rsi
00007d20d97e09eb  pop rdi
00007d20d97e09ec  pop rdx
00007d20d97e09ed  pop rcx
00007d20d97e09ee  pop rax
00007d20d97e09ef  add rsp, 0x08
00007d20d97e09f3  jmp 0x00007D20D97DC658
00007d20d97e09f8  sub rsp, 0x08
00007d20d97e09fc  push rax
00007d20d97e09fd  push rcx
00007d20d97e09fe  push rdx
00007d20d97e09ff  push rdi
00007d20d97e0a00  push rsi
00007d20d97e0a01  push r8
00007d20d97e0a03  push r9
00007d20d97e0a05  push r10
00007d20d97e0a07  push r11
00007d20d97e0a09  sub rsp, 0xF0
00007d20d97e0a10  vmovaps [rsp], xmm0
00007d20d97e0a15  vmovaps [rsp+0x10], xmm1
00007d20d97e0a1b  vmovaps [rsp+0x20], xmm2
00007d20d97e0a21  vmovaps [rsp+0x30], xmm3
00007d20d97e0a27  vmovaps [rsp+0x40], xmm4
00007d20d97e0a2d  vmovaps [rsp+0x50], xmm5
00007d20d97e0a33  vmovaps [rsp+0x60], xmm6
00007d20d97e0a39  vmovaps [rsp+0x70], xmm8
00007d20d97e0a3f  vmovaps [rsp+0x80], xmm9
00007d20d97e0a48  vmovaps [rsp+0x90], xmm10
00007d20d97e0a51  vmovaps [rsp+0xA0], xmm11
00007d20d97e0a5a  vmovaps [rsp+0xB0], xmm12
00007d20d97e0a63  vmovaps [rsp+0xC0], xmm13
00007d20d97e0a6c  vmovaps [rsp+0xD0], xmm14
00007d20d97e0a75  vmovaps [rsp+0xE0], xmm15
00007d20d97e0a7e  sub rsp, 0x30
00007d20d97e0a82  movaps [rsp], xmm7
00007d20d97e0a86  movaps [rsp+0x10], xmm11
00007d20d97e0a8c  movaps [rsp+0x20], xmm9
00007d20d97e0a92  lea rdi, [rsp]
00007d20d97e0a96  mov esi, 0x00
00007d20d97e0a9b  mov rax, 0x5EFBF4CF6530
00007d20d97e0aa5  call rax
00007d20d97e0aa7  movaps xmm7, [rsp]
00007d20d97e0aab  add rsp, 0x30
00007d20d97e0aaf  vmovaps xmm0, [rsp]
00007d20d97e0ab4  vmovaps xmm1, [rsp+0x10]
00007d20d97e0aba  vmovaps xmm2, [rsp+0x20]
00007d20d97e0ac0  vmovaps xmm3, [rsp+0x30]
00007d20d97e0ac6  vmovaps xmm4, [rsp+0x40]
00007d20d97e0acc  vmovaps xmm5, [rsp+0x50]
00007d20d97e0ad2  vmovaps xmm6, [rsp+0x60]
00007d20d97e0ad8  vmovaps xmm8, [rsp+0x70]
00007d20d97e0ade  vmovaps xmm9, [rsp+0x80]
00007d20d97e0ae7  vmovaps xmm10, [rsp+0x90]
00007d20d97e0af0  vmovaps xmm11, [rsp+0xA0]
00007d20d97e0af9  vmovaps xmm12, [rsp+0xB0]
00007d20d97e0b02  vmovaps xmm13, [rsp+0xC0]
00007d20d97e0b0b  vmovaps xmm14, [rsp+0xD0]
00007d20d97e0b14  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0b1d  add rsp, 0xF0
00007d20d97e0b24  pop r11
00007d20d97e0b26  pop r10
00007d20d97e0b28  pop r9
00007d20d97e0b2a  pop r8
00007d20d97e0b2c  pop rsi
00007d20d97e0b2d  pop rdi
00007d20d97e0b2e  pop rdx
00007d20d97e0b2f  pop rcx
00007d20d97e0b30  pop rax
00007d20d97e0b31  add rsp, 0x08
00007d20d97e0b35  jmp 0x00007D20D97DC685
00007d20d97e0b3a  sub rsp, 0x08
00007d20d97e0b3e  push rax
00007d20d97e0b3f  push rcx
00007d20d97e0b40  push rdx
00007d20d97e0b41  push rdi
00007d20d97e0b42  push rsi
00007d20d97e0b43  push r8
00007d20d97e0b45  push r9
00007d20d97e0b47  push r10
00007d20d97e0b49  push r11
00007d20d97e0b4b  sub rsp, 0xF0
00007d20d97e0b52  vmovaps [rsp], xmm0
00007d20d97e0b57  vmovaps [rsp+0x10], xmm1
00007d20d97e0b5d  vmovaps [rsp+0x20], xmm2
00007d20d97e0b63  vmovaps [rsp+0x30], xmm3
00007d20d97e0b69  vmovaps [rsp+0x40], xmm4
00007d20d97e0b6f  vmovaps [rsp+0x50], xmm5
00007d20d97e0b75  vmovaps [rsp+0x60], xmm6
00007d20d97e0b7b  vmovaps [rsp+0x70], xmm7
00007d20d97e0b81  vmovaps [rsp+0x80], xmm8
00007d20d97e0b8a  vmovaps [rsp+0x90], xmm9
00007d20d97e0b93  vmovaps [rsp+0xA0], xmm10
00007d20d97e0b9c  vmovaps [rsp+0xB0], xmm12
00007d20d97e0ba5  vmovaps [rsp+0xC0], xmm13
00007d20d97e0bae  vmovaps [rsp+0xD0], xmm14
00007d20d97e0bb7  vmovaps [rsp+0xE0], xmm15
00007d20d97e0bc0  sub rsp, 0x30
00007d20d97e0bc4  movaps [rsp], xmm11
00007d20d97e0bc9  movaps [rsp+0x10], xmm10
00007d20d97e0bcf  movaps [rsp+0x20], xmm14
00007d20d97e0bd5  lea rdi, [rsp]
00007d20d97e0bd9  mov esi, 0x00
00007d20d97e0bde  mov rax, 0x5EFBF4CF6530
00007d20d97e0be8  call rax
00007d20d97e0bea  movaps xmm11, [rsp]
00007d20d97e0bef  add rsp, 0x30
00007d20d97e0bf3  vmovaps xmm0, [rsp]
00007d20d97e0bf8  vmovaps xmm1, [rsp+0x10]
00007d20d97e0bfe  vmovaps xmm2, [rsp+0x20]
00007d20d97e0c04  vmovaps xmm3, [rsp+0x30]
00007d20d97e0c0a  vmovaps xmm4, [rsp+0x40]
00007d20d97e0c10  vmovaps xmm5, [rsp+0x50]
00007d20d97e0c16  vmovaps xmm6, [rsp+0x60]
00007d20d97e0c1c  vmovaps xmm7, [rsp+0x70]
00007d20d97e0c22  vmovaps xmm8, [rsp+0x80]
00007d20d97e0c2b  vmovaps xmm9, [rsp+0x90]
00007d20d97e0c34  vmovaps xmm10, [rsp+0xA0]
00007d20d97e0c3d  vmovaps xmm12, [rsp+0xB0]
00007d20d97e0c46  vmovaps xmm13, [rsp+0xC0]
00007d20d97e0c4f  vmovaps xmm14, [rsp+0xD0]
00007d20d97e0c58  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0c61  add rsp, 0xF0
00007d20d97e0c68  pop r11
00007d20d97e0c6a  pop r10
00007d20d97e0c6c  pop r9
00007d20d97e0c6e  pop r8
00007d20d97e0c70  pop rsi
00007d20d97e0c71  pop rdi
00007d20d97e0c72  pop rdx
00007d20d97e0c73  pop rcx
00007d20d97e0c74  pop rax
00007d20d97e0c75  add rsp, 0x08
00007d20d97e0c79  jmp 0x00007D20D97DC6A0
00007d20d97e0c7e  call 0x00007D20D96C33A0
00007d20d97e0c83  jmp 0x00007D20D97DC6AA
00007d20d97e0c88  sub rsp, 0x08
00007d20d97e0c8c  push rax
00007d20d97e0c8d  push rcx
00007d20d97e0c8e  push rdx
00007d20d97e0c8f  push rdi
00007d20d97e0c90  push rsi
00007d20d97e0c91  push r8
00007d20d97e0c93  push r9
00007d20d97e0c95  push r10
00007d20d97e0c97  push r11
00007d20d97e0c99  sub rsp, 0xF0
00007d20d97e0ca0  vmovaps [rsp], xmm0
00007d20d97e0ca5  vmovaps [rsp+0x10], xmm1
00007d20d97e0cab  vmovaps [rsp+0x20], xmm2
00007d20d97e0cb1  vmovaps [rsp+0x30], xmm3
00007d20d97e0cb7  vmovaps [rsp+0x40], xmm4
00007d20d97e0cbd  vmovaps [rsp+0x50], xmm5
00007d20d97e0cc3  vmovaps [rsp+0x60], xmm6
00007d20d97e0cc9  vmovaps [rsp+0x70], xmm7
00007d20d97e0ccf  vmovaps [rsp+0x80], xmm8
00007d20d97e0cd8  vmovaps [rsp+0x90], xmm9
00007d20d97e0ce1  vmovaps [rsp+0xA0], xmm11
00007d20d97e0cea  vmovaps [rsp+0xB0], xmm12
00007d20d97e0cf3  vmovaps [rsp+0xC0], xmm13
00007d20d97e0cfc  vmovaps [rsp+0xD0], xmm14
00007d20d97e0d05  vmovaps [rsp+0xE0], xmm15
00007d20d97e0d0e  sub rsp, 0x30
00007d20d97e0d12  movaps [rsp], xmm10
00007d20d97e0d17  movaps [rsp+0x10], xmm1
00007d20d97e0d1c  movaps [rsp+0x20], xmm12
00007d20d97e0d22  lea rdi, [rsp]
00007d20d97e0d26  mov esi, 0x00
00007d20d97e0d2b  mov rax, 0x5EFBF4CF6530
00007d20d97e0d35  call rax
00007d20d97e0d37  movaps xmm10, [rsp]
00007d20d97e0d3c  add rsp, 0x30
00007d20d97e0d40  vmovaps xmm0, [rsp]
00007d20d97e0d45  vmovaps xmm1, [rsp+0x10]
00007d20d97e0d4b  vmovaps xmm2, [rsp+0x20]
00007d20d97e0d51  vmovaps xmm3, [rsp+0x30]
00007d20d97e0d57  vmovaps xmm4, [rsp+0x40]
00007d20d97e0d5d  vmovaps xmm5, [rsp+0x50]
00007d20d97e0d63  vmovaps xmm6, [rsp+0x60]
00007d20d97e0d69  vmovaps xmm7, [rsp+0x70]
00007d20d97e0d6f  vmovaps xmm8, [rsp+0x80]
00007d20d97e0d78  vmovaps xmm9, [rsp+0x90]
00007d20d97e0d81  vmovaps xmm11, [rsp+0xA0]
00007d20d97e0d8a  vmovaps xmm12, [rsp+0xB0]
00007d20d97e0d93  vmovaps xmm13, [rsp+0xC0]
00007d20d97e0d9c  vmovaps xmm14, [rsp+0xD0]
00007d20d97e0da5  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0dae  add rsp, 0xF0
00007d20d97e0db5  pop r11
00007d20d97e0db7  pop r10
00007d20d97e0db9  pop r9
00007d20d97e0dbb  pop r8
00007d20d97e0dbd  pop rsi
00007d20d97e0dbe  pop rdi
00007d20d97e0dbf  pop rdx
00007d20d97e0dc0  pop rcx
00007d20d97e0dc1  pop rax
00007d20d97e0dc2  add rsp, 0x08
00007d20d97e0dc6  jmp 0x00007D20D97DC6CD
00007d20d97e0dcb  sub rsp, 0x08
00007d20d97e0dcf  push rax
00007d20d97e0dd0  push rcx
00007d20d97e0dd1  push rdx
00007d20d97e0dd2  push rdi
00007d20d97e0dd3  push rsi
00007d20d97e0dd4  push r8
00007d20d97e0dd6  push r9
00007d20d97e0dd8  push r10
00007d20d97e0dda  push r11
00007d20d97e0ddc  sub rsp, 0xF0
00007d20d97e0de3  vmovaps [rsp], xmm0
00007d20d97e0de8  vmovaps [rsp+0x10], xmm1
00007d20d97e0dee  vmovaps [rsp+0x20], xmm2
00007d20d97e0df4  vmovaps [rsp+0x30], xmm3
00007d20d97e0dfa  vmovaps [rsp+0x40], xmm4
00007d20d97e0e00  vmovaps [rsp+0x50], xmm5
00007d20d97e0e06  vmovaps [rsp+0x60], xmm6
00007d20d97e0e0c  vmovaps [rsp+0x70], xmm7
00007d20d97e0e12  vmovaps [rsp+0x80], xmm8
00007d20d97e0e1b  vmovaps [rsp+0x90], xmm9
00007d20d97e0e24  vmovaps [rsp+0xA0], xmm10
00007d20d97e0e2d  vmovaps [rsp+0xB0], xmm11
00007d20d97e0e36  vmovaps [rsp+0xC0], xmm13
00007d20d97e0e3f  vmovaps [rsp+0xD0], xmm14
00007d20d97e0e48  vmovaps [rsp+0xE0], xmm15
00007d20d97e0e51  sub rsp, 0x30
00007d20d97e0e55  movaps [rsp], xmm12
00007d20d97e0e5a  movaps [rsp+0x10], xmm14
00007d20d97e0e60  movaps [rsp+0x20], xmm1
00007d20d97e0e65  lea rdi, [rsp]
00007d20d97e0e69  mov esi, 0x00
00007d20d97e0e6e  mov rax, 0x5EFBF4CF6530
00007d20d97e0e78  call rax
00007d20d97e0e7a  movaps xmm12, [rsp]
00007d20d97e0e7f  add rsp, 0x30
00007d20d97e0e83  vmovaps xmm0, [rsp]
00007d20d97e0e88  vmovaps xmm1, [rsp+0x10]
00007d20d97e0e8e  vmovaps xmm2, [rsp+0x20]
00007d20d97e0e94  vmovaps xmm3, [rsp+0x30]
00007d20d97e0e9a  vmovaps xmm4, [rsp+0x40]
00007d20d97e0ea0  vmovaps xmm5, [rsp+0x50]
00007d20d97e0ea6  vmovaps xmm6, [rsp+0x60]
00007d20d97e0eac  vmovaps xmm7, [rsp+0x70]
00007d20d97e0eb2  vmovaps xmm8, [rsp+0x80]
00007d20d97e0ebb  vmovaps xmm9, [rsp+0x90]
00007d20d97e0ec4  vmovaps xmm10, [rsp+0xA0]
00007d20d97e0ecd  vmovaps xmm11, [rsp+0xB0]
00007d20d97e0ed6  vmovaps xmm13, [rsp+0xC0]
00007d20d97e0edf  vmovaps xmm14, [rsp+0xD0]
00007d20d97e0ee8  vmovaps xmm15, [rsp+0xE0]
00007d20d97e0ef1  add rsp, 0xF0
00007d20d97e0ef8  pop r11
00007d20d97e0efa  pop r10
00007d20d97e0efc  pop r9
00007d20d97e0efe  pop r8
00007d20d97e0f00  pop rsi
00007d20d97e0f01  pop rdi
00007d20d97e0f02  pop rdx
00007d20d97e0f03  pop rcx
00007d20d97e0f04  pop rax
00007d20d97e0f05  add rsp, 0x08
00007d20d97e0f09  jmp 0x00007D20D97DC6FC
00007d20d97e0f0e  sub rsp, 0x08
00007d20d97e0f12  push rax
00007d20d97e0f13  push rcx
00007d20d97e0f14  push rdx
00007d20d97e0f15  push rdi
00007d20d97e0f16  push rsi
00007d20d97e0f17  push r8
00007d20d97e0f19  push r9
00007d20d97e0f1b  push r10
00007d20d97e0f1d  push r11
00007d20d97e0f1f  sub rsp, 0xF0
00007d20d97e0f26  vmovaps [rsp], xmm0
00007d20d97e0f2b  vmovaps [rsp+0x10], xmm1
00007d20d97e0f31  vmovaps [rsp+0x20], xmm2
00007d20d97e0f37  vmovaps [rsp+0x30], xmm3
00007d20d97e0f3d  vmovaps [rsp+0x40], xmm4
00007d20d97e0f43  vmovaps [rsp+0x50], xmm5
00007d20d97e0f49  vmovaps [rsp+0x60], xmm6
00007d20d97e0f4f  vmovaps [rsp+0x70], xmm7
00007d20d97e0f55  vmovaps [rsp+0x80], xmm8
00007d20d97e0f5e  vmovaps [rsp+0x90], xmm9
00007d20d97e0f67  vmovaps [rsp+0xA0], xmm10
00007d20d97e0f70  vmovaps [rsp+0xB0], xmm11
00007d20d97e0f79  vmovaps [rsp+0xC0], xmm12
00007d20d97e0f82  vmovaps [rsp+0xD0], xmm13
00007d20d97e0f8b  vmovaps [rsp+0xE0], xmm15
00007d20d97e0f94  sub rsp, 0x30
00007d20d97e0f98  movaps [rsp], xmm14
00007d20d97e0f9d  movaps [rsp+0x10], xmm9
00007d20d97e0fa3  movaps [rsp+0x20], xmm1
00007d20d97e0fa8  lea rdi, [rsp]
00007d20d97e0fac  mov esi, 0x00
00007d20d97e0fb1  mov rax, 0x5EFBF4CF6530
00007d20d97e0fbb  call rax
00007d20d97e0fbd  movaps xmm14, [rsp]
00007d20d97e0fc2  add rsp, 0x30
00007d20d97e0fc6  vmovaps xmm0, [rsp]
00007d20d97e0fcb  vmovaps xmm1, [rsp+0x10]
00007d20d97e0fd1  vmovaps xmm2, [rsp+0x20]
00007d20d97e0fd7  vmovaps xmm3, [rsp+0x30]
00007d20d97e0fdd  vmovaps xmm4, [rsp+0x40]
00007d20d97e0fe3  vmovaps xmm5, [rsp+0x50]
00007d20d97e0fe9  vmovaps xmm6, [rsp+0x60]
00007d20d97e0fef  vmovaps xmm7, [rsp+0x70]
00007d20d97e0ff5  vmovaps xmm8, [rsp+0x80]
00007d20d97e0ffe  vmovaps xmm9, [rsp+0x90]
00007d20d97e1007  vmovaps xmm10, [rsp+0xA0]
00007d20d97e1010  vmovaps xmm11, [rsp+0xB0]
00007d20d97e1019  vmovaps xmm12, [rsp+0xC0]
00007d20d97e1022  vmovaps xmm13, [rsp+0xD0]
00007d20d97e102b  vmovaps xmm15, [rsp+0xE0]
00007d20d97e1034  add rsp, 0xF0
00007d20d97e103b  pop r11
00007d20d97e103d  pop r10
00007d20d97e103f  pop r9
00007d20d97e1041  pop r8
00007d20d97e1043  pop rsi
00007d20d97e1044  pop rdi
00007d20d97e1045  pop rdx
00007d20d97e1046  pop rcx
00007d20d97e1047  pop rax
00007d20d97e1048  add rsp, 0x08
00007d20d97e104c  jmp 0x00007D20D97DC72B
00007d20d97e1051  sub rsp, 0x08
00007d20d97e1055  push rax
00007d20d97e1056  push rcx
00007d20d97e1057  push rdx
00007d20d97e1058  push rdi
00007d20d97e1059  push rsi
00007d20d97e105a  push r8
00007d20d97e105c  push r9
00007d20d97e105e  push r10
00007d20d97e1060  push r11
00007d20d97e1062  sub rsp, 0xF0
00007d20d97e1069  vmovaps [rsp], xmm0
00007d20d97e106e  vmovaps [rsp+0x10], xmm2
00007d20d97e1074  vmovaps [rsp+0x20], xmm3
00007d20d97e107a  vmovaps [rsp+0x30], xmm4
00007d20d97e1080  vmovaps [rsp+0x40], xmm5
00007d20d97e1086  vmovaps [rsp+0x50], xmm6
00007d20d97e108c  vmovaps [rsp+0x60], xmm7
00007d20d97e1092  vmovaps [rsp+0x70], xmm8
00007d20d97e1098  vmovaps [rsp+0x80], xmm9
00007d20d97e10a1  vmovaps [rsp+0x90], xmm10
00007d20d97e10aa  vmovaps [rsp+0xA0], xmm11
00007d20d97e10b3  vmovaps [rsp+0xB0], xmm12
00007d20d97e10bc  vmovaps [rsp+0xC0], xmm13
00007d20d97e10c5  vmovaps [rsp+0xD0], xmm14
00007d20d97e10ce  vmovaps [rsp+0xE0], xmm15
00007d20d97e10d7  sub rsp, 0x30
00007d20d97e10db  movaps [rsp], xmm1
00007d20d97e10df  movaps [rsp+0x10], xmm13
00007d20d97e10e5  movaps [rsp+0x20], xmm8
00007d20d97e10eb  lea rdi, [rsp]
00007d20d97e10ef  mov esi, 0x00
00007d20d97e10f4  mov rax, 0x5EFBF4CF6530
00007d20d97e10fe  call rax
00007d20d97e1100  movaps xmm1, [rsp]
00007d20d97e1104  add rsp, 0x30
00007d20d97e1108  vmovaps xmm0, [rsp]
00007d20d97e110d  vmovaps xmm2, [rsp+0x10]
00007d20d97e1113  vmovaps xmm3, [rsp+0x20]
00007d20d97e1119  vmovaps xmm4, [rsp+0x30]
00007d20d97e111f  vmovaps xmm5, [rsp+0x40]
00007d20d97e1125  vmovaps xmm6, [rsp+0x50]
00007d20d97e112b  vmovaps xmm7, [rsp+0x60]
00007d20d97e1131  vmovaps xmm8, [rsp+0x70]
00007d20d97e1137  vmovaps xmm9, [rsp+0x80]
00007d20d97e1140  vmovaps xmm10, [rsp+0x90]
00007d20d97e1149  vmovaps xmm11, [rsp+0xA0]
00007d20d97e1152  vmovaps xmm12, [rsp+0xB0]
00007d20d97e115b  vmovaps xmm13, [rsp+0xC0]
00007d20d97e1164  vmovaps xmm14, [rsp+0xD0]
00007d20d97e116d  vmovaps xmm15, [rsp+0xE0]
00007d20d97e1176  add rsp, 0xF0
00007d20d97e117d  pop r11
00007d20d97e117f  pop r10
00007d20d97e1181  pop r9
00007d20d97e1183  pop r8
00007d20d97e1185  pop rsi
00007d20d97e1186  pop rdi
00007d20d97e1187  pop rdx
00007d20d97e1188  pop rcx
00007d20d97e1189  pop rax
00007d20d97e118a  add rsp, 0x08
00007d20d97e118e  jmp 0x00007D20D97DC74D
00007d20d97e1193  call 0x00007D20D960C260
00007d20d97e1198  jmp 0x00007D20D97DC75B
00007d20d97e119d  call 0x00007D20D96BD750
00007d20d97e11a2  jmp 0x00007D20D97DC765
00007d20d97e11a7  sub rsp, 0x08
00007d20d97e11ab  push rax
00007d20d97e11ac  push rcx
00007d20d97e11ad  push rdx
00007d20d97e11ae  push rdi
00007d20d97e11af  push rsi
00007d20d97e11b0  push r8
00007d20d97e11b2  push r9
00007d20d97e11b4  push r10
00007d20d97e11b6  push r11
00007d20d97e11b8  sub rsp, 0xF0
00007d20d97e11bf  vmovaps [rsp], xmm0
00007d20d97e11c4  vmovaps [rsp+0x10], xmm1
00007d20d97e11ca  vmovaps [rsp+0x20], xmm2
00007d20d97e11d0  vmovaps [rsp+0x30], xmm3
00007d20d97e11d6  vmovaps [rsp+0x40], xmm4
00007d20d97e11dc  vmovaps [rsp+0x50], xmm5
00007d20d97e11e2  vmovaps [rsp+0x60], xmm6
00007d20d97e11e8  vmovaps [rsp+0x70], xmm7
00007d20d97e11ee  vmovaps [rsp+0x80], xmm9
00007d20d97e11f7  vmovaps [rsp+0x90], xmm10
00007d20d97e1200  vmovaps [rsp+0xA0], xmm11
00007d20d97e1209  vmovaps [rsp+0xB0], xmm12
00007d20d97e1212  vmovaps [rsp+0xC0], xmm13
00007d20d97e121b  vmovaps [rsp+0xD0], xmm14
00007d20d97e1224  vmovaps [rsp+0xE0], xmm15
00007d20d97e122d  sub rsp, 0x30
00007d20d97e1231  movaps [rsp], xmm8
00007d20d97e1236  movaps [rsp+0x10], xmm15
00007d20d97e123c  movaps [rsp+0x20], xmm7
00007d20d97e1241  lea rdi, [rsp]
00007d20d97e1245  mov esi, 0x00
00007d20d97e124a  mov rax, 0x5EFBF4CF6530
00007d20d97e1254  call rax
00007d20d97e1256  movaps xmm8, [rsp]
00007d20d97e125b  add rsp, 0x30
00007d20d97e125f  vmovaps xmm0, [rsp]
00007d20d97e1264  vmovaps xmm1, [rsp+0x10]
00007d20d97e126a  vmovaps xmm2, [rsp+0x20]
00007d20d97e1270  vmovaps xmm3, [rsp+0x30]
00007d20d97e1276  vmovaps xmm4, [rsp+0x40]
00007d20d97e127c  vmovaps xmm5, [rsp+0x50]
00007d20d97e1282  vmovaps xmm6, [rsp+0x60]
00007d20d97e1288  vmovaps xmm7, [rsp+0x70]
00007d20d97e128e  vmovaps xmm9, [rsp+0x80]
00007d20d97e1297  vmovaps xmm10, [rsp+0x90]
00007d20d97e12a0  vmovaps xmm11, [rsp+0xA0]
00007d20d97e12a9  vmovaps xmm12, [rsp+0xB0]
00007d20d97e12b2  vmovaps xmm13, [rsp+0xC0]
00007d20d97e12bb  vmovaps xmm14, [rsp+0xD0]
00007d20d97e12c4  vmovaps xmm15, [rsp+0xE0]
00007d20d97e12cd  add rsp, 0xF0
00007d20d97e12d4  pop r11
00007d20d97e12d6  pop r10
00007d20d97e12d8  pop r9
00007d20d97e12da  pop r8
00007d20d97e12dc  pop rsi
00007d20d97e12dd  pop rdi
00007d20d97e12de  pop rdx
00007d20d97e12df  pop rcx
00007d20d97e12e0  pop rax
00007d20d97e12e1  add rsp, 0x08
00007d20d97e12e5  jmp 0x00007D20D97DC787
00007d20d97e12ea  sub rsp, 0x08
00007d20d97e12ee  push rax
00007d20d97e12ef  push rcx
00007d20d97e12f0  push rdx
00007d20d97e12f1  push rdi
00007d20d97e12f2  push rsi
00007d20d97e12f3  push r8
00007d20d97e12f5  push r9
00007d20d97e12f7  push r10
00007d20d97e12f9  push r11
00007d20d97e12fb  sub rsp, 0xF0
00007d20d97e1302  vmovaps [rsp], xmm0
00007d20d97e1307  vmovaps [rsp+0x10], xmm1
00007d20d97e130d  vmovaps [rsp+0x20], xmm2
00007d20d97e1313  vmovaps [rsp+0x30], xmm3
00007d20d97e1319  vmovaps [rsp+0x40], xmm4
00007d20d97e131f  vmovaps [rsp+0x50], xmm5
00007d20d97e1325  vmovaps [rsp+0x60], xmm6
00007d20d97e132b  vmovaps [rsp+0x70], xmm8
00007d20d97e1331  vmovaps [rsp+0x80], xmm9
00007d20d97e133a  vmovaps [rsp+0x90], xmm10
00007d20d97e1343  vmovaps [rsp+0xA0], xmm11
00007d20d97e134c  vmovaps [rsp+0xB0], xmm12
00007d20d97e1355  vmovaps [rsp+0xC0], xmm13
00007d20d97e135e  vmovaps [rsp+0xD0], xmm14
00007d20d97e1367  vmovaps [rsp+0xE0], xmm15
00007d20d97e1370  sub rsp, 0x30
00007d20d97e1374  movaps [rsp], xmm7
00007d20d97e1378  movaps [rsp+0x10], xmm9
00007d20d97e137e  movaps [rsp+0x20], xmm15
00007d20d97e1384  lea rdi, [rsp]
00007d20d97e1388  mov esi, 0x00
00007d20d97e138d  mov rax, 0x5EFBF4CF6530
00007d20d97e1397  call rax
00007d20d97e1399  movaps xmm7, [rsp]
00007d20d97e139d  add rsp, 0x30
00007d20d97e13a1  vmovaps xmm0, [rsp]
00007d20d97e13a6  vmovaps xmm1, [rsp+0x10]
00007d20d97e13ac  vmovaps xmm2, [rsp+0x20]
00007d20d97e13b2  vmovaps xmm3, [rsp+0x30]
00007d20d97e13b8  vmovaps xmm4, [rsp+0x40]
00007d20d97e13be  vmovaps xmm5, [rsp+0x50]
00007d20d97e13c4  vmovaps xmm6, [rsp+0x60]
00007d20d97e13ca  vmovaps xmm8, [rsp+0x70]
00007d20d97e13d0  vmovaps xmm9, [rsp+0x80]
00007d20d97e13d9  vmovaps xmm10, [rsp+0x90]
00007d20d97e13e2  vmovaps xmm11, [rsp+0xA0]
00007d20d97e13eb  vmovaps xmm12, [rsp+0xB0]
00007d20d97e13f4  vmovaps xmm13, [rsp+0xC0]
00007d20d97e13fd  vmovaps xmm14, [rsp+0xD0]
00007d20d97e1406  vmovaps xmm15, [rsp+0xE0]
00007d20d97e140f  add rsp, 0xF0
00007d20d97e1416  pop r11
00007d20d97e1418  pop r10
00007d20d97e141a  pop r9
00007d20d97e141c  pop r8
00007d20d97e141e  pop rsi
00007d20d97e141f  pop rdi
00007d20d97e1420  pop rdx
00007d20d97e1421  pop rcx
00007d20d97e1422  pop rax
00007d20d97e1423  add rsp, 0x08
00007d20d97e1427  jmp 0x00007D20D97DC7B4
00007d20d97e142c  sub rsp, 0x08
00007d20d97e1430  push rax
00007d20d97e1431  push rcx
00007d20d97e1432  push rdx
00007d20d97e1433  push rdi
00007d20d97e1434  push rsi
00007d20d97e1435  push r8
00007d20d97e1437  push r9
00007d20d97e1439  push r10
00007d20d97e143b  push r11
00007d20d97e143d  sub rsp, 0xF0
00007d20d97e1444  vmovaps [rsp], xmm0
00007d20d97e1449  vmovaps [rsp+0x10], xmm1
00007d20d97e144f  vmovaps [rsp+0x20], xmm2
00007d20d97e1455  vmovaps [rsp+0x30], xmm3
00007d20d97e145b  vmovaps [rsp+0x40], xmm4
00007d20d97e1461  vmovaps [rsp+0x50], xmm5
00007d20d97e1467  vmovaps [rsp+0x60], xmm6
00007d20d97e146d  vmovaps [rsp+0x70], xmm7
00007d20d97e1473  vmovaps [rsp+0x80], xmm8
00007d20d97e147c  vmovaps [rsp+0x90], xmm10
00007d20d97e1485  vmovaps [rsp+0xA0], xmm11
00007d20d97e148e  vmovaps [rsp+0xB0], xmm12
00007d20d97e1497  vmovaps [rsp+0xC0], xmm13
00007d20d97e14a0  vmovaps [rsp+0xD0], xmm14
00007d20d97e14a9  vmovaps [rsp+0xE0], xmm15
00007d20d97e14b2  sub rsp, 0x30
00007d20d97e14b6  movaps [rsp], xmm9
00007d20d97e14bb  movaps [rsp+0x10], xmm13
00007d20d97e14c1  movaps [rsp+0x20], xmm15
00007d20d97e14c7  lea rdi, [rsp]
00007d20d97e14cb  mov esi, 0x00
00007d20d97e14d0  mov rax, 0x5EFBF4CF6530
00007d20d97e14da  call rax
00007d20d97e14dc  movaps xmm9, [rsp]
00007d20d97e14e1  add rsp, 0x30
00007d20d97e14e5  vmovaps xmm0, [rsp]
00007d20d97e14ea  vmovaps xmm1, [rsp+0x10]
00007d20d97e14f0  vmovaps xmm2, [rsp+0x20]
00007d20d97e14f6  vmovaps xmm3, [rsp+0x30]
00007d20d97e14fc  vmovaps xmm4, [rsp+0x40]
00007d20d97e1502  vmovaps xmm5, [rsp+0x50]
00007d20d97e1508  vmovaps xmm6, [rsp+0x60]
00007d20d97e150e  vmovaps xmm7, [rsp+0x70]
00007d20d97e1514  vmovaps xmm8, [rsp+0x80]
00007d20d97e151d  vmovaps xmm10, [rsp+0x90]
00007d20d97e1526  vmovaps xmm11, [rsp+0xA0]
00007d20d97e152f  vmovaps xmm12, [rsp+0xB0]
00007d20d97e1538  vmovaps xmm13, [rsp+0xC0]
00007d20d97e1541  vmovaps xmm14, [rsp+0xD0]
00007d20d97e154a  vmovaps xmm15, [rsp+0xE0]
00007d20d97e1553  add rsp, 0xF0
00007d20d97e155a  pop r11
00007d20d97e155c  pop r10
00007d20d97e155e  pop r9
00007d20d97e1560  pop r8
00007d20d97e1562  pop rsi
00007d20d97e1563  pop rdi
00007d20d97e1564  pop rdx
00007d20d97e1565  pop rcx
00007d20d97e1566  pop rax
00007d20d97e1567  add rsp, 0x08
00007d20d97e156b  jmp 0x00007D20D97DC7E2
00007d20d97e1570  sub rsp, 0x08
00007d20d97e1574  push rax
00007d20d97e1575  push rcx
00007d20d97e1576  push rdx
00007d20d97e1577  push rdi
00007d20d97e1578  push rsi
00007d20d97e1579  push r8
00007d20d97e157b  push r9
00007d20d97e157d  push r10
00007d20d97e157f  push r11
00007d20d97e1581  sub rsp, 0xF0
00007d20d97e1588  vmovaps [rsp], xmm0
00007d20d97e158d  vmovaps [rsp+0x10], xmm1
00007d20d97e1593  vmovaps [rsp+0x20], xmm2
00007d20d97e1599  vmovaps [rsp+0x30], xmm3
00007d20d97e159f  vmovaps [rsp+0x40], xmm4
00007d20d97e15a5  vmovaps [rsp+0x50], xmm5
00007d20d97e15ab  vmovaps [rsp+0x60], xmm6
00007d20d97e15b1  vmovaps [rsp+0x70], xmm7
00007d20d97e15b7  vmovaps [rsp+0x80], xmm8
00007d20d97e15c0  vmovaps [rsp+0x90], xmm9
00007d20d97e15c9  vmovaps [rsp+0xA0], xmm10
00007d20d97e15d2  vmovaps [rsp+0xB0], xmm11
00007d20d97e15db  vmovaps [rsp+0xC0], xmm12
00007d20d97e15e4  vmovaps [rsp+0xD0], xmm13
00007d20d97e15ed  vmovaps [rsp+0xE0], xmm14
00007d20d97e15f6  sub rsp, 0x30
00007d20d97e15fa  movaps [rsp], xmm15
00007d20d97e15ff  movaps [rsp+0x10], xmm11
00007d20d97e1605  movaps [rsp+0x20], xmm12
00007d20d97e160b  lea rdi, [rsp]
00007d20d97e160f  mov esi, 0x00
00007d20d97e1614  mov rax, 0x5EFBF4CF6530
00007d20d97e161e  call rax
00007d20d97e1620  movaps xmm15, [rsp]
00007d20d97e1625  add rsp, 0x30
00007d20d97e1629  vmovaps xmm0, [rsp]
00007d20d97e162e  vmovaps xmm1, [rsp+0x10]
00007d20d97e1634  vmovaps xmm2, [rsp+0x20]
00007d20d97e163a  vmovaps xmm3, [rsp+0x30]
00007d20d97e1640  vmovaps xmm4, [rsp+0x40]
00007d20d97e1646  vmovaps xmm5, [rsp+0x50]
00007d20d97e164c  vmovaps xmm6, [rsp+0x60]
00007d20d97e1652  vmovaps xmm7, [rsp+0x70]
00007d20d97e1658  vmovaps xmm8, [rsp+0x80]
00007d20d97e1661  vmovaps xmm9, [rsp+0x90]
00007d20d97e166a  vmovaps xmm10, [rsp+0xA0]
00007d20d97e1673  vmovaps xmm11, [rsp+0xB0]
00007d20d97e167c  vmovaps xmm12, [rsp+0xC0]
00007d20d97e1685  vmovaps xmm13, [rsp+0xD0]
00007d20d97e168e  vmovaps xmm14, [rsp+0xE0]
00007d20d97e1697  add rsp, 0xF0
00007d20d97e169e  pop r11
00007d20d97e16a0  pop r10
00007d20d97e16a2  pop r9
00007d20d97e16a4  pop r8
00007d20d97e16a6  pop rsi
00007d20d97e16a7  pop rdi
00007d20d97e16a8  pop rdx
00007d20d97e16a9  pop rcx
00007d20d97e16aa  pop rax
00007d20d97e16ab  add rsp, 0x08
00007d20d97e16af  jmp 0x00007D20D97DC7FD
00007d20d97e16b4  sub rsp, 0x08
00007d20d97e16b8  push rax
00007d20d97e16b9  push rcx
00007d20d97e16ba  push rdx
00007d20d97e16bb  push rdi
00007d20d97e16bc  push rsi
00007d20d97e16bd  push r8
00007d20d97e16bf  push r9
00007d20d97e16c1  push r10
00007d20d97e16c3  push r11
00007d20d97e16c5  sub rsp, 0xF0
00007d20d97e16cc  vmovaps [rsp], xmm0
00007d20d97e16d1  vmovaps [rsp+0x10], xmm1
00007d20d97e16d7  vmovaps [rsp+0x20], xmm2
00007d20d97e16dd  vmovaps [rsp+0x30], xmm3
00007d20d97e16e3  vmovaps [rsp+0x40], xmm4
00007d20d97e16e9  vmovaps [rsp+0x50], xmm5
00007d20d97e16ef  vmovaps [rsp+0x60], xmm6
00007d20d97e16f5  vmovaps [rsp+0x70], xmm7
00007d20d97e16fb  vmovaps [rsp+0x80], xmm8
00007d20d97e1704  vmovaps [rsp+0x90], xmm9
00007d20d97e170d  vmovaps [rsp+0xA0], xmm10
00007d20d97e1716  vmovaps [rsp+0xB0], xmm11
00007d20d97e171f  vmovaps [rsp+0xC0], xmm12
00007d20d97e1728  vmovaps [rsp+0xD0], xmm14
00007d20d97e1731  vmovaps [rsp+0xE0], xmm15
00007d20d97e173a  sub rsp, 0x30
00007d20d97e173e  movaps [rsp], xmm13
00007d20d97e1743  movaps [rsp+0x10], xmm10
00007d20d97e1749  movaps [rsp+0x20], xmm14
00007d20d97e174f  lea rdi, [rsp]
00007d20d97e1753  mov esi, 0x00
00007d20d97e1758  mov rax, 0x5EFBF4CF6530
00007d20d97e1762  call rax
00007d20d97e1764  movaps xmm13, [rsp]
00007d20d97e1769  add rsp, 0x30
00007d20d97e176d  vmovaps xmm0, [rsp]
00007d20d97e1772  vmovaps xmm1, [rsp+0x10]
00007d20d97e1778  vmovaps xmm2, [rsp+0x20]
00007d20d97e177e  vmovaps xmm3, [rsp+0x30]
00007d20d97e1784  vmovaps xmm4, [rsp+0x40]
00007d20d97e178a  vmovaps xmm5, [rsp+0x50]
00007d20d97e1790  vmovaps xmm6, [rsp+0x60]
00007d20d97e1796  vmovaps xmm7, [rsp+0x70]
00007d20d97e179c  vmovaps xmm8, [rsp+0x80]
00007d20d97e17a5  vmovaps xmm9, [rsp+0x90]
00007d20d97e17ae  vmovaps xmm10, [rsp+0xA0]
00007d20d97e17b7  vmovaps xmm11, [rsp+0xB0]
00007d20d97e17c0  vmovaps xmm12, [rsp+0xC0]
00007d20d97e17c9  vmovaps xmm14, [rsp+0xD0]
00007d20d97e17d2  vmovaps xmm15, [rsp+0xE0]
00007d20d97e17db  add rsp, 0xF0
00007d20d97e17e2  pop r11
00007d20d97e17e4  pop r10
00007d20d97e17e6  pop r9
00007d20d97e17e8  pop r8
00007d20d97e17ea  pop rsi
00007d20d97e17eb  pop rdi
00007d20d97e17ec  pop rdx
00007d20d97e17ed  pop rcx
00007d20d97e17ee  pop rax
00007d20d97e17ef  add rsp, 0x08
00007d20d97e17f3  jmp 0x00007D20D97DC820
00007d20d97e17f8  sub rsp, 0x08
00007d20d97e17fc  push rax
00007d20d97e17fd  push rcx
00007d20d97e17fe  push rdx
00007d20d97e17ff  push rdi
00007d20d97e1800  push rsi
00007d20d97e1801  push r8
00007d20d97e1803  push r9
00007d20d97e1805  push r10
00007d20d97e1807  push r11
00007d20d97e1809  sub rsp, 0xF0
00007d20d97e1810  vmovaps [rsp], xmm0
00007d20d97e1815  vmovaps [rsp+0x10], xmm1
00007d20d97e181b  vmovaps [rsp+0x20], xmm2
00007d20d97e1821  vmovaps [rsp+0x30], xmm3
00007d20d97e1827  vmovaps [rsp+0x40], xmm4
00007d20d97e182d  vmovaps [rsp+0x50], xmm5
00007d20d97e1833  vmovaps [rsp+0x60], xmm6
00007d20d97e1839  vmovaps [rsp+0x70], xmm7
00007d20d97e183f  vmovaps [rsp+0x80], xmm8
00007d20d97e1848  vmovaps [rsp+0x90], xmm9
00007d20d97e1851  vmovaps [rsp+0xA0], xmm10
00007d20d97e185a  vmovaps [rsp+0xB0], xmm11
00007d20d97e1863  vmovaps [rsp+0xC0], xmm12
00007d20d97e186c  vmovaps [rsp+0xD0], xmm13
00007d20d97e1875  vmovaps [rsp+0xE0], xmm15
00007d20d97e187e  sub rsp, 0x30
00007d20d97e1882  movaps [rsp], xmm14
00007d20d97e1887  movaps [rsp+0x10], xmm1
00007d20d97e188c  movaps [rsp+0x20], xmm7
00007d20d97e1891  lea rdi, [rsp]
00007d20d97e1895  mov esi, 0x00
00007d20d97e189a  mov rax, 0x5EFBF4CF6530
00007d20d97e18a4  call rax
00007d20d97e18a6  movaps xmm14, [rsp]
00007d20d97e18ab  add rsp, 0x30
00007d20d97e18af  vmovaps xmm0, [rsp]
00007d20d97e18b4  vmovaps xmm1, [rsp+0x10]
00007d20d97e18ba  vmovaps xmm2, [rsp+0x20]
00007d20d97e18c0  vmovaps xmm3, [rsp+0x30]
00007d20d97e18c6  vmovaps xmm4, [rsp+0x40]
00007d20d97e18cc  vmovaps xmm5, [rsp+0x50]
00007d20d97e18d2  vmovaps xmm6, [rsp+0x60]
00007d20d97e18d8  vmovaps xmm7, [rsp+0x70]
00007d20d97e18de  vmovaps xmm8, [rsp+0x80]
00007d20d97e18e7  vmovaps xmm9, [rsp+0x90]
00007d20d97e18f0  vmovaps xmm10, [rsp+0xA0]
00007d20d97e18f9  vmovaps xmm11, [rsp+0xB0]
00007d20d97e1902  vmovaps xmm12, [rsp+0xC0]
00007d20d97e190b  vmovaps xmm13, [rsp+0xD0]
00007d20d97e1914  vmovaps xmm15, [rsp+0xE0]
00007d20d97e191d  add rsp, 0xF0
00007d20d97e1924  pop r11
00007d20d97e1926  pop r10
00007d20d97e1928  pop r9
00007d20d97e192a  pop r8
00007d20d97e192c  pop rsi
00007d20d97e192d  pop rdi
00007d20d97e192e  pop rdx
00007d20d97e192f  pop rcx
00007d20d97e1930  pop rax
00007d20d97e1931  add rsp, 0x08
00007d20d97e1935  jmp 0x00007D20D97DC843
00007d20d97e193a  sub rsp, 0x08
00007d20d97e193e  push rax
00007d20d97e193f  push rcx
00007d20d97e1940  push rdx
00007d20d97e1941  push rdi
00007d20d97e1942  push rsi
00007d20d97e1943  push r8
00007d20d97e1945  push r9
00007d20d97e1947  push r10
00007d20d97e1949  push r11
00007d20d97e194b  sub rsp, 0xF0
00007d20d97e1952  vmovaps [rsp], xmm0
00007d20d97e1957  vmovaps [rsp+0x10], xmm2
00007d20d97e195d  vmovaps [rsp+0x20], xmm3
00007d20d97e1963  vmovaps [rsp+0x30], xmm4
00007d20d97e1969  vmovaps [rsp+0x40], xmm5
00007d20d97e196f  vmovaps [rsp+0x50], xmm6
00007d20d97e1975  vmovaps [rsp+0x60], xmm7
00007d20d97e197b  vmovaps [rsp+0x70], xmm8
00007d20d97e1981  vmovaps [rsp+0x80], xmm9
00007d20d97e198a  vmovaps [rsp+0x90], xmm10
00007d20d97e1993  vmovaps [rsp+0xA0], xmm11
00007d20d97e199c  vmovaps [rsp+0xB0], xmm12
00007d20d97e19a5  vmovaps [rsp+0xC0], xmm13
00007d20d97e19ae  vmovaps [rsp+0xD0], xmm14
00007d20d97e19b7  vmovaps [rsp+0xE0], xmm15
00007d20d97e19c0  sub rsp, 0x30
00007d20d97e19c4  movaps [rsp], xmm1
00007d20d97e19c8  movaps [rsp+0x10], xmm8
00007d20d97e19ce  movaps [rsp+0x20], xmm9
00007d20d97e19d4  lea rdi, [rsp]
00007d20d97e19d8  mov esi, 0x00
00007d20d97e19dd  mov rax, 0x5EFBF4CF6530
00007d20d97e19e7  call rax
00007d20d97e19e9  movaps xmm1, [rsp]
00007d20d97e19ed  add rsp, 0x30
00007d20d97e19f1  vmovaps xmm0, [rsp]
00007d20d97e19f6  vmovaps xmm2, [rsp+0x10]
00007d20d97e19fc  vmovaps xmm3, [rsp+0x20]
00007d20d97e1a02  vmovaps xmm4, [rsp+0x30]
00007d20d97e1a08  vmovaps xmm5, [rsp+0x40]
00007d20d97e1a0e  vmovaps xmm6, [rsp+0x50]
00007d20d97e1a14  vmovaps xmm7, [rsp+0x60]
00007d20d97e1a1a  vmovaps xmm8, [rsp+0x70]
00007d20d97e1a20  vmovaps xmm9, [rsp+0x80]
00007d20d97e1a29  vmovaps xmm10, [rsp+0x90]
00007d20d97e1a32  vmovaps xmm11, [rsp+0xA0]
00007d20d97e1a3b  vmovaps xmm12, [rsp+0xB0]
00007d20d97e1a44  vmovaps xmm13, [rsp+0xC0]
00007d20d97e1a4d  vmovaps xmm14, [rsp+0xD0]
00007d20d97e1a56  vmovaps xmm15, [rsp+0xE0]
00007d20d97e1a5f  add rsp, 0xF0
00007d20d97e1a66  pop r11
00007d20d97e1a68  pop r10
00007d20d97e1a6a  pop r9
00007d20d97e1a6c  pop r8
00007d20d97e1a6e  pop rsi
00007d20d97e1a6f  pop rdi
00007d20d97e1a70  pop rdx
00007d20d97e1a71  pop rcx
00007d20d97e1a72  pop rax
00007d20d97e1a73  add rsp, 0x08
00007d20d97e1a77  jmp 0x00007D20D97DC865
00007d20d97e1a7c  call 0x00007D20D96E5940
00007d20d97e1a81  jmp 0x00007D20D97DC873
00007d20d97e1a86  call 0x00007D20D960C380
00007d20d97e1a8b  jmp 0x00007D20D97DC87D
00007d20d97e1a90  call 0x00007D20D960D600
00007d20d97e1a95  jmp 0x00007D20D97DC887
00007d20d97e1a9a  call 0x00007D20D95FF540
00007d20d97e1a9f  jmp 0x00007D20D97DC891
00007d20d97e1aa4  int3
00007d20d97e1aa5  nop [rax+rax*1], ax
00007d20d97e1aae  nop
00007d20d97e1ab0  mov rax, [r15+0xF8]
00007d20d97e1ab7  lea r14, [rax+0x140]
00007d20d97e1abe  mov r12, [r13+r14*1]
00007d20d97e1ac3  mov [r15+0xE8], r12
00007d20d97e1aca  lea r14, [rax+0x130]
00007d20d97e1ad1  mov r12, [r13+r14*1]
00007d20d97e1ad6  lea r14, [rax+0x138]
00007d20d97e1add  mov r11, [r13+r14*1]
00007d20d97e1ae2  movq xmm1, r12
00007d20d97e1ae7  movq xmm15, r11
00007d20d97e1aec  movq xmm1, xmm1
00007d20d97e1af0  movq xmm1, xmm1
00007d20d97e1af4  movaps [r15+0x1A0], xmm1
00007d20d97e1afc  movq xmm15, xmm15
00007d20d97e1b01  movq xmm15, xmm15
00007d20d97e1b06  movaps [r15+0x190], xmm15
00007d20d97e1b0e  lea r14, [rax+0x120]
00007d20d97e1b15  mov r12, [r13+r14*1]
00007d20d97e1b1a  lea r14, [rax+0x128]
00007d20d97e1b21  mov r11, [r13+r14*1]
00007d20d97e1b26  movq xmm1, r12
00007d20d97e1b2b  movq xmm15, r11
00007d20d97e1b30  movq xmm1, xmm1
00007d20d97e1b34  movq xmm1, xmm1
00007d20d97e1b38  movaps [r15+0x1C0], xmm1
00007d20d97e1b40  movq xmm15, xmm15
00007d20d97e1b45  movq xmm15, xmm15
00007d20d97e1b4a  movaps [r15+0x1B0], xmm15
00007d20d97e1b52  lea r14, [rax+0x110]
00007d20d97e1b59  mov r12, [r13+r14*1]
00007d20d97e1b5e  lea r14, [rax+0x118]
00007d20d97e1b65  mov r11, [r13+r14*1]
00007d20d97e1b6a  movq xmm1, r12
00007d20d97e1b6f  movq xmm15, r11
00007d20d97e1b74  movq xmm1, xmm1
00007d20d97e1b78  movq xmm1, xmm1
00007d20d97e1b7c  movaps [r15+0x1E0], xmm1
00007d20d97e1b84  movq xmm15, xmm15
00007d20d97e1b89  movq xmm15, xmm15
00007d20d97e1b8e  movaps [r15+0x1D0], xmm15
00007d20d97e1b96  lea r14, [rax+0x100]
00007d20d97e1b9d  mov r12, [r13+r14*1]
00007d20d97e1ba2  lea r14, [rax+0x108]
00007d20d97e1ba9  mov r11, [r13+r14*1]
00007d20d97e1bae  movq xmm1, r12
00007d20d97e1bb3  movq xmm15, r11
00007d20d97e1bb8  movq xmm1, xmm1
00007d20d97e1bbc  movq xmm1, xmm1
00007d20d97e1bc0  movaps [r15+0x200], xmm1
00007d20d97e1bc8  movq xmm15, xmm15
00007d20d97e1bcd  movq xmm15, xmm15
00007d20d97e1bd2  movaps [r15+0x1F0], xmm15
00007d20d97e1bda  mov qword ptr [r15+0x40], 0x430000
00007d20d97e1be2  mov r14d, 0x430510
00007d20d97e1be8  mov r12, [r13+r14*1]
00007d20d97e1bed  movq xmm1, r12
00007d20d97e1bf2  lea r14, [rax+0x150]
00007d20d97e1bf9  mov [r15+0xF8], r14
00007d20d97e1c00  mov rax, [r15+0x50]
00007d20d97e1c04  movups xmm15, [r13+rax*1]
00007d20d97e1c0a  movaps [r15+0x120], xmm15
00007d20d97e1c12  mov qword ptr [r15+0x48], 0x10
00007d20d97e1c1a  xor eax, eax
00007d20d97e1c1c  mov r14d, 0x10
00007d20d97e1c22  mov r12d, 0x200
00007d20d97e1c28  cmp r14, r12
00007d20d97e1c2b  cmc
00007d20d97e1c2c  lahf
00007d20d97e1c2d  seto al
00007d20d97e1c30  mov [r15+0x108], eax
00007d20d97e1c37  pextrq rax, xmm15, 0x01
00007d20d97e1c3e  movq xmm14, rax
00007d20d97e1c43  movaps [r15+0x130], xmm14
00007d20d97e1c4b  movq rax, xmm1
00007d20d97e1c50  movq r14, xmm15
00007d20d97e1c55  vmovq xmm1, rax
00007d20d97e1c5a  vmovq xmm15, r14
00007d20d97e1c5f  movaps xmm13, xmm1
00007d20d97e1c63  addsd xmm13, xmm15
00007d20d97e1c68  ucomisd xmm13, xmm13
00007d20d97e1c6d  jp 0x00007D20D97E1D86
00007d20d97e1c73  movq xmm13, xmm13
00007d20d97e1c78  movq rax, xmm13
00007d20d97e1c7d  movq r14, xmm14
00007d20d97e1c82  vmovq xmm1, rax
00007d20d97e1c87  vmovq xmm15, r14
00007d20d97e1c8c  movaps xmm14, xmm1
00007d20d97e1c90  addsd xmm14, xmm15
00007d20d97e1c95  ucomisd xmm14, xmm14
00007d20d97e1c9a  jp 0x00007D20D97E1DCE
00007d20d97e1ca0  movq xmm14, xmm14
00007d20d97e1ca5  movaps [r15+0x110], xmm14
00007d20d97e1cad  mov eax, [r15+0x108]
00007d20d97e1cb4  sahf
00007d20d97e1cb5  jnz 0x00007D20D97E1CE7
00007d20d97e1cb7  cmp dword ptr [r15+0x318], 0x00
00007d20d97e1cbf  jz 0x00007D20D97E1FE0
00007d20d97e1cc5  nop [rax+rax*1], ax
00007d20d97e1cce  nop [rax+rax*1], eax
00007d20d97e1cd6  mov eax, 0x410490
00007d20d97e1cdb  mov [r15+0x100], rax
00007d20d97e1ce2  jmp 0x00007D20D95FE110
00007d20d97e1ce7  cmp dword ptr [r15+0x318], 0x00
00007d20d97e1cef  jz 0x00007D20D97E1E20
00007d20d97e1cf5  nop [rax+rax*1], ax
00007d20d97e1cfe  nop [rax+rax*1], eax
00007d20d97e1d06  mov eax, 0x410474
00007d20d97e1d0b  mov [r15+0x100], rax
00007d20d97e1d12  jmp 0x00007D20D95FE110
00007d20d97e1d17  int3
00007d20d97e1d18  call 0x00007D20D96E27E0
00007d20d97e1d1d  jmp 0x00007D20D97E1AC3
00007d20d97e1d22  call 0x00007D20D96E27E0
00007d20d97e1d27  jmp 0x00007D20D97E1AD6
00007d20d97e1d2c  call 0x00007D20D96E1570
00007d20d97e1d31  jmp 0x00007D20D97E1AE2
00007d20d97e1d36  call 0x00007D20D96E27E0
00007d20d97e1d3b  jmp 0x00007D20D97E1B1A
00007d20d97e1d40  call 0x00007D20D96E1570
00007d20d97e1d45  jmp 0x00007D20D97E1B26
00007d20d97e1d4a  call 0x00007D20D96E27E0
00007d20d97e1d4f  jmp 0x00007D20D97E1B5E
00007d20d97e1d54  call 0x00007D20D96E1570
00007d20d97e1d59  jmp 0x00007D20D97E1B6A
00007d20d97e1d5e  call 0x00007D20D96E27E0
00007d20d97e1d63  jmp 0x00007D20D97E1BA2
00007d20d97e1d68  call 0x00007D20D96E1570
00007d20d97e1d6d  jmp 0x00007D20D97E1BAE
00007d20d97e1d72  call 0x00007D20D96E27E0
00007d20d97e1d77  jmp 0x00007D20D97E1BED
00007d20d97e1d7c  call 0x00007D20D960E760
00007d20d97e1d81  jmp 0x00007D20D97E1C0A
00007d20d97e1d86  ucomisd xmm1, xmm15
00007d20d97e1d8b  jp 0x00007D20D97E1D9A
00007d20d97e1d8d  movaps xmm13, [0x00007D20D93FE060]
00007d20d97e1d95  jmp 0x00007D20D97E1C73
00007d20d97e1d9a  vxorps xmm0, xmm1, xmm15
00007d20d97e1d9f  pextrw eax, xmm0, 0x03
00007d20d97e1da4  and eax, 0x7FF8
00007d20d97e1da9  cmp eax, 0x08
00007d20d97e1dac  jnz 0x00007D20D97E1C73
00007d20d97e1db2  movq rax, xmm15
00007d20d97e1db7  shl rax, 0x0D
00007d20d97e1dbb  jbe 0x00007D20D97E1C73
00007d20d97e1dc1  vorps xmm13, xmm15, [0x00007D20D93FE070]
00007d20d97e1dc9  jmp 0x00007D20D97E1C73
00007d20d97e1dce  ucomisd xmm1, xmm15
00007d20d97e1dd3  jp 0x00007D20D97E1DE2
00007d20d97e1dd5  movaps xmm14, [0x00007D20D93FE060]
00007d20d97e1ddd  jmp 0x00007D20D97E1CA0
00007d20d97e1de2  vxorps xmm0, xmm1, xmm15
00007d20d97e1de7  pextrw eax, xmm0, 0x03
00007d20d97e1dec  and eax, 0x7FF8
00007d20d97e1df1  cmp eax, 0x08
00007d20d97e1df4  jnz 0x00007D20D97E1CA0
00007d20d97e1dfa  movq rax, xmm15
00007d20d97e1dff  shl rax, 0x0D
00007d20d97e1e03  jbe 0x00007D20D97E1CA0
00007d20d97e1e09  vorps xmm14, xmm15, [0x00007D20D93FE070]
00007d20d97e1e11  jmp 0x00007D20D97E1CA0
00007d20d97e1e16  int3
00007d20d97e1e17  nop [rax+rax*1], ax
00007d20d97e1e20  mov rax, [r15+0x48]
00007d20d97e1e24  mov r14, [r15+0x50]
00007d20d97e1e28  lea r12, [r14+rax*1]
00007d20d97e1e2c  movups xmm1, [r13+r12*1]
00007d20d97e1e32  movaps [r15+0x120], xmm1
00007d20d97e1e3a  lea r14, [rax+0x10]
00007d20d97e1e3e  mov [r15+0x48], r14
00007d20d97e1e42  xor eax, eax
00007d20d97e1e44  mov r12d, 0x200
00007d20d97e1e4a  cmp r14, r12
00007d20d97e1e4d  cmc
00007d20d97e1e4e  lahf
00007d20d97e1e4f  seto al
00007d20d97e1e52  mov [r15+0x108], eax
00007d20d97e1e59  pextrq rax, xmm1, 0x01
00007d20d97e1e60  movq xmm15, rax
00007d20d97e1e65  movaps [r15+0x130], xmm15
00007d20d97e1e6d  movaps xmm14, [r15+0x110]
00007d20d97e1e75  movq rax, xmm14
00007d20d97e1e7a  movq r14, xmm1
00007d20d97e1e7f  vmovq xmm1, rax
00007d20d97e1e84  vmovq xmm14, r14
00007d20d97e1e89  movaps xmm13, xmm1
00007d20d97e1e8d  addsd xmm13, xmm14
00007d20d97e1e92  ucomisd xmm13, xmm13
00007d20d97e1e97  jp 0x00007D20D97E1F4C
00007d20d97e1e9d  movq xmm13, xmm13
00007d20d97e1ea2  movq rax, xmm13
00007d20d97e1ea7  movq r14, xmm15
00007d20d97e1eac  vmovq xmm1, rax
00007d20d97e1eb1  vmovq xmm15, r14
00007d20d97e1eb6  movaps xmm14, xmm1
00007d20d97e1eba  addsd xmm14, xmm15
00007d20d97e1ebf  ucomisd xmm14, xmm14
00007d20d97e1ec4  jp 0x00007D20D97E1F94
00007d20d97e1eca  movq xmm14, xmm14
00007d20d97e1ecf  movaps [r15+0x110], xmm14
00007d20d97e1ed7  mov eax, [r15+0x108]
00007d20d97e1ede  sahf
00007d20d97e1edf  jnz 0x00007D20D97E1F11
00007d20d97e1ee1  cmp dword ptr [r15+0x318], 0x00
00007d20d97e1ee9  jz 0x00007D20D97E1FE0
00007d20d97e1eef  nop [rax+rax*1], ax
00007d20d97e1ef8  nop [rax+rax*1], eax
00007d20d97e1f00  mov eax, 0x410490
00007d20d97e1f05  mov [r15+0x100], rax
00007d20d97e1f0c  jmp 0x00007D20D95FE110
00007d20d97e1f11  cmp dword ptr [r15+0x318], 0x00
00007d20d97e1f19  jz 0x00007D20D97E1E20
00007d20d97e1f1f  nop [rax+rax*1], ax
00007d20d97e1f28  nop [rax+rax*1], eax
00007d20d97e1f30  mov eax, 0x410474
00007d20d97e1f35  mov [r15+0x100], rax
00007d20d97e1f3c  jmp 0x00007D20D95FE110
00007d20d97e1f41  int3
00007d20d97e1f42  call 0x00007D20D96B52F0
00007d20d97e1f47  jmp 0x00007D20D97E1E32
00007d20d97e1f4c  ucomisd xmm1, xmm14
00007d20d97e1f51  jp 0x00007D20D97E1F60
00007d20d97e1f53  movaps xmm13, [0x00007D20D93FE060]
00007d20d97e1f5b  jmp 0x00007D20D97E1E9D
00007d20d97e1f60  vxorps xmm0, xmm1, xmm14
00007d20d97e1f65  pextrw eax, xmm0, 0x03
00007d20d97e1f6a  and eax, 0x7FF8
00007d20d97e1f6f  cmp eax, 0x08
00007d20d97e1f72  jnz 0x00007D20D97E1E9D
00007d20d97e1f78  movq rax, xmm14
00007d20d97e1f7d  shl rax, 0x0D
00007d20d97e1f81  jbe 0x00007D20D97E1E9D
00007d20d97e1f87  vorps xmm13, xmm14, [0x00007D20D93FE070]
00007d20d97e1f8f  jmp 0x00007D20D97E1E9D
00007d20d97e1f94  ucomisd xmm1, xmm15
00007d20d97e1f99  jp 0x00007D20D97E1FA8
00007d20d97e1f9b  movaps xmm14, [0x00007D20D93FE060]
00007d20d97e1fa3  jmp 0x00007D20D97E1ECA
00007d20d97e1fa8  vxorps xmm0, xmm1, xmm15
00007d20d97e1fad  pextrw eax, xmm0, 0x03
00007d20d97e1fb2  and eax, 0x7FF8
00007d20d97e1fb7  cmp eax, 0x08
00007d20d97e1fba  jnz 0x00007D20D97E1ECA
00007d20d97e1fc0  movq rax, xmm15
00007d20d97e1fc5  shl rax, 0x0D
00007d20d97e1fc9  jbe 0x00007D20D97E1ECA
00007d20d97e1fcf  vorps xmm14, xmm15, [0x00007D20D93FE070]
00007d20d97e1fd7  jmp 0x00007D20D97E1ECA
00007d20d97e1fdc  int3
00007d20d97e1fdd  nop [rax], eax
00007d20d97e1fe0  mov rax, [r15+0x40]
00007d20d97e1fe4  lea r14, [rax+0x510]
00007d20d97e1feb  movaps xmm1, [r15+0x110]
00007d20d97e1ff3  movq rax, xmm1
00007d20d97e1ff8  mov [r13+r14*1], rax
00007d20d97e1ffd  mov rax, [r15+0xF0]
00007d20d97e2004  mov [r15+0x100], rax
00007d20d97e200b  jmp 0x00007D20D97CE5C0
00007d20d97e2010  int3
00007d20d97e2011  call 0x00007D20D96D5EB0
00007d20d97e2016  jmp 0x00007D20D97E1FFD
00007d20d97e201b  int3
00007d20d97e201c  nop [rax], eax
00007d20d97e2020  mov qword ptr [r15+0x100], 0x04
00007d20d97e202b  mov esi, 0x00
00007d20d97e2030  mov edx, 0x09
00007d20d97e2035  mov rdi, 0x7FFED1FEF980
00007d20d97e203f  mov rax, 0x5EFBF4B89970
00007d20d97e2049  call rax
00007d20d97e204b  cmp dword ptr [r15+0x318], 0x00
00007d20d97e2053  jnz 0x00007D20D95FE110
00007d20d97e2059  jmp 0x00007D20D95FE0A0
00007d20d97e205e  int3
00007d20d97e205f  int3
