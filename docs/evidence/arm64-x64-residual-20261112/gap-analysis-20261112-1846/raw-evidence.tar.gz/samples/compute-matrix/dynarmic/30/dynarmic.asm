00007e4ecadce69b  nop [rax+rax*1], eax
00007e4ecadce6a0  vmovaps xmm1, [0x00007E4ECA9FE010]
00007e4ecadce6a8  movq xmm1, xmm1
00007e4ecadce6ac  movaps [r15+0x110], xmm1
00007e4ecadce6b4  vmovaps xmm1, [0x00007E4ECA9FE020]
00007e4ecadce6bc  movq xmm1, xmm1
00007e4ecadce6c0  movaps [r15+0x120], xmm1
00007e4ecadce6c8  mov eax, 0x4204C0
00007e4ecadce6cd  mov r14, [r13+rax*1]
00007e4ecadce6d2  movq xmm1, r14
00007e4ecadce6d7  movaps [r15+0x130], xmm1
00007e4ecadce6df  vmovaps xmm1, [0x00007E4ECA9FE030]
00007e4ecadce6e7  vpbroadcastq xmm1, xmm1
00007e4ecadce6ec  movaps [r15+0x140], xmm1
00007e4ecadce6f4  mov qword ptr [r15+0x40], 0x02
00007e4ecadce6fc  vmovaps xmm15, [0x00007E4ECA9FE040]
00007e4ecadce704  movq xmm15, xmm15
00007e4ecadce709  movaps [r15+0x150], xmm15
00007e4ecadce711  mov qword ptr [r15+0x58], 0x420000
00007e4ecadce719  vmovaps xmm15, [0x00007E4ECA9FE050]
00007e4ecadce721  vpbroadcastq xmm15, xmm15
00007e4ecadce726  movaps [r15+0x160], xmm15
00007e4ecadce72e  mov rax, [r15+0x40]
00007e4ecadce732  vmovq xmm14, rax
00007e4ecadce737  vpbroadcastq xmm14, xmm14
00007e4ecadce73c  movaps [r15+0x170], xmm14
00007e4ecadce744  mov eax, 0x4204D0
00007e4ecadce749  movups xmm13, [r13+rax*1]
00007e4ecadce74f  mov qword ptr [r15+0x40], 0x430518
00007e4ecadce757  mov qword ptr [r15+0x50], 0x430720
00007e4ecadce75f  vpmovqd xmm12, xmm13
00007e4ecadce765  pxor xmm11, xmm11
00007e4ecadce76a  punpcklqdq xmm12, xmm11
00007e4ecadce76f  movaps [r15+0x210], xmm12
00007e4ecadce777  movq xmm12, qword ptr [r15+0x120]
00007e4ecadce780  movq xmm11, qword ptr [r15+0x130]
00007e4ecadce789  psubd xmm12, xmm11
00007e4ecadce78e  movq xmm12, xmm12
00007e4ecadce793  paddq xmm13, xmm14
00007e4ecadce798  movaps [r15+0x180], xmm13
00007e4ecadce7a0  movq xmm14, qword ptr [r15+0x150]
00007e4ecadce7a9  paddd xmm11, xmm14
00007e4ecadce7ae  movq xmm11, xmm11
00007e4ecadce7b3  movq xmm11, xmm11
00007e4ecadce7b8  movaps [r15+0x130], xmm11
00007e4ecadce7c0  pmovzxdq xmm12, xmm12
00007e4ecadce7c6  psllq xmm12, 0x00
00007e4ecadce7cc  movq xmm14, qword ptr [r15+0x210]
00007e4ecadce7d5  movq xmm13, qword ptr [r15+0x110]
00007e4ecadce7de  paddd xmm14, xmm13
00007e4ecadce7e3  movq xmm14, xmm14
00007e4ecadce7e8  vcvtuqq2pd xmm12, xmm12
00007e4ecadce7ee  pmovzxdq xmm14, xmm14
00007e4ecadce7f4  psllq xmm14, 0x00
00007e4ecadce7fa  vcvtuqq2pd xmm14, xmm14
00007e4ecadce800  movaps xmm13, xmm12
00007e4ecadce804  mulpd xmm13, xmm1
00007e4ecadce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007e4ecadce80f  ptest xmm11, xmm11
00007e4ecadce815  jnz 0x00007E4ECADCE8FF
00007e4ecadce81b  movaps [r15+0x220], xmm13
00007e4ecadce823  mov eax, 0x430720
00007e4ecadce828  movups [r13+rax*1], xmm13
00007e4ecadce82e  movaps xmm1, xmm14
00007e4ecadce832  mulpd xmm1, xmm15
00007e4ecadce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007e4ecadce83c  ptest xmm13, xmm13
00007e4ecadce842  jnz 0x00007E4ECADCEA4C
00007e4ecadce848  movaps [r15+0x210], xmm1
00007e4ecadce850  mov eax, 0x430518
00007e4ecadce855  movups [r13+rax*1], xmm1
00007e4ecadce85b  mov qword ptr [r15+0x48], 0x10
00007e4ecadce863  xor eax, eax
00007e4ecadce865  mov r14d, 0x10
00007e4ecadce86b  mov r12d, 0x200
00007e4ecadce871  cmp r14, r12
00007e4ecadce874  cmc
00007e4ecadce875  lahf
00007e4ecadce876  seto al
00007e4ecadce879  mov [r15+0x108], eax
00007e4ecadce880  mov eax, [r15+0x108]
00007e4ecadce887  sahf
00007e4ecadce888  jnz 0x00007E4ECADCE8BA
00007e4ecadce88a  cmp dword ptr [r15+0x318], 0x00
00007e4ecadce892  jz 0x00007E4ECADCEFF0
00007e4ecadce898  nop [rax+rax*1], ax
00007e4ecadce8a1  nop [rax+rax*1], eax
00007e4ecadce8a9  mov eax, 0x4101EC
00007e4ecadce8ae  mov [r15+0x100], rax
00007e4ecadce8b5  jmp 0x00007E4ECABFE110
00007e4ecadce8ba  cmp dword ptr [r15+0x318], 0x00
00007e4ecadce8c2  jz 0x00007E4ECADCEBA0
00007e4ecadce8c8  nop [rax+rax*1], ax
00007e4ecadce8d1  nop [rax+rax*1], eax
00007e4ecadce8d9  mov eax, 0x4101AC
00007e4ecadce8de  mov [r15+0x100], rax
00007e4ecadce8e5  jmp 0x00007E4ECABFE110
00007e4ecadce8ea  int3
00007e4ecadce8eb  call 0x00007E4ECAC0DC20
00007e4ecadce8f0  jmp 0x00007E4ECADCE6D2
00007e4ecadce8f5  call 0x00007E4ECAC0C260
00007e4ecadce8fa  jmp 0x00007E4ECADCE74F
00007e4ecadce8ff  sub rsp, 0x08
00007e4ecadce903  push rax
00007e4ecadce904  push rcx
00007e4ecadce905  push rdx
00007e4ecadce906  push rdi
00007e4ecadce907  push rsi
00007e4ecadce908  push r8
00007e4ecadce90a  push r9
00007e4ecadce90c  push r10
00007e4ecadce90e  push r11
00007e4ecadce910  sub rsp, 0xF0
00007e4ecadce917  vmovaps [rsp], xmm0
00007e4ecadce91c  vmovaps [rsp+0x10], xmm1
00007e4ecadce922  vmovaps [rsp+0x20], xmm2
00007e4ecadce928  vmovaps [rsp+0x30], xmm3
00007e4ecadce92e  vmovaps [rsp+0x40], xmm4
00007e4ecadce934  vmovaps [rsp+0x50], xmm5
00007e4ecadce93a  vmovaps [rsp+0x60], xmm6
00007e4ecadce940  vmovaps [rsp+0x70], xmm7
00007e4ecadce946  vmovaps [rsp+0x80], xmm8
00007e4ecadce94f  vmovaps [rsp+0x90], xmm9
00007e4ecadce958  vmovaps [rsp+0xA0], xmm10
00007e4ecadce961  vmovaps [rsp+0xB0], xmm11
00007e4ecadce96a  vmovaps [rsp+0xC0], xmm12
00007e4ecadce973  vmovaps [rsp+0xD0], xmm14
00007e4ecadce97c  vmovaps [rsp+0xE0], xmm15
00007e4ecadce985  sub rsp, 0x30
00007e4ecadce989  movaps [rsp], xmm13
00007e4ecadce98e  movaps [rsp+0x10], xmm12
00007e4ecadce994  movaps [rsp+0x20], xmm1
00007e4ecadce999  lea rdi, [rsp]
00007e4ecadce99d  mov esi, 0x00
00007e4ecadce9a2  mov rax, 0x5784BC1F5530
00007e4ecadce9ac  call rax
00007e4ecadce9ae  movaps xmm13, [rsp]
00007e4ecadce9b3  add rsp, 0x30
00007e4ecadce9b7  vmovaps xmm0, [rsp]
00007e4ecadce9bc  vmovaps xmm1, [rsp+0x10]
00007e4ecadce9c2  vmovaps xmm2, [rsp+0x20]
00007e4ecadce9c8  vmovaps xmm3, [rsp+0x30]
00007e4ecadce9ce  vmovaps xmm4, [rsp+0x40]
00007e4ecadce9d4  vmovaps xmm5, [rsp+0x50]
00007e4ecadce9da  vmovaps xmm6, [rsp+0x60]
00007e4ecadce9e0  vmovaps xmm7, [rsp+0x70]
00007e4ecadce9e6  vmovaps xmm8, [rsp+0x80]
00007e4ecadce9ef  vmovaps xmm9, [rsp+0x90]
00007e4ecadce9f8  vmovaps xmm10, [rsp+0xA0]
00007e4ecadcea01  vmovaps xmm11, [rsp+0xB0]
00007e4ecadcea0a  vmovaps xmm12, [rsp+0xC0]
00007e4ecadcea13  vmovaps xmm14, [rsp+0xD0]
00007e4ecadcea1c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadcea25  add rsp, 0xF0
00007e4ecadcea2c  pop r11
00007e4ecadcea2e  pop r10
00007e4ecadcea30  pop r9
00007e4ecadcea32  pop r8
00007e4ecadcea34  pop rsi
00007e4ecadcea35  pop rdi
00007e4ecadcea36  pop rdx
00007e4ecadcea37  pop rcx
00007e4ecadcea38  pop rax
00007e4ecadcea39  add rsp, 0x08
00007e4ecadcea3d  jmp 0x00007E4ECADCE81B
00007e4ecadcea42  call 0x00007E4ECAC0C380
00007e4ecadcea47  jmp 0x00007E4ECADCE82E
00007e4ecadcea4c  sub rsp, 0x08
00007e4ecadcea50  push rax
00007e4ecadcea51  push rcx
00007e4ecadcea52  push rdx
00007e4ecadcea53  push rdi
00007e4ecadcea54  push rsi
00007e4ecadcea55  push r8
00007e4ecadcea57  push r9
00007e4ecadcea59  push r10
00007e4ecadcea5b  push r11
00007e4ecadcea5d  sub rsp, 0xF0
00007e4ecadcea64  vmovaps [rsp], xmm0
00007e4ecadcea69  vmovaps [rsp+0x10], xmm2
00007e4ecadcea6f  vmovaps [rsp+0x20], xmm3
00007e4ecadcea75  vmovaps [rsp+0x30], xmm4
00007e4ecadcea7b  vmovaps [rsp+0x40], xmm5
00007e4ecadcea81  vmovaps [rsp+0x50], xmm6
00007e4ecadcea87  vmovaps [rsp+0x60], xmm7
00007e4ecadcea8d  vmovaps [rsp+0x70], xmm8
00007e4ecadcea93  vmovaps [rsp+0x80], xmm9
00007e4ecadcea9c  vmovaps [rsp+0x90], xmm10
00007e4ecadceaa5  vmovaps [rsp+0xA0], xmm11
00007e4ecadceaae  vmovaps [rsp+0xB0], xmm12
00007e4ecadceab7  vmovaps [rsp+0xC0], xmm13
00007e4ecadceac0  vmovaps [rsp+0xD0], xmm14
00007e4ecadceac9  vmovaps [rsp+0xE0], xmm15
00007e4ecadcead2  sub rsp, 0x30
00007e4ecadcead6  movaps [rsp], xmm1
00007e4ecadceada  movaps [rsp+0x10], xmm14
00007e4ecadceae0  movaps [rsp+0x20], xmm15
00007e4ecadceae6  lea rdi, [rsp]
00007e4ecadceaea  mov esi, 0x00
00007e4ecadceaef  mov rax, 0x5784BC1F5530
00007e4ecadceaf9  call rax
00007e4ecadceafb  movaps xmm1, [rsp]
00007e4ecadceaff  add rsp, 0x30
00007e4ecadceb03  vmovaps xmm0, [rsp]
00007e4ecadceb08  vmovaps xmm2, [rsp+0x10]
00007e4ecadceb0e  vmovaps xmm3, [rsp+0x20]
00007e4ecadceb14  vmovaps xmm4, [rsp+0x30]
00007e4ecadceb1a  vmovaps xmm5, [rsp+0x40]
00007e4ecadceb20  vmovaps xmm6, [rsp+0x50]
00007e4ecadceb26  vmovaps xmm7, [rsp+0x60]
00007e4ecadceb2c  vmovaps xmm8, [rsp+0x70]
00007e4ecadceb32  vmovaps xmm9, [rsp+0x80]
00007e4ecadceb3b  vmovaps xmm10, [rsp+0x90]
00007e4ecadceb44  vmovaps xmm11, [rsp+0xA0]
00007e4ecadceb4d  vmovaps xmm12, [rsp+0xB0]
00007e4ecadceb56  vmovaps xmm13, [rsp+0xC0]
00007e4ecadceb5f  vmovaps xmm14, [rsp+0xD0]
00007e4ecadceb68  vmovaps xmm15, [rsp+0xE0]
00007e4ecadceb71  add rsp, 0xF0
00007e4ecadceb78  pop r11
00007e4ecadceb7a  pop r10
00007e4ecadceb7c  pop r9
00007e4ecadceb7e  pop r8
00007e4ecadceb80  pop rsi
00007e4ecadceb81  pop rdi
00007e4ecadceb82  pop rdx
00007e4ecadceb83  pop rcx
00007e4ecadceb84  pop rax
00007e4ecadceb85  add rsp, 0x08
00007e4ecadceb89  jmp 0x00007E4ECADCE848
00007e4ecadceb8e  call 0x00007E4ECABFF540
00007e4ecadceb93  jmp 0x00007E4ECADCE85B
00007e4ecadceb98  int3
00007e4ecadceb99  nop [rax], eax
00007e4ecadceba0  movaps xmm1, [r15+0x180]
00007e4ecadceba8  vpmovqd xmm15, xmm1
00007e4ecadcebae  pxor xmm14, xmm14
00007e4ecadcebb3  punpcklqdq xmm15, xmm14
00007e4ecadcebb8  movaps [r15+0x210], xmm15
00007e4ecadcebc0  movq xmm15, qword ptr [r15+0x120]
00007e4ecadcebc9  movq xmm14, qword ptr [r15+0x130]
00007e4ecadcebd2  psubd xmm15, xmm14
00007e4ecadcebd7  movq xmm15, xmm15
00007e4ecadcebdc  movaps xmm13, [r15+0x170]
00007e4ecadcebe4  paddq xmm1, xmm13
00007e4ecadcebe9  movaps [r15+0x180], xmm1
00007e4ecadcebf1  movq xmm1, qword ptr [r15+0x150]
00007e4ecadcebfa  paddd xmm14, xmm1
00007e4ecadcebff  movq xmm14, xmm14
00007e4ecadcec04  movq xmm14, xmm14
00007e4ecadcec09  movaps [r15+0x130], xmm14
00007e4ecadcec11  pmovzxdq xmm15, xmm15
00007e4ecadcec17  psllq xmm15, 0x00
00007e4ecadcec1d  movq xmm1, qword ptr [r15+0x210]
00007e4ecadcec26  movq xmm14, qword ptr [r15+0x110]
00007e4ecadcec2f  paddd xmm1, xmm14
00007e4ecadcec34  movq xmm1, xmm1
00007e4ecadcec38  vcvtuqq2pd xmm15, xmm15
00007e4ecadcec3e  pmovzxdq xmm1, xmm1
00007e4ecadcec43  psllq xmm1, 0x00
00007e4ecadcec48  vcvtuqq2pd xmm1, xmm1
00007e4ecadcec4e  movaps xmm14, [r15+0x140]
00007e4ecadcec56  movaps xmm13, xmm15
00007e4ecadcec5a  mulpd xmm13, xmm14
00007e4ecadcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4ecadcec65  ptest xmm12, xmm12
00007e4ecadcec6b  jnz 0x00007E4ECADCED4E
00007e4ecadcec71  movaps [r15+0x220], xmm13
00007e4ecadcec79  mov rax, [r15+0x48]
00007e4ecadcec7d  mov r14, [r15+0x50]
00007e4ecadcec81  lea r12, [r14+rax*1]
00007e4ecadcec85  movups [r13+r12*1], xmm13
00007e4ecadcec8b  movaps xmm15, [r15+0x160]
00007e4ecadcec93  movaps xmm14, xmm1
00007e4ecadcec97  mulpd xmm14, xmm15
00007e4ecadcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007e4ecadceca2  ptest xmm13, xmm13
00007e4ecadceca8  jnz 0x00007E4ECADCEE9C
00007e4ecadcecae  movaps [r15+0x210], xmm14
00007e4ecadcecb6  mov r14, [r15+0x40]
00007e4ecadcecba  lea r12, [r14+rax*1]
00007e4ecadcecbe  movups [r13+r12*1], xmm14
00007e4ecadcecc4  lea r14, [rax+0x10]
00007e4ecadcecc8  mov [r15+0x48], r14
00007e4ecadceccc  xor eax, eax
00007e4ecadcecce  mov r12d, 0x200
00007e4ecadcecd4  cmp r14, r12
00007e4ecadcecd7  cmc
00007e4ecadcecd8  lahf
00007e4ecadcecd9  seto al
00007e4ecadcecdc  mov [r15+0x108], eax
00007e4ecadcece3  mov eax, [r15+0x108]
00007e4ecadcecea  sahf
00007e4ecadceceb  jnz 0x00007E4ECADCED1D
00007e4ecadceced  cmp dword ptr [r15+0x318], 0x00
00007e4ecadcecf5  jz 0x00007E4ECADCEFF0
00007e4ecadcecfb  nop [rax+rax*1], ax
00007e4ecadced04  nop [rax+rax*1], eax
00007e4ecadced0c  mov eax, 0x4101EC
00007e4ecadced11  mov [r15+0x100], rax
00007e4ecadced18  jmp 0x00007E4ECABFE110
00007e4ecadced1d  cmp dword ptr [r15+0x318], 0x00
00007e4ecadced25  jz 0x00007E4ECADCEBA0
00007e4ecadced2b  nop [rax+rax*1], ax
00007e4ecadced34  nop [rax+rax*1], eax
00007e4ecadced3c  mov eax, 0x4101AC
00007e4ecadced41  mov [r15+0x100], rax
00007e4ecadced48  jmp 0x00007E4ECABFE110
00007e4ecadced4d  int3
00007e4ecadced4e  sub rsp, 0x08
00007e4ecadced52  push rax
00007e4ecadced53  push rcx
00007e4ecadced54  push rdx
00007e4ecadced55  push rdi
00007e4ecadced56  push rsi
00007e4ecadced57  push r8
00007e4ecadced59  push r9
00007e4ecadced5b  push r10
00007e4ecadced5d  push r11
00007e4ecadced5f  sub rsp, 0xF0
00007e4ecadced66  vmovaps [rsp], xmm0
00007e4ecadced6b  vmovaps [rsp+0x10], xmm1
00007e4ecadced71  vmovaps [rsp+0x20], xmm2
00007e4ecadced77  vmovaps [rsp+0x30], xmm3
00007e4ecadced7d  vmovaps [rsp+0x40], xmm4
00007e4ecadced83  vmovaps [rsp+0x50], xmm5
00007e4ecadced89  vmovaps [rsp+0x60], xmm6
00007e4ecadced8f  vmovaps [rsp+0x70], xmm7
00007e4ecadced95  vmovaps [rsp+0x80], xmm8
00007e4ecadced9e  vmovaps [rsp+0x90], xmm9
00007e4ecadceda7  vmovaps [rsp+0xA0], xmm10
00007e4ecadcedb0  vmovaps [rsp+0xB0], xmm11
00007e4ecadcedb9  vmovaps [rsp+0xC0], xmm12
00007e4ecadcedc2  vmovaps [rsp+0xD0], xmm14
00007e4ecadcedcb  vmovaps [rsp+0xE0], xmm15
00007e4ecadcedd4  sub rsp, 0x30
00007e4ecadcedd8  movaps [rsp], xmm13
00007e4ecadceddd  movaps [rsp+0x10], xmm15
00007e4ecadcede3  movaps [rsp+0x20], xmm14
00007e4ecadcede9  lea rdi, [rsp]
00007e4ecadceded  mov esi, 0x00
00007e4ecadcedf2  mov rax, 0x5784BC1F5530
00007e4ecadcedfc  call rax
00007e4ecadcedfe  movaps xmm13, [rsp]
00007e4ecadcee03  add rsp, 0x30
00007e4ecadcee07  vmovaps xmm0, [rsp]
00007e4ecadcee0c  vmovaps xmm1, [rsp+0x10]
00007e4ecadcee12  vmovaps xmm2, [rsp+0x20]
00007e4ecadcee18  vmovaps xmm3, [rsp+0x30]
00007e4ecadcee1e  vmovaps xmm4, [rsp+0x40]
00007e4ecadcee24  vmovaps xmm5, [rsp+0x50]
00007e4ecadcee2a  vmovaps xmm6, [rsp+0x60]
00007e4ecadcee30  vmovaps xmm7, [rsp+0x70]
00007e4ecadcee36  vmovaps xmm8, [rsp+0x80]
00007e4ecadcee3f  vmovaps xmm9, [rsp+0x90]
00007e4ecadcee48  vmovaps xmm10, [rsp+0xA0]
00007e4ecadcee51  vmovaps xmm11, [rsp+0xB0]
00007e4ecadcee5a  vmovaps xmm12, [rsp+0xC0]
00007e4ecadcee63  vmovaps xmm14, [rsp+0xD0]
00007e4ecadcee6c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadcee75  add rsp, 0xF0
00007e4ecadcee7c  pop r11
00007e4ecadcee7e  pop r10
00007e4ecadcee80  pop r9
00007e4ecadcee82  pop r8
00007e4ecadcee84  pop rsi
00007e4ecadcee85  pop rdi
00007e4ecadcee86  pop rdx
00007e4ecadcee87  pop rcx
00007e4ecadcee88  pop rax
00007e4ecadcee89  add rsp, 0x08
00007e4ecadcee8d  jmp 0x00007E4ECADCEC71
00007e4ecadcee92  call 0x00007E4ECACC2240
00007e4ecadcee97  jmp 0x00007E4ECADCEC8B
00007e4ecadcee9c  sub rsp, 0x08
00007e4ecadceea0  push rax
00007e4ecadceea1  push rcx
00007e4ecadceea2  push rdx
00007e4ecadceea3  push rdi
00007e4ecadceea4  push rsi
00007e4ecadceea5  push r8
00007e4ecadceea7  push r9
00007e4ecadceea9  push r10
00007e4ecadceeab  push r11
00007e4ecadceead  sub rsp, 0xF0
00007e4ecadceeb4  vmovaps [rsp], xmm0
00007e4ecadceeb9  vmovaps [rsp+0x10], xmm1
00007e4ecadceebf  vmovaps [rsp+0x20], xmm2
00007e4ecadceec5  vmovaps [rsp+0x30], xmm3
00007e4ecadceecb  vmovaps [rsp+0x40], xmm4
00007e4ecadceed1  vmovaps [rsp+0x50], xmm5
00007e4ecadceed7  vmovaps [rsp+0x60], xmm6
00007e4ecadceedd  vmovaps [rsp+0x70], xmm7
00007e4ecadceee3  vmovaps [rsp+0x80], xmm8
00007e4ecadceeec  vmovaps [rsp+0x90], xmm9
00007e4ecadceef5  vmovaps [rsp+0xA0], xmm10
00007e4ecadceefe  vmovaps [rsp+0xB0], xmm11
00007e4ecadcef07  vmovaps [rsp+0xC0], xmm12
00007e4ecadcef10  vmovaps [rsp+0xD0], xmm13
00007e4ecadcef19  vmovaps [rsp+0xE0], xmm15
00007e4ecadcef22  sub rsp, 0x30
00007e4ecadcef26  movaps [rsp], xmm14
00007e4ecadcef2b  movaps [rsp+0x10], xmm1
00007e4ecadcef30  movaps [rsp+0x20], xmm15
00007e4ecadcef36  lea rdi, [rsp]
00007e4ecadcef3a  mov esi, 0x00
00007e4ecadcef3f  mov rax, 0x5784BC1F5530
00007e4ecadcef49  call rax
00007e4ecadcef4b  movaps xmm14, [rsp]
00007e4ecadcef50  add rsp, 0x30
00007e4ecadcef54  vmovaps xmm0, [rsp]
00007e4ecadcef59  vmovaps xmm1, [rsp+0x10]
00007e4ecadcef5f  vmovaps xmm2, [rsp+0x20]
00007e4ecadcef65  vmovaps xmm3, [rsp+0x30]
00007e4ecadcef6b  vmovaps xmm4, [rsp+0x40]
00007e4ecadcef71  vmovaps xmm5, [rsp+0x50]
00007e4ecadcef77  vmovaps xmm6, [rsp+0x60]
00007e4ecadcef7d  vmovaps xmm7, [rsp+0x70]
00007e4ecadcef83  vmovaps xmm8, [rsp+0x80]
00007e4ecadcef8c  vmovaps xmm9, [rsp+0x90]
00007e4ecadcef95  vmovaps xmm10, [rsp+0xA0]
00007e4ecadcef9e  vmovaps xmm11, [rsp+0xB0]
00007e4ecadcefa7  vmovaps xmm12, [rsp+0xC0]
00007e4ecadcefb0  vmovaps xmm13, [rsp+0xD0]
00007e4ecadcefb9  vmovaps xmm15, [rsp+0xE0]
00007e4ecadcefc2  add rsp, 0xF0
00007e4ecadcefc9  pop r11
00007e4ecadcefcb  pop r10
00007e4ecadcefcd  pop r9
00007e4ecadcefcf  pop r8
00007e4ecadcefd1  pop rsi
00007e4ecadcefd2  pop rdi
00007e4ecadcefd3  pop rdx
00007e4ecadcefd4  pop rcx
00007e4ecadcefd5  pop rax
00007e4ecadcefd6  add rsp, 0x08
00007e4ecadcefda  jmp 0x00007E4ECADCECAE
00007e4ecadcefdf  call 0x00007E4ECACC34C0
00007e4ecadcefe4  jmp 0x00007E4ECADCECC4
00007e4ecadcefe9  int3
00007e4ecadcefea  nop [rax+rax*1], ax
00007e4ecadceff0  mov rax, [r15+0xF8]
00007e4ecadceff7  lea r14, [rax-0x150]
00007e4ecadceffe  mov [r15+0xF8], r14
00007e4ecadcf005  mov rax, [r15+0x50]
00007e4ecadcf009  lea r12, [rax+0x80]
00007e4ecadcf010  movups xmm1, [r13+r12*1]
00007e4ecadcf016  lea r12, [rax+0x90]
00007e4ecadcf01d  movups xmm15, [r13+r12*1]
00007e4ecadcf023  mov qword ptr [r15+0x48], 0x00
00007e4ecadcf02b  lea r12, [rax+0x40]
00007e4ecadcf02f  movups xmm14, [r13+r12*1]
00007e4ecadcf035  lea r12, [rax+0x50]
00007e4ecadcf039  movups xmm13, [r13+r12*1]
00007e4ecadcf03f  lea r12, [r14+0x120]
00007e4ecadcf046  movq xmm12, qword ptr [r15+0x1C0]
00007e4ecadcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007e4ecadcf058  movq r11, xmm12
00007e4ecadcf05d  movq r10, xmm11
00007e4ecadcf062  mov [r13+r12*1], r11
00007e4ecadcf067  lea r12, [r14+0x128]
00007e4ecadcf06e  mov [r13+r12*1], r10
00007e4ecadcf073  vxorps xmm12, xmm12, xmm12
00007e4ecadcf078  vpbroadcastq xmm12, xmm12
00007e4ecadcf07d  lea r12, [r14+0x100]
00007e4ecadcf084  movq xmm11, qword ptr [r15+0x200]
00007e4ecadcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007e4ecadcf096  movq r11, xmm11
00007e4ecadcf09b  movq r10, xmm10
00007e4ecadcf0a0  mov [r13+r12*1], r11
00007e4ecadcf0a5  lea r12, [r14+0x108]
00007e4ecadcf0ac  mov [r13+r12*1], r10
00007e4ecadcf0b1  lea r12, [r14+0xE0]
00007e4ecadcf0b8  movups [r13+r12*1], xmm15
00007e4ecadcf0be  lea r12, [r14+0xF0]
00007e4ecadcf0c5  movups [r13+r12*1], xmm1
00007e4ecadcf0cb  lea r12, [rax+0xC0]
00007e4ecadcf0d2  movups xmm1, [r13+r12*1]
00007e4ecadcf0d8  lea r12, [rax+0xD0]
00007e4ecadcf0df  movups xmm15, [r13+r12*1]
00007e4ecadcf0e5  lea r12, [r14+0x110]
00007e4ecadcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007e4ecadcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007e4ecadcf0fe  movq r11, xmm11
00007e4ecadcf103  movq r10, xmm10
00007e4ecadcf108  mov [r13+r12*1], r11
00007e4ecadcf10d  lea r12, [r14+0x118]
00007e4ecadcf114  mov [r13+r12*1], r10
00007e4ecadcf119  movups xmm11, [r13+rax*1]
00007e4ecadcf11f  lea r12, [rax+0x10]
00007e4ecadcf123  movups xmm10, [r13+r12*1]
00007e4ecadcf129  lea r12, [r14+0x130]
00007e4ecadcf130  movq xmm9, qword ptr [r15+0x1A0]
00007e4ecadcf139  movq xmm8, qword ptr [r15+0x190]
00007e4ecadcf142  movq r11, xmm9
00007e4ecadcf147  movq r10, xmm8
00007e4ecadcf14c  mov [r13+r12*1], r11
00007e4ecadcf151  lea r12, [r14+0x138]
00007e4ecadcf158  mov [r13+r12*1], r10
00007e4ecadcf15d  lea r12, [rax+0x140]
00007e4ecadcf164  movups xmm9, [r13+r12*1]
00007e4ecadcf16a  lea r12, [rax+0x150]
00007e4ecadcf171  movups xmm8, [r13+r12*1]
00007e4ecadcf177  lea r12, [r14+0xC0]
00007e4ecadcf17e  movups [r13+r12*1], xmm15
00007e4ecadcf184  lea r12, [r14+0xD0]
00007e4ecadcf18b  movups [r13+r12*1], xmm1
00007e4ecadcf191  lea r12, [rax+0x100]
00007e4ecadcf198  movups xmm1, [r13+r12*1]
00007e4ecadcf19e  lea r12, [rax+0x110]
00007e4ecadcf1a5  movups xmm15, [r13+r12*1]
00007e4ecadcf1ab  lea r12, [r14+0x140]
00007e4ecadcf1b2  mov r11, [r15+0xE8]
00007e4ecadcf1b9  mov [r13+r12*1], r11
00007e4ecadcf1be  lea r12, [rax+0x180]
00007e4ecadcf1c5  movups xmm7, [r13+r12*1]
00007e4ecadcf1cb  lea r12, [rax+0x190]
00007e4ecadcf1d2  movups xmm6, [r13+r12*1]
00007e4ecadcf1d8  lea r12, [rax+0x1C0]
00007e4ecadcf1df  movups xmm5, [r13+r12*1]
00007e4ecadcf1e5  lea r12, [rax+0x1D0]
00007e4ecadcf1ec  movups xmm4, [r13+r12*1]
00007e4ecadcf1f2  lea r12, [r14+0x20]
00007e4ecadcf1f6  movups [r13+r12*1], xmm1
00007e4ecadcf1fc  lea r12, [r14+0x30]
00007e4ecadcf200  movups [r13+r12*1], xmm13
00007e4ecadcf206  lea r12, [rax+0x60]
00007e4ecadcf20a  movups xmm1, [r13+r12*1]
00007e4ecadcf210  lea r12, [rax+0x70]
00007e4ecadcf214  movups xmm13, [r13+r12*1]
00007e4ecadcf21a  lea r12, [rax+0x20]
00007e4ecadcf21e  movups xmm3, [r13+r12*1]
00007e4ecadcf224  lea r12, [rax+0x30]
00007e4ecadcf228  movups xmm2, [r13+r12*1]
00007e4ecadcf22e  movaps [r15+0x1F0], xmm2
00007e4ecadcf236  lea r12, [r14+0x60]
00007e4ecadcf23a  movups [r13+r12*1], xmm11
00007e4ecadcf240  lea r12, [r14+0x70]
00007e4ecadcf244  movups [r13+r12*1], xmm5
00007e4ecadcf24a  lea r12, [rax+0xE0]
00007e4ecadcf251  movups xmm11, [r13+r12*1]
00007e4ecadcf257  lea r12, [rax+0xF0]
00007e4ecadcf25e  movups xmm5, [r13+r12*1]
00007e4ecadcf264  lea r12, [r14+0xA0]
00007e4ecadcf26b  movups [r13+r12*1], xmm13
00007e4ecadcf271  lea r12, [r14+0xB0]
00007e4ecadcf278  movups [r13+r12*1], xmm1
00007e4ecadcf27e  lea r12, [rax+0xA0]
00007e4ecadcf285  movups xmm1, [r13+r12*1]
00007e4ecadcf28b  lea r12, [rax+0xB0]
00007e4ecadcf292  movups xmm13, [r13+r12*1]
00007e4ecadcf298  lea r12, [rax+0x120]
00007e4ecadcf29f  vmovaps [rsp+0x10], xmm1
00007e4ecadcf2a5  movups xmm1, [r13+r12*1]
00007e4ecadcf2ab  lea r12, [rax+0x130]
00007e4ecadcf2b2  vmovaps [rsp+0x20], xmm1
00007e4ecadcf2b8  movups xmm1, [r13+r12*1]
00007e4ecadcf2be  lea r12, [rax+0x160]
00007e4ecadcf2c5  vmovaps [rsp+0x30], xmm1
00007e4ecadcf2cb  movups xmm1, [r13+r12*1]
00007e4ecadcf2d1  lea r12, [rax+0x170]
00007e4ecadcf2d8  vmovaps [rsp+0x40], xmm1
00007e4ecadcf2de  movups xmm1, [r13+r12*1]
00007e4ecadcf2e4  movaps [r15+0x2B0], xmm1
00007e4ecadcf2ec  lea r12, [r14+0x80]
00007e4ecadcf2f3  movups [r13+r12*1], xmm13
00007e4ecadcf2f9  lea r12, [r14+0x90]
00007e4ecadcf300  vmovaps xmm13, [rsp+0x10]
00007e4ecadcf306  movups [r13+r12*1], xmm13
00007e4ecadcf30c  lea r12, [rax+0x1A0]
00007e4ecadcf313  movups xmm13, [r13+r12*1]
00007e4ecadcf319  lea r12, [rax+0x1B0]
00007e4ecadcf320  vmovaps [rsp+0x10], xmm1
00007e4ecadcf326  movups xmm1, [r13+r12*1]
00007e4ecadcf32c  movaps [r15+0x290], xmm13
00007e4ecadcf334  movaps [r15+0x1E0], xmm1
00007e4ecadcf33c  lea r12, [rax+0x1E0]
00007e4ecadcf343  vmovaps [rsp+0x50], xmm1
00007e4ecadcf349  movups xmm1, [r13+r12*1]
00007e4ecadcf34f  lea r12, [rax+0x1F0]
00007e4ecadcf356  vmovaps [rsp+0x60], xmm1
00007e4ecadcf35c  movups xmm1, [r13+r12*1]
00007e4ecadcf362  mov qword ptr [r15+0x50], 0x430920
00007e4ecadcf36a  lea rax, [r14+0x40]
00007e4ecadcf36e  vmovaps [rsp+0x70], xmm1
00007e4ecadcf374  vmovaps xmm1, [rsp+0x40]
00007e4ecadcf37a  movups [r13+rax*1], xmm1
00007e4ecadcf380  lea rax, [r14+0x50]
00007e4ecadcf384  movups [r13+rax*1], xmm10
00007e4ecadcf38a  vmovaps xmm1, [rsp+0x70]
00007e4ecadcf390  movups [r13+r14*1], xmm1
00007e4ecadcf396  lea rax, [r14+0x10]
00007e4ecadcf39a  vmovaps xmm1, [rsp+0x60]
00007e4ecadcf3a0  movups [r13+rax*1], xmm1
00007e4ecadcf3a6  mov rax, [r15+0x40]
00007e4ecadcf3aa  vmovaps [rsp+0x40], xmm3
00007e4ecadcf3b0  vmovaps xmm1, [rsp+0x40]
00007e4ecadcf3b6  por xmm3, xmm1
00007e4ecadcf3ba  vmovaps [rsp+0x40], xmm6
00007e4ecadcf3c0  vmovaps xmm10, [rsp+0x40]
00007e4ecadcf3c6  por xmm6, xmm10
00007e4ecadcf3cb  lea r12, [rax+0x30]
00007e4ecadcf3cf  mov r11, [r13+r12*1]
00007e4ecadcf3d4  lea r12, [rax+0x38]
00007e4ecadcf3d8  mov r10, [r13+r12*1]
00007e4ecadcf3dd  movq xmm10, r11
00007e4ecadcf3e2  vmovaps [rsp+0x40], xmm1
00007e4ecadcf3e8  movq xmm1, r10
00007e4ecadcf3ed  movq xmm10, xmm10
00007e4ecadcf3f2  vmovaps [rsp+0x60], xmm10
00007e4ecadcf3f8  movq xmm10, xmm10
00007e4ecadcf3fd  movaps [r15+0x130], xmm10
00007e4ecadcf405  movq xmm1, xmm1
00007e4ecadcf409  vmovaps [rsp+0x70], xmm1
00007e4ecadcf40f  movq xmm1, xmm1
00007e4ecadcf413  movaps [r15+0x280], xmm1
00007e4ecadcf41b  vmovaps [rsp+0x80], xmm9
00007e4ecadcf424  vmovaps xmm1, [rsp+0x80]
00007e4ecadcf42d  por xmm9, xmm1
00007e4ecadcf432  lea r12, [rax+0x20]
00007e4ecadcf436  mov r11, [r13+r12*1]
00007e4ecadcf43b  lea r12, [rax+0x28]
00007e4ecadcf43f  mov r10, [r13+r12*1]
00007e4ecadcf444  movq xmm1, r11
00007e4ecadcf449  movq xmm10, r10
00007e4ecadcf44e  movq xmm1, xmm1
00007e4ecadcf452  vmovaps [rsp+0x80], xmm1
00007e4ecadcf45b  movq xmm1, xmm1
00007e4ecadcf45f  movaps [r15+0x150], xmm1
00007e4ecadcf467  movq xmm10, xmm10
00007e4ecadcf46c  vmovaps [rsp+0x90], xmm10
00007e4ecadcf475  movq xmm10, xmm10
00007e4ecadcf47a  movaps [r15+0x140], xmm10
00007e4ecadcf482  lea r12, [rax+0x10]
00007e4ecadcf486  mov r11, [r13+r12*1]
00007e4ecadcf48b  lea r12, [rax+0x18]
00007e4ecadcf48f  mov r10, [r13+r12*1]
00007e4ecadcf494  movq xmm1, r11
00007e4ecadcf499  movq xmm10, r10
00007e4ecadcf49e  movq xmm1, xmm1
00007e4ecadcf4a2  vmovaps [rsp+0xA0], xmm1
00007e4ecadcf4ab  movq xmm1, xmm1
00007e4ecadcf4af  movaps [r15+0x170], xmm1
00007e4ecadcf4b7  movq xmm10, xmm10
00007e4ecadcf4bc  vmovaps [rsp+0xB0], xmm10
00007e4ecadcf4c5  movq xmm10, xmm10
00007e4ecadcf4ca  movaps [r15+0x160], xmm10
00007e4ecadcf4d2  mov r12, [r13+rax*1]
00007e4ecadcf4d7  vmovq xmm1, r12
00007e4ecadcf4dc  vpbroadcastq xmm1, xmm1
00007e4ecadcf4e1  lea r12, [rax+0x08]
00007e4ecadcf4e5  mov rax, [r13+r12*1]
00007e4ecadcf4ea  movq xmm10, rax
00007e4ecadcf4ef  movaps [r15+0x230], xmm10
00007e4ecadcf4f7  lea rax, [r14+0x50]
00007e4ecadcf4fb  movups xmm10, [r13+rax*1]
00007e4ecadcf501  lea rax, [r14+0x60]
00007e4ecadcf505  vmovaps [rsp+0xC0], xmm1
00007e4ecadcf50e  movups xmm1, [r13+rax*1]
00007e4ecadcf514  lea rax, [r14+0x30]
00007e4ecadcf518  vmovaps [rsp+0xD0], xmm1
00007e4ecadcf521  movups xmm1, [r13+rax*1]
00007e4ecadcf527  mov qword ptr [r15+0x60], 0x430920
00007e4ecadcf52f  mov qword ptr [r15+0x58], 0x40
00007e4ecadcf537  vmovaps [rsp+0xE0], xmm1
00007e4ecadcf540  vmovaps [rsp+0xF0], xmm15
00007e4ecadcf549  vmovaps xmm15, [rsp+0xC0]
00007e4ecadcf552  vmovaps [rsp+0xC0], xmm14
00007e4ecadcf55b  vmovaps xmm14, [rsp+0x40]
00007e4ecadcf561  vmovaps [rsp+0x40], xmm13
00007e4ecadcf567  movaps xmm1, xmm15
00007e4ecadcf56b  mulpd xmm1, xmm14
00007e4ecadcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007e4ecadcf575  ptest xmm13, xmm13
00007e4ecadcf57b  jnz 0x00007E4ECADD0682
00007e4ecadcf581  movq xmm14, qword ptr [r15+0x230]
00007e4ecadcf58a  vmovaps [rsp+0x100], xmm14
00007e4ecadcf593  vpermilpd xmm14, xmm14, 0x00
00007e4ecadcf599  vmovaps [rsp+0x110], xmm1
00007e4ecadcf5a2  vmovaps xmm1, [rsp+0xE0]
00007e4ecadcf5ab  vmovaps [rsp+0xE0], xmm15
00007e4ecadcf5b4  movaps xmm13, xmm1
00007e4ecadcf5b8  mulpd xmm13, xmm14
00007e4ecadcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007e4ecadcf5c3  ptest xmm15, xmm15
00007e4ecadcf5c9  jnz 0x00007E4ECADD07C4
00007e4ecadcf5cf  vxorps xmm1, xmm1, xmm1
00007e4ecadcf5d3  vpbroadcastq xmm1, xmm1
00007e4ecadcf5d8  vmovaps xmm14, [rsp+0xE0]
00007e4ecadcf5e1  vmovaps [rsp+0xE0], xmm1
00007e4ecadcf5ea  vmovaps xmm1, [rsp+0xD0]
00007e4ecadcf5f3  vmovaps [rsp+0xD0], xmm13
00007e4ecadcf5fc  movaps xmm15, xmm14
00007e4ecadcf600  mulpd xmm15, xmm1
00007e4ecadcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4ecadcf60b  ptest xmm13, xmm13
00007e4ecadcf611  jnz 0x00007E4ECADD0907
00007e4ecadcf617  movaps xmm1, xmm14
00007e4ecadcf61b  mulpd xmm1, xmm10
00007e4ecadcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007e4ecadcf625  ptest xmm13, xmm13
00007e4ecadcf62b  jnz 0x00007E4ECADD0A4A
00007e4ecadcf631  movaps xmm13, xmm14
00007e4ecadcf635  mulpd xmm13, xmm2
00007e4ecadcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007e4ecadcf640  ptest xmm10, xmm10
00007e4ecadcf646  jnz 0x00007E4ECADD0B8C
00007e4ecadcf64c  vmovaps [rsp+0x120], xmm7
00007e4ecadcf655  vmovaps xmm14, [rsp+0x120]
00007e4ecadcf65e  por xmm7, xmm14
00007e4ecadcf663  vmovaps xmm14, [rsp+0xC0]
00007e4ecadcf66c  vmovaps xmm10, [rsp+0xC0]
00007e4ecadcf675  por xmm14, xmm10
00007e4ecadcf67a  vmovaps xmm2, [rsp+0x100]
00007e4ecadcf683  vpermilpd xmm2, xmm2, 0x00
00007e4ecadcf689  vmovaps [rsp+0xC0], xmm1
00007e4ecadcf692  vmovaps [rsp+0x120], xmm15
00007e4ecadcf69b  movaps xmm1, xmm10
00007e4ecadcf69f  mulpd xmm1, xmm2
00007e4ecadcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4ecadcf6a8  ptest xmm15, xmm15
00007e4ecadcf6ae  jnz 0x00007E4ECADD0CCF
00007e4ecadcf6b4  xor eax, eax
00007e4ecadcf6b6  mov r12d, 0x40
00007e4ecadcf6bc  mov r11d, 0x200
00007e4ecadcf6c2  cmp r12, r11
00007e4ecadcf6c5  cmc
00007e4ecadcf6c6  lahf
00007e4ecadcf6c7  seto al
00007e4ecadcf6ca  mov [r15+0x108], eax
00007e4ecadcf6d1  vmovaps xmm10, [rsp+0x110]
00007e4ecadcf6da  vmovaps xmm2, [rsp+0xE0]
00007e4ecadcf6e3  vmovaps [rsp+0xE0], xmm1
00007e4ecadcf6ec  movaps xmm15, xmm10
00007e4ecadcf6f0  addpd xmm15, xmm2
00007e4ecadcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecadcf6fb  ptest xmm1, xmm1
00007e4ecadcf700  jnz 0x00007E4ECADD0E10
00007e4ecadcf706  vmovaps xmm10, [rsp+0x120]
00007e4ecadcf70f  vmovaps [rsp+0x110], xmm15
00007e4ecadcf718  movaps xmm1, xmm10
00007e4ecadcf71c  addpd xmm1, xmm12
00007e4ecadcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4ecadcf726  ptest xmm15, xmm15
00007e4ecadcf72c  jnz 0x00007E4ECADD0F53
00007e4ecadcf732  vmovaps xmm10, [rsp+0xC0]
00007e4ecadcf73b  vmovaps [rsp+0xC0], xmm1
00007e4ecadcf744  movaps xmm15, xmm10
00007e4ecadcf748  addpd xmm15, xmm12
00007e4ecadcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecadcf753  ptest xmm1, xmm1
00007e4ecadcf758  jnz 0x00007E4ECADD1095
00007e4ecadcf75e  vmovaps xmm1, [rsp+0x30]
00007e4ecadcf764  vmovaps xmm12, [rsp+0x30]
00007e4ecadcf76a  por xmm1, xmm12
00007e4ecadcf76f  vmovaps xmm12, [rsp+0x20]
00007e4ecadcf775  vmovaps xmm10, [rsp+0x20]
00007e4ecadcf77b  por xmm12, xmm10
00007e4ecadcf780  vmovaps [rsp+0x20], xmm5
00007e4ecadcf786  vmovaps xmm10, [rsp+0x20]
00007e4ecadcf78c  por xmm5, xmm10
00007e4ecadcf791  vmovaps [rsp+0x20], xmm11
00007e4ecadcf797  vmovaps xmm10, [rsp+0x20]
00007e4ecadcf79d  por xmm11, xmm10
00007e4ecadcf7a2  vmovaps [rsp+0x20], xmm4
00007e4ecadcf7a8  vmovaps xmm10, [rsp+0x20]
00007e4ecadcf7ae  por xmm4, xmm10
00007e4ecadcf7b3  vmovaps [rsp+0x20], xmm8
00007e4ecadcf7b9  vmovaps xmm10, [rsp+0x20]
00007e4ecadcf7bf  por xmm8, xmm10
00007e4ecadcf7c4  vmovaps xmm10, [rsp+0xF0]
00007e4ecadcf7cd  vmovaps [rsp+0x20], xmm1
00007e4ecadcf7d3  vmovaps xmm1, [rsp+0xF0]
00007e4ecadcf7dc  por xmm10, xmm1
00007e4ecadcf7e1  lea rax, [r14+0xA0]
00007e4ecadcf7e8  movups xmm1, [r13+rax*1]
00007e4ecadcf7ee  lea rax, [r14+0xB0]
00007e4ecadcf7f5  vmovaps [rsp+0x30], xmm1
00007e4ecadcf7fb  movups xmm1, [r13+rax*1]
00007e4ecadcf801  vmovaps [rsp+0xF0], xmm1
00007e4ecadcf80a  vmovaps [rsp+0x120], xmm15
00007e4ecadcf813  movaps xmm1, xmm13
00007e4ecadcf817  addpd xmm1, xmm2
00007e4ecadcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4ecadcf820  ptest xmm15, xmm15
00007e4ecadcf826  jnz 0x00007E4ECADD11ED
00007e4ecadcf82c  lea rax, [r14+0xF0]
00007e4ecadcf833  movups xmm15, [r13+rax*1]
00007e4ecadcf839  vmovaps xmm2, [rsp+0xC0]
00007e4ecadcf842  vmovaps [rsp+0xC0], xmm1
00007e4ecadcf84b  vmovaps xmm1, [rsp+0xE0]
00007e4ecadcf854  vmovaps [rsp+0xE0], xmm15
00007e4ecadcf85d  movaps xmm13, xmm2
00007e4ecadcf861  addpd xmm13, xmm1
00007e4ecadcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007e4ecadcf86c  ptest xmm15, xmm15
00007e4ecadcf872  jnz 0x00007E4ECADD1338
00007e4ecadcf878  vmovaps xmm15, [rsp+0x120]
00007e4ecadcf881  vmovaps xmm2, [rsp+0xD0]
00007e4ecadcf88a  vmovaps [rsp+0xD0], xmm14
00007e4ecadcf893  movaps xmm1, xmm15
00007e4ecadcf897  addpd xmm1, xmm2
00007e4ecadcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4ecadcf8a0  ptest xmm14, xmm14
00007e4ecadcf8a6  jnz 0x00007E4ECADD147A
00007e4ecadcf8ac  vmovaps xmm15, [rsp+0x100]
00007e4ecadcf8b5  vpermilpd xmm15, xmm15, 0x00
00007e4ecadcf8bb  vmovaps xmm2, [rsp+0xF0]
00007e4ecadcf8c4  vmovaps [rsp+0xF0], xmm1
00007e4ecadcf8cd  movaps xmm14, xmm2
00007e4ecadcf8d1  mulpd xmm14, xmm15
00007e4ecadcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007e4ecadcf8dc  ptest xmm1, xmm1
00007e4ecadcf8e1  jnz 0x00007E4ECADD15BB
00007e4ecadcf8e7  vmovaps xmm1, [rsp+0xA0]
00007e4ecadcf8f0  vpermilpd xmm1, xmm1, 0x00
00007e4ecadcf8f6  vmovaps xmm2, [rsp+0xE0]
00007e4ecadcf8ff  vmovaps [rsp+0xE0], xmm14
00007e4ecadcf908  movaps xmm15, xmm2
00007e4ecadcf90c  mulpd xmm15, xmm1
00007e4ecadcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4ecadcf917  ptest xmm14, xmm14
00007e4ecadcf91d  jnz 0x00007E4ECADD16FE
00007e4ecadcf923  lea rax, [r14+0xE0]
00007e4ecadcf92a  movups xmm1, [r13+rax*1]
00007e4ecadcf930  vmovaps xmm14, [rsp+0x100]
00007e4ecadcf939  vpermilpd xmm14, xmm14, 0x00
00007e4ecadcf93f  vmovaps [rsp+0x100], xmm1
00007e4ecadcf948  vmovaps xmm1, [rsp+0x30]
00007e4ecadcf94e  vmovaps [rsp+0x30], xmm15
00007e4ecadcf954  movaps xmm2, xmm1
00007e4ecadcf957  mulpd xmm2, xmm14
00007e4ecadcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007e4ecadcf961  ptest xmm15, xmm15
00007e4ecadcf967  jnz 0x00007E4ECADD184A
00007e4ecadcf96d  vmovaps [rsp+0x120], xmm10
00007e4ecadcf976  vmovaps xmm1, [rsp+0x120]
00007e4ecadcf97f  por xmm10, xmm1
00007e4ecadcf984  movaps [r15+0x300], xmm10
00007e4ecadcf98c  vmovaps [rsp+0x120], xmm8
00007e4ecadcf995  vmovaps xmm1, [rsp+0x120]
00007e4ecadcf99e  por xmm8, xmm1
00007e4ecadcf9a3  movaps [r15+0x190], xmm8
00007e4ecadcf9ab  vmovaps xmm1, [rsp+0xA0]
00007e4ecadcf9b4  vpermilpd xmm1, xmm1, 0x00
00007e4ecadcf9ba  vmovaps xmm14, [rsp+0x100]
00007e4ecadcf9c3  vmovaps [rsp+0x100], xmm13
00007e4ecadcf9cc  movaps xmm15, xmm14
00007e4ecadcf9d0  mulpd xmm15, xmm1
00007e4ecadcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4ecadcf9db  ptest xmm13, xmm13
00007e4ecadcf9e1  jnz 0x00007E4ECADD198B
00007e4ecadcf9e7  lea rax, [r14+0x90]
00007e4ecadcf9ee  movups xmm1, [r13+rax*1]
00007e4ecadcf9f4  vmovaps [rsp+0x120], xmm4
00007e4ecadcf9fd  vmovaps xmm14, [rsp+0x120]
00007e4ecadcfa06  por xmm4, xmm14
00007e4ecadcfa0b  movaps [r15+0x1C0], xmm4
00007e4ecadcfa13  vmovaps [rsp+0x120], xmm11
00007e4ecadcfa1c  vmovaps xmm14, [rsp+0x120]
00007e4ecadcfa25  por xmm11, xmm14
00007e4ecadcfa2a  movaps [r15+0x200], xmm11
00007e4ecadcfa32  vmovaps [rsp+0x120], xmm5
00007e4ecadcfa3b  vmovaps xmm14, [rsp+0x120]
00007e4ecadcfa44  por xmm5, xmm14
00007e4ecadcfa49  movaps [r15+0x2D0], xmm5
00007e4ecadcfa51  vmovaps [rsp+0x120], xmm12
00007e4ecadcfa5a  vmovaps xmm14, [rsp+0x120]
00007e4ecadcfa63  por xmm12, xmm14
00007e4ecadcfa68  movaps [r15+0x2E0], xmm12
00007e4ecadcfa70  vmovaps xmm13, [rsp+0x110]
00007e4ecadcfa79  vmovaps [rsp+0x110], xmm1
00007e4ecadcfa82  vmovaps xmm1, [rsp+0xE0]
00007e4ecadcfa8b  vmovaps [rsp+0xE0], xmm15
00007e4ecadcfa94  movaps xmm14, xmm13
00007e4ecadcfa98  addpd xmm14, xmm1
00007e4ecadcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007e4ecadcfaa3  ptest xmm15, xmm15
00007e4ecadcfaa9  jnz 0x00007E4ECADD1AD8
00007e4ecadcfaaf  vmovaps xmm1, [rsp+0xA0]
00007e4ecadcfab8  vpermilpd xmm1, xmm1, 0x00
00007e4ecadcfabe  vmovaps xmm13, [rsp+0x110]
00007e4ecadcfac7  vmovaps [rsp+0x110], xmm14
00007e4ecadcfad0  movaps xmm15, xmm13
00007e4ecadcfad4  mulpd xmm15, xmm1
00007e4ecadcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4ecadcfadf  ptest xmm14, xmm14
00007e4ecadcfae5  jnz 0x00007E4ECADD1C1B
00007e4ecadcfaeb  lea rax, [r14+0x80]
00007e4ecadcfaf2  movups xmm1, [r13+rax*1]
00007e4ecadcfaf8  vmovaps xmm13, [rsp+0xC0]
00007e4ecadcfb01  vmovaps [rsp+0xC0], xmm1
00007e4ecadcfb0a  movaps xmm14, xmm13
00007e4ecadcfb0e  addpd xmm14, xmm2
00007e4ecadcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007e4ecadcfb19  ptest xmm1, xmm1
00007e4ecadcfb1e  jnz 0x00007E4ECADD1D68
00007e4ecadcfb24  vmovaps xmm13, [rsp+0x100]
00007e4ecadcfb2d  vmovaps xmm2, [rsp+0x30]
00007e4ecadcfb33  vmovaps [rsp+0x30], xmm15
00007e4ecadcfb39  movaps xmm1, xmm13
00007e4ecadcfb3d  addpd xmm1, xmm2
00007e4ecadcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4ecadcfb46  ptest xmm15, xmm15
00007e4ecadcfb4c  jnz 0x00007E4ECADD1EAB
00007e4ecadcfb52  vmovaps xmm15, [rsp+0x20]
00007e4ecadcfb58  vmovaps xmm13, [rsp+0x20]
00007e4ecadcfb5e  por xmm15, xmm13
00007e4ecadcfb63  movaps [r15+0x2F0], xmm15
00007e4ecadcfb6b  vmovaps xmm13, [rsp+0xA0]
00007e4ecadcfb74  vpermilpd xmm13, xmm13, 0x00
00007e4ecadcfb7a  vmovaps [rsp+0x20], xmm1
00007e4ecadcfb80  vmovaps xmm1, [rsp+0xC0]
00007e4ecadcfb89  vmovaps [rsp+0xA0], xmm15
00007e4ecadcfb92  movaps xmm2, xmm1
00007e4ecadcfb95  mulpd xmm2, xmm13
00007e4ecadcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007e4ecadcfb9f  ptest xmm15, xmm15
00007e4ecadcfba5  jnz 0x00007E4ECADD1FEC
00007e4ecadcfbab  lea rax, [r14+0xD0]
00007e4ecadcfbb2  movups xmm1, [r13+rax*1]
00007e4ecadcfbb8  vmovaps xmm13, [rsp+0xF0]
00007e4ecadcfbc1  vmovaps [rsp+0xC0], xmm1
00007e4ecadcfbca  vmovaps xmm1, [rsp+0xE0]
00007e4ecadcfbd3  vmovaps [rsp+0xE0], xmm14
00007e4ecadcfbdc  movaps xmm15, xmm13
00007e4ecadcfbe0  addpd xmm15, xmm1
00007e4ecadcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4ecadcfbeb  ptest xmm14, xmm14
00007e4ecadcfbf1  jnz 0x00007E4ECADD2137
00007e4ecadcfbf7  vmovaps xmm1, [rsp+0xB0]
00007e4ecadcfc00  vpermilpd xmm1, xmm1, 0x00
00007e4ecadcfc06  movaps xmm14, xmm11
00007e4ecadcfc0a  mulpd xmm14, xmm1
00007e4ecadcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007e4ecadcfc15  ptest xmm13, xmm13
00007e4ecadcfc1b  jnz 0x00007E4ECADD227A
00007e4ecadcfc21  movaps [r15+0x260], xmm14
00007e4ecadcfc29  vxorps xmm1, xmm1, xmm1
00007e4ecadcfc2d  vpbroadcastq xmm1, xmm1
00007e4ecadcfc32  movaps [r15+0x1B0], xmm1
00007e4ecadcfc3a  vmovaps xmm1, [rsp+0xB0]
00007e4ecadcfc43  vpermilpd xmm1, xmm1, 0x00
00007e4ecadcfc49  vmovaps xmm11, [rsp+0xC0]
00007e4ecadcfc52  vmovaps [rsp+0xC0], xmm15
00007e4ecadcfc5b  movaps xmm13, xmm11
00007e4ecadcfc5f  mulpd xmm13, xmm1
00007e4ecadcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007e4ecadcfc6a  ptest xmm15, xmm15
00007e4ecadcfc70  jnz 0x00007E4ECADD23BD
00007e4ecadcfc76  lea rax, [r14+0xC0]
00007e4ecadcfc7d  movups xmm1, [r13+rax*1]
00007e4ecadcfc83  vmovaps xmm11, [rsp+0x110]
00007e4ecadcfc8c  vmovaps [rsp+0xF0], xmm1
00007e4ecadcfc95  vmovaps xmm1, [rsp+0x30]
00007e4ecadcfc9b  vmovaps [rsp+0x30], xmm14
00007e4ecadcfca1  movaps xmm15, xmm11
00007e4ecadcfca5  addpd xmm15, xmm1
00007e4ecadcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4ecadcfcb0  ptest xmm14, xmm14
00007e4ecadcfcb6  jnz 0x00007E4ECADD250A
00007e4ecadcfcbc  vmovaps [rsp+0x100], xmm9
00007e4ecadcfcc5  vmovaps xmm1, [rsp+0x100]
00007e4ecadcfcce  por xmm9, xmm1
00007e4ecadcfcd3  movaps [r15+0x270], xmm9
00007e4ecadcfcdb  vmovaps [rsp+0x100], xmm6
00007e4ecadcfce4  vmovaps xmm1, [rsp+0x100]
00007e4ecadcfced  por xmm6, xmm1
00007e4ecadcfcf1  movaps [r15+0x1A0], xmm6
00007e4ecadcfcf9  vmovaps xmm14, [rsp+0xB0]
00007e4ecadcfd02  vpermilpd xmm14, xmm14, 0x00
00007e4ecadcfd08  vmovaps xmm6, [rsp+0xF0]
00007e4ecadcfd11  vmovaps [rsp+0xF0], xmm1
00007e4ecadcfd1a  movaps xmm11, xmm6
00007e4ecadcfd1e  mulpd xmm11, xmm14
00007e4ecadcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007e4ecadcfd29  ptest xmm1, xmm1
00007e4ecadcfd2e  jnz 0x00007E4ECADD264D
00007e4ecadcfd34  lea rax, [r14+0x20]
00007e4ecadcfd38  movups xmm1, [r13+rax*1]
00007e4ecadcfd3e  movaps [r15+0x110], xmm1
00007e4ecadcfd46  vmovaps xmm6, [rsp+0xE0]
00007e4ecadcfd4f  vmovaps [rsp+0xE0], xmm1
00007e4ecadcfd58  movaps xmm14, xmm6
00007e4ecadcfd5c  addpd xmm14, xmm2
00007e4ecadcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007e4ecadcfd67  ptest xmm1, xmm1
00007e4ecadcfd6c  jnz 0x00007E4ECADD279A
00007e4ecadcfd72  vmovaps xmm1, [rsp+0xB0]
00007e4ecadcfd7b  vpermilpd xmm1, xmm1, 0x00
00007e4ecadcfd81  movaps xmm6, xmm5
00007e4ecadcfd84  mulpd xmm6, xmm1
00007e4ecadcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007e4ecadcfd8d  ptest xmm2, xmm2
00007e4ecadcfd92  jnz 0x00007E4ECADD28DC
00007e4ecadcfd98  vmovaps xmm5, [rsp+0x20]
00007e4ecadcfd9e  movaps xmm1, xmm5
00007e4ecadcfda1  addpd xmm1, xmm13
00007e4ecadcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4ecadcfdab  ptest xmm2, xmm2
00007e4ecadcfdb0  jnz 0x00007E4ECADD2A1C
00007e4ecadcfdb6  vmovaps xmm13, [rsp+0x80]
00007e4ecadcfdbf  vpermilpd xmm13, xmm13, 0x00
00007e4ecadcfdc5  vmovaps xmm2, [rsp+0xE0]
00007e4ecadcfdce  vmovaps [rsp+0x20], xmm1
00007e4ecadcfdd4  movaps xmm5, xmm2
00007e4ecadcfdd7  mulpd xmm5, xmm13
00007e4ecadcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007e4ecadcfde1  ptest xmm1, xmm1
00007e4ecadcfde6  jnz 0x00007E4ECADD2B5D
00007e4ecadcfdec  vmovaps xmm1, [rsp+0x80]
00007e4ecadcfdf5  vpermilpd xmm1, xmm1, 0x00
00007e4ecadcfdfb  movaps xmm13, xmm10
00007e4ecadcfdff  mulpd xmm13, xmm1
00007e4ecadcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007e4ecadcfe0a  ptest xmm2, xmm2
00007e4ecadcfe0f  jnz 0x00007E4ECADD2C9E
00007e4ecadcfe15  vmovaps xmm10, [rsp+0x30]
00007e4ecadcfe1b  movaps xmm1, xmm15
00007e4ecadcfe1f  addpd xmm1, xmm10
00007e4ecadcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4ecadcfe29  ptest xmm2, xmm2
00007e4ecadcfe2e  jnz 0x00007E4ECADD2DE1
00007e4ecadcfe34  vmovaps xmm10, [rsp+0xC0]
00007e4ecadcfe3d  movaps xmm15, xmm10
00007e4ecadcfe41  addpd xmm15, xmm11
00007e4ecadcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007e4ecadcfe4c  ptest xmm2, xmm2
00007e4ecadcfe51  jnz 0x00007E4ECADD2F23
00007e4ecadcfe57  vmovaps xmm11, [rsp+0x80]
00007e4ecadcfe60  vpermilpd xmm11, xmm11, 0x00
00007e4ecadcfe66  movaps xmm10, xmm12
00007e4ecadcfe6a  mulpd xmm10, xmm11
00007e4ecadcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007e4ecadcfe75  ptest xmm2, xmm2
00007e4ecadcfe7a  jnz 0x00007E4ECADD3067
00007e4ecadcfe80  vmovaps xmm12, [rsp+0x80]
00007e4ecadcfe89  vpermilpd xmm12, xmm12, 0x00
00007e4ecadcfe8f  vmovaps xmm2, [rsp+0xA0]
00007e4ecadcfe98  vmovaps [rsp+0x30], xmm1
00007e4ecadcfe9e  movaps xmm11, xmm2
00007e4ecadcfea2  mulpd xmm11, xmm12
00007e4ecadcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007e4ecadcfead  ptest xmm1, xmm1
00007e4ecadcfeb2  jnz 0x00007E4ECADD31AB
00007e4ecadcfeb8  movaps xmm1, xmm14
00007e4ecadcfebc  addpd xmm1, xmm6
00007e4ecadcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4ecadcfec5  ptest xmm12, xmm12
00007e4ecadcfecb  jnz 0x00007E4ECADD32EE
00007e4ecadcfed1  vmovaps xmm12, [rsp+0x20]
00007e4ecadcfed7  movaps xmm14, xmm12
00007e4ecadcfedb  addpd xmm14, xmm5
00007e4ecadcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4ecadcfee6  ptest xmm6, xmm6
00007e4ecadcfeeb  jnz 0x00007E4ECADD342F
00007e4ecadcfef1  vmovaps xmm12, [rsp+0x90]
00007e4ecadcfefa  vpermilpd xmm12, xmm12, 0x00
00007e4ecadcff00  movaps xmm6, xmm9
00007e4ecadcff04  mulpd xmm6, xmm12
00007e4ecadcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4ecadcff0e  ptest xmm5, xmm5
00007e4ecadcff13  jnz 0x00007E4ECADD3572
00007e4ecadcff19  movaps xmm12, xmm15
00007e4ecadcff1d  addpd xmm12, xmm13
00007e4ecadcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4ecadcff28  ptest xmm9, xmm9
00007e4ecadcff2e  jnz 0x00007E4ECADD36B4
00007e4ecadcff34  vmovaps xmm13, [rsp+0x30]
00007e4ecadcff3a  movaps xmm15, xmm13
00007e4ecadcff3e  addpd xmm15, xmm10
00007e4ecadcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4ecadcff49  ptest xmm9, xmm9
00007e4ecadcff4f  jnz 0x00007E4ECADD37F8
00007e4ecadcff55  vmovaps xmm13, [rsp+0xD0]
00007e4ecadcff5e  vmovaps xmm10, [rsp+0xD0]
00007e4ecadcff67  por xmm13, xmm10
00007e4ecadcff6c  movaps [r15+0x250], xmm13
00007e4ecadcff74  vmovaps [rsp+0x20], xmm7
00007e4ecadcff7a  vmovaps xmm13, [rsp+0x20]
00007e4ecadcff80  por xmm7, xmm13
00007e4ecadcff85  movaps [r15+0x2A0], xmm7
00007e4ecadcff8d  vmovaps [rsp+0x20], xmm3
00007e4ecadcff93  vmovaps xmm13, [rsp+0x20]
00007e4ecadcff99  por xmm3, xmm13
00007e4ecadcff9e  movaps [r15+0x1D0], xmm3
00007e4ecadcffa6  lea rax, [r14+0x40]
00007e4ecadcffaa  movups xmm13, [r13+rax*1]
00007e4ecadcffb0  movaps [r15+0x2C0], xmm13
00007e4ecadcffb8  vmovaps xmm10, [rsp+0x90]
00007e4ecadcffc1  vpermilpd xmm10, xmm10, 0x00
00007e4ecadcffc7  movaps xmm9, xmm8
00007e4ecadcffcb  mulpd xmm9, xmm10
00007e4ecadcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007e4ecadcffd6  ptest xmm5, xmm5
00007e4ecadcffdb  jnz 0x00007E4ECADD3946
00007e4ecadcffe1  movaps xmm10, xmm1
00007e4ecadcffe5  addpd xmm10, xmm11
00007e4ecadcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007e4ecadcfff0  ptest xmm8, xmm8
00007e4ecadcfff6  jnz 0x00007E4ECADD3A8A
00007e4ecadcfffc  movaps xmm1, xmm14
00007e4ecadd0000  addpd xmm1, xmm6
00007e4ecadd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007e4ecadd0009  ptest xmm11, xmm11
00007e4ecadd000f  jnz 0x00007E4ECADD3BCD
00007e4ecadd0015  vmovaps xmm14, [rsp+0x90]
00007e4ecadd001e  vpermilpd xmm14, xmm14, 0x00
00007e4ecadd0024  movaps xmm11, xmm13
00007e4ecadd0028  mulpd xmm11, xmm14
00007e4ecadd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007e4ecadd0033  ptest xmm8, xmm8
00007e4ecadd0039  jnz 0x00007E4ECADD3D0E
00007e4ecadd003f  vmovaps xmm14, [rsp+0x90]
00007e4ecadd0048  vpermilpd xmm14, xmm14, 0x00
00007e4ecadd004e  vmovaps xmm8, [rsp+0x10]
00007e4ecadd0054  movaps xmm13, xmm8
00007e4ecadd0058  mulpd xmm13, xmm14
00007e4ecadd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007e4ecadd0063  ptest xmm6, xmm6
00007e4ecadd0068  jnz 0x00007E4ECADD3E52
00007e4ecadd006e  vmovaps xmm14, [rsp+0x60]
00007e4ecadd0074  vpermilpd xmm14, xmm14, 0x00
00007e4ecadd007a  movaps xmm8, xmm7
00007e4ecadd007e  mulpd xmm8, xmm14
00007e4ecadd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4ecadd0089  ptest xmm6, xmm6
00007e4ecadd008e  jnz 0x00007E4ECADD3F96
00007e4ecadd0094  movaps xmm14, xmm12
00007e4ecadd0098  addpd xmm14, xmm9
00007e4ecadd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007e4ecadd00a3  ptest xmm7, xmm7
00007e4ecadd00a8  jnz 0x00007E4ECADD40D9
00007e4ecadd00ae  vmovaps xmm12, [rsp+0x60]
00007e4ecadd00b4  vpermilpd xmm12, xmm12, 0x00
00007e4ecadd00ba  vmovaps xmm7, [rsp+0xF0]
00007e4ecadd00c3  movaps xmm9, xmm7
00007e4ecadd00c7  mulpd xmm9, xmm12
00007e4ecadd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4ecadd00d2  ptest xmm6, xmm6
00007e4ecadd00d7  jnz 0x00007E4ECADD421D
00007e4ecadd00dd  movaps xmm12, xmm15
00007e4ecadd00e1  addpd xmm12, xmm11
00007e4ecadd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007e4ecadd00ec  ptest xmm7, xmm7
00007e4ecadd00f1  jnz 0x00007E4ECADD4360
00007e4ecadd00f7  vmovaps xmm15, [rsp+0x60]
00007e4ecadd00fd  vpermilpd xmm15, xmm15, 0x00
00007e4ecadd0103  vmovaps xmm7, [rsp+0x40]
00007e4ecadd0109  movaps xmm11, xmm7
00007e4ecadd010d  mulpd xmm11, xmm15
00007e4ecadd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007e4ecadd0118  ptest xmm6, xmm6
00007e4ecadd011d  jnz 0x00007E4ECADD44A4
00007e4ecadd0123  movaps xmm15, xmm10
00007e4ecadd0127  addpd xmm15, xmm13
00007e4ecadd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007e4ecadd0132  ptest xmm7, xmm7
00007e4ecadd0137  jnz 0x00007E4ECADD45E7
00007e4ecadd013d  vmovaps xmm13, [rsp+0x60]
00007e4ecadd0143  vpermilpd xmm13, xmm13, 0x00
00007e4ecadd0149  vmovaps xmm7, [rsp+0x50]
00007e4ecadd014f  movaps xmm10, xmm7
00007e4ecadd0153  mulpd xmm10, xmm13
00007e4ecadd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4ecadd015e  ptest xmm6, xmm6
00007e4ecadd0163  jnz 0x00007E4ECADD472B
00007e4ecadd0169  movaps xmm13, xmm1
00007e4ecadd016d  addpd xmm13, xmm8
00007e4ecadd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007e4ecadd0178  ptest xmm7, xmm7
00007e4ecadd017d  jnz 0x00007E4ECADD486E
00007e4ecadd0183  lea rax, [r14+0x70]
00007e4ecadd0187  movups xmm1, [r13+rax*1]
00007e4ecadd018d  movaps [r15+0x240], xmm1
00007e4ecadd0195  movaps xmm8, xmm14
00007e4ecadd0199  addpd xmm8, xmm9
00007e4ecadd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4ecadd01a4  ptest xmm7, xmm7
00007e4ecadd01a9  jnz 0x00007E4ECADD49BB
00007e4ecadd01af  movaps [r15+0x170], xmm8
00007e4ecadd01b7  vmovaps xmm14, [rsp+0x70]
00007e4ecadd01bd  vpermilpd xmm14, xmm14, 0x00
00007e4ecadd01c3  movaps xmm9, xmm1
00007e4ecadd01c7  mulpd xmm9, xmm14
00007e4ecadd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007e4ecadd01d2  ptest xmm7, xmm7
00007e4ecadd01d7  jnz 0x00007E4ECADD4AFF
00007e4ecadd01dd  vmovaps xmm1, [rsp+0x70]
00007e4ecadd01e3  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd01e9  movaps xmm14, xmm4
00007e4ecadd01ed  mulpd xmm14, xmm1
00007e4ecadd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007e4ecadd01f8  ptest xmm7, xmm7
00007e4ecadd01fd  jnz 0x00007E4ECADD4C42
00007e4ecadd0203  movaps [r15+0x180], xmm14
00007e4ecadd020b  movaps xmm1, xmm12
00007e4ecadd020f  addpd xmm1, xmm11
00007e4ecadd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007e4ecadd0219  ptest xmm7, xmm7
00007e4ecadd021e  jnz 0x00007E4ECADD4D84
00007e4ecadd0224  movaps [r15+0x210], xmm1
00007e4ecadd022c  movups xmm12, [r13+r14*1]
00007e4ecadd0232  lea rax, [r14+0x10]
00007e4ecadd0236  movups xmm11, [r13+rax*1]
00007e4ecadd023c  movaps [r15+0x230], xmm11
00007e4ecadd0244  movaps xmm7, xmm15
00007e4ecadd0248  addpd xmm7, xmm10
00007e4ecadd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4ecadd0252  ptest xmm6, xmm6
00007e4ecadd0257  jnz 0x00007E4ECADD4EDA
00007e4ecadd025d  movaps [r15+0x130], xmm7
00007e4ecadd0265  vmovaps xmm15, [rsp+0x70]
00007e4ecadd026b  vpermilpd xmm15, xmm15, 0x00
00007e4ecadd0271  movaps xmm10, xmm11
00007e4ecadd0275  mulpd xmm10, xmm15
00007e4ecadd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4ecadd0280  ptest xmm6, xmm6
00007e4ecadd0285  jnz 0x00007E4ECADD501C
00007e4ecadd028b  movaps [r15+0x220], xmm10
00007e4ecadd0293  vmovaps xmm15, [rsp+0x70]
00007e4ecadd0299  vpermilpd xmm15, xmm15, 0x00
00007e4ecadd029f  movaps xmm11, xmm12
00007e4ecadd02a3  mulpd xmm11, xmm15
00007e4ecadd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007e4ecadd02ae  ptest xmm6, xmm6
00007e4ecadd02b3  jnz 0x00007E4ECADD5160
00007e4ecadd02b9  movaps xmm15, xmm13
00007e4ecadd02bd  addpd xmm15, xmm9
00007e4ecadd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007e4ecadd02c8  ptest xmm12, xmm12
00007e4ecadd02ce  jnz 0x00007E4ECADD52A4
00007e4ecadd02d4  movaps [r15+0x140], xmm15
00007e4ecadd02dc  movaps xmm13, xmm8
00007e4ecadd02e0  addpd xmm13, xmm14
00007e4ecadd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4ecadd02eb  ptest xmm12, xmm12
00007e4ecadd02f1  jnz 0x00007E4ECADD53E8
00007e4ecadd02f7  movaps [r15+0x150], xmm13
00007e4ecadd02ff  movaps xmm14, xmm1
00007e4ecadd0303  addpd xmm14, xmm10
00007e4ecadd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007e4ecadd030e  ptest xmm12, xmm12
00007e4ecadd0314  jnz 0x00007E4ECADD552C
00007e4ecadd031a  movaps [r15+0x160], xmm14
00007e4ecadd0322  movaps xmm1, xmm7
00007e4ecadd0325  addpd xmm1, xmm11
00007e4ecadd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4ecadd032f  ptest xmm12, xmm12
00007e4ecadd0335  jnz 0x00007E4ECADD566F
00007e4ecadd033b  movaps [r15+0x120], xmm1
00007e4ecadd0343  mov eax, 0x430920
00007e4ecadd0348  movups [r13+rax*1], xmm15
00007e4ecadd034e  mov eax, 0x430930
00007e4ecadd0353  movups [r13+rax*1], xmm13
00007e4ecadd0359  mov eax, 0x430940
00007e4ecadd035e  movups [r13+rax*1], xmm14
00007e4ecadd0364  mov eax, 0x430950
00007e4ecadd0369  movups [r13+rax*1], xmm1
00007e4ecadd036f  mov eax, [r15+0x108]
00007e4ecadd0376  sahf
00007e4ecadd0377  jnz 0x00007E4ECADD03A9
00007e4ecadd0379  cmp dword ptr [r15+0x318], 0x00
00007e4ecadd0381  jz 0x00007E4ECADDB900
00007e4ecadd0387  nop [rax+rax*1], ax
00007e4ecadd0390  nop [rax+rax*1], eax
00007e4ecadd0398  mov eax, 0x410444
00007e4ecadd039d  mov [r15+0x100], rax
00007e4ecadd03a4  jmp 0x00007E4ECABFE110
00007e4ecadd03a9  cmp dword ptr [r15+0x318], 0x00
00007e4ecadd03b1  jz 0x00007E4ECADD57E0
00007e4ecadd03b7  nop [rax+rax*1], ax
00007e4ecadd03c0  nop [rax+rax*1], eax
00007e4ecadd03c8  mov eax, 0x410278
00007e4ecadd03cd  mov [r15+0x100], rax
00007e4ecadd03d4  jmp 0x00007E4ECABFE110
00007e4ecadd03d9  int3
00007e4ecadd03da  call 0x00007E4ECACB52F0
00007e4ecadd03df  jmp 0x00007E4ECADCF016
00007e4ecadd03e4  call 0x00007E4ECACC4620
00007e4ecadd03e9  jmp 0x00007E4ECADCF023
00007e4ecadd03ee  call 0x00007E4ECACC33A0
00007e4ecadd03f3  jmp 0x00007E4ECADCF035
00007e4ecadd03f8  call 0x00007E4ECACC2120
00007e4ecadd03fd  jmp 0x00007E4ECADCF03F
00007e4ecadd0402  call 0x00007E4ECACC0860
00007e4ecadd0407  jmp 0x00007E4ECADCF067
00007e4ecadd040c  call 0x00007E4ECACBF5F0
00007e4ecadd0411  jmp 0x00007E4ECADCF073
00007e4ecadd0416  call 0x00007E4ECACC0860
00007e4ecadd041b  jmp 0x00007E4ECADCF0A5
00007e4ecadd0420  call 0x00007E4ECACBF5F0
00007e4ecadd0425  jmp 0x00007E4ECADCF0B1
00007e4ecadd042a  call 0x00007E4ECACC4740
00007e4ecadd042f  jmp 0x00007E4ECADCF0BE
00007e4ecadd0434  call 0x00007E4ECACB5400
00007e4ecadd0439  jmp 0x00007E4ECADCF0CB
00007e4ecadd043e  call 0x00007E4ECACB52F0
00007e4ecadd0443  jmp 0x00007E4ECADCF0D8
00007e4ecadd0448  call 0x00007E4ECACC4620
00007e4ecadd044d  jmp 0x00007E4ECADCF0E5
00007e4ecadd0452  call 0x00007E4ECACC0860
00007e4ecadd0457  jmp 0x00007E4ECADCF10D
00007e4ecadd045c  call 0x00007E4ECACBF5F0
00007e4ecadd0461  jmp 0x00007E4ECADCF119
00007e4ecadd0466  call 0x00007E4ECAC09D70
00007e4ecadd046b  jmp 0x00007E4ECADCF11F
00007e4ecadd0470  call 0x00007E4ECACBE9C0
00007e4ecadd0475  jmp 0x00007E4ECADCF129
00007e4ecadd047a  call 0x00007E4ECACC0860
00007e4ecadd047f  jmp 0x00007E4ECADCF151
00007e4ecadd0484  call 0x00007E4ECACBF5F0
00007e4ecadd0489  jmp 0x00007E4ECADCF15D
00007e4ecadd048e  call 0x00007E4ECACBD750
00007e4ecadd0493  jmp 0x00007E4ECADCF16A
00007e4ecadd0498  call 0x00007E4ECACBC4E0
00007e4ecadd049d  jmp 0x00007E4ECADCF177
00007e4ecadd04a2  call 0x00007E4ECACC4740
00007e4ecadd04a7  jmp 0x00007E4ECADCF184
00007e4ecadd04ac  call 0x00007E4ECACB5400
00007e4ecadd04b1  jmp 0x00007E4ECADCF191
00007e4ecadd04b6  call 0x00007E4ECACB52F0
00007e4ecadd04bb  jmp 0x00007E4ECADCF19E
00007e4ecadd04c0  call 0x00007E4ECACC4620
00007e4ecadd04c5  jmp 0x00007E4ECADCF1AB
00007e4ecadd04ca  call 0x00007E4ECACC0860
00007e4ecadd04cf  jmp 0x00007E4ECADCF1BE
00007e4ecadd04d4  call 0x00007E4ECACBB270
00007e4ecadd04d9  jmp 0x00007E4ECADCF1CB
00007e4ecadd04de  call 0x00007E4ECACBA000
00007e4ecadd04e3  jmp 0x00007E4ECADCF1D8
00007e4ecadd04e8  call 0x00007E4ECACB8D90
00007e4ecadd04ed  jmp 0x00007E4ECADCF1E5
00007e4ecadd04f2  call 0x00007E4ECACB8A20
00007e4ecadd04f7  jmp 0x00007E4ECADCF1F2
00007e4ecadd04fc  call 0x00007E4ECACB5400
00007e4ecadd0501  jmp 0x00007E4ECADCF1FC
00007e4ecadd0506  call 0x00007E4ECACC2240
00007e4ecadd050b  jmp 0x00007E4ECADCF206
00007e4ecadd0510  call 0x00007E4ECACB52F0
00007e4ecadd0515  jmp 0x00007E4ECADCF210
00007e4ecadd051a  call 0x00007E4ECACC2120
00007e4ecadd051f  jmp 0x00007E4ECADCF21A
00007e4ecadd0524  call 0x00007E4ECACB77B0
00007e4ecadd0529  jmp 0x00007E4ECADCF224
00007e4ecadd052e  call 0x00007E4ECACB6550
00007e4ecadd0533  jmp 0x00007E4ECADCF22E
00007e4ecadd0538  call 0x00007E4ECACBFD50
00007e4ecadd053d  jmp 0x00007E4ECADCF240
00007e4ecadd0542  call 0x00007E4ECACB8EA0
00007e4ecadd0547  jmp 0x00007E4ECADCF24A
00007e4ecadd054c  call 0x00007E4ECACBFC30
00007e4ecadd0551  jmp 0x00007E4ECADCF257
00007e4ecadd0556  call 0x00007E4ECACB8D90
00007e4ecadd055b  jmp 0x00007E4ECADCF264
00007e4ecadd0560  call 0x00007E4ECACC2240
00007e4ecadd0565  jmp 0x00007E4ECADCF271
00007e4ecadd056a  call 0x00007E4ECACB5400
00007e4ecadd056f  jmp 0x00007E4ECADCF27E
00007e4ecadd0574  call 0x00007E4ECACB52F0
00007e4ecadd0579  jmp 0x00007E4ECADCF28B
00007e4ecadd057e  call 0x00007E4ECACC2120
00007e4ecadd0583  jmp 0x00007E4ECADCF298
00007e4ecadd0588  call 0x00007E4ECACB52F0
00007e4ecadd058d  jmp 0x00007E4ECADCF2AB
00007e4ecadd0592  call 0x00007E4ECACB52F0
00007e4ecadd0597  jmp 0x00007E4ECADCF2BE
00007e4ecadd059c  call 0x00007E4ECACB52F0
00007e4ecadd05a1  jmp 0x00007E4ECADCF2D1
00007e4ecadd05a6  call 0x00007E4ECACB52F0
00007e4ecadd05ab  jmp 0x00007E4ECADCF2E4
00007e4ecadd05b0  call 0x00007E4ECACC2240
00007e4ecadd05b5  jmp 0x00007E4ECADCF2F9
00007e4ecadd05ba  call 0x00007E4ECACC2240
00007e4ecadd05bf  jmp 0x00007E4ECADCF30C
00007e4ecadd05c4  call 0x00007E4ECACC2120
00007e4ecadd05c9  jmp 0x00007E4ECADCF319
00007e4ecadd05ce  call 0x00007E4ECACB52F0
00007e4ecadd05d3  jmp 0x00007E4ECADCF32C
00007e4ecadd05d8  call 0x00007E4ECACB52F0
00007e4ecadd05dd  jmp 0x00007E4ECADCF34F
00007e4ecadd05e2  call 0x00007E4ECACB52F0
00007e4ecadd05e7  jmp 0x00007E4ECADCF362
00007e4ecadd05ec  call 0x00007E4ECABFF540
00007e4ecadd05f1  jmp 0x00007E4ECADCF380
00007e4ecadd05f6  call 0x00007E4ECAC08C20
00007e4ecadd05fb  jmp 0x00007E4ECADCF38A
00007e4ecadd0600  call 0x00007E4ECACD6600
00007e4ecadd0605  jmp 0x00007E4ECADCF396
00007e4ecadd060a  call 0x00007E4ECABFF540
00007e4ecadd060f  jmp 0x00007E4ECADCF3A6
00007e4ecadd0614  call 0x00007E4ECACC0370
00007e4ecadd0619  jmp 0x00007E4ECADCF3D4
00007e4ecadd061e  call 0x00007E4ECACBF100
00007e4ecadd0623  jmp 0x00007E4ECADCF3DD
00007e4ecadd0628  call 0x00007E4ECACC0370
00007e4ecadd062d  jmp 0x00007E4ECADCF43B
00007e4ecadd0632  call 0x00007E4ECACBF100
00007e4ecadd0637  jmp 0x00007E4ECADCF444
00007e4ecadd063c  call 0x00007E4ECACC0370
00007e4ecadd0641  jmp 0x00007E4ECADCF48B
00007e4ecadd0646  call 0x00007E4ECACBF100
00007e4ecadd064b  jmp 0x00007E4ECADCF494
00007e4ecadd0650  call 0x00007E4ECAC0B720
00007e4ecadd0655  jmp 0x00007E4ECADCF4D7
00007e4ecadd065a  call 0x00007E4ECACB47C0
00007e4ecadd065f  jmp 0x00007E4ECADCF4EA
00007e4ecadd0664  call 0x00007E4ECAC08B00
00007e4ecadd0669  jmp 0x00007E4ECADCF501
00007e4ecadd066e  call 0x00007E4ECABFF430
00007e4ecadd0673  jmp 0x00007E4ECADCF514
00007e4ecadd0678  call 0x00007E4ECABFF430
00007e4ecadd067d  jmp 0x00007E4ECADCF527
00007e4ecadd0682  sub rsp, 0x08
00007e4ecadd0686  push rax
00007e4ecadd0687  push rcx
00007e4ecadd0688  push rdx
00007e4ecadd0689  push rdi
00007e4ecadd068a  push rsi
00007e4ecadd068b  push r8
00007e4ecadd068d  push r9
00007e4ecadd068f  push r10
00007e4ecadd0691  push r11
00007e4ecadd0693  sub rsp, 0xF0
00007e4ecadd069a  vmovaps [rsp], xmm0
00007e4ecadd069f  vmovaps [rsp+0x10], xmm2
00007e4ecadd06a5  vmovaps [rsp+0x20], xmm3
00007e4ecadd06ab  vmovaps [rsp+0x30], xmm4
00007e4ecadd06b1  vmovaps [rsp+0x40], xmm5
00007e4ecadd06b7  vmovaps [rsp+0x50], xmm6
00007e4ecadd06bd  vmovaps [rsp+0x60], xmm7
00007e4ecadd06c3  vmovaps [rsp+0x70], xmm8
00007e4ecadd06c9  vmovaps [rsp+0x80], xmm9
00007e4ecadd06d2  vmovaps [rsp+0x90], xmm10
00007e4ecadd06db  vmovaps [rsp+0xA0], xmm11
00007e4ecadd06e4  vmovaps [rsp+0xB0], xmm12
00007e4ecadd06ed  vmovaps [rsp+0xC0], xmm13
00007e4ecadd06f6  vmovaps [rsp+0xD0], xmm14
00007e4ecadd06ff  vmovaps [rsp+0xE0], xmm15
00007e4ecadd0708  sub rsp, 0x30
00007e4ecadd070c  movaps [rsp], xmm1
00007e4ecadd0710  movaps [rsp+0x10], xmm15
00007e4ecadd0716  movaps [rsp+0x20], xmm14
00007e4ecadd071c  lea rdi, [rsp]
00007e4ecadd0720  mov esi, 0x00
00007e4ecadd0725  mov rax, 0x5784BC1F5530
00007e4ecadd072f  call rax
00007e4ecadd0731  movaps xmm1, [rsp]
00007e4ecadd0735  add rsp, 0x30
00007e4ecadd0739  vmovaps xmm0, [rsp]
00007e4ecadd073e  vmovaps xmm2, [rsp+0x10]
00007e4ecadd0744  vmovaps xmm3, [rsp+0x20]
00007e4ecadd074a  vmovaps xmm4, [rsp+0x30]
00007e4ecadd0750  vmovaps xmm5, [rsp+0x40]
00007e4ecadd0756  vmovaps xmm6, [rsp+0x50]
00007e4ecadd075c  vmovaps xmm7, [rsp+0x60]
00007e4ecadd0762  vmovaps xmm8, [rsp+0x70]
00007e4ecadd0768  vmovaps xmm9, [rsp+0x80]
00007e4ecadd0771  vmovaps xmm10, [rsp+0x90]
00007e4ecadd077a  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd0783  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd078c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd0795  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd079e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd07a7  add rsp, 0xF0
00007e4ecadd07ae  pop r11
00007e4ecadd07b0  pop r10
00007e4ecadd07b2  pop r9
00007e4ecadd07b4  pop r8
00007e4ecadd07b6  pop rsi
00007e4ecadd07b7  pop rdi
00007e4ecadd07b8  pop rdx
00007e4ecadd07b9  pop rcx
00007e4ecadd07ba  pop rax
00007e4ecadd07bb  add rsp, 0x08
00007e4ecadd07bf  jmp 0x00007E4ECADCF581
00007e4ecadd07c4  sub rsp, 0x08
00007e4ecadd07c8  push rax
00007e4ecadd07c9  push rcx
00007e4ecadd07ca  push rdx
00007e4ecadd07cb  push rdi
00007e4ecadd07cc  push rsi
00007e4ecadd07cd  push r8
00007e4ecadd07cf  push r9
00007e4ecadd07d1  push r10
00007e4ecadd07d3  push r11
00007e4ecadd07d5  sub rsp, 0xF0
00007e4ecadd07dc  vmovaps [rsp], xmm0
00007e4ecadd07e1  vmovaps [rsp+0x10], xmm1
00007e4ecadd07e7  vmovaps [rsp+0x20], xmm2
00007e4ecadd07ed  vmovaps [rsp+0x30], xmm3
00007e4ecadd07f3  vmovaps [rsp+0x40], xmm4
00007e4ecadd07f9  vmovaps [rsp+0x50], xmm5
00007e4ecadd07ff  vmovaps [rsp+0x60], xmm6
00007e4ecadd0805  vmovaps [rsp+0x70], xmm7
00007e4ecadd080b  vmovaps [rsp+0x80], xmm8
00007e4ecadd0814  vmovaps [rsp+0x90], xmm9
00007e4ecadd081d  vmovaps [rsp+0xA0], xmm10
00007e4ecadd0826  vmovaps [rsp+0xB0], xmm11
00007e4ecadd082f  vmovaps [rsp+0xC0], xmm12
00007e4ecadd0838  vmovaps [rsp+0xD0], xmm14
00007e4ecadd0841  vmovaps [rsp+0xE0], xmm15
00007e4ecadd084a  sub rsp, 0x30
00007e4ecadd084e  movaps [rsp], xmm13
00007e4ecadd0853  movaps [rsp+0x10], xmm1
00007e4ecadd0858  movaps [rsp+0x20], xmm14
00007e4ecadd085e  lea rdi, [rsp]
00007e4ecadd0862  mov esi, 0x00
00007e4ecadd0867  mov rax, 0x5784BC1F5530
00007e4ecadd0871  call rax
00007e4ecadd0873  movaps xmm13, [rsp]
00007e4ecadd0878  add rsp, 0x30
00007e4ecadd087c  vmovaps xmm0, [rsp]
00007e4ecadd0881  vmovaps xmm1, [rsp+0x10]
00007e4ecadd0887  vmovaps xmm2, [rsp+0x20]
00007e4ecadd088d  vmovaps xmm3, [rsp+0x30]
00007e4ecadd0893  vmovaps xmm4, [rsp+0x40]
00007e4ecadd0899  vmovaps xmm5, [rsp+0x50]
00007e4ecadd089f  vmovaps xmm6, [rsp+0x60]
00007e4ecadd08a5  vmovaps xmm7, [rsp+0x70]
00007e4ecadd08ab  vmovaps xmm8, [rsp+0x80]
00007e4ecadd08b4  vmovaps xmm9, [rsp+0x90]
00007e4ecadd08bd  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd08c6  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd08cf  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd08d8  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd08e1  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd08ea  add rsp, 0xF0
00007e4ecadd08f1  pop r11
00007e4ecadd08f3  pop r10
00007e4ecadd08f5  pop r9
00007e4ecadd08f7  pop r8
00007e4ecadd08f9  pop rsi
00007e4ecadd08fa  pop rdi
00007e4ecadd08fb  pop rdx
00007e4ecadd08fc  pop rcx
00007e4ecadd08fd  pop rax
00007e4ecadd08fe  add rsp, 0x08
00007e4ecadd0902  jmp 0x00007E4ECADCF5CF
00007e4ecadd0907  sub rsp, 0x08
00007e4ecadd090b  push rax
00007e4ecadd090c  push rcx
00007e4ecadd090d  push rdx
00007e4ecadd090e  push rdi
00007e4ecadd090f  push rsi
00007e4ecadd0910  push r8
00007e4ecadd0912  push r9
00007e4ecadd0914  push r10
00007e4ecadd0916  push r11
00007e4ecadd0918  sub rsp, 0xF0
00007e4ecadd091f  vmovaps [rsp], xmm0
00007e4ecadd0924  vmovaps [rsp+0x10], xmm1
00007e4ecadd092a  vmovaps [rsp+0x20], xmm2
00007e4ecadd0930  vmovaps [rsp+0x30], xmm3
00007e4ecadd0936  vmovaps [rsp+0x40], xmm4
00007e4ecadd093c  vmovaps [rsp+0x50], xmm5
00007e4ecadd0942  vmovaps [rsp+0x60], xmm6
00007e4ecadd0948  vmovaps [rsp+0x70], xmm7
00007e4ecadd094e  vmovaps [rsp+0x80], xmm8
00007e4ecadd0957  vmovaps [rsp+0x90], xmm9
00007e4ecadd0960  vmovaps [rsp+0xA0], xmm10
00007e4ecadd0969  vmovaps [rsp+0xB0], xmm11
00007e4ecadd0972  vmovaps [rsp+0xC0], xmm12
00007e4ecadd097b  vmovaps [rsp+0xD0], xmm13
00007e4ecadd0984  vmovaps [rsp+0xE0], xmm14
00007e4ecadd098d  sub rsp, 0x30
00007e4ecadd0991  movaps [rsp], xmm15
00007e4ecadd0996  movaps [rsp+0x10], xmm14
00007e4ecadd099c  movaps [rsp+0x20], xmm1
00007e4ecadd09a1  lea rdi, [rsp]
00007e4ecadd09a5  mov esi, 0x00
00007e4ecadd09aa  mov rax, 0x5784BC1F5530
00007e4ecadd09b4  call rax
00007e4ecadd09b6  movaps xmm15, [rsp]
00007e4ecadd09bb  add rsp, 0x30
00007e4ecadd09bf  vmovaps xmm0, [rsp]
00007e4ecadd09c4  vmovaps xmm1, [rsp+0x10]
00007e4ecadd09ca  vmovaps xmm2, [rsp+0x20]
00007e4ecadd09d0  vmovaps xmm3, [rsp+0x30]
00007e4ecadd09d6  vmovaps xmm4, [rsp+0x40]
00007e4ecadd09dc  vmovaps xmm5, [rsp+0x50]
00007e4ecadd09e2  vmovaps xmm6, [rsp+0x60]
00007e4ecadd09e8  vmovaps xmm7, [rsp+0x70]
00007e4ecadd09ee  vmovaps xmm8, [rsp+0x80]
00007e4ecadd09f7  vmovaps xmm9, [rsp+0x90]
00007e4ecadd0a00  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd0a09  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd0a12  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd0a1b  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd0a24  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd0a2d  add rsp, 0xF0
00007e4ecadd0a34  pop r11
00007e4ecadd0a36  pop r10
00007e4ecadd0a38  pop r9
00007e4ecadd0a3a  pop r8
00007e4ecadd0a3c  pop rsi
00007e4ecadd0a3d  pop rdi
00007e4ecadd0a3e  pop rdx
00007e4ecadd0a3f  pop rcx
00007e4ecadd0a40  pop rax
00007e4ecadd0a41  add rsp, 0x08
00007e4ecadd0a45  jmp 0x00007E4ECADCF617
00007e4ecadd0a4a  sub rsp, 0x08
00007e4ecadd0a4e  push rax
00007e4ecadd0a4f  push rcx
00007e4ecadd0a50  push rdx
00007e4ecadd0a51  push rdi
00007e4ecadd0a52  push rsi
00007e4ecadd0a53  push r8
00007e4ecadd0a55  push r9
00007e4ecadd0a57  push r10
00007e4ecadd0a59  push r11
00007e4ecadd0a5b  sub rsp, 0xF0
00007e4ecadd0a62  vmovaps [rsp], xmm0
00007e4ecadd0a67  vmovaps [rsp+0x10], xmm2
00007e4ecadd0a6d  vmovaps [rsp+0x20], xmm3
00007e4ecadd0a73  vmovaps [rsp+0x30], xmm4
00007e4ecadd0a79  vmovaps [rsp+0x40], xmm5
00007e4ecadd0a7f  vmovaps [rsp+0x50], xmm6
00007e4ecadd0a85  vmovaps [rsp+0x60], xmm7
00007e4ecadd0a8b  vmovaps [rsp+0x70], xmm8
00007e4ecadd0a91  vmovaps [rsp+0x80], xmm9
00007e4ecadd0a9a  vmovaps [rsp+0x90], xmm10
00007e4ecadd0aa3  vmovaps [rsp+0xA0], xmm11
00007e4ecadd0aac  vmovaps [rsp+0xB0], xmm12
00007e4ecadd0ab5  vmovaps [rsp+0xC0], xmm13
00007e4ecadd0abe  vmovaps [rsp+0xD0], xmm14
00007e4ecadd0ac7  vmovaps [rsp+0xE0], xmm15
00007e4ecadd0ad0  sub rsp, 0x30
00007e4ecadd0ad4  movaps [rsp], xmm1
00007e4ecadd0ad8  movaps [rsp+0x10], xmm14
00007e4ecadd0ade  movaps [rsp+0x20], xmm10
00007e4ecadd0ae4  lea rdi, [rsp]
00007e4ecadd0ae8  mov esi, 0x00
00007e4ecadd0aed  mov rax, 0x5784BC1F5530
00007e4ecadd0af7  call rax
00007e4ecadd0af9  movaps xmm1, [rsp]
00007e4ecadd0afd  add rsp, 0x30
00007e4ecadd0b01  vmovaps xmm0, [rsp]
00007e4ecadd0b06  vmovaps xmm2, [rsp+0x10]
00007e4ecadd0b0c  vmovaps xmm3, [rsp+0x20]
00007e4ecadd0b12  vmovaps xmm4, [rsp+0x30]
00007e4ecadd0b18  vmovaps xmm5, [rsp+0x40]
00007e4ecadd0b1e  vmovaps xmm6, [rsp+0x50]
00007e4ecadd0b24  vmovaps xmm7, [rsp+0x60]
00007e4ecadd0b2a  vmovaps xmm8, [rsp+0x70]
00007e4ecadd0b30  vmovaps xmm9, [rsp+0x80]
00007e4ecadd0b39  vmovaps xmm10, [rsp+0x90]
00007e4ecadd0b42  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd0b4b  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd0b54  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd0b5d  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd0b66  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd0b6f  add rsp, 0xF0
00007e4ecadd0b76  pop r11
00007e4ecadd0b78  pop r10
00007e4ecadd0b7a  pop r9
00007e4ecadd0b7c  pop r8
00007e4ecadd0b7e  pop rsi
00007e4ecadd0b7f  pop rdi
00007e4ecadd0b80  pop rdx
00007e4ecadd0b81  pop rcx
00007e4ecadd0b82  pop rax
00007e4ecadd0b83  add rsp, 0x08
00007e4ecadd0b87  jmp 0x00007E4ECADCF631
00007e4ecadd0b8c  sub rsp, 0x08
00007e4ecadd0b90  push rax
00007e4ecadd0b91  push rcx
00007e4ecadd0b92  push rdx
00007e4ecadd0b93  push rdi
00007e4ecadd0b94  push rsi
00007e4ecadd0b95  push r8
00007e4ecadd0b97  push r9
00007e4ecadd0b99  push r10
00007e4ecadd0b9b  push r11
00007e4ecadd0b9d  sub rsp, 0xF0
00007e4ecadd0ba4  vmovaps [rsp], xmm0
00007e4ecadd0ba9  vmovaps [rsp+0x10], xmm1
00007e4ecadd0baf  vmovaps [rsp+0x20], xmm2
00007e4ecadd0bb5  vmovaps [rsp+0x30], xmm3
00007e4ecadd0bbb  vmovaps [rsp+0x40], xmm4
00007e4ecadd0bc1  vmovaps [rsp+0x50], xmm5
00007e4ecadd0bc7  vmovaps [rsp+0x60], xmm6
00007e4ecadd0bcd  vmovaps [rsp+0x70], xmm7
00007e4ecadd0bd3  vmovaps [rsp+0x80], xmm8
00007e4ecadd0bdc  vmovaps [rsp+0x90], xmm9
00007e4ecadd0be5  vmovaps [rsp+0xA0], xmm10
00007e4ecadd0bee  vmovaps [rsp+0xB0], xmm11
00007e4ecadd0bf7  vmovaps [rsp+0xC0], xmm12
00007e4ecadd0c00  vmovaps [rsp+0xD0], xmm14
00007e4ecadd0c09  vmovaps [rsp+0xE0], xmm15
00007e4ecadd0c12  sub rsp, 0x30
00007e4ecadd0c16  movaps [rsp], xmm13
00007e4ecadd0c1b  movaps [rsp+0x10], xmm14
00007e4ecadd0c21  movaps [rsp+0x20], xmm2
00007e4ecadd0c26  lea rdi, [rsp]
00007e4ecadd0c2a  mov esi, 0x00
00007e4ecadd0c2f  mov rax, 0x5784BC1F5530
00007e4ecadd0c39  call rax
00007e4ecadd0c3b  movaps xmm13, [rsp]
00007e4ecadd0c40  add rsp, 0x30
00007e4ecadd0c44  vmovaps xmm0, [rsp]
00007e4ecadd0c49  vmovaps xmm1, [rsp+0x10]
00007e4ecadd0c4f  vmovaps xmm2, [rsp+0x20]
00007e4ecadd0c55  vmovaps xmm3, [rsp+0x30]
00007e4ecadd0c5b  vmovaps xmm4, [rsp+0x40]
00007e4ecadd0c61  vmovaps xmm5, [rsp+0x50]
00007e4ecadd0c67  vmovaps xmm6, [rsp+0x60]
00007e4ecadd0c6d  vmovaps xmm7, [rsp+0x70]
00007e4ecadd0c73  vmovaps xmm8, [rsp+0x80]
00007e4ecadd0c7c  vmovaps xmm9, [rsp+0x90]
00007e4ecadd0c85  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd0c8e  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd0c97  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd0ca0  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd0ca9  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd0cb2  add rsp, 0xF0
00007e4ecadd0cb9  pop r11
00007e4ecadd0cbb  pop r10
00007e4ecadd0cbd  pop r9
00007e4ecadd0cbf  pop r8
00007e4ecadd0cc1  pop rsi
00007e4ecadd0cc2  pop rdi
00007e4ecadd0cc3  pop rdx
00007e4ecadd0cc4  pop rcx
00007e4ecadd0cc5  pop rax
00007e4ecadd0cc6  add rsp, 0x08
00007e4ecadd0cca  jmp 0x00007E4ECADCF64C
00007e4ecadd0ccf  sub rsp, 0x08
00007e4ecadd0cd3  push rax
00007e4ecadd0cd4  push rcx
00007e4ecadd0cd5  push rdx
00007e4ecadd0cd6  push rdi
00007e4ecadd0cd7  push rsi
00007e4ecadd0cd8  push r8
00007e4ecadd0cda  push r9
00007e4ecadd0cdc  push r10
00007e4ecadd0cde  push r11
00007e4ecadd0ce0  sub rsp, 0xF0
00007e4ecadd0ce7  vmovaps [rsp], xmm0
00007e4ecadd0cec  vmovaps [rsp+0x10], xmm2
00007e4ecadd0cf2  vmovaps [rsp+0x20], xmm3
00007e4ecadd0cf8  vmovaps [rsp+0x30], xmm4
00007e4ecadd0cfe  vmovaps [rsp+0x40], xmm5
00007e4ecadd0d04  vmovaps [rsp+0x50], xmm6
00007e4ecadd0d0a  vmovaps [rsp+0x60], xmm7
00007e4ecadd0d10  vmovaps [rsp+0x70], xmm8
00007e4ecadd0d16  vmovaps [rsp+0x80], xmm9
00007e4ecadd0d1f  vmovaps [rsp+0x90], xmm10
00007e4ecadd0d28  vmovaps [rsp+0xA0], xmm11
00007e4ecadd0d31  vmovaps [rsp+0xB0], xmm12
00007e4ecadd0d3a  vmovaps [rsp+0xC0], xmm13
00007e4ecadd0d43  vmovaps [rsp+0xD0], xmm14
00007e4ecadd0d4c  vmovaps [rsp+0xE0], xmm15
00007e4ecadd0d55  sub rsp, 0x30
00007e4ecadd0d59  movaps [rsp], xmm1
00007e4ecadd0d5d  movaps [rsp+0x10], xmm10
00007e4ecadd0d63  movaps [rsp+0x20], xmm2
00007e4ecadd0d68  lea rdi, [rsp]
00007e4ecadd0d6c  mov esi, 0x00
00007e4ecadd0d71  mov rax, 0x5784BC1F5530
00007e4ecadd0d7b  call rax
00007e4ecadd0d7d  movaps xmm1, [rsp]
00007e4ecadd0d81  add rsp, 0x30
00007e4ecadd0d85  vmovaps xmm0, [rsp]
00007e4ecadd0d8a  vmovaps xmm2, [rsp+0x10]
00007e4ecadd0d90  vmovaps xmm3, [rsp+0x20]
00007e4ecadd0d96  vmovaps xmm4, [rsp+0x30]
00007e4ecadd0d9c  vmovaps xmm5, [rsp+0x40]
00007e4ecadd0da2  vmovaps xmm6, [rsp+0x50]
00007e4ecadd0da8  vmovaps xmm7, [rsp+0x60]
00007e4ecadd0dae  vmovaps xmm8, [rsp+0x70]
00007e4ecadd0db4  vmovaps xmm9, [rsp+0x80]
00007e4ecadd0dbd  vmovaps xmm10, [rsp+0x90]
00007e4ecadd0dc6  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd0dcf  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd0dd8  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd0de1  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd0dea  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd0df3  add rsp, 0xF0
00007e4ecadd0dfa  pop r11
00007e4ecadd0dfc  pop r10
00007e4ecadd0dfe  pop r9
00007e4ecadd0e00  pop r8
00007e4ecadd0e02  pop rsi
00007e4ecadd0e03  pop rdi
00007e4ecadd0e04  pop rdx
00007e4ecadd0e05  pop rcx
00007e4ecadd0e06  pop rax
00007e4ecadd0e07  add rsp, 0x08
00007e4ecadd0e0b  jmp 0x00007E4ECADCF6B4
00007e4ecadd0e10  sub rsp, 0x08
00007e4ecadd0e14  push rax
00007e4ecadd0e15  push rcx
00007e4ecadd0e16  push rdx
00007e4ecadd0e17  push rdi
00007e4ecadd0e18  push rsi
00007e4ecadd0e19  push r8
00007e4ecadd0e1b  push r9
00007e4ecadd0e1d  push r10
00007e4ecadd0e1f  push r11
00007e4ecadd0e21  sub rsp, 0xF0
00007e4ecadd0e28  vmovaps [rsp], xmm0
00007e4ecadd0e2d  vmovaps [rsp+0x10], xmm1
00007e4ecadd0e33  vmovaps [rsp+0x20], xmm2
00007e4ecadd0e39  vmovaps [rsp+0x30], xmm3
00007e4ecadd0e3f  vmovaps [rsp+0x40], xmm4
00007e4ecadd0e45  vmovaps [rsp+0x50], xmm5
00007e4ecadd0e4b  vmovaps [rsp+0x60], xmm6
00007e4ecadd0e51  vmovaps [rsp+0x70], xmm7
00007e4ecadd0e57  vmovaps [rsp+0x80], xmm8
00007e4ecadd0e60  vmovaps [rsp+0x90], xmm9
00007e4ecadd0e69  vmovaps [rsp+0xA0], xmm10
00007e4ecadd0e72  vmovaps [rsp+0xB0], xmm11
00007e4ecadd0e7b  vmovaps [rsp+0xC0], xmm12
00007e4ecadd0e84  vmovaps [rsp+0xD0], xmm13
00007e4ecadd0e8d  vmovaps [rsp+0xE0], xmm14
00007e4ecadd0e96  sub rsp, 0x30
00007e4ecadd0e9a  movaps [rsp], xmm15
00007e4ecadd0e9f  movaps [rsp+0x10], xmm10
00007e4ecadd0ea5  movaps [rsp+0x20], xmm2
00007e4ecadd0eaa  lea rdi, [rsp]
00007e4ecadd0eae  mov esi, 0x00
00007e4ecadd0eb3  mov rax, 0x5784BC1F5530
00007e4ecadd0ebd  call rax
00007e4ecadd0ebf  movaps xmm15, [rsp]
00007e4ecadd0ec4  add rsp, 0x30
00007e4ecadd0ec8  vmovaps xmm0, [rsp]
00007e4ecadd0ecd  vmovaps xmm1, [rsp+0x10]
00007e4ecadd0ed3  vmovaps xmm2, [rsp+0x20]
00007e4ecadd0ed9  vmovaps xmm3, [rsp+0x30]
00007e4ecadd0edf  vmovaps xmm4, [rsp+0x40]
00007e4ecadd0ee5  vmovaps xmm5, [rsp+0x50]
00007e4ecadd0eeb  vmovaps xmm6, [rsp+0x60]
00007e4ecadd0ef1  vmovaps xmm7, [rsp+0x70]
00007e4ecadd0ef7  vmovaps xmm8, [rsp+0x80]
00007e4ecadd0f00  vmovaps xmm9, [rsp+0x90]
00007e4ecadd0f09  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd0f12  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd0f1b  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd0f24  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd0f2d  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd0f36  add rsp, 0xF0
00007e4ecadd0f3d  pop r11
00007e4ecadd0f3f  pop r10
00007e4ecadd0f41  pop r9
00007e4ecadd0f43  pop r8
00007e4ecadd0f45  pop rsi
00007e4ecadd0f46  pop rdi
00007e4ecadd0f47  pop rdx
00007e4ecadd0f48  pop rcx
00007e4ecadd0f49  pop rax
00007e4ecadd0f4a  add rsp, 0x08
00007e4ecadd0f4e  jmp 0x00007E4ECADCF706
00007e4ecadd0f53  sub rsp, 0x08
00007e4ecadd0f57  push rax
00007e4ecadd0f58  push rcx
00007e4ecadd0f59  push rdx
00007e4ecadd0f5a  push rdi
00007e4ecadd0f5b  push rsi
00007e4ecadd0f5c  push r8
00007e4ecadd0f5e  push r9
00007e4ecadd0f60  push r10
00007e4ecadd0f62  push r11
00007e4ecadd0f64  sub rsp, 0xF0
00007e4ecadd0f6b  vmovaps [rsp], xmm0
00007e4ecadd0f70  vmovaps [rsp+0x10], xmm2
00007e4ecadd0f76  vmovaps [rsp+0x20], xmm3
00007e4ecadd0f7c  vmovaps [rsp+0x30], xmm4
00007e4ecadd0f82  vmovaps [rsp+0x40], xmm5
00007e4ecadd0f88  vmovaps [rsp+0x50], xmm6
00007e4ecadd0f8e  vmovaps [rsp+0x60], xmm7
00007e4ecadd0f94  vmovaps [rsp+0x70], xmm8
00007e4ecadd0f9a  vmovaps [rsp+0x80], xmm9
00007e4ecadd0fa3  vmovaps [rsp+0x90], xmm10
00007e4ecadd0fac  vmovaps [rsp+0xA0], xmm11
00007e4ecadd0fb5  vmovaps [rsp+0xB0], xmm12
00007e4ecadd0fbe  vmovaps [rsp+0xC0], xmm13
00007e4ecadd0fc7  vmovaps [rsp+0xD0], xmm14
00007e4ecadd0fd0  vmovaps [rsp+0xE0], xmm15
00007e4ecadd0fd9  sub rsp, 0x30
00007e4ecadd0fdd  movaps [rsp], xmm1
00007e4ecadd0fe1  movaps [rsp+0x10], xmm10
00007e4ecadd0fe7  movaps [rsp+0x20], xmm12
00007e4ecadd0fed  lea rdi, [rsp]
00007e4ecadd0ff1  mov esi, 0x00
00007e4ecadd0ff6  mov rax, 0x5784BC1F5530
00007e4ecadd1000  call rax
00007e4ecadd1002  movaps xmm1, [rsp]
00007e4ecadd1006  add rsp, 0x30
00007e4ecadd100a  vmovaps xmm0, [rsp]
00007e4ecadd100f  vmovaps xmm2, [rsp+0x10]
00007e4ecadd1015  vmovaps xmm3, [rsp+0x20]
00007e4ecadd101b  vmovaps xmm4, [rsp+0x30]
00007e4ecadd1021  vmovaps xmm5, [rsp+0x40]
00007e4ecadd1027  vmovaps xmm6, [rsp+0x50]
00007e4ecadd102d  vmovaps xmm7, [rsp+0x60]
00007e4ecadd1033  vmovaps xmm8, [rsp+0x70]
00007e4ecadd1039  vmovaps xmm9, [rsp+0x80]
00007e4ecadd1042  vmovaps xmm10, [rsp+0x90]
00007e4ecadd104b  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd1054  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd105d  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd1066  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd106f  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd1078  add rsp, 0xF0
00007e4ecadd107f  pop r11
00007e4ecadd1081  pop r10
00007e4ecadd1083  pop r9
00007e4ecadd1085  pop r8
00007e4ecadd1087  pop rsi
00007e4ecadd1088  pop rdi
00007e4ecadd1089  pop rdx
00007e4ecadd108a  pop rcx
00007e4ecadd108b  pop rax
00007e4ecadd108c  add rsp, 0x08
00007e4ecadd1090  jmp 0x00007E4ECADCF732
00007e4ecadd1095  sub rsp, 0x08
00007e4ecadd1099  push rax
00007e4ecadd109a  push rcx
00007e4ecadd109b  push rdx
00007e4ecadd109c  push rdi
00007e4ecadd109d  push rsi
00007e4ecadd109e  push r8
00007e4ecadd10a0  push r9
00007e4ecadd10a2  push r10
00007e4ecadd10a4  push r11
00007e4ecadd10a6  sub rsp, 0xF0
00007e4ecadd10ad  vmovaps [rsp], xmm0
00007e4ecadd10b2  vmovaps [rsp+0x10], xmm1
00007e4ecadd10b8  vmovaps [rsp+0x20], xmm2
00007e4ecadd10be  vmovaps [rsp+0x30], xmm3
00007e4ecadd10c4  vmovaps [rsp+0x40], xmm4
00007e4ecadd10ca  vmovaps [rsp+0x50], xmm5
00007e4ecadd10d0  vmovaps [rsp+0x60], xmm6
00007e4ecadd10d6  vmovaps [rsp+0x70], xmm7
00007e4ecadd10dc  vmovaps [rsp+0x80], xmm8
00007e4ecadd10e5  vmovaps [rsp+0x90], xmm9
00007e4ecadd10ee  vmovaps [rsp+0xA0], xmm10
00007e4ecadd10f7  vmovaps [rsp+0xB0], xmm11
00007e4ecadd1100  vmovaps [rsp+0xC0], xmm12
00007e4ecadd1109  vmovaps [rsp+0xD0], xmm13
00007e4ecadd1112  vmovaps [rsp+0xE0], xmm14
00007e4ecadd111b  sub rsp, 0x30
00007e4ecadd111f  movaps [rsp], xmm15
00007e4ecadd1124  movaps [rsp+0x10], xmm10
00007e4ecadd112a  movaps [rsp+0x20], xmm12
00007e4ecadd1130  lea rdi, [rsp]
00007e4ecadd1134  mov esi, 0x00
00007e4ecadd1139  mov rax, 0x5784BC1F5530
00007e4ecadd1143  call rax
00007e4ecadd1145  movaps xmm15, [rsp]
00007e4ecadd114a  add rsp, 0x30
00007e4ecadd114e  vmovaps xmm0, [rsp]
00007e4ecadd1153  vmovaps xmm1, [rsp+0x10]
00007e4ecadd1159  vmovaps xmm2, [rsp+0x20]
00007e4ecadd115f  vmovaps xmm3, [rsp+0x30]
00007e4ecadd1165  vmovaps xmm4, [rsp+0x40]
00007e4ecadd116b  vmovaps xmm5, [rsp+0x50]
00007e4ecadd1171  vmovaps xmm6, [rsp+0x60]
00007e4ecadd1177  vmovaps xmm7, [rsp+0x70]
00007e4ecadd117d  vmovaps xmm8, [rsp+0x80]
00007e4ecadd1186  vmovaps xmm9, [rsp+0x90]
00007e4ecadd118f  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd1198  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd11a1  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd11aa  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd11b3  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd11bc  add rsp, 0xF0
00007e4ecadd11c3  pop r11
00007e4ecadd11c5  pop r10
00007e4ecadd11c7  pop r9
00007e4ecadd11c9  pop r8
00007e4ecadd11cb  pop rsi
00007e4ecadd11cc  pop rdi
00007e4ecadd11cd  pop rdx
00007e4ecadd11ce  pop rcx
00007e4ecadd11cf  pop rax
00007e4ecadd11d0  add rsp, 0x08
00007e4ecadd11d4  jmp 0x00007E4ECADCF75E
00007e4ecadd11d9  call 0x00007E4ECABFF430
00007e4ecadd11de  jmp 0x00007E4ECADCF7EE
00007e4ecadd11e3  call 0x00007E4ECABFF430
00007e4ecadd11e8  jmp 0x00007E4ECADCF801
00007e4ecadd11ed  sub rsp, 0x08
00007e4ecadd11f1  push rax
00007e4ecadd11f2  push rcx
00007e4ecadd11f3  push rdx
00007e4ecadd11f4  push rdi
00007e4ecadd11f5  push rsi
00007e4ecadd11f6  push r8
00007e4ecadd11f8  push r9
00007e4ecadd11fa  push r10
00007e4ecadd11fc  push r11
00007e4ecadd11fe  sub rsp, 0xF0
00007e4ecadd1205  vmovaps [rsp], xmm0
00007e4ecadd120a  vmovaps [rsp+0x10], xmm2
00007e4ecadd1210  vmovaps [rsp+0x20], xmm3
00007e4ecadd1216  vmovaps [rsp+0x30], xmm4
00007e4ecadd121c  vmovaps [rsp+0x40], xmm5
00007e4ecadd1222  vmovaps [rsp+0x50], xmm6
00007e4ecadd1228  vmovaps [rsp+0x60], xmm7
00007e4ecadd122e  vmovaps [rsp+0x70], xmm8
00007e4ecadd1234  vmovaps [rsp+0x80], xmm9
00007e4ecadd123d  vmovaps [rsp+0x90], xmm10
00007e4ecadd1246  vmovaps [rsp+0xA0], xmm11
00007e4ecadd124f  vmovaps [rsp+0xB0], xmm12
00007e4ecadd1258  vmovaps [rsp+0xC0], xmm13
00007e4ecadd1261  vmovaps [rsp+0xD0], xmm14
00007e4ecadd126a  vmovaps [rsp+0xE0], xmm15
00007e4ecadd1273  sub rsp, 0x30
00007e4ecadd1277  movaps [rsp], xmm1
00007e4ecadd127b  movaps [rsp+0x10], xmm13
00007e4ecadd1281  movaps [rsp+0x20], xmm2
00007e4ecadd1286  lea rdi, [rsp]
00007e4ecadd128a  mov esi, 0x00
00007e4ecadd128f  mov rax, 0x5784BC1F5530
00007e4ecadd1299  call rax
00007e4ecadd129b  movaps xmm1, [rsp]
00007e4ecadd129f  add rsp, 0x30
00007e4ecadd12a3  vmovaps xmm0, [rsp]
00007e4ecadd12a8  vmovaps xmm2, [rsp+0x10]
00007e4ecadd12ae  vmovaps xmm3, [rsp+0x20]
00007e4ecadd12b4  vmovaps xmm4, [rsp+0x30]
00007e4ecadd12ba  vmovaps xmm5, [rsp+0x40]
00007e4ecadd12c0  vmovaps xmm6, [rsp+0x50]
00007e4ecadd12c6  vmovaps xmm7, [rsp+0x60]
00007e4ecadd12cc  vmovaps xmm8, [rsp+0x70]
00007e4ecadd12d2  vmovaps xmm9, [rsp+0x80]
00007e4ecadd12db  vmovaps xmm10, [rsp+0x90]
00007e4ecadd12e4  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd12ed  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd12f6  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd12ff  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd1308  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd1311  add rsp, 0xF0
00007e4ecadd1318  pop r11
00007e4ecadd131a  pop r10
00007e4ecadd131c  pop r9
00007e4ecadd131e  pop r8
00007e4ecadd1320  pop rsi
00007e4ecadd1321  pop rdi
00007e4ecadd1322  pop rdx
00007e4ecadd1323  pop rcx
00007e4ecadd1324  pop rax
00007e4ecadd1325  add rsp, 0x08
00007e4ecadd1329  jmp 0x00007E4ECADCF82C
00007e4ecadd132e  call 0x00007E4ECAC0E760
00007e4ecadd1333  jmp 0x00007E4ECADCF839
00007e4ecadd1338  sub rsp, 0x08
00007e4ecadd133c  push rax
00007e4ecadd133d  push rcx
00007e4ecadd133e  push rdx
00007e4ecadd133f  push rdi
00007e4ecadd1340  push rsi
00007e4ecadd1341  push r8
00007e4ecadd1343  push r9
00007e4ecadd1345  push r10
00007e4ecadd1347  push r11
00007e4ecadd1349  sub rsp, 0xF0
00007e4ecadd1350  vmovaps [rsp], xmm0
00007e4ecadd1355  vmovaps [rsp+0x10], xmm1
00007e4ecadd135b  vmovaps [rsp+0x20], xmm2
00007e4ecadd1361  vmovaps [rsp+0x30], xmm3
00007e4ecadd1367  vmovaps [rsp+0x40], xmm4
00007e4ecadd136d  vmovaps [rsp+0x50], xmm5
00007e4ecadd1373  vmovaps [rsp+0x60], xmm6
00007e4ecadd1379  vmovaps [rsp+0x70], xmm7
00007e4ecadd137f  vmovaps [rsp+0x80], xmm8
00007e4ecadd1388  vmovaps [rsp+0x90], xmm9
00007e4ecadd1391  vmovaps [rsp+0xA0], xmm10
00007e4ecadd139a  vmovaps [rsp+0xB0], xmm11
00007e4ecadd13a3  vmovaps [rsp+0xC0], xmm12
00007e4ecadd13ac  vmovaps [rsp+0xD0], xmm14
00007e4ecadd13b5  vmovaps [rsp+0xE0], xmm15
00007e4ecadd13be  sub rsp, 0x30
00007e4ecadd13c2  movaps [rsp], xmm13
00007e4ecadd13c7  movaps [rsp+0x10], xmm2
00007e4ecadd13cc  movaps [rsp+0x20], xmm1
00007e4ecadd13d1  lea rdi, [rsp]
00007e4ecadd13d5  mov esi, 0x00
00007e4ecadd13da  mov rax, 0x5784BC1F5530
00007e4ecadd13e4  call rax
00007e4ecadd13e6  movaps xmm13, [rsp]
00007e4ecadd13eb  add rsp, 0x30
00007e4ecadd13ef  vmovaps xmm0, [rsp]
00007e4ecadd13f4  vmovaps xmm1, [rsp+0x10]
00007e4ecadd13fa  vmovaps xmm2, [rsp+0x20]
00007e4ecadd1400  vmovaps xmm3, [rsp+0x30]
00007e4ecadd1406  vmovaps xmm4, [rsp+0x40]
00007e4ecadd140c  vmovaps xmm5, [rsp+0x50]
00007e4ecadd1412  vmovaps xmm6, [rsp+0x60]
00007e4ecadd1418  vmovaps xmm7, [rsp+0x70]
00007e4ecadd141e  vmovaps xmm8, [rsp+0x80]
00007e4ecadd1427  vmovaps xmm9, [rsp+0x90]
00007e4ecadd1430  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd1439  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd1442  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd144b  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd1454  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd145d  add rsp, 0xF0
00007e4ecadd1464  pop r11
00007e4ecadd1466  pop r10
00007e4ecadd1468  pop r9
00007e4ecadd146a  pop r8
00007e4ecadd146c  pop rsi
00007e4ecadd146d  pop rdi
00007e4ecadd146e  pop rdx
00007e4ecadd146f  pop rcx
00007e4ecadd1470  pop rax
00007e4ecadd1471  add rsp, 0x08
00007e4ecadd1475  jmp 0x00007E4ECADCF878
00007e4ecadd147a  sub rsp, 0x08
00007e4ecadd147e  push rax
00007e4ecadd147f  push rcx
00007e4ecadd1480  push rdx
00007e4ecadd1481  push rdi
00007e4ecadd1482  push rsi
00007e4ecadd1483  push r8
00007e4ecadd1485  push r9
00007e4ecadd1487  push r10
00007e4ecadd1489  push r11
00007e4ecadd148b  sub rsp, 0xF0
00007e4ecadd1492  vmovaps [rsp], xmm0
00007e4ecadd1497  vmovaps [rsp+0x10], xmm2
00007e4ecadd149d  vmovaps [rsp+0x20], xmm3
00007e4ecadd14a3  vmovaps [rsp+0x30], xmm4
00007e4ecadd14a9  vmovaps [rsp+0x40], xmm5
00007e4ecadd14af  vmovaps [rsp+0x50], xmm6
00007e4ecadd14b5  vmovaps [rsp+0x60], xmm7
00007e4ecadd14bb  vmovaps [rsp+0x70], xmm8
00007e4ecadd14c1  vmovaps [rsp+0x80], xmm9
00007e4ecadd14ca  vmovaps [rsp+0x90], xmm10
00007e4ecadd14d3  vmovaps [rsp+0xA0], xmm11
00007e4ecadd14dc  vmovaps [rsp+0xB0], xmm12
00007e4ecadd14e5  vmovaps [rsp+0xC0], xmm13
00007e4ecadd14ee  vmovaps [rsp+0xD0], xmm14
00007e4ecadd14f7  vmovaps [rsp+0xE0], xmm15
00007e4ecadd1500  sub rsp, 0x30
00007e4ecadd1504  movaps [rsp], xmm1
00007e4ecadd1508  movaps [rsp+0x10], xmm15
00007e4ecadd150e  movaps [rsp+0x20], xmm2
00007e4ecadd1513  lea rdi, [rsp]
00007e4ecadd1517  mov esi, 0x00
00007e4ecadd151c  mov rax, 0x5784BC1F5530
00007e4ecadd1526  call rax
00007e4ecadd1528  movaps xmm1, [rsp]
00007e4ecadd152c  add rsp, 0x30
00007e4ecadd1530  vmovaps xmm0, [rsp]
00007e4ecadd1535  vmovaps xmm2, [rsp+0x10]
00007e4ecadd153b  vmovaps xmm3, [rsp+0x20]
00007e4ecadd1541  vmovaps xmm4, [rsp+0x30]
00007e4ecadd1547  vmovaps xmm5, [rsp+0x40]
00007e4ecadd154d  vmovaps xmm6, [rsp+0x50]
00007e4ecadd1553  vmovaps xmm7, [rsp+0x60]
00007e4ecadd1559  vmovaps xmm8, [rsp+0x70]
00007e4ecadd155f  vmovaps xmm9, [rsp+0x80]
00007e4ecadd1568  vmovaps xmm10, [rsp+0x90]
00007e4ecadd1571  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd157a  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd1583  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd158c  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd1595  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd159e  add rsp, 0xF0
00007e4ecadd15a5  pop r11
00007e4ecadd15a7  pop r10
00007e4ecadd15a9  pop r9
00007e4ecadd15ab  pop r8
00007e4ecadd15ad  pop rsi
00007e4ecadd15ae  pop rdi
00007e4ecadd15af  pop rdx
00007e4ecadd15b0  pop rcx
00007e4ecadd15b1  pop rax
00007e4ecadd15b2  add rsp, 0x08
00007e4ecadd15b6  jmp 0x00007E4ECADCF8AC
00007e4ecadd15bb  sub rsp, 0x08
00007e4ecadd15bf  push rax
00007e4ecadd15c0  push rcx
00007e4ecadd15c1  push rdx
00007e4ecadd15c2  push rdi
00007e4ecadd15c3  push rsi
00007e4ecadd15c4  push r8
00007e4ecadd15c6  push r9
00007e4ecadd15c8  push r10
00007e4ecadd15ca  push r11
00007e4ecadd15cc  sub rsp, 0xF0
00007e4ecadd15d3  vmovaps [rsp], xmm0
00007e4ecadd15d8  vmovaps [rsp+0x10], xmm1
00007e4ecadd15de  vmovaps [rsp+0x20], xmm2
00007e4ecadd15e4  vmovaps [rsp+0x30], xmm3
00007e4ecadd15ea  vmovaps [rsp+0x40], xmm4
00007e4ecadd15f0  vmovaps [rsp+0x50], xmm5
00007e4ecadd15f6  vmovaps [rsp+0x60], xmm6
00007e4ecadd15fc  vmovaps [rsp+0x70], xmm7
00007e4ecadd1602  vmovaps [rsp+0x80], xmm8
00007e4ecadd160b  vmovaps [rsp+0x90], xmm9
00007e4ecadd1614  vmovaps [rsp+0xA0], xmm10
00007e4ecadd161d  vmovaps [rsp+0xB0], xmm11
00007e4ecadd1626  vmovaps [rsp+0xC0], xmm12
00007e4ecadd162f  vmovaps [rsp+0xD0], xmm13
00007e4ecadd1638  vmovaps [rsp+0xE0], xmm15
00007e4ecadd1641  sub rsp, 0x30
00007e4ecadd1645  movaps [rsp], xmm14
00007e4ecadd164a  movaps [rsp+0x10], xmm2
00007e4ecadd164f  movaps [rsp+0x20], xmm15
00007e4ecadd1655  lea rdi, [rsp]
00007e4ecadd1659  mov esi, 0x00
00007e4ecadd165e  mov rax, 0x5784BC1F5530
00007e4ecadd1668  call rax
00007e4ecadd166a  movaps xmm14, [rsp]
00007e4ecadd166f  add rsp, 0x30
00007e4ecadd1673  vmovaps xmm0, [rsp]
00007e4ecadd1678  vmovaps xmm1, [rsp+0x10]
00007e4ecadd167e  vmovaps xmm2, [rsp+0x20]
00007e4ecadd1684  vmovaps xmm3, [rsp+0x30]
00007e4ecadd168a  vmovaps xmm4, [rsp+0x40]
00007e4ecadd1690  vmovaps xmm5, [rsp+0x50]
00007e4ecadd1696  vmovaps xmm6, [rsp+0x60]
00007e4ecadd169c  vmovaps xmm7, [rsp+0x70]
00007e4ecadd16a2  vmovaps xmm8, [rsp+0x80]
00007e4ecadd16ab  vmovaps xmm9, [rsp+0x90]
00007e4ecadd16b4  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd16bd  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd16c6  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd16cf  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd16d8  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd16e1  add rsp, 0xF0
00007e4ecadd16e8  pop r11
00007e4ecadd16ea  pop r10
00007e4ecadd16ec  pop r9
00007e4ecadd16ee  pop r8
00007e4ecadd16f0  pop rsi
00007e4ecadd16f1  pop rdi
00007e4ecadd16f2  pop rdx
00007e4ecadd16f3  pop rcx
00007e4ecadd16f4  pop rax
00007e4ecadd16f5  add rsp, 0x08
00007e4ecadd16f9  jmp 0x00007E4ECADCF8E7
00007e4ecadd16fe  sub rsp, 0x08
00007e4ecadd1702  push rax
00007e4ecadd1703  push rcx
00007e4ecadd1704  push rdx
00007e4ecadd1705  push rdi
00007e4ecadd1706  push rsi
00007e4ecadd1707  push r8
00007e4ecadd1709  push r9
00007e4ecadd170b  push r10
00007e4ecadd170d  push r11
00007e4ecadd170f  sub rsp, 0xF0
00007e4ecadd1716  vmovaps [rsp], xmm0
00007e4ecadd171b  vmovaps [rsp+0x10], xmm1
00007e4ecadd1721  vmovaps [rsp+0x20], xmm2
00007e4ecadd1727  vmovaps [rsp+0x30], xmm3
00007e4ecadd172d  vmovaps [rsp+0x40], xmm4
00007e4ecadd1733  vmovaps [rsp+0x50], xmm5
00007e4ecadd1739  vmovaps [rsp+0x60], xmm6
00007e4ecadd173f  vmovaps [rsp+0x70], xmm7
00007e4ecadd1745  vmovaps [rsp+0x80], xmm8
00007e4ecadd174e  vmovaps [rsp+0x90], xmm9
00007e4ecadd1757  vmovaps [rsp+0xA0], xmm10
00007e4ecadd1760  vmovaps [rsp+0xB0], xmm11
00007e4ecadd1769  vmovaps [rsp+0xC0], xmm12
00007e4ecadd1772  vmovaps [rsp+0xD0], xmm13
00007e4ecadd177b  vmovaps [rsp+0xE0], xmm14
00007e4ecadd1784  sub rsp, 0x30
00007e4ecadd1788  movaps [rsp], xmm15
00007e4ecadd178d  movaps [rsp+0x10], xmm2
00007e4ecadd1792  movaps [rsp+0x20], xmm1
00007e4ecadd1797  lea rdi, [rsp]
00007e4ecadd179b  mov esi, 0x00
00007e4ecadd17a0  mov rax, 0x5784BC1F5530
00007e4ecadd17aa  call rax
00007e4ecadd17ac  movaps xmm15, [rsp]
00007e4ecadd17b1  add rsp, 0x30
00007e4ecadd17b5  vmovaps xmm0, [rsp]
00007e4ecadd17ba  vmovaps xmm1, [rsp+0x10]
00007e4ecadd17c0  vmovaps xmm2, [rsp+0x20]
00007e4ecadd17c6  vmovaps xmm3, [rsp+0x30]
00007e4ecadd17cc  vmovaps xmm4, [rsp+0x40]
00007e4ecadd17d2  vmovaps xmm5, [rsp+0x50]
00007e4ecadd17d8  vmovaps xmm6, [rsp+0x60]
00007e4ecadd17de  vmovaps xmm7, [rsp+0x70]
00007e4ecadd17e4  vmovaps xmm8, [rsp+0x80]
00007e4ecadd17ed  vmovaps xmm9, [rsp+0x90]
00007e4ecadd17f6  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd17ff  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd1808  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd1811  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd181a  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd1823  add rsp, 0xF0
00007e4ecadd182a  pop r11
00007e4ecadd182c  pop r10
00007e4ecadd182e  pop r9
00007e4ecadd1830  pop r8
00007e4ecadd1832  pop rsi
00007e4ecadd1833  pop rdi
00007e4ecadd1834  pop rdx
00007e4ecadd1835  pop rcx
00007e4ecadd1836  pop rax
00007e4ecadd1837  add rsp, 0x08
00007e4ecadd183b  jmp 0x00007E4ECADCF923
00007e4ecadd1840  call 0x00007E4ECABFF430
00007e4ecadd1845  jmp 0x00007E4ECADCF930
00007e4ecadd184a  sub rsp, 0x08
00007e4ecadd184e  push rax
00007e4ecadd184f  push rcx
00007e4ecadd1850  push rdx
00007e4ecadd1851  push rdi
00007e4ecadd1852  push rsi
00007e4ecadd1853  push r8
00007e4ecadd1855  push r9
00007e4ecadd1857  push r10
00007e4ecadd1859  push r11
00007e4ecadd185b  sub rsp, 0xF0
00007e4ecadd1862  vmovaps [rsp], xmm0
00007e4ecadd1867  vmovaps [rsp+0x10], xmm1
00007e4ecadd186d  vmovaps [rsp+0x20], xmm3
00007e4ecadd1873  vmovaps [rsp+0x30], xmm4
00007e4ecadd1879  vmovaps [rsp+0x40], xmm5
00007e4ecadd187f  vmovaps [rsp+0x50], xmm6
00007e4ecadd1885  vmovaps [rsp+0x60], xmm7
00007e4ecadd188b  vmovaps [rsp+0x70], xmm8
00007e4ecadd1891  vmovaps [rsp+0x80], xmm9
00007e4ecadd189a  vmovaps [rsp+0x90], xmm10
00007e4ecadd18a3  vmovaps [rsp+0xA0], xmm11
00007e4ecadd18ac  vmovaps [rsp+0xB0], xmm12
00007e4ecadd18b5  vmovaps [rsp+0xC0], xmm13
00007e4ecadd18be  vmovaps [rsp+0xD0], xmm14
00007e4ecadd18c7  vmovaps [rsp+0xE0], xmm15
00007e4ecadd18d0  sub rsp, 0x30
00007e4ecadd18d4  movaps [rsp], xmm2
00007e4ecadd18d8  movaps [rsp+0x10], xmm1
00007e4ecadd18dd  movaps [rsp+0x20], xmm14
00007e4ecadd18e3  lea rdi, [rsp]
00007e4ecadd18e7  mov esi, 0x00
00007e4ecadd18ec  mov rax, 0x5784BC1F5530
00007e4ecadd18f6  call rax
00007e4ecadd18f8  movaps xmm2, [rsp]
00007e4ecadd18fc  add rsp, 0x30
00007e4ecadd1900  vmovaps xmm0, [rsp]
00007e4ecadd1905  vmovaps xmm1, [rsp+0x10]
00007e4ecadd190b  vmovaps xmm3, [rsp+0x20]
00007e4ecadd1911  vmovaps xmm4, [rsp+0x30]
00007e4ecadd1917  vmovaps xmm5, [rsp+0x40]
00007e4ecadd191d  vmovaps xmm6, [rsp+0x50]
00007e4ecadd1923  vmovaps xmm7, [rsp+0x60]
00007e4ecadd1929  vmovaps xmm8, [rsp+0x70]
00007e4ecadd192f  vmovaps xmm9, [rsp+0x80]
00007e4ecadd1938  vmovaps xmm10, [rsp+0x90]
00007e4ecadd1941  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd194a  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd1953  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd195c  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd1965  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd196e  add rsp, 0xF0
00007e4ecadd1975  pop r11
00007e4ecadd1977  pop r10
00007e4ecadd1979  pop r9
00007e4ecadd197b  pop r8
00007e4ecadd197d  pop rsi
00007e4ecadd197e  pop rdi
00007e4ecadd197f  pop rdx
00007e4ecadd1980  pop rcx
00007e4ecadd1981  pop rax
00007e4ecadd1982  add rsp, 0x08
00007e4ecadd1986  jmp 0x00007E4ECADCF96D
00007e4ecadd198b  sub rsp, 0x08
00007e4ecadd198f  push rax
00007e4ecadd1990  push rcx
00007e4ecadd1991  push rdx
00007e4ecadd1992  push rdi
00007e4ecadd1993  push rsi
00007e4ecadd1994  push r8
00007e4ecadd1996  push r9
00007e4ecadd1998  push r10
00007e4ecadd199a  push r11
00007e4ecadd199c  sub rsp, 0xF0
00007e4ecadd19a3  vmovaps [rsp], xmm0
00007e4ecadd19a8  vmovaps [rsp+0x10], xmm1
00007e4ecadd19ae  vmovaps [rsp+0x20], xmm2
00007e4ecadd19b4  vmovaps [rsp+0x30], xmm3
00007e4ecadd19ba  vmovaps [rsp+0x40], xmm4
00007e4ecadd19c0  vmovaps [rsp+0x50], xmm5
00007e4ecadd19c6  vmovaps [rsp+0x60], xmm6
00007e4ecadd19cc  vmovaps [rsp+0x70], xmm7
00007e4ecadd19d2  vmovaps [rsp+0x80], xmm8
00007e4ecadd19db  vmovaps [rsp+0x90], xmm9
00007e4ecadd19e4  vmovaps [rsp+0xA0], xmm10
00007e4ecadd19ed  vmovaps [rsp+0xB0], xmm11
00007e4ecadd19f6  vmovaps [rsp+0xC0], xmm12
00007e4ecadd19ff  vmovaps [rsp+0xD0], xmm13
00007e4ecadd1a08  vmovaps [rsp+0xE0], xmm14
00007e4ecadd1a11  sub rsp, 0x30
00007e4ecadd1a15  movaps [rsp], xmm15
00007e4ecadd1a1a  movaps [rsp+0x10], xmm14
00007e4ecadd1a20  movaps [rsp+0x20], xmm1
00007e4ecadd1a25  lea rdi, [rsp]
00007e4ecadd1a29  mov esi, 0x00
00007e4ecadd1a2e  mov rax, 0x5784BC1F5530
00007e4ecadd1a38  call rax
00007e4ecadd1a3a  movaps xmm15, [rsp]
00007e4ecadd1a3f  add rsp, 0x30
00007e4ecadd1a43  vmovaps xmm0, [rsp]
00007e4ecadd1a48  vmovaps xmm1, [rsp+0x10]
00007e4ecadd1a4e  vmovaps xmm2, [rsp+0x20]
00007e4ecadd1a54  vmovaps xmm3, [rsp+0x30]
00007e4ecadd1a5a  vmovaps xmm4, [rsp+0x40]
00007e4ecadd1a60  vmovaps xmm5, [rsp+0x50]
00007e4ecadd1a66  vmovaps xmm6, [rsp+0x60]
00007e4ecadd1a6c  vmovaps xmm7, [rsp+0x70]
00007e4ecadd1a72  vmovaps xmm8, [rsp+0x80]
00007e4ecadd1a7b  vmovaps xmm9, [rsp+0x90]
00007e4ecadd1a84  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd1a8d  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd1a96  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd1a9f  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd1aa8  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd1ab1  add rsp, 0xF0
00007e4ecadd1ab8  pop r11
00007e4ecadd1aba  pop r10
00007e4ecadd1abc  pop r9
00007e4ecadd1abe  pop r8
00007e4ecadd1ac0  pop rsi
00007e4ecadd1ac1  pop rdi
00007e4ecadd1ac2  pop rdx
00007e4ecadd1ac3  pop rcx
00007e4ecadd1ac4  pop rax
00007e4ecadd1ac5  add rsp, 0x08
00007e4ecadd1ac9  jmp 0x00007E4ECADCF9E7
00007e4ecadd1ace  call 0x00007E4ECABFF430
00007e4ecadd1ad3  jmp 0x00007E4ECADCF9F4
00007e4ecadd1ad8  sub rsp, 0x08
00007e4ecadd1adc  push rax
00007e4ecadd1add  push rcx
00007e4ecadd1ade  push rdx
00007e4ecadd1adf  push rdi
00007e4ecadd1ae0  push rsi
00007e4ecadd1ae1  push r8
00007e4ecadd1ae3  push r9
00007e4ecadd1ae5  push r10
00007e4ecadd1ae7  push r11
00007e4ecadd1ae9  sub rsp, 0xF0
00007e4ecadd1af0  vmovaps [rsp], xmm0
00007e4ecadd1af5  vmovaps [rsp+0x10], xmm1
00007e4ecadd1afb  vmovaps [rsp+0x20], xmm2
00007e4ecadd1b01  vmovaps [rsp+0x30], xmm3
00007e4ecadd1b07  vmovaps [rsp+0x40], xmm4
00007e4ecadd1b0d  vmovaps [rsp+0x50], xmm5
00007e4ecadd1b13  vmovaps [rsp+0x60], xmm6
00007e4ecadd1b19  vmovaps [rsp+0x70], xmm7
00007e4ecadd1b1f  vmovaps [rsp+0x80], xmm8
00007e4ecadd1b28  vmovaps [rsp+0x90], xmm9
00007e4ecadd1b31  vmovaps [rsp+0xA0], xmm10
00007e4ecadd1b3a  vmovaps [rsp+0xB0], xmm11
00007e4ecadd1b43  vmovaps [rsp+0xC0], xmm12
00007e4ecadd1b4c  vmovaps [rsp+0xD0], xmm13
00007e4ecadd1b55  vmovaps [rsp+0xE0], xmm15
00007e4ecadd1b5e  sub rsp, 0x30
00007e4ecadd1b62  movaps [rsp], xmm14
00007e4ecadd1b67  movaps [rsp+0x10], xmm13
00007e4ecadd1b6d  movaps [rsp+0x20], xmm1
00007e4ecadd1b72  lea rdi, [rsp]
00007e4ecadd1b76  mov esi, 0x00
00007e4ecadd1b7b  mov rax, 0x5784BC1F5530
00007e4ecadd1b85  call rax
00007e4ecadd1b87  movaps xmm14, [rsp]
00007e4ecadd1b8c  add rsp, 0x30
00007e4ecadd1b90  vmovaps xmm0, [rsp]
00007e4ecadd1b95  vmovaps xmm1, [rsp+0x10]
00007e4ecadd1b9b  vmovaps xmm2, [rsp+0x20]
00007e4ecadd1ba1  vmovaps xmm3, [rsp+0x30]
00007e4ecadd1ba7  vmovaps xmm4, [rsp+0x40]
00007e4ecadd1bad  vmovaps xmm5, [rsp+0x50]
00007e4ecadd1bb3  vmovaps xmm6, [rsp+0x60]
00007e4ecadd1bb9  vmovaps xmm7, [rsp+0x70]
00007e4ecadd1bbf  vmovaps xmm8, [rsp+0x80]
00007e4ecadd1bc8  vmovaps xmm9, [rsp+0x90]
00007e4ecadd1bd1  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd1bda  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd1be3  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd1bec  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd1bf5  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd1bfe  add rsp, 0xF0
00007e4ecadd1c05  pop r11
00007e4ecadd1c07  pop r10
00007e4ecadd1c09  pop r9
00007e4ecadd1c0b  pop r8
00007e4ecadd1c0d  pop rsi
00007e4ecadd1c0e  pop rdi
00007e4ecadd1c0f  pop rdx
00007e4ecadd1c10  pop rcx
00007e4ecadd1c11  pop rax
00007e4ecadd1c12  add rsp, 0x08
00007e4ecadd1c16  jmp 0x00007E4ECADCFAAF
00007e4ecadd1c1b  sub rsp, 0x08
00007e4ecadd1c1f  push rax
00007e4ecadd1c20  push rcx
00007e4ecadd1c21  push rdx
00007e4ecadd1c22  push rdi
00007e4ecadd1c23  push rsi
00007e4ecadd1c24  push r8
00007e4ecadd1c26  push r9
00007e4ecadd1c28  push r10
00007e4ecadd1c2a  push r11
00007e4ecadd1c2c  sub rsp, 0xF0
00007e4ecadd1c33  vmovaps [rsp], xmm0
00007e4ecadd1c38  vmovaps [rsp+0x10], xmm1
00007e4ecadd1c3e  vmovaps [rsp+0x20], xmm2
00007e4ecadd1c44  vmovaps [rsp+0x30], xmm3
00007e4ecadd1c4a  vmovaps [rsp+0x40], xmm4
00007e4ecadd1c50  vmovaps [rsp+0x50], xmm5
00007e4ecadd1c56  vmovaps [rsp+0x60], xmm6
00007e4ecadd1c5c  vmovaps [rsp+0x70], xmm7
00007e4ecadd1c62  vmovaps [rsp+0x80], xmm8
00007e4ecadd1c6b  vmovaps [rsp+0x90], xmm9
00007e4ecadd1c74  vmovaps [rsp+0xA0], xmm10
00007e4ecadd1c7d  vmovaps [rsp+0xB0], xmm11
00007e4ecadd1c86  vmovaps [rsp+0xC0], xmm12
00007e4ecadd1c8f  vmovaps [rsp+0xD0], xmm13
00007e4ecadd1c98  vmovaps [rsp+0xE0], xmm14
00007e4ecadd1ca1  sub rsp, 0x30
00007e4ecadd1ca5  movaps [rsp], xmm15
00007e4ecadd1caa  movaps [rsp+0x10], xmm13
00007e4ecadd1cb0  movaps [rsp+0x20], xmm1
00007e4ecadd1cb5  lea rdi, [rsp]
00007e4ecadd1cb9  mov esi, 0x00
00007e4ecadd1cbe  mov rax, 0x5784BC1F5530
00007e4ecadd1cc8  call rax
00007e4ecadd1cca  movaps xmm15, [rsp]
00007e4ecadd1ccf  add rsp, 0x30
00007e4ecadd1cd3  vmovaps xmm0, [rsp]
00007e4ecadd1cd8  vmovaps xmm1, [rsp+0x10]
00007e4ecadd1cde  vmovaps xmm2, [rsp+0x20]
00007e4ecadd1ce4  vmovaps xmm3, [rsp+0x30]
00007e4ecadd1cea  vmovaps xmm4, [rsp+0x40]
00007e4ecadd1cf0  vmovaps xmm5, [rsp+0x50]
00007e4ecadd1cf6  vmovaps xmm6, [rsp+0x60]
00007e4ecadd1cfc  vmovaps xmm7, [rsp+0x70]
00007e4ecadd1d02  vmovaps xmm8, [rsp+0x80]
00007e4ecadd1d0b  vmovaps xmm9, [rsp+0x90]
00007e4ecadd1d14  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd1d1d  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd1d26  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd1d2f  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd1d38  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd1d41  add rsp, 0xF0
00007e4ecadd1d48  pop r11
00007e4ecadd1d4a  pop r10
00007e4ecadd1d4c  pop r9
00007e4ecadd1d4e  pop r8
00007e4ecadd1d50  pop rsi
00007e4ecadd1d51  pop rdi
00007e4ecadd1d52  pop rdx
00007e4ecadd1d53  pop rcx
00007e4ecadd1d54  pop rax
00007e4ecadd1d55  add rsp, 0x08
00007e4ecadd1d59  jmp 0x00007E4ECADCFAEB
00007e4ecadd1d5e  call 0x00007E4ECABFF430
00007e4ecadd1d63  jmp 0x00007E4ECADCFAF8
00007e4ecadd1d68  sub rsp, 0x08
00007e4ecadd1d6c  push rax
00007e4ecadd1d6d  push rcx
00007e4ecadd1d6e  push rdx
00007e4ecadd1d6f  push rdi
00007e4ecadd1d70  push rsi
00007e4ecadd1d71  push r8
00007e4ecadd1d73  push r9
00007e4ecadd1d75  push r10
00007e4ecadd1d77  push r11
00007e4ecadd1d79  sub rsp, 0xF0
00007e4ecadd1d80  vmovaps [rsp], xmm0
00007e4ecadd1d85  vmovaps [rsp+0x10], xmm1
00007e4ecadd1d8b  vmovaps [rsp+0x20], xmm2
00007e4ecadd1d91  vmovaps [rsp+0x30], xmm3
00007e4ecadd1d97  vmovaps [rsp+0x40], xmm4
00007e4ecadd1d9d  vmovaps [rsp+0x50], xmm5
00007e4ecadd1da3  vmovaps [rsp+0x60], xmm6
00007e4ecadd1da9  vmovaps [rsp+0x70], xmm7
00007e4ecadd1daf  vmovaps [rsp+0x80], xmm8
00007e4ecadd1db8  vmovaps [rsp+0x90], xmm9
00007e4ecadd1dc1  vmovaps [rsp+0xA0], xmm10
00007e4ecadd1dca  vmovaps [rsp+0xB0], xmm11
00007e4ecadd1dd3  vmovaps [rsp+0xC0], xmm12
00007e4ecadd1ddc  vmovaps [rsp+0xD0], xmm13
00007e4ecadd1de5  vmovaps [rsp+0xE0], xmm15
00007e4ecadd1dee  sub rsp, 0x30
00007e4ecadd1df2  movaps [rsp], xmm14
00007e4ecadd1df7  movaps [rsp+0x10], xmm13
00007e4ecadd1dfd  movaps [rsp+0x20], xmm2
00007e4ecadd1e02  lea rdi, [rsp]
00007e4ecadd1e06  mov esi, 0x00
00007e4ecadd1e0b  mov rax, 0x5784BC1F5530
00007e4ecadd1e15  call rax
00007e4ecadd1e17  movaps xmm14, [rsp]
00007e4ecadd1e1c  add rsp, 0x30
00007e4ecadd1e20  vmovaps xmm0, [rsp]
00007e4ecadd1e25  vmovaps xmm1, [rsp+0x10]
00007e4ecadd1e2b  vmovaps xmm2, [rsp+0x20]
00007e4ecadd1e31  vmovaps xmm3, [rsp+0x30]
00007e4ecadd1e37  vmovaps xmm4, [rsp+0x40]
00007e4ecadd1e3d  vmovaps xmm5, [rsp+0x50]
00007e4ecadd1e43  vmovaps xmm6, [rsp+0x60]
00007e4ecadd1e49  vmovaps xmm7, [rsp+0x70]
00007e4ecadd1e4f  vmovaps xmm8, [rsp+0x80]
00007e4ecadd1e58  vmovaps xmm9, [rsp+0x90]
00007e4ecadd1e61  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd1e6a  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd1e73  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd1e7c  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd1e85  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd1e8e  add rsp, 0xF0
00007e4ecadd1e95  pop r11
00007e4ecadd1e97  pop r10
00007e4ecadd1e99  pop r9
00007e4ecadd1e9b  pop r8
00007e4ecadd1e9d  pop rsi
00007e4ecadd1e9e  pop rdi
00007e4ecadd1e9f  pop rdx
00007e4ecadd1ea0  pop rcx
00007e4ecadd1ea1  pop rax
00007e4ecadd1ea2  add rsp, 0x08
00007e4ecadd1ea6  jmp 0x00007E4ECADCFB24
00007e4ecadd1eab  sub rsp, 0x08
00007e4ecadd1eaf  push rax
00007e4ecadd1eb0  push rcx
00007e4ecadd1eb1  push rdx
00007e4ecadd1eb2  push rdi
00007e4ecadd1eb3  push rsi
00007e4ecadd1eb4  push r8
00007e4ecadd1eb6  push r9
00007e4ecadd1eb8  push r10
00007e4ecadd1eba  push r11
00007e4ecadd1ebc  sub rsp, 0xF0
00007e4ecadd1ec3  vmovaps [rsp], xmm0
00007e4ecadd1ec8  vmovaps [rsp+0x10], xmm2
00007e4ecadd1ece  vmovaps [rsp+0x20], xmm3
00007e4ecadd1ed4  vmovaps [rsp+0x30], xmm4
00007e4ecadd1eda  vmovaps [rsp+0x40], xmm5
00007e4ecadd1ee0  vmovaps [rsp+0x50], xmm6
00007e4ecadd1ee6  vmovaps [rsp+0x60], xmm7
00007e4ecadd1eec  vmovaps [rsp+0x70], xmm8
00007e4ecadd1ef2  vmovaps [rsp+0x80], xmm9
00007e4ecadd1efb  vmovaps [rsp+0x90], xmm10
00007e4ecadd1f04  vmovaps [rsp+0xA0], xmm11
00007e4ecadd1f0d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd1f16  vmovaps [rsp+0xC0], xmm13
00007e4ecadd1f1f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd1f28  vmovaps [rsp+0xE0], xmm15
00007e4ecadd1f31  sub rsp, 0x30
00007e4ecadd1f35  movaps [rsp], xmm1
00007e4ecadd1f39  movaps [rsp+0x10], xmm13
00007e4ecadd1f3f  movaps [rsp+0x20], xmm2
00007e4ecadd1f44  lea rdi, [rsp]
00007e4ecadd1f48  mov esi, 0x00
00007e4ecadd1f4d  mov rax, 0x5784BC1F5530
00007e4ecadd1f57  call rax
00007e4ecadd1f59  movaps xmm1, [rsp]
00007e4ecadd1f5d  add rsp, 0x30
00007e4ecadd1f61  vmovaps xmm0, [rsp]
00007e4ecadd1f66  vmovaps xmm2, [rsp+0x10]
00007e4ecadd1f6c  vmovaps xmm3, [rsp+0x20]
00007e4ecadd1f72  vmovaps xmm4, [rsp+0x30]
00007e4ecadd1f78  vmovaps xmm5, [rsp+0x40]
00007e4ecadd1f7e  vmovaps xmm6, [rsp+0x50]
00007e4ecadd1f84  vmovaps xmm7, [rsp+0x60]
00007e4ecadd1f8a  vmovaps xmm8, [rsp+0x70]
00007e4ecadd1f90  vmovaps xmm9, [rsp+0x80]
00007e4ecadd1f99  vmovaps xmm10, [rsp+0x90]
00007e4ecadd1fa2  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd1fab  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd1fb4  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd1fbd  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd1fc6  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd1fcf  add rsp, 0xF0
00007e4ecadd1fd6  pop r11
00007e4ecadd1fd8  pop r10
00007e4ecadd1fda  pop r9
00007e4ecadd1fdc  pop r8
00007e4ecadd1fde  pop rsi
00007e4ecadd1fdf  pop rdi
00007e4ecadd1fe0  pop rdx
00007e4ecadd1fe1  pop rcx
00007e4ecadd1fe2  pop rax
00007e4ecadd1fe3  add rsp, 0x08
00007e4ecadd1fe7  jmp 0x00007E4ECADCFB52
00007e4ecadd1fec  sub rsp, 0x08
00007e4ecadd1ff0  push rax
00007e4ecadd1ff1  push rcx
00007e4ecadd1ff2  push rdx
00007e4ecadd1ff3  push rdi
00007e4ecadd1ff4  push rsi
00007e4ecadd1ff5  push r8
00007e4ecadd1ff7  push r9
00007e4ecadd1ff9  push r10
00007e4ecadd1ffb  push r11
00007e4ecadd1ffd  sub rsp, 0xF0
00007e4ecadd2004  vmovaps [rsp], xmm0
00007e4ecadd2009  vmovaps [rsp+0x10], xmm1
00007e4ecadd200f  vmovaps [rsp+0x20], xmm3
00007e4ecadd2015  vmovaps [rsp+0x30], xmm4
00007e4ecadd201b  vmovaps [rsp+0x40], xmm5
00007e4ecadd2021  vmovaps [rsp+0x50], xmm6
00007e4ecadd2027  vmovaps [rsp+0x60], xmm7
00007e4ecadd202d  vmovaps [rsp+0x70], xmm8
00007e4ecadd2033  vmovaps [rsp+0x80], xmm9
00007e4ecadd203c  vmovaps [rsp+0x90], xmm10
00007e4ecadd2045  vmovaps [rsp+0xA0], xmm11
00007e4ecadd204e  vmovaps [rsp+0xB0], xmm12
00007e4ecadd2057  vmovaps [rsp+0xC0], xmm13
00007e4ecadd2060  vmovaps [rsp+0xD0], xmm14
00007e4ecadd2069  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2072  sub rsp, 0x30
00007e4ecadd2076  movaps [rsp], xmm2
00007e4ecadd207a  movaps [rsp+0x10], xmm1
00007e4ecadd207f  movaps [rsp+0x20], xmm13
00007e4ecadd2085  lea rdi, [rsp]
00007e4ecadd2089  mov esi, 0x00
00007e4ecadd208e  mov rax, 0x5784BC1F5530
00007e4ecadd2098  call rax
00007e4ecadd209a  movaps xmm2, [rsp]
00007e4ecadd209e  add rsp, 0x30
00007e4ecadd20a2  vmovaps xmm0, [rsp]
00007e4ecadd20a7  vmovaps xmm1, [rsp+0x10]
00007e4ecadd20ad  vmovaps xmm3, [rsp+0x20]
00007e4ecadd20b3  vmovaps xmm4, [rsp+0x30]
00007e4ecadd20b9  vmovaps xmm5, [rsp+0x40]
00007e4ecadd20bf  vmovaps xmm6, [rsp+0x50]
00007e4ecadd20c5  vmovaps xmm7, [rsp+0x60]
00007e4ecadd20cb  vmovaps xmm8, [rsp+0x70]
00007e4ecadd20d1  vmovaps xmm9, [rsp+0x80]
00007e4ecadd20da  vmovaps xmm10, [rsp+0x90]
00007e4ecadd20e3  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd20ec  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd20f5  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd20fe  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd2107  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd2110  add rsp, 0xF0
00007e4ecadd2117  pop r11
00007e4ecadd2119  pop r10
00007e4ecadd211b  pop r9
00007e4ecadd211d  pop r8
00007e4ecadd211f  pop rsi
00007e4ecadd2120  pop rdi
00007e4ecadd2121  pop rdx
00007e4ecadd2122  pop rcx
00007e4ecadd2123  pop rax
00007e4ecadd2124  add rsp, 0x08
00007e4ecadd2128  jmp 0x00007E4ECADCFBAB
00007e4ecadd212d  call 0x00007E4ECABFF430
00007e4ecadd2132  jmp 0x00007E4ECADCFBB8
00007e4ecadd2137  sub rsp, 0x08
00007e4ecadd213b  push rax
00007e4ecadd213c  push rcx
00007e4ecadd213d  push rdx
00007e4ecadd213e  push rdi
00007e4ecadd213f  push rsi
00007e4ecadd2140  push r8
00007e4ecadd2142  push r9
00007e4ecadd2144  push r10
00007e4ecadd2146  push r11
00007e4ecadd2148  sub rsp, 0xF0
00007e4ecadd214f  vmovaps [rsp], xmm0
00007e4ecadd2154  vmovaps [rsp+0x10], xmm1
00007e4ecadd215a  vmovaps [rsp+0x20], xmm2
00007e4ecadd2160  vmovaps [rsp+0x30], xmm3
00007e4ecadd2166  vmovaps [rsp+0x40], xmm4
00007e4ecadd216c  vmovaps [rsp+0x50], xmm5
00007e4ecadd2172  vmovaps [rsp+0x60], xmm6
00007e4ecadd2178  vmovaps [rsp+0x70], xmm7
00007e4ecadd217e  vmovaps [rsp+0x80], xmm8
00007e4ecadd2187  vmovaps [rsp+0x90], xmm9
00007e4ecadd2190  vmovaps [rsp+0xA0], xmm10
00007e4ecadd2199  vmovaps [rsp+0xB0], xmm11
00007e4ecadd21a2  vmovaps [rsp+0xC0], xmm12
00007e4ecadd21ab  vmovaps [rsp+0xD0], xmm13
00007e4ecadd21b4  vmovaps [rsp+0xE0], xmm14
00007e4ecadd21bd  sub rsp, 0x30
00007e4ecadd21c1  movaps [rsp], xmm15
00007e4ecadd21c6  movaps [rsp+0x10], xmm13
00007e4ecadd21cc  movaps [rsp+0x20], xmm1
00007e4ecadd21d1  lea rdi, [rsp]
00007e4ecadd21d5  mov esi, 0x00
00007e4ecadd21da  mov rax, 0x5784BC1F5530
00007e4ecadd21e4  call rax
00007e4ecadd21e6  movaps xmm15, [rsp]
00007e4ecadd21eb  add rsp, 0x30
00007e4ecadd21ef  vmovaps xmm0, [rsp]
00007e4ecadd21f4  vmovaps xmm1, [rsp+0x10]
00007e4ecadd21fa  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2200  vmovaps xmm3, [rsp+0x30]
00007e4ecadd2206  vmovaps xmm4, [rsp+0x40]
00007e4ecadd220c  vmovaps xmm5, [rsp+0x50]
00007e4ecadd2212  vmovaps xmm6, [rsp+0x60]
00007e4ecadd2218  vmovaps xmm7, [rsp+0x70]
00007e4ecadd221e  vmovaps xmm8, [rsp+0x80]
00007e4ecadd2227  vmovaps xmm9, [rsp+0x90]
00007e4ecadd2230  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd2239  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd2242  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd224b  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd2254  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd225d  add rsp, 0xF0
00007e4ecadd2264  pop r11
00007e4ecadd2266  pop r10
00007e4ecadd2268  pop r9
00007e4ecadd226a  pop r8
00007e4ecadd226c  pop rsi
00007e4ecadd226d  pop rdi
00007e4ecadd226e  pop rdx
00007e4ecadd226f  pop rcx
00007e4ecadd2270  pop rax
00007e4ecadd2271  add rsp, 0x08
00007e4ecadd2275  jmp 0x00007E4ECADCFBF7
00007e4ecadd227a  sub rsp, 0x08
00007e4ecadd227e  push rax
00007e4ecadd227f  push rcx
00007e4ecadd2280  push rdx
00007e4ecadd2281  push rdi
00007e4ecadd2282  push rsi
00007e4ecadd2283  push r8
00007e4ecadd2285  push r9
00007e4ecadd2287  push r10
00007e4ecadd2289  push r11
00007e4ecadd228b  sub rsp, 0xF0
00007e4ecadd2292  vmovaps [rsp], xmm0
00007e4ecadd2297  vmovaps [rsp+0x10], xmm1
00007e4ecadd229d  vmovaps [rsp+0x20], xmm2
00007e4ecadd22a3  vmovaps [rsp+0x30], xmm3
00007e4ecadd22a9  vmovaps [rsp+0x40], xmm4
00007e4ecadd22af  vmovaps [rsp+0x50], xmm5
00007e4ecadd22b5  vmovaps [rsp+0x60], xmm6
00007e4ecadd22bb  vmovaps [rsp+0x70], xmm7
00007e4ecadd22c1  vmovaps [rsp+0x80], xmm8
00007e4ecadd22ca  vmovaps [rsp+0x90], xmm9
00007e4ecadd22d3  vmovaps [rsp+0xA0], xmm10
00007e4ecadd22dc  vmovaps [rsp+0xB0], xmm11
00007e4ecadd22e5  vmovaps [rsp+0xC0], xmm12
00007e4ecadd22ee  vmovaps [rsp+0xD0], xmm13
00007e4ecadd22f7  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2300  sub rsp, 0x30
00007e4ecadd2304  movaps [rsp], xmm14
00007e4ecadd2309  movaps [rsp+0x10], xmm11
00007e4ecadd230f  movaps [rsp+0x20], xmm1
00007e4ecadd2314  lea rdi, [rsp]
00007e4ecadd2318  mov esi, 0x00
00007e4ecadd231d  mov rax, 0x5784BC1F5530
00007e4ecadd2327  call rax
00007e4ecadd2329  movaps xmm14, [rsp]
00007e4ecadd232e  add rsp, 0x30
00007e4ecadd2332  vmovaps xmm0, [rsp]
00007e4ecadd2337  vmovaps xmm1, [rsp+0x10]
00007e4ecadd233d  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2343  vmovaps xmm3, [rsp+0x30]
00007e4ecadd2349  vmovaps xmm4, [rsp+0x40]
00007e4ecadd234f  vmovaps xmm5, [rsp+0x50]
00007e4ecadd2355  vmovaps xmm6, [rsp+0x60]
00007e4ecadd235b  vmovaps xmm7, [rsp+0x70]
00007e4ecadd2361  vmovaps xmm8, [rsp+0x80]
00007e4ecadd236a  vmovaps xmm9, [rsp+0x90]
00007e4ecadd2373  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd237c  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd2385  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd238e  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd2397  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd23a0  add rsp, 0xF0
00007e4ecadd23a7  pop r11
00007e4ecadd23a9  pop r10
00007e4ecadd23ab  pop r9
00007e4ecadd23ad  pop r8
00007e4ecadd23af  pop rsi
00007e4ecadd23b0  pop rdi
00007e4ecadd23b1  pop rdx
00007e4ecadd23b2  pop rcx
00007e4ecadd23b3  pop rax
00007e4ecadd23b4  add rsp, 0x08
00007e4ecadd23b8  jmp 0x00007E4ECADCFC21
00007e4ecadd23bd  sub rsp, 0x08
00007e4ecadd23c1  push rax
00007e4ecadd23c2  push rcx
00007e4ecadd23c3  push rdx
00007e4ecadd23c4  push rdi
00007e4ecadd23c5  push rsi
00007e4ecadd23c6  push r8
00007e4ecadd23c8  push r9
00007e4ecadd23ca  push r10
00007e4ecadd23cc  push r11
00007e4ecadd23ce  sub rsp, 0xF0
00007e4ecadd23d5  vmovaps [rsp], xmm0
00007e4ecadd23da  vmovaps [rsp+0x10], xmm1
00007e4ecadd23e0  vmovaps [rsp+0x20], xmm2
00007e4ecadd23e6  vmovaps [rsp+0x30], xmm3
00007e4ecadd23ec  vmovaps [rsp+0x40], xmm4
00007e4ecadd23f2  vmovaps [rsp+0x50], xmm5
00007e4ecadd23f8  vmovaps [rsp+0x60], xmm6
00007e4ecadd23fe  vmovaps [rsp+0x70], xmm7
00007e4ecadd2404  vmovaps [rsp+0x80], xmm8
00007e4ecadd240d  vmovaps [rsp+0x90], xmm9
00007e4ecadd2416  vmovaps [rsp+0xA0], xmm10
00007e4ecadd241f  vmovaps [rsp+0xB0], xmm11
00007e4ecadd2428  vmovaps [rsp+0xC0], xmm12
00007e4ecadd2431  vmovaps [rsp+0xD0], xmm14
00007e4ecadd243a  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2443  sub rsp, 0x30
00007e4ecadd2447  movaps [rsp], xmm13
00007e4ecadd244c  movaps [rsp+0x10], xmm11
00007e4ecadd2452  movaps [rsp+0x20], xmm1
00007e4ecadd2457  lea rdi, [rsp]
00007e4ecadd245b  mov esi, 0x00
00007e4ecadd2460  mov rax, 0x5784BC1F5530
00007e4ecadd246a  call rax
00007e4ecadd246c  movaps xmm13, [rsp]
00007e4ecadd2471  add rsp, 0x30
00007e4ecadd2475  vmovaps xmm0, [rsp]
00007e4ecadd247a  vmovaps xmm1, [rsp+0x10]
00007e4ecadd2480  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2486  vmovaps xmm3, [rsp+0x30]
00007e4ecadd248c  vmovaps xmm4, [rsp+0x40]
00007e4ecadd2492  vmovaps xmm5, [rsp+0x50]
00007e4ecadd2498  vmovaps xmm6, [rsp+0x60]
00007e4ecadd249e  vmovaps xmm7, [rsp+0x70]
00007e4ecadd24a4  vmovaps xmm8, [rsp+0x80]
00007e4ecadd24ad  vmovaps xmm9, [rsp+0x90]
00007e4ecadd24b6  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd24bf  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd24c8  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd24d1  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd24da  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd24e3  add rsp, 0xF0
00007e4ecadd24ea  pop r11
00007e4ecadd24ec  pop r10
00007e4ecadd24ee  pop r9
00007e4ecadd24f0  pop r8
00007e4ecadd24f2  pop rsi
00007e4ecadd24f3  pop rdi
00007e4ecadd24f4  pop rdx
00007e4ecadd24f5  pop rcx
00007e4ecadd24f6  pop rax
00007e4ecadd24f7  add rsp, 0x08
00007e4ecadd24fb  jmp 0x00007E4ECADCFC76
00007e4ecadd2500  call 0x00007E4ECABFF430
00007e4ecadd2505  jmp 0x00007E4ECADCFC83
00007e4ecadd250a  sub rsp, 0x08
00007e4ecadd250e  push rax
00007e4ecadd250f  push rcx
00007e4ecadd2510  push rdx
00007e4ecadd2511  push rdi
00007e4ecadd2512  push rsi
00007e4ecadd2513  push r8
00007e4ecadd2515  push r9
00007e4ecadd2517  push r10
00007e4ecadd2519  push r11
00007e4ecadd251b  sub rsp, 0xF0
00007e4ecadd2522  vmovaps [rsp], xmm0
00007e4ecadd2527  vmovaps [rsp+0x10], xmm1
00007e4ecadd252d  vmovaps [rsp+0x20], xmm2
00007e4ecadd2533  vmovaps [rsp+0x30], xmm3
00007e4ecadd2539  vmovaps [rsp+0x40], xmm4
00007e4ecadd253f  vmovaps [rsp+0x50], xmm5
00007e4ecadd2545  vmovaps [rsp+0x60], xmm6
00007e4ecadd254b  vmovaps [rsp+0x70], xmm7
00007e4ecadd2551  vmovaps [rsp+0x80], xmm8
00007e4ecadd255a  vmovaps [rsp+0x90], xmm9
00007e4ecadd2563  vmovaps [rsp+0xA0], xmm10
00007e4ecadd256c  vmovaps [rsp+0xB0], xmm11
00007e4ecadd2575  vmovaps [rsp+0xC0], xmm12
00007e4ecadd257e  vmovaps [rsp+0xD0], xmm13
00007e4ecadd2587  vmovaps [rsp+0xE0], xmm14
00007e4ecadd2590  sub rsp, 0x30
00007e4ecadd2594  movaps [rsp], xmm15
00007e4ecadd2599  movaps [rsp+0x10], xmm11
00007e4ecadd259f  movaps [rsp+0x20], xmm1
00007e4ecadd25a4  lea rdi, [rsp]
00007e4ecadd25a8  mov esi, 0x00
00007e4ecadd25ad  mov rax, 0x5784BC1F5530
00007e4ecadd25b7  call rax
00007e4ecadd25b9  movaps xmm15, [rsp]
00007e4ecadd25be  add rsp, 0x30
00007e4ecadd25c2  vmovaps xmm0, [rsp]
00007e4ecadd25c7  vmovaps xmm1, [rsp+0x10]
00007e4ecadd25cd  vmovaps xmm2, [rsp+0x20]
00007e4ecadd25d3  vmovaps xmm3, [rsp+0x30]
00007e4ecadd25d9  vmovaps xmm4, [rsp+0x40]
00007e4ecadd25df  vmovaps xmm5, [rsp+0x50]
00007e4ecadd25e5  vmovaps xmm6, [rsp+0x60]
00007e4ecadd25eb  vmovaps xmm7, [rsp+0x70]
00007e4ecadd25f1  vmovaps xmm8, [rsp+0x80]
00007e4ecadd25fa  vmovaps xmm9, [rsp+0x90]
00007e4ecadd2603  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd260c  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd2615  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd261e  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd2627  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd2630  add rsp, 0xF0
00007e4ecadd2637  pop r11
00007e4ecadd2639  pop r10
00007e4ecadd263b  pop r9
00007e4ecadd263d  pop r8
00007e4ecadd263f  pop rsi
00007e4ecadd2640  pop rdi
00007e4ecadd2641  pop rdx
00007e4ecadd2642  pop rcx
00007e4ecadd2643  pop rax
00007e4ecadd2644  add rsp, 0x08
00007e4ecadd2648  jmp 0x00007E4ECADCFCBC
00007e4ecadd264d  sub rsp, 0x08
00007e4ecadd2651  push rax
00007e4ecadd2652  push rcx
00007e4ecadd2653  push rdx
00007e4ecadd2654  push rdi
00007e4ecadd2655  push rsi
00007e4ecadd2656  push r8
00007e4ecadd2658  push r9
00007e4ecadd265a  push r10
00007e4ecadd265c  push r11
00007e4ecadd265e  sub rsp, 0xF0
00007e4ecadd2665  vmovaps [rsp], xmm0
00007e4ecadd266a  vmovaps [rsp+0x10], xmm1
00007e4ecadd2670  vmovaps [rsp+0x20], xmm2
00007e4ecadd2676  vmovaps [rsp+0x30], xmm3
00007e4ecadd267c  vmovaps [rsp+0x40], xmm4
00007e4ecadd2682  vmovaps [rsp+0x50], xmm5
00007e4ecadd2688  vmovaps [rsp+0x60], xmm6
00007e4ecadd268e  vmovaps [rsp+0x70], xmm7
00007e4ecadd2694  vmovaps [rsp+0x80], xmm8
00007e4ecadd269d  vmovaps [rsp+0x90], xmm9
00007e4ecadd26a6  vmovaps [rsp+0xA0], xmm10
00007e4ecadd26af  vmovaps [rsp+0xB0], xmm12
00007e4ecadd26b8  vmovaps [rsp+0xC0], xmm13
00007e4ecadd26c1  vmovaps [rsp+0xD0], xmm14
00007e4ecadd26ca  vmovaps [rsp+0xE0], xmm15
00007e4ecadd26d3  sub rsp, 0x30
00007e4ecadd26d7  movaps [rsp], xmm11
00007e4ecadd26dc  movaps [rsp+0x10], xmm6
00007e4ecadd26e1  movaps [rsp+0x20], xmm14
00007e4ecadd26e7  lea rdi, [rsp]
00007e4ecadd26eb  mov esi, 0x00
00007e4ecadd26f0  mov rax, 0x5784BC1F5530
00007e4ecadd26fa  call rax
00007e4ecadd26fc  movaps xmm11, [rsp]
00007e4ecadd2701  add rsp, 0x30
00007e4ecadd2705  vmovaps xmm0, [rsp]
00007e4ecadd270a  vmovaps xmm1, [rsp+0x10]
00007e4ecadd2710  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2716  vmovaps xmm3, [rsp+0x30]
00007e4ecadd271c  vmovaps xmm4, [rsp+0x40]
00007e4ecadd2722  vmovaps xmm5, [rsp+0x50]
00007e4ecadd2728  vmovaps xmm6, [rsp+0x60]
00007e4ecadd272e  vmovaps xmm7, [rsp+0x70]
00007e4ecadd2734  vmovaps xmm8, [rsp+0x80]
00007e4ecadd273d  vmovaps xmm9, [rsp+0x90]
00007e4ecadd2746  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd274f  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd2758  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd2761  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd276a  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd2773  add rsp, 0xF0
00007e4ecadd277a  pop r11
00007e4ecadd277c  pop r10
00007e4ecadd277e  pop r9
00007e4ecadd2780  pop r8
00007e4ecadd2782  pop rsi
00007e4ecadd2783  pop rdi
00007e4ecadd2784  pop rdx
00007e4ecadd2785  pop rcx
00007e4ecadd2786  pop rax
00007e4ecadd2787  add rsp, 0x08
00007e4ecadd278b  jmp 0x00007E4ECADCFD34
00007e4ecadd2790  call 0x00007E4ECABFF430
00007e4ecadd2795  jmp 0x00007E4ECADCFD3E
00007e4ecadd279a  sub rsp, 0x08
00007e4ecadd279e  push rax
00007e4ecadd279f  push rcx
00007e4ecadd27a0  push rdx
00007e4ecadd27a1  push rdi
00007e4ecadd27a2  push rsi
00007e4ecadd27a3  push r8
00007e4ecadd27a5  push r9
00007e4ecadd27a7  push r10
00007e4ecadd27a9  push r11
00007e4ecadd27ab  sub rsp, 0xF0
00007e4ecadd27b2  vmovaps [rsp], xmm0
00007e4ecadd27b7  vmovaps [rsp+0x10], xmm1
00007e4ecadd27bd  vmovaps [rsp+0x20], xmm2
00007e4ecadd27c3  vmovaps [rsp+0x30], xmm3
00007e4ecadd27c9  vmovaps [rsp+0x40], xmm4
00007e4ecadd27cf  vmovaps [rsp+0x50], xmm5
00007e4ecadd27d5  vmovaps [rsp+0x60], xmm6
00007e4ecadd27db  vmovaps [rsp+0x70], xmm7
00007e4ecadd27e1  vmovaps [rsp+0x80], xmm8
00007e4ecadd27ea  vmovaps [rsp+0x90], xmm9
00007e4ecadd27f3  vmovaps [rsp+0xA0], xmm10
00007e4ecadd27fc  vmovaps [rsp+0xB0], xmm11
00007e4ecadd2805  vmovaps [rsp+0xC0], xmm12
00007e4ecadd280e  vmovaps [rsp+0xD0], xmm13
00007e4ecadd2817  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2820  sub rsp, 0x30
00007e4ecadd2824  movaps [rsp], xmm14
00007e4ecadd2829  movaps [rsp+0x10], xmm6
00007e4ecadd282e  movaps [rsp+0x20], xmm2
00007e4ecadd2833  lea rdi, [rsp]
00007e4ecadd2837  mov esi, 0x00
00007e4ecadd283c  mov rax, 0x5784BC1F5530
00007e4ecadd2846  call rax
00007e4ecadd2848  movaps xmm14, [rsp]
00007e4ecadd284d  add rsp, 0x30
00007e4ecadd2851  vmovaps xmm0, [rsp]
00007e4ecadd2856  vmovaps xmm1, [rsp+0x10]
00007e4ecadd285c  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2862  vmovaps xmm3, [rsp+0x30]
00007e4ecadd2868  vmovaps xmm4, [rsp+0x40]
00007e4ecadd286e  vmovaps xmm5, [rsp+0x50]
00007e4ecadd2874  vmovaps xmm6, [rsp+0x60]
00007e4ecadd287a  vmovaps xmm7, [rsp+0x70]
00007e4ecadd2880  vmovaps xmm8, [rsp+0x80]
00007e4ecadd2889  vmovaps xmm9, [rsp+0x90]
00007e4ecadd2892  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd289b  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd28a4  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd28ad  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd28b6  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd28bf  add rsp, 0xF0
00007e4ecadd28c6  pop r11
00007e4ecadd28c8  pop r10
00007e4ecadd28ca  pop r9
00007e4ecadd28cc  pop r8
00007e4ecadd28ce  pop rsi
00007e4ecadd28cf  pop rdi
00007e4ecadd28d0  pop rdx
00007e4ecadd28d1  pop rcx
00007e4ecadd28d2  pop rax
00007e4ecadd28d3  add rsp, 0x08
00007e4ecadd28d7  jmp 0x00007E4ECADCFD72
00007e4ecadd28dc  sub rsp, 0x08
00007e4ecadd28e0  push rax
00007e4ecadd28e1  push rcx
00007e4ecadd28e2  push rdx
00007e4ecadd28e3  push rdi
00007e4ecadd28e4  push rsi
00007e4ecadd28e5  push r8
00007e4ecadd28e7  push r9
00007e4ecadd28e9  push r10
00007e4ecadd28eb  push r11
00007e4ecadd28ed  sub rsp, 0xF0
00007e4ecadd28f4  vmovaps [rsp], xmm0
00007e4ecadd28f9  vmovaps [rsp+0x10], xmm1
00007e4ecadd28ff  vmovaps [rsp+0x20], xmm2
00007e4ecadd2905  vmovaps [rsp+0x30], xmm3
00007e4ecadd290b  vmovaps [rsp+0x40], xmm4
00007e4ecadd2911  vmovaps [rsp+0x50], xmm5
00007e4ecadd2917  vmovaps [rsp+0x60], xmm7
00007e4ecadd291d  vmovaps [rsp+0x70], xmm8
00007e4ecadd2923  vmovaps [rsp+0x80], xmm9
00007e4ecadd292c  vmovaps [rsp+0x90], xmm10
00007e4ecadd2935  vmovaps [rsp+0xA0], xmm11
00007e4ecadd293e  vmovaps [rsp+0xB0], xmm12
00007e4ecadd2947  vmovaps [rsp+0xC0], xmm13
00007e4ecadd2950  vmovaps [rsp+0xD0], xmm14
00007e4ecadd2959  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2962  sub rsp, 0x30
00007e4ecadd2966  movaps [rsp], xmm6
00007e4ecadd296a  movaps [rsp+0x10], xmm5
00007e4ecadd296f  movaps [rsp+0x20], xmm1
00007e4ecadd2974  lea rdi, [rsp]
00007e4ecadd2978  mov esi, 0x00
00007e4ecadd297d  mov rax, 0x5784BC1F5530
00007e4ecadd2987  call rax
00007e4ecadd2989  movaps xmm6, [rsp]
00007e4ecadd298d  add rsp, 0x30
00007e4ecadd2991  vmovaps xmm0, [rsp]
00007e4ecadd2996  vmovaps xmm1, [rsp+0x10]
00007e4ecadd299c  vmovaps xmm2, [rsp+0x20]
00007e4ecadd29a2  vmovaps xmm3, [rsp+0x30]
00007e4ecadd29a8  vmovaps xmm4, [rsp+0x40]
00007e4ecadd29ae  vmovaps xmm5, [rsp+0x50]
00007e4ecadd29b4  vmovaps xmm7, [rsp+0x60]
00007e4ecadd29ba  vmovaps xmm8, [rsp+0x70]
00007e4ecadd29c0  vmovaps xmm9, [rsp+0x80]
00007e4ecadd29c9  vmovaps xmm10, [rsp+0x90]
00007e4ecadd29d2  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd29db  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd29e4  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd29ed  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd29f6  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd29ff  add rsp, 0xF0
00007e4ecadd2a06  pop r11
00007e4ecadd2a08  pop r10
00007e4ecadd2a0a  pop r9
00007e4ecadd2a0c  pop r8
00007e4ecadd2a0e  pop rsi
00007e4ecadd2a0f  pop rdi
00007e4ecadd2a10  pop rdx
00007e4ecadd2a11  pop rcx
00007e4ecadd2a12  pop rax
00007e4ecadd2a13  add rsp, 0x08
00007e4ecadd2a17  jmp 0x00007E4ECADCFD98
00007e4ecadd2a1c  sub rsp, 0x08
00007e4ecadd2a20  push rax
00007e4ecadd2a21  push rcx
00007e4ecadd2a22  push rdx
00007e4ecadd2a23  push rdi
00007e4ecadd2a24  push rsi
00007e4ecadd2a25  push r8
00007e4ecadd2a27  push r9
00007e4ecadd2a29  push r10
00007e4ecadd2a2b  push r11
00007e4ecadd2a2d  sub rsp, 0xF0
00007e4ecadd2a34  vmovaps [rsp], xmm0
00007e4ecadd2a39  vmovaps [rsp+0x10], xmm2
00007e4ecadd2a3f  vmovaps [rsp+0x20], xmm3
00007e4ecadd2a45  vmovaps [rsp+0x30], xmm4
00007e4ecadd2a4b  vmovaps [rsp+0x40], xmm5
00007e4ecadd2a51  vmovaps [rsp+0x50], xmm6
00007e4ecadd2a57  vmovaps [rsp+0x60], xmm7
00007e4ecadd2a5d  vmovaps [rsp+0x70], xmm8
00007e4ecadd2a63  vmovaps [rsp+0x80], xmm9
00007e4ecadd2a6c  vmovaps [rsp+0x90], xmm10
00007e4ecadd2a75  vmovaps [rsp+0xA0], xmm11
00007e4ecadd2a7e  vmovaps [rsp+0xB0], xmm12
00007e4ecadd2a87  vmovaps [rsp+0xC0], xmm13
00007e4ecadd2a90  vmovaps [rsp+0xD0], xmm14
00007e4ecadd2a99  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2aa2  sub rsp, 0x30
00007e4ecadd2aa6  movaps [rsp], xmm1
00007e4ecadd2aaa  movaps [rsp+0x10], xmm5
00007e4ecadd2aaf  movaps [rsp+0x20], xmm13
00007e4ecadd2ab5  lea rdi, [rsp]
00007e4ecadd2ab9  mov esi, 0x00
00007e4ecadd2abe  mov rax, 0x5784BC1F5530
00007e4ecadd2ac8  call rax
00007e4ecadd2aca  movaps xmm1, [rsp]
00007e4ecadd2ace  add rsp, 0x30
00007e4ecadd2ad2  vmovaps xmm0, [rsp]
00007e4ecadd2ad7  vmovaps xmm2, [rsp+0x10]
00007e4ecadd2add  vmovaps xmm3, [rsp+0x20]
00007e4ecadd2ae3  vmovaps xmm4, [rsp+0x30]
00007e4ecadd2ae9  vmovaps xmm5, [rsp+0x40]
00007e4ecadd2aef  vmovaps xmm6, [rsp+0x50]
00007e4ecadd2af5  vmovaps xmm7, [rsp+0x60]
00007e4ecadd2afb  vmovaps xmm8, [rsp+0x70]
00007e4ecadd2b01  vmovaps xmm9, [rsp+0x80]
00007e4ecadd2b0a  vmovaps xmm10, [rsp+0x90]
00007e4ecadd2b13  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd2b1c  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd2b25  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd2b2e  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd2b37  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd2b40  add rsp, 0xF0
00007e4ecadd2b47  pop r11
00007e4ecadd2b49  pop r10
00007e4ecadd2b4b  pop r9
00007e4ecadd2b4d  pop r8
00007e4ecadd2b4f  pop rsi
00007e4ecadd2b50  pop rdi
00007e4ecadd2b51  pop rdx
00007e4ecadd2b52  pop rcx
00007e4ecadd2b53  pop rax
00007e4ecadd2b54  add rsp, 0x08
00007e4ecadd2b58  jmp 0x00007E4ECADCFDB6
00007e4ecadd2b5d  sub rsp, 0x08
00007e4ecadd2b61  push rax
00007e4ecadd2b62  push rcx
00007e4ecadd2b63  push rdx
00007e4ecadd2b64  push rdi
00007e4ecadd2b65  push rsi
00007e4ecadd2b66  push r8
00007e4ecadd2b68  push r9
00007e4ecadd2b6a  push r10
00007e4ecadd2b6c  push r11
00007e4ecadd2b6e  sub rsp, 0xF0
00007e4ecadd2b75  vmovaps [rsp], xmm0
00007e4ecadd2b7a  vmovaps [rsp+0x10], xmm1
00007e4ecadd2b80  vmovaps [rsp+0x20], xmm2
00007e4ecadd2b86  vmovaps [rsp+0x30], xmm3
00007e4ecadd2b8c  vmovaps [rsp+0x40], xmm4
00007e4ecadd2b92  vmovaps [rsp+0x50], xmm6
00007e4ecadd2b98  vmovaps [rsp+0x60], xmm7
00007e4ecadd2b9e  vmovaps [rsp+0x70], xmm8
00007e4ecadd2ba4  vmovaps [rsp+0x80], xmm9
00007e4ecadd2bad  vmovaps [rsp+0x90], xmm10
00007e4ecadd2bb6  vmovaps [rsp+0xA0], xmm11
00007e4ecadd2bbf  vmovaps [rsp+0xB0], xmm12
00007e4ecadd2bc8  vmovaps [rsp+0xC0], xmm13
00007e4ecadd2bd1  vmovaps [rsp+0xD0], xmm14
00007e4ecadd2bda  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2be3  sub rsp, 0x30
00007e4ecadd2be7  movaps [rsp], xmm5
00007e4ecadd2beb  movaps [rsp+0x10], xmm2
00007e4ecadd2bf0  movaps [rsp+0x20], xmm13
00007e4ecadd2bf6  lea rdi, [rsp]
00007e4ecadd2bfa  mov esi, 0x00
00007e4ecadd2bff  mov rax, 0x5784BC1F5530
00007e4ecadd2c09  call rax
00007e4ecadd2c0b  movaps xmm5, [rsp]
00007e4ecadd2c0f  add rsp, 0x30
00007e4ecadd2c13  vmovaps xmm0, [rsp]
00007e4ecadd2c18  vmovaps xmm1, [rsp+0x10]
00007e4ecadd2c1e  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2c24  vmovaps xmm3, [rsp+0x30]
00007e4ecadd2c2a  vmovaps xmm4, [rsp+0x40]
00007e4ecadd2c30  vmovaps xmm6, [rsp+0x50]
00007e4ecadd2c36  vmovaps xmm7, [rsp+0x60]
00007e4ecadd2c3c  vmovaps xmm8, [rsp+0x70]
00007e4ecadd2c42  vmovaps xmm9, [rsp+0x80]
00007e4ecadd2c4b  vmovaps xmm10, [rsp+0x90]
00007e4ecadd2c54  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd2c5d  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd2c66  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd2c6f  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd2c78  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd2c81  add rsp, 0xF0
00007e4ecadd2c88  pop r11
00007e4ecadd2c8a  pop r10
00007e4ecadd2c8c  pop r9
00007e4ecadd2c8e  pop r8
00007e4ecadd2c90  pop rsi
00007e4ecadd2c91  pop rdi
00007e4ecadd2c92  pop rdx
00007e4ecadd2c93  pop rcx
00007e4ecadd2c94  pop rax
00007e4ecadd2c95  add rsp, 0x08
00007e4ecadd2c99  jmp 0x00007E4ECADCFDEC
00007e4ecadd2c9e  sub rsp, 0x08
00007e4ecadd2ca2  push rax
00007e4ecadd2ca3  push rcx
00007e4ecadd2ca4  push rdx
00007e4ecadd2ca5  push rdi
00007e4ecadd2ca6  push rsi
00007e4ecadd2ca7  push r8
00007e4ecadd2ca9  push r9
00007e4ecadd2cab  push r10
00007e4ecadd2cad  push r11
00007e4ecadd2caf  sub rsp, 0xF0
00007e4ecadd2cb6  vmovaps [rsp], xmm0
00007e4ecadd2cbb  vmovaps [rsp+0x10], xmm1
00007e4ecadd2cc1  vmovaps [rsp+0x20], xmm2
00007e4ecadd2cc7  vmovaps [rsp+0x30], xmm3
00007e4ecadd2ccd  vmovaps [rsp+0x40], xmm4
00007e4ecadd2cd3  vmovaps [rsp+0x50], xmm5
00007e4ecadd2cd9  vmovaps [rsp+0x60], xmm6
00007e4ecadd2cdf  vmovaps [rsp+0x70], xmm7
00007e4ecadd2ce5  vmovaps [rsp+0x80], xmm8
00007e4ecadd2cee  vmovaps [rsp+0x90], xmm9
00007e4ecadd2cf7  vmovaps [rsp+0xA0], xmm10
00007e4ecadd2d00  vmovaps [rsp+0xB0], xmm11
00007e4ecadd2d09  vmovaps [rsp+0xC0], xmm12
00007e4ecadd2d12  vmovaps [rsp+0xD0], xmm14
00007e4ecadd2d1b  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2d24  sub rsp, 0x30
00007e4ecadd2d28  movaps [rsp], xmm13
00007e4ecadd2d2d  movaps [rsp+0x10], xmm10
00007e4ecadd2d33  movaps [rsp+0x20], xmm1
00007e4ecadd2d38  lea rdi, [rsp]
00007e4ecadd2d3c  mov esi, 0x00
00007e4ecadd2d41  mov rax, 0x5784BC1F5530
00007e4ecadd2d4b  call rax
00007e4ecadd2d4d  movaps xmm13, [rsp]
00007e4ecadd2d52  add rsp, 0x30
00007e4ecadd2d56  vmovaps xmm0, [rsp]
00007e4ecadd2d5b  vmovaps xmm1, [rsp+0x10]
00007e4ecadd2d61  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2d67  vmovaps xmm3, [rsp+0x30]
00007e4ecadd2d6d  vmovaps xmm4, [rsp+0x40]
00007e4ecadd2d73  vmovaps xmm5, [rsp+0x50]
00007e4ecadd2d79  vmovaps xmm6, [rsp+0x60]
00007e4ecadd2d7f  vmovaps xmm7, [rsp+0x70]
00007e4ecadd2d85  vmovaps xmm8, [rsp+0x80]
00007e4ecadd2d8e  vmovaps xmm9, [rsp+0x90]
00007e4ecadd2d97  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd2da0  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd2da9  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd2db2  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd2dbb  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd2dc4  add rsp, 0xF0
00007e4ecadd2dcb  pop r11
00007e4ecadd2dcd  pop r10
00007e4ecadd2dcf  pop r9
00007e4ecadd2dd1  pop r8
00007e4ecadd2dd3  pop rsi
00007e4ecadd2dd4  pop rdi
00007e4ecadd2dd5  pop rdx
00007e4ecadd2dd6  pop rcx
00007e4ecadd2dd7  pop rax
00007e4ecadd2dd8  add rsp, 0x08
00007e4ecadd2ddc  jmp 0x00007E4ECADCFE15
00007e4ecadd2de1  sub rsp, 0x08
00007e4ecadd2de5  push rax
00007e4ecadd2de6  push rcx
00007e4ecadd2de7  push rdx
00007e4ecadd2de8  push rdi
00007e4ecadd2de9  push rsi
00007e4ecadd2dea  push r8
00007e4ecadd2dec  push r9
00007e4ecadd2dee  push r10
00007e4ecadd2df0  push r11
00007e4ecadd2df2  sub rsp, 0xF0
00007e4ecadd2df9  vmovaps [rsp], xmm0
00007e4ecadd2dfe  vmovaps [rsp+0x10], xmm2
00007e4ecadd2e04  vmovaps [rsp+0x20], xmm3
00007e4ecadd2e0a  vmovaps [rsp+0x30], xmm4
00007e4ecadd2e10  vmovaps [rsp+0x40], xmm5
00007e4ecadd2e16  vmovaps [rsp+0x50], xmm6
00007e4ecadd2e1c  vmovaps [rsp+0x60], xmm7
00007e4ecadd2e22  vmovaps [rsp+0x70], xmm8
00007e4ecadd2e28  vmovaps [rsp+0x80], xmm9
00007e4ecadd2e31  vmovaps [rsp+0x90], xmm10
00007e4ecadd2e3a  vmovaps [rsp+0xA0], xmm11
00007e4ecadd2e43  vmovaps [rsp+0xB0], xmm12
00007e4ecadd2e4c  vmovaps [rsp+0xC0], xmm13
00007e4ecadd2e55  vmovaps [rsp+0xD0], xmm14
00007e4ecadd2e5e  vmovaps [rsp+0xE0], xmm15
00007e4ecadd2e67  sub rsp, 0x30
00007e4ecadd2e6b  movaps [rsp], xmm1
00007e4ecadd2e6f  movaps [rsp+0x10], xmm15
00007e4ecadd2e75  movaps [rsp+0x20], xmm10
00007e4ecadd2e7b  lea rdi, [rsp]
00007e4ecadd2e7f  mov esi, 0x00
00007e4ecadd2e84  mov rax, 0x5784BC1F5530
00007e4ecadd2e8e  call rax
00007e4ecadd2e90  movaps xmm1, [rsp]
00007e4ecadd2e94  add rsp, 0x30
00007e4ecadd2e98  vmovaps xmm0, [rsp]
00007e4ecadd2e9d  vmovaps xmm2, [rsp+0x10]
00007e4ecadd2ea3  vmovaps xmm3, [rsp+0x20]
00007e4ecadd2ea9  vmovaps xmm4, [rsp+0x30]
00007e4ecadd2eaf  vmovaps xmm5, [rsp+0x40]
00007e4ecadd2eb5  vmovaps xmm6, [rsp+0x50]
00007e4ecadd2ebb  vmovaps xmm7, [rsp+0x60]
00007e4ecadd2ec1  vmovaps xmm8, [rsp+0x70]
00007e4ecadd2ec7  vmovaps xmm9, [rsp+0x80]
00007e4ecadd2ed0  vmovaps xmm10, [rsp+0x90]
00007e4ecadd2ed9  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd2ee2  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd2eeb  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd2ef4  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd2efd  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd2f06  add rsp, 0xF0
00007e4ecadd2f0d  pop r11
00007e4ecadd2f0f  pop r10
00007e4ecadd2f11  pop r9
00007e4ecadd2f13  pop r8
00007e4ecadd2f15  pop rsi
00007e4ecadd2f16  pop rdi
00007e4ecadd2f17  pop rdx
00007e4ecadd2f18  pop rcx
00007e4ecadd2f19  pop rax
00007e4ecadd2f1a  add rsp, 0x08
00007e4ecadd2f1e  jmp 0x00007E4ECADCFE34
00007e4ecadd2f23  sub rsp, 0x08
00007e4ecadd2f27  push rax
00007e4ecadd2f28  push rcx
00007e4ecadd2f29  push rdx
00007e4ecadd2f2a  push rdi
00007e4ecadd2f2b  push rsi
00007e4ecadd2f2c  push r8
00007e4ecadd2f2e  push r9
00007e4ecadd2f30  push r10
00007e4ecadd2f32  push r11
00007e4ecadd2f34  sub rsp, 0xF0
00007e4ecadd2f3b  vmovaps [rsp], xmm0
00007e4ecadd2f40  vmovaps [rsp+0x10], xmm1
00007e4ecadd2f46  vmovaps [rsp+0x20], xmm2
00007e4ecadd2f4c  vmovaps [rsp+0x30], xmm3
00007e4ecadd2f52  vmovaps [rsp+0x40], xmm4
00007e4ecadd2f58  vmovaps [rsp+0x50], xmm5
00007e4ecadd2f5e  vmovaps [rsp+0x60], xmm6
00007e4ecadd2f64  vmovaps [rsp+0x70], xmm7
00007e4ecadd2f6a  vmovaps [rsp+0x80], xmm8
00007e4ecadd2f73  vmovaps [rsp+0x90], xmm9
00007e4ecadd2f7c  vmovaps [rsp+0xA0], xmm10
00007e4ecadd2f85  vmovaps [rsp+0xB0], xmm11
00007e4ecadd2f8e  vmovaps [rsp+0xC0], xmm12
00007e4ecadd2f97  vmovaps [rsp+0xD0], xmm13
00007e4ecadd2fa0  vmovaps [rsp+0xE0], xmm14
00007e4ecadd2fa9  sub rsp, 0x30
00007e4ecadd2fad  movaps [rsp], xmm15
00007e4ecadd2fb2  movaps [rsp+0x10], xmm10
00007e4ecadd2fb8  movaps [rsp+0x20], xmm11
00007e4ecadd2fbe  lea rdi, [rsp]
00007e4ecadd2fc2  mov esi, 0x00
00007e4ecadd2fc7  mov rax, 0x5784BC1F5530
00007e4ecadd2fd1  call rax
00007e4ecadd2fd3  movaps xmm15, [rsp]
00007e4ecadd2fd8  add rsp, 0x30
00007e4ecadd2fdc  vmovaps xmm0, [rsp]
00007e4ecadd2fe1  vmovaps xmm1, [rsp+0x10]
00007e4ecadd2fe7  vmovaps xmm2, [rsp+0x20]
00007e4ecadd2fed  vmovaps xmm3, [rsp+0x30]
00007e4ecadd2ff3  vmovaps xmm4, [rsp+0x40]
00007e4ecadd2ff9  vmovaps xmm5, [rsp+0x50]
00007e4ecadd2fff  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3005  vmovaps xmm7, [rsp+0x70]
00007e4ecadd300b  vmovaps xmm8, [rsp+0x80]
00007e4ecadd3014  vmovaps xmm9, [rsp+0x90]
00007e4ecadd301d  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd3026  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd302f  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd3038  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd3041  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd304a  add rsp, 0xF0
00007e4ecadd3051  pop r11
00007e4ecadd3053  pop r10
00007e4ecadd3055  pop r9
00007e4ecadd3057  pop r8
00007e4ecadd3059  pop rsi
00007e4ecadd305a  pop rdi
00007e4ecadd305b  pop rdx
00007e4ecadd305c  pop rcx
00007e4ecadd305d  pop rax
00007e4ecadd305e  add rsp, 0x08
00007e4ecadd3062  jmp 0x00007E4ECADCFE57
00007e4ecadd3067  sub rsp, 0x08
00007e4ecadd306b  push rax
00007e4ecadd306c  push rcx
00007e4ecadd306d  push rdx
00007e4ecadd306e  push rdi
00007e4ecadd306f  push rsi
00007e4ecadd3070  push r8
00007e4ecadd3072  push r9
00007e4ecadd3074  push r10
00007e4ecadd3076  push r11
00007e4ecadd3078  sub rsp, 0xF0
00007e4ecadd307f  vmovaps [rsp], xmm0
00007e4ecadd3084  vmovaps [rsp+0x10], xmm1
00007e4ecadd308a  vmovaps [rsp+0x20], xmm2
00007e4ecadd3090  vmovaps [rsp+0x30], xmm3
00007e4ecadd3096  vmovaps [rsp+0x40], xmm4
00007e4ecadd309c  vmovaps [rsp+0x50], xmm5
00007e4ecadd30a2  vmovaps [rsp+0x60], xmm6
00007e4ecadd30a8  vmovaps [rsp+0x70], xmm7
00007e4ecadd30ae  vmovaps [rsp+0x80], xmm8
00007e4ecadd30b7  vmovaps [rsp+0x90], xmm9
00007e4ecadd30c0  vmovaps [rsp+0xA0], xmm11
00007e4ecadd30c9  vmovaps [rsp+0xB0], xmm12
00007e4ecadd30d2  vmovaps [rsp+0xC0], xmm13
00007e4ecadd30db  vmovaps [rsp+0xD0], xmm14
00007e4ecadd30e4  vmovaps [rsp+0xE0], xmm15
00007e4ecadd30ed  sub rsp, 0x30
00007e4ecadd30f1  movaps [rsp], xmm10
00007e4ecadd30f6  movaps [rsp+0x10], xmm12
00007e4ecadd30fc  movaps [rsp+0x20], xmm11
00007e4ecadd3102  lea rdi, [rsp]
00007e4ecadd3106  mov esi, 0x00
00007e4ecadd310b  mov rax, 0x5784BC1F5530
00007e4ecadd3115  call rax
00007e4ecadd3117  movaps xmm10, [rsp]
00007e4ecadd311c  add rsp, 0x30
00007e4ecadd3120  vmovaps xmm0, [rsp]
00007e4ecadd3125  vmovaps xmm1, [rsp+0x10]
00007e4ecadd312b  vmovaps xmm2, [rsp+0x20]
00007e4ecadd3131  vmovaps xmm3, [rsp+0x30]
00007e4ecadd3137  vmovaps xmm4, [rsp+0x40]
00007e4ecadd313d  vmovaps xmm5, [rsp+0x50]
00007e4ecadd3143  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3149  vmovaps xmm7, [rsp+0x70]
00007e4ecadd314f  vmovaps xmm8, [rsp+0x80]
00007e4ecadd3158  vmovaps xmm9, [rsp+0x90]
00007e4ecadd3161  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd316a  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd3173  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd317c  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd3185  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd318e  add rsp, 0xF0
00007e4ecadd3195  pop r11
00007e4ecadd3197  pop r10
00007e4ecadd3199  pop r9
00007e4ecadd319b  pop r8
00007e4ecadd319d  pop rsi
00007e4ecadd319e  pop rdi
00007e4ecadd319f  pop rdx
00007e4ecadd31a0  pop rcx
00007e4ecadd31a1  pop rax
00007e4ecadd31a2  add rsp, 0x08
00007e4ecadd31a6  jmp 0x00007E4ECADCFE80
00007e4ecadd31ab  sub rsp, 0x08
00007e4ecadd31af  push rax
00007e4ecadd31b0  push rcx
00007e4ecadd31b1  push rdx
00007e4ecadd31b2  push rdi
00007e4ecadd31b3  push rsi
00007e4ecadd31b4  push r8
00007e4ecadd31b6  push r9
00007e4ecadd31b8  push r10
00007e4ecadd31ba  push r11
00007e4ecadd31bc  sub rsp, 0xF0
00007e4ecadd31c3  vmovaps [rsp], xmm0
00007e4ecadd31c8  vmovaps [rsp+0x10], xmm1
00007e4ecadd31ce  vmovaps [rsp+0x20], xmm2
00007e4ecadd31d4  vmovaps [rsp+0x30], xmm3
00007e4ecadd31da  vmovaps [rsp+0x40], xmm4
00007e4ecadd31e0  vmovaps [rsp+0x50], xmm5
00007e4ecadd31e6  vmovaps [rsp+0x60], xmm6
00007e4ecadd31ec  vmovaps [rsp+0x70], xmm7
00007e4ecadd31f2  vmovaps [rsp+0x80], xmm8
00007e4ecadd31fb  vmovaps [rsp+0x90], xmm9
00007e4ecadd3204  vmovaps [rsp+0xA0], xmm10
00007e4ecadd320d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd3216  vmovaps [rsp+0xC0], xmm13
00007e4ecadd321f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd3228  vmovaps [rsp+0xE0], xmm15
00007e4ecadd3231  sub rsp, 0x30
00007e4ecadd3235  movaps [rsp], xmm11
00007e4ecadd323a  movaps [rsp+0x10], xmm2
00007e4ecadd323f  movaps [rsp+0x20], xmm12
00007e4ecadd3245  lea rdi, [rsp]
00007e4ecadd3249  mov esi, 0x00
00007e4ecadd324e  mov rax, 0x5784BC1F5530
00007e4ecadd3258  call rax
00007e4ecadd325a  movaps xmm11, [rsp]
00007e4ecadd325f  add rsp, 0x30
00007e4ecadd3263  vmovaps xmm0, [rsp]
00007e4ecadd3268  vmovaps xmm1, [rsp+0x10]
00007e4ecadd326e  vmovaps xmm2, [rsp+0x20]
00007e4ecadd3274  vmovaps xmm3, [rsp+0x30]
00007e4ecadd327a  vmovaps xmm4, [rsp+0x40]
00007e4ecadd3280  vmovaps xmm5, [rsp+0x50]
00007e4ecadd3286  vmovaps xmm6, [rsp+0x60]
00007e4ecadd328c  vmovaps xmm7, [rsp+0x70]
00007e4ecadd3292  vmovaps xmm8, [rsp+0x80]
00007e4ecadd329b  vmovaps xmm9, [rsp+0x90]
00007e4ecadd32a4  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd32ad  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd32b6  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd32bf  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd32c8  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd32d1  add rsp, 0xF0
00007e4ecadd32d8  pop r11
00007e4ecadd32da  pop r10
00007e4ecadd32dc  pop r9
00007e4ecadd32de  pop r8
00007e4ecadd32e0  pop rsi
00007e4ecadd32e1  pop rdi
00007e4ecadd32e2  pop rdx
00007e4ecadd32e3  pop rcx
00007e4ecadd32e4  pop rax
00007e4ecadd32e5  add rsp, 0x08
00007e4ecadd32e9  jmp 0x00007E4ECADCFEB8
00007e4ecadd32ee  sub rsp, 0x08
00007e4ecadd32f2  push rax
00007e4ecadd32f3  push rcx
00007e4ecadd32f4  push rdx
00007e4ecadd32f5  push rdi
00007e4ecadd32f6  push rsi
00007e4ecadd32f7  push r8
00007e4ecadd32f9  push r9
00007e4ecadd32fb  push r10
00007e4ecadd32fd  push r11
00007e4ecadd32ff  sub rsp, 0xF0
00007e4ecadd3306  vmovaps [rsp], xmm0
00007e4ecadd330b  vmovaps [rsp+0x10], xmm2
00007e4ecadd3311  vmovaps [rsp+0x20], xmm3
00007e4ecadd3317  vmovaps [rsp+0x30], xmm4
00007e4ecadd331d  vmovaps [rsp+0x40], xmm5
00007e4ecadd3323  vmovaps [rsp+0x50], xmm6
00007e4ecadd3329  vmovaps [rsp+0x60], xmm7
00007e4ecadd332f  vmovaps [rsp+0x70], xmm8
00007e4ecadd3335  vmovaps [rsp+0x80], xmm9
00007e4ecadd333e  vmovaps [rsp+0x90], xmm10
00007e4ecadd3347  vmovaps [rsp+0xA0], xmm11
00007e4ecadd3350  vmovaps [rsp+0xB0], xmm12
00007e4ecadd3359  vmovaps [rsp+0xC0], xmm13
00007e4ecadd3362  vmovaps [rsp+0xD0], xmm14
00007e4ecadd336b  vmovaps [rsp+0xE0], xmm15
00007e4ecadd3374  sub rsp, 0x30
00007e4ecadd3378  movaps [rsp], xmm1
00007e4ecadd337c  movaps [rsp+0x10], xmm14
00007e4ecadd3382  movaps [rsp+0x20], xmm6
00007e4ecadd3387  lea rdi, [rsp]
00007e4ecadd338b  mov esi, 0x00
00007e4ecadd3390  mov rax, 0x5784BC1F5530
00007e4ecadd339a  call rax
00007e4ecadd339c  movaps xmm1, [rsp]
00007e4ecadd33a0  add rsp, 0x30
00007e4ecadd33a4  vmovaps xmm0, [rsp]
00007e4ecadd33a9  vmovaps xmm2, [rsp+0x10]
00007e4ecadd33af  vmovaps xmm3, [rsp+0x20]
00007e4ecadd33b5  vmovaps xmm4, [rsp+0x30]
00007e4ecadd33bb  vmovaps xmm5, [rsp+0x40]
00007e4ecadd33c1  vmovaps xmm6, [rsp+0x50]
00007e4ecadd33c7  vmovaps xmm7, [rsp+0x60]
00007e4ecadd33cd  vmovaps xmm8, [rsp+0x70]
00007e4ecadd33d3  vmovaps xmm9, [rsp+0x80]
00007e4ecadd33dc  vmovaps xmm10, [rsp+0x90]
00007e4ecadd33e5  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd33ee  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd33f7  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd3400  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd3409  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3412  add rsp, 0xF0
00007e4ecadd3419  pop r11
00007e4ecadd341b  pop r10
00007e4ecadd341d  pop r9
00007e4ecadd341f  pop r8
00007e4ecadd3421  pop rsi
00007e4ecadd3422  pop rdi
00007e4ecadd3423  pop rdx
00007e4ecadd3424  pop rcx
00007e4ecadd3425  pop rax
00007e4ecadd3426  add rsp, 0x08
00007e4ecadd342a  jmp 0x00007E4ECADCFED1
00007e4ecadd342f  sub rsp, 0x08
00007e4ecadd3433  push rax
00007e4ecadd3434  push rcx
00007e4ecadd3435  push rdx
00007e4ecadd3436  push rdi
00007e4ecadd3437  push rsi
00007e4ecadd3438  push r8
00007e4ecadd343a  push r9
00007e4ecadd343c  push r10
00007e4ecadd343e  push r11
00007e4ecadd3440  sub rsp, 0xF0
00007e4ecadd3447  vmovaps [rsp], xmm0
00007e4ecadd344c  vmovaps [rsp+0x10], xmm1
00007e4ecadd3452  vmovaps [rsp+0x20], xmm2
00007e4ecadd3458  vmovaps [rsp+0x30], xmm3
00007e4ecadd345e  vmovaps [rsp+0x40], xmm4
00007e4ecadd3464  vmovaps [rsp+0x50], xmm5
00007e4ecadd346a  vmovaps [rsp+0x60], xmm6
00007e4ecadd3470  vmovaps [rsp+0x70], xmm7
00007e4ecadd3476  vmovaps [rsp+0x80], xmm8
00007e4ecadd347f  vmovaps [rsp+0x90], xmm9
00007e4ecadd3488  vmovaps [rsp+0xA0], xmm10
00007e4ecadd3491  vmovaps [rsp+0xB0], xmm11
00007e4ecadd349a  vmovaps [rsp+0xC0], xmm12
00007e4ecadd34a3  vmovaps [rsp+0xD0], xmm13
00007e4ecadd34ac  vmovaps [rsp+0xE0], xmm15
00007e4ecadd34b5  sub rsp, 0x30
00007e4ecadd34b9  movaps [rsp], xmm14
00007e4ecadd34be  movaps [rsp+0x10], xmm12
00007e4ecadd34c4  movaps [rsp+0x20], xmm5
00007e4ecadd34c9  lea rdi, [rsp]
00007e4ecadd34cd  mov esi, 0x00
00007e4ecadd34d2  mov rax, 0x5784BC1F5530
00007e4ecadd34dc  call rax
00007e4ecadd34de  movaps xmm14, [rsp]
00007e4ecadd34e3  add rsp, 0x30
00007e4ecadd34e7  vmovaps xmm0, [rsp]
00007e4ecadd34ec  vmovaps xmm1, [rsp+0x10]
00007e4ecadd34f2  vmovaps xmm2, [rsp+0x20]
00007e4ecadd34f8  vmovaps xmm3, [rsp+0x30]
00007e4ecadd34fe  vmovaps xmm4, [rsp+0x40]
00007e4ecadd3504  vmovaps xmm5, [rsp+0x50]
00007e4ecadd350a  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3510  vmovaps xmm7, [rsp+0x70]
00007e4ecadd3516  vmovaps xmm8, [rsp+0x80]
00007e4ecadd351f  vmovaps xmm9, [rsp+0x90]
00007e4ecadd3528  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd3531  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd353a  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd3543  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd354c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3555  add rsp, 0xF0
00007e4ecadd355c  pop r11
00007e4ecadd355e  pop r10
00007e4ecadd3560  pop r9
00007e4ecadd3562  pop r8
00007e4ecadd3564  pop rsi
00007e4ecadd3565  pop rdi
00007e4ecadd3566  pop rdx
00007e4ecadd3567  pop rcx
00007e4ecadd3568  pop rax
00007e4ecadd3569  add rsp, 0x08
00007e4ecadd356d  jmp 0x00007E4ECADCFEF1
00007e4ecadd3572  sub rsp, 0x08
00007e4ecadd3576  push rax
00007e4ecadd3577  push rcx
00007e4ecadd3578  push rdx
00007e4ecadd3579  push rdi
00007e4ecadd357a  push rsi
00007e4ecadd357b  push r8
00007e4ecadd357d  push r9
00007e4ecadd357f  push r10
00007e4ecadd3581  push r11
00007e4ecadd3583  sub rsp, 0xF0
00007e4ecadd358a  vmovaps [rsp], xmm0
00007e4ecadd358f  vmovaps [rsp+0x10], xmm1
00007e4ecadd3595  vmovaps [rsp+0x20], xmm2
00007e4ecadd359b  vmovaps [rsp+0x30], xmm3
00007e4ecadd35a1  vmovaps [rsp+0x40], xmm4
00007e4ecadd35a7  vmovaps [rsp+0x50], xmm5
00007e4ecadd35ad  vmovaps [rsp+0x60], xmm7
00007e4ecadd35b3  vmovaps [rsp+0x70], xmm8
00007e4ecadd35b9  vmovaps [rsp+0x80], xmm9
00007e4ecadd35c2  vmovaps [rsp+0x90], xmm10
00007e4ecadd35cb  vmovaps [rsp+0xA0], xmm11
00007e4ecadd35d4  vmovaps [rsp+0xB0], xmm12
00007e4ecadd35dd  vmovaps [rsp+0xC0], xmm13
00007e4ecadd35e6  vmovaps [rsp+0xD0], xmm14
00007e4ecadd35ef  vmovaps [rsp+0xE0], xmm15
00007e4ecadd35f8  sub rsp, 0x30
00007e4ecadd35fc  movaps [rsp], xmm6
00007e4ecadd3600  movaps [rsp+0x10], xmm9
00007e4ecadd3606  movaps [rsp+0x20], xmm12
00007e4ecadd360c  lea rdi, [rsp]
00007e4ecadd3610  mov esi, 0x00
00007e4ecadd3615  mov rax, 0x5784BC1F5530
00007e4ecadd361f  call rax
00007e4ecadd3621  movaps xmm6, [rsp]
00007e4ecadd3625  add rsp, 0x30
00007e4ecadd3629  vmovaps xmm0, [rsp]
00007e4ecadd362e  vmovaps xmm1, [rsp+0x10]
00007e4ecadd3634  vmovaps xmm2, [rsp+0x20]
00007e4ecadd363a  vmovaps xmm3, [rsp+0x30]
00007e4ecadd3640  vmovaps xmm4, [rsp+0x40]
00007e4ecadd3646  vmovaps xmm5, [rsp+0x50]
00007e4ecadd364c  vmovaps xmm7, [rsp+0x60]
00007e4ecadd3652  vmovaps xmm8, [rsp+0x70]
00007e4ecadd3658  vmovaps xmm9, [rsp+0x80]
00007e4ecadd3661  vmovaps xmm10, [rsp+0x90]
00007e4ecadd366a  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd3673  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd367c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd3685  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd368e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3697  add rsp, 0xF0
00007e4ecadd369e  pop r11
00007e4ecadd36a0  pop r10
00007e4ecadd36a2  pop r9
00007e4ecadd36a4  pop r8
00007e4ecadd36a6  pop rsi
00007e4ecadd36a7  pop rdi
00007e4ecadd36a8  pop rdx
00007e4ecadd36a9  pop rcx
00007e4ecadd36aa  pop rax
00007e4ecadd36ab  add rsp, 0x08
00007e4ecadd36af  jmp 0x00007E4ECADCFF19
00007e4ecadd36b4  sub rsp, 0x08
00007e4ecadd36b8  push rax
00007e4ecadd36b9  push rcx
00007e4ecadd36ba  push rdx
00007e4ecadd36bb  push rdi
00007e4ecadd36bc  push rsi
00007e4ecadd36bd  push r8
00007e4ecadd36bf  push r9
00007e4ecadd36c1  push r10
00007e4ecadd36c3  push r11
00007e4ecadd36c5  sub rsp, 0xF0
00007e4ecadd36cc  vmovaps [rsp], xmm0
00007e4ecadd36d1  vmovaps [rsp+0x10], xmm1
00007e4ecadd36d7  vmovaps [rsp+0x20], xmm2
00007e4ecadd36dd  vmovaps [rsp+0x30], xmm3
00007e4ecadd36e3  vmovaps [rsp+0x40], xmm4
00007e4ecadd36e9  vmovaps [rsp+0x50], xmm5
00007e4ecadd36ef  vmovaps [rsp+0x60], xmm6
00007e4ecadd36f5  vmovaps [rsp+0x70], xmm7
00007e4ecadd36fb  vmovaps [rsp+0x80], xmm8
00007e4ecadd3704  vmovaps [rsp+0x90], xmm9
00007e4ecadd370d  vmovaps [rsp+0xA0], xmm10
00007e4ecadd3716  vmovaps [rsp+0xB0], xmm11
00007e4ecadd371f  vmovaps [rsp+0xC0], xmm13
00007e4ecadd3728  vmovaps [rsp+0xD0], xmm14
00007e4ecadd3731  vmovaps [rsp+0xE0], xmm15
00007e4ecadd373a  sub rsp, 0x30
00007e4ecadd373e  movaps [rsp], xmm12
00007e4ecadd3743  movaps [rsp+0x10], xmm15
00007e4ecadd3749  movaps [rsp+0x20], xmm13
00007e4ecadd374f  lea rdi, [rsp]
00007e4ecadd3753  mov esi, 0x00
00007e4ecadd3758  mov rax, 0x5784BC1F5530
00007e4ecadd3762  call rax
00007e4ecadd3764  movaps xmm12, [rsp]
00007e4ecadd3769  add rsp, 0x30
00007e4ecadd376d  vmovaps xmm0, [rsp]
00007e4ecadd3772  vmovaps xmm1, [rsp+0x10]
00007e4ecadd3778  vmovaps xmm2, [rsp+0x20]
00007e4ecadd377e  vmovaps xmm3, [rsp+0x30]
00007e4ecadd3784  vmovaps xmm4, [rsp+0x40]
00007e4ecadd378a  vmovaps xmm5, [rsp+0x50]
00007e4ecadd3790  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3796  vmovaps xmm7, [rsp+0x70]
00007e4ecadd379c  vmovaps xmm8, [rsp+0x80]
00007e4ecadd37a5  vmovaps xmm9, [rsp+0x90]
00007e4ecadd37ae  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd37b7  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd37c0  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd37c9  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd37d2  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd37db  add rsp, 0xF0
00007e4ecadd37e2  pop r11
00007e4ecadd37e4  pop r10
00007e4ecadd37e6  pop r9
00007e4ecadd37e8  pop r8
00007e4ecadd37ea  pop rsi
00007e4ecadd37eb  pop rdi
00007e4ecadd37ec  pop rdx
00007e4ecadd37ed  pop rcx
00007e4ecadd37ee  pop rax
00007e4ecadd37ef  add rsp, 0x08
00007e4ecadd37f3  jmp 0x00007E4ECADCFF34
00007e4ecadd37f8  sub rsp, 0x08
00007e4ecadd37fc  push rax
00007e4ecadd37fd  push rcx
00007e4ecadd37fe  push rdx
00007e4ecadd37ff  push rdi
00007e4ecadd3800  push rsi
00007e4ecadd3801  push r8
00007e4ecadd3803  push r9
00007e4ecadd3805  push r10
00007e4ecadd3807  push r11
00007e4ecadd3809  sub rsp, 0xF0
00007e4ecadd3810  vmovaps [rsp], xmm0
00007e4ecadd3815  vmovaps [rsp+0x10], xmm1
00007e4ecadd381b  vmovaps [rsp+0x20], xmm2
00007e4ecadd3821  vmovaps [rsp+0x30], xmm3
00007e4ecadd3827  vmovaps [rsp+0x40], xmm4
00007e4ecadd382d  vmovaps [rsp+0x50], xmm5
00007e4ecadd3833  vmovaps [rsp+0x60], xmm6
00007e4ecadd3839  vmovaps [rsp+0x70], xmm7
00007e4ecadd383f  vmovaps [rsp+0x80], xmm8
00007e4ecadd3848  vmovaps [rsp+0x90], xmm9
00007e4ecadd3851  vmovaps [rsp+0xA0], xmm10
00007e4ecadd385a  vmovaps [rsp+0xB0], xmm11
00007e4ecadd3863  vmovaps [rsp+0xC0], xmm12
00007e4ecadd386c  vmovaps [rsp+0xD0], xmm13
00007e4ecadd3875  vmovaps [rsp+0xE0], xmm14
00007e4ecadd387e  sub rsp, 0x30
00007e4ecadd3882  movaps [rsp], xmm15
00007e4ecadd3887  movaps [rsp+0x10], xmm13
00007e4ecadd388d  movaps [rsp+0x20], xmm10
00007e4ecadd3893  lea rdi, [rsp]
00007e4ecadd3897  mov esi, 0x00
00007e4ecadd389c  mov rax, 0x5784BC1F5530
00007e4ecadd38a6  call rax
00007e4ecadd38a8  movaps xmm15, [rsp]
00007e4ecadd38ad  add rsp, 0x30
00007e4ecadd38b1  vmovaps xmm0, [rsp]
00007e4ecadd38b6  vmovaps xmm1, [rsp+0x10]
00007e4ecadd38bc  vmovaps xmm2, [rsp+0x20]
00007e4ecadd38c2  vmovaps xmm3, [rsp+0x30]
00007e4ecadd38c8  vmovaps xmm4, [rsp+0x40]
00007e4ecadd38ce  vmovaps xmm5, [rsp+0x50]
00007e4ecadd38d4  vmovaps xmm6, [rsp+0x60]
00007e4ecadd38da  vmovaps xmm7, [rsp+0x70]
00007e4ecadd38e0  vmovaps xmm8, [rsp+0x80]
00007e4ecadd38e9  vmovaps xmm9, [rsp+0x90]
00007e4ecadd38f2  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd38fb  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd3904  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd390d  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd3916  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd391f  add rsp, 0xF0
00007e4ecadd3926  pop r11
00007e4ecadd3928  pop r10
00007e4ecadd392a  pop r9
00007e4ecadd392c  pop r8
00007e4ecadd392e  pop rsi
00007e4ecadd392f  pop rdi
00007e4ecadd3930  pop rdx
00007e4ecadd3931  pop rcx
00007e4ecadd3932  pop rax
00007e4ecadd3933  add rsp, 0x08
00007e4ecadd3937  jmp 0x00007E4ECADCFF55
00007e4ecadd393c  call 0x00007E4ECAC0C260
00007e4ecadd3941  jmp 0x00007E4ECADCFFB0
00007e4ecadd3946  sub rsp, 0x08
00007e4ecadd394a  push rax
00007e4ecadd394b  push rcx
00007e4ecadd394c  push rdx
00007e4ecadd394d  push rdi
00007e4ecadd394e  push rsi
00007e4ecadd394f  push r8
00007e4ecadd3951  push r9
00007e4ecadd3953  push r10
00007e4ecadd3955  push r11
00007e4ecadd3957  sub rsp, 0xF0
00007e4ecadd395e  vmovaps [rsp], xmm0
00007e4ecadd3963  vmovaps [rsp+0x10], xmm1
00007e4ecadd3969  vmovaps [rsp+0x20], xmm2
00007e4ecadd396f  vmovaps [rsp+0x30], xmm3
00007e4ecadd3975  vmovaps [rsp+0x40], xmm4
00007e4ecadd397b  vmovaps [rsp+0x50], xmm5
00007e4ecadd3981  vmovaps [rsp+0x60], xmm6
00007e4ecadd3987  vmovaps [rsp+0x70], xmm7
00007e4ecadd398d  vmovaps [rsp+0x80], xmm8
00007e4ecadd3996  vmovaps [rsp+0x90], xmm10
00007e4ecadd399f  vmovaps [rsp+0xA0], xmm11
00007e4ecadd39a8  vmovaps [rsp+0xB0], xmm12
00007e4ecadd39b1  vmovaps [rsp+0xC0], xmm13
00007e4ecadd39ba  vmovaps [rsp+0xD0], xmm14
00007e4ecadd39c3  vmovaps [rsp+0xE0], xmm15
00007e4ecadd39cc  sub rsp, 0x30
00007e4ecadd39d0  movaps [rsp], xmm9
00007e4ecadd39d5  movaps [rsp+0x10], xmm8
00007e4ecadd39db  movaps [rsp+0x20], xmm10
00007e4ecadd39e1  lea rdi, [rsp]
00007e4ecadd39e5  mov esi, 0x00
00007e4ecadd39ea  mov rax, 0x5784BC1F5530
00007e4ecadd39f4  call rax
00007e4ecadd39f6  movaps xmm9, [rsp]
00007e4ecadd39fb  add rsp, 0x30
00007e4ecadd39ff  vmovaps xmm0, [rsp]
00007e4ecadd3a04  vmovaps xmm1, [rsp+0x10]
00007e4ecadd3a0a  vmovaps xmm2, [rsp+0x20]
00007e4ecadd3a10  vmovaps xmm3, [rsp+0x30]
00007e4ecadd3a16  vmovaps xmm4, [rsp+0x40]
00007e4ecadd3a1c  vmovaps xmm5, [rsp+0x50]
00007e4ecadd3a22  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3a28  vmovaps xmm7, [rsp+0x70]
00007e4ecadd3a2e  vmovaps xmm8, [rsp+0x80]
00007e4ecadd3a37  vmovaps xmm10, [rsp+0x90]
00007e4ecadd3a40  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd3a49  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd3a52  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd3a5b  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd3a64  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3a6d  add rsp, 0xF0
00007e4ecadd3a74  pop r11
00007e4ecadd3a76  pop r10
00007e4ecadd3a78  pop r9
00007e4ecadd3a7a  pop r8
00007e4ecadd3a7c  pop rsi
00007e4ecadd3a7d  pop rdi
00007e4ecadd3a7e  pop rdx
00007e4ecadd3a7f  pop rcx
00007e4ecadd3a80  pop rax
00007e4ecadd3a81  add rsp, 0x08
00007e4ecadd3a85  jmp 0x00007E4ECADCFFE1
00007e4ecadd3a8a  sub rsp, 0x08
00007e4ecadd3a8e  push rax
00007e4ecadd3a8f  push rcx
00007e4ecadd3a90  push rdx
00007e4ecadd3a91  push rdi
00007e4ecadd3a92  push rsi
00007e4ecadd3a93  push r8
00007e4ecadd3a95  push r9
00007e4ecadd3a97  push r10
00007e4ecadd3a99  push r11
00007e4ecadd3a9b  sub rsp, 0xF0
00007e4ecadd3aa2  vmovaps [rsp], xmm0
00007e4ecadd3aa7  vmovaps [rsp+0x10], xmm1
00007e4ecadd3aad  vmovaps [rsp+0x20], xmm2
00007e4ecadd3ab3  vmovaps [rsp+0x30], xmm3
00007e4ecadd3ab9  vmovaps [rsp+0x40], xmm4
00007e4ecadd3abf  vmovaps [rsp+0x50], xmm5
00007e4ecadd3ac5  vmovaps [rsp+0x60], xmm6
00007e4ecadd3acb  vmovaps [rsp+0x70], xmm7
00007e4ecadd3ad1  vmovaps [rsp+0x80], xmm8
00007e4ecadd3ada  vmovaps [rsp+0x90], xmm9
00007e4ecadd3ae3  vmovaps [rsp+0xA0], xmm11
00007e4ecadd3aec  vmovaps [rsp+0xB0], xmm12
00007e4ecadd3af5  vmovaps [rsp+0xC0], xmm13
00007e4ecadd3afe  vmovaps [rsp+0xD0], xmm14
00007e4ecadd3b07  vmovaps [rsp+0xE0], xmm15
00007e4ecadd3b10  sub rsp, 0x30
00007e4ecadd3b14  movaps [rsp], xmm10
00007e4ecadd3b19  movaps [rsp+0x10], xmm1
00007e4ecadd3b1e  movaps [rsp+0x20], xmm11
00007e4ecadd3b24  lea rdi, [rsp]
00007e4ecadd3b28  mov esi, 0x00
00007e4ecadd3b2d  mov rax, 0x5784BC1F5530
00007e4ecadd3b37  call rax
00007e4ecadd3b39  movaps xmm10, [rsp]
00007e4ecadd3b3e  add rsp, 0x30
00007e4ecadd3b42  vmovaps xmm0, [rsp]
00007e4ecadd3b47  vmovaps xmm1, [rsp+0x10]
00007e4ecadd3b4d  vmovaps xmm2, [rsp+0x20]
00007e4ecadd3b53  vmovaps xmm3, [rsp+0x30]
00007e4ecadd3b59  vmovaps xmm4, [rsp+0x40]
00007e4ecadd3b5f  vmovaps xmm5, [rsp+0x50]
00007e4ecadd3b65  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3b6b  vmovaps xmm7, [rsp+0x70]
00007e4ecadd3b71  vmovaps xmm8, [rsp+0x80]
00007e4ecadd3b7a  vmovaps xmm9, [rsp+0x90]
00007e4ecadd3b83  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd3b8c  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd3b95  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd3b9e  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd3ba7  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3bb0  add rsp, 0xF0
00007e4ecadd3bb7  pop r11
00007e4ecadd3bb9  pop r10
00007e4ecadd3bbb  pop r9
00007e4ecadd3bbd  pop r8
00007e4ecadd3bbf  pop rsi
00007e4ecadd3bc0  pop rdi
00007e4ecadd3bc1  pop rdx
00007e4ecadd3bc2  pop rcx
00007e4ecadd3bc3  pop rax
00007e4ecadd3bc4  add rsp, 0x08
00007e4ecadd3bc8  jmp 0x00007E4ECADCFFFC
00007e4ecadd3bcd  sub rsp, 0x08
00007e4ecadd3bd1  push rax
00007e4ecadd3bd2  push rcx
00007e4ecadd3bd3  push rdx
00007e4ecadd3bd4  push rdi
00007e4ecadd3bd5  push rsi
00007e4ecadd3bd6  push r8
00007e4ecadd3bd8  push r9
00007e4ecadd3bda  push r10
00007e4ecadd3bdc  push r11
00007e4ecadd3bde  sub rsp, 0xF0
00007e4ecadd3be5  vmovaps [rsp], xmm0
00007e4ecadd3bea  vmovaps [rsp+0x10], xmm2
00007e4ecadd3bf0  vmovaps [rsp+0x20], xmm3
00007e4ecadd3bf6  vmovaps [rsp+0x30], xmm4
00007e4ecadd3bfc  vmovaps [rsp+0x40], xmm5
00007e4ecadd3c02  vmovaps [rsp+0x50], xmm6
00007e4ecadd3c08  vmovaps [rsp+0x60], xmm7
00007e4ecadd3c0e  vmovaps [rsp+0x70], xmm8
00007e4ecadd3c14  vmovaps [rsp+0x80], xmm9
00007e4ecadd3c1d  vmovaps [rsp+0x90], xmm10
00007e4ecadd3c26  vmovaps [rsp+0xA0], xmm11
00007e4ecadd3c2f  vmovaps [rsp+0xB0], xmm12
00007e4ecadd3c38  vmovaps [rsp+0xC0], xmm13
00007e4ecadd3c41  vmovaps [rsp+0xD0], xmm14
00007e4ecadd3c4a  vmovaps [rsp+0xE0], xmm15
00007e4ecadd3c53  sub rsp, 0x30
00007e4ecadd3c57  movaps [rsp], xmm1
00007e4ecadd3c5b  movaps [rsp+0x10], xmm14
00007e4ecadd3c61  movaps [rsp+0x20], xmm6
00007e4ecadd3c66  lea rdi, [rsp]
00007e4ecadd3c6a  mov esi, 0x00
00007e4ecadd3c6f  mov rax, 0x5784BC1F5530
00007e4ecadd3c79  call rax
00007e4ecadd3c7b  movaps xmm1, [rsp]
00007e4ecadd3c7f  add rsp, 0x30
00007e4ecadd3c83  vmovaps xmm0, [rsp]
00007e4ecadd3c88  vmovaps xmm2, [rsp+0x10]
00007e4ecadd3c8e  vmovaps xmm3, [rsp+0x20]
00007e4ecadd3c94  vmovaps xmm4, [rsp+0x30]
00007e4ecadd3c9a  vmovaps xmm5, [rsp+0x40]
00007e4ecadd3ca0  vmovaps xmm6, [rsp+0x50]
00007e4ecadd3ca6  vmovaps xmm7, [rsp+0x60]
00007e4ecadd3cac  vmovaps xmm8, [rsp+0x70]
00007e4ecadd3cb2  vmovaps xmm9, [rsp+0x80]
00007e4ecadd3cbb  vmovaps xmm10, [rsp+0x90]
00007e4ecadd3cc4  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd3ccd  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd3cd6  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd3cdf  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd3ce8  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3cf1  add rsp, 0xF0
00007e4ecadd3cf8  pop r11
00007e4ecadd3cfa  pop r10
00007e4ecadd3cfc  pop r9
00007e4ecadd3cfe  pop r8
00007e4ecadd3d00  pop rsi
00007e4ecadd3d01  pop rdi
00007e4ecadd3d02  pop rdx
00007e4ecadd3d03  pop rcx
00007e4ecadd3d04  pop rax
00007e4ecadd3d05  add rsp, 0x08
00007e4ecadd3d09  jmp 0x00007E4ECADD0015
00007e4ecadd3d0e  sub rsp, 0x08
00007e4ecadd3d12  push rax
00007e4ecadd3d13  push rcx
00007e4ecadd3d14  push rdx
00007e4ecadd3d15  push rdi
00007e4ecadd3d16  push rsi
00007e4ecadd3d17  push r8
00007e4ecadd3d19  push r9
00007e4ecadd3d1b  push r10
00007e4ecadd3d1d  push r11
00007e4ecadd3d1f  sub rsp, 0xF0
00007e4ecadd3d26  vmovaps [rsp], xmm0
00007e4ecadd3d2b  vmovaps [rsp+0x10], xmm1
00007e4ecadd3d31  vmovaps [rsp+0x20], xmm2
00007e4ecadd3d37  vmovaps [rsp+0x30], xmm3
00007e4ecadd3d3d  vmovaps [rsp+0x40], xmm4
00007e4ecadd3d43  vmovaps [rsp+0x50], xmm5
00007e4ecadd3d49  vmovaps [rsp+0x60], xmm6
00007e4ecadd3d4f  vmovaps [rsp+0x70], xmm7
00007e4ecadd3d55  vmovaps [rsp+0x80], xmm8
00007e4ecadd3d5e  vmovaps [rsp+0x90], xmm9
00007e4ecadd3d67  vmovaps [rsp+0xA0], xmm10
00007e4ecadd3d70  vmovaps [rsp+0xB0], xmm12
00007e4ecadd3d79  vmovaps [rsp+0xC0], xmm13
00007e4ecadd3d82  vmovaps [rsp+0xD0], xmm14
00007e4ecadd3d8b  vmovaps [rsp+0xE0], xmm15
00007e4ecadd3d94  sub rsp, 0x30
00007e4ecadd3d98  movaps [rsp], xmm11
00007e4ecadd3d9d  movaps [rsp+0x10], xmm13
00007e4ecadd3da3  movaps [rsp+0x20], xmm14
00007e4ecadd3da9  lea rdi, [rsp]
00007e4ecadd3dad  mov esi, 0x00
00007e4ecadd3db2  mov rax, 0x5784BC1F5530
00007e4ecadd3dbc  call rax
00007e4ecadd3dbe  movaps xmm11, [rsp]
00007e4ecadd3dc3  add rsp, 0x30
00007e4ecadd3dc7  vmovaps xmm0, [rsp]
00007e4ecadd3dcc  vmovaps xmm1, [rsp+0x10]
00007e4ecadd3dd2  vmovaps xmm2, [rsp+0x20]
00007e4ecadd3dd8  vmovaps xmm3, [rsp+0x30]
00007e4ecadd3dde  vmovaps xmm4, [rsp+0x40]
00007e4ecadd3de4  vmovaps xmm5, [rsp+0x50]
00007e4ecadd3dea  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3df0  vmovaps xmm7, [rsp+0x70]
00007e4ecadd3df6  vmovaps xmm8, [rsp+0x80]
00007e4ecadd3dff  vmovaps xmm9, [rsp+0x90]
00007e4ecadd3e08  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd3e11  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd3e1a  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd3e23  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd3e2c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3e35  add rsp, 0xF0
00007e4ecadd3e3c  pop r11
00007e4ecadd3e3e  pop r10
00007e4ecadd3e40  pop r9
00007e4ecadd3e42  pop r8
00007e4ecadd3e44  pop rsi
00007e4ecadd3e45  pop rdi
00007e4ecadd3e46  pop rdx
00007e4ecadd3e47  pop rcx
00007e4ecadd3e48  pop rax
00007e4ecadd3e49  add rsp, 0x08
00007e4ecadd3e4d  jmp 0x00007E4ECADD003F
00007e4ecadd3e52  sub rsp, 0x08
00007e4ecadd3e56  push rax
00007e4ecadd3e57  push rcx
00007e4ecadd3e58  push rdx
00007e4ecadd3e59  push rdi
00007e4ecadd3e5a  push rsi
00007e4ecadd3e5b  push r8
00007e4ecadd3e5d  push r9
00007e4ecadd3e5f  push r10
00007e4ecadd3e61  push r11
00007e4ecadd3e63  sub rsp, 0xF0
00007e4ecadd3e6a  vmovaps [rsp], xmm0
00007e4ecadd3e6f  vmovaps [rsp+0x10], xmm1
00007e4ecadd3e75  vmovaps [rsp+0x20], xmm2
00007e4ecadd3e7b  vmovaps [rsp+0x30], xmm3
00007e4ecadd3e81  vmovaps [rsp+0x40], xmm4
00007e4ecadd3e87  vmovaps [rsp+0x50], xmm5
00007e4ecadd3e8d  vmovaps [rsp+0x60], xmm6
00007e4ecadd3e93  vmovaps [rsp+0x70], xmm7
00007e4ecadd3e99  vmovaps [rsp+0x80], xmm8
00007e4ecadd3ea2  vmovaps [rsp+0x90], xmm9
00007e4ecadd3eab  vmovaps [rsp+0xA0], xmm10
00007e4ecadd3eb4  vmovaps [rsp+0xB0], xmm11
00007e4ecadd3ebd  vmovaps [rsp+0xC0], xmm12
00007e4ecadd3ec6  vmovaps [rsp+0xD0], xmm14
00007e4ecadd3ecf  vmovaps [rsp+0xE0], xmm15
00007e4ecadd3ed8  sub rsp, 0x30
00007e4ecadd3edc  movaps [rsp], xmm13
00007e4ecadd3ee1  movaps [rsp+0x10], xmm8
00007e4ecadd3ee7  movaps [rsp+0x20], xmm14
00007e4ecadd3eed  lea rdi, [rsp]
00007e4ecadd3ef1  mov esi, 0x00
00007e4ecadd3ef6  mov rax, 0x5784BC1F5530
00007e4ecadd3f00  call rax
00007e4ecadd3f02  movaps xmm13, [rsp]
00007e4ecadd3f07  add rsp, 0x30
00007e4ecadd3f0b  vmovaps xmm0, [rsp]
00007e4ecadd3f10  vmovaps xmm1, [rsp+0x10]
00007e4ecadd3f16  vmovaps xmm2, [rsp+0x20]
00007e4ecadd3f1c  vmovaps xmm3, [rsp+0x30]
00007e4ecadd3f22  vmovaps xmm4, [rsp+0x40]
00007e4ecadd3f28  vmovaps xmm5, [rsp+0x50]
00007e4ecadd3f2e  vmovaps xmm6, [rsp+0x60]
00007e4ecadd3f34  vmovaps xmm7, [rsp+0x70]
00007e4ecadd3f3a  vmovaps xmm8, [rsp+0x80]
00007e4ecadd3f43  vmovaps xmm9, [rsp+0x90]
00007e4ecadd3f4c  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd3f55  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd3f5e  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd3f67  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd3f70  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd3f79  add rsp, 0xF0
00007e4ecadd3f80  pop r11
00007e4ecadd3f82  pop r10
00007e4ecadd3f84  pop r9
00007e4ecadd3f86  pop r8
00007e4ecadd3f88  pop rsi
00007e4ecadd3f89  pop rdi
00007e4ecadd3f8a  pop rdx
00007e4ecadd3f8b  pop rcx
00007e4ecadd3f8c  pop rax
00007e4ecadd3f8d  add rsp, 0x08
00007e4ecadd3f91  jmp 0x00007E4ECADD006E
00007e4ecadd3f96  sub rsp, 0x08
00007e4ecadd3f9a  push rax
00007e4ecadd3f9b  push rcx
00007e4ecadd3f9c  push rdx
00007e4ecadd3f9d  push rdi
00007e4ecadd3f9e  push rsi
00007e4ecadd3f9f  push r8
00007e4ecadd3fa1  push r9
00007e4ecadd3fa3  push r10
00007e4ecadd3fa5  push r11
00007e4ecadd3fa7  sub rsp, 0xF0
00007e4ecadd3fae  vmovaps [rsp], xmm0
00007e4ecadd3fb3  vmovaps [rsp+0x10], xmm1
00007e4ecadd3fb9  vmovaps [rsp+0x20], xmm2
00007e4ecadd3fbf  vmovaps [rsp+0x30], xmm3
00007e4ecadd3fc5  vmovaps [rsp+0x40], xmm4
00007e4ecadd3fcb  vmovaps [rsp+0x50], xmm5
00007e4ecadd3fd1  vmovaps [rsp+0x60], xmm6
00007e4ecadd3fd7  vmovaps [rsp+0x70], xmm7
00007e4ecadd3fdd  vmovaps [rsp+0x80], xmm9
00007e4ecadd3fe6  vmovaps [rsp+0x90], xmm10
00007e4ecadd3fef  vmovaps [rsp+0xA0], xmm11
00007e4ecadd3ff8  vmovaps [rsp+0xB0], xmm12
00007e4ecadd4001  vmovaps [rsp+0xC0], xmm13
00007e4ecadd400a  vmovaps [rsp+0xD0], xmm14
00007e4ecadd4013  vmovaps [rsp+0xE0], xmm15
00007e4ecadd401c  sub rsp, 0x30
00007e4ecadd4020  movaps [rsp], xmm8
00007e4ecadd4025  movaps [rsp+0x10], xmm7
00007e4ecadd402a  movaps [rsp+0x20], xmm14
00007e4ecadd4030  lea rdi, [rsp]
00007e4ecadd4034  mov esi, 0x00
00007e4ecadd4039  mov rax, 0x5784BC1F5530
00007e4ecadd4043  call rax
00007e4ecadd4045  movaps xmm8, [rsp]
00007e4ecadd404a  add rsp, 0x30
00007e4ecadd404e  vmovaps xmm0, [rsp]
00007e4ecadd4053  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4059  vmovaps xmm2, [rsp+0x20]
00007e4ecadd405f  vmovaps xmm3, [rsp+0x30]
00007e4ecadd4065  vmovaps xmm4, [rsp+0x40]
00007e4ecadd406b  vmovaps xmm5, [rsp+0x50]
00007e4ecadd4071  vmovaps xmm6, [rsp+0x60]
00007e4ecadd4077  vmovaps xmm7, [rsp+0x70]
00007e4ecadd407d  vmovaps xmm9, [rsp+0x80]
00007e4ecadd4086  vmovaps xmm10, [rsp+0x90]
00007e4ecadd408f  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd4098  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd40a1  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd40aa  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd40b3  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd40bc  add rsp, 0xF0
00007e4ecadd40c3  pop r11
00007e4ecadd40c5  pop r10
00007e4ecadd40c7  pop r9
00007e4ecadd40c9  pop r8
00007e4ecadd40cb  pop rsi
00007e4ecadd40cc  pop rdi
00007e4ecadd40cd  pop rdx
00007e4ecadd40ce  pop rcx
00007e4ecadd40cf  pop rax
00007e4ecadd40d0  add rsp, 0x08
00007e4ecadd40d4  jmp 0x00007E4ECADD0094
00007e4ecadd40d9  sub rsp, 0x08
00007e4ecadd40dd  push rax
00007e4ecadd40de  push rcx
00007e4ecadd40df  push rdx
00007e4ecadd40e0  push rdi
00007e4ecadd40e1  push rsi
00007e4ecadd40e2  push r8
00007e4ecadd40e4  push r9
00007e4ecadd40e6  push r10
00007e4ecadd40e8  push r11
00007e4ecadd40ea  sub rsp, 0xF0
00007e4ecadd40f1  vmovaps [rsp], xmm0
00007e4ecadd40f6  vmovaps [rsp+0x10], xmm1
00007e4ecadd40fc  vmovaps [rsp+0x20], xmm2
00007e4ecadd4102  vmovaps [rsp+0x30], xmm3
00007e4ecadd4108  vmovaps [rsp+0x40], xmm4
00007e4ecadd410e  vmovaps [rsp+0x50], xmm5
00007e4ecadd4114  vmovaps [rsp+0x60], xmm6
00007e4ecadd411a  vmovaps [rsp+0x70], xmm7
00007e4ecadd4120  vmovaps [rsp+0x80], xmm8
00007e4ecadd4129  vmovaps [rsp+0x90], xmm9
00007e4ecadd4132  vmovaps [rsp+0xA0], xmm10
00007e4ecadd413b  vmovaps [rsp+0xB0], xmm11
00007e4ecadd4144  vmovaps [rsp+0xC0], xmm12
00007e4ecadd414d  vmovaps [rsp+0xD0], xmm13
00007e4ecadd4156  vmovaps [rsp+0xE0], xmm15
00007e4ecadd415f  sub rsp, 0x30
00007e4ecadd4163  movaps [rsp], xmm14
00007e4ecadd4168  movaps [rsp+0x10], xmm12
00007e4ecadd416e  movaps [rsp+0x20], xmm9
00007e4ecadd4174  lea rdi, [rsp]
00007e4ecadd4178  mov esi, 0x00
00007e4ecadd417d  mov rax, 0x5784BC1F5530
00007e4ecadd4187  call rax
00007e4ecadd4189  movaps xmm14, [rsp]
00007e4ecadd418e  add rsp, 0x30
00007e4ecadd4192  vmovaps xmm0, [rsp]
00007e4ecadd4197  vmovaps xmm1, [rsp+0x10]
00007e4ecadd419d  vmovaps xmm2, [rsp+0x20]
00007e4ecadd41a3  vmovaps xmm3, [rsp+0x30]
00007e4ecadd41a9  vmovaps xmm4, [rsp+0x40]
00007e4ecadd41af  vmovaps xmm5, [rsp+0x50]
00007e4ecadd41b5  vmovaps xmm6, [rsp+0x60]
00007e4ecadd41bb  vmovaps xmm7, [rsp+0x70]
00007e4ecadd41c1  vmovaps xmm8, [rsp+0x80]
00007e4ecadd41ca  vmovaps xmm9, [rsp+0x90]
00007e4ecadd41d3  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd41dc  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd41e5  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd41ee  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd41f7  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4200  add rsp, 0xF0
00007e4ecadd4207  pop r11
00007e4ecadd4209  pop r10
00007e4ecadd420b  pop r9
00007e4ecadd420d  pop r8
00007e4ecadd420f  pop rsi
00007e4ecadd4210  pop rdi
00007e4ecadd4211  pop rdx
00007e4ecadd4212  pop rcx
00007e4ecadd4213  pop rax
00007e4ecadd4214  add rsp, 0x08
00007e4ecadd4218  jmp 0x00007E4ECADD00AE
00007e4ecadd421d  sub rsp, 0x08
00007e4ecadd4221  push rax
00007e4ecadd4222  push rcx
00007e4ecadd4223  push rdx
00007e4ecadd4224  push rdi
00007e4ecadd4225  push rsi
00007e4ecadd4226  push r8
00007e4ecadd4228  push r9
00007e4ecadd422a  push r10
00007e4ecadd422c  push r11
00007e4ecadd422e  sub rsp, 0xF0
00007e4ecadd4235  vmovaps [rsp], xmm0
00007e4ecadd423a  vmovaps [rsp+0x10], xmm1
00007e4ecadd4240  vmovaps [rsp+0x20], xmm2
00007e4ecadd4246  vmovaps [rsp+0x30], xmm3
00007e4ecadd424c  vmovaps [rsp+0x40], xmm4
00007e4ecadd4252  vmovaps [rsp+0x50], xmm5
00007e4ecadd4258  vmovaps [rsp+0x60], xmm6
00007e4ecadd425e  vmovaps [rsp+0x70], xmm7
00007e4ecadd4264  vmovaps [rsp+0x80], xmm8
00007e4ecadd426d  vmovaps [rsp+0x90], xmm10
00007e4ecadd4276  vmovaps [rsp+0xA0], xmm11
00007e4ecadd427f  vmovaps [rsp+0xB0], xmm12
00007e4ecadd4288  vmovaps [rsp+0xC0], xmm13
00007e4ecadd4291  vmovaps [rsp+0xD0], xmm14
00007e4ecadd429a  vmovaps [rsp+0xE0], xmm15
00007e4ecadd42a3  sub rsp, 0x30
00007e4ecadd42a7  movaps [rsp], xmm9
00007e4ecadd42ac  movaps [rsp+0x10], xmm7
00007e4ecadd42b1  movaps [rsp+0x20], xmm12
00007e4ecadd42b7  lea rdi, [rsp]
00007e4ecadd42bb  mov esi, 0x00
00007e4ecadd42c0  mov rax, 0x5784BC1F5530
00007e4ecadd42ca  call rax
00007e4ecadd42cc  movaps xmm9, [rsp]
00007e4ecadd42d1  add rsp, 0x30
00007e4ecadd42d5  vmovaps xmm0, [rsp]
00007e4ecadd42da  vmovaps xmm1, [rsp+0x10]
00007e4ecadd42e0  vmovaps xmm2, [rsp+0x20]
00007e4ecadd42e6  vmovaps xmm3, [rsp+0x30]
00007e4ecadd42ec  vmovaps xmm4, [rsp+0x40]
00007e4ecadd42f2  vmovaps xmm5, [rsp+0x50]
00007e4ecadd42f8  vmovaps xmm6, [rsp+0x60]
00007e4ecadd42fe  vmovaps xmm7, [rsp+0x70]
00007e4ecadd4304  vmovaps xmm8, [rsp+0x80]
00007e4ecadd430d  vmovaps xmm10, [rsp+0x90]
00007e4ecadd4316  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd431f  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd4328  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd4331  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd433a  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4343  add rsp, 0xF0
00007e4ecadd434a  pop r11
00007e4ecadd434c  pop r10
00007e4ecadd434e  pop r9
00007e4ecadd4350  pop r8
00007e4ecadd4352  pop rsi
00007e4ecadd4353  pop rdi
00007e4ecadd4354  pop rdx
00007e4ecadd4355  pop rcx
00007e4ecadd4356  pop rax
00007e4ecadd4357  add rsp, 0x08
00007e4ecadd435b  jmp 0x00007E4ECADD00DD
00007e4ecadd4360  sub rsp, 0x08
00007e4ecadd4364  push rax
00007e4ecadd4365  push rcx
00007e4ecadd4366  push rdx
00007e4ecadd4367  push rdi
00007e4ecadd4368  push rsi
00007e4ecadd4369  push r8
00007e4ecadd436b  push r9
00007e4ecadd436d  push r10
00007e4ecadd436f  push r11
00007e4ecadd4371  sub rsp, 0xF0
00007e4ecadd4378  vmovaps [rsp], xmm0
00007e4ecadd437d  vmovaps [rsp+0x10], xmm1
00007e4ecadd4383  vmovaps [rsp+0x20], xmm2
00007e4ecadd4389  vmovaps [rsp+0x30], xmm3
00007e4ecadd438f  vmovaps [rsp+0x40], xmm4
00007e4ecadd4395  vmovaps [rsp+0x50], xmm5
00007e4ecadd439b  vmovaps [rsp+0x60], xmm6
00007e4ecadd43a1  vmovaps [rsp+0x70], xmm7
00007e4ecadd43a7  vmovaps [rsp+0x80], xmm8
00007e4ecadd43b0  vmovaps [rsp+0x90], xmm9
00007e4ecadd43b9  vmovaps [rsp+0xA0], xmm10
00007e4ecadd43c2  vmovaps [rsp+0xB0], xmm11
00007e4ecadd43cb  vmovaps [rsp+0xC0], xmm13
00007e4ecadd43d4  vmovaps [rsp+0xD0], xmm14
00007e4ecadd43dd  vmovaps [rsp+0xE0], xmm15
00007e4ecadd43e6  sub rsp, 0x30
00007e4ecadd43ea  movaps [rsp], xmm12
00007e4ecadd43ef  movaps [rsp+0x10], xmm15
00007e4ecadd43f5  movaps [rsp+0x20], xmm11
00007e4ecadd43fb  lea rdi, [rsp]
00007e4ecadd43ff  mov esi, 0x00
00007e4ecadd4404  mov rax, 0x5784BC1F5530
00007e4ecadd440e  call rax
00007e4ecadd4410  movaps xmm12, [rsp]
00007e4ecadd4415  add rsp, 0x30
00007e4ecadd4419  vmovaps xmm0, [rsp]
00007e4ecadd441e  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4424  vmovaps xmm2, [rsp+0x20]
00007e4ecadd442a  vmovaps xmm3, [rsp+0x30]
00007e4ecadd4430  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4436  vmovaps xmm5, [rsp+0x50]
00007e4ecadd443c  vmovaps xmm6, [rsp+0x60]
00007e4ecadd4442  vmovaps xmm7, [rsp+0x70]
00007e4ecadd4448  vmovaps xmm8, [rsp+0x80]
00007e4ecadd4451  vmovaps xmm9, [rsp+0x90]
00007e4ecadd445a  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd4463  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd446c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd4475  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd447e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4487  add rsp, 0xF0
00007e4ecadd448e  pop r11
00007e4ecadd4490  pop r10
00007e4ecadd4492  pop r9
00007e4ecadd4494  pop r8
00007e4ecadd4496  pop rsi
00007e4ecadd4497  pop rdi
00007e4ecadd4498  pop rdx
00007e4ecadd4499  pop rcx
00007e4ecadd449a  pop rax
00007e4ecadd449b  add rsp, 0x08
00007e4ecadd449f  jmp 0x00007E4ECADD00F7
00007e4ecadd44a4  sub rsp, 0x08
00007e4ecadd44a8  push rax
00007e4ecadd44a9  push rcx
00007e4ecadd44aa  push rdx
00007e4ecadd44ab  push rdi
00007e4ecadd44ac  push rsi
00007e4ecadd44ad  push r8
00007e4ecadd44af  push r9
00007e4ecadd44b1  push r10
00007e4ecadd44b3  push r11
00007e4ecadd44b5  sub rsp, 0xF0
00007e4ecadd44bc  vmovaps [rsp], xmm0
00007e4ecadd44c1  vmovaps [rsp+0x10], xmm1
00007e4ecadd44c7  vmovaps [rsp+0x20], xmm2
00007e4ecadd44cd  vmovaps [rsp+0x30], xmm3
00007e4ecadd44d3  vmovaps [rsp+0x40], xmm4
00007e4ecadd44d9  vmovaps [rsp+0x50], xmm5
00007e4ecadd44df  vmovaps [rsp+0x60], xmm6
00007e4ecadd44e5  vmovaps [rsp+0x70], xmm7
00007e4ecadd44eb  vmovaps [rsp+0x80], xmm8
00007e4ecadd44f4  vmovaps [rsp+0x90], xmm9
00007e4ecadd44fd  vmovaps [rsp+0xA0], xmm10
00007e4ecadd4506  vmovaps [rsp+0xB0], xmm12
00007e4ecadd450f  vmovaps [rsp+0xC0], xmm13
00007e4ecadd4518  vmovaps [rsp+0xD0], xmm14
00007e4ecadd4521  vmovaps [rsp+0xE0], xmm15
00007e4ecadd452a  sub rsp, 0x30
00007e4ecadd452e  movaps [rsp], xmm11
00007e4ecadd4533  movaps [rsp+0x10], xmm7
00007e4ecadd4538  movaps [rsp+0x20], xmm15
00007e4ecadd453e  lea rdi, [rsp]
00007e4ecadd4542  mov esi, 0x00
00007e4ecadd4547  mov rax, 0x5784BC1F5530
00007e4ecadd4551  call rax
00007e4ecadd4553  movaps xmm11, [rsp]
00007e4ecadd4558  add rsp, 0x30
00007e4ecadd455c  vmovaps xmm0, [rsp]
00007e4ecadd4561  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4567  vmovaps xmm2, [rsp+0x20]
00007e4ecadd456d  vmovaps xmm3, [rsp+0x30]
00007e4ecadd4573  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4579  vmovaps xmm5, [rsp+0x50]
00007e4ecadd457f  vmovaps xmm6, [rsp+0x60]
00007e4ecadd4585  vmovaps xmm7, [rsp+0x70]
00007e4ecadd458b  vmovaps xmm8, [rsp+0x80]
00007e4ecadd4594  vmovaps xmm9, [rsp+0x90]
00007e4ecadd459d  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd45a6  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd45af  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd45b8  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd45c1  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd45ca  add rsp, 0xF0
00007e4ecadd45d1  pop r11
00007e4ecadd45d3  pop r10
00007e4ecadd45d5  pop r9
00007e4ecadd45d7  pop r8
00007e4ecadd45d9  pop rsi
00007e4ecadd45da  pop rdi
00007e4ecadd45db  pop rdx
00007e4ecadd45dc  pop rcx
00007e4ecadd45dd  pop rax
00007e4ecadd45de  add rsp, 0x08
00007e4ecadd45e2  jmp 0x00007E4ECADD0123
00007e4ecadd45e7  sub rsp, 0x08
00007e4ecadd45eb  push rax
00007e4ecadd45ec  push rcx
00007e4ecadd45ed  push rdx
00007e4ecadd45ee  push rdi
00007e4ecadd45ef  push rsi
00007e4ecadd45f0  push r8
00007e4ecadd45f2  push r9
00007e4ecadd45f4  push r10
00007e4ecadd45f6  push r11
00007e4ecadd45f8  sub rsp, 0xF0
00007e4ecadd45ff  vmovaps [rsp], xmm0
00007e4ecadd4604  vmovaps [rsp+0x10], xmm1
00007e4ecadd460a  vmovaps [rsp+0x20], xmm2
00007e4ecadd4610  vmovaps [rsp+0x30], xmm3
00007e4ecadd4616  vmovaps [rsp+0x40], xmm4
00007e4ecadd461c  vmovaps [rsp+0x50], xmm5
00007e4ecadd4622  vmovaps [rsp+0x60], xmm6
00007e4ecadd4628  vmovaps [rsp+0x70], xmm7
00007e4ecadd462e  vmovaps [rsp+0x80], xmm8
00007e4ecadd4637  vmovaps [rsp+0x90], xmm9
00007e4ecadd4640  vmovaps [rsp+0xA0], xmm10
00007e4ecadd4649  vmovaps [rsp+0xB0], xmm11
00007e4ecadd4652  vmovaps [rsp+0xC0], xmm12
00007e4ecadd465b  vmovaps [rsp+0xD0], xmm13
00007e4ecadd4664  vmovaps [rsp+0xE0], xmm14
00007e4ecadd466d  sub rsp, 0x30
00007e4ecadd4671  movaps [rsp], xmm15
00007e4ecadd4676  movaps [rsp+0x10], xmm10
00007e4ecadd467c  movaps [rsp+0x20], xmm13
00007e4ecadd4682  lea rdi, [rsp]
00007e4ecadd4686  mov esi, 0x00
00007e4ecadd468b  mov rax, 0x5784BC1F5530
00007e4ecadd4695  call rax
00007e4ecadd4697  movaps xmm15, [rsp]
00007e4ecadd469c  add rsp, 0x30
00007e4ecadd46a0  vmovaps xmm0, [rsp]
00007e4ecadd46a5  vmovaps xmm1, [rsp+0x10]
00007e4ecadd46ab  vmovaps xmm2, [rsp+0x20]
00007e4ecadd46b1  vmovaps xmm3, [rsp+0x30]
00007e4ecadd46b7  vmovaps xmm4, [rsp+0x40]
00007e4ecadd46bd  vmovaps xmm5, [rsp+0x50]
00007e4ecadd46c3  vmovaps xmm6, [rsp+0x60]
00007e4ecadd46c9  vmovaps xmm7, [rsp+0x70]
00007e4ecadd46cf  vmovaps xmm8, [rsp+0x80]
00007e4ecadd46d8  vmovaps xmm9, [rsp+0x90]
00007e4ecadd46e1  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd46ea  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd46f3  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd46fc  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd4705  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd470e  add rsp, 0xF0
00007e4ecadd4715  pop r11
00007e4ecadd4717  pop r10
00007e4ecadd4719  pop r9
00007e4ecadd471b  pop r8
00007e4ecadd471d  pop rsi
00007e4ecadd471e  pop rdi
00007e4ecadd471f  pop rdx
00007e4ecadd4720  pop rcx
00007e4ecadd4721  pop rax
00007e4ecadd4722  add rsp, 0x08
00007e4ecadd4726  jmp 0x00007E4ECADD013D
00007e4ecadd472b  sub rsp, 0x08
00007e4ecadd472f  push rax
00007e4ecadd4730  push rcx
00007e4ecadd4731  push rdx
00007e4ecadd4732  push rdi
00007e4ecadd4733  push rsi
00007e4ecadd4734  push r8
00007e4ecadd4736  push r9
00007e4ecadd4738  push r10
00007e4ecadd473a  push r11
00007e4ecadd473c  sub rsp, 0xF0
00007e4ecadd4743  vmovaps [rsp], xmm0
00007e4ecadd4748  vmovaps [rsp+0x10], xmm1
00007e4ecadd474e  vmovaps [rsp+0x20], xmm2
00007e4ecadd4754  vmovaps [rsp+0x30], xmm3
00007e4ecadd475a  vmovaps [rsp+0x40], xmm4
00007e4ecadd4760  vmovaps [rsp+0x50], xmm5
00007e4ecadd4766  vmovaps [rsp+0x60], xmm6
00007e4ecadd476c  vmovaps [rsp+0x70], xmm7
00007e4ecadd4772  vmovaps [rsp+0x80], xmm8
00007e4ecadd477b  vmovaps [rsp+0x90], xmm9
00007e4ecadd4784  vmovaps [rsp+0xA0], xmm11
00007e4ecadd478d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd4796  vmovaps [rsp+0xC0], xmm13
00007e4ecadd479f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd47a8  vmovaps [rsp+0xE0], xmm15
00007e4ecadd47b1  sub rsp, 0x30
00007e4ecadd47b5  movaps [rsp], xmm10
00007e4ecadd47ba  movaps [rsp+0x10], xmm7
00007e4ecadd47bf  movaps [rsp+0x20], xmm13
00007e4ecadd47c5  lea rdi, [rsp]
00007e4ecadd47c9  mov esi, 0x00
00007e4ecadd47ce  mov rax, 0x5784BC1F5530
00007e4ecadd47d8  call rax
00007e4ecadd47da  movaps xmm10, [rsp]
00007e4ecadd47df  add rsp, 0x30
00007e4ecadd47e3  vmovaps xmm0, [rsp]
00007e4ecadd47e8  vmovaps xmm1, [rsp+0x10]
00007e4ecadd47ee  vmovaps xmm2, [rsp+0x20]
00007e4ecadd47f4  vmovaps xmm3, [rsp+0x30]
00007e4ecadd47fa  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4800  vmovaps xmm5, [rsp+0x50]
00007e4ecadd4806  vmovaps xmm6, [rsp+0x60]
00007e4ecadd480c  vmovaps xmm7, [rsp+0x70]
00007e4ecadd4812  vmovaps xmm8, [rsp+0x80]
00007e4ecadd481b  vmovaps xmm9, [rsp+0x90]
00007e4ecadd4824  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd482d  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd4836  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd483f  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd4848  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4851  add rsp, 0xF0
00007e4ecadd4858  pop r11
00007e4ecadd485a  pop r10
00007e4ecadd485c  pop r9
00007e4ecadd485e  pop r8
00007e4ecadd4860  pop rsi
00007e4ecadd4861  pop rdi
00007e4ecadd4862  pop rdx
00007e4ecadd4863  pop rcx
00007e4ecadd4864  pop rax
00007e4ecadd4865  add rsp, 0x08
00007e4ecadd4869  jmp 0x00007E4ECADD0169
00007e4ecadd486e  sub rsp, 0x08
00007e4ecadd4872  push rax
00007e4ecadd4873  push rcx
00007e4ecadd4874  push rdx
00007e4ecadd4875  push rdi
00007e4ecadd4876  push rsi
00007e4ecadd4877  push r8
00007e4ecadd4879  push r9
00007e4ecadd487b  push r10
00007e4ecadd487d  push r11
00007e4ecadd487f  sub rsp, 0xF0
00007e4ecadd4886  vmovaps [rsp], xmm0
00007e4ecadd488b  vmovaps [rsp+0x10], xmm1
00007e4ecadd4891  vmovaps [rsp+0x20], xmm2
00007e4ecadd4897  vmovaps [rsp+0x30], xmm3
00007e4ecadd489d  vmovaps [rsp+0x40], xmm4
00007e4ecadd48a3  vmovaps [rsp+0x50], xmm5
00007e4ecadd48a9  vmovaps [rsp+0x60], xmm6
00007e4ecadd48af  vmovaps [rsp+0x70], xmm7
00007e4ecadd48b5  vmovaps [rsp+0x80], xmm8
00007e4ecadd48be  vmovaps [rsp+0x90], xmm9
00007e4ecadd48c7  vmovaps [rsp+0xA0], xmm10
00007e4ecadd48d0  vmovaps [rsp+0xB0], xmm11
00007e4ecadd48d9  vmovaps [rsp+0xC0], xmm12
00007e4ecadd48e2  vmovaps [rsp+0xD0], xmm14
00007e4ecadd48eb  vmovaps [rsp+0xE0], xmm15
00007e4ecadd48f4  sub rsp, 0x30
00007e4ecadd48f8  movaps [rsp], xmm13
00007e4ecadd48fd  movaps [rsp+0x10], xmm1
00007e4ecadd4902  movaps [rsp+0x20], xmm8
00007e4ecadd4908  lea rdi, [rsp]
00007e4ecadd490c  mov esi, 0x00
00007e4ecadd4911  mov rax, 0x5784BC1F5530
00007e4ecadd491b  call rax
00007e4ecadd491d  movaps xmm13, [rsp]
00007e4ecadd4922  add rsp, 0x30
00007e4ecadd4926  vmovaps xmm0, [rsp]
00007e4ecadd492b  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4931  vmovaps xmm2, [rsp+0x20]
00007e4ecadd4937  vmovaps xmm3, [rsp+0x30]
00007e4ecadd493d  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4943  vmovaps xmm5, [rsp+0x50]
00007e4ecadd4949  vmovaps xmm6, [rsp+0x60]
00007e4ecadd494f  vmovaps xmm7, [rsp+0x70]
00007e4ecadd4955  vmovaps xmm8, [rsp+0x80]
00007e4ecadd495e  vmovaps xmm9, [rsp+0x90]
00007e4ecadd4967  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd4970  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd4979  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd4982  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd498b  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4994  add rsp, 0xF0
00007e4ecadd499b  pop r11
00007e4ecadd499d  pop r10
00007e4ecadd499f  pop r9
00007e4ecadd49a1  pop r8
00007e4ecadd49a3  pop rsi
00007e4ecadd49a4  pop rdi
00007e4ecadd49a5  pop rdx
00007e4ecadd49a6  pop rcx
00007e4ecadd49a7  pop rax
00007e4ecadd49a8  add rsp, 0x08
00007e4ecadd49ac  jmp 0x00007E4ECADD0183
00007e4ecadd49b1  call 0x00007E4ECABFF430
00007e4ecadd49b6  jmp 0x00007E4ECADD018D
00007e4ecadd49bb  sub rsp, 0x08
00007e4ecadd49bf  push rax
00007e4ecadd49c0  push rcx
00007e4ecadd49c1  push rdx
00007e4ecadd49c2  push rdi
00007e4ecadd49c3  push rsi
00007e4ecadd49c4  push r8
00007e4ecadd49c6  push r9
00007e4ecadd49c8  push r10
00007e4ecadd49ca  push r11
00007e4ecadd49cc  sub rsp, 0xF0
00007e4ecadd49d3  vmovaps [rsp], xmm0
00007e4ecadd49d8  vmovaps [rsp+0x10], xmm1
00007e4ecadd49de  vmovaps [rsp+0x20], xmm2
00007e4ecadd49e4  vmovaps [rsp+0x30], xmm3
00007e4ecadd49ea  vmovaps [rsp+0x40], xmm4
00007e4ecadd49f0  vmovaps [rsp+0x50], xmm5
00007e4ecadd49f6  vmovaps [rsp+0x60], xmm6
00007e4ecadd49fc  vmovaps [rsp+0x70], xmm7
00007e4ecadd4a02  vmovaps [rsp+0x80], xmm9
00007e4ecadd4a0b  vmovaps [rsp+0x90], xmm10
00007e4ecadd4a14  vmovaps [rsp+0xA0], xmm11
00007e4ecadd4a1d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd4a26  vmovaps [rsp+0xC0], xmm13
00007e4ecadd4a2f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd4a38  vmovaps [rsp+0xE0], xmm15
00007e4ecadd4a41  sub rsp, 0x30
00007e4ecadd4a45  movaps [rsp], xmm8
00007e4ecadd4a4a  movaps [rsp+0x10], xmm14
00007e4ecadd4a50  movaps [rsp+0x20], xmm9
00007e4ecadd4a56  lea rdi, [rsp]
00007e4ecadd4a5a  mov esi, 0x00
00007e4ecadd4a5f  mov rax, 0x5784BC1F5530
00007e4ecadd4a69  call rax
00007e4ecadd4a6b  movaps xmm8, [rsp]
00007e4ecadd4a70  add rsp, 0x30
00007e4ecadd4a74  vmovaps xmm0, [rsp]
00007e4ecadd4a79  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4a7f  vmovaps xmm2, [rsp+0x20]
00007e4ecadd4a85  vmovaps xmm3, [rsp+0x30]
00007e4ecadd4a8b  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4a91  vmovaps xmm5, [rsp+0x50]
00007e4ecadd4a97  vmovaps xmm6, [rsp+0x60]
00007e4ecadd4a9d  vmovaps xmm7, [rsp+0x70]
00007e4ecadd4aa3  vmovaps xmm9, [rsp+0x80]
00007e4ecadd4aac  vmovaps xmm10, [rsp+0x90]
00007e4ecadd4ab5  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd4abe  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd4ac7  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd4ad0  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd4ad9  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4ae2  add rsp, 0xF0
00007e4ecadd4ae9  pop r11
00007e4ecadd4aeb  pop r10
00007e4ecadd4aed  pop r9
00007e4ecadd4aef  pop r8
00007e4ecadd4af1  pop rsi
00007e4ecadd4af2  pop rdi
00007e4ecadd4af3  pop rdx
00007e4ecadd4af4  pop rcx
00007e4ecadd4af5  pop rax
00007e4ecadd4af6  add rsp, 0x08
00007e4ecadd4afa  jmp 0x00007E4ECADD01AF
00007e4ecadd4aff  sub rsp, 0x08
00007e4ecadd4b03  push rax
00007e4ecadd4b04  push rcx
00007e4ecadd4b05  push rdx
00007e4ecadd4b06  push rdi
00007e4ecadd4b07  push rsi
00007e4ecadd4b08  push r8
00007e4ecadd4b0a  push r9
00007e4ecadd4b0c  push r10
00007e4ecadd4b0e  push r11
00007e4ecadd4b10  sub rsp, 0xF0
00007e4ecadd4b17  vmovaps [rsp], xmm0
00007e4ecadd4b1c  vmovaps [rsp+0x10], xmm1
00007e4ecadd4b22  vmovaps [rsp+0x20], xmm2
00007e4ecadd4b28  vmovaps [rsp+0x30], xmm3
00007e4ecadd4b2e  vmovaps [rsp+0x40], xmm4
00007e4ecadd4b34  vmovaps [rsp+0x50], xmm5
00007e4ecadd4b3a  vmovaps [rsp+0x60], xmm6
00007e4ecadd4b40  vmovaps [rsp+0x70], xmm7
00007e4ecadd4b46  vmovaps [rsp+0x80], xmm8
00007e4ecadd4b4f  vmovaps [rsp+0x90], xmm10
00007e4ecadd4b58  vmovaps [rsp+0xA0], xmm11
00007e4ecadd4b61  vmovaps [rsp+0xB0], xmm12
00007e4ecadd4b6a  vmovaps [rsp+0xC0], xmm13
00007e4ecadd4b73  vmovaps [rsp+0xD0], xmm14
00007e4ecadd4b7c  vmovaps [rsp+0xE0], xmm15
00007e4ecadd4b85  sub rsp, 0x30
00007e4ecadd4b89  movaps [rsp], xmm9
00007e4ecadd4b8e  movaps [rsp+0x10], xmm1
00007e4ecadd4b93  movaps [rsp+0x20], xmm14
00007e4ecadd4b99  lea rdi, [rsp]
00007e4ecadd4b9d  mov esi, 0x00
00007e4ecadd4ba2  mov rax, 0x5784BC1F5530
00007e4ecadd4bac  call rax
00007e4ecadd4bae  movaps xmm9, [rsp]
00007e4ecadd4bb3  add rsp, 0x30
00007e4ecadd4bb7  vmovaps xmm0, [rsp]
00007e4ecadd4bbc  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4bc2  vmovaps xmm2, [rsp+0x20]
00007e4ecadd4bc8  vmovaps xmm3, [rsp+0x30]
00007e4ecadd4bce  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4bd4  vmovaps xmm5, [rsp+0x50]
00007e4ecadd4bda  vmovaps xmm6, [rsp+0x60]
00007e4ecadd4be0  vmovaps xmm7, [rsp+0x70]
00007e4ecadd4be6  vmovaps xmm8, [rsp+0x80]
00007e4ecadd4bef  vmovaps xmm10, [rsp+0x90]
00007e4ecadd4bf8  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd4c01  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd4c0a  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd4c13  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd4c1c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4c25  add rsp, 0xF0
00007e4ecadd4c2c  pop r11
00007e4ecadd4c2e  pop r10
00007e4ecadd4c30  pop r9
00007e4ecadd4c32  pop r8
00007e4ecadd4c34  pop rsi
00007e4ecadd4c35  pop rdi
00007e4ecadd4c36  pop rdx
00007e4ecadd4c37  pop rcx
00007e4ecadd4c38  pop rax
00007e4ecadd4c39  add rsp, 0x08
00007e4ecadd4c3d  jmp 0x00007E4ECADD01DD
00007e4ecadd4c42  sub rsp, 0x08
00007e4ecadd4c46  push rax
00007e4ecadd4c47  push rcx
00007e4ecadd4c48  push rdx
00007e4ecadd4c49  push rdi
00007e4ecadd4c4a  push rsi
00007e4ecadd4c4b  push r8
00007e4ecadd4c4d  push r9
00007e4ecadd4c4f  push r10
00007e4ecadd4c51  push r11
00007e4ecadd4c53  sub rsp, 0xF0
00007e4ecadd4c5a  vmovaps [rsp], xmm0
00007e4ecadd4c5f  vmovaps [rsp+0x10], xmm1
00007e4ecadd4c65  vmovaps [rsp+0x20], xmm2
00007e4ecadd4c6b  vmovaps [rsp+0x30], xmm3
00007e4ecadd4c71  vmovaps [rsp+0x40], xmm4
00007e4ecadd4c77  vmovaps [rsp+0x50], xmm5
00007e4ecadd4c7d  vmovaps [rsp+0x60], xmm6
00007e4ecadd4c83  vmovaps [rsp+0x70], xmm7
00007e4ecadd4c89  vmovaps [rsp+0x80], xmm8
00007e4ecadd4c92  vmovaps [rsp+0x90], xmm9
00007e4ecadd4c9b  vmovaps [rsp+0xA0], xmm10
00007e4ecadd4ca4  vmovaps [rsp+0xB0], xmm11
00007e4ecadd4cad  vmovaps [rsp+0xC0], xmm12
00007e4ecadd4cb6  vmovaps [rsp+0xD0], xmm13
00007e4ecadd4cbf  vmovaps [rsp+0xE0], xmm15
00007e4ecadd4cc8  sub rsp, 0x30
00007e4ecadd4ccc  movaps [rsp], xmm14
00007e4ecadd4cd1  movaps [rsp+0x10], xmm4
00007e4ecadd4cd6  movaps [rsp+0x20], xmm1
00007e4ecadd4cdb  lea rdi, [rsp]
00007e4ecadd4cdf  mov esi, 0x00
00007e4ecadd4ce4  mov rax, 0x5784BC1F5530
00007e4ecadd4cee  call rax
00007e4ecadd4cf0  movaps xmm14, [rsp]
00007e4ecadd4cf5  add rsp, 0x30
00007e4ecadd4cf9  vmovaps xmm0, [rsp]
00007e4ecadd4cfe  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4d04  vmovaps xmm2, [rsp+0x20]
00007e4ecadd4d0a  vmovaps xmm3, [rsp+0x30]
00007e4ecadd4d10  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4d16  vmovaps xmm5, [rsp+0x50]
00007e4ecadd4d1c  vmovaps xmm6, [rsp+0x60]
00007e4ecadd4d22  vmovaps xmm7, [rsp+0x70]
00007e4ecadd4d28  vmovaps xmm8, [rsp+0x80]
00007e4ecadd4d31  vmovaps xmm9, [rsp+0x90]
00007e4ecadd4d3a  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd4d43  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd4d4c  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd4d55  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd4d5e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4d67  add rsp, 0xF0
00007e4ecadd4d6e  pop r11
00007e4ecadd4d70  pop r10
00007e4ecadd4d72  pop r9
00007e4ecadd4d74  pop r8
00007e4ecadd4d76  pop rsi
00007e4ecadd4d77  pop rdi
00007e4ecadd4d78  pop rdx
00007e4ecadd4d79  pop rcx
00007e4ecadd4d7a  pop rax
00007e4ecadd4d7b  add rsp, 0x08
00007e4ecadd4d7f  jmp 0x00007E4ECADD0203
00007e4ecadd4d84  sub rsp, 0x08
00007e4ecadd4d88  push rax
00007e4ecadd4d89  push rcx
00007e4ecadd4d8a  push rdx
00007e4ecadd4d8b  push rdi
00007e4ecadd4d8c  push rsi
00007e4ecadd4d8d  push r8
00007e4ecadd4d8f  push r9
00007e4ecadd4d91  push r10
00007e4ecadd4d93  push r11
00007e4ecadd4d95  sub rsp, 0xF0
00007e4ecadd4d9c  vmovaps [rsp], xmm0
00007e4ecadd4da1  vmovaps [rsp+0x10], xmm2
00007e4ecadd4da7  vmovaps [rsp+0x20], xmm3
00007e4ecadd4dad  vmovaps [rsp+0x30], xmm4
00007e4ecadd4db3  vmovaps [rsp+0x40], xmm5
00007e4ecadd4db9  vmovaps [rsp+0x50], xmm6
00007e4ecadd4dbf  vmovaps [rsp+0x60], xmm7
00007e4ecadd4dc5  vmovaps [rsp+0x70], xmm8
00007e4ecadd4dcb  vmovaps [rsp+0x80], xmm9
00007e4ecadd4dd4  vmovaps [rsp+0x90], xmm10
00007e4ecadd4ddd  vmovaps [rsp+0xA0], xmm11
00007e4ecadd4de6  vmovaps [rsp+0xB0], xmm12
00007e4ecadd4def  vmovaps [rsp+0xC0], xmm13
00007e4ecadd4df8  vmovaps [rsp+0xD0], xmm14
00007e4ecadd4e01  vmovaps [rsp+0xE0], xmm15
00007e4ecadd4e0a  sub rsp, 0x30
00007e4ecadd4e0e  movaps [rsp], xmm1
00007e4ecadd4e12  movaps [rsp+0x10], xmm12
00007e4ecadd4e18  movaps [rsp+0x20], xmm11
00007e4ecadd4e1e  lea rdi, [rsp]
00007e4ecadd4e22  mov esi, 0x00
00007e4ecadd4e27  mov rax, 0x5784BC1F5530
00007e4ecadd4e31  call rax
00007e4ecadd4e33  movaps xmm1, [rsp]
00007e4ecadd4e37  add rsp, 0x30
00007e4ecadd4e3b  vmovaps xmm0, [rsp]
00007e4ecadd4e40  vmovaps xmm2, [rsp+0x10]
00007e4ecadd4e46  vmovaps xmm3, [rsp+0x20]
00007e4ecadd4e4c  vmovaps xmm4, [rsp+0x30]
00007e4ecadd4e52  vmovaps xmm5, [rsp+0x40]
00007e4ecadd4e58  vmovaps xmm6, [rsp+0x50]
00007e4ecadd4e5e  vmovaps xmm7, [rsp+0x60]
00007e4ecadd4e64  vmovaps xmm8, [rsp+0x70]
00007e4ecadd4e6a  vmovaps xmm9, [rsp+0x80]
00007e4ecadd4e73  vmovaps xmm10, [rsp+0x90]
00007e4ecadd4e7c  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd4e85  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd4e8e  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd4e97  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd4ea0  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4ea9  add rsp, 0xF0
00007e4ecadd4eb0  pop r11
00007e4ecadd4eb2  pop r10
00007e4ecadd4eb4  pop r9
00007e4ecadd4eb6  pop r8
00007e4ecadd4eb8  pop rsi
00007e4ecadd4eb9  pop rdi
00007e4ecadd4eba  pop rdx
00007e4ecadd4ebb  pop rcx
00007e4ecadd4ebc  pop rax
00007e4ecadd4ebd  add rsp, 0x08
00007e4ecadd4ec1  jmp 0x00007E4ECADD0224
00007e4ecadd4ec6  call 0x00007E4ECACE20A0
00007e4ecadd4ecb  jmp 0x00007E4ECADD0232
00007e4ecadd4ed0  call 0x00007E4ECAC09D70
00007e4ecadd4ed5  jmp 0x00007E4ECADD023C
00007e4ecadd4eda  sub rsp, 0x08
00007e4ecadd4ede  push rax
00007e4ecadd4edf  push rcx
00007e4ecadd4ee0  push rdx
00007e4ecadd4ee1  push rdi
00007e4ecadd4ee2  push rsi
00007e4ecadd4ee3  push r8
00007e4ecadd4ee5  push r9
00007e4ecadd4ee7  push r10
00007e4ecadd4ee9  push r11
00007e4ecadd4eeb  sub rsp, 0xF0
00007e4ecadd4ef2  vmovaps [rsp], xmm0
00007e4ecadd4ef7  vmovaps [rsp+0x10], xmm1
00007e4ecadd4efd  vmovaps [rsp+0x20], xmm2
00007e4ecadd4f03  vmovaps [rsp+0x30], xmm3
00007e4ecadd4f09  vmovaps [rsp+0x40], xmm4
00007e4ecadd4f0f  vmovaps [rsp+0x50], xmm5
00007e4ecadd4f15  vmovaps [rsp+0x60], xmm6
00007e4ecadd4f1b  vmovaps [rsp+0x70], xmm8
00007e4ecadd4f21  vmovaps [rsp+0x80], xmm9
00007e4ecadd4f2a  vmovaps [rsp+0x90], xmm10
00007e4ecadd4f33  vmovaps [rsp+0xA0], xmm11
00007e4ecadd4f3c  vmovaps [rsp+0xB0], xmm12
00007e4ecadd4f45  vmovaps [rsp+0xC0], xmm13
00007e4ecadd4f4e  vmovaps [rsp+0xD0], xmm14
00007e4ecadd4f57  vmovaps [rsp+0xE0], xmm15
00007e4ecadd4f60  sub rsp, 0x30
00007e4ecadd4f64  movaps [rsp], xmm7
00007e4ecadd4f68  movaps [rsp+0x10], xmm15
00007e4ecadd4f6e  movaps [rsp+0x20], xmm10
00007e4ecadd4f74  lea rdi, [rsp]
00007e4ecadd4f78  mov esi, 0x00
00007e4ecadd4f7d  mov rax, 0x5784BC1F5530
00007e4ecadd4f87  call rax
00007e4ecadd4f89  movaps xmm7, [rsp]
00007e4ecadd4f8d  add rsp, 0x30
00007e4ecadd4f91  vmovaps xmm0, [rsp]
00007e4ecadd4f96  vmovaps xmm1, [rsp+0x10]
00007e4ecadd4f9c  vmovaps xmm2, [rsp+0x20]
00007e4ecadd4fa2  vmovaps xmm3, [rsp+0x30]
00007e4ecadd4fa8  vmovaps xmm4, [rsp+0x40]
00007e4ecadd4fae  vmovaps xmm5, [rsp+0x50]
00007e4ecadd4fb4  vmovaps xmm6, [rsp+0x60]
00007e4ecadd4fba  vmovaps xmm8, [rsp+0x70]
00007e4ecadd4fc0  vmovaps xmm9, [rsp+0x80]
00007e4ecadd4fc9  vmovaps xmm10, [rsp+0x90]
00007e4ecadd4fd2  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd4fdb  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd4fe4  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd4fed  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd4ff6  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd4fff  add rsp, 0xF0
00007e4ecadd5006  pop r11
00007e4ecadd5008  pop r10
00007e4ecadd500a  pop r9
00007e4ecadd500c  pop r8
00007e4ecadd500e  pop rsi
00007e4ecadd500f  pop rdi
00007e4ecadd5010  pop rdx
00007e4ecadd5011  pop rcx
00007e4ecadd5012  pop rax
00007e4ecadd5013  add rsp, 0x08
00007e4ecadd5017  jmp 0x00007E4ECADD025D
00007e4ecadd501c  sub rsp, 0x08
00007e4ecadd5020  push rax
00007e4ecadd5021  push rcx
00007e4ecadd5022  push rdx
00007e4ecadd5023  push rdi
00007e4ecadd5024  push rsi
00007e4ecadd5025  push r8
00007e4ecadd5027  push r9
00007e4ecadd5029  push r10
00007e4ecadd502b  push r11
00007e4ecadd502d  sub rsp, 0xF0
00007e4ecadd5034  vmovaps [rsp], xmm0
00007e4ecadd5039  vmovaps [rsp+0x10], xmm1
00007e4ecadd503f  vmovaps [rsp+0x20], xmm2
00007e4ecadd5045  vmovaps [rsp+0x30], xmm3
00007e4ecadd504b  vmovaps [rsp+0x40], xmm4
00007e4ecadd5051  vmovaps [rsp+0x50], xmm5
00007e4ecadd5057  vmovaps [rsp+0x60], xmm6
00007e4ecadd505d  vmovaps [rsp+0x70], xmm7
00007e4ecadd5063  vmovaps [rsp+0x80], xmm8
00007e4ecadd506c  vmovaps [rsp+0x90], xmm9
00007e4ecadd5075  vmovaps [rsp+0xA0], xmm11
00007e4ecadd507e  vmovaps [rsp+0xB0], xmm12
00007e4ecadd5087  vmovaps [rsp+0xC0], xmm13
00007e4ecadd5090  vmovaps [rsp+0xD0], xmm14
00007e4ecadd5099  vmovaps [rsp+0xE0], xmm15
00007e4ecadd50a2  sub rsp, 0x30
00007e4ecadd50a6  movaps [rsp], xmm10
00007e4ecadd50ab  movaps [rsp+0x10], xmm11
00007e4ecadd50b1  movaps [rsp+0x20], xmm15
00007e4ecadd50b7  lea rdi, [rsp]
00007e4ecadd50bb  mov esi, 0x00
00007e4ecadd50c0  mov rax, 0x5784BC1F5530
00007e4ecadd50ca  call rax
00007e4ecadd50cc  movaps xmm10, [rsp]
00007e4ecadd50d1  add rsp, 0x30
00007e4ecadd50d5  vmovaps xmm0, [rsp]
00007e4ecadd50da  vmovaps xmm1, [rsp+0x10]
00007e4ecadd50e0  vmovaps xmm2, [rsp+0x20]
00007e4ecadd50e6  vmovaps xmm3, [rsp+0x30]
00007e4ecadd50ec  vmovaps xmm4, [rsp+0x40]
00007e4ecadd50f2  vmovaps xmm5, [rsp+0x50]
00007e4ecadd50f8  vmovaps xmm6, [rsp+0x60]
00007e4ecadd50fe  vmovaps xmm7, [rsp+0x70]
00007e4ecadd5104  vmovaps xmm8, [rsp+0x80]
00007e4ecadd510d  vmovaps xmm9, [rsp+0x90]
00007e4ecadd5116  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd511f  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd5128  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd5131  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd513a  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd5143  add rsp, 0xF0
00007e4ecadd514a  pop r11
00007e4ecadd514c  pop r10
00007e4ecadd514e  pop r9
00007e4ecadd5150  pop r8
00007e4ecadd5152  pop rsi
00007e4ecadd5153  pop rdi
00007e4ecadd5154  pop rdx
00007e4ecadd5155  pop rcx
00007e4ecadd5156  pop rax
00007e4ecadd5157  add rsp, 0x08
00007e4ecadd515b  jmp 0x00007E4ECADD028B
00007e4ecadd5160  sub rsp, 0x08
00007e4ecadd5164  push rax
00007e4ecadd5165  push rcx
00007e4ecadd5166  push rdx
00007e4ecadd5167  push rdi
00007e4ecadd5168  push rsi
00007e4ecadd5169  push r8
00007e4ecadd516b  push r9
00007e4ecadd516d  push r10
00007e4ecadd516f  push r11
00007e4ecadd5171  sub rsp, 0xF0
00007e4ecadd5178  vmovaps [rsp], xmm0
00007e4ecadd517d  vmovaps [rsp+0x10], xmm1
00007e4ecadd5183  vmovaps [rsp+0x20], xmm2
00007e4ecadd5189  vmovaps [rsp+0x30], xmm3
00007e4ecadd518f  vmovaps [rsp+0x40], xmm4
00007e4ecadd5195  vmovaps [rsp+0x50], xmm5
00007e4ecadd519b  vmovaps [rsp+0x60], xmm6
00007e4ecadd51a1  vmovaps [rsp+0x70], xmm7
00007e4ecadd51a7  vmovaps [rsp+0x80], xmm8
00007e4ecadd51b0  vmovaps [rsp+0x90], xmm9
00007e4ecadd51b9  vmovaps [rsp+0xA0], xmm10
00007e4ecadd51c2  vmovaps [rsp+0xB0], xmm12
00007e4ecadd51cb  vmovaps [rsp+0xC0], xmm13
00007e4ecadd51d4  vmovaps [rsp+0xD0], xmm14
00007e4ecadd51dd  vmovaps [rsp+0xE0], xmm15
00007e4ecadd51e6  sub rsp, 0x30
00007e4ecadd51ea  movaps [rsp], xmm11
00007e4ecadd51ef  movaps [rsp+0x10], xmm12
00007e4ecadd51f5  movaps [rsp+0x20], xmm15
00007e4ecadd51fb  lea rdi, [rsp]
00007e4ecadd51ff  mov esi, 0x00
00007e4ecadd5204  mov rax, 0x5784BC1F5530
00007e4ecadd520e  call rax
00007e4ecadd5210  movaps xmm11, [rsp]
00007e4ecadd5215  add rsp, 0x30
00007e4ecadd5219  vmovaps xmm0, [rsp]
00007e4ecadd521e  vmovaps xmm1, [rsp+0x10]
00007e4ecadd5224  vmovaps xmm2, [rsp+0x20]
00007e4ecadd522a  vmovaps xmm3, [rsp+0x30]
00007e4ecadd5230  vmovaps xmm4, [rsp+0x40]
00007e4ecadd5236  vmovaps xmm5, [rsp+0x50]
00007e4ecadd523c  vmovaps xmm6, [rsp+0x60]
00007e4ecadd5242  vmovaps xmm7, [rsp+0x70]
00007e4ecadd5248  vmovaps xmm8, [rsp+0x80]
00007e4ecadd5251  vmovaps xmm9, [rsp+0x90]
00007e4ecadd525a  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd5263  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd526c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd5275  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd527e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd5287  add rsp, 0xF0
00007e4ecadd528e  pop r11
00007e4ecadd5290  pop r10
00007e4ecadd5292  pop r9
00007e4ecadd5294  pop r8
00007e4ecadd5296  pop rsi
00007e4ecadd5297  pop rdi
00007e4ecadd5298  pop rdx
00007e4ecadd5299  pop rcx
00007e4ecadd529a  pop rax
00007e4ecadd529b  add rsp, 0x08
00007e4ecadd529f  jmp 0x00007E4ECADD02B9
00007e4ecadd52a4  sub rsp, 0x08
00007e4ecadd52a8  push rax
00007e4ecadd52a9  push rcx
00007e4ecadd52aa  push rdx
00007e4ecadd52ab  push rdi
00007e4ecadd52ac  push rsi
00007e4ecadd52ad  push r8
00007e4ecadd52af  push r9
00007e4ecadd52b1  push r10
00007e4ecadd52b3  push r11
00007e4ecadd52b5  sub rsp, 0xF0
00007e4ecadd52bc  vmovaps [rsp], xmm0
00007e4ecadd52c1  vmovaps [rsp+0x10], xmm1
00007e4ecadd52c7  vmovaps [rsp+0x20], xmm2
00007e4ecadd52cd  vmovaps [rsp+0x30], xmm3
00007e4ecadd52d3  vmovaps [rsp+0x40], xmm4
00007e4ecadd52d9  vmovaps [rsp+0x50], xmm5
00007e4ecadd52df  vmovaps [rsp+0x60], xmm6
00007e4ecadd52e5  vmovaps [rsp+0x70], xmm7
00007e4ecadd52eb  vmovaps [rsp+0x80], xmm8
00007e4ecadd52f4  vmovaps [rsp+0x90], xmm9
00007e4ecadd52fd  vmovaps [rsp+0xA0], xmm10
00007e4ecadd5306  vmovaps [rsp+0xB0], xmm11
00007e4ecadd530f  vmovaps [rsp+0xC0], xmm12
00007e4ecadd5318  vmovaps [rsp+0xD0], xmm13
00007e4ecadd5321  vmovaps [rsp+0xE0], xmm14
00007e4ecadd532a  sub rsp, 0x30
00007e4ecadd532e  movaps [rsp], xmm15
00007e4ecadd5333  movaps [rsp+0x10], xmm13
00007e4ecadd5339  movaps [rsp+0x20], xmm9
00007e4ecadd533f  lea rdi, [rsp]
00007e4ecadd5343  mov esi, 0x00
00007e4ecadd5348  mov rax, 0x5784BC1F5530
00007e4ecadd5352  call rax
00007e4ecadd5354  movaps xmm15, [rsp]
00007e4ecadd5359  add rsp, 0x30
00007e4ecadd535d  vmovaps xmm0, [rsp]
00007e4ecadd5362  vmovaps xmm1, [rsp+0x10]
00007e4ecadd5368  vmovaps xmm2, [rsp+0x20]
00007e4ecadd536e  vmovaps xmm3, [rsp+0x30]
00007e4ecadd5374  vmovaps xmm4, [rsp+0x40]
00007e4ecadd537a  vmovaps xmm5, [rsp+0x50]
00007e4ecadd5380  vmovaps xmm6, [rsp+0x60]
00007e4ecadd5386  vmovaps xmm7, [rsp+0x70]
00007e4ecadd538c  vmovaps xmm8, [rsp+0x80]
00007e4ecadd5395  vmovaps xmm9, [rsp+0x90]
00007e4ecadd539e  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd53a7  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd53b0  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd53b9  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd53c2  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd53cb  add rsp, 0xF0
00007e4ecadd53d2  pop r11
00007e4ecadd53d4  pop r10
00007e4ecadd53d6  pop r9
00007e4ecadd53d8  pop r8
00007e4ecadd53da  pop rsi
00007e4ecadd53db  pop rdi
00007e4ecadd53dc  pop rdx
00007e4ecadd53dd  pop rcx
00007e4ecadd53de  pop rax
00007e4ecadd53df  add rsp, 0x08
00007e4ecadd53e3  jmp 0x00007E4ECADD02D4
00007e4ecadd53e8  sub rsp, 0x08
00007e4ecadd53ec  push rax
00007e4ecadd53ed  push rcx
00007e4ecadd53ee  push rdx
00007e4ecadd53ef  push rdi
00007e4ecadd53f0  push rsi
00007e4ecadd53f1  push r8
00007e4ecadd53f3  push r9
00007e4ecadd53f5  push r10
00007e4ecadd53f7  push r11
00007e4ecadd53f9  sub rsp, 0xF0
00007e4ecadd5400  vmovaps [rsp], xmm0
00007e4ecadd5405  vmovaps [rsp+0x10], xmm1
00007e4ecadd540b  vmovaps [rsp+0x20], xmm2
00007e4ecadd5411  vmovaps [rsp+0x30], xmm3
00007e4ecadd5417  vmovaps [rsp+0x40], xmm4
00007e4ecadd541d  vmovaps [rsp+0x50], xmm5
00007e4ecadd5423  vmovaps [rsp+0x60], xmm6
00007e4ecadd5429  vmovaps [rsp+0x70], xmm7
00007e4ecadd542f  vmovaps [rsp+0x80], xmm8
00007e4ecadd5438  vmovaps [rsp+0x90], xmm9
00007e4ecadd5441  vmovaps [rsp+0xA0], xmm10
00007e4ecadd544a  vmovaps [rsp+0xB0], xmm11
00007e4ecadd5453  vmovaps [rsp+0xC0], xmm12
00007e4ecadd545c  vmovaps [rsp+0xD0], xmm14
00007e4ecadd5465  vmovaps [rsp+0xE0], xmm15
00007e4ecadd546e  sub rsp, 0x30
00007e4ecadd5472  movaps [rsp], xmm13
00007e4ecadd5477  movaps [rsp+0x10], xmm8
00007e4ecadd547d  movaps [rsp+0x20], xmm14
00007e4ecadd5483  lea rdi, [rsp]
00007e4ecadd5487  mov esi, 0x00
00007e4ecadd548c  mov rax, 0x5784BC1F5530
00007e4ecadd5496  call rax
00007e4ecadd5498  movaps xmm13, [rsp]
00007e4ecadd549d  add rsp, 0x30
00007e4ecadd54a1  vmovaps xmm0, [rsp]
00007e4ecadd54a6  vmovaps xmm1, [rsp+0x10]
00007e4ecadd54ac  vmovaps xmm2, [rsp+0x20]
00007e4ecadd54b2  vmovaps xmm3, [rsp+0x30]
00007e4ecadd54b8  vmovaps xmm4, [rsp+0x40]
00007e4ecadd54be  vmovaps xmm5, [rsp+0x50]
00007e4ecadd54c4  vmovaps xmm6, [rsp+0x60]
00007e4ecadd54ca  vmovaps xmm7, [rsp+0x70]
00007e4ecadd54d0  vmovaps xmm8, [rsp+0x80]
00007e4ecadd54d9  vmovaps xmm9, [rsp+0x90]
00007e4ecadd54e2  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd54eb  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd54f4  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd54fd  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd5506  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd550f  add rsp, 0xF0
00007e4ecadd5516  pop r11
00007e4ecadd5518  pop r10
00007e4ecadd551a  pop r9
00007e4ecadd551c  pop r8
00007e4ecadd551e  pop rsi
00007e4ecadd551f  pop rdi
00007e4ecadd5520  pop rdx
00007e4ecadd5521  pop rcx
00007e4ecadd5522  pop rax
00007e4ecadd5523  add rsp, 0x08
00007e4ecadd5527  jmp 0x00007E4ECADD02F7
00007e4ecadd552c  sub rsp, 0x08
00007e4ecadd5530  push rax
00007e4ecadd5531  push rcx
00007e4ecadd5532  push rdx
00007e4ecadd5533  push rdi
00007e4ecadd5534  push rsi
00007e4ecadd5535  push r8
00007e4ecadd5537  push r9
00007e4ecadd5539  push r10
00007e4ecadd553b  push r11
00007e4ecadd553d  sub rsp, 0xF0
00007e4ecadd5544  vmovaps [rsp], xmm0
00007e4ecadd5549  vmovaps [rsp+0x10], xmm1
00007e4ecadd554f  vmovaps [rsp+0x20], xmm2
00007e4ecadd5555  vmovaps [rsp+0x30], xmm3
00007e4ecadd555b  vmovaps [rsp+0x40], xmm4
00007e4ecadd5561  vmovaps [rsp+0x50], xmm5
00007e4ecadd5567  vmovaps [rsp+0x60], xmm6
00007e4ecadd556d  vmovaps [rsp+0x70], xmm7
00007e4ecadd5573  vmovaps [rsp+0x80], xmm8
00007e4ecadd557c  vmovaps [rsp+0x90], xmm9
00007e4ecadd5585  vmovaps [rsp+0xA0], xmm10
00007e4ecadd558e  vmovaps [rsp+0xB0], xmm11
00007e4ecadd5597  vmovaps [rsp+0xC0], xmm12
00007e4ecadd55a0  vmovaps [rsp+0xD0], xmm13
00007e4ecadd55a9  vmovaps [rsp+0xE0], xmm15
00007e4ecadd55b2  sub rsp, 0x30
00007e4ecadd55b6  movaps [rsp], xmm14
00007e4ecadd55bb  movaps [rsp+0x10], xmm1
00007e4ecadd55c0  movaps [rsp+0x20], xmm10
00007e4ecadd55c6  lea rdi, [rsp]
00007e4ecadd55ca  mov esi, 0x00
00007e4ecadd55cf  mov rax, 0x5784BC1F5530
00007e4ecadd55d9  call rax
00007e4ecadd55db  movaps xmm14, [rsp]
00007e4ecadd55e0  add rsp, 0x30
00007e4ecadd55e4  vmovaps xmm0, [rsp]
00007e4ecadd55e9  vmovaps xmm1, [rsp+0x10]
00007e4ecadd55ef  vmovaps xmm2, [rsp+0x20]
00007e4ecadd55f5  vmovaps xmm3, [rsp+0x30]
00007e4ecadd55fb  vmovaps xmm4, [rsp+0x40]
00007e4ecadd5601  vmovaps xmm5, [rsp+0x50]
00007e4ecadd5607  vmovaps xmm6, [rsp+0x60]
00007e4ecadd560d  vmovaps xmm7, [rsp+0x70]
00007e4ecadd5613  vmovaps xmm8, [rsp+0x80]
00007e4ecadd561c  vmovaps xmm9, [rsp+0x90]
00007e4ecadd5625  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd562e  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd5637  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd5640  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd5649  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd5652  add rsp, 0xF0
00007e4ecadd5659  pop r11
00007e4ecadd565b  pop r10
00007e4ecadd565d  pop r9
00007e4ecadd565f  pop r8
00007e4ecadd5661  pop rsi
00007e4ecadd5662  pop rdi
00007e4ecadd5663  pop rdx
00007e4ecadd5664  pop rcx
00007e4ecadd5665  pop rax
00007e4ecadd5666  add rsp, 0x08
00007e4ecadd566a  jmp 0x00007E4ECADD031A
00007e4ecadd566f  sub rsp, 0x08
00007e4ecadd5673  push rax
00007e4ecadd5674  push rcx
00007e4ecadd5675  push rdx
00007e4ecadd5676  push rdi
00007e4ecadd5677  push rsi
00007e4ecadd5678  push r8
00007e4ecadd567a  push r9
00007e4ecadd567c  push r10
00007e4ecadd567e  push r11
00007e4ecadd5680  sub rsp, 0xF0
00007e4ecadd5687  vmovaps [rsp], xmm0
00007e4ecadd568c  vmovaps [rsp+0x10], xmm2
00007e4ecadd5692  vmovaps [rsp+0x20], xmm3
00007e4ecadd5698  vmovaps [rsp+0x30], xmm4
00007e4ecadd569e  vmovaps [rsp+0x40], xmm5
00007e4ecadd56a4  vmovaps [rsp+0x50], xmm6
00007e4ecadd56aa  vmovaps [rsp+0x60], xmm7
00007e4ecadd56b0  vmovaps [rsp+0x70], xmm8
00007e4ecadd56b6  vmovaps [rsp+0x80], xmm9
00007e4ecadd56bf  vmovaps [rsp+0x90], xmm10
00007e4ecadd56c8  vmovaps [rsp+0xA0], xmm11
00007e4ecadd56d1  vmovaps [rsp+0xB0], xmm12
00007e4ecadd56da  vmovaps [rsp+0xC0], xmm13
00007e4ecadd56e3  vmovaps [rsp+0xD0], xmm14
00007e4ecadd56ec  vmovaps [rsp+0xE0], xmm15
00007e4ecadd56f5  sub rsp, 0x30
00007e4ecadd56f9  movaps [rsp], xmm1
00007e4ecadd56fd  movaps [rsp+0x10], xmm7
00007e4ecadd5702  movaps [rsp+0x20], xmm11
00007e4ecadd5708  lea rdi, [rsp]
00007e4ecadd570c  mov esi, 0x00
00007e4ecadd5711  mov rax, 0x5784BC1F5530
00007e4ecadd571b  call rax
00007e4ecadd571d  movaps xmm1, [rsp]
00007e4ecadd5721  add rsp, 0x30
00007e4ecadd5725  vmovaps xmm0, [rsp]
00007e4ecadd572a  vmovaps xmm2, [rsp+0x10]
00007e4ecadd5730  vmovaps xmm3, [rsp+0x20]
00007e4ecadd5736  vmovaps xmm4, [rsp+0x30]
00007e4ecadd573c  vmovaps xmm5, [rsp+0x40]
00007e4ecadd5742  vmovaps xmm6, [rsp+0x50]
00007e4ecadd5748  vmovaps xmm7, [rsp+0x60]
00007e4ecadd574e  vmovaps xmm8, [rsp+0x70]
00007e4ecadd5754  vmovaps xmm9, [rsp+0x80]
00007e4ecadd575d  vmovaps xmm10, [rsp+0x90]
00007e4ecadd5766  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd576f  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd5778  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd5781  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd578a  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd5793  add rsp, 0xF0
00007e4ecadd579a  pop r11
00007e4ecadd579c  pop r10
00007e4ecadd579e  pop r9
00007e4ecadd57a0  pop r8
00007e4ecadd57a2  pop rsi
00007e4ecadd57a3  pop rdi
00007e4ecadd57a4  pop rdx
00007e4ecadd57a5  pop rcx
00007e4ecadd57a6  pop rax
00007e4ecadd57a7  add rsp, 0x08
00007e4ecadd57ab  jmp 0x00007E4ECADD033B
00007e4ecadd57b0  call 0x00007E4ECAC0E880
00007e4ecadd57b5  jmp 0x00007E4ECADD034E
00007e4ecadd57ba  call 0x00007E4ECAC0C380
00007e4ecadd57bf  jmp 0x00007E4ECADD0359
00007e4ecadd57c4  call 0x00007E4ECAC0D600
00007e4ecadd57c9  jmp 0x00007E4ECADD0364
00007e4ecadd57ce  call 0x00007E4ECABFF540
00007e4ecadd57d3  jmp 0x00007E4ECADD036F
00007e4ecadd57d8  int3
00007e4ecadd57d9  nop [rax], eax
00007e4ecadd57e0  mov rax, [r15+0x40]
00007e4ecadd57e4  mov r14, [r15+0x58]
00007e4ecadd57e8  lea r12, [rax+r14*1]
00007e4ecadd57ec  movaps xmm1, [r15+0x1D0]
00007e4ecadd57f4  vmovaps [rsp+0x10], xmm1
00007e4ecadd57fa  vmovaps xmm15, [rsp+0x10]
00007e4ecadd5800  por xmm1, xmm15
00007e4ecadd5805  movaps xmm14, [r15+0x1A0]
00007e4ecadd580d  vmovaps [rsp+0x10], xmm14
00007e4ecadd5813  vmovaps xmm13, [rsp+0x10]
00007e4ecadd5819  por xmm14, xmm13
00007e4ecadd581e  lea rax, [r12+0x30]
00007e4ecadd5823  mov r11, [r13+rax*1]
00007e4ecadd5828  lea rax, [r12+0x38]
00007e4ecadd582d  mov r10, [r13+rax*1]
00007e4ecadd5832  movq xmm13, r11
00007e4ecadd5837  movq xmm12, r10
00007e4ecadd583c  movq xmm13, xmm13
00007e4ecadd5841  vmovaps [rsp+0x10], xmm13
00007e4ecadd5847  movq xmm13, xmm13
00007e4ecadd584c  movaps [r15+0x130], xmm13
00007e4ecadd5854  movq xmm12, xmm12
00007e4ecadd5859  vmovaps [rsp+0x20], xmm12
00007e4ecadd585f  movq xmm12, xmm12
00007e4ecadd5864  movaps [r15+0x280], xmm12
00007e4ecadd586c  movaps xmm13, [r15+0x270]
00007e4ecadd5874  vmovaps [rsp+0x30], xmm13
00007e4ecadd587a  vmovaps xmm12, [rsp+0x30]
00007e4ecadd5880  por xmm13, xmm12
00007e4ecadd5885  lea rax, [r12+0x20]
00007e4ecadd588a  mov r11, [r13+rax*1]
00007e4ecadd588f  lea rax, [r12+0x28]
00007e4ecadd5894  mov r10, [r13+rax*1]
00007e4ecadd5899  movq xmm12, r11
00007e4ecadd589e  movq xmm11, r10
00007e4ecadd58a3  movq xmm12, xmm12
00007e4ecadd58a8  vmovaps [rsp+0x30], xmm12
00007e4ecadd58ae  movq xmm12, xmm12
00007e4ecadd58b3  movaps [r15+0x150], xmm12
00007e4ecadd58bb  movq xmm11, xmm11
00007e4ecadd58c0  vmovaps [rsp+0x40], xmm11
00007e4ecadd58c6  movq xmm11, xmm11
00007e4ecadd58cb  movaps [r15+0x140], xmm11
00007e4ecadd58d3  lea rax, [r12+0x10]
00007e4ecadd58d8  mov r11, [r13+rax*1]
00007e4ecadd58dd  lea rax, [r12+0x18]
00007e4ecadd58e2  mov r10, [r13+rax*1]
00007e4ecadd58e7  movq xmm12, r11
00007e4ecadd58ec  movq xmm11, r10
00007e4ecadd58f1  movq xmm12, xmm12
00007e4ecadd58f6  vmovaps [rsp+0x50], xmm12
00007e4ecadd58fc  movq xmm12, xmm12
00007e4ecadd5901  movaps [r15+0x170], xmm12
00007e4ecadd5909  movq xmm11, xmm11
00007e4ecadd590e  vmovaps [rsp+0x60], xmm11
00007e4ecadd5914  movq xmm11, xmm11
00007e4ecadd5919  movaps [r15+0x160], xmm11
00007e4ecadd5921  mov rax, [r13+r12*1]
00007e4ecadd5926  vmovq xmm12, rax
00007e4ecadd592b  vpbroadcastq xmm12, xmm12
00007e4ecadd5930  lea rax, [r12+0x08]
00007e4ecadd5935  mov r12, [r13+rax*1]
00007e4ecadd593a  movq xmm11, r12
00007e4ecadd593f  movaps [r15+0x230], xmm11
00007e4ecadd5947  mov rax, [r15+0xF8]
00007e4ecadd594e  lea r12, [rax+0x50]
00007e4ecadd5952  movups xmm11, [r13+r12*1]
00007e4ecadd5958  lea r12, [rax+0x60]
00007e4ecadd595c  movups xmm10, [r13+r12*1]
00007e4ecadd5962  lea r12, [rax+0x30]
00007e4ecadd5966  movups xmm9, [r13+r12*1]
00007e4ecadd596c  mov r12, [r15+0x50]
00007e4ecadd5970  lea r11, [r12+r14*1]
00007e4ecadd5974  mov [r15+0x60], r11
00007e4ecadd5978  lea r12, [r14+0x40]
00007e4ecadd597c  mov [r15+0x58], r12
00007e4ecadd5980  movaps xmm8, xmm12
00007e4ecadd5984  mulpd xmm8, xmm15
00007e4ecadd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4ecadd598f  ptest xmm7, xmm7
00007e4ecadd5994  jnz 0x00007E4ECADD67B7
00007e4ecadd599a  movq xmm15, qword ptr [r15+0x230]
00007e4ecadd59a3  vmovaps [rsp+0x70], xmm15
00007e4ecadd59a9  vpermilpd xmm15, xmm15, 0x00
00007e4ecadd59af  movaps xmm7, xmm9
00007e4ecadd59b3  mulpd xmm7, xmm15
00007e4ecadd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4ecadd59bd  ptest xmm6, xmm6
00007e4ecadd59c2  jnz 0x00007E4ECADD68FB
00007e4ecadd59c8  vxorps xmm15, xmm15, xmm15
00007e4ecadd59cd  vpbroadcastq xmm15, xmm15
00007e4ecadd59d2  movaps xmm9, xmm12
00007e4ecadd59d6  mulpd xmm9, xmm10
00007e4ecadd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4ecadd59e1  ptest xmm6, xmm6
00007e4ecadd59e6  jnz 0x00007E4ECADD6A3D
00007e4ecadd59ec  movaps xmm10, xmm12
00007e4ecadd59f0  mulpd xmm10, xmm11
00007e4ecadd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4ecadd59fb  ptest xmm6, xmm6
00007e4ecadd5a00  jnz 0x00007E4ECADD6B81
00007e4ecadd5a06  movaps xmm11, [r15+0x1F0]
00007e4ecadd5a0e  movaps xmm6, xmm12
00007e4ecadd5a12  mulpd xmm6, xmm11
00007e4ecadd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4ecadd5a1c  ptest xmm5, xmm5
00007e4ecadd5a21  jnz 0x00007E4ECADD6CC5
00007e4ecadd5a27  movaps xmm12, [r15+0x2A0]
00007e4ecadd5a2f  vmovaps [rsp+0x80], xmm12
00007e4ecadd5a38  vmovaps xmm11, [rsp+0x80]
00007e4ecadd5a41  por xmm12, xmm11
00007e4ecadd5a46  movaps xmm11, [r15+0x250]
00007e4ecadd5a4e  vmovaps [rsp+0x80], xmm11
00007e4ecadd5a57  vmovaps xmm5, [rsp+0x80]
00007e4ecadd5a60  por xmm11, xmm5
00007e4ecadd5a65  vmovaps xmm4, [rsp+0x70]
00007e4ecadd5a6b  vpermilpd xmm4, xmm4, 0x00
00007e4ecadd5a71  movaps xmm3, xmm5
00007e4ecadd5a74  mulpd xmm3, xmm4
00007e4ecadd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007e4ecadd5a7d  ptest xmm2, xmm2
00007e4ecadd5a82  jnz 0x00007E4ECADD6E07
00007e4ecadd5a88  mov [rsp+0x80], rax
00007e4ecadd5a90  xor eax, eax
00007e4ecadd5a92  mov r14d, 0x200
00007e4ecadd5a98  cmp r12, r14
00007e4ecadd5a9b  cmc
00007e4ecadd5a9c  lahf
00007e4ecadd5a9d  seto al
00007e4ecadd5aa0  mov [r15+0x108], eax
00007e4ecadd5aa7  movaps xmm5, xmm8
00007e4ecadd5aab  addpd xmm5, xmm15
00007e4ecadd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007e4ecadd5ab5  ptest xmm4, xmm4
00007e4ecadd5aba  jnz 0x00007E4ECADD6F47
00007e4ecadd5ac0  movaps xmm8, [r15+0x1B0]
00007e4ecadd5ac8  movaps xmm4, xmm9
00007e4ecadd5acc  addpd xmm4, xmm8
00007e4ecadd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007e4ecadd5ad6  ptest xmm2, xmm2
00007e4ecadd5adb  jnz 0x00007E4ECADD7089
00007e4ecadd5ae1  movaps xmm9, xmm10
00007e4ecadd5ae5  addpd xmm9, xmm8
00007e4ecadd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007e4ecadd5af0  ptest xmm2, xmm2
00007e4ecadd5af5  jnz 0x00007E4ECADD71CB
00007e4ecadd5afb  movaps xmm10, [r15+0x2F0]
00007e4ecadd5b03  vmovaps [rsp+0x90], xmm10
00007e4ecadd5b0c  vmovaps xmm8, [rsp+0x90]
00007e4ecadd5b15  por xmm10, xmm8
00007e4ecadd5b1a  movaps xmm8, [r15+0x2E0]
00007e4ecadd5b22  vmovaps [rsp+0x90], xmm8
00007e4ecadd5b2b  vmovaps xmm2, [rsp+0x90]
00007e4ecadd5b34  por xmm8, xmm2
00007e4ecadd5b39  movaps xmm2, [r15+0x2D0]
00007e4ecadd5b41  vmovaps [rsp+0x90], xmm2
00007e4ecadd5b4a  vmovaps [rsp+0xA0], xmm1
00007e4ecadd5b53  vmovaps xmm1, [rsp+0x90]
00007e4ecadd5b5c  por xmm2, xmm1
00007e4ecadd5b60  movaps xmm1, [r15+0x200]
00007e4ecadd5b68  vmovaps [rsp+0x90], xmm1
00007e4ecadd5b71  vmovaps [rsp+0xB0], xmm15
00007e4ecadd5b7a  vmovaps xmm15, [rsp+0x90]
00007e4ecadd5b83  por xmm1, xmm15
00007e4ecadd5b88  movaps xmm15, [r15+0x1C0]
00007e4ecadd5b90  vmovaps [rsp+0x90], xmm15
00007e4ecadd5b99  vmovaps [rsp+0xC0], xmm1
00007e4ecadd5ba2  vmovaps xmm1, [rsp+0x90]
00007e4ecadd5bab  por xmm15, xmm1
00007e4ecadd5bb0  movaps xmm1, [r15+0x190]
00007e4ecadd5bb8  vmovaps [rsp+0x90], xmm1
00007e4ecadd5bc1  vmovaps [rsp+0xD0], xmm15
00007e4ecadd5bca  vmovaps xmm15, [rsp+0x90]
00007e4ecadd5bd3  por xmm1, xmm15
00007e4ecadd5bd8  movaps xmm15, [r15+0x300]
00007e4ecadd5be0  vmovaps [rsp+0x90], xmm15
00007e4ecadd5be9  vmovaps [rsp+0xE0], xmm1
00007e4ecadd5bf2  vmovaps xmm1, [rsp+0x90]
00007e4ecadd5bfb  por xmm15, xmm1
00007e4ecadd5c00  mov rax, [rsp+0x80]
00007e4ecadd5c08  lea r14, [rax+0xA0]
00007e4ecadd5c0f  movups xmm1, [r13+r14*1]
00007e4ecadd5c15  lea r14, [rax+0xB0]
00007e4ecadd5c1c  vmovaps [rsp+0x80], xmm1
00007e4ecadd5c25  movups xmm1, [r13+r14*1]
00007e4ecadd5c2b  vmovaps [rsp+0x90], xmm1
00007e4ecadd5c34  vmovaps [rsp+0xF0], xmm15
00007e4ecadd5c3d  vmovaps xmm15, [rsp+0xB0]
00007e4ecadd5c46  vmovaps [rsp+0xB0], xmm14
00007e4ecadd5c4f  movaps xmm1, xmm6
00007e4ecadd5c52  addpd xmm1, xmm15
00007e4ecadd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4ecadd5c5c  ptest xmm14, xmm14
00007e4ecadd5c62  jnz 0x00007E4ECADD7323
00007e4ecadd5c68  lea r14, [rax+0xF0]
00007e4ecadd5c6f  movups xmm15, [r13+r14*1]
00007e4ecadd5c75  movaps xmm14, xmm4
00007e4ecadd5c79  addpd xmm14, xmm3
00007e4ecadd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4ecadd5c84  ptest xmm6, xmm6
00007e4ecadd5c89  jnz 0x00007E4ECADD746E
00007e4ecadd5c8f  movaps xmm6, xmm9
00007e4ecadd5c93  addpd xmm6, xmm7
00007e4ecadd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007e4ecadd5c9c  ptest xmm4, xmm4
00007e4ecadd5ca1  jnz 0x00007E4ECADD75B0
00007e4ecadd5ca7  vmovaps xmm9, [rsp+0x70]
00007e4ecadd5cad  vpermilpd xmm9, xmm9, 0x00
00007e4ecadd5cb3  vmovaps xmm4, [rsp+0x90]
00007e4ecadd5cbc  movaps xmm7, xmm4
00007e4ecadd5cbf  mulpd xmm7, xmm9
00007e4ecadd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007e4ecadd5cc9  ptest xmm3, xmm3
00007e4ecadd5cce  jnz 0x00007E4ECADD76F1
00007e4ecadd5cd4  vmovaps xmm9, [rsp+0x50]
00007e4ecadd5cda  vpermilpd xmm9, xmm9, 0x00
00007e4ecadd5ce0  movaps xmm4, xmm15
00007e4ecadd5ce4  mulpd xmm4, xmm9
00007e4ecadd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4ecadd5cee  ptest xmm3, xmm3
00007e4ecadd5cf3  jnz 0x00007E4ECADD7832
00007e4ecadd5cf9  lea r14, [rax+0xE0]
00007e4ecadd5d00  movups xmm15, [r13+r14*1]
00007e4ecadd5d06  vmovaps xmm9, [rsp+0x70]
00007e4ecadd5d0c  vpermilpd xmm9, xmm9, 0x00
00007e4ecadd5d12  vmovaps [rsp+0x70], xmm1
00007e4ecadd5d18  vmovaps xmm1, [rsp+0x80]
00007e4ecadd5d21  vmovaps [rsp+0x80], xmm15
00007e4ecadd5d2a  movaps xmm3, xmm1
00007e4ecadd5d2d  mulpd xmm3, xmm9
00007e4ecadd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007e4ecadd5d37  ptest xmm15, xmm15
00007e4ecadd5d3d  jnz 0x00007E4ECADD797E
00007e4ecadd5d43  vmovaps xmm1, [rsp+0xF0]
00007e4ecadd5d4c  vmovaps xmm15, [rsp+0xF0]
00007e4ecadd5d55  por xmm1, xmm15
00007e4ecadd5d5a  movaps [r15+0x300], xmm1
00007e4ecadd5d62  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd5d6b  vmovaps xmm9, [rsp+0xE0]
00007e4ecadd5d74  por xmm15, xmm9
00007e4ecadd5d79  movaps [r15+0x190], xmm15
00007e4ecadd5d81  vmovaps xmm9, [rsp+0x50]
00007e4ecadd5d87  vpermilpd xmm9, xmm9, 0x00
00007e4ecadd5d8d  vmovaps [rsp+0x90], xmm1
00007e4ecadd5d96  vmovaps [rsp+0xE0], xmm15
00007e4ecadd5d9f  vmovaps xmm15, [rsp+0x80]
00007e4ecadd5da8  vmovaps [rsp+0x80], xmm14
00007e4ecadd5db1  movaps xmm1, xmm15
00007e4ecadd5db5  mulpd xmm1, xmm9
00007e4ecadd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4ecadd5dbf  ptest xmm14, xmm14
00007e4ecadd5dc5  jnz 0x00007E4ECADD7ABF
00007e4ecadd5dcb  lea r14, [rax+0x90]
00007e4ecadd5dd2  movups xmm15, [r13+r14*1]
00007e4ecadd5dd8  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd5de1  vmovaps xmm9, [rsp+0xD0]
00007e4ecadd5dea  por xmm14, xmm9
00007e4ecadd5def  movaps [r15+0x1C0], xmm14
00007e4ecadd5df7  vmovaps xmm9, [rsp+0xC0]
00007e4ecadd5e00  vmovaps [rsp+0xD0], xmm1
00007e4ecadd5e09  vmovaps xmm1, [rsp+0xC0]
00007e4ecadd5e12  por xmm9, xmm1
00007e4ecadd5e17  movaps [r15+0x200], xmm9
00007e4ecadd5e1f  vmovaps [rsp+0xC0], xmm2
00007e4ecadd5e28  vmovaps xmm1, [rsp+0xC0]
00007e4ecadd5e31  por xmm2, xmm1
00007e4ecadd5e35  movaps [r15+0x2D0], xmm2
00007e4ecadd5e3d  vmovaps [rsp+0xC0], xmm8
00007e4ecadd5e46  vmovaps xmm1, [rsp+0xC0]
00007e4ecadd5e4f  por xmm8, xmm1
00007e4ecadd5e54  movaps [r15+0x2E0], xmm8
00007e4ecadd5e5c  vmovaps [rsp+0xC0], xmm15
00007e4ecadd5e65  movaps xmm1, xmm5
00007e4ecadd5e68  addpd xmm1, xmm7
00007e4ecadd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4ecadd5e71  ptest xmm15, xmm15
00007e4ecadd5e77  jnz 0x00007E4ECADD7C0B
00007e4ecadd5e7d  vmovaps xmm15, [rsp+0x50]
00007e4ecadd5e83  vpermilpd xmm15, xmm15, 0x00
00007e4ecadd5e89  vmovaps xmm5, [rsp+0xC0]
00007e4ecadd5e92  vmovaps [rsp+0xC0], xmm1
00007e4ecadd5e9b  movaps xmm7, xmm5
00007e4ecadd5e9e  mulpd xmm7, xmm15
00007e4ecadd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007e4ecadd5ea8  ptest xmm1, xmm1
00007e4ecadd5ead  jnz 0x00007E4ECADD7D4B
00007e4ecadd5eb3  lea r14, [rax+0x80]
00007e4ecadd5eba  movups xmm1, [r13+r14*1]
00007e4ecadd5ec0  vmovaps xmm5, [rsp+0x70]
00007e4ecadd5ec6  vmovaps [rsp+0x70], xmm1
00007e4ecadd5ecc  movaps xmm15, xmm5
00007e4ecadd5ed0  addpd xmm15, xmm3
00007e4ecadd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecadd5edb  ptest xmm1, xmm1
00007e4ecadd5ee0  jnz 0x00007E4ECADD7E96
00007e4ecadd5ee6  vmovaps xmm5, [rsp+0x80]
00007e4ecadd5eef  movaps xmm1, xmm5
00007e4ecadd5ef2  addpd xmm1, xmm4
00007e4ecadd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007e4ecadd5efb  ptest xmm3, xmm3
00007e4ecadd5f00  jnz 0x00007E4ECADD7FD8
00007e4ecadd5f06  vmovaps [rsp+0x80], xmm10
00007e4ecadd5f0f  vmovaps xmm5, [rsp+0x80]
00007e4ecadd5f18  por xmm10, xmm5
00007e4ecadd5f1d  movaps [r15+0x2F0], xmm10
00007e4ecadd5f25  vmovaps xmm5, [rsp+0x50]
00007e4ecadd5f2b  vpermilpd xmm5, xmm5, 0x00
00007e4ecadd5f31  vmovaps xmm3, [rsp+0x70]
00007e4ecadd5f37  vmovaps [rsp+0x50], xmm1
00007e4ecadd5f3d  movaps xmm4, xmm3
00007e4ecadd5f40  mulpd xmm4, xmm5
00007e4ecadd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4ecadd5f49  ptest xmm1, xmm1
00007e4ecadd5f4e  jnz 0x00007E4ECADD8118
00007e4ecadd5f54  lea r14, [rax+0xD0]
00007e4ecadd5f5b  movups xmm1, [r13+r14*1]
00007e4ecadd5f61  vmovaps xmm3, [rsp+0xD0]
00007e4ecadd5f6a  vmovaps [rsp+0x70], xmm1
00007e4ecadd5f70  movaps xmm5, xmm6
00007e4ecadd5f73  addpd xmm5, xmm3
00007e4ecadd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007e4ecadd5f7c  ptest xmm1, xmm1
00007e4ecadd5f81  jnz 0x00007E4ECADD8262
00007e4ecadd5f87  vmovaps xmm1, [rsp+0x60]
00007e4ecadd5f8d  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd5f93  movaps xmm6, xmm9
00007e4ecadd5f97  mulpd xmm6, xmm1
00007e4ecadd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4ecadd5fa0  ptest xmm3, xmm3
00007e4ecadd5fa5  jnz 0x00007E4ECADD83A2
00007e4ecadd5fab  movaps [r15+0x260], xmm6
00007e4ecadd5fb3  vxorps xmm1, xmm1, xmm1
00007e4ecadd5fb7  vpbroadcastq xmm1, xmm1
00007e4ecadd5fbc  movaps [r15+0x1B0], xmm1
00007e4ecadd5fc4  vmovaps xmm1, [rsp+0x60]
00007e4ecadd5fca  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd5fd0  vmovaps xmm3, [rsp+0x70]
00007e4ecadd5fd6  vmovaps [rsp+0x70], xmm15
00007e4ecadd5fdc  movaps xmm9, xmm3
00007e4ecadd5fe0  mulpd xmm9, xmm1
00007e4ecadd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4ecadd5feb  ptest xmm15, xmm15
00007e4ecadd5ff1  jnz 0x00007E4ECADD84E3
00007e4ecadd5ff7  lea r14, [rax+0xC0]
00007e4ecadd5ffe  movups xmm1, [r13+r14*1]
00007e4ecadd6004  vmovaps xmm3, [rsp+0xC0]
00007e4ecadd600d  vmovaps [rsp+0x80], xmm1
00007e4ecadd6016  movaps xmm15, xmm3
00007e4ecadd601a  addpd xmm15, xmm7
00007e4ecadd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecadd6025  ptest xmm1, xmm1
00007e4ecadd602a  jnz 0x00007E4ECADD862F
00007e4ecadd6030  vmovaps [rsp+0xC0], xmm13
00007e4ecadd6039  vmovaps xmm1, [rsp+0xC0]
00007e4ecadd6042  por xmm13, xmm1
00007e4ecadd6047  movaps [r15+0x270], xmm13
00007e4ecadd604f  vmovaps xmm1, [rsp+0xB0]
00007e4ecadd6058  vmovaps xmm7, [rsp+0xB0]
00007e4ecadd6061  por xmm1, xmm7
00007e4ecadd6065  movaps [r15+0x1A0], xmm1
00007e4ecadd606d  vmovaps xmm1, [rsp+0x60]
00007e4ecadd6073  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd6079  vmovaps [rsp+0xB0], xmm1
00007e4ecadd6082  vmovaps xmm1, [rsp+0x80]
00007e4ecadd608b  vmovaps [rsp+0x80], xmm15
00007e4ecadd6094  vmovaps xmm15, [rsp+0xB0]
00007e4ecadd609d  vmovaps [rsp+0xB0], xmm14
00007e4ecadd60a6  movaps xmm3, xmm1
00007e4ecadd60a9  mulpd xmm3, xmm15
00007e4ecadd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007e4ecadd60b3  ptest xmm14, xmm14
00007e4ecadd60b9  jnz 0x00007E4ECADD8771
00007e4ecadd60bf  lea r14, [rax+0x20]
00007e4ecadd60c3  movups xmm1, [r13+r14*1]
00007e4ecadd60c9  movaps [r15+0x110], xmm1
00007e4ecadd60d1  vmovaps xmm14, [rsp+0x70]
00007e4ecadd60d7  vmovaps [rsp+0x70], xmm1
00007e4ecadd60dd  movaps xmm15, xmm14
00007e4ecadd60e1  addpd xmm15, xmm4
00007e4ecadd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecadd60ec  ptest xmm1, xmm1
00007e4ecadd60f1  jnz 0x00007E4ECADD88BC
00007e4ecadd60f7  vmovaps xmm1, [rsp+0x60]
00007e4ecadd60fd  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd6103  movaps xmm14, xmm2
00007e4ecadd6107  mulpd xmm14, xmm1
00007e4ecadd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007e4ecadd6112  ptest xmm4, xmm4
00007e4ecadd6117  jnz 0x00007E4ECADD89FF
00007e4ecadd611d  vmovaps xmm4, [rsp+0x50]
00007e4ecadd6123  movaps xmm1, xmm4
00007e4ecadd6126  addpd xmm1, xmm9
00007e4ecadd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4ecadd6130  ptest xmm2, xmm2
00007e4ecadd6135  jnz 0x00007E4ECADD8B41
00007e4ecadd613b  vmovaps xmm9, [rsp+0x30]
00007e4ecadd6141  vpermilpd xmm9, xmm9, 0x00
00007e4ecadd6147  vmovaps xmm2, [rsp+0x70]
00007e4ecadd614d  vmovaps [rsp+0x50], xmm1
00007e4ecadd6153  movaps xmm4, xmm2
00007e4ecadd6156  mulpd xmm4, xmm9
00007e4ecadd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4ecadd6160  ptest xmm1, xmm1
00007e4ecadd6165  jnz 0x00007E4ECADD8C82
00007e4ecadd616b  vmovaps xmm1, [rsp+0x30]
00007e4ecadd6171  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd6177  vmovaps xmm2, [rsp+0x90]
00007e4ecadd6180  vmovaps [rsp+0x60], xmm15
00007e4ecadd6186  movaps xmm9, xmm2
00007e4ecadd618a  mulpd xmm9, xmm1
00007e4ecadd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4ecadd6195  ptest xmm15, xmm15
00007e4ecadd619b  jnz 0x00007E4ECADD8DC3
00007e4ecadd61a1  vmovaps xmm15, [rsp+0x80]
00007e4ecadd61aa  movaps xmm1, xmm15
00007e4ecadd61ae  addpd xmm1, xmm6
00007e4ecadd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4ecadd61b7  ptest xmm2, xmm2
00007e4ecadd61bc  jnz 0x00007E4ECADD8F05
00007e4ecadd61c2  movaps xmm15, xmm5
00007e4ecadd61c6  addpd xmm15, xmm3
00007e4ecadd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007e4ecadd61d1  ptest xmm6, xmm6
00007e4ecadd61d6  jnz 0x00007E4ECADD9046
00007e4ecadd61dc  vmovaps xmm6, [rsp+0x30]
00007e4ecadd61e2  vpermilpd xmm6, xmm6, 0x00
00007e4ecadd61e8  movaps xmm5, xmm8
00007e4ecadd61ec  mulpd xmm5, xmm6
00007e4ecadd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007e4ecadd61f5  ptest xmm3, xmm3
00007e4ecadd61fa  jnz 0x00007E4ECADD9188
00007e4ecadd6200  vmovaps xmm8, [rsp+0x30]
00007e4ecadd6206  vpermilpd xmm8, xmm8, 0x00
00007e4ecadd620c  movaps xmm6, xmm10
00007e4ecadd6210  mulpd xmm6, xmm8
00007e4ecadd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4ecadd621a  ptest xmm3, xmm3
00007e4ecadd621f  jnz 0x00007E4ECADD92C9
00007e4ecadd6225  vmovaps xmm8, [rsp+0x60]
00007e4ecadd622b  movaps xmm10, xmm8
00007e4ecadd622f  addpd xmm10, xmm14
00007e4ecadd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007e4ecadd623a  ptest xmm3, xmm3
00007e4ecadd623f  jnz 0x00007E4ECADD940B
00007e4ecadd6245  vmovaps xmm8, [rsp+0x50]
00007e4ecadd624b  movaps xmm14, xmm8
00007e4ecadd624f  addpd xmm14, xmm4
00007e4ecadd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007e4ecadd625a  ptest xmm3, xmm3
00007e4ecadd625f  jnz 0x00007E4ECADD954F
00007e4ecadd6265  vmovaps xmm8, [rsp+0x40]
00007e4ecadd626b  vpermilpd xmm8, xmm8, 0x00
00007e4ecadd6271  movaps xmm4, xmm13
00007e4ecadd6275  mulpd xmm4, xmm8
00007e4ecadd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4ecadd627f  ptest xmm3, xmm3
00007e4ecadd6284  jnz 0x00007E4ECADD9692
00007e4ecadd628a  movaps xmm13, xmm15
00007e4ecadd628e  addpd xmm13, xmm9
00007e4ecadd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007e4ecadd6299  ptest xmm8, xmm8
00007e4ecadd629f  jnz 0x00007E4ECADD97D4
00007e4ecadd62a5  movaps xmm15, xmm1
00007e4ecadd62a9  addpd xmm15, xmm5
00007e4ecadd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4ecadd62b4  ptest xmm9, xmm9
00007e4ecadd62ba  jnz 0x00007E4ECADD9918
00007e4ecadd62c0  vmovaps [rsp+0x30], xmm11
00007e4ecadd62c6  vmovaps xmm1, [rsp+0x30]
00007e4ecadd62cc  por xmm11, xmm1
00007e4ecadd62d1  movaps [r15+0x250], xmm11
00007e4ecadd62d9  vmovaps [rsp+0x30], xmm12
00007e4ecadd62df  vmovaps xmm1, [rsp+0x30]
00007e4ecadd62e5  por xmm12, xmm1
00007e4ecadd62ea  movaps [r15+0x2A0], xmm12
00007e4ecadd62f2  vmovaps xmm1, [rsp+0xA0]
00007e4ecadd62fb  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd6304  por xmm1, xmm11
00007e4ecadd6309  movaps [r15+0x1D0], xmm1
00007e4ecadd6311  lea r14, [rax+0x40]
00007e4ecadd6315  movups xmm1, [r13+r14*1]
00007e4ecadd631b  movaps [r15+0x2C0], xmm1
00007e4ecadd6323  vmovaps xmm11, [rsp+0x40]
00007e4ecadd6329  vpermilpd xmm11, xmm11, 0x00
00007e4ecadd632f  vmovaps xmm8, [rsp+0xE0]
00007e4ecadd6338  movaps xmm9, xmm8
00007e4ecadd633c  mulpd xmm9, xmm11
00007e4ecadd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007e4ecadd6347  ptest xmm5, xmm5
00007e4ecadd634c  jnz 0x00007E4ECADD9A64
00007e4ecadd6352  movaps xmm11, xmm10
00007e4ecadd6356  addpd xmm11, xmm6
00007e4ecadd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007e4ecadd6361  ptest xmm8, xmm8
00007e4ecadd6367  jnz 0x00007E4ECADD9BA8
00007e4ecadd636d  movaps xmm10, xmm14
00007e4ecadd6371  addpd xmm10, xmm4
00007e4ecadd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007e4ecadd637c  ptest xmm8, xmm8
00007e4ecadd6382  jnz 0x00007E4ECADD9CEB
00007e4ecadd6388  vmovaps xmm14, [rsp+0x40]
00007e4ecadd638e  vpermilpd xmm14, xmm14, 0x00
00007e4ecadd6394  movaps xmm8, xmm1
00007e4ecadd6398  mulpd xmm8, xmm14
00007e4ecadd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4ecadd63a3  ptest xmm6, xmm6
00007e4ecadd63a8  jnz 0x00007E4ECADD9E2E
00007e4ecadd63ae  movaps xmm1, [r15+0x2B0]
00007e4ecadd63b6  vmovaps xmm14, [rsp+0x40]
00007e4ecadd63bc  vpermilpd xmm14, xmm14, 0x00
00007e4ecadd63c2  movaps xmm6, xmm1
00007e4ecadd63c5  mulpd xmm6, xmm14
00007e4ecadd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4ecadd63cf  ptest xmm5, xmm5
00007e4ecadd63d4  jnz 0x00007E4ECADD9F71
00007e4ecadd63da  vmovaps xmm1, [rsp+0x10]
00007e4ecadd63e0  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd63e6  movaps xmm14, xmm12
00007e4ecadd63ea  mulpd xmm14, xmm1
00007e4ecadd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007e4ecadd63f5  ptest xmm5, xmm5
00007e4ecadd63fa  jnz 0x00007E4ECADDA0B2
00007e4ecadd6400  movaps xmm1, xmm13
00007e4ecadd6404  addpd xmm1, xmm9
00007e4ecadd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4ecadd640e  ptest xmm12, xmm12
00007e4ecadd6414  jnz 0x00007E4ECADDA1F5
00007e4ecadd641a  vmovaps xmm13, [rsp+0x10]
00007e4ecadd6420  vpermilpd xmm13, xmm13, 0x00
00007e4ecadd6426  movaps xmm12, xmm7
00007e4ecadd642a  mulpd xmm12, xmm13
00007e4ecadd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4ecadd6435  ptest xmm9, xmm9
00007e4ecadd643b  jnz 0x00007E4ECADDA337
00007e4ecadd6441  movaps xmm13, xmm15
00007e4ecadd6445  addpd xmm13, xmm8
00007e4ecadd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007e4ecadd6450  ptest xmm9, xmm9
00007e4ecadd6456  jnz 0x00007E4ECADDA47A
00007e4ecadd645c  movaps xmm15, [r15+0x290]
00007e4ecadd6464  vmovaps xmm9, [rsp+0x10]
00007e4ecadd646a  vpermilpd xmm9, xmm9, 0x00
00007e4ecadd6470  movaps xmm8, xmm15
00007e4ecadd6474  mulpd xmm8, xmm9
00007e4ecadd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4ecadd647f  ptest xmm7, xmm7
00007e4ecadd6484  jnz 0x00007E4ECADDA5BE
00007e4ecadd648a  movaps xmm15, xmm11
00007e4ecadd648e  addpd xmm15, xmm6
00007e4ecadd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4ecadd6499  ptest xmm9, xmm9
00007e4ecadd649f  jnz 0x00007E4ECADDA702
00007e4ecadd64a5  movaps xmm11, [r15+0x1E0]
00007e4ecadd64ad  vmovaps xmm9, [rsp+0x10]
00007e4ecadd64b3  vpermilpd xmm9, xmm9, 0x00
00007e4ecadd64b9  movaps xmm7, xmm11
00007e4ecadd64bd  mulpd xmm7, xmm9
00007e4ecadd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4ecadd64c7  ptest xmm6, xmm6
00007e4ecadd64cc  jnz 0x00007E4ECADDA845
00007e4ecadd64d2  movaps xmm11, xmm10
00007e4ecadd64d6  addpd xmm11, xmm14
00007e4ecadd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007e4ecadd64e1  ptest xmm9, xmm9
00007e4ecadd64e7  jnz 0x00007E4ECADDA987
00007e4ecadd64ed  lea r14, [rax+0x70]
00007e4ecadd64f1  movups xmm14, [r13+r14*1]
00007e4ecadd64f7  movaps [r15+0x240], xmm14
00007e4ecadd64ff  movaps xmm10, xmm1
00007e4ecadd6503  addpd xmm10, xmm12
00007e4ecadd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007e4ecadd650e  ptest xmm9, xmm9
00007e4ecadd6514  jnz 0x00007E4ECADDAAD5
00007e4ecadd651a  movaps [r15+0x170], xmm10
00007e4ecadd6522  vmovaps xmm1, [rsp+0x20]
00007e4ecadd6528  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd652e  movaps xmm12, xmm14
00007e4ecadd6532  mulpd xmm12, xmm1
00007e4ecadd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4ecadd653d  ptest xmm9, xmm9
00007e4ecadd6543  jnz 0x00007E4ECADDAC18
00007e4ecadd6549  vmovaps xmm1, [rsp+0x20]
00007e4ecadd654f  vpermilpd xmm1, xmm1, 0x00
00007e4ecadd6555  vmovaps xmm9, [rsp+0xB0]
00007e4ecadd655e  movaps xmm14, xmm9
00007e4ecadd6562  mulpd xmm14, xmm1
00007e4ecadd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4ecadd656d  ptest xmm6, xmm6
00007e4ecadd6572  jnz 0x00007E4ECADDAD5B
00007e4ecadd6578  movaps [r15+0x180], xmm14
00007e4ecadd6580  movaps xmm1, xmm13
00007e4ecadd6584  addpd xmm1, xmm8
00007e4ecadd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007e4ecadd658e  ptest xmm9, xmm9
00007e4ecadd6594  jnz 0x00007E4ECADDAE9E
00007e4ecadd659a  movaps [r15+0x210], xmm1
00007e4ecadd65a2  movups xmm13, [r13+rax*1]
00007e4ecadd65a8  lea r14, [rax+0x10]
00007e4ecadd65ac  movups xmm9, [r13+r14*1]
00007e4ecadd65b2  movaps [r15+0x230], xmm9
00007e4ecadd65ba  movaps xmm8, xmm15
00007e4ecadd65be  addpd xmm8, xmm7
00007e4ecadd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4ecadd65c9  ptest xmm6, xmm6
00007e4ecadd65ce  jnz 0x00007E4ECADDAFF4
00007e4ecadd65d4  movaps [r15+0x130], xmm8
00007e4ecadd65dc  vmovaps xmm15, [rsp+0x20]
00007e4ecadd65e2  vpermilpd xmm15, xmm15, 0x00
00007e4ecadd65e8  movaps xmm7, xmm9
00007e4ecadd65ec  mulpd xmm7, xmm15
00007e4ecadd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4ecadd65f6  ptest xmm6, xmm6
00007e4ecadd65fb  jnz 0x00007E4ECADDB137
00007e4ecadd6601  movaps [r15+0x220], xmm7
00007e4ecadd6609  vmovaps xmm15, [rsp+0x20]
00007e4ecadd660f  vpermilpd xmm15, xmm15, 0x00
00007e4ecadd6615  movaps xmm9, xmm13
00007e4ecadd6619  mulpd xmm9, xmm15
00007e4ecadd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4ecadd6624  ptest xmm6, xmm6
00007e4ecadd6629  jnz 0x00007E4ECADDB279
00007e4ecadd662f  movaps xmm15, xmm11
00007e4ecadd6633  addpd xmm15, xmm12
00007e4ecadd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4ecadd663e  ptest xmm13, xmm13
00007e4ecadd6644  jnz 0x00007E4ECADDB3BD
00007e4ecadd664a  movaps [r15+0x140], xmm15
00007e4ecadd6652  movaps xmm13, xmm10
00007e4ecadd6656  addpd xmm13, xmm14
00007e4ecadd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4ecadd6661  ptest xmm12, xmm12
00007e4ecadd6667  jnz 0x00007E4ECADDB501
00007e4ecadd666d  movaps [r15+0x150], xmm13
00007e4ecadd6675  movaps xmm14, xmm1
00007e4ecadd6679  addpd xmm14, xmm7
00007e4ecadd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007e4ecadd6684  ptest xmm12, xmm12
00007e4ecadd668a  jnz 0x00007E4ECADDB645
00007e4ecadd6690  movaps [r15+0x160], xmm14
00007e4ecadd6698  movaps xmm1, xmm8
00007e4ecadd669c  addpd xmm1, xmm9
00007e4ecadd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4ecadd66a6  ptest xmm12, xmm12
00007e4ecadd66ac  jnz 0x00007E4ECADDB787
00007e4ecadd66b2  movaps [r15+0x120], xmm1
00007e4ecadd66ba  movups [r13+r11*1], xmm15
00007e4ecadd66c0  lea rax, [r11+0x10]
00007e4ecadd66c4  movups [r13+rax*1], xmm13
00007e4ecadd66ca  lea rax, [r11+0x20]
00007e4ecadd66ce  movups [r13+rax*1], xmm14
00007e4ecadd66d4  lea rax, [r11+0x30]
00007e4ecadd66d8  movups [r13+rax*1], xmm1
00007e4ecadd66de  mov eax, [r15+0x108]
00007e4ecadd66e5  sahf
00007e4ecadd66e6  jnz 0x00007E4ECADD6718
00007e4ecadd66e8  cmp dword ptr [r15+0x318], 0x00
00007e4ecadd66f0  jz 0x00007E4ECADDB900
00007e4ecadd66f6  nop [rax+rax*1], ax
00007e4ecadd66ff  nop [rax+rax*1], eax
00007e4ecadd6707  mov eax, 0x410444
00007e4ecadd670c  mov [r15+0x100], rax
00007e4ecadd6713  jmp 0x00007E4ECABFE110
00007e4ecadd6718  cmp dword ptr [r15+0x318], 0x00
00007e4ecadd6720  jz 0x00007E4ECADD57E0
00007e4ecadd6726  nop [rax+rax*1], ax
00007e4ecadd672f  nop [rax+rax*1], eax
00007e4ecadd6737  mov eax, 0x410278
00007e4ecadd673c  mov [r15+0x100], rax
00007e4ecadd6743  jmp 0x00007E4ECABFE110
00007e4ecadd6748  int3
00007e4ecadd6749  call 0x00007E4ECAC0A4B0
00007e4ecadd674e  jmp 0x00007E4ECADD5828
00007e4ecadd6753  call 0x00007E4ECAC09240
00007e4ecadd6758  jmp 0x00007E4ECADD5832
00007e4ecadd675d  call 0x00007E4ECAC0A4B0
00007e4ecadd6762  jmp 0x00007E4ECADD588F
00007e4ecadd6767  call 0x00007E4ECAC09240
00007e4ecadd676c  jmp 0x00007E4ECADD5899
00007e4ecadd6771  call 0x00007E4ECAC0A4B0
00007e4ecadd6776  jmp 0x00007E4ECADD58DD
00007e4ecadd677b  call 0x00007E4ECAC09240
00007e4ecadd6780  jmp 0x00007E4ECADD58E7
00007e4ecadd6785  call 0x00007E4ECACB47C0
00007e4ecadd678a  jmp 0x00007E4ECADD5926
00007e4ecadd678f  call 0x00007E4ECAC0B720
00007e4ecadd6794  jmp 0x00007E4ECADD593A
00007e4ecadd6799  call 0x00007E4ECACBFC30
00007e4ecadd679e  jmp 0x00007E4ECADD5958
00007e4ecadd67a3  call 0x00007E4ECACBE9C0
00007e4ecadd67a8  jmp 0x00007E4ECADD5962
00007e4ecadd67ad  call 0x00007E4ECACBD750
00007e4ecadd67b2  jmp 0x00007E4ECADD596C
00007e4ecadd67b7  sub rsp, 0x08
00007e4ecadd67bb  push rax
00007e4ecadd67bc  push rcx
00007e4ecadd67bd  push rdx
00007e4ecadd67be  push rdi
00007e4ecadd67bf  push rsi
00007e4ecadd67c0  push r8
00007e4ecadd67c2  push r9
00007e4ecadd67c4  push r10
00007e4ecadd67c6  push r11
00007e4ecadd67c8  sub rsp, 0xF0
00007e4ecadd67cf  vmovaps [rsp], xmm0
00007e4ecadd67d4  vmovaps [rsp+0x10], xmm1
00007e4ecadd67da  vmovaps [rsp+0x20], xmm2
00007e4ecadd67e0  vmovaps [rsp+0x30], xmm3
00007e4ecadd67e6  vmovaps [rsp+0x40], xmm4
00007e4ecadd67ec  vmovaps [rsp+0x50], xmm5
00007e4ecadd67f2  vmovaps [rsp+0x60], xmm6
00007e4ecadd67f8  vmovaps [rsp+0x70], xmm7
00007e4ecadd67fe  vmovaps [rsp+0x80], xmm9
00007e4ecadd6807  vmovaps [rsp+0x90], xmm10
00007e4ecadd6810  vmovaps [rsp+0xA0], xmm11
00007e4ecadd6819  vmovaps [rsp+0xB0], xmm12
00007e4ecadd6822  vmovaps [rsp+0xC0], xmm13
00007e4ecadd682b  vmovaps [rsp+0xD0], xmm14
00007e4ecadd6834  vmovaps [rsp+0xE0], xmm15
00007e4ecadd683d  sub rsp, 0x30
00007e4ecadd6841  movaps [rsp], xmm8
00007e4ecadd6846  movaps [rsp+0x10], xmm12
00007e4ecadd684c  movaps [rsp+0x20], xmm15
00007e4ecadd6852  lea rdi, [rsp]
00007e4ecadd6856  mov esi, 0x00
00007e4ecadd685b  mov rax, 0x5784BC1F5530
00007e4ecadd6865  call rax
00007e4ecadd6867  movaps xmm8, [rsp]
00007e4ecadd686c  add rsp, 0x30
00007e4ecadd6870  vmovaps xmm0, [rsp]
00007e4ecadd6875  vmovaps xmm1, [rsp+0x10]
00007e4ecadd687b  vmovaps xmm2, [rsp+0x20]
00007e4ecadd6881  vmovaps xmm3, [rsp+0x30]
00007e4ecadd6887  vmovaps xmm4, [rsp+0x40]
00007e4ecadd688d  vmovaps xmm5, [rsp+0x50]
00007e4ecadd6893  vmovaps xmm6, [rsp+0x60]
00007e4ecadd6899  vmovaps xmm7, [rsp+0x70]
00007e4ecadd689f  vmovaps xmm9, [rsp+0x80]
00007e4ecadd68a8  vmovaps xmm10, [rsp+0x90]
00007e4ecadd68b1  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd68ba  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd68c3  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd68cc  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd68d5  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd68de  add rsp, 0xF0
00007e4ecadd68e5  pop r11
00007e4ecadd68e7  pop r10
00007e4ecadd68e9  pop r9
00007e4ecadd68eb  pop r8
00007e4ecadd68ed  pop rsi
00007e4ecadd68ee  pop rdi
00007e4ecadd68ef  pop rdx
00007e4ecadd68f0  pop rcx
00007e4ecadd68f1  pop rax
00007e4ecadd68f2  add rsp, 0x08
00007e4ecadd68f6  jmp 0x00007E4ECADD599A
00007e4ecadd68fb  sub rsp, 0x08
00007e4ecadd68ff  push rax
00007e4ecadd6900  push rcx
00007e4ecadd6901  push rdx
00007e4ecadd6902  push rdi
00007e4ecadd6903  push rsi
00007e4ecadd6904  push r8
00007e4ecadd6906  push r9
00007e4ecadd6908  push r10
00007e4ecadd690a  push r11
00007e4ecadd690c  sub rsp, 0xF0
00007e4ecadd6913  vmovaps [rsp], xmm0
00007e4ecadd6918  vmovaps [rsp+0x10], xmm1
00007e4ecadd691e  vmovaps [rsp+0x20], xmm2
00007e4ecadd6924  vmovaps [rsp+0x30], xmm3
00007e4ecadd692a  vmovaps [rsp+0x40], xmm4
00007e4ecadd6930  vmovaps [rsp+0x50], xmm5
00007e4ecadd6936  vmovaps [rsp+0x60], xmm6
00007e4ecadd693c  vmovaps [rsp+0x70], xmm8
00007e4ecadd6942  vmovaps [rsp+0x80], xmm9
00007e4ecadd694b  vmovaps [rsp+0x90], xmm10
00007e4ecadd6954  vmovaps [rsp+0xA0], xmm11
00007e4ecadd695d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd6966  vmovaps [rsp+0xC0], xmm13
00007e4ecadd696f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd6978  vmovaps [rsp+0xE0], xmm15
00007e4ecadd6981  sub rsp, 0x30
00007e4ecadd6985  movaps [rsp], xmm7
00007e4ecadd6989  movaps [rsp+0x10], xmm9
00007e4ecadd698f  movaps [rsp+0x20], xmm15
00007e4ecadd6995  lea rdi, [rsp]
00007e4ecadd6999  mov esi, 0x00
00007e4ecadd699e  mov rax, 0x5784BC1F5530
00007e4ecadd69a8  call rax
00007e4ecadd69aa  movaps xmm7, [rsp]
00007e4ecadd69ae  add rsp, 0x30
00007e4ecadd69b2  vmovaps xmm0, [rsp]
00007e4ecadd69b7  vmovaps xmm1, [rsp+0x10]
00007e4ecadd69bd  vmovaps xmm2, [rsp+0x20]
00007e4ecadd69c3  vmovaps xmm3, [rsp+0x30]
00007e4ecadd69c9  vmovaps xmm4, [rsp+0x40]
00007e4ecadd69cf  vmovaps xmm5, [rsp+0x50]
00007e4ecadd69d5  vmovaps xmm6, [rsp+0x60]
00007e4ecadd69db  vmovaps xmm8, [rsp+0x70]
00007e4ecadd69e1  vmovaps xmm9, [rsp+0x80]
00007e4ecadd69ea  vmovaps xmm10, [rsp+0x90]
00007e4ecadd69f3  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd69fc  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd6a05  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd6a0e  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd6a17  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd6a20  add rsp, 0xF0
00007e4ecadd6a27  pop r11
00007e4ecadd6a29  pop r10
00007e4ecadd6a2b  pop r9
00007e4ecadd6a2d  pop r8
00007e4ecadd6a2f  pop rsi
00007e4ecadd6a30  pop rdi
00007e4ecadd6a31  pop rdx
00007e4ecadd6a32  pop rcx
00007e4ecadd6a33  pop rax
00007e4ecadd6a34  add rsp, 0x08
00007e4ecadd6a38  jmp 0x00007E4ECADD59C8
00007e4ecadd6a3d  sub rsp, 0x08
00007e4ecadd6a41  push rax
00007e4ecadd6a42  push rcx
00007e4ecadd6a43  push rdx
00007e4ecadd6a44  push rdi
00007e4ecadd6a45  push rsi
00007e4ecadd6a46  push r8
00007e4ecadd6a48  push r9
00007e4ecadd6a4a  push r10
00007e4ecadd6a4c  push r11
00007e4ecadd6a4e  sub rsp, 0xF0
00007e4ecadd6a55  vmovaps [rsp], xmm0
00007e4ecadd6a5a  vmovaps [rsp+0x10], xmm1
00007e4ecadd6a60  vmovaps [rsp+0x20], xmm2
00007e4ecadd6a66  vmovaps [rsp+0x30], xmm3
00007e4ecadd6a6c  vmovaps [rsp+0x40], xmm4
00007e4ecadd6a72  vmovaps [rsp+0x50], xmm5
00007e4ecadd6a78  vmovaps [rsp+0x60], xmm6
00007e4ecadd6a7e  vmovaps [rsp+0x70], xmm7
00007e4ecadd6a84  vmovaps [rsp+0x80], xmm8
00007e4ecadd6a8d  vmovaps [rsp+0x90], xmm10
00007e4ecadd6a96  vmovaps [rsp+0xA0], xmm11
00007e4ecadd6a9f  vmovaps [rsp+0xB0], xmm12
00007e4ecadd6aa8  vmovaps [rsp+0xC0], xmm13
00007e4ecadd6ab1  vmovaps [rsp+0xD0], xmm14
00007e4ecadd6aba  vmovaps [rsp+0xE0], xmm15
00007e4ecadd6ac3  sub rsp, 0x30
00007e4ecadd6ac7  movaps [rsp], xmm9
00007e4ecadd6acc  movaps [rsp+0x10], xmm12
00007e4ecadd6ad2  movaps [rsp+0x20], xmm10
00007e4ecadd6ad8  lea rdi, [rsp]
00007e4ecadd6adc  mov esi, 0x00
00007e4ecadd6ae1  mov rax, 0x5784BC1F5530
00007e4ecadd6aeb  call rax
00007e4ecadd6aed  movaps xmm9, [rsp]
00007e4ecadd6af2  add rsp, 0x30
00007e4ecadd6af6  vmovaps xmm0, [rsp]
00007e4ecadd6afb  vmovaps xmm1, [rsp+0x10]
00007e4ecadd6b01  vmovaps xmm2, [rsp+0x20]
00007e4ecadd6b07  vmovaps xmm3, [rsp+0x30]
00007e4ecadd6b0d  vmovaps xmm4, [rsp+0x40]
00007e4ecadd6b13  vmovaps xmm5, [rsp+0x50]
00007e4ecadd6b19  vmovaps xmm6, [rsp+0x60]
00007e4ecadd6b1f  vmovaps xmm7, [rsp+0x70]
00007e4ecadd6b25  vmovaps xmm8, [rsp+0x80]
00007e4ecadd6b2e  vmovaps xmm10, [rsp+0x90]
00007e4ecadd6b37  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd6b40  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd6b49  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd6b52  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd6b5b  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd6b64  add rsp, 0xF0
00007e4ecadd6b6b  pop r11
00007e4ecadd6b6d  pop r10
00007e4ecadd6b6f  pop r9
00007e4ecadd6b71  pop r8
00007e4ecadd6b73  pop rsi
00007e4ecadd6b74  pop rdi
00007e4ecadd6b75  pop rdx
00007e4ecadd6b76  pop rcx
00007e4ecadd6b77  pop rax
00007e4ecadd6b78  add rsp, 0x08
00007e4ecadd6b7c  jmp 0x00007E4ECADD59EC
00007e4ecadd6b81  sub rsp, 0x08
00007e4ecadd6b85  push rax
00007e4ecadd6b86  push rcx
00007e4ecadd6b87  push rdx
00007e4ecadd6b88  push rdi
00007e4ecadd6b89  push rsi
00007e4ecadd6b8a  push r8
00007e4ecadd6b8c  push r9
00007e4ecadd6b8e  push r10
00007e4ecadd6b90  push r11
00007e4ecadd6b92  sub rsp, 0xF0
00007e4ecadd6b99  vmovaps [rsp], xmm0
00007e4ecadd6b9e  vmovaps [rsp+0x10], xmm1
00007e4ecadd6ba4  vmovaps [rsp+0x20], xmm2
00007e4ecadd6baa  vmovaps [rsp+0x30], xmm3
00007e4ecadd6bb0  vmovaps [rsp+0x40], xmm4
00007e4ecadd6bb6  vmovaps [rsp+0x50], xmm5
00007e4ecadd6bbc  vmovaps [rsp+0x60], xmm6
00007e4ecadd6bc2  vmovaps [rsp+0x70], xmm7
00007e4ecadd6bc8  vmovaps [rsp+0x80], xmm8
00007e4ecadd6bd1  vmovaps [rsp+0x90], xmm9
00007e4ecadd6bda  vmovaps [rsp+0xA0], xmm11
00007e4ecadd6be3  vmovaps [rsp+0xB0], xmm12
00007e4ecadd6bec  vmovaps [rsp+0xC0], xmm13
00007e4ecadd6bf5  vmovaps [rsp+0xD0], xmm14
00007e4ecadd6bfe  vmovaps [rsp+0xE0], xmm15
00007e4ecadd6c07  sub rsp, 0x30
00007e4ecadd6c0b  movaps [rsp], xmm10
00007e4ecadd6c10  movaps [rsp+0x10], xmm12
00007e4ecadd6c16  movaps [rsp+0x20], xmm11
00007e4ecadd6c1c  lea rdi, [rsp]
00007e4ecadd6c20  mov esi, 0x00
00007e4ecadd6c25  mov rax, 0x5784BC1F5530
00007e4ecadd6c2f  call rax
00007e4ecadd6c31  movaps xmm10, [rsp]
00007e4ecadd6c36  add rsp, 0x30
00007e4ecadd6c3a  vmovaps xmm0, [rsp]
00007e4ecadd6c3f  vmovaps xmm1, [rsp+0x10]
00007e4ecadd6c45  vmovaps xmm2, [rsp+0x20]
00007e4ecadd6c4b  vmovaps xmm3, [rsp+0x30]
00007e4ecadd6c51  vmovaps xmm4, [rsp+0x40]
00007e4ecadd6c57  vmovaps xmm5, [rsp+0x50]
00007e4ecadd6c5d  vmovaps xmm6, [rsp+0x60]
00007e4ecadd6c63  vmovaps xmm7, [rsp+0x70]
00007e4ecadd6c69  vmovaps xmm8, [rsp+0x80]
00007e4ecadd6c72  vmovaps xmm9, [rsp+0x90]
00007e4ecadd6c7b  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd6c84  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd6c8d  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd6c96  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd6c9f  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd6ca8  add rsp, 0xF0
00007e4ecadd6caf  pop r11
00007e4ecadd6cb1  pop r10
00007e4ecadd6cb3  pop r9
00007e4ecadd6cb5  pop r8
00007e4ecadd6cb7  pop rsi
00007e4ecadd6cb8  pop rdi
00007e4ecadd6cb9  pop rdx
00007e4ecadd6cba  pop rcx
00007e4ecadd6cbb  pop rax
00007e4ecadd6cbc  add rsp, 0x08
00007e4ecadd6cc0  jmp 0x00007E4ECADD5A06
00007e4ecadd6cc5  sub rsp, 0x08
00007e4ecadd6cc9  push rax
00007e4ecadd6cca  push rcx
00007e4ecadd6ccb  push rdx
00007e4ecadd6ccc  push rdi
00007e4ecadd6ccd  push rsi
00007e4ecadd6cce  push r8
00007e4ecadd6cd0  push r9
00007e4ecadd6cd2  push r10
00007e4ecadd6cd4  push r11
00007e4ecadd6cd6  sub rsp, 0xF0
00007e4ecadd6cdd  vmovaps [rsp], xmm0
00007e4ecadd6ce2  vmovaps [rsp+0x10], xmm1
00007e4ecadd6ce8  vmovaps [rsp+0x20], xmm2
00007e4ecadd6cee  vmovaps [rsp+0x30], xmm3
00007e4ecadd6cf4  vmovaps [rsp+0x40], xmm4
00007e4ecadd6cfa  vmovaps [rsp+0x50], xmm5
00007e4ecadd6d00  vmovaps [rsp+0x60], xmm7
00007e4ecadd6d06  vmovaps [rsp+0x70], xmm8
00007e4ecadd6d0c  vmovaps [rsp+0x80], xmm9
00007e4ecadd6d15  vmovaps [rsp+0x90], xmm10
00007e4ecadd6d1e  vmovaps [rsp+0xA0], xmm11
00007e4ecadd6d27  vmovaps [rsp+0xB0], xmm12
00007e4ecadd6d30  vmovaps [rsp+0xC0], xmm13
00007e4ecadd6d39  vmovaps [rsp+0xD0], xmm14
00007e4ecadd6d42  vmovaps [rsp+0xE0], xmm15
00007e4ecadd6d4b  sub rsp, 0x30
00007e4ecadd6d4f  movaps [rsp], xmm6
00007e4ecadd6d53  movaps [rsp+0x10], xmm12
00007e4ecadd6d59  movaps [rsp+0x20], xmm11
00007e4ecadd6d5f  lea rdi, [rsp]
00007e4ecadd6d63  mov esi, 0x00
00007e4ecadd6d68  mov rax, 0x5784BC1F5530
00007e4ecadd6d72  call rax
00007e4ecadd6d74  movaps xmm6, [rsp]
00007e4ecadd6d78  add rsp, 0x30
00007e4ecadd6d7c  vmovaps xmm0, [rsp]
00007e4ecadd6d81  vmovaps xmm1, [rsp+0x10]
00007e4ecadd6d87  vmovaps xmm2, [rsp+0x20]
00007e4ecadd6d8d  vmovaps xmm3, [rsp+0x30]
00007e4ecadd6d93  vmovaps xmm4, [rsp+0x40]
00007e4ecadd6d99  vmovaps xmm5, [rsp+0x50]
00007e4ecadd6d9f  vmovaps xmm7, [rsp+0x60]
00007e4ecadd6da5  vmovaps xmm8, [rsp+0x70]
00007e4ecadd6dab  vmovaps xmm9, [rsp+0x80]
00007e4ecadd6db4  vmovaps xmm10, [rsp+0x90]
00007e4ecadd6dbd  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd6dc6  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd6dcf  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd6dd8  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd6de1  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd6dea  add rsp, 0xF0
00007e4ecadd6df1  pop r11
00007e4ecadd6df3  pop r10
00007e4ecadd6df5  pop r9
00007e4ecadd6df7  pop r8
00007e4ecadd6df9  pop rsi
00007e4ecadd6dfa  pop rdi
00007e4ecadd6dfb  pop rdx
00007e4ecadd6dfc  pop rcx
00007e4ecadd6dfd  pop rax
00007e4ecadd6dfe  add rsp, 0x08
00007e4ecadd6e02  jmp 0x00007E4ECADD5A27
00007e4ecadd6e07  sub rsp, 0x08
00007e4ecadd6e0b  push rax
00007e4ecadd6e0c  push rcx
00007e4ecadd6e0d  push rdx
00007e4ecadd6e0e  push rdi
00007e4ecadd6e0f  push rsi
00007e4ecadd6e10  push r8
00007e4ecadd6e12  push r9
00007e4ecadd6e14  push r10
00007e4ecadd6e16  push r11
00007e4ecadd6e18  sub rsp, 0xF0
00007e4ecadd6e1f  vmovaps [rsp], xmm0
00007e4ecadd6e24  vmovaps [rsp+0x10], xmm1
00007e4ecadd6e2a  vmovaps [rsp+0x20], xmm2
00007e4ecadd6e30  vmovaps [rsp+0x30], xmm4
00007e4ecadd6e36  vmovaps [rsp+0x40], xmm5
00007e4ecadd6e3c  vmovaps [rsp+0x50], xmm6
00007e4ecadd6e42  vmovaps [rsp+0x60], xmm7
00007e4ecadd6e48  vmovaps [rsp+0x70], xmm8
00007e4ecadd6e4e  vmovaps [rsp+0x80], xmm9
00007e4ecadd6e57  vmovaps [rsp+0x90], xmm10
00007e4ecadd6e60  vmovaps [rsp+0xA0], xmm11
00007e4ecadd6e69  vmovaps [rsp+0xB0], xmm12
00007e4ecadd6e72  vmovaps [rsp+0xC0], xmm13
00007e4ecadd6e7b  vmovaps [rsp+0xD0], xmm14
00007e4ecadd6e84  vmovaps [rsp+0xE0], xmm15
00007e4ecadd6e8d  sub rsp, 0x30
00007e4ecadd6e91  movaps [rsp], xmm3
00007e4ecadd6e95  movaps [rsp+0x10], xmm5
00007e4ecadd6e9a  movaps [rsp+0x20], xmm4
00007e4ecadd6e9f  lea rdi, [rsp]
00007e4ecadd6ea3  mov esi, 0x00
00007e4ecadd6ea8  mov rax, 0x5784BC1F5530
00007e4ecadd6eb2  call rax
00007e4ecadd6eb4  movaps xmm3, [rsp]
00007e4ecadd6eb8  add rsp, 0x30
00007e4ecadd6ebc  vmovaps xmm0, [rsp]
00007e4ecadd6ec1  vmovaps xmm1, [rsp+0x10]
00007e4ecadd6ec7  vmovaps xmm2, [rsp+0x20]
00007e4ecadd6ecd  vmovaps xmm4, [rsp+0x30]
00007e4ecadd6ed3  vmovaps xmm5, [rsp+0x40]
00007e4ecadd6ed9  vmovaps xmm6, [rsp+0x50]
00007e4ecadd6edf  vmovaps xmm7, [rsp+0x60]
00007e4ecadd6ee5  vmovaps xmm8, [rsp+0x70]
00007e4ecadd6eeb  vmovaps xmm9, [rsp+0x80]
00007e4ecadd6ef4  vmovaps xmm10, [rsp+0x90]
00007e4ecadd6efd  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd6f06  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd6f0f  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd6f18  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd6f21  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd6f2a  add rsp, 0xF0
00007e4ecadd6f31  pop r11
00007e4ecadd6f33  pop r10
00007e4ecadd6f35  pop r9
00007e4ecadd6f37  pop r8
00007e4ecadd6f39  pop rsi
00007e4ecadd6f3a  pop rdi
00007e4ecadd6f3b  pop rdx
00007e4ecadd6f3c  pop rcx
00007e4ecadd6f3d  pop rax
00007e4ecadd6f3e  add rsp, 0x08
00007e4ecadd6f42  jmp 0x00007E4ECADD5A88
00007e4ecadd6f47  sub rsp, 0x08
00007e4ecadd6f4b  push rax
00007e4ecadd6f4c  push rcx
00007e4ecadd6f4d  push rdx
00007e4ecadd6f4e  push rdi
00007e4ecadd6f4f  push rsi
00007e4ecadd6f50  push r8
00007e4ecadd6f52  push r9
00007e4ecadd6f54  push r10
00007e4ecadd6f56  push r11
00007e4ecadd6f58  sub rsp, 0xF0
00007e4ecadd6f5f  vmovaps [rsp], xmm0
00007e4ecadd6f64  vmovaps [rsp+0x10], xmm1
00007e4ecadd6f6a  vmovaps [rsp+0x20], xmm2
00007e4ecadd6f70  vmovaps [rsp+0x30], xmm3
00007e4ecadd6f76  vmovaps [rsp+0x40], xmm4
00007e4ecadd6f7c  vmovaps [rsp+0x50], xmm6
00007e4ecadd6f82  vmovaps [rsp+0x60], xmm7
00007e4ecadd6f88  vmovaps [rsp+0x70], xmm8
00007e4ecadd6f8e  vmovaps [rsp+0x80], xmm9
00007e4ecadd6f97  vmovaps [rsp+0x90], xmm10
00007e4ecadd6fa0  vmovaps [rsp+0xA0], xmm11
00007e4ecadd6fa9  vmovaps [rsp+0xB0], xmm12
00007e4ecadd6fb2  vmovaps [rsp+0xC0], xmm13
00007e4ecadd6fbb  vmovaps [rsp+0xD0], xmm14
00007e4ecadd6fc4  vmovaps [rsp+0xE0], xmm15
00007e4ecadd6fcd  sub rsp, 0x30
00007e4ecadd6fd1  movaps [rsp], xmm5
00007e4ecadd6fd5  movaps [rsp+0x10], xmm8
00007e4ecadd6fdb  movaps [rsp+0x20], xmm15
00007e4ecadd6fe1  lea rdi, [rsp]
00007e4ecadd6fe5  mov esi, 0x00
00007e4ecadd6fea  mov rax, 0x5784BC1F5530
00007e4ecadd6ff4  call rax
00007e4ecadd6ff6  movaps xmm5, [rsp]
00007e4ecadd6ffa  add rsp, 0x30
00007e4ecadd6ffe  vmovaps xmm0, [rsp]
00007e4ecadd7003  vmovaps xmm1, [rsp+0x10]
00007e4ecadd7009  vmovaps xmm2, [rsp+0x20]
00007e4ecadd700f  vmovaps xmm3, [rsp+0x30]
00007e4ecadd7015  vmovaps xmm4, [rsp+0x40]
00007e4ecadd701b  vmovaps xmm6, [rsp+0x50]
00007e4ecadd7021  vmovaps xmm7, [rsp+0x60]
00007e4ecadd7027  vmovaps xmm8, [rsp+0x70]
00007e4ecadd702d  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7036  vmovaps xmm10, [rsp+0x90]
00007e4ecadd703f  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd7048  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd7051  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd705a  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd7063  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd706c  add rsp, 0xF0
00007e4ecadd7073  pop r11
00007e4ecadd7075  pop r10
00007e4ecadd7077  pop r9
00007e4ecadd7079  pop r8
00007e4ecadd707b  pop rsi
00007e4ecadd707c  pop rdi
00007e4ecadd707d  pop rdx
00007e4ecadd707e  pop rcx
00007e4ecadd707f  pop rax
00007e4ecadd7080  add rsp, 0x08
00007e4ecadd7084  jmp 0x00007E4ECADD5AC0
00007e4ecadd7089  sub rsp, 0x08
00007e4ecadd708d  push rax
00007e4ecadd708e  push rcx
00007e4ecadd708f  push rdx
00007e4ecadd7090  push rdi
00007e4ecadd7091  push rsi
00007e4ecadd7092  push r8
00007e4ecadd7094  push r9
00007e4ecadd7096  push r10
00007e4ecadd7098  push r11
00007e4ecadd709a  sub rsp, 0xF0
00007e4ecadd70a1  vmovaps [rsp], xmm0
00007e4ecadd70a6  vmovaps [rsp+0x10], xmm1
00007e4ecadd70ac  vmovaps [rsp+0x20], xmm2
00007e4ecadd70b2  vmovaps [rsp+0x30], xmm3
00007e4ecadd70b8  vmovaps [rsp+0x40], xmm5
00007e4ecadd70be  vmovaps [rsp+0x50], xmm6
00007e4ecadd70c4  vmovaps [rsp+0x60], xmm7
00007e4ecadd70ca  vmovaps [rsp+0x70], xmm8
00007e4ecadd70d0  vmovaps [rsp+0x80], xmm9
00007e4ecadd70d9  vmovaps [rsp+0x90], xmm10
00007e4ecadd70e2  vmovaps [rsp+0xA0], xmm11
00007e4ecadd70eb  vmovaps [rsp+0xB0], xmm12
00007e4ecadd70f4  vmovaps [rsp+0xC0], xmm13
00007e4ecadd70fd  vmovaps [rsp+0xD0], xmm14
00007e4ecadd7106  vmovaps [rsp+0xE0], xmm15
00007e4ecadd710f  sub rsp, 0x30
00007e4ecadd7113  movaps [rsp], xmm4
00007e4ecadd7117  movaps [rsp+0x10], xmm9
00007e4ecadd711d  movaps [rsp+0x20], xmm8
00007e4ecadd7123  lea rdi, [rsp]
00007e4ecadd7127  mov esi, 0x00
00007e4ecadd712c  mov rax, 0x5784BC1F5530
00007e4ecadd7136  call rax
00007e4ecadd7138  movaps xmm4, [rsp]
00007e4ecadd713c  add rsp, 0x30
00007e4ecadd7140  vmovaps xmm0, [rsp]
00007e4ecadd7145  vmovaps xmm1, [rsp+0x10]
00007e4ecadd714b  vmovaps xmm2, [rsp+0x20]
00007e4ecadd7151  vmovaps xmm3, [rsp+0x30]
00007e4ecadd7157  vmovaps xmm5, [rsp+0x40]
00007e4ecadd715d  vmovaps xmm6, [rsp+0x50]
00007e4ecadd7163  vmovaps xmm7, [rsp+0x60]
00007e4ecadd7169  vmovaps xmm8, [rsp+0x70]
00007e4ecadd716f  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7178  vmovaps xmm10, [rsp+0x90]
00007e4ecadd7181  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd718a  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd7193  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd719c  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd71a5  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd71ae  add rsp, 0xF0
00007e4ecadd71b5  pop r11
00007e4ecadd71b7  pop r10
00007e4ecadd71b9  pop r9
00007e4ecadd71bb  pop r8
00007e4ecadd71bd  pop rsi
00007e4ecadd71be  pop rdi
00007e4ecadd71bf  pop rdx
00007e4ecadd71c0  pop rcx
00007e4ecadd71c1  pop rax
00007e4ecadd71c2  add rsp, 0x08
00007e4ecadd71c6  jmp 0x00007E4ECADD5AE1
00007e4ecadd71cb  sub rsp, 0x08
00007e4ecadd71cf  push rax
00007e4ecadd71d0  push rcx
00007e4ecadd71d1  push rdx
00007e4ecadd71d2  push rdi
00007e4ecadd71d3  push rsi
00007e4ecadd71d4  push r8
00007e4ecadd71d6  push r9
00007e4ecadd71d8  push r10
00007e4ecadd71da  push r11
00007e4ecadd71dc  sub rsp, 0xF0
00007e4ecadd71e3  vmovaps [rsp], xmm0
00007e4ecadd71e8  vmovaps [rsp+0x10], xmm1
00007e4ecadd71ee  vmovaps [rsp+0x20], xmm2
00007e4ecadd71f4  vmovaps [rsp+0x30], xmm3
00007e4ecadd71fa  vmovaps [rsp+0x40], xmm4
00007e4ecadd7200  vmovaps [rsp+0x50], xmm5
00007e4ecadd7206  vmovaps [rsp+0x60], xmm6
00007e4ecadd720c  vmovaps [rsp+0x70], xmm7
00007e4ecadd7212  vmovaps [rsp+0x80], xmm8
00007e4ecadd721b  vmovaps [rsp+0x90], xmm10
00007e4ecadd7224  vmovaps [rsp+0xA0], xmm11
00007e4ecadd722d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd7236  vmovaps [rsp+0xC0], xmm13
00007e4ecadd723f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd7248  vmovaps [rsp+0xE0], xmm15
00007e4ecadd7251  sub rsp, 0x30
00007e4ecadd7255  movaps [rsp], xmm9
00007e4ecadd725a  movaps [rsp+0x10], xmm10
00007e4ecadd7260  movaps [rsp+0x20], xmm8
00007e4ecadd7266  lea rdi, [rsp]
00007e4ecadd726a  mov esi, 0x00
00007e4ecadd726f  mov rax, 0x5784BC1F5530
00007e4ecadd7279  call rax
00007e4ecadd727b  movaps xmm9, [rsp]
00007e4ecadd7280  add rsp, 0x30
00007e4ecadd7284  vmovaps xmm0, [rsp]
00007e4ecadd7289  vmovaps xmm1, [rsp+0x10]
00007e4ecadd728f  vmovaps xmm2, [rsp+0x20]
00007e4ecadd7295  vmovaps xmm3, [rsp+0x30]
00007e4ecadd729b  vmovaps xmm4, [rsp+0x40]
00007e4ecadd72a1  vmovaps xmm5, [rsp+0x50]
00007e4ecadd72a7  vmovaps xmm6, [rsp+0x60]
00007e4ecadd72ad  vmovaps xmm7, [rsp+0x70]
00007e4ecadd72b3  vmovaps xmm8, [rsp+0x80]
00007e4ecadd72bc  vmovaps xmm10, [rsp+0x90]
00007e4ecadd72c5  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd72ce  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd72d7  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd72e0  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd72e9  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd72f2  add rsp, 0xF0
00007e4ecadd72f9  pop r11
00007e4ecadd72fb  pop r10
00007e4ecadd72fd  pop r9
00007e4ecadd72ff  pop r8
00007e4ecadd7301  pop rsi
00007e4ecadd7302  pop rdi
00007e4ecadd7303  pop rdx
00007e4ecadd7304  pop rcx
00007e4ecadd7305  pop rax
00007e4ecadd7306  add rsp, 0x08
00007e4ecadd730a  jmp 0x00007E4ECADD5AFB
00007e4ecadd730f  call 0x00007E4ECACD64F0
00007e4ecadd7314  jmp 0x00007E4ECADD5C15
00007e4ecadd7319  call 0x00007E4ECACD64F0
00007e4ecadd731e  jmp 0x00007E4ECADD5C2B
00007e4ecadd7323  sub rsp, 0x08
00007e4ecadd7327  push rax
00007e4ecadd7328  push rcx
00007e4ecadd7329  push rdx
00007e4ecadd732a  push rdi
00007e4ecadd732b  push rsi
00007e4ecadd732c  push r8
00007e4ecadd732e  push r9
00007e4ecadd7330  push r10
00007e4ecadd7332  push r11
00007e4ecadd7334  sub rsp, 0xF0
00007e4ecadd733b  vmovaps [rsp], xmm0
00007e4ecadd7340  vmovaps [rsp+0x10], xmm2
00007e4ecadd7346  vmovaps [rsp+0x20], xmm3
00007e4ecadd734c  vmovaps [rsp+0x30], xmm4
00007e4ecadd7352  vmovaps [rsp+0x40], xmm5
00007e4ecadd7358  vmovaps [rsp+0x50], xmm6
00007e4ecadd735e  vmovaps [rsp+0x60], xmm7
00007e4ecadd7364  vmovaps [rsp+0x70], xmm8
00007e4ecadd736a  vmovaps [rsp+0x80], xmm9
00007e4ecadd7373  vmovaps [rsp+0x90], xmm10
00007e4ecadd737c  vmovaps [rsp+0xA0], xmm11
00007e4ecadd7385  vmovaps [rsp+0xB0], xmm12
00007e4ecadd738e  vmovaps [rsp+0xC0], xmm13
00007e4ecadd7397  vmovaps [rsp+0xD0], xmm14
00007e4ecadd73a0  vmovaps [rsp+0xE0], xmm15
00007e4ecadd73a9  sub rsp, 0x30
00007e4ecadd73ad  movaps [rsp], xmm1
00007e4ecadd73b1  movaps [rsp+0x10], xmm6
00007e4ecadd73b6  movaps [rsp+0x20], xmm15
00007e4ecadd73bc  lea rdi, [rsp]
00007e4ecadd73c0  mov esi, 0x00
00007e4ecadd73c5  mov rax, 0x5784BC1F5530
00007e4ecadd73cf  call rax
00007e4ecadd73d1  movaps xmm1, [rsp]
00007e4ecadd73d5  add rsp, 0x30
00007e4ecadd73d9  vmovaps xmm0, [rsp]
00007e4ecadd73de  vmovaps xmm2, [rsp+0x10]
00007e4ecadd73e4  vmovaps xmm3, [rsp+0x20]
00007e4ecadd73ea  vmovaps xmm4, [rsp+0x30]
00007e4ecadd73f0  vmovaps xmm5, [rsp+0x40]
00007e4ecadd73f6  vmovaps xmm6, [rsp+0x50]
00007e4ecadd73fc  vmovaps xmm7, [rsp+0x60]
00007e4ecadd7402  vmovaps xmm8, [rsp+0x70]
00007e4ecadd7408  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7411  vmovaps xmm10, [rsp+0x90]
00007e4ecadd741a  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd7423  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd742c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd7435  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd743e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7447  add rsp, 0xF0
00007e4ecadd744e  pop r11
00007e4ecadd7450  pop r10
00007e4ecadd7452  pop r9
00007e4ecadd7454  pop r8
00007e4ecadd7456  pop rsi
00007e4ecadd7457  pop rdi
00007e4ecadd7458  pop rdx
00007e4ecadd7459  pop rcx
00007e4ecadd745a  pop rax
00007e4ecadd745b  add rsp, 0x08
00007e4ecadd745f  jmp 0x00007E4ECADD5C68
00007e4ecadd7464  call 0x00007E4ECACE5820
00007e4ecadd7469  jmp 0x00007E4ECADD5C75
00007e4ecadd746e  sub rsp, 0x08
00007e4ecadd7472  push rax
00007e4ecadd7473  push rcx
00007e4ecadd7474  push rdx
00007e4ecadd7475  push rdi
00007e4ecadd7476  push rsi
00007e4ecadd7477  push r8
00007e4ecadd7479  push r9
00007e4ecadd747b  push r10
00007e4ecadd747d  push r11
00007e4ecadd747f  sub rsp, 0xF0
00007e4ecadd7486  vmovaps [rsp], xmm0
00007e4ecadd748b  vmovaps [rsp+0x10], xmm1
00007e4ecadd7491  vmovaps [rsp+0x20], xmm2
00007e4ecadd7497  vmovaps [rsp+0x30], xmm3
00007e4ecadd749d  vmovaps [rsp+0x40], xmm4
00007e4ecadd74a3  vmovaps [rsp+0x50], xmm5
00007e4ecadd74a9  vmovaps [rsp+0x60], xmm6
00007e4ecadd74af  vmovaps [rsp+0x70], xmm7
00007e4ecadd74b5  vmovaps [rsp+0x80], xmm8
00007e4ecadd74be  vmovaps [rsp+0x90], xmm9
00007e4ecadd74c7  vmovaps [rsp+0xA0], xmm10
00007e4ecadd74d0  vmovaps [rsp+0xB0], xmm11
00007e4ecadd74d9  vmovaps [rsp+0xC0], xmm12
00007e4ecadd74e2  vmovaps [rsp+0xD0], xmm13
00007e4ecadd74eb  vmovaps [rsp+0xE0], xmm15
00007e4ecadd74f4  sub rsp, 0x30
00007e4ecadd74f8  movaps [rsp], xmm14
00007e4ecadd74fd  movaps [rsp+0x10], xmm4
00007e4ecadd7502  movaps [rsp+0x20], xmm3
00007e4ecadd7507  lea rdi, [rsp]
00007e4ecadd750b  mov esi, 0x00
00007e4ecadd7510  mov rax, 0x5784BC1F5530
00007e4ecadd751a  call rax
00007e4ecadd751c  movaps xmm14, [rsp]
00007e4ecadd7521  add rsp, 0x30
00007e4ecadd7525  vmovaps xmm0, [rsp]
00007e4ecadd752a  vmovaps xmm1, [rsp+0x10]
00007e4ecadd7530  vmovaps xmm2, [rsp+0x20]
00007e4ecadd7536  vmovaps xmm3, [rsp+0x30]
00007e4ecadd753c  vmovaps xmm4, [rsp+0x40]
00007e4ecadd7542  vmovaps xmm5, [rsp+0x50]
00007e4ecadd7548  vmovaps xmm6, [rsp+0x60]
00007e4ecadd754e  vmovaps xmm7, [rsp+0x70]
00007e4ecadd7554  vmovaps xmm8, [rsp+0x80]
00007e4ecadd755d  vmovaps xmm9, [rsp+0x90]
00007e4ecadd7566  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd756f  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd7578  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd7581  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd758a  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7593  add rsp, 0xF0
00007e4ecadd759a  pop r11
00007e4ecadd759c  pop r10
00007e4ecadd759e  pop r9
00007e4ecadd75a0  pop r8
00007e4ecadd75a2  pop rsi
00007e4ecadd75a3  pop rdi
00007e4ecadd75a4  pop rdx
00007e4ecadd75a5  pop rcx
00007e4ecadd75a6  pop rax
00007e4ecadd75a7  add rsp, 0x08
00007e4ecadd75ab  jmp 0x00007E4ECADD5C8F
00007e4ecadd75b0  sub rsp, 0x08
00007e4ecadd75b4  push rax
00007e4ecadd75b5  push rcx
00007e4ecadd75b6  push rdx
00007e4ecadd75b7  push rdi
00007e4ecadd75b8  push rsi
00007e4ecadd75b9  push r8
00007e4ecadd75bb  push r9
00007e4ecadd75bd  push r10
00007e4ecadd75bf  push r11
00007e4ecadd75c1  sub rsp, 0xF0
00007e4ecadd75c8  vmovaps [rsp], xmm0
00007e4ecadd75cd  vmovaps [rsp+0x10], xmm1
00007e4ecadd75d3  vmovaps [rsp+0x20], xmm2
00007e4ecadd75d9  vmovaps [rsp+0x30], xmm3
00007e4ecadd75df  vmovaps [rsp+0x40], xmm4
00007e4ecadd75e5  vmovaps [rsp+0x50], xmm5
00007e4ecadd75eb  vmovaps [rsp+0x60], xmm7
00007e4ecadd75f1  vmovaps [rsp+0x70], xmm8
00007e4ecadd75f7  vmovaps [rsp+0x80], xmm9
00007e4ecadd7600  vmovaps [rsp+0x90], xmm10
00007e4ecadd7609  vmovaps [rsp+0xA0], xmm11
00007e4ecadd7612  vmovaps [rsp+0xB0], xmm12
00007e4ecadd761b  vmovaps [rsp+0xC0], xmm13
00007e4ecadd7624  vmovaps [rsp+0xD0], xmm14
00007e4ecadd762d  vmovaps [rsp+0xE0], xmm15
00007e4ecadd7636  sub rsp, 0x30
00007e4ecadd763a  movaps [rsp], xmm6
00007e4ecadd763e  movaps [rsp+0x10], xmm9
00007e4ecadd7644  movaps [rsp+0x20], xmm7
00007e4ecadd7649  lea rdi, [rsp]
00007e4ecadd764d  mov esi, 0x00
00007e4ecadd7652  mov rax, 0x5784BC1F5530
00007e4ecadd765c  call rax
00007e4ecadd765e  movaps xmm6, [rsp]
00007e4ecadd7662  add rsp, 0x30
00007e4ecadd7666  vmovaps xmm0, [rsp]
00007e4ecadd766b  vmovaps xmm1, [rsp+0x10]
00007e4ecadd7671  vmovaps xmm2, [rsp+0x20]
00007e4ecadd7677  vmovaps xmm3, [rsp+0x30]
00007e4ecadd767d  vmovaps xmm4, [rsp+0x40]
00007e4ecadd7683  vmovaps xmm5, [rsp+0x50]
00007e4ecadd7689  vmovaps xmm7, [rsp+0x60]
00007e4ecadd768f  vmovaps xmm8, [rsp+0x70]
00007e4ecadd7695  vmovaps xmm9, [rsp+0x80]
00007e4ecadd769e  vmovaps xmm10, [rsp+0x90]
00007e4ecadd76a7  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd76b0  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd76b9  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd76c2  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd76cb  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd76d4  add rsp, 0xF0
00007e4ecadd76db  pop r11
00007e4ecadd76dd  pop r10
00007e4ecadd76df  pop r9
00007e4ecadd76e1  pop r8
00007e4ecadd76e3  pop rsi
00007e4ecadd76e4  pop rdi
00007e4ecadd76e5  pop rdx
00007e4ecadd76e6  pop rcx
00007e4ecadd76e7  pop rax
00007e4ecadd76e8  add rsp, 0x08
00007e4ecadd76ec  jmp 0x00007E4ECADD5CA7
00007e4ecadd76f1  sub rsp, 0x08
00007e4ecadd76f5  push rax
00007e4ecadd76f6  push rcx
00007e4ecadd76f7  push rdx
00007e4ecadd76f8  push rdi
00007e4ecadd76f9  push rsi
00007e4ecadd76fa  push r8
00007e4ecadd76fc  push r9
00007e4ecadd76fe  push r10
00007e4ecadd7700  push r11
00007e4ecadd7702  sub rsp, 0xF0
00007e4ecadd7709  vmovaps [rsp], xmm0
00007e4ecadd770e  vmovaps [rsp+0x10], xmm1
00007e4ecadd7714  vmovaps [rsp+0x20], xmm2
00007e4ecadd771a  vmovaps [rsp+0x30], xmm3
00007e4ecadd7720  vmovaps [rsp+0x40], xmm4
00007e4ecadd7726  vmovaps [rsp+0x50], xmm5
00007e4ecadd772c  vmovaps [rsp+0x60], xmm6
00007e4ecadd7732  vmovaps [rsp+0x70], xmm8
00007e4ecadd7738  vmovaps [rsp+0x80], xmm9
00007e4ecadd7741  vmovaps [rsp+0x90], xmm10
00007e4ecadd774a  vmovaps [rsp+0xA0], xmm11
00007e4ecadd7753  vmovaps [rsp+0xB0], xmm12
00007e4ecadd775c  vmovaps [rsp+0xC0], xmm13
00007e4ecadd7765  vmovaps [rsp+0xD0], xmm14
00007e4ecadd776e  vmovaps [rsp+0xE0], xmm15
00007e4ecadd7777  sub rsp, 0x30
00007e4ecadd777b  movaps [rsp], xmm7
00007e4ecadd777f  movaps [rsp+0x10], xmm4
00007e4ecadd7784  movaps [rsp+0x20], xmm9
00007e4ecadd778a  lea rdi, [rsp]
00007e4ecadd778e  mov esi, 0x00
00007e4ecadd7793  mov rax, 0x5784BC1F5530
00007e4ecadd779d  call rax
00007e4ecadd779f  movaps xmm7, [rsp]
00007e4ecadd77a3  add rsp, 0x30
00007e4ecadd77a7  vmovaps xmm0, [rsp]
00007e4ecadd77ac  vmovaps xmm1, [rsp+0x10]
00007e4ecadd77b2  vmovaps xmm2, [rsp+0x20]
00007e4ecadd77b8  vmovaps xmm3, [rsp+0x30]
00007e4ecadd77be  vmovaps xmm4, [rsp+0x40]
00007e4ecadd77c4  vmovaps xmm5, [rsp+0x50]
00007e4ecadd77ca  vmovaps xmm6, [rsp+0x60]
00007e4ecadd77d0  vmovaps xmm8, [rsp+0x70]
00007e4ecadd77d6  vmovaps xmm9, [rsp+0x80]
00007e4ecadd77df  vmovaps xmm10, [rsp+0x90]
00007e4ecadd77e8  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd77f1  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd77fa  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd7803  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd780c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7815  add rsp, 0xF0
00007e4ecadd781c  pop r11
00007e4ecadd781e  pop r10
00007e4ecadd7820  pop r9
00007e4ecadd7822  pop r8
00007e4ecadd7824  pop rsi
00007e4ecadd7825  pop rdi
00007e4ecadd7826  pop rdx
00007e4ecadd7827  pop rcx
00007e4ecadd7828  pop rax
00007e4ecadd7829  add rsp, 0x08
00007e4ecadd782d  jmp 0x00007E4ECADD5CD4
00007e4ecadd7832  sub rsp, 0x08
00007e4ecadd7836  push rax
00007e4ecadd7837  push rcx
00007e4ecadd7838  push rdx
00007e4ecadd7839  push rdi
00007e4ecadd783a  push rsi
00007e4ecadd783b  push r8
00007e4ecadd783d  push r9
00007e4ecadd783f  push r10
00007e4ecadd7841  push r11
00007e4ecadd7843  sub rsp, 0xF0
00007e4ecadd784a  vmovaps [rsp], xmm0
00007e4ecadd784f  vmovaps [rsp+0x10], xmm1
00007e4ecadd7855  vmovaps [rsp+0x20], xmm2
00007e4ecadd785b  vmovaps [rsp+0x30], xmm3
00007e4ecadd7861  vmovaps [rsp+0x40], xmm5
00007e4ecadd7867  vmovaps [rsp+0x50], xmm6
00007e4ecadd786d  vmovaps [rsp+0x60], xmm7
00007e4ecadd7873  vmovaps [rsp+0x70], xmm8
00007e4ecadd7879  vmovaps [rsp+0x80], xmm9
00007e4ecadd7882  vmovaps [rsp+0x90], xmm10
00007e4ecadd788b  vmovaps [rsp+0xA0], xmm11
00007e4ecadd7894  vmovaps [rsp+0xB0], xmm12
00007e4ecadd789d  vmovaps [rsp+0xC0], xmm13
00007e4ecadd78a6  vmovaps [rsp+0xD0], xmm14
00007e4ecadd78af  vmovaps [rsp+0xE0], xmm15
00007e4ecadd78b8  sub rsp, 0x30
00007e4ecadd78bc  movaps [rsp], xmm4
00007e4ecadd78c0  movaps [rsp+0x10], xmm15
00007e4ecadd78c6  movaps [rsp+0x20], xmm9
00007e4ecadd78cc  lea rdi, [rsp]
00007e4ecadd78d0  mov esi, 0x00
00007e4ecadd78d5  mov rax, 0x5784BC1F5530
00007e4ecadd78df  call rax
00007e4ecadd78e1  movaps xmm4, [rsp]
00007e4ecadd78e5  add rsp, 0x30
00007e4ecadd78e9  vmovaps xmm0, [rsp]
00007e4ecadd78ee  vmovaps xmm1, [rsp+0x10]
00007e4ecadd78f4  vmovaps xmm2, [rsp+0x20]
00007e4ecadd78fa  vmovaps xmm3, [rsp+0x30]
00007e4ecadd7900  vmovaps xmm5, [rsp+0x40]
00007e4ecadd7906  vmovaps xmm6, [rsp+0x50]
00007e4ecadd790c  vmovaps xmm7, [rsp+0x60]
00007e4ecadd7912  vmovaps xmm8, [rsp+0x70]
00007e4ecadd7918  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7921  vmovaps xmm10, [rsp+0x90]
00007e4ecadd792a  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd7933  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd793c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd7945  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd794e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7957  add rsp, 0xF0
00007e4ecadd795e  pop r11
00007e4ecadd7960  pop r10
00007e4ecadd7962  pop r9
00007e4ecadd7964  pop r8
00007e4ecadd7966  pop rsi
00007e4ecadd7967  pop rdi
00007e4ecadd7968  pop rdx
00007e4ecadd7969  pop rcx
00007e4ecadd796a  pop rax
00007e4ecadd796b  add rsp, 0x08
00007e4ecadd796f  jmp 0x00007E4ECADD5CF9
00007e4ecadd7974  call 0x00007E4ECACE5820
00007e4ecadd7979  jmp 0x00007E4ECADD5D06
00007e4ecadd797e  sub rsp, 0x08
00007e4ecadd7982  push rax
00007e4ecadd7983  push rcx
00007e4ecadd7984  push rdx
00007e4ecadd7985  push rdi
00007e4ecadd7986  push rsi
00007e4ecadd7987  push r8
00007e4ecadd7989  push r9
00007e4ecadd798b  push r10
00007e4ecadd798d  push r11
00007e4ecadd798f  sub rsp, 0xF0
00007e4ecadd7996  vmovaps [rsp], xmm0
00007e4ecadd799b  vmovaps [rsp+0x10], xmm1
00007e4ecadd79a1  vmovaps [rsp+0x20], xmm2
00007e4ecadd79a7  vmovaps [rsp+0x30], xmm4
00007e4ecadd79ad  vmovaps [rsp+0x40], xmm5
00007e4ecadd79b3  vmovaps [rsp+0x50], xmm6
00007e4ecadd79b9  vmovaps [rsp+0x60], xmm7
00007e4ecadd79bf  vmovaps [rsp+0x70], xmm8
00007e4ecadd79c5  vmovaps [rsp+0x80], xmm9
00007e4ecadd79ce  vmovaps [rsp+0x90], xmm10
00007e4ecadd79d7  vmovaps [rsp+0xA0], xmm11
00007e4ecadd79e0  vmovaps [rsp+0xB0], xmm12
00007e4ecadd79e9  vmovaps [rsp+0xC0], xmm13
00007e4ecadd79f2  vmovaps [rsp+0xD0], xmm14
00007e4ecadd79fb  vmovaps [rsp+0xE0], xmm15
00007e4ecadd7a04  sub rsp, 0x30
00007e4ecadd7a08  movaps [rsp], xmm3
00007e4ecadd7a0c  movaps [rsp+0x10], xmm1
00007e4ecadd7a11  movaps [rsp+0x20], xmm9
00007e4ecadd7a17  lea rdi, [rsp]
00007e4ecadd7a1b  mov esi, 0x00
00007e4ecadd7a20  mov rax, 0x5784BC1F5530
00007e4ecadd7a2a  call rax
00007e4ecadd7a2c  movaps xmm3, [rsp]
00007e4ecadd7a30  add rsp, 0x30
00007e4ecadd7a34  vmovaps xmm0, [rsp]
00007e4ecadd7a39  vmovaps xmm1, [rsp+0x10]
00007e4ecadd7a3f  vmovaps xmm2, [rsp+0x20]
00007e4ecadd7a45  vmovaps xmm4, [rsp+0x30]
00007e4ecadd7a4b  vmovaps xmm5, [rsp+0x40]
00007e4ecadd7a51  vmovaps xmm6, [rsp+0x50]
00007e4ecadd7a57  vmovaps xmm7, [rsp+0x60]
00007e4ecadd7a5d  vmovaps xmm8, [rsp+0x70]
00007e4ecadd7a63  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7a6c  vmovaps xmm10, [rsp+0x90]
00007e4ecadd7a75  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd7a7e  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd7a87  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd7a90  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd7a99  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7aa2  add rsp, 0xF0
00007e4ecadd7aa9  pop r11
00007e4ecadd7aab  pop r10
00007e4ecadd7aad  pop r9
00007e4ecadd7aaf  pop r8
00007e4ecadd7ab1  pop rsi
00007e4ecadd7ab2  pop rdi
00007e4ecadd7ab3  pop rdx
00007e4ecadd7ab4  pop rcx
00007e4ecadd7ab5  pop rax
00007e4ecadd7ab6  add rsp, 0x08
00007e4ecadd7aba  jmp 0x00007E4ECADD5D43
00007e4ecadd7abf  sub rsp, 0x08
00007e4ecadd7ac3  push rax
00007e4ecadd7ac4  push rcx
00007e4ecadd7ac5  push rdx
00007e4ecadd7ac6  push rdi
00007e4ecadd7ac7  push rsi
00007e4ecadd7ac8  push r8
00007e4ecadd7aca  push r9
00007e4ecadd7acc  push r10
00007e4ecadd7ace  push r11
00007e4ecadd7ad0  sub rsp, 0xF0
00007e4ecadd7ad7  vmovaps [rsp], xmm0
00007e4ecadd7adc  vmovaps [rsp+0x10], xmm2
00007e4ecadd7ae2  vmovaps [rsp+0x20], xmm3
00007e4ecadd7ae8  vmovaps [rsp+0x30], xmm4
00007e4ecadd7aee  vmovaps [rsp+0x40], xmm5
00007e4ecadd7af4  vmovaps [rsp+0x50], xmm6
00007e4ecadd7afa  vmovaps [rsp+0x60], xmm7
00007e4ecadd7b00  vmovaps [rsp+0x70], xmm8
00007e4ecadd7b06  vmovaps [rsp+0x80], xmm9
00007e4ecadd7b0f  vmovaps [rsp+0x90], xmm10
00007e4ecadd7b18  vmovaps [rsp+0xA0], xmm11
00007e4ecadd7b21  vmovaps [rsp+0xB0], xmm12
00007e4ecadd7b2a  vmovaps [rsp+0xC0], xmm13
00007e4ecadd7b33  vmovaps [rsp+0xD0], xmm14
00007e4ecadd7b3c  vmovaps [rsp+0xE0], xmm15
00007e4ecadd7b45  sub rsp, 0x30
00007e4ecadd7b49  movaps [rsp], xmm1
00007e4ecadd7b4d  movaps [rsp+0x10], xmm15
00007e4ecadd7b53  movaps [rsp+0x20], xmm9
00007e4ecadd7b59  lea rdi, [rsp]
00007e4ecadd7b5d  mov esi, 0x00
00007e4ecadd7b62  mov rax, 0x5784BC1F5530
00007e4ecadd7b6c  call rax
00007e4ecadd7b6e  movaps xmm1, [rsp]
00007e4ecadd7b72  add rsp, 0x30
00007e4ecadd7b76  vmovaps xmm0, [rsp]
00007e4ecadd7b7b  vmovaps xmm2, [rsp+0x10]
00007e4ecadd7b81  vmovaps xmm3, [rsp+0x20]
00007e4ecadd7b87  vmovaps xmm4, [rsp+0x30]
00007e4ecadd7b8d  vmovaps xmm5, [rsp+0x40]
00007e4ecadd7b93  vmovaps xmm6, [rsp+0x50]
00007e4ecadd7b99  vmovaps xmm7, [rsp+0x60]
00007e4ecadd7b9f  vmovaps xmm8, [rsp+0x70]
00007e4ecadd7ba5  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7bae  vmovaps xmm10, [rsp+0x90]
00007e4ecadd7bb7  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd7bc0  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd7bc9  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd7bd2  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd7bdb  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7be4  add rsp, 0xF0
00007e4ecadd7beb  pop r11
00007e4ecadd7bed  pop r10
00007e4ecadd7bef  pop r9
00007e4ecadd7bf1  pop r8
00007e4ecadd7bf3  pop rsi
00007e4ecadd7bf4  pop rdi
00007e4ecadd7bf5  pop rdx
00007e4ecadd7bf6  pop rcx
00007e4ecadd7bf7  pop rax
00007e4ecadd7bf8  add rsp, 0x08
00007e4ecadd7bfc  jmp 0x00007E4ECADD5DCB
00007e4ecadd7c01  call 0x00007E4ECACE5820
00007e4ecadd7c06  jmp 0x00007E4ECADD5DD8
00007e4ecadd7c0b  sub rsp, 0x08
00007e4ecadd7c0f  push rax
00007e4ecadd7c10  push rcx
00007e4ecadd7c11  push rdx
00007e4ecadd7c12  push rdi
00007e4ecadd7c13  push rsi
00007e4ecadd7c14  push r8
00007e4ecadd7c16  push r9
00007e4ecadd7c18  push r10
00007e4ecadd7c1a  push r11
00007e4ecadd7c1c  sub rsp, 0xF0
00007e4ecadd7c23  vmovaps [rsp], xmm0
00007e4ecadd7c28  vmovaps [rsp+0x10], xmm2
00007e4ecadd7c2e  vmovaps [rsp+0x20], xmm3
00007e4ecadd7c34  vmovaps [rsp+0x30], xmm4
00007e4ecadd7c3a  vmovaps [rsp+0x40], xmm5
00007e4ecadd7c40  vmovaps [rsp+0x50], xmm6
00007e4ecadd7c46  vmovaps [rsp+0x60], xmm7
00007e4ecadd7c4c  vmovaps [rsp+0x70], xmm8
00007e4ecadd7c52  vmovaps [rsp+0x80], xmm9
00007e4ecadd7c5b  vmovaps [rsp+0x90], xmm10
00007e4ecadd7c64  vmovaps [rsp+0xA0], xmm11
00007e4ecadd7c6d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd7c76  vmovaps [rsp+0xC0], xmm13
00007e4ecadd7c7f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd7c88  vmovaps [rsp+0xE0], xmm15
00007e4ecadd7c91  sub rsp, 0x30
00007e4ecadd7c95  movaps [rsp], xmm1
00007e4ecadd7c99  movaps [rsp+0x10], xmm5
00007e4ecadd7c9e  movaps [rsp+0x20], xmm7
00007e4ecadd7ca3  lea rdi, [rsp]
00007e4ecadd7ca7  mov esi, 0x00
00007e4ecadd7cac  mov rax, 0x5784BC1F5530
00007e4ecadd7cb6  call rax
00007e4ecadd7cb8  movaps xmm1, [rsp]
00007e4ecadd7cbc  add rsp, 0x30
00007e4ecadd7cc0  vmovaps xmm0, [rsp]
00007e4ecadd7cc5  vmovaps xmm2, [rsp+0x10]
00007e4ecadd7ccb  vmovaps xmm3, [rsp+0x20]
00007e4ecadd7cd1  vmovaps xmm4, [rsp+0x30]
00007e4ecadd7cd7  vmovaps xmm5, [rsp+0x40]
00007e4ecadd7cdd  vmovaps xmm6, [rsp+0x50]
00007e4ecadd7ce3  vmovaps xmm7, [rsp+0x60]
00007e4ecadd7ce9  vmovaps xmm8, [rsp+0x70]
00007e4ecadd7cef  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7cf8  vmovaps xmm10, [rsp+0x90]
00007e4ecadd7d01  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd7d0a  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd7d13  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd7d1c  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd7d25  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7d2e  add rsp, 0xF0
00007e4ecadd7d35  pop r11
00007e4ecadd7d37  pop r10
00007e4ecadd7d39  pop r9
00007e4ecadd7d3b  pop r8
00007e4ecadd7d3d  pop rsi
00007e4ecadd7d3e  pop rdi
00007e4ecadd7d3f  pop rdx
00007e4ecadd7d40  pop rcx
00007e4ecadd7d41  pop rax
00007e4ecadd7d42  add rsp, 0x08
00007e4ecadd7d46  jmp 0x00007E4ECADD5E7D
00007e4ecadd7d4b  sub rsp, 0x08
00007e4ecadd7d4f  push rax
00007e4ecadd7d50  push rcx
00007e4ecadd7d51  push rdx
00007e4ecadd7d52  push rdi
00007e4ecadd7d53  push rsi
00007e4ecadd7d54  push r8
00007e4ecadd7d56  push r9
00007e4ecadd7d58  push r10
00007e4ecadd7d5a  push r11
00007e4ecadd7d5c  sub rsp, 0xF0
00007e4ecadd7d63  vmovaps [rsp], xmm0
00007e4ecadd7d68  vmovaps [rsp+0x10], xmm1
00007e4ecadd7d6e  vmovaps [rsp+0x20], xmm2
00007e4ecadd7d74  vmovaps [rsp+0x30], xmm3
00007e4ecadd7d7a  vmovaps [rsp+0x40], xmm4
00007e4ecadd7d80  vmovaps [rsp+0x50], xmm5
00007e4ecadd7d86  vmovaps [rsp+0x60], xmm6
00007e4ecadd7d8c  vmovaps [rsp+0x70], xmm8
00007e4ecadd7d92  vmovaps [rsp+0x80], xmm9
00007e4ecadd7d9b  vmovaps [rsp+0x90], xmm10
00007e4ecadd7da4  vmovaps [rsp+0xA0], xmm11
00007e4ecadd7dad  vmovaps [rsp+0xB0], xmm12
00007e4ecadd7db6  vmovaps [rsp+0xC0], xmm13
00007e4ecadd7dbf  vmovaps [rsp+0xD0], xmm14
00007e4ecadd7dc8  vmovaps [rsp+0xE0], xmm15
00007e4ecadd7dd1  sub rsp, 0x30
00007e4ecadd7dd5  movaps [rsp], xmm7
00007e4ecadd7dd9  movaps [rsp+0x10], xmm5
00007e4ecadd7dde  movaps [rsp+0x20], xmm15
00007e4ecadd7de4  lea rdi, [rsp]
00007e4ecadd7de8  mov esi, 0x00
00007e4ecadd7ded  mov rax, 0x5784BC1F5530
00007e4ecadd7df7  call rax
00007e4ecadd7df9  movaps xmm7, [rsp]
00007e4ecadd7dfd  add rsp, 0x30
00007e4ecadd7e01  vmovaps xmm0, [rsp]
00007e4ecadd7e06  vmovaps xmm1, [rsp+0x10]
00007e4ecadd7e0c  vmovaps xmm2, [rsp+0x20]
00007e4ecadd7e12  vmovaps xmm3, [rsp+0x30]
00007e4ecadd7e18  vmovaps xmm4, [rsp+0x40]
00007e4ecadd7e1e  vmovaps xmm5, [rsp+0x50]
00007e4ecadd7e24  vmovaps xmm6, [rsp+0x60]
00007e4ecadd7e2a  vmovaps xmm8, [rsp+0x70]
00007e4ecadd7e30  vmovaps xmm9, [rsp+0x80]
00007e4ecadd7e39  vmovaps xmm10, [rsp+0x90]
00007e4ecadd7e42  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd7e4b  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd7e54  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd7e5d  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd7e66  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd7e6f  add rsp, 0xF0
00007e4ecadd7e76  pop r11
00007e4ecadd7e78  pop r10
00007e4ecadd7e7a  pop r9
00007e4ecadd7e7c  pop r8
00007e4ecadd7e7e  pop rsi
00007e4ecadd7e7f  pop rdi
00007e4ecadd7e80  pop rdx
00007e4ecadd7e81  pop rcx
00007e4ecadd7e82  pop rax
00007e4ecadd7e83  add rsp, 0x08
00007e4ecadd7e87  jmp 0x00007E4ECADD5EB3
00007e4ecadd7e8c  call 0x00007E4ECACD64F0
00007e4ecadd7e91  jmp 0x00007E4ECADD5EC0
00007e4ecadd7e96  sub rsp, 0x08
00007e4ecadd7e9a  push rax
00007e4ecadd7e9b  push rcx
00007e4ecadd7e9c  push rdx
00007e4ecadd7e9d  push rdi
00007e4ecadd7e9e  push rsi
00007e4ecadd7e9f  push r8
00007e4ecadd7ea1  push r9
00007e4ecadd7ea3  push r10
00007e4ecadd7ea5  push r11
00007e4ecadd7ea7  sub rsp, 0xF0
00007e4ecadd7eae  vmovaps [rsp], xmm0
00007e4ecadd7eb3  vmovaps [rsp+0x10], xmm1
00007e4ecadd7eb9  vmovaps [rsp+0x20], xmm2
00007e4ecadd7ebf  vmovaps [rsp+0x30], xmm3
00007e4ecadd7ec5  vmovaps [rsp+0x40], xmm4
00007e4ecadd7ecb  vmovaps [rsp+0x50], xmm5
00007e4ecadd7ed1  vmovaps [rsp+0x60], xmm6
00007e4ecadd7ed7  vmovaps [rsp+0x70], xmm7
00007e4ecadd7edd  vmovaps [rsp+0x80], xmm8
00007e4ecadd7ee6  vmovaps [rsp+0x90], xmm9
00007e4ecadd7eef  vmovaps [rsp+0xA0], xmm10
00007e4ecadd7ef8  vmovaps [rsp+0xB0], xmm11
00007e4ecadd7f01  vmovaps [rsp+0xC0], xmm12
00007e4ecadd7f0a  vmovaps [rsp+0xD0], xmm13
00007e4ecadd7f13  vmovaps [rsp+0xE0], xmm14
00007e4ecadd7f1c  sub rsp, 0x30
00007e4ecadd7f20  movaps [rsp], xmm15
00007e4ecadd7f25  movaps [rsp+0x10], xmm5
00007e4ecadd7f2a  movaps [rsp+0x20], xmm3
00007e4ecadd7f2f  lea rdi, [rsp]
00007e4ecadd7f33  mov esi, 0x00
00007e4ecadd7f38  mov rax, 0x5784BC1F5530
00007e4ecadd7f42  call rax
00007e4ecadd7f44  movaps xmm15, [rsp]
00007e4ecadd7f49  add rsp, 0x30
00007e4ecadd7f4d  vmovaps xmm0, [rsp]
00007e4ecadd7f52  vmovaps xmm1, [rsp+0x10]
00007e4ecadd7f58  vmovaps xmm2, [rsp+0x20]
00007e4ecadd7f5e  vmovaps xmm3, [rsp+0x30]
00007e4ecadd7f64  vmovaps xmm4, [rsp+0x40]
00007e4ecadd7f6a  vmovaps xmm5, [rsp+0x50]
00007e4ecadd7f70  vmovaps xmm6, [rsp+0x60]
00007e4ecadd7f76  vmovaps xmm7, [rsp+0x70]
00007e4ecadd7f7c  vmovaps xmm8, [rsp+0x80]
00007e4ecadd7f85  vmovaps xmm9, [rsp+0x90]
00007e4ecadd7f8e  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd7f97  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd7fa0  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd7fa9  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd7fb2  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd7fbb  add rsp, 0xF0
00007e4ecadd7fc2  pop r11
00007e4ecadd7fc4  pop r10
00007e4ecadd7fc6  pop r9
00007e4ecadd7fc8  pop r8
00007e4ecadd7fca  pop rsi
00007e4ecadd7fcb  pop rdi
00007e4ecadd7fcc  pop rdx
00007e4ecadd7fcd  pop rcx
00007e4ecadd7fce  pop rax
00007e4ecadd7fcf  add rsp, 0x08
00007e4ecadd7fd3  jmp 0x00007E4ECADD5EE6
00007e4ecadd7fd8  sub rsp, 0x08
00007e4ecadd7fdc  push rax
00007e4ecadd7fdd  push rcx
00007e4ecadd7fde  push rdx
00007e4ecadd7fdf  push rdi
00007e4ecadd7fe0  push rsi
00007e4ecadd7fe1  push r8
00007e4ecadd7fe3  push r9
00007e4ecadd7fe5  push r10
00007e4ecadd7fe7  push r11
00007e4ecadd7fe9  sub rsp, 0xF0
00007e4ecadd7ff0  vmovaps [rsp], xmm0
00007e4ecadd7ff5  vmovaps [rsp+0x10], xmm2
00007e4ecadd7ffb  vmovaps [rsp+0x20], xmm3
00007e4ecadd8001  vmovaps [rsp+0x30], xmm4
00007e4ecadd8007  vmovaps [rsp+0x40], xmm5
00007e4ecadd800d  vmovaps [rsp+0x50], xmm6
00007e4ecadd8013  vmovaps [rsp+0x60], xmm7
00007e4ecadd8019  vmovaps [rsp+0x70], xmm8
00007e4ecadd801f  vmovaps [rsp+0x80], xmm9
00007e4ecadd8028  vmovaps [rsp+0x90], xmm10
00007e4ecadd8031  vmovaps [rsp+0xA0], xmm11
00007e4ecadd803a  vmovaps [rsp+0xB0], xmm12
00007e4ecadd8043  vmovaps [rsp+0xC0], xmm13
00007e4ecadd804c  vmovaps [rsp+0xD0], xmm14
00007e4ecadd8055  vmovaps [rsp+0xE0], xmm15
00007e4ecadd805e  sub rsp, 0x30
00007e4ecadd8062  movaps [rsp], xmm1
00007e4ecadd8066  movaps [rsp+0x10], xmm5
00007e4ecadd806b  movaps [rsp+0x20], xmm4
00007e4ecadd8070  lea rdi, [rsp]
00007e4ecadd8074  mov esi, 0x00
00007e4ecadd8079  mov rax, 0x5784BC1F5530
00007e4ecadd8083  call rax
00007e4ecadd8085  movaps xmm1, [rsp]
00007e4ecadd8089  add rsp, 0x30
00007e4ecadd808d  vmovaps xmm0, [rsp]
00007e4ecadd8092  vmovaps xmm2, [rsp+0x10]
00007e4ecadd8098  vmovaps xmm3, [rsp+0x20]
00007e4ecadd809e  vmovaps xmm4, [rsp+0x30]
00007e4ecadd80a4  vmovaps xmm5, [rsp+0x40]
00007e4ecadd80aa  vmovaps xmm6, [rsp+0x50]
00007e4ecadd80b0  vmovaps xmm7, [rsp+0x60]
00007e4ecadd80b6  vmovaps xmm8, [rsp+0x70]
00007e4ecadd80bc  vmovaps xmm9, [rsp+0x80]
00007e4ecadd80c5  vmovaps xmm10, [rsp+0x90]
00007e4ecadd80ce  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd80d7  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd80e0  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd80e9  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd80f2  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd80fb  add rsp, 0xF0
00007e4ecadd8102  pop r11
00007e4ecadd8104  pop r10
00007e4ecadd8106  pop r9
00007e4ecadd8108  pop r8
00007e4ecadd810a  pop rsi
00007e4ecadd810b  pop rdi
00007e4ecadd810c  pop rdx
00007e4ecadd810d  pop rcx
00007e4ecadd810e  pop rax
00007e4ecadd810f  add rsp, 0x08
00007e4ecadd8113  jmp 0x00007E4ECADD5F06
00007e4ecadd8118  sub rsp, 0x08
00007e4ecadd811c  push rax
00007e4ecadd811d  push rcx
00007e4ecadd811e  push rdx
00007e4ecadd811f  push rdi
00007e4ecadd8120  push rsi
00007e4ecadd8121  push r8
00007e4ecadd8123  push r9
00007e4ecadd8125  push r10
00007e4ecadd8127  push r11
00007e4ecadd8129  sub rsp, 0xF0
00007e4ecadd8130  vmovaps [rsp], xmm0
00007e4ecadd8135  vmovaps [rsp+0x10], xmm1
00007e4ecadd813b  vmovaps [rsp+0x20], xmm2
00007e4ecadd8141  vmovaps [rsp+0x30], xmm3
00007e4ecadd8147  vmovaps [rsp+0x40], xmm5
00007e4ecadd814d  vmovaps [rsp+0x50], xmm6
00007e4ecadd8153  vmovaps [rsp+0x60], xmm7
00007e4ecadd8159  vmovaps [rsp+0x70], xmm8
00007e4ecadd815f  vmovaps [rsp+0x80], xmm9
00007e4ecadd8168  vmovaps [rsp+0x90], xmm10
00007e4ecadd8171  vmovaps [rsp+0xA0], xmm11
00007e4ecadd817a  vmovaps [rsp+0xB0], xmm12
00007e4ecadd8183  vmovaps [rsp+0xC0], xmm13
00007e4ecadd818c  vmovaps [rsp+0xD0], xmm14
00007e4ecadd8195  vmovaps [rsp+0xE0], xmm15
00007e4ecadd819e  sub rsp, 0x30
00007e4ecadd81a2  movaps [rsp], xmm4
00007e4ecadd81a6  movaps [rsp+0x10], xmm3
00007e4ecadd81ab  movaps [rsp+0x20], xmm5
00007e4ecadd81b0  lea rdi, [rsp]
00007e4ecadd81b4  mov esi, 0x00
00007e4ecadd81b9  mov rax, 0x5784BC1F5530
00007e4ecadd81c3  call rax
00007e4ecadd81c5  movaps xmm4, [rsp]
00007e4ecadd81c9  add rsp, 0x30
00007e4ecadd81cd  vmovaps xmm0, [rsp]
00007e4ecadd81d2  vmovaps xmm1, [rsp+0x10]
00007e4ecadd81d8  vmovaps xmm2, [rsp+0x20]
00007e4ecadd81de  vmovaps xmm3, [rsp+0x30]
00007e4ecadd81e4  vmovaps xmm5, [rsp+0x40]
00007e4ecadd81ea  vmovaps xmm6, [rsp+0x50]
00007e4ecadd81f0  vmovaps xmm7, [rsp+0x60]
00007e4ecadd81f6  vmovaps xmm8, [rsp+0x70]
00007e4ecadd81fc  vmovaps xmm9, [rsp+0x80]
00007e4ecadd8205  vmovaps xmm10, [rsp+0x90]
00007e4ecadd820e  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd8217  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd8220  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd8229  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd8232  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd823b  add rsp, 0xF0
00007e4ecadd8242  pop r11
00007e4ecadd8244  pop r10
00007e4ecadd8246  pop r9
00007e4ecadd8248  pop r8
00007e4ecadd824a  pop rsi
00007e4ecadd824b  pop rdi
00007e4ecadd824c  pop rdx
00007e4ecadd824d  pop rcx
00007e4ecadd824e  pop rax
00007e4ecadd824f  add rsp, 0x08
00007e4ecadd8253  jmp 0x00007E4ECADD5F54
00007e4ecadd8258  call 0x00007E4ECACD64F0
00007e4ecadd825d  jmp 0x00007E4ECADD5F61
00007e4ecadd8262  sub rsp, 0x08
00007e4ecadd8266  push rax
00007e4ecadd8267  push rcx
00007e4ecadd8268  push rdx
00007e4ecadd8269  push rdi
00007e4ecadd826a  push rsi
00007e4ecadd826b  push r8
00007e4ecadd826d  push r9
00007e4ecadd826f  push r10
00007e4ecadd8271  push r11
00007e4ecadd8273  sub rsp, 0xF0
00007e4ecadd827a  vmovaps [rsp], xmm0
00007e4ecadd827f  vmovaps [rsp+0x10], xmm1
00007e4ecadd8285  vmovaps [rsp+0x20], xmm2
00007e4ecadd828b  vmovaps [rsp+0x30], xmm3
00007e4ecadd8291  vmovaps [rsp+0x40], xmm4
00007e4ecadd8297  vmovaps [rsp+0x50], xmm6
00007e4ecadd829d  vmovaps [rsp+0x60], xmm7
00007e4ecadd82a3  vmovaps [rsp+0x70], xmm8
00007e4ecadd82a9  vmovaps [rsp+0x80], xmm9
00007e4ecadd82b2  vmovaps [rsp+0x90], xmm10
00007e4ecadd82bb  vmovaps [rsp+0xA0], xmm11
00007e4ecadd82c4  vmovaps [rsp+0xB0], xmm12
00007e4ecadd82cd  vmovaps [rsp+0xC0], xmm13
00007e4ecadd82d6  vmovaps [rsp+0xD0], xmm14
00007e4ecadd82df  vmovaps [rsp+0xE0], xmm15
00007e4ecadd82e8  sub rsp, 0x30
00007e4ecadd82ec  movaps [rsp], xmm5
00007e4ecadd82f0  movaps [rsp+0x10], xmm6
00007e4ecadd82f5  movaps [rsp+0x20], xmm3
00007e4ecadd82fa  lea rdi, [rsp]
00007e4ecadd82fe  mov esi, 0x00
00007e4ecadd8303  mov rax, 0x5784BC1F5530
00007e4ecadd830d  call rax
00007e4ecadd830f  movaps xmm5, [rsp]
00007e4ecadd8313  add rsp, 0x30
00007e4ecadd8317  vmovaps xmm0, [rsp]
00007e4ecadd831c  vmovaps xmm1, [rsp+0x10]
00007e4ecadd8322  vmovaps xmm2, [rsp+0x20]
00007e4ecadd8328  vmovaps xmm3, [rsp+0x30]
00007e4ecadd832e  vmovaps xmm4, [rsp+0x40]
00007e4ecadd8334  vmovaps xmm6, [rsp+0x50]
00007e4ecadd833a  vmovaps xmm7, [rsp+0x60]
00007e4ecadd8340  vmovaps xmm8, [rsp+0x70]
00007e4ecadd8346  vmovaps xmm9, [rsp+0x80]
00007e4ecadd834f  vmovaps xmm10, [rsp+0x90]
00007e4ecadd8358  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd8361  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd836a  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd8373  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd837c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd8385  add rsp, 0xF0
00007e4ecadd838c  pop r11
00007e4ecadd838e  pop r10
00007e4ecadd8390  pop r9
00007e4ecadd8392  pop r8
00007e4ecadd8394  pop rsi
00007e4ecadd8395  pop rdi
00007e4ecadd8396  pop rdx
00007e4ecadd8397  pop rcx
00007e4ecadd8398  pop rax
00007e4ecadd8399  add rsp, 0x08
00007e4ecadd839d  jmp 0x00007E4ECADD5F87
00007e4ecadd83a2  sub rsp, 0x08
00007e4ecadd83a6  push rax
00007e4ecadd83a7  push rcx
00007e4ecadd83a8  push rdx
00007e4ecadd83a9  push rdi
00007e4ecadd83aa  push rsi
00007e4ecadd83ab  push r8
00007e4ecadd83ad  push r9
00007e4ecadd83af  push r10
00007e4ecadd83b1  push r11
00007e4ecadd83b3  sub rsp, 0xF0
00007e4ecadd83ba  vmovaps [rsp], xmm0
00007e4ecadd83bf  vmovaps [rsp+0x10], xmm1
00007e4ecadd83c5  vmovaps [rsp+0x20], xmm2
00007e4ecadd83cb  vmovaps [rsp+0x30], xmm3
00007e4ecadd83d1  vmovaps [rsp+0x40], xmm4
00007e4ecadd83d7  vmovaps [rsp+0x50], xmm5
00007e4ecadd83dd  vmovaps [rsp+0x60], xmm7
00007e4ecadd83e3  vmovaps [rsp+0x70], xmm8
00007e4ecadd83e9  vmovaps [rsp+0x80], xmm9
00007e4ecadd83f2  vmovaps [rsp+0x90], xmm10
00007e4ecadd83fb  vmovaps [rsp+0xA0], xmm11
00007e4ecadd8404  vmovaps [rsp+0xB0], xmm12
00007e4ecadd840d  vmovaps [rsp+0xC0], xmm13
00007e4ecadd8416  vmovaps [rsp+0xD0], xmm14
00007e4ecadd841f  vmovaps [rsp+0xE0], xmm15
00007e4ecadd8428  sub rsp, 0x30
00007e4ecadd842c  movaps [rsp], xmm6
00007e4ecadd8430  movaps [rsp+0x10], xmm9
00007e4ecadd8436  movaps [rsp+0x20], xmm1
00007e4ecadd843b  lea rdi, [rsp]
00007e4ecadd843f  mov esi, 0x00
00007e4ecadd8444  mov rax, 0x5784BC1F5530
00007e4ecadd844e  call rax
00007e4ecadd8450  movaps xmm6, [rsp]
00007e4ecadd8454  add rsp, 0x30
00007e4ecadd8458  vmovaps xmm0, [rsp]
00007e4ecadd845d  vmovaps xmm1, [rsp+0x10]
00007e4ecadd8463  vmovaps xmm2, [rsp+0x20]
00007e4ecadd8469  vmovaps xmm3, [rsp+0x30]
00007e4ecadd846f  vmovaps xmm4, [rsp+0x40]
00007e4ecadd8475  vmovaps xmm5, [rsp+0x50]
00007e4ecadd847b  vmovaps xmm7, [rsp+0x60]
00007e4ecadd8481  vmovaps xmm8, [rsp+0x70]
00007e4ecadd8487  vmovaps xmm9, [rsp+0x80]
00007e4ecadd8490  vmovaps xmm10, [rsp+0x90]
00007e4ecadd8499  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd84a2  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd84ab  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd84b4  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd84bd  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd84c6  add rsp, 0xF0
00007e4ecadd84cd  pop r11
00007e4ecadd84cf  pop r10
00007e4ecadd84d1  pop r9
00007e4ecadd84d3  pop r8
00007e4ecadd84d5  pop rsi
00007e4ecadd84d6  pop rdi
00007e4ecadd84d7  pop rdx
00007e4ecadd84d8  pop rcx
00007e4ecadd84d9  pop rax
00007e4ecadd84da  add rsp, 0x08
00007e4ecadd84de  jmp 0x00007E4ECADD5FAB
00007e4ecadd84e3  sub rsp, 0x08
00007e4ecadd84e7  push rax
00007e4ecadd84e8  push rcx
00007e4ecadd84e9  push rdx
00007e4ecadd84ea  push rdi
00007e4ecadd84eb  push rsi
00007e4ecadd84ec  push r8
00007e4ecadd84ee  push r9
00007e4ecadd84f0  push r10
00007e4ecadd84f2  push r11
00007e4ecadd84f4  sub rsp, 0xF0
00007e4ecadd84fb  vmovaps [rsp], xmm0
00007e4ecadd8500  vmovaps [rsp+0x10], xmm1
00007e4ecadd8506  vmovaps [rsp+0x20], xmm2
00007e4ecadd850c  vmovaps [rsp+0x30], xmm3
00007e4ecadd8512  vmovaps [rsp+0x40], xmm4
00007e4ecadd8518  vmovaps [rsp+0x50], xmm5
00007e4ecadd851e  vmovaps [rsp+0x60], xmm6
00007e4ecadd8524  vmovaps [rsp+0x70], xmm7
00007e4ecadd852a  vmovaps [rsp+0x80], xmm8
00007e4ecadd8533  vmovaps [rsp+0x90], xmm10
00007e4ecadd853c  vmovaps [rsp+0xA0], xmm11
00007e4ecadd8545  vmovaps [rsp+0xB0], xmm12
00007e4ecadd854e  vmovaps [rsp+0xC0], xmm13
00007e4ecadd8557  vmovaps [rsp+0xD0], xmm14
00007e4ecadd8560  vmovaps [rsp+0xE0], xmm15
00007e4ecadd8569  sub rsp, 0x30
00007e4ecadd856d  movaps [rsp], xmm9
00007e4ecadd8572  movaps [rsp+0x10], xmm3
00007e4ecadd8577  movaps [rsp+0x20], xmm1
00007e4ecadd857c  lea rdi, [rsp]
00007e4ecadd8580  mov esi, 0x00
00007e4ecadd8585  mov rax, 0x5784BC1F5530
00007e4ecadd858f  call rax
00007e4ecadd8591  movaps xmm9, [rsp]
00007e4ecadd8596  add rsp, 0x30
00007e4ecadd859a  vmovaps xmm0, [rsp]
00007e4ecadd859f  vmovaps xmm1, [rsp+0x10]
00007e4ecadd85a5  vmovaps xmm2, [rsp+0x20]
00007e4ecadd85ab  vmovaps xmm3, [rsp+0x30]
00007e4ecadd85b1  vmovaps xmm4, [rsp+0x40]
00007e4ecadd85b7  vmovaps xmm5, [rsp+0x50]
00007e4ecadd85bd  vmovaps xmm6, [rsp+0x60]
00007e4ecadd85c3  vmovaps xmm7, [rsp+0x70]
00007e4ecadd85c9  vmovaps xmm8, [rsp+0x80]
00007e4ecadd85d2  vmovaps xmm10, [rsp+0x90]
00007e4ecadd85db  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd85e4  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd85ed  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd85f6  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd85ff  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd8608  add rsp, 0xF0
00007e4ecadd860f  pop r11
00007e4ecadd8611  pop r10
00007e4ecadd8613  pop r9
00007e4ecadd8615  pop r8
00007e4ecadd8617  pop rsi
00007e4ecadd8618  pop rdi
00007e4ecadd8619  pop rdx
00007e4ecadd861a  pop rcx
00007e4ecadd861b  pop rax
00007e4ecadd861c  add rsp, 0x08
00007e4ecadd8620  jmp 0x00007E4ECADD5FF7
00007e4ecadd8625  call 0x00007E4ECACD64F0
00007e4ecadd862a  jmp 0x00007E4ECADD6004
00007e4ecadd862f  sub rsp, 0x08
00007e4ecadd8633  push rax
00007e4ecadd8634  push rcx
00007e4ecadd8635  push rdx
00007e4ecadd8636  push rdi
00007e4ecadd8637  push rsi
00007e4ecadd8638  push r8
00007e4ecadd863a  push r9
00007e4ecadd863c  push r10
00007e4ecadd863e  push r11
00007e4ecadd8640  sub rsp, 0xF0
00007e4ecadd8647  vmovaps [rsp], xmm0
00007e4ecadd864c  vmovaps [rsp+0x10], xmm1
00007e4ecadd8652  vmovaps [rsp+0x20], xmm2
00007e4ecadd8658  vmovaps [rsp+0x30], xmm3
00007e4ecadd865e  vmovaps [rsp+0x40], xmm4
00007e4ecadd8664  vmovaps [rsp+0x50], xmm5
00007e4ecadd866a  vmovaps [rsp+0x60], xmm6
00007e4ecadd8670  vmovaps [rsp+0x70], xmm7
00007e4ecadd8676  vmovaps [rsp+0x80], xmm8
00007e4ecadd867f  vmovaps [rsp+0x90], xmm9
00007e4ecadd8688  vmovaps [rsp+0xA0], xmm10
00007e4ecadd8691  vmovaps [rsp+0xB0], xmm11
00007e4ecadd869a  vmovaps [rsp+0xC0], xmm12
00007e4ecadd86a3  vmovaps [rsp+0xD0], xmm13
00007e4ecadd86ac  vmovaps [rsp+0xE0], xmm14
00007e4ecadd86b5  sub rsp, 0x30
00007e4ecadd86b9  movaps [rsp], xmm15
00007e4ecadd86be  movaps [rsp+0x10], xmm3
00007e4ecadd86c3  movaps [rsp+0x20], xmm7
00007e4ecadd86c8  lea rdi, [rsp]
00007e4ecadd86cc  mov esi, 0x00
00007e4ecadd86d1  mov rax, 0x5784BC1F5530
00007e4ecadd86db  call rax
00007e4ecadd86dd  movaps xmm15, [rsp]
00007e4ecadd86e2  add rsp, 0x30
00007e4ecadd86e6  vmovaps xmm0, [rsp]
00007e4ecadd86eb  vmovaps xmm1, [rsp+0x10]
00007e4ecadd86f1  vmovaps xmm2, [rsp+0x20]
00007e4ecadd86f7  vmovaps xmm3, [rsp+0x30]
00007e4ecadd86fd  vmovaps xmm4, [rsp+0x40]
00007e4ecadd8703  vmovaps xmm5, [rsp+0x50]
00007e4ecadd8709  vmovaps xmm6, [rsp+0x60]
00007e4ecadd870f  vmovaps xmm7, [rsp+0x70]
00007e4ecadd8715  vmovaps xmm8, [rsp+0x80]
00007e4ecadd871e  vmovaps xmm9, [rsp+0x90]
00007e4ecadd8727  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd8730  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd8739  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd8742  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd874b  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd8754  add rsp, 0xF0
00007e4ecadd875b  pop r11
00007e4ecadd875d  pop r10
00007e4ecadd875f  pop r9
00007e4ecadd8761  pop r8
00007e4ecadd8763  pop rsi
00007e4ecadd8764  pop rdi
00007e4ecadd8765  pop rdx
00007e4ecadd8766  pop rcx
00007e4ecadd8767  pop rax
00007e4ecadd8768  add rsp, 0x08
00007e4ecadd876c  jmp 0x00007E4ECADD6030
00007e4ecadd8771  sub rsp, 0x08
00007e4ecadd8775  push rax
00007e4ecadd8776  push rcx
00007e4ecadd8777  push rdx
00007e4ecadd8778  push rdi
00007e4ecadd8779  push rsi
00007e4ecadd877a  push r8
00007e4ecadd877c  push r9
00007e4ecadd877e  push r10
00007e4ecadd8780  push r11
00007e4ecadd8782  sub rsp, 0xF0
00007e4ecadd8789  vmovaps [rsp], xmm0
00007e4ecadd878e  vmovaps [rsp+0x10], xmm1
00007e4ecadd8794  vmovaps [rsp+0x20], xmm2
00007e4ecadd879a  vmovaps [rsp+0x30], xmm4
00007e4ecadd87a0  vmovaps [rsp+0x40], xmm5
00007e4ecadd87a6  vmovaps [rsp+0x50], xmm6
00007e4ecadd87ac  vmovaps [rsp+0x60], xmm7
00007e4ecadd87b2  vmovaps [rsp+0x70], xmm8
00007e4ecadd87b8  vmovaps [rsp+0x80], xmm9
00007e4ecadd87c1  vmovaps [rsp+0x90], xmm10
00007e4ecadd87ca  vmovaps [rsp+0xA0], xmm11
00007e4ecadd87d3  vmovaps [rsp+0xB0], xmm12
00007e4ecadd87dc  vmovaps [rsp+0xC0], xmm13
00007e4ecadd87e5  vmovaps [rsp+0xD0], xmm14
00007e4ecadd87ee  vmovaps [rsp+0xE0], xmm15
00007e4ecadd87f7  sub rsp, 0x30
00007e4ecadd87fb  movaps [rsp], xmm3
00007e4ecadd87ff  movaps [rsp+0x10], xmm1
00007e4ecadd8804  movaps [rsp+0x20], xmm15
00007e4ecadd880a  lea rdi, [rsp]
00007e4ecadd880e  mov esi, 0x00
00007e4ecadd8813  mov rax, 0x5784BC1F5530
00007e4ecadd881d  call rax
00007e4ecadd881f  movaps xmm3, [rsp]
00007e4ecadd8823  add rsp, 0x30
00007e4ecadd8827  vmovaps xmm0, [rsp]
00007e4ecadd882c  vmovaps xmm1, [rsp+0x10]
00007e4ecadd8832  vmovaps xmm2, [rsp+0x20]
00007e4ecadd8838  vmovaps xmm4, [rsp+0x30]
00007e4ecadd883e  vmovaps xmm5, [rsp+0x40]
00007e4ecadd8844  vmovaps xmm6, [rsp+0x50]
00007e4ecadd884a  vmovaps xmm7, [rsp+0x60]
00007e4ecadd8850  vmovaps xmm8, [rsp+0x70]
00007e4ecadd8856  vmovaps xmm9, [rsp+0x80]
00007e4ecadd885f  vmovaps xmm10, [rsp+0x90]
00007e4ecadd8868  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd8871  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd887a  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd8883  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd888c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd8895  add rsp, 0xF0
00007e4ecadd889c  pop r11
00007e4ecadd889e  pop r10
00007e4ecadd88a0  pop r9
00007e4ecadd88a2  pop r8
00007e4ecadd88a4  pop rsi
00007e4ecadd88a5  pop rdi
00007e4ecadd88a6  pop rdx
00007e4ecadd88a7  pop rcx
00007e4ecadd88a8  pop rax
00007e4ecadd88a9  add rsp, 0x08
00007e4ecadd88ad  jmp 0x00007E4ECADD60BF
00007e4ecadd88b2  call 0x00007E4ECACD64F0
00007e4ecadd88b7  jmp 0x00007E4ECADD60C9
00007e4ecadd88bc  sub rsp, 0x08
00007e4ecadd88c0  push rax
00007e4ecadd88c1  push rcx
00007e4ecadd88c2  push rdx
00007e4ecadd88c3  push rdi
00007e4ecadd88c4  push rsi
00007e4ecadd88c5  push r8
00007e4ecadd88c7  push r9
00007e4ecadd88c9  push r10
00007e4ecadd88cb  push r11
00007e4ecadd88cd  sub rsp, 0xF0
00007e4ecadd88d4  vmovaps [rsp], xmm0
00007e4ecadd88d9  vmovaps [rsp+0x10], xmm1
00007e4ecadd88df  vmovaps [rsp+0x20], xmm2
00007e4ecadd88e5  vmovaps [rsp+0x30], xmm3
00007e4ecadd88eb  vmovaps [rsp+0x40], xmm4
00007e4ecadd88f1  vmovaps [rsp+0x50], xmm5
00007e4ecadd88f7  vmovaps [rsp+0x60], xmm6
00007e4ecadd88fd  vmovaps [rsp+0x70], xmm7
00007e4ecadd8903  vmovaps [rsp+0x80], xmm8
00007e4ecadd890c  vmovaps [rsp+0x90], xmm9
00007e4ecadd8915  vmovaps [rsp+0xA0], xmm10
00007e4ecadd891e  vmovaps [rsp+0xB0], xmm11
00007e4ecadd8927  vmovaps [rsp+0xC0], xmm12
00007e4ecadd8930  vmovaps [rsp+0xD0], xmm13
00007e4ecadd8939  vmovaps [rsp+0xE0], xmm14
00007e4ecadd8942  sub rsp, 0x30
00007e4ecadd8946  movaps [rsp], xmm15
00007e4ecadd894b  movaps [rsp+0x10], xmm14
00007e4ecadd8951  movaps [rsp+0x20], xmm4
00007e4ecadd8956  lea rdi, [rsp]
00007e4ecadd895a  mov esi, 0x00
00007e4ecadd895f  mov rax, 0x5784BC1F5530
00007e4ecadd8969  call rax
00007e4ecadd896b  movaps xmm15, [rsp]
00007e4ecadd8970  add rsp, 0x30
00007e4ecadd8974  vmovaps xmm0, [rsp]
00007e4ecadd8979  vmovaps xmm1, [rsp+0x10]
00007e4ecadd897f  vmovaps xmm2, [rsp+0x20]
00007e4ecadd8985  vmovaps xmm3, [rsp+0x30]
00007e4ecadd898b  vmovaps xmm4, [rsp+0x40]
00007e4ecadd8991  vmovaps xmm5, [rsp+0x50]
00007e4ecadd8997  vmovaps xmm6, [rsp+0x60]
00007e4ecadd899d  vmovaps xmm7, [rsp+0x70]
00007e4ecadd89a3  vmovaps xmm8, [rsp+0x80]
00007e4ecadd89ac  vmovaps xmm9, [rsp+0x90]
00007e4ecadd89b5  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd89be  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd89c7  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd89d0  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd89d9  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd89e2  add rsp, 0xF0
00007e4ecadd89e9  pop r11
00007e4ecadd89eb  pop r10
00007e4ecadd89ed  pop r9
00007e4ecadd89ef  pop r8
00007e4ecadd89f1  pop rsi
00007e4ecadd89f2  pop rdi
00007e4ecadd89f3  pop rdx
00007e4ecadd89f4  pop rcx
00007e4ecadd89f5  pop rax
00007e4ecadd89f6  add rsp, 0x08
00007e4ecadd89fa  jmp 0x00007E4ECADD60F7
00007e4ecadd89ff  sub rsp, 0x08
00007e4ecadd8a03  push rax
00007e4ecadd8a04  push rcx
00007e4ecadd8a05  push rdx
00007e4ecadd8a06  push rdi
00007e4ecadd8a07  push rsi
00007e4ecadd8a08  push r8
00007e4ecadd8a0a  push r9
00007e4ecadd8a0c  push r10
00007e4ecadd8a0e  push r11
00007e4ecadd8a10  sub rsp, 0xF0
00007e4ecadd8a17  vmovaps [rsp], xmm0
00007e4ecadd8a1c  vmovaps [rsp+0x10], xmm1
00007e4ecadd8a22  vmovaps [rsp+0x20], xmm2
00007e4ecadd8a28  vmovaps [rsp+0x30], xmm3
00007e4ecadd8a2e  vmovaps [rsp+0x40], xmm4
00007e4ecadd8a34  vmovaps [rsp+0x50], xmm5
00007e4ecadd8a3a  vmovaps [rsp+0x60], xmm6
00007e4ecadd8a40  vmovaps [rsp+0x70], xmm7
00007e4ecadd8a46  vmovaps [rsp+0x80], xmm8
00007e4ecadd8a4f  vmovaps [rsp+0x90], xmm9
00007e4ecadd8a58  vmovaps [rsp+0xA0], xmm10
00007e4ecadd8a61  vmovaps [rsp+0xB0], xmm11
00007e4ecadd8a6a  vmovaps [rsp+0xC0], xmm12
00007e4ecadd8a73  vmovaps [rsp+0xD0], xmm13
00007e4ecadd8a7c  vmovaps [rsp+0xE0], xmm15
00007e4ecadd8a85  sub rsp, 0x30
00007e4ecadd8a89  movaps [rsp], xmm14
00007e4ecadd8a8e  movaps [rsp+0x10], xmm2
00007e4ecadd8a93  movaps [rsp+0x20], xmm1
00007e4ecadd8a98  lea rdi, [rsp]
00007e4ecadd8a9c  mov esi, 0x00
00007e4ecadd8aa1  mov rax, 0x5784BC1F5530
00007e4ecadd8aab  call rax
00007e4ecadd8aad  movaps xmm14, [rsp]
00007e4ecadd8ab2  add rsp, 0x30
00007e4ecadd8ab6  vmovaps xmm0, [rsp]
00007e4ecadd8abb  vmovaps xmm1, [rsp+0x10]
00007e4ecadd8ac1  vmovaps xmm2, [rsp+0x20]
00007e4ecadd8ac7  vmovaps xmm3, [rsp+0x30]
00007e4ecadd8acd  vmovaps xmm4, [rsp+0x40]
00007e4ecadd8ad3  vmovaps xmm5, [rsp+0x50]
00007e4ecadd8ad9  vmovaps xmm6, [rsp+0x60]
00007e4ecadd8adf  vmovaps xmm7, [rsp+0x70]
00007e4ecadd8ae5  vmovaps xmm8, [rsp+0x80]
00007e4ecadd8aee  vmovaps xmm9, [rsp+0x90]
00007e4ecadd8af7  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd8b00  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd8b09  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd8b12  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd8b1b  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd8b24  add rsp, 0xF0
00007e4ecadd8b2b  pop r11
00007e4ecadd8b2d  pop r10
00007e4ecadd8b2f  pop r9
00007e4ecadd8b31  pop r8
00007e4ecadd8b33  pop rsi
00007e4ecadd8b34  pop rdi
00007e4ecadd8b35  pop rdx
00007e4ecadd8b36  pop rcx
00007e4ecadd8b37  pop rax
00007e4ecadd8b38  add rsp, 0x08
00007e4ecadd8b3c  jmp 0x00007E4ECADD611D
00007e4ecadd8b41  sub rsp, 0x08
00007e4ecadd8b45  push rax
00007e4ecadd8b46  push rcx
00007e4ecadd8b47  push rdx
00007e4ecadd8b48  push rdi
00007e4ecadd8b49  push rsi
00007e4ecadd8b4a  push r8
00007e4ecadd8b4c  push r9
00007e4ecadd8b4e  push r10
00007e4ecadd8b50  push r11
00007e4ecadd8b52  sub rsp, 0xF0
00007e4ecadd8b59  vmovaps [rsp], xmm0
00007e4ecadd8b5e  vmovaps [rsp+0x10], xmm2
00007e4ecadd8b64  vmovaps [rsp+0x20], xmm3
00007e4ecadd8b6a  vmovaps [rsp+0x30], xmm4
00007e4ecadd8b70  vmovaps [rsp+0x40], xmm5
00007e4ecadd8b76  vmovaps [rsp+0x50], xmm6
00007e4ecadd8b7c  vmovaps [rsp+0x60], xmm7
00007e4ecadd8b82  vmovaps [rsp+0x70], xmm8
00007e4ecadd8b88  vmovaps [rsp+0x80], xmm9
00007e4ecadd8b91  vmovaps [rsp+0x90], xmm10
00007e4ecadd8b9a  vmovaps [rsp+0xA0], xmm11
00007e4ecadd8ba3  vmovaps [rsp+0xB0], xmm12
00007e4ecadd8bac  vmovaps [rsp+0xC0], xmm13
00007e4ecadd8bb5  vmovaps [rsp+0xD0], xmm14
00007e4ecadd8bbe  vmovaps [rsp+0xE0], xmm15
00007e4ecadd8bc7  sub rsp, 0x30
00007e4ecadd8bcb  movaps [rsp], xmm1
00007e4ecadd8bcf  movaps [rsp+0x10], xmm4
00007e4ecadd8bd4  movaps [rsp+0x20], xmm9
00007e4ecadd8bda  lea rdi, [rsp]
00007e4ecadd8bde  mov esi, 0x00
00007e4ecadd8be3  mov rax, 0x5784BC1F5530
00007e4ecadd8bed  call rax
00007e4ecadd8bef  movaps xmm1, [rsp]
00007e4ecadd8bf3  add rsp, 0x30
00007e4ecadd8bf7  vmovaps xmm0, [rsp]
00007e4ecadd8bfc  vmovaps xmm2, [rsp+0x10]
00007e4ecadd8c02  vmovaps xmm3, [rsp+0x20]
00007e4ecadd8c08  vmovaps xmm4, [rsp+0x30]
00007e4ecadd8c0e  vmovaps xmm5, [rsp+0x40]
00007e4ecadd8c14  vmovaps xmm6, [rsp+0x50]
00007e4ecadd8c1a  vmovaps xmm7, [rsp+0x60]
00007e4ecadd8c20  vmovaps xmm8, [rsp+0x70]
00007e4ecadd8c26  vmovaps xmm9, [rsp+0x80]
00007e4ecadd8c2f  vmovaps xmm10, [rsp+0x90]
00007e4ecadd8c38  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd8c41  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd8c4a  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd8c53  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd8c5c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd8c65  add rsp, 0xF0
00007e4ecadd8c6c  pop r11
00007e4ecadd8c6e  pop r10
00007e4ecadd8c70  pop r9
00007e4ecadd8c72  pop r8
00007e4ecadd8c74  pop rsi
00007e4ecadd8c75  pop rdi
00007e4ecadd8c76  pop rdx
00007e4ecadd8c77  pop rcx
00007e4ecadd8c78  pop rax
00007e4ecadd8c79  add rsp, 0x08
00007e4ecadd8c7d  jmp 0x00007E4ECADD613B
00007e4ecadd8c82  sub rsp, 0x08
00007e4ecadd8c86  push rax
00007e4ecadd8c87  push rcx
00007e4ecadd8c88  push rdx
00007e4ecadd8c89  push rdi
00007e4ecadd8c8a  push rsi
00007e4ecadd8c8b  push r8
00007e4ecadd8c8d  push r9
00007e4ecadd8c8f  push r10
00007e4ecadd8c91  push r11
00007e4ecadd8c93  sub rsp, 0xF0
00007e4ecadd8c9a  vmovaps [rsp], xmm0
00007e4ecadd8c9f  vmovaps [rsp+0x10], xmm1
00007e4ecadd8ca5  vmovaps [rsp+0x20], xmm2
00007e4ecadd8cab  vmovaps [rsp+0x30], xmm3
00007e4ecadd8cb1  vmovaps [rsp+0x40], xmm5
00007e4ecadd8cb7  vmovaps [rsp+0x50], xmm6
00007e4ecadd8cbd  vmovaps [rsp+0x60], xmm7
00007e4ecadd8cc3  vmovaps [rsp+0x70], xmm8
00007e4ecadd8cc9  vmovaps [rsp+0x80], xmm9
00007e4ecadd8cd2  vmovaps [rsp+0x90], xmm10
00007e4ecadd8cdb  vmovaps [rsp+0xA0], xmm11
00007e4ecadd8ce4  vmovaps [rsp+0xB0], xmm12
00007e4ecadd8ced  vmovaps [rsp+0xC0], xmm13
00007e4ecadd8cf6  vmovaps [rsp+0xD0], xmm14
00007e4ecadd8cff  vmovaps [rsp+0xE0], xmm15
00007e4ecadd8d08  sub rsp, 0x30
00007e4ecadd8d0c  movaps [rsp], xmm4
00007e4ecadd8d10  movaps [rsp+0x10], xmm2
00007e4ecadd8d15  movaps [rsp+0x20], xmm9
00007e4ecadd8d1b  lea rdi, [rsp]
00007e4ecadd8d1f  mov esi, 0x00
00007e4ecadd8d24  mov rax, 0x5784BC1F5530
00007e4ecadd8d2e  call rax
00007e4ecadd8d30  movaps xmm4, [rsp]
00007e4ecadd8d34  add rsp, 0x30
00007e4ecadd8d38  vmovaps xmm0, [rsp]
00007e4ecadd8d3d  vmovaps xmm1, [rsp+0x10]
00007e4ecadd8d43  vmovaps xmm2, [rsp+0x20]
00007e4ecadd8d49  vmovaps xmm3, [rsp+0x30]
00007e4ecadd8d4f  vmovaps xmm5, [rsp+0x40]
00007e4ecadd8d55  vmovaps xmm6, [rsp+0x50]
00007e4ecadd8d5b  vmovaps xmm7, [rsp+0x60]
00007e4ecadd8d61  vmovaps xmm8, [rsp+0x70]
00007e4ecadd8d67  vmovaps xmm9, [rsp+0x80]
00007e4ecadd8d70  vmovaps xmm10, [rsp+0x90]
00007e4ecadd8d79  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd8d82  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd8d8b  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd8d94  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd8d9d  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd8da6  add rsp, 0xF0
00007e4ecadd8dad  pop r11
00007e4ecadd8daf  pop r10
00007e4ecadd8db1  pop r9
00007e4ecadd8db3  pop r8
00007e4ecadd8db5  pop rsi
00007e4ecadd8db6  pop rdi
00007e4ecadd8db7  pop rdx
00007e4ecadd8db8  pop rcx
00007e4ecadd8db9  pop rax
00007e4ecadd8dba  add rsp, 0x08
00007e4ecadd8dbe  jmp 0x00007E4ECADD616B
00007e4ecadd8dc3  sub rsp, 0x08
00007e4ecadd8dc7  push rax
00007e4ecadd8dc8  push rcx
00007e4ecadd8dc9  push rdx
00007e4ecadd8dca  push rdi
00007e4ecadd8dcb  push rsi
00007e4ecadd8dcc  push r8
00007e4ecadd8dce  push r9
00007e4ecadd8dd0  push r10
00007e4ecadd8dd2  push r11
00007e4ecadd8dd4  sub rsp, 0xF0
00007e4ecadd8ddb  vmovaps [rsp], xmm0
00007e4ecadd8de0  vmovaps [rsp+0x10], xmm1
00007e4ecadd8de6  vmovaps [rsp+0x20], xmm2
00007e4ecadd8dec  vmovaps [rsp+0x30], xmm3
00007e4ecadd8df2  vmovaps [rsp+0x40], xmm4
00007e4ecadd8df8  vmovaps [rsp+0x50], xmm5
00007e4ecadd8dfe  vmovaps [rsp+0x60], xmm6
00007e4ecadd8e04  vmovaps [rsp+0x70], xmm7
00007e4ecadd8e0a  vmovaps [rsp+0x80], xmm8
00007e4ecadd8e13  vmovaps [rsp+0x90], xmm10
00007e4ecadd8e1c  vmovaps [rsp+0xA0], xmm11
00007e4ecadd8e25  vmovaps [rsp+0xB0], xmm12
00007e4ecadd8e2e  vmovaps [rsp+0xC0], xmm13
00007e4ecadd8e37  vmovaps [rsp+0xD0], xmm14
00007e4ecadd8e40  vmovaps [rsp+0xE0], xmm15
00007e4ecadd8e49  sub rsp, 0x30
00007e4ecadd8e4d  movaps [rsp], xmm9
00007e4ecadd8e52  movaps [rsp+0x10], xmm2
00007e4ecadd8e57  movaps [rsp+0x20], xmm1
00007e4ecadd8e5c  lea rdi, [rsp]
00007e4ecadd8e60  mov esi, 0x00
00007e4ecadd8e65  mov rax, 0x5784BC1F5530
00007e4ecadd8e6f  call rax
00007e4ecadd8e71  movaps xmm9, [rsp]
00007e4ecadd8e76  add rsp, 0x30
00007e4ecadd8e7a  vmovaps xmm0, [rsp]
00007e4ecadd8e7f  vmovaps xmm1, [rsp+0x10]
00007e4ecadd8e85  vmovaps xmm2, [rsp+0x20]
00007e4ecadd8e8b  vmovaps xmm3, [rsp+0x30]
00007e4ecadd8e91  vmovaps xmm4, [rsp+0x40]
00007e4ecadd8e97  vmovaps xmm5, [rsp+0x50]
00007e4ecadd8e9d  vmovaps xmm6, [rsp+0x60]
00007e4ecadd8ea3  vmovaps xmm7, [rsp+0x70]
00007e4ecadd8ea9  vmovaps xmm8, [rsp+0x80]
00007e4ecadd8eb2  vmovaps xmm10, [rsp+0x90]
00007e4ecadd8ebb  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd8ec4  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd8ecd  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd8ed6  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd8edf  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd8ee8  add rsp, 0xF0
00007e4ecadd8eef  pop r11
00007e4ecadd8ef1  pop r10
00007e4ecadd8ef3  pop r9
00007e4ecadd8ef5  pop r8
00007e4ecadd8ef7  pop rsi
00007e4ecadd8ef8  pop rdi
00007e4ecadd8ef9  pop rdx
00007e4ecadd8efa  pop rcx
00007e4ecadd8efb  pop rax
00007e4ecadd8efc  add rsp, 0x08
00007e4ecadd8f00  jmp 0x00007E4ECADD61A1
00007e4ecadd8f05  sub rsp, 0x08
00007e4ecadd8f09  push rax
00007e4ecadd8f0a  push rcx
00007e4ecadd8f0b  push rdx
00007e4ecadd8f0c  push rdi
00007e4ecadd8f0d  push rsi
00007e4ecadd8f0e  push r8
00007e4ecadd8f10  push r9
00007e4ecadd8f12  push r10
00007e4ecadd8f14  push r11
00007e4ecadd8f16  sub rsp, 0xF0
00007e4ecadd8f1d  vmovaps [rsp], xmm0
00007e4ecadd8f22  vmovaps [rsp+0x10], xmm2
00007e4ecadd8f28  vmovaps [rsp+0x20], xmm3
00007e4ecadd8f2e  vmovaps [rsp+0x30], xmm4
00007e4ecadd8f34  vmovaps [rsp+0x40], xmm5
00007e4ecadd8f3a  vmovaps [rsp+0x50], xmm6
00007e4ecadd8f40  vmovaps [rsp+0x60], xmm7
00007e4ecadd8f46  vmovaps [rsp+0x70], xmm8
00007e4ecadd8f4c  vmovaps [rsp+0x80], xmm9
00007e4ecadd8f55  vmovaps [rsp+0x90], xmm10
00007e4ecadd8f5e  vmovaps [rsp+0xA0], xmm11
00007e4ecadd8f67  vmovaps [rsp+0xB0], xmm12
00007e4ecadd8f70  vmovaps [rsp+0xC0], xmm13
00007e4ecadd8f79  vmovaps [rsp+0xD0], xmm14
00007e4ecadd8f82  vmovaps [rsp+0xE0], xmm15
00007e4ecadd8f8b  sub rsp, 0x30
00007e4ecadd8f8f  movaps [rsp], xmm1
00007e4ecadd8f93  movaps [rsp+0x10], xmm15
00007e4ecadd8f99  movaps [rsp+0x20], xmm6
00007e4ecadd8f9e  lea rdi, [rsp]
00007e4ecadd8fa2  mov esi, 0x00
00007e4ecadd8fa7  mov rax, 0x5784BC1F5530
00007e4ecadd8fb1  call rax
00007e4ecadd8fb3  movaps xmm1, [rsp]
00007e4ecadd8fb7  add rsp, 0x30
00007e4ecadd8fbb  vmovaps xmm0, [rsp]
00007e4ecadd8fc0  vmovaps xmm2, [rsp+0x10]
00007e4ecadd8fc6  vmovaps xmm3, [rsp+0x20]
00007e4ecadd8fcc  vmovaps xmm4, [rsp+0x30]
00007e4ecadd8fd2  vmovaps xmm5, [rsp+0x40]
00007e4ecadd8fd8  vmovaps xmm6, [rsp+0x50]
00007e4ecadd8fde  vmovaps xmm7, [rsp+0x60]
00007e4ecadd8fe4  vmovaps xmm8, [rsp+0x70]
00007e4ecadd8fea  vmovaps xmm9, [rsp+0x80]
00007e4ecadd8ff3  vmovaps xmm10, [rsp+0x90]
00007e4ecadd8ffc  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd9005  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd900e  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd9017  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd9020  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd9029  add rsp, 0xF0
00007e4ecadd9030  pop r11
00007e4ecadd9032  pop r10
00007e4ecadd9034  pop r9
00007e4ecadd9036  pop r8
00007e4ecadd9038  pop rsi
00007e4ecadd9039  pop rdi
00007e4ecadd903a  pop rdx
00007e4ecadd903b  pop rcx
00007e4ecadd903c  pop rax
00007e4ecadd903d  add rsp, 0x08
00007e4ecadd9041  jmp 0x00007E4ECADD61C2
00007e4ecadd9046  sub rsp, 0x08
00007e4ecadd904a  push rax
00007e4ecadd904b  push rcx
00007e4ecadd904c  push rdx
00007e4ecadd904d  push rdi
00007e4ecadd904e  push rsi
00007e4ecadd904f  push r8
00007e4ecadd9051  push r9
00007e4ecadd9053  push r10
00007e4ecadd9055  push r11
00007e4ecadd9057  sub rsp, 0xF0
00007e4ecadd905e  vmovaps [rsp], xmm0
00007e4ecadd9063  vmovaps [rsp+0x10], xmm1
00007e4ecadd9069  vmovaps [rsp+0x20], xmm2
00007e4ecadd906f  vmovaps [rsp+0x30], xmm3
00007e4ecadd9075  vmovaps [rsp+0x40], xmm4
00007e4ecadd907b  vmovaps [rsp+0x50], xmm5
00007e4ecadd9081  vmovaps [rsp+0x60], xmm6
00007e4ecadd9087  vmovaps [rsp+0x70], xmm7
00007e4ecadd908d  vmovaps [rsp+0x80], xmm8
00007e4ecadd9096  vmovaps [rsp+0x90], xmm9
00007e4ecadd909f  vmovaps [rsp+0xA0], xmm10
00007e4ecadd90a8  vmovaps [rsp+0xB0], xmm11
00007e4ecadd90b1  vmovaps [rsp+0xC0], xmm12
00007e4ecadd90ba  vmovaps [rsp+0xD0], xmm13
00007e4ecadd90c3  vmovaps [rsp+0xE0], xmm14
00007e4ecadd90cc  sub rsp, 0x30
00007e4ecadd90d0  movaps [rsp], xmm15
00007e4ecadd90d5  movaps [rsp+0x10], xmm5
00007e4ecadd90da  movaps [rsp+0x20], xmm3
00007e4ecadd90df  lea rdi, [rsp]
00007e4ecadd90e3  mov esi, 0x00
00007e4ecadd90e8  mov rax, 0x5784BC1F5530
00007e4ecadd90f2  call rax
00007e4ecadd90f4  movaps xmm15, [rsp]
00007e4ecadd90f9  add rsp, 0x30
00007e4ecadd90fd  vmovaps xmm0, [rsp]
00007e4ecadd9102  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9108  vmovaps xmm2, [rsp+0x20]
00007e4ecadd910e  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9114  vmovaps xmm4, [rsp+0x40]
00007e4ecadd911a  vmovaps xmm5, [rsp+0x50]
00007e4ecadd9120  vmovaps xmm6, [rsp+0x60]
00007e4ecadd9126  vmovaps xmm7, [rsp+0x70]
00007e4ecadd912c  vmovaps xmm8, [rsp+0x80]
00007e4ecadd9135  vmovaps xmm9, [rsp+0x90]
00007e4ecadd913e  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd9147  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd9150  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd9159  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd9162  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd916b  add rsp, 0xF0
00007e4ecadd9172  pop r11
00007e4ecadd9174  pop r10
00007e4ecadd9176  pop r9
00007e4ecadd9178  pop r8
00007e4ecadd917a  pop rsi
00007e4ecadd917b  pop rdi
00007e4ecadd917c  pop rdx
00007e4ecadd917d  pop rcx
00007e4ecadd917e  pop rax
00007e4ecadd917f  add rsp, 0x08
00007e4ecadd9183  jmp 0x00007E4ECADD61DC
00007e4ecadd9188  sub rsp, 0x08
00007e4ecadd918c  push rax
00007e4ecadd918d  push rcx
00007e4ecadd918e  push rdx
00007e4ecadd918f  push rdi
00007e4ecadd9190  push rsi
00007e4ecadd9191  push r8
00007e4ecadd9193  push r9
00007e4ecadd9195  push r10
00007e4ecadd9197  push r11
00007e4ecadd9199  sub rsp, 0xF0
00007e4ecadd91a0  vmovaps [rsp], xmm0
00007e4ecadd91a5  vmovaps [rsp+0x10], xmm1
00007e4ecadd91ab  vmovaps [rsp+0x20], xmm2
00007e4ecadd91b1  vmovaps [rsp+0x30], xmm3
00007e4ecadd91b7  vmovaps [rsp+0x40], xmm4
00007e4ecadd91bd  vmovaps [rsp+0x50], xmm6
00007e4ecadd91c3  vmovaps [rsp+0x60], xmm7
00007e4ecadd91c9  vmovaps [rsp+0x70], xmm8
00007e4ecadd91cf  vmovaps [rsp+0x80], xmm9
00007e4ecadd91d8  vmovaps [rsp+0x90], xmm10
00007e4ecadd91e1  vmovaps [rsp+0xA0], xmm11
00007e4ecadd91ea  vmovaps [rsp+0xB0], xmm12
00007e4ecadd91f3  vmovaps [rsp+0xC0], xmm13
00007e4ecadd91fc  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9205  vmovaps [rsp+0xE0], xmm15
00007e4ecadd920e  sub rsp, 0x30
00007e4ecadd9212  movaps [rsp], xmm5
00007e4ecadd9216  movaps [rsp+0x10], xmm8
00007e4ecadd921c  movaps [rsp+0x20], xmm6
00007e4ecadd9221  lea rdi, [rsp]
00007e4ecadd9225  mov esi, 0x00
00007e4ecadd922a  mov rax, 0x5784BC1F5530
00007e4ecadd9234  call rax
00007e4ecadd9236  movaps xmm5, [rsp]
00007e4ecadd923a  add rsp, 0x30
00007e4ecadd923e  vmovaps xmm0, [rsp]
00007e4ecadd9243  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9249  vmovaps xmm2, [rsp+0x20]
00007e4ecadd924f  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9255  vmovaps xmm4, [rsp+0x40]
00007e4ecadd925b  vmovaps xmm6, [rsp+0x50]
00007e4ecadd9261  vmovaps xmm7, [rsp+0x60]
00007e4ecadd9267  vmovaps xmm8, [rsp+0x70]
00007e4ecadd926d  vmovaps xmm9, [rsp+0x80]
00007e4ecadd9276  vmovaps xmm10, [rsp+0x90]
00007e4ecadd927f  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd9288  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd9291  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd929a  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd92a3  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd92ac  add rsp, 0xF0
00007e4ecadd92b3  pop r11
00007e4ecadd92b5  pop r10
00007e4ecadd92b7  pop r9
00007e4ecadd92b9  pop r8
00007e4ecadd92bb  pop rsi
00007e4ecadd92bc  pop rdi
00007e4ecadd92bd  pop rdx
00007e4ecadd92be  pop rcx
00007e4ecadd92bf  pop rax
00007e4ecadd92c0  add rsp, 0x08
00007e4ecadd92c4  jmp 0x00007E4ECADD6200
00007e4ecadd92c9  sub rsp, 0x08
00007e4ecadd92cd  push rax
00007e4ecadd92ce  push rcx
00007e4ecadd92cf  push rdx
00007e4ecadd92d0  push rdi
00007e4ecadd92d1  push rsi
00007e4ecadd92d2  push r8
00007e4ecadd92d4  push r9
00007e4ecadd92d6  push r10
00007e4ecadd92d8  push r11
00007e4ecadd92da  sub rsp, 0xF0
00007e4ecadd92e1  vmovaps [rsp], xmm0
00007e4ecadd92e6  vmovaps [rsp+0x10], xmm1
00007e4ecadd92ec  vmovaps [rsp+0x20], xmm2
00007e4ecadd92f2  vmovaps [rsp+0x30], xmm3
00007e4ecadd92f8  vmovaps [rsp+0x40], xmm4
00007e4ecadd92fe  vmovaps [rsp+0x50], xmm5
00007e4ecadd9304  vmovaps [rsp+0x60], xmm7
00007e4ecadd930a  vmovaps [rsp+0x70], xmm8
00007e4ecadd9310  vmovaps [rsp+0x80], xmm9
00007e4ecadd9319  vmovaps [rsp+0x90], xmm10
00007e4ecadd9322  vmovaps [rsp+0xA0], xmm11
00007e4ecadd932b  vmovaps [rsp+0xB0], xmm12
00007e4ecadd9334  vmovaps [rsp+0xC0], xmm13
00007e4ecadd933d  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9346  vmovaps [rsp+0xE0], xmm15
00007e4ecadd934f  sub rsp, 0x30
00007e4ecadd9353  movaps [rsp], xmm6
00007e4ecadd9357  movaps [rsp+0x10], xmm10
00007e4ecadd935d  movaps [rsp+0x20], xmm8
00007e4ecadd9363  lea rdi, [rsp]
00007e4ecadd9367  mov esi, 0x00
00007e4ecadd936c  mov rax, 0x5784BC1F5530
00007e4ecadd9376  call rax
00007e4ecadd9378  movaps xmm6, [rsp]
00007e4ecadd937c  add rsp, 0x30
00007e4ecadd9380  vmovaps xmm0, [rsp]
00007e4ecadd9385  vmovaps xmm1, [rsp+0x10]
00007e4ecadd938b  vmovaps xmm2, [rsp+0x20]
00007e4ecadd9391  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9397  vmovaps xmm4, [rsp+0x40]
00007e4ecadd939d  vmovaps xmm5, [rsp+0x50]
00007e4ecadd93a3  vmovaps xmm7, [rsp+0x60]
00007e4ecadd93a9  vmovaps xmm8, [rsp+0x70]
00007e4ecadd93af  vmovaps xmm9, [rsp+0x80]
00007e4ecadd93b8  vmovaps xmm10, [rsp+0x90]
00007e4ecadd93c1  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd93ca  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd93d3  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd93dc  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd93e5  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd93ee  add rsp, 0xF0
00007e4ecadd93f5  pop r11
00007e4ecadd93f7  pop r10
00007e4ecadd93f9  pop r9
00007e4ecadd93fb  pop r8
00007e4ecadd93fd  pop rsi
00007e4ecadd93fe  pop rdi
00007e4ecadd93ff  pop rdx
00007e4ecadd9400  pop rcx
00007e4ecadd9401  pop rax
00007e4ecadd9402  add rsp, 0x08
00007e4ecadd9406  jmp 0x00007E4ECADD6225
00007e4ecadd940b  sub rsp, 0x08
00007e4ecadd940f  push rax
00007e4ecadd9410  push rcx
00007e4ecadd9411  push rdx
00007e4ecadd9412  push rdi
00007e4ecadd9413  push rsi
00007e4ecadd9414  push r8
00007e4ecadd9416  push r9
00007e4ecadd9418  push r10
00007e4ecadd941a  push r11
00007e4ecadd941c  sub rsp, 0xF0
00007e4ecadd9423  vmovaps [rsp], xmm0
00007e4ecadd9428  vmovaps [rsp+0x10], xmm1
00007e4ecadd942e  vmovaps [rsp+0x20], xmm2
00007e4ecadd9434  vmovaps [rsp+0x30], xmm3
00007e4ecadd943a  vmovaps [rsp+0x40], xmm4
00007e4ecadd9440  vmovaps [rsp+0x50], xmm5
00007e4ecadd9446  vmovaps [rsp+0x60], xmm6
00007e4ecadd944c  vmovaps [rsp+0x70], xmm7
00007e4ecadd9452  vmovaps [rsp+0x80], xmm8
00007e4ecadd945b  vmovaps [rsp+0x90], xmm9
00007e4ecadd9464  vmovaps [rsp+0xA0], xmm11
00007e4ecadd946d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd9476  vmovaps [rsp+0xC0], xmm13
00007e4ecadd947f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9488  vmovaps [rsp+0xE0], xmm15
00007e4ecadd9491  sub rsp, 0x30
00007e4ecadd9495  movaps [rsp], xmm10
00007e4ecadd949a  movaps [rsp+0x10], xmm8
00007e4ecadd94a0  movaps [rsp+0x20], xmm14
00007e4ecadd94a6  lea rdi, [rsp]
00007e4ecadd94aa  mov esi, 0x00
00007e4ecadd94af  mov rax, 0x5784BC1F5530
00007e4ecadd94b9  call rax
00007e4ecadd94bb  movaps xmm10, [rsp]
00007e4ecadd94c0  add rsp, 0x30
00007e4ecadd94c4  vmovaps xmm0, [rsp]
00007e4ecadd94c9  vmovaps xmm1, [rsp+0x10]
00007e4ecadd94cf  vmovaps xmm2, [rsp+0x20]
00007e4ecadd94d5  vmovaps xmm3, [rsp+0x30]
00007e4ecadd94db  vmovaps xmm4, [rsp+0x40]
00007e4ecadd94e1  vmovaps xmm5, [rsp+0x50]
00007e4ecadd94e7  vmovaps xmm6, [rsp+0x60]
00007e4ecadd94ed  vmovaps xmm7, [rsp+0x70]
00007e4ecadd94f3  vmovaps xmm8, [rsp+0x80]
00007e4ecadd94fc  vmovaps xmm9, [rsp+0x90]
00007e4ecadd9505  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd950e  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd9517  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd9520  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd9529  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd9532  add rsp, 0xF0
00007e4ecadd9539  pop r11
00007e4ecadd953b  pop r10
00007e4ecadd953d  pop r9
00007e4ecadd953f  pop r8
00007e4ecadd9541  pop rsi
00007e4ecadd9542  pop rdi
00007e4ecadd9543  pop rdx
00007e4ecadd9544  pop rcx
00007e4ecadd9545  pop rax
00007e4ecadd9546  add rsp, 0x08
00007e4ecadd954a  jmp 0x00007E4ECADD6245
00007e4ecadd954f  sub rsp, 0x08
00007e4ecadd9553  push rax
00007e4ecadd9554  push rcx
00007e4ecadd9555  push rdx
00007e4ecadd9556  push rdi
00007e4ecadd9557  push rsi
00007e4ecadd9558  push r8
00007e4ecadd955a  push r9
00007e4ecadd955c  push r10
00007e4ecadd955e  push r11
00007e4ecadd9560  sub rsp, 0xF0
00007e4ecadd9567  vmovaps [rsp], xmm0
00007e4ecadd956c  vmovaps [rsp+0x10], xmm1
00007e4ecadd9572  vmovaps [rsp+0x20], xmm2
00007e4ecadd9578  vmovaps [rsp+0x30], xmm3
00007e4ecadd957e  vmovaps [rsp+0x40], xmm4
00007e4ecadd9584  vmovaps [rsp+0x50], xmm5
00007e4ecadd958a  vmovaps [rsp+0x60], xmm6
00007e4ecadd9590  vmovaps [rsp+0x70], xmm7
00007e4ecadd9596  vmovaps [rsp+0x80], xmm8
00007e4ecadd959f  vmovaps [rsp+0x90], xmm9
00007e4ecadd95a8  vmovaps [rsp+0xA0], xmm10
00007e4ecadd95b1  vmovaps [rsp+0xB0], xmm11
00007e4ecadd95ba  vmovaps [rsp+0xC0], xmm12
00007e4ecadd95c3  vmovaps [rsp+0xD0], xmm13
00007e4ecadd95cc  vmovaps [rsp+0xE0], xmm15
00007e4ecadd95d5  sub rsp, 0x30
00007e4ecadd95d9  movaps [rsp], xmm14
00007e4ecadd95de  movaps [rsp+0x10], xmm8
00007e4ecadd95e4  movaps [rsp+0x20], xmm4
00007e4ecadd95e9  lea rdi, [rsp]
00007e4ecadd95ed  mov esi, 0x00
00007e4ecadd95f2  mov rax, 0x5784BC1F5530
00007e4ecadd95fc  call rax
00007e4ecadd95fe  movaps xmm14, [rsp]
00007e4ecadd9603  add rsp, 0x30
00007e4ecadd9607  vmovaps xmm0, [rsp]
00007e4ecadd960c  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9612  vmovaps xmm2, [rsp+0x20]
00007e4ecadd9618  vmovaps xmm3, [rsp+0x30]
00007e4ecadd961e  vmovaps xmm4, [rsp+0x40]
00007e4ecadd9624  vmovaps xmm5, [rsp+0x50]
00007e4ecadd962a  vmovaps xmm6, [rsp+0x60]
00007e4ecadd9630  vmovaps xmm7, [rsp+0x70]
00007e4ecadd9636  vmovaps xmm8, [rsp+0x80]
00007e4ecadd963f  vmovaps xmm9, [rsp+0x90]
00007e4ecadd9648  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd9651  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd965a  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd9663  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd966c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd9675  add rsp, 0xF0
00007e4ecadd967c  pop r11
00007e4ecadd967e  pop r10
00007e4ecadd9680  pop r9
00007e4ecadd9682  pop r8
00007e4ecadd9684  pop rsi
00007e4ecadd9685  pop rdi
00007e4ecadd9686  pop rdx
00007e4ecadd9687  pop rcx
00007e4ecadd9688  pop rax
00007e4ecadd9689  add rsp, 0x08
00007e4ecadd968d  jmp 0x00007E4ECADD6265
00007e4ecadd9692  sub rsp, 0x08
00007e4ecadd9696  push rax
00007e4ecadd9697  push rcx
00007e4ecadd9698  push rdx
00007e4ecadd9699  push rdi
00007e4ecadd969a  push rsi
00007e4ecadd969b  push r8
00007e4ecadd969d  push r9
00007e4ecadd969f  push r10
00007e4ecadd96a1  push r11
00007e4ecadd96a3  sub rsp, 0xF0
00007e4ecadd96aa  vmovaps [rsp], xmm0
00007e4ecadd96af  vmovaps [rsp+0x10], xmm1
00007e4ecadd96b5  vmovaps [rsp+0x20], xmm2
00007e4ecadd96bb  vmovaps [rsp+0x30], xmm3
00007e4ecadd96c1  vmovaps [rsp+0x40], xmm5
00007e4ecadd96c7  vmovaps [rsp+0x50], xmm6
00007e4ecadd96cd  vmovaps [rsp+0x60], xmm7
00007e4ecadd96d3  vmovaps [rsp+0x70], xmm8
00007e4ecadd96d9  vmovaps [rsp+0x80], xmm9
00007e4ecadd96e2  vmovaps [rsp+0x90], xmm10
00007e4ecadd96eb  vmovaps [rsp+0xA0], xmm11
00007e4ecadd96f4  vmovaps [rsp+0xB0], xmm12
00007e4ecadd96fd  vmovaps [rsp+0xC0], xmm13
00007e4ecadd9706  vmovaps [rsp+0xD0], xmm14
00007e4ecadd970f  vmovaps [rsp+0xE0], xmm15
00007e4ecadd9718  sub rsp, 0x30
00007e4ecadd971c  movaps [rsp], xmm4
00007e4ecadd9720  movaps [rsp+0x10], xmm13
00007e4ecadd9726  movaps [rsp+0x20], xmm8
00007e4ecadd972c  lea rdi, [rsp]
00007e4ecadd9730  mov esi, 0x00
00007e4ecadd9735  mov rax, 0x5784BC1F5530
00007e4ecadd973f  call rax
00007e4ecadd9741  movaps xmm4, [rsp]
00007e4ecadd9745  add rsp, 0x30
00007e4ecadd9749  vmovaps xmm0, [rsp]
00007e4ecadd974e  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9754  vmovaps xmm2, [rsp+0x20]
00007e4ecadd975a  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9760  vmovaps xmm5, [rsp+0x40]
00007e4ecadd9766  vmovaps xmm6, [rsp+0x50]
00007e4ecadd976c  vmovaps xmm7, [rsp+0x60]
00007e4ecadd9772  vmovaps xmm8, [rsp+0x70]
00007e4ecadd9778  vmovaps xmm9, [rsp+0x80]
00007e4ecadd9781  vmovaps xmm10, [rsp+0x90]
00007e4ecadd978a  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd9793  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd979c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd97a5  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd97ae  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd97b7  add rsp, 0xF0
00007e4ecadd97be  pop r11
00007e4ecadd97c0  pop r10
00007e4ecadd97c2  pop r9
00007e4ecadd97c4  pop r8
00007e4ecadd97c6  pop rsi
00007e4ecadd97c7  pop rdi
00007e4ecadd97c8  pop rdx
00007e4ecadd97c9  pop rcx
00007e4ecadd97ca  pop rax
00007e4ecadd97cb  add rsp, 0x08
00007e4ecadd97cf  jmp 0x00007E4ECADD628A
00007e4ecadd97d4  sub rsp, 0x08
00007e4ecadd97d8  push rax
00007e4ecadd97d9  push rcx
00007e4ecadd97da  push rdx
00007e4ecadd97db  push rdi
00007e4ecadd97dc  push rsi
00007e4ecadd97dd  push r8
00007e4ecadd97df  push r9
00007e4ecadd97e1  push r10
00007e4ecadd97e3  push r11
00007e4ecadd97e5  sub rsp, 0xF0
00007e4ecadd97ec  vmovaps [rsp], xmm0
00007e4ecadd97f1  vmovaps [rsp+0x10], xmm1
00007e4ecadd97f7  vmovaps [rsp+0x20], xmm2
00007e4ecadd97fd  vmovaps [rsp+0x30], xmm3
00007e4ecadd9803  vmovaps [rsp+0x40], xmm4
00007e4ecadd9809  vmovaps [rsp+0x50], xmm5
00007e4ecadd980f  vmovaps [rsp+0x60], xmm6
00007e4ecadd9815  vmovaps [rsp+0x70], xmm7
00007e4ecadd981b  vmovaps [rsp+0x80], xmm8
00007e4ecadd9824  vmovaps [rsp+0x90], xmm9
00007e4ecadd982d  vmovaps [rsp+0xA0], xmm10
00007e4ecadd9836  vmovaps [rsp+0xB0], xmm11
00007e4ecadd983f  vmovaps [rsp+0xC0], xmm12
00007e4ecadd9848  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9851  vmovaps [rsp+0xE0], xmm15
00007e4ecadd985a  sub rsp, 0x30
00007e4ecadd985e  movaps [rsp], xmm13
00007e4ecadd9863  movaps [rsp+0x10], xmm15
00007e4ecadd9869  movaps [rsp+0x20], xmm9
00007e4ecadd986f  lea rdi, [rsp]
00007e4ecadd9873  mov esi, 0x00
00007e4ecadd9878  mov rax, 0x5784BC1F5530
00007e4ecadd9882  call rax
00007e4ecadd9884  movaps xmm13, [rsp]
00007e4ecadd9889  add rsp, 0x30
00007e4ecadd988d  vmovaps xmm0, [rsp]
00007e4ecadd9892  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9898  vmovaps xmm2, [rsp+0x20]
00007e4ecadd989e  vmovaps xmm3, [rsp+0x30]
00007e4ecadd98a4  vmovaps xmm4, [rsp+0x40]
00007e4ecadd98aa  vmovaps xmm5, [rsp+0x50]
00007e4ecadd98b0  vmovaps xmm6, [rsp+0x60]
00007e4ecadd98b6  vmovaps xmm7, [rsp+0x70]
00007e4ecadd98bc  vmovaps xmm8, [rsp+0x80]
00007e4ecadd98c5  vmovaps xmm9, [rsp+0x90]
00007e4ecadd98ce  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd98d7  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd98e0  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd98e9  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd98f2  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd98fb  add rsp, 0xF0
00007e4ecadd9902  pop r11
00007e4ecadd9904  pop r10
00007e4ecadd9906  pop r9
00007e4ecadd9908  pop r8
00007e4ecadd990a  pop rsi
00007e4ecadd990b  pop rdi
00007e4ecadd990c  pop rdx
00007e4ecadd990d  pop rcx
00007e4ecadd990e  pop rax
00007e4ecadd990f  add rsp, 0x08
00007e4ecadd9913  jmp 0x00007E4ECADD62A5
00007e4ecadd9918  sub rsp, 0x08
00007e4ecadd991c  push rax
00007e4ecadd991d  push rcx
00007e4ecadd991e  push rdx
00007e4ecadd991f  push rdi
00007e4ecadd9920  push rsi
00007e4ecadd9921  push r8
00007e4ecadd9923  push r9
00007e4ecadd9925  push r10
00007e4ecadd9927  push r11
00007e4ecadd9929  sub rsp, 0xF0
00007e4ecadd9930  vmovaps [rsp], xmm0
00007e4ecadd9935  vmovaps [rsp+0x10], xmm1
00007e4ecadd993b  vmovaps [rsp+0x20], xmm2
00007e4ecadd9941  vmovaps [rsp+0x30], xmm3
00007e4ecadd9947  vmovaps [rsp+0x40], xmm4
00007e4ecadd994d  vmovaps [rsp+0x50], xmm5
00007e4ecadd9953  vmovaps [rsp+0x60], xmm6
00007e4ecadd9959  vmovaps [rsp+0x70], xmm7
00007e4ecadd995f  vmovaps [rsp+0x80], xmm8
00007e4ecadd9968  vmovaps [rsp+0x90], xmm9
00007e4ecadd9971  vmovaps [rsp+0xA0], xmm10
00007e4ecadd997a  vmovaps [rsp+0xB0], xmm11
00007e4ecadd9983  vmovaps [rsp+0xC0], xmm12
00007e4ecadd998c  vmovaps [rsp+0xD0], xmm13
00007e4ecadd9995  vmovaps [rsp+0xE0], xmm14
00007e4ecadd999e  sub rsp, 0x30
00007e4ecadd99a2  movaps [rsp], xmm15
00007e4ecadd99a7  movaps [rsp+0x10], xmm1
00007e4ecadd99ac  movaps [rsp+0x20], xmm5
00007e4ecadd99b1  lea rdi, [rsp]
00007e4ecadd99b5  mov esi, 0x00
00007e4ecadd99ba  mov rax, 0x5784BC1F5530
00007e4ecadd99c4  call rax
00007e4ecadd99c6  movaps xmm15, [rsp]
00007e4ecadd99cb  add rsp, 0x30
00007e4ecadd99cf  vmovaps xmm0, [rsp]
00007e4ecadd99d4  vmovaps xmm1, [rsp+0x10]
00007e4ecadd99da  vmovaps xmm2, [rsp+0x20]
00007e4ecadd99e0  vmovaps xmm3, [rsp+0x30]
00007e4ecadd99e6  vmovaps xmm4, [rsp+0x40]
00007e4ecadd99ec  vmovaps xmm5, [rsp+0x50]
00007e4ecadd99f2  vmovaps xmm6, [rsp+0x60]
00007e4ecadd99f8  vmovaps xmm7, [rsp+0x70]
00007e4ecadd99fe  vmovaps xmm8, [rsp+0x80]
00007e4ecadd9a07  vmovaps xmm9, [rsp+0x90]
00007e4ecadd9a10  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd9a19  vmovaps xmm11, [rsp+0xB0]
00007e4ecadd9a22  vmovaps xmm12, [rsp+0xC0]
00007e4ecadd9a2b  vmovaps xmm13, [rsp+0xD0]
00007e4ecadd9a34  vmovaps xmm14, [rsp+0xE0]
00007e4ecadd9a3d  add rsp, 0xF0
00007e4ecadd9a44  pop r11
00007e4ecadd9a46  pop r10
00007e4ecadd9a48  pop r9
00007e4ecadd9a4a  pop r8
00007e4ecadd9a4c  pop rsi
00007e4ecadd9a4d  pop rdi
00007e4ecadd9a4e  pop rdx
00007e4ecadd9a4f  pop rcx
00007e4ecadd9a50  pop rax
00007e4ecadd9a51  add rsp, 0x08
00007e4ecadd9a55  jmp 0x00007E4ECADD62C0
00007e4ecadd9a5a  call 0x00007E4ECACD64F0
00007e4ecadd9a5f  jmp 0x00007E4ECADD631B
00007e4ecadd9a64  sub rsp, 0x08
00007e4ecadd9a68  push rax
00007e4ecadd9a69  push rcx
00007e4ecadd9a6a  push rdx
00007e4ecadd9a6b  push rdi
00007e4ecadd9a6c  push rsi
00007e4ecadd9a6d  push r8
00007e4ecadd9a6f  push r9
00007e4ecadd9a71  push r10
00007e4ecadd9a73  push r11
00007e4ecadd9a75  sub rsp, 0xF0
00007e4ecadd9a7c  vmovaps [rsp], xmm0
00007e4ecadd9a81  vmovaps [rsp+0x10], xmm1
00007e4ecadd9a87  vmovaps [rsp+0x20], xmm2
00007e4ecadd9a8d  vmovaps [rsp+0x30], xmm3
00007e4ecadd9a93  vmovaps [rsp+0x40], xmm4
00007e4ecadd9a99  vmovaps [rsp+0x50], xmm5
00007e4ecadd9a9f  vmovaps [rsp+0x60], xmm6
00007e4ecadd9aa5  vmovaps [rsp+0x70], xmm7
00007e4ecadd9aab  vmovaps [rsp+0x80], xmm8
00007e4ecadd9ab4  vmovaps [rsp+0x90], xmm10
00007e4ecadd9abd  vmovaps [rsp+0xA0], xmm11
00007e4ecadd9ac6  vmovaps [rsp+0xB0], xmm12
00007e4ecadd9acf  vmovaps [rsp+0xC0], xmm13
00007e4ecadd9ad8  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9ae1  vmovaps [rsp+0xE0], xmm15
00007e4ecadd9aea  sub rsp, 0x30
00007e4ecadd9aee  movaps [rsp], xmm9
00007e4ecadd9af3  movaps [rsp+0x10], xmm8
00007e4ecadd9af9  movaps [rsp+0x20], xmm11
00007e4ecadd9aff  lea rdi, [rsp]
00007e4ecadd9b03  mov esi, 0x00
00007e4ecadd9b08  mov rax, 0x5784BC1F5530
00007e4ecadd9b12  call rax
00007e4ecadd9b14  movaps xmm9, [rsp]
00007e4ecadd9b19  add rsp, 0x30
00007e4ecadd9b1d  vmovaps xmm0, [rsp]
00007e4ecadd9b22  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9b28  vmovaps xmm2, [rsp+0x20]
00007e4ecadd9b2e  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9b34  vmovaps xmm4, [rsp+0x40]
00007e4ecadd9b3a  vmovaps xmm5, [rsp+0x50]
00007e4ecadd9b40  vmovaps xmm6, [rsp+0x60]
00007e4ecadd9b46  vmovaps xmm7, [rsp+0x70]
00007e4ecadd9b4c  vmovaps xmm8, [rsp+0x80]
00007e4ecadd9b55  vmovaps xmm10, [rsp+0x90]
00007e4ecadd9b5e  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd9b67  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd9b70  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd9b79  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd9b82  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd9b8b  add rsp, 0xF0
00007e4ecadd9b92  pop r11
00007e4ecadd9b94  pop r10
00007e4ecadd9b96  pop r9
00007e4ecadd9b98  pop r8
00007e4ecadd9b9a  pop rsi
00007e4ecadd9b9b  pop rdi
00007e4ecadd9b9c  pop rdx
00007e4ecadd9b9d  pop rcx
00007e4ecadd9b9e  pop rax
00007e4ecadd9b9f  add rsp, 0x08
00007e4ecadd9ba3  jmp 0x00007E4ECADD6352
00007e4ecadd9ba8  sub rsp, 0x08
00007e4ecadd9bac  push rax
00007e4ecadd9bad  push rcx
00007e4ecadd9bae  push rdx
00007e4ecadd9baf  push rdi
00007e4ecadd9bb0  push rsi
00007e4ecadd9bb1  push r8
00007e4ecadd9bb3  push r9
00007e4ecadd9bb5  push r10
00007e4ecadd9bb7  push r11
00007e4ecadd9bb9  sub rsp, 0xF0
00007e4ecadd9bc0  vmovaps [rsp], xmm0
00007e4ecadd9bc5  vmovaps [rsp+0x10], xmm1
00007e4ecadd9bcb  vmovaps [rsp+0x20], xmm2
00007e4ecadd9bd1  vmovaps [rsp+0x30], xmm3
00007e4ecadd9bd7  vmovaps [rsp+0x40], xmm4
00007e4ecadd9bdd  vmovaps [rsp+0x50], xmm5
00007e4ecadd9be3  vmovaps [rsp+0x60], xmm6
00007e4ecadd9be9  vmovaps [rsp+0x70], xmm7
00007e4ecadd9bef  vmovaps [rsp+0x80], xmm8
00007e4ecadd9bf8  vmovaps [rsp+0x90], xmm9
00007e4ecadd9c01  vmovaps [rsp+0xA0], xmm10
00007e4ecadd9c0a  vmovaps [rsp+0xB0], xmm12
00007e4ecadd9c13  vmovaps [rsp+0xC0], xmm13
00007e4ecadd9c1c  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9c25  vmovaps [rsp+0xE0], xmm15
00007e4ecadd9c2e  sub rsp, 0x30
00007e4ecadd9c32  movaps [rsp], xmm11
00007e4ecadd9c37  movaps [rsp+0x10], xmm10
00007e4ecadd9c3d  movaps [rsp+0x20], xmm6
00007e4ecadd9c42  lea rdi, [rsp]
00007e4ecadd9c46  mov esi, 0x00
00007e4ecadd9c4b  mov rax, 0x5784BC1F5530
00007e4ecadd9c55  call rax
00007e4ecadd9c57  movaps xmm11, [rsp]
00007e4ecadd9c5c  add rsp, 0x30
00007e4ecadd9c60  vmovaps xmm0, [rsp]
00007e4ecadd9c65  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9c6b  vmovaps xmm2, [rsp+0x20]
00007e4ecadd9c71  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9c77  vmovaps xmm4, [rsp+0x40]
00007e4ecadd9c7d  vmovaps xmm5, [rsp+0x50]
00007e4ecadd9c83  vmovaps xmm6, [rsp+0x60]
00007e4ecadd9c89  vmovaps xmm7, [rsp+0x70]
00007e4ecadd9c8f  vmovaps xmm8, [rsp+0x80]
00007e4ecadd9c98  vmovaps xmm9, [rsp+0x90]
00007e4ecadd9ca1  vmovaps xmm10, [rsp+0xA0]
00007e4ecadd9caa  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd9cb3  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd9cbc  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd9cc5  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd9cce  add rsp, 0xF0
00007e4ecadd9cd5  pop r11
00007e4ecadd9cd7  pop r10
00007e4ecadd9cd9  pop r9
00007e4ecadd9cdb  pop r8
00007e4ecadd9cdd  pop rsi
00007e4ecadd9cde  pop rdi
00007e4ecadd9cdf  pop rdx
00007e4ecadd9ce0  pop rcx
00007e4ecadd9ce1  pop rax
00007e4ecadd9ce2  add rsp, 0x08
00007e4ecadd9ce6  jmp 0x00007E4ECADD636D
00007e4ecadd9ceb  sub rsp, 0x08
00007e4ecadd9cef  push rax
00007e4ecadd9cf0  push rcx
00007e4ecadd9cf1  push rdx
00007e4ecadd9cf2  push rdi
00007e4ecadd9cf3  push rsi
00007e4ecadd9cf4  push r8
00007e4ecadd9cf6  push r9
00007e4ecadd9cf8  push r10
00007e4ecadd9cfa  push r11
00007e4ecadd9cfc  sub rsp, 0xF0
00007e4ecadd9d03  vmovaps [rsp], xmm0
00007e4ecadd9d08  vmovaps [rsp+0x10], xmm1
00007e4ecadd9d0e  vmovaps [rsp+0x20], xmm2
00007e4ecadd9d14  vmovaps [rsp+0x30], xmm3
00007e4ecadd9d1a  vmovaps [rsp+0x40], xmm4
00007e4ecadd9d20  vmovaps [rsp+0x50], xmm5
00007e4ecadd9d26  vmovaps [rsp+0x60], xmm6
00007e4ecadd9d2c  vmovaps [rsp+0x70], xmm7
00007e4ecadd9d32  vmovaps [rsp+0x80], xmm8
00007e4ecadd9d3b  vmovaps [rsp+0x90], xmm9
00007e4ecadd9d44  vmovaps [rsp+0xA0], xmm11
00007e4ecadd9d4d  vmovaps [rsp+0xB0], xmm12
00007e4ecadd9d56  vmovaps [rsp+0xC0], xmm13
00007e4ecadd9d5f  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9d68  vmovaps [rsp+0xE0], xmm15
00007e4ecadd9d71  sub rsp, 0x30
00007e4ecadd9d75  movaps [rsp], xmm10
00007e4ecadd9d7a  movaps [rsp+0x10], xmm14
00007e4ecadd9d80  movaps [rsp+0x20], xmm4
00007e4ecadd9d85  lea rdi, [rsp]
00007e4ecadd9d89  mov esi, 0x00
00007e4ecadd9d8e  mov rax, 0x5784BC1F5530
00007e4ecadd9d98  call rax
00007e4ecadd9d9a  movaps xmm10, [rsp]
00007e4ecadd9d9f  add rsp, 0x30
00007e4ecadd9da3  vmovaps xmm0, [rsp]
00007e4ecadd9da8  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9dae  vmovaps xmm2, [rsp+0x20]
00007e4ecadd9db4  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9dba  vmovaps xmm4, [rsp+0x40]
00007e4ecadd9dc0  vmovaps xmm5, [rsp+0x50]
00007e4ecadd9dc6  vmovaps xmm6, [rsp+0x60]
00007e4ecadd9dcc  vmovaps xmm7, [rsp+0x70]
00007e4ecadd9dd2  vmovaps xmm8, [rsp+0x80]
00007e4ecadd9ddb  vmovaps xmm9, [rsp+0x90]
00007e4ecadd9de4  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd9ded  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd9df6  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd9dff  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd9e08  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd9e11  add rsp, 0xF0
00007e4ecadd9e18  pop r11
00007e4ecadd9e1a  pop r10
00007e4ecadd9e1c  pop r9
00007e4ecadd9e1e  pop r8
00007e4ecadd9e20  pop rsi
00007e4ecadd9e21  pop rdi
00007e4ecadd9e22  pop rdx
00007e4ecadd9e23  pop rcx
00007e4ecadd9e24  pop rax
00007e4ecadd9e25  add rsp, 0x08
00007e4ecadd9e29  jmp 0x00007E4ECADD6388
00007e4ecadd9e2e  sub rsp, 0x08
00007e4ecadd9e32  push rax
00007e4ecadd9e33  push rcx
00007e4ecadd9e34  push rdx
00007e4ecadd9e35  push rdi
00007e4ecadd9e36  push rsi
00007e4ecadd9e37  push r8
00007e4ecadd9e39  push r9
00007e4ecadd9e3b  push r10
00007e4ecadd9e3d  push r11
00007e4ecadd9e3f  sub rsp, 0xF0
00007e4ecadd9e46  vmovaps [rsp], xmm0
00007e4ecadd9e4b  vmovaps [rsp+0x10], xmm1
00007e4ecadd9e51  vmovaps [rsp+0x20], xmm2
00007e4ecadd9e57  vmovaps [rsp+0x30], xmm3
00007e4ecadd9e5d  vmovaps [rsp+0x40], xmm4
00007e4ecadd9e63  vmovaps [rsp+0x50], xmm5
00007e4ecadd9e69  vmovaps [rsp+0x60], xmm6
00007e4ecadd9e6f  vmovaps [rsp+0x70], xmm7
00007e4ecadd9e75  vmovaps [rsp+0x80], xmm9
00007e4ecadd9e7e  vmovaps [rsp+0x90], xmm10
00007e4ecadd9e87  vmovaps [rsp+0xA0], xmm11
00007e4ecadd9e90  vmovaps [rsp+0xB0], xmm12
00007e4ecadd9e99  vmovaps [rsp+0xC0], xmm13
00007e4ecadd9ea2  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9eab  vmovaps [rsp+0xE0], xmm15
00007e4ecadd9eb4  sub rsp, 0x30
00007e4ecadd9eb8  movaps [rsp], xmm8
00007e4ecadd9ebd  movaps [rsp+0x10], xmm1
00007e4ecadd9ec2  movaps [rsp+0x20], xmm14
00007e4ecadd9ec8  lea rdi, [rsp]
00007e4ecadd9ecc  mov esi, 0x00
00007e4ecadd9ed1  mov rax, 0x5784BC1F5530
00007e4ecadd9edb  call rax
00007e4ecadd9edd  movaps xmm8, [rsp]
00007e4ecadd9ee2  add rsp, 0x30
00007e4ecadd9ee6  vmovaps xmm0, [rsp]
00007e4ecadd9eeb  vmovaps xmm1, [rsp+0x10]
00007e4ecadd9ef1  vmovaps xmm2, [rsp+0x20]
00007e4ecadd9ef7  vmovaps xmm3, [rsp+0x30]
00007e4ecadd9efd  vmovaps xmm4, [rsp+0x40]
00007e4ecadd9f03  vmovaps xmm5, [rsp+0x50]
00007e4ecadd9f09  vmovaps xmm6, [rsp+0x60]
00007e4ecadd9f0f  vmovaps xmm7, [rsp+0x70]
00007e4ecadd9f15  vmovaps xmm9, [rsp+0x80]
00007e4ecadd9f1e  vmovaps xmm10, [rsp+0x90]
00007e4ecadd9f27  vmovaps xmm11, [rsp+0xA0]
00007e4ecadd9f30  vmovaps xmm12, [rsp+0xB0]
00007e4ecadd9f39  vmovaps xmm13, [rsp+0xC0]
00007e4ecadd9f42  vmovaps xmm14, [rsp+0xD0]
00007e4ecadd9f4b  vmovaps xmm15, [rsp+0xE0]
00007e4ecadd9f54  add rsp, 0xF0
00007e4ecadd9f5b  pop r11
00007e4ecadd9f5d  pop r10
00007e4ecadd9f5f  pop r9
00007e4ecadd9f61  pop r8
00007e4ecadd9f63  pop rsi
00007e4ecadd9f64  pop rdi
00007e4ecadd9f65  pop rdx
00007e4ecadd9f66  pop rcx
00007e4ecadd9f67  pop rax
00007e4ecadd9f68  add rsp, 0x08
00007e4ecadd9f6c  jmp 0x00007E4ECADD63AE
00007e4ecadd9f71  sub rsp, 0x08
00007e4ecadd9f75  push rax
00007e4ecadd9f76  push rcx
00007e4ecadd9f77  push rdx
00007e4ecadd9f78  push rdi
00007e4ecadd9f79  push rsi
00007e4ecadd9f7a  push r8
00007e4ecadd9f7c  push r9
00007e4ecadd9f7e  push r10
00007e4ecadd9f80  push r11
00007e4ecadd9f82  sub rsp, 0xF0
00007e4ecadd9f89  vmovaps [rsp], xmm0
00007e4ecadd9f8e  vmovaps [rsp+0x10], xmm1
00007e4ecadd9f94  vmovaps [rsp+0x20], xmm2
00007e4ecadd9f9a  vmovaps [rsp+0x30], xmm3
00007e4ecadd9fa0  vmovaps [rsp+0x40], xmm4
00007e4ecadd9fa6  vmovaps [rsp+0x50], xmm5
00007e4ecadd9fac  vmovaps [rsp+0x60], xmm7
00007e4ecadd9fb2  vmovaps [rsp+0x70], xmm8
00007e4ecadd9fb8  vmovaps [rsp+0x80], xmm9
00007e4ecadd9fc1  vmovaps [rsp+0x90], xmm10
00007e4ecadd9fca  vmovaps [rsp+0xA0], xmm11
00007e4ecadd9fd3  vmovaps [rsp+0xB0], xmm12
00007e4ecadd9fdc  vmovaps [rsp+0xC0], xmm13
00007e4ecadd9fe5  vmovaps [rsp+0xD0], xmm14
00007e4ecadd9fee  vmovaps [rsp+0xE0], xmm15
00007e4ecadd9ff7  sub rsp, 0x30
00007e4ecadd9ffb  movaps [rsp], xmm6
00007e4ecadd9fff  movaps [rsp+0x10], xmm1
00007e4ecadda004  movaps [rsp+0x20], xmm14
00007e4ecadda00a  lea rdi, [rsp]
00007e4ecadda00e  mov esi, 0x00
00007e4ecadda013  mov rax, 0x5784BC1F5530
00007e4ecadda01d  call rax
00007e4ecadda01f  movaps xmm6, [rsp]
00007e4ecadda023  add rsp, 0x30
00007e4ecadda027  vmovaps xmm0, [rsp]
00007e4ecadda02c  vmovaps xmm1, [rsp+0x10]
00007e4ecadda032  vmovaps xmm2, [rsp+0x20]
00007e4ecadda038  vmovaps xmm3, [rsp+0x30]
00007e4ecadda03e  vmovaps xmm4, [rsp+0x40]
00007e4ecadda044  vmovaps xmm5, [rsp+0x50]
00007e4ecadda04a  vmovaps xmm7, [rsp+0x60]
00007e4ecadda050  vmovaps xmm8, [rsp+0x70]
00007e4ecadda056  vmovaps xmm9, [rsp+0x80]
00007e4ecadda05f  vmovaps xmm10, [rsp+0x90]
00007e4ecadda068  vmovaps xmm11, [rsp+0xA0]
00007e4ecadda071  vmovaps xmm12, [rsp+0xB0]
00007e4ecadda07a  vmovaps xmm13, [rsp+0xC0]
00007e4ecadda083  vmovaps xmm14, [rsp+0xD0]
00007e4ecadda08c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadda095  add rsp, 0xF0
00007e4ecadda09c  pop r11
00007e4ecadda09e  pop r10
00007e4ecadda0a0  pop r9
00007e4ecadda0a2  pop r8
00007e4ecadda0a4  pop rsi
00007e4ecadda0a5  pop rdi
00007e4ecadda0a6  pop rdx
00007e4ecadda0a7  pop rcx
00007e4ecadda0a8  pop rax
00007e4ecadda0a9  add rsp, 0x08
00007e4ecadda0ad  jmp 0x00007E4ECADD63DA
00007e4ecadda0b2  sub rsp, 0x08
00007e4ecadda0b6  push rax
00007e4ecadda0b7  push rcx
00007e4ecadda0b8  push rdx
00007e4ecadda0b9  push rdi
00007e4ecadda0ba  push rsi
00007e4ecadda0bb  push r8
00007e4ecadda0bd  push r9
00007e4ecadda0bf  push r10
00007e4ecadda0c1  push r11
00007e4ecadda0c3  sub rsp, 0xF0
00007e4ecadda0ca  vmovaps [rsp], xmm0
00007e4ecadda0cf  vmovaps [rsp+0x10], xmm1
00007e4ecadda0d5  vmovaps [rsp+0x20], xmm2
00007e4ecadda0db  vmovaps [rsp+0x30], xmm3
00007e4ecadda0e1  vmovaps [rsp+0x40], xmm4
00007e4ecadda0e7  vmovaps [rsp+0x50], xmm5
00007e4ecadda0ed  vmovaps [rsp+0x60], xmm6
00007e4ecadda0f3  vmovaps [rsp+0x70], xmm7
00007e4ecadda0f9  vmovaps [rsp+0x80], xmm8
00007e4ecadda102  vmovaps [rsp+0x90], xmm9
00007e4ecadda10b  vmovaps [rsp+0xA0], xmm10
00007e4ecadda114  vmovaps [rsp+0xB0], xmm11
00007e4ecadda11d  vmovaps [rsp+0xC0], xmm12
00007e4ecadda126  vmovaps [rsp+0xD0], xmm13
00007e4ecadda12f  vmovaps [rsp+0xE0], xmm15
00007e4ecadda138  sub rsp, 0x30
00007e4ecadda13c  movaps [rsp], xmm14
00007e4ecadda141  movaps [rsp+0x10], xmm12
00007e4ecadda147  movaps [rsp+0x20], xmm1
00007e4ecadda14c  lea rdi, [rsp]
00007e4ecadda150  mov esi, 0x00
00007e4ecadda155  mov rax, 0x5784BC1F5530
00007e4ecadda15f  call rax
00007e4ecadda161  movaps xmm14, [rsp]
00007e4ecadda166  add rsp, 0x30
00007e4ecadda16a  vmovaps xmm0, [rsp]
00007e4ecadda16f  vmovaps xmm1, [rsp+0x10]
00007e4ecadda175  vmovaps xmm2, [rsp+0x20]
00007e4ecadda17b  vmovaps xmm3, [rsp+0x30]
00007e4ecadda181  vmovaps xmm4, [rsp+0x40]
00007e4ecadda187  vmovaps xmm5, [rsp+0x50]
00007e4ecadda18d  vmovaps xmm6, [rsp+0x60]
00007e4ecadda193  vmovaps xmm7, [rsp+0x70]
00007e4ecadda199  vmovaps xmm8, [rsp+0x80]
00007e4ecadda1a2  vmovaps xmm9, [rsp+0x90]
00007e4ecadda1ab  vmovaps xmm10, [rsp+0xA0]
00007e4ecadda1b4  vmovaps xmm11, [rsp+0xB0]
00007e4ecadda1bd  vmovaps xmm12, [rsp+0xC0]
00007e4ecadda1c6  vmovaps xmm13, [rsp+0xD0]
00007e4ecadda1cf  vmovaps xmm15, [rsp+0xE0]
00007e4ecadda1d8  add rsp, 0xF0
00007e4ecadda1df  pop r11
00007e4ecadda1e1  pop r10
00007e4ecadda1e3  pop r9
00007e4ecadda1e5  pop r8
00007e4ecadda1e7  pop rsi
00007e4ecadda1e8  pop rdi
00007e4ecadda1e9  pop rdx
00007e4ecadda1ea  pop rcx
00007e4ecadda1eb  pop rax
00007e4ecadda1ec  add rsp, 0x08
00007e4ecadda1f0  jmp 0x00007E4ECADD6400
00007e4ecadda1f5  sub rsp, 0x08
00007e4ecadda1f9  push rax
00007e4ecadda1fa  push rcx
00007e4ecadda1fb  push rdx
00007e4ecadda1fc  push rdi
00007e4ecadda1fd  push rsi
00007e4ecadda1fe  push r8
00007e4ecadda200  push r9
00007e4ecadda202  push r10
00007e4ecadda204  push r11
00007e4ecadda206  sub rsp, 0xF0
00007e4ecadda20d  vmovaps [rsp], xmm0
00007e4ecadda212  vmovaps [rsp+0x10], xmm2
00007e4ecadda218  vmovaps [rsp+0x20], xmm3
00007e4ecadda21e  vmovaps [rsp+0x30], xmm4
00007e4ecadda224  vmovaps [rsp+0x40], xmm5
00007e4ecadda22a  vmovaps [rsp+0x50], xmm6
00007e4ecadda230  vmovaps [rsp+0x60], xmm7
00007e4ecadda236  vmovaps [rsp+0x70], xmm8
00007e4ecadda23c  vmovaps [rsp+0x80], xmm9
00007e4ecadda245  vmovaps [rsp+0x90], xmm10
00007e4ecadda24e  vmovaps [rsp+0xA0], xmm11
00007e4ecadda257  vmovaps [rsp+0xB0], xmm12
00007e4ecadda260  vmovaps [rsp+0xC0], xmm13
00007e4ecadda269  vmovaps [rsp+0xD0], xmm14
00007e4ecadda272  vmovaps [rsp+0xE0], xmm15
00007e4ecadda27b  sub rsp, 0x30
00007e4ecadda27f  movaps [rsp], xmm1
00007e4ecadda283  movaps [rsp+0x10], xmm13
00007e4ecadda289  movaps [rsp+0x20], xmm9
00007e4ecadda28f  lea rdi, [rsp]
00007e4ecadda293  mov esi, 0x00
00007e4ecadda298  mov rax, 0x5784BC1F5530
00007e4ecadda2a2  call rax
00007e4ecadda2a4  movaps xmm1, [rsp]
00007e4ecadda2a8  add rsp, 0x30
00007e4ecadda2ac  vmovaps xmm0, [rsp]
00007e4ecadda2b1  vmovaps xmm2, [rsp+0x10]
00007e4ecadda2b7  vmovaps xmm3, [rsp+0x20]
00007e4ecadda2bd  vmovaps xmm4, [rsp+0x30]
00007e4ecadda2c3  vmovaps xmm5, [rsp+0x40]
00007e4ecadda2c9  vmovaps xmm6, [rsp+0x50]
00007e4ecadda2cf  vmovaps xmm7, [rsp+0x60]
00007e4ecadda2d5  vmovaps xmm8, [rsp+0x70]
00007e4ecadda2db  vmovaps xmm9, [rsp+0x80]
00007e4ecadda2e4  vmovaps xmm10, [rsp+0x90]
00007e4ecadda2ed  vmovaps xmm11, [rsp+0xA0]
00007e4ecadda2f6  vmovaps xmm12, [rsp+0xB0]
00007e4ecadda2ff  vmovaps xmm13, [rsp+0xC0]
00007e4ecadda308  vmovaps xmm14, [rsp+0xD0]
00007e4ecadda311  vmovaps xmm15, [rsp+0xE0]
00007e4ecadda31a  add rsp, 0xF0
00007e4ecadda321  pop r11
00007e4ecadda323  pop r10
00007e4ecadda325  pop r9
00007e4ecadda327  pop r8
00007e4ecadda329  pop rsi
00007e4ecadda32a  pop rdi
00007e4ecadda32b  pop rdx
00007e4ecadda32c  pop rcx
00007e4ecadda32d  pop rax
00007e4ecadda32e  add rsp, 0x08
00007e4ecadda332  jmp 0x00007E4ECADD641A
00007e4ecadda337  sub rsp, 0x08
00007e4ecadda33b  push rax
00007e4ecadda33c  push rcx
00007e4ecadda33d  push rdx
00007e4ecadda33e  push rdi
00007e4ecadda33f  push rsi
00007e4ecadda340  push r8
00007e4ecadda342  push r9
00007e4ecadda344  push r10
00007e4ecadda346  push r11
00007e4ecadda348  sub rsp, 0xF0
00007e4ecadda34f  vmovaps [rsp], xmm0
00007e4ecadda354  vmovaps [rsp+0x10], xmm1
00007e4ecadda35a  vmovaps [rsp+0x20], xmm2
00007e4ecadda360  vmovaps [rsp+0x30], xmm3
00007e4ecadda366  vmovaps [rsp+0x40], xmm4
00007e4ecadda36c  vmovaps [rsp+0x50], xmm5
00007e4ecadda372  vmovaps [rsp+0x60], xmm6
00007e4ecadda378  vmovaps [rsp+0x70], xmm7
00007e4ecadda37e  vmovaps [rsp+0x80], xmm8
00007e4ecadda387  vmovaps [rsp+0x90], xmm9
00007e4ecadda390  vmovaps [rsp+0xA0], xmm10
00007e4ecadda399  vmovaps [rsp+0xB0], xmm11
00007e4ecadda3a2  vmovaps [rsp+0xC0], xmm13
00007e4ecadda3ab  vmovaps [rsp+0xD0], xmm14
00007e4ecadda3b4  vmovaps [rsp+0xE0], xmm15
00007e4ecadda3bd  sub rsp, 0x30
00007e4ecadda3c1  movaps [rsp], xmm12
00007e4ecadda3c6  movaps [rsp+0x10], xmm7
00007e4ecadda3cb  movaps [rsp+0x20], xmm13
00007e4ecadda3d1  lea rdi, [rsp]
00007e4ecadda3d5  mov esi, 0x00
00007e4ecadda3da  mov rax, 0x5784BC1F5530
00007e4ecadda3e4  call rax
00007e4ecadda3e6  movaps xmm12, [rsp]
00007e4ecadda3eb  add rsp, 0x30
00007e4ecadda3ef  vmovaps xmm0, [rsp]
00007e4ecadda3f4  vmovaps xmm1, [rsp+0x10]
00007e4ecadda3fa  vmovaps xmm2, [rsp+0x20]
00007e4ecadda400  vmovaps xmm3, [rsp+0x30]
00007e4ecadda406  vmovaps xmm4, [rsp+0x40]
00007e4ecadda40c  vmovaps xmm5, [rsp+0x50]
00007e4ecadda412  vmovaps xmm6, [rsp+0x60]
00007e4ecadda418  vmovaps xmm7, [rsp+0x70]
00007e4ecadda41e  vmovaps xmm8, [rsp+0x80]
00007e4ecadda427  vmovaps xmm9, [rsp+0x90]
00007e4ecadda430  vmovaps xmm10, [rsp+0xA0]
00007e4ecadda439  vmovaps xmm11, [rsp+0xB0]
00007e4ecadda442  vmovaps xmm13, [rsp+0xC0]
00007e4ecadda44b  vmovaps xmm14, [rsp+0xD0]
00007e4ecadda454  vmovaps xmm15, [rsp+0xE0]
00007e4ecadda45d  add rsp, 0xF0
00007e4ecadda464  pop r11
00007e4ecadda466  pop r10
00007e4ecadda468  pop r9
00007e4ecadda46a  pop r8
00007e4ecadda46c  pop rsi
00007e4ecadda46d  pop rdi
00007e4ecadda46e  pop rdx
00007e4ecadda46f  pop rcx
00007e4ecadda470  pop rax
00007e4ecadda471  add rsp, 0x08
00007e4ecadda475  jmp 0x00007E4ECADD6441
00007e4ecadda47a  sub rsp, 0x08
00007e4ecadda47e  push rax
00007e4ecadda47f  push rcx
00007e4ecadda480  push rdx
00007e4ecadda481  push rdi
00007e4ecadda482  push rsi
00007e4ecadda483  push r8
00007e4ecadda485  push r9
00007e4ecadda487  push r10
00007e4ecadda489  push r11
00007e4ecadda48b  sub rsp, 0xF0
00007e4ecadda492  vmovaps [rsp], xmm0
00007e4ecadda497  vmovaps [rsp+0x10], xmm1
00007e4ecadda49d  vmovaps [rsp+0x20], xmm2
00007e4ecadda4a3  vmovaps [rsp+0x30], xmm3
00007e4ecadda4a9  vmovaps [rsp+0x40], xmm4
00007e4ecadda4af  vmovaps [rsp+0x50], xmm5
00007e4ecadda4b5  vmovaps [rsp+0x60], xmm6
00007e4ecadda4bb  vmovaps [rsp+0x70], xmm7
00007e4ecadda4c1  vmovaps [rsp+0x80], xmm8
00007e4ecadda4ca  vmovaps [rsp+0x90], xmm9
00007e4ecadda4d3  vmovaps [rsp+0xA0], xmm10
00007e4ecadda4dc  vmovaps [rsp+0xB0], xmm11
00007e4ecadda4e5  vmovaps [rsp+0xC0], xmm12
00007e4ecadda4ee  vmovaps [rsp+0xD0], xmm14
00007e4ecadda4f7  vmovaps [rsp+0xE0], xmm15
00007e4ecadda500  sub rsp, 0x30
00007e4ecadda504  movaps [rsp], xmm13
00007e4ecadda509  movaps [rsp+0x10], xmm15
00007e4ecadda50f  movaps [rsp+0x20], xmm8
00007e4ecadda515  lea rdi, [rsp]
00007e4ecadda519  mov esi, 0x00
00007e4ecadda51e  mov rax, 0x5784BC1F5530
00007e4ecadda528  call rax
00007e4ecadda52a  movaps xmm13, [rsp]
00007e4ecadda52f  add rsp, 0x30
00007e4ecadda533  vmovaps xmm0, [rsp]
00007e4ecadda538  vmovaps xmm1, [rsp+0x10]
00007e4ecadda53e  vmovaps xmm2, [rsp+0x20]
00007e4ecadda544  vmovaps xmm3, [rsp+0x30]
00007e4ecadda54a  vmovaps xmm4, [rsp+0x40]
00007e4ecadda550  vmovaps xmm5, [rsp+0x50]
00007e4ecadda556  vmovaps xmm6, [rsp+0x60]
00007e4ecadda55c  vmovaps xmm7, [rsp+0x70]
00007e4ecadda562  vmovaps xmm8, [rsp+0x80]
00007e4ecadda56b  vmovaps xmm9, [rsp+0x90]
00007e4ecadda574  vmovaps xmm10, [rsp+0xA0]
00007e4ecadda57d  vmovaps xmm11, [rsp+0xB0]
00007e4ecadda586  vmovaps xmm12, [rsp+0xC0]
00007e4ecadda58f  vmovaps xmm14, [rsp+0xD0]
00007e4ecadda598  vmovaps xmm15, [rsp+0xE0]
00007e4ecadda5a1  add rsp, 0xF0
00007e4ecadda5a8  pop r11
00007e4ecadda5aa  pop r10
00007e4ecadda5ac  pop r9
00007e4ecadda5ae  pop r8
00007e4ecadda5b0  pop rsi
00007e4ecadda5b1  pop rdi
00007e4ecadda5b2  pop rdx
00007e4ecadda5b3  pop rcx
00007e4ecadda5b4  pop rax
00007e4ecadda5b5  add rsp, 0x08
00007e4ecadda5b9  jmp 0x00007E4ECADD645C
00007e4ecadda5be  sub rsp, 0x08
00007e4ecadda5c2  push rax
00007e4ecadda5c3  push rcx
00007e4ecadda5c4  push rdx
00007e4ecadda5c5  push rdi
00007e4ecadda5c6  push rsi
00007e4ecadda5c7  push r8
00007e4ecadda5c9  push r9
00007e4ecadda5cb  push r10
00007e4ecadda5cd  push r11
00007e4ecadda5cf  sub rsp, 0xF0
00007e4ecadda5d6  vmovaps [rsp], xmm0
00007e4ecadda5db  vmovaps [rsp+0x10], xmm1
00007e4ecadda5e1  vmovaps [rsp+0x20], xmm2
00007e4ecadda5e7  vmovaps [rsp+0x30], xmm3
00007e4ecadda5ed  vmovaps [rsp+0x40], xmm4
00007e4ecadda5f3  vmovaps [rsp+0x50], xmm5
00007e4ecadda5f9  vmovaps [rsp+0x60], xmm6
00007e4ecadda5ff  vmovaps [rsp+0x70], xmm7
00007e4ecadda605  vmovaps [rsp+0x80], xmm9
00007e4ecadda60e  vmovaps [rsp+0x90], xmm10
00007e4ecadda617  vmovaps [rsp+0xA0], xmm11
00007e4ecadda620  vmovaps [rsp+0xB0], xmm12
00007e4ecadda629  vmovaps [rsp+0xC0], xmm13
00007e4ecadda632  vmovaps [rsp+0xD0], xmm14
00007e4ecadda63b  vmovaps [rsp+0xE0], xmm15
00007e4ecadda644  sub rsp, 0x30
00007e4ecadda648  movaps [rsp], xmm8
00007e4ecadda64d  movaps [rsp+0x10], xmm15
00007e4ecadda653  movaps [rsp+0x20], xmm9
00007e4ecadda659  lea rdi, [rsp]
00007e4ecadda65d  mov esi, 0x00
00007e4ecadda662  mov rax, 0x5784BC1F5530
00007e4ecadda66c  call rax
00007e4ecadda66e  movaps xmm8, [rsp]
00007e4ecadda673  add rsp, 0x30
00007e4ecadda677  vmovaps xmm0, [rsp]
00007e4ecadda67c  vmovaps xmm1, [rsp+0x10]
00007e4ecadda682  vmovaps xmm2, [rsp+0x20]
00007e4ecadda688  vmovaps xmm3, [rsp+0x30]
00007e4ecadda68e  vmovaps xmm4, [rsp+0x40]
00007e4ecadda694  vmovaps xmm5, [rsp+0x50]
00007e4ecadda69a  vmovaps xmm6, [rsp+0x60]
00007e4ecadda6a0  vmovaps xmm7, [rsp+0x70]
00007e4ecadda6a6  vmovaps xmm9, [rsp+0x80]
00007e4ecadda6af  vmovaps xmm10, [rsp+0x90]
00007e4ecadda6b8  vmovaps xmm11, [rsp+0xA0]
00007e4ecadda6c1  vmovaps xmm12, [rsp+0xB0]
00007e4ecadda6ca  vmovaps xmm13, [rsp+0xC0]
00007e4ecadda6d3  vmovaps xmm14, [rsp+0xD0]
00007e4ecadda6dc  vmovaps xmm15, [rsp+0xE0]
00007e4ecadda6e5  add rsp, 0xF0
00007e4ecadda6ec  pop r11
00007e4ecadda6ee  pop r10
00007e4ecadda6f0  pop r9
00007e4ecadda6f2  pop r8
00007e4ecadda6f4  pop rsi
00007e4ecadda6f5  pop rdi
00007e4ecadda6f6  pop rdx
00007e4ecadda6f7  pop rcx
00007e4ecadda6f8  pop rax
00007e4ecadda6f9  add rsp, 0x08
00007e4ecadda6fd  jmp 0x00007E4ECADD648A
00007e4ecadda702  sub rsp, 0x08
00007e4ecadda706  push rax
00007e4ecadda707  push rcx
00007e4ecadda708  push rdx
00007e4ecadda709  push rdi
00007e4ecadda70a  push rsi
00007e4ecadda70b  push r8
00007e4ecadda70d  push r9
00007e4ecadda70f  push r10
00007e4ecadda711  push r11
00007e4ecadda713  sub rsp, 0xF0
00007e4ecadda71a  vmovaps [rsp], xmm0
00007e4ecadda71f  vmovaps [rsp+0x10], xmm1
00007e4ecadda725  vmovaps [rsp+0x20], xmm2
00007e4ecadda72b  vmovaps [rsp+0x30], xmm3
00007e4ecadda731  vmovaps [rsp+0x40], xmm4
00007e4ecadda737  vmovaps [rsp+0x50], xmm5
00007e4ecadda73d  vmovaps [rsp+0x60], xmm6
00007e4ecadda743  vmovaps [rsp+0x70], xmm7
00007e4ecadda749  vmovaps [rsp+0x80], xmm8
00007e4ecadda752  vmovaps [rsp+0x90], xmm9
00007e4ecadda75b  vmovaps [rsp+0xA0], xmm10
00007e4ecadda764  vmovaps [rsp+0xB0], xmm11
00007e4ecadda76d  vmovaps [rsp+0xC0], xmm12
00007e4ecadda776  vmovaps [rsp+0xD0], xmm13
00007e4ecadda77f  vmovaps [rsp+0xE0], xmm14
00007e4ecadda788  sub rsp, 0x30
00007e4ecadda78c  movaps [rsp], xmm15
00007e4ecadda791  movaps [rsp+0x10], xmm11
00007e4ecadda797  movaps [rsp+0x20], xmm6
00007e4ecadda79c  lea rdi, [rsp]
00007e4ecadda7a0  mov esi, 0x00
00007e4ecadda7a5  mov rax, 0x5784BC1F5530
00007e4ecadda7af  call rax
00007e4ecadda7b1  movaps xmm15, [rsp]
00007e4ecadda7b6  add rsp, 0x30
00007e4ecadda7ba  vmovaps xmm0, [rsp]
00007e4ecadda7bf  vmovaps xmm1, [rsp+0x10]
00007e4ecadda7c5  vmovaps xmm2, [rsp+0x20]
00007e4ecadda7cb  vmovaps xmm3, [rsp+0x30]
00007e4ecadda7d1  vmovaps xmm4, [rsp+0x40]
00007e4ecadda7d7  vmovaps xmm5, [rsp+0x50]
00007e4ecadda7dd  vmovaps xmm6, [rsp+0x60]
00007e4ecadda7e3  vmovaps xmm7, [rsp+0x70]
00007e4ecadda7e9  vmovaps xmm8, [rsp+0x80]
00007e4ecadda7f2  vmovaps xmm9, [rsp+0x90]
00007e4ecadda7fb  vmovaps xmm10, [rsp+0xA0]
00007e4ecadda804  vmovaps xmm11, [rsp+0xB0]
00007e4ecadda80d  vmovaps xmm12, [rsp+0xC0]
00007e4ecadda816  vmovaps xmm13, [rsp+0xD0]
00007e4ecadda81f  vmovaps xmm14, [rsp+0xE0]
00007e4ecadda828  add rsp, 0xF0
00007e4ecadda82f  pop r11
00007e4ecadda831  pop r10
00007e4ecadda833  pop r9
00007e4ecadda835  pop r8
00007e4ecadda837  pop rsi
00007e4ecadda838  pop rdi
00007e4ecadda839  pop rdx
00007e4ecadda83a  pop rcx
00007e4ecadda83b  pop rax
00007e4ecadda83c  add rsp, 0x08
00007e4ecadda840  jmp 0x00007E4ECADD64A5
00007e4ecadda845  sub rsp, 0x08
00007e4ecadda849  push rax
00007e4ecadda84a  push rcx
00007e4ecadda84b  push rdx
00007e4ecadda84c  push rdi
00007e4ecadda84d  push rsi
00007e4ecadda84e  push r8
00007e4ecadda850  push r9
00007e4ecadda852  push r10
00007e4ecadda854  push r11
00007e4ecadda856  sub rsp, 0xF0
00007e4ecadda85d  vmovaps [rsp], xmm0
00007e4ecadda862  vmovaps [rsp+0x10], xmm1
00007e4ecadda868  vmovaps [rsp+0x20], xmm2
00007e4ecadda86e  vmovaps [rsp+0x30], xmm3
00007e4ecadda874  vmovaps [rsp+0x40], xmm4
00007e4ecadda87a  vmovaps [rsp+0x50], xmm5
00007e4ecadda880  vmovaps [rsp+0x60], xmm6
00007e4ecadda886  vmovaps [rsp+0x70], xmm8
00007e4ecadda88c  vmovaps [rsp+0x80], xmm9
00007e4ecadda895  vmovaps [rsp+0x90], xmm10
00007e4ecadda89e  vmovaps [rsp+0xA0], xmm11
00007e4ecadda8a7  vmovaps [rsp+0xB0], xmm12
00007e4ecadda8b0  vmovaps [rsp+0xC0], xmm13
00007e4ecadda8b9  vmovaps [rsp+0xD0], xmm14
00007e4ecadda8c2  vmovaps [rsp+0xE0], xmm15
00007e4ecadda8cb  sub rsp, 0x30
00007e4ecadda8cf  movaps [rsp], xmm7
00007e4ecadda8d3  movaps [rsp+0x10], xmm11
00007e4ecadda8d9  movaps [rsp+0x20], xmm9
00007e4ecadda8df  lea rdi, [rsp]
00007e4ecadda8e3  mov esi, 0x00
00007e4ecadda8e8  mov rax, 0x5784BC1F5530
00007e4ecadda8f2  call rax
00007e4ecadda8f4  movaps xmm7, [rsp]
00007e4ecadda8f8  add rsp, 0x30
00007e4ecadda8fc  vmovaps xmm0, [rsp]
00007e4ecadda901  vmovaps xmm1, [rsp+0x10]
00007e4ecadda907  vmovaps xmm2, [rsp+0x20]
00007e4ecadda90d  vmovaps xmm3, [rsp+0x30]
00007e4ecadda913  vmovaps xmm4, [rsp+0x40]
00007e4ecadda919  vmovaps xmm5, [rsp+0x50]
00007e4ecadda91f  vmovaps xmm6, [rsp+0x60]
00007e4ecadda925  vmovaps xmm8, [rsp+0x70]
00007e4ecadda92b  vmovaps xmm9, [rsp+0x80]
00007e4ecadda934  vmovaps xmm10, [rsp+0x90]
00007e4ecadda93d  vmovaps xmm11, [rsp+0xA0]
00007e4ecadda946  vmovaps xmm12, [rsp+0xB0]
00007e4ecadda94f  vmovaps xmm13, [rsp+0xC0]
00007e4ecadda958  vmovaps xmm14, [rsp+0xD0]
00007e4ecadda961  vmovaps xmm15, [rsp+0xE0]
00007e4ecadda96a  add rsp, 0xF0
00007e4ecadda971  pop r11
00007e4ecadda973  pop r10
00007e4ecadda975  pop r9
00007e4ecadda977  pop r8
00007e4ecadda979  pop rsi
00007e4ecadda97a  pop rdi
00007e4ecadda97b  pop rdx
00007e4ecadda97c  pop rcx
00007e4ecadda97d  pop rax
00007e4ecadda97e  add rsp, 0x08
00007e4ecadda982  jmp 0x00007E4ECADD64D2
00007e4ecadda987  sub rsp, 0x08
00007e4ecadda98b  push rax
00007e4ecadda98c  push rcx
00007e4ecadda98d  push rdx
00007e4ecadda98e  push rdi
00007e4ecadda98f  push rsi
00007e4ecadda990  push r8
00007e4ecadda992  push r9
00007e4ecadda994  push r10
00007e4ecadda996  push r11
00007e4ecadda998  sub rsp, 0xF0
00007e4ecadda99f  vmovaps [rsp], xmm0
00007e4ecadda9a4  vmovaps [rsp+0x10], xmm1
00007e4ecadda9aa  vmovaps [rsp+0x20], xmm2
00007e4ecadda9b0  vmovaps [rsp+0x30], xmm3
00007e4ecadda9b6  vmovaps [rsp+0x40], xmm4
00007e4ecadda9bc  vmovaps [rsp+0x50], xmm5
00007e4ecadda9c2  vmovaps [rsp+0x60], xmm6
00007e4ecadda9c8  vmovaps [rsp+0x70], xmm7
00007e4ecadda9ce  vmovaps [rsp+0x80], xmm8
00007e4ecadda9d7  vmovaps [rsp+0x90], xmm9
00007e4ecadda9e0  vmovaps [rsp+0xA0], xmm10
00007e4ecadda9e9  vmovaps [rsp+0xB0], xmm12
00007e4ecadda9f2  vmovaps [rsp+0xC0], xmm13
00007e4ecadda9fb  vmovaps [rsp+0xD0], xmm14
00007e4ecaddaa04  vmovaps [rsp+0xE0], xmm15
00007e4ecaddaa0d  sub rsp, 0x30
00007e4ecaddaa11  movaps [rsp], xmm11
00007e4ecaddaa16  movaps [rsp+0x10], xmm10
00007e4ecaddaa1c  movaps [rsp+0x20], xmm14
00007e4ecaddaa22  lea rdi, [rsp]
00007e4ecaddaa26  mov esi, 0x00
00007e4ecaddaa2b  mov rax, 0x5784BC1F5530
00007e4ecaddaa35  call rax
00007e4ecaddaa37  movaps xmm11, [rsp]
00007e4ecaddaa3c  add rsp, 0x30
00007e4ecaddaa40  vmovaps xmm0, [rsp]
00007e4ecaddaa45  vmovaps xmm1, [rsp+0x10]
00007e4ecaddaa4b  vmovaps xmm2, [rsp+0x20]
00007e4ecaddaa51  vmovaps xmm3, [rsp+0x30]
00007e4ecaddaa57  vmovaps xmm4, [rsp+0x40]
00007e4ecaddaa5d  vmovaps xmm5, [rsp+0x50]
00007e4ecaddaa63  vmovaps xmm6, [rsp+0x60]
00007e4ecaddaa69  vmovaps xmm7, [rsp+0x70]
00007e4ecaddaa6f  vmovaps xmm8, [rsp+0x80]
00007e4ecaddaa78  vmovaps xmm9, [rsp+0x90]
00007e4ecaddaa81  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddaa8a  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddaa93  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddaa9c  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddaaa5  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddaaae  add rsp, 0xF0
00007e4ecaddaab5  pop r11
00007e4ecaddaab7  pop r10
00007e4ecaddaab9  pop r9
00007e4ecaddaabb  pop r8
00007e4ecaddaabd  pop rsi
00007e4ecaddaabe  pop rdi
00007e4ecaddaabf  pop rdx
00007e4ecaddaac0  pop rcx
00007e4ecaddaac1  pop rax
00007e4ecaddaac2  add rsp, 0x08
00007e4ecaddaac6  jmp 0x00007E4ECADD64ED
00007e4ecaddaacb  call 0x00007E4ECACE45A0
00007e4ecaddaad0  jmp 0x00007E4ECADD64F7
00007e4ecaddaad5  sub rsp, 0x08
00007e4ecaddaad9  push rax
00007e4ecaddaada  push rcx
00007e4ecaddaadb  push rdx
00007e4ecaddaadc  push rdi
00007e4ecaddaadd  push rsi
00007e4ecaddaade  push r8
00007e4ecaddaae0  push r9
00007e4ecaddaae2  push r10
00007e4ecaddaae4  push r11
00007e4ecaddaae6  sub rsp, 0xF0
00007e4ecaddaaed  vmovaps [rsp], xmm0
00007e4ecaddaaf2  vmovaps [rsp+0x10], xmm1
00007e4ecaddaaf8  vmovaps [rsp+0x20], xmm2
00007e4ecaddaafe  vmovaps [rsp+0x30], xmm3
00007e4ecaddab04  vmovaps [rsp+0x40], xmm4
00007e4ecaddab0a  vmovaps [rsp+0x50], xmm5
00007e4ecaddab10  vmovaps [rsp+0x60], xmm6
00007e4ecaddab16  vmovaps [rsp+0x70], xmm7
00007e4ecaddab1c  vmovaps [rsp+0x80], xmm8
00007e4ecaddab25  vmovaps [rsp+0x90], xmm9
00007e4ecaddab2e  vmovaps [rsp+0xA0], xmm11
00007e4ecaddab37  vmovaps [rsp+0xB0], xmm12
00007e4ecaddab40  vmovaps [rsp+0xC0], xmm13
00007e4ecaddab49  vmovaps [rsp+0xD0], xmm14
00007e4ecaddab52  vmovaps [rsp+0xE0], xmm15
00007e4ecaddab5b  sub rsp, 0x30
00007e4ecaddab5f  movaps [rsp], xmm10
00007e4ecaddab64  movaps [rsp+0x10], xmm1
00007e4ecaddab69  movaps [rsp+0x20], xmm12
00007e4ecaddab6f  lea rdi, [rsp]
00007e4ecaddab73  mov esi, 0x00
00007e4ecaddab78  mov rax, 0x5784BC1F5530
00007e4ecaddab82  call rax
00007e4ecaddab84  movaps xmm10, [rsp]
00007e4ecaddab89  add rsp, 0x30
00007e4ecaddab8d  vmovaps xmm0, [rsp]
00007e4ecaddab92  vmovaps xmm1, [rsp+0x10]
00007e4ecaddab98  vmovaps xmm2, [rsp+0x20]
00007e4ecaddab9e  vmovaps xmm3, [rsp+0x30]
00007e4ecaddaba4  vmovaps xmm4, [rsp+0x40]
00007e4ecaddabaa  vmovaps xmm5, [rsp+0x50]
00007e4ecaddabb0  vmovaps xmm6, [rsp+0x60]
00007e4ecaddabb6  vmovaps xmm7, [rsp+0x70]
00007e4ecaddabbc  vmovaps xmm8, [rsp+0x80]
00007e4ecaddabc5  vmovaps xmm9, [rsp+0x90]
00007e4ecaddabce  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddabd7  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddabe0  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddabe9  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddabf2  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddabfb  add rsp, 0xF0
00007e4ecaddac02  pop r11
00007e4ecaddac04  pop r10
00007e4ecaddac06  pop r9
00007e4ecaddac08  pop r8
00007e4ecaddac0a  pop rsi
00007e4ecaddac0b  pop rdi
00007e4ecaddac0c  pop rdx
00007e4ecaddac0d  pop rcx
00007e4ecaddac0e  pop rax
00007e4ecaddac0f  add rsp, 0x08
00007e4ecaddac13  jmp 0x00007E4ECADD651A
00007e4ecaddac18  sub rsp, 0x08
00007e4ecaddac1c  push rax
00007e4ecaddac1d  push rcx
00007e4ecaddac1e  push rdx
00007e4ecaddac1f  push rdi
00007e4ecaddac20  push rsi
00007e4ecaddac21  push r8
00007e4ecaddac23  push r9
00007e4ecaddac25  push r10
00007e4ecaddac27  push r11
00007e4ecaddac29  sub rsp, 0xF0
00007e4ecaddac30  vmovaps [rsp], xmm0
00007e4ecaddac35  vmovaps [rsp+0x10], xmm1
00007e4ecaddac3b  vmovaps [rsp+0x20], xmm2
00007e4ecaddac41  vmovaps [rsp+0x30], xmm3
00007e4ecaddac47  vmovaps [rsp+0x40], xmm4
00007e4ecaddac4d  vmovaps [rsp+0x50], xmm5
00007e4ecaddac53  vmovaps [rsp+0x60], xmm6
00007e4ecaddac59  vmovaps [rsp+0x70], xmm7
00007e4ecaddac5f  vmovaps [rsp+0x80], xmm8
00007e4ecaddac68  vmovaps [rsp+0x90], xmm9
00007e4ecaddac71  vmovaps [rsp+0xA0], xmm10
00007e4ecaddac7a  vmovaps [rsp+0xB0], xmm11
00007e4ecaddac83  vmovaps [rsp+0xC0], xmm13
00007e4ecaddac8c  vmovaps [rsp+0xD0], xmm14
00007e4ecaddac95  vmovaps [rsp+0xE0], xmm15
00007e4ecaddac9e  sub rsp, 0x30
00007e4ecaddaca2  movaps [rsp], xmm12
00007e4ecaddaca7  movaps [rsp+0x10], xmm14
00007e4ecaddacad  movaps [rsp+0x20], xmm1
00007e4ecaddacb2  lea rdi, [rsp]
00007e4ecaddacb6  mov esi, 0x00
00007e4ecaddacbb  mov rax, 0x5784BC1F5530
00007e4ecaddacc5  call rax
00007e4ecaddacc7  movaps xmm12, [rsp]
00007e4ecaddaccc  add rsp, 0x30
00007e4ecaddacd0  vmovaps xmm0, [rsp]
00007e4ecaddacd5  vmovaps xmm1, [rsp+0x10]
00007e4ecaddacdb  vmovaps xmm2, [rsp+0x20]
00007e4ecaddace1  vmovaps xmm3, [rsp+0x30]
00007e4ecaddace7  vmovaps xmm4, [rsp+0x40]
00007e4ecaddaced  vmovaps xmm5, [rsp+0x50]
00007e4ecaddacf3  vmovaps xmm6, [rsp+0x60]
00007e4ecaddacf9  vmovaps xmm7, [rsp+0x70]
00007e4ecaddacff  vmovaps xmm8, [rsp+0x80]
00007e4ecaddad08  vmovaps xmm9, [rsp+0x90]
00007e4ecaddad11  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddad1a  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddad23  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddad2c  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddad35  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddad3e  add rsp, 0xF0
00007e4ecaddad45  pop r11
00007e4ecaddad47  pop r10
00007e4ecaddad49  pop r9
00007e4ecaddad4b  pop r8
00007e4ecaddad4d  pop rsi
00007e4ecaddad4e  pop rdi
00007e4ecaddad4f  pop rdx
00007e4ecaddad50  pop rcx
00007e4ecaddad51  pop rax
00007e4ecaddad52  add rsp, 0x08
00007e4ecaddad56  jmp 0x00007E4ECADD6549
00007e4ecaddad5b  sub rsp, 0x08
00007e4ecaddad5f  push rax
00007e4ecaddad60  push rcx
00007e4ecaddad61  push rdx
00007e4ecaddad62  push rdi
00007e4ecaddad63  push rsi
00007e4ecaddad64  push r8
00007e4ecaddad66  push r9
00007e4ecaddad68  push r10
00007e4ecaddad6a  push r11
00007e4ecaddad6c  sub rsp, 0xF0
00007e4ecaddad73  vmovaps [rsp], xmm0
00007e4ecaddad78  vmovaps [rsp+0x10], xmm1
00007e4ecaddad7e  vmovaps [rsp+0x20], xmm2
00007e4ecaddad84  vmovaps [rsp+0x30], xmm3
00007e4ecaddad8a  vmovaps [rsp+0x40], xmm4
00007e4ecaddad90  vmovaps [rsp+0x50], xmm5
00007e4ecaddad96  vmovaps [rsp+0x60], xmm6
00007e4ecaddad9c  vmovaps [rsp+0x70], xmm7
00007e4ecaddada2  vmovaps [rsp+0x80], xmm8
00007e4ecaddadab  vmovaps [rsp+0x90], xmm9
00007e4ecaddadb4  vmovaps [rsp+0xA0], xmm10
00007e4ecaddadbd  vmovaps [rsp+0xB0], xmm11
00007e4ecaddadc6  vmovaps [rsp+0xC0], xmm12
00007e4ecaddadcf  vmovaps [rsp+0xD0], xmm13
00007e4ecaddadd8  vmovaps [rsp+0xE0], xmm15
00007e4ecaddade1  sub rsp, 0x30
00007e4ecaddade5  movaps [rsp], xmm14
00007e4ecaddadea  movaps [rsp+0x10], xmm9
00007e4ecaddadf0  movaps [rsp+0x20], xmm1
00007e4ecaddadf5  lea rdi, [rsp]
00007e4ecaddadf9  mov esi, 0x00
00007e4ecaddadfe  mov rax, 0x5784BC1F5530
00007e4ecaddae08  call rax
00007e4ecaddae0a  movaps xmm14, [rsp]
00007e4ecaddae0f  add rsp, 0x30
00007e4ecaddae13  vmovaps xmm0, [rsp]
00007e4ecaddae18  vmovaps xmm1, [rsp+0x10]
00007e4ecaddae1e  vmovaps xmm2, [rsp+0x20]
00007e4ecaddae24  vmovaps xmm3, [rsp+0x30]
00007e4ecaddae2a  vmovaps xmm4, [rsp+0x40]
00007e4ecaddae30  vmovaps xmm5, [rsp+0x50]
00007e4ecaddae36  vmovaps xmm6, [rsp+0x60]
00007e4ecaddae3c  vmovaps xmm7, [rsp+0x70]
00007e4ecaddae42  vmovaps xmm8, [rsp+0x80]
00007e4ecaddae4b  vmovaps xmm9, [rsp+0x90]
00007e4ecaddae54  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddae5d  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddae66  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddae6f  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddae78  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddae81  add rsp, 0xF0
00007e4ecaddae88  pop r11
00007e4ecaddae8a  pop r10
00007e4ecaddae8c  pop r9
00007e4ecaddae8e  pop r8
00007e4ecaddae90  pop rsi
00007e4ecaddae91  pop rdi
00007e4ecaddae92  pop rdx
00007e4ecaddae93  pop rcx
00007e4ecaddae94  pop rax
00007e4ecaddae95  add rsp, 0x08
00007e4ecaddae99  jmp 0x00007E4ECADD6578
00007e4ecaddae9e  sub rsp, 0x08
00007e4ecaddaea2  push rax
00007e4ecaddaea3  push rcx
00007e4ecaddaea4  push rdx
00007e4ecaddaea5  push rdi
00007e4ecaddaea6  push rsi
00007e4ecaddaea7  push r8
00007e4ecaddaea9  push r9
00007e4ecaddaeab  push r10
00007e4ecaddaead  push r11
00007e4ecaddaeaf  sub rsp, 0xF0
00007e4ecaddaeb6  vmovaps [rsp], xmm0
00007e4ecaddaebb  vmovaps [rsp+0x10], xmm2
00007e4ecaddaec1  vmovaps [rsp+0x20], xmm3
00007e4ecaddaec7  vmovaps [rsp+0x30], xmm4
00007e4ecaddaecd  vmovaps [rsp+0x40], xmm5
00007e4ecaddaed3  vmovaps [rsp+0x50], xmm6
00007e4ecaddaed9  vmovaps [rsp+0x60], xmm7
00007e4ecaddaedf  vmovaps [rsp+0x70], xmm8
00007e4ecaddaee5  vmovaps [rsp+0x80], xmm9
00007e4ecaddaeee  vmovaps [rsp+0x90], xmm10
00007e4ecaddaef7  vmovaps [rsp+0xA0], xmm11
00007e4ecaddaf00  vmovaps [rsp+0xB0], xmm12
00007e4ecaddaf09  vmovaps [rsp+0xC0], xmm13
00007e4ecaddaf12  vmovaps [rsp+0xD0], xmm14
00007e4ecaddaf1b  vmovaps [rsp+0xE0], xmm15
00007e4ecaddaf24  sub rsp, 0x30
00007e4ecaddaf28  movaps [rsp], xmm1
00007e4ecaddaf2c  movaps [rsp+0x10], xmm13
00007e4ecaddaf32  movaps [rsp+0x20], xmm8
00007e4ecaddaf38  lea rdi, [rsp]
00007e4ecaddaf3c  mov esi, 0x00
00007e4ecaddaf41  mov rax, 0x5784BC1F5530
00007e4ecaddaf4b  call rax
00007e4ecaddaf4d  movaps xmm1, [rsp]
00007e4ecaddaf51  add rsp, 0x30
00007e4ecaddaf55  vmovaps xmm0, [rsp]
00007e4ecaddaf5a  vmovaps xmm2, [rsp+0x10]
00007e4ecaddaf60  vmovaps xmm3, [rsp+0x20]
00007e4ecaddaf66  vmovaps xmm4, [rsp+0x30]
00007e4ecaddaf6c  vmovaps xmm5, [rsp+0x40]
00007e4ecaddaf72  vmovaps xmm6, [rsp+0x50]
00007e4ecaddaf78  vmovaps xmm7, [rsp+0x60]
00007e4ecaddaf7e  vmovaps xmm8, [rsp+0x70]
00007e4ecaddaf84  vmovaps xmm9, [rsp+0x80]
00007e4ecaddaf8d  vmovaps xmm10, [rsp+0x90]
00007e4ecaddaf96  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddaf9f  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddafa8  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddafb1  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddafba  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddafc3  add rsp, 0xF0
00007e4ecaddafca  pop r11
00007e4ecaddafcc  pop r10
00007e4ecaddafce  pop r9
00007e4ecaddafd0  pop r8
00007e4ecaddafd2  pop rsi
00007e4ecaddafd3  pop rdi
00007e4ecaddafd4  pop rdx
00007e4ecaddafd5  pop rcx
00007e4ecaddafd6  pop rax
00007e4ecaddafd7  add rsp, 0x08
00007e4ecaddafdb  jmp 0x00007E4ECADD659A
00007e4ecaddafe0  call 0x00007E4ECAC0C260
00007e4ecaddafe5  jmp 0x00007E4ECADD65A8
00007e4ecaddafea  call 0x00007E4ECACDE950
00007e4ecaddafef  jmp 0x00007E4ECADD65B2
00007e4ecaddaff4  sub rsp, 0x08
00007e4ecaddaff8  push rax
00007e4ecaddaff9  push rcx
00007e4ecaddaffa  push rdx
00007e4ecaddaffb  push rdi
00007e4ecaddaffc  push rsi
00007e4ecaddaffd  push r8
00007e4ecaddafff  push r9
00007e4ecaddb001  push r10
00007e4ecaddb003  push r11
00007e4ecaddb005  sub rsp, 0xF0
00007e4ecaddb00c  vmovaps [rsp], xmm0
00007e4ecaddb011  vmovaps [rsp+0x10], xmm1
00007e4ecaddb017  vmovaps [rsp+0x20], xmm2
00007e4ecaddb01d  vmovaps [rsp+0x30], xmm3
00007e4ecaddb023  vmovaps [rsp+0x40], xmm4
00007e4ecaddb029  vmovaps [rsp+0x50], xmm5
00007e4ecaddb02f  vmovaps [rsp+0x60], xmm6
00007e4ecaddb035  vmovaps [rsp+0x70], xmm7
00007e4ecaddb03b  vmovaps [rsp+0x80], xmm9
00007e4ecaddb044  vmovaps [rsp+0x90], xmm10
00007e4ecaddb04d  vmovaps [rsp+0xA0], xmm11
00007e4ecaddb056  vmovaps [rsp+0xB0], xmm12
00007e4ecaddb05f  vmovaps [rsp+0xC0], xmm13
00007e4ecaddb068  vmovaps [rsp+0xD0], xmm14
00007e4ecaddb071  vmovaps [rsp+0xE0], xmm15
00007e4ecaddb07a  sub rsp, 0x30
00007e4ecaddb07e  movaps [rsp], xmm8
00007e4ecaddb083  movaps [rsp+0x10], xmm15
00007e4ecaddb089  movaps [rsp+0x20], xmm7
00007e4ecaddb08e  lea rdi, [rsp]
00007e4ecaddb092  mov esi, 0x00
00007e4ecaddb097  mov rax, 0x5784BC1F5530
00007e4ecaddb0a1  call rax
00007e4ecaddb0a3  movaps xmm8, [rsp]
00007e4ecaddb0a8  add rsp, 0x30
00007e4ecaddb0ac  vmovaps xmm0, [rsp]
00007e4ecaddb0b1  vmovaps xmm1, [rsp+0x10]
00007e4ecaddb0b7  vmovaps xmm2, [rsp+0x20]
00007e4ecaddb0bd  vmovaps xmm3, [rsp+0x30]
00007e4ecaddb0c3  vmovaps xmm4, [rsp+0x40]
00007e4ecaddb0c9  vmovaps xmm5, [rsp+0x50]
00007e4ecaddb0cf  vmovaps xmm6, [rsp+0x60]
00007e4ecaddb0d5  vmovaps xmm7, [rsp+0x70]
00007e4ecaddb0db  vmovaps xmm9, [rsp+0x80]
00007e4ecaddb0e4  vmovaps xmm10, [rsp+0x90]
00007e4ecaddb0ed  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddb0f6  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddb0ff  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddb108  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddb111  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddb11a  add rsp, 0xF0
00007e4ecaddb121  pop r11
00007e4ecaddb123  pop r10
00007e4ecaddb125  pop r9
00007e4ecaddb127  pop r8
00007e4ecaddb129  pop rsi
00007e4ecaddb12a  pop rdi
00007e4ecaddb12b  pop rdx
00007e4ecaddb12c  pop rcx
00007e4ecaddb12d  pop rax
00007e4ecaddb12e  add rsp, 0x08
00007e4ecaddb132  jmp 0x00007E4ECADD65D4
00007e4ecaddb137  sub rsp, 0x08
00007e4ecaddb13b  push rax
00007e4ecaddb13c  push rcx
00007e4ecaddb13d  push rdx
00007e4ecaddb13e  push rdi
00007e4ecaddb13f  push rsi
00007e4ecaddb140  push r8
00007e4ecaddb142  push r9
00007e4ecaddb144  push r10
00007e4ecaddb146  push r11
00007e4ecaddb148  sub rsp, 0xF0
00007e4ecaddb14f  vmovaps [rsp], xmm0
00007e4ecaddb154  vmovaps [rsp+0x10], xmm1
00007e4ecaddb15a  vmovaps [rsp+0x20], xmm2
00007e4ecaddb160  vmovaps [rsp+0x30], xmm3
00007e4ecaddb166  vmovaps [rsp+0x40], xmm4
00007e4ecaddb16c  vmovaps [rsp+0x50], xmm5
00007e4ecaddb172  vmovaps [rsp+0x60], xmm6
00007e4ecaddb178  vmovaps [rsp+0x70], xmm8
00007e4ecaddb17e  vmovaps [rsp+0x80], xmm9
00007e4ecaddb187  vmovaps [rsp+0x90], xmm10
00007e4ecaddb190  vmovaps [rsp+0xA0], xmm11
00007e4ecaddb199  vmovaps [rsp+0xB0], xmm12
00007e4ecaddb1a2  vmovaps [rsp+0xC0], xmm13
00007e4ecaddb1ab  vmovaps [rsp+0xD0], xmm14
00007e4ecaddb1b4  vmovaps [rsp+0xE0], xmm15
00007e4ecaddb1bd  sub rsp, 0x30
00007e4ecaddb1c1  movaps [rsp], xmm7
00007e4ecaddb1c5  movaps [rsp+0x10], xmm9
00007e4ecaddb1cb  movaps [rsp+0x20], xmm15
00007e4ecaddb1d1  lea rdi, [rsp]
00007e4ecaddb1d5  mov esi, 0x00
00007e4ecaddb1da  mov rax, 0x5784BC1F5530
00007e4ecaddb1e4  call rax
00007e4ecaddb1e6  movaps xmm7, [rsp]
00007e4ecaddb1ea  add rsp, 0x30
00007e4ecaddb1ee  vmovaps xmm0, [rsp]
00007e4ecaddb1f3  vmovaps xmm1, [rsp+0x10]
00007e4ecaddb1f9  vmovaps xmm2, [rsp+0x20]
00007e4ecaddb1ff  vmovaps xmm3, [rsp+0x30]
00007e4ecaddb205  vmovaps xmm4, [rsp+0x40]
00007e4ecaddb20b  vmovaps xmm5, [rsp+0x50]
00007e4ecaddb211  vmovaps xmm6, [rsp+0x60]
00007e4ecaddb217  vmovaps xmm8, [rsp+0x70]
00007e4ecaddb21d  vmovaps xmm9, [rsp+0x80]
00007e4ecaddb226  vmovaps xmm10, [rsp+0x90]
00007e4ecaddb22f  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddb238  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddb241  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddb24a  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddb253  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddb25c  add rsp, 0xF0
00007e4ecaddb263  pop r11
00007e4ecaddb265  pop r10
00007e4ecaddb267  pop r9
00007e4ecaddb269  pop r8
00007e4ecaddb26b  pop rsi
00007e4ecaddb26c  pop rdi
00007e4ecaddb26d  pop rdx
00007e4ecaddb26e  pop rcx
00007e4ecaddb26f  pop rax
00007e4ecaddb270  add rsp, 0x08
00007e4ecaddb274  jmp 0x00007E4ECADD6601
00007e4ecaddb279  sub rsp, 0x08
00007e4ecaddb27d  push rax
00007e4ecaddb27e  push rcx
00007e4ecaddb27f  push rdx
00007e4ecaddb280  push rdi
00007e4ecaddb281  push rsi
00007e4ecaddb282  push r8
00007e4ecaddb284  push r9
00007e4ecaddb286  push r10
00007e4ecaddb288  push r11
00007e4ecaddb28a  sub rsp, 0xF0
00007e4ecaddb291  vmovaps [rsp], xmm0
00007e4ecaddb296  vmovaps [rsp+0x10], xmm1
00007e4ecaddb29c  vmovaps [rsp+0x20], xmm2
00007e4ecaddb2a2  vmovaps [rsp+0x30], xmm3
00007e4ecaddb2a8  vmovaps [rsp+0x40], xmm4
00007e4ecaddb2ae  vmovaps [rsp+0x50], xmm5
00007e4ecaddb2b4  vmovaps [rsp+0x60], xmm6
00007e4ecaddb2ba  vmovaps [rsp+0x70], xmm7
00007e4ecaddb2c0  vmovaps [rsp+0x80], xmm8
00007e4ecaddb2c9  vmovaps [rsp+0x90], xmm10
00007e4ecaddb2d2  vmovaps [rsp+0xA0], xmm11
00007e4ecaddb2db  vmovaps [rsp+0xB0], xmm12
00007e4ecaddb2e4  vmovaps [rsp+0xC0], xmm13
00007e4ecaddb2ed  vmovaps [rsp+0xD0], xmm14
00007e4ecaddb2f6  vmovaps [rsp+0xE0], xmm15
00007e4ecaddb2ff  sub rsp, 0x30
00007e4ecaddb303  movaps [rsp], xmm9
00007e4ecaddb308  movaps [rsp+0x10], xmm13
00007e4ecaddb30e  movaps [rsp+0x20], xmm15
00007e4ecaddb314  lea rdi, [rsp]
00007e4ecaddb318  mov esi, 0x00
00007e4ecaddb31d  mov rax, 0x5784BC1F5530
00007e4ecaddb327  call rax
00007e4ecaddb329  movaps xmm9, [rsp]
00007e4ecaddb32e  add rsp, 0x30
00007e4ecaddb332  vmovaps xmm0, [rsp]
00007e4ecaddb337  vmovaps xmm1, [rsp+0x10]
00007e4ecaddb33d  vmovaps xmm2, [rsp+0x20]
00007e4ecaddb343  vmovaps xmm3, [rsp+0x30]
00007e4ecaddb349  vmovaps xmm4, [rsp+0x40]
00007e4ecaddb34f  vmovaps xmm5, [rsp+0x50]
00007e4ecaddb355  vmovaps xmm6, [rsp+0x60]
00007e4ecaddb35b  vmovaps xmm7, [rsp+0x70]
00007e4ecaddb361  vmovaps xmm8, [rsp+0x80]
00007e4ecaddb36a  vmovaps xmm10, [rsp+0x90]
00007e4ecaddb373  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddb37c  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddb385  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddb38e  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddb397  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddb3a0  add rsp, 0xF0
00007e4ecaddb3a7  pop r11
00007e4ecaddb3a9  pop r10
00007e4ecaddb3ab  pop r9
00007e4ecaddb3ad  pop r8
00007e4ecaddb3af  pop rsi
00007e4ecaddb3b0  pop rdi
00007e4ecaddb3b1  pop rdx
00007e4ecaddb3b2  pop rcx
00007e4ecaddb3b3  pop rax
00007e4ecaddb3b4  add rsp, 0x08
00007e4ecaddb3b8  jmp 0x00007E4ECADD662F
00007e4ecaddb3bd  sub rsp, 0x08
00007e4ecaddb3c1  push rax
00007e4ecaddb3c2  push rcx
00007e4ecaddb3c3  push rdx
00007e4ecaddb3c4  push rdi
00007e4ecaddb3c5  push rsi
00007e4ecaddb3c6  push r8
00007e4ecaddb3c8  push r9
00007e4ecaddb3ca  push r10
00007e4ecaddb3cc  push r11
00007e4ecaddb3ce  sub rsp, 0xF0
00007e4ecaddb3d5  vmovaps [rsp], xmm0
00007e4ecaddb3da  vmovaps [rsp+0x10], xmm1
00007e4ecaddb3e0  vmovaps [rsp+0x20], xmm2
00007e4ecaddb3e6  vmovaps [rsp+0x30], xmm3
00007e4ecaddb3ec  vmovaps [rsp+0x40], xmm4
00007e4ecaddb3f2  vmovaps [rsp+0x50], xmm5
00007e4ecaddb3f8  vmovaps [rsp+0x60], xmm6
00007e4ecaddb3fe  vmovaps [rsp+0x70], xmm7
00007e4ecaddb404  vmovaps [rsp+0x80], xmm8
00007e4ecaddb40d  vmovaps [rsp+0x90], xmm9
00007e4ecaddb416  vmovaps [rsp+0xA0], xmm10
00007e4ecaddb41f  vmovaps [rsp+0xB0], xmm11
00007e4ecaddb428  vmovaps [rsp+0xC0], xmm12
00007e4ecaddb431  vmovaps [rsp+0xD0], xmm13
00007e4ecaddb43a  vmovaps [rsp+0xE0], xmm14
00007e4ecaddb443  sub rsp, 0x30
00007e4ecaddb447  movaps [rsp], xmm15
00007e4ecaddb44c  movaps [rsp+0x10], xmm11
00007e4ecaddb452  movaps [rsp+0x20], xmm12
00007e4ecaddb458  lea rdi, [rsp]
00007e4ecaddb45c  mov esi, 0x00
00007e4ecaddb461  mov rax, 0x5784BC1F5530
00007e4ecaddb46b  call rax
00007e4ecaddb46d  movaps xmm15, [rsp]
00007e4ecaddb472  add rsp, 0x30
00007e4ecaddb476  vmovaps xmm0, [rsp]
00007e4ecaddb47b  vmovaps xmm1, [rsp+0x10]
00007e4ecaddb481  vmovaps xmm2, [rsp+0x20]
00007e4ecaddb487  vmovaps xmm3, [rsp+0x30]
00007e4ecaddb48d  vmovaps xmm4, [rsp+0x40]
00007e4ecaddb493  vmovaps xmm5, [rsp+0x50]
00007e4ecaddb499  vmovaps xmm6, [rsp+0x60]
00007e4ecaddb49f  vmovaps xmm7, [rsp+0x70]
00007e4ecaddb4a5  vmovaps xmm8, [rsp+0x80]
00007e4ecaddb4ae  vmovaps xmm9, [rsp+0x90]
00007e4ecaddb4b7  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddb4c0  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddb4c9  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddb4d2  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddb4db  vmovaps xmm14, [rsp+0xE0]
00007e4ecaddb4e4  add rsp, 0xF0
00007e4ecaddb4eb  pop r11
00007e4ecaddb4ed  pop r10
00007e4ecaddb4ef  pop r9
00007e4ecaddb4f1  pop r8
00007e4ecaddb4f3  pop rsi
00007e4ecaddb4f4  pop rdi
00007e4ecaddb4f5  pop rdx
00007e4ecaddb4f6  pop rcx
00007e4ecaddb4f7  pop rax
00007e4ecaddb4f8  add rsp, 0x08
00007e4ecaddb4fc  jmp 0x00007E4ECADD664A
00007e4ecaddb501  sub rsp, 0x08
00007e4ecaddb505  push rax
00007e4ecaddb506  push rcx
00007e4ecaddb507  push rdx
00007e4ecaddb508  push rdi
00007e4ecaddb509  push rsi
00007e4ecaddb50a  push r8
00007e4ecaddb50c  push r9
00007e4ecaddb50e  push r10
00007e4ecaddb510  push r11
00007e4ecaddb512  sub rsp, 0xF0
00007e4ecaddb519  vmovaps [rsp], xmm0
00007e4ecaddb51e  vmovaps [rsp+0x10], xmm1
00007e4ecaddb524  vmovaps [rsp+0x20], xmm2
00007e4ecaddb52a  vmovaps [rsp+0x30], xmm3
00007e4ecaddb530  vmovaps [rsp+0x40], xmm4
00007e4ecaddb536  vmovaps [rsp+0x50], xmm5
00007e4ecaddb53c  vmovaps [rsp+0x60], xmm6
00007e4ecaddb542  vmovaps [rsp+0x70], xmm7
00007e4ecaddb548  vmovaps [rsp+0x80], xmm8
00007e4ecaddb551  vmovaps [rsp+0x90], xmm9
00007e4ecaddb55a  vmovaps [rsp+0xA0], xmm10
00007e4ecaddb563  vmovaps [rsp+0xB0], xmm11
00007e4ecaddb56c  vmovaps [rsp+0xC0], xmm12
00007e4ecaddb575  vmovaps [rsp+0xD0], xmm14
00007e4ecaddb57e  vmovaps [rsp+0xE0], xmm15
00007e4ecaddb587  sub rsp, 0x30
00007e4ecaddb58b  movaps [rsp], xmm13
00007e4ecaddb590  movaps [rsp+0x10], xmm10
00007e4ecaddb596  movaps [rsp+0x20], xmm14
00007e4ecaddb59c  lea rdi, [rsp]
00007e4ecaddb5a0  mov esi, 0x00
00007e4ecaddb5a5  mov rax, 0x5784BC1F5530
00007e4ecaddb5af  call rax
00007e4ecaddb5b1  movaps xmm13, [rsp]
00007e4ecaddb5b6  add rsp, 0x30
00007e4ecaddb5ba  vmovaps xmm0, [rsp]
00007e4ecaddb5bf  vmovaps xmm1, [rsp+0x10]
00007e4ecaddb5c5  vmovaps xmm2, [rsp+0x20]
00007e4ecaddb5cb  vmovaps xmm3, [rsp+0x30]
00007e4ecaddb5d1  vmovaps xmm4, [rsp+0x40]
00007e4ecaddb5d7  vmovaps xmm5, [rsp+0x50]
00007e4ecaddb5dd  vmovaps xmm6, [rsp+0x60]
00007e4ecaddb5e3  vmovaps xmm7, [rsp+0x70]
00007e4ecaddb5e9  vmovaps xmm8, [rsp+0x80]
00007e4ecaddb5f2  vmovaps xmm9, [rsp+0x90]
00007e4ecaddb5fb  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddb604  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddb60d  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddb616  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddb61f  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddb628  add rsp, 0xF0
00007e4ecaddb62f  pop r11
00007e4ecaddb631  pop r10
00007e4ecaddb633  pop r9
00007e4ecaddb635  pop r8
00007e4ecaddb637  pop rsi
00007e4ecaddb638  pop rdi
00007e4ecaddb639  pop rdx
00007e4ecaddb63a  pop rcx
00007e4ecaddb63b  pop rax
00007e4ecaddb63c  add rsp, 0x08
00007e4ecaddb640  jmp 0x00007E4ECADD666D
00007e4ecaddb645  sub rsp, 0x08
00007e4ecaddb649  push rax
00007e4ecaddb64a  push rcx
00007e4ecaddb64b  push rdx
00007e4ecaddb64c  push rdi
00007e4ecaddb64d  push rsi
00007e4ecaddb64e  push r8
00007e4ecaddb650  push r9
00007e4ecaddb652  push r10
00007e4ecaddb654  push r11
00007e4ecaddb656  sub rsp, 0xF0
00007e4ecaddb65d  vmovaps [rsp], xmm0
00007e4ecaddb662  vmovaps [rsp+0x10], xmm1
00007e4ecaddb668  vmovaps [rsp+0x20], xmm2
00007e4ecaddb66e  vmovaps [rsp+0x30], xmm3
00007e4ecaddb674  vmovaps [rsp+0x40], xmm4
00007e4ecaddb67a  vmovaps [rsp+0x50], xmm5
00007e4ecaddb680  vmovaps [rsp+0x60], xmm6
00007e4ecaddb686  vmovaps [rsp+0x70], xmm7
00007e4ecaddb68c  vmovaps [rsp+0x80], xmm8
00007e4ecaddb695  vmovaps [rsp+0x90], xmm9
00007e4ecaddb69e  vmovaps [rsp+0xA0], xmm10
00007e4ecaddb6a7  vmovaps [rsp+0xB0], xmm11
00007e4ecaddb6b0  vmovaps [rsp+0xC0], xmm12
00007e4ecaddb6b9  vmovaps [rsp+0xD0], xmm13
00007e4ecaddb6c2  vmovaps [rsp+0xE0], xmm15
00007e4ecaddb6cb  sub rsp, 0x30
00007e4ecaddb6cf  movaps [rsp], xmm14
00007e4ecaddb6d4  movaps [rsp+0x10], xmm1
00007e4ecaddb6d9  movaps [rsp+0x20], xmm7
00007e4ecaddb6de  lea rdi, [rsp]
00007e4ecaddb6e2  mov esi, 0x00
00007e4ecaddb6e7  mov rax, 0x5784BC1F5530
00007e4ecaddb6f1  call rax
00007e4ecaddb6f3  movaps xmm14, [rsp]
00007e4ecaddb6f8  add rsp, 0x30
00007e4ecaddb6fc  vmovaps xmm0, [rsp]
00007e4ecaddb701  vmovaps xmm1, [rsp+0x10]
00007e4ecaddb707  vmovaps xmm2, [rsp+0x20]
00007e4ecaddb70d  vmovaps xmm3, [rsp+0x30]
00007e4ecaddb713  vmovaps xmm4, [rsp+0x40]
00007e4ecaddb719  vmovaps xmm5, [rsp+0x50]
00007e4ecaddb71f  vmovaps xmm6, [rsp+0x60]
00007e4ecaddb725  vmovaps xmm7, [rsp+0x70]
00007e4ecaddb72b  vmovaps xmm8, [rsp+0x80]
00007e4ecaddb734  vmovaps xmm9, [rsp+0x90]
00007e4ecaddb73d  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddb746  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddb74f  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddb758  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddb761  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddb76a  add rsp, 0xF0
00007e4ecaddb771  pop r11
00007e4ecaddb773  pop r10
00007e4ecaddb775  pop r9
00007e4ecaddb777  pop r8
00007e4ecaddb779  pop rsi
00007e4ecaddb77a  pop rdi
00007e4ecaddb77b  pop rdx
00007e4ecaddb77c  pop rcx
00007e4ecaddb77d  pop rax
00007e4ecaddb77e  add rsp, 0x08
00007e4ecaddb782  jmp 0x00007E4ECADD6690
00007e4ecaddb787  sub rsp, 0x08
00007e4ecaddb78b  push rax
00007e4ecaddb78c  push rcx
00007e4ecaddb78d  push rdx
00007e4ecaddb78e  push rdi
00007e4ecaddb78f  push rsi
00007e4ecaddb790  push r8
00007e4ecaddb792  push r9
00007e4ecaddb794  push r10
00007e4ecaddb796  push r11
00007e4ecaddb798  sub rsp, 0xF0
00007e4ecaddb79f  vmovaps [rsp], xmm0
00007e4ecaddb7a4  vmovaps [rsp+0x10], xmm2
00007e4ecaddb7aa  vmovaps [rsp+0x20], xmm3
00007e4ecaddb7b0  vmovaps [rsp+0x30], xmm4
00007e4ecaddb7b6  vmovaps [rsp+0x40], xmm5
00007e4ecaddb7bc  vmovaps [rsp+0x50], xmm6
00007e4ecaddb7c2  vmovaps [rsp+0x60], xmm7
00007e4ecaddb7c8  vmovaps [rsp+0x70], xmm8
00007e4ecaddb7ce  vmovaps [rsp+0x80], xmm9
00007e4ecaddb7d7  vmovaps [rsp+0x90], xmm10
00007e4ecaddb7e0  vmovaps [rsp+0xA0], xmm11
00007e4ecaddb7e9  vmovaps [rsp+0xB0], xmm12
00007e4ecaddb7f2  vmovaps [rsp+0xC0], xmm13
00007e4ecaddb7fb  vmovaps [rsp+0xD0], xmm14
00007e4ecaddb804  vmovaps [rsp+0xE0], xmm15
00007e4ecaddb80d  sub rsp, 0x30
00007e4ecaddb811  movaps [rsp], xmm1
00007e4ecaddb815  movaps [rsp+0x10], xmm8
00007e4ecaddb81b  movaps [rsp+0x20], xmm9
00007e4ecaddb821  lea rdi, [rsp]
00007e4ecaddb825  mov esi, 0x00
00007e4ecaddb82a  mov rax, 0x5784BC1F5530
00007e4ecaddb834  call rax
00007e4ecaddb836  movaps xmm1, [rsp]
00007e4ecaddb83a  add rsp, 0x30
00007e4ecaddb83e  vmovaps xmm0, [rsp]
00007e4ecaddb843  vmovaps xmm2, [rsp+0x10]
00007e4ecaddb849  vmovaps xmm3, [rsp+0x20]
00007e4ecaddb84f  vmovaps xmm4, [rsp+0x30]
00007e4ecaddb855  vmovaps xmm5, [rsp+0x40]
00007e4ecaddb85b  vmovaps xmm6, [rsp+0x50]
00007e4ecaddb861  vmovaps xmm7, [rsp+0x60]
00007e4ecaddb867  vmovaps xmm8, [rsp+0x70]
00007e4ecaddb86d  vmovaps xmm9, [rsp+0x80]
00007e4ecaddb876  vmovaps xmm10, [rsp+0x90]
00007e4ecaddb87f  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddb888  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddb891  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddb89a  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddb8a3  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddb8ac  add rsp, 0xF0
00007e4ecaddb8b3  pop r11
00007e4ecaddb8b5  pop r10
00007e4ecaddb8b7  pop r9
00007e4ecaddb8b9  pop r8
00007e4ecaddb8bb  pop rsi
00007e4ecaddb8bc  pop rdi
00007e4ecaddb8bd  pop rdx
00007e4ecaddb8be  pop rcx
00007e4ecaddb8bf  pop rax
00007e4ecaddb8c0  add rsp, 0x08
00007e4ecaddb8c4  jmp 0x00007E4ECADD66B2
00007e4ecaddb8c9  call 0x00007E4ECACB3E40
00007e4ecaddb8ce  jmp 0x00007E4ECADD66C0
00007e4ecaddb8d3  call 0x00007E4ECAC0C380
00007e4ecaddb8d8  jmp 0x00007E4ECADD66CA
00007e4ecaddb8dd  call 0x00007E4ECAC0D600
00007e4ecaddb8e2  jmp 0x00007E4ECADD66D4
00007e4ecaddb8e7  call 0x00007E4ECABFF540
00007e4ecaddb8ec  jmp 0x00007E4ECADD66DE
00007e4ecaddb8f1  int3
00007e4ecaddb8f2  nop [rax+rax*1], ax
00007e4ecaddb8fb  nop [rax+rax*1], eax
00007e4ecaddb900  mov eax, [r15+0x48]
00007e4ecaddb904  lea r14d, [eax+0x01]
00007e4ecaddb909  mov [rsp+0x10], r14d
00007e4ecaddb90e  mov r14d, r14d
00007e4ecaddb911  mov [r15+0x48], r14
00007e4ecaddb915  xor eax, eax
00007e4ecaddb917  mov r14d, [rsp+0x10]
00007e4ecaddb91c  cmp r14d, 0x1F4
00007e4ecaddb923  cmc
00007e4ecaddb924  lahf
00007e4ecaddb925  seto al
00007e4ecaddb928  mov [r15+0x108], eax
00007e4ecaddb92f  mov eax, [r15+0x108]
00007e4ecaddb936  sahf
00007e4ecaddb937  jnz 0x00007E4ECADDB969
00007e4ecaddb939  cmp dword ptr [r15+0x318], 0x00
00007e4ecaddb941  jz 0x00007E4ECADE1AB0
00007e4ecaddb947  nop [rax+rax*1], ax
00007e4ecaddb950  nop [rax+rax*1], eax
00007e4ecaddb958  mov eax, 0x410450
00007e4ecaddb95d  mov [r15+0x100], rax
00007e4ecaddb964  jmp 0x00007E4ECABFE110
00007e4ecaddb969  cmp dword ptr [r15+0x318], 0x00
00007e4ecaddb971  jz 0x00007E4ECADDB9A0
00007e4ecaddb977  nop [rax+rax*1], ax
00007e4ecaddb980  nop [rax+rax*1], eax
00007e4ecaddb988  mov eax, 0x410274
00007e4ecaddb98d  mov [r15+0x100], rax
00007e4ecaddb994  jmp 0x00007E4ECABFE110
00007e4ecaddb999  int3
00007e4ecaddb99a  int3
00007e4ecaddb99b  nop [rax+rax*1], eax
00007e4ecaddb9a0  mov rax, [r15+0x40]
00007e4ecaddb9a4  movaps xmm1, [r15+0x1D0]
00007e4ecaddb9ac  vmovaps [rsp+0x10], xmm1
00007e4ecaddb9b2  vmovaps xmm15, [rsp+0x10]
00007e4ecaddb9b8  por xmm1, xmm15
00007e4ecaddb9bd  movaps xmm14, [r15+0x1A0]
00007e4ecaddb9c5  vmovaps [rsp+0x10], xmm14
00007e4ecaddb9cb  vmovaps xmm13, [rsp+0x10]
00007e4ecaddb9d1  por xmm14, xmm13
00007e4ecaddb9d6  lea r14, [rax+0x30]
00007e4ecaddb9da  mov r12, [r13+r14*1]
00007e4ecaddb9df  lea r14, [rax+0x38]
00007e4ecaddb9e3  mov r11, [r13+r14*1]
00007e4ecaddb9e8  movq xmm13, r12
00007e4ecaddb9ed  movq xmm12, r11
00007e4ecaddb9f2  movq xmm13, xmm13
00007e4ecaddb9f7  vmovaps [rsp+0x10], xmm13
00007e4ecaddb9fd  movq xmm13, xmm13
00007e4ecaddba02  movaps [r15+0x130], xmm13
00007e4ecaddba0a  movq xmm12, xmm12
00007e4ecaddba0f  vmovaps [rsp+0x20], xmm12
00007e4ecaddba15  movq xmm12, xmm12
00007e4ecaddba1a  movaps [r15+0x280], xmm12
00007e4ecaddba22  movaps xmm13, [r15+0x270]
00007e4ecaddba2a  vmovaps [rsp+0x30], xmm13
00007e4ecaddba30  vmovaps xmm12, [rsp+0x30]
00007e4ecaddba36  por xmm13, xmm12
00007e4ecaddba3b  lea r14, [rax+0x20]
00007e4ecaddba3f  mov r12, [r13+r14*1]
00007e4ecaddba44  lea r14, [rax+0x28]
00007e4ecaddba48  mov r11, [r13+r14*1]
00007e4ecaddba4d  movq xmm12, r12
00007e4ecaddba52  movq xmm11, r11
00007e4ecaddba57  movq xmm12, xmm12
00007e4ecaddba5c  vmovaps [rsp+0x30], xmm12
00007e4ecaddba62  movq xmm12, xmm12
00007e4ecaddba67  movaps [r15+0x150], xmm12
00007e4ecaddba6f  movq xmm11, xmm11
00007e4ecaddba74  vmovaps [rsp+0x40], xmm11
00007e4ecaddba7a  movq xmm11, xmm11
00007e4ecaddba7f  movaps [r15+0x140], xmm11
00007e4ecaddba87  lea r14, [rax+0x10]
00007e4ecaddba8b  mov r12, [r13+r14*1]
00007e4ecaddba90  lea r14, [rax+0x18]
00007e4ecaddba94  mov r11, [r13+r14*1]
00007e4ecaddba99  movq xmm12, r12
00007e4ecaddba9e  movq xmm11, r11
00007e4ecaddbaa3  movq xmm12, xmm12
00007e4ecaddbaa8  vmovaps [rsp+0x50], xmm12
00007e4ecaddbaae  movq xmm12, xmm12
00007e4ecaddbab3  movaps [r15+0x170], xmm12
00007e4ecaddbabb  movq xmm11, xmm11
00007e4ecaddbac0  vmovaps [rsp+0x60], xmm11
00007e4ecaddbac6  movq xmm11, xmm11
00007e4ecaddbacb  movaps [r15+0x160], xmm11
00007e4ecaddbad3  mov r14, [r13+rax*1]
00007e4ecaddbad8  vmovq xmm12, r14
00007e4ecaddbadd  vpbroadcastq xmm12, xmm12
00007e4ecaddbae2  lea r14, [rax+0x08]
00007e4ecaddbae6  mov rax, [r13+r14*1]
00007e4ecaddbaeb  movq xmm11, rax
00007e4ecaddbaf0  movaps [r15+0x230], xmm11
00007e4ecaddbaf8  mov rax, [r15+0xF8]
00007e4ecaddbaff  lea r14, [rax+0x50]
00007e4ecaddbb03  movups xmm11, [r13+r14*1]
00007e4ecaddbb09  lea r14, [rax+0x60]
00007e4ecaddbb0d  movups xmm10, [r13+r14*1]
00007e4ecaddbb13  lea r14, [rax+0x30]
00007e4ecaddbb17  movups xmm9, [r13+r14*1]
00007e4ecaddbb1d  mov r14, [r15+0x50]
00007e4ecaddbb21  mov [r15+0x60], r14
00007e4ecaddbb25  mov qword ptr [r15+0x58], 0x40
00007e4ecaddbb2d  movaps xmm8, xmm12
00007e4ecaddbb31  mulpd xmm8, xmm15
00007e4ecaddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4ecaddbb3c  ptest xmm7, xmm7
00007e4ecaddbb41  jnz 0x00007E4ECADDC96A
00007e4ecaddbb47  movq xmm15, qword ptr [r15+0x230]
00007e4ecaddbb50  vmovaps [rsp+0x70], xmm15
00007e4ecaddbb56  vpermilpd xmm15, xmm15, 0x00
00007e4ecaddbb5c  movaps xmm7, xmm9
00007e4ecaddbb60  mulpd xmm7, xmm15
00007e4ecaddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4ecaddbb6a  ptest xmm6, xmm6
00007e4ecaddbb6f  jnz 0x00007E4ECADDCAAE
00007e4ecaddbb75  vxorps xmm15, xmm15, xmm15
00007e4ecaddbb7a  vpbroadcastq xmm15, xmm15
00007e4ecaddbb7f  movaps xmm9, xmm12
00007e4ecaddbb83  mulpd xmm9, xmm10
00007e4ecaddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4ecaddbb8e  ptest xmm6, xmm6
00007e4ecaddbb93  jnz 0x00007E4ECADDCBF0
00007e4ecaddbb99  movaps xmm10, xmm12
00007e4ecaddbb9d  mulpd xmm10, xmm11
00007e4ecaddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4ecaddbba8  ptest xmm6, xmm6
00007e4ecaddbbad  jnz 0x00007E4ECADDCD34
00007e4ecaddbbb3  movaps xmm11, [r15+0x1F0]
00007e4ecaddbbbb  movaps xmm6, xmm12
00007e4ecaddbbbf  mulpd xmm6, xmm11
00007e4ecaddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4ecaddbbc9  ptest xmm5, xmm5
00007e4ecaddbbce  jnz 0x00007E4ECADDCE78
00007e4ecaddbbd4  movaps xmm12, [r15+0x2A0]
00007e4ecaddbbdc  vmovaps [rsp+0x80], xmm12
00007e4ecaddbbe5  vmovaps xmm11, [rsp+0x80]
00007e4ecaddbbee  por xmm12, xmm11
00007e4ecaddbbf3  movaps xmm11, [r15+0x250]
00007e4ecaddbbfb  vmovaps [rsp+0x80], xmm11
00007e4ecaddbc04  vmovaps xmm5, [rsp+0x80]
00007e4ecaddbc0d  por xmm11, xmm5
00007e4ecaddbc12  vmovaps xmm4, [rsp+0x70]
00007e4ecaddbc18  vpermilpd xmm4, xmm4, 0x00
00007e4ecaddbc1e  movaps xmm3, xmm5
00007e4ecaddbc21  mulpd xmm3, xmm4
00007e4ecaddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007e4ecaddbc2a  ptest xmm2, xmm2
00007e4ecaddbc2f  jnz 0x00007E4ECADDCFBA
00007e4ecaddbc35  mov [rsp+0x80], rax
00007e4ecaddbc3d  xor eax, eax
00007e4ecaddbc3f  mov r12d, 0x40
00007e4ecaddbc45  mov r11d, 0x200
00007e4ecaddbc4b  cmp r12, r11
00007e4ecaddbc4e  cmc
00007e4ecaddbc4f  lahf
00007e4ecaddbc50  seto al
00007e4ecaddbc53  mov [r15+0x108], eax
00007e4ecaddbc5a  movaps xmm5, xmm8
00007e4ecaddbc5e  addpd xmm5, xmm15
00007e4ecaddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007e4ecaddbc68  ptest xmm4, xmm4
00007e4ecaddbc6d  jnz 0x00007E4ECADDD0FA
00007e4ecaddbc73  movaps xmm8, [r15+0x1B0]
00007e4ecaddbc7b  movaps xmm4, xmm9
00007e4ecaddbc7f  addpd xmm4, xmm8
00007e4ecaddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007e4ecaddbc89  ptest xmm2, xmm2
00007e4ecaddbc8e  jnz 0x00007E4ECADDD23C
00007e4ecaddbc94  movaps xmm9, xmm10
00007e4ecaddbc98  addpd xmm9, xmm8
00007e4ecaddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007e4ecaddbca3  ptest xmm2, xmm2
00007e4ecaddbca8  jnz 0x00007E4ECADDD37E
00007e4ecaddbcae  movaps xmm10, [r15+0x2F0]
00007e4ecaddbcb6  vmovaps [rsp+0x90], xmm10
00007e4ecaddbcbf  vmovaps xmm8, [rsp+0x90]
00007e4ecaddbcc8  por xmm10, xmm8
00007e4ecaddbccd  movaps xmm8, [r15+0x2E0]
00007e4ecaddbcd5  vmovaps [rsp+0x90], xmm8
00007e4ecaddbcde  vmovaps xmm2, [rsp+0x90]
00007e4ecaddbce7  por xmm8, xmm2
00007e4ecaddbcec  movaps xmm2, [r15+0x2D0]
00007e4ecaddbcf4  vmovaps [rsp+0x90], xmm2
00007e4ecaddbcfd  vmovaps [rsp+0xA0], xmm1
00007e4ecaddbd06  vmovaps xmm1, [rsp+0x90]
00007e4ecaddbd0f  por xmm2, xmm1
00007e4ecaddbd13  movaps xmm1, [r15+0x200]
00007e4ecaddbd1b  vmovaps [rsp+0x90], xmm1
00007e4ecaddbd24  vmovaps [rsp+0xB0], xmm15
00007e4ecaddbd2d  vmovaps xmm15, [rsp+0x90]
00007e4ecaddbd36  por xmm1, xmm15
00007e4ecaddbd3b  movaps xmm15, [r15+0x1C0]
00007e4ecaddbd43  vmovaps [rsp+0x90], xmm15
00007e4ecaddbd4c  vmovaps [rsp+0xC0], xmm1
00007e4ecaddbd55  vmovaps xmm1, [rsp+0x90]
00007e4ecaddbd5e  por xmm15, xmm1
00007e4ecaddbd63  movaps xmm1, [r15+0x190]
00007e4ecaddbd6b  vmovaps [rsp+0x90], xmm1
00007e4ecaddbd74  vmovaps [rsp+0xD0], xmm15
00007e4ecaddbd7d  vmovaps xmm15, [rsp+0x90]
00007e4ecaddbd86  por xmm1, xmm15
00007e4ecaddbd8b  movaps xmm15, [r15+0x300]
00007e4ecaddbd93  vmovaps [rsp+0x90], xmm15
00007e4ecaddbd9c  vmovaps [rsp+0xE0], xmm1
00007e4ecaddbda5  vmovaps xmm1, [rsp+0x90]
00007e4ecaddbdae  por xmm15, xmm1
00007e4ecaddbdb3  mov rax, [rsp+0x80]
00007e4ecaddbdbb  lea r12, [rax+0xA0]
00007e4ecaddbdc2  movups xmm1, [r13+r12*1]
00007e4ecaddbdc8  lea r12, [rax+0xB0]
00007e4ecaddbdcf  vmovaps [rsp+0x80], xmm1
00007e4ecaddbdd8  movups xmm1, [r13+r12*1]
00007e4ecaddbdde  vmovaps [rsp+0x90], xmm1
00007e4ecaddbde7  vmovaps [rsp+0xF0], xmm15
00007e4ecaddbdf0  vmovaps xmm15, [rsp+0xB0]
00007e4ecaddbdf9  vmovaps [rsp+0xB0], xmm14
00007e4ecaddbe02  movaps xmm1, xmm6
00007e4ecaddbe05  addpd xmm1, xmm15
00007e4ecaddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4ecaddbe0f  ptest xmm14, xmm14
00007e4ecaddbe15  jnz 0x00007E4ECADDD4D6
00007e4ecaddbe1b  lea r12, [rax+0xF0]
00007e4ecaddbe22  movups xmm15, [r13+r12*1]
00007e4ecaddbe28  movaps xmm14, xmm4
00007e4ecaddbe2c  addpd xmm14, xmm3
00007e4ecaddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4ecaddbe37  ptest xmm6, xmm6
00007e4ecaddbe3c  jnz 0x00007E4ECADDD621
00007e4ecaddbe42  movaps xmm6, xmm9
00007e4ecaddbe46  addpd xmm6, xmm7
00007e4ecaddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007e4ecaddbe4f  ptest xmm4, xmm4
00007e4ecaddbe54  jnz 0x00007E4ECADDD763
00007e4ecaddbe5a  vmovaps xmm9, [rsp+0x70]
00007e4ecaddbe60  vpermilpd xmm9, xmm9, 0x00
00007e4ecaddbe66  vmovaps xmm4, [rsp+0x90]
00007e4ecaddbe6f  movaps xmm7, xmm4
00007e4ecaddbe72  mulpd xmm7, xmm9
00007e4ecaddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007e4ecaddbe7c  ptest xmm3, xmm3
00007e4ecaddbe81  jnz 0x00007E4ECADDD8A4
00007e4ecaddbe87  vmovaps xmm9, [rsp+0x50]
00007e4ecaddbe8d  vpermilpd xmm9, xmm9, 0x00
00007e4ecaddbe93  movaps xmm4, xmm15
00007e4ecaddbe97  mulpd xmm4, xmm9
00007e4ecaddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4ecaddbea1  ptest xmm3, xmm3
00007e4ecaddbea6  jnz 0x00007E4ECADDD9E5
00007e4ecaddbeac  lea r12, [rax+0xE0]
00007e4ecaddbeb3  movups xmm15, [r13+r12*1]
00007e4ecaddbeb9  vmovaps xmm9, [rsp+0x70]
00007e4ecaddbebf  vpermilpd xmm9, xmm9, 0x00
00007e4ecaddbec5  vmovaps [rsp+0x70], xmm1
00007e4ecaddbecb  vmovaps xmm1, [rsp+0x80]
00007e4ecaddbed4  vmovaps [rsp+0x80], xmm15
00007e4ecaddbedd  movaps xmm3, xmm1
00007e4ecaddbee0  mulpd xmm3, xmm9
00007e4ecaddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007e4ecaddbeea  ptest xmm15, xmm15
00007e4ecaddbef0  jnz 0x00007E4ECADDDB31
00007e4ecaddbef6  vmovaps xmm1, [rsp+0xF0]
00007e4ecaddbeff  vmovaps xmm15, [rsp+0xF0]
00007e4ecaddbf08  por xmm1, xmm15
00007e4ecaddbf0d  movaps [r15+0x300], xmm1
00007e4ecaddbf15  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddbf1e  vmovaps xmm9, [rsp+0xE0]
00007e4ecaddbf27  por xmm15, xmm9
00007e4ecaddbf2c  movaps [r15+0x190], xmm15
00007e4ecaddbf34  vmovaps xmm9, [rsp+0x50]
00007e4ecaddbf3a  vpermilpd xmm9, xmm9, 0x00
00007e4ecaddbf40  vmovaps [rsp+0x90], xmm1
00007e4ecaddbf49  vmovaps [rsp+0xE0], xmm15
00007e4ecaddbf52  vmovaps xmm15, [rsp+0x80]
00007e4ecaddbf5b  vmovaps [rsp+0x80], xmm14
00007e4ecaddbf64  movaps xmm1, xmm15
00007e4ecaddbf68  mulpd xmm1, xmm9
00007e4ecaddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4ecaddbf72  ptest xmm14, xmm14
00007e4ecaddbf78  jnz 0x00007E4ECADDDC72
00007e4ecaddbf7e  lea r12, [rax+0x90]
00007e4ecaddbf85  movups xmm15, [r13+r12*1]
00007e4ecaddbf8b  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddbf94  vmovaps xmm9, [rsp+0xD0]
00007e4ecaddbf9d  por xmm14, xmm9
00007e4ecaddbfa2  movaps [r15+0x1C0], xmm14
00007e4ecaddbfaa  vmovaps xmm9, [rsp+0xC0]
00007e4ecaddbfb3  vmovaps [rsp+0xD0], xmm1
00007e4ecaddbfbc  vmovaps xmm1, [rsp+0xC0]
00007e4ecaddbfc5  por xmm9, xmm1
00007e4ecaddbfca  movaps [r15+0x200], xmm9
00007e4ecaddbfd2  vmovaps [rsp+0xC0], xmm2
00007e4ecaddbfdb  vmovaps xmm1, [rsp+0xC0]
00007e4ecaddbfe4  por xmm2, xmm1
00007e4ecaddbfe8  movaps [r15+0x2D0], xmm2
00007e4ecaddbff0  vmovaps [rsp+0xC0], xmm8
00007e4ecaddbff9  vmovaps xmm1, [rsp+0xC0]
00007e4ecaddc002  por xmm8, xmm1
00007e4ecaddc007  movaps [r15+0x2E0], xmm8
00007e4ecaddc00f  vmovaps [rsp+0xC0], xmm15
00007e4ecaddc018  movaps xmm1, xmm5
00007e4ecaddc01b  addpd xmm1, xmm7
00007e4ecaddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4ecaddc024  ptest xmm15, xmm15
00007e4ecaddc02a  jnz 0x00007E4ECADDDDBE
00007e4ecaddc030  vmovaps xmm15, [rsp+0x50]
00007e4ecaddc036  vpermilpd xmm15, xmm15, 0x00
00007e4ecaddc03c  vmovaps xmm5, [rsp+0xC0]
00007e4ecaddc045  vmovaps [rsp+0xC0], xmm1
00007e4ecaddc04e  movaps xmm7, xmm5
00007e4ecaddc051  mulpd xmm7, xmm15
00007e4ecaddc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007e4ecaddc05b  ptest xmm1, xmm1
00007e4ecaddc060  jnz 0x00007E4ECADDDEFE
00007e4ecaddc066  lea r12, [rax+0x80]
00007e4ecaddc06d  movups xmm1, [r13+r12*1]
00007e4ecaddc073  vmovaps xmm5, [rsp+0x70]
00007e4ecaddc079  vmovaps [rsp+0x70], xmm1
00007e4ecaddc07f  movaps xmm15, xmm5
00007e4ecaddc083  addpd xmm15, xmm3
00007e4ecaddc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecaddc08e  ptest xmm1, xmm1
00007e4ecaddc093  jnz 0x00007E4ECADDE049
00007e4ecaddc099  vmovaps xmm5, [rsp+0x80]
00007e4ecaddc0a2  movaps xmm1, xmm5
00007e4ecaddc0a5  addpd xmm1, xmm4
00007e4ecaddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007e4ecaddc0ae  ptest xmm3, xmm3
00007e4ecaddc0b3  jnz 0x00007E4ECADDE18B
00007e4ecaddc0b9  vmovaps [rsp+0x80], xmm10
00007e4ecaddc0c2  vmovaps xmm5, [rsp+0x80]
00007e4ecaddc0cb  por xmm10, xmm5
00007e4ecaddc0d0  movaps [r15+0x2F0], xmm10
00007e4ecaddc0d8  vmovaps xmm5, [rsp+0x50]
00007e4ecaddc0de  vpermilpd xmm5, xmm5, 0x00
00007e4ecaddc0e4  vmovaps xmm3, [rsp+0x70]
00007e4ecaddc0ea  vmovaps [rsp+0x50], xmm1
00007e4ecaddc0f0  movaps xmm4, xmm3
00007e4ecaddc0f3  mulpd xmm4, xmm5
00007e4ecaddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4ecaddc0fc  ptest xmm1, xmm1
00007e4ecaddc101  jnz 0x00007E4ECADDE2CB
00007e4ecaddc107  lea r12, [rax+0xD0]
00007e4ecaddc10e  movups xmm1, [r13+r12*1]
00007e4ecaddc114  vmovaps xmm3, [rsp+0xD0]
00007e4ecaddc11d  vmovaps [rsp+0x70], xmm1
00007e4ecaddc123  movaps xmm5, xmm6
00007e4ecaddc126  addpd xmm5, xmm3
00007e4ecaddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007e4ecaddc12f  ptest xmm1, xmm1
00007e4ecaddc134  jnz 0x00007E4ECADDE415
00007e4ecaddc13a  vmovaps xmm1, [rsp+0x60]
00007e4ecaddc140  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc146  movaps xmm6, xmm9
00007e4ecaddc14a  mulpd xmm6, xmm1
00007e4ecaddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4ecaddc153  ptest xmm3, xmm3
00007e4ecaddc158  jnz 0x00007E4ECADDE555
00007e4ecaddc15e  movaps [r15+0x260], xmm6
00007e4ecaddc166  vxorps xmm1, xmm1, xmm1
00007e4ecaddc16a  vpbroadcastq xmm1, xmm1
00007e4ecaddc16f  movaps [r15+0x1B0], xmm1
00007e4ecaddc177  vmovaps xmm1, [rsp+0x60]
00007e4ecaddc17d  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc183  vmovaps xmm3, [rsp+0x70]
00007e4ecaddc189  vmovaps [rsp+0x70], xmm15
00007e4ecaddc18f  movaps xmm9, xmm3
00007e4ecaddc193  mulpd xmm9, xmm1
00007e4ecaddc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4ecaddc19e  ptest xmm15, xmm15
00007e4ecaddc1a4  jnz 0x00007E4ECADDE696
00007e4ecaddc1aa  lea r12, [rax+0xC0]
00007e4ecaddc1b1  movups xmm1, [r13+r12*1]
00007e4ecaddc1b7  vmovaps xmm3, [rsp+0xC0]
00007e4ecaddc1c0  vmovaps [rsp+0x80], xmm1
00007e4ecaddc1c9  movaps xmm15, xmm3
00007e4ecaddc1cd  addpd xmm15, xmm7
00007e4ecaddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecaddc1d8  ptest xmm1, xmm1
00007e4ecaddc1dd  jnz 0x00007E4ECADDE7E2
00007e4ecaddc1e3  vmovaps [rsp+0xC0], xmm13
00007e4ecaddc1ec  vmovaps xmm1, [rsp+0xC0]
00007e4ecaddc1f5  por xmm13, xmm1
00007e4ecaddc1fa  movaps [r15+0x270], xmm13
00007e4ecaddc202  vmovaps xmm1, [rsp+0xB0]
00007e4ecaddc20b  vmovaps xmm7, [rsp+0xB0]
00007e4ecaddc214  por xmm1, xmm7
00007e4ecaddc218  movaps [r15+0x1A0], xmm1
00007e4ecaddc220  vmovaps xmm1, [rsp+0x60]
00007e4ecaddc226  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc22c  vmovaps [rsp+0xB0], xmm1
00007e4ecaddc235  vmovaps xmm1, [rsp+0x80]
00007e4ecaddc23e  vmovaps [rsp+0x80], xmm15
00007e4ecaddc247  vmovaps xmm15, [rsp+0xB0]
00007e4ecaddc250  vmovaps [rsp+0xB0], xmm14
00007e4ecaddc259  movaps xmm3, xmm1
00007e4ecaddc25c  mulpd xmm3, xmm15
00007e4ecaddc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007e4ecaddc266  ptest xmm14, xmm14
00007e4ecaddc26c  jnz 0x00007E4ECADDE924
00007e4ecaddc272  lea r12, [rax+0x20]
00007e4ecaddc276  movups xmm1, [r13+r12*1]
00007e4ecaddc27c  movaps [r15+0x110], xmm1
00007e4ecaddc284  vmovaps xmm14, [rsp+0x70]
00007e4ecaddc28a  vmovaps [rsp+0x70], xmm1
00007e4ecaddc290  movaps xmm15, xmm14
00007e4ecaddc294  addpd xmm15, xmm4
00007e4ecaddc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4ecaddc29f  ptest xmm1, xmm1
00007e4ecaddc2a4  jnz 0x00007E4ECADDEA6F
00007e4ecaddc2aa  vmovaps xmm1, [rsp+0x60]
00007e4ecaddc2b0  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc2b6  movaps xmm14, xmm2
00007e4ecaddc2ba  mulpd xmm14, xmm1
00007e4ecaddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007e4ecaddc2c5  ptest xmm4, xmm4
00007e4ecaddc2ca  jnz 0x00007E4ECADDEBB2
00007e4ecaddc2d0  vmovaps xmm4, [rsp+0x50]
00007e4ecaddc2d6  movaps xmm1, xmm4
00007e4ecaddc2d9  addpd xmm1, xmm9
00007e4ecaddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4ecaddc2e3  ptest xmm2, xmm2
00007e4ecaddc2e8  jnz 0x00007E4ECADDECF4
00007e4ecaddc2ee  vmovaps xmm9, [rsp+0x30]
00007e4ecaddc2f4  vpermilpd xmm9, xmm9, 0x00
00007e4ecaddc2fa  vmovaps xmm2, [rsp+0x70]
00007e4ecaddc300  vmovaps [rsp+0x50], xmm1
00007e4ecaddc306  movaps xmm4, xmm2
00007e4ecaddc309  mulpd xmm4, xmm9
00007e4ecaddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4ecaddc313  ptest xmm1, xmm1
00007e4ecaddc318  jnz 0x00007E4ECADDEE35
00007e4ecaddc31e  vmovaps xmm1, [rsp+0x30]
00007e4ecaddc324  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc32a  vmovaps xmm2, [rsp+0x90]
00007e4ecaddc333  vmovaps [rsp+0x60], xmm15
00007e4ecaddc339  movaps xmm9, xmm2
00007e4ecaddc33d  mulpd xmm9, xmm1
00007e4ecaddc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4ecaddc348  ptest xmm15, xmm15
00007e4ecaddc34e  jnz 0x00007E4ECADDEF76
00007e4ecaddc354  vmovaps xmm15, [rsp+0x80]
00007e4ecaddc35d  movaps xmm1, xmm15
00007e4ecaddc361  addpd xmm1, xmm6
00007e4ecaddc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4ecaddc36a  ptest xmm2, xmm2
00007e4ecaddc36f  jnz 0x00007E4ECADDF0B8
00007e4ecaddc375  movaps xmm15, xmm5
00007e4ecaddc379  addpd xmm15, xmm3
00007e4ecaddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007e4ecaddc384  ptest xmm6, xmm6
00007e4ecaddc389  jnz 0x00007E4ECADDF1F9
00007e4ecaddc38f  vmovaps xmm6, [rsp+0x30]
00007e4ecaddc395  vpermilpd xmm6, xmm6, 0x00
00007e4ecaddc39b  movaps xmm5, xmm8
00007e4ecaddc39f  mulpd xmm5, xmm6
00007e4ecaddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007e4ecaddc3a8  ptest xmm3, xmm3
00007e4ecaddc3ad  jnz 0x00007E4ECADDF33B
00007e4ecaddc3b3  vmovaps xmm8, [rsp+0x30]
00007e4ecaddc3b9  vpermilpd xmm8, xmm8, 0x00
00007e4ecaddc3bf  movaps xmm6, xmm10
00007e4ecaddc3c3  mulpd xmm6, xmm8
00007e4ecaddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4ecaddc3cd  ptest xmm3, xmm3
00007e4ecaddc3d2  jnz 0x00007E4ECADDF47C
00007e4ecaddc3d8  vmovaps xmm8, [rsp+0x60]
00007e4ecaddc3de  movaps xmm10, xmm8
00007e4ecaddc3e2  addpd xmm10, xmm14
00007e4ecaddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007e4ecaddc3ed  ptest xmm3, xmm3
00007e4ecaddc3f2  jnz 0x00007E4ECADDF5BE
00007e4ecaddc3f8  vmovaps xmm8, [rsp+0x50]
00007e4ecaddc3fe  movaps xmm14, xmm8
00007e4ecaddc402  addpd xmm14, xmm4
00007e4ecaddc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007e4ecaddc40d  ptest xmm3, xmm3
00007e4ecaddc412  jnz 0x00007E4ECADDF702
00007e4ecaddc418  vmovaps xmm8, [rsp+0x40]
00007e4ecaddc41e  vpermilpd xmm8, xmm8, 0x00
00007e4ecaddc424  movaps xmm4, xmm13
00007e4ecaddc428  mulpd xmm4, xmm8
00007e4ecaddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4ecaddc432  ptest xmm3, xmm3
00007e4ecaddc437  jnz 0x00007E4ECADDF845
00007e4ecaddc43d  movaps xmm13, xmm15
00007e4ecaddc441  addpd xmm13, xmm9
00007e4ecaddc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007e4ecaddc44c  ptest xmm8, xmm8
00007e4ecaddc452  jnz 0x00007E4ECADDF987
00007e4ecaddc458  movaps xmm15, xmm1
00007e4ecaddc45c  addpd xmm15, xmm5
00007e4ecaddc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4ecaddc467  ptest xmm9, xmm9
00007e4ecaddc46d  jnz 0x00007E4ECADDFACB
00007e4ecaddc473  vmovaps [rsp+0x30], xmm11
00007e4ecaddc479  vmovaps xmm1, [rsp+0x30]
00007e4ecaddc47f  por xmm11, xmm1
00007e4ecaddc484  movaps [r15+0x250], xmm11
00007e4ecaddc48c  vmovaps [rsp+0x30], xmm12
00007e4ecaddc492  vmovaps xmm1, [rsp+0x30]
00007e4ecaddc498  por xmm12, xmm1
00007e4ecaddc49d  movaps [r15+0x2A0], xmm12
00007e4ecaddc4a5  vmovaps xmm1, [rsp+0xA0]
00007e4ecaddc4ae  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddc4b7  por xmm1, xmm11
00007e4ecaddc4bc  movaps [r15+0x1D0], xmm1
00007e4ecaddc4c4  lea r12, [rax+0x40]
00007e4ecaddc4c8  movups xmm1, [r13+r12*1]
00007e4ecaddc4ce  movaps [r15+0x2C0], xmm1
00007e4ecaddc4d6  vmovaps xmm11, [rsp+0x40]
00007e4ecaddc4dc  vpermilpd xmm11, xmm11, 0x00
00007e4ecaddc4e2  vmovaps xmm8, [rsp+0xE0]
00007e4ecaddc4eb  movaps xmm9, xmm8
00007e4ecaddc4ef  mulpd xmm9, xmm11
00007e4ecaddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007e4ecaddc4fa  ptest xmm5, xmm5
00007e4ecaddc4ff  jnz 0x00007E4ECADDFC17
00007e4ecaddc505  movaps xmm11, xmm10
00007e4ecaddc509  addpd xmm11, xmm6
00007e4ecaddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007e4ecaddc514  ptest xmm8, xmm8
00007e4ecaddc51a  jnz 0x00007E4ECADDFD5B
00007e4ecaddc520  movaps xmm10, xmm14
00007e4ecaddc524  addpd xmm10, xmm4
00007e4ecaddc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007e4ecaddc52f  ptest xmm8, xmm8
00007e4ecaddc535  jnz 0x00007E4ECADDFE9E
00007e4ecaddc53b  vmovaps xmm14, [rsp+0x40]
00007e4ecaddc541  vpermilpd xmm14, xmm14, 0x00
00007e4ecaddc547  movaps xmm8, xmm1
00007e4ecaddc54b  mulpd xmm8, xmm14
00007e4ecaddc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4ecaddc556  ptest xmm6, xmm6
00007e4ecaddc55b  jnz 0x00007E4ECADDFFE1
00007e4ecaddc561  movaps xmm1, [r15+0x2B0]
00007e4ecaddc569  vmovaps xmm14, [rsp+0x40]
00007e4ecaddc56f  vpermilpd xmm14, xmm14, 0x00
00007e4ecaddc575  movaps xmm6, xmm1
00007e4ecaddc578  mulpd xmm6, xmm14
00007e4ecaddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4ecaddc582  ptest xmm5, xmm5
00007e4ecaddc587  jnz 0x00007E4ECADE0124
00007e4ecaddc58d  vmovaps xmm1, [rsp+0x10]
00007e4ecaddc593  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc599  movaps xmm14, xmm12
00007e4ecaddc59d  mulpd xmm14, xmm1
00007e4ecaddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007e4ecaddc5a8  ptest xmm5, xmm5
00007e4ecaddc5ad  jnz 0x00007E4ECADE0265
00007e4ecaddc5b3  movaps xmm1, xmm13
00007e4ecaddc5b7  addpd xmm1, xmm9
00007e4ecaddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4ecaddc5c1  ptest xmm12, xmm12
00007e4ecaddc5c7  jnz 0x00007E4ECADE03A8
00007e4ecaddc5cd  vmovaps xmm13, [rsp+0x10]
00007e4ecaddc5d3  vpermilpd xmm13, xmm13, 0x00
00007e4ecaddc5d9  movaps xmm12, xmm7
00007e4ecaddc5dd  mulpd xmm12, xmm13
00007e4ecaddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4ecaddc5e8  ptest xmm9, xmm9
00007e4ecaddc5ee  jnz 0x00007E4ECADE04EA
00007e4ecaddc5f4  movaps xmm13, xmm15
00007e4ecaddc5f8  addpd xmm13, xmm8
00007e4ecaddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007e4ecaddc603  ptest xmm9, xmm9
00007e4ecaddc609  jnz 0x00007E4ECADE062D
00007e4ecaddc60f  movaps xmm15, [r15+0x290]
00007e4ecaddc617  vmovaps xmm9, [rsp+0x10]
00007e4ecaddc61d  vpermilpd xmm9, xmm9, 0x00
00007e4ecaddc623  movaps xmm8, xmm15
00007e4ecaddc627  mulpd xmm8, xmm9
00007e4ecaddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4ecaddc632  ptest xmm7, xmm7
00007e4ecaddc637  jnz 0x00007E4ECADE0771
00007e4ecaddc63d  movaps xmm15, xmm11
00007e4ecaddc641  addpd xmm15, xmm6
00007e4ecaddc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4ecaddc64c  ptest xmm9, xmm9
00007e4ecaddc652  jnz 0x00007E4ECADE08B5
00007e4ecaddc658  movaps xmm11, [r15+0x1E0]
00007e4ecaddc660  vmovaps xmm9, [rsp+0x10]
00007e4ecaddc666  vpermilpd xmm9, xmm9, 0x00
00007e4ecaddc66c  movaps xmm7, xmm11
00007e4ecaddc670  mulpd xmm7, xmm9
00007e4ecaddc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4ecaddc67a  ptest xmm6, xmm6
00007e4ecaddc67f  jnz 0x00007E4ECADE09F8
00007e4ecaddc685  movaps xmm11, xmm10
00007e4ecaddc689  addpd xmm11, xmm14
00007e4ecaddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007e4ecaddc694  ptest xmm9, xmm9
00007e4ecaddc69a  jnz 0x00007E4ECADE0B3A
00007e4ecaddc6a0  lea r12, [rax+0x70]
00007e4ecaddc6a4  movups xmm14, [r13+r12*1]
00007e4ecaddc6aa  movaps [r15+0x240], xmm14
00007e4ecaddc6b2  movaps xmm10, xmm1
00007e4ecaddc6b6  addpd xmm10, xmm12
00007e4ecaddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007e4ecaddc6c1  ptest xmm9, xmm9
00007e4ecaddc6c7  jnz 0x00007E4ECADE0C88
00007e4ecaddc6cd  movaps [r15+0x170], xmm10
00007e4ecaddc6d5  vmovaps xmm1, [rsp+0x20]
00007e4ecaddc6db  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc6e1  movaps xmm12, xmm14
00007e4ecaddc6e5  mulpd xmm12, xmm1
00007e4ecaddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4ecaddc6f0  ptest xmm9, xmm9
00007e4ecaddc6f6  jnz 0x00007E4ECADE0DCB
00007e4ecaddc6fc  vmovaps xmm1, [rsp+0x20]
00007e4ecaddc702  vpermilpd xmm1, xmm1, 0x00
00007e4ecaddc708  vmovaps xmm9, [rsp+0xB0]
00007e4ecaddc711  movaps xmm14, xmm9
00007e4ecaddc715  mulpd xmm14, xmm1
00007e4ecaddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4ecaddc720  ptest xmm6, xmm6
00007e4ecaddc725  jnz 0x00007E4ECADE0F0E
00007e4ecaddc72b  movaps [r15+0x180], xmm14
00007e4ecaddc733  movaps xmm1, xmm13
00007e4ecaddc737  addpd xmm1, xmm8
00007e4ecaddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007e4ecaddc741  ptest xmm9, xmm9
00007e4ecaddc747  jnz 0x00007E4ECADE1051
00007e4ecaddc74d  movaps [r15+0x210], xmm1
00007e4ecaddc755  movups xmm13, [r13+rax*1]
00007e4ecaddc75b  lea r12, [rax+0x10]
00007e4ecaddc75f  movups xmm9, [r13+r12*1]
00007e4ecaddc765  movaps [r15+0x230], xmm9
00007e4ecaddc76d  movaps xmm8, xmm15
00007e4ecaddc771  addpd xmm8, xmm7
00007e4ecaddc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4ecaddc77c  ptest xmm6, xmm6
00007e4ecaddc781  jnz 0x00007E4ECADE11A7
00007e4ecaddc787  movaps [r15+0x130], xmm8
00007e4ecaddc78f  vmovaps xmm15, [rsp+0x20]
00007e4ecaddc795  vpermilpd xmm15, xmm15, 0x00
00007e4ecaddc79b  movaps xmm7, xmm9
00007e4ecaddc79f  mulpd xmm7, xmm15
00007e4ecaddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4ecaddc7a9  ptest xmm6, xmm6
00007e4ecaddc7ae  jnz 0x00007E4ECADE12EA
00007e4ecaddc7b4  movaps [r15+0x220], xmm7
00007e4ecaddc7bc  vmovaps xmm15, [rsp+0x20]
00007e4ecaddc7c2  vpermilpd xmm15, xmm15, 0x00
00007e4ecaddc7c8  movaps xmm9, xmm13
00007e4ecaddc7cc  mulpd xmm9, xmm15
00007e4ecaddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4ecaddc7d7  ptest xmm6, xmm6
00007e4ecaddc7dc  jnz 0x00007E4ECADE142C
00007e4ecaddc7e2  movaps xmm15, xmm11
00007e4ecaddc7e6  addpd xmm15, xmm12
00007e4ecaddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4ecaddc7f1  ptest xmm13, xmm13
00007e4ecaddc7f7  jnz 0x00007E4ECADE1570
00007e4ecaddc7fd  movaps [r15+0x140], xmm15
00007e4ecaddc805  movaps xmm13, xmm10
00007e4ecaddc809  addpd xmm13, xmm14
00007e4ecaddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4ecaddc814  ptest xmm12, xmm12
00007e4ecaddc81a  jnz 0x00007E4ECADE16B4
00007e4ecaddc820  movaps [r15+0x150], xmm13
00007e4ecaddc828  movaps xmm14, xmm1
00007e4ecaddc82c  addpd xmm14, xmm7
00007e4ecaddc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007e4ecaddc837  ptest xmm12, xmm12
00007e4ecaddc83d  jnz 0x00007E4ECADE17F8
00007e4ecaddc843  movaps [r15+0x160], xmm14
00007e4ecaddc84b  movaps xmm1, xmm8
00007e4ecaddc84f  addpd xmm1, xmm9
00007e4ecaddc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4ecaddc859  ptest xmm12, xmm12
00007e4ecaddc85f  jnz 0x00007E4ECADE193A
00007e4ecaddc865  movaps [r15+0x120], xmm1
00007e4ecaddc86d  movups [r13+r14*1], xmm15
00007e4ecaddc873  lea rax, [r14+0x10]
00007e4ecaddc877  movups [r13+rax*1], xmm13
00007e4ecaddc87d  lea rax, [r14+0x20]
00007e4ecaddc881  movups [r13+rax*1], xmm14
00007e4ecaddc887  lea rax, [r14+0x30]
00007e4ecaddc88b  movups [r13+rax*1], xmm1
00007e4ecaddc891  mov eax, [r15+0x108]
00007e4ecaddc898  sahf
00007e4ecaddc899  jnz 0x00007E4ECADDC8CB
00007e4ecaddc89b  cmp dword ptr [r15+0x318], 0x00
00007e4ecaddc8a3  jz 0x00007E4ECADDB900
00007e4ecaddc8a9  nop [rax+rax*1], ax
00007e4ecaddc8b2  nop [rax+rax*1], eax
00007e4ecaddc8ba  mov eax, 0x410444
00007e4ecaddc8bf  mov [r15+0x100], rax
00007e4ecaddc8c6  jmp 0x00007E4ECABFE110
00007e4ecaddc8cb  cmp dword ptr [r15+0x318], 0x00
00007e4ecaddc8d3  jz 0x00007E4ECADD57E0
00007e4ecaddc8d9  nop [rax+rax*1], ax
00007e4ecaddc8e2  nop [rax+rax*1], eax
00007e4ecaddc8ea  mov eax, 0x410278
00007e4ecaddc8ef  mov [r15+0x100], rax
00007e4ecaddc8f6  jmp 0x00007E4ECABFE110
00007e4ecaddc8fb  int3
00007e4ecaddc8fc  call 0x00007E4ECACE27E0
00007e4ecaddc901  jmp 0x00007E4ECADDB9DF
00007e4ecaddc906  call 0x00007E4ECACE1570
00007e4ecaddc90b  jmp 0x00007E4ECADDB9E8
00007e4ecaddc910  call 0x00007E4ECACE27E0
00007e4ecaddc915  jmp 0x00007E4ECADDBA44
00007e4ecaddc91a  call 0x00007E4ECACE1570
00007e4ecaddc91f  jmp 0x00007E4ECADDBA4D
00007e4ecaddc924  call 0x00007E4ECACE27E0
00007e4ecaddc929  jmp 0x00007E4ECADDBA90
00007e4ecaddc92e  call 0x00007E4ECACE1570
00007e4ecaddc933  jmp 0x00007E4ECADDBA99
00007e4ecaddc938  call 0x00007E4ECAC0DC20
00007e4ecaddc93d  jmp 0x00007E4ECADDBAD8
00007e4ecaddc942  call 0x00007E4ECACD59C0
00007e4ecaddc947  jmp 0x00007E4ECADDBAEB
00007e4ecaddc94c  call 0x00007E4ECACE0E30
00007e4ecaddc951  jmp 0x00007E4ECADDBB09
00007e4ecaddc956  call 0x00007E4ECACDFBC0
00007e4ecaddc95b  jmp 0x00007E4ECADDBB13
00007e4ecaddc960  call 0x00007E4ECACDE950
00007e4ecaddc965  jmp 0x00007E4ECADDBB1D
00007e4ecaddc96a  sub rsp, 0x08
00007e4ecaddc96e  push rax
00007e4ecaddc96f  push rcx
00007e4ecaddc970  push rdx
00007e4ecaddc971  push rdi
00007e4ecaddc972  push rsi
00007e4ecaddc973  push r8
00007e4ecaddc975  push r9
00007e4ecaddc977  push r10
00007e4ecaddc979  push r11
00007e4ecaddc97b  sub rsp, 0xF0
00007e4ecaddc982  vmovaps [rsp], xmm0
00007e4ecaddc987  vmovaps [rsp+0x10], xmm1
00007e4ecaddc98d  vmovaps [rsp+0x20], xmm2
00007e4ecaddc993  vmovaps [rsp+0x30], xmm3
00007e4ecaddc999  vmovaps [rsp+0x40], xmm4
00007e4ecaddc99f  vmovaps [rsp+0x50], xmm5
00007e4ecaddc9a5  vmovaps [rsp+0x60], xmm6
00007e4ecaddc9ab  vmovaps [rsp+0x70], xmm7
00007e4ecaddc9b1  vmovaps [rsp+0x80], xmm9
00007e4ecaddc9ba  vmovaps [rsp+0x90], xmm10
00007e4ecaddc9c3  vmovaps [rsp+0xA0], xmm11
00007e4ecaddc9cc  vmovaps [rsp+0xB0], xmm12
00007e4ecaddc9d5  vmovaps [rsp+0xC0], xmm13
00007e4ecaddc9de  vmovaps [rsp+0xD0], xmm14
00007e4ecaddc9e7  vmovaps [rsp+0xE0], xmm15
00007e4ecaddc9f0  sub rsp, 0x30
00007e4ecaddc9f4  movaps [rsp], xmm8
00007e4ecaddc9f9  movaps [rsp+0x10], xmm12
00007e4ecaddc9ff  movaps [rsp+0x20], xmm15
00007e4ecaddca05  lea rdi, [rsp]
00007e4ecaddca09  mov esi, 0x00
00007e4ecaddca0e  mov rax, 0x5784BC1F5530
00007e4ecaddca18  call rax
00007e4ecaddca1a  movaps xmm8, [rsp]
00007e4ecaddca1f  add rsp, 0x30
00007e4ecaddca23  vmovaps xmm0, [rsp]
00007e4ecaddca28  vmovaps xmm1, [rsp+0x10]
00007e4ecaddca2e  vmovaps xmm2, [rsp+0x20]
00007e4ecaddca34  vmovaps xmm3, [rsp+0x30]
00007e4ecaddca3a  vmovaps xmm4, [rsp+0x40]
00007e4ecaddca40  vmovaps xmm5, [rsp+0x50]
00007e4ecaddca46  vmovaps xmm6, [rsp+0x60]
00007e4ecaddca4c  vmovaps xmm7, [rsp+0x70]
00007e4ecaddca52  vmovaps xmm9, [rsp+0x80]
00007e4ecaddca5b  vmovaps xmm10, [rsp+0x90]
00007e4ecaddca64  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddca6d  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddca76  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddca7f  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddca88  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddca91  add rsp, 0xF0
00007e4ecaddca98  pop r11
00007e4ecaddca9a  pop r10
00007e4ecaddca9c  pop r9
00007e4ecaddca9e  pop r8
00007e4ecaddcaa0  pop rsi
00007e4ecaddcaa1  pop rdi
00007e4ecaddcaa2  pop rdx
00007e4ecaddcaa3  pop rcx
00007e4ecaddcaa4  pop rax
00007e4ecaddcaa5  add rsp, 0x08
00007e4ecaddcaa9  jmp 0x00007E4ECADDBB47
00007e4ecaddcaae  sub rsp, 0x08
00007e4ecaddcab2  push rax
00007e4ecaddcab3  push rcx
00007e4ecaddcab4  push rdx
00007e4ecaddcab5  push rdi
00007e4ecaddcab6  push rsi
00007e4ecaddcab7  push r8
00007e4ecaddcab9  push r9
00007e4ecaddcabb  push r10
00007e4ecaddcabd  push r11
00007e4ecaddcabf  sub rsp, 0xF0
00007e4ecaddcac6  vmovaps [rsp], xmm0
00007e4ecaddcacb  vmovaps [rsp+0x10], xmm1
00007e4ecaddcad1  vmovaps [rsp+0x20], xmm2
00007e4ecaddcad7  vmovaps [rsp+0x30], xmm3
00007e4ecaddcadd  vmovaps [rsp+0x40], xmm4
00007e4ecaddcae3  vmovaps [rsp+0x50], xmm5
00007e4ecaddcae9  vmovaps [rsp+0x60], xmm6
00007e4ecaddcaef  vmovaps [rsp+0x70], xmm8
00007e4ecaddcaf5  vmovaps [rsp+0x80], xmm9
00007e4ecaddcafe  vmovaps [rsp+0x90], xmm10
00007e4ecaddcb07  vmovaps [rsp+0xA0], xmm11
00007e4ecaddcb10  vmovaps [rsp+0xB0], xmm12
00007e4ecaddcb19  vmovaps [rsp+0xC0], xmm13
00007e4ecaddcb22  vmovaps [rsp+0xD0], xmm14
00007e4ecaddcb2b  vmovaps [rsp+0xE0], xmm15
00007e4ecaddcb34  sub rsp, 0x30
00007e4ecaddcb38  movaps [rsp], xmm7
00007e4ecaddcb3c  movaps [rsp+0x10], xmm9
00007e4ecaddcb42  movaps [rsp+0x20], xmm15
00007e4ecaddcb48  lea rdi, [rsp]
00007e4ecaddcb4c  mov esi, 0x00
00007e4ecaddcb51  mov rax, 0x5784BC1F5530
00007e4ecaddcb5b  call rax
00007e4ecaddcb5d  movaps xmm7, [rsp]
00007e4ecaddcb61  add rsp, 0x30
00007e4ecaddcb65  vmovaps xmm0, [rsp]
00007e4ecaddcb6a  vmovaps xmm1, [rsp+0x10]
00007e4ecaddcb70  vmovaps xmm2, [rsp+0x20]
00007e4ecaddcb76  vmovaps xmm3, [rsp+0x30]
00007e4ecaddcb7c  vmovaps xmm4, [rsp+0x40]
00007e4ecaddcb82  vmovaps xmm5, [rsp+0x50]
00007e4ecaddcb88  vmovaps xmm6, [rsp+0x60]
00007e4ecaddcb8e  vmovaps xmm8, [rsp+0x70]
00007e4ecaddcb94  vmovaps xmm9, [rsp+0x80]
00007e4ecaddcb9d  vmovaps xmm10, [rsp+0x90]
00007e4ecaddcba6  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddcbaf  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddcbb8  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddcbc1  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddcbca  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddcbd3  add rsp, 0xF0
00007e4ecaddcbda  pop r11
00007e4ecaddcbdc  pop r10
00007e4ecaddcbde  pop r9
00007e4ecaddcbe0  pop r8
00007e4ecaddcbe2  pop rsi
00007e4ecaddcbe3  pop rdi
00007e4ecaddcbe4  pop rdx
00007e4ecaddcbe5  pop rcx
00007e4ecaddcbe6  pop rax
00007e4ecaddcbe7  add rsp, 0x08
00007e4ecaddcbeb  jmp 0x00007E4ECADDBB75
00007e4ecaddcbf0  sub rsp, 0x08
00007e4ecaddcbf4  push rax
00007e4ecaddcbf5  push rcx
00007e4ecaddcbf6  push rdx
00007e4ecaddcbf7  push rdi
00007e4ecaddcbf8  push rsi
00007e4ecaddcbf9  push r8
00007e4ecaddcbfb  push r9
00007e4ecaddcbfd  push r10
00007e4ecaddcbff  push r11
00007e4ecaddcc01  sub rsp, 0xF0
00007e4ecaddcc08  vmovaps [rsp], xmm0
00007e4ecaddcc0d  vmovaps [rsp+0x10], xmm1
00007e4ecaddcc13  vmovaps [rsp+0x20], xmm2
00007e4ecaddcc19  vmovaps [rsp+0x30], xmm3
00007e4ecaddcc1f  vmovaps [rsp+0x40], xmm4
00007e4ecaddcc25  vmovaps [rsp+0x50], xmm5
00007e4ecaddcc2b  vmovaps [rsp+0x60], xmm6
00007e4ecaddcc31  vmovaps [rsp+0x70], xmm7
00007e4ecaddcc37  vmovaps [rsp+0x80], xmm8
00007e4ecaddcc40  vmovaps [rsp+0x90], xmm10
00007e4ecaddcc49  vmovaps [rsp+0xA0], xmm11
00007e4ecaddcc52  vmovaps [rsp+0xB0], xmm12
00007e4ecaddcc5b  vmovaps [rsp+0xC0], xmm13
00007e4ecaddcc64  vmovaps [rsp+0xD0], xmm14
00007e4ecaddcc6d  vmovaps [rsp+0xE0], xmm15
00007e4ecaddcc76  sub rsp, 0x30
00007e4ecaddcc7a  movaps [rsp], xmm9
00007e4ecaddcc7f  movaps [rsp+0x10], xmm12
00007e4ecaddcc85  movaps [rsp+0x20], xmm10
00007e4ecaddcc8b  lea rdi, [rsp]
00007e4ecaddcc8f  mov esi, 0x00
00007e4ecaddcc94  mov rax, 0x5784BC1F5530
00007e4ecaddcc9e  call rax
00007e4ecaddcca0  movaps xmm9, [rsp]
00007e4ecaddcca5  add rsp, 0x30
00007e4ecaddcca9  vmovaps xmm0, [rsp]
00007e4ecaddccae  vmovaps xmm1, [rsp+0x10]
00007e4ecaddccb4  vmovaps xmm2, [rsp+0x20]
00007e4ecaddccba  vmovaps xmm3, [rsp+0x30]
00007e4ecaddccc0  vmovaps xmm4, [rsp+0x40]
00007e4ecaddccc6  vmovaps xmm5, [rsp+0x50]
00007e4ecaddcccc  vmovaps xmm6, [rsp+0x60]
00007e4ecaddccd2  vmovaps xmm7, [rsp+0x70]
00007e4ecaddccd8  vmovaps xmm8, [rsp+0x80]
00007e4ecaddcce1  vmovaps xmm10, [rsp+0x90]
00007e4ecaddccea  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddccf3  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddccfc  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddcd05  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddcd0e  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddcd17  add rsp, 0xF0
00007e4ecaddcd1e  pop r11
00007e4ecaddcd20  pop r10
00007e4ecaddcd22  pop r9
00007e4ecaddcd24  pop r8
00007e4ecaddcd26  pop rsi
00007e4ecaddcd27  pop rdi
00007e4ecaddcd28  pop rdx
00007e4ecaddcd29  pop rcx
00007e4ecaddcd2a  pop rax
00007e4ecaddcd2b  add rsp, 0x08
00007e4ecaddcd2f  jmp 0x00007E4ECADDBB99
00007e4ecaddcd34  sub rsp, 0x08
00007e4ecaddcd38  push rax
00007e4ecaddcd39  push rcx
00007e4ecaddcd3a  push rdx
00007e4ecaddcd3b  push rdi
00007e4ecaddcd3c  push rsi
00007e4ecaddcd3d  push r8
00007e4ecaddcd3f  push r9
00007e4ecaddcd41  push r10
00007e4ecaddcd43  push r11
00007e4ecaddcd45  sub rsp, 0xF0
00007e4ecaddcd4c  vmovaps [rsp], xmm0
00007e4ecaddcd51  vmovaps [rsp+0x10], xmm1
00007e4ecaddcd57  vmovaps [rsp+0x20], xmm2
00007e4ecaddcd5d  vmovaps [rsp+0x30], xmm3
00007e4ecaddcd63  vmovaps [rsp+0x40], xmm4
00007e4ecaddcd69  vmovaps [rsp+0x50], xmm5
00007e4ecaddcd6f  vmovaps [rsp+0x60], xmm6
00007e4ecaddcd75  vmovaps [rsp+0x70], xmm7
00007e4ecaddcd7b  vmovaps [rsp+0x80], xmm8
00007e4ecaddcd84  vmovaps [rsp+0x90], xmm9
00007e4ecaddcd8d  vmovaps [rsp+0xA0], xmm11
00007e4ecaddcd96  vmovaps [rsp+0xB0], xmm12
00007e4ecaddcd9f  vmovaps [rsp+0xC0], xmm13
00007e4ecaddcda8  vmovaps [rsp+0xD0], xmm14
00007e4ecaddcdb1  vmovaps [rsp+0xE0], xmm15
00007e4ecaddcdba  sub rsp, 0x30
00007e4ecaddcdbe  movaps [rsp], xmm10
00007e4ecaddcdc3  movaps [rsp+0x10], xmm12
00007e4ecaddcdc9  movaps [rsp+0x20], xmm11
00007e4ecaddcdcf  lea rdi, [rsp]
00007e4ecaddcdd3  mov esi, 0x00
00007e4ecaddcdd8  mov rax, 0x5784BC1F5530
00007e4ecaddcde2  call rax
00007e4ecaddcde4  movaps xmm10, [rsp]
00007e4ecaddcde9  add rsp, 0x30
00007e4ecaddcded  vmovaps xmm0, [rsp]
00007e4ecaddcdf2  vmovaps xmm1, [rsp+0x10]
00007e4ecaddcdf8  vmovaps xmm2, [rsp+0x20]
00007e4ecaddcdfe  vmovaps xmm3, [rsp+0x30]
00007e4ecaddce04  vmovaps xmm4, [rsp+0x40]
00007e4ecaddce0a  vmovaps xmm5, [rsp+0x50]
00007e4ecaddce10  vmovaps xmm6, [rsp+0x60]
00007e4ecaddce16  vmovaps xmm7, [rsp+0x70]
00007e4ecaddce1c  vmovaps xmm8, [rsp+0x80]
00007e4ecaddce25  vmovaps xmm9, [rsp+0x90]
00007e4ecaddce2e  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddce37  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddce40  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddce49  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddce52  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddce5b  add rsp, 0xF0
00007e4ecaddce62  pop r11
00007e4ecaddce64  pop r10
00007e4ecaddce66  pop r9
00007e4ecaddce68  pop r8
00007e4ecaddce6a  pop rsi
00007e4ecaddce6b  pop rdi
00007e4ecaddce6c  pop rdx
00007e4ecaddce6d  pop rcx
00007e4ecaddce6e  pop rax
00007e4ecaddce6f  add rsp, 0x08
00007e4ecaddce73  jmp 0x00007E4ECADDBBB3
00007e4ecaddce78  sub rsp, 0x08
00007e4ecaddce7c  push rax
00007e4ecaddce7d  push rcx
00007e4ecaddce7e  push rdx
00007e4ecaddce7f  push rdi
00007e4ecaddce80  push rsi
00007e4ecaddce81  push r8
00007e4ecaddce83  push r9
00007e4ecaddce85  push r10
00007e4ecaddce87  push r11
00007e4ecaddce89  sub rsp, 0xF0
00007e4ecaddce90  vmovaps [rsp], xmm0
00007e4ecaddce95  vmovaps [rsp+0x10], xmm1
00007e4ecaddce9b  vmovaps [rsp+0x20], xmm2
00007e4ecaddcea1  vmovaps [rsp+0x30], xmm3
00007e4ecaddcea7  vmovaps [rsp+0x40], xmm4
00007e4ecaddcead  vmovaps [rsp+0x50], xmm5
00007e4ecaddceb3  vmovaps [rsp+0x60], xmm7
00007e4ecaddceb9  vmovaps [rsp+0x70], xmm8
00007e4ecaddcebf  vmovaps [rsp+0x80], xmm9
00007e4ecaddcec8  vmovaps [rsp+0x90], xmm10
00007e4ecaddced1  vmovaps [rsp+0xA0], xmm11
00007e4ecaddceda  vmovaps [rsp+0xB0], xmm12
00007e4ecaddcee3  vmovaps [rsp+0xC0], xmm13
00007e4ecaddceec  vmovaps [rsp+0xD0], xmm14
00007e4ecaddcef5  vmovaps [rsp+0xE0], xmm15
00007e4ecaddcefe  sub rsp, 0x30
00007e4ecaddcf02  movaps [rsp], xmm6
00007e4ecaddcf06  movaps [rsp+0x10], xmm12
00007e4ecaddcf0c  movaps [rsp+0x20], xmm11
00007e4ecaddcf12  lea rdi, [rsp]
00007e4ecaddcf16  mov esi, 0x00
00007e4ecaddcf1b  mov rax, 0x5784BC1F5530
00007e4ecaddcf25  call rax
00007e4ecaddcf27  movaps xmm6, [rsp]
00007e4ecaddcf2b  add rsp, 0x30
00007e4ecaddcf2f  vmovaps xmm0, [rsp]
00007e4ecaddcf34  vmovaps xmm1, [rsp+0x10]
00007e4ecaddcf3a  vmovaps xmm2, [rsp+0x20]
00007e4ecaddcf40  vmovaps xmm3, [rsp+0x30]
00007e4ecaddcf46  vmovaps xmm4, [rsp+0x40]
00007e4ecaddcf4c  vmovaps xmm5, [rsp+0x50]
00007e4ecaddcf52  vmovaps xmm7, [rsp+0x60]
00007e4ecaddcf58  vmovaps xmm8, [rsp+0x70]
00007e4ecaddcf5e  vmovaps xmm9, [rsp+0x80]
00007e4ecaddcf67  vmovaps xmm10, [rsp+0x90]
00007e4ecaddcf70  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddcf79  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddcf82  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddcf8b  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddcf94  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddcf9d  add rsp, 0xF0
00007e4ecaddcfa4  pop r11
00007e4ecaddcfa6  pop r10
00007e4ecaddcfa8  pop r9
00007e4ecaddcfaa  pop r8
00007e4ecaddcfac  pop rsi
00007e4ecaddcfad  pop rdi
00007e4ecaddcfae  pop rdx
00007e4ecaddcfaf  pop rcx
00007e4ecaddcfb0  pop rax
00007e4ecaddcfb1  add rsp, 0x08
00007e4ecaddcfb5  jmp 0x00007E4ECADDBBD4
00007e4ecaddcfba  sub rsp, 0x08
00007e4ecaddcfbe  push rax
00007e4ecaddcfbf  push rcx
00007e4ecaddcfc0  push rdx
00007e4ecaddcfc1  push rdi
00007e4ecaddcfc2  push rsi
00007e4ecaddcfc3  push r8
00007e4ecaddcfc5  push r9
00007e4ecaddcfc7  push r10
00007e4ecaddcfc9  push r11
00007e4ecaddcfcb  sub rsp, 0xF0
00007e4ecaddcfd2  vmovaps [rsp], xmm0
00007e4ecaddcfd7  vmovaps [rsp+0x10], xmm1
00007e4ecaddcfdd  vmovaps [rsp+0x20], xmm2
00007e4ecaddcfe3  vmovaps [rsp+0x30], xmm4
00007e4ecaddcfe9  vmovaps [rsp+0x40], xmm5
00007e4ecaddcfef  vmovaps [rsp+0x50], xmm6
00007e4ecaddcff5  vmovaps [rsp+0x60], xmm7
00007e4ecaddcffb  vmovaps [rsp+0x70], xmm8
00007e4ecaddd001  vmovaps [rsp+0x80], xmm9
00007e4ecaddd00a  vmovaps [rsp+0x90], xmm10
00007e4ecaddd013  vmovaps [rsp+0xA0], xmm11
00007e4ecaddd01c  vmovaps [rsp+0xB0], xmm12
00007e4ecaddd025  vmovaps [rsp+0xC0], xmm13
00007e4ecaddd02e  vmovaps [rsp+0xD0], xmm14
00007e4ecaddd037  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd040  sub rsp, 0x30
00007e4ecaddd044  movaps [rsp], xmm3
00007e4ecaddd048  movaps [rsp+0x10], xmm5
00007e4ecaddd04d  movaps [rsp+0x20], xmm4
00007e4ecaddd052  lea rdi, [rsp]
00007e4ecaddd056  mov esi, 0x00
00007e4ecaddd05b  mov rax, 0x5784BC1F5530
00007e4ecaddd065  call rax
00007e4ecaddd067  movaps xmm3, [rsp]
00007e4ecaddd06b  add rsp, 0x30
00007e4ecaddd06f  vmovaps xmm0, [rsp]
00007e4ecaddd074  vmovaps xmm1, [rsp+0x10]
00007e4ecaddd07a  vmovaps xmm2, [rsp+0x20]
00007e4ecaddd080  vmovaps xmm4, [rsp+0x30]
00007e4ecaddd086  vmovaps xmm5, [rsp+0x40]
00007e4ecaddd08c  vmovaps xmm6, [rsp+0x50]
00007e4ecaddd092  vmovaps xmm7, [rsp+0x60]
00007e4ecaddd098  vmovaps xmm8, [rsp+0x70]
00007e4ecaddd09e  vmovaps xmm9, [rsp+0x80]
00007e4ecaddd0a7  vmovaps xmm10, [rsp+0x90]
00007e4ecaddd0b0  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddd0b9  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddd0c2  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddd0cb  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddd0d4  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd0dd  add rsp, 0xF0
00007e4ecaddd0e4  pop r11
00007e4ecaddd0e6  pop r10
00007e4ecaddd0e8  pop r9
00007e4ecaddd0ea  pop r8
00007e4ecaddd0ec  pop rsi
00007e4ecaddd0ed  pop rdi
00007e4ecaddd0ee  pop rdx
00007e4ecaddd0ef  pop rcx
00007e4ecaddd0f0  pop rax
00007e4ecaddd0f1  add rsp, 0x08
00007e4ecaddd0f5  jmp 0x00007E4ECADDBC35
00007e4ecaddd0fa  sub rsp, 0x08
00007e4ecaddd0fe  push rax
00007e4ecaddd0ff  push rcx
00007e4ecaddd100  push rdx
00007e4ecaddd101  push rdi
00007e4ecaddd102  push rsi
00007e4ecaddd103  push r8
00007e4ecaddd105  push r9
00007e4ecaddd107  push r10
00007e4ecaddd109  push r11
00007e4ecaddd10b  sub rsp, 0xF0
00007e4ecaddd112  vmovaps [rsp], xmm0
00007e4ecaddd117  vmovaps [rsp+0x10], xmm1
00007e4ecaddd11d  vmovaps [rsp+0x20], xmm2
00007e4ecaddd123  vmovaps [rsp+0x30], xmm3
00007e4ecaddd129  vmovaps [rsp+0x40], xmm4
00007e4ecaddd12f  vmovaps [rsp+0x50], xmm6
00007e4ecaddd135  vmovaps [rsp+0x60], xmm7
00007e4ecaddd13b  vmovaps [rsp+0x70], xmm8
00007e4ecaddd141  vmovaps [rsp+0x80], xmm9
00007e4ecaddd14a  vmovaps [rsp+0x90], xmm10
00007e4ecaddd153  vmovaps [rsp+0xA0], xmm11
00007e4ecaddd15c  vmovaps [rsp+0xB0], xmm12
00007e4ecaddd165  vmovaps [rsp+0xC0], xmm13
00007e4ecaddd16e  vmovaps [rsp+0xD0], xmm14
00007e4ecaddd177  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd180  sub rsp, 0x30
00007e4ecaddd184  movaps [rsp], xmm5
00007e4ecaddd188  movaps [rsp+0x10], xmm8
00007e4ecaddd18e  movaps [rsp+0x20], xmm15
00007e4ecaddd194  lea rdi, [rsp]
00007e4ecaddd198  mov esi, 0x00
00007e4ecaddd19d  mov rax, 0x5784BC1F5530
00007e4ecaddd1a7  call rax
00007e4ecaddd1a9  movaps xmm5, [rsp]
00007e4ecaddd1ad  add rsp, 0x30
00007e4ecaddd1b1  vmovaps xmm0, [rsp]
00007e4ecaddd1b6  vmovaps xmm1, [rsp+0x10]
00007e4ecaddd1bc  vmovaps xmm2, [rsp+0x20]
00007e4ecaddd1c2  vmovaps xmm3, [rsp+0x30]
00007e4ecaddd1c8  vmovaps xmm4, [rsp+0x40]
00007e4ecaddd1ce  vmovaps xmm6, [rsp+0x50]
00007e4ecaddd1d4  vmovaps xmm7, [rsp+0x60]
00007e4ecaddd1da  vmovaps xmm8, [rsp+0x70]
00007e4ecaddd1e0  vmovaps xmm9, [rsp+0x80]
00007e4ecaddd1e9  vmovaps xmm10, [rsp+0x90]
00007e4ecaddd1f2  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddd1fb  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddd204  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddd20d  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddd216  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd21f  add rsp, 0xF0
00007e4ecaddd226  pop r11
00007e4ecaddd228  pop r10
00007e4ecaddd22a  pop r9
00007e4ecaddd22c  pop r8
00007e4ecaddd22e  pop rsi
00007e4ecaddd22f  pop rdi
00007e4ecaddd230  pop rdx
00007e4ecaddd231  pop rcx
00007e4ecaddd232  pop rax
00007e4ecaddd233  add rsp, 0x08
00007e4ecaddd237  jmp 0x00007E4ECADDBC73
00007e4ecaddd23c  sub rsp, 0x08
00007e4ecaddd240  push rax
00007e4ecaddd241  push rcx
00007e4ecaddd242  push rdx
00007e4ecaddd243  push rdi
00007e4ecaddd244  push rsi
00007e4ecaddd245  push r8
00007e4ecaddd247  push r9
00007e4ecaddd249  push r10
00007e4ecaddd24b  push r11
00007e4ecaddd24d  sub rsp, 0xF0
00007e4ecaddd254  vmovaps [rsp], xmm0
00007e4ecaddd259  vmovaps [rsp+0x10], xmm1
00007e4ecaddd25f  vmovaps [rsp+0x20], xmm2
00007e4ecaddd265  vmovaps [rsp+0x30], xmm3
00007e4ecaddd26b  vmovaps [rsp+0x40], xmm5
00007e4ecaddd271  vmovaps [rsp+0x50], xmm6
00007e4ecaddd277  vmovaps [rsp+0x60], xmm7
00007e4ecaddd27d  vmovaps [rsp+0x70], xmm8
00007e4ecaddd283  vmovaps [rsp+0x80], xmm9
00007e4ecaddd28c  vmovaps [rsp+0x90], xmm10
00007e4ecaddd295  vmovaps [rsp+0xA0], xmm11
00007e4ecaddd29e  vmovaps [rsp+0xB0], xmm12
00007e4ecaddd2a7  vmovaps [rsp+0xC0], xmm13
00007e4ecaddd2b0  vmovaps [rsp+0xD0], xmm14
00007e4ecaddd2b9  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd2c2  sub rsp, 0x30
00007e4ecaddd2c6  movaps [rsp], xmm4
00007e4ecaddd2ca  movaps [rsp+0x10], xmm9
00007e4ecaddd2d0  movaps [rsp+0x20], xmm8
00007e4ecaddd2d6  lea rdi, [rsp]
00007e4ecaddd2da  mov esi, 0x00
00007e4ecaddd2df  mov rax, 0x5784BC1F5530
00007e4ecaddd2e9  call rax
00007e4ecaddd2eb  movaps xmm4, [rsp]
00007e4ecaddd2ef  add rsp, 0x30
00007e4ecaddd2f3  vmovaps xmm0, [rsp]
00007e4ecaddd2f8  vmovaps xmm1, [rsp+0x10]
00007e4ecaddd2fe  vmovaps xmm2, [rsp+0x20]
00007e4ecaddd304  vmovaps xmm3, [rsp+0x30]
00007e4ecaddd30a  vmovaps xmm5, [rsp+0x40]
00007e4ecaddd310  vmovaps xmm6, [rsp+0x50]
00007e4ecaddd316  vmovaps xmm7, [rsp+0x60]
00007e4ecaddd31c  vmovaps xmm8, [rsp+0x70]
00007e4ecaddd322  vmovaps xmm9, [rsp+0x80]
00007e4ecaddd32b  vmovaps xmm10, [rsp+0x90]
00007e4ecaddd334  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddd33d  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddd346  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddd34f  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddd358  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd361  add rsp, 0xF0
00007e4ecaddd368  pop r11
00007e4ecaddd36a  pop r10
00007e4ecaddd36c  pop r9
00007e4ecaddd36e  pop r8
00007e4ecaddd370  pop rsi
00007e4ecaddd371  pop rdi
00007e4ecaddd372  pop rdx
00007e4ecaddd373  pop rcx
00007e4ecaddd374  pop rax
00007e4ecaddd375  add rsp, 0x08
00007e4ecaddd379  jmp 0x00007E4ECADDBC94
00007e4ecaddd37e  sub rsp, 0x08
00007e4ecaddd382  push rax
00007e4ecaddd383  push rcx
00007e4ecaddd384  push rdx
00007e4ecaddd385  push rdi
00007e4ecaddd386  push rsi
00007e4ecaddd387  push r8
00007e4ecaddd389  push r9
00007e4ecaddd38b  push r10
00007e4ecaddd38d  push r11
00007e4ecaddd38f  sub rsp, 0xF0
00007e4ecaddd396  vmovaps [rsp], xmm0
00007e4ecaddd39b  vmovaps [rsp+0x10], xmm1
00007e4ecaddd3a1  vmovaps [rsp+0x20], xmm2
00007e4ecaddd3a7  vmovaps [rsp+0x30], xmm3
00007e4ecaddd3ad  vmovaps [rsp+0x40], xmm4
00007e4ecaddd3b3  vmovaps [rsp+0x50], xmm5
00007e4ecaddd3b9  vmovaps [rsp+0x60], xmm6
00007e4ecaddd3bf  vmovaps [rsp+0x70], xmm7
00007e4ecaddd3c5  vmovaps [rsp+0x80], xmm8
00007e4ecaddd3ce  vmovaps [rsp+0x90], xmm10
00007e4ecaddd3d7  vmovaps [rsp+0xA0], xmm11
00007e4ecaddd3e0  vmovaps [rsp+0xB0], xmm12
00007e4ecaddd3e9  vmovaps [rsp+0xC0], xmm13
00007e4ecaddd3f2  vmovaps [rsp+0xD0], xmm14
00007e4ecaddd3fb  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd404  sub rsp, 0x30
00007e4ecaddd408  movaps [rsp], xmm9
00007e4ecaddd40d  movaps [rsp+0x10], xmm10
00007e4ecaddd413  movaps [rsp+0x20], xmm8
00007e4ecaddd419  lea rdi, [rsp]
00007e4ecaddd41d  mov esi, 0x00
00007e4ecaddd422  mov rax, 0x5784BC1F5530
00007e4ecaddd42c  call rax
00007e4ecaddd42e  movaps xmm9, [rsp]
00007e4ecaddd433  add rsp, 0x30
00007e4ecaddd437  vmovaps xmm0, [rsp]
00007e4ecaddd43c  vmovaps xmm1, [rsp+0x10]
00007e4ecaddd442  vmovaps xmm2, [rsp+0x20]
00007e4ecaddd448  vmovaps xmm3, [rsp+0x30]
00007e4ecaddd44e  vmovaps xmm4, [rsp+0x40]
00007e4ecaddd454  vmovaps xmm5, [rsp+0x50]
00007e4ecaddd45a  vmovaps xmm6, [rsp+0x60]
00007e4ecaddd460  vmovaps xmm7, [rsp+0x70]
00007e4ecaddd466  vmovaps xmm8, [rsp+0x80]
00007e4ecaddd46f  vmovaps xmm10, [rsp+0x90]
00007e4ecaddd478  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddd481  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddd48a  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddd493  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddd49c  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd4a5  add rsp, 0xF0
00007e4ecaddd4ac  pop r11
00007e4ecaddd4ae  pop r10
00007e4ecaddd4b0  pop r9
00007e4ecaddd4b2  pop r8
00007e4ecaddd4b4  pop rsi
00007e4ecaddd4b5  pop rdi
00007e4ecaddd4b6  pop rdx
00007e4ecaddd4b7  pop rcx
00007e4ecaddd4b8  pop rax
00007e4ecaddd4b9  add rsp, 0x08
00007e4ecaddd4bd  jmp 0x00007E4ECADDBCAE
00007e4ecaddd4c2  call 0x00007E4ECACB52F0
00007e4ecaddd4c7  jmp 0x00007E4ECADDBDC8
00007e4ecaddd4cc  call 0x00007E4ECACB52F0
00007e4ecaddd4d1  jmp 0x00007E4ECADDBDDE
00007e4ecaddd4d6  sub rsp, 0x08
00007e4ecaddd4da  push rax
00007e4ecaddd4db  push rcx
00007e4ecaddd4dc  push rdx
00007e4ecaddd4dd  push rdi
00007e4ecaddd4de  push rsi
00007e4ecaddd4df  push r8
00007e4ecaddd4e1  push r9
00007e4ecaddd4e3  push r10
00007e4ecaddd4e5  push r11
00007e4ecaddd4e7  sub rsp, 0xF0
00007e4ecaddd4ee  vmovaps [rsp], xmm0
00007e4ecaddd4f3  vmovaps [rsp+0x10], xmm2
00007e4ecaddd4f9  vmovaps [rsp+0x20], xmm3
00007e4ecaddd4ff  vmovaps [rsp+0x30], xmm4
00007e4ecaddd505  vmovaps [rsp+0x40], xmm5
00007e4ecaddd50b  vmovaps [rsp+0x50], xmm6
00007e4ecaddd511  vmovaps [rsp+0x60], xmm7
00007e4ecaddd517  vmovaps [rsp+0x70], xmm8
00007e4ecaddd51d  vmovaps [rsp+0x80], xmm9
00007e4ecaddd526  vmovaps [rsp+0x90], xmm10
00007e4ecaddd52f  vmovaps [rsp+0xA0], xmm11
00007e4ecaddd538  vmovaps [rsp+0xB0], xmm12
00007e4ecaddd541  vmovaps [rsp+0xC0], xmm13
00007e4ecaddd54a  vmovaps [rsp+0xD0], xmm14
00007e4ecaddd553  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd55c  sub rsp, 0x30
00007e4ecaddd560  movaps [rsp], xmm1
00007e4ecaddd564  movaps [rsp+0x10], xmm6
00007e4ecaddd569  movaps [rsp+0x20], xmm15
00007e4ecaddd56f  lea rdi, [rsp]
00007e4ecaddd573  mov esi, 0x00
00007e4ecaddd578  mov rax, 0x5784BC1F5530
00007e4ecaddd582  call rax
00007e4ecaddd584  movaps xmm1, [rsp]
00007e4ecaddd588  add rsp, 0x30
00007e4ecaddd58c  vmovaps xmm0, [rsp]
00007e4ecaddd591  vmovaps xmm2, [rsp+0x10]
00007e4ecaddd597  vmovaps xmm3, [rsp+0x20]
00007e4ecaddd59d  vmovaps xmm4, [rsp+0x30]
00007e4ecaddd5a3  vmovaps xmm5, [rsp+0x40]
00007e4ecaddd5a9  vmovaps xmm6, [rsp+0x50]
00007e4ecaddd5af  vmovaps xmm7, [rsp+0x60]
00007e4ecaddd5b5  vmovaps xmm8, [rsp+0x70]
00007e4ecaddd5bb  vmovaps xmm9, [rsp+0x80]
00007e4ecaddd5c4  vmovaps xmm10, [rsp+0x90]
00007e4ecaddd5cd  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddd5d6  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddd5df  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddd5e8  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddd5f1  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd5fa  add rsp, 0xF0
00007e4ecaddd601  pop r11
00007e4ecaddd603  pop r10
00007e4ecaddd605  pop r9
00007e4ecaddd607  pop r8
00007e4ecaddd609  pop rsi
00007e4ecaddd60a  pop rdi
00007e4ecaddd60b  pop rdx
00007e4ecaddd60c  pop rcx
00007e4ecaddd60d  pop rax
00007e4ecaddd60e  add rsp, 0x08
00007e4ecaddd612  jmp 0x00007E4ECADDBE1B
00007e4ecaddd617  call 0x00007E4ECACC4620
00007e4ecaddd61c  jmp 0x00007E4ECADDBE28
00007e4ecaddd621  sub rsp, 0x08
00007e4ecaddd625  push rax
00007e4ecaddd626  push rcx
00007e4ecaddd627  push rdx
00007e4ecaddd628  push rdi
00007e4ecaddd629  push rsi
00007e4ecaddd62a  push r8
00007e4ecaddd62c  push r9
00007e4ecaddd62e  push r10
00007e4ecaddd630  push r11
00007e4ecaddd632  sub rsp, 0xF0
00007e4ecaddd639  vmovaps [rsp], xmm0
00007e4ecaddd63e  vmovaps [rsp+0x10], xmm1
00007e4ecaddd644  vmovaps [rsp+0x20], xmm2
00007e4ecaddd64a  vmovaps [rsp+0x30], xmm3
00007e4ecaddd650  vmovaps [rsp+0x40], xmm4
00007e4ecaddd656  vmovaps [rsp+0x50], xmm5
00007e4ecaddd65c  vmovaps [rsp+0x60], xmm6
00007e4ecaddd662  vmovaps [rsp+0x70], xmm7
00007e4ecaddd668  vmovaps [rsp+0x80], xmm8
00007e4ecaddd671  vmovaps [rsp+0x90], xmm9
00007e4ecaddd67a  vmovaps [rsp+0xA0], xmm10
00007e4ecaddd683  vmovaps [rsp+0xB0], xmm11
00007e4ecaddd68c  vmovaps [rsp+0xC0], xmm12
00007e4ecaddd695  vmovaps [rsp+0xD0], xmm13
00007e4ecaddd69e  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd6a7  sub rsp, 0x30
00007e4ecaddd6ab  movaps [rsp], xmm14
00007e4ecaddd6b0  movaps [rsp+0x10], xmm4
00007e4ecaddd6b5  movaps [rsp+0x20], xmm3
00007e4ecaddd6ba  lea rdi, [rsp]
00007e4ecaddd6be  mov esi, 0x00
00007e4ecaddd6c3  mov rax, 0x5784BC1F5530
00007e4ecaddd6cd  call rax
00007e4ecaddd6cf  movaps xmm14, [rsp]
00007e4ecaddd6d4  add rsp, 0x30
00007e4ecaddd6d8  vmovaps xmm0, [rsp]
00007e4ecaddd6dd  vmovaps xmm1, [rsp+0x10]
00007e4ecaddd6e3  vmovaps xmm2, [rsp+0x20]
00007e4ecaddd6e9  vmovaps xmm3, [rsp+0x30]
00007e4ecaddd6ef  vmovaps xmm4, [rsp+0x40]
00007e4ecaddd6f5  vmovaps xmm5, [rsp+0x50]
00007e4ecaddd6fb  vmovaps xmm6, [rsp+0x60]
00007e4ecaddd701  vmovaps xmm7, [rsp+0x70]
00007e4ecaddd707  vmovaps xmm8, [rsp+0x80]
00007e4ecaddd710  vmovaps xmm9, [rsp+0x90]
00007e4ecaddd719  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddd722  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddd72b  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddd734  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddd73d  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd746  add rsp, 0xF0
00007e4ecaddd74d  pop r11
00007e4ecaddd74f  pop r10
00007e4ecaddd751  pop r9
00007e4ecaddd753  pop r8
00007e4ecaddd755  pop rsi
00007e4ecaddd756  pop rdi
00007e4ecaddd757  pop rdx
00007e4ecaddd758  pop rcx
00007e4ecaddd759  pop rax
00007e4ecaddd75a  add rsp, 0x08
00007e4ecaddd75e  jmp 0x00007E4ECADDBE42
00007e4ecaddd763  sub rsp, 0x08
00007e4ecaddd767  push rax
00007e4ecaddd768  push rcx
00007e4ecaddd769  push rdx
00007e4ecaddd76a  push rdi
00007e4ecaddd76b  push rsi
00007e4ecaddd76c  push r8
00007e4ecaddd76e  push r9
00007e4ecaddd770  push r10
00007e4ecaddd772  push r11
00007e4ecaddd774  sub rsp, 0xF0
00007e4ecaddd77b  vmovaps [rsp], xmm0
00007e4ecaddd780  vmovaps [rsp+0x10], xmm1
00007e4ecaddd786  vmovaps [rsp+0x20], xmm2
00007e4ecaddd78c  vmovaps [rsp+0x30], xmm3
00007e4ecaddd792  vmovaps [rsp+0x40], xmm4
00007e4ecaddd798  vmovaps [rsp+0x50], xmm5
00007e4ecaddd79e  vmovaps [rsp+0x60], xmm7
00007e4ecaddd7a4  vmovaps [rsp+0x70], xmm8
00007e4ecaddd7aa  vmovaps [rsp+0x80], xmm9
00007e4ecaddd7b3  vmovaps [rsp+0x90], xmm10
00007e4ecaddd7bc  vmovaps [rsp+0xA0], xmm11
00007e4ecaddd7c5  vmovaps [rsp+0xB0], xmm12
00007e4ecaddd7ce  vmovaps [rsp+0xC0], xmm13
00007e4ecaddd7d7  vmovaps [rsp+0xD0], xmm14
00007e4ecaddd7e0  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd7e9  sub rsp, 0x30
00007e4ecaddd7ed  movaps [rsp], xmm6
00007e4ecaddd7f1  movaps [rsp+0x10], xmm9
00007e4ecaddd7f7  movaps [rsp+0x20], xmm7
00007e4ecaddd7fc  lea rdi, [rsp]
00007e4ecaddd800  mov esi, 0x00
00007e4ecaddd805  mov rax, 0x5784BC1F5530
00007e4ecaddd80f  call rax
00007e4ecaddd811  movaps xmm6, [rsp]
00007e4ecaddd815  add rsp, 0x30
00007e4ecaddd819  vmovaps xmm0, [rsp]
00007e4ecaddd81e  vmovaps xmm1, [rsp+0x10]
00007e4ecaddd824  vmovaps xmm2, [rsp+0x20]
00007e4ecaddd82a  vmovaps xmm3, [rsp+0x30]
00007e4ecaddd830  vmovaps xmm4, [rsp+0x40]
00007e4ecaddd836  vmovaps xmm5, [rsp+0x50]
00007e4ecaddd83c  vmovaps xmm7, [rsp+0x60]
00007e4ecaddd842  vmovaps xmm8, [rsp+0x70]
00007e4ecaddd848  vmovaps xmm9, [rsp+0x80]
00007e4ecaddd851  vmovaps xmm10, [rsp+0x90]
00007e4ecaddd85a  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddd863  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddd86c  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddd875  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddd87e  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd887  add rsp, 0xF0
00007e4ecaddd88e  pop r11
00007e4ecaddd890  pop r10
00007e4ecaddd892  pop r9
00007e4ecaddd894  pop r8
00007e4ecaddd896  pop rsi
00007e4ecaddd897  pop rdi
00007e4ecaddd898  pop rdx
00007e4ecaddd899  pop rcx
00007e4ecaddd89a  pop rax
00007e4ecaddd89b  add rsp, 0x08
00007e4ecaddd89f  jmp 0x00007E4ECADDBE5A
00007e4ecaddd8a4  sub rsp, 0x08
00007e4ecaddd8a8  push rax
00007e4ecaddd8a9  push rcx
00007e4ecaddd8aa  push rdx
00007e4ecaddd8ab  push rdi
00007e4ecaddd8ac  push rsi
00007e4ecaddd8ad  push r8
00007e4ecaddd8af  push r9
00007e4ecaddd8b1  push r10
00007e4ecaddd8b3  push r11
00007e4ecaddd8b5  sub rsp, 0xF0
00007e4ecaddd8bc  vmovaps [rsp], xmm0
00007e4ecaddd8c1  vmovaps [rsp+0x10], xmm1
00007e4ecaddd8c7  vmovaps [rsp+0x20], xmm2
00007e4ecaddd8cd  vmovaps [rsp+0x30], xmm3
00007e4ecaddd8d3  vmovaps [rsp+0x40], xmm4
00007e4ecaddd8d9  vmovaps [rsp+0x50], xmm5
00007e4ecaddd8df  vmovaps [rsp+0x60], xmm6
00007e4ecaddd8e5  vmovaps [rsp+0x70], xmm8
00007e4ecaddd8eb  vmovaps [rsp+0x80], xmm9
00007e4ecaddd8f4  vmovaps [rsp+0x90], xmm10
00007e4ecaddd8fd  vmovaps [rsp+0xA0], xmm11
00007e4ecaddd906  vmovaps [rsp+0xB0], xmm12
00007e4ecaddd90f  vmovaps [rsp+0xC0], xmm13
00007e4ecaddd918  vmovaps [rsp+0xD0], xmm14
00007e4ecaddd921  vmovaps [rsp+0xE0], xmm15
00007e4ecaddd92a  sub rsp, 0x30
00007e4ecaddd92e  movaps [rsp], xmm7
00007e4ecaddd932  movaps [rsp+0x10], xmm4
00007e4ecaddd937  movaps [rsp+0x20], xmm9
00007e4ecaddd93d  lea rdi, [rsp]
00007e4ecaddd941  mov esi, 0x00
00007e4ecaddd946  mov rax, 0x5784BC1F5530
00007e4ecaddd950  call rax
00007e4ecaddd952  movaps xmm7, [rsp]
00007e4ecaddd956  add rsp, 0x30
00007e4ecaddd95a  vmovaps xmm0, [rsp]
00007e4ecaddd95f  vmovaps xmm1, [rsp+0x10]
00007e4ecaddd965  vmovaps xmm2, [rsp+0x20]
00007e4ecaddd96b  vmovaps xmm3, [rsp+0x30]
00007e4ecaddd971  vmovaps xmm4, [rsp+0x40]
00007e4ecaddd977  vmovaps xmm5, [rsp+0x50]
00007e4ecaddd97d  vmovaps xmm6, [rsp+0x60]
00007e4ecaddd983  vmovaps xmm8, [rsp+0x70]
00007e4ecaddd989  vmovaps xmm9, [rsp+0x80]
00007e4ecaddd992  vmovaps xmm10, [rsp+0x90]
00007e4ecaddd99b  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddd9a4  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddd9ad  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddd9b6  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddd9bf  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddd9c8  add rsp, 0xF0
00007e4ecaddd9cf  pop r11
00007e4ecaddd9d1  pop r10
00007e4ecaddd9d3  pop r9
00007e4ecaddd9d5  pop r8
00007e4ecaddd9d7  pop rsi
00007e4ecaddd9d8  pop rdi
00007e4ecaddd9d9  pop rdx
00007e4ecaddd9da  pop rcx
00007e4ecaddd9db  pop rax
00007e4ecaddd9dc  add rsp, 0x08
00007e4ecaddd9e0  jmp 0x00007E4ECADDBE87
00007e4ecaddd9e5  sub rsp, 0x08
00007e4ecaddd9e9  push rax
00007e4ecaddd9ea  push rcx
00007e4ecaddd9eb  push rdx
00007e4ecaddd9ec  push rdi
00007e4ecaddd9ed  push rsi
00007e4ecaddd9ee  push r8
00007e4ecaddd9f0  push r9
00007e4ecaddd9f2  push r10
00007e4ecaddd9f4  push r11
00007e4ecaddd9f6  sub rsp, 0xF0
00007e4ecaddd9fd  vmovaps [rsp], xmm0
00007e4ecaddda02  vmovaps [rsp+0x10], xmm1
00007e4ecaddda08  vmovaps [rsp+0x20], xmm2
00007e4ecaddda0e  vmovaps [rsp+0x30], xmm3
00007e4ecaddda14  vmovaps [rsp+0x40], xmm5
00007e4ecaddda1a  vmovaps [rsp+0x50], xmm6
00007e4ecaddda20  vmovaps [rsp+0x60], xmm7
00007e4ecaddda26  vmovaps [rsp+0x70], xmm8
00007e4ecaddda2c  vmovaps [rsp+0x80], xmm9
00007e4ecaddda35  vmovaps [rsp+0x90], xmm10
00007e4ecaddda3e  vmovaps [rsp+0xA0], xmm11
00007e4ecaddda47  vmovaps [rsp+0xB0], xmm12
00007e4ecaddda50  vmovaps [rsp+0xC0], xmm13
00007e4ecaddda59  vmovaps [rsp+0xD0], xmm14
00007e4ecaddda62  vmovaps [rsp+0xE0], xmm15
00007e4ecaddda6b  sub rsp, 0x30
00007e4ecaddda6f  movaps [rsp], xmm4
00007e4ecaddda73  movaps [rsp+0x10], xmm15
00007e4ecaddda79  movaps [rsp+0x20], xmm9
00007e4ecaddda7f  lea rdi, [rsp]
00007e4ecaddda83  mov esi, 0x00
00007e4ecaddda88  mov rax, 0x5784BC1F5530
00007e4ecaddda92  call rax
00007e4ecaddda94  movaps xmm4, [rsp]
00007e4ecaddda98  add rsp, 0x30
00007e4ecaddda9c  vmovaps xmm0, [rsp]
00007e4ecadddaa1  vmovaps xmm1, [rsp+0x10]
00007e4ecadddaa7  vmovaps xmm2, [rsp+0x20]
00007e4ecadddaad  vmovaps xmm3, [rsp+0x30]
00007e4ecadddab3  vmovaps xmm5, [rsp+0x40]
00007e4ecadddab9  vmovaps xmm6, [rsp+0x50]
00007e4ecadddabf  vmovaps xmm7, [rsp+0x60]
00007e4ecadddac5  vmovaps xmm8, [rsp+0x70]
00007e4ecadddacb  vmovaps xmm9, [rsp+0x80]
00007e4ecadddad4  vmovaps xmm10, [rsp+0x90]
00007e4ecadddadd  vmovaps xmm11, [rsp+0xA0]
00007e4ecadddae6  vmovaps xmm12, [rsp+0xB0]
00007e4ecadddaef  vmovaps xmm13, [rsp+0xC0]
00007e4ecadddaf8  vmovaps xmm14, [rsp+0xD0]
00007e4ecadddb01  vmovaps xmm15, [rsp+0xE0]
00007e4ecadddb0a  add rsp, 0xF0
00007e4ecadddb11  pop r11
00007e4ecadddb13  pop r10
00007e4ecadddb15  pop r9
00007e4ecadddb17  pop r8
00007e4ecadddb19  pop rsi
00007e4ecadddb1a  pop rdi
00007e4ecadddb1b  pop rdx
00007e4ecadddb1c  pop rcx
00007e4ecadddb1d  pop rax
00007e4ecadddb1e  add rsp, 0x08
00007e4ecadddb22  jmp 0x00007E4ECADDBEAC
00007e4ecadddb27  call 0x00007E4ECACC4620
00007e4ecadddb2c  jmp 0x00007E4ECADDBEB9
00007e4ecadddb31  sub rsp, 0x08
00007e4ecadddb35  push rax
00007e4ecadddb36  push rcx
00007e4ecadddb37  push rdx
00007e4ecadddb38  push rdi
00007e4ecadddb39  push rsi
00007e4ecadddb3a  push r8
00007e4ecadddb3c  push r9
00007e4ecadddb3e  push r10
00007e4ecadddb40  push r11
00007e4ecadddb42  sub rsp, 0xF0
00007e4ecadddb49  vmovaps [rsp], xmm0
00007e4ecadddb4e  vmovaps [rsp+0x10], xmm1
00007e4ecadddb54  vmovaps [rsp+0x20], xmm2
00007e4ecadddb5a  vmovaps [rsp+0x30], xmm4
00007e4ecadddb60  vmovaps [rsp+0x40], xmm5
00007e4ecadddb66  vmovaps [rsp+0x50], xmm6
00007e4ecadddb6c  vmovaps [rsp+0x60], xmm7
00007e4ecadddb72  vmovaps [rsp+0x70], xmm8
00007e4ecadddb78  vmovaps [rsp+0x80], xmm9
00007e4ecadddb81  vmovaps [rsp+0x90], xmm10
00007e4ecadddb8a  vmovaps [rsp+0xA0], xmm11
00007e4ecadddb93  vmovaps [rsp+0xB0], xmm12
00007e4ecadddb9c  vmovaps [rsp+0xC0], xmm13
00007e4ecadddba5  vmovaps [rsp+0xD0], xmm14
00007e4ecadddbae  vmovaps [rsp+0xE0], xmm15
00007e4ecadddbb7  sub rsp, 0x30
00007e4ecadddbbb  movaps [rsp], xmm3
00007e4ecadddbbf  movaps [rsp+0x10], xmm1
00007e4ecadddbc4  movaps [rsp+0x20], xmm9
00007e4ecadddbca  lea rdi, [rsp]
00007e4ecadddbce  mov esi, 0x00
00007e4ecadddbd3  mov rax, 0x5784BC1F5530
00007e4ecadddbdd  call rax
00007e4ecadddbdf  movaps xmm3, [rsp]
00007e4ecadddbe3  add rsp, 0x30
00007e4ecadddbe7  vmovaps xmm0, [rsp]
00007e4ecadddbec  vmovaps xmm1, [rsp+0x10]
00007e4ecadddbf2  vmovaps xmm2, [rsp+0x20]
00007e4ecadddbf8  vmovaps xmm4, [rsp+0x30]
00007e4ecadddbfe  vmovaps xmm5, [rsp+0x40]
00007e4ecadddc04  vmovaps xmm6, [rsp+0x50]
00007e4ecadddc0a  vmovaps xmm7, [rsp+0x60]
00007e4ecadddc10  vmovaps xmm8, [rsp+0x70]
00007e4ecadddc16  vmovaps xmm9, [rsp+0x80]
00007e4ecadddc1f  vmovaps xmm10, [rsp+0x90]
00007e4ecadddc28  vmovaps xmm11, [rsp+0xA0]
00007e4ecadddc31  vmovaps xmm12, [rsp+0xB0]
00007e4ecadddc3a  vmovaps xmm13, [rsp+0xC0]
00007e4ecadddc43  vmovaps xmm14, [rsp+0xD0]
00007e4ecadddc4c  vmovaps xmm15, [rsp+0xE0]
00007e4ecadddc55  add rsp, 0xF0
00007e4ecadddc5c  pop r11
00007e4ecadddc5e  pop r10
00007e4ecadddc60  pop r9
00007e4ecadddc62  pop r8
00007e4ecadddc64  pop rsi
00007e4ecadddc65  pop rdi
00007e4ecadddc66  pop rdx
00007e4ecadddc67  pop rcx
00007e4ecadddc68  pop rax
00007e4ecadddc69  add rsp, 0x08
00007e4ecadddc6d  jmp 0x00007E4ECADDBEF6
00007e4ecadddc72  sub rsp, 0x08
00007e4ecadddc76  push rax
00007e4ecadddc77  push rcx
00007e4ecadddc78  push rdx
00007e4ecadddc79  push rdi
00007e4ecadddc7a  push rsi
00007e4ecadddc7b  push r8
00007e4ecadddc7d  push r9
00007e4ecadddc7f  push r10
00007e4ecadddc81  push r11
00007e4ecadddc83  sub rsp, 0xF0
00007e4ecadddc8a  vmovaps [rsp], xmm0
00007e4ecadddc8f  vmovaps [rsp+0x10], xmm2
00007e4ecadddc95  vmovaps [rsp+0x20], xmm3
00007e4ecadddc9b  vmovaps [rsp+0x30], xmm4
00007e4ecadddca1  vmovaps [rsp+0x40], xmm5
00007e4ecadddca7  vmovaps [rsp+0x50], xmm6
00007e4ecadddcad  vmovaps [rsp+0x60], xmm7
00007e4ecadddcb3  vmovaps [rsp+0x70], xmm8
00007e4ecadddcb9  vmovaps [rsp+0x80], xmm9
00007e4ecadddcc2  vmovaps [rsp+0x90], xmm10
00007e4ecadddccb  vmovaps [rsp+0xA0], xmm11
00007e4ecadddcd4  vmovaps [rsp+0xB0], xmm12
00007e4ecadddcdd  vmovaps [rsp+0xC0], xmm13
00007e4ecadddce6  vmovaps [rsp+0xD0], xmm14
00007e4ecadddcef  vmovaps [rsp+0xE0], xmm15
00007e4ecadddcf8  sub rsp, 0x30
00007e4ecadddcfc  movaps [rsp], xmm1
00007e4ecadddd00  movaps [rsp+0x10], xmm15
00007e4ecadddd06  movaps [rsp+0x20], xmm9
00007e4ecadddd0c  lea rdi, [rsp]
00007e4ecadddd10  mov esi, 0x00
00007e4ecadddd15  mov rax, 0x5784BC1F5530
00007e4ecadddd1f  call rax
00007e4ecadddd21  movaps xmm1, [rsp]
00007e4ecadddd25  add rsp, 0x30
00007e4ecadddd29  vmovaps xmm0, [rsp]
00007e4ecadddd2e  vmovaps xmm2, [rsp+0x10]
00007e4ecadddd34  vmovaps xmm3, [rsp+0x20]
00007e4ecadddd3a  vmovaps xmm4, [rsp+0x30]
00007e4ecadddd40  vmovaps xmm5, [rsp+0x40]
00007e4ecadddd46  vmovaps xmm6, [rsp+0x50]
00007e4ecadddd4c  vmovaps xmm7, [rsp+0x60]
00007e4ecadddd52  vmovaps xmm8, [rsp+0x70]
00007e4ecadddd58  vmovaps xmm9, [rsp+0x80]
00007e4ecadddd61  vmovaps xmm10, [rsp+0x90]
00007e4ecadddd6a  vmovaps xmm11, [rsp+0xA0]
00007e4ecadddd73  vmovaps xmm12, [rsp+0xB0]
00007e4ecadddd7c  vmovaps xmm13, [rsp+0xC0]
00007e4ecadddd85  vmovaps xmm14, [rsp+0xD0]
00007e4ecadddd8e  vmovaps xmm15, [rsp+0xE0]
00007e4ecadddd97  add rsp, 0xF0
00007e4ecadddd9e  pop r11
00007e4ecadddda0  pop r10
00007e4ecadddda2  pop r9
00007e4ecadddda4  pop r8
00007e4ecadddda6  pop rsi
00007e4ecadddda7  pop rdi
00007e4ecadddda8  pop rdx
00007e4ecadddda9  pop rcx
00007e4ecaddddaa  pop rax
00007e4ecaddddab  add rsp, 0x08
00007e4ecaddddaf  jmp 0x00007E4ECADDBF7E
00007e4ecaddddb4  call 0x00007E4ECACC4620
00007e4ecaddddb9  jmp 0x00007E4ECADDBF8B
00007e4ecaddddbe  sub rsp, 0x08
00007e4ecaddddc2  push rax
00007e4ecaddddc3  push rcx
00007e4ecaddddc4  push rdx
00007e4ecaddddc5  push rdi
00007e4ecaddddc6  push rsi
00007e4ecaddddc7  push r8
00007e4ecaddddc9  push r9
00007e4ecaddddcb  push r10
00007e4ecaddddcd  push r11
00007e4ecaddddcf  sub rsp, 0xF0
00007e4ecaddddd6  vmovaps [rsp], xmm0
00007e4ecadddddb  vmovaps [rsp+0x10], xmm2
00007e4ecadddde1  vmovaps [rsp+0x20], xmm3
00007e4ecadddde7  vmovaps [rsp+0x30], xmm4
00007e4ecadddded  vmovaps [rsp+0x40], xmm5
00007e4ecaddddf3  vmovaps [rsp+0x50], xmm6
00007e4ecaddddf9  vmovaps [rsp+0x60], xmm7
00007e4ecaddddff  vmovaps [rsp+0x70], xmm8
00007e4ecaddde05  vmovaps [rsp+0x80], xmm9
00007e4ecaddde0e  vmovaps [rsp+0x90], xmm10
00007e4ecaddde17  vmovaps [rsp+0xA0], xmm11
00007e4ecaddde20  vmovaps [rsp+0xB0], xmm12
00007e4ecaddde29  vmovaps [rsp+0xC0], xmm13
00007e4ecaddde32  vmovaps [rsp+0xD0], xmm14
00007e4ecaddde3b  vmovaps [rsp+0xE0], xmm15
00007e4ecaddde44  sub rsp, 0x30
00007e4ecaddde48  movaps [rsp], xmm1
00007e4ecaddde4c  movaps [rsp+0x10], xmm5
00007e4ecaddde51  movaps [rsp+0x20], xmm7
00007e4ecaddde56  lea rdi, [rsp]
00007e4ecaddde5a  mov esi, 0x00
00007e4ecaddde5f  mov rax, 0x5784BC1F5530
00007e4ecaddde69  call rax
00007e4ecaddde6b  movaps xmm1, [rsp]
00007e4ecaddde6f  add rsp, 0x30
00007e4ecaddde73  vmovaps xmm0, [rsp]
00007e4ecaddde78  vmovaps xmm2, [rsp+0x10]
00007e4ecaddde7e  vmovaps xmm3, [rsp+0x20]
00007e4ecaddde84  vmovaps xmm4, [rsp+0x30]
00007e4ecaddde8a  vmovaps xmm5, [rsp+0x40]
00007e4ecaddde90  vmovaps xmm6, [rsp+0x50]
00007e4ecaddde96  vmovaps xmm7, [rsp+0x60]
00007e4ecaddde9c  vmovaps xmm8, [rsp+0x70]
00007e4ecadddea2  vmovaps xmm9, [rsp+0x80]
00007e4ecadddeab  vmovaps xmm10, [rsp+0x90]
00007e4ecadddeb4  vmovaps xmm11, [rsp+0xA0]
00007e4ecadddebd  vmovaps xmm12, [rsp+0xB0]
00007e4ecadddec6  vmovaps xmm13, [rsp+0xC0]
00007e4ecadddecf  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddded8  vmovaps xmm15, [rsp+0xE0]
00007e4ecadddee1  add rsp, 0xF0
00007e4ecadddee8  pop r11
00007e4ecadddeea  pop r10
00007e4ecadddeec  pop r9
00007e4ecadddeee  pop r8
00007e4ecadddef0  pop rsi
00007e4ecadddef1  pop rdi
00007e4ecadddef2  pop rdx
00007e4ecadddef3  pop rcx
00007e4ecadddef4  pop rax
00007e4ecadddef5  add rsp, 0x08
00007e4ecadddef9  jmp 0x00007E4ECADDC030
00007e4ecadddefe  sub rsp, 0x08
00007e4ecadddf02  push rax
00007e4ecadddf03  push rcx
00007e4ecadddf04  push rdx
00007e4ecadddf05  push rdi
00007e4ecadddf06  push rsi
00007e4ecadddf07  push r8
00007e4ecadddf09  push r9
00007e4ecadddf0b  push r10
00007e4ecadddf0d  push r11
00007e4ecadddf0f  sub rsp, 0xF0
00007e4ecadddf16  vmovaps [rsp], xmm0
00007e4ecadddf1b  vmovaps [rsp+0x10], xmm1
00007e4ecadddf21  vmovaps [rsp+0x20], xmm2
00007e4ecadddf27  vmovaps [rsp+0x30], xmm3
00007e4ecadddf2d  vmovaps [rsp+0x40], xmm4
00007e4ecadddf33  vmovaps [rsp+0x50], xmm5
00007e4ecadddf39  vmovaps [rsp+0x60], xmm6
00007e4ecadddf3f  vmovaps [rsp+0x70], xmm8
00007e4ecadddf45  vmovaps [rsp+0x80], xmm9
00007e4ecadddf4e  vmovaps [rsp+0x90], xmm10
00007e4ecadddf57  vmovaps [rsp+0xA0], xmm11
00007e4ecadddf60  vmovaps [rsp+0xB0], xmm12
00007e4ecadddf69  vmovaps [rsp+0xC0], xmm13
00007e4ecadddf72  vmovaps [rsp+0xD0], xmm14
00007e4ecadddf7b  vmovaps [rsp+0xE0], xmm15
00007e4ecadddf84  sub rsp, 0x30
00007e4ecadddf88  movaps [rsp], xmm7
00007e4ecadddf8c  movaps [rsp+0x10], xmm5
00007e4ecadddf91  movaps [rsp+0x20], xmm15
00007e4ecadddf97  lea rdi, [rsp]
00007e4ecadddf9b  mov esi, 0x00
00007e4ecadddfa0  mov rax, 0x5784BC1F5530
00007e4ecadddfaa  call rax
00007e4ecadddfac  movaps xmm7, [rsp]
00007e4ecadddfb0  add rsp, 0x30
00007e4ecadddfb4  vmovaps xmm0, [rsp]
00007e4ecadddfb9  vmovaps xmm1, [rsp+0x10]
00007e4ecadddfbf  vmovaps xmm2, [rsp+0x20]
00007e4ecadddfc5  vmovaps xmm3, [rsp+0x30]
00007e4ecadddfcb  vmovaps xmm4, [rsp+0x40]
00007e4ecadddfd1  vmovaps xmm5, [rsp+0x50]
00007e4ecadddfd7  vmovaps xmm6, [rsp+0x60]
00007e4ecadddfdd  vmovaps xmm8, [rsp+0x70]
00007e4ecadddfe3  vmovaps xmm9, [rsp+0x80]
00007e4ecadddfec  vmovaps xmm10, [rsp+0x90]
00007e4ecadddff5  vmovaps xmm11, [rsp+0xA0]
00007e4ecadddffe  vmovaps xmm12, [rsp+0xB0]
00007e4ecadde007  vmovaps xmm13, [rsp+0xC0]
00007e4ecadde010  vmovaps xmm14, [rsp+0xD0]
00007e4ecadde019  vmovaps xmm15, [rsp+0xE0]
00007e4ecadde022  add rsp, 0xF0
00007e4ecadde029  pop r11
00007e4ecadde02b  pop r10
00007e4ecadde02d  pop r9
00007e4ecadde02f  pop r8
00007e4ecadde031  pop rsi
00007e4ecadde032  pop rdi
00007e4ecadde033  pop rdx
00007e4ecadde034  pop rcx
00007e4ecadde035  pop rax
00007e4ecadde036  add rsp, 0x08
00007e4ecadde03a  jmp 0x00007E4ECADDC066
00007e4ecadde03f  call 0x00007E4ECACB52F0
00007e4ecadde044  jmp 0x00007E4ECADDC073
00007e4ecadde049  sub rsp, 0x08
00007e4ecadde04d  push rax
00007e4ecadde04e  push rcx
00007e4ecadde04f  push rdx
00007e4ecadde050  push rdi
00007e4ecadde051  push rsi
00007e4ecadde052  push r8
00007e4ecadde054  push r9
00007e4ecadde056  push r10
00007e4ecadde058  push r11
00007e4ecadde05a  sub rsp, 0xF0
00007e4ecadde061  vmovaps [rsp], xmm0
00007e4ecadde066  vmovaps [rsp+0x10], xmm1
00007e4ecadde06c  vmovaps [rsp+0x20], xmm2
00007e4ecadde072  vmovaps [rsp+0x30], xmm3
00007e4ecadde078  vmovaps [rsp+0x40], xmm4
00007e4ecadde07e  vmovaps [rsp+0x50], xmm5
00007e4ecadde084  vmovaps [rsp+0x60], xmm6
00007e4ecadde08a  vmovaps [rsp+0x70], xmm7
00007e4ecadde090  vmovaps [rsp+0x80], xmm8
00007e4ecadde099  vmovaps [rsp+0x90], xmm9
00007e4ecadde0a2  vmovaps [rsp+0xA0], xmm10
00007e4ecadde0ab  vmovaps [rsp+0xB0], xmm11
00007e4ecadde0b4  vmovaps [rsp+0xC0], xmm12
00007e4ecadde0bd  vmovaps [rsp+0xD0], xmm13
00007e4ecadde0c6  vmovaps [rsp+0xE0], xmm14
00007e4ecadde0cf  sub rsp, 0x30
00007e4ecadde0d3  movaps [rsp], xmm15
00007e4ecadde0d8  movaps [rsp+0x10], xmm5
00007e4ecadde0dd  movaps [rsp+0x20], xmm3
00007e4ecadde0e2  lea rdi, [rsp]
00007e4ecadde0e6  mov esi, 0x00
00007e4ecadde0eb  mov rax, 0x5784BC1F5530
00007e4ecadde0f5  call rax
00007e4ecadde0f7  movaps xmm15, [rsp]
00007e4ecadde0fc  add rsp, 0x30
00007e4ecadde100  vmovaps xmm0, [rsp]
00007e4ecadde105  vmovaps xmm1, [rsp+0x10]
00007e4ecadde10b  vmovaps xmm2, [rsp+0x20]
00007e4ecadde111  vmovaps xmm3, [rsp+0x30]
00007e4ecadde117  vmovaps xmm4, [rsp+0x40]
00007e4ecadde11d  vmovaps xmm5, [rsp+0x50]
00007e4ecadde123  vmovaps xmm6, [rsp+0x60]
00007e4ecadde129  vmovaps xmm7, [rsp+0x70]
00007e4ecadde12f  vmovaps xmm8, [rsp+0x80]
00007e4ecadde138  vmovaps xmm9, [rsp+0x90]
00007e4ecadde141  vmovaps xmm10, [rsp+0xA0]
00007e4ecadde14a  vmovaps xmm11, [rsp+0xB0]
00007e4ecadde153  vmovaps xmm12, [rsp+0xC0]
00007e4ecadde15c  vmovaps xmm13, [rsp+0xD0]
00007e4ecadde165  vmovaps xmm14, [rsp+0xE0]
00007e4ecadde16e  add rsp, 0xF0
00007e4ecadde175  pop r11
00007e4ecadde177  pop r10
00007e4ecadde179  pop r9
00007e4ecadde17b  pop r8
00007e4ecadde17d  pop rsi
00007e4ecadde17e  pop rdi
00007e4ecadde17f  pop rdx
00007e4ecadde180  pop rcx
00007e4ecadde181  pop rax
00007e4ecadde182  add rsp, 0x08
00007e4ecadde186  jmp 0x00007E4ECADDC099
00007e4ecadde18b  sub rsp, 0x08
00007e4ecadde18f  push rax
00007e4ecadde190  push rcx
00007e4ecadde191  push rdx
00007e4ecadde192  push rdi
00007e4ecadde193  push rsi
00007e4ecadde194  push r8
00007e4ecadde196  push r9
00007e4ecadde198  push r10
00007e4ecadde19a  push r11
00007e4ecadde19c  sub rsp, 0xF0
00007e4ecadde1a3  vmovaps [rsp], xmm0
00007e4ecadde1a8  vmovaps [rsp+0x10], xmm2
00007e4ecadde1ae  vmovaps [rsp+0x20], xmm3
00007e4ecadde1b4  vmovaps [rsp+0x30], xmm4
00007e4ecadde1ba  vmovaps [rsp+0x40], xmm5
00007e4ecadde1c0  vmovaps [rsp+0x50], xmm6
00007e4ecadde1c6  vmovaps [rsp+0x60], xmm7
00007e4ecadde1cc  vmovaps [rsp+0x70], xmm8
00007e4ecadde1d2  vmovaps [rsp+0x80], xmm9
00007e4ecadde1db  vmovaps [rsp+0x90], xmm10
00007e4ecadde1e4  vmovaps [rsp+0xA0], xmm11
00007e4ecadde1ed  vmovaps [rsp+0xB0], xmm12
00007e4ecadde1f6  vmovaps [rsp+0xC0], xmm13
00007e4ecadde1ff  vmovaps [rsp+0xD0], xmm14
00007e4ecadde208  vmovaps [rsp+0xE0], xmm15
00007e4ecadde211  sub rsp, 0x30
00007e4ecadde215  movaps [rsp], xmm1
00007e4ecadde219  movaps [rsp+0x10], xmm5
00007e4ecadde21e  movaps [rsp+0x20], xmm4
00007e4ecadde223  lea rdi, [rsp]
00007e4ecadde227  mov esi, 0x00
00007e4ecadde22c  mov rax, 0x5784BC1F5530
00007e4ecadde236  call rax
00007e4ecadde238  movaps xmm1, [rsp]
00007e4ecadde23c  add rsp, 0x30
00007e4ecadde240  vmovaps xmm0, [rsp]
00007e4ecadde245  vmovaps xmm2, [rsp+0x10]
00007e4ecadde24b  vmovaps xmm3, [rsp+0x20]
00007e4ecadde251  vmovaps xmm4, [rsp+0x30]
00007e4ecadde257  vmovaps xmm5, [rsp+0x40]
00007e4ecadde25d  vmovaps xmm6, [rsp+0x50]
00007e4ecadde263  vmovaps xmm7, [rsp+0x60]
00007e4ecadde269  vmovaps xmm8, [rsp+0x70]
00007e4ecadde26f  vmovaps xmm9, [rsp+0x80]
00007e4ecadde278  vmovaps xmm10, [rsp+0x90]
00007e4ecadde281  vmovaps xmm11, [rsp+0xA0]
00007e4ecadde28a  vmovaps xmm12, [rsp+0xB0]
00007e4ecadde293  vmovaps xmm13, [rsp+0xC0]
00007e4ecadde29c  vmovaps xmm14, [rsp+0xD0]
00007e4ecadde2a5  vmovaps xmm15, [rsp+0xE0]
00007e4ecadde2ae  add rsp, 0xF0
00007e4ecadde2b5  pop r11
00007e4ecadde2b7  pop r10
00007e4ecadde2b9  pop r9
00007e4ecadde2bb  pop r8
00007e4ecadde2bd  pop rsi
00007e4ecadde2be  pop rdi
00007e4ecadde2bf  pop rdx
00007e4ecadde2c0  pop rcx
00007e4ecadde2c1  pop rax
00007e4ecadde2c2  add rsp, 0x08
00007e4ecadde2c6  jmp 0x00007E4ECADDC0B9
00007e4ecadde2cb  sub rsp, 0x08
00007e4ecadde2cf  push rax
00007e4ecadde2d0  push rcx
00007e4ecadde2d1  push rdx
00007e4ecadde2d2  push rdi
00007e4ecadde2d3  push rsi
00007e4ecadde2d4  push r8
00007e4ecadde2d6  push r9
00007e4ecadde2d8  push r10
00007e4ecadde2da  push r11
00007e4ecadde2dc  sub rsp, 0xF0
00007e4ecadde2e3  vmovaps [rsp], xmm0
00007e4ecadde2e8  vmovaps [rsp+0x10], xmm1
00007e4ecadde2ee  vmovaps [rsp+0x20], xmm2
00007e4ecadde2f4  vmovaps [rsp+0x30], xmm3
00007e4ecadde2fa  vmovaps [rsp+0x40], xmm5
00007e4ecadde300  vmovaps [rsp+0x50], xmm6
00007e4ecadde306  vmovaps [rsp+0x60], xmm7
00007e4ecadde30c  vmovaps [rsp+0x70], xmm8
00007e4ecadde312  vmovaps [rsp+0x80], xmm9
00007e4ecadde31b  vmovaps [rsp+0x90], xmm10
00007e4ecadde324  vmovaps [rsp+0xA0], xmm11
00007e4ecadde32d  vmovaps [rsp+0xB0], xmm12
00007e4ecadde336  vmovaps [rsp+0xC0], xmm13
00007e4ecadde33f  vmovaps [rsp+0xD0], xmm14
00007e4ecadde348  vmovaps [rsp+0xE0], xmm15
00007e4ecadde351  sub rsp, 0x30
00007e4ecadde355  movaps [rsp], xmm4
00007e4ecadde359  movaps [rsp+0x10], xmm3
00007e4ecadde35e  movaps [rsp+0x20], xmm5
00007e4ecadde363  lea rdi, [rsp]
00007e4ecadde367  mov esi, 0x00
00007e4ecadde36c  mov rax, 0x5784BC1F5530
00007e4ecadde376  call rax
00007e4ecadde378  movaps xmm4, [rsp]
00007e4ecadde37c  add rsp, 0x30
00007e4ecadde380  vmovaps xmm0, [rsp]
00007e4ecadde385  vmovaps xmm1, [rsp+0x10]
00007e4ecadde38b  vmovaps xmm2, [rsp+0x20]
00007e4ecadde391  vmovaps xmm3, [rsp+0x30]
00007e4ecadde397  vmovaps xmm5, [rsp+0x40]
00007e4ecadde39d  vmovaps xmm6, [rsp+0x50]
00007e4ecadde3a3  vmovaps xmm7, [rsp+0x60]
00007e4ecadde3a9  vmovaps xmm8, [rsp+0x70]
00007e4ecadde3af  vmovaps xmm9, [rsp+0x80]
00007e4ecadde3b8  vmovaps xmm10, [rsp+0x90]
00007e4ecadde3c1  vmovaps xmm11, [rsp+0xA0]
00007e4ecadde3ca  vmovaps xmm12, [rsp+0xB0]
00007e4ecadde3d3  vmovaps xmm13, [rsp+0xC0]
00007e4ecadde3dc  vmovaps xmm14, [rsp+0xD0]
00007e4ecadde3e5  vmovaps xmm15, [rsp+0xE0]
00007e4ecadde3ee  add rsp, 0xF0
00007e4ecadde3f5  pop r11
00007e4ecadde3f7  pop r10
00007e4ecadde3f9  pop r9
00007e4ecadde3fb  pop r8
00007e4ecadde3fd  pop rsi
00007e4ecadde3fe  pop rdi
00007e4ecadde3ff  pop rdx
00007e4ecadde400  pop rcx
00007e4ecadde401  pop rax
00007e4ecadde402  add rsp, 0x08
00007e4ecadde406  jmp 0x00007E4ECADDC107
00007e4ecadde40b  call 0x00007E4ECACB52F0
00007e4ecadde410  jmp 0x00007E4ECADDC114
00007e4ecadde415  sub rsp, 0x08
00007e4ecadde419  push rax
00007e4ecadde41a  push rcx
00007e4ecadde41b  push rdx
00007e4ecadde41c  push rdi
00007e4ecadde41d  push rsi
00007e4ecadde41e  push r8
00007e4ecadde420  push r9
00007e4ecadde422  push r10
00007e4ecadde424  push r11
00007e4ecadde426  sub rsp, 0xF0
00007e4ecadde42d  vmovaps [rsp], xmm0
00007e4ecadde432  vmovaps [rsp+0x10], xmm1
00007e4ecadde438  vmovaps [rsp+0x20], xmm2
00007e4ecadde43e  vmovaps [rsp+0x30], xmm3
00007e4ecadde444  vmovaps [rsp+0x40], xmm4
00007e4ecadde44a  vmovaps [rsp+0x50], xmm6
00007e4ecadde450  vmovaps [rsp+0x60], xmm7
00007e4ecadde456  vmovaps [rsp+0x70], xmm8
00007e4ecadde45c  vmovaps [rsp+0x80], xmm9
00007e4ecadde465  vmovaps [rsp+0x90], xmm10
00007e4ecadde46e  vmovaps [rsp+0xA0], xmm11
00007e4ecadde477  vmovaps [rsp+0xB0], xmm12
00007e4ecadde480  vmovaps [rsp+0xC0], xmm13
00007e4ecadde489  vmovaps [rsp+0xD0], xmm14
00007e4ecadde492  vmovaps [rsp+0xE0], xmm15
00007e4ecadde49b  sub rsp, 0x30
00007e4ecadde49f  movaps [rsp], xmm5
00007e4ecadde4a3  movaps [rsp+0x10], xmm6
00007e4ecadde4a8  movaps [rsp+0x20], xmm3
00007e4ecadde4ad  lea rdi, [rsp]
00007e4ecadde4b1  mov esi, 0x00
00007e4ecadde4b6  mov rax, 0x5784BC1F5530
00007e4ecadde4c0  call rax
00007e4ecadde4c2  movaps xmm5, [rsp]
00007e4ecadde4c6  add rsp, 0x30
00007e4ecadde4ca  vmovaps xmm0, [rsp]
00007e4ecadde4cf  vmovaps xmm1, [rsp+0x10]
00007e4ecadde4d5  vmovaps xmm2, [rsp+0x20]
00007e4ecadde4db  vmovaps xmm3, [rsp+0x30]
00007e4ecadde4e1  vmovaps xmm4, [rsp+0x40]
00007e4ecadde4e7  vmovaps xmm6, [rsp+0x50]
00007e4ecadde4ed  vmovaps xmm7, [rsp+0x60]
00007e4ecadde4f3  vmovaps xmm8, [rsp+0x70]
00007e4ecadde4f9  vmovaps xmm9, [rsp+0x80]
00007e4ecadde502  vmovaps xmm10, [rsp+0x90]
00007e4ecadde50b  vmovaps xmm11, [rsp+0xA0]
00007e4ecadde514  vmovaps xmm12, [rsp+0xB0]
00007e4ecadde51d  vmovaps xmm13, [rsp+0xC0]
00007e4ecadde526  vmovaps xmm14, [rsp+0xD0]
00007e4ecadde52f  vmovaps xmm15, [rsp+0xE0]
00007e4ecadde538  add rsp, 0xF0
00007e4ecadde53f  pop r11
00007e4ecadde541  pop r10
00007e4ecadde543  pop r9
00007e4ecadde545  pop r8
00007e4ecadde547  pop rsi
00007e4ecadde548  pop rdi
00007e4ecadde549  pop rdx
00007e4ecadde54a  pop rcx
00007e4ecadde54b  pop rax
00007e4ecadde54c  add rsp, 0x08
00007e4ecadde550  jmp 0x00007E4ECADDC13A
00007e4ecadde555  sub rsp, 0x08
00007e4ecadde559  push rax
00007e4ecadde55a  push rcx
00007e4ecadde55b  push rdx
00007e4ecadde55c  push rdi
00007e4ecadde55d  push rsi
00007e4ecadde55e  push r8
00007e4ecadde560  push r9
00007e4ecadde562  push r10
00007e4ecadde564  push r11
00007e4ecadde566  sub rsp, 0xF0
00007e4ecadde56d  vmovaps [rsp], xmm0
00007e4ecadde572  vmovaps [rsp+0x10], xmm1
00007e4ecadde578  vmovaps [rsp+0x20], xmm2
00007e4ecadde57e  vmovaps [rsp+0x30], xmm3
00007e4ecadde584  vmovaps [rsp+0x40], xmm4
00007e4ecadde58a  vmovaps [rsp+0x50], xmm5
00007e4ecadde590  vmovaps [rsp+0x60], xmm7
00007e4ecadde596  vmovaps [rsp+0x70], xmm8
00007e4ecadde59c  vmovaps [rsp+0x80], xmm9
00007e4ecadde5a5  vmovaps [rsp+0x90], xmm10
00007e4ecadde5ae  vmovaps [rsp+0xA0], xmm11
00007e4ecadde5b7  vmovaps [rsp+0xB0], xmm12
00007e4ecadde5c0  vmovaps [rsp+0xC0], xmm13
00007e4ecadde5c9  vmovaps [rsp+0xD0], xmm14
00007e4ecadde5d2  vmovaps [rsp+0xE0], xmm15
00007e4ecadde5db  sub rsp, 0x30
00007e4ecadde5df  movaps [rsp], xmm6
00007e4ecadde5e3  movaps [rsp+0x10], xmm9
00007e4ecadde5e9  movaps [rsp+0x20], xmm1
00007e4ecadde5ee  lea rdi, [rsp]
00007e4ecadde5f2  mov esi, 0x00
00007e4ecadde5f7  mov rax, 0x5784BC1F5530
00007e4ecadde601  call rax
00007e4ecadde603  movaps xmm6, [rsp]
00007e4ecadde607  add rsp, 0x30
00007e4ecadde60b  vmovaps xmm0, [rsp]
00007e4ecadde610  vmovaps xmm1, [rsp+0x10]
00007e4ecadde616  vmovaps xmm2, [rsp+0x20]
00007e4ecadde61c  vmovaps xmm3, [rsp+0x30]
00007e4ecadde622  vmovaps xmm4, [rsp+0x40]
00007e4ecadde628  vmovaps xmm5, [rsp+0x50]
00007e4ecadde62e  vmovaps xmm7, [rsp+0x60]
00007e4ecadde634  vmovaps xmm8, [rsp+0x70]
00007e4ecadde63a  vmovaps xmm9, [rsp+0x80]
00007e4ecadde643  vmovaps xmm10, [rsp+0x90]
00007e4ecadde64c  vmovaps xmm11, [rsp+0xA0]
00007e4ecadde655  vmovaps xmm12, [rsp+0xB0]
00007e4ecadde65e  vmovaps xmm13, [rsp+0xC0]
00007e4ecadde667  vmovaps xmm14, [rsp+0xD0]
00007e4ecadde670  vmovaps xmm15, [rsp+0xE0]
00007e4ecadde679  add rsp, 0xF0
00007e4ecadde680  pop r11
00007e4ecadde682  pop r10
00007e4ecadde684  pop r9
00007e4ecadde686  pop r8
00007e4ecadde688  pop rsi
00007e4ecadde689  pop rdi
00007e4ecadde68a  pop rdx
00007e4ecadde68b  pop rcx
00007e4ecadde68c  pop rax
00007e4ecadde68d  add rsp, 0x08
00007e4ecadde691  jmp 0x00007E4ECADDC15E
00007e4ecadde696  sub rsp, 0x08
00007e4ecadde69a  push rax
00007e4ecadde69b  push rcx
00007e4ecadde69c  push rdx
00007e4ecadde69d  push rdi
00007e4ecadde69e  push rsi
00007e4ecadde69f  push r8
00007e4ecadde6a1  push r9
00007e4ecadde6a3  push r10
00007e4ecadde6a5  push r11
00007e4ecadde6a7  sub rsp, 0xF0
00007e4ecadde6ae  vmovaps [rsp], xmm0
00007e4ecadde6b3  vmovaps [rsp+0x10], xmm1
00007e4ecadde6b9  vmovaps [rsp+0x20], xmm2
00007e4ecadde6bf  vmovaps [rsp+0x30], xmm3
00007e4ecadde6c5  vmovaps [rsp+0x40], xmm4
00007e4ecadde6cb  vmovaps [rsp+0x50], xmm5
00007e4ecadde6d1  vmovaps [rsp+0x60], xmm6
00007e4ecadde6d7  vmovaps [rsp+0x70], xmm7
00007e4ecadde6dd  vmovaps [rsp+0x80], xmm8
00007e4ecadde6e6  vmovaps [rsp+0x90], xmm10
00007e4ecadde6ef  vmovaps [rsp+0xA0], xmm11
00007e4ecadde6f8  vmovaps [rsp+0xB0], xmm12
00007e4ecadde701  vmovaps [rsp+0xC0], xmm13
00007e4ecadde70a  vmovaps [rsp+0xD0], xmm14
00007e4ecadde713  vmovaps [rsp+0xE0], xmm15
00007e4ecadde71c  sub rsp, 0x30
00007e4ecadde720  movaps [rsp], xmm9
00007e4ecadde725  movaps [rsp+0x10], xmm3
00007e4ecadde72a  movaps [rsp+0x20], xmm1
00007e4ecadde72f  lea rdi, [rsp]
00007e4ecadde733  mov esi, 0x00
00007e4ecadde738  mov rax, 0x5784BC1F5530
00007e4ecadde742  call rax
00007e4ecadde744  movaps xmm9, [rsp]
00007e4ecadde749  add rsp, 0x30
00007e4ecadde74d  vmovaps xmm0, [rsp]
00007e4ecadde752  vmovaps xmm1, [rsp+0x10]
00007e4ecadde758  vmovaps xmm2, [rsp+0x20]
00007e4ecadde75e  vmovaps xmm3, [rsp+0x30]
00007e4ecadde764  vmovaps xmm4, [rsp+0x40]
00007e4ecadde76a  vmovaps xmm5, [rsp+0x50]
00007e4ecadde770  vmovaps xmm6, [rsp+0x60]
00007e4ecadde776  vmovaps xmm7, [rsp+0x70]
00007e4ecadde77c  vmovaps xmm8, [rsp+0x80]
00007e4ecadde785  vmovaps xmm10, [rsp+0x90]
00007e4ecadde78e  vmovaps xmm11, [rsp+0xA0]
00007e4ecadde797  vmovaps xmm12, [rsp+0xB0]
00007e4ecadde7a0  vmovaps xmm13, [rsp+0xC0]
00007e4ecadde7a9  vmovaps xmm14, [rsp+0xD0]
00007e4ecadde7b2  vmovaps xmm15, [rsp+0xE0]
00007e4ecadde7bb  add rsp, 0xF0
00007e4ecadde7c2  pop r11
00007e4ecadde7c4  pop r10
00007e4ecadde7c6  pop r9
00007e4ecadde7c8  pop r8
00007e4ecadde7ca  pop rsi
00007e4ecadde7cb  pop rdi
00007e4ecadde7cc  pop rdx
00007e4ecadde7cd  pop rcx
00007e4ecadde7ce  pop rax
00007e4ecadde7cf  add rsp, 0x08
00007e4ecadde7d3  jmp 0x00007E4ECADDC1AA
00007e4ecadde7d8  call 0x00007E4ECACB52F0
00007e4ecadde7dd  jmp 0x00007E4ECADDC1B7
00007e4ecadde7e2  sub rsp, 0x08
00007e4ecadde7e6  push rax
00007e4ecadde7e7  push rcx
00007e4ecadde7e8  push rdx
00007e4ecadde7e9  push rdi
00007e4ecadde7ea  push rsi
00007e4ecadde7eb  push r8
00007e4ecadde7ed  push r9
00007e4ecadde7ef  push r10
00007e4ecadde7f1  push r11
00007e4ecadde7f3  sub rsp, 0xF0
00007e4ecadde7fa  vmovaps [rsp], xmm0
00007e4ecadde7ff  vmovaps [rsp+0x10], xmm1
00007e4ecadde805  vmovaps [rsp+0x20], xmm2
00007e4ecadde80b  vmovaps [rsp+0x30], xmm3
00007e4ecadde811  vmovaps [rsp+0x40], xmm4
00007e4ecadde817  vmovaps [rsp+0x50], xmm5
00007e4ecadde81d  vmovaps [rsp+0x60], xmm6
00007e4ecadde823  vmovaps [rsp+0x70], xmm7
00007e4ecadde829  vmovaps [rsp+0x80], xmm8
00007e4ecadde832  vmovaps [rsp+0x90], xmm9
00007e4ecadde83b  vmovaps [rsp+0xA0], xmm10
00007e4ecadde844  vmovaps [rsp+0xB0], xmm11
00007e4ecadde84d  vmovaps [rsp+0xC0], xmm12
00007e4ecadde856  vmovaps [rsp+0xD0], xmm13
00007e4ecadde85f  vmovaps [rsp+0xE0], xmm14
00007e4ecadde868  sub rsp, 0x30
00007e4ecadde86c  movaps [rsp], xmm15
00007e4ecadde871  movaps [rsp+0x10], xmm3
00007e4ecadde876  movaps [rsp+0x20], xmm7
00007e4ecadde87b  lea rdi, [rsp]
00007e4ecadde87f  mov esi, 0x00
00007e4ecadde884  mov rax, 0x5784BC1F5530
00007e4ecadde88e  call rax
00007e4ecadde890  movaps xmm15, [rsp]
00007e4ecadde895  add rsp, 0x30
00007e4ecadde899  vmovaps xmm0, [rsp]
00007e4ecadde89e  vmovaps xmm1, [rsp+0x10]
00007e4ecadde8a4  vmovaps xmm2, [rsp+0x20]
00007e4ecadde8aa  vmovaps xmm3, [rsp+0x30]
00007e4ecadde8b0  vmovaps xmm4, [rsp+0x40]
00007e4ecadde8b6  vmovaps xmm5, [rsp+0x50]
00007e4ecadde8bc  vmovaps xmm6, [rsp+0x60]
00007e4ecadde8c2  vmovaps xmm7, [rsp+0x70]
00007e4ecadde8c8  vmovaps xmm8, [rsp+0x80]
00007e4ecadde8d1  vmovaps xmm9, [rsp+0x90]
00007e4ecadde8da  vmovaps xmm10, [rsp+0xA0]
00007e4ecadde8e3  vmovaps xmm11, [rsp+0xB0]
00007e4ecadde8ec  vmovaps xmm12, [rsp+0xC0]
00007e4ecadde8f5  vmovaps xmm13, [rsp+0xD0]
00007e4ecadde8fe  vmovaps xmm14, [rsp+0xE0]
00007e4ecadde907  add rsp, 0xF0
00007e4ecadde90e  pop r11
00007e4ecadde910  pop r10
00007e4ecadde912  pop r9
00007e4ecadde914  pop r8
00007e4ecadde916  pop rsi
00007e4ecadde917  pop rdi
00007e4ecadde918  pop rdx
00007e4ecadde919  pop rcx
00007e4ecadde91a  pop rax
00007e4ecadde91b  add rsp, 0x08
00007e4ecadde91f  jmp 0x00007E4ECADDC1E3
00007e4ecadde924  sub rsp, 0x08
00007e4ecadde928  push rax
00007e4ecadde929  push rcx
00007e4ecadde92a  push rdx
00007e4ecadde92b  push rdi
00007e4ecadde92c  push rsi
00007e4ecadde92d  push r8
00007e4ecadde92f  push r9
00007e4ecadde931  push r10
00007e4ecadde933  push r11
00007e4ecadde935  sub rsp, 0xF0
00007e4ecadde93c  vmovaps [rsp], xmm0
00007e4ecadde941  vmovaps [rsp+0x10], xmm1
00007e4ecadde947  vmovaps [rsp+0x20], xmm2
00007e4ecadde94d  vmovaps [rsp+0x30], xmm4
00007e4ecadde953  vmovaps [rsp+0x40], xmm5
00007e4ecadde959  vmovaps [rsp+0x50], xmm6
00007e4ecadde95f  vmovaps [rsp+0x60], xmm7
00007e4ecadde965  vmovaps [rsp+0x70], xmm8
00007e4ecadde96b  vmovaps [rsp+0x80], xmm9
00007e4ecadde974  vmovaps [rsp+0x90], xmm10
00007e4ecadde97d  vmovaps [rsp+0xA0], xmm11
00007e4ecadde986  vmovaps [rsp+0xB0], xmm12
00007e4ecadde98f  vmovaps [rsp+0xC0], xmm13
00007e4ecadde998  vmovaps [rsp+0xD0], xmm14
00007e4ecadde9a1  vmovaps [rsp+0xE0], xmm15
00007e4ecadde9aa  sub rsp, 0x30
00007e4ecadde9ae  movaps [rsp], xmm3
00007e4ecadde9b2  movaps [rsp+0x10], xmm1
00007e4ecadde9b7  movaps [rsp+0x20], xmm15
00007e4ecadde9bd  lea rdi, [rsp]
00007e4ecadde9c1  mov esi, 0x00
00007e4ecadde9c6  mov rax, 0x5784BC1F5530
00007e4ecadde9d0  call rax
00007e4ecadde9d2  movaps xmm3, [rsp]
00007e4ecadde9d6  add rsp, 0x30
00007e4ecadde9da  vmovaps xmm0, [rsp]
00007e4ecadde9df  vmovaps xmm1, [rsp+0x10]
00007e4ecadde9e5  vmovaps xmm2, [rsp+0x20]
00007e4ecadde9eb  vmovaps xmm4, [rsp+0x30]
00007e4ecadde9f1  vmovaps xmm5, [rsp+0x40]
00007e4ecadde9f7  vmovaps xmm6, [rsp+0x50]
00007e4ecadde9fd  vmovaps xmm7, [rsp+0x60]
00007e4ecaddea03  vmovaps xmm8, [rsp+0x70]
00007e4ecaddea09  vmovaps xmm9, [rsp+0x80]
00007e4ecaddea12  vmovaps xmm10, [rsp+0x90]
00007e4ecaddea1b  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddea24  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddea2d  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddea36  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddea3f  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddea48  add rsp, 0xF0
00007e4ecaddea4f  pop r11
00007e4ecaddea51  pop r10
00007e4ecaddea53  pop r9
00007e4ecaddea55  pop r8
00007e4ecaddea57  pop rsi
00007e4ecaddea58  pop rdi
00007e4ecaddea59  pop rdx
00007e4ecaddea5a  pop rcx
00007e4ecaddea5b  pop rax
00007e4ecaddea5c  add rsp, 0x08
00007e4ecaddea60  jmp 0x00007E4ECADDC272
00007e4ecaddea65  call 0x00007E4ECACB52F0
00007e4ecaddea6a  jmp 0x00007E4ECADDC27C
00007e4ecaddea6f  sub rsp, 0x08
00007e4ecaddea73  push rax
00007e4ecaddea74  push rcx
00007e4ecaddea75  push rdx
00007e4ecaddea76  push rdi
00007e4ecaddea77  push rsi
00007e4ecaddea78  push r8
00007e4ecaddea7a  push r9
00007e4ecaddea7c  push r10
00007e4ecaddea7e  push r11
00007e4ecaddea80  sub rsp, 0xF0
00007e4ecaddea87  vmovaps [rsp], xmm0
00007e4ecaddea8c  vmovaps [rsp+0x10], xmm1
00007e4ecaddea92  vmovaps [rsp+0x20], xmm2
00007e4ecaddea98  vmovaps [rsp+0x30], xmm3
00007e4ecaddea9e  vmovaps [rsp+0x40], xmm4
00007e4ecaddeaa4  vmovaps [rsp+0x50], xmm5
00007e4ecaddeaaa  vmovaps [rsp+0x60], xmm6
00007e4ecaddeab0  vmovaps [rsp+0x70], xmm7
00007e4ecaddeab6  vmovaps [rsp+0x80], xmm8
00007e4ecaddeabf  vmovaps [rsp+0x90], xmm9
00007e4ecaddeac8  vmovaps [rsp+0xA0], xmm10
00007e4ecaddead1  vmovaps [rsp+0xB0], xmm11
00007e4ecaddeada  vmovaps [rsp+0xC0], xmm12
00007e4ecaddeae3  vmovaps [rsp+0xD0], xmm13
00007e4ecaddeaec  vmovaps [rsp+0xE0], xmm14
00007e4ecaddeaf5  sub rsp, 0x30
00007e4ecaddeaf9  movaps [rsp], xmm15
00007e4ecaddeafe  movaps [rsp+0x10], xmm14
00007e4ecaddeb04  movaps [rsp+0x20], xmm4
00007e4ecaddeb09  lea rdi, [rsp]
00007e4ecaddeb0d  mov esi, 0x00
00007e4ecaddeb12  mov rax, 0x5784BC1F5530
00007e4ecaddeb1c  call rax
00007e4ecaddeb1e  movaps xmm15, [rsp]
00007e4ecaddeb23  add rsp, 0x30
00007e4ecaddeb27  vmovaps xmm0, [rsp]
00007e4ecaddeb2c  vmovaps xmm1, [rsp+0x10]
00007e4ecaddeb32  vmovaps xmm2, [rsp+0x20]
00007e4ecaddeb38  vmovaps xmm3, [rsp+0x30]
00007e4ecaddeb3e  vmovaps xmm4, [rsp+0x40]
00007e4ecaddeb44  vmovaps xmm5, [rsp+0x50]
00007e4ecaddeb4a  vmovaps xmm6, [rsp+0x60]
00007e4ecaddeb50  vmovaps xmm7, [rsp+0x70]
00007e4ecaddeb56  vmovaps xmm8, [rsp+0x80]
00007e4ecaddeb5f  vmovaps xmm9, [rsp+0x90]
00007e4ecaddeb68  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddeb71  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddeb7a  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddeb83  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddeb8c  vmovaps xmm14, [rsp+0xE0]
00007e4ecaddeb95  add rsp, 0xF0
00007e4ecaddeb9c  pop r11
00007e4ecaddeb9e  pop r10
00007e4ecaddeba0  pop r9
00007e4ecaddeba2  pop r8
00007e4ecaddeba4  pop rsi
00007e4ecaddeba5  pop rdi
00007e4ecaddeba6  pop rdx
00007e4ecaddeba7  pop rcx
00007e4ecaddeba8  pop rax
00007e4ecaddeba9  add rsp, 0x08
00007e4ecaddebad  jmp 0x00007E4ECADDC2AA
00007e4ecaddebb2  sub rsp, 0x08
00007e4ecaddebb6  push rax
00007e4ecaddebb7  push rcx
00007e4ecaddebb8  push rdx
00007e4ecaddebb9  push rdi
00007e4ecaddebba  push rsi
00007e4ecaddebbb  push r8
00007e4ecaddebbd  push r9
00007e4ecaddebbf  push r10
00007e4ecaddebc1  push r11
00007e4ecaddebc3  sub rsp, 0xF0
00007e4ecaddebca  vmovaps [rsp], xmm0
00007e4ecaddebcf  vmovaps [rsp+0x10], xmm1
00007e4ecaddebd5  vmovaps [rsp+0x20], xmm2
00007e4ecaddebdb  vmovaps [rsp+0x30], xmm3
00007e4ecaddebe1  vmovaps [rsp+0x40], xmm4
00007e4ecaddebe7  vmovaps [rsp+0x50], xmm5
00007e4ecaddebed  vmovaps [rsp+0x60], xmm6
00007e4ecaddebf3  vmovaps [rsp+0x70], xmm7
00007e4ecaddebf9  vmovaps [rsp+0x80], xmm8
00007e4ecaddec02  vmovaps [rsp+0x90], xmm9
00007e4ecaddec0b  vmovaps [rsp+0xA0], xmm10
00007e4ecaddec14  vmovaps [rsp+0xB0], xmm11
00007e4ecaddec1d  vmovaps [rsp+0xC0], xmm12
00007e4ecaddec26  vmovaps [rsp+0xD0], xmm13
00007e4ecaddec2f  vmovaps [rsp+0xE0], xmm15
00007e4ecaddec38  sub rsp, 0x30
00007e4ecaddec3c  movaps [rsp], xmm14
00007e4ecaddec41  movaps [rsp+0x10], xmm2
00007e4ecaddec46  movaps [rsp+0x20], xmm1
00007e4ecaddec4b  lea rdi, [rsp]
00007e4ecaddec4f  mov esi, 0x00
00007e4ecaddec54  mov rax, 0x5784BC1F5530
00007e4ecaddec5e  call rax
00007e4ecaddec60  movaps xmm14, [rsp]
00007e4ecaddec65  add rsp, 0x30
00007e4ecaddec69  vmovaps xmm0, [rsp]
00007e4ecaddec6e  vmovaps xmm1, [rsp+0x10]
00007e4ecaddec74  vmovaps xmm2, [rsp+0x20]
00007e4ecaddec7a  vmovaps xmm3, [rsp+0x30]
00007e4ecaddec80  vmovaps xmm4, [rsp+0x40]
00007e4ecaddec86  vmovaps xmm5, [rsp+0x50]
00007e4ecaddec8c  vmovaps xmm6, [rsp+0x60]
00007e4ecaddec92  vmovaps xmm7, [rsp+0x70]
00007e4ecaddec98  vmovaps xmm8, [rsp+0x80]
00007e4ecaddeca1  vmovaps xmm9, [rsp+0x90]
00007e4ecaddecaa  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddecb3  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddecbc  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddecc5  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddecce  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddecd7  add rsp, 0xF0
00007e4ecaddecde  pop r11
00007e4ecaddece0  pop r10
00007e4ecaddece2  pop r9
00007e4ecaddece4  pop r8
00007e4ecaddece6  pop rsi
00007e4ecaddece7  pop rdi
00007e4ecaddece8  pop rdx
00007e4ecaddece9  pop rcx
00007e4ecaddecea  pop rax
00007e4ecaddeceb  add rsp, 0x08
00007e4ecaddecef  jmp 0x00007E4ECADDC2D0
00007e4ecaddecf4  sub rsp, 0x08
00007e4ecaddecf8  push rax
00007e4ecaddecf9  push rcx
00007e4ecaddecfa  push rdx
00007e4ecaddecfb  push rdi
00007e4ecaddecfc  push rsi
00007e4ecaddecfd  push r8
00007e4ecaddecff  push r9
00007e4ecadded01  push r10
00007e4ecadded03  push r11
00007e4ecadded05  sub rsp, 0xF0
00007e4ecadded0c  vmovaps [rsp], xmm0
00007e4ecadded11  vmovaps [rsp+0x10], xmm2
00007e4ecadded17  vmovaps [rsp+0x20], xmm3
00007e4ecadded1d  vmovaps [rsp+0x30], xmm4
00007e4ecadded23  vmovaps [rsp+0x40], xmm5
00007e4ecadded29  vmovaps [rsp+0x50], xmm6
00007e4ecadded2f  vmovaps [rsp+0x60], xmm7
00007e4ecadded35  vmovaps [rsp+0x70], xmm8
00007e4ecadded3b  vmovaps [rsp+0x80], xmm9
00007e4ecadded44  vmovaps [rsp+0x90], xmm10
00007e4ecadded4d  vmovaps [rsp+0xA0], xmm11
00007e4ecadded56  vmovaps [rsp+0xB0], xmm12
00007e4ecadded5f  vmovaps [rsp+0xC0], xmm13
00007e4ecadded68  vmovaps [rsp+0xD0], xmm14
00007e4ecadded71  vmovaps [rsp+0xE0], xmm15
00007e4ecadded7a  sub rsp, 0x30
00007e4ecadded7e  movaps [rsp], xmm1
00007e4ecadded82  movaps [rsp+0x10], xmm4
00007e4ecadded87  movaps [rsp+0x20], xmm9
00007e4ecadded8d  lea rdi, [rsp]
00007e4ecadded91  mov esi, 0x00
00007e4ecadded96  mov rax, 0x5784BC1F5530
00007e4ecaddeda0  call rax
00007e4ecaddeda2  movaps xmm1, [rsp]
00007e4ecaddeda6  add rsp, 0x30
00007e4ecaddedaa  vmovaps xmm0, [rsp]
00007e4ecaddedaf  vmovaps xmm2, [rsp+0x10]
00007e4ecaddedb5  vmovaps xmm3, [rsp+0x20]
00007e4ecaddedbb  vmovaps xmm4, [rsp+0x30]
00007e4ecaddedc1  vmovaps xmm5, [rsp+0x40]
00007e4ecaddedc7  vmovaps xmm6, [rsp+0x50]
00007e4ecaddedcd  vmovaps xmm7, [rsp+0x60]
00007e4ecaddedd3  vmovaps xmm8, [rsp+0x70]
00007e4ecaddedd9  vmovaps xmm9, [rsp+0x80]
00007e4ecaddede2  vmovaps xmm10, [rsp+0x90]
00007e4ecaddedeb  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddedf4  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddedfd  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddee06  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddee0f  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddee18  add rsp, 0xF0
00007e4ecaddee1f  pop r11
00007e4ecaddee21  pop r10
00007e4ecaddee23  pop r9
00007e4ecaddee25  pop r8
00007e4ecaddee27  pop rsi
00007e4ecaddee28  pop rdi
00007e4ecaddee29  pop rdx
00007e4ecaddee2a  pop rcx
00007e4ecaddee2b  pop rax
00007e4ecaddee2c  add rsp, 0x08
00007e4ecaddee30  jmp 0x00007E4ECADDC2EE
00007e4ecaddee35  sub rsp, 0x08
00007e4ecaddee39  push rax
00007e4ecaddee3a  push rcx
00007e4ecaddee3b  push rdx
00007e4ecaddee3c  push rdi
00007e4ecaddee3d  push rsi
00007e4ecaddee3e  push r8
00007e4ecaddee40  push r9
00007e4ecaddee42  push r10
00007e4ecaddee44  push r11
00007e4ecaddee46  sub rsp, 0xF0
00007e4ecaddee4d  vmovaps [rsp], xmm0
00007e4ecaddee52  vmovaps [rsp+0x10], xmm1
00007e4ecaddee58  vmovaps [rsp+0x20], xmm2
00007e4ecaddee5e  vmovaps [rsp+0x30], xmm3
00007e4ecaddee64  vmovaps [rsp+0x40], xmm5
00007e4ecaddee6a  vmovaps [rsp+0x50], xmm6
00007e4ecaddee70  vmovaps [rsp+0x60], xmm7
00007e4ecaddee76  vmovaps [rsp+0x70], xmm8
00007e4ecaddee7c  vmovaps [rsp+0x80], xmm9
00007e4ecaddee85  vmovaps [rsp+0x90], xmm10
00007e4ecaddee8e  vmovaps [rsp+0xA0], xmm11
00007e4ecaddee97  vmovaps [rsp+0xB0], xmm12
00007e4ecaddeea0  vmovaps [rsp+0xC0], xmm13
00007e4ecaddeea9  vmovaps [rsp+0xD0], xmm14
00007e4ecaddeeb2  vmovaps [rsp+0xE0], xmm15
00007e4ecaddeebb  sub rsp, 0x30
00007e4ecaddeebf  movaps [rsp], xmm4
00007e4ecaddeec3  movaps [rsp+0x10], xmm2
00007e4ecaddeec8  movaps [rsp+0x20], xmm9
00007e4ecaddeece  lea rdi, [rsp]
00007e4ecaddeed2  mov esi, 0x00
00007e4ecaddeed7  mov rax, 0x5784BC1F5530
00007e4ecaddeee1  call rax
00007e4ecaddeee3  movaps xmm4, [rsp]
00007e4ecaddeee7  add rsp, 0x30
00007e4ecaddeeeb  vmovaps xmm0, [rsp]
00007e4ecaddeef0  vmovaps xmm1, [rsp+0x10]
00007e4ecaddeef6  vmovaps xmm2, [rsp+0x20]
00007e4ecaddeefc  vmovaps xmm3, [rsp+0x30]
00007e4ecaddef02  vmovaps xmm5, [rsp+0x40]
00007e4ecaddef08  vmovaps xmm6, [rsp+0x50]
00007e4ecaddef0e  vmovaps xmm7, [rsp+0x60]
00007e4ecaddef14  vmovaps xmm8, [rsp+0x70]
00007e4ecaddef1a  vmovaps xmm9, [rsp+0x80]
00007e4ecaddef23  vmovaps xmm10, [rsp+0x90]
00007e4ecaddef2c  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddef35  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddef3e  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddef47  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddef50  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddef59  add rsp, 0xF0
00007e4ecaddef60  pop r11
00007e4ecaddef62  pop r10
00007e4ecaddef64  pop r9
00007e4ecaddef66  pop r8
00007e4ecaddef68  pop rsi
00007e4ecaddef69  pop rdi
00007e4ecaddef6a  pop rdx
00007e4ecaddef6b  pop rcx
00007e4ecaddef6c  pop rax
00007e4ecaddef6d  add rsp, 0x08
00007e4ecaddef71  jmp 0x00007E4ECADDC31E
00007e4ecaddef76  sub rsp, 0x08
00007e4ecaddef7a  push rax
00007e4ecaddef7b  push rcx
00007e4ecaddef7c  push rdx
00007e4ecaddef7d  push rdi
00007e4ecaddef7e  push rsi
00007e4ecaddef7f  push r8
00007e4ecaddef81  push r9
00007e4ecaddef83  push r10
00007e4ecaddef85  push r11
00007e4ecaddef87  sub rsp, 0xF0
00007e4ecaddef8e  vmovaps [rsp], xmm0
00007e4ecaddef93  vmovaps [rsp+0x10], xmm1
00007e4ecaddef99  vmovaps [rsp+0x20], xmm2
00007e4ecaddef9f  vmovaps [rsp+0x30], xmm3
00007e4ecaddefa5  vmovaps [rsp+0x40], xmm4
00007e4ecaddefab  vmovaps [rsp+0x50], xmm5
00007e4ecaddefb1  vmovaps [rsp+0x60], xmm6
00007e4ecaddefb7  vmovaps [rsp+0x70], xmm7
00007e4ecaddefbd  vmovaps [rsp+0x80], xmm8
00007e4ecaddefc6  vmovaps [rsp+0x90], xmm10
00007e4ecaddefcf  vmovaps [rsp+0xA0], xmm11
00007e4ecaddefd8  vmovaps [rsp+0xB0], xmm12
00007e4ecaddefe1  vmovaps [rsp+0xC0], xmm13
00007e4ecaddefea  vmovaps [rsp+0xD0], xmm14
00007e4ecaddeff3  vmovaps [rsp+0xE0], xmm15
00007e4ecaddeffc  sub rsp, 0x30
00007e4ecaddf000  movaps [rsp], xmm9
00007e4ecaddf005  movaps [rsp+0x10], xmm2
00007e4ecaddf00a  movaps [rsp+0x20], xmm1
00007e4ecaddf00f  lea rdi, [rsp]
00007e4ecaddf013  mov esi, 0x00
00007e4ecaddf018  mov rax, 0x5784BC1F5530
00007e4ecaddf022  call rax
00007e4ecaddf024  movaps xmm9, [rsp]
00007e4ecaddf029  add rsp, 0x30
00007e4ecaddf02d  vmovaps xmm0, [rsp]
00007e4ecaddf032  vmovaps xmm1, [rsp+0x10]
00007e4ecaddf038  vmovaps xmm2, [rsp+0x20]
00007e4ecaddf03e  vmovaps xmm3, [rsp+0x30]
00007e4ecaddf044  vmovaps xmm4, [rsp+0x40]
00007e4ecaddf04a  vmovaps xmm5, [rsp+0x50]
00007e4ecaddf050  vmovaps xmm6, [rsp+0x60]
00007e4ecaddf056  vmovaps xmm7, [rsp+0x70]
00007e4ecaddf05c  vmovaps xmm8, [rsp+0x80]
00007e4ecaddf065  vmovaps xmm10, [rsp+0x90]
00007e4ecaddf06e  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddf077  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddf080  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddf089  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddf092  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddf09b  add rsp, 0xF0
00007e4ecaddf0a2  pop r11
00007e4ecaddf0a4  pop r10
00007e4ecaddf0a6  pop r9
00007e4ecaddf0a8  pop r8
00007e4ecaddf0aa  pop rsi
00007e4ecaddf0ab  pop rdi
00007e4ecaddf0ac  pop rdx
00007e4ecaddf0ad  pop rcx
00007e4ecaddf0ae  pop rax
00007e4ecaddf0af  add rsp, 0x08
00007e4ecaddf0b3  jmp 0x00007E4ECADDC354
00007e4ecaddf0b8  sub rsp, 0x08
00007e4ecaddf0bc  push rax
00007e4ecaddf0bd  push rcx
00007e4ecaddf0be  push rdx
00007e4ecaddf0bf  push rdi
00007e4ecaddf0c0  push rsi
00007e4ecaddf0c1  push r8
00007e4ecaddf0c3  push r9
00007e4ecaddf0c5  push r10
00007e4ecaddf0c7  push r11
00007e4ecaddf0c9  sub rsp, 0xF0
00007e4ecaddf0d0  vmovaps [rsp], xmm0
00007e4ecaddf0d5  vmovaps [rsp+0x10], xmm2
00007e4ecaddf0db  vmovaps [rsp+0x20], xmm3
00007e4ecaddf0e1  vmovaps [rsp+0x30], xmm4
00007e4ecaddf0e7  vmovaps [rsp+0x40], xmm5
00007e4ecaddf0ed  vmovaps [rsp+0x50], xmm6
00007e4ecaddf0f3  vmovaps [rsp+0x60], xmm7
00007e4ecaddf0f9  vmovaps [rsp+0x70], xmm8
00007e4ecaddf0ff  vmovaps [rsp+0x80], xmm9
00007e4ecaddf108  vmovaps [rsp+0x90], xmm10
00007e4ecaddf111  vmovaps [rsp+0xA0], xmm11
00007e4ecaddf11a  vmovaps [rsp+0xB0], xmm12
00007e4ecaddf123  vmovaps [rsp+0xC0], xmm13
00007e4ecaddf12c  vmovaps [rsp+0xD0], xmm14
00007e4ecaddf135  vmovaps [rsp+0xE0], xmm15
00007e4ecaddf13e  sub rsp, 0x30
00007e4ecaddf142  movaps [rsp], xmm1
00007e4ecaddf146  movaps [rsp+0x10], xmm15
00007e4ecaddf14c  movaps [rsp+0x20], xmm6
00007e4ecaddf151  lea rdi, [rsp]
00007e4ecaddf155  mov esi, 0x00
00007e4ecaddf15a  mov rax, 0x5784BC1F5530
00007e4ecaddf164  call rax
00007e4ecaddf166  movaps xmm1, [rsp]
00007e4ecaddf16a  add rsp, 0x30
00007e4ecaddf16e  vmovaps xmm0, [rsp]
00007e4ecaddf173  vmovaps xmm2, [rsp+0x10]
00007e4ecaddf179  vmovaps xmm3, [rsp+0x20]
00007e4ecaddf17f  vmovaps xmm4, [rsp+0x30]
00007e4ecaddf185  vmovaps xmm5, [rsp+0x40]
00007e4ecaddf18b  vmovaps xmm6, [rsp+0x50]
00007e4ecaddf191  vmovaps xmm7, [rsp+0x60]
00007e4ecaddf197  vmovaps xmm8, [rsp+0x70]
00007e4ecaddf19d  vmovaps xmm9, [rsp+0x80]
00007e4ecaddf1a6  vmovaps xmm10, [rsp+0x90]
00007e4ecaddf1af  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddf1b8  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddf1c1  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddf1ca  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddf1d3  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddf1dc  add rsp, 0xF0
00007e4ecaddf1e3  pop r11
00007e4ecaddf1e5  pop r10
00007e4ecaddf1e7  pop r9
00007e4ecaddf1e9  pop r8
00007e4ecaddf1eb  pop rsi
00007e4ecaddf1ec  pop rdi
00007e4ecaddf1ed  pop rdx
00007e4ecaddf1ee  pop rcx
00007e4ecaddf1ef  pop rax
00007e4ecaddf1f0  add rsp, 0x08
00007e4ecaddf1f4  jmp 0x00007E4ECADDC375
00007e4ecaddf1f9  sub rsp, 0x08
00007e4ecaddf1fd  push rax
00007e4ecaddf1fe  push rcx
00007e4ecaddf1ff  push rdx
00007e4ecaddf200  push rdi
00007e4ecaddf201  push rsi
00007e4ecaddf202  push r8
00007e4ecaddf204  push r9
00007e4ecaddf206  push r10
00007e4ecaddf208  push r11
00007e4ecaddf20a  sub rsp, 0xF0
00007e4ecaddf211  vmovaps [rsp], xmm0
00007e4ecaddf216  vmovaps [rsp+0x10], xmm1
00007e4ecaddf21c  vmovaps [rsp+0x20], xmm2
00007e4ecaddf222  vmovaps [rsp+0x30], xmm3
00007e4ecaddf228  vmovaps [rsp+0x40], xmm4
00007e4ecaddf22e  vmovaps [rsp+0x50], xmm5
00007e4ecaddf234  vmovaps [rsp+0x60], xmm6
00007e4ecaddf23a  vmovaps [rsp+0x70], xmm7
00007e4ecaddf240  vmovaps [rsp+0x80], xmm8
00007e4ecaddf249  vmovaps [rsp+0x90], xmm9
00007e4ecaddf252  vmovaps [rsp+0xA0], xmm10
00007e4ecaddf25b  vmovaps [rsp+0xB0], xmm11
00007e4ecaddf264  vmovaps [rsp+0xC0], xmm12
00007e4ecaddf26d  vmovaps [rsp+0xD0], xmm13
00007e4ecaddf276  vmovaps [rsp+0xE0], xmm14
00007e4ecaddf27f  sub rsp, 0x30
00007e4ecaddf283  movaps [rsp], xmm15
00007e4ecaddf288  movaps [rsp+0x10], xmm5
00007e4ecaddf28d  movaps [rsp+0x20], xmm3
00007e4ecaddf292  lea rdi, [rsp]
00007e4ecaddf296  mov esi, 0x00
00007e4ecaddf29b  mov rax, 0x5784BC1F5530
00007e4ecaddf2a5  call rax
00007e4ecaddf2a7  movaps xmm15, [rsp]
00007e4ecaddf2ac  add rsp, 0x30
00007e4ecaddf2b0  vmovaps xmm0, [rsp]
00007e4ecaddf2b5  vmovaps xmm1, [rsp+0x10]
00007e4ecaddf2bb  vmovaps xmm2, [rsp+0x20]
00007e4ecaddf2c1  vmovaps xmm3, [rsp+0x30]
00007e4ecaddf2c7  vmovaps xmm4, [rsp+0x40]
00007e4ecaddf2cd  vmovaps xmm5, [rsp+0x50]
00007e4ecaddf2d3  vmovaps xmm6, [rsp+0x60]
00007e4ecaddf2d9  vmovaps xmm7, [rsp+0x70]
00007e4ecaddf2df  vmovaps xmm8, [rsp+0x80]
00007e4ecaddf2e8  vmovaps xmm9, [rsp+0x90]
00007e4ecaddf2f1  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddf2fa  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddf303  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddf30c  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddf315  vmovaps xmm14, [rsp+0xE0]
00007e4ecaddf31e  add rsp, 0xF0
00007e4ecaddf325  pop r11
00007e4ecaddf327  pop r10
00007e4ecaddf329  pop r9
00007e4ecaddf32b  pop r8
00007e4ecaddf32d  pop rsi
00007e4ecaddf32e  pop rdi
00007e4ecaddf32f  pop rdx
00007e4ecaddf330  pop rcx
00007e4ecaddf331  pop rax
00007e4ecaddf332  add rsp, 0x08
00007e4ecaddf336  jmp 0x00007E4ECADDC38F
00007e4ecaddf33b  sub rsp, 0x08
00007e4ecaddf33f  push rax
00007e4ecaddf340  push rcx
00007e4ecaddf341  push rdx
00007e4ecaddf342  push rdi
00007e4ecaddf343  push rsi
00007e4ecaddf344  push r8
00007e4ecaddf346  push r9
00007e4ecaddf348  push r10
00007e4ecaddf34a  push r11
00007e4ecaddf34c  sub rsp, 0xF0
00007e4ecaddf353  vmovaps [rsp], xmm0
00007e4ecaddf358  vmovaps [rsp+0x10], xmm1
00007e4ecaddf35e  vmovaps [rsp+0x20], xmm2
00007e4ecaddf364  vmovaps [rsp+0x30], xmm3
00007e4ecaddf36a  vmovaps [rsp+0x40], xmm4
00007e4ecaddf370  vmovaps [rsp+0x50], xmm6
00007e4ecaddf376  vmovaps [rsp+0x60], xmm7
00007e4ecaddf37c  vmovaps [rsp+0x70], xmm8
00007e4ecaddf382  vmovaps [rsp+0x80], xmm9
00007e4ecaddf38b  vmovaps [rsp+0x90], xmm10
00007e4ecaddf394  vmovaps [rsp+0xA0], xmm11
00007e4ecaddf39d  vmovaps [rsp+0xB0], xmm12
00007e4ecaddf3a6  vmovaps [rsp+0xC0], xmm13
00007e4ecaddf3af  vmovaps [rsp+0xD0], xmm14
00007e4ecaddf3b8  vmovaps [rsp+0xE0], xmm15
00007e4ecaddf3c1  sub rsp, 0x30
00007e4ecaddf3c5  movaps [rsp], xmm5
00007e4ecaddf3c9  movaps [rsp+0x10], xmm8
00007e4ecaddf3cf  movaps [rsp+0x20], xmm6
00007e4ecaddf3d4  lea rdi, [rsp]
00007e4ecaddf3d8  mov esi, 0x00
00007e4ecaddf3dd  mov rax, 0x5784BC1F5530
00007e4ecaddf3e7  call rax
00007e4ecaddf3e9  movaps xmm5, [rsp]
00007e4ecaddf3ed  add rsp, 0x30
00007e4ecaddf3f1  vmovaps xmm0, [rsp]
00007e4ecaddf3f6  vmovaps xmm1, [rsp+0x10]
00007e4ecaddf3fc  vmovaps xmm2, [rsp+0x20]
00007e4ecaddf402  vmovaps xmm3, [rsp+0x30]
00007e4ecaddf408  vmovaps xmm4, [rsp+0x40]
00007e4ecaddf40e  vmovaps xmm6, [rsp+0x50]
00007e4ecaddf414  vmovaps xmm7, [rsp+0x60]
00007e4ecaddf41a  vmovaps xmm8, [rsp+0x70]
00007e4ecaddf420  vmovaps xmm9, [rsp+0x80]
00007e4ecaddf429  vmovaps xmm10, [rsp+0x90]
00007e4ecaddf432  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddf43b  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddf444  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddf44d  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddf456  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddf45f  add rsp, 0xF0
00007e4ecaddf466  pop r11
00007e4ecaddf468  pop r10
00007e4ecaddf46a  pop r9
00007e4ecaddf46c  pop r8
00007e4ecaddf46e  pop rsi
00007e4ecaddf46f  pop rdi
00007e4ecaddf470  pop rdx
00007e4ecaddf471  pop rcx
00007e4ecaddf472  pop rax
00007e4ecaddf473  add rsp, 0x08
00007e4ecaddf477  jmp 0x00007E4ECADDC3B3
00007e4ecaddf47c  sub rsp, 0x08
00007e4ecaddf480  push rax
00007e4ecaddf481  push rcx
00007e4ecaddf482  push rdx
00007e4ecaddf483  push rdi
00007e4ecaddf484  push rsi
00007e4ecaddf485  push r8
00007e4ecaddf487  push r9
00007e4ecaddf489  push r10
00007e4ecaddf48b  push r11
00007e4ecaddf48d  sub rsp, 0xF0
00007e4ecaddf494  vmovaps [rsp], xmm0
00007e4ecaddf499  vmovaps [rsp+0x10], xmm1
00007e4ecaddf49f  vmovaps [rsp+0x20], xmm2
00007e4ecaddf4a5  vmovaps [rsp+0x30], xmm3
00007e4ecaddf4ab  vmovaps [rsp+0x40], xmm4
00007e4ecaddf4b1  vmovaps [rsp+0x50], xmm5
00007e4ecaddf4b7  vmovaps [rsp+0x60], xmm7
00007e4ecaddf4bd  vmovaps [rsp+0x70], xmm8
00007e4ecaddf4c3  vmovaps [rsp+0x80], xmm9
00007e4ecaddf4cc  vmovaps [rsp+0x90], xmm10
00007e4ecaddf4d5  vmovaps [rsp+0xA0], xmm11
00007e4ecaddf4de  vmovaps [rsp+0xB0], xmm12
00007e4ecaddf4e7  vmovaps [rsp+0xC0], xmm13
00007e4ecaddf4f0  vmovaps [rsp+0xD0], xmm14
00007e4ecaddf4f9  vmovaps [rsp+0xE0], xmm15
00007e4ecaddf502  sub rsp, 0x30
00007e4ecaddf506  movaps [rsp], xmm6
00007e4ecaddf50a  movaps [rsp+0x10], xmm10
00007e4ecaddf510  movaps [rsp+0x20], xmm8
00007e4ecaddf516  lea rdi, [rsp]
00007e4ecaddf51a  mov esi, 0x00
00007e4ecaddf51f  mov rax, 0x5784BC1F5530
00007e4ecaddf529  call rax
00007e4ecaddf52b  movaps xmm6, [rsp]
00007e4ecaddf52f  add rsp, 0x30
00007e4ecaddf533  vmovaps xmm0, [rsp]
00007e4ecaddf538  vmovaps xmm1, [rsp+0x10]
00007e4ecaddf53e  vmovaps xmm2, [rsp+0x20]
00007e4ecaddf544  vmovaps xmm3, [rsp+0x30]
00007e4ecaddf54a  vmovaps xmm4, [rsp+0x40]
00007e4ecaddf550  vmovaps xmm5, [rsp+0x50]
00007e4ecaddf556  vmovaps xmm7, [rsp+0x60]
00007e4ecaddf55c  vmovaps xmm8, [rsp+0x70]
00007e4ecaddf562  vmovaps xmm9, [rsp+0x80]
00007e4ecaddf56b  vmovaps xmm10, [rsp+0x90]
00007e4ecaddf574  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddf57d  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddf586  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddf58f  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddf598  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddf5a1  add rsp, 0xF0
00007e4ecaddf5a8  pop r11
00007e4ecaddf5aa  pop r10
00007e4ecaddf5ac  pop r9
00007e4ecaddf5ae  pop r8
00007e4ecaddf5b0  pop rsi
00007e4ecaddf5b1  pop rdi
00007e4ecaddf5b2  pop rdx
00007e4ecaddf5b3  pop rcx
00007e4ecaddf5b4  pop rax
00007e4ecaddf5b5  add rsp, 0x08
00007e4ecaddf5b9  jmp 0x00007E4ECADDC3D8
00007e4ecaddf5be  sub rsp, 0x08
00007e4ecaddf5c2  push rax
00007e4ecaddf5c3  push rcx
00007e4ecaddf5c4  push rdx
00007e4ecaddf5c5  push rdi
00007e4ecaddf5c6  push rsi
00007e4ecaddf5c7  push r8
00007e4ecaddf5c9  push r9
00007e4ecaddf5cb  push r10
00007e4ecaddf5cd  push r11
00007e4ecaddf5cf  sub rsp, 0xF0
00007e4ecaddf5d6  vmovaps [rsp], xmm0
00007e4ecaddf5db  vmovaps [rsp+0x10], xmm1
00007e4ecaddf5e1  vmovaps [rsp+0x20], xmm2
00007e4ecaddf5e7  vmovaps [rsp+0x30], xmm3
00007e4ecaddf5ed  vmovaps [rsp+0x40], xmm4
00007e4ecaddf5f3  vmovaps [rsp+0x50], xmm5
00007e4ecaddf5f9  vmovaps [rsp+0x60], xmm6
00007e4ecaddf5ff  vmovaps [rsp+0x70], xmm7
00007e4ecaddf605  vmovaps [rsp+0x80], xmm8
00007e4ecaddf60e  vmovaps [rsp+0x90], xmm9
00007e4ecaddf617  vmovaps [rsp+0xA0], xmm11
00007e4ecaddf620  vmovaps [rsp+0xB0], xmm12
00007e4ecaddf629  vmovaps [rsp+0xC0], xmm13
00007e4ecaddf632  vmovaps [rsp+0xD0], xmm14
00007e4ecaddf63b  vmovaps [rsp+0xE0], xmm15
00007e4ecaddf644  sub rsp, 0x30
00007e4ecaddf648  movaps [rsp], xmm10
00007e4ecaddf64d  movaps [rsp+0x10], xmm8
00007e4ecaddf653  movaps [rsp+0x20], xmm14
00007e4ecaddf659  lea rdi, [rsp]
00007e4ecaddf65d  mov esi, 0x00
00007e4ecaddf662  mov rax, 0x5784BC1F5530
00007e4ecaddf66c  call rax
00007e4ecaddf66e  movaps xmm10, [rsp]
00007e4ecaddf673  add rsp, 0x30
00007e4ecaddf677  vmovaps xmm0, [rsp]
00007e4ecaddf67c  vmovaps xmm1, [rsp+0x10]
00007e4ecaddf682  vmovaps xmm2, [rsp+0x20]
00007e4ecaddf688  vmovaps xmm3, [rsp+0x30]
00007e4ecaddf68e  vmovaps xmm4, [rsp+0x40]
00007e4ecaddf694  vmovaps xmm5, [rsp+0x50]
00007e4ecaddf69a  vmovaps xmm6, [rsp+0x60]
00007e4ecaddf6a0  vmovaps xmm7, [rsp+0x70]
00007e4ecaddf6a6  vmovaps xmm8, [rsp+0x80]
00007e4ecaddf6af  vmovaps xmm9, [rsp+0x90]
00007e4ecaddf6b8  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddf6c1  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddf6ca  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddf6d3  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddf6dc  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddf6e5  add rsp, 0xF0
00007e4ecaddf6ec  pop r11
00007e4ecaddf6ee  pop r10
00007e4ecaddf6f0  pop r9
00007e4ecaddf6f2  pop r8
00007e4ecaddf6f4  pop rsi
00007e4ecaddf6f5  pop rdi
00007e4ecaddf6f6  pop rdx
00007e4ecaddf6f7  pop rcx
00007e4ecaddf6f8  pop rax
00007e4ecaddf6f9  add rsp, 0x08
00007e4ecaddf6fd  jmp 0x00007E4ECADDC3F8
00007e4ecaddf702  sub rsp, 0x08
00007e4ecaddf706  push rax
00007e4ecaddf707  push rcx
00007e4ecaddf708  push rdx
00007e4ecaddf709  push rdi
00007e4ecaddf70a  push rsi
00007e4ecaddf70b  push r8
00007e4ecaddf70d  push r9
00007e4ecaddf70f  push r10
00007e4ecaddf711  push r11
00007e4ecaddf713  sub rsp, 0xF0
00007e4ecaddf71a  vmovaps [rsp], xmm0
00007e4ecaddf71f  vmovaps [rsp+0x10], xmm1
00007e4ecaddf725  vmovaps [rsp+0x20], xmm2
00007e4ecaddf72b  vmovaps [rsp+0x30], xmm3
00007e4ecaddf731  vmovaps [rsp+0x40], xmm4
00007e4ecaddf737  vmovaps [rsp+0x50], xmm5
00007e4ecaddf73d  vmovaps [rsp+0x60], xmm6
00007e4ecaddf743  vmovaps [rsp+0x70], xmm7
00007e4ecaddf749  vmovaps [rsp+0x80], xmm8
00007e4ecaddf752  vmovaps [rsp+0x90], xmm9
00007e4ecaddf75b  vmovaps [rsp+0xA0], xmm10
00007e4ecaddf764  vmovaps [rsp+0xB0], xmm11
00007e4ecaddf76d  vmovaps [rsp+0xC0], xmm12
00007e4ecaddf776  vmovaps [rsp+0xD0], xmm13
00007e4ecaddf77f  vmovaps [rsp+0xE0], xmm15
00007e4ecaddf788  sub rsp, 0x30
00007e4ecaddf78c  movaps [rsp], xmm14
00007e4ecaddf791  movaps [rsp+0x10], xmm8
00007e4ecaddf797  movaps [rsp+0x20], xmm4
00007e4ecaddf79c  lea rdi, [rsp]
00007e4ecaddf7a0  mov esi, 0x00
00007e4ecaddf7a5  mov rax, 0x5784BC1F5530
00007e4ecaddf7af  call rax
00007e4ecaddf7b1  movaps xmm14, [rsp]
00007e4ecaddf7b6  add rsp, 0x30
00007e4ecaddf7ba  vmovaps xmm0, [rsp]
00007e4ecaddf7bf  vmovaps xmm1, [rsp+0x10]
00007e4ecaddf7c5  vmovaps xmm2, [rsp+0x20]
00007e4ecaddf7cb  vmovaps xmm3, [rsp+0x30]
00007e4ecaddf7d1  vmovaps xmm4, [rsp+0x40]
00007e4ecaddf7d7  vmovaps xmm5, [rsp+0x50]
00007e4ecaddf7dd  vmovaps xmm6, [rsp+0x60]
00007e4ecaddf7e3  vmovaps xmm7, [rsp+0x70]
00007e4ecaddf7e9  vmovaps xmm8, [rsp+0x80]
00007e4ecaddf7f2  vmovaps xmm9, [rsp+0x90]
00007e4ecaddf7fb  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddf804  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddf80d  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddf816  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddf81f  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddf828  add rsp, 0xF0
00007e4ecaddf82f  pop r11
00007e4ecaddf831  pop r10
00007e4ecaddf833  pop r9
00007e4ecaddf835  pop r8
00007e4ecaddf837  pop rsi
00007e4ecaddf838  pop rdi
00007e4ecaddf839  pop rdx
00007e4ecaddf83a  pop rcx
00007e4ecaddf83b  pop rax
00007e4ecaddf83c  add rsp, 0x08
00007e4ecaddf840  jmp 0x00007E4ECADDC418
00007e4ecaddf845  sub rsp, 0x08
00007e4ecaddf849  push rax
00007e4ecaddf84a  push rcx
00007e4ecaddf84b  push rdx
00007e4ecaddf84c  push rdi
00007e4ecaddf84d  push rsi
00007e4ecaddf84e  push r8
00007e4ecaddf850  push r9
00007e4ecaddf852  push r10
00007e4ecaddf854  push r11
00007e4ecaddf856  sub rsp, 0xF0
00007e4ecaddf85d  vmovaps [rsp], xmm0
00007e4ecaddf862  vmovaps [rsp+0x10], xmm1
00007e4ecaddf868  vmovaps [rsp+0x20], xmm2
00007e4ecaddf86e  vmovaps [rsp+0x30], xmm3
00007e4ecaddf874  vmovaps [rsp+0x40], xmm5
00007e4ecaddf87a  vmovaps [rsp+0x50], xmm6
00007e4ecaddf880  vmovaps [rsp+0x60], xmm7
00007e4ecaddf886  vmovaps [rsp+0x70], xmm8
00007e4ecaddf88c  vmovaps [rsp+0x80], xmm9
00007e4ecaddf895  vmovaps [rsp+0x90], xmm10
00007e4ecaddf89e  vmovaps [rsp+0xA0], xmm11
00007e4ecaddf8a7  vmovaps [rsp+0xB0], xmm12
00007e4ecaddf8b0  vmovaps [rsp+0xC0], xmm13
00007e4ecaddf8b9  vmovaps [rsp+0xD0], xmm14
00007e4ecaddf8c2  vmovaps [rsp+0xE0], xmm15
00007e4ecaddf8cb  sub rsp, 0x30
00007e4ecaddf8cf  movaps [rsp], xmm4
00007e4ecaddf8d3  movaps [rsp+0x10], xmm13
00007e4ecaddf8d9  movaps [rsp+0x20], xmm8
00007e4ecaddf8df  lea rdi, [rsp]
00007e4ecaddf8e3  mov esi, 0x00
00007e4ecaddf8e8  mov rax, 0x5784BC1F5530
00007e4ecaddf8f2  call rax
00007e4ecaddf8f4  movaps xmm4, [rsp]
00007e4ecaddf8f8  add rsp, 0x30
00007e4ecaddf8fc  vmovaps xmm0, [rsp]
00007e4ecaddf901  vmovaps xmm1, [rsp+0x10]
00007e4ecaddf907  vmovaps xmm2, [rsp+0x20]
00007e4ecaddf90d  vmovaps xmm3, [rsp+0x30]
00007e4ecaddf913  vmovaps xmm5, [rsp+0x40]
00007e4ecaddf919  vmovaps xmm6, [rsp+0x50]
00007e4ecaddf91f  vmovaps xmm7, [rsp+0x60]
00007e4ecaddf925  vmovaps xmm8, [rsp+0x70]
00007e4ecaddf92b  vmovaps xmm9, [rsp+0x80]
00007e4ecaddf934  vmovaps xmm10, [rsp+0x90]
00007e4ecaddf93d  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddf946  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddf94f  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddf958  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddf961  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddf96a  add rsp, 0xF0
00007e4ecaddf971  pop r11
00007e4ecaddf973  pop r10
00007e4ecaddf975  pop r9
00007e4ecaddf977  pop r8
00007e4ecaddf979  pop rsi
00007e4ecaddf97a  pop rdi
00007e4ecaddf97b  pop rdx
00007e4ecaddf97c  pop rcx
00007e4ecaddf97d  pop rax
00007e4ecaddf97e  add rsp, 0x08
00007e4ecaddf982  jmp 0x00007E4ECADDC43D
00007e4ecaddf987  sub rsp, 0x08
00007e4ecaddf98b  push rax
00007e4ecaddf98c  push rcx
00007e4ecaddf98d  push rdx
00007e4ecaddf98e  push rdi
00007e4ecaddf98f  push rsi
00007e4ecaddf990  push r8
00007e4ecaddf992  push r9
00007e4ecaddf994  push r10
00007e4ecaddf996  push r11
00007e4ecaddf998  sub rsp, 0xF0
00007e4ecaddf99f  vmovaps [rsp], xmm0
00007e4ecaddf9a4  vmovaps [rsp+0x10], xmm1
00007e4ecaddf9aa  vmovaps [rsp+0x20], xmm2
00007e4ecaddf9b0  vmovaps [rsp+0x30], xmm3
00007e4ecaddf9b6  vmovaps [rsp+0x40], xmm4
00007e4ecaddf9bc  vmovaps [rsp+0x50], xmm5
00007e4ecaddf9c2  vmovaps [rsp+0x60], xmm6
00007e4ecaddf9c8  vmovaps [rsp+0x70], xmm7
00007e4ecaddf9ce  vmovaps [rsp+0x80], xmm8
00007e4ecaddf9d7  vmovaps [rsp+0x90], xmm9
00007e4ecaddf9e0  vmovaps [rsp+0xA0], xmm10
00007e4ecaddf9e9  vmovaps [rsp+0xB0], xmm11
00007e4ecaddf9f2  vmovaps [rsp+0xC0], xmm12
00007e4ecaddf9fb  vmovaps [rsp+0xD0], xmm14
00007e4ecaddfa04  vmovaps [rsp+0xE0], xmm15
00007e4ecaddfa0d  sub rsp, 0x30
00007e4ecaddfa11  movaps [rsp], xmm13
00007e4ecaddfa16  movaps [rsp+0x10], xmm15
00007e4ecaddfa1c  movaps [rsp+0x20], xmm9
00007e4ecaddfa22  lea rdi, [rsp]
00007e4ecaddfa26  mov esi, 0x00
00007e4ecaddfa2b  mov rax, 0x5784BC1F5530
00007e4ecaddfa35  call rax
00007e4ecaddfa37  movaps xmm13, [rsp]
00007e4ecaddfa3c  add rsp, 0x30
00007e4ecaddfa40  vmovaps xmm0, [rsp]
00007e4ecaddfa45  vmovaps xmm1, [rsp+0x10]
00007e4ecaddfa4b  vmovaps xmm2, [rsp+0x20]
00007e4ecaddfa51  vmovaps xmm3, [rsp+0x30]
00007e4ecaddfa57  vmovaps xmm4, [rsp+0x40]
00007e4ecaddfa5d  vmovaps xmm5, [rsp+0x50]
00007e4ecaddfa63  vmovaps xmm6, [rsp+0x60]
00007e4ecaddfa69  vmovaps xmm7, [rsp+0x70]
00007e4ecaddfa6f  vmovaps xmm8, [rsp+0x80]
00007e4ecaddfa78  vmovaps xmm9, [rsp+0x90]
00007e4ecaddfa81  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddfa8a  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddfa93  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddfa9c  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddfaa5  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddfaae  add rsp, 0xF0
00007e4ecaddfab5  pop r11
00007e4ecaddfab7  pop r10
00007e4ecaddfab9  pop r9
00007e4ecaddfabb  pop r8
00007e4ecaddfabd  pop rsi
00007e4ecaddfabe  pop rdi
00007e4ecaddfabf  pop rdx
00007e4ecaddfac0  pop rcx
00007e4ecaddfac1  pop rax
00007e4ecaddfac2  add rsp, 0x08
00007e4ecaddfac6  jmp 0x00007E4ECADDC458
00007e4ecaddfacb  sub rsp, 0x08
00007e4ecaddfacf  push rax
00007e4ecaddfad0  push rcx
00007e4ecaddfad1  push rdx
00007e4ecaddfad2  push rdi
00007e4ecaddfad3  push rsi
00007e4ecaddfad4  push r8
00007e4ecaddfad6  push r9
00007e4ecaddfad8  push r10
00007e4ecaddfada  push r11
00007e4ecaddfadc  sub rsp, 0xF0
00007e4ecaddfae3  vmovaps [rsp], xmm0
00007e4ecaddfae8  vmovaps [rsp+0x10], xmm1
00007e4ecaddfaee  vmovaps [rsp+0x20], xmm2
00007e4ecaddfaf4  vmovaps [rsp+0x30], xmm3
00007e4ecaddfafa  vmovaps [rsp+0x40], xmm4
00007e4ecaddfb00  vmovaps [rsp+0x50], xmm5
00007e4ecaddfb06  vmovaps [rsp+0x60], xmm6
00007e4ecaddfb0c  vmovaps [rsp+0x70], xmm7
00007e4ecaddfb12  vmovaps [rsp+0x80], xmm8
00007e4ecaddfb1b  vmovaps [rsp+0x90], xmm9
00007e4ecaddfb24  vmovaps [rsp+0xA0], xmm10
00007e4ecaddfb2d  vmovaps [rsp+0xB0], xmm11
00007e4ecaddfb36  vmovaps [rsp+0xC0], xmm12
00007e4ecaddfb3f  vmovaps [rsp+0xD0], xmm13
00007e4ecaddfb48  vmovaps [rsp+0xE0], xmm14
00007e4ecaddfb51  sub rsp, 0x30
00007e4ecaddfb55  movaps [rsp], xmm15
00007e4ecaddfb5a  movaps [rsp+0x10], xmm1
00007e4ecaddfb5f  movaps [rsp+0x20], xmm5
00007e4ecaddfb64  lea rdi, [rsp]
00007e4ecaddfb68  mov esi, 0x00
00007e4ecaddfb6d  mov rax, 0x5784BC1F5530
00007e4ecaddfb77  call rax
00007e4ecaddfb79  movaps xmm15, [rsp]
00007e4ecaddfb7e  add rsp, 0x30
00007e4ecaddfb82  vmovaps xmm0, [rsp]
00007e4ecaddfb87  vmovaps xmm1, [rsp+0x10]
00007e4ecaddfb8d  vmovaps xmm2, [rsp+0x20]
00007e4ecaddfb93  vmovaps xmm3, [rsp+0x30]
00007e4ecaddfb99  vmovaps xmm4, [rsp+0x40]
00007e4ecaddfb9f  vmovaps xmm5, [rsp+0x50]
00007e4ecaddfba5  vmovaps xmm6, [rsp+0x60]
00007e4ecaddfbab  vmovaps xmm7, [rsp+0x70]
00007e4ecaddfbb1  vmovaps xmm8, [rsp+0x80]
00007e4ecaddfbba  vmovaps xmm9, [rsp+0x90]
00007e4ecaddfbc3  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddfbcc  vmovaps xmm11, [rsp+0xB0]
00007e4ecaddfbd5  vmovaps xmm12, [rsp+0xC0]
00007e4ecaddfbde  vmovaps xmm13, [rsp+0xD0]
00007e4ecaddfbe7  vmovaps xmm14, [rsp+0xE0]
00007e4ecaddfbf0  add rsp, 0xF0
00007e4ecaddfbf7  pop r11
00007e4ecaddfbf9  pop r10
00007e4ecaddfbfb  pop r9
00007e4ecaddfbfd  pop r8
00007e4ecaddfbff  pop rsi
00007e4ecaddfc00  pop rdi
00007e4ecaddfc01  pop rdx
00007e4ecaddfc02  pop rcx
00007e4ecaddfc03  pop rax
00007e4ecaddfc04  add rsp, 0x08
00007e4ecaddfc08  jmp 0x00007E4ECADDC473
00007e4ecaddfc0d  call 0x00007E4ECACB52F0
00007e4ecaddfc12  jmp 0x00007E4ECADDC4CE
00007e4ecaddfc17  sub rsp, 0x08
00007e4ecaddfc1b  push rax
00007e4ecaddfc1c  push rcx
00007e4ecaddfc1d  push rdx
00007e4ecaddfc1e  push rdi
00007e4ecaddfc1f  push rsi
00007e4ecaddfc20  push r8
00007e4ecaddfc22  push r9
00007e4ecaddfc24  push r10
00007e4ecaddfc26  push r11
00007e4ecaddfc28  sub rsp, 0xF0
00007e4ecaddfc2f  vmovaps [rsp], xmm0
00007e4ecaddfc34  vmovaps [rsp+0x10], xmm1
00007e4ecaddfc3a  vmovaps [rsp+0x20], xmm2
00007e4ecaddfc40  vmovaps [rsp+0x30], xmm3
00007e4ecaddfc46  vmovaps [rsp+0x40], xmm4
00007e4ecaddfc4c  vmovaps [rsp+0x50], xmm5
00007e4ecaddfc52  vmovaps [rsp+0x60], xmm6
00007e4ecaddfc58  vmovaps [rsp+0x70], xmm7
00007e4ecaddfc5e  vmovaps [rsp+0x80], xmm8
00007e4ecaddfc67  vmovaps [rsp+0x90], xmm10
00007e4ecaddfc70  vmovaps [rsp+0xA0], xmm11
00007e4ecaddfc79  vmovaps [rsp+0xB0], xmm12
00007e4ecaddfc82  vmovaps [rsp+0xC0], xmm13
00007e4ecaddfc8b  vmovaps [rsp+0xD0], xmm14
00007e4ecaddfc94  vmovaps [rsp+0xE0], xmm15
00007e4ecaddfc9d  sub rsp, 0x30
00007e4ecaddfca1  movaps [rsp], xmm9
00007e4ecaddfca6  movaps [rsp+0x10], xmm8
00007e4ecaddfcac  movaps [rsp+0x20], xmm11
00007e4ecaddfcb2  lea rdi, [rsp]
00007e4ecaddfcb6  mov esi, 0x00
00007e4ecaddfcbb  mov rax, 0x5784BC1F5530
00007e4ecaddfcc5  call rax
00007e4ecaddfcc7  movaps xmm9, [rsp]
00007e4ecaddfccc  add rsp, 0x30
00007e4ecaddfcd0  vmovaps xmm0, [rsp]
00007e4ecaddfcd5  vmovaps xmm1, [rsp+0x10]
00007e4ecaddfcdb  vmovaps xmm2, [rsp+0x20]
00007e4ecaddfce1  vmovaps xmm3, [rsp+0x30]
00007e4ecaddfce7  vmovaps xmm4, [rsp+0x40]
00007e4ecaddfced  vmovaps xmm5, [rsp+0x50]
00007e4ecaddfcf3  vmovaps xmm6, [rsp+0x60]
00007e4ecaddfcf9  vmovaps xmm7, [rsp+0x70]
00007e4ecaddfcff  vmovaps xmm8, [rsp+0x80]
00007e4ecaddfd08  vmovaps xmm10, [rsp+0x90]
00007e4ecaddfd11  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddfd1a  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddfd23  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddfd2c  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddfd35  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddfd3e  add rsp, 0xF0
00007e4ecaddfd45  pop r11
00007e4ecaddfd47  pop r10
00007e4ecaddfd49  pop r9
00007e4ecaddfd4b  pop r8
00007e4ecaddfd4d  pop rsi
00007e4ecaddfd4e  pop rdi
00007e4ecaddfd4f  pop rdx
00007e4ecaddfd50  pop rcx
00007e4ecaddfd51  pop rax
00007e4ecaddfd52  add rsp, 0x08
00007e4ecaddfd56  jmp 0x00007E4ECADDC505
00007e4ecaddfd5b  sub rsp, 0x08
00007e4ecaddfd5f  push rax
00007e4ecaddfd60  push rcx
00007e4ecaddfd61  push rdx
00007e4ecaddfd62  push rdi
00007e4ecaddfd63  push rsi
00007e4ecaddfd64  push r8
00007e4ecaddfd66  push r9
00007e4ecaddfd68  push r10
00007e4ecaddfd6a  push r11
00007e4ecaddfd6c  sub rsp, 0xF0
00007e4ecaddfd73  vmovaps [rsp], xmm0
00007e4ecaddfd78  vmovaps [rsp+0x10], xmm1
00007e4ecaddfd7e  vmovaps [rsp+0x20], xmm2
00007e4ecaddfd84  vmovaps [rsp+0x30], xmm3
00007e4ecaddfd8a  vmovaps [rsp+0x40], xmm4
00007e4ecaddfd90  vmovaps [rsp+0x50], xmm5
00007e4ecaddfd96  vmovaps [rsp+0x60], xmm6
00007e4ecaddfd9c  vmovaps [rsp+0x70], xmm7
00007e4ecaddfda2  vmovaps [rsp+0x80], xmm8
00007e4ecaddfdab  vmovaps [rsp+0x90], xmm9
00007e4ecaddfdb4  vmovaps [rsp+0xA0], xmm10
00007e4ecaddfdbd  vmovaps [rsp+0xB0], xmm12
00007e4ecaddfdc6  vmovaps [rsp+0xC0], xmm13
00007e4ecaddfdcf  vmovaps [rsp+0xD0], xmm14
00007e4ecaddfdd8  vmovaps [rsp+0xE0], xmm15
00007e4ecaddfde1  sub rsp, 0x30
00007e4ecaddfde5  movaps [rsp], xmm11
00007e4ecaddfdea  movaps [rsp+0x10], xmm10
00007e4ecaddfdf0  movaps [rsp+0x20], xmm6
00007e4ecaddfdf5  lea rdi, [rsp]
00007e4ecaddfdf9  mov esi, 0x00
00007e4ecaddfdfe  mov rax, 0x5784BC1F5530
00007e4ecaddfe08  call rax
00007e4ecaddfe0a  movaps xmm11, [rsp]
00007e4ecaddfe0f  add rsp, 0x30
00007e4ecaddfe13  vmovaps xmm0, [rsp]
00007e4ecaddfe18  vmovaps xmm1, [rsp+0x10]
00007e4ecaddfe1e  vmovaps xmm2, [rsp+0x20]
00007e4ecaddfe24  vmovaps xmm3, [rsp+0x30]
00007e4ecaddfe2a  vmovaps xmm4, [rsp+0x40]
00007e4ecaddfe30  vmovaps xmm5, [rsp+0x50]
00007e4ecaddfe36  vmovaps xmm6, [rsp+0x60]
00007e4ecaddfe3c  vmovaps xmm7, [rsp+0x70]
00007e4ecaddfe42  vmovaps xmm8, [rsp+0x80]
00007e4ecaddfe4b  vmovaps xmm9, [rsp+0x90]
00007e4ecaddfe54  vmovaps xmm10, [rsp+0xA0]
00007e4ecaddfe5d  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddfe66  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddfe6f  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddfe78  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddfe81  add rsp, 0xF0
00007e4ecaddfe88  pop r11
00007e4ecaddfe8a  pop r10
00007e4ecaddfe8c  pop r9
00007e4ecaddfe8e  pop r8
00007e4ecaddfe90  pop rsi
00007e4ecaddfe91  pop rdi
00007e4ecaddfe92  pop rdx
00007e4ecaddfe93  pop rcx
00007e4ecaddfe94  pop rax
00007e4ecaddfe95  add rsp, 0x08
00007e4ecaddfe99  jmp 0x00007E4ECADDC520
00007e4ecaddfe9e  sub rsp, 0x08
00007e4ecaddfea2  push rax
00007e4ecaddfea3  push rcx
00007e4ecaddfea4  push rdx
00007e4ecaddfea5  push rdi
00007e4ecaddfea6  push rsi
00007e4ecaddfea7  push r8
00007e4ecaddfea9  push r9
00007e4ecaddfeab  push r10
00007e4ecaddfead  push r11
00007e4ecaddfeaf  sub rsp, 0xF0
00007e4ecaddfeb6  vmovaps [rsp], xmm0
00007e4ecaddfebb  vmovaps [rsp+0x10], xmm1
00007e4ecaddfec1  vmovaps [rsp+0x20], xmm2
00007e4ecaddfec7  vmovaps [rsp+0x30], xmm3
00007e4ecaddfecd  vmovaps [rsp+0x40], xmm4
00007e4ecaddfed3  vmovaps [rsp+0x50], xmm5
00007e4ecaddfed9  vmovaps [rsp+0x60], xmm6
00007e4ecaddfedf  vmovaps [rsp+0x70], xmm7
00007e4ecaddfee5  vmovaps [rsp+0x80], xmm8
00007e4ecaddfeee  vmovaps [rsp+0x90], xmm9
00007e4ecaddfef7  vmovaps [rsp+0xA0], xmm11
00007e4ecaddff00  vmovaps [rsp+0xB0], xmm12
00007e4ecaddff09  vmovaps [rsp+0xC0], xmm13
00007e4ecaddff12  vmovaps [rsp+0xD0], xmm14
00007e4ecaddff1b  vmovaps [rsp+0xE0], xmm15
00007e4ecaddff24  sub rsp, 0x30
00007e4ecaddff28  movaps [rsp], xmm10
00007e4ecaddff2d  movaps [rsp+0x10], xmm14
00007e4ecaddff33  movaps [rsp+0x20], xmm4
00007e4ecaddff38  lea rdi, [rsp]
00007e4ecaddff3c  mov esi, 0x00
00007e4ecaddff41  mov rax, 0x5784BC1F5530
00007e4ecaddff4b  call rax
00007e4ecaddff4d  movaps xmm10, [rsp]
00007e4ecaddff52  add rsp, 0x30
00007e4ecaddff56  vmovaps xmm0, [rsp]
00007e4ecaddff5b  vmovaps xmm1, [rsp+0x10]
00007e4ecaddff61  vmovaps xmm2, [rsp+0x20]
00007e4ecaddff67  vmovaps xmm3, [rsp+0x30]
00007e4ecaddff6d  vmovaps xmm4, [rsp+0x40]
00007e4ecaddff73  vmovaps xmm5, [rsp+0x50]
00007e4ecaddff79  vmovaps xmm6, [rsp+0x60]
00007e4ecaddff7f  vmovaps xmm7, [rsp+0x70]
00007e4ecaddff85  vmovaps xmm8, [rsp+0x80]
00007e4ecaddff8e  vmovaps xmm9, [rsp+0x90]
00007e4ecaddff97  vmovaps xmm11, [rsp+0xA0]
00007e4ecaddffa0  vmovaps xmm12, [rsp+0xB0]
00007e4ecaddffa9  vmovaps xmm13, [rsp+0xC0]
00007e4ecaddffb2  vmovaps xmm14, [rsp+0xD0]
00007e4ecaddffbb  vmovaps xmm15, [rsp+0xE0]
00007e4ecaddffc4  add rsp, 0xF0
00007e4ecaddffcb  pop r11
00007e4ecaddffcd  pop r10
00007e4ecaddffcf  pop r9
00007e4ecaddffd1  pop r8
00007e4ecaddffd3  pop rsi
00007e4ecaddffd4  pop rdi
00007e4ecaddffd5  pop rdx
00007e4ecaddffd6  pop rcx
00007e4ecaddffd7  pop rax
00007e4ecaddffd8  add rsp, 0x08
00007e4ecaddffdc  jmp 0x00007E4ECADDC53B
00007e4ecaddffe1  sub rsp, 0x08
00007e4ecaddffe5  push rax
00007e4ecaddffe6  push rcx
00007e4ecaddffe7  push rdx
00007e4ecaddffe8  push rdi
00007e4ecaddffe9  push rsi
00007e4ecaddffea  push r8
00007e4ecaddffec  push r9
00007e4ecaddffee  push r10
00007e4ecaddfff0  push r11
00007e4ecaddfff2  sub rsp, 0xF0
00007e4ecaddfff9  vmovaps [rsp], xmm0
00007e4ecaddfffe  vmovaps [rsp+0x10], xmm1
00007e4ecade0004  vmovaps [rsp+0x20], xmm2
00007e4ecade000a  vmovaps [rsp+0x30], xmm3
00007e4ecade0010  vmovaps [rsp+0x40], xmm4
00007e4ecade0016  vmovaps [rsp+0x50], xmm5
00007e4ecade001c  vmovaps [rsp+0x60], xmm6
00007e4ecade0022  vmovaps [rsp+0x70], xmm7
00007e4ecade0028  vmovaps [rsp+0x80], xmm9
00007e4ecade0031  vmovaps [rsp+0x90], xmm10
00007e4ecade003a  vmovaps [rsp+0xA0], xmm11
00007e4ecade0043  vmovaps [rsp+0xB0], xmm12
00007e4ecade004c  vmovaps [rsp+0xC0], xmm13
00007e4ecade0055  vmovaps [rsp+0xD0], xmm14
00007e4ecade005e  vmovaps [rsp+0xE0], xmm15
00007e4ecade0067  sub rsp, 0x30
00007e4ecade006b  movaps [rsp], xmm8
00007e4ecade0070  movaps [rsp+0x10], xmm1
00007e4ecade0075  movaps [rsp+0x20], xmm14
00007e4ecade007b  lea rdi, [rsp]
00007e4ecade007f  mov esi, 0x00
00007e4ecade0084  mov rax, 0x5784BC1F5530
00007e4ecade008e  call rax
00007e4ecade0090  movaps xmm8, [rsp]
00007e4ecade0095  add rsp, 0x30
00007e4ecade0099  vmovaps xmm0, [rsp]
00007e4ecade009e  vmovaps xmm1, [rsp+0x10]
00007e4ecade00a4  vmovaps xmm2, [rsp+0x20]
00007e4ecade00aa  vmovaps xmm3, [rsp+0x30]
00007e4ecade00b0  vmovaps xmm4, [rsp+0x40]
00007e4ecade00b6  vmovaps xmm5, [rsp+0x50]
00007e4ecade00bc  vmovaps xmm6, [rsp+0x60]
00007e4ecade00c2  vmovaps xmm7, [rsp+0x70]
00007e4ecade00c8  vmovaps xmm9, [rsp+0x80]
00007e4ecade00d1  vmovaps xmm10, [rsp+0x90]
00007e4ecade00da  vmovaps xmm11, [rsp+0xA0]
00007e4ecade00e3  vmovaps xmm12, [rsp+0xB0]
00007e4ecade00ec  vmovaps xmm13, [rsp+0xC0]
00007e4ecade00f5  vmovaps xmm14, [rsp+0xD0]
00007e4ecade00fe  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0107  add rsp, 0xF0
00007e4ecade010e  pop r11
00007e4ecade0110  pop r10
00007e4ecade0112  pop r9
00007e4ecade0114  pop r8
00007e4ecade0116  pop rsi
00007e4ecade0117  pop rdi
00007e4ecade0118  pop rdx
00007e4ecade0119  pop rcx
00007e4ecade011a  pop rax
00007e4ecade011b  add rsp, 0x08
00007e4ecade011f  jmp 0x00007E4ECADDC561
00007e4ecade0124  sub rsp, 0x08
00007e4ecade0128  push rax
00007e4ecade0129  push rcx
00007e4ecade012a  push rdx
00007e4ecade012b  push rdi
00007e4ecade012c  push rsi
00007e4ecade012d  push r8
00007e4ecade012f  push r9
00007e4ecade0131  push r10
00007e4ecade0133  push r11
00007e4ecade0135  sub rsp, 0xF0
00007e4ecade013c  vmovaps [rsp], xmm0
00007e4ecade0141  vmovaps [rsp+0x10], xmm1
00007e4ecade0147  vmovaps [rsp+0x20], xmm2
00007e4ecade014d  vmovaps [rsp+0x30], xmm3
00007e4ecade0153  vmovaps [rsp+0x40], xmm4
00007e4ecade0159  vmovaps [rsp+0x50], xmm5
00007e4ecade015f  vmovaps [rsp+0x60], xmm7
00007e4ecade0165  vmovaps [rsp+0x70], xmm8
00007e4ecade016b  vmovaps [rsp+0x80], xmm9
00007e4ecade0174  vmovaps [rsp+0x90], xmm10
00007e4ecade017d  vmovaps [rsp+0xA0], xmm11
00007e4ecade0186  vmovaps [rsp+0xB0], xmm12
00007e4ecade018f  vmovaps [rsp+0xC0], xmm13
00007e4ecade0198  vmovaps [rsp+0xD0], xmm14
00007e4ecade01a1  vmovaps [rsp+0xE0], xmm15
00007e4ecade01aa  sub rsp, 0x30
00007e4ecade01ae  movaps [rsp], xmm6
00007e4ecade01b2  movaps [rsp+0x10], xmm1
00007e4ecade01b7  movaps [rsp+0x20], xmm14
00007e4ecade01bd  lea rdi, [rsp]
00007e4ecade01c1  mov esi, 0x00
00007e4ecade01c6  mov rax, 0x5784BC1F5530
00007e4ecade01d0  call rax
00007e4ecade01d2  movaps xmm6, [rsp]
00007e4ecade01d6  add rsp, 0x30
00007e4ecade01da  vmovaps xmm0, [rsp]
00007e4ecade01df  vmovaps xmm1, [rsp+0x10]
00007e4ecade01e5  vmovaps xmm2, [rsp+0x20]
00007e4ecade01eb  vmovaps xmm3, [rsp+0x30]
00007e4ecade01f1  vmovaps xmm4, [rsp+0x40]
00007e4ecade01f7  vmovaps xmm5, [rsp+0x50]
00007e4ecade01fd  vmovaps xmm7, [rsp+0x60]
00007e4ecade0203  vmovaps xmm8, [rsp+0x70]
00007e4ecade0209  vmovaps xmm9, [rsp+0x80]
00007e4ecade0212  vmovaps xmm10, [rsp+0x90]
00007e4ecade021b  vmovaps xmm11, [rsp+0xA0]
00007e4ecade0224  vmovaps xmm12, [rsp+0xB0]
00007e4ecade022d  vmovaps xmm13, [rsp+0xC0]
00007e4ecade0236  vmovaps xmm14, [rsp+0xD0]
00007e4ecade023f  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0248  add rsp, 0xF0
00007e4ecade024f  pop r11
00007e4ecade0251  pop r10
00007e4ecade0253  pop r9
00007e4ecade0255  pop r8
00007e4ecade0257  pop rsi
00007e4ecade0258  pop rdi
00007e4ecade0259  pop rdx
00007e4ecade025a  pop rcx
00007e4ecade025b  pop rax
00007e4ecade025c  add rsp, 0x08
00007e4ecade0260  jmp 0x00007E4ECADDC58D
00007e4ecade0265  sub rsp, 0x08
00007e4ecade0269  push rax
00007e4ecade026a  push rcx
00007e4ecade026b  push rdx
00007e4ecade026c  push rdi
00007e4ecade026d  push rsi
00007e4ecade026e  push r8
00007e4ecade0270  push r9
00007e4ecade0272  push r10
00007e4ecade0274  push r11
00007e4ecade0276  sub rsp, 0xF0
00007e4ecade027d  vmovaps [rsp], xmm0
00007e4ecade0282  vmovaps [rsp+0x10], xmm1
00007e4ecade0288  vmovaps [rsp+0x20], xmm2
00007e4ecade028e  vmovaps [rsp+0x30], xmm3
00007e4ecade0294  vmovaps [rsp+0x40], xmm4
00007e4ecade029a  vmovaps [rsp+0x50], xmm5
00007e4ecade02a0  vmovaps [rsp+0x60], xmm6
00007e4ecade02a6  vmovaps [rsp+0x70], xmm7
00007e4ecade02ac  vmovaps [rsp+0x80], xmm8
00007e4ecade02b5  vmovaps [rsp+0x90], xmm9
00007e4ecade02be  vmovaps [rsp+0xA0], xmm10
00007e4ecade02c7  vmovaps [rsp+0xB0], xmm11
00007e4ecade02d0  vmovaps [rsp+0xC0], xmm12
00007e4ecade02d9  vmovaps [rsp+0xD0], xmm13
00007e4ecade02e2  vmovaps [rsp+0xE0], xmm15
00007e4ecade02eb  sub rsp, 0x30
00007e4ecade02ef  movaps [rsp], xmm14
00007e4ecade02f4  movaps [rsp+0x10], xmm12
00007e4ecade02fa  movaps [rsp+0x20], xmm1
00007e4ecade02ff  lea rdi, [rsp]
00007e4ecade0303  mov esi, 0x00
00007e4ecade0308  mov rax, 0x5784BC1F5530
00007e4ecade0312  call rax
00007e4ecade0314  movaps xmm14, [rsp]
00007e4ecade0319  add rsp, 0x30
00007e4ecade031d  vmovaps xmm0, [rsp]
00007e4ecade0322  vmovaps xmm1, [rsp+0x10]
00007e4ecade0328  vmovaps xmm2, [rsp+0x20]
00007e4ecade032e  vmovaps xmm3, [rsp+0x30]
00007e4ecade0334  vmovaps xmm4, [rsp+0x40]
00007e4ecade033a  vmovaps xmm5, [rsp+0x50]
00007e4ecade0340  vmovaps xmm6, [rsp+0x60]
00007e4ecade0346  vmovaps xmm7, [rsp+0x70]
00007e4ecade034c  vmovaps xmm8, [rsp+0x80]
00007e4ecade0355  vmovaps xmm9, [rsp+0x90]
00007e4ecade035e  vmovaps xmm10, [rsp+0xA0]
00007e4ecade0367  vmovaps xmm11, [rsp+0xB0]
00007e4ecade0370  vmovaps xmm12, [rsp+0xC0]
00007e4ecade0379  vmovaps xmm13, [rsp+0xD0]
00007e4ecade0382  vmovaps xmm15, [rsp+0xE0]
00007e4ecade038b  add rsp, 0xF0
00007e4ecade0392  pop r11
00007e4ecade0394  pop r10
00007e4ecade0396  pop r9
00007e4ecade0398  pop r8
00007e4ecade039a  pop rsi
00007e4ecade039b  pop rdi
00007e4ecade039c  pop rdx
00007e4ecade039d  pop rcx
00007e4ecade039e  pop rax
00007e4ecade039f  add rsp, 0x08
00007e4ecade03a3  jmp 0x00007E4ECADDC5B3
00007e4ecade03a8  sub rsp, 0x08
00007e4ecade03ac  push rax
00007e4ecade03ad  push rcx
00007e4ecade03ae  push rdx
00007e4ecade03af  push rdi
00007e4ecade03b0  push rsi
00007e4ecade03b1  push r8
00007e4ecade03b3  push r9
00007e4ecade03b5  push r10
00007e4ecade03b7  push r11
00007e4ecade03b9  sub rsp, 0xF0
00007e4ecade03c0  vmovaps [rsp], xmm0
00007e4ecade03c5  vmovaps [rsp+0x10], xmm2
00007e4ecade03cb  vmovaps [rsp+0x20], xmm3
00007e4ecade03d1  vmovaps [rsp+0x30], xmm4
00007e4ecade03d7  vmovaps [rsp+0x40], xmm5
00007e4ecade03dd  vmovaps [rsp+0x50], xmm6
00007e4ecade03e3  vmovaps [rsp+0x60], xmm7
00007e4ecade03e9  vmovaps [rsp+0x70], xmm8
00007e4ecade03ef  vmovaps [rsp+0x80], xmm9
00007e4ecade03f8  vmovaps [rsp+0x90], xmm10
00007e4ecade0401  vmovaps [rsp+0xA0], xmm11
00007e4ecade040a  vmovaps [rsp+0xB0], xmm12
00007e4ecade0413  vmovaps [rsp+0xC0], xmm13
00007e4ecade041c  vmovaps [rsp+0xD0], xmm14
00007e4ecade0425  vmovaps [rsp+0xE0], xmm15
00007e4ecade042e  sub rsp, 0x30
00007e4ecade0432  movaps [rsp], xmm1
00007e4ecade0436  movaps [rsp+0x10], xmm13
00007e4ecade043c  movaps [rsp+0x20], xmm9
00007e4ecade0442  lea rdi, [rsp]
00007e4ecade0446  mov esi, 0x00
00007e4ecade044b  mov rax, 0x5784BC1F5530
00007e4ecade0455  call rax
00007e4ecade0457  movaps xmm1, [rsp]
00007e4ecade045b  add rsp, 0x30
00007e4ecade045f  vmovaps xmm0, [rsp]
00007e4ecade0464  vmovaps xmm2, [rsp+0x10]
00007e4ecade046a  vmovaps xmm3, [rsp+0x20]
00007e4ecade0470  vmovaps xmm4, [rsp+0x30]
00007e4ecade0476  vmovaps xmm5, [rsp+0x40]
00007e4ecade047c  vmovaps xmm6, [rsp+0x50]
00007e4ecade0482  vmovaps xmm7, [rsp+0x60]
00007e4ecade0488  vmovaps xmm8, [rsp+0x70]
00007e4ecade048e  vmovaps xmm9, [rsp+0x80]
00007e4ecade0497  vmovaps xmm10, [rsp+0x90]
00007e4ecade04a0  vmovaps xmm11, [rsp+0xA0]
00007e4ecade04a9  vmovaps xmm12, [rsp+0xB0]
00007e4ecade04b2  vmovaps xmm13, [rsp+0xC0]
00007e4ecade04bb  vmovaps xmm14, [rsp+0xD0]
00007e4ecade04c4  vmovaps xmm15, [rsp+0xE0]
00007e4ecade04cd  add rsp, 0xF0
00007e4ecade04d4  pop r11
00007e4ecade04d6  pop r10
00007e4ecade04d8  pop r9
00007e4ecade04da  pop r8
00007e4ecade04dc  pop rsi
00007e4ecade04dd  pop rdi
00007e4ecade04de  pop rdx
00007e4ecade04df  pop rcx
00007e4ecade04e0  pop rax
00007e4ecade04e1  add rsp, 0x08
00007e4ecade04e5  jmp 0x00007E4ECADDC5CD
00007e4ecade04ea  sub rsp, 0x08
00007e4ecade04ee  push rax
00007e4ecade04ef  push rcx
00007e4ecade04f0  push rdx
00007e4ecade04f1  push rdi
00007e4ecade04f2  push rsi
00007e4ecade04f3  push r8
00007e4ecade04f5  push r9
00007e4ecade04f7  push r10
00007e4ecade04f9  push r11
00007e4ecade04fb  sub rsp, 0xF0
00007e4ecade0502  vmovaps [rsp], xmm0
00007e4ecade0507  vmovaps [rsp+0x10], xmm1
00007e4ecade050d  vmovaps [rsp+0x20], xmm2
00007e4ecade0513  vmovaps [rsp+0x30], xmm3
00007e4ecade0519  vmovaps [rsp+0x40], xmm4
00007e4ecade051f  vmovaps [rsp+0x50], xmm5
00007e4ecade0525  vmovaps [rsp+0x60], xmm6
00007e4ecade052b  vmovaps [rsp+0x70], xmm7
00007e4ecade0531  vmovaps [rsp+0x80], xmm8
00007e4ecade053a  vmovaps [rsp+0x90], xmm9
00007e4ecade0543  vmovaps [rsp+0xA0], xmm10
00007e4ecade054c  vmovaps [rsp+0xB0], xmm11
00007e4ecade0555  vmovaps [rsp+0xC0], xmm13
00007e4ecade055e  vmovaps [rsp+0xD0], xmm14
00007e4ecade0567  vmovaps [rsp+0xE0], xmm15
00007e4ecade0570  sub rsp, 0x30
00007e4ecade0574  movaps [rsp], xmm12
00007e4ecade0579  movaps [rsp+0x10], xmm7
00007e4ecade057e  movaps [rsp+0x20], xmm13
00007e4ecade0584  lea rdi, [rsp]
00007e4ecade0588  mov esi, 0x00
00007e4ecade058d  mov rax, 0x5784BC1F5530
00007e4ecade0597  call rax
00007e4ecade0599  movaps xmm12, [rsp]
00007e4ecade059e  add rsp, 0x30
00007e4ecade05a2  vmovaps xmm0, [rsp]
00007e4ecade05a7  vmovaps xmm1, [rsp+0x10]
00007e4ecade05ad  vmovaps xmm2, [rsp+0x20]
00007e4ecade05b3  vmovaps xmm3, [rsp+0x30]
00007e4ecade05b9  vmovaps xmm4, [rsp+0x40]
00007e4ecade05bf  vmovaps xmm5, [rsp+0x50]
00007e4ecade05c5  vmovaps xmm6, [rsp+0x60]
00007e4ecade05cb  vmovaps xmm7, [rsp+0x70]
00007e4ecade05d1  vmovaps xmm8, [rsp+0x80]
00007e4ecade05da  vmovaps xmm9, [rsp+0x90]
00007e4ecade05e3  vmovaps xmm10, [rsp+0xA0]
00007e4ecade05ec  vmovaps xmm11, [rsp+0xB0]
00007e4ecade05f5  vmovaps xmm13, [rsp+0xC0]
00007e4ecade05fe  vmovaps xmm14, [rsp+0xD0]
00007e4ecade0607  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0610  add rsp, 0xF0
00007e4ecade0617  pop r11
00007e4ecade0619  pop r10
00007e4ecade061b  pop r9
00007e4ecade061d  pop r8
00007e4ecade061f  pop rsi
00007e4ecade0620  pop rdi
00007e4ecade0621  pop rdx
00007e4ecade0622  pop rcx
00007e4ecade0623  pop rax
00007e4ecade0624  add rsp, 0x08
00007e4ecade0628  jmp 0x00007E4ECADDC5F4
00007e4ecade062d  sub rsp, 0x08
00007e4ecade0631  push rax
00007e4ecade0632  push rcx
00007e4ecade0633  push rdx
00007e4ecade0634  push rdi
00007e4ecade0635  push rsi
00007e4ecade0636  push r8
00007e4ecade0638  push r9
00007e4ecade063a  push r10
00007e4ecade063c  push r11
00007e4ecade063e  sub rsp, 0xF0
00007e4ecade0645  vmovaps [rsp], xmm0
00007e4ecade064a  vmovaps [rsp+0x10], xmm1
00007e4ecade0650  vmovaps [rsp+0x20], xmm2
00007e4ecade0656  vmovaps [rsp+0x30], xmm3
00007e4ecade065c  vmovaps [rsp+0x40], xmm4
00007e4ecade0662  vmovaps [rsp+0x50], xmm5
00007e4ecade0668  vmovaps [rsp+0x60], xmm6
00007e4ecade066e  vmovaps [rsp+0x70], xmm7
00007e4ecade0674  vmovaps [rsp+0x80], xmm8
00007e4ecade067d  vmovaps [rsp+0x90], xmm9
00007e4ecade0686  vmovaps [rsp+0xA0], xmm10
00007e4ecade068f  vmovaps [rsp+0xB0], xmm11
00007e4ecade0698  vmovaps [rsp+0xC0], xmm12
00007e4ecade06a1  vmovaps [rsp+0xD0], xmm14
00007e4ecade06aa  vmovaps [rsp+0xE0], xmm15
00007e4ecade06b3  sub rsp, 0x30
00007e4ecade06b7  movaps [rsp], xmm13
00007e4ecade06bc  movaps [rsp+0x10], xmm15
00007e4ecade06c2  movaps [rsp+0x20], xmm8
00007e4ecade06c8  lea rdi, [rsp]
00007e4ecade06cc  mov esi, 0x00
00007e4ecade06d1  mov rax, 0x5784BC1F5530
00007e4ecade06db  call rax
00007e4ecade06dd  movaps xmm13, [rsp]
00007e4ecade06e2  add rsp, 0x30
00007e4ecade06e6  vmovaps xmm0, [rsp]
00007e4ecade06eb  vmovaps xmm1, [rsp+0x10]
00007e4ecade06f1  vmovaps xmm2, [rsp+0x20]
00007e4ecade06f7  vmovaps xmm3, [rsp+0x30]
00007e4ecade06fd  vmovaps xmm4, [rsp+0x40]
00007e4ecade0703  vmovaps xmm5, [rsp+0x50]
00007e4ecade0709  vmovaps xmm6, [rsp+0x60]
00007e4ecade070f  vmovaps xmm7, [rsp+0x70]
00007e4ecade0715  vmovaps xmm8, [rsp+0x80]
00007e4ecade071e  vmovaps xmm9, [rsp+0x90]
00007e4ecade0727  vmovaps xmm10, [rsp+0xA0]
00007e4ecade0730  vmovaps xmm11, [rsp+0xB0]
00007e4ecade0739  vmovaps xmm12, [rsp+0xC0]
00007e4ecade0742  vmovaps xmm14, [rsp+0xD0]
00007e4ecade074b  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0754  add rsp, 0xF0
00007e4ecade075b  pop r11
00007e4ecade075d  pop r10
00007e4ecade075f  pop r9
00007e4ecade0761  pop r8
00007e4ecade0763  pop rsi
00007e4ecade0764  pop rdi
00007e4ecade0765  pop rdx
00007e4ecade0766  pop rcx
00007e4ecade0767  pop rax
00007e4ecade0768  add rsp, 0x08
00007e4ecade076c  jmp 0x00007E4ECADDC60F
00007e4ecade0771  sub rsp, 0x08
00007e4ecade0775  push rax
00007e4ecade0776  push rcx
00007e4ecade0777  push rdx
00007e4ecade0778  push rdi
00007e4ecade0779  push rsi
00007e4ecade077a  push r8
00007e4ecade077c  push r9
00007e4ecade077e  push r10
00007e4ecade0780  push r11
00007e4ecade0782  sub rsp, 0xF0
00007e4ecade0789  vmovaps [rsp], xmm0
00007e4ecade078e  vmovaps [rsp+0x10], xmm1
00007e4ecade0794  vmovaps [rsp+0x20], xmm2
00007e4ecade079a  vmovaps [rsp+0x30], xmm3
00007e4ecade07a0  vmovaps [rsp+0x40], xmm4
00007e4ecade07a6  vmovaps [rsp+0x50], xmm5
00007e4ecade07ac  vmovaps [rsp+0x60], xmm6
00007e4ecade07b2  vmovaps [rsp+0x70], xmm7
00007e4ecade07b8  vmovaps [rsp+0x80], xmm9
00007e4ecade07c1  vmovaps [rsp+0x90], xmm10
00007e4ecade07ca  vmovaps [rsp+0xA0], xmm11
00007e4ecade07d3  vmovaps [rsp+0xB0], xmm12
00007e4ecade07dc  vmovaps [rsp+0xC0], xmm13
00007e4ecade07e5  vmovaps [rsp+0xD0], xmm14
00007e4ecade07ee  vmovaps [rsp+0xE0], xmm15
00007e4ecade07f7  sub rsp, 0x30
00007e4ecade07fb  movaps [rsp], xmm8
00007e4ecade0800  movaps [rsp+0x10], xmm15
00007e4ecade0806  movaps [rsp+0x20], xmm9
00007e4ecade080c  lea rdi, [rsp]
00007e4ecade0810  mov esi, 0x00
00007e4ecade0815  mov rax, 0x5784BC1F5530
00007e4ecade081f  call rax
00007e4ecade0821  movaps xmm8, [rsp]
00007e4ecade0826  add rsp, 0x30
00007e4ecade082a  vmovaps xmm0, [rsp]
00007e4ecade082f  vmovaps xmm1, [rsp+0x10]
00007e4ecade0835  vmovaps xmm2, [rsp+0x20]
00007e4ecade083b  vmovaps xmm3, [rsp+0x30]
00007e4ecade0841  vmovaps xmm4, [rsp+0x40]
00007e4ecade0847  vmovaps xmm5, [rsp+0x50]
00007e4ecade084d  vmovaps xmm6, [rsp+0x60]
00007e4ecade0853  vmovaps xmm7, [rsp+0x70]
00007e4ecade0859  vmovaps xmm9, [rsp+0x80]
00007e4ecade0862  vmovaps xmm10, [rsp+0x90]
00007e4ecade086b  vmovaps xmm11, [rsp+0xA0]
00007e4ecade0874  vmovaps xmm12, [rsp+0xB0]
00007e4ecade087d  vmovaps xmm13, [rsp+0xC0]
00007e4ecade0886  vmovaps xmm14, [rsp+0xD0]
00007e4ecade088f  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0898  add rsp, 0xF0
00007e4ecade089f  pop r11
00007e4ecade08a1  pop r10
00007e4ecade08a3  pop r9
00007e4ecade08a5  pop r8
00007e4ecade08a7  pop rsi
00007e4ecade08a8  pop rdi
00007e4ecade08a9  pop rdx
00007e4ecade08aa  pop rcx
00007e4ecade08ab  pop rax
00007e4ecade08ac  add rsp, 0x08
00007e4ecade08b0  jmp 0x00007E4ECADDC63D
00007e4ecade08b5  sub rsp, 0x08
00007e4ecade08b9  push rax
00007e4ecade08ba  push rcx
00007e4ecade08bb  push rdx
00007e4ecade08bc  push rdi
00007e4ecade08bd  push rsi
00007e4ecade08be  push r8
00007e4ecade08c0  push r9
00007e4ecade08c2  push r10
00007e4ecade08c4  push r11
00007e4ecade08c6  sub rsp, 0xF0
00007e4ecade08cd  vmovaps [rsp], xmm0
00007e4ecade08d2  vmovaps [rsp+0x10], xmm1
00007e4ecade08d8  vmovaps [rsp+0x20], xmm2
00007e4ecade08de  vmovaps [rsp+0x30], xmm3
00007e4ecade08e4  vmovaps [rsp+0x40], xmm4
00007e4ecade08ea  vmovaps [rsp+0x50], xmm5
00007e4ecade08f0  vmovaps [rsp+0x60], xmm6
00007e4ecade08f6  vmovaps [rsp+0x70], xmm7
00007e4ecade08fc  vmovaps [rsp+0x80], xmm8
00007e4ecade0905  vmovaps [rsp+0x90], xmm9
00007e4ecade090e  vmovaps [rsp+0xA0], xmm10
00007e4ecade0917  vmovaps [rsp+0xB0], xmm11
00007e4ecade0920  vmovaps [rsp+0xC0], xmm12
00007e4ecade0929  vmovaps [rsp+0xD0], xmm13
00007e4ecade0932  vmovaps [rsp+0xE0], xmm14
00007e4ecade093b  sub rsp, 0x30
00007e4ecade093f  movaps [rsp], xmm15
00007e4ecade0944  movaps [rsp+0x10], xmm11
00007e4ecade094a  movaps [rsp+0x20], xmm6
00007e4ecade094f  lea rdi, [rsp]
00007e4ecade0953  mov esi, 0x00
00007e4ecade0958  mov rax, 0x5784BC1F5530
00007e4ecade0962  call rax
00007e4ecade0964  movaps xmm15, [rsp]
00007e4ecade0969  add rsp, 0x30
00007e4ecade096d  vmovaps xmm0, [rsp]
00007e4ecade0972  vmovaps xmm1, [rsp+0x10]
00007e4ecade0978  vmovaps xmm2, [rsp+0x20]
00007e4ecade097e  vmovaps xmm3, [rsp+0x30]
00007e4ecade0984  vmovaps xmm4, [rsp+0x40]
00007e4ecade098a  vmovaps xmm5, [rsp+0x50]
00007e4ecade0990  vmovaps xmm6, [rsp+0x60]
00007e4ecade0996  vmovaps xmm7, [rsp+0x70]
00007e4ecade099c  vmovaps xmm8, [rsp+0x80]
00007e4ecade09a5  vmovaps xmm9, [rsp+0x90]
00007e4ecade09ae  vmovaps xmm10, [rsp+0xA0]
00007e4ecade09b7  vmovaps xmm11, [rsp+0xB0]
00007e4ecade09c0  vmovaps xmm12, [rsp+0xC0]
00007e4ecade09c9  vmovaps xmm13, [rsp+0xD0]
00007e4ecade09d2  vmovaps xmm14, [rsp+0xE0]
00007e4ecade09db  add rsp, 0xF0
00007e4ecade09e2  pop r11
00007e4ecade09e4  pop r10
00007e4ecade09e6  pop r9
00007e4ecade09e8  pop r8
00007e4ecade09ea  pop rsi
00007e4ecade09eb  pop rdi
00007e4ecade09ec  pop rdx
00007e4ecade09ed  pop rcx
00007e4ecade09ee  pop rax
00007e4ecade09ef  add rsp, 0x08
00007e4ecade09f3  jmp 0x00007E4ECADDC658
00007e4ecade09f8  sub rsp, 0x08
00007e4ecade09fc  push rax
00007e4ecade09fd  push rcx
00007e4ecade09fe  push rdx
00007e4ecade09ff  push rdi
00007e4ecade0a00  push rsi
00007e4ecade0a01  push r8
00007e4ecade0a03  push r9
00007e4ecade0a05  push r10
00007e4ecade0a07  push r11
00007e4ecade0a09  sub rsp, 0xF0
00007e4ecade0a10  vmovaps [rsp], xmm0
00007e4ecade0a15  vmovaps [rsp+0x10], xmm1
00007e4ecade0a1b  vmovaps [rsp+0x20], xmm2
00007e4ecade0a21  vmovaps [rsp+0x30], xmm3
00007e4ecade0a27  vmovaps [rsp+0x40], xmm4
00007e4ecade0a2d  vmovaps [rsp+0x50], xmm5
00007e4ecade0a33  vmovaps [rsp+0x60], xmm6
00007e4ecade0a39  vmovaps [rsp+0x70], xmm8
00007e4ecade0a3f  vmovaps [rsp+0x80], xmm9
00007e4ecade0a48  vmovaps [rsp+0x90], xmm10
00007e4ecade0a51  vmovaps [rsp+0xA0], xmm11
00007e4ecade0a5a  vmovaps [rsp+0xB0], xmm12
00007e4ecade0a63  vmovaps [rsp+0xC0], xmm13
00007e4ecade0a6c  vmovaps [rsp+0xD0], xmm14
00007e4ecade0a75  vmovaps [rsp+0xE0], xmm15
00007e4ecade0a7e  sub rsp, 0x30
00007e4ecade0a82  movaps [rsp], xmm7
00007e4ecade0a86  movaps [rsp+0x10], xmm11
00007e4ecade0a8c  movaps [rsp+0x20], xmm9
00007e4ecade0a92  lea rdi, [rsp]
00007e4ecade0a96  mov esi, 0x00
00007e4ecade0a9b  mov rax, 0x5784BC1F5530
00007e4ecade0aa5  call rax
00007e4ecade0aa7  movaps xmm7, [rsp]
00007e4ecade0aab  add rsp, 0x30
00007e4ecade0aaf  vmovaps xmm0, [rsp]
00007e4ecade0ab4  vmovaps xmm1, [rsp+0x10]
00007e4ecade0aba  vmovaps xmm2, [rsp+0x20]
00007e4ecade0ac0  vmovaps xmm3, [rsp+0x30]
00007e4ecade0ac6  vmovaps xmm4, [rsp+0x40]
00007e4ecade0acc  vmovaps xmm5, [rsp+0x50]
00007e4ecade0ad2  vmovaps xmm6, [rsp+0x60]
00007e4ecade0ad8  vmovaps xmm8, [rsp+0x70]
00007e4ecade0ade  vmovaps xmm9, [rsp+0x80]
00007e4ecade0ae7  vmovaps xmm10, [rsp+0x90]
00007e4ecade0af0  vmovaps xmm11, [rsp+0xA0]
00007e4ecade0af9  vmovaps xmm12, [rsp+0xB0]
00007e4ecade0b02  vmovaps xmm13, [rsp+0xC0]
00007e4ecade0b0b  vmovaps xmm14, [rsp+0xD0]
00007e4ecade0b14  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0b1d  add rsp, 0xF0
00007e4ecade0b24  pop r11
00007e4ecade0b26  pop r10
00007e4ecade0b28  pop r9
00007e4ecade0b2a  pop r8
00007e4ecade0b2c  pop rsi
00007e4ecade0b2d  pop rdi
00007e4ecade0b2e  pop rdx
00007e4ecade0b2f  pop rcx
00007e4ecade0b30  pop rax
00007e4ecade0b31  add rsp, 0x08
00007e4ecade0b35  jmp 0x00007E4ECADDC685
00007e4ecade0b3a  sub rsp, 0x08
00007e4ecade0b3e  push rax
00007e4ecade0b3f  push rcx
00007e4ecade0b40  push rdx
00007e4ecade0b41  push rdi
00007e4ecade0b42  push rsi
00007e4ecade0b43  push r8
00007e4ecade0b45  push r9
00007e4ecade0b47  push r10
00007e4ecade0b49  push r11
00007e4ecade0b4b  sub rsp, 0xF0
00007e4ecade0b52  vmovaps [rsp], xmm0
00007e4ecade0b57  vmovaps [rsp+0x10], xmm1
00007e4ecade0b5d  vmovaps [rsp+0x20], xmm2
00007e4ecade0b63  vmovaps [rsp+0x30], xmm3
00007e4ecade0b69  vmovaps [rsp+0x40], xmm4
00007e4ecade0b6f  vmovaps [rsp+0x50], xmm5
00007e4ecade0b75  vmovaps [rsp+0x60], xmm6
00007e4ecade0b7b  vmovaps [rsp+0x70], xmm7
00007e4ecade0b81  vmovaps [rsp+0x80], xmm8
00007e4ecade0b8a  vmovaps [rsp+0x90], xmm9
00007e4ecade0b93  vmovaps [rsp+0xA0], xmm10
00007e4ecade0b9c  vmovaps [rsp+0xB0], xmm12
00007e4ecade0ba5  vmovaps [rsp+0xC0], xmm13
00007e4ecade0bae  vmovaps [rsp+0xD0], xmm14
00007e4ecade0bb7  vmovaps [rsp+0xE0], xmm15
00007e4ecade0bc0  sub rsp, 0x30
00007e4ecade0bc4  movaps [rsp], xmm11
00007e4ecade0bc9  movaps [rsp+0x10], xmm10
00007e4ecade0bcf  movaps [rsp+0x20], xmm14
00007e4ecade0bd5  lea rdi, [rsp]
00007e4ecade0bd9  mov esi, 0x00
00007e4ecade0bde  mov rax, 0x5784BC1F5530
00007e4ecade0be8  call rax
00007e4ecade0bea  movaps xmm11, [rsp]
00007e4ecade0bef  add rsp, 0x30
00007e4ecade0bf3  vmovaps xmm0, [rsp]
00007e4ecade0bf8  vmovaps xmm1, [rsp+0x10]
00007e4ecade0bfe  vmovaps xmm2, [rsp+0x20]
00007e4ecade0c04  vmovaps xmm3, [rsp+0x30]
00007e4ecade0c0a  vmovaps xmm4, [rsp+0x40]
00007e4ecade0c10  vmovaps xmm5, [rsp+0x50]
00007e4ecade0c16  vmovaps xmm6, [rsp+0x60]
00007e4ecade0c1c  vmovaps xmm7, [rsp+0x70]
00007e4ecade0c22  vmovaps xmm8, [rsp+0x80]
00007e4ecade0c2b  vmovaps xmm9, [rsp+0x90]
00007e4ecade0c34  vmovaps xmm10, [rsp+0xA0]
00007e4ecade0c3d  vmovaps xmm12, [rsp+0xB0]
00007e4ecade0c46  vmovaps xmm13, [rsp+0xC0]
00007e4ecade0c4f  vmovaps xmm14, [rsp+0xD0]
00007e4ecade0c58  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0c61  add rsp, 0xF0
00007e4ecade0c68  pop r11
00007e4ecade0c6a  pop r10
00007e4ecade0c6c  pop r9
00007e4ecade0c6e  pop r8
00007e4ecade0c70  pop rsi
00007e4ecade0c71  pop rdi
00007e4ecade0c72  pop rdx
00007e4ecade0c73  pop rcx
00007e4ecade0c74  pop rax
00007e4ecade0c75  add rsp, 0x08
00007e4ecade0c79  jmp 0x00007E4ECADDC6A0
00007e4ecade0c7e  call 0x00007E4ECACC33A0
00007e4ecade0c83  jmp 0x00007E4ECADDC6AA
00007e4ecade0c88  sub rsp, 0x08
00007e4ecade0c8c  push rax
00007e4ecade0c8d  push rcx
00007e4ecade0c8e  push rdx
00007e4ecade0c8f  push rdi
00007e4ecade0c90  push rsi
00007e4ecade0c91  push r8
00007e4ecade0c93  push r9
00007e4ecade0c95  push r10
00007e4ecade0c97  push r11
00007e4ecade0c99  sub rsp, 0xF0
00007e4ecade0ca0  vmovaps [rsp], xmm0
00007e4ecade0ca5  vmovaps [rsp+0x10], xmm1
00007e4ecade0cab  vmovaps [rsp+0x20], xmm2
00007e4ecade0cb1  vmovaps [rsp+0x30], xmm3
00007e4ecade0cb7  vmovaps [rsp+0x40], xmm4
00007e4ecade0cbd  vmovaps [rsp+0x50], xmm5
00007e4ecade0cc3  vmovaps [rsp+0x60], xmm6
00007e4ecade0cc9  vmovaps [rsp+0x70], xmm7
00007e4ecade0ccf  vmovaps [rsp+0x80], xmm8
00007e4ecade0cd8  vmovaps [rsp+0x90], xmm9
00007e4ecade0ce1  vmovaps [rsp+0xA0], xmm11
00007e4ecade0cea  vmovaps [rsp+0xB0], xmm12
00007e4ecade0cf3  vmovaps [rsp+0xC0], xmm13
00007e4ecade0cfc  vmovaps [rsp+0xD0], xmm14
00007e4ecade0d05  vmovaps [rsp+0xE0], xmm15
00007e4ecade0d0e  sub rsp, 0x30
00007e4ecade0d12  movaps [rsp], xmm10
00007e4ecade0d17  movaps [rsp+0x10], xmm1
00007e4ecade0d1c  movaps [rsp+0x20], xmm12
00007e4ecade0d22  lea rdi, [rsp]
00007e4ecade0d26  mov esi, 0x00
00007e4ecade0d2b  mov rax, 0x5784BC1F5530
00007e4ecade0d35  call rax
00007e4ecade0d37  movaps xmm10, [rsp]
00007e4ecade0d3c  add rsp, 0x30
00007e4ecade0d40  vmovaps xmm0, [rsp]
00007e4ecade0d45  vmovaps xmm1, [rsp+0x10]
00007e4ecade0d4b  vmovaps xmm2, [rsp+0x20]
00007e4ecade0d51  vmovaps xmm3, [rsp+0x30]
00007e4ecade0d57  vmovaps xmm4, [rsp+0x40]
00007e4ecade0d5d  vmovaps xmm5, [rsp+0x50]
00007e4ecade0d63  vmovaps xmm6, [rsp+0x60]
00007e4ecade0d69  vmovaps xmm7, [rsp+0x70]
00007e4ecade0d6f  vmovaps xmm8, [rsp+0x80]
00007e4ecade0d78  vmovaps xmm9, [rsp+0x90]
00007e4ecade0d81  vmovaps xmm11, [rsp+0xA0]
00007e4ecade0d8a  vmovaps xmm12, [rsp+0xB0]
00007e4ecade0d93  vmovaps xmm13, [rsp+0xC0]
00007e4ecade0d9c  vmovaps xmm14, [rsp+0xD0]
00007e4ecade0da5  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0dae  add rsp, 0xF0
00007e4ecade0db5  pop r11
00007e4ecade0db7  pop r10
00007e4ecade0db9  pop r9
00007e4ecade0dbb  pop r8
00007e4ecade0dbd  pop rsi
00007e4ecade0dbe  pop rdi
00007e4ecade0dbf  pop rdx
00007e4ecade0dc0  pop rcx
00007e4ecade0dc1  pop rax
00007e4ecade0dc2  add rsp, 0x08
00007e4ecade0dc6  jmp 0x00007E4ECADDC6CD
00007e4ecade0dcb  sub rsp, 0x08
00007e4ecade0dcf  push rax
00007e4ecade0dd0  push rcx
00007e4ecade0dd1  push rdx
00007e4ecade0dd2  push rdi
00007e4ecade0dd3  push rsi
00007e4ecade0dd4  push r8
00007e4ecade0dd6  push r9
00007e4ecade0dd8  push r10
00007e4ecade0dda  push r11
00007e4ecade0ddc  sub rsp, 0xF0
00007e4ecade0de3  vmovaps [rsp], xmm0
00007e4ecade0de8  vmovaps [rsp+0x10], xmm1
00007e4ecade0dee  vmovaps [rsp+0x20], xmm2
00007e4ecade0df4  vmovaps [rsp+0x30], xmm3
00007e4ecade0dfa  vmovaps [rsp+0x40], xmm4
00007e4ecade0e00  vmovaps [rsp+0x50], xmm5
00007e4ecade0e06  vmovaps [rsp+0x60], xmm6
00007e4ecade0e0c  vmovaps [rsp+0x70], xmm7
00007e4ecade0e12  vmovaps [rsp+0x80], xmm8
00007e4ecade0e1b  vmovaps [rsp+0x90], xmm9
00007e4ecade0e24  vmovaps [rsp+0xA0], xmm10
00007e4ecade0e2d  vmovaps [rsp+0xB0], xmm11
00007e4ecade0e36  vmovaps [rsp+0xC0], xmm13
00007e4ecade0e3f  vmovaps [rsp+0xD0], xmm14
00007e4ecade0e48  vmovaps [rsp+0xE0], xmm15
00007e4ecade0e51  sub rsp, 0x30
00007e4ecade0e55  movaps [rsp], xmm12
00007e4ecade0e5a  movaps [rsp+0x10], xmm14
00007e4ecade0e60  movaps [rsp+0x20], xmm1
00007e4ecade0e65  lea rdi, [rsp]
00007e4ecade0e69  mov esi, 0x00
00007e4ecade0e6e  mov rax, 0x5784BC1F5530
00007e4ecade0e78  call rax
00007e4ecade0e7a  movaps xmm12, [rsp]
00007e4ecade0e7f  add rsp, 0x30
00007e4ecade0e83  vmovaps xmm0, [rsp]
00007e4ecade0e88  vmovaps xmm1, [rsp+0x10]
00007e4ecade0e8e  vmovaps xmm2, [rsp+0x20]
00007e4ecade0e94  vmovaps xmm3, [rsp+0x30]
00007e4ecade0e9a  vmovaps xmm4, [rsp+0x40]
00007e4ecade0ea0  vmovaps xmm5, [rsp+0x50]
00007e4ecade0ea6  vmovaps xmm6, [rsp+0x60]
00007e4ecade0eac  vmovaps xmm7, [rsp+0x70]
00007e4ecade0eb2  vmovaps xmm8, [rsp+0x80]
00007e4ecade0ebb  vmovaps xmm9, [rsp+0x90]
00007e4ecade0ec4  vmovaps xmm10, [rsp+0xA0]
00007e4ecade0ecd  vmovaps xmm11, [rsp+0xB0]
00007e4ecade0ed6  vmovaps xmm13, [rsp+0xC0]
00007e4ecade0edf  vmovaps xmm14, [rsp+0xD0]
00007e4ecade0ee8  vmovaps xmm15, [rsp+0xE0]
00007e4ecade0ef1  add rsp, 0xF0
00007e4ecade0ef8  pop r11
00007e4ecade0efa  pop r10
00007e4ecade0efc  pop r9
00007e4ecade0efe  pop r8
00007e4ecade0f00  pop rsi
00007e4ecade0f01  pop rdi
00007e4ecade0f02  pop rdx
00007e4ecade0f03  pop rcx
00007e4ecade0f04  pop rax
00007e4ecade0f05  add rsp, 0x08
00007e4ecade0f09  jmp 0x00007E4ECADDC6FC
00007e4ecade0f0e  sub rsp, 0x08
00007e4ecade0f12  push rax
00007e4ecade0f13  push rcx
00007e4ecade0f14  push rdx
00007e4ecade0f15  push rdi
00007e4ecade0f16  push rsi
00007e4ecade0f17  push r8
00007e4ecade0f19  push r9
00007e4ecade0f1b  push r10
00007e4ecade0f1d  push r11
00007e4ecade0f1f  sub rsp, 0xF0
00007e4ecade0f26  vmovaps [rsp], xmm0
00007e4ecade0f2b  vmovaps [rsp+0x10], xmm1
00007e4ecade0f31  vmovaps [rsp+0x20], xmm2
00007e4ecade0f37  vmovaps [rsp+0x30], xmm3
00007e4ecade0f3d  vmovaps [rsp+0x40], xmm4
00007e4ecade0f43  vmovaps [rsp+0x50], xmm5
00007e4ecade0f49  vmovaps [rsp+0x60], xmm6
00007e4ecade0f4f  vmovaps [rsp+0x70], xmm7
00007e4ecade0f55  vmovaps [rsp+0x80], xmm8
00007e4ecade0f5e  vmovaps [rsp+0x90], xmm9
00007e4ecade0f67  vmovaps [rsp+0xA0], xmm10
00007e4ecade0f70  vmovaps [rsp+0xB0], xmm11
00007e4ecade0f79  vmovaps [rsp+0xC0], xmm12
00007e4ecade0f82  vmovaps [rsp+0xD0], xmm13
00007e4ecade0f8b  vmovaps [rsp+0xE0], xmm15
00007e4ecade0f94  sub rsp, 0x30
00007e4ecade0f98  movaps [rsp], xmm14
00007e4ecade0f9d  movaps [rsp+0x10], xmm9
00007e4ecade0fa3  movaps [rsp+0x20], xmm1
00007e4ecade0fa8  lea rdi, [rsp]
00007e4ecade0fac  mov esi, 0x00
00007e4ecade0fb1  mov rax, 0x5784BC1F5530
00007e4ecade0fbb  call rax
00007e4ecade0fbd  movaps xmm14, [rsp]
00007e4ecade0fc2  add rsp, 0x30
00007e4ecade0fc6  vmovaps xmm0, [rsp]
00007e4ecade0fcb  vmovaps xmm1, [rsp+0x10]
00007e4ecade0fd1  vmovaps xmm2, [rsp+0x20]
00007e4ecade0fd7  vmovaps xmm3, [rsp+0x30]
00007e4ecade0fdd  vmovaps xmm4, [rsp+0x40]
00007e4ecade0fe3  vmovaps xmm5, [rsp+0x50]
00007e4ecade0fe9  vmovaps xmm6, [rsp+0x60]
00007e4ecade0fef  vmovaps xmm7, [rsp+0x70]
00007e4ecade0ff5  vmovaps xmm8, [rsp+0x80]
00007e4ecade0ffe  vmovaps xmm9, [rsp+0x90]
00007e4ecade1007  vmovaps xmm10, [rsp+0xA0]
00007e4ecade1010  vmovaps xmm11, [rsp+0xB0]
00007e4ecade1019  vmovaps xmm12, [rsp+0xC0]
00007e4ecade1022  vmovaps xmm13, [rsp+0xD0]
00007e4ecade102b  vmovaps xmm15, [rsp+0xE0]
00007e4ecade1034  add rsp, 0xF0
00007e4ecade103b  pop r11
00007e4ecade103d  pop r10
00007e4ecade103f  pop r9
00007e4ecade1041  pop r8
00007e4ecade1043  pop rsi
00007e4ecade1044  pop rdi
00007e4ecade1045  pop rdx
00007e4ecade1046  pop rcx
00007e4ecade1047  pop rax
00007e4ecade1048  add rsp, 0x08
00007e4ecade104c  jmp 0x00007E4ECADDC72B
00007e4ecade1051  sub rsp, 0x08
00007e4ecade1055  push rax
00007e4ecade1056  push rcx
00007e4ecade1057  push rdx
00007e4ecade1058  push rdi
00007e4ecade1059  push rsi
00007e4ecade105a  push r8
00007e4ecade105c  push r9
00007e4ecade105e  push r10
00007e4ecade1060  push r11
00007e4ecade1062  sub rsp, 0xF0
00007e4ecade1069  vmovaps [rsp], xmm0
00007e4ecade106e  vmovaps [rsp+0x10], xmm2
00007e4ecade1074  vmovaps [rsp+0x20], xmm3
00007e4ecade107a  vmovaps [rsp+0x30], xmm4
00007e4ecade1080  vmovaps [rsp+0x40], xmm5
00007e4ecade1086  vmovaps [rsp+0x50], xmm6
00007e4ecade108c  vmovaps [rsp+0x60], xmm7
00007e4ecade1092  vmovaps [rsp+0x70], xmm8
00007e4ecade1098  vmovaps [rsp+0x80], xmm9
00007e4ecade10a1  vmovaps [rsp+0x90], xmm10
00007e4ecade10aa  vmovaps [rsp+0xA0], xmm11
00007e4ecade10b3  vmovaps [rsp+0xB0], xmm12
00007e4ecade10bc  vmovaps [rsp+0xC0], xmm13
00007e4ecade10c5  vmovaps [rsp+0xD0], xmm14
00007e4ecade10ce  vmovaps [rsp+0xE0], xmm15
00007e4ecade10d7  sub rsp, 0x30
00007e4ecade10db  movaps [rsp], xmm1
00007e4ecade10df  movaps [rsp+0x10], xmm13
00007e4ecade10e5  movaps [rsp+0x20], xmm8
00007e4ecade10eb  lea rdi, [rsp]
00007e4ecade10ef  mov esi, 0x00
00007e4ecade10f4  mov rax, 0x5784BC1F5530
00007e4ecade10fe  call rax
00007e4ecade1100  movaps xmm1, [rsp]
00007e4ecade1104  add rsp, 0x30
00007e4ecade1108  vmovaps xmm0, [rsp]
00007e4ecade110d  vmovaps xmm2, [rsp+0x10]
00007e4ecade1113  vmovaps xmm3, [rsp+0x20]
00007e4ecade1119  vmovaps xmm4, [rsp+0x30]
00007e4ecade111f  vmovaps xmm5, [rsp+0x40]
00007e4ecade1125  vmovaps xmm6, [rsp+0x50]
00007e4ecade112b  vmovaps xmm7, [rsp+0x60]
00007e4ecade1131  vmovaps xmm8, [rsp+0x70]
00007e4ecade1137  vmovaps xmm9, [rsp+0x80]
00007e4ecade1140  vmovaps xmm10, [rsp+0x90]
00007e4ecade1149  vmovaps xmm11, [rsp+0xA0]
00007e4ecade1152  vmovaps xmm12, [rsp+0xB0]
00007e4ecade115b  vmovaps xmm13, [rsp+0xC0]
00007e4ecade1164  vmovaps xmm14, [rsp+0xD0]
00007e4ecade116d  vmovaps xmm15, [rsp+0xE0]
00007e4ecade1176  add rsp, 0xF0
00007e4ecade117d  pop r11
00007e4ecade117f  pop r10
00007e4ecade1181  pop r9
00007e4ecade1183  pop r8
00007e4ecade1185  pop rsi
00007e4ecade1186  pop rdi
00007e4ecade1187  pop rdx
00007e4ecade1188  pop rcx
00007e4ecade1189  pop rax
00007e4ecade118a  add rsp, 0x08
00007e4ecade118e  jmp 0x00007E4ECADDC74D
00007e4ecade1193  call 0x00007E4ECAC0C260
00007e4ecade1198  jmp 0x00007E4ECADDC75B
00007e4ecade119d  call 0x00007E4ECACBD750
00007e4ecade11a2  jmp 0x00007E4ECADDC765
00007e4ecade11a7  sub rsp, 0x08
00007e4ecade11ab  push rax
00007e4ecade11ac  push rcx
00007e4ecade11ad  push rdx
00007e4ecade11ae  push rdi
00007e4ecade11af  push rsi
00007e4ecade11b0  push r8
00007e4ecade11b2  push r9
00007e4ecade11b4  push r10
00007e4ecade11b6  push r11
00007e4ecade11b8  sub rsp, 0xF0
00007e4ecade11bf  vmovaps [rsp], xmm0
00007e4ecade11c4  vmovaps [rsp+0x10], xmm1
00007e4ecade11ca  vmovaps [rsp+0x20], xmm2
00007e4ecade11d0  vmovaps [rsp+0x30], xmm3
00007e4ecade11d6  vmovaps [rsp+0x40], xmm4
00007e4ecade11dc  vmovaps [rsp+0x50], xmm5
00007e4ecade11e2  vmovaps [rsp+0x60], xmm6
00007e4ecade11e8  vmovaps [rsp+0x70], xmm7
00007e4ecade11ee  vmovaps [rsp+0x80], xmm9
00007e4ecade11f7  vmovaps [rsp+0x90], xmm10
00007e4ecade1200  vmovaps [rsp+0xA0], xmm11
00007e4ecade1209  vmovaps [rsp+0xB0], xmm12
00007e4ecade1212  vmovaps [rsp+0xC0], xmm13
00007e4ecade121b  vmovaps [rsp+0xD0], xmm14
00007e4ecade1224  vmovaps [rsp+0xE0], xmm15
00007e4ecade122d  sub rsp, 0x30
00007e4ecade1231  movaps [rsp], xmm8
00007e4ecade1236  movaps [rsp+0x10], xmm15
00007e4ecade123c  movaps [rsp+0x20], xmm7
00007e4ecade1241  lea rdi, [rsp]
00007e4ecade1245  mov esi, 0x00
00007e4ecade124a  mov rax, 0x5784BC1F5530
00007e4ecade1254  call rax
00007e4ecade1256  movaps xmm8, [rsp]
00007e4ecade125b  add rsp, 0x30
00007e4ecade125f  vmovaps xmm0, [rsp]
00007e4ecade1264  vmovaps xmm1, [rsp+0x10]
00007e4ecade126a  vmovaps xmm2, [rsp+0x20]
00007e4ecade1270  vmovaps xmm3, [rsp+0x30]
00007e4ecade1276  vmovaps xmm4, [rsp+0x40]
00007e4ecade127c  vmovaps xmm5, [rsp+0x50]
00007e4ecade1282  vmovaps xmm6, [rsp+0x60]
00007e4ecade1288  vmovaps xmm7, [rsp+0x70]
00007e4ecade128e  vmovaps xmm9, [rsp+0x80]
00007e4ecade1297  vmovaps xmm10, [rsp+0x90]
00007e4ecade12a0  vmovaps xmm11, [rsp+0xA0]
00007e4ecade12a9  vmovaps xmm12, [rsp+0xB0]
00007e4ecade12b2  vmovaps xmm13, [rsp+0xC0]
00007e4ecade12bb  vmovaps xmm14, [rsp+0xD0]
00007e4ecade12c4  vmovaps xmm15, [rsp+0xE0]
00007e4ecade12cd  add rsp, 0xF0
00007e4ecade12d4  pop r11
00007e4ecade12d6  pop r10
00007e4ecade12d8  pop r9
00007e4ecade12da  pop r8
00007e4ecade12dc  pop rsi
00007e4ecade12dd  pop rdi
00007e4ecade12de  pop rdx
00007e4ecade12df  pop rcx
00007e4ecade12e0  pop rax
00007e4ecade12e1  add rsp, 0x08
00007e4ecade12e5  jmp 0x00007E4ECADDC787
00007e4ecade12ea  sub rsp, 0x08
00007e4ecade12ee  push rax
00007e4ecade12ef  push rcx
00007e4ecade12f0  push rdx
00007e4ecade12f1  push rdi
00007e4ecade12f2  push rsi
00007e4ecade12f3  push r8
00007e4ecade12f5  push r9
00007e4ecade12f7  push r10
00007e4ecade12f9  push r11
00007e4ecade12fb  sub rsp, 0xF0
00007e4ecade1302  vmovaps [rsp], xmm0
00007e4ecade1307  vmovaps [rsp+0x10], xmm1
00007e4ecade130d  vmovaps [rsp+0x20], xmm2
00007e4ecade1313  vmovaps [rsp+0x30], xmm3
00007e4ecade1319  vmovaps [rsp+0x40], xmm4
00007e4ecade131f  vmovaps [rsp+0x50], xmm5
00007e4ecade1325  vmovaps [rsp+0x60], xmm6
00007e4ecade132b  vmovaps [rsp+0x70], xmm8
00007e4ecade1331  vmovaps [rsp+0x80], xmm9
00007e4ecade133a  vmovaps [rsp+0x90], xmm10
00007e4ecade1343  vmovaps [rsp+0xA0], xmm11
00007e4ecade134c  vmovaps [rsp+0xB0], xmm12
00007e4ecade1355  vmovaps [rsp+0xC0], xmm13
00007e4ecade135e  vmovaps [rsp+0xD0], xmm14
00007e4ecade1367  vmovaps [rsp+0xE0], xmm15
00007e4ecade1370  sub rsp, 0x30
00007e4ecade1374  movaps [rsp], xmm7
00007e4ecade1378  movaps [rsp+0x10], xmm9
00007e4ecade137e  movaps [rsp+0x20], xmm15
00007e4ecade1384  lea rdi, [rsp]
00007e4ecade1388  mov esi, 0x00
00007e4ecade138d  mov rax, 0x5784BC1F5530
00007e4ecade1397  call rax
00007e4ecade1399  movaps xmm7, [rsp]
00007e4ecade139d  add rsp, 0x30
00007e4ecade13a1  vmovaps xmm0, [rsp]
00007e4ecade13a6  vmovaps xmm1, [rsp+0x10]
00007e4ecade13ac  vmovaps xmm2, [rsp+0x20]
00007e4ecade13b2  vmovaps xmm3, [rsp+0x30]
00007e4ecade13b8  vmovaps xmm4, [rsp+0x40]
00007e4ecade13be  vmovaps xmm5, [rsp+0x50]
00007e4ecade13c4  vmovaps xmm6, [rsp+0x60]
00007e4ecade13ca  vmovaps xmm8, [rsp+0x70]
00007e4ecade13d0  vmovaps xmm9, [rsp+0x80]
00007e4ecade13d9  vmovaps xmm10, [rsp+0x90]
00007e4ecade13e2  vmovaps xmm11, [rsp+0xA0]
00007e4ecade13eb  vmovaps xmm12, [rsp+0xB0]
00007e4ecade13f4  vmovaps xmm13, [rsp+0xC0]
00007e4ecade13fd  vmovaps xmm14, [rsp+0xD0]
00007e4ecade1406  vmovaps xmm15, [rsp+0xE0]
00007e4ecade140f  add rsp, 0xF0
00007e4ecade1416  pop r11
00007e4ecade1418  pop r10
00007e4ecade141a  pop r9
00007e4ecade141c  pop r8
00007e4ecade141e  pop rsi
00007e4ecade141f  pop rdi
00007e4ecade1420  pop rdx
00007e4ecade1421  pop rcx
00007e4ecade1422  pop rax
00007e4ecade1423  add rsp, 0x08
00007e4ecade1427  jmp 0x00007E4ECADDC7B4
00007e4ecade142c  sub rsp, 0x08
00007e4ecade1430  push rax
00007e4ecade1431  push rcx
00007e4ecade1432  push rdx
00007e4ecade1433  push rdi
00007e4ecade1434  push rsi
00007e4ecade1435  push r8
00007e4ecade1437  push r9
00007e4ecade1439  push r10
00007e4ecade143b  push r11
00007e4ecade143d  sub rsp, 0xF0
00007e4ecade1444  vmovaps [rsp], xmm0
00007e4ecade1449  vmovaps [rsp+0x10], xmm1
00007e4ecade144f  vmovaps [rsp+0x20], xmm2
00007e4ecade1455  vmovaps [rsp+0x30], xmm3
00007e4ecade145b  vmovaps [rsp+0x40], xmm4
00007e4ecade1461  vmovaps [rsp+0x50], xmm5
00007e4ecade1467  vmovaps [rsp+0x60], xmm6
00007e4ecade146d  vmovaps [rsp+0x70], xmm7
00007e4ecade1473  vmovaps [rsp+0x80], xmm8
00007e4ecade147c  vmovaps [rsp+0x90], xmm10
00007e4ecade1485  vmovaps [rsp+0xA0], xmm11
00007e4ecade148e  vmovaps [rsp+0xB0], xmm12
00007e4ecade1497  vmovaps [rsp+0xC0], xmm13
00007e4ecade14a0  vmovaps [rsp+0xD0], xmm14
00007e4ecade14a9  vmovaps [rsp+0xE0], xmm15
00007e4ecade14b2  sub rsp, 0x30
00007e4ecade14b6  movaps [rsp], xmm9
00007e4ecade14bb  movaps [rsp+0x10], xmm13
00007e4ecade14c1  movaps [rsp+0x20], xmm15
00007e4ecade14c7  lea rdi, [rsp]
00007e4ecade14cb  mov esi, 0x00
00007e4ecade14d0  mov rax, 0x5784BC1F5530
00007e4ecade14da  call rax
00007e4ecade14dc  movaps xmm9, [rsp]
00007e4ecade14e1  add rsp, 0x30
00007e4ecade14e5  vmovaps xmm0, [rsp]
00007e4ecade14ea  vmovaps xmm1, [rsp+0x10]
00007e4ecade14f0  vmovaps xmm2, [rsp+0x20]
00007e4ecade14f6  vmovaps xmm3, [rsp+0x30]
00007e4ecade14fc  vmovaps xmm4, [rsp+0x40]
00007e4ecade1502  vmovaps xmm5, [rsp+0x50]
00007e4ecade1508  vmovaps xmm6, [rsp+0x60]
00007e4ecade150e  vmovaps xmm7, [rsp+0x70]
00007e4ecade1514  vmovaps xmm8, [rsp+0x80]
00007e4ecade151d  vmovaps xmm10, [rsp+0x90]
00007e4ecade1526  vmovaps xmm11, [rsp+0xA0]
00007e4ecade152f  vmovaps xmm12, [rsp+0xB0]
00007e4ecade1538  vmovaps xmm13, [rsp+0xC0]
00007e4ecade1541  vmovaps xmm14, [rsp+0xD0]
00007e4ecade154a  vmovaps xmm15, [rsp+0xE0]
00007e4ecade1553  add rsp, 0xF0
00007e4ecade155a  pop r11
00007e4ecade155c  pop r10
00007e4ecade155e  pop r9
00007e4ecade1560  pop r8
00007e4ecade1562  pop rsi
00007e4ecade1563  pop rdi
00007e4ecade1564  pop rdx
00007e4ecade1565  pop rcx
00007e4ecade1566  pop rax
00007e4ecade1567  add rsp, 0x08
00007e4ecade156b  jmp 0x00007E4ECADDC7E2
00007e4ecade1570  sub rsp, 0x08
00007e4ecade1574  push rax
00007e4ecade1575  push rcx
00007e4ecade1576  push rdx
00007e4ecade1577  push rdi
00007e4ecade1578  push rsi
00007e4ecade1579  push r8
00007e4ecade157b  push r9
00007e4ecade157d  push r10
00007e4ecade157f  push r11
00007e4ecade1581  sub rsp, 0xF0
00007e4ecade1588  vmovaps [rsp], xmm0
00007e4ecade158d  vmovaps [rsp+0x10], xmm1
00007e4ecade1593  vmovaps [rsp+0x20], xmm2
00007e4ecade1599  vmovaps [rsp+0x30], xmm3
00007e4ecade159f  vmovaps [rsp+0x40], xmm4
00007e4ecade15a5  vmovaps [rsp+0x50], xmm5
00007e4ecade15ab  vmovaps [rsp+0x60], xmm6
00007e4ecade15b1  vmovaps [rsp+0x70], xmm7
00007e4ecade15b7  vmovaps [rsp+0x80], xmm8
00007e4ecade15c0  vmovaps [rsp+0x90], xmm9
00007e4ecade15c9  vmovaps [rsp+0xA0], xmm10
00007e4ecade15d2  vmovaps [rsp+0xB0], xmm11
00007e4ecade15db  vmovaps [rsp+0xC0], xmm12
00007e4ecade15e4  vmovaps [rsp+0xD0], xmm13
00007e4ecade15ed  vmovaps [rsp+0xE0], xmm14
00007e4ecade15f6  sub rsp, 0x30
00007e4ecade15fa  movaps [rsp], xmm15
00007e4ecade15ff  movaps [rsp+0x10], xmm11
00007e4ecade1605  movaps [rsp+0x20], xmm12
00007e4ecade160b  lea rdi, [rsp]
00007e4ecade160f  mov esi, 0x00
00007e4ecade1614  mov rax, 0x5784BC1F5530
00007e4ecade161e  call rax
00007e4ecade1620  movaps xmm15, [rsp]
00007e4ecade1625  add rsp, 0x30
00007e4ecade1629  vmovaps xmm0, [rsp]
00007e4ecade162e  vmovaps xmm1, [rsp+0x10]
00007e4ecade1634  vmovaps xmm2, [rsp+0x20]
00007e4ecade163a  vmovaps xmm3, [rsp+0x30]
00007e4ecade1640  vmovaps xmm4, [rsp+0x40]
00007e4ecade1646  vmovaps xmm5, [rsp+0x50]
00007e4ecade164c  vmovaps xmm6, [rsp+0x60]
00007e4ecade1652  vmovaps xmm7, [rsp+0x70]
00007e4ecade1658  vmovaps xmm8, [rsp+0x80]
00007e4ecade1661  vmovaps xmm9, [rsp+0x90]
00007e4ecade166a  vmovaps xmm10, [rsp+0xA0]
00007e4ecade1673  vmovaps xmm11, [rsp+0xB0]
00007e4ecade167c  vmovaps xmm12, [rsp+0xC0]
00007e4ecade1685  vmovaps xmm13, [rsp+0xD0]
00007e4ecade168e  vmovaps xmm14, [rsp+0xE0]
00007e4ecade1697  add rsp, 0xF0
00007e4ecade169e  pop r11
00007e4ecade16a0  pop r10
00007e4ecade16a2  pop r9
00007e4ecade16a4  pop r8
00007e4ecade16a6  pop rsi
00007e4ecade16a7  pop rdi
00007e4ecade16a8  pop rdx
00007e4ecade16a9  pop rcx
00007e4ecade16aa  pop rax
00007e4ecade16ab  add rsp, 0x08
00007e4ecade16af  jmp 0x00007E4ECADDC7FD
00007e4ecade16b4  sub rsp, 0x08
00007e4ecade16b8  push rax
00007e4ecade16b9  push rcx
00007e4ecade16ba  push rdx
00007e4ecade16bb  push rdi
00007e4ecade16bc  push rsi
00007e4ecade16bd  push r8
00007e4ecade16bf  push r9
00007e4ecade16c1  push r10
00007e4ecade16c3  push r11
00007e4ecade16c5  sub rsp, 0xF0
00007e4ecade16cc  vmovaps [rsp], xmm0
00007e4ecade16d1  vmovaps [rsp+0x10], xmm1
00007e4ecade16d7  vmovaps [rsp+0x20], xmm2
00007e4ecade16dd  vmovaps [rsp+0x30], xmm3
00007e4ecade16e3  vmovaps [rsp+0x40], xmm4
00007e4ecade16e9  vmovaps [rsp+0x50], xmm5
00007e4ecade16ef  vmovaps [rsp+0x60], xmm6
00007e4ecade16f5  vmovaps [rsp+0x70], xmm7
00007e4ecade16fb  vmovaps [rsp+0x80], xmm8
00007e4ecade1704  vmovaps [rsp+0x90], xmm9
00007e4ecade170d  vmovaps [rsp+0xA0], xmm10
00007e4ecade1716  vmovaps [rsp+0xB0], xmm11
00007e4ecade171f  vmovaps [rsp+0xC0], xmm12
00007e4ecade1728  vmovaps [rsp+0xD0], xmm14
00007e4ecade1731  vmovaps [rsp+0xE0], xmm15
00007e4ecade173a  sub rsp, 0x30
00007e4ecade173e  movaps [rsp], xmm13
00007e4ecade1743  movaps [rsp+0x10], xmm10
00007e4ecade1749  movaps [rsp+0x20], xmm14
00007e4ecade174f  lea rdi, [rsp]
00007e4ecade1753  mov esi, 0x00
00007e4ecade1758  mov rax, 0x5784BC1F5530
00007e4ecade1762  call rax
00007e4ecade1764  movaps xmm13, [rsp]
00007e4ecade1769  add rsp, 0x30
00007e4ecade176d  vmovaps xmm0, [rsp]
00007e4ecade1772  vmovaps xmm1, [rsp+0x10]
00007e4ecade1778  vmovaps xmm2, [rsp+0x20]
00007e4ecade177e  vmovaps xmm3, [rsp+0x30]
00007e4ecade1784  vmovaps xmm4, [rsp+0x40]
00007e4ecade178a  vmovaps xmm5, [rsp+0x50]
00007e4ecade1790  vmovaps xmm6, [rsp+0x60]
00007e4ecade1796  vmovaps xmm7, [rsp+0x70]
00007e4ecade179c  vmovaps xmm8, [rsp+0x80]
00007e4ecade17a5  vmovaps xmm9, [rsp+0x90]
00007e4ecade17ae  vmovaps xmm10, [rsp+0xA0]
00007e4ecade17b7  vmovaps xmm11, [rsp+0xB0]
00007e4ecade17c0  vmovaps xmm12, [rsp+0xC0]
00007e4ecade17c9  vmovaps xmm14, [rsp+0xD0]
00007e4ecade17d2  vmovaps xmm15, [rsp+0xE0]
00007e4ecade17db  add rsp, 0xF0
00007e4ecade17e2  pop r11
00007e4ecade17e4  pop r10
00007e4ecade17e6  pop r9
00007e4ecade17e8  pop r8
00007e4ecade17ea  pop rsi
00007e4ecade17eb  pop rdi
00007e4ecade17ec  pop rdx
00007e4ecade17ed  pop rcx
00007e4ecade17ee  pop rax
00007e4ecade17ef  add rsp, 0x08
00007e4ecade17f3  jmp 0x00007E4ECADDC820
00007e4ecade17f8  sub rsp, 0x08
00007e4ecade17fc  push rax
00007e4ecade17fd  push rcx
00007e4ecade17fe  push rdx
00007e4ecade17ff  push rdi
00007e4ecade1800  push rsi
00007e4ecade1801  push r8
00007e4ecade1803  push r9
00007e4ecade1805  push r10
00007e4ecade1807  push r11
00007e4ecade1809  sub rsp, 0xF0
00007e4ecade1810  vmovaps [rsp], xmm0
00007e4ecade1815  vmovaps [rsp+0x10], xmm1
00007e4ecade181b  vmovaps [rsp+0x20], xmm2
00007e4ecade1821  vmovaps [rsp+0x30], xmm3
00007e4ecade1827  vmovaps [rsp+0x40], xmm4
00007e4ecade182d  vmovaps [rsp+0x50], xmm5
00007e4ecade1833  vmovaps [rsp+0x60], xmm6
00007e4ecade1839  vmovaps [rsp+0x70], xmm7
00007e4ecade183f  vmovaps [rsp+0x80], xmm8
00007e4ecade1848  vmovaps [rsp+0x90], xmm9
00007e4ecade1851  vmovaps [rsp+0xA0], xmm10
00007e4ecade185a  vmovaps [rsp+0xB0], xmm11
00007e4ecade1863  vmovaps [rsp+0xC0], xmm12
00007e4ecade186c  vmovaps [rsp+0xD0], xmm13
00007e4ecade1875  vmovaps [rsp+0xE0], xmm15
00007e4ecade187e  sub rsp, 0x30
00007e4ecade1882  movaps [rsp], xmm14
00007e4ecade1887  movaps [rsp+0x10], xmm1
00007e4ecade188c  movaps [rsp+0x20], xmm7
00007e4ecade1891  lea rdi, [rsp]
00007e4ecade1895  mov esi, 0x00
00007e4ecade189a  mov rax, 0x5784BC1F5530
00007e4ecade18a4  call rax
00007e4ecade18a6  movaps xmm14, [rsp]
00007e4ecade18ab  add rsp, 0x30
00007e4ecade18af  vmovaps xmm0, [rsp]
00007e4ecade18b4  vmovaps xmm1, [rsp+0x10]
00007e4ecade18ba  vmovaps xmm2, [rsp+0x20]
00007e4ecade18c0  vmovaps xmm3, [rsp+0x30]
00007e4ecade18c6  vmovaps xmm4, [rsp+0x40]
00007e4ecade18cc  vmovaps xmm5, [rsp+0x50]
00007e4ecade18d2  vmovaps xmm6, [rsp+0x60]
00007e4ecade18d8  vmovaps xmm7, [rsp+0x70]
00007e4ecade18de  vmovaps xmm8, [rsp+0x80]
00007e4ecade18e7  vmovaps xmm9, [rsp+0x90]
00007e4ecade18f0  vmovaps xmm10, [rsp+0xA0]
00007e4ecade18f9  vmovaps xmm11, [rsp+0xB0]
00007e4ecade1902  vmovaps xmm12, [rsp+0xC0]
00007e4ecade190b  vmovaps xmm13, [rsp+0xD0]
00007e4ecade1914  vmovaps xmm15, [rsp+0xE0]
00007e4ecade191d  add rsp, 0xF0
00007e4ecade1924  pop r11
00007e4ecade1926  pop r10
00007e4ecade1928  pop r9
00007e4ecade192a  pop r8
00007e4ecade192c  pop rsi
00007e4ecade192d  pop rdi
00007e4ecade192e  pop rdx
00007e4ecade192f  pop rcx
00007e4ecade1930  pop rax
00007e4ecade1931  add rsp, 0x08
00007e4ecade1935  jmp 0x00007E4ECADDC843
00007e4ecade193a  sub rsp, 0x08
00007e4ecade193e  push rax
00007e4ecade193f  push rcx
00007e4ecade1940  push rdx
00007e4ecade1941  push rdi
00007e4ecade1942  push rsi
00007e4ecade1943  push r8
00007e4ecade1945  push r9
00007e4ecade1947  push r10
00007e4ecade1949  push r11
00007e4ecade194b  sub rsp, 0xF0
00007e4ecade1952  vmovaps [rsp], xmm0
00007e4ecade1957  vmovaps [rsp+0x10], xmm2
00007e4ecade195d  vmovaps [rsp+0x20], xmm3
00007e4ecade1963  vmovaps [rsp+0x30], xmm4
00007e4ecade1969  vmovaps [rsp+0x40], xmm5
00007e4ecade196f  vmovaps [rsp+0x50], xmm6
00007e4ecade1975  vmovaps [rsp+0x60], xmm7
00007e4ecade197b  vmovaps [rsp+0x70], xmm8
00007e4ecade1981  vmovaps [rsp+0x80], xmm9
00007e4ecade198a  vmovaps [rsp+0x90], xmm10
00007e4ecade1993  vmovaps [rsp+0xA0], xmm11
00007e4ecade199c  vmovaps [rsp+0xB0], xmm12
00007e4ecade19a5  vmovaps [rsp+0xC0], xmm13
00007e4ecade19ae  vmovaps [rsp+0xD0], xmm14
00007e4ecade19b7  vmovaps [rsp+0xE0], xmm15
00007e4ecade19c0  sub rsp, 0x30
00007e4ecade19c4  movaps [rsp], xmm1
00007e4ecade19c8  movaps [rsp+0x10], xmm8
00007e4ecade19ce  movaps [rsp+0x20], xmm9
00007e4ecade19d4  lea rdi, [rsp]
00007e4ecade19d8  mov esi, 0x00
00007e4ecade19dd  mov rax, 0x5784BC1F5530
00007e4ecade19e7  call rax
00007e4ecade19e9  movaps xmm1, [rsp]
00007e4ecade19ed  add rsp, 0x30
00007e4ecade19f1  vmovaps xmm0, [rsp]
00007e4ecade19f6  vmovaps xmm2, [rsp+0x10]
00007e4ecade19fc  vmovaps xmm3, [rsp+0x20]
00007e4ecade1a02  vmovaps xmm4, [rsp+0x30]
00007e4ecade1a08  vmovaps xmm5, [rsp+0x40]
00007e4ecade1a0e  vmovaps xmm6, [rsp+0x50]
00007e4ecade1a14  vmovaps xmm7, [rsp+0x60]
00007e4ecade1a1a  vmovaps xmm8, [rsp+0x70]
00007e4ecade1a20  vmovaps xmm9, [rsp+0x80]
00007e4ecade1a29  vmovaps xmm10, [rsp+0x90]
00007e4ecade1a32  vmovaps xmm11, [rsp+0xA0]
00007e4ecade1a3b  vmovaps xmm12, [rsp+0xB0]
00007e4ecade1a44  vmovaps xmm13, [rsp+0xC0]
00007e4ecade1a4d  vmovaps xmm14, [rsp+0xD0]
00007e4ecade1a56  vmovaps xmm15, [rsp+0xE0]
00007e4ecade1a5f  add rsp, 0xF0
00007e4ecade1a66  pop r11
00007e4ecade1a68  pop r10
00007e4ecade1a6a  pop r9
00007e4ecade1a6c  pop r8
00007e4ecade1a6e  pop rsi
00007e4ecade1a6f  pop rdi
00007e4ecade1a70  pop rdx
00007e4ecade1a71  pop rcx
00007e4ecade1a72  pop rax
00007e4ecade1a73  add rsp, 0x08
00007e4ecade1a77  jmp 0x00007E4ECADDC865
00007e4ecade1a7c  call 0x00007E4ECACE5940
00007e4ecade1a81  jmp 0x00007E4ECADDC873
00007e4ecade1a86  call 0x00007E4ECAC0C380
00007e4ecade1a8b  jmp 0x00007E4ECADDC87D
00007e4ecade1a90  call 0x00007E4ECAC0D600
00007e4ecade1a95  jmp 0x00007E4ECADDC887
00007e4ecade1a9a  call 0x00007E4ECABFF540
00007e4ecade1a9f  jmp 0x00007E4ECADDC891
00007e4ecade1aa4  int3
00007e4ecade1aa5  nop [rax+rax*1], ax
00007e4ecade1aae  nop
00007e4ecade1ab0  mov rax, [r15+0xF8]
00007e4ecade1ab7  lea r14, [rax+0x140]
00007e4ecade1abe  mov r12, [r13+r14*1]
00007e4ecade1ac3  mov [r15+0xE8], r12
00007e4ecade1aca  lea r14, [rax+0x130]
00007e4ecade1ad1  mov r12, [r13+r14*1]
00007e4ecade1ad6  lea r14, [rax+0x138]
00007e4ecade1add  mov r11, [r13+r14*1]
00007e4ecade1ae2  movq xmm1, r12
00007e4ecade1ae7  movq xmm15, r11
00007e4ecade1aec  movq xmm1, xmm1
00007e4ecade1af0  movq xmm1, xmm1
00007e4ecade1af4  movaps [r15+0x1A0], xmm1
00007e4ecade1afc  movq xmm15, xmm15
00007e4ecade1b01  movq xmm15, xmm15
00007e4ecade1b06  movaps [r15+0x190], xmm15
00007e4ecade1b0e  lea r14, [rax+0x120]
00007e4ecade1b15  mov r12, [r13+r14*1]
00007e4ecade1b1a  lea r14, [rax+0x128]
00007e4ecade1b21  mov r11, [r13+r14*1]
00007e4ecade1b26  movq xmm1, r12
00007e4ecade1b2b  movq xmm15, r11
00007e4ecade1b30  movq xmm1, xmm1
00007e4ecade1b34  movq xmm1, xmm1
00007e4ecade1b38  movaps [r15+0x1C0], xmm1
00007e4ecade1b40  movq xmm15, xmm15
00007e4ecade1b45  movq xmm15, xmm15
00007e4ecade1b4a  movaps [r15+0x1B0], xmm15
00007e4ecade1b52  lea r14, [rax+0x110]
00007e4ecade1b59  mov r12, [r13+r14*1]
00007e4ecade1b5e  lea r14, [rax+0x118]
00007e4ecade1b65  mov r11, [r13+r14*1]
00007e4ecade1b6a  movq xmm1, r12
00007e4ecade1b6f  movq xmm15, r11
00007e4ecade1b74  movq xmm1, xmm1
00007e4ecade1b78  movq xmm1, xmm1
00007e4ecade1b7c  movaps [r15+0x1E0], xmm1
00007e4ecade1b84  movq xmm15, xmm15
00007e4ecade1b89  movq xmm15, xmm15
00007e4ecade1b8e  movaps [r15+0x1D0], xmm15
00007e4ecade1b96  lea r14, [rax+0x100]
00007e4ecade1b9d  mov r12, [r13+r14*1]
00007e4ecade1ba2  lea r14, [rax+0x108]
00007e4ecade1ba9  mov r11, [r13+r14*1]
00007e4ecade1bae  movq xmm1, r12
00007e4ecade1bb3  movq xmm15, r11
00007e4ecade1bb8  movq xmm1, xmm1
00007e4ecade1bbc  movq xmm1, xmm1
00007e4ecade1bc0  movaps [r15+0x200], xmm1
00007e4ecade1bc8  movq xmm15, xmm15
00007e4ecade1bcd  movq xmm15, xmm15
00007e4ecade1bd2  movaps [r15+0x1F0], xmm15
00007e4ecade1bda  mov qword ptr [r15+0x40], 0x430000
00007e4ecade1be2  mov r14d, 0x430510
00007e4ecade1be8  mov r12, [r13+r14*1]
00007e4ecade1bed  movq xmm1, r12
00007e4ecade1bf2  lea r14, [rax+0x150]
00007e4ecade1bf9  mov [r15+0xF8], r14
00007e4ecade1c00  mov rax, [r15+0x50]
00007e4ecade1c04  movups xmm15, [r13+rax*1]
00007e4ecade1c0a  movaps [r15+0x120], xmm15
00007e4ecade1c12  mov qword ptr [r15+0x48], 0x10
00007e4ecade1c1a  xor eax, eax
00007e4ecade1c1c  mov r14d, 0x10
00007e4ecade1c22  mov r12d, 0x200
00007e4ecade1c28  cmp r14, r12
00007e4ecade1c2b  cmc
00007e4ecade1c2c  lahf
00007e4ecade1c2d  seto al
00007e4ecade1c30  mov [r15+0x108], eax
00007e4ecade1c37  pextrq rax, xmm15, 0x01
00007e4ecade1c3e  movq xmm14, rax
00007e4ecade1c43  movaps [r15+0x130], xmm14
00007e4ecade1c4b  movq rax, xmm1
00007e4ecade1c50  movq r14, xmm15
00007e4ecade1c55  vmovq xmm1, rax
00007e4ecade1c5a  vmovq xmm15, r14
00007e4ecade1c5f  movaps xmm13, xmm1
00007e4ecade1c63  addsd xmm13, xmm15
00007e4ecade1c68  ucomisd xmm13, xmm13
00007e4ecade1c6d  jp 0x00007E4ECADE1D86
00007e4ecade1c73  movq xmm13, xmm13
00007e4ecade1c78  movq rax, xmm13
00007e4ecade1c7d  movq r14, xmm14
00007e4ecade1c82  vmovq xmm1, rax
00007e4ecade1c87  vmovq xmm15, r14
00007e4ecade1c8c  movaps xmm14, xmm1
00007e4ecade1c90  addsd xmm14, xmm15
00007e4ecade1c95  ucomisd xmm14, xmm14
00007e4ecade1c9a  jp 0x00007E4ECADE1DCE
00007e4ecade1ca0  movq xmm14, xmm14
00007e4ecade1ca5  movaps [r15+0x110], xmm14
00007e4ecade1cad  mov eax, [r15+0x108]
00007e4ecade1cb4  sahf
00007e4ecade1cb5  jnz 0x00007E4ECADE1CE7
00007e4ecade1cb7  cmp dword ptr [r15+0x318], 0x00
00007e4ecade1cbf  jz 0x00007E4ECADE1FE0
00007e4ecade1cc5  nop [rax+rax*1], ax
00007e4ecade1cce  nop [rax+rax*1], eax
00007e4ecade1cd6  mov eax, 0x410490
00007e4ecade1cdb  mov [r15+0x100], rax
00007e4ecade1ce2  jmp 0x00007E4ECABFE110
00007e4ecade1ce7  cmp dword ptr [r15+0x318], 0x00
00007e4ecade1cef  jz 0x00007E4ECADE1E20
00007e4ecade1cf5  nop [rax+rax*1], ax
00007e4ecade1cfe  nop [rax+rax*1], eax
00007e4ecade1d06  mov eax, 0x410474
00007e4ecade1d0b  mov [r15+0x100], rax
00007e4ecade1d12  jmp 0x00007E4ECABFE110
00007e4ecade1d17  int3
00007e4ecade1d18  call 0x00007E4ECACE27E0
00007e4ecade1d1d  jmp 0x00007E4ECADE1AC3
00007e4ecade1d22  call 0x00007E4ECACE27E0
00007e4ecade1d27  jmp 0x00007E4ECADE1AD6
00007e4ecade1d2c  call 0x00007E4ECACE1570
00007e4ecade1d31  jmp 0x00007E4ECADE1AE2
00007e4ecade1d36  call 0x00007E4ECACE27E0
00007e4ecade1d3b  jmp 0x00007E4ECADE1B1A
00007e4ecade1d40  call 0x00007E4ECACE1570
00007e4ecade1d45  jmp 0x00007E4ECADE1B26
00007e4ecade1d4a  call 0x00007E4ECACE27E0
00007e4ecade1d4f  jmp 0x00007E4ECADE1B5E
00007e4ecade1d54  call 0x00007E4ECACE1570
00007e4ecade1d59  jmp 0x00007E4ECADE1B6A
00007e4ecade1d5e  call 0x00007E4ECACE27E0
00007e4ecade1d63  jmp 0x00007E4ECADE1BA2
00007e4ecade1d68  call 0x00007E4ECACE1570
00007e4ecade1d6d  jmp 0x00007E4ECADE1BAE
00007e4ecade1d72  call 0x00007E4ECACE27E0
00007e4ecade1d77  jmp 0x00007E4ECADE1BED
00007e4ecade1d7c  call 0x00007E4ECAC0E760
00007e4ecade1d81  jmp 0x00007E4ECADE1C0A
00007e4ecade1d86  ucomisd xmm1, xmm15
00007e4ecade1d8b  jp 0x00007E4ECADE1D9A
00007e4ecade1d8d  movaps xmm13, [0x00007E4ECA9FE060]
00007e4ecade1d95  jmp 0x00007E4ECADE1C73
00007e4ecade1d9a  vxorps xmm0, xmm1, xmm15
00007e4ecade1d9f  pextrw eax, xmm0, 0x03
00007e4ecade1da4  and eax, 0x7FF8
00007e4ecade1da9  cmp eax, 0x08
00007e4ecade1dac  jnz 0x00007E4ECADE1C73
00007e4ecade1db2  movq rax, xmm15
00007e4ecade1db7  shl rax, 0x0D
00007e4ecade1dbb  jbe 0x00007E4ECADE1C73
00007e4ecade1dc1  vorps xmm13, xmm15, [0x00007E4ECA9FE070]
00007e4ecade1dc9  jmp 0x00007E4ECADE1C73
00007e4ecade1dce  ucomisd xmm1, xmm15
00007e4ecade1dd3  jp 0x00007E4ECADE1DE2
00007e4ecade1dd5  movaps xmm14, [0x00007E4ECA9FE060]
00007e4ecade1ddd  jmp 0x00007E4ECADE1CA0
00007e4ecade1de2  vxorps xmm0, xmm1, xmm15
00007e4ecade1de7  pextrw eax, xmm0, 0x03
00007e4ecade1dec  and eax, 0x7FF8
00007e4ecade1df1  cmp eax, 0x08
00007e4ecade1df4  jnz 0x00007E4ECADE1CA0
00007e4ecade1dfa  movq rax, xmm15
00007e4ecade1dff  shl rax, 0x0D
00007e4ecade1e03  jbe 0x00007E4ECADE1CA0
00007e4ecade1e09  vorps xmm14, xmm15, [0x00007E4ECA9FE070]
00007e4ecade1e11  jmp 0x00007E4ECADE1CA0
00007e4ecade1e16  int3
00007e4ecade1e17  nop [rax+rax*1], ax
00007e4ecade1e20  mov rax, [r15+0x48]
00007e4ecade1e24  mov r14, [r15+0x50]
00007e4ecade1e28  lea r12, [r14+rax*1]
00007e4ecade1e2c  movups xmm1, [r13+r12*1]
00007e4ecade1e32  movaps [r15+0x120], xmm1
00007e4ecade1e3a  lea r14, [rax+0x10]
00007e4ecade1e3e  mov [r15+0x48], r14
00007e4ecade1e42  xor eax, eax
00007e4ecade1e44  mov r12d, 0x200
00007e4ecade1e4a  cmp r14, r12
00007e4ecade1e4d  cmc
00007e4ecade1e4e  lahf
00007e4ecade1e4f  seto al
00007e4ecade1e52  mov [r15+0x108], eax
00007e4ecade1e59  pextrq rax, xmm1, 0x01
00007e4ecade1e60  movq xmm15, rax
00007e4ecade1e65  movaps [r15+0x130], xmm15
00007e4ecade1e6d  movaps xmm14, [r15+0x110]
00007e4ecade1e75  movq rax, xmm14
00007e4ecade1e7a  movq r14, xmm1
00007e4ecade1e7f  vmovq xmm1, rax
00007e4ecade1e84  vmovq xmm14, r14
00007e4ecade1e89  movaps xmm13, xmm1
00007e4ecade1e8d  addsd xmm13, xmm14
00007e4ecade1e92  ucomisd xmm13, xmm13
00007e4ecade1e97  jp 0x00007E4ECADE1F4C
00007e4ecade1e9d  movq xmm13, xmm13
00007e4ecade1ea2  movq rax, xmm13
00007e4ecade1ea7  movq r14, xmm15
00007e4ecade1eac  vmovq xmm1, rax
00007e4ecade1eb1  vmovq xmm15, r14
00007e4ecade1eb6  movaps xmm14, xmm1
00007e4ecade1eba  addsd xmm14, xmm15
00007e4ecade1ebf  ucomisd xmm14, xmm14
00007e4ecade1ec4  jp 0x00007E4ECADE1F94
00007e4ecade1eca  movq xmm14, xmm14
00007e4ecade1ecf  movaps [r15+0x110], xmm14
00007e4ecade1ed7  mov eax, [r15+0x108]
00007e4ecade1ede  sahf
00007e4ecade1edf  jnz 0x00007E4ECADE1F11
00007e4ecade1ee1  cmp dword ptr [r15+0x318], 0x00
00007e4ecade1ee9  jz 0x00007E4ECADE1FE0
00007e4ecade1eef  nop [rax+rax*1], ax
00007e4ecade1ef8  nop [rax+rax*1], eax
00007e4ecade1f00  mov eax, 0x410490
00007e4ecade1f05  mov [r15+0x100], rax
00007e4ecade1f0c  jmp 0x00007E4ECABFE110
00007e4ecade1f11  cmp dword ptr [r15+0x318], 0x00
00007e4ecade1f19  jz 0x00007E4ECADE1E20
00007e4ecade1f1f  nop [rax+rax*1], ax
00007e4ecade1f28  nop [rax+rax*1], eax
00007e4ecade1f30  mov eax, 0x410474
00007e4ecade1f35  mov [r15+0x100], rax
00007e4ecade1f3c  jmp 0x00007E4ECABFE110
00007e4ecade1f41  int3
00007e4ecade1f42  call 0x00007E4ECACB52F0
00007e4ecade1f47  jmp 0x00007E4ECADE1E32
00007e4ecade1f4c  ucomisd xmm1, xmm14
00007e4ecade1f51  jp 0x00007E4ECADE1F60
00007e4ecade1f53  movaps xmm13, [0x00007E4ECA9FE060]
00007e4ecade1f5b  jmp 0x00007E4ECADE1E9D
00007e4ecade1f60  vxorps xmm0, xmm1, xmm14
00007e4ecade1f65  pextrw eax, xmm0, 0x03
00007e4ecade1f6a  and eax, 0x7FF8
00007e4ecade1f6f  cmp eax, 0x08
00007e4ecade1f72  jnz 0x00007E4ECADE1E9D
00007e4ecade1f78  movq rax, xmm14
00007e4ecade1f7d  shl rax, 0x0D
00007e4ecade1f81  jbe 0x00007E4ECADE1E9D
00007e4ecade1f87  vorps xmm13, xmm14, [0x00007E4ECA9FE070]
00007e4ecade1f8f  jmp 0x00007E4ECADE1E9D
00007e4ecade1f94  ucomisd xmm1, xmm15
00007e4ecade1f99  jp 0x00007E4ECADE1FA8
00007e4ecade1f9b  movaps xmm14, [0x00007E4ECA9FE060]
00007e4ecade1fa3  jmp 0x00007E4ECADE1ECA
00007e4ecade1fa8  vxorps xmm0, xmm1, xmm15
00007e4ecade1fad  pextrw eax, xmm0, 0x03
00007e4ecade1fb2  and eax, 0x7FF8
00007e4ecade1fb7  cmp eax, 0x08
00007e4ecade1fba  jnz 0x00007E4ECADE1ECA
00007e4ecade1fc0  movq rax, xmm15
00007e4ecade1fc5  shl rax, 0x0D
00007e4ecade1fc9  jbe 0x00007E4ECADE1ECA
00007e4ecade1fcf  vorps xmm14, xmm15, [0x00007E4ECA9FE070]
00007e4ecade1fd7  jmp 0x00007E4ECADE1ECA
00007e4ecade1fdc  int3
00007e4ecade1fdd  nop [rax], eax
00007e4ecade1fe0  mov rax, [r15+0x40]
00007e4ecade1fe4  lea r14, [rax+0x510]
00007e4ecade1feb  movaps xmm1, [r15+0x110]
00007e4ecade1ff3  movq rax, xmm1
00007e4ecade1ff8  mov [r13+r14*1], rax
00007e4ecade1ffd  mov rax, [r15+0xF0]
00007e4ecade2004  mov [r15+0x100], rax
00007e4ecade200b  jmp 0x00007E4ECADCE5C0
00007e4ecade2010  int3
00007e4ecade2011  call 0x00007E4ECACD5EB0
00007e4ecade2016  jmp 0x00007E4ECADE1FFD
00007e4ecade201b  int3
00007e4ecade201c  nop [rax], eax
00007e4ecade2020  mov qword ptr [r15+0x100], 0x04
00007e4ecade202b  mov esi, 0x00
00007e4ecade2030  mov edx, 0x09
00007e4ecade2035  mov rdi, 0x7FFC3C6F52A0
00007e4ecade203f  mov rax, 0x5784BC088970
00007e4ecade2049  call rax
00007e4ecade204b  cmp dword ptr [r15+0x318], 0x00
00007e4ecade2053  jnz 0x00007E4ECABFE110
00007e4ecade2059  jmp 0x00007E4ECABFE0A0
00007e4ecade205e  int3
00007e4ecade205f  int3
