0000786bc93ce69b  nop [rax+rax*1], eax
0000786bc93ce6a0  vmovaps xmm1, [0x0000786BC8FFE010]
0000786bc93ce6a8  movq xmm1, xmm1
0000786bc93ce6ac  movaps [r15+0x110], xmm1
0000786bc93ce6b4  vmovaps xmm1, [0x0000786BC8FFE020]
0000786bc93ce6bc  movq xmm1, xmm1
0000786bc93ce6c0  movaps [r15+0x120], xmm1
0000786bc93ce6c8  mov eax, 0x4204C0
0000786bc93ce6cd  mov r14, [r13+rax*1]
0000786bc93ce6d2  movq xmm1, r14
0000786bc93ce6d7  movaps [r15+0x130], xmm1
0000786bc93ce6df  vmovaps xmm1, [0x0000786BC8FFE030]
0000786bc93ce6e7  vpbroadcastq xmm1, xmm1
0000786bc93ce6ec  movaps [r15+0x140], xmm1
0000786bc93ce6f4  mov qword ptr [r15+0x40], 0x02
0000786bc93ce6fc  vmovaps xmm15, [0x0000786BC8FFE040]
0000786bc93ce704  movq xmm15, xmm15
0000786bc93ce709  movaps [r15+0x150], xmm15
0000786bc93ce711  mov qword ptr [r15+0x58], 0x420000
0000786bc93ce719  vmovaps xmm15, [0x0000786BC8FFE050]
0000786bc93ce721  vpbroadcastq xmm15, xmm15
0000786bc93ce726  movaps [r15+0x160], xmm15
0000786bc93ce72e  mov rax, [r15+0x40]
0000786bc93ce732  vmovq xmm14, rax
0000786bc93ce737  vpbroadcastq xmm14, xmm14
0000786bc93ce73c  movaps [r15+0x170], xmm14
0000786bc93ce744  mov eax, 0x4204D0
0000786bc93ce749  movups xmm13, [r13+rax*1]
0000786bc93ce74f  mov qword ptr [r15+0x40], 0x430518
0000786bc93ce757  mov qword ptr [r15+0x50], 0x430720
0000786bc93ce75f  vpmovqd xmm12, xmm13
0000786bc93ce765  pxor xmm11, xmm11
0000786bc93ce76a  punpcklqdq xmm12, xmm11
0000786bc93ce76f  movaps [r15+0x210], xmm12
0000786bc93ce777  movq xmm12, qword ptr [r15+0x120]
0000786bc93ce780  movq xmm11, qword ptr [r15+0x130]
0000786bc93ce789  psubd xmm12, xmm11
0000786bc93ce78e  movq xmm12, xmm12
0000786bc93ce793  paddq xmm13, xmm14
0000786bc93ce798  movaps [r15+0x180], xmm13
0000786bc93ce7a0  movq xmm14, qword ptr [r15+0x150]
0000786bc93ce7a9  paddd xmm11, xmm14
0000786bc93ce7ae  movq xmm11, xmm11
0000786bc93ce7b3  movq xmm11, xmm11
0000786bc93ce7b8  movaps [r15+0x130], xmm11
0000786bc93ce7c0  pmovzxdq xmm12, xmm12
0000786bc93ce7c6  psllq xmm12, 0x00
0000786bc93ce7cc  movq xmm14, qword ptr [r15+0x210]
0000786bc93ce7d5  movq xmm13, qword ptr [r15+0x110]
0000786bc93ce7de  paddd xmm14, xmm13
0000786bc93ce7e3  movq xmm14, xmm14
0000786bc93ce7e8  vcvtuqq2pd xmm12, xmm12
0000786bc93ce7ee  pmovzxdq xmm14, xmm14
0000786bc93ce7f4  psllq xmm14, 0x00
0000786bc93ce7fa  vcvtuqq2pd xmm14, xmm14
0000786bc93ce800  movaps xmm13, xmm12
0000786bc93ce804  mulpd xmm13, xmm1
0000786bc93ce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000786bc93ce80f  ptest xmm11, xmm11
0000786bc93ce815  jnz 0x0000786BC93CE8FF
0000786bc93ce81b  movaps [r15+0x220], xmm13
0000786bc93ce823  mov eax, 0x430720
0000786bc93ce828  movups [r13+rax*1], xmm13
0000786bc93ce82e  movaps xmm1, xmm14
0000786bc93ce832  mulpd xmm1, xmm15
0000786bc93ce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000786bc93ce83c  ptest xmm13, xmm13
0000786bc93ce842  jnz 0x0000786BC93CEA4C
0000786bc93ce848  movaps [r15+0x210], xmm1
0000786bc93ce850  mov eax, 0x430518
0000786bc93ce855  movups [r13+rax*1], xmm1
0000786bc93ce85b  mov qword ptr [r15+0x48], 0x10
0000786bc93ce863  xor eax, eax
0000786bc93ce865  mov r14d, 0x10
0000786bc93ce86b  mov r12d, 0x200
0000786bc93ce871  cmp r14, r12
0000786bc93ce874  cmc
0000786bc93ce875  lahf
0000786bc93ce876  seto al
0000786bc93ce879  mov [r15+0x108], eax
0000786bc93ce880  mov eax, [r15+0x108]
0000786bc93ce887  sahf
0000786bc93ce888  jnz 0x0000786BC93CE8BA
0000786bc93ce88a  cmp dword ptr [r15+0x318], 0x00
0000786bc93ce892  jz 0x0000786BC93CEFF0
0000786bc93ce898  nop [rax+rax*1], ax
0000786bc93ce8a1  nop [rax+rax*1], eax
0000786bc93ce8a9  mov eax, 0x4101EC
0000786bc93ce8ae  mov [r15+0x100], rax
0000786bc93ce8b5  jmp 0x0000786BC91FE110
0000786bc93ce8ba  cmp dword ptr [r15+0x318], 0x00
0000786bc93ce8c2  jz 0x0000786BC93CEBA0
0000786bc93ce8c8  nop [rax+rax*1], ax
0000786bc93ce8d1  nop [rax+rax*1], eax
0000786bc93ce8d9  mov eax, 0x4101AC
0000786bc93ce8de  mov [r15+0x100], rax
0000786bc93ce8e5  jmp 0x0000786BC91FE110
0000786bc93ce8ea  int3
0000786bc93ce8eb  call 0x0000786BC920DC20
0000786bc93ce8f0  jmp 0x0000786BC93CE6D2
0000786bc93ce8f5  call 0x0000786BC920C260
0000786bc93ce8fa  jmp 0x0000786BC93CE74F
0000786bc93ce8ff  sub rsp, 0x08
0000786bc93ce903  push rax
0000786bc93ce904  push rcx
0000786bc93ce905  push rdx
0000786bc93ce906  push rdi
0000786bc93ce907  push rsi
0000786bc93ce908  push r8
0000786bc93ce90a  push r9
0000786bc93ce90c  push r10
0000786bc93ce90e  push r11
0000786bc93ce910  sub rsp, 0xF0
0000786bc93ce917  vmovaps [rsp], xmm0
0000786bc93ce91c  vmovaps [rsp+0x10], xmm1
0000786bc93ce922  vmovaps [rsp+0x20], xmm2
0000786bc93ce928  vmovaps [rsp+0x30], xmm3
0000786bc93ce92e  vmovaps [rsp+0x40], xmm4
0000786bc93ce934  vmovaps [rsp+0x50], xmm5
0000786bc93ce93a  vmovaps [rsp+0x60], xmm6
0000786bc93ce940  vmovaps [rsp+0x70], xmm7
0000786bc93ce946  vmovaps [rsp+0x80], xmm8
0000786bc93ce94f  vmovaps [rsp+0x90], xmm9
0000786bc93ce958  vmovaps [rsp+0xA0], xmm10
0000786bc93ce961  vmovaps [rsp+0xB0], xmm11
0000786bc93ce96a  vmovaps [rsp+0xC0], xmm12
0000786bc93ce973  vmovaps [rsp+0xD0], xmm14
0000786bc93ce97c  vmovaps [rsp+0xE0], xmm15
0000786bc93ce985  sub rsp, 0x30
0000786bc93ce989  movaps [rsp], xmm13
0000786bc93ce98e  movaps [rsp+0x10], xmm12
0000786bc93ce994  movaps [rsp+0x20], xmm1
0000786bc93ce999  lea rdi, [rsp]
0000786bc93ce99d  mov esi, 0x00
0000786bc93ce9a2  mov rax, 0x60810F6F7530
0000786bc93ce9ac  call rax
0000786bc93ce9ae  movaps xmm13, [rsp]
0000786bc93ce9b3  add rsp, 0x30
0000786bc93ce9b7  vmovaps xmm0, [rsp]
0000786bc93ce9bc  vmovaps xmm1, [rsp+0x10]
0000786bc93ce9c2  vmovaps xmm2, [rsp+0x20]
0000786bc93ce9c8  vmovaps xmm3, [rsp+0x30]
0000786bc93ce9ce  vmovaps xmm4, [rsp+0x40]
0000786bc93ce9d4  vmovaps xmm5, [rsp+0x50]
0000786bc93ce9da  vmovaps xmm6, [rsp+0x60]
0000786bc93ce9e0  vmovaps xmm7, [rsp+0x70]
0000786bc93ce9e6  vmovaps xmm8, [rsp+0x80]
0000786bc93ce9ef  vmovaps xmm9, [rsp+0x90]
0000786bc93ce9f8  vmovaps xmm10, [rsp+0xA0]
0000786bc93cea01  vmovaps xmm11, [rsp+0xB0]
0000786bc93cea0a  vmovaps xmm12, [rsp+0xC0]
0000786bc93cea13  vmovaps xmm14, [rsp+0xD0]
0000786bc93cea1c  vmovaps xmm15, [rsp+0xE0]
0000786bc93cea25  add rsp, 0xF0
0000786bc93cea2c  pop r11
0000786bc93cea2e  pop r10
0000786bc93cea30  pop r9
0000786bc93cea32  pop r8
0000786bc93cea34  pop rsi
0000786bc93cea35  pop rdi
0000786bc93cea36  pop rdx
0000786bc93cea37  pop rcx
0000786bc93cea38  pop rax
0000786bc93cea39  add rsp, 0x08
0000786bc93cea3d  jmp 0x0000786BC93CE81B
0000786bc93cea42  call 0x0000786BC920C380
0000786bc93cea47  jmp 0x0000786BC93CE82E
0000786bc93cea4c  sub rsp, 0x08
0000786bc93cea50  push rax
0000786bc93cea51  push rcx
0000786bc93cea52  push rdx
0000786bc93cea53  push rdi
0000786bc93cea54  push rsi
0000786bc93cea55  push r8
0000786bc93cea57  push r9
0000786bc93cea59  push r10
0000786bc93cea5b  push r11
0000786bc93cea5d  sub rsp, 0xF0
0000786bc93cea64  vmovaps [rsp], xmm0
0000786bc93cea69  vmovaps [rsp+0x10], xmm2
0000786bc93cea6f  vmovaps [rsp+0x20], xmm3
0000786bc93cea75  vmovaps [rsp+0x30], xmm4
0000786bc93cea7b  vmovaps [rsp+0x40], xmm5
0000786bc93cea81  vmovaps [rsp+0x50], xmm6
0000786bc93cea87  vmovaps [rsp+0x60], xmm7
0000786bc93cea8d  vmovaps [rsp+0x70], xmm8
0000786bc93cea93  vmovaps [rsp+0x80], xmm9
0000786bc93cea9c  vmovaps [rsp+0x90], xmm10
0000786bc93ceaa5  vmovaps [rsp+0xA0], xmm11
0000786bc93ceaae  vmovaps [rsp+0xB0], xmm12
0000786bc93ceab7  vmovaps [rsp+0xC0], xmm13
0000786bc93ceac0  vmovaps [rsp+0xD0], xmm14
0000786bc93ceac9  vmovaps [rsp+0xE0], xmm15
0000786bc93cead2  sub rsp, 0x30
0000786bc93cead6  movaps [rsp], xmm1
0000786bc93ceada  movaps [rsp+0x10], xmm14
0000786bc93ceae0  movaps [rsp+0x20], xmm15
0000786bc93ceae6  lea rdi, [rsp]
0000786bc93ceaea  mov esi, 0x00
0000786bc93ceaef  mov rax, 0x60810F6F7530
0000786bc93ceaf9  call rax
0000786bc93ceafb  movaps xmm1, [rsp]
0000786bc93ceaff  add rsp, 0x30
0000786bc93ceb03  vmovaps xmm0, [rsp]
0000786bc93ceb08  vmovaps xmm2, [rsp+0x10]
0000786bc93ceb0e  vmovaps xmm3, [rsp+0x20]
0000786bc93ceb14  vmovaps xmm4, [rsp+0x30]
0000786bc93ceb1a  vmovaps xmm5, [rsp+0x40]
0000786bc93ceb20  vmovaps xmm6, [rsp+0x50]
0000786bc93ceb26  vmovaps xmm7, [rsp+0x60]
0000786bc93ceb2c  vmovaps xmm8, [rsp+0x70]
0000786bc93ceb32  vmovaps xmm9, [rsp+0x80]
0000786bc93ceb3b  vmovaps xmm10, [rsp+0x90]
0000786bc93ceb44  vmovaps xmm11, [rsp+0xA0]
0000786bc93ceb4d  vmovaps xmm12, [rsp+0xB0]
0000786bc93ceb56  vmovaps xmm13, [rsp+0xC0]
0000786bc93ceb5f  vmovaps xmm14, [rsp+0xD0]
0000786bc93ceb68  vmovaps xmm15, [rsp+0xE0]
0000786bc93ceb71  add rsp, 0xF0
0000786bc93ceb78  pop r11
0000786bc93ceb7a  pop r10
0000786bc93ceb7c  pop r9
0000786bc93ceb7e  pop r8
0000786bc93ceb80  pop rsi
0000786bc93ceb81  pop rdi
0000786bc93ceb82  pop rdx
0000786bc93ceb83  pop rcx
0000786bc93ceb84  pop rax
0000786bc93ceb85  add rsp, 0x08
0000786bc93ceb89  jmp 0x0000786BC93CE848
0000786bc93ceb8e  call 0x0000786BC91FF540
0000786bc93ceb93  jmp 0x0000786BC93CE85B
0000786bc93ceb98  int3
0000786bc93ceb99  nop [rax], eax
0000786bc93ceba0  movaps xmm1, [r15+0x180]
0000786bc93ceba8  vpmovqd xmm15, xmm1
0000786bc93cebae  pxor xmm14, xmm14
0000786bc93cebb3  punpcklqdq xmm15, xmm14
0000786bc93cebb8  movaps [r15+0x210], xmm15
0000786bc93cebc0  movq xmm15, qword ptr [r15+0x120]
0000786bc93cebc9  movq xmm14, qword ptr [r15+0x130]
0000786bc93cebd2  psubd xmm15, xmm14
0000786bc93cebd7  movq xmm15, xmm15
0000786bc93cebdc  movaps xmm13, [r15+0x170]
0000786bc93cebe4  paddq xmm1, xmm13
0000786bc93cebe9  movaps [r15+0x180], xmm1
0000786bc93cebf1  movq xmm1, qword ptr [r15+0x150]
0000786bc93cebfa  paddd xmm14, xmm1
0000786bc93cebff  movq xmm14, xmm14
0000786bc93cec04  movq xmm14, xmm14
0000786bc93cec09  movaps [r15+0x130], xmm14
0000786bc93cec11  pmovzxdq xmm15, xmm15
0000786bc93cec17  psllq xmm15, 0x00
0000786bc93cec1d  movq xmm1, qword ptr [r15+0x210]
0000786bc93cec26  movq xmm14, qword ptr [r15+0x110]
0000786bc93cec2f  paddd xmm1, xmm14
0000786bc93cec34  movq xmm1, xmm1
0000786bc93cec38  vcvtuqq2pd xmm15, xmm15
0000786bc93cec3e  pmovzxdq xmm1, xmm1
0000786bc93cec43  psllq xmm1, 0x00
0000786bc93cec48  vcvtuqq2pd xmm1, xmm1
0000786bc93cec4e  movaps xmm14, [r15+0x140]
0000786bc93cec56  movaps xmm13, xmm15
0000786bc93cec5a  mulpd xmm13, xmm14
0000786bc93cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000786bc93cec65  ptest xmm12, xmm12
0000786bc93cec6b  jnz 0x0000786BC93CED4E
0000786bc93cec71  movaps [r15+0x220], xmm13
0000786bc93cec79  mov rax, [r15+0x48]
0000786bc93cec7d  mov r14, [r15+0x50]
0000786bc93cec81  lea r12, [r14+rax*1]
0000786bc93cec85  movups [r13+r12*1], xmm13
0000786bc93cec8b  movaps xmm15, [r15+0x160]
0000786bc93cec93  movaps xmm14, xmm1
0000786bc93cec97  mulpd xmm14, xmm15
0000786bc93cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000786bc93ceca2  ptest xmm13, xmm13
0000786bc93ceca8  jnz 0x0000786BC93CEE9C
0000786bc93cecae  movaps [r15+0x210], xmm14
0000786bc93cecb6  mov r14, [r15+0x40]
0000786bc93cecba  lea r12, [r14+rax*1]
0000786bc93cecbe  movups [r13+r12*1], xmm14
0000786bc93cecc4  lea r14, [rax+0x10]
0000786bc93cecc8  mov [r15+0x48], r14
0000786bc93ceccc  xor eax, eax
0000786bc93cecce  mov r12d, 0x200
0000786bc93cecd4  cmp r14, r12
0000786bc93cecd7  cmc
0000786bc93cecd8  lahf
0000786bc93cecd9  seto al
0000786bc93cecdc  mov [r15+0x108], eax
0000786bc93cece3  mov eax, [r15+0x108]
0000786bc93cecea  sahf
0000786bc93ceceb  jnz 0x0000786BC93CED1D
0000786bc93ceced  cmp dword ptr [r15+0x318], 0x00
0000786bc93cecf5  jz 0x0000786BC93CEFF0
0000786bc93cecfb  nop [rax+rax*1], ax
0000786bc93ced04  nop [rax+rax*1], eax
0000786bc93ced0c  mov eax, 0x4101EC
0000786bc93ced11  mov [r15+0x100], rax
0000786bc93ced18  jmp 0x0000786BC91FE110
0000786bc93ced1d  cmp dword ptr [r15+0x318], 0x00
0000786bc93ced25  jz 0x0000786BC93CEBA0
0000786bc93ced2b  nop [rax+rax*1], ax
0000786bc93ced34  nop [rax+rax*1], eax
0000786bc93ced3c  mov eax, 0x4101AC
0000786bc93ced41  mov [r15+0x100], rax
0000786bc93ced48  jmp 0x0000786BC91FE110
0000786bc93ced4d  int3
0000786bc93ced4e  sub rsp, 0x08
0000786bc93ced52  push rax
0000786bc93ced53  push rcx
0000786bc93ced54  push rdx
0000786bc93ced55  push rdi
0000786bc93ced56  push rsi
0000786bc93ced57  push r8
0000786bc93ced59  push r9
0000786bc93ced5b  push r10
0000786bc93ced5d  push r11
0000786bc93ced5f  sub rsp, 0xF0
0000786bc93ced66  vmovaps [rsp], xmm0
0000786bc93ced6b  vmovaps [rsp+0x10], xmm1
0000786bc93ced71  vmovaps [rsp+0x20], xmm2
0000786bc93ced77  vmovaps [rsp+0x30], xmm3
0000786bc93ced7d  vmovaps [rsp+0x40], xmm4
0000786bc93ced83  vmovaps [rsp+0x50], xmm5
0000786bc93ced89  vmovaps [rsp+0x60], xmm6
0000786bc93ced8f  vmovaps [rsp+0x70], xmm7
0000786bc93ced95  vmovaps [rsp+0x80], xmm8
0000786bc93ced9e  vmovaps [rsp+0x90], xmm9
0000786bc93ceda7  vmovaps [rsp+0xA0], xmm10
0000786bc93cedb0  vmovaps [rsp+0xB0], xmm11
0000786bc93cedb9  vmovaps [rsp+0xC0], xmm12
0000786bc93cedc2  vmovaps [rsp+0xD0], xmm14
0000786bc93cedcb  vmovaps [rsp+0xE0], xmm15
0000786bc93cedd4  sub rsp, 0x30
0000786bc93cedd8  movaps [rsp], xmm13
0000786bc93ceddd  movaps [rsp+0x10], xmm15
0000786bc93cede3  movaps [rsp+0x20], xmm14
0000786bc93cede9  lea rdi, [rsp]
0000786bc93ceded  mov esi, 0x00
0000786bc93cedf2  mov rax, 0x60810F6F7530
0000786bc93cedfc  call rax
0000786bc93cedfe  movaps xmm13, [rsp]
0000786bc93cee03  add rsp, 0x30
0000786bc93cee07  vmovaps xmm0, [rsp]
0000786bc93cee0c  vmovaps xmm1, [rsp+0x10]
0000786bc93cee12  vmovaps xmm2, [rsp+0x20]
0000786bc93cee18  vmovaps xmm3, [rsp+0x30]
0000786bc93cee1e  vmovaps xmm4, [rsp+0x40]
0000786bc93cee24  vmovaps xmm5, [rsp+0x50]
0000786bc93cee2a  vmovaps xmm6, [rsp+0x60]
0000786bc93cee30  vmovaps xmm7, [rsp+0x70]
0000786bc93cee36  vmovaps xmm8, [rsp+0x80]
0000786bc93cee3f  vmovaps xmm9, [rsp+0x90]
0000786bc93cee48  vmovaps xmm10, [rsp+0xA0]
0000786bc93cee51  vmovaps xmm11, [rsp+0xB0]
0000786bc93cee5a  vmovaps xmm12, [rsp+0xC0]
0000786bc93cee63  vmovaps xmm14, [rsp+0xD0]
0000786bc93cee6c  vmovaps xmm15, [rsp+0xE0]
0000786bc93cee75  add rsp, 0xF0
0000786bc93cee7c  pop r11
0000786bc93cee7e  pop r10
0000786bc93cee80  pop r9
0000786bc93cee82  pop r8
0000786bc93cee84  pop rsi
0000786bc93cee85  pop rdi
0000786bc93cee86  pop rdx
0000786bc93cee87  pop rcx
0000786bc93cee88  pop rax
0000786bc93cee89  add rsp, 0x08
0000786bc93cee8d  jmp 0x0000786BC93CEC71
0000786bc93cee92  call 0x0000786BC92C2240
0000786bc93cee97  jmp 0x0000786BC93CEC8B
0000786bc93cee9c  sub rsp, 0x08
0000786bc93ceea0  push rax
0000786bc93ceea1  push rcx
0000786bc93ceea2  push rdx
0000786bc93ceea3  push rdi
0000786bc93ceea4  push rsi
0000786bc93ceea5  push r8
0000786bc93ceea7  push r9
0000786bc93ceea9  push r10
0000786bc93ceeab  push r11
0000786bc93ceead  sub rsp, 0xF0
0000786bc93ceeb4  vmovaps [rsp], xmm0
0000786bc93ceeb9  vmovaps [rsp+0x10], xmm1
0000786bc93ceebf  vmovaps [rsp+0x20], xmm2
0000786bc93ceec5  vmovaps [rsp+0x30], xmm3
0000786bc93ceecb  vmovaps [rsp+0x40], xmm4
0000786bc93ceed1  vmovaps [rsp+0x50], xmm5
0000786bc93ceed7  vmovaps [rsp+0x60], xmm6
0000786bc93ceedd  vmovaps [rsp+0x70], xmm7
0000786bc93ceee3  vmovaps [rsp+0x80], xmm8
0000786bc93ceeec  vmovaps [rsp+0x90], xmm9
0000786bc93ceef5  vmovaps [rsp+0xA0], xmm10
0000786bc93ceefe  vmovaps [rsp+0xB0], xmm11
0000786bc93cef07  vmovaps [rsp+0xC0], xmm12
0000786bc93cef10  vmovaps [rsp+0xD0], xmm13
0000786bc93cef19  vmovaps [rsp+0xE0], xmm15
0000786bc93cef22  sub rsp, 0x30
0000786bc93cef26  movaps [rsp], xmm14
0000786bc93cef2b  movaps [rsp+0x10], xmm1
0000786bc93cef30  movaps [rsp+0x20], xmm15
0000786bc93cef36  lea rdi, [rsp]
0000786bc93cef3a  mov esi, 0x00
0000786bc93cef3f  mov rax, 0x60810F6F7530
0000786bc93cef49  call rax
0000786bc93cef4b  movaps xmm14, [rsp]
0000786bc93cef50  add rsp, 0x30
0000786bc93cef54  vmovaps xmm0, [rsp]
0000786bc93cef59  vmovaps xmm1, [rsp+0x10]
0000786bc93cef5f  vmovaps xmm2, [rsp+0x20]
0000786bc93cef65  vmovaps xmm3, [rsp+0x30]
0000786bc93cef6b  vmovaps xmm4, [rsp+0x40]
0000786bc93cef71  vmovaps xmm5, [rsp+0x50]
0000786bc93cef77  vmovaps xmm6, [rsp+0x60]
0000786bc93cef7d  vmovaps xmm7, [rsp+0x70]
0000786bc93cef83  vmovaps xmm8, [rsp+0x80]
0000786bc93cef8c  vmovaps xmm9, [rsp+0x90]
0000786bc93cef95  vmovaps xmm10, [rsp+0xA0]
0000786bc93cef9e  vmovaps xmm11, [rsp+0xB0]
0000786bc93cefa7  vmovaps xmm12, [rsp+0xC0]
0000786bc93cefb0  vmovaps xmm13, [rsp+0xD0]
0000786bc93cefb9  vmovaps xmm15, [rsp+0xE0]
0000786bc93cefc2  add rsp, 0xF0
0000786bc93cefc9  pop r11
0000786bc93cefcb  pop r10
0000786bc93cefcd  pop r9
0000786bc93cefcf  pop r8
0000786bc93cefd1  pop rsi
0000786bc93cefd2  pop rdi
0000786bc93cefd3  pop rdx
0000786bc93cefd4  pop rcx
0000786bc93cefd5  pop rax
0000786bc93cefd6  add rsp, 0x08
0000786bc93cefda  jmp 0x0000786BC93CECAE
0000786bc93cefdf  call 0x0000786BC92C34C0
0000786bc93cefe4  jmp 0x0000786BC93CECC4
0000786bc93cefe9  int3
0000786bc93cefea  nop [rax+rax*1], ax
0000786bc93ceff0  mov rax, [r15+0xF8]
0000786bc93ceff7  lea r14, [rax-0x150]
0000786bc93ceffe  mov [r15+0xF8], r14
0000786bc93cf005  mov rax, [r15+0x50]
0000786bc93cf009  lea r12, [rax+0x80]
0000786bc93cf010  movups xmm1, [r13+r12*1]
0000786bc93cf016  lea r12, [rax+0x90]
0000786bc93cf01d  movups xmm15, [r13+r12*1]
0000786bc93cf023  mov qword ptr [r15+0x48], 0x00
0000786bc93cf02b  lea r12, [rax+0x40]
0000786bc93cf02f  movups xmm14, [r13+r12*1]
0000786bc93cf035  lea r12, [rax+0x50]
0000786bc93cf039  movups xmm13, [r13+r12*1]
0000786bc93cf03f  lea r12, [r14+0x120]
0000786bc93cf046  movq xmm12, qword ptr [r15+0x1C0]
0000786bc93cf04f  movq xmm11, qword ptr [r15+0x1B0]
0000786bc93cf058  movq r11, xmm12
0000786bc93cf05d  movq r10, xmm11
0000786bc93cf062  mov [r13+r12*1], r11
0000786bc93cf067  lea r12, [r14+0x128]
0000786bc93cf06e  mov [r13+r12*1], r10
0000786bc93cf073  vxorps xmm12, xmm12, xmm12
0000786bc93cf078  vpbroadcastq xmm12, xmm12
0000786bc93cf07d  lea r12, [r14+0x100]
0000786bc93cf084  movq xmm11, qword ptr [r15+0x200]
0000786bc93cf08d  movq xmm10, qword ptr [r15+0x1F0]
0000786bc93cf096  movq r11, xmm11
0000786bc93cf09b  movq r10, xmm10
0000786bc93cf0a0  mov [r13+r12*1], r11
0000786bc93cf0a5  lea r12, [r14+0x108]
0000786bc93cf0ac  mov [r13+r12*1], r10
0000786bc93cf0b1  lea r12, [r14+0xE0]
0000786bc93cf0b8  movups [r13+r12*1], xmm15
0000786bc93cf0be  lea r12, [r14+0xF0]
0000786bc93cf0c5  movups [r13+r12*1], xmm1
0000786bc93cf0cb  lea r12, [rax+0xC0]
0000786bc93cf0d2  movups xmm1, [r13+r12*1]
0000786bc93cf0d8  lea r12, [rax+0xD0]
0000786bc93cf0df  movups xmm15, [r13+r12*1]
0000786bc93cf0e5  lea r12, [r14+0x110]
0000786bc93cf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000786bc93cf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000786bc93cf0fe  movq r11, xmm11
0000786bc93cf103  movq r10, xmm10
0000786bc93cf108  mov [r13+r12*1], r11
0000786bc93cf10d  lea r12, [r14+0x118]
0000786bc93cf114  mov [r13+r12*1], r10
0000786bc93cf119  movups xmm11, [r13+rax*1]
0000786bc93cf11f  lea r12, [rax+0x10]
0000786bc93cf123  movups xmm10, [r13+r12*1]
0000786bc93cf129  lea r12, [r14+0x130]
0000786bc93cf130  movq xmm9, qword ptr [r15+0x1A0]
0000786bc93cf139  movq xmm8, qword ptr [r15+0x190]
0000786bc93cf142  movq r11, xmm9
0000786bc93cf147  movq r10, xmm8
0000786bc93cf14c  mov [r13+r12*1], r11
0000786bc93cf151  lea r12, [r14+0x138]
0000786bc93cf158  mov [r13+r12*1], r10
0000786bc93cf15d  lea r12, [rax+0x140]
0000786bc93cf164  movups xmm9, [r13+r12*1]
0000786bc93cf16a  lea r12, [rax+0x150]
0000786bc93cf171  movups xmm8, [r13+r12*1]
0000786bc93cf177  lea r12, [r14+0xC0]
0000786bc93cf17e  movups [r13+r12*1], xmm15
0000786bc93cf184  lea r12, [r14+0xD0]
0000786bc93cf18b  movups [r13+r12*1], xmm1
0000786bc93cf191  lea r12, [rax+0x100]
0000786bc93cf198  movups xmm1, [r13+r12*1]
0000786bc93cf19e  lea r12, [rax+0x110]
0000786bc93cf1a5  movups xmm15, [r13+r12*1]
0000786bc93cf1ab  lea r12, [r14+0x140]
0000786bc93cf1b2  mov r11, [r15+0xE8]
0000786bc93cf1b9  mov [r13+r12*1], r11
0000786bc93cf1be  lea r12, [rax+0x180]
0000786bc93cf1c5  movups xmm7, [r13+r12*1]
0000786bc93cf1cb  lea r12, [rax+0x190]
0000786bc93cf1d2  movups xmm6, [r13+r12*1]
0000786bc93cf1d8  lea r12, [rax+0x1C0]
0000786bc93cf1df  movups xmm5, [r13+r12*1]
0000786bc93cf1e5  lea r12, [rax+0x1D0]
0000786bc93cf1ec  movups xmm4, [r13+r12*1]
0000786bc93cf1f2  lea r12, [r14+0x20]
0000786bc93cf1f6  movups [r13+r12*1], xmm1
0000786bc93cf1fc  lea r12, [r14+0x30]
0000786bc93cf200  movups [r13+r12*1], xmm13
0000786bc93cf206  lea r12, [rax+0x60]
0000786bc93cf20a  movups xmm1, [r13+r12*1]
0000786bc93cf210  lea r12, [rax+0x70]
0000786bc93cf214  movups xmm13, [r13+r12*1]
0000786bc93cf21a  lea r12, [rax+0x20]
0000786bc93cf21e  movups xmm3, [r13+r12*1]
0000786bc93cf224  lea r12, [rax+0x30]
0000786bc93cf228  movups xmm2, [r13+r12*1]
0000786bc93cf22e  movaps [r15+0x1F0], xmm2
0000786bc93cf236  lea r12, [r14+0x60]
0000786bc93cf23a  movups [r13+r12*1], xmm11
0000786bc93cf240  lea r12, [r14+0x70]
0000786bc93cf244  movups [r13+r12*1], xmm5
0000786bc93cf24a  lea r12, [rax+0xE0]
0000786bc93cf251  movups xmm11, [r13+r12*1]
0000786bc93cf257  lea r12, [rax+0xF0]
0000786bc93cf25e  movups xmm5, [r13+r12*1]
0000786bc93cf264  lea r12, [r14+0xA0]
0000786bc93cf26b  movups [r13+r12*1], xmm13
0000786bc93cf271  lea r12, [r14+0xB0]
0000786bc93cf278  movups [r13+r12*1], xmm1
0000786bc93cf27e  lea r12, [rax+0xA0]
0000786bc93cf285  movups xmm1, [r13+r12*1]
0000786bc93cf28b  lea r12, [rax+0xB0]
0000786bc93cf292  movups xmm13, [r13+r12*1]
0000786bc93cf298  lea r12, [rax+0x120]
0000786bc93cf29f  vmovaps [rsp+0x10], xmm1
0000786bc93cf2a5  movups xmm1, [r13+r12*1]
0000786bc93cf2ab  lea r12, [rax+0x130]
0000786bc93cf2b2  vmovaps [rsp+0x20], xmm1
0000786bc93cf2b8  movups xmm1, [r13+r12*1]
0000786bc93cf2be  lea r12, [rax+0x160]
0000786bc93cf2c5  vmovaps [rsp+0x30], xmm1
0000786bc93cf2cb  movups xmm1, [r13+r12*1]
0000786bc93cf2d1  lea r12, [rax+0x170]
0000786bc93cf2d8  vmovaps [rsp+0x40], xmm1
0000786bc93cf2de  movups xmm1, [r13+r12*1]
0000786bc93cf2e4  movaps [r15+0x2B0], xmm1
0000786bc93cf2ec  lea r12, [r14+0x80]
0000786bc93cf2f3  movups [r13+r12*1], xmm13
0000786bc93cf2f9  lea r12, [r14+0x90]
0000786bc93cf300  vmovaps xmm13, [rsp+0x10]
0000786bc93cf306  movups [r13+r12*1], xmm13
0000786bc93cf30c  lea r12, [rax+0x1A0]
0000786bc93cf313  movups xmm13, [r13+r12*1]
0000786bc93cf319  lea r12, [rax+0x1B0]
0000786bc93cf320  vmovaps [rsp+0x10], xmm1
0000786bc93cf326  movups xmm1, [r13+r12*1]
0000786bc93cf32c  movaps [r15+0x290], xmm13
0000786bc93cf334  movaps [r15+0x1E0], xmm1
0000786bc93cf33c  lea r12, [rax+0x1E0]
0000786bc93cf343  vmovaps [rsp+0x50], xmm1
0000786bc93cf349  movups xmm1, [r13+r12*1]
0000786bc93cf34f  lea r12, [rax+0x1F0]
0000786bc93cf356  vmovaps [rsp+0x60], xmm1
0000786bc93cf35c  movups xmm1, [r13+r12*1]
0000786bc93cf362  mov qword ptr [r15+0x50], 0x430920
0000786bc93cf36a  lea rax, [r14+0x40]
0000786bc93cf36e  vmovaps [rsp+0x70], xmm1
0000786bc93cf374  vmovaps xmm1, [rsp+0x40]
0000786bc93cf37a  movups [r13+rax*1], xmm1
0000786bc93cf380  lea rax, [r14+0x50]
0000786bc93cf384  movups [r13+rax*1], xmm10
0000786bc93cf38a  vmovaps xmm1, [rsp+0x70]
0000786bc93cf390  movups [r13+r14*1], xmm1
0000786bc93cf396  lea rax, [r14+0x10]
0000786bc93cf39a  vmovaps xmm1, [rsp+0x60]
0000786bc93cf3a0  movups [r13+rax*1], xmm1
0000786bc93cf3a6  mov rax, [r15+0x40]
0000786bc93cf3aa  vmovaps [rsp+0x40], xmm3
0000786bc93cf3b0  vmovaps xmm1, [rsp+0x40]
0000786bc93cf3b6  por xmm3, xmm1
0000786bc93cf3ba  vmovaps [rsp+0x40], xmm6
0000786bc93cf3c0  vmovaps xmm10, [rsp+0x40]
0000786bc93cf3c6  por xmm6, xmm10
0000786bc93cf3cb  lea r12, [rax+0x30]
0000786bc93cf3cf  mov r11, [r13+r12*1]
0000786bc93cf3d4  lea r12, [rax+0x38]
0000786bc93cf3d8  mov r10, [r13+r12*1]
0000786bc93cf3dd  movq xmm10, r11
0000786bc93cf3e2  vmovaps [rsp+0x40], xmm1
0000786bc93cf3e8  movq xmm1, r10
0000786bc93cf3ed  movq xmm10, xmm10
0000786bc93cf3f2  vmovaps [rsp+0x60], xmm10
0000786bc93cf3f8  movq xmm10, xmm10
0000786bc93cf3fd  movaps [r15+0x130], xmm10
0000786bc93cf405  movq xmm1, xmm1
0000786bc93cf409  vmovaps [rsp+0x70], xmm1
0000786bc93cf40f  movq xmm1, xmm1
0000786bc93cf413  movaps [r15+0x280], xmm1
0000786bc93cf41b  vmovaps [rsp+0x80], xmm9
0000786bc93cf424  vmovaps xmm1, [rsp+0x80]
0000786bc93cf42d  por xmm9, xmm1
0000786bc93cf432  lea r12, [rax+0x20]
0000786bc93cf436  mov r11, [r13+r12*1]
0000786bc93cf43b  lea r12, [rax+0x28]
0000786bc93cf43f  mov r10, [r13+r12*1]
0000786bc93cf444  movq xmm1, r11
0000786bc93cf449  movq xmm10, r10
0000786bc93cf44e  movq xmm1, xmm1
0000786bc93cf452  vmovaps [rsp+0x80], xmm1
0000786bc93cf45b  movq xmm1, xmm1
0000786bc93cf45f  movaps [r15+0x150], xmm1
0000786bc93cf467  movq xmm10, xmm10
0000786bc93cf46c  vmovaps [rsp+0x90], xmm10
0000786bc93cf475  movq xmm10, xmm10
0000786bc93cf47a  movaps [r15+0x140], xmm10
0000786bc93cf482  lea r12, [rax+0x10]
0000786bc93cf486  mov r11, [r13+r12*1]
0000786bc93cf48b  lea r12, [rax+0x18]
0000786bc93cf48f  mov r10, [r13+r12*1]
0000786bc93cf494  movq xmm1, r11
0000786bc93cf499  movq xmm10, r10
0000786bc93cf49e  movq xmm1, xmm1
0000786bc93cf4a2  vmovaps [rsp+0xA0], xmm1
0000786bc93cf4ab  movq xmm1, xmm1
0000786bc93cf4af  movaps [r15+0x170], xmm1
0000786bc93cf4b7  movq xmm10, xmm10
0000786bc93cf4bc  vmovaps [rsp+0xB0], xmm10
0000786bc93cf4c5  movq xmm10, xmm10
0000786bc93cf4ca  movaps [r15+0x160], xmm10
0000786bc93cf4d2  mov r12, [r13+rax*1]
0000786bc93cf4d7  vmovq xmm1, r12
0000786bc93cf4dc  vpbroadcastq xmm1, xmm1
0000786bc93cf4e1  lea r12, [rax+0x08]
0000786bc93cf4e5  mov rax, [r13+r12*1]
0000786bc93cf4ea  movq xmm10, rax
0000786bc93cf4ef  movaps [r15+0x230], xmm10
0000786bc93cf4f7  lea rax, [r14+0x50]
0000786bc93cf4fb  movups xmm10, [r13+rax*1]
0000786bc93cf501  lea rax, [r14+0x60]
0000786bc93cf505  vmovaps [rsp+0xC0], xmm1
0000786bc93cf50e  movups xmm1, [r13+rax*1]
0000786bc93cf514  lea rax, [r14+0x30]
0000786bc93cf518  vmovaps [rsp+0xD0], xmm1
0000786bc93cf521  movups xmm1, [r13+rax*1]
0000786bc93cf527  mov qword ptr [r15+0x60], 0x430920
0000786bc93cf52f  mov qword ptr [r15+0x58], 0x40
0000786bc93cf537  vmovaps [rsp+0xE0], xmm1
0000786bc93cf540  vmovaps [rsp+0xF0], xmm15
0000786bc93cf549  vmovaps xmm15, [rsp+0xC0]
0000786bc93cf552  vmovaps [rsp+0xC0], xmm14
0000786bc93cf55b  vmovaps xmm14, [rsp+0x40]
0000786bc93cf561  vmovaps [rsp+0x40], xmm13
0000786bc93cf567  movaps xmm1, xmm15
0000786bc93cf56b  mulpd xmm1, xmm14
0000786bc93cf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000786bc93cf575  ptest xmm13, xmm13
0000786bc93cf57b  jnz 0x0000786BC93D0682
0000786bc93cf581  movq xmm14, qword ptr [r15+0x230]
0000786bc93cf58a  vmovaps [rsp+0x100], xmm14
0000786bc93cf593  vpermilpd xmm14, xmm14, 0x00
0000786bc93cf599  vmovaps [rsp+0x110], xmm1
0000786bc93cf5a2  vmovaps xmm1, [rsp+0xE0]
0000786bc93cf5ab  vmovaps [rsp+0xE0], xmm15
0000786bc93cf5b4  movaps xmm13, xmm1
0000786bc93cf5b8  mulpd xmm13, xmm14
0000786bc93cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000786bc93cf5c3  ptest xmm15, xmm15
0000786bc93cf5c9  jnz 0x0000786BC93D07C4
0000786bc93cf5cf  vxorps xmm1, xmm1, xmm1
0000786bc93cf5d3  vpbroadcastq xmm1, xmm1
0000786bc93cf5d8  vmovaps xmm14, [rsp+0xE0]
0000786bc93cf5e1  vmovaps [rsp+0xE0], xmm1
0000786bc93cf5ea  vmovaps xmm1, [rsp+0xD0]
0000786bc93cf5f3  vmovaps [rsp+0xD0], xmm13
0000786bc93cf5fc  movaps xmm15, xmm14
0000786bc93cf600  mulpd xmm15, xmm1
0000786bc93cf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000786bc93cf60b  ptest xmm13, xmm13
0000786bc93cf611  jnz 0x0000786BC93D0907
0000786bc93cf617  movaps xmm1, xmm14
0000786bc93cf61b  mulpd xmm1, xmm10
0000786bc93cf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000786bc93cf625  ptest xmm13, xmm13
0000786bc93cf62b  jnz 0x0000786BC93D0A4A
0000786bc93cf631  movaps xmm13, xmm14
0000786bc93cf635  mulpd xmm13, xmm2
0000786bc93cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000786bc93cf640  ptest xmm10, xmm10
0000786bc93cf646  jnz 0x0000786BC93D0B8C
0000786bc93cf64c  vmovaps [rsp+0x120], xmm7
0000786bc93cf655  vmovaps xmm14, [rsp+0x120]
0000786bc93cf65e  por xmm7, xmm14
0000786bc93cf663  vmovaps xmm14, [rsp+0xC0]
0000786bc93cf66c  vmovaps xmm10, [rsp+0xC0]
0000786bc93cf675  por xmm14, xmm10
0000786bc93cf67a  vmovaps xmm2, [rsp+0x100]
0000786bc93cf683  vpermilpd xmm2, xmm2, 0x00
0000786bc93cf689  vmovaps [rsp+0xC0], xmm1
0000786bc93cf692  vmovaps [rsp+0x120], xmm15
0000786bc93cf69b  movaps xmm1, xmm10
0000786bc93cf69f  mulpd xmm1, xmm2
0000786bc93cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000786bc93cf6a8  ptest xmm15, xmm15
0000786bc93cf6ae  jnz 0x0000786BC93D0CCF
0000786bc93cf6b4  xor eax, eax
0000786bc93cf6b6  mov r12d, 0x40
0000786bc93cf6bc  mov r11d, 0x200
0000786bc93cf6c2  cmp r12, r11
0000786bc93cf6c5  cmc
0000786bc93cf6c6  lahf
0000786bc93cf6c7  seto al
0000786bc93cf6ca  mov [r15+0x108], eax
0000786bc93cf6d1  vmovaps xmm10, [rsp+0x110]
0000786bc93cf6da  vmovaps xmm2, [rsp+0xE0]
0000786bc93cf6e3  vmovaps [rsp+0xE0], xmm1
0000786bc93cf6ec  movaps xmm15, xmm10
0000786bc93cf6f0  addpd xmm15, xmm2
0000786bc93cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93cf6fb  ptest xmm1, xmm1
0000786bc93cf700  jnz 0x0000786BC93D0E10
0000786bc93cf706  vmovaps xmm10, [rsp+0x120]
0000786bc93cf70f  vmovaps [rsp+0x110], xmm15
0000786bc93cf718  movaps xmm1, xmm10
0000786bc93cf71c  addpd xmm1, xmm12
0000786bc93cf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000786bc93cf726  ptest xmm15, xmm15
0000786bc93cf72c  jnz 0x0000786BC93D0F53
0000786bc93cf732  vmovaps xmm10, [rsp+0xC0]
0000786bc93cf73b  vmovaps [rsp+0xC0], xmm1
0000786bc93cf744  movaps xmm15, xmm10
0000786bc93cf748  addpd xmm15, xmm12
0000786bc93cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93cf753  ptest xmm1, xmm1
0000786bc93cf758  jnz 0x0000786BC93D1095
0000786bc93cf75e  vmovaps xmm1, [rsp+0x30]
0000786bc93cf764  vmovaps xmm12, [rsp+0x30]
0000786bc93cf76a  por xmm1, xmm12
0000786bc93cf76f  vmovaps xmm12, [rsp+0x20]
0000786bc93cf775  vmovaps xmm10, [rsp+0x20]
0000786bc93cf77b  por xmm12, xmm10
0000786bc93cf780  vmovaps [rsp+0x20], xmm5
0000786bc93cf786  vmovaps xmm10, [rsp+0x20]
0000786bc93cf78c  por xmm5, xmm10
0000786bc93cf791  vmovaps [rsp+0x20], xmm11
0000786bc93cf797  vmovaps xmm10, [rsp+0x20]
0000786bc93cf79d  por xmm11, xmm10
0000786bc93cf7a2  vmovaps [rsp+0x20], xmm4
0000786bc93cf7a8  vmovaps xmm10, [rsp+0x20]
0000786bc93cf7ae  por xmm4, xmm10
0000786bc93cf7b3  vmovaps [rsp+0x20], xmm8
0000786bc93cf7b9  vmovaps xmm10, [rsp+0x20]
0000786bc93cf7bf  por xmm8, xmm10
0000786bc93cf7c4  vmovaps xmm10, [rsp+0xF0]
0000786bc93cf7cd  vmovaps [rsp+0x20], xmm1
0000786bc93cf7d3  vmovaps xmm1, [rsp+0xF0]
0000786bc93cf7dc  por xmm10, xmm1
0000786bc93cf7e1  lea rax, [r14+0xA0]
0000786bc93cf7e8  movups xmm1, [r13+rax*1]
0000786bc93cf7ee  lea rax, [r14+0xB0]
0000786bc93cf7f5  vmovaps [rsp+0x30], xmm1
0000786bc93cf7fb  movups xmm1, [r13+rax*1]
0000786bc93cf801  vmovaps [rsp+0xF0], xmm1
0000786bc93cf80a  vmovaps [rsp+0x120], xmm15
0000786bc93cf813  movaps xmm1, xmm13
0000786bc93cf817  addpd xmm1, xmm2
0000786bc93cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000786bc93cf820  ptest xmm15, xmm15
0000786bc93cf826  jnz 0x0000786BC93D11ED
0000786bc93cf82c  lea rax, [r14+0xF0]
0000786bc93cf833  movups xmm15, [r13+rax*1]
0000786bc93cf839  vmovaps xmm2, [rsp+0xC0]
0000786bc93cf842  vmovaps [rsp+0xC0], xmm1
0000786bc93cf84b  vmovaps xmm1, [rsp+0xE0]
0000786bc93cf854  vmovaps [rsp+0xE0], xmm15
0000786bc93cf85d  movaps xmm13, xmm2
0000786bc93cf861  addpd xmm13, xmm1
0000786bc93cf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000786bc93cf86c  ptest xmm15, xmm15
0000786bc93cf872  jnz 0x0000786BC93D1338
0000786bc93cf878  vmovaps xmm15, [rsp+0x120]
0000786bc93cf881  vmovaps xmm2, [rsp+0xD0]
0000786bc93cf88a  vmovaps [rsp+0xD0], xmm14
0000786bc93cf893  movaps xmm1, xmm15
0000786bc93cf897  addpd xmm1, xmm2
0000786bc93cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000786bc93cf8a0  ptest xmm14, xmm14
0000786bc93cf8a6  jnz 0x0000786BC93D147A
0000786bc93cf8ac  vmovaps xmm15, [rsp+0x100]
0000786bc93cf8b5  vpermilpd xmm15, xmm15, 0x00
0000786bc93cf8bb  vmovaps xmm2, [rsp+0xF0]
0000786bc93cf8c4  vmovaps [rsp+0xF0], xmm1
0000786bc93cf8cd  movaps xmm14, xmm2
0000786bc93cf8d1  mulpd xmm14, xmm15
0000786bc93cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000786bc93cf8dc  ptest xmm1, xmm1
0000786bc93cf8e1  jnz 0x0000786BC93D15BB
0000786bc93cf8e7  vmovaps xmm1, [rsp+0xA0]
0000786bc93cf8f0  vpermilpd xmm1, xmm1, 0x00
0000786bc93cf8f6  vmovaps xmm2, [rsp+0xE0]
0000786bc93cf8ff  vmovaps [rsp+0xE0], xmm14
0000786bc93cf908  movaps xmm15, xmm2
0000786bc93cf90c  mulpd xmm15, xmm1
0000786bc93cf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000786bc93cf917  ptest xmm14, xmm14
0000786bc93cf91d  jnz 0x0000786BC93D16FE
0000786bc93cf923  lea rax, [r14+0xE0]
0000786bc93cf92a  movups xmm1, [r13+rax*1]
0000786bc93cf930  vmovaps xmm14, [rsp+0x100]
0000786bc93cf939  vpermilpd xmm14, xmm14, 0x00
0000786bc93cf93f  vmovaps [rsp+0x100], xmm1
0000786bc93cf948  vmovaps xmm1, [rsp+0x30]
0000786bc93cf94e  vmovaps [rsp+0x30], xmm15
0000786bc93cf954  movaps xmm2, xmm1
0000786bc93cf957  mulpd xmm2, xmm14
0000786bc93cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000786bc93cf961  ptest xmm15, xmm15
0000786bc93cf967  jnz 0x0000786BC93D184A
0000786bc93cf96d  vmovaps [rsp+0x120], xmm10
0000786bc93cf976  vmovaps xmm1, [rsp+0x120]
0000786bc93cf97f  por xmm10, xmm1
0000786bc93cf984  movaps [r15+0x300], xmm10
0000786bc93cf98c  vmovaps [rsp+0x120], xmm8
0000786bc93cf995  vmovaps xmm1, [rsp+0x120]
0000786bc93cf99e  por xmm8, xmm1
0000786bc93cf9a3  movaps [r15+0x190], xmm8
0000786bc93cf9ab  vmovaps xmm1, [rsp+0xA0]
0000786bc93cf9b4  vpermilpd xmm1, xmm1, 0x00
0000786bc93cf9ba  vmovaps xmm14, [rsp+0x100]
0000786bc93cf9c3  vmovaps [rsp+0x100], xmm13
0000786bc93cf9cc  movaps xmm15, xmm14
0000786bc93cf9d0  mulpd xmm15, xmm1
0000786bc93cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000786bc93cf9db  ptest xmm13, xmm13
0000786bc93cf9e1  jnz 0x0000786BC93D198B
0000786bc93cf9e7  lea rax, [r14+0x90]
0000786bc93cf9ee  movups xmm1, [r13+rax*1]
0000786bc93cf9f4  vmovaps [rsp+0x120], xmm4
0000786bc93cf9fd  vmovaps xmm14, [rsp+0x120]
0000786bc93cfa06  por xmm4, xmm14
0000786bc93cfa0b  movaps [r15+0x1C0], xmm4
0000786bc93cfa13  vmovaps [rsp+0x120], xmm11
0000786bc93cfa1c  vmovaps xmm14, [rsp+0x120]
0000786bc93cfa25  por xmm11, xmm14
0000786bc93cfa2a  movaps [r15+0x200], xmm11
0000786bc93cfa32  vmovaps [rsp+0x120], xmm5
0000786bc93cfa3b  vmovaps xmm14, [rsp+0x120]
0000786bc93cfa44  por xmm5, xmm14
0000786bc93cfa49  movaps [r15+0x2D0], xmm5
0000786bc93cfa51  vmovaps [rsp+0x120], xmm12
0000786bc93cfa5a  vmovaps xmm14, [rsp+0x120]
0000786bc93cfa63  por xmm12, xmm14
0000786bc93cfa68  movaps [r15+0x2E0], xmm12
0000786bc93cfa70  vmovaps xmm13, [rsp+0x110]
0000786bc93cfa79  vmovaps [rsp+0x110], xmm1
0000786bc93cfa82  vmovaps xmm1, [rsp+0xE0]
0000786bc93cfa8b  vmovaps [rsp+0xE0], xmm15
0000786bc93cfa94  movaps xmm14, xmm13
0000786bc93cfa98  addpd xmm14, xmm1
0000786bc93cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000786bc93cfaa3  ptest xmm15, xmm15
0000786bc93cfaa9  jnz 0x0000786BC93D1AD8
0000786bc93cfaaf  vmovaps xmm1, [rsp+0xA0]
0000786bc93cfab8  vpermilpd xmm1, xmm1, 0x00
0000786bc93cfabe  vmovaps xmm13, [rsp+0x110]
0000786bc93cfac7  vmovaps [rsp+0x110], xmm14
0000786bc93cfad0  movaps xmm15, xmm13
0000786bc93cfad4  mulpd xmm15, xmm1
0000786bc93cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000786bc93cfadf  ptest xmm14, xmm14
0000786bc93cfae5  jnz 0x0000786BC93D1C1B
0000786bc93cfaeb  lea rax, [r14+0x80]
0000786bc93cfaf2  movups xmm1, [r13+rax*1]
0000786bc93cfaf8  vmovaps xmm13, [rsp+0xC0]
0000786bc93cfb01  vmovaps [rsp+0xC0], xmm1
0000786bc93cfb0a  movaps xmm14, xmm13
0000786bc93cfb0e  addpd xmm14, xmm2
0000786bc93cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000786bc93cfb19  ptest xmm1, xmm1
0000786bc93cfb1e  jnz 0x0000786BC93D1D68
0000786bc93cfb24  vmovaps xmm13, [rsp+0x100]
0000786bc93cfb2d  vmovaps xmm2, [rsp+0x30]
0000786bc93cfb33  vmovaps [rsp+0x30], xmm15
0000786bc93cfb39  movaps xmm1, xmm13
0000786bc93cfb3d  addpd xmm1, xmm2
0000786bc93cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000786bc93cfb46  ptest xmm15, xmm15
0000786bc93cfb4c  jnz 0x0000786BC93D1EAB
0000786bc93cfb52  vmovaps xmm15, [rsp+0x20]
0000786bc93cfb58  vmovaps xmm13, [rsp+0x20]
0000786bc93cfb5e  por xmm15, xmm13
0000786bc93cfb63  movaps [r15+0x2F0], xmm15
0000786bc93cfb6b  vmovaps xmm13, [rsp+0xA0]
0000786bc93cfb74  vpermilpd xmm13, xmm13, 0x00
0000786bc93cfb7a  vmovaps [rsp+0x20], xmm1
0000786bc93cfb80  vmovaps xmm1, [rsp+0xC0]
0000786bc93cfb89  vmovaps [rsp+0xA0], xmm15
0000786bc93cfb92  movaps xmm2, xmm1
0000786bc93cfb95  mulpd xmm2, xmm13
0000786bc93cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000786bc93cfb9f  ptest xmm15, xmm15
0000786bc93cfba5  jnz 0x0000786BC93D1FEC
0000786bc93cfbab  lea rax, [r14+0xD0]
0000786bc93cfbb2  movups xmm1, [r13+rax*1]
0000786bc93cfbb8  vmovaps xmm13, [rsp+0xF0]
0000786bc93cfbc1  vmovaps [rsp+0xC0], xmm1
0000786bc93cfbca  vmovaps xmm1, [rsp+0xE0]
0000786bc93cfbd3  vmovaps [rsp+0xE0], xmm14
0000786bc93cfbdc  movaps xmm15, xmm13
0000786bc93cfbe0  addpd xmm15, xmm1
0000786bc93cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000786bc93cfbeb  ptest xmm14, xmm14
0000786bc93cfbf1  jnz 0x0000786BC93D2137
0000786bc93cfbf7  vmovaps xmm1, [rsp+0xB0]
0000786bc93cfc00  vpermilpd xmm1, xmm1, 0x00
0000786bc93cfc06  movaps xmm14, xmm11
0000786bc93cfc0a  mulpd xmm14, xmm1
0000786bc93cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000786bc93cfc15  ptest xmm13, xmm13
0000786bc93cfc1b  jnz 0x0000786BC93D227A
0000786bc93cfc21  movaps [r15+0x260], xmm14
0000786bc93cfc29  vxorps xmm1, xmm1, xmm1
0000786bc93cfc2d  vpbroadcastq xmm1, xmm1
0000786bc93cfc32  movaps [r15+0x1B0], xmm1
0000786bc93cfc3a  vmovaps xmm1, [rsp+0xB0]
0000786bc93cfc43  vpermilpd xmm1, xmm1, 0x00
0000786bc93cfc49  vmovaps xmm11, [rsp+0xC0]
0000786bc93cfc52  vmovaps [rsp+0xC0], xmm15
0000786bc93cfc5b  movaps xmm13, xmm11
0000786bc93cfc5f  mulpd xmm13, xmm1
0000786bc93cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000786bc93cfc6a  ptest xmm15, xmm15
0000786bc93cfc70  jnz 0x0000786BC93D23BD
0000786bc93cfc76  lea rax, [r14+0xC0]
0000786bc93cfc7d  movups xmm1, [r13+rax*1]
0000786bc93cfc83  vmovaps xmm11, [rsp+0x110]
0000786bc93cfc8c  vmovaps [rsp+0xF0], xmm1
0000786bc93cfc95  vmovaps xmm1, [rsp+0x30]
0000786bc93cfc9b  vmovaps [rsp+0x30], xmm14
0000786bc93cfca1  movaps xmm15, xmm11
0000786bc93cfca5  addpd xmm15, xmm1
0000786bc93cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000786bc93cfcb0  ptest xmm14, xmm14
0000786bc93cfcb6  jnz 0x0000786BC93D250A
0000786bc93cfcbc  vmovaps [rsp+0x100], xmm9
0000786bc93cfcc5  vmovaps xmm1, [rsp+0x100]
0000786bc93cfcce  por xmm9, xmm1
0000786bc93cfcd3  movaps [r15+0x270], xmm9
0000786bc93cfcdb  vmovaps [rsp+0x100], xmm6
0000786bc93cfce4  vmovaps xmm1, [rsp+0x100]
0000786bc93cfced  por xmm6, xmm1
0000786bc93cfcf1  movaps [r15+0x1A0], xmm6
0000786bc93cfcf9  vmovaps xmm14, [rsp+0xB0]
0000786bc93cfd02  vpermilpd xmm14, xmm14, 0x00
0000786bc93cfd08  vmovaps xmm6, [rsp+0xF0]
0000786bc93cfd11  vmovaps [rsp+0xF0], xmm1
0000786bc93cfd1a  movaps xmm11, xmm6
0000786bc93cfd1e  mulpd xmm11, xmm14
0000786bc93cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000786bc93cfd29  ptest xmm1, xmm1
0000786bc93cfd2e  jnz 0x0000786BC93D264D
0000786bc93cfd34  lea rax, [r14+0x20]
0000786bc93cfd38  movups xmm1, [r13+rax*1]
0000786bc93cfd3e  movaps [r15+0x110], xmm1
0000786bc93cfd46  vmovaps xmm6, [rsp+0xE0]
0000786bc93cfd4f  vmovaps [rsp+0xE0], xmm1
0000786bc93cfd58  movaps xmm14, xmm6
0000786bc93cfd5c  addpd xmm14, xmm2
0000786bc93cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000786bc93cfd67  ptest xmm1, xmm1
0000786bc93cfd6c  jnz 0x0000786BC93D279A
0000786bc93cfd72  vmovaps xmm1, [rsp+0xB0]
0000786bc93cfd7b  vpermilpd xmm1, xmm1, 0x00
0000786bc93cfd81  movaps xmm6, xmm5
0000786bc93cfd84  mulpd xmm6, xmm1
0000786bc93cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000786bc93cfd8d  ptest xmm2, xmm2
0000786bc93cfd92  jnz 0x0000786BC93D28DC
0000786bc93cfd98  vmovaps xmm5, [rsp+0x20]
0000786bc93cfd9e  movaps xmm1, xmm5
0000786bc93cfda1  addpd xmm1, xmm13
0000786bc93cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000786bc93cfdab  ptest xmm2, xmm2
0000786bc93cfdb0  jnz 0x0000786BC93D2A1C
0000786bc93cfdb6  vmovaps xmm13, [rsp+0x80]
0000786bc93cfdbf  vpermilpd xmm13, xmm13, 0x00
0000786bc93cfdc5  vmovaps xmm2, [rsp+0xE0]
0000786bc93cfdce  vmovaps [rsp+0x20], xmm1
0000786bc93cfdd4  movaps xmm5, xmm2
0000786bc93cfdd7  mulpd xmm5, xmm13
0000786bc93cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000786bc93cfde1  ptest xmm1, xmm1
0000786bc93cfde6  jnz 0x0000786BC93D2B5D
0000786bc93cfdec  vmovaps xmm1, [rsp+0x80]
0000786bc93cfdf5  vpermilpd xmm1, xmm1, 0x00
0000786bc93cfdfb  movaps xmm13, xmm10
0000786bc93cfdff  mulpd xmm13, xmm1
0000786bc93cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000786bc93cfe0a  ptest xmm2, xmm2
0000786bc93cfe0f  jnz 0x0000786BC93D2C9E
0000786bc93cfe15  vmovaps xmm10, [rsp+0x30]
0000786bc93cfe1b  movaps xmm1, xmm15
0000786bc93cfe1f  addpd xmm1, xmm10
0000786bc93cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000786bc93cfe29  ptest xmm2, xmm2
0000786bc93cfe2e  jnz 0x0000786BC93D2DE1
0000786bc93cfe34  vmovaps xmm10, [rsp+0xC0]
0000786bc93cfe3d  movaps xmm15, xmm10
0000786bc93cfe41  addpd xmm15, xmm11
0000786bc93cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000786bc93cfe4c  ptest xmm2, xmm2
0000786bc93cfe51  jnz 0x0000786BC93D2F23
0000786bc93cfe57  vmovaps xmm11, [rsp+0x80]
0000786bc93cfe60  vpermilpd xmm11, xmm11, 0x00
0000786bc93cfe66  movaps xmm10, xmm12
0000786bc93cfe6a  mulpd xmm10, xmm11
0000786bc93cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000786bc93cfe75  ptest xmm2, xmm2
0000786bc93cfe7a  jnz 0x0000786BC93D3067
0000786bc93cfe80  vmovaps xmm12, [rsp+0x80]
0000786bc93cfe89  vpermilpd xmm12, xmm12, 0x00
0000786bc93cfe8f  vmovaps xmm2, [rsp+0xA0]
0000786bc93cfe98  vmovaps [rsp+0x30], xmm1
0000786bc93cfe9e  movaps xmm11, xmm2
0000786bc93cfea2  mulpd xmm11, xmm12
0000786bc93cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000786bc93cfead  ptest xmm1, xmm1
0000786bc93cfeb2  jnz 0x0000786BC93D31AB
0000786bc93cfeb8  movaps xmm1, xmm14
0000786bc93cfebc  addpd xmm1, xmm6
0000786bc93cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000786bc93cfec5  ptest xmm12, xmm12
0000786bc93cfecb  jnz 0x0000786BC93D32EE
0000786bc93cfed1  vmovaps xmm12, [rsp+0x20]
0000786bc93cfed7  movaps xmm14, xmm12
0000786bc93cfedb  addpd xmm14, xmm5
0000786bc93cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000786bc93cfee6  ptest xmm6, xmm6
0000786bc93cfeeb  jnz 0x0000786BC93D342F
0000786bc93cfef1  vmovaps xmm12, [rsp+0x90]
0000786bc93cfefa  vpermilpd xmm12, xmm12, 0x00
0000786bc93cff00  movaps xmm6, xmm9
0000786bc93cff04  mulpd xmm6, xmm12
0000786bc93cff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000786bc93cff0e  ptest xmm5, xmm5
0000786bc93cff13  jnz 0x0000786BC93D3572
0000786bc93cff19  movaps xmm12, xmm15
0000786bc93cff1d  addpd xmm12, xmm13
0000786bc93cff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000786bc93cff28  ptest xmm9, xmm9
0000786bc93cff2e  jnz 0x0000786BC93D36B4
0000786bc93cff34  vmovaps xmm13, [rsp+0x30]
0000786bc93cff3a  movaps xmm15, xmm13
0000786bc93cff3e  addpd xmm15, xmm10
0000786bc93cff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000786bc93cff49  ptest xmm9, xmm9
0000786bc93cff4f  jnz 0x0000786BC93D37F8
0000786bc93cff55  vmovaps xmm13, [rsp+0xD0]
0000786bc93cff5e  vmovaps xmm10, [rsp+0xD0]
0000786bc93cff67  por xmm13, xmm10
0000786bc93cff6c  movaps [r15+0x250], xmm13
0000786bc93cff74  vmovaps [rsp+0x20], xmm7
0000786bc93cff7a  vmovaps xmm13, [rsp+0x20]
0000786bc93cff80  por xmm7, xmm13
0000786bc93cff85  movaps [r15+0x2A0], xmm7
0000786bc93cff8d  vmovaps [rsp+0x20], xmm3
0000786bc93cff93  vmovaps xmm13, [rsp+0x20]
0000786bc93cff99  por xmm3, xmm13
0000786bc93cff9e  movaps [r15+0x1D0], xmm3
0000786bc93cffa6  lea rax, [r14+0x40]
0000786bc93cffaa  movups xmm13, [r13+rax*1]
0000786bc93cffb0  movaps [r15+0x2C0], xmm13
0000786bc93cffb8  vmovaps xmm10, [rsp+0x90]
0000786bc93cffc1  vpermilpd xmm10, xmm10, 0x00
0000786bc93cffc7  movaps xmm9, xmm8
0000786bc93cffcb  mulpd xmm9, xmm10
0000786bc93cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000786bc93cffd6  ptest xmm5, xmm5
0000786bc93cffdb  jnz 0x0000786BC93D3946
0000786bc93cffe1  movaps xmm10, xmm1
0000786bc93cffe5  addpd xmm10, xmm11
0000786bc93cffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000786bc93cfff0  ptest xmm8, xmm8
0000786bc93cfff6  jnz 0x0000786BC93D3A8A
0000786bc93cfffc  movaps xmm1, xmm14
0000786bc93d0000  addpd xmm1, xmm6
0000786bc93d0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000786bc93d0009  ptest xmm11, xmm11
0000786bc93d000f  jnz 0x0000786BC93D3BCD
0000786bc93d0015  vmovaps xmm14, [rsp+0x90]
0000786bc93d001e  vpermilpd xmm14, xmm14, 0x00
0000786bc93d0024  movaps xmm11, xmm13
0000786bc93d0028  mulpd xmm11, xmm14
0000786bc93d002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000786bc93d0033  ptest xmm8, xmm8
0000786bc93d0039  jnz 0x0000786BC93D3D0E
0000786bc93d003f  vmovaps xmm14, [rsp+0x90]
0000786bc93d0048  vpermilpd xmm14, xmm14, 0x00
0000786bc93d004e  vmovaps xmm8, [rsp+0x10]
0000786bc93d0054  movaps xmm13, xmm8
0000786bc93d0058  mulpd xmm13, xmm14
0000786bc93d005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000786bc93d0063  ptest xmm6, xmm6
0000786bc93d0068  jnz 0x0000786BC93D3E52
0000786bc93d006e  vmovaps xmm14, [rsp+0x60]
0000786bc93d0074  vpermilpd xmm14, xmm14, 0x00
0000786bc93d007a  movaps xmm8, xmm7
0000786bc93d007e  mulpd xmm8, xmm14
0000786bc93d0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000786bc93d0089  ptest xmm6, xmm6
0000786bc93d008e  jnz 0x0000786BC93D3F96
0000786bc93d0094  movaps xmm14, xmm12
0000786bc93d0098  addpd xmm14, xmm9
0000786bc93d009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000786bc93d00a3  ptest xmm7, xmm7
0000786bc93d00a8  jnz 0x0000786BC93D40D9
0000786bc93d00ae  vmovaps xmm12, [rsp+0x60]
0000786bc93d00b4  vpermilpd xmm12, xmm12, 0x00
0000786bc93d00ba  vmovaps xmm7, [rsp+0xF0]
0000786bc93d00c3  movaps xmm9, xmm7
0000786bc93d00c7  mulpd xmm9, xmm12
0000786bc93d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000786bc93d00d2  ptest xmm6, xmm6
0000786bc93d00d7  jnz 0x0000786BC93D421D
0000786bc93d00dd  movaps xmm12, xmm15
0000786bc93d00e1  addpd xmm12, xmm11
0000786bc93d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000786bc93d00ec  ptest xmm7, xmm7
0000786bc93d00f1  jnz 0x0000786BC93D4360
0000786bc93d00f7  vmovaps xmm15, [rsp+0x60]
0000786bc93d00fd  vpermilpd xmm15, xmm15, 0x00
0000786bc93d0103  vmovaps xmm7, [rsp+0x40]
0000786bc93d0109  movaps xmm11, xmm7
0000786bc93d010d  mulpd xmm11, xmm15
0000786bc93d0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000786bc93d0118  ptest xmm6, xmm6
0000786bc93d011d  jnz 0x0000786BC93D44A4
0000786bc93d0123  movaps xmm15, xmm10
0000786bc93d0127  addpd xmm15, xmm13
0000786bc93d012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000786bc93d0132  ptest xmm7, xmm7
0000786bc93d0137  jnz 0x0000786BC93D45E7
0000786bc93d013d  vmovaps xmm13, [rsp+0x60]
0000786bc93d0143  vpermilpd xmm13, xmm13, 0x00
0000786bc93d0149  vmovaps xmm7, [rsp+0x50]
0000786bc93d014f  movaps xmm10, xmm7
0000786bc93d0153  mulpd xmm10, xmm13
0000786bc93d0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000786bc93d015e  ptest xmm6, xmm6
0000786bc93d0163  jnz 0x0000786BC93D472B
0000786bc93d0169  movaps xmm13, xmm1
0000786bc93d016d  addpd xmm13, xmm8
0000786bc93d0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000786bc93d0178  ptest xmm7, xmm7
0000786bc93d017d  jnz 0x0000786BC93D486E
0000786bc93d0183  lea rax, [r14+0x70]
0000786bc93d0187  movups xmm1, [r13+rax*1]
0000786bc93d018d  movaps [r15+0x240], xmm1
0000786bc93d0195  movaps xmm8, xmm14
0000786bc93d0199  addpd xmm8, xmm9
0000786bc93d019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000786bc93d01a4  ptest xmm7, xmm7
0000786bc93d01a9  jnz 0x0000786BC93D49BB
0000786bc93d01af  movaps [r15+0x170], xmm8
0000786bc93d01b7  vmovaps xmm14, [rsp+0x70]
0000786bc93d01bd  vpermilpd xmm14, xmm14, 0x00
0000786bc93d01c3  movaps xmm9, xmm1
0000786bc93d01c7  mulpd xmm9, xmm14
0000786bc93d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000786bc93d01d2  ptest xmm7, xmm7
0000786bc93d01d7  jnz 0x0000786BC93D4AFF
0000786bc93d01dd  vmovaps xmm1, [rsp+0x70]
0000786bc93d01e3  vpermilpd xmm1, xmm1, 0x00
0000786bc93d01e9  movaps xmm14, xmm4
0000786bc93d01ed  mulpd xmm14, xmm1
0000786bc93d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000786bc93d01f8  ptest xmm7, xmm7
0000786bc93d01fd  jnz 0x0000786BC93D4C42
0000786bc93d0203  movaps [r15+0x180], xmm14
0000786bc93d020b  movaps xmm1, xmm12
0000786bc93d020f  addpd xmm1, xmm11
0000786bc93d0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000786bc93d0219  ptest xmm7, xmm7
0000786bc93d021e  jnz 0x0000786BC93D4D84
0000786bc93d0224  movaps [r15+0x210], xmm1
0000786bc93d022c  movups xmm12, [r13+r14*1]
0000786bc93d0232  lea rax, [r14+0x10]
0000786bc93d0236  movups xmm11, [r13+rax*1]
0000786bc93d023c  movaps [r15+0x230], xmm11
0000786bc93d0244  movaps xmm7, xmm15
0000786bc93d0248  addpd xmm7, xmm10
0000786bc93d024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000786bc93d0252  ptest xmm6, xmm6
0000786bc93d0257  jnz 0x0000786BC93D4EDA
0000786bc93d025d  movaps [r15+0x130], xmm7
0000786bc93d0265  vmovaps xmm15, [rsp+0x70]
0000786bc93d026b  vpermilpd xmm15, xmm15, 0x00
0000786bc93d0271  movaps xmm10, xmm11
0000786bc93d0275  mulpd xmm10, xmm15
0000786bc93d027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000786bc93d0280  ptest xmm6, xmm6
0000786bc93d0285  jnz 0x0000786BC93D501C
0000786bc93d028b  movaps [r15+0x220], xmm10
0000786bc93d0293  vmovaps xmm15, [rsp+0x70]
0000786bc93d0299  vpermilpd xmm15, xmm15, 0x00
0000786bc93d029f  movaps xmm11, xmm12
0000786bc93d02a3  mulpd xmm11, xmm15
0000786bc93d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000786bc93d02ae  ptest xmm6, xmm6
0000786bc93d02b3  jnz 0x0000786BC93D5160
0000786bc93d02b9  movaps xmm15, xmm13
0000786bc93d02bd  addpd xmm15, xmm9
0000786bc93d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000786bc93d02c8  ptest xmm12, xmm12
0000786bc93d02ce  jnz 0x0000786BC93D52A4
0000786bc93d02d4  movaps [r15+0x140], xmm15
0000786bc93d02dc  movaps xmm13, xmm8
0000786bc93d02e0  addpd xmm13, xmm14
0000786bc93d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000786bc93d02eb  ptest xmm12, xmm12
0000786bc93d02f1  jnz 0x0000786BC93D53E8
0000786bc93d02f7  movaps [r15+0x150], xmm13
0000786bc93d02ff  movaps xmm14, xmm1
0000786bc93d0303  addpd xmm14, xmm10
0000786bc93d0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000786bc93d030e  ptest xmm12, xmm12
0000786bc93d0314  jnz 0x0000786BC93D552C
0000786bc93d031a  movaps [r15+0x160], xmm14
0000786bc93d0322  movaps xmm1, xmm7
0000786bc93d0325  addpd xmm1, xmm11
0000786bc93d032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000786bc93d032f  ptest xmm12, xmm12
0000786bc93d0335  jnz 0x0000786BC93D566F
0000786bc93d033b  movaps [r15+0x120], xmm1
0000786bc93d0343  mov eax, 0x430920
0000786bc93d0348  movups [r13+rax*1], xmm15
0000786bc93d034e  mov eax, 0x430930
0000786bc93d0353  movups [r13+rax*1], xmm13
0000786bc93d0359  mov eax, 0x430940
0000786bc93d035e  movups [r13+rax*1], xmm14
0000786bc93d0364  mov eax, 0x430950
0000786bc93d0369  movups [r13+rax*1], xmm1
0000786bc93d036f  mov eax, [r15+0x108]
0000786bc93d0376  sahf
0000786bc93d0377  jnz 0x0000786BC93D03A9
0000786bc93d0379  cmp dword ptr [r15+0x318], 0x00
0000786bc93d0381  jz 0x0000786BC93DB900
0000786bc93d0387  nop [rax+rax*1], ax
0000786bc93d0390  nop [rax+rax*1], eax
0000786bc93d0398  mov eax, 0x410444
0000786bc93d039d  mov [r15+0x100], rax
0000786bc93d03a4  jmp 0x0000786BC91FE110
0000786bc93d03a9  cmp dword ptr [r15+0x318], 0x00
0000786bc93d03b1  jz 0x0000786BC93D57E0
0000786bc93d03b7  nop [rax+rax*1], ax
0000786bc93d03c0  nop [rax+rax*1], eax
0000786bc93d03c8  mov eax, 0x410278
0000786bc93d03cd  mov [r15+0x100], rax
0000786bc93d03d4  jmp 0x0000786BC91FE110
0000786bc93d03d9  int3
0000786bc93d03da  call 0x0000786BC92B52F0
0000786bc93d03df  jmp 0x0000786BC93CF016
0000786bc93d03e4  call 0x0000786BC92C4620
0000786bc93d03e9  jmp 0x0000786BC93CF023
0000786bc93d03ee  call 0x0000786BC92C33A0
0000786bc93d03f3  jmp 0x0000786BC93CF035
0000786bc93d03f8  call 0x0000786BC92C2120
0000786bc93d03fd  jmp 0x0000786BC93CF03F
0000786bc93d0402  call 0x0000786BC92C0860
0000786bc93d0407  jmp 0x0000786BC93CF067
0000786bc93d040c  call 0x0000786BC92BF5F0
0000786bc93d0411  jmp 0x0000786BC93CF073
0000786bc93d0416  call 0x0000786BC92C0860
0000786bc93d041b  jmp 0x0000786BC93CF0A5
0000786bc93d0420  call 0x0000786BC92BF5F0
0000786bc93d0425  jmp 0x0000786BC93CF0B1
0000786bc93d042a  call 0x0000786BC92C4740
0000786bc93d042f  jmp 0x0000786BC93CF0BE
0000786bc93d0434  call 0x0000786BC92B5400
0000786bc93d0439  jmp 0x0000786BC93CF0CB
0000786bc93d043e  call 0x0000786BC92B52F0
0000786bc93d0443  jmp 0x0000786BC93CF0D8
0000786bc93d0448  call 0x0000786BC92C4620
0000786bc93d044d  jmp 0x0000786BC93CF0E5
0000786bc93d0452  call 0x0000786BC92C0860
0000786bc93d0457  jmp 0x0000786BC93CF10D
0000786bc93d045c  call 0x0000786BC92BF5F0
0000786bc93d0461  jmp 0x0000786BC93CF119
0000786bc93d0466  call 0x0000786BC9209D70
0000786bc93d046b  jmp 0x0000786BC93CF11F
0000786bc93d0470  call 0x0000786BC92BE9C0
0000786bc93d0475  jmp 0x0000786BC93CF129
0000786bc93d047a  call 0x0000786BC92C0860
0000786bc93d047f  jmp 0x0000786BC93CF151
0000786bc93d0484  call 0x0000786BC92BF5F0
0000786bc93d0489  jmp 0x0000786BC93CF15D
0000786bc93d048e  call 0x0000786BC92BD750
0000786bc93d0493  jmp 0x0000786BC93CF16A
0000786bc93d0498  call 0x0000786BC92BC4E0
0000786bc93d049d  jmp 0x0000786BC93CF177
0000786bc93d04a2  call 0x0000786BC92C4740
0000786bc93d04a7  jmp 0x0000786BC93CF184
0000786bc93d04ac  call 0x0000786BC92B5400
0000786bc93d04b1  jmp 0x0000786BC93CF191
0000786bc93d04b6  call 0x0000786BC92B52F0
0000786bc93d04bb  jmp 0x0000786BC93CF19E
0000786bc93d04c0  call 0x0000786BC92C4620
0000786bc93d04c5  jmp 0x0000786BC93CF1AB
0000786bc93d04ca  call 0x0000786BC92C0860
0000786bc93d04cf  jmp 0x0000786BC93CF1BE
0000786bc93d04d4  call 0x0000786BC92BB270
0000786bc93d04d9  jmp 0x0000786BC93CF1CB
0000786bc93d04de  call 0x0000786BC92BA000
0000786bc93d04e3  jmp 0x0000786BC93CF1D8
0000786bc93d04e8  call 0x0000786BC92B8D90
0000786bc93d04ed  jmp 0x0000786BC93CF1E5
0000786bc93d04f2  call 0x0000786BC92B8A20
0000786bc93d04f7  jmp 0x0000786BC93CF1F2
0000786bc93d04fc  call 0x0000786BC92B5400
0000786bc93d0501  jmp 0x0000786BC93CF1FC
0000786bc93d0506  call 0x0000786BC92C2240
0000786bc93d050b  jmp 0x0000786BC93CF206
0000786bc93d0510  call 0x0000786BC92B52F0
0000786bc93d0515  jmp 0x0000786BC93CF210
0000786bc93d051a  call 0x0000786BC92C2120
0000786bc93d051f  jmp 0x0000786BC93CF21A
0000786bc93d0524  call 0x0000786BC92B77B0
0000786bc93d0529  jmp 0x0000786BC93CF224
0000786bc93d052e  call 0x0000786BC92B6550
0000786bc93d0533  jmp 0x0000786BC93CF22E
0000786bc93d0538  call 0x0000786BC92BFD50
0000786bc93d053d  jmp 0x0000786BC93CF240
0000786bc93d0542  call 0x0000786BC92B8EA0
0000786bc93d0547  jmp 0x0000786BC93CF24A
0000786bc93d054c  call 0x0000786BC92BFC30
0000786bc93d0551  jmp 0x0000786BC93CF257
0000786bc93d0556  call 0x0000786BC92B8D90
0000786bc93d055b  jmp 0x0000786BC93CF264
0000786bc93d0560  call 0x0000786BC92C2240
0000786bc93d0565  jmp 0x0000786BC93CF271
0000786bc93d056a  call 0x0000786BC92B5400
0000786bc93d056f  jmp 0x0000786BC93CF27E
0000786bc93d0574  call 0x0000786BC92B52F0
0000786bc93d0579  jmp 0x0000786BC93CF28B
0000786bc93d057e  call 0x0000786BC92C2120
0000786bc93d0583  jmp 0x0000786BC93CF298
0000786bc93d0588  call 0x0000786BC92B52F0
0000786bc93d058d  jmp 0x0000786BC93CF2AB
0000786bc93d0592  call 0x0000786BC92B52F0
0000786bc93d0597  jmp 0x0000786BC93CF2BE
0000786bc93d059c  call 0x0000786BC92B52F0
0000786bc93d05a1  jmp 0x0000786BC93CF2D1
0000786bc93d05a6  call 0x0000786BC92B52F0
0000786bc93d05ab  jmp 0x0000786BC93CF2E4
0000786bc93d05b0  call 0x0000786BC92C2240
0000786bc93d05b5  jmp 0x0000786BC93CF2F9
0000786bc93d05ba  call 0x0000786BC92C2240
0000786bc93d05bf  jmp 0x0000786BC93CF30C
0000786bc93d05c4  call 0x0000786BC92C2120
0000786bc93d05c9  jmp 0x0000786BC93CF319
0000786bc93d05ce  call 0x0000786BC92B52F0
0000786bc93d05d3  jmp 0x0000786BC93CF32C
0000786bc93d05d8  call 0x0000786BC92B52F0
0000786bc93d05dd  jmp 0x0000786BC93CF34F
0000786bc93d05e2  call 0x0000786BC92B52F0
0000786bc93d05e7  jmp 0x0000786BC93CF362
0000786bc93d05ec  call 0x0000786BC91FF540
0000786bc93d05f1  jmp 0x0000786BC93CF380
0000786bc93d05f6  call 0x0000786BC9208C20
0000786bc93d05fb  jmp 0x0000786BC93CF38A
0000786bc93d0600  call 0x0000786BC92D6600
0000786bc93d0605  jmp 0x0000786BC93CF396
0000786bc93d060a  call 0x0000786BC91FF540
0000786bc93d060f  jmp 0x0000786BC93CF3A6
0000786bc93d0614  call 0x0000786BC92C0370
0000786bc93d0619  jmp 0x0000786BC93CF3D4
0000786bc93d061e  call 0x0000786BC92BF100
0000786bc93d0623  jmp 0x0000786BC93CF3DD
0000786bc93d0628  call 0x0000786BC92C0370
0000786bc93d062d  jmp 0x0000786BC93CF43B
0000786bc93d0632  call 0x0000786BC92BF100
0000786bc93d0637  jmp 0x0000786BC93CF444
0000786bc93d063c  call 0x0000786BC92C0370
0000786bc93d0641  jmp 0x0000786BC93CF48B
0000786bc93d0646  call 0x0000786BC92BF100
0000786bc93d064b  jmp 0x0000786BC93CF494
0000786bc93d0650  call 0x0000786BC920B720
0000786bc93d0655  jmp 0x0000786BC93CF4D7
0000786bc93d065a  call 0x0000786BC92B47C0
0000786bc93d065f  jmp 0x0000786BC93CF4EA
0000786bc93d0664  call 0x0000786BC9208B00
0000786bc93d0669  jmp 0x0000786BC93CF501
0000786bc93d066e  call 0x0000786BC91FF430
0000786bc93d0673  jmp 0x0000786BC93CF514
0000786bc93d0678  call 0x0000786BC91FF430
0000786bc93d067d  jmp 0x0000786BC93CF527
0000786bc93d0682  sub rsp, 0x08
0000786bc93d0686  push rax
0000786bc93d0687  push rcx
0000786bc93d0688  push rdx
0000786bc93d0689  push rdi
0000786bc93d068a  push rsi
0000786bc93d068b  push r8
0000786bc93d068d  push r9
0000786bc93d068f  push r10
0000786bc93d0691  push r11
0000786bc93d0693  sub rsp, 0xF0
0000786bc93d069a  vmovaps [rsp], xmm0
0000786bc93d069f  vmovaps [rsp+0x10], xmm2
0000786bc93d06a5  vmovaps [rsp+0x20], xmm3
0000786bc93d06ab  vmovaps [rsp+0x30], xmm4
0000786bc93d06b1  vmovaps [rsp+0x40], xmm5
0000786bc93d06b7  vmovaps [rsp+0x50], xmm6
0000786bc93d06bd  vmovaps [rsp+0x60], xmm7
0000786bc93d06c3  vmovaps [rsp+0x70], xmm8
0000786bc93d06c9  vmovaps [rsp+0x80], xmm9
0000786bc93d06d2  vmovaps [rsp+0x90], xmm10
0000786bc93d06db  vmovaps [rsp+0xA0], xmm11
0000786bc93d06e4  vmovaps [rsp+0xB0], xmm12
0000786bc93d06ed  vmovaps [rsp+0xC0], xmm13
0000786bc93d06f6  vmovaps [rsp+0xD0], xmm14
0000786bc93d06ff  vmovaps [rsp+0xE0], xmm15
0000786bc93d0708  sub rsp, 0x30
0000786bc93d070c  movaps [rsp], xmm1
0000786bc93d0710  movaps [rsp+0x10], xmm15
0000786bc93d0716  movaps [rsp+0x20], xmm14
0000786bc93d071c  lea rdi, [rsp]
0000786bc93d0720  mov esi, 0x00
0000786bc93d0725  mov rax, 0x60810F6F7530
0000786bc93d072f  call rax
0000786bc93d0731  movaps xmm1, [rsp]
0000786bc93d0735  add rsp, 0x30
0000786bc93d0739  vmovaps xmm0, [rsp]
0000786bc93d073e  vmovaps xmm2, [rsp+0x10]
0000786bc93d0744  vmovaps xmm3, [rsp+0x20]
0000786bc93d074a  vmovaps xmm4, [rsp+0x30]
0000786bc93d0750  vmovaps xmm5, [rsp+0x40]
0000786bc93d0756  vmovaps xmm6, [rsp+0x50]
0000786bc93d075c  vmovaps xmm7, [rsp+0x60]
0000786bc93d0762  vmovaps xmm8, [rsp+0x70]
0000786bc93d0768  vmovaps xmm9, [rsp+0x80]
0000786bc93d0771  vmovaps xmm10, [rsp+0x90]
0000786bc93d077a  vmovaps xmm11, [rsp+0xA0]
0000786bc93d0783  vmovaps xmm12, [rsp+0xB0]
0000786bc93d078c  vmovaps xmm13, [rsp+0xC0]
0000786bc93d0795  vmovaps xmm14, [rsp+0xD0]
0000786bc93d079e  vmovaps xmm15, [rsp+0xE0]
0000786bc93d07a7  add rsp, 0xF0
0000786bc93d07ae  pop r11
0000786bc93d07b0  pop r10
0000786bc93d07b2  pop r9
0000786bc93d07b4  pop r8
0000786bc93d07b6  pop rsi
0000786bc93d07b7  pop rdi
0000786bc93d07b8  pop rdx
0000786bc93d07b9  pop rcx
0000786bc93d07ba  pop rax
0000786bc93d07bb  add rsp, 0x08
0000786bc93d07bf  jmp 0x0000786BC93CF581
0000786bc93d07c4  sub rsp, 0x08
0000786bc93d07c8  push rax
0000786bc93d07c9  push rcx
0000786bc93d07ca  push rdx
0000786bc93d07cb  push rdi
0000786bc93d07cc  push rsi
0000786bc93d07cd  push r8
0000786bc93d07cf  push r9
0000786bc93d07d1  push r10
0000786bc93d07d3  push r11
0000786bc93d07d5  sub rsp, 0xF0
0000786bc93d07dc  vmovaps [rsp], xmm0
0000786bc93d07e1  vmovaps [rsp+0x10], xmm1
0000786bc93d07e7  vmovaps [rsp+0x20], xmm2
0000786bc93d07ed  vmovaps [rsp+0x30], xmm3
0000786bc93d07f3  vmovaps [rsp+0x40], xmm4
0000786bc93d07f9  vmovaps [rsp+0x50], xmm5
0000786bc93d07ff  vmovaps [rsp+0x60], xmm6
0000786bc93d0805  vmovaps [rsp+0x70], xmm7
0000786bc93d080b  vmovaps [rsp+0x80], xmm8
0000786bc93d0814  vmovaps [rsp+0x90], xmm9
0000786bc93d081d  vmovaps [rsp+0xA0], xmm10
0000786bc93d0826  vmovaps [rsp+0xB0], xmm11
0000786bc93d082f  vmovaps [rsp+0xC0], xmm12
0000786bc93d0838  vmovaps [rsp+0xD0], xmm14
0000786bc93d0841  vmovaps [rsp+0xE0], xmm15
0000786bc93d084a  sub rsp, 0x30
0000786bc93d084e  movaps [rsp], xmm13
0000786bc93d0853  movaps [rsp+0x10], xmm1
0000786bc93d0858  movaps [rsp+0x20], xmm14
0000786bc93d085e  lea rdi, [rsp]
0000786bc93d0862  mov esi, 0x00
0000786bc93d0867  mov rax, 0x60810F6F7530
0000786bc93d0871  call rax
0000786bc93d0873  movaps xmm13, [rsp]
0000786bc93d0878  add rsp, 0x30
0000786bc93d087c  vmovaps xmm0, [rsp]
0000786bc93d0881  vmovaps xmm1, [rsp+0x10]
0000786bc93d0887  vmovaps xmm2, [rsp+0x20]
0000786bc93d088d  vmovaps xmm3, [rsp+0x30]
0000786bc93d0893  vmovaps xmm4, [rsp+0x40]
0000786bc93d0899  vmovaps xmm5, [rsp+0x50]
0000786bc93d089f  vmovaps xmm6, [rsp+0x60]
0000786bc93d08a5  vmovaps xmm7, [rsp+0x70]
0000786bc93d08ab  vmovaps xmm8, [rsp+0x80]
0000786bc93d08b4  vmovaps xmm9, [rsp+0x90]
0000786bc93d08bd  vmovaps xmm10, [rsp+0xA0]
0000786bc93d08c6  vmovaps xmm11, [rsp+0xB0]
0000786bc93d08cf  vmovaps xmm12, [rsp+0xC0]
0000786bc93d08d8  vmovaps xmm14, [rsp+0xD0]
0000786bc93d08e1  vmovaps xmm15, [rsp+0xE0]
0000786bc93d08ea  add rsp, 0xF0
0000786bc93d08f1  pop r11
0000786bc93d08f3  pop r10
0000786bc93d08f5  pop r9
0000786bc93d08f7  pop r8
0000786bc93d08f9  pop rsi
0000786bc93d08fa  pop rdi
0000786bc93d08fb  pop rdx
0000786bc93d08fc  pop rcx
0000786bc93d08fd  pop rax
0000786bc93d08fe  add rsp, 0x08
0000786bc93d0902  jmp 0x0000786BC93CF5CF
0000786bc93d0907  sub rsp, 0x08
0000786bc93d090b  push rax
0000786bc93d090c  push rcx
0000786bc93d090d  push rdx
0000786bc93d090e  push rdi
0000786bc93d090f  push rsi
0000786bc93d0910  push r8
0000786bc93d0912  push r9
0000786bc93d0914  push r10
0000786bc93d0916  push r11
0000786bc93d0918  sub rsp, 0xF0
0000786bc93d091f  vmovaps [rsp], xmm0
0000786bc93d0924  vmovaps [rsp+0x10], xmm1
0000786bc93d092a  vmovaps [rsp+0x20], xmm2
0000786bc93d0930  vmovaps [rsp+0x30], xmm3
0000786bc93d0936  vmovaps [rsp+0x40], xmm4
0000786bc93d093c  vmovaps [rsp+0x50], xmm5
0000786bc93d0942  vmovaps [rsp+0x60], xmm6
0000786bc93d0948  vmovaps [rsp+0x70], xmm7
0000786bc93d094e  vmovaps [rsp+0x80], xmm8
0000786bc93d0957  vmovaps [rsp+0x90], xmm9
0000786bc93d0960  vmovaps [rsp+0xA0], xmm10
0000786bc93d0969  vmovaps [rsp+0xB0], xmm11
0000786bc93d0972  vmovaps [rsp+0xC0], xmm12
0000786bc93d097b  vmovaps [rsp+0xD0], xmm13
0000786bc93d0984  vmovaps [rsp+0xE0], xmm14
0000786bc93d098d  sub rsp, 0x30
0000786bc93d0991  movaps [rsp], xmm15
0000786bc93d0996  movaps [rsp+0x10], xmm14
0000786bc93d099c  movaps [rsp+0x20], xmm1
0000786bc93d09a1  lea rdi, [rsp]
0000786bc93d09a5  mov esi, 0x00
0000786bc93d09aa  mov rax, 0x60810F6F7530
0000786bc93d09b4  call rax
0000786bc93d09b6  movaps xmm15, [rsp]
0000786bc93d09bb  add rsp, 0x30
0000786bc93d09bf  vmovaps xmm0, [rsp]
0000786bc93d09c4  vmovaps xmm1, [rsp+0x10]
0000786bc93d09ca  vmovaps xmm2, [rsp+0x20]
0000786bc93d09d0  vmovaps xmm3, [rsp+0x30]
0000786bc93d09d6  vmovaps xmm4, [rsp+0x40]
0000786bc93d09dc  vmovaps xmm5, [rsp+0x50]
0000786bc93d09e2  vmovaps xmm6, [rsp+0x60]
0000786bc93d09e8  vmovaps xmm7, [rsp+0x70]
0000786bc93d09ee  vmovaps xmm8, [rsp+0x80]
0000786bc93d09f7  vmovaps xmm9, [rsp+0x90]
0000786bc93d0a00  vmovaps xmm10, [rsp+0xA0]
0000786bc93d0a09  vmovaps xmm11, [rsp+0xB0]
0000786bc93d0a12  vmovaps xmm12, [rsp+0xC0]
0000786bc93d0a1b  vmovaps xmm13, [rsp+0xD0]
0000786bc93d0a24  vmovaps xmm14, [rsp+0xE0]
0000786bc93d0a2d  add rsp, 0xF0
0000786bc93d0a34  pop r11
0000786bc93d0a36  pop r10
0000786bc93d0a38  pop r9
0000786bc93d0a3a  pop r8
0000786bc93d0a3c  pop rsi
0000786bc93d0a3d  pop rdi
0000786bc93d0a3e  pop rdx
0000786bc93d0a3f  pop rcx
0000786bc93d0a40  pop rax
0000786bc93d0a41  add rsp, 0x08
0000786bc93d0a45  jmp 0x0000786BC93CF617
0000786bc93d0a4a  sub rsp, 0x08
0000786bc93d0a4e  push rax
0000786bc93d0a4f  push rcx
0000786bc93d0a50  push rdx
0000786bc93d0a51  push rdi
0000786bc93d0a52  push rsi
0000786bc93d0a53  push r8
0000786bc93d0a55  push r9
0000786bc93d0a57  push r10
0000786bc93d0a59  push r11
0000786bc93d0a5b  sub rsp, 0xF0
0000786bc93d0a62  vmovaps [rsp], xmm0
0000786bc93d0a67  vmovaps [rsp+0x10], xmm2
0000786bc93d0a6d  vmovaps [rsp+0x20], xmm3
0000786bc93d0a73  vmovaps [rsp+0x30], xmm4
0000786bc93d0a79  vmovaps [rsp+0x40], xmm5
0000786bc93d0a7f  vmovaps [rsp+0x50], xmm6
0000786bc93d0a85  vmovaps [rsp+0x60], xmm7
0000786bc93d0a8b  vmovaps [rsp+0x70], xmm8
0000786bc93d0a91  vmovaps [rsp+0x80], xmm9
0000786bc93d0a9a  vmovaps [rsp+0x90], xmm10
0000786bc93d0aa3  vmovaps [rsp+0xA0], xmm11
0000786bc93d0aac  vmovaps [rsp+0xB0], xmm12
0000786bc93d0ab5  vmovaps [rsp+0xC0], xmm13
0000786bc93d0abe  vmovaps [rsp+0xD0], xmm14
0000786bc93d0ac7  vmovaps [rsp+0xE0], xmm15
0000786bc93d0ad0  sub rsp, 0x30
0000786bc93d0ad4  movaps [rsp], xmm1
0000786bc93d0ad8  movaps [rsp+0x10], xmm14
0000786bc93d0ade  movaps [rsp+0x20], xmm10
0000786bc93d0ae4  lea rdi, [rsp]
0000786bc93d0ae8  mov esi, 0x00
0000786bc93d0aed  mov rax, 0x60810F6F7530
0000786bc93d0af7  call rax
0000786bc93d0af9  movaps xmm1, [rsp]
0000786bc93d0afd  add rsp, 0x30
0000786bc93d0b01  vmovaps xmm0, [rsp]
0000786bc93d0b06  vmovaps xmm2, [rsp+0x10]
0000786bc93d0b0c  vmovaps xmm3, [rsp+0x20]
0000786bc93d0b12  vmovaps xmm4, [rsp+0x30]
0000786bc93d0b18  vmovaps xmm5, [rsp+0x40]
0000786bc93d0b1e  vmovaps xmm6, [rsp+0x50]
0000786bc93d0b24  vmovaps xmm7, [rsp+0x60]
0000786bc93d0b2a  vmovaps xmm8, [rsp+0x70]
0000786bc93d0b30  vmovaps xmm9, [rsp+0x80]
0000786bc93d0b39  vmovaps xmm10, [rsp+0x90]
0000786bc93d0b42  vmovaps xmm11, [rsp+0xA0]
0000786bc93d0b4b  vmovaps xmm12, [rsp+0xB0]
0000786bc93d0b54  vmovaps xmm13, [rsp+0xC0]
0000786bc93d0b5d  vmovaps xmm14, [rsp+0xD0]
0000786bc93d0b66  vmovaps xmm15, [rsp+0xE0]
0000786bc93d0b6f  add rsp, 0xF0
0000786bc93d0b76  pop r11
0000786bc93d0b78  pop r10
0000786bc93d0b7a  pop r9
0000786bc93d0b7c  pop r8
0000786bc93d0b7e  pop rsi
0000786bc93d0b7f  pop rdi
0000786bc93d0b80  pop rdx
0000786bc93d0b81  pop rcx
0000786bc93d0b82  pop rax
0000786bc93d0b83  add rsp, 0x08
0000786bc93d0b87  jmp 0x0000786BC93CF631
0000786bc93d0b8c  sub rsp, 0x08
0000786bc93d0b90  push rax
0000786bc93d0b91  push rcx
0000786bc93d0b92  push rdx
0000786bc93d0b93  push rdi
0000786bc93d0b94  push rsi
0000786bc93d0b95  push r8
0000786bc93d0b97  push r9
0000786bc93d0b99  push r10
0000786bc93d0b9b  push r11
0000786bc93d0b9d  sub rsp, 0xF0
0000786bc93d0ba4  vmovaps [rsp], xmm0
0000786bc93d0ba9  vmovaps [rsp+0x10], xmm1
0000786bc93d0baf  vmovaps [rsp+0x20], xmm2
0000786bc93d0bb5  vmovaps [rsp+0x30], xmm3
0000786bc93d0bbb  vmovaps [rsp+0x40], xmm4
0000786bc93d0bc1  vmovaps [rsp+0x50], xmm5
0000786bc93d0bc7  vmovaps [rsp+0x60], xmm6
0000786bc93d0bcd  vmovaps [rsp+0x70], xmm7
0000786bc93d0bd3  vmovaps [rsp+0x80], xmm8
0000786bc93d0bdc  vmovaps [rsp+0x90], xmm9
0000786bc93d0be5  vmovaps [rsp+0xA0], xmm10
0000786bc93d0bee  vmovaps [rsp+0xB0], xmm11
0000786bc93d0bf7  vmovaps [rsp+0xC0], xmm12
0000786bc93d0c00  vmovaps [rsp+0xD0], xmm14
0000786bc93d0c09  vmovaps [rsp+0xE0], xmm15
0000786bc93d0c12  sub rsp, 0x30
0000786bc93d0c16  movaps [rsp], xmm13
0000786bc93d0c1b  movaps [rsp+0x10], xmm14
0000786bc93d0c21  movaps [rsp+0x20], xmm2
0000786bc93d0c26  lea rdi, [rsp]
0000786bc93d0c2a  mov esi, 0x00
0000786bc93d0c2f  mov rax, 0x60810F6F7530
0000786bc93d0c39  call rax
0000786bc93d0c3b  movaps xmm13, [rsp]
0000786bc93d0c40  add rsp, 0x30
0000786bc93d0c44  vmovaps xmm0, [rsp]
0000786bc93d0c49  vmovaps xmm1, [rsp+0x10]
0000786bc93d0c4f  vmovaps xmm2, [rsp+0x20]
0000786bc93d0c55  vmovaps xmm3, [rsp+0x30]
0000786bc93d0c5b  vmovaps xmm4, [rsp+0x40]
0000786bc93d0c61  vmovaps xmm5, [rsp+0x50]
0000786bc93d0c67  vmovaps xmm6, [rsp+0x60]
0000786bc93d0c6d  vmovaps xmm7, [rsp+0x70]
0000786bc93d0c73  vmovaps xmm8, [rsp+0x80]
0000786bc93d0c7c  vmovaps xmm9, [rsp+0x90]
0000786bc93d0c85  vmovaps xmm10, [rsp+0xA0]
0000786bc93d0c8e  vmovaps xmm11, [rsp+0xB0]
0000786bc93d0c97  vmovaps xmm12, [rsp+0xC0]
0000786bc93d0ca0  vmovaps xmm14, [rsp+0xD0]
0000786bc93d0ca9  vmovaps xmm15, [rsp+0xE0]
0000786bc93d0cb2  add rsp, 0xF0
0000786bc93d0cb9  pop r11
0000786bc93d0cbb  pop r10
0000786bc93d0cbd  pop r9
0000786bc93d0cbf  pop r8
0000786bc93d0cc1  pop rsi
0000786bc93d0cc2  pop rdi
0000786bc93d0cc3  pop rdx
0000786bc93d0cc4  pop rcx
0000786bc93d0cc5  pop rax
0000786bc93d0cc6  add rsp, 0x08
0000786bc93d0cca  jmp 0x0000786BC93CF64C
0000786bc93d0ccf  sub rsp, 0x08
0000786bc93d0cd3  push rax
0000786bc93d0cd4  push rcx
0000786bc93d0cd5  push rdx
0000786bc93d0cd6  push rdi
0000786bc93d0cd7  push rsi
0000786bc93d0cd8  push r8
0000786bc93d0cda  push r9
0000786bc93d0cdc  push r10
0000786bc93d0cde  push r11
0000786bc93d0ce0  sub rsp, 0xF0
0000786bc93d0ce7  vmovaps [rsp], xmm0
0000786bc93d0cec  vmovaps [rsp+0x10], xmm2
0000786bc93d0cf2  vmovaps [rsp+0x20], xmm3
0000786bc93d0cf8  vmovaps [rsp+0x30], xmm4
0000786bc93d0cfe  vmovaps [rsp+0x40], xmm5
0000786bc93d0d04  vmovaps [rsp+0x50], xmm6
0000786bc93d0d0a  vmovaps [rsp+0x60], xmm7
0000786bc93d0d10  vmovaps [rsp+0x70], xmm8
0000786bc93d0d16  vmovaps [rsp+0x80], xmm9
0000786bc93d0d1f  vmovaps [rsp+0x90], xmm10
0000786bc93d0d28  vmovaps [rsp+0xA0], xmm11
0000786bc93d0d31  vmovaps [rsp+0xB0], xmm12
0000786bc93d0d3a  vmovaps [rsp+0xC0], xmm13
0000786bc93d0d43  vmovaps [rsp+0xD0], xmm14
0000786bc93d0d4c  vmovaps [rsp+0xE0], xmm15
0000786bc93d0d55  sub rsp, 0x30
0000786bc93d0d59  movaps [rsp], xmm1
0000786bc93d0d5d  movaps [rsp+0x10], xmm10
0000786bc93d0d63  movaps [rsp+0x20], xmm2
0000786bc93d0d68  lea rdi, [rsp]
0000786bc93d0d6c  mov esi, 0x00
0000786bc93d0d71  mov rax, 0x60810F6F7530
0000786bc93d0d7b  call rax
0000786bc93d0d7d  movaps xmm1, [rsp]
0000786bc93d0d81  add rsp, 0x30
0000786bc93d0d85  vmovaps xmm0, [rsp]
0000786bc93d0d8a  vmovaps xmm2, [rsp+0x10]
0000786bc93d0d90  vmovaps xmm3, [rsp+0x20]
0000786bc93d0d96  vmovaps xmm4, [rsp+0x30]
0000786bc93d0d9c  vmovaps xmm5, [rsp+0x40]
0000786bc93d0da2  vmovaps xmm6, [rsp+0x50]
0000786bc93d0da8  vmovaps xmm7, [rsp+0x60]
0000786bc93d0dae  vmovaps xmm8, [rsp+0x70]
0000786bc93d0db4  vmovaps xmm9, [rsp+0x80]
0000786bc93d0dbd  vmovaps xmm10, [rsp+0x90]
0000786bc93d0dc6  vmovaps xmm11, [rsp+0xA0]
0000786bc93d0dcf  vmovaps xmm12, [rsp+0xB0]
0000786bc93d0dd8  vmovaps xmm13, [rsp+0xC0]
0000786bc93d0de1  vmovaps xmm14, [rsp+0xD0]
0000786bc93d0dea  vmovaps xmm15, [rsp+0xE0]
0000786bc93d0df3  add rsp, 0xF0
0000786bc93d0dfa  pop r11
0000786bc93d0dfc  pop r10
0000786bc93d0dfe  pop r9
0000786bc93d0e00  pop r8
0000786bc93d0e02  pop rsi
0000786bc93d0e03  pop rdi
0000786bc93d0e04  pop rdx
0000786bc93d0e05  pop rcx
0000786bc93d0e06  pop rax
0000786bc93d0e07  add rsp, 0x08
0000786bc93d0e0b  jmp 0x0000786BC93CF6B4
0000786bc93d0e10  sub rsp, 0x08
0000786bc93d0e14  push rax
0000786bc93d0e15  push rcx
0000786bc93d0e16  push rdx
0000786bc93d0e17  push rdi
0000786bc93d0e18  push rsi
0000786bc93d0e19  push r8
0000786bc93d0e1b  push r9
0000786bc93d0e1d  push r10
0000786bc93d0e1f  push r11
0000786bc93d0e21  sub rsp, 0xF0
0000786bc93d0e28  vmovaps [rsp], xmm0
0000786bc93d0e2d  vmovaps [rsp+0x10], xmm1
0000786bc93d0e33  vmovaps [rsp+0x20], xmm2
0000786bc93d0e39  vmovaps [rsp+0x30], xmm3
0000786bc93d0e3f  vmovaps [rsp+0x40], xmm4
0000786bc93d0e45  vmovaps [rsp+0x50], xmm5
0000786bc93d0e4b  vmovaps [rsp+0x60], xmm6
0000786bc93d0e51  vmovaps [rsp+0x70], xmm7
0000786bc93d0e57  vmovaps [rsp+0x80], xmm8
0000786bc93d0e60  vmovaps [rsp+0x90], xmm9
0000786bc93d0e69  vmovaps [rsp+0xA0], xmm10
0000786bc93d0e72  vmovaps [rsp+0xB0], xmm11
0000786bc93d0e7b  vmovaps [rsp+0xC0], xmm12
0000786bc93d0e84  vmovaps [rsp+0xD0], xmm13
0000786bc93d0e8d  vmovaps [rsp+0xE0], xmm14
0000786bc93d0e96  sub rsp, 0x30
0000786bc93d0e9a  movaps [rsp], xmm15
0000786bc93d0e9f  movaps [rsp+0x10], xmm10
0000786bc93d0ea5  movaps [rsp+0x20], xmm2
0000786bc93d0eaa  lea rdi, [rsp]
0000786bc93d0eae  mov esi, 0x00
0000786bc93d0eb3  mov rax, 0x60810F6F7530
0000786bc93d0ebd  call rax
0000786bc93d0ebf  movaps xmm15, [rsp]
0000786bc93d0ec4  add rsp, 0x30
0000786bc93d0ec8  vmovaps xmm0, [rsp]
0000786bc93d0ecd  vmovaps xmm1, [rsp+0x10]
0000786bc93d0ed3  vmovaps xmm2, [rsp+0x20]
0000786bc93d0ed9  vmovaps xmm3, [rsp+0x30]
0000786bc93d0edf  vmovaps xmm4, [rsp+0x40]
0000786bc93d0ee5  vmovaps xmm5, [rsp+0x50]
0000786bc93d0eeb  vmovaps xmm6, [rsp+0x60]
0000786bc93d0ef1  vmovaps xmm7, [rsp+0x70]
0000786bc93d0ef7  vmovaps xmm8, [rsp+0x80]
0000786bc93d0f00  vmovaps xmm9, [rsp+0x90]
0000786bc93d0f09  vmovaps xmm10, [rsp+0xA0]
0000786bc93d0f12  vmovaps xmm11, [rsp+0xB0]
0000786bc93d0f1b  vmovaps xmm12, [rsp+0xC0]
0000786bc93d0f24  vmovaps xmm13, [rsp+0xD0]
0000786bc93d0f2d  vmovaps xmm14, [rsp+0xE0]
0000786bc93d0f36  add rsp, 0xF0
0000786bc93d0f3d  pop r11
0000786bc93d0f3f  pop r10
0000786bc93d0f41  pop r9
0000786bc93d0f43  pop r8
0000786bc93d0f45  pop rsi
0000786bc93d0f46  pop rdi
0000786bc93d0f47  pop rdx
0000786bc93d0f48  pop rcx
0000786bc93d0f49  pop rax
0000786bc93d0f4a  add rsp, 0x08
0000786bc93d0f4e  jmp 0x0000786BC93CF706
0000786bc93d0f53  sub rsp, 0x08
0000786bc93d0f57  push rax
0000786bc93d0f58  push rcx
0000786bc93d0f59  push rdx
0000786bc93d0f5a  push rdi
0000786bc93d0f5b  push rsi
0000786bc93d0f5c  push r8
0000786bc93d0f5e  push r9
0000786bc93d0f60  push r10
0000786bc93d0f62  push r11
0000786bc93d0f64  sub rsp, 0xF0
0000786bc93d0f6b  vmovaps [rsp], xmm0
0000786bc93d0f70  vmovaps [rsp+0x10], xmm2
0000786bc93d0f76  vmovaps [rsp+0x20], xmm3
0000786bc93d0f7c  vmovaps [rsp+0x30], xmm4
0000786bc93d0f82  vmovaps [rsp+0x40], xmm5
0000786bc93d0f88  vmovaps [rsp+0x50], xmm6
0000786bc93d0f8e  vmovaps [rsp+0x60], xmm7
0000786bc93d0f94  vmovaps [rsp+0x70], xmm8
0000786bc93d0f9a  vmovaps [rsp+0x80], xmm9
0000786bc93d0fa3  vmovaps [rsp+0x90], xmm10
0000786bc93d0fac  vmovaps [rsp+0xA0], xmm11
0000786bc93d0fb5  vmovaps [rsp+0xB0], xmm12
0000786bc93d0fbe  vmovaps [rsp+0xC0], xmm13
0000786bc93d0fc7  vmovaps [rsp+0xD0], xmm14
0000786bc93d0fd0  vmovaps [rsp+0xE0], xmm15
0000786bc93d0fd9  sub rsp, 0x30
0000786bc93d0fdd  movaps [rsp], xmm1
0000786bc93d0fe1  movaps [rsp+0x10], xmm10
0000786bc93d0fe7  movaps [rsp+0x20], xmm12
0000786bc93d0fed  lea rdi, [rsp]
0000786bc93d0ff1  mov esi, 0x00
0000786bc93d0ff6  mov rax, 0x60810F6F7530
0000786bc93d1000  call rax
0000786bc93d1002  movaps xmm1, [rsp]
0000786bc93d1006  add rsp, 0x30
0000786bc93d100a  vmovaps xmm0, [rsp]
0000786bc93d100f  vmovaps xmm2, [rsp+0x10]
0000786bc93d1015  vmovaps xmm3, [rsp+0x20]
0000786bc93d101b  vmovaps xmm4, [rsp+0x30]
0000786bc93d1021  vmovaps xmm5, [rsp+0x40]
0000786bc93d1027  vmovaps xmm6, [rsp+0x50]
0000786bc93d102d  vmovaps xmm7, [rsp+0x60]
0000786bc93d1033  vmovaps xmm8, [rsp+0x70]
0000786bc93d1039  vmovaps xmm9, [rsp+0x80]
0000786bc93d1042  vmovaps xmm10, [rsp+0x90]
0000786bc93d104b  vmovaps xmm11, [rsp+0xA0]
0000786bc93d1054  vmovaps xmm12, [rsp+0xB0]
0000786bc93d105d  vmovaps xmm13, [rsp+0xC0]
0000786bc93d1066  vmovaps xmm14, [rsp+0xD0]
0000786bc93d106f  vmovaps xmm15, [rsp+0xE0]
0000786bc93d1078  add rsp, 0xF0
0000786bc93d107f  pop r11
0000786bc93d1081  pop r10
0000786bc93d1083  pop r9
0000786bc93d1085  pop r8
0000786bc93d1087  pop rsi
0000786bc93d1088  pop rdi
0000786bc93d1089  pop rdx
0000786bc93d108a  pop rcx
0000786bc93d108b  pop rax
0000786bc93d108c  add rsp, 0x08
0000786bc93d1090  jmp 0x0000786BC93CF732
0000786bc93d1095  sub rsp, 0x08
0000786bc93d1099  push rax
0000786bc93d109a  push rcx
0000786bc93d109b  push rdx
0000786bc93d109c  push rdi
0000786bc93d109d  push rsi
0000786bc93d109e  push r8
0000786bc93d10a0  push r9
0000786bc93d10a2  push r10
0000786bc93d10a4  push r11
0000786bc93d10a6  sub rsp, 0xF0
0000786bc93d10ad  vmovaps [rsp], xmm0
0000786bc93d10b2  vmovaps [rsp+0x10], xmm1
0000786bc93d10b8  vmovaps [rsp+0x20], xmm2
0000786bc93d10be  vmovaps [rsp+0x30], xmm3
0000786bc93d10c4  vmovaps [rsp+0x40], xmm4
0000786bc93d10ca  vmovaps [rsp+0x50], xmm5
0000786bc93d10d0  vmovaps [rsp+0x60], xmm6
0000786bc93d10d6  vmovaps [rsp+0x70], xmm7
0000786bc93d10dc  vmovaps [rsp+0x80], xmm8
0000786bc93d10e5  vmovaps [rsp+0x90], xmm9
0000786bc93d10ee  vmovaps [rsp+0xA0], xmm10
0000786bc93d10f7  vmovaps [rsp+0xB0], xmm11
0000786bc93d1100  vmovaps [rsp+0xC0], xmm12
0000786bc93d1109  vmovaps [rsp+0xD0], xmm13
0000786bc93d1112  vmovaps [rsp+0xE0], xmm14
0000786bc93d111b  sub rsp, 0x30
0000786bc93d111f  movaps [rsp], xmm15
0000786bc93d1124  movaps [rsp+0x10], xmm10
0000786bc93d112a  movaps [rsp+0x20], xmm12
0000786bc93d1130  lea rdi, [rsp]
0000786bc93d1134  mov esi, 0x00
0000786bc93d1139  mov rax, 0x60810F6F7530
0000786bc93d1143  call rax
0000786bc93d1145  movaps xmm15, [rsp]
0000786bc93d114a  add rsp, 0x30
0000786bc93d114e  vmovaps xmm0, [rsp]
0000786bc93d1153  vmovaps xmm1, [rsp+0x10]
0000786bc93d1159  vmovaps xmm2, [rsp+0x20]
0000786bc93d115f  vmovaps xmm3, [rsp+0x30]
0000786bc93d1165  vmovaps xmm4, [rsp+0x40]
0000786bc93d116b  vmovaps xmm5, [rsp+0x50]
0000786bc93d1171  vmovaps xmm6, [rsp+0x60]
0000786bc93d1177  vmovaps xmm7, [rsp+0x70]
0000786bc93d117d  vmovaps xmm8, [rsp+0x80]
0000786bc93d1186  vmovaps xmm9, [rsp+0x90]
0000786bc93d118f  vmovaps xmm10, [rsp+0xA0]
0000786bc93d1198  vmovaps xmm11, [rsp+0xB0]
0000786bc93d11a1  vmovaps xmm12, [rsp+0xC0]
0000786bc93d11aa  vmovaps xmm13, [rsp+0xD0]
0000786bc93d11b3  vmovaps xmm14, [rsp+0xE0]
0000786bc93d11bc  add rsp, 0xF0
0000786bc93d11c3  pop r11
0000786bc93d11c5  pop r10
0000786bc93d11c7  pop r9
0000786bc93d11c9  pop r8
0000786bc93d11cb  pop rsi
0000786bc93d11cc  pop rdi
0000786bc93d11cd  pop rdx
0000786bc93d11ce  pop rcx
0000786bc93d11cf  pop rax
0000786bc93d11d0  add rsp, 0x08
0000786bc93d11d4  jmp 0x0000786BC93CF75E
0000786bc93d11d9  call 0x0000786BC91FF430
0000786bc93d11de  jmp 0x0000786BC93CF7EE
0000786bc93d11e3  call 0x0000786BC91FF430
0000786bc93d11e8  jmp 0x0000786BC93CF801
0000786bc93d11ed  sub rsp, 0x08
0000786bc93d11f1  push rax
0000786bc93d11f2  push rcx
0000786bc93d11f3  push rdx
0000786bc93d11f4  push rdi
0000786bc93d11f5  push rsi
0000786bc93d11f6  push r8
0000786bc93d11f8  push r9
0000786bc93d11fa  push r10
0000786bc93d11fc  push r11
0000786bc93d11fe  sub rsp, 0xF0
0000786bc93d1205  vmovaps [rsp], xmm0
0000786bc93d120a  vmovaps [rsp+0x10], xmm2
0000786bc93d1210  vmovaps [rsp+0x20], xmm3
0000786bc93d1216  vmovaps [rsp+0x30], xmm4
0000786bc93d121c  vmovaps [rsp+0x40], xmm5
0000786bc93d1222  vmovaps [rsp+0x50], xmm6
0000786bc93d1228  vmovaps [rsp+0x60], xmm7
0000786bc93d122e  vmovaps [rsp+0x70], xmm8
0000786bc93d1234  vmovaps [rsp+0x80], xmm9
0000786bc93d123d  vmovaps [rsp+0x90], xmm10
0000786bc93d1246  vmovaps [rsp+0xA0], xmm11
0000786bc93d124f  vmovaps [rsp+0xB0], xmm12
0000786bc93d1258  vmovaps [rsp+0xC0], xmm13
0000786bc93d1261  vmovaps [rsp+0xD0], xmm14
0000786bc93d126a  vmovaps [rsp+0xE0], xmm15
0000786bc93d1273  sub rsp, 0x30
0000786bc93d1277  movaps [rsp], xmm1
0000786bc93d127b  movaps [rsp+0x10], xmm13
0000786bc93d1281  movaps [rsp+0x20], xmm2
0000786bc93d1286  lea rdi, [rsp]
0000786bc93d128a  mov esi, 0x00
0000786bc93d128f  mov rax, 0x60810F6F7530
0000786bc93d1299  call rax
0000786bc93d129b  movaps xmm1, [rsp]
0000786bc93d129f  add rsp, 0x30
0000786bc93d12a3  vmovaps xmm0, [rsp]
0000786bc93d12a8  vmovaps xmm2, [rsp+0x10]
0000786bc93d12ae  vmovaps xmm3, [rsp+0x20]
0000786bc93d12b4  vmovaps xmm4, [rsp+0x30]
0000786bc93d12ba  vmovaps xmm5, [rsp+0x40]
0000786bc93d12c0  vmovaps xmm6, [rsp+0x50]
0000786bc93d12c6  vmovaps xmm7, [rsp+0x60]
0000786bc93d12cc  vmovaps xmm8, [rsp+0x70]
0000786bc93d12d2  vmovaps xmm9, [rsp+0x80]
0000786bc93d12db  vmovaps xmm10, [rsp+0x90]
0000786bc93d12e4  vmovaps xmm11, [rsp+0xA0]
0000786bc93d12ed  vmovaps xmm12, [rsp+0xB0]
0000786bc93d12f6  vmovaps xmm13, [rsp+0xC0]
0000786bc93d12ff  vmovaps xmm14, [rsp+0xD0]
0000786bc93d1308  vmovaps xmm15, [rsp+0xE0]
0000786bc93d1311  add rsp, 0xF0
0000786bc93d1318  pop r11
0000786bc93d131a  pop r10
0000786bc93d131c  pop r9
0000786bc93d131e  pop r8
0000786bc93d1320  pop rsi
0000786bc93d1321  pop rdi
0000786bc93d1322  pop rdx
0000786bc93d1323  pop rcx
0000786bc93d1324  pop rax
0000786bc93d1325  add rsp, 0x08
0000786bc93d1329  jmp 0x0000786BC93CF82C
0000786bc93d132e  call 0x0000786BC920E760
0000786bc93d1333  jmp 0x0000786BC93CF839
0000786bc93d1338  sub rsp, 0x08
0000786bc93d133c  push rax
0000786bc93d133d  push rcx
0000786bc93d133e  push rdx
0000786bc93d133f  push rdi
0000786bc93d1340  push rsi
0000786bc93d1341  push r8
0000786bc93d1343  push r9
0000786bc93d1345  push r10
0000786bc93d1347  push r11
0000786bc93d1349  sub rsp, 0xF0
0000786bc93d1350  vmovaps [rsp], xmm0
0000786bc93d1355  vmovaps [rsp+0x10], xmm1
0000786bc93d135b  vmovaps [rsp+0x20], xmm2
0000786bc93d1361  vmovaps [rsp+0x30], xmm3
0000786bc93d1367  vmovaps [rsp+0x40], xmm4
0000786bc93d136d  vmovaps [rsp+0x50], xmm5
0000786bc93d1373  vmovaps [rsp+0x60], xmm6
0000786bc93d1379  vmovaps [rsp+0x70], xmm7
0000786bc93d137f  vmovaps [rsp+0x80], xmm8
0000786bc93d1388  vmovaps [rsp+0x90], xmm9
0000786bc93d1391  vmovaps [rsp+0xA0], xmm10
0000786bc93d139a  vmovaps [rsp+0xB0], xmm11
0000786bc93d13a3  vmovaps [rsp+0xC0], xmm12
0000786bc93d13ac  vmovaps [rsp+0xD0], xmm14
0000786bc93d13b5  vmovaps [rsp+0xE0], xmm15
0000786bc93d13be  sub rsp, 0x30
0000786bc93d13c2  movaps [rsp], xmm13
0000786bc93d13c7  movaps [rsp+0x10], xmm2
0000786bc93d13cc  movaps [rsp+0x20], xmm1
0000786bc93d13d1  lea rdi, [rsp]
0000786bc93d13d5  mov esi, 0x00
0000786bc93d13da  mov rax, 0x60810F6F7530
0000786bc93d13e4  call rax
0000786bc93d13e6  movaps xmm13, [rsp]
0000786bc93d13eb  add rsp, 0x30
0000786bc93d13ef  vmovaps xmm0, [rsp]
0000786bc93d13f4  vmovaps xmm1, [rsp+0x10]
0000786bc93d13fa  vmovaps xmm2, [rsp+0x20]
0000786bc93d1400  vmovaps xmm3, [rsp+0x30]
0000786bc93d1406  vmovaps xmm4, [rsp+0x40]
0000786bc93d140c  vmovaps xmm5, [rsp+0x50]
0000786bc93d1412  vmovaps xmm6, [rsp+0x60]
0000786bc93d1418  vmovaps xmm7, [rsp+0x70]
0000786bc93d141e  vmovaps xmm8, [rsp+0x80]
0000786bc93d1427  vmovaps xmm9, [rsp+0x90]
0000786bc93d1430  vmovaps xmm10, [rsp+0xA0]
0000786bc93d1439  vmovaps xmm11, [rsp+0xB0]
0000786bc93d1442  vmovaps xmm12, [rsp+0xC0]
0000786bc93d144b  vmovaps xmm14, [rsp+0xD0]
0000786bc93d1454  vmovaps xmm15, [rsp+0xE0]
0000786bc93d145d  add rsp, 0xF0
0000786bc93d1464  pop r11
0000786bc93d1466  pop r10
0000786bc93d1468  pop r9
0000786bc93d146a  pop r8
0000786bc93d146c  pop rsi
0000786bc93d146d  pop rdi
0000786bc93d146e  pop rdx
0000786bc93d146f  pop rcx
0000786bc93d1470  pop rax
0000786bc93d1471  add rsp, 0x08
0000786bc93d1475  jmp 0x0000786BC93CF878
0000786bc93d147a  sub rsp, 0x08
0000786bc93d147e  push rax
0000786bc93d147f  push rcx
0000786bc93d1480  push rdx
0000786bc93d1481  push rdi
0000786bc93d1482  push rsi
0000786bc93d1483  push r8
0000786bc93d1485  push r9
0000786bc93d1487  push r10
0000786bc93d1489  push r11
0000786bc93d148b  sub rsp, 0xF0
0000786bc93d1492  vmovaps [rsp], xmm0
0000786bc93d1497  vmovaps [rsp+0x10], xmm2
0000786bc93d149d  vmovaps [rsp+0x20], xmm3
0000786bc93d14a3  vmovaps [rsp+0x30], xmm4
0000786bc93d14a9  vmovaps [rsp+0x40], xmm5
0000786bc93d14af  vmovaps [rsp+0x50], xmm6
0000786bc93d14b5  vmovaps [rsp+0x60], xmm7
0000786bc93d14bb  vmovaps [rsp+0x70], xmm8
0000786bc93d14c1  vmovaps [rsp+0x80], xmm9
0000786bc93d14ca  vmovaps [rsp+0x90], xmm10
0000786bc93d14d3  vmovaps [rsp+0xA0], xmm11
0000786bc93d14dc  vmovaps [rsp+0xB0], xmm12
0000786bc93d14e5  vmovaps [rsp+0xC0], xmm13
0000786bc93d14ee  vmovaps [rsp+0xD0], xmm14
0000786bc93d14f7  vmovaps [rsp+0xE0], xmm15
0000786bc93d1500  sub rsp, 0x30
0000786bc93d1504  movaps [rsp], xmm1
0000786bc93d1508  movaps [rsp+0x10], xmm15
0000786bc93d150e  movaps [rsp+0x20], xmm2
0000786bc93d1513  lea rdi, [rsp]
0000786bc93d1517  mov esi, 0x00
0000786bc93d151c  mov rax, 0x60810F6F7530
0000786bc93d1526  call rax
0000786bc93d1528  movaps xmm1, [rsp]
0000786bc93d152c  add rsp, 0x30
0000786bc93d1530  vmovaps xmm0, [rsp]
0000786bc93d1535  vmovaps xmm2, [rsp+0x10]
0000786bc93d153b  vmovaps xmm3, [rsp+0x20]
0000786bc93d1541  vmovaps xmm4, [rsp+0x30]
0000786bc93d1547  vmovaps xmm5, [rsp+0x40]
0000786bc93d154d  vmovaps xmm6, [rsp+0x50]
0000786bc93d1553  vmovaps xmm7, [rsp+0x60]
0000786bc93d1559  vmovaps xmm8, [rsp+0x70]
0000786bc93d155f  vmovaps xmm9, [rsp+0x80]
0000786bc93d1568  vmovaps xmm10, [rsp+0x90]
0000786bc93d1571  vmovaps xmm11, [rsp+0xA0]
0000786bc93d157a  vmovaps xmm12, [rsp+0xB0]
0000786bc93d1583  vmovaps xmm13, [rsp+0xC0]
0000786bc93d158c  vmovaps xmm14, [rsp+0xD0]
0000786bc93d1595  vmovaps xmm15, [rsp+0xE0]
0000786bc93d159e  add rsp, 0xF0
0000786bc93d15a5  pop r11
0000786bc93d15a7  pop r10
0000786bc93d15a9  pop r9
0000786bc93d15ab  pop r8
0000786bc93d15ad  pop rsi
0000786bc93d15ae  pop rdi
0000786bc93d15af  pop rdx
0000786bc93d15b0  pop rcx
0000786bc93d15b1  pop rax
0000786bc93d15b2  add rsp, 0x08
0000786bc93d15b6  jmp 0x0000786BC93CF8AC
0000786bc93d15bb  sub rsp, 0x08
0000786bc93d15bf  push rax
0000786bc93d15c0  push rcx
0000786bc93d15c1  push rdx
0000786bc93d15c2  push rdi
0000786bc93d15c3  push rsi
0000786bc93d15c4  push r8
0000786bc93d15c6  push r9
0000786bc93d15c8  push r10
0000786bc93d15ca  push r11
0000786bc93d15cc  sub rsp, 0xF0
0000786bc93d15d3  vmovaps [rsp], xmm0
0000786bc93d15d8  vmovaps [rsp+0x10], xmm1
0000786bc93d15de  vmovaps [rsp+0x20], xmm2
0000786bc93d15e4  vmovaps [rsp+0x30], xmm3
0000786bc93d15ea  vmovaps [rsp+0x40], xmm4
0000786bc93d15f0  vmovaps [rsp+0x50], xmm5
0000786bc93d15f6  vmovaps [rsp+0x60], xmm6
0000786bc93d15fc  vmovaps [rsp+0x70], xmm7
0000786bc93d1602  vmovaps [rsp+0x80], xmm8
0000786bc93d160b  vmovaps [rsp+0x90], xmm9
0000786bc93d1614  vmovaps [rsp+0xA0], xmm10
0000786bc93d161d  vmovaps [rsp+0xB0], xmm11
0000786bc93d1626  vmovaps [rsp+0xC0], xmm12
0000786bc93d162f  vmovaps [rsp+0xD0], xmm13
0000786bc93d1638  vmovaps [rsp+0xE0], xmm15
0000786bc93d1641  sub rsp, 0x30
0000786bc93d1645  movaps [rsp], xmm14
0000786bc93d164a  movaps [rsp+0x10], xmm2
0000786bc93d164f  movaps [rsp+0x20], xmm15
0000786bc93d1655  lea rdi, [rsp]
0000786bc93d1659  mov esi, 0x00
0000786bc93d165e  mov rax, 0x60810F6F7530
0000786bc93d1668  call rax
0000786bc93d166a  movaps xmm14, [rsp]
0000786bc93d166f  add rsp, 0x30
0000786bc93d1673  vmovaps xmm0, [rsp]
0000786bc93d1678  vmovaps xmm1, [rsp+0x10]
0000786bc93d167e  vmovaps xmm2, [rsp+0x20]
0000786bc93d1684  vmovaps xmm3, [rsp+0x30]
0000786bc93d168a  vmovaps xmm4, [rsp+0x40]
0000786bc93d1690  vmovaps xmm5, [rsp+0x50]
0000786bc93d1696  vmovaps xmm6, [rsp+0x60]
0000786bc93d169c  vmovaps xmm7, [rsp+0x70]
0000786bc93d16a2  vmovaps xmm8, [rsp+0x80]
0000786bc93d16ab  vmovaps xmm9, [rsp+0x90]
0000786bc93d16b4  vmovaps xmm10, [rsp+0xA0]
0000786bc93d16bd  vmovaps xmm11, [rsp+0xB0]
0000786bc93d16c6  vmovaps xmm12, [rsp+0xC0]
0000786bc93d16cf  vmovaps xmm13, [rsp+0xD0]
0000786bc93d16d8  vmovaps xmm15, [rsp+0xE0]
0000786bc93d16e1  add rsp, 0xF0
0000786bc93d16e8  pop r11
0000786bc93d16ea  pop r10
0000786bc93d16ec  pop r9
0000786bc93d16ee  pop r8
0000786bc93d16f0  pop rsi
0000786bc93d16f1  pop rdi
0000786bc93d16f2  pop rdx
0000786bc93d16f3  pop rcx
0000786bc93d16f4  pop rax
0000786bc93d16f5  add rsp, 0x08
0000786bc93d16f9  jmp 0x0000786BC93CF8E7
0000786bc93d16fe  sub rsp, 0x08
0000786bc93d1702  push rax
0000786bc93d1703  push rcx
0000786bc93d1704  push rdx
0000786bc93d1705  push rdi
0000786bc93d1706  push rsi
0000786bc93d1707  push r8
0000786bc93d1709  push r9
0000786bc93d170b  push r10
0000786bc93d170d  push r11
0000786bc93d170f  sub rsp, 0xF0
0000786bc93d1716  vmovaps [rsp], xmm0
0000786bc93d171b  vmovaps [rsp+0x10], xmm1
0000786bc93d1721  vmovaps [rsp+0x20], xmm2
0000786bc93d1727  vmovaps [rsp+0x30], xmm3
0000786bc93d172d  vmovaps [rsp+0x40], xmm4
0000786bc93d1733  vmovaps [rsp+0x50], xmm5
0000786bc93d1739  vmovaps [rsp+0x60], xmm6
0000786bc93d173f  vmovaps [rsp+0x70], xmm7
0000786bc93d1745  vmovaps [rsp+0x80], xmm8
0000786bc93d174e  vmovaps [rsp+0x90], xmm9
0000786bc93d1757  vmovaps [rsp+0xA0], xmm10
0000786bc93d1760  vmovaps [rsp+0xB0], xmm11
0000786bc93d1769  vmovaps [rsp+0xC0], xmm12
0000786bc93d1772  vmovaps [rsp+0xD0], xmm13
0000786bc93d177b  vmovaps [rsp+0xE0], xmm14
0000786bc93d1784  sub rsp, 0x30
0000786bc93d1788  movaps [rsp], xmm15
0000786bc93d178d  movaps [rsp+0x10], xmm2
0000786bc93d1792  movaps [rsp+0x20], xmm1
0000786bc93d1797  lea rdi, [rsp]
0000786bc93d179b  mov esi, 0x00
0000786bc93d17a0  mov rax, 0x60810F6F7530
0000786bc93d17aa  call rax
0000786bc93d17ac  movaps xmm15, [rsp]
0000786bc93d17b1  add rsp, 0x30
0000786bc93d17b5  vmovaps xmm0, [rsp]
0000786bc93d17ba  vmovaps xmm1, [rsp+0x10]
0000786bc93d17c0  vmovaps xmm2, [rsp+0x20]
0000786bc93d17c6  vmovaps xmm3, [rsp+0x30]
0000786bc93d17cc  vmovaps xmm4, [rsp+0x40]
0000786bc93d17d2  vmovaps xmm5, [rsp+0x50]
0000786bc93d17d8  vmovaps xmm6, [rsp+0x60]
0000786bc93d17de  vmovaps xmm7, [rsp+0x70]
0000786bc93d17e4  vmovaps xmm8, [rsp+0x80]
0000786bc93d17ed  vmovaps xmm9, [rsp+0x90]
0000786bc93d17f6  vmovaps xmm10, [rsp+0xA0]
0000786bc93d17ff  vmovaps xmm11, [rsp+0xB0]
0000786bc93d1808  vmovaps xmm12, [rsp+0xC0]
0000786bc93d1811  vmovaps xmm13, [rsp+0xD0]
0000786bc93d181a  vmovaps xmm14, [rsp+0xE0]
0000786bc93d1823  add rsp, 0xF0
0000786bc93d182a  pop r11
0000786bc93d182c  pop r10
0000786bc93d182e  pop r9
0000786bc93d1830  pop r8
0000786bc93d1832  pop rsi
0000786bc93d1833  pop rdi
0000786bc93d1834  pop rdx
0000786bc93d1835  pop rcx
0000786bc93d1836  pop rax
0000786bc93d1837  add rsp, 0x08
0000786bc93d183b  jmp 0x0000786BC93CF923
0000786bc93d1840  call 0x0000786BC91FF430
0000786bc93d1845  jmp 0x0000786BC93CF930
0000786bc93d184a  sub rsp, 0x08
0000786bc93d184e  push rax
0000786bc93d184f  push rcx
0000786bc93d1850  push rdx
0000786bc93d1851  push rdi
0000786bc93d1852  push rsi
0000786bc93d1853  push r8
0000786bc93d1855  push r9
0000786bc93d1857  push r10
0000786bc93d1859  push r11
0000786bc93d185b  sub rsp, 0xF0
0000786bc93d1862  vmovaps [rsp], xmm0
0000786bc93d1867  vmovaps [rsp+0x10], xmm1
0000786bc93d186d  vmovaps [rsp+0x20], xmm3
0000786bc93d1873  vmovaps [rsp+0x30], xmm4
0000786bc93d1879  vmovaps [rsp+0x40], xmm5
0000786bc93d187f  vmovaps [rsp+0x50], xmm6
0000786bc93d1885  vmovaps [rsp+0x60], xmm7
0000786bc93d188b  vmovaps [rsp+0x70], xmm8
0000786bc93d1891  vmovaps [rsp+0x80], xmm9
0000786bc93d189a  vmovaps [rsp+0x90], xmm10
0000786bc93d18a3  vmovaps [rsp+0xA0], xmm11
0000786bc93d18ac  vmovaps [rsp+0xB0], xmm12
0000786bc93d18b5  vmovaps [rsp+0xC0], xmm13
0000786bc93d18be  vmovaps [rsp+0xD0], xmm14
0000786bc93d18c7  vmovaps [rsp+0xE0], xmm15
0000786bc93d18d0  sub rsp, 0x30
0000786bc93d18d4  movaps [rsp], xmm2
0000786bc93d18d8  movaps [rsp+0x10], xmm1
0000786bc93d18dd  movaps [rsp+0x20], xmm14
0000786bc93d18e3  lea rdi, [rsp]
0000786bc93d18e7  mov esi, 0x00
0000786bc93d18ec  mov rax, 0x60810F6F7530
0000786bc93d18f6  call rax
0000786bc93d18f8  movaps xmm2, [rsp]
0000786bc93d18fc  add rsp, 0x30
0000786bc93d1900  vmovaps xmm0, [rsp]
0000786bc93d1905  vmovaps xmm1, [rsp+0x10]
0000786bc93d190b  vmovaps xmm3, [rsp+0x20]
0000786bc93d1911  vmovaps xmm4, [rsp+0x30]
0000786bc93d1917  vmovaps xmm5, [rsp+0x40]
0000786bc93d191d  vmovaps xmm6, [rsp+0x50]
0000786bc93d1923  vmovaps xmm7, [rsp+0x60]
0000786bc93d1929  vmovaps xmm8, [rsp+0x70]
0000786bc93d192f  vmovaps xmm9, [rsp+0x80]
0000786bc93d1938  vmovaps xmm10, [rsp+0x90]
0000786bc93d1941  vmovaps xmm11, [rsp+0xA0]
0000786bc93d194a  vmovaps xmm12, [rsp+0xB0]
0000786bc93d1953  vmovaps xmm13, [rsp+0xC0]
0000786bc93d195c  vmovaps xmm14, [rsp+0xD0]
0000786bc93d1965  vmovaps xmm15, [rsp+0xE0]
0000786bc93d196e  add rsp, 0xF0
0000786bc93d1975  pop r11
0000786bc93d1977  pop r10
0000786bc93d1979  pop r9
0000786bc93d197b  pop r8
0000786bc93d197d  pop rsi
0000786bc93d197e  pop rdi
0000786bc93d197f  pop rdx
0000786bc93d1980  pop rcx
0000786bc93d1981  pop rax
0000786bc93d1982  add rsp, 0x08
0000786bc93d1986  jmp 0x0000786BC93CF96D
0000786bc93d198b  sub rsp, 0x08
0000786bc93d198f  push rax
0000786bc93d1990  push rcx
0000786bc93d1991  push rdx
0000786bc93d1992  push rdi
0000786bc93d1993  push rsi
0000786bc93d1994  push r8
0000786bc93d1996  push r9
0000786bc93d1998  push r10
0000786bc93d199a  push r11
0000786bc93d199c  sub rsp, 0xF0
0000786bc93d19a3  vmovaps [rsp], xmm0
0000786bc93d19a8  vmovaps [rsp+0x10], xmm1
0000786bc93d19ae  vmovaps [rsp+0x20], xmm2
0000786bc93d19b4  vmovaps [rsp+0x30], xmm3
0000786bc93d19ba  vmovaps [rsp+0x40], xmm4
0000786bc93d19c0  vmovaps [rsp+0x50], xmm5
0000786bc93d19c6  vmovaps [rsp+0x60], xmm6
0000786bc93d19cc  vmovaps [rsp+0x70], xmm7
0000786bc93d19d2  vmovaps [rsp+0x80], xmm8
0000786bc93d19db  vmovaps [rsp+0x90], xmm9
0000786bc93d19e4  vmovaps [rsp+0xA0], xmm10
0000786bc93d19ed  vmovaps [rsp+0xB0], xmm11
0000786bc93d19f6  vmovaps [rsp+0xC0], xmm12
0000786bc93d19ff  vmovaps [rsp+0xD0], xmm13
0000786bc93d1a08  vmovaps [rsp+0xE0], xmm14
0000786bc93d1a11  sub rsp, 0x30
0000786bc93d1a15  movaps [rsp], xmm15
0000786bc93d1a1a  movaps [rsp+0x10], xmm14
0000786bc93d1a20  movaps [rsp+0x20], xmm1
0000786bc93d1a25  lea rdi, [rsp]
0000786bc93d1a29  mov esi, 0x00
0000786bc93d1a2e  mov rax, 0x60810F6F7530
0000786bc93d1a38  call rax
0000786bc93d1a3a  movaps xmm15, [rsp]
0000786bc93d1a3f  add rsp, 0x30
0000786bc93d1a43  vmovaps xmm0, [rsp]
0000786bc93d1a48  vmovaps xmm1, [rsp+0x10]
0000786bc93d1a4e  vmovaps xmm2, [rsp+0x20]
0000786bc93d1a54  vmovaps xmm3, [rsp+0x30]
0000786bc93d1a5a  vmovaps xmm4, [rsp+0x40]
0000786bc93d1a60  vmovaps xmm5, [rsp+0x50]
0000786bc93d1a66  vmovaps xmm6, [rsp+0x60]
0000786bc93d1a6c  vmovaps xmm7, [rsp+0x70]
0000786bc93d1a72  vmovaps xmm8, [rsp+0x80]
0000786bc93d1a7b  vmovaps xmm9, [rsp+0x90]
0000786bc93d1a84  vmovaps xmm10, [rsp+0xA0]
0000786bc93d1a8d  vmovaps xmm11, [rsp+0xB0]
0000786bc93d1a96  vmovaps xmm12, [rsp+0xC0]
0000786bc93d1a9f  vmovaps xmm13, [rsp+0xD0]
0000786bc93d1aa8  vmovaps xmm14, [rsp+0xE0]
0000786bc93d1ab1  add rsp, 0xF0
0000786bc93d1ab8  pop r11
0000786bc93d1aba  pop r10
0000786bc93d1abc  pop r9
0000786bc93d1abe  pop r8
0000786bc93d1ac0  pop rsi
0000786bc93d1ac1  pop rdi
0000786bc93d1ac2  pop rdx
0000786bc93d1ac3  pop rcx
0000786bc93d1ac4  pop rax
0000786bc93d1ac5  add rsp, 0x08
0000786bc93d1ac9  jmp 0x0000786BC93CF9E7
0000786bc93d1ace  call 0x0000786BC91FF430
0000786bc93d1ad3  jmp 0x0000786BC93CF9F4
0000786bc93d1ad8  sub rsp, 0x08
0000786bc93d1adc  push rax
0000786bc93d1add  push rcx
0000786bc93d1ade  push rdx
0000786bc93d1adf  push rdi
0000786bc93d1ae0  push rsi
0000786bc93d1ae1  push r8
0000786bc93d1ae3  push r9
0000786bc93d1ae5  push r10
0000786bc93d1ae7  push r11
0000786bc93d1ae9  sub rsp, 0xF0
0000786bc93d1af0  vmovaps [rsp], xmm0
0000786bc93d1af5  vmovaps [rsp+0x10], xmm1
0000786bc93d1afb  vmovaps [rsp+0x20], xmm2
0000786bc93d1b01  vmovaps [rsp+0x30], xmm3
0000786bc93d1b07  vmovaps [rsp+0x40], xmm4
0000786bc93d1b0d  vmovaps [rsp+0x50], xmm5
0000786bc93d1b13  vmovaps [rsp+0x60], xmm6
0000786bc93d1b19  vmovaps [rsp+0x70], xmm7
0000786bc93d1b1f  vmovaps [rsp+0x80], xmm8
0000786bc93d1b28  vmovaps [rsp+0x90], xmm9
0000786bc93d1b31  vmovaps [rsp+0xA0], xmm10
0000786bc93d1b3a  vmovaps [rsp+0xB0], xmm11
0000786bc93d1b43  vmovaps [rsp+0xC0], xmm12
0000786bc93d1b4c  vmovaps [rsp+0xD0], xmm13
0000786bc93d1b55  vmovaps [rsp+0xE0], xmm15
0000786bc93d1b5e  sub rsp, 0x30
0000786bc93d1b62  movaps [rsp], xmm14
0000786bc93d1b67  movaps [rsp+0x10], xmm13
0000786bc93d1b6d  movaps [rsp+0x20], xmm1
0000786bc93d1b72  lea rdi, [rsp]
0000786bc93d1b76  mov esi, 0x00
0000786bc93d1b7b  mov rax, 0x60810F6F7530
0000786bc93d1b85  call rax
0000786bc93d1b87  movaps xmm14, [rsp]
0000786bc93d1b8c  add rsp, 0x30
0000786bc93d1b90  vmovaps xmm0, [rsp]
0000786bc93d1b95  vmovaps xmm1, [rsp+0x10]
0000786bc93d1b9b  vmovaps xmm2, [rsp+0x20]
0000786bc93d1ba1  vmovaps xmm3, [rsp+0x30]
0000786bc93d1ba7  vmovaps xmm4, [rsp+0x40]
0000786bc93d1bad  vmovaps xmm5, [rsp+0x50]
0000786bc93d1bb3  vmovaps xmm6, [rsp+0x60]
0000786bc93d1bb9  vmovaps xmm7, [rsp+0x70]
0000786bc93d1bbf  vmovaps xmm8, [rsp+0x80]
0000786bc93d1bc8  vmovaps xmm9, [rsp+0x90]
0000786bc93d1bd1  vmovaps xmm10, [rsp+0xA0]
0000786bc93d1bda  vmovaps xmm11, [rsp+0xB0]
0000786bc93d1be3  vmovaps xmm12, [rsp+0xC0]
0000786bc93d1bec  vmovaps xmm13, [rsp+0xD0]
0000786bc93d1bf5  vmovaps xmm15, [rsp+0xE0]
0000786bc93d1bfe  add rsp, 0xF0
0000786bc93d1c05  pop r11
0000786bc93d1c07  pop r10
0000786bc93d1c09  pop r9
0000786bc93d1c0b  pop r8
0000786bc93d1c0d  pop rsi
0000786bc93d1c0e  pop rdi
0000786bc93d1c0f  pop rdx
0000786bc93d1c10  pop rcx
0000786bc93d1c11  pop rax
0000786bc93d1c12  add rsp, 0x08
0000786bc93d1c16  jmp 0x0000786BC93CFAAF
0000786bc93d1c1b  sub rsp, 0x08
0000786bc93d1c1f  push rax
0000786bc93d1c20  push rcx
0000786bc93d1c21  push rdx
0000786bc93d1c22  push rdi
0000786bc93d1c23  push rsi
0000786bc93d1c24  push r8
0000786bc93d1c26  push r9
0000786bc93d1c28  push r10
0000786bc93d1c2a  push r11
0000786bc93d1c2c  sub rsp, 0xF0
0000786bc93d1c33  vmovaps [rsp], xmm0
0000786bc93d1c38  vmovaps [rsp+0x10], xmm1
0000786bc93d1c3e  vmovaps [rsp+0x20], xmm2
0000786bc93d1c44  vmovaps [rsp+0x30], xmm3
0000786bc93d1c4a  vmovaps [rsp+0x40], xmm4
0000786bc93d1c50  vmovaps [rsp+0x50], xmm5
0000786bc93d1c56  vmovaps [rsp+0x60], xmm6
0000786bc93d1c5c  vmovaps [rsp+0x70], xmm7
0000786bc93d1c62  vmovaps [rsp+0x80], xmm8
0000786bc93d1c6b  vmovaps [rsp+0x90], xmm9
0000786bc93d1c74  vmovaps [rsp+0xA0], xmm10
0000786bc93d1c7d  vmovaps [rsp+0xB0], xmm11
0000786bc93d1c86  vmovaps [rsp+0xC0], xmm12
0000786bc93d1c8f  vmovaps [rsp+0xD0], xmm13
0000786bc93d1c98  vmovaps [rsp+0xE0], xmm14
0000786bc93d1ca1  sub rsp, 0x30
0000786bc93d1ca5  movaps [rsp], xmm15
0000786bc93d1caa  movaps [rsp+0x10], xmm13
0000786bc93d1cb0  movaps [rsp+0x20], xmm1
0000786bc93d1cb5  lea rdi, [rsp]
0000786bc93d1cb9  mov esi, 0x00
0000786bc93d1cbe  mov rax, 0x60810F6F7530
0000786bc93d1cc8  call rax
0000786bc93d1cca  movaps xmm15, [rsp]
0000786bc93d1ccf  add rsp, 0x30
0000786bc93d1cd3  vmovaps xmm0, [rsp]
0000786bc93d1cd8  vmovaps xmm1, [rsp+0x10]
0000786bc93d1cde  vmovaps xmm2, [rsp+0x20]
0000786bc93d1ce4  vmovaps xmm3, [rsp+0x30]
0000786bc93d1cea  vmovaps xmm4, [rsp+0x40]
0000786bc93d1cf0  vmovaps xmm5, [rsp+0x50]
0000786bc93d1cf6  vmovaps xmm6, [rsp+0x60]
0000786bc93d1cfc  vmovaps xmm7, [rsp+0x70]
0000786bc93d1d02  vmovaps xmm8, [rsp+0x80]
0000786bc93d1d0b  vmovaps xmm9, [rsp+0x90]
0000786bc93d1d14  vmovaps xmm10, [rsp+0xA0]
0000786bc93d1d1d  vmovaps xmm11, [rsp+0xB0]
0000786bc93d1d26  vmovaps xmm12, [rsp+0xC0]
0000786bc93d1d2f  vmovaps xmm13, [rsp+0xD0]
0000786bc93d1d38  vmovaps xmm14, [rsp+0xE0]
0000786bc93d1d41  add rsp, 0xF0
0000786bc93d1d48  pop r11
0000786bc93d1d4a  pop r10
0000786bc93d1d4c  pop r9
0000786bc93d1d4e  pop r8
0000786bc93d1d50  pop rsi
0000786bc93d1d51  pop rdi
0000786bc93d1d52  pop rdx
0000786bc93d1d53  pop rcx
0000786bc93d1d54  pop rax
0000786bc93d1d55  add rsp, 0x08
0000786bc93d1d59  jmp 0x0000786BC93CFAEB
0000786bc93d1d5e  call 0x0000786BC91FF430
0000786bc93d1d63  jmp 0x0000786BC93CFAF8
0000786bc93d1d68  sub rsp, 0x08
0000786bc93d1d6c  push rax
0000786bc93d1d6d  push rcx
0000786bc93d1d6e  push rdx
0000786bc93d1d6f  push rdi
0000786bc93d1d70  push rsi
0000786bc93d1d71  push r8
0000786bc93d1d73  push r9
0000786bc93d1d75  push r10
0000786bc93d1d77  push r11
0000786bc93d1d79  sub rsp, 0xF0
0000786bc93d1d80  vmovaps [rsp], xmm0
0000786bc93d1d85  vmovaps [rsp+0x10], xmm1
0000786bc93d1d8b  vmovaps [rsp+0x20], xmm2
0000786bc93d1d91  vmovaps [rsp+0x30], xmm3
0000786bc93d1d97  vmovaps [rsp+0x40], xmm4
0000786bc93d1d9d  vmovaps [rsp+0x50], xmm5
0000786bc93d1da3  vmovaps [rsp+0x60], xmm6
0000786bc93d1da9  vmovaps [rsp+0x70], xmm7
0000786bc93d1daf  vmovaps [rsp+0x80], xmm8
0000786bc93d1db8  vmovaps [rsp+0x90], xmm9
0000786bc93d1dc1  vmovaps [rsp+0xA0], xmm10
0000786bc93d1dca  vmovaps [rsp+0xB0], xmm11
0000786bc93d1dd3  vmovaps [rsp+0xC0], xmm12
0000786bc93d1ddc  vmovaps [rsp+0xD0], xmm13
0000786bc93d1de5  vmovaps [rsp+0xE0], xmm15
0000786bc93d1dee  sub rsp, 0x30
0000786bc93d1df2  movaps [rsp], xmm14
0000786bc93d1df7  movaps [rsp+0x10], xmm13
0000786bc93d1dfd  movaps [rsp+0x20], xmm2
0000786bc93d1e02  lea rdi, [rsp]
0000786bc93d1e06  mov esi, 0x00
0000786bc93d1e0b  mov rax, 0x60810F6F7530
0000786bc93d1e15  call rax
0000786bc93d1e17  movaps xmm14, [rsp]
0000786bc93d1e1c  add rsp, 0x30
0000786bc93d1e20  vmovaps xmm0, [rsp]
0000786bc93d1e25  vmovaps xmm1, [rsp+0x10]
0000786bc93d1e2b  vmovaps xmm2, [rsp+0x20]
0000786bc93d1e31  vmovaps xmm3, [rsp+0x30]
0000786bc93d1e37  vmovaps xmm4, [rsp+0x40]
0000786bc93d1e3d  vmovaps xmm5, [rsp+0x50]
0000786bc93d1e43  vmovaps xmm6, [rsp+0x60]
0000786bc93d1e49  vmovaps xmm7, [rsp+0x70]
0000786bc93d1e4f  vmovaps xmm8, [rsp+0x80]
0000786bc93d1e58  vmovaps xmm9, [rsp+0x90]
0000786bc93d1e61  vmovaps xmm10, [rsp+0xA0]
0000786bc93d1e6a  vmovaps xmm11, [rsp+0xB0]
0000786bc93d1e73  vmovaps xmm12, [rsp+0xC0]
0000786bc93d1e7c  vmovaps xmm13, [rsp+0xD0]
0000786bc93d1e85  vmovaps xmm15, [rsp+0xE0]
0000786bc93d1e8e  add rsp, 0xF0
0000786bc93d1e95  pop r11
0000786bc93d1e97  pop r10
0000786bc93d1e99  pop r9
0000786bc93d1e9b  pop r8
0000786bc93d1e9d  pop rsi
0000786bc93d1e9e  pop rdi
0000786bc93d1e9f  pop rdx
0000786bc93d1ea0  pop rcx
0000786bc93d1ea1  pop rax
0000786bc93d1ea2  add rsp, 0x08
0000786bc93d1ea6  jmp 0x0000786BC93CFB24
0000786bc93d1eab  sub rsp, 0x08
0000786bc93d1eaf  push rax
0000786bc93d1eb0  push rcx
0000786bc93d1eb1  push rdx
0000786bc93d1eb2  push rdi
0000786bc93d1eb3  push rsi
0000786bc93d1eb4  push r8
0000786bc93d1eb6  push r9
0000786bc93d1eb8  push r10
0000786bc93d1eba  push r11
0000786bc93d1ebc  sub rsp, 0xF0
0000786bc93d1ec3  vmovaps [rsp], xmm0
0000786bc93d1ec8  vmovaps [rsp+0x10], xmm2
0000786bc93d1ece  vmovaps [rsp+0x20], xmm3
0000786bc93d1ed4  vmovaps [rsp+0x30], xmm4
0000786bc93d1eda  vmovaps [rsp+0x40], xmm5
0000786bc93d1ee0  vmovaps [rsp+0x50], xmm6
0000786bc93d1ee6  vmovaps [rsp+0x60], xmm7
0000786bc93d1eec  vmovaps [rsp+0x70], xmm8
0000786bc93d1ef2  vmovaps [rsp+0x80], xmm9
0000786bc93d1efb  vmovaps [rsp+0x90], xmm10
0000786bc93d1f04  vmovaps [rsp+0xA0], xmm11
0000786bc93d1f0d  vmovaps [rsp+0xB0], xmm12
0000786bc93d1f16  vmovaps [rsp+0xC0], xmm13
0000786bc93d1f1f  vmovaps [rsp+0xD0], xmm14
0000786bc93d1f28  vmovaps [rsp+0xE0], xmm15
0000786bc93d1f31  sub rsp, 0x30
0000786bc93d1f35  movaps [rsp], xmm1
0000786bc93d1f39  movaps [rsp+0x10], xmm13
0000786bc93d1f3f  movaps [rsp+0x20], xmm2
0000786bc93d1f44  lea rdi, [rsp]
0000786bc93d1f48  mov esi, 0x00
0000786bc93d1f4d  mov rax, 0x60810F6F7530
0000786bc93d1f57  call rax
0000786bc93d1f59  movaps xmm1, [rsp]
0000786bc93d1f5d  add rsp, 0x30
0000786bc93d1f61  vmovaps xmm0, [rsp]
0000786bc93d1f66  vmovaps xmm2, [rsp+0x10]
0000786bc93d1f6c  vmovaps xmm3, [rsp+0x20]
0000786bc93d1f72  vmovaps xmm4, [rsp+0x30]
0000786bc93d1f78  vmovaps xmm5, [rsp+0x40]
0000786bc93d1f7e  vmovaps xmm6, [rsp+0x50]
0000786bc93d1f84  vmovaps xmm7, [rsp+0x60]
0000786bc93d1f8a  vmovaps xmm8, [rsp+0x70]
0000786bc93d1f90  vmovaps xmm9, [rsp+0x80]
0000786bc93d1f99  vmovaps xmm10, [rsp+0x90]
0000786bc93d1fa2  vmovaps xmm11, [rsp+0xA0]
0000786bc93d1fab  vmovaps xmm12, [rsp+0xB0]
0000786bc93d1fb4  vmovaps xmm13, [rsp+0xC0]
0000786bc93d1fbd  vmovaps xmm14, [rsp+0xD0]
0000786bc93d1fc6  vmovaps xmm15, [rsp+0xE0]
0000786bc93d1fcf  add rsp, 0xF0
0000786bc93d1fd6  pop r11
0000786bc93d1fd8  pop r10
0000786bc93d1fda  pop r9
0000786bc93d1fdc  pop r8
0000786bc93d1fde  pop rsi
0000786bc93d1fdf  pop rdi
0000786bc93d1fe0  pop rdx
0000786bc93d1fe1  pop rcx
0000786bc93d1fe2  pop rax
0000786bc93d1fe3  add rsp, 0x08
0000786bc93d1fe7  jmp 0x0000786BC93CFB52
0000786bc93d1fec  sub rsp, 0x08
0000786bc93d1ff0  push rax
0000786bc93d1ff1  push rcx
0000786bc93d1ff2  push rdx
0000786bc93d1ff3  push rdi
0000786bc93d1ff4  push rsi
0000786bc93d1ff5  push r8
0000786bc93d1ff7  push r9
0000786bc93d1ff9  push r10
0000786bc93d1ffb  push r11
0000786bc93d1ffd  sub rsp, 0xF0
0000786bc93d2004  vmovaps [rsp], xmm0
0000786bc93d2009  vmovaps [rsp+0x10], xmm1
0000786bc93d200f  vmovaps [rsp+0x20], xmm3
0000786bc93d2015  vmovaps [rsp+0x30], xmm4
0000786bc93d201b  vmovaps [rsp+0x40], xmm5
0000786bc93d2021  vmovaps [rsp+0x50], xmm6
0000786bc93d2027  vmovaps [rsp+0x60], xmm7
0000786bc93d202d  vmovaps [rsp+0x70], xmm8
0000786bc93d2033  vmovaps [rsp+0x80], xmm9
0000786bc93d203c  vmovaps [rsp+0x90], xmm10
0000786bc93d2045  vmovaps [rsp+0xA0], xmm11
0000786bc93d204e  vmovaps [rsp+0xB0], xmm12
0000786bc93d2057  vmovaps [rsp+0xC0], xmm13
0000786bc93d2060  vmovaps [rsp+0xD0], xmm14
0000786bc93d2069  vmovaps [rsp+0xE0], xmm15
0000786bc93d2072  sub rsp, 0x30
0000786bc93d2076  movaps [rsp], xmm2
0000786bc93d207a  movaps [rsp+0x10], xmm1
0000786bc93d207f  movaps [rsp+0x20], xmm13
0000786bc93d2085  lea rdi, [rsp]
0000786bc93d2089  mov esi, 0x00
0000786bc93d208e  mov rax, 0x60810F6F7530
0000786bc93d2098  call rax
0000786bc93d209a  movaps xmm2, [rsp]
0000786bc93d209e  add rsp, 0x30
0000786bc93d20a2  vmovaps xmm0, [rsp]
0000786bc93d20a7  vmovaps xmm1, [rsp+0x10]
0000786bc93d20ad  vmovaps xmm3, [rsp+0x20]
0000786bc93d20b3  vmovaps xmm4, [rsp+0x30]
0000786bc93d20b9  vmovaps xmm5, [rsp+0x40]
0000786bc93d20bf  vmovaps xmm6, [rsp+0x50]
0000786bc93d20c5  vmovaps xmm7, [rsp+0x60]
0000786bc93d20cb  vmovaps xmm8, [rsp+0x70]
0000786bc93d20d1  vmovaps xmm9, [rsp+0x80]
0000786bc93d20da  vmovaps xmm10, [rsp+0x90]
0000786bc93d20e3  vmovaps xmm11, [rsp+0xA0]
0000786bc93d20ec  vmovaps xmm12, [rsp+0xB0]
0000786bc93d20f5  vmovaps xmm13, [rsp+0xC0]
0000786bc93d20fe  vmovaps xmm14, [rsp+0xD0]
0000786bc93d2107  vmovaps xmm15, [rsp+0xE0]
0000786bc93d2110  add rsp, 0xF0
0000786bc93d2117  pop r11
0000786bc93d2119  pop r10
0000786bc93d211b  pop r9
0000786bc93d211d  pop r8
0000786bc93d211f  pop rsi
0000786bc93d2120  pop rdi
0000786bc93d2121  pop rdx
0000786bc93d2122  pop rcx
0000786bc93d2123  pop rax
0000786bc93d2124  add rsp, 0x08
0000786bc93d2128  jmp 0x0000786BC93CFBAB
0000786bc93d212d  call 0x0000786BC91FF430
0000786bc93d2132  jmp 0x0000786BC93CFBB8
0000786bc93d2137  sub rsp, 0x08
0000786bc93d213b  push rax
0000786bc93d213c  push rcx
0000786bc93d213d  push rdx
0000786bc93d213e  push rdi
0000786bc93d213f  push rsi
0000786bc93d2140  push r8
0000786bc93d2142  push r9
0000786bc93d2144  push r10
0000786bc93d2146  push r11
0000786bc93d2148  sub rsp, 0xF0
0000786bc93d214f  vmovaps [rsp], xmm0
0000786bc93d2154  vmovaps [rsp+0x10], xmm1
0000786bc93d215a  vmovaps [rsp+0x20], xmm2
0000786bc93d2160  vmovaps [rsp+0x30], xmm3
0000786bc93d2166  vmovaps [rsp+0x40], xmm4
0000786bc93d216c  vmovaps [rsp+0x50], xmm5
0000786bc93d2172  vmovaps [rsp+0x60], xmm6
0000786bc93d2178  vmovaps [rsp+0x70], xmm7
0000786bc93d217e  vmovaps [rsp+0x80], xmm8
0000786bc93d2187  vmovaps [rsp+0x90], xmm9
0000786bc93d2190  vmovaps [rsp+0xA0], xmm10
0000786bc93d2199  vmovaps [rsp+0xB0], xmm11
0000786bc93d21a2  vmovaps [rsp+0xC0], xmm12
0000786bc93d21ab  vmovaps [rsp+0xD0], xmm13
0000786bc93d21b4  vmovaps [rsp+0xE0], xmm14
0000786bc93d21bd  sub rsp, 0x30
0000786bc93d21c1  movaps [rsp], xmm15
0000786bc93d21c6  movaps [rsp+0x10], xmm13
0000786bc93d21cc  movaps [rsp+0x20], xmm1
0000786bc93d21d1  lea rdi, [rsp]
0000786bc93d21d5  mov esi, 0x00
0000786bc93d21da  mov rax, 0x60810F6F7530
0000786bc93d21e4  call rax
0000786bc93d21e6  movaps xmm15, [rsp]
0000786bc93d21eb  add rsp, 0x30
0000786bc93d21ef  vmovaps xmm0, [rsp]
0000786bc93d21f4  vmovaps xmm1, [rsp+0x10]
0000786bc93d21fa  vmovaps xmm2, [rsp+0x20]
0000786bc93d2200  vmovaps xmm3, [rsp+0x30]
0000786bc93d2206  vmovaps xmm4, [rsp+0x40]
0000786bc93d220c  vmovaps xmm5, [rsp+0x50]
0000786bc93d2212  vmovaps xmm6, [rsp+0x60]
0000786bc93d2218  vmovaps xmm7, [rsp+0x70]
0000786bc93d221e  vmovaps xmm8, [rsp+0x80]
0000786bc93d2227  vmovaps xmm9, [rsp+0x90]
0000786bc93d2230  vmovaps xmm10, [rsp+0xA0]
0000786bc93d2239  vmovaps xmm11, [rsp+0xB0]
0000786bc93d2242  vmovaps xmm12, [rsp+0xC0]
0000786bc93d224b  vmovaps xmm13, [rsp+0xD0]
0000786bc93d2254  vmovaps xmm14, [rsp+0xE0]
0000786bc93d225d  add rsp, 0xF0
0000786bc93d2264  pop r11
0000786bc93d2266  pop r10
0000786bc93d2268  pop r9
0000786bc93d226a  pop r8
0000786bc93d226c  pop rsi
0000786bc93d226d  pop rdi
0000786bc93d226e  pop rdx
0000786bc93d226f  pop rcx
0000786bc93d2270  pop rax
0000786bc93d2271  add rsp, 0x08
0000786bc93d2275  jmp 0x0000786BC93CFBF7
0000786bc93d227a  sub rsp, 0x08
0000786bc93d227e  push rax
0000786bc93d227f  push rcx
0000786bc93d2280  push rdx
0000786bc93d2281  push rdi
0000786bc93d2282  push rsi
0000786bc93d2283  push r8
0000786bc93d2285  push r9
0000786bc93d2287  push r10
0000786bc93d2289  push r11
0000786bc93d228b  sub rsp, 0xF0
0000786bc93d2292  vmovaps [rsp], xmm0
0000786bc93d2297  vmovaps [rsp+0x10], xmm1
0000786bc93d229d  vmovaps [rsp+0x20], xmm2
0000786bc93d22a3  vmovaps [rsp+0x30], xmm3
0000786bc93d22a9  vmovaps [rsp+0x40], xmm4
0000786bc93d22af  vmovaps [rsp+0x50], xmm5
0000786bc93d22b5  vmovaps [rsp+0x60], xmm6
0000786bc93d22bb  vmovaps [rsp+0x70], xmm7
0000786bc93d22c1  vmovaps [rsp+0x80], xmm8
0000786bc93d22ca  vmovaps [rsp+0x90], xmm9
0000786bc93d22d3  vmovaps [rsp+0xA0], xmm10
0000786bc93d22dc  vmovaps [rsp+0xB0], xmm11
0000786bc93d22e5  vmovaps [rsp+0xC0], xmm12
0000786bc93d22ee  vmovaps [rsp+0xD0], xmm13
0000786bc93d22f7  vmovaps [rsp+0xE0], xmm15
0000786bc93d2300  sub rsp, 0x30
0000786bc93d2304  movaps [rsp], xmm14
0000786bc93d2309  movaps [rsp+0x10], xmm11
0000786bc93d230f  movaps [rsp+0x20], xmm1
0000786bc93d2314  lea rdi, [rsp]
0000786bc93d2318  mov esi, 0x00
0000786bc93d231d  mov rax, 0x60810F6F7530
0000786bc93d2327  call rax
0000786bc93d2329  movaps xmm14, [rsp]
0000786bc93d232e  add rsp, 0x30
0000786bc93d2332  vmovaps xmm0, [rsp]
0000786bc93d2337  vmovaps xmm1, [rsp+0x10]
0000786bc93d233d  vmovaps xmm2, [rsp+0x20]
0000786bc93d2343  vmovaps xmm3, [rsp+0x30]
0000786bc93d2349  vmovaps xmm4, [rsp+0x40]
0000786bc93d234f  vmovaps xmm5, [rsp+0x50]
0000786bc93d2355  vmovaps xmm6, [rsp+0x60]
0000786bc93d235b  vmovaps xmm7, [rsp+0x70]
0000786bc93d2361  vmovaps xmm8, [rsp+0x80]
0000786bc93d236a  vmovaps xmm9, [rsp+0x90]
0000786bc93d2373  vmovaps xmm10, [rsp+0xA0]
0000786bc93d237c  vmovaps xmm11, [rsp+0xB0]
0000786bc93d2385  vmovaps xmm12, [rsp+0xC0]
0000786bc93d238e  vmovaps xmm13, [rsp+0xD0]
0000786bc93d2397  vmovaps xmm15, [rsp+0xE0]
0000786bc93d23a0  add rsp, 0xF0
0000786bc93d23a7  pop r11
0000786bc93d23a9  pop r10
0000786bc93d23ab  pop r9
0000786bc93d23ad  pop r8
0000786bc93d23af  pop rsi
0000786bc93d23b0  pop rdi
0000786bc93d23b1  pop rdx
0000786bc93d23b2  pop rcx
0000786bc93d23b3  pop rax
0000786bc93d23b4  add rsp, 0x08
0000786bc93d23b8  jmp 0x0000786BC93CFC21
0000786bc93d23bd  sub rsp, 0x08
0000786bc93d23c1  push rax
0000786bc93d23c2  push rcx
0000786bc93d23c3  push rdx
0000786bc93d23c4  push rdi
0000786bc93d23c5  push rsi
0000786bc93d23c6  push r8
0000786bc93d23c8  push r9
0000786bc93d23ca  push r10
0000786bc93d23cc  push r11
0000786bc93d23ce  sub rsp, 0xF0
0000786bc93d23d5  vmovaps [rsp], xmm0
0000786bc93d23da  vmovaps [rsp+0x10], xmm1
0000786bc93d23e0  vmovaps [rsp+0x20], xmm2
0000786bc93d23e6  vmovaps [rsp+0x30], xmm3
0000786bc93d23ec  vmovaps [rsp+0x40], xmm4
0000786bc93d23f2  vmovaps [rsp+0x50], xmm5
0000786bc93d23f8  vmovaps [rsp+0x60], xmm6
0000786bc93d23fe  vmovaps [rsp+0x70], xmm7
0000786bc93d2404  vmovaps [rsp+0x80], xmm8
0000786bc93d240d  vmovaps [rsp+0x90], xmm9
0000786bc93d2416  vmovaps [rsp+0xA0], xmm10
0000786bc93d241f  vmovaps [rsp+0xB0], xmm11
0000786bc93d2428  vmovaps [rsp+0xC0], xmm12
0000786bc93d2431  vmovaps [rsp+0xD0], xmm14
0000786bc93d243a  vmovaps [rsp+0xE0], xmm15
0000786bc93d2443  sub rsp, 0x30
0000786bc93d2447  movaps [rsp], xmm13
0000786bc93d244c  movaps [rsp+0x10], xmm11
0000786bc93d2452  movaps [rsp+0x20], xmm1
0000786bc93d2457  lea rdi, [rsp]
0000786bc93d245b  mov esi, 0x00
0000786bc93d2460  mov rax, 0x60810F6F7530
0000786bc93d246a  call rax
0000786bc93d246c  movaps xmm13, [rsp]
0000786bc93d2471  add rsp, 0x30
0000786bc93d2475  vmovaps xmm0, [rsp]
0000786bc93d247a  vmovaps xmm1, [rsp+0x10]
0000786bc93d2480  vmovaps xmm2, [rsp+0x20]
0000786bc93d2486  vmovaps xmm3, [rsp+0x30]
0000786bc93d248c  vmovaps xmm4, [rsp+0x40]
0000786bc93d2492  vmovaps xmm5, [rsp+0x50]
0000786bc93d2498  vmovaps xmm6, [rsp+0x60]
0000786bc93d249e  vmovaps xmm7, [rsp+0x70]
0000786bc93d24a4  vmovaps xmm8, [rsp+0x80]
0000786bc93d24ad  vmovaps xmm9, [rsp+0x90]
0000786bc93d24b6  vmovaps xmm10, [rsp+0xA0]
0000786bc93d24bf  vmovaps xmm11, [rsp+0xB0]
0000786bc93d24c8  vmovaps xmm12, [rsp+0xC0]
0000786bc93d24d1  vmovaps xmm14, [rsp+0xD0]
0000786bc93d24da  vmovaps xmm15, [rsp+0xE0]
0000786bc93d24e3  add rsp, 0xF0
0000786bc93d24ea  pop r11
0000786bc93d24ec  pop r10
0000786bc93d24ee  pop r9
0000786bc93d24f0  pop r8
0000786bc93d24f2  pop rsi
0000786bc93d24f3  pop rdi
0000786bc93d24f4  pop rdx
0000786bc93d24f5  pop rcx
0000786bc93d24f6  pop rax
0000786bc93d24f7  add rsp, 0x08
0000786bc93d24fb  jmp 0x0000786BC93CFC76
0000786bc93d2500  call 0x0000786BC91FF430
0000786bc93d2505  jmp 0x0000786BC93CFC83
0000786bc93d250a  sub rsp, 0x08
0000786bc93d250e  push rax
0000786bc93d250f  push rcx
0000786bc93d2510  push rdx
0000786bc93d2511  push rdi
0000786bc93d2512  push rsi
0000786bc93d2513  push r8
0000786bc93d2515  push r9
0000786bc93d2517  push r10
0000786bc93d2519  push r11
0000786bc93d251b  sub rsp, 0xF0
0000786bc93d2522  vmovaps [rsp], xmm0
0000786bc93d2527  vmovaps [rsp+0x10], xmm1
0000786bc93d252d  vmovaps [rsp+0x20], xmm2
0000786bc93d2533  vmovaps [rsp+0x30], xmm3
0000786bc93d2539  vmovaps [rsp+0x40], xmm4
0000786bc93d253f  vmovaps [rsp+0x50], xmm5
0000786bc93d2545  vmovaps [rsp+0x60], xmm6
0000786bc93d254b  vmovaps [rsp+0x70], xmm7
0000786bc93d2551  vmovaps [rsp+0x80], xmm8
0000786bc93d255a  vmovaps [rsp+0x90], xmm9
0000786bc93d2563  vmovaps [rsp+0xA0], xmm10
0000786bc93d256c  vmovaps [rsp+0xB0], xmm11
0000786bc93d2575  vmovaps [rsp+0xC0], xmm12
0000786bc93d257e  vmovaps [rsp+0xD0], xmm13
0000786bc93d2587  vmovaps [rsp+0xE0], xmm14
0000786bc93d2590  sub rsp, 0x30
0000786bc93d2594  movaps [rsp], xmm15
0000786bc93d2599  movaps [rsp+0x10], xmm11
0000786bc93d259f  movaps [rsp+0x20], xmm1
0000786bc93d25a4  lea rdi, [rsp]
0000786bc93d25a8  mov esi, 0x00
0000786bc93d25ad  mov rax, 0x60810F6F7530
0000786bc93d25b7  call rax
0000786bc93d25b9  movaps xmm15, [rsp]
0000786bc93d25be  add rsp, 0x30
0000786bc93d25c2  vmovaps xmm0, [rsp]
0000786bc93d25c7  vmovaps xmm1, [rsp+0x10]
0000786bc93d25cd  vmovaps xmm2, [rsp+0x20]
0000786bc93d25d3  vmovaps xmm3, [rsp+0x30]
0000786bc93d25d9  vmovaps xmm4, [rsp+0x40]
0000786bc93d25df  vmovaps xmm5, [rsp+0x50]
0000786bc93d25e5  vmovaps xmm6, [rsp+0x60]
0000786bc93d25eb  vmovaps xmm7, [rsp+0x70]
0000786bc93d25f1  vmovaps xmm8, [rsp+0x80]
0000786bc93d25fa  vmovaps xmm9, [rsp+0x90]
0000786bc93d2603  vmovaps xmm10, [rsp+0xA0]
0000786bc93d260c  vmovaps xmm11, [rsp+0xB0]
0000786bc93d2615  vmovaps xmm12, [rsp+0xC0]
0000786bc93d261e  vmovaps xmm13, [rsp+0xD0]
0000786bc93d2627  vmovaps xmm14, [rsp+0xE0]
0000786bc93d2630  add rsp, 0xF0
0000786bc93d2637  pop r11
0000786bc93d2639  pop r10
0000786bc93d263b  pop r9
0000786bc93d263d  pop r8
0000786bc93d263f  pop rsi
0000786bc93d2640  pop rdi
0000786bc93d2641  pop rdx
0000786bc93d2642  pop rcx
0000786bc93d2643  pop rax
0000786bc93d2644  add rsp, 0x08
0000786bc93d2648  jmp 0x0000786BC93CFCBC
0000786bc93d264d  sub rsp, 0x08
0000786bc93d2651  push rax
0000786bc93d2652  push rcx
0000786bc93d2653  push rdx
0000786bc93d2654  push rdi
0000786bc93d2655  push rsi
0000786bc93d2656  push r8
0000786bc93d2658  push r9
0000786bc93d265a  push r10
0000786bc93d265c  push r11
0000786bc93d265e  sub rsp, 0xF0
0000786bc93d2665  vmovaps [rsp], xmm0
0000786bc93d266a  vmovaps [rsp+0x10], xmm1
0000786bc93d2670  vmovaps [rsp+0x20], xmm2
0000786bc93d2676  vmovaps [rsp+0x30], xmm3
0000786bc93d267c  vmovaps [rsp+0x40], xmm4
0000786bc93d2682  vmovaps [rsp+0x50], xmm5
0000786bc93d2688  vmovaps [rsp+0x60], xmm6
0000786bc93d268e  vmovaps [rsp+0x70], xmm7
0000786bc93d2694  vmovaps [rsp+0x80], xmm8
0000786bc93d269d  vmovaps [rsp+0x90], xmm9
0000786bc93d26a6  vmovaps [rsp+0xA0], xmm10
0000786bc93d26af  vmovaps [rsp+0xB0], xmm12
0000786bc93d26b8  vmovaps [rsp+0xC0], xmm13
0000786bc93d26c1  vmovaps [rsp+0xD0], xmm14
0000786bc93d26ca  vmovaps [rsp+0xE0], xmm15
0000786bc93d26d3  sub rsp, 0x30
0000786bc93d26d7  movaps [rsp], xmm11
0000786bc93d26dc  movaps [rsp+0x10], xmm6
0000786bc93d26e1  movaps [rsp+0x20], xmm14
0000786bc93d26e7  lea rdi, [rsp]
0000786bc93d26eb  mov esi, 0x00
0000786bc93d26f0  mov rax, 0x60810F6F7530
0000786bc93d26fa  call rax
0000786bc93d26fc  movaps xmm11, [rsp]
0000786bc93d2701  add rsp, 0x30
0000786bc93d2705  vmovaps xmm0, [rsp]
0000786bc93d270a  vmovaps xmm1, [rsp+0x10]
0000786bc93d2710  vmovaps xmm2, [rsp+0x20]
0000786bc93d2716  vmovaps xmm3, [rsp+0x30]
0000786bc93d271c  vmovaps xmm4, [rsp+0x40]
0000786bc93d2722  vmovaps xmm5, [rsp+0x50]
0000786bc93d2728  vmovaps xmm6, [rsp+0x60]
0000786bc93d272e  vmovaps xmm7, [rsp+0x70]
0000786bc93d2734  vmovaps xmm8, [rsp+0x80]
0000786bc93d273d  vmovaps xmm9, [rsp+0x90]
0000786bc93d2746  vmovaps xmm10, [rsp+0xA0]
0000786bc93d274f  vmovaps xmm12, [rsp+0xB0]
0000786bc93d2758  vmovaps xmm13, [rsp+0xC0]
0000786bc93d2761  vmovaps xmm14, [rsp+0xD0]
0000786bc93d276a  vmovaps xmm15, [rsp+0xE0]
0000786bc93d2773  add rsp, 0xF0
0000786bc93d277a  pop r11
0000786bc93d277c  pop r10
0000786bc93d277e  pop r9
0000786bc93d2780  pop r8
0000786bc93d2782  pop rsi
0000786bc93d2783  pop rdi
0000786bc93d2784  pop rdx
0000786bc93d2785  pop rcx
0000786bc93d2786  pop rax
0000786bc93d2787  add rsp, 0x08
0000786bc93d278b  jmp 0x0000786BC93CFD34
0000786bc93d2790  call 0x0000786BC91FF430
0000786bc93d2795  jmp 0x0000786BC93CFD3E
0000786bc93d279a  sub rsp, 0x08
0000786bc93d279e  push rax
0000786bc93d279f  push rcx
0000786bc93d27a0  push rdx
0000786bc93d27a1  push rdi
0000786bc93d27a2  push rsi
0000786bc93d27a3  push r8
0000786bc93d27a5  push r9
0000786bc93d27a7  push r10
0000786bc93d27a9  push r11
0000786bc93d27ab  sub rsp, 0xF0
0000786bc93d27b2  vmovaps [rsp], xmm0
0000786bc93d27b7  vmovaps [rsp+0x10], xmm1
0000786bc93d27bd  vmovaps [rsp+0x20], xmm2
0000786bc93d27c3  vmovaps [rsp+0x30], xmm3
0000786bc93d27c9  vmovaps [rsp+0x40], xmm4
0000786bc93d27cf  vmovaps [rsp+0x50], xmm5
0000786bc93d27d5  vmovaps [rsp+0x60], xmm6
0000786bc93d27db  vmovaps [rsp+0x70], xmm7
0000786bc93d27e1  vmovaps [rsp+0x80], xmm8
0000786bc93d27ea  vmovaps [rsp+0x90], xmm9
0000786bc93d27f3  vmovaps [rsp+0xA0], xmm10
0000786bc93d27fc  vmovaps [rsp+0xB0], xmm11
0000786bc93d2805  vmovaps [rsp+0xC0], xmm12
0000786bc93d280e  vmovaps [rsp+0xD0], xmm13
0000786bc93d2817  vmovaps [rsp+0xE0], xmm15
0000786bc93d2820  sub rsp, 0x30
0000786bc93d2824  movaps [rsp], xmm14
0000786bc93d2829  movaps [rsp+0x10], xmm6
0000786bc93d282e  movaps [rsp+0x20], xmm2
0000786bc93d2833  lea rdi, [rsp]
0000786bc93d2837  mov esi, 0x00
0000786bc93d283c  mov rax, 0x60810F6F7530
0000786bc93d2846  call rax
0000786bc93d2848  movaps xmm14, [rsp]
0000786bc93d284d  add rsp, 0x30
0000786bc93d2851  vmovaps xmm0, [rsp]
0000786bc93d2856  vmovaps xmm1, [rsp+0x10]
0000786bc93d285c  vmovaps xmm2, [rsp+0x20]
0000786bc93d2862  vmovaps xmm3, [rsp+0x30]
0000786bc93d2868  vmovaps xmm4, [rsp+0x40]
0000786bc93d286e  vmovaps xmm5, [rsp+0x50]
0000786bc93d2874  vmovaps xmm6, [rsp+0x60]
0000786bc93d287a  vmovaps xmm7, [rsp+0x70]
0000786bc93d2880  vmovaps xmm8, [rsp+0x80]
0000786bc93d2889  vmovaps xmm9, [rsp+0x90]
0000786bc93d2892  vmovaps xmm10, [rsp+0xA0]
0000786bc93d289b  vmovaps xmm11, [rsp+0xB0]
0000786bc93d28a4  vmovaps xmm12, [rsp+0xC0]
0000786bc93d28ad  vmovaps xmm13, [rsp+0xD0]
0000786bc93d28b6  vmovaps xmm15, [rsp+0xE0]
0000786bc93d28bf  add rsp, 0xF0
0000786bc93d28c6  pop r11
0000786bc93d28c8  pop r10
0000786bc93d28ca  pop r9
0000786bc93d28cc  pop r8
0000786bc93d28ce  pop rsi
0000786bc93d28cf  pop rdi
0000786bc93d28d0  pop rdx
0000786bc93d28d1  pop rcx
0000786bc93d28d2  pop rax
0000786bc93d28d3  add rsp, 0x08
0000786bc93d28d7  jmp 0x0000786BC93CFD72
0000786bc93d28dc  sub rsp, 0x08
0000786bc93d28e0  push rax
0000786bc93d28e1  push rcx
0000786bc93d28e2  push rdx
0000786bc93d28e3  push rdi
0000786bc93d28e4  push rsi
0000786bc93d28e5  push r8
0000786bc93d28e7  push r9
0000786bc93d28e9  push r10
0000786bc93d28eb  push r11
0000786bc93d28ed  sub rsp, 0xF0
0000786bc93d28f4  vmovaps [rsp], xmm0
0000786bc93d28f9  vmovaps [rsp+0x10], xmm1
0000786bc93d28ff  vmovaps [rsp+0x20], xmm2
0000786bc93d2905  vmovaps [rsp+0x30], xmm3
0000786bc93d290b  vmovaps [rsp+0x40], xmm4
0000786bc93d2911  vmovaps [rsp+0x50], xmm5
0000786bc93d2917  vmovaps [rsp+0x60], xmm7
0000786bc93d291d  vmovaps [rsp+0x70], xmm8
0000786bc93d2923  vmovaps [rsp+0x80], xmm9
0000786bc93d292c  vmovaps [rsp+0x90], xmm10
0000786bc93d2935  vmovaps [rsp+0xA0], xmm11
0000786bc93d293e  vmovaps [rsp+0xB0], xmm12
0000786bc93d2947  vmovaps [rsp+0xC0], xmm13
0000786bc93d2950  vmovaps [rsp+0xD0], xmm14
0000786bc93d2959  vmovaps [rsp+0xE0], xmm15
0000786bc93d2962  sub rsp, 0x30
0000786bc93d2966  movaps [rsp], xmm6
0000786bc93d296a  movaps [rsp+0x10], xmm5
0000786bc93d296f  movaps [rsp+0x20], xmm1
0000786bc93d2974  lea rdi, [rsp]
0000786bc93d2978  mov esi, 0x00
0000786bc93d297d  mov rax, 0x60810F6F7530
0000786bc93d2987  call rax
0000786bc93d2989  movaps xmm6, [rsp]
0000786bc93d298d  add rsp, 0x30
0000786bc93d2991  vmovaps xmm0, [rsp]
0000786bc93d2996  vmovaps xmm1, [rsp+0x10]
0000786bc93d299c  vmovaps xmm2, [rsp+0x20]
0000786bc93d29a2  vmovaps xmm3, [rsp+0x30]
0000786bc93d29a8  vmovaps xmm4, [rsp+0x40]
0000786bc93d29ae  vmovaps xmm5, [rsp+0x50]
0000786bc93d29b4  vmovaps xmm7, [rsp+0x60]
0000786bc93d29ba  vmovaps xmm8, [rsp+0x70]
0000786bc93d29c0  vmovaps xmm9, [rsp+0x80]
0000786bc93d29c9  vmovaps xmm10, [rsp+0x90]
0000786bc93d29d2  vmovaps xmm11, [rsp+0xA0]
0000786bc93d29db  vmovaps xmm12, [rsp+0xB0]
0000786bc93d29e4  vmovaps xmm13, [rsp+0xC0]
0000786bc93d29ed  vmovaps xmm14, [rsp+0xD0]
0000786bc93d29f6  vmovaps xmm15, [rsp+0xE0]
0000786bc93d29ff  add rsp, 0xF0
0000786bc93d2a06  pop r11
0000786bc93d2a08  pop r10
0000786bc93d2a0a  pop r9
0000786bc93d2a0c  pop r8
0000786bc93d2a0e  pop rsi
0000786bc93d2a0f  pop rdi
0000786bc93d2a10  pop rdx
0000786bc93d2a11  pop rcx
0000786bc93d2a12  pop rax
0000786bc93d2a13  add rsp, 0x08
0000786bc93d2a17  jmp 0x0000786BC93CFD98
0000786bc93d2a1c  sub rsp, 0x08
0000786bc93d2a20  push rax
0000786bc93d2a21  push rcx
0000786bc93d2a22  push rdx
0000786bc93d2a23  push rdi
0000786bc93d2a24  push rsi
0000786bc93d2a25  push r8
0000786bc93d2a27  push r9
0000786bc93d2a29  push r10
0000786bc93d2a2b  push r11
0000786bc93d2a2d  sub rsp, 0xF0
0000786bc93d2a34  vmovaps [rsp], xmm0
0000786bc93d2a39  vmovaps [rsp+0x10], xmm2
0000786bc93d2a3f  vmovaps [rsp+0x20], xmm3
0000786bc93d2a45  vmovaps [rsp+0x30], xmm4
0000786bc93d2a4b  vmovaps [rsp+0x40], xmm5
0000786bc93d2a51  vmovaps [rsp+0x50], xmm6
0000786bc93d2a57  vmovaps [rsp+0x60], xmm7
0000786bc93d2a5d  vmovaps [rsp+0x70], xmm8
0000786bc93d2a63  vmovaps [rsp+0x80], xmm9
0000786bc93d2a6c  vmovaps [rsp+0x90], xmm10
0000786bc93d2a75  vmovaps [rsp+0xA0], xmm11
0000786bc93d2a7e  vmovaps [rsp+0xB0], xmm12
0000786bc93d2a87  vmovaps [rsp+0xC0], xmm13
0000786bc93d2a90  vmovaps [rsp+0xD0], xmm14
0000786bc93d2a99  vmovaps [rsp+0xE0], xmm15
0000786bc93d2aa2  sub rsp, 0x30
0000786bc93d2aa6  movaps [rsp], xmm1
0000786bc93d2aaa  movaps [rsp+0x10], xmm5
0000786bc93d2aaf  movaps [rsp+0x20], xmm13
0000786bc93d2ab5  lea rdi, [rsp]
0000786bc93d2ab9  mov esi, 0x00
0000786bc93d2abe  mov rax, 0x60810F6F7530
0000786bc93d2ac8  call rax
0000786bc93d2aca  movaps xmm1, [rsp]
0000786bc93d2ace  add rsp, 0x30
0000786bc93d2ad2  vmovaps xmm0, [rsp]
0000786bc93d2ad7  vmovaps xmm2, [rsp+0x10]
0000786bc93d2add  vmovaps xmm3, [rsp+0x20]
0000786bc93d2ae3  vmovaps xmm4, [rsp+0x30]
0000786bc93d2ae9  vmovaps xmm5, [rsp+0x40]
0000786bc93d2aef  vmovaps xmm6, [rsp+0x50]
0000786bc93d2af5  vmovaps xmm7, [rsp+0x60]
0000786bc93d2afb  vmovaps xmm8, [rsp+0x70]
0000786bc93d2b01  vmovaps xmm9, [rsp+0x80]
0000786bc93d2b0a  vmovaps xmm10, [rsp+0x90]
0000786bc93d2b13  vmovaps xmm11, [rsp+0xA0]
0000786bc93d2b1c  vmovaps xmm12, [rsp+0xB0]
0000786bc93d2b25  vmovaps xmm13, [rsp+0xC0]
0000786bc93d2b2e  vmovaps xmm14, [rsp+0xD0]
0000786bc93d2b37  vmovaps xmm15, [rsp+0xE0]
0000786bc93d2b40  add rsp, 0xF0
0000786bc93d2b47  pop r11
0000786bc93d2b49  pop r10
0000786bc93d2b4b  pop r9
0000786bc93d2b4d  pop r8
0000786bc93d2b4f  pop rsi
0000786bc93d2b50  pop rdi
0000786bc93d2b51  pop rdx
0000786bc93d2b52  pop rcx
0000786bc93d2b53  pop rax
0000786bc93d2b54  add rsp, 0x08
0000786bc93d2b58  jmp 0x0000786BC93CFDB6
0000786bc93d2b5d  sub rsp, 0x08
0000786bc93d2b61  push rax
0000786bc93d2b62  push rcx
0000786bc93d2b63  push rdx
0000786bc93d2b64  push rdi
0000786bc93d2b65  push rsi
0000786bc93d2b66  push r8
0000786bc93d2b68  push r9
0000786bc93d2b6a  push r10
0000786bc93d2b6c  push r11
0000786bc93d2b6e  sub rsp, 0xF0
0000786bc93d2b75  vmovaps [rsp], xmm0
0000786bc93d2b7a  vmovaps [rsp+0x10], xmm1
0000786bc93d2b80  vmovaps [rsp+0x20], xmm2
0000786bc93d2b86  vmovaps [rsp+0x30], xmm3
0000786bc93d2b8c  vmovaps [rsp+0x40], xmm4
0000786bc93d2b92  vmovaps [rsp+0x50], xmm6
0000786bc93d2b98  vmovaps [rsp+0x60], xmm7
0000786bc93d2b9e  vmovaps [rsp+0x70], xmm8
0000786bc93d2ba4  vmovaps [rsp+0x80], xmm9
0000786bc93d2bad  vmovaps [rsp+0x90], xmm10
0000786bc93d2bb6  vmovaps [rsp+0xA0], xmm11
0000786bc93d2bbf  vmovaps [rsp+0xB0], xmm12
0000786bc93d2bc8  vmovaps [rsp+0xC0], xmm13
0000786bc93d2bd1  vmovaps [rsp+0xD0], xmm14
0000786bc93d2bda  vmovaps [rsp+0xE0], xmm15
0000786bc93d2be3  sub rsp, 0x30
0000786bc93d2be7  movaps [rsp], xmm5
0000786bc93d2beb  movaps [rsp+0x10], xmm2
0000786bc93d2bf0  movaps [rsp+0x20], xmm13
0000786bc93d2bf6  lea rdi, [rsp]
0000786bc93d2bfa  mov esi, 0x00
0000786bc93d2bff  mov rax, 0x60810F6F7530
0000786bc93d2c09  call rax
0000786bc93d2c0b  movaps xmm5, [rsp]
0000786bc93d2c0f  add rsp, 0x30
0000786bc93d2c13  vmovaps xmm0, [rsp]
0000786bc93d2c18  vmovaps xmm1, [rsp+0x10]
0000786bc93d2c1e  vmovaps xmm2, [rsp+0x20]
0000786bc93d2c24  vmovaps xmm3, [rsp+0x30]
0000786bc93d2c2a  vmovaps xmm4, [rsp+0x40]
0000786bc93d2c30  vmovaps xmm6, [rsp+0x50]
0000786bc93d2c36  vmovaps xmm7, [rsp+0x60]
0000786bc93d2c3c  vmovaps xmm8, [rsp+0x70]
0000786bc93d2c42  vmovaps xmm9, [rsp+0x80]
0000786bc93d2c4b  vmovaps xmm10, [rsp+0x90]
0000786bc93d2c54  vmovaps xmm11, [rsp+0xA0]
0000786bc93d2c5d  vmovaps xmm12, [rsp+0xB0]
0000786bc93d2c66  vmovaps xmm13, [rsp+0xC0]
0000786bc93d2c6f  vmovaps xmm14, [rsp+0xD0]
0000786bc93d2c78  vmovaps xmm15, [rsp+0xE0]
0000786bc93d2c81  add rsp, 0xF0
0000786bc93d2c88  pop r11
0000786bc93d2c8a  pop r10
0000786bc93d2c8c  pop r9
0000786bc93d2c8e  pop r8
0000786bc93d2c90  pop rsi
0000786bc93d2c91  pop rdi
0000786bc93d2c92  pop rdx
0000786bc93d2c93  pop rcx
0000786bc93d2c94  pop rax
0000786bc93d2c95  add rsp, 0x08
0000786bc93d2c99  jmp 0x0000786BC93CFDEC
0000786bc93d2c9e  sub rsp, 0x08
0000786bc93d2ca2  push rax
0000786bc93d2ca3  push rcx
0000786bc93d2ca4  push rdx
0000786bc93d2ca5  push rdi
0000786bc93d2ca6  push rsi
0000786bc93d2ca7  push r8
0000786bc93d2ca9  push r9
0000786bc93d2cab  push r10
0000786bc93d2cad  push r11
0000786bc93d2caf  sub rsp, 0xF0
0000786bc93d2cb6  vmovaps [rsp], xmm0
0000786bc93d2cbb  vmovaps [rsp+0x10], xmm1
0000786bc93d2cc1  vmovaps [rsp+0x20], xmm2
0000786bc93d2cc7  vmovaps [rsp+0x30], xmm3
0000786bc93d2ccd  vmovaps [rsp+0x40], xmm4
0000786bc93d2cd3  vmovaps [rsp+0x50], xmm5
0000786bc93d2cd9  vmovaps [rsp+0x60], xmm6
0000786bc93d2cdf  vmovaps [rsp+0x70], xmm7
0000786bc93d2ce5  vmovaps [rsp+0x80], xmm8
0000786bc93d2cee  vmovaps [rsp+0x90], xmm9
0000786bc93d2cf7  vmovaps [rsp+0xA0], xmm10
0000786bc93d2d00  vmovaps [rsp+0xB0], xmm11
0000786bc93d2d09  vmovaps [rsp+0xC0], xmm12
0000786bc93d2d12  vmovaps [rsp+0xD0], xmm14
0000786bc93d2d1b  vmovaps [rsp+0xE0], xmm15
0000786bc93d2d24  sub rsp, 0x30
0000786bc93d2d28  movaps [rsp], xmm13
0000786bc93d2d2d  movaps [rsp+0x10], xmm10
0000786bc93d2d33  movaps [rsp+0x20], xmm1
0000786bc93d2d38  lea rdi, [rsp]
0000786bc93d2d3c  mov esi, 0x00
0000786bc93d2d41  mov rax, 0x60810F6F7530
0000786bc93d2d4b  call rax
0000786bc93d2d4d  movaps xmm13, [rsp]
0000786bc93d2d52  add rsp, 0x30
0000786bc93d2d56  vmovaps xmm0, [rsp]
0000786bc93d2d5b  vmovaps xmm1, [rsp+0x10]
0000786bc93d2d61  vmovaps xmm2, [rsp+0x20]
0000786bc93d2d67  vmovaps xmm3, [rsp+0x30]
0000786bc93d2d6d  vmovaps xmm4, [rsp+0x40]
0000786bc93d2d73  vmovaps xmm5, [rsp+0x50]
0000786bc93d2d79  vmovaps xmm6, [rsp+0x60]
0000786bc93d2d7f  vmovaps xmm7, [rsp+0x70]
0000786bc93d2d85  vmovaps xmm8, [rsp+0x80]
0000786bc93d2d8e  vmovaps xmm9, [rsp+0x90]
0000786bc93d2d97  vmovaps xmm10, [rsp+0xA0]
0000786bc93d2da0  vmovaps xmm11, [rsp+0xB0]
0000786bc93d2da9  vmovaps xmm12, [rsp+0xC0]
0000786bc93d2db2  vmovaps xmm14, [rsp+0xD0]
0000786bc93d2dbb  vmovaps xmm15, [rsp+0xE0]
0000786bc93d2dc4  add rsp, 0xF0
0000786bc93d2dcb  pop r11
0000786bc93d2dcd  pop r10
0000786bc93d2dcf  pop r9
0000786bc93d2dd1  pop r8
0000786bc93d2dd3  pop rsi
0000786bc93d2dd4  pop rdi
0000786bc93d2dd5  pop rdx
0000786bc93d2dd6  pop rcx
0000786bc93d2dd7  pop rax
0000786bc93d2dd8  add rsp, 0x08
0000786bc93d2ddc  jmp 0x0000786BC93CFE15
0000786bc93d2de1  sub rsp, 0x08
0000786bc93d2de5  push rax
0000786bc93d2de6  push rcx
0000786bc93d2de7  push rdx
0000786bc93d2de8  push rdi
0000786bc93d2de9  push rsi
0000786bc93d2dea  push r8
0000786bc93d2dec  push r9
0000786bc93d2dee  push r10
0000786bc93d2df0  push r11
0000786bc93d2df2  sub rsp, 0xF0
0000786bc93d2df9  vmovaps [rsp], xmm0
0000786bc93d2dfe  vmovaps [rsp+0x10], xmm2
0000786bc93d2e04  vmovaps [rsp+0x20], xmm3
0000786bc93d2e0a  vmovaps [rsp+0x30], xmm4
0000786bc93d2e10  vmovaps [rsp+0x40], xmm5
0000786bc93d2e16  vmovaps [rsp+0x50], xmm6
0000786bc93d2e1c  vmovaps [rsp+0x60], xmm7
0000786bc93d2e22  vmovaps [rsp+0x70], xmm8
0000786bc93d2e28  vmovaps [rsp+0x80], xmm9
0000786bc93d2e31  vmovaps [rsp+0x90], xmm10
0000786bc93d2e3a  vmovaps [rsp+0xA0], xmm11
0000786bc93d2e43  vmovaps [rsp+0xB0], xmm12
0000786bc93d2e4c  vmovaps [rsp+0xC0], xmm13
0000786bc93d2e55  vmovaps [rsp+0xD0], xmm14
0000786bc93d2e5e  vmovaps [rsp+0xE0], xmm15
0000786bc93d2e67  sub rsp, 0x30
0000786bc93d2e6b  movaps [rsp], xmm1
0000786bc93d2e6f  movaps [rsp+0x10], xmm15
0000786bc93d2e75  movaps [rsp+0x20], xmm10
0000786bc93d2e7b  lea rdi, [rsp]
0000786bc93d2e7f  mov esi, 0x00
0000786bc93d2e84  mov rax, 0x60810F6F7530
0000786bc93d2e8e  call rax
0000786bc93d2e90  movaps xmm1, [rsp]
0000786bc93d2e94  add rsp, 0x30
0000786bc93d2e98  vmovaps xmm0, [rsp]
0000786bc93d2e9d  vmovaps xmm2, [rsp+0x10]
0000786bc93d2ea3  vmovaps xmm3, [rsp+0x20]
0000786bc93d2ea9  vmovaps xmm4, [rsp+0x30]
0000786bc93d2eaf  vmovaps xmm5, [rsp+0x40]
0000786bc93d2eb5  vmovaps xmm6, [rsp+0x50]
0000786bc93d2ebb  vmovaps xmm7, [rsp+0x60]
0000786bc93d2ec1  vmovaps xmm8, [rsp+0x70]
0000786bc93d2ec7  vmovaps xmm9, [rsp+0x80]
0000786bc93d2ed0  vmovaps xmm10, [rsp+0x90]
0000786bc93d2ed9  vmovaps xmm11, [rsp+0xA0]
0000786bc93d2ee2  vmovaps xmm12, [rsp+0xB0]
0000786bc93d2eeb  vmovaps xmm13, [rsp+0xC0]
0000786bc93d2ef4  vmovaps xmm14, [rsp+0xD0]
0000786bc93d2efd  vmovaps xmm15, [rsp+0xE0]
0000786bc93d2f06  add rsp, 0xF0
0000786bc93d2f0d  pop r11
0000786bc93d2f0f  pop r10
0000786bc93d2f11  pop r9
0000786bc93d2f13  pop r8
0000786bc93d2f15  pop rsi
0000786bc93d2f16  pop rdi
0000786bc93d2f17  pop rdx
0000786bc93d2f18  pop rcx
0000786bc93d2f19  pop rax
0000786bc93d2f1a  add rsp, 0x08
0000786bc93d2f1e  jmp 0x0000786BC93CFE34
0000786bc93d2f23  sub rsp, 0x08
0000786bc93d2f27  push rax
0000786bc93d2f28  push rcx
0000786bc93d2f29  push rdx
0000786bc93d2f2a  push rdi
0000786bc93d2f2b  push rsi
0000786bc93d2f2c  push r8
0000786bc93d2f2e  push r9
0000786bc93d2f30  push r10
0000786bc93d2f32  push r11
0000786bc93d2f34  sub rsp, 0xF0
0000786bc93d2f3b  vmovaps [rsp], xmm0
0000786bc93d2f40  vmovaps [rsp+0x10], xmm1
0000786bc93d2f46  vmovaps [rsp+0x20], xmm2
0000786bc93d2f4c  vmovaps [rsp+0x30], xmm3
0000786bc93d2f52  vmovaps [rsp+0x40], xmm4
0000786bc93d2f58  vmovaps [rsp+0x50], xmm5
0000786bc93d2f5e  vmovaps [rsp+0x60], xmm6
0000786bc93d2f64  vmovaps [rsp+0x70], xmm7
0000786bc93d2f6a  vmovaps [rsp+0x80], xmm8
0000786bc93d2f73  vmovaps [rsp+0x90], xmm9
0000786bc93d2f7c  vmovaps [rsp+0xA0], xmm10
0000786bc93d2f85  vmovaps [rsp+0xB0], xmm11
0000786bc93d2f8e  vmovaps [rsp+0xC0], xmm12
0000786bc93d2f97  vmovaps [rsp+0xD0], xmm13
0000786bc93d2fa0  vmovaps [rsp+0xE0], xmm14
0000786bc93d2fa9  sub rsp, 0x30
0000786bc93d2fad  movaps [rsp], xmm15
0000786bc93d2fb2  movaps [rsp+0x10], xmm10
0000786bc93d2fb8  movaps [rsp+0x20], xmm11
0000786bc93d2fbe  lea rdi, [rsp]
0000786bc93d2fc2  mov esi, 0x00
0000786bc93d2fc7  mov rax, 0x60810F6F7530
0000786bc93d2fd1  call rax
0000786bc93d2fd3  movaps xmm15, [rsp]
0000786bc93d2fd8  add rsp, 0x30
0000786bc93d2fdc  vmovaps xmm0, [rsp]
0000786bc93d2fe1  vmovaps xmm1, [rsp+0x10]
0000786bc93d2fe7  vmovaps xmm2, [rsp+0x20]
0000786bc93d2fed  vmovaps xmm3, [rsp+0x30]
0000786bc93d2ff3  vmovaps xmm4, [rsp+0x40]
0000786bc93d2ff9  vmovaps xmm5, [rsp+0x50]
0000786bc93d2fff  vmovaps xmm6, [rsp+0x60]
0000786bc93d3005  vmovaps xmm7, [rsp+0x70]
0000786bc93d300b  vmovaps xmm8, [rsp+0x80]
0000786bc93d3014  vmovaps xmm9, [rsp+0x90]
0000786bc93d301d  vmovaps xmm10, [rsp+0xA0]
0000786bc93d3026  vmovaps xmm11, [rsp+0xB0]
0000786bc93d302f  vmovaps xmm12, [rsp+0xC0]
0000786bc93d3038  vmovaps xmm13, [rsp+0xD0]
0000786bc93d3041  vmovaps xmm14, [rsp+0xE0]
0000786bc93d304a  add rsp, 0xF0
0000786bc93d3051  pop r11
0000786bc93d3053  pop r10
0000786bc93d3055  pop r9
0000786bc93d3057  pop r8
0000786bc93d3059  pop rsi
0000786bc93d305a  pop rdi
0000786bc93d305b  pop rdx
0000786bc93d305c  pop rcx
0000786bc93d305d  pop rax
0000786bc93d305e  add rsp, 0x08
0000786bc93d3062  jmp 0x0000786BC93CFE57
0000786bc93d3067  sub rsp, 0x08
0000786bc93d306b  push rax
0000786bc93d306c  push rcx
0000786bc93d306d  push rdx
0000786bc93d306e  push rdi
0000786bc93d306f  push rsi
0000786bc93d3070  push r8
0000786bc93d3072  push r9
0000786bc93d3074  push r10
0000786bc93d3076  push r11
0000786bc93d3078  sub rsp, 0xF0
0000786bc93d307f  vmovaps [rsp], xmm0
0000786bc93d3084  vmovaps [rsp+0x10], xmm1
0000786bc93d308a  vmovaps [rsp+0x20], xmm2
0000786bc93d3090  vmovaps [rsp+0x30], xmm3
0000786bc93d3096  vmovaps [rsp+0x40], xmm4
0000786bc93d309c  vmovaps [rsp+0x50], xmm5
0000786bc93d30a2  vmovaps [rsp+0x60], xmm6
0000786bc93d30a8  vmovaps [rsp+0x70], xmm7
0000786bc93d30ae  vmovaps [rsp+0x80], xmm8
0000786bc93d30b7  vmovaps [rsp+0x90], xmm9
0000786bc93d30c0  vmovaps [rsp+0xA0], xmm11
0000786bc93d30c9  vmovaps [rsp+0xB0], xmm12
0000786bc93d30d2  vmovaps [rsp+0xC0], xmm13
0000786bc93d30db  vmovaps [rsp+0xD0], xmm14
0000786bc93d30e4  vmovaps [rsp+0xE0], xmm15
0000786bc93d30ed  sub rsp, 0x30
0000786bc93d30f1  movaps [rsp], xmm10
0000786bc93d30f6  movaps [rsp+0x10], xmm12
0000786bc93d30fc  movaps [rsp+0x20], xmm11
0000786bc93d3102  lea rdi, [rsp]
0000786bc93d3106  mov esi, 0x00
0000786bc93d310b  mov rax, 0x60810F6F7530
0000786bc93d3115  call rax
0000786bc93d3117  movaps xmm10, [rsp]
0000786bc93d311c  add rsp, 0x30
0000786bc93d3120  vmovaps xmm0, [rsp]
0000786bc93d3125  vmovaps xmm1, [rsp+0x10]
0000786bc93d312b  vmovaps xmm2, [rsp+0x20]
0000786bc93d3131  vmovaps xmm3, [rsp+0x30]
0000786bc93d3137  vmovaps xmm4, [rsp+0x40]
0000786bc93d313d  vmovaps xmm5, [rsp+0x50]
0000786bc93d3143  vmovaps xmm6, [rsp+0x60]
0000786bc93d3149  vmovaps xmm7, [rsp+0x70]
0000786bc93d314f  vmovaps xmm8, [rsp+0x80]
0000786bc93d3158  vmovaps xmm9, [rsp+0x90]
0000786bc93d3161  vmovaps xmm11, [rsp+0xA0]
0000786bc93d316a  vmovaps xmm12, [rsp+0xB0]
0000786bc93d3173  vmovaps xmm13, [rsp+0xC0]
0000786bc93d317c  vmovaps xmm14, [rsp+0xD0]
0000786bc93d3185  vmovaps xmm15, [rsp+0xE0]
0000786bc93d318e  add rsp, 0xF0
0000786bc93d3195  pop r11
0000786bc93d3197  pop r10
0000786bc93d3199  pop r9
0000786bc93d319b  pop r8
0000786bc93d319d  pop rsi
0000786bc93d319e  pop rdi
0000786bc93d319f  pop rdx
0000786bc93d31a0  pop rcx
0000786bc93d31a1  pop rax
0000786bc93d31a2  add rsp, 0x08
0000786bc93d31a6  jmp 0x0000786BC93CFE80
0000786bc93d31ab  sub rsp, 0x08
0000786bc93d31af  push rax
0000786bc93d31b0  push rcx
0000786bc93d31b1  push rdx
0000786bc93d31b2  push rdi
0000786bc93d31b3  push rsi
0000786bc93d31b4  push r8
0000786bc93d31b6  push r9
0000786bc93d31b8  push r10
0000786bc93d31ba  push r11
0000786bc93d31bc  sub rsp, 0xF0
0000786bc93d31c3  vmovaps [rsp], xmm0
0000786bc93d31c8  vmovaps [rsp+0x10], xmm1
0000786bc93d31ce  vmovaps [rsp+0x20], xmm2
0000786bc93d31d4  vmovaps [rsp+0x30], xmm3
0000786bc93d31da  vmovaps [rsp+0x40], xmm4
0000786bc93d31e0  vmovaps [rsp+0x50], xmm5
0000786bc93d31e6  vmovaps [rsp+0x60], xmm6
0000786bc93d31ec  vmovaps [rsp+0x70], xmm7
0000786bc93d31f2  vmovaps [rsp+0x80], xmm8
0000786bc93d31fb  vmovaps [rsp+0x90], xmm9
0000786bc93d3204  vmovaps [rsp+0xA0], xmm10
0000786bc93d320d  vmovaps [rsp+0xB0], xmm12
0000786bc93d3216  vmovaps [rsp+0xC0], xmm13
0000786bc93d321f  vmovaps [rsp+0xD0], xmm14
0000786bc93d3228  vmovaps [rsp+0xE0], xmm15
0000786bc93d3231  sub rsp, 0x30
0000786bc93d3235  movaps [rsp], xmm11
0000786bc93d323a  movaps [rsp+0x10], xmm2
0000786bc93d323f  movaps [rsp+0x20], xmm12
0000786bc93d3245  lea rdi, [rsp]
0000786bc93d3249  mov esi, 0x00
0000786bc93d324e  mov rax, 0x60810F6F7530
0000786bc93d3258  call rax
0000786bc93d325a  movaps xmm11, [rsp]
0000786bc93d325f  add rsp, 0x30
0000786bc93d3263  vmovaps xmm0, [rsp]
0000786bc93d3268  vmovaps xmm1, [rsp+0x10]
0000786bc93d326e  vmovaps xmm2, [rsp+0x20]
0000786bc93d3274  vmovaps xmm3, [rsp+0x30]
0000786bc93d327a  vmovaps xmm4, [rsp+0x40]
0000786bc93d3280  vmovaps xmm5, [rsp+0x50]
0000786bc93d3286  vmovaps xmm6, [rsp+0x60]
0000786bc93d328c  vmovaps xmm7, [rsp+0x70]
0000786bc93d3292  vmovaps xmm8, [rsp+0x80]
0000786bc93d329b  vmovaps xmm9, [rsp+0x90]
0000786bc93d32a4  vmovaps xmm10, [rsp+0xA0]
0000786bc93d32ad  vmovaps xmm12, [rsp+0xB0]
0000786bc93d32b6  vmovaps xmm13, [rsp+0xC0]
0000786bc93d32bf  vmovaps xmm14, [rsp+0xD0]
0000786bc93d32c8  vmovaps xmm15, [rsp+0xE0]
0000786bc93d32d1  add rsp, 0xF0
0000786bc93d32d8  pop r11
0000786bc93d32da  pop r10
0000786bc93d32dc  pop r9
0000786bc93d32de  pop r8
0000786bc93d32e0  pop rsi
0000786bc93d32e1  pop rdi
0000786bc93d32e2  pop rdx
0000786bc93d32e3  pop rcx
0000786bc93d32e4  pop rax
0000786bc93d32e5  add rsp, 0x08
0000786bc93d32e9  jmp 0x0000786BC93CFEB8
0000786bc93d32ee  sub rsp, 0x08
0000786bc93d32f2  push rax
0000786bc93d32f3  push rcx
0000786bc93d32f4  push rdx
0000786bc93d32f5  push rdi
0000786bc93d32f6  push rsi
0000786bc93d32f7  push r8
0000786bc93d32f9  push r9
0000786bc93d32fb  push r10
0000786bc93d32fd  push r11
0000786bc93d32ff  sub rsp, 0xF0
0000786bc93d3306  vmovaps [rsp], xmm0
0000786bc93d330b  vmovaps [rsp+0x10], xmm2
0000786bc93d3311  vmovaps [rsp+0x20], xmm3
0000786bc93d3317  vmovaps [rsp+0x30], xmm4
0000786bc93d331d  vmovaps [rsp+0x40], xmm5
0000786bc93d3323  vmovaps [rsp+0x50], xmm6
0000786bc93d3329  vmovaps [rsp+0x60], xmm7
0000786bc93d332f  vmovaps [rsp+0x70], xmm8
0000786bc93d3335  vmovaps [rsp+0x80], xmm9
0000786bc93d333e  vmovaps [rsp+0x90], xmm10
0000786bc93d3347  vmovaps [rsp+0xA0], xmm11
0000786bc93d3350  vmovaps [rsp+0xB0], xmm12
0000786bc93d3359  vmovaps [rsp+0xC0], xmm13
0000786bc93d3362  vmovaps [rsp+0xD0], xmm14
0000786bc93d336b  vmovaps [rsp+0xE0], xmm15
0000786bc93d3374  sub rsp, 0x30
0000786bc93d3378  movaps [rsp], xmm1
0000786bc93d337c  movaps [rsp+0x10], xmm14
0000786bc93d3382  movaps [rsp+0x20], xmm6
0000786bc93d3387  lea rdi, [rsp]
0000786bc93d338b  mov esi, 0x00
0000786bc93d3390  mov rax, 0x60810F6F7530
0000786bc93d339a  call rax
0000786bc93d339c  movaps xmm1, [rsp]
0000786bc93d33a0  add rsp, 0x30
0000786bc93d33a4  vmovaps xmm0, [rsp]
0000786bc93d33a9  vmovaps xmm2, [rsp+0x10]
0000786bc93d33af  vmovaps xmm3, [rsp+0x20]
0000786bc93d33b5  vmovaps xmm4, [rsp+0x30]
0000786bc93d33bb  vmovaps xmm5, [rsp+0x40]
0000786bc93d33c1  vmovaps xmm6, [rsp+0x50]
0000786bc93d33c7  vmovaps xmm7, [rsp+0x60]
0000786bc93d33cd  vmovaps xmm8, [rsp+0x70]
0000786bc93d33d3  vmovaps xmm9, [rsp+0x80]
0000786bc93d33dc  vmovaps xmm10, [rsp+0x90]
0000786bc93d33e5  vmovaps xmm11, [rsp+0xA0]
0000786bc93d33ee  vmovaps xmm12, [rsp+0xB0]
0000786bc93d33f7  vmovaps xmm13, [rsp+0xC0]
0000786bc93d3400  vmovaps xmm14, [rsp+0xD0]
0000786bc93d3409  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3412  add rsp, 0xF0
0000786bc93d3419  pop r11
0000786bc93d341b  pop r10
0000786bc93d341d  pop r9
0000786bc93d341f  pop r8
0000786bc93d3421  pop rsi
0000786bc93d3422  pop rdi
0000786bc93d3423  pop rdx
0000786bc93d3424  pop rcx
0000786bc93d3425  pop rax
0000786bc93d3426  add rsp, 0x08
0000786bc93d342a  jmp 0x0000786BC93CFED1
0000786bc93d342f  sub rsp, 0x08
0000786bc93d3433  push rax
0000786bc93d3434  push rcx
0000786bc93d3435  push rdx
0000786bc93d3436  push rdi
0000786bc93d3437  push rsi
0000786bc93d3438  push r8
0000786bc93d343a  push r9
0000786bc93d343c  push r10
0000786bc93d343e  push r11
0000786bc93d3440  sub rsp, 0xF0
0000786bc93d3447  vmovaps [rsp], xmm0
0000786bc93d344c  vmovaps [rsp+0x10], xmm1
0000786bc93d3452  vmovaps [rsp+0x20], xmm2
0000786bc93d3458  vmovaps [rsp+0x30], xmm3
0000786bc93d345e  vmovaps [rsp+0x40], xmm4
0000786bc93d3464  vmovaps [rsp+0x50], xmm5
0000786bc93d346a  vmovaps [rsp+0x60], xmm6
0000786bc93d3470  vmovaps [rsp+0x70], xmm7
0000786bc93d3476  vmovaps [rsp+0x80], xmm8
0000786bc93d347f  vmovaps [rsp+0x90], xmm9
0000786bc93d3488  vmovaps [rsp+0xA0], xmm10
0000786bc93d3491  vmovaps [rsp+0xB0], xmm11
0000786bc93d349a  vmovaps [rsp+0xC0], xmm12
0000786bc93d34a3  vmovaps [rsp+0xD0], xmm13
0000786bc93d34ac  vmovaps [rsp+0xE0], xmm15
0000786bc93d34b5  sub rsp, 0x30
0000786bc93d34b9  movaps [rsp], xmm14
0000786bc93d34be  movaps [rsp+0x10], xmm12
0000786bc93d34c4  movaps [rsp+0x20], xmm5
0000786bc93d34c9  lea rdi, [rsp]
0000786bc93d34cd  mov esi, 0x00
0000786bc93d34d2  mov rax, 0x60810F6F7530
0000786bc93d34dc  call rax
0000786bc93d34de  movaps xmm14, [rsp]
0000786bc93d34e3  add rsp, 0x30
0000786bc93d34e7  vmovaps xmm0, [rsp]
0000786bc93d34ec  vmovaps xmm1, [rsp+0x10]
0000786bc93d34f2  vmovaps xmm2, [rsp+0x20]
0000786bc93d34f8  vmovaps xmm3, [rsp+0x30]
0000786bc93d34fe  vmovaps xmm4, [rsp+0x40]
0000786bc93d3504  vmovaps xmm5, [rsp+0x50]
0000786bc93d350a  vmovaps xmm6, [rsp+0x60]
0000786bc93d3510  vmovaps xmm7, [rsp+0x70]
0000786bc93d3516  vmovaps xmm8, [rsp+0x80]
0000786bc93d351f  vmovaps xmm9, [rsp+0x90]
0000786bc93d3528  vmovaps xmm10, [rsp+0xA0]
0000786bc93d3531  vmovaps xmm11, [rsp+0xB0]
0000786bc93d353a  vmovaps xmm12, [rsp+0xC0]
0000786bc93d3543  vmovaps xmm13, [rsp+0xD0]
0000786bc93d354c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3555  add rsp, 0xF0
0000786bc93d355c  pop r11
0000786bc93d355e  pop r10
0000786bc93d3560  pop r9
0000786bc93d3562  pop r8
0000786bc93d3564  pop rsi
0000786bc93d3565  pop rdi
0000786bc93d3566  pop rdx
0000786bc93d3567  pop rcx
0000786bc93d3568  pop rax
0000786bc93d3569  add rsp, 0x08
0000786bc93d356d  jmp 0x0000786BC93CFEF1
0000786bc93d3572  sub rsp, 0x08
0000786bc93d3576  push rax
0000786bc93d3577  push rcx
0000786bc93d3578  push rdx
0000786bc93d3579  push rdi
0000786bc93d357a  push rsi
0000786bc93d357b  push r8
0000786bc93d357d  push r9
0000786bc93d357f  push r10
0000786bc93d3581  push r11
0000786bc93d3583  sub rsp, 0xF0
0000786bc93d358a  vmovaps [rsp], xmm0
0000786bc93d358f  vmovaps [rsp+0x10], xmm1
0000786bc93d3595  vmovaps [rsp+0x20], xmm2
0000786bc93d359b  vmovaps [rsp+0x30], xmm3
0000786bc93d35a1  vmovaps [rsp+0x40], xmm4
0000786bc93d35a7  vmovaps [rsp+0x50], xmm5
0000786bc93d35ad  vmovaps [rsp+0x60], xmm7
0000786bc93d35b3  vmovaps [rsp+0x70], xmm8
0000786bc93d35b9  vmovaps [rsp+0x80], xmm9
0000786bc93d35c2  vmovaps [rsp+0x90], xmm10
0000786bc93d35cb  vmovaps [rsp+0xA0], xmm11
0000786bc93d35d4  vmovaps [rsp+0xB0], xmm12
0000786bc93d35dd  vmovaps [rsp+0xC0], xmm13
0000786bc93d35e6  vmovaps [rsp+0xD0], xmm14
0000786bc93d35ef  vmovaps [rsp+0xE0], xmm15
0000786bc93d35f8  sub rsp, 0x30
0000786bc93d35fc  movaps [rsp], xmm6
0000786bc93d3600  movaps [rsp+0x10], xmm9
0000786bc93d3606  movaps [rsp+0x20], xmm12
0000786bc93d360c  lea rdi, [rsp]
0000786bc93d3610  mov esi, 0x00
0000786bc93d3615  mov rax, 0x60810F6F7530
0000786bc93d361f  call rax
0000786bc93d3621  movaps xmm6, [rsp]
0000786bc93d3625  add rsp, 0x30
0000786bc93d3629  vmovaps xmm0, [rsp]
0000786bc93d362e  vmovaps xmm1, [rsp+0x10]
0000786bc93d3634  vmovaps xmm2, [rsp+0x20]
0000786bc93d363a  vmovaps xmm3, [rsp+0x30]
0000786bc93d3640  vmovaps xmm4, [rsp+0x40]
0000786bc93d3646  vmovaps xmm5, [rsp+0x50]
0000786bc93d364c  vmovaps xmm7, [rsp+0x60]
0000786bc93d3652  vmovaps xmm8, [rsp+0x70]
0000786bc93d3658  vmovaps xmm9, [rsp+0x80]
0000786bc93d3661  vmovaps xmm10, [rsp+0x90]
0000786bc93d366a  vmovaps xmm11, [rsp+0xA0]
0000786bc93d3673  vmovaps xmm12, [rsp+0xB0]
0000786bc93d367c  vmovaps xmm13, [rsp+0xC0]
0000786bc93d3685  vmovaps xmm14, [rsp+0xD0]
0000786bc93d368e  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3697  add rsp, 0xF0
0000786bc93d369e  pop r11
0000786bc93d36a0  pop r10
0000786bc93d36a2  pop r9
0000786bc93d36a4  pop r8
0000786bc93d36a6  pop rsi
0000786bc93d36a7  pop rdi
0000786bc93d36a8  pop rdx
0000786bc93d36a9  pop rcx
0000786bc93d36aa  pop rax
0000786bc93d36ab  add rsp, 0x08
0000786bc93d36af  jmp 0x0000786BC93CFF19
0000786bc93d36b4  sub rsp, 0x08
0000786bc93d36b8  push rax
0000786bc93d36b9  push rcx
0000786bc93d36ba  push rdx
0000786bc93d36bb  push rdi
0000786bc93d36bc  push rsi
0000786bc93d36bd  push r8
0000786bc93d36bf  push r9
0000786bc93d36c1  push r10
0000786bc93d36c3  push r11
0000786bc93d36c5  sub rsp, 0xF0
0000786bc93d36cc  vmovaps [rsp], xmm0
0000786bc93d36d1  vmovaps [rsp+0x10], xmm1
0000786bc93d36d7  vmovaps [rsp+0x20], xmm2
0000786bc93d36dd  vmovaps [rsp+0x30], xmm3
0000786bc93d36e3  vmovaps [rsp+0x40], xmm4
0000786bc93d36e9  vmovaps [rsp+0x50], xmm5
0000786bc93d36ef  vmovaps [rsp+0x60], xmm6
0000786bc93d36f5  vmovaps [rsp+0x70], xmm7
0000786bc93d36fb  vmovaps [rsp+0x80], xmm8
0000786bc93d3704  vmovaps [rsp+0x90], xmm9
0000786bc93d370d  vmovaps [rsp+0xA0], xmm10
0000786bc93d3716  vmovaps [rsp+0xB0], xmm11
0000786bc93d371f  vmovaps [rsp+0xC0], xmm13
0000786bc93d3728  vmovaps [rsp+0xD0], xmm14
0000786bc93d3731  vmovaps [rsp+0xE0], xmm15
0000786bc93d373a  sub rsp, 0x30
0000786bc93d373e  movaps [rsp], xmm12
0000786bc93d3743  movaps [rsp+0x10], xmm15
0000786bc93d3749  movaps [rsp+0x20], xmm13
0000786bc93d374f  lea rdi, [rsp]
0000786bc93d3753  mov esi, 0x00
0000786bc93d3758  mov rax, 0x60810F6F7530
0000786bc93d3762  call rax
0000786bc93d3764  movaps xmm12, [rsp]
0000786bc93d3769  add rsp, 0x30
0000786bc93d376d  vmovaps xmm0, [rsp]
0000786bc93d3772  vmovaps xmm1, [rsp+0x10]
0000786bc93d3778  vmovaps xmm2, [rsp+0x20]
0000786bc93d377e  vmovaps xmm3, [rsp+0x30]
0000786bc93d3784  vmovaps xmm4, [rsp+0x40]
0000786bc93d378a  vmovaps xmm5, [rsp+0x50]
0000786bc93d3790  vmovaps xmm6, [rsp+0x60]
0000786bc93d3796  vmovaps xmm7, [rsp+0x70]
0000786bc93d379c  vmovaps xmm8, [rsp+0x80]
0000786bc93d37a5  vmovaps xmm9, [rsp+0x90]
0000786bc93d37ae  vmovaps xmm10, [rsp+0xA0]
0000786bc93d37b7  vmovaps xmm11, [rsp+0xB0]
0000786bc93d37c0  vmovaps xmm13, [rsp+0xC0]
0000786bc93d37c9  vmovaps xmm14, [rsp+0xD0]
0000786bc93d37d2  vmovaps xmm15, [rsp+0xE0]
0000786bc93d37db  add rsp, 0xF0
0000786bc93d37e2  pop r11
0000786bc93d37e4  pop r10
0000786bc93d37e6  pop r9
0000786bc93d37e8  pop r8
0000786bc93d37ea  pop rsi
0000786bc93d37eb  pop rdi
0000786bc93d37ec  pop rdx
0000786bc93d37ed  pop rcx
0000786bc93d37ee  pop rax
0000786bc93d37ef  add rsp, 0x08
0000786bc93d37f3  jmp 0x0000786BC93CFF34
0000786bc93d37f8  sub rsp, 0x08
0000786bc93d37fc  push rax
0000786bc93d37fd  push rcx
0000786bc93d37fe  push rdx
0000786bc93d37ff  push rdi
0000786bc93d3800  push rsi
0000786bc93d3801  push r8
0000786bc93d3803  push r9
0000786bc93d3805  push r10
0000786bc93d3807  push r11
0000786bc93d3809  sub rsp, 0xF0
0000786bc93d3810  vmovaps [rsp], xmm0
0000786bc93d3815  vmovaps [rsp+0x10], xmm1
0000786bc93d381b  vmovaps [rsp+0x20], xmm2
0000786bc93d3821  vmovaps [rsp+0x30], xmm3
0000786bc93d3827  vmovaps [rsp+0x40], xmm4
0000786bc93d382d  vmovaps [rsp+0x50], xmm5
0000786bc93d3833  vmovaps [rsp+0x60], xmm6
0000786bc93d3839  vmovaps [rsp+0x70], xmm7
0000786bc93d383f  vmovaps [rsp+0x80], xmm8
0000786bc93d3848  vmovaps [rsp+0x90], xmm9
0000786bc93d3851  vmovaps [rsp+0xA0], xmm10
0000786bc93d385a  vmovaps [rsp+0xB0], xmm11
0000786bc93d3863  vmovaps [rsp+0xC0], xmm12
0000786bc93d386c  vmovaps [rsp+0xD0], xmm13
0000786bc93d3875  vmovaps [rsp+0xE0], xmm14
0000786bc93d387e  sub rsp, 0x30
0000786bc93d3882  movaps [rsp], xmm15
0000786bc93d3887  movaps [rsp+0x10], xmm13
0000786bc93d388d  movaps [rsp+0x20], xmm10
0000786bc93d3893  lea rdi, [rsp]
0000786bc93d3897  mov esi, 0x00
0000786bc93d389c  mov rax, 0x60810F6F7530
0000786bc93d38a6  call rax
0000786bc93d38a8  movaps xmm15, [rsp]
0000786bc93d38ad  add rsp, 0x30
0000786bc93d38b1  vmovaps xmm0, [rsp]
0000786bc93d38b6  vmovaps xmm1, [rsp+0x10]
0000786bc93d38bc  vmovaps xmm2, [rsp+0x20]
0000786bc93d38c2  vmovaps xmm3, [rsp+0x30]
0000786bc93d38c8  vmovaps xmm4, [rsp+0x40]
0000786bc93d38ce  vmovaps xmm5, [rsp+0x50]
0000786bc93d38d4  vmovaps xmm6, [rsp+0x60]
0000786bc93d38da  vmovaps xmm7, [rsp+0x70]
0000786bc93d38e0  vmovaps xmm8, [rsp+0x80]
0000786bc93d38e9  vmovaps xmm9, [rsp+0x90]
0000786bc93d38f2  vmovaps xmm10, [rsp+0xA0]
0000786bc93d38fb  vmovaps xmm11, [rsp+0xB0]
0000786bc93d3904  vmovaps xmm12, [rsp+0xC0]
0000786bc93d390d  vmovaps xmm13, [rsp+0xD0]
0000786bc93d3916  vmovaps xmm14, [rsp+0xE0]
0000786bc93d391f  add rsp, 0xF0
0000786bc93d3926  pop r11
0000786bc93d3928  pop r10
0000786bc93d392a  pop r9
0000786bc93d392c  pop r8
0000786bc93d392e  pop rsi
0000786bc93d392f  pop rdi
0000786bc93d3930  pop rdx
0000786bc93d3931  pop rcx
0000786bc93d3932  pop rax
0000786bc93d3933  add rsp, 0x08
0000786bc93d3937  jmp 0x0000786BC93CFF55
0000786bc93d393c  call 0x0000786BC920C260
0000786bc93d3941  jmp 0x0000786BC93CFFB0
0000786bc93d3946  sub rsp, 0x08
0000786bc93d394a  push rax
0000786bc93d394b  push rcx
0000786bc93d394c  push rdx
0000786bc93d394d  push rdi
0000786bc93d394e  push rsi
0000786bc93d394f  push r8
0000786bc93d3951  push r9
0000786bc93d3953  push r10
0000786bc93d3955  push r11
0000786bc93d3957  sub rsp, 0xF0
0000786bc93d395e  vmovaps [rsp], xmm0
0000786bc93d3963  vmovaps [rsp+0x10], xmm1
0000786bc93d3969  vmovaps [rsp+0x20], xmm2
0000786bc93d396f  vmovaps [rsp+0x30], xmm3
0000786bc93d3975  vmovaps [rsp+0x40], xmm4
0000786bc93d397b  vmovaps [rsp+0x50], xmm5
0000786bc93d3981  vmovaps [rsp+0x60], xmm6
0000786bc93d3987  vmovaps [rsp+0x70], xmm7
0000786bc93d398d  vmovaps [rsp+0x80], xmm8
0000786bc93d3996  vmovaps [rsp+0x90], xmm10
0000786bc93d399f  vmovaps [rsp+0xA0], xmm11
0000786bc93d39a8  vmovaps [rsp+0xB0], xmm12
0000786bc93d39b1  vmovaps [rsp+0xC0], xmm13
0000786bc93d39ba  vmovaps [rsp+0xD0], xmm14
0000786bc93d39c3  vmovaps [rsp+0xE0], xmm15
0000786bc93d39cc  sub rsp, 0x30
0000786bc93d39d0  movaps [rsp], xmm9
0000786bc93d39d5  movaps [rsp+0x10], xmm8
0000786bc93d39db  movaps [rsp+0x20], xmm10
0000786bc93d39e1  lea rdi, [rsp]
0000786bc93d39e5  mov esi, 0x00
0000786bc93d39ea  mov rax, 0x60810F6F7530
0000786bc93d39f4  call rax
0000786bc93d39f6  movaps xmm9, [rsp]
0000786bc93d39fb  add rsp, 0x30
0000786bc93d39ff  vmovaps xmm0, [rsp]
0000786bc93d3a04  vmovaps xmm1, [rsp+0x10]
0000786bc93d3a0a  vmovaps xmm2, [rsp+0x20]
0000786bc93d3a10  vmovaps xmm3, [rsp+0x30]
0000786bc93d3a16  vmovaps xmm4, [rsp+0x40]
0000786bc93d3a1c  vmovaps xmm5, [rsp+0x50]
0000786bc93d3a22  vmovaps xmm6, [rsp+0x60]
0000786bc93d3a28  vmovaps xmm7, [rsp+0x70]
0000786bc93d3a2e  vmovaps xmm8, [rsp+0x80]
0000786bc93d3a37  vmovaps xmm10, [rsp+0x90]
0000786bc93d3a40  vmovaps xmm11, [rsp+0xA0]
0000786bc93d3a49  vmovaps xmm12, [rsp+0xB0]
0000786bc93d3a52  vmovaps xmm13, [rsp+0xC0]
0000786bc93d3a5b  vmovaps xmm14, [rsp+0xD0]
0000786bc93d3a64  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3a6d  add rsp, 0xF0
0000786bc93d3a74  pop r11
0000786bc93d3a76  pop r10
0000786bc93d3a78  pop r9
0000786bc93d3a7a  pop r8
0000786bc93d3a7c  pop rsi
0000786bc93d3a7d  pop rdi
0000786bc93d3a7e  pop rdx
0000786bc93d3a7f  pop rcx
0000786bc93d3a80  pop rax
0000786bc93d3a81  add rsp, 0x08
0000786bc93d3a85  jmp 0x0000786BC93CFFE1
0000786bc93d3a8a  sub rsp, 0x08
0000786bc93d3a8e  push rax
0000786bc93d3a8f  push rcx
0000786bc93d3a90  push rdx
0000786bc93d3a91  push rdi
0000786bc93d3a92  push rsi
0000786bc93d3a93  push r8
0000786bc93d3a95  push r9
0000786bc93d3a97  push r10
0000786bc93d3a99  push r11
0000786bc93d3a9b  sub rsp, 0xF0
0000786bc93d3aa2  vmovaps [rsp], xmm0
0000786bc93d3aa7  vmovaps [rsp+0x10], xmm1
0000786bc93d3aad  vmovaps [rsp+0x20], xmm2
0000786bc93d3ab3  vmovaps [rsp+0x30], xmm3
0000786bc93d3ab9  vmovaps [rsp+0x40], xmm4
0000786bc93d3abf  vmovaps [rsp+0x50], xmm5
0000786bc93d3ac5  vmovaps [rsp+0x60], xmm6
0000786bc93d3acb  vmovaps [rsp+0x70], xmm7
0000786bc93d3ad1  vmovaps [rsp+0x80], xmm8
0000786bc93d3ada  vmovaps [rsp+0x90], xmm9
0000786bc93d3ae3  vmovaps [rsp+0xA0], xmm11
0000786bc93d3aec  vmovaps [rsp+0xB0], xmm12
0000786bc93d3af5  vmovaps [rsp+0xC0], xmm13
0000786bc93d3afe  vmovaps [rsp+0xD0], xmm14
0000786bc93d3b07  vmovaps [rsp+0xE0], xmm15
0000786bc93d3b10  sub rsp, 0x30
0000786bc93d3b14  movaps [rsp], xmm10
0000786bc93d3b19  movaps [rsp+0x10], xmm1
0000786bc93d3b1e  movaps [rsp+0x20], xmm11
0000786bc93d3b24  lea rdi, [rsp]
0000786bc93d3b28  mov esi, 0x00
0000786bc93d3b2d  mov rax, 0x60810F6F7530
0000786bc93d3b37  call rax
0000786bc93d3b39  movaps xmm10, [rsp]
0000786bc93d3b3e  add rsp, 0x30
0000786bc93d3b42  vmovaps xmm0, [rsp]
0000786bc93d3b47  vmovaps xmm1, [rsp+0x10]
0000786bc93d3b4d  vmovaps xmm2, [rsp+0x20]
0000786bc93d3b53  vmovaps xmm3, [rsp+0x30]
0000786bc93d3b59  vmovaps xmm4, [rsp+0x40]
0000786bc93d3b5f  vmovaps xmm5, [rsp+0x50]
0000786bc93d3b65  vmovaps xmm6, [rsp+0x60]
0000786bc93d3b6b  vmovaps xmm7, [rsp+0x70]
0000786bc93d3b71  vmovaps xmm8, [rsp+0x80]
0000786bc93d3b7a  vmovaps xmm9, [rsp+0x90]
0000786bc93d3b83  vmovaps xmm11, [rsp+0xA0]
0000786bc93d3b8c  vmovaps xmm12, [rsp+0xB0]
0000786bc93d3b95  vmovaps xmm13, [rsp+0xC0]
0000786bc93d3b9e  vmovaps xmm14, [rsp+0xD0]
0000786bc93d3ba7  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3bb0  add rsp, 0xF0
0000786bc93d3bb7  pop r11
0000786bc93d3bb9  pop r10
0000786bc93d3bbb  pop r9
0000786bc93d3bbd  pop r8
0000786bc93d3bbf  pop rsi
0000786bc93d3bc0  pop rdi
0000786bc93d3bc1  pop rdx
0000786bc93d3bc2  pop rcx
0000786bc93d3bc3  pop rax
0000786bc93d3bc4  add rsp, 0x08
0000786bc93d3bc8  jmp 0x0000786BC93CFFFC
0000786bc93d3bcd  sub rsp, 0x08
0000786bc93d3bd1  push rax
0000786bc93d3bd2  push rcx
0000786bc93d3bd3  push rdx
0000786bc93d3bd4  push rdi
0000786bc93d3bd5  push rsi
0000786bc93d3bd6  push r8
0000786bc93d3bd8  push r9
0000786bc93d3bda  push r10
0000786bc93d3bdc  push r11
0000786bc93d3bde  sub rsp, 0xF0
0000786bc93d3be5  vmovaps [rsp], xmm0
0000786bc93d3bea  vmovaps [rsp+0x10], xmm2
0000786bc93d3bf0  vmovaps [rsp+0x20], xmm3
0000786bc93d3bf6  vmovaps [rsp+0x30], xmm4
0000786bc93d3bfc  vmovaps [rsp+0x40], xmm5
0000786bc93d3c02  vmovaps [rsp+0x50], xmm6
0000786bc93d3c08  vmovaps [rsp+0x60], xmm7
0000786bc93d3c0e  vmovaps [rsp+0x70], xmm8
0000786bc93d3c14  vmovaps [rsp+0x80], xmm9
0000786bc93d3c1d  vmovaps [rsp+0x90], xmm10
0000786bc93d3c26  vmovaps [rsp+0xA0], xmm11
0000786bc93d3c2f  vmovaps [rsp+0xB0], xmm12
0000786bc93d3c38  vmovaps [rsp+0xC0], xmm13
0000786bc93d3c41  vmovaps [rsp+0xD0], xmm14
0000786bc93d3c4a  vmovaps [rsp+0xE0], xmm15
0000786bc93d3c53  sub rsp, 0x30
0000786bc93d3c57  movaps [rsp], xmm1
0000786bc93d3c5b  movaps [rsp+0x10], xmm14
0000786bc93d3c61  movaps [rsp+0x20], xmm6
0000786bc93d3c66  lea rdi, [rsp]
0000786bc93d3c6a  mov esi, 0x00
0000786bc93d3c6f  mov rax, 0x60810F6F7530
0000786bc93d3c79  call rax
0000786bc93d3c7b  movaps xmm1, [rsp]
0000786bc93d3c7f  add rsp, 0x30
0000786bc93d3c83  vmovaps xmm0, [rsp]
0000786bc93d3c88  vmovaps xmm2, [rsp+0x10]
0000786bc93d3c8e  vmovaps xmm3, [rsp+0x20]
0000786bc93d3c94  vmovaps xmm4, [rsp+0x30]
0000786bc93d3c9a  vmovaps xmm5, [rsp+0x40]
0000786bc93d3ca0  vmovaps xmm6, [rsp+0x50]
0000786bc93d3ca6  vmovaps xmm7, [rsp+0x60]
0000786bc93d3cac  vmovaps xmm8, [rsp+0x70]
0000786bc93d3cb2  vmovaps xmm9, [rsp+0x80]
0000786bc93d3cbb  vmovaps xmm10, [rsp+0x90]
0000786bc93d3cc4  vmovaps xmm11, [rsp+0xA0]
0000786bc93d3ccd  vmovaps xmm12, [rsp+0xB0]
0000786bc93d3cd6  vmovaps xmm13, [rsp+0xC0]
0000786bc93d3cdf  vmovaps xmm14, [rsp+0xD0]
0000786bc93d3ce8  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3cf1  add rsp, 0xF0
0000786bc93d3cf8  pop r11
0000786bc93d3cfa  pop r10
0000786bc93d3cfc  pop r9
0000786bc93d3cfe  pop r8
0000786bc93d3d00  pop rsi
0000786bc93d3d01  pop rdi
0000786bc93d3d02  pop rdx
0000786bc93d3d03  pop rcx
0000786bc93d3d04  pop rax
0000786bc93d3d05  add rsp, 0x08
0000786bc93d3d09  jmp 0x0000786BC93D0015
0000786bc93d3d0e  sub rsp, 0x08
0000786bc93d3d12  push rax
0000786bc93d3d13  push rcx
0000786bc93d3d14  push rdx
0000786bc93d3d15  push rdi
0000786bc93d3d16  push rsi
0000786bc93d3d17  push r8
0000786bc93d3d19  push r9
0000786bc93d3d1b  push r10
0000786bc93d3d1d  push r11
0000786bc93d3d1f  sub rsp, 0xF0
0000786bc93d3d26  vmovaps [rsp], xmm0
0000786bc93d3d2b  vmovaps [rsp+0x10], xmm1
0000786bc93d3d31  vmovaps [rsp+0x20], xmm2
0000786bc93d3d37  vmovaps [rsp+0x30], xmm3
0000786bc93d3d3d  vmovaps [rsp+0x40], xmm4
0000786bc93d3d43  vmovaps [rsp+0x50], xmm5
0000786bc93d3d49  vmovaps [rsp+0x60], xmm6
0000786bc93d3d4f  vmovaps [rsp+0x70], xmm7
0000786bc93d3d55  vmovaps [rsp+0x80], xmm8
0000786bc93d3d5e  vmovaps [rsp+0x90], xmm9
0000786bc93d3d67  vmovaps [rsp+0xA0], xmm10
0000786bc93d3d70  vmovaps [rsp+0xB0], xmm12
0000786bc93d3d79  vmovaps [rsp+0xC0], xmm13
0000786bc93d3d82  vmovaps [rsp+0xD0], xmm14
0000786bc93d3d8b  vmovaps [rsp+0xE0], xmm15
0000786bc93d3d94  sub rsp, 0x30
0000786bc93d3d98  movaps [rsp], xmm11
0000786bc93d3d9d  movaps [rsp+0x10], xmm13
0000786bc93d3da3  movaps [rsp+0x20], xmm14
0000786bc93d3da9  lea rdi, [rsp]
0000786bc93d3dad  mov esi, 0x00
0000786bc93d3db2  mov rax, 0x60810F6F7530
0000786bc93d3dbc  call rax
0000786bc93d3dbe  movaps xmm11, [rsp]
0000786bc93d3dc3  add rsp, 0x30
0000786bc93d3dc7  vmovaps xmm0, [rsp]
0000786bc93d3dcc  vmovaps xmm1, [rsp+0x10]
0000786bc93d3dd2  vmovaps xmm2, [rsp+0x20]
0000786bc93d3dd8  vmovaps xmm3, [rsp+0x30]
0000786bc93d3dde  vmovaps xmm4, [rsp+0x40]
0000786bc93d3de4  vmovaps xmm5, [rsp+0x50]
0000786bc93d3dea  vmovaps xmm6, [rsp+0x60]
0000786bc93d3df0  vmovaps xmm7, [rsp+0x70]
0000786bc93d3df6  vmovaps xmm8, [rsp+0x80]
0000786bc93d3dff  vmovaps xmm9, [rsp+0x90]
0000786bc93d3e08  vmovaps xmm10, [rsp+0xA0]
0000786bc93d3e11  vmovaps xmm12, [rsp+0xB0]
0000786bc93d3e1a  vmovaps xmm13, [rsp+0xC0]
0000786bc93d3e23  vmovaps xmm14, [rsp+0xD0]
0000786bc93d3e2c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3e35  add rsp, 0xF0
0000786bc93d3e3c  pop r11
0000786bc93d3e3e  pop r10
0000786bc93d3e40  pop r9
0000786bc93d3e42  pop r8
0000786bc93d3e44  pop rsi
0000786bc93d3e45  pop rdi
0000786bc93d3e46  pop rdx
0000786bc93d3e47  pop rcx
0000786bc93d3e48  pop rax
0000786bc93d3e49  add rsp, 0x08
0000786bc93d3e4d  jmp 0x0000786BC93D003F
0000786bc93d3e52  sub rsp, 0x08
0000786bc93d3e56  push rax
0000786bc93d3e57  push rcx
0000786bc93d3e58  push rdx
0000786bc93d3e59  push rdi
0000786bc93d3e5a  push rsi
0000786bc93d3e5b  push r8
0000786bc93d3e5d  push r9
0000786bc93d3e5f  push r10
0000786bc93d3e61  push r11
0000786bc93d3e63  sub rsp, 0xF0
0000786bc93d3e6a  vmovaps [rsp], xmm0
0000786bc93d3e6f  vmovaps [rsp+0x10], xmm1
0000786bc93d3e75  vmovaps [rsp+0x20], xmm2
0000786bc93d3e7b  vmovaps [rsp+0x30], xmm3
0000786bc93d3e81  vmovaps [rsp+0x40], xmm4
0000786bc93d3e87  vmovaps [rsp+0x50], xmm5
0000786bc93d3e8d  vmovaps [rsp+0x60], xmm6
0000786bc93d3e93  vmovaps [rsp+0x70], xmm7
0000786bc93d3e99  vmovaps [rsp+0x80], xmm8
0000786bc93d3ea2  vmovaps [rsp+0x90], xmm9
0000786bc93d3eab  vmovaps [rsp+0xA0], xmm10
0000786bc93d3eb4  vmovaps [rsp+0xB0], xmm11
0000786bc93d3ebd  vmovaps [rsp+0xC0], xmm12
0000786bc93d3ec6  vmovaps [rsp+0xD0], xmm14
0000786bc93d3ecf  vmovaps [rsp+0xE0], xmm15
0000786bc93d3ed8  sub rsp, 0x30
0000786bc93d3edc  movaps [rsp], xmm13
0000786bc93d3ee1  movaps [rsp+0x10], xmm8
0000786bc93d3ee7  movaps [rsp+0x20], xmm14
0000786bc93d3eed  lea rdi, [rsp]
0000786bc93d3ef1  mov esi, 0x00
0000786bc93d3ef6  mov rax, 0x60810F6F7530
0000786bc93d3f00  call rax
0000786bc93d3f02  movaps xmm13, [rsp]
0000786bc93d3f07  add rsp, 0x30
0000786bc93d3f0b  vmovaps xmm0, [rsp]
0000786bc93d3f10  vmovaps xmm1, [rsp+0x10]
0000786bc93d3f16  vmovaps xmm2, [rsp+0x20]
0000786bc93d3f1c  vmovaps xmm3, [rsp+0x30]
0000786bc93d3f22  vmovaps xmm4, [rsp+0x40]
0000786bc93d3f28  vmovaps xmm5, [rsp+0x50]
0000786bc93d3f2e  vmovaps xmm6, [rsp+0x60]
0000786bc93d3f34  vmovaps xmm7, [rsp+0x70]
0000786bc93d3f3a  vmovaps xmm8, [rsp+0x80]
0000786bc93d3f43  vmovaps xmm9, [rsp+0x90]
0000786bc93d3f4c  vmovaps xmm10, [rsp+0xA0]
0000786bc93d3f55  vmovaps xmm11, [rsp+0xB0]
0000786bc93d3f5e  vmovaps xmm12, [rsp+0xC0]
0000786bc93d3f67  vmovaps xmm14, [rsp+0xD0]
0000786bc93d3f70  vmovaps xmm15, [rsp+0xE0]
0000786bc93d3f79  add rsp, 0xF0
0000786bc93d3f80  pop r11
0000786bc93d3f82  pop r10
0000786bc93d3f84  pop r9
0000786bc93d3f86  pop r8
0000786bc93d3f88  pop rsi
0000786bc93d3f89  pop rdi
0000786bc93d3f8a  pop rdx
0000786bc93d3f8b  pop rcx
0000786bc93d3f8c  pop rax
0000786bc93d3f8d  add rsp, 0x08
0000786bc93d3f91  jmp 0x0000786BC93D006E
0000786bc93d3f96  sub rsp, 0x08
0000786bc93d3f9a  push rax
0000786bc93d3f9b  push rcx
0000786bc93d3f9c  push rdx
0000786bc93d3f9d  push rdi
0000786bc93d3f9e  push rsi
0000786bc93d3f9f  push r8
0000786bc93d3fa1  push r9
0000786bc93d3fa3  push r10
0000786bc93d3fa5  push r11
0000786bc93d3fa7  sub rsp, 0xF0
0000786bc93d3fae  vmovaps [rsp], xmm0
0000786bc93d3fb3  vmovaps [rsp+0x10], xmm1
0000786bc93d3fb9  vmovaps [rsp+0x20], xmm2
0000786bc93d3fbf  vmovaps [rsp+0x30], xmm3
0000786bc93d3fc5  vmovaps [rsp+0x40], xmm4
0000786bc93d3fcb  vmovaps [rsp+0x50], xmm5
0000786bc93d3fd1  vmovaps [rsp+0x60], xmm6
0000786bc93d3fd7  vmovaps [rsp+0x70], xmm7
0000786bc93d3fdd  vmovaps [rsp+0x80], xmm9
0000786bc93d3fe6  vmovaps [rsp+0x90], xmm10
0000786bc93d3fef  vmovaps [rsp+0xA0], xmm11
0000786bc93d3ff8  vmovaps [rsp+0xB0], xmm12
0000786bc93d4001  vmovaps [rsp+0xC0], xmm13
0000786bc93d400a  vmovaps [rsp+0xD0], xmm14
0000786bc93d4013  vmovaps [rsp+0xE0], xmm15
0000786bc93d401c  sub rsp, 0x30
0000786bc93d4020  movaps [rsp], xmm8
0000786bc93d4025  movaps [rsp+0x10], xmm7
0000786bc93d402a  movaps [rsp+0x20], xmm14
0000786bc93d4030  lea rdi, [rsp]
0000786bc93d4034  mov esi, 0x00
0000786bc93d4039  mov rax, 0x60810F6F7530
0000786bc93d4043  call rax
0000786bc93d4045  movaps xmm8, [rsp]
0000786bc93d404a  add rsp, 0x30
0000786bc93d404e  vmovaps xmm0, [rsp]
0000786bc93d4053  vmovaps xmm1, [rsp+0x10]
0000786bc93d4059  vmovaps xmm2, [rsp+0x20]
0000786bc93d405f  vmovaps xmm3, [rsp+0x30]
0000786bc93d4065  vmovaps xmm4, [rsp+0x40]
0000786bc93d406b  vmovaps xmm5, [rsp+0x50]
0000786bc93d4071  vmovaps xmm6, [rsp+0x60]
0000786bc93d4077  vmovaps xmm7, [rsp+0x70]
0000786bc93d407d  vmovaps xmm9, [rsp+0x80]
0000786bc93d4086  vmovaps xmm10, [rsp+0x90]
0000786bc93d408f  vmovaps xmm11, [rsp+0xA0]
0000786bc93d4098  vmovaps xmm12, [rsp+0xB0]
0000786bc93d40a1  vmovaps xmm13, [rsp+0xC0]
0000786bc93d40aa  vmovaps xmm14, [rsp+0xD0]
0000786bc93d40b3  vmovaps xmm15, [rsp+0xE0]
0000786bc93d40bc  add rsp, 0xF0
0000786bc93d40c3  pop r11
0000786bc93d40c5  pop r10
0000786bc93d40c7  pop r9
0000786bc93d40c9  pop r8
0000786bc93d40cb  pop rsi
0000786bc93d40cc  pop rdi
0000786bc93d40cd  pop rdx
0000786bc93d40ce  pop rcx
0000786bc93d40cf  pop rax
0000786bc93d40d0  add rsp, 0x08
0000786bc93d40d4  jmp 0x0000786BC93D0094
0000786bc93d40d9  sub rsp, 0x08
0000786bc93d40dd  push rax
0000786bc93d40de  push rcx
0000786bc93d40df  push rdx
0000786bc93d40e0  push rdi
0000786bc93d40e1  push rsi
0000786bc93d40e2  push r8
0000786bc93d40e4  push r9
0000786bc93d40e6  push r10
0000786bc93d40e8  push r11
0000786bc93d40ea  sub rsp, 0xF0
0000786bc93d40f1  vmovaps [rsp], xmm0
0000786bc93d40f6  vmovaps [rsp+0x10], xmm1
0000786bc93d40fc  vmovaps [rsp+0x20], xmm2
0000786bc93d4102  vmovaps [rsp+0x30], xmm3
0000786bc93d4108  vmovaps [rsp+0x40], xmm4
0000786bc93d410e  vmovaps [rsp+0x50], xmm5
0000786bc93d4114  vmovaps [rsp+0x60], xmm6
0000786bc93d411a  vmovaps [rsp+0x70], xmm7
0000786bc93d4120  vmovaps [rsp+0x80], xmm8
0000786bc93d4129  vmovaps [rsp+0x90], xmm9
0000786bc93d4132  vmovaps [rsp+0xA0], xmm10
0000786bc93d413b  vmovaps [rsp+0xB0], xmm11
0000786bc93d4144  vmovaps [rsp+0xC0], xmm12
0000786bc93d414d  vmovaps [rsp+0xD0], xmm13
0000786bc93d4156  vmovaps [rsp+0xE0], xmm15
0000786bc93d415f  sub rsp, 0x30
0000786bc93d4163  movaps [rsp], xmm14
0000786bc93d4168  movaps [rsp+0x10], xmm12
0000786bc93d416e  movaps [rsp+0x20], xmm9
0000786bc93d4174  lea rdi, [rsp]
0000786bc93d4178  mov esi, 0x00
0000786bc93d417d  mov rax, 0x60810F6F7530
0000786bc93d4187  call rax
0000786bc93d4189  movaps xmm14, [rsp]
0000786bc93d418e  add rsp, 0x30
0000786bc93d4192  vmovaps xmm0, [rsp]
0000786bc93d4197  vmovaps xmm1, [rsp+0x10]
0000786bc93d419d  vmovaps xmm2, [rsp+0x20]
0000786bc93d41a3  vmovaps xmm3, [rsp+0x30]
0000786bc93d41a9  vmovaps xmm4, [rsp+0x40]
0000786bc93d41af  vmovaps xmm5, [rsp+0x50]
0000786bc93d41b5  vmovaps xmm6, [rsp+0x60]
0000786bc93d41bb  vmovaps xmm7, [rsp+0x70]
0000786bc93d41c1  vmovaps xmm8, [rsp+0x80]
0000786bc93d41ca  vmovaps xmm9, [rsp+0x90]
0000786bc93d41d3  vmovaps xmm10, [rsp+0xA0]
0000786bc93d41dc  vmovaps xmm11, [rsp+0xB0]
0000786bc93d41e5  vmovaps xmm12, [rsp+0xC0]
0000786bc93d41ee  vmovaps xmm13, [rsp+0xD0]
0000786bc93d41f7  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4200  add rsp, 0xF0
0000786bc93d4207  pop r11
0000786bc93d4209  pop r10
0000786bc93d420b  pop r9
0000786bc93d420d  pop r8
0000786bc93d420f  pop rsi
0000786bc93d4210  pop rdi
0000786bc93d4211  pop rdx
0000786bc93d4212  pop rcx
0000786bc93d4213  pop rax
0000786bc93d4214  add rsp, 0x08
0000786bc93d4218  jmp 0x0000786BC93D00AE
0000786bc93d421d  sub rsp, 0x08
0000786bc93d4221  push rax
0000786bc93d4222  push rcx
0000786bc93d4223  push rdx
0000786bc93d4224  push rdi
0000786bc93d4225  push rsi
0000786bc93d4226  push r8
0000786bc93d4228  push r9
0000786bc93d422a  push r10
0000786bc93d422c  push r11
0000786bc93d422e  sub rsp, 0xF0
0000786bc93d4235  vmovaps [rsp], xmm0
0000786bc93d423a  vmovaps [rsp+0x10], xmm1
0000786bc93d4240  vmovaps [rsp+0x20], xmm2
0000786bc93d4246  vmovaps [rsp+0x30], xmm3
0000786bc93d424c  vmovaps [rsp+0x40], xmm4
0000786bc93d4252  vmovaps [rsp+0x50], xmm5
0000786bc93d4258  vmovaps [rsp+0x60], xmm6
0000786bc93d425e  vmovaps [rsp+0x70], xmm7
0000786bc93d4264  vmovaps [rsp+0x80], xmm8
0000786bc93d426d  vmovaps [rsp+0x90], xmm10
0000786bc93d4276  vmovaps [rsp+0xA0], xmm11
0000786bc93d427f  vmovaps [rsp+0xB0], xmm12
0000786bc93d4288  vmovaps [rsp+0xC0], xmm13
0000786bc93d4291  vmovaps [rsp+0xD0], xmm14
0000786bc93d429a  vmovaps [rsp+0xE0], xmm15
0000786bc93d42a3  sub rsp, 0x30
0000786bc93d42a7  movaps [rsp], xmm9
0000786bc93d42ac  movaps [rsp+0x10], xmm7
0000786bc93d42b1  movaps [rsp+0x20], xmm12
0000786bc93d42b7  lea rdi, [rsp]
0000786bc93d42bb  mov esi, 0x00
0000786bc93d42c0  mov rax, 0x60810F6F7530
0000786bc93d42ca  call rax
0000786bc93d42cc  movaps xmm9, [rsp]
0000786bc93d42d1  add rsp, 0x30
0000786bc93d42d5  vmovaps xmm0, [rsp]
0000786bc93d42da  vmovaps xmm1, [rsp+0x10]
0000786bc93d42e0  vmovaps xmm2, [rsp+0x20]
0000786bc93d42e6  vmovaps xmm3, [rsp+0x30]
0000786bc93d42ec  vmovaps xmm4, [rsp+0x40]
0000786bc93d42f2  vmovaps xmm5, [rsp+0x50]
0000786bc93d42f8  vmovaps xmm6, [rsp+0x60]
0000786bc93d42fe  vmovaps xmm7, [rsp+0x70]
0000786bc93d4304  vmovaps xmm8, [rsp+0x80]
0000786bc93d430d  vmovaps xmm10, [rsp+0x90]
0000786bc93d4316  vmovaps xmm11, [rsp+0xA0]
0000786bc93d431f  vmovaps xmm12, [rsp+0xB0]
0000786bc93d4328  vmovaps xmm13, [rsp+0xC0]
0000786bc93d4331  vmovaps xmm14, [rsp+0xD0]
0000786bc93d433a  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4343  add rsp, 0xF0
0000786bc93d434a  pop r11
0000786bc93d434c  pop r10
0000786bc93d434e  pop r9
0000786bc93d4350  pop r8
0000786bc93d4352  pop rsi
0000786bc93d4353  pop rdi
0000786bc93d4354  pop rdx
0000786bc93d4355  pop rcx
0000786bc93d4356  pop rax
0000786bc93d4357  add rsp, 0x08
0000786bc93d435b  jmp 0x0000786BC93D00DD
0000786bc93d4360  sub rsp, 0x08
0000786bc93d4364  push rax
0000786bc93d4365  push rcx
0000786bc93d4366  push rdx
0000786bc93d4367  push rdi
0000786bc93d4368  push rsi
0000786bc93d4369  push r8
0000786bc93d436b  push r9
0000786bc93d436d  push r10
0000786bc93d436f  push r11
0000786bc93d4371  sub rsp, 0xF0
0000786bc93d4378  vmovaps [rsp], xmm0
0000786bc93d437d  vmovaps [rsp+0x10], xmm1
0000786bc93d4383  vmovaps [rsp+0x20], xmm2
0000786bc93d4389  vmovaps [rsp+0x30], xmm3
0000786bc93d438f  vmovaps [rsp+0x40], xmm4
0000786bc93d4395  vmovaps [rsp+0x50], xmm5
0000786bc93d439b  vmovaps [rsp+0x60], xmm6
0000786bc93d43a1  vmovaps [rsp+0x70], xmm7
0000786bc93d43a7  vmovaps [rsp+0x80], xmm8
0000786bc93d43b0  vmovaps [rsp+0x90], xmm9
0000786bc93d43b9  vmovaps [rsp+0xA0], xmm10
0000786bc93d43c2  vmovaps [rsp+0xB0], xmm11
0000786bc93d43cb  vmovaps [rsp+0xC0], xmm13
0000786bc93d43d4  vmovaps [rsp+0xD0], xmm14
0000786bc93d43dd  vmovaps [rsp+0xE0], xmm15
0000786bc93d43e6  sub rsp, 0x30
0000786bc93d43ea  movaps [rsp], xmm12
0000786bc93d43ef  movaps [rsp+0x10], xmm15
0000786bc93d43f5  movaps [rsp+0x20], xmm11
0000786bc93d43fb  lea rdi, [rsp]
0000786bc93d43ff  mov esi, 0x00
0000786bc93d4404  mov rax, 0x60810F6F7530
0000786bc93d440e  call rax
0000786bc93d4410  movaps xmm12, [rsp]
0000786bc93d4415  add rsp, 0x30
0000786bc93d4419  vmovaps xmm0, [rsp]
0000786bc93d441e  vmovaps xmm1, [rsp+0x10]
0000786bc93d4424  vmovaps xmm2, [rsp+0x20]
0000786bc93d442a  vmovaps xmm3, [rsp+0x30]
0000786bc93d4430  vmovaps xmm4, [rsp+0x40]
0000786bc93d4436  vmovaps xmm5, [rsp+0x50]
0000786bc93d443c  vmovaps xmm6, [rsp+0x60]
0000786bc93d4442  vmovaps xmm7, [rsp+0x70]
0000786bc93d4448  vmovaps xmm8, [rsp+0x80]
0000786bc93d4451  vmovaps xmm9, [rsp+0x90]
0000786bc93d445a  vmovaps xmm10, [rsp+0xA0]
0000786bc93d4463  vmovaps xmm11, [rsp+0xB0]
0000786bc93d446c  vmovaps xmm13, [rsp+0xC0]
0000786bc93d4475  vmovaps xmm14, [rsp+0xD0]
0000786bc93d447e  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4487  add rsp, 0xF0
0000786bc93d448e  pop r11
0000786bc93d4490  pop r10
0000786bc93d4492  pop r9
0000786bc93d4494  pop r8
0000786bc93d4496  pop rsi
0000786bc93d4497  pop rdi
0000786bc93d4498  pop rdx
0000786bc93d4499  pop rcx
0000786bc93d449a  pop rax
0000786bc93d449b  add rsp, 0x08
0000786bc93d449f  jmp 0x0000786BC93D00F7
0000786bc93d44a4  sub rsp, 0x08
0000786bc93d44a8  push rax
0000786bc93d44a9  push rcx
0000786bc93d44aa  push rdx
0000786bc93d44ab  push rdi
0000786bc93d44ac  push rsi
0000786bc93d44ad  push r8
0000786bc93d44af  push r9
0000786bc93d44b1  push r10
0000786bc93d44b3  push r11
0000786bc93d44b5  sub rsp, 0xF0
0000786bc93d44bc  vmovaps [rsp], xmm0
0000786bc93d44c1  vmovaps [rsp+0x10], xmm1
0000786bc93d44c7  vmovaps [rsp+0x20], xmm2
0000786bc93d44cd  vmovaps [rsp+0x30], xmm3
0000786bc93d44d3  vmovaps [rsp+0x40], xmm4
0000786bc93d44d9  vmovaps [rsp+0x50], xmm5
0000786bc93d44df  vmovaps [rsp+0x60], xmm6
0000786bc93d44e5  vmovaps [rsp+0x70], xmm7
0000786bc93d44eb  vmovaps [rsp+0x80], xmm8
0000786bc93d44f4  vmovaps [rsp+0x90], xmm9
0000786bc93d44fd  vmovaps [rsp+0xA0], xmm10
0000786bc93d4506  vmovaps [rsp+0xB0], xmm12
0000786bc93d450f  vmovaps [rsp+0xC0], xmm13
0000786bc93d4518  vmovaps [rsp+0xD0], xmm14
0000786bc93d4521  vmovaps [rsp+0xE0], xmm15
0000786bc93d452a  sub rsp, 0x30
0000786bc93d452e  movaps [rsp], xmm11
0000786bc93d4533  movaps [rsp+0x10], xmm7
0000786bc93d4538  movaps [rsp+0x20], xmm15
0000786bc93d453e  lea rdi, [rsp]
0000786bc93d4542  mov esi, 0x00
0000786bc93d4547  mov rax, 0x60810F6F7530
0000786bc93d4551  call rax
0000786bc93d4553  movaps xmm11, [rsp]
0000786bc93d4558  add rsp, 0x30
0000786bc93d455c  vmovaps xmm0, [rsp]
0000786bc93d4561  vmovaps xmm1, [rsp+0x10]
0000786bc93d4567  vmovaps xmm2, [rsp+0x20]
0000786bc93d456d  vmovaps xmm3, [rsp+0x30]
0000786bc93d4573  vmovaps xmm4, [rsp+0x40]
0000786bc93d4579  vmovaps xmm5, [rsp+0x50]
0000786bc93d457f  vmovaps xmm6, [rsp+0x60]
0000786bc93d4585  vmovaps xmm7, [rsp+0x70]
0000786bc93d458b  vmovaps xmm8, [rsp+0x80]
0000786bc93d4594  vmovaps xmm9, [rsp+0x90]
0000786bc93d459d  vmovaps xmm10, [rsp+0xA0]
0000786bc93d45a6  vmovaps xmm12, [rsp+0xB0]
0000786bc93d45af  vmovaps xmm13, [rsp+0xC0]
0000786bc93d45b8  vmovaps xmm14, [rsp+0xD0]
0000786bc93d45c1  vmovaps xmm15, [rsp+0xE0]
0000786bc93d45ca  add rsp, 0xF0
0000786bc93d45d1  pop r11
0000786bc93d45d3  pop r10
0000786bc93d45d5  pop r9
0000786bc93d45d7  pop r8
0000786bc93d45d9  pop rsi
0000786bc93d45da  pop rdi
0000786bc93d45db  pop rdx
0000786bc93d45dc  pop rcx
0000786bc93d45dd  pop rax
0000786bc93d45de  add rsp, 0x08
0000786bc93d45e2  jmp 0x0000786BC93D0123
0000786bc93d45e7  sub rsp, 0x08
0000786bc93d45eb  push rax
0000786bc93d45ec  push rcx
0000786bc93d45ed  push rdx
0000786bc93d45ee  push rdi
0000786bc93d45ef  push rsi
0000786bc93d45f0  push r8
0000786bc93d45f2  push r9
0000786bc93d45f4  push r10
0000786bc93d45f6  push r11
0000786bc93d45f8  sub rsp, 0xF0
0000786bc93d45ff  vmovaps [rsp], xmm0
0000786bc93d4604  vmovaps [rsp+0x10], xmm1
0000786bc93d460a  vmovaps [rsp+0x20], xmm2
0000786bc93d4610  vmovaps [rsp+0x30], xmm3
0000786bc93d4616  vmovaps [rsp+0x40], xmm4
0000786bc93d461c  vmovaps [rsp+0x50], xmm5
0000786bc93d4622  vmovaps [rsp+0x60], xmm6
0000786bc93d4628  vmovaps [rsp+0x70], xmm7
0000786bc93d462e  vmovaps [rsp+0x80], xmm8
0000786bc93d4637  vmovaps [rsp+0x90], xmm9
0000786bc93d4640  vmovaps [rsp+0xA0], xmm10
0000786bc93d4649  vmovaps [rsp+0xB0], xmm11
0000786bc93d4652  vmovaps [rsp+0xC0], xmm12
0000786bc93d465b  vmovaps [rsp+0xD0], xmm13
0000786bc93d4664  vmovaps [rsp+0xE0], xmm14
0000786bc93d466d  sub rsp, 0x30
0000786bc93d4671  movaps [rsp], xmm15
0000786bc93d4676  movaps [rsp+0x10], xmm10
0000786bc93d467c  movaps [rsp+0x20], xmm13
0000786bc93d4682  lea rdi, [rsp]
0000786bc93d4686  mov esi, 0x00
0000786bc93d468b  mov rax, 0x60810F6F7530
0000786bc93d4695  call rax
0000786bc93d4697  movaps xmm15, [rsp]
0000786bc93d469c  add rsp, 0x30
0000786bc93d46a0  vmovaps xmm0, [rsp]
0000786bc93d46a5  vmovaps xmm1, [rsp+0x10]
0000786bc93d46ab  vmovaps xmm2, [rsp+0x20]
0000786bc93d46b1  vmovaps xmm3, [rsp+0x30]
0000786bc93d46b7  vmovaps xmm4, [rsp+0x40]
0000786bc93d46bd  vmovaps xmm5, [rsp+0x50]
0000786bc93d46c3  vmovaps xmm6, [rsp+0x60]
0000786bc93d46c9  vmovaps xmm7, [rsp+0x70]
0000786bc93d46cf  vmovaps xmm8, [rsp+0x80]
0000786bc93d46d8  vmovaps xmm9, [rsp+0x90]
0000786bc93d46e1  vmovaps xmm10, [rsp+0xA0]
0000786bc93d46ea  vmovaps xmm11, [rsp+0xB0]
0000786bc93d46f3  vmovaps xmm12, [rsp+0xC0]
0000786bc93d46fc  vmovaps xmm13, [rsp+0xD0]
0000786bc93d4705  vmovaps xmm14, [rsp+0xE0]
0000786bc93d470e  add rsp, 0xF0
0000786bc93d4715  pop r11
0000786bc93d4717  pop r10
0000786bc93d4719  pop r9
0000786bc93d471b  pop r8
0000786bc93d471d  pop rsi
0000786bc93d471e  pop rdi
0000786bc93d471f  pop rdx
0000786bc93d4720  pop rcx
0000786bc93d4721  pop rax
0000786bc93d4722  add rsp, 0x08
0000786bc93d4726  jmp 0x0000786BC93D013D
0000786bc93d472b  sub rsp, 0x08
0000786bc93d472f  push rax
0000786bc93d4730  push rcx
0000786bc93d4731  push rdx
0000786bc93d4732  push rdi
0000786bc93d4733  push rsi
0000786bc93d4734  push r8
0000786bc93d4736  push r9
0000786bc93d4738  push r10
0000786bc93d473a  push r11
0000786bc93d473c  sub rsp, 0xF0
0000786bc93d4743  vmovaps [rsp], xmm0
0000786bc93d4748  vmovaps [rsp+0x10], xmm1
0000786bc93d474e  vmovaps [rsp+0x20], xmm2
0000786bc93d4754  vmovaps [rsp+0x30], xmm3
0000786bc93d475a  vmovaps [rsp+0x40], xmm4
0000786bc93d4760  vmovaps [rsp+0x50], xmm5
0000786bc93d4766  vmovaps [rsp+0x60], xmm6
0000786bc93d476c  vmovaps [rsp+0x70], xmm7
0000786bc93d4772  vmovaps [rsp+0x80], xmm8
0000786bc93d477b  vmovaps [rsp+0x90], xmm9
0000786bc93d4784  vmovaps [rsp+0xA0], xmm11
0000786bc93d478d  vmovaps [rsp+0xB0], xmm12
0000786bc93d4796  vmovaps [rsp+0xC0], xmm13
0000786bc93d479f  vmovaps [rsp+0xD0], xmm14
0000786bc93d47a8  vmovaps [rsp+0xE0], xmm15
0000786bc93d47b1  sub rsp, 0x30
0000786bc93d47b5  movaps [rsp], xmm10
0000786bc93d47ba  movaps [rsp+0x10], xmm7
0000786bc93d47bf  movaps [rsp+0x20], xmm13
0000786bc93d47c5  lea rdi, [rsp]
0000786bc93d47c9  mov esi, 0x00
0000786bc93d47ce  mov rax, 0x60810F6F7530
0000786bc93d47d8  call rax
0000786bc93d47da  movaps xmm10, [rsp]
0000786bc93d47df  add rsp, 0x30
0000786bc93d47e3  vmovaps xmm0, [rsp]
0000786bc93d47e8  vmovaps xmm1, [rsp+0x10]
0000786bc93d47ee  vmovaps xmm2, [rsp+0x20]
0000786bc93d47f4  vmovaps xmm3, [rsp+0x30]
0000786bc93d47fa  vmovaps xmm4, [rsp+0x40]
0000786bc93d4800  vmovaps xmm5, [rsp+0x50]
0000786bc93d4806  vmovaps xmm6, [rsp+0x60]
0000786bc93d480c  vmovaps xmm7, [rsp+0x70]
0000786bc93d4812  vmovaps xmm8, [rsp+0x80]
0000786bc93d481b  vmovaps xmm9, [rsp+0x90]
0000786bc93d4824  vmovaps xmm11, [rsp+0xA0]
0000786bc93d482d  vmovaps xmm12, [rsp+0xB0]
0000786bc93d4836  vmovaps xmm13, [rsp+0xC0]
0000786bc93d483f  vmovaps xmm14, [rsp+0xD0]
0000786bc93d4848  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4851  add rsp, 0xF0
0000786bc93d4858  pop r11
0000786bc93d485a  pop r10
0000786bc93d485c  pop r9
0000786bc93d485e  pop r8
0000786bc93d4860  pop rsi
0000786bc93d4861  pop rdi
0000786bc93d4862  pop rdx
0000786bc93d4863  pop rcx
0000786bc93d4864  pop rax
0000786bc93d4865  add rsp, 0x08
0000786bc93d4869  jmp 0x0000786BC93D0169
0000786bc93d486e  sub rsp, 0x08
0000786bc93d4872  push rax
0000786bc93d4873  push rcx
0000786bc93d4874  push rdx
0000786bc93d4875  push rdi
0000786bc93d4876  push rsi
0000786bc93d4877  push r8
0000786bc93d4879  push r9
0000786bc93d487b  push r10
0000786bc93d487d  push r11
0000786bc93d487f  sub rsp, 0xF0
0000786bc93d4886  vmovaps [rsp], xmm0
0000786bc93d488b  vmovaps [rsp+0x10], xmm1
0000786bc93d4891  vmovaps [rsp+0x20], xmm2
0000786bc93d4897  vmovaps [rsp+0x30], xmm3
0000786bc93d489d  vmovaps [rsp+0x40], xmm4
0000786bc93d48a3  vmovaps [rsp+0x50], xmm5
0000786bc93d48a9  vmovaps [rsp+0x60], xmm6
0000786bc93d48af  vmovaps [rsp+0x70], xmm7
0000786bc93d48b5  vmovaps [rsp+0x80], xmm8
0000786bc93d48be  vmovaps [rsp+0x90], xmm9
0000786bc93d48c7  vmovaps [rsp+0xA0], xmm10
0000786bc93d48d0  vmovaps [rsp+0xB0], xmm11
0000786bc93d48d9  vmovaps [rsp+0xC0], xmm12
0000786bc93d48e2  vmovaps [rsp+0xD0], xmm14
0000786bc93d48eb  vmovaps [rsp+0xE0], xmm15
0000786bc93d48f4  sub rsp, 0x30
0000786bc93d48f8  movaps [rsp], xmm13
0000786bc93d48fd  movaps [rsp+0x10], xmm1
0000786bc93d4902  movaps [rsp+0x20], xmm8
0000786bc93d4908  lea rdi, [rsp]
0000786bc93d490c  mov esi, 0x00
0000786bc93d4911  mov rax, 0x60810F6F7530
0000786bc93d491b  call rax
0000786bc93d491d  movaps xmm13, [rsp]
0000786bc93d4922  add rsp, 0x30
0000786bc93d4926  vmovaps xmm0, [rsp]
0000786bc93d492b  vmovaps xmm1, [rsp+0x10]
0000786bc93d4931  vmovaps xmm2, [rsp+0x20]
0000786bc93d4937  vmovaps xmm3, [rsp+0x30]
0000786bc93d493d  vmovaps xmm4, [rsp+0x40]
0000786bc93d4943  vmovaps xmm5, [rsp+0x50]
0000786bc93d4949  vmovaps xmm6, [rsp+0x60]
0000786bc93d494f  vmovaps xmm7, [rsp+0x70]
0000786bc93d4955  vmovaps xmm8, [rsp+0x80]
0000786bc93d495e  vmovaps xmm9, [rsp+0x90]
0000786bc93d4967  vmovaps xmm10, [rsp+0xA0]
0000786bc93d4970  vmovaps xmm11, [rsp+0xB0]
0000786bc93d4979  vmovaps xmm12, [rsp+0xC0]
0000786bc93d4982  vmovaps xmm14, [rsp+0xD0]
0000786bc93d498b  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4994  add rsp, 0xF0
0000786bc93d499b  pop r11
0000786bc93d499d  pop r10
0000786bc93d499f  pop r9
0000786bc93d49a1  pop r8
0000786bc93d49a3  pop rsi
0000786bc93d49a4  pop rdi
0000786bc93d49a5  pop rdx
0000786bc93d49a6  pop rcx
0000786bc93d49a7  pop rax
0000786bc93d49a8  add rsp, 0x08
0000786bc93d49ac  jmp 0x0000786BC93D0183
0000786bc93d49b1  call 0x0000786BC91FF430
0000786bc93d49b6  jmp 0x0000786BC93D018D
0000786bc93d49bb  sub rsp, 0x08
0000786bc93d49bf  push rax
0000786bc93d49c0  push rcx
0000786bc93d49c1  push rdx
0000786bc93d49c2  push rdi
0000786bc93d49c3  push rsi
0000786bc93d49c4  push r8
0000786bc93d49c6  push r9
0000786bc93d49c8  push r10
0000786bc93d49ca  push r11
0000786bc93d49cc  sub rsp, 0xF0
0000786bc93d49d3  vmovaps [rsp], xmm0
0000786bc93d49d8  vmovaps [rsp+0x10], xmm1
0000786bc93d49de  vmovaps [rsp+0x20], xmm2
0000786bc93d49e4  vmovaps [rsp+0x30], xmm3
0000786bc93d49ea  vmovaps [rsp+0x40], xmm4
0000786bc93d49f0  vmovaps [rsp+0x50], xmm5
0000786bc93d49f6  vmovaps [rsp+0x60], xmm6
0000786bc93d49fc  vmovaps [rsp+0x70], xmm7
0000786bc93d4a02  vmovaps [rsp+0x80], xmm9
0000786bc93d4a0b  vmovaps [rsp+0x90], xmm10
0000786bc93d4a14  vmovaps [rsp+0xA0], xmm11
0000786bc93d4a1d  vmovaps [rsp+0xB0], xmm12
0000786bc93d4a26  vmovaps [rsp+0xC0], xmm13
0000786bc93d4a2f  vmovaps [rsp+0xD0], xmm14
0000786bc93d4a38  vmovaps [rsp+0xE0], xmm15
0000786bc93d4a41  sub rsp, 0x30
0000786bc93d4a45  movaps [rsp], xmm8
0000786bc93d4a4a  movaps [rsp+0x10], xmm14
0000786bc93d4a50  movaps [rsp+0x20], xmm9
0000786bc93d4a56  lea rdi, [rsp]
0000786bc93d4a5a  mov esi, 0x00
0000786bc93d4a5f  mov rax, 0x60810F6F7530
0000786bc93d4a69  call rax
0000786bc93d4a6b  movaps xmm8, [rsp]
0000786bc93d4a70  add rsp, 0x30
0000786bc93d4a74  vmovaps xmm0, [rsp]
0000786bc93d4a79  vmovaps xmm1, [rsp+0x10]
0000786bc93d4a7f  vmovaps xmm2, [rsp+0x20]
0000786bc93d4a85  vmovaps xmm3, [rsp+0x30]
0000786bc93d4a8b  vmovaps xmm4, [rsp+0x40]
0000786bc93d4a91  vmovaps xmm5, [rsp+0x50]
0000786bc93d4a97  vmovaps xmm6, [rsp+0x60]
0000786bc93d4a9d  vmovaps xmm7, [rsp+0x70]
0000786bc93d4aa3  vmovaps xmm9, [rsp+0x80]
0000786bc93d4aac  vmovaps xmm10, [rsp+0x90]
0000786bc93d4ab5  vmovaps xmm11, [rsp+0xA0]
0000786bc93d4abe  vmovaps xmm12, [rsp+0xB0]
0000786bc93d4ac7  vmovaps xmm13, [rsp+0xC0]
0000786bc93d4ad0  vmovaps xmm14, [rsp+0xD0]
0000786bc93d4ad9  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4ae2  add rsp, 0xF0
0000786bc93d4ae9  pop r11
0000786bc93d4aeb  pop r10
0000786bc93d4aed  pop r9
0000786bc93d4aef  pop r8
0000786bc93d4af1  pop rsi
0000786bc93d4af2  pop rdi
0000786bc93d4af3  pop rdx
0000786bc93d4af4  pop rcx
0000786bc93d4af5  pop rax
0000786bc93d4af6  add rsp, 0x08
0000786bc93d4afa  jmp 0x0000786BC93D01AF
0000786bc93d4aff  sub rsp, 0x08
0000786bc93d4b03  push rax
0000786bc93d4b04  push rcx
0000786bc93d4b05  push rdx
0000786bc93d4b06  push rdi
0000786bc93d4b07  push rsi
0000786bc93d4b08  push r8
0000786bc93d4b0a  push r9
0000786bc93d4b0c  push r10
0000786bc93d4b0e  push r11
0000786bc93d4b10  sub rsp, 0xF0
0000786bc93d4b17  vmovaps [rsp], xmm0
0000786bc93d4b1c  vmovaps [rsp+0x10], xmm1
0000786bc93d4b22  vmovaps [rsp+0x20], xmm2
0000786bc93d4b28  vmovaps [rsp+0x30], xmm3
0000786bc93d4b2e  vmovaps [rsp+0x40], xmm4
0000786bc93d4b34  vmovaps [rsp+0x50], xmm5
0000786bc93d4b3a  vmovaps [rsp+0x60], xmm6
0000786bc93d4b40  vmovaps [rsp+0x70], xmm7
0000786bc93d4b46  vmovaps [rsp+0x80], xmm8
0000786bc93d4b4f  vmovaps [rsp+0x90], xmm10
0000786bc93d4b58  vmovaps [rsp+0xA0], xmm11
0000786bc93d4b61  vmovaps [rsp+0xB0], xmm12
0000786bc93d4b6a  vmovaps [rsp+0xC0], xmm13
0000786bc93d4b73  vmovaps [rsp+0xD0], xmm14
0000786bc93d4b7c  vmovaps [rsp+0xE0], xmm15
0000786bc93d4b85  sub rsp, 0x30
0000786bc93d4b89  movaps [rsp], xmm9
0000786bc93d4b8e  movaps [rsp+0x10], xmm1
0000786bc93d4b93  movaps [rsp+0x20], xmm14
0000786bc93d4b99  lea rdi, [rsp]
0000786bc93d4b9d  mov esi, 0x00
0000786bc93d4ba2  mov rax, 0x60810F6F7530
0000786bc93d4bac  call rax
0000786bc93d4bae  movaps xmm9, [rsp]
0000786bc93d4bb3  add rsp, 0x30
0000786bc93d4bb7  vmovaps xmm0, [rsp]
0000786bc93d4bbc  vmovaps xmm1, [rsp+0x10]
0000786bc93d4bc2  vmovaps xmm2, [rsp+0x20]
0000786bc93d4bc8  vmovaps xmm3, [rsp+0x30]
0000786bc93d4bce  vmovaps xmm4, [rsp+0x40]
0000786bc93d4bd4  vmovaps xmm5, [rsp+0x50]
0000786bc93d4bda  vmovaps xmm6, [rsp+0x60]
0000786bc93d4be0  vmovaps xmm7, [rsp+0x70]
0000786bc93d4be6  vmovaps xmm8, [rsp+0x80]
0000786bc93d4bef  vmovaps xmm10, [rsp+0x90]
0000786bc93d4bf8  vmovaps xmm11, [rsp+0xA0]
0000786bc93d4c01  vmovaps xmm12, [rsp+0xB0]
0000786bc93d4c0a  vmovaps xmm13, [rsp+0xC0]
0000786bc93d4c13  vmovaps xmm14, [rsp+0xD0]
0000786bc93d4c1c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4c25  add rsp, 0xF0
0000786bc93d4c2c  pop r11
0000786bc93d4c2e  pop r10
0000786bc93d4c30  pop r9
0000786bc93d4c32  pop r8
0000786bc93d4c34  pop rsi
0000786bc93d4c35  pop rdi
0000786bc93d4c36  pop rdx
0000786bc93d4c37  pop rcx
0000786bc93d4c38  pop rax
0000786bc93d4c39  add rsp, 0x08
0000786bc93d4c3d  jmp 0x0000786BC93D01DD
0000786bc93d4c42  sub rsp, 0x08
0000786bc93d4c46  push rax
0000786bc93d4c47  push rcx
0000786bc93d4c48  push rdx
0000786bc93d4c49  push rdi
0000786bc93d4c4a  push rsi
0000786bc93d4c4b  push r8
0000786bc93d4c4d  push r9
0000786bc93d4c4f  push r10
0000786bc93d4c51  push r11
0000786bc93d4c53  sub rsp, 0xF0
0000786bc93d4c5a  vmovaps [rsp], xmm0
0000786bc93d4c5f  vmovaps [rsp+0x10], xmm1
0000786bc93d4c65  vmovaps [rsp+0x20], xmm2
0000786bc93d4c6b  vmovaps [rsp+0x30], xmm3
0000786bc93d4c71  vmovaps [rsp+0x40], xmm4
0000786bc93d4c77  vmovaps [rsp+0x50], xmm5
0000786bc93d4c7d  vmovaps [rsp+0x60], xmm6
0000786bc93d4c83  vmovaps [rsp+0x70], xmm7
0000786bc93d4c89  vmovaps [rsp+0x80], xmm8
0000786bc93d4c92  vmovaps [rsp+0x90], xmm9
0000786bc93d4c9b  vmovaps [rsp+0xA0], xmm10
0000786bc93d4ca4  vmovaps [rsp+0xB0], xmm11
0000786bc93d4cad  vmovaps [rsp+0xC0], xmm12
0000786bc93d4cb6  vmovaps [rsp+0xD0], xmm13
0000786bc93d4cbf  vmovaps [rsp+0xE0], xmm15
0000786bc93d4cc8  sub rsp, 0x30
0000786bc93d4ccc  movaps [rsp], xmm14
0000786bc93d4cd1  movaps [rsp+0x10], xmm4
0000786bc93d4cd6  movaps [rsp+0x20], xmm1
0000786bc93d4cdb  lea rdi, [rsp]
0000786bc93d4cdf  mov esi, 0x00
0000786bc93d4ce4  mov rax, 0x60810F6F7530
0000786bc93d4cee  call rax
0000786bc93d4cf0  movaps xmm14, [rsp]
0000786bc93d4cf5  add rsp, 0x30
0000786bc93d4cf9  vmovaps xmm0, [rsp]
0000786bc93d4cfe  vmovaps xmm1, [rsp+0x10]
0000786bc93d4d04  vmovaps xmm2, [rsp+0x20]
0000786bc93d4d0a  vmovaps xmm3, [rsp+0x30]
0000786bc93d4d10  vmovaps xmm4, [rsp+0x40]
0000786bc93d4d16  vmovaps xmm5, [rsp+0x50]
0000786bc93d4d1c  vmovaps xmm6, [rsp+0x60]
0000786bc93d4d22  vmovaps xmm7, [rsp+0x70]
0000786bc93d4d28  vmovaps xmm8, [rsp+0x80]
0000786bc93d4d31  vmovaps xmm9, [rsp+0x90]
0000786bc93d4d3a  vmovaps xmm10, [rsp+0xA0]
0000786bc93d4d43  vmovaps xmm11, [rsp+0xB0]
0000786bc93d4d4c  vmovaps xmm12, [rsp+0xC0]
0000786bc93d4d55  vmovaps xmm13, [rsp+0xD0]
0000786bc93d4d5e  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4d67  add rsp, 0xF0
0000786bc93d4d6e  pop r11
0000786bc93d4d70  pop r10
0000786bc93d4d72  pop r9
0000786bc93d4d74  pop r8
0000786bc93d4d76  pop rsi
0000786bc93d4d77  pop rdi
0000786bc93d4d78  pop rdx
0000786bc93d4d79  pop rcx
0000786bc93d4d7a  pop rax
0000786bc93d4d7b  add rsp, 0x08
0000786bc93d4d7f  jmp 0x0000786BC93D0203
0000786bc93d4d84  sub rsp, 0x08
0000786bc93d4d88  push rax
0000786bc93d4d89  push rcx
0000786bc93d4d8a  push rdx
0000786bc93d4d8b  push rdi
0000786bc93d4d8c  push rsi
0000786bc93d4d8d  push r8
0000786bc93d4d8f  push r9
0000786bc93d4d91  push r10
0000786bc93d4d93  push r11
0000786bc93d4d95  sub rsp, 0xF0
0000786bc93d4d9c  vmovaps [rsp], xmm0
0000786bc93d4da1  vmovaps [rsp+0x10], xmm2
0000786bc93d4da7  vmovaps [rsp+0x20], xmm3
0000786bc93d4dad  vmovaps [rsp+0x30], xmm4
0000786bc93d4db3  vmovaps [rsp+0x40], xmm5
0000786bc93d4db9  vmovaps [rsp+0x50], xmm6
0000786bc93d4dbf  vmovaps [rsp+0x60], xmm7
0000786bc93d4dc5  vmovaps [rsp+0x70], xmm8
0000786bc93d4dcb  vmovaps [rsp+0x80], xmm9
0000786bc93d4dd4  vmovaps [rsp+0x90], xmm10
0000786bc93d4ddd  vmovaps [rsp+0xA0], xmm11
0000786bc93d4de6  vmovaps [rsp+0xB0], xmm12
0000786bc93d4def  vmovaps [rsp+0xC0], xmm13
0000786bc93d4df8  vmovaps [rsp+0xD0], xmm14
0000786bc93d4e01  vmovaps [rsp+0xE0], xmm15
0000786bc93d4e0a  sub rsp, 0x30
0000786bc93d4e0e  movaps [rsp], xmm1
0000786bc93d4e12  movaps [rsp+0x10], xmm12
0000786bc93d4e18  movaps [rsp+0x20], xmm11
0000786bc93d4e1e  lea rdi, [rsp]
0000786bc93d4e22  mov esi, 0x00
0000786bc93d4e27  mov rax, 0x60810F6F7530
0000786bc93d4e31  call rax
0000786bc93d4e33  movaps xmm1, [rsp]
0000786bc93d4e37  add rsp, 0x30
0000786bc93d4e3b  vmovaps xmm0, [rsp]
0000786bc93d4e40  vmovaps xmm2, [rsp+0x10]
0000786bc93d4e46  vmovaps xmm3, [rsp+0x20]
0000786bc93d4e4c  vmovaps xmm4, [rsp+0x30]
0000786bc93d4e52  vmovaps xmm5, [rsp+0x40]
0000786bc93d4e58  vmovaps xmm6, [rsp+0x50]
0000786bc93d4e5e  vmovaps xmm7, [rsp+0x60]
0000786bc93d4e64  vmovaps xmm8, [rsp+0x70]
0000786bc93d4e6a  vmovaps xmm9, [rsp+0x80]
0000786bc93d4e73  vmovaps xmm10, [rsp+0x90]
0000786bc93d4e7c  vmovaps xmm11, [rsp+0xA0]
0000786bc93d4e85  vmovaps xmm12, [rsp+0xB0]
0000786bc93d4e8e  vmovaps xmm13, [rsp+0xC0]
0000786bc93d4e97  vmovaps xmm14, [rsp+0xD0]
0000786bc93d4ea0  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4ea9  add rsp, 0xF0
0000786bc93d4eb0  pop r11
0000786bc93d4eb2  pop r10
0000786bc93d4eb4  pop r9
0000786bc93d4eb6  pop r8
0000786bc93d4eb8  pop rsi
0000786bc93d4eb9  pop rdi
0000786bc93d4eba  pop rdx
0000786bc93d4ebb  pop rcx
0000786bc93d4ebc  pop rax
0000786bc93d4ebd  add rsp, 0x08
0000786bc93d4ec1  jmp 0x0000786BC93D0224
0000786bc93d4ec6  call 0x0000786BC92E20A0
0000786bc93d4ecb  jmp 0x0000786BC93D0232
0000786bc93d4ed0  call 0x0000786BC9209D70
0000786bc93d4ed5  jmp 0x0000786BC93D023C
0000786bc93d4eda  sub rsp, 0x08
0000786bc93d4ede  push rax
0000786bc93d4edf  push rcx
0000786bc93d4ee0  push rdx
0000786bc93d4ee1  push rdi
0000786bc93d4ee2  push rsi
0000786bc93d4ee3  push r8
0000786bc93d4ee5  push r9
0000786bc93d4ee7  push r10
0000786bc93d4ee9  push r11
0000786bc93d4eeb  sub rsp, 0xF0
0000786bc93d4ef2  vmovaps [rsp], xmm0
0000786bc93d4ef7  vmovaps [rsp+0x10], xmm1
0000786bc93d4efd  vmovaps [rsp+0x20], xmm2
0000786bc93d4f03  vmovaps [rsp+0x30], xmm3
0000786bc93d4f09  vmovaps [rsp+0x40], xmm4
0000786bc93d4f0f  vmovaps [rsp+0x50], xmm5
0000786bc93d4f15  vmovaps [rsp+0x60], xmm6
0000786bc93d4f1b  vmovaps [rsp+0x70], xmm8
0000786bc93d4f21  vmovaps [rsp+0x80], xmm9
0000786bc93d4f2a  vmovaps [rsp+0x90], xmm10
0000786bc93d4f33  vmovaps [rsp+0xA0], xmm11
0000786bc93d4f3c  vmovaps [rsp+0xB0], xmm12
0000786bc93d4f45  vmovaps [rsp+0xC0], xmm13
0000786bc93d4f4e  vmovaps [rsp+0xD0], xmm14
0000786bc93d4f57  vmovaps [rsp+0xE0], xmm15
0000786bc93d4f60  sub rsp, 0x30
0000786bc93d4f64  movaps [rsp], xmm7
0000786bc93d4f68  movaps [rsp+0x10], xmm15
0000786bc93d4f6e  movaps [rsp+0x20], xmm10
0000786bc93d4f74  lea rdi, [rsp]
0000786bc93d4f78  mov esi, 0x00
0000786bc93d4f7d  mov rax, 0x60810F6F7530
0000786bc93d4f87  call rax
0000786bc93d4f89  movaps xmm7, [rsp]
0000786bc93d4f8d  add rsp, 0x30
0000786bc93d4f91  vmovaps xmm0, [rsp]
0000786bc93d4f96  vmovaps xmm1, [rsp+0x10]
0000786bc93d4f9c  vmovaps xmm2, [rsp+0x20]
0000786bc93d4fa2  vmovaps xmm3, [rsp+0x30]
0000786bc93d4fa8  vmovaps xmm4, [rsp+0x40]
0000786bc93d4fae  vmovaps xmm5, [rsp+0x50]
0000786bc93d4fb4  vmovaps xmm6, [rsp+0x60]
0000786bc93d4fba  vmovaps xmm8, [rsp+0x70]
0000786bc93d4fc0  vmovaps xmm9, [rsp+0x80]
0000786bc93d4fc9  vmovaps xmm10, [rsp+0x90]
0000786bc93d4fd2  vmovaps xmm11, [rsp+0xA0]
0000786bc93d4fdb  vmovaps xmm12, [rsp+0xB0]
0000786bc93d4fe4  vmovaps xmm13, [rsp+0xC0]
0000786bc93d4fed  vmovaps xmm14, [rsp+0xD0]
0000786bc93d4ff6  vmovaps xmm15, [rsp+0xE0]
0000786bc93d4fff  add rsp, 0xF0
0000786bc93d5006  pop r11
0000786bc93d5008  pop r10
0000786bc93d500a  pop r9
0000786bc93d500c  pop r8
0000786bc93d500e  pop rsi
0000786bc93d500f  pop rdi
0000786bc93d5010  pop rdx
0000786bc93d5011  pop rcx
0000786bc93d5012  pop rax
0000786bc93d5013  add rsp, 0x08
0000786bc93d5017  jmp 0x0000786BC93D025D
0000786bc93d501c  sub rsp, 0x08
0000786bc93d5020  push rax
0000786bc93d5021  push rcx
0000786bc93d5022  push rdx
0000786bc93d5023  push rdi
0000786bc93d5024  push rsi
0000786bc93d5025  push r8
0000786bc93d5027  push r9
0000786bc93d5029  push r10
0000786bc93d502b  push r11
0000786bc93d502d  sub rsp, 0xF0
0000786bc93d5034  vmovaps [rsp], xmm0
0000786bc93d5039  vmovaps [rsp+0x10], xmm1
0000786bc93d503f  vmovaps [rsp+0x20], xmm2
0000786bc93d5045  vmovaps [rsp+0x30], xmm3
0000786bc93d504b  vmovaps [rsp+0x40], xmm4
0000786bc93d5051  vmovaps [rsp+0x50], xmm5
0000786bc93d5057  vmovaps [rsp+0x60], xmm6
0000786bc93d505d  vmovaps [rsp+0x70], xmm7
0000786bc93d5063  vmovaps [rsp+0x80], xmm8
0000786bc93d506c  vmovaps [rsp+0x90], xmm9
0000786bc93d5075  vmovaps [rsp+0xA0], xmm11
0000786bc93d507e  vmovaps [rsp+0xB0], xmm12
0000786bc93d5087  vmovaps [rsp+0xC0], xmm13
0000786bc93d5090  vmovaps [rsp+0xD0], xmm14
0000786bc93d5099  vmovaps [rsp+0xE0], xmm15
0000786bc93d50a2  sub rsp, 0x30
0000786bc93d50a6  movaps [rsp], xmm10
0000786bc93d50ab  movaps [rsp+0x10], xmm11
0000786bc93d50b1  movaps [rsp+0x20], xmm15
0000786bc93d50b7  lea rdi, [rsp]
0000786bc93d50bb  mov esi, 0x00
0000786bc93d50c0  mov rax, 0x60810F6F7530
0000786bc93d50ca  call rax
0000786bc93d50cc  movaps xmm10, [rsp]
0000786bc93d50d1  add rsp, 0x30
0000786bc93d50d5  vmovaps xmm0, [rsp]
0000786bc93d50da  vmovaps xmm1, [rsp+0x10]
0000786bc93d50e0  vmovaps xmm2, [rsp+0x20]
0000786bc93d50e6  vmovaps xmm3, [rsp+0x30]
0000786bc93d50ec  vmovaps xmm4, [rsp+0x40]
0000786bc93d50f2  vmovaps xmm5, [rsp+0x50]
0000786bc93d50f8  vmovaps xmm6, [rsp+0x60]
0000786bc93d50fe  vmovaps xmm7, [rsp+0x70]
0000786bc93d5104  vmovaps xmm8, [rsp+0x80]
0000786bc93d510d  vmovaps xmm9, [rsp+0x90]
0000786bc93d5116  vmovaps xmm11, [rsp+0xA0]
0000786bc93d511f  vmovaps xmm12, [rsp+0xB0]
0000786bc93d5128  vmovaps xmm13, [rsp+0xC0]
0000786bc93d5131  vmovaps xmm14, [rsp+0xD0]
0000786bc93d513a  vmovaps xmm15, [rsp+0xE0]
0000786bc93d5143  add rsp, 0xF0
0000786bc93d514a  pop r11
0000786bc93d514c  pop r10
0000786bc93d514e  pop r9
0000786bc93d5150  pop r8
0000786bc93d5152  pop rsi
0000786bc93d5153  pop rdi
0000786bc93d5154  pop rdx
0000786bc93d5155  pop rcx
0000786bc93d5156  pop rax
0000786bc93d5157  add rsp, 0x08
0000786bc93d515b  jmp 0x0000786BC93D028B
0000786bc93d5160  sub rsp, 0x08
0000786bc93d5164  push rax
0000786bc93d5165  push rcx
0000786bc93d5166  push rdx
0000786bc93d5167  push rdi
0000786bc93d5168  push rsi
0000786bc93d5169  push r8
0000786bc93d516b  push r9
0000786bc93d516d  push r10
0000786bc93d516f  push r11
0000786bc93d5171  sub rsp, 0xF0
0000786bc93d5178  vmovaps [rsp], xmm0
0000786bc93d517d  vmovaps [rsp+0x10], xmm1
0000786bc93d5183  vmovaps [rsp+0x20], xmm2
0000786bc93d5189  vmovaps [rsp+0x30], xmm3
0000786bc93d518f  vmovaps [rsp+0x40], xmm4
0000786bc93d5195  vmovaps [rsp+0x50], xmm5
0000786bc93d519b  vmovaps [rsp+0x60], xmm6
0000786bc93d51a1  vmovaps [rsp+0x70], xmm7
0000786bc93d51a7  vmovaps [rsp+0x80], xmm8
0000786bc93d51b0  vmovaps [rsp+0x90], xmm9
0000786bc93d51b9  vmovaps [rsp+0xA0], xmm10
0000786bc93d51c2  vmovaps [rsp+0xB0], xmm12
0000786bc93d51cb  vmovaps [rsp+0xC0], xmm13
0000786bc93d51d4  vmovaps [rsp+0xD0], xmm14
0000786bc93d51dd  vmovaps [rsp+0xE0], xmm15
0000786bc93d51e6  sub rsp, 0x30
0000786bc93d51ea  movaps [rsp], xmm11
0000786bc93d51ef  movaps [rsp+0x10], xmm12
0000786bc93d51f5  movaps [rsp+0x20], xmm15
0000786bc93d51fb  lea rdi, [rsp]
0000786bc93d51ff  mov esi, 0x00
0000786bc93d5204  mov rax, 0x60810F6F7530
0000786bc93d520e  call rax
0000786bc93d5210  movaps xmm11, [rsp]
0000786bc93d5215  add rsp, 0x30
0000786bc93d5219  vmovaps xmm0, [rsp]
0000786bc93d521e  vmovaps xmm1, [rsp+0x10]
0000786bc93d5224  vmovaps xmm2, [rsp+0x20]
0000786bc93d522a  vmovaps xmm3, [rsp+0x30]
0000786bc93d5230  vmovaps xmm4, [rsp+0x40]
0000786bc93d5236  vmovaps xmm5, [rsp+0x50]
0000786bc93d523c  vmovaps xmm6, [rsp+0x60]
0000786bc93d5242  vmovaps xmm7, [rsp+0x70]
0000786bc93d5248  vmovaps xmm8, [rsp+0x80]
0000786bc93d5251  vmovaps xmm9, [rsp+0x90]
0000786bc93d525a  vmovaps xmm10, [rsp+0xA0]
0000786bc93d5263  vmovaps xmm12, [rsp+0xB0]
0000786bc93d526c  vmovaps xmm13, [rsp+0xC0]
0000786bc93d5275  vmovaps xmm14, [rsp+0xD0]
0000786bc93d527e  vmovaps xmm15, [rsp+0xE0]
0000786bc93d5287  add rsp, 0xF0
0000786bc93d528e  pop r11
0000786bc93d5290  pop r10
0000786bc93d5292  pop r9
0000786bc93d5294  pop r8
0000786bc93d5296  pop rsi
0000786bc93d5297  pop rdi
0000786bc93d5298  pop rdx
0000786bc93d5299  pop rcx
0000786bc93d529a  pop rax
0000786bc93d529b  add rsp, 0x08
0000786bc93d529f  jmp 0x0000786BC93D02B9
0000786bc93d52a4  sub rsp, 0x08
0000786bc93d52a8  push rax
0000786bc93d52a9  push rcx
0000786bc93d52aa  push rdx
0000786bc93d52ab  push rdi
0000786bc93d52ac  push rsi
0000786bc93d52ad  push r8
0000786bc93d52af  push r9
0000786bc93d52b1  push r10
0000786bc93d52b3  push r11
0000786bc93d52b5  sub rsp, 0xF0
0000786bc93d52bc  vmovaps [rsp], xmm0
0000786bc93d52c1  vmovaps [rsp+0x10], xmm1
0000786bc93d52c7  vmovaps [rsp+0x20], xmm2
0000786bc93d52cd  vmovaps [rsp+0x30], xmm3
0000786bc93d52d3  vmovaps [rsp+0x40], xmm4
0000786bc93d52d9  vmovaps [rsp+0x50], xmm5
0000786bc93d52df  vmovaps [rsp+0x60], xmm6
0000786bc93d52e5  vmovaps [rsp+0x70], xmm7
0000786bc93d52eb  vmovaps [rsp+0x80], xmm8
0000786bc93d52f4  vmovaps [rsp+0x90], xmm9
0000786bc93d52fd  vmovaps [rsp+0xA0], xmm10
0000786bc93d5306  vmovaps [rsp+0xB0], xmm11
0000786bc93d530f  vmovaps [rsp+0xC0], xmm12
0000786bc93d5318  vmovaps [rsp+0xD0], xmm13
0000786bc93d5321  vmovaps [rsp+0xE0], xmm14
0000786bc93d532a  sub rsp, 0x30
0000786bc93d532e  movaps [rsp], xmm15
0000786bc93d5333  movaps [rsp+0x10], xmm13
0000786bc93d5339  movaps [rsp+0x20], xmm9
0000786bc93d533f  lea rdi, [rsp]
0000786bc93d5343  mov esi, 0x00
0000786bc93d5348  mov rax, 0x60810F6F7530
0000786bc93d5352  call rax
0000786bc93d5354  movaps xmm15, [rsp]
0000786bc93d5359  add rsp, 0x30
0000786bc93d535d  vmovaps xmm0, [rsp]
0000786bc93d5362  vmovaps xmm1, [rsp+0x10]
0000786bc93d5368  vmovaps xmm2, [rsp+0x20]
0000786bc93d536e  vmovaps xmm3, [rsp+0x30]
0000786bc93d5374  vmovaps xmm4, [rsp+0x40]
0000786bc93d537a  vmovaps xmm5, [rsp+0x50]
0000786bc93d5380  vmovaps xmm6, [rsp+0x60]
0000786bc93d5386  vmovaps xmm7, [rsp+0x70]
0000786bc93d538c  vmovaps xmm8, [rsp+0x80]
0000786bc93d5395  vmovaps xmm9, [rsp+0x90]
0000786bc93d539e  vmovaps xmm10, [rsp+0xA0]
0000786bc93d53a7  vmovaps xmm11, [rsp+0xB0]
0000786bc93d53b0  vmovaps xmm12, [rsp+0xC0]
0000786bc93d53b9  vmovaps xmm13, [rsp+0xD0]
0000786bc93d53c2  vmovaps xmm14, [rsp+0xE0]
0000786bc93d53cb  add rsp, 0xF0
0000786bc93d53d2  pop r11
0000786bc93d53d4  pop r10
0000786bc93d53d6  pop r9
0000786bc93d53d8  pop r8
0000786bc93d53da  pop rsi
0000786bc93d53db  pop rdi
0000786bc93d53dc  pop rdx
0000786bc93d53dd  pop rcx
0000786bc93d53de  pop rax
0000786bc93d53df  add rsp, 0x08
0000786bc93d53e3  jmp 0x0000786BC93D02D4
0000786bc93d53e8  sub rsp, 0x08
0000786bc93d53ec  push rax
0000786bc93d53ed  push rcx
0000786bc93d53ee  push rdx
0000786bc93d53ef  push rdi
0000786bc93d53f0  push rsi
0000786bc93d53f1  push r8
0000786bc93d53f3  push r9
0000786bc93d53f5  push r10
0000786bc93d53f7  push r11
0000786bc93d53f9  sub rsp, 0xF0
0000786bc93d5400  vmovaps [rsp], xmm0
0000786bc93d5405  vmovaps [rsp+0x10], xmm1
0000786bc93d540b  vmovaps [rsp+0x20], xmm2
0000786bc93d5411  vmovaps [rsp+0x30], xmm3
0000786bc93d5417  vmovaps [rsp+0x40], xmm4
0000786bc93d541d  vmovaps [rsp+0x50], xmm5
0000786bc93d5423  vmovaps [rsp+0x60], xmm6
0000786bc93d5429  vmovaps [rsp+0x70], xmm7
0000786bc93d542f  vmovaps [rsp+0x80], xmm8
0000786bc93d5438  vmovaps [rsp+0x90], xmm9
0000786bc93d5441  vmovaps [rsp+0xA0], xmm10
0000786bc93d544a  vmovaps [rsp+0xB0], xmm11
0000786bc93d5453  vmovaps [rsp+0xC0], xmm12
0000786bc93d545c  vmovaps [rsp+0xD0], xmm14
0000786bc93d5465  vmovaps [rsp+0xE0], xmm15
0000786bc93d546e  sub rsp, 0x30
0000786bc93d5472  movaps [rsp], xmm13
0000786bc93d5477  movaps [rsp+0x10], xmm8
0000786bc93d547d  movaps [rsp+0x20], xmm14
0000786bc93d5483  lea rdi, [rsp]
0000786bc93d5487  mov esi, 0x00
0000786bc93d548c  mov rax, 0x60810F6F7530
0000786bc93d5496  call rax
0000786bc93d5498  movaps xmm13, [rsp]
0000786bc93d549d  add rsp, 0x30
0000786bc93d54a1  vmovaps xmm0, [rsp]
0000786bc93d54a6  vmovaps xmm1, [rsp+0x10]
0000786bc93d54ac  vmovaps xmm2, [rsp+0x20]
0000786bc93d54b2  vmovaps xmm3, [rsp+0x30]
0000786bc93d54b8  vmovaps xmm4, [rsp+0x40]
0000786bc93d54be  vmovaps xmm5, [rsp+0x50]
0000786bc93d54c4  vmovaps xmm6, [rsp+0x60]
0000786bc93d54ca  vmovaps xmm7, [rsp+0x70]
0000786bc93d54d0  vmovaps xmm8, [rsp+0x80]
0000786bc93d54d9  vmovaps xmm9, [rsp+0x90]
0000786bc93d54e2  vmovaps xmm10, [rsp+0xA0]
0000786bc93d54eb  vmovaps xmm11, [rsp+0xB0]
0000786bc93d54f4  vmovaps xmm12, [rsp+0xC0]
0000786bc93d54fd  vmovaps xmm14, [rsp+0xD0]
0000786bc93d5506  vmovaps xmm15, [rsp+0xE0]
0000786bc93d550f  add rsp, 0xF0
0000786bc93d5516  pop r11
0000786bc93d5518  pop r10
0000786bc93d551a  pop r9
0000786bc93d551c  pop r8
0000786bc93d551e  pop rsi
0000786bc93d551f  pop rdi
0000786bc93d5520  pop rdx
0000786bc93d5521  pop rcx
0000786bc93d5522  pop rax
0000786bc93d5523  add rsp, 0x08
0000786bc93d5527  jmp 0x0000786BC93D02F7
0000786bc93d552c  sub rsp, 0x08
0000786bc93d5530  push rax
0000786bc93d5531  push rcx
0000786bc93d5532  push rdx
0000786bc93d5533  push rdi
0000786bc93d5534  push rsi
0000786bc93d5535  push r8
0000786bc93d5537  push r9
0000786bc93d5539  push r10
0000786bc93d553b  push r11
0000786bc93d553d  sub rsp, 0xF0
0000786bc93d5544  vmovaps [rsp], xmm0
0000786bc93d5549  vmovaps [rsp+0x10], xmm1
0000786bc93d554f  vmovaps [rsp+0x20], xmm2
0000786bc93d5555  vmovaps [rsp+0x30], xmm3
0000786bc93d555b  vmovaps [rsp+0x40], xmm4
0000786bc93d5561  vmovaps [rsp+0x50], xmm5
0000786bc93d5567  vmovaps [rsp+0x60], xmm6
0000786bc93d556d  vmovaps [rsp+0x70], xmm7
0000786bc93d5573  vmovaps [rsp+0x80], xmm8
0000786bc93d557c  vmovaps [rsp+0x90], xmm9
0000786bc93d5585  vmovaps [rsp+0xA0], xmm10
0000786bc93d558e  vmovaps [rsp+0xB0], xmm11
0000786bc93d5597  vmovaps [rsp+0xC0], xmm12
0000786bc93d55a0  vmovaps [rsp+0xD0], xmm13
0000786bc93d55a9  vmovaps [rsp+0xE0], xmm15
0000786bc93d55b2  sub rsp, 0x30
0000786bc93d55b6  movaps [rsp], xmm14
0000786bc93d55bb  movaps [rsp+0x10], xmm1
0000786bc93d55c0  movaps [rsp+0x20], xmm10
0000786bc93d55c6  lea rdi, [rsp]
0000786bc93d55ca  mov esi, 0x00
0000786bc93d55cf  mov rax, 0x60810F6F7530
0000786bc93d55d9  call rax
0000786bc93d55db  movaps xmm14, [rsp]
0000786bc93d55e0  add rsp, 0x30
0000786bc93d55e4  vmovaps xmm0, [rsp]
0000786bc93d55e9  vmovaps xmm1, [rsp+0x10]
0000786bc93d55ef  vmovaps xmm2, [rsp+0x20]
0000786bc93d55f5  vmovaps xmm3, [rsp+0x30]
0000786bc93d55fb  vmovaps xmm4, [rsp+0x40]
0000786bc93d5601  vmovaps xmm5, [rsp+0x50]
0000786bc93d5607  vmovaps xmm6, [rsp+0x60]
0000786bc93d560d  vmovaps xmm7, [rsp+0x70]
0000786bc93d5613  vmovaps xmm8, [rsp+0x80]
0000786bc93d561c  vmovaps xmm9, [rsp+0x90]
0000786bc93d5625  vmovaps xmm10, [rsp+0xA0]
0000786bc93d562e  vmovaps xmm11, [rsp+0xB0]
0000786bc93d5637  vmovaps xmm12, [rsp+0xC0]
0000786bc93d5640  vmovaps xmm13, [rsp+0xD0]
0000786bc93d5649  vmovaps xmm15, [rsp+0xE0]
0000786bc93d5652  add rsp, 0xF0
0000786bc93d5659  pop r11
0000786bc93d565b  pop r10
0000786bc93d565d  pop r9
0000786bc93d565f  pop r8
0000786bc93d5661  pop rsi
0000786bc93d5662  pop rdi
0000786bc93d5663  pop rdx
0000786bc93d5664  pop rcx
0000786bc93d5665  pop rax
0000786bc93d5666  add rsp, 0x08
0000786bc93d566a  jmp 0x0000786BC93D031A
0000786bc93d566f  sub rsp, 0x08
0000786bc93d5673  push rax
0000786bc93d5674  push rcx
0000786bc93d5675  push rdx
0000786bc93d5676  push rdi
0000786bc93d5677  push rsi
0000786bc93d5678  push r8
0000786bc93d567a  push r9
0000786bc93d567c  push r10
0000786bc93d567e  push r11
0000786bc93d5680  sub rsp, 0xF0
0000786bc93d5687  vmovaps [rsp], xmm0
0000786bc93d568c  vmovaps [rsp+0x10], xmm2
0000786bc93d5692  vmovaps [rsp+0x20], xmm3
0000786bc93d5698  vmovaps [rsp+0x30], xmm4
0000786bc93d569e  vmovaps [rsp+0x40], xmm5
0000786bc93d56a4  vmovaps [rsp+0x50], xmm6
0000786bc93d56aa  vmovaps [rsp+0x60], xmm7
0000786bc93d56b0  vmovaps [rsp+0x70], xmm8
0000786bc93d56b6  vmovaps [rsp+0x80], xmm9
0000786bc93d56bf  vmovaps [rsp+0x90], xmm10
0000786bc93d56c8  vmovaps [rsp+0xA0], xmm11
0000786bc93d56d1  vmovaps [rsp+0xB0], xmm12
0000786bc93d56da  vmovaps [rsp+0xC0], xmm13
0000786bc93d56e3  vmovaps [rsp+0xD0], xmm14
0000786bc93d56ec  vmovaps [rsp+0xE0], xmm15
0000786bc93d56f5  sub rsp, 0x30
0000786bc93d56f9  movaps [rsp], xmm1
0000786bc93d56fd  movaps [rsp+0x10], xmm7
0000786bc93d5702  movaps [rsp+0x20], xmm11
0000786bc93d5708  lea rdi, [rsp]
0000786bc93d570c  mov esi, 0x00
0000786bc93d5711  mov rax, 0x60810F6F7530
0000786bc93d571b  call rax
0000786bc93d571d  movaps xmm1, [rsp]
0000786bc93d5721  add rsp, 0x30
0000786bc93d5725  vmovaps xmm0, [rsp]
0000786bc93d572a  vmovaps xmm2, [rsp+0x10]
0000786bc93d5730  vmovaps xmm3, [rsp+0x20]
0000786bc93d5736  vmovaps xmm4, [rsp+0x30]
0000786bc93d573c  vmovaps xmm5, [rsp+0x40]
0000786bc93d5742  vmovaps xmm6, [rsp+0x50]
0000786bc93d5748  vmovaps xmm7, [rsp+0x60]
0000786bc93d574e  vmovaps xmm8, [rsp+0x70]
0000786bc93d5754  vmovaps xmm9, [rsp+0x80]
0000786bc93d575d  vmovaps xmm10, [rsp+0x90]
0000786bc93d5766  vmovaps xmm11, [rsp+0xA0]
0000786bc93d576f  vmovaps xmm12, [rsp+0xB0]
0000786bc93d5778  vmovaps xmm13, [rsp+0xC0]
0000786bc93d5781  vmovaps xmm14, [rsp+0xD0]
0000786bc93d578a  vmovaps xmm15, [rsp+0xE0]
0000786bc93d5793  add rsp, 0xF0
0000786bc93d579a  pop r11
0000786bc93d579c  pop r10
0000786bc93d579e  pop r9
0000786bc93d57a0  pop r8
0000786bc93d57a2  pop rsi
0000786bc93d57a3  pop rdi
0000786bc93d57a4  pop rdx
0000786bc93d57a5  pop rcx
0000786bc93d57a6  pop rax
0000786bc93d57a7  add rsp, 0x08
0000786bc93d57ab  jmp 0x0000786BC93D033B
0000786bc93d57b0  call 0x0000786BC920E880
0000786bc93d57b5  jmp 0x0000786BC93D034E
0000786bc93d57ba  call 0x0000786BC920C380
0000786bc93d57bf  jmp 0x0000786BC93D0359
0000786bc93d57c4  call 0x0000786BC920D600
0000786bc93d57c9  jmp 0x0000786BC93D0364
0000786bc93d57ce  call 0x0000786BC91FF540
0000786bc93d57d3  jmp 0x0000786BC93D036F
0000786bc93d57d8  int3
0000786bc93d57d9  nop [rax], eax
0000786bc93d57e0  mov rax, [r15+0x40]
0000786bc93d57e4  mov r14, [r15+0x58]
0000786bc93d57e8  lea r12, [rax+r14*1]
0000786bc93d57ec  movaps xmm1, [r15+0x1D0]
0000786bc93d57f4  vmovaps [rsp+0x10], xmm1
0000786bc93d57fa  vmovaps xmm15, [rsp+0x10]
0000786bc93d5800  por xmm1, xmm15
0000786bc93d5805  movaps xmm14, [r15+0x1A0]
0000786bc93d580d  vmovaps [rsp+0x10], xmm14
0000786bc93d5813  vmovaps xmm13, [rsp+0x10]
0000786bc93d5819  por xmm14, xmm13
0000786bc93d581e  lea rax, [r12+0x30]
0000786bc93d5823  mov r11, [r13+rax*1]
0000786bc93d5828  lea rax, [r12+0x38]
0000786bc93d582d  mov r10, [r13+rax*1]
0000786bc93d5832  movq xmm13, r11
0000786bc93d5837  movq xmm12, r10
0000786bc93d583c  movq xmm13, xmm13
0000786bc93d5841  vmovaps [rsp+0x10], xmm13
0000786bc93d5847  movq xmm13, xmm13
0000786bc93d584c  movaps [r15+0x130], xmm13
0000786bc93d5854  movq xmm12, xmm12
0000786bc93d5859  vmovaps [rsp+0x20], xmm12
0000786bc93d585f  movq xmm12, xmm12
0000786bc93d5864  movaps [r15+0x280], xmm12
0000786bc93d586c  movaps xmm13, [r15+0x270]
0000786bc93d5874  vmovaps [rsp+0x30], xmm13
0000786bc93d587a  vmovaps xmm12, [rsp+0x30]
0000786bc93d5880  por xmm13, xmm12
0000786bc93d5885  lea rax, [r12+0x20]
0000786bc93d588a  mov r11, [r13+rax*1]
0000786bc93d588f  lea rax, [r12+0x28]
0000786bc93d5894  mov r10, [r13+rax*1]
0000786bc93d5899  movq xmm12, r11
0000786bc93d589e  movq xmm11, r10
0000786bc93d58a3  movq xmm12, xmm12
0000786bc93d58a8  vmovaps [rsp+0x30], xmm12
0000786bc93d58ae  movq xmm12, xmm12
0000786bc93d58b3  movaps [r15+0x150], xmm12
0000786bc93d58bb  movq xmm11, xmm11
0000786bc93d58c0  vmovaps [rsp+0x40], xmm11
0000786bc93d58c6  movq xmm11, xmm11
0000786bc93d58cb  movaps [r15+0x140], xmm11
0000786bc93d58d3  lea rax, [r12+0x10]
0000786bc93d58d8  mov r11, [r13+rax*1]
0000786bc93d58dd  lea rax, [r12+0x18]
0000786bc93d58e2  mov r10, [r13+rax*1]
0000786bc93d58e7  movq xmm12, r11
0000786bc93d58ec  movq xmm11, r10
0000786bc93d58f1  movq xmm12, xmm12
0000786bc93d58f6  vmovaps [rsp+0x50], xmm12
0000786bc93d58fc  movq xmm12, xmm12
0000786bc93d5901  movaps [r15+0x170], xmm12
0000786bc93d5909  movq xmm11, xmm11
0000786bc93d590e  vmovaps [rsp+0x60], xmm11
0000786bc93d5914  movq xmm11, xmm11
0000786bc93d5919  movaps [r15+0x160], xmm11
0000786bc93d5921  mov rax, [r13+r12*1]
0000786bc93d5926  vmovq xmm12, rax
0000786bc93d592b  vpbroadcastq xmm12, xmm12
0000786bc93d5930  lea rax, [r12+0x08]
0000786bc93d5935  mov r12, [r13+rax*1]
0000786bc93d593a  movq xmm11, r12
0000786bc93d593f  movaps [r15+0x230], xmm11
0000786bc93d5947  mov rax, [r15+0xF8]
0000786bc93d594e  lea r12, [rax+0x50]
0000786bc93d5952  movups xmm11, [r13+r12*1]
0000786bc93d5958  lea r12, [rax+0x60]
0000786bc93d595c  movups xmm10, [r13+r12*1]
0000786bc93d5962  lea r12, [rax+0x30]
0000786bc93d5966  movups xmm9, [r13+r12*1]
0000786bc93d596c  mov r12, [r15+0x50]
0000786bc93d5970  lea r11, [r12+r14*1]
0000786bc93d5974  mov [r15+0x60], r11
0000786bc93d5978  lea r12, [r14+0x40]
0000786bc93d597c  mov [r15+0x58], r12
0000786bc93d5980  movaps xmm8, xmm12
0000786bc93d5984  mulpd xmm8, xmm15
0000786bc93d5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000786bc93d598f  ptest xmm7, xmm7
0000786bc93d5994  jnz 0x0000786BC93D67B7
0000786bc93d599a  movq xmm15, qword ptr [r15+0x230]
0000786bc93d59a3  vmovaps [rsp+0x70], xmm15
0000786bc93d59a9  vpermilpd xmm15, xmm15, 0x00
0000786bc93d59af  movaps xmm7, xmm9
0000786bc93d59b3  mulpd xmm7, xmm15
0000786bc93d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000786bc93d59bd  ptest xmm6, xmm6
0000786bc93d59c2  jnz 0x0000786BC93D68FB
0000786bc93d59c8  vxorps xmm15, xmm15, xmm15
0000786bc93d59cd  vpbroadcastq xmm15, xmm15
0000786bc93d59d2  movaps xmm9, xmm12
0000786bc93d59d6  mulpd xmm9, xmm10
0000786bc93d59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000786bc93d59e1  ptest xmm6, xmm6
0000786bc93d59e6  jnz 0x0000786BC93D6A3D
0000786bc93d59ec  movaps xmm10, xmm12
0000786bc93d59f0  mulpd xmm10, xmm11
0000786bc93d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000786bc93d59fb  ptest xmm6, xmm6
0000786bc93d5a00  jnz 0x0000786BC93D6B81
0000786bc93d5a06  movaps xmm11, [r15+0x1F0]
0000786bc93d5a0e  movaps xmm6, xmm12
0000786bc93d5a12  mulpd xmm6, xmm11
0000786bc93d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000786bc93d5a1c  ptest xmm5, xmm5
0000786bc93d5a21  jnz 0x0000786BC93D6CC5
0000786bc93d5a27  movaps xmm12, [r15+0x2A0]
0000786bc93d5a2f  vmovaps [rsp+0x80], xmm12
0000786bc93d5a38  vmovaps xmm11, [rsp+0x80]
0000786bc93d5a41  por xmm12, xmm11
0000786bc93d5a46  movaps xmm11, [r15+0x250]
0000786bc93d5a4e  vmovaps [rsp+0x80], xmm11
0000786bc93d5a57  vmovaps xmm5, [rsp+0x80]
0000786bc93d5a60  por xmm11, xmm5
0000786bc93d5a65  vmovaps xmm4, [rsp+0x70]
0000786bc93d5a6b  vpermilpd xmm4, xmm4, 0x00
0000786bc93d5a71  movaps xmm3, xmm5
0000786bc93d5a74  mulpd xmm3, xmm4
0000786bc93d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000786bc93d5a7d  ptest xmm2, xmm2
0000786bc93d5a82  jnz 0x0000786BC93D6E07
0000786bc93d5a88  mov [rsp+0x80], rax
0000786bc93d5a90  xor eax, eax
0000786bc93d5a92  mov r14d, 0x200
0000786bc93d5a98  cmp r12, r14
0000786bc93d5a9b  cmc
0000786bc93d5a9c  lahf
0000786bc93d5a9d  seto al
0000786bc93d5aa0  mov [r15+0x108], eax
0000786bc93d5aa7  movaps xmm5, xmm8
0000786bc93d5aab  addpd xmm5, xmm15
0000786bc93d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000786bc93d5ab5  ptest xmm4, xmm4
0000786bc93d5aba  jnz 0x0000786BC93D6F47
0000786bc93d5ac0  movaps xmm8, [r15+0x1B0]
0000786bc93d5ac8  movaps xmm4, xmm9
0000786bc93d5acc  addpd xmm4, xmm8
0000786bc93d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000786bc93d5ad6  ptest xmm2, xmm2
0000786bc93d5adb  jnz 0x0000786BC93D7089
0000786bc93d5ae1  movaps xmm9, xmm10
0000786bc93d5ae5  addpd xmm9, xmm8
0000786bc93d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000786bc93d5af0  ptest xmm2, xmm2
0000786bc93d5af5  jnz 0x0000786BC93D71CB
0000786bc93d5afb  movaps xmm10, [r15+0x2F0]
0000786bc93d5b03  vmovaps [rsp+0x90], xmm10
0000786bc93d5b0c  vmovaps xmm8, [rsp+0x90]
0000786bc93d5b15  por xmm10, xmm8
0000786bc93d5b1a  movaps xmm8, [r15+0x2E0]
0000786bc93d5b22  vmovaps [rsp+0x90], xmm8
0000786bc93d5b2b  vmovaps xmm2, [rsp+0x90]
0000786bc93d5b34  por xmm8, xmm2
0000786bc93d5b39  movaps xmm2, [r15+0x2D0]
0000786bc93d5b41  vmovaps [rsp+0x90], xmm2
0000786bc93d5b4a  vmovaps [rsp+0xA0], xmm1
0000786bc93d5b53  vmovaps xmm1, [rsp+0x90]
0000786bc93d5b5c  por xmm2, xmm1
0000786bc93d5b60  movaps xmm1, [r15+0x200]
0000786bc93d5b68  vmovaps [rsp+0x90], xmm1
0000786bc93d5b71  vmovaps [rsp+0xB0], xmm15
0000786bc93d5b7a  vmovaps xmm15, [rsp+0x90]
0000786bc93d5b83  por xmm1, xmm15
0000786bc93d5b88  movaps xmm15, [r15+0x1C0]
0000786bc93d5b90  vmovaps [rsp+0x90], xmm15
0000786bc93d5b99  vmovaps [rsp+0xC0], xmm1
0000786bc93d5ba2  vmovaps xmm1, [rsp+0x90]
0000786bc93d5bab  por xmm15, xmm1
0000786bc93d5bb0  movaps xmm1, [r15+0x190]
0000786bc93d5bb8  vmovaps [rsp+0x90], xmm1
0000786bc93d5bc1  vmovaps [rsp+0xD0], xmm15
0000786bc93d5bca  vmovaps xmm15, [rsp+0x90]
0000786bc93d5bd3  por xmm1, xmm15
0000786bc93d5bd8  movaps xmm15, [r15+0x300]
0000786bc93d5be0  vmovaps [rsp+0x90], xmm15
0000786bc93d5be9  vmovaps [rsp+0xE0], xmm1
0000786bc93d5bf2  vmovaps xmm1, [rsp+0x90]
0000786bc93d5bfb  por xmm15, xmm1
0000786bc93d5c00  mov rax, [rsp+0x80]
0000786bc93d5c08  lea r14, [rax+0xA0]
0000786bc93d5c0f  movups xmm1, [r13+r14*1]
0000786bc93d5c15  lea r14, [rax+0xB0]
0000786bc93d5c1c  vmovaps [rsp+0x80], xmm1
0000786bc93d5c25  movups xmm1, [r13+r14*1]
0000786bc93d5c2b  vmovaps [rsp+0x90], xmm1
0000786bc93d5c34  vmovaps [rsp+0xF0], xmm15
0000786bc93d5c3d  vmovaps xmm15, [rsp+0xB0]
0000786bc93d5c46  vmovaps [rsp+0xB0], xmm14
0000786bc93d5c4f  movaps xmm1, xmm6
0000786bc93d5c52  addpd xmm1, xmm15
0000786bc93d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000786bc93d5c5c  ptest xmm14, xmm14
0000786bc93d5c62  jnz 0x0000786BC93D7323
0000786bc93d5c68  lea r14, [rax+0xF0]
0000786bc93d5c6f  movups xmm15, [r13+r14*1]
0000786bc93d5c75  movaps xmm14, xmm4
0000786bc93d5c79  addpd xmm14, xmm3
0000786bc93d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000786bc93d5c84  ptest xmm6, xmm6
0000786bc93d5c89  jnz 0x0000786BC93D746E
0000786bc93d5c8f  movaps xmm6, xmm9
0000786bc93d5c93  addpd xmm6, xmm7
0000786bc93d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000786bc93d5c9c  ptest xmm4, xmm4
0000786bc93d5ca1  jnz 0x0000786BC93D75B0
0000786bc93d5ca7  vmovaps xmm9, [rsp+0x70]
0000786bc93d5cad  vpermilpd xmm9, xmm9, 0x00
0000786bc93d5cb3  vmovaps xmm4, [rsp+0x90]
0000786bc93d5cbc  movaps xmm7, xmm4
0000786bc93d5cbf  mulpd xmm7, xmm9
0000786bc93d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000786bc93d5cc9  ptest xmm3, xmm3
0000786bc93d5cce  jnz 0x0000786BC93D76F1
0000786bc93d5cd4  vmovaps xmm9, [rsp+0x50]
0000786bc93d5cda  vpermilpd xmm9, xmm9, 0x00
0000786bc93d5ce0  movaps xmm4, xmm15
0000786bc93d5ce4  mulpd xmm4, xmm9
0000786bc93d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000786bc93d5cee  ptest xmm3, xmm3
0000786bc93d5cf3  jnz 0x0000786BC93D7832
0000786bc93d5cf9  lea r14, [rax+0xE0]
0000786bc93d5d00  movups xmm15, [r13+r14*1]
0000786bc93d5d06  vmovaps xmm9, [rsp+0x70]
0000786bc93d5d0c  vpermilpd xmm9, xmm9, 0x00
0000786bc93d5d12  vmovaps [rsp+0x70], xmm1
0000786bc93d5d18  vmovaps xmm1, [rsp+0x80]
0000786bc93d5d21  vmovaps [rsp+0x80], xmm15
0000786bc93d5d2a  movaps xmm3, xmm1
0000786bc93d5d2d  mulpd xmm3, xmm9
0000786bc93d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000786bc93d5d37  ptest xmm15, xmm15
0000786bc93d5d3d  jnz 0x0000786BC93D797E
0000786bc93d5d43  vmovaps xmm1, [rsp+0xF0]
0000786bc93d5d4c  vmovaps xmm15, [rsp+0xF0]
0000786bc93d5d55  por xmm1, xmm15
0000786bc93d5d5a  movaps [r15+0x300], xmm1
0000786bc93d5d62  vmovaps xmm15, [rsp+0xE0]
0000786bc93d5d6b  vmovaps xmm9, [rsp+0xE0]
0000786bc93d5d74  por xmm15, xmm9
0000786bc93d5d79  movaps [r15+0x190], xmm15
0000786bc93d5d81  vmovaps xmm9, [rsp+0x50]
0000786bc93d5d87  vpermilpd xmm9, xmm9, 0x00
0000786bc93d5d8d  vmovaps [rsp+0x90], xmm1
0000786bc93d5d96  vmovaps [rsp+0xE0], xmm15
0000786bc93d5d9f  vmovaps xmm15, [rsp+0x80]
0000786bc93d5da8  vmovaps [rsp+0x80], xmm14
0000786bc93d5db1  movaps xmm1, xmm15
0000786bc93d5db5  mulpd xmm1, xmm9
0000786bc93d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000786bc93d5dbf  ptest xmm14, xmm14
0000786bc93d5dc5  jnz 0x0000786BC93D7ABF
0000786bc93d5dcb  lea r14, [rax+0x90]
0000786bc93d5dd2  movups xmm15, [r13+r14*1]
0000786bc93d5dd8  vmovaps xmm14, [rsp+0xD0]
0000786bc93d5de1  vmovaps xmm9, [rsp+0xD0]
0000786bc93d5dea  por xmm14, xmm9
0000786bc93d5def  movaps [r15+0x1C0], xmm14
0000786bc93d5df7  vmovaps xmm9, [rsp+0xC0]
0000786bc93d5e00  vmovaps [rsp+0xD0], xmm1
0000786bc93d5e09  vmovaps xmm1, [rsp+0xC0]
0000786bc93d5e12  por xmm9, xmm1
0000786bc93d5e17  movaps [r15+0x200], xmm9
0000786bc93d5e1f  vmovaps [rsp+0xC0], xmm2
0000786bc93d5e28  vmovaps xmm1, [rsp+0xC0]
0000786bc93d5e31  por xmm2, xmm1
0000786bc93d5e35  movaps [r15+0x2D0], xmm2
0000786bc93d5e3d  vmovaps [rsp+0xC0], xmm8
0000786bc93d5e46  vmovaps xmm1, [rsp+0xC0]
0000786bc93d5e4f  por xmm8, xmm1
0000786bc93d5e54  movaps [r15+0x2E0], xmm8
0000786bc93d5e5c  vmovaps [rsp+0xC0], xmm15
0000786bc93d5e65  movaps xmm1, xmm5
0000786bc93d5e68  addpd xmm1, xmm7
0000786bc93d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000786bc93d5e71  ptest xmm15, xmm15
0000786bc93d5e77  jnz 0x0000786BC93D7C0B
0000786bc93d5e7d  vmovaps xmm15, [rsp+0x50]
0000786bc93d5e83  vpermilpd xmm15, xmm15, 0x00
0000786bc93d5e89  vmovaps xmm5, [rsp+0xC0]
0000786bc93d5e92  vmovaps [rsp+0xC0], xmm1
0000786bc93d5e9b  movaps xmm7, xmm5
0000786bc93d5e9e  mulpd xmm7, xmm15
0000786bc93d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000786bc93d5ea8  ptest xmm1, xmm1
0000786bc93d5ead  jnz 0x0000786BC93D7D4B
0000786bc93d5eb3  lea r14, [rax+0x80]
0000786bc93d5eba  movups xmm1, [r13+r14*1]
0000786bc93d5ec0  vmovaps xmm5, [rsp+0x70]
0000786bc93d5ec6  vmovaps [rsp+0x70], xmm1
0000786bc93d5ecc  movaps xmm15, xmm5
0000786bc93d5ed0  addpd xmm15, xmm3
0000786bc93d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93d5edb  ptest xmm1, xmm1
0000786bc93d5ee0  jnz 0x0000786BC93D7E96
0000786bc93d5ee6  vmovaps xmm5, [rsp+0x80]
0000786bc93d5eef  movaps xmm1, xmm5
0000786bc93d5ef2  addpd xmm1, xmm4
0000786bc93d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000786bc93d5efb  ptest xmm3, xmm3
0000786bc93d5f00  jnz 0x0000786BC93D7FD8
0000786bc93d5f06  vmovaps [rsp+0x80], xmm10
0000786bc93d5f0f  vmovaps xmm5, [rsp+0x80]
0000786bc93d5f18  por xmm10, xmm5
0000786bc93d5f1d  movaps [r15+0x2F0], xmm10
0000786bc93d5f25  vmovaps xmm5, [rsp+0x50]
0000786bc93d5f2b  vpermilpd xmm5, xmm5, 0x00
0000786bc93d5f31  vmovaps xmm3, [rsp+0x70]
0000786bc93d5f37  vmovaps [rsp+0x50], xmm1
0000786bc93d5f3d  movaps xmm4, xmm3
0000786bc93d5f40  mulpd xmm4, xmm5
0000786bc93d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000786bc93d5f49  ptest xmm1, xmm1
0000786bc93d5f4e  jnz 0x0000786BC93D8118
0000786bc93d5f54  lea r14, [rax+0xD0]
0000786bc93d5f5b  movups xmm1, [r13+r14*1]
0000786bc93d5f61  vmovaps xmm3, [rsp+0xD0]
0000786bc93d5f6a  vmovaps [rsp+0x70], xmm1
0000786bc93d5f70  movaps xmm5, xmm6
0000786bc93d5f73  addpd xmm5, xmm3
0000786bc93d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000786bc93d5f7c  ptest xmm1, xmm1
0000786bc93d5f81  jnz 0x0000786BC93D8262
0000786bc93d5f87  vmovaps xmm1, [rsp+0x60]
0000786bc93d5f8d  vpermilpd xmm1, xmm1, 0x00
0000786bc93d5f93  movaps xmm6, xmm9
0000786bc93d5f97  mulpd xmm6, xmm1
0000786bc93d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000786bc93d5fa0  ptest xmm3, xmm3
0000786bc93d5fa5  jnz 0x0000786BC93D83A2
0000786bc93d5fab  movaps [r15+0x260], xmm6
0000786bc93d5fb3  vxorps xmm1, xmm1, xmm1
0000786bc93d5fb7  vpbroadcastq xmm1, xmm1
0000786bc93d5fbc  movaps [r15+0x1B0], xmm1
0000786bc93d5fc4  vmovaps xmm1, [rsp+0x60]
0000786bc93d5fca  vpermilpd xmm1, xmm1, 0x00
0000786bc93d5fd0  vmovaps xmm3, [rsp+0x70]
0000786bc93d5fd6  vmovaps [rsp+0x70], xmm15
0000786bc93d5fdc  movaps xmm9, xmm3
0000786bc93d5fe0  mulpd xmm9, xmm1
0000786bc93d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000786bc93d5feb  ptest xmm15, xmm15
0000786bc93d5ff1  jnz 0x0000786BC93D84E3
0000786bc93d5ff7  lea r14, [rax+0xC0]
0000786bc93d5ffe  movups xmm1, [r13+r14*1]
0000786bc93d6004  vmovaps xmm3, [rsp+0xC0]
0000786bc93d600d  vmovaps [rsp+0x80], xmm1
0000786bc93d6016  movaps xmm15, xmm3
0000786bc93d601a  addpd xmm15, xmm7
0000786bc93d601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93d6025  ptest xmm1, xmm1
0000786bc93d602a  jnz 0x0000786BC93D862F
0000786bc93d6030  vmovaps [rsp+0xC0], xmm13
0000786bc93d6039  vmovaps xmm1, [rsp+0xC0]
0000786bc93d6042  por xmm13, xmm1
0000786bc93d6047  movaps [r15+0x270], xmm13
0000786bc93d604f  vmovaps xmm1, [rsp+0xB0]
0000786bc93d6058  vmovaps xmm7, [rsp+0xB0]
0000786bc93d6061  por xmm1, xmm7
0000786bc93d6065  movaps [r15+0x1A0], xmm1
0000786bc93d606d  vmovaps xmm1, [rsp+0x60]
0000786bc93d6073  vpermilpd xmm1, xmm1, 0x00
0000786bc93d6079  vmovaps [rsp+0xB0], xmm1
0000786bc93d6082  vmovaps xmm1, [rsp+0x80]
0000786bc93d608b  vmovaps [rsp+0x80], xmm15
0000786bc93d6094  vmovaps xmm15, [rsp+0xB0]
0000786bc93d609d  vmovaps [rsp+0xB0], xmm14
0000786bc93d60a6  movaps xmm3, xmm1
0000786bc93d60a9  mulpd xmm3, xmm15
0000786bc93d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000786bc93d60b3  ptest xmm14, xmm14
0000786bc93d60b9  jnz 0x0000786BC93D8771
0000786bc93d60bf  lea r14, [rax+0x20]
0000786bc93d60c3  movups xmm1, [r13+r14*1]
0000786bc93d60c9  movaps [r15+0x110], xmm1
0000786bc93d60d1  vmovaps xmm14, [rsp+0x70]
0000786bc93d60d7  vmovaps [rsp+0x70], xmm1
0000786bc93d60dd  movaps xmm15, xmm14
0000786bc93d60e1  addpd xmm15, xmm4
0000786bc93d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93d60ec  ptest xmm1, xmm1
0000786bc93d60f1  jnz 0x0000786BC93D88BC
0000786bc93d60f7  vmovaps xmm1, [rsp+0x60]
0000786bc93d60fd  vpermilpd xmm1, xmm1, 0x00
0000786bc93d6103  movaps xmm14, xmm2
0000786bc93d6107  mulpd xmm14, xmm1
0000786bc93d610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000786bc93d6112  ptest xmm4, xmm4
0000786bc93d6117  jnz 0x0000786BC93D89FF
0000786bc93d611d  vmovaps xmm4, [rsp+0x50]
0000786bc93d6123  movaps xmm1, xmm4
0000786bc93d6126  addpd xmm1, xmm9
0000786bc93d612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000786bc93d6130  ptest xmm2, xmm2
0000786bc93d6135  jnz 0x0000786BC93D8B41
0000786bc93d613b  vmovaps xmm9, [rsp+0x30]
0000786bc93d6141  vpermilpd xmm9, xmm9, 0x00
0000786bc93d6147  vmovaps xmm2, [rsp+0x70]
0000786bc93d614d  vmovaps [rsp+0x50], xmm1
0000786bc93d6153  movaps xmm4, xmm2
0000786bc93d6156  mulpd xmm4, xmm9
0000786bc93d615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000786bc93d6160  ptest xmm1, xmm1
0000786bc93d6165  jnz 0x0000786BC93D8C82
0000786bc93d616b  vmovaps xmm1, [rsp+0x30]
0000786bc93d6171  vpermilpd xmm1, xmm1, 0x00
0000786bc93d6177  vmovaps xmm2, [rsp+0x90]
0000786bc93d6180  vmovaps [rsp+0x60], xmm15
0000786bc93d6186  movaps xmm9, xmm2
0000786bc93d618a  mulpd xmm9, xmm1
0000786bc93d618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000786bc93d6195  ptest xmm15, xmm15
0000786bc93d619b  jnz 0x0000786BC93D8DC3
0000786bc93d61a1  vmovaps xmm15, [rsp+0x80]
0000786bc93d61aa  movaps xmm1, xmm15
0000786bc93d61ae  addpd xmm1, xmm6
0000786bc93d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000786bc93d61b7  ptest xmm2, xmm2
0000786bc93d61bc  jnz 0x0000786BC93D8F05
0000786bc93d61c2  movaps xmm15, xmm5
0000786bc93d61c6  addpd xmm15, xmm3
0000786bc93d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000786bc93d61d1  ptest xmm6, xmm6
0000786bc93d61d6  jnz 0x0000786BC93D9046
0000786bc93d61dc  vmovaps xmm6, [rsp+0x30]
0000786bc93d61e2  vpermilpd xmm6, xmm6, 0x00
0000786bc93d61e8  movaps xmm5, xmm8
0000786bc93d61ec  mulpd xmm5, xmm6
0000786bc93d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000786bc93d61f5  ptest xmm3, xmm3
0000786bc93d61fa  jnz 0x0000786BC93D9188
0000786bc93d6200  vmovaps xmm8, [rsp+0x30]
0000786bc93d6206  vpermilpd xmm8, xmm8, 0x00
0000786bc93d620c  movaps xmm6, xmm10
0000786bc93d6210  mulpd xmm6, xmm8
0000786bc93d6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000786bc93d621a  ptest xmm3, xmm3
0000786bc93d621f  jnz 0x0000786BC93D92C9
0000786bc93d6225  vmovaps xmm8, [rsp+0x60]
0000786bc93d622b  movaps xmm10, xmm8
0000786bc93d622f  addpd xmm10, xmm14
0000786bc93d6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000786bc93d623a  ptest xmm3, xmm3
0000786bc93d623f  jnz 0x0000786BC93D940B
0000786bc93d6245  vmovaps xmm8, [rsp+0x50]
0000786bc93d624b  movaps xmm14, xmm8
0000786bc93d624f  addpd xmm14, xmm4
0000786bc93d6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000786bc93d625a  ptest xmm3, xmm3
0000786bc93d625f  jnz 0x0000786BC93D954F
0000786bc93d6265  vmovaps xmm8, [rsp+0x40]
0000786bc93d626b  vpermilpd xmm8, xmm8, 0x00
0000786bc93d6271  movaps xmm4, xmm13
0000786bc93d6275  mulpd xmm4, xmm8
0000786bc93d627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000786bc93d627f  ptest xmm3, xmm3
0000786bc93d6284  jnz 0x0000786BC93D9692
0000786bc93d628a  movaps xmm13, xmm15
0000786bc93d628e  addpd xmm13, xmm9
0000786bc93d6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000786bc93d6299  ptest xmm8, xmm8
0000786bc93d629f  jnz 0x0000786BC93D97D4
0000786bc93d62a5  movaps xmm15, xmm1
0000786bc93d62a9  addpd xmm15, xmm5
0000786bc93d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000786bc93d62b4  ptest xmm9, xmm9
0000786bc93d62ba  jnz 0x0000786BC93D9918
0000786bc93d62c0  vmovaps [rsp+0x30], xmm11
0000786bc93d62c6  vmovaps xmm1, [rsp+0x30]
0000786bc93d62cc  por xmm11, xmm1
0000786bc93d62d1  movaps [r15+0x250], xmm11
0000786bc93d62d9  vmovaps [rsp+0x30], xmm12
0000786bc93d62df  vmovaps xmm1, [rsp+0x30]
0000786bc93d62e5  por xmm12, xmm1
0000786bc93d62ea  movaps [r15+0x2A0], xmm12
0000786bc93d62f2  vmovaps xmm1, [rsp+0xA0]
0000786bc93d62fb  vmovaps xmm11, [rsp+0xA0]
0000786bc93d6304  por xmm1, xmm11
0000786bc93d6309  movaps [r15+0x1D0], xmm1
0000786bc93d6311  lea r14, [rax+0x40]
0000786bc93d6315  movups xmm1, [r13+r14*1]
0000786bc93d631b  movaps [r15+0x2C0], xmm1
0000786bc93d6323  vmovaps xmm11, [rsp+0x40]
0000786bc93d6329  vpermilpd xmm11, xmm11, 0x00
0000786bc93d632f  vmovaps xmm8, [rsp+0xE0]
0000786bc93d6338  movaps xmm9, xmm8
0000786bc93d633c  mulpd xmm9, xmm11
0000786bc93d6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000786bc93d6347  ptest xmm5, xmm5
0000786bc93d634c  jnz 0x0000786BC93D9A64
0000786bc93d6352  movaps xmm11, xmm10
0000786bc93d6356  addpd xmm11, xmm6
0000786bc93d635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000786bc93d6361  ptest xmm8, xmm8
0000786bc93d6367  jnz 0x0000786BC93D9BA8
0000786bc93d636d  movaps xmm10, xmm14
0000786bc93d6371  addpd xmm10, xmm4
0000786bc93d6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000786bc93d637c  ptest xmm8, xmm8
0000786bc93d6382  jnz 0x0000786BC93D9CEB
0000786bc93d6388  vmovaps xmm14, [rsp+0x40]
0000786bc93d638e  vpermilpd xmm14, xmm14, 0x00
0000786bc93d6394  movaps xmm8, xmm1
0000786bc93d6398  mulpd xmm8, xmm14
0000786bc93d639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000786bc93d63a3  ptest xmm6, xmm6
0000786bc93d63a8  jnz 0x0000786BC93D9E2E
0000786bc93d63ae  movaps xmm1, [r15+0x2B0]
0000786bc93d63b6  vmovaps xmm14, [rsp+0x40]
0000786bc93d63bc  vpermilpd xmm14, xmm14, 0x00
0000786bc93d63c2  movaps xmm6, xmm1
0000786bc93d63c5  mulpd xmm6, xmm14
0000786bc93d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000786bc93d63cf  ptest xmm5, xmm5
0000786bc93d63d4  jnz 0x0000786BC93D9F71
0000786bc93d63da  vmovaps xmm1, [rsp+0x10]
0000786bc93d63e0  vpermilpd xmm1, xmm1, 0x00
0000786bc93d63e6  movaps xmm14, xmm12
0000786bc93d63ea  mulpd xmm14, xmm1
0000786bc93d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000786bc93d63f5  ptest xmm5, xmm5
0000786bc93d63fa  jnz 0x0000786BC93DA0B2
0000786bc93d6400  movaps xmm1, xmm13
0000786bc93d6404  addpd xmm1, xmm9
0000786bc93d6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000786bc93d640e  ptest xmm12, xmm12
0000786bc93d6414  jnz 0x0000786BC93DA1F5
0000786bc93d641a  vmovaps xmm13, [rsp+0x10]
0000786bc93d6420  vpermilpd xmm13, xmm13, 0x00
0000786bc93d6426  movaps xmm12, xmm7
0000786bc93d642a  mulpd xmm12, xmm13
0000786bc93d642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000786bc93d6435  ptest xmm9, xmm9
0000786bc93d643b  jnz 0x0000786BC93DA337
0000786bc93d6441  movaps xmm13, xmm15
0000786bc93d6445  addpd xmm13, xmm8
0000786bc93d644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000786bc93d6450  ptest xmm9, xmm9
0000786bc93d6456  jnz 0x0000786BC93DA47A
0000786bc93d645c  movaps xmm15, [r15+0x290]
0000786bc93d6464  vmovaps xmm9, [rsp+0x10]
0000786bc93d646a  vpermilpd xmm9, xmm9, 0x00
0000786bc93d6470  movaps xmm8, xmm15
0000786bc93d6474  mulpd xmm8, xmm9
0000786bc93d6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000786bc93d647f  ptest xmm7, xmm7
0000786bc93d6484  jnz 0x0000786BC93DA5BE
0000786bc93d648a  movaps xmm15, xmm11
0000786bc93d648e  addpd xmm15, xmm6
0000786bc93d6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000786bc93d6499  ptest xmm9, xmm9
0000786bc93d649f  jnz 0x0000786BC93DA702
0000786bc93d64a5  movaps xmm11, [r15+0x1E0]
0000786bc93d64ad  vmovaps xmm9, [rsp+0x10]
0000786bc93d64b3  vpermilpd xmm9, xmm9, 0x00
0000786bc93d64b9  movaps xmm7, xmm11
0000786bc93d64bd  mulpd xmm7, xmm9
0000786bc93d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000786bc93d64c7  ptest xmm6, xmm6
0000786bc93d64cc  jnz 0x0000786BC93DA845
0000786bc93d64d2  movaps xmm11, xmm10
0000786bc93d64d6  addpd xmm11, xmm14
0000786bc93d64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000786bc93d64e1  ptest xmm9, xmm9
0000786bc93d64e7  jnz 0x0000786BC93DA987
0000786bc93d64ed  lea r14, [rax+0x70]
0000786bc93d64f1  movups xmm14, [r13+r14*1]
0000786bc93d64f7  movaps [r15+0x240], xmm14
0000786bc93d64ff  movaps xmm10, xmm1
0000786bc93d6503  addpd xmm10, xmm12
0000786bc93d6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000786bc93d650e  ptest xmm9, xmm9
0000786bc93d6514  jnz 0x0000786BC93DAAD5
0000786bc93d651a  movaps [r15+0x170], xmm10
0000786bc93d6522  vmovaps xmm1, [rsp+0x20]
0000786bc93d6528  vpermilpd xmm1, xmm1, 0x00
0000786bc93d652e  movaps xmm12, xmm14
0000786bc93d6532  mulpd xmm12, xmm1
0000786bc93d6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000786bc93d653d  ptest xmm9, xmm9
0000786bc93d6543  jnz 0x0000786BC93DAC18
0000786bc93d6549  vmovaps xmm1, [rsp+0x20]
0000786bc93d654f  vpermilpd xmm1, xmm1, 0x00
0000786bc93d6555  vmovaps xmm9, [rsp+0xB0]
0000786bc93d655e  movaps xmm14, xmm9
0000786bc93d6562  mulpd xmm14, xmm1
0000786bc93d6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000786bc93d656d  ptest xmm6, xmm6
0000786bc93d6572  jnz 0x0000786BC93DAD5B
0000786bc93d6578  movaps [r15+0x180], xmm14
0000786bc93d6580  movaps xmm1, xmm13
0000786bc93d6584  addpd xmm1, xmm8
0000786bc93d6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000786bc93d658e  ptest xmm9, xmm9
0000786bc93d6594  jnz 0x0000786BC93DAE9E
0000786bc93d659a  movaps [r15+0x210], xmm1
0000786bc93d65a2  movups xmm13, [r13+rax*1]
0000786bc93d65a8  lea r14, [rax+0x10]
0000786bc93d65ac  movups xmm9, [r13+r14*1]
0000786bc93d65b2  movaps [r15+0x230], xmm9
0000786bc93d65ba  movaps xmm8, xmm15
0000786bc93d65be  addpd xmm8, xmm7
0000786bc93d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000786bc93d65c9  ptest xmm6, xmm6
0000786bc93d65ce  jnz 0x0000786BC93DAFF4
0000786bc93d65d4  movaps [r15+0x130], xmm8
0000786bc93d65dc  vmovaps xmm15, [rsp+0x20]
0000786bc93d65e2  vpermilpd xmm15, xmm15, 0x00
0000786bc93d65e8  movaps xmm7, xmm9
0000786bc93d65ec  mulpd xmm7, xmm15
0000786bc93d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000786bc93d65f6  ptest xmm6, xmm6
0000786bc93d65fb  jnz 0x0000786BC93DB137
0000786bc93d6601  movaps [r15+0x220], xmm7
0000786bc93d6609  vmovaps xmm15, [rsp+0x20]
0000786bc93d660f  vpermilpd xmm15, xmm15, 0x00
0000786bc93d6615  movaps xmm9, xmm13
0000786bc93d6619  mulpd xmm9, xmm15
0000786bc93d661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000786bc93d6624  ptest xmm6, xmm6
0000786bc93d6629  jnz 0x0000786BC93DB279
0000786bc93d662f  movaps xmm15, xmm11
0000786bc93d6633  addpd xmm15, xmm12
0000786bc93d6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000786bc93d663e  ptest xmm13, xmm13
0000786bc93d6644  jnz 0x0000786BC93DB3BD
0000786bc93d664a  movaps [r15+0x140], xmm15
0000786bc93d6652  movaps xmm13, xmm10
0000786bc93d6656  addpd xmm13, xmm14
0000786bc93d665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000786bc93d6661  ptest xmm12, xmm12
0000786bc93d6667  jnz 0x0000786BC93DB501
0000786bc93d666d  movaps [r15+0x150], xmm13
0000786bc93d6675  movaps xmm14, xmm1
0000786bc93d6679  addpd xmm14, xmm7
0000786bc93d667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000786bc93d6684  ptest xmm12, xmm12
0000786bc93d668a  jnz 0x0000786BC93DB645
0000786bc93d6690  movaps [r15+0x160], xmm14
0000786bc93d6698  movaps xmm1, xmm8
0000786bc93d669c  addpd xmm1, xmm9
0000786bc93d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000786bc93d66a6  ptest xmm12, xmm12
0000786bc93d66ac  jnz 0x0000786BC93DB787
0000786bc93d66b2  movaps [r15+0x120], xmm1
0000786bc93d66ba  movups [r13+r11*1], xmm15
0000786bc93d66c0  lea rax, [r11+0x10]
0000786bc93d66c4  movups [r13+rax*1], xmm13
0000786bc93d66ca  lea rax, [r11+0x20]
0000786bc93d66ce  movups [r13+rax*1], xmm14
0000786bc93d66d4  lea rax, [r11+0x30]
0000786bc93d66d8  movups [r13+rax*1], xmm1
0000786bc93d66de  mov eax, [r15+0x108]
0000786bc93d66e5  sahf
0000786bc93d66e6  jnz 0x0000786BC93D6718
0000786bc93d66e8  cmp dword ptr [r15+0x318], 0x00
0000786bc93d66f0  jz 0x0000786BC93DB900
0000786bc93d66f6  nop [rax+rax*1], ax
0000786bc93d66ff  nop [rax+rax*1], eax
0000786bc93d6707  mov eax, 0x410444
0000786bc93d670c  mov [r15+0x100], rax
0000786bc93d6713  jmp 0x0000786BC91FE110
0000786bc93d6718  cmp dword ptr [r15+0x318], 0x00
0000786bc93d6720  jz 0x0000786BC93D57E0
0000786bc93d6726  nop [rax+rax*1], ax
0000786bc93d672f  nop [rax+rax*1], eax
0000786bc93d6737  mov eax, 0x410278
0000786bc93d673c  mov [r15+0x100], rax
0000786bc93d6743  jmp 0x0000786BC91FE110
0000786bc93d6748  int3
0000786bc93d6749  call 0x0000786BC920A4B0
0000786bc93d674e  jmp 0x0000786BC93D5828
0000786bc93d6753  call 0x0000786BC9209240
0000786bc93d6758  jmp 0x0000786BC93D5832
0000786bc93d675d  call 0x0000786BC920A4B0
0000786bc93d6762  jmp 0x0000786BC93D588F
0000786bc93d6767  call 0x0000786BC9209240
0000786bc93d676c  jmp 0x0000786BC93D5899
0000786bc93d6771  call 0x0000786BC920A4B0
0000786bc93d6776  jmp 0x0000786BC93D58DD
0000786bc93d677b  call 0x0000786BC9209240
0000786bc93d6780  jmp 0x0000786BC93D58E7
0000786bc93d6785  call 0x0000786BC92B47C0
0000786bc93d678a  jmp 0x0000786BC93D5926
0000786bc93d678f  call 0x0000786BC920B720
0000786bc93d6794  jmp 0x0000786BC93D593A
0000786bc93d6799  call 0x0000786BC92BFC30
0000786bc93d679e  jmp 0x0000786BC93D5958
0000786bc93d67a3  call 0x0000786BC92BE9C0
0000786bc93d67a8  jmp 0x0000786BC93D5962
0000786bc93d67ad  call 0x0000786BC92BD750
0000786bc93d67b2  jmp 0x0000786BC93D596C
0000786bc93d67b7  sub rsp, 0x08
0000786bc93d67bb  push rax
0000786bc93d67bc  push rcx
0000786bc93d67bd  push rdx
0000786bc93d67be  push rdi
0000786bc93d67bf  push rsi
0000786bc93d67c0  push r8
0000786bc93d67c2  push r9
0000786bc93d67c4  push r10
0000786bc93d67c6  push r11
0000786bc93d67c8  sub rsp, 0xF0
0000786bc93d67cf  vmovaps [rsp], xmm0
0000786bc93d67d4  vmovaps [rsp+0x10], xmm1
0000786bc93d67da  vmovaps [rsp+0x20], xmm2
0000786bc93d67e0  vmovaps [rsp+0x30], xmm3
0000786bc93d67e6  vmovaps [rsp+0x40], xmm4
0000786bc93d67ec  vmovaps [rsp+0x50], xmm5
0000786bc93d67f2  vmovaps [rsp+0x60], xmm6
0000786bc93d67f8  vmovaps [rsp+0x70], xmm7
0000786bc93d67fe  vmovaps [rsp+0x80], xmm9
0000786bc93d6807  vmovaps [rsp+0x90], xmm10
0000786bc93d6810  vmovaps [rsp+0xA0], xmm11
0000786bc93d6819  vmovaps [rsp+0xB0], xmm12
0000786bc93d6822  vmovaps [rsp+0xC0], xmm13
0000786bc93d682b  vmovaps [rsp+0xD0], xmm14
0000786bc93d6834  vmovaps [rsp+0xE0], xmm15
0000786bc93d683d  sub rsp, 0x30
0000786bc93d6841  movaps [rsp], xmm8
0000786bc93d6846  movaps [rsp+0x10], xmm12
0000786bc93d684c  movaps [rsp+0x20], xmm15
0000786bc93d6852  lea rdi, [rsp]
0000786bc93d6856  mov esi, 0x00
0000786bc93d685b  mov rax, 0x60810F6F7530
0000786bc93d6865  call rax
0000786bc93d6867  movaps xmm8, [rsp]
0000786bc93d686c  add rsp, 0x30
0000786bc93d6870  vmovaps xmm0, [rsp]
0000786bc93d6875  vmovaps xmm1, [rsp+0x10]
0000786bc93d687b  vmovaps xmm2, [rsp+0x20]
0000786bc93d6881  vmovaps xmm3, [rsp+0x30]
0000786bc93d6887  vmovaps xmm4, [rsp+0x40]
0000786bc93d688d  vmovaps xmm5, [rsp+0x50]
0000786bc93d6893  vmovaps xmm6, [rsp+0x60]
0000786bc93d6899  vmovaps xmm7, [rsp+0x70]
0000786bc93d689f  vmovaps xmm9, [rsp+0x80]
0000786bc93d68a8  vmovaps xmm10, [rsp+0x90]
0000786bc93d68b1  vmovaps xmm11, [rsp+0xA0]
0000786bc93d68ba  vmovaps xmm12, [rsp+0xB0]
0000786bc93d68c3  vmovaps xmm13, [rsp+0xC0]
0000786bc93d68cc  vmovaps xmm14, [rsp+0xD0]
0000786bc93d68d5  vmovaps xmm15, [rsp+0xE0]
0000786bc93d68de  add rsp, 0xF0
0000786bc93d68e5  pop r11
0000786bc93d68e7  pop r10
0000786bc93d68e9  pop r9
0000786bc93d68eb  pop r8
0000786bc93d68ed  pop rsi
0000786bc93d68ee  pop rdi
0000786bc93d68ef  pop rdx
0000786bc93d68f0  pop rcx
0000786bc93d68f1  pop rax
0000786bc93d68f2  add rsp, 0x08
0000786bc93d68f6  jmp 0x0000786BC93D599A
0000786bc93d68fb  sub rsp, 0x08
0000786bc93d68ff  push rax
0000786bc93d6900  push rcx
0000786bc93d6901  push rdx
0000786bc93d6902  push rdi
0000786bc93d6903  push rsi
0000786bc93d6904  push r8
0000786bc93d6906  push r9
0000786bc93d6908  push r10
0000786bc93d690a  push r11
0000786bc93d690c  sub rsp, 0xF0
0000786bc93d6913  vmovaps [rsp], xmm0
0000786bc93d6918  vmovaps [rsp+0x10], xmm1
0000786bc93d691e  vmovaps [rsp+0x20], xmm2
0000786bc93d6924  vmovaps [rsp+0x30], xmm3
0000786bc93d692a  vmovaps [rsp+0x40], xmm4
0000786bc93d6930  vmovaps [rsp+0x50], xmm5
0000786bc93d6936  vmovaps [rsp+0x60], xmm6
0000786bc93d693c  vmovaps [rsp+0x70], xmm8
0000786bc93d6942  vmovaps [rsp+0x80], xmm9
0000786bc93d694b  vmovaps [rsp+0x90], xmm10
0000786bc93d6954  vmovaps [rsp+0xA0], xmm11
0000786bc93d695d  vmovaps [rsp+0xB0], xmm12
0000786bc93d6966  vmovaps [rsp+0xC0], xmm13
0000786bc93d696f  vmovaps [rsp+0xD0], xmm14
0000786bc93d6978  vmovaps [rsp+0xE0], xmm15
0000786bc93d6981  sub rsp, 0x30
0000786bc93d6985  movaps [rsp], xmm7
0000786bc93d6989  movaps [rsp+0x10], xmm9
0000786bc93d698f  movaps [rsp+0x20], xmm15
0000786bc93d6995  lea rdi, [rsp]
0000786bc93d6999  mov esi, 0x00
0000786bc93d699e  mov rax, 0x60810F6F7530
0000786bc93d69a8  call rax
0000786bc93d69aa  movaps xmm7, [rsp]
0000786bc93d69ae  add rsp, 0x30
0000786bc93d69b2  vmovaps xmm0, [rsp]
0000786bc93d69b7  vmovaps xmm1, [rsp+0x10]
0000786bc93d69bd  vmovaps xmm2, [rsp+0x20]
0000786bc93d69c3  vmovaps xmm3, [rsp+0x30]
0000786bc93d69c9  vmovaps xmm4, [rsp+0x40]
0000786bc93d69cf  vmovaps xmm5, [rsp+0x50]
0000786bc93d69d5  vmovaps xmm6, [rsp+0x60]
0000786bc93d69db  vmovaps xmm8, [rsp+0x70]
0000786bc93d69e1  vmovaps xmm9, [rsp+0x80]
0000786bc93d69ea  vmovaps xmm10, [rsp+0x90]
0000786bc93d69f3  vmovaps xmm11, [rsp+0xA0]
0000786bc93d69fc  vmovaps xmm12, [rsp+0xB0]
0000786bc93d6a05  vmovaps xmm13, [rsp+0xC0]
0000786bc93d6a0e  vmovaps xmm14, [rsp+0xD0]
0000786bc93d6a17  vmovaps xmm15, [rsp+0xE0]
0000786bc93d6a20  add rsp, 0xF0
0000786bc93d6a27  pop r11
0000786bc93d6a29  pop r10
0000786bc93d6a2b  pop r9
0000786bc93d6a2d  pop r8
0000786bc93d6a2f  pop rsi
0000786bc93d6a30  pop rdi
0000786bc93d6a31  pop rdx
0000786bc93d6a32  pop rcx
0000786bc93d6a33  pop rax
0000786bc93d6a34  add rsp, 0x08
0000786bc93d6a38  jmp 0x0000786BC93D59C8
0000786bc93d6a3d  sub rsp, 0x08
0000786bc93d6a41  push rax
0000786bc93d6a42  push rcx
0000786bc93d6a43  push rdx
0000786bc93d6a44  push rdi
0000786bc93d6a45  push rsi
0000786bc93d6a46  push r8
0000786bc93d6a48  push r9
0000786bc93d6a4a  push r10
0000786bc93d6a4c  push r11
0000786bc93d6a4e  sub rsp, 0xF0
0000786bc93d6a55  vmovaps [rsp], xmm0
0000786bc93d6a5a  vmovaps [rsp+0x10], xmm1
0000786bc93d6a60  vmovaps [rsp+0x20], xmm2
0000786bc93d6a66  vmovaps [rsp+0x30], xmm3
0000786bc93d6a6c  vmovaps [rsp+0x40], xmm4
0000786bc93d6a72  vmovaps [rsp+0x50], xmm5
0000786bc93d6a78  vmovaps [rsp+0x60], xmm6
0000786bc93d6a7e  vmovaps [rsp+0x70], xmm7
0000786bc93d6a84  vmovaps [rsp+0x80], xmm8
0000786bc93d6a8d  vmovaps [rsp+0x90], xmm10
0000786bc93d6a96  vmovaps [rsp+0xA0], xmm11
0000786bc93d6a9f  vmovaps [rsp+0xB0], xmm12
0000786bc93d6aa8  vmovaps [rsp+0xC0], xmm13
0000786bc93d6ab1  vmovaps [rsp+0xD0], xmm14
0000786bc93d6aba  vmovaps [rsp+0xE0], xmm15
0000786bc93d6ac3  sub rsp, 0x30
0000786bc93d6ac7  movaps [rsp], xmm9
0000786bc93d6acc  movaps [rsp+0x10], xmm12
0000786bc93d6ad2  movaps [rsp+0x20], xmm10
0000786bc93d6ad8  lea rdi, [rsp]
0000786bc93d6adc  mov esi, 0x00
0000786bc93d6ae1  mov rax, 0x60810F6F7530
0000786bc93d6aeb  call rax
0000786bc93d6aed  movaps xmm9, [rsp]
0000786bc93d6af2  add rsp, 0x30
0000786bc93d6af6  vmovaps xmm0, [rsp]
0000786bc93d6afb  vmovaps xmm1, [rsp+0x10]
0000786bc93d6b01  vmovaps xmm2, [rsp+0x20]
0000786bc93d6b07  vmovaps xmm3, [rsp+0x30]
0000786bc93d6b0d  vmovaps xmm4, [rsp+0x40]
0000786bc93d6b13  vmovaps xmm5, [rsp+0x50]
0000786bc93d6b19  vmovaps xmm6, [rsp+0x60]
0000786bc93d6b1f  vmovaps xmm7, [rsp+0x70]
0000786bc93d6b25  vmovaps xmm8, [rsp+0x80]
0000786bc93d6b2e  vmovaps xmm10, [rsp+0x90]
0000786bc93d6b37  vmovaps xmm11, [rsp+0xA0]
0000786bc93d6b40  vmovaps xmm12, [rsp+0xB0]
0000786bc93d6b49  vmovaps xmm13, [rsp+0xC0]
0000786bc93d6b52  vmovaps xmm14, [rsp+0xD0]
0000786bc93d6b5b  vmovaps xmm15, [rsp+0xE0]
0000786bc93d6b64  add rsp, 0xF0
0000786bc93d6b6b  pop r11
0000786bc93d6b6d  pop r10
0000786bc93d6b6f  pop r9
0000786bc93d6b71  pop r8
0000786bc93d6b73  pop rsi
0000786bc93d6b74  pop rdi
0000786bc93d6b75  pop rdx
0000786bc93d6b76  pop rcx
0000786bc93d6b77  pop rax
0000786bc93d6b78  add rsp, 0x08
0000786bc93d6b7c  jmp 0x0000786BC93D59EC
0000786bc93d6b81  sub rsp, 0x08
0000786bc93d6b85  push rax
0000786bc93d6b86  push rcx
0000786bc93d6b87  push rdx
0000786bc93d6b88  push rdi
0000786bc93d6b89  push rsi
0000786bc93d6b8a  push r8
0000786bc93d6b8c  push r9
0000786bc93d6b8e  push r10
0000786bc93d6b90  push r11
0000786bc93d6b92  sub rsp, 0xF0
0000786bc93d6b99  vmovaps [rsp], xmm0
0000786bc93d6b9e  vmovaps [rsp+0x10], xmm1
0000786bc93d6ba4  vmovaps [rsp+0x20], xmm2
0000786bc93d6baa  vmovaps [rsp+0x30], xmm3
0000786bc93d6bb0  vmovaps [rsp+0x40], xmm4
0000786bc93d6bb6  vmovaps [rsp+0x50], xmm5
0000786bc93d6bbc  vmovaps [rsp+0x60], xmm6
0000786bc93d6bc2  vmovaps [rsp+0x70], xmm7
0000786bc93d6bc8  vmovaps [rsp+0x80], xmm8
0000786bc93d6bd1  vmovaps [rsp+0x90], xmm9
0000786bc93d6bda  vmovaps [rsp+0xA0], xmm11
0000786bc93d6be3  vmovaps [rsp+0xB0], xmm12
0000786bc93d6bec  vmovaps [rsp+0xC0], xmm13
0000786bc93d6bf5  vmovaps [rsp+0xD0], xmm14
0000786bc93d6bfe  vmovaps [rsp+0xE0], xmm15
0000786bc93d6c07  sub rsp, 0x30
0000786bc93d6c0b  movaps [rsp], xmm10
0000786bc93d6c10  movaps [rsp+0x10], xmm12
0000786bc93d6c16  movaps [rsp+0x20], xmm11
0000786bc93d6c1c  lea rdi, [rsp]
0000786bc93d6c20  mov esi, 0x00
0000786bc93d6c25  mov rax, 0x60810F6F7530
0000786bc93d6c2f  call rax
0000786bc93d6c31  movaps xmm10, [rsp]
0000786bc93d6c36  add rsp, 0x30
0000786bc93d6c3a  vmovaps xmm0, [rsp]
0000786bc93d6c3f  vmovaps xmm1, [rsp+0x10]
0000786bc93d6c45  vmovaps xmm2, [rsp+0x20]
0000786bc93d6c4b  vmovaps xmm3, [rsp+0x30]
0000786bc93d6c51  vmovaps xmm4, [rsp+0x40]
0000786bc93d6c57  vmovaps xmm5, [rsp+0x50]
0000786bc93d6c5d  vmovaps xmm6, [rsp+0x60]
0000786bc93d6c63  vmovaps xmm7, [rsp+0x70]
0000786bc93d6c69  vmovaps xmm8, [rsp+0x80]
0000786bc93d6c72  vmovaps xmm9, [rsp+0x90]
0000786bc93d6c7b  vmovaps xmm11, [rsp+0xA0]
0000786bc93d6c84  vmovaps xmm12, [rsp+0xB0]
0000786bc93d6c8d  vmovaps xmm13, [rsp+0xC0]
0000786bc93d6c96  vmovaps xmm14, [rsp+0xD0]
0000786bc93d6c9f  vmovaps xmm15, [rsp+0xE0]
0000786bc93d6ca8  add rsp, 0xF0
0000786bc93d6caf  pop r11
0000786bc93d6cb1  pop r10
0000786bc93d6cb3  pop r9
0000786bc93d6cb5  pop r8
0000786bc93d6cb7  pop rsi
0000786bc93d6cb8  pop rdi
0000786bc93d6cb9  pop rdx
0000786bc93d6cba  pop rcx
0000786bc93d6cbb  pop rax
0000786bc93d6cbc  add rsp, 0x08
0000786bc93d6cc0  jmp 0x0000786BC93D5A06
0000786bc93d6cc5  sub rsp, 0x08
0000786bc93d6cc9  push rax
0000786bc93d6cca  push rcx
0000786bc93d6ccb  push rdx
0000786bc93d6ccc  push rdi
0000786bc93d6ccd  push rsi
0000786bc93d6cce  push r8
0000786bc93d6cd0  push r9
0000786bc93d6cd2  push r10
0000786bc93d6cd4  push r11
0000786bc93d6cd6  sub rsp, 0xF0
0000786bc93d6cdd  vmovaps [rsp], xmm0
0000786bc93d6ce2  vmovaps [rsp+0x10], xmm1
0000786bc93d6ce8  vmovaps [rsp+0x20], xmm2
0000786bc93d6cee  vmovaps [rsp+0x30], xmm3
0000786bc93d6cf4  vmovaps [rsp+0x40], xmm4
0000786bc93d6cfa  vmovaps [rsp+0x50], xmm5
0000786bc93d6d00  vmovaps [rsp+0x60], xmm7
0000786bc93d6d06  vmovaps [rsp+0x70], xmm8
0000786bc93d6d0c  vmovaps [rsp+0x80], xmm9
0000786bc93d6d15  vmovaps [rsp+0x90], xmm10
0000786bc93d6d1e  vmovaps [rsp+0xA0], xmm11
0000786bc93d6d27  vmovaps [rsp+0xB0], xmm12
0000786bc93d6d30  vmovaps [rsp+0xC0], xmm13
0000786bc93d6d39  vmovaps [rsp+0xD0], xmm14
0000786bc93d6d42  vmovaps [rsp+0xE0], xmm15
0000786bc93d6d4b  sub rsp, 0x30
0000786bc93d6d4f  movaps [rsp], xmm6
0000786bc93d6d53  movaps [rsp+0x10], xmm12
0000786bc93d6d59  movaps [rsp+0x20], xmm11
0000786bc93d6d5f  lea rdi, [rsp]
0000786bc93d6d63  mov esi, 0x00
0000786bc93d6d68  mov rax, 0x60810F6F7530
0000786bc93d6d72  call rax
0000786bc93d6d74  movaps xmm6, [rsp]
0000786bc93d6d78  add rsp, 0x30
0000786bc93d6d7c  vmovaps xmm0, [rsp]
0000786bc93d6d81  vmovaps xmm1, [rsp+0x10]
0000786bc93d6d87  vmovaps xmm2, [rsp+0x20]
0000786bc93d6d8d  vmovaps xmm3, [rsp+0x30]
0000786bc93d6d93  vmovaps xmm4, [rsp+0x40]
0000786bc93d6d99  vmovaps xmm5, [rsp+0x50]
0000786bc93d6d9f  vmovaps xmm7, [rsp+0x60]
0000786bc93d6da5  vmovaps xmm8, [rsp+0x70]
0000786bc93d6dab  vmovaps xmm9, [rsp+0x80]
0000786bc93d6db4  vmovaps xmm10, [rsp+0x90]
0000786bc93d6dbd  vmovaps xmm11, [rsp+0xA0]
0000786bc93d6dc6  vmovaps xmm12, [rsp+0xB0]
0000786bc93d6dcf  vmovaps xmm13, [rsp+0xC0]
0000786bc93d6dd8  vmovaps xmm14, [rsp+0xD0]
0000786bc93d6de1  vmovaps xmm15, [rsp+0xE0]
0000786bc93d6dea  add rsp, 0xF0
0000786bc93d6df1  pop r11
0000786bc93d6df3  pop r10
0000786bc93d6df5  pop r9
0000786bc93d6df7  pop r8
0000786bc93d6df9  pop rsi
0000786bc93d6dfa  pop rdi
0000786bc93d6dfb  pop rdx
0000786bc93d6dfc  pop rcx
0000786bc93d6dfd  pop rax
0000786bc93d6dfe  add rsp, 0x08
0000786bc93d6e02  jmp 0x0000786BC93D5A27
0000786bc93d6e07  sub rsp, 0x08
0000786bc93d6e0b  push rax
0000786bc93d6e0c  push rcx
0000786bc93d6e0d  push rdx
0000786bc93d6e0e  push rdi
0000786bc93d6e0f  push rsi
0000786bc93d6e10  push r8
0000786bc93d6e12  push r9
0000786bc93d6e14  push r10
0000786bc93d6e16  push r11
0000786bc93d6e18  sub rsp, 0xF0
0000786bc93d6e1f  vmovaps [rsp], xmm0
0000786bc93d6e24  vmovaps [rsp+0x10], xmm1
0000786bc93d6e2a  vmovaps [rsp+0x20], xmm2
0000786bc93d6e30  vmovaps [rsp+0x30], xmm4
0000786bc93d6e36  vmovaps [rsp+0x40], xmm5
0000786bc93d6e3c  vmovaps [rsp+0x50], xmm6
0000786bc93d6e42  vmovaps [rsp+0x60], xmm7
0000786bc93d6e48  vmovaps [rsp+0x70], xmm8
0000786bc93d6e4e  vmovaps [rsp+0x80], xmm9
0000786bc93d6e57  vmovaps [rsp+0x90], xmm10
0000786bc93d6e60  vmovaps [rsp+0xA0], xmm11
0000786bc93d6e69  vmovaps [rsp+0xB0], xmm12
0000786bc93d6e72  vmovaps [rsp+0xC0], xmm13
0000786bc93d6e7b  vmovaps [rsp+0xD0], xmm14
0000786bc93d6e84  vmovaps [rsp+0xE0], xmm15
0000786bc93d6e8d  sub rsp, 0x30
0000786bc93d6e91  movaps [rsp], xmm3
0000786bc93d6e95  movaps [rsp+0x10], xmm5
0000786bc93d6e9a  movaps [rsp+0x20], xmm4
0000786bc93d6e9f  lea rdi, [rsp]
0000786bc93d6ea3  mov esi, 0x00
0000786bc93d6ea8  mov rax, 0x60810F6F7530
0000786bc93d6eb2  call rax
0000786bc93d6eb4  movaps xmm3, [rsp]
0000786bc93d6eb8  add rsp, 0x30
0000786bc93d6ebc  vmovaps xmm0, [rsp]
0000786bc93d6ec1  vmovaps xmm1, [rsp+0x10]
0000786bc93d6ec7  vmovaps xmm2, [rsp+0x20]
0000786bc93d6ecd  vmovaps xmm4, [rsp+0x30]
0000786bc93d6ed3  vmovaps xmm5, [rsp+0x40]
0000786bc93d6ed9  vmovaps xmm6, [rsp+0x50]
0000786bc93d6edf  vmovaps xmm7, [rsp+0x60]
0000786bc93d6ee5  vmovaps xmm8, [rsp+0x70]
0000786bc93d6eeb  vmovaps xmm9, [rsp+0x80]
0000786bc93d6ef4  vmovaps xmm10, [rsp+0x90]
0000786bc93d6efd  vmovaps xmm11, [rsp+0xA0]
0000786bc93d6f06  vmovaps xmm12, [rsp+0xB0]
0000786bc93d6f0f  vmovaps xmm13, [rsp+0xC0]
0000786bc93d6f18  vmovaps xmm14, [rsp+0xD0]
0000786bc93d6f21  vmovaps xmm15, [rsp+0xE0]
0000786bc93d6f2a  add rsp, 0xF0
0000786bc93d6f31  pop r11
0000786bc93d6f33  pop r10
0000786bc93d6f35  pop r9
0000786bc93d6f37  pop r8
0000786bc93d6f39  pop rsi
0000786bc93d6f3a  pop rdi
0000786bc93d6f3b  pop rdx
0000786bc93d6f3c  pop rcx
0000786bc93d6f3d  pop rax
0000786bc93d6f3e  add rsp, 0x08
0000786bc93d6f42  jmp 0x0000786BC93D5A88
0000786bc93d6f47  sub rsp, 0x08
0000786bc93d6f4b  push rax
0000786bc93d6f4c  push rcx
0000786bc93d6f4d  push rdx
0000786bc93d6f4e  push rdi
0000786bc93d6f4f  push rsi
0000786bc93d6f50  push r8
0000786bc93d6f52  push r9
0000786bc93d6f54  push r10
0000786bc93d6f56  push r11
0000786bc93d6f58  sub rsp, 0xF0
0000786bc93d6f5f  vmovaps [rsp], xmm0
0000786bc93d6f64  vmovaps [rsp+0x10], xmm1
0000786bc93d6f6a  vmovaps [rsp+0x20], xmm2
0000786bc93d6f70  vmovaps [rsp+0x30], xmm3
0000786bc93d6f76  vmovaps [rsp+0x40], xmm4
0000786bc93d6f7c  vmovaps [rsp+0x50], xmm6
0000786bc93d6f82  vmovaps [rsp+0x60], xmm7
0000786bc93d6f88  vmovaps [rsp+0x70], xmm8
0000786bc93d6f8e  vmovaps [rsp+0x80], xmm9
0000786bc93d6f97  vmovaps [rsp+0x90], xmm10
0000786bc93d6fa0  vmovaps [rsp+0xA0], xmm11
0000786bc93d6fa9  vmovaps [rsp+0xB0], xmm12
0000786bc93d6fb2  vmovaps [rsp+0xC0], xmm13
0000786bc93d6fbb  vmovaps [rsp+0xD0], xmm14
0000786bc93d6fc4  vmovaps [rsp+0xE0], xmm15
0000786bc93d6fcd  sub rsp, 0x30
0000786bc93d6fd1  movaps [rsp], xmm5
0000786bc93d6fd5  movaps [rsp+0x10], xmm8
0000786bc93d6fdb  movaps [rsp+0x20], xmm15
0000786bc93d6fe1  lea rdi, [rsp]
0000786bc93d6fe5  mov esi, 0x00
0000786bc93d6fea  mov rax, 0x60810F6F7530
0000786bc93d6ff4  call rax
0000786bc93d6ff6  movaps xmm5, [rsp]
0000786bc93d6ffa  add rsp, 0x30
0000786bc93d6ffe  vmovaps xmm0, [rsp]
0000786bc93d7003  vmovaps xmm1, [rsp+0x10]
0000786bc93d7009  vmovaps xmm2, [rsp+0x20]
0000786bc93d700f  vmovaps xmm3, [rsp+0x30]
0000786bc93d7015  vmovaps xmm4, [rsp+0x40]
0000786bc93d701b  vmovaps xmm6, [rsp+0x50]
0000786bc93d7021  vmovaps xmm7, [rsp+0x60]
0000786bc93d7027  vmovaps xmm8, [rsp+0x70]
0000786bc93d702d  vmovaps xmm9, [rsp+0x80]
0000786bc93d7036  vmovaps xmm10, [rsp+0x90]
0000786bc93d703f  vmovaps xmm11, [rsp+0xA0]
0000786bc93d7048  vmovaps xmm12, [rsp+0xB0]
0000786bc93d7051  vmovaps xmm13, [rsp+0xC0]
0000786bc93d705a  vmovaps xmm14, [rsp+0xD0]
0000786bc93d7063  vmovaps xmm15, [rsp+0xE0]
0000786bc93d706c  add rsp, 0xF0
0000786bc93d7073  pop r11
0000786bc93d7075  pop r10
0000786bc93d7077  pop r9
0000786bc93d7079  pop r8
0000786bc93d707b  pop rsi
0000786bc93d707c  pop rdi
0000786bc93d707d  pop rdx
0000786bc93d707e  pop rcx
0000786bc93d707f  pop rax
0000786bc93d7080  add rsp, 0x08
0000786bc93d7084  jmp 0x0000786BC93D5AC0
0000786bc93d7089  sub rsp, 0x08
0000786bc93d708d  push rax
0000786bc93d708e  push rcx
0000786bc93d708f  push rdx
0000786bc93d7090  push rdi
0000786bc93d7091  push rsi
0000786bc93d7092  push r8
0000786bc93d7094  push r9
0000786bc93d7096  push r10
0000786bc93d7098  push r11
0000786bc93d709a  sub rsp, 0xF0
0000786bc93d70a1  vmovaps [rsp], xmm0
0000786bc93d70a6  vmovaps [rsp+0x10], xmm1
0000786bc93d70ac  vmovaps [rsp+0x20], xmm2
0000786bc93d70b2  vmovaps [rsp+0x30], xmm3
0000786bc93d70b8  vmovaps [rsp+0x40], xmm5
0000786bc93d70be  vmovaps [rsp+0x50], xmm6
0000786bc93d70c4  vmovaps [rsp+0x60], xmm7
0000786bc93d70ca  vmovaps [rsp+0x70], xmm8
0000786bc93d70d0  vmovaps [rsp+0x80], xmm9
0000786bc93d70d9  vmovaps [rsp+0x90], xmm10
0000786bc93d70e2  vmovaps [rsp+0xA0], xmm11
0000786bc93d70eb  vmovaps [rsp+0xB0], xmm12
0000786bc93d70f4  vmovaps [rsp+0xC0], xmm13
0000786bc93d70fd  vmovaps [rsp+0xD0], xmm14
0000786bc93d7106  vmovaps [rsp+0xE0], xmm15
0000786bc93d710f  sub rsp, 0x30
0000786bc93d7113  movaps [rsp], xmm4
0000786bc93d7117  movaps [rsp+0x10], xmm9
0000786bc93d711d  movaps [rsp+0x20], xmm8
0000786bc93d7123  lea rdi, [rsp]
0000786bc93d7127  mov esi, 0x00
0000786bc93d712c  mov rax, 0x60810F6F7530
0000786bc93d7136  call rax
0000786bc93d7138  movaps xmm4, [rsp]
0000786bc93d713c  add rsp, 0x30
0000786bc93d7140  vmovaps xmm0, [rsp]
0000786bc93d7145  vmovaps xmm1, [rsp+0x10]
0000786bc93d714b  vmovaps xmm2, [rsp+0x20]
0000786bc93d7151  vmovaps xmm3, [rsp+0x30]
0000786bc93d7157  vmovaps xmm5, [rsp+0x40]
0000786bc93d715d  vmovaps xmm6, [rsp+0x50]
0000786bc93d7163  vmovaps xmm7, [rsp+0x60]
0000786bc93d7169  vmovaps xmm8, [rsp+0x70]
0000786bc93d716f  vmovaps xmm9, [rsp+0x80]
0000786bc93d7178  vmovaps xmm10, [rsp+0x90]
0000786bc93d7181  vmovaps xmm11, [rsp+0xA0]
0000786bc93d718a  vmovaps xmm12, [rsp+0xB0]
0000786bc93d7193  vmovaps xmm13, [rsp+0xC0]
0000786bc93d719c  vmovaps xmm14, [rsp+0xD0]
0000786bc93d71a5  vmovaps xmm15, [rsp+0xE0]
0000786bc93d71ae  add rsp, 0xF0
0000786bc93d71b5  pop r11
0000786bc93d71b7  pop r10
0000786bc93d71b9  pop r9
0000786bc93d71bb  pop r8
0000786bc93d71bd  pop rsi
0000786bc93d71be  pop rdi
0000786bc93d71bf  pop rdx
0000786bc93d71c0  pop rcx
0000786bc93d71c1  pop rax
0000786bc93d71c2  add rsp, 0x08
0000786bc93d71c6  jmp 0x0000786BC93D5AE1
0000786bc93d71cb  sub rsp, 0x08
0000786bc93d71cf  push rax
0000786bc93d71d0  push rcx
0000786bc93d71d1  push rdx
0000786bc93d71d2  push rdi
0000786bc93d71d3  push rsi
0000786bc93d71d4  push r8
0000786bc93d71d6  push r9
0000786bc93d71d8  push r10
0000786bc93d71da  push r11
0000786bc93d71dc  sub rsp, 0xF0
0000786bc93d71e3  vmovaps [rsp], xmm0
0000786bc93d71e8  vmovaps [rsp+0x10], xmm1
0000786bc93d71ee  vmovaps [rsp+0x20], xmm2
0000786bc93d71f4  vmovaps [rsp+0x30], xmm3
0000786bc93d71fa  vmovaps [rsp+0x40], xmm4
0000786bc93d7200  vmovaps [rsp+0x50], xmm5
0000786bc93d7206  vmovaps [rsp+0x60], xmm6
0000786bc93d720c  vmovaps [rsp+0x70], xmm7
0000786bc93d7212  vmovaps [rsp+0x80], xmm8
0000786bc93d721b  vmovaps [rsp+0x90], xmm10
0000786bc93d7224  vmovaps [rsp+0xA0], xmm11
0000786bc93d722d  vmovaps [rsp+0xB0], xmm12
0000786bc93d7236  vmovaps [rsp+0xC0], xmm13
0000786bc93d723f  vmovaps [rsp+0xD0], xmm14
0000786bc93d7248  vmovaps [rsp+0xE0], xmm15
0000786bc93d7251  sub rsp, 0x30
0000786bc93d7255  movaps [rsp], xmm9
0000786bc93d725a  movaps [rsp+0x10], xmm10
0000786bc93d7260  movaps [rsp+0x20], xmm8
0000786bc93d7266  lea rdi, [rsp]
0000786bc93d726a  mov esi, 0x00
0000786bc93d726f  mov rax, 0x60810F6F7530
0000786bc93d7279  call rax
0000786bc93d727b  movaps xmm9, [rsp]
0000786bc93d7280  add rsp, 0x30
0000786bc93d7284  vmovaps xmm0, [rsp]
0000786bc93d7289  vmovaps xmm1, [rsp+0x10]
0000786bc93d728f  vmovaps xmm2, [rsp+0x20]
0000786bc93d7295  vmovaps xmm3, [rsp+0x30]
0000786bc93d729b  vmovaps xmm4, [rsp+0x40]
0000786bc93d72a1  vmovaps xmm5, [rsp+0x50]
0000786bc93d72a7  vmovaps xmm6, [rsp+0x60]
0000786bc93d72ad  vmovaps xmm7, [rsp+0x70]
0000786bc93d72b3  vmovaps xmm8, [rsp+0x80]
0000786bc93d72bc  vmovaps xmm10, [rsp+0x90]
0000786bc93d72c5  vmovaps xmm11, [rsp+0xA0]
0000786bc93d72ce  vmovaps xmm12, [rsp+0xB0]
0000786bc93d72d7  vmovaps xmm13, [rsp+0xC0]
0000786bc93d72e0  vmovaps xmm14, [rsp+0xD0]
0000786bc93d72e9  vmovaps xmm15, [rsp+0xE0]
0000786bc93d72f2  add rsp, 0xF0
0000786bc93d72f9  pop r11
0000786bc93d72fb  pop r10
0000786bc93d72fd  pop r9
0000786bc93d72ff  pop r8
0000786bc93d7301  pop rsi
0000786bc93d7302  pop rdi
0000786bc93d7303  pop rdx
0000786bc93d7304  pop rcx
0000786bc93d7305  pop rax
0000786bc93d7306  add rsp, 0x08
0000786bc93d730a  jmp 0x0000786BC93D5AFB
0000786bc93d730f  call 0x0000786BC92D64F0
0000786bc93d7314  jmp 0x0000786BC93D5C15
0000786bc93d7319  call 0x0000786BC92D64F0
0000786bc93d731e  jmp 0x0000786BC93D5C2B
0000786bc93d7323  sub rsp, 0x08
0000786bc93d7327  push rax
0000786bc93d7328  push rcx
0000786bc93d7329  push rdx
0000786bc93d732a  push rdi
0000786bc93d732b  push rsi
0000786bc93d732c  push r8
0000786bc93d732e  push r9
0000786bc93d7330  push r10
0000786bc93d7332  push r11
0000786bc93d7334  sub rsp, 0xF0
0000786bc93d733b  vmovaps [rsp], xmm0
0000786bc93d7340  vmovaps [rsp+0x10], xmm2
0000786bc93d7346  vmovaps [rsp+0x20], xmm3
0000786bc93d734c  vmovaps [rsp+0x30], xmm4
0000786bc93d7352  vmovaps [rsp+0x40], xmm5
0000786bc93d7358  vmovaps [rsp+0x50], xmm6
0000786bc93d735e  vmovaps [rsp+0x60], xmm7
0000786bc93d7364  vmovaps [rsp+0x70], xmm8
0000786bc93d736a  vmovaps [rsp+0x80], xmm9
0000786bc93d7373  vmovaps [rsp+0x90], xmm10
0000786bc93d737c  vmovaps [rsp+0xA0], xmm11
0000786bc93d7385  vmovaps [rsp+0xB0], xmm12
0000786bc93d738e  vmovaps [rsp+0xC0], xmm13
0000786bc93d7397  vmovaps [rsp+0xD0], xmm14
0000786bc93d73a0  vmovaps [rsp+0xE0], xmm15
0000786bc93d73a9  sub rsp, 0x30
0000786bc93d73ad  movaps [rsp], xmm1
0000786bc93d73b1  movaps [rsp+0x10], xmm6
0000786bc93d73b6  movaps [rsp+0x20], xmm15
0000786bc93d73bc  lea rdi, [rsp]
0000786bc93d73c0  mov esi, 0x00
0000786bc93d73c5  mov rax, 0x60810F6F7530
0000786bc93d73cf  call rax
0000786bc93d73d1  movaps xmm1, [rsp]
0000786bc93d73d5  add rsp, 0x30
0000786bc93d73d9  vmovaps xmm0, [rsp]
0000786bc93d73de  vmovaps xmm2, [rsp+0x10]
0000786bc93d73e4  vmovaps xmm3, [rsp+0x20]
0000786bc93d73ea  vmovaps xmm4, [rsp+0x30]
0000786bc93d73f0  vmovaps xmm5, [rsp+0x40]
0000786bc93d73f6  vmovaps xmm6, [rsp+0x50]
0000786bc93d73fc  vmovaps xmm7, [rsp+0x60]
0000786bc93d7402  vmovaps xmm8, [rsp+0x70]
0000786bc93d7408  vmovaps xmm9, [rsp+0x80]
0000786bc93d7411  vmovaps xmm10, [rsp+0x90]
0000786bc93d741a  vmovaps xmm11, [rsp+0xA0]
0000786bc93d7423  vmovaps xmm12, [rsp+0xB0]
0000786bc93d742c  vmovaps xmm13, [rsp+0xC0]
0000786bc93d7435  vmovaps xmm14, [rsp+0xD0]
0000786bc93d743e  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7447  add rsp, 0xF0
0000786bc93d744e  pop r11
0000786bc93d7450  pop r10
0000786bc93d7452  pop r9
0000786bc93d7454  pop r8
0000786bc93d7456  pop rsi
0000786bc93d7457  pop rdi
0000786bc93d7458  pop rdx
0000786bc93d7459  pop rcx
0000786bc93d745a  pop rax
0000786bc93d745b  add rsp, 0x08
0000786bc93d745f  jmp 0x0000786BC93D5C68
0000786bc93d7464  call 0x0000786BC92E5820
0000786bc93d7469  jmp 0x0000786BC93D5C75
0000786bc93d746e  sub rsp, 0x08
0000786bc93d7472  push rax
0000786bc93d7473  push rcx
0000786bc93d7474  push rdx
0000786bc93d7475  push rdi
0000786bc93d7476  push rsi
0000786bc93d7477  push r8
0000786bc93d7479  push r9
0000786bc93d747b  push r10
0000786bc93d747d  push r11
0000786bc93d747f  sub rsp, 0xF0
0000786bc93d7486  vmovaps [rsp], xmm0
0000786bc93d748b  vmovaps [rsp+0x10], xmm1
0000786bc93d7491  vmovaps [rsp+0x20], xmm2
0000786bc93d7497  vmovaps [rsp+0x30], xmm3
0000786bc93d749d  vmovaps [rsp+0x40], xmm4
0000786bc93d74a3  vmovaps [rsp+0x50], xmm5
0000786bc93d74a9  vmovaps [rsp+0x60], xmm6
0000786bc93d74af  vmovaps [rsp+0x70], xmm7
0000786bc93d74b5  vmovaps [rsp+0x80], xmm8
0000786bc93d74be  vmovaps [rsp+0x90], xmm9
0000786bc93d74c7  vmovaps [rsp+0xA0], xmm10
0000786bc93d74d0  vmovaps [rsp+0xB0], xmm11
0000786bc93d74d9  vmovaps [rsp+0xC0], xmm12
0000786bc93d74e2  vmovaps [rsp+0xD0], xmm13
0000786bc93d74eb  vmovaps [rsp+0xE0], xmm15
0000786bc93d74f4  sub rsp, 0x30
0000786bc93d74f8  movaps [rsp], xmm14
0000786bc93d74fd  movaps [rsp+0x10], xmm4
0000786bc93d7502  movaps [rsp+0x20], xmm3
0000786bc93d7507  lea rdi, [rsp]
0000786bc93d750b  mov esi, 0x00
0000786bc93d7510  mov rax, 0x60810F6F7530
0000786bc93d751a  call rax
0000786bc93d751c  movaps xmm14, [rsp]
0000786bc93d7521  add rsp, 0x30
0000786bc93d7525  vmovaps xmm0, [rsp]
0000786bc93d752a  vmovaps xmm1, [rsp+0x10]
0000786bc93d7530  vmovaps xmm2, [rsp+0x20]
0000786bc93d7536  vmovaps xmm3, [rsp+0x30]
0000786bc93d753c  vmovaps xmm4, [rsp+0x40]
0000786bc93d7542  vmovaps xmm5, [rsp+0x50]
0000786bc93d7548  vmovaps xmm6, [rsp+0x60]
0000786bc93d754e  vmovaps xmm7, [rsp+0x70]
0000786bc93d7554  vmovaps xmm8, [rsp+0x80]
0000786bc93d755d  vmovaps xmm9, [rsp+0x90]
0000786bc93d7566  vmovaps xmm10, [rsp+0xA0]
0000786bc93d756f  vmovaps xmm11, [rsp+0xB0]
0000786bc93d7578  vmovaps xmm12, [rsp+0xC0]
0000786bc93d7581  vmovaps xmm13, [rsp+0xD0]
0000786bc93d758a  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7593  add rsp, 0xF0
0000786bc93d759a  pop r11
0000786bc93d759c  pop r10
0000786bc93d759e  pop r9
0000786bc93d75a0  pop r8
0000786bc93d75a2  pop rsi
0000786bc93d75a3  pop rdi
0000786bc93d75a4  pop rdx
0000786bc93d75a5  pop rcx
0000786bc93d75a6  pop rax
0000786bc93d75a7  add rsp, 0x08
0000786bc93d75ab  jmp 0x0000786BC93D5C8F
0000786bc93d75b0  sub rsp, 0x08
0000786bc93d75b4  push rax
0000786bc93d75b5  push rcx
0000786bc93d75b6  push rdx
0000786bc93d75b7  push rdi
0000786bc93d75b8  push rsi
0000786bc93d75b9  push r8
0000786bc93d75bb  push r9
0000786bc93d75bd  push r10
0000786bc93d75bf  push r11
0000786bc93d75c1  sub rsp, 0xF0
0000786bc93d75c8  vmovaps [rsp], xmm0
0000786bc93d75cd  vmovaps [rsp+0x10], xmm1
0000786bc93d75d3  vmovaps [rsp+0x20], xmm2
0000786bc93d75d9  vmovaps [rsp+0x30], xmm3
0000786bc93d75df  vmovaps [rsp+0x40], xmm4
0000786bc93d75e5  vmovaps [rsp+0x50], xmm5
0000786bc93d75eb  vmovaps [rsp+0x60], xmm7
0000786bc93d75f1  vmovaps [rsp+0x70], xmm8
0000786bc93d75f7  vmovaps [rsp+0x80], xmm9
0000786bc93d7600  vmovaps [rsp+0x90], xmm10
0000786bc93d7609  vmovaps [rsp+0xA0], xmm11
0000786bc93d7612  vmovaps [rsp+0xB0], xmm12
0000786bc93d761b  vmovaps [rsp+0xC0], xmm13
0000786bc93d7624  vmovaps [rsp+0xD0], xmm14
0000786bc93d762d  vmovaps [rsp+0xE0], xmm15
0000786bc93d7636  sub rsp, 0x30
0000786bc93d763a  movaps [rsp], xmm6
0000786bc93d763e  movaps [rsp+0x10], xmm9
0000786bc93d7644  movaps [rsp+0x20], xmm7
0000786bc93d7649  lea rdi, [rsp]
0000786bc93d764d  mov esi, 0x00
0000786bc93d7652  mov rax, 0x60810F6F7530
0000786bc93d765c  call rax
0000786bc93d765e  movaps xmm6, [rsp]
0000786bc93d7662  add rsp, 0x30
0000786bc93d7666  vmovaps xmm0, [rsp]
0000786bc93d766b  vmovaps xmm1, [rsp+0x10]
0000786bc93d7671  vmovaps xmm2, [rsp+0x20]
0000786bc93d7677  vmovaps xmm3, [rsp+0x30]
0000786bc93d767d  vmovaps xmm4, [rsp+0x40]
0000786bc93d7683  vmovaps xmm5, [rsp+0x50]
0000786bc93d7689  vmovaps xmm7, [rsp+0x60]
0000786bc93d768f  vmovaps xmm8, [rsp+0x70]
0000786bc93d7695  vmovaps xmm9, [rsp+0x80]
0000786bc93d769e  vmovaps xmm10, [rsp+0x90]
0000786bc93d76a7  vmovaps xmm11, [rsp+0xA0]
0000786bc93d76b0  vmovaps xmm12, [rsp+0xB0]
0000786bc93d76b9  vmovaps xmm13, [rsp+0xC0]
0000786bc93d76c2  vmovaps xmm14, [rsp+0xD0]
0000786bc93d76cb  vmovaps xmm15, [rsp+0xE0]
0000786bc93d76d4  add rsp, 0xF0
0000786bc93d76db  pop r11
0000786bc93d76dd  pop r10
0000786bc93d76df  pop r9
0000786bc93d76e1  pop r8
0000786bc93d76e3  pop rsi
0000786bc93d76e4  pop rdi
0000786bc93d76e5  pop rdx
0000786bc93d76e6  pop rcx
0000786bc93d76e7  pop rax
0000786bc93d76e8  add rsp, 0x08
0000786bc93d76ec  jmp 0x0000786BC93D5CA7
0000786bc93d76f1  sub rsp, 0x08
0000786bc93d76f5  push rax
0000786bc93d76f6  push rcx
0000786bc93d76f7  push rdx
0000786bc93d76f8  push rdi
0000786bc93d76f9  push rsi
0000786bc93d76fa  push r8
0000786bc93d76fc  push r9
0000786bc93d76fe  push r10
0000786bc93d7700  push r11
0000786bc93d7702  sub rsp, 0xF0
0000786bc93d7709  vmovaps [rsp], xmm0
0000786bc93d770e  vmovaps [rsp+0x10], xmm1
0000786bc93d7714  vmovaps [rsp+0x20], xmm2
0000786bc93d771a  vmovaps [rsp+0x30], xmm3
0000786bc93d7720  vmovaps [rsp+0x40], xmm4
0000786bc93d7726  vmovaps [rsp+0x50], xmm5
0000786bc93d772c  vmovaps [rsp+0x60], xmm6
0000786bc93d7732  vmovaps [rsp+0x70], xmm8
0000786bc93d7738  vmovaps [rsp+0x80], xmm9
0000786bc93d7741  vmovaps [rsp+0x90], xmm10
0000786bc93d774a  vmovaps [rsp+0xA0], xmm11
0000786bc93d7753  vmovaps [rsp+0xB0], xmm12
0000786bc93d775c  vmovaps [rsp+0xC0], xmm13
0000786bc93d7765  vmovaps [rsp+0xD0], xmm14
0000786bc93d776e  vmovaps [rsp+0xE0], xmm15
0000786bc93d7777  sub rsp, 0x30
0000786bc93d777b  movaps [rsp], xmm7
0000786bc93d777f  movaps [rsp+0x10], xmm4
0000786bc93d7784  movaps [rsp+0x20], xmm9
0000786bc93d778a  lea rdi, [rsp]
0000786bc93d778e  mov esi, 0x00
0000786bc93d7793  mov rax, 0x60810F6F7530
0000786bc93d779d  call rax
0000786bc93d779f  movaps xmm7, [rsp]
0000786bc93d77a3  add rsp, 0x30
0000786bc93d77a7  vmovaps xmm0, [rsp]
0000786bc93d77ac  vmovaps xmm1, [rsp+0x10]
0000786bc93d77b2  vmovaps xmm2, [rsp+0x20]
0000786bc93d77b8  vmovaps xmm3, [rsp+0x30]
0000786bc93d77be  vmovaps xmm4, [rsp+0x40]
0000786bc93d77c4  vmovaps xmm5, [rsp+0x50]
0000786bc93d77ca  vmovaps xmm6, [rsp+0x60]
0000786bc93d77d0  vmovaps xmm8, [rsp+0x70]
0000786bc93d77d6  vmovaps xmm9, [rsp+0x80]
0000786bc93d77df  vmovaps xmm10, [rsp+0x90]
0000786bc93d77e8  vmovaps xmm11, [rsp+0xA0]
0000786bc93d77f1  vmovaps xmm12, [rsp+0xB0]
0000786bc93d77fa  vmovaps xmm13, [rsp+0xC0]
0000786bc93d7803  vmovaps xmm14, [rsp+0xD0]
0000786bc93d780c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7815  add rsp, 0xF0
0000786bc93d781c  pop r11
0000786bc93d781e  pop r10
0000786bc93d7820  pop r9
0000786bc93d7822  pop r8
0000786bc93d7824  pop rsi
0000786bc93d7825  pop rdi
0000786bc93d7826  pop rdx
0000786bc93d7827  pop rcx
0000786bc93d7828  pop rax
0000786bc93d7829  add rsp, 0x08
0000786bc93d782d  jmp 0x0000786BC93D5CD4
0000786bc93d7832  sub rsp, 0x08
0000786bc93d7836  push rax
0000786bc93d7837  push rcx
0000786bc93d7838  push rdx
0000786bc93d7839  push rdi
0000786bc93d783a  push rsi
0000786bc93d783b  push r8
0000786bc93d783d  push r9
0000786bc93d783f  push r10
0000786bc93d7841  push r11
0000786bc93d7843  sub rsp, 0xF0
0000786bc93d784a  vmovaps [rsp], xmm0
0000786bc93d784f  vmovaps [rsp+0x10], xmm1
0000786bc93d7855  vmovaps [rsp+0x20], xmm2
0000786bc93d785b  vmovaps [rsp+0x30], xmm3
0000786bc93d7861  vmovaps [rsp+0x40], xmm5
0000786bc93d7867  vmovaps [rsp+0x50], xmm6
0000786bc93d786d  vmovaps [rsp+0x60], xmm7
0000786bc93d7873  vmovaps [rsp+0x70], xmm8
0000786bc93d7879  vmovaps [rsp+0x80], xmm9
0000786bc93d7882  vmovaps [rsp+0x90], xmm10
0000786bc93d788b  vmovaps [rsp+0xA0], xmm11
0000786bc93d7894  vmovaps [rsp+0xB0], xmm12
0000786bc93d789d  vmovaps [rsp+0xC0], xmm13
0000786bc93d78a6  vmovaps [rsp+0xD0], xmm14
0000786bc93d78af  vmovaps [rsp+0xE0], xmm15
0000786bc93d78b8  sub rsp, 0x30
0000786bc93d78bc  movaps [rsp], xmm4
0000786bc93d78c0  movaps [rsp+0x10], xmm15
0000786bc93d78c6  movaps [rsp+0x20], xmm9
0000786bc93d78cc  lea rdi, [rsp]
0000786bc93d78d0  mov esi, 0x00
0000786bc93d78d5  mov rax, 0x60810F6F7530
0000786bc93d78df  call rax
0000786bc93d78e1  movaps xmm4, [rsp]
0000786bc93d78e5  add rsp, 0x30
0000786bc93d78e9  vmovaps xmm0, [rsp]
0000786bc93d78ee  vmovaps xmm1, [rsp+0x10]
0000786bc93d78f4  vmovaps xmm2, [rsp+0x20]
0000786bc93d78fa  vmovaps xmm3, [rsp+0x30]
0000786bc93d7900  vmovaps xmm5, [rsp+0x40]
0000786bc93d7906  vmovaps xmm6, [rsp+0x50]
0000786bc93d790c  vmovaps xmm7, [rsp+0x60]
0000786bc93d7912  vmovaps xmm8, [rsp+0x70]
0000786bc93d7918  vmovaps xmm9, [rsp+0x80]
0000786bc93d7921  vmovaps xmm10, [rsp+0x90]
0000786bc93d792a  vmovaps xmm11, [rsp+0xA0]
0000786bc93d7933  vmovaps xmm12, [rsp+0xB0]
0000786bc93d793c  vmovaps xmm13, [rsp+0xC0]
0000786bc93d7945  vmovaps xmm14, [rsp+0xD0]
0000786bc93d794e  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7957  add rsp, 0xF0
0000786bc93d795e  pop r11
0000786bc93d7960  pop r10
0000786bc93d7962  pop r9
0000786bc93d7964  pop r8
0000786bc93d7966  pop rsi
0000786bc93d7967  pop rdi
0000786bc93d7968  pop rdx
0000786bc93d7969  pop rcx
0000786bc93d796a  pop rax
0000786bc93d796b  add rsp, 0x08
0000786bc93d796f  jmp 0x0000786BC93D5CF9
0000786bc93d7974  call 0x0000786BC92E5820
0000786bc93d7979  jmp 0x0000786BC93D5D06
0000786bc93d797e  sub rsp, 0x08
0000786bc93d7982  push rax
0000786bc93d7983  push rcx
0000786bc93d7984  push rdx
0000786bc93d7985  push rdi
0000786bc93d7986  push rsi
0000786bc93d7987  push r8
0000786bc93d7989  push r9
0000786bc93d798b  push r10
0000786bc93d798d  push r11
0000786bc93d798f  sub rsp, 0xF0
0000786bc93d7996  vmovaps [rsp], xmm0
0000786bc93d799b  vmovaps [rsp+0x10], xmm1
0000786bc93d79a1  vmovaps [rsp+0x20], xmm2
0000786bc93d79a7  vmovaps [rsp+0x30], xmm4
0000786bc93d79ad  vmovaps [rsp+0x40], xmm5
0000786bc93d79b3  vmovaps [rsp+0x50], xmm6
0000786bc93d79b9  vmovaps [rsp+0x60], xmm7
0000786bc93d79bf  vmovaps [rsp+0x70], xmm8
0000786bc93d79c5  vmovaps [rsp+0x80], xmm9
0000786bc93d79ce  vmovaps [rsp+0x90], xmm10
0000786bc93d79d7  vmovaps [rsp+0xA0], xmm11
0000786bc93d79e0  vmovaps [rsp+0xB0], xmm12
0000786bc93d79e9  vmovaps [rsp+0xC0], xmm13
0000786bc93d79f2  vmovaps [rsp+0xD0], xmm14
0000786bc93d79fb  vmovaps [rsp+0xE0], xmm15
0000786bc93d7a04  sub rsp, 0x30
0000786bc93d7a08  movaps [rsp], xmm3
0000786bc93d7a0c  movaps [rsp+0x10], xmm1
0000786bc93d7a11  movaps [rsp+0x20], xmm9
0000786bc93d7a17  lea rdi, [rsp]
0000786bc93d7a1b  mov esi, 0x00
0000786bc93d7a20  mov rax, 0x60810F6F7530
0000786bc93d7a2a  call rax
0000786bc93d7a2c  movaps xmm3, [rsp]
0000786bc93d7a30  add rsp, 0x30
0000786bc93d7a34  vmovaps xmm0, [rsp]
0000786bc93d7a39  vmovaps xmm1, [rsp+0x10]
0000786bc93d7a3f  vmovaps xmm2, [rsp+0x20]
0000786bc93d7a45  vmovaps xmm4, [rsp+0x30]
0000786bc93d7a4b  vmovaps xmm5, [rsp+0x40]
0000786bc93d7a51  vmovaps xmm6, [rsp+0x50]
0000786bc93d7a57  vmovaps xmm7, [rsp+0x60]
0000786bc93d7a5d  vmovaps xmm8, [rsp+0x70]
0000786bc93d7a63  vmovaps xmm9, [rsp+0x80]
0000786bc93d7a6c  vmovaps xmm10, [rsp+0x90]
0000786bc93d7a75  vmovaps xmm11, [rsp+0xA0]
0000786bc93d7a7e  vmovaps xmm12, [rsp+0xB0]
0000786bc93d7a87  vmovaps xmm13, [rsp+0xC0]
0000786bc93d7a90  vmovaps xmm14, [rsp+0xD0]
0000786bc93d7a99  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7aa2  add rsp, 0xF0
0000786bc93d7aa9  pop r11
0000786bc93d7aab  pop r10
0000786bc93d7aad  pop r9
0000786bc93d7aaf  pop r8
0000786bc93d7ab1  pop rsi
0000786bc93d7ab2  pop rdi
0000786bc93d7ab3  pop rdx
0000786bc93d7ab4  pop rcx
0000786bc93d7ab5  pop rax
0000786bc93d7ab6  add rsp, 0x08
0000786bc93d7aba  jmp 0x0000786BC93D5D43
0000786bc93d7abf  sub rsp, 0x08
0000786bc93d7ac3  push rax
0000786bc93d7ac4  push rcx
0000786bc93d7ac5  push rdx
0000786bc93d7ac6  push rdi
0000786bc93d7ac7  push rsi
0000786bc93d7ac8  push r8
0000786bc93d7aca  push r9
0000786bc93d7acc  push r10
0000786bc93d7ace  push r11
0000786bc93d7ad0  sub rsp, 0xF0
0000786bc93d7ad7  vmovaps [rsp], xmm0
0000786bc93d7adc  vmovaps [rsp+0x10], xmm2
0000786bc93d7ae2  vmovaps [rsp+0x20], xmm3
0000786bc93d7ae8  vmovaps [rsp+0x30], xmm4
0000786bc93d7aee  vmovaps [rsp+0x40], xmm5
0000786bc93d7af4  vmovaps [rsp+0x50], xmm6
0000786bc93d7afa  vmovaps [rsp+0x60], xmm7
0000786bc93d7b00  vmovaps [rsp+0x70], xmm8
0000786bc93d7b06  vmovaps [rsp+0x80], xmm9
0000786bc93d7b0f  vmovaps [rsp+0x90], xmm10
0000786bc93d7b18  vmovaps [rsp+0xA0], xmm11
0000786bc93d7b21  vmovaps [rsp+0xB0], xmm12
0000786bc93d7b2a  vmovaps [rsp+0xC0], xmm13
0000786bc93d7b33  vmovaps [rsp+0xD0], xmm14
0000786bc93d7b3c  vmovaps [rsp+0xE0], xmm15
0000786bc93d7b45  sub rsp, 0x30
0000786bc93d7b49  movaps [rsp], xmm1
0000786bc93d7b4d  movaps [rsp+0x10], xmm15
0000786bc93d7b53  movaps [rsp+0x20], xmm9
0000786bc93d7b59  lea rdi, [rsp]
0000786bc93d7b5d  mov esi, 0x00
0000786bc93d7b62  mov rax, 0x60810F6F7530
0000786bc93d7b6c  call rax
0000786bc93d7b6e  movaps xmm1, [rsp]
0000786bc93d7b72  add rsp, 0x30
0000786bc93d7b76  vmovaps xmm0, [rsp]
0000786bc93d7b7b  vmovaps xmm2, [rsp+0x10]
0000786bc93d7b81  vmovaps xmm3, [rsp+0x20]
0000786bc93d7b87  vmovaps xmm4, [rsp+0x30]
0000786bc93d7b8d  vmovaps xmm5, [rsp+0x40]
0000786bc93d7b93  vmovaps xmm6, [rsp+0x50]
0000786bc93d7b99  vmovaps xmm7, [rsp+0x60]
0000786bc93d7b9f  vmovaps xmm8, [rsp+0x70]
0000786bc93d7ba5  vmovaps xmm9, [rsp+0x80]
0000786bc93d7bae  vmovaps xmm10, [rsp+0x90]
0000786bc93d7bb7  vmovaps xmm11, [rsp+0xA0]
0000786bc93d7bc0  vmovaps xmm12, [rsp+0xB0]
0000786bc93d7bc9  vmovaps xmm13, [rsp+0xC0]
0000786bc93d7bd2  vmovaps xmm14, [rsp+0xD0]
0000786bc93d7bdb  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7be4  add rsp, 0xF0
0000786bc93d7beb  pop r11
0000786bc93d7bed  pop r10
0000786bc93d7bef  pop r9
0000786bc93d7bf1  pop r8
0000786bc93d7bf3  pop rsi
0000786bc93d7bf4  pop rdi
0000786bc93d7bf5  pop rdx
0000786bc93d7bf6  pop rcx
0000786bc93d7bf7  pop rax
0000786bc93d7bf8  add rsp, 0x08
0000786bc93d7bfc  jmp 0x0000786BC93D5DCB
0000786bc93d7c01  call 0x0000786BC92E5820
0000786bc93d7c06  jmp 0x0000786BC93D5DD8
0000786bc93d7c0b  sub rsp, 0x08
0000786bc93d7c0f  push rax
0000786bc93d7c10  push rcx
0000786bc93d7c11  push rdx
0000786bc93d7c12  push rdi
0000786bc93d7c13  push rsi
0000786bc93d7c14  push r8
0000786bc93d7c16  push r9
0000786bc93d7c18  push r10
0000786bc93d7c1a  push r11
0000786bc93d7c1c  sub rsp, 0xF0
0000786bc93d7c23  vmovaps [rsp], xmm0
0000786bc93d7c28  vmovaps [rsp+0x10], xmm2
0000786bc93d7c2e  vmovaps [rsp+0x20], xmm3
0000786bc93d7c34  vmovaps [rsp+0x30], xmm4
0000786bc93d7c3a  vmovaps [rsp+0x40], xmm5
0000786bc93d7c40  vmovaps [rsp+0x50], xmm6
0000786bc93d7c46  vmovaps [rsp+0x60], xmm7
0000786bc93d7c4c  vmovaps [rsp+0x70], xmm8
0000786bc93d7c52  vmovaps [rsp+0x80], xmm9
0000786bc93d7c5b  vmovaps [rsp+0x90], xmm10
0000786bc93d7c64  vmovaps [rsp+0xA0], xmm11
0000786bc93d7c6d  vmovaps [rsp+0xB0], xmm12
0000786bc93d7c76  vmovaps [rsp+0xC0], xmm13
0000786bc93d7c7f  vmovaps [rsp+0xD0], xmm14
0000786bc93d7c88  vmovaps [rsp+0xE0], xmm15
0000786bc93d7c91  sub rsp, 0x30
0000786bc93d7c95  movaps [rsp], xmm1
0000786bc93d7c99  movaps [rsp+0x10], xmm5
0000786bc93d7c9e  movaps [rsp+0x20], xmm7
0000786bc93d7ca3  lea rdi, [rsp]
0000786bc93d7ca7  mov esi, 0x00
0000786bc93d7cac  mov rax, 0x60810F6F7530
0000786bc93d7cb6  call rax
0000786bc93d7cb8  movaps xmm1, [rsp]
0000786bc93d7cbc  add rsp, 0x30
0000786bc93d7cc0  vmovaps xmm0, [rsp]
0000786bc93d7cc5  vmovaps xmm2, [rsp+0x10]
0000786bc93d7ccb  vmovaps xmm3, [rsp+0x20]
0000786bc93d7cd1  vmovaps xmm4, [rsp+0x30]
0000786bc93d7cd7  vmovaps xmm5, [rsp+0x40]
0000786bc93d7cdd  vmovaps xmm6, [rsp+0x50]
0000786bc93d7ce3  vmovaps xmm7, [rsp+0x60]
0000786bc93d7ce9  vmovaps xmm8, [rsp+0x70]
0000786bc93d7cef  vmovaps xmm9, [rsp+0x80]
0000786bc93d7cf8  vmovaps xmm10, [rsp+0x90]
0000786bc93d7d01  vmovaps xmm11, [rsp+0xA0]
0000786bc93d7d0a  vmovaps xmm12, [rsp+0xB0]
0000786bc93d7d13  vmovaps xmm13, [rsp+0xC0]
0000786bc93d7d1c  vmovaps xmm14, [rsp+0xD0]
0000786bc93d7d25  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7d2e  add rsp, 0xF0
0000786bc93d7d35  pop r11
0000786bc93d7d37  pop r10
0000786bc93d7d39  pop r9
0000786bc93d7d3b  pop r8
0000786bc93d7d3d  pop rsi
0000786bc93d7d3e  pop rdi
0000786bc93d7d3f  pop rdx
0000786bc93d7d40  pop rcx
0000786bc93d7d41  pop rax
0000786bc93d7d42  add rsp, 0x08
0000786bc93d7d46  jmp 0x0000786BC93D5E7D
0000786bc93d7d4b  sub rsp, 0x08
0000786bc93d7d4f  push rax
0000786bc93d7d50  push rcx
0000786bc93d7d51  push rdx
0000786bc93d7d52  push rdi
0000786bc93d7d53  push rsi
0000786bc93d7d54  push r8
0000786bc93d7d56  push r9
0000786bc93d7d58  push r10
0000786bc93d7d5a  push r11
0000786bc93d7d5c  sub rsp, 0xF0
0000786bc93d7d63  vmovaps [rsp], xmm0
0000786bc93d7d68  vmovaps [rsp+0x10], xmm1
0000786bc93d7d6e  vmovaps [rsp+0x20], xmm2
0000786bc93d7d74  vmovaps [rsp+0x30], xmm3
0000786bc93d7d7a  vmovaps [rsp+0x40], xmm4
0000786bc93d7d80  vmovaps [rsp+0x50], xmm5
0000786bc93d7d86  vmovaps [rsp+0x60], xmm6
0000786bc93d7d8c  vmovaps [rsp+0x70], xmm8
0000786bc93d7d92  vmovaps [rsp+0x80], xmm9
0000786bc93d7d9b  vmovaps [rsp+0x90], xmm10
0000786bc93d7da4  vmovaps [rsp+0xA0], xmm11
0000786bc93d7dad  vmovaps [rsp+0xB0], xmm12
0000786bc93d7db6  vmovaps [rsp+0xC0], xmm13
0000786bc93d7dbf  vmovaps [rsp+0xD0], xmm14
0000786bc93d7dc8  vmovaps [rsp+0xE0], xmm15
0000786bc93d7dd1  sub rsp, 0x30
0000786bc93d7dd5  movaps [rsp], xmm7
0000786bc93d7dd9  movaps [rsp+0x10], xmm5
0000786bc93d7dde  movaps [rsp+0x20], xmm15
0000786bc93d7de4  lea rdi, [rsp]
0000786bc93d7de8  mov esi, 0x00
0000786bc93d7ded  mov rax, 0x60810F6F7530
0000786bc93d7df7  call rax
0000786bc93d7df9  movaps xmm7, [rsp]
0000786bc93d7dfd  add rsp, 0x30
0000786bc93d7e01  vmovaps xmm0, [rsp]
0000786bc93d7e06  vmovaps xmm1, [rsp+0x10]
0000786bc93d7e0c  vmovaps xmm2, [rsp+0x20]
0000786bc93d7e12  vmovaps xmm3, [rsp+0x30]
0000786bc93d7e18  vmovaps xmm4, [rsp+0x40]
0000786bc93d7e1e  vmovaps xmm5, [rsp+0x50]
0000786bc93d7e24  vmovaps xmm6, [rsp+0x60]
0000786bc93d7e2a  vmovaps xmm8, [rsp+0x70]
0000786bc93d7e30  vmovaps xmm9, [rsp+0x80]
0000786bc93d7e39  vmovaps xmm10, [rsp+0x90]
0000786bc93d7e42  vmovaps xmm11, [rsp+0xA0]
0000786bc93d7e4b  vmovaps xmm12, [rsp+0xB0]
0000786bc93d7e54  vmovaps xmm13, [rsp+0xC0]
0000786bc93d7e5d  vmovaps xmm14, [rsp+0xD0]
0000786bc93d7e66  vmovaps xmm15, [rsp+0xE0]
0000786bc93d7e6f  add rsp, 0xF0
0000786bc93d7e76  pop r11
0000786bc93d7e78  pop r10
0000786bc93d7e7a  pop r9
0000786bc93d7e7c  pop r8
0000786bc93d7e7e  pop rsi
0000786bc93d7e7f  pop rdi
0000786bc93d7e80  pop rdx
0000786bc93d7e81  pop rcx
0000786bc93d7e82  pop rax
0000786bc93d7e83  add rsp, 0x08
0000786bc93d7e87  jmp 0x0000786BC93D5EB3
0000786bc93d7e8c  call 0x0000786BC92D64F0
0000786bc93d7e91  jmp 0x0000786BC93D5EC0
0000786bc93d7e96  sub rsp, 0x08
0000786bc93d7e9a  push rax
0000786bc93d7e9b  push rcx
0000786bc93d7e9c  push rdx
0000786bc93d7e9d  push rdi
0000786bc93d7e9e  push rsi
0000786bc93d7e9f  push r8
0000786bc93d7ea1  push r9
0000786bc93d7ea3  push r10
0000786bc93d7ea5  push r11
0000786bc93d7ea7  sub rsp, 0xF0
0000786bc93d7eae  vmovaps [rsp], xmm0
0000786bc93d7eb3  vmovaps [rsp+0x10], xmm1
0000786bc93d7eb9  vmovaps [rsp+0x20], xmm2
0000786bc93d7ebf  vmovaps [rsp+0x30], xmm3
0000786bc93d7ec5  vmovaps [rsp+0x40], xmm4
0000786bc93d7ecb  vmovaps [rsp+0x50], xmm5
0000786bc93d7ed1  vmovaps [rsp+0x60], xmm6
0000786bc93d7ed7  vmovaps [rsp+0x70], xmm7
0000786bc93d7edd  vmovaps [rsp+0x80], xmm8
0000786bc93d7ee6  vmovaps [rsp+0x90], xmm9
0000786bc93d7eef  vmovaps [rsp+0xA0], xmm10
0000786bc93d7ef8  vmovaps [rsp+0xB0], xmm11
0000786bc93d7f01  vmovaps [rsp+0xC0], xmm12
0000786bc93d7f0a  vmovaps [rsp+0xD0], xmm13
0000786bc93d7f13  vmovaps [rsp+0xE0], xmm14
0000786bc93d7f1c  sub rsp, 0x30
0000786bc93d7f20  movaps [rsp], xmm15
0000786bc93d7f25  movaps [rsp+0x10], xmm5
0000786bc93d7f2a  movaps [rsp+0x20], xmm3
0000786bc93d7f2f  lea rdi, [rsp]
0000786bc93d7f33  mov esi, 0x00
0000786bc93d7f38  mov rax, 0x60810F6F7530
0000786bc93d7f42  call rax
0000786bc93d7f44  movaps xmm15, [rsp]
0000786bc93d7f49  add rsp, 0x30
0000786bc93d7f4d  vmovaps xmm0, [rsp]
0000786bc93d7f52  vmovaps xmm1, [rsp+0x10]
0000786bc93d7f58  vmovaps xmm2, [rsp+0x20]
0000786bc93d7f5e  vmovaps xmm3, [rsp+0x30]
0000786bc93d7f64  vmovaps xmm4, [rsp+0x40]
0000786bc93d7f6a  vmovaps xmm5, [rsp+0x50]
0000786bc93d7f70  vmovaps xmm6, [rsp+0x60]
0000786bc93d7f76  vmovaps xmm7, [rsp+0x70]
0000786bc93d7f7c  vmovaps xmm8, [rsp+0x80]
0000786bc93d7f85  vmovaps xmm9, [rsp+0x90]
0000786bc93d7f8e  vmovaps xmm10, [rsp+0xA0]
0000786bc93d7f97  vmovaps xmm11, [rsp+0xB0]
0000786bc93d7fa0  vmovaps xmm12, [rsp+0xC0]
0000786bc93d7fa9  vmovaps xmm13, [rsp+0xD0]
0000786bc93d7fb2  vmovaps xmm14, [rsp+0xE0]
0000786bc93d7fbb  add rsp, 0xF0
0000786bc93d7fc2  pop r11
0000786bc93d7fc4  pop r10
0000786bc93d7fc6  pop r9
0000786bc93d7fc8  pop r8
0000786bc93d7fca  pop rsi
0000786bc93d7fcb  pop rdi
0000786bc93d7fcc  pop rdx
0000786bc93d7fcd  pop rcx
0000786bc93d7fce  pop rax
0000786bc93d7fcf  add rsp, 0x08
0000786bc93d7fd3  jmp 0x0000786BC93D5EE6
0000786bc93d7fd8  sub rsp, 0x08
0000786bc93d7fdc  push rax
0000786bc93d7fdd  push rcx
0000786bc93d7fde  push rdx
0000786bc93d7fdf  push rdi
0000786bc93d7fe0  push rsi
0000786bc93d7fe1  push r8
0000786bc93d7fe3  push r9
0000786bc93d7fe5  push r10
0000786bc93d7fe7  push r11
0000786bc93d7fe9  sub rsp, 0xF0
0000786bc93d7ff0  vmovaps [rsp], xmm0
0000786bc93d7ff5  vmovaps [rsp+0x10], xmm2
0000786bc93d7ffb  vmovaps [rsp+0x20], xmm3
0000786bc93d8001  vmovaps [rsp+0x30], xmm4
0000786bc93d8007  vmovaps [rsp+0x40], xmm5
0000786bc93d800d  vmovaps [rsp+0x50], xmm6
0000786bc93d8013  vmovaps [rsp+0x60], xmm7
0000786bc93d8019  vmovaps [rsp+0x70], xmm8
0000786bc93d801f  vmovaps [rsp+0x80], xmm9
0000786bc93d8028  vmovaps [rsp+0x90], xmm10
0000786bc93d8031  vmovaps [rsp+0xA0], xmm11
0000786bc93d803a  vmovaps [rsp+0xB0], xmm12
0000786bc93d8043  vmovaps [rsp+0xC0], xmm13
0000786bc93d804c  vmovaps [rsp+0xD0], xmm14
0000786bc93d8055  vmovaps [rsp+0xE0], xmm15
0000786bc93d805e  sub rsp, 0x30
0000786bc93d8062  movaps [rsp], xmm1
0000786bc93d8066  movaps [rsp+0x10], xmm5
0000786bc93d806b  movaps [rsp+0x20], xmm4
0000786bc93d8070  lea rdi, [rsp]
0000786bc93d8074  mov esi, 0x00
0000786bc93d8079  mov rax, 0x60810F6F7530
0000786bc93d8083  call rax
0000786bc93d8085  movaps xmm1, [rsp]
0000786bc93d8089  add rsp, 0x30
0000786bc93d808d  vmovaps xmm0, [rsp]
0000786bc93d8092  vmovaps xmm2, [rsp+0x10]
0000786bc93d8098  vmovaps xmm3, [rsp+0x20]
0000786bc93d809e  vmovaps xmm4, [rsp+0x30]
0000786bc93d80a4  vmovaps xmm5, [rsp+0x40]
0000786bc93d80aa  vmovaps xmm6, [rsp+0x50]
0000786bc93d80b0  vmovaps xmm7, [rsp+0x60]
0000786bc93d80b6  vmovaps xmm8, [rsp+0x70]
0000786bc93d80bc  vmovaps xmm9, [rsp+0x80]
0000786bc93d80c5  vmovaps xmm10, [rsp+0x90]
0000786bc93d80ce  vmovaps xmm11, [rsp+0xA0]
0000786bc93d80d7  vmovaps xmm12, [rsp+0xB0]
0000786bc93d80e0  vmovaps xmm13, [rsp+0xC0]
0000786bc93d80e9  vmovaps xmm14, [rsp+0xD0]
0000786bc93d80f2  vmovaps xmm15, [rsp+0xE0]
0000786bc93d80fb  add rsp, 0xF0
0000786bc93d8102  pop r11
0000786bc93d8104  pop r10
0000786bc93d8106  pop r9
0000786bc93d8108  pop r8
0000786bc93d810a  pop rsi
0000786bc93d810b  pop rdi
0000786bc93d810c  pop rdx
0000786bc93d810d  pop rcx
0000786bc93d810e  pop rax
0000786bc93d810f  add rsp, 0x08
0000786bc93d8113  jmp 0x0000786BC93D5F06
0000786bc93d8118  sub rsp, 0x08
0000786bc93d811c  push rax
0000786bc93d811d  push rcx
0000786bc93d811e  push rdx
0000786bc93d811f  push rdi
0000786bc93d8120  push rsi
0000786bc93d8121  push r8
0000786bc93d8123  push r9
0000786bc93d8125  push r10
0000786bc93d8127  push r11
0000786bc93d8129  sub rsp, 0xF0
0000786bc93d8130  vmovaps [rsp], xmm0
0000786bc93d8135  vmovaps [rsp+0x10], xmm1
0000786bc93d813b  vmovaps [rsp+0x20], xmm2
0000786bc93d8141  vmovaps [rsp+0x30], xmm3
0000786bc93d8147  vmovaps [rsp+0x40], xmm5
0000786bc93d814d  vmovaps [rsp+0x50], xmm6
0000786bc93d8153  vmovaps [rsp+0x60], xmm7
0000786bc93d8159  vmovaps [rsp+0x70], xmm8
0000786bc93d815f  vmovaps [rsp+0x80], xmm9
0000786bc93d8168  vmovaps [rsp+0x90], xmm10
0000786bc93d8171  vmovaps [rsp+0xA0], xmm11
0000786bc93d817a  vmovaps [rsp+0xB0], xmm12
0000786bc93d8183  vmovaps [rsp+0xC0], xmm13
0000786bc93d818c  vmovaps [rsp+0xD0], xmm14
0000786bc93d8195  vmovaps [rsp+0xE0], xmm15
0000786bc93d819e  sub rsp, 0x30
0000786bc93d81a2  movaps [rsp], xmm4
0000786bc93d81a6  movaps [rsp+0x10], xmm3
0000786bc93d81ab  movaps [rsp+0x20], xmm5
0000786bc93d81b0  lea rdi, [rsp]
0000786bc93d81b4  mov esi, 0x00
0000786bc93d81b9  mov rax, 0x60810F6F7530
0000786bc93d81c3  call rax
0000786bc93d81c5  movaps xmm4, [rsp]
0000786bc93d81c9  add rsp, 0x30
0000786bc93d81cd  vmovaps xmm0, [rsp]
0000786bc93d81d2  vmovaps xmm1, [rsp+0x10]
0000786bc93d81d8  vmovaps xmm2, [rsp+0x20]
0000786bc93d81de  vmovaps xmm3, [rsp+0x30]
0000786bc93d81e4  vmovaps xmm5, [rsp+0x40]
0000786bc93d81ea  vmovaps xmm6, [rsp+0x50]
0000786bc93d81f0  vmovaps xmm7, [rsp+0x60]
0000786bc93d81f6  vmovaps xmm8, [rsp+0x70]
0000786bc93d81fc  vmovaps xmm9, [rsp+0x80]
0000786bc93d8205  vmovaps xmm10, [rsp+0x90]
0000786bc93d820e  vmovaps xmm11, [rsp+0xA0]
0000786bc93d8217  vmovaps xmm12, [rsp+0xB0]
0000786bc93d8220  vmovaps xmm13, [rsp+0xC0]
0000786bc93d8229  vmovaps xmm14, [rsp+0xD0]
0000786bc93d8232  vmovaps xmm15, [rsp+0xE0]
0000786bc93d823b  add rsp, 0xF0
0000786bc93d8242  pop r11
0000786bc93d8244  pop r10
0000786bc93d8246  pop r9
0000786bc93d8248  pop r8
0000786bc93d824a  pop rsi
0000786bc93d824b  pop rdi
0000786bc93d824c  pop rdx
0000786bc93d824d  pop rcx
0000786bc93d824e  pop rax
0000786bc93d824f  add rsp, 0x08
0000786bc93d8253  jmp 0x0000786BC93D5F54
0000786bc93d8258  call 0x0000786BC92D64F0
0000786bc93d825d  jmp 0x0000786BC93D5F61
0000786bc93d8262  sub rsp, 0x08
0000786bc93d8266  push rax
0000786bc93d8267  push rcx
0000786bc93d8268  push rdx
0000786bc93d8269  push rdi
0000786bc93d826a  push rsi
0000786bc93d826b  push r8
0000786bc93d826d  push r9
0000786bc93d826f  push r10
0000786bc93d8271  push r11
0000786bc93d8273  sub rsp, 0xF0
0000786bc93d827a  vmovaps [rsp], xmm0
0000786bc93d827f  vmovaps [rsp+0x10], xmm1
0000786bc93d8285  vmovaps [rsp+0x20], xmm2
0000786bc93d828b  vmovaps [rsp+0x30], xmm3
0000786bc93d8291  vmovaps [rsp+0x40], xmm4
0000786bc93d8297  vmovaps [rsp+0x50], xmm6
0000786bc93d829d  vmovaps [rsp+0x60], xmm7
0000786bc93d82a3  vmovaps [rsp+0x70], xmm8
0000786bc93d82a9  vmovaps [rsp+0x80], xmm9
0000786bc93d82b2  vmovaps [rsp+0x90], xmm10
0000786bc93d82bb  vmovaps [rsp+0xA0], xmm11
0000786bc93d82c4  vmovaps [rsp+0xB0], xmm12
0000786bc93d82cd  vmovaps [rsp+0xC0], xmm13
0000786bc93d82d6  vmovaps [rsp+0xD0], xmm14
0000786bc93d82df  vmovaps [rsp+0xE0], xmm15
0000786bc93d82e8  sub rsp, 0x30
0000786bc93d82ec  movaps [rsp], xmm5
0000786bc93d82f0  movaps [rsp+0x10], xmm6
0000786bc93d82f5  movaps [rsp+0x20], xmm3
0000786bc93d82fa  lea rdi, [rsp]
0000786bc93d82fe  mov esi, 0x00
0000786bc93d8303  mov rax, 0x60810F6F7530
0000786bc93d830d  call rax
0000786bc93d830f  movaps xmm5, [rsp]
0000786bc93d8313  add rsp, 0x30
0000786bc93d8317  vmovaps xmm0, [rsp]
0000786bc93d831c  vmovaps xmm1, [rsp+0x10]
0000786bc93d8322  vmovaps xmm2, [rsp+0x20]
0000786bc93d8328  vmovaps xmm3, [rsp+0x30]
0000786bc93d832e  vmovaps xmm4, [rsp+0x40]
0000786bc93d8334  vmovaps xmm6, [rsp+0x50]
0000786bc93d833a  vmovaps xmm7, [rsp+0x60]
0000786bc93d8340  vmovaps xmm8, [rsp+0x70]
0000786bc93d8346  vmovaps xmm9, [rsp+0x80]
0000786bc93d834f  vmovaps xmm10, [rsp+0x90]
0000786bc93d8358  vmovaps xmm11, [rsp+0xA0]
0000786bc93d8361  vmovaps xmm12, [rsp+0xB0]
0000786bc93d836a  vmovaps xmm13, [rsp+0xC0]
0000786bc93d8373  vmovaps xmm14, [rsp+0xD0]
0000786bc93d837c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d8385  add rsp, 0xF0
0000786bc93d838c  pop r11
0000786bc93d838e  pop r10
0000786bc93d8390  pop r9
0000786bc93d8392  pop r8
0000786bc93d8394  pop rsi
0000786bc93d8395  pop rdi
0000786bc93d8396  pop rdx
0000786bc93d8397  pop rcx
0000786bc93d8398  pop rax
0000786bc93d8399  add rsp, 0x08
0000786bc93d839d  jmp 0x0000786BC93D5F87
0000786bc93d83a2  sub rsp, 0x08
0000786bc93d83a6  push rax
0000786bc93d83a7  push rcx
0000786bc93d83a8  push rdx
0000786bc93d83a9  push rdi
0000786bc93d83aa  push rsi
0000786bc93d83ab  push r8
0000786bc93d83ad  push r9
0000786bc93d83af  push r10
0000786bc93d83b1  push r11
0000786bc93d83b3  sub rsp, 0xF0
0000786bc93d83ba  vmovaps [rsp], xmm0
0000786bc93d83bf  vmovaps [rsp+0x10], xmm1
0000786bc93d83c5  vmovaps [rsp+0x20], xmm2
0000786bc93d83cb  vmovaps [rsp+0x30], xmm3
0000786bc93d83d1  vmovaps [rsp+0x40], xmm4
0000786bc93d83d7  vmovaps [rsp+0x50], xmm5
0000786bc93d83dd  vmovaps [rsp+0x60], xmm7
0000786bc93d83e3  vmovaps [rsp+0x70], xmm8
0000786bc93d83e9  vmovaps [rsp+0x80], xmm9
0000786bc93d83f2  vmovaps [rsp+0x90], xmm10
0000786bc93d83fb  vmovaps [rsp+0xA0], xmm11
0000786bc93d8404  vmovaps [rsp+0xB0], xmm12
0000786bc93d840d  vmovaps [rsp+0xC0], xmm13
0000786bc93d8416  vmovaps [rsp+0xD0], xmm14
0000786bc93d841f  vmovaps [rsp+0xE0], xmm15
0000786bc93d8428  sub rsp, 0x30
0000786bc93d842c  movaps [rsp], xmm6
0000786bc93d8430  movaps [rsp+0x10], xmm9
0000786bc93d8436  movaps [rsp+0x20], xmm1
0000786bc93d843b  lea rdi, [rsp]
0000786bc93d843f  mov esi, 0x00
0000786bc93d8444  mov rax, 0x60810F6F7530
0000786bc93d844e  call rax
0000786bc93d8450  movaps xmm6, [rsp]
0000786bc93d8454  add rsp, 0x30
0000786bc93d8458  vmovaps xmm0, [rsp]
0000786bc93d845d  vmovaps xmm1, [rsp+0x10]
0000786bc93d8463  vmovaps xmm2, [rsp+0x20]
0000786bc93d8469  vmovaps xmm3, [rsp+0x30]
0000786bc93d846f  vmovaps xmm4, [rsp+0x40]
0000786bc93d8475  vmovaps xmm5, [rsp+0x50]
0000786bc93d847b  vmovaps xmm7, [rsp+0x60]
0000786bc93d8481  vmovaps xmm8, [rsp+0x70]
0000786bc93d8487  vmovaps xmm9, [rsp+0x80]
0000786bc93d8490  vmovaps xmm10, [rsp+0x90]
0000786bc93d8499  vmovaps xmm11, [rsp+0xA0]
0000786bc93d84a2  vmovaps xmm12, [rsp+0xB0]
0000786bc93d84ab  vmovaps xmm13, [rsp+0xC0]
0000786bc93d84b4  vmovaps xmm14, [rsp+0xD0]
0000786bc93d84bd  vmovaps xmm15, [rsp+0xE0]
0000786bc93d84c6  add rsp, 0xF0
0000786bc93d84cd  pop r11
0000786bc93d84cf  pop r10
0000786bc93d84d1  pop r9
0000786bc93d84d3  pop r8
0000786bc93d84d5  pop rsi
0000786bc93d84d6  pop rdi
0000786bc93d84d7  pop rdx
0000786bc93d84d8  pop rcx
0000786bc93d84d9  pop rax
0000786bc93d84da  add rsp, 0x08
0000786bc93d84de  jmp 0x0000786BC93D5FAB
0000786bc93d84e3  sub rsp, 0x08
0000786bc93d84e7  push rax
0000786bc93d84e8  push rcx
0000786bc93d84e9  push rdx
0000786bc93d84ea  push rdi
0000786bc93d84eb  push rsi
0000786bc93d84ec  push r8
0000786bc93d84ee  push r9
0000786bc93d84f0  push r10
0000786bc93d84f2  push r11
0000786bc93d84f4  sub rsp, 0xF0
0000786bc93d84fb  vmovaps [rsp], xmm0
0000786bc93d8500  vmovaps [rsp+0x10], xmm1
0000786bc93d8506  vmovaps [rsp+0x20], xmm2
0000786bc93d850c  vmovaps [rsp+0x30], xmm3
0000786bc93d8512  vmovaps [rsp+0x40], xmm4
0000786bc93d8518  vmovaps [rsp+0x50], xmm5
0000786bc93d851e  vmovaps [rsp+0x60], xmm6
0000786bc93d8524  vmovaps [rsp+0x70], xmm7
0000786bc93d852a  vmovaps [rsp+0x80], xmm8
0000786bc93d8533  vmovaps [rsp+0x90], xmm10
0000786bc93d853c  vmovaps [rsp+0xA0], xmm11
0000786bc93d8545  vmovaps [rsp+0xB0], xmm12
0000786bc93d854e  vmovaps [rsp+0xC0], xmm13
0000786bc93d8557  vmovaps [rsp+0xD0], xmm14
0000786bc93d8560  vmovaps [rsp+0xE0], xmm15
0000786bc93d8569  sub rsp, 0x30
0000786bc93d856d  movaps [rsp], xmm9
0000786bc93d8572  movaps [rsp+0x10], xmm3
0000786bc93d8577  movaps [rsp+0x20], xmm1
0000786bc93d857c  lea rdi, [rsp]
0000786bc93d8580  mov esi, 0x00
0000786bc93d8585  mov rax, 0x60810F6F7530
0000786bc93d858f  call rax
0000786bc93d8591  movaps xmm9, [rsp]
0000786bc93d8596  add rsp, 0x30
0000786bc93d859a  vmovaps xmm0, [rsp]
0000786bc93d859f  vmovaps xmm1, [rsp+0x10]
0000786bc93d85a5  vmovaps xmm2, [rsp+0x20]
0000786bc93d85ab  vmovaps xmm3, [rsp+0x30]
0000786bc93d85b1  vmovaps xmm4, [rsp+0x40]
0000786bc93d85b7  vmovaps xmm5, [rsp+0x50]
0000786bc93d85bd  vmovaps xmm6, [rsp+0x60]
0000786bc93d85c3  vmovaps xmm7, [rsp+0x70]
0000786bc93d85c9  vmovaps xmm8, [rsp+0x80]
0000786bc93d85d2  vmovaps xmm10, [rsp+0x90]
0000786bc93d85db  vmovaps xmm11, [rsp+0xA0]
0000786bc93d85e4  vmovaps xmm12, [rsp+0xB0]
0000786bc93d85ed  vmovaps xmm13, [rsp+0xC0]
0000786bc93d85f6  vmovaps xmm14, [rsp+0xD0]
0000786bc93d85ff  vmovaps xmm15, [rsp+0xE0]
0000786bc93d8608  add rsp, 0xF0
0000786bc93d860f  pop r11
0000786bc93d8611  pop r10
0000786bc93d8613  pop r9
0000786bc93d8615  pop r8
0000786bc93d8617  pop rsi
0000786bc93d8618  pop rdi
0000786bc93d8619  pop rdx
0000786bc93d861a  pop rcx
0000786bc93d861b  pop rax
0000786bc93d861c  add rsp, 0x08
0000786bc93d8620  jmp 0x0000786BC93D5FF7
0000786bc93d8625  call 0x0000786BC92D64F0
0000786bc93d862a  jmp 0x0000786BC93D6004
0000786bc93d862f  sub rsp, 0x08
0000786bc93d8633  push rax
0000786bc93d8634  push rcx
0000786bc93d8635  push rdx
0000786bc93d8636  push rdi
0000786bc93d8637  push rsi
0000786bc93d8638  push r8
0000786bc93d863a  push r9
0000786bc93d863c  push r10
0000786bc93d863e  push r11
0000786bc93d8640  sub rsp, 0xF0
0000786bc93d8647  vmovaps [rsp], xmm0
0000786bc93d864c  vmovaps [rsp+0x10], xmm1
0000786bc93d8652  vmovaps [rsp+0x20], xmm2
0000786bc93d8658  vmovaps [rsp+0x30], xmm3
0000786bc93d865e  vmovaps [rsp+0x40], xmm4
0000786bc93d8664  vmovaps [rsp+0x50], xmm5
0000786bc93d866a  vmovaps [rsp+0x60], xmm6
0000786bc93d8670  vmovaps [rsp+0x70], xmm7
0000786bc93d8676  vmovaps [rsp+0x80], xmm8
0000786bc93d867f  vmovaps [rsp+0x90], xmm9
0000786bc93d8688  vmovaps [rsp+0xA0], xmm10
0000786bc93d8691  vmovaps [rsp+0xB0], xmm11
0000786bc93d869a  vmovaps [rsp+0xC0], xmm12
0000786bc93d86a3  vmovaps [rsp+0xD0], xmm13
0000786bc93d86ac  vmovaps [rsp+0xE0], xmm14
0000786bc93d86b5  sub rsp, 0x30
0000786bc93d86b9  movaps [rsp], xmm15
0000786bc93d86be  movaps [rsp+0x10], xmm3
0000786bc93d86c3  movaps [rsp+0x20], xmm7
0000786bc93d86c8  lea rdi, [rsp]
0000786bc93d86cc  mov esi, 0x00
0000786bc93d86d1  mov rax, 0x60810F6F7530
0000786bc93d86db  call rax
0000786bc93d86dd  movaps xmm15, [rsp]
0000786bc93d86e2  add rsp, 0x30
0000786bc93d86e6  vmovaps xmm0, [rsp]
0000786bc93d86eb  vmovaps xmm1, [rsp+0x10]
0000786bc93d86f1  vmovaps xmm2, [rsp+0x20]
0000786bc93d86f7  vmovaps xmm3, [rsp+0x30]
0000786bc93d86fd  vmovaps xmm4, [rsp+0x40]
0000786bc93d8703  vmovaps xmm5, [rsp+0x50]
0000786bc93d8709  vmovaps xmm6, [rsp+0x60]
0000786bc93d870f  vmovaps xmm7, [rsp+0x70]
0000786bc93d8715  vmovaps xmm8, [rsp+0x80]
0000786bc93d871e  vmovaps xmm9, [rsp+0x90]
0000786bc93d8727  vmovaps xmm10, [rsp+0xA0]
0000786bc93d8730  vmovaps xmm11, [rsp+0xB0]
0000786bc93d8739  vmovaps xmm12, [rsp+0xC0]
0000786bc93d8742  vmovaps xmm13, [rsp+0xD0]
0000786bc93d874b  vmovaps xmm14, [rsp+0xE0]
0000786bc93d8754  add rsp, 0xF0
0000786bc93d875b  pop r11
0000786bc93d875d  pop r10
0000786bc93d875f  pop r9
0000786bc93d8761  pop r8
0000786bc93d8763  pop rsi
0000786bc93d8764  pop rdi
0000786bc93d8765  pop rdx
0000786bc93d8766  pop rcx
0000786bc93d8767  pop rax
0000786bc93d8768  add rsp, 0x08
0000786bc93d876c  jmp 0x0000786BC93D6030
0000786bc93d8771  sub rsp, 0x08
0000786bc93d8775  push rax
0000786bc93d8776  push rcx
0000786bc93d8777  push rdx
0000786bc93d8778  push rdi
0000786bc93d8779  push rsi
0000786bc93d877a  push r8
0000786bc93d877c  push r9
0000786bc93d877e  push r10
0000786bc93d8780  push r11
0000786bc93d8782  sub rsp, 0xF0
0000786bc93d8789  vmovaps [rsp], xmm0
0000786bc93d878e  vmovaps [rsp+0x10], xmm1
0000786bc93d8794  vmovaps [rsp+0x20], xmm2
0000786bc93d879a  vmovaps [rsp+0x30], xmm4
0000786bc93d87a0  vmovaps [rsp+0x40], xmm5
0000786bc93d87a6  vmovaps [rsp+0x50], xmm6
0000786bc93d87ac  vmovaps [rsp+0x60], xmm7
0000786bc93d87b2  vmovaps [rsp+0x70], xmm8
0000786bc93d87b8  vmovaps [rsp+0x80], xmm9
0000786bc93d87c1  vmovaps [rsp+0x90], xmm10
0000786bc93d87ca  vmovaps [rsp+0xA0], xmm11
0000786bc93d87d3  vmovaps [rsp+0xB0], xmm12
0000786bc93d87dc  vmovaps [rsp+0xC0], xmm13
0000786bc93d87e5  vmovaps [rsp+0xD0], xmm14
0000786bc93d87ee  vmovaps [rsp+0xE0], xmm15
0000786bc93d87f7  sub rsp, 0x30
0000786bc93d87fb  movaps [rsp], xmm3
0000786bc93d87ff  movaps [rsp+0x10], xmm1
0000786bc93d8804  movaps [rsp+0x20], xmm15
0000786bc93d880a  lea rdi, [rsp]
0000786bc93d880e  mov esi, 0x00
0000786bc93d8813  mov rax, 0x60810F6F7530
0000786bc93d881d  call rax
0000786bc93d881f  movaps xmm3, [rsp]
0000786bc93d8823  add rsp, 0x30
0000786bc93d8827  vmovaps xmm0, [rsp]
0000786bc93d882c  vmovaps xmm1, [rsp+0x10]
0000786bc93d8832  vmovaps xmm2, [rsp+0x20]
0000786bc93d8838  vmovaps xmm4, [rsp+0x30]
0000786bc93d883e  vmovaps xmm5, [rsp+0x40]
0000786bc93d8844  vmovaps xmm6, [rsp+0x50]
0000786bc93d884a  vmovaps xmm7, [rsp+0x60]
0000786bc93d8850  vmovaps xmm8, [rsp+0x70]
0000786bc93d8856  vmovaps xmm9, [rsp+0x80]
0000786bc93d885f  vmovaps xmm10, [rsp+0x90]
0000786bc93d8868  vmovaps xmm11, [rsp+0xA0]
0000786bc93d8871  vmovaps xmm12, [rsp+0xB0]
0000786bc93d887a  vmovaps xmm13, [rsp+0xC0]
0000786bc93d8883  vmovaps xmm14, [rsp+0xD0]
0000786bc93d888c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d8895  add rsp, 0xF0
0000786bc93d889c  pop r11
0000786bc93d889e  pop r10
0000786bc93d88a0  pop r9
0000786bc93d88a2  pop r8
0000786bc93d88a4  pop rsi
0000786bc93d88a5  pop rdi
0000786bc93d88a6  pop rdx
0000786bc93d88a7  pop rcx
0000786bc93d88a8  pop rax
0000786bc93d88a9  add rsp, 0x08
0000786bc93d88ad  jmp 0x0000786BC93D60BF
0000786bc93d88b2  call 0x0000786BC92D64F0
0000786bc93d88b7  jmp 0x0000786BC93D60C9
0000786bc93d88bc  sub rsp, 0x08
0000786bc93d88c0  push rax
0000786bc93d88c1  push rcx
0000786bc93d88c2  push rdx
0000786bc93d88c3  push rdi
0000786bc93d88c4  push rsi
0000786bc93d88c5  push r8
0000786bc93d88c7  push r9
0000786bc93d88c9  push r10
0000786bc93d88cb  push r11
0000786bc93d88cd  sub rsp, 0xF0
0000786bc93d88d4  vmovaps [rsp], xmm0
0000786bc93d88d9  vmovaps [rsp+0x10], xmm1
0000786bc93d88df  vmovaps [rsp+0x20], xmm2
0000786bc93d88e5  vmovaps [rsp+0x30], xmm3
0000786bc93d88eb  vmovaps [rsp+0x40], xmm4
0000786bc93d88f1  vmovaps [rsp+0x50], xmm5
0000786bc93d88f7  vmovaps [rsp+0x60], xmm6
0000786bc93d88fd  vmovaps [rsp+0x70], xmm7
0000786bc93d8903  vmovaps [rsp+0x80], xmm8
0000786bc93d890c  vmovaps [rsp+0x90], xmm9
0000786bc93d8915  vmovaps [rsp+0xA0], xmm10
0000786bc93d891e  vmovaps [rsp+0xB0], xmm11
0000786bc93d8927  vmovaps [rsp+0xC0], xmm12
0000786bc93d8930  vmovaps [rsp+0xD0], xmm13
0000786bc93d8939  vmovaps [rsp+0xE0], xmm14
0000786bc93d8942  sub rsp, 0x30
0000786bc93d8946  movaps [rsp], xmm15
0000786bc93d894b  movaps [rsp+0x10], xmm14
0000786bc93d8951  movaps [rsp+0x20], xmm4
0000786bc93d8956  lea rdi, [rsp]
0000786bc93d895a  mov esi, 0x00
0000786bc93d895f  mov rax, 0x60810F6F7530
0000786bc93d8969  call rax
0000786bc93d896b  movaps xmm15, [rsp]
0000786bc93d8970  add rsp, 0x30
0000786bc93d8974  vmovaps xmm0, [rsp]
0000786bc93d8979  vmovaps xmm1, [rsp+0x10]
0000786bc93d897f  vmovaps xmm2, [rsp+0x20]
0000786bc93d8985  vmovaps xmm3, [rsp+0x30]
0000786bc93d898b  vmovaps xmm4, [rsp+0x40]
0000786bc93d8991  vmovaps xmm5, [rsp+0x50]
0000786bc93d8997  vmovaps xmm6, [rsp+0x60]
0000786bc93d899d  vmovaps xmm7, [rsp+0x70]
0000786bc93d89a3  vmovaps xmm8, [rsp+0x80]
0000786bc93d89ac  vmovaps xmm9, [rsp+0x90]
0000786bc93d89b5  vmovaps xmm10, [rsp+0xA0]
0000786bc93d89be  vmovaps xmm11, [rsp+0xB0]
0000786bc93d89c7  vmovaps xmm12, [rsp+0xC0]
0000786bc93d89d0  vmovaps xmm13, [rsp+0xD0]
0000786bc93d89d9  vmovaps xmm14, [rsp+0xE0]
0000786bc93d89e2  add rsp, 0xF0
0000786bc93d89e9  pop r11
0000786bc93d89eb  pop r10
0000786bc93d89ed  pop r9
0000786bc93d89ef  pop r8
0000786bc93d89f1  pop rsi
0000786bc93d89f2  pop rdi
0000786bc93d89f3  pop rdx
0000786bc93d89f4  pop rcx
0000786bc93d89f5  pop rax
0000786bc93d89f6  add rsp, 0x08
0000786bc93d89fa  jmp 0x0000786BC93D60F7
0000786bc93d89ff  sub rsp, 0x08
0000786bc93d8a03  push rax
0000786bc93d8a04  push rcx
0000786bc93d8a05  push rdx
0000786bc93d8a06  push rdi
0000786bc93d8a07  push rsi
0000786bc93d8a08  push r8
0000786bc93d8a0a  push r9
0000786bc93d8a0c  push r10
0000786bc93d8a0e  push r11
0000786bc93d8a10  sub rsp, 0xF0
0000786bc93d8a17  vmovaps [rsp], xmm0
0000786bc93d8a1c  vmovaps [rsp+0x10], xmm1
0000786bc93d8a22  vmovaps [rsp+0x20], xmm2
0000786bc93d8a28  vmovaps [rsp+0x30], xmm3
0000786bc93d8a2e  vmovaps [rsp+0x40], xmm4
0000786bc93d8a34  vmovaps [rsp+0x50], xmm5
0000786bc93d8a3a  vmovaps [rsp+0x60], xmm6
0000786bc93d8a40  vmovaps [rsp+0x70], xmm7
0000786bc93d8a46  vmovaps [rsp+0x80], xmm8
0000786bc93d8a4f  vmovaps [rsp+0x90], xmm9
0000786bc93d8a58  vmovaps [rsp+0xA0], xmm10
0000786bc93d8a61  vmovaps [rsp+0xB0], xmm11
0000786bc93d8a6a  vmovaps [rsp+0xC0], xmm12
0000786bc93d8a73  vmovaps [rsp+0xD0], xmm13
0000786bc93d8a7c  vmovaps [rsp+0xE0], xmm15
0000786bc93d8a85  sub rsp, 0x30
0000786bc93d8a89  movaps [rsp], xmm14
0000786bc93d8a8e  movaps [rsp+0x10], xmm2
0000786bc93d8a93  movaps [rsp+0x20], xmm1
0000786bc93d8a98  lea rdi, [rsp]
0000786bc93d8a9c  mov esi, 0x00
0000786bc93d8aa1  mov rax, 0x60810F6F7530
0000786bc93d8aab  call rax
0000786bc93d8aad  movaps xmm14, [rsp]
0000786bc93d8ab2  add rsp, 0x30
0000786bc93d8ab6  vmovaps xmm0, [rsp]
0000786bc93d8abb  vmovaps xmm1, [rsp+0x10]
0000786bc93d8ac1  vmovaps xmm2, [rsp+0x20]
0000786bc93d8ac7  vmovaps xmm3, [rsp+0x30]
0000786bc93d8acd  vmovaps xmm4, [rsp+0x40]
0000786bc93d8ad3  vmovaps xmm5, [rsp+0x50]
0000786bc93d8ad9  vmovaps xmm6, [rsp+0x60]
0000786bc93d8adf  vmovaps xmm7, [rsp+0x70]
0000786bc93d8ae5  vmovaps xmm8, [rsp+0x80]
0000786bc93d8aee  vmovaps xmm9, [rsp+0x90]
0000786bc93d8af7  vmovaps xmm10, [rsp+0xA0]
0000786bc93d8b00  vmovaps xmm11, [rsp+0xB0]
0000786bc93d8b09  vmovaps xmm12, [rsp+0xC0]
0000786bc93d8b12  vmovaps xmm13, [rsp+0xD0]
0000786bc93d8b1b  vmovaps xmm15, [rsp+0xE0]
0000786bc93d8b24  add rsp, 0xF0
0000786bc93d8b2b  pop r11
0000786bc93d8b2d  pop r10
0000786bc93d8b2f  pop r9
0000786bc93d8b31  pop r8
0000786bc93d8b33  pop rsi
0000786bc93d8b34  pop rdi
0000786bc93d8b35  pop rdx
0000786bc93d8b36  pop rcx
0000786bc93d8b37  pop rax
0000786bc93d8b38  add rsp, 0x08
0000786bc93d8b3c  jmp 0x0000786BC93D611D
0000786bc93d8b41  sub rsp, 0x08
0000786bc93d8b45  push rax
0000786bc93d8b46  push rcx
0000786bc93d8b47  push rdx
0000786bc93d8b48  push rdi
0000786bc93d8b49  push rsi
0000786bc93d8b4a  push r8
0000786bc93d8b4c  push r9
0000786bc93d8b4e  push r10
0000786bc93d8b50  push r11
0000786bc93d8b52  sub rsp, 0xF0
0000786bc93d8b59  vmovaps [rsp], xmm0
0000786bc93d8b5e  vmovaps [rsp+0x10], xmm2
0000786bc93d8b64  vmovaps [rsp+0x20], xmm3
0000786bc93d8b6a  vmovaps [rsp+0x30], xmm4
0000786bc93d8b70  vmovaps [rsp+0x40], xmm5
0000786bc93d8b76  vmovaps [rsp+0x50], xmm6
0000786bc93d8b7c  vmovaps [rsp+0x60], xmm7
0000786bc93d8b82  vmovaps [rsp+0x70], xmm8
0000786bc93d8b88  vmovaps [rsp+0x80], xmm9
0000786bc93d8b91  vmovaps [rsp+0x90], xmm10
0000786bc93d8b9a  vmovaps [rsp+0xA0], xmm11
0000786bc93d8ba3  vmovaps [rsp+0xB0], xmm12
0000786bc93d8bac  vmovaps [rsp+0xC0], xmm13
0000786bc93d8bb5  vmovaps [rsp+0xD0], xmm14
0000786bc93d8bbe  vmovaps [rsp+0xE0], xmm15
0000786bc93d8bc7  sub rsp, 0x30
0000786bc93d8bcb  movaps [rsp], xmm1
0000786bc93d8bcf  movaps [rsp+0x10], xmm4
0000786bc93d8bd4  movaps [rsp+0x20], xmm9
0000786bc93d8bda  lea rdi, [rsp]
0000786bc93d8bde  mov esi, 0x00
0000786bc93d8be3  mov rax, 0x60810F6F7530
0000786bc93d8bed  call rax
0000786bc93d8bef  movaps xmm1, [rsp]
0000786bc93d8bf3  add rsp, 0x30
0000786bc93d8bf7  vmovaps xmm0, [rsp]
0000786bc93d8bfc  vmovaps xmm2, [rsp+0x10]
0000786bc93d8c02  vmovaps xmm3, [rsp+0x20]
0000786bc93d8c08  vmovaps xmm4, [rsp+0x30]
0000786bc93d8c0e  vmovaps xmm5, [rsp+0x40]
0000786bc93d8c14  vmovaps xmm6, [rsp+0x50]
0000786bc93d8c1a  vmovaps xmm7, [rsp+0x60]
0000786bc93d8c20  vmovaps xmm8, [rsp+0x70]
0000786bc93d8c26  vmovaps xmm9, [rsp+0x80]
0000786bc93d8c2f  vmovaps xmm10, [rsp+0x90]
0000786bc93d8c38  vmovaps xmm11, [rsp+0xA0]
0000786bc93d8c41  vmovaps xmm12, [rsp+0xB0]
0000786bc93d8c4a  vmovaps xmm13, [rsp+0xC0]
0000786bc93d8c53  vmovaps xmm14, [rsp+0xD0]
0000786bc93d8c5c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d8c65  add rsp, 0xF0
0000786bc93d8c6c  pop r11
0000786bc93d8c6e  pop r10
0000786bc93d8c70  pop r9
0000786bc93d8c72  pop r8
0000786bc93d8c74  pop rsi
0000786bc93d8c75  pop rdi
0000786bc93d8c76  pop rdx
0000786bc93d8c77  pop rcx
0000786bc93d8c78  pop rax
0000786bc93d8c79  add rsp, 0x08
0000786bc93d8c7d  jmp 0x0000786BC93D613B
0000786bc93d8c82  sub rsp, 0x08
0000786bc93d8c86  push rax
0000786bc93d8c87  push rcx
0000786bc93d8c88  push rdx
0000786bc93d8c89  push rdi
0000786bc93d8c8a  push rsi
0000786bc93d8c8b  push r8
0000786bc93d8c8d  push r9
0000786bc93d8c8f  push r10
0000786bc93d8c91  push r11
0000786bc93d8c93  sub rsp, 0xF0
0000786bc93d8c9a  vmovaps [rsp], xmm0
0000786bc93d8c9f  vmovaps [rsp+0x10], xmm1
0000786bc93d8ca5  vmovaps [rsp+0x20], xmm2
0000786bc93d8cab  vmovaps [rsp+0x30], xmm3
0000786bc93d8cb1  vmovaps [rsp+0x40], xmm5
0000786bc93d8cb7  vmovaps [rsp+0x50], xmm6
0000786bc93d8cbd  vmovaps [rsp+0x60], xmm7
0000786bc93d8cc3  vmovaps [rsp+0x70], xmm8
0000786bc93d8cc9  vmovaps [rsp+0x80], xmm9
0000786bc93d8cd2  vmovaps [rsp+0x90], xmm10
0000786bc93d8cdb  vmovaps [rsp+0xA0], xmm11
0000786bc93d8ce4  vmovaps [rsp+0xB0], xmm12
0000786bc93d8ced  vmovaps [rsp+0xC0], xmm13
0000786bc93d8cf6  vmovaps [rsp+0xD0], xmm14
0000786bc93d8cff  vmovaps [rsp+0xE0], xmm15
0000786bc93d8d08  sub rsp, 0x30
0000786bc93d8d0c  movaps [rsp], xmm4
0000786bc93d8d10  movaps [rsp+0x10], xmm2
0000786bc93d8d15  movaps [rsp+0x20], xmm9
0000786bc93d8d1b  lea rdi, [rsp]
0000786bc93d8d1f  mov esi, 0x00
0000786bc93d8d24  mov rax, 0x60810F6F7530
0000786bc93d8d2e  call rax
0000786bc93d8d30  movaps xmm4, [rsp]
0000786bc93d8d34  add rsp, 0x30
0000786bc93d8d38  vmovaps xmm0, [rsp]
0000786bc93d8d3d  vmovaps xmm1, [rsp+0x10]
0000786bc93d8d43  vmovaps xmm2, [rsp+0x20]
0000786bc93d8d49  vmovaps xmm3, [rsp+0x30]
0000786bc93d8d4f  vmovaps xmm5, [rsp+0x40]
0000786bc93d8d55  vmovaps xmm6, [rsp+0x50]
0000786bc93d8d5b  vmovaps xmm7, [rsp+0x60]
0000786bc93d8d61  vmovaps xmm8, [rsp+0x70]
0000786bc93d8d67  vmovaps xmm9, [rsp+0x80]
0000786bc93d8d70  vmovaps xmm10, [rsp+0x90]
0000786bc93d8d79  vmovaps xmm11, [rsp+0xA0]
0000786bc93d8d82  vmovaps xmm12, [rsp+0xB0]
0000786bc93d8d8b  vmovaps xmm13, [rsp+0xC0]
0000786bc93d8d94  vmovaps xmm14, [rsp+0xD0]
0000786bc93d8d9d  vmovaps xmm15, [rsp+0xE0]
0000786bc93d8da6  add rsp, 0xF0
0000786bc93d8dad  pop r11
0000786bc93d8daf  pop r10
0000786bc93d8db1  pop r9
0000786bc93d8db3  pop r8
0000786bc93d8db5  pop rsi
0000786bc93d8db6  pop rdi
0000786bc93d8db7  pop rdx
0000786bc93d8db8  pop rcx
0000786bc93d8db9  pop rax
0000786bc93d8dba  add rsp, 0x08
0000786bc93d8dbe  jmp 0x0000786BC93D616B
0000786bc93d8dc3  sub rsp, 0x08
0000786bc93d8dc7  push rax
0000786bc93d8dc8  push rcx
0000786bc93d8dc9  push rdx
0000786bc93d8dca  push rdi
0000786bc93d8dcb  push rsi
0000786bc93d8dcc  push r8
0000786bc93d8dce  push r9
0000786bc93d8dd0  push r10
0000786bc93d8dd2  push r11
0000786bc93d8dd4  sub rsp, 0xF0
0000786bc93d8ddb  vmovaps [rsp], xmm0
0000786bc93d8de0  vmovaps [rsp+0x10], xmm1
0000786bc93d8de6  vmovaps [rsp+0x20], xmm2
0000786bc93d8dec  vmovaps [rsp+0x30], xmm3
0000786bc93d8df2  vmovaps [rsp+0x40], xmm4
0000786bc93d8df8  vmovaps [rsp+0x50], xmm5
0000786bc93d8dfe  vmovaps [rsp+0x60], xmm6
0000786bc93d8e04  vmovaps [rsp+0x70], xmm7
0000786bc93d8e0a  vmovaps [rsp+0x80], xmm8
0000786bc93d8e13  vmovaps [rsp+0x90], xmm10
0000786bc93d8e1c  vmovaps [rsp+0xA0], xmm11
0000786bc93d8e25  vmovaps [rsp+0xB0], xmm12
0000786bc93d8e2e  vmovaps [rsp+0xC0], xmm13
0000786bc93d8e37  vmovaps [rsp+0xD0], xmm14
0000786bc93d8e40  vmovaps [rsp+0xE0], xmm15
0000786bc93d8e49  sub rsp, 0x30
0000786bc93d8e4d  movaps [rsp], xmm9
0000786bc93d8e52  movaps [rsp+0x10], xmm2
0000786bc93d8e57  movaps [rsp+0x20], xmm1
0000786bc93d8e5c  lea rdi, [rsp]
0000786bc93d8e60  mov esi, 0x00
0000786bc93d8e65  mov rax, 0x60810F6F7530
0000786bc93d8e6f  call rax
0000786bc93d8e71  movaps xmm9, [rsp]
0000786bc93d8e76  add rsp, 0x30
0000786bc93d8e7a  vmovaps xmm0, [rsp]
0000786bc93d8e7f  vmovaps xmm1, [rsp+0x10]
0000786bc93d8e85  vmovaps xmm2, [rsp+0x20]
0000786bc93d8e8b  vmovaps xmm3, [rsp+0x30]
0000786bc93d8e91  vmovaps xmm4, [rsp+0x40]
0000786bc93d8e97  vmovaps xmm5, [rsp+0x50]
0000786bc93d8e9d  vmovaps xmm6, [rsp+0x60]
0000786bc93d8ea3  vmovaps xmm7, [rsp+0x70]
0000786bc93d8ea9  vmovaps xmm8, [rsp+0x80]
0000786bc93d8eb2  vmovaps xmm10, [rsp+0x90]
0000786bc93d8ebb  vmovaps xmm11, [rsp+0xA0]
0000786bc93d8ec4  vmovaps xmm12, [rsp+0xB0]
0000786bc93d8ecd  vmovaps xmm13, [rsp+0xC0]
0000786bc93d8ed6  vmovaps xmm14, [rsp+0xD0]
0000786bc93d8edf  vmovaps xmm15, [rsp+0xE0]
0000786bc93d8ee8  add rsp, 0xF0
0000786bc93d8eef  pop r11
0000786bc93d8ef1  pop r10
0000786bc93d8ef3  pop r9
0000786bc93d8ef5  pop r8
0000786bc93d8ef7  pop rsi
0000786bc93d8ef8  pop rdi
0000786bc93d8ef9  pop rdx
0000786bc93d8efa  pop rcx
0000786bc93d8efb  pop rax
0000786bc93d8efc  add rsp, 0x08
0000786bc93d8f00  jmp 0x0000786BC93D61A1
0000786bc93d8f05  sub rsp, 0x08
0000786bc93d8f09  push rax
0000786bc93d8f0a  push rcx
0000786bc93d8f0b  push rdx
0000786bc93d8f0c  push rdi
0000786bc93d8f0d  push rsi
0000786bc93d8f0e  push r8
0000786bc93d8f10  push r9
0000786bc93d8f12  push r10
0000786bc93d8f14  push r11
0000786bc93d8f16  sub rsp, 0xF0
0000786bc93d8f1d  vmovaps [rsp], xmm0
0000786bc93d8f22  vmovaps [rsp+0x10], xmm2
0000786bc93d8f28  vmovaps [rsp+0x20], xmm3
0000786bc93d8f2e  vmovaps [rsp+0x30], xmm4
0000786bc93d8f34  vmovaps [rsp+0x40], xmm5
0000786bc93d8f3a  vmovaps [rsp+0x50], xmm6
0000786bc93d8f40  vmovaps [rsp+0x60], xmm7
0000786bc93d8f46  vmovaps [rsp+0x70], xmm8
0000786bc93d8f4c  vmovaps [rsp+0x80], xmm9
0000786bc93d8f55  vmovaps [rsp+0x90], xmm10
0000786bc93d8f5e  vmovaps [rsp+0xA0], xmm11
0000786bc93d8f67  vmovaps [rsp+0xB0], xmm12
0000786bc93d8f70  vmovaps [rsp+0xC0], xmm13
0000786bc93d8f79  vmovaps [rsp+0xD0], xmm14
0000786bc93d8f82  vmovaps [rsp+0xE0], xmm15
0000786bc93d8f8b  sub rsp, 0x30
0000786bc93d8f8f  movaps [rsp], xmm1
0000786bc93d8f93  movaps [rsp+0x10], xmm15
0000786bc93d8f99  movaps [rsp+0x20], xmm6
0000786bc93d8f9e  lea rdi, [rsp]
0000786bc93d8fa2  mov esi, 0x00
0000786bc93d8fa7  mov rax, 0x60810F6F7530
0000786bc93d8fb1  call rax
0000786bc93d8fb3  movaps xmm1, [rsp]
0000786bc93d8fb7  add rsp, 0x30
0000786bc93d8fbb  vmovaps xmm0, [rsp]
0000786bc93d8fc0  vmovaps xmm2, [rsp+0x10]
0000786bc93d8fc6  vmovaps xmm3, [rsp+0x20]
0000786bc93d8fcc  vmovaps xmm4, [rsp+0x30]
0000786bc93d8fd2  vmovaps xmm5, [rsp+0x40]
0000786bc93d8fd8  vmovaps xmm6, [rsp+0x50]
0000786bc93d8fde  vmovaps xmm7, [rsp+0x60]
0000786bc93d8fe4  vmovaps xmm8, [rsp+0x70]
0000786bc93d8fea  vmovaps xmm9, [rsp+0x80]
0000786bc93d8ff3  vmovaps xmm10, [rsp+0x90]
0000786bc93d8ffc  vmovaps xmm11, [rsp+0xA0]
0000786bc93d9005  vmovaps xmm12, [rsp+0xB0]
0000786bc93d900e  vmovaps xmm13, [rsp+0xC0]
0000786bc93d9017  vmovaps xmm14, [rsp+0xD0]
0000786bc93d9020  vmovaps xmm15, [rsp+0xE0]
0000786bc93d9029  add rsp, 0xF0
0000786bc93d9030  pop r11
0000786bc93d9032  pop r10
0000786bc93d9034  pop r9
0000786bc93d9036  pop r8
0000786bc93d9038  pop rsi
0000786bc93d9039  pop rdi
0000786bc93d903a  pop rdx
0000786bc93d903b  pop rcx
0000786bc93d903c  pop rax
0000786bc93d903d  add rsp, 0x08
0000786bc93d9041  jmp 0x0000786BC93D61C2
0000786bc93d9046  sub rsp, 0x08
0000786bc93d904a  push rax
0000786bc93d904b  push rcx
0000786bc93d904c  push rdx
0000786bc93d904d  push rdi
0000786bc93d904e  push rsi
0000786bc93d904f  push r8
0000786bc93d9051  push r9
0000786bc93d9053  push r10
0000786bc93d9055  push r11
0000786bc93d9057  sub rsp, 0xF0
0000786bc93d905e  vmovaps [rsp], xmm0
0000786bc93d9063  vmovaps [rsp+0x10], xmm1
0000786bc93d9069  vmovaps [rsp+0x20], xmm2
0000786bc93d906f  vmovaps [rsp+0x30], xmm3
0000786bc93d9075  vmovaps [rsp+0x40], xmm4
0000786bc93d907b  vmovaps [rsp+0x50], xmm5
0000786bc93d9081  vmovaps [rsp+0x60], xmm6
0000786bc93d9087  vmovaps [rsp+0x70], xmm7
0000786bc93d908d  vmovaps [rsp+0x80], xmm8
0000786bc93d9096  vmovaps [rsp+0x90], xmm9
0000786bc93d909f  vmovaps [rsp+0xA0], xmm10
0000786bc93d90a8  vmovaps [rsp+0xB0], xmm11
0000786bc93d90b1  vmovaps [rsp+0xC0], xmm12
0000786bc93d90ba  vmovaps [rsp+0xD0], xmm13
0000786bc93d90c3  vmovaps [rsp+0xE0], xmm14
0000786bc93d90cc  sub rsp, 0x30
0000786bc93d90d0  movaps [rsp], xmm15
0000786bc93d90d5  movaps [rsp+0x10], xmm5
0000786bc93d90da  movaps [rsp+0x20], xmm3
0000786bc93d90df  lea rdi, [rsp]
0000786bc93d90e3  mov esi, 0x00
0000786bc93d90e8  mov rax, 0x60810F6F7530
0000786bc93d90f2  call rax
0000786bc93d90f4  movaps xmm15, [rsp]
0000786bc93d90f9  add rsp, 0x30
0000786bc93d90fd  vmovaps xmm0, [rsp]
0000786bc93d9102  vmovaps xmm1, [rsp+0x10]
0000786bc93d9108  vmovaps xmm2, [rsp+0x20]
0000786bc93d910e  vmovaps xmm3, [rsp+0x30]
0000786bc93d9114  vmovaps xmm4, [rsp+0x40]
0000786bc93d911a  vmovaps xmm5, [rsp+0x50]
0000786bc93d9120  vmovaps xmm6, [rsp+0x60]
0000786bc93d9126  vmovaps xmm7, [rsp+0x70]
0000786bc93d912c  vmovaps xmm8, [rsp+0x80]
0000786bc93d9135  vmovaps xmm9, [rsp+0x90]
0000786bc93d913e  vmovaps xmm10, [rsp+0xA0]
0000786bc93d9147  vmovaps xmm11, [rsp+0xB0]
0000786bc93d9150  vmovaps xmm12, [rsp+0xC0]
0000786bc93d9159  vmovaps xmm13, [rsp+0xD0]
0000786bc93d9162  vmovaps xmm14, [rsp+0xE0]
0000786bc93d916b  add rsp, 0xF0
0000786bc93d9172  pop r11
0000786bc93d9174  pop r10
0000786bc93d9176  pop r9
0000786bc93d9178  pop r8
0000786bc93d917a  pop rsi
0000786bc93d917b  pop rdi
0000786bc93d917c  pop rdx
0000786bc93d917d  pop rcx
0000786bc93d917e  pop rax
0000786bc93d917f  add rsp, 0x08
0000786bc93d9183  jmp 0x0000786BC93D61DC
0000786bc93d9188  sub rsp, 0x08
0000786bc93d918c  push rax
0000786bc93d918d  push rcx
0000786bc93d918e  push rdx
0000786bc93d918f  push rdi
0000786bc93d9190  push rsi
0000786bc93d9191  push r8
0000786bc93d9193  push r9
0000786bc93d9195  push r10
0000786bc93d9197  push r11
0000786bc93d9199  sub rsp, 0xF0
0000786bc93d91a0  vmovaps [rsp], xmm0
0000786bc93d91a5  vmovaps [rsp+0x10], xmm1
0000786bc93d91ab  vmovaps [rsp+0x20], xmm2
0000786bc93d91b1  vmovaps [rsp+0x30], xmm3
0000786bc93d91b7  vmovaps [rsp+0x40], xmm4
0000786bc93d91bd  vmovaps [rsp+0x50], xmm6
0000786bc93d91c3  vmovaps [rsp+0x60], xmm7
0000786bc93d91c9  vmovaps [rsp+0x70], xmm8
0000786bc93d91cf  vmovaps [rsp+0x80], xmm9
0000786bc93d91d8  vmovaps [rsp+0x90], xmm10
0000786bc93d91e1  vmovaps [rsp+0xA0], xmm11
0000786bc93d91ea  vmovaps [rsp+0xB0], xmm12
0000786bc93d91f3  vmovaps [rsp+0xC0], xmm13
0000786bc93d91fc  vmovaps [rsp+0xD0], xmm14
0000786bc93d9205  vmovaps [rsp+0xE0], xmm15
0000786bc93d920e  sub rsp, 0x30
0000786bc93d9212  movaps [rsp], xmm5
0000786bc93d9216  movaps [rsp+0x10], xmm8
0000786bc93d921c  movaps [rsp+0x20], xmm6
0000786bc93d9221  lea rdi, [rsp]
0000786bc93d9225  mov esi, 0x00
0000786bc93d922a  mov rax, 0x60810F6F7530
0000786bc93d9234  call rax
0000786bc93d9236  movaps xmm5, [rsp]
0000786bc93d923a  add rsp, 0x30
0000786bc93d923e  vmovaps xmm0, [rsp]
0000786bc93d9243  vmovaps xmm1, [rsp+0x10]
0000786bc93d9249  vmovaps xmm2, [rsp+0x20]
0000786bc93d924f  vmovaps xmm3, [rsp+0x30]
0000786bc93d9255  vmovaps xmm4, [rsp+0x40]
0000786bc93d925b  vmovaps xmm6, [rsp+0x50]
0000786bc93d9261  vmovaps xmm7, [rsp+0x60]
0000786bc93d9267  vmovaps xmm8, [rsp+0x70]
0000786bc93d926d  vmovaps xmm9, [rsp+0x80]
0000786bc93d9276  vmovaps xmm10, [rsp+0x90]
0000786bc93d927f  vmovaps xmm11, [rsp+0xA0]
0000786bc93d9288  vmovaps xmm12, [rsp+0xB0]
0000786bc93d9291  vmovaps xmm13, [rsp+0xC0]
0000786bc93d929a  vmovaps xmm14, [rsp+0xD0]
0000786bc93d92a3  vmovaps xmm15, [rsp+0xE0]
0000786bc93d92ac  add rsp, 0xF0
0000786bc93d92b3  pop r11
0000786bc93d92b5  pop r10
0000786bc93d92b7  pop r9
0000786bc93d92b9  pop r8
0000786bc93d92bb  pop rsi
0000786bc93d92bc  pop rdi
0000786bc93d92bd  pop rdx
0000786bc93d92be  pop rcx
0000786bc93d92bf  pop rax
0000786bc93d92c0  add rsp, 0x08
0000786bc93d92c4  jmp 0x0000786BC93D6200
0000786bc93d92c9  sub rsp, 0x08
0000786bc93d92cd  push rax
0000786bc93d92ce  push rcx
0000786bc93d92cf  push rdx
0000786bc93d92d0  push rdi
0000786bc93d92d1  push rsi
0000786bc93d92d2  push r8
0000786bc93d92d4  push r9
0000786bc93d92d6  push r10
0000786bc93d92d8  push r11
0000786bc93d92da  sub rsp, 0xF0
0000786bc93d92e1  vmovaps [rsp], xmm0
0000786bc93d92e6  vmovaps [rsp+0x10], xmm1
0000786bc93d92ec  vmovaps [rsp+0x20], xmm2
0000786bc93d92f2  vmovaps [rsp+0x30], xmm3
0000786bc93d92f8  vmovaps [rsp+0x40], xmm4
0000786bc93d92fe  vmovaps [rsp+0x50], xmm5
0000786bc93d9304  vmovaps [rsp+0x60], xmm7
0000786bc93d930a  vmovaps [rsp+0x70], xmm8
0000786bc93d9310  vmovaps [rsp+0x80], xmm9
0000786bc93d9319  vmovaps [rsp+0x90], xmm10
0000786bc93d9322  vmovaps [rsp+0xA0], xmm11
0000786bc93d932b  vmovaps [rsp+0xB0], xmm12
0000786bc93d9334  vmovaps [rsp+0xC0], xmm13
0000786bc93d933d  vmovaps [rsp+0xD0], xmm14
0000786bc93d9346  vmovaps [rsp+0xE0], xmm15
0000786bc93d934f  sub rsp, 0x30
0000786bc93d9353  movaps [rsp], xmm6
0000786bc93d9357  movaps [rsp+0x10], xmm10
0000786bc93d935d  movaps [rsp+0x20], xmm8
0000786bc93d9363  lea rdi, [rsp]
0000786bc93d9367  mov esi, 0x00
0000786bc93d936c  mov rax, 0x60810F6F7530
0000786bc93d9376  call rax
0000786bc93d9378  movaps xmm6, [rsp]
0000786bc93d937c  add rsp, 0x30
0000786bc93d9380  vmovaps xmm0, [rsp]
0000786bc93d9385  vmovaps xmm1, [rsp+0x10]
0000786bc93d938b  vmovaps xmm2, [rsp+0x20]
0000786bc93d9391  vmovaps xmm3, [rsp+0x30]
0000786bc93d9397  vmovaps xmm4, [rsp+0x40]
0000786bc93d939d  vmovaps xmm5, [rsp+0x50]
0000786bc93d93a3  vmovaps xmm7, [rsp+0x60]
0000786bc93d93a9  vmovaps xmm8, [rsp+0x70]
0000786bc93d93af  vmovaps xmm9, [rsp+0x80]
0000786bc93d93b8  vmovaps xmm10, [rsp+0x90]
0000786bc93d93c1  vmovaps xmm11, [rsp+0xA0]
0000786bc93d93ca  vmovaps xmm12, [rsp+0xB0]
0000786bc93d93d3  vmovaps xmm13, [rsp+0xC0]
0000786bc93d93dc  vmovaps xmm14, [rsp+0xD0]
0000786bc93d93e5  vmovaps xmm15, [rsp+0xE0]
0000786bc93d93ee  add rsp, 0xF0
0000786bc93d93f5  pop r11
0000786bc93d93f7  pop r10
0000786bc93d93f9  pop r9
0000786bc93d93fb  pop r8
0000786bc93d93fd  pop rsi
0000786bc93d93fe  pop rdi
0000786bc93d93ff  pop rdx
0000786bc93d9400  pop rcx
0000786bc93d9401  pop rax
0000786bc93d9402  add rsp, 0x08
0000786bc93d9406  jmp 0x0000786BC93D6225
0000786bc93d940b  sub rsp, 0x08
0000786bc93d940f  push rax
0000786bc93d9410  push rcx
0000786bc93d9411  push rdx
0000786bc93d9412  push rdi
0000786bc93d9413  push rsi
0000786bc93d9414  push r8
0000786bc93d9416  push r9
0000786bc93d9418  push r10
0000786bc93d941a  push r11
0000786bc93d941c  sub rsp, 0xF0
0000786bc93d9423  vmovaps [rsp], xmm0
0000786bc93d9428  vmovaps [rsp+0x10], xmm1
0000786bc93d942e  vmovaps [rsp+0x20], xmm2
0000786bc93d9434  vmovaps [rsp+0x30], xmm3
0000786bc93d943a  vmovaps [rsp+0x40], xmm4
0000786bc93d9440  vmovaps [rsp+0x50], xmm5
0000786bc93d9446  vmovaps [rsp+0x60], xmm6
0000786bc93d944c  vmovaps [rsp+0x70], xmm7
0000786bc93d9452  vmovaps [rsp+0x80], xmm8
0000786bc93d945b  vmovaps [rsp+0x90], xmm9
0000786bc93d9464  vmovaps [rsp+0xA0], xmm11
0000786bc93d946d  vmovaps [rsp+0xB0], xmm12
0000786bc93d9476  vmovaps [rsp+0xC0], xmm13
0000786bc93d947f  vmovaps [rsp+0xD0], xmm14
0000786bc93d9488  vmovaps [rsp+0xE0], xmm15
0000786bc93d9491  sub rsp, 0x30
0000786bc93d9495  movaps [rsp], xmm10
0000786bc93d949a  movaps [rsp+0x10], xmm8
0000786bc93d94a0  movaps [rsp+0x20], xmm14
0000786bc93d94a6  lea rdi, [rsp]
0000786bc93d94aa  mov esi, 0x00
0000786bc93d94af  mov rax, 0x60810F6F7530
0000786bc93d94b9  call rax
0000786bc93d94bb  movaps xmm10, [rsp]
0000786bc93d94c0  add rsp, 0x30
0000786bc93d94c4  vmovaps xmm0, [rsp]
0000786bc93d94c9  vmovaps xmm1, [rsp+0x10]
0000786bc93d94cf  vmovaps xmm2, [rsp+0x20]
0000786bc93d94d5  vmovaps xmm3, [rsp+0x30]
0000786bc93d94db  vmovaps xmm4, [rsp+0x40]
0000786bc93d94e1  vmovaps xmm5, [rsp+0x50]
0000786bc93d94e7  vmovaps xmm6, [rsp+0x60]
0000786bc93d94ed  vmovaps xmm7, [rsp+0x70]
0000786bc93d94f3  vmovaps xmm8, [rsp+0x80]
0000786bc93d94fc  vmovaps xmm9, [rsp+0x90]
0000786bc93d9505  vmovaps xmm11, [rsp+0xA0]
0000786bc93d950e  vmovaps xmm12, [rsp+0xB0]
0000786bc93d9517  vmovaps xmm13, [rsp+0xC0]
0000786bc93d9520  vmovaps xmm14, [rsp+0xD0]
0000786bc93d9529  vmovaps xmm15, [rsp+0xE0]
0000786bc93d9532  add rsp, 0xF0
0000786bc93d9539  pop r11
0000786bc93d953b  pop r10
0000786bc93d953d  pop r9
0000786bc93d953f  pop r8
0000786bc93d9541  pop rsi
0000786bc93d9542  pop rdi
0000786bc93d9543  pop rdx
0000786bc93d9544  pop rcx
0000786bc93d9545  pop rax
0000786bc93d9546  add rsp, 0x08
0000786bc93d954a  jmp 0x0000786BC93D6245
0000786bc93d954f  sub rsp, 0x08
0000786bc93d9553  push rax
0000786bc93d9554  push rcx
0000786bc93d9555  push rdx
0000786bc93d9556  push rdi
0000786bc93d9557  push rsi
0000786bc93d9558  push r8
0000786bc93d955a  push r9
0000786bc93d955c  push r10
0000786bc93d955e  push r11
0000786bc93d9560  sub rsp, 0xF0
0000786bc93d9567  vmovaps [rsp], xmm0
0000786bc93d956c  vmovaps [rsp+0x10], xmm1
0000786bc93d9572  vmovaps [rsp+0x20], xmm2
0000786bc93d9578  vmovaps [rsp+0x30], xmm3
0000786bc93d957e  vmovaps [rsp+0x40], xmm4
0000786bc93d9584  vmovaps [rsp+0x50], xmm5
0000786bc93d958a  vmovaps [rsp+0x60], xmm6
0000786bc93d9590  vmovaps [rsp+0x70], xmm7
0000786bc93d9596  vmovaps [rsp+0x80], xmm8
0000786bc93d959f  vmovaps [rsp+0x90], xmm9
0000786bc93d95a8  vmovaps [rsp+0xA0], xmm10
0000786bc93d95b1  vmovaps [rsp+0xB0], xmm11
0000786bc93d95ba  vmovaps [rsp+0xC0], xmm12
0000786bc93d95c3  vmovaps [rsp+0xD0], xmm13
0000786bc93d95cc  vmovaps [rsp+0xE0], xmm15
0000786bc93d95d5  sub rsp, 0x30
0000786bc93d95d9  movaps [rsp], xmm14
0000786bc93d95de  movaps [rsp+0x10], xmm8
0000786bc93d95e4  movaps [rsp+0x20], xmm4
0000786bc93d95e9  lea rdi, [rsp]
0000786bc93d95ed  mov esi, 0x00
0000786bc93d95f2  mov rax, 0x60810F6F7530
0000786bc93d95fc  call rax
0000786bc93d95fe  movaps xmm14, [rsp]
0000786bc93d9603  add rsp, 0x30
0000786bc93d9607  vmovaps xmm0, [rsp]
0000786bc93d960c  vmovaps xmm1, [rsp+0x10]
0000786bc93d9612  vmovaps xmm2, [rsp+0x20]
0000786bc93d9618  vmovaps xmm3, [rsp+0x30]
0000786bc93d961e  vmovaps xmm4, [rsp+0x40]
0000786bc93d9624  vmovaps xmm5, [rsp+0x50]
0000786bc93d962a  vmovaps xmm6, [rsp+0x60]
0000786bc93d9630  vmovaps xmm7, [rsp+0x70]
0000786bc93d9636  vmovaps xmm8, [rsp+0x80]
0000786bc93d963f  vmovaps xmm9, [rsp+0x90]
0000786bc93d9648  vmovaps xmm10, [rsp+0xA0]
0000786bc93d9651  vmovaps xmm11, [rsp+0xB0]
0000786bc93d965a  vmovaps xmm12, [rsp+0xC0]
0000786bc93d9663  vmovaps xmm13, [rsp+0xD0]
0000786bc93d966c  vmovaps xmm15, [rsp+0xE0]
0000786bc93d9675  add rsp, 0xF0
0000786bc93d967c  pop r11
0000786bc93d967e  pop r10
0000786bc93d9680  pop r9
0000786bc93d9682  pop r8
0000786bc93d9684  pop rsi
0000786bc93d9685  pop rdi
0000786bc93d9686  pop rdx
0000786bc93d9687  pop rcx
0000786bc93d9688  pop rax
0000786bc93d9689  add rsp, 0x08
0000786bc93d968d  jmp 0x0000786BC93D6265
0000786bc93d9692  sub rsp, 0x08
0000786bc93d9696  push rax
0000786bc93d9697  push rcx
0000786bc93d9698  push rdx
0000786bc93d9699  push rdi
0000786bc93d969a  push rsi
0000786bc93d969b  push r8
0000786bc93d969d  push r9
0000786bc93d969f  push r10
0000786bc93d96a1  push r11
0000786bc93d96a3  sub rsp, 0xF0
0000786bc93d96aa  vmovaps [rsp], xmm0
0000786bc93d96af  vmovaps [rsp+0x10], xmm1
0000786bc93d96b5  vmovaps [rsp+0x20], xmm2
0000786bc93d96bb  vmovaps [rsp+0x30], xmm3
0000786bc93d96c1  vmovaps [rsp+0x40], xmm5
0000786bc93d96c7  vmovaps [rsp+0x50], xmm6
0000786bc93d96cd  vmovaps [rsp+0x60], xmm7
0000786bc93d96d3  vmovaps [rsp+0x70], xmm8
0000786bc93d96d9  vmovaps [rsp+0x80], xmm9
0000786bc93d96e2  vmovaps [rsp+0x90], xmm10
0000786bc93d96eb  vmovaps [rsp+0xA0], xmm11
0000786bc93d96f4  vmovaps [rsp+0xB0], xmm12
0000786bc93d96fd  vmovaps [rsp+0xC0], xmm13
0000786bc93d9706  vmovaps [rsp+0xD0], xmm14
0000786bc93d970f  vmovaps [rsp+0xE0], xmm15
0000786bc93d9718  sub rsp, 0x30
0000786bc93d971c  movaps [rsp], xmm4
0000786bc93d9720  movaps [rsp+0x10], xmm13
0000786bc93d9726  movaps [rsp+0x20], xmm8
0000786bc93d972c  lea rdi, [rsp]
0000786bc93d9730  mov esi, 0x00
0000786bc93d9735  mov rax, 0x60810F6F7530
0000786bc93d973f  call rax
0000786bc93d9741  movaps xmm4, [rsp]
0000786bc93d9745  add rsp, 0x30
0000786bc93d9749  vmovaps xmm0, [rsp]
0000786bc93d974e  vmovaps xmm1, [rsp+0x10]
0000786bc93d9754  vmovaps xmm2, [rsp+0x20]
0000786bc93d975a  vmovaps xmm3, [rsp+0x30]
0000786bc93d9760  vmovaps xmm5, [rsp+0x40]
0000786bc93d9766  vmovaps xmm6, [rsp+0x50]
0000786bc93d976c  vmovaps xmm7, [rsp+0x60]
0000786bc93d9772  vmovaps xmm8, [rsp+0x70]
0000786bc93d9778  vmovaps xmm9, [rsp+0x80]
0000786bc93d9781  vmovaps xmm10, [rsp+0x90]
0000786bc93d978a  vmovaps xmm11, [rsp+0xA0]
0000786bc93d9793  vmovaps xmm12, [rsp+0xB0]
0000786bc93d979c  vmovaps xmm13, [rsp+0xC0]
0000786bc93d97a5  vmovaps xmm14, [rsp+0xD0]
0000786bc93d97ae  vmovaps xmm15, [rsp+0xE0]
0000786bc93d97b7  add rsp, 0xF0
0000786bc93d97be  pop r11
0000786bc93d97c0  pop r10
0000786bc93d97c2  pop r9
0000786bc93d97c4  pop r8
0000786bc93d97c6  pop rsi
0000786bc93d97c7  pop rdi
0000786bc93d97c8  pop rdx
0000786bc93d97c9  pop rcx
0000786bc93d97ca  pop rax
0000786bc93d97cb  add rsp, 0x08
0000786bc93d97cf  jmp 0x0000786BC93D628A
0000786bc93d97d4  sub rsp, 0x08
0000786bc93d97d8  push rax
0000786bc93d97d9  push rcx
0000786bc93d97da  push rdx
0000786bc93d97db  push rdi
0000786bc93d97dc  push rsi
0000786bc93d97dd  push r8
0000786bc93d97df  push r9
0000786bc93d97e1  push r10
0000786bc93d97e3  push r11
0000786bc93d97e5  sub rsp, 0xF0
0000786bc93d97ec  vmovaps [rsp], xmm0
0000786bc93d97f1  vmovaps [rsp+0x10], xmm1
0000786bc93d97f7  vmovaps [rsp+0x20], xmm2
0000786bc93d97fd  vmovaps [rsp+0x30], xmm3
0000786bc93d9803  vmovaps [rsp+0x40], xmm4
0000786bc93d9809  vmovaps [rsp+0x50], xmm5
0000786bc93d980f  vmovaps [rsp+0x60], xmm6
0000786bc93d9815  vmovaps [rsp+0x70], xmm7
0000786bc93d981b  vmovaps [rsp+0x80], xmm8
0000786bc93d9824  vmovaps [rsp+0x90], xmm9
0000786bc93d982d  vmovaps [rsp+0xA0], xmm10
0000786bc93d9836  vmovaps [rsp+0xB0], xmm11
0000786bc93d983f  vmovaps [rsp+0xC0], xmm12
0000786bc93d9848  vmovaps [rsp+0xD0], xmm14
0000786bc93d9851  vmovaps [rsp+0xE0], xmm15
0000786bc93d985a  sub rsp, 0x30
0000786bc93d985e  movaps [rsp], xmm13
0000786bc93d9863  movaps [rsp+0x10], xmm15
0000786bc93d9869  movaps [rsp+0x20], xmm9
0000786bc93d986f  lea rdi, [rsp]
0000786bc93d9873  mov esi, 0x00
0000786bc93d9878  mov rax, 0x60810F6F7530
0000786bc93d9882  call rax
0000786bc93d9884  movaps xmm13, [rsp]
0000786bc93d9889  add rsp, 0x30
0000786bc93d988d  vmovaps xmm0, [rsp]
0000786bc93d9892  vmovaps xmm1, [rsp+0x10]
0000786bc93d9898  vmovaps xmm2, [rsp+0x20]
0000786bc93d989e  vmovaps xmm3, [rsp+0x30]
0000786bc93d98a4  vmovaps xmm4, [rsp+0x40]
0000786bc93d98aa  vmovaps xmm5, [rsp+0x50]
0000786bc93d98b0  vmovaps xmm6, [rsp+0x60]
0000786bc93d98b6  vmovaps xmm7, [rsp+0x70]
0000786bc93d98bc  vmovaps xmm8, [rsp+0x80]
0000786bc93d98c5  vmovaps xmm9, [rsp+0x90]
0000786bc93d98ce  vmovaps xmm10, [rsp+0xA0]
0000786bc93d98d7  vmovaps xmm11, [rsp+0xB0]
0000786bc93d98e0  vmovaps xmm12, [rsp+0xC0]
0000786bc93d98e9  vmovaps xmm14, [rsp+0xD0]
0000786bc93d98f2  vmovaps xmm15, [rsp+0xE0]
0000786bc93d98fb  add rsp, 0xF0
0000786bc93d9902  pop r11
0000786bc93d9904  pop r10
0000786bc93d9906  pop r9
0000786bc93d9908  pop r8
0000786bc93d990a  pop rsi
0000786bc93d990b  pop rdi
0000786bc93d990c  pop rdx
0000786bc93d990d  pop rcx
0000786bc93d990e  pop rax
0000786bc93d990f  add rsp, 0x08
0000786bc93d9913  jmp 0x0000786BC93D62A5
0000786bc93d9918  sub rsp, 0x08
0000786bc93d991c  push rax
0000786bc93d991d  push rcx
0000786bc93d991e  push rdx
0000786bc93d991f  push rdi
0000786bc93d9920  push rsi
0000786bc93d9921  push r8
0000786bc93d9923  push r9
0000786bc93d9925  push r10
0000786bc93d9927  push r11
0000786bc93d9929  sub rsp, 0xF0
0000786bc93d9930  vmovaps [rsp], xmm0
0000786bc93d9935  vmovaps [rsp+0x10], xmm1
0000786bc93d993b  vmovaps [rsp+0x20], xmm2
0000786bc93d9941  vmovaps [rsp+0x30], xmm3
0000786bc93d9947  vmovaps [rsp+0x40], xmm4
0000786bc93d994d  vmovaps [rsp+0x50], xmm5
0000786bc93d9953  vmovaps [rsp+0x60], xmm6
0000786bc93d9959  vmovaps [rsp+0x70], xmm7
0000786bc93d995f  vmovaps [rsp+0x80], xmm8
0000786bc93d9968  vmovaps [rsp+0x90], xmm9
0000786bc93d9971  vmovaps [rsp+0xA0], xmm10
0000786bc93d997a  vmovaps [rsp+0xB0], xmm11
0000786bc93d9983  vmovaps [rsp+0xC0], xmm12
0000786bc93d998c  vmovaps [rsp+0xD0], xmm13
0000786bc93d9995  vmovaps [rsp+0xE0], xmm14
0000786bc93d999e  sub rsp, 0x30
0000786bc93d99a2  movaps [rsp], xmm15
0000786bc93d99a7  movaps [rsp+0x10], xmm1
0000786bc93d99ac  movaps [rsp+0x20], xmm5
0000786bc93d99b1  lea rdi, [rsp]
0000786bc93d99b5  mov esi, 0x00
0000786bc93d99ba  mov rax, 0x60810F6F7530
0000786bc93d99c4  call rax
0000786bc93d99c6  movaps xmm15, [rsp]
0000786bc93d99cb  add rsp, 0x30
0000786bc93d99cf  vmovaps xmm0, [rsp]
0000786bc93d99d4  vmovaps xmm1, [rsp+0x10]
0000786bc93d99da  vmovaps xmm2, [rsp+0x20]
0000786bc93d99e0  vmovaps xmm3, [rsp+0x30]
0000786bc93d99e6  vmovaps xmm4, [rsp+0x40]
0000786bc93d99ec  vmovaps xmm5, [rsp+0x50]
0000786bc93d99f2  vmovaps xmm6, [rsp+0x60]
0000786bc93d99f8  vmovaps xmm7, [rsp+0x70]
0000786bc93d99fe  vmovaps xmm8, [rsp+0x80]
0000786bc93d9a07  vmovaps xmm9, [rsp+0x90]
0000786bc93d9a10  vmovaps xmm10, [rsp+0xA0]
0000786bc93d9a19  vmovaps xmm11, [rsp+0xB0]
0000786bc93d9a22  vmovaps xmm12, [rsp+0xC0]
0000786bc93d9a2b  vmovaps xmm13, [rsp+0xD0]
0000786bc93d9a34  vmovaps xmm14, [rsp+0xE0]
0000786bc93d9a3d  add rsp, 0xF0
0000786bc93d9a44  pop r11
0000786bc93d9a46  pop r10
0000786bc93d9a48  pop r9
0000786bc93d9a4a  pop r8
0000786bc93d9a4c  pop rsi
0000786bc93d9a4d  pop rdi
0000786bc93d9a4e  pop rdx
0000786bc93d9a4f  pop rcx
0000786bc93d9a50  pop rax
0000786bc93d9a51  add rsp, 0x08
0000786bc93d9a55  jmp 0x0000786BC93D62C0
0000786bc93d9a5a  call 0x0000786BC92D64F0
0000786bc93d9a5f  jmp 0x0000786BC93D631B
0000786bc93d9a64  sub rsp, 0x08
0000786bc93d9a68  push rax
0000786bc93d9a69  push rcx
0000786bc93d9a6a  push rdx
0000786bc93d9a6b  push rdi
0000786bc93d9a6c  push rsi
0000786bc93d9a6d  push r8
0000786bc93d9a6f  push r9
0000786bc93d9a71  push r10
0000786bc93d9a73  push r11
0000786bc93d9a75  sub rsp, 0xF0
0000786bc93d9a7c  vmovaps [rsp], xmm0
0000786bc93d9a81  vmovaps [rsp+0x10], xmm1
0000786bc93d9a87  vmovaps [rsp+0x20], xmm2
0000786bc93d9a8d  vmovaps [rsp+0x30], xmm3
0000786bc93d9a93  vmovaps [rsp+0x40], xmm4
0000786bc93d9a99  vmovaps [rsp+0x50], xmm5
0000786bc93d9a9f  vmovaps [rsp+0x60], xmm6
0000786bc93d9aa5  vmovaps [rsp+0x70], xmm7
0000786bc93d9aab  vmovaps [rsp+0x80], xmm8
0000786bc93d9ab4  vmovaps [rsp+0x90], xmm10
0000786bc93d9abd  vmovaps [rsp+0xA0], xmm11
0000786bc93d9ac6  vmovaps [rsp+0xB0], xmm12
0000786bc93d9acf  vmovaps [rsp+0xC0], xmm13
0000786bc93d9ad8  vmovaps [rsp+0xD0], xmm14
0000786bc93d9ae1  vmovaps [rsp+0xE0], xmm15
0000786bc93d9aea  sub rsp, 0x30
0000786bc93d9aee  movaps [rsp], xmm9
0000786bc93d9af3  movaps [rsp+0x10], xmm8
0000786bc93d9af9  movaps [rsp+0x20], xmm11
0000786bc93d9aff  lea rdi, [rsp]
0000786bc93d9b03  mov esi, 0x00
0000786bc93d9b08  mov rax, 0x60810F6F7530
0000786bc93d9b12  call rax
0000786bc93d9b14  movaps xmm9, [rsp]
0000786bc93d9b19  add rsp, 0x30
0000786bc93d9b1d  vmovaps xmm0, [rsp]
0000786bc93d9b22  vmovaps xmm1, [rsp+0x10]
0000786bc93d9b28  vmovaps xmm2, [rsp+0x20]
0000786bc93d9b2e  vmovaps xmm3, [rsp+0x30]
0000786bc93d9b34  vmovaps xmm4, [rsp+0x40]
0000786bc93d9b3a  vmovaps xmm5, [rsp+0x50]
0000786bc93d9b40  vmovaps xmm6, [rsp+0x60]
0000786bc93d9b46  vmovaps xmm7, [rsp+0x70]
0000786bc93d9b4c  vmovaps xmm8, [rsp+0x80]
0000786bc93d9b55  vmovaps xmm10, [rsp+0x90]
0000786bc93d9b5e  vmovaps xmm11, [rsp+0xA0]
0000786bc93d9b67  vmovaps xmm12, [rsp+0xB0]
0000786bc93d9b70  vmovaps xmm13, [rsp+0xC0]
0000786bc93d9b79  vmovaps xmm14, [rsp+0xD0]
0000786bc93d9b82  vmovaps xmm15, [rsp+0xE0]
0000786bc93d9b8b  add rsp, 0xF0
0000786bc93d9b92  pop r11
0000786bc93d9b94  pop r10
0000786bc93d9b96  pop r9
0000786bc93d9b98  pop r8
0000786bc93d9b9a  pop rsi
0000786bc93d9b9b  pop rdi
0000786bc93d9b9c  pop rdx
0000786bc93d9b9d  pop rcx
0000786bc93d9b9e  pop rax
0000786bc93d9b9f  add rsp, 0x08
0000786bc93d9ba3  jmp 0x0000786BC93D6352
0000786bc93d9ba8  sub rsp, 0x08
0000786bc93d9bac  push rax
0000786bc93d9bad  push rcx
0000786bc93d9bae  push rdx
0000786bc93d9baf  push rdi
0000786bc93d9bb0  push rsi
0000786bc93d9bb1  push r8
0000786bc93d9bb3  push r9
0000786bc93d9bb5  push r10
0000786bc93d9bb7  push r11
0000786bc93d9bb9  sub rsp, 0xF0
0000786bc93d9bc0  vmovaps [rsp], xmm0
0000786bc93d9bc5  vmovaps [rsp+0x10], xmm1
0000786bc93d9bcb  vmovaps [rsp+0x20], xmm2
0000786bc93d9bd1  vmovaps [rsp+0x30], xmm3
0000786bc93d9bd7  vmovaps [rsp+0x40], xmm4
0000786bc93d9bdd  vmovaps [rsp+0x50], xmm5
0000786bc93d9be3  vmovaps [rsp+0x60], xmm6
0000786bc93d9be9  vmovaps [rsp+0x70], xmm7
0000786bc93d9bef  vmovaps [rsp+0x80], xmm8
0000786bc93d9bf8  vmovaps [rsp+0x90], xmm9
0000786bc93d9c01  vmovaps [rsp+0xA0], xmm10
0000786bc93d9c0a  vmovaps [rsp+0xB0], xmm12
0000786bc93d9c13  vmovaps [rsp+0xC0], xmm13
0000786bc93d9c1c  vmovaps [rsp+0xD0], xmm14
0000786bc93d9c25  vmovaps [rsp+0xE0], xmm15
0000786bc93d9c2e  sub rsp, 0x30
0000786bc93d9c32  movaps [rsp], xmm11
0000786bc93d9c37  movaps [rsp+0x10], xmm10
0000786bc93d9c3d  movaps [rsp+0x20], xmm6
0000786bc93d9c42  lea rdi, [rsp]
0000786bc93d9c46  mov esi, 0x00
0000786bc93d9c4b  mov rax, 0x60810F6F7530
0000786bc93d9c55  call rax
0000786bc93d9c57  movaps xmm11, [rsp]
0000786bc93d9c5c  add rsp, 0x30
0000786bc93d9c60  vmovaps xmm0, [rsp]
0000786bc93d9c65  vmovaps xmm1, [rsp+0x10]
0000786bc93d9c6b  vmovaps xmm2, [rsp+0x20]
0000786bc93d9c71  vmovaps xmm3, [rsp+0x30]
0000786bc93d9c77  vmovaps xmm4, [rsp+0x40]
0000786bc93d9c7d  vmovaps xmm5, [rsp+0x50]
0000786bc93d9c83  vmovaps xmm6, [rsp+0x60]
0000786bc93d9c89  vmovaps xmm7, [rsp+0x70]
0000786bc93d9c8f  vmovaps xmm8, [rsp+0x80]
0000786bc93d9c98  vmovaps xmm9, [rsp+0x90]
0000786bc93d9ca1  vmovaps xmm10, [rsp+0xA0]
0000786bc93d9caa  vmovaps xmm12, [rsp+0xB0]
0000786bc93d9cb3  vmovaps xmm13, [rsp+0xC0]
0000786bc93d9cbc  vmovaps xmm14, [rsp+0xD0]
0000786bc93d9cc5  vmovaps xmm15, [rsp+0xE0]
0000786bc93d9cce  add rsp, 0xF0
0000786bc93d9cd5  pop r11
0000786bc93d9cd7  pop r10
0000786bc93d9cd9  pop r9
0000786bc93d9cdb  pop r8
0000786bc93d9cdd  pop rsi
0000786bc93d9cde  pop rdi
0000786bc93d9cdf  pop rdx
0000786bc93d9ce0  pop rcx
0000786bc93d9ce1  pop rax
0000786bc93d9ce2  add rsp, 0x08
0000786bc93d9ce6  jmp 0x0000786BC93D636D
0000786bc93d9ceb  sub rsp, 0x08
0000786bc93d9cef  push rax
0000786bc93d9cf0  push rcx
0000786bc93d9cf1  push rdx
0000786bc93d9cf2  push rdi
0000786bc93d9cf3  push rsi
0000786bc93d9cf4  push r8
0000786bc93d9cf6  push r9
0000786bc93d9cf8  push r10
0000786bc93d9cfa  push r11
0000786bc93d9cfc  sub rsp, 0xF0
0000786bc93d9d03  vmovaps [rsp], xmm0
0000786bc93d9d08  vmovaps [rsp+0x10], xmm1
0000786bc93d9d0e  vmovaps [rsp+0x20], xmm2
0000786bc93d9d14  vmovaps [rsp+0x30], xmm3
0000786bc93d9d1a  vmovaps [rsp+0x40], xmm4
0000786bc93d9d20  vmovaps [rsp+0x50], xmm5
0000786bc93d9d26  vmovaps [rsp+0x60], xmm6
0000786bc93d9d2c  vmovaps [rsp+0x70], xmm7
0000786bc93d9d32  vmovaps [rsp+0x80], xmm8
0000786bc93d9d3b  vmovaps [rsp+0x90], xmm9
0000786bc93d9d44  vmovaps [rsp+0xA0], xmm11
0000786bc93d9d4d  vmovaps [rsp+0xB0], xmm12
0000786bc93d9d56  vmovaps [rsp+0xC0], xmm13
0000786bc93d9d5f  vmovaps [rsp+0xD0], xmm14
0000786bc93d9d68  vmovaps [rsp+0xE0], xmm15
0000786bc93d9d71  sub rsp, 0x30
0000786bc93d9d75  movaps [rsp], xmm10
0000786bc93d9d7a  movaps [rsp+0x10], xmm14
0000786bc93d9d80  movaps [rsp+0x20], xmm4
0000786bc93d9d85  lea rdi, [rsp]
0000786bc93d9d89  mov esi, 0x00
0000786bc93d9d8e  mov rax, 0x60810F6F7530
0000786bc93d9d98  call rax
0000786bc93d9d9a  movaps xmm10, [rsp]
0000786bc93d9d9f  add rsp, 0x30
0000786bc93d9da3  vmovaps xmm0, [rsp]
0000786bc93d9da8  vmovaps xmm1, [rsp+0x10]
0000786bc93d9dae  vmovaps xmm2, [rsp+0x20]
0000786bc93d9db4  vmovaps xmm3, [rsp+0x30]
0000786bc93d9dba  vmovaps xmm4, [rsp+0x40]
0000786bc93d9dc0  vmovaps xmm5, [rsp+0x50]
0000786bc93d9dc6  vmovaps xmm6, [rsp+0x60]
0000786bc93d9dcc  vmovaps xmm7, [rsp+0x70]
0000786bc93d9dd2  vmovaps xmm8, [rsp+0x80]
0000786bc93d9ddb  vmovaps xmm9, [rsp+0x90]
0000786bc93d9de4  vmovaps xmm11, [rsp+0xA0]
0000786bc93d9ded  vmovaps xmm12, [rsp+0xB0]
0000786bc93d9df6  vmovaps xmm13, [rsp+0xC0]
0000786bc93d9dff  vmovaps xmm14, [rsp+0xD0]
0000786bc93d9e08  vmovaps xmm15, [rsp+0xE0]
0000786bc93d9e11  add rsp, 0xF0
0000786bc93d9e18  pop r11
0000786bc93d9e1a  pop r10
0000786bc93d9e1c  pop r9
0000786bc93d9e1e  pop r8
0000786bc93d9e20  pop rsi
0000786bc93d9e21  pop rdi
0000786bc93d9e22  pop rdx
0000786bc93d9e23  pop rcx
0000786bc93d9e24  pop rax
0000786bc93d9e25  add rsp, 0x08
0000786bc93d9e29  jmp 0x0000786BC93D6388
0000786bc93d9e2e  sub rsp, 0x08
0000786bc93d9e32  push rax
0000786bc93d9e33  push rcx
0000786bc93d9e34  push rdx
0000786bc93d9e35  push rdi
0000786bc93d9e36  push rsi
0000786bc93d9e37  push r8
0000786bc93d9e39  push r9
0000786bc93d9e3b  push r10
0000786bc93d9e3d  push r11
0000786bc93d9e3f  sub rsp, 0xF0
0000786bc93d9e46  vmovaps [rsp], xmm0
0000786bc93d9e4b  vmovaps [rsp+0x10], xmm1
0000786bc93d9e51  vmovaps [rsp+0x20], xmm2
0000786bc93d9e57  vmovaps [rsp+0x30], xmm3
0000786bc93d9e5d  vmovaps [rsp+0x40], xmm4
0000786bc93d9e63  vmovaps [rsp+0x50], xmm5
0000786bc93d9e69  vmovaps [rsp+0x60], xmm6
0000786bc93d9e6f  vmovaps [rsp+0x70], xmm7
0000786bc93d9e75  vmovaps [rsp+0x80], xmm9
0000786bc93d9e7e  vmovaps [rsp+0x90], xmm10
0000786bc93d9e87  vmovaps [rsp+0xA0], xmm11
0000786bc93d9e90  vmovaps [rsp+0xB0], xmm12
0000786bc93d9e99  vmovaps [rsp+0xC0], xmm13
0000786bc93d9ea2  vmovaps [rsp+0xD0], xmm14
0000786bc93d9eab  vmovaps [rsp+0xE0], xmm15
0000786bc93d9eb4  sub rsp, 0x30
0000786bc93d9eb8  movaps [rsp], xmm8
0000786bc93d9ebd  movaps [rsp+0x10], xmm1
0000786bc93d9ec2  movaps [rsp+0x20], xmm14
0000786bc93d9ec8  lea rdi, [rsp]
0000786bc93d9ecc  mov esi, 0x00
0000786bc93d9ed1  mov rax, 0x60810F6F7530
0000786bc93d9edb  call rax
0000786bc93d9edd  movaps xmm8, [rsp]
0000786bc93d9ee2  add rsp, 0x30
0000786bc93d9ee6  vmovaps xmm0, [rsp]
0000786bc93d9eeb  vmovaps xmm1, [rsp+0x10]
0000786bc93d9ef1  vmovaps xmm2, [rsp+0x20]
0000786bc93d9ef7  vmovaps xmm3, [rsp+0x30]
0000786bc93d9efd  vmovaps xmm4, [rsp+0x40]
0000786bc93d9f03  vmovaps xmm5, [rsp+0x50]
0000786bc93d9f09  vmovaps xmm6, [rsp+0x60]
0000786bc93d9f0f  vmovaps xmm7, [rsp+0x70]
0000786bc93d9f15  vmovaps xmm9, [rsp+0x80]
0000786bc93d9f1e  vmovaps xmm10, [rsp+0x90]
0000786bc93d9f27  vmovaps xmm11, [rsp+0xA0]
0000786bc93d9f30  vmovaps xmm12, [rsp+0xB0]
0000786bc93d9f39  vmovaps xmm13, [rsp+0xC0]
0000786bc93d9f42  vmovaps xmm14, [rsp+0xD0]
0000786bc93d9f4b  vmovaps xmm15, [rsp+0xE0]
0000786bc93d9f54  add rsp, 0xF0
0000786bc93d9f5b  pop r11
0000786bc93d9f5d  pop r10
0000786bc93d9f5f  pop r9
0000786bc93d9f61  pop r8
0000786bc93d9f63  pop rsi
0000786bc93d9f64  pop rdi
0000786bc93d9f65  pop rdx
0000786bc93d9f66  pop rcx
0000786bc93d9f67  pop rax
0000786bc93d9f68  add rsp, 0x08
0000786bc93d9f6c  jmp 0x0000786BC93D63AE
0000786bc93d9f71  sub rsp, 0x08
0000786bc93d9f75  push rax
0000786bc93d9f76  push rcx
0000786bc93d9f77  push rdx
0000786bc93d9f78  push rdi
0000786bc93d9f79  push rsi
0000786bc93d9f7a  push r8
0000786bc93d9f7c  push r9
0000786bc93d9f7e  push r10
0000786bc93d9f80  push r11
0000786bc93d9f82  sub rsp, 0xF0
0000786bc93d9f89  vmovaps [rsp], xmm0
0000786bc93d9f8e  vmovaps [rsp+0x10], xmm1
0000786bc93d9f94  vmovaps [rsp+0x20], xmm2
0000786bc93d9f9a  vmovaps [rsp+0x30], xmm3
0000786bc93d9fa0  vmovaps [rsp+0x40], xmm4
0000786bc93d9fa6  vmovaps [rsp+0x50], xmm5
0000786bc93d9fac  vmovaps [rsp+0x60], xmm7
0000786bc93d9fb2  vmovaps [rsp+0x70], xmm8
0000786bc93d9fb8  vmovaps [rsp+0x80], xmm9
0000786bc93d9fc1  vmovaps [rsp+0x90], xmm10
0000786bc93d9fca  vmovaps [rsp+0xA0], xmm11
0000786bc93d9fd3  vmovaps [rsp+0xB0], xmm12
0000786bc93d9fdc  vmovaps [rsp+0xC0], xmm13
0000786bc93d9fe5  vmovaps [rsp+0xD0], xmm14
0000786bc93d9fee  vmovaps [rsp+0xE0], xmm15
0000786bc93d9ff7  sub rsp, 0x30
0000786bc93d9ffb  movaps [rsp], xmm6
0000786bc93d9fff  movaps [rsp+0x10], xmm1
0000786bc93da004  movaps [rsp+0x20], xmm14
0000786bc93da00a  lea rdi, [rsp]
0000786bc93da00e  mov esi, 0x00
0000786bc93da013  mov rax, 0x60810F6F7530
0000786bc93da01d  call rax
0000786bc93da01f  movaps xmm6, [rsp]
0000786bc93da023  add rsp, 0x30
0000786bc93da027  vmovaps xmm0, [rsp]
0000786bc93da02c  vmovaps xmm1, [rsp+0x10]
0000786bc93da032  vmovaps xmm2, [rsp+0x20]
0000786bc93da038  vmovaps xmm3, [rsp+0x30]
0000786bc93da03e  vmovaps xmm4, [rsp+0x40]
0000786bc93da044  vmovaps xmm5, [rsp+0x50]
0000786bc93da04a  vmovaps xmm7, [rsp+0x60]
0000786bc93da050  vmovaps xmm8, [rsp+0x70]
0000786bc93da056  vmovaps xmm9, [rsp+0x80]
0000786bc93da05f  vmovaps xmm10, [rsp+0x90]
0000786bc93da068  vmovaps xmm11, [rsp+0xA0]
0000786bc93da071  vmovaps xmm12, [rsp+0xB0]
0000786bc93da07a  vmovaps xmm13, [rsp+0xC0]
0000786bc93da083  vmovaps xmm14, [rsp+0xD0]
0000786bc93da08c  vmovaps xmm15, [rsp+0xE0]
0000786bc93da095  add rsp, 0xF0
0000786bc93da09c  pop r11
0000786bc93da09e  pop r10
0000786bc93da0a0  pop r9
0000786bc93da0a2  pop r8
0000786bc93da0a4  pop rsi
0000786bc93da0a5  pop rdi
0000786bc93da0a6  pop rdx
0000786bc93da0a7  pop rcx
0000786bc93da0a8  pop rax
0000786bc93da0a9  add rsp, 0x08
0000786bc93da0ad  jmp 0x0000786BC93D63DA
0000786bc93da0b2  sub rsp, 0x08
0000786bc93da0b6  push rax
0000786bc93da0b7  push rcx
0000786bc93da0b8  push rdx
0000786bc93da0b9  push rdi
0000786bc93da0ba  push rsi
0000786bc93da0bb  push r8
0000786bc93da0bd  push r9
0000786bc93da0bf  push r10
0000786bc93da0c1  push r11
0000786bc93da0c3  sub rsp, 0xF0
0000786bc93da0ca  vmovaps [rsp], xmm0
0000786bc93da0cf  vmovaps [rsp+0x10], xmm1
0000786bc93da0d5  vmovaps [rsp+0x20], xmm2
0000786bc93da0db  vmovaps [rsp+0x30], xmm3
0000786bc93da0e1  vmovaps [rsp+0x40], xmm4
0000786bc93da0e7  vmovaps [rsp+0x50], xmm5
0000786bc93da0ed  vmovaps [rsp+0x60], xmm6
0000786bc93da0f3  vmovaps [rsp+0x70], xmm7
0000786bc93da0f9  vmovaps [rsp+0x80], xmm8
0000786bc93da102  vmovaps [rsp+0x90], xmm9
0000786bc93da10b  vmovaps [rsp+0xA0], xmm10
0000786bc93da114  vmovaps [rsp+0xB0], xmm11
0000786bc93da11d  vmovaps [rsp+0xC0], xmm12
0000786bc93da126  vmovaps [rsp+0xD0], xmm13
0000786bc93da12f  vmovaps [rsp+0xE0], xmm15
0000786bc93da138  sub rsp, 0x30
0000786bc93da13c  movaps [rsp], xmm14
0000786bc93da141  movaps [rsp+0x10], xmm12
0000786bc93da147  movaps [rsp+0x20], xmm1
0000786bc93da14c  lea rdi, [rsp]
0000786bc93da150  mov esi, 0x00
0000786bc93da155  mov rax, 0x60810F6F7530
0000786bc93da15f  call rax
0000786bc93da161  movaps xmm14, [rsp]
0000786bc93da166  add rsp, 0x30
0000786bc93da16a  vmovaps xmm0, [rsp]
0000786bc93da16f  vmovaps xmm1, [rsp+0x10]
0000786bc93da175  vmovaps xmm2, [rsp+0x20]
0000786bc93da17b  vmovaps xmm3, [rsp+0x30]
0000786bc93da181  vmovaps xmm4, [rsp+0x40]
0000786bc93da187  vmovaps xmm5, [rsp+0x50]
0000786bc93da18d  vmovaps xmm6, [rsp+0x60]
0000786bc93da193  vmovaps xmm7, [rsp+0x70]
0000786bc93da199  vmovaps xmm8, [rsp+0x80]
0000786bc93da1a2  vmovaps xmm9, [rsp+0x90]
0000786bc93da1ab  vmovaps xmm10, [rsp+0xA0]
0000786bc93da1b4  vmovaps xmm11, [rsp+0xB0]
0000786bc93da1bd  vmovaps xmm12, [rsp+0xC0]
0000786bc93da1c6  vmovaps xmm13, [rsp+0xD0]
0000786bc93da1cf  vmovaps xmm15, [rsp+0xE0]
0000786bc93da1d8  add rsp, 0xF0
0000786bc93da1df  pop r11
0000786bc93da1e1  pop r10
0000786bc93da1e3  pop r9
0000786bc93da1e5  pop r8
0000786bc93da1e7  pop rsi
0000786bc93da1e8  pop rdi
0000786bc93da1e9  pop rdx
0000786bc93da1ea  pop rcx
0000786bc93da1eb  pop rax
0000786bc93da1ec  add rsp, 0x08
0000786bc93da1f0  jmp 0x0000786BC93D6400
0000786bc93da1f5  sub rsp, 0x08
0000786bc93da1f9  push rax
0000786bc93da1fa  push rcx
0000786bc93da1fb  push rdx
0000786bc93da1fc  push rdi
0000786bc93da1fd  push rsi
0000786bc93da1fe  push r8
0000786bc93da200  push r9
0000786bc93da202  push r10
0000786bc93da204  push r11
0000786bc93da206  sub rsp, 0xF0
0000786bc93da20d  vmovaps [rsp], xmm0
0000786bc93da212  vmovaps [rsp+0x10], xmm2
0000786bc93da218  vmovaps [rsp+0x20], xmm3
0000786bc93da21e  vmovaps [rsp+0x30], xmm4
0000786bc93da224  vmovaps [rsp+0x40], xmm5
0000786bc93da22a  vmovaps [rsp+0x50], xmm6
0000786bc93da230  vmovaps [rsp+0x60], xmm7
0000786bc93da236  vmovaps [rsp+0x70], xmm8
0000786bc93da23c  vmovaps [rsp+0x80], xmm9
0000786bc93da245  vmovaps [rsp+0x90], xmm10
0000786bc93da24e  vmovaps [rsp+0xA0], xmm11
0000786bc93da257  vmovaps [rsp+0xB0], xmm12
0000786bc93da260  vmovaps [rsp+0xC0], xmm13
0000786bc93da269  vmovaps [rsp+0xD0], xmm14
0000786bc93da272  vmovaps [rsp+0xE0], xmm15
0000786bc93da27b  sub rsp, 0x30
0000786bc93da27f  movaps [rsp], xmm1
0000786bc93da283  movaps [rsp+0x10], xmm13
0000786bc93da289  movaps [rsp+0x20], xmm9
0000786bc93da28f  lea rdi, [rsp]
0000786bc93da293  mov esi, 0x00
0000786bc93da298  mov rax, 0x60810F6F7530
0000786bc93da2a2  call rax
0000786bc93da2a4  movaps xmm1, [rsp]
0000786bc93da2a8  add rsp, 0x30
0000786bc93da2ac  vmovaps xmm0, [rsp]
0000786bc93da2b1  vmovaps xmm2, [rsp+0x10]
0000786bc93da2b7  vmovaps xmm3, [rsp+0x20]
0000786bc93da2bd  vmovaps xmm4, [rsp+0x30]
0000786bc93da2c3  vmovaps xmm5, [rsp+0x40]
0000786bc93da2c9  vmovaps xmm6, [rsp+0x50]
0000786bc93da2cf  vmovaps xmm7, [rsp+0x60]
0000786bc93da2d5  vmovaps xmm8, [rsp+0x70]
0000786bc93da2db  vmovaps xmm9, [rsp+0x80]
0000786bc93da2e4  vmovaps xmm10, [rsp+0x90]
0000786bc93da2ed  vmovaps xmm11, [rsp+0xA0]
0000786bc93da2f6  vmovaps xmm12, [rsp+0xB0]
0000786bc93da2ff  vmovaps xmm13, [rsp+0xC0]
0000786bc93da308  vmovaps xmm14, [rsp+0xD0]
0000786bc93da311  vmovaps xmm15, [rsp+0xE0]
0000786bc93da31a  add rsp, 0xF0
0000786bc93da321  pop r11
0000786bc93da323  pop r10
0000786bc93da325  pop r9
0000786bc93da327  pop r8
0000786bc93da329  pop rsi
0000786bc93da32a  pop rdi
0000786bc93da32b  pop rdx
0000786bc93da32c  pop rcx
0000786bc93da32d  pop rax
0000786bc93da32e  add rsp, 0x08
0000786bc93da332  jmp 0x0000786BC93D641A
0000786bc93da337  sub rsp, 0x08
0000786bc93da33b  push rax
0000786bc93da33c  push rcx
0000786bc93da33d  push rdx
0000786bc93da33e  push rdi
0000786bc93da33f  push rsi
0000786bc93da340  push r8
0000786bc93da342  push r9
0000786bc93da344  push r10
0000786bc93da346  push r11
0000786bc93da348  sub rsp, 0xF0
0000786bc93da34f  vmovaps [rsp], xmm0
0000786bc93da354  vmovaps [rsp+0x10], xmm1
0000786bc93da35a  vmovaps [rsp+0x20], xmm2
0000786bc93da360  vmovaps [rsp+0x30], xmm3
0000786bc93da366  vmovaps [rsp+0x40], xmm4
0000786bc93da36c  vmovaps [rsp+0x50], xmm5
0000786bc93da372  vmovaps [rsp+0x60], xmm6
0000786bc93da378  vmovaps [rsp+0x70], xmm7
0000786bc93da37e  vmovaps [rsp+0x80], xmm8
0000786bc93da387  vmovaps [rsp+0x90], xmm9
0000786bc93da390  vmovaps [rsp+0xA0], xmm10
0000786bc93da399  vmovaps [rsp+0xB0], xmm11
0000786bc93da3a2  vmovaps [rsp+0xC0], xmm13
0000786bc93da3ab  vmovaps [rsp+0xD0], xmm14
0000786bc93da3b4  vmovaps [rsp+0xE0], xmm15
0000786bc93da3bd  sub rsp, 0x30
0000786bc93da3c1  movaps [rsp], xmm12
0000786bc93da3c6  movaps [rsp+0x10], xmm7
0000786bc93da3cb  movaps [rsp+0x20], xmm13
0000786bc93da3d1  lea rdi, [rsp]
0000786bc93da3d5  mov esi, 0x00
0000786bc93da3da  mov rax, 0x60810F6F7530
0000786bc93da3e4  call rax
0000786bc93da3e6  movaps xmm12, [rsp]
0000786bc93da3eb  add rsp, 0x30
0000786bc93da3ef  vmovaps xmm0, [rsp]
0000786bc93da3f4  vmovaps xmm1, [rsp+0x10]
0000786bc93da3fa  vmovaps xmm2, [rsp+0x20]
0000786bc93da400  vmovaps xmm3, [rsp+0x30]
0000786bc93da406  vmovaps xmm4, [rsp+0x40]
0000786bc93da40c  vmovaps xmm5, [rsp+0x50]
0000786bc93da412  vmovaps xmm6, [rsp+0x60]
0000786bc93da418  vmovaps xmm7, [rsp+0x70]
0000786bc93da41e  vmovaps xmm8, [rsp+0x80]
0000786bc93da427  vmovaps xmm9, [rsp+0x90]
0000786bc93da430  vmovaps xmm10, [rsp+0xA0]
0000786bc93da439  vmovaps xmm11, [rsp+0xB0]
0000786bc93da442  vmovaps xmm13, [rsp+0xC0]
0000786bc93da44b  vmovaps xmm14, [rsp+0xD0]
0000786bc93da454  vmovaps xmm15, [rsp+0xE0]
0000786bc93da45d  add rsp, 0xF0
0000786bc93da464  pop r11
0000786bc93da466  pop r10
0000786bc93da468  pop r9
0000786bc93da46a  pop r8
0000786bc93da46c  pop rsi
0000786bc93da46d  pop rdi
0000786bc93da46e  pop rdx
0000786bc93da46f  pop rcx
0000786bc93da470  pop rax
0000786bc93da471  add rsp, 0x08
0000786bc93da475  jmp 0x0000786BC93D6441
0000786bc93da47a  sub rsp, 0x08
0000786bc93da47e  push rax
0000786bc93da47f  push rcx
0000786bc93da480  push rdx
0000786bc93da481  push rdi
0000786bc93da482  push rsi
0000786bc93da483  push r8
0000786bc93da485  push r9
0000786bc93da487  push r10
0000786bc93da489  push r11
0000786bc93da48b  sub rsp, 0xF0
0000786bc93da492  vmovaps [rsp], xmm0
0000786bc93da497  vmovaps [rsp+0x10], xmm1
0000786bc93da49d  vmovaps [rsp+0x20], xmm2
0000786bc93da4a3  vmovaps [rsp+0x30], xmm3
0000786bc93da4a9  vmovaps [rsp+0x40], xmm4
0000786bc93da4af  vmovaps [rsp+0x50], xmm5
0000786bc93da4b5  vmovaps [rsp+0x60], xmm6
0000786bc93da4bb  vmovaps [rsp+0x70], xmm7
0000786bc93da4c1  vmovaps [rsp+0x80], xmm8
0000786bc93da4ca  vmovaps [rsp+0x90], xmm9
0000786bc93da4d3  vmovaps [rsp+0xA0], xmm10
0000786bc93da4dc  vmovaps [rsp+0xB0], xmm11
0000786bc93da4e5  vmovaps [rsp+0xC0], xmm12
0000786bc93da4ee  vmovaps [rsp+0xD0], xmm14
0000786bc93da4f7  vmovaps [rsp+0xE0], xmm15
0000786bc93da500  sub rsp, 0x30
0000786bc93da504  movaps [rsp], xmm13
0000786bc93da509  movaps [rsp+0x10], xmm15
0000786bc93da50f  movaps [rsp+0x20], xmm8
0000786bc93da515  lea rdi, [rsp]
0000786bc93da519  mov esi, 0x00
0000786bc93da51e  mov rax, 0x60810F6F7530
0000786bc93da528  call rax
0000786bc93da52a  movaps xmm13, [rsp]
0000786bc93da52f  add rsp, 0x30
0000786bc93da533  vmovaps xmm0, [rsp]
0000786bc93da538  vmovaps xmm1, [rsp+0x10]
0000786bc93da53e  vmovaps xmm2, [rsp+0x20]
0000786bc93da544  vmovaps xmm3, [rsp+0x30]
0000786bc93da54a  vmovaps xmm4, [rsp+0x40]
0000786bc93da550  vmovaps xmm5, [rsp+0x50]
0000786bc93da556  vmovaps xmm6, [rsp+0x60]
0000786bc93da55c  vmovaps xmm7, [rsp+0x70]
0000786bc93da562  vmovaps xmm8, [rsp+0x80]
0000786bc93da56b  vmovaps xmm9, [rsp+0x90]
0000786bc93da574  vmovaps xmm10, [rsp+0xA0]
0000786bc93da57d  vmovaps xmm11, [rsp+0xB0]
0000786bc93da586  vmovaps xmm12, [rsp+0xC0]
0000786bc93da58f  vmovaps xmm14, [rsp+0xD0]
0000786bc93da598  vmovaps xmm15, [rsp+0xE0]
0000786bc93da5a1  add rsp, 0xF0
0000786bc93da5a8  pop r11
0000786bc93da5aa  pop r10
0000786bc93da5ac  pop r9
0000786bc93da5ae  pop r8
0000786bc93da5b0  pop rsi
0000786bc93da5b1  pop rdi
0000786bc93da5b2  pop rdx
0000786bc93da5b3  pop rcx
0000786bc93da5b4  pop rax
0000786bc93da5b5  add rsp, 0x08
0000786bc93da5b9  jmp 0x0000786BC93D645C
0000786bc93da5be  sub rsp, 0x08
0000786bc93da5c2  push rax
0000786bc93da5c3  push rcx
0000786bc93da5c4  push rdx
0000786bc93da5c5  push rdi
0000786bc93da5c6  push rsi
0000786bc93da5c7  push r8
0000786bc93da5c9  push r9
0000786bc93da5cb  push r10
0000786bc93da5cd  push r11
0000786bc93da5cf  sub rsp, 0xF0
0000786bc93da5d6  vmovaps [rsp], xmm0
0000786bc93da5db  vmovaps [rsp+0x10], xmm1
0000786bc93da5e1  vmovaps [rsp+0x20], xmm2
0000786bc93da5e7  vmovaps [rsp+0x30], xmm3
0000786bc93da5ed  vmovaps [rsp+0x40], xmm4
0000786bc93da5f3  vmovaps [rsp+0x50], xmm5
0000786bc93da5f9  vmovaps [rsp+0x60], xmm6
0000786bc93da5ff  vmovaps [rsp+0x70], xmm7
0000786bc93da605  vmovaps [rsp+0x80], xmm9
0000786bc93da60e  vmovaps [rsp+0x90], xmm10
0000786bc93da617  vmovaps [rsp+0xA0], xmm11
0000786bc93da620  vmovaps [rsp+0xB0], xmm12
0000786bc93da629  vmovaps [rsp+0xC0], xmm13
0000786bc93da632  vmovaps [rsp+0xD0], xmm14
0000786bc93da63b  vmovaps [rsp+0xE0], xmm15
0000786bc93da644  sub rsp, 0x30
0000786bc93da648  movaps [rsp], xmm8
0000786bc93da64d  movaps [rsp+0x10], xmm15
0000786bc93da653  movaps [rsp+0x20], xmm9
0000786bc93da659  lea rdi, [rsp]
0000786bc93da65d  mov esi, 0x00
0000786bc93da662  mov rax, 0x60810F6F7530
0000786bc93da66c  call rax
0000786bc93da66e  movaps xmm8, [rsp]
0000786bc93da673  add rsp, 0x30
0000786bc93da677  vmovaps xmm0, [rsp]
0000786bc93da67c  vmovaps xmm1, [rsp+0x10]
0000786bc93da682  vmovaps xmm2, [rsp+0x20]
0000786bc93da688  vmovaps xmm3, [rsp+0x30]
0000786bc93da68e  vmovaps xmm4, [rsp+0x40]
0000786bc93da694  vmovaps xmm5, [rsp+0x50]
0000786bc93da69a  vmovaps xmm6, [rsp+0x60]
0000786bc93da6a0  vmovaps xmm7, [rsp+0x70]
0000786bc93da6a6  vmovaps xmm9, [rsp+0x80]
0000786bc93da6af  vmovaps xmm10, [rsp+0x90]
0000786bc93da6b8  vmovaps xmm11, [rsp+0xA0]
0000786bc93da6c1  vmovaps xmm12, [rsp+0xB0]
0000786bc93da6ca  vmovaps xmm13, [rsp+0xC0]
0000786bc93da6d3  vmovaps xmm14, [rsp+0xD0]
0000786bc93da6dc  vmovaps xmm15, [rsp+0xE0]
0000786bc93da6e5  add rsp, 0xF0
0000786bc93da6ec  pop r11
0000786bc93da6ee  pop r10
0000786bc93da6f0  pop r9
0000786bc93da6f2  pop r8
0000786bc93da6f4  pop rsi
0000786bc93da6f5  pop rdi
0000786bc93da6f6  pop rdx
0000786bc93da6f7  pop rcx
0000786bc93da6f8  pop rax
0000786bc93da6f9  add rsp, 0x08
0000786bc93da6fd  jmp 0x0000786BC93D648A
0000786bc93da702  sub rsp, 0x08
0000786bc93da706  push rax
0000786bc93da707  push rcx
0000786bc93da708  push rdx
0000786bc93da709  push rdi
0000786bc93da70a  push rsi
0000786bc93da70b  push r8
0000786bc93da70d  push r9
0000786bc93da70f  push r10
0000786bc93da711  push r11
0000786bc93da713  sub rsp, 0xF0
0000786bc93da71a  vmovaps [rsp], xmm0
0000786bc93da71f  vmovaps [rsp+0x10], xmm1
0000786bc93da725  vmovaps [rsp+0x20], xmm2
0000786bc93da72b  vmovaps [rsp+0x30], xmm3
0000786bc93da731  vmovaps [rsp+0x40], xmm4
0000786bc93da737  vmovaps [rsp+0x50], xmm5
0000786bc93da73d  vmovaps [rsp+0x60], xmm6
0000786bc93da743  vmovaps [rsp+0x70], xmm7
0000786bc93da749  vmovaps [rsp+0x80], xmm8
0000786bc93da752  vmovaps [rsp+0x90], xmm9
0000786bc93da75b  vmovaps [rsp+0xA0], xmm10
0000786bc93da764  vmovaps [rsp+0xB0], xmm11
0000786bc93da76d  vmovaps [rsp+0xC0], xmm12
0000786bc93da776  vmovaps [rsp+0xD0], xmm13
0000786bc93da77f  vmovaps [rsp+0xE0], xmm14
0000786bc93da788  sub rsp, 0x30
0000786bc93da78c  movaps [rsp], xmm15
0000786bc93da791  movaps [rsp+0x10], xmm11
0000786bc93da797  movaps [rsp+0x20], xmm6
0000786bc93da79c  lea rdi, [rsp]
0000786bc93da7a0  mov esi, 0x00
0000786bc93da7a5  mov rax, 0x60810F6F7530
0000786bc93da7af  call rax
0000786bc93da7b1  movaps xmm15, [rsp]
0000786bc93da7b6  add rsp, 0x30
0000786bc93da7ba  vmovaps xmm0, [rsp]
0000786bc93da7bf  vmovaps xmm1, [rsp+0x10]
0000786bc93da7c5  vmovaps xmm2, [rsp+0x20]
0000786bc93da7cb  vmovaps xmm3, [rsp+0x30]
0000786bc93da7d1  vmovaps xmm4, [rsp+0x40]
0000786bc93da7d7  vmovaps xmm5, [rsp+0x50]
0000786bc93da7dd  vmovaps xmm6, [rsp+0x60]
0000786bc93da7e3  vmovaps xmm7, [rsp+0x70]
0000786bc93da7e9  vmovaps xmm8, [rsp+0x80]
0000786bc93da7f2  vmovaps xmm9, [rsp+0x90]
0000786bc93da7fb  vmovaps xmm10, [rsp+0xA0]
0000786bc93da804  vmovaps xmm11, [rsp+0xB0]
0000786bc93da80d  vmovaps xmm12, [rsp+0xC0]
0000786bc93da816  vmovaps xmm13, [rsp+0xD0]
0000786bc93da81f  vmovaps xmm14, [rsp+0xE0]
0000786bc93da828  add rsp, 0xF0
0000786bc93da82f  pop r11
0000786bc93da831  pop r10
0000786bc93da833  pop r9
0000786bc93da835  pop r8
0000786bc93da837  pop rsi
0000786bc93da838  pop rdi
0000786bc93da839  pop rdx
0000786bc93da83a  pop rcx
0000786bc93da83b  pop rax
0000786bc93da83c  add rsp, 0x08
0000786bc93da840  jmp 0x0000786BC93D64A5
0000786bc93da845  sub rsp, 0x08
0000786bc93da849  push rax
0000786bc93da84a  push rcx
0000786bc93da84b  push rdx
0000786bc93da84c  push rdi
0000786bc93da84d  push rsi
0000786bc93da84e  push r8
0000786bc93da850  push r9
0000786bc93da852  push r10
0000786bc93da854  push r11
0000786bc93da856  sub rsp, 0xF0
0000786bc93da85d  vmovaps [rsp], xmm0
0000786bc93da862  vmovaps [rsp+0x10], xmm1
0000786bc93da868  vmovaps [rsp+0x20], xmm2
0000786bc93da86e  vmovaps [rsp+0x30], xmm3
0000786bc93da874  vmovaps [rsp+0x40], xmm4
0000786bc93da87a  vmovaps [rsp+0x50], xmm5
0000786bc93da880  vmovaps [rsp+0x60], xmm6
0000786bc93da886  vmovaps [rsp+0x70], xmm8
0000786bc93da88c  vmovaps [rsp+0x80], xmm9
0000786bc93da895  vmovaps [rsp+0x90], xmm10
0000786bc93da89e  vmovaps [rsp+0xA0], xmm11
0000786bc93da8a7  vmovaps [rsp+0xB0], xmm12
0000786bc93da8b0  vmovaps [rsp+0xC0], xmm13
0000786bc93da8b9  vmovaps [rsp+0xD0], xmm14
0000786bc93da8c2  vmovaps [rsp+0xE0], xmm15
0000786bc93da8cb  sub rsp, 0x30
0000786bc93da8cf  movaps [rsp], xmm7
0000786bc93da8d3  movaps [rsp+0x10], xmm11
0000786bc93da8d9  movaps [rsp+0x20], xmm9
0000786bc93da8df  lea rdi, [rsp]
0000786bc93da8e3  mov esi, 0x00
0000786bc93da8e8  mov rax, 0x60810F6F7530
0000786bc93da8f2  call rax
0000786bc93da8f4  movaps xmm7, [rsp]
0000786bc93da8f8  add rsp, 0x30
0000786bc93da8fc  vmovaps xmm0, [rsp]
0000786bc93da901  vmovaps xmm1, [rsp+0x10]
0000786bc93da907  vmovaps xmm2, [rsp+0x20]
0000786bc93da90d  vmovaps xmm3, [rsp+0x30]
0000786bc93da913  vmovaps xmm4, [rsp+0x40]
0000786bc93da919  vmovaps xmm5, [rsp+0x50]
0000786bc93da91f  vmovaps xmm6, [rsp+0x60]
0000786bc93da925  vmovaps xmm8, [rsp+0x70]
0000786bc93da92b  vmovaps xmm9, [rsp+0x80]
0000786bc93da934  vmovaps xmm10, [rsp+0x90]
0000786bc93da93d  vmovaps xmm11, [rsp+0xA0]
0000786bc93da946  vmovaps xmm12, [rsp+0xB0]
0000786bc93da94f  vmovaps xmm13, [rsp+0xC0]
0000786bc93da958  vmovaps xmm14, [rsp+0xD0]
0000786bc93da961  vmovaps xmm15, [rsp+0xE0]
0000786bc93da96a  add rsp, 0xF0
0000786bc93da971  pop r11
0000786bc93da973  pop r10
0000786bc93da975  pop r9
0000786bc93da977  pop r8
0000786bc93da979  pop rsi
0000786bc93da97a  pop rdi
0000786bc93da97b  pop rdx
0000786bc93da97c  pop rcx
0000786bc93da97d  pop rax
0000786bc93da97e  add rsp, 0x08
0000786bc93da982  jmp 0x0000786BC93D64D2
0000786bc93da987  sub rsp, 0x08
0000786bc93da98b  push rax
0000786bc93da98c  push rcx
0000786bc93da98d  push rdx
0000786bc93da98e  push rdi
0000786bc93da98f  push rsi
0000786bc93da990  push r8
0000786bc93da992  push r9
0000786bc93da994  push r10
0000786bc93da996  push r11
0000786bc93da998  sub rsp, 0xF0
0000786bc93da99f  vmovaps [rsp], xmm0
0000786bc93da9a4  vmovaps [rsp+0x10], xmm1
0000786bc93da9aa  vmovaps [rsp+0x20], xmm2
0000786bc93da9b0  vmovaps [rsp+0x30], xmm3
0000786bc93da9b6  vmovaps [rsp+0x40], xmm4
0000786bc93da9bc  vmovaps [rsp+0x50], xmm5
0000786bc93da9c2  vmovaps [rsp+0x60], xmm6
0000786bc93da9c8  vmovaps [rsp+0x70], xmm7
0000786bc93da9ce  vmovaps [rsp+0x80], xmm8
0000786bc93da9d7  vmovaps [rsp+0x90], xmm9
0000786bc93da9e0  vmovaps [rsp+0xA0], xmm10
0000786bc93da9e9  vmovaps [rsp+0xB0], xmm12
0000786bc93da9f2  vmovaps [rsp+0xC0], xmm13
0000786bc93da9fb  vmovaps [rsp+0xD0], xmm14
0000786bc93daa04  vmovaps [rsp+0xE0], xmm15
0000786bc93daa0d  sub rsp, 0x30
0000786bc93daa11  movaps [rsp], xmm11
0000786bc93daa16  movaps [rsp+0x10], xmm10
0000786bc93daa1c  movaps [rsp+0x20], xmm14
0000786bc93daa22  lea rdi, [rsp]
0000786bc93daa26  mov esi, 0x00
0000786bc93daa2b  mov rax, 0x60810F6F7530
0000786bc93daa35  call rax
0000786bc93daa37  movaps xmm11, [rsp]
0000786bc93daa3c  add rsp, 0x30
0000786bc93daa40  vmovaps xmm0, [rsp]
0000786bc93daa45  vmovaps xmm1, [rsp+0x10]
0000786bc93daa4b  vmovaps xmm2, [rsp+0x20]
0000786bc93daa51  vmovaps xmm3, [rsp+0x30]
0000786bc93daa57  vmovaps xmm4, [rsp+0x40]
0000786bc93daa5d  vmovaps xmm5, [rsp+0x50]
0000786bc93daa63  vmovaps xmm6, [rsp+0x60]
0000786bc93daa69  vmovaps xmm7, [rsp+0x70]
0000786bc93daa6f  vmovaps xmm8, [rsp+0x80]
0000786bc93daa78  vmovaps xmm9, [rsp+0x90]
0000786bc93daa81  vmovaps xmm10, [rsp+0xA0]
0000786bc93daa8a  vmovaps xmm12, [rsp+0xB0]
0000786bc93daa93  vmovaps xmm13, [rsp+0xC0]
0000786bc93daa9c  vmovaps xmm14, [rsp+0xD0]
0000786bc93daaa5  vmovaps xmm15, [rsp+0xE0]
0000786bc93daaae  add rsp, 0xF0
0000786bc93daab5  pop r11
0000786bc93daab7  pop r10
0000786bc93daab9  pop r9
0000786bc93daabb  pop r8
0000786bc93daabd  pop rsi
0000786bc93daabe  pop rdi
0000786bc93daabf  pop rdx
0000786bc93daac0  pop rcx
0000786bc93daac1  pop rax
0000786bc93daac2  add rsp, 0x08
0000786bc93daac6  jmp 0x0000786BC93D64ED
0000786bc93daacb  call 0x0000786BC92E45A0
0000786bc93daad0  jmp 0x0000786BC93D64F7
0000786bc93daad5  sub rsp, 0x08
0000786bc93daad9  push rax
0000786bc93daada  push rcx
0000786bc93daadb  push rdx
0000786bc93daadc  push rdi
0000786bc93daadd  push rsi
0000786bc93daade  push r8
0000786bc93daae0  push r9
0000786bc93daae2  push r10
0000786bc93daae4  push r11
0000786bc93daae6  sub rsp, 0xF0
0000786bc93daaed  vmovaps [rsp], xmm0
0000786bc93daaf2  vmovaps [rsp+0x10], xmm1
0000786bc93daaf8  vmovaps [rsp+0x20], xmm2
0000786bc93daafe  vmovaps [rsp+0x30], xmm3
0000786bc93dab04  vmovaps [rsp+0x40], xmm4
0000786bc93dab0a  vmovaps [rsp+0x50], xmm5
0000786bc93dab10  vmovaps [rsp+0x60], xmm6
0000786bc93dab16  vmovaps [rsp+0x70], xmm7
0000786bc93dab1c  vmovaps [rsp+0x80], xmm8
0000786bc93dab25  vmovaps [rsp+0x90], xmm9
0000786bc93dab2e  vmovaps [rsp+0xA0], xmm11
0000786bc93dab37  vmovaps [rsp+0xB0], xmm12
0000786bc93dab40  vmovaps [rsp+0xC0], xmm13
0000786bc93dab49  vmovaps [rsp+0xD0], xmm14
0000786bc93dab52  vmovaps [rsp+0xE0], xmm15
0000786bc93dab5b  sub rsp, 0x30
0000786bc93dab5f  movaps [rsp], xmm10
0000786bc93dab64  movaps [rsp+0x10], xmm1
0000786bc93dab69  movaps [rsp+0x20], xmm12
0000786bc93dab6f  lea rdi, [rsp]
0000786bc93dab73  mov esi, 0x00
0000786bc93dab78  mov rax, 0x60810F6F7530
0000786bc93dab82  call rax
0000786bc93dab84  movaps xmm10, [rsp]
0000786bc93dab89  add rsp, 0x30
0000786bc93dab8d  vmovaps xmm0, [rsp]
0000786bc93dab92  vmovaps xmm1, [rsp+0x10]
0000786bc93dab98  vmovaps xmm2, [rsp+0x20]
0000786bc93dab9e  vmovaps xmm3, [rsp+0x30]
0000786bc93daba4  vmovaps xmm4, [rsp+0x40]
0000786bc93dabaa  vmovaps xmm5, [rsp+0x50]
0000786bc93dabb0  vmovaps xmm6, [rsp+0x60]
0000786bc93dabb6  vmovaps xmm7, [rsp+0x70]
0000786bc93dabbc  vmovaps xmm8, [rsp+0x80]
0000786bc93dabc5  vmovaps xmm9, [rsp+0x90]
0000786bc93dabce  vmovaps xmm11, [rsp+0xA0]
0000786bc93dabd7  vmovaps xmm12, [rsp+0xB0]
0000786bc93dabe0  vmovaps xmm13, [rsp+0xC0]
0000786bc93dabe9  vmovaps xmm14, [rsp+0xD0]
0000786bc93dabf2  vmovaps xmm15, [rsp+0xE0]
0000786bc93dabfb  add rsp, 0xF0
0000786bc93dac02  pop r11
0000786bc93dac04  pop r10
0000786bc93dac06  pop r9
0000786bc93dac08  pop r8
0000786bc93dac0a  pop rsi
0000786bc93dac0b  pop rdi
0000786bc93dac0c  pop rdx
0000786bc93dac0d  pop rcx
0000786bc93dac0e  pop rax
0000786bc93dac0f  add rsp, 0x08
0000786bc93dac13  jmp 0x0000786BC93D651A
0000786bc93dac18  sub rsp, 0x08
0000786bc93dac1c  push rax
0000786bc93dac1d  push rcx
0000786bc93dac1e  push rdx
0000786bc93dac1f  push rdi
0000786bc93dac20  push rsi
0000786bc93dac21  push r8
0000786bc93dac23  push r9
0000786bc93dac25  push r10
0000786bc93dac27  push r11
0000786bc93dac29  sub rsp, 0xF0
0000786bc93dac30  vmovaps [rsp], xmm0
0000786bc93dac35  vmovaps [rsp+0x10], xmm1
0000786bc93dac3b  vmovaps [rsp+0x20], xmm2
0000786bc93dac41  vmovaps [rsp+0x30], xmm3
0000786bc93dac47  vmovaps [rsp+0x40], xmm4
0000786bc93dac4d  vmovaps [rsp+0x50], xmm5
0000786bc93dac53  vmovaps [rsp+0x60], xmm6
0000786bc93dac59  vmovaps [rsp+0x70], xmm7
0000786bc93dac5f  vmovaps [rsp+0x80], xmm8
0000786bc93dac68  vmovaps [rsp+0x90], xmm9
0000786bc93dac71  vmovaps [rsp+0xA0], xmm10
0000786bc93dac7a  vmovaps [rsp+0xB0], xmm11
0000786bc93dac83  vmovaps [rsp+0xC0], xmm13
0000786bc93dac8c  vmovaps [rsp+0xD0], xmm14
0000786bc93dac95  vmovaps [rsp+0xE0], xmm15
0000786bc93dac9e  sub rsp, 0x30
0000786bc93daca2  movaps [rsp], xmm12
0000786bc93daca7  movaps [rsp+0x10], xmm14
0000786bc93dacad  movaps [rsp+0x20], xmm1
0000786bc93dacb2  lea rdi, [rsp]
0000786bc93dacb6  mov esi, 0x00
0000786bc93dacbb  mov rax, 0x60810F6F7530
0000786bc93dacc5  call rax
0000786bc93dacc7  movaps xmm12, [rsp]
0000786bc93daccc  add rsp, 0x30
0000786bc93dacd0  vmovaps xmm0, [rsp]
0000786bc93dacd5  vmovaps xmm1, [rsp+0x10]
0000786bc93dacdb  vmovaps xmm2, [rsp+0x20]
0000786bc93dace1  vmovaps xmm3, [rsp+0x30]
0000786bc93dace7  vmovaps xmm4, [rsp+0x40]
0000786bc93daced  vmovaps xmm5, [rsp+0x50]
0000786bc93dacf3  vmovaps xmm6, [rsp+0x60]
0000786bc93dacf9  vmovaps xmm7, [rsp+0x70]
0000786bc93dacff  vmovaps xmm8, [rsp+0x80]
0000786bc93dad08  vmovaps xmm9, [rsp+0x90]
0000786bc93dad11  vmovaps xmm10, [rsp+0xA0]
0000786bc93dad1a  vmovaps xmm11, [rsp+0xB0]
0000786bc93dad23  vmovaps xmm13, [rsp+0xC0]
0000786bc93dad2c  vmovaps xmm14, [rsp+0xD0]
0000786bc93dad35  vmovaps xmm15, [rsp+0xE0]
0000786bc93dad3e  add rsp, 0xF0
0000786bc93dad45  pop r11
0000786bc93dad47  pop r10
0000786bc93dad49  pop r9
0000786bc93dad4b  pop r8
0000786bc93dad4d  pop rsi
0000786bc93dad4e  pop rdi
0000786bc93dad4f  pop rdx
0000786bc93dad50  pop rcx
0000786bc93dad51  pop rax
0000786bc93dad52  add rsp, 0x08
0000786bc93dad56  jmp 0x0000786BC93D6549
0000786bc93dad5b  sub rsp, 0x08
0000786bc93dad5f  push rax
0000786bc93dad60  push rcx
0000786bc93dad61  push rdx
0000786bc93dad62  push rdi
0000786bc93dad63  push rsi
0000786bc93dad64  push r8
0000786bc93dad66  push r9
0000786bc93dad68  push r10
0000786bc93dad6a  push r11
0000786bc93dad6c  sub rsp, 0xF0
0000786bc93dad73  vmovaps [rsp], xmm0
0000786bc93dad78  vmovaps [rsp+0x10], xmm1
0000786bc93dad7e  vmovaps [rsp+0x20], xmm2
0000786bc93dad84  vmovaps [rsp+0x30], xmm3
0000786bc93dad8a  vmovaps [rsp+0x40], xmm4
0000786bc93dad90  vmovaps [rsp+0x50], xmm5
0000786bc93dad96  vmovaps [rsp+0x60], xmm6
0000786bc93dad9c  vmovaps [rsp+0x70], xmm7
0000786bc93dada2  vmovaps [rsp+0x80], xmm8
0000786bc93dadab  vmovaps [rsp+0x90], xmm9
0000786bc93dadb4  vmovaps [rsp+0xA0], xmm10
0000786bc93dadbd  vmovaps [rsp+0xB0], xmm11
0000786bc93dadc6  vmovaps [rsp+0xC0], xmm12
0000786bc93dadcf  vmovaps [rsp+0xD0], xmm13
0000786bc93dadd8  vmovaps [rsp+0xE0], xmm15
0000786bc93dade1  sub rsp, 0x30
0000786bc93dade5  movaps [rsp], xmm14
0000786bc93dadea  movaps [rsp+0x10], xmm9
0000786bc93dadf0  movaps [rsp+0x20], xmm1
0000786bc93dadf5  lea rdi, [rsp]
0000786bc93dadf9  mov esi, 0x00
0000786bc93dadfe  mov rax, 0x60810F6F7530
0000786bc93dae08  call rax
0000786bc93dae0a  movaps xmm14, [rsp]
0000786bc93dae0f  add rsp, 0x30
0000786bc93dae13  vmovaps xmm0, [rsp]
0000786bc93dae18  vmovaps xmm1, [rsp+0x10]
0000786bc93dae1e  vmovaps xmm2, [rsp+0x20]
0000786bc93dae24  vmovaps xmm3, [rsp+0x30]
0000786bc93dae2a  vmovaps xmm4, [rsp+0x40]
0000786bc93dae30  vmovaps xmm5, [rsp+0x50]
0000786bc93dae36  vmovaps xmm6, [rsp+0x60]
0000786bc93dae3c  vmovaps xmm7, [rsp+0x70]
0000786bc93dae42  vmovaps xmm8, [rsp+0x80]
0000786bc93dae4b  vmovaps xmm9, [rsp+0x90]
0000786bc93dae54  vmovaps xmm10, [rsp+0xA0]
0000786bc93dae5d  vmovaps xmm11, [rsp+0xB0]
0000786bc93dae66  vmovaps xmm12, [rsp+0xC0]
0000786bc93dae6f  vmovaps xmm13, [rsp+0xD0]
0000786bc93dae78  vmovaps xmm15, [rsp+0xE0]
0000786bc93dae81  add rsp, 0xF0
0000786bc93dae88  pop r11
0000786bc93dae8a  pop r10
0000786bc93dae8c  pop r9
0000786bc93dae8e  pop r8
0000786bc93dae90  pop rsi
0000786bc93dae91  pop rdi
0000786bc93dae92  pop rdx
0000786bc93dae93  pop rcx
0000786bc93dae94  pop rax
0000786bc93dae95  add rsp, 0x08
0000786bc93dae99  jmp 0x0000786BC93D6578
0000786bc93dae9e  sub rsp, 0x08
0000786bc93daea2  push rax
0000786bc93daea3  push rcx
0000786bc93daea4  push rdx
0000786bc93daea5  push rdi
0000786bc93daea6  push rsi
0000786bc93daea7  push r8
0000786bc93daea9  push r9
0000786bc93daeab  push r10
0000786bc93daead  push r11
0000786bc93daeaf  sub rsp, 0xF0
0000786bc93daeb6  vmovaps [rsp], xmm0
0000786bc93daebb  vmovaps [rsp+0x10], xmm2
0000786bc93daec1  vmovaps [rsp+0x20], xmm3
0000786bc93daec7  vmovaps [rsp+0x30], xmm4
0000786bc93daecd  vmovaps [rsp+0x40], xmm5
0000786bc93daed3  vmovaps [rsp+0x50], xmm6
0000786bc93daed9  vmovaps [rsp+0x60], xmm7
0000786bc93daedf  vmovaps [rsp+0x70], xmm8
0000786bc93daee5  vmovaps [rsp+0x80], xmm9
0000786bc93daeee  vmovaps [rsp+0x90], xmm10
0000786bc93daef7  vmovaps [rsp+0xA0], xmm11
0000786bc93daf00  vmovaps [rsp+0xB0], xmm12
0000786bc93daf09  vmovaps [rsp+0xC0], xmm13
0000786bc93daf12  vmovaps [rsp+0xD0], xmm14
0000786bc93daf1b  vmovaps [rsp+0xE0], xmm15
0000786bc93daf24  sub rsp, 0x30
0000786bc93daf28  movaps [rsp], xmm1
0000786bc93daf2c  movaps [rsp+0x10], xmm13
0000786bc93daf32  movaps [rsp+0x20], xmm8
0000786bc93daf38  lea rdi, [rsp]
0000786bc93daf3c  mov esi, 0x00
0000786bc93daf41  mov rax, 0x60810F6F7530
0000786bc93daf4b  call rax
0000786bc93daf4d  movaps xmm1, [rsp]
0000786bc93daf51  add rsp, 0x30
0000786bc93daf55  vmovaps xmm0, [rsp]
0000786bc93daf5a  vmovaps xmm2, [rsp+0x10]
0000786bc93daf60  vmovaps xmm3, [rsp+0x20]
0000786bc93daf66  vmovaps xmm4, [rsp+0x30]
0000786bc93daf6c  vmovaps xmm5, [rsp+0x40]
0000786bc93daf72  vmovaps xmm6, [rsp+0x50]
0000786bc93daf78  vmovaps xmm7, [rsp+0x60]
0000786bc93daf7e  vmovaps xmm8, [rsp+0x70]
0000786bc93daf84  vmovaps xmm9, [rsp+0x80]
0000786bc93daf8d  vmovaps xmm10, [rsp+0x90]
0000786bc93daf96  vmovaps xmm11, [rsp+0xA0]
0000786bc93daf9f  vmovaps xmm12, [rsp+0xB0]
0000786bc93dafa8  vmovaps xmm13, [rsp+0xC0]
0000786bc93dafb1  vmovaps xmm14, [rsp+0xD0]
0000786bc93dafba  vmovaps xmm15, [rsp+0xE0]
0000786bc93dafc3  add rsp, 0xF0
0000786bc93dafca  pop r11
0000786bc93dafcc  pop r10
0000786bc93dafce  pop r9
0000786bc93dafd0  pop r8
0000786bc93dafd2  pop rsi
0000786bc93dafd3  pop rdi
0000786bc93dafd4  pop rdx
0000786bc93dafd5  pop rcx
0000786bc93dafd6  pop rax
0000786bc93dafd7  add rsp, 0x08
0000786bc93dafdb  jmp 0x0000786BC93D659A
0000786bc93dafe0  call 0x0000786BC920C260
0000786bc93dafe5  jmp 0x0000786BC93D65A8
0000786bc93dafea  call 0x0000786BC92DE950
0000786bc93dafef  jmp 0x0000786BC93D65B2
0000786bc93daff4  sub rsp, 0x08
0000786bc93daff8  push rax
0000786bc93daff9  push rcx
0000786bc93daffa  push rdx
0000786bc93daffb  push rdi
0000786bc93daffc  push rsi
0000786bc93daffd  push r8
0000786bc93dafff  push r9
0000786bc93db001  push r10
0000786bc93db003  push r11
0000786bc93db005  sub rsp, 0xF0
0000786bc93db00c  vmovaps [rsp], xmm0
0000786bc93db011  vmovaps [rsp+0x10], xmm1
0000786bc93db017  vmovaps [rsp+0x20], xmm2
0000786bc93db01d  vmovaps [rsp+0x30], xmm3
0000786bc93db023  vmovaps [rsp+0x40], xmm4
0000786bc93db029  vmovaps [rsp+0x50], xmm5
0000786bc93db02f  vmovaps [rsp+0x60], xmm6
0000786bc93db035  vmovaps [rsp+0x70], xmm7
0000786bc93db03b  vmovaps [rsp+0x80], xmm9
0000786bc93db044  vmovaps [rsp+0x90], xmm10
0000786bc93db04d  vmovaps [rsp+0xA0], xmm11
0000786bc93db056  vmovaps [rsp+0xB0], xmm12
0000786bc93db05f  vmovaps [rsp+0xC0], xmm13
0000786bc93db068  vmovaps [rsp+0xD0], xmm14
0000786bc93db071  vmovaps [rsp+0xE0], xmm15
0000786bc93db07a  sub rsp, 0x30
0000786bc93db07e  movaps [rsp], xmm8
0000786bc93db083  movaps [rsp+0x10], xmm15
0000786bc93db089  movaps [rsp+0x20], xmm7
0000786bc93db08e  lea rdi, [rsp]
0000786bc93db092  mov esi, 0x00
0000786bc93db097  mov rax, 0x60810F6F7530
0000786bc93db0a1  call rax
0000786bc93db0a3  movaps xmm8, [rsp]
0000786bc93db0a8  add rsp, 0x30
0000786bc93db0ac  vmovaps xmm0, [rsp]
0000786bc93db0b1  vmovaps xmm1, [rsp+0x10]
0000786bc93db0b7  vmovaps xmm2, [rsp+0x20]
0000786bc93db0bd  vmovaps xmm3, [rsp+0x30]
0000786bc93db0c3  vmovaps xmm4, [rsp+0x40]
0000786bc93db0c9  vmovaps xmm5, [rsp+0x50]
0000786bc93db0cf  vmovaps xmm6, [rsp+0x60]
0000786bc93db0d5  vmovaps xmm7, [rsp+0x70]
0000786bc93db0db  vmovaps xmm9, [rsp+0x80]
0000786bc93db0e4  vmovaps xmm10, [rsp+0x90]
0000786bc93db0ed  vmovaps xmm11, [rsp+0xA0]
0000786bc93db0f6  vmovaps xmm12, [rsp+0xB0]
0000786bc93db0ff  vmovaps xmm13, [rsp+0xC0]
0000786bc93db108  vmovaps xmm14, [rsp+0xD0]
0000786bc93db111  vmovaps xmm15, [rsp+0xE0]
0000786bc93db11a  add rsp, 0xF0
0000786bc93db121  pop r11
0000786bc93db123  pop r10
0000786bc93db125  pop r9
0000786bc93db127  pop r8
0000786bc93db129  pop rsi
0000786bc93db12a  pop rdi
0000786bc93db12b  pop rdx
0000786bc93db12c  pop rcx
0000786bc93db12d  pop rax
0000786bc93db12e  add rsp, 0x08
0000786bc93db132  jmp 0x0000786BC93D65D4
0000786bc93db137  sub rsp, 0x08
0000786bc93db13b  push rax
0000786bc93db13c  push rcx
0000786bc93db13d  push rdx
0000786bc93db13e  push rdi
0000786bc93db13f  push rsi
0000786bc93db140  push r8
0000786bc93db142  push r9
0000786bc93db144  push r10
0000786bc93db146  push r11
0000786bc93db148  sub rsp, 0xF0
0000786bc93db14f  vmovaps [rsp], xmm0
0000786bc93db154  vmovaps [rsp+0x10], xmm1
0000786bc93db15a  vmovaps [rsp+0x20], xmm2
0000786bc93db160  vmovaps [rsp+0x30], xmm3
0000786bc93db166  vmovaps [rsp+0x40], xmm4
0000786bc93db16c  vmovaps [rsp+0x50], xmm5
0000786bc93db172  vmovaps [rsp+0x60], xmm6
0000786bc93db178  vmovaps [rsp+0x70], xmm8
0000786bc93db17e  vmovaps [rsp+0x80], xmm9
0000786bc93db187  vmovaps [rsp+0x90], xmm10
0000786bc93db190  vmovaps [rsp+0xA0], xmm11
0000786bc93db199  vmovaps [rsp+0xB0], xmm12
0000786bc93db1a2  vmovaps [rsp+0xC0], xmm13
0000786bc93db1ab  vmovaps [rsp+0xD0], xmm14
0000786bc93db1b4  vmovaps [rsp+0xE0], xmm15
0000786bc93db1bd  sub rsp, 0x30
0000786bc93db1c1  movaps [rsp], xmm7
0000786bc93db1c5  movaps [rsp+0x10], xmm9
0000786bc93db1cb  movaps [rsp+0x20], xmm15
0000786bc93db1d1  lea rdi, [rsp]
0000786bc93db1d5  mov esi, 0x00
0000786bc93db1da  mov rax, 0x60810F6F7530
0000786bc93db1e4  call rax
0000786bc93db1e6  movaps xmm7, [rsp]
0000786bc93db1ea  add rsp, 0x30
0000786bc93db1ee  vmovaps xmm0, [rsp]
0000786bc93db1f3  vmovaps xmm1, [rsp+0x10]
0000786bc93db1f9  vmovaps xmm2, [rsp+0x20]
0000786bc93db1ff  vmovaps xmm3, [rsp+0x30]
0000786bc93db205  vmovaps xmm4, [rsp+0x40]
0000786bc93db20b  vmovaps xmm5, [rsp+0x50]
0000786bc93db211  vmovaps xmm6, [rsp+0x60]
0000786bc93db217  vmovaps xmm8, [rsp+0x70]
0000786bc93db21d  vmovaps xmm9, [rsp+0x80]
0000786bc93db226  vmovaps xmm10, [rsp+0x90]
0000786bc93db22f  vmovaps xmm11, [rsp+0xA0]
0000786bc93db238  vmovaps xmm12, [rsp+0xB0]
0000786bc93db241  vmovaps xmm13, [rsp+0xC0]
0000786bc93db24a  vmovaps xmm14, [rsp+0xD0]
0000786bc93db253  vmovaps xmm15, [rsp+0xE0]
0000786bc93db25c  add rsp, 0xF0
0000786bc93db263  pop r11
0000786bc93db265  pop r10
0000786bc93db267  pop r9
0000786bc93db269  pop r8
0000786bc93db26b  pop rsi
0000786bc93db26c  pop rdi
0000786bc93db26d  pop rdx
0000786bc93db26e  pop rcx
0000786bc93db26f  pop rax
0000786bc93db270  add rsp, 0x08
0000786bc93db274  jmp 0x0000786BC93D6601
0000786bc93db279  sub rsp, 0x08
0000786bc93db27d  push rax
0000786bc93db27e  push rcx
0000786bc93db27f  push rdx
0000786bc93db280  push rdi
0000786bc93db281  push rsi
0000786bc93db282  push r8
0000786bc93db284  push r9
0000786bc93db286  push r10
0000786bc93db288  push r11
0000786bc93db28a  sub rsp, 0xF0
0000786bc93db291  vmovaps [rsp], xmm0
0000786bc93db296  vmovaps [rsp+0x10], xmm1
0000786bc93db29c  vmovaps [rsp+0x20], xmm2
0000786bc93db2a2  vmovaps [rsp+0x30], xmm3
0000786bc93db2a8  vmovaps [rsp+0x40], xmm4
0000786bc93db2ae  vmovaps [rsp+0x50], xmm5
0000786bc93db2b4  vmovaps [rsp+0x60], xmm6
0000786bc93db2ba  vmovaps [rsp+0x70], xmm7
0000786bc93db2c0  vmovaps [rsp+0x80], xmm8
0000786bc93db2c9  vmovaps [rsp+0x90], xmm10
0000786bc93db2d2  vmovaps [rsp+0xA0], xmm11
0000786bc93db2db  vmovaps [rsp+0xB0], xmm12
0000786bc93db2e4  vmovaps [rsp+0xC0], xmm13
0000786bc93db2ed  vmovaps [rsp+0xD0], xmm14
0000786bc93db2f6  vmovaps [rsp+0xE0], xmm15
0000786bc93db2ff  sub rsp, 0x30
0000786bc93db303  movaps [rsp], xmm9
0000786bc93db308  movaps [rsp+0x10], xmm13
0000786bc93db30e  movaps [rsp+0x20], xmm15
0000786bc93db314  lea rdi, [rsp]
0000786bc93db318  mov esi, 0x00
0000786bc93db31d  mov rax, 0x60810F6F7530
0000786bc93db327  call rax
0000786bc93db329  movaps xmm9, [rsp]
0000786bc93db32e  add rsp, 0x30
0000786bc93db332  vmovaps xmm0, [rsp]
0000786bc93db337  vmovaps xmm1, [rsp+0x10]
0000786bc93db33d  vmovaps xmm2, [rsp+0x20]
0000786bc93db343  vmovaps xmm3, [rsp+0x30]
0000786bc93db349  vmovaps xmm4, [rsp+0x40]
0000786bc93db34f  vmovaps xmm5, [rsp+0x50]
0000786bc93db355  vmovaps xmm6, [rsp+0x60]
0000786bc93db35b  vmovaps xmm7, [rsp+0x70]
0000786bc93db361  vmovaps xmm8, [rsp+0x80]
0000786bc93db36a  vmovaps xmm10, [rsp+0x90]
0000786bc93db373  vmovaps xmm11, [rsp+0xA0]
0000786bc93db37c  vmovaps xmm12, [rsp+0xB0]
0000786bc93db385  vmovaps xmm13, [rsp+0xC0]
0000786bc93db38e  vmovaps xmm14, [rsp+0xD0]
0000786bc93db397  vmovaps xmm15, [rsp+0xE0]
0000786bc93db3a0  add rsp, 0xF0
0000786bc93db3a7  pop r11
0000786bc93db3a9  pop r10
0000786bc93db3ab  pop r9
0000786bc93db3ad  pop r8
0000786bc93db3af  pop rsi
0000786bc93db3b0  pop rdi
0000786bc93db3b1  pop rdx
0000786bc93db3b2  pop rcx
0000786bc93db3b3  pop rax
0000786bc93db3b4  add rsp, 0x08
0000786bc93db3b8  jmp 0x0000786BC93D662F
0000786bc93db3bd  sub rsp, 0x08
0000786bc93db3c1  push rax
0000786bc93db3c2  push rcx
0000786bc93db3c3  push rdx
0000786bc93db3c4  push rdi
0000786bc93db3c5  push rsi
0000786bc93db3c6  push r8
0000786bc93db3c8  push r9
0000786bc93db3ca  push r10
0000786bc93db3cc  push r11
0000786bc93db3ce  sub rsp, 0xF0
0000786bc93db3d5  vmovaps [rsp], xmm0
0000786bc93db3da  vmovaps [rsp+0x10], xmm1
0000786bc93db3e0  vmovaps [rsp+0x20], xmm2
0000786bc93db3e6  vmovaps [rsp+0x30], xmm3
0000786bc93db3ec  vmovaps [rsp+0x40], xmm4
0000786bc93db3f2  vmovaps [rsp+0x50], xmm5
0000786bc93db3f8  vmovaps [rsp+0x60], xmm6
0000786bc93db3fe  vmovaps [rsp+0x70], xmm7
0000786bc93db404  vmovaps [rsp+0x80], xmm8
0000786bc93db40d  vmovaps [rsp+0x90], xmm9
0000786bc93db416  vmovaps [rsp+0xA0], xmm10
0000786bc93db41f  vmovaps [rsp+0xB0], xmm11
0000786bc93db428  vmovaps [rsp+0xC0], xmm12
0000786bc93db431  vmovaps [rsp+0xD0], xmm13
0000786bc93db43a  vmovaps [rsp+0xE0], xmm14
0000786bc93db443  sub rsp, 0x30
0000786bc93db447  movaps [rsp], xmm15
0000786bc93db44c  movaps [rsp+0x10], xmm11
0000786bc93db452  movaps [rsp+0x20], xmm12
0000786bc93db458  lea rdi, [rsp]
0000786bc93db45c  mov esi, 0x00
0000786bc93db461  mov rax, 0x60810F6F7530
0000786bc93db46b  call rax
0000786bc93db46d  movaps xmm15, [rsp]
0000786bc93db472  add rsp, 0x30
0000786bc93db476  vmovaps xmm0, [rsp]
0000786bc93db47b  vmovaps xmm1, [rsp+0x10]
0000786bc93db481  vmovaps xmm2, [rsp+0x20]
0000786bc93db487  vmovaps xmm3, [rsp+0x30]
0000786bc93db48d  vmovaps xmm4, [rsp+0x40]
0000786bc93db493  vmovaps xmm5, [rsp+0x50]
0000786bc93db499  vmovaps xmm6, [rsp+0x60]
0000786bc93db49f  vmovaps xmm7, [rsp+0x70]
0000786bc93db4a5  vmovaps xmm8, [rsp+0x80]
0000786bc93db4ae  vmovaps xmm9, [rsp+0x90]
0000786bc93db4b7  vmovaps xmm10, [rsp+0xA0]
0000786bc93db4c0  vmovaps xmm11, [rsp+0xB0]
0000786bc93db4c9  vmovaps xmm12, [rsp+0xC0]
0000786bc93db4d2  vmovaps xmm13, [rsp+0xD0]
0000786bc93db4db  vmovaps xmm14, [rsp+0xE0]
0000786bc93db4e4  add rsp, 0xF0
0000786bc93db4eb  pop r11
0000786bc93db4ed  pop r10
0000786bc93db4ef  pop r9
0000786bc93db4f1  pop r8
0000786bc93db4f3  pop rsi
0000786bc93db4f4  pop rdi
0000786bc93db4f5  pop rdx
0000786bc93db4f6  pop rcx
0000786bc93db4f7  pop rax
0000786bc93db4f8  add rsp, 0x08
0000786bc93db4fc  jmp 0x0000786BC93D664A
0000786bc93db501  sub rsp, 0x08
0000786bc93db505  push rax
0000786bc93db506  push rcx
0000786bc93db507  push rdx
0000786bc93db508  push rdi
0000786bc93db509  push rsi
0000786bc93db50a  push r8
0000786bc93db50c  push r9
0000786bc93db50e  push r10
0000786bc93db510  push r11
0000786bc93db512  sub rsp, 0xF0
0000786bc93db519  vmovaps [rsp], xmm0
0000786bc93db51e  vmovaps [rsp+0x10], xmm1
0000786bc93db524  vmovaps [rsp+0x20], xmm2
0000786bc93db52a  vmovaps [rsp+0x30], xmm3
0000786bc93db530  vmovaps [rsp+0x40], xmm4
0000786bc93db536  vmovaps [rsp+0x50], xmm5
0000786bc93db53c  vmovaps [rsp+0x60], xmm6
0000786bc93db542  vmovaps [rsp+0x70], xmm7
0000786bc93db548  vmovaps [rsp+0x80], xmm8
0000786bc93db551  vmovaps [rsp+0x90], xmm9
0000786bc93db55a  vmovaps [rsp+0xA0], xmm10
0000786bc93db563  vmovaps [rsp+0xB0], xmm11
0000786bc93db56c  vmovaps [rsp+0xC0], xmm12
0000786bc93db575  vmovaps [rsp+0xD0], xmm14
0000786bc93db57e  vmovaps [rsp+0xE0], xmm15
0000786bc93db587  sub rsp, 0x30
0000786bc93db58b  movaps [rsp], xmm13
0000786bc93db590  movaps [rsp+0x10], xmm10
0000786bc93db596  movaps [rsp+0x20], xmm14
0000786bc93db59c  lea rdi, [rsp]
0000786bc93db5a0  mov esi, 0x00
0000786bc93db5a5  mov rax, 0x60810F6F7530
0000786bc93db5af  call rax
0000786bc93db5b1  movaps xmm13, [rsp]
0000786bc93db5b6  add rsp, 0x30
0000786bc93db5ba  vmovaps xmm0, [rsp]
0000786bc93db5bf  vmovaps xmm1, [rsp+0x10]
0000786bc93db5c5  vmovaps xmm2, [rsp+0x20]
0000786bc93db5cb  vmovaps xmm3, [rsp+0x30]
0000786bc93db5d1  vmovaps xmm4, [rsp+0x40]
0000786bc93db5d7  vmovaps xmm5, [rsp+0x50]
0000786bc93db5dd  vmovaps xmm6, [rsp+0x60]
0000786bc93db5e3  vmovaps xmm7, [rsp+0x70]
0000786bc93db5e9  vmovaps xmm8, [rsp+0x80]
0000786bc93db5f2  vmovaps xmm9, [rsp+0x90]
0000786bc93db5fb  vmovaps xmm10, [rsp+0xA0]
0000786bc93db604  vmovaps xmm11, [rsp+0xB0]
0000786bc93db60d  vmovaps xmm12, [rsp+0xC0]
0000786bc93db616  vmovaps xmm14, [rsp+0xD0]
0000786bc93db61f  vmovaps xmm15, [rsp+0xE0]
0000786bc93db628  add rsp, 0xF0
0000786bc93db62f  pop r11
0000786bc93db631  pop r10
0000786bc93db633  pop r9
0000786bc93db635  pop r8
0000786bc93db637  pop rsi
0000786bc93db638  pop rdi
0000786bc93db639  pop rdx
0000786bc93db63a  pop rcx
0000786bc93db63b  pop rax
0000786bc93db63c  add rsp, 0x08
0000786bc93db640  jmp 0x0000786BC93D666D
0000786bc93db645  sub rsp, 0x08
0000786bc93db649  push rax
0000786bc93db64a  push rcx
0000786bc93db64b  push rdx
0000786bc93db64c  push rdi
0000786bc93db64d  push rsi
0000786bc93db64e  push r8
0000786bc93db650  push r9
0000786bc93db652  push r10
0000786bc93db654  push r11
0000786bc93db656  sub rsp, 0xF0
0000786bc93db65d  vmovaps [rsp], xmm0
0000786bc93db662  vmovaps [rsp+0x10], xmm1
0000786bc93db668  vmovaps [rsp+0x20], xmm2
0000786bc93db66e  vmovaps [rsp+0x30], xmm3
0000786bc93db674  vmovaps [rsp+0x40], xmm4
0000786bc93db67a  vmovaps [rsp+0x50], xmm5
0000786bc93db680  vmovaps [rsp+0x60], xmm6
0000786bc93db686  vmovaps [rsp+0x70], xmm7
0000786bc93db68c  vmovaps [rsp+0x80], xmm8
0000786bc93db695  vmovaps [rsp+0x90], xmm9
0000786bc93db69e  vmovaps [rsp+0xA0], xmm10
0000786bc93db6a7  vmovaps [rsp+0xB0], xmm11
0000786bc93db6b0  vmovaps [rsp+0xC0], xmm12
0000786bc93db6b9  vmovaps [rsp+0xD0], xmm13
0000786bc93db6c2  vmovaps [rsp+0xE0], xmm15
0000786bc93db6cb  sub rsp, 0x30
0000786bc93db6cf  movaps [rsp], xmm14
0000786bc93db6d4  movaps [rsp+0x10], xmm1
0000786bc93db6d9  movaps [rsp+0x20], xmm7
0000786bc93db6de  lea rdi, [rsp]
0000786bc93db6e2  mov esi, 0x00
0000786bc93db6e7  mov rax, 0x60810F6F7530
0000786bc93db6f1  call rax
0000786bc93db6f3  movaps xmm14, [rsp]
0000786bc93db6f8  add rsp, 0x30
0000786bc93db6fc  vmovaps xmm0, [rsp]
0000786bc93db701  vmovaps xmm1, [rsp+0x10]
0000786bc93db707  vmovaps xmm2, [rsp+0x20]
0000786bc93db70d  vmovaps xmm3, [rsp+0x30]
0000786bc93db713  vmovaps xmm4, [rsp+0x40]
0000786bc93db719  vmovaps xmm5, [rsp+0x50]
0000786bc93db71f  vmovaps xmm6, [rsp+0x60]
0000786bc93db725  vmovaps xmm7, [rsp+0x70]
0000786bc93db72b  vmovaps xmm8, [rsp+0x80]
0000786bc93db734  vmovaps xmm9, [rsp+0x90]
0000786bc93db73d  vmovaps xmm10, [rsp+0xA0]
0000786bc93db746  vmovaps xmm11, [rsp+0xB0]
0000786bc93db74f  vmovaps xmm12, [rsp+0xC0]
0000786bc93db758  vmovaps xmm13, [rsp+0xD0]
0000786bc93db761  vmovaps xmm15, [rsp+0xE0]
0000786bc93db76a  add rsp, 0xF0
0000786bc93db771  pop r11
0000786bc93db773  pop r10
0000786bc93db775  pop r9
0000786bc93db777  pop r8
0000786bc93db779  pop rsi
0000786bc93db77a  pop rdi
0000786bc93db77b  pop rdx
0000786bc93db77c  pop rcx
0000786bc93db77d  pop rax
0000786bc93db77e  add rsp, 0x08
0000786bc93db782  jmp 0x0000786BC93D6690
0000786bc93db787  sub rsp, 0x08
0000786bc93db78b  push rax
0000786bc93db78c  push rcx
0000786bc93db78d  push rdx
0000786bc93db78e  push rdi
0000786bc93db78f  push rsi
0000786bc93db790  push r8
0000786bc93db792  push r9
0000786bc93db794  push r10
0000786bc93db796  push r11
0000786bc93db798  sub rsp, 0xF0
0000786bc93db79f  vmovaps [rsp], xmm0
0000786bc93db7a4  vmovaps [rsp+0x10], xmm2
0000786bc93db7aa  vmovaps [rsp+0x20], xmm3
0000786bc93db7b0  vmovaps [rsp+0x30], xmm4
0000786bc93db7b6  vmovaps [rsp+0x40], xmm5
0000786bc93db7bc  vmovaps [rsp+0x50], xmm6
0000786bc93db7c2  vmovaps [rsp+0x60], xmm7
0000786bc93db7c8  vmovaps [rsp+0x70], xmm8
0000786bc93db7ce  vmovaps [rsp+0x80], xmm9
0000786bc93db7d7  vmovaps [rsp+0x90], xmm10
0000786bc93db7e0  vmovaps [rsp+0xA0], xmm11
0000786bc93db7e9  vmovaps [rsp+0xB0], xmm12
0000786bc93db7f2  vmovaps [rsp+0xC0], xmm13
0000786bc93db7fb  vmovaps [rsp+0xD0], xmm14
0000786bc93db804  vmovaps [rsp+0xE0], xmm15
0000786bc93db80d  sub rsp, 0x30
0000786bc93db811  movaps [rsp], xmm1
0000786bc93db815  movaps [rsp+0x10], xmm8
0000786bc93db81b  movaps [rsp+0x20], xmm9
0000786bc93db821  lea rdi, [rsp]
0000786bc93db825  mov esi, 0x00
0000786bc93db82a  mov rax, 0x60810F6F7530
0000786bc93db834  call rax
0000786bc93db836  movaps xmm1, [rsp]
0000786bc93db83a  add rsp, 0x30
0000786bc93db83e  vmovaps xmm0, [rsp]
0000786bc93db843  vmovaps xmm2, [rsp+0x10]
0000786bc93db849  vmovaps xmm3, [rsp+0x20]
0000786bc93db84f  vmovaps xmm4, [rsp+0x30]
0000786bc93db855  vmovaps xmm5, [rsp+0x40]
0000786bc93db85b  vmovaps xmm6, [rsp+0x50]
0000786bc93db861  vmovaps xmm7, [rsp+0x60]
0000786bc93db867  vmovaps xmm8, [rsp+0x70]
0000786bc93db86d  vmovaps xmm9, [rsp+0x80]
0000786bc93db876  vmovaps xmm10, [rsp+0x90]
0000786bc93db87f  vmovaps xmm11, [rsp+0xA0]
0000786bc93db888  vmovaps xmm12, [rsp+0xB0]
0000786bc93db891  vmovaps xmm13, [rsp+0xC0]
0000786bc93db89a  vmovaps xmm14, [rsp+0xD0]
0000786bc93db8a3  vmovaps xmm15, [rsp+0xE0]
0000786bc93db8ac  add rsp, 0xF0
0000786bc93db8b3  pop r11
0000786bc93db8b5  pop r10
0000786bc93db8b7  pop r9
0000786bc93db8b9  pop r8
0000786bc93db8bb  pop rsi
0000786bc93db8bc  pop rdi
0000786bc93db8bd  pop rdx
0000786bc93db8be  pop rcx
0000786bc93db8bf  pop rax
0000786bc93db8c0  add rsp, 0x08
0000786bc93db8c4  jmp 0x0000786BC93D66B2
0000786bc93db8c9  call 0x0000786BC92B3E40
0000786bc93db8ce  jmp 0x0000786BC93D66C0
0000786bc93db8d3  call 0x0000786BC920C380
0000786bc93db8d8  jmp 0x0000786BC93D66CA
0000786bc93db8dd  call 0x0000786BC920D600
0000786bc93db8e2  jmp 0x0000786BC93D66D4
0000786bc93db8e7  call 0x0000786BC91FF540
0000786bc93db8ec  jmp 0x0000786BC93D66DE
0000786bc93db8f1  int3
0000786bc93db8f2  nop [rax+rax*1], ax
0000786bc93db8fb  nop [rax+rax*1], eax
0000786bc93db900  mov eax, [r15+0x48]
0000786bc93db904  lea r14d, [eax+0x01]
0000786bc93db909  mov [rsp+0x10], r14d
0000786bc93db90e  mov r14d, r14d
0000786bc93db911  mov [r15+0x48], r14
0000786bc93db915  xor eax, eax
0000786bc93db917  mov r14d, [rsp+0x10]
0000786bc93db91c  cmp r14d, 0x1F4
0000786bc93db923  cmc
0000786bc93db924  lahf
0000786bc93db925  seto al
0000786bc93db928  mov [r15+0x108], eax
0000786bc93db92f  mov eax, [r15+0x108]
0000786bc93db936  sahf
0000786bc93db937  jnz 0x0000786BC93DB969
0000786bc93db939  cmp dword ptr [r15+0x318], 0x00
0000786bc93db941  jz 0x0000786BC93E1AB0
0000786bc93db947  nop [rax+rax*1], ax
0000786bc93db950  nop [rax+rax*1], eax
0000786bc93db958  mov eax, 0x410450
0000786bc93db95d  mov [r15+0x100], rax
0000786bc93db964  jmp 0x0000786BC91FE110
0000786bc93db969  cmp dword ptr [r15+0x318], 0x00
0000786bc93db971  jz 0x0000786BC93DB9A0
0000786bc93db977  nop [rax+rax*1], ax
0000786bc93db980  nop [rax+rax*1], eax
0000786bc93db988  mov eax, 0x410274
0000786bc93db98d  mov [r15+0x100], rax
0000786bc93db994  jmp 0x0000786BC91FE110
0000786bc93db999  int3
0000786bc93db99a  int3
0000786bc93db99b  nop [rax+rax*1], eax
0000786bc93db9a0  mov rax, [r15+0x40]
0000786bc93db9a4  movaps xmm1, [r15+0x1D0]
0000786bc93db9ac  vmovaps [rsp+0x10], xmm1
0000786bc93db9b2  vmovaps xmm15, [rsp+0x10]
0000786bc93db9b8  por xmm1, xmm15
0000786bc93db9bd  movaps xmm14, [r15+0x1A0]
0000786bc93db9c5  vmovaps [rsp+0x10], xmm14
0000786bc93db9cb  vmovaps xmm13, [rsp+0x10]
0000786bc93db9d1  por xmm14, xmm13
0000786bc93db9d6  lea r14, [rax+0x30]
0000786bc93db9da  mov r12, [r13+r14*1]
0000786bc93db9df  lea r14, [rax+0x38]
0000786bc93db9e3  mov r11, [r13+r14*1]
0000786bc93db9e8  movq xmm13, r12
0000786bc93db9ed  movq xmm12, r11
0000786bc93db9f2  movq xmm13, xmm13
0000786bc93db9f7  vmovaps [rsp+0x10], xmm13
0000786bc93db9fd  movq xmm13, xmm13
0000786bc93dba02  movaps [r15+0x130], xmm13
0000786bc93dba0a  movq xmm12, xmm12
0000786bc93dba0f  vmovaps [rsp+0x20], xmm12
0000786bc93dba15  movq xmm12, xmm12
0000786bc93dba1a  movaps [r15+0x280], xmm12
0000786bc93dba22  movaps xmm13, [r15+0x270]
0000786bc93dba2a  vmovaps [rsp+0x30], xmm13
0000786bc93dba30  vmovaps xmm12, [rsp+0x30]
0000786bc93dba36  por xmm13, xmm12
0000786bc93dba3b  lea r14, [rax+0x20]
0000786bc93dba3f  mov r12, [r13+r14*1]
0000786bc93dba44  lea r14, [rax+0x28]
0000786bc93dba48  mov r11, [r13+r14*1]
0000786bc93dba4d  movq xmm12, r12
0000786bc93dba52  movq xmm11, r11
0000786bc93dba57  movq xmm12, xmm12
0000786bc93dba5c  vmovaps [rsp+0x30], xmm12
0000786bc93dba62  movq xmm12, xmm12
0000786bc93dba67  movaps [r15+0x150], xmm12
0000786bc93dba6f  movq xmm11, xmm11
0000786bc93dba74  vmovaps [rsp+0x40], xmm11
0000786bc93dba7a  movq xmm11, xmm11
0000786bc93dba7f  movaps [r15+0x140], xmm11
0000786bc93dba87  lea r14, [rax+0x10]
0000786bc93dba8b  mov r12, [r13+r14*1]
0000786bc93dba90  lea r14, [rax+0x18]
0000786bc93dba94  mov r11, [r13+r14*1]
0000786bc93dba99  movq xmm12, r12
0000786bc93dba9e  movq xmm11, r11
0000786bc93dbaa3  movq xmm12, xmm12
0000786bc93dbaa8  vmovaps [rsp+0x50], xmm12
0000786bc93dbaae  movq xmm12, xmm12
0000786bc93dbab3  movaps [r15+0x170], xmm12
0000786bc93dbabb  movq xmm11, xmm11
0000786bc93dbac0  vmovaps [rsp+0x60], xmm11
0000786bc93dbac6  movq xmm11, xmm11
0000786bc93dbacb  movaps [r15+0x160], xmm11
0000786bc93dbad3  mov r14, [r13+rax*1]
0000786bc93dbad8  vmovq xmm12, r14
0000786bc93dbadd  vpbroadcastq xmm12, xmm12
0000786bc93dbae2  lea r14, [rax+0x08]
0000786bc93dbae6  mov rax, [r13+r14*1]
0000786bc93dbaeb  movq xmm11, rax
0000786bc93dbaf0  movaps [r15+0x230], xmm11
0000786bc93dbaf8  mov rax, [r15+0xF8]
0000786bc93dbaff  lea r14, [rax+0x50]
0000786bc93dbb03  movups xmm11, [r13+r14*1]
0000786bc93dbb09  lea r14, [rax+0x60]
0000786bc93dbb0d  movups xmm10, [r13+r14*1]
0000786bc93dbb13  lea r14, [rax+0x30]
0000786bc93dbb17  movups xmm9, [r13+r14*1]
0000786bc93dbb1d  mov r14, [r15+0x50]
0000786bc93dbb21  mov [r15+0x60], r14
0000786bc93dbb25  mov qword ptr [r15+0x58], 0x40
0000786bc93dbb2d  movaps xmm8, xmm12
0000786bc93dbb31  mulpd xmm8, xmm15
0000786bc93dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000786bc93dbb3c  ptest xmm7, xmm7
0000786bc93dbb41  jnz 0x0000786BC93DC96A
0000786bc93dbb47  movq xmm15, qword ptr [r15+0x230]
0000786bc93dbb50  vmovaps [rsp+0x70], xmm15
0000786bc93dbb56  vpermilpd xmm15, xmm15, 0x00
0000786bc93dbb5c  movaps xmm7, xmm9
0000786bc93dbb60  mulpd xmm7, xmm15
0000786bc93dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000786bc93dbb6a  ptest xmm6, xmm6
0000786bc93dbb6f  jnz 0x0000786BC93DCAAE
0000786bc93dbb75  vxorps xmm15, xmm15, xmm15
0000786bc93dbb7a  vpbroadcastq xmm15, xmm15
0000786bc93dbb7f  movaps xmm9, xmm12
0000786bc93dbb83  mulpd xmm9, xmm10
0000786bc93dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000786bc93dbb8e  ptest xmm6, xmm6
0000786bc93dbb93  jnz 0x0000786BC93DCBF0
0000786bc93dbb99  movaps xmm10, xmm12
0000786bc93dbb9d  mulpd xmm10, xmm11
0000786bc93dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000786bc93dbba8  ptest xmm6, xmm6
0000786bc93dbbad  jnz 0x0000786BC93DCD34
0000786bc93dbbb3  movaps xmm11, [r15+0x1F0]
0000786bc93dbbbb  movaps xmm6, xmm12
0000786bc93dbbbf  mulpd xmm6, xmm11
0000786bc93dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000786bc93dbbc9  ptest xmm5, xmm5
0000786bc93dbbce  jnz 0x0000786BC93DCE78
0000786bc93dbbd4  movaps xmm12, [r15+0x2A0]
0000786bc93dbbdc  vmovaps [rsp+0x80], xmm12
0000786bc93dbbe5  vmovaps xmm11, [rsp+0x80]
0000786bc93dbbee  por xmm12, xmm11
0000786bc93dbbf3  movaps xmm11, [r15+0x250]
0000786bc93dbbfb  vmovaps [rsp+0x80], xmm11
0000786bc93dbc04  vmovaps xmm5, [rsp+0x80]
0000786bc93dbc0d  por xmm11, xmm5
0000786bc93dbc12  vmovaps xmm4, [rsp+0x70]
0000786bc93dbc18  vpermilpd xmm4, xmm4, 0x00
0000786bc93dbc1e  movaps xmm3, xmm5
0000786bc93dbc21  mulpd xmm3, xmm4
0000786bc93dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000786bc93dbc2a  ptest xmm2, xmm2
0000786bc93dbc2f  jnz 0x0000786BC93DCFBA
0000786bc93dbc35  mov [rsp+0x80], rax
0000786bc93dbc3d  xor eax, eax
0000786bc93dbc3f  mov r12d, 0x40
0000786bc93dbc45  mov r11d, 0x200
0000786bc93dbc4b  cmp r12, r11
0000786bc93dbc4e  cmc
0000786bc93dbc4f  lahf
0000786bc93dbc50  seto al
0000786bc93dbc53  mov [r15+0x108], eax
0000786bc93dbc5a  movaps xmm5, xmm8
0000786bc93dbc5e  addpd xmm5, xmm15
0000786bc93dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000786bc93dbc68  ptest xmm4, xmm4
0000786bc93dbc6d  jnz 0x0000786BC93DD0FA
0000786bc93dbc73  movaps xmm8, [r15+0x1B0]
0000786bc93dbc7b  movaps xmm4, xmm9
0000786bc93dbc7f  addpd xmm4, xmm8
0000786bc93dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000786bc93dbc89  ptest xmm2, xmm2
0000786bc93dbc8e  jnz 0x0000786BC93DD23C
0000786bc93dbc94  movaps xmm9, xmm10
0000786bc93dbc98  addpd xmm9, xmm8
0000786bc93dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000786bc93dbca3  ptest xmm2, xmm2
0000786bc93dbca8  jnz 0x0000786BC93DD37E
0000786bc93dbcae  movaps xmm10, [r15+0x2F0]
0000786bc93dbcb6  vmovaps [rsp+0x90], xmm10
0000786bc93dbcbf  vmovaps xmm8, [rsp+0x90]
0000786bc93dbcc8  por xmm10, xmm8
0000786bc93dbccd  movaps xmm8, [r15+0x2E0]
0000786bc93dbcd5  vmovaps [rsp+0x90], xmm8
0000786bc93dbcde  vmovaps xmm2, [rsp+0x90]
0000786bc93dbce7  por xmm8, xmm2
0000786bc93dbcec  movaps xmm2, [r15+0x2D0]
0000786bc93dbcf4  vmovaps [rsp+0x90], xmm2
0000786bc93dbcfd  vmovaps [rsp+0xA0], xmm1
0000786bc93dbd06  vmovaps xmm1, [rsp+0x90]
0000786bc93dbd0f  por xmm2, xmm1
0000786bc93dbd13  movaps xmm1, [r15+0x200]
0000786bc93dbd1b  vmovaps [rsp+0x90], xmm1
0000786bc93dbd24  vmovaps [rsp+0xB0], xmm15
0000786bc93dbd2d  vmovaps xmm15, [rsp+0x90]
0000786bc93dbd36  por xmm1, xmm15
0000786bc93dbd3b  movaps xmm15, [r15+0x1C0]
0000786bc93dbd43  vmovaps [rsp+0x90], xmm15
0000786bc93dbd4c  vmovaps [rsp+0xC0], xmm1
0000786bc93dbd55  vmovaps xmm1, [rsp+0x90]
0000786bc93dbd5e  por xmm15, xmm1
0000786bc93dbd63  movaps xmm1, [r15+0x190]
0000786bc93dbd6b  vmovaps [rsp+0x90], xmm1
0000786bc93dbd74  vmovaps [rsp+0xD0], xmm15
0000786bc93dbd7d  vmovaps xmm15, [rsp+0x90]
0000786bc93dbd86  por xmm1, xmm15
0000786bc93dbd8b  movaps xmm15, [r15+0x300]
0000786bc93dbd93  vmovaps [rsp+0x90], xmm15
0000786bc93dbd9c  vmovaps [rsp+0xE0], xmm1
0000786bc93dbda5  vmovaps xmm1, [rsp+0x90]
0000786bc93dbdae  por xmm15, xmm1
0000786bc93dbdb3  mov rax, [rsp+0x80]
0000786bc93dbdbb  lea r12, [rax+0xA0]
0000786bc93dbdc2  movups xmm1, [r13+r12*1]
0000786bc93dbdc8  lea r12, [rax+0xB0]
0000786bc93dbdcf  vmovaps [rsp+0x80], xmm1
0000786bc93dbdd8  movups xmm1, [r13+r12*1]
0000786bc93dbdde  vmovaps [rsp+0x90], xmm1
0000786bc93dbde7  vmovaps [rsp+0xF0], xmm15
0000786bc93dbdf0  vmovaps xmm15, [rsp+0xB0]
0000786bc93dbdf9  vmovaps [rsp+0xB0], xmm14
0000786bc93dbe02  movaps xmm1, xmm6
0000786bc93dbe05  addpd xmm1, xmm15
0000786bc93dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000786bc93dbe0f  ptest xmm14, xmm14
0000786bc93dbe15  jnz 0x0000786BC93DD4D6
0000786bc93dbe1b  lea r12, [rax+0xF0]
0000786bc93dbe22  movups xmm15, [r13+r12*1]
0000786bc93dbe28  movaps xmm14, xmm4
0000786bc93dbe2c  addpd xmm14, xmm3
0000786bc93dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000786bc93dbe37  ptest xmm6, xmm6
0000786bc93dbe3c  jnz 0x0000786BC93DD621
0000786bc93dbe42  movaps xmm6, xmm9
0000786bc93dbe46  addpd xmm6, xmm7
0000786bc93dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000786bc93dbe4f  ptest xmm4, xmm4
0000786bc93dbe54  jnz 0x0000786BC93DD763
0000786bc93dbe5a  vmovaps xmm9, [rsp+0x70]
0000786bc93dbe60  vpermilpd xmm9, xmm9, 0x00
0000786bc93dbe66  vmovaps xmm4, [rsp+0x90]
0000786bc93dbe6f  movaps xmm7, xmm4
0000786bc93dbe72  mulpd xmm7, xmm9
0000786bc93dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000786bc93dbe7c  ptest xmm3, xmm3
0000786bc93dbe81  jnz 0x0000786BC93DD8A4
0000786bc93dbe87  vmovaps xmm9, [rsp+0x50]
0000786bc93dbe8d  vpermilpd xmm9, xmm9, 0x00
0000786bc93dbe93  movaps xmm4, xmm15
0000786bc93dbe97  mulpd xmm4, xmm9
0000786bc93dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000786bc93dbea1  ptest xmm3, xmm3
0000786bc93dbea6  jnz 0x0000786BC93DD9E5
0000786bc93dbeac  lea r12, [rax+0xE0]
0000786bc93dbeb3  movups xmm15, [r13+r12*1]
0000786bc93dbeb9  vmovaps xmm9, [rsp+0x70]
0000786bc93dbebf  vpermilpd xmm9, xmm9, 0x00
0000786bc93dbec5  vmovaps [rsp+0x70], xmm1
0000786bc93dbecb  vmovaps xmm1, [rsp+0x80]
0000786bc93dbed4  vmovaps [rsp+0x80], xmm15
0000786bc93dbedd  movaps xmm3, xmm1
0000786bc93dbee0  mulpd xmm3, xmm9
0000786bc93dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000786bc93dbeea  ptest xmm15, xmm15
0000786bc93dbef0  jnz 0x0000786BC93DDB31
0000786bc93dbef6  vmovaps xmm1, [rsp+0xF0]
0000786bc93dbeff  vmovaps xmm15, [rsp+0xF0]
0000786bc93dbf08  por xmm1, xmm15
0000786bc93dbf0d  movaps [r15+0x300], xmm1
0000786bc93dbf15  vmovaps xmm15, [rsp+0xE0]
0000786bc93dbf1e  vmovaps xmm9, [rsp+0xE0]
0000786bc93dbf27  por xmm15, xmm9
0000786bc93dbf2c  movaps [r15+0x190], xmm15
0000786bc93dbf34  vmovaps xmm9, [rsp+0x50]
0000786bc93dbf3a  vpermilpd xmm9, xmm9, 0x00
0000786bc93dbf40  vmovaps [rsp+0x90], xmm1
0000786bc93dbf49  vmovaps [rsp+0xE0], xmm15
0000786bc93dbf52  vmovaps xmm15, [rsp+0x80]
0000786bc93dbf5b  vmovaps [rsp+0x80], xmm14
0000786bc93dbf64  movaps xmm1, xmm15
0000786bc93dbf68  mulpd xmm1, xmm9
0000786bc93dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000786bc93dbf72  ptest xmm14, xmm14
0000786bc93dbf78  jnz 0x0000786BC93DDC72
0000786bc93dbf7e  lea r12, [rax+0x90]
0000786bc93dbf85  movups xmm15, [r13+r12*1]
0000786bc93dbf8b  vmovaps xmm14, [rsp+0xD0]
0000786bc93dbf94  vmovaps xmm9, [rsp+0xD0]
0000786bc93dbf9d  por xmm14, xmm9
0000786bc93dbfa2  movaps [r15+0x1C0], xmm14
0000786bc93dbfaa  vmovaps xmm9, [rsp+0xC0]
0000786bc93dbfb3  vmovaps [rsp+0xD0], xmm1
0000786bc93dbfbc  vmovaps xmm1, [rsp+0xC0]
0000786bc93dbfc5  por xmm9, xmm1
0000786bc93dbfca  movaps [r15+0x200], xmm9
0000786bc93dbfd2  vmovaps [rsp+0xC0], xmm2
0000786bc93dbfdb  vmovaps xmm1, [rsp+0xC0]
0000786bc93dbfe4  por xmm2, xmm1
0000786bc93dbfe8  movaps [r15+0x2D0], xmm2
0000786bc93dbff0  vmovaps [rsp+0xC0], xmm8
0000786bc93dbff9  vmovaps xmm1, [rsp+0xC0]
0000786bc93dc002  por xmm8, xmm1
0000786bc93dc007  movaps [r15+0x2E0], xmm8
0000786bc93dc00f  vmovaps [rsp+0xC0], xmm15
0000786bc93dc018  movaps xmm1, xmm5
0000786bc93dc01b  addpd xmm1, xmm7
0000786bc93dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000786bc93dc024  ptest xmm15, xmm15
0000786bc93dc02a  jnz 0x0000786BC93DDDBE
0000786bc93dc030  vmovaps xmm15, [rsp+0x50]
0000786bc93dc036  vpermilpd xmm15, xmm15, 0x00
0000786bc93dc03c  vmovaps xmm5, [rsp+0xC0]
0000786bc93dc045  vmovaps [rsp+0xC0], xmm1
0000786bc93dc04e  movaps xmm7, xmm5
0000786bc93dc051  mulpd xmm7, xmm15
0000786bc93dc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000786bc93dc05b  ptest xmm1, xmm1
0000786bc93dc060  jnz 0x0000786BC93DDEFE
0000786bc93dc066  lea r12, [rax+0x80]
0000786bc93dc06d  movups xmm1, [r13+r12*1]
0000786bc93dc073  vmovaps xmm5, [rsp+0x70]
0000786bc93dc079  vmovaps [rsp+0x70], xmm1
0000786bc93dc07f  movaps xmm15, xmm5
0000786bc93dc083  addpd xmm15, xmm3
0000786bc93dc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93dc08e  ptest xmm1, xmm1
0000786bc93dc093  jnz 0x0000786BC93DE049
0000786bc93dc099  vmovaps xmm5, [rsp+0x80]
0000786bc93dc0a2  movaps xmm1, xmm5
0000786bc93dc0a5  addpd xmm1, xmm4
0000786bc93dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000786bc93dc0ae  ptest xmm3, xmm3
0000786bc93dc0b3  jnz 0x0000786BC93DE18B
0000786bc93dc0b9  vmovaps [rsp+0x80], xmm10
0000786bc93dc0c2  vmovaps xmm5, [rsp+0x80]
0000786bc93dc0cb  por xmm10, xmm5
0000786bc93dc0d0  movaps [r15+0x2F0], xmm10
0000786bc93dc0d8  vmovaps xmm5, [rsp+0x50]
0000786bc93dc0de  vpermilpd xmm5, xmm5, 0x00
0000786bc93dc0e4  vmovaps xmm3, [rsp+0x70]
0000786bc93dc0ea  vmovaps [rsp+0x50], xmm1
0000786bc93dc0f0  movaps xmm4, xmm3
0000786bc93dc0f3  mulpd xmm4, xmm5
0000786bc93dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000786bc93dc0fc  ptest xmm1, xmm1
0000786bc93dc101  jnz 0x0000786BC93DE2CB
0000786bc93dc107  lea r12, [rax+0xD0]
0000786bc93dc10e  movups xmm1, [r13+r12*1]
0000786bc93dc114  vmovaps xmm3, [rsp+0xD0]
0000786bc93dc11d  vmovaps [rsp+0x70], xmm1
0000786bc93dc123  movaps xmm5, xmm6
0000786bc93dc126  addpd xmm5, xmm3
0000786bc93dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000786bc93dc12f  ptest xmm1, xmm1
0000786bc93dc134  jnz 0x0000786BC93DE415
0000786bc93dc13a  vmovaps xmm1, [rsp+0x60]
0000786bc93dc140  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc146  movaps xmm6, xmm9
0000786bc93dc14a  mulpd xmm6, xmm1
0000786bc93dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000786bc93dc153  ptest xmm3, xmm3
0000786bc93dc158  jnz 0x0000786BC93DE555
0000786bc93dc15e  movaps [r15+0x260], xmm6
0000786bc93dc166  vxorps xmm1, xmm1, xmm1
0000786bc93dc16a  vpbroadcastq xmm1, xmm1
0000786bc93dc16f  movaps [r15+0x1B0], xmm1
0000786bc93dc177  vmovaps xmm1, [rsp+0x60]
0000786bc93dc17d  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc183  vmovaps xmm3, [rsp+0x70]
0000786bc93dc189  vmovaps [rsp+0x70], xmm15
0000786bc93dc18f  movaps xmm9, xmm3
0000786bc93dc193  mulpd xmm9, xmm1
0000786bc93dc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000786bc93dc19e  ptest xmm15, xmm15
0000786bc93dc1a4  jnz 0x0000786BC93DE696
0000786bc93dc1aa  lea r12, [rax+0xC0]
0000786bc93dc1b1  movups xmm1, [r13+r12*1]
0000786bc93dc1b7  vmovaps xmm3, [rsp+0xC0]
0000786bc93dc1c0  vmovaps [rsp+0x80], xmm1
0000786bc93dc1c9  movaps xmm15, xmm3
0000786bc93dc1cd  addpd xmm15, xmm7
0000786bc93dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93dc1d8  ptest xmm1, xmm1
0000786bc93dc1dd  jnz 0x0000786BC93DE7E2
0000786bc93dc1e3  vmovaps [rsp+0xC0], xmm13
0000786bc93dc1ec  vmovaps xmm1, [rsp+0xC0]
0000786bc93dc1f5  por xmm13, xmm1
0000786bc93dc1fa  movaps [r15+0x270], xmm13
0000786bc93dc202  vmovaps xmm1, [rsp+0xB0]
0000786bc93dc20b  vmovaps xmm7, [rsp+0xB0]
0000786bc93dc214  por xmm1, xmm7
0000786bc93dc218  movaps [r15+0x1A0], xmm1
0000786bc93dc220  vmovaps xmm1, [rsp+0x60]
0000786bc93dc226  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc22c  vmovaps [rsp+0xB0], xmm1
0000786bc93dc235  vmovaps xmm1, [rsp+0x80]
0000786bc93dc23e  vmovaps [rsp+0x80], xmm15
0000786bc93dc247  vmovaps xmm15, [rsp+0xB0]
0000786bc93dc250  vmovaps [rsp+0xB0], xmm14
0000786bc93dc259  movaps xmm3, xmm1
0000786bc93dc25c  mulpd xmm3, xmm15
0000786bc93dc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000786bc93dc266  ptest xmm14, xmm14
0000786bc93dc26c  jnz 0x0000786BC93DE924
0000786bc93dc272  lea r12, [rax+0x20]
0000786bc93dc276  movups xmm1, [r13+r12*1]
0000786bc93dc27c  movaps [r15+0x110], xmm1
0000786bc93dc284  vmovaps xmm14, [rsp+0x70]
0000786bc93dc28a  vmovaps [rsp+0x70], xmm1
0000786bc93dc290  movaps xmm15, xmm14
0000786bc93dc294  addpd xmm15, xmm4
0000786bc93dc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000786bc93dc29f  ptest xmm1, xmm1
0000786bc93dc2a4  jnz 0x0000786BC93DEA6F
0000786bc93dc2aa  vmovaps xmm1, [rsp+0x60]
0000786bc93dc2b0  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc2b6  movaps xmm14, xmm2
0000786bc93dc2ba  mulpd xmm14, xmm1
0000786bc93dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000786bc93dc2c5  ptest xmm4, xmm4
0000786bc93dc2ca  jnz 0x0000786BC93DEBB2
0000786bc93dc2d0  vmovaps xmm4, [rsp+0x50]
0000786bc93dc2d6  movaps xmm1, xmm4
0000786bc93dc2d9  addpd xmm1, xmm9
0000786bc93dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000786bc93dc2e3  ptest xmm2, xmm2
0000786bc93dc2e8  jnz 0x0000786BC93DECF4
0000786bc93dc2ee  vmovaps xmm9, [rsp+0x30]
0000786bc93dc2f4  vpermilpd xmm9, xmm9, 0x00
0000786bc93dc2fa  vmovaps xmm2, [rsp+0x70]
0000786bc93dc300  vmovaps [rsp+0x50], xmm1
0000786bc93dc306  movaps xmm4, xmm2
0000786bc93dc309  mulpd xmm4, xmm9
0000786bc93dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000786bc93dc313  ptest xmm1, xmm1
0000786bc93dc318  jnz 0x0000786BC93DEE35
0000786bc93dc31e  vmovaps xmm1, [rsp+0x30]
0000786bc93dc324  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc32a  vmovaps xmm2, [rsp+0x90]
0000786bc93dc333  vmovaps [rsp+0x60], xmm15
0000786bc93dc339  movaps xmm9, xmm2
0000786bc93dc33d  mulpd xmm9, xmm1
0000786bc93dc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000786bc93dc348  ptest xmm15, xmm15
0000786bc93dc34e  jnz 0x0000786BC93DEF76
0000786bc93dc354  vmovaps xmm15, [rsp+0x80]
0000786bc93dc35d  movaps xmm1, xmm15
0000786bc93dc361  addpd xmm1, xmm6
0000786bc93dc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000786bc93dc36a  ptest xmm2, xmm2
0000786bc93dc36f  jnz 0x0000786BC93DF0B8
0000786bc93dc375  movaps xmm15, xmm5
0000786bc93dc379  addpd xmm15, xmm3
0000786bc93dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000786bc93dc384  ptest xmm6, xmm6
0000786bc93dc389  jnz 0x0000786BC93DF1F9
0000786bc93dc38f  vmovaps xmm6, [rsp+0x30]
0000786bc93dc395  vpermilpd xmm6, xmm6, 0x00
0000786bc93dc39b  movaps xmm5, xmm8
0000786bc93dc39f  mulpd xmm5, xmm6
0000786bc93dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000786bc93dc3a8  ptest xmm3, xmm3
0000786bc93dc3ad  jnz 0x0000786BC93DF33B
0000786bc93dc3b3  vmovaps xmm8, [rsp+0x30]
0000786bc93dc3b9  vpermilpd xmm8, xmm8, 0x00
0000786bc93dc3bf  movaps xmm6, xmm10
0000786bc93dc3c3  mulpd xmm6, xmm8
0000786bc93dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000786bc93dc3cd  ptest xmm3, xmm3
0000786bc93dc3d2  jnz 0x0000786BC93DF47C
0000786bc93dc3d8  vmovaps xmm8, [rsp+0x60]
0000786bc93dc3de  movaps xmm10, xmm8
0000786bc93dc3e2  addpd xmm10, xmm14
0000786bc93dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000786bc93dc3ed  ptest xmm3, xmm3
0000786bc93dc3f2  jnz 0x0000786BC93DF5BE
0000786bc93dc3f8  vmovaps xmm8, [rsp+0x50]
0000786bc93dc3fe  movaps xmm14, xmm8
0000786bc93dc402  addpd xmm14, xmm4
0000786bc93dc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000786bc93dc40d  ptest xmm3, xmm3
0000786bc93dc412  jnz 0x0000786BC93DF702
0000786bc93dc418  vmovaps xmm8, [rsp+0x40]
0000786bc93dc41e  vpermilpd xmm8, xmm8, 0x00
0000786bc93dc424  movaps xmm4, xmm13
0000786bc93dc428  mulpd xmm4, xmm8
0000786bc93dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000786bc93dc432  ptest xmm3, xmm3
0000786bc93dc437  jnz 0x0000786BC93DF845
0000786bc93dc43d  movaps xmm13, xmm15
0000786bc93dc441  addpd xmm13, xmm9
0000786bc93dc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000786bc93dc44c  ptest xmm8, xmm8
0000786bc93dc452  jnz 0x0000786BC93DF987
0000786bc93dc458  movaps xmm15, xmm1
0000786bc93dc45c  addpd xmm15, xmm5
0000786bc93dc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000786bc93dc467  ptest xmm9, xmm9
0000786bc93dc46d  jnz 0x0000786BC93DFACB
0000786bc93dc473  vmovaps [rsp+0x30], xmm11
0000786bc93dc479  vmovaps xmm1, [rsp+0x30]
0000786bc93dc47f  por xmm11, xmm1
0000786bc93dc484  movaps [r15+0x250], xmm11
0000786bc93dc48c  vmovaps [rsp+0x30], xmm12
0000786bc93dc492  vmovaps xmm1, [rsp+0x30]
0000786bc93dc498  por xmm12, xmm1
0000786bc93dc49d  movaps [r15+0x2A0], xmm12
0000786bc93dc4a5  vmovaps xmm1, [rsp+0xA0]
0000786bc93dc4ae  vmovaps xmm11, [rsp+0xA0]
0000786bc93dc4b7  por xmm1, xmm11
0000786bc93dc4bc  movaps [r15+0x1D0], xmm1
0000786bc93dc4c4  lea r12, [rax+0x40]
0000786bc93dc4c8  movups xmm1, [r13+r12*1]
0000786bc93dc4ce  movaps [r15+0x2C0], xmm1
0000786bc93dc4d6  vmovaps xmm11, [rsp+0x40]
0000786bc93dc4dc  vpermilpd xmm11, xmm11, 0x00
0000786bc93dc4e2  vmovaps xmm8, [rsp+0xE0]
0000786bc93dc4eb  movaps xmm9, xmm8
0000786bc93dc4ef  mulpd xmm9, xmm11
0000786bc93dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000786bc93dc4fa  ptest xmm5, xmm5
0000786bc93dc4ff  jnz 0x0000786BC93DFC17
0000786bc93dc505  movaps xmm11, xmm10
0000786bc93dc509  addpd xmm11, xmm6
0000786bc93dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000786bc93dc514  ptest xmm8, xmm8
0000786bc93dc51a  jnz 0x0000786BC93DFD5B
0000786bc93dc520  movaps xmm10, xmm14
0000786bc93dc524  addpd xmm10, xmm4
0000786bc93dc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000786bc93dc52f  ptest xmm8, xmm8
0000786bc93dc535  jnz 0x0000786BC93DFE9E
0000786bc93dc53b  vmovaps xmm14, [rsp+0x40]
0000786bc93dc541  vpermilpd xmm14, xmm14, 0x00
0000786bc93dc547  movaps xmm8, xmm1
0000786bc93dc54b  mulpd xmm8, xmm14
0000786bc93dc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000786bc93dc556  ptest xmm6, xmm6
0000786bc93dc55b  jnz 0x0000786BC93DFFE1
0000786bc93dc561  movaps xmm1, [r15+0x2B0]
0000786bc93dc569  vmovaps xmm14, [rsp+0x40]
0000786bc93dc56f  vpermilpd xmm14, xmm14, 0x00
0000786bc93dc575  movaps xmm6, xmm1
0000786bc93dc578  mulpd xmm6, xmm14
0000786bc93dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000786bc93dc582  ptest xmm5, xmm5
0000786bc93dc587  jnz 0x0000786BC93E0124
0000786bc93dc58d  vmovaps xmm1, [rsp+0x10]
0000786bc93dc593  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc599  movaps xmm14, xmm12
0000786bc93dc59d  mulpd xmm14, xmm1
0000786bc93dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000786bc93dc5a8  ptest xmm5, xmm5
0000786bc93dc5ad  jnz 0x0000786BC93E0265
0000786bc93dc5b3  movaps xmm1, xmm13
0000786bc93dc5b7  addpd xmm1, xmm9
0000786bc93dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000786bc93dc5c1  ptest xmm12, xmm12
0000786bc93dc5c7  jnz 0x0000786BC93E03A8
0000786bc93dc5cd  vmovaps xmm13, [rsp+0x10]
0000786bc93dc5d3  vpermilpd xmm13, xmm13, 0x00
0000786bc93dc5d9  movaps xmm12, xmm7
0000786bc93dc5dd  mulpd xmm12, xmm13
0000786bc93dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000786bc93dc5e8  ptest xmm9, xmm9
0000786bc93dc5ee  jnz 0x0000786BC93E04EA
0000786bc93dc5f4  movaps xmm13, xmm15
0000786bc93dc5f8  addpd xmm13, xmm8
0000786bc93dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000786bc93dc603  ptest xmm9, xmm9
0000786bc93dc609  jnz 0x0000786BC93E062D
0000786bc93dc60f  movaps xmm15, [r15+0x290]
0000786bc93dc617  vmovaps xmm9, [rsp+0x10]
0000786bc93dc61d  vpermilpd xmm9, xmm9, 0x00
0000786bc93dc623  movaps xmm8, xmm15
0000786bc93dc627  mulpd xmm8, xmm9
0000786bc93dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000786bc93dc632  ptest xmm7, xmm7
0000786bc93dc637  jnz 0x0000786BC93E0771
0000786bc93dc63d  movaps xmm15, xmm11
0000786bc93dc641  addpd xmm15, xmm6
0000786bc93dc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000786bc93dc64c  ptest xmm9, xmm9
0000786bc93dc652  jnz 0x0000786BC93E08B5
0000786bc93dc658  movaps xmm11, [r15+0x1E0]
0000786bc93dc660  vmovaps xmm9, [rsp+0x10]
0000786bc93dc666  vpermilpd xmm9, xmm9, 0x00
0000786bc93dc66c  movaps xmm7, xmm11
0000786bc93dc670  mulpd xmm7, xmm9
0000786bc93dc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000786bc93dc67a  ptest xmm6, xmm6
0000786bc93dc67f  jnz 0x0000786BC93E09F8
0000786bc93dc685  movaps xmm11, xmm10
0000786bc93dc689  addpd xmm11, xmm14
0000786bc93dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000786bc93dc694  ptest xmm9, xmm9
0000786bc93dc69a  jnz 0x0000786BC93E0B3A
0000786bc93dc6a0  lea r12, [rax+0x70]
0000786bc93dc6a4  movups xmm14, [r13+r12*1]
0000786bc93dc6aa  movaps [r15+0x240], xmm14
0000786bc93dc6b2  movaps xmm10, xmm1
0000786bc93dc6b6  addpd xmm10, xmm12
0000786bc93dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000786bc93dc6c1  ptest xmm9, xmm9
0000786bc93dc6c7  jnz 0x0000786BC93E0C88
0000786bc93dc6cd  movaps [r15+0x170], xmm10
0000786bc93dc6d5  vmovaps xmm1, [rsp+0x20]
0000786bc93dc6db  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc6e1  movaps xmm12, xmm14
0000786bc93dc6e5  mulpd xmm12, xmm1
0000786bc93dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000786bc93dc6f0  ptest xmm9, xmm9
0000786bc93dc6f6  jnz 0x0000786BC93E0DCB
0000786bc93dc6fc  vmovaps xmm1, [rsp+0x20]
0000786bc93dc702  vpermilpd xmm1, xmm1, 0x00
0000786bc93dc708  vmovaps xmm9, [rsp+0xB0]
0000786bc93dc711  movaps xmm14, xmm9
0000786bc93dc715  mulpd xmm14, xmm1
0000786bc93dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000786bc93dc720  ptest xmm6, xmm6
0000786bc93dc725  jnz 0x0000786BC93E0F0E
0000786bc93dc72b  movaps [r15+0x180], xmm14
0000786bc93dc733  movaps xmm1, xmm13
0000786bc93dc737  addpd xmm1, xmm8
0000786bc93dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000786bc93dc741  ptest xmm9, xmm9
0000786bc93dc747  jnz 0x0000786BC93E1051
0000786bc93dc74d  movaps [r15+0x210], xmm1
0000786bc93dc755  movups xmm13, [r13+rax*1]
0000786bc93dc75b  lea r12, [rax+0x10]
0000786bc93dc75f  movups xmm9, [r13+r12*1]
0000786bc93dc765  movaps [r15+0x230], xmm9
0000786bc93dc76d  movaps xmm8, xmm15
0000786bc93dc771  addpd xmm8, xmm7
0000786bc93dc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000786bc93dc77c  ptest xmm6, xmm6
0000786bc93dc781  jnz 0x0000786BC93E11A7
0000786bc93dc787  movaps [r15+0x130], xmm8
0000786bc93dc78f  vmovaps xmm15, [rsp+0x20]
0000786bc93dc795  vpermilpd xmm15, xmm15, 0x00
0000786bc93dc79b  movaps xmm7, xmm9
0000786bc93dc79f  mulpd xmm7, xmm15
0000786bc93dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000786bc93dc7a9  ptest xmm6, xmm6
0000786bc93dc7ae  jnz 0x0000786BC93E12EA
0000786bc93dc7b4  movaps [r15+0x220], xmm7
0000786bc93dc7bc  vmovaps xmm15, [rsp+0x20]
0000786bc93dc7c2  vpermilpd xmm15, xmm15, 0x00
0000786bc93dc7c8  movaps xmm9, xmm13
0000786bc93dc7cc  mulpd xmm9, xmm15
0000786bc93dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000786bc93dc7d7  ptest xmm6, xmm6
0000786bc93dc7dc  jnz 0x0000786BC93E142C
0000786bc93dc7e2  movaps xmm15, xmm11
0000786bc93dc7e6  addpd xmm15, xmm12
0000786bc93dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000786bc93dc7f1  ptest xmm13, xmm13
0000786bc93dc7f7  jnz 0x0000786BC93E1570
0000786bc93dc7fd  movaps [r15+0x140], xmm15
0000786bc93dc805  movaps xmm13, xmm10
0000786bc93dc809  addpd xmm13, xmm14
0000786bc93dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000786bc93dc814  ptest xmm12, xmm12
0000786bc93dc81a  jnz 0x0000786BC93E16B4
0000786bc93dc820  movaps [r15+0x150], xmm13
0000786bc93dc828  movaps xmm14, xmm1
0000786bc93dc82c  addpd xmm14, xmm7
0000786bc93dc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000786bc93dc837  ptest xmm12, xmm12
0000786bc93dc83d  jnz 0x0000786BC93E17F8
0000786bc93dc843  movaps [r15+0x160], xmm14
0000786bc93dc84b  movaps xmm1, xmm8
0000786bc93dc84f  addpd xmm1, xmm9
0000786bc93dc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000786bc93dc859  ptest xmm12, xmm12
0000786bc93dc85f  jnz 0x0000786BC93E193A
0000786bc93dc865  movaps [r15+0x120], xmm1
0000786bc93dc86d  movups [r13+r14*1], xmm15
0000786bc93dc873  lea rax, [r14+0x10]
0000786bc93dc877  movups [r13+rax*1], xmm13
0000786bc93dc87d  lea rax, [r14+0x20]
0000786bc93dc881  movups [r13+rax*1], xmm14
0000786bc93dc887  lea rax, [r14+0x30]
0000786bc93dc88b  movups [r13+rax*1], xmm1
0000786bc93dc891  mov eax, [r15+0x108]
0000786bc93dc898  sahf
0000786bc93dc899  jnz 0x0000786BC93DC8CB
0000786bc93dc89b  cmp dword ptr [r15+0x318], 0x00
0000786bc93dc8a3  jz 0x0000786BC93DB900
0000786bc93dc8a9  nop [rax+rax*1], ax
0000786bc93dc8b2  nop [rax+rax*1], eax
0000786bc93dc8ba  mov eax, 0x410444
0000786bc93dc8bf  mov [r15+0x100], rax
0000786bc93dc8c6  jmp 0x0000786BC91FE110
0000786bc93dc8cb  cmp dword ptr [r15+0x318], 0x00
0000786bc93dc8d3  jz 0x0000786BC93D57E0
0000786bc93dc8d9  nop [rax+rax*1], ax
0000786bc93dc8e2  nop [rax+rax*1], eax
0000786bc93dc8ea  mov eax, 0x410278
0000786bc93dc8ef  mov [r15+0x100], rax
0000786bc93dc8f6  jmp 0x0000786BC91FE110
0000786bc93dc8fb  int3
0000786bc93dc8fc  call 0x0000786BC92E27E0
0000786bc93dc901  jmp 0x0000786BC93DB9DF
0000786bc93dc906  call 0x0000786BC92E1570
0000786bc93dc90b  jmp 0x0000786BC93DB9E8
0000786bc93dc910  call 0x0000786BC92E27E0
0000786bc93dc915  jmp 0x0000786BC93DBA44
0000786bc93dc91a  call 0x0000786BC92E1570
0000786bc93dc91f  jmp 0x0000786BC93DBA4D
0000786bc93dc924  call 0x0000786BC92E27E0
0000786bc93dc929  jmp 0x0000786BC93DBA90
0000786bc93dc92e  call 0x0000786BC92E1570
0000786bc93dc933  jmp 0x0000786BC93DBA99
0000786bc93dc938  call 0x0000786BC920DC20
0000786bc93dc93d  jmp 0x0000786BC93DBAD8
0000786bc93dc942  call 0x0000786BC92D59C0
0000786bc93dc947  jmp 0x0000786BC93DBAEB
0000786bc93dc94c  call 0x0000786BC92E0E30
0000786bc93dc951  jmp 0x0000786BC93DBB09
0000786bc93dc956  call 0x0000786BC92DFBC0
0000786bc93dc95b  jmp 0x0000786BC93DBB13
0000786bc93dc960  call 0x0000786BC92DE950
0000786bc93dc965  jmp 0x0000786BC93DBB1D
0000786bc93dc96a  sub rsp, 0x08
0000786bc93dc96e  push rax
0000786bc93dc96f  push rcx
0000786bc93dc970  push rdx
0000786bc93dc971  push rdi
0000786bc93dc972  push rsi
0000786bc93dc973  push r8
0000786bc93dc975  push r9
0000786bc93dc977  push r10
0000786bc93dc979  push r11
0000786bc93dc97b  sub rsp, 0xF0
0000786bc93dc982  vmovaps [rsp], xmm0
0000786bc93dc987  vmovaps [rsp+0x10], xmm1
0000786bc93dc98d  vmovaps [rsp+0x20], xmm2
0000786bc93dc993  vmovaps [rsp+0x30], xmm3
0000786bc93dc999  vmovaps [rsp+0x40], xmm4
0000786bc93dc99f  vmovaps [rsp+0x50], xmm5
0000786bc93dc9a5  vmovaps [rsp+0x60], xmm6
0000786bc93dc9ab  vmovaps [rsp+0x70], xmm7
0000786bc93dc9b1  vmovaps [rsp+0x80], xmm9
0000786bc93dc9ba  vmovaps [rsp+0x90], xmm10
0000786bc93dc9c3  vmovaps [rsp+0xA0], xmm11
0000786bc93dc9cc  vmovaps [rsp+0xB0], xmm12
0000786bc93dc9d5  vmovaps [rsp+0xC0], xmm13
0000786bc93dc9de  vmovaps [rsp+0xD0], xmm14
0000786bc93dc9e7  vmovaps [rsp+0xE0], xmm15
0000786bc93dc9f0  sub rsp, 0x30
0000786bc93dc9f4  movaps [rsp], xmm8
0000786bc93dc9f9  movaps [rsp+0x10], xmm12
0000786bc93dc9ff  movaps [rsp+0x20], xmm15
0000786bc93dca05  lea rdi, [rsp]
0000786bc93dca09  mov esi, 0x00
0000786bc93dca0e  mov rax, 0x60810F6F7530
0000786bc93dca18  call rax
0000786bc93dca1a  movaps xmm8, [rsp]
0000786bc93dca1f  add rsp, 0x30
0000786bc93dca23  vmovaps xmm0, [rsp]
0000786bc93dca28  vmovaps xmm1, [rsp+0x10]
0000786bc93dca2e  vmovaps xmm2, [rsp+0x20]
0000786bc93dca34  vmovaps xmm3, [rsp+0x30]
0000786bc93dca3a  vmovaps xmm4, [rsp+0x40]
0000786bc93dca40  vmovaps xmm5, [rsp+0x50]
0000786bc93dca46  vmovaps xmm6, [rsp+0x60]
0000786bc93dca4c  vmovaps xmm7, [rsp+0x70]
0000786bc93dca52  vmovaps xmm9, [rsp+0x80]
0000786bc93dca5b  vmovaps xmm10, [rsp+0x90]
0000786bc93dca64  vmovaps xmm11, [rsp+0xA0]
0000786bc93dca6d  vmovaps xmm12, [rsp+0xB0]
0000786bc93dca76  vmovaps xmm13, [rsp+0xC0]
0000786bc93dca7f  vmovaps xmm14, [rsp+0xD0]
0000786bc93dca88  vmovaps xmm15, [rsp+0xE0]
0000786bc93dca91  add rsp, 0xF0
0000786bc93dca98  pop r11
0000786bc93dca9a  pop r10
0000786bc93dca9c  pop r9
0000786bc93dca9e  pop r8
0000786bc93dcaa0  pop rsi
0000786bc93dcaa1  pop rdi
0000786bc93dcaa2  pop rdx
0000786bc93dcaa3  pop rcx
0000786bc93dcaa4  pop rax
0000786bc93dcaa5  add rsp, 0x08
0000786bc93dcaa9  jmp 0x0000786BC93DBB47
0000786bc93dcaae  sub rsp, 0x08
0000786bc93dcab2  push rax
0000786bc93dcab3  push rcx
0000786bc93dcab4  push rdx
0000786bc93dcab5  push rdi
0000786bc93dcab6  push rsi
0000786bc93dcab7  push r8
0000786bc93dcab9  push r9
0000786bc93dcabb  push r10
0000786bc93dcabd  push r11
0000786bc93dcabf  sub rsp, 0xF0
0000786bc93dcac6  vmovaps [rsp], xmm0
0000786bc93dcacb  vmovaps [rsp+0x10], xmm1
0000786bc93dcad1  vmovaps [rsp+0x20], xmm2
0000786bc93dcad7  vmovaps [rsp+0x30], xmm3
0000786bc93dcadd  vmovaps [rsp+0x40], xmm4
0000786bc93dcae3  vmovaps [rsp+0x50], xmm5
0000786bc93dcae9  vmovaps [rsp+0x60], xmm6
0000786bc93dcaef  vmovaps [rsp+0x70], xmm8
0000786bc93dcaf5  vmovaps [rsp+0x80], xmm9
0000786bc93dcafe  vmovaps [rsp+0x90], xmm10
0000786bc93dcb07  vmovaps [rsp+0xA0], xmm11
0000786bc93dcb10  vmovaps [rsp+0xB0], xmm12
0000786bc93dcb19  vmovaps [rsp+0xC0], xmm13
0000786bc93dcb22  vmovaps [rsp+0xD0], xmm14
0000786bc93dcb2b  vmovaps [rsp+0xE0], xmm15
0000786bc93dcb34  sub rsp, 0x30
0000786bc93dcb38  movaps [rsp], xmm7
0000786bc93dcb3c  movaps [rsp+0x10], xmm9
0000786bc93dcb42  movaps [rsp+0x20], xmm15
0000786bc93dcb48  lea rdi, [rsp]
0000786bc93dcb4c  mov esi, 0x00
0000786bc93dcb51  mov rax, 0x60810F6F7530
0000786bc93dcb5b  call rax
0000786bc93dcb5d  movaps xmm7, [rsp]
0000786bc93dcb61  add rsp, 0x30
0000786bc93dcb65  vmovaps xmm0, [rsp]
0000786bc93dcb6a  vmovaps xmm1, [rsp+0x10]
0000786bc93dcb70  vmovaps xmm2, [rsp+0x20]
0000786bc93dcb76  vmovaps xmm3, [rsp+0x30]
0000786bc93dcb7c  vmovaps xmm4, [rsp+0x40]
0000786bc93dcb82  vmovaps xmm5, [rsp+0x50]
0000786bc93dcb88  vmovaps xmm6, [rsp+0x60]
0000786bc93dcb8e  vmovaps xmm8, [rsp+0x70]
0000786bc93dcb94  vmovaps xmm9, [rsp+0x80]
0000786bc93dcb9d  vmovaps xmm10, [rsp+0x90]
0000786bc93dcba6  vmovaps xmm11, [rsp+0xA0]
0000786bc93dcbaf  vmovaps xmm12, [rsp+0xB0]
0000786bc93dcbb8  vmovaps xmm13, [rsp+0xC0]
0000786bc93dcbc1  vmovaps xmm14, [rsp+0xD0]
0000786bc93dcbca  vmovaps xmm15, [rsp+0xE0]
0000786bc93dcbd3  add rsp, 0xF0
0000786bc93dcbda  pop r11
0000786bc93dcbdc  pop r10
0000786bc93dcbde  pop r9
0000786bc93dcbe0  pop r8
0000786bc93dcbe2  pop rsi
0000786bc93dcbe3  pop rdi
0000786bc93dcbe4  pop rdx
0000786bc93dcbe5  pop rcx
0000786bc93dcbe6  pop rax
0000786bc93dcbe7  add rsp, 0x08
0000786bc93dcbeb  jmp 0x0000786BC93DBB75
0000786bc93dcbf0  sub rsp, 0x08
0000786bc93dcbf4  push rax
0000786bc93dcbf5  push rcx
0000786bc93dcbf6  push rdx
0000786bc93dcbf7  push rdi
0000786bc93dcbf8  push rsi
0000786bc93dcbf9  push r8
0000786bc93dcbfb  push r9
0000786bc93dcbfd  push r10
0000786bc93dcbff  push r11
0000786bc93dcc01  sub rsp, 0xF0
0000786bc93dcc08  vmovaps [rsp], xmm0
0000786bc93dcc0d  vmovaps [rsp+0x10], xmm1
0000786bc93dcc13  vmovaps [rsp+0x20], xmm2
0000786bc93dcc19  vmovaps [rsp+0x30], xmm3
0000786bc93dcc1f  vmovaps [rsp+0x40], xmm4
0000786bc93dcc25  vmovaps [rsp+0x50], xmm5
0000786bc93dcc2b  vmovaps [rsp+0x60], xmm6
0000786bc93dcc31  vmovaps [rsp+0x70], xmm7
0000786bc93dcc37  vmovaps [rsp+0x80], xmm8
0000786bc93dcc40  vmovaps [rsp+0x90], xmm10
0000786bc93dcc49  vmovaps [rsp+0xA0], xmm11
0000786bc93dcc52  vmovaps [rsp+0xB0], xmm12
0000786bc93dcc5b  vmovaps [rsp+0xC0], xmm13
0000786bc93dcc64  vmovaps [rsp+0xD0], xmm14
0000786bc93dcc6d  vmovaps [rsp+0xE0], xmm15
0000786bc93dcc76  sub rsp, 0x30
0000786bc93dcc7a  movaps [rsp], xmm9
0000786bc93dcc7f  movaps [rsp+0x10], xmm12
0000786bc93dcc85  movaps [rsp+0x20], xmm10
0000786bc93dcc8b  lea rdi, [rsp]
0000786bc93dcc8f  mov esi, 0x00
0000786bc93dcc94  mov rax, 0x60810F6F7530
0000786bc93dcc9e  call rax
0000786bc93dcca0  movaps xmm9, [rsp]
0000786bc93dcca5  add rsp, 0x30
0000786bc93dcca9  vmovaps xmm0, [rsp]
0000786bc93dccae  vmovaps xmm1, [rsp+0x10]
0000786bc93dccb4  vmovaps xmm2, [rsp+0x20]
0000786bc93dccba  vmovaps xmm3, [rsp+0x30]
0000786bc93dccc0  vmovaps xmm4, [rsp+0x40]
0000786bc93dccc6  vmovaps xmm5, [rsp+0x50]
0000786bc93dcccc  vmovaps xmm6, [rsp+0x60]
0000786bc93dccd2  vmovaps xmm7, [rsp+0x70]
0000786bc93dccd8  vmovaps xmm8, [rsp+0x80]
0000786bc93dcce1  vmovaps xmm10, [rsp+0x90]
0000786bc93dccea  vmovaps xmm11, [rsp+0xA0]
0000786bc93dccf3  vmovaps xmm12, [rsp+0xB0]
0000786bc93dccfc  vmovaps xmm13, [rsp+0xC0]
0000786bc93dcd05  vmovaps xmm14, [rsp+0xD0]
0000786bc93dcd0e  vmovaps xmm15, [rsp+0xE0]
0000786bc93dcd17  add rsp, 0xF0
0000786bc93dcd1e  pop r11
0000786bc93dcd20  pop r10
0000786bc93dcd22  pop r9
0000786bc93dcd24  pop r8
0000786bc93dcd26  pop rsi
0000786bc93dcd27  pop rdi
0000786bc93dcd28  pop rdx
0000786bc93dcd29  pop rcx
0000786bc93dcd2a  pop rax
0000786bc93dcd2b  add rsp, 0x08
0000786bc93dcd2f  jmp 0x0000786BC93DBB99
0000786bc93dcd34  sub rsp, 0x08
0000786bc93dcd38  push rax
0000786bc93dcd39  push rcx
0000786bc93dcd3a  push rdx
0000786bc93dcd3b  push rdi
0000786bc93dcd3c  push rsi
0000786bc93dcd3d  push r8
0000786bc93dcd3f  push r9
0000786bc93dcd41  push r10
0000786bc93dcd43  push r11
0000786bc93dcd45  sub rsp, 0xF0
0000786bc93dcd4c  vmovaps [rsp], xmm0
0000786bc93dcd51  vmovaps [rsp+0x10], xmm1
0000786bc93dcd57  vmovaps [rsp+0x20], xmm2
0000786bc93dcd5d  vmovaps [rsp+0x30], xmm3
0000786bc93dcd63  vmovaps [rsp+0x40], xmm4
0000786bc93dcd69  vmovaps [rsp+0x50], xmm5
0000786bc93dcd6f  vmovaps [rsp+0x60], xmm6
0000786bc93dcd75  vmovaps [rsp+0x70], xmm7
0000786bc93dcd7b  vmovaps [rsp+0x80], xmm8
0000786bc93dcd84  vmovaps [rsp+0x90], xmm9
0000786bc93dcd8d  vmovaps [rsp+0xA0], xmm11
0000786bc93dcd96  vmovaps [rsp+0xB0], xmm12
0000786bc93dcd9f  vmovaps [rsp+0xC0], xmm13
0000786bc93dcda8  vmovaps [rsp+0xD0], xmm14
0000786bc93dcdb1  vmovaps [rsp+0xE0], xmm15
0000786bc93dcdba  sub rsp, 0x30
0000786bc93dcdbe  movaps [rsp], xmm10
0000786bc93dcdc3  movaps [rsp+0x10], xmm12
0000786bc93dcdc9  movaps [rsp+0x20], xmm11
0000786bc93dcdcf  lea rdi, [rsp]
0000786bc93dcdd3  mov esi, 0x00
0000786bc93dcdd8  mov rax, 0x60810F6F7530
0000786bc93dcde2  call rax
0000786bc93dcde4  movaps xmm10, [rsp]
0000786bc93dcde9  add rsp, 0x30
0000786bc93dcded  vmovaps xmm0, [rsp]
0000786bc93dcdf2  vmovaps xmm1, [rsp+0x10]
0000786bc93dcdf8  vmovaps xmm2, [rsp+0x20]
0000786bc93dcdfe  vmovaps xmm3, [rsp+0x30]
0000786bc93dce04  vmovaps xmm4, [rsp+0x40]
0000786bc93dce0a  vmovaps xmm5, [rsp+0x50]
0000786bc93dce10  vmovaps xmm6, [rsp+0x60]
0000786bc93dce16  vmovaps xmm7, [rsp+0x70]
0000786bc93dce1c  vmovaps xmm8, [rsp+0x80]
0000786bc93dce25  vmovaps xmm9, [rsp+0x90]
0000786bc93dce2e  vmovaps xmm11, [rsp+0xA0]
0000786bc93dce37  vmovaps xmm12, [rsp+0xB0]
0000786bc93dce40  vmovaps xmm13, [rsp+0xC0]
0000786bc93dce49  vmovaps xmm14, [rsp+0xD0]
0000786bc93dce52  vmovaps xmm15, [rsp+0xE0]
0000786bc93dce5b  add rsp, 0xF0
0000786bc93dce62  pop r11
0000786bc93dce64  pop r10
0000786bc93dce66  pop r9
0000786bc93dce68  pop r8
0000786bc93dce6a  pop rsi
0000786bc93dce6b  pop rdi
0000786bc93dce6c  pop rdx
0000786bc93dce6d  pop rcx
0000786bc93dce6e  pop rax
0000786bc93dce6f  add rsp, 0x08
0000786bc93dce73  jmp 0x0000786BC93DBBB3
0000786bc93dce78  sub rsp, 0x08
0000786bc93dce7c  push rax
0000786bc93dce7d  push rcx
0000786bc93dce7e  push rdx
0000786bc93dce7f  push rdi
0000786bc93dce80  push rsi
0000786bc93dce81  push r8
0000786bc93dce83  push r9
0000786bc93dce85  push r10
0000786bc93dce87  push r11
0000786bc93dce89  sub rsp, 0xF0
0000786bc93dce90  vmovaps [rsp], xmm0
0000786bc93dce95  vmovaps [rsp+0x10], xmm1
0000786bc93dce9b  vmovaps [rsp+0x20], xmm2
0000786bc93dcea1  vmovaps [rsp+0x30], xmm3
0000786bc93dcea7  vmovaps [rsp+0x40], xmm4
0000786bc93dcead  vmovaps [rsp+0x50], xmm5
0000786bc93dceb3  vmovaps [rsp+0x60], xmm7
0000786bc93dceb9  vmovaps [rsp+0x70], xmm8
0000786bc93dcebf  vmovaps [rsp+0x80], xmm9
0000786bc93dcec8  vmovaps [rsp+0x90], xmm10
0000786bc93dced1  vmovaps [rsp+0xA0], xmm11
0000786bc93dceda  vmovaps [rsp+0xB0], xmm12
0000786bc93dcee3  vmovaps [rsp+0xC0], xmm13
0000786bc93dceec  vmovaps [rsp+0xD0], xmm14
0000786bc93dcef5  vmovaps [rsp+0xE0], xmm15
0000786bc93dcefe  sub rsp, 0x30
0000786bc93dcf02  movaps [rsp], xmm6
0000786bc93dcf06  movaps [rsp+0x10], xmm12
0000786bc93dcf0c  movaps [rsp+0x20], xmm11
0000786bc93dcf12  lea rdi, [rsp]
0000786bc93dcf16  mov esi, 0x00
0000786bc93dcf1b  mov rax, 0x60810F6F7530
0000786bc93dcf25  call rax
0000786bc93dcf27  movaps xmm6, [rsp]
0000786bc93dcf2b  add rsp, 0x30
0000786bc93dcf2f  vmovaps xmm0, [rsp]
0000786bc93dcf34  vmovaps xmm1, [rsp+0x10]
0000786bc93dcf3a  vmovaps xmm2, [rsp+0x20]
0000786bc93dcf40  vmovaps xmm3, [rsp+0x30]
0000786bc93dcf46  vmovaps xmm4, [rsp+0x40]
0000786bc93dcf4c  vmovaps xmm5, [rsp+0x50]
0000786bc93dcf52  vmovaps xmm7, [rsp+0x60]
0000786bc93dcf58  vmovaps xmm8, [rsp+0x70]
0000786bc93dcf5e  vmovaps xmm9, [rsp+0x80]
0000786bc93dcf67  vmovaps xmm10, [rsp+0x90]
0000786bc93dcf70  vmovaps xmm11, [rsp+0xA0]
0000786bc93dcf79  vmovaps xmm12, [rsp+0xB0]
0000786bc93dcf82  vmovaps xmm13, [rsp+0xC0]
0000786bc93dcf8b  vmovaps xmm14, [rsp+0xD0]
0000786bc93dcf94  vmovaps xmm15, [rsp+0xE0]
0000786bc93dcf9d  add rsp, 0xF0
0000786bc93dcfa4  pop r11
0000786bc93dcfa6  pop r10
0000786bc93dcfa8  pop r9
0000786bc93dcfaa  pop r8
0000786bc93dcfac  pop rsi
0000786bc93dcfad  pop rdi
0000786bc93dcfae  pop rdx
0000786bc93dcfaf  pop rcx
0000786bc93dcfb0  pop rax
0000786bc93dcfb1  add rsp, 0x08
0000786bc93dcfb5  jmp 0x0000786BC93DBBD4
0000786bc93dcfba  sub rsp, 0x08
0000786bc93dcfbe  push rax
0000786bc93dcfbf  push rcx
0000786bc93dcfc0  push rdx
0000786bc93dcfc1  push rdi
0000786bc93dcfc2  push rsi
0000786bc93dcfc3  push r8
0000786bc93dcfc5  push r9
0000786bc93dcfc7  push r10
0000786bc93dcfc9  push r11
0000786bc93dcfcb  sub rsp, 0xF0
0000786bc93dcfd2  vmovaps [rsp], xmm0
0000786bc93dcfd7  vmovaps [rsp+0x10], xmm1
0000786bc93dcfdd  vmovaps [rsp+0x20], xmm2
0000786bc93dcfe3  vmovaps [rsp+0x30], xmm4
0000786bc93dcfe9  vmovaps [rsp+0x40], xmm5
0000786bc93dcfef  vmovaps [rsp+0x50], xmm6
0000786bc93dcff5  vmovaps [rsp+0x60], xmm7
0000786bc93dcffb  vmovaps [rsp+0x70], xmm8
0000786bc93dd001  vmovaps [rsp+0x80], xmm9
0000786bc93dd00a  vmovaps [rsp+0x90], xmm10
0000786bc93dd013  vmovaps [rsp+0xA0], xmm11
0000786bc93dd01c  vmovaps [rsp+0xB0], xmm12
0000786bc93dd025  vmovaps [rsp+0xC0], xmm13
0000786bc93dd02e  vmovaps [rsp+0xD0], xmm14
0000786bc93dd037  vmovaps [rsp+0xE0], xmm15
0000786bc93dd040  sub rsp, 0x30
0000786bc93dd044  movaps [rsp], xmm3
0000786bc93dd048  movaps [rsp+0x10], xmm5
0000786bc93dd04d  movaps [rsp+0x20], xmm4
0000786bc93dd052  lea rdi, [rsp]
0000786bc93dd056  mov esi, 0x00
0000786bc93dd05b  mov rax, 0x60810F6F7530
0000786bc93dd065  call rax
0000786bc93dd067  movaps xmm3, [rsp]
0000786bc93dd06b  add rsp, 0x30
0000786bc93dd06f  vmovaps xmm0, [rsp]
0000786bc93dd074  vmovaps xmm1, [rsp+0x10]
0000786bc93dd07a  vmovaps xmm2, [rsp+0x20]
0000786bc93dd080  vmovaps xmm4, [rsp+0x30]
0000786bc93dd086  vmovaps xmm5, [rsp+0x40]
0000786bc93dd08c  vmovaps xmm6, [rsp+0x50]
0000786bc93dd092  vmovaps xmm7, [rsp+0x60]
0000786bc93dd098  vmovaps xmm8, [rsp+0x70]
0000786bc93dd09e  vmovaps xmm9, [rsp+0x80]
0000786bc93dd0a7  vmovaps xmm10, [rsp+0x90]
0000786bc93dd0b0  vmovaps xmm11, [rsp+0xA0]
0000786bc93dd0b9  vmovaps xmm12, [rsp+0xB0]
0000786bc93dd0c2  vmovaps xmm13, [rsp+0xC0]
0000786bc93dd0cb  vmovaps xmm14, [rsp+0xD0]
0000786bc93dd0d4  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd0dd  add rsp, 0xF0
0000786bc93dd0e4  pop r11
0000786bc93dd0e6  pop r10
0000786bc93dd0e8  pop r9
0000786bc93dd0ea  pop r8
0000786bc93dd0ec  pop rsi
0000786bc93dd0ed  pop rdi
0000786bc93dd0ee  pop rdx
0000786bc93dd0ef  pop rcx
0000786bc93dd0f0  pop rax
0000786bc93dd0f1  add rsp, 0x08
0000786bc93dd0f5  jmp 0x0000786BC93DBC35
0000786bc93dd0fa  sub rsp, 0x08
0000786bc93dd0fe  push rax
0000786bc93dd0ff  push rcx
0000786bc93dd100  push rdx
0000786bc93dd101  push rdi
0000786bc93dd102  push rsi
0000786bc93dd103  push r8
0000786bc93dd105  push r9
0000786bc93dd107  push r10
0000786bc93dd109  push r11
0000786bc93dd10b  sub rsp, 0xF0
0000786bc93dd112  vmovaps [rsp], xmm0
0000786bc93dd117  vmovaps [rsp+0x10], xmm1
0000786bc93dd11d  vmovaps [rsp+0x20], xmm2
0000786bc93dd123  vmovaps [rsp+0x30], xmm3
0000786bc93dd129  vmovaps [rsp+0x40], xmm4
0000786bc93dd12f  vmovaps [rsp+0x50], xmm6
0000786bc93dd135  vmovaps [rsp+0x60], xmm7
0000786bc93dd13b  vmovaps [rsp+0x70], xmm8
0000786bc93dd141  vmovaps [rsp+0x80], xmm9
0000786bc93dd14a  vmovaps [rsp+0x90], xmm10
0000786bc93dd153  vmovaps [rsp+0xA0], xmm11
0000786bc93dd15c  vmovaps [rsp+0xB0], xmm12
0000786bc93dd165  vmovaps [rsp+0xC0], xmm13
0000786bc93dd16e  vmovaps [rsp+0xD0], xmm14
0000786bc93dd177  vmovaps [rsp+0xE0], xmm15
0000786bc93dd180  sub rsp, 0x30
0000786bc93dd184  movaps [rsp], xmm5
0000786bc93dd188  movaps [rsp+0x10], xmm8
0000786bc93dd18e  movaps [rsp+0x20], xmm15
0000786bc93dd194  lea rdi, [rsp]
0000786bc93dd198  mov esi, 0x00
0000786bc93dd19d  mov rax, 0x60810F6F7530
0000786bc93dd1a7  call rax
0000786bc93dd1a9  movaps xmm5, [rsp]
0000786bc93dd1ad  add rsp, 0x30
0000786bc93dd1b1  vmovaps xmm0, [rsp]
0000786bc93dd1b6  vmovaps xmm1, [rsp+0x10]
0000786bc93dd1bc  vmovaps xmm2, [rsp+0x20]
0000786bc93dd1c2  vmovaps xmm3, [rsp+0x30]
0000786bc93dd1c8  vmovaps xmm4, [rsp+0x40]
0000786bc93dd1ce  vmovaps xmm6, [rsp+0x50]
0000786bc93dd1d4  vmovaps xmm7, [rsp+0x60]
0000786bc93dd1da  vmovaps xmm8, [rsp+0x70]
0000786bc93dd1e0  vmovaps xmm9, [rsp+0x80]
0000786bc93dd1e9  vmovaps xmm10, [rsp+0x90]
0000786bc93dd1f2  vmovaps xmm11, [rsp+0xA0]
0000786bc93dd1fb  vmovaps xmm12, [rsp+0xB0]
0000786bc93dd204  vmovaps xmm13, [rsp+0xC0]
0000786bc93dd20d  vmovaps xmm14, [rsp+0xD0]
0000786bc93dd216  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd21f  add rsp, 0xF0
0000786bc93dd226  pop r11
0000786bc93dd228  pop r10
0000786bc93dd22a  pop r9
0000786bc93dd22c  pop r8
0000786bc93dd22e  pop rsi
0000786bc93dd22f  pop rdi
0000786bc93dd230  pop rdx
0000786bc93dd231  pop rcx
0000786bc93dd232  pop rax
0000786bc93dd233  add rsp, 0x08
0000786bc93dd237  jmp 0x0000786BC93DBC73
0000786bc93dd23c  sub rsp, 0x08
0000786bc93dd240  push rax
0000786bc93dd241  push rcx
0000786bc93dd242  push rdx
0000786bc93dd243  push rdi
0000786bc93dd244  push rsi
0000786bc93dd245  push r8
0000786bc93dd247  push r9
0000786bc93dd249  push r10
0000786bc93dd24b  push r11
0000786bc93dd24d  sub rsp, 0xF0
0000786bc93dd254  vmovaps [rsp], xmm0
0000786bc93dd259  vmovaps [rsp+0x10], xmm1
0000786bc93dd25f  vmovaps [rsp+0x20], xmm2
0000786bc93dd265  vmovaps [rsp+0x30], xmm3
0000786bc93dd26b  vmovaps [rsp+0x40], xmm5
0000786bc93dd271  vmovaps [rsp+0x50], xmm6
0000786bc93dd277  vmovaps [rsp+0x60], xmm7
0000786bc93dd27d  vmovaps [rsp+0x70], xmm8
0000786bc93dd283  vmovaps [rsp+0x80], xmm9
0000786bc93dd28c  vmovaps [rsp+0x90], xmm10
0000786bc93dd295  vmovaps [rsp+0xA0], xmm11
0000786bc93dd29e  vmovaps [rsp+0xB0], xmm12
0000786bc93dd2a7  vmovaps [rsp+0xC0], xmm13
0000786bc93dd2b0  vmovaps [rsp+0xD0], xmm14
0000786bc93dd2b9  vmovaps [rsp+0xE0], xmm15
0000786bc93dd2c2  sub rsp, 0x30
0000786bc93dd2c6  movaps [rsp], xmm4
0000786bc93dd2ca  movaps [rsp+0x10], xmm9
0000786bc93dd2d0  movaps [rsp+0x20], xmm8
0000786bc93dd2d6  lea rdi, [rsp]
0000786bc93dd2da  mov esi, 0x00
0000786bc93dd2df  mov rax, 0x60810F6F7530
0000786bc93dd2e9  call rax
0000786bc93dd2eb  movaps xmm4, [rsp]
0000786bc93dd2ef  add rsp, 0x30
0000786bc93dd2f3  vmovaps xmm0, [rsp]
0000786bc93dd2f8  vmovaps xmm1, [rsp+0x10]
0000786bc93dd2fe  vmovaps xmm2, [rsp+0x20]
0000786bc93dd304  vmovaps xmm3, [rsp+0x30]
0000786bc93dd30a  vmovaps xmm5, [rsp+0x40]
0000786bc93dd310  vmovaps xmm6, [rsp+0x50]
0000786bc93dd316  vmovaps xmm7, [rsp+0x60]
0000786bc93dd31c  vmovaps xmm8, [rsp+0x70]
0000786bc93dd322  vmovaps xmm9, [rsp+0x80]
0000786bc93dd32b  vmovaps xmm10, [rsp+0x90]
0000786bc93dd334  vmovaps xmm11, [rsp+0xA0]
0000786bc93dd33d  vmovaps xmm12, [rsp+0xB0]
0000786bc93dd346  vmovaps xmm13, [rsp+0xC0]
0000786bc93dd34f  vmovaps xmm14, [rsp+0xD0]
0000786bc93dd358  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd361  add rsp, 0xF0
0000786bc93dd368  pop r11
0000786bc93dd36a  pop r10
0000786bc93dd36c  pop r9
0000786bc93dd36e  pop r8
0000786bc93dd370  pop rsi
0000786bc93dd371  pop rdi
0000786bc93dd372  pop rdx
0000786bc93dd373  pop rcx
0000786bc93dd374  pop rax
0000786bc93dd375  add rsp, 0x08
0000786bc93dd379  jmp 0x0000786BC93DBC94
0000786bc93dd37e  sub rsp, 0x08
0000786bc93dd382  push rax
0000786bc93dd383  push rcx
0000786bc93dd384  push rdx
0000786bc93dd385  push rdi
0000786bc93dd386  push rsi
0000786bc93dd387  push r8
0000786bc93dd389  push r9
0000786bc93dd38b  push r10
0000786bc93dd38d  push r11
0000786bc93dd38f  sub rsp, 0xF0
0000786bc93dd396  vmovaps [rsp], xmm0
0000786bc93dd39b  vmovaps [rsp+0x10], xmm1
0000786bc93dd3a1  vmovaps [rsp+0x20], xmm2
0000786bc93dd3a7  vmovaps [rsp+0x30], xmm3
0000786bc93dd3ad  vmovaps [rsp+0x40], xmm4
0000786bc93dd3b3  vmovaps [rsp+0x50], xmm5
0000786bc93dd3b9  vmovaps [rsp+0x60], xmm6
0000786bc93dd3bf  vmovaps [rsp+0x70], xmm7
0000786bc93dd3c5  vmovaps [rsp+0x80], xmm8
0000786bc93dd3ce  vmovaps [rsp+0x90], xmm10
0000786bc93dd3d7  vmovaps [rsp+0xA0], xmm11
0000786bc93dd3e0  vmovaps [rsp+0xB0], xmm12
0000786bc93dd3e9  vmovaps [rsp+0xC0], xmm13
0000786bc93dd3f2  vmovaps [rsp+0xD0], xmm14
0000786bc93dd3fb  vmovaps [rsp+0xE0], xmm15
0000786bc93dd404  sub rsp, 0x30
0000786bc93dd408  movaps [rsp], xmm9
0000786bc93dd40d  movaps [rsp+0x10], xmm10
0000786bc93dd413  movaps [rsp+0x20], xmm8
0000786bc93dd419  lea rdi, [rsp]
0000786bc93dd41d  mov esi, 0x00
0000786bc93dd422  mov rax, 0x60810F6F7530
0000786bc93dd42c  call rax
0000786bc93dd42e  movaps xmm9, [rsp]
0000786bc93dd433  add rsp, 0x30
0000786bc93dd437  vmovaps xmm0, [rsp]
0000786bc93dd43c  vmovaps xmm1, [rsp+0x10]
0000786bc93dd442  vmovaps xmm2, [rsp+0x20]
0000786bc93dd448  vmovaps xmm3, [rsp+0x30]
0000786bc93dd44e  vmovaps xmm4, [rsp+0x40]
0000786bc93dd454  vmovaps xmm5, [rsp+0x50]
0000786bc93dd45a  vmovaps xmm6, [rsp+0x60]
0000786bc93dd460  vmovaps xmm7, [rsp+0x70]
0000786bc93dd466  vmovaps xmm8, [rsp+0x80]
0000786bc93dd46f  vmovaps xmm10, [rsp+0x90]
0000786bc93dd478  vmovaps xmm11, [rsp+0xA0]
0000786bc93dd481  vmovaps xmm12, [rsp+0xB0]
0000786bc93dd48a  vmovaps xmm13, [rsp+0xC0]
0000786bc93dd493  vmovaps xmm14, [rsp+0xD0]
0000786bc93dd49c  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd4a5  add rsp, 0xF0
0000786bc93dd4ac  pop r11
0000786bc93dd4ae  pop r10
0000786bc93dd4b0  pop r9
0000786bc93dd4b2  pop r8
0000786bc93dd4b4  pop rsi
0000786bc93dd4b5  pop rdi
0000786bc93dd4b6  pop rdx
0000786bc93dd4b7  pop rcx
0000786bc93dd4b8  pop rax
0000786bc93dd4b9  add rsp, 0x08
0000786bc93dd4bd  jmp 0x0000786BC93DBCAE
0000786bc93dd4c2  call 0x0000786BC92B52F0
0000786bc93dd4c7  jmp 0x0000786BC93DBDC8
0000786bc93dd4cc  call 0x0000786BC92B52F0
0000786bc93dd4d1  jmp 0x0000786BC93DBDDE
0000786bc93dd4d6  sub rsp, 0x08
0000786bc93dd4da  push rax
0000786bc93dd4db  push rcx
0000786bc93dd4dc  push rdx
0000786bc93dd4dd  push rdi
0000786bc93dd4de  push rsi
0000786bc93dd4df  push r8
0000786bc93dd4e1  push r9
0000786bc93dd4e3  push r10
0000786bc93dd4e5  push r11
0000786bc93dd4e7  sub rsp, 0xF0
0000786bc93dd4ee  vmovaps [rsp], xmm0
0000786bc93dd4f3  vmovaps [rsp+0x10], xmm2
0000786bc93dd4f9  vmovaps [rsp+0x20], xmm3
0000786bc93dd4ff  vmovaps [rsp+0x30], xmm4
0000786bc93dd505  vmovaps [rsp+0x40], xmm5
0000786bc93dd50b  vmovaps [rsp+0x50], xmm6
0000786bc93dd511  vmovaps [rsp+0x60], xmm7
0000786bc93dd517  vmovaps [rsp+0x70], xmm8
0000786bc93dd51d  vmovaps [rsp+0x80], xmm9
0000786bc93dd526  vmovaps [rsp+0x90], xmm10
0000786bc93dd52f  vmovaps [rsp+0xA0], xmm11
0000786bc93dd538  vmovaps [rsp+0xB0], xmm12
0000786bc93dd541  vmovaps [rsp+0xC0], xmm13
0000786bc93dd54a  vmovaps [rsp+0xD0], xmm14
0000786bc93dd553  vmovaps [rsp+0xE0], xmm15
0000786bc93dd55c  sub rsp, 0x30
0000786bc93dd560  movaps [rsp], xmm1
0000786bc93dd564  movaps [rsp+0x10], xmm6
0000786bc93dd569  movaps [rsp+0x20], xmm15
0000786bc93dd56f  lea rdi, [rsp]
0000786bc93dd573  mov esi, 0x00
0000786bc93dd578  mov rax, 0x60810F6F7530
0000786bc93dd582  call rax
0000786bc93dd584  movaps xmm1, [rsp]
0000786bc93dd588  add rsp, 0x30
0000786bc93dd58c  vmovaps xmm0, [rsp]
0000786bc93dd591  vmovaps xmm2, [rsp+0x10]
0000786bc93dd597  vmovaps xmm3, [rsp+0x20]
0000786bc93dd59d  vmovaps xmm4, [rsp+0x30]
0000786bc93dd5a3  vmovaps xmm5, [rsp+0x40]
0000786bc93dd5a9  vmovaps xmm6, [rsp+0x50]
0000786bc93dd5af  vmovaps xmm7, [rsp+0x60]
0000786bc93dd5b5  vmovaps xmm8, [rsp+0x70]
0000786bc93dd5bb  vmovaps xmm9, [rsp+0x80]
0000786bc93dd5c4  vmovaps xmm10, [rsp+0x90]
0000786bc93dd5cd  vmovaps xmm11, [rsp+0xA0]
0000786bc93dd5d6  vmovaps xmm12, [rsp+0xB0]
0000786bc93dd5df  vmovaps xmm13, [rsp+0xC0]
0000786bc93dd5e8  vmovaps xmm14, [rsp+0xD0]
0000786bc93dd5f1  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd5fa  add rsp, 0xF0
0000786bc93dd601  pop r11
0000786bc93dd603  pop r10
0000786bc93dd605  pop r9
0000786bc93dd607  pop r8
0000786bc93dd609  pop rsi
0000786bc93dd60a  pop rdi
0000786bc93dd60b  pop rdx
0000786bc93dd60c  pop rcx
0000786bc93dd60d  pop rax
0000786bc93dd60e  add rsp, 0x08
0000786bc93dd612  jmp 0x0000786BC93DBE1B
0000786bc93dd617  call 0x0000786BC92C4620
0000786bc93dd61c  jmp 0x0000786BC93DBE28
0000786bc93dd621  sub rsp, 0x08
0000786bc93dd625  push rax
0000786bc93dd626  push rcx
0000786bc93dd627  push rdx
0000786bc93dd628  push rdi
0000786bc93dd629  push rsi
0000786bc93dd62a  push r8
0000786bc93dd62c  push r9
0000786bc93dd62e  push r10
0000786bc93dd630  push r11
0000786bc93dd632  sub rsp, 0xF0
0000786bc93dd639  vmovaps [rsp], xmm0
0000786bc93dd63e  vmovaps [rsp+0x10], xmm1
0000786bc93dd644  vmovaps [rsp+0x20], xmm2
0000786bc93dd64a  vmovaps [rsp+0x30], xmm3
0000786bc93dd650  vmovaps [rsp+0x40], xmm4
0000786bc93dd656  vmovaps [rsp+0x50], xmm5
0000786bc93dd65c  vmovaps [rsp+0x60], xmm6
0000786bc93dd662  vmovaps [rsp+0x70], xmm7
0000786bc93dd668  vmovaps [rsp+0x80], xmm8
0000786bc93dd671  vmovaps [rsp+0x90], xmm9
0000786bc93dd67a  vmovaps [rsp+0xA0], xmm10
0000786bc93dd683  vmovaps [rsp+0xB0], xmm11
0000786bc93dd68c  vmovaps [rsp+0xC0], xmm12
0000786bc93dd695  vmovaps [rsp+0xD0], xmm13
0000786bc93dd69e  vmovaps [rsp+0xE0], xmm15
0000786bc93dd6a7  sub rsp, 0x30
0000786bc93dd6ab  movaps [rsp], xmm14
0000786bc93dd6b0  movaps [rsp+0x10], xmm4
0000786bc93dd6b5  movaps [rsp+0x20], xmm3
0000786bc93dd6ba  lea rdi, [rsp]
0000786bc93dd6be  mov esi, 0x00
0000786bc93dd6c3  mov rax, 0x60810F6F7530
0000786bc93dd6cd  call rax
0000786bc93dd6cf  movaps xmm14, [rsp]
0000786bc93dd6d4  add rsp, 0x30
0000786bc93dd6d8  vmovaps xmm0, [rsp]
0000786bc93dd6dd  vmovaps xmm1, [rsp+0x10]
0000786bc93dd6e3  vmovaps xmm2, [rsp+0x20]
0000786bc93dd6e9  vmovaps xmm3, [rsp+0x30]
0000786bc93dd6ef  vmovaps xmm4, [rsp+0x40]
0000786bc93dd6f5  vmovaps xmm5, [rsp+0x50]
0000786bc93dd6fb  vmovaps xmm6, [rsp+0x60]
0000786bc93dd701  vmovaps xmm7, [rsp+0x70]
0000786bc93dd707  vmovaps xmm8, [rsp+0x80]
0000786bc93dd710  vmovaps xmm9, [rsp+0x90]
0000786bc93dd719  vmovaps xmm10, [rsp+0xA0]
0000786bc93dd722  vmovaps xmm11, [rsp+0xB0]
0000786bc93dd72b  vmovaps xmm12, [rsp+0xC0]
0000786bc93dd734  vmovaps xmm13, [rsp+0xD0]
0000786bc93dd73d  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd746  add rsp, 0xF0
0000786bc93dd74d  pop r11
0000786bc93dd74f  pop r10
0000786bc93dd751  pop r9
0000786bc93dd753  pop r8
0000786bc93dd755  pop rsi
0000786bc93dd756  pop rdi
0000786bc93dd757  pop rdx
0000786bc93dd758  pop rcx
0000786bc93dd759  pop rax
0000786bc93dd75a  add rsp, 0x08
0000786bc93dd75e  jmp 0x0000786BC93DBE42
0000786bc93dd763  sub rsp, 0x08
0000786bc93dd767  push rax
0000786bc93dd768  push rcx
0000786bc93dd769  push rdx
0000786bc93dd76a  push rdi
0000786bc93dd76b  push rsi
0000786bc93dd76c  push r8
0000786bc93dd76e  push r9
0000786bc93dd770  push r10
0000786bc93dd772  push r11
0000786bc93dd774  sub rsp, 0xF0
0000786bc93dd77b  vmovaps [rsp], xmm0
0000786bc93dd780  vmovaps [rsp+0x10], xmm1
0000786bc93dd786  vmovaps [rsp+0x20], xmm2
0000786bc93dd78c  vmovaps [rsp+0x30], xmm3
0000786bc93dd792  vmovaps [rsp+0x40], xmm4
0000786bc93dd798  vmovaps [rsp+0x50], xmm5
0000786bc93dd79e  vmovaps [rsp+0x60], xmm7
0000786bc93dd7a4  vmovaps [rsp+0x70], xmm8
0000786bc93dd7aa  vmovaps [rsp+0x80], xmm9
0000786bc93dd7b3  vmovaps [rsp+0x90], xmm10
0000786bc93dd7bc  vmovaps [rsp+0xA0], xmm11
0000786bc93dd7c5  vmovaps [rsp+0xB0], xmm12
0000786bc93dd7ce  vmovaps [rsp+0xC0], xmm13
0000786bc93dd7d7  vmovaps [rsp+0xD0], xmm14
0000786bc93dd7e0  vmovaps [rsp+0xE0], xmm15
0000786bc93dd7e9  sub rsp, 0x30
0000786bc93dd7ed  movaps [rsp], xmm6
0000786bc93dd7f1  movaps [rsp+0x10], xmm9
0000786bc93dd7f7  movaps [rsp+0x20], xmm7
0000786bc93dd7fc  lea rdi, [rsp]
0000786bc93dd800  mov esi, 0x00
0000786bc93dd805  mov rax, 0x60810F6F7530
0000786bc93dd80f  call rax
0000786bc93dd811  movaps xmm6, [rsp]
0000786bc93dd815  add rsp, 0x30
0000786bc93dd819  vmovaps xmm0, [rsp]
0000786bc93dd81e  vmovaps xmm1, [rsp+0x10]
0000786bc93dd824  vmovaps xmm2, [rsp+0x20]
0000786bc93dd82a  vmovaps xmm3, [rsp+0x30]
0000786bc93dd830  vmovaps xmm4, [rsp+0x40]
0000786bc93dd836  vmovaps xmm5, [rsp+0x50]
0000786bc93dd83c  vmovaps xmm7, [rsp+0x60]
0000786bc93dd842  vmovaps xmm8, [rsp+0x70]
0000786bc93dd848  vmovaps xmm9, [rsp+0x80]
0000786bc93dd851  vmovaps xmm10, [rsp+0x90]
0000786bc93dd85a  vmovaps xmm11, [rsp+0xA0]
0000786bc93dd863  vmovaps xmm12, [rsp+0xB0]
0000786bc93dd86c  vmovaps xmm13, [rsp+0xC0]
0000786bc93dd875  vmovaps xmm14, [rsp+0xD0]
0000786bc93dd87e  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd887  add rsp, 0xF0
0000786bc93dd88e  pop r11
0000786bc93dd890  pop r10
0000786bc93dd892  pop r9
0000786bc93dd894  pop r8
0000786bc93dd896  pop rsi
0000786bc93dd897  pop rdi
0000786bc93dd898  pop rdx
0000786bc93dd899  pop rcx
0000786bc93dd89a  pop rax
0000786bc93dd89b  add rsp, 0x08
0000786bc93dd89f  jmp 0x0000786BC93DBE5A
0000786bc93dd8a4  sub rsp, 0x08
0000786bc93dd8a8  push rax
0000786bc93dd8a9  push rcx
0000786bc93dd8aa  push rdx
0000786bc93dd8ab  push rdi
0000786bc93dd8ac  push rsi
0000786bc93dd8ad  push r8
0000786bc93dd8af  push r9
0000786bc93dd8b1  push r10
0000786bc93dd8b3  push r11
0000786bc93dd8b5  sub rsp, 0xF0
0000786bc93dd8bc  vmovaps [rsp], xmm0
0000786bc93dd8c1  vmovaps [rsp+0x10], xmm1
0000786bc93dd8c7  vmovaps [rsp+0x20], xmm2
0000786bc93dd8cd  vmovaps [rsp+0x30], xmm3
0000786bc93dd8d3  vmovaps [rsp+0x40], xmm4
0000786bc93dd8d9  vmovaps [rsp+0x50], xmm5
0000786bc93dd8df  vmovaps [rsp+0x60], xmm6
0000786bc93dd8e5  vmovaps [rsp+0x70], xmm8
0000786bc93dd8eb  vmovaps [rsp+0x80], xmm9
0000786bc93dd8f4  vmovaps [rsp+0x90], xmm10
0000786bc93dd8fd  vmovaps [rsp+0xA0], xmm11
0000786bc93dd906  vmovaps [rsp+0xB0], xmm12
0000786bc93dd90f  vmovaps [rsp+0xC0], xmm13
0000786bc93dd918  vmovaps [rsp+0xD0], xmm14
0000786bc93dd921  vmovaps [rsp+0xE0], xmm15
0000786bc93dd92a  sub rsp, 0x30
0000786bc93dd92e  movaps [rsp], xmm7
0000786bc93dd932  movaps [rsp+0x10], xmm4
0000786bc93dd937  movaps [rsp+0x20], xmm9
0000786bc93dd93d  lea rdi, [rsp]
0000786bc93dd941  mov esi, 0x00
0000786bc93dd946  mov rax, 0x60810F6F7530
0000786bc93dd950  call rax
0000786bc93dd952  movaps xmm7, [rsp]
0000786bc93dd956  add rsp, 0x30
0000786bc93dd95a  vmovaps xmm0, [rsp]
0000786bc93dd95f  vmovaps xmm1, [rsp+0x10]
0000786bc93dd965  vmovaps xmm2, [rsp+0x20]
0000786bc93dd96b  vmovaps xmm3, [rsp+0x30]
0000786bc93dd971  vmovaps xmm4, [rsp+0x40]
0000786bc93dd977  vmovaps xmm5, [rsp+0x50]
0000786bc93dd97d  vmovaps xmm6, [rsp+0x60]
0000786bc93dd983  vmovaps xmm8, [rsp+0x70]
0000786bc93dd989  vmovaps xmm9, [rsp+0x80]
0000786bc93dd992  vmovaps xmm10, [rsp+0x90]
0000786bc93dd99b  vmovaps xmm11, [rsp+0xA0]
0000786bc93dd9a4  vmovaps xmm12, [rsp+0xB0]
0000786bc93dd9ad  vmovaps xmm13, [rsp+0xC0]
0000786bc93dd9b6  vmovaps xmm14, [rsp+0xD0]
0000786bc93dd9bf  vmovaps xmm15, [rsp+0xE0]
0000786bc93dd9c8  add rsp, 0xF0
0000786bc93dd9cf  pop r11
0000786bc93dd9d1  pop r10
0000786bc93dd9d3  pop r9
0000786bc93dd9d5  pop r8
0000786bc93dd9d7  pop rsi
0000786bc93dd9d8  pop rdi
0000786bc93dd9d9  pop rdx
0000786bc93dd9da  pop rcx
0000786bc93dd9db  pop rax
0000786bc93dd9dc  add rsp, 0x08
0000786bc93dd9e0  jmp 0x0000786BC93DBE87
0000786bc93dd9e5  sub rsp, 0x08
0000786bc93dd9e9  push rax
0000786bc93dd9ea  push rcx
0000786bc93dd9eb  push rdx
0000786bc93dd9ec  push rdi
0000786bc93dd9ed  push rsi
0000786bc93dd9ee  push r8
0000786bc93dd9f0  push r9
0000786bc93dd9f2  push r10
0000786bc93dd9f4  push r11
0000786bc93dd9f6  sub rsp, 0xF0
0000786bc93dd9fd  vmovaps [rsp], xmm0
0000786bc93dda02  vmovaps [rsp+0x10], xmm1
0000786bc93dda08  vmovaps [rsp+0x20], xmm2
0000786bc93dda0e  vmovaps [rsp+0x30], xmm3
0000786bc93dda14  vmovaps [rsp+0x40], xmm5
0000786bc93dda1a  vmovaps [rsp+0x50], xmm6
0000786bc93dda20  vmovaps [rsp+0x60], xmm7
0000786bc93dda26  vmovaps [rsp+0x70], xmm8
0000786bc93dda2c  vmovaps [rsp+0x80], xmm9
0000786bc93dda35  vmovaps [rsp+0x90], xmm10
0000786bc93dda3e  vmovaps [rsp+0xA0], xmm11
0000786bc93dda47  vmovaps [rsp+0xB0], xmm12
0000786bc93dda50  vmovaps [rsp+0xC0], xmm13
0000786bc93dda59  vmovaps [rsp+0xD0], xmm14
0000786bc93dda62  vmovaps [rsp+0xE0], xmm15
0000786bc93dda6b  sub rsp, 0x30
0000786bc93dda6f  movaps [rsp], xmm4
0000786bc93dda73  movaps [rsp+0x10], xmm15
0000786bc93dda79  movaps [rsp+0x20], xmm9
0000786bc93dda7f  lea rdi, [rsp]
0000786bc93dda83  mov esi, 0x00
0000786bc93dda88  mov rax, 0x60810F6F7530
0000786bc93dda92  call rax
0000786bc93dda94  movaps xmm4, [rsp]
0000786bc93dda98  add rsp, 0x30
0000786bc93dda9c  vmovaps xmm0, [rsp]
0000786bc93ddaa1  vmovaps xmm1, [rsp+0x10]
0000786bc93ddaa7  vmovaps xmm2, [rsp+0x20]
0000786bc93ddaad  vmovaps xmm3, [rsp+0x30]
0000786bc93ddab3  vmovaps xmm5, [rsp+0x40]
0000786bc93ddab9  vmovaps xmm6, [rsp+0x50]
0000786bc93ddabf  vmovaps xmm7, [rsp+0x60]
0000786bc93ddac5  vmovaps xmm8, [rsp+0x70]
0000786bc93ddacb  vmovaps xmm9, [rsp+0x80]
0000786bc93ddad4  vmovaps xmm10, [rsp+0x90]
0000786bc93ddadd  vmovaps xmm11, [rsp+0xA0]
0000786bc93ddae6  vmovaps xmm12, [rsp+0xB0]
0000786bc93ddaef  vmovaps xmm13, [rsp+0xC0]
0000786bc93ddaf8  vmovaps xmm14, [rsp+0xD0]
0000786bc93ddb01  vmovaps xmm15, [rsp+0xE0]
0000786bc93ddb0a  add rsp, 0xF0
0000786bc93ddb11  pop r11
0000786bc93ddb13  pop r10
0000786bc93ddb15  pop r9
0000786bc93ddb17  pop r8
0000786bc93ddb19  pop rsi
0000786bc93ddb1a  pop rdi
0000786bc93ddb1b  pop rdx
0000786bc93ddb1c  pop rcx
0000786bc93ddb1d  pop rax
0000786bc93ddb1e  add rsp, 0x08
0000786bc93ddb22  jmp 0x0000786BC93DBEAC
0000786bc93ddb27  call 0x0000786BC92C4620
0000786bc93ddb2c  jmp 0x0000786BC93DBEB9
0000786bc93ddb31  sub rsp, 0x08
0000786bc93ddb35  push rax
0000786bc93ddb36  push rcx
0000786bc93ddb37  push rdx
0000786bc93ddb38  push rdi
0000786bc93ddb39  push rsi
0000786bc93ddb3a  push r8
0000786bc93ddb3c  push r9
0000786bc93ddb3e  push r10
0000786bc93ddb40  push r11
0000786bc93ddb42  sub rsp, 0xF0
0000786bc93ddb49  vmovaps [rsp], xmm0
0000786bc93ddb4e  vmovaps [rsp+0x10], xmm1
0000786bc93ddb54  vmovaps [rsp+0x20], xmm2
0000786bc93ddb5a  vmovaps [rsp+0x30], xmm4
0000786bc93ddb60  vmovaps [rsp+0x40], xmm5
0000786bc93ddb66  vmovaps [rsp+0x50], xmm6
0000786bc93ddb6c  vmovaps [rsp+0x60], xmm7
0000786bc93ddb72  vmovaps [rsp+0x70], xmm8
0000786bc93ddb78  vmovaps [rsp+0x80], xmm9
0000786bc93ddb81  vmovaps [rsp+0x90], xmm10
0000786bc93ddb8a  vmovaps [rsp+0xA0], xmm11
0000786bc93ddb93  vmovaps [rsp+0xB0], xmm12
0000786bc93ddb9c  vmovaps [rsp+0xC0], xmm13
0000786bc93ddba5  vmovaps [rsp+0xD0], xmm14
0000786bc93ddbae  vmovaps [rsp+0xE0], xmm15
0000786bc93ddbb7  sub rsp, 0x30
0000786bc93ddbbb  movaps [rsp], xmm3
0000786bc93ddbbf  movaps [rsp+0x10], xmm1
0000786bc93ddbc4  movaps [rsp+0x20], xmm9
0000786bc93ddbca  lea rdi, [rsp]
0000786bc93ddbce  mov esi, 0x00
0000786bc93ddbd3  mov rax, 0x60810F6F7530
0000786bc93ddbdd  call rax
0000786bc93ddbdf  movaps xmm3, [rsp]
0000786bc93ddbe3  add rsp, 0x30
0000786bc93ddbe7  vmovaps xmm0, [rsp]
0000786bc93ddbec  vmovaps xmm1, [rsp+0x10]
0000786bc93ddbf2  vmovaps xmm2, [rsp+0x20]
0000786bc93ddbf8  vmovaps xmm4, [rsp+0x30]
0000786bc93ddbfe  vmovaps xmm5, [rsp+0x40]
0000786bc93ddc04  vmovaps xmm6, [rsp+0x50]
0000786bc93ddc0a  vmovaps xmm7, [rsp+0x60]
0000786bc93ddc10  vmovaps xmm8, [rsp+0x70]
0000786bc93ddc16  vmovaps xmm9, [rsp+0x80]
0000786bc93ddc1f  vmovaps xmm10, [rsp+0x90]
0000786bc93ddc28  vmovaps xmm11, [rsp+0xA0]
0000786bc93ddc31  vmovaps xmm12, [rsp+0xB0]
0000786bc93ddc3a  vmovaps xmm13, [rsp+0xC0]
0000786bc93ddc43  vmovaps xmm14, [rsp+0xD0]
0000786bc93ddc4c  vmovaps xmm15, [rsp+0xE0]
0000786bc93ddc55  add rsp, 0xF0
0000786bc93ddc5c  pop r11
0000786bc93ddc5e  pop r10
0000786bc93ddc60  pop r9
0000786bc93ddc62  pop r8
0000786bc93ddc64  pop rsi
0000786bc93ddc65  pop rdi
0000786bc93ddc66  pop rdx
0000786bc93ddc67  pop rcx
0000786bc93ddc68  pop rax
0000786bc93ddc69  add rsp, 0x08
0000786bc93ddc6d  jmp 0x0000786BC93DBEF6
0000786bc93ddc72  sub rsp, 0x08
0000786bc93ddc76  push rax
0000786bc93ddc77  push rcx
0000786bc93ddc78  push rdx
0000786bc93ddc79  push rdi
0000786bc93ddc7a  push rsi
0000786bc93ddc7b  push r8
0000786bc93ddc7d  push r9
0000786bc93ddc7f  push r10
0000786bc93ddc81  push r11
0000786bc93ddc83  sub rsp, 0xF0
0000786bc93ddc8a  vmovaps [rsp], xmm0
0000786bc93ddc8f  vmovaps [rsp+0x10], xmm2
0000786bc93ddc95  vmovaps [rsp+0x20], xmm3
0000786bc93ddc9b  vmovaps [rsp+0x30], xmm4
0000786bc93ddca1  vmovaps [rsp+0x40], xmm5
0000786bc93ddca7  vmovaps [rsp+0x50], xmm6
0000786bc93ddcad  vmovaps [rsp+0x60], xmm7
0000786bc93ddcb3  vmovaps [rsp+0x70], xmm8
0000786bc93ddcb9  vmovaps [rsp+0x80], xmm9
0000786bc93ddcc2  vmovaps [rsp+0x90], xmm10
0000786bc93ddccb  vmovaps [rsp+0xA0], xmm11
0000786bc93ddcd4  vmovaps [rsp+0xB0], xmm12
0000786bc93ddcdd  vmovaps [rsp+0xC0], xmm13
0000786bc93ddce6  vmovaps [rsp+0xD0], xmm14
0000786bc93ddcef  vmovaps [rsp+0xE0], xmm15
0000786bc93ddcf8  sub rsp, 0x30
0000786bc93ddcfc  movaps [rsp], xmm1
0000786bc93ddd00  movaps [rsp+0x10], xmm15
0000786bc93ddd06  movaps [rsp+0x20], xmm9
0000786bc93ddd0c  lea rdi, [rsp]
0000786bc93ddd10  mov esi, 0x00
0000786bc93ddd15  mov rax, 0x60810F6F7530
0000786bc93ddd1f  call rax
0000786bc93ddd21  movaps xmm1, [rsp]
0000786bc93ddd25  add rsp, 0x30
0000786bc93ddd29  vmovaps xmm0, [rsp]
0000786bc93ddd2e  vmovaps xmm2, [rsp+0x10]
0000786bc93ddd34  vmovaps xmm3, [rsp+0x20]
0000786bc93ddd3a  vmovaps xmm4, [rsp+0x30]
0000786bc93ddd40  vmovaps xmm5, [rsp+0x40]
0000786bc93ddd46  vmovaps xmm6, [rsp+0x50]
0000786bc93ddd4c  vmovaps xmm7, [rsp+0x60]
0000786bc93ddd52  vmovaps xmm8, [rsp+0x70]
0000786bc93ddd58  vmovaps xmm9, [rsp+0x80]
0000786bc93ddd61  vmovaps xmm10, [rsp+0x90]
0000786bc93ddd6a  vmovaps xmm11, [rsp+0xA0]
0000786bc93ddd73  vmovaps xmm12, [rsp+0xB0]
0000786bc93ddd7c  vmovaps xmm13, [rsp+0xC0]
0000786bc93ddd85  vmovaps xmm14, [rsp+0xD0]
0000786bc93ddd8e  vmovaps xmm15, [rsp+0xE0]
0000786bc93ddd97  add rsp, 0xF0
0000786bc93ddd9e  pop r11
0000786bc93ddda0  pop r10
0000786bc93ddda2  pop r9
0000786bc93ddda4  pop r8
0000786bc93ddda6  pop rsi
0000786bc93ddda7  pop rdi
0000786bc93ddda8  pop rdx
0000786bc93ddda9  pop rcx
0000786bc93dddaa  pop rax
0000786bc93dddab  add rsp, 0x08
0000786bc93dddaf  jmp 0x0000786BC93DBF7E
0000786bc93dddb4  call 0x0000786BC92C4620
0000786bc93dddb9  jmp 0x0000786BC93DBF8B
0000786bc93dddbe  sub rsp, 0x08
0000786bc93dddc2  push rax
0000786bc93dddc3  push rcx
0000786bc93dddc4  push rdx
0000786bc93dddc5  push rdi
0000786bc93dddc6  push rsi
0000786bc93dddc7  push r8
0000786bc93dddc9  push r9
0000786bc93dddcb  push r10
0000786bc93dddcd  push r11
0000786bc93dddcf  sub rsp, 0xF0
0000786bc93dddd6  vmovaps [rsp], xmm0
0000786bc93ddddb  vmovaps [rsp+0x10], xmm2
0000786bc93ddde1  vmovaps [rsp+0x20], xmm3
0000786bc93ddde7  vmovaps [rsp+0x30], xmm4
0000786bc93ddded  vmovaps [rsp+0x40], xmm5
0000786bc93dddf3  vmovaps [rsp+0x50], xmm6
0000786bc93dddf9  vmovaps [rsp+0x60], xmm7
0000786bc93dddff  vmovaps [rsp+0x70], xmm8
0000786bc93dde05  vmovaps [rsp+0x80], xmm9
0000786bc93dde0e  vmovaps [rsp+0x90], xmm10
0000786bc93dde17  vmovaps [rsp+0xA0], xmm11
0000786bc93dde20  vmovaps [rsp+0xB0], xmm12
0000786bc93dde29  vmovaps [rsp+0xC0], xmm13
0000786bc93dde32  vmovaps [rsp+0xD0], xmm14
0000786bc93dde3b  vmovaps [rsp+0xE0], xmm15
0000786bc93dde44  sub rsp, 0x30
0000786bc93dde48  movaps [rsp], xmm1
0000786bc93dde4c  movaps [rsp+0x10], xmm5
0000786bc93dde51  movaps [rsp+0x20], xmm7
0000786bc93dde56  lea rdi, [rsp]
0000786bc93dde5a  mov esi, 0x00
0000786bc93dde5f  mov rax, 0x60810F6F7530
0000786bc93dde69  call rax
0000786bc93dde6b  movaps xmm1, [rsp]
0000786bc93dde6f  add rsp, 0x30
0000786bc93dde73  vmovaps xmm0, [rsp]
0000786bc93dde78  vmovaps xmm2, [rsp+0x10]
0000786bc93dde7e  vmovaps xmm3, [rsp+0x20]
0000786bc93dde84  vmovaps xmm4, [rsp+0x30]
0000786bc93dde8a  vmovaps xmm5, [rsp+0x40]
0000786bc93dde90  vmovaps xmm6, [rsp+0x50]
0000786bc93dde96  vmovaps xmm7, [rsp+0x60]
0000786bc93dde9c  vmovaps xmm8, [rsp+0x70]
0000786bc93ddea2  vmovaps xmm9, [rsp+0x80]
0000786bc93ddeab  vmovaps xmm10, [rsp+0x90]
0000786bc93ddeb4  vmovaps xmm11, [rsp+0xA0]
0000786bc93ddebd  vmovaps xmm12, [rsp+0xB0]
0000786bc93ddec6  vmovaps xmm13, [rsp+0xC0]
0000786bc93ddecf  vmovaps xmm14, [rsp+0xD0]
0000786bc93dded8  vmovaps xmm15, [rsp+0xE0]
0000786bc93ddee1  add rsp, 0xF0
0000786bc93ddee8  pop r11
0000786bc93ddeea  pop r10
0000786bc93ddeec  pop r9
0000786bc93ddeee  pop r8
0000786bc93ddef0  pop rsi
0000786bc93ddef1  pop rdi
0000786bc93ddef2  pop rdx
0000786bc93ddef3  pop rcx
0000786bc93ddef4  pop rax
0000786bc93ddef5  add rsp, 0x08
0000786bc93ddef9  jmp 0x0000786BC93DC030
0000786bc93ddefe  sub rsp, 0x08
0000786bc93ddf02  push rax
0000786bc93ddf03  push rcx
0000786bc93ddf04  push rdx
0000786bc93ddf05  push rdi
0000786bc93ddf06  push rsi
0000786bc93ddf07  push r8
0000786bc93ddf09  push r9
0000786bc93ddf0b  push r10
0000786bc93ddf0d  push r11
0000786bc93ddf0f  sub rsp, 0xF0
0000786bc93ddf16  vmovaps [rsp], xmm0
0000786bc93ddf1b  vmovaps [rsp+0x10], xmm1
0000786bc93ddf21  vmovaps [rsp+0x20], xmm2
0000786bc93ddf27  vmovaps [rsp+0x30], xmm3
0000786bc93ddf2d  vmovaps [rsp+0x40], xmm4
0000786bc93ddf33  vmovaps [rsp+0x50], xmm5
0000786bc93ddf39  vmovaps [rsp+0x60], xmm6
0000786bc93ddf3f  vmovaps [rsp+0x70], xmm8
0000786bc93ddf45  vmovaps [rsp+0x80], xmm9
0000786bc93ddf4e  vmovaps [rsp+0x90], xmm10
0000786bc93ddf57  vmovaps [rsp+0xA0], xmm11
0000786bc93ddf60  vmovaps [rsp+0xB0], xmm12
0000786bc93ddf69  vmovaps [rsp+0xC0], xmm13
0000786bc93ddf72  vmovaps [rsp+0xD0], xmm14
0000786bc93ddf7b  vmovaps [rsp+0xE0], xmm15
0000786bc93ddf84  sub rsp, 0x30
0000786bc93ddf88  movaps [rsp], xmm7
0000786bc93ddf8c  movaps [rsp+0x10], xmm5
0000786bc93ddf91  movaps [rsp+0x20], xmm15
0000786bc93ddf97  lea rdi, [rsp]
0000786bc93ddf9b  mov esi, 0x00
0000786bc93ddfa0  mov rax, 0x60810F6F7530
0000786bc93ddfaa  call rax
0000786bc93ddfac  movaps xmm7, [rsp]
0000786bc93ddfb0  add rsp, 0x30
0000786bc93ddfb4  vmovaps xmm0, [rsp]
0000786bc93ddfb9  vmovaps xmm1, [rsp+0x10]
0000786bc93ddfbf  vmovaps xmm2, [rsp+0x20]
0000786bc93ddfc5  vmovaps xmm3, [rsp+0x30]
0000786bc93ddfcb  vmovaps xmm4, [rsp+0x40]
0000786bc93ddfd1  vmovaps xmm5, [rsp+0x50]
0000786bc93ddfd7  vmovaps xmm6, [rsp+0x60]
0000786bc93ddfdd  vmovaps xmm8, [rsp+0x70]
0000786bc93ddfe3  vmovaps xmm9, [rsp+0x80]
0000786bc93ddfec  vmovaps xmm10, [rsp+0x90]
0000786bc93ddff5  vmovaps xmm11, [rsp+0xA0]
0000786bc93ddffe  vmovaps xmm12, [rsp+0xB0]
0000786bc93de007  vmovaps xmm13, [rsp+0xC0]
0000786bc93de010  vmovaps xmm14, [rsp+0xD0]
0000786bc93de019  vmovaps xmm15, [rsp+0xE0]
0000786bc93de022  add rsp, 0xF0
0000786bc93de029  pop r11
0000786bc93de02b  pop r10
0000786bc93de02d  pop r9
0000786bc93de02f  pop r8
0000786bc93de031  pop rsi
0000786bc93de032  pop rdi
0000786bc93de033  pop rdx
0000786bc93de034  pop rcx
0000786bc93de035  pop rax
0000786bc93de036  add rsp, 0x08
0000786bc93de03a  jmp 0x0000786BC93DC066
0000786bc93de03f  call 0x0000786BC92B52F0
0000786bc93de044  jmp 0x0000786BC93DC073
0000786bc93de049  sub rsp, 0x08
0000786bc93de04d  push rax
0000786bc93de04e  push rcx
0000786bc93de04f  push rdx
0000786bc93de050  push rdi
0000786bc93de051  push rsi
0000786bc93de052  push r8
0000786bc93de054  push r9
0000786bc93de056  push r10
0000786bc93de058  push r11
0000786bc93de05a  sub rsp, 0xF0
0000786bc93de061  vmovaps [rsp], xmm0
0000786bc93de066  vmovaps [rsp+0x10], xmm1
0000786bc93de06c  vmovaps [rsp+0x20], xmm2
0000786bc93de072  vmovaps [rsp+0x30], xmm3
0000786bc93de078  vmovaps [rsp+0x40], xmm4
0000786bc93de07e  vmovaps [rsp+0x50], xmm5
0000786bc93de084  vmovaps [rsp+0x60], xmm6
0000786bc93de08a  vmovaps [rsp+0x70], xmm7
0000786bc93de090  vmovaps [rsp+0x80], xmm8
0000786bc93de099  vmovaps [rsp+0x90], xmm9
0000786bc93de0a2  vmovaps [rsp+0xA0], xmm10
0000786bc93de0ab  vmovaps [rsp+0xB0], xmm11
0000786bc93de0b4  vmovaps [rsp+0xC0], xmm12
0000786bc93de0bd  vmovaps [rsp+0xD0], xmm13
0000786bc93de0c6  vmovaps [rsp+0xE0], xmm14
0000786bc93de0cf  sub rsp, 0x30
0000786bc93de0d3  movaps [rsp], xmm15
0000786bc93de0d8  movaps [rsp+0x10], xmm5
0000786bc93de0dd  movaps [rsp+0x20], xmm3
0000786bc93de0e2  lea rdi, [rsp]
0000786bc93de0e6  mov esi, 0x00
0000786bc93de0eb  mov rax, 0x60810F6F7530
0000786bc93de0f5  call rax
0000786bc93de0f7  movaps xmm15, [rsp]
0000786bc93de0fc  add rsp, 0x30
0000786bc93de100  vmovaps xmm0, [rsp]
0000786bc93de105  vmovaps xmm1, [rsp+0x10]
0000786bc93de10b  vmovaps xmm2, [rsp+0x20]
0000786bc93de111  vmovaps xmm3, [rsp+0x30]
0000786bc93de117  vmovaps xmm4, [rsp+0x40]
0000786bc93de11d  vmovaps xmm5, [rsp+0x50]
0000786bc93de123  vmovaps xmm6, [rsp+0x60]
0000786bc93de129  vmovaps xmm7, [rsp+0x70]
0000786bc93de12f  vmovaps xmm8, [rsp+0x80]
0000786bc93de138  vmovaps xmm9, [rsp+0x90]
0000786bc93de141  vmovaps xmm10, [rsp+0xA0]
0000786bc93de14a  vmovaps xmm11, [rsp+0xB0]
0000786bc93de153  vmovaps xmm12, [rsp+0xC0]
0000786bc93de15c  vmovaps xmm13, [rsp+0xD0]
0000786bc93de165  vmovaps xmm14, [rsp+0xE0]
0000786bc93de16e  add rsp, 0xF0
0000786bc93de175  pop r11
0000786bc93de177  pop r10
0000786bc93de179  pop r9
0000786bc93de17b  pop r8
0000786bc93de17d  pop rsi
0000786bc93de17e  pop rdi
0000786bc93de17f  pop rdx
0000786bc93de180  pop rcx
0000786bc93de181  pop rax
0000786bc93de182  add rsp, 0x08
0000786bc93de186  jmp 0x0000786BC93DC099
0000786bc93de18b  sub rsp, 0x08
0000786bc93de18f  push rax
0000786bc93de190  push rcx
0000786bc93de191  push rdx
0000786bc93de192  push rdi
0000786bc93de193  push rsi
0000786bc93de194  push r8
0000786bc93de196  push r9
0000786bc93de198  push r10
0000786bc93de19a  push r11
0000786bc93de19c  sub rsp, 0xF0
0000786bc93de1a3  vmovaps [rsp], xmm0
0000786bc93de1a8  vmovaps [rsp+0x10], xmm2
0000786bc93de1ae  vmovaps [rsp+0x20], xmm3
0000786bc93de1b4  vmovaps [rsp+0x30], xmm4
0000786bc93de1ba  vmovaps [rsp+0x40], xmm5
0000786bc93de1c0  vmovaps [rsp+0x50], xmm6
0000786bc93de1c6  vmovaps [rsp+0x60], xmm7
0000786bc93de1cc  vmovaps [rsp+0x70], xmm8
0000786bc93de1d2  vmovaps [rsp+0x80], xmm9
0000786bc93de1db  vmovaps [rsp+0x90], xmm10
0000786bc93de1e4  vmovaps [rsp+0xA0], xmm11
0000786bc93de1ed  vmovaps [rsp+0xB0], xmm12
0000786bc93de1f6  vmovaps [rsp+0xC0], xmm13
0000786bc93de1ff  vmovaps [rsp+0xD0], xmm14
0000786bc93de208  vmovaps [rsp+0xE0], xmm15
0000786bc93de211  sub rsp, 0x30
0000786bc93de215  movaps [rsp], xmm1
0000786bc93de219  movaps [rsp+0x10], xmm5
0000786bc93de21e  movaps [rsp+0x20], xmm4
0000786bc93de223  lea rdi, [rsp]
0000786bc93de227  mov esi, 0x00
0000786bc93de22c  mov rax, 0x60810F6F7530
0000786bc93de236  call rax
0000786bc93de238  movaps xmm1, [rsp]
0000786bc93de23c  add rsp, 0x30
0000786bc93de240  vmovaps xmm0, [rsp]
0000786bc93de245  vmovaps xmm2, [rsp+0x10]
0000786bc93de24b  vmovaps xmm3, [rsp+0x20]
0000786bc93de251  vmovaps xmm4, [rsp+0x30]
0000786bc93de257  vmovaps xmm5, [rsp+0x40]
0000786bc93de25d  vmovaps xmm6, [rsp+0x50]
0000786bc93de263  vmovaps xmm7, [rsp+0x60]
0000786bc93de269  vmovaps xmm8, [rsp+0x70]
0000786bc93de26f  vmovaps xmm9, [rsp+0x80]
0000786bc93de278  vmovaps xmm10, [rsp+0x90]
0000786bc93de281  vmovaps xmm11, [rsp+0xA0]
0000786bc93de28a  vmovaps xmm12, [rsp+0xB0]
0000786bc93de293  vmovaps xmm13, [rsp+0xC0]
0000786bc93de29c  vmovaps xmm14, [rsp+0xD0]
0000786bc93de2a5  vmovaps xmm15, [rsp+0xE0]
0000786bc93de2ae  add rsp, 0xF0
0000786bc93de2b5  pop r11
0000786bc93de2b7  pop r10
0000786bc93de2b9  pop r9
0000786bc93de2bb  pop r8
0000786bc93de2bd  pop rsi
0000786bc93de2be  pop rdi
0000786bc93de2bf  pop rdx
0000786bc93de2c0  pop rcx
0000786bc93de2c1  pop rax
0000786bc93de2c2  add rsp, 0x08
0000786bc93de2c6  jmp 0x0000786BC93DC0B9
0000786bc93de2cb  sub rsp, 0x08
0000786bc93de2cf  push rax
0000786bc93de2d0  push rcx
0000786bc93de2d1  push rdx
0000786bc93de2d2  push rdi
0000786bc93de2d3  push rsi
0000786bc93de2d4  push r8
0000786bc93de2d6  push r9
0000786bc93de2d8  push r10
0000786bc93de2da  push r11
0000786bc93de2dc  sub rsp, 0xF0
0000786bc93de2e3  vmovaps [rsp], xmm0
0000786bc93de2e8  vmovaps [rsp+0x10], xmm1
0000786bc93de2ee  vmovaps [rsp+0x20], xmm2
0000786bc93de2f4  vmovaps [rsp+0x30], xmm3
0000786bc93de2fa  vmovaps [rsp+0x40], xmm5
0000786bc93de300  vmovaps [rsp+0x50], xmm6
0000786bc93de306  vmovaps [rsp+0x60], xmm7
0000786bc93de30c  vmovaps [rsp+0x70], xmm8
0000786bc93de312  vmovaps [rsp+0x80], xmm9
0000786bc93de31b  vmovaps [rsp+0x90], xmm10
0000786bc93de324  vmovaps [rsp+0xA0], xmm11
0000786bc93de32d  vmovaps [rsp+0xB0], xmm12
0000786bc93de336  vmovaps [rsp+0xC0], xmm13
0000786bc93de33f  vmovaps [rsp+0xD0], xmm14
0000786bc93de348  vmovaps [rsp+0xE0], xmm15
0000786bc93de351  sub rsp, 0x30
0000786bc93de355  movaps [rsp], xmm4
0000786bc93de359  movaps [rsp+0x10], xmm3
0000786bc93de35e  movaps [rsp+0x20], xmm5
0000786bc93de363  lea rdi, [rsp]
0000786bc93de367  mov esi, 0x00
0000786bc93de36c  mov rax, 0x60810F6F7530
0000786bc93de376  call rax
0000786bc93de378  movaps xmm4, [rsp]
0000786bc93de37c  add rsp, 0x30
0000786bc93de380  vmovaps xmm0, [rsp]
0000786bc93de385  vmovaps xmm1, [rsp+0x10]
0000786bc93de38b  vmovaps xmm2, [rsp+0x20]
0000786bc93de391  vmovaps xmm3, [rsp+0x30]
0000786bc93de397  vmovaps xmm5, [rsp+0x40]
0000786bc93de39d  vmovaps xmm6, [rsp+0x50]
0000786bc93de3a3  vmovaps xmm7, [rsp+0x60]
0000786bc93de3a9  vmovaps xmm8, [rsp+0x70]
0000786bc93de3af  vmovaps xmm9, [rsp+0x80]
0000786bc93de3b8  vmovaps xmm10, [rsp+0x90]
0000786bc93de3c1  vmovaps xmm11, [rsp+0xA0]
0000786bc93de3ca  vmovaps xmm12, [rsp+0xB0]
0000786bc93de3d3  vmovaps xmm13, [rsp+0xC0]
0000786bc93de3dc  vmovaps xmm14, [rsp+0xD0]
0000786bc93de3e5  vmovaps xmm15, [rsp+0xE0]
0000786bc93de3ee  add rsp, 0xF0
0000786bc93de3f5  pop r11
0000786bc93de3f7  pop r10
0000786bc93de3f9  pop r9
0000786bc93de3fb  pop r8
0000786bc93de3fd  pop rsi
0000786bc93de3fe  pop rdi
0000786bc93de3ff  pop rdx
0000786bc93de400  pop rcx
0000786bc93de401  pop rax
0000786bc93de402  add rsp, 0x08
0000786bc93de406  jmp 0x0000786BC93DC107
0000786bc93de40b  call 0x0000786BC92B52F0
0000786bc93de410  jmp 0x0000786BC93DC114
0000786bc93de415  sub rsp, 0x08
0000786bc93de419  push rax
0000786bc93de41a  push rcx
0000786bc93de41b  push rdx
0000786bc93de41c  push rdi
0000786bc93de41d  push rsi
0000786bc93de41e  push r8
0000786bc93de420  push r9
0000786bc93de422  push r10
0000786bc93de424  push r11
0000786bc93de426  sub rsp, 0xF0
0000786bc93de42d  vmovaps [rsp], xmm0
0000786bc93de432  vmovaps [rsp+0x10], xmm1
0000786bc93de438  vmovaps [rsp+0x20], xmm2
0000786bc93de43e  vmovaps [rsp+0x30], xmm3
0000786bc93de444  vmovaps [rsp+0x40], xmm4
0000786bc93de44a  vmovaps [rsp+0x50], xmm6
0000786bc93de450  vmovaps [rsp+0x60], xmm7
0000786bc93de456  vmovaps [rsp+0x70], xmm8
0000786bc93de45c  vmovaps [rsp+0x80], xmm9
0000786bc93de465  vmovaps [rsp+0x90], xmm10
0000786bc93de46e  vmovaps [rsp+0xA0], xmm11
0000786bc93de477  vmovaps [rsp+0xB0], xmm12
0000786bc93de480  vmovaps [rsp+0xC0], xmm13
0000786bc93de489  vmovaps [rsp+0xD0], xmm14
0000786bc93de492  vmovaps [rsp+0xE0], xmm15
0000786bc93de49b  sub rsp, 0x30
0000786bc93de49f  movaps [rsp], xmm5
0000786bc93de4a3  movaps [rsp+0x10], xmm6
0000786bc93de4a8  movaps [rsp+0x20], xmm3
0000786bc93de4ad  lea rdi, [rsp]
0000786bc93de4b1  mov esi, 0x00
0000786bc93de4b6  mov rax, 0x60810F6F7530
0000786bc93de4c0  call rax
0000786bc93de4c2  movaps xmm5, [rsp]
0000786bc93de4c6  add rsp, 0x30
0000786bc93de4ca  vmovaps xmm0, [rsp]
0000786bc93de4cf  vmovaps xmm1, [rsp+0x10]
0000786bc93de4d5  vmovaps xmm2, [rsp+0x20]
0000786bc93de4db  vmovaps xmm3, [rsp+0x30]
0000786bc93de4e1  vmovaps xmm4, [rsp+0x40]
0000786bc93de4e7  vmovaps xmm6, [rsp+0x50]
0000786bc93de4ed  vmovaps xmm7, [rsp+0x60]
0000786bc93de4f3  vmovaps xmm8, [rsp+0x70]
0000786bc93de4f9  vmovaps xmm9, [rsp+0x80]
0000786bc93de502  vmovaps xmm10, [rsp+0x90]
0000786bc93de50b  vmovaps xmm11, [rsp+0xA0]
0000786bc93de514  vmovaps xmm12, [rsp+0xB0]
0000786bc93de51d  vmovaps xmm13, [rsp+0xC0]
0000786bc93de526  vmovaps xmm14, [rsp+0xD0]
0000786bc93de52f  vmovaps xmm15, [rsp+0xE0]
0000786bc93de538  add rsp, 0xF0
0000786bc93de53f  pop r11
0000786bc93de541  pop r10
0000786bc93de543  pop r9
0000786bc93de545  pop r8
0000786bc93de547  pop rsi
0000786bc93de548  pop rdi
0000786bc93de549  pop rdx
0000786bc93de54a  pop rcx
0000786bc93de54b  pop rax
0000786bc93de54c  add rsp, 0x08
0000786bc93de550  jmp 0x0000786BC93DC13A
0000786bc93de555  sub rsp, 0x08
0000786bc93de559  push rax
0000786bc93de55a  push rcx
0000786bc93de55b  push rdx
0000786bc93de55c  push rdi
0000786bc93de55d  push rsi
0000786bc93de55e  push r8
0000786bc93de560  push r9
0000786bc93de562  push r10
0000786bc93de564  push r11
0000786bc93de566  sub rsp, 0xF0
0000786bc93de56d  vmovaps [rsp], xmm0
0000786bc93de572  vmovaps [rsp+0x10], xmm1
0000786bc93de578  vmovaps [rsp+0x20], xmm2
0000786bc93de57e  vmovaps [rsp+0x30], xmm3
0000786bc93de584  vmovaps [rsp+0x40], xmm4
0000786bc93de58a  vmovaps [rsp+0x50], xmm5
0000786bc93de590  vmovaps [rsp+0x60], xmm7
0000786bc93de596  vmovaps [rsp+0x70], xmm8
0000786bc93de59c  vmovaps [rsp+0x80], xmm9
0000786bc93de5a5  vmovaps [rsp+0x90], xmm10
0000786bc93de5ae  vmovaps [rsp+0xA0], xmm11
0000786bc93de5b7  vmovaps [rsp+0xB0], xmm12
0000786bc93de5c0  vmovaps [rsp+0xC0], xmm13
0000786bc93de5c9  vmovaps [rsp+0xD0], xmm14
0000786bc93de5d2  vmovaps [rsp+0xE0], xmm15
0000786bc93de5db  sub rsp, 0x30
0000786bc93de5df  movaps [rsp], xmm6
0000786bc93de5e3  movaps [rsp+0x10], xmm9
0000786bc93de5e9  movaps [rsp+0x20], xmm1
0000786bc93de5ee  lea rdi, [rsp]
0000786bc93de5f2  mov esi, 0x00
0000786bc93de5f7  mov rax, 0x60810F6F7530
0000786bc93de601  call rax
0000786bc93de603  movaps xmm6, [rsp]
0000786bc93de607  add rsp, 0x30
0000786bc93de60b  vmovaps xmm0, [rsp]
0000786bc93de610  vmovaps xmm1, [rsp+0x10]
0000786bc93de616  vmovaps xmm2, [rsp+0x20]
0000786bc93de61c  vmovaps xmm3, [rsp+0x30]
0000786bc93de622  vmovaps xmm4, [rsp+0x40]
0000786bc93de628  vmovaps xmm5, [rsp+0x50]
0000786bc93de62e  vmovaps xmm7, [rsp+0x60]
0000786bc93de634  vmovaps xmm8, [rsp+0x70]
0000786bc93de63a  vmovaps xmm9, [rsp+0x80]
0000786bc93de643  vmovaps xmm10, [rsp+0x90]
0000786bc93de64c  vmovaps xmm11, [rsp+0xA0]
0000786bc93de655  vmovaps xmm12, [rsp+0xB0]
0000786bc93de65e  vmovaps xmm13, [rsp+0xC0]
0000786bc93de667  vmovaps xmm14, [rsp+0xD0]
0000786bc93de670  vmovaps xmm15, [rsp+0xE0]
0000786bc93de679  add rsp, 0xF0
0000786bc93de680  pop r11
0000786bc93de682  pop r10
0000786bc93de684  pop r9
0000786bc93de686  pop r8
0000786bc93de688  pop rsi
0000786bc93de689  pop rdi
0000786bc93de68a  pop rdx
0000786bc93de68b  pop rcx
0000786bc93de68c  pop rax
0000786bc93de68d  add rsp, 0x08
0000786bc93de691  jmp 0x0000786BC93DC15E
0000786bc93de696  sub rsp, 0x08
0000786bc93de69a  push rax
0000786bc93de69b  push rcx
0000786bc93de69c  push rdx
0000786bc93de69d  push rdi
0000786bc93de69e  push rsi
0000786bc93de69f  push r8
0000786bc93de6a1  push r9
0000786bc93de6a3  push r10
0000786bc93de6a5  push r11
0000786bc93de6a7  sub rsp, 0xF0
0000786bc93de6ae  vmovaps [rsp], xmm0
0000786bc93de6b3  vmovaps [rsp+0x10], xmm1
0000786bc93de6b9  vmovaps [rsp+0x20], xmm2
0000786bc93de6bf  vmovaps [rsp+0x30], xmm3
0000786bc93de6c5  vmovaps [rsp+0x40], xmm4
0000786bc93de6cb  vmovaps [rsp+0x50], xmm5
0000786bc93de6d1  vmovaps [rsp+0x60], xmm6
0000786bc93de6d7  vmovaps [rsp+0x70], xmm7
0000786bc93de6dd  vmovaps [rsp+0x80], xmm8
0000786bc93de6e6  vmovaps [rsp+0x90], xmm10
0000786bc93de6ef  vmovaps [rsp+0xA0], xmm11
0000786bc93de6f8  vmovaps [rsp+0xB0], xmm12
0000786bc93de701  vmovaps [rsp+0xC0], xmm13
0000786bc93de70a  vmovaps [rsp+0xD0], xmm14
0000786bc93de713  vmovaps [rsp+0xE0], xmm15
0000786bc93de71c  sub rsp, 0x30
0000786bc93de720  movaps [rsp], xmm9
0000786bc93de725  movaps [rsp+0x10], xmm3
0000786bc93de72a  movaps [rsp+0x20], xmm1
0000786bc93de72f  lea rdi, [rsp]
0000786bc93de733  mov esi, 0x00
0000786bc93de738  mov rax, 0x60810F6F7530
0000786bc93de742  call rax
0000786bc93de744  movaps xmm9, [rsp]
0000786bc93de749  add rsp, 0x30
0000786bc93de74d  vmovaps xmm0, [rsp]
0000786bc93de752  vmovaps xmm1, [rsp+0x10]
0000786bc93de758  vmovaps xmm2, [rsp+0x20]
0000786bc93de75e  vmovaps xmm3, [rsp+0x30]
0000786bc93de764  vmovaps xmm4, [rsp+0x40]
0000786bc93de76a  vmovaps xmm5, [rsp+0x50]
0000786bc93de770  vmovaps xmm6, [rsp+0x60]
0000786bc93de776  vmovaps xmm7, [rsp+0x70]
0000786bc93de77c  vmovaps xmm8, [rsp+0x80]
0000786bc93de785  vmovaps xmm10, [rsp+0x90]
0000786bc93de78e  vmovaps xmm11, [rsp+0xA0]
0000786bc93de797  vmovaps xmm12, [rsp+0xB0]
0000786bc93de7a0  vmovaps xmm13, [rsp+0xC0]
0000786bc93de7a9  vmovaps xmm14, [rsp+0xD0]
0000786bc93de7b2  vmovaps xmm15, [rsp+0xE0]
0000786bc93de7bb  add rsp, 0xF0
0000786bc93de7c2  pop r11
0000786bc93de7c4  pop r10
0000786bc93de7c6  pop r9
0000786bc93de7c8  pop r8
0000786bc93de7ca  pop rsi
0000786bc93de7cb  pop rdi
0000786bc93de7cc  pop rdx
0000786bc93de7cd  pop rcx
0000786bc93de7ce  pop rax
0000786bc93de7cf  add rsp, 0x08
0000786bc93de7d3  jmp 0x0000786BC93DC1AA
0000786bc93de7d8  call 0x0000786BC92B52F0
0000786bc93de7dd  jmp 0x0000786BC93DC1B7
0000786bc93de7e2  sub rsp, 0x08
0000786bc93de7e6  push rax
0000786bc93de7e7  push rcx
0000786bc93de7e8  push rdx
0000786bc93de7e9  push rdi
0000786bc93de7ea  push rsi
0000786bc93de7eb  push r8
0000786bc93de7ed  push r9
0000786bc93de7ef  push r10
0000786bc93de7f1  push r11
0000786bc93de7f3  sub rsp, 0xF0
0000786bc93de7fa  vmovaps [rsp], xmm0
0000786bc93de7ff  vmovaps [rsp+0x10], xmm1
0000786bc93de805  vmovaps [rsp+0x20], xmm2
0000786bc93de80b  vmovaps [rsp+0x30], xmm3
0000786bc93de811  vmovaps [rsp+0x40], xmm4
0000786bc93de817  vmovaps [rsp+0x50], xmm5
0000786bc93de81d  vmovaps [rsp+0x60], xmm6
0000786bc93de823  vmovaps [rsp+0x70], xmm7
0000786bc93de829  vmovaps [rsp+0x80], xmm8
0000786bc93de832  vmovaps [rsp+0x90], xmm9
0000786bc93de83b  vmovaps [rsp+0xA0], xmm10
0000786bc93de844  vmovaps [rsp+0xB0], xmm11
0000786bc93de84d  vmovaps [rsp+0xC0], xmm12
0000786bc93de856  vmovaps [rsp+0xD0], xmm13
0000786bc93de85f  vmovaps [rsp+0xE0], xmm14
0000786bc93de868  sub rsp, 0x30
0000786bc93de86c  movaps [rsp], xmm15
0000786bc93de871  movaps [rsp+0x10], xmm3
0000786bc93de876  movaps [rsp+0x20], xmm7
0000786bc93de87b  lea rdi, [rsp]
0000786bc93de87f  mov esi, 0x00
0000786bc93de884  mov rax, 0x60810F6F7530
0000786bc93de88e  call rax
0000786bc93de890  movaps xmm15, [rsp]
0000786bc93de895  add rsp, 0x30
0000786bc93de899  vmovaps xmm0, [rsp]
0000786bc93de89e  vmovaps xmm1, [rsp+0x10]
0000786bc93de8a4  vmovaps xmm2, [rsp+0x20]
0000786bc93de8aa  vmovaps xmm3, [rsp+0x30]
0000786bc93de8b0  vmovaps xmm4, [rsp+0x40]
0000786bc93de8b6  vmovaps xmm5, [rsp+0x50]
0000786bc93de8bc  vmovaps xmm6, [rsp+0x60]
0000786bc93de8c2  vmovaps xmm7, [rsp+0x70]
0000786bc93de8c8  vmovaps xmm8, [rsp+0x80]
0000786bc93de8d1  vmovaps xmm9, [rsp+0x90]
0000786bc93de8da  vmovaps xmm10, [rsp+0xA0]
0000786bc93de8e3  vmovaps xmm11, [rsp+0xB0]
0000786bc93de8ec  vmovaps xmm12, [rsp+0xC0]
0000786bc93de8f5  vmovaps xmm13, [rsp+0xD0]
0000786bc93de8fe  vmovaps xmm14, [rsp+0xE0]
0000786bc93de907  add rsp, 0xF0
0000786bc93de90e  pop r11
0000786bc93de910  pop r10
0000786bc93de912  pop r9
0000786bc93de914  pop r8
0000786bc93de916  pop rsi
0000786bc93de917  pop rdi
0000786bc93de918  pop rdx
0000786bc93de919  pop rcx
0000786bc93de91a  pop rax
0000786bc93de91b  add rsp, 0x08
0000786bc93de91f  jmp 0x0000786BC93DC1E3
0000786bc93de924  sub rsp, 0x08
0000786bc93de928  push rax
0000786bc93de929  push rcx
0000786bc93de92a  push rdx
0000786bc93de92b  push rdi
0000786bc93de92c  push rsi
0000786bc93de92d  push r8
0000786bc93de92f  push r9
0000786bc93de931  push r10
0000786bc93de933  push r11
0000786bc93de935  sub rsp, 0xF0
0000786bc93de93c  vmovaps [rsp], xmm0
0000786bc93de941  vmovaps [rsp+0x10], xmm1
0000786bc93de947  vmovaps [rsp+0x20], xmm2
0000786bc93de94d  vmovaps [rsp+0x30], xmm4
0000786bc93de953  vmovaps [rsp+0x40], xmm5
0000786bc93de959  vmovaps [rsp+0x50], xmm6
0000786bc93de95f  vmovaps [rsp+0x60], xmm7
0000786bc93de965  vmovaps [rsp+0x70], xmm8
0000786bc93de96b  vmovaps [rsp+0x80], xmm9
0000786bc93de974  vmovaps [rsp+0x90], xmm10
0000786bc93de97d  vmovaps [rsp+0xA0], xmm11
0000786bc93de986  vmovaps [rsp+0xB0], xmm12
0000786bc93de98f  vmovaps [rsp+0xC0], xmm13
0000786bc93de998  vmovaps [rsp+0xD0], xmm14
0000786bc93de9a1  vmovaps [rsp+0xE0], xmm15
0000786bc93de9aa  sub rsp, 0x30
0000786bc93de9ae  movaps [rsp], xmm3
0000786bc93de9b2  movaps [rsp+0x10], xmm1
0000786bc93de9b7  movaps [rsp+0x20], xmm15
0000786bc93de9bd  lea rdi, [rsp]
0000786bc93de9c1  mov esi, 0x00
0000786bc93de9c6  mov rax, 0x60810F6F7530
0000786bc93de9d0  call rax
0000786bc93de9d2  movaps xmm3, [rsp]
0000786bc93de9d6  add rsp, 0x30
0000786bc93de9da  vmovaps xmm0, [rsp]
0000786bc93de9df  vmovaps xmm1, [rsp+0x10]
0000786bc93de9e5  vmovaps xmm2, [rsp+0x20]
0000786bc93de9eb  vmovaps xmm4, [rsp+0x30]
0000786bc93de9f1  vmovaps xmm5, [rsp+0x40]
0000786bc93de9f7  vmovaps xmm6, [rsp+0x50]
0000786bc93de9fd  vmovaps xmm7, [rsp+0x60]
0000786bc93dea03  vmovaps xmm8, [rsp+0x70]
0000786bc93dea09  vmovaps xmm9, [rsp+0x80]
0000786bc93dea12  vmovaps xmm10, [rsp+0x90]
0000786bc93dea1b  vmovaps xmm11, [rsp+0xA0]
0000786bc93dea24  vmovaps xmm12, [rsp+0xB0]
0000786bc93dea2d  vmovaps xmm13, [rsp+0xC0]
0000786bc93dea36  vmovaps xmm14, [rsp+0xD0]
0000786bc93dea3f  vmovaps xmm15, [rsp+0xE0]
0000786bc93dea48  add rsp, 0xF0
0000786bc93dea4f  pop r11
0000786bc93dea51  pop r10
0000786bc93dea53  pop r9
0000786bc93dea55  pop r8
0000786bc93dea57  pop rsi
0000786bc93dea58  pop rdi
0000786bc93dea59  pop rdx
0000786bc93dea5a  pop rcx
0000786bc93dea5b  pop rax
0000786bc93dea5c  add rsp, 0x08
0000786bc93dea60  jmp 0x0000786BC93DC272
0000786bc93dea65  call 0x0000786BC92B52F0
0000786bc93dea6a  jmp 0x0000786BC93DC27C
0000786bc93dea6f  sub rsp, 0x08
0000786bc93dea73  push rax
0000786bc93dea74  push rcx
0000786bc93dea75  push rdx
0000786bc93dea76  push rdi
0000786bc93dea77  push rsi
0000786bc93dea78  push r8
0000786bc93dea7a  push r9
0000786bc93dea7c  push r10
0000786bc93dea7e  push r11
0000786bc93dea80  sub rsp, 0xF0
0000786bc93dea87  vmovaps [rsp], xmm0
0000786bc93dea8c  vmovaps [rsp+0x10], xmm1
0000786bc93dea92  vmovaps [rsp+0x20], xmm2
0000786bc93dea98  vmovaps [rsp+0x30], xmm3
0000786bc93dea9e  vmovaps [rsp+0x40], xmm4
0000786bc93deaa4  vmovaps [rsp+0x50], xmm5
0000786bc93deaaa  vmovaps [rsp+0x60], xmm6
0000786bc93deab0  vmovaps [rsp+0x70], xmm7
0000786bc93deab6  vmovaps [rsp+0x80], xmm8
0000786bc93deabf  vmovaps [rsp+0x90], xmm9
0000786bc93deac8  vmovaps [rsp+0xA0], xmm10
0000786bc93dead1  vmovaps [rsp+0xB0], xmm11
0000786bc93deada  vmovaps [rsp+0xC0], xmm12
0000786bc93deae3  vmovaps [rsp+0xD0], xmm13
0000786bc93deaec  vmovaps [rsp+0xE0], xmm14
0000786bc93deaf5  sub rsp, 0x30
0000786bc93deaf9  movaps [rsp], xmm15
0000786bc93deafe  movaps [rsp+0x10], xmm14
0000786bc93deb04  movaps [rsp+0x20], xmm4
0000786bc93deb09  lea rdi, [rsp]
0000786bc93deb0d  mov esi, 0x00
0000786bc93deb12  mov rax, 0x60810F6F7530
0000786bc93deb1c  call rax
0000786bc93deb1e  movaps xmm15, [rsp]
0000786bc93deb23  add rsp, 0x30
0000786bc93deb27  vmovaps xmm0, [rsp]
0000786bc93deb2c  vmovaps xmm1, [rsp+0x10]
0000786bc93deb32  vmovaps xmm2, [rsp+0x20]
0000786bc93deb38  vmovaps xmm3, [rsp+0x30]
0000786bc93deb3e  vmovaps xmm4, [rsp+0x40]
0000786bc93deb44  vmovaps xmm5, [rsp+0x50]
0000786bc93deb4a  vmovaps xmm6, [rsp+0x60]
0000786bc93deb50  vmovaps xmm7, [rsp+0x70]
0000786bc93deb56  vmovaps xmm8, [rsp+0x80]
0000786bc93deb5f  vmovaps xmm9, [rsp+0x90]
0000786bc93deb68  vmovaps xmm10, [rsp+0xA0]
0000786bc93deb71  vmovaps xmm11, [rsp+0xB0]
0000786bc93deb7a  vmovaps xmm12, [rsp+0xC0]
0000786bc93deb83  vmovaps xmm13, [rsp+0xD0]
0000786bc93deb8c  vmovaps xmm14, [rsp+0xE0]
0000786bc93deb95  add rsp, 0xF0
0000786bc93deb9c  pop r11
0000786bc93deb9e  pop r10
0000786bc93deba0  pop r9
0000786bc93deba2  pop r8
0000786bc93deba4  pop rsi
0000786bc93deba5  pop rdi
0000786bc93deba6  pop rdx
0000786bc93deba7  pop rcx
0000786bc93deba8  pop rax
0000786bc93deba9  add rsp, 0x08
0000786bc93debad  jmp 0x0000786BC93DC2AA
0000786bc93debb2  sub rsp, 0x08
0000786bc93debb6  push rax
0000786bc93debb7  push rcx
0000786bc93debb8  push rdx
0000786bc93debb9  push rdi
0000786bc93debba  push rsi
0000786bc93debbb  push r8
0000786bc93debbd  push r9
0000786bc93debbf  push r10
0000786bc93debc1  push r11
0000786bc93debc3  sub rsp, 0xF0
0000786bc93debca  vmovaps [rsp], xmm0
0000786bc93debcf  vmovaps [rsp+0x10], xmm1
0000786bc93debd5  vmovaps [rsp+0x20], xmm2
0000786bc93debdb  vmovaps [rsp+0x30], xmm3
0000786bc93debe1  vmovaps [rsp+0x40], xmm4
0000786bc93debe7  vmovaps [rsp+0x50], xmm5
0000786bc93debed  vmovaps [rsp+0x60], xmm6
0000786bc93debf3  vmovaps [rsp+0x70], xmm7
0000786bc93debf9  vmovaps [rsp+0x80], xmm8
0000786bc93dec02  vmovaps [rsp+0x90], xmm9
0000786bc93dec0b  vmovaps [rsp+0xA0], xmm10
0000786bc93dec14  vmovaps [rsp+0xB0], xmm11
0000786bc93dec1d  vmovaps [rsp+0xC0], xmm12
0000786bc93dec26  vmovaps [rsp+0xD0], xmm13
0000786bc93dec2f  vmovaps [rsp+0xE0], xmm15
0000786bc93dec38  sub rsp, 0x30
0000786bc93dec3c  movaps [rsp], xmm14
0000786bc93dec41  movaps [rsp+0x10], xmm2
0000786bc93dec46  movaps [rsp+0x20], xmm1
0000786bc93dec4b  lea rdi, [rsp]
0000786bc93dec4f  mov esi, 0x00
0000786bc93dec54  mov rax, 0x60810F6F7530
0000786bc93dec5e  call rax
0000786bc93dec60  movaps xmm14, [rsp]
0000786bc93dec65  add rsp, 0x30
0000786bc93dec69  vmovaps xmm0, [rsp]
0000786bc93dec6e  vmovaps xmm1, [rsp+0x10]
0000786bc93dec74  vmovaps xmm2, [rsp+0x20]
0000786bc93dec7a  vmovaps xmm3, [rsp+0x30]
0000786bc93dec80  vmovaps xmm4, [rsp+0x40]
0000786bc93dec86  vmovaps xmm5, [rsp+0x50]
0000786bc93dec8c  vmovaps xmm6, [rsp+0x60]
0000786bc93dec92  vmovaps xmm7, [rsp+0x70]
0000786bc93dec98  vmovaps xmm8, [rsp+0x80]
0000786bc93deca1  vmovaps xmm9, [rsp+0x90]
0000786bc93decaa  vmovaps xmm10, [rsp+0xA0]
0000786bc93decb3  vmovaps xmm11, [rsp+0xB0]
0000786bc93decbc  vmovaps xmm12, [rsp+0xC0]
0000786bc93decc5  vmovaps xmm13, [rsp+0xD0]
0000786bc93decce  vmovaps xmm15, [rsp+0xE0]
0000786bc93decd7  add rsp, 0xF0
0000786bc93decde  pop r11
0000786bc93dece0  pop r10
0000786bc93dece2  pop r9
0000786bc93dece4  pop r8
0000786bc93dece6  pop rsi
0000786bc93dece7  pop rdi
0000786bc93dece8  pop rdx
0000786bc93dece9  pop rcx
0000786bc93decea  pop rax
0000786bc93deceb  add rsp, 0x08
0000786bc93decef  jmp 0x0000786BC93DC2D0
0000786bc93decf4  sub rsp, 0x08
0000786bc93decf8  push rax
0000786bc93decf9  push rcx
0000786bc93decfa  push rdx
0000786bc93decfb  push rdi
0000786bc93decfc  push rsi
0000786bc93decfd  push r8
0000786bc93decff  push r9
0000786bc93ded01  push r10
0000786bc93ded03  push r11
0000786bc93ded05  sub rsp, 0xF0
0000786bc93ded0c  vmovaps [rsp], xmm0
0000786bc93ded11  vmovaps [rsp+0x10], xmm2
0000786bc93ded17  vmovaps [rsp+0x20], xmm3
0000786bc93ded1d  vmovaps [rsp+0x30], xmm4
0000786bc93ded23  vmovaps [rsp+0x40], xmm5
0000786bc93ded29  vmovaps [rsp+0x50], xmm6
0000786bc93ded2f  vmovaps [rsp+0x60], xmm7
0000786bc93ded35  vmovaps [rsp+0x70], xmm8
0000786bc93ded3b  vmovaps [rsp+0x80], xmm9
0000786bc93ded44  vmovaps [rsp+0x90], xmm10
0000786bc93ded4d  vmovaps [rsp+0xA0], xmm11
0000786bc93ded56  vmovaps [rsp+0xB0], xmm12
0000786bc93ded5f  vmovaps [rsp+0xC0], xmm13
0000786bc93ded68  vmovaps [rsp+0xD0], xmm14
0000786bc93ded71  vmovaps [rsp+0xE0], xmm15
0000786bc93ded7a  sub rsp, 0x30
0000786bc93ded7e  movaps [rsp], xmm1
0000786bc93ded82  movaps [rsp+0x10], xmm4
0000786bc93ded87  movaps [rsp+0x20], xmm9
0000786bc93ded8d  lea rdi, [rsp]
0000786bc93ded91  mov esi, 0x00
0000786bc93ded96  mov rax, 0x60810F6F7530
0000786bc93deda0  call rax
0000786bc93deda2  movaps xmm1, [rsp]
0000786bc93deda6  add rsp, 0x30
0000786bc93dedaa  vmovaps xmm0, [rsp]
0000786bc93dedaf  vmovaps xmm2, [rsp+0x10]
0000786bc93dedb5  vmovaps xmm3, [rsp+0x20]
0000786bc93dedbb  vmovaps xmm4, [rsp+0x30]
0000786bc93dedc1  vmovaps xmm5, [rsp+0x40]
0000786bc93dedc7  vmovaps xmm6, [rsp+0x50]
0000786bc93dedcd  vmovaps xmm7, [rsp+0x60]
0000786bc93dedd3  vmovaps xmm8, [rsp+0x70]
0000786bc93dedd9  vmovaps xmm9, [rsp+0x80]
0000786bc93dede2  vmovaps xmm10, [rsp+0x90]
0000786bc93dedeb  vmovaps xmm11, [rsp+0xA0]
0000786bc93dedf4  vmovaps xmm12, [rsp+0xB0]
0000786bc93dedfd  vmovaps xmm13, [rsp+0xC0]
0000786bc93dee06  vmovaps xmm14, [rsp+0xD0]
0000786bc93dee0f  vmovaps xmm15, [rsp+0xE0]
0000786bc93dee18  add rsp, 0xF0
0000786bc93dee1f  pop r11
0000786bc93dee21  pop r10
0000786bc93dee23  pop r9
0000786bc93dee25  pop r8
0000786bc93dee27  pop rsi
0000786bc93dee28  pop rdi
0000786bc93dee29  pop rdx
0000786bc93dee2a  pop rcx
0000786bc93dee2b  pop rax
0000786bc93dee2c  add rsp, 0x08
0000786bc93dee30  jmp 0x0000786BC93DC2EE
0000786bc93dee35  sub rsp, 0x08
0000786bc93dee39  push rax
0000786bc93dee3a  push rcx
0000786bc93dee3b  push rdx
0000786bc93dee3c  push rdi
0000786bc93dee3d  push rsi
0000786bc93dee3e  push r8
0000786bc93dee40  push r9
0000786bc93dee42  push r10
0000786bc93dee44  push r11
0000786bc93dee46  sub rsp, 0xF0
0000786bc93dee4d  vmovaps [rsp], xmm0
0000786bc93dee52  vmovaps [rsp+0x10], xmm1
0000786bc93dee58  vmovaps [rsp+0x20], xmm2
0000786bc93dee5e  vmovaps [rsp+0x30], xmm3
0000786bc93dee64  vmovaps [rsp+0x40], xmm5
0000786bc93dee6a  vmovaps [rsp+0x50], xmm6
0000786bc93dee70  vmovaps [rsp+0x60], xmm7
0000786bc93dee76  vmovaps [rsp+0x70], xmm8
0000786bc93dee7c  vmovaps [rsp+0x80], xmm9
0000786bc93dee85  vmovaps [rsp+0x90], xmm10
0000786bc93dee8e  vmovaps [rsp+0xA0], xmm11
0000786bc93dee97  vmovaps [rsp+0xB0], xmm12
0000786bc93deea0  vmovaps [rsp+0xC0], xmm13
0000786bc93deea9  vmovaps [rsp+0xD0], xmm14
0000786bc93deeb2  vmovaps [rsp+0xE0], xmm15
0000786bc93deebb  sub rsp, 0x30
0000786bc93deebf  movaps [rsp], xmm4
0000786bc93deec3  movaps [rsp+0x10], xmm2
0000786bc93deec8  movaps [rsp+0x20], xmm9
0000786bc93deece  lea rdi, [rsp]
0000786bc93deed2  mov esi, 0x00
0000786bc93deed7  mov rax, 0x60810F6F7530
0000786bc93deee1  call rax
0000786bc93deee3  movaps xmm4, [rsp]
0000786bc93deee7  add rsp, 0x30
0000786bc93deeeb  vmovaps xmm0, [rsp]
0000786bc93deef0  vmovaps xmm1, [rsp+0x10]
0000786bc93deef6  vmovaps xmm2, [rsp+0x20]
0000786bc93deefc  vmovaps xmm3, [rsp+0x30]
0000786bc93def02  vmovaps xmm5, [rsp+0x40]
0000786bc93def08  vmovaps xmm6, [rsp+0x50]
0000786bc93def0e  vmovaps xmm7, [rsp+0x60]
0000786bc93def14  vmovaps xmm8, [rsp+0x70]
0000786bc93def1a  vmovaps xmm9, [rsp+0x80]
0000786bc93def23  vmovaps xmm10, [rsp+0x90]
0000786bc93def2c  vmovaps xmm11, [rsp+0xA0]
0000786bc93def35  vmovaps xmm12, [rsp+0xB0]
0000786bc93def3e  vmovaps xmm13, [rsp+0xC0]
0000786bc93def47  vmovaps xmm14, [rsp+0xD0]
0000786bc93def50  vmovaps xmm15, [rsp+0xE0]
0000786bc93def59  add rsp, 0xF0
0000786bc93def60  pop r11
0000786bc93def62  pop r10
0000786bc93def64  pop r9
0000786bc93def66  pop r8
0000786bc93def68  pop rsi
0000786bc93def69  pop rdi
0000786bc93def6a  pop rdx
0000786bc93def6b  pop rcx
0000786bc93def6c  pop rax
0000786bc93def6d  add rsp, 0x08
0000786bc93def71  jmp 0x0000786BC93DC31E
0000786bc93def76  sub rsp, 0x08
0000786bc93def7a  push rax
0000786bc93def7b  push rcx
0000786bc93def7c  push rdx
0000786bc93def7d  push rdi
0000786bc93def7e  push rsi
0000786bc93def7f  push r8
0000786bc93def81  push r9
0000786bc93def83  push r10
0000786bc93def85  push r11
0000786bc93def87  sub rsp, 0xF0
0000786bc93def8e  vmovaps [rsp], xmm0
0000786bc93def93  vmovaps [rsp+0x10], xmm1
0000786bc93def99  vmovaps [rsp+0x20], xmm2
0000786bc93def9f  vmovaps [rsp+0x30], xmm3
0000786bc93defa5  vmovaps [rsp+0x40], xmm4
0000786bc93defab  vmovaps [rsp+0x50], xmm5
0000786bc93defb1  vmovaps [rsp+0x60], xmm6
0000786bc93defb7  vmovaps [rsp+0x70], xmm7
0000786bc93defbd  vmovaps [rsp+0x80], xmm8
0000786bc93defc6  vmovaps [rsp+0x90], xmm10
0000786bc93defcf  vmovaps [rsp+0xA0], xmm11
0000786bc93defd8  vmovaps [rsp+0xB0], xmm12
0000786bc93defe1  vmovaps [rsp+0xC0], xmm13
0000786bc93defea  vmovaps [rsp+0xD0], xmm14
0000786bc93deff3  vmovaps [rsp+0xE0], xmm15
0000786bc93deffc  sub rsp, 0x30
0000786bc93df000  movaps [rsp], xmm9
0000786bc93df005  movaps [rsp+0x10], xmm2
0000786bc93df00a  movaps [rsp+0x20], xmm1
0000786bc93df00f  lea rdi, [rsp]
0000786bc93df013  mov esi, 0x00
0000786bc93df018  mov rax, 0x60810F6F7530
0000786bc93df022  call rax
0000786bc93df024  movaps xmm9, [rsp]
0000786bc93df029  add rsp, 0x30
0000786bc93df02d  vmovaps xmm0, [rsp]
0000786bc93df032  vmovaps xmm1, [rsp+0x10]
0000786bc93df038  vmovaps xmm2, [rsp+0x20]
0000786bc93df03e  vmovaps xmm3, [rsp+0x30]
0000786bc93df044  vmovaps xmm4, [rsp+0x40]
0000786bc93df04a  vmovaps xmm5, [rsp+0x50]
0000786bc93df050  vmovaps xmm6, [rsp+0x60]
0000786bc93df056  vmovaps xmm7, [rsp+0x70]
0000786bc93df05c  vmovaps xmm8, [rsp+0x80]
0000786bc93df065  vmovaps xmm10, [rsp+0x90]
0000786bc93df06e  vmovaps xmm11, [rsp+0xA0]
0000786bc93df077  vmovaps xmm12, [rsp+0xB0]
0000786bc93df080  vmovaps xmm13, [rsp+0xC0]
0000786bc93df089  vmovaps xmm14, [rsp+0xD0]
0000786bc93df092  vmovaps xmm15, [rsp+0xE0]
0000786bc93df09b  add rsp, 0xF0
0000786bc93df0a2  pop r11
0000786bc93df0a4  pop r10
0000786bc93df0a6  pop r9
0000786bc93df0a8  pop r8
0000786bc93df0aa  pop rsi
0000786bc93df0ab  pop rdi
0000786bc93df0ac  pop rdx
0000786bc93df0ad  pop rcx
0000786bc93df0ae  pop rax
0000786bc93df0af  add rsp, 0x08
0000786bc93df0b3  jmp 0x0000786BC93DC354
0000786bc93df0b8  sub rsp, 0x08
0000786bc93df0bc  push rax
0000786bc93df0bd  push rcx
0000786bc93df0be  push rdx
0000786bc93df0bf  push rdi
0000786bc93df0c0  push rsi
0000786bc93df0c1  push r8
0000786bc93df0c3  push r9
0000786bc93df0c5  push r10
0000786bc93df0c7  push r11
0000786bc93df0c9  sub rsp, 0xF0
0000786bc93df0d0  vmovaps [rsp], xmm0
0000786bc93df0d5  vmovaps [rsp+0x10], xmm2
0000786bc93df0db  vmovaps [rsp+0x20], xmm3
0000786bc93df0e1  vmovaps [rsp+0x30], xmm4
0000786bc93df0e7  vmovaps [rsp+0x40], xmm5
0000786bc93df0ed  vmovaps [rsp+0x50], xmm6
0000786bc93df0f3  vmovaps [rsp+0x60], xmm7
0000786bc93df0f9  vmovaps [rsp+0x70], xmm8
0000786bc93df0ff  vmovaps [rsp+0x80], xmm9
0000786bc93df108  vmovaps [rsp+0x90], xmm10
0000786bc93df111  vmovaps [rsp+0xA0], xmm11
0000786bc93df11a  vmovaps [rsp+0xB0], xmm12
0000786bc93df123  vmovaps [rsp+0xC0], xmm13
0000786bc93df12c  vmovaps [rsp+0xD0], xmm14
0000786bc93df135  vmovaps [rsp+0xE0], xmm15
0000786bc93df13e  sub rsp, 0x30
0000786bc93df142  movaps [rsp], xmm1
0000786bc93df146  movaps [rsp+0x10], xmm15
0000786bc93df14c  movaps [rsp+0x20], xmm6
0000786bc93df151  lea rdi, [rsp]
0000786bc93df155  mov esi, 0x00
0000786bc93df15a  mov rax, 0x60810F6F7530
0000786bc93df164  call rax
0000786bc93df166  movaps xmm1, [rsp]
0000786bc93df16a  add rsp, 0x30
0000786bc93df16e  vmovaps xmm0, [rsp]
0000786bc93df173  vmovaps xmm2, [rsp+0x10]
0000786bc93df179  vmovaps xmm3, [rsp+0x20]
0000786bc93df17f  vmovaps xmm4, [rsp+0x30]
0000786bc93df185  vmovaps xmm5, [rsp+0x40]
0000786bc93df18b  vmovaps xmm6, [rsp+0x50]
0000786bc93df191  vmovaps xmm7, [rsp+0x60]
0000786bc93df197  vmovaps xmm8, [rsp+0x70]
0000786bc93df19d  vmovaps xmm9, [rsp+0x80]
0000786bc93df1a6  vmovaps xmm10, [rsp+0x90]
0000786bc93df1af  vmovaps xmm11, [rsp+0xA0]
0000786bc93df1b8  vmovaps xmm12, [rsp+0xB0]
0000786bc93df1c1  vmovaps xmm13, [rsp+0xC0]
0000786bc93df1ca  vmovaps xmm14, [rsp+0xD0]
0000786bc93df1d3  vmovaps xmm15, [rsp+0xE0]
0000786bc93df1dc  add rsp, 0xF0
0000786bc93df1e3  pop r11
0000786bc93df1e5  pop r10
0000786bc93df1e7  pop r9
0000786bc93df1e9  pop r8
0000786bc93df1eb  pop rsi
0000786bc93df1ec  pop rdi
0000786bc93df1ed  pop rdx
0000786bc93df1ee  pop rcx
0000786bc93df1ef  pop rax
0000786bc93df1f0  add rsp, 0x08
0000786bc93df1f4  jmp 0x0000786BC93DC375
0000786bc93df1f9  sub rsp, 0x08
0000786bc93df1fd  push rax
0000786bc93df1fe  push rcx
0000786bc93df1ff  push rdx
0000786bc93df200  push rdi
0000786bc93df201  push rsi
0000786bc93df202  push r8
0000786bc93df204  push r9
0000786bc93df206  push r10
0000786bc93df208  push r11
0000786bc93df20a  sub rsp, 0xF0
0000786bc93df211  vmovaps [rsp], xmm0
0000786bc93df216  vmovaps [rsp+0x10], xmm1
0000786bc93df21c  vmovaps [rsp+0x20], xmm2
0000786bc93df222  vmovaps [rsp+0x30], xmm3
0000786bc93df228  vmovaps [rsp+0x40], xmm4
0000786bc93df22e  vmovaps [rsp+0x50], xmm5
0000786bc93df234  vmovaps [rsp+0x60], xmm6
0000786bc93df23a  vmovaps [rsp+0x70], xmm7
0000786bc93df240  vmovaps [rsp+0x80], xmm8
0000786bc93df249  vmovaps [rsp+0x90], xmm9
0000786bc93df252  vmovaps [rsp+0xA0], xmm10
0000786bc93df25b  vmovaps [rsp+0xB0], xmm11
0000786bc93df264  vmovaps [rsp+0xC0], xmm12
0000786bc93df26d  vmovaps [rsp+0xD0], xmm13
0000786bc93df276  vmovaps [rsp+0xE0], xmm14
0000786bc93df27f  sub rsp, 0x30
0000786bc93df283  movaps [rsp], xmm15
0000786bc93df288  movaps [rsp+0x10], xmm5
0000786bc93df28d  movaps [rsp+0x20], xmm3
0000786bc93df292  lea rdi, [rsp]
0000786bc93df296  mov esi, 0x00
0000786bc93df29b  mov rax, 0x60810F6F7530
0000786bc93df2a5  call rax
0000786bc93df2a7  movaps xmm15, [rsp]
0000786bc93df2ac  add rsp, 0x30
0000786bc93df2b0  vmovaps xmm0, [rsp]
0000786bc93df2b5  vmovaps xmm1, [rsp+0x10]
0000786bc93df2bb  vmovaps xmm2, [rsp+0x20]
0000786bc93df2c1  vmovaps xmm3, [rsp+0x30]
0000786bc93df2c7  vmovaps xmm4, [rsp+0x40]
0000786bc93df2cd  vmovaps xmm5, [rsp+0x50]
0000786bc93df2d3  vmovaps xmm6, [rsp+0x60]
0000786bc93df2d9  vmovaps xmm7, [rsp+0x70]
0000786bc93df2df  vmovaps xmm8, [rsp+0x80]
0000786bc93df2e8  vmovaps xmm9, [rsp+0x90]
0000786bc93df2f1  vmovaps xmm10, [rsp+0xA0]
0000786bc93df2fa  vmovaps xmm11, [rsp+0xB0]
0000786bc93df303  vmovaps xmm12, [rsp+0xC0]
0000786bc93df30c  vmovaps xmm13, [rsp+0xD0]
0000786bc93df315  vmovaps xmm14, [rsp+0xE0]
0000786bc93df31e  add rsp, 0xF0
0000786bc93df325  pop r11
0000786bc93df327  pop r10
0000786bc93df329  pop r9
0000786bc93df32b  pop r8
0000786bc93df32d  pop rsi
0000786bc93df32e  pop rdi
0000786bc93df32f  pop rdx
0000786bc93df330  pop rcx
0000786bc93df331  pop rax
0000786bc93df332  add rsp, 0x08
0000786bc93df336  jmp 0x0000786BC93DC38F
0000786bc93df33b  sub rsp, 0x08
0000786bc93df33f  push rax
0000786bc93df340  push rcx
0000786bc93df341  push rdx
0000786bc93df342  push rdi
0000786bc93df343  push rsi
0000786bc93df344  push r8
0000786bc93df346  push r9
0000786bc93df348  push r10
0000786bc93df34a  push r11
0000786bc93df34c  sub rsp, 0xF0
0000786bc93df353  vmovaps [rsp], xmm0
0000786bc93df358  vmovaps [rsp+0x10], xmm1
0000786bc93df35e  vmovaps [rsp+0x20], xmm2
0000786bc93df364  vmovaps [rsp+0x30], xmm3
0000786bc93df36a  vmovaps [rsp+0x40], xmm4
0000786bc93df370  vmovaps [rsp+0x50], xmm6
0000786bc93df376  vmovaps [rsp+0x60], xmm7
0000786bc93df37c  vmovaps [rsp+0x70], xmm8
0000786bc93df382  vmovaps [rsp+0x80], xmm9
0000786bc93df38b  vmovaps [rsp+0x90], xmm10
0000786bc93df394  vmovaps [rsp+0xA0], xmm11
0000786bc93df39d  vmovaps [rsp+0xB0], xmm12
0000786bc93df3a6  vmovaps [rsp+0xC0], xmm13
0000786bc93df3af  vmovaps [rsp+0xD0], xmm14
0000786bc93df3b8  vmovaps [rsp+0xE0], xmm15
0000786bc93df3c1  sub rsp, 0x30
0000786bc93df3c5  movaps [rsp], xmm5
0000786bc93df3c9  movaps [rsp+0x10], xmm8
0000786bc93df3cf  movaps [rsp+0x20], xmm6
0000786bc93df3d4  lea rdi, [rsp]
0000786bc93df3d8  mov esi, 0x00
0000786bc93df3dd  mov rax, 0x60810F6F7530
0000786bc93df3e7  call rax
0000786bc93df3e9  movaps xmm5, [rsp]
0000786bc93df3ed  add rsp, 0x30
0000786bc93df3f1  vmovaps xmm0, [rsp]
0000786bc93df3f6  vmovaps xmm1, [rsp+0x10]
0000786bc93df3fc  vmovaps xmm2, [rsp+0x20]
0000786bc93df402  vmovaps xmm3, [rsp+0x30]
0000786bc93df408  vmovaps xmm4, [rsp+0x40]
0000786bc93df40e  vmovaps xmm6, [rsp+0x50]
0000786bc93df414  vmovaps xmm7, [rsp+0x60]
0000786bc93df41a  vmovaps xmm8, [rsp+0x70]
0000786bc93df420  vmovaps xmm9, [rsp+0x80]
0000786bc93df429  vmovaps xmm10, [rsp+0x90]
0000786bc93df432  vmovaps xmm11, [rsp+0xA0]
0000786bc93df43b  vmovaps xmm12, [rsp+0xB0]
0000786bc93df444  vmovaps xmm13, [rsp+0xC0]
0000786bc93df44d  vmovaps xmm14, [rsp+0xD0]
0000786bc93df456  vmovaps xmm15, [rsp+0xE0]
0000786bc93df45f  add rsp, 0xF0
0000786bc93df466  pop r11
0000786bc93df468  pop r10
0000786bc93df46a  pop r9
0000786bc93df46c  pop r8
0000786bc93df46e  pop rsi
0000786bc93df46f  pop rdi
0000786bc93df470  pop rdx
0000786bc93df471  pop rcx
0000786bc93df472  pop rax
0000786bc93df473  add rsp, 0x08
0000786bc93df477  jmp 0x0000786BC93DC3B3
0000786bc93df47c  sub rsp, 0x08
0000786bc93df480  push rax
0000786bc93df481  push rcx
0000786bc93df482  push rdx
0000786bc93df483  push rdi
0000786bc93df484  push rsi
0000786bc93df485  push r8
0000786bc93df487  push r9
0000786bc93df489  push r10
0000786bc93df48b  push r11
0000786bc93df48d  sub rsp, 0xF0
0000786bc93df494  vmovaps [rsp], xmm0
0000786bc93df499  vmovaps [rsp+0x10], xmm1
0000786bc93df49f  vmovaps [rsp+0x20], xmm2
0000786bc93df4a5  vmovaps [rsp+0x30], xmm3
0000786bc93df4ab  vmovaps [rsp+0x40], xmm4
0000786bc93df4b1  vmovaps [rsp+0x50], xmm5
0000786bc93df4b7  vmovaps [rsp+0x60], xmm7
0000786bc93df4bd  vmovaps [rsp+0x70], xmm8
0000786bc93df4c3  vmovaps [rsp+0x80], xmm9
0000786bc93df4cc  vmovaps [rsp+0x90], xmm10
0000786bc93df4d5  vmovaps [rsp+0xA0], xmm11
0000786bc93df4de  vmovaps [rsp+0xB0], xmm12
0000786bc93df4e7  vmovaps [rsp+0xC0], xmm13
0000786bc93df4f0  vmovaps [rsp+0xD0], xmm14
0000786bc93df4f9  vmovaps [rsp+0xE0], xmm15
0000786bc93df502  sub rsp, 0x30
0000786bc93df506  movaps [rsp], xmm6
0000786bc93df50a  movaps [rsp+0x10], xmm10
0000786bc93df510  movaps [rsp+0x20], xmm8
0000786bc93df516  lea rdi, [rsp]
0000786bc93df51a  mov esi, 0x00
0000786bc93df51f  mov rax, 0x60810F6F7530
0000786bc93df529  call rax
0000786bc93df52b  movaps xmm6, [rsp]
0000786bc93df52f  add rsp, 0x30
0000786bc93df533  vmovaps xmm0, [rsp]
0000786bc93df538  vmovaps xmm1, [rsp+0x10]
0000786bc93df53e  vmovaps xmm2, [rsp+0x20]
0000786bc93df544  vmovaps xmm3, [rsp+0x30]
0000786bc93df54a  vmovaps xmm4, [rsp+0x40]
0000786bc93df550  vmovaps xmm5, [rsp+0x50]
0000786bc93df556  vmovaps xmm7, [rsp+0x60]
0000786bc93df55c  vmovaps xmm8, [rsp+0x70]
0000786bc93df562  vmovaps xmm9, [rsp+0x80]
0000786bc93df56b  vmovaps xmm10, [rsp+0x90]
0000786bc93df574  vmovaps xmm11, [rsp+0xA0]
0000786bc93df57d  vmovaps xmm12, [rsp+0xB0]
0000786bc93df586  vmovaps xmm13, [rsp+0xC0]
0000786bc93df58f  vmovaps xmm14, [rsp+0xD0]
0000786bc93df598  vmovaps xmm15, [rsp+0xE0]
0000786bc93df5a1  add rsp, 0xF0
0000786bc93df5a8  pop r11
0000786bc93df5aa  pop r10
0000786bc93df5ac  pop r9
0000786bc93df5ae  pop r8
0000786bc93df5b0  pop rsi
0000786bc93df5b1  pop rdi
0000786bc93df5b2  pop rdx
0000786bc93df5b3  pop rcx
0000786bc93df5b4  pop rax
0000786bc93df5b5  add rsp, 0x08
0000786bc93df5b9  jmp 0x0000786BC93DC3D8
0000786bc93df5be  sub rsp, 0x08
0000786bc93df5c2  push rax
0000786bc93df5c3  push rcx
0000786bc93df5c4  push rdx
0000786bc93df5c5  push rdi
0000786bc93df5c6  push rsi
0000786bc93df5c7  push r8
0000786bc93df5c9  push r9
0000786bc93df5cb  push r10
0000786bc93df5cd  push r11
0000786bc93df5cf  sub rsp, 0xF0
0000786bc93df5d6  vmovaps [rsp], xmm0
0000786bc93df5db  vmovaps [rsp+0x10], xmm1
0000786bc93df5e1  vmovaps [rsp+0x20], xmm2
0000786bc93df5e7  vmovaps [rsp+0x30], xmm3
0000786bc93df5ed  vmovaps [rsp+0x40], xmm4
0000786bc93df5f3  vmovaps [rsp+0x50], xmm5
0000786bc93df5f9  vmovaps [rsp+0x60], xmm6
0000786bc93df5ff  vmovaps [rsp+0x70], xmm7
0000786bc93df605  vmovaps [rsp+0x80], xmm8
0000786bc93df60e  vmovaps [rsp+0x90], xmm9
0000786bc93df617  vmovaps [rsp+0xA0], xmm11
0000786bc93df620  vmovaps [rsp+0xB0], xmm12
0000786bc93df629  vmovaps [rsp+0xC0], xmm13
0000786bc93df632  vmovaps [rsp+0xD0], xmm14
0000786bc93df63b  vmovaps [rsp+0xE0], xmm15
0000786bc93df644  sub rsp, 0x30
0000786bc93df648  movaps [rsp], xmm10
0000786bc93df64d  movaps [rsp+0x10], xmm8
0000786bc93df653  movaps [rsp+0x20], xmm14
0000786bc93df659  lea rdi, [rsp]
0000786bc93df65d  mov esi, 0x00
0000786bc93df662  mov rax, 0x60810F6F7530
0000786bc93df66c  call rax
0000786bc93df66e  movaps xmm10, [rsp]
0000786bc93df673  add rsp, 0x30
0000786bc93df677  vmovaps xmm0, [rsp]
0000786bc93df67c  vmovaps xmm1, [rsp+0x10]
0000786bc93df682  vmovaps xmm2, [rsp+0x20]
0000786bc93df688  vmovaps xmm3, [rsp+0x30]
0000786bc93df68e  vmovaps xmm4, [rsp+0x40]
0000786bc93df694  vmovaps xmm5, [rsp+0x50]
0000786bc93df69a  vmovaps xmm6, [rsp+0x60]
0000786bc93df6a0  vmovaps xmm7, [rsp+0x70]
0000786bc93df6a6  vmovaps xmm8, [rsp+0x80]
0000786bc93df6af  vmovaps xmm9, [rsp+0x90]
0000786bc93df6b8  vmovaps xmm11, [rsp+0xA0]
0000786bc93df6c1  vmovaps xmm12, [rsp+0xB0]
0000786bc93df6ca  vmovaps xmm13, [rsp+0xC0]
0000786bc93df6d3  vmovaps xmm14, [rsp+0xD0]
0000786bc93df6dc  vmovaps xmm15, [rsp+0xE0]
0000786bc93df6e5  add rsp, 0xF0
0000786bc93df6ec  pop r11
0000786bc93df6ee  pop r10
0000786bc93df6f0  pop r9
0000786bc93df6f2  pop r8
0000786bc93df6f4  pop rsi
0000786bc93df6f5  pop rdi
0000786bc93df6f6  pop rdx
0000786bc93df6f7  pop rcx
0000786bc93df6f8  pop rax
0000786bc93df6f9  add rsp, 0x08
0000786bc93df6fd  jmp 0x0000786BC93DC3F8
0000786bc93df702  sub rsp, 0x08
0000786bc93df706  push rax
0000786bc93df707  push rcx
0000786bc93df708  push rdx
0000786bc93df709  push rdi
0000786bc93df70a  push rsi
0000786bc93df70b  push r8
0000786bc93df70d  push r9
0000786bc93df70f  push r10
0000786bc93df711  push r11
0000786bc93df713  sub rsp, 0xF0
0000786bc93df71a  vmovaps [rsp], xmm0
0000786bc93df71f  vmovaps [rsp+0x10], xmm1
0000786bc93df725  vmovaps [rsp+0x20], xmm2
0000786bc93df72b  vmovaps [rsp+0x30], xmm3
0000786bc93df731  vmovaps [rsp+0x40], xmm4
0000786bc93df737  vmovaps [rsp+0x50], xmm5
0000786bc93df73d  vmovaps [rsp+0x60], xmm6
0000786bc93df743  vmovaps [rsp+0x70], xmm7
0000786bc93df749  vmovaps [rsp+0x80], xmm8
0000786bc93df752  vmovaps [rsp+0x90], xmm9
0000786bc93df75b  vmovaps [rsp+0xA0], xmm10
0000786bc93df764  vmovaps [rsp+0xB0], xmm11
0000786bc93df76d  vmovaps [rsp+0xC0], xmm12
0000786bc93df776  vmovaps [rsp+0xD0], xmm13
0000786bc93df77f  vmovaps [rsp+0xE0], xmm15
0000786bc93df788  sub rsp, 0x30
0000786bc93df78c  movaps [rsp], xmm14
0000786bc93df791  movaps [rsp+0x10], xmm8
0000786bc93df797  movaps [rsp+0x20], xmm4
0000786bc93df79c  lea rdi, [rsp]
0000786bc93df7a0  mov esi, 0x00
0000786bc93df7a5  mov rax, 0x60810F6F7530
0000786bc93df7af  call rax
0000786bc93df7b1  movaps xmm14, [rsp]
0000786bc93df7b6  add rsp, 0x30
0000786bc93df7ba  vmovaps xmm0, [rsp]
0000786bc93df7bf  vmovaps xmm1, [rsp+0x10]
0000786bc93df7c5  vmovaps xmm2, [rsp+0x20]
0000786bc93df7cb  vmovaps xmm3, [rsp+0x30]
0000786bc93df7d1  vmovaps xmm4, [rsp+0x40]
0000786bc93df7d7  vmovaps xmm5, [rsp+0x50]
0000786bc93df7dd  vmovaps xmm6, [rsp+0x60]
0000786bc93df7e3  vmovaps xmm7, [rsp+0x70]
0000786bc93df7e9  vmovaps xmm8, [rsp+0x80]
0000786bc93df7f2  vmovaps xmm9, [rsp+0x90]
0000786bc93df7fb  vmovaps xmm10, [rsp+0xA0]
0000786bc93df804  vmovaps xmm11, [rsp+0xB0]
0000786bc93df80d  vmovaps xmm12, [rsp+0xC0]
0000786bc93df816  vmovaps xmm13, [rsp+0xD0]
0000786bc93df81f  vmovaps xmm15, [rsp+0xE0]
0000786bc93df828  add rsp, 0xF0
0000786bc93df82f  pop r11
0000786bc93df831  pop r10
0000786bc93df833  pop r9
0000786bc93df835  pop r8
0000786bc93df837  pop rsi
0000786bc93df838  pop rdi
0000786bc93df839  pop rdx
0000786bc93df83a  pop rcx
0000786bc93df83b  pop rax
0000786bc93df83c  add rsp, 0x08
0000786bc93df840  jmp 0x0000786BC93DC418
0000786bc93df845  sub rsp, 0x08
0000786bc93df849  push rax
0000786bc93df84a  push rcx
0000786bc93df84b  push rdx
0000786bc93df84c  push rdi
0000786bc93df84d  push rsi
0000786bc93df84e  push r8
0000786bc93df850  push r9
0000786bc93df852  push r10
0000786bc93df854  push r11
0000786bc93df856  sub rsp, 0xF0
0000786bc93df85d  vmovaps [rsp], xmm0
0000786bc93df862  vmovaps [rsp+0x10], xmm1
0000786bc93df868  vmovaps [rsp+0x20], xmm2
0000786bc93df86e  vmovaps [rsp+0x30], xmm3
0000786bc93df874  vmovaps [rsp+0x40], xmm5
0000786bc93df87a  vmovaps [rsp+0x50], xmm6
0000786bc93df880  vmovaps [rsp+0x60], xmm7
0000786bc93df886  vmovaps [rsp+0x70], xmm8
0000786bc93df88c  vmovaps [rsp+0x80], xmm9
0000786bc93df895  vmovaps [rsp+0x90], xmm10
0000786bc93df89e  vmovaps [rsp+0xA0], xmm11
0000786bc93df8a7  vmovaps [rsp+0xB0], xmm12
0000786bc93df8b0  vmovaps [rsp+0xC0], xmm13
0000786bc93df8b9  vmovaps [rsp+0xD0], xmm14
0000786bc93df8c2  vmovaps [rsp+0xE0], xmm15
0000786bc93df8cb  sub rsp, 0x30
0000786bc93df8cf  movaps [rsp], xmm4
0000786bc93df8d3  movaps [rsp+0x10], xmm13
0000786bc93df8d9  movaps [rsp+0x20], xmm8
0000786bc93df8df  lea rdi, [rsp]
0000786bc93df8e3  mov esi, 0x00
0000786bc93df8e8  mov rax, 0x60810F6F7530
0000786bc93df8f2  call rax
0000786bc93df8f4  movaps xmm4, [rsp]
0000786bc93df8f8  add rsp, 0x30
0000786bc93df8fc  vmovaps xmm0, [rsp]
0000786bc93df901  vmovaps xmm1, [rsp+0x10]
0000786bc93df907  vmovaps xmm2, [rsp+0x20]
0000786bc93df90d  vmovaps xmm3, [rsp+0x30]
0000786bc93df913  vmovaps xmm5, [rsp+0x40]
0000786bc93df919  vmovaps xmm6, [rsp+0x50]
0000786bc93df91f  vmovaps xmm7, [rsp+0x60]
0000786bc93df925  vmovaps xmm8, [rsp+0x70]
0000786bc93df92b  vmovaps xmm9, [rsp+0x80]
0000786bc93df934  vmovaps xmm10, [rsp+0x90]
0000786bc93df93d  vmovaps xmm11, [rsp+0xA0]
0000786bc93df946  vmovaps xmm12, [rsp+0xB0]
0000786bc93df94f  vmovaps xmm13, [rsp+0xC0]
0000786bc93df958  vmovaps xmm14, [rsp+0xD0]
0000786bc93df961  vmovaps xmm15, [rsp+0xE0]
0000786bc93df96a  add rsp, 0xF0
0000786bc93df971  pop r11
0000786bc93df973  pop r10
0000786bc93df975  pop r9
0000786bc93df977  pop r8
0000786bc93df979  pop rsi
0000786bc93df97a  pop rdi
0000786bc93df97b  pop rdx
0000786bc93df97c  pop rcx
0000786bc93df97d  pop rax
0000786bc93df97e  add rsp, 0x08
0000786bc93df982  jmp 0x0000786BC93DC43D
0000786bc93df987  sub rsp, 0x08
0000786bc93df98b  push rax
0000786bc93df98c  push rcx
0000786bc93df98d  push rdx
0000786bc93df98e  push rdi
0000786bc93df98f  push rsi
0000786bc93df990  push r8
0000786bc93df992  push r9
0000786bc93df994  push r10
0000786bc93df996  push r11
0000786bc93df998  sub rsp, 0xF0
0000786bc93df99f  vmovaps [rsp], xmm0
0000786bc93df9a4  vmovaps [rsp+0x10], xmm1
0000786bc93df9aa  vmovaps [rsp+0x20], xmm2
0000786bc93df9b0  vmovaps [rsp+0x30], xmm3
0000786bc93df9b6  vmovaps [rsp+0x40], xmm4
0000786bc93df9bc  vmovaps [rsp+0x50], xmm5
0000786bc93df9c2  vmovaps [rsp+0x60], xmm6
0000786bc93df9c8  vmovaps [rsp+0x70], xmm7
0000786bc93df9ce  vmovaps [rsp+0x80], xmm8
0000786bc93df9d7  vmovaps [rsp+0x90], xmm9
0000786bc93df9e0  vmovaps [rsp+0xA0], xmm10
0000786bc93df9e9  vmovaps [rsp+0xB0], xmm11
0000786bc93df9f2  vmovaps [rsp+0xC0], xmm12
0000786bc93df9fb  vmovaps [rsp+0xD0], xmm14
0000786bc93dfa04  vmovaps [rsp+0xE0], xmm15
0000786bc93dfa0d  sub rsp, 0x30
0000786bc93dfa11  movaps [rsp], xmm13
0000786bc93dfa16  movaps [rsp+0x10], xmm15
0000786bc93dfa1c  movaps [rsp+0x20], xmm9
0000786bc93dfa22  lea rdi, [rsp]
0000786bc93dfa26  mov esi, 0x00
0000786bc93dfa2b  mov rax, 0x60810F6F7530
0000786bc93dfa35  call rax
0000786bc93dfa37  movaps xmm13, [rsp]
0000786bc93dfa3c  add rsp, 0x30
0000786bc93dfa40  vmovaps xmm0, [rsp]
0000786bc93dfa45  vmovaps xmm1, [rsp+0x10]
0000786bc93dfa4b  vmovaps xmm2, [rsp+0x20]
0000786bc93dfa51  vmovaps xmm3, [rsp+0x30]
0000786bc93dfa57  vmovaps xmm4, [rsp+0x40]
0000786bc93dfa5d  vmovaps xmm5, [rsp+0x50]
0000786bc93dfa63  vmovaps xmm6, [rsp+0x60]
0000786bc93dfa69  vmovaps xmm7, [rsp+0x70]
0000786bc93dfa6f  vmovaps xmm8, [rsp+0x80]
0000786bc93dfa78  vmovaps xmm9, [rsp+0x90]
0000786bc93dfa81  vmovaps xmm10, [rsp+0xA0]
0000786bc93dfa8a  vmovaps xmm11, [rsp+0xB0]
0000786bc93dfa93  vmovaps xmm12, [rsp+0xC0]
0000786bc93dfa9c  vmovaps xmm14, [rsp+0xD0]
0000786bc93dfaa5  vmovaps xmm15, [rsp+0xE0]
0000786bc93dfaae  add rsp, 0xF0
0000786bc93dfab5  pop r11
0000786bc93dfab7  pop r10
0000786bc93dfab9  pop r9
0000786bc93dfabb  pop r8
0000786bc93dfabd  pop rsi
0000786bc93dfabe  pop rdi
0000786bc93dfabf  pop rdx
0000786bc93dfac0  pop rcx
0000786bc93dfac1  pop rax
0000786bc93dfac2  add rsp, 0x08
0000786bc93dfac6  jmp 0x0000786BC93DC458
0000786bc93dfacb  sub rsp, 0x08
0000786bc93dfacf  push rax
0000786bc93dfad0  push rcx
0000786bc93dfad1  push rdx
0000786bc93dfad2  push rdi
0000786bc93dfad3  push rsi
0000786bc93dfad4  push r8
0000786bc93dfad6  push r9
0000786bc93dfad8  push r10
0000786bc93dfada  push r11
0000786bc93dfadc  sub rsp, 0xF0
0000786bc93dfae3  vmovaps [rsp], xmm0
0000786bc93dfae8  vmovaps [rsp+0x10], xmm1
0000786bc93dfaee  vmovaps [rsp+0x20], xmm2
0000786bc93dfaf4  vmovaps [rsp+0x30], xmm3
0000786bc93dfafa  vmovaps [rsp+0x40], xmm4
0000786bc93dfb00  vmovaps [rsp+0x50], xmm5
0000786bc93dfb06  vmovaps [rsp+0x60], xmm6
0000786bc93dfb0c  vmovaps [rsp+0x70], xmm7
0000786bc93dfb12  vmovaps [rsp+0x80], xmm8
0000786bc93dfb1b  vmovaps [rsp+0x90], xmm9
0000786bc93dfb24  vmovaps [rsp+0xA0], xmm10
0000786bc93dfb2d  vmovaps [rsp+0xB0], xmm11
0000786bc93dfb36  vmovaps [rsp+0xC0], xmm12
0000786bc93dfb3f  vmovaps [rsp+0xD0], xmm13
0000786bc93dfb48  vmovaps [rsp+0xE0], xmm14
0000786bc93dfb51  sub rsp, 0x30
0000786bc93dfb55  movaps [rsp], xmm15
0000786bc93dfb5a  movaps [rsp+0x10], xmm1
0000786bc93dfb5f  movaps [rsp+0x20], xmm5
0000786bc93dfb64  lea rdi, [rsp]
0000786bc93dfb68  mov esi, 0x00
0000786bc93dfb6d  mov rax, 0x60810F6F7530
0000786bc93dfb77  call rax
0000786bc93dfb79  movaps xmm15, [rsp]
0000786bc93dfb7e  add rsp, 0x30
0000786bc93dfb82  vmovaps xmm0, [rsp]
0000786bc93dfb87  vmovaps xmm1, [rsp+0x10]
0000786bc93dfb8d  vmovaps xmm2, [rsp+0x20]
0000786bc93dfb93  vmovaps xmm3, [rsp+0x30]
0000786bc93dfb99  vmovaps xmm4, [rsp+0x40]
0000786bc93dfb9f  vmovaps xmm5, [rsp+0x50]
0000786bc93dfba5  vmovaps xmm6, [rsp+0x60]
0000786bc93dfbab  vmovaps xmm7, [rsp+0x70]
0000786bc93dfbb1  vmovaps xmm8, [rsp+0x80]
0000786bc93dfbba  vmovaps xmm9, [rsp+0x90]
0000786bc93dfbc3  vmovaps xmm10, [rsp+0xA0]
0000786bc93dfbcc  vmovaps xmm11, [rsp+0xB0]
0000786bc93dfbd5  vmovaps xmm12, [rsp+0xC0]
0000786bc93dfbde  vmovaps xmm13, [rsp+0xD0]
0000786bc93dfbe7  vmovaps xmm14, [rsp+0xE0]
0000786bc93dfbf0  add rsp, 0xF0
0000786bc93dfbf7  pop r11
0000786bc93dfbf9  pop r10
0000786bc93dfbfb  pop r9
0000786bc93dfbfd  pop r8
0000786bc93dfbff  pop rsi
0000786bc93dfc00  pop rdi
0000786bc93dfc01  pop rdx
0000786bc93dfc02  pop rcx
0000786bc93dfc03  pop rax
0000786bc93dfc04  add rsp, 0x08
0000786bc93dfc08  jmp 0x0000786BC93DC473
0000786bc93dfc0d  call 0x0000786BC92B52F0
0000786bc93dfc12  jmp 0x0000786BC93DC4CE
0000786bc93dfc17  sub rsp, 0x08
0000786bc93dfc1b  push rax
0000786bc93dfc1c  push rcx
0000786bc93dfc1d  push rdx
0000786bc93dfc1e  push rdi
0000786bc93dfc1f  push rsi
0000786bc93dfc20  push r8
0000786bc93dfc22  push r9
0000786bc93dfc24  push r10
0000786bc93dfc26  push r11
0000786bc93dfc28  sub rsp, 0xF0
0000786bc93dfc2f  vmovaps [rsp], xmm0
0000786bc93dfc34  vmovaps [rsp+0x10], xmm1
0000786bc93dfc3a  vmovaps [rsp+0x20], xmm2
0000786bc93dfc40  vmovaps [rsp+0x30], xmm3
0000786bc93dfc46  vmovaps [rsp+0x40], xmm4
0000786bc93dfc4c  vmovaps [rsp+0x50], xmm5
0000786bc93dfc52  vmovaps [rsp+0x60], xmm6
0000786bc93dfc58  vmovaps [rsp+0x70], xmm7
0000786bc93dfc5e  vmovaps [rsp+0x80], xmm8
0000786bc93dfc67  vmovaps [rsp+0x90], xmm10
0000786bc93dfc70  vmovaps [rsp+0xA0], xmm11
0000786bc93dfc79  vmovaps [rsp+0xB0], xmm12
0000786bc93dfc82  vmovaps [rsp+0xC0], xmm13
0000786bc93dfc8b  vmovaps [rsp+0xD0], xmm14
0000786bc93dfc94  vmovaps [rsp+0xE0], xmm15
0000786bc93dfc9d  sub rsp, 0x30
0000786bc93dfca1  movaps [rsp], xmm9
0000786bc93dfca6  movaps [rsp+0x10], xmm8
0000786bc93dfcac  movaps [rsp+0x20], xmm11
0000786bc93dfcb2  lea rdi, [rsp]
0000786bc93dfcb6  mov esi, 0x00
0000786bc93dfcbb  mov rax, 0x60810F6F7530
0000786bc93dfcc5  call rax
0000786bc93dfcc7  movaps xmm9, [rsp]
0000786bc93dfccc  add rsp, 0x30
0000786bc93dfcd0  vmovaps xmm0, [rsp]
0000786bc93dfcd5  vmovaps xmm1, [rsp+0x10]
0000786bc93dfcdb  vmovaps xmm2, [rsp+0x20]
0000786bc93dfce1  vmovaps xmm3, [rsp+0x30]
0000786bc93dfce7  vmovaps xmm4, [rsp+0x40]
0000786bc93dfced  vmovaps xmm5, [rsp+0x50]
0000786bc93dfcf3  vmovaps xmm6, [rsp+0x60]
0000786bc93dfcf9  vmovaps xmm7, [rsp+0x70]
0000786bc93dfcff  vmovaps xmm8, [rsp+0x80]
0000786bc93dfd08  vmovaps xmm10, [rsp+0x90]
0000786bc93dfd11  vmovaps xmm11, [rsp+0xA0]
0000786bc93dfd1a  vmovaps xmm12, [rsp+0xB0]
0000786bc93dfd23  vmovaps xmm13, [rsp+0xC0]
0000786bc93dfd2c  vmovaps xmm14, [rsp+0xD0]
0000786bc93dfd35  vmovaps xmm15, [rsp+0xE0]
0000786bc93dfd3e  add rsp, 0xF0
0000786bc93dfd45  pop r11
0000786bc93dfd47  pop r10
0000786bc93dfd49  pop r9
0000786bc93dfd4b  pop r8
0000786bc93dfd4d  pop rsi
0000786bc93dfd4e  pop rdi
0000786bc93dfd4f  pop rdx
0000786bc93dfd50  pop rcx
0000786bc93dfd51  pop rax
0000786bc93dfd52  add rsp, 0x08
0000786bc93dfd56  jmp 0x0000786BC93DC505
0000786bc93dfd5b  sub rsp, 0x08
0000786bc93dfd5f  push rax
0000786bc93dfd60  push rcx
0000786bc93dfd61  push rdx
0000786bc93dfd62  push rdi
0000786bc93dfd63  push rsi
0000786bc93dfd64  push r8
0000786bc93dfd66  push r9
0000786bc93dfd68  push r10
0000786bc93dfd6a  push r11
0000786bc93dfd6c  sub rsp, 0xF0
0000786bc93dfd73  vmovaps [rsp], xmm0
0000786bc93dfd78  vmovaps [rsp+0x10], xmm1
0000786bc93dfd7e  vmovaps [rsp+0x20], xmm2
0000786bc93dfd84  vmovaps [rsp+0x30], xmm3
0000786bc93dfd8a  vmovaps [rsp+0x40], xmm4
0000786bc93dfd90  vmovaps [rsp+0x50], xmm5
0000786bc93dfd96  vmovaps [rsp+0x60], xmm6
0000786bc93dfd9c  vmovaps [rsp+0x70], xmm7
0000786bc93dfda2  vmovaps [rsp+0x80], xmm8
0000786bc93dfdab  vmovaps [rsp+0x90], xmm9
0000786bc93dfdb4  vmovaps [rsp+0xA0], xmm10
0000786bc93dfdbd  vmovaps [rsp+0xB0], xmm12
0000786bc93dfdc6  vmovaps [rsp+0xC0], xmm13
0000786bc93dfdcf  vmovaps [rsp+0xD0], xmm14
0000786bc93dfdd8  vmovaps [rsp+0xE0], xmm15
0000786bc93dfde1  sub rsp, 0x30
0000786bc93dfde5  movaps [rsp], xmm11
0000786bc93dfdea  movaps [rsp+0x10], xmm10
0000786bc93dfdf0  movaps [rsp+0x20], xmm6
0000786bc93dfdf5  lea rdi, [rsp]
0000786bc93dfdf9  mov esi, 0x00
0000786bc93dfdfe  mov rax, 0x60810F6F7530
0000786bc93dfe08  call rax
0000786bc93dfe0a  movaps xmm11, [rsp]
0000786bc93dfe0f  add rsp, 0x30
0000786bc93dfe13  vmovaps xmm0, [rsp]
0000786bc93dfe18  vmovaps xmm1, [rsp+0x10]
0000786bc93dfe1e  vmovaps xmm2, [rsp+0x20]
0000786bc93dfe24  vmovaps xmm3, [rsp+0x30]
0000786bc93dfe2a  vmovaps xmm4, [rsp+0x40]
0000786bc93dfe30  vmovaps xmm5, [rsp+0x50]
0000786bc93dfe36  vmovaps xmm6, [rsp+0x60]
0000786bc93dfe3c  vmovaps xmm7, [rsp+0x70]
0000786bc93dfe42  vmovaps xmm8, [rsp+0x80]
0000786bc93dfe4b  vmovaps xmm9, [rsp+0x90]
0000786bc93dfe54  vmovaps xmm10, [rsp+0xA0]
0000786bc93dfe5d  vmovaps xmm12, [rsp+0xB0]
0000786bc93dfe66  vmovaps xmm13, [rsp+0xC0]
0000786bc93dfe6f  vmovaps xmm14, [rsp+0xD0]
0000786bc93dfe78  vmovaps xmm15, [rsp+0xE0]
0000786bc93dfe81  add rsp, 0xF0
0000786bc93dfe88  pop r11
0000786bc93dfe8a  pop r10
0000786bc93dfe8c  pop r9
0000786bc93dfe8e  pop r8
0000786bc93dfe90  pop rsi
0000786bc93dfe91  pop rdi
0000786bc93dfe92  pop rdx
0000786bc93dfe93  pop rcx
0000786bc93dfe94  pop rax
0000786bc93dfe95  add rsp, 0x08
0000786bc93dfe99  jmp 0x0000786BC93DC520
0000786bc93dfe9e  sub rsp, 0x08
0000786bc93dfea2  push rax
0000786bc93dfea3  push rcx
0000786bc93dfea4  push rdx
0000786bc93dfea5  push rdi
0000786bc93dfea6  push rsi
0000786bc93dfea7  push r8
0000786bc93dfea9  push r9
0000786bc93dfeab  push r10
0000786bc93dfead  push r11
0000786bc93dfeaf  sub rsp, 0xF0
0000786bc93dfeb6  vmovaps [rsp], xmm0
0000786bc93dfebb  vmovaps [rsp+0x10], xmm1
0000786bc93dfec1  vmovaps [rsp+0x20], xmm2
0000786bc93dfec7  vmovaps [rsp+0x30], xmm3
0000786bc93dfecd  vmovaps [rsp+0x40], xmm4
0000786bc93dfed3  vmovaps [rsp+0x50], xmm5
0000786bc93dfed9  vmovaps [rsp+0x60], xmm6
0000786bc93dfedf  vmovaps [rsp+0x70], xmm7
0000786bc93dfee5  vmovaps [rsp+0x80], xmm8
0000786bc93dfeee  vmovaps [rsp+0x90], xmm9
0000786bc93dfef7  vmovaps [rsp+0xA0], xmm11
0000786bc93dff00  vmovaps [rsp+0xB0], xmm12
0000786bc93dff09  vmovaps [rsp+0xC0], xmm13
0000786bc93dff12  vmovaps [rsp+0xD0], xmm14
0000786bc93dff1b  vmovaps [rsp+0xE0], xmm15
0000786bc93dff24  sub rsp, 0x30
0000786bc93dff28  movaps [rsp], xmm10
0000786bc93dff2d  movaps [rsp+0x10], xmm14
0000786bc93dff33  movaps [rsp+0x20], xmm4
0000786bc93dff38  lea rdi, [rsp]
0000786bc93dff3c  mov esi, 0x00
0000786bc93dff41  mov rax, 0x60810F6F7530
0000786bc93dff4b  call rax
0000786bc93dff4d  movaps xmm10, [rsp]
0000786bc93dff52  add rsp, 0x30
0000786bc93dff56  vmovaps xmm0, [rsp]
0000786bc93dff5b  vmovaps xmm1, [rsp+0x10]
0000786bc93dff61  vmovaps xmm2, [rsp+0x20]
0000786bc93dff67  vmovaps xmm3, [rsp+0x30]
0000786bc93dff6d  vmovaps xmm4, [rsp+0x40]
0000786bc93dff73  vmovaps xmm5, [rsp+0x50]
0000786bc93dff79  vmovaps xmm6, [rsp+0x60]
0000786bc93dff7f  vmovaps xmm7, [rsp+0x70]
0000786bc93dff85  vmovaps xmm8, [rsp+0x80]
0000786bc93dff8e  vmovaps xmm9, [rsp+0x90]
0000786bc93dff97  vmovaps xmm11, [rsp+0xA0]
0000786bc93dffa0  vmovaps xmm12, [rsp+0xB0]
0000786bc93dffa9  vmovaps xmm13, [rsp+0xC0]
0000786bc93dffb2  vmovaps xmm14, [rsp+0xD0]
0000786bc93dffbb  vmovaps xmm15, [rsp+0xE0]
0000786bc93dffc4  add rsp, 0xF0
0000786bc93dffcb  pop r11
0000786bc93dffcd  pop r10
0000786bc93dffcf  pop r9
0000786bc93dffd1  pop r8
0000786bc93dffd3  pop rsi
0000786bc93dffd4  pop rdi
0000786bc93dffd5  pop rdx
0000786bc93dffd6  pop rcx
0000786bc93dffd7  pop rax
0000786bc93dffd8  add rsp, 0x08
0000786bc93dffdc  jmp 0x0000786BC93DC53B
0000786bc93dffe1  sub rsp, 0x08
0000786bc93dffe5  push rax
0000786bc93dffe6  push rcx
0000786bc93dffe7  push rdx
0000786bc93dffe8  push rdi
0000786bc93dffe9  push rsi
0000786bc93dffea  push r8
0000786bc93dffec  push r9
0000786bc93dffee  push r10
0000786bc93dfff0  push r11
0000786bc93dfff2  sub rsp, 0xF0
0000786bc93dfff9  vmovaps [rsp], xmm0
0000786bc93dfffe  vmovaps [rsp+0x10], xmm1
0000786bc93e0004  vmovaps [rsp+0x20], xmm2
0000786bc93e000a  vmovaps [rsp+0x30], xmm3
0000786bc93e0010  vmovaps [rsp+0x40], xmm4
0000786bc93e0016  vmovaps [rsp+0x50], xmm5
0000786bc93e001c  vmovaps [rsp+0x60], xmm6
0000786bc93e0022  vmovaps [rsp+0x70], xmm7
0000786bc93e0028  vmovaps [rsp+0x80], xmm9
0000786bc93e0031  vmovaps [rsp+0x90], xmm10
0000786bc93e003a  vmovaps [rsp+0xA0], xmm11
0000786bc93e0043  vmovaps [rsp+0xB0], xmm12
0000786bc93e004c  vmovaps [rsp+0xC0], xmm13
0000786bc93e0055  vmovaps [rsp+0xD0], xmm14
0000786bc93e005e  vmovaps [rsp+0xE0], xmm15
0000786bc93e0067  sub rsp, 0x30
0000786bc93e006b  movaps [rsp], xmm8
0000786bc93e0070  movaps [rsp+0x10], xmm1
0000786bc93e0075  movaps [rsp+0x20], xmm14
0000786bc93e007b  lea rdi, [rsp]
0000786bc93e007f  mov esi, 0x00
0000786bc93e0084  mov rax, 0x60810F6F7530
0000786bc93e008e  call rax
0000786bc93e0090  movaps xmm8, [rsp]
0000786bc93e0095  add rsp, 0x30
0000786bc93e0099  vmovaps xmm0, [rsp]
0000786bc93e009e  vmovaps xmm1, [rsp+0x10]
0000786bc93e00a4  vmovaps xmm2, [rsp+0x20]
0000786bc93e00aa  vmovaps xmm3, [rsp+0x30]
0000786bc93e00b0  vmovaps xmm4, [rsp+0x40]
0000786bc93e00b6  vmovaps xmm5, [rsp+0x50]
0000786bc93e00bc  vmovaps xmm6, [rsp+0x60]
0000786bc93e00c2  vmovaps xmm7, [rsp+0x70]
0000786bc93e00c8  vmovaps xmm9, [rsp+0x80]
0000786bc93e00d1  vmovaps xmm10, [rsp+0x90]
0000786bc93e00da  vmovaps xmm11, [rsp+0xA0]
0000786bc93e00e3  vmovaps xmm12, [rsp+0xB0]
0000786bc93e00ec  vmovaps xmm13, [rsp+0xC0]
0000786bc93e00f5  vmovaps xmm14, [rsp+0xD0]
0000786bc93e00fe  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0107  add rsp, 0xF0
0000786bc93e010e  pop r11
0000786bc93e0110  pop r10
0000786bc93e0112  pop r9
0000786bc93e0114  pop r8
0000786bc93e0116  pop rsi
0000786bc93e0117  pop rdi
0000786bc93e0118  pop rdx
0000786bc93e0119  pop rcx
0000786bc93e011a  pop rax
0000786bc93e011b  add rsp, 0x08
0000786bc93e011f  jmp 0x0000786BC93DC561
0000786bc93e0124  sub rsp, 0x08
0000786bc93e0128  push rax
0000786bc93e0129  push rcx
0000786bc93e012a  push rdx
0000786bc93e012b  push rdi
0000786bc93e012c  push rsi
0000786bc93e012d  push r8
0000786bc93e012f  push r9
0000786bc93e0131  push r10
0000786bc93e0133  push r11
0000786bc93e0135  sub rsp, 0xF0
0000786bc93e013c  vmovaps [rsp], xmm0
0000786bc93e0141  vmovaps [rsp+0x10], xmm1
0000786bc93e0147  vmovaps [rsp+0x20], xmm2
0000786bc93e014d  vmovaps [rsp+0x30], xmm3
0000786bc93e0153  vmovaps [rsp+0x40], xmm4
0000786bc93e0159  vmovaps [rsp+0x50], xmm5
0000786bc93e015f  vmovaps [rsp+0x60], xmm7
0000786bc93e0165  vmovaps [rsp+0x70], xmm8
0000786bc93e016b  vmovaps [rsp+0x80], xmm9
0000786bc93e0174  vmovaps [rsp+0x90], xmm10
0000786bc93e017d  vmovaps [rsp+0xA0], xmm11
0000786bc93e0186  vmovaps [rsp+0xB0], xmm12
0000786bc93e018f  vmovaps [rsp+0xC0], xmm13
0000786bc93e0198  vmovaps [rsp+0xD0], xmm14
0000786bc93e01a1  vmovaps [rsp+0xE0], xmm15
0000786bc93e01aa  sub rsp, 0x30
0000786bc93e01ae  movaps [rsp], xmm6
0000786bc93e01b2  movaps [rsp+0x10], xmm1
0000786bc93e01b7  movaps [rsp+0x20], xmm14
0000786bc93e01bd  lea rdi, [rsp]
0000786bc93e01c1  mov esi, 0x00
0000786bc93e01c6  mov rax, 0x60810F6F7530
0000786bc93e01d0  call rax
0000786bc93e01d2  movaps xmm6, [rsp]
0000786bc93e01d6  add rsp, 0x30
0000786bc93e01da  vmovaps xmm0, [rsp]
0000786bc93e01df  vmovaps xmm1, [rsp+0x10]
0000786bc93e01e5  vmovaps xmm2, [rsp+0x20]
0000786bc93e01eb  vmovaps xmm3, [rsp+0x30]
0000786bc93e01f1  vmovaps xmm4, [rsp+0x40]
0000786bc93e01f7  vmovaps xmm5, [rsp+0x50]
0000786bc93e01fd  vmovaps xmm7, [rsp+0x60]
0000786bc93e0203  vmovaps xmm8, [rsp+0x70]
0000786bc93e0209  vmovaps xmm9, [rsp+0x80]
0000786bc93e0212  vmovaps xmm10, [rsp+0x90]
0000786bc93e021b  vmovaps xmm11, [rsp+0xA0]
0000786bc93e0224  vmovaps xmm12, [rsp+0xB0]
0000786bc93e022d  vmovaps xmm13, [rsp+0xC0]
0000786bc93e0236  vmovaps xmm14, [rsp+0xD0]
0000786bc93e023f  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0248  add rsp, 0xF0
0000786bc93e024f  pop r11
0000786bc93e0251  pop r10
0000786bc93e0253  pop r9
0000786bc93e0255  pop r8
0000786bc93e0257  pop rsi
0000786bc93e0258  pop rdi
0000786bc93e0259  pop rdx
0000786bc93e025a  pop rcx
0000786bc93e025b  pop rax
0000786bc93e025c  add rsp, 0x08
0000786bc93e0260  jmp 0x0000786BC93DC58D
0000786bc93e0265  sub rsp, 0x08
0000786bc93e0269  push rax
0000786bc93e026a  push rcx
0000786bc93e026b  push rdx
0000786bc93e026c  push rdi
0000786bc93e026d  push rsi
0000786bc93e026e  push r8
0000786bc93e0270  push r9
0000786bc93e0272  push r10
0000786bc93e0274  push r11
0000786bc93e0276  sub rsp, 0xF0
0000786bc93e027d  vmovaps [rsp], xmm0
0000786bc93e0282  vmovaps [rsp+0x10], xmm1
0000786bc93e0288  vmovaps [rsp+0x20], xmm2
0000786bc93e028e  vmovaps [rsp+0x30], xmm3
0000786bc93e0294  vmovaps [rsp+0x40], xmm4
0000786bc93e029a  vmovaps [rsp+0x50], xmm5
0000786bc93e02a0  vmovaps [rsp+0x60], xmm6
0000786bc93e02a6  vmovaps [rsp+0x70], xmm7
0000786bc93e02ac  vmovaps [rsp+0x80], xmm8
0000786bc93e02b5  vmovaps [rsp+0x90], xmm9
0000786bc93e02be  vmovaps [rsp+0xA0], xmm10
0000786bc93e02c7  vmovaps [rsp+0xB0], xmm11
0000786bc93e02d0  vmovaps [rsp+0xC0], xmm12
0000786bc93e02d9  vmovaps [rsp+0xD0], xmm13
0000786bc93e02e2  vmovaps [rsp+0xE0], xmm15
0000786bc93e02eb  sub rsp, 0x30
0000786bc93e02ef  movaps [rsp], xmm14
0000786bc93e02f4  movaps [rsp+0x10], xmm12
0000786bc93e02fa  movaps [rsp+0x20], xmm1
0000786bc93e02ff  lea rdi, [rsp]
0000786bc93e0303  mov esi, 0x00
0000786bc93e0308  mov rax, 0x60810F6F7530
0000786bc93e0312  call rax
0000786bc93e0314  movaps xmm14, [rsp]
0000786bc93e0319  add rsp, 0x30
0000786bc93e031d  vmovaps xmm0, [rsp]
0000786bc93e0322  vmovaps xmm1, [rsp+0x10]
0000786bc93e0328  vmovaps xmm2, [rsp+0x20]
0000786bc93e032e  vmovaps xmm3, [rsp+0x30]
0000786bc93e0334  vmovaps xmm4, [rsp+0x40]
0000786bc93e033a  vmovaps xmm5, [rsp+0x50]
0000786bc93e0340  vmovaps xmm6, [rsp+0x60]
0000786bc93e0346  vmovaps xmm7, [rsp+0x70]
0000786bc93e034c  vmovaps xmm8, [rsp+0x80]
0000786bc93e0355  vmovaps xmm9, [rsp+0x90]
0000786bc93e035e  vmovaps xmm10, [rsp+0xA0]
0000786bc93e0367  vmovaps xmm11, [rsp+0xB0]
0000786bc93e0370  vmovaps xmm12, [rsp+0xC0]
0000786bc93e0379  vmovaps xmm13, [rsp+0xD0]
0000786bc93e0382  vmovaps xmm15, [rsp+0xE0]
0000786bc93e038b  add rsp, 0xF0
0000786bc93e0392  pop r11
0000786bc93e0394  pop r10
0000786bc93e0396  pop r9
0000786bc93e0398  pop r8
0000786bc93e039a  pop rsi
0000786bc93e039b  pop rdi
0000786bc93e039c  pop rdx
0000786bc93e039d  pop rcx
0000786bc93e039e  pop rax
0000786bc93e039f  add rsp, 0x08
0000786bc93e03a3  jmp 0x0000786BC93DC5B3
0000786bc93e03a8  sub rsp, 0x08
0000786bc93e03ac  push rax
0000786bc93e03ad  push rcx
0000786bc93e03ae  push rdx
0000786bc93e03af  push rdi
0000786bc93e03b0  push rsi
0000786bc93e03b1  push r8
0000786bc93e03b3  push r9
0000786bc93e03b5  push r10
0000786bc93e03b7  push r11
0000786bc93e03b9  sub rsp, 0xF0
0000786bc93e03c0  vmovaps [rsp], xmm0
0000786bc93e03c5  vmovaps [rsp+0x10], xmm2
0000786bc93e03cb  vmovaps [rsp+0x20], xmm3
0000786bc93e03d1  vmovaps [rsp+0x30], xmm4
0000786bc93e03d7  vmovaps [rsp+0x40], xmm5
0000786bc93e03dd  vmovaps [rsp+0x50], xmm6
0000786bc93e03e3  vmovaps [rsp+0x60], xmm7
0000786bc93e03e9  vmovaps [rsp+0x70], xmm8
0000786bc93e03ef  vmovaps [rsp+0x80], xmm9
0000786bc93e03f8  vmovaps [rsp+0x90], xmm10
0000786bc93e0401  vmovaps [rsp+0xA0], xmm11
0000786bc93e040a  vmovaps [rsp+0xB0], xmm12
0000786bc93e0413  vmovaps [rsp+0xC0], xmm13
0000786bc93e041c  vmovaps [rsp+0xD0], xmm14
0000786bc93e0425  vmovaps [rsp+0xE0], xmm15
0000786bc93e042e  sub rsp, 0x30
0000786bc93e0432  movaps [rsp], xmm1
0000786bc93e0436  movaps [rsp+0x10], xmm13
0000786bc93e043c  movaps [rsp+0x20], xmm9
0000786bc93e0442  lea rdi, [rsp]
0000786bc93e0446  mov esi, 0x00
0000786bc93e044b  mov rax, 0x60810F6F7530
0000786bc93e0455  call rax
0000786bc93e0457  movaps xmm1, [rsp]
0000786bc93e045b  add rsp, 0x30
0000786bc93e045f  vmovaps xmm0, [rsp]
0000786bc93e0464  vmovaps xmm2, [rsp+0x10]
0000786bc93e046a  vmovaps xmm3, [rsp+0x20]
0000786bc93e0470  vmovaps xmm4, [rsp+0x30]
0000786bc93e0476  vmovaps xmm5, [rsp+0x40]
0000786bc93e047c  vmovaps xmm6, [rsp+0x50]
0000786bc93e0482  vmovaps xmm7, [rsp+0x60]
0000786bc93e0488  vmovaps xmm8, [rsp+0x70]
0000786bc93e048e  vmovaps xmm9, [rsp+0x80]
0000786bc93e0497  vmovaps xmm10, [rsp+0x90]
0000786bc93e04a0  vmovaps xmm11, [rsp+0xA0]
0000786bc93e04a9  vmovaps xmm12, [rsp+0xB0]
0000786bc93e04b2  vmovaps xmm13, [rsp+0xC0]
0000786bc93e04bb  vmovaps xmm14, [rsp+0xD0]
0000786bc93e04c4  vmovaps xmm15, [rsp+0xE0]
0000786bc93e04cd  add rsp, 0xF0
0000786bc93e04d4  pop r11
0000786bc93e04d6  pop r10
0000786bc93e04d8  pop r9
0000786bc93e04da  pop r8
0000786bc93e04dc  pop rsi
0000786bc93e04dd  pop rdi
0000786bc93e04de  pop rdx
0000786bc93e04df  pop rcx
0000786bc93e04e0  pop rax
0000786bc93e04e1  add rsp, 0x08
0000786bc93e04e5  jmp 0x0000786BC93DC5CD
0000786bc93e04ea  sub rsp, 0x08
0000786bc93e04ee  push rax
0000786bc93e04ef  push rcx
0000786bc93e04f0  push rdx
0000786bc93e04f1  push rdi
0000786bc93e04f2  push rsi
0000786bc93e04f3  push r8
0000786bc93e04f5  push r9
0000786bc93e04f7  push r10
0000786bc93e04f9  push r11
0000786bc93e04fb  sub rsp, 0xF0
0000786bc93e0502  vmovaps [rsp], xmm0
0000786bc93e0507  vmovaps [rsp+0x10], xmm1
0000786bc93e050d  vmovaps [rsp+0x20], xmm2
0000786bc93e0513  vmovaps [rsp+0x30], xmm3
0000786bc93e0519  vmovaps [rsp+0x40], xmm4
0000786bc93e051f  vmovaps [rsp+0x50], xmm5
0000786bc93e0525  vmovaps [rsp+0x60], xmm6
0000786bc93e052b  vmovaps [rsp+0x70], xmm7
0000786bc93e0531  vmovaps [rsp+0x80], xmm8
0000786bc93e053a  vmovaps [rsp+0x90], xmm9
0000786bc93e0543  vmovaps [rsp+0xA0], xmm10
0000786bc93e054c  vmovaps [rsp+0xB0], xmm11
0000786bc93e0555  vmovaps [rsp+0xC0], xmm13
0000786bc93e055e  vmovaps [rsp+0xD0], xmm14
0000786bc93e0567  vmovaps [rsp+0xE0], xmm15
0000786bc93e0570  sub rsp, 0x30
0000786bc93e0574  movaps [rsp], xmm12
0000786bc93e0579  movaps [rsp+0x10], xmm7
0000786bc93e057e  movaps [rsp+0x20], xmm13
0000786bc93e0584  lea rdi, [rsp]
0000786bc93e0588  mov esi, 0x00
0000786bc93e058d  mov rax, 0x60810F6F7530
0000786bc93e0597  call rax
0000786bc93e0599  movaps xmm12, [rsp]
0000786bc93e059e  add rsp, 0x30
0000786bc93e05a2  vmovaps xmm0, [rsp]
0000786bc93e05a7  vmovaps xmm1, [rsp+0x10]
0000786bc93e05ad  vmovaps xmm2, [rsp+0x20]
0000786bc93e05b3  vmovaps xmm3, [rsp+0x30]
0000786bc93e05b9  vmovaps xmm4, [rsp+0x40]
0000786bc93e05bf  vmovaps xmm5, [rsp+0x50]
0000786bc93e05c5  vmovaps xmm6, [rsp+0x60]
0000786bc93e05cb  vmovaps xmm7, [rsp+0x70]
0000786bc93e05d1  vmovaps xmm8, [rsp+0x80]
0000786bc93e05da  vmovaps xmm9, [rsp+0x90]
0000786bc93e05e3  vmovaps xmm10, [rsp+0xA0]
0000786bc93e05ec  vmovaps xmm11, [rsp+0xB0]
0000786bc93e05f5  vmovaps xmm13, [rsp+0xC0]
0000786bc93e05fe  vmovaps xmm14, [rsp+0xD0]
0000786bc93e0607  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0610  add rsp, 0xF0
0000786bc93e0617  pop r11
0000786bc93e0619  pop r10
0000786bc93e061b  pop r9
0000786bc93e061d  pop r8
0000786bc93e061f  pop rsi
0000786bc93e0620  pop rdi
0000786bc93e0621  pop rdx
0000786bc93e0622  pop rcx
0000786bc93e0623  pop rax
0000786bc93e0624  add rsp, 0x08
0000786bc93e0628  jmp 0x0000786BC93DC5F4
0000786bc93e062d  sub rsp, 0x08
0000786bc93e0631  push rax
0000786bc93e0632  push rcx
0000786bc93e0633  push rdx
0000786bc93e0634  push rdi
0000786bc93e0635  push rsi
0000786bc93e0636  push r8
0000786bc93e0638  push r9
0000786bc93e063a  push r10
0000786bc93e063c  push r11
0000786bc93e063e  sub rsp, 0xF0
0000786bc93e0645  vmovaps [rsp], xmm0
0000786bc93e064a  vmovaps [rsp+0x10], xmm1
0000786bc93e0650  vmovaps [rsp+0x20], xmm2
0000786bc93e0656  vmovaps [rsp+0x30], xmm3
0000786bc93e065c  vmovaps [rsp+0x40], xmm4
0000786bc93e0662  vmovaps [rsp+0x50], xmm5
0000786bc93e0668  vmovaps [rsp+0x60], xmm6
0000786bc93e066e  vmovaps [rsp+0x70], xmm7
0000786bc93e0674  vmovaps [rsp+0x80], xmm8
0000786bc93e067d  vmovaps [rsp+0x90], xmm9
0000786bc93e0686  vmovaps [rsp+0xA0], xmm10
0000786bc93e068f  vmovaps [rsp+0xB0], xmm11
0000786bc93e0698  vmovaps [rsp+0xC0], xmm12
0000786bc93e06a1  vmovaps [rsp+0xD0], xmm14
0000786bc93e06aa  vmovaps [rsp+0xE0], xmm15
0000786bc93e06b3  sub rsp, 0x30
0000786bc93e06b7  movaps [rsp], xmm13
0000786bc93e06bc  movaps [rsp+0x10], xmm15
0000786bc93e06c2  movaps [rsp+0x20], xmm8
0000786bc93e06c8  lea rdi, [rsp]
0000786bc93e06cc  mov esi, 0x00
0000786bc93e06d1  mov rax, 0x60810F6F7530
0000786bc93e06db  call rax
0000786bc93e06dd  movaps xmm13, [rsp]
0000786bc93e06e2  add rsp, 0x30
0000786bc93e06e6  vmovaps xmm0, [rsp]
0000786bc93e06eb  vmovaps xmm1, [rsp+0x10]
0000786bc93e06f1  vmovaps xmm2, [rsp+0x20]
0000786bc93e06f7  vmovaps xmm3, [rsp+0x30]
0000786bc93e06fd  vmovaps xmm4, [rsp+0x40]
0000786bc93e0703  vmovaps xmm5, [rsp+0x50]
0000786bc93e0709  vmovaps xmm6, [rsp+0x60]
0000786bc93e070f  vmovaps xmm7, [rsp+0x70]
0000786bc93e0715  vmovaps xmm8, [rsp+0x80]
0000786bc93e071e  vmovaps xmm9, [rsp+0x90]
0000786bc93e0727  vmovaps xmm10, [rsp+0xA0]
0000786bc93e0730  vmovaps xmm11, [rsp+0xB0]
0000786bc93e0739  vmovaps xmm12, [rsp+0xC0]
0000786bc93e0742  vmovaps xmm14, [rsp+0xD0]
0000786bc93e074b  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0754  add rsp, 0xF0
0000786bc93e075b  pop r11
0000786bc93e075d  pop r10
0000786bc93e075f  pop r9
0000786bc93e0761  pop r8
0000786bc93e0763  pop rsi
0000786bc93e0764  pop rdi
0000786bc93e0765  pop rdx
0000786bc93e0766  pop rcx
0000786bc93e0767  pop rax
0000786bc93e0768  add rsp, 0x08
0000786bc93e076c  jmp 0x0000786BC93DC60F
0000786bc93e0771  sub rsp, 0x08
0000786bc93e0775  push rax
0000786bc93e0776  push rcx
0000786bc93e0777  push rdx
0000786bc93e0778  push rdi
0000786bc93e0779  push rsi
0000786bc93e077a  push r8
0000786bc93e077c  push r9
0000786bc93e077e  push r10
0000786bc93e0780  push r11
0000786bc93e0782  sub rsp, 0xF0
0000786bc93e0789  vmovaps [rsp], xmm0
0000786bc93e078e  vmovaps [rsp+0x10], xmm1
0000786bc93e0794  vmovaps [rsp+0x20], xmm2
0000786bc93e079a  vmovaps [rsp+0x30], xmm3
0000786bc93e07a0  vmovaps [rsp+0x40], xmm4
0000786bc93e07a6  vmovaps [rsp+0x50], xmm5
0000786bc93e07ac  vmovaps [rsp+0x60], xmm6
0000786bc93e07b2  vmovaps [rsp+0x70], xmm7
0000786bc93e07b8  vmovaps [rsp+0x80], xmm9
0000786bc93e07c1  vmovaps [rsp+0x90], xmm10
0000786bc93e07ca  vmovaps [rsp+0xA0], xmm11
0000786bc93e07d3  vmovaps [rsp+0xB0], xmm12
0000786bc93e07dc  vmovaps [rsp+0xC0], xmm13
0000786bc93e07e5  vmovaps [rsp+0xD0], xmm14
0000786bc93e07ee  vmovaps [rsp+0xE0], xmm15
0000786bc93e07f7  sub rsp, 0x30
0000786bc93e07fb  movaps [rsp], xmm8
0000786bc93e0800  movaps [rsp+0x10], xmm15
0000786bc93e0806  movaps [rsp+0x20], xmm9
0000786bc93e080c  lea rdi, [rsp]
0000786bc93e0810  mov esi, 0x00
0000786bc93e0815  mov rax, 0x60810F6F7530
0000786bc93e081f  call rax
0000786bc93e0821  movaps xmm8, [rsp]
0000786bc93e0826  add rsp, 0x30
0000786bc93e082a  vmovaps xmm0, [rsp]
0000786bc93e082f  vmovaps xmm1, [rsp+0x10]
0000786bc93e0835  vmovaps xmm2, [rsp+0x20]
0000786bc93e083b  vmovaps xmm3, [rsp+0x30]
0000786bc93e0841  vmovaps xmm4, [rsp+0x40]
0000786bc93e0847  vmovaps xmm5, [rsp+0x50]
0000786bc93e084d  vmovaps xmm6, [rsp+0x60]
0000786bc93e0853  vmovaps xmm7, [rsp+0x70]
0000786bc93e0859  vmovaps xmm9, [rsp+0x80]
0000786bc93e0862  vmovaps xmm10, [rsp+0x90]
0000786bc93e086b  vmovaps xmm11, [rsp+0xA0]
0000786bc93e0874  vmovaps xmm12, [rsp+0xB0]
0000786bc93e087d  vmovaps xmm13, [rsp+0xC0]
0000786bc93e0886  vmovaps xmm14, [rsp+0xD0]
0000786bc93e088f  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0898  add rsp, 0xF0
0000786bc93e089f  pop r11
0000786bc93e08a1  pop r10
0000786bc93e08a3  pop r9
0000786bc93e08a5  pop r8
0000786bc93e08a7  pop rsi
0000786bc93e08a8  pop rdi
0000786bc93e08a9  pop rdx
0000786bc93e08aa  pop rcx
0000786bc93e08ab  pop rax
0000786bc93e08ac  add rsp, 0x08
0000786bc93e08b0  jmp 0x0000786BC93DC63D
0000786bc93e08b5  sub rsp, 0x08
0000786bc93e08b9  push rax
0000786bc93e08ba  push rcx
0000786bc93e08bb  push rdx
0000786bc93e08bc  push rdi
0000786bc93e08bd  push rsi
0000786bc93e08be  push r8
0000786bc93e08c0  push r9
0000786bc93e08c2  push r10
0000786bc93e08c4  push r11
0000786bc93e08c6  sub rsp, 0xF0
0000786bc93e08cd  vmovaps [rsp], xmm0
0000786bc93e08d2  vmovaps [rsp+0x10], xmm1
0000786bc93e08d8  vmovaps [rsp+0x20], xmm2
0000786bc93e08de  vmovaps [rsp+0x30], xmm3
0000786bc93e08e4  vmovaps [rsp+0x40], xmm4
0000786bc93e08ea  vmovaps [rsp+0x50], xmm5
0000786bc93e08f0  vmovaps [rsp+0x60], xmm6
0000786bc93e08f6  vmovaps [rsp+0x70], xmm7
0000786bc93e08fc  vmovaps [rsp+0x80], xmm8
0000786bc93e0905  vmovaps [rsp+0x90], xmm9
0000786bc93e090e  vmovaps [rsp+0xA0], xmm10
0000786bc93e0917  vmovaps [rsp+0xB0], xmm11
0000786bc93e0920  vmovaps [rsp+0xC0], xmm12
0000786bc93e0929  vmovaps [rsp+0xD0], xmm13
0000786bc93e0932  vmovaps [rsp+0xE0], xmm14
0000786bc93e093b  sub rsp, 0x30
0000786bc93e093f  movaps [rsp], xmm15
0000786bc93e0944  movaps [rsp+0x10], xmm11
0000786bc93e094a  movaps [rsp+0x20], xmm6
0000786bc93e094f  lea rdi, [rsp]
0000786bc93e0953  mov esi, 0x00
0000786bc93e0958  mov rax, 0x60810F6F7530
0000786bc93e0962  call rax
0000786bc93e0964  movaps xmm15, [rsp]
0000786bc93e0969  add rsp, 0x30
0000786bc93e096d  vmovaps xmm0, [rsp]
0000786bc93e0972  vmovaps xmm1, [rsp+0x10]
0000786bc93e0978  vmovaps xmm2, [rsp+0x20]
0000786bc93e097e  vmovaps xmm3, [rsp+0x30]
0000786bc93e0984  vmovaps xmm4, [rsp+0x40]
0000786bc93e098a  vmovaps xmm5, [rsp+0x50]
0000786bc93e0990  vmovaps xmm6, [rsp+0x60]
0000786bc93e0996  vmovaps xmm7, [rsp+0x70]
0000786bc93e099c  vmovaps xmm8, [rsp+0x80]
0000786bc93e09a5  vmovaps xmm9, [rsp+0x90]
0000786bc93e09ae  vmovaps xmm10, [rsp+0xA0]
0000786bc93e09b7  vmovaps xmm11, [rsp+0xB0]
0000786bc93e09c0  vmovaps xmm12, [rsp+0xC0]
0000786bc93e09c9  vmovaps xmm13, [rsp+0xD0]
0000786bc93e09d2  vmovaps xmm14, [rsp+0xE0]
0000786bc93e09db  add rsp, 0xF0
0000786bc93e09e2  pop r11
0000786bc93e09e4  pop r10
0000786bc93e09e6  pop r9
0000786bc93e09e8  pop r8
0000786bc93e09ea  pop rsi
0000786bc93e09eb  pop rdi
0000786bc93e09ec  pop rdx
0000786bc93e09ed  pop rcx
0000786bc93e09ee  pop rax
0000786bc93e09ef  add rsp, 0x08
0000786bc93e09f3  jmp 0x0000786BC93DC658
0000786bc93e09f8  sub rsp, 0x08
0000786bc93e09fc  push rax
0000786bc93e09fd  push rcx
0000786bc93e09fe  push rdx
0000786bc93e09ff  push rdi
0000786bc93e0a00  push rsi
0000786bc93e0a01  push r8
0000786bc93e0a03  push r9
0000786bc93e0a05  push r10
0000786bc93e0a07  push r11
0000786bc93e0a09  sub rsp, 0xF0
0000786bc93e0a10  vmovaps [rsp], xmm0
0000786bc93e0a15  vmovaps [rsp+0x10], xmm1
0000786bc93e0a1b  vmovaps [rsp+0x20], xmm2
0000786bc93e0a21  vmovaps [rsp+0x30], xmm3
0000786bc93e0a27  vmovaps [rsp+0x40], xmm4
0000786bc93e0a2d  vmovaps [rsp+0x50], xmm5
0000786bc93e0a33  vmovaps [rsp+0x60], xmm6
0000786bc93e0a39  vmovaps [rsp+0x70], xmm8
0000786bc93e0a3f  vmovaps [rsp+0x80], xmm9
0000786bc93e0a48  vmovaps [rsp+0x90], xmm10
0000786bc93e0a51  vmovaps [rsp+0xA0], xmm11
0000786bc93e0a5a  vmovaps [rsp+0xB0], xmm12
0000786bc93e0a63  vmovaps [rsp+0xC0], xmm13
0000786bc93e0a6c  vmovaps [rsp+0xD0], xmm14
0000786bc93e0a75  vmovaps [rsp+0xE0], xmm15
0000786bc93e0a7e  sub rsp, 0x30
0000786bc93e0a82  movaps [rsp], xmm7
0000786bc93e0a86  movaps [rsp+0x10], xmm11
0000786bc93e0a8c  movaps [rsp+0x20], xmm9
0000786bc93e0a92  lea rdi, [rsp]
0000786bc93e0a96  mov esi, 0x00
0000786bc93e0a9b  mov rax, 0x60810F6F7530
0000786bc93e0aa5  call rax
0000786bc93e0aa7  movaps xmm7, [rsp]
0000786bc93e0aab  add rsp, 0x30
0000786bc93e0aaf  vmovaps xmm0, [rsp]
0000786bc93e0ab4  vmovaps xmm1, [rsp+0x10]
0000786bc93e0aba  vmovaps xmm2, [rsp+0x20]
0000786bc93e0ac0  vmovaps xmm3, [rsp+0x30]
0000786bc93e0ac6  vmovaps xmm4, [rsp+0x40]
0000786bc93e0acc  vmovaps xmm5, [rsp+0x50]
0000786bc93e0ad2  vmovaps xmm6, [rsp+0x60]
0000786bc93e0ad8  vmovaps xmm8, [rsp+0x70]
0000786bc93e0ade  vmovaps xmm9, [rsp+0x80]
0000786bc93e0ae7  vmovaps xmm10, [rsp+0x90]
0000786bc93e0af0  vmovaps xmm11, [rsp+0xA0]
0000786bc93e0af9  vmovaps xmm12, [rsp+0xB0]
0000786bc93e0b02  vmovaps xmm13, [rsp+0xC0]
0000786bc93e0b0b  vmovaps xmm14, [rsp+0xD0]
0000786bc93e0b14  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0b1d  add rsp, 0xF0
0000786bc93e0b24  pop r11
0000786bc93e0b26  pop r10
0000786bc93e0b28  pop r9
0000786bc93e0b2a  pop r8
0000786bc93e0b2c  pop rsi
0000786bc93e0b2d  pop rdi
0000786bc93e0b2e  pop rdx
0000786bc93e0b2f  pop rcx
0000786bc93e0b30  pop rax
0000786bc93e0b31  add rsp, 0x08
0000786bc93e0b35  jmp 0x0000786BC93DC685
0000786bc93e0b3a  sub rsp, 0x08
0000786bc93e0b3e  push rax
0000786bc93e0b3f  push rcx
0000786bc93e0b40  push rdx
0000786bc93e0b41  push rdi
0000786bc93e0b42  push rsi
0000786bc93e0b43  push r8
0000786bc93e0b45  push r9
0000786bc93e0b47  push r10
0000786bc93e0b49  push r11
0000786bc93e0b4b  sub rsp, 0xF0
0000786bc93e0b52  vmovaps [rsp], xmm0
0000786bc93e0b57  vmovaps [rsp+0x10], xmm1
0000786bc93e0b5d  vmovaps [rsp+0x20], xmm2
0000786bc93e0b63  vmovaps [rsp+0x30], xmm3
0000786bc93e0b69  vmovaps [rsp+0x40], xmm4
0000786bc93e0b6f  vmovaps [rsp+0x50], xmm5
0000786bc93e0b75  vmovaps [rsp+0x60], xmm6
0000786bc93e0b7b  vmovaps [rsp+0x70], xmm7
0000786bc93e0b81  vmovaps [rsp+0x80], xmm8
0000786bc93e0b8a  vmovaps [rsp+0x90], xmm9
0000786bc93e0b93  vmovaps [rsp+0xA0], xmm10
0000786bc93e0b9c  vmovaps [rsp+0xB0], xmm12
0000786bc93e0ba5  vmovaps [rsp+0xC0], xmm13
0000786bc93e0bae  vmovaps [rsp+0xD0], xmm14
0000786bc93e0bb7  vmovaps [rsp+0xE0], xmm15
0000786bc93e0bc0  sub rsp, 0x30
0000786bc93e0bc4  movaps [rsp], xmm11
0000786bc93e0bc9  movaps [rsp+0x10], xmm10
0000786bc93e0bcf  movaps [rsp+0x20], xmm14
0000786bc93e0bd5  lea rdi, [rsp]
0000786bc93e0bd9  mov esi, 0x00
0000786bc93e0bde  mov rax, 0x60810F6F7530
0000786bc93e0be8  call rax
0000786bc93e0bea  movaps xmm11, [rsp]
0000786bc93e0bef  add rsp, 0x30
0000786bc93e0bf3  vmovaps xmm0, [rsp]
0000786bc93e0bf8  vmovaps xmm1, [rsp+0x10]
0000786bc93e0bfe  vmovaps xmm2, [rsp+0x20]
0000786bc93e0c04  vmovaps xmm3, [rsp+0x30]
0000786bc93e0c0a  vmovaps xmm4, [rsp+0x40]
0000786bc93e0c10  vmovaps xmm5, [rsp+0x50]
0000786bc93e0c16  vmovaps xmm6, [rsp+0x60]
0000786bc93e0c1c  vmovaps xmm7, [rsp+0x70]
0000786bc93e0c22  vmovaps xmm8, [rsp+0x80]
0000786bc93e0c2b  vmovaps xmm9, [rsp+0x90]
0000786bc93e0c34  vmovaps xmm10, [rsp+0xA0]
0000786bc93e0c3d  vmovaps xmm12, [rsp+0xB0]
0000786bc93e0c46  vmovaps xmm13, [rsp+0xC0]
0000786bc93e0c4f  vmovaps xmm14, [rsp+0xD0]
0000786bc93e0c58  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0c61  add rsp, 0xF0
0000786bc93e0c68  pop r11
0000786bc93e0c6a  pop r10
0000786bc93e0c6c  pop r9
0000786bc93e0c6e  pop r8
0000786bc93e0c70  pop rsi
0000786bc93e0c71  pop rdi
0000786bc93e0c72  pop rdx
0000786bc93e0c73  pop rcx
0000786bc93e0c74  pop rax
0000786bc93e0c75  add rsp, 0x08
0000786bc93e0c79  jmp 0x0000786BC93DC6A0
0000786bc93e0c7e  call 0x0000786BC92C33A0
0000786bc93e0c83  jmp 0x0000786BC93DC6AA
0000786bc93e0c88  sub rsp, 0x08
0000786bc93e0c8c  push rax
0000786bc93e0c8d  push rcx
0000786bc93e0c8e  push rdx
0000786bc93e0c8f  push rdi
0000786bc93e0c90  push rsi
0000786bc93e0c91  push r8
0000786bc93e0c93  push r9
0000786bc93e0c95  push r10
0000786bc93e0c97  push r11
0000786bc93e0c99  sub rsp, 0xF0
0000786bc93e0ca0  vmovaps [rsp], xmm0
0000786bc93e0ca5  vmovaps [rsp+0x10], xmm1
0000786bc93e0cab  vmovaps [rsp+0x20], xmm2
0000786bc93e0cb1  vmovaps [rsp+0x30], xmm3
0000786bc93e0cb7  vmovaps [rsp+0x40], xmm4
0000786bc93e0cbd  vmovaps [rsp+0x50], xmm5
0000786bc93e0cc3  vmovaps [rsp+0x60], xmm6
0000786bc93e0cc9  vmovaps [rsp+0x70], xmm7
0000786bc93e0ccf  vmovaps [rsp+0x80], xmm8
0000786bc93e0cd8  vmovaps [rsp+0x90], xmm9
0000786bc93e0ce1  vmovaps [rsp+0xA0], xmm11
0000786bc93e0cea  vmovaps [rsp+0xB0], xmm12
0000786bc93e0cf3  vmovaps [rsp+0xC0], xmm13
0000786bc93e0cfc  vmovaps [rsp+0xD0], xmm14
0000786bc93e0d05  vmovaps [rsp+0xE0], xmm15
0000786bc93e0d0e  sub rsp, 0x30
0000786bc93e0d12  movaps [rsp], xmm10
0000786bc93e0d17  movaps [rsp+0x10], xmm1
0000786bc93e0d1c  movaps [rsp+0x20], xmm12
0000786bc93e0d22  lea rdi, [rsp]
0000786bc93e0d26  mov esi, 0x00
0000786bc93e0d2b  mov rax, 0x60810F6F7530
0000786bc93e0d35  call rax
0000786bc93e0d37  movaps xmm10, [rsp]
0000786bc93e0d3c  add rsp, 0x30
0000786bc93e0d40  vmovaps xmm0, [rsp]
0000786bc93e0d45  vmovaps xmm1, [rsp+0x10]
0000786bc93e0d4b  vmovaps xmm2, [rsp+0x20]
0000786bc93e0d51  vmovaps xmm3, [rsp+0x30]
0000786bc93e0d57  vmovaps xmm4, [rsp+0x40]
0000786bc93e0d5d  vmovaps xmm5, [rsp+0x50]
0000786bc93e0d63  vmovaps xmm6, [rsp+0x60]
0000786bc93e0d69  vmovaps xmm7, [rsp+0x70]
0000786bc93e0d6f  vmovaps xmm8, [rsp+0x80]
0000786bc93e0d78  vmovaps xmm9, [rsp+0x90]
0000786bc93e0d81  vmovaps xmm11, [rsp+0xA0]
0000786bc93e0d8a  vmovaps xmm12, [rsp+0xB0]
0000786bc93e0d93  vmovaps xmm13, [rsp+0xC0]
0000786bc93e0d9c  vmovaps xmm14, [rsp+0xD0]
0000786bc93e0da5  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0dae  add rsp, 0xF0
0000786bc93e0db5  pop r11
0000786bc93e0db7  pop r10
0000786bc93e0db9  pop r9
0000786bc93e0dbb  pop r8
0000786bc93e0dbd  pop rsi
0000786bc93e0dbe  pop rdi
0000786bc93e0dbf  pop rdx
0000786bc93e0dc0  pop rcx
0000786bc93e0dc1  pop rax
0000786bc93e0dc2  add rsp, 0x08
0000786bc93e0dc6  jmp 0x0000786BC93DC6CD
0000786bc93e0dcb  sub rsp, 0x08
0000786bc93e0dcf  push rax
0000786bc93e0dd0  push rcx
0000786bc93e0dd1  push rdx
0000786bc93e0dd2  push rdi
0000786bc93e0dd3  push rsi
0000786bc93e0dd4  push r8
0000786bc93e0dd6  push r9
0000786bc93e0dd8  push r10
0000786bc93e0dda  push r11
0000786bc93e0ddc  sub rsp, 0xF0
0000786bc93e0de3  vmovaps [rsp], xmm0
0000786bc93e0de8  vmovaps [rsp+0x10], xmm1
0000786bc93e0dee  vmovaps [rsp+0x20], xmm2
0000786bc93e0df4  vmovaps [rsp+0x30], xmm3
0000786bc93e0dfa  vmovaps [rsp+0x40], xmm4
0000786bc93e0e00  vmovaps [rsp+0x50], xmm5
0000786bc93e0e06  vmovaps [rsp+0x60], xmm6
0000786bc93e0e0c  vmovaps [rsp+0x70], xmm7
0000786bc93e0e12  vmovaps [rsp+0x80], xmm8
0000786bc93e0e1b  vmovaps [rsp+0x90], xmm9
0000786bc93e0e24  vmovaps [rsp+0xA0], xmm10
0000786bc93e0e2d  vmovaps [rsp+0xB0], xmm11
0000786bc93e0e36  vmovaps [rsp+0xC0], xmm13
0000786bc93e0e3f  vmovaps [rsp+0xD0], xmm14
0000786bc93e0e48  vmovaps [rsp+0xE0], xmm15
0000786bc93e0e51  sub rsp, 0x30
0000786bc93e0e55  movaps [rsp], xmm12
0000786bc93e0e5a  movaps [rsp+0x10], xmm14
0000786bc93e0e60  movaps [rsp+0x20], xmm1
0000786bc93e0e65  lea rdi, [rsp]
0000786bc93e0e69  mov esi, 0x00
0000786bc93e0e6e  mov rax, 0x60810F6F7530
0000786bc93e0e78  call rax
0000786bc93e0e7a  movaps xmm12, [rsp]
0000786bc93e0e7f  add rsp, 0x30
0000786bc93e0e83  vmovaps xmm0, [rsp]
0000786bc93e0e88  vmovaps xmm1, [rsp+0x10]
0000786bc93e0e8e  vmovaps xmm2, [rsp+0x20]
0000786bc93e0e94  vmovaps xmm3, [rsp+0x30]
0000786bc93e0e9a  vmovaps xmm4, [rsp+0x40]
0000786bc93e0ea0  vmovaps xmm5, [rsp+0x50]
0000786bc93e0ea6  vmovaps xmm6, [rsp+0x60]
0000786bc93e0eac  vmovaps xmm7, [rsp+0x70]
0000786bc93e0eb2  vmovaps xmm8, [rsp+0x80]
0000786bc93e0ebb  vmovaps xmm9, [rsp+0x90]
0000786bc93e0ec4  vmovaps xmm10, [rsp+0xA0]
0000786bc93e0ecd  vmovaps xmm11, [rsp+0xB0]
0000786bc93e0ed6  vmovaps xmm13, [rsp+0xC0]
0000786bc93e0edf  vmovaps xmm14, [rsp+0xD0]
0000786bc93e0ee8  vmovaps xmm15, [rsp+0xE0]
0000786bc93e0ef1  add rsp, 0xF0
0000786bc93e0ef8  pop r11
0000786bc93e0efa  pop r10
0000786bc93e0efc  pop r9
0000786bc93e0efe  pop r8
0000786bc93e0f00  pop rsi
0000786bc93e0f01  pop rdi
0000786bc93e0f02  pop rdx
0000786bc93e0f03  pop rcx
0000786bc93e0f04  pop rax
0000786bc93e0f05  add rsp, 0x08
0000786bc93e0f09  jmp 0x0000786BC93DC6FC
0000786bc93e0f0e  sub rsp, 0x08
0000786bc93e0f12  push rax
0000786bc93e0f13  push rcx
0000786bc93e0f14  push rdx
0000786bc93e0f15  push rdi
0000786bc93e0f16  push rsi
0000786bc93e0f17  push r8
0000786bc93e0f19  push r9
0000786bc93e0f1b  push r10
0000786bc93e0f1d  push r11
0000786bc93e0f1f  sub rsp, 0xF0
0000786bc93e0f26  vmovaps [rsp], xmm0
0000786bc93e0f2b  vmovaps [rsp+0x10], xmm1
0000786bc93e0f31  vmovaps [rsp+0x20], xmm2
0000786bc93e0f37  vmovaps [rsp+0x30], xmm3
0000786bc93e0f3d  vmovaps [rsp+0x40], xmm4
0000786bc93e0f43  vmovaps [rsp+0x50], xmm5
0000786bc93e0f49  vmovaps [rsp+0x60], xmm6
0000786bc93e0f4f  vmovaps [rsp+0x70], xmm7
0000786bc93e0f55  vmovaps [rsp+0x80], xmm8
0000786bc93e0f5e  vmovaps [rsp+0x90], xmm9
0000786bc93e0f67  vmovaps [rsp+0xA0], xmm10
0000786bc93e0f70  vmovaps [rsp+0xB0], xmm11
0000786bc93e0f79  vmovaps [rsp+0xC0], xmm12
0000786bc93e0f82  vmovaps [rsp+0xD0], xmm13
0000786bc93e0f8b  vmovaps [rsp+0xE0], xmm15
0000786bc93e0f94  sub rsp, 0x30
0000786bc93e0f98  movaps [rsp], xmm14
0000786bc93e0f9d  movaps [rsp+0x10], xmm9
0000786bc93e0fa3  movaps [rsp+0x20], xmm1
0000786bc93e0fa8  lea rdi, [rsp]
0000786bc93e0fac  mov esi, 0x00
0000786bc93e0fb1  mov rax, 0x60810F6F7530
0000786bc93e0fbb  call rax
0000786bc93e0fbd  movaps xmm14, [rsp]
0000786bc93e0fc2  add rsp, 0x30
0000786bc93e0fc6  vmovaps xmm0, [rsp]
0000786bc93e0fcb  vmovaps xmm1, [rsp+0x10]
0000786bc93e0fd1  vmovaps xmm2, [rsp+0x20]
0000786bc93e0fd7  vmovaps xmm3, [rsp+0x30]
0000786bc93e0fdd  vmovaps xmm4, [rsp+0x40]
0000786bc93e0fe3  vmovaps xmm5, [rsp+0x50]
0000786bc93e0fe9  vmovaps xmm6, [rsp+0x60]
0000786bc93e0fef  vmovaps xmm7, [rsp+0x70]
0000786bc93e0ff5  vmovaps xmm8, [rsp+0x80]
0000786bc93e0ffe  vmovaps xmm9, [rsp+0x90]
0000786bc93e1007  vmovaps xmm10, [rsp+0xA0]
0000786bc93e1010  vmovaps xmm11, [rsp+0xB0]
0000786bc93e1019  vmovaps xmm12, [rsp+0xC0]
0000786bc93e1022  vmovaps xmm13, [rsp+0xD0]
0000786bc93e102b  vmovaps xmm15, [rsp+0xE0]
0000786bc93e1034  add rsp, 0xF0
0000786bc93e103b  pop r11
0000786bc93e103d  pop r10
0000786bc93e103f  pop r9
0000786bc93e1041  pop r8
0000786bc93e1043  pop rsi
0000786bc93e1044  pop rdi
0000786bc93e1045  pop rdx
0000786bc93e1046  pop rcx
0000786bc93e1047  pop rax
0000786bc93e1048  add rsp, 0x08
0000786bc93e104c  jmp 0x0000786BC93DC72B
0000786bc93e1051  sub rsp, 0x08
0000786bc93e1055  push rax
0000786bc93e1056  push rcx
0000786bc93e1057  push rdx
0000786bc93e1058  push rdi
0000786bc93e1059  push rsi
0000786bc93e105a  push r8
0000786bc93e105c  push r9
0000786bc93e105e  push r10
0000786bc93e1060  push r11
0000786bc93e1062  sub rsp, 0xF0
0000786bc93e1069  vmovaps [rsp], xmm0
0000786bc93e106e  vmovaps [rsp+0x10], xmm2
0000786bc93e1074  vmovaps [rsp+0x20], xmm3
0000786bc93e107a  vmovaps [rsp+0x30], xmm4
0000786bc93e1080  vmovaps [rsp+0x40], xmm5
0000786bc93e1086  vmovaps [rsp+0x50], xmm6
0000786bc93e108c  vmovaps [rsp+0x60], xmm7
0000786bc93e1092  vmovaps [rsp+0x70], xmm8
0000786bc93e1098  vmovaps [rsp+0x80], xmm9
0000786bc93e10a1  vmovaps [rsp+0x90], xmm10
0000786bc93e10aa  vmovaps [rsp+0xA0], xmm11
0000786bc93e10b3  vmovaps [rsp+0xB0], xmm12
0000786bc93e10bc  vmovaps [rsp+0xC0], xmm13
0000786bc93e10c5  vmovaps [rsp+0xD0], xmm14
0000786bc93e10ce  vmovaps [rsp+0xE0], xmm15
0000786bc93e10d7  sub rsp, 0x30
0000786bc93e10db  movaps [rsp], xmm1
0000786bc93e10df  movaps [rsp+0x10], xmm13
0000786bc93e10e5  movaps [rsp+0x20], xmm8
0000786bc93e10eb  lea rdi, [rsp]
0000786bc93e10ef  mov esi, 0x00
0000786bc93e10f4  mov rax, 0x60810F6F7530
0000786bc93e10fe  call rax
0000786bc93e1100  movaps xmm1, [rsp]
0000786bc93e1104  add rsp, 0x30
0000786bc93e1108  vmovaps xmm0, [rsp]
0000786bc93e110d  vmovaps xmm2, [rsp+0x10]
0000786bc93e1113  vmovaps xmm3, [rsp+0x20]
0000786bc93e1119  vmovaps xmm4, [rsp+0x30]
0000786bc93e111f  vmovaps xmm5, [rsp+0x40]
0000786bc93e1125  vmovaps xmm6, [rsp+0x50]
0000786bc93e112b  vmovaps xmm7, [rsp+0x60]
0000786bc93e1131  vmovaps xmm8, [rsp+0x70]
0000786bc93e1137  vmovaps xmm9, [rsp+0x80]
0000786bc93e1140  vmovaps xmm10, [rsp+0x90]
0000786bc93e1149  vmovaps xmm11, [rsp+0xA0]
0000786bc93e1152  vmovaps xmm12, [rsp+0xB0]
0000786bc93e115b  vmovaps xmm13, [rsp+0xC0]
0000786bc93e1164  vmovaps xmm14, [rsp+0xD0]
0000786bc93e116d  vmovaps xmm15, [rsp+0xE0]
0000786bc93e1176  add rsp, 0xF0
0000786bc93e117d  pop r11
0000786bc93e117f  pop r10
0000786bc93e1181  pop r9
0000786bc93e1183  pop r8
0000786bc93e1185  pop rsi
0000786bc93e1186  pop rdi
0000786bc93e1187  pop rdx
0000786bc93e1188  pop rcx
0000786bc93e1189  pop rax
0000786bc93e118a  add rsp, 0x08
0000786bc93e118e  jmp 0x0000786BC93DC74D
0000786bc93e1193  call 0x0000786BC920C260
0000786bc93e1198  jmp 0x0000786BC93DC75B
0000786bc93e119d  call 0x0000786BC92BD750
0000786bc93e11a2  jmp 0x0000786BC93DC765
0000786bc93e11a7  sub rsp, 0x08
0000786bc93e11ab  push rax
0000786bc93e11ac  push rcx
0000786bc93e11ad  push rdx
0000786bc93e11ae  push rdi
0000786bc93e11af  push rsi
0000786bc93e11b0  push r8
0000786bc93e11b2  push r9
0000786bc93e11b4  push r10
0000786bc93e11b6  push r11
0000786bc93e11b8  sub rsp, 0xF0
0000786bc93e11bf  vmovaps [rsp], xmm0
0000786bc93e11c4  vmovaps [rsp+0x10], xmm1
0000786bc93e11ca  vmovaps [rsp+0x20], xmm2
0000786bc93e11d0  vmovaps [rsp+0x30], xmm3
0000786bc93e11d6  vmovaps [rsp+0x40], xmm4
0000786bc93e11dc  vmovaps [rsp+0x50], xmm5
0000786bc93e11e2  vmovaps [rsp+0x60], xmm6
0000786bc93e11e8  vmovaps [rsp+0x70], xmm7
0000786bc93e11ee  vmovaps [rsp+0x80], xmm9
0000786bc93e11f7  vmovaps [rsp+0x90], xmm10
0000786bc93e1200  vmovaps [rsp+0xA0], xmm11
0000786bc93e1209  vmovaps [rsp+0xB0], xmm12
0000786bc93e1212  vmovaps [rsp+0xC0], xmm13
0000786bc93e121b  vmovaps [rsp+0xD0], xmm14
0000786bc93e1224  vmovaps [rsp+0xE0], xmm15
0000786bc93e122d  sub rsp, 0x30
0000786bc93e1231  movaps [rsp], xmm8
0000786bc93e1236  movaps [rsp+0x10], xmm15
0000786bc93e123c  movaps [rsp+0x20], xmm7
0000786bc93e1241  lea rdi, [rsp]
0000786bc93e1245  mov esi, 0x00
0000786bc93e124a  mov rax, 0x60810F6F7530
0000786bc93e1254  call rax
0000786bc93e1256  movaps xmm8, [rsp]
0000786bc93e125b  add rsp, 0x30
0000786bc93e125f  vmovaps xmm0, [rsp]
0000786bc93e1264  vmovaps xmm1, [rsp+0x10]
0000786bc93e126a  vmovaps xmm2, [rsp+0x20]
0000786bc93e1270  vmovaps xmm3, [rsp+0x30]
0000786bc93e1276  vmovaps xmm4, [rsp+0x40]
0000786bc93e127c  vmovaps xmm5, [rsp+0x50]
0000786bc93e1282  vmovaps xmm6, [rsp+0x60]
0000786bc93e1288  vmovaps xmm7, [rsp+0x70]
0000786bc93e128e  vmovaps xmm9, [rsp+0x80]
0000786bc93e1297  vmovaps xmm10, [rsp+0x90]
0000786bc93e12a0  vmovaps xmm11, [rsp+0xA0]
0000786bc93e12a9  vmovaps xmm12, [rsp+0xB0]
0000786bc93e12b2  vmovaps xmm13, [rsp+0xC0]
0000786bc93e12bb  vmovaps xmm14, [rsp+0xD0]
0000786bc93e12c4  vmovaps xmm15, [rsp+0xE0]
0000786bc93e12cd  add rsp, 0xF0
0000786bc93e12d4  pop r11
0000786bc93e12d6  pop r10
0000786bc93e12d8  pop r9
0000786bc93e12da  pop r8
0000786bc93e12dc  pop rsi
0000786bc93e12dd  pop rdi
0000786bc93e12de  pop rdx
0000786bc93e12df  pop rcx
0000786bc93e12e0  pop rax
0000786bc93e12e1  add rsp, 0x08
0000786bc93e12e5  jmp 0x0000786BC93DC787
0000786bc93e12ea  sub rsp, 0x08
0000786bc93e12ee  push rax
0000786bc93e12ef  push rcx
0000786bc93e12f0  push rdx
0000786bc93e12f1  push rdi
0000786bc93e12f2  push rsi
0000786bc93e12f3  push r8
0000786bc93e12f5  push r9
0000786bc93e12f7  push r10
0000786bc93e12f9  push r11
0000786bc93e12fb  sub rsp, 0xF0
0000786bc93e1302  vmovaps [rsp], xmm0
0000786bc93e1307  vmovaps [rsp+0x10], xmm1
0000786bc93e130d  vmovaps [rsp+0x20], xmm2
0000786bc93e1313  vmovaps [rsp+0x30], xmm3
0000786bc93e1319  vmovaps [rsp+0x40], xmm4
0000786bc93e131f  vmovaps [rsp+0x50], xmm5
0000786bc93e1325  vmovaps [rsp+0x60], xmm6
0000786bc93e132b  vmovaps [rsp+0x70], xmm8
0000786bc93e1331  vmovaps [rsp+0x80], xmm9
0000786bc93e133a  vmovaps [rsp+0x90], xmm10
0000786bc93e1343  vmovaps [rsp+0xA0], xmm11
0000786bc93e134c  vmovaps [rsp+0xB0], xmm12
0000786bc93e1355  vmovaps [rsp+0xC0], xmm13
0000786bc93e135e  vmovaps [rsp+0xD0], xmm14
0000786bc93e1367  vmovaps [rsp+0xE0], xmm15
0000786bc93e1370  sub rsp, 0x30
0000786bc93e1374  movaps [rsp], xmm7
0000786bc93e1378  movaps [rsp+0x10], xmm9
0000786bc93e137e  movaps [rsp+0x20], xmm15
0000786bc93e1384  lea rdi, [rsp]
0000786bc93e1388  mov esi, 0x00
0000786bc93e138d  mov rax, 0x60810F6F7530
0000786bc93e1397  call rax
0000786bc93e1399  movaps xmm7, [rsp]
0000786bc93e139d  add rsp, 0x30
0000786bc93e13a1  vmovaps xmm0, [rsp]
0000786bc93e13a6  vmovaps xmm1, [rsp+0x10]
0000786bc93e13ac  vmovaps xmm2, [rsp+0x20]
0000786bc93e13b2  vmovaps xmm3, [rsp+0x30]
0000786bc93e13b8  vmovaps xmm4, [rsp+0x40]
0000786bc93e13be  vmovaps xmm5, [rsp+0x50]
0000786bc93e13c4  vmovaps xmm6, [rsp+0x60]
0000786bc93e13ca  vmovaps xmm8, [rsp+0x70]
0000786bc93e13d0  vmovaps xmm9, [rsp+0x80]
0000786bc93e13d9  vmovaps xmm10, [rsp+0x90]
0000786bc93e13e2  vmovaps xmm11, [rsp+0xA0]
0000786bc93e13eb  vmovaps xmm12, [rsp+0xB0]
0000786bc93e13f4  vmovaps xmm13, [rsp+0xC0]
0000786bc93e13fd  vmovaps xmm14, [rsp+0xD0]
0000786bc93e1406  vmovaps xmm15, [rsp+0xE0]
0000786bc93e140f  add rsp, 0xF0
0000786bc93e1416  pop r11
0000786bc93e1418  pop r10
0000786bc93e141a  pop r9
0000786bc93e141c  pop r8
0000786bc93e141e  pop rsi
0000786bc93e141f  pop rdi
0000786bc93e1420  pop rdx
0000786bc93e1421  pop rcx
0000786bc93e1422  pop rax
0000786bc93e1423  add rsp, 0x08
0000786bc93e1427  jmp 0x0000786BC93DC7B4
0000786bc93e142c  sub rsp, 0x08
0000786bc93e1430  push rax
0000786bc93e1431  push rcx
0000786bc93e1432  push rdx
0000786bc93e1433  push rdi
0000786bc93e1434  push rsi
0000786bc93e1435  push r8
0000786bc93e1437  push r9
0000786bc93e1439  push r10
0000786bc93e143b  push r11
0000786bc93e143d  sub rsp, 0xF0
0000786bc93e1444  vmovaps [rsp], xmm0
0000786bc93e1449  vmovaps [rsp+0x10], xmm1
0000786bc93e144f  vmovaps [rsp+0x20], xmm2
0000786bc93e1455  vmovaps [rsp+0x30], xmm3
0000786bc93e145b  vmovaps [rsp+0x40], xmm4
0000786bc93e1461  vmovaps [rsp+0x50], xmm5
0000786bc93e1467  vmovaps [rsp+0x60], xmm6
0000786bc93e146d  vmovaps [rsp+0x70], xmm7
0000786bc93e1473  vmovaps [rsp+0x80], xmm8
0000786bc93e147c  vmovaps [rsp+0x90], xmm10
0000786bc93e1485  vmovaps [rsp+0xA0], xmm11
0000786bc93e148e  vmovaps [rsp+0xB0], xmm12
0000786bc93e1497  vmovaps [rsp+0xC0], xmm13
0000786bc93e14a0  vmovaps [rsp+0xD0], xmm14
0000786bc93e14a9  vmovaps [rsp+0xE0], xmm15
0000786bc93e14b2  sub rsp, 0x30
0000786bc93e14b6  movaps [rsp], xmm9
0000786bc93e14bb  movaps [rsp+0x10], xmm13
0000786bc93e14c1  movaps [rsp+0x20], xmm15
0000786bc93e14c7  lea rdi, [rsp]
0000786bc93e14cb  mov esi, 0x00
0000786bc93e14d0  mov rax, 0x60810F6F7530
0000786bc93e14da  call rax
0000786bc93e14dc  movaps xmm9, [rsp]
0000786bc93e14e1  add rsp, 0x30
0000786bc93e14e5  vmovaps xmm0, [rsp]
0000786bc93e14ea  vmovaps xmm1, [rsp+0x10]
0000786bc93e14f0  vmovaps xmm2, [rsp+0x20]
0000786bc93e14f6  vmovaps xmm3, [rsp+0x30]
0000786bc93e14fc  vmovaps xmm4, [rsp+0x40]
0000786bc93e1502  vmovaps xmm5, [rsp+0x50]
0000786bc93e1508  vmovaps xmm6, [rsp+0x60]
0000786bc93e150e  vmovaps xmm7, [rsp+0x70]
0000786bc93e1514  vmovaps xmm8, [rsp+0x80]
0000786bc93e151d  vmovaps xmm10, [rsp+0x90]
0000786bc93e1526  vmovaps xmm11, [rsp+0xA0]
0000786bc93e152f  vmovaps xmm12, [rsp+0xB0]
0000786bc93e1538  vmovaps xmm13, [rsp+0xC0]
0000786bc93e1541  vmovaps xmm14, [rsp+0xD0]
0000786bc93e154a  vmovaps xmm15, [rsp+0xE0]
0000786bc93e1553  add rsp, 0xF0
0000786bc93e155a  pop r11
0000786bc93e155c  pop r10
0000786bc93e155e  pop r9
0000786bc93e1560  pop r8
0000786bc93e1562  pop rsi
0000786bc93e1563  pop rdi
0000786bc93e1564  pop rdx
0000786bc93e1565  pop rcx
0000786bc93e1566  pop rax
0000786bc93e1567  add rsp, 0x08
0000786bc93e156b  jmp 0x0000786BC93DC7E2
0000786bc93e1570  sub rsp, 0x08
0000786bc93e1574  push rax
0000786bc93e1575  push rcx
0000786bc93e1576  push rdx
0000786bc93e1577  push rdi
0000786bc93e1578  push rsi
0000786bc93e1579  push r8
0000786bc93e157b  push r9
0000786bc93e157d  push r10
0000786bc93e157f  push r11
0000786bc93e1581  sub rsp, 0xF0
0000786bc93e1588  vmovaps [rsp], xmm0
0000786bc93e158d  vmovaps [rsp+0x10], xmm1
0000786bc93e1593  vmovaps [rsp+0x20], xmm2
0000786bc93e1599  vmovaps [rsp+0x30], xmm3
0000786bc93e159f  vmovaps [rsp+0x40], xmm4
0000786bc93e15a5  vmovaps [rsp+0x50], xmm5
0000786bc93e15ab  vmovaps [rsp+0x60], xmm6
0000786bc93e15b1  vmovaps [rsp+0x70], xmm7
0000786bc93e15b7  vmovaps [rsp+0x80], xmm8
0000786bc93e15c0  vmovaps [rsp+0x90], xmm9
0000786bc93e15c9  vmovaps [rsp+0xA0], xmm10
0000786bc93e15d2  vmovaps [rsp+0xB0], xmm11
0000786bc93e15db  vmovaps [rsp+0xC0], xmm12
0000786bc93e15e4  vmovaps [rsp+0xD0], xmm13
0000786bc93e15ed  vmovaps [rsp+0xE0], xmm14
0000786bc93e15f6  sub rsp, 0x30
0000786bc93e15fa  movaps [rsp], xmm15
0000786bc93e15ff  movaps [rsp+0x10], xmm11
0000786bc93e1605  movaps [rsp+0x20], xmm12
0000786bc93e160b  lea rdi, [rsp]
0000786bc93e160f  mov esi, 0x00
0000786bc93e1614  mov rax, 0x60810F6F7530
0000786bc93e161e  call rax
0000786bc93e1620  movaps xmm15, [rsp]
0000786bc93e1625  add rsp, 0x30
0000786bc93e1629  vmovaps xmm0, [rsp]
0000786bc93e162e  vmovaps xmm1, [rsp+0x10]
0000786bc93e1634  vmovaps xmm2, [rsp+0x20]
0000786bc93e163a  vmovaps xmm3, [rsp+0x30]
0000786bc93e1640  vmovaps xmm4, [rsp+0x40]
0000786bc93e1646  vmovaps xmm5, [rsp+0x50]
0000786bc93e164c  vmovaps xmm6, [rsp+0x60]
0000786bc93e1652  vmovaps xmm7, [rsp+0x70]
0000786bc93e1658  vmovaps xmm8, [rsp+0x80]
0000786bc93e1661  vmovaps xmm9, [rsp+0x90]
0000786bc93e166a  vmovaps xmm10, [rsp+0xA0]
0000786bc93e1673  vmovaps xmm11, [rsp+0xB0]
0000786bc93e167c  vmovaps xmm12, [rsp+0xC0]
0000786bc93e1685  vmovaps xmm13, [rsp+0xD0]
0000786bc93e168e  vmovaps xmm14, [rsp+0xE0]
0000786bc93e1697  add rsp, 0xF0
0000786bc93e169e  pop r11
0000786bc93e16a0  pop r10
0000786bc93e16a2  pop r9
0000786bc93e16a4  pop r8
0000786bc93e16a6  pop rsi
0000786bc93e16a7  pop rdi
0000786bc93e16a8  pop rdx
0000786bc93e16a9  pop rcx
0000786bc93e16aa  pop rax
0000786bc93e16ab  add rsp, 0x08
0000786bc93e16af  jmp 0x0000786BC93DC7FD
0000786bc93e16b4  sub rsp, 0x08
0000786bc93e16b8  push rax
0000786bc93e16b9  push rcx
0000786bc93e16ba  push rdx
0000786bc93e16bb  push rdi
0000786bc93e16bc  push rsi
0000786bc93e16bd  push r8
0000786bc93e16bf  push r9
0000786bc93e16c1  push r10
0000786bc93e16c3  push r11
0000786bc93e16c5  sub rsp, 0xF0
0000786bc93e16cc  vmovaps [rsp], xmm0
0000786bc93e16d1  vmovaps [rsp+0x10], xmm1
0000786bc93e16d7  vmovaps [rsp+0x20], xmm2
0000786bc93e16dd  vmovaps [rsp+0x30], xmm3
0000786bc93e16e3  vmovaps [rsp+0x40], xmm4
0000786bc93e16e9  vmovaps [rsp+0x50], xmm5
0000786bc93e16ef  vmovaps [rsp+0x60], xmm6
0000786bc93e16f5  vmovaps [rsp+0x70], xmm7
0000786bc93e16fb  vmovaps [rsp+0x80], xmm8
0000786bc93e1704  vmovaps [rsp+0x90], xmm9
0000786bc93e170d  vmovaps [rsp+0xA0], xmm10
0000786bc93e1716  vmovaps [rsp+0xB0], xmm11
0000786bc93e171f  vmovaps [rsp+0xC0], xmm12
0000786bc93e1728  vmovaps [rsp+0xD0], xmm14
0000786bc93e1731  vmovaps [rsp+0xE0], xmm15
0000786bc93e173a  sub rsp, 0x30
0000786bc93e173e  movaps [rsp], xmm13
0000786bc93e1743  movaps [rsp+0x10], xmm10
0000786bc93e1749  movaps [rsp+0x20], xmm14
0000786bc93e174f  lea rdi, [rsp]
0000786bc93e1753  mov esi, 0x00
0000786bc93e1758  mov rax, 0x60810F6F7530
0000786bc93e1762  call rax
0000786bc93e1764  movaps xmm13, [rsp]
0000786bc93e1769  add rsp, 0x30
0000786bc93e176d  vmovaps xmm0, [rsp]
0000786bc93e1772  vmovaps xmm1, [rsp+0x10]
0000786bc93e1778  vmovaps xmm2, [rsp+0x20]
0000786bc93e177e  vmovaps xmm3, [rsp+0x30]
0000786bc93e1784  vmovaps xmm4, [rsp+0x40]
0000786bc93e178a  vmovaps xmm5, [rsp+0x50]
0000786bc93e1790  vmovaps xmm6, [rsp+0x60]
0000786bc93e1796  vmovaps xmm7, [rsp+0x70]
0000786bc93e179c  vmovaps xmm8, [rsp+0x80]
0000786bc93e17a5  vmovaps xmm9, [rsp+0x90]
0000786bc93e17ae  vmovaps xmm10, [rsp+0xA0]
0000786bc93e17b7  vmovaps xmm11, [rsp+0xB0]
0000786bc93e17c0  vmovaps xmm12, [rsp+0xC0]
0000786bc93e17c9  vmovaps xmm14, [rsp+0xD0]
0000786bc93e17d2  vmovaps xmm15, [rsp+0xE0]
0000786bc93e17db  add rsp, 0xF0
0000786bc93e17e2  pop r11
0000786bc93e17e4  pop r10
0000786bc93e17e6  pop r9
0000786bc93e17e8  pop r8
0000786bc93e17ea  pop rsi
0000786bc93e17eb  pop rdi
0000786bc93e17ec  pop rdx
0000786bc93e17ed  pop rcx
0000786bc93e17ee  pop rax
0000786bc93e17ef  add rsp, 0x08
0000786bc93e17f3  jmp 0x0000786BC93DC820
0000786bc93e17f8  sub rsp, 0x08
0000786bc93e17fc  push rax
0000786bc93e17fd  push rcx
0000786bc93e17fe  push rdx
0000786bc93e17ff  push rdi
0000786bc93e1800  push rsi
0000786bc93e1801  push r8
0000786bc93e1803  push r9
0000786bc93e1805  push r10
0000786bc93e1807  push r11
0000786bc93e1809  sub rsp, 0xF0
0000786bc93e1810  vmovaps [rsp], xmm0
0000786bc93e1815  vmovaps [rsp+0x10], xmm1
0000786bc93e181b  vmovaps [rsp+0x20], xmm2
0000786bc93e1821  vmovaps [rsp+0x30], xmm3
0000786bc93e1827  vmovaps [rsp+0x40], xmm4
0000786bc93e182d  vmovaps [rsp+0x50], xmm5
0000786bc93e1833  vmovaps [rsp+0x60], xmm6
0000786bc93e1839  vmovaps [rsp+0x70], xmm7
0000786bc93e183f  vmovaps [rsp+0x80], xmm8
0000786bc93e1848  vmovaps [rsp+0x90], xmm9
0000786bc93e1851  vmovaps [rsp+0xA0], xmm10
0000786bc93e185a  vmovaps [rsp+0xB0], xmm11
0000786bc93e1863  vmovaps [rsp+0xC0], xmm12
0000786bc93e186c  vmovaps [rsp+0xD0], xmm13
0000786bc93e1875  vmovaps [rsp+0xE0], xmm15
0000786bc93e187e  sub rsp, 0x30
0000786bc93e1882  movaps [rsp], xmm14
0000786bc93e1887  movaps [rsp+0x10], xmm1
0000786bc93e188c  movaps [rsp+0x20], xmm7
0000786bc93e1891  lea rdi, [rsp]
0000786bc93e1895  mov esi, 0x00
0000786bc93e189a  mov rax, 0x60810F6F7530
0000786bc93e18a4  call rax
0000786bc93e18a6  movaps xmm14, [rsp]
0000786bc93e18ab  add rsp, 0x30
0000786bc93e18af  vmovaps xmm0, [rsp]
0000786bc93e18b4  vmovaps xmm1, [rsp+0x10]
0000786bc93e18ba  vmovaps xmm2, [rsp+0x20]
0000786bc93e18c0  vmovaps xmm3, [rsp+0x30]
0000786bc93e18c6  vmovaps xmm4, [rsp+0x40]
0000786bc93e18cc  vmovaps xmm5, [rsp+0x50]
0000786bc93e18d2  vmovaps xmm6, [rsp+0x60]
0000786bc93e18d8  vmovaps xmm7, [rsp+0x70]
0000786bc93e18de  vmovaps xmm8, [rsp+0x80]
0000786bc93e18e7  vmovaps xmm9, [rsp+0x90]
0000786bc93e18f0  vmovaps xmm10, [rsp+0xA0]
0000786bc93e18f9  vmovaps xmm11, [rsp+0xB0]
0000786bc93e1902  vmovaps xmm12, [rsp+0xC0]
0000786bc93e190b  vmovaps xmm13, [rsp+0xD0]
0000786bc93e1914  vmovaps xmm15, [rsp+0xE0]
0000786bc93e191d  add rsp, 0xF0
0000786bc93e1924  pop r11
0000786bc93e1926  pop r10
0000786bc93e1928  pop r9
0000786bc93e192a  pop r8
0000786bc93e192c  pop rsi
0000786bc93e192d  pop rdi
0000786bc93e192e  pop rdx
0000786bc93e192f  pop rcx
0000786bc93e1930  pop rax
0000786bc93e1931  add rsp, 0x08
0000786bc93e1935  jmp 0x0000786BC93DC843
0000786bc93e193a  sub rsp, 0x08
0000786bc93e193e  push rax
0000786bc93e193f  push rcx
0000786bc93e1940  push rdx
0000786bc93e1941  push rdi
0000786bc93e1942  push rsi
0000786bc93e1943  push r8
0000786bc93e1945  push r9
0000786bc93e1947  push r10
0000786bc93e1949  push r11
0000786bc93e194b  sub rsp, 0xF0
0000786bc93e1952  vmovaps [rsp], xmm0
0000786bc93e1957  vmovaps [rsp+0x10], xmm2
0000786bc93e195d  vmovaps [rsp+0x20], xmm3
0000786bc93e1963  vmovaps [rsp+0x30], xmm4
0000786bc93e1969  vmovaps [rsp+0x40], xmm5
0000786bc93e196f  vmovaps [rsp+0x50], xmm6
0000786bc93e1975  vmovaps [rsp+0x60], xmm7
0000786bc93e197b  vmovaps [rsp+0x70], xmm8
0000786bc93e1981  vmovaps [rsp+0x80], xmm9
0000786bc93e198a  vmovaps [rsp+0x90], xmm10
0000786bc93e1993  vmovaps [rsp+0xA0], xmm11
0000786bc93e199c  vmovaps [rsp+0xB0], xmm12
0000786bc93e19a5  vmovaps [rsp+0xC0], xmm13
0000786bc93e19ae  vmovaps [rsp+0xD0], xmm14
0000786bc93e19b7  vmovaps [rsp+0xE0], xmm15
0000786bc93e19c0  sub rsp, 0x30
0000786bc93e19c4  movaps [rsp], xmm1
0000786bc93e19c8  movaps [rsp+0x10], xmm8
0000786bc93e19ce  movaps [rsp+0x20], xmm9
0000786bc93e19d4  lea rdi, [rsp]
0000786bc93e19d8  mov esi, 0x00
0000786bc93e19dd  mov rax, 0x60810F6F7530
0000786bc93e19e7  call rax
0000786bc93e19e9  movaps xmm1, [rsp]
0000786bc93e19ed  add rsp, 0x30
0000786bc93e19f1  vmovaps xmm0, [rsp]
0000786bc93e19f6  vmovaps xmm2, [rsp+0x10]
0000786bc93e19fc  vmovaps xmm3, [rsp+0x20]
0000786bc93e1a02  vmovaps xmm4, [rsp+0x30]
0000786bc93e1a08  vmovaps xmm5, [rsp+0x40]
0000786bc93e1a0e  vmovaps xmm6, [rsp+0x50]
0000786bc93e1a14  vmovaps xmm7, [rsp+0x60]
0000786bc93e1a1a  vmovaps xmm8, [rsp+0x70]
0000786bc93e1a20  vmovaps xmm9, [rsp+0x80]
0000786bc93e1a29  vmovaps xmm10, [rsp+0x90]
0000786bc93e1a32  vmovaps xmm11, [rsp+0xA0]
0000786bc93e1a3b  vmovaps xmm12, [rsp+0xB0]
0000786bc93e1a44  vmovaps xmm13, [rsp+0xC0]
0000786bc93e1a4d  vmovaps xmm14, [rsp+0xD0]
0000786bc93e1a56  vmovaps xmm15, [rsp+0xE0]
0000786bc93e1a5f  add rsp, 0xF0
0000786bc93e1a66  pop r11
0000786bc93e1a68  pop r10
0000786bc93e1a6a  pop r9
0000786bc93e1a6c  pop r8
0000786bc93e1a6e  pop rsi
0000786bc93e1a6f  pop rdi
0000786bc93e1a70  pop rdx
0000786bc93e1a71  pop rcx
0000786bc93e1a72  pop rax
0000786bc93e1a73  add rsp, 0x08
0000786bc93e1a77  jmp 0x0000786BC93DC865
0000786bc93e1a7c  call 0x0000786BC92E5940
0000786bc93e1a81  jmp 0x0000786BC93DC873
0000786bc93e1a86  call 0x0000786BC920C380
0000786bc93e1a8b  jmp 0x0000786BC93DC87D
0000786bc93e1a90  call 0x0000786BC920D600
0000786bc93e1a95  jmp 0x0000786BC93DC887
0000786bc93e1a9a  call 0x0000786BC91FF540
0000786bc93e1a9f  jmp 0x0000786BC93DC891
0000786bc93e1aa4  int3
0000786bc93e1aa5  nop [rax+rax*1], ax
0000786bc93e1aae  nop
0000786bc93e1ab0  mov rax, [r15+0xF8]
0000786bc93e1ab7  lea r14, [rax+0x140]
0000786bc93e1abe  mov r12, [r13+r14*1]
0000786bc93e1ac3  mov [r15+0xE8], r12
0000786bc93e1aca  lea r14, [rax+0x130]
0000786bc93e1ad1  mov r12, [r13+r14*1]
0000786bc93e1ad6  lea r14, [rax+0x138]
0000786bc93e1add  mov r11, [r13+r14*1]
0000786bc93e1ae2  movq xmm1, r12
0000786bc93e1ae7  movq xmm15, r11
0000786bc93e1aec  movq xmm1, xmm1
0000786bc93e1af0  movq xmm1, xmm1
0000786bc93e1af4  movaps [r15+0x1A0], xmm1
0000786bc93e1afc  movq xmm15, xmm15
0000786bc93e1b01  movq xmm15, xmm15
0000786bc93e1b06  movaps [r15+0x190], xmm15
0000786bc93e1b0e  lea r14, [rax+0x120]
0000786bc93e1b15  mov r12, [r13+r14*1]
0000786bc93e1b1a  lea r14, [rax+0x128]
0000786bc93e1b21  mov r11, [r13+r14*1]
0000786bc93e1b26  movq xmm1, r12
0000786bc93e1b2b  movq xmm15, r11
0000786bc93e1b30  movq xmm1, xmm1
0000786bc93e1b34  movq xmm1, xmm1
0000786bc93e1b38  movaps [r15+0x1C0], xmm1
0000786bc93e1b40  movq xmm15, xmm15
0000786bc93e1b45  movq xmm15, xmm15
0000786bc93e1b4a  movaps [r15+0x1B0], xmm15
0000786bc93e1b52  lea r14, [rax+0x110]
0000786bc93e1b59  mov r12, [r13+r14*1]
0000786bc93e1b5e  lea r14, [rax+0x118]
0000786bc93e1b65  mov r11, [r13+r14*1]
0000786bc93e1b6a  movq xmm1, r12
0000786bc93e1b6f  movq xmm15, r11
0000786bc93e1b74  movq xmm1, xmm1
0000786bc93e1b78  movq xmm1, xmm1
0000786bc93e1b7c  movaps [r15+0x1E0], xmm1
0000786bc93e1b84  movq xmm15, xmm15
0000786bc93e1b89  movq xmm15, xmm15
0000786bc93e1b8e  movaps [r15+0x1D0], xmm15
0000786bc93e1b96  lea r14, [rax+0x100]
0000786bc93e1b9d  mov r12, [r13+r14*1]
0000786bc93e1ba2  lea r14, [rax+0x108]
0000786bc93e1ba9  mov r11, [r13+r14*1]
0000786bc93e1bae  movq xmm1, r12
0000786bc93e1bb3  movq xmm15, r11
0000786bc93e1bb8  movq xmm1, xmm1
0000786bc93e1bbc  movq xmm1, xmm1
0000786bc93e1bc0  movaps [r15+0x200], xmm1
0000786bc93e1bc8  movq xmm15, xmm15
0000786bc93e1bcd  movq xmm15, xmm15
0000786bc93e1bd2  movaps [r15+0x1F0], xmm15
0000786bc93e1bda  mov qword ptr [r15+0x40], 0x430000
0000786bc93e1be2  mov r14d, 0x430510
0000786bc93e1be8  mov r12, [r13+r14*1]
0000786bc93e1bed  movq xmm1, r12
0000786bc93e1bf2  lea r14, [rax+0x150]
0000786bc93e1bf9  mov [r15+0xF8], r14
0000786bc93e1c00  mov rax, [r15+0x50]
0000786bc93e1c04  movups xmm15, [r13+rax*1]
0000786bc93e1c0a  movaps [r15+0x120], xmm15
0000786bc93e1c12  mov qword ptr [r15+0x48], 0x10
0000786bc93e1c1a  xor eax, eax
0000786bc93e1c1c  mov r14d, 0x10
0000786bc93e1c22  mov r12d, 0x200
0000786bc93e1c28  cmp r14, r12
0000786bc93e1c2b  cmc
0000786bc93e1c2c  lahf
0000786bc93e1c2d  seto al
0000786bc93e1c30  mov [r15+0x108], eax
0000786bc93e1c37  pextrq rax, xmm15, 0x01
0000786bc93e1c3e  movq xmm14, rax
0000786bc93e1c43  movaps [r15+0x130], xmm14
0000786bc93e1c4b  movq rax, xmm1
0000786bc93e1c50  movq r14, xmm15
0000786bc93e1c55  vmovq xmm1, rax
0000786bc93e1c5a  vmovq xmm15, r14
0000786bc93e1c5f  movaps xmm13, xmm1
0000786bc93e1c63  addsd xmm13, xmm15
0000786bc93e1c68  ucomisd xmm13, xmm13
0000786bc93e1c6d  jp 0x0000786BC93E1D86
0000786bc93e1c73  movq xmm13, xmm13
0000786bc93e1c78  movq rax, xmm13
0000786bc93e1c7d  movq r14, xmm14
0000786bc93e1c82  vmovq xmm1, rax
0000786bc93e1c87  vmovq xmm15, r14
0000786bc93e1c8c  movaps xmm14, xmm1
0000786bc93e1c90  addsd xmm14, xmm15
0000786bc93e1c95  ucomisd xmm14, xmm14
0000786bc93e1c9a  jp 0x0000786BC93E1DCE
0000786bc93e1ca0  movq xmm14, xmm14
0000786bc93e1ca5  movaps [r15+0x110], xmm14
0000786bc93e1cad  mov eax, [r15+0x108]
0000786bc93e1cb4  sahf
0000786bc93e1cb5  jnz 0x0000786BC93E1CE7
0000786bc93e1cb7  cmp dword ptr [r15+0x318], 0x00
0000786bc93e1cbf  jz 0x0000786BC93E1FE0
0000786bc93e1cc5  nop [rax+rax*1], ax
0000786bc93e1cce  nop [rax+rax*1], eax
0000786bc93e1cd6  mov eax, 0x410490
0000786bc93e1cdb  mov [r15+0x100], rax
0000786bc93e1ce2  jmp 0x0000786BC91FE110
0000786bc93e1ce7  cmp dword ptr [r15+0x318], 0x00
0000786bc93e1cef  jz 0x0000786BC93E1E20
0000786bc93e1cf5  nop [rax+rax*1], ax
0000786bc93e1cfe  nop [rax+rax*1], eax
0000786bc93e1d06  mov eax, 0x410474
0000786bc93e1d0b  mov [r15+0x100], rax
0000786bc93e1d12  jmp 0x0000786BC91FE110
0000786bc93e1d17  int3
0000786bc93e1d18  call 0x0000786BC92E27E0
0000786bc93e1d1d  jmp 0x0000786BC93E1AC3
0000786bc93e1d22  call 0x0000786BC92E27E0
0000786bc93e1d27  jmp 0x0000786BC93E1AD6
0000786bc93e1d2c  call 0x0000786BC92E1570
0000786bc93e1d31  jmp 0x0000786BC93E1AE2
0000786bc93e1d36  call 0x0000786BC92E27E0
0000786bc93e1d3b  jmp 0x0000786BC93E1B1A
0000786bc93e1d40  call 0x0000786BC92E1570
0000786bc93e1d45  jmp 0x0000786BC93E1B26
0000786bc93e1d4a  call 0x0000786BC92E27E0
0000786bc93e1d4f  jmp 0x0000786BC93E1B5E
0000786bc93e1d54  call 0x0000786BC92E1570
0000786bc93e1d59  jmp 0x0000786BC93E1B6A
0000786bc93e1d5e  call 0x0000786BC92E27E0
0000786bc93e1d63  jmp 0x0000786BC93E1BA2
0000786bc93e1d68  call 0x0000786BC92E1570
0000786bc93e1d6d  jmp 0x0000786BC93E1BAE
0000786bc93e1d72  call 0x0000786BC92E27E0
0000786bc93e1d77  jmp 0x0000786BC93E1BED
0000786bc93e1d7c  call 0x0000786BC920E760
0000786bc93e1d81  jmp 0x0000786BC93E1C0A
0000786bc93e1d86  ucomisd xmm1, xmm15
0000786bc93e1d8b  jp 0x0000786BC93E1D9A
0000786bc93e1d8d  movaps xmm13, [0x0000786BC8FFE060]
0000786bc93e1d95  jmp 0x0000786BC93E1C73
0000786bc93e1d9a  vxorps xmm0, xmm1, xmm15
0000786bc93e1d9f  pextrw eax, xmm0, 0x03
0000786bc93e1da4  and eax, 0x7FF8
0000786bc93e1da9  cmp eax, 0x08
0000786bc93e1dac  jnz 0x0000786BC93E1C73
0000786bc93e1db2  movq rax, xmm15
0000786bc93e1db7  shl rax, 0x0D
0000786bc93e1dbb  jbe 0x0000786BC93E1C73
0000786bc93e1dc1  vorps xmm13, xmm15, [0x0000786BC8FFE070]
0000786bc93e1dc9  jmp 0x0000786BC93E1C73
0000786bc93e1dce  ucomisd xmm1, xmm15
0000786bc93e1dd3  jp 0x0000786BC93E1DE2
0000786bc93e1dd5  movaps xmm14, [0x0000786BC8FFE060]
0000786bc93e1ddd  jmp 0x0000786BC93E1CA0
0000786bc93e1de2  vxorps xmm0, xmm1, xmm15
0000786bc93e1de7  pextrw eax, xmm0, 0x03
0000786bc93e1dec  and eax, 0x7FF8
0000786bc93e1df1  cmp eax, 0x08
0000786bc93e1df4  jnz 0x0000786BC93E1CA0
0000786bc93e1dfa  movq rax, xmm15
0000786bc93e1dff  shl rax, 0x0D
0000786bc93e1e03  jbe 0x0000786BC93E1CA0
0000786bc93e1e09  vorps xmm14, xmm15, [0x0000786BC8FFE070]
0000786bc93e1e11  jmp 0x0000786BC93E1CA0
0000786bc93e1e16  int3
0000786bc93e1e17  nop [rax+rax*1], ax
0000786bc93e1e20  mov rax, [r15+0x48]
0000786bc93e1e24  mov r14, [r15+0x50]
0000786bc93e1e28  lea r12, [r14+rax*1]
0000786bc93e1e2c  movups xmm1, [r13+r12*1]
0000786bc93e1e32  movaps [r15+0x120], xmm1
0000786bc93e1e3a  lea r14, [rax+0x10]
0000786bc93e1e3e  mov [r15+0x48], r14
0000786bc93e1e42  xor eax, eax
0000786bc93e1e44  mov r12d, 0x200
0000786bc93e1e4a  cmp r14, r12
0000786bc93e1e4d  cmc
0000786bc93e1e4e  lahf
0000786bc93e1e4f  seto al
0000786bc93e1e52  mov [r15+0x108], eax
0000786bc93e1e59  pextrq rax, xmm1, 0x01
0000786bc93e1e60  movq xmm15, rax
0000786bc93e1e65  movaps [r15+0x130], xmm15
0000786bc93e1e6d  movaps xmm14, [r15+0x110]
0000786bc93e1e75  movq rax, xmm14
0000786bc93e1e7a  movq r14, xmm1
0000786bc93e1e7f  vmovq xmm1, rax
0000786bc93e1e84  vmovq xmm14, r14
0000786bc93e1e89  movaps xmm13, xmm1
0000786bc93e1e8d  addsd xmm13, xmm14
0000786bc93e1e92  ucomisd xmm13, xmm13
0000786bc93e1e97  jp 0x0000786BC93E1F4C
0000786bc93e1e9d  movq xmm13, xmm13
0000786bc93e1ea2  movq rax, xmm13
0000786bc93e1ea7  movq r14, xmm15
0000786bc93e1eac  vmovq xmm1, rax
0000786bc93e1eb1  vmovq xmm15, r14
0000786bc93e1eb6  movaps xmm14, xmm1
0000786bc93e1eba  addsd xmm14, xmm15
0000786bc93e1ebf  ucomisd xmm14, xmm14
0000786bc93e1ec4  jp 0x0000786BC93E1F94
0000786bc93e1eca  movq xmm14, xmm14
0000786bc93e1ecf  movaps [r15+0x110], xmm14
0000786bc93e1ed7  mov eax, [r15+0x108]
0000786bc93e1ede  sahf
0000786bc93e1edf  jnz 0x0000786BC93E1F11
0000786bc93e1ee1  cmp dword ptr [r15+0x318], 0x00
0000786bc93e1ee9  jz 0x0000786BC93E1FE0
0000786bc93e1eef  nop [rax+rax*1], ax
0000786bc93e1ef8  nop [rax+rax*1], eax
0000786bc93e1f00  mov eax, 0x410490
0000786bc93e1f05  mov [r15+0x100], rax
0000786bc93e1f0c  jmp 0x0000786BC91FE110
0000786bc93e1f11  cmp dword ptr [r15+0x318], 0x00
0000786bc93e1f19  jz 0x0000786BC93E1E20
0000786bc93e1f1f  nop [rax+rax*1], ax
0000786bc93e1f28  nop [rax+rax*1], eax
0000786bc93e1f30  mov eax, 0x410474
0000786bc93e1f35  mov [r15+0x100], rax
0000786bc93e1f3c  jmp 0x0000786BC91FE110
0000786bc93e1f41  int3
0000786bc93e1f42  call 0x0000786BC92B52F0
0000786bc93e1f47  jmp 0x0000786BC93E1E32
0000786bc93e1f4c  ucomisd xmm1, xmm14
0000786bc93e1f51  jp 0x0000786BC93E1F60
0000786bc93e1f53  movaps xmm13, [0x0000786BC8FFE060]
0000786bc93e1f5b  jmp 0x0000786BC93E1E9D
0000786bc93e1f60  vxorps xmm0, xmm1, xmm14
0000786bc93e1f65  pextrw eax, xmm0, 0x03
0000786bc93e1f6a  and eax, 0x7FF8
0000786bc93e1f6f  cmp eax, 0x08
0000786bc93e1f72  jnz 0x0000786BC93E1E9D
0000786bc93e1f78  movq rax, xmm14
0000786bc93e1f7d  shl rax, 0x0D
0000786bc93e1f81  jbe 0x0000786BC93E1E9D
0000786bc93e1f87  vorps xmm13, xmm14, [0x0000786BC8FFE070]
0000786bc93e1f8f  jmp 0x0000786BC93E1E9D
0000786bc93e1f94  ucomisd xmm1, xmm15
0000786bc93e1f99  jp 0x0000786BC93E1FA8
0000786bc93e1f9b  movaps xmm14, [0x0000786BC8FFE060]
0000786bc93e1fa3  jmp 0x0000786BC93E1ECA
0000786bc93e1fa8  vxorps xmm0, xmm1, xmm15
0000786bc93e1fad  pextrw eax, xmm0, 0x03
0000786bc93e1fb2  and eax, 0x7FF8
0000786bc93e1fb7  cmp eax, 0x08
0000786bc93e1fba  jnz 0x0000786BC93E1ECA
0000786bc93e1fc0  movq rax, xmm15
0000786bc93e1fc5  shl rax, 0x0D
0000786bc93e1fc9  jbe 0x0000786BC93E1ECA
0000786bc93e1fcf  vorps xmm14, xmm15, [0x0000786BC8FFE070]
0000786bc93e1fd7  jmp 0x0000786BC93E1ECA
0000786bc93e1fdc  int3
0000786bc93e1fdd  nop [rax], eax
0000786bc93e1fe0  mov rax, [r15+0x40]
0000786bc93e1fe4  lea r14, [rax+0x510]
0000786bc93e1feb  movaps xmm1, [r15+0x110]
0000786bc93e1ff3  movq rax, xmm1
0000786bc93e1ff8  mov [r13+r14*1], rax
0000786bc93e1ffd  mov rax, [r15+0xF0]
0000786bc93e2004  mov [r15+0x100], rax
0000786bc93e200b  jmp 0x0000786BC93CE5C0
0000786bc93e2010  int3
0000786bc93e2011  call 0x0000786BC92D5EB0
0000786bc93e2016  jmp 0x0000786BC93E1FFD
0000786bc93e201b  int3
0000786bc93e201c  nop [rax], eax
0000786bc93e2020  mov qword ptr [r15+0x100], 0x04
0000786bc93e202b  mov esi, 0x00
0000786bc93e2030  mov edx, 0x09
0000786bc93e2035  mov rdi, 0x7FFCEB658480
0000786bc93e203f  mov rax, 0x60810F58A970
0000786bc93e2049  call rax
0000786bc93e204b  cmp dword ptr [r15+0x318], 0x00
0000786bc93e2053  jnz 0x0000786BC91FE110
0000786bc93e2059  jmp 0x0000786BC91FE0A0
0000786bc93e205e  int3
0000786bc93e205f  int3
