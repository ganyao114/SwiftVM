000075d5269ce69b  nop [rax+rax*1], eax
000075d5269ce6a0  vmovaps xmm1, [0x000075D5265FE010]
000075d5269ce6a8  movq xmm1, xmm1
000075d5269ce6ac  movaps [r15+0x110], xmm1
000075d5269ce6b4  vmovaps xmm1, [0x000075D5265FE020]
000075d5269ce6bc  movq xmm1, xmm1
000075d5269ce6c0  movaps [r15+0x120], xmm1
000075d5269ce6c8  mov eax, 0x4204C0
000075d5269ce6cd  mov r14, [r13+rax*1]
000075d5269ce6d2  movq xmm1, r14
000075d5269ce6d7  movaps [r15+0x130], xmm1
000075d5269ce6df  vmovaps xmm1, [0x000075D5265FE030]
000075d5269ce6e7  vpbroadcastq xmm1, xmm1
000075d5269ce6ec  movaps [r15+0x140], xmm1
000075d5269ce6f4  mov qword ptr [r15+0x40], 0x02
000075d5269ce6fc  vmovaps xmm15, [0x000075D5265FE040]
000075d5269ce704  movq xmm15, xmm15
000075d5269ce709  movaps [r15+0x150], xmm15
000075d5269ce711  mov qword ptr [r15+0x58], 0x420000
000075d5269ce719  vmovaps xmm15, [0x000075D5265FE050]
000075d5269ce721  vpbroadcastq xmm15, xmm15
000075d5269ce726  movaps [r15+0x160], xmm15
000075d5269ce72e  mov rax, [r15+0x40]
000075d5269ce732  vmovq xmm14, rax
000075d5269ce737  vpbroadcastq xmm14, xmm14
000075d5269ce73c  movaps [r15+0x170], xmm14
000075d5269ce744  mov eax, 0x4204D0
000075d5269ce749  movups xmm13, [r13+rax*1]
000075d5269ce74f  mov qword ptr [r15+0x40], 0x430518
000075d5269ce757  mov qword ptr [r15+0x50], 0x430720
000075d5269ce75f  vpmovqd xmm12, xmm13
000075d5269ce765  pxor xmm11, xmm11
000075d5269ce76a  punpcklqdq xmm12, xmm11
000075d5269ce76f  movaps [r15+0x210], xmm12
000075d5269ce777  movq xmm12, qword ptr [r15+0x120]
000075d5269ce780  movq xmm11, qword ptr [r15+0x130]
000075d5269ce789  psubd xmm12, xmm11
000075d5269ce78e  movq xmm12, xmm12
000075d5269ce793  paddq xmm13, xmm14
000075d5269ce798  movaps [r15+0x180], xmm13
000075d5269ce7a0  movq xmm14, qword ptr [r15+0x150]
000075d5269ce7a9  paddd xmm11, xmm14
000075d5269ce7ae  movq xmm11, xmm11
000075d5269ce7b3  movq xmm11, xmm11
000075d5269ce7b8  movaps [r15+0x130], xmm11
000075d5269ce7c0  pmovzxdq xmm12, xmm12
000075d5269ce7c6  psllq xmm12, 0x00
000075d5269ce7cc  movq xmm14, qword ptr [r15+0x210]
000075d5269ce7d5  movq xmm13, qword ptr [r15+0x110]
000075d5269ce7de  paddd xmm14, xmm13
000075d5269ce7e3  movq xmm14, xmm14
000075d5269ce7e8  vcvtuqq2pd xmm12, xmm12
000075d5269ce7ee  pmovzxdq xmm14, xmm14
000075d5269ce7f4  psllq xmm14, 0x00
000075d5269ce7fa  vcvtuqq2pd xmm14, xmm14
000075d5269ce800  movaps xmm13, xmm12
000075d5269ce804  mulpd xmm13, xmm1
000075d5269ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000075d5269ce80f  ptest xmm11, xmm11
000075d5269ce815  jnz 0x000075D5269CE8FF
000075d5269ce81b  movaps [r15+0x220], xmm13
000075d5269ce823  mov eax, 0x430720
000075d5269ce828  movups [r13+rax*1], xmm13
000075d5269ce82e  movaps xmm1, xmm14
000075d5269ce832  mulpd xmm1, xmm15
000075d5269ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000075d5269ce83c  ptest xmm13, xmm13
000075d5269ce842  jnz 0x000075D5269CEA4C
000075d5269ce848  movaps [r15+0x210], xmm1
000075d5269ce850  mov eax, 0x430518
000075d5269ce855  movups [r13+rax*1], xmm1
000075d5269ce85b  mov qword ptr [r15+0x48], 0x10
000075d5269ce863  xor eax, eax
000075d5269ce865  mov r14d, 0x10
000075d5269ce86b  mov r12d, 0x200
000075d5269ce871  cmp r14, r12
000075d5269ce874  cmc
000075d5269ce875  lahf
000075d5269ce876  seto al
000075d5269ce879  mov [r15+0x108], eax
000075d5269ce880  mov eax, [r15+0x108]
000075d5269ce887  sahf
000075d5269ce888  jnz 0x000075D5269CE8BA
000075d5269ce88a  cmp dword ptr [r15+0x318], 0x00
000075d5269ce892  jz 0x000075D5269CEFF0
000075d5269ce898  nop [rax+rax*1], ax
000075d5269ce8a1  nop [rax+rax*1], eax
000075d5269ce8a9  mov eax, 0x4101EC
000075d5269ce8ae  mov [r15+0x100], rax
000075d5269ce8b5  jmp 0x000075D5267FE110
000075d5269ce8ba  cmp dword ptr [r15+0x318], 0x00
000075d5269ce8c2  jz 0x000075D5269CEBA0
000075d5269ce8c8  nop [rax+rax*1], ax
000075d5269ce8d1  nop [rax+rax*1], eax
000075d5269ce8d9  mov eax, 0x4101AC
000075d5269ce8de  mov [r15+0x100], rax
000075d5269ce8e5  jmp 0x000075D5267FE110
000075d5269ce8ea  int3
000075d5269ce8eb  call 0x000075D52680DC20
000075d5269ce8f0  jmp 0x000075D5269CE6D2
000075d5269ce8f5  call 0x000075D52680C260
000075d5269ce8fa  jmp 0x000075D5269CE74F
000075d5269ce8ff  sub rsp, 0x08
000075d5269ce903  push rax
000075d5269ce904  push rcx
000075d5269ce905  push rdx
000075d5269ce906  push rdi
000075d5269ce907  push rsi
000075d5269ce908  push r8
000075d5269ce90a  push r9
000075d5269ce90c  push r10
000075d5269ce90e  push r11
000075d5269ce910  sub rsp, 0xF0
000075d5269ce917  vmovaps [rsp], xmm0
000075d5269ce91c  vmovaps [rsp+0x10], xmm1
000075d5269ce922  vmovaps [rsp+0x20], xmm2
000075d5269ce928  vmovaps [rsp+0x30], xmm3
000075d5269ce92e  vmovaps [rsp+0x40], xmm4
000075d5269ce934  vmovaps [rsp+0x50], xmm5
000075d5269ce93a  vmovaps [rsp+0x60], xmm6
000075d5269ce940  vmovaps [rsp+0x70], xmm7
000075d5269ce946  vmovaps [rsp+0x80], xmm8
000075d5269ce94f  vmovaps [rsp+0x90], xmm9
000075d5269ce958  vmovaps [rsp+0xA0], xmm10
000075d5269ce961  vmovaps [rsp+0xB0], xmm11
000075d5269ce96a  vmovaps [rsp+0xC0], xmm12
000075d5269ce973  vmovaps [rsp+0xD0], xmm14
000075d5269ce97c  vmovaps [rsp+0xE0], xmm15
000075d5269ce985  sub rsp, 0x30
000075d5269ce989  movaps [rsp], xmm13
000075d5269ce98e  movaps [rsp+0x10], xmm12
000075d5269ce994  movaps [rsp+0x20], xmm1
000075d5269ce999  lea rdi, [rsp]
000075d5269ce99d  mov esi, 0x00
000075d5269ce9a2  mov rax, 0x601129E62530
000075d5269ce9ac  call rax
000075d5269ce9ae  movaps xmm13, [rsp]
000075d5269ce9b3  add rsp, 0x30
000075d5269ce9b7  vmovaps xmm0, [rsp]
000075d5269ce9bc  vmovaps xmm1, [rsp+0x10]
000075d5269ce9c2  vmovaps xmm2, [rsp+0x20]
000075d5269ce9c8  vmovaps xmm3, [rsp+0x30]
000075d5269ce9ce  vmovaps xmm4, [rsp+0x40]
000075d5269ce9d4  vmovaps xmm5, [rsp+0x50]
000075d5269ce9da  vmovaps xmm6, [rsp+0x60]
000075d5269ce9e0  vmovaps xmm7, [rsp+0x70]
000075d5269ce9e6  vmovaps xmm8, [rsp+0x80]
000075d5269ce9ef  vmovaps xmm9, [rsp+0x90]
000075d5269ce9f8  vmovaps xmm10, [rsp+0xA0]
000075d5269cea01  vmovaps xmm11, [rsp+0xB0]
000075d5269cea0a  vmovaps xmm12, [rsp+0xC0]
000075d5269cea13  vmovaps xmm14, [rsp+0xD0]
000075d5269cea1c  vmovaps xmm15, [rsp+0xE0]
000075d5269cea25  add rsp, 0xF0
000075d5269cea2c  pop r11
000075d5269cea2e  pop r10
000075d5269cea30  pop r9
000075d5269cea32  pop r8
000075d5269cea34  pop rsi
000075d5269cea35  pop rdi
000075d5269cea36  pop rdx
000075d5269cea37  pop rcx
000075d5269cea38  pop rax
000075d5269cea39  add rsp, 0x08
000075d5269cea3d  jmp 0x000075D5269CE81B
000075d5269cea42  call 0x000075D52680C380
000075d5269cea47  jmp 0x000075D5269CE82E
000075d5269cea4c  sub rsp, 0x08
000075d5269cea50  push rax
000075d5269cea51  push rcx
000075d5269cea52  push rdx
000075d5269cea53  push rdi
000075d5269cea54  push rsi
000075d5269cea55  push r8
000075d5269cea57  push r9
000075d5269cea59  push r10
000075d5269cea5b  push r11
000075d5269cea5d  sub rsp, 0xF0
000075d5269cea64  vmovaps [rsp], xmm0
000075d5269cea69  vmovaps [rsp+0x10], xmm2
000075d5269cea6f  vmovaps [rsp+0x20], xmm3
000075d5269cea75  vmovaps [rsp+0x30], xmm4
000075d5269cea7b  vmovaps [rsp+0x40], xmm5
000075d5269cea81  vmovaps [rsp+0x50], xmm6
000075d5269cea87  vmovaps [rsp+0x60], xmm7
000075d5269cea8d  vmovaps [rsp+0x70], xmm8
000075d5269cea93  vmovaps [rsp+0x80], xmm9
000075d5269cea9c  vmovaps [rsp+0x90], xmm10
000075d5269ceaa5  vmovaps [rsp+0xA0], xmm11
000075d5269ceaae  vmovaps [rsp+0xB0], xmm12
000075d5269ceab7  vmovaps [rsp+0xC0], xmm13
000075d5269ceac0  vmovaps [rsp+0xD0], xmm14
000075d5269ceac9  vmovaps [rsp+0xE0], xmm15
000075d5269cead2  sub rsp, 0x30
000075d5269cead6  movaps [rsp], xmm1
000075d5269ceada  movaps [rsp+0x10], xmm14
000075d5269ceae0  movaps [rsp+0x20], xmm15
000075d5269ceae6  lea rdi, [rsp]
000075d5269ceaea  mov esi, 0x00
000075d5269ceaef  mov rax, 0x601129E62530
000075d5269ceaf9  call rax
000075d5269ceafb  movaps xmm1, [rsp]
000075d5269ceaff  add rsp, 0x30
000075d5269ceb03  vmovaps xmm0, [rsp]
000075d5269ceb08  vmovaps xmm2, [rsp+0x10]
000075d5269ceb0e  vmovaps xmm3, [rsp+0x20]
000075d5269ceb14  vmovaps xmm4, [rsp+0x30]
000075d5269ceb1a  vmovaps xmm5, [rsp+0x40]
000075d5269ceb20  vmovaps xmm6, [rsp+0x50]
000075d5269ceb26  vmovaps xmm7, [rsp+0x60]
000075d5269ceb2c  vmovaps xmm8, [rsp+0x70]
000075d5269ceb32  vmovaps xmm9, [rsp+0x80]
000075d5269ceb3b  vmovaps xmm10, [rsp+0x90]
000075d5269ceb44  vmovaps xmm11, [rsp+0xA0]
000075d5269ceb4d  vmovaps xmm12, [rsp+0xB0]
000075d5269ceb56  vmovaps xmm13, [rsp+0xC0]
000075d5269ceb5f  vmovaps xmm14, [rsp+0xD0]
000075d5269ceb68  vmovaps xmm15, [rsp+0xE0]
000075d5269ceb71  add rsp, 0xF0
000075d5269ceb78  pop r11
000075d5269ceb7a  pop r10
000075d5269ceb7c  pop r9
000075d5269ceb7e  pop r8
000075d5269ceb80  pop rsi
000075d5269ceb81  pop rdi
000075d5269ceb82  pop rdx
000075d5269ceb83  pop rcx
000075d5269ceb84  pop rax
000075d5269ceb85  add rsp, 0x08
000075d5269ceb89  jmp 0x000075D5269CE848
000075d5269ceb8e  call 0x000075D5267FF540
000075d5269ceb93  jmp 0x000075D5269CE85B
000075d5269ceb98  int3
000075d5269ceb99  nop [rax], eax
000075d5269ceba0  movaps xmm1, [r15+0x180]
000075d5269ceba8  vpmovqd xmm15, xmm1
000075d5269cebae  pxor xmm14, xmm14
000075d5269cebb3  punpcklqdq xmm15, xmm14
000075d5269cebb8  movaps [r15+0x210], xmm15
000075d5269cebc0  movq xmm15, qword ptr [r15+0x120]
000075d5269cebc9  movq xmm14, qword ptr [r15+0x130]
000075d5269cebd2  psubd xmm15, xmm14
000075d5269cebd7  movq xmm15, xmm15
000075d5269cebdc  movaps xmm13, [r15+0x170]
000075d5269cebe4  paddq xmm1, xmm13
000075d5269cebe9  movaps [r15+0x180], xmm1
000075d5269cebf1  movq xmm1, qword ptr [r15+0x150]
000075d5269cebfa  paddd xmm14, xmm1
000075d5269cebff  movq xmm14, xmm14
000075d5269cec04  movq xmm14, xmm14
000075d5269cec09  movaps [r15+0x130], xmm14
000075d5269cec11  pmovzxdq xmm15, xmm15
000075d5269cec17  psllq xmm15, 0x00
000075d5269cec1d  movq xmm1, qword ptr [r15+0x210]
000075d5269cec26  movq xmm14, qword ptr [r15+0x110]
000075d5269cec2f  paddd xmm1, xmm14
000075d5269cec34  movq xmm1, xmm1
000075d5269cec38  vcvtuqq2pd xmm15, xmm15
000075d5269cec3e  pmovzxdq xmm1, xmm1
000075d5269cec43  psllq xmm1, 0x00
000075d5269cec48  vcvtuqq2pd xmm1, xmm1
000075d5269cec4e  movaps xmm14, [r15+0x140]
000075d5269cec56  movaps xmm13, xmm15
000075d5269cec5a  mulpd xmm13, xmm14
000075d5269cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000075d5269cec65  ptest xmm12, xmm12
000075d5269cec6b  jnz 0x000075D5269CED4E
000075d5269cec71  movaps [r15+0x220], xmm13
000075d5269cec79  mov rax, [r15+0x48]
000075d5269cec7d  mov r14, [r15+0x50]
000075d5269cec81  lea r12, [r14+rax*1]
000075d5269cec85  movups [r13+r12*1], xmm13
000075d5269cec8b  movaps xmm15, [r15+0x160]
000075d5269cec93  movaps xmm14, xmm1
000075d5269cec97  mulpd xmm14, xmm15
000075d5269cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000075d5269ceca2  ptest xmm13, xmm13
000075d5269ceca8  jnz 0x000075D5269CEE9C
000075d5269cecae  movaps [r15+0x210], xmm14
000075d5269cecb6  mov r14, [r15+0x40]
000075d5269cecba  lea r12, [r14+rax*1]
000075d5269cecbe  movups [r13+r12*1], xmm14
000075d5269cecc4  lea r14, [rax+0x10]
000075d5269cecc8  mov [r15+0x48], r14
000075d5269ceccc  xor eax, eax
000075d5269cecce  mov r12d, 0x200
000075d5269cecd4  cmp r14, r12
000075d5269cecd7  cmc
000075d5269cecd8  lahf
000075d5269cecd9  seto al
000075d5269cecdc  mov [r15+0x108], eax
000075d5269cece3  mov eax, [r15+0x108]
000075d5269cecea  sahf
000075d5269ceceb  jnz 0x000075D5269CED1D
000075d5269ceced  cmp dword ptr [r15+0x318], 0x00
000075d5269cecf5  jz 0x000075D5269CEFF0
000075d5269cecfb  nop [rax+rax*1], ax
000075d5269ced04  nop [rax+rax*1], eax
000075d5269ced0c  mov eax, 0x4101EC
000075d5269ced11  mov [r15+0x100], rax
000075d5269ced18  jmp 0x000075D5267FE110
000075d5269ced1d  cmp dword ptr [r15+0x318], 0x00
000075d5269ced25  jz 0x000075D5269CEBA0
000075d5269ced2b  nop [rax+rax*1], ax
000075d5269ced34  nop [rax+rax*1], eax
000075d5269ced3c  mov eax, 0x4101AC
000075d5269ced41  mov [r15+0x100], rax
000075d5269ced48  jmp 0x000075D5267FE110
000075d5269ced4d  int3
000075d5269ced4e  sub rsp, 0x08
000075d5269ced52  push rax
000075d5269ced53  push rcx
000075d5269ced54  push rdx
000075d5269ced55  push rdi
000075d5269ced56  push rsi
000075d5269ced57  push r8
000075d5269ced59  push r9
000075d5269ced5b  push r10
000075d5269ced5d  push r11
000075d5269ced5f  sub rsp, 0xF0
000075d5269ced66  vmovaps [rsp], xmm0
000075d5269ced6b  vmovaps [rsp+0x10], xmm1
000075d5269ced71  vmovaps [rsp+0x20], xmm2
000075d5269ced77  vmovaps [rsp+0x30], xmm3
000075d5269ced7d  vmovaps [rsp+0x40], xmm4
000075d5269ced83  vmovaps [rsp+0x50], xmm5
000075d5269ced89  vmovaps [rsp+0x60], xmm6
000075d5269ced8f  vmovaps [rsp+0x70], xmm7
000075d5269ced95  vmovaps [rsp+0x80], xmm8
000075d5269ced9e  vmovaps [rsp+0x90], xmm9
000075d5269ceda7  vmovaps [rsp+0xA0], xmm10
000075d5269cedb0  vmovaps [rsp+0xB0], xmm11
000075d5269cedb9  vmovaps [rsp+0xC0], xmm12
000075d5269cedc2  vmovaps [rsp+0xD0], xmm14
000075d5269cedcb  vmovaps [rsp+0xE0], xmm15
000075d5269cedd4  sub rsp, 0x30
000075d5269cedd8  movaps [rsp], xmm13
000075d5269ceddd  movaps [rsp+0x10], xmm15
000075d5269cede3  movaps [rsp+0x20], xmm14
000075d5269cede9  lea rdi, [rsp]
000075d5269ceded  mov esi, 0x00
000075d5269cedf2  mov rax, 0x601129E62530
000075d5269cedfc  call rax
000075d5269cedfe  movaps xmm13, [rsp]
000075d5269cee03  add rsp, 0x30
000075d5269cee07  vmovaps xmm0, [rsp]
000075d5269cee0c  vmovaps xmm1, [rsp+0x10]
000075d5269cee12  vmovaps xmm2, [rsp+0x20]
000075d5269cee18  vmovaps xmm3, [rsp+0x30]
000075d5269cee1e  vmovaps xmm4, [rsp+0x40]
000075d5269cee24  vmovaps xmm5, [rsp+0x50]
000075d5269cee2a  vmovaps xmm6, [rsp+0x60]
000075d5269cee30  vmovaps xmm7, [rsp+0x70]
000075d5269cee36  vmovaps xmm8, [rsp+0x80]
000075d5269cee3f  vmovaps xmm9, [rsp+0x90]
000075d5269cee48  vmovaps xmm10, [rsp+0xA0]
000075d5269cee51  vmovaps xmm11, [rsp+0xB0]
000075d5269cee5a  vmovaps xmm12, [rsp+0xC0]
000075d5269cee63  vmovaps xmm14, [rsp+0xD0]
000075d5269cee6c  vmovaps xmm15, [rsp+0xE0]
000075d5269cee75  add rsp, 0xF0
000075d5269cee7c  pop r11
000075d5269cee7e  pop r10
000075d5269cee80  pop r9
000075d5269cee82  pop r8
000075d5269cee84  pop rsi
000075d5269cee85  pop rdi
000075d5269cee86  pop rdx
000075d5269cee87  pop rcx
000075d5269cee88  pop rax
000075d5269cee89  add rsp, 0x08
000075d5269cee8d  jmp 0x000075D5269CEC71
000075d5269cee92  call 0x000075D5268C2240
000075d5269cee97  jmp 0x000075D5269CEC8B
000075d5269cee9c  sub rsp, 0x08
000075d5269ceea0  push rax
000075d5269ceea1  push rcx
000075d5269ceea2  push rdx
000075d5269ceea3  push rdi
000075d5269ceea4  push rsi
000075d5269ceea5  push r8
000075d5269ceea7  push r9
000075d5269ceea9  push r10
000075d5269ceeab  push r11
000075d5269ceead  sub rsp, 0xF0
000075d5269ceeb4  vmovaps [rsp], xmm0
000075d5269ceeb9  vmovaps [rsp+0x10], xmm1
000075d5269ceebf  vmovaps [rsp+0x20], xmm2
000075d5269ceec5  vmovaps [rsp+0x30], xmm3
000075d5269ceecb  vmovaps [rsp+0x40], xmm4
000075d5269ceed1  vmovaps [rsp+0x50], xmm5
000075d5269ceed7  vmovaps [rsp+0x60], xmm6
000075d5269ceedd  vmovaps [rsp+0x70], xmm7
000075d5269ceee3  vmovaps [rsp+0x80], xmm8
000075d5269ceeec  vmovaps [rsp+0x90], xmm9
000075d5269ceef5  vmovaps [rsp+0xA0], xmm10
000075d5269ceefe  vmovaps [rsp+0xB0], xmm11
000075d5269cef07  vmovaps [rsp+0xC0], xmm12
000075d5269cef10  vmovaps [rsp+0xD0], xmm13
000075d5269cef19  vmovaps [rsp+0xE0], xmm15
000075d5269cef22  sub rsp, 0x30
000075d5269cef26  movaps [rsp], xmm14
000075d5269cef2b  movaps [rsp+0x10], xmm1
000075d5269cef30  movaps [rsp+0x20], xmm15
000075d5269cef36  lea rdi, [rsp]
000075d5269cef3a  mov esi, 0x00
000075d5269cef3f  mov rax, 0x601129E62530
000075d5269cef49  call rax
000075d5269cef4b  movaps xmm14, [rsp]
000075d5269cef50  add rsp, 0x30
000075d5269cef54  vmovaps xmm0, [rsp]
000075d5269cef59  vmovaps xmm1, [rsp+0x10]
000075d5269cef5f  vmovaps xmm2, [rsp+0x20]
000075d5269cef65  vmovaps xmm3, [rsp+0x30]
000075d5269cef6b  vmovaps xmm4, [rsp+0x40]
000075d5269cef71  vmovaps xmm5, [rsp+0x50]
000075d5269cef77  vmovaps xmm6, [rsp+0x60]
000075d5269cef7d  vmovaps xmm7, [rsp+0x70]
000075d5269cef83  vmovaps xmm8, [rsp+0x80]
000075d5269cef8c  vmovaps xmm9, [rsp+0x90]
000075d5269cef95  vmovaps xmm10, [rsp+0xA0]
000075d5269cef9e  vmovaps xmm11, [rsp+0xB0]
000075d5269cefa7  vmovaps xmm12, [rsp+0xC0]
000075d5269cefb0  vmovaps xmm13, [rsp+0xD0]
000075d5269cefb9  vmovaps xmm15, [rsp+0xE0]
000075d5269cefc2  add rsp, 0xF0
000075d5269cefc9  pop r11
000075d5269cefcb  pop r10
000075d5269cefcd  pop r9
000075d5269cefcf  pop r8
000075d5269cefd1  pop rsi
000075d5269cefd2  pop rdi
000075d5269cefd3  pop rdx
000075d5269cefd4  pop rcx
000075d5269cefd5  pop rax
000075d5269cefd6  add rsp, 0x08
000075d5269cefda  jmp 0x000075D5269CECAE
000075d5269cefdf  call 0x000075D5268C34C0
000075d5269cefe4  jmp 0x000075D5269CECC4
000075d5269cefe9  int3
000075d5269cefea  nop [rax+rax*1], ax
000075d5269ceff0  mov rax, [r15+0xF8]
000075d5269ceff7  lea r14, [rax-0x150]
000075d5269ceffe  mov [r15+0xF8], r14
000075d5269cf005  mov rax, [r15+0x50]
000075d5269cf009  lea r12, [rax+0x80]
000075d5269cf010  movups xmm1, [r13+r12*1]
000075d5269cf016  lea r12, [rax+0x90]
000075d5269cf01d  movups xmm15, [r13+r12*1]
000075d5269cf023  mov qword ptr [r15+0x48], 0x00
000075d5269cf02b  lea r12, [rax+0x40]
000075d5269cf02f  movups xmm14, [r13+r12*1]
000075d5269cf035  lea r12, [rax+0x50]
000075d5269cf039  movups xmm13, [r13+r12*1]
000075d5269cf03f  lea r12, [r14+0x120]
000075d5269cf046  movq xmm12, qword ptr [r15+0x1C0]
000075d5269cf04f  movq xmm11, qword ptr [r15+0x1B0]
000075d5269cf058  movq r11, xmm12
000075d5269cf05d  movq r10, xmm11
000075d5269cf062  mov [r13+r12*1], r11
000075d5269cf067  lea r12, [r14+0x128]
000075d5269cf06e  mov [r13+r12*1], r10
000075d5269cf073  vxorps xmm12, xmm12, xmm12
000075d5269cf078  vpbroadcastq xmm12, xmm12
000075d5269cf07d  lea r12, [r14+0x100]
000075d5269cf084  movq xmm11, qword ptr [r15+0x200]
000075d5269cf08d  movq xmm10, qword ptr [r15+0x1F0]
000075d5269cf096  movq r11, xmm11
000075d5269cf09b  movq r10, xmm10
000075d5269cf0a0  mov [r13+r12*1], r11
000075d5269cf0a5  lea r12, [r14+0x108]
000075d5269cf0ac  mov [r13+r12*1], r10
000075d5269cf0b1  lea r12, [r14+0xE0]
000075d5269cf0b8  movups [r13+r12*1], xmm15
000075d5269cf0be  lea r12, [r14+0xF0]
000075d5269cf0c5  movups [r13+r12*1], xmm1
000075d5269cf0cb  lea r12, [rax+0xC0]
000075d5269cf0d2  movups xmm1, [r13+r12*1]
000075d5269cf0d8  lea r12, [rax+0xD0]
000075d5269cf0df  movups xmm15, [r13+r12*1]
000075d5269cf0e5  lea r12, [r14+0x110]
000075d5269cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000075d5269cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000075d5269cf0fe  movq r11, xmm11
000075d5269cf103  movq r10, xmm10
000075d5269cf108  mov [r13+r12*1], r11
000075d5269cf10d  lea r12, [r14+0x118]
000075d5269cf114  mov [r13+r12*1], r10
000075d5269cf119  movups xmm11, [r13+rax*1]
000075d5269cf11f  lea r12, [rax+0x10]
000075d5269cf123  movups xmm10, [r13+r12*1]
000075d5269cf129  lea r12, [r14+0x130]
000075d5269cf130  movq xmm9, qword ptr [r15+0x1A0]
000075d5269cf139  movq xmm8, qword ptr [r15+0x190]
000075d5269cf142  movq r11, xmm9
000075d5269cf147  movq r10, xmm8
000075d5269cf14c  mov [r13+r12*1], r11
000075d5269cf151  lea r12, [r14+0x138]
000075d5269cf158  mov [r13+r12*1], r10
000075d5269cf15d  lea r12, [rax+0x140]
000075d5269cf164  movups xmm9, [r13+r12*1]
000075d5269cf16a  lea r12, [rax+0x150]
000075d5269cf171  movups xmm8, [r13+r12*1]
000075d5269cf177  lea r12, [r14+0xC0]
000075d5269cf17e  movups [r13+r12*1], xmm15
000075d5269cf184  lea r12, [r14+0xD0]
000075d5269cf18b  movups [r13+r12*1], xmm1
000075d5269cf191  lea r12, [rax+0x100]
000075d5269cf198  movups xmm1, [r13+r12*1]
000075d5269cf19e  lea r12, [rax+0x110]
000075d5269cf1a5  movups xmm15, [r13+r12*1]
000075d5269cf1ab  lea r12, [r14+0x140]
000075d5269cf1b2  mov r11, [r15+0xE8]
000075d5269cf1b9  mov [r13+r12*1], r11
000075d5269cf1be  lea r12, [rax+0x180]
000075d5269cf1c5  movups xmm7, [r13+r12*1]
000075d5269cf1cb  lea r12, [rax+0x190]
000075d5269cf1d2  movups xmm6, [r13+r12*1]
000075d5269cf1d8  lea r12, [rax+0x1C0]
000075d5269cf1df  movups xmm5, [r13+r12*1]
000075d5269cf1e5  lea r12, [rax+0x1D0]
000075d5269cf1ec  movups xmm4, [r13+r12*1]
000075d5269cf1f2  lea r12, [r14+0x20]
000075d5269cf1f6  movups [r13+r12*1], xmm1
000075d5269cf1fc  lea r12, [r14+0x30]
000075d5269cf200  movups [r13+r12*1], xmm13
000075d5269cf206  lea r12, [rax+0x60]
000075d5269cf20a  movups xmm1, [r13+r12*1]
000075d5269cf210  lea r12, [rax+0x70]
000075d5269cf214  movups xmm13, [r13+r12*1]
000075d5269cf21a  lea r12, [rax+0x20]
000075d5269cf21e  movups xmm3, [r13+r12*1]
000075d5269cf224  lea r12, [rax+0x30]
000075d5269cf228  movups xmm2, [r13+r12*1]
000075d5269cf22e  movaps [r15+0x1F0], xmm2
000075d5269cf236  lea r12, [r14+0x60]
000075d5269cf23a  movups [r13+r12*1], xmm11
000075d5269cf240  lea r12, [r14+0x70]
000075d5269cf244  movups [r13+r12*1], xmm5
000075d5269cf24a  lea r12, [rax+0xE0]
000075d5269cf251  movups xmm11, [r13+r12*1]
000075d5269cf257  lea r12, [rax+0xF0]
000075d5269cf25e  movups xmm5, [r13+r12*1]
000075d5269cf264  lea r12, [r14+0xA0]
000075d5269cf26b  movups [r13+r12*1], xmm13
000075d5269cf271  lea r12, [r14+0xB0]
000075d5269cf278  movups [r13+r12*1], xmm1
000075d5269cf27e  lea r12, [rax+0xA0]
000075d5269cf285  movups xmm1, [r13+r12*1]
000075d5269cf28b  lea r12, [rax+0xB0]
000075d5269cf292  movups xmm13, [r13+r12*1]
000075d5269cf298  lea r12, [rax+0x120]
000075d5269cf29f  vmovaps [rsp+0x10], xmm1
000075d5269cf2a5  movups xmm1, [r13+r12*1]
000075d5269cf2ab  lea r12, [rax+0x130]
000075d5269cf2b2  vmovaps [rsp+0x20], xmm1
000075d5269cf2b8  movups xmm1, [r13+r12*1]
000075d5269cf2be  lea r12, [rax+0x160]
000075d5269cf2c5  vmovaps [rsp+0x30], xmm1
000075d5269cf2cb  movups xmm1, [r13+r12*1]
000075d5269cf2d1  lea r12, [rax+0x170]
000075d5269cf2d8  vmovaps [rsp+0x40], xmm1
000075d5269cf2de  movups xmm1, [r13+r12*1]
000075d5269cf2e4  movaps [r15+0x2B0], xmm1
000075d5269cf2ec  lea r12, [r14+0x80]
000075d5269cf2f3  movups [r13+r12*1], xmm13
000075d5269cf2f9  lea r12, [r14+0x90]
000075d5269cf300  vmovaps xmm13, [rsp+0x10]
000075d5269cf306  movups [r13+r12*1], xmm13
000075d5269cf30c  lea r12, [rax+0x1A0]
000075d5269cf313  movups xmm13, [r13+r12*1]
000075d5269cf319  lea r12, [rax+0x1B0]
000075d5269cf320  vmovaps [rsp+0x10], xmm1
000075d5269cf326  movups xmm1, [r13+r12*1]
000075d5269cf32c  movaps [r15+0x290], xmm13
000075d5269cf334  movaps [r15+0x1E0], xmm1
000075d5269cf33c  lea r12, [rax+0x1E0]
000075d5269cf343  vmovaps [rsp+0x50], xmm1
000075d5269cf349  movups xmm1, [r13+r12*1]
000075d5269cf34f  lea r12, [rax+0x1F0]
000075d5269cf356  vmovaps [rsp+0x60], xmm1
000075d5269cf35c  movups xmm1, [r13+r12*1]
000075d5269cf362  mov qword ptr [r15+0x50], 0x430920
000075d5269cf36a  lea rax, [r14+0x40]
000075d5269cf36e  vmovaps [rsp+0x70], xmm1
000075d5269cf374  vmovaps xmm1, [rsp+0x40]
000075d5269cf37a  movups [r13+rax*1], xmm1
000075d5269cf380  lea rax, [r14+0x50]
000075d5269cf384  movups [r13+rax*1], xmm10
000075d5269cf38a  vmovaps xmm1, [rsp+0x70]
000075d5269cf390  movups [r13+r14*1], xmm1
000075d5269cf396  lea rax, [r14+0x10]
000075d5269cf39a  vmovaps xmm1, [rsp+0x60]
000075d5269cf3a0  movups [r13+rax*1], xmm1
000075d5269cf3a6  mov rax, [r15+0x40]
000075d5269cf3aa  vmovaps [rsp+0x40], xmm3
000075d5269cf3b0  vmovaps xmm1, [rsp+0x40]
000075d5269cf3b6  por xmm3, xmm1
000075d5269cf3ba  vmovaps [rsp+0x40], xmm6
000075d5269cf3c0  vmovaps xmm10, [rsp+0x40]
000075d5269cf3c6  por xmm6, xmm10
000075d5269cf3cb  lea r12, [rax+0x30]
000075d5269cf3cf  mov r11, [r13+r12*1]
000075d5269cf3d4  lea r12, [rax+0x38]
000075d5269cf3d8  mov r10, [r13+r12*1]
000075d5269cf3dd  movq xmm10, r11
000075d5269cf3e2  vmovaps [rsp+0x40], xmm1
000075d5269cf3e8  movq xmm1, r10
000075d5269cf3ed  movq xmm10, xmm10
000075d5269cf3f2  vmovaps [rsp+0x60], xmm10
000075d5269cf3f8  movq xmm10, xmm10
000075d5269cf3fd  movaps [r15+0x130], xmm10
000075d5269cf405  movq xmm1, xmm1
000075d5269cf409  vmovaps [rsp+0x70], xmm1
000075d5269cf40f  movq xmm1, xmm1
000075d5269cf413  movaps [r15+0x280], xmm1
000075d5269cf41b  vmovaps [rsp+0x80], xmm9
000075d5269cf424  vmovaps xmm1, [rsp+0x80]
000075d5269cf42d  por xmm9, xmm1
000075d5269cf432  lea r12, [rax+0x20]
000075d5269cf436  mov r11, [r13+r12*1]
000075d5269cf43b  lea r12, [rax+0x28]
000075d5269cf43f  mov r10, [r13+r12*1]
000075d5269cf444  movq xmm1, r11
000075d5269cf449  movq xmm10, r10
000075d5269cf44e  movq xmm1, xmm1
000075d5269cf452  vmovaps [rsp+0x80], xmm1
000075d5269cf45b  movq xmm1, xmm1
000075d5269cf45f  movaps [r15+0x150], xmm1
000075d5269cf467  movq xmm10, xmm10
000075d5269cf46c  vmovaps [rsp+0x90], xmm10
000075d5269cf475  movq xmm10, xmm10
000075d5269cf47a  movaps [r15+0x140], xmm10
000075d5269cf482  lea r12, [rax+0x10]
000075d5269cf486  mov r11, [r13+r12*1]
000075d5269cf48b  lea r12, [rax+0x18]
000075d5269cf48f  mov r10, [r13+r12*1]
000075d5269cf494  movq xmm1, r11
000075d5269cf499  movq xmm10, r10
000075d5269cf49e  movq xmm1, xmm1
000075d5269cf4a2  vmovaps [rsp+0xA0], xmm1
000075d5269cf4ab  movq xmm1, xmm1
000075d5269cf4af  movaps [r15+0x170], xmm1
000075d5269cf4b7  movq xmm10, xmm10
000075d5269cf4bc  vmovaps [rsp+0xB0], xmm10
000075d5269cf4c5  movq xmm10, xmm10
000075d5269cf4ca  movaps [r15+0x160], xmm10
000075d5269cf4d2  mov r12, [r13+rax*1]
000075d5269cf4d7  vmovq xmm1, r12
000075d5269cf4dc  vpbroadcastq xmm1, xmm1
000075d5269cf4e1  lea r12, [rax+0x08]
000075d5269cf4e5  mov rax, [r13+r12*1]
000075d5269cf4ea  movq xmm10, rax
000075d5269cf4ef  movaps [r15+0x230], xmm10
000075d5269cf4f7  lea rax, [r14+0x50]
000075d5269cf4fb  movups xmm10, [r13+rax*1]
000075d5269cf501  lea rax, [r14+0x60]
000075d5269cf505  vmovaps [rsp+0xC0], xmm1
000075d5269cf50e  movups xmm1, [r13+rax*1]
000075d5269cf514  lea rax, [r14+0x30]
000075d5269cf518  vmovaps [rsp+0xD0], xmm1
000075d5269cf521  movups xmm1, [r13+rax*1]
000075d5269cf527  mov qword ptr [r15+0x60], 0x430920
000075d5269cf52f  mov qword ptr [r15+0x58], 0x40
000075d5269cf537  vmovaps [rsp+0xE0], xmm1
000075d5269cf540  vmovaps [rsp+0xF0], xmm15
000075d5269cf549  vmovaps xmm15, [rsp+0xC0]
000075d5269cf552  vmovaps [rsp+0xC0], xmm14
000075d5269cf55b  vmovaps xmm14, [rsp+0x40]
000075d5269cf561  vmovaps [rsp+0x40], xmm13
000075d5269cf567  movaps xmm1, xmm15
000075d5269cf56b  mulpd xmm1, xmm14
000075d5269cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000075d5269cf575  ptest xmm13, xmm13
000075d5269cf57b  jnz 0x000075D5269D0682
000075d5269cf581  movq xmm14, qword ptr [r15+0x230]
000075d5269cf58a  vmovaps [rsp+0x100], xmm14
000075d5269cf593  vpermilpd xmm14, xmm14, 0x00
000075d5269cf599  vmovaps [rsp+0x110], xmm1
000075d5269cf5a2  vmovaps xmm1, [rsp+0xE0]
000075d5269cf5ab  vmovaps [rsp+0xE0], xmm15
000075d5269cf5b4  movaps xmm13, xmm1
000075d5269cf5b8  mulpd xmm13, xmm14
000075d5269cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000075d5269cf5c3  ptest xmm15, xmm15
000075d5269cf5c9  jnz 0x000075D5269D07C4
000075d5269cf5cf  vxorps xmm1, xmm1, xmm1
000075d5269cf5d3  vpbroadcastq xmm1, xmm1
000075d5269cf5d8  vmovaps xmm14, [rsp+0xE0]
000075d5269cf5e1  vmovaps [rsp+0xE0], xmm1
000075d5269cf5ea  vmovaps xmm1, [rsp+0xD0]
000075d5269cf5f3  vmovaps [rsp+0xD0], xmm13
000075d5269cf5fc  movaps xmm15, xmm14
000075d5269cf600  mulpd xmm15, xmm1
000075d5269cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000075d5269cf60b  ptest xmm13, xmm13
000075d5269cf611  jnz 0x000075D5269D0907
000075d5269cf617  movaps xmm1, xmm14
000075d5269cf61b  mulpd xmm1, xmm10
000075d5269cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000075d5269cf625  ptest xmm13, xmm13
000075d5269cf62b  jnz 0x000075D5269D0A4A
000075d5269cf631  movaps xmm13, xmm14
000075d5269cf635  mulpd xmm13, xmm2
000075d5269cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000075d5269cf640  ptest xmm10, xmm10
000075d5269cf646  jnz 0x000075D5269D0B8C
000075d5269cf64c  vmovaps [rsp+0x120], xmm7
000075d5269cf655  vmovaps xmm14, [rsp+0x120]
000075d5269cf65e  por xmm7, xmm14
000075d5269cf663  vmovaps xmm14, [rsp+0xC0]
000075d5269cf66c  vmovaps xmm10, [rsp+0xC0]
000075d5269cf675  por xmm14, xmm10
000075d5269cf67a  vmovaps xmm2, [rsp+0x100]
000075d5269cf683  vpermilpd xmm2, xmm2, 0x00
000075d5269cf689  vmovaps [rsp+0xC0], xmm1
000075d5269cf692  vmovaps [rsp+0x120], xmm15
000075d5269cf69b  movaps xmm1, xmm10
000075d5269cf69f  mulpd xmm1, xmm2
000075d5269cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000075d5269cf6a8  ptest xmm15, xmm15
000075d5269cf6ae  jnz 0x000075D5269D0CCF
000075d5269cf6b4  xor eax, eax
000075d5269cf6b6  mov r12d, 0x40
000075d5269cf6bc  mov r11d, 0x200
000075d5269cf6c2  cmp r12, r11
000075d5269cf6c5  cmc
000075d5269cf6c6  lahf
000075d5269cf6c7  seto al
000075d5269cf6ca  mov [r15+0x108], eax
000075d5269cf6d1  vmovaps xmm10, [rsp+0x110]
000075d5269cf6da  vmovaps xmm2, [rsp+0xE0]
000075d5269cf6e3  vmovaps [rsp+0xE0], xmm1
000075d5269cf6ec  movaps xmm15, xmm10
000075d5269cf6f0  addpd xmm15, xmm2
000075d5269cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269cf6fb  ptest xmm1, xmm1
000075d5269cf700  jnz 0x000075D5269D0E10
000075d5269cf706  vmovaps xmm10, [rsp+0x120]
000075d5269cf70f  vmovaps [rsp+0x110], xmm15
000075d5269cf718  movaps xmm1, xmm10
000075d5269cf71c  addpd xmm1, xmm12
000075d5269cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000075d5269cf726  ptest xmm15, xmm15
000075d5269cf72c  jnz 0x000075D5269D0F53
000075d5269cf732  vmovaps xmm10, [rsp+0xC0]
000075d5269cf73b  vmovaps [rsp+0xC0], xmm1
000075d5269cf744  movaps xmm15, xmm10
000075d5269cf748  addpd xmm15, xmm12
000075d5269cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269cf753  ptest xmm1, xmm1
000075d5269cf758  jnz 0x000075D5269D1095
000075d5269cf75e  vmovaps xmm1, [rsp+0x30]
000075d5269cf764  vmovaps xmm12, [rsp+0x30]
000075d5269cf76a  por xmm1, xmm12
000075d5269cf76f  vmovaps xmm12, [rsp+0x20]
000075d5269cf775  vmovaps xmm10, [rsp+0x20]
000075d5269cf77b  por xmm12, xmm10
000075d5269cf780  vmovaps [rsp+0x20], xmm5
000075d5269cf786  vmovaps xmm10, [rsp+0x20]
000075d5269cf78c  por xmm5, xmm10
000075d5269cf791  vmovaps [rsp+0x20], xmm11
000075d5269cf797  vmovaps xmm10, [rsp+0x20]
000075d5269cf79d  por xmm11, xmm10
000075d5269cf7a2  vmovaps [rsp+0x20], xmm4
000075d5269cf7a8  vmovaps xmm10, [rsp+0x20]
000075d5269cf7ae  por xmm4, xmm10
000075d5269cf7b3  vmovaps [rsp+0x20], xmm8
000075d5269cf7b9  vmovaps xmm10, [rsp+0x20]
000075d5269cf7bf  por xmm8, xmm10
000075d5269cf7c4  vmovaps xmm10, [rsp+0xF0]
000075d5269cf7cd  vmovaps [rsp+0x20], xmm1
000075d5269cf7d3  vmovaps xmm1, [rsp+0xF0]
000075d5269cf7dc  por xmm10, xmm1
000075d5269cf7e1  lea rax, [r14+0xA0]
000075d5269cf7e8  movups xmm1, [r13+rax*1]
000075d5269cf7ee  lea rax, [r14+0xB0]
000075d5269cf7f5  vmovaps [rsp+0x30], xmm1
000075d5269cf7fb  movups xmm1, [r13+rax*1]
000075d5269cf801  vmovaps [rsp+0xF0], xmm1
000075d5269cf80a  vmovaps [rsp+0x120], xmm15
000075d5269cf813  movaps xmm1, xmm13
000075d5269cf817  addpd xmm1, xmm2
000075d5269cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000075d5269cf820  ptest xmm15, xmm15
000075d5269cf826  jnz 0x000075D5269D11ED
000075d5269cf82c  lea rax, [r14+0xF0]
000075d5269cf833  movups xmm15, [r13+rax*1]
000075d5269cf839  vmovaps xmm2, [rsp+0xC0]
000075d5269cf842  vmovaps [rsp+0xC0], xmm1
000075d5269cf84b  vmovaps xmm1, [rsp+0xE0]
000075d5269cf854  vmovaps [rsp+0xE0], xmm15
000075d5269cf85d  movaps xmm13, xmm2
000075d5269cf861  addpd xmm13, xmm1
000075d5269cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000075d5269cf86c  ptest xmm15, xmm15
000075d5269cf872  jnz 0x000075D5269D1338
000075d5269cf878  vmovaps xmm15, [rsp+0x120]
000075d5269cf881  vmovaps xmm2, [rsp+0xD0]
000075d5269cf88a  vmovaps [rsp+0xD0], xmm14
000075d5269cf893  movaps xmm1, xmm15
000075d5269cf897  addpd xmm1, xmm2
000075d5269cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000075d5269cf8a0  ptest xmm14, xmm14
000075d5269cf8a6  jnz 0x000075D5269D147A
000075d5269cf8ac  vmovaps xmm15, [rsp+0x100]
000075d5269cf8b5  vpermilpd xmm15, xmm15, 0x00
000075d5269cf8bb  vmovaps xmm2, [rsp+0xF0]
000075d5269cf8c4  vmovaps [rsp+0xF0], xmm1
000075d5269cf8cd  movaps xmm14, xmm2
000075d5269cf8d1  mulpd xmm14, xmm15
000075d5269cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000075d5269cf8dc  ptest xmm1, xmm1
000075d5269cf8e1  jnz 0x000075D5269D15BB
000075d5269cf8e7  vmovaps xmm1, [rsp+0xA0]
000075d5269cf8f0  vpermilpd xmm1, xmm1, 0x00
000075d5269cf8f6  vmovaps xmm2, [rsp+0xE0]
000075d5269cf8ff  vmovaps [rsp+0xE0], xmm14
000075d5269cf908  movaps xmm15, xmm2
000075d5269cf90c  mulpd xmm15, xmm1
000075d5269cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000075d5269cf917  ptest xmm14, xmm14
000075d5269cf91d  jnz 0x000075D5269D16FE
000075d5269cf923  lea rax, [r14+0xE0]
000075d5269cf92a  movups xmm1, [r13+rax*1]
000075d5269cf930  vmovaps xmm14, [rsp+0x100]
000075d5269cf939  vpermilpd xmm14, xmm14, 0x00
000075d5269cf93f  vmovaps [rsp+0x100], xmm1
000075d5269cf948  vmovaps xmm1, [rsp+0x30]
000075d5269cf94e  vmovaps [rsp+0x30], xmm15
000075d5269cf954  movaps xmm2, xmm1
000075d5269cf957  mulpd xmm2, xmm14
000075d5269cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000075d5269cf961  ptest xmm15, xmm15
000075d5269cf967  jnz 0x000075D5269D184A
000075d5269cf96d  vmovaps [rsp+0x120], xmm10
000075d5269cf976  vmovaps xmm1, [rsp+0x120]
000075d5269cf97f  por xmm10, xmm1
000075d5269cf984  movaps [r15+0x300], xmm10
000075d5269cf98c  vmovaps [rsp+0x120], xmm8
000075d5269cf995  vmovaps xmm1, [rsp+0x120]
000075d5269cf99e  por xmm8, xmm1
000075d5269cf9a3  movaps [r15+0x190], xmm8
000075d5269cf9ab  vmovaps xmm1, [rsp+0xA0]
000075d5269cf9b4  vpermilpd xmm1, xmm1, 0x00
000075d5269cf9ba  vmovaps xmm14, [rsp+0x100]
000075d5269cf9c3  vmovaps [rsp+0x100], xmm13
000075d5269cf9cc  movaps xmm15, xmm14
000075d5269cf9d0  mulpd xmm15, xmm1
000075d5269cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000075d5269cf9db  ptest xmm13, xmm13
000075d5269cf9e1  jnz 0x000075D5269D198B
000075d5269cf9e7  lea rax, [r14+0x90]
000075d5269cf9ee  movups xmm1, [r13+rax*1]
000075d5269cf9f4  vmovaps [rsp+0x120], xmm4
000075d5269cf9fd  vmovaps xmm14, [rsp+0x120]
000075d5269cfa06  por xmm4, xmm14
000075d5269cfa0b  movaps [r15+0x1C0], xmm4
000075d5269cfa13  vmovaps [rsp+0x120], xmm11
000075d5269cfa1c  vmovaps xmm14, [rsp+0x120]
000075d5269cfa25  por xmm11, xmm14
000075d5269cfa2a  movaps [r15+0x200], xmm11
000075d5269cfa32  vmovaps [rsp+0x120], xmm5
000075d5269cfa3b  vmovaps xmm14, [rsp+0x120]
000075d5269cfa44  por xmm5, xmm14
000075d5269cfa49  movaps [r15+0x2D0], xmm5
000075d5269cfa51  vmovaps [rsp+0x120], xmm12
000075d5269cfa5a  vmovaps xmm14, [rsp+0x120]
000075d5269cfa63  por xmm12, xmm14
000075d5269cfa68  movaps [r15+0x2E0], xmm12
000075d5269cfa70  vmovaps xmm13, [rsp+0x110]
000075d5269cfa79  vmovaps [rsp+0x110], xmm1
000075d5269cfa82  vmovaps xmm1, [rsp+0xE0]
000075d5269cfa8b  vmovaps [rsp+0xE0], xmm15
000075d5269cfa94  movaps xmm14, xmm13
000075d5269cfa98  addpd xmm14, xmm1
000075d5269cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000075d5269cfaa3  ptest xmm15, xmm15
000075d5269cfaa9  jnz 0x000075D5269D1AD8
000075d5269cfaaf  vmovaps xmm1, [rsp+0xA0]
000075d5269cfab8  vpermilpd xmm1, xmm1, 0x00
000075d5269cfabe  vmovaps xmm13, [rsp+0x110]
000075d5269cfac7  vmovaps [rsp+0x110], xmm14
000075d5269cfad0  movaps xmm15, xmm13
000075d5269cfad4  mulpd xmm15, xmm1
000075d5269cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000075d5269cfadf  ptest xmm14, xmm14
000075d5269cfae5  jnz 0x000075D5269D1C1B
000075d5269cfaeb  lea rax, [r14+0x80]
000075d5269cfaf2  movups xmm1, [r13+rax*1]
000075d5269cfaf8  vmovaps xmm13, [rsp+0xC0]
000075d5269cfb01  vmovaps [rsp+0xC0], xmm1
000075d5269cfb0a  movaps xmm14, xmm13
000075d5269cfb0e  addpd xmm14, xmm2
000075d5269cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000075d5269cfb19  ptest xmm1, xmm1
000075d5269cfb1e  jnz 0x000075D5269D1D68
000075d5269cfb24  vmovaps xmm13, [rsp+0x100]
000075d5269cfb2d  vmovaps xmm2, [rsp+0x30]
000075d5269cfb33  vmovaps [rsp+0x30], xmm15
000075d5269cfb39  movaps xmm1, xmm13
000075d5269cfb3d  addpd xmm1, xmm2
000075d5269cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000075d5269cfb46  ptest xmm15, xmm15
000075d5269cfb4c  jnz 0x000075D5269D1EAB
000075d5269cfb52  vmovaps xmm15, [rsp+0x20]
000075d5269cfb58  vmovaps xmm13, [rsp+0x20]
000075d5269cfb5e  por xmm15, xmm13
000075d5269cfb63  movaps [r15+0x2F0], xmm15
000075d5269cfb6b  vmovaps xmm13, [rsp+0xA0]
000075d5269cfb74  vpermilpd xmm13, xmm13, 0x00
000075d5269cfb7a  vmovaps [rsp+0x20], xmm1
000075d5269cfb80  vmovaps xmm1, [rsp+0xC0]
000075d5269cfb89  vmovaps [rsp+0xA0], xmm15
000075d5269cfb92  movaps xmm2, xmm1
000075d5269cfb95  mulpd xmm2, xmm13
000075d5269cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000075d5269cfb9f  ptest xmm15, xmm15
000075d5269cfba5  jnz 0x000075D5269D1FEC
000075d5269cfbab  lea rax, [r14+0xD0]
000075d5269cfbb2  movups xmm1, [r13+rax*1]
000075d5269cfbb8  vmovaps xmm13, [rsp+0xF0]
000075d5269cfbc1  vmovaps [rsp+0xC0], xmm1
000075d5269cfbca  vmovaps xmm1, [rsp+0xE0]
000075d5269cfbd3  vmovaps [rsp+0xE0], xmm14
000075d5269cfbdc  movaps xmm15, xmm13
000075d5269cfbe0  addpd xmm15, xmm1
000075d5269cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000075d5269cfbeb  ptest xmm14, xmm14
000075d5269cfbf1  jnz 0x000075D5269D2137
000075d5269cfbf7  vmovaps xmm1, [rsp+0xB0]
000075d5269cfc00  vpermilpd xmm1, xmm1, 0x00
000075d5269cfc06  movaps xmm14, xmm11
000075d5269cfc0a  mulpd xmm14, xmm1
000075d5269cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000075d5269cfc15  ptest xmm13, xmm13
000075d5269cfc1b  jnz 0x000075D5269D227A
000075d5269cfc21  movaps [r15+0x260], xmm14
000075d5269cfc29  vxorps xmm1, xmm1, xmm1
000075d5269cfc2d  vpbroadcastq xmm1, xmm1
000075d5269cfc32  movaps [r15+0x1B0], xmm1
000075d5269cfc3a  vmovaps xmm1, [rsp+0xB0]
000075d5269cfc43  vpermilpd xmm1, xmm1, 0x00
000075d5269cfc49  vmovaps xmm11, [rsp+0xC0]
000075d5269cfc52  vmovaps [rsp+0xC0], xmm15
000075d5269cfc5b  movaps xmm13, xmm11
000075d5269cfc5f  mulpd xmm13, xmm1
000075d5269cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000075d5269cfc6a  ptest xmm15, xmm15
000075d5269cfc70  jnz 0x000075D5269D23BD
000075d5269cfc76  lea rax, [r14+0xC0]
000075d5269cfc7d  movups xmm1, [r13+rax*1]
000075d5269cfc83  vmovaps xmm11, [rsp+0x110]
000075d5269cfc8c  vmovaps [rsp+0xF0], xmm1
000075d5269cfc95  vmovaps xmm1, [rsp+0x30]
000075d5269cfc9b  vmovaps [rsp+0x30], xmm14
000075d5269cfca1  movaps xmm15, xmm11
000075d5269cfca5  addpd xmm15, xmm1
000075d5269cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000075d5269cfcb0  ptest xmm14, xmm14
000075d5269cfcb6  jnz 0x000075D5269D250A
000075d5269cfcbc  vmovaps [rsp+0x100], xmm9
000075d5269cfcc5  vmovaps xmm1, [rsp+0x100]
000075d5269cfcce  por xmm9, xmm1
000075d5269cfcd3  movaps [r15+0x270], xmm9
000075d5269cfcdb  vmovaps [rsp+0x100], xmm6
000075d5269cfce4  vmovaps xmm1, [rsp+0x100]
000075d5269cfced  por xmm6, xmm1
000075d5269cfcf1  movaps [r15+0x1A0], xmm6
000075d5269cfcf9  vmovaps xmm14, [rsp+0xB0]
000075d5269cfd02  vpermilpd xmm14, xmm14, 0x00
000075d5269cfd08  vmovaps xmm6, [rsp+0xF0]
000075d5269cfd11  vmovaps [rsp+0xF0], xmm1
000075d5269cfd1a  movaps xmm11, xmm6
000075d5269cfd1e  mulpd xmm11, xmm14
000075d5269cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000075d5269cfd29  ptest xmm1, xmm1
000075d5269cfd2e  jnz 0x000075D5269D264D
000075d5269cfd34  lea rax, [r14+0x20]
000075d5269cfd38  movups xmm1, [r13+rax*1]
000075d5269cfd3e  movaps [r15+0x110], xmm1
000075d5269cfd46  vmovaps xmm6, [rsp+0xE0]
000075d5269cfd4f  vmovaps [rsp+0xE0], xmm1
000075d5269cfd58  movaps xmm14, xmm6
000075d5269cfd5c  addpd xmm14, xmm2
000075d5269cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000075d5269cfd67  ptest xmm1, xmm1
000075d5269cfd6c  jnz 0x000075D5269D279A
000075d5269cfd72  vmovaps xmm1, [rsp+0xB0]
000075d5269cfd7b  vpermilpd xmm1, xmm1, 0x00
000075d5269cfd81  movaps xmm6, xmm5
000075d5269cfd84  mulpd xmm6, xmm1
000075d5269cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000075d5269cfd8d  ptest xmm2, xmm2
000075d5269cfd92  jnz 0x000075D5269D28DC
000075d5269cfd98  vmovaps xmm5, [rsp+0x20]
000075d5269cfd9e  movaps xmm1, xmm5
000075d5269cfda1  addpd xmm1, xmm13
000075d5269cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000075d5269cfdab  ptest xmm2, xmm2
000075d5269cfdb0  jnz 0x000075D5269D2A1C
000075d5269cfdb6  vmovaps xmm13, [rsp+0x80]
000075d5269cfdbf  vpermilpd xmm13, xmm13, 0x00
000075d5269cfdc5  vmovaps xmm2, [rsp+0xE0]
000075d5269cfdce  vmovaps [rsp+0x20], xmm1
000075d5269cfdd4  movaps xmm5, xmm2
000075d5269cfdd7  mulpd xmm5, xmm13
000075d5269cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000075d5269cfde1  ptest xmm1, xmm1
000075d5269cfde6  jnz 0x000075D5269D2B5D
000075d5269cfdec  vmovaps xmm1, [rsp+0x80]
000075d5269cfdf5  vpermilpd xmm1, xmm1, 0x00
000075d5269cfdfb  movaps xmm13, xmm10
000075d5269cfdff  mulpd xmm13, xmm1
000075d5269cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000075d5269cfe0a  ptest xmm2, xmm2
000075d5269cfe0f  jnz 0x000075D5269D2C9E
000075d5269cfe15  vmovaps xmm10, [rsp+0x30]
000075d5269cfe1b  movaps xmm1, xmm15
000075d5269cfe1f  addpd xmm1, xmm10
000075d5269cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000075d5269cfe29  ptest xmm2, xmm2
000075d5269cfe2e  jnz 0x000075D5269D2DE1
000075d5269cfe34  vmovaps xmm10, [rsp+0xC0]
000075d5269cfe3d  movaps xmm15, xmm10
000075d5269cfe41  addpd xmm15, xmm11
000075d5269cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000075d5269cfe4c  ptest xmm2, xmm2
000075d5269cfe51  jnz 0x000075D5269D2F23
000075d5269cfe57  vmovaps xmm11, [rsp+0x80]
000075d5269cfe60  vpermilpd xmm11, xmm11, 0x00
000075d5269cfe66  movaps xmm10, xmm12
000075d5269cfe6a  mulpd xmm10, xmm11
000075d5269cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000075d5269cfe75  ptest xmm2, xmm2
000075d5269cfe7a  jnz 0x000075D5269D3067
000075d5269cfe80  vmovaps xmm12, [rsp+0x80]
000075d5269cfe89  vpermilpd xmm12, xmm12, 0x00
000075d5269cfe8f  vmovaps xmm2, [rsp+0xA0]
000075d5269cfe98  vmovaps [rsp+0x30], xmm1
000075d5269cfe9e  movaps xmm11, xmm2
000075d5269cfea2  mulpd xmm11, xmm12
000075d5269cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000075d5269cfead  ptest xmm1, xmm1
000075d5269cfeb2  jnz 0x000075D5269D31AB
000075d5269cfeb8  movaps xmm1, xmm14
000075d5269cfebc  addpd xmm1, xmm6
000075d5269cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000075d5269cfec5  ptest xmm12, xmm12
000075d5269cfecb  jnz 0x000075D5269D32EE
000075d5269cfed1  vmovaps xmm12, [rsp+0x20]
000075d5269cfed7  movaps xmm14, xmm12
000075d5269cfedb  addpd xmm14, xmm5
000075d5269cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000075d5269cfee6  ptest xmm6, xmm6
000075d5269cfeeb  jnz 0x000075D5269D342F
000075d5269cfef1  vmovaps xmm12, [rsp+0x90]
000075d5269cfefa  vpermilpd xmm12, xmm12, 0x00
000075d5269cff00  movaps xmm6, xmm9
000075d5269cff04  mulpd xmm6, xmm12
000075d5269cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000075d5269cff0e  ptest xmm5, xmm5
000075d5269cff13  jnz 0x000075D5269D3572
000075d5269cff19  movaps xmm12, xmm15
000075d5269cff1d  addpd xmm12, xmm13
000075d5269cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000075d5269cff28  ptest xmm9, xmm9
000075d5269cff2e  jnz 0x000075D5269D36B4
000075d5269cff34  vmovaps xmm13, [rsp+0x30]
000075d5269cff3a  movaps xmm15, xmm13
000075d5269cff3e  addpd xmm15, xmm10
000075d5269cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000075d5269cff49  ptest xmm9, xmm9
000075d5269cff4f  jnz 0x000075D5269D37F8
000075d5269cff55  vmovaps xmm13, [rsp+0xD0]
000075d5269cff5e  vmovaps xmm10, [rsp+0xD0]
000075d5269cff67  por xmm13, xmm10
000075d5269cff6c  movaps [r15+0x250], xmm13
000075d5269cff74  vmovaps [rsp+0x20], xmm7
000075d5269cff7a  vmovaps xmm13, [rsp+0x20]
000075d5269cff80  por xmm7, xmm13
000075d5269cff85  movaps [r15+0x2A0], xmm7
000075d5269cff8d  vmovaps [rsp+0x20], xmm3
000075d5269cff93  vmovaps xmm13, [rsp+0x20]
000075d5269cff99  por xmm3, xmm13
000075d5269cff9e  movaps [r15+0x1D0], xmm3
000075d5269cffa6  lea rax, [r14+0x40]
000075d5269cffaa  movups xmm13, [r13+rax*1]
000075d5269cffb0  movaps [r15+0x2C0], xmm13
000075d5269cffb8  vmovaps xmm10, [rsp+0x90]
000075d5269cffc1  vpermilpd xmm10, xmm10, 0x00
000075d5269cffc7  movaps xmm9, xmm8
000075d5269cffcb  mulpd xmm9, xmm10
000075d5269cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000075d5269cffd6  ptest xmm5, xmm5
000075d5269cffdb  jnz 0x000075D5269D3946
000075d5269cffe1  movaps xmm10, xmm1
000075d5269cffe5  addpd xmm10, xmm11
000075d5269cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000075d5269cfff0  ptest xmm8, xmm8
000075d5269cfff6  jnz 0x000075D5269D3A8A
000075d5269cfffc  movaps xmm1, xmm14
000075d5269d0000  addpd xmm1, xmm6
000075d5269d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000075d5269d0009  ptest xmm11, xmm11
000075d5269d000f  jnz 0x000075D5269D3BCD
000075d5269d0015  vmovaps xmm14, [rsp+0x90]
000075d5269d001e  vpermilpd xmm14, xmm14, 0x00
000075d5269d0024  movaps xmm11, xmm13
000075d5269d0028  mulpd xmm11, xmm14
000075d5269d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000075d5269d0033  ptest xmm8, xmm8
000075d5269d0039  jnz 0x000075D5269D3D0E
000075d5269d003f  vmovaps xmm14, [rsp+0x90]
000075d5269d0048  vpermilpd xmm14, xmm14, 0x00
000075d5269d004e  vmovaps xmm8, [rsp+0x10]
000075d5269d0054  movaps xmm13, xmm8
000075d5269d0058  mulpd xmm13, xmm14
000075d5269d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000075d5269d0063  ptest xmm6, xmm6
000075d5269d0068  jnz 0x000075D5269D3E52
000075d5269d006e  vmovaps xmm14, [rsp+0x60]
000075d5269d0074  vpermilpd xmm14, xmm14, 0x00
000075d5269d007a  movaps xmm8, xmm7
000075d5269d007e  mulpd xmm8, xmm14
000075d5269d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000075d5269d0089  ptest xmm6, xmm6
000075d5269d008e  jnz 0x000075D5269D3F96
000075d5269d0094  movaps xmm14, xmm12
000075d5269d0098  addpd xmm14, xmm9
000075d5269d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000075d5269d00a3  ptest xmm7, xmm7
000075d5269d00a8  jnz 0x000075D5269D40D9
000075d5269d00ae  vmovaps xmm12, [rsp+0x60]
000075d5269d00b4  vpermilpd xmm12, xmm12, 0x00
000075d5269d00ba  vmovaps xmm7, [rsp+0xF0]
000075d5269d00c3  movaps xmm9, xmm7
000075d5269d00c7  mulpd xmm9, xmm12
000075d5269d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000075d5269d00d2  ptest xmm6, xmm6
000075d5269d00d7  jnz 0x000075D5269D421D
000075d5269d00dd  movaps xmm12, xmm15
000075d5269d00e1  addpd xmm12, xmm11
000075d5269d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000075d5269d00ec  ptest xmm7, xmm7
000075d5269d00f1  jnz 0x000075D5269D4360
000075d5269d00f7  vmovaps xmm15, [rsp+0x60]
000075d5269d00fd  vpermilpd xmm15, xmm15, 0x00
000075d5269d0103  vmovaps xmm7, [rsp+0x40]
000075d5269d0109  movaps xmm11, xmm7
000075d5269d010d  mulpd xmm11, xmm15
000075d5269d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000075d5269d0118  ptest xmm6, xmm6
000075d5269d011d  jnz 0x000075D5269D44A4
000075d5269d0123  movaps xmm15, xmm10
000075d5269d0127  addpd xmm15, xmm13
000075d5269d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000075d5269d0132  ptest xmm7, xmm7
000075d5269d0137  jnz 0x000075D5269D45E7
000075d5269d013d  vmovaps xmm13, [rsp+0x60]
000075d5269d0143  vpermilpd xmm13, xmm13, 0x00
000075d5269d0149  vmovaps xmm7, [rsp+0x50]
000075d5269d014f  movaps xmm10, xmm7
000075d5269d0153  mulpd xmm10, xmm13
000075d5269d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000075d5269d015e  ptest xmm6, xmm6
000075d5269d0163  jnz 0x000075D5269D472B
000075d5269d0169  movaps xmm13, xmm1
000075d5269d016d  addpd xmm13, xmm8
000075d5269d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000075d5269d0178  ptest xmm7, xmm7
000075d5269d017d  jnz 0x000075D5269D486E
000075d5269d0183  lea rax, [r14+0x70]
000075d5269d0187  movups xmm1, [r13+rax*1]
000075d5269d018d  movaps [r15+0x240], xmm1
000075d5269d0195  movaps xmm8, xmm14
000075d5269d0199  addpd xmm8, xmm9
000075d5269d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000075d5269d01a4  ptest xmm7, xmm7
000075d5269d01a9  jnz 0x000075D5269D49BB
000075d5269d01af  movaps [r15+0x170], xmm8
000075d5269d01b7  vmovaps xmm14, [rsp+0x70]
000075d5269d01bd  vpermilpd xmm14, xmm14, 0x00
000075d5269d01c3  movaps xmm9, xmm1
000075d5269d01c7  mulpd xmm9, xmm14
000075d5269d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000075d5269d01d2  ptest xmm7, xmm7
000075d5269d01d7  jnz 0x000075D5269D4AFF
000075d5269d01dd  vmovaps xmm1, [rsp+0x70]
000075d5269d01e3  vpermilpd xmm1, xmm1, 0x00
000075d5269d01e9  movaps xmm14, xmm4
000075d5269d01ed  mulpd xmm14, xmm1
000075d5269d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000075d5269d01f8  ptest xmm7, xmm7
000075d5269d01fd  jnz 0x000075D5269D4C42
000075d5269d0203  movaps [r15+0x180], xmm14
000075d5269d020b  movaps xmm1, xmm12
000075d5269d020f  addpd xmm1, xmm11
000075d5269d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000075d5269d0219  ptest xmm7, xmm7
000075d5269d021e  jnz 0x000075D5269D4D84
000075d5269d0224  movaps [r15+0x210], xmm1
000075d5269d022c  movups xmm12, [r13+r14*1]
000075d5269d0232  lea rax, [r14+0x10]
000075d5269d0236  movups xmm11, [r13+rax*1]
000075d5269d023c  movaps [r15+0x230], xmm11
000075d5269d0244  movaps xmm7, xmm15
000075d5269d0248  addpd xmm7, xmm10
000075d5269d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000075d5269d0252  ptest xmm6, xmm6
000075d5269d0257  jnz 0x000075D5269D4EDA
000075d5269d025d  movaps [r15+0x130], xmm7
000075d5269d0265  vmovaps xmm15, [rsp+0x70]
000075d5269d026b  vpermilpd xmm15, xmm15, 0x00
000075d5269d0271  movaps xmm10, xmm11
000075d5269d0275  mulpd xmm10, xmm15
000075d5269d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000075d5269d0280  ptest xmm6, xmm6
000075d5269d0285  jnz 0x000075D5269D501C
000075d5269d028b  movaps [r15+0x220], xmm10
000075d5269d0293  vmovaps xmm15, [rsp+0x70]
000075d5269d0299  vpermilpd xmm15, xmm15, 0x00
000075d5269d029f  movaps xmm11, xmm12
000075d5269d02a3  mulpd xmm11, xmm15
000075d5269d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000075d5269d02ae  ptest xmm6, xmm6
000075d5269d02b3  jnz 0x000075D5269D5160
000075d5269d02b9  movaps xmm15, xmm13
000075d5269d02bd  addpd xmm15, xmm9
000075d5269d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000075d5269d02c8  ptest xmm12, xmm12
000075d5269d02ce  jnz 0x000075D5269D52A4
000075d5269d02d4  movaps [r15+0x140], xmm15
000075d5269d02dc  movaps xmm13, xmm8
000075d5269d02e0  addpd xmm13, xmm14
000075d5269d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000075d5269d02eb  ptest xmm12, xmm12
000075d5269d02f1  jnz 0x000075D5269D53E8
000075d5269d02f7  movaps [r15+0x150], xmm13
000075d5269d02ff  movaps xmm14, xmm1
000075d5269d0303  addpd xmm14, xmm10
000075d5269d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000075d5269d030e  ptest xmm12, xmm12
000075d5269d0314  jnz 0x000075D5269D552C
000075d5269d031a  movaps [r15+0x160], xmm14
000075d5269d0322  movaps xmm1, xmm7
000075d5269d0325  addpd xmm1, xmm11
000075d5269d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000075d5269d032f  ptest xmm12, xmm12
000075d5269d0335  jnz 0x000075D5269D566F
000075d5269d033b  movaps [r15+0x120], xmm1
000075d5269d0343  mov eax, 0x430920
000075d5269d0348  movups [r13+rax*1], xmm15
000075d5269d034e  mov eax, 0x430930
000075d5269d0353  movups [r13+rax*1], xmm13
000075d5269d0359  mov eax, 0x430940
000075d5269d035e  movups [r13+rax*1], xmm14
000075d5269d0364  mov eax, 0x430950
000075d5269d0369  movups [r13+rax*1], xmm1
000075d5269d036f  mov eax, [r15+0x108]
000075d5269d0376  sahf
000075d5269d0377  jnz 0x000075D5269D03A9
000075d5269d0379  cmp dword ptr [r15+0x318], 0x00
000075d5269d0381  jz 0x000075D5269DB900
000075d5269d0387  nop [rax+rax*1], ax
000075d5269d0390  nop [rax+rax*1], eax
000075d5269d0398  mov eax, 0x410444
000075d5269d039d  mov [r15+0x100], rax
000075d5269d03a4  jmp 0x000075D5267FE110
000075d5269d03a9  cmp dword ptr [r15+0x318], 0x00
000075d5269d03b1  jz 0x000075D5269D57E0
000075d5269d03b7  nop [rax+rax*1], ax
000075d5269d03c0  nop [rax+rax*1], eax
000075d5269d03c8  mov eax, 0x410278
000075d5269d03cd  mov [r15+0x100], rax
000075d5269d03d4  jmp 0x000075D5267FE110
000075d5269d03d9  int3
000075d5269d03da  call 0x000075D5268B52F0
000075d5269d03df  jmp 0x000075D5269CF016
000075d5269d03e4  call 0x000075D5268C4620
000075d5269d03e9  jmp 0x000075D5269CF023
000075d5269d03ee  call 0x000075D5268C33A0
000075d5269d03f3  jmp 0x000075D5269CF035
000075d5269d03f8  call 0x000075D5268C2120
000075d5269d03fd  jmp 0x000075D5269CF03F
000075d5269d0402  call 0x000075D5268C0860
000075d5269d0407  jmp 0x000075D5269CF067
000075d5269d040c  call 0x000075D5268BF5F0
000075d5269d0411  jmp 0x000075D5269CF073
000075d5269d0416  call 0x000075D5268C0860
000075d5269d041b  jmp 0x000075D5269CF0A5
000075d5269d0420  call 0x000075D5268BF5F0
000075d5269d0425  jmp 0x000075D5269CF0B1
000075d5269d042a  call 0x000075D5268C4740
000075d5269d042f  jmp 0x000075D5269CF0BE
000075d5269d0434  call 0x000075D5268B5400
000075d5269d0439  jmp 0x000075D5269CF0CB
000075d5269d043e  call 0x000075D5268B52F0
000075d5269d0443  jmp 0x000075D5269CF0D8
000075d5269d0448  call 0x000075D5268C4620
000075d5269d044d  jmp 0x000075D5269CF0E5
000075d5269d0452  call 0x000075D5268C0860
000075d5269d0457  jmp 0x000075D5269CF10D
000075d5269d045c  call 0x000075D5268BF5F0
000075d5269d0461  jmp 0x000075D5269CF119
000075d5269d0466  call 0x000075D526809D70
000075d5269d046b  jmp 0x000075D5269CF11F
000075d5269d0470  call 0x000075D5268BE9C0
000075d5269d0475  jmp 0x000075D5269CF129
000075d5269d047a  call 0x000075D5268C0860
000075d5269d047f  jmp 0x000075D5269CF151
000075d5269d0484  call 0x000075D5268BF5F0
000075d5269d0489  jmp 0x000075D5269CF15D
000075d5269d048e  call 0x000075D5268BD750
000075d5269d0493  jmp 0x000075D5269CF16A
000075d5269d0498  call 0x000075D5268BC4E0
000075d5269d049d  jmp 0x000075D5269CF177
000075d5269d04a2  call 0x000075D5268C4740
000075d5269d04a7  jmp 0x000075D5269CF184
000075d5269d04ac  call 0x000075D5268B5400
000075d5269d04b1  jmp 0x000075D5269CF191
000075d5269d04b6  call 0x000075D5268B52F0
000075d5269d04bb  jmp 0x000075D5269CF19E
000075d5269d04c0  call 0x000075D5268C4620
000075d5269d04c5  jmp 0x000075D5269CF1AB
000075d5269d04ca  call 0x000075D5268C0860
000075d5269d04cf  jmp 0x000075D5269CF1BE
000075d5269d04d4  call 0x000075D5268BB270
000075d5269d04d9  jmp 0x000075D5269CF1CB
000075d5269d04de  call 0x000075D5268BA000
000075d5269d04e3  jmp 0x000075D5269CF1D8
000075d5269d04e8  call 0x000075D5268B8D90
000075d5269d04ed  jmp 0x000075D5269CF1E5
000075d5269d04f2  call 0x000075D5268B8A20
000075d5269d04f7  jmp 0x000075D5269CF1F2
000075d5269d04fc  call 0x000075D5268B5400
000075d5269d0501  jmp 0x000075D5269CF1FC
000075d5269d0506  call 0x000075D5268C2240
000075d5269d050b  jmp 0x000075D5269CF206
000075d5269d0510  call 0x000075D5268B52F0
000075d5269d0515  jmp 0x000075D5269CF210
000075d5269d051a  call 0x000075D5268C2120
000075d5269d051f  jmp 0x000075D5269CF21A
000075d5269d0524  call 0x000075D5268B77B0
000075d5269d0529  jmp 0x000075D5269CF224
000075d5269d052e  call 0x000075D5268B6550
000075d5269d0533  jmp 0x000075D5269CF22E
000075d5269d0538  call 0x000075D5268BFD50
000075d5269d053d  jmp 0x000075D5269CF240
000075d5269d0542  call 0x000075D5268B8EA0
000075d5269d0547  jmp 0x000075D5269CF24A
000075d5269d054c  call 0x000075D5268BFC30
000075d5269d0551  jmp 0x000075D5269CF257
000075d5269d0556  call 0x000075D5268B8D90
000075d5269d055b  jmp 0x000075D5269CF264
000075d5269d0560  call 0x000075D5268C2240
000075d5269d0565  jmp 0x000075D5269CF271
000075d5269d056a  call 0x000075D5268B5400
000075d5269d056f  jmp 0x000075D5269CF27E
000075d5269d0574  call 0x000075D5268B52F0
000075d5269d0579  jmp 0x000075D5269CF28B
000075d5269d057e  call 0x000075D5268C2120
000075d5269d0583  jmp 0x000075D5269CF298
000075d5269d0588  call 0x000075D5268B52F0
000075d5269d058d  jmp 0x000075D5269CF2AB
000075d5269d0592  call 0x000075D5268B52F0
000075d5269d0597  jmp 0x000075D5269CF2BE
000075d5269d059c  call 0x000075D5268B52F0
000075d5269d05a1  jmp 0x000075D5269CF2D1
000075d5269d05a6  call 0x000075D5268B52F0
000075d5269d05ab  jmp 0x000075D5269CF2E4
000075d5269d05b0  call 0x000075D5268C2240
000075d5269d05b5  jmp 0x000075D5269CF2F9
000075d5269d05ba  call 0x000075D5268C2240
000075d5269d05bf  jmp 0x000075D5269CF30C
000075d5269d05c4  call 0x000075D5268C2120
000075d5269d05c9  jmp 0x000075D5269CF319
000075d5269d05ce  call 0x000075D5268B52F0
000075d5269d05d3  jmp 0x000075D5269CF32C
000075d5269d05d8  call 0x000075D5268B52F0
000075d5269d05dd  jmp 0x000075D5269CF34F
000075d5269d05e2  call 0x000075D5268B52F0
000075d5269d05e7  jmp 0x000075D5269CF362
000075d5269d05ec  call 0x000075D5267FF540
000075d5269d05f1  jmp 0x000075D5269CF380
000075d5269d05f6  call 0x000075D526808C20
000075d5269d05fb  jmp 0x000075D5269CF38A
000075d5269d0600  call 0x000075D5268D6600
000075d5269d0605  jmp 0x000075D5269CF396
000075d5269d060a  call 0x000075D5267FF540
000075d5269d060f  jmp 0x000075D5269CF3A6
000075d5269d0614  call 0x000075D5268C0370
000075d5269d0619  jmp 0x000075D5269CF3D4
000075d5269d061e  call 0x000075D5268BF100
000075d5269d0623  jmp 0x000075D5269CF3DD
000075d5269d0628  call 0x000075D5268C0370
000075d5269d062d  jmp 0x000075D5269CF43B
000075d5269d0632  call 0x000075D5268BF100
000075d5269d0637  jmp 0x000075D5269CF444
000075d5269d063c  call 0x000075D5268C0370
000075d5269d0641  jmp 0x000075D5269CF48B
000075d5269d0646  call 0x000075D5268BF100
000075d5269d064b  jmp 0x000075D5269CF494
000075d5269d0650  call 0x000075D52680B720
000075d5269d0655  jmp 0x000075D5269CF4D7
000075d5269d065a  call 0x000075D5268B47C0
000075d5269d065f  jmp 0x000075D5269CF4EA
000075d5269d0664  call 0x000075D526808B00
000075d5269d0669  jmp 0x000075D5269CF501
000075d5269d066e  call 0x000075D5267FF430
000075d5269d0673  jmp 0x000075D5269CF514
000075d5269d0678  call 0x000075D5267FF430
000075d5269d067d  jmp 0x000075D5269CF527
000075d5269d0682  sub rsp, 0x08
000075d5269d0686  push rax
000075d5269d0687  push rcx
000075d5269d0688  push rdx
000075d5269d0689  push rdi
000075d5269d068a  push rsi
000075d5269d068b  push r8
000075d5269d068d  push r9
000075d5269d068f  push r10
000075d5269d0691  push r11
000075d5269d0693  sub rsp, 0xF0
000075d5269d069a  vmovaps [rsp], xmm0
000075d5269d069f  vmovaps [rsp+0x10], xmm2
000075d5269d06a5  vmovaps [rsp+0x20], xmm3
000075d5269d06ab  vmovaps [rsp+0x30], xmm4
000075d5269d06b1  vmovaps [rsp+0x40], xmm5
000075d5269d06b7  vmovaps [rsp+0x50], xmm6
000075d5269d06bd  vmovaps [rsp+0x60], xmm7
000075d5269d06c3  vmovaps [rsp+0x70], xmm8
000075d5269d06c9  vmovaps [rsp+0x80], xmm9
000075d5269d06d2  vmovaps [rsp+0x90], xmm10
000075d5269d06db  vmovaps [rsp+0xA0], xmm11
000075d5269d06e4  vmovaps [rsp+0xB0], xmm12
000075d5269d06ed  vmovaps [rsp+0xC0], xmm13
000075d5269d06f6  vmovaps [rsp+0xD0], xmm14
000075d5269d06ff  vmovaps [rsp+0xE0], xmm15
000075d5269d0708  sub rsp, 0x30
000075d5269d070c  movaps [rsp], xmm1
000075d5269d0710  movaps [rsp+0x10], xmm15
000075d5269d0716  movaps [rsp+0x20], xmm14
000075d5269d071c  lea rdi, [rsp]
000075d5269d0720  mov esi, 0x00
000075d5269d0725  mov rax, 0x601129E62530
000075d5269d072f  call rax
000075d5269d0731  movaps xmm1, [rsp]
000075d5269d0735  add rsp, 0x30
000075d5269d0739  vmovaps xmm0, [rsp]
000075d5269d073e  vmovaps xmm2, [rsp+0x10]
000075d5269d0744  vmovaps xmm3, [rsp+0x20]
000075d5269d074a  vmovaps xmm4, [rsp+0x30]
000075d5269d0750  vmovaps xmm5, [rsp+0x40]
000075d5269d0756  vmovaps xmm6, [rsp+0x50]
000075d5269d075c  vmovaps xmm7, [rsp+0x60]
000075d5269d0762  vmovaps xmm8, [rsp+0x70]
000075d5269d0768  vmovaps xmm9, [rsp+0x80]
000075d5269d0771  vmovaps xmm10, [rsp+0x90]
000075d5269d077a  vmovaps xmm11, [rsp+0xA0]
000075d5269d0783  vmovaps xmm12, [rsp+0xB0]
000075d5269d078c  vmovaps xmm13, [rsp+0xC0]
000075d5269d0795  vmovaps xmm14, [rsp+0xD0]
000075d5269d079e  vmovaps xmm15, [rsp+0xE0]
000075d5269d07a7  add rsp, 0xF0
000075d5269d07ae  pop r11
000075d5269d07b0  pop r10
000075d5269d07b2  pop r9
000075d5269d07b4  pop r8
000075d5269d07b6  pop rsi
000075d5269d07b7  pop rdi
000075d5269d07b8  pop rdx
000075d5269d07b9  pop rcx
000075d5269d07ba  pop rax
000075d5269d07bb  add rsp, 0x08
000075d5269d07bf  jmp 0x000075D5269CF581
000075d5269d07c4  sub rsp, 0x08
000075d5269d07c8  push rax
000075d5269d07c9  push rcx
000075d5269d07ca  push rdx
000075d5269d07cb  push rdi
000075d5269d07cc  push rsi
000075d5269d07cd  push r8
000075d5269d07cf  push r9
000075d5269d07d1  push r10
000075d5269d07d3  push r11
000075d5269d07d5  sub rsp, 0xF0
000075d5269d07dc  vmovaps [rsp], xmm0
000075d5269d07e1  vmovaps [rsp+0x10], xmm1
000075d5269d07e7  vmovaps [rsp+0x20], xmm2
000075d5269d07ed  vmovaps [rsp+0x30], xmm3
000075d5269d07f3  vmovaps [rsp+0x40], xmm4
000075d5269d07f9  vmovaps [rsp+0x50], xmm5
000075d5269d07ff  vmovaps [rsp+0x60], xmm6
000075d5269d0805  vmovaps [rsp+0x70], xmm7
000075d5269d080b  vmovaps [rsp+0x80], xmm8
000075d5269d0814  vmovaps [rsp+0x90], xmm9
000075d5269d081d  vmovaps [rsp+0xA0], xmm10
000075d5269d0826  vmovaps [rsp+0xB0], xmm11
000075d5269d082f  vmovaps [rsp+0xC0], xmm12
000075d5269d0838  vmovaps [rsp+0xD0], xmm14
000075d5269d0841  vmovaps [rsp+0xE0], xmm15
000075d5269d084a  sub rsp, 0x30
000075d5269d084e  movaps [rsp], xmm13
000075d5269d0853  movaps [rsp+0x10], xmm1
000075d5269d0858  movaps [rsp+0x20], xmm14
000075d5269d085e  lea rdi, [rsp]
000075d5269d0862  mov esi, 0x00
000075d5269d0867  mov rax, 0x601129E62530
000075d5269d0871  call rax
000075d5269d0873  movaps xmm13, [rsp]
000075d5269d0878  add rsp, 0x30
000075d5269d087c  vmovaps xmm0, [rsp]
000075d5269d0881  vmovaps xmm1, [rsp+0x10]
000075d5269d0887  vmovaps xmm2, [rsp+0x20]
000075d5269d088d  vmovaps xmm3, [rsp+0x30]
000075d5269d0893  vmovaps xmm4, [rsp+0x40]
000075d5269d0899  vmovaps xmm5, [rsp+0x50]
000075d5269d089f  vmovaps xmm6, [rsp+0x60]
000075d5269d08a5  vmovaps xmm7, [rsp+0x70]
000075d5269d08ab  vmovaps xmm8, [rsp+0x80]
000075d5269d08b4  vmovaps xmm9, [rsp+0x90]
000075d5269d08bd  vmovaps xmm10, [rsp+0xA0]
000075d5269d08c6  vmovaps xmm11, [rsp+0xB0]
000075d5269d08cf  vmovaps xmm12, [rsp+0xC0]
000075d5269d08d8  vmovaps xmm14, [rsp+0xD0]
000075d5269d08e1  vmovaps xmm15, [rsp+0xE0]
000075d5269d08ea  add rsp, 0xF0
000075d5269d08f1  pop r11
000075d5269d08f3  pop r10
000075d5269d08f5  pop r9
000075d5269d08f7  pop r8
000075d5269d08f9  pop rsi
000075d5269d08fa  pop rdi
000075d5269d08fb  pop rdx
000075d5269d08fc  pop rcx
000075d5269d08fd  pop rax
000075d5269d08fe  add rsp, 0x08
000075d5269d0902  jmp 0x000075D5269CF5CF
000075d5269d0907  sub rsp, 0x08
000075d5269d090b  push rax
000075d5269d090c  push rcx
000075d5269d090d  push rdx
000075d5269d090e  push rdi
000075d5269d090f  push rsi
000075d5269d0910  push r8
000075d5269d0912  push r9
000075d5269d0914  push r10
000075d5269d0916  push r11
000075d5269d0918  sub rsp, 0xF0
000075d5269d091f  vmovaps [rsp], xmm0
000075d5269d0924  vmovaps [rsp+0x10], xmm1
000075d5269d092a  vmovaps [rsp+0x20], xmm2
000075d5269d0930  vmovaps [rsp+0x30], xmm3
000075d5269d0936  vmovaps [rsp+0x40], xmm4
000075d5269d093c  vmovaps [rsp+0x50], xmm5
000075d5269d0942  vmovaps [rsp+0x60], xmm6
000075d5269d0948  vmovaps [rsp+0x70], xmm7
000075d5269d094e  vmovaps [rsp+0x80], xmm8
000075d5269d0957  vmovaps [rsp+0x90], xmm9
000075d5269d0960  vmovaps [rsp+0xA0], xmm10
000075d5269d0969  vmovaps [rsp+0xB0], xmm11
000075d5269d0972  vmovaps [rsp+0xC0], xmm12
000075d5269d097b  vmovaps [rsp+0xD0], xmm13
000075d5269d0984  vmovaps [rsp+0xE0], xmm14
000075d5269d098d  sub rsp, 0x30
000075d5269d0991  movaps [rsp], xmm15
000075d5269d0996  movaps [rsp+0x10], xmm14
000075d5269d099c  movaps [rsp+0x20], xmm1
000075d5269d09a1  lea rdi, [rsp]
000075d5269d09a5  mov esi, 0x00
000075d5269d09aa  mov rax, 0x601129E62530
000075d5269d09b4  call rax
000075d5269d09b6  movaps xmm15, [rsp]
000075d5269d09bb  add rsp, 0x30
000075d5269d09bf  vmovaps xmm0, [rsp]
000075d5269d09c4  vmovaps xmm1, [rsp+0x10]
000075d5269d09ca  vmovaps xmm2, [rsp+0x20]
000075d5269d09d0  vmovaps xmm3, [rsp+0x30]
000075d5269d09d6  vmovaps xmm4, [rsp+0x40]
000075d5269d09dc  vmovaps xmm5, [rsp+0x50]
000075d5269d09e2  vmovaps xmm6, [rsp+0x60]
000075d5269d09e8  vmovaps xmm7, [rsp+0x70]
000075d5269d09ee  vmovaps xmm8, [rsp+0x80]
000075d5269d09f7  vmovaps xmm9, [rsp+0x90]
000075d5269d0a00  vmovaps xmm10, [rsp+0xA0]
000075d5269d0a09  vmovaps xmm11, [rsp+0xB0]
000075d5269d0a12  vmovaps xmm12, [rsp+0xC0]
000075d5269d0a1b  vmovaps xmm13, [rsp+0xD0]
000075d5269d0a24  vmovaps xmm14, [rsp+0xE0]
000075d5269d0a2d  add rsp, 0xF0
000075d5269d0a34  pop r11
000075d5269d0a36  pop r10
000075d5269d0a38  pop r9
000075d5269d0a3a  pop r8
000075d5269d0a3c  pop rsi
000075d5269d0a3d  pop rdi
000075d5269d0a3e  pop rdx
000075d5269d0a3f  pop rcx
000075d5269d0a40  pop rax
000075d5269d0a41  add rsp, 0x08
000075d5269d0a45  jmp 0x000075D5269CF617
000075d5269d0a4a  sub rsp, 0x08
000075d5269d0a4e  push rax
000075d5269d0a4f  push rcx
000075d5269d0a50  push rdx
000075d5269d0a51  push rdi
000075d5269d0a52  push rsi
000075d5269d0a53  push r8
000075d5269d0a55  push r9
000075d5269d0a57  push r10
000075d5269d0a59  push r11
000075d5269d0a5b  sub rsp, 0xF0
000075d5269d0a62  vmovaps [rsp], xmm0
000075d5269d0a67  vmovaps [rsp+0x10], xmm2
000075d5269d0a6d  vmovaps [rsp+0x20], xmm3
000075d5269d0a73  vmovaps [rsp+0x30], xmm4
000075d5269d0a79  vmovaps [rsp+0x40], xmm5
000075d5269d0a7f  vmovaps [rsp+0x50], xmm6
000075d5269d0a85  vmovaps [rsp+0x60], xmm7
000075d5269d0a8b  vmovaps [rsp+0x70], xmm8
000075d5269d0a91  vmovaps [rsp+0x80], xmm9
000075d5269d0a9a  vmovaps [rsp+0x90], xmm10
000075d5269d0aa3  vmovaps [rsp+0xA0], xmm11
000075d5269d0aac  vmovaps [rsp+0xB0], xmm12
000075d5269d0ab5  vmovaps [rsp+0xC0], xmm13
000075d5269d0abe  vmovaps [rsp+0xD0], xmm14
000075d5269d0ac7  vmovaps [rsp+0xE0], xmm15
000075d5269d0ad0  sub rsp, 0x30
000075d5269d0ad4  movaps [rsp], xmm1
000075d5269d0ad8  movaps [rsp+0x10], xmm14
000075d5269d0ade  movaps [rsp+0x20], xmm10
000075d5269d0ae4  lea rdi, [rsp]
000075d5269d0ae8  mov esi, 0x00
000075d5269d0aed  mov rax, 0x601129E62530
000075d5269d0af7  call rax
000075d5269d0af9  movaps xmm1, [rsp]
000075d5269d0afd  add rsp, 0x30
000075d5269d0b01  vmovaps xmm0, [rsp]
000075d5269d0b06  vmovaps xmm2, [rsp+0x10]
000075d5269d0b0c  vmovaps xmm3, [rsp+0x20]
000075d5269d0b12  vmovaps xmm4, [rsp+0x30]
000075d5269d0b18  vmovaps xmm5, [rsp+0x40]
000075d5269d0b1e  vmovaps xmm6, [rsp+0x50]
000075d5269d0b24  vmovaps xmm7, [rsp+0x60]
000075d5269d0b2a  vmovaps xmm8, [rsp+0x70]
000075d5269d0b30  vmovaps xmm9, [rsp+0x80]
000075d5269d0b39  vmovaps xmm10, [rsp+0x90]
000075d5269d0b42  vmovaps xmm11, [rsp+0xA0]
000075d5269d0b4b  vmovaps xmm12, [rsp+0xB0]
000075d5269d0b54  vmovaps xmm13, [rsp+0xC0]
000075d5269d0b5d  vmovaps xmm14, [rsp+0xD0]
000075d5269d0b66  vmovaps xmm15, [rsp+0xE0]
000075d5269d0b6f  add rsp, 0xF0
000075d5269d0b76  pop r11
000075d5269d0b78  pop r10
000075d5269d0b7a  pop r9
000075d5269d0b7c  pop r8
000075d5269d0b7e  pop rsi
000075d5269d0b7f  pop rdi
000075d5269d0b80  pop rdx
000075d5269d0b81  pop rcx
000075d5269d0b82  pop rax
000075d5269d0b83  add rsp, 0x08
000075d5269d0b87  jmp 0x000075D5269CF631
000075d5269d0b8c  sub rsp, 0x08
000075d5269d0b90  push rax
000075d5269d0b91  push rcx
000075d5269d0b92  push rdx
000075d5269d0b93  push rdi
000075d5269d0b94  push rsi
000075d5269d0b95  push r8
000075d5269d0b97  push r9
000075d5269d0b99  push r10
000075d5269d0b9b  push r11
000075d5269d0b9d  sub rsp, 0xF0
000075d5269d0ba4  vmovaps [rsp], xmm0
000075d5269d0ba9  vmovaps [rsp+0x10], xmm1
000075d5269d0baf  vmovaps [rsp+0x20], xmm2
000075d5269d0bb5  vmovaps [rsp+0x30], xmm3
000075d5269d0bbb  vmovaps [rsp+0x40], xmm4
000075d5269d0bc1  vmovaps [rsp+0x50], xmm5
000075d5269d0bc7  vmovaps [rsp+0x60], xmm6
000075d5269d0bcd  vmovaps [rsp+0x70], xmm7
000075d5269d0bd3  vmovaps [rsp+0x80], xmm8
000075d5269d0bdc  vmovaps [rsp+0x90], xmm9
000075d5269d0be5  vmovaps [rsp+0xA0], xmm10
000075d5269d0bee  vmovaps [rsp+0xB0], xmm11
000075d5269d0bf7  vmovaps [rsp+0xC0], xmm12
000075d5269d0c00  vmovaps [rsp+0xD0], xmm14
000075d5269d0c09  vmovaps [rsp+0xE0], xmm15
000075d5269d0c12  sub rsp, 0x30
000075d5269d0c16  movaps [rsp], xmm13
000075d5269d0c1b  movaps [rsp+0x10], xmm14
000075d5269d0c21  movaps [rsp+0x20], xmm2
000075d5269d0c26  lea rdi, [rsp]
000075d5269d0c2a  mov esi, 0x00
000075d5269d0c2f  mov rax, 0x601129E62530
000075d5269d0c39  call rax
000075d5269d0c3b  movaps xmm13, [rsp]
000075d5269d0c40  add rsp, 0x30
000075d5269d0c44  vmovaps xmm0, [rsp]
000075d5269d0c49  vmovaps xmm1, [rsp+0x10]
000075d5269d0c4f  vmovaps xmm2, [rsp+0x20]
000075d5269d0c55  vmovaps xmm3, [rsp+0x30]
000075d5269d0c5b  vmovaps xmm4, [rsp+0x40]
000075d5269d0c61  vmovaps xmm5, [rsp+0x50]
000075d5269d0c67  vmovaps xmm6, [rsp+0x60]
000075d5269d0c6d  vmovaps xmm7, [rsp+0x70]
000075d5269d0c73  vmovaps xmm8, [rsp+0x80]
000075d5269d0c7c  vmovaps xmm9, [rsp+0x90]
000075d5269d0c85  vmovaps xmm10, [rsp+0xA0]
000075d5269d0c8e  vmovaps xmm11, [rsp+0xB0]
000075d5269d0c97  vmovaps xmm12, [rsp+0xC0]
000075d5269d0ca0  vmovaps xmm14, [rsp+0xD0]
000075d5269d0ca9  vmovaps xmm15, [rsp+0xE0]
000075d5269d0cb2  add rsp, 0xF0
000075d5269d0cb9  pop r11
000075d5269d0cbb  pop r10
000075d5269d0cbd  pop r9
000075d5269d0cbf  pop r8
000075d5269d0cc1  pop rsi
000075d5269d0cc2  pop rdi
000075d5269d0cc3  pop rdx
000075d5269d0cc4  pop rcx
000075d5269d0cc5  pop rax
000075d5269d0cc6  add rsp, 0x08
000075d5269d0cca  jmp 0x000075D5269CF64C
000075d5269d0ccf  sub rsp, 0x08
000075d5269d0cd3  push rax
000075d5269d0cd4  push rcx
000075d5269d0cd5  push rdx
000075d5269d0cd6  push rdi
000075d5269d0cd7  push rsi
000075d5269d0cd8  push r8
000075d5269d0cda  push r9
000075d5269d0cdc  push r10
000075d5269d0cde  push r11
000075d5269d0ce0  sub rsp, 0xF0
000075d5269d0ce7  vmovaps [rsp], xmm0
000075d5269d0cec  vmovaps [rsp+0x10], xmm2
000075d5269d0cf2  vmovaps [rsp+0x20], xmm3
000075d5269d0cf8  vmovaps [rsp+0x30], xmm4
000075d5269d0cfe  vmovaps [rsp+0x40], xmm5
000075d5269d0d04  vmovaps [rsp+0x50], xmm6
000075d5269d0d0a  vmovaps [rsp+0x60], xmm7
000075d5269d0d10  vmovaps [rsp+0x70], xmm8
000075d5269d0d16  vmovaps [rsp+0x80], xmm9
000075d5269d0d1f  vmovaps [rsp+0x90], xmm10
000075d5269d0d28  vmovaps [rsp+0xA0], xmm11
000075d5269d0d31  vmovaps [rsp+0xB0], xmm12
000075d5269d0d3a  vmovaps [rsp+0xC0], xmm13
000075d5269d0d43  vmovaps [rsp+0xD0], xmm14
000075d5269d0d4c  vmovaps [rsp+0xE0], xmm15
000075d5269d0d55  sub rsp, 0x30
000075d5269d0d59  movaps [rsp], xmm1
000075d5269d0d5d  movaps [rsp+0x10], xmm10
000075d5269d0d63  movaps [rsp+0x20], xmm2
000075d5269d0d68  lea rdi, [rsp]
000075d5269d0d6c  mov esi, 0x00
000075d5269d0d71  mov rax, 0x601129E62530
000075d5269d0d7b  call rax
000075d5269d0d7d  movaps xmm1, [rsp]
000075d5269d0d81  add rsp, 0x30
000075d5269d0d85  vmovaps xmm0, [rsp]
000075d5269d0d8a  vmovaps xmm2, [rsp+0x10]
000075d5269d0d90  vmovaps xmm3, [rsp+0x20]
000075d5269d0d96  vmovaps xmm4, [rsp+0x30]
000075d5269d0d9c  vmovaps xmm5, [rsp+0x40]
000075d5269d0da2  vmovaps xmm6, [rsp+0x50]
000075d5269d0da8  vmovaps xmm7, [rsp+0x60]
000075d5269d0dae  vmovaps xmm8, [rsp+0x70]
000075d5269d0db4  vmovaps xmm9, [rsp+0x80]
000075d5269d0dbd  vmovaps xmm10, [rsp+0x90]
000075d5269d0dc6  vmovaps xmm11, [rsp+0xA0]
000075d5269d0dcf  vmovaps xmm12, [rsp+0xB0]
000075d5269d0dd8  vmovaps xmm13, [rsp+0xC0]
000075d5269d0de1  vmovaps xmm14, [rsp+0xD0]
000075d5269d0dea  vmovaps xmm15, [rsp+0xE0]
000075d5269d0df3  add rsp, 0xF0
000075d5269d0dfa  pop r11
000075d5269d0dfc  pop r10
000075d5269d0dfe  pop r9
000075d5269d0e00  pop r8
000075d5269d0e02  pop rsi
000075d5269d0e03  pop rdi
000075d5269d0e04  pop rdx
000075d5269d0e05  pop rcx
000075d5269d0e06  pop rax
000075d5269d0e07  add rsp, 0x08
000075d5269d0e0b  jmp 0x000075D5269CF6B4
000075d5269d0e10  sub rsp, 0x08
000075d5269d0e14  push rax
000075d5269d0e15  push rcx
000075d5269d0e16  push rdx
000075d5269d0e17  push rdi
000075d5269d0e18  push rsi
000075d5269d0e19  push r8
000075d5269d0e1b  push r9
000075d5269d0e1d  push r10
000075d5269d0e1f  push r11
000075d5269d0e21  sub rsp, 0xF0
000075d5269d0e28  vmovaps [rsp], xmm0
000075d5269d0e2d  vmovaps [rsp+0x10], xmm1
000075d5269d0e33  vmovaps [rsp+0x20], xmm2
000075d5269d0e39  vmovaps [rsp+0x30], xmm3
000075d5269d0e3f  vmovaps [rsp+0x40], xmm4
000075d5269d0e45  vmovaps [rsp+0x50], xmm5
000075d5269d0e4b  vmovaps [rsp+0x60], xmm6
000075d5269d0e51  vmovaps [rsp+0x70], xmm7
000075d5269d0e57  vmovaps [rsp+0x80], xmm8
000075d5269d0e60  vmovaps [rsp+0x90], xmm9
000075d5269d0e69  vmovaps [rsp+0xA0], xmm10
000075d5269d0e72  vmovaps [rsp+0xB0], xmm11
000075d5269d0e7b  vmovaps [rsp+0xC0], xmm12
000075d5269d0e84  vmovaps [rsp+0xD0], xmm13
000075d5269d0e8d  vmovaps [rsp+0xE0], xmm14
000075d5269d0e96  sub rsp, 0x30
000075d5269d0e9a  movaps [rsp], xmm15
000075d5269d0e9f  movaps [rsp+0x10], xmm10
000075d5269d0ea5  movaps [rsp+0x20], xmm2
000075d5269d0eaa  lea rdi, [rsp]
000075d5269d0eae  mov esi, 0x00
000075d5269d0eb3  mov rax, 0x601129E62530
000075d5269d0ebd  call rax
000075d5269d0ebf  movaps xmm15, [rsp]
000075d5269d0ec4  add rsp, 0x30
000075d5269d0ec8  vmovaps xmm0, [rsp]
000075d5269d0ecd  vmovaps xmm1, [rsp+0x10]
000075d5269d0ed3  vmovaps xmm2, [rsp+0x20]
000075d5269d0ed9  vmovaps xmm3, [rsp+0x30]
000075d5269d0edf  vmovaps xmm4, [rsp+0x40]
000075d5269d0ee5  vmovaps xmm5, [rsp+0x50]
000075d5269d0eeb  vmovaps xmm6, [rsp+0x60]
000075d5269d0ef1  vmovaps xmm7, [rsp+0x70]
000075d5269d0ef7  vmovaps xmm8, [rsp+0x80]
000075d5269d0f00  vmovaps xmm9, [rsp+0x90]
000075d5269d0f09  vmovaps xmm10, [rsp+0xA0]
000075d5269d0f12  vmovaps xmm11, [rsp+0xB0]
000075d5269d0f1b  vmovaps xmm12, [rsp+0xC0]
000075d5269d0f24  vmovaps xmm13, [rsp+0xD0]
000075d5269d0f2d  vmovaps xmm14, [rsp+0xE0]
000075d5269d0f36  add rsp, 0xF0
000075d5269d0f3d  pop r11
000075d5269d0f3f  pop r10
000075d5269d0f41  pop r9
000075d5269d0f43  pop r8
000075d5269d0f45  pop rsi
000075d5269d0f46  pop rdi
000075d5269d0f47  pop rdx
000075d5269d0f48  pop rcx
000075d5269d0f49  pop rax
000075d5269d0f4a  add rsp, 0x08
000075d5269d0f4e  jmp 0x000075D5269CF706
000075d5269d0f53  sub rsp, 0x08
000075d5269d0f57  push rax
000075d5269d0f58  push rcx
000075d5269d0f59  push rdx
000075d5269d0f5a  push rdi
000075d5269d0f5b  push rsi
000075d5269d0f5c  push r8
000075d5269d0f5e  push r9
000075d5269d0f60  push r10
000075d5269d0f62  push r11
000075d5269d0f64  sub rsp, 0xF0
000075d5269d0f6b  vmovaps [rsp], xmm0
000075d5269d0f70  vmovaps [rsp+0x10], xmm2
000075d5269d0f76  vmovaps [rsp+0x20], xmm3
000075d5269d0f7c  vmovaps [rsp+0x30], xmm4
000075d5269d0f82  vmovaps [rsp+0x40], xmm5
000075d5269d0f88  vmovaps [rsp+0x50], xmm6
000075d5269d0f8e  vmovaps [rsp+0x60], xmm7
000075d5269d0f94  vmovaps [rsp+0x70], xmm8
000075d5269d0f9a  vmovaps [rsp+0x80], xmm9
000075d5269d0fa3  vmovaps [rsp+0x90], xmm10
000075d5269d0fac  vmovaps [rsp+0xA0], xmm11
000075d5269d0fb5  vmovaps [rsp+0xB0], xmm12
000075d5269d0fbe  vmovaps [rsp+0xC0], xmm13
000075d5269d0fc7  vmovaps [rsp+0xD0], xmm14
000075d5269d0fd0  vmovaps [rsp+0xE0], xmm15
000075d5269d0fd9  sub rsp, 0x30
000075d5269d0fdd  movaps [rsp], xmm1
000075d5269d0fe1  movaps [rsp+0x10], xmm10
000075d5269d0fe7  movaps [rsp+0x20], xmm12
000075d5269d0fed  lea rdi, [rsp]
000075d5269d0ff1  mov esi, 0x00
000075d5269d0ff6  mov rax, 0x601129E62530
000075d5269d1000  call rax
000075d5269d1002  movaps xmm1, [rsp]
000075d5269d1006  add rsp, 0x30
000075d5269d100a  vmovaps xmm0, [rsp]
000075d5269d100f  vmovaps xmm2, [rsp+0x10]
000075d5269d1015  vmovaps xmm3, [rsp+0x20]
000075d5269d101b  vmovaps xmm4, [rsp+0x30]
000075d5269d1021  vmovaps xmm5, [rsp+0x40]
000075d5269d1027  vmovaps xmm6, [rsp+0x50]
000075d5269d102d  vmovaps xmm7, [rsp+0x60]
000075d5269d1033  vmovaps xmm8, [rsp+0x70]
000075d5269d1039  vmovaps xmm9, [rsp+0x80]
000075d5269d1042  vmovaps xmm10, [rsp+0x90]
000075d5269d104b  vmovaps xmm11, [rsp+0xA0]
000075d5269d1054  vmovaps xmm12, [rsp+0xB0]
000075d5269d105d  vmovaps xmm13, [rsp+0xC0]
000075d5269d1066  vmovaps xmm14, [rsp+0xD0]
000075d5269d106f  vmovaps xmm15, [rsp+0xE0]
000075d5269d1078  add rsp, 0xF0
000075d5269d107f  pop r11
000075d5269d1081  pop r10
000075d5269d1083  pop r9
000075d5269d1085  pop r8
000075d5269d1087  pop rsi
000075d5269d1088  pop rdi
000075d5269d1089  pop rdx
000075d5269d108a  pop rcx
000075d5269d108b  pop rax
000075d5269d108c  add rsp, 0x08
000075d5269d1090  jmp 0x000075D5269CF732
000075d5269d1095  sub rsp, 0x08
000075d5269d1099  push rax
000075d5269d109a  push rcx
000075d5269d109b  push rdx
000075d5269d109c  push rdi
000075d5269d109d  push rsi
000075d5269d109e  push r8
000075d5269d10a0  push r9
000075d5269d10a2  push r10
000075d5269d10a4  push r11
000075d5269d10a6  sub rsp, 0xF0
000075d5269d10ad  vmovaps [rsp], xmm0
000075d5269d10b2  vmovaps [rsp+0x10], xmm1
000075d5269d10b8  vmovaps [rsp+0x20], xmm2
000075d5269d10be  vmovaps [rsp+0x30], xmm3
000075d5269d10c4  vmovaps [rsp+0x40], xmm4
000075d5269d10ca  vmovaps [rsp+0x50], xmm5
000075d5269d10d0  vmovaps [rsp+0x60], xmm6
000075d5269d10d6  vmovaps [rsp+0x70], xmm7
000075d5269d10dc  vmovaps [rsp+0x80], xmm8
000075d5269d10e5  vmovaps [rsp+0x90], xmm9
000075d5269d10ee  vmovaps [rsp+0xA0], xmm10
000075d5269d10f7  vmovaps [rsp+0xB0], xmm11
000075d5269d1100  vmovaps [rsp+0xC0], xmm12
000075d5269d1109  vmovaps [rsp+0xD0], xmm13
000075d5269d1112  vmovaps [rsp+0xE0], xmm14
000075d5269d111b  sub rsp, 0x30
000075d5269d111f  movaps [rsp], xmm15
000075d5269d1124  movaps [rsp+0x10], xmm10
000075d5269d112a  movaps [rsp+0x20], xmm12
000075d5269d1130  lea rdi, [rsp]
000075d5269d1134  mov esi, 0x00
000075d5269d1139  mov rax, 0x601129E62530
000075d5269d1143  call rax
000075d5269d1145  movaps xmm15, [rsp]
000075d5269d114a  add rsp, 0x30
000075d5269d114e  vmovaps xmm0, [rsp]
000075d5269d1153  vmovaps xmm1, [rsp+0x10]
000075d5269d1159  vmovaps xmm2, [rsp+0x20]
000075d5269d115f  vmovaps xmm3, [rsp+0x30]
000075d5269d1165  vmovaps xmm4, [rsp+0x40]
000075d5269d116b  vmovaps xmm5, [rsp+0x50]
000075d5269d1171  vmovaps xmm6, [rsp+0x60]
000075d5269d1177  vmovaps xmm7, [rsp+0x70]
000075d5269d117d  vmovaps xmm8, [rsp+0x80]
000075d5269d1186  vmovaps xmm9, [rsp+0x90]
000075d5269d118f  vmovaps xmm10, [rsp+0xA0]
000075d5269d1198  vmovaps xmm11, [rsp+0xB0]
000075d5269d11a1  vmovaps xmm12, [rsp+0xC0]
000075d5269d11aa  vmovaps xmm13, [rsp+0xD0]
000075d5269d11b3  vmovaps xmm14, [rsp+0xE0]
000075d5269d11bc  add rsp, 0xF0
000075d5269d11c3  pop r11
000075d5269d11c5  pop r10
000075d5269d11c7  pop r9
000075d5269d11c9  pop r8
000075d5269d11cb  pop rsi
000075d5269d11cc  pop rdi
000075d5269d11cd  pop rdx
000075d5269d11ce  pop rcx
000075d5269d11cf  pop rax
000075d5269d11d0  add rsp, 0x08
000075d5269d11d4  jmp 0x000075D5269CF75E
000075d5269d11d9  call 0x000075D5267FF430
000075d5269d11de  jmp 0x000075D5269CF7EE
000075d5269d11e3  call 0x000075D5267FF430
000075d5269d11e8  jmp 0x000075D5269CF801
000075d5269d11ed  sub rsp, 0x08
000075d5269d11f1  push rax
000075d5269d11f2  push rcx
000075d5269d11f3  push rdx
000075d5269d11f4  push rdi
000075d5269d11f5  push rsi
000075d5269d11f6  push r8
000075d5269d11f8  push r9
000075d5269d11fa  push r10
000075d5269d11fc  push r11
000075d5269d11fe  sub rsp, 0xF0
000075d5269d1205  vmovaps [rsp], xmm0
000075d5269d120a  vmovaps [rsp+0x10], xmm2
000075d5269d1210  vmovaps [rsp+0x20], xmm3
000075d5269d1216  vmovaps [rsp+0x30], xmm4
000075d5269d121c  vmovaps [rsp+0x40], xmm5
000075d5269d1222  vmovaps [rsp+0x50], xmm6
000075d5269d1228  vmovaps [rsp+0x60], xmm7
000075d5269d122e  vmovaps [rsp+0x70], xmm8
000075d5269d1234  vmovaps [rsp+0x80], xmm9
000075d5269d123d  vmovaps [rsp+0x90], xmm10
000075d5269d1246  vmovaps [rsp+0xA0], xmm11
000075d5269d124f  vmovaps [rsp+0xB0], xmm12
000075d5269d1258  vmovaps [rsp+0xC0], xmm13
000075d5269d1261  vmovaps [rsp+0xD0], xmm14
000075d5269d126a  vmovaps [rsp+0xE0], xmm15
000075d5269d1273  sub rsp, 0x30
000075d5269d1277  movaps [rsp], xmm1
000075d5269d127b  movaps [rsp+0x10], xmm13
000075d5269d1281  movaps [rsp+0x20], xmm2
000075d5269d1286  lea rdi, [rsp]
000075d5269d128a  mov esi, 0x00
000075d5269d128f  mov rax, 0x601129E62530
000075d5269d1299  call rax
000075d5269d129b  movaps xmm1, [rsp]
000075d5269d129f  add rsp, 0x30
000075d5269d12a3  vmovaps xmm0, [rsp]
000075d5269d12a8  vmovaps xmm2, [rsp+0x10]
000075d5269d12ae  vmovaps xmm3, [rsp+0x20]
000075d5269d12b4  vmovaps xmm4, [rsp+0x30]
000075d5269d12ba  vmovaps xmm5, [rsp+0x40]
000075d5269d12c0  vmovaps xmm6, [rsp+0x50]
000075d5269d12c6  vmovaps xmm7, [rsp+0x60]
000075d5269d12cc  vmovaps xmm8, [rsp+0x70]
000075d5269d12d2  vmovaps xmm9, [rsp+0x80]
000075d5269d12db  vmovaps xmm10, [rsp+0x90]
000075d5269d12e4  vmovaps xmm11, [rsp+0xA0]
000075d5269d12ed  vmovaps xmm12, [rsp+0xB0]
000075d5269d12f6  vmovaps xmm13, [rsp+0xC0]
000075d5269d12ff  vmovaps xmm14, [rsp+0xD0]
000075d5269d1308  vmovaps xmm15, [rsp+0xE0]
000075d5269d1311  add rsp, 0xF0
000075d5269d1318  pop r11
000075d5269d131a  pop r10
000075d5269d131c  pop r9
000075d5269d131e  pop r8
000075d5269d1320  pop rsi
000075d5269d1321  pop rdi
000075d5269d1322  pop rdx
000075d5269d1323  pop rcx
000075d5269d1324  pop rax
000075d5269d1325  add rsp, 0x08
000075d5269d1329  jmp 0x000075D5269CF82C
000075d5269d132e  call 0x000075D52680E760
000075d5269d1333  jmp 0x000075D5269CF839
000075d5269d1338  sub rsp, 0x08
000075d5269d133c  push rax
000075d5269d133d  push rcx
000075d5269d133e  push rdx
000075d5269d133f  push rdi
000075d5269d1340  push rsi
000075d5269d1341  push r8
000075d5269d1343  push r9
000075d5269d1345  push r10
000075d5269d1347  push r11
000075d5269d1349  sub rsp, 0xF0
000075d5269d1350  vmovaps [rsp], xmm0
000075d5269d1355  vmovaps [rsp+0x10], xmm1
000075d5269d135b  vmovaps [rsp+0x20], xmm2
000075d5269d1361  vmovaps [rsp+0x30], xmm3
000075d5269d1367  vmovaps [rsp+0x40], xmm4
000075d5269d136d  vmovaps [rsp+0x50], xmm5
000075d5269d1373  vmovaps [rsp+0x60], xmm6
000075d5269d1379  vmovaps [rsp+0x70], xmm7
000075d5269d137f  vmovaps [rsp+0x80], xmm8
000075d5269d1388  vmovaps [rsp+0x90], xmm9
000075d5269d1391  vmovaps [rsp+0xA0], xmm10
000075d5269d139a  vmovaps [rsp+0xB0], xmm11
000075d5269d13a3  vmovaps [rsp+0xC0], xmm12
000075d5269d13ac  vmovaps [rsp+0xD0], xmm14
000075d5269d13b5  vmovaps [rsp+0xE0], xmm15
000075d5269d13be  sub rsp, 0x30
000075d5269d13c2  movaps [rsp], xmm13
000075d5269d13c7  movaps [rsp+0x10], xmm2
000075d5269d13cc  movaps [rsp+0x20], xmm1
000075d5269d13d1  lea rdi, [rsp]
000075d5269d13d5  mov esi, 0x00
000075d5269d13da  mov rax, 0x601129E62530
000075d5269d13e4  call rax
000075d5269d13e6  movaps xmm13, [rsp]
000075d5269d13eb  add rsp, 0x30
000075d5269d13ef  vmovaps xmm0, [rsp]
000075d5269d13f4  vmovaps xmm1, [rsp+0x10]
000075d5269d13fa  vmovaps xmm2, [rsp+0x20]
000075d5269d1400  vmovaps xmm3, [rsp+0x30]
000075d5269d1406  vmovaps xmm4, [rsp+0x40]
000075d5269d140c  vmovaps xmm5, [rsp+0x50]
000075d5269d1412  vmovaps xmm6, [rsp+0x60]
000075d5269d1418  vmovaps xmm7, [rsp+0x70]
000075d5269d141e  vmovaps xmm8, [rsp+0x80]
000075d5269d1427  vmovaps xmm9, [rsp+0x90]
000075d5269d1430  vmovaps xmm10, [rsp+0xA0]
000075d5269d1439  vmovaps xmm11, [rsp+0xB0]
000075d5269d1442  vmovaps xmm12, [rsp+0xC0]
000075d5269d144b  vmovaps xmm14, [rsp+0xD0]
000075d5269d1454  vmovaps xmm15, [rsp+0xE0]
000075d5269d145d  add rsp, 0xF0
000075d5269d1464  pop r11
000075d5269d1466  pop r10
000075d5269d1468  pop r9
000075d5269d146a  pop r8
000075d5269d146c  pop rsi
000075d5269d146d  pop rdi
000075d5269d146e  pop rdx
000075d5269d146f  pop rcx
000075d5269d1470  pop rax
000075d5269d1471  add rsp, 0x08
000075d5269d1475  jmp 0x000075D5269CF878
000075d5269d147a  sub rsp, 0x08
000075d5269d147e  push rax
000075d5269d147f  push rcx
000075d5269d1480  push rdx
000075d5269d1481  push rdi
000075d5269d1482  push rsi
000075d5269d1483  push r8
000075d5269d1485  push r9
000075d5269d1487  push r10
000075d5269d1489  push r11
000075d5269d148b  sub rsp, 0xF0
000075d5269d1492  vmovaps [rsp], xmm0
000075d5269d1497  vmovaps [rsp+0x10], xmm2
000075d5269d149d  vmovaps [rsp+0x20], xmm3
000075d5269d14a3  vmovaps [rsp+0x30], xmm4
000075d5269d14a9  vmovaps [rsp+0x40], xmm5
000075d5269d14af  vmovaps [rsp+0x50], xmm6
000075d5269d14b5  vmovaps [rsp+0x60], xmm7
000075d5269d14bb  vmovaps [rsp+0x70], xmm8
000075d5269d14c1  vmovaps [rsp+0x80], xmm9
000075d5269d14ca  vmovaps [rsp+0x90], xmm10
000075d5269d14d3  vmovaps [rsp+0xA0], xmm11
000075d5269d14dc  vmovaps [rsp+0xB0], xmm12
000075d5269d14e5  vmovaps [rsp+0xC0], xmm13
000075d5269d14ee  vmovaps [rsp+0xD0], xmm14
000075d5269d14f7  vmovaps [rsp+0xE0], xmm15
000075d5269d1500  sub rsp, 0x30
000075d5269d1504  movaps [rsp], xmm1
000075d5269d1508  movaps [rsp+0x10], xmm15
000075d5269d150e  movaps [rsp+0x20], xmm2
000075d5269d1513  lea rdi, [rsp]
000075d5269d1517  mov esi, 0x00
000075d5269d151c  mov rax, 0x601129E62530
000075d5269d1526  call rax
000075d5269d1528  movaps xmm1, [rsp]
000075d5269d152c  add rsp, 0x30
000075d5269d1530  vmovaps xmm0, [rsp]
000075d5269d1535  vmovaps xmm2, [rsp+0x10]
000075d5269d153b  vmovaps xmm3, [rsp+0x20]
000075d5269d1541  vmovaps xmm4, [rsp+0x30]
000075d5269d1547  vmovaps xmm5, [rsp+0x40]
000075d5269d154d  vmovaps xmm6, [rsp+0x50]
000075d5269d1553  vmovaps xmm7, [rsp+0x60]
000075d5269d1559  vmovaps xmm8, [rsp+0x70]
000075d5269d155f  vmovaps xmm9, [rsp+0x80]
000075d5269d1568  vmovaps xmm10, [rsp+0x90]
000075d5269d1571  vmovaps xmm11, [rsp+0xA0]
000075d5269d157a  vmovaps xmm12, [rsp+0xB0]
000075d5269d1583  vmovaps xmm13, [rsp+0xC0]
000075d5269d158c  vmovaps xmm14, [rsp+0xD0]
000075d5269d1595  vmovaps xmm15, [rsp+0xE0]
000075d5269d159e  add rsp, 0xF0
000075d5269d15a5  pop r11
000075d5269d15a7  pop r10
000075d5269d15a9  pop r9
000075d5269d15ab  pop r8
000075d5269d15ad  pop rsi
000075d5269d15ae  pop rdi
000075d5269d15af  pop rdx
000075d5269d15b0  pop rcx
000075d5269d15b1  pop rax
000075d5269d15b2  add rsp, 0x08
000075d5269d15b6  jmp 0x000075D5269CF8AC
000075d5269d15bb  sub rsp, 0x08
000075d5269d15bf  push rax
000075d5269d15c0  push rcx
000075d5269d15c1  push rdx
000075d5269d15c2  push rdi
000075d5269d15c3  push rsi
000075d5269d15c4  push r8
000075d5269d15c6  push r9
000075d5269d15c8  push r10
000075d5269d15ca  push r11
000075d5269d15cc  sub rsp, 0xF0
000075d5269d15d3  vmovaps [rsp], xmm0
000075d5269d15d8  vmovaps [rsp+0x10], xmm1
000075d5269d15de  vmovaps [rsp+0x20], xmm2
000075d5269d15e4  vmovaps [rsp+0x30], xmm3
000075d5269d15ea  vmovaps [rsp+0x40], xmm4
000075d5269d15f0  vmovaps [rsp+0x50], xmm5
000075d5269d15f6  vmovaps [rsp+0x60], xmm6
000075d5269d15fc  vmovaps [rsp+0x70], xmm7
000075d5269d1602  vmovaps [rsp+0x80], xmm8
000075d5269d160b  vmovaps [rsp+0x90], xmm9
000075d5269d1614  vmovaps [rsp+0xA0], xmm10
000075d5269d161d  vmovaps [rsp+0xB0], xmm11
000075d5269d1626  vmovaps [rsp+0xC0], xmm12
000075d5269d162f  vmovaps [rsp+0xD0], xmm13
000075d5269d1638  vmovaps [rsp+0xE0], xmm15
000075d5269d1641  sub rsp, 0x30
000075d5269d1645  movaps [rsp], xmm14
000075d5269d164a  movaps [rsp+0x10], xmm2
000075d5269d164f  movaps [rsp+0x20], xmm15
000075d5269d1655  lea rdi, [rsp]
000075d5269d1659  mov esi, 0x00
000075d5269d165e  mov rax, 0x601129E62530
000075d5269d1668  call rax
000075d5269d166a  movaps xmm14, [rsp]
000075d5269d166f  add rsp, 0x30
000075d5269d1673  vmovaps xmm0, [rsp]
000075d5269d1678  vmovaps xmm1, [rsp+0x10]
000075d5269d167e  vmovaps xmm2, [rsp+0x20]
000075d5269d1684  vmovaps xmm3, [rsp+0x30]
000075d5269d168a  vmovaps xmm4, [rsp+0x40]
000075d5269d1690  vmovaps xmm5, [rsp+0x50]
000075d5269d1696  vmovaps xmm6, [rsp+0x60]
000075d5269d169c  vmovaps xmm7, [rsp+0x70]
000075d5269d16a2  vmovaps xmm8, [rsp+0x80]
000075d5269d16ab  vmovaps xmm9, [rsp+0x90]
000075d5269d16b4  vmovaps xmm10, [rsp+0xA0]
000075d5269d16bd  vmovaps xmm11, [rsp+0xB0]
000075d5269d16c6  vmovaps xmm12, [rsp+0xC0]
000075d5269d16cf  vmovaps xmm13, [rsp+0xD0]
000075d5269d16d8  vmovaps xmm15, [rsp+0xE0]
000075d5269d16e1  add rsp, 0xF0
000075d5269d16e8  pop r11
000075d5269d16ea  pop r10
000075d5269d16ec  pop r9
000075d5269d16ee  pop r8
000075d5269d16f0  pop rsi
000075d5269d16f1  pop rdi
000075d5269d16f2  pop rdx
000075d5269d16f3  pop rcx
000075d5269d16f4  pop rax
000075d5269d16f5  add rsp, 0x08
000075d5269d16f9  jmp 0x000075D5269CF8E7
000075d5269d16fe  sub rsp, 0x08
000075d5269d1702  push rax
000075d5269d1703  push rcx
000075d5269d1704  push rdx
000075d5269d1705  push rdi
000075d5269d1706  push rsi
000075d5269d1707  push r8
000075d5269d1709  push r9
000075d5269d170b  push r10
000075d5269d170d  push r11
000075d5269d170f  sub rsp, 0xF0
000075d5269d1716  vmovaps [rsp], xmm0
000075d5269d171b  vmovaps [rsp+0x10], xmm1
000075d5269d1721  vmovaps [rsp+0x20], xmm2
000075d5269d1727  vmovaps [rsp+0x30], xmm3
000075d5269d172d  vmovaps [rsp+0x40], xmm4
000075d5269d1733  vmovaps [rsp+0x50], xmm5
000075d5269d1739  vmovaps [rsp+0x60], xmm6
000075d5269d173f  vmovaps [rsp+0x70], xmm7
000075d5269d1745  vmovaps [rsp+0x80], xmm8
000075d5269d174e  vmovaps [rsp+0x90], xmm9
000075d5269d1757  vmovaps [rsp+0xA0], xmm10
000075d5269d1760  vmovaps [rsp+0xB0], xmm11
000075d5269d1769  vmovaps [rsp+0xC0], xmm12
000075d5269d1772  vmovaps [rsp+0xD0], xmm13
000075d5269d177b  vmovaps [rsp+0xE0], xmm14
000075d5269d1784  sub rsp, 0x30
000075d5269d1788  movaps [rsp], xmm15
000075d5269d178d  movaps [rsp+0x10], xmm2
000075d5269d1792  movaps [rsp+0x20], xmm1
000075d5269d1797  lea rdi, [rsp]
000075d5269d179b  mov esi, 0x00
000075d5269d17a0  mov rax, 0x601129E62530
000075d5269d17aa  call rax
000075d5269d17ac  movaps xmm15, [rsp]
000075d5269d17b1  add rsp, 0x30
000075d5269d17b5  vmovaps xmm0, [rsp]
000075d5269d17ba  vmovaps xmm1, [rsp+0x10]
000075d5269d17c0  vmovaps xmm2, [rsp+0x20]
000075d5269d17c6  vmovaps xmm3, [rsp+0x30]
000075d5269d17cc  vmovaps xmm4, [rsp+0x40]
000075d5269d17d2  vmovaps xmm5, [rsp+0x50]
000075d5269d17d8  vmovaps xmm6, [rsp+0x60]
000075d5269d17de  vmovaps xmm7, [rsp+0x70]
000075d5269d17e4  vmovaps xmm8, [rsp+0x80]
000075d5269d17ed  vmovaps xmm9, [rsp+0x90]
000075d5269d17f6  vmovaps xmm10, [rsp+0xA0]
000075d5269d17ff  vmovaps xmm11, [rsp+0xB0]
000075d5269d1808  vmovaps xmm12, [rsp+0xC0]
000075d5269d1811  vmovaps xmm13, [rsp+0xD0]
000075d5269d181a  vmovaps xmm14, [rsp+0xE0]
000075d5269d1823  add rsp, 0xF0
000075d5269d182a  pop r11
000075d5269d182c  pop r10
000075d5269d182e  pop r9
000075d5269d1830  pop r8
000075d5269d1832  pop rsi
000075d5269d1833  pop rdi
000075d5269d1834  pop rdx
000075d5269d1835  pop rcx
000075d5269d1836  pop rax
000075d5269d1837  add rsp, 0x08
000075d5269d183b  jmp 0x000075D5269CF923
000075d5269d1840  call 0x000075D5267FF430
000075d5269d1845  jmp 0x000075D5269CF930
000075d5269d184a  sub rsp, 0x08
000075d5269d184e  push rax
000075d5269d184f  push rcx
000075d5269d1850  push rdx
000075d5269d1851  push rdi
000075d5269d1852  push rsi
000075d5269d1853  push r8
000075d5269d1855  push r9
000075d5269d1857  push r10
000075d5269d1859  push r11
000075d5269d185b  sub rsp, 0xF0
000075d5269d1862  vmovaps [rsp], xmm0
000075d5269d1867  vmovaps [rsp+0x10], xmm1
000075d5269d186d  vmovaps [rsp+0x20], xmm3
000075d5269d1873  vmovaps [rsp+0x30], xmm4
000075d5269d1879  vmovaps [rsp+0x40], xmm5
000075d5269d187f  vmovaps [rsp+0x50], xmm6
000075d5269d1885  vmovaps [rsp+0x60], xmm7
000075d5269d188b  vmovaps [rsp+0x70], xmm8
000075d5269d1891  vmovaps [rsp+0x80], xmm9
000075d5269d189a  vmovaps [rsp+0x90], xmm10
000075d5269d18a3  vmovaps [rsp+0xA0], xmm11
000075d5269d18ac  vmovaps [rsp+0xB0], xmm12
000075d5269d18b5  vmovaps [rsp+0xC0], xmm13
000075d5269d18be  vmovaps [rsp+0xD0], xmm14
000075d5269d18c7  vmovaps [rsp+0xE0], xmm15
000075d5269d18d0  sub rsp, 0x30
000075d5269d18d4  movaps [rsp], xmm2
000075d5269d18d8  movaps [rsp+0x10], xmm1
000075d5269d18dd  movaps [rsp+0x20], xmm14
000075d5269d18e3  lea rdi, [rsp]
000075d5269d18e7  mov esi, 0x00
000075d5269d18ec  mov rax, 0x601129E62530
000075d5269d18f6  call rax
000075d5269d18f8  movaps xmm2, [rsp]
000075d5269d18fc  add rsp, 0x30
000075d5269d1900  vmovaps xmm0, [rsp]
000075d5269d1905  vmovaps xmm1, [rsp+0x10]
000075d5269d190b  vmovaps xmm3, [rsp+0x20]
000075d5269d1911  vmovaps xmm4, [rsp+0x30]
000075d5269d1917  vmovaps xmm5, [rsp+0x40]
000075d5269d191d  vmovaps xmm6, [rsp+0x50]
000075d5269d1923  vmovaps xmm7, [rsp+0x60]
000075d5269d1929  vmovaps xmm8, [rsp+0x70]
000075d5269d192f  vmovaps xmm9, [rsp+0x80]
000075d5269d1938  vmovaps xmm10, [rsp+0x90]
000075d5269d1941  vmovaps xmm11, [rsp+0xA0]
000075d5269d194a  vmovaps xmm12, [rsp+0xB0]
000075d5269d1953  vmovaps xmm13, [rsp+0xC0]
000075d5269d195c  vmovaps xmm14, [rsp+0xD0]
000075d5269d1965  vmovaps xmm15, [rsp+0xE0]
000075d5269d196e  add rsp, 0xF0
000075d5269d1975  pop r11
000075d5269d1977  pop r10
000075d5269d1979  pop r9
000075d5269d197b  pop r8
000075d5269d197d  pop rsi
000075d5269d197e  pop rdi
000075d5269d197f  pop rdx
000075d5269d1980  pop rcx
000075d5269d1981  pop rax
000075d5269d1982  add rsp, 0x08
000075d5269d1986  jmp 0x000075D5269CF96D
000075d5269d198b  sub rsp, 0x08
000075d5269d198f  push rax
000075d5269d1990  push rcx
000075d5269d1991  push rdx
000075d5269d1992  push rdi
000075d5269d1993  push rsi
000075d5269d1994  push r8
000075d5269d1996  push r9
000075d5269d1998  push r10
000075d5269d199a  push r11
000075d5269d199c  sub rsp, 0xF0
000075d5269d19a3  vmovaps [rsp], xmm0
000075d5269d19a8  vmovaps [rsp+0x10], xmm1
000075d5269d19ae  vmovaps [rsp+0x20], xmm2
000075d5269d19b4  vmovaps [rsp+0x30], xmm3
000075d5269d19ba  vmovaps [rsp+0x40], xmm4
000075d5269d19c0  vmovaps [rsp+0x50], xmm5
000075d5269d19c6  vmovaps [rsp+0x60], xmm6
000075d5269d19cc  vmovaps [rsp+0x70], xmm7
000075d5269d19d2  vmovaps [rsp+0x80], xmm8
000075d5269d19db  vmovaps [rsp+0x90], xmm9
000075d5269d19e4  vmovaps [rsp+0xA0], xmm10
000075d5269d19ed  vmovaps [rsp+0xB0], xmm11
000075d5269d19f6  vmovaps [rsp+0xC0], xmm12
000075d5269d19ff  vmovaps [rsp+0xD0], xmm13
000075d5269d1a08  vmovaps [rsp+0xE0], xmm14
000075d5269d1a11  sub rsp, 0x30
000075d5269d1a15  movaps [rsp], xmm15
000075d5269d1a1a  movaps [rsp+0x10], xmm14
000075d5269d1a20  movaps [rsp+0x20], xmm1
000075d5269d1a25  lea rdi, [rsp]
000075d5269d1a29  mov esi, 0x00
000075d5269d1a2e  mov rax, 0x601129E62530
000075d5269d1a38  call rax
000075d5269d1a3a  movaps xmm15, [rsp]
000075d5269d1a3f  add rsp, 0x30
000075d5269d1a43  vmovaps xmm0, [rsp]
000075d5269d1a48  vmovaps xmm1, [rsp+0x10]
000075d5269d1a4e  vmovaps xmm2, [rsp+0x20]
000075d5269d1a54  vmovaps xmm3, [rsp+0x30]
000075d5269d1a5a  vmovaps xmm4, [rsp+0x40]
000075d5269d1a60  vmovaps xmm5, [rsp+0x50]
000075d5269d1a66  vmovaps xmm6, [rsp+0x60]
000075d5269d1a6c  vmovaps xmm7, [rsp+0x70]
000075d5269d1a72  vmovaps xmm8, [rsp+0x80]
000075d5269d1a7b  vmovaps xmm9, [rsp+0x90]
000075d5269d1a84  vmovaps xmm10, [rsp+0xA0]
000075d5269d1a8d  vmovaps xmm11, [rsp+0xB0]
000075d5269d1a96  vmovaps xmm12, [rsp+0xC0]
000075d5269d1a9f  vmovaps xmm13, [rsp+0xD0]
000075d5269d1aa8  vmovaps xmm14, [rsp+0xE0]
000075d5269d1ab1  add rsp, 0xF0
000075d5269d1ab8  pop r11
000075d5269d1aba  pop r10
000075d5269d1abc  pop r9
000075d5269d1abe  pop r8
000075d5269d1ac0  pop rsi
000075d5269d1ac1  pop rdi
000075d5269d1ac2  pop rdx
000075d5269d1ac3  pop rcx
000075d5269d1ac4  pop rax
000075d5269d1ac5  add rsp, 0x08
000075d5269d1ac9  jmp 0x000075D5269CF9E7
000075d5269d1ace  call 0x000075D5267FF430
000075d5269d1ad3  jmp 0x000075D5269CF9F4
000075d5269d1ad8  sub rsp, 0x08
000075d5269d1adc  push rax
000075d5269d1add  push rcx
000075d5269d1ade  push rdx
000075d5269d1adf  push rdi
000075d5269d1ae0  push rsi
000075d5269d1ae1  push r8
000075d5269d1ae3  push r9
000075d5269d1ae5  push r10
000075d5269d1ae7  push r11
000075d5269d1ae9  sub rsp, 0xF0
000075d5269d1af0  vmovaps [rsp], xmm0
000075d5269d1af5  vmovaps [rsp+0x10], xmm1
000075d5269d1afb  vmovaps [rsp+0x20], xmm2
000075d5269d1b01  vmovaps [rsp+0x30], xmm3
000075d5269d1b07  vmovaps [rsp+0x40], xmm4
000075d5269d1b0d  vmovaps [rsp+0x50], xmm5
000075d5269d1b13  vmovaps [rsp+0x60], xmm6
000075d5269d1b19  vmovaps [rsp+0x70], xmm7
000075d5269d1b1f  vmovaps [rsp+0x80], xmm8
000075d5269d1b28  vmovaps [rsp+0x90], xmm9
000075d5269d1b31  vmovaps [rsp+0xA0], xmm10
000075d5269d1b3a  vmovaps [rsp+0xB0], xmm11
000075d5269d1b43  vmovaps [rsp+0xC0], xmm12
000075d5269d1b4c  vmovaps [rsp+0xD0], xmm13
000075d5269d1b55  vmovaps [rsp+0xE0], xmm15
000075d5269d1b5e  sub rsp, 0x30
000075d5269d1b62  movaps [rsp], xmm14
000075d5269d1b67  movaps [rsp+0x10], xmm13
000075d5269d1b6d  movaps [rsp+0x20], xmm1
000075d5269d1b72  lea rdi, [rsp]
000075d5269d1b76  mov esi, 0x00
000075d5269d1b7b  mov rax, 0x601129E62530
000075d5269d1b85  call rax
000075d5269d1b87  movaps xmm14, [rsp]
000075d5269d1b8c  add rsp, 0x30
000075d5269d1b90  vmovaps xmm0, [rsp]
000075d5269d1b95  vmovaps xmm1, [rsp+0x10]
000075d5269d1b9b  vmovaps xmm2, [rsp+0x20]
000075d5269d1ba1  vmovaps xmm3, [rsp+0x30]
000075d5269d1ba7  vmovaps xmm4, [rsp+0x40]
000075d5269d1bad  vmovaps xmm5, [rsp+0x50]
000075d5269d1bb3  vmovaps xmm6, [rsp+0x60]
000075d5269d1bb9  vmovaps xmm7, [rsp+0x70]
000075d5269d1bbf  vmovaps xmm8, [rsp+0x80]
000075d5269d1bc8  vmovaps xmm9, [rsp+0x90]
000075d5269d1bd1  vmovaps xmm10, [rsp+0xA0]
000075d5269d1bda  vmovaps xmm11, [rsp+0xB0]
000075d5269d1be3  vmovaps xmm12, [rsp+0xC0]
000075d5269d1bec  vmovaps xmm13, [rsp+0xD0]
000075d5269d1bf5  vmovaps xmm15, [rsp+0xE0]
000075d5269d1bfe  add rsp, 0xF0
000075d5269d1c05  pop r11
000075d5269d1c07  pop r10
000075d5269d1c09  pop r9
000075d5269d1c0b  pop r8
000075d5269d1c0d  pop rsi
000075d5269d1c0e  pop rdi
000075d5269d1c0f  pop rdx
000075d5269d1c10  pop rcx
000075d5269d1c11  pop rax
000075d5269d1c12  add rsp, 0x08
000075d5269d1c16  jmp 0x000075D5269CFAAF
000075d5269d1c1b  sub rsp, 0x08
000075d5269d1c1f  push rax
000075d5269d1c20  push rcx
000075d5269d1c21  push rdx
000075d5269d1c22  push rdi
000075d5269d1c23  push rsi
000075d5269d1c24  push r8
000075d5269d1c26  push r9
000075d5269d1c28  push r10
000075d5269d1c2a  push r11
000075d5269d1c2c  sub rsp, 0xF0
000075d5269d1c33  vmovaps [rsp], xmm0
000075d5269d1c38  vmovaps [rsp+0x10], xmm1
000075d5269d1c3e  vmovaps [rsp+0x20], xmm2
000075d5269d1c44  vmovaps [rsp+0x30], xmm3
000075d5269d1c4a  vmovaps [rsp+0x40], xmm4
000075d5269d1c50  vmovaps [rsp+0x50], xmm5
000075d5269d1c56  vmovaps [rsp+0x60], xmm6
000075d5269d1c5c  vmovaps [rsp+0x70], xmm7
000075d5269d1c62  vmovaps [rsp+0x80], xmm8
000075d5269d1c6b  vmovaps [rsp+0x90], xmm9
000075d5269d1c74  vmovaps [rsp+0xA0], xmm10
000075d5269d1c7d  vmovaps [rsp+0xB0], xmm11
000075d5269d1c86  vmovaps [rsp+0xC0], xmm12
000075d5269d1c8f  vmovaps [rsp+0xD0], xmm13
000075d5269d1c98  vmovaps [rsp+0xE0], xmm14
000075d5269d1ca1  sub rsp, 0x30
000075d5269d1ca5  movaps [rsp], xmm15
000075d5269d1caa  movaps [rsp+0x10], xmm13
000075d5269d1cb0  movaps [rsp+0x20], xmm1
000075d5269d1cb5  lea rdi, [rsp]
000075d5269d1cb9  mov esi, 0x00
000075d5269d1cbe  mov rax, 0x601129E62530
000075d5269d1cc8  call rax
000075d5269d1cca  movaps xmm15, [rsp]
000075d5269d1ccf  add rsp, 0x30
000075d5269d1cd3  vmovaps xmm0, [rsp]
000075d5269d1cd8  vmovaps xmm1, [rsp+0x10]
000075d5269d1cde  vmovaps xmm2, [rsp+0x20]
000075d5269d1ce4  vmovaps xmm3, [rsp+0x30]
000075d5269d1cea  vmovaps xmm4, [rsp+0x40]
000075d5269d1cf0  vmovaps xmm5, [rsp+0x50]
000075d5269d1cf6  vmovaps xmm6, [rsp+0x60]
000075d5269d1cfc  vmovaps xmm7, [rsp+0x70]
000075d5269d1d02  vmovaps xmm8, [rsp+0x80]
000075d5269d1d0b  vmovaps xmm9, [rsp+0x90]
000075d5269d1d14  vmovaps xmm10, [rsp+0xA0]
000075d5269d1d1d  vmovaps xmm11, [rsp+0xB0]
000075d5269d1d26  vmovaps xmm12, [rsp+0xC0]
000075d5269d1d2f  vmovaps xmm13, [rsp+0xD0]
000075d5269d1d38  vmovaps xmm14, [rsp+0xE0]
000075d5269d1d41  add rsp, 0xF0
000075d5269d1d48  pop r11
000075d5269d1d4a  pop r10
000075d5269d1d4c  pop r9
000075d5269d1d4e  pop r8
000075d5269d1d50  pop rsi
000075d5269d1d51  pop rdi
000075d5269d1d52  pop rdx
000075d5269d1d53  pop rcx
000075d5269d1d54  pop rax
000075d5269d1d55  add rsp, 0x08
000075d5269d1d59  jmp 0x000075D5269CFAEB
000075d5269d1d5e  call 0x000075D5267FF430
000075d5269d1d63  jmp 0x000075D5269CFAF8
000075d5269d1d68  sub rsp, 0x08
000075d5269d1d6c  push rax
000075d5269d1d6d  push rcx
000075d5269d1d6e  push rdx
000075d5269d1d6f  push rdi
000075d5269d1d70  push rsi
000075d5269d1d71  push r8
000075d5269d1d73  push r9
000075d5269d1d75  push r10
000075d5269d1d77  push r11
000075d5269d1d79  sub rsp, 0xF0
000075d5269d1d80  vmovaps [rsp], xmm0
000075d5269d1d85  vmovaps [rsp+0x10], xmm1
000075d5269d1d8b  vmovaps [rsp+0x20], xmm2
000075d5269d1d91  vmovaps [rsp+0x30], xmm3
000075d5269d1d97  vmovaps [rsp+0x40], xmm4
000075d5269d1d9d  vmovaps [rsp+0x50], xmm5
000075d5269d1da3  vmovaps [rsp+0x60], xmm6
000075d5269d1da9  vmovaps [rsp+0x70], xmm7
000075d5269d1daf  vmovaps [rsp+0x80], xmm8
000075d5269d1db8  vmovaps [rsp+0x90], xmm9
000075d5269d1dc1  vmovaps [rsp+0xA0], xmm10
000075d5269d1dca  vmovaps [rsp+0xB0], xmm11
000075d5269d1dd3  vmovaps [rsp+0xC0], xmm12
000075d5269d1ddc  vmovaps [rsp+0xD0], xmm13
000075d5269d1de5  vmovaps [rsp+0xE0], xmm15
000075d5269d1dee  sub rsp, 0x30
000075d5269d1df2  movaps [rsp], xmm14
000075d5269d1df7  movaps [rsp+0x10], xmm13
000075d5269d1dfd  movaps [rsp+0x20], xmm2
000075d5269d1e02  lea rdi, [rsp]
000075d5269d1e06  mov esi, 0x00
000075d5269d1e0b  mov rax, 0x601129E62530
000075d5269d1e15  call rax
000075d5269d1e17  movaps xmm14, [rsp]
000075d5269d1e1c  add rsp, 0x30
000075d5269d1e20  vmovaps xmm0, [rsp]
000075d5269d1e25  vmovaps xmm1, [rsp+0x10]
000075d5269d1e2b  vmovaps xmm2, [rsp+0x20]
000075d5269d1e31  vmovaps xmm3, [rsp+0x30]
000075d5269d1e37  vmovaps xmm4, [rsp+0x40]
000075d5269d1e3d  vmovaps xmm5, [rsp+0x50]
000075d5269d1e43  vmovaps xmm6, [rsp+0x60]
000075d5269d1e49  vmovaps xmm7, [rsp+0x70]
000075d5269d1e4f  vmovaps xmm8, [rsp+0x80]
000075d5269d1e58  vmovaps xmm9, [rsp+0x90]
000075d5269d1e61  vmovaps xmm10, [rsp+0xA0]
000075d5269d1e6a  vmovaps xmm11, [rsp+0xB0]
000075d5269d1e73  vmovaps xmm12, [rsp+0xC0]
000075d5269d1e7c  vmovaps xmm13, [rsp+0xD0]
000075d5269d1e85  vmovaps xmm15, [rsp+0xE0]
000075d5269d1e8e  add rsp, 0xF0
000075d5269d1e95  pop r11
000075d5269d1e97  pop r10
000075d5269d1e99  pop r9
000075d5269d1e9b  pop r8
000075d5269d1e9d  pop rsi
000075d5269d1e9e  pop rdi
000075d5269d1e9f  pop rdx
000075d5269d1ea0  pop rcx
000075d5269d1ea1  pop rax
000075d5269d1ea2  add rsp, 0x08
000075d5269d1ea6  jmp 0x000075D5269CFB24
000075d5269d1eab  sub rsp, 0x08
000075d5269d1eaf  push rax
000075d5269d1eb0  push rcx
000075d5269d1eb1  push rdx
000075d5269d1eb2  push rdi
000075d5269d1eb3  push rsi
000075d5269d1eb4  push r8
000075d5269d1eb6  push r9
000075d5269d1eb8  push r10
000075d5269d1eba  push r11
000075d5269d1ebc  sub rsp, 0xF0
000075d5269d1ec3  vmovaps [rsp], xmm0
000075d5269d1ec8  vmovaps [rsp+0x10], xmm2
000075d5269d1ece  vmovaps [rsp+0x20], xmm3
000075d5269d1ed4  vmovaps [rsp+0x30], xmm4
000075d5269d1eda  vmovaps [rsp+0x40], xmm5
000075d5269d1ee0  vmovaps [rsp+0x50], xmm6
000075d5269d1ee6  vmovaps [rsp+0x60], xmm7
000075d5269d1eec  vmovaps [rsp+0x70], xmm8
000075d5269d1ef2  vmovaps [rsp+0x80], xmm9
000075d5269d1efb  vmovaps [rsp+0x90], xmm10
000075d5269d1f04  vmovaps [rsp+0xA0], xmm11
000075d5269d1f0d  vmovaps [rsp+0xB0], xmm12
000075d5269d1f16  vmovaps [rsp+0xC0], xmm13
000075d5269d1f1f  vmovaps [rsp+0xD0], xmm14
000075d5269d1f28  vmovaps [rsp+0xE0], xmm15
000075d5269d1f31  sub rsp, 0x30
000075d5269d1f35  movaps [rsp], xmm1
000075d5269d1f39  movaps [rsp+0x10], xmm13
000075d5269d1f3f  movaps [rsp+0x20], xmm2
000075d5269d1f44  lea rdi, [rsp]
000075d5269d1f48  mov esi, 0x00
000075d5269d1f4d  mov rax, 0x601129E62530
000075d5269d1f57  call rax
000075d5269d1f59  movaps xmm1, [rsp]
000075d5269d1f5d  add rsp, 0x30
000075d5269d1f61  vmovaps xmm0, [rsp]
000075d5269d1f66  vmovaps xmm2, [rsp+0x10]
000075d5269d1f6c  vmovaps xmm3, [rsp+0x20]
000075d5269d1f72  vmovaps xmm4, [rsp+0x30]
000075d5269d1f78  vmovaps xmm5, [rsp+0x40]
000075d5269d1f7e  vmovaps xmm6, [rsp+0x50]
000075d5269d1f84  vmovaps xmm7, [rsp+0x60]
000075d5269d1f8a  vmovaps xmm8, [rsp+0x70]
000075d5269d1f90  vmovaps xmm9, [rsp+0x80]
000075d5269d1f99  vmovaps xmm10, [rsp+0x90]
000075d5269d1fa2  vmovaps xmm11, [rsp+0xA0]
000075d5269d1fab  vmovaps xmm12, [rsp+0xB0]
000075d5269d1fb4  vmovaps xmm13, [rsp+0xC0]
000075d5269d1fbd  vmovaps xmm14, [rsp+0xD0]
000075d5269d1fc6  vmovaps xmm15, [rsp+0xE0]
000075d5269d1fcf  add rsp, 0xF0
000075d5269d1fd6  pop r11
000075d5269d1fd8  pop r10
000075d5269d1fda  pop r9
000075d5269d1fdc  pop r8
000075d5269d1fde  pop rsi
000075d5269d1fdf  pop rdi
000075d5269d1fe0  pop rdx
000075d5269d1fe1  pop rcx
000075d5269d1fe2  pop rax
000075d5269d1fe3  add rsp, 0x08
000075d5269d1fe7  jmp 0x000075D5269CFB52
000075d5269d1fec  sub rsp, 0x08
000075d5269d1ff0  push rax
000075d5269d1ff1  push rcx
000075d5269d1ff2  push rdx
000075d5269d1ff3  push rdi
000075d5269d1ff4  push rsi
000075d5269d1ff5  push r8
000075d5269d1ff7  push r9
000075d5269d1ff9  push r10
000075d5269d1ffb  push r11
000075d5269d1ffd  sub rsp, 0xF0
000075d5269d2004  vmovaps [rsp], xmm0
000075d5269d2009  vmovaps [rsp+0x10], xmm1
000075d5269d200f  vmovaps [rsp+0x20], xmm3
000075d5269d2015  vmovaps [rsp+0x30], xmm4
000075d5269d201b  vmovaps [rsp+0x40], xmm5
000075d5269d2021  vmovaps [rsp+0x50], xmm6
000075d5269d2027  vmovaps [rsp+0x60], xmm7
000075d5269d202d  vmovaps [rsp+0x70], xmm8
000075d5269d2033  vmovaps [rsp+0x80], xmm9
000075d5269d203c  vmovaps [rsp+0x90], xmm10
000075d5269d2045  vmovaps [rsp+0xA0], xmm11
000075d5269d204e  vmovaps [rsp+0xB0], xmm12
000075d5269d2057  vmovaps [rsp+0xC0], xmm13
000075d5269d2060  vmovaps [rsp+0xD0], xmm14
000075d5269d2069  vmovaps [rsp+0xE0], xmm15
000075d5269d2072  sub rsp, 0x30
000075d5269d2076  movaps [rsp], xmm2
000075d5269d207a  movaps [rsp+0x10], xmm1
000075d5269d207f  movaps [rsp+0x20], xmm13
000075d5269d2085  lea rdi, [rsp]
000075d5269d2089  mov esi, 0x00
000075d5269d208e  mov rax, 0x601129E62530
000075d5269d2098  call rax
000075d5269d209a  movaps xmm2, [rsp]
000075d5269d209e  add rsp, 0x30
000075d5269d20a2  vmovaps xmm0, [rsp]
000075d5269d20a7  vmovaps xmm1, [rsp+0x10]
000075d5269d20ad  vmovaps xmm3, [rsp+0x20]
000075d5269d20b3  vmovaps xmm4, [rsp+0x30]
000075d5269d20b9  vmovaps xmm5, [rsp+0x40]
000075d5269d20bf  vmovaps xmm6, [rsp+0x50]
000075d5269d20c5  vmovaps xmm7, [rsp+0x60]
000075d5269d20cb  vmovaps xmm8, [rsp+0x70]
000075d5269d20d1  vmovaps xmm9, [rsp+0x80]
000075d5269d20da  vmovaps xmm10, [rsp+0x90]
000075d5269d20e3  vmovaps xmm11, [rsp+0xA0]
000075d5269d20ec  vmovaps xmm12, [rsp+0xB0]
000075d5269d20f5  vmovaps xmm13, [rsp+0xC0]
000075d5269d20fe  vmovaps xmm14, [rsp+0xD0]
000075d5269d2107  vmovaps xmm15, [rsp+0xE0]
000075d5269d2110  add rsp, 0xF0
000075d5269d2117  pop r11
000075d5269d2119  pop r10
000075d5269d211b  pop r9
000075d5269d211d  pop r8
000075d5269d211f  pop rsi
000075d5269d2120  pop rdi
000075d5269d2121  pop rdx
000075d5269d2122  pop rcx
000075d5269d2123  pop rax
000075d5269d2124  add rsp, 0x08
000075d5269d2128  jmp 0x000075D5269CFBAB
000075d5269d212d  call 0x000075D5267FF430
000075d5269d2132  jmp 0x000075D5269CFBB8
000075d5269d2137  sub rsp, 0x08
000075d5269d213b  push rax
000075d5269d213c  push rcx
000075d5269d213d  push rdx
000075d5269d213e  push rdi
000075d5269d213f  push rsi
000075d5269d2140  push r8
000075d5269d2142  push r9
000075d5269d2144  push r10
000075d5269d2146  push r11
000075d5269d2148  sub rsp, 0xF0
000075d5269d214f  vmovaps [rsp], xmm0
000075d5269d2154  vmovaps [rsp+0x10], xmm1
000075d5269d215a  vmovaps [rsp+0x20], xmm2
000075d5269d2160  vmovaps [rsp+0x30], xmm3
000075d5269d2166  vmovaps [rsp+0x40], xmm4
000075d5269d216c  vmovaps [rsp+0x50], xmm5
000075d5269d2172  vmovaps [rsp+0x60], xmm6
000075d5269d2178  vmovaps [rsp+0x70], xmm7
000075d5269d217e  vmovaps [rsp+0x80], xmm8
000075d5269d2187  vmovaps [rsp+0x90], xmm9
000075d5269d2190  vmovaps [rsp+0xA0], xmm10
000075d5269d2199  vmovaps [rsp+0xB0], xmm11
000075d5269d21a2  vmovaps [rsp+0xC0], xmm12
000075d5269d21ab  vmovaps [rsp+0xD0], xmm13
000075d5269d21b4  vmovaps [rsp+0xE0], xmm14
000075d5269d21bd  sub rsp, 0x30
000075d5269d21c1  movaps [rsp], xmm15
000075d5269d21c6  movaps [rsp+0x10], xmm13
000075d5269d21cc  movaps [rsp+0x20], xmm1
000075d5269d21d1  lea rdi, [rsp]
000075d5269d21d5  mov esi, 0x00
000075d5269d21da  mov rax, 0x601129E62530
000075d5269d21e4  call rax
000075d5269d21e6  movaps xmm15, [rsp]
000075d5269d21eb  add rsp, 0x30
000075d5269d21ef  vmovaps xmm0, [rsp]
000075d5269d21f4  vmovaps xmm1, [rsp+0x10]
000075d5269d21fa  vmovaps xmm2, [rsp+0x20]
000075d5269d2200  vmovaps xmm3, [rsp+0x30]
000075d5269d2206  vmovaps xmm4, [rsp+0x40]
000075d5269d220c  vmovaps xmm5, [rsp+0x50]
000075d5269d2212  vmovaps xmm6, [rsp+0x60]
000075d5269d2218  vmovaps xmm7, [rsp+0x70]
000075d5269d221e  vmovaps xmm8, [rsp+0x80]
000075d5269d2227  vmovaps xmm9, [rsp+0x90]
000075d5269d2230  vmovaps xmm10, [rsp+0xA0]
000075d5269d2239  vmovaps xmm11, [rsp+0xB0]
000075d5269d2242  vmovaps xmm12, [rsp+0xC0]
000075d5269d224b  vmovaps xmm13, [rsp+0xD0]
000075d5269d2254  vmovaps xmm14, [rsp+0xE0]
000075d5269d225d  add rsp, 0xF0
000075d5269d2264  pop r11
000075d5269d2266  pop r10
000075d5269d2268  pop r9
000075d5269d226a  pop r8
000075d5269d226c  pop rsi
000075d5269d226d  pop rdi
000075d5269d226e  pop rdx
000075d5269d226f  pop rcx
000075d5269d2270  pop rax
000075d5269d2271  add rsp, 0x08
000075d5269d2275  jmp 0x000075D5269CFBF7
000075d5269d227a  sub rsp, 0x08
000075d5269d227e  push rax
000075d5269d227f  push rcx
000075d5269d2280  push rdx
000075d5269d2281  push rdi
000075d5269d2282  push rsi
000075d5269d2283  push r8
000075d5269d2285  push r9
000075d5269d2287  push r10
000075d5269d2289  push r11
000075d5269d228b  sub rsp, 0xF0
000075d5269d2292  vmovaps [rsp], xmm0
000075d5269d2297  vmovaps [rsp+0x10], xmm1
000075d5269d229d  vmovaps [rsp+0x20], xmm2
000075d5269d22a3  vmovaps [rsp+0x30], xmm3
000075d5269d22a9  vmovaps [rsp+0x40], xmm4
000075d5269d22af  vmovaps [rsp+0x50], xmm5
000075d5269d22b5  vmovaps [rsp+0x60], xmm6
000075d5269d22bb  vmovaps [rsp+0x70], xmm7
000075d5269d22c1  vmovaps [rsp+0x80], xmm8
000075d5269d22ca  vmovaps [rsp+0x90], xmm9
000075d5269d22d3  vmovaps [rsp+0xA0], xmm10
000075d5269d22dc  vmovaps [rsp+0xB0], xmm11
000075d5269d22e5  vmovaps [rsp+0xC0], xmm12
000075d5269d22ee  vmovaps [rsp+0xD0], xmm13
000075d5269d22f7  vmovaps [rsp+0xE0], xmm15
000075d5269d2300  sub rsp, 0x30
000075d5269d2304  movaps [rsp], xmm14
000075d5269d2309  movaps [rsp+0x10], xmm11
000075d5269d230f  movaps [rsp+0x20], xmm1
000075d5269d2314  lea rdi, [rsp]
000075d5269d2318  mov esi, 0x00
000075d5269d231d  mov rax, 0x601129E62530
000075d5269d2327  call rax
000075d5269d2329  movaps xmm14, [rsp]
000075d5269d232e  add rsp, 0x30
000075d5269d2332  vmovaps xmm0, [rsp]
000075d5269d2337  vmovaps xmm1, [rsp+0x10]
000075d5269d233d  vmovaps xmm2, [rsp+0x20]
000075d5269d2343  vmovaps xmm3, [rsp+0x30]
000075d5269d2349  vmovaps xmm4, [rsp+0x40]
000075d5269d234f  vmovaps xmm5, [rsp+0x50]
000075d5269d2355  vmovaps xmm6, [rsp+0x60]
000075d5269d235b  vmovaps xmm7, [rsp+0x70]
000075d5269d2361  vmovaps xmm8, [rsp+0x80]
000075d5269d236a  vmovaps xmm9, [rsp+0x90]
000075d5269d2373  vmovaps xmm10, [rsp+0xA0]
000075d5269d237c  vmovaps xmm11, [rsp+0xB0]
000075d5269d2385  vmovaps xmm12, [rsp+0xC0]
000075d5269d238e  vmovaps xmm13, [rsp+0xD0]
000075d5269d2397  vmovaps xmm15, [rsp+0xE0]
000075d5269d23a0  add rsp, 0xF0
000075d5269d23a7  pop r11
000075d5269d23a9  pop r10
000075d5269d23ab  pop r9
000075d5269d23ad  pop r8
000075d5269d23af  pop rsi
000075d5269d23b0  pop rdi
000075d5269d23b1  pop rdx
000075d5269d23b2  pop rcx
000075d5269d23b3  pop rax
000075d5269d23b4  add rsp, 0x08
000075d5269d23b8  jmp 0x000075D5269CFC21
000075d5269d23bd  sub rsp, 0x08
000075d5269d23c1  push rax
000075d5269d23c2  push rcx
000075d5269d23c3  push rdx
000075d5269d23c4  push rdi
000075d5269d23c5  push rsi
000075d5269d23c6  push r8
000075d5269d23c8  push r9
000075d5269d23ca  push r10
000075d5269d23cc  push r11
000075d5269d23ce  sub rsp, 0xF0
000075d5269d23d5  vmovaps [rsp], xmm0
000075d5269d23da  vmovaps [rsp+0x10], xmm1
000075d5269d23e0  vmovaps [rsp+0x20], xmm2
000075d5269d23e6  vmovaps [rsp+0x30], xmm3
000075d5269d23ec  vmovaps [rsp+0x40], xmm4
000075d5269d23f2  vmovaps [rsp+0x50], xmm5
000075d5269d23f8  vmovaps [rsp+0x60], xmm6
000075d5269d23fe  vmovaps [rsp+0x70], xmm7
000075d5269d2404  vmovaps [rsp+0x80], xmm8
000075d5269d240d  vmovaps [rsp+0x90], xmm9
000075d5269d2416  vmovaps [rsp+0xA0], xmm10
000075d5269d241f  vmovaps [rsp+0xB0], xmm11
000075d5269d2428  vmovaps [rsp+0xC0], xmm12
000075d5269d2431  vmovaps [rsp+0xD0], xmm14
000075d5269d243a  vmovaps [rsp+0xE0], xmm15
000075d5269d2443  sub rsp, 0x30
000075d5269d2447  movaps [rsp], xmm13
000075d5269d244c  movaps [rsp+0x10], xmm11
000075d5269d2452  movaps [rsp+0x20], xmm1
000075d5269d2457  lea rdi, [rsp]
000075d5269d245b  mov esi, 0x00
000075d5269d2460  mov rax, 0x601129E62530
000075d5269d246a  call rax
000075d5269d246c  movaps xmm13, [rsp]
000075d5269d2471  add rsp, 0x30
000075d5269d2475  vmovaps xmm0, [rsp]
000075d5269d247a  vmovaps xmm1, [rsp+0x10]
000075d5269d2480  vmovaps xmm2, [rsp+0x20]
000075d5269d2486  vmovaps xmm3, [rsp+0x30]
000075d5269d248c  vmovaps xmm4, [rsp+0x40]
000075d5269d2492  vmovaps xmm5, [rsp+0x50]
000075d5269d2498  vmovaps xmm6, [rsp+0x60]
000075d5269d249e  vmovaps xmm7, [rsp+0x70]
000075d5269d24a4  vmovaps xmm8, [rsp+0x80]
000075d5269d24ad  vmovaps xmm9, [rsp+0x90]
000075d5269d24b6  vmovaps xmm10, [rsp+0xA0]
000075d5269d24bf  vmovaps xmm11, [rsp+0xB0]
000075d5269d24c8  vmovaps xmm12, [rsp+0xC0]
000075d5269d24d1  vmovaps xmm14, [rsp+0xD0]
000075d5269d24da  vmovaps xmm15, [rsp+0xE0]
000075d5269d24e3  add rsp, 0xF0
000075d5269d24ea  pop r11
000075d5269d24ec  pop r10
000075d5269d24ee  pop r9
000075d5269d24f0  pop r8
000075d5269d24f2  pop rsi
000075d5269d24f3  pop rdi
000075d5269d24f4  pop rdx
000075d5269d24f5  pop rcx
000075d5269d24f6  pop rax
000075d5269d24f7  add rsp, 0x08
000075d5269d24fb  jmp 0x000075D5269CFC76
000075d5269d2500  call 0x000075D5267FF430
000075d5269d2505  jmp 0x000075D5269CFC83
000075d5269d250a  sub rsp, 0x08
000075d5269d250e  push rax
000075d5269d250f  push rcx
000075d5269d2510  push rdx
000075d5269d2511  push rdi
000075d5269d2512  push rsi
000075d5269d2513  push r8
000075d5269d2515  push r9
000075d5269d2517  push r10
000075d5269d2519  push r11
000075d5269d251b  sub rsp, 0xF0
000075d5269d2522  vmovaps [rsp], xmm0
000075d5269d2527  vmovaps [rsp+0x10], xmm1
000075d5269d252d  vmovaps [rsp+0x20], xmm2
000075d5269d2533  vmovaps [rsp+0x30], xmm3
000075d5269d2539  vmovaps [rsp+0x40], xmm4
000075d5269d253f  vmovaps [rsp+0x50], xmm5
000075d5269d2545  vmovaps [rsp+0x60], xmm6
000075d5269d254b  vmovaps [rsp+0x70], xmm7
000075d5269d2551  vmovaps [rsp+0x80], xmm8
000075d5269d255a  vmovaps [rsp+0x90], xmm9
000075d5269d2563  vmovaps [rsp+0xA0], xmm10
000075d5269d256c  vmovaps [rsp+0xB0], xmm11
000075d5269d2575  vmovaps [rsp+0xC0], xmm12
000075d5269d257e  vmovaps [rsp+0xD0], xmm13
000075d5269d2587  vmovaps [rsp+0xE0], xmm14
000075d5269d2590  sub rsp, 0x30
000075d5269d2594  movaps [rsp], xmm15
000075d5269d2599  movaps [rsp+0x10], xmm11
000075d5269d259f  movaps [rsp+0x20], xmm1
000075d5269d25a4  lea rdi, [rsp]
000075d5269d25a8  mov esi, 0x00
000075d5269d25ad  mov rax, 0x601129E62530
000075d5269d25b7  call rax
000075d5269d25b9  movaps xmm15, [rsp]
000075d5269d25be  add rsp, 0x30
000075d5269d25c2  vmovaps xmm0, [rsp]
000075d5269d25c7  vmovaps xmm1, [rsp+0x10]
000075d5269d25cd  vmovaps xmm2, [rsp+0x20]
000075d5269d25d3  vmovaps xmm3, [rsp+0x30]
000075d5269d25d9  vmovaps xmm4, [rsp+0x40]
000075d5269d25df  vmovaps xmm5, [rsp+0x50]
000075d5269d25e5  vmovaps xmm6, [rsp+0x60]
000075d5269d25eb  vmovaps xmm7, [rsp+0x70]
000075d5269d25f1  vmovaps xmm8, [rsp+0x80]
000075d5269d25fa  vmovaps xmm9, [rsp+0x90]
000075d5269d2603  vmovaps xmm10, [rsp+0xA0]
000075d5269d260c  vmovaps xmm11, [rsp+0xB0]
000075d5269d2615  vmovaps xmm12, [rsp+0xC0]
000075d5269d261e  vmovaps xmm13, [rsp+0xD0]
000075d5269d2627  vmovaps xmm14, [rsp+0xE0]
000075d5269d2630  add rsp, 0xF0
000075d5269d2637  pop r11
000075d5269d2639  pop r10
000075d5269d263b  pop r9
000075d5269d263d  pop r8
000075d5269d263f  pop rsi
000075d5269d2640  pop rdi
000075d5269d2641  pop rdx
000075d5269d2642  pop rcx
000075d5269d2643  pop rax
000075d5269d2644  add rsp, 0x08
000075d5269d2648  jmp 0x000075D5269CFCBC
000075d5269d264d  sub rsp, 0x08
000075d5269d2651  push rax
000075d5269d2652  push rcx
000075d5269d2653  push rdx
000075d5269d2654  push rdi
000075d5269d2655  push rsi
000075d5269d2656  push r8
000075d5269d2658  push r9
000075d5269d265a  push r10
000075d5269d265c  push r11
000075d5269d265e  sub rsp, 0xF0
000075d5269d2665  vmovaps [rsp], xmm0
000075d5269d266a  vmovaps [rsp+0x10], xmm1
000075d5269d2670  vmovaps [rsp+0x20], xmm2
000075d5269d2676  vmovaps [rsp+0x30], xmm3
000075d5269d267c  vmovaps [rsp+0x40], xmm4
000075d5269d2682  vmovaps [rsp+0x50], xmm5
000075d5269d2688  vmovaps [rsp+0x60], xmm6
000075d5269d268e  vmovaps [rsp+0x70], xmm7
000075d5269d2694  vmovaps [rsp+0x80], xmm8
000075d5269d269d  vmovaps [rsp+0x90], xmm9
000075d5269d26a6  vmovaps [rsp+0xA0], xmm10
000075d5269d26af  vmovaps [rsp+0xB0], xmm12
000075d5269d26b8  vmovaps [rsp+0xC0], xmm13
000075d5269d26c1  vmovaps [rsp+0xD0], xmm14
000075d5269d26ca  vmovaps [rsp+0xE0], xmm15
000075d5269d26d3  sub rsp, 0x30
000075d5269d26d7  movaps [rsp], xmm11
000075d5269d26dc  movaps [rsp+0x10], xmm6
000075d5269d26e1  movaps [rsp+0x20], xmm14
000075d5269d26e7  lea rdi, [rsp]
000075d5269d26eb  mov esi, 0x00
000075d5269d26f0  mov rax, 0x601129E62530
000075d5269d26fa  call rax
000075d5269d26fc  movaps xmm11, [rsp]
000075d5269d2701  add rsp, 0x30
000075d5269d2705  vmovaps xmm0, [rsp]
000075d5269d270a  vmovaps xmm1, [rsp+0x10]
000075d5269d2710  vmovaps xmm2, [rsp+0x20]
000075d5269d2716  vmovaps xmm3, [rsp+0x30]
000075d5269d271c  vmovaps xmm4, [rsp+0x40]
000075d5269d2722  vmovaps xmm5, [rsp+0x50]
000075d5269d2728  vmovaps xmm6, [rsp+0x60]
000075d5269d272e  vmovaps xmm7, [rsp+0x70]
000075d5269d2734  vmovaps xmm8, [rsp+0x80]
000075d5269d273d  vmovaps xmm9, [rsp+0x90]
000075d5269d2746  vmovaps xmm10, [rsp+0xA0]
000075d5269d274f  vmovaps xmm12, [rsp+0xB0]
000075d5269d2758  vmovaps xmm13, [rsp+0xC0]
000075d5269d2761  vmovaps xmm14, [rsp+0xD0]
000075d5269d276a  vmovaps xmm15, [rsp+0xE0]
000075d5269d2773  add rsp, 0xF0
000075d5269d277a  pop r11
000075d5269d277c  pop r10
000075d5269d277e  pop r9
000075d5269d2780  pop r8
000075d5269d2782  pop rsi
000075d5269d2783  pop rdi
000075d5269d2784  pop rdx
000075d5269d2785  pop rcx
000075d5269d2786  pop rax
000075d5269d2787  add rsp, 0x08
000075d5269d278b  jmp 0x000075D5269CFD34
000075d5269d2790  call 0x000075D5267FF430
000075d5269d2795  jmp 0x000075D5269CFD3E
000075d5269d279a  sub rsp, 0x08
000075d5269d279e  push rax
000075d5269d279f  push rcx
000075d5269d27a0  push rdx
000075d5269d27a1  push rdi
000075d5269d27a2  push rsi
000075d5269d27a3  push r8
000075d5269d27a5  push r9
000075d5269d27a7  push r10
000075d5269d27a9  push r11
000075d5269d27ab  sub rsp, 0xF0
000075d5269d27b2  vmovaps [rsp], xmm0
000075d5269d27b7  vmovaps [rsp+0x10], xmm1
000075d5269d27bd  vmovaps [rsp+0x20], xmm2
000075d5269d27c3  vmovaps [rsp+0x30], xmm3
000075d5269d27c9  vmovaps [rsp+0x40], xmm4
000075d5269d27cf  vmovaps [rsp+0x50], xmm5
000075d5269d27d5  vmovaps [rsp+0x60], xmm6
000075d5269d27db  vmovaps [rsp+0x70], xmm7
000075d5269d27e1  vmovaps [rsp+0x80], xmm8
000075d5269d27ea  vmovaps [rsp+0x90], xmm9
000075d5269d27f3  vmovaps [rsp+0xA0], xmm10
000075d5269d27fc  vmovaps [rsp+0xB0], xmm11
000075d5269d2805  vmovaps [rsp+0xC0], xmm12
000075d5269d280e  vmovaps [rsp+0xD0], xmm13
000075d5269d2817  vmovaps [rsp+0xE0], xmm15
000075d5269d2820  sub rsp, 0x30
000075d5269d2824  movaps [rsp], xmm14
000075d5269d2829  movaps [rsp+0x10], xmm6
000075d5269d282e  movaps [rsp+0x20], xmm2
000075d5269d2833  lea rdi, [rsp]
000075d5269d2837  mov esi, 0x00
000075d5269d283c  mov rax, 0x601129E62530
000075d5269d2846  call rax
000075d5269d2848  movaps xmm14, [rsp]
000075d5269d284d  add rsp, 0x30
000075d5269d2851  vmovaps xmm0, [rsp]
000075d5269d2856  vmovaps xmm1, [rsp+0x10]
000075d5269d285c  vmovaps xmm2, [rsp+0x20]
000075d5269d2862  vmovaps xmm3, [rsp+0x30]
000075d5269d2868  vmovaps xmm4, [rsp+0x40]
000075d5269d286e  vmovaps xmm5, [rsp+0x50]
000075d5269d2874  vmovaps xmm6, [rsp+0x60]
000075d5269d287a  vmovaps xmm7, [rsp+0x70]
000075d5269d2880  vmovaps xmm8, [rsp+0x80]
000075d5269d2889  vmovaps xmm9, [rsp+0x90]
000075d5269d2892  vmovaps xmm10, [rsp+0xA0]
000075d5269d289b  vmovaps xmm11, [rsp+0xB0]
000075d5269d28a4  vmovaps xmm12, [rsp+0xC0]
000075d5269d28ad  vmovaps xmm13, [rsp+0xD0]
000075d5269d28b6  vmovaps xmm15, [rsp+0xE0]
000075d5269d28bf  add rsp, 0xF0
000075d5269d28c6  pop r11
000075d5269d28c8  pop r10
000075d5269d28ca  pop r9
000075d5269d28cc  pop r8
000075d5269d28ce  pop rsi
000075d5269d28cf  pop rdi
000075d5269d28d0  pop rdx
000075d5269d28d1  pop rcx
000075d5269d28d2  pop rax
000075d5269d28d3  add rsp, 0x08
000075d5269d28d7  jmp 0x000075D5269CFD72
000075d5269d28dc  sub rsp, 0x08
000075d5269d28e0  push rax
000075d5269d28e1  push rcx
000075d5269d28e2  push rdx
000075d5269d28e3  push rdi
000075d5269d28e4  push rsi
000075d5269d28e5  push r8
000075d5269d28e7  push r9
000075d5269d28e9  push r10
000075d5269d28eb  push r11
000075d5269d28ed  sub rsp, 0xF0
000075d5269d28f4  vmovaps [rsp], xmm0
000075d5269d28f9  vmovaps [rsp+0x10], xmm1
000075d5269d28ff  vmovaps [rsp+0x20], xmm2
000075d5269d2905  vmovaps [rsp+0x30], xmm3
000075d5269d290b  vmovaps [rsp+0x40], xmm4
000075d5269d2911  vmovaps [rsp+0x50], xmm5
000075d5269d2917  vmovaps [rsp+0x60], xmm7
000075d5269d291d  vmovaps [rsp+0x70], xmm8
000075d5269d2923  vmovaps [rsp+0x80], xmm9
000075d5269d292c  vmovaps [rsp+0x90], xmm10
000075d5269d2935  vmovaps [rsp+0xA0], xmm11
000075d5269d293e  vmovaps [rsp+0xB0], xmm12
000075d5269d2947  vmovaps [rsp+0xC0], xmm13
000075d5269d2950  vmovaps [rsp+0xD0], xmm14
000075d5269d2959  vmovaps [rsp+0xE0], xmm15
000075d5269d2962  sub rsp, 0x30
000075d5269d2966  movaps [rsp], xmm6
000075d5269d296a  movaps [rsp+0x10], xmm5
000075d5269d296f  movaps [rsp+0x20], xmm1
000075d5269d2974  lea rdi, [rsp]
000075d5269d2978  mov esi, 0x00
000075d5269d297d  mov rax, 0x601129E62530
000075d5269d2987  call rax
000075d5269d2989  movaps xmm6, [rsp]
000075d5269d298d  add rsp, 0x30
000075d5269d2991  vmovaps xmm0, [rsp]
000075d5269d2996  vmovaps xmm1, [rsp+0x10]
000075d5269d299c  vmovaps xmm2, [rsp+0x20]
000075d5269d29a2  vmovaps xmm3, [rsp+0x30]
000075d5269d29a8  vmovaps xmm4, [rsp+0x40]
000075d5269d29ae  vmovaps xmm5, [rsp+0x50]
000075d5269d29b4  vmovaps xmm7, [rsp+0x60]
000075d5269d29ba  vmovaps xmm8, [rsp+0x70]
000075d5269d29c0  vmovaps xmm9, [rsp+0x80]
000075d5269d29c9  vmovaps xmm10, [rsp+0x90]
000075d5269d29d2  vmovaps xmm11, [rsp+0xA0]
000075d5269d29db  vmovaps xmm12, [rsp+0xB0]
000075d5269d29e4  vmovaps xmm13, [rsp+0xC0]
000075d5269d29ed  vmovaps xmm14, [rsp+0xD0]
000075d5269d29f6  vmovaps xmm15, [rsp+0xE0]
000075d5269d29ff  add rsp, 0xF0
000075d5269d2a06  pop r11
000075d5269d2a08  pop r10
000075d5269d2a0a  pop r9
000075d5269d2a0c  pop r8
000075d5269d2a0e  pop rsi
000075d5269d2a0f  pop rdi
000075d5269d2a10  pop rdx
000075d5269d2a11  pop rcx
000075d5269d2a12  pop rax
000075d5269d2a13  add rsp, 0x08
000075d5269d2a17  jmp 0x000075D5269CFD98
000075d5269d2a1c  sub rsp, 0x08
000075d5269d2a20  push rax
000075d5269d2a21  push rcx
000075d5269d2a22  push rdx
000075d5269d2a23  push rdi
000075d5269d2a24  push rsi
000075d5269d2a25  push r8
000075d5269d2a27  push r9
000075d5269d2a29  push r10
000075d5269d2a2b  push r11
000075d5269d2a2d  sub rsp, 0xF0
000075d5269d2a34  vmovaps [rsp], xmm0
000075d5269d2a39  vmovaps [rsp+0x10], xmm2
000075d5269d2a3f  vmovaps [rsp+0x20], xmm3
000075d5269d2a45  vmovaps [rsp+0x30], xmm4
000075d5269d2a4b  vmovaps [rsp+0x40], xmm5
000075d5269d2a51  vmovaps [rsp+0x50], xmm6
000075d5269d2a57  vmovaps [rsp+0x60], xmm7
000075d5269d2a5d  vmovaps [rsp+0x70], xmm8
000075d5269d2a63  vmovaps [rsp+0x80], xmm9
000075d5269d2a6c  vmovaps [rsp+0x90], xmm10
000075d5269d2a75  vmovaps [rsp+0xA0], xmm11
000075d5269d2a7e  vmovaps [rsp+0xB0], xmm12
000075d5269d2a87  vmovaps [rsp+0xC0], xmm13
000075d5269d2a90  vmovaps [rsp+0xD0], xmm14
000075d5269d2a99  vmovaps [rsp+0xE0], xmm15
000075d5269d2aa2  sub rsp, 0x30
000075d5269d2aa6  movaps [rsp], xmm1
000075d5269d2aaa  movaps [rsp+0x10], xmm5
000075d5269d2aaf  movaps [rsp+0x20], xmm13
000075d5269d2ab5  lea rdi, [rsp]
000075d5269d2ab9  mov esi, 0x00
000075d5269d2abe  mov rax, 0x601129E62530
000075d5269d2ac8  call rax
000075d5269d2aca  movaps xmm1, [rsp]
000075d5269d2ace  add rsp, 0x30
000075d5269d2ad2  vmovaps xmm0, [rsp]
000075d5269d2ad7  vmovaps xmm2, [rsp+0x10]
000075d5269d2add  vmovaps xmm3, [rsp+0x20]
000075d5269d2ae3  vmovaps xmm4, [rsp+0x30]
000075d5269d2ae9  vmovaps xmm5, [rsp+0x40]
000075d5269d2aef  vmovaps xmm6, [rsp+0x50]
000075d5269d2af5  vmovaps xmm7, [rsp+0x60]
000075d5269d2afb  vmovaps xmm8, [rsp+0x70]
000075d5269d2b01  vmovaps xmm9, [rsp+0x80]
000075d5269d2b0a  vmovaps xmm10, [rsp+0x90]
000075d5269d2b13  vmovaps xmm11, [rsp+0xA0]
000075d5269d2b1c  vmovaps xmm12, [rsp+0xB0]
000075d5269d2b25  vmovaps xmm13, [rsp+0xC0]
000075d5269d2b2e  vmovaps xmm14, [rsp+0xD0]
000075d5269d2b37  vmovaps xmm15, [rsp+0xE0]
000075d5269d2b40  add rsp, 0xF0
000075d5269d2b47  pop r11
000075d5269d2b49  pop r10
000075d5269d2b4b  pop r9
000075d5269d2b4d  pop r8
000075d5269d2b4f  pop rsi
000075d5269d2b50  pop rdi
000075d5269d2b51  pop rdx
000075d5269d2b52  pop rcx
000075d5269d2b53  pop rax
000075d5269d2b54  add rsp, 0x08
000075d5269d2b58  jmp 0x000075D5269CFDB6
000075d5269d2b5d  sub rsp, 0x08
000075d5269d2b61  push rax
000075d5269d2b62  push rcx
000075d5269d2b63  push rdx
000075d5269d2b64  push rdi
000075d5269d2b65  push rsi
000075d5269d2b66  push r8
000075d5269d2b68  push r9
000075d5269d2b6a  push r10
000075d5269d2b6c  push r11
000075d5269d2b6e  sub rsp, 0xF0
000075d5269d2b75  vmovaps [rsp], xmm0
000075d5269d2b7a  vmovaps [rsp+0x10], xmm1
000075d5269d2b80  vmovaps [rsp+0x20], xmm2
000075d5269d2b86  vmovaps [rsp+0x30], xmm3
000075d5269d2b8c  vmovaps [rsp+0x40], xmm4
000075d5269d2b92  vmovaps [rsp+0x50], xmm6
000075d5269d2b98  vmovaps [rsp+0x60], xmm7
000075d5269d2b9e  vmovaps [rsp+0x70], xmm8
000075d5269d2ba4  vmovaps [rsp+0x80], xmm9
000075d5269d2bad  vmovaps [rsp+0x90], xmm10
000075d5269d2bb6  vmovaps [rsp+0xA0], xmm11
000075d5269d2bbf  vmovaps [rsp+0xB0], xmm12
000075d5269d2bc8  vmovaps [rsp+0xC0], xmm13
000075d5269d2bd1  vmovaps [rsp+0xD0], xmm14
000075d5269d2bda  vmovaps [rsp+0xE0], xmm15
000075d5269d2be3  sub rsp, 0x30
000075d5269d2be7  movaps [rsp], xmm5
000075d5269d2beb  movaps [rsp+0x10], xmm2
000075d5269d2bf0  movaps [rsp+0x20], xmm13
000075d5269d2bf6  lea rdi, [rsp]
000075d5269d2bfa  mov esi, 0x00
000075d5269d2bff  mov rax, 0x601129E62530
000075d5269d2c09  call rax
000075d5269d2c0b  movaps xmm5, [rsp]
000075d5269d2c0f  add rsp, 0x30
000075d5269d2c13  vmovaps xmm0, [rsp]
000075d5269d2c18  vmovaps xmm1, [rsp+0x10]
000075d5269d2c1e  vmovaps xmm2, [rsp+0x20]
000075d5269d2c24  vmovaps xmm3, [rsp+0x30]
000075d5269d2c2a  vmovaps xmm4, [rsp+0x40]
000075d5269d2c30  vmovaps xmm6, [rsp+0x50]
000075d5269d2c36  vmovaps xmm7, [rsp+0x60]
000075d5269d2c3c  vmovaps xmm8, [rsp+0x70]
000075d5269d2c42  vmovaps xmm9, [rsp+0x80]
000075d5269d2c4b  vmovaps xmm10, [rsp+0x90]
000075d5269d2c54  vmovaps xmm11, [rsp+0xA0]
000075d5269d2c5d  vmovaps xmm12, [rsp+0xB0]
000075d5269d2c66  vmovaps xmm13, [rsp+0xC0]
000075d5269d2c6f  vmovaps xmm14, [rsp+0xD0]
000075d5269d2c78  vmovaps xmm15, [rsp+0xE0]
000075d5269d2c81  add rsp, 0xF0
000075d5269d2c88  pop r11
000075d5269d2c8a  pop r10
000075d5269d2c8c  pop r9
000075d5269d2c8e  pop r8
000075d5269d2c90  pop rsi
000075d5269d2c91  pop rdi
000075d5269d2c92  pop rdx
000075d5269d2c93  pop rcx
000075d5269d2c94  pop rax
000075d5269d2c95  add rsp, 0x08
000075d5269d2c99  jmp 0x000075D5269CFDEC
000075d5269d2c9e  sub rsp, 0x08
000075d5269d2ca2  push rax
000075d5269d2ca3  push rcx
000075d5269d2ca4  push rdx
000075d5269d2ca5  push rdi
000075d5269d2ca6  push rsi
000075d5269d2ca7  push r8
000075d5269d2ca9  push r9
000075d5269d2cab  push r10
000075d5269d2cad  push r11
000075d5269d2caf  sub rsp, 0xF0
000075d5269d2cb6  vmovaps [rsp], xmm0
000075d5269d2cbb  vmovaps [rsp+0x10], xmm1
000075d5269d2cc1  vmovaps [rsp+0x20], xmm2
000075d5269d2cc7  vmovaps [rsp+0x30], xmm3
000075d5269d2ccd  vmovaps [rsp+0x40], xmm4
000075d5269d2cd3  vmovaps [rsp+0x50], xmm5
000075d5269d2cd9  vmovaps [rsp+0x60], xmm6
000075d5269d2cdf  vmovaps [rsp+0x70], xmm7
000075d5269d2ce5  vmovaps [rsp+0x80], xmm8
000075d5269d2cee  vmovaps [rsp+0x90], xmm9
000075d5269d2cf7  vmovaps [rsp+0xA0], xmm10
000075d5269d2d00  vmovaps [rsp+0xB0], xmm11
000075d5269d2d09  vmovaps [rsp+0xC0], xmm12
000075d5269d2d12  vmovaps [rsp+0xD0], xmm14
000075d5269d2d1b  vmovaps [rsp+0xE0], xmm15
000075d5269d2d24  sub rsp, 0x30
000075d5269d2d28  movaps [rsp], xmm13
000075d5269d2d2d  movaps [rsp+0x10], xmm10
000075d5269d2d33  movaps [rsp+0x20], xmm1
000075d5269d2d38  lea rdi, [rsp]
000075d5269d2d3c  mov esi, 0x00
000075d5269d2d41  mov rax, 0x601129E62530
000075d5269d2d4b  call rax
000075d5269d2d4d  movaps xmm13, [rsp]
000075d5269d2d52  add rsp, 0x30
000075d5269d2d56  vmovaps xmm0, [rsp]
000075d5269d2d5b  vmovaps xmm1, [rsp+0x10]
000075d5269d2d61  vmovaps xmm2, [rsp+0x20]
000075d5269d2d67  vmovaps xmm3, [rsp+0x30]
000075d5269d2d6d  vmovaps xmm4, [rsp+0x40]
000075d5269d2d73  vmovaps xmm5, [rsp+0x50]
000075d5269d2d79  vmovaps xmm6, [rsp+0x60]
000075d5269d2d7f  vmovaps xmm7, [rsp+0x70]
000075d5269d2d85  vmovaps xmm8, [rsp+0x80]
000075d5269d2d8e  vmovaps xmm9, [rsp+0x90]
000075d5269d2d97  vmovaps xmm10, [rsp+0xA0]
000075d5269d2da0  vmovaps xmm11, [rsp+0xB0]
000075d5269d2da9  vmovaps xmm12, [rsp+0xC0]
000075d5269d2db2  vmovaps xmm14, [rsp+0xD0]
000075d5269d2dbb  vmovaps xmm15, [rsp+0xE0]
000075d5269d2dc4  add rsp, 0xF0
000075d5269d2dcb  pop r11
000075d5269d2dcd  pop r10
000075d5269d2dcf  pop r9
000075d5269d2dd1  pop r8
000075d5269d2dd3  pop rsi
000075d5269d2dd4  pop rdi
000075d5269d2dd5  pop rdx
000075d5269d2dd6  pop rcx
000075d5269d2dd7  pop rax
000075d5269d2dd8  add rsp, 0x08
000075d5269d2ddc  jmp 0x000075D5269CFE15
000075d5269d2de1  sub rsp, 0x08
000075d5269d2de5  push rax
000075d5269d2de6  push rcx
000075d5269d2de7  push rdx
000075d5269d2de8  push rdi
000075d5269d2de9  push rsi
000075d5269d2dea  push r8
000075d5269d2dec  push r9
000075d5269d2dee  push r10
000075d5269d2df0  push r11
000075d5269d2df2  sub rsp, 0xF0
000075d5269d2df9  vmovaps [rsp], xmm0
000075d5269d2dfe  vmovaps [rsp+0x10], xmm2
000075d5269d2e04  vmovaps [rsp+0x20], xmm3
000075d5269d2e0a  vmovaps [rsp+0x30], xmm4
000075d5269d2e10  vmovaps [rsp+0x40], xmm5
000075d5269d2e16  vmovaps [rsp+0x50], xmm6
000075d5269d2e1c  vmovaps [rsp+0x60], xmm7
000075d5269d2e22  vmovaps [rsp+0x70], xmm8
000075d5269d2e28  vmovaps [rsp+0x80], xmm9
000075d5269d2e31  vmovaps [rsp+0x90], xmm10
000075d5269d2e3a  vmovaps [rsp+0xA0], xmm11
000075d5269d2e43  vmovaps [rsp+0xB0], xmm12
000075d5269d2e4c  vmovaps [rsp+0xC0], xmm13
000075d5269d2e55  vmovaps [rsp+0xD0], xmm14
000075d5269d2e5e  vmovaps [rsp+0xE0], xmm15
000075d5269d2e67  sub rsp, 0x30
000075d5269d2e6b  movaps [rsp], xmm1
000075d5269d2e6f  movaps [rsp+0x10], xmm15
000075d5269d2e75  movaps [rsp+0x20], xmm10
000075d5269d2e7b  lea rdi, [rsp]
000075d5269d2e7f  mov esi, 0x00
000075d5269d2e84  mov rax, 0x601129E62530
000075d5269d2e8e  call rax
000075d5269d2e90  movaps xmm1, [rsp]
000075d5269d2e94  add rsp, 0x30
000075d5269d2e98  vmovaps xmm0, [rsp]
000075d5269d2e9d  vmovaps xmm2, [rsp+0x10]
000075d5269d2ea3  vmovaps xmm3, [rsp+0x20]
000075d5269d2ea9  vmovaps xmm4, [rsp+0x30]
000075d5269d2eaf  vmovaps xmm5, [rsp+0x40]
000075d5269d2eb5  vmovaps xmm6, [rsp+0x50]
000075d5269d2ebb  vmovaps xmm7, [rsp+0x60]
000075d5269d2ec1  vmovaps xmm8, [rsp+0x70]
000075d5269d2ec7  vmovaps xmm9, [rsp+0x80]
000075d5269d2ed0  vmovaps xmm10, [rsp+0x90]
000075d5269d2ed9  vmovaps xmm11, [rsp+0xA0]
000075d5269d2ee2  vmovaps xmm12, [rsp+0xB0]
000075d5269d2eeb  vmovaps xmm13, [rsp+0xC0]
000075d5269d2ef4  vmovaps xmm14, [rsp+0xD0]
000075d5269d2efd  vmovaps xmm15, [rsp+0xE0]
000075d5269d2f06  add rsp, 0xF0
000075d5269d2f0d  pop r11
000075d5269d2f0f  pop r10
000075d5269d2f11  pop r9
000075d5269d2f13  pop r8
000075d5269d2f15  pop rsi
000075d5269d2f16  pop rdi
000075d5269d2f17  pop rdx
000075d5269d2f18  pop rcx
000075d5269d2f19  pop rax
000075d5269d2f1a  add rsp, 0x08
000075d5269d2f1e  jmp 0x000075D5269CFE34
000075d5269d2f23  sub rsp, 0x08
000075d5269d2f27  push rax
000075d5269d2f28  push rcx
000075d5269d2f29  push rdx
000075d5269d2f2a  push rdi
000075d5269d2f2b  push rsi
000075d5269d2f2c  push r8
000075d5269d2f2e  push r9
000075d5269d2f30  push r10
000075d5269d2f32  push r11
000075d5269d2f34  sub rsp, 0xF0
000075d5269d2f3b  vmovaps [rsp], xmm0
000075d5269d2f40  vmovaps [rsp+0x10], xmm1
000075d5269d2f46  vmovaps [rsp+0x20], xmm2
000075d5269d2f4c  vmovaps [rsp+0x30], xmm3
000075d5269d2f52  vmovaps [rsp+0x40], xmm4
000075d5269d2f58  vmovaps [rsp+0x50], xmm5
000075d5269d2f5e  vmovaps [rsp+0x60], xmm6
000075d5269d2f64  vmovaps [rsp+0x70], xmm7
000075d5269d2f6a  vmovaps [rsp+0x80], xmm8
000075d5269d2f73  vmovaps [rsp+0x90], xmm9
000075d5269d2f7c  vmovaps [rsp+0xA0], xmm10
000075d5269d2f85  vmovaps [rsp+0xB0], xmm11
000075d5269d2f8e  vmovaps [rsp+0xC0], xmm12
000075d5269d2f97  vmovaps [rsp+0xD0], xmm13
000075d5269d2fa0  vmovaps [rsp+0xE0], xmm14
000075d5269d2fa9  sub rsp, 0x30
000075d5269d2fad  movaps [rsp], xmm15
000075d5269d2fb2  movaps [rsp+0x10], xmm10
000075d5269d2fb8  movaps [rsp+0x20], xmm11
000075d5269d2fbe  lea rdi, [rsp]
000075d5269d2fc2  mov esi, 0x00
000075d5269d2fc7  mov rax, 0x601129E62530
000075d5269d2fd1  call rax
000075d5269d2fd3  movaps xmm15, [rsp]
000075d5269d2fd8  add rsp, 0x30
000075d5269d2fdc  vmovaps xmm0, [rsp]
000075d5269d2fe1  vmovaps xmm1, [rsp+0x10]
000075d5269d2fe7  vmovaps xmm2, [rsp+0x20]
000075d5269d2fed  vmovaps xmm3, [rsp+0x30]
000075d5269d2ff3  vmovaps xmm4, [rsp+0x40]
000075d5269d2ff9  vmovaps xmm5, [rsp+0x50]
000075d5269d2fff  vmovaps xmm6, [rsp+0x60]
000075d5269d3005  vmovaps xmm7, [rsp+0x70]
000075d5269d300b  vmovaps xmm8, [rsp+0x80]
000075d5269d3014  vmovaps xmm9, [rsp+0x90]
000075d5269d301d  vmovaps xmm10, [rsp+0xA0]
000075d5269d3026  vmovaps xmm11, [rsp+0xB0]
000075d5269d302f  vmovaps xmm12, [rsp+0xC0]
000075d5269d3038  vmovaps xmm13, [rsp+0xD0]
000075d5269d3041  vmovaps xmm14, [rsp+0xE0]
000075d5269d304a  add rsp, 0xF0
000075d5269d3051  pop r11
000075d5269d3053  pop r10
000075d5269d3055  pop r9
000075d5269d3057  pop r8
000075d5269d3059  pop rsi
000075d5269d305a  pop rdi
000075d5269d305b  pop rdx
000075d5269d305c  pop rcx
000075d5269d305d  pop rax
000075d5269d305e  add rsp, 0x08
000075d5269d3062  jmp 0x000075D5269CFE57
000075d5269d3067  sub rsp, 0x08
000075d5269d306b  push rax
000075d5269d306c  push rcx
000075d5269d306d  push rdx
000075d5269d306e  push rdi
000075d5269d306f  push rsi
000075d5269d3070  push r8
000075d5269d3072  push r9
000075d5269d3074  push r10
000075d5269d3076  push r11
000075d5269d3078  sub rsp, 0xF0
000075d5269d307f  vmovaps [rsp], xmm0
000075d5269d3084  vmovaps [rsp+0x10], xmm1
000075d5269d308a  vmovaps [rsp+0x20], xmm2
000075d5269d3090  vmovaps [rsp+0x30], xmm3
000075d5269d3096  vmovaps [rsp+0x40], xmm4
000075d5269d309c  vmovaps [rsp+0x50], xmm5
000075d5269d30a2  vmovaps [rsp+0x60], xmm6
000075d5269d30a8  vmovaps [rsp+0x70], xmm7
000075d5269d30ae  vmovaps [rsp+0x80], xmm8
000075d5269d30b7  vmovaps [rsp+0x90], xmm9
000075d5269d30c0  vmovaps [rsp+0xA0], xmm11
000075d5269d30c9  vmovaps [rsp+0xB0], xmm12
000075d5269d30d2  vmovaps [rsp+0xC0], xmm13
000075d5269d30db  vmovaps [rsp+0xD0], xmm14
000075d5269d30e4  vmovaps [rsp+0xE0], xmm15
000075d5269d30ed  sub rsp, 0x30
000075d5269d30f1  movaps [rsp], xmm10
000075d5269d30f6  movaps [rsp+0x10], xmm12
000075d5269d30fc  movaps [rsp+0x20], xmm11
000075d5269d3102  lea rdi, [rsp]
000075d5269d3106  mov esi, 0x00
000075d5269d310b  mov rax, 0x601129E62530
000075d5269d3115  call rax
000075d5269d3117  movaps xmm10, [rsp]
000075d5269d311c  add rsp, 0x30
000075d5269d3120  vmovaps xmm0, [rsp]
000075d5269d3125  vmovaps xmm1, [rsp+0x10]
000075d5269d312b  vmovaps xmm2, [rsp+0x20]
000075d5269d3131  vmovaps xmm3, [rsp+0x30]
000075d5269d3137  vmovaps xmm4, [rsp+0x40]
000075d5269d313d  vmovaps xmm5, [rsp+0x50]
000075d5269d3143  vmovaps xmm6, [rsp+0x60]
000075d5269d3149  vmovaps xmm7, [rsp+0x70]
000075d5269d314f  vmovaps xmm8, [rsp+0x80]
000075d5269d3158  vmovaps xmm9, [rsp+0x90]
000075d5269d3161  vmovaps xmm11, [rsp+0xA0]
000075d5269d316a  vmovaps xmm12, [rsp+0xB0]
000075d5269d3173  vmovaps xmm13, [rsp+0xC0]
000075d5269d317c  vmovaps xmm14, [rsp+0xD0]
000075d5269d3185  vmovaps xmm15, [rsp+0xE0]
000075d5269d318e  add rsp, 0xF0
000075d5269d3195  pop r11
000075d5269d3197  pop r10
000075d5269d3199  pop r9
000075d5269d319b  pop r8
000075d5269d319d  pop rsi
000075d5269d319e  pop rdi
000075d5269d319f  pop rdx
000075d5269d31a0  pop rcx
000075d5269d31a1  pop rax
000075d5269d31a2  add rsp, 0x08
000075d5269d31a6  jmp 0x000075D5269CFE80
000075d5269d31ab  sub rsp, 0x08
000075d5269d31af  push rax
000075d5269d31b0  push rcx
000075d5269d31b1  push rdx
000075d5269d31b2  push rdi
000075d5269d31b3  push rsi
000075d5269d31b4  push r8
000075d5269d31b6  push r9
000075d5269d31b8  push r10
000075d5269d31ba  push r11
000075d5269d31bc  sub rsp, 0xF0
000075d5269d31c3  vmovaps [rsp], xmm0
000075d5269d31c8  vmovaps [rsp+0x10], xmm1
000075d5269d31ce  vmovaps [rsp+0x20], xmm2
000075d5269d31d4  vmovaps [rsp+0x30], xmm3
000075d5269d31da  vmovaps [rsp+0x40], xmm4
000075d5269d31e0  vmovaps [rsp+0x50], xmm5
000075d5269d31e6  vmovaps [rsp+0x60], xmm6
000075d5269d31ec  vmovaps [rsp+0x70], xmm7
000075d5269d31f2  vmovaps [rsp+0x80], xmm8
000075d5269d31fb  vmovaps [rsp+0x90], xmm9
000075d5269d3204  vmovaps [rsp+0xA0], xmm10
000075d5269d320d  vmovaps [rsp+0xB0], xmm12
000075d5269d3216  vmovaps [rsp+0xC0], xmm13
000075d5269d321f  vmovaps [rsp+0xD0], xmm14
000075d5269d3228  vmovaps [rsp+0xE0], xmm15
000075d5269d3231  sub rsp, 0x30
000075d5269d3235  movaps [rsp], xmm11
000075d5269d323a  movaps [rsp+0x10], xmm2
000075d5269d323f  movaps [rsp+0x20], xmm12
000075d5269d3245  lea rdi, [rsp]
000075d5269d3249  mov esi, 0x00
000075d5269d324e  mov rax, 0x601129E62530
000075d5269d3258  call rax
000075d5269d325a  movaps xmm11, [rsp]
000075d5269d325f  add rsp, 0x30
000075d5269d3263  vmovaps xmm0, [rsp]
000075d5269d3268  vmovaps xmm1, [rsp+0x10]
000075d5269d326e  vmovaps xmm2, [rsp+0x20]
000075d5269d3274  vmovaps xmm3, [rsp+0x30]
000075d5269d327a  vmovaps xmm4, [rsp+0x40]
000075d5269d3280  vmovaps xmm5, [rsp+0x50]
000075d5269d3286  vmovaps xmm6, [rsp+0x60]
000075d5269d328c  vmovaps xmm7, [rsp+0x70]
000075d5269d3292  vmovaps xmm8, [rsp+0x80]
000075d5269d329b  vmovaps xmm9, [rsp+0x90]
000075d5269d32a4  vmovaps xmm10, [rsp+0xA0]
000075d5269d32ad  vmovaps xmm12, [rsp+0xB0]
000075d5269d32b6  vmovaps xmm13, [rsp+0xC0]
000075d5269d32bf  vmovaps xmm14, [rsp+0xD0]
000075d5269d32c8  vmovaps xmm15, [rsp+0xE0]
000075d5269d32d1  add rsp, 0xF0
000075d5269d32d8  pop r11
000075d5269d32da  pop r10
000075d5269d32dc  pop r9
000075d5269d32de  pop r8
000075d5269d32e0  pop rsi
000075d5269d32e1  pop rdi
000075d5269d32e2  pop rdx
000075d5269d32e3  pop rcx
000075d5269d32e4  pop rax
000075d5269d32e5  add rsp, 0x08
000075d5269d32e9  jmp 0x000075D5269CFEB8
000075d5269d32ee  sub rsp, 0x08
000075d5269d32f2  push rax
000075d5269d32f3  push rcx
000075d5269d32f4  push rdx
000075d5269d32f5  push rdi
000075d5269d32f6  push rsi
000075d5269d32f7  push r8
000075d5269d32f9  push r9
000075d5269d32fb  push r10
000075d5269d32fd  push r11
000075d5269d32ff  sub rsp, 0xF0
000075d5269d3306  vmovaps [rsp], xmm0
000075d5269d330b  vmovaps [rsp+0x10], xmm2
000075d5269d3311  vmovaps [rsp+0x20], xmm3
000075d5269d3317  vmovaps [rsp+0x30], xmm4
000075d5269d331d  vmovaps [rsp+0x40], xmm5
000075d5269d3323  vmovaps [rsp+0x50], xmm6
000075d5269d3329  vmovaps [rsp+0x60], xmm7
000075d5269d332f  vmovaps [rsp+0x70], xmm8
000075d5269d3335  vmovaps [rsp+0x80], xmm9
000075d5269d333e  vmovaps [rsp+0x90], xmm10
000075d5269d3347  vmovaps [rsp+0xA0], xmm11
000075d5269d3350  vmovaps [rsp+0xB0], xmm12
000075d5269d3359  vmovaps [rsp+0xC0], xmm13
000075d5269d3362  vmovaps [rsp+0xD0], xmm14
000075d5269d336b  vmovaps [rsp+0xE0], xmm15
000075d5269d3374  sub rsp, 0x30
000075d5269d3378  movaps [rsp], xmm1
000075d5269d337c  movaps [rsp+0x10], xmm14
000075d5269d3382  movaps [rsp+0x20], xmm6
000075d5269d3387  lea rdi, [rsp]
000075d5269d338b  mov esi, 0x00
000075d5269d3390  mov rax, 0x601129E62530
000075d5269d339a  call rax
000075d5269d339c  movaps xmm1, [rsp]
000075d5269d33a0  add rsp, 0x30
000075d5269d33a4  vmovaps xmm0, [rsp]
000075d5269d33a9  vmovaps xmm2, [rsp+0x10]
000075d5269d33af  vmovaps xmm3, [rsp+0x20]
000075d5269d33b5  vmovaps xmm4, [rsp+0x30]
000075d5269d33bb  vmovaps xmm5, [rsp+0x40]
000075d5269d33c1  vmovaps xmm6, [rsp+0x50]
000075d5269d33c7  vmovaps xmm7, [rsp+0x60]
000075d5269d33cd  vmovaps xmm8, [rsp+0x70]
000075d5269d33d3  vmovaps xmm9, [rsp+0x80]
000075d5269d33dc  vmovaps xmm10, [rsp+0x90]
000075d5269d33e5  vmovaps xmm11, [rsp+0xA0]
000075d5269d33ee  vmovaps xmm12, [rsp+0xB0]
000075d5269d33f7  vmovaps xmm13, [rsp+0xC0]
000075d5269d3400  vmovaps xmm14, [rsp+0xD0]
000075d5269d3409  vmovaps xmm15, [rsp+0xE0]
000075d5269d3412  add rsp, 0xF0
000075d5269d3419  pop r11
000075d5269d341b  pop r10
000075d5269d341d  pop r9
000075d5269d341f  pop r8
000075d5269d3421  pop rsi
000075d5269d3422  pop rdi
000075d5269d3423  pop rdx
000075d5269d3424  pop rcx
000075d5269d3425  pop rax
000075d5269d3426  add rsp, 0x08
000075d5269d342a  jmp 0x000075D5269CFED1
000075d5269d342f  sub rsp, 0x08
000075d5269d3433  push rax
000075d5269d3434  push rcx
000075d5269d3435  push rdx
000075d5269d3436  push rdi
000075d5269d3437  push rsi
000075d5269d3438  push r8
000075d5269d343a  push r9
000075d5269d343c  push r10
000075d5269d343e  push r11
000075d5269d3440  sub rsp, 0xF0
000075d5269d3447  vmovaps [rsp], xmm0
000075d5269d344c  vmovaps [rsp+0x10], xmm1
000075d5269d3452  vmovaps [rsp+0x20], xmm2
000075d5269d3458  vmovaps [rsp+0x30], xmm3
000075d5269d345e  vmovaps [rsp+0x40], xmm4
000075d5269d3464  vmovaps [rsp+0x50], xmm5
000075d5269d346a  vmovaps [rsp+0x60], xmm6
000075d5269d3470  vmovaps [rsp+0x70], xmm7
000075d5269d3476  vmovaps [rsp+0x80], xmm8
000075d5269d347f  vmovaps [rsp+0x90], xmm9
000075d5269d3488  vmovaps [rsp+0xA0], xmm10
000075d5269d3491  vmovaps [rsp+0xB0], xmm11
000075d5269d349a  vmovaps [rsp+0xC0], xmm12
000075d5269d34a3  vmovaps [rsp+0xD0], xmm13
000075d5269d34ac  vmovaps [rsp+0xE0], xmm15
000075d5269d34b5  sub rsp, 0x30
000075d5269d34b9  movaps [rsp], xmm14
000075d5269d34be  movaps [rsp+0x10], xmm12
000075d5269d34c4  movaps [rsp+0x20], xmm5
000075d5269d34c9  lea rdi, [rsp]
000075d5269d34cd  mov esi, 0x00
000075d5269d34d2  mov rax, 0x601129E62530
000075d5269d34dc  call rax
000075d5269d34de  movaps xmm14, [rsp]
000075d5269d34e3  add rsp, 0x30
000075d5269d34e7  vmovaps xmm0, [rsp]
000075d5269d34ec  vmovaps xmm1, [rsp+0x10]
000075d5269d34f2  vmovaps xmm2, [rsp+0x20]
000075d5269d34f8  vmovaps xmm3, [rsp+0x30]
000075d5269d34fe  vmovaps xmm4, [rsp+0x40]
000075d5269d3504  vmovaps xmm5, [rsp+0x50]
000075d5269d350a  vmovaps xmm6, [rsp+0x60]
000075d5269d3510  vmovaps xmm7, [rsp+0x70]
000075d5269d3516  vmovaps xmm8, [rsp+0x80]
000075d5269d351f  vmovaps xmm9, [rsp+0x90]
000075d5269d3528  vmovaps xmm10, [rsp+0xA0]
000075d5269d3531  vmovaps xmm11, [rsp+0xB0]
000075d5269d353a  vmovaps xmm12, [rsp+0xC0]
000075d5269d3543  vmovaps xmm13, [rsp+0xD0]
000075d5269d354c  vmovaps xmm15, [rsp+0xE0]
000075d5269d3555  add rsp, 0xF0
000075d5269d355c  pop r11
000075d5269d355e  pop r10
000075d5269d3560  pop r9
000075d5269d3562  pop r8
000075d5269d3564  pop rsi
000075d5269d3565  pop rdi
000075d5269d3566  pop rdx
000075d5269d3567  pop rcx
000075d5269d3568  pop rax
000075d5269d3569  add rsp, 0x08
000075d5269d356d  jmp 0x000075D5269CFEF1
000075d5269d3572  sub rsp, 0x08
000075d5269d3576  push rax
000075d5269d3577  push rcx
000075d5269d3578  push rdx
000075d5269d3579  push rdi
000075d5269d357a  push rsi
000075d5269d357b  push r8
000075d5269d357d  push r9
000075d5269d357f  push r10
000075d5269d3581  push r11
000075d5269d3583  sub rsp, 0xF0
000075d5269d358a  vmovaps [rsp], xmm0
000075d5269d358f  vmovaps [rsp+0x10], xmm1
000075d5269d3595  vmovaps [rsp+0x20], xmm2
000075d5269d359b  vmovaps [rsp+0x30], xmm3
000075d5269d35a1  vmovaps [rsp+0x40], xmm4
000075d5269d35a7  vmovaps [rsp+0x50], xmm5
000075d5269d35ad  vmovaps [rsp+0x60], xmm7
000075d5269d35b3  vmovaps [rsp+0x70], xmm8
000075d5269d35b9  vmovaps [rsp+0x80], xmm9
000075d5269d35c2  vmovaps [rsp+0x90], xmm10
000075d5269d35cb  vmovaps [rsp+0xA0], xmm11
000075d5269d35d4  vmovaps [rsp+0xB0], xmm12
000075d5269d35dd  vmovaps [rsp+0xC0], xmm13
000075d5269d35e6  vmovaps [rsp+0xD0], xmm14
000075d5269d35ef  vmovaps [rsp+0xE0], xmm15
000075d5269d35f8  sub rsp, 0x30
000075d5269d35fc  movaps [rsp], xmm6
000075d5269d3600  movaps [rsp+0x10], xmm9
000075d5269d3606  movaps [rsp+0x20], xmm12
000075d5269d360c  lea rdi, [rsp]
000075d5269d3610  mov esi, 0x00
000075d5269d3615  mov rax, 0x601129E62530
000075d5269d361f  call rax
000075d5269d3621  movaps xmm6, [rsp]
000075d5269d3625  add rsp, 0x30
000075d5269d3629  vmovaps xmm0, [rsp]
000075d5269d362e  vmovaps xmm1, [rsp+0x10]
000075d5269d3634  vmovaps xmm2, [rsp+0x20]
000075d5269d363a  vmovaps xmm3, [rsp+0x30]
000075d5269d3640  vmovaps xmm4, [rsp+0x40]
000075d5269d3646  vmovaps xmm5, [rsp+0x50]
000075d5269d364c  vmovaps xmm7, [rsp+0x60]
000075d5269d3652  vmovaps xmm8, [rsp+0x70]
000075d5269d3658  vmovaps xmm9, [rsp+0x80]
000075d5269d3661  vmovaps xmm10, [rsp+0x90]
000075d5269d366a  vmovaps xmm11, [rsp+0xA0]
000075d5269d3673  vmovaps xmm12, [rsp+0xB0]
000075d5269d367c  vmovaps xmm13, [rsp+0xC0]
000075d5269d3685  vmovaps xmm14, [rsp+0xD0]
000075d5269d368e  vmovaps xmm15, [rsp+0xE0]
000075d5269d3697  add rsp, 0xF0
000075d5269d369e  pop r11
000075d5269d36a0  pop r10
000075d5269d36a2  pop r9
000075d5269d36a4  pop r8
000075d5269d36a6  pop rsi
000075d5269d36a7  pop rdi
000075d5269d36a8  pop rdx
000075d5269d36a9  pop rcx
000075d5269d36aa  pop rax
000075d5269d36ab  add rsp, 0x08
000075d5269d36af  jmp 0x000075D5269CFF19
000075d5269d36b4  sub rsp, 0x08
000075d5269d36b8  push rax
000075d5269d36b9  push rcx
000075d5269d36ba  push rdx
000075d5269d36bb  push rdi
000075d5269d36bc  push rsi
000075d5269d36bd  push r8
000075d5269d36bf  push r9
000075d5269d36c1  push r10
000075d5269d36c3  push r11
000075d5269d36c5  sub rsp, 0xF0
000075d5269d36cc  vmovaps [rsp], xmm0
000075d5269d36d1  vmovaps [rsp+0x10], xmm1
000075d5269d36d7  vmovaps [rsp+0x20], xmm2
000075d5269d36dd  vmovaps [rsp+0x30], xmm3
000075d5269d36e3  vmovaps [rsp+0x40], xmm4
000075d5269d36e9  vmovaps [rsp+0x50], xmm5
000075d5269d36ef  vmovaps [rsp+0x60], xmm6
000075d5269d36f5  vmovaps [rsp+0x70], xmm7
000075d5269d36fb  vmovaps [rsp+0x80], xmm8
000075d5269d3704  vmovaps [rsp+0x90], xmm9
000075d5269d370d  vmovaps [rsp+0xA0], xmm10
000075d5269d3716  vmovaps [rsp+0xB0], xmm11
000075d5269d371f  vmovaps [rsp+0xC0], xmm13
000075d5269d3728  vmovaps [rsp+0xD0], xmm14
000075d5269d3731  vmovaps [rsp+0xE0], xmm15
000075d5269d373a  sub rsp, 0x30
000075d5269d373e  movaps [rsp], xmm12
000075d5269d3743  movaps [rsp+0x10], xmm15
000075d5269d3749  movaps [rsp+0x20], xmm13
000075d5269d374f  lea rdi, [rsp]
000075d5269d3753  mov esi, 0x00
000075d5269d3758  mov rax, 0x601129E62530
000075d5269d3762  call rax
000075d5269d3764  movaps xmm12, [rsp]
000075d5269d3769  add rsp, 0x30
000075d5269d376d  vmovaps xmm0, [rsp]
000075d5269d3772  vmovaps xmm1, [rsp+0x10]
000075d5269d3778  vmovaps xmm2, [rsp+0x20]
000075d5269d377e  vmovaps xmm3, [rsp+0x30]
000075d5269d3784  vmovaps xmm4, [rsp+0x40]
000075d5269d378a  vmovaps xmm5, [rsp+0x50]
000075d5269d3790  vmovaps xmm6, [rsp+0x60]
000075d5269d3796  vmovaps xmm7, [rsp+0x70]
000075d5269d379c  vmovaps xmm8, [rsp+0x80]
000075d5269d37a5  vmovaps xmm9, [rsp+0x90]
000075d5269d37ae  vmovaps xmm10, [rsp+0xA0]
000075d5269d37b7  vmovaps xmm11, [rsp+0xB0]
000075d5269d37c0  vmovaps xmm13, [rsp+0xC0]
000075d5269d37c9  vmovaps xmm14, [rsp+0xD0]
000075d5269d37d2  vmovaps xmm15, [rsp+0xE0]
000075d5269d37db  add rsp, 0xF0
000075d5269d37e2  pop r11
000075d5269d37e4  pop r10
000075d5269d37e6  pop r9
000075d5269d37e8  pop r8
000075d5269d37ea  pop rsi
000075d5269d37eb  pop rdi
000075d5269d37ec  pop rdx
000075d5269d37ed  pop rcx
000075d5269d37ee  pop rax
000075d5269d37ef  add rsp, 0x08
000075d5269d37f3  jmp 0x000075D5269CFF34
000075d5269d37f8  sub rsp, 0x08
000075d5269d37fc  push rax
000075d5269d37fd  push rcx
000075d5269d37fe  push rdx
000075d5269d37ff  push rdi
000075d5269d3800  push rsi
000075d5269d3801  push r8
000075d5269d3803  push r9
000075d5269d3805  push r10
000075d5269d3807  push r11
000075d5269d3809  sub rsp, 0xF0
000075d5269d3810  vmovaps [rsp], xmm0
000075d5269d3815  vmovaps [rsp+0x10], xmm1
000075d5269d381b  vmovaps [rsp+0x20], xmm2
000075d5269d3821  vmovaps [rsp+0x30], xmm3
000075d5269d3827  vmovaps [rsp+0x40], xmm4
000075d5269d382d  vmovaps [rsp+0x50], xmm5
000075d5269d3833  vmovaps [rsp+0x60], xmm6
000075d5269d3839  vmovaps [rsp+0x70], xmm7
000075d5269d383f  vmovaps [rsp+0x80], xmm8
000075d5269d3848  vmovaps [rsp+0x90], xmm9
000075d5269d3851  vmovaps [rsp+0xA0], xmm10
000075d5269d385a  vmovaps [rsp+0xB0], xmm11
000075d5269d3863  vmovaps [rsp+0xC0], xmm12
000075d5269d386c  vmovaps [rsp+0xD0], xmm13
000075d5269d3875  vmovaps [rsp+0xE0], xmm14
000075d5269d387e  sub rsp, 0x30
000075d5269d3882  movaps [rsp], xmm15
000075d5269d3887  movaps [rsp+0x10], xmm13
000075d5269d388d  movaps [rsp+0x20], xmm10
000075d5269d3893  lea rdi, [rsp]
000075d5269d3897  mov esi, 0x00
000075d5269d389c  mov rax, 0x601129E62530
000075d5269d38a6  call rax
000075d5269d38a8  movaps xmm15, [rsp]
000075d5269d38ad  add rsp, 0x30
000075d5269d38b1  vmovaps xmm0, [rsp]
000075d5269d38b6  vmovaps xmm1, [rsp+0x10]
000075d5269d38bc  vmovaps xmm2, [rsp+0x20]
000075d5269d38c2  vmovaps xmm3, [rsp+0x30]
000075d5269d38c8  vmovaps xmm4, [rsp+0x40]
000075d5269d38ce  vmovaps xmm5, [rsp+0x50]
000075d5269d38d4  vmovaps xmm6, [rsp+0x60]
000075d5269d38da  vmovaps xmm7, [rsp+0x70]
000075d5269d38e0  vmovaps xmm8, [rsp+0x80]
000075d5269d38e9  vmovaps xmm9, [rsp+0x90]
000075d5269d38f2  vmovaps xmm10, [rsp+0xA0]
000075d5269d38fb  vmovaps xmm11, [rsp+0xB0]
000075d5269d3904  vmovaps xmm12, [rsp+0xC0]
000075d5269d390d  vmovaps xmm13, [rsp+0xD0]
000075d5269d3916  vmovaps xmm14, [rsp+0xE0]
000075d5269d391f  add rsp, 0xF0
000075d5269d3926  pop r11
000075d5269d3928  pop r10
000075d5269d392a  pop r9
000075d5269d392c  pop r8
000075d5269d392e  pop rsi
000075d5269d392f  pop rdi
000075d5269d3930  pop rdx
000075d5269d3931  pop rcx
000075d5269d3932  pop rax
000075d5269d3933  add rsp, 0x08
000075d5269d3937  jmp 0x000075D5269CFF55
000075d5269d393c  call 0x000075D52680C260
000075d5269d3941  jmp 0x000075D5269CFFB0
000075d5269d3946  sub rsp, 0x08
000075d5269d394a  push rax
000075d5269d394b  push rcx
000075d5269d394c  push rdx
000075d5269d394d  push rdi
000075d5269d394e  push rsi
000075d5269d394f  push r8
000075d5269d3951  push r9
000075d5269d3953  push r10
000075d5269d3955  push r11
000075d5269d3957  sub rsp, 0xF0
000075d5269d395e  vmovaps [rsp], xmm0
000075d5269d3963  vmovaps [rsp+0x10], xmm1
000075d5269d3969  vmovaps [rsp+0x20], xmm2
000075d5269d396f  vmovaps [rsp+0x30], xmm3
000075d5269d3975  vmovaps [rsp+0x40], xmm4
000075d5269d397b  vmovaps [rsp+0x50], xmm5
000075d5269d3981  vmovaps [rsp+0x60], xmm6
000075d5269d3987  vmovaps [rsp+0x70], xmm7
000075d5269d398d  vmovaps [rsp+0x80], xmm8
000075d5269d3996  vmovaps [rsp+0x90], xmm10
000075d5269d399f  vmovaps [rsp+0xA0], xmm11
000075d5269d39a8  vmovaps [rsp+0xB0], xmm12
000075d5269d39b1  vmovaps [rsp+0xC0], xmm13
000075d5269d39ba  vmovaps [rsp+0xD0], xmm14
000075d5269d39c3  vmovaps [rsp+0xE0], xmm15
000075d5269d39cc  sub rsp, 0x30
000075d5269d39d0  movaps [rsp], xmm9
000075d5269d39d5  movaps [rsp+0x10], xmm8
000075d5269d39db  movaps [rsp+0x20], xmm10
000075d5269d39e1  lea rdi, [rsp]
000075d5269d39e5  mov esi, 0x00
000075d5269d39ea  mov rax, 0x601129E62530
000075d5269d39f4  call rax
000075d5269d39f6  movaps xmm9, [rsp]
000075d5269d39fb  add rsp, 0x30
000075d5269d39ff  vmovaps xmm0, [rsp]
000075d5269d3a04  vmovaps xmm1, [rsp+0x10]
000075d5269d3a0a  vmovaps xmm2, [rsp+0x20]
000075d5269d3a10  vmovaps xmm3, [rsp+0x30]
000075d5269d3a16  vmovaps xmm4, [rsp+0x40]
000075d5269d3a1c  vmovaps xmm5, [rsp+0x50]
000075d5269d3a22  vmovaps xmm6, [rsp+0x60]
000075d5269d3a28  vmovaps xmm7, [rsp+0x70]
000075d5269d3a2e  vmovaps xmm8, [rsp+0x80]
000075d5269d3a37  vmovaps xmm10, [rsp+0x90]
000075d5269d3a40  vmovaps xmm11, [rsp+0xA0]
000075d5269d3a49  vmovaps xmm12, [rsp+0xB0]
000075d5269d3a52  vmovaps xmm13, [rsp+0xC0]
000075d5269d3a5b  vmovaps xmm14, [rsp+0xD0]
000075d5269d3a64  vmovaps xmm15, [rsp+0xE0]
000075d5269d3a6d  add rsp, 0xF0
000075d5269d3a74  pop r11
000075d5269d3a76  pop r10
000075d5269d3a78  pop r9
000075d5269d3a7a  pop r8
000075d5269d3a7c  pop rsi
000075d5269d3a7d  pop rdi
000075d5269d3a7e  pop rdx
000075d5269d3a7f  pop rcx
000075d5269d3a80  pop rax
000075d5269d3a81  add rsp, 0x08
000075d5269d3a85  jmp 0x000075D5269CFFE1
000075d5269d3a8a  sub rsp, 0x08
000075d5269d3a8e  push rax
000075d5269d3a8f  push rcx
000075d5269d3a90  push rdx
000075d5269d3a91  push rdi
000075d5269d3a92  push rsi
000075d5269d3a93  push r8
000075d5269d3a95  push r9
000075d5269d3a97  push r10
000075d5269d3a99  push r11
000075d5269d3a9b  sub rsp, 0xF0
000075d5269d3aa2  vmovaps [rsp], xmm0
000075d5269d3aa7  vmovaps [rsp+0x10], xmm1
000075d5269d3aad  vmovaps [rsp+0x20], xmm2
000075d5269d3ab3  vmovaps [rsp+0x30], xmm3
000075d5269d3ab9  vmovaps [rsp+0x40], xmm4
000075d5269d3abf  vmovaps [rsp+0x50], xmm5
000075d5269d3ac5  vmovaps [rsp+0x60], xmm6
000075d5269d3acb  vmovaps [rsp+0x70], xmm7
000075d5269d3ad1  vmovaps [rsp+0x80], xmm8
000075d5269d3ada  vmovaps [rsp+0x90], xmm9
000075d5269d3ae3  vmovaps [rsp+0xA0], xmm11
000075d5269d3aec  vmovaps [rsp+0xB0], xmm12
000075d5269d3af5  vmovaps [rsp+0xC0], xmm13
000075d5269d3afe  vmovaps [rsp+0xD0], xmm14
000075d5269d3b07  vmovaps [rsp+0xE0], xmm15
000075d5269d3b10  sub rsp, 0x30
000075d5269d3b14  movaps [rsp], xmm10
000075d5269d3b19  movaps [rsp+0x10], xmm1
000075d5269d3b1e  movaps [rsp+0x20], xmm11
000075d5269d3b24  lea rdi, [rsp]
000075d5269d3b28  mov esi, 0x00
000075d5269d3b2d  mov rax, 0x601129E62530
000075d5269d3b37  call rax
000075d5269d3b39  movaps xmm10, [rsp]
000075d5269d3b3e  add rsp, 0x30
000075d5269d3b42  vmovaps xmm0, [rsp]
000075d5269d3b47  vmovaps xmm1, [rsp+0x10]
000075d5269d3b4d  vmovaps xmm2, [rsp+0x20]
000075d5269d3b53  vmovaps xmm3, [rsp+0x30]
000075d5269d3b59  vmovaps xmm4, [rsp+0x40]
000075d5269d3b5f  vmovaps xmm5, [rsp+0x50]
000075d5269d3b65  vmovaps xmm6, [rsp+0x60]
000075d5269d3b6b  vmovaps xmm7, [rsp+0x70]
000075d5269d3b71  vmovaps xmm8, [rsp+0x80]
000075d5269d3b7a  vmovaps xmm9, [rsp+0x90]
000075d5269d3b83  vmovaps xmm11, [rsp+0xA0]
000075d5269d3b8c  vmovaps xmm12, [rsp+0xB0]
000075d5269d3b95  vmovaps xmm13, [rsp+0xC0]
000075d5269d3b9e  vmovaps xmm14, [rsp+0xD0]
000075d5269d3ba7  vmovaps xmm15, [rsp+0xE0]
000075d5269d3bb0  add rsp, 0xF0
000075d5269d3bb7  pop r11
000075d5269d3bb9  pop r10
000075d5269d3bbb  pop r9
000075d5269d3bbd  pop r8
000075d5269d3bbf  pop rsi
000075d5269d3bc0  pop rdi
000075d5269d3bc1  pop rdx
000075d5269d3bc2  pop rcx
000075d5269d3bc3  pop rax
000075d5269d3bc4  add rsp, 0x08
000075d5269d3bc8  jmp 0x000075D5269CFFFC
000075d5269d3bcd  sub rsp, 0x08
000075d5269d3bd1  push rax
000075d5269d3bd2  push rcx
000075d5269d3bd3  push rdx
000075d5269d3bd4  push rdi
000075d5269d3bd5  push rsi
000075d5269d3bd6  push r8
000075d5269d3bd8  push r9
000075d5269d3bda  push r10
000075d5269d3bdc  push r11
000075d5269d3bde  sub rsp, 0xF0
000075d5269d3be5  vmovaps [rsp], xmm0
000075d5269d3bea  vmovaps [rsp+0x10], xmm2
000075d5269d3bf0  vmovaps [rsp+0x20], xmm3
000075d5269d3bf6  vmovaps [rsp+0x30], xmm4
000075d5269d3bfc  vmovaps [rsp+0x40], xmm5
000075d5269d3c02  vmovaps [rsp+0x50], xmm6
000075d5269d3c08  vmovaps [rsp+0x60], xmm7
000075d5269d3c0e  vmovaps [rsp+0x70], xmm8
000075d5269d3c14  vmovaps [rsp+0x80], xmm9
000075d5269d3c1d  vmovaps [rsp+0x90], xmm10
000075d5269d3c26  vmovaps [rsp+0xA0], xmm11
000075d5269d3c2f  vmovaps [rsp+0xB0], xmm12
000075d5269d3c38  vmovaps [rsp+0xC0], xmm13
000075d5269d3c41  vmovaps [rsp+0xD0], xmm14
000075d5269d3c4a  vmovaps [rsp+0xE0], xmm15
000075d5269d3c53  sub rsp, 0x30
000075d5269d3c57  movaps [rsp], xmm1
000075d5269d3c5b  movaps [rsp+0x10], xmm14
000075d5269d3c61  movaps [rsp+0x20], xmm6
000075d5269d3c66  lea rdi, [rsp]
000075d5269d3c6a  mov esi, 0x00
000075d5269d3c6f  mov rax, 0x601129E62530
000075d5269d3c79  call rax
000075d5269d3c7b  movaps xmm1, [rsp]
000075d5269d3c7f  add rsp, 0x30
000075d5269d3c83  vmovaps xmm0, [rsp]
000075d5269d3c88  vmovaps xmm2, [rsp+0x10]
000075d5269d3c8e  vmovaps xmm3, [rsp+0x20]
000075d5269d3c94  vmovaps xmm4, [rsp+0x30]
000075d5269d3c9a  vmovaps xmm5, [rsp+0x40]
000075d5269d3ca0  vmovaps xmm6, [rsp+0x50]
000075d5269d3ca6  vmovaps xmm7, [rsp+0x60]
000075d5269d3cac  vmovaps xmm8, [rsp+0x70]
000075d5269d3cb2  vmovaps xmm9, [rsp+0x80]
000075d5269d3cbb  vmovaps xmm10, [rsp+0x90]
000075d5269d3cc4  vmovaps xmm11, [rsp+0xA0]
000075d5269d3ccd  vmovaps xmm12, [rsp+0xB0]
000075d5269d3cd6  vmovaps xmm13, [rsp+0xC0]
000075d5269d3cdf  vmovaps xmm14, [rsp+0xD0]
000075d5269d3ce8  vmovaps xmm15, [rsp+0xE0]
000075d5269d3cf1  add rsp, 0xF0
000075d5269d3cf8  pop r11
000075d5269d3cfa  pop r10
000075d5269d3cfc  pop r9
000075d5269d3cfe  pop r8
000075d5269d3d00  pop rsi
000075d5269d3d01  pop rdi
000075d5269d3d02  pop rdx
000075d5269d3d03  pop rcx
000075d5269d3d04  pop rax
000075d5269d3d05  add rsp, 0x08
000075d5269d3d09  jmp 0x000075D5269D0015
000075d5269d3d0e  sub rsp, 0x08
000075d5269d3d12  push rax
000075d5269d3d13  push rcx
000075d5269d3d14  push rdx
000075d5269d3d15  push rdi
000075d5269d3d16  push rsi
000075d5269d3d17  push r8
000075d5269d3d19  push r9
000075d5269d3d1b  push r10
000075d5269d3d1d  push r11
000075d5269d3d1f  sub rsp, 0xF0
000075d5269d3d26  vmovaps [rsp], xmm0
000075d5269d3d2b  vmovaps [rsp+0x10], xmm1
000075d5269d3d31  vmovaps [rsp+0x20], xmm2
000075d5269d3d37  vmovaps [rsp+0x30], xmm3
000075d5269d3d3d  vmovaps [rsp+0x40], xmm4
000075d5269d3d43  vmovaps [rsp+0x50], xmm5
000075d5269d3d49  vmovaps [rsp+0x60], xmm6
000075d5269d3d4f  vmovaps [rsp+0x70], xmm7
000075d5269d3d55  vmovaps [rsp+0x80], xmm8
000075d5269d3d5e  vmovaps [rsp+0x90], xmm9
000075d5269d3d67  vmovaps [rsp+0xA0], xmm10
000075d5269d3d70  vmovaps [rsp+0xB0], xmm12
000075d5269d3d79  vmovaps [rsp+0xC0], xmm13
000075d5269d3d82  vmovaps [rsp+0xD0], xmm14
000075d5269d3d8b  vmovaps [rsp+0xE0], xmm15
000075d5269d3d94  sub rsp, 0x30
000075d5269d3d98  movaps [rsp], xmm11
000075d5269d3d9d  movaps [rsp+0x10], xmm13
000075d5269d3da3  movaps [rsp+0x20], xmm14
000075d5269d3da9  lea rdi, [rsp]
000075d5269d3dad  mov esi, 0x00
000075d5269d3db2  mov rax, 0x601129E62530
000075d5269d3dbc  call rax
000075d5269d3dbe  movaps xmm11, [rsp]
000075d5269d3dc3  add rsp, 0x30
000075d5269d3dc7  vmovaps xmm0, [rsp]
000075d5269d3dcc  vmovaps xmm1, [rsp+0x10]
000075d5269d3dd2  vmovaps xmm2, [rsp+0x20]
000075d5269d3dd8  vmovaps xmm3, [rsp+0x30]
000075d5269d3dde  vmovaps xmm4, [rsp+0x40]
000075d5269d3de4  vmovaps xmm5, [rsp+0x50]
000075d5269d3dea  vmovaps xmm6, [rsp+0x60]
000075d5269d3df0  vmovaps xmm7, [rsp+0x70]
000075d5269d3df6  vmovaps xmm8, [rsp+0x80]
000075d5269d3dff  vmovaps xmm9, [rsp+0x90]
000075d5269d3e08  vmovaps xmm10, [rsp+0xA0]
000075d5269d3e11  vmovaps xmm12, [rsp+0xB0]
000075d5269d3e1a  vmovaps xmm13, [rsp+0xC0]
000075d5269d3e23  vmovaps xmm14, [rsp+0xD0]
000075d5269d3e2c  vmovaps xmm15, [rsp+0xE0]
000075d5269d3e35  add rsp, 0xF0
000075d5269d3e3c  pop r11
000075d5269d3e3e  pop r10
000075d5269d3e40  pop r9
000075d5269d3e42  pop r8
000075d5269d3e44  pop rsi
000075d5269d3e45  pop rdi
000075d5269d3e46  pop rdx
000075d5269d3e47  pop rcx
000075d5269d3e48  pop rax
000075d5269d3e49  add rsp, 0x08
000075d5269d3e4d  jmp 0x000075D5269D003F
000075d5269d3e52  sub rsp, 0x08
000075d5269d3e56  push rax
000075d5269d3e57  push rcx
000075d5269d3e58  push rdx
000075d5269d3e59  push rdi
000075d5269d3e5a  push rsi
000075d5269d3e5b  push r8
000075d5269d3e5d  push r9
000075d5269d3e5f  push r10
000075d5269d3e61  push r11
000075d5269d3e63  sub rsp, 0xF0
000075d5269d3e6a  vmovaps [rsp], xmm0
000075d5269d3e6f  vmovaps [rsp+0x10], xmm1
000075d5269d3e75  vmovaps [rsp+0x20], xmm2
000075d5269d3e7b  vmovaps [rsp+0x30], xmm3
000075d5269d3e81  vmovaps [rsp+0x40], xmm4
000075d5269d3e87  vmovaps [rsp+0x50], xmm5
000075d5269d3e8d  vmovaps [rsp+0x60], xmm6
000075d5269d3e93  vmovaps [rsp+0x70], xmm7
000075d5269d3e99  vmovaps [rsp+0x80], xmm8
000075d5269d3ea2  vmovaps [rsp+0x90], xmm9
000075d5269d3eab  vmovaps [rsp+0xA0], xmm10
000075d5269d3eb4  vmovaps [rsp+0xB0], xmm11
000075d5269d3ebd  vmovaps [rsp+0xC0], xmm12
000075d5269d3ec6  vmovaps [rsp+0xD0], xmm14
000075d5269d3ecf  vmovaps [rsp+0xE0], xmm15
000075d5269d3ed8  sub rsp, 0x30
000075d5269d3edc  movaps [rsp], xmm13
000075d5269d3ee1  movaps [rsp+0x10], xmm8
000075d5269d3ee7  movaps [rsp+0x20], xmm14
000075d5269d3eed  lea rdi, [rsp]
000075d5269d3ef1  mov esi, 0x00
000075d5269d3ef6  mov rax, 0x601129E62530
000075d5269d3f00  call rax
000075d5269d3f02  movaps xmm13, [rsp]
000075d5269d3f07  add rsp, 0x30
000075d5269d3f0b  vmovaps xmm0, [rsp]
000075d5269d3f10  vmovaps xmm1, [rsp+0x10]
000075d5269d3f16  vmovaps xmm2, [rsp+0x20]
000075d5269d3f1c  vmovaps xmm3, [rsp+0x30]
000075d5269d3f22  vmovaps xmm4, [rsp+0x40]
000075d5269d3f28  vmovaps xmm5, [rsp+0x50]
000075d5269d3f2e  vmovaps xmm6, [rsp+0x60]
000075d5269d3f34  vmovaps xmm7, [rsp+0x70]
000075d5269d3f3a  vmovaps xmm8, [rsp+0x80]
000075d5269d3f43  vmovaps xmm9, [rsp+0x90]
000075d5269d3f4c  vmovaps xmm10, [rsp+0xA0]
000075d5269d3f55  vmovaps xmm11, [rsp+0xB0]
000075d5269d3f5e  vmovaps xmm12, [rsp+0xC0]
000075d5269d3f67  vmovaps xmm14, [rsp+0xD0]
000075d5269d3f70  vmovaps xmm15, [rsp+0xE0]
000075d5269d3f79  add rsp, 0xF0
000075d5269d3f80  pop r11
000075d5269d3f82  pop r10
000075d5269d3f84  pop r9
000075d5269d3f86  pop r8
000075d5269d3f88  pop rsi
000075d5269d3f89  pop rdi
000075d5269d3f8a  pop rdx
000075d5269d3f8b  pop rcx
000075d5269d3f8c  pop rax
000075d5269d3f8d  add rsp, 0x08
000075d5269d3f91  jmp 0x000075D5269D006E
000075d5269d3f96  sub rsp, 0x08
000075d5269d3f9a  push rax
000075d5269d3f9b  push rcx
000075d5269d3f9c  push rdx
000075d5269d3f9d  push rdi
000075d5269d3f9e  push rsi
000075d5269d3f9f  push r8
000075d5269d3fa1  push r9
000075d5269d3fa3  push r10
000075d5269d3fa5  push r11
000075d5269d3fa7  sub rsp, 0xF0
000075d5269d3fae  vmovaps [rsp], xmm0
000075d5269d3fb3  vmovaps [rsp+0x10], xmm1
000075d5269d3fb9  vmovaps [rsp+0x20], xmm2
000075d5269d3fbf  vmovaps [rsp+0x30], xmm3
000075d5269d3fc5  vmovaps [rsp+0x40], xmm4
000075d5269d3fcb  vmovaps [rsp+0x50], xmm5
000075d5269d3fd1  vmovaps [rsp+0x60], xmm6
000075d5269d3fd7  vmovaps [rsp+0x70], xmm7
000075d5269d3fdd  vmovaps [rsp+0x80], xmm9
000075d5269d3fe6  vmovaps [rsp+0x90], xmm10
000075d5269d3fef  vmovaps [rsp+0xA0], xmm11
000075d5269d3ff8  vmovaps [rsp+0xB0], xmm12
000075d5269d4001  vmovaps [rsp+0xC0], xmm13
000075d5269d400a  vmovaps [rsp+0xD0], xmm14
000075d5269d4013  vmovaps [rsp+0xE0], xmm15
000075d5269d401c  sub rsp, 0x30
000075d5269d4020  movaps [rsp], xmm8
000075d5269d4025  movaps [rsp+0x10], xmm7
000075d5269d402a  movaps [rsp+0x20], xmm14
000075d5269d4030  lea rdi, [rsp]
000075d5269d4034  mov esi, 0x00
000075d5269d4039  mov rax, 0x601129E62530
000075d5269d4043  call rax
000075d5269d4045  movaps xmm8, [rsp]
000075d5269d404a  add rsp, 0x30
000075d5269d404e  vmovaps xmm0, [rsp]
000075d5269d4053  vmovaps xmm1, [rsp+0x10]
000075d5269d4059  vmovaps xmm2, [rsp+0x20]
000075d5269d405f  vmovaps xmm3, [rsp+0x30]
000075d5269d4065  vmovaps xmm4, [rsp+0x40]
000075d5269d406b  vmovaps xmm5, [rsp+0x50]
000075d5269d4071  vmovaps xmm6, [rsp+0x60]
000075d5269d4077  vmovaps xmm7, [rsp+0x70]
000075d5269d407d  vmovaps xmm9, [rsp+0x80]
000075d5269d4086  vmovaps xmm10, [rsp+0x90]
000075d5269d408f  vmovaps xmm11, [rsp+0xA0]
000075d5269d4098  vmovaps xmm12, [rsp+0xB0]
000075d5269d40a1  vmovaps xmm13, [rsp+0xC0]
000075d5269d40aa  vmovaps xmm14, [rsp+0xD0]
000075d5269d40b3  vmovaps xmm15, [rsp+0xE0]
000075d5269d40bc  add rsp, 0xF0
000075d5269d40c3  pop r11
000075d5269d40c5  pop r10
000075d5269d40c7  pop r9
000075d5269d40c9  pop r8
000075d5269d40cb  pop rsi
000075d5269d40cc  pop rdi
000075d5269d40cd  pop rdx
000075d5269d40ce  pop rcx
000075d5269d40cf  pop rax
000075d5269d40d0  add rsp, 0x08
000075d5269d40d4  jmp 0x000075D5269D0094
000075d5269d40d9  sub rsp, 0x08
000075d5269d40dd  push rax
000075d5269d40de  push rcx
000075d5269d40df  push rdx
000075d5269d40e0  push rdi
000075d5269d40e1  push rsi
000075d5269d40e2  push r8
000075d5269d40e4  push r9
000075d5269d40e6  push r10
000075d5269d40e8  push r11
000075d5269d40ea  sub rsp, 0xF0
000075d5269d40f1  vmovaps [rsp], xmm0
000075d5269d40f6  vmovaps [rsp+0x10], xmm1
000075d5269d40fc  vmovaps [rsp+0x20], xmm2
000075d5269d4102  vmovaps [rsp+0x30], xmm3
000075d5269d4108  vmovaps [rsp+0x40], xmm4
000075d5269d410e  vmovaps [rsp+0x50], xmm5
000075d5269d4114  vmovaps [rsp+0x60], xmm6
000075d5269d411a  vmovaps [rsp+0x70], xmm7
000075d5269d4120  vmovaps [rsp+0x80], xmm8
000075d5269d4129  vmovaps [rsp+0x90], xmm9
000075d5269d4132  vmovaps [rsp+0xA0], xmm10
000075d5269d413b  vmovaps [rsp+0xB0], xmm11
000075d5269d4144  vmovaps [rsp+0xC0], xmm12
000075d5269d414d  vmovaps [rsp+0xD0], xmm13
000075d5269d4156  vmovaps [rsp+0xE0], xmm15
000075d5269d415f  sub rsp, 0x30
000075d5269d4163  movaps [rsp], xmm14
000075d5269d4168  movaps [rsp+0x10], xmm12
000075d5269d416e  movaps [rsp+0x20], xmm9
000075d5269d4174  lea rdi, [rsp]
000075d5269d4178  mov esi, 0x00
000075d5269d417d  mov rax, 0x601129E62530
000075d5269d4187  call rax
000075d5269d4189  movaps xmm14, [rsp]
000075d5269d418e  add rsp, 0x30
000075d5269d4192  vmovaps xmm0, [rsp]
000075d5269d4197  vmovaps xmm1, [rsp+0x10]
000075d5269d419d  vmovaps xmm2, [rsp+0x20]
000075d5269d41a3  vmovaps xmm3, [rsp+0x30]
000075d5269d41a9  vmovaps xmm4, [rsp+0x40]
000075d5269d41af  vmovaps xmm5, [rsp+0x50]
000075d5269d41b5  vmovaps xmm6, [rsp+0x60]
000075d5269d41bb  vmovaps xmm7, [rsp+0x70]
000075d5269d41c1  vmovaps xmm8, [rsp+0x80]
000075d5269d41ca  vmovaps xmm9, [rsp+0x90]
000075d5269d41d3  vmovaps xmm10, [rsp+0xA0]
000075d5269d41dc  vmovaps xmm11, [rsp+0xB0]
000075d5269d41e5  vmovaps xmm12, [rsp+0xC0]
000075d5269d41ee  vmovaps xmm13, [rsp+0xD0]
000075d5269d41f7  vmovaps xmm15, [rsp+0xE0]
000075d5269d4200  add rsp, 0xF0
000075d5269d4207  pop r11
000075d5269d4209  pop r10
000075d5269d420b  pop r9
000075d5269d420d  pop r8
000075d5269d420f  pop rsi
000075d5269d4210  pop rdi
000075d5269d4211  pop rdx
000075d5269d4212  pop rcx
000075d5269d4213  pop rax
000075d5269d4214  add rsp, 0x08
000075d5269d4218  jmp 0x000075D5269D00AE
000075d5269d421d  sub rsp, 0x08
000075d5269d4221  push rax
000075d5269d4222  push rcx
000075d5269d4223  push rdx
000075d5269d4224  push rdi
000075d5269d4225  push rsi
000075d5269d4226  push r8
000075d5269d4228  push r9
000075d5269d422a  push r10
000075d5269d422c  push r11
000075d5269d422e  sub rsp, 0xF0
000075d5269d4235  vmovaps [rsp], xmm0
000075d5269d423a  vmovaps [rsp+0x10], xmm1
000075d5269d4240  vmovaps [rsp+0x20], xmm2
000075d5269d4246  vmovaps [rsp+0x30], xmm3
000075d5269d424c  vmovaps [rsp+0x40], xmm4
000075d5269d4252  vmovaps [rsp+0x50], xmm5
000075d5269d4258  vmovaps [rsp+0x60], xmm6
000075d5269d425e  vmovaps [rsp+0x70], xmm7
000075d5269d4264  vmovaps [rsp+0x80], xmm8
000075d5269d426d  vmovaps [rsp+0x90], xmm10
000075d5269d4276  vmovaps [rsp+0xA0], xmm11
000075d5269d427f  vmovaps [rsp+0xB0], xmm12
000075d5269d4288  vmovaps [rsp+0xC0], xmm13
000075d5269d4291  vmovaps [rsp+0xD0], xmm14
000075d5269d429a  vmovaps [rsp+0xE0], xmm15
000075d5269d42a3  sub rsp, 0x30
000075d5269d42a7  movaps [rsp], xmm9
000075d5269d42ac  movaps [rsp+0x10], xmm7
000075d5269d42b1  movaps [rsp+0x20], xmm12
000075d5269d42b7  lea rdi, [rsp]
000075d5269d42bb  mov esi, 0x00
000075d5269d42c0  mov rax, 0x601129E62530
000075d5269d42ca  call rax
000075d5269d42cc  movaps xmm9, [rsp]
000075d5269d42d1  add rsp, 0x30
000075d5269d42d5  vmovaps xmm0, [rsp]
000075d5269d42da  vmovaps xmm1, [rsp+0x10]
000075d5269d42e0  vmovaps xmm2, [rsp+0x20]
000075d5269d42e6  vmovaps xmm3, [rsp+0x30]
000075d5269d42ec  vmovaps xmm4, [rsp+0x40]
000075d5269d42f2  vmovaps xmm5, [rsp+0x50]
000075d5269d42f8  vmovaps xmm6, [rsp+0x60]
000075d5269d42fe  vmovaps xmm7, [rsp+0x70]
000075d5269d4304  vmovaps xmm8, [rsp+0x80]
000075d5269d430d  vmovaps xmm10, [rsp+0x90]
000075d5269d4316  vmovaps xmm11, [rsp+0xA0]
000075d5269d431f  vmovaps xmm12, [rsp+0xB0]
000075d5269d4328  vmovaps xmm13, [rsp+0xC0]
000075d5269d4331  vmovaps xmm14, [rsp+0xD0]
000075d5269d433a  vmovaps xmm15, [rsp+0xE0]
000075d5269d4343  add rsp, 0xF0
000075d5269d434a  pop r11
000075d5269d434c  pop r10
000075d5269d434e  pop r9
000075d5269d4350  pop r8
000075d5269d4352  pop rsi
000075d5269d4353  pop rdi
000075d5269d4354  pop rdx
000075d5269d4355  pop rcx
000075d5269d4356  pop rax
000075d5269d4357  add rsp, 0x08
000075d5269d435b  jmp 0x000075D5269D00DD
000075d5269d4360  sub rsp, 0x08
000075d5269d4364  push rax
000075d5269d4365  push rcx
000075d5269d4366  push rdx
000075d5269d4367  push rdi
000075d5269d4368  push rsi
000075d5269d4369  push r8
000075d5269d436b  push r9
000075d5269d436d  push r10
000075d5269d436f  push r11
000075d5269d4371  sub rsp, 0xF0
000075d5269d4378  vmovaps [rsp], xmm0
000075d5269d437d  vmovaps [rsp+0x10], xmm1
000075d5269d4383  vmovaps [rsp+0x20], xmm2
000075d5269d4389  vmovaps [rsp+0x30], xmm3
000075d5269d438f  vmovaps [rsp+0x40], xmm4
000075d5269d4395  vmovaps [rsp+0x50], xmm5
000075d5269d439b  vmovaps [rsp+0x60], xmm6
000075d5269d43a1  vmovaps [rsp+0x70], xmm7
000075d5269d43a7  vmovaps [rsp+0x80], xmm8
000075d5269d43b0  vmovaps [rsp+0x90], xmm9
000075d5269d43b9  vmovaps [rsp+0xA0], xmm10
000075d5269d43c2  vmovaps [rsp+0xB0], xmm11
000075d5269d43cb  vmovaps [rsp+0xC0], xmm13
000075d5269d43d4  vmovaps [rsp+0xD0], xmm14
000075d5269d43dd  vmovaps [rsp+0xE0], xmm15
000075d5269d43e6  sub rsp, 0x30
000075d5269d43ea  movaps [rsp], xmm12
000075d5269d43ef  movaps [rsp+0x10], xmm15
000075d5269d43f5  movaps [rsp+0x20], xmm11
000075d5269d43fb  lea rdi, [rsp]
000075d5269d43ff  mov esi, 0x00
000075d5269d4404  mov rax, 0x601129E62530
000075d5269d440e  call rax
000075d5269d4410  movaps xmm12, [rsp]
000075d5269d4415  add rsp, 0x30
000075d5269d4419  vmovaps xmm0, [rsp]
000075d5269d441e  vmovaps xmm1, [rsp+0x10]
000075d5269d4424  vmovaps xmm2, [rsp+0x20]
000075d5269d442a  vmovaps xmm3, [rsp+0x30]
000075d5269d4430  vmovaps xmm4, [rsp+0x40]
000075d5269d4436  vmovaps xmm5, [rsp+0x50]
000075d5269d443c  vmovaps xmm6, [rsp+0x60]
000075d5269d4442  vmovaps xmm7, [rsp+0x70]
000075d5269d4448  vmovaps xmm8, [rsp+0x80]
000075d5269d4451  vmovaps xmm9, [rsp+0x90]
000075d5269d445a  vmovaps xmm10, [rsp+0xA0]
000075d5269d4463  vmovaps xmm11, [rsp+0xB0]
000075d5269d446c  vmovaps xmm13, [rsp+0xC0]
000075d5269d4475  vmovaps xmm14, [rsp+0xD0]
000075d5269d447e  vmovaps xmm15, [rsp+0xE0]
000075d5269d4487  add rsp, 0xF0
000075d5269d448e  pop r11
000075d5269d4490  pop r10
000075d5269d4492  pop r9
000075d5269d4494  pop r8
000075d5269d4496  pop rsi
000075d5269d4497  pop rdi
000075d5269d4498  pop rdx
000075d5269d4499  pop rcx
000075d5269d449a  pop rax
000075d5269d449b  add rsp, 0x08
000075d5269d449f  jmp 0x000075D5269D00F7
000075d5269d44a4  sub rsp, 0x08
000075d5269d44a8  push rax
000075d5269d44a9  push rcx
000075d5269d44aa  push rdx
000075d5269d44ab  push rdi
000075d5269d44ac  push rsi
000075d5269d44ad  push r8
000075d5269d44af  push r9
000075d5269d44b1  push r10
000075d5269d44b3  push r11
000075d5269d44b5  sub rsp, 0xF0
000075d5269d44bc  vmovaps [rsp], xmm0
000075d5269d44c1  vmovaps [rsp+0x10], xmm1
000075d5269d44c7  vmovaps [rsp+0x20], xmm2
000075d5269d44cd  vmovaps [rsp+0x30], xmm3
000075d5269d44d3  vmovaps [rsp+0x40], xmm4
000075d5269d44d9  vmovaps [rsp+0x50], xmm5
000075d5269d44df  vmovaps [rsp+0x60], xmm6
000075d5269d44e5  vmovaps [rsp+0x70], xmm7
000075d5269d44eb  vmovaps [rsp+0x80], xmm8
000075d5269d44f4  vmovaps [rsp+0x90], xmm9
000075d5269d44fd  vmovaps [rsp+0xA0], xmm10
000075d5269d4506  vmovaps [rsp+0xB0], xmm12
000075d5269d450f  vmovaps [rsp+0xC0], xmm13
000075d5269d4518  vmovaps [rsp+0xD0], xmm14
000075d5269d4521  vmovaps [rsp+0xE0], xmm15
000075d5269d452a  sub rsp, 0x30
000075d5269d452e  movaps [rsp], xmm11
000075d5269d4533  movaps [rsp+0x10], xmm7
000075d5269d4538  movaps [rsp+0x20], xmm15
000075d5269d453e  lea rdi, [rsp]
000075d5269d4542  mov esi, 0x00
000075d5269d4547  mov rax, 0x601129E62530
000075d5269d4551  call rax
000075d5269d4553  movaps xmm11, [rsp]
000075d5269d4558  add rsp, 0x30
000075d5269d455c  vmovaps xmm0, [rsp]
000075d5269d4561  vmovaps xmm1, [rsp+0x10]
000075d5269d4567  vmovaps xmm2, [rsp+0x20]
000075d5269d456d  vmovaps xmm3, [rsp+0x30]
000075d5269d4573  vmovaps xmm4, [rsp+0x40]
000075d5269d4579  vmovaps xmm5, [rsp+0x50]
000075d5269d457f  vmovaps xmm6, [rsp+0x60]
000075d5269d4585  vmovaps xmm7, [rsp+0x70]
000075d5269d458b  vmovaps xmm8, [rsp+0x80]
000075d5269d4594  vmovaps xmm9, [rsp+0x90]
000075d5269d459d  vmovaps xmm10, [rsp+0xA0]
000075d5269d45a6  vmovaps xmm12, [rsp+0xB0]
000075d5269d45af  vmovaps xmm13, [rsp+0xC0]
000075d5269d45b8  vmovaps xmm14, [rsp+0xD0]
000075d5269d45c1  vmovaps xmm15, [rsp+0xE0]
000075d5269d45ca  add rsp, 0xF0
000075d5269d45d1  pop r11
000075d5269d45d3  pop r10
000075d5269d45d5  pop r9
000075d5269d45d7  pop r8
000075d5269d45d9  pop rsi
000075d5269d45da  pop rdi
000075d5269d45db  pop rdx
000075d5269d45dc  pop rcx
000075d5269d45dd  pop rax
000075d5269d45de  add rsp, 0x08
000075d5269d45e2  jmp 0x000075D5269D0123
000075d5269d45e7  sub rsp, 0x08
000075d5269d45eb  push rax
000075d5269d45ec  push rcx
000075d5269d45ed  push rdx
000075d5269d45ee  push rdi
000075d5269d45ef  push rsi
000075d5269d45f0  push r8
000075d5269d45f2  push r9
000075d5269d45f4  push r10
000075d5269d45f6  push r11
000075d5269d45f8  sub rsp, 0xF0
000075d5269d45ff  vmovaps [rsp], xmm0
000075d5269d4604  vmovaps [rsp+0x10], xmm1
000075d5269d460a  vmovaps [rsp+0x20], xmm2
000075d5269d4610  vmovaps [rsp+0x30], xmm3
000075d5269d4616  vmovaps [rsp+0x40], xmm4
000075d5269d461c  vmovaps [rsp+0x50], xmm5
000075d5269d4622  vmovaps [rsp+0x60], xmm6
000075d5269d4628  vmovaps [rsp+0x70], xmm7
000075d5269d462e  vmovaps [rsp+0x80], xmm8
000075d5269d4637  vmovaps [rsp+0x90], xmm9
000075d5269d4640  vmovaps [rsp+0xA0], xmm10
000075d5269d4649  vmovaps [rsp+0xB0], xmm11
000075d5269d4652  vmovaps [rsp+0xC0], xmm12
000075d5269d465b  vmovaps [rsp+0xD0], xmm13
000075d5269d4664  vmovaps [rsp+0xE0], xmm14
000075d5269d466d  sub rsp, 0x30
000075d5269d4671  movaps [rsp], xmm15
000075d5269d4676  movaps [rsp+0x10], xmm10
000075d5269d467c  movaps [rsp+0x20], xmm13
000075d5269d4682  lea rdi, [rsp]
000075d5269d4686  mov esi, 0x00
000075d5269d468b  mov rax, 0x601129E62530
000075d5269d4695  call rax
000075d5269d4697  movaps xmm15, [rsp]
000075d5269d469c  add rsp, 0x30
000075d5269d46a0  vmovaps xmm0, [rsp]
000075d5269d46a5  vmovaps xmm1, [rsp+0x10]
000075d5269d46ab  vmovaps xmm2, [rsp+0x20]
000075d5269d46b1  vmovaps xmm3, [rsp+0x30]
000075d5269d46b7  vmovaps xmm4, [rsp+0x40]
000075d5269d46bd  vmovaps xmm5, [rsp+0x50]
000075d5269d46c3  vmovaps xmm6, [rsp+0x60]
000075d5269d46c9  vmovaps xmm7, [rsp+0x70]
000075d5269d46cf  vmovaps xmm8, [rsp+0x80]
000075d5269d46d8  vmovaps xmm9, [rsp+0x90]
000075d5269d46e1  vmovaps xmm10, [rsp+0xA0]
000075d5269d46ea  vmovaps xmm11, [rsp+0xB0]
000075d5269d46f3  vmovaps xmm12, [rsp+0xC0]
000075d5269d46fc  vmovaps xmm13, [rsp+0xD0]
000075d5269d4705  vmovaps xmm14, [rsp+0xE0]
000075d5269d470e  add rsp, 0xF0
000075d5269d4715  pop r11
000075d5269d4717  pop r10
000075d5269d4719  pop r9
000075d5269d471b  pop r8
000075d5269d471d  pop rsi
000075d5269d471e  pop rdi
000075d5269d471f  pop rdx
000075d5269d4720  pop rcx
000075d5269d4721  pop rax
000075d5269d4722  add rsp, 0x08
000075d5269d4726  jmp 0x000075D5269D013D
000075d5269d472b  sub rsp, 0x08
000075d5269d472f  push rax
000075d5269d4730  push rcx
000075d5269d4731  push rdx
000075d5269d4732  push rdi
000075d5269d4733  push rsi
000075d5269d4734  push r8
000075d5269d4736  push r9
000075d5269d4738  push r10
000075d5269d473a  push r11
000075d5269d473c  sub rsp, 0xF0
000075d5269d4743  vmovaps [rsp], xmm0
000075d5269d4748  vmovaps [rsp+0x10], xmm1
000075d5269d474e  vmovaps [rsp+0x20], xmm2
000075d5269d4754  vmovaps [rsp+0x30], xmm3
000075d5269d475a  vmovaps [rsp+0x40], xmm4
000075d5269d4760  vmovaps [rsp+0x50], xmm5
000075d5269d4766  vmovaps [rsp+0x60], xmm6
000075d5269d476c  vmovaps [rsp+0x70], xmm7
000075d5269d4772  vmovaps [rsp+0x80], xmm8
000075d5269d477b  vmovaps [rsp+0x90], xmm9
000075d5269d4784  vmovaps [rsp+0xA0], xmm11
000075d5269d478d  vmovaps [rsp+0xB0], xmm12
000075d5269d4796  vmovaps [rsp+0xC0], xmm13
000075d5269d479f  vmovaps [rsp+0xD0], xmm14
000075d5269d47a8  vmovaps [rsp+0xE0], xmm15
000075d5269d47b1  sub rsp, 0x30
000075d5269d47b5  movaps [rsp], xmm10
000075d5269d47ba  movaps [rsp+0x10], xmm7
000075d5269d47bf  movaps [rsp+0x20], xmm13
000075d5269d47c5  lea rdi, [rsp]
000075d5269d47c9  mov esi, 0x00
000075d5269d47ce  mov rax, 0x601129E62530
000075d5269d47d8  call rax
000075d5269d47da  movaps xmm10, [rsp]
000075d5269d47df  add rsp, 0x30
000075d5269d47e3  vmovaps xmm0, [rsp]
000075d5269d47e8  vmovaps xmm1, [rsp+0x10]
000075d5269d47ee  vmovaps xmm2, [rsp+0x20]
000075d5269d47f4  vmovaps xmm3, [rsp+0x30]
000075d5269d47fa  vmovaps xmm4, [rsp+0x40]
000075d5269d4800  vmovaps xmm5, [rsp+0x50]
000075d5269d4806  vmovaps xmm6, [rsp+0x60]
000075d5269d480c  vmovaps xmm7, [rsp+0x70]
000075d5269d4812  vmovaps xmm8, [rsp+0x80]
000075d5269d481b  vmovaps xmm9, [rsp+0x90]
000075d5269d4824  vmovaps xmm11, [rsp+0xA0]
000075d5269d482d  vmovaps xmm12, [rsp+0xB0]
000075d5269d4836  vmovaps xmm13, [rsp+0xC0]
000075d5269d483f  vmovaps xmm14, [rsp+0xD0]
000075d5269d4848  vmovaps xmm15, [rsp+0xE0]
000075d5269d4851  add rsp, 0xF0
000075d5269d4858  pop r11
000075d5269d485a  pop r10
000075d5269d485c  pop r9
000075d5269d485e  pop r8
000075d5269d4860  pop rsi
000075d5269d4861  pop rdi
000075d5269d4862  pop rdx
000075d5269d4863  pop rcx
000075d5269d4864  pop rax
000075d5269d4865  add rsp, 0x08
000075d5269d4869  jmp 0x000075D5269D0169
000075d5269d486e  sub rsp, 0x08
000075d5269d4872  push rax
000075d5269d4873  push rcx
000075d5269d4874  push rdx
000075d5269d4875  push rdi
000075d5269d4876  push rsi
000075d5269d4877  push r8
000075d5269d4879  push r9
000075d5269d487b  push r10
000075d5269d487d  push r11
000075d5269d487f  sub rsp, 0xF0
000075d5269d4886  vmovaps [rsp], xmm0
000075d5269d488b  vmovaps [rsp+0x10], xmm1
000075d5269d4891  vmovaps [rsp+0x20], xmm2
000075d5269d4897  vmovaps [rsp+0x30], xmm3
000075d5269d489d  vmovaps [rsp+0x40], xmm4
000075d5269d48a3  vmovaps [rsp+0x50], xmm5
000075d5269d48a9  vmovaps [rsp+0x60], xmm6
000075d5269d48af  vmovaps [rsp+0x70], xmm7
000075d5269d48b5  vmovaps [rsp+0x80], xmm8
000075d5269d48be  vmovaps [rsp+0x90], xmm9
000075d5269d48c7  vmovaps [rsp+0xA0], xmm10
000075d5269d48d0  vmovaps [rsp+0xB0], xmm11
000075d5269d48d9  vmovaps [rsp+0xC0], xmm12
000075d5269d48e2  vmovaps [rsp+0xD0], xmm14
000075d5269d48eb  vmovaps [rsp+0xE0], xmm15
000075d5269d48f4  sub rsp, 0x30
000075d5269d48f8  movaps [rsp], xmm13
000075d5269d48fd  movaps [rsp+0x10], xmm1
000075d5269d4902  movaps [rsp+0x20], xmm8
000075d5269d4908  lea rdi, [rsp]
000075d5269d490c  mov esi, 0x00
000075d5269d4911  mov rax, 0x601129E62530
000075d5269d491b  call rax
000075d5269d491d  movaps xmm13, [rsp]
000075d5269d4922  add rsp, 0x30
000075d5269d4926  vmovaps xmm0, [rsp]
000075d5269d492b  vmovaps xmm1, [rsp+0x10]
000075d5269d4931  vmovaps xmm2, [rsp+0x20]
000075d5269d4937  vmovaps xmm3, [rsp+0x30]
000075d5269d493d  vmovaps xmm4, [rsp+0x40]
000075d5269d4943  vmovaps xmm5, [rsp+0x50]
000075d5269d4949  vmovaps xmm6, [rsp+0x60]
000075d5269d494f  vmovaps xmm7, [rsp+0x70]
000075d5269d4955  vmovaps xmm8, [rsp+0x80]
000075d5269d495e  vmovaps xmm9, [rsp+0x90]
000075d5269d4967  vmovaps xmm10, [rsp+0xA0]
000075d5269d4970  vmovaps xmm11, [rsp+0xB0]
000075d5269d4979  vmovaps xmm12, [rsp+0xC0]
000075d5269d4982  vmovaps xmm14, [rsp+0xD0]
000075d5269d498b  vmovaps xmm15, [rsp+0xE0]
000075d5269d4994  add rsp, 0xF0
000075d5269d499b  pop r11
000075d5269d499d  pop r10
000075d5269d499f  pop r9
000075d5269d49a1  pop r8
000075d5269d49a3  pop rsi
000075d5269d49a4  pop rdi
000075d5269d49a5  pop rdx
000075d5269d49a6  pop rcx
000075d5269d49a7  pop rax
000075d5269d49a8  add rsp, 0x08
000075d5269d49ac  jmp 0x000075D5269D0183
000075d5269d49b1  call 0x000075D5267FF430
000075d5269d49b6  jmp 0x000075D5269D018D
000075d5269d49bb  sub rsp, 0x08
000075d5269d49bf  push rax
000075d5269d49c0  push rcx
000075d5269d49c1  push rdx
000075d5269d49c2  push rdi
000075d5269d49c3  push rsi
000075d5269d49c4  push r8
000075d5269d49c6  push r9
000075d5269d49c8  push r10
000075d5269d49ca  push r11
000075d5269d49cc  sub rsp, 0xF0
000075d5269d49d3  vmovaps [rsp], xmm0
000075d5269d49d8  vmovaps [rsp+0x10], xmm1
000075d5269d49de  vmovaps [rsp+0x20], xmm2
000075d5269d49e4  vmovaps [rsp+0x30], xmm3
000075d5269d49ea  vmovaps [rsp+0x40], xmm4
000075d5269d49f0  vmovaps [rsp+0x50], xmm5
000075d5269d49f6  vmovaps [rsp+0x60], xmm6
000075d5269d49fc  vmovaps [rsp+0x70], xmm7
000075d5269d4a02  vmovaps [rsp+0x80], xmm9
000075d5269d4a0b  vmovaps [rsp+0x90], xmm10
000075d5269d4a14  vmovaps [rsp+0xA0], xmm11
000075d5269d4a1d  vmovaps [rsp+0xB0], xmm12
000075d5269d4a26  vmovaps [rsp+0xC0], xmm13
000075d5269d4a2f  vmovaps [rsp+0xD0], xmm14
000075d5269d4a38  vmovaps [rsp+0xE0], xmm15
000075d5269d4a41  sub rsp, 0x30
000075d5269d4a45  movaps [rsp], xmm8
000075d5269d4a4a  movaps [rsp+0x10], xmm14
000075d5269d4a50  movaps [rsp+0x20], xmm9
000075d5269d4a56  lea rdi, [rsp]
000075d5269d4a5a  mov esi, 0x00
000075d5269d4a5f  mov rax, 0x601129E62530
000075d5269d4a69  call rax
000075d5269d4a6b  movaps xmm8, [rsp]
000075d5269d4a70  add rsp, 0x30
000075d5269d4a74  vmovaps xmm0, [rsp]
000075d5269d4a79  vmovaps xmm1, [rsp+0x10]
000075d5269d4a7f  vmovaps xmm2, [rsp+0x20]
000075d5269d4a85  vmovaps xmm3, [rsp+0x30]
000075d5269d4a8b  vmovaps xmm4, [rsp+0x40]
000075d5269d4a91  vmovaps xmm5, [rsp+0x50]
000075d5269d4a97  vmovaps xmm6, [rsp+0x60]
000075d5269d4a9d  vmovaps xmm7, [rsp+0x70]
000075d5269d4aa3  vmovaps xmm9, [rsp+0x80]
000075d5269d4aac  vmovaps xmm10, [rsp+0x90]
000075d5269d4ab5  vmovaps xmm11, [rsp+0xA0]
000075d5269d4abe  vmovaps xmm12, [rsp+0xB0]
000075d5269d4ac7  vmovaps xmm13, [rsp+0xC0]
000075d5269d4ad0  vmovaps xmm14, [rsp+0xD0]
000075d5269d4ad9  vmovaps xmm15, [rsp+0xE0]
000075d5269d4ae2  add rsp, 0xF0
000075d5269d4ae9  pop r11
000075d5269d4aeb  pop r10
000075d5269d4aed  pop r9
000075d5269d4aef  pop r8
000075d5269d4af1  pop rsi
000075d5269d4af2  pop rdi
000075d5269d4af3  pop rdx
000075d5269d4af4  pop rcx
000075d5269d4af5  pop rax
000075d5269d4af6  add rsp, 0x08
000075d5269d4afa  jmp 0x000075D5269D01AF
000075d5269d4aff  sub rsp, 0x08
000075d5269d4b03  push rax
000075d5269d4b04  push rcx
000075d5269d4b05  push rdx
000075d5269d4b06  push rdi
000075d5269d4b07  push rsi
000075d5269d4b08  push r8
000075d5269d4b0a  push r9
000075d5269d4b0c  push r10
000075d5269d4b0e  push r11
000075d5269d4b10  sub rsp, 0xF0
000075d5269d4b17  vmovaps [rsp], xmm0
000075d5269d4b1c  vmovaps [rsp+0x10], xmm1
000075d5269d4b22  vmovaps [rsp+0x20], xmm2
000075d5269d4b28  vmovaps [rsp+0x30], xmm3
000075d5269d4b2e  vmovaps [rsp+0x40], xmm4
000075d5269d4b34  vmovaps [rsp+0x50], xmm5
000075d5269d4b3a  vmovaps [rsp+0x60], xmm6
000075d5269d4b40  vmovaps [rsp+0x70], xmm7
000075d5269d4b46  vmovaps [rsp+0x80], xmm8
000075d5269d4b4f  vmovaps [rsp+0x90], xmm10
000075d5269d4b58  vmovaps [rsp+0xA0], xmm11
000075d5269d4b61  vmovaps [rsp+0xB0], xmm12
000075d5269d4b6a  vmovaps [rsp+0xC0], xmm13
000075d5269d4b73  vmovaps [rsp+0xD0], xmm14
000075d5269d4b7c  vmovaps [rsp+0xE0], xmm15
000075d5269d4b85  sub rsp, 0x30
000075d5269d4b89  movaps [rsp], xmm9
000075d5269d4b8e  movaps [rsp+0x10], xmm1
000075d5269d4b93  movaps [rsp+0x20], xmm14
000075d5269d4b99  lea rdi, [rsp]
000075d5269d4b9d  mov esi, 0x00
000075d5269d4ba2  mov rax, 0x601129E62530
000075d5269d4bac  call rax
000075d5269d4bae  movaps xmm9, [rsp]
000075d5269d4bb3  add rsp, 0x30
000075d5269d4bb7  vmovaps xmm0, [rsp]
000075d5269d4bbc  vmovaps xmm1, [rsp+0x10]
000075d5269d4bc2  vmovaps xmm2, [rsp+0x20]
000075d5269d4bc8  vmovaps xmm3, [rsp+0x30]
000075d5269d4bce  vmovaps xmm4, [rsp+0x40]
000075d5269d4bd4  vmovaps xmm5, [rsp+0x50]
000075d5269d4bda  vmovaps xmm6, [rsp+0x60]
000075d5269d4be0  vmovaps xmm7, [rsp+0x70]
000075d5269d4be6  vmovaps xmm8, [rsp+0x80]
000075d5269d4bef  vmovaps xmm10, [rsp+0x90]
000075d5269d4bf8  vmovaps xmm11, [rsp+0xA0]
000075d5269d4c01  vmovaps xmm12, [rsp+0xB0]
000075d5269d4c0a  vmovaps xmm13, [rsp+0xC0]
000075d5269d4c13  vmovaps xmm14, [rsp+0xD0]
000075d5269d4c1c  vmovaps xmm15, [rsp+0xE0]
000075d5269d4c25  add rsp, 0xF0
000075d5269d4c2c  pop r11
000075d5269d4c2e  pop r10
000075d5269d4c30  pop r9
000075d5269d4c32  pop r8
000075d5269d4c34  pop rsi
000075d5269d4c35  pop rdi
000075d5269d4c36  pop rdx
000075d5269d4c37  pop rcx
000075d5269d4c38  pop rax
000075d5269d4c39  add rsp, 0x08
000075d5269d4c3d  jmp 0x000075D5269D01DD
000075d5269d4c42  sub rsp, 0x08
000075d5269d4c46  push rax
000075d5269d4c47  push rcx
000075d5269d4c48  push rdx
000075d5269d4c49  push rdi
000075d5269d4c4a  push rsi
000075d5269d4c4b  push r8
000075d5269d4c4d  push r9
000075d5269d4c4f  push r10
000075d5269d4c51  push r11
000075d5269d4c53  sub rsp, 0xF0
000075d5269d4c5a  vmovaps [rsp], xmm0
000075d5269d4c5f  vmovaps [rsp+0x10], xmm1
000075d5269d4c65  vmovaps [rsp+0x20], xmm2
000075d5269d4c6b  vmovaps [rsp+0x30], xmm3
000075d5269d4c71  vmovaps [rsp+0x40], xmm4
000075d5269d4c77  vmovaps [rsp+0x50], xmm5
000075d5269d4c7d  vmovaps [rsp+0x60], xmm6
000075d5269d4c83  vmovaps [rsp+0x70], xmm7
000075d5269d4c89  vmovaps [rsp+0x80], xmm8
000075d5269d4c92  vmovaps [rsp+0x90], xmm9
000075d5269d4c9b  vmovaps [rsp+0xA0], xmm10
000075d5269d4ca4  vmovaps [rsp+0xB0], xmm11
000075d5269d4cad  vmovaps [rsp+0xC0], xmm12
000075d5269d4cb6  vmovaps [rsp+0xD0], xmm13
000075d5269d4cbf  vmovaps [rsp+0xE0], xmm15
000075d5269d4cc8  sub rsp, 0x30
000075d5269d4ccc  movaps [rsp], xmm14
000075d5269d4cd1  movaps [rsp+0x10], xmm4
000075d5269d4cd6  movaps [rsp+0x20], xmm1
000075d5269d4cdb  lea rdi, [rsp]
000075d5269d4cdf  mov esi, 0x00
000075d5269d4ce4  mov rax, 0x601129E62530
000075d5269d4cee  call rax
000075d5269d4cf0  movaps xmm14, [rsp]
000075d5269d4cf5  add rsp, 0x30
000075d5269d4cf9  vmovaps xmm0, [rsp]
000075d5269d4cfe  vmovaps xmm1, [rsp+0x10]
000075d5269d4d04  vmovaps xmm2, [rsp+0x20]
000075d5269d4d0a  vmovaps xmm3, [rsp+0x30]
000075d5269d4d10  vmovaps xmm4, [rsp+0x40]
000075d5269d4d16  vmovaps xmm5, [rsp+0x50]
000075d5269d4d1c  vmovaps xmm6, [rsp+0x60]
000075d5269d4d22  vmovaps xmm7, [rsp+0x70]
000075d5269d4d28  vmovaps xmm8, [rsp+0x80]
000075d5269d4d31  vmovaps xmm9, [rsp+0x90]
000075d5269d4d3a  vmovaps xmm10, [rsp+0xA0]
000075d5269d4d43  vmovaps xmm11, [rsp+0xB0]
000075d5269d4d4c  vmovaps xmm12, [rsp+0xC0]
000075d5269d4d55  vmovaps xmm13, [rsp+0xD0]
000075d5269d4d5e  vmovaps xmm15, [rsp+0xE0]
000075d5269d4d67  add rsp, 0xF0
000075d5269d4d6e  pop r11
000075d5269d4d70  pop r10
000075d5269d4d72  pop r9
000075d5269d4d74  pop r8
000075d5269d4d76  pop rsi
000075d5269d4d77  pop rdi
000075d5269d4d78  pop rdx
000075d5269d4d79  pop rcx
000075d5269d4d7a  pop rax
000075d5269d4d7b  add rsp, 0x08
000075d5269d4d7f  jmp 0x000075D5269D0203
000075d5269d4d84  sub rsp, 0x08
000075d5269d4d88  push rax
000075d5269d4d89  push rcx
000075d5269d4d8a  push rdx
000075d5269d4d8b  push rdi
000075d5269d4d8c  push rsi
000075d5269d4d8d  push r8
000075d5269d4d8f  push r9
000075d5269d4d91  push r10
000075d5269d4d93  push r11
000075d5269d4d95  sub rsp, 0xF0
000075d5269d4d9c  vmovaps [rsp], xmm0
000075d5269d4da1  vmovaps [rsp+0x10], xmm2
000075d5269d4da7  vmovaps [rsp+0x20], xmm3
000075d5269d4dad  vmovaps [rsp+0x30], xmm4
000075d5269d4db3  vmovaps [rsp+0x40], xmm5
000075d5269d4db9  vmovaps [rsp+0x50], xmm6
000075d5269d4dbf  vmovaps [rsp+0x60], xmm7
000075d5269d4dc5  vmovaps [rsp+0x70], xmm8
000075d5269d4dcb  vmovaps [rsp+0x80], xmm9
000075d5269d4dd4  vmovaps [rsp+0x90], xmm10
000075d5269d4ddd  vmovaps [rsp+0xA0], xmm11
000075d5269d4de6  vmovaps [rsp+0xB0], xmm12
000075d5269d4def  vmovaps [rsp+0xC0], xmm13
000075d5269d4df8  vmovaps [rsp+0xD0], xmm14
000075d5269d4e01  vmovaps [rsp+0xE0], xmm15
000075d5269d4e0a  sub rsp, 0x30
000075d5269d4e0e  movaps [rsp], xmm1
000075d5269d4e12  movaps [rsp+0x10], xmm12
000075d5269d4e18  movaps [rsp+0x20], xmm11
000075d5269d4e1e  lea rdi, [rsp]
000075d5269d4e22  mov esi, 0x00
000075d5269d4e27  mov rax, 0x601129E62530
000075d5269d4e31  call rax
000075d5269d4e33  movaps xmm1, [rsp]
000075d5269d4e37  add rsp, 0x30
000075d5269d4e3b  vmovaps xmm0, [rsp]
000075d5269d4e40  vmovaps xmm2, [rsp+0x10]
000075d5269d4e46  vmovaps xmm3, [rsp+0x20]
000075d5269d4e4c  vmovaps xmm4, [rsp+0x30]
000075d5269d4e52  vmovaps xmm5, [rsp+0x40]
000075d5269d4e58  vmovaps xmm6, [rsp+0x50]
000075d5269d4e5e  vmovaps xmm7, [rsp+0x60]
000075d5269d4e64  vmovaps xmm8, [rsp+0x70]
000075d5269d4e6a  vmovaps xmm9, [rsp+0x80]
000075d5269d4e73  vmovaps xmm10, [rsp+0x90]
000075d5269d4e7c  vmovaps xmm11, [rsp+0xA0]
000075d5269d4e85  vmovaps xmm12, [rsp+0xB0]
000075d5269d4e8e  vmovaps xmm13, [rsp+0xC0]
000075d5269d4e97  vmovaps xmm14, [rsp+0xD0]
000075d5269d4ea0  vmovaps xmm15, [rsp+0xE0]
000075d5269d4ea9  add rsp, 0xF0
000075d5269d4eb0  pop r11
000075d5269d4eb2  pop r10
000075d5269d4eb4  pop r9
000075d5269d4eb6  pop r8
000075d5269d4eb8  pop rsi
000075d5269d4eb9  pop rdi
000075d5269d4eba  pop rdx
000075d5269d4ebb  pop rcx
000075d5269d4ebc  pop rax
000075d5269d4ebd  add rsp, 0x08
000075d5269d4ec1  jmp 0x000075D5269D0224
000075d5269d4ec6  call 0x000075D5268E20A0
000075d5269d4ecb  jmp 0x000075D5269D0232
000075d5269d4ed0  call 0x000075D526809D70
000075d5269d4ed5  jmp 0x000075D5269D023C
000075d5269d4eda  sub rsp, 0x08
000075d5269d4ede  push rax
000075d5269d4edf  push rcx
000075d5269d4ee0  push rdx
000075d5269d4ee1  push rdi
000075d5269d4ee2  push rsi
000075d5269d4ee3  push r8
000075d5269d4ee5  push r9
000075d5269d4ee7  push r10
000075d5269d4ee9  push r11
000075d5269d4eeb  sub rsp, 0xF0
000075d5269d4ef2  vmovaps [rsp], xmm0
000075d5269d4ef7  vmovaps [rsp+0x10], xmm1
000075d5269d4efd  vmovaps [rsp+0x20], xmm2
000075d5269d4f03  vmovaps [rsp+0x30], xmm3
000075d5269d4f09  vmovaps [rsp+0x40], xmm4
000075d5269d4f0f  vmovaps [rsp+0x50], xmm5
000075d5269d4f15  vmovaps [rsp+0x60], xmm6
000075d5269d4f1b  vmovaps [rsp+0x70], xmm8
000075d5269d4f21  vmovaps [rsp+0x80], xmm9
000075d5269d4f2a  vmovaps [rsp+0x90], xmm10
000075d5269d4f33  vmovaps [rsp+0xA0], xmm11
000075d5269d4f3c  vmovaps [rsp+0xB0], xmm12
000075d5269d4f45  vmovaps [rsp+0xC0], xmm13
000075d5269d4f4e  vmovaps [rsp+0xD0], xmm14
000075d5269d4f57  vmovaps [rsp+0xE0], xmm15
000075d5269d4f60  sub rsp, 0x30
000075d5269d4f64  movaps [rsp], xmm7
000075d5269d4f68  movaps [rsp+0x10], xmm15
000075d5269d4f6e  movaps [rsp+0x20], xmm10
000075d5269d4f74  lea rdi, [rsp]
000075d5269d4f78  mov esi, 0x00
000075d5269d4f7d  mov rax, 0x601129E62530
000075d5269d4f87  call rax
000075d5269d4f89  movaps xmm7, [rsp]
000075d5269d4f8d  add rsp, 0x30
000075d5269d4f91  vmovaps xmm0, [rsp]
000075d5269d4f96  vmovaps xmm1, [rsp+0x10]
000075d5269d4f9c  vmovaps xmm2, [rsp+0x20]
000075d5269d4fa2  vmovaps xmm3, [rsp+0x30]
000075d5269d4fa8  vmovaps xmm4, [rsp+0x40]
000075d5269d4fae  vmovaps xmm5, [rsp+0x50]
000075d5269d4fb4  vmovaps xmm6, [rsp+0x60]
000075d5269d4fba  vmovaps xmm8, [rsp+0x70]
000075d5269d4fc0  vmovaps xmm9, [rsp+0x80]
000075d5269d4fc9  vmovaps xmm10, [rsp+0x90]
000075d5269d4fd2  vmovaps xmm11, [rsp+0xA0]
000075d5269d4fdb  vmovaps xmm12, [rsp+0xB0]
000075d5269d4fe4  vmovaps xmm13, [rsp+0xC0]
000075d5269d4fed  vmovaps xmm14, [rsp+0xD0]
000075d5269d4ff6  vmovaps xmm15, [rsp+0xE0]
000075d5269d4fff  add rsp, 0xF0
000075d5269d5006  pop r11
000075d5269d5008  pop r10
000075d5269d500a  pop r9
000075d5269d500c  pop r8
000075d5269d500e  pop rsi
000075d5269d500f  pop rdi
000075d5269d5010  pop rdx
000075d5269d5011  pop rcx
000075d5269d5012  pop rax
000075d5269d5013  add rsp, 0x08
000075d5269d5017  jmp 0x000075D5269D025D
000075d5269d501c  sub rsp, 0x08
000075d5269d5020  push rax
000075d5269d5021  push rcx
000075d5269d5022  push rdx
000075d5269d5023  push rdi
000075d5269d5024  push rsi
000075d5269d5025  push r8
000075d5269d5027  push r9
000075d5269d5029  push r10
000075d5269d502b  push r11
000075d5269d502d  sub rsp, 0xF0
000075d5269d5034  vmovaps [rsp], xmm0
000075d5269d5039  vmovaps [rsp+0x10], xmm1
000075d5269d503f  vmovaps [rsp+0x20], xmm2
000075d5269d5045  vmovaps [rsp+0x30], xmm3
000075d5269d504b  vmovaps [rsp+0x40], xmm4
000075d5269d5051  vmovaps [rsp+0x50], xmm5
000075d5269d5057  vmovaps [rsp+0x60], xmm6
000075d5269d505d  vmovaps [rsp+0x70], xmm7
000075d5269d5063  vmovaps [rsp+0x80], xmm8
000075d5269d506c  vmovaps [rsp+0x90], xmm9
000075d5269d5075  vmovaps [rsp+0xA0], xmm11
000075d5269d507e  vmovaps [rsp+0xB0], xmm12
000075d5269d5087  vmovaps [rsp+0xC0], xmm13
000075d5269d5090  vmovaps [rsp+0xD0], xmm14
000075d5269d5099  vmovaps [rsp+0xE0], xmm15
000075d5269d50a2  sub rsp, 0x30
000075d5269d50a6  movaps [rsp], xmm10
000075d5269d50ab  movaps [rsp+0x10], xmm11
000075d5269d50b1  movaps [rsp+0x20], xmm15
000075d5269d50b7  lea rdi, [rsp]
000075d5269d50bb  mov esi, 0x00
000075d5269d50c0  mov rax, 0x601129E62530
000075d5269d50ca  call rax
000075d5269d50cc  movaps xmm10, [rsp]
000075d5269d50d1  add rsp, 0x30
000075d5269d50d5  vmovaps xmm0, [rsp]
000075d5269d50da  vmovaps xmm1, [rsp+0x10]
000075d5269d50e0  vmovaps xmm2, [rsp+0x20]
000075d5269d50e6  vmovaps xmm3, [rsp+0x30]
000075d5269d50ec  vmovaps xmm4, [rsp+0x40]
000075d5269d50f2  vmovaps xmm5, [rsp+0x50]
000075d5269d50f8  vmovaps xmm6, [rsp+0x60]
000075d5269d50fe  vmovaps xmm7, [rsp+0x70]
000075d5269d5104  vmovaps xmm8, [rsp+0x80]
000075d5269d510d  vmovaps xmm9, [rsp+0x90]
000075d5269d5116  vmovaps xmm11, [rsp+0xA0]
000075d5269d511f  vmovaps xmm12, [rsp+0xB0]
000075d5269d5128  vmovaps xmm13, [rsp+0xC0]
000075d5269d5131  vmovaps xmm14, [rsp+0xD0]
000075d5269d513a  vmovaps xmm15, [rsp+0xE0]
000075d5269d5143  add rsp, 0xF0
000075d5269d514a  pop r11
000075d5269d514c  pop r10
000075d5269d514e  pop r9
000075d5269d5150  pop r8
000075d5269d5152  pop rsi
000075d5269d5153  pop rdi
000075d5269d5154  pop rdx
000075d5269d5155  pop rcx
000075d5269d5156  pop rax
000075d5269d5157  add rsp, 0x08
000075d5269d515b  jmp 0x000075D5269D028B
000075d5269d5160  sub rsp, 0x08
000075d5269d5164  push rax
000075d5269d5165  push rcx
000075d5269d5166  push rdx
000075d5269d5167  push rdi
000075d5269d5168  push rsi
000075d5269d5169  push r8
000075d5269d516b  push r9
000075d5269d516d  push r10
000075d5269d516f  push r11
000075d5269d5171  sub rsp, 0xF0
000075d5269d5178  vmovaps [rsp], xmm0
000075d5269d517d  vmovaps [rsp+0x10], xmm1
000075d5269d5183  vmovaps [rsp+0x20], xmm2
000075d5269d5189  vmovaps [rsp+0x30], xmm3
000075d5269d518f  vmovaps [rsp+0x40], xmm4
000075d5269d5195  vmovaps [rsp+0x50], xmm5
000075d5269d519b  vmovaps [rsp+0x60], xmm6
000075d5269d51a1  vmovaps [rsp+0x70], xmm7
000075d5269d51a7  vmovaps [rsp+0x80], xmm8
000075d5269d51b0  vmovaps [rsp+0x90], xmm9
000075d5269d51b9  vmovaps [rsp+0xA0], xmm10
000075d5269d51c2  vmovaps [rsp+0xB0], xmm12
000075d5269d51cb  vmovaps [rsp+0xC0], xmm13
000075d5269d51d4  vmovaps [rsp+0xD0], xmm14
000075d5269d51dd  vmovaps [rsp+0xE0], xmm15
000075d5269d51e6  sub rsp, 0x30
000075d5269d51ea  movaps [rsp], xmm11
000075d5269d51ef  movaps [rsp+0x10], xmm12
000075d5269d51f5  movaps [rsp+0x20], xmm15
000075d5269d51fb  lea rdi, [rsp]
000075d5269d51ff  mov esi, 0x00
000075d5269d5204  mov rax, 0x601129E62530
000075d5269d520e  call rax
000075d5269d5210  movaps xmm11, [rsp]
000075d5269d5215  add rsp, 0x30
000075d5269d5219  vmovaps xmm0, [rsp]
000075d5269d521e  vmovaps xmm1, [rsp+0x10]
000075d5269d5224  vmovaps xmm2, [rsp+0x20]
000075d5269d522a  vmovaps xmm3, [rsp+0x30]
000075d5269d5230  vmovaps xmm4, [rsp+0x40]
000075d5269d5236  vmovaps xmm5, [rsp+0x50]
000075d5269d523c  vmovaps xmm6, [rsp+0x60]
000075d5269d5242  vmovaps xmm7, [rsp+0x70]
000075d5269d5248  vmovaps xmm8, [rsp+0x80]
000075d5269d5251  vmovaps xmm9, [rsp+0x90]
000075d5269d525a  vmovaps xmm10, [rsp+0xA0]
000075d5269d5263  vmovaps xmm12, [rsp+0xB0]
000075d5269d526c  vmovaps xmm13, [rsp+0xC0]
000075d5269d5275  vmovaps xmm14, [rsp+0xD0]
000075d5269d527e  vmovaps xmm15, [rsp+0xE0]
000075d5269d5287  add rsp, 0xF0
000075d5269d528e  pop r11
000075d5269d5290  pop r10
000075d5269d5292  pop r9
000075d5269d5294  pop r8
000075d5269d5296  pop rsi
000075d5269d5297  pop rdi
000075d5269d5298  pop rdx
000075d5269d5299  pop rcx
000075d5269d529a  pop rax
000075d5269d529b  add rsp, 0x08
000075d5269d529f  jmp 0x000075D5269D02B9
000075d5269d52a4  sub rsp, 0x08
000075d5269d52a8  push rax
000075d5269d52a9  push rcx
000075d5269d52aa  push rdx
000075d5269d52ab  push rdi
000075d5269d52ac  push rsi
000075d5269d52ad  push r8
000075d5269d52af  push r9
000075d5269d52b1  push r10
000075d5269d52b3  push r11
000075d5269d52b5  sub rsp, 0xF0
000075d5269d52bc  vmovaps [rsp], xmm0
000075d5269d52c1  vmovaps [rsp+0x10], xmm1
000075d5269d52c7  vmovaps [rsp+0x20], xmm2
000075d5269d52cd  vmovaps [rsp+0x30], xmm3
000075d5269d52d3  vmovaps [rsp+0x40], xmm4
000075d5269d52d9  vmovaps [rsp+0x50], xmm5
000075d5269d52df  vmovaps [rsp+0x60], xmm6
000075d5269d52e5  vmovaps [rsp+0x70], xmm7
000075d5269d52eb  vmovaps [rsp+0x80], xmm8
000075d5269d52f4  vmovaps [rsp+0x90], xmm9
000075d5269d52fd  vmovaps [rsp+0xA0], xmm10
000075d5269d5306  vmovaps [rsp+0xB0], xmm11
000075d5269d530f  vmovaps [rsp+0xC0], xmm12
000075d5269d5318  vmovaps [rsp+0xD0], xmm13
000075d5269d5321  vmovaps [rsp+0xE0], xmm14
000075d5269d532a  sub rsp, 0x30
000075d5269d532e  movaps [rsp], xmm15
000075d5269d5333  movaps [rsp+0x10], xmm13
000075d5269d5339  movaps [rsp+0x20], xmm9
000075d5269d533f  lea rdi, [rsp]
000075d5269d5343  mov esi, 0x00
000075d5269d5348  mov rax, 0x601129E62530
000075d5269d5352  call rax
000075d5269d5354  movaps xmm15, [rsp]
000075d5269d5359  add rsp, 0x30
000075d5269d535d  vmovaps xmm0, [rsp]
000075d5269d5362  vmovaps xmm1, [rsp+0x10]
000075d5269d5368  vmovaps xmm2, [rsp+0x20]
000075d5269d536e  vmovaps xmm3, [rsp+0x30]
000075d5269d5374  vmovaps xmm4, [rsp+0x40]
000075d5269d537a  vmovaps xmm5, [rsp+0x50]
000075d5269d5380  vmovaps xmm6, [rsp+0x60]
000075d5269d5386  vmovaps xmm7, [rsp+0x70]
000075d5269d538c  vmovaps xmm8, [rsp+0x80]
000075d5269d5395  vmovaps xmm9, [rsp+0x90]
000075d5269d539e  vmovaps xmm10, [rsp+0xA0]
000075d5269d53a7  vmovaps xmm11, [rsp+0xB0]
000075d5269d53b0  vmovaps xmm12, [rsp+0xC0]
000075d5269d53b9  vmovaps xmm13, [rsp+0xD0]
000075d5269d53c2  vmovaps xmm14, [rsp+0xE0]
000075d5269d53cb  add rsp, 0xF0
000075d5269d53d2  pop r11
000075d5269d53d4  pop r10
000075d5269d53d6  pop r9
000075d5269d53d8  pop r8
000075d5269d53da  pop rsi
000075d5269d53db  pop rdi
000075d5269d53dc  pop rdx
000075d5269d53dd  pop rcx
000075d5269d53de  pop rax
000075d5269d53df  add rsp, 0x08
000075d5269d53e3  jmp 0x000075D5269D02D4
000075d5269d53e8  sub rsp, 0x08
000075d5269d53ec  push rax
000075d5269d53ed  push rcx
000075d5269d53ee  push rdx
000075d5269d53ef  push rdi
000075d5269d53f0  push rsi
000075d5269d53f1  push r8
000075d5269d53f3  push r9
000075d5269d53f5  push r10
000075d5269d53f7  push r11
000075d5269d53f9  sub rsp, 0xF0
000075d5269d5400  vmovaps [rsp], xmm0
000075d5269d5405  vmovaps [rsp+0x10], xmm1
000075d5269d540b  vmovaps [rsp+0x20], xmm2
000075d5269d5411  vmovaps [rsp+0x30], xmm3
000075d5269d5417  vmovaps [rsp+0x40], xmm4
000075d5269d541d  vmovaps [rsp+0x50], xmm5
000075d5269d5423  vmovaps [rsp+0x60], xmm6
000075d5269d5429  vmovaps [rsp+0x70], xmm7
000075d5269d542f  vmovaps [rsp+0x80], xmm8
000075d5269d5438  vmovaps [rsp+0x90], xmm9
000075d5269d5441  vmovaps [rsp+0xA0], xmm10
000075d5269d544a  vmovaps [rsp+0xB0], xmm11
000075d5269d5453  vmovaps [rsp+0xC0], xmm12
000075d5269d545c  vmovaps [rsp+0xD0], xmm14
000075d5269d5465  vmovaps [rsp+0xE0], xmm15
000075d5269d546e  sub rsp, 0x30
000075d5269d5472  movaps [rsp], xmm13
000075d5269d5477  movaps [rsp+0x10], xmm8
000075d5269d547d  movaps [rsp+0x20], xmm14
000075d5269d5483  lea rdi, [rsp]
000075d5269d5487  mov esi, 0x00
000075d5269d548c  mov rax, 0x601129E62530
000075d5269d5496  call rax
000075d5269d5498  movaps xmm13, [rsp]
000075d5269d549d  add rsp, 0x30
000075d5269d54a1  vmovaps xmm0, [rsp]
000075d5269d54a6  vmovaps xmm1, [rsp+0x10]
000075d5269d54ac  vmovaps xmm2, [rsp+0x20]
000075d5269d54b2  vmovaps xmm3, [rsp+0x30]
000075d5269d54b8  vmovaps xmm4, [rsp+0x40]
000075d5269d54be  vmovaps xmm5, [rsp+0x50]
000075d5269d54c4  vmovaps xmm6, [rsp+0x60]
000075d5269d54ca  vmovaps xmm7, [rsp+0x70]
000075d5269d54d0  vmovaps xmm8, [rsp+0x80]
000075d5269d54d9  vmovaps xmm9, [rsp+0x90]
000075d5269d54e2  vmovaps xmm10, [rsp+0xA0]
000075d5269d54eb  vmovaps xmm11, [rsp+0xB0]
000075d5269d54f4  vmovaps xmm12, [rsp+0xC0]
000075d5269d54fd  vmovaps xmm14, [rsp+0xD0]
000075d5269d5506  vmovaps xmm15, [rsp+0xE0]
000075d5269d550f  add rsp, 0xF0
000075d5269d5516  pop r11
000075d5269d5518  pop r10
000075d5269d551a  pop r9
000075d5269d551c  pop r8
000075d5269d551e  pop rsi
000075d5269d551f  pop rdi
000075d5269d5520  pop rdx
000075d5269d5521  pop rcx
000075d5269d5522  pop rax
000075d5269d5523  add rsp, 0x08
000075d5269d5527  jmp 0x000075D5269D02F7
000075d5269d552c  sub rsp, 0x08
000075d5269d5530  push rax
000075d5269d5531  push rcx
000075d5269d5532  push rdx
000075d5269d5533  push rdi
000075d5269d5534  push rsi
000075d5269d5535  push r8
000075d5269d5537  push r9
000075d5269d5539  push r10
000075d5269d553b  push r11
000075d5269d553d  sub rsp, 0xF0
000075d5269d5544  vmovaps [rsp], xmm0
000075d5269d5549  vmovaps [rsp+0x10], xmm1
000075d5269d554f  vmovaps [rsp+0x20], xmm2
000075d5269d5555  vmovaps [rsp+0x30], xmm3
000075d5269d555b  vmovaps [rsp+0x40], xmm4
000075d5269d5561  vmovaps [rsp+0x50], xmm5
000075d5269d5567  vmovaps [rsp+0x60], xmm6
000075d5269d556d  vmovaps [rsp+0x70], xmm7
000075d5269d5573  vmovaps [rsp+0x80], xmm8
000075d5269d557c  vmovaps [rsp+0x90], xmm9
000075d5269d5585  vmovaps [rsp+0xA0], xmm10
000075d5269d558e  vmovaps [rsp+0xB0], xmm11
000075d5269d5597  vmovaps [rsp+0xC0], xmm12
000075d5269d55a0  vmovaps [rsp+0xD0], xmm13
000075d5269d55a9  vmovaps [rsp+0xE0], xmm15
000075d5269d55b2  sub rsp, 0x30
000075d5269d55b6  movaps [rsp], xmm14
000075d5269d55bb  movaps [rsp+0x10], xmm1
000075d5269d55c0  movaps [rsp+0x20], xmm10
000075d5269d55c6  lea rdi, [rsp]
000075d5269d55ca  mov esi, 0x00
000075d5269d55cf  mov rax, 0x601129E62530
000075d5269d55d9  call rax
000075d5269d55db  movaps xmm14, [rsp]
000075d5269d55e0  add rsp, 0x30
000075d5269d55e4  vmovaps xmm0, [rsp]
000075d5269d55e9  vmovaps xmm1, [rsp+0x10]
000075d5269d55ef  vmovaps xmm2, [rsp+0x20]
000075d5269d55f5  vmovaps xmm3, [rsp+0x30]
000075d5269d55fb  vmovaps xmm4, [rsp+0x40]
000075d5269d5601  vmovaps xmm5, [rsp+0x50]
000075d5269d5607  vmovaps xmm6, [rsp+0x60]
000075d5269d560d  vmovaps xmm7, [rsp+0x70]
000075d5269d5613  vmovaps xmm8, [rsp+0x80]
000075d5269d561c  vmovaps xmm9, [rsp+0x90]
000075d5269d5625  vmovaps xmm10, [rsp+0xA0]
000075d5269d562e  vmovaps xmm11, [rsp+0xB0]
000075d5269d5637  vmovaps xmm12, [rsp+0xC0]
000075d5269d5640  vmovaps xmm13, [rsp+0xD0]
000075d5269d5649  vmovaps xmm15, [rsp+0xE0]
000075d5269d5652  add rsp, 0xF0
000075d5269d5659  pop r11
000075d5269d565b  pop r10
000075d5269d565d  pop r9
000075d5269d565f  pop r8
000075d5269d5661  pop rsi
000075d5269d5662  pop rdi
000075d5269d5663  pop rdx
000075d5269d5664  pop rcx
000075d5269d5665  pop rax
000075d5269d5666  add rsp, 0x08
000075d5269d566a  jmp 0x000075D5269D031A
000075d5269d566f  sub rsp, 0x08
000075d5269d5673  push rax
000075d5269d5674  push rcx
000075d5269d5675  push rdx
000075d5269d5676  push rdi
000075d5269d5677  push rsi
000075d5269d5678  push r8
000075d5269d567a  push r9
000075d5269d567c  push r10
000075d5269d567e  push r11
000075d5269d5680  sub rsp, 0xF0
000075d5269d5687  vmovaps [rsp], xmm0
000075d5269d568c  vmovaps [rsp+0x10], xmm2
000075d5269d5692  vmovaps [rsp+0x20], xmm3
000075d5269d5698  vmovaps [rsp+0x30], xmm4
000075d5269d569e  vmovaps [rsp+0x40], xmm5
000075d5269d56a4  vmovaps [rsp+0x50], xmm6
000075d5269d56aa  vmovaps [rsp+0x60], xmm7
000075d5269d56b0  vmovaps [rsp+0x70], xmm8
000075d5269d56b6  vmovaps [rsp+0x80], xmm9
000075d5269d56bf  vmovaps [rsp+0x90], xmm10
000075d5269d56c8  vmovaps [rsp+0xA0], xmm11
000075d5269d56d1  vmovaps [rsp+0xB0], xmm12
000075d5269d56da  vmovaps [rsp+0xC0], xmm13
000075d5269d56e3  vmovaps [rsp+0xD0], xmm14
000075d5269d56ec  vmovaps [rsp+0xE0], xmm15
000075d5269d56f5  sub rsp, 0x30
000075d5269d56f9  movaps [rsp], xmm1
000075d5269d56fd  movaps [rsp+0x10], xmm7
000075d5269d5702  movaps [rsp+0x20], xmm11
000075d5269d5708  lea rdi, [rsp]
000075d5269d570c  mov esi, 0x00
000075d5269d5711  mov rax, 0x601129E62530
000075d5269d571b  call rax
000075d5269d571d  movaps xmm1, [rsp]
000075d5269d5721  add rsp, 0x30
000075d5269d5725  vmovaps xmm0, [rsp]
000075d5269d572a  vmovaps xmm2, [rsp+0x10]
000075d5269d5730  vmovaps xmm3, [rsp+0x20]
000075d5269d5736  vmovaps xmm4, [rsp+0x30]
000075d5269d573c  vmovaps xmm5, [rsp+0x40]
000075d5269d5742  vmovaps xmm6, [rsp+0x50]
000075d5269d5748  vmovaps xmm7, [rsp+0x60]
000075d5269d574e  vmovaps xmm8, [rsp+0x70]
000075d5269d5754  vmovaps xmm9, [rsp+0x80]
000075d5269d575d  vmovaps xmm10, [rsp+0x90]
000075d5269d5766  vmovaps xmm11, [rsp+0xA0]
000075d5269d576f  vmovaps xmm12, [rsp+0xB0]
000075d5269d5778  vmovaps xmm13, [rsp+0xC0]
000075d5269d5781  vmovaps xmm14, [rsp+0xD0]
000075d5269d578a  vmovaps xmm15, [rsp+0xE0]
000075d5269d5793  add rsp, 0xF0
000075d5269d579a  pop r11
000075d5269d579c  pop r10
000075d5269d579e  pop r9
000075d5269d57a0  pop r8
000075d5269d57a2  pop rsi
000075d5269d57a3  pop rdi
000075d5269d57a4  pop rdx
000075d5269d57a5  pop rcx
000075d5269d57a6  pop rax
000075d5269d57a7  add rsp, 0x08
000075d5269d57ab  jmp 0x000075D5269D033B
000075d5269d57b0  call 0x000075D52680E880
000075d5269d57b5  jmp 0x000075D5269D034E
000075d5269d57ba  call 0x000075D52680C380
000075d5269d57bf  jmp 0x000075D5269D0359
000075d5269d57c4  call 0x000075D52680D600
000075d5269d57c9  jmp 0x000075D5269D0364
000075d5269d57ce  call 0x000075D5267FF540
000075d5269d57d3  jmp 0x000075D5269D036F
000075d5269d57d8  int3
000075d5269d57d9  nop [rax], eax
000075d5269d57e0  mov rax, [r15+0x40]
000075d5269d57e4  mov r14, [r15+0x58]
000075d5269d57e8  lea r12, [rax+r14*1]
000075d5269d57ec  movaps xmm1, [r15+0x1D0]
000075d5269d57f4  vmovaps [rsp+0x10], xmm1
000075d5269d57fa  vmovaps xmm15, [rsp+0x10]
000075d5269d5800  por xmm1, xmm15
000075d5269d5805  movaps xmm14, [r15+0x1A0]
000075d5269d580d  vmovaps [rsp+0x10], xmm14
000075d5269d5813  vmovaps xmm13, [rsp+0x10]
000075d5269d5819  por xmm14, xmm13
000075d5269d581e  lea rax, [r12+0x30]
000075d5269d5823  mov r11, [r13+rax*1]
000075d5269d5828  lea rax, [r12+0x38]
000075d5269d582d  mov r10, [r13+rax*1]
000075d5269d5832  movq xmm13, r11
000075d5269d5837  movq xmm12, r10
000075d5269d583c  movq xmm13, xmm13
000075d5269d5841  vmovaps [rsp+0x10], xmm13
000075d5269d5847  movq xmm13, xmm13
000075d5269d584c  movaps [r15+0x130], xmm13
000075d5269d5854  movq xmm12, xmm12
000075d5269d5859  vmovaps [rsp+0x20], xmm12
000075d5269d585f  movq xmm12, xmm12
000075d5269d5864  movaps [r15+0x280], xmm12
000075d5269d586c  movaps xmm13, [r15+0x270]
000075d5269d5874  vmovaps [rsp+0x30], xmm13
000075d5269d587a  vmovaps xmm12, [rsp+0x30]
000075d5269d5880  por xmm13, xmm12
000075d5269d5885  lea rax, [r12+0x20]
000075d5269d588a  mov r11, [r13+rax*1]
000075d5269d588f  lea rax, [r12+0x28]
000075d5269d5894  mov r10, [r13+rax*1]
000075d5269d5899  movq xmm12, r11
000075d5269d589e  movq xmm11, r10
000075d5269d58a3  movq xmm12, xmm12
000075d5269d58a8  vmovaps [rsp+0x30], xmm12
000075d5269d58ae  movq xmm12, xmm12
000075d5269d58b3  movaps [r15+0x150], xmm12
000075d5269d58bb  movq xmm11, xmm11
000075d5269d58c0  vmovaps [rsp+0x40], xmm11
000075d5269d58c6  movq xmm11, xmm11
000075d5269d58cb  movaps [r15+0x140], xmm11
000075d5269d58d3  lea rax, [r12+0x10]
000075d5269d58d8  mov r11, [r13+rax*1]
000075d5269d58dd  lea rax, [r12+0x18]
000075d5269d58e2  mov r10, [r13+rax*1]
000075d5269d58e7  movq xmm12, r11
000075d5269d58ec  movq xmm11, r10
000075d5269d58f1  movq xmm12, xmm12
000075d5269d58f6  vmovaps [rsp+0x50], xmm12
000075d5269d58fc  movq xmm12, xmm12
000075d5269d5901  movaps [r15+0x170], xmm12
000075d5269d5909  movq xmm11, xmm11
000075d5269d590e  vmovaps [rsp+0x60], xmm11
000075d5269d5914  movq xmm11, xmm11
000075d5269d5919  movaps [r15+0x160], xmm11
000075d5269d5921  mov rax, [r13+r12*1]
000075d5269d5926  vmovq xmm12, rax
000075d5269d592b  vpbroadcastq xmm12, xmm12
000075d5269d5930  lea rax, [r12+0x08]
000075d5269d5935  mov r12, [r13+rax*1]
000075d5269d593a  movq xmm11, r12
000075d5269d593f  movaps [r15+0x230], xmm11
000075d5269d5947  mov rax, [r15+0xF8]
000075d5269d594e  lea r12, [rax+0x50]
000075d5269d5952  movups xmm11, [r13+r12*1]
000075d5269d5958  lea r12, [rax+0x60]
000075d5269d595c  movups xmm10, [r13+r12*1]
000075d5269d5962  lea r12, [rax+0x30]
000075d5269d5966  movups xmm9, [r13+r12*1]
000075d5269d596c  mov r12, [r15+0x50]
000075d5269d5970  lea r11, [r12+r14*1]
000075d5269d5974  mov [r15+0x60], r11
000075d5269d5978  lea r12, [r14+0x40]
000075d5269d597c  mov [r15+0x58], r12
000075d5269d5980  movaps xmm8, xmm12
000075d5269d5984  mulpd xmm8, xmm15
000075d5269d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000075d5269d598f  ptest xmm7, xmm7
000075d5269d5994  jnz 0x000075D5269D67B7
000075d5269d599a  movq xmm15, qword ptr [r15+0x230]
000075d5269d59a3  vmovaps [rsp+0x70], xmm15
000075d5269d59a9  vpermilpd xmm15, xmm15, 0x00
000075d5269d59af  movaps xmm7, xmm9
000075d5269d59b3  mulpd xmm7, xmm15
000075d5269d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000075d5269d59bd  ptest xmm6, xmm6
000075d5269d59c2  jnz 0x000075D5269D68FB
000075d5269d59c8  vxorps xmm15, xmm15, xmm15
000075d5269d59cd  vpbroadcastq xmm15, xmm15
000075d5269d59d2  movaps xmm9, xmm12
000075d5269d59d6  mulpd xmm9, xmm10
000075d5269d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000075d5269d59e1  ptest xmm6, xmm6
000075d5269d59e6  jnz 0x000075D5269D6A3D
000075d5269d59ec  movaps xmm10, xmm12
000075d5269d59f0  mulpd xmm10, xmm11
000075d5269d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000075d5269d59fb  ptest xmm6, xmm6
000075d5269d5a00  jnz 0x000075D5269D6B81
000075d5269d5a06  movaps xmm11, [r15+0x1F0]
000075d5269d5a0e  movaps xmm6, xmm12
000075d5269d5a12  mulpd xmm6, xmm11
000075d5269d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000075d5269d5a1c  ptest xmm5, xmm5
000075d5269d5a21  jnz 0x000075D5269D6CC5
000075d5269d5a27  movaps xmm12, [r15+0x2A0]
000075d5269d5a2f  vmovaps [rsp+0x80], xmm12
000075d5269d5a38  vmovaps xmm11, [rsp+0x80]
000075d5269d5a41  por xmm12, xmm11
000075d5269d5a46  movaps xmm11, [r15+0x250]
000075d5269d5a4e  vmovaps [rsp+0x80], xmm11
000075d5269d5a57  vmovaps xmm5, [rsp+0x80]
000075d5269d5a60  por xmm11, xmm5
000075d5269d5a65  vmovaps xmm4, [rsp+0x70]
000075d5269d5a6b  vpermilpd xmm4, xmm4, 0x00
000075d5269d5a71  movaps xmm3, xmm5
000075d5269d5a74  mulpd xmm3, xmm4
000075d5269d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000075d5269d5a7d  ptest xmm2, xmm2
000075d5269d5a82  jnz 0x000075D5269D6E07
000075d5269d5a88  mov [rsp+0x80], rax
000075d5269d5a90  xor eax, eax
000075d5269d5a92  mov r14d, 0x200
000075d5269d5a98  cmp r12, r14
000075d5269d5a9b  cmc
000075d5269d5a9c  lahf
000075d5269d5a9d  seto al
000075d5269d5aa0  mov [r15+0x108], eax
000075d5269d5aa7  movaps xmm5, xmm8
000075d5269d5aab  addpd xmm5, xmm15
000075d5269d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000075d5269d5ab5  ptest xmm4, xmm4
000075d5269d5aba  jnz 0x000075D5269D6F47
000075d5269d5ac0  movaps xmm8, [r15+0x1B0]
000075d5269d5ac8  movaps xmm4, xmm9
000075d5269d5acc  addpd xmm4, xmm8
000075d5269d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000075d5269d5ad6  ptest xmm2, xmm2
000075d5269d5adb  jnz 0x000075D5269D7089
000075d5269d5ae1  movaps xmm9, xmm10
000075d5269d5ae5  addpd xmm9, xmm8
000075d5269d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000075d5269d5af0  ptest xmm2, xmm2
000075d5269d5af5  jnz 0x000075D5269D71CB
000075d5269d5afb  movaps xmm10, [r15+0x2F0]
000075d5269d5b03  vmovaps [rsp+0x90], xmm10
000075d5269d5b0c  vmovaps xmm8, [rsp+0x90]
000075d5269d5b15  por xmm10, xmm8
000075d5269d5b1a  movaps xmm8, [r15+0x2E0]
000075d5269d5b22  vmovaps [rsp+0x90], xmm8
000075d5269d5b2b  vmovaps xmm2, [rsp+0x90]
000075d5269d5b34  por xmm8, xmm2
000075d5269d5b39  movaps xmm2, [r15+0x2D0]
000075d5269d5b41  vmovaps [rsp+0x90], xmm2
000075d5269d5b4a  vmovaps [rsp+0xA0], xmm1
000075d5269d5b53  vmovaps xmm1, [rsp+0x90]
000075d5269d5b5c  por xmm2, xmm1
000075d5269d5b60  movaps xmm1, [r15+0x200]
000075d5269d5b68  vmovaps [rsp+0x90], xmm1
000075d5269d5b71  vmovaps [rsp+0xB0], xmm15
000075d5269d5b7a  vmovaps xmm15, [rsp+0x90]
000075d5269d5b83  por xmm1, xmm15
000075d5269d5b88  movaps xmm15, [r15+0x1C0]
000075d5269d5b90  vmovaps [rsp+0x90], xmm15
000075d5269d5b99  vmovaps [rsp+0xC0], xmm1
000075d5269d5ba2  vmovaps xmm1, [rsp+0x90]
000075d5269d5bab  por xmm15, xmm1
000075d5269d5bb0  movaps xmm1, [r15+0x190]
000075d5269d5bb8  vmovaps [rsp+0x90], xmm1
000075d5269d5bc1  vmovaps [rsp+0xD0], xmm15
000075d5269d5bca  vmovaps xmm15, [rsp+0x90]
000075d5269d5bd3  por xmm1, xmm15
000075d5269d5bd8  movaps xmm15, [r15+0x300]
000075d5269d5be0  vmovaps [rsp+0x90], xmm15
000075d5269d5be9  vmovaps [rsp+0xE0], xmm1
000075d5269d5bf2  vmovaps xmm1, [rsp+0x90]
000075d5269d5bfb  por xmm15, xmm1
000075d5269d5c00  mov rax, [rsp+0x80]
000075d5269d5c08  lea r14, [rax+0xA0]
000075d5269d5c0f  movups xmm1, [r13+r14*1]
000075d5269d5c15  lea r14, [rax+0xB0]
000075d5269d5c1c  vmovaps [rsp+0x80], xmm1
000075d5269d5c25  movups xmm1, [r13+r14*1]
000075d5269d5c2b  vmovaps [rsp+0x90], xmm1
000075d5269d5c34  vmovaps [rsp+0xF0], xmm15
000075d5269d5c3d  vmovaps xmm15, [rsp+0xB0]
000075d5269d5c46  vmovaps [rsp+0xB0], xmm14
000075d5269d5c4f  movaps xmm1, xmm6
000075d5269d5c52  addpd xmm1, xmm15
000075d5269d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000075d5269d5c5c  ptest xmm14, xmm14
000075d5269d5c62  jnz 0x000075D5269D7323
000075d5269d5c68  lea r14, [rax+0xF0]
000075d5269d5c6f  movups xmm15, [r13+r14*1]
000075d5269d5c75  movaps xmm14, xmm4
000075d5269d5c79  addpd xmm14, xmm3
000075d5269d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000075d5269d5c84  ptest xmm6, xmm6
000075d5269d5c89  jnz 0x000075D5269D746E
000075d5269d5c8f  movaps xmm6, xmm9
000075d5269d5c93  addpd xmm6, xmm7
000075d5269d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000075d5269d5c9c  ptest xmm4, xmm4
000075d5269d5ca1  jnz 0x000075D5269D75B0
000075d5269d5ca7  vmovaps xmm9, [rsp+0x70]
000075d5269d5cad  vpermilpd xmm9, xmm9, 0x00
000075d5269d5cb3  vmovaps xmm4, [rsp+0x90]
000075d5269d5cbc  movaps xmm7, xmm4
000075d5269d5cbf  mulpd xmm7, xmm9
000075d5269d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000075d5269d5cc9  ptest xmm3, xmm3
000075d5269d5cce  jnz 0x000075D5269D76F1
000075d5269d5cd4  vmovaps xmm9, [rsp+0x50]
000075d5269d5cda  vpermilpd xmm9, xmm9, 0x00
000075d5269d5ce0  movaps xmm4, xmm15
000075d5269d5ce4  mulpd xmm4, xmm9
000075d5269d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000075d5269d5cee  ptest xmm3, xmm3
000075d5269d5cf3  jnz 0x000075D5269D7832
000075d5269d5cf9  lea r14, [rax+0xE0]
000075d5269d5d00  movups xmm15, [r13+r14*1]
000075d5269d5d06  vmovaps xmm9, [rsp+0x70]
000075d5269d5d0c  vpermilpd xmm9, xmm9, 0x00
000075d5269d5d12  vmovaps [rsp+0x70], xmm1
000075d5269d5d18  vmovaps xmm1, [rsp+0x80]
000075d5269d5d21  vmovaps [rsp+0x80], xmm15
000075d5269d5d2a  movaps xmm3, xmm1
000075d5269d5d2d  mulpd xmm3, xmm9
000075d5269d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000075d5269d5d37  ptest xmm15, xmm15
000075d5269d5d3d  jnz 0x000075D5269D797E
000075d5269d5d43  vmovaps xmm1, [rsp+0xF0]
000075d5269d5d4c  vmovaps xmm15, [rsp+0xF0]
000075d5269d5d55  por xmm1, xmm15
000075d5269d5d5a  movaps [r15+0x300], xmm1
000075d5269d5d62  vmovaps xmm15, [rsp+0xE0]
000075d5269d5d6b  vmovaps xmm9, [rsp+0xE0]
000075d5269d5d74  por xmm15, xmm9
000075d5269d5d79  movaps [r15+0x190], xmm15
000075d5269d5d81  vmovaps xmm9, [rsp+0x50]
000075d5269d5d87  vpermilpd xmm9, xmm9, 0x00
000075d5269d5d8d  vmovaps [rsp+0x90], xmm1
000075d5269d5d96  vmovaps [rsp+0xE0], xmm15
000075d5269d5d9f  vmovaps xmm15, [rsp+0x80]
000075d5269d5da8  vmovaps [rsp+0x80], xmm14
000075d5269d5db1  movaps xmm1, xmm15
000075d5269d5db5  mulpd xmm1, xmm9
000075d5269d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000075d5269d5dbf  ptest xmm14, xmm14
000075d5269d5dc5  jnz 0x000075D5269D7ABF
000075d5269d5dcb  lea r14, [rax+0x90]
000075d5269d5dd2  movups xmm15, [r13+r14*1]
000075d5269d5dd8  vmovaps xmm14, [rsp+0xD0]
000075d5269d5de1  vmovaps xmm9, [rsp+0xD0]
000075d5269d5dea  por xmm14, xmm9
000075d5269d5def  movaps [r15+0x1C0], xmm14
000075d5269d5df7  vmovaps xmm9, [rsp+0xC0]
000075d5269d5e00  vmovaps [rsp+0xD0], xmm1
000075d5269d5e09  vmovaps xmm1, [rsp+0xC0]
000075d5269d5e12  por xmm9, xmm1
000075d5269d5e17  movaps [r15+0x200], xmm9
000075d5269d5e1f  vmovaps [rsp+0xC0], xmm2
000075d5269d5e28  vmovaps xmm1, [rsp+0xC0]
000075d5269d5e31  por xmm2, xmm1
000075d5269d5e35  movaps [r15+0x2D0], xmm2
000075d5269d5e3d  vmovaps [rsp+0xC0], xmm8
000075d5269d5e46  vmovaps xmm1, [rsp+0xC0]
000075d5269d5e4f  por xmm8, xmm1
000075d5269d5e54  movaps [r15+0x2E0], xmm8
000075d5269d5e5c  vmovaps [rsp+0xC0], xmm15
000075d5269d5e65  movaps xmm1, xmm5
000075d5269d5e68  addpd xmm1, xmm7
000075d5269d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000075d5269d5e71  ptest xmm15, xmm15
000075d5269d5e77  jnz 0x000075D5269D7C0B
000075d5269d5e7d  vmovaps xmm15, [rsp+0x50]
000075d5269d5e83  vpermilpd xmm15, xmm15, 0x00
000075d5269d5e89  vmovaps xmm5, [rsp+0xC0]
000075d5269d5e92  vmovaps [rsp+0xC0], xmm1
000075d5269d5e9b  movaps xmm7, xmm5
000075d5269d5e9e  mulpd xmm7, xmm15
000075d5269d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000075d5269d5ea8  ptest xmm1, xmm1
000075d5269d5ead  jnz 0x000075D5269D7D4B
000075d5269d5eb3  lea r14, [rax+0x80]
000075d5269d5eba  movups xmm1, [r13+r14*1]
000075d5269d5ec0  vmovaps xmm5, [rsp+0x70]
000075d5269d5ec6  vmovaps [rsp+0x70], xmm1
000075d5269d5ecc  movaps xmm15, xmm5
000075d5269d5ed0  addpd xmm15, xmm3
000075d5269d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269d5edb  ptest xmm1, xmm1
000075d5269d5ee0  jnz 0x000075D5269D7E96
000075d5269d5ee6  vmovaps xmm5, [rsp+0x80]
000075d5269d5eef  movaps xmm1, xmm5
000075d5269d5ef2  addpd xmm1, xmm4
000075d5269d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000075d5269d5efb  ptest xmm3, xmm3
000075d5269d5f00  jnz 0x000075D5269D7FD8
000075d5269d5f06  vmovaps [rsp+0x80], xmm10
000075d5269d5f0f  vmovaps xmm5, [rsp+0x80]
000075d5269d5f18  por xmm10, xmm5
000075d5269d5f1d  movaps [r15+0x2F0], xmm10
000075d5269d5f25  vmovaps xmm5, [rsp+0x50]
000075d5269d5f2b  vpermilpd xmm5, xmm5, 0x00
000075d5269d5f31  vmovaps xmm3, [rsp+0x70]
000075d5269d5f37  vmovaps [rsp+0x50], xmm1
000075d5269d5f3d  movaps xmm4, xmm3
000075d5269d5f40  mulpd xmm4, xmm5
000075d5269d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000075d5269d5f49  ptest xmm1, xmm1
000075d5269d5f4e  jnz 0x000075D5269D8118
000075d5269d5f54  lea r14, [rax+0xD0]
000075d5269d5f5b  movups xmm1, [r13+r14*1]
000075d5269d5f61  vmovaps xmm3, [rsp+0xD0]
000075d5269d5f6a  vmovaps [rsp+0x70], xmm1
000075d5269d5f70  movaps xmm5, xmm6
000075d5269d5f73  addpd xmm5, xmm3
000075d5269d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000075d5269d5f7c  ptest xmm1, xmm1
000075d5269d5f81  jnz 0x000075D5269D8262
000075d5269d5f87  vmovaps xmm1, [rsp+0x60]
000075d5269d5f8d  vpermilpd xmm1, xmm1, 0x00
000075d5269d5f93  movaps xmm6, xmm9
000075d5269d5f97  mulpd xmm6, xmm1
000075d5269d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000075d5269d5fa0  ptest xmm3, xmm3
000075d5269d5fa5  jnz 0x000075D5269D83A2
000075d5269d5fab  movaps [r15+0x260], xmm6
000075d5269d5fb3  vxorps xmm1, xmm1, xmm1
000075d5269d5fb7  vpbroadcastq xmm1, xmm1
000075d5269d5fbc  movaps [r15+0x1B0], xmm1
000075d5269d5fc4  vmovaps xmm1, [rsp+0x60]
000075d5269d5fca  vpermilpd xmm1, xmm1, 0x00
000075d5269d5fd0  vmovaps xmm3, [rsp+0x70]
000075d5269d5fd6  vmovaps [rsp+0x70], xmm15
000075d5269d5fdc  movaps xmm9, xmm3
000075d5269d5fe0  mulpd xmm9, xmm1
000075d5269d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000075d5269d5feb  ptest xmm15, xmm15
000075d5269d5ff1  jnz 0x000075D5269D84E3
000075d5269d5ff7  lea r14, [rax+0xC0]
000075d5269d5ffe  movups xmm1, [r13+r14*1]
000075d5269d6004  vmovaps xmm3, [rsp+0xC0]
000075d5269d600d  vmovaps [rsp+0x80], xmm1
000075d5269d6016  movaps xmm15, xmm3
000075d5269d601a  addpd xmm15, xmm7
000075d5269d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269d6025  ptest xmm1, xmm1
000075d5269d602a  jnz 0x000075D5269D862F
000075d5269d6030  vmovaps [rsp+0xC0], xmm13
000075d5269d6039  vmovaps xmm1, [rsp+0xC0]
000075d5269d6042  por xmm13, xmm1
000075d5269d6047  movaps [r15+0x270], xmm13
000075d5269d604f  vmovaps xmm1, [rsp+0xB0]
000075d5269d6058  vmovaps xmm7, [rsp+0xB0]
000075d5269d6061  por xmm1, xmm7
000075d5269d6065  movaps [r15+0x1A0], xmm1
000075d5269d606d  vmovaps xmm1, [rsp+0x60]
000075d5269d6073  vpermilpd xmm1, xmm1, 0x00
000075d5269d6079  vmovaps [rsp+0xB0], xmm1
000075d5269d6082  vmovaps xmm1, [rsp+0x80]
000075d5269d608b  vmovaps [rsp+0x80], xmm15
000075d5269d6094  vmovaps xmm15, [rsp+0xB0]
000075d5269d609d  vmovaps [rsp+0xB0], xmm14
000075d5269d60a6  movaps xmm3, xmm1
000075d5269d60a9  mulpd xmm3, xmm15
000075d5269d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000075d5269d60b3  ptest xmm14, xmm14
000075d5269d60b9  jnz 0x000075D5269D8771
000075d5269d60bf  lea r14, [rax+0x20]
000075d5269d60c3  movups xmm1, [r13+r14*1]
000075d5269d60c9  movaps [r15+0x110], xmm1
000075d5269d60d1  vmovaps xmm14, [rsp+0x70]
000075d5269d60d7  vmovaps [rsp+0x70], xmm1
000075d5269d60dd  movaps xmm15, xmm14
000075d5269d60e1  addpd xmm15, xmm4
000075d5269d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269d60ec  ptest xmm1, xmm1
000075d5269d60f1  jnz 0x000075D5269D88BC
000075d5269d60f7  vmovaps xmm1, [rsp+0x60]
000075d5269d60fd  vpermilpd xmm1, xmm1, 0x00
000075d5269d6103  movaps xmm14, xmm2
000075d5269d6107  mulpd xmm14, xmm1
000075d5269d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000075d5269d6112  ptest xmm4, xmm4
000075d5269d6117  jnz 0x000075D5269D89FF
000075d5269d611d  vmovaps xmm4, [rsp+0x50]
000075d5269d6123  movaps xmm1, xmm4
000075d5269d6126  addpd xmm1, xmm9
000075d5269d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000075d5269d6130  ptest xmm2, xmm2
000075d5269d6135  jnz 0x000075D5269D8B41
000075d5269d613b  vmovaps xmm9, [rsp+0x30]
000075d5269d6141  vpermilpd xmm9, xmm9, 0x00
000075d5269d6147  vmovaps xmm2, [rsp+0x70]
000075d5269d614d  vmovaps [rsp+0x50], xmm1
000075d5269d6153  movaps xmm4, xmm2
000075d5269d6156  mulpd xmm4, xmm9
000075d5269d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000075d5269d6160  ptest xmm1, xmm1
000075d5269d6165  jnz 0x000075D5269D8C82
000075d5269d616b  vmovaps xmm1, [rsp+0x30]
000075d5269d6171  vpermilpd xmm1, xmm1, 0x00
000075d5269d6177  vmovaps xmm2, [rsp+0x90]
000075d5269d6180  vmovaps [rsp+0x60], xmm15
000075d5269d6186  movaps xmm9, xmm2
000075d5269d618a  mulpd xmm9, xmm1
000075d5269d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000075d5269d6195  ptest xmm15, xmm15
000075d5269d619b  jnz 0x000075D5269D8DC3
000075d5269d61a1  vmovaps xmm15, [rsp+0x80]
000075d5269d61aa  movaps xmm1, xmm15
000075d5269d61ae  addpd xmm1, xmm6
000075d5269d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000075d5269d61b7  ptest xmm2, xmm2
000075d5269d61bc  jnz 0x000075D5269D8F05
000075d5269d61c2  movaps xmm15, xmm5
000075d5269d61c6  addpd xmm15, xmm3
000075d5269d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000075d5269d61d1  ptest xmm6, xmm6
000075d5269d61d6  jnz 0x000075D5269D9046
000075d5269d61dc  vmovaps xmm6, [rsp+0x30]
000075d5269d61e2  vpermilpd xmm6, xmm6, 0x00
000075d5269d61e8  movaps xmm5, xmm8
000075d5269d61ec  mulpd xmm5, xmm6
000075d5269d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000075d5269d61f5  ptest xmm3, xmm3
000075d5269d61fa  jnz 0x000075D5269D9188
000075d5269d6200  vmovaps xmm8, [rsp+0x30]
000075d5269d6206  vpermilpd xmm8, xmm8, 0x00
000075d5269d620c  movaps xmm6, xmm10
000075d5269d6210  mulpd xmm6, xmm8
000075d5269d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000075d5269d621a  ptest xmm3, xmm3
000075d5269d621f  jnz 0x000075D5269D92C9
000075d5269d6225  vmovaps xmm8, [rsp+0x60]
000075d5269d622b  movaps xmm10, xmm8
000075d5269d622f  addpd xmm10, xmm14
000075d5269d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000075d5269d623a  ptest xmm3, xmm3
000075d5269d623f  jnz 0x000075D5269D940B
000075d5269d6245  vmovaps xmm8, [rsp+0x50]
000075d5269d624b  movaps xmm14, xmm8
000075d5269d624f  addpd xmm14, xmm4
000075d5269d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000075d5269d625a  ptest xmm3, xmm3
000075d5269d625f  jnz 0x000075D5269D954F
000075d5269d6265  vmovaps xmm8, [rsp+0x40]
000075d5269d626b  vpermilpd xmm8, xmm8, 0x00
000075d5269d6271  movaps xmm4, xmm13
000075d5269d6275  mulpd xmm4, xmm8
000075d5269d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000075d5269d627f  ptest xmm3, xmm3
000075d5269d6284  jnz 0x000075D5269D9692
000075d5269d628a  movaps xmm13, xmm15
000075d5269d628e  addpd xmm13, xmm9
000075d5269d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000075d5269d6299  ptest xmm8, xmm8
000075d5269d629f  jnz 0x000075D5269D97D4
000075d5269d62a5  movaps xmm15, xmm1
000075d5269d62a9  addpd xmm15, xmm5
000075d5269d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000075d5269d62b4  ptest xmm9, xmm9
000075d5269d62ba  jnz 0x000075D5269D9918
000075d5269d62c0  vmovaps [rsp+0x30], xmm11
000075d5269d62c6  vmovaps xmm1, [rsp+0x30]
000075d5269d62cc  por xmm11, xmm1
000075d5269d62d1  movaps [r15+0x250], xmm11
000075d5269d62d9  vmovaps [rsp+0x30], xmm12
000075d5269d62df  vmovaps xmm1, [rsp+0x30]
000075d5269d62e5  por xmm12, xmm1
000075d5269d62ea  movaps [r15+0x2A0], xmm12
000075d5269d62f2  vmovaps xmm1, [rsp+0xA0]
000075d5269d62fb  vmovaps xmm11, [rsp+0xA0]
000075d5269d6304  por xmm1, xmm11
000075d5269d6309  movaps [r15+0x1D0], xmm1
000075d5269d6311  lea r14, [rax+0x40]
000075d5269d6315  movups xmm1, [r13+r14*1]
000075d5269d631b  movaps [r15+0x2C0], xmm1
000075d5269d6323  vmovaps xmm11, [rsp+0x40]
000075d5269d6329  vpermilpd xmm11, xmm11, 0x00
000075d5269d632f  vmovaps xmm8, [rsp+0xE0]
000075d5269d6338  movaps xmm9, xmm8
000075d5269d633c  mulpd xmm9, xmm11
000075d5269d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000075d5269d6347  ptest xmm5, xmm5
000075d5269d634c  jnz 0x000075D5269D9A64
000075d5269d6352  movaps xmm11, xmm10
000075d5269d6356  addpd xmm11, xmm6
000075d5269d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000075d5269d6361  ptest xmm8, xmm8
000075d5269d6367  jnz 0x000075D5269D9BA8
000075d5269d636d  movaps xmm10, xmm14
000075d5269d6371  addpd xmm10, xmm4
000075d5269d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000075d5269d637c  ptest xmm8, xmm8
000075d5269d6382  jnz 0x000075D5269D9CEB
000075d5269d6388  vmovaps xmm14, [rsp+0x40]
000075d5269d638e  vpermilpd xmm14, xmm14, 0x00
000075d5269d6394  movaps xmm8, xmm1
000075d5269d6398  mulpd xmm8, xmm14
000075d5269d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000075d5269d63a3  ptest xmm6, xmm6
000075d5269d63a8  jnz 0x000075D5269D9E2E
000075d5269d63ae  movaps xmm1, [r15+0x2B0]
000075d5269d63b6  vmovaps xmm14, [rsp+0x40]
000075d5269d63bc  vpermilpd xmm14, xmm14, 0x00
000075d5269d63c2  movaps xmm6, xmm1
000075d5269d63c5  mulpd xmm6, xmm14
000075d5269d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000075d5269d63cf  ptest xmm5, xmm5
000075d5269d63d4  jnz 0x000075D5269D9F71
000075d5269d63da  vmovaps xmm1, [rsp+0x10]
000075d5269d63e0  vpermilpd xmm1, xmm1, 0x00
000075d5269d63e6  movaps xmm14, xmm12
000075d5269d63ea  mulpd xmm14, xmm1
000075d5269d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000075d5269d63f5  ptest xmm5, xmm5
000075d5269d63fa  jnz 0x000075D5269DA0B2
000075d5269d6400  movaps xmm1, xmm13
000075d5269d6404  addpd xmm1, xmm9
000075d5269d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000075d5269d640e  ptest xmm12, xmm12
000075d5269d6414  jnz 0x000075D5269DA1F5
000075d5269d641a  vmovaps xmm13, [rsp+0x10]
000075d5269d6420  vpermilpd xmm13, xmm13, 0x00
000075d5269d6426  movaps xmm12, xmm7
000075d5269d642a  mulpd xmm12, xmm13
000075d5269d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000075d5269d6435  ptest xmm9, xmm9
000075d5269d643b  jnz 0x000075D5269DA337
000075d5269d6441  movaps xmm13, xmm15
000075d5269d6445  addpd xmm13, xmm8
000075d5269d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000075d5269d6450  ptest xmm9, xmm9
000075d5269d6456  jnz 0x000075D5269DA47A
000075d5269d645c  movaps xmm15, [r15+0x290]
000075d5269d6464  vmovaps xmm9, [rsp+0x10]
000075d5269d646a  vpermilpd xmm9, xmm9, 0x00
000075d5269d6470  movaps xmm8, xmm15
000075d5269d6474  mulpd xmm8, xmm9
000075d5269d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000075d5269d647f  ptest xmm7, xmm7
000075d5269d6484  jnz 0x000075D5269DA5BE
000075d5269d648a  movaps xmm15, xmm11
000075d5269d648e  addpd xmm15, xmm6
000075d5269d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000075d5269d6499  ptest xmm9, xmm9
000075d5269d649f  jnz 0x000075D5269DA702
000075d5269d64a5  movaps xmm11, [r15+0x1E0]
000075d5269d64ad  vmovaps xmm9, [rsp+0x10]
000075d5269d64b3  vpermilpd xmm9, xmm9, 0x00
000075d5269d64b9  movaps xmm7, xmm11
000075d5269d64bd  mulpd xmm7, xmm9
000075d5269d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000075d5269d64c7  ptest xmm6, xmm6
000075d5269d64cc  jnz 0x000075D5269DA845
000075d5269d64d2  movaps xmm11, xmm10
000075d5269d64d6  addpd xmm11, xmm14
000075d5269d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000075d5269d64e1  ptest xmm9, xmm9
000075d5269d64e7  jnz 0x000075D5269DA987
000075d5269d64ed  lea r14, [rax+0x70]
000075d5269d64f1  movups xmm14, [r13+r14*1]
000075d5269d64f7  movaps [r15+0x240], xmm14
000075d5269d64ff  movaps xmm10, xmm1
000075d5269d6503  addpd xmm10, xmm12
000075d5269d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000075d5269d650e  ptest xmm9, xmm9
000075d5269d6514  jnz 0x000075D5269DAAD5
000075d5269d651a  movaps [r15+0x170], xmm10
000075d5269d6522  vmovaps xmm1, [rsp+0x20]
000075d5269d6528  vpermilpd xmm1, xmm1, 0x00
000075d5269d652e  movaps xmm12, xmm14
000075d5269d6532  mulpd xmm12, xmm1
000075d5269d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000075d5269d653d  ptest xmm9, xmm9
000075d5269d6543  jnz 0x000075D5269DAC18
000075d5269d6549  vmovaps xmm1, [rsp+0x20]
000075d5269d654f  vpermilpd xmm1, xmm1, 0x00
000075d5269d6555  vmovaps xmm9, [rsp+0xB0]
000075d5269d655e  movaps xmm14, xmm9
000075d5269d6562  mulpd xmm14, xmm1
000075d5269d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000075d5269d656d  ptest xmm6, xmm6
000075d5269d6572  jnz 0x000075D5269DAD5B
000075d5269d6578  movaps [r15+0x180], xmm14
000075d5269d6580  movaps xmm1, xmm13
000075d5269d6584  addpd xmm1, xmm8
000075d5269d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000075d5269d658e  ptest xmm9, xmm9
000075d5269d6594  jnz 0x000075D5269DAE9E
000075d5269d659a  movaps [r15+0x210], xmm1
000075d5269d65a2  movups xmm13, [r13+rax*1]
000075d5269d65a8  lea r14, [rax+0x10]
000075d5269d65ac  movups xmm9, [r13+r14*1]
000075d5269d65b2  movaps [r15+0x230], xmm9
000075d5269d65ba  movaps xmm8, xmm15
000075d5269d65be  addpd xmm8, xmm7
000075d5269d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000075d5269d65c9  ptest xmm6, xmm6
000075d5269d65ce  jnz 0x000075D5269DAFF4
000075d5269d65d4  movaps [r15+0x130], xmm8
000075d5269d65dc  vmovaps xmm15, [rsp+0x20]
000075d5269d65e2  vpermilpd xmm15, xmm15, 0x00
000075d5269d65e8  movaps xmm7, xmm9
000075d5269d65ec  mulpd xmm7, xmm15
000075d5269d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000075d5269d65f6  ptest xmm6, xmm6
000075d5269d65fb  jnz 0x000075D5269DB137
000075d5269d6601  movaps [r15+0x220], xmm7
000075d5269d6609  vmovaps xmm15, [rsp+0x20]
000075d5269d660f  vpermilpd xmm15, xmm15, 0x00
000075d5269d6615  movaps xmm9, xmm13
000075d5269d6619  mulpd xmm9, xmm15
000075d5269d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000075d5269d6624  ptest xmm6, xmm6
000075d5269d6629  jnz 0x000075D5269DB279
000075d5269d662f  movaps xmm15, xmm11
000075d5269d6633  addpd xmm15, xmm12
000075d5269d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000075d5269d663e  ptest xmm13, xmm13
000075d5269d6644  jnz 0x000075D5269DB3BD
000075d5269d664a  movaps [r15+0x140], xmm15
000075d5269d6652  movaps xmm13, xmm10
000075d5269d6656  addpd xmm13, xmm14
000075d5269d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000075d5269d6661  ptest xmm12, xmm12
000075d5269d6667  jnz 0x000075D5269DB501
000075d5269d666d  movaps [r15+0x150], xmm13
000075d5269d6675  movaps xmm14, xmm1
000075d5269d6679  addpd xmm14, xmm7
000075d5269d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000075d5269d6684  ptest xmm12, xmm12
000075d5269d668a  jnz 0x000075D5269DB645
000075d5269d6690  movaps [r15+0x160], xmm14
000075d5269d6698  movaps xmm1, xmm8
000075d5269d669c  addpd xmm1, xmm9
000075d5269d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000075d5269d66a6  ptest xmm12, xmm12
000075d5269d66ac  jnz 0x000075D5269DB787
000075d5269d66b2  movaps [r15+0x120], xmm1
000075d5269d66ba  movups [r13+r11*1], xmm15
000075d5269d66c0  lea rax, [r11+0x10]
000075d5269d66c4  movups [r13+rax*1], xmm13
000075d5269d66ca  lea rax, [r11+0x20]
000075d5269d66ce  movups [r13+rax*1], xmm14
000075d5269d66d4  lea rax, [r11+0x30]
000075d5269d66d8  movups [r13+rax*1], xmm1
000075d5269d66de  mov eax, [r15+0x108]
000075d5269d66e5  sahf
000075d5269d66e6  jnz 0x000075D5269D6718
000075d5269d66e8  cmp dword ptr [r15+0x318], 0x00
000075d5269d66f0  jz 0x000075D5269DB900
000075d5269d66f6  nop [rax+rax*1], ax
000075d5269d66ff  nop [rax+rax*1], eax
000075d5269d6707  mov eax, 0x410444
000075d5269d670c  mov [r15+0x100], rax
000075d5269d6713  jmp 0x000075D5267FE110
000075d5269d6718  cmp dword ptr [r15+0x318], 0x00
000075d5269d6720  jz 0x000075D5269D57E0
000075d5269d6726  nop [rax+rax*1], ax
000075d5269d672f  nop [rax+rax*1], eax
000075d5269d6737  mov eax, 0x410278
000075d5269d673c  mov [r15+0x100], rax
000075d5269d6743  jmp 0x000075D5267FE110
000075d5269d6748  int3
000075d5269d6749  call 0x000075D52680A4B0
000075d5269d674e  jmp 0x000075D5269D5828
000075d5269d6753  call 0x000075D526809240
000075d5269d6758  jmp 0x000075D5269D5832
000075d5269d675d  call 0x000075D52680A4B0
000075d5269d6762  jmp 0x000075D5269D588F
000075d5269d6767  call 0x000075D526809240
000075d5269d676c  jmp 0x000075D5269D5899
000075d5269d6771  call 0x000075D52680A4B0
000075d5269d6776  jmp 0x000075D5269D58DD
000075d5269d677b  call 0x000075D526809240
000075d5269d6780  jmp 0x000075D5269D58E7
000075d5269d6785  call 0x000075D5268B47C0
000075d5269d678a  jmp 0x000075D5269D5926
000075d5269d678f  call 0x000075D52680B720
000075d5269d6794  jmp 0x000075D5269D593A
000075d5269d6799  call 0x000075D5268BFC30
000075d5269d679e  jmp 0x000075D5269D5958
000075d5269d67a3  call 0x000075D5268BE9C0
000075d5269d67a8  jmp 0x000075D5269D5962
000075d5269d67ad  call 0x000075D5268BD750
000075d5269d67b2  jmp 0x000075D5269D596C
000075d5269d67b7  sub rsp, 0x08
000075d5269d67bb  push rax
000075d5269d67bc  push rcx
000075d5269d67bd  push rdx
000075d5269d67be  push rdi
000075d5269d67bf  push rsi
000075d5269d67c0  push r8
000075d5269d67c2  push r9
000075d5269d67c4  push r10
000075d5269d67c6  push r11
000075d5269d67c8  sub rsp, 0xF0
000075d5269d67cf  vmovaps [rsp], xmm0
000075d5269d67d4  vmovaps [rsp+0x10], xmm1
000075d5269d67da  vmovaps [rsp+0x20], xmm2
000075d5269d67e0  vmovaps [rsp+0x30], xmm3
000075d5269d67e6  vmovaps [rsp+0x40], xmm4
000075d5269d67ec  vmovaps [rsp+0x50], xmm5
000075d5269d67f2  vmovaps [rsp+0x60], xmm6
000075d5269d67f8  vmovaps [rsp+0x70], xmm7
000075d5269d67fe  vmovaps [rsp+0x80], xmm9
000075d5269d6807  vmovaps [rsp+0x90], xmm10
000075d5269d6810  vmovaps [rsp+0xA0], xmm11
000075d5269d6819  vmovaps [rsp+0xB0], xmm12
000075d5269d6822  vmovaps [rsp+0xC0], xmm13
000075d5269d682b  vmovaps [rsp+0xD0], xmm14
000075d5269d6834  vmovaps [rsp+0xE0], xmm15
000075d5269d683d  sub rsp, 0x30
000075d5269d6841  movaps [rsp], xmm8
000075d5269d6846  movaps [rsp+0x10], xmm12
000075d5269d684c  movaps [rsp+0x20], xmm15
000075d5269d6852  lea rdi, [rsp]
000075d5269d6856  mov esi, 0x00
000075d5269d685b  mov rax, 0x601129E62530
000075d5269d6865  call rax
000075d5269d6867  movaps xmm8, [rsp]
000075d5269d686c  add rsp, 0x30
000075d5269d6870  vmovaps xmm0, [rsp]
000075d5269d6875  vmovaps xmm1, [rsp+0x10]
000075d5269d687b  vmovaps xmm2, [rsp+0x20]
000075d5269d6881  vmovaps xmm3, [rsp+0x30]
000075d5269d6887  vmovaps xmm4, [rsp+0x40]
000075d5269d688d  vmovaps xmm5, [rsp+0x50]
000075d5269d6893  vmovaps xmm6, [rsp+0x60]
000075d5269d6899  vmovaps xmm7, [rsp+0x70]
000075d5269d689f  vmovaps xmm9, [rsp+0x80]
000075d5269d68a8  vmovaps xmm10, [rsp+0x90]
000075d5269d68b1  vmovaps xmm11, [rsp+0xA0]
000075d5269d68ba  vmovaps xmm12, [rsp+0xB0]
000075d5269d68c3  vmovaps xmm13, [rsp+0xC0]
000075d5269d68cc  vmovaps xmm14, [rsp+0xD0]
000075d5269d68d5  vmovaps xmm15, [rsp+0xE0]
000075d5269d68de  add rsp, 0xF0
000075d5269d68e5  pop r11
000075d5269d68e7  pop r10
000075d5269d68e9  pop r9
000075d5269d68eb  pop r8
000075d5269d68ed  pop rsi
000075d5269d68ee  pop rdi
000075d5269d68ef  pop rdx
000075d5269d68f0  pop rcx
000075d5269d68f1  pop rax
000075d5269d68f2  add rsp, 0x08
000075d5269d68f6  jmp 0x000075D5269D599A
000075d5269d68fb  sub rsp, 0x08
000075d5269d68ff  push rax
000075d5269d6900  push rcx
000075d5269d6901  push rdx
000075d5269d6902  push rdi
000075d5269d6903  push rsi
000075d5269d6904  push r8
000075d5269d6906  push r9
000075d5269d6908  push r10
000075d5269d690a  push r11
000075d5269d690c  sub rsp, 0xF0
000075d5269d6913  vmovaps [rsp], xmm0
000075d5269d6918  vmovaps [rsp+0x10], xmm1
000075d5269d691e  vmovaps [rsp+0x20], xmm2
000075d5269d6924  vmovaps [rsp+0x30], xmm3
000075d5269d692a  vmovaps [rsp+0x40], xmm4
000075d5269d6930  vmovaps [rsp+0x50], xmm5
000075d5269d6936  vmovaps [rsp+0x60], xmm6
000075d5269d693c  vmovaps [rsp+0x70], xmm8
000075d5269d6942  vmovaps [rsp+0x80], xmm9
000075d5269d694b  vmovaps [rsp+0x90], xmm10
000075d5269d6954  vmovaps [rsp+0xA0], xmm11
000075d5269d695d  vmovaps [rsp+0xB0], xmm12
000075d5269d6966  vmovaps [rsp+0xC0], xmm13
000075d5269d696f  vmovaps [rsp+0xD0], xmm14
000075d5269d6978  vmovaps [rsp+0xE0], xmm15
000075d5269d6981  sub rsp, 0x30
000075d5269d6985  movaps [rsp], xmm7
000075d5269d6989  movaps [rsp+0x10], xmm9
000075d5269d698f  movaps [rsp+0x20], xmm15
000075d5269d6995  lea rdi, [rsp]
000075d5269d6999  mov esi, 0x00
000075d5269d699e  mov rax, 0x601129E62530
000075d5269d69a8  call rax
000075d5269d69aa  movaps xmm7, [rsp]
000075d5269d69ae  add rsp, 0x30
000075d5269d69b2  vmovaps xmm0, [rsp]
000075d5269d69b7  vmovaps xmm1, [rsp+0x10]
000075d5269d69bd  vmovaps xmm2, [rsp+0x20]
000075d5269d69c3  vmovaps xmm3, [rsp+0x30]
000075d5269d69c9  vmovaps xmm4, [rsp+0x40]
000075d5269d69cf  vmovaps xmm5, [rsp+0x50]
000075d5269d69d5  vmovaps xmm6, [rsp+0x60]
000075d5269d69db  vmovaps xmm8, [rsp+0x70]
000075d5269d69e1  vmovaps xmm9, [rsp+0x80]
000075d5269d69ea  vmovaps xmm10, [rsp+0x90]
000075d5269d69f3  vmovaps xmm11, [rsp+0xA0]
000075d5269d69fc  vmovaps xmm12, [rsp+0xB0]
000075d5269d6a05  vmovaps xmm13, [rsp+0xC0]
000075d5269d6a0e  vmovaps xmm14, [rsp+0xD0]
000075d5269d6a17  vmovaps xmm15, [rsp+0xE0]
000075d5269d6a20  add rsp, 0xF0
000075d5269d6a27  pop r11
000075d5269d6a29  pop r10
000075d5269d6a2b  pop r9
000075d5269d6a2d  pop r8
000075d5269d6a2f  pop rsi
000075d5269d6a30  pop rdi
000075d5269d6a31  pop rdx
000075d5269d6a32  pop rcx
000075d5269d6a33  pop rax
000075d5269d6a34  add rsp, 0x08
000075d5269d6a38  jmp 0x000075D5269D59C8
000075d5269d6a3d  sub rsp, 0x08
000075d5269d6a41  push rax
000075d5269d6a42  push rcx
000075d5269d6a43  push rdx
000075d5269d6a44  push rdi
000075d5269d6a45  push rsi
000075d5269d6a46  push r8
000075d5269d6a48  push r9
000075d5269d6a4a  push r10
000075d5269d6a4c  push r11
000075d5269d6a4e  sub rsp, 0xF0
000075d5269d6a55  vmovaps [rsp], xmm0
000075d5269d6a5a  vmovaps [rsp+0x10], xmm1
000075d5269d6a60  vmovaps [rsp+0x20], xmm2
000075d5269d6a66  vmovaps [rsp+0x30], xmm3
000075d5269d6a6c  vmovaps [rsp+0x40], xmm4
000075d5269d6a72  vmovaps [rsp+0x50], xmm5
000075d5269d6a78  vmovaps [rsp+0x60], xmm6
000075d5269d6a7e  vmovaps [rsp+0x70], xmm7
000075d5269d6a84  vmovaps [rsp+0x80], xmm8
000075d5269d6a8d  vmovaps [rsp+0x90], xmm10
000075d5269d6a96  vmovaps [rsp+0xA0], xmm11
000075d5269d6a9f  vmovaps [rsp+0xB0], xmm12
000075d5269d6aa8  vmovaps [rsp+0xC0], xmm13
000075d5269d6ab1  vmovaps [rsp+0xD0], xmm14
000075d5269d6aba  vmovaps [rsp+0xE0], xmm15
000075d5269d6ac3  sub rsp, 0x30
000075d5269d6ac7  movaps [rsp], xmm9
000075d5269d6acc  movaps [rsp+0x10], xmm12
000075d5269d6ad2  movaps [rsp+0x20], xmm10
000075d5269d6ad8  lea rdi, [rsp]
000075d5269d6adc  mov esi, 0x00
000075d5269d6ae1  mov rax, 0x601129E62530
000075d5269d6aeb  call rax
000075d5269d6aed  movaps xmm9, [rsp]
000075d5269d6af2  add rsp, 0x30
000075d5269d6af6  vmovaps xmm0, [rsp]
000075d5269d6afb  vmovaps xmm1, [rsp+0x10]
000075d5269d6b01  vmovaps xmm2, [rsp+0x20]
000075d5269d6b07  vmovaps xmm3, [rsp+0x30]
000075d5269d6b0d  vmovaps xmm4, [rsp+0x40]
000075d5269d6b13  vmovaps xmm5, [rsp+0x50]
000075d5269d6b19  vmovaps xmm6, [rsp+0x60]
000075d5269d6b1f  vmovaps xmm7, [rsp+0x70]
000075d5269d6b25  vmovaps xmm8, [rsp+0x80]
000075d5269d6b2e  vmovaps xmm10, [rsp+0x90]
000075d5269d6b37  vmovaps xmm11, [rsp+0xA0]
000075d5269d6b40  vmovaps xmm12, [rsp+0xB0]
000075d5269d6b49  vmovaps xmm13, [rsp+0xC0]
000075d5269d6b52  vmovaps xmm14, [rsp+0xD0]
000075d5269d6b5b  vmovaps xmm15, [rsp+0xE0]
000075d5269d6b64  add rsp, 0xF0
000075d5269d6b6b  pop r11
000075d5269d6b6d  pop r10
000075d5269d6b6f  pop r9
000075d5269d6b71  pop r8
000075d5269d6b73  pop rsi
000075d5269d6b74  pop rdi
000075d5269d6b75  pop rdx
000075d5269d6b76  pop rcx
000075d5269d6b77  pop rax
000075d5269d6b78  add rsp, 0x08
000075d5269d6b7c  jmp 0x000075D5269D59EC
000075d5269d6b81  sub rsp, 0x08
000075d5269d6b85  push rax
000075d5269d6b86  push rcx
000075d5269d6b87  push rdx
000075d5269d6b88  push rdi
000075d5269d6b89  push rsi
000075d5269d6b8a  push r8
000075d5269d6b8c  push r9
000075d5269d6b8e  push r10
000075d5269d6b90  push r11
000075d5269d6b92  sub rsp, 0xF0
000075d5269d6b99  vmovaps [rsp], xmm0
000075d5269d6b9e  vmovaps [rsp+0x10], xmm1
000075d5269d6ba4  vmovaps [rsp+0x20], xmm2
000075d5269d6baa  vmovaps [rsp+0x30], xmm3
000075d5269d6bb0  vmovaps [rsp+0x40], xmm4
000075d5269d6bb6  vmovaps [rsp+0x50], xmm5
000075d5269d6bbc  vmovaps [rsp+0x60], xmm6
000075d5269d6bc2  vmovaps [rsp+0x70], xmm7
000075d5269d6bc8  vmovaps [rsp+0x80], xmm8
000075d5269d6bd1  vmovaps [rsp+0x90], xmm9
000075d5269d6bda  vmovaps [rsp+0xA0], xmm11
000075d5269d6be3  vmovaps [rsp+0xB0], xmm12
000075d5269d6bec  vmovaps [rsp+0xC0], xmm13
000075d5269d6bf5  vmovaps [rsp+0xD0], xmm14
000075d5269d6bfe  vmovaps [rsp+0xE0], xmm15
000075d5269d6c07  sub rsp, 0x30
000075d5269d6c0b  movaps [rsp], xmm10
000075d5269d6c10  movaps [rsp+0x10], xmm12
000075d5269d6c16  movaps [rsp+0x20], xmm11
000075d5269d6c1c  lea rdi, [rsp]
000075d5269d6c20  mov esi, 0x00
000075d5269d6c25  mov rax, 0x601129E62530
000075d5269d6c2f  call rax
000075d5269d6c31  movaps xmm10, [rsp]
000075d5269d6c36  add rsp, 0x30
000075d5269d6c3a  vmovaps xmm0, [rsp]
000075d5269d6c3f  vmovaps xmm1, [rsp+0x10]
000075d5269d6c45  vmovaps xmm2, [rsp+0x20]
000075d5269d6c4b  vmovaps xmm3, [rsp+0x30]
000075d5269d6c51  vmovaps xmm4, [rsp+0x40]
000075d5269d6c57  vmovaps xmm5, [rsp+0x50]
000075d5269d6c5d  vmovaps xmm6, [rsp+0x60]
000075d5269d6c63  vmovaps xmm7, [rsp+0x70]
000075d5269d6c69  vmovaps xmm8, [rsp+0x80]
000075d5269d6c72  vmovaps xmm9, [rsp+0x90]
000075d5269d6c7b  vmovaps xmm11, [rsp+0xA0]
000075d5269d6c84  vmovaps xmm12, [rsp+0xB0]
000075d5269d6c8d  vmovaps xmm13, [rsp+0xC0]
000075d5269d6c96  vmovaps xmm14, [rsp+0xD0]
000075d5269d6c9f  vmovaps xmm15, [rsp+0xE0]
000075d5269d6ca8  add rsp, 0xF0
000075d5269d6caf  pop r11
000075d5269d6cb1  pop r10
000075d5269d6cb3  pop r9
000075d5269d6cb5  pop r8
000075d5269d6cb7  pop rsi
000075d5269d6cb8  pop rdi
000075d5269d6cb9  pop rdx
000075d5269d6cba  pop rcx
000075d5269d6cbb  pop rax
000075d5269d6cbc  add rsp, 0x08
000075d5269d6cc0  jmp 0x000075D5269D5A06
000075d5269d6cc5  sub rsp, 0x08
000075d5269d6cc9  push rax
000075d5269d6cca  push rcx
000075d5269d6ccb  push rdx
000075d5269d6ccc  push rdi
000075d5269d6ccd  push rsi
000075d5269d6cce  push r8
000075d5269d6cd0  push r9
000075d5269d6cd2  push r10
000075d5269d6cd4  push r11
000075d5269d6cd6  sub rsp, 0xF0
000075d5269d6cdd  vmovaps [rsp], xmm0
000075d5269d6ce2  vmovaps [rsp+0x10], xmm1
000075d5269d6ce8  vmovaps [rsp+0x20], xmm2
000075d5269d6cee  vmovaps [rsp+0x30], xmm3
000075d5269d6cf4  vmovaps [rsp+0x40], xmm4
000075d5269d6cfa  vmovaps [rsp+0x50], xmm5
000075d5269d6d00  vmovaps [rsp+0x60], xmm7
000075d5269d6d06  vmovaps [rsp+0x70], xmm8
000075d5269d6d0c  vmovaps [rsp+0x80], xmm9
000075d5269d6d15  vmovaps [rsp+0x90], xmm10
000075d5269d6d1e  vmovaps [rsp+0xA0], xmm11
000075d5269d6d27  vmovaps [rsp+0xB0], xmm12
000075d5269d6d30  vmovaps [rsp+0xC0], xmm13
000075d5269d6d39  vmovaps [rsp+0xD0], xmm14
000075d5269d6d42  vmovaps [rsp+0xE0], xmm15
000075d5269d6d4b  sub rsp, 0x30
000075d5269d6d4f  movaps [rsp], xmm6
000075d5269d6d53  movaps [rsp+0x10], xmm12
000075d5269d6d59  movaps [rsp+0x20], xmm11
000075d5269d6d5f  lea rdi, [rsp]
000075d5269d6d63  mov esi, 0x00
000075d5269d6d68  mov rax, 0x601129E62530
000075d5269d6d72  call rax
000075d5269d6d74  movaps xmm6, [rsp]
000075d5269d6d78  add rsp, 0x30
000075d5269d6d7c  vmovaps xmm0, [rsp]
000075d5269d6d81  vmovaps xmm1, [rsp+0x10]
000075d5269d6d87  vmovaps xmm2, [rsp+0x20]
000075d5269d6d8d  vmovaps xmm3, [rsp+0x30]
000075d5269d6d93  vmovaps xmm4, [rsp+0x40]
000075d5269d6d99  vmovaps xmm5, [rsp+0x50]
000075d5269d6d9f  vmovaps xmm7, [rsp+0x60]
000075d5269d6da5  vmovaps xmm8, [rsp+0x70]
000075d5269d6dab  vmovaps xmm9, [rsp+0x80]
000075d5269d6db4  vmovaps xmm10, [rsp+0x90]
000075d5269d6dbd  vmovaps xmm11, [rsp+0xA0]
000075d5269d6dc6  vmovaps xmm12, [rsp+0xB0]
000075d5269d6dcf  vmovaps xmm13, [rsp+0xC0]
000075d5269d6dd8  vmovaps xmm14, [rsp+0xD0]
000075d5269d6de1  vmovaps xmm15, [rsp+0xE0]
000075d5269d6dea  add rsp, 0xF0
000075d5269d6df1  pop r11
000075d5269d6df3  pop r10
000075d5269d6df5  pop r9
000075d5269d6df7  pop r8
000075d5269d6df9  pop rsi
000075d5269d6dfa  pop rdi
000075d5269d6dfb  pop rdx
000075d5269d6dfc  pop rcx
000075d5269d6dfd  pop rax
000075d5269d6dfe  add rsp, 0x08
000075d5269d6e02  jmp 0x000075D5269D5A27
000075d5269d6e07  sub rsp, 0x08
000075d5269d6e0b  push rax
000075d5269d6e0c  push rcx
000075d5269d6e0d  push rdx
000075d5269d6e0e  push rdi
000075d5269d6e0f  push rsi
000075d5269d6e10  push r8
000075d5269d6e12  push r9
000075d5269d6e14  push r10
000075d5269d6e16  push r11
000075d5269d6e18  sub rsp, 0xF0
000075d5269d6e1f  vmovaps [rsp], xmm0
000075d5269d6e24  vmovaps [rsp+0x10], xmm1
000075d5269d6e2a  vmovaps [rsp+0x20], xmm2
000075d5269d6e30  vmovaps [rsp+0x30], xmm4
000075d5269d6e36  vmovaps [rsp+0x40], xmm5
000075d5269d6e3c  vmovaps [rsp+0x50], xmm6
000075d5269d6e42  vmovaps [rsp+0x60], xmm7
000075d5269d6e48  vmovaps [rsp+0x70], xmm8
000075d5269d6e4e  vmovaps [rsp+0x80], xmm9
000075d5269d6e57  vmovaps [rsp+0x90], xmm10
000075d5269d6e60  vmovaps [rsp+0xA0], xmm11
000075d5269d6e69  vmovaps [rsp+0xB0], xmm12
000075d5269d6e72  vmovaps [rsp+0xC0], xmm13
000075d5269d6e7b  vmovaps [rsp+0xD0], xmm14
000075d5269d6e84  vmovaps [rsp+0xE0], xmm15
000075d5269d6e8d  sub rsp, 0x30
000075d5269d6e91  movaps [rsp], xmm3
000075d5269d6e95  movaps [rsp+0x10], xmm5
000075d5269d6e9a  movaps [rsp+0x20], xmm4
000075d5269d6e9f  lea rdi, [rsp]
000075d5269d6ea3  mov esi, 0x00
000075d5269d6ea8  mov rax, 0x601129E62530
000075d5269d6eb2  call rax
000075d5269d6eb4  movaps xmm3, [rsp]
000075d5269d6eb8  add rsp, 0x30
000075d5269d6ebc  vmovaps xmm0, [rsp]
000075d5269d6ec1  vmovaps xmm1, [rsp+0x10]
000075d5269d6ec7  vmovaps xmm2, [rsp+0x20]
000075d5269d6ecd  vmovaps xmm4, [rsp+0x30]
000075d5269d6ed3  vmovaps xmm5, [rsp+0x40]
000075d5269d6ed9  vmovaps xmm6, [rsp+0x50]
000075d5269d6edf  vmovaps xmm7, [rsp+0x60]
000075d5269d6ee5  vmovaps xmm8, [rsp+0x70]
000075d5269d6eeb  vmovaps xmm9, [rsp+0x80]
000075d5269d6ef4  vmovaps xmm10, [rsp+0x90]
000075d5269d6efd  vmovaps xmm11, [rsp+0xA0]
000075d5269d6f06  vmovaps xmm12, [rsp+0xB0]
000075d5269d6f0f  vmovaps xmm13, [rsp+0xC0]
000075d5269d6f18  vmovaps xmm14, [rsp+0xD0]
000075d5269d6f21  vmovaps xmm15, [rsp+0xE0]
000075d5269d6f2a  add rsp, 0xF0
000075d5269d6f31  pop r11
000075d5269d6f33  pop r10
000075d5269d6f35  pop r9
000075d5269d6f37  pop r8
000075d5269d6f39  pop rsi
000075d5269d6f3a  pop rdi
000075d5269d6f3b  pop rdx
000075d5269d6f3c  pop rcx
000075d5269d6f3d  pop rax
000075d5269d6f3e  add rsp, 0x08
000075d5269d6f42  jmp 0x000075D5269D5A88
000075d5269d6f47  sub rsp, 0x08
000075d5269d6f4b  push rax
000075d5269d6f4c  push rcx
000075d5269d6f4d  push rdx
000075d5269d6f4e  push rdi
000075d5269d6f4f  push rsi
000075d5269d6f50  push r8
000075d5269d6f52  push r9
000075d5269d6f54  push r10
000075d5269d6f56  push r11
000075d5269d6f58  sub rsp, 0xF0
000075d5269d6f5f  vmovaps [rsp], xmm0
000075d5269d6f64  vmovaps [rsp+0x10], xmm1
000075d5269d6f6a  vmovaps [rsp+0x20], xmm2
000075d5269d6f70  vmovaps [rsp+0x30], xmm3
000075d5269d6f76  vmovaps [rsp+0x40], xmm4
000075d5269d6f7c  vmovaps [rsp+0x50], xmm6
000075d5269d6f82  vmovaps [rsp+0x60], xmm7
000075d5269d6f88  vmovaps [rsp+0x70], xmm8
000075d5269d6f8e  vmovaps [rsp+0x80], xmm9
000075d5269d6f97  vmovaps [rsp+0x90], xmm10
000075d5269d6fa0  vmovaps [rsp+0xA0], xmm11
000075d5269d6fa9  vmovaps [rsp+0xB0], xmm12
000075d5269d6fb2  vmovaps [rsp+0xC0], xmm13
000075d5269d6fbb  vmovaps [rsp+0xD0], xmm14
000075d5269d6fc4  vmovaps [rsp+0xE0], xmm15
000075d5269d6fcd  sub rsp, 0x30
000075d5269d6fd1  movaps [rsp], xmm5
000075d5269d6fd5  movaps [rsp+0x10], xmm8
000075d5269d6fdb  movaps [rsp+0x20], xmm15
000075d5269d6fe1  lea rdi, [rsp]
000075d5269d6fe5  mov esi, 0x00
000075d5269d6fea  mov rax, 0x601129E62530
000075d5269d6ff4  call rax
000075d5269d6ff6  movaps xmm5, [rsp]
000075d5269d6ffa  add rsp, 0x30
000075d5269d6ffe  vmovaps xmm0, [rsp]
000075d5269d7003  vmovaps xmm1, [rsp+0x10]
000075d5269d7009  vmovaps xmm2, [rsp+0x20]
000075d5269d700f  vmovaps xmm3, [rsp+0x30]
000075d5269d7015  vmovaps xmm4, [rsp+0x40]
000075d5269d701b  vmovaps xmm6, [rsp+0x50]
000075d5269d7021  vmovaps xmm7, [rsp+0x60]
000075d5269d7027  vmovaps xmm8, [rsp+0x70]
000075d5269d702d  vmovaps xmm9, [rsp+0x80]
000075d5269d7036  vmovaps xmm10, [rsp+0x90]
000075d5269d703f  vmovaps xmm11, [rsp+0xA0]
000075d5269d7048  vmovaps xmm12, [rsp+0xB0]
000075d5269d7051  vmovaps xmm13, [rsp+0xC0]
000075d5269d705a  vmovaps xmm14, [rsp+0xD0]
000075d5269d7063  vmovaps xmm15, [rsp+0xE0]
000075d5269d706c  add rsp, 0xF0
000075d5269d7073  pop r11
000075d5269d7075  pop r10
000075d5269d7077  pop r9
000075d5269d7079  pop r8
000075d5269d707b  pop rsi
000075d5269d707c  pop rdi
000075d5269d707d  pop rdx
000075d5269d707e  pop rcx
000075d5269d707f  pop rax
000075d5269d7080  add rsp, 0x08
000075d5269d7084  jmp 0x000075D5269D5AC0
000075d5269d7089  sub rsp, 0x08
000075d5269d708d  push rax
000075d5269d708e  push rcx
000075d5269d708f  push rdx
000075d5269d7090  push rdi
000075d5269d7091  push rsi
000075d5269d7092  push r8
000075d5269d7094  push r9
000075d5269d7096  push r10
000075d5269d7098  push r11
000075d5269d709a  sub rsp, 0xF0
000075d5269d70a1  vmovaps [rsp], xmm0
000075d5269d70a6  vmovaps [rsp+0x10], xmm1
000075d5269d70ac  vmovaps [rsp+0x20], xmm2
000075d5269d70b2  vmovaps [rsp+0x30], xmm3
000075d5269d70b8  vmovaps [rsp+0x40], xmm5
000075d5269d70be  vmovaps [rsp+0x50], xmm6
000075d5269d70c4  vmovaps [rsp+0x60], xmm7
000075d5269d70ca  vmovaps [rsp+0x70], xmm8
000075d5269d70d0  vmovaps [rsp+0x80], xmm9
000075d5269d70d9  vmovaps [rsp+0x90], xmm10
000075d5269d70e2  vmovaps [rsp+0xA0], xmm11
000075d5269d70eb  vmovaps [rsp+0xB0], xmm12
000075d5269d70f4  vmovaps [rsp+0xC0], xmm13
000075d5269d70fd  vmovaps [rsp+0xD0], xmm14
000075d5269d7106  vmovaps [rsp+0xE0], xmm15
000075d5269d710f  sub rsp, 0x30
000075d5269d7113  movaps [rsp], xmm4
000075d5269d7117  movaps [rsp+0x10], xmm9
000075d5269d711d  movaps [rsp+0x20], xmm8
000075d5269d7123  lea rdi, [rsp]
000075d5269d7127  mov esi, 0x00
000075d5269d712c  mov rax, 0x601129E62530
000075d5269d7136  call rax
000075d5269d7138  movaps xmm4, [rsp]
000075d5269d713c  add rsp, 0x30
000075d5269d7140  vmovaps xmm0, [rsp]
000075d5269d7145  vmovaps xmm1, [rsp+0x10]
000075d5269d714b  vmovaps xmm2, [rsp+0x20]
000075d5269d7151  vmovaps xmm3, [rsp+0x30]
000075d5269d7157  vmovaps xmm5, [rsp+0x40]
000075d5269d715d  vmovaps xmm6, [rsp+0x50]
000075d5269d7163  vmovaps xmm7, [rsp+0x60]
000075d5269d7169  vmovaps xmm8, [rsp+0x70]
000075d5269d716f  vmovaps xmm9, [rsp+0x80]
000075d5269d7178  vmovaps xmm10, [rsp+0x90]
000075d5269d7181  vmovaps xmm11, [rsp+0xA0]
000075d5269d718a  vmovaps xmm12, [rsp+0xB0]
000075d5269d7193  vmovaps xmm13, [rsp+0xC0]
000075d5269d719c  vmovaps xmm14, [rsp+0xD0]
000075d5269d71a5  vmovaps xmm15, [rsp+0xE0]
000075d5269d71ae  add rsp, 0xF0
000075d5269d71b5  pop r11
000075d5269d71b7  pop r10
000075d5269d71b9  pop r9
000075d5269d71bb  pop r8
000075d5269d71bd  pop rsi
000075d5269d71be  pop rdi
000075d5269d71bf  pop rdx
000075d5269d71c0  pop rcx
000075d5269d71c1  pop rax
000075d5269d71c2  add rsp, 0x08
000075d5269d71c6  jmp 0x000075D5269D5AE1
000075d5269d71cb  sub rsp, 0x08
000075d5269d71cf  push rax
000075d5269d71d0  push rcx
000075d5269d71d1  push rdx
000075d5269d71d2  push rdi
000075d5269d71d3  push rsi
000075d5269d71d4  push r8
000075d5269d71d6  push r9
000075d5269d71d8  push r10
000075d5269d71da  push r11
000075d5269d71dc  sub rsp, 0xF0
000075d5269d71e3  vmovaps [rsp], xmm0
000075d5269d71e8  vmovaps [rsp+0x10], xmm1
000075d5269d71ee  vmovaps [rsp+0x20], xmm2
000075d5269d71f4  vmovaps [rsp+0x30], xmm3
000075d5269d71fa  vmovaps [rsp+0x40], xmm4
000075d5269d7200  vmovaps [rsp+0x50], xmm5
000075d5269d7206  vmovaps [rsp+0x60], xmm6
000075d5269d720c  vmovaps [rsp+0x70], xmm7
000075d5269d7212  vmovaps [rsp+0x80], xmm8
000075d5269d721b  vmovaps [rsp+0x90], xmm10
000075d5269d7224  vmovaps [rsp+0xA0], xmm11
000075d5269d722d  vmovaps [rsp+0xB0], xmm12
000075d5269d7236  vmovaps [rsp+0xC0], xmm13
000075d5269d723f  vmovaps [rsp+0xD0], xmm14
000075d5269d7248  vmovaps [rsp+0xE0], xmm15
000075d5269d7251  sub rsp, 0x30
000075d5269d7255  movaps [rsp], xmm9
000075d5269d725a  movaps [rsp+0x10], xmm10
000075d5269d7260  movaps [rsp+0x20], xmm8
000075d5269d7266  lea rdi, [rsp]
000075d5269d726a  mov esi, 0x00
000075d5269d726f  mov rax, 0x601129E62530
000075d5269d7279  call rax
000075d5269d727b  movaps xmm9, [rsp]
000075d5269d7280  add rsp, 0x30
000075d5269d7284  vmovaps xmm0, [rsp]
000075d5269d7289  vmovaps xmm1, [rsp+0x10]
000075d5269d728f  vmovaps xmm2, [rsp+0x20]
000075d5269d7295  vmovaps xmm3, [rsp+0x30]
000075d5269d729b  vmovaps xmm4, [rsp+0x40]
000075d5269d72a1  vmovaps xmm5, [rsp+0x50]
000075d5269d72a7  vmovaps xmm6, [rsp+0x60]
000075d5269d72ad  vmovaps xmm7, [rsp+0x70]
000075d5269d72b3  vmovaps xmm8, [rsp+0x80]
000075d5269d72bc  vmovaps xmm10, [rsp+0x90]
000075d5269d72c5  vmovaps xmm11, [rsp+0xA0]
000075d5269d72ce  vmovaps xmm12, [rsp+0xB0]
000075d5269d72d7  vmovaps xmm13, [rsp+0xC0]
000075d5269d72e0  vmovaps xmm14, [rsp+0xD0]
000075d5269d72e9  vmovaps xmm15, [rsp+0xE0]
000075d5269d72f2  add rsp, 0xF0
000075d5269d72f9  pop r11
000075d5269d72fb  pop r10
000075d5269d72fd  pop r9
000075d5269d72ff  pop r8
000075d5269d7301  pop rsi
000075d5269d7302  pop rdi
000075d5269d7303  pop rdx
000075d5269d7304  pop rcx
000075d5269d7305  pop rax
000075d5269d7306  add rsp, 0x08
000075d5269d730a  jmp 0x000075D5269D5AFB
000075d5269d730f  call 0x000075D5268D64F0
000075d5269d7314  jmp 0x000075D5269D5C15
000075d5269d7319  call 0x000075D5268D64F0
000075d5269d731e  jmp 0x000075D5269D5C2B
000075d5269d7323  sub rsp, 0x08
000075d5269d7327  push rax
000075d5269d7328  push rcx
000075d5269d7329  push rdx
000075d5269d732a  push rdi
000075d5269d732b  push rsi
000075d5269d732c  push r8
000075d5269d732e  push r9
000075d5269d7330  push r10
000075d5269d7332  push r11
000075d5269d7334  sub rsp, 0xF0
000075d5269d733b  vmovaps [rsp], xmm0
000075d5269d7340  vmovaps [rsp+0x10], xmm2
000075d5269d7346  vmovaps [rsp+0x20], xmm3
000075d5269d734c  vmovaps [rsp+0x30], xmm4
000075d5269d7352  vmovaps [rsp+0x40], xmm5
000075d5269d7358  vmovaps [rsp+0x50], xmm6
000075d5269d735e  vmovaps [rsp+0x60], xmm7
000075d5269d7364  vmovaps [rsp+0x70], xmm8
000075d5269d736a  vmovaps [rsp+0x80], xmm9
000075d5269d7373  vmovaps [rsp+0x90], xmm10
000075d5269d737c  vmovaps [rsp+0xA0], xmm11
000075d5269d7385  vmovaps [rsp+0xB0], xmm12
000075d5269d738e  vmovaps [rsp+0xC0], xmm13
000075d5269d7397  vmovaps [rsp+0xD0], xmm14
000075d5269d73a0  vmovaps [rsp+0xE0], xmm15
000075d5269d73a9  sub rsp, 0x30
000075d5269d73ad  movaps [rsp], xmm1
000075d5269d73b1  movaps [rsp+0x10], xmm6
000075d5269d73b6  movaps [rsp+0x20], xmm15
000075d5269d73bc  lea rdi, [rsp]
000075d5269d73c0  mov esi, 0x00
000075d5269d73c5  mov rax, 0x601129E62530
000075d5269d73cf  call rax
000075d5269d73d1  movaps xmm1, [rsp]
000075d5269d73d5  add rsp, 0x30
000075d5269d73d9  vmovaps xmm0, [rsp]
000075d5269d73de  vmovaps xmm2, [rsp+0x10]
000075d5269d73e4  vmovaps xmm3, [rsp+0x20]
000075d5269d73ea  vmovaps xmm4, [rsp+0x30]
000075d5269d73f0  vmovaps xmm5, [rsp+0x40]
000075d5269d73f6  vmovaps xmm6, [rsp+0x50]
000075d5269d73fc  vmovaps xmm7, [rsp+0x60]
000075d5269d7402  vmovaps xmm8, [rsp+0x70]
000075d5269d7408  vmovaps xmm9, [rsp+0x80]
000075d5269d7411  vmovaps xmm10, [rsp+0x90]
000075d5269d741a  vmovaps xmm11, [rsp+0xA0]
000075d5269d7423  vmovaps xmm12, [rsp+0xB0]
000075d5269d742c  vmovaps xmm13, [rsp+0xC0]
000075d5269d7435  vmovaps xmm14, [rsp+0xD0]
000075d5269d743e  vmovaps xmm15, [rsp+0xE0]
000075d5269d7447  add rsp, 0xF0
000075d5269d744e  pop r11
000075d5269d7450  pop r10
000075d5269d7452  pop r9
000075d5269d7454  pop r8
000075d5269d7456  pop rsi
000075d5269d7457  pop rdi
000075d5269d7458  pop rdx
000075d5269d7459  pop rcx
000075d5269d745a  pop rax
000075d5269d745b  add rsp, 0x08
000075d5269d745f  jmp 0x000075D5269D5C68
000075d5269d7464  call 0x000075D5268E5820
000075d5269d7469  jmp 0x000075D5269D5C75
000075d5269d746e  sub rsp, 0x08
000075d5269d7472  push rax
000075d5269d7473  push rcx
000075d5269d7474  push rdx
000075d5269d7475  push rdi
000075d5269d7476  push rsi
000075d5269d7477  push r8
000075d5269d7479  push r9
000075d5269d747b  push r10
000075d5269d747d  push r11
000075d5269d747f  sub rsp, 0xF0
000075d5269d7486  vmovaps [rsp], xmm0
000075d5269d748b  vmovaps [rsp+0x10], xmm1
000075d5269d7491  vmovaps [rsp+0x20], xmm2
000075d5269d7497  vmovaps [rsp+0x30], xmm3
000075d5269d749d  vmovaps [rsp+0x40], xmm4
000075d5269d74a3  vmovaps [rsp+0x50], xmm5
000075d5269d74a9  vmovaps [rsp+0x60], xmm6
000075d5269d74af  vmovaps [rsp+0x70], xmm7
000075d5269d74b5  vmovaps [rsp+0x80], xmm8
000075d5269d74be  vmovaps [rsp+0x90], xmm9
000075d5269d74c7  vmovaps [rsp+0xA0], xmm10
000075d5269d74d0  vmovaps [rsp+0xB0], xmm11
000075d5269d74d9  vmovaps [rsp+0xC0], xmm12
000075d5269d74e2  vmovaps [rsp+0xD0], xmm13
000075d5269d74eb  vmovaps [rsp+0xE0], xmm15
000075d5269d74f4  sub rsp, 0x30
000075d5269d74f8  movaps [rsp], xmm14
000075d5269d74fd  movaps [rsp+0x10], xmm4
000075d5269d7502  movaps [rsp+0x20], xmm3
000075d5269d7507  lea rdi, [rsp]
000075d5269d750b  mov esi, 0x00
000075d5269d7510  mov rax, 0x601129E62530
000075d5269d751a  call rax
000075d5269d751c  movaps xmm14, [rsp]
000075d5269d7521  add rsp, 0x30
000075d5269d7525  vmovaps xmm0, [rsp]
000075d5269d752a  vmovaps xmm1, [rsp+0x10]
000075d5269d7530  vmovaps xmm2, [rsp+0x20]
000075d5269d7536  vmovaps xmm3, [rsp+0x30]
000075d5269d753c  vmovaps xmm4, [rsp+0x40]
000075d5269d7542  vmovaps xmm5, [rsp+0x50]
000075d5269d7548  vmovaps xmm6, [rsp+0x60]
000075d5269d754e  vmovaps xmm7, [rsp+0x70]
000075d5269d7554  vmovaps xmm8, [rsp+0x80]
000075d5269d755d  vmovaps xmm9, [rsp+0x90]
000075d5269d7566  vmovaps xmm10, [rsp+0xA0]
000075d5269d756f  vmovaps xmm11, [rsp+0xB0]
000075d5269d7578  vmovaps xmm12, [rsp+0xC0]
000075d5269d7581  vmovaps xmm13, [rsp+0xD0]
000075d5269d758a  vmovaps xmm15, [rsp+0xE0]
000075d5269d7593  add rsp, 0xF0
000075d5269d759a  pop r11
000075d5269d759c  pop r10
000075d5269d759e  pop r9
000075d5269d75a0  pop r8
000075d5269d75a2  pop rsi
000075d5269d75a3  pop rdi
000075d5269d75a4  pop rdx
000075d5269d75a5  pop rcx
000075d5269d75a6  pop rax
000075d5269d75a7  add rsp, 0x08
000075d5269d75ab  jmp 0x000075D5269D5C8F
000075d5269d75b0  sub rsp, 0x08
000075d5269d75b4  push rax
000075d5269d75b5  push rcx
000075d5269d75b6  push rdx
000075d5269d75b7  push rdi
000075d5269d75b8  push rsi
000075d5269d75b9  push r8
000075d5269d75bb  push r9
000075d5269d75bd  push r10
000075d5269d75bf  push r11
000075d5269d75c1  sub rsp, 0xF0
000075d5269d75c8  vmovaps [rsp], xmm0
000075d5269d75cd  vmovaps [rsp+0x10], xmm1
000075d5269d75d3  vmovaps [rsp+0x20], xmm2
000075d5269d75d9  vmovaps [rsp+0x30], xmm3
000075d5269d75df  vmovaps [rsp+0x40], xmm4
000075d5269d75e5  vmovaps [rsp+0x50], xmm5
000075d5269d75eb  vmovaps [rsp+0x60], xmm7
000075d5269d75f1  vmovaps [rsp+0x70], xmm8
000075d5269d75f7  vmovaps [rsp+0x80], xmm9
000075d5269d7600  vmovaps [rsp+0x90], xmm10
000075d5269d7609  vmovaps [rsp+0xA0], xmm11
000075d5269d7612  vmovaps [rsp+0xB0], xmm12
000075d5269d761b  vmovaps [rsp+0xC0], xmm13
000075d5269d7624  vmovaps [rsp+0xD0], xmm14
000075d5269d762d  vmovaps [rsp+0xE0], xmm15
000075d5269d7636  sub rsp, 0x30
000075d5269d763a  movaps [rsp], xmm6
000075d5269d763e  movaps [rsp+0x10], xmm9
000075d5269d7644  movaps [rsp+0x20], xmm7
000075d5269d7649  lea rdi, [rsp]
000075d5269d764d  mov esi, 0x00
000075d5269d7652  mov rax, 0x601129E62530
000075d5269d765c  call rax
000075d5269d765e  movaps xmm6, [rsp]
000075d5269d7662  add rsp, 0x30
000075d5269d7666  vmovaps xmm0, [rsp]
000075d5269d766b  vmovaps xmm1, [rsp+0x10]
000075d5269d7671  vmovaps xmm2, [rsp+0x20]
000075d5269d7677  vmovaps xmm3, [rsp+0x30]
000075d5269d767d  vmovaps xmm4, [rsp+0x40]
000075d5269d7683  vmovaps xmm5, [rsp+0x50]
000075d5269d7689  vmovaps xmm7, [rsp+0x60]
000075d5269d768f  vmovaps xmm8, [rsp+0x70]
000075d5269d7695  vmovaps xmm9, [rsp+0x80]
000075d5269d769e  vmovaps xmm10, [rsp+0x90]
000075d5269d76a7  vmovaps xmm11, [rsp+0xA0]
000075d5269d76b0  vmovaps xmm12, [rsp+0xB0]
000075d5269d76b9  vmovaps xmm13, [rsp+0xC0]
000075d5269d76c2  vmovaps xmm14, [rsp+0xD0]
000075d5269d76cb  vmovaps xmm15, [rsp+0xE0]
000075d5269d76d4  add rsp, 0xF0
000075d5269d76db  pop r11
000075d5269d76dd  pop r10
000075d5269d76df  pop r9
000075d5269d76e1  pop r8
000075d5269d76e3  pop rsi
000075d5269d76e4  pop rdi
000075d5269d76e5  pop rdx
000075d5269d76e6  pop rcx
000075d5269d76e7  pop rax
000075d5269d76e8  add rsp, 0x08
000075d5269d76ec  jmp 0x000075D5269D5CA7
000075d5269d76f1  sub rsp, 0x08
000075d5269d76f5  push rax
000075d5269d76f6  push rcx
000075d5269d76f7  push rdx
000075d5269d76f8  push rdi
000075d5269d76f9  push rsi
000075d5269d76fa  push r8
000075d5269d76fc  push r9
000075d5269d76fe  push r10
000075d5269d7700  push r11
000075d5269d7702  sub rsp, 0xF0
000075d5269d7709  vmovaps [rsp], xmm0
000075d5269d770e  vmovaps [rsp+0x10], xmm1
000075d5269d7714  vmovaps [rsp+0x20], xmm2
000075d5269d771a  vmovaps [rsp+0x30], xmm3
000075d5269d7720  vmovaps [rsp+0x40], xmm4
000075d5269d7726  vmovaps [rsp+0x50], xmm5
000075d5269d772c  vmovaps [rsp+0x60], xmm6
000075d5269d7732  vmovaps [rsp+0x70], xmm8
000075d5269d7738  vmovaps [rsp+0x80], xmm9
000075d5269d7741  vmovaps [rsp+0x90], xmm10
000075d5269d774a  vmovaps [rsp+0xA0], xmm11
000075d5269d7753  vmovaps [rsp+0xB0], xmm12
000075d5269d775c  vmovaps [rsp+0xC0], xmm13
000075d5269d7765  vmovaps [rsp+0xD0], xmm14
000075d5269d776e  vmovaps [rsp+0xE0], xmm15
000075d5269d7777  sub rsp, 0x30
000075d5269d777b  movaps [rsp], xmm7
000075d5269d777f  movaps [rsp+0x10], xmm4
000075d5269d7784  movaps [rsp+0x20], xmm9
000075d5269d778a  lea rdi, [rsp]
000075d5269d778e  mov esi, 0x00
000075d5269d7793  mov rax, 0x601129E62530
000075d5269d779d  call rax
000075d5269d779f  movaps xmm7, [rsp]
000075d5269d77a3  add rsp, 0x30
000075d5269d77a7  vmovaps xmm0, [rsp]
000075d5269d77ac  vmovaps xmm1, [rsp+0x10]
000075d5269d77b2  vmovaps xmm2, [rsp+0x20]
000075d5269d77b8  vmovaps xmm3, [rsp+0x30]
000075d5269d77be  vmovaps xmm4, [rsp+0x40]
000075d5269d77c4  vmovaps xmm5, [rsp+0x50]
000075d5269d77ca  vmovaps xmm6, [rsp+0x60]
000075d5269d77d0  vmovaps xmm8, [rsp+0x70]
000075d5269d77d6  vmovaps xmm9, [rsp+0x80]
000075d5269d77df  vmovaps xmm10, [rsp+0x90]
000075d5269d77e8  vmovaps xmm11, [rsp+0xA0]
000075d5269d77f1  vmovaps xmm12, [rsp+0xB0]
000075d5269d77fa  vmovaps xmm13, [rsp+0xC0]
000075d5269d7803  vmovaps xmm14, [rsp+0xD0]
000075d5269d780c  vmovaps xmm15, [rsp+0xE0]
000075d5269d7815  add rsp, 0xF0
000075d5269d781c  pop r11
000075d5269d781e  pop r10
000075d5269d7820  pop r9
000075d5269d7822  pop r8
000075d5269d7824  pop rsi
000075d5269d7825  pop rdi
000075d5269d7826  pop rdx
000075d5269d7827  pop rcx
000075d5269d7828  pop rax
000075d5269d7829  add rsp, 0x08
000075d5269d782d  jmp 0x000075D5269D5CD4
000075d5269d7832  sub rsp, 0x08
000075d5269d7836  push rax
000075d5269d7837  push rcx
000075d5269d7838  push rdx
000075d5269d7839  push rdi
000075d5269d783a  push rsi
000075d5269d783b  push r8
000075d5269d783d  push r9
000075d5269d783f  push r10
000075d5269d7841  push r11
000075d5269d7843  sub rsp, 0xF0
000075d5269d784a  vmovaps [rsp], xmm0
000075d5269d784f  vmovaps [rsp+0x10], xmm1
000075d5269d7855  vmovaps [rsp+0x20], xmm2
000075d5269d785b  vmovaps [rsp+0x30], xmm3
000075d5269d7861  vmovaps [rsp+0x40], xmm5
000075d5269d7867  vmovaps [rsp+0x50], xmm6
000075d5269d786d  vmovaps [rsp+0x60], xmm7
000075d5269d7873  vmovaps [rsp+0x70], xmm8
000075d5269d7879  vmovaps [rsp+0x80], xmm9
000075d5269d7882  vmovaps [rsp+0x90], xmm10
000075d5269d788b  vmovaps [rsp+0xA0], xmm11
000075d5269d7894  vmovaps [rsp+0xB0], xmm12
000075d5269d789d  vmovaps [rsp+0xC0], xmm13
000075d5269d78a6  vmovaps [rsp+0xD0], xmm14
000075d5269d78af  vmovaps [rsp+0xE0], xmm15
000075d5269d78b8  sub rsp, 0x30
000075d5269d78bc  movaps [rsp], xmm4
000075d5269d78c0  movaps [rsp+0x10], xmm15
000075d5269d78c6  movaps [rsp+0x20], xmm9
000075d5269d78cc  lea rdi, [rsp]
000075d5269d78d0  mov esi, 0x00
000075d5269d78d5  mov rax, 0x601129E62530
000075d5269d78df  call rax
000075d5269d78e1  movaps xmm4, [rsp]
000075d5269d78e5  add rsp, 0x30
000075d5269d78e9  vmovaps xmm0, [rsp]
000075d5269d78ee  vmovaps xmm1, [rsp+0x10]
000075d5269d78f4  vmovaps xmm2, [rsp+0x20]
000075d5269d78fa  vmovaps xmm3, [rsp+0x30]
000075d5269d7900  vmovaps xmm5, [rsp+0x40]
000075d5269d7906  vmovaps xmm6, [rsp+0x50]
000075d5269d790c  vmovaps xmm7, [rsp+0x60]
000075d5269d7912  vmovaps xmm8, [rsp+0x70]
000075d5269d7918  vmovaps xmm9, [rsp+0x80]
000075d5269d7921  vmovaps xmm10, [rsp+0x90]
000075d5269d792a  vmovaps xmm11, [rsp+0xA0]
000075d5269d7933  vmovaps xmm12, [rsp+0xB0]
000075d5269d793c  vmovaps xmm13, [rsp+0xC0]
000075d5269d7945  vmovaps xmm14, [rsp+0xD0]
000075d5269d794e  vmovaps xmm15, [rsp+0xE0]
000075d5269d7957  add rsp, 0xF0
000075d5269d795e  pop r11
000075d5269d7960  pop r10
000075d5269d7962  pop r9
000075d5269d7964  pop r8
000075d5269d7966  pop rsi
000075d5269d7967  pop rdi
000075d5269d7968  pop rdx
000075d5269d7969  pop rcx
000075d5269d796a  pop rax
000075d5269d796b  add rsp, 0x08
000075d5269d796f  jmp 0x000075D5269D5CF9
000075d5269d7974  call 0x000075D5268E5820
000075d5269d7979  jmp 0x000075D5269D5D06
000075d5269d797e  sub rsp, 0x08
000075d5269d7982  push rax
000075d5269d7983  push rcx
000075d5269d7984  push rdx
000075d5269d7985  push rdi
000075d5269d7986  push rsi
000075d5269d7987  push r8
000075d5269d7989  push r9
000075d5269d798b  push r10
000075d5269d798d  push r11
000075d5269d798f  sub rsp, 0xF0
000075d5269d7996  vmovaps [rsp], xmm0
000075d5269d799b  vmovaps [rsp+0x10], xmm1
000075d5269d79a1  vmovaps [rsp+0x20], xmm2
000075d5269d79a7  vmovaps [rsp+0x30], xmm4
000075d5269d79ad  vmovaps [rsp+0x40], xmm5
000075d5269d79b3  vmovaps [rsp+0x50], xmm6
000075d5269d79b9  vmovaps [rsp+0x60], xmm7
000075d5269d79bf  vmovaps [rsp+0x70], xmm8
000075d5269d79c5  vmovaps [rsp+0x80], xmm9
000075d5269d79ce  vmovaps [rsp+0x90], xmm10
000075d5269d79d7  vmovaps [rsp+0xA0], xmm11
000075d5269d79e0  vmovaps [rsp+0xB0], xmm12
000075d5269d79e9  vmovaps [rsp+0xC0], xmm13
000075d5269d79f2  vmovaps [rsp+0xD0], xmm14
000075d5269d79fb  vmovaps [rsp+0xE0], xmm15
000075d5269d7a04  sub rsp, 0x30
000075d5269d7a08  movaps [rsp], xmm3
000075d5269d7a0c  movaps [rsp+0x10], xmm1
000075d5269d7a11  movaps [rsp+0x20], xmm9
000075d5269d7a17  lea rdi, [rsp]
000075d5269d7a1b  mov esi, 0x00
000075d5269d7a20  mov rax, 0x601129E62530
000075d5269d7a2a  call rax
000075d5269d7a2c  movaps xmm3, [rsp]
000075d5269d7a30  add rsp, 0x30
000075d5269d7a34  vmovaps xmm0, [rsp]
000075d5269d7a39  vmovaps xmm1, [rsp+0x10]
000075d5269d7a3f  vmovaps xmm2, [rsp+0x20]
000075d5269d7a45  vmovaps xmm4, [rsp+0x30]
000075d5269d7a4b  vmovaps xmm5, [rsp+0x40]
000075d5269d7a51  vmovaps xmm6, [rsp+0x50]
000075d5269d7a57  vmovaps xmm7, [rsp+0x60]
000075d5269d7a5d  vmovaps xmm8, [rsp+0x70]
000075d5269d7a63  vmovaps xmm9, [rsp+0x80]
000075d5269d7a6c  vmovaps xmm10, [rsp+0x90]
000075d5269d7a75  vmovaps xmm11, [rsp+0xA0]
000075d5269d7a7e  vmovaps xmm12, [rsp+0xB0]
000075d5269d7a87  vmovaps xmm13, [rsp+0xC0]
000075d5269d7a90  vmovaps xmm14, [rsp+0xD0]
000075d5269d7a99  vmovaps xmm15, [rsp+0xE0]
000075d5269d7aa2  add rsp, 0xF0
000075d5269d7aa9  pop r11
000075d5269d7aab  pop r10
000075d5269d7aad  pop r9
000075d5269d7aaf  pop r8
000075d5269d7ab1  pop rsi
000075d5269d7ab2  pop rdi
000075d5269d7ab3  pop rdx
000075d5269d7ab4  pop rcx
000075d5269d7ab5  pop rax
000075d5269d7ab6  add rsp, 0x08
000075d5269d7aba  jmp 0x000075D5269D5D43
000075d5269d7abf  sub rsp, 0x08
000075d5269d7ac3  push rax
000075d5269d7ac4  push rcx
000075d5269d7ac5  push rdx
000075d5269d7ac6  push rdi
000075d5269d7ac7  push rsi
000075d5269d7ac8  push r8
000075d5269d7aca  push r9
000075d5269d7acc  push r10
000075d5269d7ace  push r11
000075d5269d7ad0  sub rsp, 0xF0
000075d5269d7ad7  vmovaps [rsp], xmm0
000075d5269d7adc  vmovaps [rsp+0x10], xmm2
000075d5269d7ae2  vmovaps [rsp+0x20], xmm3
000075d5269d7ae8  vmovaps [rsp+0x30], xmm4
000075d5269d7aee  vmovaps [rsp+0x40], xmm5
000075d5269d7af4  vmovaps [rsp+0x50], xmm6
000075d5269d7afa  vmovaps [rsp+0x60], xmm7
000075d5269d7b00  vmovaps [rsp+0x70], xmm8
000075d5269d7b06  vmovaps [rsp+0x80], xmm9
000075d5269d7b0f  vmovaps [rsp+0x90], xmm10
000075d5269d7b18  vmovaps [rsp+0xA0], xmm11
000075d5269d7b21  vmovaps [rsp+0xB0], xmm12
000075d5269d7b2a  vmovaps [rsp+0xC0], xmm13
000075d5269d7b33  vmovaps [rsp+0xD0], xmm14
000075d5269d7b3c  vmovaps [rsp+0xE0], xmm15
000075d5269d7b45  sub rsp, 0x30
000075d5269d7b49  movaps [rsp], xmm1
000075d5269d7b4d  movaps [rsp+0x10], xmm15
000075d5269d7b53  movaps [rsp+0x20], xmm9
000075d5269d7b59  lea rdi, [rsp]
000075d5269d7b5d  mov esi, 0x00
000075d5269d7b62  mov rax, 0x601129E62530
000075d5269d7b6c  call rax
000075d5269d7b6e  movaps xmm1, [rsp]
000075d5269d7b72  add rsp, 0x30
000075d5269d7b76  vmovaps xmm0, [rsp]
000075d5269d7b7b  vmovaps xmm2, [rsp+0x10]
000075d5269d7b81  vmovaps xmm3, [rsp+0x20]
000075d5269d7b87  vmovaps xmm4, [rsp+0x30]
000075d5269d7b8d  vmovaps xmm5, [rsp+0x40]
000075d5269d7b93  vmovaps xmm6, [rsp+0x50]
000075d5269d7b99  vmovaps xmm7, [rsp+0x60]
000075d5269d7b9f  vmovaps xmm8, [rsp+0x70]
000075d5269d7ba5  vmovaps xmm9, [rsp+0x80]
000075d5269d7bae  vmovaps xmm10, [rsp+0x90]
000075d5269d7bb7  vmovaps xmm11, [rsp+0xA0]
000075d5269d7bc0  vmovaps xmm12, [rsp+0xB0]
000075d5269d7bc9  vmovaps xmm13, [rsp+0xC0]
000075d5269d7bd2  vmovaps xmm14, [rsp+0xD0]
000075d5269d7bdb  vmovaps xmm15, [rsp+0xE0]
000075d5269d7be4  add rsp, 0xF0
000075d5269d7beb  pop r11
000075d5269d7bed  pop r10
000075d5269d7bef  pop r9
000075d5269d7bf1  pop r8
000075d5269d7bf3  pop rsi
000075d5269d7bf4  pop rdi
000075d5269d7bf5  pop rdx
000075d5269d7bf6  pop rcx
000075d5269d7bf7  pop rax
000075d5269d7bf8  add rsp, 0x08
000075d5269d7bfc  jmp 0x000075D5269D5DCB
000075d5269d7c01  call 0x000075D5268E5820
000075d5269d7c06  jmp 0x000075D5269D5DD8
000075d5269d7c0b  sub rsp, 0x08
000075d5269d7c0f  push rax
000075d5269d7c10  push rcx
000075d5269d7c11  push rdx
000075d5269d7c12  push rdi
000075d5269d7c13  push rsi
000075d5269d7c14  push r8
000075d5269d7c16  push r9
000075d5269d7c18  push r10
000075d5269d7c1a  push r11
000075d5269d7c1c  sub rsp, 0xF0
000075d5269d7c23  vmovaps [rsp], xmm0
000075d5269d7c28  vmovaps [rsp+0x10], xmm2
000075d5269d7c2e  vmovaps [rsp+0x20], xmm3
000075d5269d7c34  vmovaps [rsp+0x30], xmm4
000075d5269d7c3a  vmovaps [rsp+0x40], xmm5
000075d5269d7c40  vmovaps [rsp+0x50], xmm6
000075d5269d7c46  vmovaps [rsp+0x60], xmm7
000075d5269d7c4c  vmovaps [rsp+0x70], xmm8
000075d5269d7c52  vmovaps [rsp+0x80], xmm9
000075d5269d7c5b  vmovaps [rsp+0x90], xmm10
000075d5269d7c64  vmovaps [rsp+0xA0], xmm11
000075d5269d7c6d  vmovaps [rsp+0xB0], xmm12
000075d5269d7c76  vmovaps [rsp+0xC0], xmm13
000075d5269d7c7f  vmovaps [rsp+0xD0], xmm14
000075d5269d7c88  vmovaps [rsp+0xE0], xmm15
000075d5269d7c91  sub rsp, 0x30
000075d5269d7c95  movaps [rsp], xmm1
000075d5269d7c99  movaps [rsp+0x10], xmm5
000075d5269d7c9e  movaps [rsp+0x20], xmm7
000075d5269d7ca3  lea rdi, [rsp]
000075d5269d7ca7  mov esi, 0x00
000075d5269d7cac  mov rax, 0x601129E62530
000075d5269d7cb6  call rax
000075d5269d7cb8  movaps xmm1, [rsp]
000075d5269d7cbc  add rsp, 0x30
000075d5269d7cc0  vmovaps xmm0, [rsp]
000075d5269d7cc5  vmovaps xmm2, [rsp+0x10]
000075d5269d7ccb  vmovaps xmm3, [rsp+0x20]
000075d5269d7cd1  vmovaps xmm4, [rsp+0x30]
000075d5269d7cd7  vmovaps xmm5, [rsp+0x40]
000075d5269d7cdd  vmovaps xmm6, [rsp+0x50]
000075d5269d7ce3  vmovaps xmm7, [rsp+0x60]
000075d5269d7ce9  vmovaps xmm8, [rsp+0x70]
000075d5269d7cef  vmovaps xmm9, [rsp+0x80]
000075d5269d7cf8  vmovaps xmm10, [rsp+0x90]
000075d5269d7d01  vmovaps xmm11, [rsp+0xA0]
000075d5269d7d0a  vmovaps xmm12, [rsp+0xB0]
000075d5269d7d13  vmovaps xmm13, [rsp+0xC0]
000075d5269d7d1c  vmovaps xmm14, [rsp+0xD0]
000075d5269d7d25  vmovaps xmm15, [rsp+0xE0]
000075d5269d7d2e  add rsp, 0xF0
000075d5269d7d35  pop r11
000075d5269d7d37  pop r10
000075d5269d7d39  pop r9
000075d5269d7d3b  pop r8
000075d5269d7d3d  pop rsi
000075d5269d7d3e  pop rdi
000075d5269d7d3f  pop rdx
000075d5269d7d40  pop rcx
000075d5269d7d41  pop rax
000075d5269d7d42  add rsp, 0x08
000075d5269d7d46  jmp 0x000075D5269D5E7D
000075d5269d7d4b  sub rsp, 0x08
000075d5269d7d4f  push rax
000075d5269d7d50  push rcx
000075d5269d7d51  push rdx
000075d5269d7d52  push rdi
000075d5269d7d53  push rsi
000075d5269d7d54  push r8
000075d5269d7d56  push r9
000075d5269d7d58  push r10
000075d5269d7d5a  push r11
000075d5269d7d5c  sub rsp, 0xF0
000075d5269d7d63  vmovaps [rsp], xmm0
000075d5269d7d68  vmovaps [rsp+0x10], xmm1
000075d5269d7d6e  vmovaps [rsp+0x20], xmm2
000075d5269d7d74  vmovaps [rsp+0x30], xmm3
000075d5269d7d7a  vmovaps [rsp+0x40], xmm4
000075d5269d7d80  vmovaps [rsp+0x50], xmm5
000075d5269d7d86  vmovaps [rsp+0x60], xmm6
000075d5269d7d8c  vmovaps [rsp+0x70], xmm8
000075d5269d7d92  vmovaps [rsp+0x80], xmm9
000075d5269d7d9b  vmovaps [rsp+0x90], xmm10
000075d5269d7da4  vmovaps [rsp+0xA0], xmm11
000075d5269d7dad  vmovaps [rsp+0xB0], xmm12
000075d5269d7db6  vmovaps [rsp+0xC0], xmm13
000075d5269d7dbf  vmovaps [rsp+0xD0], xmm14
000075d5269d7dc8  vmovaps [rsp+0xE0], xmm15
000075d5269d7dd1  sub rsp, 0x30
000075d5269d7dd5  movaps [rsp], xmm7
000075d5269d7dd9  movaps [rsp+0x10], xmm5
000075d5269d7dde  movaps [rsp+0x20], xmm15
000075d5269d7de4  lea rdi, [rsp]
000075d5269d7de8  mov esi, 0x00
000075d5269d7ded  mov rax, 0x601129E62530
000075d5269d7df7  call rax
000075d5269d7df9  movaps xmm7, [rsp]
000075d5269d7dfd  add rsp, 0x30
000075d5269d7e01  vmovaps xmm0, [rsp]
000075d5269d7e06  vmovaps xmm1, [rsp+0x10]
000075d5269d7e0c  vmovaps xmm2, [rsp+0x20]
000075d5269d7e12  vmovaps xmm3, [rsp+0x30]
000075d5269d7e18  vmovaps xmm4, [rsp+0x40]
000075d5269d7e1e  vmovaps xmm5, [rsp+0x50]
000075d5269d7e24  vmovaps xmm6, [rsp+0x60]
000075d5269d7e2a  vmovaps xmm8, [rsp+0x70]
000075d5269d7e30  vmovaps xmm9, [rsp+0x80]
000075d5269d7e39  vmovaps xmm10, [rsp+0x90]
000075d5269d7e42  vmovaps xmm11, [rsp+0xA0]
000075d5269d7e4b  vmovaps xmm12, [rsp+0xB0]
000075d5269d7e54  vmovaps xmm13, [rsp+0xC0]
000075d5269d7e5d  vmovaps xmm14, [rsp+0xD0]
000075d5269d7e66  vmovaps xmm15, [rsp+0xE0]
000075d5269d7e6f  add rsp, 0xF0
000075d5269d7e76  pop r11
000075d5269d7e78  pop r10
000075d5269d7e7a  pop r9
000075d5269d7e7c  pop r8
000075d5269d7e7e  pop rsi
000075d5269d7e7f  pop rdi
000075d5269d7e80  pop rdx
000075d5269d7e81  pop rcx
000075d5269d7e82  pop rax
000075d5269d7e83  add rsp, 0x08
000075d5269d7e87  jmp 0x000075D5269D5EB3
000075d5269d7e8c  call 0x000075D5268D64F0
000075d5269d7e91  jmp 0x000075D5269D5EC0
000075d5269d7e96  sub rsp, 0x08
000075d5269d7e9a  push rax
000075d5269d7e9b  push rcx
000075d5269d7e9c  push rdx
000075d5269d7e9d  push rdi
000075d5269d7e9e  push rsi
000075d5269d7e9f  push r8
000075d5269d7ea1  push r9
000075d5269d7ea3  push r10
000075d5269d7ea5  push r11
000075d5269d7ea7  sub rsp, 0xF0
000075d5269d7eae  vmovaps [rsp], xmm0
000075d5269d7eb3  vmovaps [rsp+0x10], xmm1
000075d5269d7eb9  vmovaps [rsp+0x20], xmm2
000075d5269d7ebf  vmovaps [rsp+0x30], xmm3
000075d5269d7ec5  vmovaps [rsp+0x40], xmm4
000075d5269d7ecb  vmovaps [rsp+0x50], xmm5
000075d5269d7ed1  vmovaps [rsp+0x60], xmm6
000075d5269d7ed7  vmovaps [rsp+0x70], xmm7
000075d5269d7edd  vmovaps [rsp+0x80], xmm8
000075d5269d7ee6  vmovaps [rsp+0x90], xmm9
000075d5269d7eef  vmovaps [rsp+0xA0], xmm10
000075d5269d7ef8  vmovaps [rsp+0xB0], xmm11
000075d5269d7f01  vmovaps [rsp+0xC0], xmm12
000075d5269d7f0a  vmovaps [rsp+0xD0], xmm13
000075d5269d7f13  vmovaps [rsp+0xE0], xmm14
000075d5269d7f1c  sub rsp, 0x30
000075d5269d7f20  movaps [rsp], xmm15
000075d5269d7f25  movaps [rsp+0x10], xmm5
000075d5269d7f2a  movaps [rsp+0x20], xmm3
000075d5269d7f2f  lea rdi, [rsp]
000075d5269d7f33  mov esi, 0x00
000075d5269d7f38  mov rax, 0x601129E62530
000075d5269d7f42  call rax
000075d5269d7f44  movaps xmm15, [rsp]
000075d5269d7f49  add rsp, 0x30
000075d5269d7f4d  vmovaps xmm0, [rsp]
000075d5269d7f52  vmovaps xmm1, [rsp+0x10]
000075d5269d7f58  vmovaps xmm2, [rsp+0x20]
000075d5269d7f5e  vmovaps xmm3, [rsp+0x30]
000075d5269d7f64  vmovaps xmm4, [rsp+0x40]
000075d5269d7f6a  vmovaps xmm5, [rsp+0x50]
000075d5269d7f70  vmovaps xmm6, [rsp+0x60]
000075d5269d7f76  vmovaps xmm7, [rsp+0x70]
000075d5269d7f7c  vmovaps xmm8, [rsp+0x80]
000075d5269d7f85  vmovaps xmm9, [rsp+0x90]
000075d5269d7f8e  vmovaps xmm10, [rsp+0xA0]
000075d5269d7f97  vmovaps xmm11, [rsp+0xB0]
000075d5269d7fa0  vmovaps xmm12, [rsp+0xC0]
000075d5269d7fa9  vmovaps xmm13, [rsp+0xD0]
000075d5269d7fb2  vmovaps xmm14, [rsp+0xE0]
000075d5269d7fbb  add rsp, 0xF0
000075d5269d7fc2  pop r11
000075d5269d7fc4  pop r10
000075d5269d7fc6  pop r9
000075d5269d7fc8  pop r8
000075d5269d7fca  pop rsi
000075d5269d7fcb  pop rdi
000075d5269d7fcc  pop rdx
000075d5269d7fcd  pop rcx
000075d5269d7fce  pop rax
000075d5269d7fcf  add rsp, 0x08
000075d5269d7fd3  jmp 0x000075D5269D5EE6
000075d5269d7fd8  sub rsp, 0x08
000075d5269d7fdc  push rax
000075d5269d7fdd  push rcx
000075d5269d7fde  push rdx
000075d5269d7fdf  push rdi
000075d5269d7fe0  push rsi
000075d5269d7fe1  push r8
000075d5269d7fe3  push r9
000075d5269d7fe5  push r10
000075d5269d7fe7  push r11
000075d5269d7fe9  sub rsp, 0xF0
000075d5269d7ff0  vmovaps [rsp], xmm0
000075d5269d7ff5  vmovaps [rsp+0x10], xmm2
000075d5269d7ffb  vmovaps [rsp+0x20], xmm3
000075d5269d8001  vmovaps [rsp+0x30], xmm4
000075d5269d8007  vmovaps [rsp+0x40], xmm5
000075d5269d800d  vmovaps [rsp+0x50], xmm6
000075d5269d8013  vmovaps [rsp+0x60], xmm7
000075d5269d8019  vmovaps [rsp+0x70], xmm8
000075d5269d801f  vmovaps [rsp+0x80], xmm9
000075d5269d8028  vmovaps [rsp+0x90], xmm10
000075d5269d8031  vmovaps [rsp+0xA0], xmm11
000075d5269d803a  vmovaps [rsp+0xB0], xmm12
000075d5269d8043  vmovaps [rsp+0xC0], xmm13
000075d5269d804c  vmovaps [rsp+0xD0], xmm14
000075d5269d8055  vmovaps [rsp+0xE0], xmm15
000075d5269d805e  sub rsp, 0x30
000075d5269d8062  movaps [rsp], xmm1
000075d5269d8066  movaps [rsp+0x10], xmm5
000075d5269d806b  movaps [rsp+0x20], xmm4
000075d5269d8070  lea rdi, [rsp]
000075d5269d8074  mov esi, 0x00
000075d5269d8079  mov rax, 0x601129E62530
000075d5269d8083  call rax
000075d5269d8085  movaps xmm1, [rsp]
000075d5269d8089  add rsp, 0x30
000075d5269d808d  vmovaps xmm0, [rsp]
000075d5269d8092  vmovaps xmm2, [rsp+0x10]
000075d5269d8098  vmovaps xmm3, [rsp+0x20]
000075d5269d809e  vmovaps xmm4, [rsp+0x30]
000075d5269d80a4  vmovaps xmm5, [rsp+0x40]
000075d5269d80aa  vmovaps xmm6, [rsp+0x50]
000075d5269d80b0  vmovaps xmm7, [rsp+0x60]
000075d5269d80b6  vmovaps xmm8, [rsp+0x70]
000075d5269d80bc  vmovaps xmm9, [rsp+0x80]
000075d5269d80c5  vmovaps xmm10, [rsp+0x90]
000075d5269d80ce  vmovaps xmm11, [rsp+0xA0]
000075d5269d80d7  vmovaps xmm12, [rsp+0xB0]
000075d5269d80e0  vmovaps xmm13, [rsp+0xC0]
000075d5269d80e9  vmovaps xmm14, [rsp+0xD0]
000075d5269d80f2  vmovaps xmm15, [rsp+0xE0]
000075d5269d80fb  add rsp, 0xF0
000075d5269d8102  pop r11
000075d5269d8104  pop r10
000075d5269d8106  pop r9
000075d5269d8108  pop r8
000075d5269d810a  pop rsi
000075d5269d810b  pop rdi
000075d5269d810c  pop rdx
000075d5269d810d  pop rcx
000075d5269d810e  pop rax
000075d5269d810f  add rsp, 0x08
000075d5269d8113  jmp 0x000075D5269D5F06
000075d5269d8118  sub rsp, 0x08
000075d5269d811c  push rax
000075d5269d811d  push rcx
000075d5269d811e  push rdx
000075d5269d811f  push rdi
000075d5269d8120  push rsi
000075d5269d8121  push r8
000075d5269d8123  push r9
000075d5269d8125  push r10
000075d5269d8127  push r11
000075d5269d8129  sub rsp, 0xF0
000075d5269d8130  vmovaps [rsp], xmm0
000075d5269d8135  vmovaps [rsp+0x10], xmm1
000075d5269d813b  vmovaps [rsp+0x20], xmm2
000075d5269d8141  vmovaps [rsp+0x30], xmm3
000075d5269d8147  vmovaps [rsp+0x40], xmm5
000075d5269d814d  vmovaps [rsp+0x50], xmm6
000075d5269d8153  vmovaps [rsp+0x60], xmm7
000075d5269d8159  vmovaps [rsp+0x70], xmm8
000075d5269d815f  vmovaps [rsp+0x80], xmm9
000075d5269d8168  vmovaps [rsp+0x90], xmm10
000075d5269d8171  vmovaps [rsp+0xA0], xmm11
000075d5269d817a  vmovaps [rsp+0xB0], xmm12
000075d5269d8183  vmovaps [rsp+0xC0], xmm13
000075d5269d818c  vmovaps [rsp+0xD0], xmm14
000075d5269d8195  vmovaps [rsp+0xE0], xmm15
000075d5269d819e  sub rsp, 0x30
000075d5269d81a2  movaps [rsp], xmm4
000075d5269d81a6  movaps [rsp+0x10], xmm3
000075d5269d81ab  movaps [rsp+0x20], xmm5
000075d5269d81b0  lea rdi, [rsp]
000075d5269d81b4  mov esi, 0x00
000075d5269d81b9  mov rax, 0x601129E62530
000075d5269d81c3  call rax
000075d5269d81c5  movaps xmm4, [rsp]
000075d5269d81c9  add rsp, 0x30
000075d5269d81cd  vmovaps xmm0, [rsp]
000075d5269d81d2  vmovaps xmm1, [rsp+0x10]
000075d5269d81d8  vmovaps xmm2, [rsp+0x20]
000075d5269d81de  vmovaps xmm3, [rsp+0x30]
000075d5269d81e4  vmovaps xmm5, [rsp+0x40]
000075d5269d81ea  vmovaps xmm6, [rsp+0x50]
000075d5269d81f0  vmovaps xmm7, [rsp+0x60]
000075d5269d81f6  vmovaps xmm8, [rsp+0x70]
000075d5269d81fc  vmovaps xmm9, [rsp+0x80]
000075d5269d8205  vmovaps xmm10, [rsp+0x90]
000075d5269d820e  vmovaps xmm11, [rsp+0xA0]
000075d5269d8217  vmovaps xmm12, [rsp+0xB0]
000075d5269d8220  vmovaps xmm13, [rsp+0xC0]
000075d5269d8229  vmovaps xmm14, [rsp+0xD0]
000075d5269d8232  vmovaps xmm15, [rsp+0xE0]
000075d5269d823b  add rsp, 0xF0
000075d5269d8242  pop r11
000075d5269d8244  pop r10
000075d5269d8246  pop r9
000075d5269d8248  pop r8
000075d5269d824a  pop rsi
000075d5269d824b  pop rdi
000075d5269d824c  pop rdx
000075d5269d824d  pop rcx
000075d5269d824e  pop rax
000075d5269d824f  add rsp, 0x08
000075d5269d8253  jmp 0x000075D5269D5F54
000075d5269d8258  call 0x000075D5268D64F0
000075d5269d825d  jmp 0x000075D5269D5F61
000075d5269d8262  sub rsp, 0x08
000075d5269d8266  push rax
000075d5269d8267  push rcx
000075d5269d8268  push rdx
000075d5269d8269  push rdi
000075d5269d826a  push rsi
000075d5269d826b  push r8
000075d5269d826d  push r9
000075d5269d826f  push r10
000075d5269d8271  push r11
000075d5269d8273  sub rsp, 0xF0
000075d5269d827a  vmovaps [rsp], xmm0
000075d5269d827f  vmovaps [rsp+0x10], xmm1
000075d5269d8285  vmovaps [rsp+0x20], xmm2
000075d5269d828b  vmovaps [rsp+0x30], xmm3
000075d5269d8291  vmovaps [rsp+0x40], xmm4
000075d5269d8297  vmovaps [rsp+0x50], xmm6
000075d5269d829d  vmovaps [rsp+0x60], xmm7
000075d5269d82a3  vmovaps [rsp+0x70], xmm8
000075d5269d82a9  vmovaps [rsp+0x80], xmm9
000075d5269d82b2  vmovaps [rsp+0x90], xmm10
000075d5269d82bb  vmovaps [rsp+0xA0], xmm11
000075d5269d82c4  vmovaps [rsp+0xB0], xmm12
000075d5269d82cd  vmovaps [rsp+0xC0], xmm13
000075d5269d82d6  vmovaps [rsp+0xD0], xmm14
000075d5269d82df  vmovaps [rsp+0xE0], xmm15
000075d5269d82e8  sub rsp, 0x30
000075d5269d82ec  movaps [rsp], xmm5
000075d5269d82f0  movaps [rsp+0x10], xmm6
000075d5269d82f5  movaps [rsp+0x20], xmm3
000075d5269d82fa  lea rdi, [rsp]
000075d5269d82fe  mov esi, 0x00
000075d5269d8303  mov rax, 0x601129E62530
000075d5269d830d  call rax
000075d5269d830f  movaps xmm5, [rsp]
000075d5269d8313  add rsp, 0x30
000075d5269d8317  vmovaps xmm0, [rsp]
000075d5269d831c  vmovaps xmm1, [rsp+0x10]
000075d5269d8322  vmovaps xmm2, [rsp+0x20]
000075d5269d8328  vmovaps xmm3, [rsp+0x30]
000075d5269d832e  vmovaps xmm4, [rsp+0x40]
000075d5269d8334  vmovaps xmm6, [rsp+0x50]
000075d5269d833a  vmovaps xmm7, [rsp+0x60]
000075d5269d8340  vmovaps xmm8, [rsp+0x70]
000075d5269d8346  vmovaps xmm9, [rsp+0x80]
000075d5269d834f  vmovaps xmm10, [rsp+0x90]
000075d5269d8358  vmovaps xmm11, [rsp+0xA0]
000075d5269d8361  vmovaps xmm12, [rsp+0xB0]
000075d5269d836a  vmovaps xmm13, [rsp+0xC0]
000075d5269d8373  vmovaps xmm14, [rsp+0xD0]
000075d5269d837c  vmovaps xmm15, [rsp+0xE0]
000075d5269d8385  add rsp, 0xF0
000075d5269d838c  pop r11
000075d5269d838e  pop r10
000075d5269d8390  pop r9
000075d5269d8392  pop r8
000075d5269d8394  pop rsi
000075d5269d8395  pop rdi
000075d5269d8396  pop rdx
000075d5269d8397  pop rcx
000075d5269d8398  pop rax
000075d5269d8399  add rsp, 0x08
000075d5269d839d  jmp 0x000075D5269D5F87
000075d5269d83a2  sub rsp, 0x08
000075d5269d83a6  push rax
000075d5269d83a7  push rcx
000075d5269d83a8  push rdx
000075d5269d83a9  push rdi
000075d5269d83aa  push rsi
000075d5269d83ab  push r8
000075d5269d83ad  push r9
000075d5269d83af  push r10
000075d5269d83b1  push r11
000075d5269d83b3  sub rsp, 0xF0
000075d5269d83ba  vmovaps [rsp], xmm0
000075d5269d83bf  vmovaps [rsp+0x10], xmm1
000075d5269d83c5  vmovaps [rsp+0x20], xmm2
000075d5269d83cb  vmovaps [rsp+0x30], xmm3
000075d5269d83d1  vmovaps [rsp+0x40], xmm4
000075d5269d83d7  vmovaps [rsp+0x50], xmm5
000075d5269d83dd  vmovaps [rsp+0x60], xmm7
000075d5269d83e3  vmovaps [rsp+0x70], xmm8
000075d5269d83e9  vmovaps [rsp+0x80], xmm9
000075d5269d83f2  vmovaps [rsp+0x90], xmm10
000075d5269d83fb  vmovaps [rsp+0xA0], xmm11
000075d5269d8404  vmovaps [rsp+0xB0], xmm12
000075d5269d840d  vmovaps [rsp+0xC0], xmm13
000075d5269d8416  vmovaps [rsp+0xD0], xmm14
000075d5269d841f  vmovaps [rsp+0xE0], xmm15
000075d5269d8428  sub rsp, 0x30
000075d5269d842c  movaps [rsp], xmm6
000075d5269d8430  movaps [rsp+0x10], xmm9
000075d5269d8436  movaps [rsp+0x20], xmm1
000075d5269d843b  lea rdi, [rsp]
000075d5269d843f  mov esi, 0x00
000075d5269d8444  mov rax, 0x601129E62530
000075d5269d844e  call rax
000075d5269d8450  movaps xmm6, [rsp]
000075d5269d8454  add rsp, 0x30
000075d5269d8458  vmovaps xmm0, [rsp]
000075d5269d845d  vmovaps xmm1, [rsp+0x10]
000075d5269d8463  vmovaps xmm2, [rsp+0x20]
000075d5269d8469  vmovaps xmm3, [rsp+0x30]
000075d5269d846f  vmovaps xmm4, [rsp+0x40]
000075d5269d8475  vmovaps xmm5, [rsp+0x50]
000075d5269d847b  vmovaps xmm7, [rsp+0x60]
000075d5269d8481  vmovaps xmm8, [rsp+0x70]
000075d5269d8487  vmovaps xmm9, [rsp+0x80]
000075d5269d8490  vmovaps xmm10, [rsp+0x90]
000075d5269d8499  vmovaps xmm11, [rsp+0xA0]
000075d5269d84a2  vmovaps xmm12, [rsp+0xB0]
000075d5269d84ab  vmovaps xmm13, [rsp+0xC0]
000075d5269d84b4  vmovaps xmm14, [rsp+0xD0]
000075d5269d84bd  vmovaps xmm15, [rsp+0xE0]
000075d5269d84c6  add rsp, 0xF0
000075d5269d84cd  pop r11
000075d5269d84cf  pop r10
000075d5269d84d1  pop r9
000075d5269d84d3  pop r8
000075d5269d84d5  pop rsi
000075d5269d84d6  pop rdi
000075d5269d84d7  pop rdx
000075d5269d84d8  pop rcx
000075d5269d84d9  pop rax
000075d5269d84da  add rsp, 0x08
000075d5269d84de  jmp 0x000075D5269D5FAB
000075d5269d84e3  sub rsp, 0x08
000075d5269d84e7  push rax
000075d5269d84e8  push rcx
000075d5269d84e9  push rdx
000075d5269d84ea  push rdi
000075d5269d84eb  push rsi
000075d5269d84ec  push r8
000075d5269d84ee  push r9
000075d5269d84f0  push r10
000075d5269d84f2  push r11
000075d5269d84f4  sub rsp, 0xF0
000075d5269d84fb  vmovaps [rsp], xmm0
000075d5269d8500  vmovaps [rsp+0x10], xmm1
000075d5269d8506  vmovaps [rsp+0x20], xmm2
000075d5269d850c  vmovaps [rsp+0x30], xmm3
000075d5269d8512  vmovaps [rsp+0x40], xmm4
000075d5269d8518  vmovaps [rsp+0x50], xmm5
000075d5269d851e  vmovaps [rsp+0x60], xmm6
000075d5269d8524  vmovaps [rsp+0x70], xmm7
000075d5269d852a  vmovaps [rsp+0x80], xmm8
000075d5269d8533  vmovaps [rsp+0x90], xmm10
000075d5269d853c  vmovaps [rsp+0xA0], xmm11
000075d5269d8545  vmovaps [rsp+0xB0], xmm12
000075d5269d854e  vmovaps [rsp+0xC0], xmm13
000075d5269d8557  vmovaps [rsp+0xD0], xmm14
000075d5269d8560  vmovaps [rsp+0xE0], xmm15
000075d5269d8569  sub rsp, 0x30
000075d5269d856d  movaps [rsp], xmm9
000075d5269d8572  movaps [rsp+0x10], xmm3
000075d5269d8577  movaps [rsp+0x20], xmm1
000075d5269d857c  lea rdi, [rsp]
000075d5269d8580  mov esi, 0x00
000075d5269d8585  mov rax, 0x601129E62530
000075d5269d858f  call rax
000075d5269d8591  movaps xmm9, [rsp]
000075d5269d8596  add rsp, 0x30
000075d5269d859a  vmovaps xmm0, [rsp]
000075d5269d859f  vmovaps xmm1, [rsp+0x10]
000075d5269d85a5  vmovaps xmm2, [rsp+0x20]
000075d5269d85ab  vmovaps xmm3, [rsp+0x30]
000075d5269d85b1  vmovaps xmm4, [rsp+0x40]
000075d5269d85b7  vmovaps xmm5, [rsp+0x50]
000075d5269d85bd  vmovaps xmm6, [rsp+0x60]
000075d5269d85c3  vmovaps xmm7, [rsp+0x70]
000075d5269d85c9  vmovaps xmm8, [rsp+0x80]
000075d5269d85d2  vmovaps xmm10, [rsp+0x90]
000075d5269d85db  vmovaps xmm11, [rsp+0xA0]
000075d5269d85e4  vmovaps xmm12, [rsp+0xB0]
000075d5269d85ed  vmovaps xmm13, [rsp+0xC0]
000075d5269d85f6  vmovaps xmm14, [rsp+0xD0]
000075d5269d85ff  vmovaps xmm15, [rsp+0xE0]
000075d5269d8608  add rsp, 0xF0
000075d5269d860f  pop r11
000075d5269d8611  pop r10
000075d5269d8613  pop r9
000075d5269d8615  pop r8
000075d5269d8617  pop rsi
000075d5269d8618  pop rdi
000075d5269d8619  pop rdx
000075d5269d861a  pop rcx
000075d5269d861b  pop rax
000075d5269d861c  add rsp, 0x08
000075d5269d8620  jmp 0x000075D5269D5FF7
000075d5269d8625  call 0x000075D5268D64F0
000075d5269d862a  jmp 0x000075D5269D6004
000075d5269d862f  sub rsp, 0x08
000075d5269d8633  push rax
000075d5269d8634  push rcx
000075d5269d8635  push rdx
000075d5269d8636  push rdi
000075d5269d8637  push rsi
000075d5269d8638  push r8
000075d5269d863a  push r9
000075d5269d863c  push r10
000075d5269d863e  push r11
000075d5269d8640  sub rsp, 0xF0
000075d5269d8647  vmovaps [rsp], xmm0
000075d5269d864c  vmovaps [rsp+0x10], xmm1
000075d5269d8652  vmovaps [rsp+0x20], xmm2
000075d5269d8658  vmovaps [rsp+0x30], xmm3
000075d5269d865e  vmovaps [rsp+0x40], xmm4
000075d5269d8664  vmovaps [rsp+0x50], xmm5
000075d5269d866a  vmovaps [rsp+0x60], xmm6
000075d5269d8670  vmovaps [rsp+0x70], xmm7
000075d5269d8676  vmovaps [rsp+0x80], xmm8
000075d5269d867f  vmovaps [rsp+0x90], xmm9
000075d5269d8688  vmovaps [rsp+0xA0], xmm10
000075d5269d8691  vmovaps [rsp+0xB0], xmm11
000075d5269d869a  vmovaps [rsp+0xC0], xmm12
000075d5269d86a3  vmovaps [rsp+0xD0], xmm13
000075d5269d86ac  vmovaps [rsp+0xE0], xmm14
000075d5269d86b5  sub rsp, 0x30
000075d5269d86b9  movaps [rsp], xmm15
000075d5269d86be  movaps [rsp+0x10], xmm3
000075d5269d86c3  movaps [rsp+0x20], xmm7
000075d5269d86c8  lea rdi, [rsp]
000075d5269d86cc  mov esi, 0x00
000075d5269d86d1  mov rax, 0x601129E62530
000075d5269d86db  call rax
000075d5269d86dd  movaps xmm15, [rsp]
000075d5269d86e2  add rsp, 0x30
000075d5269d86e6  vmovaps xmm0, [rsp]
000075d5269d86eb  vmovaps xmm1, [rsp+0x10]
000075d5269d86f1  vmovaps xmm2, [rsp+0x20]
000075d5269d86f7  vmovaps xmm3, [rsp+0x30]
000075d5269d86fd  vmovaps xmm4, [rsp+0x40]
000075d5269d8703  vmovaps xmm5, [rsp+0x50]
000075d5269d8709  vmovaps xmm6, [rsp+0x60]
000075d5269d870f  vmovaps xmm7, [rsp+0x70]
000075d5269d8715  vmovaps xmm8, [rsp+0x80]
000075d5269d871e  vmovaps xmm9, [rsp+0x90]
000075d5269d8727  vmovaps xmm10, [rsp+0xA0]
000075d5269d8730  vmovaps xmm11, [rsp+0xB0]
000075d5269d8739  vmovaps xmm12, [rsp+0xC0]
000075d5269d8742  vmovaps xmm13, [rsp+0xD0]
000075d5269d874b  vmovaps xmm14, [rsp+0xE0]
000075d5269d8754  add rsp, 0xF0
000075d5269d875b  pop r11
000075d5269d875d  pop r10
000075d5269d875f  pop r9
000075d5269d8761  pop r8
000075d5269d8763  pop rsi
000075d5269d8764  pop rdi
000075d5269d8765  pop rdx
000075d5269d8766  pop rcx
000075d5269d8767  pop rax
000075d5269d8768  add rsp, 0x08
000075d5269d876c  jmp 0x000075D5269D6030
000075d5269d8771  sub rsp, 0x08
000075d5269d8775  push rax
000075d5269d8776  push rcx
000075d5269d8777  push rdx
000075d5269d8778  push rdi
000075d5269d8779  push rsi
000075d5269d877a  push r8
000075d5269d877c  push r9
000075d5269d877e  push r10
000075d5269d8780  push r11
000075d5269d8782  sub rsp, 0xF0
000075d5269d8789  vmovaps [rsp], xmm0
000075d5269d878e  vmovaps [rsp+0x10], xmm1
000075d5269d8794  vmovaps [rsp+0x20], xmm2
000075d5269d879a  vmovaps [rsp+0x30], xmm4
000075d5269d87a0  vmovaps [rsp+0x40], xmm5
000075d5269d87a6  vmovaps [rsp+0x50], xmm6
000075d5269d87ac  vmovaps [rsp+0x60], xmm7
000075d5269d87b2  vmovaps [rsp+0x70], xmm8
000075d5269d87b8  vmovaps [rsp+0x80], xmm9
000075d5269d87c1  vmovaps [rsp+0x90], xmm10
000075d5269d87ca  vmovaps [rsp+0xA0], xmm11
000075d5269d87d3  vmovaps [rsp+0xB0], xmm12
000075d5269d87dc  vmovaps [rsp+0xC0], xmm13
000075d5269d87e5  vmovaps [rsp+0xD0], xmm14
000075d5269d87ee  vmovaps [rsp+0xE0], xmm15
000075d5269d87f7  sub rsp, 0x30
000075d5269d87fb  movaps [rsp], xmm3
000075d5269d87ff  movaps [rsp+0x10], xmm1
000075d5269d8804  movaps [rsp+0x20], xmm15
000075d5269d880a  lea rdi, [rsp]
000075d5269d880e  mov esi, 0x00
000075d5269d8813  mov rax, 0x601129E62530
000075d5269d881d  call rax
000075d5269d881f  movaps xmm3, [rsp]
000075d5269d8823  add rsp, 0x30
000075d5269d8827  vmovaps xmm0, [rsp]
000075d5269d882c  vmovaps xmm1, [rsp+0x10]
000075d5269d8832  vmovaps xmm2, [rsp+0x20]
000075d5269d8838  vmovaps xmm4, [rsp+0x30]
000075d5269d883e  vmovaps xmm5, [rsp+0x40]
000075d5269d8844  vmovaps xmm6, [rsp+0x50]
000075d5269d884a  vmovaps xmm7, [rsp+0x60]
000075d5269d8850  vmovaps xmm8, [rsp+0x70]
000075d5269d8856  vmovaps xmm9, [rsp+0x80]
000075d5269d885f  vmovaps xmm10, [rsp+0x90]
000075d5269d8868  vmovaps xmm11, [rsp+0xA0]
000075d5269d8871  vmovaps xmm12, [rsp+0xB0]
000075d5269d887a  vmovaps xmm13, [rsp+0xC0]
000075d5269d8883  vmovaps xmm14, [rsp+0xD0]
000075d5269d888c  vmovaps xmm15, [rsp+0xE0]
000075d5269d8895  add rsp, 0xF0
000075d5269d889c  pop r11
000075d5269d889e  pop r10
000075d5269d88a0  pop r9
000075d5269d88a2  pop r8
000075d5269d88a4  pop rsi
000075d5269d88a5  pop rdi
000075d5269d88a6  pop rdx
000075d5269d88a7  pop rcx
000075d5269d88a8  pop rax
000075d5269d88a9  add rsp, 0x08
000075d5269d88ad  jmp 0x000075D5269D60BF
000075d5269d88b2  call 0x000075D5268D64F0
000075d5269d88b7  jmp 0x000075D5269D60C9
000075d5269d88bc  sub rsp, 0x08
000075d5269d88c0  push rax
000075d5269d88c1  push rcx
000075d5269d88c2  push rdx
000075d5269d88c3  push rdi
000075d5269d88c4  push rsi
000075d5269d88c5  push r8
000075d5269d88c7  push r9
000075d5269d88c9  push r10
000075d5269d88cb  push r11
000075d5269d88cd  sub rsp, 0xF0
000075d5269d88d4  vmovaps [rsp], xmm0
000075d5269d88d9  vmovaps [rsp+0x10], xmm1
000075d5269d88df  vmovaps [rsp+0x20], xmm2
000075d5269d88e5  vmovaps [rsp+0x30], xmm3
000075d5269d88eb  vmovaps [rsp+0x40], xmm4
000075d5269d88f1  vmovaps [rsp+0x50], xmm5
000075d5269d88f7  vmovaps [rsp+0x60], xmm6
000075d5269d88fd  vmovaps [rsp+0x70], xmm7
000075d5269d8903  vmovaps [rsp+0x80], xmm8
000075d5269d890c  vmovaps [rsp+0x90], xmm9
000075d5269d8915  vmovaps [rsp+0xA0], xmm10
000075d5269d891e  vmovaps [rsp+0xB0], xmm11
000075d5269d8927  vmovaps [rsp+0xC0], xmm12
000075d5269d8930  vmovaps [rsp+0xD0], xmm13
000075d5269d8939  vmovaps [rsp+0xE0], xmm14
000075d5269d8942  sub rsp, 0x30
000075d5269d8946  movaps [rsp], xmm15
000075d5269d894b  movaps [rsp+0x10], xmm14
000075d5269d8951  movaps [rsp+0x20], xmm4
000075d5269d8956  lea rdi, [rsp]
000075d5269d895a  mov esi, 0x00
000075d5269d895f  mov rax, 0x601129E62530
000075d5269d8969  call rax
000075d5269d896b  movaps xmm15, [rsp]
000075d5269d8970  add rsp, 0x30
000075d5269d8974  vmovaps xmm0, [rsp]
000075d5269d8979  vmovaps xmm1, [rsp+0x10]
000075d5269d897f  vmovaps xmm2, [rsp+0x20]
000075d5269d8985  vmovaps xmm3, [rsp+0x30]
000075d5269d898b  vmovaps xmm4, [rsp+0x40]
000075d5269d8991  vmovaps xmm5, [rsp+0x50]
000075d5269d8997  vmovaps xmm6, [rsp+0x60]
000075d5269d899d  vmovaps xmm7, [rsp+0x70]
000075d5269d89a3  vmovaps xmm8, [rsp+0x80]
000075d5269d89ac  vmovaps xmm9, [rsp+0x90]
000075d5269d89b5  vmovaps xmm10, [rsp+0xA0]
000075d5269d89be  vmovaps xmm11, [rsp+0xB0]
000075d5269d89c7  vmovaps xmm12, [rsp+0xC0]
000075d5269d89d0  vmovaps xmm13, [rsp+0xD0]
000075d5269d89d9  vmovaps xmm14, [rsp+0xE0]
000075d5269d89e2  add rsp, 0xF0
000075d5269d89e9  pop r11
000075d5269d89eb  pop r10
000075d5269d89ed  pop r9
000075d5269d89ef  pop r8
000075d5269d89f1  pop rsi
000075d5269d89f2  pop rdi
000075d5269d89f3  pop rdx
000075d5269d89f4  pop rcx
000075d5269d89f5  pop rax
000075d5269d89f6  add rsp, 0x08
000075d5269d89fa  jmp 0x000075D5269D60F7
000075d5269d89ff  sub rsp, 0x08
000075d5269d8a03  push rax
000075d5269d8a04  push rcx
000075d5269d8a05  push rdx
000075d5269d8a06  push rdi
000075d5269d8a07  push rsi
000075d5269d8a08  push r8
000075d5269d8a0a  push r9
000075d5269d8a0c  push r10
000075d5269d8a0e  push r11
000075d5269d8a10  sub rsp, 0xF0
000075d5269d8a17  vmovaps [rsp], xmm0
000075d5269d8a1c  vmovaps [rsp+0x10], xmm1
000075d5269d8a22  vmovaps [rsp+0x20], xmm2
000075d5269d8a28  vmovaps [rsp+0x30], xmm3
000075d5269d8a2e  vmovaps [rsp+0x40], xmm4
000075d5269d8a34  vmovaps [rsp+0x50], xmm5
000075d5269d8a3a  vmovaps [rsp+0x60], xmm6
000075d5269d8a40  vmovaps [rsp+0x70], xmm7
000075d5269d8a46  vmovaps [rsp+0x80], xmm8
000075d5269d8a4f  vmovaps [rsp+0x90], xmm9
000075d5269d8a58  vmovaps [rsp+0xA0], xmm10
000075d5269d8a61  vmovaps [rsp+0xB0], xmm11
000075d5269d8a6a  vmovaps [rsp+0xC0], xmm12
000075d5269d8a73  vmovaps [rsp+0xD0], xmm13
000075d5269d8a7c  vmovaps [rsp+0xE0], xmm15
000075d5269d8a85  sub rsp, 0x30
000075d5269d8a89  movaps [rsp], xmm14
000075d5269d8a8e  movaps [rsp+0x10], xmm2
000075d5269d8a93  movaps [rsp+0x20], xmm1
000075d5269d8a98  lea rdi, [rsp]
000075d5269d8a9c  mov esi, 0x00
000075d5269d8aa1  mov rax, 0x601129E62530
000075d5269d8aab  call rax
000075d5269d8aad  movaps xmm14, [rsp]
000075d5269d8ab2  add rsp, 0x30
000075d5269d8ab6  vmovaps xmm0, [rsp]
000075d5269d8abb  vmovaps xmm1, [rsp+0x10]
000075d5269d8ac1  vmovaps xmm2, [rsp+0x20]
000075d5269d8ac7  vmovaps xmm3, [rsp+0x30]
000075d5269d8acd  vmovaps xmm4, [rsp+0x40]
000075d5269d8ad3  vmovaps xmm5, [rsp+0x50]
000075d5269d8ad9  vmovaps xmm6, [rsp+0x60]
000075d5269d8adf  vmovaps xmm7, [rsp+0x70]
000075d5269d8ae5  vmovaps xmm8, [rsp+0x80]
000075d5269d8aee  vmovaps xmm9, [rsp+0x90]
000075d5269d8af7  vmovaps xmm10, [rsp+0xA0]
000075d5269d8b00  vmovaps xmm11, [rsp+0xB0]
000075d5269d8b09  vmovaps xmm12, [rsp+0xC0]
000075d5269d8b12  vmovaps xmm13, [rsp+0xD0]
000075d5269d8b1b  vmovaps xmm15, [rsp+0xE0]
000075d5269d8b24  add rsp, 0xF0
000075d5269d8b2b  pop r11
000075d5269d8b2d  pop r10
000075d5269d8b2f  pop r9
000075d5269d8b31  pop r8
000075d5269d8b33  pop rsi
000075d5269d8b34  pop rdi
000075d5269d8b35  pop rdx
000075d5269d8b36  pop rcx
000075d5269d8b37  pop rax
000075d5269d8b38  add rsp, 0x08
000075d5269d8b3c  jmp 0x000075D5269D611D
000075d5269d8b41  sub rsp, 0x08
000075d5269d8b45  push rax
000075d5269d8b46  push rcx
000075d5269d8b47  push rdx
000075d5269d8b48  push rdi
000075d5269d8b49  push rsi
000075d5269d8b4a  push r8
000075d5269d8b4c  push r9
000075d5269d8b4e  push r10
000075d5269d8b50  push r11
000075d5269d8b52  sub rsp, 0xF0
000075d5269d8b59  vmovaps [rsp], xmm0
000075d5269d8b5e  vmovaps [rsp+0x10], xmm2
000075d5269d8b64  vmovaps [rsp+0x20], xmm3
000075d5269d8b6a  vmovaps [rsp+0x30], xmm4
000075d5269d8b70  vmovaps [rsp+0x40], xmm5
000075d5269d8b76  vmovaps [rsp+0x50], xmm6
000075d5269d8b7c  vmovaps [rsp+0x60], xmm7
000075d5269d8b82  vmovaps [rsp+0x70], xmm8
000075d5269d8b88  vmovaps [rsp+0x80], xmm9
000075d5269d8b91  vmovaps [rsp+0x90], xmm10
000075d5269d8b9a  vmovaps [rsp+0xA0], xmm11
000075d5269d8ba3  vmovaps [rsp+0xB0], xmm12
000075d5269d8bac  vmovaps [rsp+0xC0], xmm13
000075d5269d8bb5  vmovaps [rsp+0xD0], xmm14
000075d5269d8bbe  vmovaps [rsp+0xE0], xmm15
000075d5269d8bc7  sub rsp, 0x30
000075d5269d8bcb  movaps [rsp], xmm1
000075d5269d8bcf  movaps [rsp+0x10], xmm4
000075d5269d8bd4  movaps [rsp+0x20], xmm9
000075d5269d8bda  lea rdi, [rsp]
000075d5269d8bde  mov esi, 0x00
000075d5269d8be3  mov rax, 0x601129E62530
000075d5269d8bed  call rax
000075d5269d8bef  movaps xmm1, [rsp]
000075d5269d8bf3  add rsp, 0x30
000075d5269d8bf7  vmovaps xmm0, [rsp]
000075d5269d8bfc  vmovaps xmm2, [rsp+0x10]
000075d5269d8c02  vmovaps xmm3, [rsp+0x20]
000075d5269d8c08  vmovaps xmm4, [rsp+0x30]
000075d5269d8c0e  vmovaps xmm5, [rsp+0x40]
000075d5269d8c14  vmovaps xmm6, [rsp+0x50]
000075d5269d8c1a  vmovaps xmm7, [rsp+0x60]
000075d5269d8c20  vmovaps xmm8, [rsp+0x70]
000075d5269d8c26  vmovaps xmm9, [rsp+0x80]
000075d5269d8c2f  vmovaps xmm10, [rsp+0x90]
000075d5269d8c38  vmovaps xmm11, [rsp+0xA0]
000075d5269d8c41  vmovaps xmm12, [rsp+0xB0]
000075d5269d8c4a  vmovaps xmm13, [rsp+0xC0]
000075d5269d8c53  vmovaps xmm14, [rsp+0xD0]
000075d5269d8c5c  vmovaps xmm15, [rsp+0xE0]
000075d5269d8c65  add rsp, 0xF0
000075d5269d8c6c  pop r11
000075d5269d8c6e  pop r10
000075d5269d8c70  pop r9
000075d5269d8c72  pop r8
000075d5269d8c74  pop rsi
000075d5269d8c75  pop rdi
000075d5269d8c76  pop rdx
000075d5269d8c77  pop rcx
000075d5269d8c78  pop rax
000075d5269d8c79  add rsp, 0x08
000075d5269d8c7d  jmp 0x000075D5269D613B
000075d5269d8c82  sub rsp, 0x08
000075d5269d8c86  push rax
000075d5269d8c87  push rcx
000075d5269d8c88  push rdx
000075d5269d8c89  push rdi
000075d5269d8c8a  push rsi
000075d5269d8c8b  push r8
000075d5269d8c8d  push r9
000075d5269d8c8f  push r10
000075d5269d8c91  push r11
000075d5269d8c93  sub rsp, 0xF0
000075d5269d8c9a  vmovaps [rsp], xmm0
000075d5269d8c9f  vmovaps [rsp+0x10], xmm1
000075d5269d8ca5  vmovaps [rsp+0x20], xmm2
000075d5269d8cab  vmovaps [rsp+0x30], xmm3
000075d5269d8cb1  vmovaps [rsp+0x40], xmm5
000075d5269d8cb7  vmovaps [rsp+0x50], xmm6
000075d5269d8cbd  vmovaps [rsp+0x60], xmm7
000075d5269d8cc3  vmovaps [rsp+0x70], xmm8
000075d5269d8cc9  vmovaps [rsp+0x80], xmm9
000075d5269d8cd2  vmovaps [rsp+0x90], xmm10
000075d5269d8cdb  vmovaps [rsp+0xA0], xmm11
000075d5269d8ce4  vmovaps [rsp+0xB0], xmm12
000075d5269d8ced  vmovaps [rsp+0xC0], xmm13
000075d5269d8cf6  vmovaps [rsp+0xD0], xmm14
000075d5269d8cff  vmovaps [rsp+0xE0], xmm15
000075d5269d8d08  sub rsp, 0x30
000075d5269d8d0c  movaps [rsp], xmm4
000075d5269d8d10  movaps [rsp+0x10], xmm2
000075d5269d8d15  movaps [rsp+0x20], xmm9
000075d5269d8d1b  lea rdi, [rsp]
000075d5269d8d1f  mov esi, 0x00
000075d5269d8d24  mov rax, 0x601129E62530
000075d5269d8d2e  call rax
000075d5269d8d30  movaps xmm4, [rsp]
000075d5269d8d34  add rsp, 0x30
000075d5269d8d38  vmovaps xmm0, [rsp]
000075d5269d8d3d  vmovaps xmm1, [rsp+0x10]
000075d5269d8d43  vmovaps xmm2, [rsp+0x20]
000075d5269d8d49  vmovaps xmm3, [rsp+0x30]
000075d5269d8d4f  vmovaps xmm5, [rsp+0x40]
000075d5269d8d55  vmovaps xmm6, [rsp+0x50]
000075d5269d8d5b  vmovaps xmm7, [rsp+0x60]
000075d5269d8d61  vmovaps xmm8, [rsp+0x70]
000075d5269d8d67  vmovaps xmm9, [rsp+0x80]
000075d5269d8d70  vmovaps xmm10, [rsp+0x90]
000075d5269d8d79  vmovaps xmm11, [rsp+0xA0]
000075d5269d8d82  vmovaps xmm12, [rsp+0xB0]
000075d5269d8d8b  vmovaps xmm13, [rsp+0xC0]
000075d5269d8d94  vmovaps xmm14, [rsp+0xD0]
000075d5269d8d9d  vmovaps xmm15, [rsp+0xE0]
000075d5269d8da6  add rsp, 0xF0
000075d5269d8dad  pop r11
000075d5269d8daf  pop r10
000075d5269d8db1  pop r9
000075d5269d8db3  pop r8
000075d5269d8db5  pop rsi
000075d5269d8db6  pop rdi
000075d5269d8db7  pop rdx
000075d5269d8db8  pop rcx
000075d5269d8db9  pop rax
000075d5269d8dba  add rsp, 0x08
000075d5269d8dbe  jmp 0x000075D5269D616B
000075d5269d8dc3  sub rsp, 0x08
000075d5269d8dc7  push rax
000075d5269d8dc8  push rcx
000075d5269d8dc9  push rdx
000075d5269d8dca  push rdi
000075d5269d8dcb  push rsi
000075d5269d8dcc  push r8
000075d5269d8dce  push r9
000075d5269d8dd0  push r10
000075d5269d8dd2  push r11
000075d5269d8dd4  sub rsp, 0xF0
000075d5269d8ddb  vmovaps [rsp], xmm0
000075d5269d8de0  vmovaps [rsp+0x10], xmm1
000075d5269d8de6  vmovaps [rsp+0x20], xmm2
000075d5269d8dec  vmovaps [rsp+0x30], xmm3
000075d5269d8df2  vmovaps [rsp+0x40], xmm4
000075d5269d8df8  vmovaps [rsp+0x50], xmm5
000075d5269d8dfe  vmovaps [rsp+0x60], xmm6
000075d5269d8e04  vmovaps [rsp+0x70], xmm7
000075d5269d8e0a  vmovaps [rsp+0x80], xmm8
000075d5269d8e13  vmovaps [rsp+0x90], xmm10
000075d5269d8e1c  vmovaps [rsp+0xA0], xmm11
000075d5269d8e25  vmovaps [rsp+0xB0], xmm12
000075d5269d8e2e  vmovaps [rsp+0xC0], xmm13
000075d5269d8e37  vmovaps [rsp+0xD0], xmm14
000075d5269d8e40  vmovaps [rsp+0xE0], xmm15
000075d5269d8e49  sub rsp, 0x30
000075d5269d8e4d  movaps [rsp], xmm9
000075d5269d8e52  movaps [rsp+0x10], xmm2
000075d5269d8e57  movaps [rsp+0x20], xmm1
000075d5269d8e5c  lea rdi, [rsp]
000075d5269d8e60  mov esi, 0x00
000075d5269d8e65  mov rax, 0x601129E62530
000075d5269d8e6f  call rax
000075d5269d8e71  movaps xmm9, [rsp]
000075d5269d8e76  add rsp, 0x30
000075d5269d8e7a  vmovaps xmm0, [rsp]
000075d5269d8e7f  vmovaps xmm1, [rsp+0x10]
000075d5269d8e85  vmovaps xmm2, [rsp+0x20]
000075d5269d8e8b  vmovaps xmm3, [rsp+0x30]
000075d5269d8e91  vmovaps xmm4, [rsp+0x40]
000075d5269d8e97  vmovaps xmm5, [rsp+0x50]
000075d5269d8e9d  vmovaps xmm6, [rsp+0x60]
000075d5269d8ea3  vmovaps xmm7, [rsp+0x70]
000075d5269d8ea9  vmovaps xmm8, [rsp+0x80]
000075d5269d8eb2  vmovaps xmm10, [rsp+0x90]
000075d5269d8ebb  vmovaps xmm11, [rsp+0xA0]
000075d5269d8ec4  vmovaps xmm12, [rsp+0xB0]
000075d5269d8ecd  vmovaps xmm13, [rsp+0xC0]
000075d5269d8ed6  vmovaps xmm14, [rsp+0xD0]
000075d5269d8edf  vmovaps xmm15, [rsp+0xE0]
000075d5269d8ee8  add rsp, 0xF0
000075d5269d8eef  pop r11
000075d5269d8ef1  pop r10
000075d5269d8ef3  pop r9
000075d5269d8ef5  pop r8
000075d5269d8ef7  pop rsi
000075d5269d8ef8  pop rdi
000075d5269d8ef9  pop rdx
000075d5269d8efa  pop rcx
000075d5269d8efb  pop rax
000075d5269d8efc  add rsp, 0x08
000075d5269d8f00  jmp 0x000075D5269D61A1
000075d5269d8f05  sub rsp, 0x08
000075d5269d8f09  push rax
000075d5269d8f0a  push rcx
000075d5269d8f0b  push rdx
000075d5269d8f0c  push rdi
000075d5269d8f0d  push rsi
000075d5269d8f0e  push r8
000075d5269d8f10  push r9
000075d5269d8f12  push r10
000075d5269d8f14  push r11
000075d5269d8f16  sub rsp, 0xF0
000075d5269d8f1d  vmovaps [rsp], xmm0
000075d5269d8f22  vmovaps [rsp+0x10], xmm2
000075d5269d8f28  vmovaps [rsp+0x20], xmm3
000075d5269d8f2e  vmovaps [rsp+0x30], xmm4
000075d5269d8f34  vmovaps [rsp+0x40], xmm5
000075d5269d8f3a  vmovaps [rsp+0x50], xmm6
000075d5269d8f40  vmovaps [rsp+0x60], xmm7
000075d5269d8f46  vmovaps [rsp+0x70], xmm8
000075d5269d8f4c  vmovaps [rsp+0x80], xmm9
000075d5269d8f55  vmovaps [rsp+0x90], xmm10
000075d5269d8f5e  vmovaps [rsp+0xA0], xmm11
000075d5269d8f67  vmovaps [rsp+0xB0], xmm12
000075d5269d8f70  vmovaps [rsp+0xC0], xmm13
000075d5269d8f79  vmovaps [rsp+0xD0], xmm14
000075d5269d8f82  vmovaps [rsp+0xE0], xmm15
000075d5269d8f8b  sub rsp, 0x30
000075d5269d8f8f  movaps [rsp], xmm1
000075d5269d8f93  movaps [rsp+0x10], xmm15
000075d5269d8f99  movaps [rsp+0x20], xmm6
000075d5269d8f9e  lea rdi, [rsp]
000075d5269d8fa2  mov esi, 0x00
000075d5269d8fa7  mov rax, 0x601129E62530
000075d5269d8fb1  call rax
000075d5269d8fb3  movaps xmm1, [rsp]
000075d5269d8fb7  add rsp, 0x30
000075d5269d8fbb  vmovaps xmm0, [rsp]
000075d5269d8fc0  vmovaps xmm2, [rsp+0x10]
000075d5269d8fc6  vmovaps xmm3, [rsp+0x20]
000075d5269d8fcc  vmovaps xmm4, [rsp+0x30]
000075d5269d8fd2  vmovaps xmm5, [rsp+0x40]
000075d5269d8fd8  vmovaps xmm6, [rsp+0x50]
000075d5269d8fde  vmovaps xmm7, [rsp+0x60]
000075d5269d8fe4  vmovaps xmm8, [rsp+0x70]
000075d5269d8fea  vmovaps xmm9, [rsp+0x80]
000075d5269d8ff3  vmovaps xmm10, [rsp+0x90]
000075d5269d8ffc  vmovaps xmm11, [rsp+0xA0]
000075d5269d9005  vmovaps xmm12, [rsp+0xB0]
000075d5269d900e  vmovaps xmm13, [rsp+0xC0]
000075d5269d9017  vmovaps xmm14, [rsp+0xD0]
000075d5269d9020  vmovaps xmm15, [rsp+0xE0]
000075d5269d9029  add rsp, 0xF0
000075d5269d9030  pop r11
000075d5269d9032  pop r10
000075d5269d9034  pop r9
000075d5269d9036  pop r8
000075d5269d9038  pop rsi
000075d5269d9039  pop rdi
000075d5269d903a  pop rdx
000075d5269d903b  pop rcx
000075d5269d903c  pop rax
000075d5269d903d  add rsp, 0x08
000075d5269d9041  jmp 0x000075D5269D61C2
000075d5269d9046  sub rsp, 0x08
000075d5269d904a  push rax
000075d5269d904b  push rcx
000075d5269d904c  push rdx
000075d5269d904d  push rdi
000075d5269d904e  push rsi
000075d5269d904f  push r8
000075d5269d9051  push r9
000075d5269d9053  push r10
000075d5269d9055  push r11
000075d5269d9057  sub rsp, 0xF0
000075d5269d905e  vmovaps [rsp], xmm0
000075d5269d9063  vmovaps [rsp+0x10], xmm1
000075d5269d9069  vmovaps [rsp+0x20], xmm2
000075d5269d906f  vmovaps [rsp+0x30], xmm3
000075d5269d9075  vmovaps [rsp+0x40], xmm4
000075d5269d907b  vmovaps [rsp+0x50], xmm5
000075d5269d9081  vmovaps [rsp+0x60], xmm6
000075d5269d9087  vmovaps [rsp+0x70], xmm7
000075d5269d908d  vmovaps [rsp+0x80], xmm8
000075d5269d9096  vmovaps [rsp+0x90], xmm9
000075d5269d909f  vmovaps [rsp+0xA0], xmm10
000075d5269d90a8  vmovaps [rsp+0xB0], xmm11
000075d5269d90b1  vmovaps [rsp+0xC0], xmm12
000075d5269d90ba  vmovaps [rsp+0xD0], xmm13
000075d5269d90c3  vmovaps [rsp+0xE0], xmm14
000075d5269d90cc  sub rsp, 0x30
000075d5269d90d0  movaps [rsp], xmm15
000075d5269d90d5  movaps [rsp+0x10], xmm5
000075d5269d90da  movaps [rsp+0x20], xmm3
000075d5269d90df  lea rdi, [rsp]
000075d5269d90e3  mov esi, 0x00
000075d5269d90e8  mov rax, 0x601129E62530
000075d5269d90f2  call rax
000075d5269d90f4  movaps xmm15, [rsp]
000075d5269d90f9  add rsp, 0x30
000075d5269d90fd  vmovaps xmm0, [rsp]
000075d5269d9102  vmovaps xmm1, [rsp+0x10]
000075d5269d9108  vmovaps xmm2, [rsp+0x20]
000075d5269d910e  vmovaps xmm3, [rsp+0x30]
000075d5269d9114  vmovaps xmm4, [rsp+0x40]
000075d5269d911a  vmovaps xmm5, [rsp+0x50]
000075d5269d9120  vmovaps xmm6, [rsp+0x60]
000075d5269d9126  vmovaps xmm7, [rsp+0x70]
000075d5269d912c  vmovaps xmm8, [rsp+0x80]
000075d5269d9135  vmovaps xmm9, [rsp+0x90]
000075d5269d913e  vmovaps xmm10, [rsp+0xA0]
000075d5269d9147  vmovaps xmm11, [rsp+0xB0]
000075d5269d9150  vmovaps xmm12, [rsp+0xC0]
000075d5269d9159  vmovaps xmm13, [rsp+0xD0]
000075d5269d9162  vmovaps xmm14, [rsp+0xE0]
000075d5269d916b  add rsp, 0xF0
000075d5269d9172  pop r11
000075d5269d9174  pop r10
000075d5269d9176  pop r9
000075d5269d9178  pop r8
000075d5269d917a  pop rsi
000075d5269d917b  pop rdi
000075d5269d917c  pop rdx
000075d5269d917d  pop rcx
000075d5269d917e  pop rax
000075d5269d917f  add rsp, 0x08
000075d5269d9183  jmp 0x000075D5269D61DC
000075d5269d9188  sub rsp, 0x08
000075d5269d918c  push rax
000075d5269d918d  push rcx
000075d5269d918e  push rdx
000075d5269d918f  push rdi
000075d5269d9190  push rsi
000075d5269d9191  push r8
000075d5269d9193  push r9
000075d5269d9195  push r10
000075d5269d9197  push r11
000075d5269d9199  sub rsp, 0xF0
000075d5269d91a0  vmovaps [rsp], xmm0
000075d5269d91a5  vmovaps [rsp+0x10], xmm1
000075d5269d91ab  vmovaps [rsp+0x20], xmm2
000075d5269d91b1  vmovaps [rsp+0x30], xmm3
000075d5269d91b7  vmovaps [rsp+0x40], xmm4
000075d5269d91bd  vmovaps [rsp+0x50], xmm6
000075d5269d91c3  vmovaps [rsp+0x60], xmm7
000075d5269d91c9  vmovaps [rsp+0x70], xmm8
000075d5269d91cf  vmovaps [rsp+0x80], xmm9
000075d5269d91d8  vmovaps [rsp+0x90], xmm10
000075d5269d91e1  vmovaps [rsp+0xA0], xmm11
000075d5269d91ea  vmovaps [rsp+0xB0], xmm12
000075d5269d91f3  vmovaps [rsp+0xC0], xmm13
000075d5269d91fc  vmovaps [rsp+0xD0], xmm14
000075d5269d9205  vmovaps [rsp+0xE0], xmm15
000075d5269d920e  sub rsp, 0x30
000075d5269d9212  movaps [rsp], xmm5
000075d5269d9216  movaps [rsp+0x10], xmm8
000075d5269d921c  movaps [rsp+0x20], xmm6
000075d5269d9221  lea rdi, [rsp]
000075d5269d9225  mov esi, 0x00
000075d5269d922a  mov rax, 0x601129E62530
000075d5269d9234  call rax
000075d5269d9236  movaps xmm5, [rsp]
000075d5269d923a  add rsp, 0x30
000075d5269d923e  vmovaps xmm0, [rsp]
000075d5269d9243  vmovaps xmm1, [rsp+0x10]
000075d5269d9249  vmovaps xmm2, [rsp+0x20]
000075d5269d924f  vmovaps xmm3, [rsp+0x30]
000075d5269d9255  vmovaps xmm4, [rsp+0x40]
000075d5269d925b  vmovaps xmm6, [rsp+0x50]
000075d5269d9261  vmovaps xmm7, [rsp+0x60]
000075d5269d9267  vmovaps xmm8, [rsp+0x70]
000075d5269d926d  vmovaps xmm9, [rsp+0x80]
000075d5269d9276  vmovaps xmm10, [rsp+0x90]
000075d5269d927f  vmovaps xmm11, [rsp+0xA0]
000075d5269d9288  vmovaps xmm12, [rsp+0xB0]
000075d5269d9291  vmovaps xmm13, [rsp+0xC0]
000075d5269d929a  vmovaps xmm14, [rsp+0xD0]
000075d5269d92a3  vmovaps xmm15, [rsp+0xE0]
000075d5269d92ac  add rsp, 0xF0
000075d5269d92b3  pop r11
000075d5269d92b5  pop r10
000075d5269d92b7  pop r9
000075d5269d92b9  pop r8
000075d5269d92bb  pop rsi
000075d5269d92bc  pop rdi
000075d5269d92bd  pop rdx
000075d5269d92be  pop rcx
000075d5269d92bf  pop rax
000075d5269d92c0  add rsp, 0x08
000075d5269d92c4  jmp 0x000075D5269D6200
000075d5269d92c9  sub rsp, 0x08
000075d5269d92cd  push rax
000075d5269d92ce  push rcx
000075d5269d92cf  push rdx
000075d5269d92d0  push rdi
000075d5269d92d1  push rsi
000075d5269d92d2  push r8
000075d5269d92d4  push r9
000075d5269d92d6  push r10
000075d5269d92d8  push r11
000075d5269d92da  sub rsp, 0xF0
000075d5269d92e1  vmovaps [rsp], xmm0
000075d5269d92e6  vmovaps [rsp+0x10], xmm1
000075d5269d92ec  vmovaps [rsp+0x20], xmm2
000075d5269d92f2  vmovaps [rsp+0x30], xmm3
000075d5269d92f8  vmovaps [rsp+0x40], xmm4
000075d5269d92fe  vmovaps [rsp+0x50], xmm5
000075d5269d9304  vmovaps [rsp+0x60], xmm7
000075d5269d930a  vmovaps [rsp+0x70], xmm8
000075d5269d9310  vmovaps [rsp+0x80], xmm9
000075d5269d9319  vmovaps [rsp+0x90], xmm10
000075d5269d9322  vmovaps [rsp+0xA0], xmm11
000075d5269d932b  vmovaps [rsp+0xB0], xmm12
000075d5269d9334  vmovaps [rsp+0xC0], xmm13
000075d5269d933d  vmovaps [rsp+0xD0], xmm14
000075d5269d9346  vmovaps [rsp+0xE0], xmm15
000075d5269d934f  sub rsp, 0x30
000075d5269d9353  movaps [rsp], xmm6
000075d5269d9357  movaps [rsp+0x10], xmm10
000075d5269d935d  movaps [rsp+0x20], xmm8
000075d5269d9363  lea rdi, [rsp]
000075d5269d9367  mov esi, 0x00
000075d5269d936c  mov rax, 0x601129E62530
000075d5269d9376  call rax
000075d5269d9378  movaps xmm6, [rsp]
000075d5269d937c  add rsp, 0x30
000075d5269d9380  vmovaps xmm0, [rsp]
000075d5269d9385  vmovaps xmm1, [rsp+0x10]
000075d5269d938b  vmovaps xmm2, [rsp+0x20]
000075d5269d9391  vmovaps xmm3, [rsp+0x30]
000075d5269d9397  vmovaps xmm4, [rsp+0x40]
000075d5269d939d  vmovaps xmm5, [rsp+0x50]
000075d5269d93a3  vmovaps xmm7, [rsp+0x60]
000075d5269d93a9  vmovaps xmm8, [rsp+0x70]
000075d5269d93af  vmovaps xmm9, [rsp+0x80]
000075d5269d93b8  vmovaps xmm10, [rsp+0x90]
000075d5269d93c1  vmovaps xmm11, [rsp+0xA0]
000075d5269d93ca  vmovaps xmm12, [rsp+0xB0]
000075d5269d93d3  vmovaps xmm13, [rsp+0xC0]
000075d5269d93dc  vmovaps xmm14, [rsp+0xD0]
000075d5269d93e5  vmovaps xmm15, [rsp+0xE0]
000075d5269d93ee  add rsp, 0xF0
000075d5269d93f5  pop r11
000075d5269d93f7  pop r10
000075d5269d93f9  pop r9
000075d5269d93fb  pop r8
000075d5269d93fd  pop rsi
000075d5269d93fe  pop rdi
000075d5269d93ff  pop rdx
000075d5269d9400  pop rcx
000075d5269d9401  pop rax
000075d5269d9402  add rsp, 0x08
000075d5269d9406  jmp 0x000075D5269D6225
000075d5269d940b  sub rsp, 0x08
000075d5269d940f  push rax
000075d5269d9410  push rcx
000075d5269d9411  push rdx
000075d5269d9412  push rdi
000075d5269d9413  push rsi
000075d5269d9414  push r8
000075d5269d9416  push r9
000075d5269d9418  push r10
000075d5269d941a  push r11
000075d5269d941c  sub rsp, 0xF0
000075d5269d9423  vmovaps [rsp], xmm0
000075d5269d9428  vmovaps [rsp+0x10], xmm1
000075d5269d942e  vmovaps [rsp+0x20], xmm2
000075d5269d9434  vmovaps [rsp+0x30], xmm3
000075d5269d943a  vmovaps [rsp+0x40], xmm4
000075d5269d9440  vmovaps [rsp+0x50], xmm5
000075d5269d9446  vmovaps [rsp+0x60], xmm6
000075d5269d944c  vmovaps [rsp+0x70], xmm7
000075d5269d9452  vmovaps [rsp+0x80], xmm8
000075d5269d945b  vmovaps [rsp+0x90], xmm9
000075d5269d9464  vmovaps [rsp+0xA0], xmm11
000075d5269d946d  vmovaps [rsp+0xB0], xmm12
000075d5269d9476  vmovaps [rsp+0xC0], xmm13
000075d5269d947f  vmovaps [rsp+0xD0], xmm14
000075d5269d9488  vmovaps [rsp+0xE0], xmm15
000075d5269d9491  sub rsp, 0x30
000075d5269d9495  movaps [rsp], xmm10
000075d5269d949a  movaps [rsp+0x10], xmm8
000075d5269d94a0  movaps [rsp+0x20], xmm14
000075d5269d94a6  lea rdi, [rsp]
000075d5269d94aa  mov esi, 0x00
000075d5269d94af  mov rax, 0x601129E62530
000075d5269d94b9  call rax
000075d5269d94bb  movaps xmm10, [rsp]
000075d5269d94c0  add rsp, 0x30
000075d5269d94c4  vmovaps xmm0, [rsp]
000075d5269d94c9  vmovaps xmm1, [rsp+0x10]
000075d5269d94cf  vmovaps xmm2, [rsp+0x20]
000075d5269d94d5  vmovaps xmm3, [rsp+0x30]
000075d5269d94db  vmovaps xmm4, [rsp+0x40]
000075d5269d94e1  vmovaps xmm5, [rsp+0x50]
000075d5269d94e7  vmovaps xmm6, [rsp+0x60]
000075d5269d94ed  vmovaps xmm7, [rsp+0x70]
000075d5269d94f3  vmovaps xmm8, [rsp+0x80]
000075d5269d94fc  vmovaps xmm9, [rsp+0x90]
000075d5269d9505  vmovaps xmm11, [rsp+0xA0]
000075d5269d950e  vmovaps xmm12, [rsp+0xB0]
000075d5269d9517  vmovaps xmm13, [rsp+0xC0]
000075d5269d9520  vmovaps xmm14, [rsp+0xD0]
000075d5269d9529  vmovaps xmm15, [rsp+0xE0]
000075d5269d9532  add rsp, 0xF0
000075d5269d9539  pop r11
000075d5269d953b  pop r10
000075d5269d953d  pop r9
000075d5269d953f  pop r8
000075d5269d9541  pop rsi
000075d5269d9542  pop rdi
000075d5269d9543  pop rdx
000075d5269d9544  pop rcx
000075d5269d9545  pop rax
000075d5269d9546  add rsp, 0x08
000075d5269d954a  jmp 0x000075D5269D6245
000075d5269d954f  sub rsp, 0x08
000075d5269d9553  push rax
000075d5269d9554  push rcx
000075d5269d9555  push rdx
000075d5269d9556  push rdi
000075d5269d9557  push rsi
000075d5269d9558  push r8
000075d5269d955a  push r9
000075d5269d955c  push r10
000075d5269d955e  push r11
000075d5269d9560  sub rsp, 0xF0
000075d5269d9567  vmovaps [rsp], xmm0
000075d5269d956c  vmovaps [rsp+0x10], xmm1
000075d5269d9572  vmovaps [rsp+0x20], xmm2
000075d5269d9578  vmovaps [rsp+0x30], xmm3
000075d5269d957e  vmovaps [rsp+0x40], xmm4
000075d5269d9584  vmovaps [rsp+0x50], xmm5
000075d5269d958a  vmovaps [rsp+0x60], xmm6
000075d5269d9590  vmovaps [rsp+0x70], xmm7
000075d5269d9596  vmovaps [rsp+0x80], xmm8
000075d5269d959f  vmovaps [rsp+0x90], xmm9
000075d5269d95a8  vmovaps [rsp+0xA0], xmm10
000075d5269d95b1  vmovaps [rsp+0xB0], xmm11
000075d5269d95ba  vmovaps [rsp+0xC0], xmm12
000075d5269d95c3  vmovaps [rsp+0xD0], xmm13
000075d5269d95cc  vmovaps [rsp+0xE0], xmm15
000075d5269d95d5  sub rsp, 0x30
000075d5269d95d9  movaps [rsp], xmm14
000075d5269d95de  movaps [rsp+0x10], xmm8
000075d5269d95e4  movaps [rsp+0x20], xmm4
000075d5269d95e9  lea rdi, [rsp]
000075d5269d95ed  mov esi, 0x00
000075d5269d95f2  mov rax, 0x601129E62530
000075d5269d95fc  call rax
000075d5269d95fe  movaps xmm14, [rsp]
000075d5269d9603  add rsp, 0x30
000075d5269d9607  vmovaps xmm0, [rsp]
000075d5269d960c  vmovaps xmm1, [rsp+0x10]
000075d5269d9612  vmovaps xmm2, [rsp+0x20]
000075d5269d9618  vmovaps xmm3, [rsp+0x30]
000075d5269d961e  vmovaps xmm4, [rsp+0x40]
000075d5269d9624  vmovaps xmm5, [rsp+0x50]
000075d5269d962a  vmovaps xmm6, [rsp+0x60]
000075d5269d9630  vmovaps xmm7, [rsp+0x70]
000075d5269d9636  vmovaps xmm8, [rsp+0x80]
000075d5269d963f  vmovaps xmm9, [rsp+0x90]
000075d5269d9648  vmovaps xmm10, [rsp+0xA0]
000075d5269d9651  vmovaps xmm11, [rsp+0xB0]
000075d5269d965a  vmovaps xmm12, [rsp+0xC0]
000075d5269d9663  vmovaps xmm13, [rsp+0xD0]
000075d5269d966c  vmovaps xmm15, [rsp+0xE0]
000075d5269d9675  add rsp, 0xF0
000075d5269d967c  pop r11
000075d5269d967e  pop r10
000075d5269d9680  pop r9
000075d5269d9682  pop r8
000075d5269d9684  pop rsi
000075d5269d9685  pop rdi
000075d5269d9686  pop rdx
000075d5269d9687  pop rcx
000075d5269d9688  pop rax
000075d5269d9689  add rsp, 0x08
000075d5269d968d  jmp 0x000075D5269D6265
000075d5269d9692  sub rsp, 0x08
000075d5269d9696  push rax
000075d5269d9697  push rcx
000075d5269d9698  push rdx
000075d5269d9699  push rdi
000075d5269d969a  push rsi
000075d5269d969b  push r8
000075d5269d969d  push r9
000075d5269d969f  push r10
000075d5269d96a1  push r11
000075d5269d96a3  sub rsp, 0xF0
000075d5269d96aa  vmovaps [rsp], xmm0
000075d5269d96af  vmovaps [rsp+0x10], xmm1
000075d5269d96b5  vmovaps [rsp+0x20], xmm2
000075d5269d96bb  vmovaps [rsp+0x30], xmm3
000075d5269d96c1  vmovaps [rsp+0x40], xmm5
000075d5269d96c7  vmovaps [rsp+0x50], xmm6
000075d5269d96cd  vmovaps [rsp+0x60], xmm7
000075d5269d96d3  vmovaps [rsp+0x70], xmm8
000075d5269d96d9  vmovaps [rsp+0x80], xmm9
000075d5269d96e2  vmovaps [rsp+0x90], xmm10
000075d5269d96eb  vmovaps [rsp+0xA0], xmm11
000075d5269d96f4  vmovaps [rsp+0xB0], xmm12
000075d5269d96fd  vmovaps [rsp+0xC0], xmm13
000075d5269d9706  vmovaps [rsp+0xD0], xmm14
000075d5269d970f  vmovaps [rsp+0xE0], xmm15
000075d5269d9718  sub rsp, 0x30
000075d5269d971c  movaps [rsp], xmm4
000075d5269d9720  movaps [rsp+0x10], xmm13
000075d5269d9726  movaps [rsp+0x20], xmm8
000075d5269d972c  lea rdi, [rsp]
000075d5269d9730  mov esi, 0x00
000075d5269d9735  mov rax, 0x601129E62530
000075d5269d973f  call rax
000075d5269d9741  movaps xmm4, [rsp]
000075d5269d9745  add rsp, 0x30
000075d5269d9749  vmovaps xmm0, [rsp]
000075d5269d974e  vmovaps xmm1, [rsp+0x10]
000075d5269d9754  vmovaps xmm2, [rsp+0x20]
000075d5269d975a  vmovaps xmm3, [rsp+0x30]
000075d5269d9760  vmovaps xmm5, [rsp+0x40]
000075d5269d9766  vmovaps xmm6, [rsp+0x50]
000075d5269d976c  vmovaps xmm7, [rsp+0x60]
000075d5269d9772  vmovaps xmm8, [rsp+0x70]
000075d5269d9778  vmovaps xmm9, [rsp+0x80]
000075d5269d9781  vmovaps xmm10, [rsp+0x90]
000075d5269d978a  vmovaps xmm11, [rsp+0xA0]
000075d5269d9793  vmovaps xmm12, [rsp+0xB0]
000075d5269d979c  vmovaps xmm13, [rsp+0xC0]
000075d5269d97a5  vmovaps xmm14, [rsp+0xD0]
000075d5269d97ae  vmovaps xmm15, [rsp+0xE0]
000075d5269d97b7  add rsp, 0xF0
000075d5269d97be  pop r11
000075d5269d97c0  pop r10
000075d5269d97c2  pop r9
000075d5269d97c4  pop r8
000075d5269d97c6  pop rsi
000075d5269d97c7  pop rdi
000075d5269d97c8  pop rdx
000075d5269d97c9  pop rcx
000075d5269d97ca  pop rax
000075d5269d97cb  add rsp, 0x08
000075d5269d97cf  jmp 0x000075D5269D628A
000075d5269d97d4  sub rsp, 0x08
000075d5269d97d8  push rax
000075d5269d97d9  push rcx
000075d5269d97da  push rdx
000075d5269d97db  push rdi
000075d5269d97dc  push rsi
000075d5269d97dd  push r8
000075d5269d97df  push r9
000075d5269d97e1  push r10
000075d5269d97e3  push r11
000075d5269d97e5  sub rsp, 0xF0
000075d5269d97ec  vmovaps [rsp], xmm0
000075d5269d97f1  vmovaps [rsp+0x10], xmm1
000075d5269d97f7  vmovaps [rsp+0x20], xmm2
000075d5269d97fd  vmovaps [rsp+0x30], xmm3
000075d5269d9803  vmovaps [rsp+0x40], xmm4
000075d5269d9809  vmovaps [rsp+0x50], xmm5
000075d5269d980f  vmovaps [rsp+0x60], xmm6
000075d5269d9815  vmovaps [rsp+0x70], xmm7
000075d5269d981b  vmovaps [rsp+0x80], xmm8
000075d5269d9824  vmovaps [rsp+0x90], xmm9
000075d5269d982d  vmovaps [rsp+0xA0], xmm10
000075d5269d9836  vmovaps [rsp+0xB0], xmm11
000075d5269d983f  vmovaps [rsp+0xC0], xmm12
000075d5269d9848  vmovaps [rsp+0xD0], xmm14
000075d5269d9851  vmovaps [rsp+0xE0], xmm15
000075d5269d985a  sub rsp, 0x30
000075d5269d985e  movaps [rsp], xmm13
000075d5269d9863  movaps [rsp+0x10], xmm15
000075d5269d9869  movaps [rsp+0x20], xmm9
000075d5269d986f  lea rdi, [rsp]
000075d5269d9873  mov esi, 0x00
000075d5269d9878  mov rax, 0x601129E62530
000075d5269d9882  call rax
000075d5269d9884  movaps xmm13, [rsp]
000075d5269d9889  add rsp, 0x30
000075d5269d988d  vmovaps xmm0, [rsp]
000075d5269d9892  vmovaps xmm1, [rsp+0x10]
000075d5269d9898  vmovaps xmm2, [rsp+0x20]
000075d5269d989e  vmovaps xmm3, [rsp+0x30]
000075d5269d98a4  vmovaps xmm4, [rsp+0x40]
000075d5269d98aa  vmovaps xmm5, [rsp+0x50]
000075d5269d98b0  vmovaps xmm6, [rsp+0x60]
000075d5269d98b6  vmovaps xmm7, [rsp+0x70]
000075d5269d98bc  vmovaps xmm8, [rsp+0x80]
000075d5269d98c5  vmovaps xmm9, [rsp+0x90]
000075d5269d98ce  vmovaps xmm10, [rsp+0xA0]
000075d5269d98d7  vmovaps xmm11, [rsp+0xB0]
000075d5269d98e0  vmovaps xmm12, [rsp+0xC0]
000075d5269d98e9  vmovaps xmm14, [rsp+0xD0]
000075d5269d98f2  vmovaps xmm15, [rsp+0xE0]
000075d5269d98fb  add rsp, 0xF0
000075d5269d9902  pop r11
000075d5269d9904  pop r10
000075d5269d9906  pop r9
000075d5269d9908  pop r8
000075d5269d990a  pop rsi
000075d5269d990b  pop rdi
000075d5269d990c  pop rdx
000075d5269d990d  pop rcx
000075d5269d990e  pop rax
000075d5269d990f  add rsp, 0x08
000075d5269d9913  jmp 0x000075D5269D62A5
000075d5269d9918  sub rsp, 0x08
000075d5269d991c  push rax
000075d5269d991d  push rcx
000075d5269d991e  push rdx
000075d5269d991f  push rdi
000075d5269d9920  push rsi
000075d5269d9921  push r8
000075d5269d9923  push r9
000075d5269d9925  push r10
000075d5269d9927  push r11
000075d5269d9929  sub rsp, 0xF0
000075d5269d9930  vmovaps [rsp], xmm0
000075d5269d9935  vmovaps [rsp+0x10], xmm1
000075d5269d993b  vmovaps [rsp+0x20], xmm2
000075d5269d9941  vmovaps [rsp+0x30], xmm3
000075d5269d9947  vmovaps [rsp+0x40], xmm4
000075d5269d994d  vmovaps [rsp+0x50], xmm5
000075d5269d9953  vmovaps [rsp+0x60], xmm6
000075d5269d9959  vmovaps [rsp+0x70], xmm7
000075d5269d995f  vmovaps [rsp+0x80], xmm8
000075d5269d9968  vmovaps [rsp+0x90], xmm9
000075d5269d9971  vmovaps [rsp+0xA0], xmm10
000075d5269d997a  vmovaps [rsp+0xB0], xmm11
000075d5269d9983  vmovaps [rsp+0xC0], xmm12
000075d5269d998c  vmovaps [rsp+0xD0], xmm13
000075d5269d9995  vmovaps [rsp+0xE0], xmm14
000075d5269d999e  sub rsp, 0x30
000075d5269d99a2  movaps [rsp], xmm15
000075d5269d99a7  movaps [rsp+0x10], xmm1
000075d5269d99ac  movaps [rsp+0x20], xmm5
000075d5269d99b1  lea rdi, [rsp]
000075d5269d99b5  mov esi, 0x00
000075d5269d99ba  mov rax, 0x601129E62530
000075d5269d99c4  call rax
000075d5269d99c6  movaps xmm15, [rsp]
000075d5269d99cb  add rsp, 0x30
000075d5269d99cf  vmovaps xmm0, [rsp]
000075d5269d99d4  vmovaps xmm1, [rsp+0x10]
000075d5269d99da  vmovaps xmm2, [rsp+0x20]
000075d5269d99e0  vmovaps xmm3, [rsp+0x30]
000075d5269d99e6  vmovaps xmm4, [rsp+0x40]
000075d5269d99ec  vmovaps xmm5, [rsp+0x50]
000075d5269d99f2  vmovaps xmm6, [rsp+0x60]
000075d5269d99f8  vmovaps xmm7, [rsp+0x70]
000075d5269d99fe  vmovaps xmm8, [rsp+0x80]
000075d5269d9a07  vmovaps xmm9, [rsp+0x90]
000075d5269d9a10  vmovaps xmm10, [rsp+0xA0]
000075d5269d9a19  vmovaps xmm11, [rsp+0xB0]
000075d5269d9a22  vmovaps xmm12, [rsp+0xC0]
000075d5269d9a2b  vmovaps xmm13, [rsp+0xD0]
000075d5269d9a34  vmovaps xmm14, [rsp+0xE0]
000075d5269d9a3d  add rsp, 0xF0
000075d5269d9a44  pop r11
000075d5269d9a46  pop r10
000075d5269d9a48  pop r9
000075d5269d9a4a  pop r8
000075d5269d9a4c  pop rsi
000075d5269d9a4d  pop rdi
000075d5269d9a4e  pop rdx
000075d5269d9a4f  pop rcx
000075d5269d9a50  pop rax
000075d5269d9a51  add rsp, 0x08
000075d5269d9a55  jmp 0x000075D5269D62C0
000075d5269d9a5a  call 0x000075D5268D64F0
000075d5269d9a5f  jmp 0x000075D5269D631B
000075d5269d9a64  sub rsp, 0x08
000075d5269d9a68  push rax
000075d5269d9a69  push rcx
000075d5269d9a6a  push rdx
000075d5269d9a6b  push rdi
000075d5269d9a6c  push rsi
000075d5269d9a6d  push r8
000075d5269d9a6f  push r9
000075d5269d9a71  push r10
000075d5269d9a73  push r11
000075d5269d9a75  sub rsp, 0xF0
000075d5269d9a7c  vmovaps [rsp], xmm0
000075d5269d9a81  vmovaps [rsp+0x10], xmm1
000075d5269d9a87  vmovaps [rsp+0x20], xmm2
000075d5269d9a8d  vmovaps [rsp+0x30], xmm3
000075d5269d9a93  vmovaps [rsp+0x40], xmm4
000075d5269d9a99  vmovaps [rsp+0x50], xmm5
000075d5269d9a9f  vmovaps [rsp+0x60], xmm6
000075d5269d9aa5  vmovaps [rsp+0x70], xmm7
000075d5269d9aab  vmovaps [rsp+0x80], xmm8
000075d5269d9ab4  vmovaps [rsp+0x90], xmm10
000075d5269d9abd  vmovaps [rsp+0xA0], xmm11
000075d5269d9ac6  vmovaps [rsp+0xB0], xmm12
000075d5269d9acf  vmovaps [rsp+0xC0], xmm13
000075d5269d9ad8  vmovaps [rsp+0xD0], xmm14
000075d5269d9ae1  vmovaps [rsp+0xE0], xmm15
000075d5269d9aea  sub rsp, 0x30
000075d5269d9aee  movaps [rsp], xmm9
000075d5269d9af3  movaps [rsp+0x10], xmm8
000075d5269d9af9  movaps [rsp+0x20], xmm11
000075d5269d9aff  lea rdi, [rsp]
000075d5269d9b03  mov esi, 0x00
000075d5269d9b08  mov rax, 0x601129E62530
000075d5269d9b12  call rax
000075d5269d9b14  movaps xmm9, [rsp]
000075d5269d9b19  add rsp, 0x30
000075d5269d9b1d  vmovaps xmm0, [rsp]
000075d5269d9b22  vmovaps xmm1, [rsp+0x10]
000075d5269d9b28  vmovaps xmm2, [rsp+0x20]
000075d5269d9b2e  vmovaps xmm3, [rsp+0x30]
000075d5269d9b34  vmovaps xmm4, [rsp+0x40]
000075d5269d9b3a  vmovaps xmm5, [rsp+0x50]
000075d5269d9b40  vmovaps xmm6, [rsp+0x60]
000075d5269d9b46  vmovaps xmm7, [rsp+0x70]
000075d5269d9b4c  vmovaps xmm8, [rsp+0x80]
000075d5269d9b55  vmovaps xmm10, [rsp+0x90]
000075d5269d9b5e  vmovaps xmm11, [rsp+0xA0]
000075d5269d9b67  vmovaps xmm12, [rsp+0xB0]
000075d5269d9b70  vmovaps xmm13, [rsp+0xC0]
000075d5269d9b79  vmovaps xmm14, [rsp+0xD0]
000075d5269d9b82  vmovaps xmm15, [rsp+0xE0]
000075d5269d9b8b  add rsp, 0xF0
000075d5269d9b92  pop r11
000075d5269d9b94  pop r10
000075d5269d9b96  pop r9
000075d5269d9b98  pop r8
000075d5269d9b9a  pop rsi
000075d5269d9b9b  pop rdi
000075d5269d9b9c  pop rdx
000075d5269d9b9d  pop rcx
000075d5269d9b9e  pop rax
000075d5269d9b9f  add rsp, 0x08
000075d5269d9ba3  jmp 0x000075D5269D6352
000075d5269d9ba8  sub rsp, 0x08
000075d5269d9bac  push rax
000075d5269d9bad  push rcx
000075d5269d9bae  push rdx
000075d5269d9baf  push rdi
000075d5269d9bb0  push rsi
000075d5269d9bb1  push r8
000075d5269d9bb3  push r9
000075d5269d9bb5  push r10
000075d5269d9bb7  push r11
000075d5269d9bb9  sub rsp, 0xF0
000075d5269d9bc0  vmovaps [rsp], xmm0
000075d5269d9bc5  vmovaps [rsp+0x10], xmm1
000075d5269d9bcb  vmovaps [rsp+0x20], xmm2
000075d5269d9bd1  vmovaps [rsp+0x30], xmm3
000075d5269d9bd7  vmovaps [rsp+0x40], xmm4
000075d5269d9bdd  vmovaps [rsp+0x50], xmm5
000075d5269d9be3  vmovaps [rsp+0x60], xmm6
000075d5269d9be9  vmovaps [rsp+0x70], xmm7
000075d5269d9bef  vmovaps [rsp+0x80], xmm8
000075d5269d9bf8  vmovaps [rsp+0x90], xmm9
000075d5269d9c01  vmovaps [rsp+0xA0], xmm10
000075d5269d9c0a  vmovaps [rsp+0xB0], xmm12
000075d5269d9c13  vmovaps [rsp+0xC0], xmm13
000075d5269d9c1c  vmovaps [rsp+0xD0], xmm14
000075d5269d9c25  vmovaps [rsp+0xE0], xmm15
000075d5269d9c2e  sub rsp, 0x30
000075d5269d9c32  movaps [rsp], xmm11
000075d5269d9c37  movaps [rsp+0x10], xmm10
000075d5269d9c3d  movaps [rsp+0x20], xmm6
000075d5269d9c42  lea rdi, [rsp]
000075d5269d9c46  mov esi, 0x00
000075d5269d9c4b  mov rax, 0x601129E62530
000075d5269d9c55  call rax
000075d5269d9c57  movaps xmm11, [rsp]
000075d5269d9c5c  add rsp, 0x30
000075d5269d9c60  vmovaps xmm0, [rsp]
000075d5269d9c65  vmovaps xmm1, [rsp+0x10]
000075d5269d9c6b  vmovaps xmm2, [rsp+0x20]
000075d5269d9c71  vmovaps xmm3, [rsp+0x30]
000075d5269d9c77  vmovaps xmm4, [rsp+0x40]
000075d5269d9c7d  vmovaps xmm5, [rsp+0x50]
000075d5269d9c83  vmovaps xmm6, [rsp+0x60]
000075d5269d9c89  vmovaps xmm7, [rsp+0x70]
000075d5269d9c8f  vmovaps xmm8, [rsp+0x80]
000075d5269d9c98  vmovaps xmm9, [rsp+0x90]
000075d5269d9ca1  vmovaps xmm10, [rsp+0xA0]
000075d5269d9caa  vmovaps xmm12, [rsp+0xB0]
000075d5269d9cb3  vmovaps xmm13, [rsp+0xC0]
000075d5269d9cbc  vmovaps xmm14, [rsp+0xD0]
000075d5269d9cc5  vmovaps xmm15, [rsp+0xE0]
000075d5269d9cce  add rsp, 0xF0
000075d5269d9cd5  pop r11
000075d5269d9cd7  pop r10
000075d5269d9cd9  pop r9
000075d5269d9cdb  pop r8
000075d5269d9cdd  pop rsi
000075d5269d9cde  pop rdi
000075d5269d9cdf  pop rdx
000075d5269d9ce0  pop rcx
000075d5269d9ce1  pop rax
000075d5269d9ce2  add rsp, 0x08
000075d5269d9ce6  jmp 0x000075D5269D636D
000075d5269d9ceb  sub rsp, 0x08
000075d5269d9cef  push rax
000075d5269d9cf0  push rcx
000075d5269d9cf1  push rdx
000075d5269d9cf2  push rdi
000075d5269d9cf3  push rsi
000075d5269d9cf4  push r8
000075d5269d9cf6  push r9
000075d5269d9cf8  push r10
000075d5269d9cfa  push r11
000075d5269d9cfc  sub rsp, 0xF0
000075d5269d9d03  vmovaps [rsp], xmm0
000075d5269d9d08  vmovaps [rsp+0x10], xmm1
000075d5269d9d0e  vmovaps [rsp+0x20], xmm2
000075d5269d9d14  vmovaps [rsp+0x30], xmm3
000075d5269d9d1a  vmovaps [rsp+0x40], xmm4
000075d5269d9d20  vmovaps [rsp+0x50], xmm5
000075d5269d9d26  vmovaps [rsp+0x60], xmm6
000075d5269d9d2c  vmovaps [rsp+0x70], xmm7
000075d5269d9d32  vmovaps [rsp+0x80], xmm8
000075d5269d9d3b  vmovaps [rsp+0x90], xmm9
000075d5269d9d44  vmovaps [rsp+0xA0], xmm11
000075d5269d9d4d  vmovaps [rsp+0xB0], xmm12
000075d5269d9d56  vmovaps [rsp+0xC0], xmm13
000075d5269d9d5f  vmovaps [rsp+0xD0], xmm14
000075d5269d9d68  vmovaps [rsp+0xE0], xmm15
000075d5269d9d71  sub rsp, 0x30
000075d5269d9d75  movaps [rsp], xmm10
000075d5269d9d7a  movaps [rsp+0x10], xmm14
000075d5269d9d80  movaps [rsp+0x20], xmm4
000075d5269d9d85  lea rdi, [rsp]
000075d5269d9d89  mov esi, 0x00
000075d5269d9d8e  mov rax, 0x601129E62530
000075d5269d9d98  call rax
000075d5269d9d9a  movaps xmm10, [rsp]
000075d5269d9d9f  add rsp, 0x30
000075d5269d9da3  vmovaps xmm0, [rsp]
000075d5269d9da8  vmovaps xmm1, [rsp+0x10]
000075d5269d9dae  vmovaps xmm2, [rsp+0x20]
000075d5269d9db4  vmovaps xmm3, [rsp+0x30]
000075d5269d9dba  vmovaps xmm4, [rsp+0x40]
000075d5269d9dc0  vmovaps xmm5, [rsp+0x50]
000075d5269d9dc6  vmovaps xmm6, [rsp+0x60]
000075d5269d9dcc  vmovaps xmm7, [rsp+0x70]
000075d5269d9dd2  vmovaps xmm8, [rsp+0x80]
000075d5269d9ddb  vmovaps xmm9, [rsp+0x90]
000075d5269d9de4  vmovaps xmm11, [rsp+0xA0]
000075d5269d9ded  vmovaps xmm12, [rsp+0xB0]
000075d5269d9df6  vmovaps xmm13, [rsp+0xC0]
000075d5269d9dff  vmovaps xmm14, [rsp+0xD0]
000075d5269d9e08  vmovaps xmm15, [rsp+0xE0]
000075d5269d9e11  add rsp, 0xF0
000075d5269d9e18  pop r11
000075d5269d9e1a  pop r10
000075d5269d9e1c  pop r9
000075d5269d9e1e  pop r8
000075d5269d9e20  pop rsi
000075d5269d9e21  pop rdi
000075d5269d9e22  pop rdx
000075d5269d9e23  pop rcx
000075d5269d9e24  pop rax
000075d5269d9e25  add rsp, 0x08
000075d5269d9e29  jmp 0x000075D5269D6388
000075d5269d9e2e  sub rsp, 0x08
000075d5269d9e32  push rax
000075d5269d9e33  push rcx
000075d5269d9e34  push rdx
000075d5269d9e35  push rdi
000075d5269d9e36  push rsi
000075d5269d9e37  push r8
000075d5269d9e39  push r9
000075d5269d9e3b  push r10
000075d5269d9e3d  push r11
000075d5269d9e3f  sub rsp, 0xF0
000075d5269d9e46  vmovaps [rsp], xmm0
000075d5269d9e4b  vmovaps [rsp+0x10], xmm1
000075d5269d9e51  vmovaps [rsp+0x20], xmm2
000075d5269d9e57  vmovaps [rsp+0x30], xmm3
000075d5269d9e5d  vmovaps [rsp+0x40], xmm4
000075d5269d9e63  vmovaps [rsp+0x50], xmm5
000075d5269d9e69  vmovaps [rsp+0x60], xmm6
000075d5269d9e6f  vmovaps [rsp+0x70], xmm7
000075d5269d9e75  vmovaps [rsp+0x80], xmm9
000075d5269d9e7e  vmovaps [rsp+0x90], xmm10
000075d5269d9e87  vmovaps [rsp+0xA0], xmm11
000075d5269d9e90  vmovaps [rsp+0xB0], xmm12
000075d5269d9e99  vmovaps [rsp+0xC0], xmm13
000075d5269d9ea2  vmovaps [rsp+0xD0], xmm14
000075d5269d9eab  vmovaps [rsp+0xE0], xmm15
000075d5269d9eb4  sub rsp, 0x30
000075d5269d9eb8  movaps [rsp], xmm8
000075d5269d9ebd  movaps [rsp+0x10], xmm1
000075d5269d9ec2  movaps [rsp+0x20], xmm14
000075d5269d9ec8  lea rdi, [rsp]
000075d5269d9ecc  mov esi, 0x00
000075d5269d9ed1  mov rax, 0x601129E62530
000075d5269d9edb  call rax
000075d5269d9edd  movaps xmm8, [rsp]
000075d5269d9ee2  add rsp, 0x30
000075d5269d9ee6  vmovaps xmm0, [rsp]
000075d5269d9eeb  vmovaps xmm1, [rsp+0x10]
000075d5269d9ef1  vmovaps xmm2, [rsp+0x20]
000075d5269d9ef7  vmovaps xmm3, [rsp+0x30]
000075d5269d9efd  vmovaps xmm4, [rsp+0x40]
000075d5269d9f03  vmovaps xmm5, [rsp+0x50]
000075d5269d9f09  vmovaps xmm6, [rsp+0x60]
000075d5269d9f0f  vmovaps xmm7, [rsp+0x70]
000075d5269d9f15  vmovaps xmm9, [rsp+0x80]
000075d5269d9f1e  vmovaps xmm10, [rsp+0x90]
000075d5269d9f27  vmovaps xmm11, [rsp+0xA0]
000075d5269d9f30  vmovaps xmm12, [rsp+0xB0]
000075d5269d9f39  vmovaps xmm13, [rsp+0xC0]
000075d5269d9f42  vmovaps xmm14, [rsp+0xD0]
000075d5269d9f4b  vmovaps xmm15, [rsp+0xE0]
000075d5269d9f54  add rsp, 0xF0
000075d5269d9f5b  pop r11
000075d5269d9f5d  pop r10
000075d5269d9f5f  pop r9
000075d5269d9f61  pop r8
000075d5269d9f63  pop rsi
000075d5269d9f64  pop rdi
000075d5269d9f65  pop rdx
000075d5269d9f66  pop rcx
000075d5269d9f67  pop rax
000075d5269d9f68  add rsp, 0x08
000075d5269d9f6c  jmp 0x000075D5269D63AE
000075d5269d9f71  sub rsp, 0x08
000075d5269d9f75  push rax
000075d5269d9f76  push rcx
000075d5269d9f77  push rdx
000075d5269d9f78  push rdi
000075d5269d9f79  push rsi
000075d5269d9f7a  push r8
000075d5269d9f7c  push r9
000075d5269d9f7e  push r10
000075d5269d9f80  push r11
000075d5269d9f82  sub rsp, 0xF0
000075d5269d9f89  vmovaps [rsp], xmm0
000075d5269d9f8e  vmovaps [rsp+0x10], xmm1
000075d5269d9f94  vmovaps [rsp+0x20], xmm2
000075d5269d9f9a  vmovaps [rsp+0x30], xmm3
000075d5269d9fa0  vmovaps [rsp+0x40], xmm4
000075d5269d9fa6  vmovaps [rsp+0x50], xmm5
000075d5269d9fac  vmovaps [rsp+0x60], xmm7
000075d5269d9fb2  vmovaps [rsp+0x70], xmm8
000075d5269d9fb8  vmovaps [rsp+0x80], xmm9
000075d5269d9fc1  vmovaps [rsp+0x90], xmm10
000075d5269d9fca  vmovaps [rsp+0xA0], xmm11
000075d5269d9fd3  vmovaps [rsp+0xB0], xmm12
000075d5269d9fdc  vmovaps [rsp+0xC0], xmm13
000075d5269d9fe5  vmovaps [rsp+0xD0], xmm14
000075d5269d9fee  vmovaps [rsp+0xE0], xmm15
000075d5269d9ff7  sub rsp, 0x30
000075d5269d9ffb  movaps [rsp], xmm6
000075d5269d9fff  movaps [rsp+0x10], xmm1
000075d5269da004  movaps [rsp+0x20], xmm14
000075d5269da00a  lea rdi, [rsp]
000075d5269da00e  mov esi, 0x00
000075d5269da013  mov rax, 0x601129E62530
000075d5269da01d  call rax
000075d5269da01f  movaps xmm6, [rsp]
000075d5269da023  add rsp, 0x30
000075d5269da027  vmovaps xmm0, [rsp]
000075d5269da02c  vmovaps xmm1, [rsp+0x10]
000075d5269da032  vmovaps xmm2, [rsp+0x20]
000075d5269da038  vmovaps xmm3, [rsp+0x30]
000075d5269da03e  vmovaps xmm4, [rsp+0x40]
000075d5269da044  vmovaps xmm5, [rsp+0x50]
000075d5269da04a  vmovaps xmm7, [rsp+0x60]
000075d5269da050  vmovaps xmm8, [rsp+0x70]
000075d5269da056  vmovaps xmm9, [rsp+0x80]
000075d5269da05f  vmovaps xmm10, [rsp+0x90]
000075d5269da068  vmovaps xmm11, [rsp+0xA0]
000075d5269da071  vmovaps xmm12, [rsp+0xB0]
000075d5269da07a  vmovaps xmm13, [rsp+0xC0]
000075d5269da083  vmovaps xmm14, [rsp+0xD0]
000075d5269da08c  vmovaps xmm15, [rsp+0xE0]
000075d5269da095  add rsp, 0xF0
000075d5269da09c  pop r11
000075d5269da09e  pop r10
000075d5269da0a0  pop r9
000075d5269da0a2  pop r8
000075d5269da0a4  pop rsi
000075d5269da0a5  pop rdi
000075d5269da0a6  pop rdx
000075d5269da0a7  pop rcx
000075d5269da0a8  pop rax
000075d5269da0a9  add rsp, 0x08
000075d5269da0ad  jmp 0x000075D5269D63DA
000075d5269da0b2  sub rsp, 0x08
000075d5269da0b6  push rax
000075d5269da0b7  push rcx
000075d5269da0b8  push rdx
000075d5269da0b9  push rdi
000075d5269da0ba  push rsi
000075d5269da0bb  push r8
000075d5269da0bd  push r9
000075d5269da0bf  push r10
000075d5269da0c1  push r11
000075d5269da0c3  sub rsp, 0xF0
000075d5269da0ca  vmovaps [rsp], xmm0
000075d5269da0cf  vmovaps [rsp+0x10], xmm1
000075d5269da0d5  vmovaps [rsp+0x20], xmm2
000075d5269da0db  vmovaps [rsp+0x30], xmm3
000075d5269da0e1  vmovaps [rsp+0x40], xmm4
000075d5269da0e7  vmovaps [rsp+0x50], xmm5
000075d5269da0ed  vmovaps [rsp+0x60], xmm6
000075d5269da0f3  vmovaps [rsp+0x70], xmm7
000075d5269da0f9  vmovaps [rsp+0x80], xmm8
000075d5269da102  vmovaps [rsp+0x90], xmm9
000075d5269da10b  vmovaps [rsp+0xA0], xmm10
000075d5269da114  vmovaps [rsp+0xB0], xmm11
000075d5269da11d  vmovaps [rsp+0xC0], xmm12
000075d5269da126  vmovaps [rsp+0xD0], xmm13
000075d5269da12f  vmovaps [rsp+0xE0], xmm15
000075d5269da138  sub rsp, 0x30
000075d5269da13c  movaps [rsp], xmm14
000075d5269da141  movaps [rsp+0x10], xmm12
000075d5269da147  movaps [rsp+0x20], xmm1
000075d5269da14c  lea rdi, [rsp]
000075d5269da150  mov esi, 0x00
000075d5269da155  mov rax, 0x601129E62530
000075d5269da15f  call rax
000075d5269da161  movaps xmm14, [rsp]
000075d5269da166  add rsp, 0x30
000075d5269da16a  vmovaps xmm0, [rsp]
000075d5269da16f  vmovaps xmm1, [rsp+0x10]
000075d5269da175  vmovaps xmm2, [rsp+0x20]
000075d5269da17b  vmovaps xmm3, [rsp+0x30]
000075d5269da181  vmovaps xmm4, [rsp+0x40]
000075d5269da187  vmovaps xmm5, [rsp+0x50]
000075d5269da18d  vmovaps xmm6, [rsp+0x60]
000075d5269da193  vmovaps xmm7, [rsp+0x70]
000075d5269da199  vmovaps xmm8, [rsp+0x80]
000075d5269da1a2  vmovaps xmm9, [rsp+0x90]
000075d5269da1ab  vmovaps xmm10, [rsp+0xA0]
000075d5269da1b4  vmovaps xmm11, [rsp+0xB0]
000075d5269da1bd  vmovaps xmm12, [rsp+0xC0]
000075d5269da1c6  vmovaps xmm13, [rsp+0xD0]
000075d5269da1cf  vmovaps xmm15, [rsp+0xE0]
000075d5269da1d8  add rsp, 0xF0
000075d5269da1df  pop r11
000075d5269da1e1  pop r10
000075d5269da1e3  pop r9
000075d5269da1e5  pop r8
000075d5269da1e7  pop rsi
000075d5269da1e8  pop rdi
000075d5269da1e9  pop rdx
000075d5269da1ea  pop rcx
000075d5269da1eb  pop rax
000075d5269da1ec  add rsp, 0x08
000075d5269da1f0  jmp 0x000075D5269D6400
000075d5269da1f5  sub rsp, 0x08
000075d5269da1f9  push rax
000075d5269da1fa  push rcx
000075d5269da1fb  push rdx
000075d5269da1fc  push rdi
000075d5269da1fd  push rsi
000075d5269da1fe  push r8
000075d5269da200  push r9
000075d5269da202  push r10
000075d5269da204  push r11
000075d5269da206  sub rsp, 0xF0
000075d5269da20d  vmovaps [rsp], xmm0
000075d5269da212  vmovaps [rsp+0x10], xmm2
000075d5269da218  vmovaps [rsp+0x20], xmm3
000075d5269da21e  vmovaps [rsp+0x30], xmm4
000075d5269da224  vmovaps [rsp+0x40], xmm5
000075d5269da22a  vmovaps [rsp+0x50], xmm6
000075d5269da230  vmovaps [rsp+0x60], xmm7
000075d5269da236  vmovaps [rsp+0x70], xmm8
000075d5269da23c  vmovaps [rsp+0x80], xmm9
000075d5269da245  vmovaps [rsp+0x90], xmm10
000075d5269da24e  vmovaps [rsp+0xA0], xmm11
000075d5269da257  vmovaps [rsp+0xB0], xmm12
000075d5269da260  vmovaps [rsp+0xC0], xmm13
000075d5269da269  vmovaps [rsp+0xD0], xmm14
000075d5269da272  vmovaps [rsp+0xE0], xmm15
000075d5269da27b  sub rsp, 0x30
000075d5269da27f  movaps [rsp], xmm1
000075d5269da283  movaps [rsp+0x10], xmm13
000075d5269da289  movaps [rsp+0x20], xmm9
000075d5269da28f  lea rdi, [rsp]
000075d5269da293  mov esi, 0x00
000075d5269da298  mov rax, 0x601129E62530
000075d5269da2a2  call rax
000075d5269da2a4  movaps xmm1, [rsp]
000075d5269da2a8  add rsp, 0x30
000075d5269da2ac  vmovaps xmm0, [rsp]
000075d5269da2b1  vmovaps xmm2, [rsp+0x10]
000075d5269da2b7  vmovaps xmm3, [rsp+0x20]
000075d5269da2bd  vmovaps xmm4, [rsp+0x30]
000075d5269da2c3  vmovaps xmm5, [rsp+0x40]
000075d5269da2c9  vmovaps xmm6, [rsp+0x50]
000075d5269da2cf  vmovaps xmm7, [rsp+0x60]
000075d5269da2d5  vmovaps xmm8, [rsp+0x70]
000075d5269da2db  vmovaps xmm9, [rsp+0x80]
000075d5269da2e4  vmovaps xmm10, [rsp+0x90]
000075d5269da2ed  vmovaps xmm11, [rsp+0xA0]
000075d5269da2f6  vmovaps xmm12, [rsp+0xB0]
000075d5269da2ff  vmovaps xmm13, [rsp+0xC0]
000075d5269da308  vmovaps xmm14, [rsp+0xD0]
000075d5269da311  vmovaps xmm15, [rsp+0xE0]
000075d5269da31a  add rsp, 0xF0
000075d5269da321  pop r11
000075d5269da323  pop r10
000075d5269da325  pop r9
000075d5269da327  pop r8
000075d5269da329  pop rsi
000075d5269da32a  pop rdi
000075d5269da32b  pop rdx
000075d5269da32c  pop rcx
000075d5269da32d  pop rax
000075d5269da32e  add rsp, 0x08
000075d5269da332  jmp 0x000075D5269D641A
000075d5269da337  sub rsp, 0x08
000075d5269da33b  push rax
000075d5269da33c  push rcx
000075d5269da33d  push rdx
000075d5269da33e  push rdi
000075d5269da33f  push rsi
000075d5269da340  push r8
000075d5269da342  push r9
000075d5269da344  push r10
000075d5269da346  push r11
000075d5269da348  sub rsp, 0xF0
000075d5269da34f  vmovaps [rsp], xmm0
000075d5269da354  vmovaps [rsp+0x10], xmm1
000075d5269da35a  vmovaps [rsp+0x20], xmm2
000075d5269da360  vmovaps [rsp+0x30], xmm3
000075d5269da366  vmovaps [rsp+0x40], xmm4
000075d5269da36c  vmovaps [rsp+0x50], xmm5
000075d5269da372  vmovaps [rsp+0x60], xmm6
000075d5269da378  vmovaps [rsp+0x70], xmm7
000075d5269da37e  vmovaps [rsp+0x80], xmm8
000075d5269da387  vmovaps [rsp+0x90], xmm9
000075d5269da390  vmovaps [rsp+0xA0], xmm10
000075d5269da399  vmovaps [rsp+0xB0], xmm11
000075d5269da3a2  vmovaps [rsp+0xC0], xmm13
000075d5269da3ab  vmovaps [rsp+0xD0], xmm14
000075d5269da3b4  vmovaps [rsp+0xE0], xmm15
000075d5269da3bd  sub rsp, 0x30
000075d5269da3c1  movaps [rsp], xmm12
000075d5269da3c6  movaps [rsp+0x10], xmm7
000075d5269da3cb  movaps [rsp+0x20], xmm13
000075d5269da3d1  lea rdi, [rsp]
000075d5269da3d5  mov esi, 0x00
000075d5269da3da  mov rax, 0x601129E62530
000075d5269da3e4  call rax
000075d5269da3e6  movaps xmm12, [rsp]
000075d5269da3eb  add rsp, 0x30
000075d5269da3ef  vmovaps xmm0, [rsp]
000075d5269da3f4  vmovaps xmm1, [rsp+0x10]
000075d5269da3fa  vmovaps xmm2, [rsp+0x20]
000075d5269da400  vmovaps xmm3, [rsp+0x30]
000075d5269da406  vmovaps xmm4, [rsp+0x40]
000075d5269da40c  vmovaps xmm5, [rsp+0x50]
000075d5269da412  vmovaps xmm6, [rsp+0x60]
000075d5269da418  vmovaps xmm7, [rsp+0x70]
000075d5269da41e  vmovaps xmm8, [rsp+0x80]
000075d5269da427  vmovaps xmm9, [rsp+0x90]
000075d5269da430  vmovaps xmm10, [rsp+0xA0]
000075d5269da439  vmovaps xmm11, [rsp+0xB0]
000075d5269da442  vmovaps xmm13, [rsp+0xC0]
000075d5269da44b  vmovaps xmm14, [rsp+0xD0]
000075d5269da454  vmovaps xmm15, [rsp+0xE0]
000075d5269da45d  add rsp, 0xF0
000075d5269da464  pop r11
000075d5269da466  pop r10
000075d5269da468  pop r9
000075d5269da46a  pop r8
000075d5269da46c  pop rsi
000075d5269da46d  pop rdi
000075d5269da46e  pop rdx
000075d5269da46f  pop rcx
000075d5269da470  pop rax
000075d5269da471  add rsp, 0x08
000075d5269da475  jmp 0x000075D5269D6441
000075d5269da47a  sub rsp, 0x08
000075d5269da47e  push rax
000075d5269da47f  push rcx
000075d5269da480  push rdx
000075d5269da481  push rdi
000075d5269da482  push rsi
000075d5269da483  push r8
000075d5269da485  push r9
000075d5269da487  push r10
000075d5269da489  push r11
000075d5269da48b  sub rsp, 0xF0
000075d5269da492  vmovaps [rsp], xmm0
000075d5269da497  vmovaps [rsp+0x10], xmm1
000075d5269da49d  vmovaps [rsp+0x20], xmm2
000075d5269da4a3  vmovaps [rsp+0x30], xmm3
000075d5269da4a9  vmovaps [rsp+0x40], xmm4
000075d5269da4af  vmovaps [rsp+0x50], xmm5
000075d5269da4b5  vmovaps [rsp+0x60], xmm6
000075d5269da4bb  vmovaps [rsp+0x70], xmm7
000075d5269da4c1  vmovaps [rsp+0x80], xmm8
000075d5269da4ca  vmovaps [rsp+0x90], xmm9
000075d5269da4d3  vmovaps [rsp+0xA0], xmm10
000075d5269da4dc  vmovaps [rsp+0xB0], xmm11
000075d5269da4e5  vmovaps [rsp+0xC0], xmm12
000075d5269da4ee  vmovaps [rsp+0xD0], xmm14
000075d5269da4f7  vmovaps [rsp+0xE0], xmm15
000075d5269da500  sub rsp, 0x30
000075d5269da504  movaps [rsp], xmm13
000075d5269da509  movaps [rsp+0x10], xmm15
000075d5269da50f  movaps [rsp+0x20], xmm8
000075d5269da515  lea rdi, [rsp]
000075d5269da519  mov esi, 0x00
000075d5269da51e  mov rax, 0x601129E62530
000075d5269da528  call rax
000075d5269da52a  movaps xmm13, [rsp]
000075d5269da52f  add rsp, 0x30
000075d5269da533  vmovaps xmm0, [rsp]
000075d5269da538  vmovaps xmm1, [rsp+0x10]
000075d5269da53e  vmovaps xmm2, [rsp+0x20]
000075d5269da544  vmovaps xmm3, [rsp+0x30]
000075d5269da54a  vmovaps xmm4, [rsp+0x40]
000075d5269da550  vmovaps xmm5, [rsp+0x50]
000075d5269da556  vmovaps xmm6, [rsp+0x60]
000075d5269da55c  vmovaps xmm7, [rsp+0x70]
000075d5269da562  vmovaps xmm8, [rsp+0x80]
000075d5269da56b  vmovaps xmm9, [rsp+0x90]
000075d5269da574  vmovaps xmm10, [rsp+0xA0]
000075d5269da57d  vmovaps xmm11, [rsp+0xB0]
000075d5269da586  vmovaps xmm12, [rsp+0xC0]
000075d5269da58f  vmovaps xmm14, [rsp+0xD0]
000075d5269da598  vmovaps xmm15, [rsp+0xE0]
000075d5269da5a1  add rsp, 0xF0
000075d5269da5a8  pop r11
000075d5269da5aa  pop r10
000075d5269da5ac  pop r9
000075d5269da5ae  pop r8
000075d5269da5b0  pop rsi
000075d5269da5b1  pop rdi
000075d5269da5b2  pop rdx
000075d5269da5b3  pop rcx
000075d5269da5b4  pop rax
000075d5269da5b5  add rsp, 0x08
000075d5269da5b9  jmp 0x000075D5269D645C
000075d5269da5be  sub rsp, 0x08
000075d5269da5c2  push rax
000075d5269da5c3  push rcx
000075d5269da5c4  push rdx
000075d5269da5c5  push rdi
000075d5269da5c6  push rsi
000075d5269da5c7  push r8
000075d5269da5c9  push r9
000075d5269da5cb  push r10
000075d5269da5cd  push r11
000075d5269da5cf  sub rsp, 0xF0
000075d5269da5d6  vmovaps [rsp], xmm0
000075d5269da5db  vmovaps [rsp+0x10], xmm1
000075d5269da5e1  vmovaps [rsp+0x20], xmm2
000075d5269da5e7  vmovaps [rsp+0x30], xmm3
000075d5269da5ed  vmovaps [rsp+0x40], xmm4
000075d5269da5f3  vmovaps [rsp+0x50], xmm5
000075d5269da5f9  vmovaps [rsp+0x60], xmm6
000075d5269da5ff  vmovaps [rsp+0x70], xmm7
000075d5269da605  vmovaps [rsp+0x80], xmm9
000075d5269da60e  vmovaps [rsp+0x90], xmm10
000075d5269da617  vmovaps [rsp+0xA0], xmm11
000075d5269da620  vmovaps [rsp+0xB0], xmm12
000075d5269da629  vmovaps [rsp+0xC0], xmm13
000075d5269da632  vmovaps [rsp+0xD0], xmm14
000075d5269da63b  vmovaps [rsp+0xE0], xmm15
000075d5269da644  sub rsp, 0x30
000075d5269da648  movaps [rsp], xmm8
000075d5269da64d  movaps [rsp+0x10], xmm15
000075d5269da653  movaps [rsp+0x20], xmm9
000075d5269da659  lea rdi, [rsp]
000075d5269da65d  mov esi, 0x00
000075d5269da662  mov rax, 0x601129E62530
000075d5269da66c  call rax
000075d5269da66e  movaps xmm8, [rsp]
000075d5269da673  add rsp, 0x30
000075d5269da677  vmovaps xmm0, [rsp]
000075d5269da67c  vmovaps xmm1, [rsp+0x10]
000075d5269da682  vmovaps xmm2, [rsp+0x20]
000075d5269da688  vmovaps xmm3, [rsp+0x30]
000075d5269da68e  vmovaps xmm4, [rsp+0x40]
000075d5269da694  vmovaps xmm5, [rsp+0x50]
000075d5269da69a  vmovaps xmm6, [rsp+0x60]
000075d5269da6a0  vmovaps xmm7, [rsp+0x70]
000075d5269da6a6  vmovaps xmm9, [rsp+0x80]
000075d5269da6af  vmovaps xmm10, [rsp+0x90]
000075d5269da6b8  vmovaps xmm11, [rsp+0xA0]
000075d5269da6c1  vmovaps xmm12, [rsp+0xB0]
000075d5269da6ca  vmovaps xmm13, [rsp+0xC0]
000075d5269da6d3  vmovaps xmm14, [rsp+0xD0]
000075d5269da6dc  vmovaps xmm15, [rsp+0xE0]
000075d5269da6e5  add rsp, 0xF0
000075d5269da6ec  pop r11
000075d5269da6ee  pop r10
000075d5269da6f0  pop r9
000075d5269da6f2  pop r8
000075d5269da6f4  pop rsi
000075d5269da6f5  pop rdi
000075d5269da6f6  pop rdx
000075d5269da6f7  pop rcx
000075d5269da6f8  pop rax
000075d5269da6f9  add rsp, 0x08
000075d5269da6fd  jmp 0x000075D5269D648A
000075d5269da702  sub rsp, 0x08
000075d5269da706  push rax
000075d5269da707  push rcx
000075d5269da708  push rdx
000075d5269da709  push rdi
000075d5269da70a  push rsi
000075d5269da70b  push r8
000075d5269da70d  push r9
000075d5269da70f  push r10
000075d5269da711  push r11
000075d5269da713  sub rsp, 0xF0
000075d5269da71a  vmovaps [rsp], xmm0
000075d5269da71f  vmovaps [rsp+0x10], xmm1
000075d5269da725  vmovaps [rsp+0x20], xmm2
000075d5269da72b  vmovaps [rsp+0x30], xmm3
000075d5269da731  vmovaps [rsp+0x40], xmm4
000075d5269da737  vmovaps [rsp+0x50], xmm5
000075d5269da73d  vmovaps [rsp+0x60], xmm6
000075d5269da743  vmovaps [rsp+0x70], xmm7
000075d5269da749  vmovaps [rsp+0x80], xmm8
000075d5269da752  vmovaps [rsp+0x90], xmm9
000075d5269da75b  vmovaps [rsp+0xA0], xmm10
000075d5269da764  vmovaps [rsp+0xB0], xmm11
000075d5269da76d  vmovaps [rsp+0xC0], xmm12
000075d5269da776  vmovaps [rsp+0xD0], xmm13
000075d5269da77f  vmovaps [rsp+0xE0], xmm14
000075d5269da788  sub rsp, 0x30
000075d5269da78c  movaps [rsp], xmm15
000075d5269da791  movaps [rsp+0x10], xmm11
000075d5269da797  movaps [rsp+0x20], xmm6
000075d5269da79c  lea rdi, [rsp]
000075d5269da7a0  mov esi, 0x00
000075d5269da7a5  mov rax, 0x601129E62530
000075d5269da7af  call rax
000075d5269da7b1  movaps xmm15, [rsp]
000075d5269da7b6  add rsp, 0x30
000075d5269da7ba  vmovaps xmm0, [rsp]
000075d5269da7bf  vmovaps xmm1, [rsp+0x10]
000075d5269da7c5  vmovaps xmm2, [rsp+0x20]
000075d5269da7cb  vmovaps xmm3, [rsp+0x30]
000075d5269da7d1  vmovaps xmm4, [rsp+0x40]
000075d5269da7d7  vmovaps xmm5, [rsp+0x50]
000075d5269da7dd  vmovaps xmm6, [rsp+0x60]
000075d5269da7e3  vmovaps xmm7, [rsp+0x70]
000075d5269da7e9  vmovaps xmm8, [rsp+0x80]
000075d5269da7f2  vmovaps xmm9, [rsp+0x90]
000075d5269da7fb  vmovaps xmm10, [rsp+0xA0]
000075d5269da804  vmovaps xmm11, [rsp+0xB0]
000075d5269da80d  vmovaps xmm12, [rsp+0xC0]
000075d5269da816  vmovaps xmm13, [rsp+0xD0]
000075d5269da81f  vmovaps xmm14, [rsp+0xE0]
000075d5269da828  add rsp, 0xF0
000075d5269da82f  pop r11
000075d5269da831  pop r10
000075d5269da833  pop r9
000075d5269da835  pop r8
000075d5269da837  pop rsi
000075d5269da838  pop rdi
000075d5269da839  pop rdx
000075d5269da83a  pop rcx
000075d5269da83b  pop rax
000075d5269da83c  add rsp, 0x08
000075d5269da840  jmp 0x000075D5269D64A5
000075d5269da845  sub rsp, 0x08
000075d5269da849  push rax
000075d5269da84a  push rcx
000075d5269da84b  push rdx
000075d5269da84c  push rdi
000075d5269da84d  push rsi
000075d5269da84e  push r8
000075d5269da850  push r9
000075d5269da852  push r10
000075d5269da854  push r11
000075d5269da856  sub rsp, 0xF0
000075d5269da85d  vmovaps [rsp], xmm0
000075d5269da862  vmovaps [rsp+0x10], xmm1
000075d5269da868  vmovaps [rsp+0x20], xmm2
000075d5269da86e  vmovaps [rsp+0x30], xmm3
000075d5269da874  vmovaps [rsp+0x40], xmm4
000075d5269da87a  vmovaps [rsp+0x50], xmm5
000075d5269da880  vmovaps [rsp+0x60], xmm6
000075d5269da886  vmovaps [rsp+0x70], xmm8
000075d5269da88c  vmovaps [rsp+0x80], xmm9
000075d5269da895  vmovaps [rsp+0x90], xmm10
000075d5269da89e  vmovaps [rsp+0xA0], xmm11
000075d5269da8a7  vmovaps [rsp+0xB0], xmm12
000075d5269da8b0  vmovaps [rsp+0xC0], xmm13
000075d5269da8b9  vmovaps [rsp+0xD0], xmm14
000075d5269da8c2  vmovaps [rsp+0xE0], xmm15
000075d5269da8cb  sub rsp, 0x30
000075d5269da8cf  movaps [rsp], xmm7
000075d5269da8d3  movaps [rsp+0x10], xmm11
000075d5269da8d9  movaps [rsp+0x20], xmm9
000075d5269da8df  lea rdi, [rsp]
000075d5269da8e3  mov esi, 0x00
000075d5269da8e8  mov rax, 0x601129E62530
000075d5269da8f2  call rax
000075d5269da8f4  movaps xmm7, [rsp]
000075d5269da8f8  add rsp, 0x30
000075d5269da8fc  vmovaps xmm0, [rsp]
000075d5269da901  vmovaps xmm1, [rsp+0x10]
000075d5269da907  vmovaps xmm2, [rsp+0x20]
000075d5269da90d  vmovaps xmm3, [rsp+0x30]
000075d5269da913  vmovaps xmm4, [rsp+0x40]
000075d5269da919  vmovaps xmm5, [rsp+0x50]
000075d5269da91f  vmovaps xmm6, [rsp+0x60]
000075d5269da925  vmovaps xmm8, [rsp+0x70]
000075d5269da92b  vmovaps xmm9, [rsp+0x80]
000075d5269da934  vmovaps xmm10, [rsp+0x90]
000075d5269da93d  vmovaps xmm11, [rsp+0xA0]
000075d5269da946  vmovaps xmm12, [rsp+0xB0]
000075d5269da94f  vmovaps xmm13, [rsp+0xC0]
000075d5269da958  vmovaps xmm14, [rsp+0xD0]
000075d5269da961  vmovaps xmm15, [rsp+0xE0]
000075d5269da96a  add rsp, 0xF0
000075d5269da971  pop r11
000075d5269da973  pop r10
000075d5269da975  pop r9
000075d5269da977  pop r8
000075d5269da979  pop rsi
000075d5269da97a  pop rdi
000075d5269da97b  pop rdx
000075d5269da97c  pop rcx
000075d5269da97d  pop rax
000075d5269da97e  add rsp, 0x08
000075d5269da982  jmp 0x000075D5269D64D2
000075d5269da987  sub rsp, 0x08
000075d5269da98b  push rax
000075d5269da98c  push rcx
000075d5269da98d  push rdx
000075d5269da98e  push rdi
000075d5269da98f  push rsi
000075d5269da990  push r8
000075d5269da992  push r9
000075d5269da994  push r10
000075d5269da996  push r11
000075d5269da998  sub rsp, 0xF0
000075d5269da99f  vmovaps [rsp], xmm0
000075d5269da9a4  vmovaps [rsp+0x10], xmm1
000075d5269da9aa  vmovaps [rsp+0x20], xmm2
000075d5269da9b0  vmovaps [rsp+0x30], xmm3
000075d5269da9b6  vmovaps [rsp+0x40], xmm4
000075d5269da9bc  vmovaps [rsp+0x50], xmm5
000075d5269da9c2  vmovaps [rsp+0x60], xmm6
000075d5269da9c8  vmovaps [rsp+0x70], xmm7
000075d5269da9ce  vmovaps [rsp+0x80], xmm8
000075d5269da9d7  vmovaps [rsp+0x90], xmm9
000075d5269da9e0  vmovaps [rsp+0xA0], xmm10
000075d5269da9e9  vmovaps [rsp+0xB0], xmm12
000075d5269da9f2  vmovaps [rsp+0xC0], xmm13
000075d5269da9fb  vmovaps [rsp+0xD0], xmm14
000075d5269daa04  vmovaps [rsp+0xE0], xmm15
000075d5269daa0d  sub rsp, 0x30
000075d5269daa11  movaps [rsp], xmm11
000075d5269daa16  movaps [rsp+0x10], xmm10
000075d5269daa1c  movaps [rsp+0x20], xmm14
000075d5269daa22  lea rdi, [rsp]
000075d5269daa26  mov esi, 0x00
000075d5269daa2b  mov rax, 0x601129E62530
000075d5269daa35  call rax
000075d5269daa37  movaps xmm11, [rsp]
000075d5269daa3c  add rsp, 0x30
000075d5269daa40  vmovaps xmm0, [rsp]
000075d5269daa45  vmovaps xmm1, [rsp+0x10]
000075d5269daa4b  vmovaps xmm2, [rsp+0x20]
000075d5269daa51  vmovaps xmm3, [rsp+0x30]
000075d5269daa57  vmovaps xmm4, [rsp+0x40]
000075d5269daa5d  vmovaps xmm5, [rsp+0x50]
000075d5269daa63  vmovaps xmm6, [rsp+0x60]
000075d5269daa69  vmovaps xmm7, [rsp+0x70]
000075d5269daa6f  vmovaps xmm8, [rsp+0x80]
000075d5269daa78  vmovaps xmm9, [rsp+0x90]
000075d5269daa81  vmovaps xmm10, [rsp+0xA0]
000075d5269daa8a  vmovaps xmm12, [rsp+0xB0]
000075d5269daa93  vmovaps xmm13, [rsp+0xC0]
000075d5269daa9c  vmovaps xmm14, [rsp+0xD0]
000075d5269daaa5  vmovaps xmm15, [rsp+0xE0]
000075d5269daaae  add rsp, 0xF0
000075d5269daab5  pop r11
000075d5269daab7  pop r10
000075d5269daab9  pop r9
000075d5269daabb  pop r8
000075d5269daabd  pop rsi
000075d5269daabe  pop rdi
000075d5269daabf  pop rdx
000075d5269daac0  pop rcx
000075d5269daac1  pop rax
000075d5269daac2  add rsp, 0x08
000075d5269daac6  jmp 0x000075D5269D64ED
000075d5269daacb  call 0x000075D5268E45A0
000075d5269daad0  jmp 0x000075D5269D64F7
000075d5269daad5  sub rsp, 0x08
000075d5269daad9  push rax
000075d5269daada  push rcx
000075d5269daadb  push rdx
000075d5269daadc  push rdi
000075d5269daadd  push rsi
000075d5269daade  push r8
000075d5269daae0  push r9
000075d5269daae2  push r10
000075d5269daae4  push r11
000075d5269daae6  sub rsp, 0xF0
000075d5269daaed  vmovaps [rsp], xmm0
000075d5269daaf2  vmovaps [rsp+0x10], xmm1
000075d5269daaf8  vmovaps [rsp+0x20], xmm2
000075d5269daafe  vmovaps [rsp+0x30], xmm3
000075d5269dab04  vmovaps [rsp+0x40], xmm4
000075d5269dab0a  vmovaps [rsp+0x50], xmm5
000075d5269dab10  vmovaps [rsp+0x60], xmm6
000075d5269dab16  vmovaps [rsp+0x70], xmm7
000075d5269dab1c  vmovaps [rsp+0x80], xmm8
000075d5269dab25  vmovaps [rsp+0x90], xmm9
000075d5269dab2e  vmovaps [rsp+0xA0], xmm11
000075d5269dab37  vmovaps [rsp+0xB0], xmm12
000075d5269dab40  vmovaps [rsp+0xC0], xmm13
000075d5269dab49  vmovaps [rsp+0xD0], xmm14
000075d5269dab52  vmovaps [rsp+0xE0], xmm15
000075d5269dab5b  sub rsp, 0x30
000075d5269dab5f  movaps [rsp], xmm10
000075d5269dab64  movaps [rsp+0x10], xmm1
000075d5269dab69  movaps [rsp+0x20], xmm12
000075d5269dab6f  lea rdi, [rsp]
000075d5269dab73  mov esi, 0x00
000075d5269dab78  mov rax, 0x601129E62530
000075d5269dab82  call rax
000075d5269dab84  movaps xmm10, [rsp]
000075d5269dab89  add rsp, 0x30
000075d5269dab8d  vmovaps xmm0, [rsp]
000075d5269dab92  vmovaps xmm1, [rsp+0x10]
000075d5269dab98  vmovaps xmm2, [rsp+0x20]
000075d5269dab9e  vmovaps xmm3, [rsp+0x30]
000075d5269daba4  vmovaps xmm4, [rsp+0x40]
000075d5269dabaa  vmovaps xmm5, [rsp+0x50]
000075d5269dabb0  vmovaps xmm6, [rsp+0x60]
000075d5269dabb6  vmovaps xmm7, [rsp+0x70]
000075d5269dabbc  vmovaps xmm8, [rsp+0x80]
000075d5269dabc5  vmovaps xmm9, [rsp+0x90]
000075d5269dabce  vmovaps xmm11, [rsp+0xA0]
000075d5269dabd7  vmovaps xmm12, [rsp+0xB0]
000075d5269dabe0  vmovaps xmm13, [rsp+0xC0]
000075d5269dabe9  vmovaps xmm14, [rsp+0xD0]
000075d5269dabf2  vmovaps xmm15, [rsp+0xE0]
000075d5269dabfb  add rsp, 0xF0
000075d5269dac02  pop r11
000075d5269dac04  pop r10
000075d5269dac06  pop r9
000075d5269dac08  pop r8
000075d5269dac0a  pop rsi
000075d5269dac0b  pop rdi
000075d5269dac0c  pop rdx
000075d5269dac0d  pop rcx
000075d5269dac0e  pop rax
000075d5269dac0f  add rsp, 0x08
000075d5269dac13  jmp 0x000075D5269D651A
000075d5269dac18  sub rsp, 0x08
000075d5269dac1c  push rax
000075d5269dac1d  push rcx
000075d5269dac1e  push rdx
000075d5269dac1f  push rdi
000075d5269dac20  push rsi
000075d5269dac21  push r8
000075d5269dac23  push r9
000075d5269dac25  push r10
000075d5269dac27  push r11
000075d5269dac29  sub rsp, 0xF0
000075d5269dac30  vmovaps [rsp], xmm0
000075d5269dac35  vmovaps [rsp+0x10], xmm1
000075d5269dac3b  vmovaps [rsp+0x20], xmm2
000075d5269dac41  vmovaps [rsp+0x30], xmm3
000075d5269dac47  vmovaps [rsp+0x40], xmm4
000075d5269dac4d  vmovaps [rsp+0x50], xmm5
000075d5269dac53  vmovaps [rsp+0x60], xmm6
000075d5269dac59  vmovaps [rsp+0x70], xmm7
000075d5269dac5f  vmovaps [rsp+0x80], xmm8
000075d5269dac68  vmovaps [rsp+0x90], xmm9
000075d5269dac71  vmovaps [rsp+0xA0], xmm10
000075d5269dac7a  vmovaps [rsp+0xB0], xmm11
000075d5269dac83  vmovaps [rsp+0xC0], xmm13
000075d5269dac8c  vmovaps [rsp+0xD0], xmm14
000075d5269dac95  vmovaps [rsp+0xE0], xmm15
000075d5269dac9e  sub rsp, 0x30
000075d5269daca2  movaps [rsp], xmm12
000075d5269daca7  movaps [rsp+0x10], xmm14
000075d5269dacad  movaps [rsp+0x20], xmm1
000075d5269dacb2  lea rdi, [rsp]
000075d5269dacb6  mov esi, 0x00
000075d5269dacbb  mov rax, 0x601129E62530
000075d5269dacc5  call rax
000075d5269dacc7  movaps xmm12, [rsp]
000075d5269daccc  add rsp, 0x30
000075d5269dacd0  vmovaps xmm0, [rsp]
000075d5269dacd5  vmovaps xmm1, [rsp+0x10]
000075d5269dacdb  vmovaps xmm2, [rsp+0x20]
000075d5269dace1  vmovaps xmm3, [rsp+0x30]
000075d5269dace7  vmovaps xmm4, [rsp+0x40]
000075d5269daced  vmovaps xmm5, [rsp+0x50]
000075d5269dacf3  vmovaps xmm6, [rsp+0x60]
000075d5269dacf9  vmovaps xmm7, [rsp+0x70]
000075d5269dacff  vmovaps xmm8, [rsp+0x80]
000075d5269dad08  vmovaps xmm9, [rsp+0x90]
000075d5269dad11  vmovaps xmm10, [rsp+0xA0]
000075d5269dad1a  vmovaps xmm11, [rsp+0xB0]
000075d5269dad23  vmovaps xmm13, [rsp+0xC0]
000075d5269dad2c  vmovaps xmm14, [rsp+0xD0]
000075d5269dad35  vmovaps xmm15, [rsp+0xE0]
000075d5269dad3e  add rsp, 0xF0
000075d5269dad45  pop r11
000075d5269dad47  pop r10
000075d5269dad49  pop r9
000075d5269dad4b  pop r8
000075d5269dad4d  pop rsi
000075d5269dad4e  pop rdi
000075d5269dad4f  pop rdx
000075d5269dad50  pop rcx
000075d5269dad51  pop rax
000075d5269dad52  add rsp, 0x08
000075d5269dad56  jmp 0x000075D5269D6549
000075d5269dad5b  sub rsp, 0x08
000075d5269dad5f  push rax
000075d5269dad60  push rcx
000075d5269dad61  push rdx
000075d5269dad62  push rdi
000075d5269dad63  push rsi
000075d5269dad64  push r8
000075d5269dad66  push r9
000075d5269dad68  push r10
000075d5269dad6a  push r11
000075d5269dad6c  sub rsp, 0xF0
000075d5269dad73  vmovaps [rsp], xmm0
000075d5269dad78  vmovaps [rsp+0x10], xmm1
000075d5269dad7e  vmovaps [rsp+0x20], xmm2
000075d5269dad84  vmovaps [rsp+0x30], xmm3
000075d5269dad8a  vmovaps [rsp+0x40], xmm4
000075d5269dad90  vmovaps [rsp+0x50], xmm5
000075d5269dad96  vmovaps [rsp+0x60], xmm6
000075d5269dad9c  vmovaps [rsp+0x70], xmm7
000075d5269dada2  vmovaps [rsp+0x80], xmm8
000075d5269dadab  vmovaps [rsp+0x90], xmm9
000075d5269dadb4  vmovaps [rsp+0xA0], xmm10
000075d5269dadbd  vmovaps [rsp+0xB0], xmm11
000075d5269dadc6  vmovaps [rsp+0xC0], xmm12
000075d5269dadcf  vmovaps [rsp+0xD0], xmm13
000075d5269dadd8  vmovaps [rsp+0xE0], xmm15
000075d5269dade1  sub rsp, 0x30
000075d5269dade5  movaps [rsp], xmm14
000075d5269dadea  movaps [rsp+0x10], xmm9
000075d5269dadf0  movaps [rsp+0x20], xmm1
000075d5269dadf5  lea rdi, [rsp]
000075d5269dadf9  mov esi, 0x00
000075d5269dadfe  mov rax, 0x601129E62530
000075d5269dae08  call rax
000075d5269dae0a  movaps xmm14, [rsp]
000075d5269dae0f  add rsp, 0x30
000075d5269dae13  vmovaps xmm0, [rsp]
000075d5269dae18  vmovaps xmm1, [rsp+0x10]
000075d5269dae1e  vmovaps xmm2, [rsp+0x20]
000075d5269dae24  vmovaps xmm3, [rsp+0x30]
000075d5269dae2a  vmovaps xmm4, [rsp+0x40]
000075d5269dae30  vmovaps xmm5, [rsp+0x50]
000075d5269dae36  vmovaps xmm6, [rsp+0x60]
000075d5269dae3c  vmovaps xmm7, [rsp+0x70]
000075d5269dae42  vmovaps xmm8, [rsp+0x80]
000075d5269dae4b  vmovaps xmm9, [rsp+0x90]
000075d5269dae54  vmovaps xmm10, [rsp+0xA0]
000075d5269dae5d  vmovaps xmm11, [rsp+0xB0]
000075d5269dae66  vmovaps xmm12, [rsp+0xC0]
000075d5269dae6f  vmovaps xmm13, [rsp+0xD0]
000075d5269dae78  vmovaps xmm15, [rsp+0xE0]
000075d5269dae81  add rsp, 0xF0
000075d5269dae88  pop r11
000075d5269dae8a  pop r10
000075d5269dae8c  pop r9
000075d5269dae8e  pop r8
000075d5269dae90  pop rsi
000075d5269dae91  pop rdi
000075d5269dae92  pop rdx
000075d5269dae93  pop rcx
000075d5269dae94  pop rax
000075d5269dae95  add rsp, 0x08
000075d5269dae99  jmp 0x000075D5269D6578
000075d5269dae9e  sub rsp, 0x08
000075d5269daea2  push rax
000075d5269daea3  push rcx
000075d5269daea4  push rdx
000075d5269daea5  push rdi
000075d5269daea6  push rsi
000075d5269daea7  push r8
000075d5269daea9  push r9
000075d5269daeab  push r10
000075d5269daead  push r11
000075d5269daeaf  sub rsp, 0xF0
000075d5269daeb6  vmovaps [rsp], xmm0
000075d5269daebb  vmovaps [rsp+0x10], xmm2
000075d5269daec1  vmovaps [rsp+0x20], xmm3
000075d5269daec7  vmovaps [rsp+0x30], xmm4
000075d5269daecd  vmovaps [rsp+0x40], xmm5
000075d5269daed3  vmovaps [rsp+0x50], xmm6
000075d5269daed9  vmovaps [rsp+0x60], xmm7
000075d5269daedf  vmovaps [rsp+0x70], xmm8
000075d5269daee5  vmovaps [rsp+0x80], xmm9
000075d5269daeee  vmovaps [rsp+0x90], xmm10
000075d5269daef7  vmovaps [rsp+0xA0], xmm11
000075d5269daf00  vmovaps [rsp+0xB0], xmm12
000075d5269daf09  vmovaps [rsp+0xC0], xmm13
000075d5269daf12  vmovaps [rsp+0xD0], xmm14
000075d5269daf1b  vmovaps [rsp+0xE0], xmm15
000075d5269daf24  sub rsp, 0x30
000075d5269daf28  movaps [rsp], xmm1
000075d5269daf2c  movaps [rsp+0x10], xmm13
000075d5269daf32  movaps [rsp+0x20], xmm8
000075d5269daf38  lea rdi, [rsp]
000075d5269daf3c  mov esi, 0x00
000075d5269daf41  mov rax, 0x601129E62530
000075d5269daf4b  call rax
000075d5269daf4d  movaps xmm1, [rsp]
000075d5269daf51  add rsp, 0x30
000075d5269daf55  vmovaps xmm0, [rsp]
000075d5269daf5a  vmovaps xmm2, [rsp+0x10]
000075d5269daf60  vmovaps xmm3, [rsp+0x20]
000075d5269daf66  vmovaps xmm4, [rsp+0x30]
000075d5269daf6c  vmovaps xmm5, [rsp+0x40]
000075d5269daf72  vmovaps xmm6, [rsp+0x50]
000075d5269daf78  vmovaps xmm7, [rsp+0x60]
000075d5269daf7e  vmovaps xmm8, [rsp+0x70]
000075d5269daf84  vmovaps xmm9, [rsp+0x80]
000075d5269daf8d  vmovaps xmm10, [rsp+0x90]
000075d5269daf96  vmovaps xmm11, [rsp+0xA0]
000075d5269daf9f  vmovaps xmm12, [rsp+0xB0]
000075d5269dafa8  vmovaps xmm13, [rsp+0xC0]
000075d5269dafb1  vmovaps xmm14, [rsp+0xD0]
000075d5269dafba  vmovaps xmm15, [rsp+0xE0]
000075d5269dafc3  add rsp, 0xF0
000075d5269dafca  pop r11
000075d5269dafcc  pop r10
000075d5269dafce  pop r9
000075d5269dafd0  pop r8
000075d5269dafd2  pop rsi
000075d5269dafd3  pop rdi
000075d5269dafd4  pop rdx
000075d5269dafd5  pop rcx
000075d5269dafd6  pop rax
000075d5269dafd7  add rsp, 0x08
000075d5269dafdb  jmp 0x000075D5269D659A
000075d5269dafe0  call 0x000075D52680C260
000075d5269dafe5  jmp 0x000075D5269D65A8
000075d5269dafea  call 0x000075D5268DE950
000075d5269dafef  jmp 0x000075D5269D65B2
000075d5269daff4  sub rsp, 0x08
000075d5269daff8  push rax
000075d5269daff9  push rcx
000075d5269daffa  push rdx
000075d5269daffb  push rdi
000075d5269daffc  push rsi
000075d5269daffd  push r8
000075d5269dafff  push r9
000075d5269db001  push r10
000075d5269db003  push r11
000075d5269db005  sub rsp, 0xF0
000075d5269db00c  vmovaps [rsp], xmm0
000075d5269db011  vmovaps [rsp+0x10], xmm1
000075d5269db017  vmovaps [rsp+0x20], xmm2
000075d5269db01d  vmovaps [rsp+0x30], xmm3
000075d5269db023  vmovaps [rsp+0x40], xmm4
000075d5269db029  vmovaps [rsp+0x50], xmm5
000075d5269db02f  vmovaps [rsp+0x60], xmm6
000075d5269db035  vmovaps [rsp+0x70], xmm7
000075d5269db03b  vmovaps [rsp+0x80], xmm9
000075d5269db044  vmovaps [rsp+0x90], xmm10
000075d5269db04d  vmovaps [rsp+0xA0], xmm11
000075d5269db056  vmovaps [rsp+0xB0], xmm12
000075d5269db05f  vmovaps [rsp+0xC0], xmm13
000075d5269db068  vmovaps [rsp+0xD0], xmm14
000075d5269db071  vmovaps [rsp+0xE0], xmm15
000075d5269db07a  sub rsp, 0x30
000075d5269db07e  movaps [rsp], xmm8
000075d5269db083  movaps [rsp+0x10], xmm15
000075d5269db089  movaps [rsp+0x20], xmm7
000075d5269db08e  lea rdi, [rsp]
000075d5269db092  mov esi, 0x00
000075d5269db097  mov rax, 0x601129E62530
000075d5269db0a1  call rax
000075d5269db0a3  movaps xmm8, [rsp]
000075d5269db0a8  add rsp, 0x30
000075d5269db0ac  vmovaps xmm0, [rsp]
000075d5269db0b1  vmovaps xmm1, [rsp+0x10]
000075d5269db0b7  vmovaps xmm2, [rsp+0x20]
000075d5269db0bd  vmovaps xmm3, [rsp+0x30]
000075d5269db0c3  vmovaps xmm4, [rsp+0x40]
000075d5269db0c9  vmovaps xmm5, [rsp+0x50]
000075d5269db0cf  vmovaps xmm6, [rsp+0x60]
000075d5269db0d5  vmovaps xmm7, [rsp+0x70]
000075d5269db0db  vmovaps xmm9, [rsp+0x80]
000075d5269db0e4  vmovaps xmm10, [rsp+0x90]
000075d5269db0ed  vmovaps xmm11, [rsp+0xA0]
000075d5269db0f6  vmovaps xmm12, [rsp+0xB0]
000075d5269db0ff  vmovaps xmm13, [rsp+0xC0]
000075d5269db108  vmovaps xmm14, [rsp+0xD0]
000075d5269db111  vmovaps xmm15, [rsp+0xE0]
000075d5269db11a  add rsp, 0xF0
000075d5269db121  pop r11
000075d5269db123  pop r10
000075d5269db125  pop r9
000075d5269db127  pop r8
000075d5269db129  pop rsi
000075d5269db12a  pop rdi
000075d5269db12b  pop rdx
000075d5269db12c  pop rcx
000075d5269db12d  pop rax
000075d5269db12e  add rsp, 0x08
000075d5269db132  jmp 0x000075D5269D65D4
000075d5269db137  sub rsp, 0x08
000075d5269db13b  push rax
000075d5269db13c  push rcx
000075d5269db13d  push rdx
000075d5269db13e  push rdi
000075d5269db13f  push rsi
000075d5269db140  push r8
000075d5269db142  push r9
000075d5269db144  push r10
000075d5269db146  push r11
000075d5269db148  sub rsp, 0xF0
000075d5269db14f  vmovaps [rsp], xmm0
000075d5269db154  vmovaps [rsp+0x10], xmm1
000075d5269db15a  vmovaps [rsp+0x20], xmm2
000075d5269db160  vmovaps [rsp+0x30], xmm3
000075d5269db166  vmovaps [rsp+0x40], xmm4
000075d5269db16c  vmovaps [rsp+0x50], xmm5
000075d5269db172  vmovaps [rsp+0x60], xmm6
000075d5269db178  vmovaps [rsp+0x70], xmm8
000075d5269db17e  vmovaps [rsp+0x80], xmm9
000075d5269db187  vmovaps [rsp+0x90], xmm10
000075d5269db190  vmovaps [rsp+0xA0], xmm11
000075d5269db199  vmovaps [rsp+0xB0], xmm12
000075d5269db1a2  vmovaps [rsp+0xC0], xmm13
000075d5269db1ab  vmovaps [rsp+0xD0], xmm14
000075d5269db1b4  vmovaps [rsp+0xE0], xmm15
000075d5269db1bd  sub rsp, 0x30
000075d5269db1c1  movaps [rsp], xmm7
000075d5269db1c5  movaps [rsp+0x10], xmm9
000075d5269db1cb  movaps [rsp+0x20], xmm15
000075d5269db1d1  lea rdi, [rsp]
000075d5269db1d5  mov esi, 0x00
000075d5269db1da  mov rax, 0x601129E62530
000075d5269db1e4  call rax
000075d5269db1e6  movaps xmm7, [rsp]
000075d5269db1ea  add rsp, 0x30
000075d5269db1ee  vmovaps xmm0, [rsp]
000075d5269db1f3  vmovaps xmm1, [rsp+0x10]
000075d5269db1f9  vmovaps xmm2, [rsp+0x20]
000075d5269db1ff  vmovaps xmm3, [rsp+0x30]
000075d5269db205  vmovaps xmm4, [rsp+0x40]
000075d5269db20b  vmovaps xmm5, [rsp+0x50]
000075d5269db211  vmovaps xmm6, [rsp+0x60]
000075d5269db217  vmovaps xmm8, [rsp+0x70]
000075d5269db21d  vmovaps xmm9, [rsp+0x80]
000075d5269db226  vmovaps xmm10, [rsp+0x90]
000075d5269db22f  vmovaps xmm11, [rsp+0xA0]
000075d5269db238  vmovaps xmm12, [rsp+0xB0]
000075d5269db241  vmovaps xmm13, [rsp+0xC0]
000075d5269db24a  vmovaps xmm14, [rsp+0xD0]
000075d5269db253  vmovaps xmm15, [rsp+0xE0]
000075d5269db25c  add rsp, 0xF0
000075d5269db263  pop r11
000075d5269db265  pop r10
000075d5269db267  pop r9
000075d5269db269  pop r8
000075d5269db26b  pop rsi
000075d5269db26c  pop rdi
000075d5269db26d  pop rdx
000075d5269db26e  pop rcx
000075d5269db26f  pop rax
000075d5269db270  add rsp, 0x08
000075d5269db274  jmp 0x000075D5269D6601
000075d5269db279  sub rsp, 0x08
000075d5269db27d  push rax
000075d5269db27e  push rcx
000075d5269db27f  push rdx
000075d5269db280  push rdi
000075d5269db281  push rsi
000075d5269db282  push r8
000075d5269db284  push r9
000075d5269db286  push r10
000075d5269db288  push r11
000075d5269db28a  sub rsp, 0xF0
000075d5269db291  vmovaps [rsp], xmm0
000075d5269db296  vmovaps [rsp+0x10], xmm1
000075d5269db29c  vmovaps [rsp+0x20], xmm2
000075d5269db2a2  vmovaps [rsp+0x30], xmm3
000075d5269db2a8  vmovaps [rsp+0x40], xmm4
000075d5269db2ae  vmovaps [rsp+0x50], xmm5
000075d5269db2b4  vmovaps [rsp+0x60], xmm6
000075d5269db2ba  vmovaps [rsp+0x70], xmm7
000075d5269db2c0  vmovaps [rsp+0x80], xmm8
000075d5269db2c9  vmovaps [rsp+0x90], xmm10
000075d5269db2d2  vmovaps [rsp+0xA0], xmm11
000075d5269db2db  vmovaps [rsp+0xB0], xmm12
000075d5269db2e4  vmovaps [rsp+0xC0], xmm13
000075d5269db2ed  vmovaps [rsp+0xD0], xmm14
000075d5269db2f6  vmovaps [rsp+0xE0], xmm15
000075d5269db2ff  sub rsp, 0x30
000075d5269db303  movaps [rsp], xmm9
000075d5269db308  movaps [rsp+0x10], xmm13
000075d5269db30e  movaps [rsp+0x20], xmm15
000075d5269db314  lea rdi, [rsp]
000075d5269db318  mov esi, 0x00
000075d5269db31d  mov rax, 0x601129E62530
000075d5269db327  call rax
000075d5269db329  movaps xmm9, [rsp]
000075d5269db32e  add rsp, 0x30
000075d5269db332  vmovaps xmm0, [rsp]
000075d5269db337  vmovaps xmm1, [rsp+0x10]
000075d5269db33d  vmovaps xmm2, [rsp+0x20]
000075d5269db343  vmovaps xmm3, [rsp+0x30]
000075d5269db349  vmovaps xmm4, [rsp+0x40]
000075d5269db34f  vmovaps xmm5, [rsp+0x50]
000075d5269db355  vmovaps xmm6, [rsp+0x60]
000075d5269db35b  vmovaps xmm7, [rsp+0x70]
000075d5269db361  vmovaps xmm8, [rsp+0x80]
000075d5269db36a  vmovaps xmm10, [rsp+0x90]
000075d5269db373  vmovaps xmm11, [rsp+0xA0]
000075d5269db37c  vmovaps xmm12, [rsp+0xB0]
000075d5269db385  vmovaps xmm13, [rsp+0xC0]
000075d5269db38e  vmovaps xmm14, [rsp+0xD0]
000075d5269db397  vmovaps xmm15, [rsp+0xE0]
000075d5269db3a0  add rsp, 0xF0
000075d5269db3a7  pop r11
000075d5269db3a9  pop r10
000075d5269db3ab  pop r9
000075d5269db3ad  pop r8
000075d5269db3af  pop rsi
000075d5269db3b0  pop rdi
000075d5269db3b1  pop rdx
000075d5269db3b2  pop rcx
000075d5269db3b3  pop rax
000075d5269db3b4  add rsp, 0x08
000075d5269db3b8  jmp 0x000075D5269D662F
000075d5269db3bd  sub rsp, 0x08
000075d5269db3c1  push rax
000075d5269db3c2  push rcx
000075d5269db3c3  push rdx
000075d5269db3c4  push rdi
000075d5269db3c5  push rsi
000075d5269db3c6  push r8
000075d5269db3c8  push r9
000075d5269db3ca  push r10
000075d5269db3cc  push r11
000075d5269db3ce  sub rsp, 0xF0
000075d5269db3d5  vmovaps [rsp], xmm0
000075d5269db3da  vmovaps [rsp+0x10], xmm1
000075d5269db3e0  vmovaps [rsp+0x20], xmm2
000075d5269db3e6  vmovaps [rsp+0x30], xmm3
000075d5269db3ec  vmovaps [rsp+0x40], xmm4
000075d5269db3f2  vmovaps [rsp+0x50], xmm5
000075d5269db3f8  vmovaps [rsp+0x60], xmm6
000075d5269db3fe  vmovaps [rsp+0x70], xmm7
000075d5269db404  vmovaps [rsp+0x80], xmm8
000075d5269db40d  vmovaps [rsp+0x90], xmm9
000075d5269db416  vmovaps [rsp+0xA0], xmm10
000075d5269db41f  vmovaps [rsp+0xB0], xmm11
000075d5269db428  vmovaps [rsp+0xC0], xmm12
000075d5269db431  vmovaps [rsp+0xD0], xmm13
000075d5269db43a  vmovaps [rsp+0xE0], xmm14
000075d5269db443  sub rsp, 0x30
000075d5269db447  movaps [rsp], xmm15
000075d5269db44c  movaps [rsp+0x10], xmm11
000075d5269db452  movaps [rsp+0x20], xmm12
000075d5269db458  lea rdi, [rsp]
000075d5269db45c  mov esi, 0x00
000075d5269db461  mov rax, 0x601129E62530
000075d5269db46b  call rax
000075d5269db46d  movaps xmm15, [rsp]
000075d5269db472  add rsp, 0x30
000075d5269db476  vmovaps xmm0, [rsp]
000075d5269db47b  vmovaps xmm1, [rsp+0x10]
000075d5269db481  vmovaps xmm2, [rsp+0x20]
000075d5269db487  vmovaps xmm3, [rsp+0x30]
000075d5269db48d  vmovaps xmm4, [rsp+0x40]
000075d5269db493  vmovaps xmm5, [rsp+0x50]
000075d5269db499  vmovaps xmm6, [rsp+0x60]
000075d5269db49f  vmovaps xmm7, [rsp+0x70]
000075d5269db4a5  vmovaps xmm8, [rsp+0x80]
000075d5269db4ae  vmovaps xmm9, [rsp+0x90]
000075d5269db4b7  vmovaps xmm10, [rsp+0xA0]
000075d5269db4c0  vmovaps xmm11, [rsp+0xB0]
000075d5269db4c9  vmovaps xmm12, [rsp+0xC0]
000075d5269db4d2  vmovaps xmm13, [rsp+0xD0]
000075d5269db4db  vmovaps xmm14, [rsp+0xE0]
000075d5269db4e4  add rsp, 0xF0
000075d5269db4eb  pop r11
000075d5269db4ed  pop r10
000075d5269db4ef  pop r9
000075d5269db4f1  pop r8
000075d5269db4f3  pop rsi
000075d5269db4f4  pop rdi
000075d5269db4f5  pop rdx
000075d5269db4f6  pop rcx
000075d5269db4f7  pop rax
000075d5269db4f8  add rsp, 0x08
000075d5269db4fc  jmp 0x000075D5269D664A
000075d5269db501  sub rsp, 0x08
000075d5269db505  push rax
000075d5269db506  push rcx
000075d5269db507  push rdx
000075d5269db508  push rdi
000075d5269db509  push rsi
000075d5269db50a  push r8
000075d5269db50c  push r9
000075d5269db50e  push r10
000075d5269db510  push r11
000075d5269db512  sub rsp, 0xF0
000075d5269db519  vmovaps [rsp], xmm0
000075d5269db51e  vmovaps [rsp+0x10], xmm1
000075d5269db524  vmovaps [rsp+0x20], xmm2
000075d5269db52a  vmovaps [rsp+0x30], xmm3
000075d5269db530  vmovaps [rsp+0x40], xmm4
000075d5269db536  vmovaps [rsp+0x50], xmm5
000075d5269db53c  vmovaps [rsp+0x60], xmm6
000075d5269db542  vmovaps [rsp+0x70], xmm7
000075d5269db548  vmovaps [rsp+0x80], xmm8
000075d5269db551  vmovaps [rsp+0x90], xmm9
000075d5269db55a  vmovaps [rsp+0xA0], xmm10
000075d5269db563  vmovaps [rsp+0xB0], xmm11
000075d5269db56c  vmovaps [rsp+0xC0], xmm12
000075d5269db575  vmovaps [rsp+0xD0], xmm14
000075d5269db57e  vmovaps [rsp+0xE0], xmm15
000075d5269db587  sub rsp, 0x30
000075d5269db58b  movaps [rsp], xmm13
000075d5269db590  movaps [rsp+0x10], xmm10
000075d5269db596  movaps [rsp+0x20], xmm14
000075d5269db59c  lea rdi, [rsp]
000075d5269db5a0  mov esi, 0x00
000075d5269db5a5  mov rax, 0x601129E62530
000075d5269db5af  call rax
000075d5269db5b1  movaps xmm13, [rsp]
000075d5269db5b6  add rsp, 0x30
000075d5269db5ba  vmovaps xmm0, [rsp]
000075d5269db5bf  vmovaps xmm1, [rsp+0x10]
000075d5269db5c5  vmovaps xmm2, [rsp+0x20]
000075d5269db5cb  vmovaps xmm3, [rsp+0x30]
000075d5269db5d1  vmovaps xmm4, [rsp+0x40]
000075d5269db5d7  vmovaps xmm5, [rsp+0x50]
000075d5269db5dd  vmovaps xmm6, [rsp+0x60]
000075d5269db5e3  vmovaps xmm7, [rsp+0x70]
000075d5269db5e9  vmovaps xmm8, [rsp+0x80]
000075d5269db5f2  vmovaps xmm9, [rsp+0x90]
000075d5269db5fb  vmovaps xmm10, [rsp+0xA0]
000075d5269db604  vmovaps xmm11, [rsp+0xB0]
000075d5269db60d  vmovaps xmm12, [rsp+0xC0]
000075d5269db616  vmovaps xmm14, [rsp+0xD0]
000075d5269db61f  vmovaps xmm15, [rsp+0xE0]
000075d5269db628  add rsp, 0xF0
000075d5269db62f  pop r11
000075d5269db631  pop r10
000075d5269db633  pop r9
000075d5269db635  pop r8
000075d5269db637  pop rsi
000075d5269db638  pop rdi
000075d5269db639  pop rdx
000075d5269db63a  pop rcx
000075d5269db63b  pop rax
000075d5269db63c  add rsp, 0x08
000075d5269db640  jmp 0x000075D5269D666D
000075d5269db645  sub rsp, 0x08
000075d5269db649  push rax
000075d5269db64a  push rcx
000075d5269db64b  push rdx
000075d5269db64c  push rdi
000075d5269db64d  push rsi
000075d5269db64e  push r8
000075d5269db650  push r9
000075d5269db652  push r10
000075d5269db654  push r11
000075d5269db656  sub rsp, 0xF0
000075d5269db65d  vmovaps [rsp], xmm0
000075d5269db662  vmovaps [rsp+0x10], xmm1
000075d5269db668  vmovaps [rsp+0x20], xmm2
000075d5269db66e  vmovaps [rsp+0x30], xmm3
000075d5269db674  vmovaps [rsp+0x40], xmm4
000075d5269db67a  vmovaps [rsp+0x50], xmm5
000075d5269db680  vmovaps [rsp+0x60], xmm6
000075d5269db686  vmovaps [rsp+0x70], xmm7
000075d5269db68c  vmovaps [rsp+0x80], xmm8
000075d5269db695  vmovaps [rsp+0x90], xmm9
000075d5269db69e  vmovaps [rsp+0xA0], xmm10
000075d5269db6a7  vmovaps [rsp+0xB0], xmm11
000075d5269db6b0  vmovaps [rsp+0xC0], xmm12
000075d5269db6b9  vmovaps [rsp+0xD0], xmm13
000075d5269db6c2  vmovaps [rsp+0xE0], xmm15
000075d5269db6cb  sub rsp, 0x30
000075d5269db6cf  movaps [rsp], xmm14
000075d5269db6d4  movaps [rsp+0x10], xmm1
000075d5269db6d9  movaps [rsp+0x20], xmm7
000075d5269db6de  lea rdi, [rsp]
000075d5269db6e2  mov esi, 0x00
000075d5269db6e7  mov rax, 0x601129E62530
000075d5269db6f1  call rax
000075d5269db6f3  movaps xmm14, [rsp]
000075d5269db6f8  add rsp, 0x30
000075d5269db6fc  vmovaps xmm0, [rsp]
000075d5269db701  vmovaps xmm1, [rsp+0x10]
000075d5269db707  vmovaps xmm2, [rsp+0x20]
000075d5269db70d  vmovaps xmm3, [rsp+0x30]
000075d5269db713  vmovaps xmm4, [rsp+0x40]
000075d5269db719  vmovaps xmm5, [rsp+0x50]
000075d5269db71f  vmovaps xmm6, [rsp+0x60]
000075d5269db725  vmovaps xmm7, [rsp+0x70]
000075d5269db72b  vmovaps xmm8, [rsp+0x80]
000075d5269db734  vmovaps xmm9, [rsp+0x90]
000075d5269db73d  vmovaps xmm10, [rsp+0xA0]
000075d5269db746  vmovaps xmm11, [rsp+0xB0]
000075d5269db74f  vmovaps xmm12, [rsp+0xC0]
000075d5269db758  vmovaps xmm13, [rsp+0xD0]
000075d5269db761  vmovaps xmm15, [rsp+0xE0]
000075d5269db76a  add rsp, 0xF0
000075d5269db771  pop r11
000075d5269db773  pop r10
000075d5269db775  pop r9
000075d5269db777  pop r8
000075d5269db779  pop rsi
000075d5269db77a  pop rdi
000075d5269db77b  pop rdx
000075d5269db77c  pop rcx
000075d5269db77d  pop rax
000075d5269db77e  add rsp, 0x08
000075d5269db782  jmp 0x000075D5269D6690
000075d5269db787  sub rsp, 0x08
000075d5269db78b  push rax
000075d5269db78c  push rcx
000075d5269db78d  push rdx
000075d5269db78e  push rdi
000075d5269db78f  push rsi
000075d5269db790  push r8
000075d5269db792  push r9
000075d5269db794  push r10
000075d5269db796  push r11
000075d5269db798  sub rsp, 0xF0
000075d5269db79f  vmovaps [rsp], xmm0
000075d5269db7a4  vmovaps [rsp+0x10], xmm2
000075d5269db7aa  vmovaps [rsp+0x20], xmm3
000075d5269db7b0  vmovaps [rsp+0x30], xmm4
000075d5269db7b6  vmovaps [rsp+0x40], xmm5
000075d5269db7bc  vmovaps [rsp+0x50], xmm6
000075d5269db7c2  vmovaps [rsp+0x60], xmm7
000075d5269db7c8  vmovaps [rsp+0x70], xmm8
000075d5269db7ce  vmovaps [rsp+0x80], xmm9
000075d5269db7d7  vmovaps [rsp+0x90], xmm10
000075d5269db7e0  vmovaps [rsp+0xA0], xmm11
000075d5269db7e9  vmovaps [rsp+0xB0], xmm12
000075d5269db7f2  vmovaps [rsp+0xC0], xmm13
000075d5269db7fb  vmovaps [rsp+0xD0], xmm14
000075d5269db804  vmovaps [rsp+0xE0], xmm15
000075d5269db80d  sub rsp, 0x30
000075d5269db811  movaps [rsp], xmm1
000075d5269db815  movaps [rsp+0x10], xmm8
000075d5269db81b  movaps [rsp+0x20], xmm9
000075d5269db821  lea rdi, [rsp]
000075d5269db825  mov esi, 0x00
000075d5269db82a  mov rax, 0x601129E62530
000075d5269db834  call rax
000075d5269db836  movaps xmm1, [rsp]
000075d5269db83a  add rsp, 0x30
000075d5269db83e  vmovaps xmm0, [rsp]
000075d5269db843  vmovaps xmm2, [rsp+0x10]
000075d5269db849  vmovaps xmm3, [rsp+0x20]
000075d5269db84f  vmovaps xmm4, [rsp+0x30]
000075d5269db855  vmovaps xmm5, [rsp+0x40]
000075d5269db85b  vmovaps xmm6, [rsp+0x50]
000075d5269db861  vmovaps xmm7, [rsp+0x60]
000075d5269db867  vmovaps xmm8, [rsp+0x70]
000075d5269db86d  vmovaps xmm9, [rsp+0x80]
000075d5269db876  vmovaps xmm10, [rsp+0x90]
000075d5269db87f  vmovaps xmm11, [rsp+0xA0]
000075d5269db888  vmovaps xmm12, [rsp+0xB0]
000075d5269db891  vmovaps xmm13, [rsp+0xC0]
000075d5269db89a  vmovaps xmm14, [rsp+0xD0]
000075d5269db8a3  vmovaps xmm15, [rsp+0xE0]
000075d5269db8ac  add rsp, 0xF0
000075d5269db8b3  pop r11
000075d5269db8b5  pop r10
000075d5269db8b7  pop r9
000075d5269db8b9  pop r8
000075d5269db8bb  pop rsi
000075d5269db8bc  pop rdi
000075d5269db8bd  pop rdx
000075d5269db8be  pop rcx
000075d5269db8bf  pop rax
000075d5269db8c0  add rsp, 0x08
000075d5269db8c4  jmp 0x000075D5269D66B2
000075d5269db8c9  call 0x000075D5268B3E40
000075d5269db8ce  jmp 0x000075D5269D66C0
000075d5269db8d3  call 0x000075D52680C380
000075d5269db8d8  jmp 0x000075D5269D66CA
000075d5269db8dd  call 0x000075D52680D600
000075d5269db8e2  jmp 0x000075D5269D66D4
000075d5269db8e7  call 0x000075D5267FF540
000075d5269db8ec  jmp 0x000075D5269D66DE
000075d5269db8f1  int3
000075d5269db8f2  nop [rax+rax*1], ax
000075d5269db8fb  nop [rax+rax*1], eax
000075d5269db900  mov eax, [r15+0x48]
000075d5269db904  lea r14d, [eax+0x01]
000075d5269db909  mov [rsp+0x10], r14d
000075d5269db90e  mov r14d, r14d
000075d5269db911  mov [r15+0x48], r14
000075d5269db915  xor eax, eax
000075d5269db917  mov r14d, [rsp+0x10]
000075d5269db91c  cmp r14d, 0x1F4
000075d5269db923  cmc
000075d5269db924  lahf
000075d5269db925  seto al
000075d5269db928  mov [r15+0x108], eax
000075d5269db92f  mov eax, [r15+0x108]
000075d5269db936  sahf
000075d5269db937  jnz 0x000075D5269DB969
000075d5269db939  cmp dword ptr [r15+0x318], 0x00
000075d5269db941  jz 0x000075D5269E1AB0
000075d5269db947  nop [rax+rax*1], ax
000075d5269db950  nop [rax+rax*1], eax
000075d5269db958  mov eax, 0x410450
000075d5269db95d  mov [r15+0x100], rax
000075d5269db964  jmp 0x000075D5267FE110
000075d5269db969  cmp dword ptr [r15+0x318], 0x00
000075d5269db971  jz 0x000075D5269DB9A0
000075d5269db977  nop [rax+rax*1], ax
000075d5269db980  nop [rax+rax*1], eax
000075d5269db988  mov eax, 0x410274
000075d5269db98d  mov [r15+0x100], rax
000075d5269db994  jmp 0x000075D5267FE110
000075d5269db999  int3
000075d5269db99a  int3
000075d5269db99b  nop [rax+rax*1], eax
000075d5269db9a0  mov rax, [r15+0x40]
000075d5269db9a4  movaps xmm1, [r15+0x1D0]
000075d5269db9ac  vmovaps [rsp+0x10], xmm1
000075d5269db9b2  vmovaps xmm15, [rsp+0x10]
000075d5269db9b8  por xmm1, xmm15
000075d5269db9bd  movaps xmm14, [r15+0x1A0]
000075d5269db9c5  vmovaps [rsp+0x10], xmm14
000075d5269db9cb  vmovaps xmm13, [rsp+0x10]
000075d5269db9d1  por xmm14, xmm13
000075d5269db9d6  lea r14, [rax+0x30]
000075d5269db9da  mov r12, [r13+r14*1]
000075d5269db9df  lea r14, [rax+0x38]
000075d5269db9e3  mov r11, [r13+r14*1]
000075d5269db9e8  movq xmm13, r12
000075d5269db9ed  movq xmm12, r11
000075d5269db9f2  movq xmm13, xmm13
000075d5269db9f7  vmovaps [rsp+0x10], xmm13
000075d5269db9fd  movq xmm13, xmm13
000075d5269dba02  movaps [r15+0x130], xmm13
000075d5269dba0a  movq xmm12, xmm12
000075d5269dba0f  vmovaps [rsp+0x20], xmm12
000075d5269dba15  movq xmm12, xmm12
000075d5269dba1a  movaps [r15+0x280], xmm12
000075d5269dba22  movaps xmm13, [r15+0x270]
000075d5269dba2a  vmovaps [rsp+0x30], xmm13
000075d5269dba30  vmovaps xmm12, [rsp+0x30]
000075d5269dba36  por xmm13, xmm12
000075d5269dba3b  lea r14, [rax+0x20]
000075d5269dba3f  mov r12, [r13+r14*1]
000075d5269dba44  lea r14, [rax+0x28]
000075d5269dba48  mov r11, [r13+r14*1]
000075d5269dba4d  movq xmm12, r12
000075d5269dba52  movq xmm11, r11
000075d5269dba57  movq xmm12, xmm12
000075d5269dba5c  vmovaps [rsp+0x30], xmm12
000075d5269dba62  movq xmm12, xmm12
000075d5269dba67  movaps [r15+0x150], xmm12
000075d5269dba6f  movq xmm11, xmm11
000075d5269dba74  vmovaps [rsp+0x40], xmm11
000075d5269dba7a  movq xmm11, xmm11
000075d5269dba7f  movaps [r15+0x140], xmm11
000075d5269dba87  lea r14, [rax+0x10]
000075d5269dba8b  mov r12, [r13+r14*1]
000075d5269dba90  lea r14, [rax+0x18]
000075d5269dba94  mov r11, [r13+r14*1]
000075d5269dba99  movq xmm12, r12
000075d5269dba9e  movq xmm11, r11
000075d5269dbaa3  movq xmm12, xmm12
000075d5269dbaa8  vmovaps [rsp+0x50], xmm12
000075d5269dbaae  movq xmm12, xmm12
000075d5269dbab3  movaps [r15+0x170], xmm12
000075d5269dbabb  movq xmm11, xmm11
000075d5269dbac0  vmovaps [rsp+0x60], xmm11
000075d5269dbac6  movq xmm11, xmm11
000075d5269dbacb  movaps [r15+0x160], xmm11
000075d5269dbad3  mov r14, [r13+rax*1]
000075d5269dbad8  vmovq xmm12, r14
000075d5269dbadd  vpbroadcastq xmm12, xmm12
000075d5269dbae2  lea r14, [rax+0x08]
000075d5269dbae6  mov rax, [r13+r14*1]
000075d5269dbaeb  movq xmm11, rax
000075d5269dbaf0  movaps [r15+0x230], xmm11
000075d5269dbaf8  mov rax, [r15+0xF8]
000075d5269dbaff  lea r14, [rax+0x50]
000075d5269dbb03  movups xmm11, [r13+r14*1]
000075d5269dbb09  lea r14, [rax+0x60]
000075d5269dbb0d  movups xmm10, [r13+r14*1]
000075d5269dbb13  lea r14, [rax+0x30]
000075d5269dbb17  movups xmm9, [r13+r14*1]
000075d5269dbb1d  mov r14, [r15+0x50]
000075d5269dbb21  mov [r15+0x60], r14
000075d5269dbb25  mov qword ptr [r15+0x58], 0x40
000075d5269dbb2d  movaps xmm8, xmm12
000075d5269dbb31  mulpd xmm8, xmm15
000075d5269dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000075d5269dbb3c  ptest xmm7, xmm7
000075d5269dbb41  jnz 0x000075D5269DC96A
000075d5269dbb47  movq xmm15, qword ptr [r15+0x230]
000075d5269dbb50  vmovaps [rsp+0x70], xmm15
000075d5269dbb56  vpermilpd xmm15, xmm15, 0x00
000075d5269dbb5c  movaps xmm7, xmm9
000075d5269dbb60  mulpd xmm7, xmm15
000075d5269dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000075d5269dbb6a  ptest xmm6, xmm6
000075d5269dbb6f  jnz 0x000075D5269DCAAE
000075d5269dbb75  vxorps xmm15, xmm15, xmm15
000075d5269dbb7a  vpbroadcastq xmm15, xmm15
000075d5269dbb7f  movaps xmm9, xmm12
000075d5269dbb83  mulpd xmm9, xmm10
000075d5269dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000075d5269dbb8e  ptest xmm6, xmm6
000075d5269dbb93  jnz 0x000075D5269DCBF0
000075d5269dbb99  movaps xmm10, xmm12
000075d5269dbb9d  mulpd xmm10, xmm11
000075d5269dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000075d5269dbba8  ptest xmm6, xmm6
000075d5269dbbad  jnz 0x000075D5269DCD34
000075d5269dbbb3  movaps xmm11, [r15+0x1F0]
000075d5269dbbbb  movaps xmm6, xmm12
000075d5269dbbbf  mulpd xmm6, xmm11
000075d5269dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000075d5269dbbc9  ptest xmm5, xmm5
000075d5269dbbce  jnz 0x000075D5269DCE78
000075d5269dbbd4  movaps xmm12, [r15+0x2A0]
000075d5269dbbdc  vmovaps [rsp+0x80], xmm12
000075d5269dbbe5  vmovaps xmm11, [rsp+0x80]
000075d5269dbbee  por xmm12, xmm11
000075d5269dbbf3  movaps xmm11, [r15+0x250]
000075d5269dbbfb  vmovaps [rsp+0x80], xmm11
000075d5269dbc04  vmovaps xmm5, [rsp+0x80]
000075d5269dbc0d  por xmm11, xmm5
000075d5269dbc12  vmovaps xmm4, [rsp+0x70]
000075d5269dbc18  vpermilpd xmm4, xmm4, 0x00
000075d5269dbc1e  movaps xmm3, xmm5
000075d5269dbc21  mulpd xmm3, xmm4
000075d5269dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000075d5269dbc2a  ptest xmm2, xmm2
000075d5269dbc2f  jnz 0x000075D5269DCFBA
000075d5269dbc35  mov [rsp+0x80], rax
000075d5269dbc3d  xor eax, eax
000075d5269dbc3f  mov r12d, 0x40
000075d5269dbc45  mov r11d, 0x200
000075d5269dbc4b  cmp r12, r11
000075d5269dbc4e  cmc
000075d5269dbc4f  lahf
000075d5269dbc50  seto al
000075d5269dbc53  mov [r15+0x108], eax
000075d5269dbc5a  movaps xmm5, xmm8
000075d5269dbc5e  addpd xmm5, xmm15
000075d5269dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000075d5269dbc68  ptest xmm4, xmm4
000075d5269dbc6d  jnz 0x000075D5269DD0FA
000075d5269dbc73  movaps xmm8, [r15+0x1B0]
000075d5269dbc7b  movaps xmm4, xmm9
000075d5269dbc7f  addpd xmm4, xmm8
000075d5269dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000075d5269dbc89  ptest xmm2, xmm2
000075d5269dbc8e  jnz 0x000075D5269DD23C
000075d5269dbc94  movaps xmm9, xmm10
000075d5269dbc98  addpd xmm9, xmm8
000075d5269dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000075d5269dbca3  ptest xmm2, xmm2
000075d5269dbca8  jnz 0x000075D5269DD37E
000075d5269dbcae  movaps xmm10, [r15+0x2F0]
000075d5269dbcb6  vmovaps [rsp+0x90], xmm10
000075d5269dbcbf  vmovaps xmm8, [rsp+0x90]
000075d5269dbcc8  por xmm10, xmm8
000075d5269dbccd  movaps xmm8, [r15+0x2E0]
000075d5269dbcd5  vmovaps [rsp+0x90], xmm8
000075d5269dbcde  vmovaps xmm2, [rsp+0x90]
000075d5269dbce7  por xmm8, xmm2
000075d5269dbcec  movaps xmm2, [r15+0x2D0]
000075d5269dbcf4  vmovaps [rsp+0x90], xmm2
000075d5269dbcfd  vmovaps [rsp+0xA0], xmm1
000075d5269dbd06  vmovaps xmm1, [rsp+0x90]
000075d5269dbd0f  por xmm2, xmm1
000075d5269dbd13  movaps xmm1, [r15+0x200]
000075d5269dbd1b  vmovaps [rsp+0x90], xmm1
000075d5269dbd24  vmovaps [rsp+0xB0], xmm15
000075d5269dbd2d  vmovaps xmm15, [rsp+0x90]
000075d5269dbd36  por xmm1, xmm15
000075d5269dbd3b  movaps xmm15, [r15+0x1C0]
000075d5269dbd43  vmovaps [rsp+0x90], xmm15
000075d5269dbd4c  vmovaps [rsp+0xC0], xmm1
000075d5269dbd55  vmovaps xmm1, [rsp+0x90]
000075d5269dbd5e  por xmm15, xmm1
000075d5269dbd63  movaps xmm1, [r15+0x190]
000075d5269dbd6b  vmovaps [rsp+0x90], xmm1
000075d5269dbd74  vmovaps [rsp+0xD0], xmm15
000075d5269dbd7d  vmovaps xmm15, [rsp+0x90]
000075d5269dbd86  por xmm1, xmm15
000075d5269dbd8b  movaps xmm15, [r15+0x300]
000075d5269dbd93  vmovaps [rsp+0x90], xmm15
000075d5269dbd9c  vmovaps [rsp+0xE0], xmm1
000075d5269dbda5  vmovaps xmm1, [rsp+0x90]
000075d5269dbdae  por xmm15, xmm1
000075d5269dbdb3  mov rax, [rsp+0x80]
000075d5269dbdbb  lea r12, [rax+0xA0]
000075d5269dbdc2  movups xmm1, [r13+r12*1]
000075d5269dbdc8  lea r12, [rax+0xB0]
000075d5269dbdcf  vmovaps [rsp+0x80], xmm1
000075d5269dbdd8  movups xmm1, [r13+r12*1]
000075d5269dbdde  vmovaps [rsp+0x90], xmm1
000075d5269dbde7  vmovaps [rsp+0xF0], xmm15
000075d5269dbdf0  vmovaps xmm15, [rsp+0xB0]
000075d5269dbdf9  vmovaps [rsp+0xB0], xmm14
000075d5269dbe02  movaps xmm1, xmm6
000075d5269dbe05  addpd xmm1, xmm15
000075d5269dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000075d5269dbe0f  ptest xmm14, xmm14
000075d5269dbe15  jnz 0x000075D5269DD4D6
000075d5269dbe1b  lea r12, [rax+0xF0]
000075d5269dbe22  movups xmm15, [r13+r12*1]
000075d5269dbe28  movaps xmm14, xmm4
000075d5269dbe2c  addpd xmm14, xmm3
000075d5269dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000075d5269dbe37  ptest xmm6, xmm6
000075d5269dbe3c  jnz 0x000075D5269DD621
000075d5269dbe42  movaps xmm6, xmm9
000075d5269dbe46  addpd xmm6, xmm7
000075d5269dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000075d5269dbe4f  ptest xmm4, xmm4
000075d5269dbe54  jnz 0x000075D5269DD763
000075d5269dbe5a  vmovaps xmm9, [rsp+0x70]
000075d5269dbe60  vpermilpd xmm9, xmm9, 0x00
000075d5269dbe66  vmovaps xmm4, [rsp+0x90]
000075d5269dbe6f  movaps xmm7, xmm4
000075d5269dbe72  mulpd xmm7, xmm9
000075d5269dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000075d5269dbe7c  ptest xmm3, xmm3
000075d5269dbe81  jnz 0x000075D5269DD8A4
000075d5269dbe87  vmovaps xmm9, [rsp+0x50]
000075d5269dbe8d  vpermilpd xmm9, xmm9, 0x00
000075d5269dbe93  movaps xmm4, xmm15
000075d5269dbe97  mulpd xmm4, xmm9
000075d5269dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000075d5269dbea1  ptest xmm3, xmm3
000075d5269dbea6  jnz 0x000075D5269DD9E5
000075d5269dbeac  lea r12, [rax+0xE0]
000075d5269dbeb3  movups xmm15, [r13+r12*1]
000075d5269dbeb9  vmovaps xmm9, [rsp+0x70]
000075d5269dbebf  vpermilpd xmm9, xmm9, 0x00
000075d5269dbec5  vmovaps [rsp+0x70], xmm1
000075d5269dbecb  vmovaps xmm1, [rsp+0x80]
000075d5269dbed4  vmovaps [rsp+0x80], xmm15
000075d5269dbedd  movaps xmm3, xmm1
000075d5269dbee0  mulpd xmm3, xmm9
000075d5269dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000075d5269dbeea  ptest xmm15, xmm15
000075d5269dbef0  jnz 0x000075D5269DDB31
000075d5269dbef6  vmovaps xmm1, [rsp+0xF0]
000075d5269dbeff  vmovaps xmm15, [rsp+0xF0]
000075d5269dbf08  por xmm1, xmm15
000075d5269dbf0d  movaps [r15+0x300], xmm1
000075d5269dbf15  vmovaps xmm15, [rsp+0xE0]
000075d5269dbf1e  vmovaps xmm9, [rsp+0xE0]
000075d5269dbf27  por xmm15, xmm9
000075d5269dbf2c  movaps [r15+0x190], xmm15
000075d5269dbf34  vmovaps xmm9, [rsp+0x50]
000075d5269dbf3a  vpermilpd xmm9, xmm9, 0x00
000075d5269dbf40  vmovaps [rsp+0x90], xmm1
000075d5269dbf49  vmovaps [rsp+0xE0], xmm15
000075d5269dbf52  vmovaps xmm15, [rsp+0x80]
000075d5269dbf5b  vmovaps [rsp+0x80], xmm14
000075d5269dbf64  movaps xmm1, xmm15
000075d5269dbf68  mulpd xmm1, xmm9
000075d5269dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000075d5269dbf72  ptest xmm14, xmm14
000075d5269dbf78  jnz 0x000075D5269DDC72
000075d5269dbf7e  lea r12, [rax+0x90]
000075d5269dbf85  movups xmm15, [r13+r12*1]
000075d5269dbf8b  vmovaps xmm14, [rsp+0xD0]
000075d5269dbf94  vmovaps xmm9, [rsp+0xD0]
000075d5269dbf9d  por xmm14, xmm9
000075d5269dbfa2  movaps [r15+0x1C0], xmm14
000075d5269dbfaa  vmovaps xmm9, [rsp+0xC0]
000075d5269dbfb3  vmovaps [rsp+0xD0], xmm1
000075d5269dbfbc  vmovaps xmm1, [rsp+0xC0]
000075d5269dbfc5  por xmm9, xmm1
000075d5269dbfca  movaps [r15+0x200], xmm9
000075d5269dbfd2  vmovaps [rsp+0xC0], xmm2
000075d5269dbfdb  vmovaps xmm1, [rsp+0xC0]
000075d5269dbfe4  por xmm2, xmm1
000075d5269dbfe8  movaps [r15+0x2D0], xmm2
000075d5269dbff0  vmovaps [rsp+0xC0], xmm8
000075d5269dbff9  vmovaps xmm1, [rsp+0xC0]
000075d5269dc002  por xmm8, xmm1
000075d5269dc007  movaps [r15+0x2E0], xmm8
000075d5269dc00f  vmovaps [rsp+0xC0], xmm15
000075d5269dc018  movaps xmm1, xmm5
000075d5269dc01b  addpd xmm1, xmm7
000075d5269dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000075d5269dc024  ptest xmm15, xmm15
000075d5269dc02a  jnz 0x000075D5269DDDBE
000075d5269dc030  vmovaps xmm15, [rsp+0x50]
000075d5269dc036  vpermilpd xmm15, xmm15, 0x00
000075d5269dc03c  vmovaps xmm5, [rsp+0xC0]
000075d5269dc045  vmovaps [rsp+0xC0], xmm1
000075d5269dc04e  movaps xmm7, xmm5
000075d5269dc051  mulpd xmm7, xmm15
000075d5269dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000075d5269dc05b  ptest xmm1, xmm1
000075d5269dc060  jnz 0x000075D5269DDEFE
000075d5269dc066  lea r12, [rax+0x80]
000075d5269dc06d  movups xmm1, [r13+r12*1]
000075d5269dc073  vmovaps xmm5, [rsp+0x70]
000075d5269dc079  vmovaps [rsp+0x70], xmm1
000075d5269dc07f  movaps xmm15, xmm5
000075d5269dc083  addpd xmm15, xmm3
000075d5269dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269dc08e  ptest xmm1, xmm1
000075d5269dc093  jnz 0x000075D5269DE049
000075d5269dc099  vmovaps xmm5, [rsp+0x80]
000075d5269dc0a2  movaps xmm1, xmm5
000075d5269dc0a5  addpd xmm1, xmm4
000075d5269dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000075d5269dc0ae  ptest xmm3, xmm3
000075d5269dc0b3  jnz 0x000075D5269DE18B
000075d5269dc0b9  vmovaps [rsp+0x80], xmm10
000075d5269dc0c2  vmovaps xmm5, [rsp+0x80]
000075d5269dc0cb  por xmm10, xmm5
000075d5269dc0d0  movaps [r15+0x2F0], xmm10
000075d5269dc0d8  vmovaps xmm5, [rsp+0x50]
000075d5269dc0de  vpermilpd xmm5, xmm5, 0x00
000075d5269dc0e4  vmovaps xmm3, [rsp+0x70]
000075d5269dc0ea  vmovaps [rsp+0x50], xmm1
000075d5269dc0f0  movaps xmm4, xmm3
000075d5269dc0f3  mulpd xmm4, xmm5
000075d5269dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000075d5269dc0fc  ptest xmm1, xmm1
000075d5269dc101  jnz 0x000075D5269DE2CB
000075d5269dc107  lea r12, [rax+0xD0]
000075d5269dc10e  movups xmm1, [r13+r12*1]
000075d5269dc114  vmovaps xmm3, [rsp+0xD0]
000075d5269dc11d  vmovaps [rsp+0x70], xmm1
000075d5269dc123  movaps xmm5, xmm6
000075d5269dc126  addpd xmm5, xmm3
000075d5269dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000075d5269dc12f  ptest xmm1, xmm1
000075d5269dc134  jnz 0x000075D5269DE415
000075d5269dc13a  vmovaps xmm1, [rsp+0x60]
000075d5269dc140  vpermilpd xmm1, xmm1, 0x00
000075d5269dc146  movaps xmm6, xmm9
000075d5269dc14a  mulpd xmm6, xmm1
000075d5269dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000075d5269dc153  ptest xmm3, xmm3
000075d5269dc158  jnz 0x000075D5269DE555
000075d5269dc15e  movaps [r15+0x260], xmm6
000075d5269dc166  vxorps xmm1, xmm1, xmm1
000075d5269dc16a  vpbroadcastq xmm1, xmm1
000075d5269dc16f  movaps [r15+0x1B0], xmm1
000075d5269dc177  vmovaps xmm1, [rsp+0x60]
000075d5269dc17d  vpermilpd xmm1, xmm1, 0x00
000075d5269dc183  vmovaps xmm3, [rsp+0x70]
000075d5269dc189  vmovaps [rsp+0x70], xmm15
000075d5269dc18f  movaps xmm9, xmm3
000075d5269dc193  mulpd xmm9, xmm1
000075d5269dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000075d5269dc19e  ptest xmm15, xmm15
000075d5269dc1a4  jnz 0x000075D5269DE696
000075d5269dc1aa  lea r12, [rax+0xC0]
000075d5269dc1b1  movups xmm1, [r13+r12*1]
000075d5269dc1b7  vmovaps xmm3, [rsp+0xC0]
000075d5269dc1c0  vmovaps [rsp+0x80], xmm1
000075d5269dc1c9  movaps xmm15, xmm3
000075d5269dc1cd  addpd xmm15, xmm7
000075d5269dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269dc1d8  ptest xmm1, xmm1
000075d5269dc1dd  jnz 0x000075D5269DE7E2
000075d5269dc1e3  vmovaps [rsp+0xC0], xmm13
000075d5269dc1ec  vmovaps xmm1, [rsp+0xC0]
000075d5269dc1f5  por xmm13, xmm1
000075d5269dc1fa  movaps [r15+0x270], xmm13
000075d5269dc202  vmovaps xmm1, [rsp+0xB0]
000075d5269dc20b  vmovaps xmm7, [rsp+0xB0]
000075d5269dc214  por xmm1, xmm7
000075d5269dc218  movaps [r15+0x1A0], xmm1
000075d5269dc220  vmovaps xmm1, [rsp+0x60]
000075d5269dc226  vpermilpd xmm1, xmm1, 0x00
000075d5269dc22c  vmovaps [rsp+0xB0], xmm1
000075d5269dc235  vmovaps xmm1, [rsp+0x80]
000075d5269dc23e  vmovaps [rsp+0x80], xmm15
000075d5269dc247  vmovaps xmm15, [rsp+0xB0]
000075d5269dc250  vmovaps [rsp+0xB0], xmm14
000075d5269dc259  movaps xmm3, xmm1
000075d5269dc25c  mulpd xmm3, xmm15
000075d5269dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000075d5269dc266  ptest xmm14, xmm14
000075d5269dc26c  jnz 0x000075D5269DE924
000075d5269dc272  lea r12, [rax+0x20]
000075d5269dc276  movups xmm1, [r13+r12*1]
000075d5269dc27c  movaps [r15+0x110], xmm1
000075d5269dc284  vmovaps xmm14, [rsp+0x70]
000075d5269dc28a  vmovaps [rsp+0x70], xmm1
000075d5269dc290  movaps xmm15, xmm14
000075d5269dc294  addpd xmm15, xmm4
000075d5269dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000075d5269dc29f  ptest xmm1, xmm1
000075d5269dc2a4  jnz 0x000075D5269DEA6F
000075d5269dc2aa  vmovaps xmm1, [rsp+0x60]
000075d5269dc2b0  vpermilpd xmm1, xmm1, 0x00
000075d5269dc2b6  movaps xmm14, xmm2
000075d5269dc2ba  mulpd xmm14, xmm1
000075d5269dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000075d5269dc2c5  ptest xmm4, xmm4
000075d5269dc2ca  jnz 0x000075D5269DEBB2
000075d5269dc2d0  vmovaps xmm4, [rsp+0x50]
000075d5269dc2d6  movaps xmm1, xmm4
000075d5269dc2d9  addpd xmm1, xmm9
000075d5269dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000075d5269dc2e3  ptest xmm2, xmm2
000075d5269dc2e8  jnz 0x000075D5269DECF4
000075d5269dc2ee  vmovaps xmm9, [rsp+0x30]
000075d5269dc2f4  vpermilpd xmm9, xmm9, 0x00
000075d5269dc2fa  vmovaps xmm2, [rsp+0x70]
000075d5269dc300  vmovaps [rsp+0x50], xmm1
000075d5269dc306  movaps xmm4, xmm2
000075d5269dc309  mulpd xmm4, xmm9
000075d5269dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000075d5269dc313  ptest xmm1, xmm1
000075d5269dc318  jnz 0x000075D5269DEE35
000075d5269dc31e  vmovaps xmm1, [rsp+0x30]
000075d5269dc324  vpermilpd xmm1, xmm1, 0x00
000075d5269dc32a  vmovaps xmm2, [rsp+0x90]
000075d5269dc333  vmovaps [rsp+0x60], xmm15
000075d5269dc339  movaps xmm9, xmm2
000075d5269dc33d  mulpd xmm9, xmm1
000075d5269dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000075d5269dc348  ptest xmm15, xmm15
000075d5269dc34e  jnz 0x000075D5269DEF76
000075d5269dc354  vmovaps xmm15, [rsp+0x80]
000075d5269dc35d  movaps xmm1, xmm15
000075d5269dc361  addpd xmm1, xmm6
000075d5269dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000075d5269dc36a  ptest xmm2, xmm2
000075d5269dc36f  jnz 0x000075D5269DF0B8
000075d5269dc375  movaps xmm15, xmm5
000075d5269dc379  addpd xmm15, xmm3
000075d5269dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000075d5269dc384  ptest xmm6, xmm6
000075d5269dc389  jnz 0x000075D5269DF1F9
000075d5269dc38f  vmovaps xmm6, [rsp+0x30]
000075d5269dc395  vpermilpd xmm6, xmm6, 0x00
000075d5269dc39b  movaps xmm5, xmm8
000075d5269dc39f  mulpd xmm5, xmm6
000075d5269dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000075d5269dc3a8  ptest xmm3, xmm3
000075d5269dc3ad  jnz 0x000075D5269DF33B
000075d5269dc3b3  vmovaps xmm8, [rsp+0x30]
000075d5269dc3b9  vpermilpd xmm8, xmm8, 0x00
000075d5269dc3bf  movaps xmm6, xmm10
000075d5269dc3c3  mulpd xmm6, xmm8
000075d5269dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000075d5269dc3cd  ptest xmm3, xmm3
000075d5269dc3d2  jnz 0x000075D5269DF47C
000075d5269dc3d8  vmovaps xmm8, [rsp+0x60]
000075d5269dc3de  movaps xmm10, xmm8
000075d5269dc3e2  addpd xmm10, xmm14
000075d5269dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000075d5269dc3ed  ptest xmm3, xmm3
000075d5269dc3f2  jnz 0x000075D5269DF5BE
000075d5269dc3f8  vmovaps xmm8, [rsp+0x50]
000075d5269dc3fe  movaps xmm14, xmm8
000075d5269dc402  addpd xmm14, xmm4
000075d5269dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000075d5269dc40d  ptest xmm3, xmm3
000075d5269dc412  jnz 0x000075D5269DF702
000075d5269dc418  vmovaps xmm8, [rsp+0x40]
000075d5269dc41e  vpermilpd xmm8, xmm8, 0x00
000075d5269dc424  movaps xmm4, xmm13
000075d5269dc428  mulpd xmm4, xmm8
000075d5269dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000075d5269dc432  ptest xmm3, xmm3
000075d5269dc437  jnz 0x000075D5269DF845
000075d5269dc43d  movaps xmm13, xmm15
000075d5269dc441  addpd xmm13, xmm9
000075d5269dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000075d5269dc44c  ptest xmm8, xmm8
000075d5269dc452  jnz 0x000075D5269DF987
000075d5269dc458  movaps xmm15, xmm1
000075d5269dc45c  addpd xmm15, xmm5
000075d5269dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000075d5269dc467  ptest xmm9, xmm9
000075d5269dc46d  jnz 0x000075D5269DFACB
000075d5269dc473  vmovaps [rsp+0x30], xmm11
000075d5269dc479  vmovaps xmm1, [rsp+0x30]
000075d5269dc47f  por xmm11, xmm1
000075d5269dc484  movaps [r15+0x250], xmm11
000075d5269dc48c  vmovaps [rsp+0x30], xmm12
000075d5269dc492  vmovaps xmm1, [rsp+0x30]
000075d5269dc498  por xmm12, xmm1
000075d5269dc49d  movaps [r15+0x2A0], xmm12
000075d5269dc4a5  vmovaps xmm1, [rsp+0xA0]
000075d5269dc4ae  vmovaps xmm11, [rsp+0xA0]
000075d5269dc4b7  por xmm1, xmm11
000075d5269dc4bc  movaps [r15+0x1D0], xmm1
000075d5269dc4c4  lea r12, [rax+0x40]
000075d5269dc4c8  movups xmm1, [r13+r12*1]
000075d5269dc4ce  movaps [r15+0x2C0], xmm1
000075d5269dc4d6  vmovaps xmm11, [rsp+0x40]
000075d5269dc4dc  vpermilpd xmm11, xmm11, 0x00
000075d5269dc4e2  vmovaps xmm8, [rsp+0xE0]
000075d5269dc4eb  movaps xmm9, xmm8
000075d5269dc4ef  mulpd xmm9, xmm11
000075d5269dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000075d5269dc4fa  ptest xmm5, xmm5
000075d5269dc4ff  jnz 0x000075D5269DFC17
000075d5269dc505  movaps xmm11, xmm10
000075d5269dc509  addpd xmm11, xmm6
000075d5269dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000075d5269dc514  ptest xmm8, xmm8
000075d5269dc51a  jnz 0x000075D5269DFD5B
000075d5269dc520  movaps xmm10, xmm14
000075d5269dc524  addpd xmm10, xmm4
000075d5269dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000075d5269dc52f  ptest xmm8, xmm8
000075d5269dc535  jnz 0x000075D5269DFE9E
000075d5269dc53b  vmovaps xmm14, [rsp+0x40]
000075d5269dc541  vpermilpd xmm14, xmm14, 0x00
000075d5269dc547  movaps xmm8, xmm1
000075d5269dc54b  mulpd xmm8, xmm14
000075d5269dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000075d5269dc556  ptest xmm6, xmm6
000075d5269dc55b  jnz 0x000075D5269DFFE1
000075d5269dc561  movaps xmm1, [r15+0x2B0]
000075d5269dc569  vmovaps xmm14, [rsp+0x40]
000075d5269dc56f  vpermilpd xmm14, xmm14, 0x00
000075d5269dc575  movaps xmm6, xmm1
000075d5269dc578  mulpd xmm6, xmm14
000075d5269dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000075d5269dc582  ptest xmm5, xmm5
000075d5269dc587  jnz 0x000075D5269E0124
000075d5269dc58d  vmovaps xmm1, [rsp+0x10]
000075d5269dc593  vpermilpd xmm1, xmm1, 0x00
000075d5269dc599  movaps xmm14, xmm12
000075d5269dc59d  mulpd xmm14, xmm1
000075d5269dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000075d5269dc5a8  ptest xmm5, xmm5
000075d5269dc5ad  jnz 0x000075D5269E0265
000075d5269dc5b3  movaps xmm1, xmm13
000075d5269dc5b7  addpd xmm1, xmm9
000075d5269dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000075d5269dc5c1  ptest xmm12, xmm12
000075d5269dc5c7  jnz 0x000075D5269E03A8
000075d5269dc5cd  vmovaps xmm13, [rsp+0x10]
000075d5269dc5d3  vpermilpd xmm13, xmm13, 0x00
000075d5269dc5d9  movaps xmm12, xmm7
000075d5269dc5dd  mulpd xmm12, xmm13
000075d5269dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000075d5269dc5e8  ptest xmm9, xmm9
000075d5269dc5ee  jnz 0x000075D5269E04EA
000075d5269dc5f4  movaps xmm13, xmm15
000075d5269dc5f8  addpd xmm13, xmm8
000075d5269dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000075d5269dc603  ptest xmm9, xmm9
000075d5269dc609  jnz 0x000075D5269E062D
000075d5269dc60f  movaps xmm15, [r15+0x290]
000075d5269dc617  vmovaps xmm9, [rsp+0x10]
000075d5269dc61d  vpermilpd xmm9, xmm9, 0x00
000075d5269dc623  movaps xmm8, xmm15
000075d5269dc627  mulpd xmm8, xmm9
000075d5269dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000075d5269dc632  ptest xmm7, xmm7
000075d5269dc637  jnz 0x000075D5269E0771
000075d5269dc63d  movaps xmm15, xmm11
000075d5269dc641  addpd xmm15, xmm6
000075d5269dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000075d5269dc64c  ptest xmm9, xmm9
000075d5269dc652  jnz 0x000075D5269E08B5
000075d5269dc658  movaps xmm11, [r15+0x1E0]
000075d5269dc660  vmovaps xmm9, [rsp+0x10]
000075d5269dc666  vpermilpd xmm9, xmm9, 0x00
000075d5269dc66c  movaps xmm7, xmm11
000075d5269dc670  mulpd xmm7, xmm9
000075d5269dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000075d5269dc67a  ptest xmm6, xmm6
000075d5269dc67f  jnz 0x000075D5269E09F8
000075d5269dc685  movaps xmm11, xmm10
000075d5269dc689  addpd xmm11, xmm14
000075d5269dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000075d5269dc694  ptest xmm9, xmm9
000075d5269dc69a  jnz 0x000075D5269E0B3A
000075d5269dc6a0  lea r12, [rax+0x70]
000075d5269dc6a4  movups xmm14, [r13+r12*1]
000075d5269dc6aa  movaps [r15+0x240], xmm14
000075d5269dc6b2  movaps xmm10, xmm1
000075d5269dc6b6  addpd xmm10, xmm12
000075d5269dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000075d5269dc6c1  ptest xmm9, xmm9
000075d5269dc6c7  jnz 0x000075D5269E0C88
000075d5269dc6cd  movaps [r15+0x170], xmm10
000075d5269dc6d5  vmovaps xmm1, [rsp+0x20]
000075d5269dc6db  vpermilpd xmm1, xmm1, 0x00
000075d5269dc6e1  movaps xmm12, xmm14
000075d5269dc6e5  mulpd xmm12, xmm1
000075d5269dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000075d5269dc6f0  ptest xmm9, xmm9
000075d5269dc6f6  jnz 0x000075D5269E0DCB
000075d5269dc6fc  vmovaps xmm1, [rsp+0x20]
000075d5269dc702  vpermilpd xmm1, xmm1, 0x00
000075d5269dc708  vmovaps xmm9, [rsp+0xB0]
000075d5269dc711  movaps xmm14, xmm9
000075d5269dc715  mulpd xmm14, xmm1
000075d5269dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000075d5269dc720  ptest xmm6, xmm6
000075d5269dc725  jnz 0x000075D5269E0F0E
000075d5269dc72b  movaps [r15+0x180], xmm14
000075d5269dc733  movaps xmm1, xmm13
000075d5269dc737  addpd xmm1, xmm8
000075d5269dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000075d5269dc741  ptest xmm9, xmm9
000075d5269dc747  jnz 0x000075D5269E1051
000075d5269dc74d  movaps [r15+0x210], xmm1
000075d5269dc755  movups xmm13, [r13+rax*1]
000075d5269dc75b  lea r12, [rax+0x10]
000075d5269dc75f  movups xmm9, [r13+r12*1]
000075d5269dc765  movaps [r15+0x230], xmm9
000075d5269dc76d  movaps xmm8, xmm15
000075d5269dc771  addpd xmm8, xmm7
000075d5269dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000075d5269dc77c  ptest xmm6, xmm6
000075d5269dc781  jnz 0x000075D5269E11A7
000075d5269dc787  movaps [r15+0x130], xmm8
000075d5269dc78f  vmovaps xmm15, [rsp+0x20]
000075d5269dc795  vpermilpd xmm15, xmm15, 0x00
000075d5269dc79b  movaps xmm7, xmm9
000075d5269dc79f  mulpd xmm7, xmm15
000075d5269dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000075d5269dc7a9  ptest xmm6, xmm6
000075d5269dc7ae  jnz 0x000075D5269E12EA
000075d5269dc7b4  movaps [r15+0x220], xmm7
000075d5269dc7bc  vmovaps xmm15, [rsp+0x20]
000075d5269dc7c2  vpermilpd xmm15, xmm15, 0x00
000075d5269dc7c8  movaps xmm9, xmm13
000075d5269dc7cc  mulpd xmm9, xmm15
000075d5269dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000075d5269dc7d7  ptest xmm6, xmm6
000075d5269dc7dc  jnz 0x000075D5269E142C
000075d5269dc7e2  movaps xmm15, xmm11
000075d5269dc7e6  addpd xmm15, xmm12
000075d5269dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000075d5269dc7f1  ptest xmm13, xmm13
000075d5269dc7f7  jnz 0x000075D5269E1570
000075d5269dc7fd  movaps [r15+0x140], xmm15
000075d5269dc805  movaps xmm13, xmm10
000075d5269dc809  addpd xmm13, xmm14
000075d5269dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000075d5269dc814  ptest xmm12, xmm12
000075d5269dc81a  jnz 0x000075D5269E16B4
000075d5269dc820  movaps [r15+0x150], xmm13
000075d5269dc828  movaps xmm14, xmm1
000075d5269dc82c  addpd xmm14, xmm7
000075d5269dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000075d5269dc837  ptest xmm12, xmm12
000075d5269dc83d  jnz 0x000075D5269E17F8
000075d5269dc843  movaps [r15+0x160], xmm14
000075d5269dc84b  movaps xmm1, xmm8
000075d5269dc84f  addpd xmm1, xmm9
000075d5269dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000075d5269dc859  ptest xmm12, xmm12
000075d5269dc85f  jnz 0x000075D5269E193A
000075d5269dc865  movaps [r15+0x120], xmm1
000075d5269dc86d  movups [r13+r14*1], xmm15
000075d5269dc873  lea rax, [r14+0x10]
000075d5269dc877  movups [r13+rax*1], xmm13
000075d5269dc87d  lea rax, [r14+0x20]
000075d5269dc881  movups [r13+rax*1], xmm14
000075d5269dc887  lea rax, [r14+0x30]
000075d5269dc88b  movups [r13+rax*1], xmm1
000075d5269dc891  mov eax, [r15+0x108]
000075d5269dc898  sahf
000075d5269dc899  jnz 0x000075D5269DC8CB
000075d5269dc89b  cmp dword ptr [r15+0x318], 0x00
000075d5269dc8a3  jz 0x000075D5269DB900
000075d5269dc8a9  nop [rax+rax*1], ax
000075d5269dc8b2  nop [rax+rax*1], eax
000075d5269dc8ba  mov eax, 0x410444
000075d5269dc8bf  mov [r15+0x100], rax
000075d5269dc8c6  jmp 0x000075D5267FE110
000075d5269dc8cb  cmp dword ptr [r15+0x318], 0x00
000075d5269dc8d3  jz 0x000075D5269D57E0
000075d5269dc8d9  nop [rax+rax*1], ax
000075d5269dc8e2  nop [rax+rax*1], eax
000075d5269dc8ea  mov eax, 0x410278
000075d5269dc8ef  mov [r15+0x100], rax
000075d5269dc8f6  jmp 0x000075D5267FE110
000075d5269dc8fb  int3
000075d5269dc8fc  call 0x000075D5268E27E0
000075d5269dc901  jmp 0x000075D5269DB9DF
000075d5269dc906  call 0x000075D5268E1570
000075d5269dc90b  jmp 0x000075D5269DB9E8
000075d5269dc910  call 0x000075D5268E27E0
000075d5269dc915  jmp 0x000075D5269DBA44
000075d5269dc91a  call 0x000075D5268E1570
000075d5269dc91f  jmp 0x000075D5269DBA4D
000075d5269dc924  call 0x000075D5268E27E0
000075d5269dc929  jmp 0x000075D5269DBA90
000075d5269dc92e  call 0x000075D5268E1570
000075d5269dc933  jmp 0x000075D5269DBA99
000075d5269dc938  call 0x000075D52680DC20
000075d5269dc93d  jmp 0x000075D5269DBAD8
000075d5269dc942  call 0x000075D5268D59C0
000075d5269dc947  jmp 0x000075D5269DBAEB
000075d5269dc94c  call 0x000075D5268E0E30
000075d5269dc951  jmp 0x000075D5269DBB09
000075d5269dc956  call 0x000075D5268DFBC0
000075d5269dc95b  jmp 0x000075D5269DBB13
000075d5269dc960  call 0x000075D5268DE950
000075d5269dc965  jmp 0x000075D5269DBB1D
000075d5269dc96a  sub rsp, 0x08
000075d5269dc96e  push rax
000075d5269dc96f  push rcx
000075d5269dc970  push rdx
000075d5269dc971  push rdi
000075d5269dc972  push rsi
000075d5269dc973  push r8
000075d5269dc975  push r9
000075d5269dc977  push r10
000075d5269dc979  push r11
000075d5269dc97b  sub rsp, 0xF0
000075d5269dc982  vmovaps [rsp], xmm0
000075d5269dc987  vmovaps [rsp+0x10], xmm1
000075d5269dc98d  vmovaps [rsp+0x20], xmm2
000075d5269dc993  vmovaps [rsp+0x30], xmm3
000075d5269dc999  vmovaps [rsp+0x40], xmm4
000075d5269dc99f  vmovaps [rsp+0x50], xmm5
000075d5269dc9a5  vmovaps [rsp+0x60], xmm6
000075d5269dc9ab  vmovaps [rsp+0x70], xmm7
000075d5269dc9b1  vmovaps [rsp+0x80], xmm9
000075d5269dc9ba  vmovaps [rsp+0x90], xmm10
000075d5269dc9c3  vmovaps [rsp+0xA0], xmm11
000075d5269dc9cc  vmovaps [rsp+0xB0], xmm12
000075d5269dc9d5  vmovaps [rsp+0xC0], xmm13
000075d5269dc9de  vmovaps [rsp+0xD0], xmm14
000075d5269dc9e7  vmovaps [rsp+0xE0], xmm15
000075d5269dc9f0  sub rsp, 0x30
000075d5269dc9f4  movaps [rsp], xmm8
000075d5269dc9f9  movaps [rsp+0x10], xmm12
000075d5269dc9ff  movaps [rsp+0x20], xmm15
000075d5269dca05  lea rdi, [rsp]
000075d5269dca09  mov esi, 0x00
000075d5269dca0e  mov rax, 0x601129E62530
000075d5269dca18  call rax
000075d5269dca1a  movaps xmm8, [rsp]
000075d5269dca1f  add rsp, 0x30
000075d5269dca23  vmovaps xmm0, [rsp]
000075d5269dca28  vmovaps xmm1, [rsp+0x10]
000075d5269dca2e  vmovaps xmm2, [rsp+0x20]
000075d5269dca34  vmovaps xmm3, [rsp+0x30]
000075d5269dca3a  vmovaps xmm4, [rsp+0x40]
000075d5269dca40  vmovaps xmm5, [rsp+0x50]
000075d5269dca46  vmovaps xmm6, [rsp+0x60]
000075d5269dca4c  vmovaps xmm7, [rsp+0x70]
000075d5269dca52  vmovaps xmm9, [rsp+0x80]
000075d5269dca5b  vmovaps xmm10, [rsp+0x90]
000075d5269dca64  vmovaps xmm11, [rsp+0xA0]
000075d5269dca6d  vmovaps xmm12, [rsp+0xB0]
000075d5269dca76  vmovaps xmm13, [rsp+0xC0]
000075d5269dca7f  vmovaps xmm14, [rsp+0xD0]
000075d5269dca88  vmovaps xmm15, [rsp+0xE0]
000075d5269dca91  add rsp, 0xF0
000075d5269dca98  pop r11
000075d5269dca9a  pop r10
000075d5269dca9c  pop r9
000075d5269dca9e  pop r8
000075d5269dcaa0  pop rsi
000075d5269dcaa1  pop rdi
000075d5269dcaa2  pop rdx
000075d5269dcaa3  pop rcx
000075d5269dcaa4  pop rax
000075d5269dcaa5  add rsp, 0x08
000075d5269dcaa9  jmp 0x000075D5269DBB47
000075d5269dcaae  sub rsp, 0x08
000075d5269dcab2  push rax
000075d5269dcab3  push rcx
000075d5269dcab4  push rdx
000075d5269dcab5  push rdi
000075d5269dcab6  push rsi
000075d5269dcab7  push r8
000075d5269dcab9  push r9
000075d5269dcabb  push r10
000075d5269dcabd  push r11
000075d5269dcabf  sub rsp, 0xF0
000075d5269dcac6  vmovaps [rsp], xmm0
000075d5269dcacb  vmovaps [rsp+0x10], xmm1
000075d5269dcad1  vmovaps [rsp+0x20], xmm2
000075d5269dcad7  vmovaps [rsp+0x30], xmm3
000075d5269dcadd  vmovaps [rsp+0x40], xmm4
000075d5269dcae3  vmovaps [rsp+0x50], xmm5
000075d5269dcae9  vmovaps [rsp+0x60], xmm6
000075d5269dcaef  vmovaps [rsp+0x70], xmm8
000075d5269dcaf5  vmovaps [rsp+0x80], xmm9
000075d5269dcafe  vmovaps [rsp+0x90], xmm10
000075d5269dcb07  vmovaps [rsp+0xA0], xmm11
000075d5269dcb10  vmovaps [rsp+0xB0], xmm12
000075d5269dcb19  vmovaps [rsp+0xC0], xmm13
000075d5269dcb22  vmovaps [rsp+0xD0], xmm14
000075d5269dcb2b  vmovaps [rsp+0xE0], xmm15
000075d5269dcb34  sub rsp, 0x30
000075d5269dcb38  movaps [rsp], xmm7
000075d5269dcb3c  movaps [rsp+0x10], xmm9
000075d5269dcb42  movaps [rsp+0x20], xmm15
000075d5269dcb48  lea rdi, [rsp]
000075d5269dcb4c  mov esi, 0x00
000075d5269dcb51  mov rax, 0x601129E62530
000075d5269dcb5b  call rax
000075d5269dcb5d  movaps xmm7, [rsp]
000075d5269dcb61  add rsp, 0x30
000075d5269dcb65  vmovaps xmm0, [rsp]
000075d5269dcb6a  vmovaps xmm1, [rsp+0x10]
000075d5269dcb70  vmovaps xmm2, [rsp+0x20]
000075d5269dcb76  vmovaps xmm3, [rsp+0x30]
000075d5269dcb7c  vmovaps xmm4, [rsp+0x40]
000075d5269dcb82  vmovaps xmm5, [rsp+0x50]
000075d5269dcb88  vmovaps xmm6, [rsp+0x60]
000075d5269dcb8e  vmovaps xmm8, [rsp+0x70]
000075d5269dcb94  vmovaps xmm9, [rsp+0x80]
000075d5269dcb9d  vmovaps xmm10, [rsp+0x90]
000075d5269dcba6  vmovaps xmm11, [rsp+0xA0]
000075d5269dcbaf  vmovaps xmm12, [rsp+0xB0]
000075d5269dcbb8  vmovaps xmm13, [rsp+0xC0]
000075d5269dcbc1  vmovaps xmm14, [rsp+0xD0]
000075d5269dcbca  vmovaps xmm15, [rsp+0xE0]
000075d5269dcbd3  add rsp, 0xF0
000075d5269dcbda  pop r11
000075d5269dcbdc  pop r10
000075d5269dcbde  pop r9
000075d5269dcbe0  pop r8
000075d5269dcbe2  pop rsi
000075d5269dcbe3  pop rdi
000075d5269dcbe4  pop rdx
000075d5269dcbe5  pop rcx
000075d5269dcbe6  pop rax
000075d5269dcbe7  add rsp, 0x08
000075d5269dcbeb  jmp 0x000075D5269DBB75
000075d5269dcbf0  sub rsp, 0x08
000075d5269dcbf4  push rax
000075d5269dcbf5  push rcx
000075d5269dcbf6  push rdx
000075d5269dcbf7  push rdi
000075d5269dcbf8  push rsi
000075d5269dcbf9  push r8
000075d5269dcbfb  push r9
000075d5269dcbfd  push r10
000075d5269dcbff  push r11
000075d5269dcc01  sub rsp, 0xF0
000075d5269dcc08  vmovaps [rsp], xmm0
000075d5269dcc0d  vmovaps [rsp+0x10], xmm1
000075d5269dcc13  vmovaps [rsp+0x20], xmm2
000075d5269dcc19  vmovaps [rsp+0x30], xmm3
000075d5269dcc1f  vmovaps [rsp+0x40], xmm4
000075d5269dcc25  vmovaps [rsp+0x50], xmm5
000075d5269dcc2b  vmovaps [rsp+0x60], xmm6
000075d5269dcc31  vmovaps [rsp+0x70], xmm7
000075d5269dcc37  vmovaps [rsp+0x80], xmm8
000075d5269dcc40  vmovaps [rsp+0x90], xmm10
000075d5269dcc49  vmovaps [rsp+0xA0], xmm11
000075d5269dcc52  vmovaps [rsp+0xB0], xmm12
000075d5269dcc5b  vmovaps [rsp+0xC0], xmm13
000075d5269dcc64  vmovaps [rsp+0xD0], xmm14
000075d5269dcc6d  vmovaps [rsp+0xE0], xmm15
000075d5269dcc76  sub rsp, 0x30
000075d5269dcc7a  movaps [rsp], xmm9
000075d5269dcc7f  movaps [rsp+0x10], xmm12
000075d5269dcc85  movaps [rsp+0x20], xmm10
000075d5269dcc8b  lea rdi, [rsp]
000075d5269dcc8f  mov esi, 0x00
000075d5269dcc94  mov rax, 0x601129E62530
000075d5269dcc9e  call rax
000075d5269dcca0  movaps xmm9, [rsp]
000075d5269dcca5  add rsp, 0x30
000075d5269dcca9  vmovaps xmm0, [rsp]
000075d5269dccae  vmovaps xmm1, [rsp+0x10]
000075d5269dccb4  vmovaps xmm2, [rsp+0x20]
000075d5269dccba  vmovaps xmm3, [rsp+0x30]
000075d5269dccc0  vmovaps xmm4, [rsp+0x40]
000075d5269dccc6  vmovaps xmm5, [rsp+0x50]
000075d5269dcccc  vmovaps xmm6, [rsp+0x60]
000075d5269dccd2  vmovaps xmm7, [rsp+0x70]
000075d5269dccd8  vmovaps xmm8, [rsp+0x80]
000075d5269dcce1  vmovaps xmm10, [rsp+0x90]
000075d5269dccea  vmovaps xmm11, [rsp+0xA0]
000075d5269dccf3  vmovaps xmm12, [rsp+0xB0]
000075d5269dccfc  vmovaps xmm13, [rsp+0xC0]
000075d5269dcd05  vmovaps xmm14, [rsp+0xD0]
000075d5269dcd0e  vmovaps xmm15, [rsp+0xE0]
000075d5269dcd17  add rsp, 0xF0
000075d5269dcd1e  pop r11
000075d5269dcd20  pop r10
000075d5269dcd22  pop r9
000075d5269dcd24  pop r8
000075d5269dcd26  pop rsi
000075d5269dcd27  pop rdi
000075d5269dcd28  pop rdx
000075d5269dcd29  pop rcx
000075d5269dcd2a  pop rax
000075d5269dcd2b  add rsp, 0x08
000075d5269dcd2f  jmp 0x000075D5269DBB99
000075d5269dcd34  sub rsp, 0x08
000075d5269dcd38  push rax
000075d5269dcd39  push rcx
000075d5269dcd3a  push rdx
000075d5269dcd3b  push rdi
000075d5269dcd3c  push rsi
000075d5269dcd3d  push r8
000075d5269dcd3f  push r9
000075d5269dcd41  push r10
000075d5269dcd43  push r11
000075d5269dcd45  sub rsp, 0xF0
000075d5269dcd4c  vmovaps [rsp], xmm0
000075d5269dcd51  vmovaps [rsp+0x10], xmm1
000075d5269dcd57  vmovaps [rsp+0x20], xmm2
000075d5269dcd5d  vmovaps [rsp+0x30], xmm3
000075d5269dcd63  vmovaps [rsp+0x40], xmm4
000075d5269dcd69  vmovaps [rsp+0x50], xmm5
000075d5269dcd6f  vmovaps [rsp+0x60], xmm6
000075d5269dcd75  vmovaps [rsp+0x70], xmm7
000075d5269dcd7b  vmovaps [rsp+0x80], xmm8
000075d5269dcd84  vmovaps [rsp+0x90], xmm9
000075d5269dcd8d  vmovaps [rsp+0xA0], xmm11
000075d5269dcd96  vmovaps [rsp+0xB0], xmm12
000075d5269dcd9f  vmovaps [rsp+0xC0], xmm13
000075d5269dcda8  vmovaps [rsp+0xD0], xmm14
000075d5269dcdb1  vmovaps [rsp+0xE0], xmm15
000075d5269dcdba  sub rsp, 0x30
000075d5269dcdbe  movaps [rsp], xmm10
000075d5269dcdc3  movaps [rsp+0x10], xmm12
000075d5269dcdc9  movaps [rsp+0x20], xmm11
000075d5269dcdcf  lea rdi, [rsp]
000075d5269dcdd3  mov esi, 0x00
000075d5269dcdd8  mov rax, 0x601129E62530
000075d5269dcde2  call rax
000075d5269dcde4  movaps xmm10, [rsp]
000075d5269dcde9  add rsp, 0x30
000075d5269dcded  vmovaps xmm0, [rsp]
000075d5269dcdf2  vmovaps xmm1, [rsp+0x10]
000075d5269dcdf8  vmovaps xmm2, [rsp+0x20]
000075d5269dcdfe  vmovaps xmm3, [rsp+0x30]
000075d5269dce04  vmovaps xmm4, [rsp+0x40]
000075d5269dce0a  vmovaps xmm5, [rsp+0x50]
000075d5269dce10  vmovaps xmm6, [rsp+0x60]
000075d5269dce16  vmovaps xmm7, [rsp+0x70]
000075d5269dce1c  vmovaps xmm8, [rsp+0x80]
000075d5269dce25  vmovaps xmm9, [rsp+0x90]
000075d5269dce2e  vmovaps xmm11, [rsp+0xA0]
000075d5269dce37  vmovaps xmm12, [rsp+0xB0]
000075d5269dce40  vmovaps xmm13, [rsp+0xC0]
000075d5269dce49  vmovaps xmm14, [rsp+0xD0]
000075d5269dce52  vmovaps xmm15, [rsp+0xE0]
000075d5269dce5b  add rsp, 0xF0
000075d5269dce62  pop r11
000075d5269dce64  pop r10
000075d5269dce66  pop r9
000075d5269dce68  pop r8
000075d5269dce6a  pop rsi
000075d5269dce6b  pop rdi
000075d5269dce6c  pop rdx
000075d5269dce6d  pop rcx
000075d5269dce6e  pop rax
000075d5269dce6f  add rsp, 0x08
000075d5269dce73  jmp 0x000075D5269DBBB3
000075d5269dce78  sub rsp, 0x08
000075d5269dce7c  push rax
000075d5269dce7d  push rcx
000075d5269dce7e  push rdx
000075d5269dce7f  push rdi
000075d5269dce80  push rsi
000075d5269dce81  push r8
000075d5269dce83  push r9
000075d5269dce85  push r10
000075d5269dce87  push r11
000075d5269dce89  sub rsp, 0xF0
000075d5269dce90  vmovaps [rsp], xmm0
000075d5269dce95  vmovaps [rsp+0x10], xmm1
000075d5269dce9b  vmovaps [rsp+0x20], xmm2
000075d5269dcea1  vmovaps [rsp+0x30], xmm3
000075d5269dcea7  vmovaps [rsp+0x40], xmm4
000075d5269dcead  vmovaps [rsp+0x50], xmm5
000075d5269dceb3  vmovaps [rsp+0x60], xmm7
000075d5269dceb9  vmovaps [rsp+0x70], xmm8
000075d5269dcebf  vmovaps [rsp+0x80], xmm9
000075d5269dcec8  vmovaps [rsp+0x90], xmm10
000075d5269dced1  vmovaps [rsp+0xA0], xmm11
000075d5269dceda  vmovaps [rsp+0xB0], xmm12
000075d5269dcee3  vmovaps [rsp+0xC0], xmm13
000075d5269dceec  vmovaps [rsp+0xD0], xmm14
000075d5269dcef5  vmovaps [rsp+0xE0], xmm15
000075d5269dcefe  sub rsp, 0x30
000075d5269dcf02  movaps [rsp], xmm6
000075d5269dcf06  movaps [rsp+0x10], xmm12
000075d5269dcf0c  movaps [rsp+0x20], xmm11
000075d5269dcf12  lea rdi, [rsp]
000075d5269dcf16  mov esi, 0x00
000075d5269dcf1b  mov rax, 0x601129E62530
000075d5269dcf25  call rax
000075d5269dcf27  movaps xmm6, [rsp]
000075d5269dcf2b  add rsp, 0x30
000075d5269dcf2f  vmovaps xmm0, [rsp]
000075d5269dcf34  vmovaps xmm1, [rsp+0x10]
000075d5269dcf3a  vmovaps xmm2, [rsp+0x20]
000075d5269dcf40  vmovaps xmm3, [rsp+0x30]
000075d5269dcf46  vmovaps xmm4, [rsp+0x40]
000075d5269dcf4c  vmovaps xmm5, [rsp+0x50]
000075d5269dcf52  vmovaps xmm7, [rsp+0x60]
000075d5269dcf58  vmovaps xmm8, [rsp+0x70]
000075d5269dcf5e  vmovaps xmm9, [rsp+0x80]
000075d5269dcf67  vmovaps xmm10, [rsp+0x90]
000075d5269dcf70  vmovaps xmm11, [rsp+0xA0]
000075d5269dcf79  vmovaps xmm12, [rsp+0xB0]
000075d5269dcf82  vmovaps xmm13, [rsp+0xC0]
000075d5269dcf8b  vmovaps xmm14, [rsp+0xD0]
000075d5269dcf94  vmovaps xmm15, [rsp+0xE0]
000075d5269dcf9d  add rsp, 0xF0
000075d5269dcfa4  pop r11
000075d5269dcfa6  pop r10
000075d5269dcfa8  pop r9
000075d5269dcfaa  pop r8
000075d5269dcfac  pop rsi
000075d5269dcfad  pop rdi
000075d5269dcfae  pop rdx
000075d5269dcfaf  pop rcx
000075d5269dcfb0  pop rax
000075d5269dcfb1  add rsp, 0x08
000075d5269dcfb5  jmp 0x000075D5269DBBD4
000075d5269dcfba  sub rsp, 0x08
000075d5269dcfbe  push rax
000075d5269dcfbf  push rcx
000075d5269dcfc0  push rdx
000075d5269dcfc1  push rdi
000075d5269dcfc2  push rsi
000075d5269dcfc3  push r8
000075d5269dcfc5  push r9
000075d5269dcfc7  push r10
000075d5269dcfc9  push r11
000075d5269dcfcb  sub rsp, 0xF0
000075d5269dcfd2  vmovaps [rsp], xmm0
000075d5269dcfd7  vmovaps [rsp+0x10], xmm1
000075d5269dcfdd  vmovaps [rsp+0x20], xmm2
000075d5269dcfe3  vmovaps [rsp+0x30], xmm4
000075d5269dcfe9  vmovaps [rsp+0x40], xmm5
000075d5269dcfef  vmovaps [rsp+0x50], xmm6
000075d5269dcff5  vmovaps [rsp+0x60], xmm7
000075d5269dcffb  vmovaps [rsp+0x70], xmm8
000075d5269dd001  vmovaps [rsp+0x80], xmm9
000075d5269dd00a  vmovaps [rsp+0x90], xmm10
000075d5269dd013  vmovaps [rsp+0xA0], xmm11
000075d5269dd01c  vmovaps [rsp+0xB0], xmm12
000075d5269dd025  vmovaps [rsp+0xC0], xmm13
000075d5269dd02e  vmovaps [rsp+0xD0], xmm14
000075d5269dd037  vmovaps [rsp+0xE0], xmm15
000075d5269dd040  sub rsp, 0x30
000075d5269dd044  movaps [rsp], xmm3
000075d5269dd048  movaps [rsp+0x10], xmm5
000075d5269dd04d  movaps [rsp+0x20], xmm4
000075d5269dd052  lea rdi, [rsp]
000075d5269dd056  mov esi, 0x00
000075d5269dd05b  mov rax, 0x601129E62530
000075d5269dd065  call rax
000075d5269dd067  movaps xmm3, [rsp]
000075d5269dd06b  add rsp, 0x30
000075d5269dd06f  vmovaps xmm0, [rsp]
000075d5269dd074  vmovaps xmm1, [rsp+0x10]
000075d5269dd07a  vmovaps xmm2, [rsp+0x20]
000075d5269dd080  vmovaps xmm4, [rsp+0x30]
000075d5269dd086  vmovaps xmm5, [rsp+0x40]
000075d5269dd08c  vmovaps xmm6, [rsp+0x50]
000075d5269dd092  vmovaps xmm7, [rsp+0x60]
000075d5269dd098  vmovaps xmm8, [rsp+0x70]
000075d5269dd09e  vmovaps xmm9, [rsp+0x80]
000075d5269dd0a7  vmovaps xmm10, [rsp+0x90]
000075d5269dd0b0  vmovaps xmm11, [rsp+0xA0]
000075d5269dd0b9  vmovaps xmm12, [rsp+0xB0]
000075d5269dd0c2  vmovaps xmm13, [rsp+0xC0]
000075d5269dd0cb  vmovaps xmm14, [rsp+0xD0]
000075d5269dd0d4  vmovaps xmm15, [rsp+0xE0]
000075d5269dd0dd  add rsp, 0xF0
000075d5269dd0e4  pop r11
000075d5269dd0e6  pop r10
000075d5269dd0e8  pop r9
000075d5269dd0ea  pop r8
000075d5269dd0ec  pop rsi
000075d5269dd0ed  pop rdi
000075d5269dd0ee  pop rdx
000075d5269dd0ef  pop rcx
000075d5269dd0f0  pop rax
000075d5269dd0f1  add rsp, 0x08
000075d5269dd0f5  jmp 0x000075D5269DBC35
000075d5269dd0fa  sub rsp, 0x08
000075d5269dd0fe  push rax
000075d5269dd0ff  push rcx
000075d5269dd100  push rdx
000075d5269dd101  push rdi
000075d5269dd102  push rsi
000075d5269dd103  push r8
000075d5269dd105  push r9
000075d5269dd107  push r10
000075d5269dd109  push r11
000075d5269dd10b  sub rsp, 0xF0
000075d5269dd112  vmovaps [rsp], xmm0
000075d5269dd117  vmovaps [rsp+0x10], xmm1
000075d5269dd11d  vmovaps [rsp+0x20], xmm2
000075d5269dd123  vmovaps [rsp+0x30], xmm3
000075d5269dd129  vmovaps [rsp+0x40], xmm4
000075d5269dd12f  vmovaps [rsp+0x50], xmm6
000075d5269dd135  vmovaps [rsp+0x60], xmm7
000075d5269dd13b  vmovaps [rsp+0x70], xmm8
000075d5269dd141  vmovaps [rsp+0x80], xmm9
000075d5269dd14a  vmovaps [rsp+0x90], xmm10
000075d5269dd153  vmovaps [rsp+0xA0], xmm11
000075d5269dd15c  vmovaps [rsp+0xB0], xmm12
000075d5269dd165  vmovaps [rsp+0xC0], xmm13
000075d5269dd16e  vmovaps [rsp+0xD0], xmm14
000075d5269dd177  vmovaps [rsp+0xE0], xmm15
000075d5269dd180  sub rsp, 0x30
000075d5269dd184  movaps [rsp], xmm5
000075d5269dd188  movaps [rsp+0x10], xmm8
000075d5269dd18e  movaps [rsp+0x20], xmm15
000075d5269dd194  lea rdi, [rsp]
000075d5269dd198  mov esi, 0x00
000075d5269dd19d  mov rax, 0x601129E62530
000075d5269dd1a7  call rax
000075d5269dd1a9  movaps xmm5, [rsp]
000075d5269dd1ad  add rsp, 0x30
000075d5269dd1b1  vmovaps xmm0, [rsp]
000075d5269dd1b6  vmovaps xmm1, [rsp+0x10]
000075d5269dd1bc  vmovaps xmm2, [rsp+0x20]
000075d5269dd1c2  vmovaps xmm3, [rsp+0x30]
000075d5269dd1c8  vmovaps xmm4, [rsp+0x40]
000075d5269dd1ce  vmovaps xmm6, [rsp+0x50]
000075d5269dd1d4  vmovaps xmm7, [rsp+0x60]
000075d5269dd1da  vmovaps xmm8, [rsp+0x70]
000075d5269dd1e0  vmovaps xmm9, [rsp+0x80]
000075d5269dd1e9  vmovaps xmm10, [rsp+0x90]
000075d5269dd1f2  vmovaps xmm11, [rsp+0xA0]
000075d5269dd1fb  vmovaps xmm12, [rsp+0xB0]
000075d5269dd204  vmovaps xmm13, [rsp+0xC0]
000075d5269dd20d  vmovaps xmm14, [rsp+0xD0]
000075d5269dd216  vmovaps xmm15, [rsp+0xE0]
000075d5269dd21f  add rsp, 0xF0
000075d5269dd226  pop r11
000075d5269dd228  pop r10
000075d5269dd22a  pop r9
000075d5269dd22c  pop r8
000075d5269dd22e  pop rsi
000075d5269dd22f  pop rdi
000075d5269dd230  pop rdx
000075d5269dd231  pop rcx
000075d5269dd232  pop rax
000075d5269dd233  add rsp, 0x08
000075d5269dd237  jmp 0x000075D5269DBC73
000075d5269dd23c  sub rsp, 0x08
000075d5269dd240  push rax
000075d5269dd241  push rcx
000075d5269dd242  push rdx
000075d5269dd243  push rdi
000075d5269dd244  push rsi
000075d5269dd245  push r8
000075d5269dd247  push r9
000075d5269dd249  push r10
000075d5269dd24b  push r11
000075d5269dd24d  sub rsp, 0xF0
000075d5269dd254  vmovaps [rsp], xmm0
000075d5269dd259  vmovaps [rsp+0x10], xmm1
000075d5269dd25f  vmovaps [rsp+0x20], xmm2
000075d5269dd265  vmovaps [rsp+0x30], xmm3
000075d5269dd26b  vmovaps [rsp+0x40], xmm5
000075d5269dd271  vmovaps [rsp+0x50], xmm6
000075d5269dd277  vmovaps [rsp+0x60], xmm7
000075d5269dd27d  vmovaps [rsp+0x70], xmm8
000075d5269dd283  vmovaps [rsp+0x80], xmm9
000075d5269dd28c  vmovaps [rsp+0x90], xmm10
000075d5269dd295  vmovaps [rsp+0xA0], xmm11
000075d5269dd29e  vmovaps [rsp+0xB0], xmm12
000075d5269dd2a7  vmovaps [rsp+0xC0], xmm13
000075d5269dd2b0  vmovaps [rsp+0xD0], xmm14
000075d5269dd2b9  vmovaps [rsp+0xE0], xmm15
000075d5269dd2c2  sub rsp, 0x30
000075d5269dd2c6  movaps [rsp], xmm4
000075d5269dd2ca  movaps [rsp+0x10], xmm9
000075d5269dd2d0  movaps [rsp+0x20], xmm8
000075d5269dd2d6  lea rdi, [rsp]
000075d5269dd2da  mov esi, 0x00
000075d5269dd2df  mov rax, 0x601129E62530
000075d5269dd2e9  call rax
000075d5269dd2eb  movaps xmm4, [rsp]
000075d5269dd2ef  add rsp, 0x30
000075d5269dd2f3  vmovaps xmm0, [rsp]
000075d5269dd2f8  vmovaps xmm1, [rsp+0x10]
000075d5269dd2fe  vmovaps xmm2, [rsp+0x20]
000075d5269dd304  vmovaps xmm3, [rsp+0x30]
000075d5269dd30a  vmovaps xmm5, [rsp+0x40]
000075d5269dd310  vmovaps xmm6, [rsp+0x50]
000075d5269dd316  vmovaps xmm7, [rsp+0x60]
000075d5269dd31c  vmovaps xmm8, [rsp+0x70]
000075d5269dd322  vmovaps xmm9, [rsp+0x80]
000075d5269dd32b  vmovaps xmm10, [rsp+0x90]
000075d5269dd334  vmovaps xmm11, [rsp+0xA0]
000075d5269dd33d  vmovaps xmm12, [rsp+0xB0]
000075d5269dd346  vmovaps xmm13, [rsp+0xC0]
000075d5269dd34f  vmovaps xmm14, [rsp+0xD0]
000075d5269dd358  vmovaps xmm15, [rsp+0xE0]
000075d5269dd361  add rsp, 0xF0
000075d5269dd368  pop r11
000075d5269dd36a  pop r10
000075d5269dd36c  pop r9
000075d5269dd36e  pop r8
000075d5269dd370  pop rsi
000075d5269dd371  pop rdi
000075d5269dd372  pop rdx
000075d5269dd373  pop rcx
000075d5269dd374  pop rax
000075d5269dd375  add rsp, 0x08
000075d5269dd379  jmp 0x000075D5269DBC94
000075d5269dd37e  sub rsp, 0x08
000075d5269dd382  push rax
000075d5269dd383  push rcx
000075d5269dd384  push rdx
000075d5269dd385  push rdi
000075d5269dd386  push rsi
000075d5269dd387  push r8
000075d5269dd389  push r9
000075d5269dd38b  push r10
000075d5269dd38d  push r11
000075d5269dd38f  sub rsp, 0xF0
000075d5269dd396  vmovaps [rsp], xmm0
000075d5269dd39b  vmovaps [rsp+0x10], xmm1
000075d5269dd3a1  vmovaps [rsp+0x20], xmm2
000075d5269dd3a7  vmovaps [rsp+0x30], xmm3
000075d5269dd3ad  vmovaps [rsp+0x40], xmm4
000075d5269dd3b3  vmovaps [rsp+0x50], xmm5
000075d5269dd3b9  vmovaps [rsp+0x60], xmm6
000075d5269dd3bf  vmovaps [rsp+0x70], xmm7
000075d5269dd3c5  vmovaps [rsp+0x80], xmm8
000075d5269dd3ce  vmovaps [rsp+0x90], xmm10
000075d5269dd3d7  vmovaps [rsp+0xA0], xmm11
000075d5269dd3e0  vmovaps [rsp+0xB0], xmm12
000075d5269dd3e9  vmovaps [rsp+0xC0], xmm13
000075d5269dd3f2  vmovaps [rsp+0xD0], xmm14
000075d5269dd3fb  vmovaps [rsp+0xE0], xmm15
000075d5269dd404  sub rsp, 0x30
000075d5269dd408  movaps [rsp], xmm9
000075d5269dd40d  movaps [rsp+0x10], xmm10
000075d5269dd413  movaps [rsp+0x20], xmm8
000075d5269dd419  lea rdi, [rsp]
000075d5269dd41d  mov esi, 0x00
000075d5269dd422  mov rax, 0x601129E62530
000075d5269dd42c  call rax
000075d5269dd42e  movaps xmm9, [rsp]
000075d5269dd433  add rsp, 0x30
000075d5269dd437  vmovaps xmm0, [rsp]
000075d5269dd43c  vmovaps xmm1, [rsp+0x10]
000075d5269dd442  vmovaps xmm2, [rsp+0x20]
000075d5269dd448  vmovaps xmm3, [rsp+0x30]
000075d5269dd44e  vmovaps xmm4, [rsp+0x40]
000075d5269dd454  vmovaps xmm5, [rsp+0x50]
000075d5269dd45a  vmovaps xmm6, [rsp+0x60]
000075d5269dd460  vmovaps xmm7, [rsp+0x70]
000075d5269dd466  vmovaps xmm8, [rsp+0x80]
000075d5269dd46f  vmovaps xmm10, [rsp+0x90]
000075d5269dd478  vmovaps xmm11, [rsp+0xA0]
000075d5269dd481  vmovaps xmm12, [rsp+0xB0]
000075d5269dd48a  vmovaps xmm13, [rsp+0xC0]
000075d5269dd493  vmovaps xmm14, [rsp+0xD0]
000075d5269dd49c  vmovaps xmm15, [rsp+0xE0]
000075d5269dd4a5  add rsp, 0xF0
000075d5269dd4ac  pop r11
000075d5269dd4ae  pop r10
000075d5269dd4b0  pop r9
000075d5269dd4b2  pop r8
000075d5269dd4b4  pop rsi
000075d5269dd4b5  pop rdi
000075d5269dd4b6  pop rdx
000075d5269dd4b7  pop rcx
000075d5269dd4b8  pop rax
000075d5269dd4b9  add rsp, 0x08
000075d5269dd4bd  jmp 0x000075D5269DBCAE
000075d5269dd4c2  call 0x000075D5268B52F0
000075d5269dd4c7  jmp 0x000075D5269DBDC8
000075d5269dd4cc  call 0x000075D5268B52F0
000075d5269dd4d1  jmp 0x000075D5269DBDDE
000075d5269dd4d6  sub rsp, 0x08
000075d5269dd4da  push rax
000075d5269dd4db  push rcx
000075d5269dd4dc  push rdx
000075d5269dd4dd  push rdi
000075d5269dd4de  push rsi
000075d5269dd4df  push r8
000075d5269dd4e1  push r9
000075d5269dd4e3  push r10
000075d5269dd4e5  push r11
000075d5269dd4e7  sub rsp, 0xF0
000075d5269dd4ee  vmovaps [rsp], xmm0
000075d5269dd4f3  vmovaps [rsp+0x10], xmm2
000075d5269dd4f9  vmovaps [rsp+0x20], xmm3
000075d5269dd4ff  vmovaps [rsp+0x30], xmm4
000075d5269dd505  vmovaps [rsp+0x40], xmm5
000075d5269dd50b  vmovaps [rsp+0x50], xmm6
000075d5269dd511  vmovaps [rsp+0x60], xmm7
000075d5269dd517  vmovaps [rsp+0x70], xmm8
000075d5269dd51d  vmovaps [rsp+0x80], xmm9
000075d5269dd526  vmovaps [rsp+0x90], xmm10
000075d5269dd52f  vmovaps [rsp+0xA0], xmm11
000075d5269dd538  vmovaps [rsp+0xB0], xmm12
000075d5269dd541  vmovaps [rsp+0xC0], xmm13
000075d5269dd54a  vmovaps [rsp+0xD0], xmm14
000075d5269dd553  vmovaps [rsp+0xE0], xmm15
000075d5269dd55c  sub rsp, 0x30
000075d5269dd560  movaps [rsp], xmm1
000075d5269dd564  movaps [rsp+0x10], xmm6
000075d5269dd569  movaps [rsp+0x20], xmm15
000075d5269dd56f  lea rdi, [rsp]
000075d5269dd573  mov esi, 0x00
000075d5269dd578  mov rax, 0x601129E62530
000075d5269dd582  call rax
000075d5269dd584  movaps xmm1, [rsp]
000075d5269dd588  add rsp, 0x30
000075d5269dd58c  vmovaps xmm0, [rsp]
000075d5269dd591  vmovaps xmm2, [rsp+0x10]
000075d5269dd597  vmovaps xmm3, [rsp+0x20]
000075d5269dd59d  vmovaps xmm4, [rsp+0x30]
000075d5269dd5a3  vmovaps xmm5, [rsp+0x40]
000075d5269dd5a9  vmovaps xmm6, [rsp+0x50]
000075d5269dd5af  vmovaps xmm7, [rsp+0x60]
000075d5269dd5b5  vmovaps xmm8, [rsp+0x70]
000075d5269dd5bb  vmovaps xmm9, [rsp+0x80]
000075d5269dd5c4  vmovaps xmm10, [rsp+0x90]
000075d5269dd5cd  vmovaps xmm11, [rsp+0xA0]
000075d5269dd5d6  vmovaps xmm12, [rsp+0xB0]
000075d5269dd5df  vmovaps xmm13, [rsp+0xC0]
000075d5269dd5e8  vmovaps xmm14, [rsp+0xD0]
000075d5269dd5f1  vmovaps xmm15, [rsp+0xE0]
000075d5269dd5fa  add rsp, 0xF0
000075d5269dd601  pop r11
000075d5269dd603  pop r10
000075d5269dd605  pop r9
000075d5269dd607  pop r8
000075d5269dd609  pop rsi
000075d5269dd60a  pop rdi
000075d5269dd60b  pop rdx
000075d5269dd60c  pop rcx
000075d5269dd60d  pop rax
000075d5269dd60e  add rsp, 0x08
000075d5269dd612  jmp 0x000075D5269DBE1B
000075d5269dd617  call 0x000075D5268C4620
000075d5269dd61c  jmp 0x000075D5269DBE28
000075d5269dd621  sub rsp, 0x08
000075d5269dd625  push rax
000075d5269dd626  push rcx
000075d5269dd627  push rdx
000075d5269dd628  push rdi
000075d5269dd629  push rsi
000075d5269dd62a  push r8
000075d5269dd62c  push r9
000075d5269dd62e  push r10
000075d5269dd630  push r11
000075d5269dd632  sub rsp, 0xF0
000075d5269dd639  vmovaps [rsp], xmm0
000075d5269dd63e  vmovaps [rsp+0x10], xmm1
000075d5269dd644  vmovaps [rsp+0x20], xmm2
000075d5269dd64a  vmovaps [rsp+0x30], xmm3
000075d5269dd650  vmovaps [rsp+0x40], xmm4
000075d5269dd656  vmovaps [rsp+0x50], xmm5
000075d5269dd65c  vmovaps [rsp+0x60], xmm6
000075d5269dd662  vmovaps [rsp+0x70], xmm7
000075d5269dd668  vmovaps [rsp+0x80], xmm8
000075d5269dd671  vmovaps [rsp+0x90], xmm9
000075d5269dd67a  vmovaps [rsp+0xA0], xmm10
000075d5269dd683  vmovaps [rsp+0xB0], xmm11
000075d5269dd68c  vmovaps [rsp+0xC0], xmm12
000075d5269dd695  vmovaps [rsp+0xD0], xmm13
000075d5269dd69e  vmovaps [rsp+0xE0], xmm15
000075d5269dd6a7  sub rsp, 0x30
000075d5269dd6ab  movaps [rsp], xmm14
000075d5269dd6b0  movaps [rsp+0x10], xmm4
000075d5269dd6b5  movaps [rsp+0x20], xmm3
000075d5269dd6ba  lea rdi, [rsp]
000075d5269dd6be  mov esi, 0x00
000075d5269dd6c3  mov rax, 0x601129E62530
000075d5269dd6cd  call rax
000075d5269dd6cf  movaps xmm14, [rsp]
000075d5269dd6d4  add rsp, 0x30
000075d5269dd6d8  vmovaps xmm0, [rsp]
000075d5269dd6dd  vmovaps xmm1, [rsp+0x10]
000075d5269dd6e3  vmovaps xmm2, [rsp+0x20]
000075d5269dd6e9  vmovaps xmm3, [rsp+0x30]
000075d5269dd6ef  vmovaps xmm4, [rsp+0x40]
000075d5269dd6f5  vmovaps xmm5, [rsp+0x50]
000075d5269dd6fb  vmovaps xmm6, [rsp+0x60]
000075d5269dd701  vmovaps xmm7, [rsp+0x70]
000075d5269dd707  vmovaps xmm8, [rsp+0x80]
000075d5269dd710  vmovaps xmm9, [rsp+0x90]
000075d5269dd719  vmovaps xmm10, [rsp+0xA0]
000075d5269dd722  vmovaps xmm11, [rsp+0xB0]
000075d5269dd72b  vmovaps xmm12, [rsp+0xC0]
000075d5269dd734  vmovaps xmm13, [rsp+0xD0]
000075d5269dd73d  vmovaps xmm15, [rsp+0xE0]
000075d5269dd746  add rsp, 0xF0
000075d5269dd74d  pop r11
000075d5269dd74f  pop r10
000075d5269dd751  pop r9
000075d5269dd753  pop r8
000075d5269dd755  pop rsi
000075d5269dd756  pop rdi
000075d5269dd757  pop rdx
000075d5269dd758  pop rcx
000075d5269dd759  pop rax
000075d5269dd75a  add rsp, 0x08
000075d5269dd75e  jmp 0x000075D5269DBE42
000075d5269dd763  sub rsp, 0x08
000075d5269dd767  push rax
000075d5269dd768  push rcx
000075d5269dd769  push rdx
000075d5269dd76a  push rdi
000075d5269dd76b  push rsi
000075d5269dd76c  push r8
000075d5269dd76e  push r9
000075d5269dd770  push r10
000075d5269dd772  push r11
000075d5269dd774  sub rsp, 0xF0
000075d5269dd77b  vmovaps [rsp], xmm0
000075d5269dd780  vmovaps [rsp+0x10], xmm1
000075d5269dd786  vmovaps [rsp+0x20], xmm2
000075d5269dd78c  vmovaps [rsp+0x30], xmm3
000075d5269dd792  vmovaps [rsp+0x40], xmm4
000075d5269dd798  vmovaps [rsp+0x50], xmm5
000075d5269dd79e  vmovaps [rsp+0x60], xmm7
000075d5269dd7a4  vmovaps [rsp+0x70], xmm8
000075d5269dd7aa  vmovaps [rsp+0x80], xmm9
000075d5269dd7b3  vmovaps [rsp+0x90], xmm10
000075d5269dd7bc  vmovaps [rsp+0xA0], xmm11
000075d5269dd7c5  vmovaps [rsp+0xB0], xmm12
000075d5269dd7ce  vmovaps [rsp+0xC0], xmm13
000075d5269dd7d7  vmovaps [rsp+0xD0], xmm14
000075d5269dd7e0  vmovaps [rsp+0xE0], xmm15
000075d5269dd7e9  sub rsp, 0x30
000075d5269dd7ed  movaps [rsp], xmm6
000075d5269dd7f1  movaps [rsp+0x10], xmm9
000075d5269dd7f7  movaps [rsp+0x20], xmm7
000075d5269dd7fc  lea rdi, [rsp]
000075d5269dd800  mov esi, 0x00
000075d5269dd805  mov rax, 0x601129E62530
000075d5269dd80f  call rax
000075d5269dd811  movaps xmm6, [rsp]
000075d5269dd815  add rsp, 0x30
000075d5269dd819  vmovaps xmm0, [rsp]
000075d5269dd81e  vmovaps xmm1, [rsp+0x10]
000075d5269dd824  vmovaps xmm2, [rsp+0x20]
000075d5269dd82a  vmovaps xmm3, [rsp+0x30]
000075d5269dd830  vmovaps xmm4, [rsp+0x40]
000075d5269dd836  vmovaps xmm5, [rsp+0x50]
000075d5269dd83c  vmovaps xmm7, [rsp+0x60]
000075d5269dd842  vmovaps xmm8, [rsp+0x70]
000075d5269dd848  vmovaps xmm9, [rsp+0x80]
000075d5269dd851  vmovaps xmm10, [rsp+0x90]
000075d5269dd85a  vmovaps xmm11, [rsp+0xA0]
000075d5269dd863  vmovaps xmm12, [rsp+0xB0]
000075d5269dd86c  vmovaps xmm13, [rsp+0xC0]
000075d5269dd875  vmovaps xmm14, [rsp+0xD0]
000075d5269dd87e  vmovaps xmm15, [rsp+0xE0]
000075d5269dd887  add rsp, 0xF0
000075d5269dd88e  pop r11
000075d5269dd890  pop r10
000075d5269dd892  pop r9
000075d5269dd894  pop r8
000075d5269dd896  pop rsi
000075d5269dd897  pop rdi
000075d5269dd898  pop rdx
000075d5269dd899  pop rcx
000075d5269dd89a  pop rax
000075d5269dd89b  add rsp, 0x08
000075d5269dd89f  jmp 0x000075D5269DBE5A
000075d5269dd8a4  sub rsp, 0x08
000075d5269dd8a8  push rax
000075d5269dd8a9  push rcx
000075d5269dd8aa  push rdx
000075d5269dd8ab  push rdi
000075d5269dd8ac  push rsi
000075d5269dd8ad  push r8
000075d5269dd8af  push r9
000075d5269dd8b1  push r10
000075d5269dd8b3  push r11
000075d5269dd8b5  sub rsp, 0xF0
000075d5269dd8bc  vmovaps [rsp], xmm0
000075d5269dd8c1  vmovaps [rsp+0x10], xmm1
000075d5269dd8c7  vmovaps [rsp+0x20], xmm2
000075d5269dd8cd  vmovaps [rsp+0x30], xmm3
000075d5269dd8d3  vmovaps [rsp+0x40], xmm4
000075d5269dd8d9  vmovaps [rsp+0x50], xmm5
000075d5269dd8df  vmovaps [rsp+0x60], xmm6
000075d5269dd8e5  vmovaps [rsp+0x70], xmm8
000075d5269dd8eb  vmovaps [rsp+0x80], xmm9
000075d5269dd8f4  vmovaps [rsp+0x90], xmm10
000075d5269dd8fd  vmovaps [rsp+0xA0], xmm11
000075d5269dd906  vmovaps [rsp+0xB0], xmm12
000075d5269dd90f  vmovaps [rsp+0xC0], xmm13
000075d5269dd918  vmovaps [rsp+0xD0], xmm14
000075d5269dd921  vmovaps [rsp+0xE0], xmm15
000075d5269dd92a  sub rsp, 0x30
000075d5269dd92e  movaps [rsp], xmm7
000075d5269dd932  movaps [rsp+0x10], xmm4
000075d5269dd937  movaps [rsp+0x20], xmm9
000075d5269dd93d  lea rdi, [rsp]
000075d5269dd941  mov esi, 0x00
000075d5269dd946  mov rax, 0x601129E62530
000075d5269dd950  call rax
000075d5269dd952  movaps xmm7, [rsp]
000075d5269dd956  add rsp, 0x30
000075d5269dd95a  vmovaps xmm0, [rsp]
000075d5269dd95f  vmovaps xmm1, [rsp+0x10]
000075d5269dd965  vmovaps xmm2, [rsp+0x20]
000075d5269dd96b  vmovaps xmm3, [rsp+0x30]
000075d5269dd971  vmovaps xmm4, [rsp+0x40]
000075d5269dd977  vmovaps xmm5, [rsp+0x50]
000075d5269dd97d  vmovaps xmm6, [rsp+0x60]
000075d5269dd983  vmovaps xmm8, [rsp+0x70]
000075d5269dd989  vmovaps xmm9, [rsp+0x80]
000075d5269dd992  vmovaps xmm10, [rsp+0x90]
000075d5269dd99b  vmovaps xmm11, [rsp+0xA0]
000075d5269dd9a4  vmovaps xmm12, [rsp+0xB0]
000075d5269dd9ad  vmovaps xmm13, [rsp+0xC0]
000075d5269dd9b6  vmovaps xmm14, [rsp+0xD0]
000075d5269dd9bf  vmovaps xmm15, [rsp+0xE0]
000075d5269dd9c8  add rsp, 0xF0
000075d5269dd9cf  pop r11
000075d5269dd9d1  pop r10
000075d5269dd9d3  pop r9
000075d5269dd9d5  pop r8
000075d5269dd9d7  pop rsi
000075d5269dd9d8  pop rdi
000075d5269dd9d9  pop rdx
000075d5269dd9da  pop rcx
000075d5269dd9db  pop rax
000075d5269dd9dc  add rsp, 0x08
000075d5269dd9e0  jmp 0x000075D5269DBE87
000075d5269dd9e5  sub rsp, 0x08
000075d5269dd9e9  push rax
000075d5269dd9ea  push rcx
000075d5269dd9eb  push rdx
000075d5269dd9ec  push rdi
000075d5269dd9ed  push rsi
000075d5269dd9ee  push r8
000075d5269dd9f0  push r9
000075d5269dd9f2  push r10
000075d5269dd9f4  push r11
000075d5269dd9f6  sub rsp, 0xF0
000075d5269dd9fd  vmovaps [rsp], xmm0
000075d5269dda02  vmovaps [rsp+0x10], xmm1
000075d5269dda08  vmovaps [rsp+0x20], xmm2
000075d5269dda0e  vmovaps [rsp+0x30], xmm3
000075d5269dda14  vmovaps [rsp+0x40], xmm5
000075d5269dda1a  vmovaps [rsp+0x50], xmm6
000075d5269dda20  vmovaps [rsp+0x60], xmm7
000075d5269dda26  vmovaps [rsp+0x70], xmm8
000075d5269dda2c  vmovaps [rsp+0x80], xmm9
000075d5269dda35  vmovaps [rsp+0x90], xmm10
000075d5269dda3e  vmovaps [rsp+0xA0], xmm11
000075d5269dda47  vmovaps [rsp+0xB0], xmm12
000075d5269dda50  vmovaps [rsp+0xC0], xmm13
000075d5269dda59  vmovaps [rsp+0xD0], xmm14
000075d5269dda62  vmovaps [rsp+0xE0], xmm15
000075d5269dda6b  sub rsp, 0x30
000075d5269dda6f  movaps [rsp], xmm4
000075d5269dda73  movaps [rsp+0x10], xmm15
000075d5269dda79  movaps [rsp+0x20], xmm9
000075d5269dda7f  lea rdi, [rsp]
000075d5269dda83  mov esi, 0x00
000075d5269dda88  mov rax, 0x601129E62530
000075d5269dda92  call rax
000075d5269dda94  movaps xmm4, [rsp]
000075d5269dda98  add rsp, 0x30
000075d5269dda9c  vmovaps xmm0, [rsp]
000075d5269ddaa1  vmovaps xmm1, [rsp+0x10]
000075d5269ddaa7  vmovaps xmm2, [rsp+0x20]
000075d5269ddaad  vmovaps xmm3, [rsp+0x30]
000075d5269ddab3  vmovaps xmm5, [rsp+0x40]
000075d5269ddab9  vmovaps xmm6, [rsp+0x50]
000075d5269ddabf  vmovaps xmm7, [rsp+0x60]
000075d5269ddac5  vmovaps xmm8, [rsp+0x70]
000075d5269ddacb  vmovaps xmm9, [rsp+0x80]
000075d5269ddad4  vmovaps xmm10, [rsp+0x90]
000075d5269ddadd  vmovaps xmm11, [rsp+0xA0]
000075d5269ddae6  vmovaps xmm12, [rsp+0xB0]
000075d5269ddaef  vmovaps xmm13, [rsp+0xC0]
000075d5269ddaf8  vmovaps xmm14, [rsp+0xD0]
000075d5269ddb01  vmovaps xmm15, [rsp+0xE0]
000075d5269ddb0a  add rsp, 0xF0
000075d5269ddb11  pop r11
000075d5269ddb13  pop r10
000075d5269ddb15  pop r9
000075d5269ddb17  pop r8
000075d5269ddb19  pop rsi
000075d5269ddb1a  pop rdi
000075d5269ddb1b  pop rdx
000075d5269ddb1c  pop rcx
000075d5269ddb1d  pop rax
000075d5269ddb1e  add rsp, 0x08
000075d5269ddb22  jmp 0x000075D5269DBEAC
000075d5269ddb27  call 0x000075D5268C4620
000075d5269ddb2c  jmp 0x000075D5269DBEB9
000075d5269ddb31  sub rsp, 0x08
000075d5269ddb35  push rax
000075d5269ddb36  push rcx
000075d5269ddb37  push rdx
000075d5269ddb38  push rdi
000075d5269ddb39  push rsi
000075d5269ddb3a  push r8
000075d5269ddb3c  push r9
000075d5269ddb3e  push r10
000075d5269ddb40  push r11
000075d5269ddb42  sub rsp, 0xF0
000075d5269ddb49  vmovaps [rsp], xmm0
000075d5269ddb4e  vmovaps [rsp+0x10], xmm1
000075d5269ddb54  vmovaps [rsp+0x20], xmm2
000075d5269ddb5a  vmovaps [rsp+0x30], xmm4
000075d5269ddb60  vmovaps [rsp+0x40], xmm5
000075d5269ddb66  vmovaps [rsp+0x50], xmm6
000075d5269ddb6c  vmovaps [rsp+0x60], xmm7
000075d5269ddb72  vmovaps [rsp+0x70], xmm8
000075d5269ddb78  vmovaps [rsp+0x80], xmm9
000075d5269ddb81  vmovaps [rsp+0x90], xmm10
000075d5269ddb8a  vmovaps [rsp+0xA0], xmm11
000075d5269ddb93  vmovaps [rsp+0xB0], xmm12
000075d5269ddb9c  vmovaps [rsp+0xC0], xmm13
000075d5269ddba5  vmovaps [rsp+0xD0], xmm14
000075d5269ddbae  vmovaps [rsp+0xE0], xmm15
000075d5269ddbb7  sub rsp, 0x30
000075d5269ddbbb  movaps [rsp], xmm3
000075d5269ddbbf  movaps [rsp+0x10], xmm1
000075d5269ddbc4  movaps [rsp+0x20], xmm9
000075d5269ddbca  lea rdi, [rsp]
000075d5269ddbce  mov esi, 0x00
000075d5269ddbd3  mov rax, 0x601129E62530
000075d5269ddbdd  call rax
000075d5269ddbdf  movaps xmm3, [rsp]
000075d5269ddbe3  add rsp, 0x30
000075d5269ddbe7  vmovaps xmm0, [rsp]
000075d5269ddbec  vmovaps xmm1, [rsp+0x10]
000075d5269ddbf2  vmovaps xmm2, [rsp+0x20]
000075d5269ddbf8  vmovaps xmm4, [rsp+0x30]
000075d5269ddbfe  vmovaps xmm5, [rsp+0x40]
000075d5269ddc04  vmovaps xmm6, [rsp+0x50]
000075d5269ddc0a  vmovaps xmm7, [rsp+0x60]
000075d5269ddc10  vmovaps xmm8, [rsp+0x70]
000075d5269ddc16  vmovaps xmm9, [rsp+0x80]
000075d5269ddc1f  vmovaps xmm10, [rsp+0x90]
000075d5269ddc28  vmovaps xmm11, [rsp+0xA0]
000075d5269ddc31  vmovaps xmm12, [rsp+0xB0]
000075d5269ddc3a  vmovaps xmm13, [rsp+0xC0]
000075d5269ddc43  vmovaps xmm14, [rsp+0xD0]
000075d5269ddc4c  vmovaps xmm15, [rsp+0xE0]
000075d5269ddc55  add rsp, 0xF0
000075d5269ddc5c  pop r11
000075d5269ddc5e  pop r10
000075d5269ddc60  pop r9
000075d5269ddc62  pop r8
000075d5269ddc64  pop rsi
000075d5269ddc65  pop rdi
000075d5269ddc66  pop rdx
000075d5269ddc67  pop rcx
000075d5269ddc68  pop rax
000075d5269ddc69  add rsp, 0x08
000075d5269ddc6d  jmp 0x000075D5269DBEF6
000075d5269ddc72  sub rsp, 0x08
000075d5269ddc76  push rax
000075d5269ddc77  push rcx
000075d5269ddc78  push rdx
000075d5269ddc79  push rdi
000075d5269ddc7a  push rsi
000075d5269ddc7b  push r8
000075d5269ddc7d  push r9
000075d5269ddc7f  push r10
000075d5269ddc81  push r11
000075d5269ddc83  sub rsp, 0xF0
000075d5269ddc8a  vmovaps [rsp], xmm0
000075d5269ddc8f  vmovaps [rsp+0x10], xmm2
000075d5269ddc95  vmovaps [rsp+0x20], xmm3
000075d5269ddc9b  vmovaps [rsp+0x30], xmm4
000075d5269ddca1  vmovaps [rsp+0x40], xmm5
000075d5269ddca7  vmovaps [rsp+0x50], xmm6
000075d5269ddcad  vmovaps [rsp+0x60], xmm7
000075d5269ddcb3  vmovaps [rsp+0x70], xmm8
000075d5269ddcb9  vmovaps [rsp+0x80], xmm9
000075d5269ddcc2  vmovaps [rsp+0x90], xmm10
000075d5269ddccb  vmovaps [rsp+0xA0], xmm11
000075d5269ddcd4  vmovaps [rsp+0xB0], xmm12
000075d5269ddcdd  vmovaps [rsp+0xC0], xmm13
000075d5269ddce6  vmovaps [rsp+0xD0], xmm14
000075d5269ddcef  vmovaps [rsp+0xE0], xmm15
000075d5269ddcf8  sub rsp, 0x30
000075d5269ddcfc  movaps [rsp], xmm1
000075d5269ddd00  movaps [rsp+0x10], xmm15
000075d5269ddd06  movaps [rsp+0x20], xmm9
000075d5269ddd0c  lea rdi, [rsp]
000075d5269ddd10  mov esi, 0x00
000075d5269ddd15  mov rax, 0x601129E62530
000075d5269ddd1f  call rax
000075d5269ddd21  movaps xmm1, [rsp]
000075d5269ddd25  add rsp, 0x30
000075d5269ddd29  vmovaps xmm0, [rsp]
000075d5269ddd2e  vmovaps xmm2, [rsp+0x10]
000075d5269ddd34  vmovaps xmm3, [rsp+0x20]
000075d5269ddd3a  vmovaps xmm4, [rsp+0x30]
000075d5269ddd40  vmovaps xmm5, [rsp+0x40]
000075d5269ddd46  vmovaps xmm6, [rsp+0x50]
000075d5269ddd4c  vmovaps xmm7, [rsp+0x60]
000075d5269ddd52  vmovaps xmm8, [rsp+0x70]
000075d5269ddd58  vmovaps xmm9, [rsp+0x80]
000075d5269ddd61  vmovaps xmm10, [rsp+0x90]
000075d5269ddd6a  vmovaps xmm11, [rsp+0xA0]
000075d5269ddd73  vmovaps xmm12, [rsp+0xB0]
000075d5269ddd7c  vmovaps xmm13, [rsp+0xC0]
000075d5269ddd85  vmovaps xmm14, [rsp+0xD0]
000075d5269ddd8e  vmovaps xmm15, [rsp+0xE0]
000075d5269ddd97  add rsp, 0xF0
000075d5269ddd9e  pop r11
000075d5269ddda0  pop r10
000075d5269ddda2  pop r9
000075d5269ddda4  pop r8
000075d5269ddda6  pop rsi
000075d5269ddda7  pop rdi
000075d5269ddda8  pop rdx
000075d5269ddda9  pop rcx
000075d5269dddaa  pop rax
000075d5269dddab  add rsp, 0x08
000075d5269dddaf  jmp 0x000075D5269DBF7E
000075d5269dddb4  call 0x000075D5268C4620
000075d5269dddb9  jmp 0x000075D5269DBF8B
000075d5269dddbe  sub rsp, 0x08
000075d5269dddc2  push rax
000075d5269dddc3  push rcx
000075d5269dddc4  push rdx
000075d5269dddc5  push rdi
000075d5269dddc6  push rsi
000075d5269dddc7  push r8
000075d5269dddc9  push r9
000075d5269dddcb  push r10
000075d5269dddcd  push r11
000075d5269dddcf  sub rsp, 0xF0
000075d5269dddd6  vmovaps [rsp], xmm0
000075d5269ddddb  vmovaps [rsp+0x10], xmm2
000075d5269ddde1  vmovaps [rsp+0x20], xmm3
000075d5269ddde7  vmovaps [rsp+0x30], xmm4
000075d5269ddded  vmovaps [rsp+0x40], xmm5
000075d5269dddf3  vmovaps [rsp+0x50], xmm6
000075d5269dddf9  vmovaps [rsp+0x60], xmm7
000075d5269dddff  vmovaps [rsp+0x70], xmm8
000075d5269dde05  vmovaps [rsp+0x80], xmm9
000075d5269dde0e  vmovaps [rsp+0x90], xmm10
000075d5269dde17  vmovaps [rsp+0xA0], xmm11
000075d5269dde20  vmovaps [rsp+0xB0], xmm12
000075d5269dde29  vmovaps [rsp+0xC0], xmm13
000075d5269dde32  vmovaps [rsp+0xD0], xmm14
000075d5269dde3b  vmovaps [rsp+0xE0], xmm15
000075d5269dde44  sub rsp, 0x30
000075d5269dde48  movaps [rsp], xmm1
000075d5269dde4c  movaps [rsp+0x10], xmm5
000075d5269dde51  movaps [rsp+0x20], xmm7
000075d5269dde56  lea rdi, [rsp]
000075d5269dde5a  mov esi, 0x00
000075d5269dde5f  mov rax, 0x601129E62530
000075d5269dde69  call rax
000075d5269dde6b  movaps xmm1, [rsp]
000075d5269dde6f  add rsp, 0x30
000075d5269dde73  vmovaps xmm0, [rsp]
000075d5269dde78  vmovaps xmm2, [rsp+0x10]
000075d5269dde7e  vmovaps xmm3, [rsp+0x20]
000075d5269dde84  vmovaps xmm4, [rsp+0x30]
000075d5269dde8a  vmovaps xmm5, [rsp+0x40]
000075d5269dde90  vmovaps xmm6, [rsp+0x50]
000075d5269dde96  vmovaps xmm7, [rsp+0x60]
000075d5269dde9c  vmovaps xmm8, [rsp+0x70]
000075d5269ddea2  vmovaps xmm9, [rsp+0x80]
000075d5269ddeab  vmovaps xmm10, [rsp+0x90]
000075d5269ddeb4  vmovaps xmm11, [rsp+0xA0]
000075d5269ddebd  vmovaps xmm12, [rsp+0xB0]
000075d5269ddec6  vmovaps xmm13, [rsp+0xC0]
000075d5269ddecf  vmovaps xmm14, [rsp+0xD0]
000075d5269dded8  vmovaps xmm15, [rsp+0xE0]
000075d5269ddee1  add rsp, 0xF0
000075d5269ddee8  pop r11
000075d5269ddeea  pop r10
000075d5269ddeec  pop r9
000075d5269ddeee  pop r8
000075d5269ddef0  pop rsi
000075d5269ddef1  pop rdi
000075d5269ddef2  pop rdx
000075d5269ddef3  pop rcx
000075d5269ddef4  pop rax
000075d5269ddef5  add rsp, 0x08
000075d5269ddef9  jmp 0x000075D5269DC030
000075d5269ddefe  sub rsp, 0x08
000075d5269ddf02  push rax
000075d5269ddf03  push rcx
000075d5269ddf04  push rdx
000075d5269ddf05  push rdi
000075d5269ddf06  push rsi
000075d5269ddf07  push r8
000075d5269ddf09  push r9
000075d5269ddf0b  push r10
000075d5269ddf0d  push r11
000075d5269ddf0f  sub rsp, 0xF0
000075d5269ddf16  vmovaps [rsp], xmm0
000075d5269ddf1b  vmovaps [rsp+0x10], xmm1
000075d5269ddf21  vmovaps [rsp+0x20], xmm2
000075d5269ddf27  vmovaps [rsp+0x30], xmm3
000075d5269ddf2d  vmovaps [rsp+0x40], xmm4
000075d5269ddf33  vmovaps [rsp+0x50], xmm5
000075d5269ddf39  vmovaps [rsp+0x60], xmm6
000075d5269ddf3f  vmovaps [rsp+0x70], xmm8
000075d5269ddf45  vmovaps [rsp+0x80], xmm9
000075d5269ddf4e  vmovaps [rsp+0x90], xmm10
000075d5269ddf57  vmovaps [rsp+0xA0], xmm11
000075d5269ddf60  vmovaps [rsp+0xB0], xmm12
000075d5269ddf69  vmovaps [rsp+0xC0], xmm13
000075d5269ddf72  vmovaps [rsp+0xD0], xmm14
000075d5269ddf7b  vmovaps [rsp+0xE0], xmm15
000075d5269ddf84  sub rsp, 0x30
000075d5269ddf88  movaps [rsp], xmm7
000075d5269ddf8c  movaps [rsp+0x10], xmm5
000075d5269ddf91  movaps [rsp+0x20], xmm15
000075d5269ddf97  lea rdi, [rsp]
000075d5269ddf9b  mov esi, 0x00
000075d5269ddfa0  mov rax, 0x601129E62530
000075d5269ddfaa  call rax
000075d5269ddfac  movaps xmm7, [rsp]
000075d5269ddfb0  add rsp, 0x30
000075d5269ddfb4  vmovaps xmm0, [rsp]
000075d5269ddfb9  vmovaps xmm1, [rsp+0x10]
000075d5269ddfbf  vmovaps xmm2, [rsp+0x20]
000075d5269ddfc5  vmovaps xmm3, [rsp+0x30]
000075d5269ddfcb  vmovaps xmm4, [rsp+0x40]
000075d5269ddfd1  vmovaps xmm5, [rsp+0x50]
000075d5269ddfd7  vmovaps xmm6, [rsp+0x60]
000075d5269ddfdd  vmovaps xmm8, [rsp+0x70]
000075d5269ddfe3  vmovaps xmm9, [rsp+0x80]
000075d5269ddfec  vmovaps xmm10, [rsp+0x90]
000075d5269ddff5  vmovaps xmm11, [rsp+0xA0]
000075d5269ddffe  vmovaps xmm12, [rsp+0xB0]
000075d5269de007  vmovaps xmm13, [rsp+0xC0]
000075d5269de010  vmovaps xmm14, [rsp+0xD0]
000075d5269de019  vmovaps xmm15, [rsp+0xE0]
000075d5269de022  add rsp, 0xF0
000075d5269de029  pop r11
000075d5269de02b  pop r10
000075d5269de02d  pop r9
000075d5269de02f  pop r8
000075d5269de031  pop rsi
000075d5269de032  pop rdi
000075d5269de033  pop rdx
000075d5269de034  pop rcx
000075d5269de035  pop rax
000075d5269de036  add rsp, 0x08
000075d5269de03a  jmp 0x000075D5269DC066
000075d5269de03f  call 0x000075D5268B52F0
000075d5269de044  jmp 0x000075D5269DC073
000075d5269de049  sub rsp, 0x08
000075d5269de04d  push rax
000075d5269de04e  push rcx
000075d5269de04f  push rdx
000075d5269de050  push rdi
000075d5269de051  push rsi
000075d5269de052  push r8
000075d5269de054  push r9
000075d5269de056  push r10
000075d5269de058  push r11
000075d5269de05a  sub rsp, 0xF0
000075d5269de061  vmovaps [rsp], xmm0
000075d5269de066  vmovaps [rsp+0x10], xmm1
000075d5269de06c  vmovaps [rsp+0x20], xmm2
000075d5269de072  vmovaps [rsp+0x30], xmm3
000075d5269de078  vmovaps [rsp+0x40], xmm4
000075d5269de07e  vmovaps [rsp+0x50], xmm5
000075d5269de084  vmovaps [rsp+0x60], xmm6
000075d5269de08a  vmovaps [rsp+0x70], xmm7
000075d5269de090  vmovaps [rsp+0x80], xmm8
000075d5269de099  vmovaps [rsp+0x90], xmm9
000075d5269de0a2  vmovaps [rsp+0xA0], xmm10
000075d5269de0ab  vmovaps [rsp+0xB0], xmm11
000075d5269de0b4  vmovaps [rsp+0xC0], xmm12
000075d5269de0bd  vmovaps [rsp+0xD0], xmm13
000075d5269de0c6  vmovaps [rsp+0xE0], xmm14
000075d5269de0cf  sub rsp, 0x30
000075d5269de0d3  movaps [rsp], xmm15
000075d5269de0d8  movaps [rsp+0x10], xmm5
000075d5269de0dd  movaps [rsp+0x20], xmm3
000075d5269de0e2  lea rdi, [rsp]
000075d5269de0e6  mov esi, 0x00
000075d5269de0eb  mov rax, 0x601129E62530
000075d5269de0f5  call rax
000075d5269de0f7  movaps xmm15, [rsp]
000075d5269de0fc  add rsp, 0x30
000075d5269de100  vmovaps xmm0, [rsp]
000075d5269de105  vmovaps xmm1, [rsp+0x10]
000075d5269de10b  vmovaps xmm2, [rsp+0x20]
000075d5269de111  vmovaps xmm3, [rsp+0x30]
000075d5269de117  vmovaps xmm4, [rsp+0x40]
000075d5269de11d  vmovaps xmm5, [rsp+0x50]
000075d5269de123  vmovaps xmm6, [rsp+0x60]
000075d5269de129  vmovaps xmm7, [rsp+0x70]
000075d5269de12f  vmovaps xmm8, [rsp+0x80]
000075d5269de138  vmovaps xmm9, [rsp+0x90]
000075d5269de141  vmovaps xmm10, [rsp+0xA0]
000075d5269de14a  vmovaps xmm11, [rsp+0xB0]
000075d5269de153  vmovaps xmm12, [rsp+0xC0]
000075d5269de15c  vmovaps xmm13, [rsp+0xD0]
000075d5269de165  vmovaps xmm14, [rsp+0xE0]
000075d5269de16e  add rsp, 0xF0
000075d5269de175  pop r11
000075d5269de177  pop r10
000075d5269de179  pop r9
000075d5269de17b  pop r8
000075d5269de17d  pop rsi
000075d5269de17e  pop rdi
000075d5269de17f  pop rdx
000075d5269de180  pop rcx
000075d5269de181  pop rax
000075d5269de182  add rsp, 0x08
000075d5269de186  jmp 0x000075D5269DC099
000075d5269de18b  sub rsp, 0x08
000075d5269de18f  push rax
000075d5269de190  push rcx
000075d5269de191  push rdx
000075d5269de192  push rdi
000075d5269de193  push rsi
000075d5269de194  push r8
000075d5269de196  push r9
000075d5269de198  push r10
000075d5269de19a  push r11
000075d5269de19c  sub rsp, 0xF0
000075d5269de1a3  vmovaps [rsp], xmm0
000075d5269de1a8  vmovaps [rsp+0x10], xmm2
000075d5269de1ae  vmovaps [rsp+0x20], xmm3
000075d5269de1b4  vmovaps [rsp+0x30], xmm4
000075d5269de1ba  vmovaps [rsp+0x40], xmm5
000075d5269de1c0  vmovaps [rsp+0x50], xmm6
000075d5269de1c6  vmovaps [rsp+0x60], xmm7
000075d5269de1cc  vmovaps [rsp+0x70], xmm8
000075d5269de1d2  vmovaps [rsp+0x80], xmm9
000075d5269de1db  vmovaps [rsp+0x90], xmm10
000075d5269de1e4  vmovaps [rsp+0xA0], xmm11
000075d5269de1ed  vmovaps [rsp+0xB0], xmm12
000075d5269de1f6  vmovaps [rsp+0xC0], xmm13
000075d5269de1ff  vmovaps [rsp+0xD0], xmm14
000075d5269de208  vmovaps [rsp+0xE0], xmm15
000075d5269de211  sub rsp, 0x30
000075d5269de215  movaps [rsp], xmm1
000075d5269de219  movaps [rsp+0x10], xmm5
000075d5269de21e  movaps [rsp+0x20], xmm4
000075d5269de223  lea rdi, [rsp]
000075d5269de227  mov esi, 0x00
000075d5269de22c  mov rax, 0x601129E62530
000075d5269de236  call rax
000075d5269de238  movaps xmm1, [rsp]
000075d5269de23c  add rsp, 0x30
000075d5269de240  vmovaps xmm0, [rsp]
000075d5269de245  vmovaps xmm2, [rsp+0x10]
000075d5269de24b  vmovaps xmm3, [rsp+0x20]
000075d5269de251  vmovaps xmm4, [rsp+0x30]
000075d5269de257  vmovaps xmm5, [rsp+0x40]
000075d5269de25d  vmovaps xmm6, [rsp+0x50]
000075d5269de263  vmovaps xmm7, [rsp+0x60]
000075d5269de269  vmovaps xmm8, [rsp+0x70]
000075d5269de26f  vmovaps xmm9, [rsp+0x80]
000075d5269de278  vmovaps xmm10, [rsp+0x90]
000075d5269de281  vmovaps xmm11, [rsp+0xA0]
000075d5269de28a  vmovaps xmm12, [rsp+0xB0]
000075d5269de293  vmovaps xmm13, [rsp+0xC0]
000075d5269de29c  vmovaps xmm14, [rsp+0xD0]
000075d5269de2a5  vmovaps xmm15, [rsp+0xE0]
000075d5269de2ae  add rsp, 0xF0
000075d5269de2b5  pop r11
000075d5269de2b7  pop r10
000075d5269de2b9  pop r9
000075d5269de2bb  pop r8
000075d5269de2bd  pop rsi
000075d5269de2be  pop rdi
000075d5269de2bf  pop rdx
000075d5269de2c0  pop rcx
000075d5269de2c1  pop rax
000075d5269de2c2  add rsp, 0x08
000075d5269de2c6  jmp 0x000075D5269DC0B9
000075d5269de2cb  sub rsp, 0x08
000075d5269de2cf  push rax
000075d5269de2d0  push rcx
000075d5269de2d1  push rdx
000075d5269de2d2  push rdi
000075d5269de2d3  push rsi
000075d5269de2d4  push r8
000075d5269de2d6  push r9
000075d5269de2d8  push r10
000075d5269de2da  push r11
000075d5269de2dc  sub rsp, 0xF0
000075d5269de2e3  vmovaps [rsp], xmm0
000075d5269de2e8  vmovaps [rsp+0x10], xmm1
000075d5269de2ee  vmovaps [rsp+0x20], xmm2
000075d5269de2f4  vmovaps [rsp+0x30], xmm3
000075d5269de2fa  vmovaps [rsp+0x40], xmm5
000075d5269de300  vmovaps [rsp+0x50], xmm6
000075d5269de306  vmovaps [rsp+0x60], xmm7
000075d5269de30c  vmovaps [rsp+0x70], xmm8
000075d5269de312  vmovaps [rsp+0x80], xmm9
000075d5269de31b  vmovaps [rsp+0x90], xmm10
000075d5269de324  vmovaps [rsp+0xA0], xmm11
000075d5269de32d  vmovaps [rsp+0xB0], xmm12
000075d5269de336  vmovaps [rsp+0xC0], xmm13
000075d5269de33f  vmovaps [rsp+0xD0], xmm14
000075d5269de348  vmovaps [rsp+0xE0], xmm15
000075d5269de351  sub rsp, 0x30
000075d5269de355  movaps [rsp], xmm4
000075d5269de359  movaps [rsp+0x10], xmm3
000075d5269de35e  movaps [rsp+0x20], xmm5
000075d5269de363  lea rdi, [rsp]
000075d5269de367  mov esi, 0x00
000075d5269de36c  mov rax, 0x601129E62530
000075d5269de376  call rax
000075d5269de378  movaps xmm4, [rsp]
000075d5269de37c  add rsp, 0x30
000075d5269de380  vmovaps xmm0, [rsp]
000075d5269de385  vmovaps xmm1, [rsp+0x10]
000075d5269de38b  vmovaps xmm2, [rsp+0x20]
000075d5269de391  vmovaps xmm3, [rsp+0x30]
000075d5269de397  vmovaps xmm5, [rsp+0x40]
000075d5269de39d  vmovaps xmm6, [rsp+0x50]
000075d5269de3a3  vmovaps xmm7, [rsp+0x60]
000075d5269de3a9  vmovaps xmm8, [rsp+0x70]
000075d5269de3af  vmovaps xmm9, [rsp+0x80]
000075d5269de3b8  vmovaps xmm10, [rsp+0x90]
000075d5269de3c1  vmovaps xmm11, [rsp+0xA0]
000075d5269de3ca  vmovaps xmm12, [rsp+0xB0]
000075d5269de3d3  vmovaps xmm13, [rsp+0xC0]
000075d5269de3dc  vmovaps xmm14, [rsp+0xD0]
000075d5269de3e5  vmovaps xmm15, [rsp+0xE0]
000075d5269de3ee  add rsp, 0xF0
000075d5269de3f5  pop r11
000075d5269de3f7  pop r10
000075d5269de3f9  pop r9
000075d5269de3fb  pop r8
000075d5269de3fd  pop rsi
000075d5269de3fe  pop rdi
000075d5269de3ff  pop rdx
000075d5269de400  pop rcx
000075d5269de401  pop rax
000075d5269de402  add rsp, 0x08
000075d5269de406  jmp 0x000075D5269DC107
000075d5269de40b  call 0x000075D5268B52F0
000075d5269de410  jmp 0x000075D5269DC114
000075d5269de415  sub rsp, 0x08
000075d5269de419  push rax
000075d5269de41a  push rcx
000075d5269de41b  push rdx
000075d5269de41c  push rdi
000075d5269de41d  push rsi
000075d5269de41e  push r8
000075d5269de420  push r9
000075d5269de422  push r10
000075d5269de424  push r11
000075d5269de426  sub rsp, 0xF0
000075d5269de42d  vmovaps [rsp], xmm0
000075d5269de432  vmovaps [rsp+0x10], xmm1
000075d5269de438  vmovaps [rsp+0x20], xmm2
000075d5269de43e  vmovaps [rsp+0x30], xmm3
000075d5269de444  vmovaps [rsp+0x40], xmm4
000075d5269de44a  vmovaps [rsp+0x50], xmm6
000075d5269de450  vmovaps [rsp+0x60], xmm7
000075d5269de456  vmovaps [rsp+0x70], xmm8
000075d5269de45c  vmovaps [rsp+0x80], xmm9
000075d5269de465  vmovaps [rsp+0x90], xmm10
000075d5269de46e  vmovaps [rsp+0xA0], xmm11
000075d5269de477  vmovaps [rsp+0xB0], xmm12
000075d5269de480  vmovaps [rsp+0xC0], xmm13
000075d5269de489  vmovaps [rsp+0xD0], xmm14
000075d5269de492  vmovaps [rsp+0xE0], xmm15
000075d5269de49b  sub rsp, 0x30
000075d5269de49f  movaps [rsp], xmm5
000075d5269de4a3  movaps [rsp+0x10], xmm6
000075d5269de4a8  movaps [rsp+0x20], xmm3
000075d5269de4ad  lea rdi, [rsp]
000075d5269de4b1  mov esi, 0x00
000075d5269de4b6  mov rax, 0x601129E62530
000075d5269de4c0  call rax
000075d5269de4c2  movaps xmm5, [rsp]
000075d5269de4c6  add rsp, 0x30
000075d5269de4ca  vmovaps xmm0, [rsp]
000075d5269de4cf  vmovaps xmm1, [rsp+0x10]
000075d5269de4d5  vmovaps xmm2, [rsp+0x20]
000075d5269de4db  vmovaps xmm3, [rsp+0x30]
000075d5269de4e1  vmovaps xmm4, [rsp+0x40]
000075d5269de4e7  vmovaps xmm6, [rsp+0x50]
000075d5269de4ed  vmovaps xmm7, [rsp+0x60]
000075d5269de4f3  vmovaps xmm8, [rsp+0x70]
000075d5269de4f9  vmovaps xmm9, [rsp+0x80]
000075d5269de502  vmovaps xmm10, [rsp+0x90]
000075d5269de50b  vmovaps xmm11, [rsp+0xA0]
000075d5269de514  vmovaps xmm12, [rsp+0xB0]
000075d5269de51d  vmovaps xmm13, [rsp+0xC0]
000075d5269de526  vmovaps xmm14, [rsp+0xD0]
000075d5269de52f  vmovaps xmm15, [rsp+0xE0]
000075d5269de538  add rsp, 0xF0
000075d5269de53f  pop r11
000075d5269de541  pop r10
000075d5269de543  pop r9
000075d5269de545  pop r8
000075d5269de547  pop rsi
000075d5269de548  pop rdi
000075d5269de549  pop rdx
000075d5269de54a  pop rcx
000075d5269de54b  pop rax
000075d5269de54c  add rsp, 0x08
000075d5269de550  jmp 0x000075D5269DC13A
000075d5269de555  sub rsp, 0x08
000075d5269de559  push rax
000075d5269de55a  push rcx
000075d5269de55b  push rdx
000075d5269de55c  push rdi
000075d5269de55d  push rsi
000075d5269de55e  push r8
000075d5269de560  push r9
000075d5269de562  push r10
000075d5269de564  push r11
000075d5269de566  sub rsp, 0xF0
000075d5269de56d  vmovaps [rsp], xmm0
000075d5269de572  vmovaps [rsp+0x10], xmm1
000075d5269de578  vmovaps [rsp+0x20], xmm2
000075d5269de57e  vmovaps [rsp+0x30], xmm3
000075d5269de584  vmovaps [rsp+0x40], xmm4
000075d5269de58a  vmovaps [rsp+0x50], xmm5
000075d5269de590  vmovaps [rsp+0x60], xmm7
000075d5269de596  vmovaps [rsp+0x70], xmm8
000075d5269de59c  vmovaps [rsp+0x80], xmm9
000075d5269de5a5  vmovaps [rsp+0x90], xmm10
000075d5269de5ae  vmovaps [rsp+0xA0], xmm11
000075d5269de5b7  vmovaps [rsp+0xB0], xmm12
000075d5269de5c0  vmovaps [rsp+0xC0], xmm13
000075d5269de5c9  vmovaps [rsp+0xD0], xmm14
000075d5269de5d2  vmovaps [rsp+0xE0], xmm15
000075d5269de5db  sub rsp, 0x30
000075d5269de5df  movaps [rsp], xmm6
000075d5269de5e3  movaps [rsp+0x10], xmm9
000075d5269de5e9  movaps [rsp+0x20], xmm1
000075d5269de5ee  lea rdi, [rsp]
000075d5269de5f2  mov esi, 0x00
000075d5269de5f7  mov rax, 0x601129E62530
000075d5269de601  call rax
000075d5269de603  movaps xmm6, [rsp]
000075d5269de607  add rsp, 0x30
000075d5269de60b  vmovaps xmm0, [rsp]
000075d5269de610  vmovaps xmm1, [rsp+0x10]
000075d5269de616  vmovaps xmm2, [rsp+0x20]
000075d5269de61c  vmovaps xmm3, [rsp+0x30]
000075d5269de622  vmovaps xmm4, [rsp+0x40]
000075d5269de628  vmovaps xmm5, [rsp+0x50]
000075d5269de62e  vmovaps xmm7, [rsp+0x60]
000075d5269de634  vmovaps xmm8, [rsp+0x70]
000075d5269de63a  vmovaps xmm9, [rsp+0x80]
000075d5269de643  vmovaps xmm10, [rsp+0x90]
000075d5269de64c  vmovaps xmm11, [rsp+0xA0]
000075d5269de655  vmovaps xmm12, [rsp+0xB0]
000075d5269de65e  vmovaps xmm13, [rsp+0xC0]
000075d5269de667  vmovaps xmm14, [rsp+0xD0]
000075d5269de670  vmovaps xmm15, [rsp+0xE0]
000075d5269de679  add rsp, 0xF0
000075d5269de680  pop r11
000075d5269de682  pop r10
000075d5269de684  pop r9
000075d5269de686  pop r8
000075d5269de688  pop rsi
000075d5269de689  pop rdi
000075d5269de68a  pop rdx
000075d5269de68b  pop rcx
000075d5269de68c  pop rax
000075d5269de68d  add rsp, 0x08
000075d5269de691  jmp 0x000075D5269DC15E
000075d5269de696  sub rsp, 0x08
000075d5269de69a  push rax
000075d5269de69b  push rcx
000075d5269de69c  push rdx
000075d5269de69d  push rdi
000075d5269de69e  push rsi
000075d5269de69f  push r8
000075d5269de6a1  push r9
000075d5269de6a3  push r10
000075d5269de6a5  push r11
000075d5269de6a7  sub rsp, 0xF0
000075d5269de6ae  vmovaps [rsp], xmm0
000075d5269de6b3  vmovaps [rsp+0x10], xmm1
000075d5269de6b9  vmovaps [rsp+0x20], xmm2
000075d5269de6bf  vmovaps [rsp+0x30], xmm3
000075d5269de6c5  vmovaps [rsp+0x40], xmm4
000075d5269de6cb  vmovaps [rsp+0x50], xmm5
000075d5269de6d1  vmovaps [rsp+0x60], xmm6
000075d5269de6d7  vmovaps [rsp+0x70], xmm7
000075d5269de6dd  vmovaps [rsp+0x80], xmm8
000075d5269de6e6  vmovaps [rsp+0x90], xmm10
000075d5269de6ef  vmovaps [rsp+0xA0], xmm11
000075d5269de6f8  vmovaps [rsp+0xB0], xmm12
000075d5269de701  vmovaps [rsp+0xC0], xmm13
000075d5269de70a  vmovaps [rsp+0xD0], xmm14
000075d5269de713  vmovaps [rsp+0xE0], xmm15
000075d5269de71c  sub rsp, 0x30
000075d5269de720  movaps [rsp], xmm9
000075d5269de725  movaps [rsp+0x10], xmm3
000075d5269de72a  movaps [rsp+0x20], xmm1
000075d5269de72f  lea rdi, [rsp]
000075d5269de733  mov esi, 0x00
000075d5269de738  mov rax, 0x601129E62530
000075d5269de742  call rax
000075d5269de744  movaps xmm9, [rsp]
000075d5269de749  add rsp, 0x30
000075d5269de74d  vmovaps xmm0, [rsp]
000075d5269de752  vmovaps xmm1, [rsp+0x10]
000075d5269de758  vmovaps xmm2, [rsp+0x20]
000075d5269de75e  vmovaps xmm3, [rsp+0x30]
000075d5269de764  vmovaps xmm4, [rsp+0x40]
000075d5269de76a  vmovaps xmm5, [rsp+0x50]
000075d5269de770  vmovaps xmm6, [rsp+0x60]
000075d5269de776  vmovaps xmm7, [rsp+0x70]
000075d5269de77c  vmovaps xmm8, [rsp+0x80]
000075d5269de785  vmovaps xmm10, [rsp+0x90]
000075d5269de78e  vmovaps xmm11, [rsp+0xA0]
000075d5269de797  vmovaps xmm12, [rsp+0xB0]
000075d5269de7a0  vmovaps xmm13, [rsp+0xC0]
000075d5269de7a9  vmovaps xmm14, [rsp+0xD0]
000075d5269de7b2  vmovaps xmm15, [rsp+0xE0]
000075d5269de7bb  add rsp, 0xF0
000075d5269de7c2  pop r11
000075d5269de7c4  pop r10
000075d5269de7c6  pop r9
000075d5269de7c8  pop r8
000075d5269de7ca  pop rsi
000075d5269de7cb  pop rdi
000075d5269de7cc  pop rdx
000075d5269de7cd  pop rcx
000075d5269de7ce  pop rax
000075d5269de7cf  add rsp, 0x08
000075d5269de7d3  jmp 0x000075D5269DC1AA
000075d5269de7d8  call 0x000075D5268B52F0
000075d5269de7dd  jmp 0x000075D5269DC1B7
000075d5269de7e2  sub rsp, 0x08
000075d5269de7e6  push rax
000075d5269de7e7  push rcx
000075d5269de7e8  push rdx
000075d5269de7e9  push rdi
000075d5269de7ea  push rsi
000075d5269de7eb  push r8
000075d5269de7ed  push r9
000075d5269de7ef  push r10
000075d5269de7f1  push r11
000075d5269de7f3  sub rsp, 0xF0
000075d5269de7fa  vmovaps [rsp], xmm0
000075d5269de7ff  vmovaps [rsp+0x10], xmm1
000075d5269de805  vmovaps [rsp+0x20], xmm2
000075d5269de80b  vmovaps [rsp+0x30], xmm3
000075d5269de811  vmovaps [rsp+0x40], xmm4
000075d5269de817  vmovaps [rsp+0x50], xmm5
000075d5269de81d  vmovaps [rsp+0x60], xmm6
000075d5269de823  vmovaps [rsp+0x70], xmm7
000075d5269de829  vmovaps [rsp+0x80], xmm8
000075d5269de832  vmovaps [rsp+0x90], xmm9
000075d5269de83b  vmovaps [rsp+0xA0], xmm10
000075d5269de844  vmovaps [rsp+0xB0], xmm11
000075d5269de84d  vmovaps [rsp+0xC0], xmm12
000075d5269de856  vmovaps [rsp+0xD0], xmm13
000075d5269de85f  vmovaps [rsp+0xE0], xmm14
000075d5269de868  sub rsp, 0x30
000075d5269de86c  movaps [rsp], xmm15
000075d5269de871  movaps [rsp+0x10], xmm3
000075d5269de876  movaps [rsp+0x20], xmm7
000075d5269de87b  lea rdi, [rsp]
000075d5269de87f  mov esi, 0x00
000075d5269de884  mov rax, 0x601129E62530
000075d5269de88e  call rax
000075d5269de890  movaps xmm15, [rsp]
000075d5269de895  add rsp, 0x30
000075d5269de899  vmovaps xmm0, [rsp]
000075d5269de89e  vmovaps xmm1, [rsp+0x10]
000075d5269de8a4  vmovaps xmm2, [rsp+0x20]
000075d5269de8aa  vmovaps xmm3, [rsp+0x30]
000075d5269de8b0  vmovaps xmm4, [rsp+0x40]
000075d5269de8b6  vmovaps xmm5, [rsp+0x50]
000075d5269de8bc  vmovaps xmm6, [rsp+0x60]
000075d5269de8c2  vmovaps xmm7, [rsp+0x70]
000075d5269de8c8  vmovaps xmm8, [rsp+0x80]
000075d5269de8d1  vmovaps xmm9, [rsp+0x90]
000075d5269de8da  vmovaps xmm10, [rsp+0xA0]
000075d5269de8e3  vmovaps xmm11, [rsp+0xB0]
000075d5269de8ec  vmovaps xmm12, [rsp+0xC0]
000075d5269de8f5  vmovaps xmm13, [rsp+0xD0]
000075d5269de8fe  vmovaps xmm14, [rsp+0xE0]
000075d5269de907  add rsp, 0xF0
000075d5269de90e  pop r11
000075d5269de910  pop r10
000075d5269de912  pop r9
000075d5269de914  pop r8
000075d5269de916  pop rsi
000075d5269de917  pop rdi
000075d5269de918  pop rdx
000075d5269de919  pop rcx
000075d5269de91a  pop rax
000075d5269de91b  add rsp, 0x08
000075d5269de91f  jmp 0x000075D5269DC1E3
000075d5269de924  sub rsp, 0x08
000075d5269de928  push rax
000075d5269de929  push rcx
000075d5269de92a  push rdx
000075d5269de92b  push rdi
000075d5269de92c  push rsi
000075d5269de92d  push r8
000075d5269de92f  push r9
000075d5269de931  push r10
000075d5269de933  push r11
000075d5269de935  sub rsp, 0xF0
000075d5269de93c  vmovaps [rsp], xmm0
000075d5269de941  vmovaps [rsp+0x10], xmm1
000075d5269de947  vmovaps [rsp+0x20], xmm2
000075d5269de94d  vmovaps [rsp+0x30], xmm4
000075d5269de953  vmovaps [rsp+0x40], xmm5
000075d5269de959  vmovaps [rsp+0x50], xmm6
000075d5269de95f  vmovaps [rsp+0x60], xmm7
000075d5269de965  vmovaps [rsp+0x70], xmm8
000075d5269de96b  vmovaps [rsp+0x80], xmm9
000075d5269de974  vmovaps [rsp+0x90], xmm10
000075d5269de97d  vmovaps [rsp+0xA0], xmm11
000075d5269de986  vmovaps [rsp+0xB0], xmm12
000075d5269de98f  vmovaps [rsp+0xC0], xmm13
000075d5269de998  vmovaps [rsp+0xD0], xmm14
000075d5269de9a1  vmovaps [rsp+0xE0], xmm15
000075d5269de9aa  sub rsp, 0x30
000075d5269de9ae  movaps [rsp], xmm3
000075d5269de9b2  movaps [rsp+0x10], xmm1
000075d5269de9b7  movaps [rsp+0x20], xmm15
000075d5269de9bd  lea rdi, [rsp]
000075d5269de9c1  mov esi, 0x00
000075d5269de9c6  mov rax, 0x601129E62530
000075d5269de9d0  call rax
000075d5269de9d2  movaps xmm3, [rsp]
000075d5269de9d6  add rsp, 0x30
000075d5269de9da  vmovaps xmm0, [rsp]
000075d5269de9df  vmovaps xmm1, [rsp+0x10]
000075d5269de9e5  vmovaps xmm2, [rsp+0x20]
000075d5269de9eb  vmovaps xmm4, [rsp+0x30]
000075d5269de9f1  vmovaps xmm5, [rsp+0x40]
000075d5269de9f7  vmovaps xmm6, [rsp+0x50]
000075d5269de9fd  vmovaps xmm7, [rsp+0x60]
000075d5269dea03  vmovaps xmm8, [rsp+0x70]
000075d5269dea09  vmovaps xmm9, [rsp+0x80]
000075d5269dea12  vmovaps xmm10, [rsp+0x90]
000075d5269dea1b  vmovaps xmm11, [rsp+0xA0]
000075d5269dea24  vmovaps xmm12, [rsp+0xB0]
000075d5269dea2d  vmovaps xmm13, [rsp+0xC0]
000075d5269dea36  vmovaps xmm14, [rsp+0xD0]
000075d5269dea3f  vmovaps xmm15, [rsp+0xE0]
000075d5269dea48  add rsp, 0xF0
000075d5269dea4f  pop r11
000075d5269dea51  pop r10
000075d5269dea53  pop r9
000075d5269dea55  pop r8
000075d5269dea57  pop rsi
000075d5269dea58  pop rdi
000075d5269dea59  pop rdx
000075d5269dea5a  pop rcx
000075d5269dea5b  pop rax
000075d5269dea5c  add rsp, 0x08
000075d5269dea60  jmp 0x000075D5269DC272
000075d5269dea65  call 0x000075D5268B52F0
000075d5269dea6a  jmp 0x000075D5269DC27C
000075d5269dea6f  sub rsp, 0x08
000075d5269dea73  push rax
000075d5269dea74  push rcx
000075d5269dea75  push rdx
000075d5269dea76  push rdi
000075d5269dea77  push rsi
000075d5269dea78  push r8
000075d5269dea7a  push r9
000075d5269dea7c  push r10
000075d5269dea7e  push r11
000075d5269dea80  sub rsp, 0xF0
000075d5269dea87  vmovaps [rsp], xmm0
000075d5269dea8c  vmovaps [rsp+0x10], xmm1
000075d5269dea92  vmovaps [rsp+0x20], xmm2
000075d5269dea98  vmovaps [rsp+0x30], xmm3
000075d5269dea9e  vmovaps [rsp+0x40], xmm4
000075d5269deaa4  vmovaps [rsp+0x50], xmm5
000075d5269deaaa  vmovaps [rsp+0x60], xmm6
000075d5269deab0  vmovaps [rsp+0x70], xmm7
000075d5269deab6  vmovaps [rsp+0x80], xmm8
000075d5269deabf  vmovaps [rsp+0x90], xmm9
000075d5269deac8  vmovaps [rsp+0xA0], xmm10
000075d5269dead1  vmovaps [rsp+0xB0], xmm11
000075d5269deada  vmovaps [rsp+0xC0], xmm12
000075d5269deae3  vmovaps [rsp+0xD0], xmm13
000075d5269deaec  vmovaps [rsp+0xE0], xmm14
000075d5269deaf5  sub rsp, 0x30
000075d5269deaf9  movaps [rsp], xmm15
000075d5269deafe  movaps [rsp+0x10], xmm14
000075d5269deb04  movaps [rsp+0x20], xmm4
000075d5269deb09  lea rdi, [rsp]
000075d5269deb0d  mov esi, 0x00
000075d5269deb12  mov rax, 0x601129E62530
000075d5269deb1c  call rax
000075d5269deb1e  movaps xmm15, [rsp]
000075d5269deb23  add rsp, 0x30
000075d5269deb27  vmovaps xmm0, [rsp]
000075d5269deb2c  vmovaps xmm1, [rsp+0x10]
000075d5269deb32  vmovaps xmm2, [rsp+0x20]
000075d5269deb38  vmovaps xmm3, [rsp+0x30]
000075d5269deb3e  vmovaps xmm4, [rsp+0x40]
000075d5269deb44  vmovaps xmm5, [rsp+0x50]
000075d5269deb4a  vmovaps xmm6, [rsp+0x60]
000075d5269deb50  vmovaps xmm7, [rsp+0x70]
000075d5269deb56  vmovaps xmm8, [rsp+0x80]
000075d5269deb5f  vmovaps xmm9, [rsp+0x90]
000075d5269deb68  vmovaps xmm10, [rsp+0xA0]
000075d5269deb71  vmovaps xmm11, [rsp+0xB0]
000075d5269deb7a  vmovaps xmm12, [rsp+0xC0]
000075d5269deb83  vmovaps xmm13, [rsp+0xD0]
000075d5269deb8c  vmovaps xmm14, [rsp+0xE0]
000075d5269deb95  add rsp, 0xF0
000075d5269deb9c  pop r11
000075d5269deb9e  pop r10
000075d5269deba0  pop r9
000075d5269deba2  pop r8
000075d5269deba4  pop rsi
000075d5269deba5  pop rdi
000075d5269deba6  pop rdx
000075d5269deba7  pop rcx
000075d5269deba8  pop rax
000075d5269deba9  add rsp, 0x08
000075d5269debad  jmp 0x000075D5269DC2AA
000075d5269debb2  sub rsp, 0x08
000075d5269debb6  push rax
000075d5269debb7  push rcx
000075d5269debb8  push rdx
000075d5269debb9  push rdi
000075d5269debba  push rsi
000075d5269debbb  push r8
000075d5269debbd  push r9
000075d5269debbf  push r10
000075d5269debc1  push r11
000075d5269debc3  sub rsp, 0xF0
000075d5269debca  vmovaps [rsp], xmm0
000075d5269debcf  vmovaps [rsp+0x10], xmm1
000075d5269debd5  vmovaps [rsp+0x20], xmm2
000075d5269debdb  vmovaps [rsp+0x30], xmm3
000075d5269debe1  vmovaps [rsp+0x40], xmm4
000075d5269debe7  vmovaps [rsp+0x50], xmm5
000075d5269debed  vmovaps [rsp+0x60], xmm6
000075d5269debf3  vmovaps [rsp+0x70], xmm7
000075d5269debf9  vmovaps [rsp+0x80], xmm8
000075d5269dec02  vmovaps [rsp+0x90], xmm9
000075d5269dec0b  vmovaps [rsp+0xA0], xmm10
000075d5269dec14  vmovaps [rsp+0xB0], xmm11
000075d5269dec1d  vmovaps [rsp+0xC0], xmm12
000075d5269dec26  vmovaps [rsp+0xD0], xmm13
000075d5269dec2f  vmovaps [rsp+0xE0], xmm15
000075d5269dec38  sub rsp, 0x30
000075d5269dec3c  movaps [rsp], xmm14
000075d5269dec41  movaps [rsp+0x10], xmm2
000075d5269dec46  movaps [rsp+0x20], xmm1
000075d5269dec4b  lea rdi, [rsp]
000075d5269dec4f  mov esi, 0x00
000075d5269dec54  mov rax, 0x601129E62530
000075d5269dec5e  call rax
000075d5269dec60  movaps xmm14, [rsp]
000075d5269dec65  add rsp, 0x30
000075d5269dec69  vmovaps xmm0, [rsp]
000075d5269dec6e  vmovaps xmm1, [rsp+0x10]
000075d5269dec74  vmovaps xmm2, [rsp+0x20]
000075d5269dec7a  vmovaps xmm3, [rsp+0x30]
000075d5269dec80  vmovaps xmm4, [rsp+0x40]
000075d5269dec86  vmovaps xmm5, [rsp+0x50]
000075d5269dec8c  vmovaps xmm6, [rsp+0x60]
000075d5269dec92  vmovaps xmm7, [rsp+0x70]
000075d5269dec98  vmovaps xmm8, [rsp+0x80]
000075d5269deca1  vmovaps xmm9, [rsp+0x90]
000075d5269decaa  vmovaps xmm10, [rsp+0xA0]
000075d5269decb3  vmovaps xmm11, [rsp+0xB0]
000075d5269decbc  vmovaps xmm12, [rsp+0xC0]
000075d5269decc5  vmovaps xmm13, [rsp+0xD0]
000075d5269decce  vmovaps xmm15, [rsp+0xE0]
000075d5269decd7  add rsp, 0xF0
000075d5269decde  pop r11
000075d5269dece0  pop r10
000075d5269dece2  pop r9
000075d5269dece4  pop r8
000075d5269dece6  pop rsi
000075d5269dece7  pop rdi
000075d5269dece8  pop rdx
000075d5269dece9  pop rcx
000075d5269decea  pop rax
000075d5269deceb  add rsp, 0x08
000075d5269decef  jmp 0x000075D5269DC2D0
000075d5269decf4  sub rsp, 0x08
000075d5269decf8  push rax
000075d5269decf9  push rcx
000075d5269decfa  push rdx
000075d5269decfb  push rdi
000075d5269decfc  push rsi
000075d5269decfd  push r8
000075d5269decff  push r9
000075d5269ded01  push r10
000075d5269ded03  push r11
000075d5269ded05  sub rsp, 0xF0
000075d5269ded0c  vmovaps [rsp], xmm0
000075d5269ded11  vmovaps [rsp+0x10], xmm2
000075d5269ded17  vmovaps [rsp+0x20], xmm3
000075d5269ded1d  vmovaps [rsp+0x30], xmm4
000075d5269ded23  vmovaps [rsp+0x40], xmm5
000075d5269ded29  vmovaps [rsp+0x50], xmm6
000075d5269ded2f  vmovaps [rsp+0x60], xmm7
000075d5269ded35  vmovaps [rsp+0x70], xmm8
000075d5269ded3b  vmovaps [rsp+0x80], xmm9
000075d5269ded44  vmovaps [rsp+0x90], xmm10
000075d5269ded4d  vmovaps [rsp+0xA0], xmm11
000075d5269ded56  vmovaps [rsp+0xB0], xmm12
000075d5269ded5f  vmovaps [rsp+0xC0], xmm13
000075d5269ded68  vmovaps [rsp+0xD0], xmm14
000075d5269ded71  vmovaps [rsp+0xE0], xmm15
000075d5269ded7a  sub rsp, 0x30
000075d5269ded7e  movaps [rsp], xmm1
000075d5269ded82  movaps [rsp+0x10], xmm4
000075d5269ded87  movaps [rsp+0x20], xmm9
000075d5269ded8d  lea rdi, [rsp]
000075d5269ded91  mov esi, 0x00
000075d5269ded96  mov rax, 0x601129E62530
000075d5269deda0  call rax
000075d5269deda2  movaps xmm1, [rsp]
000075d5269deda6  add rsp, 0x30
000075d5269dedaa  vmovaps xmm0, [rsp]
000075d5269dedaf  vmovaps xmm2, [rsp+0x10]
000075d5269dedb5  vmovaps xmm3, [rsp+0x20]
000075d5269dedbb  vmovaps xmm4, [rsp+0x30]
000075d5269dedc1  vmovaps xmm5, [rsp+0x40]
000075d5269dedc7  vmovaps xmm6, [rsp+0x50]
000075d5269dedcd  vmovaps xmm7, [rsp+0x60]
000075d5269dedd3  vmovaps xmm8, [rsp+0x70]
000075d5269dedd9  vmovaps xmm9, [rsp+0x80]
000075d5269dede2  vmovaps xmm10, [rsp+0x90]
000075d5269dedeb  vmovaps xmm11, [rsp+0xA0]
000075d5269dedf4  vmovaps xmm12, [rsp+0xB0]
000075d5269dedfd  vmovaps xmm13, [rsp+0xC0]
000075d5269dee06  vmovaps xmm14, [rsp+0xD0]
000075d5269dee0f  vmovaps xmm15, [rsp+0xE0]
000075d5269dee18  add rsp, 0xF0
000075d5269dee1f  pop r11
000075d5269dee21  pop r10
000075d5269dee23  pop r9
000075d5269dee25  pop r8
000075d5269dee27  pop rsi
000075d5269dee28  pop rdi
000075d5269dee29  pop rdx
000075d5269dee2a  pop rcx
000075d5269dee2b  pop rax
000075d5269dee2c  add rsp, 0x08
000075d5269dee30  jmp 0x000075D5269DC2EE
000075d5269dee35  sub rsp, 0x08
000075d5269dee39  push rax
000075d5269dee3a  push rcx
000075d5269dee3b  push rdx
000075d5269dee3c  push rdi
000075d5269dee3d  push rsi
000075d5269dee3e  push r8
000075d5269dee40  push r9
000075d5269dee42  push r10
000075d5269dee44  push r11
000075d5269dee46  sub rsp, 0xF0
000075d5269dee4d  vmovaps [rsp], xmm0
000075d5269dee52  vmovaps [rsp+0x10], xmm1
000075d5269dee58  vmovaps [rsp+0x20], xmm2
000075d5269dee5e  vmovaps [rsp+0x30], xmm3
000075d5269dee64  vmovaps [rsp+0x40], xmm5
000075d5269dee6a  vmovaps [rsp+0x50], xmm6
000075d5269dee70  vmovaps [rsp+0x60], xmm7
000075d5269dee76  vmovaps [rsp+0x70], xmm8
000075d5269dee7c  vmovaps [rsp+0x80], xmm9
000075d5269dee85  vmovaps [rsp+0x90], xmm10
000075d5269dee8e  vmovaps [rsp+0xA0], xmm11
000075d5269dee97  vmovaps [rsp+0xB0], xmm12
000075d5269deea0  vmovaps [rsp+0xC0], xmm13
000075d5269deea9  vmovaps [rsp+0xD0], xmm14
000075d5269deeb2  vmovaps [rsp+0xE0], xmm15
000075d5269deebb  sub rsp, 0x30
000075d5269deebf  movaps [rsp], xmm4
000075d5269deec3  movaps [rsp+0x10], xmm2
000075d5269deec8  movaps [rsp+0x20], xmm9
000075d5269deece  lea rdi, [rsp]
000075d5269deed2  mov esi, 0x00
000075d5269deed7  mov rax, 0x601129E62530
000075d5269deee1  call rax
000075d5269deee3  movaps xmm4, [rsp]
000075d5269deee7  add rsp, 0x30
000075d5269deeeb  vmovaps xmm0, [rsp]
000075d5269deef0  vmovaps xmm1, [rsp+0x10]
000075d5269deef6  vmovaps xmm2, [rsp+0x20]
000075d5269deefc  vmovaps xmm3, [rsp+0x30]
000075d5269def02  vmovaps xmm5, [rsp+0x40]
000075d5269def08  vmovaps xmm6, [rsp+0x50]
000075d5269def0e  vmovaps xmm7, [rsp+0x60]
000075d5269def14  vmovaps xmm8, [rsp+0x70]
000075d5269def1a  vmovaps xmm9, [rsp+0x80]
000075d5269def23  vmovaps xmm10, [rsp+0x90]
000075d5269def2c  vmovaps xmm11, [rsp+0xA0]
000075d5269def35  vmovaps xmm12, [rsp+0xB0]
000075d5269def3e  vmovaps xmm13, [rsp+0xC0]
000075d5269def47  vmovaps xmm14, [rsp+0xD0]
000075d5269def50  vmovaps xmm15, [rsp+0xE0]
000075d5269def59  add rsp, 0xF0
000075d5269def60  pop r11
000075d5269def62  pop r10
000075d5269def64  pop r9
000075d5269def66  pop r8
000075d5269def68  pop rsi
000075d5269def69  pop rdi
000075d5269def6a  pop rdx
000075d5269def6b  pop rcx
000075d5269def6c  pop rax
000075d5269def6d  add rsp, 0x08
000075d5269def71  jmp 0x000075D5269DC31E
000075d5269def76  sub rsp, 0x08
000075d5269def7a  push rax
000075d5269def7b  push rcx
000075d5269def7c  push rdx
000075d5269def7d  push rdi
000075d5269def7e  push rsi
000075d5269def7f  push r8
000075d5269def81  push r9
000075d5269def83  push r10
000075d5269def85  push r11
000075d5269def87  sub rsp, 0xF0
000075d5269def8e  vmovaps [rsp], xmm0
000075d5269def93  vmovaps [rsp+0x10], xmm1
000075d5269def99  vmovaps [rsp+0x20], xmm2
000075d5269def9f  vmovaps [rsp+0x30], xmm3
000075d5269defa5  vmovaps [rsp+0x40], xmm4
000075d5269defab  vmovaps [rsp+0x50], xmm5
000075d5269defb1  vmovaps [rsp+0x60], xmm6
000075d5269defb7  vmovaps [rsp+0x70], xmm7
000075d5269defbd  vmovaps [rsp+0x80], xmm8
000075d5269defc6  vmovaps [rsp+0x90], xmm10
000075d5269defcf  vmovaps [rsp+0xA0], xmm11
000075d5269defd8  vmovaps [rsp+0xB0], xmm12
000075d5269defe1  vmovaps [rsp+0xC0], xmm13
000075d5269defea  vmovaps [rsp+0xD0], xmm14
000075d5269deff3  vmovaps [rsp+0xE0], xmm15
000075d5269deffc  sub rsp, 0x30
000075d5269df000  movaps [rsp], xmm9
000075d5269df005  movaps [rsp+0x10], xmm2
000075d5269df00a  movaps [rsp+0x20], xmm1
000075d5269df00f  lea rdi, [rsp]
000075d5269df013  mov esi, 0x00
000075d5269df018  mov rax, 0x601129E62530
000075d5269df022  call rax
000075d5269df024  movaps xmm9, [rsp]
000075d5269df029  add rsp, 0x30
000075d5269df02d  vmovaps xmm0, [rsp]
000075d5269df032  vmovaps xmm1, [rsp+0x10]
000075d5269df038  vmovaps xmm2, [rsp+0x20]
000075d5269df03e  vmovaps xmm3, [rsp+0x30]
000075d5269df044  vmovaps xmm4, [rsp+0x40]
000075d5269df04a  vmovaps xmm5, [rsp+0x50]
000075d5269df050  vmovaps xmm6, [rsp+0x60]
000075d5269df056  vmovaps xmm7, [rsp+0x70]
000075d5269df05c  vmovaps xmm8, [rsp+0x80]
000075d5269df065  vmovaps xmm10, [rsp+0x90]
000075d5269df06e  vmovaps xmm11, [rsp+0xA0]
000075d5269df077  vmovaps xmm12, [rsp+0xB0]
000075d5269df080  vmovaps xmm13, [rsp+0xC0]
000075d5269df089  vmovaps xmm14, [rsp+0xD0]
000075d5269df092  vmovaps xmm15, [rsp+0xE0]
000075d5269df09b  add rsp, 0xF0
000075d5269df0a2  pop r11
000075d5269df0a4  pop r10
000075d5269df0a6  pop r9
000075d5269df0a8  pop r8
000075d5269df0aa  pop rsi
000075d5269df0ab  pop rdi
000075d5269df0ac  pop rdx
000075d5269df0ad  pop rcx
000075d5269df0ae  pop rax
000075d5269df0af  add rsp, 0x08
000075d5269df0b3  jmp 0x000075D5269DC354
000075d5269df0b8  sub rsp, 0x08
000075d5269df0bc  push rax
000075d5269df0bd  push rcx
000075d5269df0be  push rdx
000075d5269df0bf  push rdi
000075d5269df0c0  push rsi
000075d5269df0c1  push r8
000075d5269df0c3  push r9
000075d5269df0c5  push r10
000075d5269df0c7  push r11
000075d5269df0c9  sub rsp, 0xF0
000075d5269df0d0  vmovaps [rsp], xmm0
000075d5269df0d5  vmovaps [rsp+0x10], xmm2
000075d5269df0db  vmovaps [rsp+0x20], xmm3
000075d5269df0e1  vmovaps [rsp+0x30], xmm4
000075d5269df0e7  vmovaps [rsp+0x40], xmm5
000075d5269df0ed  vmovaps [rsp+0x50], xmm6
000075d5269df0f3  vmovaps [rsp+0x60], xmm7
000075d5269df0f9  vmovaps [rsp+0x70], xmm8
000075d5269df0ff  vmovaps [rsp+0x80], xmm9
000075d5269df108  vmovaps [rsp+0x90], xmm10
000075d5269df111  vmovaps [rsp+0xA0], xmm11
000075d5269df11a  vmovaps [rsp+0xB0], xmm12
000075d5269df123  vmovaps [rsp+0xC0], xmm13
000075d5269df12c  vmovaps [rsp+0xD0], xmm14
000075d5269df135  vmovaps [rsp+0xE0], xmm15
000075d5269df13e  sub rsp, 0x30
000075d5269df142  movaps [rsp], xmm1
000075d5269df146  movaps [rsp+0x10], xmm15
000075d5269df14c  movaps [rsp+0x20], xmm6
000075d5269df151  lea rdi, [rsp]
000075d5269df155  mov esi, 0x00
000075d5269df15a  mov rax, 0x601129E62530
000075d5269df164  call rax
000075d5269df166  movaps xmm1, [rsp]
000075d5269df16a  add rsp, 0x30
000075d5269df16e  vmovaps xmm0, [rsp]
000075d5269df173  vmovaps xmm2, [rsp+0x10]
000075d5269df179  vmovaps xmm3, [rsp+0x20]
000075d5269df17f  vmovaps xmm4, [rsp+0x30]
000075d5269df185  vmovaps xmm5, [rsp+0x40]
000075d5269df18b  vmovaps xmm6, [rsp+0x50]
000075d5269df191  vmovaps xmm7, [rsp+0x60]
000075d5269df197  vmovaps xmm8, [rsp+0x70]
000075d5269df19d  vmovaps xmm9, [rsp+0x80]
000075d5269df1a6  vmovaps xmm10, [rsp+0x90]
000075d5269df1af  vmovaps xmm11, [rsp+0xA0]
000075d5269df1b8  vmovaps xmm12, [rsp+0xB0]
000075d5269df1c1  vmovaps xmm13, [rsp+0xC0]
000075d5269df1ca  vmovaps xmm14, [rsp+0xD0]
000075d5269df1d3  vmovaps xmm15, [rsp+0xE0]
000075d5269df1dc  add rsp, 0xF0
000075d5269df1e3  pop r11
000075d5269df1e5  pop r10
000075d5269df1e7  pop r9
000075d5269df1e9  pop r8
000075d5269df1eb  pop rsi
000075d5269df1ec  pop rdi
000075d5269df1ed  pop rdx
000075d5269df1ee  pop rcx
000075d5269df1ef  pop rax
000075d5269df1f0  add rsp, 0x08
000075d5269df1f4  jmp 0x000075D5269DC375
000075d5269df1f9  sub rsp, 0x08
000075d5269df1fd  push rax
000075d5269df1fe  push rcx
000075d5269df1ff  push rdx
000075d5269df200  push rdi
000075d5269df201  push rsi
000075d5269df202  push r8
000075d5269df204  push r9
000075d5269df206  push r10
000075d5269df208  push r11
000075d5269df20a  sub rsp, 0xF0
000075d5269df211  vmovaps [rsp], xmm0
000075d5269df216  vmovaps [rsp+0x10], xmm1
000075d5269df21c  vmovaps [rsp+0x20], xmm2
000075d5269df222  vmovaps [rsp+0x30], xmm3
000075d5269df228  vmovaps [rsp+0x40], xmm4
000075d5269df22e  vmovaps [rsp+0x50], xmm5
000075d5269df234  vmovaps [rsp+0x60], xmm6
000075d5269df23a  vmovaps [rsp+0x70], xmm7
000075d5269df240  vmovaps [rsp+0x80], xmm8
000075d5269df249  vmovaps [rsp+0x90], xmm9
000075d5269df252  vmovaps [rsp+0xA0], xmm10
000075d5269df25b  vmovaps [rsp+0xB0], xmm11
000075d5269df264  vmovaps [rsp+0xC0], xmm12
000075d5269df26d  vmovaps [rsp+0xD0], xmm13
000075d5269df276  vmovaps [rsp+0xE0], xmm14
000075d5269df27f  sub rsp, 0x30
000075d5269df283  movaps [rsp], xmm15
000075d5269df288  movaps [rsp+0x10], xmm5
000075d5269df28d  movaps [rsp+0x20], xmm3
000075d5269df292  lea rdi, [rsp]
000075d5269df296  mov esi, 0x00
000075d5269df29b  mov rax, 0x601129E62530
000075d5269df2a5  call rax
000075d5269df2a7  movaps xmm15, [rsp]
000075d5269df2ac  add rsp, 0x30
000075d5269df2b0  vmovaps xmm0, [rsp]
000075d5269df2b5  vmovaps xmm1, [rsp+0x10]
000075d5269df2bb  vmovaps xmm2, [rsp+0x20]
000075d5269df2c1  vmovaps xmm3, [rsp+0x30]
000075d5269df2c7  vmovaps xmm4, [rsp+0x40]
000075d5269df2cd  vmovaps xmm5, [rsp+0x50]
000075d5269df2d3  vmovaps xmm6, [rsp+0x60]
000075d5269df2d9  vmovaps xmm7, [rsp+0x70]
000075d5269df2df  vmovaps xmm8, [rsp+0x80]
000075d5269df2e8  vmovaps xmm9, [rsp+0x90]
000075d5269df2f1  vmovaps xmm10, [rsp+0xA0]
000075d5269df2fa  vmovaps xmm11, [rsp+0xB0]
000075d5269df303  vmovaps xmm12, [rsp+0xC0]
000075d5269df30c  vmovaps xmm13, [rsp+0xD0]
000075d5269df315  vmovaps xmm14, [rsp+0xE0]
000075d5269df31e  add rsp, 0xF0
000075d5269df325  pop r11
000075d5269df327  pop r10
000075d5269df329  pop r9
000075d5269df32b  pop r8
000075d5269df32d  pop rsi
000075d5269df32e  pop rdi
000075d5269df32f  pop rdx
000075d5269df330  pop rcx
000075d5269df331  pop rax
000075d5269df332  add rsp, 0x08
000075d5269df336  jmp 0x000075D5269DC38F
000075d5269df33b  sub rsp, 0x08
000075d5269df33f  push rax
000075d5269df340  push rcx
000075d5269df341  push rdx
000075d5269df342  push rdi
000075d5269df343  push rsi
000075d5269df344  push r8
000075d5269df346  push r9
000075d5269df348  push r10
000075d5269df34a  push r11
000075d5269df34c  sub rsp, 0xF0
000075d5269df353  vmovaps [rsp], xmm0
000075d5269df358  vmovaps [rsp+0x10], xmm1
000075d5269df35e  vmovaps [rsp+0x20], xmm2
000075d5269df364  vmovaps [rsp+0x30], xmm3
000075d5269df36a  vmovaps [rsp+0x40], xmm4
000075d5269df370  vmovaps [rsp+0x50], xmm6
000075d5269df376  vmovaps [rsp+0x60], xmm7
000075d5269df37c  vmovaps [rsp+0x70], xmm8
000075d5269df382  vmovaps [rsp+0x80], xmm9
000075d5269df38b  vmovaps [rsp+0x90], xmm10
000075d5269df394  vmovaps [rsp+0xA0], xmm11
000075d5269df39d  vmovaps [rsp+0xB0], xmm12
000075d5269df3a6  vmovaps [rsp+0xC0], xmm13
000075d5269df3af  vmovaps [rsp+0xD0], xmm14
000075d5269df3b8  vmovaps [rsp+0xE0], xmm15
000075d5269df3c1  sub rsp, 0x30
000075d5269df3c5  movaps [rsp], xmm5
000075d5269df3c9  movaps [rsp+0x10], xmm8
000075d5269df3cf  movaps [rsp+0x20], xmm6
000075d5269df3d4  lea rdi, [rsp]
000075d5269df3d8  mov esi, 0x00
000075d5269df3dd  mov rax, 0x601129E62530
000075d5269df3e7  call rax
000075d5269df3e9  movaps xmm5, [rsp]
000075d5269df3ed  add rsp, 0x30
000075d5269df3f1  vmovaps xmm0, [rsp]
000075d5269df3f6  vmovaps xmm1, [rsp+0x10]
000075d5269df3fc  vmovaps xmm2, [rsp+0x20]
000075d5269df402  vmovaps xmm3, [rsp+0x30]
000075d5269df408  vmovaps xmm4, [rsp+0x40]
000075d5269df40e  vmovaps xmm6, [rsp+0x50]
000075d5269df414  vmovaps xmm7, [rsp+0x60]
000075d5269df41a  vmovaps xmm8, [rsp+0x70]
000075d5269df420  vmovaps xmm9, [rsp+0x80]
000075d5269df429  vmovaps xmm10, [rsp+0x90]
000075d5269df432  vmovaps xmm11, [rsp+0xA0]
000075d5269df43b  vmovaps xmm12, [rsp+0xB0]
000075d5269df444  vmovaps xmm13, [rsp+0xC0]
000075d5269df44d  vmovaps xmm14, [rsp+0xD0]
000075d5269df456  vmovaps xmm15, [rsp+0xE0]
000075d5269df45f  add rsp, 0xF0
000075d5269df466  pop r11
000075d5269df468  pop r10
000075d5269df46a  pop r9
000075d5269df46c  pop r8
000075d5269df46e  pop rsi
000075d5269df46f  pop rdi
000075d5269df470  pop rdx
000075d5269df471  pop rcx
000075d5269df472  pop rax
000075d5269df473  add rsp, 0x08
000075d5269df477  jmp 0x000075D5269DC3B3
000075d5269df47c  sub rsp, 0x08
000075d5269df480  push rax
000075d5269df481  push rcx
000075d5269df482  push rdx
000075d5269df483  push rdi
000075d5269df484  push rsi
000075d5269df485  push r8
000075d5269df487  push r9
000075d5269df489  push r10
000075d5269df48b  push r11
000075d5269df48d  sub rsp, 0xF0
000075d5269df494  vmovaps [rsp], xmm0
000075d5269df499  vmovaps [rsp+0x10], xmm1
000075d5269df49f  vmovaps [rsp+0x20], xmm2
000075d5269df4a5  vmovaps [rsp+0x30], xmm3
000075d5269df4ab  vmovaps [rsp+0x40], xmm4
000075d5269df4b1  vmovaps [rsp+0x50], xmm5
000075d5269df4b7  vmovaps [rsp+0x60], xmm7
000075d5269df4bd  vmovaps [rsp+0x70], xmm8
000075d5269df4c3  vmovaps [rsp+0x80], xmm9
000075d5269df4cc  vmovaps [rsp+0x90], xmm10
000075d5269df4d5  vmovaps [rsp+0xA0], xmm11
000075d5269df4de  vmovaps [rsp+0xB0], xmm12
000075d5269df4e7  vmovaps [rsp+0xC0], xmm13
000075d5269df4f0  vmovaps [rsp+0xD0], xmm14
000075d5269df4f9  vmovaps [rsp+0xE0], xmm15
000075d5269df502  sub rsp, 0x30
000075d5269df506  movaps [rsp], xmm6
000075d5269df50a  movaps [rsp+0x10], xmm10
000075d5269df510  movaps [rsp+0x20], xmm8
000075d5269df516  lea rdi, [rsp]
000075d5269df51a  mov esi, 0x00
000075d5269df51f  mov rax, 0x601129E62530
000075d5269df529  call rax
000075d5269df52b  movaps xmm6, [rsp]
000075d5269df52f  add rsp, 0x30
000075d5269df533  vmovaps xmm0, [rsp]
000075d5269df538  vmovaps xmm1, [rsp+0x10]
000075d5269df53e  vmovaps xmm2, [rsp+0x20]
000075d5269df544  vmovaps xmm3, [rsp+0x30]
000075d5269df54a  vmovaps xmm4, [rsp+0x40]
000075d5269df550  vmovaps xmm5, [rsp+0x50]
000075d5269df556  vmovaps xmm7, [rsp+0x60]
000075d5269df55c  vmovaps xmm8, [rsp+0x70]
000075d5269df562  vmovaps xmm9, [rsp+0x80]
000075d5269df56b  vmovaps xmm10, [rsp+0x90]
000075d5269df574  vmovaps xmm11, [rsp+0xA0]
000075d5269df57d  vmovaps xmm12, [rsp+0xB0]
000075d5269df586  vmovaps xmm13, [rsp+0xC0]
000075d5269df58f  vmovaps xmm14, [rsp+0xD0]
000075d5269df598  vmovaps xmm15, [rsp+0xE0]
000075d5269df5a1  add rsp, 0xF0
000075d5269df5a8  pop r11
000075d5269df5aa  pop r10
000075d5269df5ac  pop r9
000075d5269df5ae  pop r8
000075d5269df5b0  pop rsi
000075d5269df5b1  pop rdi
000075d5269df5b2  pop rdx
000075d5269df5b3  pop rcx
000075d5269df5b4  pop rax
000075d5269df5b5  add rsp, 0x08
000075d5269df5b9  jmp 0x000075D5269DC3D8
000075d5269df5be  sub rsp, 0x08
000075d5269df5c2  push rax
000075d5269df5c3  push rcx
000075d5269df5c4  push rdx
000075d5269df5c5  push rdi
000075d5269df5c6  push rsi
000075d5269df5c7  push r8
000075d5269df5c9  push r9
000075d5269df5cb  push r10
000075d5269df5cd  push r11
000075d5269df5cf  sub rsp, 0xF0
000075d5269df5d6  vmovaps [rsp], xmm0
000075d5269df5db  vmovaps [rsp+0x10], xmm1
000075d5269df5e1  vmovaps [rsp+0x20], xmm2
000075d5269df5e7  vmovaps [rsp+0x30], xmm3
000075d5269df5ed  vmovaps [rsp+0x40], xmm4
000075d5269df5f3  vmovaps [rsp+0x50], xmm5
000075d5269df5f9  vmovaps [rsp+0x60], xmm6
000075d5269df5ff  vmovaps [rsp+0x70], xmm7
000075d5269df605  vmovaps [rsp+0x80], xmm8
000075d5269df60e  vmovaps [rsp+0x90], xmm9
000075d5269df617  vmovaps [rsp+0xA0], xmm11
000075d5269df620  vmovaps [rsp+0xB0], xmm12
000075d5269df629  vmovaps [rsp+0xC0], xmm13
000075d5269df632  vmovaps [rsp+0xD0], xmm14
000075d5269df63b  vmovaps [rsp+0xE0], xmm15
000075d5269df644  sub rsp, 0x30
000075d5269df648  movaps [rsp], xmm10
000075d5269df64d  movaps [rsp+0x10], xmm8
000075d5269df653  movaps [rsp+0x20], xmm14
000075d5269df659  lea rdi, [rsp]
000075d5269df65d  mov esi, 0x00
000075d5269df662  mov rax, 0x601129E62530
000075d5269df66c  call rax
000075d5269df66e  movaps xmm10, [rsp]
000075d5269df673  add rsp, 0x30
000075d5269df677  vmovaps xmm0, [rsp]
000075d5269df67c  vmovaps xmm1, [rsp+0x10]
000075d5269df682  vmovaps xmm2, [rsp+0x20]
000075d5269df688  vmovaps xmm3, [rsp+0x30]
000075d5269df68e  vmovaps xmm4, [rsp+0x40]
000075d5269df694  vmovaps xmm5, [rsp+0x50]
000075d5269df69a  vmovaps xmm6, [rsp+0x60]
000075d5269df6a0  vmovaps xmm7, [rsp+0x70]
000075d5269df6a6  vmovaps xmm8, [rsp+0x80]
000075d5269df6af  vmovaps xmm9, [rsp+0x90]
000075d5269df6b8  vmovaps xmm11, [rsp+0xA0]
000075d5269df6c1  vmovaps xmm12, [rsp+0xB0]
000075d5269df6ca  vmovaps xmm13, [rsp+0xC0]
000075d5269df6d3  vmovaps xmm14, [rsp+0xD0]
000075d5269df6dc  vmovaps xmm15, [rsp+0xE0]
000075d5269df6e5  add rsp, 0xF0
000075d5269df6ec  pop r11
000075d5269df6ee  pop r10
000075d5269df6f0  pop r9
000075d5269df6f2  pop r8
000075d5269df6f4  pop rsi
000075d5269df6f5  pop rdi
000075d5269df6f6  pop rdx
000075d5269df6f7  pop rcx
000075d5269df6f8  pop rax
000075d5269df6f9  add rsp, 0x08
000075d5269df6fd  jmp 0x000075D5269DC3F8
000075d5269df702  sub rsp, 0x08
000075d5269df706  push rax
000075d5269df707  push rcx
000075d5269df708  push rdx
000075d5269df709  push rdi
000075d5269df70a  push rsi
000075d5269df70b  push r8
000075d5269df70d  push r9
000075d5269df70f  push r10
000075d5269df711  push r11
000075d5269df713  sub rsp, 0xF0
000075d5269df71a  vmovaps [rsp], xmm0
000075d5269df71f  vmovaps [rsp+0x10], xmm1
000075d5269df725  vmovaps [rsp+0x20], xmm2
000075d5269df72b  vmovaps [rsp+0x30], xmm3
000075d5269df731  vmovaps [rsp+0x40], xmm4
000075d5269df737  vmovaps [rsp+0x50], xmm5
000075d5269df73d  vmovaps [rsp+0x60], xmm6
000075d5269df743  vmovaps [rsp+0x70], xmm7
000075d5269df749  vmovaps [rsp+0x80], xmm8
000075d5269df752  vmovaps [rsp+0x90], xmm9
000075d5269df75b  vmovaps [rsp+0xA0], xmm10
000075d5269df764  vmovaps [rsp+0xB0], xmm11
000075d5269df76d  vmovaps [rsp+0xC0], xmm12
000075d5269df776  vmovaps [rsp+0xD0], xmm13
000075d5269df77f  vmovaps [rsp+0xE0], xmm15
000075d5269df788  sub rsp, 0x30
000075d5269df78c  movaps [rsp], xmm14
000075d5269df791  movaps [rsp+0x10], xmm8
000075d5269df797  movaps [rsp+0x20], xmm4
000075d5269df79c  lea rdi, [rsp]
000075d5269df7a0  mov esi, 0x00
000075d5269df7a5  mov rax, 0x601129E62530
000075d5269df7af  call rax
000075d5269df7b1  movaps xmm14, [rsp]
000075d5269df7b6  add rsp, 0x30
000075d5269df7ba  vmovaps xmm0, [rsp]
000075d5269df7bf  vmovaps xmm1, [rsp+0x10]
000075d5269df7c5  vmovaps xmm2, [rsp+0x20]
000075d5269df7cb  vmovaps xmm3, [rsp+0x30]
000075d5269df7d1  vmovaps xmm4, [rsp+0x40]
000075d5269df7d7  vmovaps xmm5, [rsp+0x50]
000075d5269df7dd  vmovaps xmm6, [rsp+0x60]
000075d5269df7e3  vmovaps xmm7, [rsp+0x70]
000075d5269df7e9  vmovaps xmm8, [rsp+0x80]
000075d5269df7f2  vmovaps xmm9, [rsp+0x90]
000075d5269df7fb  vmovaps xmm10, [rsp+0xA0]
000075d5269df804  vmovaps xmm11, [rsp+0xB0]
000075d5269df80d  vmovaps xmm12, [rsp+0xC0]
000075d5269df816  vmovaps xmm13, [rsp+0xD0]
000075d5269df81f  vmovaps xmm15, [rsp+0xE0]
000075d5269df828  add rsp, 0xF0
000075d5269df82f  pop r11
000075d5269df831  pop r10
000075d5269df833  pop r9
000075d5269df835  pop r8
000075d5269df837  pop rsi
000075d5269df838  pop rdi
000075d5269df839  pop rdx
000075d5269df83a  pop rcx
000075d5269df83b  pop rax
000075d5269df83c  add rsp, 0x08
000075d5269df840  jmp 0x000075D5269DC418
000075d5269df845  sub rsp, 0x08
000075d5269df849  push rax
000075d5269df84a  push rcx
000075d5269df84b  push rdx
000075d5269df84c  push rdi
000075d5269df84d  push rsi
000075d5269df84e  push r8
000075d5269df850  push r9
000075d5269df852  push r10
000075d5269df854  push r11
000075d5269df856  sub rsp, 0xF0
000075d5269df85d  vmovaps [rsp], xmm0
000075d5269df862  vmovaps [rsp+0x10], xmm1
000075d5269df868  vmovaps [rsp+0x20], xmm2
000075d5269df86e  vmovaps [rsp+0x30], xmm3
000075d5269df874  vmovaps [rsp+0x40], xmm5
000075d5269df87a  vmovaps [rsp+0x50], xmm6
000075d5269df880  vmovaps [rsp+0x60], xmm7
000075d5269df886  vmovaps [rsp+0x70], xmm8
000075d5269df88c  vmovaps [rsp+0x80], xmm9
000075d5269df895  vmovaps [rsp+0x90], xmm10
000075d5269df89e  vmovaps [rsp+0xA0], xmm11
000075d5269df8a7  vmovaps [rsp+0xB0], xmm12
000075d5269df8b0  vmovaps [rsp+0xC0], xmm13
000075d5269df8b9  vmovaps [rsp+0xD0], xmm14
000075d5269df8c2  vmovaps [rsp+0xE0], xmm15
000075d5269df8cb  sub rsp, 0x30
000075d5269df8cf  movaps [rsp], xmm4
000075d5269df8d3  movaps [rsp+0x10], xmm13
000075d5269df8d9  movaps [rsp+0x20], xmm8
000075d5269df8df  lea rdi, [rsp]
000075d5269df8e3  mov esi, 0x00
000075d5269df8e8  mov rax, 0x601129E62530
000075d5269df8f2  call rax
000075d5269df8f4  movaps xmm4, [rsp]
000075d5269df8f8  add rsp, 0x30
000075d5269df8fc  vmovaps xmm0, [rsp]
000075d5269df901  vmovaps xmm1, [rsp+0x10]
000075d5269df907  vmovaps xmm2, [rsp+0x20]
000075d5269df90d  vmovaps xmm3, [rsp+0x30]
000075d5269df913  vmovaps xmm5, [rsp+0x40]
000075d5269df919  vmovaps xmm6, [rsp+0x50]
000075d5269df91f  vmovaps xmm7, [rsp+0x60]
000075d5269df925  vmovaps xmm8, [rsp+0x70]
000075d5269df92b  vmovaps xmm9, [rsp+0x80]
000075d5269df934  vmovaps xmm10, [rsp+0x90]
000075d5269df93d  vmovaps xmm11, [rsp+0xA0]
000075d5269df946  vmovaps xmm12, [rsp+0xB0]
000075d5269df94f  vmovaps xmm13, [rsp+0xC0]
000075d5269df958  vmovaps xmm14, [rsp+0xD0]
000075d5269df961  vmovaps xmm15, [rsp+0xE0]
000075d5269df96a  add rsp, 0xF0
000075d5269df971  pop r11
000075d5269df973  pop r10
000075d5269df975  pop r9
000075d5269df977  pop r8
000075d5269df979  pop rsi
000075d5269df97a  pop rdi
000075d5269df97b  pop rdx
000075d5269df97c  pop rcx
000075d5269df97d  pop rax
000075d5269df97e  add rsp, 0x08
000075d5269df982  jmp 0x000075D5269DC43D
000075d5269df987  sub rsp, 0x08
000075d5269df98b  push rax
000075d5269df98c  push rcx
000075d5269df98d  push rdx
000075d5269df98e  push rdi
000075d5269df98f  push rsi
000075d5269df990  push r8
000075d5269df992  push r9
000075d5269df994  push r10
000075d5269df996  push r11
000075d5269df998  sub rsp, 0xF0
000075d5269df99f  vmovaps [rsp], xmm0
000075d5269df9a4  vmovaps [rsp+0x10], xmm1
000075d5269df9aa  vmovaps [rsp+0x20], xmm2
000075d5269df9b0  vmovaps [rsp+0x30], xmm3
000075d5269df9b6  vmovaps [rsp+0x40], xmm4
000075d5269df9bc  vmovaps [rsp+0x50], xmm5
000075d5269df9c2  vmovaps [rsp+0x60], xmm6
000075d5269df9c8  vmovaps [rsp+0x70], xmm7
000075d5269df9ce  vmovaps [rsp+0x80], xmm8
000075d5269df9d7  vmovaps [rsp+0x90], xmm9
000075d5269df9e0  vmovaps [rsp+0xA0], xmm10
000075d5269df9e9  vmovaps [rsp+0xB0], xmm11
000075d5269df9f2  vmovaps [rsp+0xC0], xmm12
000075d5269df9fb  vmovaps [rsp+0xD0], xmm14
000075d5269dfa04  vmovaps [rsp+0xE0], xmm15
000075d5269dfa0d  sub rsp, 0x30
000075d5269dfa11  movaps [rsp], xmm13
000075d5269dfa16  movaps [rsp+0x10], xmm15
000075d5269dfa1c  movaps [rsp+0x20], xmm9
000075d5269dfa22  lea rdi, [rsp]
000075d5269dfa26  mov esi, 0x00
000075d5269dfa2b  mov rax, 0x601129E62530
000075d5269dfa35  call rax
000075d5269dfa37  movaps xmm13, [rsp]
000075d5269dfa3c  add rsp, 0x30
000075d5269dfa40  vmovaps xmm0, [rsp]
000075d5269dfa45  vmovaps xmm1, [rsp+0x10]
000075d5269dfa4b  vmovaps xmm2, [rsp+0x20]
000075d5269dfa51  vmovaps xmm3, [rsp+0x30]
000075d5269dfa57  vmovaps xmm4, [rsp+0x40]
000075d5269dfa5d  vmovaps xmm5, [rsp+0x50]
000075d5269dfa63  vmovaps xmm6, [rsp+0x60]
000075d5269dfa69  vmovaps xmm7, [rsp+0x70]
000075d5269dfa6f  vmovaps xmm8, [rsp+0x80]
000075d5269dfa78  vmovaps xmm9, [rsp+0x90]
000075d5269dfa81  vmovaps xmm10, [rsp+0xA0]
000075d5269dfa8a  vmovaps xmm11, [rsp+0xB0]
000075d5269dfa93  vmovaps xmm12, [rsp+0xC0]
000075d5269dfa9c  vmovaps xmm14, [rsp+0xD0]
000075d5269dfaa5  vmovaps xmm15, [rsp+0xE0]
000075d5269dfaae  add rsp, 0xF0
000075d5269dfab5  pop r11
000075d5269dfab7  pop r10
000075d5269dfab9  pop r9
000075d5269dfabb  pop r8
000075d5269dfabd  pop rsi
000075d5269dfabe  pop rdi
000075d5269dfabf  pop rdx
000075d5269dfac0  pop rcx
000075d5269dfac1  pop rax
000075d5269dfac2  add rsp, 0x08
000075d5269dfac6  jmp 0x000075D5269DC458
000075d5269dfacb  sub rsp, 0x08
000075d5269dfacf  push rax
000075d5269dfad0  push rcx
000075d5269dfad1  push rdx
000075d5269dfad2  push rdi
000075d5269dfad3  push rsi
000075d5269dfad4  push r8
000075d5269dfad6  push r9
000075d5269dfad8  push r10
000075d5269dfada  push r11
000075d5269dfadc  sub rsp, 0xF0
000075d5269dfae3  vmovaps [rsp], xmm0
000075d5269dfae8  vmovaps [rsp+0x10], xmm1
000075d5269dfaee  vmovaps [rsp+0x20], xmm2
000075d5269dfaf4  vmovaps [rsp+0x30], xmm3
000075d5269dfafa  vmovaps [rsp+0x40], xmm4
000075d5269dfb00  vmovaps [rsp+0x50], xmm5
000075d5269dfb06  vmovaps [rsp+0x60], xmm6
000075d5269dfb0c  vmovaps [rsp+0x70], xmm7
000075d5269dfb12  vmovaps [rsp+0x80], xmm8
000075d5269dfb1b  vmovaps [rsp+0x90], xmm9
000075d5269dfb24  vmovaps [rsp+0xA0], xmm10
000075d5269dfb2d  vmovaps [rsp+0xB0], xmm11
000075d5269dfb36  vmovaps [rsp+0xC0], xmm12
000075d5269dfb3f  vmovaps [rsp+0xD0], xmm13
000075d5269dfb48  vmovaps [rsp+0xE0], xmm14
000075d5269dfb51  sub rsp, 0x30
000075d5269dfb55  movaps [rsp], xmm15
000075d5269dfb5a  movaps [rsp+0x10], xmm1
000075d5269dfb5f  movaps [rsp+0x20], xmm5
000075d5269dfb64  lea rdi, [rsp]
000075d5269dfb68  mov esi, 0x00
000075d5269dfb6d  mov rax, 0x601129E62530
000075d5269dfb77  call rax
000075d5269dfb79  movaps xmm15, [rsp]
000075d5269dfb7e  add rsp, 0x30
000075d5269dfb82  vmovaps xmm0, [rsp]
000075d5269dfb87  vmovaps xmm1, [rsp+0x10]
000075d5269dfb8d  vmovaps xmm2, [rsp+0x20]
000075d5269dfb93  vmovaps xmm3, [rsp+0x30]
000075d5269dfb99  vmovaps xmm4, [rsp+0x40]
000075d5269dfb9f  vmovaps xmm5, [rsp+0x50]
000075d5269dfba5  vmovaps xmm6, [rsp+0x60]
000075d5269dfbab  vmovaps xmm7, [rsp+0x70]
000075d5269dfbb1  vmovaps xmm8, [rsp+0x80]
000075d5269dfbba  vmovaps xmm9, [rsp+0x90]
000075d5269dfbc3  vmovaps xmm10, [rsp+0xA0]
000075d5269dfbcc  vmovaps xmm11, [rsp+0xB0]
000075d5269dfbd5  vmovaps xmm12, [rsp+0xC0]
000075d5269dfbde  vmovaps xmm13, [rsp+0xD0]
000075d5269dfbe7  vmovaps xmm14, [rsp+0xE0]
000075d5269dfbf0  add rsp, 0xF0
000075d5269dfbf7  pop r11
000075d5269dfbf9  pop r10
000075d5269dfbfb  pop r9
000075d5269dfbfd  pop r8
000075d5269dfbff  pop rsi
000075d5269dfc00  pop rdi
000075d5269dfc01  pop rdx
000075d5269dfc02  pop rcx
000075d5269dfc03  pop rax
000075d5269dfc04  add rsp, 0x08
000075d5269dfc08  jmp 0x000075D5269DC473
000075d5269dfc0d  call 0x000075D5268B52F0
000075d5269dfc12  jmp 0x000075D5269DC4CE
000075d5269dfc17  sub rsp, 0x08
000075d5269dfc1b  push rax
000075d5269dfc1c  push rcx
000075d5269dfc1d  push rdx
000075d5269dfc1e  push rdi
000075d5269dfc1f  push rsi
000075d5269dfc20  push r8
000075d5269dfc22  push r9
000075d5269dfc24  push r10
000075d5269dfc26  push r11
000075d5269dfc28  sub rsp, 0xF0
000075d5269dfc2f  vmovaps [rsp], xmm0
000075d5269dfc34  vmovaps [rsp+0x10], xmm1
000075d5269dfc3a  vmovaps [rsp+0x20], xmm2
000075d5269dfc40  vmovaps [rsp+0x30], xmm3
000075d5269dfc46  vmovaps [rsp+0x40], xmm4
000075d5269dfc4c  vmovaps [rsp+0x50], xmm5
000075d5269dfc52  vmovaps [rsp+0x60], xmm6
000075d5269dfc58  vmovaps [rsp+0x70], xmm7
000075d5269dfc5e  vmovaps [rsp+0x80], xmm8
000075d5269dfc67  vmovaps [rsp+0x90], xmm10
000075d5269dfc70  vmovaps [rsp+0xA0], xmm11
000075d5269dfc79  vmovaps [rsp+0xB0], xmm12
000075d5269dfc82  vmovaps [rsp+0xC0], xmm13
000075d5269dfc8b  vmovaps [rsp+0xD0], xmm14
000075d5269dfc94  vmovaps [rsp+0xE0], xmm15
000075d5269dfc9d  sub rsp, 0x30
000075d5269dfca1  movaps [rsp], xmm9
000075d5269dfca6  movaps [rsp+0x10], xmm8
000075d5269dfcac  movaps [rsp+0x20], xmm11
000075d5269dfcb2  lea rdi, [rsp]
000075d5269dfcb6  mov esi, 0x00
000075d5269dfcbb  mov rax, 0x601129E62530
000075d5269dfcc5  call rax
000075d5269dfcc7  movaps xmm9, [rsp]
000075d5269dfccc  add rsp, 0x30
000075d5269dfcd0  vmovaps xmm0, [rsp]
000075d5269dfcd5  vmovaps xmm1, [rsp+0x10]
000075d5269dfcdb  vmovaps xmm2, [rsp+0x20]
000075d5269dfce1  vmovaps xmm3, [rsp+0x30]
000075d5269dfce7  vmovaps xmm4, [rsp+0x40]
000075d5269dfced  vmovaps xmm5, [rsp+0x50]
000075d5269dfcf3  vmovaps xmm6, [rsp+0x60]
000075d5269dfcf9  vmovaps xmm7, [rsp+0x70]
000075d5269dfcff  vmovaps xmm8, [rsp+0x80]
000075d5269dfd08  vmovaps xmm10, [rsp+0x90]
000075d5269dfd11  vmovaps xmm11, [rsp+0xA0]
000075d5269dfd1a  vmovaps xmm12, [rsp+0xB0]
000075d5269dfd23  vmovaps xmm13, [rsp+0xC0]
000075d5269dfd2c  vmovaps xmm14, [rsp+0xD0]
000075d5269dfd35  vmovaps xmm15, [rsp+0xE0]
000075d5269dfd3e  add rsp, 0xF0
000075d5269dfd45  pop r11
000075d5269dfd47  pop r10
000075d5269dfd49  pop r9
000075d5269dfd4b  pop r8
000075d5269dfd4d  pop rsi
000075d5269dfd4e  pop rdi
000075d5269dfd4f  pop rdx
000075d5269dfd50  pop rcx
000075d5269dfd51  pop rax
000075d5269dfd52  add rsp, 0x08
000075d5269dfd56  jmp 0x000075D5269DC505
000075d5269dfd5b  sub rsp, 0x08
000075d5269dfd5f  push rax
000075d5269dfd60  push rcx
000075d5269dfd61  push rdx
000075d5269dfd62  push rdi
000075d5269dfd63  push rsi
000075d5269dfd64  push r8
000075d5269dfd66  push r9
000075d5269dfd68  push r10
000075d5269dfd6a  push r11
000075d5269dfd6c  sub rsp, 0xF0
000075d5269dfd73  vmovaps [rsp], xmm0
000075d5269dfd78  vmovaps [rsp+0x10], xmm1
000075d5269dfd7e  vmovaps [rsp+0x20], xmm2
000075d5269dfd84  vmovaps [rsp+0x30], xmm3
000075d5269dfd8a  vmovaps [rsp+0x40], xmm4
000075d5269dfd90  vmovaps [rsp+0x50], xmm5
000075d5269dfd96  vmovaps [rsp+0x60], xmm6
000075d5269dfd9c  vmovaps [rsp+0x70], xmm7
000075d5269dfda2  vmovaps [rsp+0x80], xmm8
000075d5269dfdab  vmovaps [rsp+0x90], xmm9
000075d5269dfdb4  vmovaps [rsp+0xA0], xmm10
000075d5269dfdbd  vmovaps [rsp+0xB0], xmm12
000075d5269dfdc6  vmovaps [rsp+0xC0], xmm13
000075d5269dfdcf  vmovaps [rsp+0xD0], xmm14
000075d5269dfdd8  vmovaps [rsp+0xE0], xmm15
000075d5269dfde1  sub rsp, 0x30
000075d5269dfde5  movaps [rsp], xmm11
000075d5269dfdea  movaps [rsp+0x10], xmm10
000075d5269dfdf0  movaps [rsp+0x20], xmm6
000075d5269dfdf5  lea rdi, [rsp]
000075d5269dfdf9  mov esi, 0x00
000075d5269dfdfe  mov rax, 0x601129E62530
000075d5269dfe08  call rax
000075d5269dfe0a  movaps xmm11, [rsp]
000075d5269dfe0f  add rsp, 0x30
000075d5269dfe13  vmovaps xmm0, [rsp]
000075d5269dfe18  vmovaps xmm1, [rsp+0x10]
000075d5269dfe1e  vmovaps xmm2, [rsp+0x20]
000075d5269dfe24  vmovaps xmm3, [rsp+0x30]
000075d5269dfe2a  vmovaps xmm4, [rsp+0x40]
000075d5269dfe30  vmovaps xmm5, [rsp+0x50]
000075d5269dfe36  vmovaps xmm6, [rsp+0x60]
000075d5269dfe3c  vmovaps xmm7, [rsp+0x70]
000075d5269dfe42  vmovaps xmm8, [rsp+0x80]
000075d5269dfe4b  vmovaps xmm9, [rsp+0x90]
000075d5269dfe54  vmovaps xmm10, [rsp+0xA0]
000075d5269dfe5d  vmovaps xmm12, [rsp+0xB0]
000075d5269dfe66  vmovaps xmm13, [rsp+0xC0]
000075d5269dfe6f  vmovaps xmm14, [rsp+0xD0]
000075d5269dfe78  vmovaps xmm15, [rsp+0xE0]
000075d5269dfe81  add rsp, 0xF0
000075d5269dfe88  pop r11
000075d5269dfe8a  pop r10
000075d5269dfe8c  pop r9
000075d5269dfe8e  pop r8
000075d5269dfe90  pop rsi
000075d5269dfe91  pop rdi
000075d5269dfe92  pop rdx
000075d5269dfe93  pop rcx
000075d5269dfe94  pop rax
000075d5269dfe95  add rsp, 0x08
000075d5269dfe99  jmp 0x000075D5269DC520
000075d5269dfe9e  sub rsp, 0x08
000075d5269dfea2  push rax
000075d5269dfea3  push rcx
000075d5269dfea4  push rdx
000075d5269dfea5  push rdi
000075d5269dfea6  push rsi
000075d5269dfea7  push r8
000075d5269dfea9  push r9
000075d5269dfeab  push r10
000075d5269dfead  push r11
000075d5269dfeaf  sub rsp, 0xF0
000075d5269dfeb6  vmovaps [rsp], xmm0
000075d5269dfebb  vmovaps [rsp+0x10], xmm1
000075d5269dfec1  vmovaps [rsp+0x20], xmm2
000075d5269dfec7  vmovaps [rsp+0x30], xmm3
000075d5269dfecd  vmovaps [rsp+0x40], xmm4
000075d5269dfed3  vmovaps [rsp+0x50], xmm5
000075d5269dfed9  vmovaps [rsp+0x60], xmm6
000075d5269dfedf  vmovaps [rsp+0x70], xmm7
000075d5269dfee5  vmovaps [rsp+0x80], xmm8
000075d5269dfeee  vmovaps [rsp+0x90], xmm9
000075d5269dfef7  vmovaps [rsp+0xA0], xmm11
000075d5269dff00  vmovaps [rsp+0xB0], xmm12
000075d5269dff09  vmovaps [rsp+0xC0], xmm13
000075d5269dff12  vmovaps [rsp+0xD0], xmm14
000075d5269dff1b  vmovaps [rsp+0xE0], xmm15
000075d5269dff24  sub rsp, 0x30
000075d5269dff28  movaps [rsp], xmm10
000075d5269dff2d  movaps [rsp+0x10], xmm14
000075d5269dff33  movaps [rsp+0x20], xmm4
000075d5269dff38  lea rdi, [rsp]
000075d5269dff3c  mov esi, 0x00
000075d5269dff41  mov rax, 0x601129E62530
000075d5269dff4b  call rax
000075d5269dff4d  movaps xmm10, [rsp]
000075d5269dff52  add rsp, 0x30
000075d5269dff56  vmovaps xmm0, [rsp]
000075d5269dff5b  vmovaps xmm1, [rsp+0x10]
000075d5269dff61  vmovaps xmm2, [rsp+0x20]
000075d5269dff67  vmovaps xmm3, [rsp+0x30]
000075d5269dff6d  vmovaps xmm4, [rsp+0x40]
000075d5269dff73  vmovaps xmm5, [rsp+0x50]
000075d5269dff79  vmovaps xmm6, [rsp+0x60]
000075d5269dff7f  vmovaps xmm7, [rsp+0x70]
000075d5269dff85  vmovaps xmm8, [rsp+0x80]
000075d5269dff8e  vmovaps xmm9, [rsp+0x90]
000075d5269dff97  vmovaps xmm11, [rsp+0xA0]
000075d5269dffa0  vmovaps xmm12, [rsp+0xB0]
000075d5269dffa9  vmovaps xmm13, [rsp+0xC0]
000075d5269dffb2  vmovaps xmm14, [rsp+0xD0]
000075d5269dffbb  vmovaps xmm15, [rsp+0xE0]
000075d5269dffc4  add rsp, 0xF0
000075d5269dffcb  pop r11
000075d5269dffcd  pop r10
000075d5269dffcf  pop r9
000075d5269dffd1  pop r8
000075d5269dffd3  pop rsi
000075d5269dffd4  pop rdi
000075d5269dffd5  pop rdx
000075d5269dffd6  pop rcx
000075d5269dffd7  pop rax
000075d5269dffd8  add rsp, 0x08
000075d5269dffdc  jmp 0x000075D5269DC53B
000075d5269dffe1  sub rsp, 0x08
000075d5269dffe5  push rax
000075d5269dffe6  push rcx
000075d5269dffe7  push rdx
000075d5269dffe8  push rdi
000075d5269dffe9  push rsi
000075d5269dffea  push r8
000075d5269dffec  push r9
000075d5269dffee  push r10
000075d5269dfff0  push r11
000075d5269dfff2  sub rsp, 0xF0
000075d5269dfff9  vmovaps [rsp], xmm0
000075d5269dfffe  vmovaps [rsp+0x10], xmm1
000075d5269e0004  vmovaps [rsp+0x20], xmm2
000075d5269e000a  vmovaps [rsp+0x30], xmm3
000075d5269e0010  vmovaps [rsp+0x40], xmm4
000075d5269e0016  vmovaps [rsp+0x50], xmm5
000075d5269e001c  vmovaps [rsp+0x60], xmm6
000075d5269e0022  vmovaps [rsp+0x70], xmm7
000075d5269e0028  vmovaps [rsp+0x80], xmm9
000075d5269e0031  vmovaps [rsp+0x90], xmm10
000075d5269e003a  vmovaps [rsp+0xA0], xmm11
000075d5269e0043  vmovaps [rsp+0xB0], xmm12
000075d5269e004c  vmovaps [rsp+0xC0], xmm13
000075d5269e0055  vmovaps [rsp+0xD0], xmm14
000075d5269e005e  vmovaps [rsp+0xE0], xmm15
000075d5269e0067  sub rsp, 0x30
000075d5269e006b  movaps [rsp], xmm8
000075d5269e0070  movaps [rsp+0x10], xmm1
000075d5269e0075  movaps [rsp+0x20], xmm14
000075d5269e007b  lea rdi, [rsp]
000075d5269e007f  mov esi, 0x00
000075d5269e0084  mov rax, 0x601129E62530
000075d5269e008e  call rax
000075d5269e0090  movaps xmm8, [rsp]
000075d5269e0095  add rsp, 0x30
000075d5269e0099  vmovaps xmm0, [rsp]
000075d5269e009e  vmovaps xmm1, [rsp+0x10]
000075d5269e00a4  vmovaps xmm2, [rsp+0x20]
000075d5269e00aa  vmovaps xmm3, [rsp+0x30]
000075d5269e00b0  vmovaps xmm4, [rsp+0x40]
000075d5269e00b6  vmovaps xmm5, [rsp+0x50]
000075d5269e00bc  vmovaps xmm6, [rsp+0x60]
000075d5269e00c2  vmovaps xmm7, [rsp+0x70]
000075d5269e00c8  vmovaps xmm9, [rsp+0x80]
000075d5269e00d1  vmovaps xmm10, [rsp+0x90]
000075d5269e00da  vmovaps xmm11, [rsp+0xA0]
000075d5269e00e3  vmovaps xmm12, [rsp+0xB0]
000075d5269e00ec  vmovaps xmm13, [rsp+0xC0]
000075d5269e00f5  vmovaps xmm14, [rsp+0xD0]
000075d5269e00fe  vmovaps xmm15, [rsp+0xE0]
000075d5269e0107  add rsp, 0xF0
000075d5269e010e  pop r11
000075d5269e0110  pop r10
000075d5269e0112  pop r9
000075d5269e0114  pop r8
000075d5269e0116  pop rsi
000075d5269e0117  pop rdi
000075d5269e0118  pop rdx
000075d5269e0119  pop rcx
000075d5269e011a  pop rax
000075d5269e011b  add rsp, 0x08
000075d5269e011f  jmp 0x000075D5269DC561
000075d5269e0124  sub rsp, 0x08
000075d5269e0128  push rax
000075d5269e0129  push rcx
000075d5269e012a  push rdx
000075d5269e012b  push rdi
000075d5269e012c  push rsi
000075d5269e012d  push r8
000075d5269e012f  push r9
000075d5269e0131  push r10
000075d5269e0133  push r11
000075d5269e0135  sub rsp, 0xF0
000075d5269e013c  vmovaps [rsp], xmm0
000075d5269e0141  vmovaps [rsp+0x10], xmm1
000075d5269e0147  vmovaps [rsp+0x20], xmm2
000075d5269e014d  vmovaps [rsp+0x30], xmm3
000075d5269e0153  vmovaps [rsp+0x40], xmm4
000075d5269e0159  vmovaps [rsp+0x50], xmm5
000075d5269e015f  vmovaps [rsp+0x60], xmm7
000075d5269e0165  vmovaps [rsp+0x70], xmm8
000075d5269e016b  vmovaps [rsp+0x80], xmm9
000075d5269e0174  vmovaps [rsp+0x90], xmm10
000075d5269e017d  vmovaps [rsp+0xA0], xmm11
000075d5269e0186  vmovaps [rsp+0xB0], xmm12
000075d5269e018f  vmovaps [rsp+0xC0], xmm13
000075d5269e0198  vmovaps [rsp+0xD0], xmm14
000075d5269e01a1  vmovaps [rsp+0xE0], xmm15
000075d5269e01aa  sub rsp, 0x30
000075d5269e01ae  movaps [rsp], xmm6
000075d5269e01b2  movaps [rsp+0x10], xmm1
000075d5269e01b7  movaps [rsp+0x20], xmm14
000075d5269e01bd  lea rdi, [rsp]
000075d5269e01c1  mov esi, 0x00
000075d5269e01c6  mov rax, 0x601129E62530
000075d5269e01d0  call rax
000075d5269e01d2  movaps xmm6, [rsp]
000075d5269e01d6  add rsp, 0x30
000075d5269e01da  vmovaps xmm0, [rsp]
000075d5269e01df  vmovaps xmm1, [rsp+0x10]
000075d5269e01e5  vmovaps xmm2, [rsp+0x20]
000075d5269e01eb  vmovaps xmm3, [rsp+0x30]
000075d5269e01f1  vmovaps xmm4, [rsp+0x40]
000075d5269e01f7  vmovaps xmm5, [rsp+0x50]
000075d5269e01fd  vmovaps xmm7, [rsp+0x60]
000075d5269e0203  vmovaps xmm8, [rsp+0x70]
000075d5269e0209  vmovaps xmm9, [rsp+0x80]
000075d5269e0212  vmovaps xmm10, [rsp+0x90]
000075d5269e021b  vmovaps xmm11, [rsp+0xA0]
000075d5269e0224  vmovaps xmm12, [rsp+0xB0]
000075d5269e022d  vmovaps xmm13, [rsp+0xC0]
000075d5269e0236  vmovaps xmm14, [rsp+0xD0]
000075d5269e023f  vmovaps xmm15, [rsp+0xE0]
000075d5269e0248  add rsp, 0xF0
000075d5269e024f  pop r11
000075d5269e0251  pop r10
000075d5269e0253  pop r9
000075d5269e0255  pop r8
000075d5269e0257  pop rsi
000075d5269e0258  pop rdi
000075d5269e0259  pop rdx
000075d5269e025a  pop rcx
000075d5269e025b  pop rax
000075d5269e025c  add rsp, 0x08
000075d5269e0260  jmp 0x000075D5269DC58D
000075d5269e0265  sub rsp, 0x08
000075d5269e0269  push rax
000075d5269e026a  push rcx
000075d5269e026b  push rdx
000075d5269e026c  push rdi
000075d5269e026d  push rsi
000075d5269e026e  push r8
000075d5269e0270  push r9
000075d5269e0272  push r10
000075d5269e0274  push r11
000075d5269e0276  sub rsp, 0xF0
000075d5269e027d  vmovaps [rsp], xmm0
000075d5269e0282  vmovaps [rsp+0x10], xmm1
000075d5269e0288  vmovaps [rsp+0x20], xmm2
000075d5269e028e  vmovaps [rsp+0x30], xmm3
000075d5269e0294  vmovaps [rsp+0x40], xmm4
000075d5269e029a  vmovaps [rsp+0x50], xmm5
000075d5269e02a0  vmovaps [rsp+0x60], xmm6
000075d5269e02a6  vmovaps [rsp+0x70], xmm7
000075d5269e02ac  vmovaps [rsp+0x80], xmm8
000075d5269e02b5  vmovaps [rsp+0x90], xmm9
000075d5269e02be  vmovaps [rsp+0xA0], xmm10
000075d5269e02c7  vmovaps [rsp+0xB0], xmm11
000075d5269e02d0  vmovaps [rsp+0xC0], xmm12
000075d5269e02d9  vmovaps [rsp+0xD0], xmm13
000075d5269e02e2  vmovaps [rsp+0xE0], xmm15
000075d5269e02eb  sub rsp, 0x30
000075d5269e02ef  movaps [rsp], xmm14
000075d5269e02f4  movaps [rsp+0x10], xmm12
000075d5269e02fa  movaps [rsp+0x20], xmm1
000075d5269e02ff  lea rdi, [rsp]
000075d5269e0303  mov esi, 0x00
000075d5269e0308  mov rax, 0x601129E62530
000075d5269e0312  call rax
000075d5269e0314  movaps xmm14, [rsp]
000075d5269e0319  add rsp, 0x30
000075d5269e031d  vmovaps xmm0, [rsp]
000075d5269e0322  vmovaps xmm1, [rsp+0x10]
000075d5269e0328  vmovaps xmm2, [rsp+0x20]
000075d5269e032e  vmovaps xmm3, [rsp+0x30]
000075d5269e0334  vmovaps xmm4, [rsp+0x40]
000075d5269e033a  vmovaps xmm5, [rsp+0x50]
000075d5269e0340  vmovaps xmm6, [rsp+0x60]
000075d5269e0346  vmovaps xmm7, [rsp+0x70]
000075d5269e034c  vmovaps xmm8, [rsp+0x80]
000075d5269e0355  vmovaps xmm9, [rsp+0x90]
000075d5269e035e  vmovaps xmm10, [rsp+0xA0]
000075d5269e0367  vmovaps xmm11, [rsp+0xB0]
000075d5269e0370  vmovaps xmm12, [rsp+0xC0]
000075d5269e0379  vmovaps xmm13, [rsp+0xD0]
000075d5269e0382  vmovaps xmm15, [rsp+0xE0]
000075d5269e038b  add rsp, 0xF0
000075d5269e0392  pop r11
000075d5269e0394  pop r10
000075d5269e0396  pop r9
000075d5269e0398  pop r8
000075d5269e039a  pop rsi
000075d5269e039b  pop rdi
000075d5269e039c  pop rdx
000075d5269e039d  pop rcx
000075d5269e039e  pop rax
000075d5269e039f  add rsp, 0x08
000075d5269e03a3  jmp 0x000075D5269DC5B3
000075d5269e03a8  sub rsp, 0x08
000075d5269e03ac  push rax
000075d5269e03ad  push rcx
000075d5269e03ae  push rdx
000075d5269e03af  push rdi
000075d5269e03b0  push rsi
000075d5269e03b1  push r8
000075d5269e03b3  push r9
000075d5269e03b5  push r10
000075d5269e03b7  push r11
000075d5269e03b9  sub rsp, 0xF0
000075d5269e03c0  vmovaps [rsp], xmm0
000075d5269e03c5  vmovaps [rsp+0x10], xmm2
000075d5269e03cb  vmovaps [rsp+0x20], xmm3
000075d5269e03d1  vmovaps [rsp+0x30], xmm4
000075d5269e03d7  vmovaps [rsp+0x40], xmm5
000075d5269e03dd  vmovaps [rsp+0x50], xmm6
000075d5269e03e3  vmovaps [rsp+0x60], xmm7
000075d5269e03e9  vmovaps [rsp+0x70], xmm8
000075d5269e03ef  vmovaps [rsp+0x80], xmm9
000075d5269e03f8  vmovaps [rsp+0x90], xmm10
000075d5269e0401  vmovaps [rsp+0xA0], xmm11
000075d5269e040a  vmovaps [rsp+0xB0], xmm12
000075d5269e0413  vmovaps [rsp+0xC0], xmm13
000075d5269e041c  vmovaps [rsp+0xD0], xmm14
000075d5269e0425  vmovaps [rsp+0xE0], xmm15
000075d5269e042e  sub rsp, 0x30
000075d5269e0432  movaps [rsp], xmm1
000075d5269e0436  movaps [rsp+0x10], xmm13
000075d5269e043c  movaps [rsp+0x20], xmm9
000075d5269e0442  lea rdi, [rsp]
000075d5269e0446  mov esi, 0x00
000075d5269e044b  mov rax, 0x601129E62530
000075d5269e0455  call rax
000075d5269e0457  movaps xmm1, [rsp]
000075d5269e045b  add rsp, 0x30
000075d5269e045f  vmovaps xmm0, [rsp]
000075d5269e0464  vmovaps xmm2, [rsp+0x10]
000075d5269e046a  vmovaps xmm3, [rsp+0x20]
000075d5269e0470  vmovaps xmm4, [rsp+0x30]
000075d5269e0476  vmovaps xmm5, [rsp+0x40]
000075d5269e047c  vmovaps xmm6, [rsp+0x50]
000075d5269e0482  vmovaps xmm7, [rsp+0x60]
000075d5269e0488  vmovaps xmm8, [rsp+0x70]
000075d5269e048e  vmovaps xmm9, [rsp+0x80]
000075d5269e0497  vmovaps xmm10, [rsp+0x90]
000075d5269e04a0  vmovaps xmm11, [rsp+0xA0]
000075d5269e04a9  vmovaps xmm12, [rsp+0xB0]
000075d5269e04b2  vmovaps xmm13, [rsp+0xC0]
000075d5269e04bb  vmovaps xmm14, [rsp+0xD0]
000075d5269e04c4  vmovaps xmm15, [rsp+0xE0]
000075d5269e04cd  add rsp, 0xF0
000075d5269e04d4  pop r11
000075d5269e04d6  pop r10
000075d5269e04d8  pop r9
000075d5269e04da  pop r8
000075d5269e04dc  pop rsi
000075d5269e04dd  pop rdi
000075d5269e04de  pop rdx
000075d5269e04df  pop rcx
000075d5269e04e0  pop rax
000075d5269e04e1  add rsp, 0x08
000075d5269e04e5  jmp 0x000075D5269DC5CD
000075d5269e04ea  sub rsp, 0x08
000075d5269e04ee  push rax
000075d5269e04ef  push rcx
000075d5269e04f0  push rdx
000075d5269e04f1  push rdi
000075d5269e04f2  push rsi
000075d5269e04f3  push r8
000075d5269e04f5  push r9
000075d5269e04f7  push r10
000075d5269e04f9  push r11
000075d5269e04fb  sub rsp, 0xF0
000075d5269e0502  vmovaps [rsp], xmm0
000075d5269e0507  vmovaps [rsp+0x10], xmm1
000075d5269e050d  vmovaps [rsp+0x20], xmm2
000075d5269e0513  vmovaps [rsp+0x30], xmm3
000075d5269e0519  vmovaps [rsp+0x40], xmm4
000075d5269e051f  vmovaps [rsp+0x50], xmm5
000075d5269e0525  vmovaps [rsp+0x60], xmm6
000075d5269e052b  vmovaps [rsp+0x70], xmm7
000075d5269e0531  vmovaps [rsp+0x80], xmm8
000075d5269e053a  vmovaps [rsp+0x90], xmm9
000075d5269e0543  vmovaps [rsp+0xA0], xmm10
000075d5269e054c  vmovaps [rsp+0xB0], xmm11
000075d5269e0555  vmovaps [rsp+0xC0], xmm13
000075d5269e055e  vmovaps [rsp+0xD0], xmm14
000075d5269e0567  vmovaps [rsp+0xE0], xmm15
000075d5269e0570  sub rsp, 0x30
000075d5269e0574  movaps [rsp], xmm12
000075d5269e0579  movaps [rsp+0x10], xmm7
000075d5269e057e  movaps [rsp+0x20], xmm13
000075d5269e0584  lea rdi, [rsp]
000075d5269e0588  mov esi, 0x00
000075d5269e058d  mov rax, 0x601129E62530
000075d5269e0597  call rax
000075d5269e0599  movaps xmm12, [rsp]
000075d5269e059e  add rsp, 0x30
000075d5269e05a2  vmovaps xmm0, [rsp]
000075d5269e05a7  vmovaps xmm1, [rsp+0x10]
000075d5269e05ad  vmovaps xmm2, [rsp+0x20]
000075d5269e05b3  vmovaps xmm3, [rsp+0x30]
000075d5269e05b9  vmovaps xmm4, [rsp+0x40]
000075d5269e05bf  vmovaps xmm5, [rsp+0x50]
000075d5269e05c5  vmovaps xmm6, [rsp+0x60]
000075d5269e05cb  vmovaps xmm7, [rsp+0x70]
000075d5269e05d1  vmovaps xmm8, [rsp+0x80]
000075d5269e05da  vmovaps xmm9, [rsp+0x90]
000075d5269e05e3  vmovaps xmm10, [rsp+0xA0]
000075d5269e05ec  vmovaps xmm11, [rsp+0xB0]
000075d5269e05f5  vmovaps xmm13, [rsp+0xC0]
000075d5269e05fe  vmovaps xmm14, [rsp+0xD0]
000075d5269e0607  vmovaps xmm15, [rsp+0xE0]
000075d5269e0610  add rsp, 0xF0
000075d5269e0617  pop r11
000075d5269e0619  pop r10
000075d5269e061b  pop r9
000075d5269e061d  pop r8
000075d5269e061f  pop rsi
000075d5269e0620  pop rdi
000075d5269e0621  pop rdx
000075d5269e0622  pop rcx
000075d5269e0623  pop rax
000075d5269e0624  add rsp, 0x08
000075d5269e0628  jmp 0x000075D5269DC5F4
000075d5269e062d  sub rsp, 0x08
000075d5269e0631  push rax
000075d5269e0632  push rcx
000075d5269e0633  push rdx
000075d5269e0634  push rdi
000075d5269e0635  push rsi
000075d5269e0636  push r8
000075d5269e0638  push r9
000075d5269e063a  push r10
000075d5269e063c  push r11
000075d5269e063e  sub rsp, 0xF0
000075d5269e0645  vmovaps [rsp], xmm0
000075d5269e064a  vmovaps [rsp+0x10], xmm1
000075d5269e0650  vmovaps [rsp+0x20], xmm2
000075d5269e0656  vmovaps [rsp+0x30], xmm3
000075d5269e065c  vmovaps [rsp+0x40], xmm4
000075d5269e0662  vmovaps [rsp+0x50], xmm5
000075d5269e0668  vmovaps [rsp+0x60], xmm6
000075d5269e066e  vmovaps [rsp+0x70], xmm7
000075d5269e0674  vmovaps [rsp+0x80], xmm8
000075d5269e067d  vmovaps [rsp+0x90], xmm9
000075d5269e0686  vmovaps [rsp+0xA0], xmm10
000075d5269e068f  vmovaps [rsp+0xB0], xmm11
000075d5269e0698  vmovaps [rsp+0xC0], xmm12
000075d5269e06a1  vmovaps [rsp+0xD0], xmm14
000075d5269e06aa  vmovaps [rsp+0xE0], xmm15
000075d5269e06b3  sub rsp, 0x30
000075d5269e06b7  movaps [rsp], xmm13
000075d5269e06bc  movaps [rsp+0x10], xmm15
000075d5269e06c2  movaps [rsp+0x20], xmm8
000075d5269e06c8  lea rdi, [rsp]
000075d5269e06cc  mov esi, 0x00
000075d5269e06d1  mov rax, 0x601129E62530
000075d5269e06db  call rax
000075d5269e06dd  movaps xmm13, [rsp]
000075d5269e06e2  add rsp, 0x30
000075d5269e06e6  vmovaps xmm0, [rsp]
000075d5269e06eb  vmovaps xmm1, [rsp+0x10]
000075d5269e06f1  vmovaps xmm2, [rsp+0x20]
000075d5269e06f7  vmovaps xmm3, [rsp+0x30]
000075d5269e06fd  vmovaps xmm4, [rsp+0x40]
000075d5269e0703  vmovaps xmm5, [rsp+0x50]
000075d5269e0709  vmovaps xmm6, [rsp+0x60]
000075d5269e070f  vmovaps xmm7, [rsp+0x70]
000075d5269e0715  vmovaps xmm8, [rsp+0x80]
000075d5269e071e  vmovaps xmm9, [rsp+0x90]
000075d5269e0727  vmovaps xmm10, [rsp+0xA0]
000075d5269e0730  vmovaps xmm11, [rsp+0xB0]
000075d5269e0739  vmovaps xmm12, [rsp+0xC0]
000075d5269e0742  vmovaps xmm14, [rsp+0xD0]
000075d5269e074b  vmovaps xmm15, [rsp+0xE0]
000075d5269e0754  add rsp, 0xF0
000075d5269e075b  pop r11
000075d5269e075d  pop r10
000075d5269e075f  pop r9
000075d5269e0761  pop r8
000075d5269e0763  pop rsi
000075d5269e0764  pop rdi
000075d5269e0765  pop rdx
000075d5269e0766  pop rcx
000075d5269e0767  pop rax
000075d5269e0768  add rsp, 0x08
000075d5269e076c  jmp 0x000075D5269DC60F
000075d5269e0771  sub rsp, 0x08
000075d5269e0775  push rax
000075d5269e0776  push rcx
000075d5269e0777  push rdx
000075d5269e0778  push rdi
000075d5269e0779  push rsi
000075d5269e077a  push r8
000075d5269e077c  push r9
000075d5269e077e  push r10
000075d5269e0780  push r11
000075d5269e0782  sub rsp, 0xF0
000075d5269e0789  vmovaps [rsp], xmm0
000075d5269e078e  vmovaps [rsp+0x10], xmm1
000075d5269e0794  vmovaps [rsp+0x20], xmm2
000075d5269e079a  vmovaps [rsp+0x30], xmm3
000075d5269e07a0  vmovaps [rsp+0x40], xmm4
000075d5269e07a6  vmovaps [rsp+0x50], xmm5
000075d5269e07ac  vmovaps [rsp+0x60], xmm6
000075d5269e07b2  vmovaps [rsp+0x70], xmm7
000075d5269e07b8  vmovaps [rsp+0x80], xmm9
000075d5269e07c1  vmovaps [rsp+0x90], xmm10
000075d5269e07ca  vmovaps [rsp+0xA0], xmm11
000075d5269e07d3  vmovaps [rsp+0xB0], xmm12
000075d5269e07dc  vmovaps [rsp+0xC0], xmm13
000075d5269e07e5  vmovaps [rsp+0xD0], xmm14
000075d5269e07ee  vmovaps [rsp+0xE0], xmm15
000075d5269e07f7  sub rsp, 0x30
000075d5269e07fb  movaps [rsp], xmm8
000075d5269e0800  movaps [rsp+0x10], xmm15
000075d5269e0806  movaps [rsp+0x20], xmm9
000075d5269e080c  lea rdi, [rsp]
000075d5269e0810  mov esi, 0x00
000075d5269e0815  mov rax, 0x601129E62530
000075d5269e081f  call rax
000075d5269e0821  movaps xmm8, [rsp]
000075d5269e0826  add rsp, 0x30
000075d5269e082a  vmovaps xmm0, [rsp]
000075d5269e082f  vmovaps xmm1, [rsp+0x10]
000075d5269e0835  vmovaps xmm2, [rsp+0x20]
000075d5269e083b  vmovaps xmm3, [rsp+0x30]
000075d5269e0841  vmovaps xmm4, [rsp+0x40]
000075d5269e0847  vmovaps xmm5, [rsp+0x50]
000075d5269e084d  vmovaps xmm6, [rsp+0x60]
000075d5269e0853  vmovaps xmm7, [rsp+0x70]
000075d5269e0859  vmovaps xmm9, [rsp+0x80]
000075d5269e0862  vmovaps xmm10, [rsp+0x90]
000075d5269e086b  vmovaps xmm11, [rsp+0xA0]
000075d5269e0874  vmovaps xmm12, [rsp+0xB0]
000075d5269e087d  vmovaps xmm13, [rsp+0xC0]
000075d5269e0886  vmovaps xmm14, [rsp+0xD0]
000075d5269e088f  vmovaps xmm15, [rsp+0xE0]
000075d5269e0898  add rsp, 0xF0
000075d5269e089f  pop r11
000075d5269e08a1  pop r10
000075d5269e08a3  pop r9
000075d5269e08a5  pop r8
000075d5269e08a7  pop rsi
000075d5269e08a8  pop rdi
000075d5269e08a9  pop rdx
000075d5269e08aa  pop rcx
000075d5269e08ab  pop rax
000075d5269e08ac  add rsp, 0x08
000075d5269e08b0  jmp 0x000075D5269DC63D
000075d5269e08b5  sub rsp, 0x08
000075d5269e08b9  push rax
000075d5269e08ba  push rcx
000075d5269e08bb  push rdx
000075d5269e08bc  push rdi
000075d5269e08bd  push rsi
000075d5269e08be  push r8
000075d5269e08c0  push r9
000075d5269e08c2  push r10
000075d5269e08c4  push r11
000075d5269e08c6  sub rsp, 0xF0
000075d5269e08cd  vmovaps [rsp], xmm0
000075d5269e08d2  vmovaps [rsp+0x10], xmm1
000075d5269e08d8  vmovaps [rsp+0x20], xmm2
000075d5269e08de  vmovaps [rsp+0x30], xmm3
000075d5269e08e4  vmovaps [rsp+0x40], xmm4
000075d5269e08ea  vmovaps [rsp+0x50], xmm5
000075d5269e08f0  vmovaps [rsp+0x60], xmm6
000075d5269e08f6  vmovaps [rsp+0x70], xmm7
000075d5269e08fc  vmovaps [rsp+0x80], xmm8
000075d5269e0905  vmovaps [rsp+0x90], xmm9
000075d5269e090e  vmovaps [rsp+0xA0], xmm10
000075d5269e0917  vmovaps [rsp+0xB0], xmm11
000075d5269e0920  vmovaps [rsp+0xC0], xmm12
000075d5269e0929  vmovaps [rsp+0xD0], xmm13
000075d5269e0932  vmovaps [rsp+0xE0], xmm14
000075d5269e093b  sub rsp, 0x30
000075d5269e093f  movaps [rsp], xmm15
000075d5269e0944  movaps [rsp+0x10], xmm11
000075d5269e094a  movaps [rsp+0x20], xmm6
000075d5269e094f  lea rdi, [rsp]
000075d5269e0953  mov esi, 0x00
000075d5269e0958  mov rax, 0x601129E62530
000075d5269e0962  call rax
000075d5269e0964  movaps xmm15, [rsp]
000075d5269e0969  add rsp, 0x30
000075d5269e096d  vmovaps xmm0, [rsp]
000075d5269e0972  vmovaps xmm1, [rsp+0x10]
000075d5269e0978  vmovaps xmm2, [rsp+0x20]
000075d5269e097e  vmovaps xmm3, [rsp+0x30]
000075d5269e0984  vmovaps xmm4, [rsp+0x40]
000075d5269e098a  vmovaps xmm5, [rsp+0x50]
000075d5269e0990  vmovaps xmm6, [rsp+0x60]
000075d5269e0996  vmovaps xmm7, [rsp+0x70]
000075d5269e099c  vmovaps xmm8, [rsp+0x80]
000075d5269e09a5  vmovaps xmm9, [rsp+0x90]
000075d5269e09ae  vmovaps xmm10, [rsp+0xA0]
000075d5269e09b7  vmovaps xmm11, [rsp+0xB0]
000075d5269e09c0  vmovaps xmm12, [rsp+0xC0]
000075d5269e09c9  vmovaps xmm13, [rsp+0xD0]
000075d5269e09d2  vmovaps xmm14, [rsp+0xE0]
000075d5269e09db  add rsp, 0xF0
000075d5269e09e2  pop r11
000075d5269e09e4  pop r10
000075d5269e09e6  pop r9
000075d5269e09e8  pop r8
000075d5269e09ea  pop rsi
000075d5269e09eb  pop rdi
000075d5269e09ec  pop rdx
000075d5269e09ed  pop rcx
000075d5269e09ee  pop rax
000075d5269e09ef  add rsp, 0x08
000075d5269e09f3  jmp 0x000075D5269DC658
000075d5269e09f8  sub rsp, 0x08
000075d5269e09fc  push rax
000075d5269e09fd  push rcx
000075d5269e09fe  push rdx
000075d5269e09ff  push rdi
000075d5269e0a00  push rsi
000075d5269e0a01  push r8
000075d5269e0a03  push r9
000075d5269e0a05  push r10
000075d5269e0a07  push r11
000075d5269e0a09  sub rsp, 0xF0
000075d5269e0a10  vmovaps [rsp], xmm0
000075d5269e0a15  vmovaps [rsp+0x10], xmm1
000075d5269e0a1b  vmovaps [rsp+0x20], xmm2
000075d5269e0a21  vmovaps [rsp+0x30], xmm3
000075d5269e0a27  vmovaps [rsp+0x40], xmm4
000075d5269e0a2d  vmovaps [rsp+0x50], xmm5
000075d5269e0a33  vmovaps [rsp+0x60], xmm6
000075d5269e0a39  vmovaps [rsp+0x70], xmm8
000075d5269e0a3f  vmovaps [rsp+0x80], xmm9
000075d5269e0a48  vmovaps [rsp+0x90], xmm10
000075d5269e0a51  vmovaps [rsp+0xA0], xmm11
000075d5269e0a5a  vmovaps [rsp+0xB0], xmm12
000075d5269e0a63  vmovaps [rsp+0xC0], xmm13
000075d5269e0a6c  vmovaps [rsp+0xD0], xmm14
000075d5269e0a75  vmovaps [rsp+0xE0], xmm15
000075d5269e0a7e  sub rsp, 0x30
000075d5269e0a82  movaps [rsp], xmm7
000075d5269e0a86  movaps [rsp+0x10], xmm11
000075d5269e0a8c  movaps [rsp+0x20], xmm9
000075d5269e0a92  lea rdi, [rsp]
000075d5269e0a96  mov esi, 0x00
000075d5269e0a9b  mov rax, 0x601129E62530
000075d5269e0aa5  call rax
000075d5269e0aa7  movaps xmm7, [rsp]
000075d5269e0aab  add rsp, 0x30
000075d5269e0aaf  vmovaps xmm0, [rsp]
000075d5269e0ab4  vmovaps xmm1, [rsp+0x10]
000075d5269e0aba  vmovaps xmm2, [rsp+0x20]
000075d5269e0ac0  vmovaps xmm3, [rsp+0x30]
000075d5269e0ac6  vmovaps xmm4, [rsp+0x40]
000075d5269e0acc  vmovaps xmm5, [rsp+0x50]
000075d5269e0ad2  vmovaps xmm6, [rsp+0x60]
000075d5269e0ad8  vmovaps xmm8, [rsp+0x70]
000075d5269e0ade  vmovaps xmm9, [rsp+0x80]
000075d5269e0ae7  vmovaps xmm10, [rsp+0x90]
000075d5269e0af0  vmovaps xmm11, [rsp+0xA0]
000075d5269e0af9  vmovaps xmm12, [rsp+0xB0]
000075d5269e0b02  vmovaps xmm13, [rsp+0xC0]
000075d5269e0b0b  vmovaps xmm14, [rsp+0xD0]
000075d5269e0b14  vmovaps xmm15, [rsp+0xE0]
000075d5269e0b1d  add rsp, 0xF0
000075d5269e0b24  pop r11
000075d5269e0b26  pop r10
000075d5269e0b28  pop r9
000075d5269e0b2a  pop r8
000075d5269e0b2c  pop rsi
000075d5269e0b2d  pop rdi
000075d5269e0b2e  pop rdx
000075d5269e0b2f  pop rcx
000075d5269e0b30  pop rax
000075d5269e0b31  add rsp, 0x08
000075d5269e0b35  jmp 0x000075D5269DC685
000075d5269e0b3a  sub rsp, 0x08
000075d5269e0b3e  push rax
000075d5269e0b3f  push rcx
000075d5269e0b40  push rdx
000075d5269e0b41  push rdi
000075d5269e0b42  push rsi
000075d5269e0b43  push r8
000075d5269e0b45  push r9
000075d5269e0b47  push r10
000075d5269e0b49  push r11
000075d5269e0b4b  sub rsp, 0xF0
000075d5269e0b52  vmovaps [rsp], xmm0
000075d5269e0b57  vmovaps [rsp+0x10], xmm1
000075d5269e0b5d  vmovaps [rsp+0x20], xmm2
000075d5269e0b63  vmovaps [rsp+0x30], xmm3
000075d5269e0b69  vmovaps [rsp+0x40], xmm4
000075d5269e0b6f  vmovaps [rsp+0x50], xmm5
000075d5269e0b75  vmovaps [rsp+0x60], xmm6
000075d5269e0b7b  vmovaps [rsp+0x70], xmm7
000075d5269e0b81  vmovaps [rsp+0x80], xmm8
000075d5269e0b8a  vmovaps [rsp+0x90], xmm9
000075d5269e0b93  vmovaps [rsp+0xA0], xmm10
000075d5269e0b9c  vmovaps [rsp+0xB0], xmm12
000075d5269e0ba5  vmovaps [rsp+0xC0], xmm13
000075d5269e0bae  vmovaps [rsp+0xD0], xmm14
000075d5269e0bb7  vmovaps [rsp+0xE0], xmm15
000075d5269e0bc0  sub rsp, 0x30
000075d5269e0bc4  movaps [rsp], xmm11
000075d5269e0bc9  movaps [rsp+0x10], xmm10
000075d5269e0bcf  movaps [rsp+0x20], xmm14
000075d5269e0bd5  lea rdi, [rsp]
000075d5269e0bd9  mov esi, 0x00
000075d5269e0bde  mov rax, 0x601129E62530
000075d5269e0be8  call rax
000075d5269e0bea  movaps xmm11, [rsp]
000075d5269e0bef  add rsp, 0x30
000075d5269e0bf3  vmovaps xmm0, [rsp]
000075d5269e0bf8  vmovaps xmm1, [rsp+0x10]
000075d5269e0bfe  vmovaps xmm2, [rsp+0x20]
000075d5269e0c04  vmovaps xmm3, [rsp+0x30]
000075d5269e0c0a  vmovaps xmm4, [rsp+0x40]
000075d5269e0c10  vmovaps xmm5, [rsp+0x50]
000075d5269e0c16  vmovaps xmm6, [rsp+0x60]
000075d5269e0c1c  vmovaps xmm7, [rsp+0x70]
000075d5269e0c22  vmovaps xmm8, [rsp+0x80]
000075d5269e0c2b  vmovaps xmm9, [rsp+0x90]
000075d5269e0c34  vmovaps xmm10, [rsp+0xA0]
000075d5269e0c3d  vmovaps xmm12, [rsp+0xB0]
000075d5269e0c46  vmovaps xmm13, [rsp+0xC0]
000075d5269e0c4f  vmovaps xmm14, [rsp+0xD0]
000075d5269e0c58  vmovaps xmm15, [rsp+0xE0]
000075d5269e0c61  add rsp, 0xF0
000075d5269e0c68  pop r11
000075d5269e0c6a  pop r10
000075d5269e0c6c  pop r9
000075d5269e0c6e  pop r8
000075d5269e0c70  pop rsi
000075d5269e0c71  pop rdi
000075d5269e0c72  pop rdx
000075d5269e0c73  pop rcx
000075d5269e0c74  pop rax
000075d5269e0c75  add rsp, 0x08
000075d5269e0c79  jmp 0x000075D5269DC6A0
000075d5269e0c7e  call 0x000075D5268C33A0
000075d5269e0c83  jmp 0x000075D5269DC6AA
000075d5269e0c88  sub rsp, 0x08
000075d5269e0c8c  push rax
000075d5269e0c8d  push rcx
000075d5269e0c8e  push rdx
000075d5269e0c8f  push rdi
000075d5269e0c90  push rsi
000075d5269e0c91  push r8
000075d5269e0c93  push r9
000075d5269e0c95  push r10
000075d5269e0c97  push r11
000075d5269e0c99  sub rsp, 0xF0
000075d5269e0ca0  vmovaps [rsp], xmm0
000075d5269e0ca5  vmovaps [rsp+0x10], xmm1
000075d5269e0cab  vmovaps [rsp+0x20], xmm2
000075d5269e0cb1  vmovaps [rsp+0x30], xmm3
000075d5269e0cb7  vmovaps [rsp+0x40], xmm4
000075d5269e0cbd  vmovaps [rsp+0x50], xmm5
000075d5269e0cc3  vmovaps [rsp+0x60], xmm6
000075d5269e0cc9  vmovaps [rsp+0x70], xmm7
000075d5269e0ccf  vmovaps [rsp+0x80], xmm8
000075d5269e0cd8  vmovaps [rsp+0x90], xmm9
000075d5269e0ce1  vmovaps [rsp+0xA0], xmm11
000075d5269e0cea  vmovaps [rsp+0xB0], xmm12
000075d5269e0cf3  vmovaps [rsp+0xC0], xmm13
000075d5269e0cfc  vmovaps [rsp+0xD0], xmm14
000075d5269e0d05  vmovaps [rsp+0xE0], xmm15
000075d5269e0d0e  sub rsp, 0x30
000075d5269e0d12  movaps [rsp], xmm10
000075d5269e0d17  movaps [rsp+0x10], xmm1
000075d5269e0d1c  movaps [rsp+0x20], xmm12
000075d5269e0d22  lea rdi, [rsp]
000075d5269e0d26  mov esi, 0x00
000075d5269e0d2b  mov rax, 0x601129E62530
000075d5269e0d35  call rax
000075d5269e0d37  movaps xmm10, [rsp]
000075d5269e0d3c  add rsp, 0x30
000075d5269e0d40  vmovaps xmm0, [rsp]
000075d5269e0d45  vmovaps xmm1, [rsp+0x10]
000075d5269e0d4b  vmovaps xmm2, [rsp+0x20]
000075d5269e0d51  vmovaps xmm3, [rsp+0x30]
000075d5269e0d57  vmovaps xmm4, [rsp+0x40]
000075d5269e0d5d  vmovaps xmm5, [rsp+0x50]
000075d5269e0d63  vmovaps xmm6, [rsp+0x60]
000075d5269e0d69  vmovaps xmm7, [rsp+0x70]
000075d5269e0d6f  vmovaps xmm8, [rsp+0x80]
000075d5269e0d78  vmovaps xmm9, [rsp+0x90]
000075d5269e0d81  vmovaps xmm11, [rsp+0xA0]
000075d5269e0d8a  vmovaps xmm12, [rsp+0xB0]
000075d5269e0d93  vmovaps xmm13, [rsp+0xC0]
000075d5269e0d9c  vmovaps xmm14, [rsp+0xD0]
000075d5269e0da5  vmovaps xmm15, [rsp+0xE0]
000075d5269e0dae  add rsp, 0xF0
000075d5269e0db5  pop r11
000075d5269e0db7  pop r10
000075d5269e0db9  pop r9
000075d5269e0dbb  pop r8
000075d5269e0dbd  pop rsi
000075d5269e0dbe  pop rdi
000075d5269e0dbf  pop rdx
000075d5269e0dc0  pop rcx
000075d5269e0dc1  pop rax
000075d5269e0dc2  add rsp, 0x08
000075d5269e0dc6  jmp 0x000075D5269DC6CD
000075d5269e0dcb  sub rsp, 0x08
000075d5269e0dcf  push rax
000075d5269e0dd0  push rcx
000075d5269e0dd1  push rdx
000075d5269e0dd2  push rdi
000075d5269e0dd3  push rsi
000075d5269e0dd4  push r8
000075d5269e0dd6  push r9
000075d5269e0dd8  push r10
000075d5269e0dda  push r11
000075d5269e0ddc  sub rsp, 0xF0
000075d5269e0de3  vmovaps [rsp], xmm0
000075d5269e0de8  vmovaps [rsp+0x10], xmm1
000075d5269e0dee  vmovaps [rsp+0x20], xmm2
000075d5269e0df4  vmovaps [rsp+0x30], xmm3
000075d5269e0dfa  vmovaps [rsp+0x40], xmm4
000075d5269e0e00  vmovaps [rsp+0x50], xmm5
000075d5269e0e06  vmovaps [rsp+0x60], xmm6
000075d5269e0e0c  vmovaps [rsp+0x70], xmm7
000075d5269e0e12  vmovaps [rsp+0x80], xmm8
000075d5269e0e1b  vmovaps [rsp+0x90], xmm9
000075d5269e0e24  vmovaps [rsp+0xA0], xmm10
000075d5269e0e2d  vmovaps [rsp+0xB0], xmm11
000075d5269e0e36  vmovaps [rsp+0xC0], xmm13
000075d5269e0e3f  vmovaps [rsp+0xD0], xmm14
000075d5269e0e48  vmovaps [rsp+0xE0], xmm15
000075d5269e0e51  sub rsp, 0x30
000075d5269e0e55  movaps [rsp], xmm12
000075d5269e0e5a  movaps [rsp+0x10], xmm14
000075d5269e0e60  movaps [rsp+0x20], xmm1
000075d5269e0e65  lea rdi, [rsp]
000075d5269e0e69  mov esi, 0x00
000075d5269e0e6e  mov rax, 0x601129E62530
000075d5269e0e78  call rax
000075d5269e0e7a  movaps xmm12, [rsp]
000075d5269e0e7f  add rsp, 0x30
000075d5269e0e83  vmovaps xmm0, [rsp]
000075d5269e0e88  vmovaps xmm1, [rsp+0x10]
000075d5269e0e8e  vmovaps xmm2, [rsp+0x20]
000075d5269e0e94  vmovaps xmm3, [rsp+0x30]
000075d5269e0e9a  vmovaps xmm4, [rsp+0x40]
000075d5269e0ea0  vmovaps xmm5, [rsp+0x50]
000075d5269e0ea6  vmovaps xmm6, [rsp+0x60]
000075d5269e0eac  vmovaps xmm7, [rsp+0x70]
000075d5269e0eb2  vmovaps xmm8, [rsp+0x80]
000075d5269e0ebb  vmovaps xmm9, [rsp+0x90]
000075d5269e0ec4  vmovaps xmm10, [rsp+0xA0]
000075d5269e0ecd  vmovaps xmm11, [rsp+0xB0]
000075d5269e0ed6  vmovaps xmm13, [rsp+0xC0]
000075d5269e0edf  vmovaps xmm14, [rsp+0xD0]
000075d5269e0ee8  vmovaps xmm15, [rsp+0xE0]
000075d5269e0ef1  add rsp, 0xF0
000075d5269e0ef8  pop r11
000075d5269e0efa  pop r10
000075d5269e0efc  pop r9
000075d5269e0efe  pop r8
000075d5269e0f00  pop rsi
000075d5269e0f01  pop rdi
000075d5269e0f02  pop rdx
000075d5269e0f03  pop rcx
000075d5269e0f04  pop rax
000075d5269e0f05  add rsp, 0x08
000075d5269e0f09  jmp 0x000075D5269DC6FC
000075d5269e0f0e  sub rsp, 0x08
000075d5269e0f12  push rax
000075d5269e0f13  push rcx
000075d5269e0f14  push rdx
000075d5269e0f15  push rdi
000075d5269e0f16  push rsi
000075d5269e0f17  push r8
000075d5269e0f19  push r9
000075d5269e0f1b  push r10
000075d5269e0f1d  push r11
000075d5269e0f1f  sub rsp, 0xF0
000075d5269e0f26  vmovaps [rsp], xmm0
000075d5269e0f2b  vmovaps [rsp+0x10], xmm1
000075d5269e0f31  vmovaps [rsp+0x20], xmm2
000075d5269e0f37  vmovaps [rsp+0x30], xmm3
000075d5269e0f3d  vmovaps [rsp+0x40], xmm4
000075d5269e0f43  vmovaps [rsp+0x50], xmm5
000075d5269e0f49  vmovaps [rsp+0x60], xmm6
000075d5269e0f4f  vmovaps [rsp+0x70], xmm7
000075d5269e0f55  vmovaps [rsp+0x80], xmm8
000075d5269e0f5e  vmovaps [rsp+0x90], xmm9
000075d5269e0f67  vmovaps [rsp+0xA0], xmm10
000075d5269e0f70  vmovaps [rsp+0xB0], xmm11
000075d5269e0f79  vmovaps [rsp+0xC0], xmm12
000075d5269e0f82  vmovaps [rsp+0xD0], xmm13
000075d5269e0f8b  vmovaps [rsp+0xE0], xmm15
000075d5269e0f94  sub rsp, 0x30
000075d5269e0f98  movaps [rsp], xmm14
000075d5269e0f9d  movaps [rsp+0x10], xmm9
000075d5269e0fa3  movaps [rsp+0x20], xmm1
000075d5269e0fa8  lea rdi, [rsp]
000075d5269e0fac  mov esi, 0x00
000075d5269e0fb1  mov rax, 0x601129E62530
000075d5269e0fbb  call rax
000075d5269e0fbd  movaps xmm14, [rsp]
000075d5269e0fc2  add rsp, 0x30
000075d5269e0fc6  vmovaps xmm0, [rsp]
000075d5269e0fcb  vmovaps xmm1, [rsp+0x10]
000075d5269e0fd1  vmovaps xmm2, [rsp+0x20]
000075d5269e0fd7  vmovaps xmm3, [rsp+0x30]
000075d5269e0fdd  vmovaps xmm4, [rsp+0x40]
000075d5269e0fe3  vmovaps xmm5, [rsp+0x50]
000075d5269e0fe9  vmovaps xmm6, [rsp+0x60]
000075d5269e0fef  vmovaps xmm7, [rsp+0x70]
000075d5269e0ff5  vmovaps xmm8, [rsp+0x80]
000075d5269e0ffe  vmovaps xmm9, [rsp+0x90]
000075d5269e1007  vmovaps xmm10, [rsp+0xA0]
000075d5269e1010  vmovaps xmm11, [rsp+0xB0]
000075d5269e1019  vmovaps xmm12, [rsp+0xC0]
000075d5269e1022  vmovaps xmm13, [rsp+0xD0]
000075d5269e102b  vmovaps xmm15, [rsp+0xE0]
000075d5269e1034  add rsp, 0xF0
000075d5269e103b  pop r11
000075d5269e103d  pop r10
000075d5269e103f  pop r9
000075d5269e1041  pop r8
000075d5269e1043  pop rsi
000075d5269e1044  pop rdi
000075d5269e1045  pop rdx
000075d5269e1046  pop rcx
000075d5269e1047  pop rax
000075d5269e1048  add rsp, 0x08
000075d5269e104c  jmp 0x000075D5269DC72B
000075d5269e1051  sub rsp, 0x08
000075d5269e1055  push rax
000075d5269e1056  push rcx
000075d5269e1057  push rdx
000075d5269e1058  push rdi
000075d5269e1059  push rsi
000075d5269e105a  push r8
000075d5269e105c  push r9
000075d5269e105e  push r10
000075d5269e1060  push r11
000075d5269e1062  sub rsp, 0xF0
000075d5269e1069  vmovaps [rsp], xmm0
000075d5269e106e  vmovaps [rsp+0x10], xmm2
000075d5269e1074  vmovaps [rsp+0x20], xmm3
000075d5269e107a  vmovaps [rsp+0x30], xmm4
000075d5269e1080  vmovaps [rsp+0x40], xmm5
000075d5269e1086  vmovaps [rsp+0x50], xmm6
000075d5269e108c  vmovaps [rsp+0x60], xmm7
000075d5269e1092  vmovaps [rsp+0x70], xmm8
000075d5269e1098  vmovaps [rsp+0x80], xmm9
000075d5269e10a1  vmovaps [rsp+0x90], xmm10
000075d5269e10aa  vmovaps [rsp+0xA0], xmm11
000075d5269e10b3  vmovaps [rsp+0xB0], xmm12
000075d5269e10bc  vmovaps [rsp+0xC0], xmm13
000075d5269e10c5  vmovaps [rsp+0xD0], xmm14
000075d5269e10ce  vmovaps [rsp+0xE0], xmm15
000075d5269e10d7  sub rsp, 0x30
000075d5269e10db  movaps [rsp], xmm1
000075d5269e10df  movaps [rsp+0x10], xmm13
000075d5269e10e5  movaps [rsp+0x20], xmm8
000075d5269e10eb  lea rdi, [rsp]
000075d5269e10ef  mov esi, 0x00
000075d5269e10f4  mov rax, 0x601129E62530
000075d5269e10fe  call rax
000075d5269e1100  movaps xmm1, [rsp]
000075d5269e1104  add rsp, 0x30
000075d5269e1108  vmovaps xmm0, [rsp]
000075d5269e110d  vmovaps xmm2, [rsp+0x10]
000075d5269e1113  vmovaps xmm3, [rsp+0x20]
000075d5269e1119  vmovaps xmm4, [rsp+0x30]
000075d5269e111f  vmovaps xmm5, [rsp+0x40]
000075d5269e1125  vmovaps xmm6, [rsp+0x50]
000075d5269e112b  vmovaps xmm7, [rsp+0x60]
000075d5269e1131  vmovaps xmm8, [rsp+0x70]
000075d5269e1137  vmovaps xmm9, [rsp+0x80]
000075d5269e1140  vmovaps xmm10, [rsp+0x90]
000075d5269e1149  vmovaps xmm11, [rsp+0xA0]
000075d5269e1152  vmovaps xmm12, [rsp+0xB0]
000075d5269e115b  vmovaps xmm13, [rsp+0xC0]
000075d5269e1164  vmovaps xmm14, [rsp+0xD0]
000075d5269e116d  vmovaps xmm15, [rsp+0xE0]
000075d5269e1176  add rsp, 0xF0
000075d5269e117d  pop r11
000075d5269e117f  pop r10
000075d5269e1181  pop r9
000075d5269e1183  pop r8
000075d5269e1185  pop rsi
000075d5269e1186  pop rdi
000075d5269e1187  pop rdx
000075d5269e1188  pop rcx
000075d5269e1189  pop rax
000075d5269e118a  add rsp, 0x08
000075d5269e118e  jmp 0x000075D5269DC74D
000075d5269e1193  call 0x000075D52680C260
000075d5269e1198  jmp 0x000075D5269DC75B
000075d5269e119d  call 0x000075D5268BD750
000075d5269e11a2  jmp 0x000075D5269DC765
000075d5269e11a7  sub rsp, 0x08
000075d5269e11ab  push rax
000075d5269e11ac  push rcx
000075d5269e11ad  push rdx
000075d5269e11ae  push rdi
000075d5269e11af  push rsi
000075d5269e11b0  push r8
000075d5269e11b2  push r9
000075d5269e11b4  push r10
000075d5269e11b6  push r11
000075d5269e11b8  sub rsp, 0xF0
000075d5269e11bf  vmovaps [rsp], xmm0
000075d5269e11c4  vmovaps [rsp+0x10], xmm1
000075d5269e11ca  vmovaps [rsp+0x20], xmm2
000075d5269e11d0  vmovaps [rsp+0x30], xmm3
000075d5269e11d6  vmovaps [rsp+0x40], xmm4
000075d5269e11dc  vmovaps [rsp+0x50], xmm5
000075d5269e11e2  vmovaps [rsp+0x60], xmm6
000075d5269e11e8  vmovaps [rsp+0x70], xmm7
000075d5269e11ee  vmovaps [rsp+0x80], xmm9
000075d5269e11f7  vmovaps [rsp+0x90], xmm10
000075d5269e1200  vmovaps [rsp+0xA0], xmm11
000075d5269e1209  vmovaps [rsp+0xB0], xmm12
000075d5269e1212  vmovaps [rsp+0xC0], xmm13
000075d5269e121b  vmovaps [rsp+0xD0], xmm14
000075d5269e1224  vmovaps [rsp+0xE0], xmm15
000075d5269e122d  sub rsp, 0x30
000075d5269e1231  movaps [rsp], xmm8
000075d5269e1236  movaps [rsp+0x10], xmm15
000075d5269e123c  movaps [rsp+0x20], xmm7
000075d5269e1241  lea rdi, [rsp]
000075d5269e1245  mov esi, 0x00
000075d5269e124a  mov rax, 0x601129E62530
000075d5269e1254  call rax
000075d5269e1256  movaps xmm8, [rsp]
000075d5269e125b  add rsp, 0x30
000075d5269e125f  vmovaps xmm0, [rsp]
000075d5269e1264  vmovaps xmm1, [rsp+0x10]
000075d5269e126a  vmovaps xmm2, [rsp+0x20]
000075d5269e1270  vmovaps xmm3, [rsp+0x30]
000075d5269e1276  vmovaps xmm4, [rsp+0x40]
000075d5269e127c  vmovaps xmm5, [rsp+0x50]
000075d5269e1282  vmovaps xmm6, [rsp+0x60]
000075d5269e1288  vmovaps xmm7, [rsp+0x70]
000075d5269e128e  vmovaps xmm9, [rsp+0x80]
000075d5269e1297  vmovaps xmm10, [rsp+0x90]
000075d5269e12a0  vmovaps xmm11, [rsp+0xA0]
000075d5269e12a9  vmovaps xmm12, [rsp+0xB0]
000075d5269e12b2  vmovaps xmm13, [rsp+0xC0]
000075d5269e12bb  vmovaps xmm14, [rsp+0xD0]
000075d5269e12c4  vmovaps xmm15, [rsp+0xE0]
000075d5269e12cd  add rsp, 0xF0
000075d5269e12d4  pop r11
000075d5269e12d6  pop r10
000075d5269e12d8  pop r9
000075d5269e12da  pop r8
000075d5269e12dc  pop rsi
000075d5269e12dd  pop rdi
000075d5269e12de  pop rdx
000075d5269e12df  pop rcx
000075d5269e12e0  pop rax
000075d5269e12e1  add rsp, 0x08
000075d5269e12e5  jmp 0x000075D5269DC787
000075d5269e12ea  sub rsp, 0x08
000075d5269e12ee  push rax
000075d5269e12ef  push rcx
000075d5269e12f0  push rdx
000075d5269e12f1  push rdi
000075d5269e12f2  push rsi
000075d5269e12f3  push r8
000075d5269e12f5  push r9
000075d5269e12f7  push r10
000075d5269e12f9  push r11
000075d5269e12fb  sub rsp, 0xF0
000075d5269e1302  vmovaps [rsp], xmm0
000075d5269e1307  vmovaps [rsp+0x10], xmm1
000075d5269e130d  vmovaps [rsp+0x20], xmm2
000075d5269e1313  vmovaps [rsp+0x30], xmm3
000075d5269e1319  vmovaps [rsp+0x40], xmm4
000075d5269e131f  vmovaps [rsp+0x50], xmm5
000075d5269e1325  vmovaps [rsp+0x60], xmm6
000075d5269e132b  vmovaps [rsp+0x70], xmm8
000075d5269e1331  vmovaps [rsp+0x80], xmm9
000075d5269e133a  vmovaps [rsp+0x90], xmm10
000075d5269e1343  vmovaps [rsp+0xA0], xmm11
000075d5269e134c  vmovaps [rsp+0xB0], xmm12
000075d5269e1355  vmovaps [rsp+0xC0], xmm13
000075d5269e135e  vmovaps [rsp+0xD0], xmm14
000075d5269e1367  vmovaps [rsp+0xE0], xmm15
000075d5269e1370  sub rsp, 0x30
000075d5269e1374  movaps [rsp], xmm7
000075d5269e1378  movaps [rsp+0x10], xmm9
000075d5269e137e  movaps [rsp+0x20], xmm15
000075d5269e1384  lea rdi, [rsp]
000075d5269e1388  mov esi, 0x00
000075d5269e138d  mov rax, 0x601129E62530
000075d5269e1397  call rax
000075d5269e1399  movaps xmm7, [rsp]
000075d5269e139d  add rsp, 0x30
000075d5269e13a1  vmovaps xmm0, [rsp]
000075d5269e13a6  vmovaps xmm1, [rsp+0x10]
000075d5269e13ac  vmovaps xmm2, [rsp+0x20]
000075d5269e13b2  vmovaps xmm3, [rsp+0x30]
000075d5269e13b8  vmovaps xmm4, [rsp+0x40]
000075d5269e13be  vmovaps xmm5, [rsp+0x50]
000075d5269e13c4  vmovaps xmm6, [rsp+0x60]
000075d5269e13ca  vmovaps xmm8, [rsp+0x70]
000075d5269e13d0  vmovaps xmm9, [rsp+0x80]
000075d5269e13d9  vmovaps xmm10, [rsp+0x90]
000075d5269e13e2  vmovaps xmm11, [rsp+0xA0]
000075d5269e13eb  vmovaps xmm12, [rsp+0xB0]
000075d5269e13f4  vmovaps xmm13, [rsp+0xC0]
000075d5269e13fd  vmovaps xmm14, [rsp+0xD0]
000075d5269e1406  vmovaps xmm15, [rsp+0xE0]
000075d5269e140f  add rsp, 0xF0
000075d5269e1416  pop r11
000075d5269e1418  pop r10
000075d5269e141a  pop r9
000075d5269e141c  pop r8
000075d5269e141e  pop rsi
000075d5269e141f  pop rdi
000075d5269e1420  pop rdx
000075d5269e1421  pop rcx
000075d5269e1422  pop rax
000075d5269e1423  add rsp, 0x08
000075d5269e1427  jmp 0x000075D5269DC7B4
000075d5269e142c  sub rsp, 0x08
000075d5269e1430  push rax
000075d5269e1431  push rcx
000075d5269e1432  push rdx
000075d5269e1433  push rdi
000075d5269e1434  push rsi
000075d5269e1435  push r8
000075d5269e1437  push r9
000075d5269e1439  push r10
000075d5269e143b  push r11
000075d5269e143d  sub rsp, 0xF0
000075d5269e1444  vmovaps [rsp], xmm0
000075d5269e1449  vmovaps [rsp+0x10], xmm1
000075d5269e144f  vmovaps [rsp+0x20], xmm2
000075d5269e1455  vmovaps [rsp+0x30], xmm3
000075d5269e145b  vmovaps [rsp+0x40], xmm4
000075d5269e1461  vmovaps [rsp+0x50], xmm5
000075d5269e1467  vmovaps [rsp+0x60], xmm6
000075d5269e146d  vmovaps [rsp+0x70], xmm7
000075d5269e1473  vmovaps [rsp+0x80], xmm8
000075d5269e147c  vmovaps [rsp+0x90], xmm10
000075d5269e1485  vmovaps [rsp+0xA0], xmm11
000075d5269e148e  vmovaps [rsp+0xB0], xmm12
000075d5269e1497  vmovaps [rsp+0xC0], xmm13
000075d5269e14a0  vmovaps [rsp+0xD0], xmm14
000075d5269e14a9  vmovaps [rsp+0xE0], xmm15
000075d5269e14b2  sub rsp, 0x30
000075d5269e14b6  movaps [rsp], xmm9
000075d5269e14bb  movaps [rsp+0x10], xmm13
000075d5269e14c1  movaps [rsp+0x20], xmm15
000075d5269e14c7  lea rdi, [rsp]
000075d5269e14cb  mov esi, 0x00
000075d5269e14d0  mov rax, 0x601129E62530
000075d5269e14da  call rax
000075d5269e14dc  movaps xmm9, [rsp]
000075d5269e14e1  add rsp, 0x30
000075d5269e14e5  vmovaps xmm0, [rsp]
000075d5269e14ea  vmovaps xmm1, [rsp+0x10]
000075d5269e14f0  vmovaps xmm2, [rsp+0x20]
000075d5269e14f6  vmovaps xmm3, [rsp+0x30]
000075d5269e14fc  vmovaps xmm4, [rsp+0x40]
000075d5269e1502  vmovaps xmm5, [rsp+0x50]
000075d5269e1508  vmovaps xmm6, [rsp+0x60]
000075d5269e150e  vmovaps xmm7, [rsp+0x70]
000075d5269e1514  vmovaps xmm8, [rsp+0x80]
000075d5269e151d  vmovaps xmm10, [rsp+0x90]
000075d5269e1526  vmovaps xmm11, [rsp+0xA0]
000075d5269e152f  vmovaps xmm12, [rsp+0xB0]
000075d5269e1538  vmovaps xmm13, [rsp+0xC0]
000075d5269e1541  vmovaps xmm14, [rsp+0xD0]
000075d5269e154a  vmovaps xmm15, [rsp+0xE0]
000075d5269e1553  add rsp, 0xF0
000075d5269e155a  pop r11
000075d5269e155c  pop r10
000075d5269e155e  pop r9
000075d5269e1560  pop r8
000075d5269e1562  pop rsi
000075d5269e1563  pop rdi
000075d5269e1564  pop rdx
000075d5269e1565  pop rcx
000075d5269e1566  pop rax
000075d5269e1567  add rsp, 0x08
000075d5269e156b  jmp 0x000075D5269DC7E2
000075d5269e1570  sub rsp, 0x08
000075d5269e1574  push rax
000075d5269e1575  push rcx
000075d5269e1576  push rdx
000075d5269e1577  push rdi
000075d5269e1578  push rsi
000075d5269e1579  push r8
000075d5269e157b  push r9
000075d5269e157d  push r10
000075d5269e157f  push r11
000075d5269e1581  sub rsp, 0xF0
000075d5269e1588  vmovaps [rsp], xmm0
000075d5269e158d  vmovaps [rsp+0x10], xmm1
000075d5269e1593  vmovaps [rsp+0x20], xmm2
000075d5269e1599  vmovaps [rsp+0x30], xmm3
000075d5269e159f  vmovaps [rsp+0x40], xmm4
000075d5269e15a5  vmovaps [rsp+0x50], xmm5
000075d5269e15ab  vmovaps [rsp+0x60], xmm6
000075d5269e15b1  vmovaps [rsp+0x70], xmm7
000075d5269e15b7  vmovaps [rsp+0x80], xmm8
000075d5269e15c0  vmovaps [rsp+0x90], xmm9
000075d5269e15c9  vmovaps [rsp+0xA0], xmm10
000075d5269e15d2  vmovaps [rsp+0xB0], xmm11
000075d5269e15db  vmovaps [rsp+0xC0], xmm12
000075d5269e15e4  vmovaps [rsp+0xD0], xmm13
000075d5269e15ed  vmovaps [rsp+0xE0], xmm14
000075d5269e15f6  sub rsp, 0x30
000075d5269e15fa  movaps [rsp], xmm15
000075d5269e15ff  movaps [rsp+0x10], xmm11
000075d5269e1605  movaps [rsp+0x20], xmm12
000075d5269e160b  lea rdi, [rsp]
000075d5269e160f  mov esi, 0x00
000075d5269e1614  mov rax, 0x601129E62530
000075d5269e161e  call rax
000075d5269e1620  movaps xmm15, [rsp]
000075d5269e1625  add rsp, 0x30
000075d5269e1629  vmovaps xmm0, [rsp]
000075d5269e162e  vmovaps xmm1, [rsp+0x10]
000075d5269e1634  vmovaps xmm2, [rsp+0x20]
000075d5269e163a  vmovaps xmm3, [rsp+0x30]
000075d5269e1640  vmovaps xmm4, [rsp+0x40]
000075d5269e1646  vmovaps xmm5, [rsp+0x50]
000075d5269e164c  vmovaps xmm6, [rsp+0x60]
000075d5269e1652  vmovaps xmm7, [rsp+0x70]
000075d5269e1658  vmovaps xmm8, [rsp+0x80]
000075d5269e1661  vmovaps xmm9, [rsp+0x90]
000075d5269e166a  vmovaps xmm10, [rsp+0xA0]
000075d5269e1673  vmovaps xmm11, [rsp+0xB0]
000075d5269e167c  vmovaps xmm12, [rsp+0xC0]
000075d5269e1685  vmovaps xmm13, [rsp+0xD0]
000075d5269e168e  vmovaps xmm14, [rsp+0xE0]
000075d5269e1697  add rsp, 0xF0
000075d5269e169e  pop r11
000075d5269e16a0  pop r10
000075d5269e16a2  pop r9
000075d5269e16a4  pop r8
000075d5269e16a6  pop rsi
000075d5269e16a7  pop rdi
000075d5269e16a8  pop rdx
000075d5269e16a9  pop rcx
000075d5269e16aa  pop rax
000075d5269e16ab  add rsp, 0x08
000075d5269e16af  jmp 0x000075D5269DC7FD
000075d5269e16b4  sub rsp, 0x08
000075d5269e16b8  push rax
000075d5269e16b9  push rcx
000075d5269e16ba  push rdx
000075d5269e16bb  push rdi
000075d5269e16bc  push rsi
000075d5269e16bd  push r8
000075d5269e16bf  push r9
000075d5269e16c1  push r10
000075d5269e16c3  push r11
000075d5269e16c5  sub rsp, 0xF0
000075d5269e16cc  vmovaps [rsp], xmm0
000075d5269e16d1  vmovaps [rsp+0x10], xmm1
000075d5269e16d7  vmovaps [rsp+0x20], xmm2
000075d5269e16dd  vmovaps [rsp+0x30], xmm3
000075d5269e16e3  vmovaps [rsp+0x40], xmm4
000075d5269e16e9  vmovaps [rsp+0x50], xmm5
000075d5269e16ef  vmovaps [rsp+0x60], xmm6
000075d5269e16f5  vmovaps [rsp+0x70], xmm7
000075d5269e16fb  vmovaps [rsp+0x80], xmm8
000075d5269e1704  vmovaps [rsp+0x90], xmm9
000075d5269e170d  vmovaps [rsp+0xA0], xmm10
000075d5269e1716  vmovaps [rsp+0xB0], xmm11
000075d5269e171f  vmovaps [rsp+0xC0], xmm12
000075d5269e1728  vmovaps [rsp+0xD0], xmm14
000075d5269e1731  vmovaps [rsp+0xE0], xmm15
000075d5269e173a  sub rsp, 0x30
000075d5269e173e  movaps [rsp], xmm13
000075d5269e1743  movaps [rsp+0x10], xmm10
000075d5269e1749  movaps [rsp+0x20], xmm14
000075d5269e174f  lea rdi, [rsp]
000075d5269e1753  mov esi, 0x00
000075d5269e1758  mov rax, 0x601129E62530
000075d5269e1762  call rax
000075d5269e1764  movaps xmm13, [rsp]
000075d5269e1769  add rsp, 0x30
000075d5269e176d  vmovaps xmm0, [rsp]
000075d5269e1772  vmovaps xmm1, [rsp+0x10]
000075d5269e1778  vmovaps xmm2, [rsp+0x20]
000075d5269e177e  vmovaps xmm3, [rsp+0x30]
000075d5269e1784  vmovaps xmm4, [rsp+0x40]
000075d5269e178a  vmovaps xmm5, [rsp+0x50]
000075d5269e1790  vmovaps xmm6, [rsp+0x60]
000075d5269e1796  vmovaps xmm7, [rsp+0x70]
000075d5269e179c  vmovaps xmm8, [rsp+0x80]
000075d5269e17a5  vmovaps xmm9, [rsp+0x90]
000075d5269e17ae  vmovaps xmm10, [rsp+0xA0]
000075d5269e17b7  vmovaps xmm11, [rsp+0xB0]
000075d5269e17c0  vmovaps xmm12, [rsp+0xC0]
000075d5269e17c9  vmovaps xmm14, [rsp+0xD0]
000075d5269e17d2  vmovaps xmm15, [rsp+0xE0]
000075d5269e17db  add rsp, 0xF0
000075d5269e17e2  pop r11
000075d5269e17e4  pop r10
000075d5269e17e6  pop r9
000075d5269e17e8  pop r8
000075d5269e17ea  pop rsi
000075d5269e17eb  pop rdi
000075d5269e17ec  pop rdx
000075d5269e17ed  pop rcx
000075d5269e17ee  pop rax
000075d5269e17ef  add rsp, 0x08
000075d5269e17f3  jmp 0x000075D5269DC820
000075d5269e17f8  sub rsp, 0x08
000075d5269e17fc  push rax
000075d5269e17fd  push rcx
000075d5269e17fe  push rdx
000075d5269e17ff  push rdi
000075d5269e1800  push rsi
000075d5269e1801  push r8
000075d5269e1803  push r9
000075d5269e1805  push r10
000075d5269e1807  push r11
000075d5269e1809  sub rsp, 0xF0
000075d5269e1810  vmovaps [rsp], xmm0
000075d5269e1815  vmovaps [rsp+0x10], xmm1
000075d5269e181b  vmovaps [rsp+0x20], xmm2
000075d5269e1821  vmovaps [rsp+0x30], xmm3
000075d5269e1827  vmovaps [rsp+0x40], xmm4
000075d5269e182d  vmovaps [rsp+0x50], xmm5
000075d5269e1833  vmovaps [rsp+0x60], xmm6
000075d5269e1839  vmovaps [rsp+0x70], xmm7
000075d5269e183f  vmovaps [rsp+0x80], xmm8
000075d5269e1848  vmovaps [rsp+0x90], xmm9
000075d5269e1851  vmovaps [rsp+0xA0], xmm10
000075d5269e185a  vmovaps [rsp+0xB0], xmm11
000075d5269e1863  vmovaps [rsp+0xC0], xmm12
000075d5269e186c  vmovaps [rsp+0xD0], xmm13
000075d5269e1875  vmovaps [rsp+0xE0], xmm15
000075d5269e187e  sub rsp, 0x30
000075d5269e1882  movaps [rsp], xmm14
000075d5269e1887  movaps [rsp+0x10], xmm1
000075d5269e188c  movaps [rsp+0x20], xmm7
000075d5269e1891  lea rdi, [rsp]
000075d5269e1895  mov esi, 0x00
000075d5269e189a  mov rax, 0x601129E62530
000075d5269e18a4  call rax
000075d5269e18a6  movaps xmm14, [rsp]
000075d5269e18ab  add rsp, 0x30
000075d5269e18af  vmovaps xmm0, [rsp]
000075d5269e18b4  vmovaps xmm1, [rsp+0x10]
000075d5269e18ba  vmovaps xmm2, [rsp+0x20]
000075d5269e18c0  vmovaps xmm3, [rsp+0x30]
000075d5269e18c6  vmovaps xmm4, [rsp+0x40]
000075d5269e18cc  vmovaps xmm5, [rsp+0x50]
000075d5269e18d2  vmovaps xmm6, [rsp+0x60]
000075d5269e18d8  vmovaps xmm7, [rsp+0x70]
000075d5269e18de  vmovaps xmm8, [rsp+0x80]
000075d5269e18e7  vmovaps xmm9, [rsp+0x90]
000075d5269e18f0  vmovaps xmm10, [rsp+0xA0]
000075d5269e18f9  vmovaps xmm11, [rsp+0xB0]
000075d5269e1902  vmovaps xmm12, [rsp+0xC0]
000075d5269e190b  vmovaps xmm13, [rsp+0xD0]
000075d5269e1914  vmovaps xmm15, [rsp+0xE0]
000075d5269e191d  add rsp, 0xF0
000075d5269e1924  pop r11
000075d5269e1926  pop r10
000075d5269e1928  pop r9
000075d5269e192a  pop r8
000075d5269e192c  pop rsi
000075d5269e192d  pop rdi
000075d5269e192e  pop rdx
000075d5269e192f  pop rcx
000075d5269e1930  pop rax
000075d5269e1931  add rsp, 0x08
000075d5269e1935  jmp 0x000075D5269DC843
000075d5269e193a  sub rsp, 0x08
000075d5269e193e  push rax
000075d5269e193f  push rcx
000075d5269e1940  push rdx
000075d5269e1941  push rdi
000075d5269e1942  push rsi
000075d5269e1943  push r8
000075d5269e1945  push r9
000075d5269e1947  push r10
000075d5269e1949  push r11
000075d5269e194b  sub rsp, 0xF0
000075d5269e1952  vmovaps [rsp], xmm0
000075d5269e1957  vmovaps [rsp+0x10], xmm2
000075d5269e195d  vmovaps [rsp+0x20], xmm3
000075d5269e1963  vmovaps [rsp+0x30], xmm4
000075d5269e1969  vmovaps [rsp+0x40], xmm5
000075d5269e196f  vmovaps [rsp+0x50], xmm6
000075d5269e1975  vmovaps [rsp+0x60], xmm7
000075d5269e197b  vmovaps [rsp+0x70], xmm8
000075d5269e1981  vmovaps [rsp+0x80], xmm9
000075d5269e198a  vmovaps [rsp+0x90], xmm10
000075d5269e1993  vmovaps [rsp+0xA0], xmm11
000075d5269e199c  vmovaps [rsp+0xB0], xmm12
000075d5269e19a5  vmovaps [rsp+0xC0], xmm13
000075d5269e19ae  vmovaps [rsp+0xD0], xmm14
000075d5269e19b7  vmovaps [rsp+0xE0], xmm15
000075d5269e19c0  sub rsp, 0x30
000075d5269e19c4  movaps [rsp], xmm1
000075d5269e19c8  movaps [rsp+0x10], xmm8
000075d5269e19ce  movaps [rsp+0x20], xmm9
000075d5269e19d4  lea rdi, [rsp]
000075d5269e19d8  mov esi, 0x00
000075d5269e19dd  mov rax, 0x601129E62530
000075d5269e19e7  call rax
000075d5269e19e9  movaps xmm1, [rsp]
000075d5269e19ed  add rsp, 0x30
000075d5269e19f1  vmovaps xmm0, [rsp]
000075d5269e19f6  vmovaps xmm2, [rsp+0x10]
000075d5269e19fc  vmovaps xmm3, [rsp+0x20]
000075d5269e1a02  vmovaps xmm4, [rsp+0x30]
000075d5269e1a08  vmovaps xmm5, [rsp+0x40]
000075d5269e1a0e  vmovaps xmm6, [rsp+0x50]
000075d5269e1a14  vmovaps xmm7, [rsp+0x60]
000075d5269e1a1a  vmovaps xmm8, [rsp+0x70]
000075d5269e1a20  vmovaps xmm9, [rsp+0x80]
000075d5269e1a29  vmovaps xmm10, [rsp+0x90]
000075d5269e1a32  vmovaps xmm11, [rsp+0xA0]
000075d5269e1a3b  vmovaps xmm12, [rsp+0xB0]
000075d5269e1a44  vmovaps xmm13, [rsp+0xC0]
000075d5269e1a4d  vmovaps xmm14, [rsp+0xD0]
000075d5269e1a56  vmovaps xmm15, [rsp+0xE0]
000075d5269e1a5f  add rsp, 0xF0
000075d5269e1a66  pop r11
000075d5269e1a68  pop r10
000075d5269e1a6a  pop r9
000075d5269e1a6c  pop r8
000075d5269e1a6e  pop rsi
000075d5269e1a6f  pop rdi
000075d5269e1a70  pop rdx
000075d5269e1a71  pop rcx
000075d5269e1a72  pop rax
000075d5269e1a73  add rsp, 0x08
000075d5269e1a77  jmp 0x000075D5269DC865
000075d5269e1a7c  call 0x000075D5268E5940
000075d5269e1a81  jmp 0x000075D5269DC873
000075d5269e1a86  call 0x000075D52680C380
000075d5269e1a8b  jmp 0x000075D5269DC87D
000075d5269e1a90  call 0x000075D52680D600
000075d5269e1a95  jmp 0x000075D5269DC887
000075d5269e1a9a  call 0x000075D5267FF540
000075d5269e1a9f  jmp 0x000075D5269DC891
000075d5269e1aa4  int3
000075d5269e1aa5  nop [rax+rax*1], ax
000075d5269e1aae  nop
000075d5269e1ab0  mov rax, [r15+0xF8]
000075d5269e1ab7  lea r14, [rax+0x140]
000075d5269e1abe  mov r12, [r13+r14*1]
000075d5269e1ac3  mov [r15+0xE8], r12
000075d5269e1aca  lea r14, [rax+0x130]
000075d5269e1ad1  mov r12, [r13+r14*1]
000075d5269e1ad6  lea r14, [rax+0x138]
000075d5269e1add  mov r11, [r13+r14*1]
000075d5269e1ae2  movq xmm1, r12
000075d5269e1ae7  movq xmm15, r11
000075d5269e1aec  movq xmm1, xmm1
000075d5269e1af0  movq xmm1, xmm1
000075d5269e1af4  movaps [r15+0x1A0], xmm1
000075d5269e1afc  movq xmm15, xmm15
000075d5269e1b01  movq xmm15, xmm15
000075d5269e1b06  movaps [r15+0x190], xmm15
000075d5269e1b0e  lea r14, [rax+0x120]
000075d5269e1b15  mov r12, [r13+r14*1]
000075d5269e1b1a  lea r14, [rax+0x128]
000075d5269e1b21  mov r11, [r13+r14*1]
000075d5269e1b26  movq xmm1, r12
000075d5269e1b2b  movq xmm15, r11
000075d5269e1b30  movq xmm1, xmm1
000075d5269e1b34  movq xmm1, xmm1
000075d5269e1b38  movaps [r15+0x1C0], xmm1
000075d5269e1b40  movq xmm15, xmm15
000075d5269e1b45  movq xmm15, xmm15
000075d5269e1b4a  movaps [r15+0x1B0], xmm15
000075d5269e1b52  lea r14, [rax+0x110]
000075d5269e1b59  mov r12, [r13+r14*1]
000075d5269e1b5e  lea r14, [rax+0x118]
000075d5269e1b65  mov r11, [r13+r14*1]
000075d5269e1b6a  movq xmm1, r12
000075d5269e1b6f  movq xmm15, r11
000075d5269e1b74  movq xmm1, xmm1
000075d5269e1b78  movq xmm1, xmm1
000075d5269e1b7c  movaps [r15+0x1E0], xmm1
000075d5269e1b84  movq xmm15, xmm15
000075d5269e1b89  movq xmm15, xmm15
000075d5269e1b8e  movaps [r15+0x1D0], xmm15
000075d5269e1b96  lea r14, [rax+0x100]
000075d5269e1b9d  mov r12, [r13+r14*1]
000075d5269e1ba2  lea r14, [rax+0x108]
000075d5269e1ba9  mov r11, [r13+r14*1]
000075d5269e1bae  movq xmm1, r12
000075d5269e1bb3  movq xmm15, r11
000075d5269e1bb8  movq xmm1, xmm1
000075d5269e1bbc  movq xmm1, xmm1
000075d5269e1bc0  movaps [r15+0x200], xmm1
000075d5269e1bc8  movq xmm15, xmm15
000075d5269e1bcd  movq xmm15, xmm15
000075d5269e1bd2  movaps [r15+0x1F0], xmm15
000075d5269e1bda  mov qword ptr [r15+0x40], 0x430000
000075d5269e1be2  mov r14d, 0x430510
000075d5269e1be8  mov r12, [r13+r14*1]
000075d5269e1bed  movq xmm1, r12
000075d5269e1bf2  lea r14, [rax+0x150]
000075d5269e1bf9  mov [r15+0xF8], r14
000075d5269e1c00  mov rax, [r15+0x50]
000075d5269e1c04  movups xmm15, [r13+rax*1]
000075d5269e1c0a  movaps [r15+0x120], xmm15
000075d5269e1c12  mov qword ptr [r15+0x48], 0x10
000075d5269e1c1a  xor eax, eax
000075d5269e1c1c  mov r14d, 0x10
000075d5269e1c22  mov r12d, 0x200
000075d5269e1c28  cmp r14, r12
000075d5269e1c2b  cmc
000075d5269e1c2c  lahf
000075d5269e1c2d  seto al
000075d5269e1c30  mov [r15+0x108], eax
000075d5269e1c37  pextrq rax, xmm15, 0x01
000075d5269e1c3e  movq xmm14, rax
000075d5269e1c43  movaps [r15+0x130], xmm14
000075d5269e1c4b  movq rax, xmm1
000075d5269e1c50  movq r14, xmm15
000075d5269e1c55  vmovq xmm1, rax
000075d5269e1c5a  vmovq xmm15, r14
000075d5269e1c5f  movaps xmm13, xmm1
000075d5269e1c63  addsd xmm13, xmm15
000075d5269e1c68  ucomisd xmm13, xmm13
000075d5269e1c6d  jp 0x000075D5269E1D86
000075d5269e1c73  movq xmm13, xmm13
000075d5269e1c78  movq rax, xmm13
000075d5269e1c7d  movq r14, xmm14
000075d5269e1c82  vmovq xmm1, rax
000075d5269e1c87  vmovq xmm15, r14
000075d5269e1c8c  movaps xmm14, xmm1
000075d5269e1c90  addsd xmm14, xmm15
000075d5269e1c95  ucomisd xmm14, xmm14
000075d5269e1c9a  jp 0x000075D5269E1DCE
000075d5269e1ca0  movq xmm14, xmm14
000075d5269e1ca5  movaps [r15+0x110], xmm14
000075d5269e1cad  mov eax, [r15+0x108]
000075d5269e1cb4  sahf
000075d5269e1cb5  jnz 0x000075D5269E1CE7
000075d5269e1cb7  cmp dword ptr [r15+0x318], 0x00
000075d5269e1cbf  jz 0x000075D5269E1FE0
000075d5269e1cc5  nop [rax+rax*1], ax
000075d5269e1cce  nop [rax+rax*1], eax
000075d5269e1cd6  mov eax, 0x410490
000075d5269e1cdb  mov [r15+0x100], rax
000075d5269e1ce2  jmp 0x000075D5267FE110
000075d5269e1ce7  cmp dword ptr [r15+0x318], 0x00
000075d5269e1cef  jz 0x000075D5269E1E20
000075d5269e1cf5  nop [rax+rax*1], ax
000075d5269e1cfe  nop [rax+rax*1], eax
000075d5269e1d06  mov eax, 0x410474
000075d5269e1d0b  mov [r15+0x100], rax
000075d5269e1d12  jmp 0x000075D5267FE110
000075d5269e1d17  int3
000075d5269e1d18  call 0x000075D5268E27E0
000075d5269e1d1d  jmp 0x000075D5269E1AC3
000075d5269e1d22  call 0x000075D5268E27E0
000075d5269e1d27  jmp 0x000075D5269E1AD6
000075d5269e1d2c  call 0x000075D5268E1570
000075d5269e1d31  jmp 0x000075D5269E1AE2
000075d5269e1d36  call 0x000075D5268E27E0
000075d5269e1d3b  jmp 0x000075D5269E1B1A
000075d5269e1d40  call 0x000075D5268E1570
000075d5269e1d45  jmp 0x000075D5269E1B26
000075d5269e1d4a  call 0x000075D5268E27E0
000075d5269e1d4f  jmp 0x000075D5269E1B5E
000075d5269e1d54  call 0x000075D5268E1570
000075d5269e1d59  jmp 0x000075D5269E1B6A
000075d5269e1d5e  call 0x000075D5268E27E0
000075d5269e1d63  jmp 0x000075D5269E1BA2
000075d5269e1d68  call 0x000075D5268E1570
000075d5269e1d6d  jmp 0x000075D5269E1BAE
000075d5269e1d72  call 0x000075D5268E27E0
000075d5269e1d77  jmp 0x000075D5269E1BED
000075d5269e1d7c  call 0x000075D52680E760
000075d5269e1d81  jmp 0x000075D5269E1C0A
000075d5269e1d86  ucomisd xmm1, xmm15
000075d5269e1d8b  jp 0x000075D5269E1D9A
000075d5269e1d8d  movaps xmm13, [0x000075D5265FE060]
000075d5269e1d95  jmp 0x000075D5269E1C73
000075d5269e1d9a  vxorps xmm0, xmm1, xmm15
000075d5269e1d9f  pextrw eax, xmm0, 0x03
000075d5269e1da4  and eax, 0x7FF8
000075d5269e1da9  cmp eax, 0x08
000075d5269e1dac  jnz 0x000075D5269E1C73
000075d5269e1db2  movq rax, xmm15
000075d5269e1db7  shl rax, 0x0D
000075d5269e1dbb  jbe 0x000075D5269E1C73
000075d5269e1dc1  vorps xmm13, xmm15, [0x000075D5265FE070]
000075d5269e1dc9  jmp 0x000075D5269E1C73
000075d5269e1dce  ucomisd xmm1, xmm15
000075d5269e1dd3  jp 0x000075D5269E1DE2
000075d5269e1dd5  movaps xmm14, [0x000075D5265FE060]
000075d5269e1ddd  jmp 0x000075D5269E1CA0
000075d5269e1de2  vxorps xmm0, xmm1, xmm15
000075d5269e1de7  pextrw eax, xmm0, 0x03
000075d5269e1dec  and eax, 0x7FF8
000075d5269e1df1  cmp eax, 0x08
000075d5269e1df4  jnz 0x000075D5269E1CA0
000075d5269e1dfa  movq rax, xmm15
000075d5269e1dff  shl rax, 0x0D
000075d5269e1e03  jbe 0x000075D5269E1CA0
000075d5269e1e09  vorps xmm14, xmm15, [0x000075D5265FE070]
000075d5269e1e11  jmp 0x000075D5269E1CA0
000075d5269e1e16  int3
000075d5269e1e17  nop [rax+rax*1], ax
000075d5269e1e20  mov rax, [r15+0x48]
000075d5269e1e24  mov r14, [r15+0x50]
000075d5269e1e28  lea r12, [r14+rax*1]
000075d5269e1e2c  movups xmm1, [r13+r12*1]
000075d5269e1e32  movaps [r15+0x120], xmm1
000075d5269e1e3a  lea r14, [rax+0x10]
000075d5269e1e3e  mov [r15+0x48], r14
000075d5269e1e42  xor eax, eax
000075d5269e1e44  mov r12d, 0x200
000075d5269e1e4a  cmp r14, r12
000075d5269e1e4d  cmc
000075d5269e1e4e  lahf
000075d5269e1e4f  seto al
000075d5269e1e52  mov [r15+0x108], eax
000075d5269e1e59  pextrq rax, xmm1, 0x01
000075d5269e1e60  movq xmm15, rax
000075d5269e1e65  movaps [r15+0x130], xmm15
000075d5269e1e6d  movaps xmm14, [r15+0x110]
000075d5269e1e75  movq rax, xmm14
000075d5269e1e7a  movq r14, xmm1
000075d5269e1e7f  vmovq xmm1, rax
000075d5269e1e84  vmovq xmm14, r14
000075d5269e1e89  movaps xmm13, xmm1
000075d5269e1e8d  addsd xmm13, xmm14
000075d5269e1e92  ucomisd xmm13, xmm13
000075d5269e1e97  jp 0x000075D5269E1F4C
000075d5269e1e9d  movq xmm13, xmm13
000075d5269e1ea2  movq rax, xmm13
000075d5269e1ea7  movq r14, xmm15
000075d5269e1eac  vmovq xmm1, rax
000075d5269e1eb1  vmovq xmm15, r14
000075d5269e1eb6  movaps xmm14, xmm1
000075d5269e1eba  addsd xmm14, xmm15
000075d5269e1ebf  ucomisd xmm14, xmm14
000075d5269e1ec4  jp 0x000075D5269E1F94
000075d5269e1eca  movq xmm14, xmm14
000075d5269e1ecf  movaps [r15+0x110], xmm14
000075d5269e1ed7  mov eax, [r15+0x108]
000075d5269e1ede  sahf
000075d5269e1edf  jnz 0x000075D5269E1F11
000075d5269e1ee1  cmp dword ptr [r15+0x318], 0x00
000075d5269e1ee9  jz 0x000075D5269E1FE0
000075d5269e1eef  nop [rax+rax*1], ax
000075d5269e1ef8  nop [rax+rax*1], eax
000075d5269e1f00  mov eax, 0x410490
000075d5269e1f05  mov [r15+0x100], rax
000075d5269e1f0c  jmp 0x000075D5267FE110
000075d5269e1f11  cmp dword ptr [r15+0x318], 0x00
000075d5269e1f19  jz 0x000075D5269E1E20
000075d5269e1f1f  nop [rax+rax*1], ax
000075d5269e1f28  nop [rax+rax*1], eax
000075d5269e1f30  mov eax, 0x410474
000075d5269e1f35  mov [r15+0x100], rax
000075d5269e1f3c  jmp 0x000075D5267FE110
000075d5269e1f41  int3
000075d5269e1f42  call 0x000075D5268B52F0
000075d5269e1f47  jmp 0x000075D5269E1E32
000075d5269e1f4c  ucomisd xmm1, xmm14
000075d5269e1f51  jp 0x000075D5269E1F60
000075d5269e1f53  movaps xmm13, [0x000075D5265FE060]
000075d5269e1f5b  jmp 0x000075D5269E1E9D
000075d5269e1f60  vxorps xmm0, xmm1, xmm14
000075d5269e1f65  pextrw eax, xmm0, 0x03
000075d5269e1f6a  and eax, 0x7FF8
000075d5269e1f6f  cmp eax, 0x08
000075d5269e1f72  jnz 0x000075D5269E1E9D
000075d5269e1f78  movq rax, xmm14
000075d5269e1f7d  shl rax, 0x0D
000075d5269e1f81  jbe 0x000075D5269E1E9D
000075d5269e1f87  vorps xmm13, xmm14, [0x000075D5265FE070]
000075d5269e1f8f  jmp 0x000075D5269E1E9D
000075d5269e1f94  ucomisd xmm1, xmm15
000075d5269e1f99  jp 0x000075D5269E1FA8
000075d5269e1f9b  movaps xmm14, [0x000075D5265FE060]
000075d5269e1fa3  jmp 0x000075D5269E1ECA
000075d5269e1fa8  vxorps xmm0, xmm1, xmm15
000075d5269e1fad  pextrw eax, xmm0, 0x03
000075d5269e1fb2  and eax, 0x7FF8
000075d5269e1fb7  cmp eax, 0x08
000075d5269e1fba  jnz 0x000075D5269E1ECA
000075d5269e1fc0  movq rax, xmm15
000075d5269e1fc5  shl rax, 0x0D
000075d5269e1fc9  jbe 0x000075D5269E1ECA
000075d5269e1fcf  vorps xmm14, xmm15, [0x000075D5265FE070]
000075d5269e1fd7  jmp 0x000075D5269E1ECA
000075d5269e1fdc  int3
000075d5269e1fdd  nop [rax], eax
000075d5269e1fe0  mov rax, [r15+0x40]
000075d5269e1fe4  lea r14, [rax+0x510]
000075d5269e1feb  movaps xmm1, [r15+0x110]
000075d5269e1ff3  movq rax, xmm1
000075d5269e1ff8  mov [r13+r14*1], rax
000075d5269e1ffd  mov rax, [r15+0xF0]
000075d5269e2004  mov [r15+0x100], rax
000075d5269e200b  jmp 0x000075D5269CE5C0
000075d5269e2010  int3
000075d5269e2011  call 0x000075D5268D5EB0
000075d5269e2016  jmp 0x000075D5269E1FFD
000075d5269e201b  int3
000075d5269e201c  nop [rax], eax
000075d5269e2020  mov qword ptr [r15+0x100], 0x04
000075d5269e202b  mov esi, 0x00
000075d5269e2030  mov edx, 0x09
000075d5269e2035  mov rdi, 0x7FFD4D8253A0
000075d5269e203f  mov rax, 0x601129CF5970
000075d5269e2049  call rax
000075d5269e204b  cmp dword ptr [r15+0x318], 0x00
000075d5269e2053  jnz 0x000075D5267FE110
000075d5269e2059  jmp 0x000075D5267FE0A0
000075d5269e205e  int3
000075d5269e205f  int3
