000071709abce69b  nop [rax+rax*1], eax
000071709abce6a0  vmovaps xmm1, [0x000071709A7FE010]
000071709abce6a8  movq xmm1, xmm1
000071709abce6ac  movaps [r15+0x110], xmm1
000071709abce6b4  vmovaps xmm1, [0x000071709A7FE020]
000071709abce6bc  movq xmm1, xmm1
000071709abce6c0  movaps [r15+0x120], xmm1
000071709abce6c8  mov eax, 0x4204C0
000071709abce6cd  mov r14, [r13+rax*1]
000071709abce6d2  movq xmm1, r14
000071709abce6d7  movaps [r15+0x130], xmm1
000071709abce6df  vmovaps xmm1, [0x000071709A7FE030]
000071709abce6e7  vpbroadcastq xmm1, xmm1
000071709abce6ec  movaps [r15+0x140], xmm1
000071709abce6f4  mov qword ptr [r15+0x40], 0x02
000071709abce6fc  vmovaps xmm15, [0x000071709A7FE040]
000071709abce704  movq xmm15, xmm15
000071709abce709  movaps [r15+0x150], xmm15
000071709abce711  mov qword ptr [r15+0x58], 0x420000
000071709abce719  vmovaps xmm15, [0x000071709A7FE050]
000071709abce721  vpbroadcastq xmm15, xmm15
000071709abce726  movaps [r15+0x160], xmm15
000071709abce72e  mov rax, [r15+0x40]
000071709abce732  vmovq xmm14, rax
000071709abce737  vpbroadcastq xmm14, xmm14
000071709abce73c  movaps [r15+0x170], xmm14
000071709abce744  mov eax, 0x4204D0
000071709abce749  movups xmm13, [r13+rax*1]
000071709abce74f  mov qword ptr [r15+0x40], 0x430518
000071709abce757  mov qword ptr [r15+0x50], 0x430720
000071709abce75f  vpmovqd xmm12, xmm13
000071709abce765  pxor xmm11, xmm11
000071709abce76a  punpcklqdq xmm12, xmm11
000071709abce76f  movaps [r15+0x210], xmm12
000071709abce777  movq xmm12, qword ptr [r15+0x120]
000071709abce780  movq xmm11, qword ptr [r15+0x130]
000071709abce789  psubd xmm12, xmm11
000071709abce78e  movq xmm12, xmm12
000071709abce793  paddq xmm13, xmm14
000071709abce798  movaps [r15+0x180], xmm13
000071709abce7a0  movq xmm14, qword ptr [r15+0x150]
000071709abce7a9  paddd xmm11, xmm14
000071709abce7ae  movq xmm11, xmm11
000071709abce7b3  movq xmm11, xmm11
000071709abce7b8  movaps [r15+0x130], xmm11
000071709abce7c0  pmovzxdq xmm12, xmm12
000071709abce7c6  psllq xmm12, 0x00
000071709abce7cc  movq xmm14, qword ptr [r15+0x210]
000071709abce7d5  movq xmm13, qword ptr [r15+0x110]
000071709abce7de  paddd xmm14, xmm13
000071709abce7e3  movq xmm14, xmm14
000071709abce7e8  vcvtuqq2pd xmm12, xmm12
000071709abce7ee  pmovzxdq xmm14, xmm14
000071709abce7f4  psllq xmm14, 0x00
000071709abce7fa  vcvtuqq2pd xmm14, xmm14
000071709abce800  movaps xmm13, xmm12
000071709abce804  mulpd xmm13, xmm1
000071709abce809  vcmppd xmm11, xmm13, xmm13, 0x03
000071709abce80f  ptest xmm11, xmm11
000071709abce815  jnz 0x000071709ABCE8FF
000071709abce81b  movaps [r15+0x220], xmm13
000071709abce823  mov eax, 0x430720
000071709abce828  movups [r13+rax*1], xmm13
000071709abce82e  movaps xmm1, xmm14
000071709abce832  mulpd xmm1, xmm15
000071709abce837  vcmppd xmm13, xmm1, xmm1, 0x03
000071709abce83c  ptest xmm13, xmm13
000071709abce842  jnz 0x000071709ABCEA4C
000071709abce848  movaps [r15+0x210], xmm1
000071709abce850  mov eax, 0x430518
000071709abce855  movups [r13+rax*1], xmm1
000071709abce85b  mov qword ptr [r15+0x48], 0x10
000071709abce863  xor eax, eax
000071709abce865  mov r14d, 0x10
000071709abce86b  mov r12d, 0x200
000071709abce871  cmp r14, r12
000071709abce874  cmc
000071709abce875  lahf
000071709abce876  seto al
000071709abce879  mov [r15+0x108], eax
000071709abce880  mov eax, [r15+0x108]
000071709abce887  sahf
000071709abce888  jnz 0x000071709ABCE8BA
000071709abce88a  cmp dword ptr [r15+0x318], 0x00
000071709abce892  jz 0x000071709ABCEFF0
000071709abce898  nop [rax+rax*1], ax
000071709abce8a1  nop [rax+rax*1], eax
000071709abce8a9  mov eax, 0x4101EC
000071709abce8ae  mov [r15+0x100], rax
000071709abce8b5  jmp 0x000071709A9FE110
000071709abce8ba  cmp dword ptr [r15+0x318], 0x00
000071709abce8c2  jz 0x000071709ABCEBA0
000071709abce8c8  nop [rax+rax*1], ax
000071709abce8d1  nop [rax+rax*1], eax
000071709abce8d9  mov eax, 0x4101AC
000071709abce8de  mov [r15+0x100], rax
000071709abce8e5  jmp 0x000071709A9FE110
000071709abce8ea  int3
000071709abce8eb  call 0x000071709AA0DC20
000071709abce8f0  jmp 0x000071709ABCE6D2
000071709abce8f5  call 0x000071709AA0C260
000071709abce8fa  jmp 0x000071709ABCE74F
000071709abce8ff  sub rsp, 0x08
000071709abce903  push rax
000071709abce904  push rcx
000071709abce905  push rdx
000071709abce906  push rdi
000071709abce907  push rsi
000071709abce908  push r8
000071709abce90a  push r9
000071709abce90c  push r10
000071709abce90e  push r11
000071709abce910  sub rsp, 0xF0
000071709abce917  vmovaps [rsp], xmm0
000071709abce91c  vmovaps [rsp+0x10], xmm1
000071709abce922  vmovaps [rsp+0x20], xmm2
000071709abce928  vmovaps [rsp+0x30], xmm3
000071709abce92e  vmovaps [rsp+0x40], xmm4
000071709abce934  vmovaps [rsp+0x50], xmm5
000071709abce93a  vmovaps [rsp+0x60], xmm6
000071709abce940  vmovaps [rsp+0x70], xmm7
000071709abce946  vmovaps [rsp+0x80], xmm8
000071709abce94f  vmovaps [rsp+0x90], xmm9
000071709abce958  vmovaps [rsp+0xA0], xmm10
000071709abce961  vmovaps [rsp+0xB0], xmm11
000071709abce96a  vmovaps [rsp+0xC0], xmm12
000071709abce973  vmovaps [rsp+0xD0], xmm14
000071709abce97c  vmovaps [rsp+0xE0], xmm15
000071709abce985  sub rsp, 0x30
000071709abce989  movaps [rsp], xmm13
000071709abce98e  movaps [rsp+0x10], xmm12
000071709abce994  movaps [rsp+0x20], xmm1
000071709abce999  lea rdi, [rsp]
000071709abce99d  mov esi, 0x00
000071709abce9a2  mov rax, 0x60B9B2ABC530
000071709abce9ac  call rax
000071709abce9ae  movaps xmm13, [rsp]
000071709abce9b3  add rsp, 0x30
000071709abce9b7  vmovaps xmm0, [rsp]
000071709abce9bc  vmovaps xmm1, [rsp+0x10]
000071709abce9c2  vmovaps xmm2, [rsp+0x20]
000071709abce9c8  vmovaps xmm3, [rsp+0x30]
000071709abce9ce  vmovaps xmm4, [rsp+0x40]
000071709abce9d4  vmovaps xmm5, [rsp+0x50]
000071709abce9da  vmovaps xmm6, [rsp+0x60]
000071709abce9e0  vmovaps xmm7, [rsp+0x70]
000071709abce9e6  vmovaps xmm8, [rsp+0x80]
000071709abce9ef  vmovaps xmm9, [rsp+0x90]
000071709abce9f8  vmovaps xmm10, [rsp+0xA0]
000071709abcea01  vmovaps xmm11, [rsp+0xB0]
000071709abcea0a  vmovaps xmm12, [rsp+0xC0]
000071709abcea13  vmovaps xmm14, [rsp+0xD0]
000071709abcea1c  vmovaps xmm15, [rsp+0xE0]
000071709abcea25  add rsp, 0xF0
000071709abcea2c  pop r11
000071709abcea2e  pop r10
000071709abcea30  pop r9
000071709abcea32  pop r8
000071709abcea34  pop rsi
000071709abcea35  pop rdi
000071709abcea36  pop rdx
000071709abcea37  pop rcx
000071709abcea38  pop rax
000071709abcea39  add rsp, 0x08
000071709abcea3d  jmp 0x000071709ABCE81B
000071709abcea42  call 0x000071709AA0C380
000071709abcea47  jmp 0x000071709ABCE82E
000071709abcea4c  sub rsp, 0x08
000071709abcea50  push rax
000071709abcea51  push rcx
000071709abcea52  push rdx
000071709abcea53  push rdi
000071709abcea54  push rsi
000071709abcea55  push r8
000071709abcea57  push r9
000071709abcea59  push r10
000071709abcea5b  push r11
000071709abcea5d  sub rsp, 0xF0
000071709abcea64  vmovaps [rsp], xmm0
000071709abcea69  vmovaps [rsp+0x10], xmm2
000071709abcea6f  vmovaps [rsp+0x20], xmm3
000071709abcea75  vmovaps [rsp+0x30], xmm4
000071709abcea7b  vmovaps [rsp+0x40], xmm5
000071709abcea81  vmovaps [rsp+0x50], xmm6
000071709abcea87  vmovaps [rsp+0x60], xmm7
000071709abcea8d  vmovaps [rsp+0x70], xmm8
000071709abcea93  vmovaps [rsp+0x80], xmm9
000071709abcea9c  vmovaps [rsp+0x90], xmm10
000071709abceaa5  vmovaps [rsp+0xA0], xmm11
000071709abceaae  vmovaps [rsp+0xB0], xmm12
000071709abceab7  vmovaps [rsp+0xC0], xmm13
000071709abceac0  vmovaps [rsp+0xD0], xmm14
000071709abceac9  vmovaps [rsp+0xE0], xmm15
000071709abcead2  sub rsp, 0x30
000071709abcead6  movaps [rsp], xmm1
000071709abceada  movaps [rsp+0x10], xmm14
000071709abceae0  movaps [rsp+0x20], xmm15
000071709abceae6  lea rdi, [rsp]
000071709abceaea  mov esi, 0x00
000071709abceaef  mov rax, 0x60B9B2ABC530
000071709abceaf9  call rax
000071709abceafb  movaps xmm1, [rsp]
000071709abceaff  add rsp, 0x30
000071709abceb03  vmovaps xmm0, [rsp]
000071709abceb08  vmovaps xmm2, [rsp+0x10]
000071709abceb0e  vmovaps xmm3, [rsp+0x20]
000071709abceb14  vmovaps xmm4, [rsp+0x30]
000071709abceb1a  vmovaps xmm5, [rsp+0x40]
000071709abceb20  vmovaps xmm6, [rsp+0x50]
000071709abceb26  vmovaps xmm7, [rsp+0x60]
000071709abceb2c  vmovaps xmm8, [rsp+0x70]
000071709abceb32  vmovaps xmm9, [rsp+0x80]
000071709abceb3b  vmovaps xmm10, [rsp+0x90]
000071709abceb44  vmovaps xmm11, [rsp+0xA0]
000071709abceb4d  vmovaps xmm12, [rsp+0xB0]
000071709abceb56  vmovaps xmm13, [rsp+0xC0]
000071709abceb5f  vmovaps xmm14, [rsp+0xD0]
000071709abceb68  vmovaps xmm15, [rsp+0xE0]
000071709abceb71  add rsp, 0xF0
000071709abceb78  pop r11
000071709abceb7a  pop r10
000071709abceb7c  pop r9
000071709abceb7e  pop r8
000071709abceb80  pop rsi
000071709abceb81  pop rdi
000071709abceb82  pop rdx
000071709abceb83  pop rcx
000071709abceb84  pop rax
000071709abceb85  add rsp, 0x08
000071709abceb89  jmp 0x000071709ABCE848
000071709abceb8e  call 0x000071709A9FF540
000071709abceb93  jmp 0x000071709ABCE85B
000071709abceb98  int3
000071709abceb99  nop [rax], eax
000071709abceba0  movaps xmm1, [r15+0x180]
000071709abceba8  vpmovqd xmm15, xmm1
000071709abcebae  pxor xmm14, xmm14
000071709abcebb3  punpcklqdq xmm15, xmm14
000071709abcebb8  movaps [r15+0x210], xmm15
000071709abcebc0  movq xmm15, qword ptr [r15+0x120]
000071709abcebc9  movq xmm14, qword ptr [r15+0x130]
000071709abcebd2  psubd xmm15, xmm14
000071709abcebd7  movq xmm15, xmm15
000071709abcebdc  movaps xmm13, [r15+0x170]
000071709abcebe4  paddq xmm1, xmm13
000071709abcebe9  movaps [r15+0x180], xmm1
000071709abcebf1  movq xmm1, qword ptr [r15+0x150]
000071709abcebfa  paddd xmm14, xmm1
000071709abcebff  movq xmm14, xmm14
000071709abcec04  movq xmm14, xmm14
000071709abcec09  movaps [r15+0x130], xmm14
000071709abcec11  pmovzxdq xmm15, xmm15
000071709abcec17  psllq xmm15, 0x00
000071709abcec1d  movq xmm1, qword ptr [r15+0x210]
000071709abcec26  movq xmm14, qword ptr [r15+0x110]
000071709abcec2f  paddd xmm1, xmm14
000071709abcec34  movq xmm1, xmm1
000071709abcec38  vcvtuqq2pd xmm15, xmm15
000071709abcec3e  pmovzxdq xmm1, xmm1
000071709abcec43  psllq xmm1, 0x00
000071709abcec48  vcvtuqq2pd xmm1, xmm1
000071709abcec4e  movaps xmm14, [r15+0x140]
000071709abcec56  movaps xmm13, xmm15
000071709abcec5a  mulpd xmm13, xmm14
000071709abcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000071709abcec65  ptest xmm12, xmm12
000071709abcec6b  jnz 0x000071709ABCED4E
000071709abcec71  movaps [r15+0x220], xmm13
000071709abcec79  mov rax, [r15+0x48]
000071709abcec7d  mov r14, [r15+0x50]
000071709abcec81  lea r12, [r14+rax*1]
000071709abcec85  movups [r13+r12*1], xmm13
000071709abcec8b  movaps xmm15, [r15+0x160]
000071709abcec93  movaps xmm14, xmm1
000071709abcec97  mulpd xmm14, xmm15
000071709abcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000071709abceca2  ptest xmm13, xmm13
000071709abceca8  jnz 0x000071709ABCEE9C
000071709abcecae  movaps [r15+0x210], xmm14
000071709abcecb6  mov r14, [r15+0x40]
000071709abcecba  lea r12, [r14+rax*1]
000071709abcecbe  movups [r13+r12*1], xmm14
000071709abcecc4  lea r14, [rax+0x10]
000071709abcecc8  mov [r15+0x48], r14
000071709abceccc  xor eax, eax
000071709abcecce  mov r12d, 0x200
000071709abcecd4  cmp r14, r12
000071709abcecd7  cmc
000071709abcecd8  lahf
000071709abcecd9  seto al
000071709abcecdc  mov [r15+0x108], eax
000071709abcece3  mov eax, [r15+0x108]
000071709abcecea  sahf
000071709abceceb  jnz 0x000071709ABCED1D
000071709abceced  cmp dword ptr [r15+0x318], 0x00
000071709abcecf5  jz 0x000071709ABCEFF0
000071709abcecfb  nop [rax+rax*1], ax
000071709abced04  nop [rax+rax*1], eax
000071709abced0c  mov eax, 0x4101EC
000071709abced11  mov [r15+0x100], rax
000071709abced18  jmp 0x000071709A9FE110
000071709abced1d  cmp dword ptr [r15+0x318], 0x00
000071709abced25  jz 0x000071709ABCEBA0
000071709abced2b  nop [rax+rax*1], ax
000071709abced34  nop [rax+rax*1], eax
000071709abced3c  mov eax, 0x4101AC
000071709abced41  mov [r15+0x100], rax
000071709abced48  jmp 0x000071709A9FE110
000071709abced4d  int3
000071709abced4e  sub rsp, 0x08
000071709abced52  push rax
000071709abced53  push rcx
000071709abced54  push rdx
000071709abced55  push rdi
000071709abced56  push rsi
000071709abced57  push r8
000071709abced59  push r9
000071709abced5b  push r10
000071709abced5d  push r11
000071709abced5f  sub rsp, 0xF0
000071709abced66  vmovaps [rsp], xmm0
000071709abced6b  vmovaps [rsp+0x10], xmm1
000071709abced71  vmovaps [rsp+0x20], xmm2
000071709abced77  vmovaps [rsp+0x30], xmm3
000071709abced7d  vmovaps [rsp+0x40], xmm4
000071709abced83  vmovaps [rsp+0x50], xmm5
000071709abced89  vmovaps [rsp+0x60], xmm6
000071709abced8f  vmovaps [rsp+0x70], xmm7
000071709abced95  vmovaps [rsp+0x80], xmm8
000071709abced9e  vmovaps [rsp+0x90], xmm9
000071709abceda7  vmovaps [rsp+0xA0], xmm10
000071709abcedb0  vmovaps [rsp+0xB0], xmm11
000071709abcedb9  vmovaps [rsp+0xC0], xmm12
000071709abcedc2  vmovaps [rsp+0xD0], xmm14
000071709abcedcb  vmovaps [rsp+0xE0], xmm15
000071709abcedd4  sub rsp, 0x30
000071709abcedd8  movaps [rsp], xmm13
000071709abceddd  movaps [rsp+0x10], xmm15
000071709abcede3  movaps [rsp+0x20], xmm14
000071709abcede9  lea rdi, [rsp]
000071709abceded  mov esi, 0x00
000071709abcedf2  mov rax, 0x60B9B2ABC530
000071709abcedfc  call rax
000071709abcedfe  movaps xmm13, [rsp]
000071709abcee03  add rsp, 0x30
000071709abcee07  vmovaps xmm0, [rsp]
000071709abcee0c  vmovaps xmm1, [rsp+0x10]
000071709abcee12  vmovaps xmm2, [rsp+0x20]
000071709abcee18  vmovaps xmm3, [rsp+0x30]
000071709abcee1e  vmovaps xmm4, [rsp+0x40]
000071709abcee24  vmovaps xmm5, [rsp+0x50]
000071709abcee2a  vmovaps xmm6, [rsp+0x60]
000071709abcee30  vmovaps xmm7, [rsp+0x70]
000071709abcee36  vmovaps xmm8, [rsp+0x80]
000071709abcee3f  vmovaps xmm9, [rsp+0x90]
000071709abcee48  vmovaps xmm10, [rsp+0xA0]
000071709abcee51  vmovaps xmm11, [rsp+0xB0]
000071709abcee5a  vmovaps xmm12, [rsp+0xC0]
000071709abcee63  vmovaps xmm14, [rsp+0xD0]
000071709abcee6c  vmovaps xmm15, [rsp+0xE0]
000071709abcee75  add rsp, 0xF0
000071709abcee7c  pop r11
000071709abcee7e  pop r10
000071709abcee80  pop r9
000071709abcee82  pop r8
000071709abcee84  pop rsi
000071709abcee85  pop rdi
000071709abcee86  pop rdx
000071709abcee87  pop rcx
000071709abcee88  pop rax
000071709abcee89  add rsp, 0x08
000071709abcee8d  jmp 0x000071709ABCEC71
000071709abcee92  call 0x000071709AAC2240
000071709abcee97  jmp 0x000071709ABCEC8B
000071709abcee9c  sub rsp, 0x08
000071709abceea0  push rax
000071709abceea1  push rcx
000071709abceea2  push rdx
000071709abceea3  push rdi
000071709abceea4  push rsi
000071709abceea5  push r8
000071709abceea7  push r9
000071709abceea9  push r10
000071709abceeab  push r11
000071709abceead  sub rsp, 0xF0
000071709abceeb4  vmovaps [rsp], xmm0
000071709abceeb9  vmovaps [rsp+0x10], xmm1
000071709abceebf  vmovaps [rsp+0x20], xmm2
000071709abceec5  vmovaps [rsp+0x30], xmm3
000071709abceecb  vmovaps [rsp+0x40], xmm4
000071709abceed1  vmovaps [rsp+0x50], xmm5
000071709abceed7  vmovaps [rsp+0x60], xmm6
000071709abceedd  vmovaps [rsp+0x70], xmm7
000071709abceee3  vmovaps [rsp+0x80], xmm8
000071709abceeec  vmovaps [rsp+0x90], xmm9
000071709abceef5  vmovaps [rsp+0xA0], xmm10
000071709abceefe  vmovaps [rsp+0xB0], xmm11
000071709abcef07  vmovaps [rsp+0xC0], xmm12
000071709abcef10  vmovaps [rsp+0xD0], xmm13
000071709abcef19  vmovaps [rsp+0xE0], xmm15
000071709abcef22  sub rsp, 0x30
000071709abcef26  movaps [rsp], xmm14
000071709abcef2b  movaps [rsp+0x10], xmm1
000071709abcef30  movaps [rsp+0x20], xmm15
000071709abcef36  lea rdi, [rsp]
000071709abcef3a  mov esi, 0x00
000071709abcef3f  mov rax, 0x60B9B2ABC530
000071709abcef49  call rax
000071709abcef4b  movaps xmm14, [rsp]
000071709abcef50  add rsp, 0x30
000071709abcef54  vmovaps xmm0, [rsp]
000071709abcef59  vmovaps xmm1, [rsp+0x10]
000071709abcef5f  vmovaps xmm2, [rsp+0x20]
000071709abcef65  vmovaps xmm3, [rsp+0x30]
000071709abcef6b  vmovaps xmm4, [rsp+0x40]
000071709abcef71  vmovaps xmm5, [rsp+0x50]
000071709abcef77  vmovaps xmm6, [rsp+0x60]
000071709abcef7d  vmovaps xmm7, [rsp+0x70]
000071709abcef83  vmovaps xmm8, [rsp+0x80]
000071709abcef8c  vmovaps xmm9, [rsp+0x90]
000071709abcef95  vmovaps xmm10, [rsp+0xA0]
000071709abcef9e  vmovaps xmm11, [rsp+0xB0]
000071709abcefa7  vmovaps xmm12, [rsp+0xC0]
000071709abcefb0  vmovaps xmm13, [rsp+0xD0]
000071709abcefb9  vmovaps xmm15, [rsp+0xE0]
000071709abcefc2  add rsp, 0xF0
000071709abcefc9  pop r11
000071709abcefcb  pop r10
000071709abcefcd  pop r9
000071709abcefcf  pop r8
000071709abcefd1  pop rsi
000071709abcefd2  pop rdi
000071709abcefd3  pop rdx
000071709abcefd4  pop rcx
000071709abcefd5  pop rax
000071709abcefd6  add rsp, 0x08
000071709abcefda  jmp 0x000071709ABCECAE
000071709abcefdf  call 0x000071709AAC34C0
000071709abcefe4  jmp 0x000071709ABCECC4
000071709abcefe9  int3
000071709abcefea  nop [rax+rax*1], ax
000071709abceff0  mov rax, [r15+0xF8]
000071709abceff7  lea r14, [rax-0x150]
000071709abceffe  mov [r15+0xF8], r14
000071709abcf005  mov rax, [r15+0x50]
000071709abcf009  lea r12, [rax+0x80]
000071709abcf010  movups xmm1, [r13+r12*1]
000071709abcf016  lea r12, [rax+0x90]
000071709abcf01d  movups xmm15, [r13+r12*1]
000071709abcf023  mov qword ptr [r15+0x48], 0x00
000071709abcf02b  lea r12, [rax+0x40]
000071709abcf02f  movups xmm14, [r13+r12*1]
000071709abcf035  lea r12, [rax+0x50]
000071709abcf039  movups xmm13, [r13+r12*1]
000071709abcf03f  lea r12, [r14+0x120]
000071709abcf046  movq xmm12, qword ptr [r15+0x1C0]
000071709abcf04f  movq xmm11, qword ptr [r15+0x1B0]
000071709abcf058  movq r11, xmm12
000071709abcf05d  movq r10, xmm11
000071709abcf062  mov [r13+r12*1], r11
000071709abcf067  lea r12, [r14+0x128]
000071709abcf06e  mov [r13+r12*1], r10
000071709abcf073  vxorps xmm12, xmm12, xmm12
000071709abcf078  vpbroadcastq xmm12, xmm12
000071709abcf07d  lea r12, [r14+0x100]
000071709abcf084  movq xmm11, qword ptr [r15+0x200]
000071709abcf08d  movq xmm10, qword ptr [r15+0x1F0]
000071709abcf096  movq r11, xmm11
000071709abcf09b  movq r10, xmm10
000071709abcf0a0  mov [r13+r12*1], r11
000071709abcf0a5  lea r12, [r14+0x108]
000071709abcf0ac  mov [r13+r12*1], r10
000071709abcf0b1  lea r12, [r14+0xE0]
000071709abcf0b8  movups [r13+r12*1], xmm15
000071709abcf0be  lea r12, [r14+0xF0]
000071709abcf0c5  movups [r13+r12*1], xmm1
000071709abcf0cb  lea r12, [rax+0xC0]
000071709abcf0d2  movups xmm1, [r13+r12*1]
000071709abcf0d8  lea r12, [rax+0xD0]
000071709abcf0df  movups xmm15, [r13+r12*1]
000071709abcf0e5  lea r12, [r14+0x110]
000071709abcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000071709abcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000071709abcf0fe  movq r11, xmm11
000071709abcf103  movq r10, xmm10
000071709abcf108  mov [r13+r12*1], r11
000071709abcf10d  lea r12, [r14+0x118]
000071709abcf114  mov [r13+r12*1], r10
000071709abcf119  movups xmm11, [r13+rax*1]
000071709abcf11f  lea r12, [rax+0x10]
000071709abcf123  movups xmm10, [r13+r12*1]
000071709abcf129  lea r12, [r14+0x130]
000071709abcf130  movq xmm9, qword ptr [r15+0x1A0]
000071709abcf139  movq xmm8, qword ptr [r15+0x190]
000071709abcf142  movq r11, xmm9
000071709abcf147  movq r10, xmm8
000071709abcf14c  mov [r13+r12*1], r11
000071709abcf151  lea r12, [r14+0x138]
000071709abcf158  mov [r13+r12*1], r10
000071709abcf15d  lea r12, [rax+0x140]
000071709abcf164  movups xmm9, [r13+r12*1]
000071709abcf16a  lea r12, [rax+0x150]
000071709abcf171  movups xmm8, [r13+r12*1]
000071709abcf177  lea r12, [r14+0xC0]
000071709abcf17e  movups [r13+r12*1], xmm15
000071709abcf184  lea r12, [r14+0xD0]
000071709abcf18b  movups [r13+r12*1], xmm1
000071709abcf191  lea r12, [rax+0x100]
000071709abcf198  movups xmm1, [r13+r12*1]
000071709abcf19e  lea r12, [rax+0x110]
000071709abcf1a5  movups xmm15, [r13+r12*1]
000071709abcf1ab  lea r12, [r14+0x140]
000071709abcf1b2  mov r11, [r15+0xE8]
000071709abcf1b9  mov [r13+r12*1], r11
000071709abcf1be  lea r12, [rax+0x180]
000071709abcf1c5  movups xmm7, [r13+r12*1]
000071709abcf1cb  lea r12, [rax+0x190]
000071709abcf1d2  movups xmm6, [r13+r12*1]
000071709abcf1d8  lea r12, [rax+0x1C0]
000071709abcf1df  movups xmm5, [r13+r12*1]
000071709abcf1e5  lea r12, [rax+0x1D0]
000071709abcf1ec  movups xmm4, [r13+r12*1]
000071709abcf1f2  lea r12, [r14+0x20]
000071709abcf1f6  movups [r13+r12*1], xmm1
000071709abcf1fc  lea r12, [r14+0x30]
000071709abcf200  movups [r13+r12*1], xmm13
000071709abcf206  lea r12, [rax+0x60]
000071709abcf20a  movups xmm1, [r13+r12*1]
000071709abcf210  lea r12, [rax+0x70]
000071709abcf214  movups xmm13, [r13+r12*1]
000071709abcf21a  lea r12, [rax+0x20]
000071709abcf21e  movups xmm3, [r13+r12*1]
000071709abcf224  lea r12, [rax+0x30]
000071709abcf228  movups xmm2, [r13+r12*1]
000071709abcf22e  movaps [r15+0x1F0], xmm2
000071709abcf236  lea r12, [r14+0x60]
000071709abcf23a  movups [r13+r12*1], xmm11
000071709abcf240  lea r12, [r14+0x70]
000071709abcf244  movups [r13+r12*1], xmm5
000071709abcf24a  lea r12, [rax+0xE0]
000071709abcf251  movups xmm11, [r13+r12*1]
000071709abcf257  lea r12, [rax+0xF0]
000071709abcf25e  movups xmm5, [r13+r12*1]
000071709abcf264  lea r12, [r14+0xA0]
000071709abcf26b  movups [r13+r12*1], xmm13
000071709abcf271  lea r12, [r14+0xB0]
000071709abcf278  movups [r13+r12*1], xmm1
000071709abcf27e  lea r12, [rax+0xA0]
000071709abcf285  movups xmm1, [r13+r12*1]
000071709abcf28b  lea r12, [rax+0xB0]
000071709abcf292  movups xmm13, [r13+r12*1]
000071709abcf298  lea r12, [rax+0x120]
000071709abcf29f  vmovaps [rsp+0x10], xmm1
000071709abcf2a5  movups xmm1, [r13+r12*1]
000071709abcf2ab  lea r12, [rax+0x130]
000071709abcf2b2  vmovaps [rsp+0x20], xmm1
000071709abcf2b8  movups xmm1, [r13+r12*1]
000071709abcf2be  lea r12, [rax+0x160]
000071709abcf2c5  vmovaps [rsp+0x30], xmm1
000071709abcf2cb  movups xmm1, [r13+r12*1]
000071709abcf2d1  lea r12, [rax+0x170]
000071709abcf2d8  vmovaps [rsp+0x40], xmm1
000071709abcf2de  movups xmm1, [r13+r12*1]
000071709abcf2e4  movaps [r15+0x2B0], xmm1
000071709abcf2ec  lea r12, [r14+0x80]
000071709abcf2f3  movups [r13+r12*1], xmm13
000071709abcf2f9  lea r12, [r14+0x90]
000071709abcf300  vmovaps xmm13, [rsp+0x10]
000071709abcf306  movups [r13+r12*1], xmm13
000071709abcf30c  lea r12, [rax+0x1A0]
000071709abcf313  movups xmm13, [r13+r12*1]
000071709abcf319  lea r12, [rax+0x1B0]
000071709abcf320  vmovaps [rsp+0x10], xmm1
000071709abcf326  movups xmm1, [r13+r12*1]
000071709abcf32c  movaps [r15+0x290], xmm13
000071709abcf334  movaps [r15+0x1E0], xmm1
000071709abcf33c  lea r12, [rax+0x1E0]
000071709abcf343  vmovaps [rsp+0x50], xmm1
000071709abcf349  movups xmm1, [r13+r12*1]
000071709abcf34f  lea r12, [rax+0x1F0]
000071709abcf356  vmovaps [rsp+0x60], xmm1
000071709abcf35c  movups xmm1, [r13+r12*1]
000071709abcf362  mov qword ptr [r15+0x50], 0x430920
000071709abcf36a  lea rax, [r14+0x40]
000071709abcf36e  vmovaps [rsp+0x70], xmm1
000071709abcf374  vmovaps xmm1, [rsp+0x40]
000071709abcf37a  movups [r13+rax*1], xmm1
000071709abcf380  lea rax, [r14+0x50]
000071709abcf384  movups [r13+rax*1], xmm10
000071709abcf38a  vmovaps xmm1, [rsp+0x70]
000071709abcf390  movups [r13+r14*1], xmm1
000071709abcf396  lea rax, [r14+0x10]
000071709abcf39a  vmovaps xmm1, [rsp+0x60]
000071709abcf3a0  movups [r13+rax*1], xmm1
000071709abcf3a6  mov rax, [r15+0x40]
000071709abcf3aa  vmovaps [rsp+0x40], xmm3
000071709abcf3b0  vmovaps xmm1, [rsp+0x40]
000071709abcf3b6  por xmm3, xmm1
000071709abcf3ba  vmovaps [rsp+0x40], xmm6
000071709abcf3c0  vmovaps xmm10, [rsp+0x40]
000071709abcf3c6  por xmm6, xmm10
000071709abcf3cb  lea r12, [rax+0x30]
000071709abcf3cf  mov r11, [r13+r12*1]
000071709abcf3d4  lea r12, [rax+0x38]
000071709abcf3d8  mov r10, [r13+r12*1]
000071709abcf3dd  movq xmm10, r11
000071709abcf3e2  vmovaps [rsp+0x40], xmm1
000071709abcf3e8  movq xmm1, r10
000071709abcf3ed  movq xmm10, xmm10
000071709abcf3f2  vmovaps [rsp+0x60], xmm10
000071709abcf3f8  movq xmm10, xmm10
000071709abcf3fd  movaps [r15+0x130], xmm10
000071709abcf405  movq xmm1, xmm1
000071709abcf409  vmovaps [rsp+0x70], xmm1
000071709abcf40f  movq xmm1, xmm1
000071709abcf413  movaps [r15+0x280], xmm1
000071709abcf41b  vmovaps [rsp+0x80], xmm9
000071709abcf424  vmovaps xmm1, [rsp+0x80]
000071709abcf42d  por xmm9, xmm1
000071709abcf432  lea r12, [rax+0x20]
000071709abcf436  mov r11, [r13+r12*1]
000071709abcf43b  lea r12, [rax+0x28]
000071709abcf43f  mov r10, [r13+r12*1]
000071709abcf444  movq xmm1, r11
000071709abcf449  movq xmm10, r10
000071709abcf44e  movq xmm1, xmm1
000071709abcf452  vmovaps [rsp+0x80], xmm1
000071709abcf45b  movq xmm1, xmm1
000071709abcf45f  movaps [r15+0x150], xmm1
000071709abcf467  movq xmm10, xmm10
000071709abcf46c  vmovaps [rsp+0x90], xmm10
000071709abcf475  movq xmm10, xmm10
000071709abcf47a  movaps [r15+0x140], xmm10
000071709abcf482  lea r12, [rax+0x10]
000071709abcf486  mov r11, [r13+r12*1]
000071709abcf48b  lea r12, [rax+0x18]
000071709abcf48f  mov r10, [r13+r12*1]
000071709abcf494  movq xmm1, r11
000071709abcf499  movq xmm10, r10
000071709abcf49e  movq xmm1, xmm1
000071709abcf4a2  vmovaps [rsp+0xA0], xmm1
000071709abcf4ab  movq xmm1, xmm1
000071709abcf4af  movaps [r15+0x170], xmm1
000071709abcf4b7  movq xmm10, xmm10
000071709abcf4bc  vmovaps [rsp+0xB0], xmm10
000071709abcf4c5  movq xmm10, xmm10
000071709abcf4ca  movaps [r15+0x160], xmm10
000071709abcf4d2  mov r12, [r13+rax*1]
000071709abcf4d7  vmovq xmm1, r12
000071709abcf4dc  vpbroadcastq xmm1, xmm1
000071709abcf4e1  lea r12, [rax+0x08]
000071709abcf4e5  mov rax, [r13+r12*1]
000071709abcf4ea  movq xmm10, rax
000071709abcf4ef  movaps [r15+0x230], xmm10
000071709abcf4f7  lea rax, [r14+0x50]
000071709abcf4fb  movups xmm10, [r13+rax*1]
000071709abcf501  lea rax, [r14+0x60]
000071709abcf505  vmovaps [rsp+0xC0], xmm1
000071709abcf50e  movups xmm1, [r13+rax*1]
000071709abcf514  lea rax, [r14+0x30]
000071709abcf518  vmovaps [rsp+0xD0], xmm1
000071709abcf521  movups xmm1, [r13+rax*1]
000071709abcf527  mov qword ptr [r15+0x60], 0x430920
000071709abcf52f  mov qword ptr [r15+0x58], 0x40
000071709abcf537  vmovaps [rsp+0xE0], xmm1
000071709abcf540  vmovaps [rsp+0xF0], xmm15
000071709abcf549  vmovaps xmm15, [rsp+0xC0]
000071709abcf552  vmovaps [rsp+0xC0], xmm14
000071709abcf55b  vmovaps xmm14, [rsp+0x40]
000071709abcf561  vmovaps [rsp+0x40], xmm13
000071709abcf567  movaps xmm1, xmm15
000071709abcf56b  mulpd xmm1, xmm14
000071709abcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000071709abcf575  ptest xmm13, xmm13
000071709abcf57b  jnz 0x000071709ABD0682
000071709abcf581  movq xmm14, qword ptr [r15+0x230]
000071709abcf58a  vmovaps [rsp+0x100], xmm14
000071709abcf593  vpermilpd xmm14, xmm14, 0x00
000071709abcf599  vmovaps [rsp+0x110], xmm1
000071709abcf5a2  vmovaps xmm1, [rsp+0xE0]
000071709abcf5ab  vmovaps [rsp+0xE0], xmm15
000071709abcf5b4  movaps xmm13, xmm1
000071709abcf5b8  mulpd xmm13, xmm14
000071709abcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000071709abcf5c3  ptest xmm15, xmm15
000071709abcf5c9  jnz 0x000071709ABD07C4
000071709abcf5cf  vxorps xmm1, xmm1, xmm1
000071709abcf5d3  vpbroadcastq xmm1, xmm1
000071709abcf5d8  vmovaps xmm14, [rsp+0xE0]
000071709abcf5e1  vmovaps [rsp+0xE0], xmm1
000071709abcf5ea  vmovaps xmm1, [rsp+0xD0]
000071709abcf5f3  vmovaps [rsp+0xD0], xmm13
000071709abcf5fc  movaps xmm15, xmm14
000071709abcf600  mulpd xmm15, xmm1
000071709abcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000071709abcf60b  ptest xmm13, xmm13
000071709abcf611  jnz 0x000071709ABD0907
000071709abcf617  movaps xmm1, xmm14
000071709abcf61b  mulpd xmm1, xmm10
000071709abcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000071709abcf625  ptest xmm13, xmm13
000071709abcf62b  jnz 0x000071709ABD0A4A
000071709abcf631  movaps xmm13, xmm14
000071709abcf635  mulpd xmm13, xmm2
000071709abcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000071709abcf640  ptest xmm10, xmm10
000071709abcf646  jnz 0x000071709ABD0B8C
000071709abcf64c  vmovaps [rsp+0x120], xmm7
000071709abcf655  vmovaps xmm14, [rsp+0x120]
000071709abcf65e  por xmm7, xmm14
000071709abcf663  vmovaps xmm14, [rsp+0xC0]
000071709abcf66c  vmovaps xmm10, [rsp+0xC0]
000071709abcf675  por xmm14, xmm10
000071709abcf67a  vmovaps xmm2, [rsp+0x100]
000071709abcf683  vpermilpd xmm2, xmm2, 0x00
000071709abcf689  vmovaps [rsp+0xC0], xmm1
000071709abcf692  vmovaps [rsp+0x120], xmm15
000071709abcf69b  movaps xmm1, xmm10
000071709abcf69f  mulpd xmm1, xmm2
000071709abcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000071709abcf6a8  ptest xmm15, xmm15
000071709abcf6ae  jnz 0x000071709ABD0CCF
000071709abcf6b4  xor eax, eax
000071709abcf6b6  mov r12d, 0x40
000071709abcf6bc  mov r11d, 0x200
000071709abcf6c2  cmp r12, r11
000071709abcf6c5  cmc
000071709abcf6c6  lahf
000071709abcf6c7  seto al
000071709abcf6ca  mov [r15+0x108], eax
000071709abcf6d1  vmovaps xmm10, [rsp+0x110]
000071709abcf6da  vmovaps xmm2, [rsp+0xE0]
000071709abcf6e3  vmovaps [rsp+0xE0], xmm1
000071709abcf6ec  movaps xmm15, xmm10
000071709abcf6f0  addpd xmm15, xmm2
000071709abcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abcf6fb  ptest xmm1, xmm1
000071709abcf700  jnz 0x000071709ABD0E10
000071709abcf706  vmovaps xmm10, [rsp+0x120]
000071709abcf70f  vmovaps [rsp+0x110], xmm15
000071709abcf718  movaps xmm1, xmm10
000071709abcf71c  addpd xmm1, xmm12
000071709abcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000071709abcf726  ptest xmm15, xmm15
000071709abcf72c  jnz 0x000071709ABD0F53
000071709abcf732  vmovaps xmm10, [rsp+0xC0]
000071709abcf73b  vmovaps [rsp+0xC0], xmm1
000071709abcf744  movaps xmm15, xmm10
000071709abcf748  addpd xmm15, xmm12
000071709abcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abcf753  ptest xmm1, xmm1
000071709abcf758  jnz 0x000071709ABD1095
000071709abcf75e  vmovaps xmm1, [rsp+0x30]
000071709abcf764  vmovaps xmm12, [rsp+0x30]
000071709abcf76a  por xmm1, xmm12
000071709abcf76f  vmovaps xmm12, [rsp+0x20]
000071709abcf775  vmovaps xmm10, [rsp+0x20]
000071709abcf77b  por xmm12, xmm10
000071709abcf780  vmovaps [rsp+0x20], xmm5
000071709abcf786  vmovaps xmm10, [rsp+0x20]
000071709abcf78c  por xmm5, xmm10
000071709abcf791  vmovaps [rsp+0x20], xmm11
000071709abcf797  vmovaps xmm10, [rsp+0x20]
000071709abcf79d  por xmm11, xmm10
000071709abcf7a2  vmovaps [rsp+0x20], xmm4
000071709abcf7a8  vmovaps xmm10, [rsp+0x20]
000071709abcf7ae  por xmm4, xmm10
000071709abcf7b3  vmovaps [rsp+0x20], xmm8
000071709abcf7b9  vmovaps xmm10, [rsp+0x20]
000071709abcf7bf  por xmm8, xmm10
000071709abcf7c4  vmovaps xmm10, [rsp+0xF0]
000071709abcf7cd  vmovaps [rsp+0x20], xmm1
000071709abcf7d3  vmovaps xmm1, [rsp+0xF0]
000071709abcf7dc  por xmm10, xmm1
000071709abcf7e1  lea rax, [r14+0xA0]
000071709abcf7e8  movups xmm1, [r13+rax*1]
000071709abcf7ee  lea rax, [r14+0xB0]
000071709abcf7f5  vmovaps [rsp+0x30], xmm1
000071709abcf7fb  movups xmm1, [r13+rax*1]
000071709abcf801  vmovaps [rsp+0xF0], xmm1
000071709abcf80a  vmovaps [rsp+0x120], xmm15
000071709abcf813  movaps xmm1, xmm13
000071709abcf817  addpd xmm1, xmm2
000071709abcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000071709abcf820  ptest xmm15, xmm15
000071709abcf826  jnz 0x000071709ABD11ED
000071709abcf82c  lea rax, [r14+0xF0]
000071709abcf833  movups xmm15, [r13+rax*1]
000071709abcf839  vmovaps xmm2, [rsp+0xC0]
000071709abcf842  vmovaps [rsp+0xC0], xmm1
000071709abcf84b  vmovaps xmm1, [rsp+0xE0]
000071709abcf854  vmovaps [rsp+0xE0], xmm15
000071709abcf85d  movaps xmm13, xmm2
000071709abcf861  addpd xmm13, xmm1
000071709abcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000071709abcf86c  ptest xmm15, xmm15
000071709abcf872  jnz 0x000071709ABD1338
000071709abcf878  vmovaps xmm15, [rsp+0x120]
000071709abcf881  vmovaps xmm2, [rsp+0xD0]
000071709abcf88a  vmovaps [rsp+0xD0], xmm14
000071709abcf893  movaps xmm1, xmm15
000071709abcf897  addpd xmm1, xmm2
000071709abcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000071709abcf8a0  ptest xmm14, xmm14
000071709abcf8a6  jnz 0x000071709ABD147A
000071709abcf8ac  vmovaps xmm15, [rsp+0x100]
000071709abcf8b5  vpermilpd xmm15, xmm15, 0x00
000071709abcf8bb  vmovaps xmm2, [rsp+0xF0]
000071709abcf8c4  vmovaps [rsp+0xF0], xmm1
000071709abcf8cd  movaps xmm14, xmm2
000071709abcf8d1  mulpd xmm14, xmm15
000071709abcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000071709abcf8dc  ptest xmm1, xmm1
000071709abcf8e1  jnz 0x000071709ABD15BB
000071709abcf8e7  vmovaps xmm1, [rsp+0xA0]
000071709abcf8f0  vpermilpd xmm1, xmm1, 0x00
000071709abcf8f6  vmovaps xmm2, [rsp+0xE0]
000071709abcf8ff  vmovaps [rsp+0xE0], xmm14
000071709abcf908  movaps xmm15, xmm2
000071709abcf90c  mulpd xmm15, xmm1
000071709abcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000071709abcf917  ptest xmm14, xmm14
000071709abcf91d  jnz 0x000071709ABD16FE
000071709abcf923  lea rax, [r14+0xE0]
000071709abcf92a  movups xmm1, [r13+rax*1]
000071709abcf930  vmovaps xmm14, [rsp+0x100]
000071709abcf939  vpermilpd xmm14, xmm14, 0x00
000071709abcf93f  vmovaps [rsp+0x100], xmm1
000071709abcf948  vmovaps xmm1, [rsp+0x30]
000071709abcf94e  vmovaps [rsp+0x30], xmm15
000071709abcf954  movaps xmm2, xmm1
000071709abcf957  mulpd xmm2, xmm14
000071709abcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000071709abcf961  ptest xmm15, xmm15
000071709abcf967  jnz 0x000071709ABD184A
000071709abcf96d  vmovaps [rsp+0x120], xmm10
000071709abcf976  vmovaps xmm1, [rsp+0x120]
000071709abcf97f  por xmm10, xmm1
000071709abcf984  movaps [r15+0x300], xmm10
000071709abcf98c  vmovaps [rsp+0x120], xmm8
000071709abcf995  vmovaps xmm1, [rsp+0x120]
000071709abcf99e  por xmm8, xmm1
000071709abcf9a3  movaps [r15+0x190], xmm8
000071709abcf9ab  vmovaps xmm1, [rsp+0xA0]
000071709abcf9b4  vpermilpd xmm1, xmm1, 0x00
000071709abcf9ba  vmovaps xmm14, [rsp+0x100]
000071709abcf9c3  vmovaps [rsp+0x100], xmm13
000071709abcf9cc  movaps xmm15, xmm14
000071709abcf9d0  mulpd xmm15, xmm1
000071709abcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000071709abcf9db  ptest xmm13, xmm13
000071709abcf9e1  jnz 0x000071709ABD198B
000071709abcf9e7  lea rax, [r14+0x90]
000071709abcf9ee  movups xmm1, [r13+rax*1]
000071709abcf9f4  vmovaps [rsp+0x120], xmm4
000071709abcf9fd  vmovaps xmm14, [rsp+0x120]
000071709abcfa06  por xmm4, xmm14
000071709abcfa0b  movaps [r15+0x1C0], xmm4
000071709abcfa13  vmovaps [rsp+0x120], xmm11
000071709abcfa1c  vmovaps xmm14, [rsp+0x120]
000071709abcfa25  por xmm11, xmm14
000071709abcfa2a  movaps [r15+0x200], xmm11
000071709abcfa32  vmovaps [rsp+0x120], xmm5
000071709abcfa3b  vmovaps xmm14, [rsp+0x120]
000071709abcfa44  por xmm5, xmm14
000071709abcfa49  movaps [r15+0x2D0], xmm5
000071709abcfa51  vmovaps [rsp+0x120], xmm12
000071709abcfa5a  vmovaps xmm14, [rsp+0x120]
000071709abcfa63  por xmm12, xmm14
000071709abcfa68  movaps [r15+0x2E0], xmm12
000071709abcfa70  vmovaps xmm13, [rsp+0x110]
000071709abcfa79  vmovaps [rsp+0x110], xmm1
000071709abcfa82  vmovaps xmm1, [rsp+0xE0]
000071709abcfa8b  vmovaps [rsp+0xE0], xmm15
000071709abcfa94  movaps xmm14, xmm13
000071709abcfa98  addpd xmm14, xmm1
000071709abcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000071709abcfaa3  ptest xmm15, xmm15
000071709abcfaa9  jnz 0x000071709ABD1AD8
000071709abcfaaf  vmovaps xmm1, [rsp+0xA0]
000071709abcfab8  vpermilpd xmm1, xmm1, 0x00
000071709abcfabe  vmovaps xmm13, [rsp+0x110]
000071709abcfac7  vmovaps [rsp+0x110], xmm14
000071709abcfad0  movaps xmm15, xmm13
000071709abcfad4  mulpd xmm15, xmm1
000071709abcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000071709abcfadf  ptest xmm14, xmm14
000071709abcfae5  jnz 0x000071709ABD1C1B
000071709abcfaeb  lea rax, [r14+0x80]
000071709abcfaf2  movups xmm1, [r13+rax*1]
000071709abcfaf8  vmovaps xmm13, [rsp+0xC0]
000071709abcfb01  vmovaps [rsp+0xC0], xmm1
000071709abcfb0a  movaps xmm14, xmm13
000071709abcfb0e  addpd xmm14, xmm2
000071709abcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000071709abcfb19  ptest xmm1, xmm1
000071709abcfb1e  jnz 0x000071709ABD1D68
000071709abcfb24  vmovaps xmm13, [rsp+0x100]
000071709abcfb2d  vmovaps xmm2, [rsp+0x30]
000071709abcfb33  vmovaps [rsp+0x30], xmm15
000071709abcfb39  movaps xmm1, xmm13
000071709abcfb3d  addpd xmm1, xmm2
000071709abcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000071709abcfb46  ptest xmm15, xmm15
000071709abcfb4c  jnz 0x000071709ABD1EAB
000071709abcfb52  vmovaps xmm15, [rsp+0x20]
000071709abcfb58  vmovaps xmm13, [rsp+0x20]
000071709abcfb5e  por xmm15, xmm13
000071709abcfb63  movaps [r15+0x2F0], xmm15
000071709abcfb6b  vmovaps xmm13, [rsp+0xA0]
000071709abcfb74  vpermilpd xmm13, xmm13, 0x00
000071709abcfb7a  vmovaps [rsp+0x20], xmm1
000071709abcfb80  vmovaps xmm1, [rsp+0xC0]
000071709abcfb89  vmovaps [rsp+0xA0], xmm15
000071709abcfb92  movaps xmm2, xmm1
000071709abcfb95  mulpd xmm2, xmm13
000071709abcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000071709abcfb9f  ptest xmm15, xmm15
000071709abcfba5  jnz 0x000071709ABD1FEC
000071709abcfbab  lea rax, [r14+0xD0]
000071709abcfbb2  movups xmm1, [r13+rax*1]
000071709abcfbb8  vmovaps xmm13, [rsp+0xF0]
000071709abcfbc1  vmovaps [rsp+0xC0], xmm1
000071709abcfbca  vmovaps xmm1, [rsp+0xE0]
000071709abcfbd3  vmovaps [rsp+0xE0], xmm14
000071709abcfbdc  movaps xmm15, xmm13
000071709abcfbe0  addpd xmm15, xmm1
000071709abcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000071709abcfbeb  ptest xmm14, xmm14
000071709abcfbf1  jnz 0x000071709ABD2137
000071709abcfbf7  vmovaps xmm1, [rsp+0xB0]
000071709abcfc00  vpermilpd xmm1, xmm1, 0x00
000071709abcfc06  movaps xmm14, xmm11
000071709abcfc0a  mulpd xmm14, xmm1
000071709abcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000071709abcfc15  ptest xmm13, xmm13
000071709abcfc1b  jnz 0x000071709ABD227A
000071709abcfc21  movaps [r15+0x260], xmm14
000071709abcfc29  vxorps xmm1, xmm1, xmm1
000071709abcfc2d  vpbroadcastq xmm1, xmm1
000071709abcfc32  movaps [r15+0x1B0], xmm1
000071709abcfc3a  vmovaps xmm1, [rsp+0xB0]
000071709abcfc43  vpermilpd xmm1, xmm1, 0x00
000071709abcfc49  vmovaps xmm11, [rsp+0xC0]
000071709abcfc52  vmovaps [rsp+0xC0], xmm15
000071709abcfc5b  movaps xmm13, xmm11
000071709abcfc5f  mulpd xmm13, xmm1
000071709abcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000071709abcfc6a  ptest xmm15, xmm15
000071709abcfc70  jnz 0x000071709ABD23BD
000071709abcfc76  lea rax, [r14+0xC0]
000071709abcfc7d  movups xmm1, [r13+rax*1]
000071709abcfc83  vmovaps xmm11, [rsp+0x110]
000071709abcfc8c  vmovaps [rsp+0xF0], xmm1
000071709abcfc95  vmovaps xmm1, [rsp+0x30]
000071709abcfc9b  vmovaps [rsp+0x30], xmm14
000071709abcfca1  movaps xmm15, xmm11
000071709abcfca5  addpd xmm15, xmm1
000071709abcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000071709abcfcb0  ptest xmm14, xmm14
000071709abcfcb6  jnz 0x000071709ABD250A
000071709abcfcbc  vmovaps [rsp+0x100], xmm9
000071709abcfcc5  vmovaps xmm1, [rsp+0x100]
000071709abcfcce  por xmm9, xmm1
000071709abcfcd3  movaps [r15+0x270], xmm9
000071709abcfcdb  vmovaps [rsp+0x100], xmm6
000071709abcfce4  vmovaps xmm1, [rsp+0x100]
000071709abcfced  por xmm6, xmm1
000071709abcfcf1  movaps [r15+0x1A0], xmm6
000071709abcfcf9  vmovaps xmm14, [rsp+0xB0]
000071709abcfd02  vpermilpd xmm14, xmm14, 0x00
000071709abcfd08  vmovaps xmm6, [rsp+0xF0]
000071709abcfd11  vmovaps [rsp+0xF0], xmm1
000071709abcfd1a  movaps xmm11, xmm6
000071709abcfd1e  mulpd xmm11, xmm14
000071709abcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000071709abcfd29  ptest xmm1, xmm1
000071709abcfd2e  jnz 0x000071709ABD264D
000071709abcfd34  lea rax, [r14+0x20]
000071709abcfd38  movups xmm1, [r13+rax*1]
000071709abcfd3e  movaps [r15+0x110], xmm1
000071709abcfd46  vmovaps xmm6, [rsp+0xE0]
000071709abcfd4f  vmovaps [rsp+0xE0], xmm1
000071709abcfd58  movaps xmm14, xmm6
000071709abcfd5c  addpd xmm14, xmm2
000071709abcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000071709abcfd67  ptest xmm1, xmm1
000071709abcfd6c  jnz 0x000071709ABD279A
000071709abcfd72  vmovaps xmm1, [rsp+0xB0]
000071709abcfd7b  vpermilpd xmm1, xmm1, 0x00
000071709abcfd81  movaps xmm6, xmm5
000071709abcfd84  mulpd xmm6, xmm1
000071709abcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000071709abcfd8d  ptest xmm2, xmm2
000071709abcfd92  jnz 0x000071709ABD28DC
000071709abcfd98  vmovaps xmm5, [rsp+0x20]
000071709abcfd9e  movaps xmm1, xmm5
000071709abcfda1  addpd xmm1, xmm13
000071709abcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000071709abcfdab  ptest xmm2, xmm2
000071709abcfdb0  jnz 0x000071709ABD2A1C
000071709abcfdb6  vmovaps xmm13, [rsp+0x80]
000071709abcfdbf  vpermilpd xmm13, xmm13, 0x00
000071709abcfdc5  vmovaps xmm2, [rsp+0xE0]
000071709abcfdce  vmovaps [rsp+0x20], xmm1
000071709abcfdd4  movaps xmm5, xmm2
000071709abcfdd7  mulpd xmm5, xmm13
000071709abcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000071709abcfde1  ptest xmm1, xmm1
000071709abcfde6  jnz 0x000071709ABD2B5D
000071709abcfdec  vmovaps xmm1, [rsp+0x80]
000071709abcfdf5  vpermilpd xmm1, xmm1, 0x00
000071709abcfdfb  movaps xmm13, xmm10
000071709abcfdff  mulpd xmm13, xmm1
000071709abcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000071709abcfe0a  ptest xmm2, xmm2
000071709abcfe0f  jnz 0x000071709ABD2C9E
000071709abcfe15  vmovaps xmm10, [rsp+0x30]
000071709abcfe1b  movaps xmm1, xmm15
000071709abcfe1f  addpd xmm1, xmm10
000071709abcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000071709abcfe29  ptest xmm2, xmm2
000071709abcfe2e  jnz 0x000071709ABD2DE1
000071709abcfe34  vmovaps xmm10, [rsp+0xC0]
000071709abcfe3d  movaps xmm15, xmm10
000071709abcfe41  addpd xmm15, xmm11
000071709abcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000071709abcfe4c  ptest xmm2, xmm2
000071709abcfe51  jnz 0x000071709ABD2F23
000071709abcfe57  vmovaps xmm11, [rsp+0x80]
000071709abcfe60  vpermilpd xmm11, xmm11, 0x00
000071709abcfe66  movaps xmm10, xmm12
000071709abcfe6a  mulpd xmm10, xmm11
000071709abcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000071709abcfe75  ptest xmm2, xmm2
000071709abcfe7a  jnz 0x000071709ABD3067
000071709abcfe80  vmovaps xmm12, [rsp+0x80]
000071709abcfe89  vpermilpd xmm12, xmm12, 0x00
000071709abcfe8f  vmovaps xmm2, [rsp+0xA0]
000071709abcfe98  vmovaps [rsp+0x30], xmm1
000071709abcfe9e  movaps xmm11, xmm2
000071709abcfea2  mulpd xmm11, xmm12
000071709abcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000071709abcfead  ptest xmm1, xmm1
000071709abcfeb2  jnz 0x000071709ABD31AB
000071709abcfeb8  movaps xmm1, xmm14
000071709abcfebc  addpd xmm1, xmm6
000071709abcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000071709abcfec5  ptest xmm12, xmm12
000071709abcfecb  jnz 0x000071709ABD32EE
000071709abcfed1  vmovaps xmm12, [rsp+0x20]
000071709abcfed7  movaps xmm14, xmm12
000071709abcfedb  addpd xmm14, xmm5
000071709abcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000071709abcfee6  ptest xmm6, xmm6
000071709abcfeeb  jnz 0x000071709ABD342F
000071709abcfef1  vmovaps xmm12, [rsp+0x90]
000071709abcfefa  vpermilpd xmm12, xmm12, 0x00
000071709abcff00  movaps xmm6, xmm9
000071709abcff04  mulpd xmm6, xmm12
000071709abcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000071709abcff0e  ptest xmm5, xmm5
000071709abcff13  jnz 0x000071709ABD3572
000071709abcff19  movaps xmm12, xmm15
000071709abcff1d  addpd xmm12, xmm13
000071709abcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000071709abcff28  ptest xmm9, xmm9
000071709abcff2e  jnz 0x000071709ABD36B4
000071709abcff34  vmovaps xmm13, [rsp+0x30]
000071709abcff3a  movaps xmm15, xmm13
000071709abcff3e  addpd xmm15, xmm10
000071709abcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000071709abcff49  ptest xmm9, xmm9
000071709abcff4f  jnz 0x000071709ABD37F8
000071709abcff55  vmovaps xmm13, [rsp+0xD0]
000071709abcff5e  vmovaps xmm10, [rsp+0xD0]
000071709abcff67  por xmm13, xmm10
000071709abcff6c  movaps [r15+0x250], xmm13
000071709abcff74  vmovaps [rsp+0x20], xmm7
000071709abcff7a  vmovaps xmm13, [rsp+0x20]
000071709abcff80  por xmm7, xmm13
000071709abcff85  movaps [r15+0x2A0], xmm7
000071709abcff8d  vmovaps [rsp+0x20], xmm3
000071709abcff93  vmovaps xmm13, [rsp+0x20]
000071709abcff99  por xmm3, xmm13
000071709abcff9e  movaps [r15+0x1D0], xmm3
000071709abcffa6  lea rax, [r14+0x40]
000071709abcffaa  movups xmm13, [r13+rax*1]
000071709abcffb0  movaps [r15+0x2C0], xmm13
000071709abcffb8  vmovaps xmm10, [rsp+0x90]
000071709abcffc1  vpermilpd xmm10, xmm10, 0x00
000071709abcffc7  movaps xmm9, xmm8
000071709abcffcb  mulpd xmm9, xmm10
000071709abcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000071709abcffd6  ptest xmm5, xmm5
000071709abcffdb  jnz 0x000071709ABD3946
000071709abcffe1  movaps xmm10, xmm1
000071709abcffe5  addpd xmm10, xmm11
000071709abcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000071709abcfff0  ptest xmm8, xmm8
000071709abcfff6  jnz 0x000071709ABD3A8A
000071709abcfffc  movaps xmm1, xmm14
000071709abd0000  addpd xmm1, xmm6
000071709abd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000071709abd0009  ptest xmm11, xmm11
000071709abd000f  jnz 0x000071709ABD3BCD
000071709abd0015  vmovaps xmm14, [rsp+0x90]
000071709abd001e  vpermilpd xmm14, xmm14, 0x00
000071709abd0024  movaps xmm11, xmm13
000071709abd0028  mulpd xmm11, xmm14
000071709abd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000071709abd0033  ptest xmm8, xmm8
000071709abd0039  jnz 0x000071709ABD3D0E
000071709abd003f  vmovaps xmm14, [rsp+0x90]
000071709abd0048  vpermilpd xmm14, xmm14, 0x00
000071709abd004e  vmovaps xmm8, [rsp+0x10]
000071709abd0054  movaps xmm13, xmm8
000071709abd0058  mulpd xmm13, xmm14
000071709abd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000071709abd0063  ptest xmm6, xmm6
000071709abd0068  jnz 0x000071709ABD3E52
000071709abd006e  vmovaps xmm14, [rsp+0x60]
000071709abd0074  vpermilpd xmm14, xmm14, 0x00
000071709abd007a  movaps xmm8, xmm7
000071709abd007e  mulpd xmm8, xmm14
000071709abd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000071709abd0089  ptest xmm6, xmm6
000071709abd008e  jnz 0x000071709ABD3F96
000071709abd0094  movaps xmm14, xmm12
000071709abd0098  addpd xmm14, xmm9
000071709abd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000071709abd00a3  ptest xmm7, xmm7
000071709abd00a8  jnz 0x000071709ABD40D9
000071709abd00ae  vmovaps xmm12, [rsp+0x60]
000071709abd00b4  vpermilpd xmm12, xmm12, 0x00
000071709abd00ba  vmovaps xmm7, [rsp+0xF0]
000071709abd00c3  movaps xmm9, xmm7
000071709abd00c7  mulpd xmm9, xmm12
000071709abd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000071709abd00d2  ptest xmm6, xmm6
000071709abd00d7  jnz 0x000071709ABD421D
000071709abd00dd  movaps xmm12, xmm15
000071709abd00e1  addpd xmm12, xmm11
000071709abd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000071709abd00ec  ptest xmm7, xmm7
000071709abd00f1  jnz 0x000071709ABD4360
000071709abd00f7  vmovaps xmm15, [rsp+0x60]
000071709abd00fd  vpermilpd xmm15, xmm15, 0x00
000071709abd0103  vmovaps xmm7, [rsp+0x40]
000071709abd0109  movaps xmm11, xmm7
000071709abd010d  mulpd xmm11, xmm15
000071709abd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000071709abd0118  ptest xmm6, xmm6
000071709abd011d  jnz 0x000071709ABD44A4
000071709abd0123  movaps xmm15, xmm10
000071709abd0127  addpd xmm15, xmm13
000071709abd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000071709abd0132  ptest xmm7, xmm7
000071709abd0137  jnz 0x000071709ABD45E7
000071709abd013d  vmovaps xmm13, [rsp+0x60]
000071709abd0143  vpermilpd xmm13, xmm13, 0x00
000071709abd0149  vmovaps xmm7, [rsp+0x50]
000071709abd014f  movaps xmm10, xmm7
000071709abd0153  mulpd xmm10, xmm13
000071709abd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000071709abd015e  ptest xmm6, xmm6
000071709abd0163  jnz 0x000071709ABD472B
000071709abd0169  movaps xmm13, xmm1
000071709abd016d  addpd xmm13, xmm8
000071709abd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000071709abd0178  ptest xmm7, xmm7
000071709abd017d  jnz 0x000071709ABD486E
000071709abd0183  lea rax, [r14+0x70]
000071709abd0187  movups xmm1, [r13+rax*1]
000071709abd018d  movaps [r15+0x240], xmm1
000071709abd0195  movaps xmm8, xmm14
000071709abd0199  addpd xmm8, xmm9
000071709abd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000071709abd01a4  ptest xmm7, xmm7
000071709abd01a9  jnz 0x000071709ABD49BB
000071709abd01af  movaps [r15+0x170], xmm8
000071709abd01b7  vmovaps xmm14, [rsp+0x70]
000071709abd01bd  vpermilpd xmm14, xmm14, 0x00
000071709abd01c3  movaps xmm9, xmm1
000071709abd01c7  mulpd xmm9, xmm14
000071709abd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000071709abd01d2  ptest xmm7, xmm7
000071709abd01d7  jnz 0x000071709ABD4AFF
000071709abd01dd  vmovaps xmm1, [rsp+0x70]
000071709abd01e3  vpermilpd xmm1, xmm1, 0x00
000071709abd01e9  movaps xmm14, xmm4
000071709abd01ed  mulpd xmm14, xmm1
000071709abd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000071709abd01f8  ptest xmm7, xmm7
000071709abd01fd  jnz 0x000071709ABD4C42
000071709abd0203  movaps [r15+0x180], xmm14
000071709abd020b  movaps xmm1, xmm12
000071709abd020f  addpd xmm1, xmm11
000071709abd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000071709abd0219  ptest xmm7, xmm7
000071709abd021e  jnz 0x000071709ABD4D84
000071709abd0224  movaps [r15+0x210], xmm1
000071709abd022c  movups xmm12, [r13+r14*1]
000071709abd0232  lea rax, [r14+0x10]
000071709abd0236  movups xmm11, [r13+rax*1]
000071709abd023c  movaps [r15+0x230], xmm11
000071709abd0244  movaps xmm7, xmm15
000071709abd0248  addpd xmm7, xmm10
000071709abd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000071709abd0252  ptest xmm6, xmm6
000071709abd0257  jnz 0x000071709ABD4EDA
000071709abd025d  movaps [r15+0x130], xmm7
000071709abd0265  vmovaps xmm15, [rsp+0x70]
000071709abd026b  vpermilpd xmm15, xmm15, 0x00
000071709abd0271  movaps xmm10, xmm11
000071709abd0275  mulpd xmm10, xmm15
000071709abd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000071709abd0280  ptest xmm6, xmm6
000071709abd0285  jnz 0x000071709ABD501C
000071709abd028b  movaps [r15+0x220], xmm10
000071709abd0293  vmovaps xmm15, [rsp+0x70]
000071709abd0299  vpermilpd xmm15, xmm15, 0x00
000071709abd029f  movaps xmm11, xmm12
000071709abd02a3  mulpd xmm11, xmm15
000071709abd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000071709abd02ae  ptest xmm6, xmm6
000071709abd02b3  jnz 0x000071709ABD5160
000071709abd02b9  movaps xmm15, xmm13
000071709abd02bd  addpd xmm15, xmm9
000071709abd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000071709abd02c8  ptest xmm12, xmm12
000071709abd02ce  jnz 0x000071709ABD52A4
000071709abd02d4  movaps [r15+0x140], xmm15
000071709abd02dc  movaps xmm13, xmm8
000071709abd02e0  addpd xmm13, xmm14
000071709abd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000071709abd02eb  ptest xmm12, xmm12
000071709abd02f1  jnz 0x000071709ABD53E8
000071709abd02f7  movaps [r15+0x150], xmm13
000071709abd02ff  movaps xmm14, xmm1
000071709abd0303  addpd xmm14, xmm10
000071709abd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000071709abd030e  ptest xmm12, xmm12
000071709abd0314  jnz 0x000071709ABD552C
000071709abd031a  movaps [r15+0x160], xmm14
000071709abd0322  movaps xmm1, xmm7
000071709abd0325  addpd xmm1, xmm11
000071709abd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000071709abd032f  ptest xmm12, xmm12
000071709abd0335  jnz 0x000071709ABD566F
000071709abd033b  movaps [r15+0x120], xmm1
000071709abd0343  mov eax, 0x430920
000071709abd0348  movups [r13+rax*1], xmm15
000071709abd034e  mov eax, 0x430930
000071709abd0353  movups [r13+rax*1], xmm13
000071709abd0359  mov eax, 0x430940
000071709abd035e  movups [r13+rax*1], xmm14
000071709abd0364  mov eax, 0x430950
000071709abd0369  movups [r13+rax*1], xmm1
000071709abd036f  mov eax, [r15+0x108]
000071709abd0376  sahf
000071709abd0377  jnz 0x000071709ABD03A9
000071709abd0379  cmp dword ptr [r15+0x318], 0x00
000071709abd0381  jz 0x000071709ABDB900
000071709abd0387  nop [rax+rax*1], ax
000071709abd0390  nop [rax+rax*1], eax
000071709abd0398  mov eax, 0x410444
000071709abd039d  mov [r15+0x100], rax
000071709abd03a4  jmp 0x000071709A9FE110
000071709abd03a9  cmp dword ptr [r15+0x318], 0x00
000071709abd03b1  jz 0x000071709ABD57E0
000071709abd03b7  nop [rax+rax*1], ax
000071709abd03c0  nop [rax+rax*1], eax
000071709abd03c8  mov eax, 0x410278
000071709abd03cd  mov [r15+0x100], rax
000071709abd03d4  jmp 0x000071709A9FE110
000071709abd03d9  int3
000071709abd03da  call 0x000071709AAB52F0
000071709abd03df  jmp 0x000071709ABCF016
000071709abd03e4  call 0x000071709AAC4620
000071709abd03e9  jmp 0x000071709ABCF023
000071709abd03ee  call 0x000071709AAC33A0
000071709abd03f3  jmp 0x000071709ABCF035
000071709abd03f8  call 0x000071709AAC2120
000071709abd03fd  jmp 0x000071709ABCF03F
000071709abd0402  call 0x000071709AAC0860
000071709abd0407  jmp 0x000071709ABCF067
000071709abd040c  call 0x000071709AABF5F0
000071709abd0411  jmp 0x000071709ABCF073
000071709abd0416  call 0x000071709AAC0860
000071709abd041b  jmp 0x000071709ABCF0A5
000071709abd0420  call 0x000071709AABF5F0
000071709abd0425  jmp 0x000071709ABCF0B1
000071709abd042a  call 0x000071709AAC4740
000071709abd042f  jmp 0x000071709ABCF0BE
000071709abd0434  call 0x000071709AAB5400
000071709abd0439  jmp 0x000071709ABCF0CB
000071709abd043e  call 0x000071709AAB52F0
000071709abd0443  jmp 0x000071709ABCF0D8
000071709abd0448  call 0x000071709AAC4620
000071709abd044d  jmp 0x000071709ABCF0E5
000071709abd0452  call 0x000071709AAC0860
000071709abd0457  jmp 0x000071709ABCF10D
000071709abd045c  call 0x000071709AABF5F0
000071709abd0461  jmp 0x000071709ABCF119
000071709abd0466  call 0x000071709AA09D70
000071709abd046b  jmp 0x000071709ABCF11F
000071709abd0470  call 0x000071709AABE9C0
000071709abd0475  jmp 0x000071709ABCF129
000071709abd047a  call 0x000071709AAC0860
000071709abd047f  jmp 0x000071709ABCF151
000071709abd0484  call 0x000071709AABF5F0
000071709abd0489  jmp 0x000071709ABCF15D
000071709abd048e  call 0x000071709AABD750
000071709abd0493  jmp 0x000071709ABCF16A
000071709abd0498  call 0x000071709AABC4E0
000071709abd049d  jmp 0x000071709ABCF177
000071709abd04a2  call 0x000071709AAC4740
000071709abd04a7  jmp 0x000071709ABCF184
000071709abd04ac  call 0x000071709AAB5400
000071709abd04b1  jmp 0x000071709ABCF191
000071709abd04b6  call 0x000071709AAB52F0
000071709abd04bb  jmp 0x000071709ABCF19E
000071709abd04c0  call 0x000071709AAC4620
000071709abd04c5  jmp 0x000071709ABCF1AB
000071709abd04ca  call 0x000071709AAC0860
000071709abd04cf  jmp 0x000071709ABCF1BE
000071709abd04d4  call 0x000071709AABB270
000071709abd04d9  jmp 0x000071709ABCF1CB
000071709abd04de  call 0x000071709AABA000
000071709abd04e3  jmp 0x000071709ABCF1D8
000071709abd04e8  call 0x000071709AAB8D90
000071709abd04ed  jmp 0x000071709ABCF1E5
000071709abd04f2  call 0x000071709AAB8A20
000071709abd04f7  jmp 0x000071709ABCF1F2
000071709abd04fc  call 0x000071709AAB5400
000071709abd0501  jmp 0x000071709ABCF1FC
000071709abd0506  call 0x000071709AAC2240
000071709abd050b  jmp 0x000071709ABCF206
000071709abd0510  call 0x000071709AAB52F0
000071709abd0515  jmp 0x000071709ABCF210
000071709abd051a  call 0x000071709AAC2120
000071709abd051f  jmp 0x000071709ABCF21A
000071709abd0524  call 0x000071709AAB77B0
000071709abd0529  jmp 0x000071709ABCF224
000071709abd052e  call 0x000071709AAB6550
000071709abd0533  jmp 0x000071709ABCF22E
000071709abd0538  call 0x000071709AABFD50
000071709abd053d  jmp 0x000071709ABCF240
000071709abd0542  call 0x000071709AAB8EA0
000071709abd0547  jmp 0x000071709ABCF24A
000071709abd054c  call 0x000071709AABFC30
000071709abd0551  jmp 0x000071709ABCF257
000071709abd0556  call 0x000071709AAB8D90
000071709abd055b  jmp 0x000071709ABCF264
000071709abd0560  call 0x000071709AAC2240
000071709abd0565  jmp 0x000071709ABCF271
000071709abd056a  call 0x000071709AAB5400
000071709abd056f  jmp 0x000071709ABCF27E
000071709abd0574  call 0x000071709AAB52F0
000071709abd0579  jmp 0x000071709ABCF28B
000071709abd057e  call 0x000071709AAC2120
000071709abd0583  jmp 0x000071709ABCF298
000071709abd0588  call 0x000071709AAB52F0
000071709abd058d  jmp 0x000071709ABCF2AB
000071709abd0592  call 0x000071709AAB52F0
000071709abd0597  jmp 0x000071709ABCF2BE
000071709abd059c  call 0x000071709AAB52F0
000071709abd05a1  jmp 0x000071709ABCF2D1
000071709abd05a6  call 0x000071709AAB52F0
000071709abd05ab  jmp 0x000071709ABCF2E4
000071709abd05b0  call 0x000071709AAC2240
000071709abd05b5  jmp 0x000071709ABCF2F9
000071709abd05ba  call 0x000071709AAC2240
000071709abd05bf  jmp 0x000071709ABCF30C
000071709abd05c4  call 0x000071709AAC2120
000071709abd05c9  jmp 0x000071709ABCF319
000071709abd05ce  call 0x000071709AAB52F0
000071709abd05d3  jmp 0x000071709ABCF32C
000071709abd05d8  call 0x000071709AAB52F0
000071709abd05dd  jmp 0x000071709ABCF34F
000071709abd05e2  call 0x000071709AAB52F0
000071709abd05e7  jmp 0x000071709ABCF362
000071709abd05ec  call 0x000071709A9FF540
000071709abd05f1  jmp 0x000071709ABCF380
000071709abd05f6  call 0x000071709AA08C20
000071709abd05fb  jmp 0x000071709ABCF38A
000071709abd0600  call 0x000071709AAD6600
000071709abd0605  jmp 0x000071709ABCF396
000071709abd060a  call 0x000071709A9FF540
000071709abd060f  jmp 0x000071709ABCF3A6
000071709abd0614  call 0x000071709AAC0370
000071709abd0619  jmp 0x000071709ABCF3D4
000071709abd061e  call 0x000071709AABF100
000071709abd0623  jmp 0x000071709ABCF3DD
000071709abd0628  call 0x000071709AAC0370
000071709abd062d  jmp 0x000071709ABCF43B
000071709abd0632  call 0x000071709AABF100
000071709abd0637  jmp 0x000071709ABCF444
000071709abd063c  call 0x000071709AAC0370
000071709abd0641  jmp 0x000071709ABCF48B
000071709abd0646  call 0x000071709AABF100
000071709abd064b  jmp 0x000071709ABCF494
000071709abd0650  call 0x000071709AA0B720
000071709abd0655  jmp 0x000071709ABCF4D7
000071709abd065a  call 0x000071709AAB47C0
000071709abd065f  jmp 0x000071709ABCF4EA
000071709abd0664  call 0x000071709AA08B00
000071709abd0669  jmp 0x000071709ABCF501
000071709abd066e  call 0x000071709A9FF430
000071709abd0673  jmp 0x000071709ABCF514
000071709abd0678  call 0x000071709A9FF430
000071709abd067d  jmp 0x000071709ABCF527
000071709abd0682  sub rsp, 0x08
000071709abd0686  push rax
000071709abd0687  push rcx
000071709abd0688  push rdx
000071709abd0689  push rdi
000071709abd068a  push rsi
000071709abd068b  push r8
000071709abd068d  push r9
000071709abd068f  push r10
000071709abd0691  push r11
000071709abd0693  sub rsp, 0xF0
000071709abd069a  vmovaps [rsp], xmm0
000071709abd069f  vmovaps [rsp+0x10], xmm2
000071709abd06a5  vmovaps [rsp+0x20], xmm3
000071709abd06ab  vmovaps [rsp+0x30], xmm4
000071709abd06b1  vmovaps [rsp+0x40], xmm5
000071709abd06b7  vmovaps [rsp+0x50], xmm6
000071709abd06bd  vmovaps [rsp+0x60], xmm7
000071709abd06c3  vmovaps [rsp+0x70], xmm8
000071709abd06c9  vmovaps [rsp+0x80], xmm9
000071709abd06d2  vmovaps [rsp+0x90], xmm10
000071709abd06db  vmovaps [rsp+0xA0], xmm11
000071709abd06e4  vmovaps [rsp+0xB0], xmm12
000071709abd06ed  vmovaps [rsp+0xC0], xmm13
000071709abd06f6  vmovaps [rsp+0xD0], xmm14
000071709abd06ff  vmovaps [rsp+0xE0], xmm15
000071709abd0708  sub rsp, 0x30
000071709abd070c  movaps [rsp], xmm1
000071709abd0710  movaps [rsp+0x10], xmm15
000071709abd0716  movaps [rsp+0x20], xmm14
000071709abd071c  lea rdi, [rsp]
000071709abd0720  mov esi, 0x00
000071709abd0725  mov rax, 0x60B9B2ABC530
000071709abd072f  call rax
000071709abd0731  movaps xmm1, [rsp]
000071709abd0735  add rsp, 0x30
000071709abd0739  vmovaps xmm0, [rsp]
000071709abd073e  vmovaps xmm2, [rsp+0x10]
000071709abd0744  vmovaps xmm3, [rsp+0x20]
000071709abd074a  vmovaps xmm4, [rsp+0x30]
000071709abd0750  vmovaps xmm5, [rsp+0x40]
000071709abd0756  vmovaps xmm6, [rsp+0x50]
000071709abd075c  vmovaps xmm7, [rsp+0x60]
000071709abd0762  vmovaps xmm8, [rsp+0x70]
000071709abd0768  vmovaps xmm9, [rsp+0x80]
000071709abd0771  vmovaps xmm10, [rsp+0x90]
000071709abd077a  vmovaps xmm11, [rsp+0xA0]
000071709abd0783  vmovaps xmm12, [rsp+0xB0]
000071709abd078c  vmovaps xmm13, [rsp+0xC0]
000071709abd0795  vmovaps xmm14, [rsp+0xD0]
000071709abd079e  vmovaps xmm15, [rsp+0xE0]
000071709abd07a7  add rsp, 0xF0
000071709abd07ae  pop r11
000071709abd07b0  pop r10
000071709abd07b2  pop r9
000071709abd07b4  pop r8
000071709abd07b6  pop rsi
000071709abd07b7  pop rdi
000071709abd07b8  pop rdx
000071709abd07b9  pop rcx
000071709abd07ba  pop rax
000071709abd07bb  add rsp, 0x08
000071709abd07bf  jmp 0x000071709ABCF581
000071709abd07c4  sub rsp, 0x08
000071709abd07c8  push rax
000071709abd07c9  push rcx
000071709abd07ca  push rdx
000071709abd07cb  push rdi
000071709abd07cc  push rsi
000071709abd07cd  push r8
000071709abd07cf  push r9
000071709abd07d1  push r10
000071709abd07d3  push r11
000071709abd07d5  sub rsp, 0xF0
000071709abd07dc  vmovaps [rsp], xmm0
000071709abd07e1  vmovaps [rsp+0x10], xmm1
000071709abd07e7  vmovaps [rsp+0x20], xmm2
000071709abd07ed  vmovaps [rsp+0x30], xmm3
000071709abd07f3  vmovaps [rsp+0x40], xmm4
000071709abd07f9  vmovaps [rsp+0x50], xmm5
000071709abd07ff  vmovaps [rsp+0x60], xmm6
000071709abd0805  vmovaps [rsp+0x70], xmm7
000071709abd080b  vmovaps [rsp+0x80], xmm8
000071709abd0814  vmovaps [rsp+0x90], xmm9
000071709abd081d  vmovaps [rsp+0xA0], xmm10
000071709abd0826  vmovaps [rsp+0xB0], xmm11
000071709abd082f  vmovaps [rsp+0xC0], xmm12
000071709abd0838  vmovaps [rsp+0xD0], xmm14
000071709abd0841  vmovaps [rsp+0xE0], xmm15
000071709abd084a  sub rsp, 0x30
000071709abd084e  movaps [rsp], xmm13
000071709abd0853  movaps [rsp+0x10], xmm1
000071709abd0858  movaps [rsp+0x20], xmm14
000071709abd085e  lea rdi, [rsp]
000071709abd0862  mov esi, 0x00
000071709abd0867  mov rax, 0x60B9B2ABC530
000071709abd0871  call rax
000071709abd0873  movaps xmm13, [rsp]
000071709abd0878  add rsp, 0x30
000071709abd087c  vmovaps xmm0, [rsp]
000071709abd0881  vmovaps xmm1, [rsp+0x10]
000071709abd0887  vmovaps xmm2, [rsp+0x20]
000071709abd088d  vmovaps xmm3, [rsp+0x30]
000071709abd0893  vmovaps xmm4, [rsp+0x40]
000071709abd0899  vmovaps xmm5, [rsp+0x50]
000071709abd089f  vmovaps xmm6, [rsp+0x60]
000071709abd08a5  vmovaps xmm7, [rsp+0x70]
000071709abd08ab  vmovaps xmm8, [rsp+0x80]
000071709abd08b4  vmovaps xmm9, [rsp+0x90]
000071709abd08bd  vmovaps xmm10, [rsp+0xA0]
000071709abd08c6  vmovaps xmm11, [rsp+0xB0]
000071709abd08cf  vmovaps xmm12, [rsp+0xC0]
000071709abd08d8  vmovaps xmm14, [rsp+0xD0]
000071709abd08e1  vmovaps xmm15, [rsp+0xE0]
000071709abd08ea  add rsp, 0xF0
000071709abd08f1  pop r11
000071709abd08f3  pop r10
000071709abd08f5  pop r9
000071709abd08f7  pop r8
000071709abd08f9  pop rsi
000071709abd08fa  pop rdi
000071709abd08fb  pop rdx
000071709abd08fc  pop rcx
000071709abd08fd  pop rax
000071709abd08fe  add rsp, 0x08
000071709abd0902  jmp 0x000071709ABCF5CF
000071709abd0907  sub rsp, 0x08
000071709abd090b  push rax
000071709abd090c  push rcx
000071709abd090d  push rdx
000071709abd090e  push rdi
000071709abd090f  push rsi
000071709abd0910  push r8
000071709abd0912  push r9
000071709abd0914  push r10
000071709abd0916  push r11
000071709abd0918  sub rsp, 0xF0
000071709abd091f  vmovaps [rsp], xmm0
000071709abd0924  vmovaps [rsp+0x10], xmm1
000071709abd092a  vmovaps [rsp+0x20], xmm2
000071709abd0930  vmovaps [rsp+0x30], xmm3
000071709abd0936  vmovaps [rsp+0x40], xmm4
000071709abd093c  vmovaps [rsp+0x50], xmm5
000071709abd0942  vmovaps [rsp+0x60], xmm6
000071709abd0948  vmovaps [rsp+0x70], xmm7
000071709abd094e  vmovaps [rsp+0x80], xmm8
000071709abd0957  vmovaps [rsp+0x90], xmm9
000071709abd0960  vmovaps [rsp+0xA0], xmm10
000071709abd0969  vmovaps [rsp+0xB0], xmm11
000071709abd0972  vmovaps [rsp+0xC0], xmm12
000071709abd097b  vmovaps [rsp+0xD0], xmm13
000071709abd0984  vmovaps [rsp+0xE0], xmm14
000071709abd098d  sub rsp, 0x30
000071709abd0991  movaps [rsp], xmm15
000071709abd0996  movaps [rsp+0x10], xmm14
000071709abd099c  movaps [rsp+0x20], xmm1
000071709abd09a1  lea rdi, [rsp]
000071709abd09a5  mov esi, 0x00
000071709abd09aa  mov rax, 0x60B9B2ABC530
000071709abd09b4  call rax
000071709abd09b6  movaps xmm15, [rsp]
000071709abd09bb  add rsp, 0x30
000071709abd09bf  vmovaps xmm0, [rsp]
000071709abd09c4  vmovaps xmm1, [rsp+0x10]
000071709abd09ca  vmovaps xmm2, [rsp+0x20]
000071709abd09d0  vmovaps xmm3, [rsp+0x30]
000071709abd09d6  vmovaps xmm4, [rsp+0x40]
000071709abd09dc  vmovaps xmm5, [rsp+0x50]
000071709abd09e2  vmovaps xmm6, [rsp+0x60]
000071709abd09e8  vmovaps xmm7, [rsp+0x70]
000071709abd09ee  vmovaps xmm8, [rsp+0x80]
000071709abd09f7  vmovaps xmm9, [rsp+0x90]
000071709abd0a00  vmovaps xmm10, [rsp+0xA0]
000071709abd0a09  vmovaps xmm11, [rsp+0xB0]
000071709abd0a12  vmovaps xmm12, [rsp+0xC0]
000071709abd0a1b  vmovaps xmm13, [rsp+0xD0]
000071709abd0a24  vmovaps xmm14, [rsp+0xE0]
000071709abd0a2d  add rsp, 0xF0
000071709abd0a34  pop r11
000071709abd0a36  pop r10
000071709abd0a38  pop r9
000071709abd0a3a  pop r8
000071709abd0a3c  pop rsi
000071709abd0a3d  pop rdi
000071709abd0a3e  pop rdx
000071709abd0a3f  pop rcx
000071709abd0a40  pop rax
000071709abd0a41  add rsp, 0x08
000071709abd0a45  jmp 0x000071709ABCF617
000071709abd0a4a  sub rsp, 0x08
000071709abd0a4e  push rax
000071709abd0a4f  push rcx
000071709abd0a50  push rdx
000071709abd0a51  push rdi
000071709abd0a52  push rsi
000071709abd0a53  push r8
000071709abd0a55  push r9
000071709abd0a57  push r10
000071709abd0a59  push r11
000071709abd0a5b  sub rsp, 0xF0
000071709abd0a62  vmovaps [rsp], xmm0
000071709abd0a67  vmovaps [rsp+0x10], xmm2
000071709abd0a6d  vmovaps [rsp+0x20], xmm3
000071709abd0a73  vmovaps [rsp+0x30], xmm4
000071709abd0a79  vmovaps [rsp+0x40], xmm5
000071709abd0a7f  vmovaps [rsp+0x50], xmm6
000071709abd0a85  vmovaps [rsp+0x60], xmm7
000071709abd0a8b  vmovaps [rsp+0x70], xmm8
000071709abd0a91  vmovaps [rsp+0x80], xmm9
000071709abd0a9a  vmovaps [rsp+0x90], xmm10
000071709abd0aa3  vmovaps [rsp+0xA0], xmm11
000071709abd0aac  vmovaps [rsp+0xB0], xmm12
000071709abd0ab5  vmovaps [rsp+0xC0], xmm13
000071709abd0abe  vmovaps [rsp+0xD0], xmm14
000071709abd0ac7  vmovaps [rsp+0xE0], xmm15
000071709abd0ad0  sub rsp, 0x30
000071709abd0ad4  movaps [rsp], xmm1
000071709abd0ad8  movaps [rsp+0x10], xmm14
000071709abd0ade  movaps [rsp+0x20], xmm10
000071709abd0ae4  lea rdi, [rsp]
000071709abd0ae8  mov esi, 0x00
000071709abd0aed  mov rax, 0x60B9B2ABC530
000071709abd0af7  call rax
000071709abd0af9  movaps xmm1, [rsp]
000071709abd0afd  add rsp, 0x30
000071709abd0b01  vmovaps xmm0, [rsp]
000071709abd0b06  vmovaps xmm2, [rsp+0x10]
000071709abd0b0c  vmovaps xmm3, [rsp+0x20]
000071709abd0b12  vmovaps xmm4, [rsp+0x30]
000071709abd0b18  vmovaps xmm5, [rsp+0x40]
000071709abd0b1e  vmovaps xmm6, [rsp+0x50]
000071709abd0b24  vmovaps xmm7, [rsp+0x60]
000071709abd0b2a  vmovaps xmm8, [rsp+0x70]
000071709abd0b30  vmovaps xmm9, [rsp+0x80]
000071709abd0b39  vmovaps xmm10, [rsp+0x90]
000071709abd0b42  vmovaps xmm11, [rsp+0xA0]
000071709abd0b4b  vmovaps xmm12, [rsp+0xB0]
000071709abd0b54  vmovaps xmm13, [rsp+0xC0]
000071709abd0b5d  vmovaps xmm14, [rsp+0xD0]
000071709abd0b66  vmovaps xmm15, [rsp+0xE0]
000071709abd0b6f  add rsp, 0xF0
000071709abd0b76  pop r11
000071709abd0b78  pop r10
000071709abd0b7a  pop r9
000071709abd0b7c  pop r8
000071709abd0b7e  pop rsi
000071709abd0b7f  pop rdi
000071709abd0b80  pop rdx
000071709abd0b81  pop rcx
000071709abd0b82  pop rax
000071709abd0b83  add rsp, 0x08
000071709abd0b87  jmp 0x000071709ABCF631
000071709abd0b8c  sub rsp, 0x08
000071709abd0b90  push rax
000071709abd0b91  push rcx
000071709abd0b92  push rdx
000071709abd0b93  push rdi
000071709abd0b94  push rsi
000071709abd0b95  push r8
000071709abd0b97  push r9
000071709abd0b99  push r10
000071709abd0b9b  push r11
000071709abd0b9d  sub rsp, 0xF0
000071709abd0ba4  vmovaps [rsp], xmm0
000071709abd0ba9  vmovaps [rsp+0x10], xmm1
000071709abd0baf  vmovaps [rsp+0x20], xmm2
000071709abd0bb5  vmovaps [rsp+0x30], xmm3
000071709abd0bbb  vmovaps [rsp+0x40], xmm4
000071709abd0bc1  vmovaps [rsp+0x50], xmm5
000071709abd0bc7  vmovaps [rsp+0x60], xmm6
000071709abd0bcd  vmovaps [rsp+0x70], xmm7
000071709abd0bd3  vmovaps [rsp+0x80], xmm8
000071709abd0bdc  vmovaps [rsp+0x90], xmm9
000071709abd0be5  vmovaps [rsp+0xA0], xmm10
000071709abd0bee  vmovaps [rsp+0xB0], xmm11
000071709abd0bf7  vmovaps [rsp+0xC0], xmm12
000071709abd0c00  vmovaps [rsp+0xD0], xmm14
000071709abd0c09  vmovaps [rsp+0xE0], xmm15
000071709abd0c12  sub rsp, 0x30
000071709abd0c16  movaps [rsp], xmm13
000071709abd0c1b  movaps [rsp+0x10], xmm14
000071709abd0c21  movaps [rsp+0x20], xmm2
000071709abd0c26  lea rdi, [rsp]
000071709abd0c2a  mov esi, 0x00
000071709abd0c2f  mov rax, 0x60B9B2ABC530
000071709abd0c39  call rax
000071709abd0c3b  movaps xmm13, [rsp]
000071709abd0c40  add rsp, 0x30
000071709abd0c44  vmovaps xmm0, [rsp]
000071709abd0c49  vmovaps xmm1, [rsp+0x10]
000071709abd0c4f  vmovaps xmm2, [rsp+0x20]
000071709abd0c55  vmovaps xmm3, [rsp+0x30]
000071709abd0c5b  vmovaps xmm4, [rsp+0x40]
000071709abd0c61  vmovaps xmm5, [rsp+0x50]
000071709abd0c67  vmovaps xmm6, [rsp+0x60]
000071709abd0c6d  vmovaps xmm7, [rsp+0x70]
000071709abd0c73  vmovaps xmm8, [rsp+0x80]
000071709abd0c7c  vmovaps xmm9, [rsp+0x90]
000071709abd0c85  vmovaps xmm10, [rsp+0xA0]
000071709abd0c8e  vmovaps xmm11, [rsp+0xB0]
000071709abd0c97  vmovaps xmm12, [rsp+0xC0]
000071709abd0ca0  vmovaps xmm14, [rsp+0xD0]
000071709abd0ca9  vmovaps xmm15, [rsp+0xE0]
000071709abd0cb2  add rsp, 0xF0
000071709abd0cb9  pop r11
000071709abd0cbb  pop r10
000071709abd0cbd  pop r9
000071709abd0cbf  pop r8
000071709abd0cc1  pop rsi
000071709abd0cc2  pop rdi
000071709abd0cc3  pop rdx
000071709abd0cc4  pop rcx
000071709abd0cc5  pop rax
000071709abd0cc6  add rsp, 0x08
000071709abd0cca  jmp 0x000071709ABCF64C
000071709abd0ccf  sub rsp, 0x08
000071709abd0cd3  push rax
000071709abd0cd4  push rcx
000071709abd0cd5  push rdx
000071709abd0cd6  push rdi
000071709abd0cd7  push rsi
000071709abd0cd8  push r8
000071709abd0cda  push r9
000071709abd0cdc  push r10
000071709abd0cde  push r11
000071709abd0ce0  sub rsp, 0xF0
000071709abd0ce7  vmovaps [rsp], xmm0
000071709abd0cec  vmovaps [rsp+0x10], xmm2
000071709abd0cf2  vmovaps [rsp+0x20], xmm3
000071709abd0cf8  vmovaps [rsp+0x30], xmm4
000071709abd0cfe  vmovaps [rsp+0x40], xmm5
000071709abd0d04  vmovaps [rsp+0x50], xmm6
000071709abd0d0a  vmovaps [rsp+0x60], xmm7
000071709abd0d10  vmovaps [rsp+0x70], xmm8
000071709abd0d16  vmovaps [rsp+0x80], xmm9
000071709abd0d1f  vmovaps [rsp+0x90], xmm10
000071709abd0d28  vmovaps [rsp+0xA0], xmm11
000071709abd0d31  vmovaps [rsp+0xB0], xmm12
000071709abd0d3a  vmovaps [rsp+0xC0], xmm13
000071709abd0d43  vmovaps [rsp+0xD0], xmm14
000071709abd0d4c  vmovaps [rsp+0xE0], xmm15
000071709abd0d55  sub rsp, 0x30
000071709abd0d59  movaps [rsp], xmm1
000071709abd0d5d  movaps [rsp+0x10], xmm10
000071709abd0d63  movaps [rsp+0x20], xmm2
000071709abd0d68  lea rdi, [rsp]
000071709abd0d6c  mov esi, 0x00
000071709abd0d71  mov rax, 0x60B9B2ABC530
000071709abd0d7b  call rax
000071709abd0d7d  movaps xmm1, [rsp]
000071709abd0d81  add rsp, 0x30
000071709abd0d85  vmovaps xmm0, [rsp]
000071709abd0d8a  vmovaps xmm2, [rsp+0x10]
000071709abd0d90  vmovaps xmm3, [rsp+0x20]
000071709abd0d96  vmovaps xmm4, [rsp+0x30]
000071709abd0d9c  vmovaps xmm5, [rsp+0x40]
000071709abd0da2  vmovaps xmm6, [rsp+0x50]
000071709abd0da8  vmovaps xmm7, [rsp+0x60]
000071709abd0dae  vmovaps xmm8, [rsp+0x70]
000071709abd0db4  vmovaps xmm9, [rsp+0x80]
000071709abd0dbd  vmovaps xmm10, [rsp+0x90]
000071709abd0dc6  vmovaps xmm11, [rsp+0xA0]
000071709abd0dcf  vmovaps xmm12, [rsp+0xB0]
000071709abd0dd8  vmovaps xmm13, [rsp+0xC0]
000071709abd0de1  vmovaps xmm14, [rsp+0xD0]
000071709abd0dea  vmovaps xmm15, [rsp+0xE0]
000071709abd0df3  add rsp, 0xF0
000071709abd0dfa  pop r11
000071709abd0dfc  pop r10
000071709abd0dfe  pop r9
000071709abd0e00  pop r8
000071709abd0e02  pop rsi
000071709abd0e03  pop rdi
000071709abd0e04  pop rdx
000071709abd0e05  pop rcx
000071709abd0e06  pop rax
000071709abd0e07  add rsp, 0x08
000071709abd0e0b  jmp 0x000071709ABCF6B4
000071709abd0e10  sub rsp, 0x08
000071709abd0e14  push rax
000071709abd0e15  push rcx
000071709abd0e16  push rdx
000071709abd0e17  push rdi
000071709abd0e18  push rsi
000071709abd0e19  push r8
000071709abd0e1b  push r9
000071709abd0e1d  push r10
000071709abd0e1f  push r11
000071709abd0e21  sub rsp, 0xF0
000071709abd0e28  vmovaps [rsp], xmm0
000071709abd0e2d  vmovaps [rsp+0x10], xmm1
000071709abd0e33  vmovaps [rsp+0x20], xmm2
000071709abd0e39  vmovaps [rsp+0x30], xmm3
000071709abd0e3f  vmovaps [rsp+0x40], xmm4
000071709abd0e45  vmovaps [rsp+0x50], xmm5
000071709abd0e4b  vmovaps [rsp+0x60], xmm6
000071709abd0e51  vmovaps [rsp+0x70], xmm7
000071709abd0e57  vmovaps [rsp+0x80], xmm8
000071709abd0e60  vmovaps [rsp+0x90], xmm9
000071709abd0e69  vmovaps [rsp+0xA0], xmm10
000071709abd0e72  vmovaps [rsp+0xB0], xmm11
000071709abd0e7b  vmovaps [rsp+0xC0], xmm12
000071709abd0e84  vmovaps [rsp+0xD0], xmm13
000071709abd0e8d  vmovaps [rsp+0xE0], xmm14
000071709abd0e96  sub rsp, 0x30
000071709abd0e9a  movaps [rsp], xmm15
000071709abd0e9f  movaps [rsp+0x10], xmm10
000071709abd0ea5  movaps [rsp+0x20], xmm2
000071709abd0eaa  lea rdi, [rsp]
000071709abd0eae  mov esi, 0x00
000071709abd0eb3  mov rax, 0x60B9B2ABC530
000071709abd0ebd  call rax
000071709abd0ebf  movaps xmm15, [rsp]
000071709abd0ec4  add rsp, 0x30
000071709abd0ec8  vmovaps xmm0, [rsp]
000071709abd0ecd  vmovaps xmm1, [rsp+0x10]
000071709abd0ed3  vmovaps xmm2, [rsp+0x20]
000071709abd0ed9  vmovaps xmm3, [rsp+0x30]
000071709abd0edf  vmovaps xmm4, [rsp+0x40]
000071709abd0ee5  vmovaps xmm5, [rsp+0x50]
000071709abd0eeb  vmovaps xmm6, [rsp+0x60]
000071709abd0ef1  vmovaps xmm7, [rsp+0x70]
000071709abd0ef7  vmovaps xmm8, [rsp+0x80]
000071709abd0f00  vmovaps xmm9, [rsp+0x90]
000071709abd0f09  vmovaps xmm10, [rsp+0xA0]
000071709abd0f12  vmovaps xmm11, [rsp+0xB0]
000071709abd0f1b  vmovaps xmm12, [rsp+0xC0]
000071709abd0f24  vmovaps xmm13, [rsp+0xD0]
000071709abd0f2d  vmovaps xmm14, [rsp+0xE0]
000071709abd0f36  add rsp, 0xF0
000071709abd0f3d  pop r11
000071709abd0f3f  pop r10
000071709abd0f41  pop r9
000071709abd0f43  pop r8
000071709abd0f45  pop rsi
000071709abd0f46  pop rdi
000071709abd0f47  pop rdx
000071709abd0f48  pop rcx
000071709abd0f49  pop rax
000071709abd0f4a  add rsp, 0x08
000071709abd0f4e  jmp 0x000071709ABCF706
000071709abd0f53  sub rsp, 0x08
000071709abd0f57  push rax
000071709abd0f58  push rcx
000071709abd0f59  push rdx
000071709abd0f5a  push rdi
000071709abd0f5b  push rsi
000071709abd0f5c  push r8
000071709abd0f5e  push r9
000071709abd0f60  push r10
000071709abd0f62  push r11
000071709abd0f64  sub rsp, 0xF0
000071709abd0f6b  vmovaps [rsp], xmm0
000071709abd0f70  vmovaps [rsp+0x10], xmm2
000071709abd0f76  vmovaps [rsp+0x20], xmm3
000071709abd0f7c  vmovaps [rsp+0x30], xmm4
000071709abd0f82  vmovaps [rsp+0x40], xmm5
000071709abd0f88  vmovaps [rsp+0x50], xmm6
000071709abd0f8e  vmovaps [rsp+0x60], xmm7
000071709abd0f94  vmovaps [rsp+0x70], xmm8
000071709abd0f9a  vmovaps [rsp+0x80], xmm9
000071709abd0fa3  vmovaps [rsp+0x90], xmm10
000071709abd0fac  vmovaps [rsp+0xA0], xmm11
000071709abd0fb5  vmovaps [rsp+0xB0], xmm12
000071709abd0fbe  vmovaps [rsp+0xC0], xmm13
000071709abd0fc7  vmovaps [rsp+0xD0], xmm14
000071709abd0fd0  vmovaps [rsp+0xE0], xmm15
000071709abd0fd9  sub rsp, 0x30
000071709abd0fdd  movaps [rsp], xmm1
000071709abd0fe1  movaps [rsp+0x10], xmm10
000071709abd0fe7  movaps [rsp+0x20], xmm12
000071709abd0fed  lea rdi, [rsp]
000071709abd0ff1  mov esi, 0x00
000071709abd0ff6  mov rax, 0x60B9B2ABC530
000071709abd1000  call rax
000071709abd1002  movaps xmm1, [rsp]
000071709abd1006  add rsp, 0x30
000071709abd100a  vmovaps xmm0, [rsp]
000071709abd100f  vmovaps xmm2, [rsp+0x10]
000071709abd1015  vmovaps xmm3, [rsp+0x20]
000071709abd101b  vmovaps xmm4, [rsp+0x30]
000071709abd1021  vmovaps xmm5, [rsp+0x40]
000071709abd1027  vmovaps xmm6, [rsp+0x50]
000071709abd102d  vmovaps xmm7, [rsp+0x60]
000071709abd1033  vmovaps xmm8, [rsp+0x70]
000071709abd1039  vmovaps xmm9, [rsp+0x80]
000071709abd1042  vmovaps xmm10, [rsp+0x90]
000071709abd104b  vmovaps xmm11, [rsp+0xA0]
000071709abd1054  vmovaps xmm12, [rsp+0xB0]
000071709abd105d  vmovaps xmm13, [rsp+0xC0]
000071709abd1066  vmovaps xmm14, [rsp+0xD0]
000071709abd106f  vmovaps xmm15, [rsp+0xE0]
000071709abd1078  add rsp, 0xF0
000071709abd107f  pop r11
000071709abd1081  pop r10
000071709abd1083  pop r9
000071709abd1085  pop r8
000071709abd1087  pop rsi
000071709abd1088  pop rdi
000071709abd1089  pop rdx
000071709abd108a  pop rcx
000071709abd108b  pop rax
000071709abd108c  add rsp, 0x08
000071709abd1090  jmp 0x000071709ABCF732
000071709abd1095  sub rsp, 0x08
000071709abd1099  push rax
000071709abd109a  push rcx
000071709abd109b  push rdx
000071709abd109c  push rdi
000071709abd109d  push rsi
000071709abd109e  push r8
000071709abd10a0  push r9
000071709abd10a2  push r10
000071709abd10a4  push r11
000071709abd10a6  sub rsp, 0xF0
000071709abd10ad  vmovaps [rsp], xmm0
000071709abd10b2  vmovaps [rsp+0x10], xmm1
000071709abd10b8  vmovaps [rsp+0x20], xmm2
000071709abd10be  vmovaps [rsp+0x30], xmm3
000071709abd10c4  vmovaps [rsp+0x40], xmm4
000071709abd10ca  vmovaps [rsp+0x50], xmm5
000071709abd10d0  vmovaps [rsp+0x60], xmm6
000071709abd10d6  vmovaps [rsp+0x70], xmm7
000071709abd10dc  vmovaps [rsp+0x80], xmm8
000071709abd10e5  vmovaps [rsp+0x90], xmm9
000071709abd10ee  vmovaps [rsp+0xA0], xmm10
000071709abd10f7  vmovaps [rsp+0xB0], xmm11
000071709abd1100  vmovaps [rsp+0xC0], xmm12
000071709abd1109  vmovaps [rsp+0xD0], xmm13
000071709abd1112  vmovaps [rsp+0xE0], xmm14
000071709abd111b  sub rsp, 0x30
000071709abd111f  movaps [rsp], xmm15
000071709abd1124  movaps [rsp+0x10], xmm10
000071709abd112a  movaps [rsp+0x20], xmm12
000071709abd1130  lea rdi, [rsp]
000071709abd1134  mov esi, 0x00
000071709abd1139  mov rax, 0x60B9B2ABC530
000071709abd1143  call rax
000071709abd1145  movaps xmm15, [rsp]
000071709abd114a  add rsp, 0x30
000071709abd114e  vmovaps xmm0, [rsp]
000071709abd1153  vmovaps xmm1, [rsp+0x10]
000071709abd1159  vmovaps xmm2, [rsp+0x20]
000071709abd115f  vmovaps xmm3, [rsp+0x30]
000071709abd1165  vmovaps xmm4, [rsp+0x40]
000071709abd116b  vmovaps xmm5, [rsp+0x50]
000071709abd1171  vmovaps xmm6, [rsp+0x60]
000071709abd1177  vmovaps xmm7, [rsp+0x70]
000071709abd117d  vmovaps xmm8, [rsp+0x80]
000071709abd1186  vmovaps xmm9, [rsp+0x90]
000071709abd118f  vmovaps xmm10, [rsp+0xA0]
000071709abd1198  vmovaps xmm11, [rsp+0xB0]
000071709abd11a1  vmovaps xmm12, [rsp+0xC0]
000071709abd11aa  vmovaps xmm13, [rsp+0xD0]
000071709abd11b3  vmovaps xmm14, [rsp+0xE0]
000071709abd11bc  add rsp, 0xF0
000071709abd11c3  pop r11
000071709abd11c5  pop r10
000071709abd11c7  pop r9
000071709abd11c9  pop r8
000071709abd11cb  pop rsi
000071709abd11cc  pop rdi
000071709abd11cd  pop rdx
000071709abd11ce  pop rcx
000071709abd11cf  pop rax
000071709abd11d0  add rsp, 0x08
000071709abd11d4  jmp 0x000071709ABCF75E
000071709abd11d9  call 0x000071709A9FF430
000071709abd11de  jmp 0x000071709ABCF7EE
000071709abd11e3  call 0x000071709A9FF430
000071709abd11e8  jmp 0x000071709ABCF801
000071709abd11ed  sub rsp, 0x08
000071709abd11f1  push rax
000071709abd11f2  push rcx
000071709abd11f3  push rdx
000071709abd11f4  push rdi
000071709abd11f5  push rsi
000071709abd11f6  push r8
000071709abd11f8  push r9
000071709abd11fa  push r10
000071709abd11fc  push r11
000071709abd11fe  sub rsp, 0xF0
000071709abd1205  vmovaps [rsp], xmm0
000071709abd120a  vmovaps [rsp+0x10], xmm2
000071709abd1210  vmovaps [rsp+0x20], xmm3
000071709abd1216  vmovaps [rsp+0x30], xmm4
000071709abd121c  vmovaps [rsp+0x40], xmm5
000071709abd1222  vmovaps [rsp+0x50], xmm6
000071709abd1228  vmovaps [rsp+0x60], xmm7
000071709abd122e  vmovaps [rsp+0x70], xmm8
000071709abd1234  vmovaps [rsp+0x80], xmm9
000071709abd123d  vmovaps [rsp+0x90], xmm10
000071709abd1246  vmovaps [rsp+0xA0], xmm11
000071709abd124f  vmovaps [rsp+0xB0], xmm12
000071709abd1258  vmovaps [rsp+0xC0], xmm13
000071709abd1261  vmovaps [rsp+0xD0], xmm14
000071709abd126a  vmovaps [rsp+0xE0], xmm15
000071709abd1273  sub rsp, 0x30
000071709abd1277  movaps [rsp], xmm1
000071709abd127b  movaps [rsp+0x10], xmm13
000071709abd1281  movaps [rsp+0x20], xmm2
000071709abd1286  lea rdi, [rsp]
000071709abd128a  mov esi, 0x00
000071709abd128f  mov rax, 0x60B9B2ABC530
000071709abd1299  call rax
000071709abd129b  movaps xmm1, [rsp]
000071709abd129f  add rsp, 0x30
000071709abd12a3  vmovaps xmm0, [rsp]
000071709abd12a8  vmovaps xmm2, [rsp+0x10]
000071709abd12ae  vmovaps xmm3, [rsp+0x20]
000071709abd12b4  vmovaps xmm4, [rsp+0x30]
000071709abd12ba  vmovaps xmm5, [rsp+0x40]
000071709abd12c0  vmovaps xmm6, [rsp+0x50]
000071709abd12c6  vmovaps xmm7, [rsp+0x60]
000071709abd12cc  vmovaps xmm8, [rsp+0x70]
000071709abd12d2  vmovaps xmm9, [rsp+0x80]
000071709abd12db  vmovaps xmm10, [rsp+0x90]
000071709abd12e4  vmovaps xmm11, [rsp+0xA0]
000071709abd12ed  vmovaps xmm12, [rsp+0xB0]
000071709abd12f6  vmovaps xmm13, [rsp+0xC0]
000071709abd12ff  vmovaps xmm14, [rsp+0xD0]
000071709abd1308  vmovaps xmm15, [rsp+0xE0]
000071709abd1311  add rsp, 0xF0
000071709abd1318  pop r11
000071709abd131a  pop r10
000071709abd131c  pop r9
000071709abd131e  pop r8
000071709abd1320  pop rsi
000071709abd1321  pop rdi
000071709abd1322  pop rdx
000071709abd1323  pop rcx
000071709abd1324  pop rax
000071709abd1325  add rsp, 0x08
000071709abd1329  jmp 0x000071709ABCF82C
000071709abd132e  call 0x000071709AA0E760
000071709abd1333  jmp 0x000071709ABCF839
000071709abd1338  sub rsp, 0x08
000071709abd133c  push rax
000071709abd133d  push rcx
000071709abd133e  push rdx
000071709abd133f  push rdi
000071709abd1340  push rsi
000071709abd1341  push r8
000071709abd1343  push r9
000071709abd1345  push r10
000071709abd1347  push r11
000071709abd1349  sub rsp, 0xF0
000071709abd1350  vmovaps [rsp], xmm0
000071709abd1355  vmovaps [rsp+0x10], xmm1
000071709abd135b  vmovaps [rsp+0x20], xmm2
000071709abd1361  vmovaps [rsp+0x30], xmm3
000071709abd1367  vmovaps [rsp+0x40], xmm4
000071709abd136d  vmovaps [rsp+0x50], xmm5
000071709abd1373  vmovaps [rsp+0x60], xmm6
000071709abd1379  vmovaps [rsp+0x70], xmm7
000071709abd137f  vmovaps [rsp+0x80], xmm8
000071709abd1388  vmovaps [rsp+0x90], xmm9
000071709abd1391  vmovaps [rsp+0xA0], xmm10
000071709abd139a  vmovaps [rsp+0xB0], xmm11
000071709abd13a3  vmovaps [rsp+0xC0], xmm12
000071709abd13ac  vmovaps [rsp+0xD0], xmm14
000071709abd13b5  vmovaps [rsp+0xE0], xmm15
000071709abd13be  sub rsp, 0x30
000071709abd13c2  movaps [rsp], xmm13
000071709abd13c7  movaps [rsp+0x10], xmm2
000071709abd13cc  movaps [rsp+0x20], xmm1
000071709abd13d1  lea rdi, [rsp]
000071709abd13d5  mov esi, 0x00
000071709abd13da  mov rax, 0x60B9B2ABC530
000071709abd13e4  call rax
000071709abd13e6  movaps xmm13, [rsp]
000071709abd13eb  add rsp, 0x30
000071709abd13ef  vmovaps xmm0, [rsp]
000071709abd13f4  vmovaps xmm1, [rsp+0x10]
000071709abd13fa  vmovaps xmm2, [rsp+0x20]
000071709abd1400  vmovaps xmm3, [rsp+0x30]
000071709abd1406  vmovaps xmm4, [rsp+0x40]
000071709abd140c  vmovaps xmm5, [rsp+0x50]
000071709abd1412  vmovaps xmm6, [rsp+0x60]
000071709abd1418  vmovaps xmm7, [rsp+0x70]
000071709abd141e  vmovaps xmm8, [rsp+0x80]
000071709abd1427  vmovaps xmm9, [rsp+0x90]
000071709abd1430  vmovaps xmm10, [rsp+0xA0]
000071709abd1439  vmovaps xmm11, [rsp+0xB0]
000071709abd1442  vmovaps xmm12, [rsp+0xC0]
000071709abd144b  vmovaps xmm14, [rsp+0xD0]
000071709abd1454  vmovaps xmm15, [rsp+0xE0]
000071709abd145d  add rsp, 0xF0
000071709abd1464  pop r11
000071709abd1466  pop r10
000071709abd1468  pop r9
000071709abd146a  pop r8
000071709abd146c  pop rsi
000071709abd146d  pop rdi
000071709abd146e  pop rdx
000071709abd146f  pop rcx
000071709abd1470  pop rax
000071709abd1471  add rsp, 0x08
000071709abd1475  jmp 0x000071709ABCF878
000071709abd147a  sub rsp, 0x08
000071709abd147e  push rax
000071709abd147f  push rcx
000071709abd1480  push rdx
000071709abd1481  push rdi
000071709abd1482  push rsi
000071709abd1483  push r8
000071709abd1485  push r9
000071709abd1487  push r10
000071709abd1489  push r11
000071709abd148b  sub rsp, 0xF0
000071709abd1492  vmovaps [rsp], xmm0
000071709abd1497  vmovaps [rsp+0x10], xmm2
000071709abd149d  vmovaps [rsp+0x20], xmm3
000071709abd14a3  vmovaps [rsp+0x30], xmm4
000071709abd14a9  vmovaps [rsp+0x40], xmm5
000071709abd14af  vmovaps [rsp+0x50], xmm6
000071709abd14b5  vmovaps [rsp+0x60], xmm7
000071709abd14bb  vmovaps [rsp+0x70], xmm8
000071709abd14c1  vmovaps [rsp+0x80], xmm9
000071709abd14ca  vmovaps [rsp+0x90], xmm10
000071709abd14d3  vmovaps [rsp+0xA0], xmm11
000071709abd14dc  vmovaps [rsp+0xB0], xmm12
000071709abd14e5  vmovaps [rsp+0xC0], xmm13
000071709abd14ee  vmovaps [rsp+0xD0], xmm14
000071709abd14f7  vmovaps [rsp+0xE0], xmm15
000071709abd1500  sub rsp, 0x30
000071709abd1504  movaps [rsp], xmm1
000071709abd1508  movaps [rsp+0x10], xmm15
000071709abd150e  movaps [rsp+0x20], xmm2
000071709abd1513  lea rdi, [rsp]
000071709abd1517  mov esi, 0x00
000071709abd151c  mov rax, 0x60B9B2ABC530
000071709abd1526  call rax
000071709abd1528  movaps xmm1, [rsp]
000071709abd152c  add rsp, 0x30
000071709abd1530  vmovaps xmm0, [rsp]
000071709abd1535  vmovaps xmm2, [rsp+0x10]
000071709abd153b  vmovaps xmm3, [rsp+0x20]
000071709abd1541  vmovaps xmm4, [rsp+0x30]
000071709abd1547  vmovaps xmm5, [rsp+0x40]
000071709abd154d  vmovaps xmm6, [rsp+0x50]
000071709abd1553  vmovaps xmm7, [rsp+0x60]
000071709abd1559  vmovaps xmm8, [rsp+0x70]
000071709abd155f  vmovaps xmm9, [rsp+0x80]
000071709abd1568  vmovaps xmm10, [rsp+0x90]
000071709abd1571  vmovaps xmm11, [rsp+0xA0]
000071709abd157a  vmovaps xmm12, [rsp+0xB0]
000071709abd1583  vmovaps xmm13, [rsp+0xC0]
000071709abd158c  vmovaps xmm14, [rsp+0xD0]
000071709abd1595  vmovaps xmm15, [rsp+0xE0]
000071709abd159e  add rsp, 0xF0
000071709abd15a5  pop r11
000071709abd15a7  pop r10
000071709abd15a9  pop r9
000071709abd15ab  pop r8
000071709abd15ad  pop rsi
000071709abd15ae  pop rdi
000071709abd15af  pop rdx
000071709abd15b0  pop rcx
000071709abd15b1  pop rax
000071709abd15b2  add rsp, 0x08
000071709abd15b6  jmp 0x000071709ABCF8AC
000071709abd15bb  sub rsp, 0x08
000071709abd15bf  push rax
000071709abd15c0  push rcx
000071709abd15c1  push rdx
000071709abd15c2  push rdi
000071709abd15c3  push rsi
000071709abd15c4  push r8
000071709abd15c6  push r9
000071709abd15c8  push r10
000071709abd15ca  push r11
000071709abd15cc  sub rsp, 0xF0
000071709abd15d3  vmovaps [rsp], xmm0
000071709abd15d8  vmovaps [rsp+0x10], xmm1
000071709abd15de  vmovaps [rsp+0x20], xmm2
000071709abd15e4  vmovaps [rsp+0x30], xmm3
000071709abd15ea  vmovaps [rsp+0x40], xmm4
000071709abd15f0  vmovaps [rsp+0x50], xmm5
000071709abd15f6  vmovaps [rsp+0x60], xmm6
000071709abd15fc  vmovaps [rsp+0x70], xmm7
000071709abd1602  vmovaps [rsp+0x80], xmm8
000071709abd160b  vmovaps [rsp+0x90], xmm9
000071709abd1614  vmovaps [rsp+0xA0], xmm10
000071709abd161d  vmovaps [rsp+0xB0], xmm11
000071709abd1626  vmovaps [rsp+0xC0], xmm12
000071709abd162f  vmovaps [rsp+0xD0], xmm13
000071709abd1638  vmovaps [rsp+0xE0], xmm15
000071709abd1641  sub rsp, 0x30
000071709abd1645  movaps [rsp], xmm14
000071709abd164a  movaps [rsp+0x10], xmm2
000071709abd164f  movaps [rsp+0x20], xmm15
000071709abd1655  lea rdi, [rsp]
000071709abd1659  mov esi, 0x00
000071709abd165e  mov rax, 0x60B9B2ABC530
000071709abd1668  call rax
000071709abd166a  movaps xmm14, [rsp]
000071709abd166f  add rsp, 0x30
000071709abd1673  vmovaps xmm0, [rsp]
000071709abd1678  vmovaps xmm1, [rsp+0x10]
000071709abd167e  vmovaps xmm2, [rsp+0x20]
000071709abd1684  vmovaps xmm3, [rsp+0x30]
000071709abd168a  vmovaps xmm4, [rsp+0x40]
000071709abd1690  vmovaps xmm5, [rsp+0x50]
000071709abd1696  vmovaps xmm6, [rsp+0x60]
000071709abd169c  vmovaps xmm7, [rsp+0x70]
000071709abd16a2  vmovaps xmm8, [rsp+0x80]
000071709abd16ab  vmovaps xmm9, [rsp+0x90]
000071709abd16b4  vmovaps xmm10, [rsp+0xA0]
000071709abd16bd  vmovaps xmm11, [rsp+0xB0]
000071709abd16c6  vmovaps xmm12, [rsp+0xC0]
000071709abd16cf  vmovaps xmm13, [rsp+0xD0]
000071709abd16d8  vmovaps xmm15, [rsp+0xE0]
000071709abd16e1  add rsp, 0xF0
000071709abd16e8  pop r11
000071709abd16ea  pop r10
000071709abd16ec  pop r9
000071709abd16ee  pop r8
000071709abd16f0  pop rsi
000071709abd16f1  pop rdi
000071709abd16f2  pop rdx
000071709abd16f3  pop rcx
000071709abd16f4  pop rax
000071709abd16f5  add rsp, 0x08
000071709abd16f9  jmp 0x000071709ABCF8E7
000071709abd16fe  sub rsp, 0x08
000071709abd1702  push rax
000071709abd1703  push rcx
000071709abd1704  push rdx
000071709abd1705  push rdi
000071709abd1706  push rsi
000071709abd1707  push r8
000071709abd1709  push r9
000071709abd170b  push r10
000071709abd170d  push r11
000071709abd170f  sub rsp, 0xF0
000071709abd1716  vmovaps [rsp], xmm0
000071709abd171b  vmovaps [rsp+0x10], xmm1
000071709abd1721  vmovaps [rsp+0x20], xmm2
000071709abd1727  vmovaps [rsp+0x30], xmm3
000071709abd172d  vmovaps [rsp+0x40], xmm4
000071709abd1733  vmovaps [rsp+0x50], xmm5
000071709abd1739  vmovaps [rsp+0x60], xmm6
000071709abd173f  vmovaps [rsp+0x70], xmm7
000071709abd1745  vmovaps [rsp+0x80], xmm8
000071709abd174e  vmovaps [rsp+0x90], xmm9
000071709abd1757  vmovaps [rsp+0xA0], xmm10
000071709abd1760  vmovaps [rsp+0xB0], xmm11
000071709abd1769  vmovaps [rsp+0xC0], xmm12
000071709abd1772  vmovaps [rsp+0xD0], xmm13
000071709abd177b  vmovaps [rsp+0xE0], xmm14
000071709abd1784  sub rsp, 0x30
000071709abd1788  movaps [rsp], xmm15
000071709abd178d  movaps [rsp+0x10], xmm2
000071709abd1792  movaps [rsp+0x20], xmm1
000071709abd1797  lea rdi, [rsp]
000071709abd179b  mov esi, 0x00
000071709abd17a0  mov rax, 0x60B9B2ABC530
000071709abd17aa  call rax
000071709abd17ac  movaps xmm15, [rsp]
000071709abd17b1  add rsp, 0x30
000071709abd17b5  vmovaps xmm0, [rsp]
000071709abd17ba  vmovaps xmm1, [rsp+0x10]
000071709abd17c0  vmovaps xmm2, [rsp+0x20]
000071709abd17c6  vmovaps xmm3, [rsp+0x30]
000071709abd17cc  vmovaps xmm4, [rsp+0x40]
000071709abd17d2  vmovaps xmm5, [rsp+0x50]
000071709abd17d8  vmovaps xmm6, [rsp+0x60]
000071709abd17de  vmovaps xmm7, [rsp+0x70]
000071709abd17e4  vmovaps xmm8, [rsp+0x80]
000071709abd17ed  vmovaps xmm9, [rsp+0x90]
000071709abd17f6  vmovaps xmm10, [rsp+0xA0]
000071709abd17ff  vmovaps xmm11, [rsp+0xB0]
000071709abd1808  vmovaps xmm12, [rsp+0xC0]
000071709abd1811  vmovaps xmm13, [rsp+0xD0]
000071709abd181a  vmovaps xmm14, [rsp+0xE0]
000071709abd1823  add rsp, 0xF0
000071709abd182a  pop r11
000071709abd182c  pop r10
000071709abd182e  pop r9
000071709abd1830  pop r8
000071709abd1832  pop rsi
000071709abd1833  pop rdi
000071709abd1834  pop rdx
000071709abd1835  pop rcx
000071709abd1836  pop rax
000071709abd1837  add rsp, 0x08
000071709abd183b  jmp 0x000071709ABCF923
000071709abd1840  call 0x000071709A9FF430
000071709abd1845  jmp 0x000071709ABCF930
000071709abd184a  sub rsp, 0x08
000071709abd184e  push rax
000071709abd184f  push rcx
000071709abd1850  push rdx
000071709abd1851  push rdi
000071709abd1852  push rsi
000071709abd1853  push r8
000071709abd1855  push r9
000071709abd1857  push r10
000071709abd1859  push r11
000071709abd185b  sub rsp, 0xF0
000071709abd1862  vmovaps [rsp], xmm0
000071709abd1867  vmovaps [rsp+0x10], xmm1
000071709abd186d  vmovaps [rsp+0x20], xmm3
000071709abd1873  vmovaps [rsp+0x30], xmm4
000071709abd1879  vmovaps [rsp+0x40], xmm5
000071709abd187f  vmovaps [rsp+0x50], xmm6
000071709abd1885  vmovaps [rsp+0x60], xmm7
000071709abd188b  vmovaps [rsp+0x70], xmm8
000071709abd1891  vmovaps [rsp+0x80], xmm9
000071709abd189a  vmovaps [rsp+0x90], xmm10
000071709abd18a3  vmovaps [rsp+0xA0], xmm11
000071709abd18ac  vmovaps [rsp+0xB0], xmm12
000071709abd18b5  vmovaps [rsp+0xC0], xmm13
000071709abd18be  vmovaps [rsp+0xD0], xmm14
000071709abd18c7  vmovaps [rsp+0xE0], xmm15
000071709abd18d0  sub rsp, 0x30
000071709abd18d4  movaps [rsp], xmm2
000071709abd18d8  movaps [rsp+0x10], xmm1
000071709abd18dd  movaps [rsp+0x20], xmm14
000071709abd18e3  lea rdi, [rsp]
000071709abd18e7  mov esi, 0x00
000071709abd18ec  mov rax, 0x60B9B2ABC530
000071709abd18f6  call rax
000071709abd18f8  movaps xmm2, [rsp]
000071709abd18fc  add rsp, 0x30
000071709abd1900  vmovaps xmm0, [rsp]
000071709abd1905  vmovaps xmm1, [rsp+0x10]
000071709abd190b  vmovaps xmm3, [rsp+0x20]
000071709abd1911  vmovaps xmm4, [rsp+0x30]
000071709abd1917  vmovaps xmm5, [rsp+0x40]
000071709abd191d  vmovaps xmm6, [rsp+0x50]
000071709abd1923  vmovaps xmm7, [rsp+0x60]
000071709abd1929  vmovaps xmm8, [rsp+0x70]
000071709abd192f  vmovaps xmm9, [rsp+0x80]
000071709abd1938  vmovaps xmm10, [rsp+0x90]
000071709abd1941  vmovaps xmm11, [rsp+0xA0]
000071709abd194a  vmovaps xmm12, [rsp+0xB0]
000071709abd1953  vmovaps xmm13, [rsp+0xC0]
000071709abd195c  vmovaps xmm14, [rsp+0xD0]
000071709abd1965  vmovaps xmm15, [rsp+0xE0]
000071709abd196e  add rsp, 0xF0
000071709abd1975  pop r11
000071709abd1977  pop r10
000071709abd1979  pop r9
000071709abd197b  pop r8
000071709abd197d  pop rsi
000071709abd197e  pop rdi
000071709abd197f  pop rdx
000071709abd1980  pop rcx
000071709abd1981  pop rax
000071709abd1982  add rsp, 0x08
000071709abd1986  jmp 0x000071709ABCF96D
000071709abd198b  sub rsp, 0x08
000071709abd198f  push rax
000071709abd1990  push rcx
000071709abd1991  push rdx
000071709abd1992  push rdi
000071709abd1993  push rsi
000071709abd1994  push r8
000071709abd1996  push r9
000071709abd1998  push r10
000071709abd199a  push r11
000071709abd199c  sub rsp, 0xF0
000071709abd19a3  vmovaps [rsp], xmm0
000071709abd19a8  vmovaps [rsp+0x10], xmm1
000071709abd19ae  vmovaps [rsp+0x20], xmm2
000071709abd19b4  vmovaps [rsp+0x30], xmm3
000071709abd19ba  vmovaps [rsp+0x40], xmm4
000071709abd19c0  vmovaps [rsp+0x50], xmm5
000071709abd19c6  vmovaps [rsp+0x60], xmm6
000071709abd19cc  vmovaps [rsp+0x70], xmm7
000071709abd19d2  vmovaps [rsp+0x80], xmm8
000071709abd19db  vmovaps [rsp+0x90], xmm9
000071709abd19e4  vmovaps [rsp+0xA0], xmm10
000071709abd19ed  vmovaps [rsp+0xB0], xmm11
000071709abd19f6  vmovaps [rsp+0xC0], xmm12
000071709abd19ff  vmovaps [rsp+0xD0], xmm13
000071709abd1a08  vmovaps [rsp+0xE0], xmm14
000071709abd1a11  sub rsp, 0x30
000071709abd1a15  movaps [rsp], xmm15
000071709abd1a1a  movaps [rsp+0x10], xmm14
000071709abd1a20  movaps [rsp+0x20], xmm1
000071709abd1a25  lea rdi, [rsp]
000071709abd1a29  mov esi, 0x00
000071709abd1a2e  mov rax, 0x60B9B2ABC530
000071709abd1a38  call rax
000071709abd1a3a  movaps xmm15, [rsp]
000071709abd1a3f  add rsp, 0x30
000071709abd1a43  vmovaps xmm0, [rsp]
000071709abd1a48  vmovaps xmm1, [rsp+0x10]
000071709abd1a4e  vmovaps xmm2, [rsp+0x20]
000071709abd1a54  vmovaps xmm3, [rsp+0x30]
000071709abd1a5a  vmovaps xmm4, [rsp+0x40]
000071709abd1a60  vmovaps xmm5, [rsp+0x50]
000071709abd1a66  vmovaps xmm6, [rsp+0x60]
000071709abd1a6c  vmovaps xmm7, [rsp+0x70]
000071709abd1a72  vmovaps xmm8, [rsp+0x80]
000071709abd1a7b  vmovaps xmm9, [rsp+0x90]
000071709abd1a84  vmovaps xmm10, [rsp+0xA0]
000071709abd1a8d  vmovaps xmm11, [rsp+0xB0]
000071709abd1a96  vmovaps xmm12, [rsp+0xC0]
000071709abd1a9f  vmovaps xmm13, [rsp+0xD0]
000071709abd1aa8  vmovaps xmm14, [rsp+0xE0]
000071709abd1ab1  add rsp, 0xF0
000071709abd1ab8  pop r11
000071709abd1aba  pop r10
000071709abd1abc  pop r9
000071709abd1abe  pop r8
000071709abd1ac0  pop rsi
000071709abd1ac1  pop rdi
000071709abd1ac2  pop rdx
000071709abd1ac3  pop rcx
000071709abd1ac4  pop rax
000071709abd1ac5  add rsp, 0x08
000071709abd1ac9  jmp 0x000071709ABCF9E7
000071709abd1ace  call 0x000071709A9FF430
000071709abd1ad3  jmp 0x000071709ABCF9F4
000071709abd1ad8  sub rsp, 0x08
000071709abd1adc  push rax
000071709abd1add  push rcx
000071709abd1ade  push rdx
000071709abd1adf  push rdi
000071709abd1ae0  push rsi
000071709abd1ae1  push r8
000071709abd1ae3  push r9
000071709abd1ae5  push r10
000071709abd1ae7  push r11
000071709abd1ae9  sub rsp, 0xF0
000071709abd1af0  vmovaps [rsp], xmm0
000071709abd1af5  vmovaps [rsp+0x10], xmm1
000071709abd1afb  vmovaps [rsp+0x20], xmm2
000071709abd1b01  vmovaps [rsp+0x30], xmm3
000071709abd1b07  vmovaps [rsp+0x40], xmm4
000071709abd1b0d  vmovaps [rsp+0x50], xmm5
000071709abd1b13  vmovaps [rsp+0x60], xmm6
000071709abd1b19  vmovaps [rsp+0x70], xmm7
000071709abd1b1f  vmovaps [rsp+0x80], xmm8
000071709abd1b28  vmovaps [rsp+0x90], xmm9
000071709abd1b31  vmovaps [rsp+0xA0], xmm10
000071709abd1b3a  vmovaps [rsp+0xB0], xmm11
000071709abd1b43  vmovaps [rsp+0xC0], xmm12
000071709abd1b4c  vmovaps [rsp+0xD0], xmm13
000071709abd1b55  vmovaps [rsp+0xE0], xmm15
000071709abd1b5e  sub rsp, 0x30
000071709abd1b62  movaps [rsp], xmm14
000071709abd1b67  movaps [rsp+0x10], xmm13
000071709abd1b6d  movaps [rsp+0x20], xmm1
000071709abd1b72  lea rdi, [rsp]
000071709abd1b76  mov esi, 0x00
000071709abd1b7b  mov rax, 0x60B9B2ABC530
000071709abd1b85  call rax
000071709abd1b87  movaps xmm14, [rsp]
000071709abd1b8c  add rsp, 0x30
000071709abd1b90  vmovaps xmm0, [rsp]
000071709abd1b95  vmovaps xmm1, [rsp+0x10]
000071709abd1b9b  vmovaps xmm2, [rsp+0x20]
000071709abd1ba1  vmovaps xmm3, [rsp+0x30]
000071709abd1ba7  vmovaps xmm4, [rsp+0x40]
000071709abd1bad  vmovaps xmm5, [rsp+0x50]
000071709abd1bb3  vmovaps xmm6, [rsp+0x60]
000071709abd1bb9  vmovaps xmm7, [rsp+0x70]
000071709abd1bbf  vmovaps xmm8, [rsp+0x80]
000071709abd1bc8  vmovaps xmm9, [rsp+0x90]
000071709abd1bd1  vmovaps xmm10, [rsp+0xA0]
000071709abd1bda  vmovaps xmm11, [rsp+0xB0]
000071709abd1be3  vmovaps xmm12, [rsp+0xC0]
000071709abd1bec  vmovaps xmm13, [rsp+0xD0]
000071709abd1bf5  vmovaps xmm15, [rsp+0xE0]
000071709abd1bfe  add rsp, 0xF0
000071709abd1c05  pop r11
000071709abd1c07  pop r10
000071709abd1c09  pop r9
000071709abd1c0b  pop r8
000071709abd1c0d  pop rsi
000071709abd1c0e  pop rdi
000071709abd1c0f  pop rdx
000071709abd1c10  pop rcx
000071709abd1c11  pop rax
000071709abd1c12  add rsp, 0x08
000071709abd1c16  jmp 0x000071709ABCFAAF
000071709abd1c1b  sub rsp, 0x08
000071709abd1c1f  push rax
000071709abd1c20  push rcx
000071709abd1c21  push rdx
000071709abd1c22  push rdi
000071709abd1c23  push rsi
000071709abd1c24  push r8
000071709abd1c26  push r9
000071709abd1c28  push r10
000071709abd1c2a  push r11
000071709abd1c2c  sub rsp, 0xF0
000071709abd1c33  vmovaps [rsp], xmm0
000071709abd1c38  vmovaps [rsp+0x10], xmm1
000071709abd1c3e  vmovaps [rsp+0x20], xmm2
000071709abd1c44  vmovaps [rsp+0x30], xmm3
000071709abd1c4a  vmovaps [rsp+0x40], xmm4
000071709abd1c50  vmovaps [rsp+0x50], xmm5
000071709abd1c56  vmovaps [rsp+0x60], xmm6
000071709abd1c5c  vmovaps [rsp+0x70], xmm7
000071709abd1c62  vmovaps [rsp+0x80], xmm8
000071709abd1c6b  vmovaps [rsp+0x90], xmm9
000071709abd1c74  vmovaps [rsp+0xA0], xmm10
000071709abd1c7d  vmovaps [rsp+0xB0], xmm11
000071709abd1c86  vmovaps [rsp+0xC0], xmm12
000071709abd1c8f  vmovaps [rsp+0xD0], xmm13
000071709abd1c98  vmovaps [rsp+0xE0], xmm14
000071709abd1ca1  sub rsp, 0x30
000071709abd1ca5  movaps [rsp], xmm15
000071709abd1caa  movaps [rsp+0x10], xmm13
000071709abd1cb0  movaps [rsp+0x20], xmm1
000071709abd1cb5  lea rdi, [rsp]
000071709abd1cb9  mov esi, 0x00
000071709abd1cbe  mov rax, 0x60B9B2ABC530
000071709abd1cc8  call rax
000071709abd1cca  movaps xmm15, [rsp]
000071709abd1ccf  add rsp, 0x30
000071709abd1cd3  vmovaps xmm0, [rsp]
000071709abd1cd8  vmovaps xmm1, [rsp+0x10]
000071709abd1cde  vmovaps xmm2, [rsp+0x20]
000071709abd1ce4  vmovaps xmm3, [rsp+0x30]
000071709abd1cea  vmovaps xmm4, [rsp+0x40]
000071709abd1cf0  vmovaps xmm5, [rsp+0x50]
000071709abd1cf6  vmovaps xmm6, [rsp+0x60]
000071709abd1cfc  vmovaps xmm7, [rsp+0x70]
000071709abd1d02  vmovaps xmm8, [rsp+0x80]
000071709abd1d0b  vmovaps xmm9, [rsp+0x90]
000071709abd1d14  vmovaps xmm10, [rsp+0xA0]
000071709abd1d1d  vmovaps xmm11, [rsp+0xB0]
000071709abd1d26  vmovaps xmm12, [rsp+0xC0]
000071709abd1d2f  vmovaps xmm13, [rsp+0xD0]
000071709abd1d38  vmovaps xmm14, [rsp+0xE0]
000071709abd1d41  add rsp, 0xF0
000071709abd1d48  pop r11
000071709abd1d4a  pop r10
000071709abd1d4c  pop r9
000071709abd1d4e  pop r8
000071709abd1d50  pop rsi
000071709abd1d51  pop rdi
000071709abd1d52  pop rdx
000071709abd1d53  pop rcx
000071709abd1d54  pop rax
000071709abd1d55  add rsp, 0x08
000071709abd1d59  jmp 0x000071709ABCFAEB
000071709abd1d5e  call 0x000071709A9FF430
000071709abd1d63  jmp 0x000071709ABCFAF8
000071709abd1d68  sub rsp, 0x08
000071709abd1d6c  push rax
000071709abd1d6d  push rcx
000071709abd1d6e  push rdx
000071709abd1d6f  push rdi
000071709abd1d70  push rsi
000071709abd1d71  push r8
000071709abd1d73  push r9
000071709abd1d75  push r10
000071709abd1d77  push r11
000071709abd1d79  sub rsp, 0xF0
000071709abd1d80  vmovaps [rsp], xmm0
000071709abd1d85  vmovaps [rsp+0x10], xmm1
000071709abd1d8b  vmovaps [rsp+0x20], xmm2
000071709abd1d91  vmovaps [rsp+0x30], xmm3
000071709abd1d97  vmovaps [rsp+0x40], xmm4
000071709abd1d9d  vmovaps [rsp+0x50], xmm5
000071709abd1da3  vmovaps [rsp+0x60], xmm6
000071709abd1da9  vmovaps [rsp+0x70], xmm7
000071709abd1daf  vmovaps [rsp+0x80], xmm8
000071709abd1db8  vmovaps [rsp+0x90], xmm9
000071709abd1dc1  vmovaps [rsp+0xA0], xmm10
000071709abd1dca  vmovaps [rsp+0xB0], xmm11
000071709abd1dd3  vmovaps [rsp+0xC0], xmm12
000071709abd1ddc  vmovaps [rsp+0xD0], xmm13
000071709abd1de5  vmovaps [rsp+0xE0], xmm15
000071709abd1dee  sub rsp, 0x30
000071709abd1df2  movaps [rsp], xmm14
000071709abd1df7  movaps [rsp+0x10], xmm13
000071709abd1dfd  movaps [rsp+0x20], xmm2
000071709abd1e02  lea rdi, [rsp]
000071709abd1e06  mov esi, 0x00
000071709abd1e0b  mov rax, 0x60B9B2ABC530
000071709abd1e15  call rax
000071709abd1e17  movaps xmm14, [rsp]
000071709abd1e1c  add rsp, 0x30
000071709abd1e20  vmovaps xmm0, [rsp]
000071709abd1e25  vmovaps xmm1, [rsp+0x10]
000071709abd1e2b  vmovaps xmm2, [rsp+0x20]
000071709abd1e31  vmovaps xmm3, [rsp+0x30]
000071709abd1e37  vmovaps xmm4, [rsp+0x40]
000071709abd1e3d  vmovaps xmm5, [rsp+0x50]
000071709abd1e43  vmovaps xmm6, [rsp+0x60]
000071709abd1e49  vmovaps xmm7, [rsp+0x70]
000071709abd1e4f  vmovaps xmm8, [rsp+0x80]
000071709abd1e58  vmovaps xmm9, [rsp+0x90]
000071709abd1e61  vmovaps xmm10, [rsp+0xA0]
000071709abd1e6a  vmovaps xmm11, [rsp+0xB0]
000071709abd1e73  vmovaps xmm12, [rsp+0xC0]
000071709abd1e7c  vmovaps xmm13, [rsp+0xD0]
000071709abd1e85  vmovaps xmm15, [rsp+0xE0]
000071709abd1e8e  add rsp, 0xF0
000071709abd1e95  pop r11
000071709abd1e97  pop r10
000071709abd1e99  pop r9
000071709abd1e9b  pop r8
000071709abd1e9d  pop rsi
000071709abd1e9e  pop rdi
000071709abd1e9f  pop rdx
000071709abd1ea0  pop rcx
000071709abd1ea1  pop rax
000071709abd1ea2  add rsp, 0x08
000071709abd1ea6  jmp 0x000071709ABCFB24
000071709abd1eab  sub rsp, 0x08
000071709abd1eaf  push rax
000071709abd1eb0  push rcx
000071709abd1eb1  push rdx
000071709abd1eb2  push rdi
000071709abd1eb3  push rsi
000071709abd1eb4  push r8
000071709abd1eb6  push r9
000071709abd1eb8  push r10
000071709abd1eba  push r11
000071709abd1ebc  sub rsp, 0xF0
000071709abd1ec3  vmovaps [rsp], xmm0
000071709abd1ec8  vmovaps [rsp+0x10], xmm2
000071709abd1ece  vmovaps [rsp+0x20], xmm3
000071709abd1ed4  vmovaps [rsp+0x30], xmm4
000071709abd1eda  vmovaps [rsp+0x40], xmm5
000071709abd1ee0  vmovaps [rsp+0x50], xmm6
000071709abd1ee6  vmovaps [rsp+0x60], xmm7
000071709abd1eec  vmovaps [rsp+0x70], xmm8
000071709abd1ef2  vmovaps [rsp+0x80], xmm9
000071709abd1efb  vmovaps [rsp+0x90], xmm10
000071709abd1f04  vmovaps [rsp+0xA0], xmm11
000071709abd1f0d  vmovaps [rsp+0xB0], xmm12
000071709abd1f16  vmovaps [rsp+0xC0], xmm13
000071709abd1f1f  vmovaps [rsp+0xD0], xmm14
000071709abd1f28  vmovaps [rsp+0xE0], xmm15
000071709abd1f31  sub rsp, 0x30
000071709abd1f35  movaps [rsp], xmm1
000071709abd1f39  movaps [rsp+0x10], xmm13
000071709abd1f3f  movaps [rsp+0x20], xmm2
000071709abd1f44  lea rdi, [rsp]
000071709abd1f48  mov esi, 0x00
000071709abd1f4d  mov rax, 0x60B9B2ABC530
000071709abd1f57  call rax
000071709abd1f59  movaps xmm1, [rsp]
000071709abd1f5d  add rsp, 0x30
000071709abd1f61  vmovaps xmm0, [rsp]
000071709abd1f66  vmovaps xmm2, [rsp+0x10]
000071709abd1f6c  vmovaps xmm3, [rsp+0x20]
000071709abd1f72  vmovaps xmm4, [rsp+0x30]
000071709abd1f78  vmovaps xmm5, [rsp+0x40]
000071709abd1f7e  vmovaps xmm6, [rsp+0x50]
000071709abd1f84  vmovaps xmm7, [rsp+0x60]
000071709abd1f8a  vmovaps xmm8, [rsp+0x70]
000071709abd1f90  vmovaps xmm9, [rsp+0x80]
000071709abd1f99  vmovaps xmm10, [rsp+0x90]
000071709abd1fa2  vmovaps xmm11, [rsp+0xA0]
000071709abd1fab  vmovaps xmm12, [rsp+0xB0]
000071709abd1fb4  vmovaps xmm13, [rsp+0xC0]
000071709abd1fbd  vmovaps xmm14, [rsp+0xD0]
000071709abd1fc6  vmovaps xmm15, [rsp+0xE0]
000071709abd1fcf  add rsp, 0xF0
000071709abd1fd6  pop r11
000071709abd1fd8  pop r10
000071709abd1fda  pop r9
000071709abd1fdc  pop r8
000071709abd1fde  pop rsi
000071709abd1fdf  pop rdi
000071709abd1fe0  pop rdx
000071709abd1fe1  pop rcx
000071709abd1fe2  pop rax
000071709abd1fe3  add rsp, 0x08
000071709abd1fe7  jmp 0x000071709ABCFB52
000071709abd1fec  sub rsp, 0x08
000071709abd1ff0  push rax
000071709abd1ff1  push rcx
000071709abd1ff2  push rdx
000071709abd1ff3  push rdi
000071709abd1ff4  push rsi
000071709abd1ff5  push r8
000071709abd1ff7  push r9
000071709abd1ff9  push r10
000071709abd1ffb  push r11
000071709abd1ffd  sub rsp, 0xF0
000071709abd2004  vmovaps [rsp], xmm0
000071709abd2009  vmovaps [rsp+0x10], xmm1
000071709abd200f  vmovaps [rsp+0x20], xmm3
000071709abd2015  vmovaps [rsp+0x30], xmm4
000071709abd201b  vmovaps [rsp+0x40], xmm5
000071709abd2021  vmovaps [rsp+0x50], xmm6
000071709abd2027  vmovaps [rsp+0x60], xmm7
000071709abd202d  vmovaps [rsp+0x70], xmm8
000071709abd2033  vmovaps [rsp+0x80], xmm9
000071709abd203c  vmovaps [rsp+0x90], xmm10
000071709abd2045  vmovaps [rsp+0xA0], xmm11
000071709abd204e  vmovaps [rsp+0xB0], xmm12
000071709abd2057  vmovaps [rsp+0xC0], xmm13
000071709abd2060  vmovaps [rsp+0xD0], xmm14
000071709abd2069  vmovaps [rsp+0xE0], xmm15
000071709abd2072  sub rsp, 0x30
000071709abd2076  movaps [rsp], xmm2
000071709abd207a  movaps [rsp+0x10], xmm1
000071709abd207f  movaps [rsp+0x20], xmm13
000071709abd2085  lea rdi, [rsp]
000071709abd2089  mov esi, 0x00
000071709abd208e  mov rax, 0x60B9B2ABC530
000071709abd2098  call rax
000071709abd209a  movaps xmm2, [rsp]
000071709abd209e  add rsp, 0x30
000071709abd20a2  vmovaps xmm0, [rsp]
000071709abd20a7  vmovaps xmm1, [rsp+0x10]
000071709abd20ad  vmovaps xmm3, [rsp+0x20]
000071709abd20b3  vmovaps xmm4, [rsp+0x30]
000071709abd20b9  vmovaps xmm5, [rsp+0x40]
000071709abd20bf  vmovaps xmm6, [rsp+0x50]
000071709abd20c5  vmovaps xmm7, [rsp+0x60]
000071709abd20cb  vmovaps xmm8, [rsp+0x70]
000071709abd20d1  vmovaps xmm9, [rsp+0x80]
000071709abd20da  vmovaps xmm10, [rsp+0x90]
000071709abd20e3  vmovaps xmm11, [rsp+0xA0]
000071709abd20ec  vmovaps xmm12, [rsp+0xB0]
000071709abd20f5  vmovaps xmm13, [rsp+0xC0]
000071709abd20fe  vmovaps xmm14, [rsp+0xD0]
000071709abd2107  vmovaps xmm15, [rsp+0xE0]
000071709abd2110  add rsp, 0xF0
000071709abd2117  pop r11
000071709abd2119  pop r10
000071709abd211b  pop r9
000071709abd211d  pop r8
000071709abd211f  pop rsi
000071709abd2120  pop rdi
000071709abd2121  pop rdx
000071709abd2122  pop rcx
000071709abd2123  pop rax
000071709abd2124  add rsp, 0x08
000071709abd2128  jmp 0x000071709ABCFBAB
000071709abd212d  call 0x000071709A9FF430
000071709abd2132  jmp 0x000071709ABCFBB8
000071709abd2137  sub rsp, 0x08
000071709abd213b  push rax
000071709abd213c  push rcx
000071709abd213d  push rdx
000071709abd213e  push rdi
000071709abd213f  push rsi
000071709abd2140  push r8
000071709abd2142  push r9
000071709abd2144  push r10
000071709abd2146  push r11
000071709abd2148  sub rsp, 0xF0
000071709abd214f  vmovaps [rsp], xmm0
000071709abd2154  vmovaps [rsp+0x10], xmm1
000071709abd215a  vmovaps [rsp+0x20], xmm2
000071709abd2160  vmovaps [rsp+0x30], xmm3
000071709abd2166  vmovaps [rsp+0x40], xmm4
000071709abd216c  vmovaps [rsp+0x50], xmm5
000071709abd2172  vmovaps [rsp+0x60], xmm6
000071709abd2178  vmovaps [rsp+0x70], xmm7
000071709abd217e  vmovaps [rsp+0x80], xmm8
000071709abd2187  vmovaps [rsp+0x90], xmm9
000071709abd2190  vmovaps [rsp+0xA0], xmm10
000071709abd2199  vmovaps [rsp+0xB0], xmm11
000071709abd21a2  vmovaps [rsp+0xC0], xmm12
000071709abd21ab  vmovaps [rsp+0xD0], xmm13
000071709abd21b4  vmovaps [rsp+0xE0], xmm14
000071709abd21bd  sub rsp, 0x30
000071709abd21c1  movaps [rsp], xmm15
000071709abd21c6  movaps [rsp+0x10], xmm13
000071709abd21cc  movaps [rsp+0x20], xmm1
000071709abd21d1  lea rdi, [rsp]
000071709abd21d5  mov esi, 0x00
000071709abd21da  mov rax, 0x60B9B2ABC530
000071709abd21e4  call rax
000071709abd21e6  movaps xmm15, [rsp]
000071709abd21eb  add rsp, 0x30
000071709abd21ef  vmovaps xmm0, [rsp]
000071709abd21f4  vmovaps xmm1, [rsp+0x10]
000071709abd21fa  vmovaps xmm2, [rsp+0x20]
000071709abd2200  vmovaps xmm3, [rsp+0x30]
000071709abd2206  vmovaps xmm4, [rsp+0x40]
000071709abd220c  vmovaps xmm5, [rsp+0x50]
000071709abd2212  vmovaps xmm6, [rsp+0x60]
000071709abd2218  vmovaps xmm7, [rsp+0x70]
000071709abd221e  vmovaps xmm8, [rsp+0x80]
000071709abd2227  vmovaps xmm9, [rsp+0x90]
000071709abd2230  vmovaps xmm10, [rsp+0xA0]
000071709abd2239  vmovaps xmm11, [rsp+0xB0]
000071709abd2242  vmovaps xmm12, [rsp+0xC0]
000071709abd224b  vmovaps xmm13, [rsp+0xD0]
000071709abd2254  vmovaps xmm14, [rsp+0xE0]
000071709abd225d  add rsp, 0xF0
000071709abd2264  pop r11
000071709abd2266  pop r10
000071709abd2268  pop r9
000071709abd226a  pop r8
000071709abd226c  pop rsi
000071709abd226d  pop rdi
000071709abd226e  pop rdx
000071709abd226f  pop rcx
000071709abd2270  pop rax
000071709abd2271  add rsp, 0x08
000071709abd2275  jmp 0x000071709ABCFBF7
000071709abd227a  sub rsp, 0x08
000071709abd227e  push rax
000071709abd227f  push rcx
000071709abd2280  push rdx
000071709abd2281  push rdi
000071709abd2282  push rsi
000071709abd2283  push r8
000071709abd2285  push r9
000071709abd2287  push r10
000071709abd2289  push r11
000071709abd228b  sub rsp, 0xF0
000071709abd2292  vmovaps [rsp], xmm0
000071709abd2297  vmovaps [rsp+0x10], xmm1
000071709abd229d  vmovaps [rsp+0x20], xmm2
000071709abd22a3  vmovaps [rsp+0x30], xmm3
000071709abd22a9  vmovaps [rsp+0x40], xmm4
000071709abd22af  vmovaps [rsp+0x50], xmm5
000071709abd22b5  vmovaps [rsp+0x60], xmm6
000071709abd22bb  vmovaps [rsp+0x70], xmm7
000071709abd22c1  vmovaps [rsp+0x80], xmm8
000071709abd22ca  vmovaps [rsp+0x90], xmm9
000071709abd22d3  vmovaps [rsp+0xA0], xmm10
000071709abd22dc  vmovaps [rsp+0xB0], xmm11
000071709abd22e5  vmovaps [rsp+0xC0], xmm12
000071709abd22ee  vmovaps [rsp+0xD0], xmm13
000071709abd22f7  vmovaps [rsp+0xE0], xmm15
000071709abd2300  sub rsp, 0x30
000071709abd2304  movaps [rsp], xmm14
000071709abd2309  movaps [rsp+0x10], xmm11
000071709abd230f  movaps [rsp+0x20], xmm1
000071709abd2314  lea rdi, [rsp]
000071709abd2318  mov esi, 0x00
000071709abd231d  mov rax, 0x60B9B2ABC530
000071709abd2327  call rax
000071709abd2329  movaps xmm14, [rsp]
000071709abd232e  add rsp, 0x30
000071709abd2332  vmovaps xmm0, [rsp]
000071709abd2337  vmovaps xmm1, [rsp+0x10]
000071709abd233d  vmovaps xmm2, [rsp+0x20]
000071709abd2343  vmovaps xmm3, [rsp+0x30]
000071709abd2349  vmovaps xmm4, [rsp+0x40]
000071709abd234f  vmovaps xmm5, [rsp+0x50]
000071709abd2355  vmovaps xmm6, [rsp+0x60]
000071709abd235b  vmovaps xmm7, [rsp+0x70]
000071709abd2361  vmovaps xmm8, [rsp+0x80]
000071709abd236a  vmovaps xmm9, [rsp+0x90]
000071709abd2373  vmovaps xmm10, [rsp+0xA0]
000071709abd237c  vmovaps xmm11, [rsp+0xB0]
000071709abd2385  vmovaps xmm12, [rsp+0xC0]
000071709abd238e  vmovaps xmm13, [rsp+0xD0]
000071709abd2397  vmovaps xmm15, [rsp+0xE0]
000071709abd23a0  add rsp, 0xF0
000071709abd23a7  pop r11
000071709abd23a9  pop r10
000071709abd23ab  pop r9
000071709abd23ad  pop r8
000071709abd23af  pop rsi
000071709abd23b0  pop rdi
000071709abd23b1  pop rdx
000071709abd23b2  pop rcx
000071709abd23b3  pop rax
000071709abd23b4  add rsp, 0x08
000071709abd23b8  jmp 0x000071709ABCFC21
000071709abd23bd  sub rsp, 0x08
000071709abd23c1  push rax
000071709abd23c2  push rcx
000071709abd23c3  push rdx
000071709abd23c4  push rdi
000071709abd23c5  push rsi
000071709abd23c6  push r8
000071709abd23c8  push r9
000071709abd23ca  push r10
000071709abd23cc  push r11
000071709abd23ce  sub rsp, 0xF0
000071709abd23d5  vmovaps [rsp], xmm0
000071709abd23da  vmovaps [rsp+0x10], xmm1
000071709abd23e0  vmovaps [rsp+0x20], xmm2
000071709abd23e6  vmovaps [rsp+0x30], xmm3
000071709abd23ec  vmovaps [rsp+0x40], xmm4
000071709abd23f2  vmovaps [rsp+0x50], xmm5
000071709abd23f8  vmovaps [rsp+0x60], xmm6
000071709abd23fe  vmovaps [rsp+0x70], xmm7
000071709abd2404  vmovaps [rsp+0x80], xmm8
000071709abd240d  vmovaps [rsp+0x90], xmm9
000071709abd2416  vmovaps [rsp+0xA0], xmm10
000071709abd241f  vmovaps [rsp+0xB0], xmm11
000071709abd2428  vmovaps [rsp+0xC0], xmm12
000071709abd2431  vmovaps [rsp+0xD0], xmm14
000071709abd243a  vmovaps [rsp+0xE0], xmm15
000071709abd2443  sub rsp, 0x30
000071709abd2447  movaps [rsp], xmm13
000071709abd244c  movaps [rsp+0x10], xmm11
000071709abd2452  movaps [rsp+0x20], xmm1
000071709abd2457  lea rdi, [rsp]
000071709abd245b  mov esi, 0x00
000071709abd2460  mov rax, 0x60B9B2ABC530
000071709abd246a  call rax
000071709abd246c  movaps xmm13, [rsp]
000071709abd2471  add rsp, 0x30
000071709abd2475  vmovaps xmm0, [rsp]
000071709abd247a  vmovaps xmm1, [rsp+0x10]
000071709abd2480  vmovaps xmm2, [rsp+0x20]
000071709abd2486  vmovaps xmm3, [rsp+0x30]
000071709abd248c  vmovaps xmm4, [rsp+0x40]
000071709abd2492  vmovaps xmm5, [rsp+0x50]
000071709abd2498  vmovaps xmm6, [rsp+0x60]
000071709abd249e  vmovaps xmm7, [rsp+0x70]
000071709abd24a4  vmovaps xmm8, [rsp+0x80]
000071709abd24ad  vmovaps xmm9, [rsp+0x90]
000071709abd24b6  vmovaps xmm10, [rsp+0xA0]
000071709abd24bf  vmovaps xmm11, [rsp+0xB0]
000071709abd24c8  vmovaps xmm12, [rsp+0xC0]
000071709abd24d1  vmovaps xmm14, [rsp+0xD0]
000071709abd24da  vmovaps xmm15, [rsp+0xE0]
000071709abd24e3  add rsp, 0xF0
000071709abd24ea  pop r11
000071709abd24ec  pop r10
000071709abd24ee  pop r9
000071709abd24f0  pop r8
000071709abd24f2  pop rsi
000071709abd24f3  pop rdi
000071709abd24f4  pop rdx
000071709abd24f5  pop rcx
000071709abd24f6  pop rax
000071709abd24f7  add rsp, 0x08
000071709abd24fb  jmp 0x000071709ABCFC76
000071709abd2500  call 0x000071709A9FF430
000071709abd2505  jmp 0x000071709ABCFC83
000071709abd250a  sub rsp, 0x08
000071709abd250e  push rax
000071709abd250f  push rcx
000071709abd2510  push rdx
000071709abd2511  push rdi
000071709abd2512  push rsi
000071709abd2513  push r8
000071709abd2515  push r9
000071709abd2517  push r10
000071709abd2519  push r11
000071709abd251b  sub rsp, 0xF0
000071709abd2522  vmovaps [rsp], xmm0
000071709abd2527  vmovaps [rsp+0x10], xmm1
000071709abd252d  vmovaps [rsp+0x20], xmm2
000071709abd2533  vmovaps [rsp+0x30], xmm3
000071709abd2539  vmovaps [rsp+0x40], xmm4
000071709abd253f  vmovaps [rsp+0x50], xmm5
000071709abd2545  vmovaps [rsp+0x60], xmm6
000071709abd254b  vmovaps [rsp+0x70], xmm7
000071709abd2551  vmovaps [rsp+0x80], xmm8
000071709abd255a  vmovaps [rsp+0x90], xmm9
000071709abd2563  vmovaps [rsp+0xA0], xmm10
000071709abd256c  vmovaps [rsp+0xB0], xmm11
000071709abd2575  vmovaps [rsp+0xC0], xmm12
000071709abd257e  vmovaps [rsp+0xD0], xmm13
000071709abd2587  vmovaps [rsp+0xE0], xmm14
000071709abd2590  sub rsp, 0x30
000071709abd2594  movaps [rsp], xmm15
000071709abd2599  movaps [rsp+0x10], xmm11
000071709abd259f  movaps [rsp+0x20], xmm1
000071709abd25a4  lea rdi, [rsp]
000071709abd25a8  mov esi, 0x00
000071709abd25ad  mov rax, 0x60B9B2ABC530
000071709abd25b7  call rax
000071709abd25b9  movaps xmm15, [rsp]
000071709abd25be  add rsp, 0x30
000071709abd25c2  vmovaps xmm0, [rsp]
000071709abd25c7  vmovaps xmm1, [rsp+0x10]
000071709abd25cd  vmovaps xmm2, [rsp+0x20]
000071709abd25d3  vmovaps xmm3, [rsp+0x30]
000071709abd25d9  vmovaps xmm4, [rsp+0x40]
000071709abd25df  vmovaps xmm5, [rsp+0x50]
000071709abd25e5  vmovaps xmm6, [rsp+0x60]
000071709abd25eb  vmovaps xmm7, [rsp+0x70]
000071709abd25f1  vmovaps xmm8, [rsp+0x80]
000071709abd25fa  vmovaps xmm9, [rsp+0x90]
000071709abd2603  vmovaps xmm10, [rsp+0xA0]
000071709abd260c  vmovaps xmm11, [rsp+0xB0]
000071709abd2615  vmovaps xmm12, [rsp+0xC0]
000071709abd261e  vmovaps xmm13, [rsp+0xD0]
000071709abd2627  vmovaps xmm14, [rsp+0xE0]
000071709abd2630  add rsp, 0xF0
000071709abd2637  pop r11
000071709abd2639  pop r10
000071709abd263b  pop r9
000071709abd263d  pop r8
000071709abd263f  pop rsi
000071709abd2640  pop rdi
000071709abd2641  pop rdx
000071709abd2642  pop rcx
000071709abd2643  pop rax
000071709abd2644  add rsp, 0x08
000071709abd2648  jmp 0x000071709ABCFCBC
000071709abd264d  sub rsp, 0x08
000071709abd2651  push rax
000071709abd2652  push rcx
000071709abd2653  push rdx
000071709abd2654  push rdi
000071709abd2655  push rsi
000071709abd2656  push r8
000071709abd2658  push r9
000071709abd265a  push r10
000071709abd265c  push r11
000071709abd265e  sub rsp, 0xF0
000071709abd2665  vmovaps [rsp], xmm0
000071709abd266a  vmovaps [rsp+0x10], xmm1
000071709abd2670  vmovaps [rsp+0x20], xmm2
000071709abd2676  vmovaps [rsp+0x30], xmm3
000071709abd267c  vmovaps [rsp+0x40], xmm4
000071709abd2682  vmovaps [rsp+0x50], xmm5
000071709abd2688  vmovaps [rsp+0x60], xmm6
000071709abd268e  vmovaps [rsp+0x70], xmm7
000071709abd2694  vmovaps [rsp+0x80], xmm8
000071709abd269d  vmovaps [rsp+0x90], xmm9
000071709abd26a6  vmovaps [rsp+0xA0], xmm10
000071709abd26af  vmovaps [rsp+0xB0], xmm12
000071709abd26b8  vmovaps [rsp+0xC0], xmm13
000071709abd26c1  vmovaps [rsp+0xD0], xmm14
000071709abd26ca  vmovaps [rsp+0xE0], xmm15
000071709abd26d3  sub rsp, 0x30
000071709abd26d7  movaps [rsp], xmm11
000071709abd26dc  movaps [rsp+0x10], xmm6
000071709abd26e1  movaps [rsp+0x20], xmm14
000071709abd26e7  lea rdi, [rsp]
000071709abd26eb  mov esi, 0x00
000071709abd26f0  mov rax, 0x60B9B2ABC530
000071709abd26fa  call rax
000071709abd26fc  movaps xmm11, [rsp]
000071709abd2701  add rsp, 0x30
000071709abd2705  vmovaps xmm0, [rsp]
000071709abd270a  vmovaps xmm1, [rsp+0x10]
000071709abd2710  vmovaps xmm2, [rsp+0x20]
000071709abd2716  vmovaps xmm3, [rsp+0x30]
000071709abd271c  vmovaps xmm4, [rsp+0x40]
000071709abd2722  vmovaps xmm5, [rsp+0x50]
000071709abd2728  vmovaps xmm6, [rsp+0x60]
000071709abd272e  vmovaps xmm7, [rsp+0x70]
000071709abd2734  vmovaps xmm8, [rsp+0x80]
000071709abd273d  vmovaps xmm9, [rsp+0x90]
000071709abd2746  vmovaps xmm10, [rsp+0xA0]
000071709abd274f  vmovaps xmm12, [rsp+0xB0]
000071709abd2758  vmovaps xmm13, [rsp+0xC0]
000071709abd2761  vmovaps xmm14, [rsp+0xD0]
000071709abd276a  vmovaps xmm15, [rsp+0xE0]
000071709abd2773  add rsp, 0xF0
000071709abd277a  pop r11
000071709abd277c  pop r10
000071709abd277e  pop r9
000071709abd2780  pop r8
000071709abd2782  pop rsi
000071709abd2783  pop rdi
000071709abd2784  pop rdx
000071709abd2785  pop rcx
000071709abd2786  pop rax
000071709abd2787  add rsp, 0x08
000071709abd278b  jmp 0x000071709ABCFD34
000071709abd2790  call 0x000071709A9FF430
000071709abd2795  jmp 0x000071709ABCFD3E
000071709abd279a  sub rsp, 0x08
000071709abd279e  push rax
000071709abd279f  push rcx
000071709abd27a0  push rdx
000071709abd27a1  push rdi
000071709abd27a2  push rsi
000071709abd27a3  push r8
000071709abd27a5  push r9
000071709abd27a7  push r10
000071709abd27a9  push r11
000071709abd27ab  sub rsp, 0xF0
000071709abd27b2  vmovaps [rsp], xmm0
000071709abd27b7  vmovaps [rsp+0x10], xmm1
000071709abd27bd  vmovaps [rsp+0x20], xmm2
000071709abd27c3  vmovaps [rsp+0x30], xmm3
000071709abd27c9  vmovaps [rsp+0x40], xmm4
000071709abd27cf  vmovaps [rsp+0x50], xmm5
000071709abd27d5  vmovaps [rsp+0x60], xmm6
000071709abd27db  vmovaps [rsp+0x70], xmm7
000071709abd27e1  vmovaps [rsp+0x80], xmm8
000071709abd27ea  vmovaps [rsp+0x90], xmm9
000071709abd27f3  vmovaps [rsp+0xA0], xmm10
000071709abd27fc  vmovaps [rsp+0xB0], xmm11
000071709abd2805  vmovaps [rsp+0xC0], xmm12
000071709abd280e  vmovaps [rsp+0xD0], xmm13
000071709abd2817  vmovaps [rsp+0xE0], xmm15
000071709abd2820  sub rsp, 0x30
000071709abd2824  movaps [rsp], xmm14
000071709abd2829  movaps [rsp+0x10], xmm6
000071709abd282e  movaps [rsp+0x20], xmm2
000071709abd2833  lea rdi, [rsp]
000071709abd2837  mov esi, 0x00
000071709abd283c  mov rax, 0x60B9B2ABC530
000071709abd2846  call rax
000071709abd2848  movaps xmm14, [rsp]
000071709abd284d  add rsp, 0x30
000071709abd2851  vmovaps xmm0, [rsp]
000071709abd2856  vmovaps xmm1, [rsp+0x10]
000071709abd285c  vmovaps xmm2, [rsp+0x20]
000071709abd2862  vmovaps xmm3, [rsp+0x30]
000071709abd2868  vmovaps xmm4, [rsp+0x40]
000071709abd286e  vmovaps xmm5, [rsp+0x50]
000071709abd2874  vmovaps xmm6, [rsp+0x60]
000071709abd287a  vmovaps xmm7, [rsp+0x70]
000071709abd2880  vmovaps xmm8, [rsp+0x80]
000071709abd2889  vmovaps xmm9, [rsp+0x90]
000071709abd2892  vmovaps xmm10, [rsp+0xA0]
000071709abd289b  vmovaps xmm11, [rsp+0xB0]
000071709abd28a4  vmovaps xmm12, [rsp+0xC0]
000071709abd28ad  vmovaps xmm13, [rsp+0xD0]
000071709abd28b6  vmovaps xmm15, [rsp+0xE0]
000071709abd28bf  add rsp, 0xF0
000071709abd28c6  pop r11
000071709abd28c8  pop r10
000071709abd28ca  pop r9
000071709abd28cc  pop r8
000071709abd28ce  pop rsi
000071709abd28cf  pop rdi
000071709abd28d0  pop rdx
000071709abd28d1  pop rcx
000071709abd28d2  pop rax
000071709abd28d3  add rsp, 0x08
000071709abd28d7  jmp 0x000071709ABCFD72
000071709abd28dc  sub rsp, 0x08
000071709abd28e0  push rax
000071709abd28e1  push rcx
000071709abd28e2  push rdx
000071709abd28e3  push rdi
000071709abd28e4  push rsi
000071709abd28e5  push r8
000071709abd28e7  push r9
000071709abd28e9  push r10
000071709abd28eb  push r11
000071709abd28ed  sub rsp, 0xF0
000071709abd28f4  vmovaps [rsp], xmm0
000071709abd28f9  vmovaps [rsp+0x10], xmm1
000071709abd28ff  vmovaps [rsp+0x20], xmm2
000071709abd2905  vmovaps [rsp+0x30], xmm3
000071709abd290b  vmovaps [rsp+0x40], xmm4
000071709abd2911  vmovaps [rsp+0x50], xmm5
000071709abd2917  vmovaps [rsp+0x60], xmm7
000071709abd291d  vmovaps [rsp+0x70], xmm8
000071709abd2923  vmovaps [rsp+0x80], xmm9
000071709abd292c  vmovaps [rsp+0x90], xmm10
000071709abd2935  vmovaps [rsp+0xA0], xmm11
000071709abd293e  vmovaps [rsp+0xB0], xmm12
000071709abd2947  vmovaps [rsp+0xC0], xmm13
000071709abd2950  vmovaps [rsp+0xD0], xmm14
000071709abd2959  vmovaps [rsp+0xE0], xmm15
000071709abd2962  sub rsp, 0x30
000071709abd2966  movaps [rsp], xmm6
000071709abd296a  movaps [rsp+0x10], xmm5
000071709abd296f  movaps [rsp+0x20], xmm1
000071709abd2974  lea rdi, [rsp]
000071709abd2978  mov esi, 0x00
000071709abd297d  mov rax, 0x60B9B2ABC530
000071709abd2987  call rax
000071709abd2989  movaps xmm6, [rsp]
000071709abd298d  add rsp, 0x30
000071709abd2991  vmovaps xmm0, [rsp]
000071709abd2996  vmovaps xmm1, [rsp+0x10]
000071709abd299c  vmovaps xmm2, [rsp+0x20]
000071709abd29a2  vmovaps xmm3, [rsp+0x30]
000071709abd29a8  vmovaps xmm4, [rsp+0x40]
000071709abd29ae  vmovaps xmm5, [rsp+0x50]
000071709abd29b4  vmovaps xmm7, [rsp+0x60]
000071709abd29ba  vmovaps xmm8, [rsp+0x70]
000071709abd29c0  vmovaps xmm9, [rsp+0x80]
000071709abd29c9  vmovaps xmm10, [rsp+0x90]
000071709abd29d2  vmovaps xmm11, [rsp+0xA0]
000071709abd29db  vmovaps xmm12, [rsp+0xB0]
000071709abd29e4  vmovaps xmm13, [rsp+0xC0]
000071709abd29ed  vmovaps xmm14, [rsp+0xD0]
000071709abd29f6  vmovaps xmm15, [rsp+0xE0]
000071709abd29ff  add rsp, 0xF0
000071709abd2a06  pop r11
000071709abd2a08  pop r10
000071709abd2a0a  pop r9
000071709abd2a0c  pop r8
000071709abd2a0e  pop rsi
000071709abd2a0f  pop rdi
000071709abd2a10  pop rdx
000071709abd2a11  pop rcx
000071709abd2a12  pop rax
000071709abd2a13  add rsp, 0x08
000071709abd2a17  jmp 0x000071709ABCFD98
000071709abd2a1c  sub rsp, 0x08
000071709abd2a20  push rax
000071709abd2a21  push rcx
000071709abd2a22  push rdx
000071709abd2a23  push rdi
000071709abd2a24  push rsi
000071709abd2a25  push r8
000071709abd2a27  push r9
000071709abd2a29  push r10
000071709abd2a2b  push r11
000071709abd2a2d  sub rsp, 0xF0
000071709abd2a34  vmovaps [rsp], xmm0
000071709abd2a39  vmovaps [rsp+0x10], xmm2
000071709abd2a3f  vmovaps [rsp+0x20], xmm3
000071709abd2a45  vmovaps [rsp+0x30], xmm4
000071709abd2a4b  vmovaps [rsp+0x40], xmm5
000071709abd2a51  vmovaps [rsp+0x50], xmm6
000071709abd2a57  vmovaps [rsp+0x60], xmm7
000071709abd2a5d  vmovaps [rsp+0x70], xmm8
000071709abd2a63  vmovaps [rsp+0x80], xmm9
000071709abd2a6c  vmovaps [rsp+0x90], xmm10
000071709abd2a75  vmovaps [rsp+0xA0], xmm11
000071709abd2a7e  vmovaps [rsp+0xB0], xmm12
000071709abd2a87  vmovaps [rsp+0xC0], xmm13
000071709abd2a90  vmovaps [rsp+0xD0], xmm14
000071709abd2a99  vmovaps [rsp+0xE0], xmm15
000071709abd2aa2  sub rsp, 0x30
000071709abd2aa6  movaps [rsp], xmm1
000071709abd2aaa  movaps [rsp+0x10], xmm5
000071709abd2aaf  movaps [rsp+0x20], xmm13
000071709abd2ab5  lea rdi, [rsp]
000071709abd2ab9  mov esi, 0x00
000071709abd2abe  mov rax, 0x60B9B2ABC530
000071709abd2ac8  call rax
000071709abd2aca  movaps xmm1, [rsp]
000071709abd2ace  add rsp, 0x30
000071709abd2ad2  vmovaps xmm0, [rsp]
000071709abd2ad7  vmovaps xmm2, [rsp+0x10]
000071709abd2add  vmovaps xmm3, [rsp+0x20]
000071709abd2ae3  vmovaps xmm4, [rsp+0x30]
000071709abd2ae9  vmovaps xmm5, [rsp+0x40]
000071709abd2aef  vmovaps xmm6, [rsp+0x50]
000071709abd2af5  vmovaps xmm7, [rsp+0x60]
000071709abd2afb  vmovaps xmm8, [rsp+0x70]
000071709abd2b01  vmovaps xmm9, [rsp+0x80]
000071709abd2b0a  vmovaps xmm10, [rsp+0x90]
000071709abd2b13  vmovaps xmm11, [rsp+0xA0]
000071709abd2b1c  vmovaps xmm12, [rsp+0xB0]
000071709abd2b25  vmovaps xmm13, [rsp+0xC0]
000071709abd2b2e  vmovaps xmm14, [rsp+0xD0]
000071709abd2b37  vmovaps xmm15, [rsp+0xE0]
000071709abd2b40  add rsp, 0xF0
000071709abd2b47  pop r11
000071709abd2b49  pop r10
000071709abd2b4b  pop r9
000071709abd2b4d  pop r8
000071709abd2b4f  pop rsi
000071709abd2b50  pop rdi
000071709abd2b51  pop rdx
000071709abd2b52  pop rcx
000071709abd2b53  pop rax
000071709abd2b54  add rsp, 0x08
000071709abd2b58  jmp 0x000071709ABCFDB6
000071709abd2b5d  sub rsp, 0x08
000071709abd2b61  push rax
000071709abd2b62  push rcx
000071709abd2b63  push rdx
000071709abd2b64  push rdi
000071709abd2b65  push rsi
000071709abd2b66  push r8
000071709abd2b68  push r9
000071709abd2b6a  push r10
000071709abd2b6c  push r11
000071709abd2b6e  sub rsp, 0xF0
000071709abd2b75  vmovaps [rsp], xmm0
000071709abd2b7a  vmovaps [rsp+0x10], xmm1
000071709abd2b80  vmovaps [rsp+0x20], xmm2
000071709abd2b86  vmovaps [rsp+0x30], xmm3
000071709abd2b8c  vmovaps [rsp+0x40], xmm4
000071709abd2b92  vmovaps [rsp+0x50], xmm6
000071709abd2b98  vmovaps [rsp+0x60], xmm7
000071709abd2b9e  vmovaps [rsp+0x70], xmm8
000071709abd2ba4  vmovaps [rsp+0x80], xmm9
000071709abd2bad  vmovaps [rsp+0x90], xmm10
000071709abd2bb6  vmovaps [rsp+0xA0], xmm11
000071709abd2bbf  vmovaps [rsp+0xB0], xmm12
000071709abd2bc8  vmovaps [rsp+0xC0], xmm13
000071709abd2bd1  vmovaps [rsp+0xD0], xmm14
000071709abd2bda  vmovaps [rsp+0xE0], xmm15
000071709abd2be3  sub rsp, 0x30
000071709abd2be7  movaps [rsp], xmm5
000071709abd2beb  movaps [rsp+0x10], xmm2
000071709abd2bf0  movaps [rsp+0x20], xmm13
000071709abd2bf6  lea rdi, [rsp]
000071709abd2bfa  mov esi, 0x00
000071709abd2bff  mov rax, 0x60B9B2ABC530
000071709abd2c09  call rax
000071709abd2c0b  movaps xmm5, [rsp]
000071709abd2c0f  add rsp, 0x30
000071709abd2c13  vmovaps xmm0, [rsp]
000071709abd2c18  vmovaps xmm1, [rsp+0x10]
000071709abd2c1e  vmovaps xmm2, [rsp+0x20]
000071709abd2c24  vmovaps xmm3, [rsp+0x30]
000071709abd2c2a  vmovaps xmm4, [rsp+0x40]
000071709abd2c30  vmovaps xmm6, [rsp+0x50]
000071709abd2c36  vmovaps xmm7, [rsp+0x60]
000071709abd2c3c  vmovaps xmm8, [rsp+0x70]
000071709abd2c42  vmovaps xmm9, [rsp+0x80]
000071709abd2c4b  vmovaps xmm10, [rsp+0x90]
000071709abd2c54  vmovaps xmm11, [rsp+0xA0]
000071709abd2c5d  vmovaps xmm12, [rsp+0xB0]
000071709abd2c66  vmovaps xmm13, [rsp+0xC0]
000071709abd2c6f  vmovaps xmm14, [rsp+0xD0]
000071709abd2c78  vmovaps xmm15, [rsp+0xE0]
000071709abd2c81  add rsp, 0xF0
000071709abd2c88  pop r11
000071709abd2c8a  pop r10
000071709abd2c8c  pop r9
000071709abd2c8e  pop r8
000071709abd2c90  pop rsi
000071709abd2c91  pop rdi
000071709abd2c92  pop rdx
000071709abd2c93  pop rcx
000071709abd2c94  pop rax
000071709abd2c95  add rsp, 0x08
000071709abd2c99  jmp 0x000071709ABCFDEC
000071709abd2c9e  sub rsp, 0x08
000071709abd2ca2  push rax
000071709abd2ca3  push rcx
000071709abd2ca4  push rdx
000071709abd2ca5  push rdi
000071709abd2ca6  push rsi
000071709abd2ca7  push r8
000071709abd2ca9  push r9
000071709abd2cab  push r10
000071709abd2cad  push r11
000071709abd2caf  sub rsp, 0xF0
000071709abd2cb6  vmovaps [rsp], xmm0
000071709abd2cbb  vmovaps [rsp+0x10], xmm1
000071709abd2cc1  vmovaps [rsp+0x20], xmm2
000071709abd2cc7  vmovaps [rsp+0x30], xmm3
000071709abd2ccd  vmovaps [rsp+0x40], xmm4
000071709abd2cd3  vmovaps [rsp+0x50], xmm5
000071709abd2cd9  vmovaps [rsp+0x60], xmm6
000071709abd2cdf  vmovaps [rsp+0x70], xmm7
000071709abd2ce5  vmovaps [rsp+0x80], xmm8
000071709abd2cee  vmovaps [rsp+0x90], xmm9
000071709abd2cf7  vmovaps [rsp+0xA0], xmm10
000071709abd2d00  vmovaps [rsp+0xB0], xmm11
000071709abd2d09  vmovaps [rsp+0xC0], xmm12
000071709abd2d12  vmovaps [rsp+0xD0], xmm14
000071709abd2d1b  vmovaps [rsp+0xE0], xmm15
000071709abd2d24  sub rsp, 0x30
000071709abd2d28  movaps [rsp], xmm13
000071709abd2d2d  movaps [rsp+0x10], xmm10
000071709abd2d33  movaps [rsp+0x20], xmm1
000071709abd2d38  lea rdi, [rsp]
000071709abd2d3c  mov esi, 0x00
000071709abd2d41  mov rax, 0x60B9B2ABC530
000071709abd2d4b  call rax
000071709abd2d4d  movaps xmm13, [rsp]
000071709abd2d52  add rsp, 0x30
000071709abd2d56  vmovaps xmm0, [rsp]
000071709abd2d5b  vmovaps xmm1, [rsp+0x10]
000071709abd2d61  vmovaps xmm2, [rsp+0x20]
000071709abd2d67  vmovaps xmm3, [rsp+0x30]
000071709abd2d6d  vmovaps xmm4, [rsp+0x40]
000071709abd2d73  vmovaps xmm5, [rsp+0x50]
000071709abd2d79  vmovaps xmm6, [rsp+0x60]
000071709abd2d7f  vmovaps xmm7, [rsp+0x70]
000071709abd2d85  vmovaps xmm8, [rsp+0x80]
000071709abd2d8e  vmovaps xmm9, [rsp+0x90]
000071709abd2d97  vmovaps xmm10, [rsp+0xA0]
000071709abd2da0  vmovaps xmm11, [rsp+0xB0]
000071709abd2da9  vmovaps xmm12, [rsp+0xC0]
000071709abd2db2  vmovaps xmm14, [rsp+0xD0]
000071709abd2dbb  vmovaps xmm15, [rsp+0xE0]
000071709abd2dc4  add rsp, 0xF0
000071709abd2dcb  pop r11
000071709abd2dcd  pop r10
000071709abd2dcf  pop r9
000071709abd2dd1  pop r8
000071709abd2dd3  pop rsi
000071709abd2dd4  pop rdi
000071709abd2dd5  pop rdx
000071709abd2dd6  pop rcx
000071709abd2dd7  pop rax
000071709abd2dd8  add rsp, 0x08
000071709abd2ddc  jmp 0x000071709ABCFE15
000071709abd2de1  sub rsp, 0x08
000071709abd2de5  push rax
000071709abd2de6  push rcx
000071709abd2de7  push rdx
000071709abd2de8  push rdi
000071709abd2de9  push rsi
000071709abd2dea  push r8
000071709abd2dec  push r9
000071709abd2dee  push r10
000071709abd2df0  push r11
000071709abd2df2  sub rsp, 0xF0
000071709abd2df9  vmovaps [rsp], xmm0
000071709abd2dfe  vmovaps [rsp+0x10], xmm2
000071709abd2e04  vmovaps [rsp+0x20], xmm3
000071709abd2e0a  vmovaps [rsp+0x30], xmm4
000071709abd2e10  vmovaps [rsp+0x40], xmm5
000071709abd2e16  vmovaps [rsp+0x50], xmm6
000071709abd2e1c  vmovaps [rsp+0x60], xmm7
000071709abd2e22  vmovaps [rsp+0x70], xmm8
000071709abd2e28  vmovaps [rsp+0x80], xmm9
000071709abd2e31  vmovaps [rsp+0x90], xmm10
000071709abd2e3a  vmovaps [rsp+0xA0], xmm11
000071709abd2e43  vmovaps [rsp+0xB0], xmm12
000071709abd2e4c  vmovaps [rsp+0xC0], xmm13
000071709abd2e55  vmovaps [rsp+0xD0], xmm14
000071709abd2e5e  vmovaps [rsp+0xE0], xmm15
000071709abd2e67  sub rsp, 0x30
000071709abd2e6b  movaps [rsp], xmm1
000071709abd2e6f  movaps [rsp+0x10], xmm15
000071709abd2e75  movaps [rsp+0x20], xmm10
000071709abd2e7b  lea rdi, [rsp]
000071709abd2e7f  mov esi, 0x00
000071709abd2e84  mov rax, 0x60B9B2ABC530
000071709abd2e8e  call rax
000071709abd2e90  movaps xmm1, [rsp]
000071709abd2e94  add rsp, 0x30
000071709abd2e98  vmovaps xmm0, [rsp]
000071709abd2e9d  vmovaps xmm2, [rsp+0x10]
000071709abd2ea3  vmovaps xmm3, [rsp+0x20]
000071709abd2ea9  vmovaps xmm4, [rsp+0x30]
000071709abd2eaf  vmovaps xmm5, [rsp+0x40]
000071709abd2eb5  vmovaps xmm6, [rsp+0x50]
000071709abd2ebb  vmovaps xmm7, [rsp+0x60]
000071709abd2ec1  vmovaps xmm8, [rsp+0x70]
000071709abd2ec7  vmovaps xmm9, [rsp+0x80]
000071709abd2ed0  vmovaps xmm10, [rsp+0x90]
000071709abd2ed9  vmovaps xmm11, [rsp+0xA0]
000071709abd2ee2  vmovaps xmm12, [rsp+0xB0]
000071709abd2eeb  vmovaps xmm13, [rsp+0xC0]
000071709abd2ef4  vmovaps xmm14, [rsp+0xD0]
000071709abd2efd  vmovaps xmm15, [rsp+0xE0]
000071709abd2f06  add rsp, 0xF0
000071709abd2f0d  pop r11
000071709abd2f0f  pop r10
000071709abd2f11  pop r9
000071709abd2f13  pop r8
000071709abd2f15  pop rsi
000071709abd2f16  pop rdi
000071709abd2f17  pop rdx
000071709abd2f18  pop rcx
000071709abd2f19  pop rax
000071709abd2f1a  add rsp, 0x08
000071709abd2f1e  jmp 0x000071709ABCFE34
000071709abd2f23  sub rsp, 0x08
000071709abd2f27  push rax
000071709abd2f28  push rcx
000071709abd2f29  push rdx
000071709abd2f2a  push rdi
000071709abd2f2b  push rsi
000071709abd2f2c  push r8
000071709abd2f2e  push r9
000071709abd2f30  push r10
000071709abd2f32  push r11
000071709abd2f34  sub rsp, 0xF0
000071709abd2f3b  vmovaps [rsp], xmm0
000071709abd2f40  vmovaps [rsp+0x10], xmm1
000071709abd2f46  vmovaps [rsp+0x20], xmm2
000071709abd2f4c  vmovaps [rsp+0x30], xmm3
000071709abd2f52  vmovaps [rsp+0x40], xmm4
000071709abd2f58  vmovaps [rsp+0x50], xmm5
000071709abd2f5e  vmovaps [rsp+0x60], xmm6
000071709abd2f64  vmovaps [rsp+0x70], xmm7
000071709abd2f6a  vmovaps [rsp+0x80], xmm8
000071709abd2f73  vmovaps [rsp+0x90], xmm9
000071709abd2f7c  vmovaps [rsp+0xA0], xmm10
000071709abd2f85  vmovaps [rsp+0xB0], xmm11
000071709abd2f8e  vmovaps [rsp+0xC0], xmm12
000071709abd2f97  vmovaps [rsp+0xD0], xmm13
000071709abd2fa0  vmovaps [rsp+0xE0], xmm14
000071709abd2fa9  sub rsp, 0x30
000071709abd2fad  movaps [rsp], xmm15
000071709abd2fb2  movaps [rsp+0x10], xmm10
000071709abd2fb8  movaps [rsp+0x20], xmm11
000071709abd2fbe  lea rdi, [rsp]
000071709abd2fc2  mov esi, 0x00
000071709abd2fc7  mov rax, 0x60B9B2ABC530
000071709abd2fd1  call rax
000071709abd2fd3  movaps xmm15, [rsp]
000071709abd2fd8  add rsp, 0x30
000071709abd2fdc  vmovaps xmm0, [rsp]
000071709abd2fe1  vmovaps xmm1, [rsp+0x10]
000071709abd2fe7  vmovaps xmm2, [rsp+0x20]
000071709abd2fed  vmovaps xmm3, [rsp+0x30]
000071709abd2ff3  vmovaps xmm4, [rsp+0x40]
000071709abd2ff9  vmovaps xmm5, [rsp+0x50]
000071709abd2fff  vmovaps xmm6, [rsp+0x60]
000071709abd3005  vmovaps xmm7, [rsp+0x70]
000071709abd300b  vmovaps xmm8, [rsp+0x80]
000071709abd3014  vmovaps xmm9, [rsp+0x90]
000071709abd301d  vmovaps xmm10, [rsp+0xA0]
000071709abd3026  vmovaps xmm11, [rsp+0xB0]
000071709abd302f  vmovaps xmm12, [rsp+0xC0]
000071709abd3038  vmovaps xmm13, [rsp+0xD0]
000071709abd3041  vmovaps xmm14, [rsp+0xE0]
000071709abd304a  add rsp, 0xF0
000071709abd3051  pop r11
000071709abd3053  pop r10
000071709abd3055  pop r9
000071709abd3057  pop r8
000071709abd3059  pop rsi
000071709abd305a  pop rdi
000071709abd305b  pop rdx
000071709abd305c  pop rcx
000071709abd305d  pop rax
000071709abd305e  add rsp, 0x08
000071709abd3062  jmp 0x000071709ABCFE57
000071709abd3067  sub rsp, 0x08
000071709abd306b  push rax
000071709abd306c  push rcx
000071709abd306d  push rdx
000071709abd306e  push rdi
000071709abd306f  push rsi
000071709abd3070  push r8
000071709abd3072  push r9
000071709abd3074  push r10
000071709abd3076  push r11
000071709abd3078  sub rsp, 0xF0
000071709abd307f  vmovaps [rsp], xmm0
000071709abd3084  vmovaps [rsp+0x10], xmm1
000071709abd308a  vmovaps [rsp+0x20], xmm2
000071709abd3090  vmovaps [rsp+0x30], xmm3
000071709abd3096  vmovaps [rsp+0x40], xmm4
000071709abd309c  vmovaps [rsp+0x50], xmm5
000071709abd30a2  vmovaps [rsp+0x60], xmm6
000071709abd30a8  vmovaps [rsp+0x70], xmm7
000071709abd30ae  vmovaps [rsp+0x80], xmm8
000071709abd30b7  vmovaps [rsp+0x90], xmm9
000071709abd30c0  vmovaps [rsp+0xA0], xmm11
000071709abd30c9  vmovaps [rsp+0xB0], xmm12
000071709abd30d2  vmovaps [rsp+0xC0], xmm13
000071709abd30db  vmovaps [rsp+0xD0], xmm14
000071709abd30e4  vmovaps [rsp+0xE0], xmm15
000071709abd30ed  sub rsp, 0x30
000071709abd30f1  movaps [rsp], xmm10
000071709abd30f6  movaps [rsp+0x10], xmm12
000071709abd30fc  movaps [rsp+0x20], xmm11
000071709abd3102  lea rdi, [rsp]
000071709abd3106  mov esi, 0x00
000071709abd310b  mov rax, 0x60B9B2ABC530
000071709abd3115  call rax
000071709abd3117  movaps xmm10, [rsp]
000071709abd311c  add rsp, 0x30
000071709abd3120  vmovaps xmm0, [rsp]
000071709abd3125  vmovaps xmm1, [rsp+0x10]
000071709abd312b  vmovaps xmm2, [rsp+0x20]
000071709abd3131  vmovaps xmm3, [rsp+0x30]
000071709abd3137  vmovaps xmm4, [rsp+0x40]
000071709abd313d  vmovaps xmm5, [rsp+0x50]
000071709abd3143  vmovaps xmm6, [rsp+0x60]
000071709abd3149  vmovaps xmm7, [rsp+0x70]
000071709abd314f  vmovaps xmm8, [rsp+0x80]
000071709abd3158  vmovaps xmm9, [rsp+0x90]
000071709abd3161  vmovaps xmm11, [rsp+0xA0]
000071709abd316a  vmovaps xmm12, [rsp+0xB0]
000071709abd3173  vmovaps xmm13, [rsp+0xC0]
000071709abd317c  vmovaps xmm14, [rsp+0xD0]
000071709abd3185  vmovaps xmm15, [rsp+0xE0]
000071709abd318e  add rsp, 0xF0
000071709abd3195  pop r11
000071709abd3197  pop r10
000071709abd3199  pop r9
000071709abd319b  pop r8
000071709abd319d  pop rsi
000071709abd319e  pop rdi
000071709abd319f  pop rdx
000071709abd31a0  pop rcx
000071709abd31a1  pop rax
000071709abd31a2  add rsp, 0x08
000071709abd31a6  jmp 0x000071709ABCFE80
000071709abd31ab  sub rsp, 0x08
000071709abd31af  push rax
000071709abd31b0  push rcx
000071709abd31b1  push rdx
000071709abd31b2  push rdi
000071709abd31b3  push rsi
000071709abd31b4  push r8
000071709abd31b6  push r9
000071709abd31b8  push r10
000071709abd31ba  push r11
000071709abd31bc  sub rsp, 0xF0
000071709abd31c3  vmovaps [rsp], xmm0
000071709abd31c8  vmovaps [rsp+0x10], xmm1
000071709abd31ce  vmovaps [rsp+0x20], xmm2
000071709abd31d4  vmovaps [rsp+0x30], xmm3
000071709abd31da  vmovaps [rsp+0x40], xmm4
000071709abd31e0  vmovaps [rsp+0x50], xmm5
000071709abd31e6  vmovaps [rsp+0x60], xmm6
000071709abd31ec  vmovaps [rsp+0x70], xmm7
000071709abd31f2  vmovaps [rsp+0x80], xmm8
000071709abd31fb  vmovaps [rsp+0x90], xmm9
000071709abd3204  vmovaps [rsp+0xA0], xmm10
000071709abd320d  vmovaps [rsp+0xB0], xmm12
000071709abd3216  vmovaps [rsp+0xC0], xmm13
000071709abd321f  vmovaps [rsp+0xD0], xmm14
000071709abd3228  vmovaps [rsp+0xE0], xmm15
000071709abd3231  sub rsp, 0x30
000071709abd3235  movaps [rsp], xmm11
000071709abd323a  movaps [rsp+0x10], xmm2
000071709abd323f  movaps [rsp+0x20], xmm12
000071709abd3245  lea rdi, [rsp]
000071709abd3249  mov esi, 0x00
000071709abd324e  mov rax, 0x60B9B2ABC530
000071709abd3258  call rax
000071709abd325a  movaps xmm11, [rsp]
000071709abd325f  add rsp, 0x30
000071709abd3263  vmovaps xmm0, [rsp]
000071709abd3268  vmovaps xmm1, [rsp+0x10]
000071709abd326e  vmovaps xmm2, [rsp+0x20]
000071709abd3274  vmovaps xmm3, [rsp+0x30]
000071709abd327a  vmovaps xmm4, [rsp+0x40]
000071709abd3280  vmovaps xmm5, [rsp+0x50]
000071709abd3286  vmovaps xmm6, [rsp+0x60]
000071709abd328c  vmovaps xmm7, [rsp+0x70]
000071709abd3292  vmovaps xmm8, [rsp+0x80]
000071709abd329b  vmovaps xmm9, [rsp+0x90]
000071709abd32a4  vmovaps xmm10, [rsp+0xA0]
000071709abd32ad  vmovaps xmm12, [rsp+0xB0]
000071709abd32b6  vmovaps xmm13, [rsp+0xC0]
000071709abd32bf  vmovaps xmm14, [rsp+0xD0]
000071709abd32c8  vmovaps xmm15, [rsp+0xE0]
000071709abd32d1  add rsp, 0xF0
000071709abd32d8  pop r11
000071709abd32da  pop r10
000071709abd32dc  pop r9
000071709abd32de  pop r8
000071709abd32e0  pop rsi
000071709abd32e1  pop rdi
000071709abd32e2  pop rdx
000071709abd32e3  pop rcx
000071709abd32e4  pop rax
000071709abd32e5  add rsp, 0x08
000071709abd32e9  jmp 0x000071709ABCFEB8
000071709abd32ee  sub rsp, 0x08
000071709abd32f2  push rax
000071709abd32f3  push rcx
000071709abd32f4  push rdx
000071709abd32f5  push rdi
000071709abd32f6  push rsi
000071709abd32f7  push r8
000071709abd32f9  push r9
000071709abd32fb  push r10
000071709abd32fd  push r11
000071709abd32ff  sub rsp, 0xF0
000071709abd3306  vmovaps [rsp], xmm0
000071709abd330b  vmovaps [rsp+0x10], xmm2
000071709abd3311  vmovaps [rsp+0x20], xmm3
000071709abd3317  vmovaps [rsp+0x30], xmm4
000071709abd331d  vmovaps [rsp+0x40], xmm5
000071709abd3323  vmovaps [rsp+0x50], xmm6
000071709abd3329  vmovaps [rsp+0x60], xmm7
000071709abd332f  vmovaps [rsp+0x70], xmm8
000071709abd3335  vmovaps [rsp+0x80], xmm9
000071709abd333e  vmovaps [rsp+0x90], xmm10
000071709abd3347  vmovaps [rsp+0xA0], xmm11
000071709abd3350  vmovaps [rsp+0xB0], xmm12
000071709abd3359  vmovaps [rsp+0xC0], xmm13
000071709abd3362  vmovaps [rsp+0xD0], xmm14
000071709abd336b  vmovaps [rsp+0xE0], xmm15
000071709abd3374  sub rsp, 0x30
000071709abd3378  movaps [rsp], xmm1
000071709abd337c  movaps [rsp+0x10], xmm14
000071709abd3382  movaps [rsp+0x20], xmm6
000071709abd3387  lea rdi, [rsp]
000071709abd338b  mov esi, 0x00
000071709abd3390  mov rax, 0x60B9B2ABC530
000071709abd339a  call rax
000071709abd339c  movaps xmm1, [rsp]
000071709abd33a0  add rsp, 0x30
000071709abd33a4  vmovaps xmm0, [rsp]
000071709abd33a9  vmovaps xmm2, [rsp+0x10]
000071709abd33af  vmovaps xmm3, [rsp+0x20]
000071709abd33b5  vmovaps xmm4, [rsp+0x30]
000071709abd33bb  vmovaps xmm5, [rsp+0x40]
000071709abd33c1  vmovaps xmm6, [rsp+0x50]
000071709abd33c7  vmovaps xmm7, [rsp+0x60]
000071709abd33cd  vmovaps xmm8, [rsp+0x70]
000071709abd33d3  vmovaps xmm9, [rsp+0x80]
000071709abd33dc  vmovaps xmm10, [rsp+0x90]
000071709abd33e5  vmovaps xmm11, [rsp+0xA0]
000071709abd33ee  vmovaps xmm12, [rsp+0xB0]
000071709abd33f7  vmovaps xmm13, [rsp+0xC0]
000071709abd3400  vmovaps xmm14, [rsp+0xD0]
000071709abd3409  vmovaps xmm15, [rsp+0xE0]
000071709abd3412  add rsp, 0xF0
000071709abd3419  pop r11
000071709abd341b  pop r10
000071709abd341d  pop r9
000071709abd341f  pop r8
000071709abd3421  pop rsi
000071709abd3422  pop rdi
000071709abd3423  pop rdx
000071709abd3424  pop rcx
000071709abd3425  pop rax
000071709abd3426  add rsp, 0x08
000071709abd342a  jmp 0x000071709ABCFED1
000071709abd342f  sub rsp, 0x08
000071709abd3433  push rax
000071709abd3434  push rcx
000071709abd3435  push rdx
000071709abd3436  push rdi
000071709abd3437  push rsi
000071709abd3438  push r8
000071709abd343a  push r9
000071709abd343c  push r10
000071709abd343e  push r11
000071709abd3440  sub rsp, 0xF0
000071709abd3447  vmovaps [rsp], xmm0
000071709abd344c  vmovaps [rsp+0x10], xmm1
000071709abd3452  vmovaps [rsp+0x20], xmm2
000071709abd3458  vmovaps [rsp+0x30], xmm3
000071709abd345e  vmovaps [rsp+0x40], xmm4
000071709abd3464  vmovaps [rsp+0x50], xmm5
000071709abd346a  vmovaps [rsp+0x60], xmm6
000071709abd3470  vmovaps [rsp+0x70], xmm7
000071709abd3476  vmovaps [rsp+0x80], xmm8
000071709abd347f  vmovaps [rsp+0x90], xmm9
000071709abd3488  vmovaps [rsp+0xA0], xmm10
000071709abd3491  vmovaps [rsp+0xB0], xmm11
000071709abd349a  vmovaps [rsp+0xC0], xmm12
000071709abd34a3  vmovaps [rsp+0xD0], xmm13
000071709abd34ac  vmovaps [rsp+0xE0], xmm15
000071709abd34b5  sub rsp, 0x30
000071709abd34b9  movaps [rsp], xmm14
000071709abd34be  movaps [rsp+0x10], xmm12
000071709abd34c4  movaps [rsp+0x20], xmm5
000071709abd34c9  lea rdi, [rsp]
000071709abd34cd  mov esi, 0x00
000071709abd34d2  mov rax, 0x60B9B2ABC530
000071709abd34dc  call rax
000071709abd34de  movaps xmm14, [rsp]
000071709abd34e3  add rsp, 0x30
000071709abd34e7  vmovaps xmm0, [rsp]
000071709abd34ec  vmovaps xmm1, [rsp+0x10]
000071709abd34f2  vmovaps xmm2, [rsp+0x20]
000071709abd34f8  vmovaps xmm3, [rsp+0x30]
000071709abd34fe  vmovaps xmm4, [rsp+0x40]
000071709abd3504  vmovaps xmm5, [rsp+0x50]
000071709abd350a  vmovaps xmm6, [rsp+0x60]
000071709abd3510  vmovaps xmm7, [rsp+0x70]
000071709abd3516  vmovaps xmm8, [rsp+0x80]
000071709abd351f  vmovaps xmm9, [rsp+0x90]
000071709abd3528  vmovaps xmm10, [rsp+0xA0]
000071709abd3531  vmovaps xmm11, [rsp+0xB0]
000071709abd353a  vmovaps xmm12, [rsp+0xC0]
000071709abd3543  vmovaps xmm13, [rsp+0xD0]
000071709abd354c  vmovaps xmm15, [rsp+0xE0]
000071709abd3555  add rsp, 0xF0
000071709abd355c  pop r11
000071709abd355e  pop r10
000071709abd3560  pop r9
000071709abd3562  pop r8
000071709abd3564  pop rsi
000071709abd3565  pop rdi
000071709abd3566  pop rdx
000071709abd3567  pop rcx
000071709abd3568  pop rax
000071709abd3569  add rsp, 0x08
000071709abd356d  jmp 0x000071709ABCFEF1
000071709abd3572  sub rsp, 0x08
000071709abd3576  push rax
000071709abd3577  push rcx
000071709abd3578  push rdx
000071709abd3579  push rdi
000071709abd357a  push rsi
000071709abd357b  push r8
000071709abd357d  push r9
000071709abd357f  push r10
000071709abd3581  push r11
000071709abd3583  sub rsp, 0xF0
000071709abd358a  vmovaps [rsp], xmm0
000071709abd358f  vmovaps [rsp+0x10], xmm1
000071709abd3595  vmovaps [rsp+0x20], xmm2
000071709abd359b  vmovaps [rsp+0x30], xmm3
000071709abd35a1  vmovaps [rsp+0x40], xmm4
000071709abd35a7  vmovaps [rsp+0x50], xmm5
000071709abd35ad  vmovaps [rsp+0x60], xmm7
000071709abd35b3  vmovaps [rsp+0x70], xmm8
000071709abd35b9  vmovaps [rsp+0x80], xmm9
000071709abd35c2  vmovaps [rsp+0x90], xmm10
000071709abd35cb  vmovaps [rsp+0xA0], xmm11
000071709abd35d4  vmovaps [rsp+0xB0], xmm12
000071709abd35dd  vmovaps [rsp+0xC0], xmm13
000071709abd35e6  vmovaps [rsp+0xD0], xmm14
000071709abd35ef  vmovaps [rsp+0xE0], xmm15
000071709abd35f8  sub rsp, 0x30
000071709abd35fc  movaps [rsp], xmm6
000071709abd3600  movaps [rsp+0x10], xmm9
000071709abd3606  movaps [rsp+0x20], xmm12
000071709abd360c  lea rdi, [rsp]
000071709abd3610  mov esi, 0x00
000071709abd3615  mov rax, 0x60B9B2ABC530
000071709abd361f  call rax
000071709abd3621  movaps xmm6, [rsp]
000071709abd3625  add rsp, 0x30
000071709abd3629  vmovaps xmm0, [rsp]
000071709abd362e  vmovaps xmm1, [rsp+0x10]
000071709abd3634  vmovaps xmm2, [rsp+0x20]
000071709abd363a  vmovaps xmm3, [rsp+0x30]
000071709abd3640  vmovaps xmm4, [rsp+0x40]
000071709abd3646  vmovaps xmm5, [rsp+0x50]
000071709abd364c  vmovaps xmm7, [rsp+0x60]
000071709abd3652  vmovaps xmm8, [rsp+0x70]
000071709abd3658  vmovaps xmm9, [rsp+0x80]
000071709abd3661  vmovaps xmm10, [rsp+0x90]
000071709abd366a  vmovaps xmm11, [rsp+0xA0]
000071709abd3673  vmovaps xmm12, [rsp+0xB0]
000071709abd367c  vmovaps xmm13, [rsp+0xC0]
000071709abd3685  vmovaps xmm14, [rsp+0xD0]
000071709abd368e  vmovaps xmm15, [rsp+0xE0]
000071709abd3697  add rsp, 0xF0
000071709abd369e  pop r11
000071709abd36a0  pop r10
000071709abd36a2  pop r9
000071709abd36a4  pop r8
000071709abd36a6  pop rsi
000071709abd36a7  pop rdi
000071709abd36a8  pop rdx
000071709abd36a9  pop rcx
000071709abd36aa  pop rax
000071709abd36ab  add rsp, 0x08
000071709abd36af  jmp 0x000071709ABCFF19
000071709abd36b4  sub rsp, 0x08
000071709abd36b8  push rax
000071709abd36b9  push rcx
000071709abd36ba  push rdx
000071709abd36bb  push rdi
000071709abd36bc  push rsi
000071709abd36bd  push r8
000071709abd36bf  push r9
000071709abd36c1  push r10
000071709abd36c3  push r11
000071709abd36c5  sub rsp, 0xF0
000071709abd36cc  vmovaps [rsp], xmm0
000071709abd36d1  vmovaps [rsp+0x10], xmm1
000071709abd36d7  vmovaps [rsp+0x20], xmm2
000071709abd36dd  vmovaps [rsp+0x30], xmm3
000071709abd36e3  vmovaps [rsp+0x40], xmm4
000071709abd36e9  vmovaps [rsp+0x50], xmm5
000071709abd36ef  vmovaps [rsp+0x60], xmm6
000071709abd36f5  vmovaps [rsp+0x70], xmm7
000071709abd36fb  vmovaps [rsp+0x80], xmm8
000071709abd3704  vmovaps [rsp+0x90], xmm9
000071709abd370d  vmovaps [rsp+0xA0], xmm10
000071709abd3716  vmovaps [rsp+0xB0], xmm11
000071709abd371f  vmovaps [rsp+0xC0], xmm13
000071709abd3728  vmovaps [rsp+0xD0], xmm14
000071709abd3731  vmovaps [rsp+0xE0], xmm15
000071709abd373a  sub rsp, 0x30
000071709abd373e  movaps [rsp], xmm12
000071709abd3743  movaps [rsp+0x10], xmm15
000071709abd3749  movaps [rsp+0x20], xmm13
000071709abd374f  lea rdi, [rsp]
000071709abd3753  mov esi, 0x00
000071709abd3758  mov rax, 0x60B9B2ABC530
000071709abd3762  call rax
000071709abd3764  movaps xmm12, [rsp]
000071709abd3769  add rsp, 0x30
000071709abd376d  vmovaps xmm0, [rsp]
000071709abd3772  vmovaps xmm1, [rsp+0x10]
000071709abd3778  vmovaps xmm2, [rsp+0x20]
000071709abd377e  vmovaps xmm3, [rsp+0x30]
000071709abd3784  vmovaps xmm4, [rsp+0x40]
000071709abd378a  vmovaps xmm5, [rsp+0x50]
000071709abd3790  vmovaps xmm6, [rsp+0x60]
000071709abd3796  vmovaps xmm7, [rsp+0x70]
000071709abd379c  vmovaps xmm8, [rsp+0x80]
000071709abd37a5  vmovaps xmm9, [rsp+0x90]
000071709abd37ae  vmovaps xmm10, [rsp+0xA0]
000071709abd37b7  vmovaps xmm11, [rsp+0xB0]
000071709abd37c0  vmovaps xmm13, [rsp+0xC0]
000071709abd37c9  vmovaps xmm14, [rsp+0xD0]
000071709abd37d2  vmovaps xmm15, [rsp+0xE0]
000071709abd37db  add rsp, 0xF0
000071709abd37e2  pop r11
000071709abd37e4  pop r10
000071709abd37e6  pop r9
000071709abd37e8  pop r8
000071709abd37ea  pop rsi
000071709abd37eb  pop rdi
000071709abd37ec  pop rdx
000071709abd37ed  pop rcx
000071709abd37ee  pop rax
000071709abd37ef  add rsp, 0x08
000071709abd37f3  jmp 0x000071709ABCFF34
000071709abd37f8  sub rsp, 0x08
000071709abd37fc  push rax
000071709abd37fd  push rcx
000071709abd37fe  push rdx
000071709abd37ff  push rdi
000071709abd3800  push rsi
000071709abd3801  push r8
000071709abd3803  push r9
000071709abd3805  push r10
000071709abd3807  push r11
000071709abd3809  sub rsp, 0xF0
000071709abd3810  vmovaps [rsp], xmm0
000071709abd3815  vmovaps [rsp+0x10], xmm1
000071709abd381b  vmovaps [rsp+0x20], xmm2
000071709abd3821  vmovaps [rsp+0x30], xmm3
000071709abd3827  vmovaps [rsp+0x40], xmm4
000071709abd382d  vmovaps [rsp+0x50], xmm5
000071709abd3833  vmovaps [rsp+0x60], xmm6
000071709abd3839  vmovaps [rsp+0x70], xmm7
000071709abd383f  vmovaps [rsp+0x80], xmm8
000071709abd3848  vmovaps [rsp+0x90], xmm9
000071709abd3851  vmovaps [rsp+0xA0], xmm10
000071709abd385a  vmovaps [rsp+0xB0], xmm11
000071709abd3863  vmovaps [rsp+0xC0], xmm12
000071709abd386c  vmovaps [rsp+0xD0], xmm13
000071709abd3875  vmovaps [rsp+0xE0], xmm14
000071709abd387e  sub rsp, 0x30
000071709abd3882  movaps [rsp], xmm15
000071709abd3887  movaps [rsp+0x10], xmm13
000071709abd388d  movaps [rsp+0x20], xmm10
000071709abd3893  lea rdi, [rsp]
000071709abd3897  mov esi, 0x00
000071709abd389c  mov rax, 0x60B9B2ABC530
000071709abd38a6  call rax
000071709abd38a8  movaps xmm15, [rsp]
000071709abd38ad  add rsp, 0x30
000071709abd38b1  vmovaps xmm0, [rsp]
000071709abd38b6  vmovaps xmm1, [rsp+0x10]
000071709abd38bc  vmovaps xmm2, [rsp+0x20]
000071709abd38c2  vmovaps xmm3, [rsp+0x30]
000071709abd38c8  vmovaps xmm4, [rsp+0x40]
000071709abd38ce  vmovaps xmm5, [rsp+0x50]
000071709abd38d4  vmovaps xmm6, [rsp+0x60]
000071709abd38da  vmovaps xmm7, [rsp+0x70]
000071709abd38e0  vmovaps xmm8, [rsp+0x80]
000071709abd38e9  vmovaps xmm9, [rsp+0x90]
000071709abd38f2  vmovaps xmm10, [rsp+0xA0]
000071709abd38fb  vmovaps xmm11, [rsp+0xB0]
000071709abd3904  vmovaps xmm12, [rsp+0xC0]
000071709abd390d  vmovaps xmm13, [rsp+0xD0]
000071709abd3916  vmovaps xmm14, [rsp+0xE0]
000071709abd391f  add rsp, 0xF0
000071709abd3926  pop r11
000071709abd3928  pop r10
000071709abd392a  pop r9
000071709abd392c  pop r8
000071709abd392e  pop rsi
000071709abd392f  pop rdi
000071709abd3930  pop rdx
000071709abd3931  pop rcx
000071709abd3932  pop rax
000071709abd3933  add rsp, 0x08
000071709abd3937  jmp 0x000071709ABCFF55
000071709abd393c  call 0x000071709AA0C260
000071709abd3941  jmp 0x000071709ABCFFB0
000071709abd3946  sub rsp, 0x08
000071709abd394a  push rax
000071709abd394b  push rcx
000071709abd394c  push rdx
000071709abd394d  push rdi
000071709abd394e  push rsi
000071709abd394f  push r8
000071709abd3951  push r9
000071709abd3953  push r10
000071709abd3955  push r11
000071709abd3957  sub rsp, 0xF0
000071709abd395e  vmovaps [rsp], xmm0
000071709abd3963  vmovaps [rsp+0x10], xmm1
000071709abd3969  vmovaps [rsp+0x20], xmm2
000071709abd396f  vmovaps [rsp+0x30], xmm3
000071709abd3975  vmovaps [rsp+0x40], xmm4
000071709abd397b  vmovaps [rsp+0x50], xmm5
000071709abd3981  vmovaps [rsp+0x60], xmm6
000071709abd3987  vmovaps [rsp+0x70], xmm7
000071709abd398d  vmovaps [rsp+0x80], xmm8
000071709abd3996  vmovaps [rsp+0x90], xmm10
000071709abd399f  vmovaps [rsp+0xA0], xmm11
000071709abd39a8  vmovaps [rsp+0xB0], xmm12
000071709abd39b1  vmovaps [rsp+0xC0], xmm13
000071709abd39ba  vmovaps [rsp+0xD0], xmm14
000071709abd39c3  vmovaps [rsp+0xE0], xmm15
000071709abd39cc  sub rsp, 0x30
000071709abd39d0  movaps [rsp], xmm9
000071709abd39d5  movaps [rsp+0x10], xmm8
000071709abd39db  movaps [rsp+0x20], xmm10
000071709abd39e1  lea rdi, [rsp]
000071709abd39e5  mov esi, 0x00
000071709abd39ea  mov rax, 0x60B9B2ABC530
000071709abd39f4  call rax
000071709abd39f6  movaps xmm9, [rsp]
000071709abd39fb  add rsp, 0x30
000071709abd39ff  vmovaps xmm0, [rsp]
000071709abd3a04  vmovaps xmm1, [rsp+0x10]
000071709abd3a0a  vmovaps xmm2, [rsp+0x20]
000071709abd3a10  vmovaps xmm3, [rsp+0x30]
000071709abd3a16  vmovaps xmm4, [rsp+0x40]
000071709abd3a1c  vmovaps xmm5, [rsp+0x50]
000071709abd3a22  vmovaps xmm6, [rsp+0x60]
000071709abd3a28  vmovaps xmm7, [rsp+0x70]
000071709abd3a2e  vmovaps xmm8, [rsp+0x80]
000071709abd3a37  vmovaps xmm10, [rsp+0x90]
000071709abd3a40  vmovaps xmm11, [rsp+0xA0]
000071709abd3a49  vmovaps xmm12, [rsp+0xB0]
000071709abd3a52  vmovaps xmm13, [rsp+0xC0]
000071709abd3a5b  vmovaps xmm14, [rsp+0xD0]
000071709abd3a64  vmovaps xmm15, [rsp+0xE0]
000071709abd3a6d  add rsp, 0xF0
000071709abd3a74  pop r11
000071709abd3a76  pop r10
000071709abd3a78  pop r9
000071709abd3a7a  pop r8
000071709abd3a7c  pop rsi
000071709abd3a7d  pop rdi
000071709abd3a7e  pop rdx
000071709abd3a7f  pop rcx
000071709abd3a80  pop rax
000071709abd3a81  add rsp, 0x08
000071709abd3a85  jmp 0x000071709ABCFFE1
000071709abd3a8a  sub rsp, 0x08
000071709abd3a8e  push rax
000071709abd3a8f  push rcx
000071709abd3a90  push rdx
000071709abd3a91  push rdi
000071709abd3a92  push rsi
000071709abd3a93  push r8
000071709abd3a95  push r9
000071709abd3a97  push r10
000071709abd3a99  push r11
000071709abd3a9b  sub rsp, 0xF0
000071709abd3aa2  vmovaps [rsp], xmm0
000071709abd3aa7  vmovaps [rsp+0x10], xmm1
000071709abd3aad  vmovaps [rsp+0x20], xmm2
000071709abd3ab3  vmovaps [rsp+0x30], xmm3
000071709abd3ab9  vmovaps [rsp+0x40], xmm4
000071709abd3abf  vmovaps [rsp+0x50], xmm5
000071709abd3ac5  vmovaps [rsp+0x60], xmm6
000071709abd3acb  vmovaps [rsp+0x70], xmm7
000071709abd3ad1  vmovaps [rsp+0x80], xmm8
000071709abd3ada  vmovaps [rsp+0x90], xmm9
000071709abd3ae3  vmovaps [rsp+0xA0], xmm11
000071709abd3aec  vmovaps [rsp+0xB0], xmm12
000071709abd3af5  vmovaps [rsp+0xC0], xmm13
000071709abd3afe  vmovaps [rsp+0xD0], xmm14
000071709abd3b07  vmovaps [rsp+0xE0], xmm15
000071709abd3b10  sub rsp, 0x30
000071709abd3b14  movaps [rsp], xmm10
000071709abd3b19  movaps [rsp+0x10], xmm1
000071709abd3b1e  movaps [rsp+0x20], xmm11
000071709abd3b24  lea rdi, [rsp]
000071709abd3b28  mov esi, 0x00
000071709abd3b2d  mov rax, 0x60B9B2ABC530
000071709abd3b37  call rax
000071709abd3b39  movaps xmm10, [rsp]
000071709abd3b3e  add rsp, 0x30
000071709abd3b42  vmovaps xmm0, [rsp]
000071709abd3b47  vmovaps xmm1, [rsp+0x10]
000071709abd3b4d  vmovaps xmm2, [rsp+0x20]
000071709abd3b53  vmovaps xmm3, [rsp+0x30]
000071709abd3b59  vmovaps xmm4, [rsp+0x40]
000071709abd3b5f  vmovaps xmm5, [rsp+0x50]
000071709abd3b65  vmovaps xmm6, [rsp+0x60]
000071709abd3b6b  vmovaps xmm7, [rsp+0x70]
000071709abd3b71  vmovaps xmm8, [rsp+0x80]
000071709abd3b7a  vmovaps xmm9, [rsp+0x90]
000071709abd3b83  vmovaps xmm11, [rsp+0xA0]
000071709abd3b8c  vmovaps xmm12, [rsp+0xB0]
000071709abd3b95  vmovaps xmm13, [rsp+0xC0]
000071709abd3b9e  vmovaps xmm14, [rsp+0xD0]
000071709abd3ba7  vmovaps xmm15, [rsp+0xE0]
000071709abd3bb0  add rsp, 0xF0
000071709abd3bb7  pop r11
000071709abd3bb9  pop r10
000071709abd3bbb  pop r9
000071709abd3bbd  pop r8
000071709abd3bbf  pop rsi
000071709abd3bc0  pop rdi
000071709abd3bc1  pop rdx
000071709abd3bc2  pop rcx
000071709abd3bc3  pop rax
000071709abd3bc4  add rsp, 0x08
000071709abd3bc8  jmp 0x000071709ABCFFFC
000071709abd3bcd  sub rsp, 0x08
000071709abd3bd1  push rax
000071709abd3bd2  push rcx
000071709abd3bd3  push rdx
000071709abd3bd4  push rdi
000071709abd3bd5  push rsi
000071709abd3bd6  push r8
000071709abd3bd8  push r9
000071709abd3bda  push r10
000071709abd3bdc  push r11
000071709abd3bde  sub rsp, 0xF0
000071709abd3be5  vmovaps [rsp], xmm0
000071709abd3bea  vmovaps [rsp+0x10], xmm2
000071709abd3bf0  vmovaps [rsp+0x20], xmm3
000071709abd3bf6  vmovaps [rsp+0x30], xmm4
000071709abd3bfc  vmovaps [rsp+0x40], xmm5
000071709abd3c02  vmovaps [rsp+0x50], xmm6
000071709abd3c08  vmovaps [rsp+0x60], xmm7
000071709abd3c0e  vmovaps [rsp+0x70], xmm8
000071709abd3c14  vmovaps [rsp+0x80], xmm9
000071709abd3c1d  vmovaps [rsp+0x90], xmm10
000071709abd3c26  vmovaps [rsp+0xA0], xmm11
000071709abd3c2f  vmovaps [rsp+0xB0], xmm12
000071709abd3c38  vmovaps [rsp+0xC0], xmm13
000071709abd3c41  vmovaps [rsp+0xD0], xmm14
000071709abd3c4a  vmovaps [rsp+0xE0], xmm15
000071709abd3c53  sub rsp, 0x30
000071709abd3c57  movaps [rsp], xmm1
000071709abd3c5b  movaps [rsp+0x10], xmm14
000071709abd3c61  movaps [rsp+0x20], xmm6
000071709abd3c66  lea rdi, [rsp]
000071709abd3c6a  mov esi, 0x00
000071709abd3c6f  mov rax, 0x60B9B2ABC530
000071709abd3c79  call rax
000071709abd3c7b  movaps xmm1, [rsp]
000071709abd3c7f  add rsp, 0x30
000071709abd3c83  vmovaps xmm0, [rsp]
000071709abd3c88  vmovaps xmm2, [rsp+0x10]
000071709abd3c8e  vmovaps xmm3, [rsp+0x20]
000071709abd3c94  vmovaps xmm4, [rsp+0x30]
000071709abd3c9a  vmovaps xmm5, [rsp+0x40]
000071709abd3ca0  vmovaps xmm6, [rsp+0x50]
000071709abd3ca6  vmovaps xmm7, [rsp+0x60]
000071709abd3cac  vmovaps xmm8, [rsp+0x70]
000071709abd3cb2  vmovaps xmm9, [rsp+0x80]
000071709abd3cbb  vmovaps xmm10, [rsp+0x90]
000071709abd3cc4  vmovaps xmm11, [rsp+0xA0]
000071709abd3ccd  vmovaps xmm12, [rsp+0xB0]
000071709abd3cd6  vmovaps xmm13, [rsp+0xC0]
000071709abd3cdf  vmovaps xmm14, [rsp+0xD0]
000071709abd3ce8  vmovaps xmm15, [rsp+0xE0]
000071709abd3cf1  add rsp, 0xF0
000071709abd3cf8  pop r11
000071709abd3cfa  pop r10
000071709abd3cfc  pop r9
000071709abd3cfe  pop r8
000071709abd3d00  pop rsi
000071709abd3d01  pop rdi
000071709abd3d02  pop rdx
000071709abd3d03  pop rcx
000071709abd3d04  pop rax
000071709abd3d05  add rsp, 0x08
000071709abd3d09  jmp 0x000071709ABD0015
000071709abd3d0e  sub rsp, 0x08
000071709abd3d12  push rax
000071709abd3d13  push rcx
000071709abd3d14  push rdx
000071709abd3d15  push rdi
000071709abd3d16  push rsi
000071709abd3d17  push r8
000071709abd3d19  push r9
000071709abd3d1b  push r10
000071709abd3d1d  push r11
000071709abd3d1f  sub rsp, 0xF0
000071709abd3d26  vmovaps [rsp], xmm0
000071709abd3d2b  vmovaps [rsp+0x10], xmm1
000071709abd3d31  vmovaps [rsp+0x20], xmm2
000071709abd3d37  vmovaps [rsp+0x30], xmm3
000071709abd3d3d  vmovaps [rsp+0x40], xmm4
000071709abd3d43  vmovaps [rsp+0x50], xmm5
000071709abd3d49  vmovaps [rsp+0x60], xmm6
000071709abd3d4f  vmovaps [rsp+0x70], xmm7
000071709abd3d55  vmovaps [rsp+0x80], xmm8
000071709abd3d5e  vmovaps [rsp+0x90], xmm9
000071709abd3d67  vmovaps [rsp+0xA0], xmm10
000071709abd3d70  vmovaps [rsp+0xB0], xmm12
000071709abd3d79  vmovaps [rsp+0xC0], xmm13
000071709abd3d82  vmovaps [rsp+0xD0], xmm14
000071709abd3d8b  vmovaps [rsp+0xE0], xmm15
000071709abd3d94  sub rsp, 0x30
000071709abd3d98  movaps [rsp], xmm11
000071709abd3d9d  movaps [rsp+0x10], xmm13
000071709abd3da3  movaps [rsp+0x20], xmm14
000071709abd3da9  lea rdi, [rsp]
000071709abd3dad  mov esi, 0x00
000071709abd3db2  mov rax, 0x60B9B2ABC530
000071709abd3dbc  call rax
000071709abd3dbe  movaps xmm11, [rsp]
000071709abd3dc3  add rsp, 0x30
000071709abd3dc7  vmovaps xmm0, [rsp]
000071709abd3dcc  vmovaps xmm1, [rsp+0x10]
000071709abd3dd2  vmovaps xmm2, [rsp+0x20]
000071709abd3dd8  vmovaps xmm3, [rsp+0x30]
000071709abd3dde  vmovaps xmm4, [rsp+0x40]
000071709abd3de4  vmovaps xmm5, [rsp+0x50]
000071709abd3dea  vmovaps xmm6, [rsp+0x60]
000071709abd3df0  vmovaps xmm7, [rsp+0x70]
000071709abd3df6  vmovaps xmm8, [rsp+0x80]
000071709abd3dff  vmovaps xmm9, [rsp+0x90]
000071709abd3e08  vmovaps xmm10, [rsp+0xA0]
000071709abd3e11  vmovaps xmm12, [rsp+0xB0]
000071709abd3e1a  vmovaps xmm13, [rsp+0xC0]
000071709abd3e23  vmovaps xmm14, [rsp+0xD0]
000071709abd3e2c  vmovaps xmm15, [rsp+0xE0]
000071709abd3e35  add rsp, 0xF0
000071709abd3e3c  pop r11
000071709abd3e3e  pop r10
000071709abd3e40  pop r9
000071709abd3e42  pop r8
000071709abd3e44  pop rsi
000071709abd3e45  pop rdi
000071709abd3e46  pop rdx
000071709abd3e47  pop rcx
000071709abd3e48  pop rax
000071709abd3e49  add rsp, 0x08
000071709abd3e4d  jmp 0x000071709ABD003F
000071709abd3e52  sub rsp, 0x08
000071709abd3e56  push rax
000071709abd3e57  push rcx
000071709abd3e58  push rdx
000071709abd3e59  push rdi
000071709abd3e5a  push rsi
000071709abd3e5b  push r8
000071709abd3e5d  push r9
000071709abd3e5f  push r10
000071709abd3e61  push r11
000071709abd3e63  sub rsp, 0xF0
000071709abd3e6a  vmovaps [rsp], xmm0
000071709abd3e6f  vmovaps [rsp+0x10], xmm1
000071709abd3e75  vmovaps [rsp+0x20], xmm2
000071709abd3e7b  vmovaps [rsp+0x30], xmm3
000071709abd3e81  vmovaps [rsp+0x40], xmm4
000071709abd3e87  vmovaps [rsp+0x50], xmm5
000071709abd3e8d  vmovaps [rsp+0x60], xmm6
000071709abd3e93  vmovaps [rsp+0x70], xmm7
000071709abd3e99  vmovaps [rsp+0x80], xmm8
000071709abd3ea2  vmovaps [rsp+0x90], xmm9
000071709abd3eab  vmovaps [rsp+0xA0], xmm10
000071709abd3eb4  vmovaps [rsp+0xB0], xmm11
000071709abd3ebd  vmovaps [rsp+0xC0], xmm12
000071709abd3ec6  vmovaps [rsp+0xD0], xmm14
000071709abd3ecf  vmovaps [rsp+0xE0], xmm15
000071709abd3ed8  sub rsp, 0x30
000071709abd3edc  movaps [rsp], xmm13
000071709abd3ee1  movaps [rsp+0x10], xmm8
000071709abd3ee7  movaps [rsp+0x20], xmm14
000071709abd3eed  lea rdi, [rsp]
000071709abd3ef1  mov esi, 0x00
000071709abd3ef6  mov rax, 0x60B9B2ABC530
000071709abd3f00  call rax
000071709abd3f02  movaps xmm13, [rsp]
000071709abd3f07  add rsp, 0x30
000071709abd3f0b  vmovaps xmm0, [rsp]
000071709abd3f10  vmovaps xmm1, [rsp+0x10]
000071709abd3f16  vmovaps xmm2, [rsp+0x20]
000071709abd3f1c  vmovaps xmm3, [rsp+0x30]
000071709abd3f22  vmovaps xmm4, [rsp+0x40]
000071709abd3f28  vmovaps xmm5, [rsp+0x50]
000071709abd3f2e  vmovaps xmm6, [rsp+0x60]
000071709abd3f34  vmovaps xmm7, [rsp+0x70]
000071709abd3f3a  vmovaps xmm8, [rsp+0x80]
000071709abd3f43  vmovaps xmm9, [rsp+0x90]
000071709abd3f4c  vmovaps xmm10, [rsp+0xA0]
000071709abd3f55  vmovaps xmm11, [rsp+0xB0]
000071709abd3f5e  vmovaps xmm12, [rsp+0xC0]
000071709abd3f67  vmovaps xmm14, [rsp+0xD0]
000071709abd3f70  vmovaps xmm15, [rsp+0xE0]
000071709abd3f79  add rsp, 0xF0
000071709abd3f80  pop r11
000071709abd3f82  pop r10
000071709abd3f84  pop r9
000071709abd3f86  pop r8
000071709abd3f88  pop rsi
000071709abd3f89  pop rdi
000071709abd3f8a  pop rdx
000071709abd3f8b  pop rcx
000071709abd3f8c  pop rax
000071709abd3f8d  add rsp, 0x08
000071709abd3f91  jmp 0x000071709ABD006E
000071709abd3f96  sub rsp, 0x08
000071709abd3f9a  push rax
000071709abd3f9b  push rcx
000071709abd3f9c  push rdx
000071709abd3f9d  push rdi
000071709abd3f9e  push rsi
000071709abd3f9f  push r8
000071709abd3fa1  push r9
000071709abd3fa3  push r10
000071709abd3fa5  push r11
000071709abd3fa7  sub rsp, 0xF0
000071709abd3fae  vmovaps [rsp], xmm0
000071709abd3fb3  vmovaps [rsp+0x10], xmm1
000071709abd3fb9  vmovaps [rsp+0x20], xmm2
000071709abd3fbf  vmovaps [rsp+0x30], xmm3
000071709abd3fc5  vmovaps [rsp+0x40], xmm4
000071709abd3fcb  vmovaps [rsp+0x50], xmm5
000071709abd3fd1  vmovaps [rsp+0x60], xmm6
000071709abd3fd7  vmovaps [rsp+0x70], xmm7
000071709abd3fdd  vmovaps [rsp+0x80], xmm9
000071709abd3fe6  vmovaps [rsp+0x90], xmm10
000071709abd3fef  vmovaps [rsp+0xA0], xmm11
000071709abd3ff8  vmovaps [rsp+0xB0], xmm12
000071709abd4001  vmovaps [rsp+0xC0], xmm13
000071709abd400a  vmovaps [rsp+0xD0], xmm14
000071709abd4013  vmovaps [rsp+0xE0], xmm15
000071709abd401c  sub rsp, 0x30
000071709abd4020  movaps [rsp], xmm8
000071709abd4025  movaps [rsp+0x10], xmm7
000071709abd402a  movaps [rsp+0x20], xmm14
000071709abd4030  lea rdi, [rsp]
000071709abd4034  mov esi, 0x00
000071709abd4039  mov rax, 0x60B9B2ABC530
000071709abd4043  call rax
000071709abd4045  movaps xmm8, [rsp]
000071709abd404a  add rsp, 0x30
000071709abd404e  vmovaps xmm0, [rsp]
000071709abd4053  vmovaps xmm1, [rsp+0x10]
000071709abd4059  vmovaps xmm2, [rsp+0x20]
000071709abd405f  vmovaps xmm3, [rsp+0x30]
000071709abd4065  vmovaps xmm4, [rsp+0x40]
000071709abd406b  vmovaps xmm5, [rsp+0x50]
000071709abd4071  vmovaps xmm6, [rsp+0x60]
000071709abd4077  vmovaps xmm7, [rsp+0x70]
000071709abd407d  vmovaps xmm9, [rsp+0x80]
000071709abd4086  vmovaps xmm10, [rsp+0x90]
000071709abd408f  vmovaps xmm11, [rsp+0xA0]
000071709abd4098  vmovaps xmm12, [rsp+0xB0]
000071709abd40a1  vmovaps xmm13, [rsp+0xC0]
000071709abd40aa  vmovaps xmm14, [rsp+0xD0]
000071709abd40b3  vmovaps xmm15, [rsp+0xE0]
000071709abd40bc  add rsp, 0xF0
000071709abd40c3  pop r11
000071709abd40c5  pop r10
000071709abd40c7  pop r9
000071709abd40c9  pop r8
000071709abd40cb  pop rsi
000071709abd40cc  pop rdi
000071709abd40cd  pop rdx
000071709abd40ce  pop rcx
000071709abd40cf  pop rax
000071709abd40d0  add rsp, 0x08
000071709abd40d4  jmp 0x000071709ABD0094
000071709abd40d9  sub rsp, 0x08
000071709abd40dd  push rax
000071709abd40de  push rcx
000071709abd40df  push rdx
000071709abd40e0  push rdi
000071709abd40e1  push rsi
000071709abd40e2  push r8
000071709abd40e4  push r9
000071709abd40e6  push r10
000071709abd40e8  push r11
000071709abd40ea  sub rsp, 0xF0
000071709abd40f1  vmovaps [rsp], xmm0
000071709abd40f6  vmovaps [rsp+0x10], xmm1
000071709abd40fc  vmovaps [rsp+0x20], xmm2
000071709abd4102  vmovaps [rsp+0x30], xmm3
000071709abd4108  vmovaps [rsp+0x40], xmm4
000071709abd410e  vmovaps [rsp+0x50], xmm5
000071709abd4114  vmovaps [rsp+0x60], xmm6
000071709abd411a  vmovaps [rsp+0x70], xmm7
000071709abd4120  vmovaps [rsp+0x80], xmm8
000071709abd4129  vmovaps [rsp+0x90], xmm9
000071709abd4132  vmovaps [rsp+0xA0], xmm10
000071709abd413b  vmovaps [rsp+0xB0], xmm11
000071709abd4144  vmovaps [rsp+0xC0], xmm12
000071709abd414d  vmovaps [rsp+0xD0], xmm13
000071709abd4156  vmovaps [rsp+0xE0], xmm15
000071709abd415f  sub rsp, 0x30
000071709abd4163  movaps [rsp], xmm14
000071709abd4168  movaps [rsp+0x10], xmm12
000071709abd416e  movaps [rsp+0x20], xmm9
000071709abd4174  lea rdi, [rsp]
000071709abd4178  mov esi, 0x00
000071709abd417d  mov rax, 0x60B9B2ABC530
000071709abd4187  call rax
000071709abd4189  movaps xmm14, [rsp]
000071709abd418e  add rsp, 0x30
000071709abd4192  vmovaps xmm0, [rsp]
000071709abd4197  vmovaps xmm1, [rsp+0x10]
000071709abd419d  vmovaps xmm2, [rsp+0x20]
000071709abd41a3  vmovaps xmm3, [rsp+0x30]
000071709abd41a9  vmovaps xmm4, [rsp+0x40]
000071709abd41af  vmovaps xmm5, [rsp+0x50]
000071709abd41b5  vmovaps xmm6, [rsp+0x60]
000071709abd41bb  vmovaps xmm7, [rsp+0x70]
000071709abd41c1  vmovaps xmm8, [rsp+0x80]
000071709abd41ca  vmovaps xmm9, [rsp+0x90]
000071709abd41d3  vmovaps xmm10, [rsp+0xA0]
000071709abd41dc  vmovaps xmm11, [rsp+0xB0]
000071709abd41e5  vmovaps xmm12, [rsp+0xC0]
000071709abd41ee  vmovaps xmm13, [rsp+0xD0]
000071709abd41f7  vmovaps xmm15, [rsp+0xE0]
000071709abd4200  add rsp, 0xF0
000071709abd4207  pop r11
000071709abd4209  pop r10
000071709abd420b  pop r9
000071709abd420d  pop r8
000071709abd420f  pop rsi
000071709abd4210  pop rdi
000071709abd4211  pop rdx
000071709abd4212  pop rcx
000071709abd4213  pop rax
000071709abd4214  add rsp, 0x08
000071709abd4218  jmp 0x000071709ABD00AE
000071709abd421d  sub rsp, 0x08
000071709abd4221  push rax
000071709abd4222  push rcx
000071709abd4223  push rdx
000071709abd4224  push rdi
000071709abd4225  push rsi
000071709abd4226  push r8
000071709abd4228  push r9
000071709abd422a  push r10
000071709abd422c  push r11
000071709abd422e  sub rsp, 0xF0
000071709abd4235  vmovaps [rsp], xmm0
000071709abd423a  vmovaps [rsp+0x10], xmm1
000071709abd4240  vmovaps [rsp+0x20], xmm2
000071709abd4246  vmovaps [rsp+0x30], xmm3
000071709abd424c  vmovaps [rsp+0x40], xmm4
000071709abd4252  vmovaps [rsp+0x50], xmm5
000071709abd4258  vmovaps [rsp+0x60], xmm6
000071709abd425e  vmovaps [rsp+0x70], xmm7
000071709abd4264  vmovaps [rsp+0x80], xmm8
000071709abd426d  vmovaps [rsp+0x90], xmm10
000071709abd4276  vmovaps [rsp+0xA0], xmm11
000071709abd427f  vmovaps [rsp+0xB0], xmm12
000071709abd4288  vmovaps [rsp+0xC0], xmm13
000071709abd4291  vmovaps [rsp+0xD0], xmm14
000071709abd429a  vmovaps [rsp+0xE0], xmm15
000071709abd42a3  sub rsp, 0x30
000071709abd42a7  movaps [rsp], xmm9
000071709abd42ac  movaps [rsp+0x10], xmm7
000071709abd42b1  movaps [rsp+0x20], xmm12
000071709abd42b7  lea rdi, [rsp]
000071709abd42bb  mov esi, 0x00
000071709abd42c0  mov rax, 0x60B9B2ABC530
000071709abd42ca  call rax
000071709abd42cc  movaps xmm9, [rsp]
000071709abd42d1  add rsp, 0x30
000071709abd42d5  vmovaps xmm0, [rsp]
000071709abd42da  vmovaps xmm1, [rsp+0x10]
000071709abd42e0  vmovaps xmm2, [rsp+0x20]
000071709abd42e6  vmovaps xmm3, [rsp+0x30]
000071709abd42ec  vmovaps xmm4, [rsp+0x40]
000071709abd42f2  vmovaps xmm5, [rsp+0x50]
000071709abd42f8  vmovaps xmm6, [rsp+0x60]
000071709abd42fe  vmovaps xmm7, [rsp+0x70]
000071709abd4304  vmovaps xmm8, [rsp+0x80]
000071709abd430d  vmovaps xmm10, [rsp+0x90]
000071709abd4316  vmovaps xmm11, [rsp+0xA0]
000071709abd431f  vmovaps xmm12, [rsp+0xB0]
000071709abd4328  vmovaps xmm13, [rsp+0xC0]
000071709abd4331  vmovaps xmm14, [rsp+0xD0]
000071709abd433a  vmovaps xmm15, [rsp+0xE0]
000071709abd4343  add rsp, 0xF0
000071709abd434a  pop r11
000071709abd434c  pop r10
000071709abd434e  pop r9
000071709abd4350  pop r8
000071709abd4352  pop rsi
000071709abd4353  pop rdi
000071709abd4354  pop rdx
000071709abd4355  pop rcx
000071709abd4356  pop rax
000071709abd4357  add rsp, 0x08
000071709abd435b  jmp 0x000071709ABD00DD
000071709abd4360  sub rsp, 0x08
000071709abd4364  push rax
000071709abd4365  push rcx
000071709abd4366  push rdx
000071709abd4367  push rdi
000071709abd4368  push rsi
000071709abd4369  push r8
000071709abd436b  push r9
000071709abd436d  push r10
000071709abd436f  push r11
000071709abd4371  sub rsp, 0xF0
000071709abd4378  vmovaps [rsp], xmm0
000071709abd437d  vmovaps [rsp+0x10], xmm1
000071709abd4383  vmovaps [rsp+0x20], xmm2
000071709abd4389  vmovaps [rsp+0x30], xmm3
000071709abd438f  vmovaps [rsp+0x40], xmm4
000071709abd4395  vmovaps [rsp+0x50], xmm5
000071709abd439b  vmovaps [rsp+0x60], xmm6
000071709abd43a1  vmovaps [rsp+0x70], xmm7
000071709abd43a7  vmovaps [rsp+0x80], xmm8
000071709abd43b0  vmovaps [rsp+0x90], xmm9
000071709abd43b9  vmovaps [rsp+0xA0], xmm10
000071709abd43c2  vmovaps [rsp+0xB0], xmm11
000071709abd43cb  vmovaps [rsp+0xC0], xmm13
000071709abd43d4  vmovaps [rsp+0xD0], xmm14
000071709abd43dd  vmovaps [rsp+0xE0], xmm15
000071709abd43e6  sub rsp, 0x30
000071709abd43ea  movaps [rsp], xmm12
000071709abd43ef  movaps [rsp+0x10], xmm15
000071709abd43f5  movaps [rsp+0x20], xmm11
000071709abd43fb  lea rdi, [rsp]
000071709abd43ff  mov esi, 0x00
000071709abd4404  mov rax, 0x60B9B2ABC530
000071709abd440e  call rax
000071709abd4410  movaps xmm12, [rsp]
000071709abd4415  add rsp, 0x30
000071709abd4419  vmovaps xmm0, [rsp]
000071709abd441e  vmovaps xmm1, [rsp+0x10]
000071709abd4424  vmovaps xmm2, [rsp+0x20]
000071709abd442a  vmovaps xmm3, [rsp+0x30]
000071709abd4430  vmovaps xmm4, [rsp+0x40]
000071709abd4436  vmovaps xmm5, [rsp+0x50]
000071709abd443c  vmovaps xmm6, [rsp+0x60]
000071709abd4442  vmovaps xmm7, [rsp+0x70]
000071709abd4448  vmovaps xmm8, [rsp+0x80]
000071709abd4451  vmovaps xmm9, [rsp+0x90]
000071709abd445a  vmovaps xmm10, [rsp+0xA0]
000071709abd4463  vmovaps xmm11, [rsp+0xB0]
000071709abd446c  vmovaps xmm13, [rsp+0xC0]
000071709abd4475  vmovaps xmm14, [rsp+0xD0]
000071709abd447e  vmovaps xmm15, [rsp+0xE0]
000071709abd4487  add rsp, 0xF0
000071709abd448e  pop r11
000071709abd4490  pop r10
000071709abd4492  pop r9
000071709abd4494  pop r8
000071709abd4496  pop rsi
000071709abd4497  pop rdi
000071709abd4498  pop rdx
000071709abd4499  pop rcx
000071709abd449a  pop rax
000071709abd449b  add rsp, 0x08
000071709abd449f  jmp 0x000071709ABD00F7
000071709abd44a4  sub rsp, 0x08
000071709abd44a8  push rax
000071709abd44a9  push rcx
000071709abd44aa  push rdx
000071709abd44ab  push rdi
000071709abd44ac  push rsi
000071709abd44ad  push r8
000071709abd44af  push r9
000071709abd44b1  push r10
000071709abd44b3  push r11
000071709abd44b5  sub rsp, 0xF0
000071709abd44bc  vmovaps [rsp], xmm0
000071709abd44c1  vmovaps [rsp+0x10], xmm1
000071709abd44c7  vmovaps [rsp+0x20], xmm2
000071709abd44cd  vmovaps [rsp+0x30], xmm3
000071709abd44d3  vmovaps [rsp+0x40], xmm4
000071709abd44d9  vmovaps [rsp+0x50], xmm5
000071709abd44df  vmovaps [rsp+0x60], xmm6
000071709abd44e5  vmovaps [rsp+0x70], xmm7
000071709abd44eb  vmovaps [rsp+0x80], xmm8
000071709abd44f4  vmovaps [rsp+0x90], xmm9
000071709abd44fd  vmovaps [rsp+0xA0], xmm10
000071709abd4506  vmovaps [rsp+0xB0], xmm12
000071709abd450f  vmovaps [rsp+0xC0], xmm13
000071709abd4518  vmovaps [rsp+0xD0], xmm14
000071709abd4521  vmovaps [rsp+0xE0], xmm15
000071709abd452a  sub rsp, 0x30
000071709abd452e  movaps [rsp], xmm11
000071709abd4533  movaps [rsp+0x10], xmm7
000071709abd4538  movaps [rsp+0x20], xmm15
000071709abd453e  lea rdi, [rsp]
000071709abd4542  mov esi, 0x00
000071709abd4547  mov rax, 0x60B9B2ABC530
000071709abd4551  call rax
000071709abd4553  movaps xmm11, [rsp]
000071709abd4558  add rsp, 0x30
000071709abd455c  vmovaps xmm0, [rsp]
000071709abd4561  vmovaps xmm1, [rsp+0x10]
000071709abd4567  vmovaps xmm2, [rsp+0x20]
000071709abd456d  vmovaps xmm3, [rsp+0x30]
000071709abd4573  vmovaps xmm4, [rsp+0x40]
000071709abd4579  vmovaps xmm5, [rsp+0x50]
000071709abd457f  vmovaps xmm6, [rsp+0x60]
000071709abd4585  vmovaps xmm7, [rsp+0x70]
000071709abd458b  vmovaps xmm8, [rsp+0x80]
000071709abd4594  vmovaps xmm9, [rsp+0x90]
000071709abd459d  vmovaps xmm10, [rsp+0xA0]
000071709abd45a6  vmovaps xmm12, [rsp+0xB0]
000071709abd45af  vmovaps xmm13, [rsp+0xC0]
000071709abd45b8  vmovaps xmm14, [rsp+0xD0]
000071709abd45c1  vmovaps xmm15, [rsp+0xE0]
000071709abd45ca  add rsp, 0xF0
000071709abd45d1  pop r11
000071709abd45d3  pop r10
000071709abd45d5  pop r9
000071709abd45d7  pop r8
000071709abd45d9  pop rsi
000071709abd45da  pop rdi
000071709abd45db  pop rdx
000071709abd45dc  pop rcx
000071709abd45dd  pop rax
000071709abd45de  add rsp, 0x08
000071709abd45e2  jmp 0x000071709ABD0123
000071709abd45e7  sub rsp, 0x08
000071709abd45eb  push rax
000071709abd45ec  push rcx
000071709abd45ed  push rdx
000071709abd45ee  push rdi
000071709abd45ef  push rsi
000071709abd45f0  push r8
000071709abd45f2  push r9
000071709abd45f4  push r10
000071709abd45f6  push r11
000071709abd45f8  sub rsp, 0xF0
000071709abd45ff  vmovaps [rsp], xmm0
000071709abd4604  vmovaps [rsp+0x10], xmm1
000071709abd460a  vmovaps [rsp+0x20], xmm2
000071709abd4610  vmovaps [rsp+0x30], xmm3
000071709abd4616  vmovaps [rsp+0x40], xmm4
000071709abd461c  vmovaps [rsp+0x50], xmm5
000071709abd4622  vmovaps [rsp+0x60], xmm6
000071709abd4628  vmovaps [rsp+0x70], xmm7
000071709abd462e  vmovaps [rsp+0x80], xmm8
000071709abd4637  vmovaps [rsp+0x90], xmm9
000071709abd4640  vmovaps [rsp+0xA0], xmm10
000071709abd4649  vmovaps [rsp+0xB0], xmm11
000071709abd4652  vmovaps [rsp+0xC0], xmm12
000071709abd465b  vmovaps [rsp+0xD0], xmm13
000071709abd4664  vmovaps [rsp+0xE0], xmm14
000071709abd466d  sub rsp, 0x30
000071709abd4671  movaps [rsp], xmm15
000071709abd4676  movaps [rsp+0x10], xmm10
000071709abd467c  movaps [rsp+0x20], xmm13
000071709abd4682  lea rdi, [rsp]
000071709abd4686  mov esi, 0x00
000071709abd468b  mov rax, 0x60B9B2ABC530
000071709abd4695  call rax
000071709abd4697  movaps xmm15, [rsp]
000071709abd469c  add rsp, 0x30
000071709abd46a0  vmovaps xmm0, [rsp]
000071709abd46a5  vmovaps xmm1, [rsp+0x10]
000071709abd46ab  vmovaps xmm2, [rsp+0x20]
000071709abd46b1  vmovaps xmm3, [rsp+0x30]
000071709abd46b7  vmovaps xmm4, [rsp+0x40]
000071709abd46bd  vmovaps xmm5, [rsp+0x50]
000071709abd46c3  vmovaps xmm6, [rsp+0x60]
000071709abd46c9  vmovaps xmm7, [rsp+0x70]
000071709abd46cf  vmovaps xmm8, [rsp+0x80]
000071709abd46d8  vmovaps xmm9, [rsp+0x90]
000071709abd46e1  vmovaps xmm10, [rsp+0xA0]
000071709abd46ea  vmovaps xmm11, [rsp+0xB0]
000071709abd46f3  vmovaps xmm12, [rsp+0xC0]
000071709abd46fc  vmovaps xmm13, [rsp+0xD0]
000071709abd4705  vmovaps xmm14, [rsp+0xE0]
000071709abd470e  add rsp, 0xF0
000071709abd4715  pop r11
000071709abd4717  pop r10
000071709abd4719  pop r9
000071709abd471b  pop r8
000071709abd471d  pop rsi
000071709abd471e  pop rdi
000071709abd471f  pop rdx
000071709abd4720  pop rcx
000071709abd4721  pop rax
000071709abd4722  add rsp, 0x08
000071709abd4726  jmp 0x000071709ABD013D
000071709abd472b  sub rsp, 0x08
000071709abd472f  push rax
000071709abd4730  push rcx
000071709abd4731  push rdx
000071709abd4732  push rdi
000071709abd4733  push rsi
000071709abd4734  push r8
000071709abd4736  push r9
000071709abd4738  push r10
000071709abd473a  push r11
000071709abd473c  sub rsp, 0xF0
000071709abd4743  vmovaps [rsp], xmm0
000071709abd4748  vmovaps [rsp+0x10], xmm1
000071709abd474e  vmovaps [rsp+0x20], xmm2
000071709abd4754  vmovaps [rsp+0x30], xmm3
000071709abd475a  vmovaps [rsp+0x40], xmm4
000071709abd4760  vmovaps [rsp+0x50], xmm5
000071709abd4766  vmovaps [rsp+0x60], xmm6
000071709abd476c  vmovaps [rsp+0x70], xmm7
000071709abd4772  vmovaps [rsp+0x80], xmm8
000071709abd477b  vmovaps [rsp+0x90], xmm9
000071709abd4784  vmovaps [rsp+0xA0], xmm11
000071709abd478d  vmovaps [rsp+0xB0], xmm12
000071709abd4796  vmovaps [rsp+0xC0], xmm13
000071709abd479f  vmovaps [rsp+0xD0], xmm14
000071709abd47a8  vmovaps [rsp+0xE0], xmm15
000071709abd47b1  sub rsp, 0x30
000071709abd47b5  movaps [rsp], xmm10
000071709abd47ba  movaps [rsp+0x10], xmm7
000071709abd47bf  movaps [rsp+0x20], xmm13
000071709abd47c5  lea rdi, [rsp]
000071709abd47c9  mov esi, 0x00
000071709abd47ce  mov rax, 0x60B9B2ABC530
000071709abd47d8  call rax
000071709abd47da  movaps xmm10, [rsp]
000071709abd47df  add rsp, 0x30
000071709abd47e3  vmovaps xmm0, [rsp]
000071709abd47e8  vmovaps xmm1, [rsp+0x10]
000071709abd47ee  vmovaps xmm2, [rsp+0x20]
000071709abd47f4  vmovaps xmm3, [rsp+0x30]
000071709abd47fa  vmovaps xmm4, [rsp+0x40]
000071709abd4800  vmovaps xmm5, [rsp+0x50]
000071709abd4806  vmovaps xmm6, [rsp+0x60]
000071709abd480c  vmovaps xmm7, [rsp+0x70]
000071709abd4812  vmovaps xmm8, [rsp+0x80]
000071709abd481b  vmovaps xmm9, [rsp+0x90]
000071709abd4824  vmovaps xmm11, [rsp+0xA0]
000071709abd482d  vmovaps xmm12, [rsp+0xB0]
000071709abd4836  vmovaps xmm13, [rsp+0xC0]
000071709abd483f  vmovaps xmm14, [rsp+0xD0]
000071709abd4848  vmovaps xmm15, [rsp+0xE0]
000071709abd4851  add rsp, 0xF0
000071709abd4858  pop r11
000071709abd485a  pop r10
000071709abd485c  pop r9
000071709abd485e  pop r8
000071709abd4860  pop rsi
000071709abd4861  pop rdi
000071709abd4862  pop rdx
000071709abd4863  pop rcx
000071709abd4864  pop rax
000071709abd4865  add rsp, 0x08
000071709abd4869  jmp 0x000071709ABD0169
000071709abd486e  sub rsp, 0x08
000071709abd4872  push rax
000071709abd4873  push rcx
000071709abd4874  push rdx
000071709abd4875  push rdi
000071709abd4876  push rsi
000071709abd4877  push r8
000071709abd4879  push r9
000071709abd487b  push r10
000071709abd487d  push r11
000071709abd487f  sub rsp, 0xF0
000071709abd4886  vmovaps [rsp], xmm0
000071709abd488b  vmovaps [rsp+0x10], xmm1
000071709abd4891  vmovaps [rsp+0x20], xmm2
000071709abd4897  vmovaps [rsp+0x30], xmm3
000071709abd489d  vmovaps [rsp+0x40], xmm4
000071709abd48a3  vmovaps [rsp+0x50], xmm5
000071709abd48a9  vmovaps [rsp+0x60], xmm6
000071709abd48af  vmovaps [rsp+0x70], xmm7
000071709abd48b5  vmovaps [rsp+0x80], xmm8
000071709abd48be  vmovaps [rsp+0x90], xmm9
000071709abd48c7  vmovaps [rsp+0xA0], xmm10
000071709abd48d0  vmovaps [rsp+0xB0], xmm11
000071709abd48d9  vmovaps [rsp+0xC0], xmm12
000071709abd48e2  vmovaps [rsp+0xD0], xmm14
000071709abd48eb  vmovaps [rsp+0xE0], xmm15
000071709abd48f4  sub rsp, 0x30
000071709abd48f8  movaps [rsp], xmm13
000071709abd48fd  movaps [rsp+0x10], xmm1
000071709abd4902  movaps [rsp+0x20], xmm8
000071709abd4908  lea rdi, [rsp]
000071709abd490c  mov esi, 0x00
000071709abd4911  mov rax, 0x60B9B2ABC530
000071709abd491b  call rax
000071709abd491d  movaps xmm13, [rsp]
000071709abd4922  add rsp, 0x30
000071709abd4926  vmovaps xmm0, [rsp]
000071709abd492b  vmovaps xmm1, [rsp+0x10]
000071709abd4931  vmovaps xmm2, [rsp+0x20]
000071709abd4937  vmovaps xmm3, [rsp+0x30]
000071709abd493d  vmovaps xmm4, [rsp+0x40]
000071709abd4943  vmovaps xmm5, [rsp+0x50]
000071709abd4949  vmovaps xmm6, [rsp+0x60]
000071709abd494f  vmovaps xmm7, [rsp+0x70]
000071709abd4955  vmovaps xmm8, [rsp+0x80]
000071709abd495e  vmovaps xmm9, [rsp+0x90]
000071709abd4967  vmovaps xmm10, [rsp+0xA0]
000071709abd4970  vmovaps xmm11, [rsp+0xB0]
000071709abd4979  vmovaps xmm12, [rsp+0xC0]
000071709abd4982  vmovaps xmm14, [rsp+0xD0]
000071709abd498b  vmovaps xmm15, [rsp+0xE0]
000071709abd4994  add rsp, 0xF0
000071709abd499b  pop r11
000071709abd499d  pop r10
000071709abd499f  pop r9
000071709abd49a1  pop r8
000071709abd49a3  pop rsi
000071709abd49a4  pop rdi
000071709abd49a5  pop rdx
000071709abd49a6  pop rcx
000071709abd49a7  pop rax
000071709abd49a8  add rsp, 0x08
000071709abd49ac  jmp 0x000071709ABD0183
000071709abd49b1  call 0x000071709A9FF430
000071709abd49b6  jmp 0x000071709ABD018D
000071709abd49bb  sub rsp, 0x08
000071709abd49bf  push rax
000071709abd49c0  push rcx
000071709abd49c1  push rdx
000071709abd49c2  push rdi
000071709abd49c3  push rsi
000071709abd49c4  push r8
000071709abd49c6  push r9
000071709abd49c8  push r10
000071709abd49ca  push r11
000071709abd49cc  sub rsp, 0xF0
000071709abd49d3  vmovaps [rsp], xmm0
000071709abd49d8  vmovaps [rsp+0x10], xmm1
000071709abd49de  vmovaps [rsp+0x20], xmm2
000071709abd49e4  vmovaps [rsp+0x30], xmm3
000071709abd49ea  vmovaps [rsp+0x40], xmm4
000071709abd49f0  vmovaps [rsp+0x50], xmm5
000071709abd49f6  vmovaps [rsp+0x60], xmm6
000071709abd49fc  vmovaps [rsp+0x70], xmm7
000071709abd4a02  vmovaps [rsp+0x80], xmm9
000071709abd4a0b  vmovaps [rsp+0x90], xmm10
000071709abd4a14  vmovaps [rsp+0xA0], xmm11
000071709abd4a1d  vmovaps [rsp+0xB0], xmm12
000071709abd4a26  vmovaps [rsp+0xC0], xmm13
000071709abd4a2f  vmovaps [rsp+0xD0], xmm14
000071709abd4a38  vmovaps [rsp+0xE0], xmm15
000071709abd4a41  sub rsp, 0x30
000071709abd4a45  movaps [rsp], xmm8
000071709abd4a4a  movaps [rsp+0x10], xmm14
000071709abd4a50  movaps [rsp+0x20], xmm9
000071709abd4a56  lea rdi, [rsp]
000071709abd4a5a  mov esi, 0x00
000071709abd4a5f  mov rax, 0x60B9B2ABC530
000071709abd4a69  call rax
000071709abd4a6b  movaps xmm8, [rsp]
000071709abd4a70  add rsp, 0x30
000071709abd4a74  vmovaps xmm0, [rsp]
000071709abd4a79  vmovaps xmm1, [rsp+0x10]
000071709abd4a7f  vmovaps xmm2, [rsp+0x20]
000071709abd4a85  vmovaps xmm3, [rsp+0x30]
000071709abd4a8b  vmovaps xmm4, [rsp+0x40]
000071709abd4a91  vmovaps xmm5, [rsp+0x50]
000071709abd4a97  vmovaps xmm6, [rsp+0x60]
000071709abd4a9d  vmovaps xmm7, [rsp+0x70]
000071709abd4aa3  vmovaps xmm9, [rsp+0x80]
000071709abd4aac  vmovaps xmm10, [rsp+0x90]
000071709abd4ab5  vmovaps xmm11, [rsp+0xA0]
000071709abd4abe  vmovaps xmm12, [rsp+0xB0]
000071709abd4ac7  vmovaps xmm13, [rsp+0xC0]
000071709abd4ad0  vmovaps xmm14, [rsp+0xD0]
000071709abd4ad9  vmovaps xmm15, [rsp+0xE0]
000071709abd4ae2  add rsp, 0xF0
000071709abd4ae9  pop r11
000071709abd4aeb  pop r10
000071709abd4aed  pop r9
000071709abd4aef  pop r8
000071709abd4af1  pop rsi
000071709abd4af2  pop rdi
000071709abd4af3  pop rdx
000071709abd4af4  pop rcx
000071709abd4af5  pop rax
000071709abd4af6  add rsp, 0x08
000071709abd4afa  jmp 0x000071709ABD01AF
000071709abd4aff  sub rsp, 0x08
000071709abd4b03  push rax
000071709abd4b04  push rcx
000071709abd4b05  push rdx
000071709abd4b06  push rdi
000071709abd4b07  push rsi
000071709abd4b08  push r8
000071709abd4b0a  push r9
000071709abd4b0c  push r10
000071709abd4b0e  push r11
000071709abd4b10  sub rsp, 0xF0
000071709abd4b17  vmovaps [rsp], xmm0
000071709abd4b1c  vmovaps [rsp+0x10], xmm1
000071709abd4b22  vmovaps [rsp+0x20], xmm2
000071709abd4b28  vmovaps [rsp+0x30], xmm3
000071709abd4b2e  vmovaps [rsp+0x40], xmm4
000071709abd4b34  vmovaps [rsp+0x50], xmm5
000071709abd4b3a  vmovaps [rsp+0x60], xmm6
000071709abd4b40  vmovaps [rsp+0x70], xmm7
000071709abd4b46  vmovaps [rsp+0x80], xmm8
000071709abd4b4f  vmovaps [rsp+0x90], xmm10
000071709abd4b58  vmovaps [rsp+0xA0], xmm11
000071709abd4b61  vmovaps [rsp+0xB0], xmm12
000071709abd4b6a  vmovaps [rsp+0xC0], xmm13
000071709abd4b73  vmovaps [rsp+0xD0], xmm14
000071709abd4b7c  vmovaps [rsp+0xE0], xmm15
000071709abd4b85  sub rsp, 0x30
000071709abd4b89  movaps [rsp], xmm9
000071709abd4b8e  movaps [rsp+0x10], xmm1
000071709abd4b93  movaps [rsp+0x20], xmm14
000071709abd4b99  lea rdi, [rsp]
000071709abd4b9d  mov esi, 0x00
000071709abd4ba2  mov rax, 0x60B9B2ABC530
000071709abd4bac  call rax
000071709abd4bae  movaps xmm9, [rsp]
000071709abd4bb3  add rsp, 0x30
000071709abd4bb7  vmovaps xmm0, [rsp]
000071709abd4bbc  vmovaps xmm1, [rsp+0x10]
000071709abd4bc2  vmovaps xmm2, [rsp+0x20]
000071709abd4bc8  vmovaps xmm3, [rsp+0x30]
000071709abd4bce  vmovaps xmm4, [rsp+0x40]
000071709abd4bd4  vmovaps xmm5, [rsp+0x50]
000071709abd4bda  vmovaps xmm6, [rsp+0x60]
000071709abd4be0  vmovaps xmm7, [rsp+0x70]
000071709abd4be6  vmovaps xmm8, [rsp+0x80]
000071709abd4bef  vmovaps xmm10, [rsp+0x90]
000071709abd4bf8  vmovaps xmm11, [rsp+0xA0]
000071709abd4c01  vmovaps xmm12, [rsp+0xB0]
000071709abd4c0a  vmovaps xmm13, [rsp+0xC0]
000071709abd4c13  vmovaps xmm14, [rsp+0xD0]
000071709abd4c1c  vmovaps xmm15, [rsp+0xE0]
000071709abd4c25  add rsp, 0xF0
000071709abd4c2c  pop r11
000071709abd4c2e  pop r10
000071709abd4c30  pop r9
000071709abd4c32  pop r8
000071709abd4c34  pop rsi
000071709abd4c35  pop rdi
000071709abd4c36  pop rdx
000071709abd4c37  pop rcx
000071709abd4c38  pop rax
000071709abd4c39  add rsp, 0x08
000071709abd4c3d  jmp 0x000071709ABD01DD
000071709abd4c42  sub rsp, 0x08
000071709abd4c46  push rax
000071709abd4c47  push rcx
000071709abd4c48  push rdx
000071709abd4c49  push rdi
000071709abd4c4a  push rsi
000071709abd4c4b  push r8
000071709abd4c4d  push r9
000071709abd4c4f  push r10
000071709abd4c51  push r11
000071709abd4c53  sub rsp, 0xF0
000071709abd4c5a  vmovaps [rsp], xmm0
000071709abd4c5f  vmovaps [rsp+0x10], xmm1
000071709abd4c65  vmovaps [rsp+0x20], xmm2
000071709abd4c6b  vmovaps [rsp+0x30], xmm3
000071709abd4c71  vmovaps [rsp+0x40], xmm4
000071709abd4c77  vmovaps [rsp+0x50], xmm5
000071709abd4c7d  vmovaps [rsp+0x60], xmm6
000071709abd4c83  vmovaps [rsp+0x70], xmm7
000071709abd4c89  vmovaps [rsp+0x80], xmm8
000071709abd4c92  vmovaps [rsp+0x90], xmm9
000071709abd4c9b  vmovaps [rsp+0xA0], xmm10
000071709abd4ca4  vmovaps [rsp+0xB0], xmm11
000071709abd4cad  vmovaps [rsp+0xC0], xmm12
000071709abd4cb6  vmovaps [rsp+0xD0], xmm13
000071709abd4cbf  vmovaps [rsp+0xE0], xmm15
000071709abd4cc8  sub rsp, 0x30
000071709abd4ccc  movaps [rsp], xmm14
000071709abd4cd1  movaps [rsp+0x10], xmm4
000071709abd4cd6  movaps [rsp+0x20], xmm1
000071709abd4cdb  lea rdi, [rsp]
000071709abd4cdf  mov esi, 0x00
000071709abd4ce4  mov rax, 0x60B9B2ABC530
000071709abd4cee  call rax
000071709abd4cf0  movaps xmm14, [rsp]
000071709abd4cf5  add rsp, 0x30
000071709abd4cf9  vmovaps xmm0, [rsp]
000071709abd4cfe  vmovaps xmm1, [rsp+0x10]
000071709abd4d04  vmovaps xmm2, [rsp+0x20]
000071709abd4d0a  vmovaps xmm3, [rsp+0x30]
000071709abd4d10  vmovaps xmm4, [rsp+0x40]
000071709abd4d16  vmovaps xmm5, [rsp+0x50]
000071709abd4d1c  vmovaps xmm6, [rsp+0x60]
000071709abd4d22  vmovaps xmm7, [rsp+0x70]
000071709abd4d28  vmovaps xmm8, [rsp+0x80]
000071709abd4d31  vmovaps xmm9, [rsp+0x90]
000071709abd4d3a  vmovaps xmm10, [rsp+0xA0]
000071709abd4d43  vmovaps xmm11, [rsp+0xB0]
000071709abd4d4c  vmovaps xmm12, [rsp+0xC0]
000071709abd4d55  vmovaps xmm13, [rsp+0xD0]
000071709abd4d5e  vmovaps xmm15, [rsp+0xE0]
000071709abd4d67  add rsp, 0xF0
000071709abd4d6e  pop r11
000071709abd4d70  pop r10
000071709abd4d72  pop r9
000071709abd4d74  pop r8
000071709abd4d76  pop rsi
000071709abd4d77  pop rdi
000071709abd4d78  pop rdx
000071709abd4d79  pop rcx
000071709abd4d7a  pop rax
000071709abd4d7b  add rsp, 0x08
000071709abd4d7f  jmp 0x000071709ABD0203
000071709abd4d84  sub rsp, 0x08
000071709abd4d88  push rax
000071709abd4d89  push rcx
000071709abd4d8a  push rdx
000071709abd4d8b  push rdi
000071709abd4d8c  push rsi
000071709abd4d8d  push r8
000071709abd4d8f  push r9
000071709abd4d91  push r10
000071709abd4d93  push r11
000071709abd4d95  sub rsp, 0xF0
000071709abd4d9c  vmovaps [rsp], xmm0
000071709abd4da1  vmovaps [rsp+0x10], xmm2
000071709abd4da7  vmovaps [rsp+0x20], xmm3
000071709abd4dad  vmovaps [rsp+0x30], xmm4
000071709abd4db3  vmovaps [rsp+0x40], xmm5
000071709abd4db9  vmovaps [rsp+0x50], xmm6
000071709abd4dbf  vmovaps [rsp+0x60], xmm7
000071709abd4dc5  vmovaps [rsp+0x70], xmm8
000071709abd4dcb  vmovaps [rsp+0x80], xmm9
000071709abd4dd4  vmovaps [rsp+0x90], xmm10
000071709abd4ddd  vmovaps [rsp+0xA0], xmm11
000071709abd4de6  vmovaps [rsp+0xB0], xmm12
000071709abd4def  vmovaps [rsp+0xC0], xmm13
000071709abd4df8  vmovaps [rsp+0xD0], xmm14
000071709abd4e01  vmovaps [rsp+0xE0], xmm15
000071709abd4e0a  sub rsp, 0x30
000071709abd4e0e  movaps [rsp], xmm1
000071709abd4e12  movaps [rsp+0x10], xmm12
000071709abd4e18  movaps [rsp+0x20], xmm11
000071709abd4e1e  lea rdi, [rsp]
000071709abd4e22  mov esi, 0x00
000071709abd4e27  mov rax, 0x60B9B2ABC530
000071709abd4e31  call rax
000071709abd4e33  movaps xmm1, [rsp]
000071709abd4e37  add rsp, 0x30
000071709abd4e3b  vmovaps xmm0, [rsp]
000071709abd4e40  vmovaps xmm2, [rsp+0x10]
000071709abd4e46  vmovaps xmm3, [rsp+0x20]
000071709abd4e4c  vmovaps xmm4, [rsp+0x30]
000071709abd4e52  vmovaps xmm5, [rsp+0x40]
000071709abd4e58  vmovaps xmm6, [rsp+0x50]
000071709abd4e5e  vmovaps xmm7, [rsp+0x60]
000071709abd4e64  vmovaps xmm8, [rsp+0x70]
000071709abd4e6a  vmovaps xmm9, [rsp+0x80]
000071709abd4e73  vmovaps xmm10, [rsp+0x90]
000071709abd4e7c  vmovaps xmm11, [rsp+0xA0]
000071709abd4e85  vmovaps xmm12, [rsp+0xB0]
000071709abd4e8e  vmovaps xmm13, [rsp+0xC0]
000071709abd4e97  vmovaps xmm14, [rsp+0xD0]
000071709abd4ea0  vmovaps xmm15, [rsp+0xE0]
000071709abd4ea9  add rsp, 0xF0
000071709abd4eb0  pop r11
000071709abd4eb2  pop r10
000071709abd4eb4  pop r9
000071709abd4eb6  pop r8
000071709abd4eb8  pop rsi
000071709abd4eb9  pop rdi
000071709abd4eba  pop rdx
000071709abd4ebb  pop rcx
000071709abd4ebc  pop rax
000071709abd4ebd  add rsp, 0x08
000071709abd4ec1  jmp 0x000071709ABD0224
000071709abd4ec6  call 0x000071709AAE20A0
000071709abd4ecb  jmp 0x000071709ABD0232
000071709abd4ed0  call 0x000071709AA09D70
000071709abd4ed5  jmp 0x000071709ABD023C
000071709abd4eda  sub rsp, 0x08
000071709abd4ede  push rax
000071709abd4edf  push rcx
000071709abd4ee0  push rdx
000071709abd4ee1  push rdi
000071709abd4ee2  push rsi
000071709abd4ee3  push r8
000071709abd4ee5  push r9
000071709abd4ee7  push r10
000071709abd4ee9  push r11
000071709abd4eeb  sub rsp, 0xF0
000071709abd4ef2  vmovaps [rsp], xmm0
000071709abd4ef7  vmovaps [rsp+0x10], xmm1
000071709abd4efd  vmovaps [rsp+0x20], xmm2
000071709abd4f03  vmovaps [rsp+0x30], xmm3
000071709abd4f09  vmovaps [rsp+0x40], xmm4
000071709abd4f0f  vmovaps [rsp+0x50], xmm5
000071709abd4f15  vmovaps [rsp+0x60], xmm6
000071709abd4f1b  vmovaps [rsp+0x70], xmm8
000071709abd4f21  vmovaps [rsp+0x80], xmm9
000071709abd4f2a  vmovaps [rsp+0x90], xmm10
000071709abd4f33  vmovaps [rsp+0xA0], xmm11
000071709abd4f3c  vmovaps [rsp+0xB0], xmm12
000071709abd4f45  vmovaps [rsp+0xC0], xmm13
000071709abd4f4e  vmovaps [rsp+0xD0], xmm14
000071709abd4f57  vmovaps [rsp+0xE0], xmm15
000071709abd4f60  sub rsp, 0x30
000071709abd4f64  movaps [rsp], xmm7
000071709abd4f68  movaps [rsp+0x10], xmm15
000071709abd4f6e  movaps [rsp+0x20], xmm10
000071709abd4f74  lea rdi, [rsp]
000071709abd4f78  mov esi, 0x00
000071709abd4f7d  mov rax, 0x60B9B2ABC530
000071709abd4f87  call rax
000071709abd4f89  movaps xmm7, [rsp]
000071709abd4f8d  add rsp, 0x30
000071709abd4f91  vmovaps xmm0, [rsp]
000071709abd4f96  vmovaps xmm1, [rsp+0x10]
000071709abd4f9c  vmovaps xmm2, [rsp+0x20]
000071709abd4fa2  vmovaps xmm3, [rsp+0x30]
000071709abd4fa8  vmovaps xmm4, [rsp+0x40]
000071709abd4fae  vmovaps xmm5, [rsp+0x50]
000071709abd4fb4  vmovaps xmm6, [rsp+0x60]
000071709abd4fba  vmovaps xmm8, [rsp+0x70]
000071709abd4fc0  vmovaps xmm9, [rsp+0x80]
000071709abd4fc9  vmovaps xmm10, [rsp+0x90]
000071709abd4fd2  vmovaps xmm11, [rsp+0xA0]
000071709abd4fdb  vmovaps xmm12, [rsp+0xB0]
000071709abd4fe4  vmovaps xmm13, [rsp+0xC0]
000071709abd4fed  vmovaps xmm14, [rsp+0xD0]
000071709abd4ff6  vmovaps xmm15, [rsp+0xE0]
000071709abd4fff  add rsp, 0xF0
000071709abd5006  pop r11
000071709abd5008  pop r10
000071709abd500a  pop r9
000071709abd500c  pop r8
000071709abd500e  pop rsi
000071709abd500f  pop rdi
000071709abd5010  pop rdx
000071709abd5011  pop rcx
000071709abd5012  pop rax
000071709abd5013  add rsp, 0x08
000071709abd5017  jmp 0x000071709ABD025D
000071709abd501c  sub rsp, 0x08
000071709abd5020  push rax
000071709abd5021  push rcx
000071709abd5022  push rdx
000071709abd5023  push rdi
000071709abd5024  push rsi
000071709abd5025  push r8
000071709abd5027  push r9
000071709abd5029  push r10
000071709abd502b  push r11
000071709abd502d  sub rsp, 0xF0
000071709abd5034  vmovaps [rsp], xmm0
000071709abd5039  vmovaps [rsp+0x10], xmm1
000071709abd503f  vmovaps [rsp+0x20], xmm2
000071709abd5045  vmovaps [rsp+0x30], xmm3
000071709abd504b  vmovaps [rsp+0x40], xmm4
000071709abd5051  vmovaps [rsp+0x50], xmm5
000071709abd5057  vmovaps [rsp+0x60], xmm6
000071709abd505d  vmovaps [rsp+0x70], xmm7
000071709abd5063  vmovaps [rsp+0x80], xmm8
000071709abd506c  vmovaps [rsp+0x90], xmm9
000071709abd5075  vmovaps [rsp+0xA0], xmm11
000071709abd507e  vmovaps [rsp+0xB0], xmm12
000071709abd5087  vmovaps [rsp+0xC0], xmm13
000071709abd5090  vmovaps [rsp+0xD0], xmm14
000071709abd5099  vmovaps [rsp+0xE0], xmm15
000071709abd50a2  sub rsp, 0x30
000071709abd50a6  movaps [rsp], xmm10
000071709abd50ab  movaps [rsp+0x10], xmm11
000071709abd50b1  movaps [rsp+0x20], xmm15
000071709abd50b7  lea rdi, [rsp]
000071709abd50bb  mov esi, 0x00
000071709abd50c0  mov rax, 0x60B9B2ABC530
000071709abd50ca  call rax
000071709abd50cc  movaps xmm10, [rsp]
000071709abd50d1  add rsp, 0x30
000071709abd50d5  vmovaps xmm0, [rsp]
000071709abd50da  vmovaps xmm1, [rsp+0x10]
000071709abd50e0  vmovaps xmm2, [rsp+0x20]
000071709abd50e6  vmovaps xmm3, [rsp+0x30]
000071709abd50ec  vmovaps xmm4, [rsp+0x40]
000071709abd50f2  vmovaps xmm5, [rsp+0x50]
000071709abd50f8  vmovaps xmm6, [rsp+0x60]
000071709abd50fe  vmovaps xmm7, [rsp+0x70]
000071709abd5104  vmovaps xmm8, [rsp+0x80]
000071709abd510d  vmovaps xmm9, [rsp+0x90]
000071709abd5116  vmovaps xmm11, [rsp+0xA0]
000071709abd511f  vmovaps xmm12, [rsp+0xB0]
000071709abd5128  vmovaps xmm13, [rsp+0xC0]
000071709abd5131  vmovaps xmm14, [rsp+0xD0]
000071709abd513a  vmovaps xmm15, [rsp+0xE0]
000071709abd5143  add rsp, 0xF0
000071709abd514a  pop r11
000071709abd514c  pop r10
000071709abd514e  pop r9
000071709abd5150  pop r8
000071709abd5152  pop rsi
000071709abd5153  pop rdi
000071709abd5154  pop rdx
000071709abd5155  pop rcx
000071709abd5156  pop rax
000071709abd5157  add rsp, 0x08
000071709abd515b  jmp 0x000071709ABD028B
000071709abd5160  sub rsp, 0x08
000071709abd5164  push rax
000071709abd5165  push rcx
000071709abd5166  push rdx
000071709abd5167  push rdi
000071709abd5168  push rsi
000071709abd5169  push r8
000071709abd516b  push r9
000071709abd516d  push r10
000071709abd516f  push r11
000071709abd5171  sub rsp, 0xF0
000071709abd5178  vmovaps [rsp], xmm0
000071709abd517d  vmovaps [rsp+0x10], xmm1
000071709abd5183  vmovaps [rsp+0x20], xmm2
000071709abd5189  vmovaps [rsp+0x30], xmm3
000071709abd518f  vmovaps [rsp+0x40], xmm4
000071709abd5195  vmovaps [rsp+0x50], xmm5
000071709abd519b  vmovaps [rsp+0x60], xmm6
000071709abd51a1  vmovaps [rsp+0x70], xmm7
000071709abd51a7  vmovaps [rsp+0x80], xmm8
000071709abd51b0  vmovaps [rsp+0x90], xmm9
000071709abd51b9  vmovaps [rsp+0xA0], xmm10
000071709abd51c2  vmovaps [rsp+0xB0], xmm12
000071709abd51cb  vmovaps [rsp+0xC0], xmm13
000071709abd51d4  vmovaps [rsp+0xD0], xmm14
000071709abd51dd  vmovaps [rsp+0xE0], xmm15
000071709abd51e6  sub rsp, 0x30
000071709abd51ea  movaps [rsp], xmm11
000071709abd51ef  movaps [rsp+0x10], xmm12
000071709abd51f5  movaps [rsp+0x20], xmm15
000071709abd51fb  lea rdi, [rsp]
000071709abd51ff  mov esi, 0x00
000071709abd5204  mov rax, 0x60B9B2ABC530
000071709abd520e  call rax
000071709abd5210  movaps xmm11, [rsp]
000071709abd5215  add rsp, 0x30
000071709abd5219  vmovaps xmm0, [rsp]
000071709abd521e  vmovaps xmm1, [rsp+0x10]
000071709abd5224  vmovaps xmm2, [rsp+0x20]
000071709abd522a  vmovaps xmm3, [rsp+0x30]
000071709abd5230  vmovaps xmm4, [rsp+0x40]
000071709abd5236  vmovaps xmm5, [rsp+0x50]
000071709abd523c  vmovaps xmm6, [rsp+0x60]
000071709abd5242  vmovaps xmm7, [rsp+0x70]
000071709abd5248  vmovaps xmm8, [rsp+0x80]
000071709abd5251  vmovaps xmm9, [rsp+0x90]
000071709abd525a  vmovaps xmm10, [rsp+0xA0]
000071709abd5263  vmovaps xmm12, [rsp+0xB0]
000071709abd526c  vmovaps xmm13, [rsp+0xC0]
000071709abd5275  vmovaps xmm14, [rsp+0xD0]
000071709abd527e  vmovaps xmm15, [rsp+0xE0]
000071709abd5287  add rsp, 0xF0
000071709abd528e  pop r11
000071709abd5290  pop r10
000071709abd5292  pop r9
000071709abd5294  pop r8
000071709abd5296  pop rsi
000071709abd5297  pop rdi
000071709abd5298  pop rdx
000071709abd5299  pop rcx
000071709abd529a  pop rax
000071709abd529b  add rsp, 0x08
000071709abd529f  jmp 0x000071709ABD02B9
000071709abd52a4  sub rsp, 0x08
000071709abd52a8  push rax
000071709abd52a9  push rcx
000071709abd52aa  push rdx
000071709abd52ab  push rdi
000071709abd52ac  push rsi
000071709abd52ad  push r8
000071709abd52af  push r9
000071709abd52b1  push r10
000071709abd52b3  push r11
000071709abd52b5  sub rsp, 0xF0
000071709abd52bc  vmovaps [rsp], xmm0
000071709abd52c1  vmovaps [rsp+0x10], xmm1
000071709abd52c7  vmovaps [rsp+0x20], xmm2
000071709abd52cd  vmovaps [rsp+0x30], xmm3
000071709abd52d3  vmovaps [rsp+0x40], xmm4
000071709abd52d9  vmovaps [rsp+0x50], xmm5
000071709abd52df  vmovaps [rsp+0x60], xmm6
000071709abd52e5  vmovaps [rsp+0x70], xmm7
000071709abd52eb  vmovaps [rsp+0x80], xmm8
000071709abd52f4  vmovaps [rsp+0x90], xmm9
000071709abd52fd  vmovaps [rsp+0xA0], xmm10
000071709abd5306  vmovaps [rsp+0xB0], xmm11
000071709abd530f  vmovaps [rsp+0xC0], xmm12
000071709abd5318  vmovaps [rsp+0xD0], xmm13
000071709abd5321  vmovaps [rsp+0xE0], xmm14
000071709abd532a  sub rsp, 0x30
000071709abd532e  movaps [rsp], xmm15
000071709abd5333  movaps [rsp+0x10], xmm13
000071709abd5339  movaps [rsp+0x20], xmm9
000071709abd533f  lea rdi, [rsp]
000071709abd5343  mov esi, 0x00
000071709abd5348  mov rax, 0x60B9B2ABC530
000071709abd5352  call rax
000071709abd5354  movaps xmm15, [rsp]
000071709abd5359  add rsp, 0x30
000071709abd535d  vmovaps xmm0, [rsp]
000071709abd5362  vmovaps xmm1, [rsp+0x10]
000071709abd5368  vmovaps xmm2, [rsp+0x20]
000071709abd536e  vmovaps xmm3, [rsp+0x30]
000071709abd5374  vmovaps xmm4, [rsp+0x40]
000071709abd537a  vmovaps xmm5, [rsp+0x50]
000071709abd5380  vmovaps xmm6, [rsp+0x60]
000071709abd5386  vmovaps xmm7, [rsp+0x70]
000071709abd538c  vmovaps xmm8, [rsp+0x80]
000071709abd5395  vmovaps xmm9, [rsp+0x90]
000071709abd539e  vmovaps xmm10, [rsp+0xA0]
000071709abd53a7  vmovaps xmm11, [rsp+0xB0]
000071709abd53b0  vmovaps xmm12, [rsp+0xC0]
000071709abd53b9  vmovaps xmm13, [rsp+0xD0]
000071709abd53c2  vmovaps xmm14, [rsp+0xE0]
000071709abd53cb  add rsp, 0xF0
000071709abd53d2  pop r11
000071709abd53d4  pop r10
000071709abd53d6  pop r9
000071709abd53d8  pop r8
000071709abd53da  pop rsi
000071709abd53db  pop rdi
000071709abd53dc  pop rdx
000071709abd53dd  pop rcx
000071709abd53de  pop rax
000071709abd53df  add rsp, 0x08
000071709abd53e3  jmp 0x000071709ABD02D4
000071709abd53e8  sub rsp, 0x08
000071709abd53ec  push rax
000071709abd53ed  push rcx
000071709abd53ee  push rdx
000071709abd53ef  push rdi
000071709abd53f0  push rsi
000071709abd53f1  push r8
000071709abd53f3  push r9
000071709abd53f5  push r10
000071709abd53f7  push r11
000071709abd53f9  sub rsp, 0xF0
000071709abd5400  vmovaps [rsp], xmm0
000071709abd5405  vmovaps [rsp+0x10], xmm1
000071709abd540b  vmovaps [rsp+0x20], xmm2
000071709abd5411  vmovaps [rsp+0x30], xmm3
000071709abd5417  vmovaps [rsp+0x40], xmm4
000071709abd541d  vmovaps [rsp+0x50], xmm5
000071709abd5423  vmovaps [rsp+0x60], xmm6
000071709abd5429  vmovaps [rsp+0x70], xmm7
000071709abd542f  vmovaps [rsp+0x80], xmm8
000071709abd5438  vmovaps [rsp+0x90], xmm9
000071709abd5441  vmovaps [rsp+0xA0], xmm10
000071709abd544a  vmovaps [rsp+0xB0], xmm11
000071709abd5453  vmovaps [rsp+0xC0], xmm12
000071709abd545c  vmovaps [rsp+0xD0], xmm14
000071709abd5465  vmovaps [rsp+0xE0], xmm15
000071709abd546e  sub rsp, 0x30
000071709abd5472  movaps [rsp], xmm13
000071709abd5477  movaps [rsp+0x10], xmm8
000071709abd547d  movaps [rsp+0x20], xmm14
000071709abd5483  lea rdi, [rsp]
000071709abd5487  mov esi, 0x00
000071709abd548c  mov rax, 0x60B9B2ABC530
000071709abd5496  call rax
000071709abd5498  movaps xmm13, [rsp]
000071709abd549d  add rsp, 0x30
000071709abd54a1  vmovaps xmm0, [rsp]
000071709abd54a6  vmovaps xmm1, [rsp+0x10]
000071709abd54ac  vmovaps xmm2, [rsp+0x20]
000071709abd54b2  vmovaps xmm3, [rsp+0x30]
000071709abd54b8  vmovaps xmm4, [rsp+0x40]
000071709abd54be  vmovaps xmm5, [rsp+0x50]
000071709abd54c4  vmovaps xmm6, [rsp+0x60]
000071709abd54ca  vmovaps xmm7, [rsp+0x70]
000071709abd54d0  vmovaps xmm8, [rsp+0x80]
000071709abd54d9  vmovaps xmm9, [rsp+0x90]
000071709abd54e2  vmovaps xmm10, [rsp+0xA0]
000071709abd54eb  vmovaps xmm11, [rsp+0xB0]
000071709abd54f4  vmovaps xmm12, [rsp+0xC0]
000071709abd54fd  vmovaps xmm14, [rsp+0xD0]
000071709abd5506  vmovaps xmm15, [rsp+0xE0]
000071709abd550f  add rsp, 0xF0
000071709abd5516  pop r11
000071709abd5518  pop r10
000071709abd551a  pop r9
000071709abd551c  pop r8
000071709abd551e  pop rsi
000071709abd551f  pop rdi
000071709abd5520  pop rdx
000071709abd5521  pop rcx
000071709abd5522  pop rax
000071709abd5523  add rsp, 0x08
000071709abd5527  jmp 0x000071709ABD02F7
000071709abd552c  sub rsp, 0x08
000071709abd5530  push rax
000071709abd5531  push rcx
000071709abd5532  push rdx
000071709abd5533  push rdi
000071709abd5534  push rsi
000071709abd5535  push r8
000071709abd5537  push r9
000071709abd5539  push r10
000071709abd553b  push r11
000071709abd553d  sub rsp, 0xF0
000071709abd5544  vmovaps [rsp], xmm0
000071709abd5549  vmovaps [rsp+0x10], xmm1
000071709abd554f  vmovaps [rsp+0x20], xmm2
000071709abd5555  vmovaps [rsp+0x30], xmm3
000071709abd555b  vmovaps [rsp+0x40], xmm4
000071709abd5561  vmovaps [rsp+0x50], xmm5
000071709abd5567  vmovaps [rsp+0x60], xmm6
000071709abd556d  vmovaps [rsp+0x70], xmm7
000071709abd5573  vmovaps [rsp+0x80], xmm8
000071709abd557c  vmovaps [rsp+0x90], xmm9
000071709abd5585  vmovaps [rsp+0xA0], xmm10
000071709abd558e  vmovaps [rsp+0xB0], xmm11
000071709abd5597  vmovaps [rsp+0xC0], xmm12
000071709abd55a0  vmovaps [rsp+0xD0], xmm13
000071709abd55a9  vmovaps [rsp+0xE0], xmm15
000071709abd55b2  sub rsp, 0x30
000071709abd55b6  movaps [rsp], xmm14
000071709abd55bb  movaps [rsp+0x10], xmm1
000071709abd55c0  movaps [rsp+0x20], xmm10
000071709abd55c6  lea rdi, [rsp]
000071709abd55ca  mov esi, 0x00
000071709abd55cf  mov rax, 0x60B9B2ABC530
000071709abd55d9  call rax
000071709abd55db  movaps xmm14, [rsp]
000071709abd55e0  add rsp, 0x30
000071709abd55e4  vmovaps xmm0, [rsp]
000071709abd55e9  vmovaps xmm1, [rsp+0x10]
000071709abd55ef  vmovaps xmm2, [rsp+0x20]
000071709abd55f5  vmovaps xmm3, [rsp+0x30]
000071709abd55fb  vmovaps xmm4, [rsp+0x40]
000071709abd5601  vmovaps xmm5, [rsp+0x50]
000071709abd5607  vmovaps xmm6, [rsp+0x60]
000071709abd560d  vmovaps xmm7, [rsp+0x70]
000071709abd5613  vmovaps xmm8, [rsp+0x80]
000071709abd561c  vmovaps xmm9, [rsp+0x90]
000071709abd5625  vmovaps xmm10, [rsp+0xA0]
000071709abd562e  vmovaps xmm11, [rsp+0xB0]
000071709abd5637  vmovaps xmm12, [rsp+0xC0]
000071709abd5640  vmovaps xmm13, [rsp+0xD0]
000071709abd5649  vmovaps xmm15, [rsp+0xE0]
000071709abd5652  add rsp, 0xF0
000071709abd5659  pop r11
000071709abd565b  pop r10
000071709abd565d  pop r9
000071709abd565f  pop r8
000071709abd5661  pop rsi
000071709abd5662  pop rdi
000071709abd5663  pop rdx
000071709abd5664  pop rcx
000071709abd5665  pop rax
000071709abd5666  add rsp, 0x08
000071709abd566a  jmp 0x000071709ABD031A
000071709abd566f  sub rsp, 0x08
000071709abd5673  push rax
000071709abd5674  push rcx
000071709abd5675  push rdx
000071709abd5676  push rdi
000071709abd5677  push rsi
000071709abd5678  push r8
000071709abd567a  push r9
000071709abd567c  push r10
000071709abd567e  push r11
000071709abd5680  sub rsp, 0xF0
000071709abd5687  vmovaps [rsp], xmm0
000071709abd568c  vmovaps [rsp+0x10], xmm2
000071709abd5692  vmovaps [rsp+0x20], xmm3
000071709abd5698  vmovaps [rsp+0x30], xmm4
000071709abd569e  vmovaps [rsp+0x40], xmm5
000071709abd56a4  vmovaps [rsp+0x50], xmm6
000071709abd56aa  vmovaps [rsp+0x60], xmm7
000071709abd56b0  vmovaps [rsp+0x70], xmm8
000071709abd56b6  vmovaps [rsp+0x80], xmm9
000071709abd56bf  vmovaps [rsp+0x90], xmm10
000071709abd56c8  vmovaps [rsp+0xA0], xmm11
000071709abd56d1  vmovaps [rsp+0xB0], xmm12
000071709abd56da  vmovaps [rsp+0xC0], xmm13
000071709abd56e3  vmovaps [rsp+0xD0], xmm14
000071709abd56ec  vmovaps [rsp+0xE0], xmm15
000071709abd56f5  sub rsp, 0x30
000071709abd56f9  movaps [rsp], xmm1
000071709abd56fd  movaps [rsp+0x10], xmm7
000071709abd5702  movaps [rsp+0x20], xmm11
000071709abd5708  lea rdi, [rsp]
000071709abd570c  mov esi, 0x00
000071709abd5711  mov rax, 0x60B9B2ABC530
000071709abd571b  call rax
000071709abd571d  movaps xmm1, [rsp]
000071709abd5721  add rsp, 0x30
000071709abd5725  vmovaps xmm0, [rsp]
000071709abd572a  vmovaps xmm2, [rsp+0x10]
000071709abd5730  vmovaps xmm3, [rsp+0x20]
000071709abd5736  vmovaps xmm4, [rsp+0x30]
000071709abd573c  vmovaps xmm5, [rsp+0x40]
000071709abd5742  vmovaps xmm6, [rsp+0x50]
000071709abd5748  vmovaps xmm7, [rsp+0x60]
000071709abd574e  vmovaps xmm8, [rsp+0x70]
000071709abd5754  vmovaps xmm9, [rsp+0x80]
000071709abd575d  vmovaps xmm10, [rsp+0x90]
000071709abd5766  vmovaps xmm11, [rsp+0xA0]
000071709abd576f  vmovaps xmm12, [rsp+0xB0]
000071709abd5778  vmovaps xmm13, [rsp+0xC0]
000071709abd5781  vmovaps xmm14, [rsp+0xD0]
000071709abd578a  vmovaps xmm15, [rsp+0xE0]
000071709abd5793  add rsp, 0xF0
000071709abd579a  pop r11
000071709abd579c  pop r10
000071709abd579e  pop r9
000071709abd57a0  pop r8
000071709abd57a2  pop rsi
000071709abd57a3  pop rdi
000071709abd57a4  pop rdx
000071709abd57a5  pop rcx
000071709abd57a6  pop rax
000071709abd57a7  add rsp, 0x08
000071709abd57ab  jmp 0x000071709ABD033B
000071709abd57b0  call 0x000071709AA0E880
000071709abd57b5  jmp 0x000071709ABD034E
000071709abd57ba  call 0x000071709AA0C380
000071709abd57bf  jmp 0x000071709ABD0359
000071709abd57c4  call 0x000071709AA0D600
000071709abd57c9  jmp 0x000071709ABD0364
000071709abd57ce  call 0x000071709A9FF540
000071709abd57d3  jmp 0x000071709ABD036F
000071709abd57d8  int3
000071709abd57d9  nop [rax], eax
000071709abd57e0  mov rax, [r15+0x40]
000071709abd57e4  mov r14, [r15+0x58]
000071709abd57e8  lea r12, [rax+r14*1]
000071709abd57ec  movaps xmm1, [r15+0x1D0]
000071709abd57f4  vmovaps [rsp+0x10], xmm1
000071709abd57fa  vmovaps xmm15, [rsp+0x10]
000071709abd5800  por xmm1, xmm15
000071709abd5805  movaps xmm14, [r15+0x1A0]
000071709abd580d  vmovaps [rsp+0x10], xmm14
000071709abd5813  vmovaps xmm13, [rsp+0x10]
000071709abd5819  por xmm14, xmm13
000071709abd581e  lea rax, [r12+0x30]
000071709abd5823  mov r11, [r13+rax*1]
000071709abd5828  lea rax, [r12+0x38]
000071709abd582d  mov r10, [r13+rax*1]
000071709abd5832  movq xmm13, r11
000071709abd5837  movq xmm12, r10
000071709abd583c  movq xmm13, xmm13
000071709abd5841  vmovaps [rsp+0x10], xmm13
000071709abd5847  movq xmm13, xmm13
000071709abd584c  movaps [r15+0x130], xmm13
000071709abd5854  movq xmm12, xmm12
000071709abd5859  vmovaps [rsp+0x20], xmm12
000071709abd585f  movq xmm12, xmm12
000071709abd5864  movaps [r15+0x280], xmm12
000071709abd586c  movaps xmm13, [r15+0x270]
000071709abd5874  vmovaps [rsp+0x30], xmm13
000071709abd587a  vmovaps xmm12, [rsp+0x30]
000071709abd5880  por xmm13, xmm12
000071709abd5885  lea rax, [r12+0x20]
000071709abd588a  mov r11, [r13+rax*1]
000071709abd588f  lea rax, [r12+0x28]
000071709abd5894  mov r10, [r13+rax*1]
000071709abd5899  movq xmm12, r11
000071709abd589e  movq xmm11, r10
000071709abd58a3  movq xmm12, xmm12
000071709abd58a8  vmovaps [rsp+0x30], xmm12
000071709abd58ae  movq xmm12, xmm12
000071709abd58b3  movaps [r15+0x150], xmm12
000071709abd58bb  movq xmm11, xmm11
000071709abd58c0  vmovaps [rsp+0x40], xmm11
000071709abd58c6  movq xmm11, xmm11
000071709abd58cb  movaps [r15+0x140], xmm11
000071709abd58d3  lea rax, [r12+0x10]
000071709abd58d8  mov r11, [r13+rax*1]
000071709abd58dd  lea rax, [r12+0x18]
000071709abd58e2  mov r10, [r13+rax*1]
000071709abd58e7  movq xmm12, r11
000071709abd58ec  movq xmm11, r10
000071709abd58f1  movq xmm12, xmm12
000071709abd58f6  vmovaps [rsp+0x50], xmm12
000071709abd58fc  movq xmm12, xmm12
000071709abd5901  movaps [r15+0x170], xmm12
000071709abd5909  movq xmm11, xmm11
000071709abd590e  vmovaps [rsp+0x60], xmm11
000071709abd5914  movq xmm11, xmm11
000071709abd5919  movaps [r15+0x160], xmm11
000071709abd5921  mov rax, [r13+r12*1]
000071709abd5926  vmovq xmm12, rax
000071709abd592b  vpbroadcastq xmm12, xmm12
000071709abd5930  lea rax, [r12+0x08]
000071709abd5935  mov r12, [r13+rax*1]
000071709abd593a  movq xmm11, r12
000071709abd593f  movaps [r15+0x230], xmm11
000071709abd5947  mov rax, [r15+0xF8]
000071709abd594e  lea r12, [rax+0x50]
000071709abd5952  movups xmm11, [r13+r12*1]
000071709abd5958  lea r12, [rax+0x60]
000071709abd595c  movups xmm10, [r13+r12*1]
000071709abd5962  lea r12, [rax+0x30]
000071709abd5966  movups xmm9, [r13+r12*1]
000071709abd596c  mov r12, [r15+0x50]
000071709abd5970  lea r11, [r12+r14*1]
000071709abd5974  mov [r15+0x60], r11
000071709abd5978  lea r12, [r14+0x40]
000071709abd597c  mov [r15+0x58], r12
000071709abd5980  movaps xmm8, xmm12
000071709abd5984  mulpd xmm8, xmm15
000071709abd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000071709abd598f  ptest xmm7, xmm7
000071709abd5994  jnz 0x000071709ABD67B7
000071709abd599a  movq xmm15, qword ptr [r15+0x230]
000071709abd59a3  vmovaps [rsp+0x70], xmm15
000071709abd59a9  vpermilpd xmm15, xmm15, 0x00
000071709abd59af  movaps xmm7, xmm9
000071709abd59b3  mulpd xmm7, xmm15
000071709abd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000071709abd59bd  ptest xmm6, xmm6
000071709abd59c2  jnz 0x000071709ABD68FB
000071709abd59c8  vxorps xmm15, xmm15, xmm15
000071709abd59cd  vpbroadcastq xmm15, xmm15
000071709abd59d2  movaps xmm9, xmm12
000071709abd59d6  mulpd xmm9, xmm10
000071709abd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000071709abd59e1  ptest xmm6, xmm6
000071709abd59e6  jnz 0x000071709ABD6A3D
000071709abd59ec  movaps xmm10, xmm12
000071709abd59f0  mulpd xmm10, xmm11
000071709abd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000071709abd59fb  ptest xmm6, xmm6
000071709abd5a00  jnz 0x000071709ABD6B81
000071709abd5a06  movaps xmm11, [r15+0x1F0]
000071709abd5a0e  movaps xmm6, xmm12
000071709abd5a12  mulpd xmm6, xmm11
000071709abd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000071709abd5a1c  ptest xmm5, xmm5
000071709abd5a21  jnz 0x000071709ABD6CC5
000071709abd5a27  movaps xmm12, [r15+0x2A0]
000071709abd5a2f  vmovaps [rsp+0x80], xmm12
000071709abd5a38  vmovaps xmm11, [rsp+0x80]
000071709abd5a41  por xmm12, xmm11
000071709abd5a46  movaps xmm11, [r15+0x250]
000071709abd5a4e  vmovaps [rsp+0x80], xmm11
000071709abd5a57  vmovaps xmm5, [rsp+0x80]
000071709abd5a60  por xmm11, xmm5
000071709abd5a65  vmovaps xmm4, [rsp+0x70]
000071709abd5a6b  vpermilpd xmm4, xmm4, 0x00
000071709abd5a71  movaps xmm3, xmm5
000071709abd5a74  mulpd xmm3, xmm4
000071709abd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000071709abd5a7d  ptest xmm2, xmm2
000071709abd5a82  jnz 0x000071709ABD6E07
000071709abd5a88  mov [rsp+0x80], rax
000071709abd5a90  xor eax, eax
000071709abd5a92  mov r14d, 0x200
000071709abd5a98  cmp r12, r14
000071709abd5a9b  cmc
000071709abd5a9c  lahf
000071709abd5a9d  seto al
000071709abd5aa0  mov [r15+0x108], eax
000071709abd5aa7  movaps xmm5, xmm8
000071709abd5aab  addpd xmm5, xmm15
000071709abd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000071709abd5ab5  ptest xmm4, xmm4
000071709abd5aba  jnz 0x000071709ABD6F47
000071709abd5ac0  movaps xmm8, [r15+0x1B0]
000071709abd5ac8  movaps xmm4, xmm9
000071709abd5acc  addpd xmm4, xmm8
000071709abd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000071709abd5ad6  ptest xmm2, xmm2
000071709abd5adb  jnz 0x000071709ABD7089
000071709abd5ae1  movaps xmm9, xmm10
000071709abd5ae5  addpd xmm9, xmm8
000071709abd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000071709abd5af0  ptest xmm2, xmm2
000071709abd5af5  jnz 0x000071709ABD71CB
000071709abd5afb  movaps xmm10, [r15+0x2F0]
000071709abd5b03  vmovaps [rsp+0x90], xmm10
000071709abd5b0c  vmovaps xmm8, [rsp+0x90]
000071709abd5b15  por xmm10, xmm8
000071709abd5b1a  movaps xmm8, [r15+0x2E0]
000071709abd5b22  vmovaps [rsp+0x90], xmm8
000071709abd5b2b  vmovaps xmm2, [rsp+0x90]
000071709abd5b34  por xmm8, xmm2
000071709abd5b39  movaps xmm2, [r15+0x2D0]
000071709abd5b41  vmovaps [rsp+0x90], xmm2
000071709abd5b4a  vmovaps [rsp+0xA0], xmm1
000071709abd5b53  vmovaps xmm1, [rsp+0x90]
000071709abd5b5c  por xmm2, xmm1
000071709abd5b60  movaps xmm1, [r15+0x200]
000071709abd5b68  vmovaps [rsp+0x90], xmm1
000071709abd5b71  vmovaps [rsp+0xB0], xmm15
000071709abd5b7a  vmovaps xmm15, [rsp+0x90]
000071709abd5b83  por xmm1, xmm15
000071709abd5b88  movaps xmm15, [r15+0x1C0]
000071709abd5b90  vmovaps [rsp+0x90], xmm15
000071709abd5b99  vmovaps [rsp+0xC0], xmm1
000071709abd5ba2  vmovaps xmm1, [rsp+0x90]
000071709abd5bab  por xmm15, xmm1
000071709abd5bb0  movaps xmm1, [r15+0x190]
000071709abd5bb8  vmovaps [rsp+0x90], xmm1
000071709abd5bc1  vmovaps [rsp+0xD0], xmm15
000071709abd5bca  vmovaps xmm15, [rsp+0x90]
000071709abd5bd3  por xmm1, xmm15
000071709abd5bd8  movaps xmm15, [r15+0x300]
000071709abd5be0  vmovaps [rsp+0x90], xmm15
000071709abd5be9  vmovaps [rsp+0xE0], xmm1
000071709abd5bf2  vmovaps xmm1, [rsp+0x90]
000071709abd5bfb  por xmm15, xmm1
000071709abd5c00  mov rax, [rsp+0x80]
000071709abd5c08  lea r14, [rax+0xA0]
000071709abd5c0f  movups xmm1, [r13+r14*1]
000071709abd5c15  lea r14, [rax+0xB0]
000071709abd5c1c  vmovaps [rsp+0x80], xmm1
000071709abd5c25  movups xmm1, [r13+r14*1]
000071709abd5c2b  vmovaps [rsp+0x90], xmm1
000071709abd5c34  vmovaps [rsp+0xF0], xmm15
000071709abd5c3d  vmovaps xmm15, [rsp+0xB0]
000071709abd5c46  vmovaps [rsp+0xB0], xmm14
000071709abd5c4f  movaps xmm1, xmm6
000071709abd5c52  addpd xmm1, xmm15
000071709abd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000071709abd5c5c  ptest xmm14, xmm14
000071709abd5c62  jnz 0x000071709ABD7323
000071709abd5c68  lea r14, [rax+0xF0]
000071709abd5c6f  movups xmm15, [r13+r14*1]
000071709abd5c75  movaps xmm14, xmm4
000071709abd5c79  addpd xmm14, xmm3
000071709abd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000071709abd5c84  ptest xmm6, xmm6
000071709abd5c89  jnz 0x000071709ABD746E
000071709abd5c8f  movaps xmm6, xmm9
000071709abd5c93  addpd xmm6, xmm7
000071709abd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000071709abd5c9c  ptest xmm4, xmm4
000071709abd5ca1  jnz 0x000071709ABD75B0
000071709abd5ca7  vmovaps xmm9, [rsp+0x70]
000071709abd5cad  vpermilpd xmm9, xmm9, 0x00
000071709abd5cb3  vmovaps xmm4, [rsp+0x90]
000071709abd5cbc  movaps xmm7, xmm4
000071709abd5cbf  mulpd xmm7, xmm9
000071709abd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000071709abd5cc9  ptest xmm3, xmm3
000071709abd5cce  jnz 0x000071709ABD76F1
000071709abd5cd4  vmovaps xmm9, [rsp+0x50]
000071709abd5cda  vpermilpd xmm9, xmm9, 0x00
000071709abd5ce0  movaps xmm4, xmm15
000071709abd5ce4  mulpd xmm4, xmm9
000071709abd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000071709abd5cee  ptest xmm3, xmm3
000071709abd5cf3  jnz 0x000071709ABD7832
000071709abd5cf9  lea r14, [rax+0xE0]
000071709abd5d00  movups xmm15, [r13+r14*1]
000071709abd5d06  vmovaps xmm9, [rsp+0x70]
000071709abd5d0c  vpermilpd xmm9, xmm9, 0x00
000071709abd5d12  vmovaps [rsp+0x70], xmm1
000071709abd5d18  vmovaps xmm1, [rsp+0x80]
000071709abd5d21  vmovaps [rsp+0x80], xmm15
000071709abd5d2a  movaps xmm3, xmm1
000071709abd5d2d  mulpd xmm3, xmm9
000071709abd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000071709abd5d37  ptest xmm15, xmm15
000071709abd5d3d  jnz 0x000071709ABD797E
000071709abd5d43  vmovaps xmm1, [rsp+0xF0]
000071709abd5d4c  vmovaps xmm15, [rsp+0xF0]
000071709abd5d55  por xmm1, xmm15
000071709abd5d5a  movaps [r15+0x300], xmm1
000071709abd5d62  vmovaps xmm15, [rsp+0xE0]
000071709abd5d6b  vmovaps xmm9, [rsp+0xE0]
000071709abd5d74  por xmm15, xmm9
000071709abd5d79  movaps [r15+0x190], xmm15
000071709abd5d81  vmovaps xmm9, [rsp+0x50]
000071709abd5d87  vpermilpd xmm9, xmm9, 0x00
000071709abd5d8d  vmovaps [rsp+0x90], xmm1
000071709abd5d96  vmovaps [rsp+0xE0], xmm15
000071709abd5d9f  vmovaps xmm15, [rsp+0x80]
000071709abd5da8  vmovaps [rsp+0x80], xmm14
000071709abd5db1  movaps xmm1, xmm15
000071709abd5db5  mulpd xmm1, xmm9
000071709abd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000071709abd5dbf  ptest xmm14, xmm14
000071709abd5dc5  jnz 0x000071709ABD7ABF
000071709abd5dcb  lea r14, [rax+0x90]
000071709abd5dd2  movups xmm15, [r13+r14*1]
000071709abd5dd8  vmovaps xmm14, [rsp+0xD0]
000071709abd5de1  vmovaps xmm9, [rsp+0xD0]
000071709abd5dea  por xmm14, xmm9
000071709abd5def  movaps [r15+0x1C0], xmm14
000071709abd5df7  vmovaps xmm9, [rsp+0xC0]
000071709abd5e00  vmovaps [rsp+0xD0], xmm1
000071709abd5e09  vmovaps xmm1, [rsp+0xC0]
000071709abd5e12  por xmm9, xmm1
000071709abd5e17  movaps [r15+0x200], xmm9
000071709abd5e1f  vmovaps [rsp+0xC0], xmm2
000071709abd5e28  vmovaps xmm1, [rsp+0xC0]
000071709abd5e31  por xmm2, xmm1
000071709abd5e35  movaps [r15+0x2D0], xmm2
000071709abd5e3d  vmovaps [rsp+0xC0], xmm8
000071709abd5e46  vmovaps xmm1, [rsp+0xC0]
000071709abd5e4f  por xmm8, xmm1
000071709abd5e54  movaps [r15+0x2E0], xmm8
000071709abd5e5c  vmovaps [rsp+0xC0], xmm15
000071709abd5e65  movaps xmm1, xmm5
000071709abd5e68  addpd xmm1, xmm7
000071709abd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000071709abd5e71  ptest xmm15, xmm15
000071709abd5e77  jnz 0x000071709ABD7C0B
000071709abd5e7d  vmovaps xmm15, [rsp+0x50]
000071709abd5e83  vpermilpd xmm15, xmm15, 0x00
000071709abd5e89  vmovaps xmm5, [rsp+0xC0]
000071709abd5e92  vmovaps [rsp+0xC0], xmm1
000071709abd5e9b  movaps xmm7, xmm5
000071709abd5e9e  mulpd xmm7, xmm15
000071709abd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000071709abd5ea8  ptest xmm1, xmm1
000071709abd5ead  jnz 0x000071709ABD7D4B
000071709abd5eb3  lea r14, [rax+0x80]
000071709abd5eba  movups xmm1, [r13+r14*1]
000071709abd5ec0  vmovaps xmm5, [rsp+0x70]
000071709abd5ec6  vmovaps [rsp+0x70], xmm1
000071709abd5ecc  movaps xmm15, xmm5
000071709abd5ed0  addpd xmm15, xmm3
000071709abd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abd5edb  ptest xmm1, xmm1
000071709abd5ee0  jnz 0x000071709ABD7E96
000071709abd5ee6  vmovaps xmm5, [rsp+0x80]
000071709abd5eef  movaps xmm1, xmm5
000071709abd5ef2  addpd xmm1, xmm4
000071709abd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000071709abd5efb  ptest xmm3, xmm3
000071709abd5f00  jnz 0x000071709ABD7FD8
000071709abd5f06  vmovaps [rsp+0x80], xmm10
000071709abd5f0f  vmovaps xmm5, [rsp+0x80]
000071709abd5f18  por xmm10, xmm5
000071709abd5f1d  movaps [r15+0x2F0], xmm10
000071709abd5f25  vmovaps xmm5, [rsp+0x50]
000071709abd5f2b  vpermilpd xmm5, xmm5, 0x00
000071709abd5f31  vmovaps xmm3, [rsp+0x70]
000071709abd5f37  vmovaps [rsp+0x50], xmm1
000071709abd5f3d  movaps xmm4, xmm3
000071709abd5f40  mulpd xmm4, xmm5
000071709abd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000071709abd5f49  ptest xmm1, xmm1
000071709abd5f4e  jnz 0x000071709ABD8118
000071709abd5f54  lea r14, [rax+0xD0]
000071709abd5f5b  movups xmm1, [r13+r14*1]
000071709abd5f61  vmovaps xmm3, [rsp+0xD0]
000071709abd5f6a  vmovaps [rsp+0x70], xmm1
000071709abd5f70  movaps xmm5, xmm6
000071709abd5f73  addpd xmm5, xmm3
000071709abd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000071709abd5f7c  ptest xmm1, xmm1
000071709abd5f81  jnz 0x000071709ABD8262
000071709abd5f87  vmovaps xmm1, [rsp+0x60]
000071709abd5f8d  vpermilpd xmm1, xmm1, 0x00
000071709abd5f93  movaps xmm6, xmm9
000071709abd5f97  mulpd xmm6, xmm1
000071709abd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000071709abd5fa0  ptest xmm3, xmm3
000071709abd5fa5  jnz 0x000071709ABD83A2
000071709abd5fab  movaps [r15+0x260], xmm6
000071709abd5fb3  vxorps xmm1, xmm1, xmm1
000071709abd5fb7  vpbroadcastq xmm1, xmm1
000071709abd5fbc  movaps [r15+0x1B0], xmm1
000071709abd5fc4  vmovaps xmm1, [rsp+0x60]
000071709abd5fca  vpermilpd xmm1, xmm1, 0x00
000071709abd5fd0  vmovaps xmm3, [rsp+0x70]
000071709abd5fd6  vmovaps [rsp+0x70], xmm15
000071709abd5fdc  movaps xmm9, xmm3
000071709abd5fe0  mulpd xmm9, xmm1
000071709abd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000071709abd5feb  ptest xmm15, xmm15
000071709abd5ff1  jnz 0x000071709ABD84E3
000071709abd5ff7  lea r14, [rax+0xC0]
000071709abd5ffe  movups xmm1, [r13+r14*1]
000071709abd6004  vmovaps xmm3, [rsp+0xC0]
000071709abd600d  vmovaps [rsp+0x80], xmm1
000071709abd6016  movaps xmm15, xmm3
000071709abd601a  addpd xmm15, xmm7
000071709abd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abd6025  ptest xmm1, xmm1
000071709abd602a  jnz 0x000071709ABD862F
000071709abd6030  vmovaps [rsp+0xC0], xmm13
000071709abd6039  vmovaps xmm1, [rsp+0xC0]
000071709abd6042  por xmm13, xmm1
000071709abd6047  movaps [r15+0x270], xmm13
000071709abd604f  vmovaps xmm1, [rsp+0xB0]
000071709abd6058  vmovaps xmm7, [rsp+0xB0]
000071709abd6061  por xmm1, xmm7
000071709abd6065  movaps [r15+0x1A0], xmm1
000071709abd606d  vmovaps xmm1, [rsp+0x60]
000071709abd6073  vpermilpd xmm1, xmm1, 0x00
000071709abd6079  vmovaps [rsp+0xB0], xmm1
000071709abd6082  vmovaps xmm1, [rsp+0x80]
000071709abd608b  vmovaps [rsp+0x80], xmm15
000071709abd6094  vmovaps xmm15, [rsp+0xB0]
000071709abd609d  vmovaps [rsp+0xB0], xmm14
000071709abd60a6  movaps xmm3, xmm1
000071709abd60a9  mulpd xmm3, xmm15
000071709abd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000071709abd60b3  ptest xmm14, xmm14
000071709abd60b9  jnz 0x000071709ABD8771
000071709abd60bf  lea r14, [rax+0x20]
000071709abd60c3  movups xmm1, [r13+r14*1]
000071709abd60c9  movaps [r15+0x110], xmm1
000071709abd60d1  vmovaps xmm14, [rsp+0x70]
000071709abd60d7  vmovaps [rsp+0x70], xmm1
000071709abd60dd  movaps xmm15, xmm14
000071709abd60e1  addpd xmm15, xmm4
000071709abd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abd60ec  ptest xmm1, xmm1
000071709abd60f1  jnz 0x000071709ABD88BC
000071709abd60f7  vmovaps xmm1, [rsp+0x60]
000071709abd60fd  vpermilpd xmm1, xmm1, 0x00
000071709abd6103  movaps xmm14, xmm2
000071709abd6107  mulpd xmm14, xmm1
000071709abd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000071709abd6112  ptest xmm4, xmm4
000071709abd6117  jnz 0x000071709ABD89FF
000071709abd611d  vmovaps xmm4, [rsp+0x50]
000071709abd6123  movaps xmm1, xmm4
000071709abd6126  addpd xmm1, xmm9
000071709abd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000071709abd6130  ptest xmm2, xmm2
000071709abd6135  jnz 0x000071709ABD8B41
000071709abd613b  vmovaps xmm9, [rsp+0x30]
000071709abd6141  vpermilpd xmm9, xmm9, 0x00
000071709abd6147  vmovaps xmm2, [rsp+0x70]
000071709abd614d  vmovaps [rsp+0x50], xmm1
000071709abd6153  movaps xmm4, xmm2
000071709abd6156  mulpd xmm4, xmm9
000071709abd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000071709abd6160  ptest xmm1, xmm1
000071709abd6165  jnz 0x000071709ABD8C82
000071709abd616b  vmovaps xmm1, [rsp+0x30]
000071709abd6171  vpermilpd xmm1, xmm1, 0x00
000071709abd6177  vmovaps xmm2, [rsp+0x90]
000071709abd6180  vmovaps [rsp+0x60], xmm15
000071709abd6186  movaps xmm9, xmm2
000071709abd618a  mulpd xmm9, xmm1
000071709abd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000071709abd6195  ptest xmm15, xmm15
000071709abd619b  jnz 0x000071709ABD8DC3
000071709abd61a1  vmovaps xmm15, [rsp+0x80]
000071709abd61aa  movaps xmm1, xmm15
000071709abd61ae  addpd xmm1, xmm6
000071709abd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000071709abd61b7  ptest xmm2, xmm2
000071709abd61bc  jnz 0x000071709ABD8F05
000071709abd61c2  movaps xmm15, xmm5
000071709abd61c6  addpd xmm15, xmm3
000071709abd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000071709abd61d1  ptest xmm6, xmm6
000071709abd61d6  jnz 0x000071709ABD9046
000071709abd61dc  vmovaps xmm6, [rsp+0x30]
000071709abd61e2  vpermilpd xmm6, xmm6, 0x00
000071709abd61e8  movaps xmm5, xmm8
000071709abd61ec  mulpd xmm5, xmm6
000071709abd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000071709abd61f5  ptest xmm3, xmm3
000071709abd61fa  jnz 0x000071709ABD9188
000071709abd6200  vmovaps xmm8, [rsp+0x30]
000071709abd6206  vpermilpd xmm8, xmm8, 0x00
000071709abd620c  movaps xmm6, xmm10
000071709abd6210  mulpd xmm6, xmm8
000071709abd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000071709abd621a  ptest xmm3, xmm3
000071709abd621f  jnz 0x000071709ABD92C9
000071709abd6225  vmovaps xmm8, [rsp+0x60]
000071709abd622b  movaps xmm10, xmm8
000071709abd622f  addpd xmm10, xmm14
000071709abd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000071709abd623a  ptest xmm3, xmm3
000071709abd623f  jnz 0x000071709ABD940B
000071709abd6245  vmovaps xmm8, [rsp+0x50]
000071709abd624b  movaps xmm14, xmm8
000071709abd624f  addpd xmm14, xmm4
000071709abd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000071709abd625a  ptest xmm3, xmm3
000071709abd625f  jnz 0x000071709ABD954F
000071709abd6265  vmovaps xmm8, [rsp+0x40]
000071709abd626b  vpermilpd xmm8, xmm8, 0x00
000071709abd6271  movaps xmm4, xmm13
000071709abd6275  mulpd xmm4, xmm8
000071709abd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000071709abd627f  ptest xmm3, xmm3
000071709abd6284  jnz 0x000071709ABD9692
000071709abd628a  movaps xmm13, xmm15
000071709abd628e  addpd xmm13, xmm9
000071709abd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000071709abd6299  ptest xmm8, xmm8
000071709abd629f  jnz 0x000071709ABD97D4
000071709abd62a5  movaps xmm15, xmm1
000071709abd62a9  addpd xmm15, xmm5
000071709abd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000071709abd62b4  ptest xmm9, xmm9
000071709abd62ba  jnz 0x000071709ABD9918
000071709abd62c0  vmovaps [rsp+0x30], xmm11
000071709abd62c6  vmovaps xmm1, [rsp+0x30]
000071709abd62cc  por xmm11, xmm1
000071709abd62d1  movaps [r15+0x250], xmm11
000071709abd62d9  vmovaps [rsp+0x30], xmm12
000071709abd62df  vmovaps xmm1, [rsp+0x30]
000071709abd62e5  por xmm12, xmm1
000071709abd62ea  movaps [r15+0x2A0], xmm12
000071709abd62f2  vmovaps xmm1, [rsp+0xA0]
000071709abd62fb  vmovaps xmm11, [rsp+0xA0]
000071709abd6304  por xmm1, xmm11
000071709abd6309  movaps [r15+0x1D0], xmm1
000071709abd6311  lea r14, [rax+0x40]
000071709abd6315  movups xmm1, [r13+r14*1]
000071709abd631b  movaps [r15+0x2C0], xmm1
000071709abd6323  vmovaps xmm11, [rsp+0x40]
000071709abd6329  vpermilpd xmm11, xmm11, 0x00
000071709abd632f  vmovaps xmm8, [rsp+0xE0]
000071709abd6338  movaps xmm9, xmm8
000071709abd633c  mulpd xmm9, xmm11
000071709abd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000071709abd6347  ptest xmm5, xmm5
000071709abd634c  jnz 0x000071709ABD9A64
000071709abd6352  movaps xmm11, xmm10
000071709abd6356  addpd xmm11, xmm6
000071709abd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000071709abd6361  ptest xmm8, xmm8
000071709abd6367  jnz 0x000071709ABD9BA8
000071709abd636d  movaps xmm10, xmm14
000071709abd6371  addpd xmm10, xmm4
000071709abd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000071709abd637c  ptest xmm8, xmm8
000071709abd6382  jnz 0x000071709ABD9CEB
000071709abd6388  vmovaps xmm14, [rsp+0x40]
000071709abd638e  vpermilpd xmm14, xmm14, 0x00
000071709abd6394  movaps xmm8, xmm1
000071709abd6398  mulpd xmm8, xmm14
000071709abd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000071709abd63a3  ptest xmm6, xmm6
000071709abd63a8  jnz 0x000071709ABD9E2E
000071709abd63ae  movaps xmm1, [r15+0x2B0]
000071709abd63b6  vmovaps xmm14, [rsp+0x40]
000071709abd63bc  vpermilpd xmm14, xmm14, 0x00
000071709abd63c2  movaps xmm6, xmm1
000071709abd63c5  mulpd xmm6, xmm14
000071709abd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000071709abd63cf  ptest xmm5, xmm5
000071709abd63d4  jnz 0x000071709ABD9F71
000071709abd63da  vmovaps xmm1, [rsp+0x10]
000071709abd63e0  vpermilpd xmm1, xmm1, 0x00
000071709abd63e6  movaps xmm14, xmm12
000071709abd63ea  mulpd xmm14, xmm1
000071709abd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000071709abd63f5  ptest xmm5, xmm5
000071709abd63fa  jnz 0x000071709ABDA0B2
000071709abd6400  movaps xmm1, xmm13
000071709abd6404  addpd xmm1, xmm9
000071709abd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000071709abd640e  ptest xmm12, xmm12
000071709abd6414  jnz 0x000071709ABDA1F5
000071709abd641a  vmovaps xmm13, [rsp+0x10]
000071709abd6420  vpermilpd xmm13, xmm13, 0x00
000071709abd6426  movaps xmm12, xmm7
000071709abd642a  mulpd xmm12, xmm13
000071709abd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000071709abd6435  ptest xmm9, xmm9
000071709abd643b  jnz 0x000071709ABDA337
000071709abd6441  movaps xmm13, xmm15
000071709abd6445  addpd xmm13, xmm8
000071709abd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000071709abd6450  ptest xmm9, xmm9
000071709abd6456  jnz 0x000071709ABDA47A
000071709abd645c  movaps xmm15, [r15+0x290]
000071709abd6464  vmovaps xmm9, [rsp+0x10]
000071709abd646a  vpermilpd xmm9, xmm9, 0x00
000071709abd6470  movaps xmm8, xmm15
000071709abd6474  mulpd xmm8, xmm9
000071709abd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000071709abd647f  ptest xmm7, xmm7
000071709abd6484  jnz 0x000071709ABDA5BE
000071709abd648a  movaps xmm15, xmm11
000071709abd648e  addpd xmm15, xmm6
000071709abd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000071709abd6499  ptest xmm9, xmm9
000071709abd649f  jnz 0x000071709ABDA702
000071709abd64a5  movaps xmm11, [r15+0x1E0]
000071709abd64ad  vmovaps xmm9, [rsp+0x10]
000071709abd64b3  vpermilpd xmm9, xmm9, 0x00
000071709abd64b9  movaps xmm7, xmm11
000071709abd64bd  mulpd xmm7, xmm9
000071709abd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000071709abd64c7  ptest xmm6, xmm6
000071709abd64cc  jnz 0x000071709ABDA845
000071709abd64d2  movaps xmm11, xmm10
000071709abd64d6  addpd xmm11, xmm14
000071709abd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000071709abd64e1  ptest xmm9, xmm9
000071709abd64e7  jnz 0x000071709ABDA987
000071709abd64ed  lea r14, [rax+0x70]
000071709abd64f1  movups xmm14, [r13+r14*1]
000071709abd64f7  movaps [r15+0x240], xmm14
000071709abd64ff  movaps xmm10, xmm1
000071709abd6503  addpd xmm10, xmm12
000071709abd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000071709abd650e  ptest xmm9, xmm9
000071709abd6514  jnz 0x000071709ABDAAD5
000071709abd651a  movaps [r15+0x170], xmm10
000071709abd6522  vmovaps xmm1, [rsp+0x20]
000071709abd6528  vpermilpd xmm1, xmm1, 0x00
000071709abd652e  movaps xmm12, xmm14
000071709abd6532  mulpd xmm12, xmm1
000071709abd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000071709abd653d  ptest xmm9, xmm9
000071709abd6543  jnz 0x000071709ABDAC18
000071709abd6549  vmovaps xmm1, [rsp+0x20]
000071709abd654f  vpermilpd xmm1, xmm1, 0x00
000071709abd6555  vmovaps xmm9, [rsp+0xB0]
000071709abd655e  movaps xmm14, xmm9
000071709abd6562  mulpd xmm14, xmm1
000071709abd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000071709abd656d  ptest xmm6, xmm6
000071709abd6572  jnz 0x000071709ABDAD5B
000071709abd6578  movaps [r15+0x180], xmm14
000071709abd6580  movaps xmm1, xmm13
000071709abd6584  addpd xmm1, xmm8
000071709abd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000071709abd658e  ptest xmm9, xmm9
000071709abd6594  jnz 0x000071709ABDAE9E
000071709abd659a  movaps [r15+0x210], xmm1
000071709abd65a2  movups xmm13, [r13+rax*1]
000071709abd65a8  lea r14, [rax+0x10]
000071709abd65ac  movups xmm9, [r13+r14*1]
000071709abd65b2  movaps [r15+0x230], xmm9
000071709abd65ba  movaps xmm8, xmm15
000071709abd65be  addpd xmm8, xmm7
000071709abd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000071709abd65c9  ptest xmm6, xmm6
000071709abd65ce  jnz 0x000071709ABDAFF4
000071709abd65d4  movaps [r15+0x130], xmm8
000071709abd65dc  vmovaps xmm15, [rsp+0x20]
000071709abd65e2  vpermilpd xmm15, xmm15, 0x00
000071709abd65e8  movaps xmm7, xmm9
000071709abd65ec  mulpd xmm7, xmm15
000071709abd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000071709abd65f6  ptest xmm6, xmm6
000071709abd65fb  jnz 0x000071709ABDB137
000071709abd6601  movaps [r15+0x220], xmm7
000071709abd6609  vmovaps xmm15, [rsp+0x20]
000071709abd660f  vpermilpd xmm15, xmm15, 0x00
000071709abd6615  movaps xmm9, xmm13
000071709abd6619  mulpd xmm9, xmm15
000071709abd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000071709abd6624  ptest xmm6, xmm6
000071709abd6629  jnz 0x000071709ABDB279
000071709abd662f  movaps xmm15, xmm11
000071709abd6633  addpd xmm15, xmm12
000071709abd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000071709abd663e  ptest xmm13, xmm13
000071709abd6644  jnz 0x000071709ABDB3BD
000071709abd664a  movaps [r15+0x140], xmm15
000071709abd6652  movaps xmm13, xmm10
000071709abd6656  addpd xmm13, xmm14
000071709abd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000071709abd6661  ptest xmm12, xmm12
000071709abd6667  jnz 0x000071709ABDB501
000071709abd666d  movaps [r15+0x150], xmm13
000071709abd6675  movaps xmm14, xmm1
000071709abd6679  addpd xmm14, xmm7
000071709abd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000071709abd6684  ptest xmm12, xmm12
000071709abd668a  jnz 0x000071709ABDB645
000071709abd6690  movaps [r15+0x160], xmm14
000071709abd6698  movaps xmm1, xmm8
000071709abd669c  addpd xmm1, xmm9
000071709abd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000071709abd66a6  ptest xmm12, xmm12
000071709abd66ac  jnz 0x000071709ABDB787
000071709abd66b2  movaps [r15+0x120], xmm1
000071709abd66ba  movups [r13+r11*1], xmm15
000071709abd66c0  lea rax, [r11+0x10]
000071709abd66c4  movups [r13+rax*1], xmm13
000071709abd66ca  lea rax, [r11+0x20]
000071709abd66ce  movups [r13+rax*1], xmm14
000071709abd66d4  lea rax, [r11+0x30]
000071709abd66d8  movups [r13+rax*1], xmm1
000071709abd66de  mov eax, [r15+0x108]
000071709abd66e5  sahf
000071709abd66e6  jnz 0x000071709ABD6718
000071709abd66e8  cmp dword ptr [r15+0x318], 0x00
000071709abd66f0  jz 0x000071709ABDB900
000071709abd66f6  nop [rax+rax*1], ax
000071709abd66ff  nop [rax+rax*1], eax
000071709abd6707  mov eax, 0x410444
000071709abd670c  mov [r15+0x100], rax
000071709abd6713  jmp 0x000071709A9FE110
000071709abd6718  cmp dword ptr [r15+0x318], 0x00
000071709abd6720  jz 0x000071709ABD57E0
000071709abd6726  nop [rax+rax*1], ax
000071709abd672f  nop [rax+rax*1], eax
000071709abd6737  mov eax, 0x410278
000071709abd673c  mov [r15+0x100], rax
000071709abd6743  jmp 0x000071709A9FE110
000071709abd6748  int3
000071709abd6749  call 0x000071709AA0A4B0
000071709abd674e  jmp 0x000071709ABD5828
000071709abd6753  call 0x000071709AA09240
000071709abd6758  jmp 0x000071709ABD5832
000071709abd675d  call 0x000071709AA0A4B0
000071709abd6762  jmp 0x000071709ABD588F
000071709abd6767  call 0x000071709AA09240
000071709abd676c  jmp 0x000071709ABD5899
000071709abd6771  call 0x000071709AA0A4B0
000071709abd6776  jmp 0x000071709ABD58DD
000071709abd677b  call 0x000071709AA09240
000071709abd6780  jmp 0x000071709ABD58E7
000071709abd6785  call 0x000071709AAB47C0
000071709abd678a  jmp 0x000071709ABD5926
000071709abd678f  call 0x000071709AA0B720
000071709abd6794  jmp 0x000071709ABD593A
000071709abd6799  call 0x000071709AABFC30
000071709abd679e  jmp 0x000071709ABD5958
000071709abd67a3  call 0x000071709AABE9C0
000071709abd67a8  jmp 0x000071709ABD5962
000071709abd67ad  call 0x000071709AABD750
000071709abd67b2  jmp 0x000071709ABD596C
000071709abd67b7  sub rsp, 0x08
000071709abd67bb  push rax
000071709abd67bc  push rcx
000071709abd67bd  push rdx
000071709abd67be  push rdi
000071709abd67bf  push rsi
000071709abd67c0  push r8
000071709abd67c2  push r9
000071709abd67c4  push r10
000071709abd67c6  push r11
000071709abd67c8  sub rsp, 0xF0
000071709abd67cf  vmovaps [rsp], xmm0
000071709abd67d4  vmovaps [rsp+0x10], xmm1
000071709abd67da  vmovaps [rsp+0x20], xmm2
000071709abd67e0  vmovaps [rsp+0x30], xmm3
000071709abd67e6  vmovaps [rsp+0x40], xmm4
000071709abd67ec  vmovaps [rsp+0x50], xmm5
000071709abd67f2  vmovaps [rsp+0x60], xmm6
000071709abd67f8  vmovaps [rsp+0x70], xmm7
000071709abd67fe  vmovaps [rsp+0x80], xmm9
000071709abd6807  vmovaps [rsp+0x90], xmm10
000071709abd6810  vmovaps [rsp+0xA0], xmm11
000071709abd6819  vmovaps [rsp+0xB0], xmm12
000071709abd6822  vmovaps [rsp+0xC0], xmm13
000071709abd682b  vmovaps [rsp+0xD0], xmm14
000071709abd6834  vmovaps [rsp+0xE0], xmm15
000071709abd683d  sub rsp, 0x30
000071709abd6841  movaps [rsp], xmm8
000071709abd6846  movaps [rsp+0x10], xmm12
000071709abd684c  movaps [rsp+0x20], xmm15
000071709abd6852  lea rdi, [rsp]
000071709abd6856  mov esi, 0x00
000071709abd685b  mov rax, 0x60B9B2ABC530
000071709abd6865  call rax
000071709abd6867  movaps xmm8, [rsp]
000071709abd686c  add rsp, 0x30
000071709abd6870  vmovaps xmm0, [rsp]
000071709abd6875  vmovaps xmm1, [rsp+0x10]
000071709abd687b  vmovaps xmm2, [rsp+0x20]
000071709abd6881  vmovaps xmm3, [rsp+0x30]
000071709abd6887  vmovaps xmm4, [rsp+0x40]
000071709abd688d  vmovaps xmm5, [rsp+0x50]
000071709abd6893  vmovaps xmm6, [rsp+0x60]
000071709abd6899  vmovaps xmm7, [rsp+0x70]
000071709abd689f  vmovaps xmm9, [rsp+0x80]
000071709abd68a8  vmovaps xmm10, [rsp+0x90]
000071709abd68b1  vmovaps xmm11, [rsp+0xA0]
000071709abd68ba  vmovaps xmm12, [rsp+0xB0]
000071709abd68c3  vmovaps xmm13, [rsp+0xC0]
000071709abd68cc  vmovaps xmm14, [rsp+0xD0]
000071709abd68d5  vmovaps xmm15, [rsp+0xE0]
000071709abd68de  add rsp, 0xF0
000071709abd68e5  pop r11
000071709abd68e7  pop r10
000071709abd68e9  pop r9
000071709abd68eb  pop r8
000071709abd68ed  pop rsi
000071709abd68ee  pop rdi
000071709abd68ef  pop rdx
000071709abd68f0  pop rcx
000071709abd68f1  pop rax
000071709abd68f2  add rsp, 0x08
000071709abd68f6  jmp 0x000071709ABD599A
000071709abd68fb  sub rsp, 0x08
000071709abd68ff  push rax
000071709abd6900  push rcx
000071709abd6901  push rdx
000071709abd6902  push rdi
000071709abd6903  push rsi
000071709abd6904  push r8
000071709abd6906  push r9
000071709abd6908  push r10
000071709abd690a  push r11
000071709abd690c  sub rsp, 0xF0
000071709abd6913  vmovaps [rsp], xmm0
000071709abd6918  vmovaps [rsp+0x10], xmm1
000071709abd691e  vmovaps [rsp+0x20], xmm2
000071709abd6924  vmovaps [rsp+0x30], xmm3
000071709abd692a  vmovaps [rsp+0x40], xmm4
000071709abd6930  vmovaps [rsp+0x50], xmm5
000071709abd6936  vmovaps [rsp+0x60], xmm6
000071709abd693c  vmovaps [rsp+0x70], xmm8
000071709abd6942  vmovaps [rsp+0x80], xmm9
000071709abd694b  vmovaps [rsp+0x90], xmm10
000071709abd6954  vmovaps [rsp+0xA0], xmm11
000071709abd695d  vmovaps [rsp+0xB0], xmm12
000071709abd6966  vmovaps [rsp+0xC0], xmm13
000071709abd696f  vmovaps [rsp+0xD0], xmm14
000071709abd6978  vmovaps [rsp+0xE0], xmm15
000071709abd6981  sub rsp, 0x30
000071709abd6985  movaps [rsp], xmm7
000071709abd6989  movaps [rsp+0x10], xmm9
000071709abd698f  movaps [rsp+0x20], xmm15
000071709abd6995  lea rdi, [rsp]
000071709abd6999  mov esi, 0x00
000071709abd699e  mov rax, 0x60B9B2ABC530
000071709abd69a8  call rax
000071709abd69aa  movaps xmm7, [rsp]
000071709abd69ae  add rsp, 0x30
000071709abd69b2  vmovaps xmm0, [rsp]
000071709abd69b7  vmovaps xmm1, [rsp+0x10]
000071709abd69bd  vmovaps xmm2, [rsp+0x20]
000071709abd69c3  vmovaps xmm3, [rsp+0x30]
000071709abd69c9  vmovaps xmm4, [rsp+0x40]
000071709abd69cf  vmovaps xmm5, [rsp+0x50]
000071709abd69d5  vmovaps xmm6, [rsp+0x60]
000071709abd69db  vmovaps xmm8, [rsp+0x70]
000071709abd69e1  vmovaps xmm9, [rsp+0x80]
000071709abd69ea  vmovaps xmm10, [rsp+0x90]
000071709abd69f3  vmovaps xmm11, [rsp+0xA0]
000071709abd69fc  vmovaps xmm12, [rsp+0xB0]
000071709abd6a05  vmovaps xmm13, [rsp+0xC0]
000071709abd6a0e  vmovaps xmm14, [rsp+0xD0]
000071709abd6a17  vmovaps xmm15, [rsp+0xE0]
000071709abd6a20  add rsp, 0xF0
000071709abd6a27  pop r11
000071709abd6a29  pop r10
000071709abd6a2b  pop r9
000071709abd6a2d  pop r8
000071709abd6a2f  pop rsi
000071709abd6a30  pop rdi
000071709abd6a31  pop rdx
000071709abd6a32  pop rcx
000071709abd6a33  pop rax
000071709abd6a34  add rsp, 0x08
000071709abd6a38  jmp 0x000071709ABD59C8
000071709abd6a3d  sub rsp, 0x08
000071709abd6a41  push rax
000071709abd6a42  push rcx
000071709abd6a43  push rdx
000071709abd6a44  push rdi
000071709abd6a45  push rsi
000071709abd6a46  push r8
000071709abd6a48  push r9
000071709abd6a4a  push r10
000071709abd6a4c  push r11
000071709abd6a4e  sub rsp, 0xF0
000071709abd6a55  vmovaps [rsp], xmm0
000071709abd6a5a  vmovaps [rsp+0x10], xmm1
000071709abd6a60  vmovaps [rsp+0x20], xmm2
000071709abd6a66  vmovaps [rsp+0x30], xmm3
000071709abd6a6c  vmovaps [rsp+0x40], xmm4
000071709abd6a72  vmovaps [rsp+0x50], xmm5
000071709abd6a78  vmovaps [rsp+0x60], xmm6
000071709abd6a7e  vmovaps [rsp+0x70], xmm7
000071709abd6a84  vmovaps [rsp+0x80], xmm8
000071709abd6a8d  vmovaps [rsp+0x90], xmm10
000071709abd6a96  vmovaps [rsp+0xA0], xmm11
000071709abd6a9f  vmovaps [rsp+0xB0], xmm12
000071709abd6aa8  vmovaps [rsp+0xC0], xmm13
000071709abd6ab1  vmovaps [rsp+0xD0], xmm14
000071709abd6aba  vmovaps [rsp+0xE0], xmm15
000071709abd6ac3  sub rsp, 0x30
000071709abd6ac7  movaps [rsp], xmm9
000071709abd6acc  movaps [rsp+0x10], xmm12
000071709abd6ad2  movaps [rsp+0x20], xmm10
000071709abd6ad8  lea rdi, [rsp]
000071709abd6adc  mov esi, 0x00
000071709abd6ae1  mov rax, 0x60B9B2ABC530
000071709abd6aeb  call rax
000071709abd6aed  movaps xmm9, [rsp]
000071709abd6af2  add rsp, 0x30
000071709abd6af6  vmovaps xmm0, [rsp]
000071709abd6afb  vmovaps xmm1, [rsp+0x10]
000071709abd6b01  vmovaps xmm2, [rsp+0x20]
000071709abd6b07  vmovaps xmm3, [rsp+0x30]
000071709abd6b0d  vmovaps xmm4, [rsp+0x40]
000071709abd6b13  vmovaps xmm5, [rsp+0x50]
000071709abd6b19  vmovaps xmm6, [rsp+0x60]
000071709abd6b1f  vmovaps xmm7, [rsp+0x70]
000071709abd6b25  vmovaps xmm8, [rsp+0x80]
000071709abd6b2e  vmovaps xmm10, [rsp+0x90]
000071709abd6b37  vmovaps xmm11, [rsp+0xA0]
000071709abd6b40  vmovaps xmm12, [rsp+0xB0]
000071709abd6b49  vmovaps xmm13, [rsp+0xC0]
000071709abd6b52  vmovaps xmm14, [rsp+0xD0]
000071709abd6b5b  vmovaps xmm15, [rsp+0xE0]
000071709abd6b64  add rsp, 0xF0
000071709abd6b6b  pop r11
000071709abd6b6d  pop r10
000071709abd6b6f  pop r9
000071709abd6b71  pop r8
000071709abd6b73  pop rsi
000071709abd6b74  pop rdi
000071709abd6b75  pop rdx
000071709abd6b76  pop rcx
000071709abd6b77  pop rax
000071709abd6b78  add rsp, 0x08
000071709abd6b7c  jmp 0x000071709ABD59EC
000071709abd6b81  sub rsp, 0x08
000071709abd6b85  push rax
000071709abd6b86  push rcx
000071709abd6b87  push rdx
000071709abd6b88  push rdi
000071709abd6b89  push rsi
000071709abd6b8a  push r8
000071709abd6b8c  push r9
000071709abd6b8e  push r10
000071709abd6b90  push r11
000071709abd6b92  sub rsp, 0xF0
000071709abd6b99  vmovaps [rsp], xmm0
000071709abd6b9e  vmovaps [rsp+0x10], xmm1
000071709abd6ba4  vmovaps [rsp+0x20], xmm2
000071709abd6baa  vmovaps [rsp+0x30], xmm3
000071709abd6bb0  vmovaps [rsp+0x40], xmm4
000071709abd6bb6  vmovaps [rsp+0x50], xmm5
000071709abd6bbc  vmovaps [rsp+0x60], xmm6
000071709abd6bc2  vmovaps [rsp+0x70], xmm7
000071709abd6bc8  vmovaps [rsp+0x80], xmm8
000071709abd6bd1  vmovaps [rsp+0x90], xmm9
000071709abd6bda  vmovaps [rsp+0xA0], xmm11
000071709abd6be3  vmovaps [rsp+0xB0], xmm12
000071709abd6bec  vmovaps [rsp+0xC0], xmm13
000071709abd6bf5  vmovaps [rsp+0xD0], xmm14
000071709abd6bfe  vmovaps [rsp+0xE0], xmm15
000071709abd6c07  sub rsp, 0x30
000071709abd6c0b  movaps [rsp], xmm10
000071709abd6c10  movaps [rsp+0x10], xmm12
000071709abd6c16  movaps [rsp+0x20], xmm11
000071709abd6c1c  lea rdi, [rsp]
000071709abd6c20  mov esi, 0x00
000071709abd6c25  mov rax, 0x60B9B2ABC530
000071709abd6c2f  call rax
000071709abd6c31  movaps xmm10, [rsp]
000071709abd6c36  add rsp, 0x30
000071709abd6c3a  vmovaps xmm0, [rsp]
000071709abd6c3f  vmovaps xmm1, [rsp+0x10]
000071709abd6c45  vmovaps xmm2, [rsp+0x20]
000071709abd6c4b  vmovaps xmm3, [rsp+0x30]
000071709abd6c51  vmovaps xmm4, [rsp+0x40]
000071709abd6c57  vmovaps xmm5, [rsp+0x50]
000071709abd6c5d  vmovaps xmm6, [rsp+0x60]
000071709abd6c63  vmovaps xmm7, [rsp+0x70]
000071709abd6c69  vmovaps xmm8, [rsp+0x80]
000071709abd6c72  vmovaps xmm9, [rsp+0x90]
000071709abd6c7b  vmovaps xmm11, [rsp+0xA0]
000071709abd6c84  vmovaps xmm12, [rsp+0xB0]
000071709abd6c8d  vmovaps xmm13, [rsp+0xC0]
000071709abd6c96  vmovaps xmm14, [rsp+0xD0]
000071709abd6c9f  vmovaps xmm15, [rsp+0xE0]
000071709abd6ca8  add rsp, 0xF0
000071709abd6caf  pop r11
000071709abd6cb1  pop r10
000071709abd6cb3  pop r9
000071709abd6cb5  pop r8
000071709abd6cb7  pop rsi
000071709abd6cb8  pop rdi
000071709abd6cb9  pop rdx
000071709abd6cba  pop rcx
000071709abd6cbb  pop rax
000071709abd6cbc  add rsp, 0x08
000071709abd6cc0  jmp 0x000071709ABD5A06
000071709abd6cc5  sub rsp, 0x08
000071709abd6cc9  push rax
000071709abd6cca  push rcx
000071709abd6ccb  push rdx
000071709abd6ccc  push rdi
000071709abd6ccd  push rsi
000071709abd6cce  push r8
000071709abd6cd0  push r9
000071709abd6cd2  push r10
000071709abd6cd4  push r11
000071709abd6cd6  sub rsp, 0xF0
000071709abd6cdd  vmovaps [rsp], xmm0
000071709abd6ce2  vmovaps [rsp+0x10], xmm1
000071709abd6ce8  vmovaps [rsp+0x20], xmm2
000071709abd6cee  vmovaps [rsp+0x30], xmm3
000071709abd6cf4  vmovaps [rsp+0x40], xmm4
000071709abd6cfa  vmovaps [rsp+0x50], xmm5
000071709abd6d00  vmovaps [rsp+0x60], xmm7
000071709abd6d06  vmovaps [rsp+0x70], xmm8
000071709abd6d0c  vmovaps [rsp+0x80], xmm9
000071709abd6d15  vmovaps [rsp+0x90], xmm10
000071709abd6d1e  vmovaps [rsp+0xA0], xmm11
000071709abd6d27  vmovaps [rsp+0xB0], xmm12
000071709abd6d30  vmovaps [rsp+0xC0], xmm13
000071709abd6d39  vmovaps [rsp+0xD0], xmm14
000071709abd6d42  vmovaps [rsp+0xE0], xmm15
000071709abd6d4b  sub rsp, 0x30
000071709abd6d4f  movaps [rsp], xmm6
000071709abd6d53  movaps [rsp+0x10], xmm12
000071709abd6d59  movaps [rsp+0x20], xmm11
000071709abd6d5f  lea rdi, [rsp]
000071709abd6d63  mov esi, 0x00
000071709abd6d68  mov rax, 0x60B9B2ABC530
000071709abd6d72  call rax
000071709abd6d74  movaps xmm6, [rsp]
000071709abd6d78  add rsp, 0x30
000071709abd6d7c  vmovaps xmm0, [rsp]
000071709abd6d81  vmovaps xmm1, [rsp+0x10]
000071709abd6d87  vmovaps xmm2, [rsp+0x20]
000071709abd6d8d  vmovaps xmm3, [rsp+0x30]
000071709abd6d93  vmovaps xmm4, [rsp+0x40]
000071709abd6d99  vmovaps xmm5, [rsp+0x50]
000071709abd6d9f  vmovaps xmm7, [rsp+0x60]
000071709abd6da5  vmovaps xmm8, [rsp+0x70]
000071709abd6dab  vmovaps xmm9, [rsp+0x80]
000071709abd6db4  vmovaps xmm10, [rsp+0x90]
000071709abd6dbd  vmovaps xmm11, [rsp+0xA0]
000071709abd6dc6  vmovaps xmm12, [rsp+0xB0]
000071709abd6dcf  vmovaps xmm13, [rsp+0xC0]
000071709abd6dd8  vmovaps xmm14, [rsp+0xD0]
000071709abd6de1  vmovaps xmm15, [rsp+0xE0]
000071709abd6dea  add rsp, 0xF0
000071709abd6df1  pop r11
000071709abd6df3  pop r10
000071709abd6df5  pop r9
000071709abd6df7  pop r8
000071709abd6df9  pop rsi
000071709abd6dfa  pop rdi
000071709abd6dfb  pop rdx
000071709abd6dfc  pop rcx
000071709abd6dfd  pop rax
000071709abd6dfe  add rsp, 0x08
000071709abd6e02  jmp 0x000071709ABD5A27
000071709abd6e07  sub rsp, 0x08
000071709abd6e0b  push rax
000071709abd6e0c  push rcx
000071709abd6e0d  push rdx
000071709abd6e0e  push rdi
000071709abd6e0f  push rsi
000071709abd6e10  push r8
000071709abd6e12  push r9
000071709abd6e14  push r10
000071709abd6e16  push r11
000071709abd6e18  sub rsp, 0xF0
000071709abd6e1f  vmovaps [rsp], xmm0
000071709abd6e24  vmovaps [rsp+0x10], xmm1
000071709abd6e2a  vmovaps [rsp+0x20], xmm2
000071709abd6e30  vmovaps [rsp+0x30], xmm4
000071709abd6e36  vmovaps [rsp+0x40], xmm5
000071709abd6e3c  vmovaps [rsp+0x50], xmm6
000071709abd6e42  vmovaps [rsp+0x60], xmm7
000071709abd6e48  vmovaps [rsp+0x70], xmm8
000071709abd6e4e  vmovaps [rsp+0x80], xmm9
000071709abd6e57  vmovaps [rsp+0x90], xmm10
000071709abd6e60  vmovaps [rsp+0xA0], xmm11
000071709abd6e69  vmovaps [rsp+0xB0], xmm12
000071709abd6e72  vmovaps [rsp+0xC0], xmm13
000071709abd6e7b  vmovaps [rsp+0xD0], xmm14
000071709abd6e84  vmovaps [rsp+0xE0], xmm15
000071709abd6e8d  sub rsp, 0x30
000071709abd6e91  movaps [rsp], xmm3
000071709abd6e95  movaps [rsp+0x10], xmm5
000071709abd6e9a  movaps [rsp+0x20], xmm4
000071709abd6e9f  lea rdi, [rsp]
000071709abd6ea3  mov esi, 0x00
000071709abd6ea8  mov rax, 0x60B9B2ABC530
000071709abd6eb2  call rax
000071709abd6eb4  movaps xmm3, [rsp]
000071709abd6eb8  add rsp, 0x30
000071709abd6ebc  vmovaps xmm0, [rsp]
000071709abd6ec1  vmovaps xmm1, [rsp+0x10]
000071709abd6ec7  vmovaps xmm2, [rsp+0x20]
000071709abd6ecd  vmovaps xmm4, [rsp+0x30]
000071709abd6ed3  vmovaps xmm5, [rsp+0x40]
000071709abd6ed9  vmovaps xmm6, [rsp+0x50]
000071709abd6edf  vmovaps xmm7, [rsp+0x60]
000071709abd6ee5  vmovaps xmm8, [rsp+0x70]
000071709abd6eeb  vmovaps xmm9, [rsp+0x80]
000071709abd6ef4  vmovaps xmm10, [rsp+0x90]
000071709abd6efd  vmovaps xmm11, [rsp+0xA0]
000071709abd6f06  vmovaps xmm12, [rsp+0xB0]
000071709abd6f0f  vmovaps xmm13, [rsp+0xC0]
000071709abd6f18  vmovaps xmm14, [rsp+0xD0]
000071709abd6f21  vmovaps xmm15, [rsp+0xE0]
000071709abd6f2a  add rsp, 0xF0
000071709abd6f31  pop r11
000071709abd6f33  pop r10
000071709abd6f35  pop r9
000071709abd6f37  pop r8
000071709abd6f39  pop rsi
000071709abd6f3a  pop rdi
000071709abd6f3b  pop rdx
000071709abd6f3c  pop rcx
000071709abd6f3d  pop rax
000071709abd6f3e  add rsp, 0x08
000071709abd6f42  jmp 0x000071709ABD5A88
000071709abd6f47  sub rsp, 0x08
000071709abd6f4b  push rax
000071709abd6f4c  push rcx
000071709abd6f4d  push rdx
000071709abd6f4e  push rdi
000071709abd6f4f  push rsi
000071709abd6f50  push r8
000071709abd6f52  push r9
000071709abd6f54  push r10
000071709abd6f56  push r11
000071709abd6f58  sub rsp, 0xF0
000071709abd6f5f  vmovaps [rsp], xmm0
000071709abd6f64  vmovaps [rsp+0x10], xmm1
000071709abd6f6a  vmovaps [rsp+0x20], xmm2
000071709abd6f70  vmovaps [rsp+0x30], xmm3
000071709abd6f76  vmovaps [rsp+0x40], xmm4
000071709abd6f7c  vmovaps [rsp+0x50], xmm6
000071709abd6f82  vmovaps [rsp+0x60], xmm7
000071709abd6f88  vmovaps [rsp+0x70], xmm8
000071709abd6f8e  vmovaps [rsp+0x80], xmm9
000071709abd6f97  vmovaps [rsp+0x90], xmm10
000071709abd6fa0  vmovaps [rsp+0xA0], xmm11
000071709abd6fa9  vmovaps [rsp+0xB0], xmm12
000071709abd6fb2  vmovaps [rsp+0xC0], xmm13
000071709abd6fbb  vmovaps [rsp+0xD0], xmm14
000071709abd6fc4  vmovaps [rsp+0xE0], xmm15
000071709abd6fcd  sub rsp, 0x30
000071709abd6fd1  movaps [rsp], xmm5
000071709abd6fd5  movaps [rsp+0x10], xmm8
000071709abd6fdb  movaps [rsp+0x20], xmm15
000071709abd6fe1  lea rdi, [rsp]
000071709abd6fe5  mov esi, 0x00
000071709abd6fea  mov rax, 0x60B9B2ABC530
000071709abd6ff4  call rax
000071709abd6ff6  movaps xmm5, [rsp]
000071709abd6ffa  add rsp, 0x30
000071709abd6ffe  vmovaps xmm0, [rsp]
000071709abd7003  vmovaps xmm1, [rsp+0x10]
000071709abd7009  vmovaps xmm2, [rsp+0x20]
000071709abd700f  vmovaps xmm3, [rsp+0x30]
000071709abd7015  vmovaps xmm4, [rsp+0x40]
000071709abd701b  vmovaps xmm6, [rsp+0x50]
000071709abd7021  vmovaps xmm7, [rsp+0x60]
000071709abd7027  vmovaps xmm8, [rsp+0x70]
000071709abd702d  vmovaps xmm9, [rsp+0x80]
000071709abd7036  vmovaps xmm10, [rsp+0x90]
000071709abd703f  vmovaps xmm11, [rsp+0xA0]
000071709abd7048  vmovaps xmm12, [rsp+0xB0]
000071709abd7051  vmovaps xmm13, [rsp+0xC0]
000071709abd705a  vmovaps xmm14, [rsp+0xD0]
000071709abd7063  vmovaps xmm15, [rsp+0xE0]
000071709abd706c  add rsp, 0xF0
000071709abd7073  pop r11
000071709abd7075  pop r10
000071709abd7077  pop r9
000071709abd7079  pop r8
000071709abd707b  pop rsi
000071709abd707c  pop rdi
000071709abd707d  pop rdx
000071709abd707e  pop rcx
000071709abd707f  pop rax
000071709abd7080  add rsp, 0x08
000071709abd7084  jmp 0x000071709ABD5AC0
000071709abd7089  sub rsp, 0x08
000071709abd708d  push rax
000071709abd708e  push rcx
000071709abd708f  push rdx
000071709abd7090  push rdi
000071709abd7091  push rsi
000071709abd7092  push r8
000071709abd7094  push r9
000071709abd7096  push r10
000071709abd7098  push r11
000071709abd709a  sub rsp, 0xF0
000071709abd70a1  vmovaps [rsp], xmm0
000071709abd70a6  vmovaps [rsp+0x10], xmm1
000071709abd70ac  vmovaps [rsp+0x20], xmm2
000071709abd70b2  vmovaps [rsp+0x30], xmm3
000071709abd70b8  vmovaps [rsp+0x40], xmm5
000071709abd70be  vmovaps [rsp+0x50], xmm6
000071709abd70c4  vmovaps [rsp+0x60], xmm7
000071709abd70ca  vmovaps [rsp+0x70], xmm8
000071709abd70d0  vmovaps [rsp+0x80], xmm9
000071709abd70d9  vmovaps [rsp+0x90], xmm10
000071709abd70e2  vmovaps [rsp+0xA0], xmm11
000071709abd70eb  vmovaps [rsp+0xB0], xmm12
000071709abd70f4  vmovaps [rsp+0xC0], xmm13
000071709abd70fd  vmovaps [rsp+0xD0], xmm14
000071709abd7106  vmovaps [rsp+0xE0], xmm15
000071709abd710f  sub rsp, 0x30
000071709abd7113  movaps [rsp], xmm4
000071709abd7117  movaps [rsp+0x10], xmm9
000071709abd711d  movaps [rsp+0x20], xmm8
000071709abd7123  lea rdi, [rsp]
000071709abd7127  mov esi, 0x00
000071709abd712c  mov rax, 0x60B9B2ABC530
000071709abd7136  call rax
000071709abd7138  movaps xmm4, [rsp]
000071709abd713c  add rsp, 0x30
000071709abd7140  vmovaps xmm0, [rsp]
000071709abd7145  vmovaps xmm1, [rsp+0x10]
000071709abd714b  vmovaps xmm2, [rsp+0x20]
000071709abd7151  vmovaps xmm3, [rsp+0x30]
000071709abd7157  vmovaps xmm5, [rsp+0x40]
000071709abd715d  vmovaps xmm6, [rsp+0x50]
000071709abd7163  vmovaps xmm7, [rsp+0x60]
000071709abd7169  vmovaps xmm8, [rsp+0x70]
000071709abd716f  vmovaps xmm9, [rsp+0x80]
000071709abd7178  vmovaps xmm10, [rsp+0x90]
000071709abd7181  vmovaps xmm11, [rsp+0xA0]
000071709abd718a  vmovaps xmm12, [rsp+0xB0]
000071709abd7193  vmovaps xmm13, [rsp+0xC0]
000071709abd719c  vmovaps xmm14, [rsp+0xD0]
000071709abd71a5  vmovaps xmm15, [rsp+0xE0]
000071709abd71ae  add rsp, 0xF0
000071709abd71b5  pop r11
000071709abd71b7  pop r10
000071709abd71b9  pop r9
000071709abd71bb  pop r8
000071709abd71bd  pop rsi
000071709abd71be  pop rdi
000071709abd71bf  pop rdx
000071709abd71c0  pop rcx
000071709abd71c1  pop rax
000071709abd71c2  add rsp, 0x08
000071709abd71c6  jmp 0x000071709ABD5AE1
000071709abd71cb  sub rsp, 0x08
000071709abd71cf  push rax
000071709abd71d0  push rcx
000071709abd71d1  push rdx
000071709abd71d2  push rdi
000071709abd71d3  push rsi
000071709abd71d4  push r8
000071709abd71d6  push r9
000071709abd71d8  push r10
000071709abd71da  push r11
000071709abd71dc  sub rsp, 0xF0
000071709abd71e3  vmovaps [rsp], xmm0
000071709abd71e8  vmovaps [rsp+0x10], xmm1
000071709abd71ee  vmovaps [rsp+0x20], xmm2
000071709abd71f4  vmovaps [rsp+0x30], xmm3
000071709abd71fa  vmovaps [rsp+0x40], xmm4
000071709abd7200  vmovaps [rsp+0x50], xmm5
000071709abd7206  vmovaps [rsp+0x60], xmm6
000071709abd720c  vmovaps [rsp+0x70], xmm7
000071709abd7212  vmovaps [rsp+0x80], xmm8
000071709abd721b  vmovaps [rsp+0x90], xmm10
000071709abd7224  vmovaps [rsp+0xA0], xmm11
000071709abd722d  vmovaps [rsp+0xB0], xmm12
000071709abd7236  vmovaps [rsp+0xC0], xmm13
000071709abd723f  vmovaps [rsp+0xD0], xmm14
000071709abd7248  vmovaps [rsp+0xE0], xmm15
000071709abd7251  sub rsp, 0x30
000071709abd7255  movaps [rsp], xmm9
000071709abd725a  movaps [rsp+0x10], xmm10
000071709abd7260  movaps [rsp+0x20], xmm8
000071709abd7266  lea rdi, [rsp]
000071709abd726a  mov esi, 0x00
000071709abd726f  mov rax, 0x60B9B2ABC530
000071709abd7279  call rax
000071709abd727b  movaps xmm9, [rsp]
000071709abd7280  add rsp, 0x30
000071709abd7284  vmovaps xmm0, [rsp]
000071709abd7289  vmovaps xmm1, [rsp+0x10]
000071709abd728f  vmovaps xmm2, [rsp+0x20]
000071709abd7295  vmovaps xmm3, [rsp+0x30]
000071709abd729b  vmovaps xmm4, [rsp+0x40]
000071709abd72a1  vmovaps xmm5, [rsp+0x50]
000071709abd72a7  vmovaps xmm6, [rsp+0x60]
000071709abd72ad  vmovaps xmm7, [rsp+0x70]
000071709abd72b3  vmovaps xmm8, [rsp+0x80]
000071709abd72bc  vmovaps xmm10, [rsp+0x90]
000071709abd72c5  vmovaps xmm11, [rsp+0xA0]
000071709abd72ce  vmovaps xmm12, [rsp+0xB0]
000071709abd72d7  vmovaps xmm13, [rsp+0xC0]
000071709abd72e0  vmovaps xmm14, [rsp+0xD0]
000071709abd72e9  vmovaps xmm15, [rsp+0xE0]
000071709abd72f2  add rsp, 0xF0
000071709abd72f9  pop r11
000071709abd72fb  pop r10
000071709abd72fd  pop r9
000071709abd72ff  pop r8
000071709abd7301  pop rsi
000071709abd7302  pop rdi
000071709abd7303  pop rdx
000071709abd7304  pop rcx
000071709abd7305  pop rax
000071709abd7306  add rsp, 0x08
000071709abd730a  jmp 0x000071709ABD5AFB
000071709abd730f  call 0x000071709AAD64F0
000071709abd7314  jmp 0x000071709ABD5C15
000071709abd7319  call 0x000071709AAD64F0
000071709abd731e  jmp 0x000071709ABD5C2B
000071709abd7323  sub rsp, 0x08
000071709abd7327  push rax
000071709abd7328  push rcx
000071709abd7329  push rdx
000071709abd732a  push rdi
000071709abd732b  push rsi
000071709abd732c  push r8
000071709abd732e  push r9
000071709abd7330  push r10
000071709abd7332  push r11
000071709abd7334  sub rsp, 0xF0
000071709abd733b  vmovaps [rsp], xmm0
000071709abd7340  vmovaps [rsp+0x10], xmm2
000071709abd7346  vmovaps [rsp+0x20], xmm3
000071709abd734c  vmovaps [rsp+0x30], xmm4
000071709abd7352  vmovaps [rsp+0x40], xmm5
000071709abd7358  vmovaps [rsp+0x50], xmm6
000071709abd735e  vmovaps [rsp+0x60], xmm7
000071709abd7364  vmovaps [rsp+0x70], xmm8
000071709abd736a  vmovaps [rsp+0x80], xmm9
000071709abd7373  vmovaps [rsp+0x90], xmm10
000071709abd737c  vmovaps [rsp+0xA0], xmm11
000071709abd7385  vmovaps [rsp+0xB0], xmm12
000071709abd738e  vmovaps [rsp+0xC0], xmm13
000071709abd7397  vmovaps [rsp+0xD0], xmm14
000071709abd73a0  vmovaps [rsp+0xE0], xmm15
000071709abd73a9  sub rsp, 0x30
000071709abd73ad  movaps [rsp], xmm1
000071709abd73b1  movaps [rsp+0x10], xmm6
000071709abd73b6  movaps [rsp+0x20], xmm15
000071709abd73bc  lea rdi, [rsp]
000071709abd73c0  mov esi, 0x00
000071709abd73c5  mov rax, 0x60B9B2ABC530
000071709abd73cf  call rax
000071709abd73d1  movaps xmm1, [rsp]
000071709abd73d5  add rsp, 0x30
000071709abd73d9  vmovaps xmm0, [rsp]
000071709abd73de  vmovaps xmm2, [rsp+0x10]
000071709abd73e4  vmovaps xmm3, [rsp+0x20]
000071709abd73ea  vmovaps xmm4, [rsp+0x30]
000071709abd73f0  vmovaps xmm5, [rsp+0x40]
000071709abd73f6  vmovaps xmm6, [rsp+0x50]
000071709abd73fc  vmovaps xmm7, [rsp+0x60]
000071709abd7402  vmovaps xmm8, [rsp+0x70]
000071709abd7408  vmovaps xmm9, [rsp+0x80]
000071709abd7411  vmovaps xmm10, [rsp+0x90]
000071709abd741a  vmovaps xmm11, [rsp+0xA0]
000071709abd7423  vmovaps xmm12, [rsp+0xB0]
000071709abd742c  vmovaps xmm13, [rsp+0xC0]
000071709abd7435  vmovaps xmm14, [rsp+0xD0]
000071709abd743e  vmovaps xmm15, [rsp+0xE0]
000071709abd7447  add rsp, 0xF0
000071709abd744e  pop r11
000071709abd7450  pop r10
000071709abd7452  pop r9
000071709abd7454  pop r8
000071709abd7456  pop rsi
000071709abd7457  pop rdi
000071709abd7458  pop rdx
000071709abd7459  pop rcx
000071709abd745a  pop rax
000071709abd745b  add rsp, 0x08
000071709abd745f  jmp 0x000071709ABD5C68
000071709abd7464  call 0x000071709AAE5820
000071709abd7469  jmp 0x000071709ABD5C75
000071709abd746e  sub rsp, 0x08
000071709abd7472  push rax
000071709abd7473  push rcx
000071709abd7474  push rdx
000071709abd7475  push rdi
000071709abd7476  push rsi
000071709abd7477  push r8
000071709abd7479  push r9
000071709abd747b  push r10
000071709abd747d  push r11
000071709abd747f  sub rsp, 0xF0
000071709abd7486  vmovaps [rsp], xmm0
000071709abd748b  vmovaps [rsp+0x10], xmm1
000071709abd7491  vmovaps [rsp+0x20], xmm2
000071709abd7497  vmovaps [rsp+0x30], xmm3
000071709abd749d  vmovaps [rsp+0x40], xmm4
000071709abd74a3  vmovaps [rsp+0x50], xmm5
000071709abd74a9  vmovaps [rsp+0x60], xmm6
000071709abd74af  vmovaps [rsp+0x70], xmm7
000071709abd74b5  vmovaps [rsp+0x80], xmm8
000071709abd74be  vmovaps [rsp+0x90], xmm9
000071709abd74c7  vmovaps [rsp+0xA0], xmm10
000071709abd74d0  vmovaps [rsp+0xB0], xmm11
000071709abd74d9  vmovaps [rsp+0xC0], xmm12
000071709abd74e2  vmovaps [rsp+0xD0], xmm13
000071709abd74eb  vmovaps [rsp+0xE0], xmm15
000071709abd74f4  sub rsp, 0x30
000071709abd74f8  movaps [rsp], xmm14
000071709abd74fd  movaps [rsp+0x10], xmm4
000071709abd7502  movaps [rsp+0x20], xmm3
000071709abd7507  lea rdi, [rsp]
000071709abd750b  mov esi, 0x00
000071709abd7510  mov rax, 0x60B9B2ABC530
000071709abd751a  call rax
000071709abd751c  movaps xmm14, [rsp]
000071709abd7521  add rsp, 0x30
000071709abd7525  vmovaps xmm0, [rsp]
000071709abd752a  vmovaps xmm1, [rsp+0x10]
000071709abd7530  vmovaps xmm2, [rsp+0x20]
000071709abd7536  vmovaps xmm3, [rsp+0x30]
000071709abd753c  vmovaps xmm4, [rsp+0x40]
000071709abd7542  vmovaps xmm5, [rsp+0x50]
000071709abd7548  vmovaps xmm6, [rsp+0x60]
000071709abd754e  vmovaps xmm7, [rsp+0x70]
000071709abd7554  vmovaps xmm8, [rsp+0x80]
000071709abd755d  vmovaps xmm9, [rsp+0x90]
000071709abd7566  vmovaps xmm10, [rsp+0xA0]
000071709abd756f  vmovaps xmm11, [rsp+0xB0]
000071709abd7578  vmovaps xmm12, [rsp+0xC0]
000071709abd7581  vmovaps xmm13, [rsp+0xD0]
000071709abd758a  vmovaps xmm15, [rsp+0xE0]
000071709abd7593  add rsp, 0xF0
000071709abd759a  pop r11
000071709abd759c  pop r10
000071709abd759e  pop r9
000071709abd75a0  pop r8
000071709abd75a2  pop rsi
000071709abd75a3  pop rdi
000071709abd75a4  pop rdx
000071709abd75a5  pop rcx
000071709abd75a6  pop rax
000071709abd75a7  add rsp, 0x08
000071709abd75ab  jmp 0x000071709ABD5C8F
000071709abd75b0  sub rsp, 0x08
000071709abd75b4  push rax
000071709abd75b5  push rcx
000071709abd75b6  push rdx
000071709abd75b7  push rdi
000071709abd75b8  push rsi
000071709abd75b9  push r8
000071709abd75bb  push r9
000071709abd75bd  push r10
000071709abd75bf  push r11
000071709abd75c1  sub rsp, 0xF0
000071709abd75c8  vmovaps [rsp], xmm0
000071709abd75cd  vmovaps [rsp+0x10], xmm1
000071709abd75d3  vmovaps [rsp+0x20], xmm2
000071709abd75d9  vmovaps [rsp+0x30], xmm3
000071709abd75df  vmovaps [rsp+0x40], xmm4
000071709abd75e5  vmovaps [rsp+0x50], xmm5
000071709abd75eb  vmovaps [rsp+0x60], xmm7
000071709abd75f1  vmovaps [rsp+0x70], xmm8
000071709abd75f7  vmovaps [rsp+0x80], xmm9
000071709abd7600  vmovaps [rsp+0x90], xmm10
000071709abd7609  vmovaps [rsp+0xA0], xmm11
000071709abd7612  vmovaps [rsp+0xB0], xmm12
000071709abd761b  vmovaps [rsp+0xC0], xmm13
000071709abd7624  vmovaps [rsp+0xD0], xmm14
000071709abd762d  vmovaps [rsp+0xE0], xmm15
000071709abd7636  sub rsp, 0x30
000071709abd763a  movaps [rsp], xmm6
000071709abd763e  movaps [rsp+0x10], xmm9
000071709abd7644  movaps [rsp+0x20], xmm7
000071709abd7649  lea rdi, [rsp]
000071709abd764d  mov esi, 0x00
000071709abd7652  mov rax, 0x60B9B2ABC530
000071709abd765c  call rax
000071709abd765e  movaps xmm6, [rsp]
000071709abd7662  add rsp, 0x30
000071709abd7666  vmovaps xmm0, [rsp]
000071709abd766b  vmovaps xmm1, [rsp+0x10]
000071709abd7671  vmovaps xmm2, [rsp+0x20]
000071709abd7677  vmovaps xmm3, [rsp+0x30]
000071709abd767d  vmovaps xmm4, [rsp+0x40]
000071709abd7683  vmovaps xmm5, [rsp+0x50]
000071709abd7689  vmovaps xmm7, [rsp+0x60]
000071709abd768f  vmovaps xmm8, [rsp+0x70]
000071709abd7695  vmovaps xmm9, [rsp+0x80]
000071709abd769e  vmovaps xmm10, [rsp+0x90]
000071709abd76a7  vmovaps xmm11, [rsp+0xA0]
000071709abd76b0  vmovaps xmm12, [rsp+0xB0]
000071709abd76b9  vmovaps xmm13, [rsp+0xC0]
000071709abd76c2  vmovaps xmm14, [rsp+0xD0]
000071709abd76cb  vmovaps xmm15, [rsp+0xE0]
000071709abd76d4  add rsp, 0xF0
000071709abd76db  pop r11
000071709abd76dd  pop r10
000071709abd76df  pop r9
000071709abd76e1  pop r8
000071709abd76e3  pop rsi
000071709abd76e4  pop rdi
000071709abd76e5  pop rdx
000071709abd76e6  pop rcx
000071709abd76e7  pop rax
000071709abd76e8  add rsp, 0x08
000071709abd76ec  jmp 0x000071709ABD5CA7
000071709abd76f1  sub rsp, 0x08
000071709abd76f5  push rax
000071709abd76f6  push rcx
000071709abd76f7  push rdx
000071709abd76f8  push rdi
000071709abd76f9  push rsi
000071709abd76fa  push r8
000071709abd76fc  push r9
000071709abd76fe  push r10
000071709abd7700  push r11
000071709abd7702  sub rsp, 0xF0
000071709abd7709  vmovaps [rsp], xmm0
000071709abd770e  vmovaps [rsp+0x10], xmm1
000071709abd7714  vmovaps [rsp+0x20], xmm2
000071709abd771a  vmovaps [rsp+0x30], xmm3
000071709abd7720  vmovaps [rsp+0x40], xmm4
000071709abd7726  vmovaps [rsp+0x50], xmm5
000071709abd772c  vmovaps [rsp+0x60], xmm6
000071709abd7732  vmovaps [rsp+0x70], xmm8
000071709abd7738  vmovaps [rsp+0x80], xmm9
000071709abd7741  vmovaps [rsp+0x90], xmm10
000071709abd774a  vmovaps [rsp+0xA0], xmm11
000071709abd7753  vmovaps [rsp+0xB0], xmm12
000071709abd775c  vmovaps [rsp+0xC0], xmm13
000071709abd7765  vmovaps [rsp+0xD0], xmm14
000071709abd776e  vmovaps [rsp+0xE0], xmm15
000071709abd7777  sub rsp, 0x30
000071709abd777b  movaps [rsp], xmm7
000071709abd777f  movaps [rsp+0x10], xmm4
000071709abd7784  movaps [rsp+0x20], xmm9
000071709abd778a  lea rdi, [rsp]
000071709abd778e  mov esi, 0x00
000071709abd7793  mov rax, 0x60B9B2ABC530
000071709abd779d  call rax
000071709abd779f  movaps xmm7, [rsp]
000071709abd77a3  add rsp, 0x30
000071709abd77a7  vmovaps xmm0, [rsp]
000071709abd77ac  vmovaps xmm1, [rsp+0x10]
000071709abd77b2  vmovaps xmm2, [rsp+0x20]
000071709abd77b8  vmovaps xmm3, [rsp+0x30]
000071709abd77be  vmovaps xmm4, [rsp+0x40]
000071709abd77c4  vmovaps xmm5, [rsp+0x50]
000071709abd77ca  vmovaps xmm6, [rsp+0x60]
000071709abd77d0  vmovaps xmm8, [rsp+0x70]
000071709abd77d6  vmovaps xmm9, [rsp+0x80]
000071709abd77df  vmovaps xmm10, [rsp+0x90]
000071709abd77e8  vmovaps xmm11, [rsp+0xA0]
000071709abd77f1  vmovaps xmm12, [rsp+0xB0]
000071709abd77fa  vmovaps xmm13, [rsp+0xC0]
000071709abd7803  vmovaps xmm14, [rsp+0xD0]
000071709abd780c  vmovaps xmm15, [rsp+0xE0]
000071709abd7815  add rsp, 0xF0
000071709abd781c  pop r11
000071709abd781e  pop r10
000071709abd7820  pop r9
000071709abd7822  pop r8
000071709abd7824  pop rsi
000071709abd7825  pop rdi
000071709abd7826  pop rdx
000071709abd7827  pop rcx
000071709abd7828  pop rax
000071709abd7829  add rsp, 0x08
000071709abd782d  jmp 0x000071709ABD5CD4
000071709abd7832  sub rsp, 0x08
000071709abd7836  push rax
000071709abd7837  push rcx
000071709abd7838  push rdx
000071709abd7839  push rdi
000071709abd783a  push rsi
000071709abd783b  push r8
000071709abd783d  push r9
000071709abd783f  push r10
000071709abd7841  push r11
000071709abd7843  sub rsp, 0xF0
000071709abd784a  vmovaps [rsp], xmm0
000071709abd784f  vmovaps [rsp+0x10], xmm1
000071709abd7855  vmovaps [rsp+0x20], xmm2
000071709abd785b  vmovaps [rsp+0x30], xmm3
000071709abd7861  vmovaps [rsp+0x40], xmm5
000071709abd7867  vmovaps [rsp+0x50], xmm6
000071709abd786d  vmovaps [rsp+0x60], xmm7
000071709abd7873  vmovaps [rsp+0x70], xmm8
000071709abd7879  vmovaps [rsp+0x80], xmm9
000071709abd7882  vmovaps [rsp+0x90], xmm10
000071709abd788b  vmovaps [rsp+0xA0], xmm11
000071709abd7894  vmovaps [rsp+0xB0], xmm12
000071709abd789d  vmovaps [rsp+0xC0], xmm13
000071709abd78a6  vmovaps [rsp+0xD0], xmm14
000071709abd78af  vmovaps [rsp+0xE0], xmm15
000071709abd78b8  sub rsp, 0x30
000071709abd78bc  movaps [rsp], xmm4
000071709abd78c0  movaps [rsp+0x10], xmm15
000071709abd78c6  movaps [rsp+0x20], xmm9
000071709abd78cc  lea rdi, [rsp]
000071709abd78d0  mov esi, 0x00
000071709abd78d5  mov rax, 0x60B9B2ABC530
000071709abd78df  call rax
000071709abd78e1  movaps xmm4, [rsp]
000071709abd78e5  add rsp, 0x30
000071709abd78e9  vmovaps xmm0, [rsp]
000071709abd78ee  vmovaps xmm1, [rsp+0x10]
000071709abd78f4  vmovaps xmm2, [rsp+0x20]
000071709abd78fa  vmovaps xmm3, [rsp+0x30]
000071709abd7900  vmovaps xmm5, [rsp+0x40]
000071709abd7906  vmovaps xmm6, [rsp+0x50]
000071709abd790c  vmovaps xmm7, [rsp+0x60]
000071709abd7912  vmovaps xmm8, [rsp+0x70]
000071709abd7918  vmovaps xmm9, [rsp+0x80]
000071709abd7921  vmovaps xmm10, [rsp+0x90]
000071709abd792a  vmovaps xmm11, [rsp+0xA0]
000071709abd7933  vmovaps xmm12, [rsp+0xB0]
000071709abd793c  vmovaps xmm13, [rsp+0xC0]
000071709abd7945  vmovaps xmm14, [rsp+0xD0]
000071709abd794e  vmovaps xmm15, [rsp+0xE0]
000071709abd7957  add rsp, 0xF0
000071709abd795e  pop r11
000071709abd7960  pop r10
000071709abd7962  pop r9
000071709abd7964  pop r8
000071709abd7966  pop rsi
000071709abd7967  pop rdi
000071709abd7968  pop rdx
000071709abd7969  pop rcx
000071709abd796a  pop rax
000071709abd796b  add rsp, 0x08
000071709abd796f  jmp 0x000071709ABD5CF9
000071709abd7974  call 0x000071709AAE5820
000071709abd7979  jmp 0x000071709ABD5D06
000071709abd797e  sub rsp, 0x08
000071709abd7982  push rax
000071709abd7983  push rcx
000071709abd7984  push rdx
000071709abd7985  push rdi
000071709abd7986  push rsi
000071709abd7987  push r8
000071709abd7989  push r9
000071709abd798b  push r10
000071709abd798d  push r11
000071709abd798f  sub rsp, 0xF0
000071709abd7996  vmovaps [rsp], xmm0
000071709abd799b  vmovaps [rsp+0x10], xmm1
000071709abd79a1  vmovaps [rsp+0x20], xmm2
000071709abd79a7  vmovaps [rsp+0x30], xmm4
000071709abd79ad  vmovaps [rsp+0x40], xmm5
000071709abd79b3  vmovaps [rsp+0x50], xmm6
000071709abd79b9  vmovaps [rsp+0x60], xmm7
000071709abd79bf  vmovaps [rsp+0x70], xmm8
000071709abd79c5  vmovaps [rsp+0x80], xmm9
000071709abd79ce  vmovaps [rsp+0x90], xmm10
000071709abd79d7  vmovaps [rsp+0xA0], xmm11
000071709abd79e0  vmovaps [rsp+0xB0], xmm12
000071709abd79e9  vmovaps [rsp+0xC0], xmm13
000071709abd79f2  vmovaps [rsp+0xD0], xmm14
000071709abd79fb  vmovaps [rsp+0xE0], xmm15
000071709abd7a04  sub rsp, 0x30
000071709abd7a08  movaps [rsp], xmm3
000071709abd7a0c  movaps [rsp+0x10], xmm1
000071709abd7a11  movaps [rsp+0x20], xmm9
000071709abd7a17  lea rdi, [rsp]
000071709abd7a1b  mov esi, 0x00
000071709abd7a20  mov rax, 0x60B9B2ABC530
000071709abd7a2a  call rax
000071709abd7a2c  movaps xmm3, [rsp]
000071709abd7a30  add rsp, 0x30
000071709abd7a34  vmovaps xmm0, [rsp]
000071709abd7a39  vmovaps xmm1, [rsp+0x10]
000071709abd7a3f  vmovaps xmm2, [rsp+0x20]
000071709abd7a45  vmovaps xmm4, [rsp+0x30]
000071709abd7a4b  vmovaps xmm5, [rsp+0x40]
000071709abd7a51  vmovaps xmm6, [rsp+0x50]
000071709abd7a57  vmovaps xmm7, [rsp+0x60]
000071709abd7a5d  vmovaps xmm8, [rsp+0x70]
000071709abd7a63  vmovaps xmm9, [rsp+0x80]
000071709abd7a6c  vmovaps xmm10, [rsp+0x90]
000071709abd7a75  vmovaps xmm11, [rsp+0xA0]
000071709abd7a7e  vmovaps xmm12, [rsp+0xB0]
000071709abd7a87  vmovaps xmm13, [rsp+0xC0]
000071709abd7a90  vmovaps xmm14, [rsp+0xD0]
000071709abd7a99  vmovaps xmm15, [rsp+0xE0]
000071709abd7aa2  add rsp, 0xF0
000071709abd7aa9  pop r11
000071709abd7aab  pop r10
000071709abd7aad  pop r9
000071709abd7aaf  pop r8
000071709abd7ab1  pop rsi
000071709abd7ab2  pop rdi
000071709abd7ab3  pop rdx
000071709abd7ab4  pop rcx
000071709abd7ab5  pop rax
000071709abd7ab6  add rsp, 0x08
000071709abd7aba  jmp 0x000071709ABD5D43
000071709abd7abf  sub rsp, 0x08
000071709abd7ac3  push rax
000071709abd7ac4  push rcx
000071709abd7ac5  push rdx
000071709abd7ac6  push rdi
000071709abd7ac7  push rsi
000071709abd7ac8  push r8
000071709abd7aca  push r9
000071709abd7acc  push r10
000071709abd7ace  push r11
000071709abd7ad0  sub rsp, 0xF0
000071709abd7ad7  vmovaps [rsp], xmm0
000071709abd7adc  vmovaps [rsp+0x10], xmm2
000071709abd7ae2  vmovaps [rsp+0x20], xmm3
000071709abd7ae8  vmovaps [rsp+0x30], xmm4
000071709abd7aee  vmovaps [rsp+0x40], xmm5
000071709abd7af4  vmovaps [rsp+0x50], xmm6
000071709abd7afa  vmovaps [rsp+0x60], xmm7
000071709abd7b00  vmovaps [rsp+0x70], xmm8
000071709abd7b06  vmovaps [rsp+0x80], xmm9
000071709abd7b0f  vmovaps [rsp+0x90], xmm10
000071709abd7b18  vmovaps [rsp+0xA0], xmm11
000071709abd7b21  vmovaps [rsp+0xB0], xmm12
000071709abd7b2a  vmovaps [rsp+0xC0], xmm13
000071709abd7b33  vmovaps [rsp+0xD0], xmm14
000071709abd7b3c  vmovaps [rsp+0xE0], xmm15
000071709abd7b45  sub rsp, 0x30
000071709abd7b49  movaps [rsp], xmm1
000071709abd7b4d  movaps [rsp+0x10], xmm15
000071709abd7b53  movaps [rsp+0x20], xmm9
000071709abd7b59  lea rdi, [rsp]
000071709abd7b5d  mov esi, 0x00
000071709abd7b62  mov rax, 0x60B9B2ABC530
000071709abd7b6c  call rax
000071709abd7b6e  movaps xmm1, [rsp]
000071709abd7b72  add rsp, 0x30
000071709abd7b76  vmovaps xmm0, [rsp]
000071709abd7b7b  vmovaps xmm2, [rsp+0x10]
000071709abd7b81  vmovaps xmm3, [rsp+0x20]
000071709abd7b87  vmovaps xmm4, [rsp+0x30]
000071709abd7b8d  vmovaps xmm5, [rsp+0x40]
000071709abd7b93  vmovaps xmm6, [rsp+0x50]
000071709abd7b99  vmovaps xmm7, [rsp+0x60]
000071709abd7b9f  vmovaps xmm8, [rsp+0x70]
000071709abd7ba5  vmovaps xmm9, [rsp+0x80]
000071709abd7bae  vmovaps xmm10, [rsp+0x90]
000071709abd7bb7  vmovaps xmm11, [rsp+0xA0]
000071709abd7bc0  vmovaps xmm12, [rsp+0xB0]
000071709abd7bc9  vmovaps xmm13, [rsp+0xC0]
000071709abd7bd2  vmovaps xmm14, [rsp+0xD0]
000071709abd7bdb  vmovaps xmm15, [rsp+0xE0]
000071709abd7be4  add rsp, 0xF0
000071709abd7beb  pop r11
000071709abd7bed  pop r10
000071709abd7bef  pop r9
000071709abd7bf1  pop r8
000071709abd7bf3  pop rsi
000071709abd7bf4  pop rdi
000071709abd7bf5  pop rdx
000071709abd7bf6  pop rcx
000071709abd7bf7  pop rax
000071709abd7bf8  add rsp, 0x08
000071709abd7bfc  jmp 0x000071709ABD5DCB
000071709abd7c01  call 0x000071709AAE5820
000071709abd7c06  jmp 0x000071709ABD5DD8
000071709abd7c0b  sub rsp, 0x08
000071709abd7c0f  push rax
000071709abd7c10  push rcx
000071709abd7c11  push rdx
000071709abd7c12  push rdi
000071709abd7c13  push rsi
000071709abd7c14  push r8
000071709abd7c16  push r9
000071709abd7c18  push r10
000071709abd7c1a  push r11
000071709abd7c1c  sub rsp, 0xF0
000071709abd7c23  vmovaps [rsp], xmm0
000071709abd7c28  vmovaps [rsp+0x10], xmm2
000071709abd7c2e  vmovaps [rsp+0x20], xmm3
000071709abd7c34  vmovaps [rsp+0x30], xmm4
000071709abd7c3a  vmovaps [rsp+0x40], xmm5
000071709abd7c40  vmovaps [rsp+0x50], xmm6
000071709abd7c46  vmovaps [rsp+0x60], xmm7
000071709abd7c4c  vmovaps [rsp+0x70], xmm8
000071709abd7c52  vmovaps [rsp+0x80], xmm9
000071709abd7c5b  vmovaps [rsp+0x90], xmm10
000071709abd7c64  vmovaps [rsp+0xA0], xmm11
000071709abd7c6d  vmovaps [rsp+0xB0], xmm12
000071709abd7c76  vmovaps [rsp+0xC0], xmm13
000071709abd7c7f  vmovaps [rsp+0xD0], xmm14
000071709abd7c88  vmovaps [rsp+0xE0], xmm15
000071709abd7c91  sub rsp, 0x30
000071709abd7c95  movaps [rsp], xmm1
000071709abd7c99  movaps [rsp+0x10], xmm5
000071709abd7c9e  movaps [rsp+0x20], xmm7
000071709abd7ca3  lea rdi, [rsp]
000071709abd7ca7  mov esi, 0x00
000071709abd7cac  mov rax, 0x60B9B2ABC530
000071709abd7cb6  call rax
000071709abd7cb8  movaps xmm1, [rsp]
000071709abd7cbc  add rsp, 0x30
000071709abd7cc0  vmovaps xmm0, [rsp]
000071709abd7cc5  vmovaps xmm2, [rsp+0x10]
000071709abd7ccb  vmovaps xmm3, [rsp+0x20]
000071709abd7cd1  vmovaps xmm4, [rsp+0x30]
000071709abd7cd7  vmovaps xmm5, [rsp+0x40]
000071709abd7cdd  vmovaps xmm6, [rsp+0x50]
000071709abd7ce3  vmovaps xmm7, [rsp+0x60]
000071709abd7ce9  vmovaps xmm8, [rsp+0x70]
000071709abd7cef  vmovaps xmm9, [rsp+0x80]
000071709abd7cf8  vmovaps xmm10, [rsp+0x90]
000071709abd7d01  vmovaps xmm11, [rsp+0xA0]
000071709abd7d0a  vmovaps xmm12, [rsp+0xB0]
000071709abd7d13  vmovaps xmm13, [rsp+0xC0]
000071709abd7d1c  vmovaps xmm14, [rsp+0xD0]
000071709abd7d25  vmovaps xmm15, [rsp+0xE0]
000071709abd7d2e  add rsp, 0xF0
000071709abd7d35  pop r11
000071709abd7d37  pop r10
000071709abd7d39  pop r9
000071709abd7d3b  pop r8
000071709abd7d3d  pop rsi
000071709abd7d3e  pop rdi
000071709abd7d3f  pop rdx
000071709abd7d40  pop rcx
000071709abd7d41  pop rax
000071709abd7d42  add rsp, 0x08
000071709abd7d46  jmp 0x000071709ABD5E7D
000071709abd7d4b  sub rsp, 0x08
000071709abd7d4f  push rax
000071709abd7d50  push rcx
000071709abd7d51  push rdx
000071709abd7d52  push rdi
000071709abd7d53  push rsi
000071709abd7d54  push r8
000071709abd7d56  push r9
000071709abd7d58  push r10
000071709abd7d5a  push r11
000071709abd7d5c  sub rsp, 0xF0
000071709abd7d63  vmovaps [rsp], xmm0
000071709abd7d68  vmovaps [rsp+0x10], xmm1
000071709abd7d6e  vmovaps [rsp+0x20], xmm2
000071709abd7d74  vmovaps [rsp+0x30], xmm3
000071709abd7d7a  vmovaps [rsp+0x40], xmm4
000071709abd7d80  vmovaps [rsp+0x50], xmm5
000071709abd7d86  vmovaps [rsp+0x60], xmm6
000071709abd7d8c  vmovaps [rsp+0x70], xmm8
000071709abd7d92  vmovaps [rsp+0x80], xmm9
000071709abd7d9b  vmovaps [rsp+0x90], xmm10
000071709abd7da4  vmovaps [rsp+0xA0], xmm11
000071709abd7dad  vmovaps [rsp+0xB0], xmm12
000071709abd7db6  vmovaps [rsp+0xC0], xmm13
000071709abd7dbf  vmovaps [rsp+0xD0], xmm14
000071709abd7dc8  vmovaps [rsp+0xE0], xmm15
000071709abd7dd1  sub rsp, 0x30
000071709abd7dd5  movaps [rsp], xmm7
000071709abd7dd9  movaps [rsp+0x10], xmm5
000071709abd7dde  movaps [rsp+0x20], xmm15
000071709abd7de4  lea rdi, [rsp]
000071709abd7de8  mov esi, 0x00
000071709abd7ded  mov rax, 0x60B9B2ABC530
000071709abd7df7  call rax
000071709abd7df9  movaps xmm7, [rsp]
000071709abd7dfd  add rsp, 0x30
000071709abd7e01  vmovaps xmm0, [rsp]
000071709abd7e06  vmovaps xmm1, [rsp+0x10]
000071709abd7e0c  vmovaps xmm2, [rsp+0x20]
000071709abd7e12  vmovaps xmm3, [rsp+0x30]
000071709abd7e18  vmovaps xmm4, [rsp+0x40]
000071709abd7e1e  vmovaps xmm5, [rsp+0x50]
000071709abd7e24  vmovaps xmm6, [rsp+0x60]
000071709abd7e2a  vmovaps xmm8, [rsp+0x70]
000071709abd7e30  vmovaps xmm9, [rsp+0x80]
000071709abd7e39  vmovaps xmm10, [rsp+0x90]
000071709abd7e42  vmovaps xmm11, [rsp+0xA0]
000071709abd7e4b  vmovaps xmm12, [rsp+0xB0]
000071709abd7e54  vmovaps xmm13, [rsp+0xC0]
000071709abd7e5d  vmovaps xmm14, [rsp+0xD0]
000071709abd7e66  vmovaps xmm15, [rsp+0xE0]
000071709abd7e6f  add rsp, 0xF0
000071709abd7e76  pop r11
000071709abd7e78  pop r10
000071709abd7e7a  pop r9
000071709abd7e7c  pop r8
000071709abd7e7e  pop rsi
000071709abd7e7f  pop rdi
000071709abd7e80  pop rdx
000071709abd7e81  pop rcx
000071709abd7e82  pop rax
000071709abd7e83  add rsp, 0x08
000071709abd7e87  jmp 0x000071709ABD5EB3
000071709abd7e8c  call 0x000071709AAD64F0
000071709abd7e91  jmp 0x000071709ABD5EC0
000071709abd7e96  sub rsp, 0x08
000071709abd7e9a  push rax
000071709abd7e9b  push rcx
000071709abd7e9c  push rdx
000071709abd7e9d  push rdi
000071709abd7e9e  push rsi
000071709abd7e9f  push r8
000071709abd7ea1  push r9
000071709abd7ea3  push r10
000071709abd7ea5  push r11
000071709abd7ea7  sub rsp, 0xF0
000071709abd7eae  vmovaps [rsp], xmm0
000071709abd7eb3  vmovaps [rsp+0x10], xmm1
000071709abd7eb9  vmovaps [rsp+0x20], xmm2
000071709abd7ebf  vmovaps [rsp+0x30], xmm3
000071709abd7ec5  vmovaps [rsp+0x40], xmm4
000071709abd7ecb  vmovaps [rsp+0x50], xmm5
000071709abd7ed1  vmovaps [rsp+0x60], xmm6
000071709abd7ed7  vmovaps [rsp+0x70], xmm7
000071709abd7edd  vmovaps [rsp+0x80], xmm8
000071709abd7ee6  vmovaps [rsp+0x90], xmm9
000071709abd7eef  vmovaps [rsp+0xA0], xmm10
000071709abd7ef8  vmovaps [rsp+0xB0], xmm11
000071709abd7f01  vmovaps [rsp+0xC0], xmm12
000071709abd7f0a  vmovaps [rsp+0xD0], xmm13
000071709abd7f13  vmovaps [rsp+0xE0], xmm14
000071709abd7f1c  sub rsp, 0x30
000071709abd7f20  movaps [rsp], xmm15
000071709abd7f25  movaps [rsp+0x10], xmm5
000071709abd7f2a  movaps [rsp+0x20], xmm3
000071709abd7f2f  lea rdi, [rsp]
000071709abd7f33  mov esi, 0x00
000071709abd7f38  mov rax, 0x60B9B2ABC530
000071709abd7f42  call rax
000071709abd7f44  movaps xmm15, [rsp]
000071709abd7f49  add rsp, 0x30
000071709abd7f4d  vmovaps xmm0, [rsp]
000071709abd7f52  vmovaps xmm1, [rsp+0x10]
000071709abd7f58  vmovaps xmm2, [rsp+0x20]
000071709abd7f5e  vmovaps xmm3, [rsp+0x30]
000071709abd7f64  vmovaps xmm4, [rsp+0x40]
000071709abd7f6a  vmovaps xmm5, [rsp+0x50]
000071709abd7f70  vmovaps xmm6, [rsp+0x60]
000071709abd7f76  vmovaps xmm7, [rsp+0x70]
000071709abd7f7c  vmovaps xmm8, [rsp+0x80]
000071709abd7f85  vmovaps xmm9, [rsp+0x90]
000071709abd7f8e  vmovaps xmm10, [rsp+0xA0]
000071709abd7f97  vmovaps xmm11, [rsp+0xB0]
000071709abd7fa0  vmovaps xmm12, [rsp+0xC0]
000071709abd7fa9  vmovaps xmm13, [rsp+0xD0]
000071709abd7fb2  vmovaps xmm14, [rsp+0xE0]
000071709abd7fbb  add rsp, 0xF0
000071709abd7fc2  pop r11
000071709abd7fc4  pop r10
000071709abd7fc6  pop r9
000071709abd7fc8  pop r8
000071709abd7fca  pop rsi
000071709abd7fcb  pop rdi
000071709abd7fcc  pop rdx
000071709abd7fcd  pop rcx
000071709abd7fce  pop rax
000071709abd7fcf  add rsp, 0x08
000071709abd7fd3  jmp 0x000071709ABD5EE6
000071709abd7fd8  sub rsp, 0x08
000071709abd7fdc  push rax
000071709abd7fdd  push rcx
000071709abd7fde  push rdx
000071709abd7fdf  push rdi
000071709abd7fe0  push rsi
000071709abd7fe1  push r8
000071709abd7fe3  push r9
000071709abd7fe5  push r10
000071709abd7fe7  push r11
000071709abd7fe9  sub rsp, 0xF0
000071709abd7ff0  vmovaps [rsp], xmm0
000071709abd7ff5  vmovaps [rsp+0x10], xmm2
000071709abd7ffb  vmovaps [rsp+0x20], xmm3
000071709abd8001  vmovaps [rsp+0x30], xmm4
000071709abd8007  vmovaps [rsp+0x40], xmm5
000071709abd800d  vmovaps [rsp+0x50], xmm6
000071709abd8013  vmovaps [rsp+0x60], xmm7
000071709abd8019  vmovaps [rsp+0x70], xmm8
000071709abd801f  vmovaps [rsp+0x80], xmm9
000071709abd8028  vmovaps [rsp+0x90], xmm10
000071709abd8031  vmovaps [rsp+0xA0], xmm11
000071709abd803a  vmovaps [rsp+0xB0], xmm12
000071709abd8043  vmovaps [rsp+0xC0], xmm13
000071709abd804c  vmovaps [rsp+0xD0], xmm14
000071709abd8055  vmovaps [rsp+0xE0], xmm15
000071709abd805e  sub rsp, 0x30
000071709abd8062  movaps [rsp], xmm1
000071709abd8066  movaps [rsp+0x10], xmm5
000071709abd806b  movaps [rsp+0x20], xmm4
000071709abd8070  lea rdi, [rsp]
000071709abd8074  mov esi, 0x00
000071709abd8079  mov rax, 0x60B9B2ABC530
000071709abd8083  call rax
000071709abd8085  movaps xmm1, [rsp]
000071709abd8089  add rsp, 0x30
000071709abd808d  vmovaps xmm0, [rsp]
000071709abd8092  vmovaps xmm2, [rsp+0x10]
000071709abd8098  vmovaps xmm3, [rsp+0x20]
000071709abd809e  vmovaps xmm4, [rsp+0x30]
000071709abd80a4  vmovaps xmm5, [rsp+0x40]
000071709abd80aa  vmovaps xmm6, [rsp+0x50]
000071709abd80b0  vmovaps xmm7, [rsp+0x60]
000071709abd80b6  vmovaps xmm8, [rsp+0x70]
000071709abd80bc  vmovaps xmm9, [rsp+0x80]
000071709abd80c5  vmovaps xmm10, [rsp+0x90]
000071709abd80ce  vmovaps xmm11, [rsp+0xA0]
000071709abd80d7  vmovaps xmm12, [rsp+0xB0]
000071709abd80e0  vmovaps xmm13, [rsp+0xC0]
000071709abd80e9  vmovaps xmm14, [rsp+0xD0]
000071709abd80f2  vmovaps xmm15, [rsp+0xE0]
000071709abd80fb  add rsp, 0xF0
000071709abd8102  pop r11
000071709abd8104  pop r10
000071709abd8106  pop r9
000071709abd8108  pop r8
000071709abd810a  pop rsi
000071709abd810b  pop rdi
000071709abd810c  pop rdx
000071709abd810d  pop rcx
000071709abd810e  pop rax
000071709abd810f  add rsp, 0x08
000071709abd8113  jmp 0x000071709ABD5F06
000071709abd8118  sub rsp, 0x08
000071709abd811c  push rax
000071709abd811d  push rcx
000071709abd811e  push rdx
000071709abd811f  push rdi
000071709abd8120  push rsi
000071709abd8121  push r8
000071709abd8123  push r9
000071709abd8125  push r10
000071709abd8127  push r11
000071709abd8129  sub rsp, 0xF0
000071709abd8130  vmovaps [rsp], xmm0
000071709abd8135  vmovaps [rsp+0x10], xmm1
000071709abd813b  vmovaps [rsp+0x20], xmm2
000071709abd8141  vmovaps [rsp+0x30], xmm3
000071709abd8147  vmovaps [rsp+0x40], xmm5
000071709abd814d  vmovaps [rsp+0x50], xmm6
000071709abd8153  vmovaps [rsp+0x60], xmm7
000071709abd8159  vmovaps [rsp+0x70], xmm8
000071709abd815f  vmovaps [rsp+0x80], xmm9
000071709abd8168  vmovaps [rsp+0x90], xmm10
000071709abd8171  vmovaps [rsp+0xA0], xmm11
000071709abd817a  vmovaps [rsp+0xB0], xmm12
000071709abd8183  vmovaps [rsp+0xC0], xmm13
000071709abd818c  vmovaps [rsp+0xD0], xmm14
000071709abd8195  vmovaps [rsp+0xE0], xmm15
000071709abd819e  sub rsp, 0x30
000071709abd81a2  movaps [rsp], xmm4
000071709abd81a6  movaps [rsp+0x10], xmm3
000071709abd81ab  movaps [rsp+0x20], xmm5
000071709abd81b0  lea rdi, [rsp]
000071709abd81b4  mov esi, 0x00
000071709abd81b9  mov rax, 0x60B9B2ABC530
000071709abd81c3  call rax
000071709abd81c5  movaps xmm4, [rsp]
000071709abd81c9  add rsp, 0x30
000071709abd81cd  vmovaps xmm0, [rsp]
000071709abd81d2  vmovaps xmm1, [rsp+0x10]
000071709abd81d8  vmovaps xmm2, [rsp+0x20]
000071709abd81de  vmovaps xmm3, [rsp+0x30]
000071709abd81e4  vmovaps xmm5, [rsp+0x40]
000071709abd81ea  vmovaps xmm6, [rsp+0x50]
000071709abd81f0  vmovaps xmm7, [rsp+0x60]
000071709abd81f6  vmovaps xmm8, [rsp+0x70]
000071709abd81fc  vmovaps xmm9, [rsp+0x80]
000071709abd8205  vmovaps xmm10, [rsp+0x90]
000071709abd820e  vmovaps xmm11, [rsp+0xA0]
000071709abd8217  vmovaps xmm12, [rsp+0xB0]
000071709abd8220  vmovaps xmm13, [rsp+0xC0]
000071709abd8229  vmovaps xmm14, [rsp+0xD0]
000071709abd8232  vmovaps xmm15, [rsp+0xE0]
000071709abd823b  add rsp, 0xF0
000071709abd8242  pop r11
000071709abd8244  pop r10
000071709abd8246  pop r9
000071709abd8248  pop r8
000071709abd824a  pop rsi
000071709abd824b  pop rdi
000071709abd824c  pop rdx
000071709abd824d  pop rcx
000071709abd824e  pop rax
000071709abd824f  add rsp, 0x08
000071709abd8253  jmp 0x000071709ABD5F54
000071709abd8258  call 0x000071709AAD64F0
000071709abd825d  jmp 0x000071709ABD5F61
000071709abd8262  sub rsp, 0x08
000071709abd8266  push rax
000071709abd8267  push rcx
000071709abd8268  push rdx
000071709abd8269  push rdi
000071709abd826a  push rsi
000071709abd826b  push r8
000071709abd826d  push r9
000071709abd826f  push r10
000071709abd8271  push r11
000071709abd8273  sub rsp, 0xF0
000071709abd827a  vmovaps [rsp], xmm0
000071709abd827f  vmovaps [rsp+0x10], xmm1
000071709abd8285  vmovaps [rsp+0x20], xmm2
000071709abd828b  vmovaps [rsp+0x30], xmm3
000071709abd8291  vmovaps [rsp+0x40], xmm4
000071709abd8297  vmovaps [rsp+0x50], xmm6
000071709abd829d  vmovaps [rsp+0x60], xmm7
000071709abd82a3  vmovaps [rsp+0x70], xmm8
000071709abd82a9  vmovaps [rsp+0x80], xmm9
000071709abd82b2  vmovaps [rsp+0x90], xmm10
000071709abd82bb  vmovaps [rsp+0xA0], xmm11
000071709abd82c4  vmovaps [rsp+0xB0], xmm12
000071709abd82cd  vmovaps [rsp+0xC0], xmm13
000071709abd82d6  vmovaps [rsp+0xD0], xmm14
000071709abd82df  vmovaps [rsp+0xE0], xmm15
000071709abd82e8  sub rsp, 0x30
000071709abd82ec  movaps [rsp], xmm5
000071709abd82f0  movaps [rsp+0x10], xmm6
000071709abd82f5  movaps [rsp+0x20], xmm3
000071709abd82fa  lea rdi, [rsp]
000071709abd82fe  mov esi, 0x00
000071709abd8303  mov rax, 0x60B9B2ABC530
000071709abd830d  call rax
000071709abd830f  movaps xmm5, [rsp]
000071709abd8313  add rsp, 0x30
000071709abd8317  vmovaps xmm0, [rsp]
000071709abd831c  vmovaps xmm1, [rsp+0x10]
000071709abd8322  vmovaps xmm2, [rsp+0x20]
000071709abd8328  vmovaps xmm3, [rsp+0x30]
000071709abd832e  vmovaps xmm4, [rsp+0x40]
000071709abd8334  vmovaps xmm6, [rsp+0x50]
000071709abd833a  vmovaps xmm7, [rsp+0x60]
000071709abd8340  vmovaps xmm8, [rsp+0x70]
000071709abd8346  vmovaps xmm9, [rsp+0x80]
000071709abd834f  vmovaps xmm10, [rsp+0x90]
000071709abd8358  vmovaps xmm11, [rsp+0xA0]
000071709abd8361  vmovaps xmm12, [rsp+0xB0]
000071709abd836a  vmovaps xmm13, [rsp+0xC0]
000071709abd8373  vmovaps xmm14, [rsp+0xD0]
000071709abd837c  vmovaps xmm15, [rsp+0xE0]
000071709abd8385  add rsp, 0xF0
000071709abd838c  pop r11
000071709abd838e  pop r10
000071709abd8390  pop r9
000071709abd8392  pop r8
000071709abd8394  pop rsi
000071709abd8395  pop rdi
000071709abd8396  pop rdx
000071709abd8397  pop rcx
000071709abd8398  pop rax
000071709abd8399  add rsp, 0x08
000071709abd839d  jmp 0x000071709ABD5F87
000071709abd83a2  sub rsp, 0x08
000071709abd83a6  push rax
000071709abd83a7  push rcx
000071709abd83a8  push rdx
000071709abd83a9  push rdi
000071709abd83aa  push rsi
000071709abd83ab  push r8
000071709abd83ad  push r9
000071709abd83af  push r10
000071709abd83b1  push r11
000071709abd83b3  sub rsp, 0xF0
000071709abd83ba  vmovaps [rsp], xmm0
000071709abd83bf  vmovaps [rsp+0x10], xmm1
000071709abd83c5  vmovaps [rsp+0x20], xmm2
000071709abd83cb  vmovaps [rsp+0x30], xmm3
000071709abd83d1  vmovaps [rsp+0x40], xmm4
000071709abd83d7  vmovaps [rsp+0x50], xmm5
000071709abd83dd  vmovaps [rsp+0x60], xmm7
000071709abd83e3  vmovaps [rsp+0x70], xmm8
000071709abd83e9  vmovaps [rsp+0x80], xmm9
000071709abd83f2  vmovaps [rsp+0x90], xmm10
000071709abd83fb  vmovaps [rsp+0xA0], xmm11
000071709abd8404  vmovaps [rsp+0xB0], xmm12
000071709abd840d  vmovaps [rsp+0xC0], xmm13
000071709abd8416  vmovaps [rsp+0xD0], xmm14
000071709abd841f  vmovaps [rsp+0xE0], xmm15
000071709abd8428  sub rsp, 0x30
000071709abd842c  movaps [rsp], xmm6
000071709abd8430  movaps [rsp+0x10], xmm9
000071709abd8436  movaps [rsp+0x20], xmm1
000071709abd843b  lea rdi, [rsp]
000071709abd843f  mov esi, 0x00
000071709abd8444  mov rax, 0x60B9B2ABC530
000071709abd844e  call rax
000071709abd8450  movaps xmm6, [rsp]
000071709abd8454  add rsp, 0x30
000071709abd8458  vmovaps xmm0, [rsp]
000071709abd845d  vmovaps xmm1, [rsp+0x10]
000071709abd8463  vmovaps xmm2, [rsp+0x20]
000071709abd8469  vmovaps xmm3, [rsp+0x30]
000071709abd846f  vmovaps xmm4, [rsp+0x40]
000071709abd8475  vmovaps xmm5, [rsp+0x50]
000071709abd847b  vmovaps xmm7, [rsp+0x60]
000071709abd8481  vmovaps xmm8, [rsp+0x70]
000071709abd8487  vmovaps xmm9, [rsp+0x80]
000071709abd8490  vmovaps xmm10, [rsp+0x90]
000071709abd8499  vmovaps xmm11, [rsp+0xA0]
000071709abd84a2  vmovaps xmm12, [rsp+0xB0]
000071709abd84ab  vmovaps xmm13, [rsp+0xC0]
000071709abd84b4  vmovaps xmm14, [rsp+0xD0]
000071709abd84bd  vmovaps xmm15, [rsp+0xE0]
000071709abd84c6  add rsp, 0xF0
000071709abd84cd  pop r11
000071709abd84cf  pop r10
000071709abd84d1  pop r9
000071709abd84d3  pop r8
000071709abd84d5  pop rsi
000071709abd84d6  pop rdi
000071709abd84d7  pop rdx
000071709abd84d8  pop rcx
000071709abd84d9  pop rax
000071709abd84da  add rsp, 0x08
000071709abd84de  jmp 0x000071709ABD5FAB
000071709abd84e3  sub rsp, 0x08
000071709abd84e7  push rax
000071709abd84e8  push rcx
000071709abd84e9  push rdx
000071709abd84ea  push rdi
000071709abd84eb  push rsi
000071709abd84ec  push r8
000071709abd84ee  push r9
000071709abd84f0  push r10
000071709abd84f2  push r11
000071709abd84f4  sub rsp, 0xF0
000071709abd84fb  vmovaps [rsp], xmm0
000071709abd8500  vmovaps [rsp+0x10], xmm1
000071709abd8506  vmovaps [rsp+0x20], xmm2
000071709abd850c  vmovaps [rsp+0x30], xmm3
000071709abd8512  vmovaps [rsp+0x40], xmm4
000071709abd8518  vmovaps [rsp+0x50], xmm5
000071709abd851e  vmovaps [rsp+0x60], xmm6
000071709abd8524  vmovaps [rsp+0x70], xmm7
000071709abd852a  vmovaps [rsp+0x80], xmm8
000071709abd8533  vmovaps [rsp+0x90], xmm10
000071709abd853c  vmovaps [rsp+0xA0], xmm11
000071709abd8545  vmovaps [rsp+0xB0], xmm12
000071709abd854e  vmovaps [rsp+0xC0], xmm13
000071709abd8557  vmovaps [rsp+0xD0], xmm14
000071709abd8560  vmovaps [rsp+0xE0], xmm15
000071709abd8569  sub rsp, 0x30
000071709abd856d  movaps [rsp], xmm9
000071709abd8572  movaps [rsp+0x10], xmm3
000071709abd8577  movaps [rsp+0x20], xmm1
000071709abd857c  lea rdi, [rsp]
000071709abd8580  mov esi, 0x00
000071709abd8585  mov rax, 0x60B9B2ABC530
000071709abd858f  call rax
000071709abd8591  movaps xmm9, [rsp]
000071709abd8596  add rsp, 0x30
000071709abd859a  vmovaps xmm0, [rsp]
000071709abd859f  vmovaps xmm1, [rsp+0x10]
000071709abd85a5  vmovaps xmm2, [rsp+0x20]
000071709abd85ab  vmovaps xmm3, [rsp+0x30]
000071709abd85b1  vmovaps xmm4, [rsp+0x40]
000071709abd85b7  vmovaps xmm5, [rsp+0x50]
000071709abd85bd  vmovaps xmm6, [rsp+0x60]
000071709abd85c3  vmovaps xmm7, [rsp+0x70]
000071709abd85c9  vmovaps xmm8, [rsp+0x80]
000071709abd85d2  vmovaps xmm10, [rsp+0x90]
000071709abd85db  vmovaps xmm11, [rsp+0xA0]
000071709abd85e4  vmovaps xmm12, [rsp+0xB0]
000071709abd85ed  vmovaps xmm13, [rsp+0xC0]
000071709abd85f6  vmovaps xmm14, [rsp+0xD0]
000071709abd85ff  vmovaps xmm15, [rsp+0xE0]
000071709abd8608  add rsp, 0xF0
000071709abd860f  pop r11
000071709abd8611  pop r10
000071709abd8613  pop r9
000071709abd8615  pop r8
000071709abd8617  pop rsi
000071709abd8618  pop rdi
000071709abd8619  pop rdx
000071709abd861a  pop rcx
000071709abd861b  pop rax
000071709abd861c  add rsp, 0x08
000071709abd8620  jmp 0x000071709ABD5FF7
000071709abd8625  call 0x000071709AAD64F0
000071709abd862a  jmp 0x000071709ABD6004
000071709abd862f  sub rsp, 0x08
000071709abd8633  push rax
000071709abd8634  push rcx
000071709abd8635  push rdx
000071709abd8636  push rdi
000071709abd8637  push rsi
000071709abd8638  push r8
000071709abd863a  push r9
000071709abd863c  push r10
000071709abd863e  push r11
000071709abd8640  sub rsp, 0xF0
000071709abd8647  vmovaps [rsp], xmm0
000071709abd864c  vmovaps [rsp+0x10], xmm1
000071709abd8652  vmovaps [rsp+0x20], xmm2
000071709abd8658  vmovaps [rsp+0x30], xmm3
000071709abd865e  vmovaps [rsp+0x40], xmm4
000071709abd8664  vmovaps [rsp+0x50], xmm5
000071709abd866a  vmovaps [rsp+0x60], xmm6
000071709abd8670  vmovaps [rsp+0x70], xmm7
000071709abd8676  vmovaps [rsp+0x80], xmm8
000071709abd867f  vmovaps [rsp+0x90], xmm9
000071709abd8688  vmovaps [rsp+0xA0], xmm10
000071709abd8691  vmovaps [rsp+0xB0], xmm11
000071709abd869a  vmovaps [rsp+0xC0], xmm12
000071709abd86a3  vmovaps [rsp+0xD0], xmm13
000071709abd86ac  vmovaps [rsp+0xE0], xmm14
000071709abd86b5  sub rsp, 0x30
000071709abd86b9  movaps [rsp], xmm15
000071709abd86be  movaps [rsp+0x10], xmm3
000071709abd86c3  movaps [rsp+0x20], xmm7
000071709abd86c8  lea rdi, [rsp]
000071709abd86cc  mov esi, 0x00
000071709abd86d1  mov rax, 0x60B9B2ABC530
000071709abd86db  call rax
000071709abd86dd  movaps xmm15, [rsp]
000071709abd86e2  add rsp, 0x30
000071709abd86e6  vmovaps xmm0, [rsp]
000071709abd86eb  vmovaps xmm1, [rsp+0x10]
000071709abd86f1  vmovaps xmm2, [rsp+0x20]
000071709abd86f7  vmovaps xmm3, [rsp+0x30]
000071709abd86fd  vmovaps xmm4, [rsp+0x40]
000071709abd8703  vmovaps xmm5, [rsp+0x50]
000071709abd8709  vmovaps xmm6, [rsp+0x60]
000071709abd870f  vmovaps xmm7, [rsp+0x70]
000071709abd8715  vmovaps xmm8, [rsp+0x80]
000071709abd871e  vmovaps xmm9, [rsp+0x90]
000071709abd8727  vmovaps xmm10, [rsp+0xA0]
000071709abd8730  vmovaps xmm11, [rsp+0xB0]
000071709abd8739  vmovaps xmm12, [rsp+0xC0]
000071709abd8742  vmovaps xmm13, [rsp+0xD0]
000071709abd874b  vmovaps xmm14, [rsp+0xE0]
000071709abd8754  add rsp, 0xF0
000071709abd875b  pop r11
000071709abd875d  pop r10
000071709abd875f  pop r9
000071709abd8761  pop r8
000071709abd8763  pop rsi
000071709abd8764  pop rdi
000071709abd8765  pop rdx
000071709abd8766  pop rcx
000071709abd8767  pop rax
000071709abd8768  add rsp, 0x08
000071709abd876c  jmp 0x000071709ABD6030
000071709abd8771  sub rsp, 0x08
000071709abd8775  push rax
000071709abd8776  push rcx
000071709abd8777  push rdx
000071709abd8778  push rdi
000071709abd8779  push rsi
000071709abd877a  push r8
000071709abd877c  push r9
000071709abd877e  push r10
000071709abd8780  push r11
000071709abd8782  sub rsp, 0xF0
000071709abd8789  vmovaps [rsp], xmm0
000071709abd878e  vmovaps [rsp+0x10], xmm1
000071709abd8794  vmovaps [rsp+0x20], xmm2
000071709abd879a  vmovaps [rsp+0x30], xmm4
000071709abd87a0  vmovaps [rsp+0x40], xmm5
000071709abd87a6  vmovaps [rsp+0x50], xmm6
000071709abd87ac  vmovaps [rsp+0x60], xmm7
000071709abd87b2  vmovaps [rsp+0x70], xmm8
000071709abd87b8  vmovaps [rsp+0x80], xmm9
000071709abd87c1  vmovaps [rsp+0x90], xmm10
000071709abd87ca  vmovaps [rsp+0xA0], xmm11
000071709abd87d3  vmovaps [rsp+0xB0], xmm12
000071709abd87dc  vmovaps [rsp+0xC0], xmm13
000071709abd87e5  vmovaps [rsp+0xD0], xmm14
000071709abd87ee  vmovaps [rsp+0xE0], xmm15
000071709abd87f7  sub rsp, 0x30
000071709abd87fb  movaps [rsp], xmm3
000071709abd87ff  movaps [rsp+0x10], xmm1
000071709abd8804  movaps [rsp+0x20], xmm15
000071709abd880a  lea rdi, [rsp]
000071709abd880e  mov esi, 0x00
000071709abd8813  mov rax, 0x60B9B2ABC530
000071709abd881d  call rax
000071709abd881f  movaps xmm3, [rsp]
000071709abd8823  add rsp, 0x30
000071709abd8827  vmovaps xmm0, [rsp]
000071709abd882c  vmovaps xmm1, [rsp+0x10]
000071709abd8832  vmovaps xmm2, [rsp+0x20]
000071709abd8838  vmovaps xmm4, [rsp+0x30]
000071709abd883e  vmovaps xmm5, [rsp+0x40]
000071709abd8844  vmovaps xmm6, [rsp+0x50]
000071709abd884a  vmovaps xmm7, [rsp+0x60]
000071709abd8850  vmovaps xmm8, [rsp+0x70]
000071709abd8856  vmovaps xmm9, [rsp+0x80]
000071709abd885f  vmovaps xmm10, [rsp+0x90]
000071709abd8868  vmovaps xmm11, [rsp+0xA0]
000071709abd8871  vmovaps xmm12, [rsp+0xB0]
000071709abd887a  vmovaps xmm13, [rsp+0xC0]
000071709abd8883  vmovaps xmm14, [rsp+0xD0]
000071709abd888c  vmovaps xmm15, [rsp+0xE0]
000071709abd8895  add rsp, 0xF0
000071709abd889c  pop r11
000071709abd889e  pop r10
000071709abd88a0  pop r9
000071709abd88a2  pop r8
000071709abd88a4  pop rsi
000071709abd88a5  pop rdi
000071709abd88a6  pop rdx
000071709abd88a7  pop rcx
000071709abd88a8  pop rax
000071709abd88a9  add rsp, 0x08
000071709abd88ad  jmp 0x000071709ABD60BF
000071709abd88b2  call 0x000071709AAD64F0
000071709abd88b7  jmp 0x000071709ABD60C9
000071709abd88bc  sub rsp, 0x08
000071709abd88c0  push rax
000071709abd88c1  push rcx
000071709abd88c2  push rdx
000071709abd88c3  push rdi
000071709abd88c4  push rsi
000071709abd88c5  push r8
000071709abd88c7  push r9
000071709abd88c9  push r10
000071709abd88cb  push r11
000071709abd88cd  sub rsp, 0xF0
000071709abd88d4  vmovaps [rsp], xmm0
000071709abd88d9  vmovaps [rsp+0x10], xmm1
000071709abd88df  vmovaps [rsp+0x20], xmm2
000071709abd88e5  vmovaps [rsp+0x30], xmm3
000071709abd88eb  vmovaps [rsp+0x40], xmm4
000071709abd88f1  vmovaps [rsp+0x50], xmm5
000071709abd88f7  vmovaps [rsp+0x60], xmm6
000071709abd88fd  vmovaps [rsp+0x70], xmm7
000071709abd8903  vmovaps [rsp+0x80], xmm8
000071709abd890c  vmovaps [rsp+0x90], xmm9
000071709abd8915  vmovaps [rsp+0xA0], xmm10
000071709abd891e  vmovaps [rsp+0xB0], xmm11
000071709abd8927  vmovaps [rsp+0xC0], xmm12
000071709abd8930  vmovaps [rsp+0xD0], xmm13
000071709abd8939  vmovaps [rsp+0xE0], xmm14
000071709abd8942  sub rsp, 0x30
000071709abd8946  movaps [rsp], xmm15
000071709abd894b  movaps [rsp+0x10], xmm14
000071709abd8951  movaps [rsp+0x20], xmm4
000071709abd8956  lea rdi, [rsp]
000071709abd895a  mov esi, 0x00
000071709abd895f  mov rax, 0x60B9B2ABC530
000071709abd8969  call rax
000071709abd896b  movaps xmm15, [rsp]
000071709abd8970  add rsp, 0x30
000071709abd8974  vmovaps xmm0, [rsp]
000071709abd8979  vmovaps xmm1, [rsp+0x10]
000071709abd897f  vmovaps xmm2, [rsp+0x20]
000071709abd8985  vmovaps xmm3, [rsp+0x30]
000071709abd898b  vmovaps xmm4, [rsp+0x40]
000071709abd8991  vmovaps xmm5, [rsp+0x50]
000071709abd8997  vmovaps xmm6, [rsp+0x60]
000071709abd899d  vmovaps xmm7, [rsp+0x70]
000071709abd89a3  vmovaps xmm8, [rsp+0x80]
000071709abd89ac  vmovaps xmm9, [rsp+0x90]
000071709abd89b5  vmovaps xmm10, [rsp+0xA0]
000071709abd89be  vmovaps xmm11, [rsp+0xB0]
000071709abd89c7  vmovaps xmm12, [rsp+0xC0]
000071709abd89d0  vmovaps xmm13, [rsp+0xD0]
000071709abd89d9  vmovaps xmm14, [rsp+0xE0]
000071709abd89e2  add rsp, 0xF0
000071709abd89e9  pop r11
000071709abd89eb  pop r10
000071709abd89ed  pop r9
000071709abd89ef  pop r8
000071709abd89f1  pop rsi
000071709abd89f2  pop rdi
000071709abd89f3  pop rdx
000071709abd89f4  pop rcx
000071709abd89f5  pop rax
000071709abd89f6  add rsp, 0x08
000071709abd89fa  jmp 0x000071709ABD60F7
000071709abd89ff  sub rsp, 0x08
000071709abd8a03  push rax
000071709abd8a04  push rcx
000071709abd8a05  push rdx
000071709abd8a06  push rdi
000071709abd8a07  push rsi
000071709abd8a08  push r8
000071709abd8a0a  push r9
000071709abd8a0c  push r10
000071709abd8a0e  push r11
000071709abd8a10  sub rsp, 0xF0
000071709abd8a17  vmovaps [rsp], xmm0
000071709abd8a1c  vmovaps [rsp+0x10], xmm1
000071709abd8a22  vmovaps [rsp+0x20], xmm2
000071709abd8a28  vmovaps [rsp+0x30], xmm3
000071709abd8a2e  vmovaps [rsp+0x40], xmm4
000071709abd8a34  vmovaps [rsp+0x50], xmm5
000071709abd8a3a  vmovaps [rsp+0x60], xmm6
000071709abd8a40  vmovaps [rsp+0x70], xmm7
000071709abd8a46  vmovaps [rsp+0x80], xmm8
000071709abd8a4f  vmovaps [rsp+0x90], xmm9
000071709abd8a58  vmovaps [rsp+0xA0], xmm10
000071709abd8a61  vmovaps [rsp+0xB0], xmm11
000071709abd8a6a  vmovaps [rsp+0xC0], xmm12
000071709abd8a73  vmovaps [rsp+0xD0], xmm13
000071709abd8a7c  vmovaps [rsp+0xE0], xmm15
000071709abd8a85  sub rsp, 0x30
000071709abd8a89  movaps [rsp], xmm14
000071709abd8a8e  movaps [rsp+0x10], xmm2
000071709abd8a93  movaps [rsp+0x20], xmm1
000071709abd8a98  lea rdi, [rsp]
000071709abd8a9c  mov esi, 0x00
000071709abd8aa1  mov rax, 0x60B9B2ABC530
000071709abd8aab  call rax
000071709abd8aad  movaps xmm14, [rsp]
000071709abd8ab2  add rsp, 0x30
000071709abd8ab6  vmovaps xmm0, [rsp]
000071709abd8abb  vmovaps xmm1, [rsp+0x10]
000071709abd8ac1  vmovaps xmm2, [rsp+0x20]
000071709abd8ac7  vmovaps xmm3, [rsp+0x30]
000071709abd8acd  vmovaps xmm4, [rsp+0x40]
000071709abd8ad3  vmovaps xmm5, [rsp+0x50]
000071709abd8ad9  vmovaps xmm6, [rsp+0x60]
000071709abd8adf  vmovaps xmm7, [rsp+0x70]
000071709abd8ae5  vmovaps xmm8, [rsp+0x80]
000071709abd8aee  vmovaps xmm9, [rsp+0x90]
000071709abd8af7  vmovaps xmm10, [rsp+0xA0]
000071709abd8b00  vmovaps xmm11, [rsp+0xB0]
000071709abd8b09  vmovaps xmm12, [rsp+0xC0]
000071709abd8b12  vmovaps xmm13, [rsp+0xD0]
000071709abd8b1b  vmovaps xmm15, [rsp+0xE0]
000071709abd8b24  add rsp, 0xF0
000071709abd8b2b  pop r11
000071709abd8b2d  pop r10
000071709abd8b2f  pop r9
000071709abd8b31  pop r8
000071709abd8b33  pop rsi
000071709abd8b34  pop rdi
000071709abd8b35  pop rdx
000071709abd8b36  pop rcx
000071709abd8b37  pop rax
000071709abd8b38  add rsp, 0x08
000071709abd8b3c  jmp 0x000071709ABD611D
000071709abd8b41  sub rsp, 0x08
000071709abd8b45  push rax
000071709abd8b46  push rcx
000071709abd8b47  push rdx
000071709abd8b48  push rdi
000071709abd8b49  push rsi
000071709abd8b4a  push r8
000071709abd8b4c  push r9
000071709abd8b4e  push r10
000071709abd8b50  push r11
000071709abd8b52  sub rsp, 0xF0
000071709abd8b59  vmovaps [rsp], xmm0
000071709abd8b5e  vmovaps [rsp+0x10], xmm2
000071709abd8b64  vmovaps [rsp+0x20], xmm3
000071709abd8b6a  vmovaps [rsp+0x30], xmm4
000071709abd8b70  vmovaps [rsp+0x40], xmm5
000071709abd8b76  vmovaps [rsp+0x50], xmm6
000071709abd8b7c  vmovaps [rsp+0x60], xmm7
000071709abd8b82  vmovaps [rsp+0x70], xmm8
000071709abd8b88  vmovaps [rsp+0x80], xmm9
000071709abd8b91  vmovaps [rsp+0x90], xmm10
000071709abd8b9a  vmovaps [rsp+0xA0], xmm11
000071709abd8ba3  vmovaps [rsp+0xB0], xmm12
000071709abd8bac  vmovaps [rsp+0xC0], xmm13
000071709abd8bb5  vmovaps [rsp+0xD0], xmm14
000071709abd8bbe  vmovaps [rsp+0xE0], xmm15
000071709abd8bc7  sub rsp, 0x30
000071709abd8bcb  movaps [rsp], xmm1
000071709abd8bcf  movaps [rsp+0x10], xmm4
000071709abd8bd4  movaps [rsp+0x20], xmm9
000071709abd8bda  lea rdi, [rsp]
000071709abd8bde  mov esi, 0x00
000071709abd8be3  mov rax, 0x60B9B2ABC530
000071709abd8bed  call rax
000071709abd8bef  movaps xmm1, [rsp]
000071709abd8bf3  add rsp, 0x30
000071709abd8bf7  vmovaps xmm0, [rsp]
000071709abd8bfc  vmovaps xmm2, [rsp+0x10]
000071709abd8c02  vmovaps xmm3, [rsp+0x20]
000071709abd8c08  vmovaps xmm4, [rsp+0x30]
000071709abd8c0e  vmovaps xmm5, [rsp+0x40]
000071709abd8c14  vmovaps xmm6, [rsp+0x50]
000071709abd8c1a  vmovaps xmm7, [rsp+0x60]
000071709abd8c20  vmovaps xmm8, [rsp+0x70]
000071709abd8c26  vmovaps xmm9, [rsp+0x80]
000071709abd8c2f  vmovaps xmm10, [rsp+0x90]
000071709abd8c38  vmovaps xmm11, [rsp+0xA0]
000071709abd8c41  vmovaps xmm12, [rsp+0xB0]
000071709abd8c4a  vmovaps xmm13, [rsp+0xC0]
000071709abd8c53  vmovaps xmm14, [rsp+0xD0]
000071709abd8c5c  vmovaps xmm15, [rsp+0xE0]
000071709abd8c65  add rsp, 0xF0
000071709abd8c6c  pop r11
000071709abd8c6e  pop r10
000071709abd8c70  pop r9
000071709abd8c72  pop r8
000071709abd8c74  pop rsi
000071709abd8c75  pop rdi
000071709abd8c76  pop rdx
000071709abd8c77  pop rcx
000071709abd8c78  pop rax
000071709abd8c79  add rsp, 0x08
000071709abd8c7d  jmp 0x000071709ABD613B
000071709abd8c82  sub rsp, 0x08
000071709abd8c86  push rax
000071709abd8c87  push rcx
000071709abd8c88  push rdx
000071709abd8c89  push rdi
000071709abd8c8a  push rsi
000071709abd8c8b  push r8
000071709abd8c8d  push r9
000071709abd8c8f  push r10
000071709abd8c91  push r11
000071709abd8c93  sub rsp, 0xF0
000071709abd8c9a  vmovaps [rsp], xmm0
000071709abd8c9f  vmovaps [rsp+0x10], xmm1
000071709abd8ca5  vmovaps [rsp+0x20], xmm2
000071709abd8cab  vmovaps [rsp+0x30], xmm3
000071709abd8cb1  vmovaps [rsp+0x40], xmm5
000071709abd8cb7  vmovaps [rsp+0x50], xmm6
000071709abd8cbd  vmovaps [rsp+0x60], xmm7
000071709abd8cc3  vmovaps [rsp+0x70], xmm8
000071709abd8cc9  vmovaps [rsp+0x80], xmm9
000071709abd8cd2  vmovaps [rsp+0x90], xmm10
000071709abd8cdb  vmovaps [rsp+0xA0], xmm11
000071709abd8ce4  vmovaps [rsp+0xB0], xmm12
000071709abd8ced  vmovaps [rsp+0xC0], xmm13
000071709abd8cf6  vmovaps [rsp+0xD0], xmm14
000071709abd8cff  vmovaps [rsp+0xE0], xmm15
000071709abd8d08  sub rsp, 0x30
000071709abd8d0c  movaps [rsp], xmm4
000071709abd8d10  movaps [rsp+0x10], xmm2
000071709abd8d15  movaps [rsp+0x20], xmm9
000071709abd8d1b  lea rdi, [rsp]
000071709abd8d1f  mov esi, 0x00
000071709abd8d24  mov rax, 0x60B9B2ABC530
000071709abd8d2e  call rax
000071709abd8d30  movaps xmm4, [rsp]
000071709abd8d34  add rsp, 0x30
000071709abd8d38  vmovaps xmm0, [rsp]
000071709abd8d3d  vmovaps xmm1, [rsp+0x10]
000071709abd8d43  vmovaps xmm2, [rsp+0x20]
000071709abd8d49  vmovaps xmm3, [rsp+0x30]
000071709abd8d4f  vmovaps xmm5, [rsp+0x40]
000071709abd8d55  vmovaps xmm6, [rsp+0x50]
000071709abd8d5b  vmovaps xmm7, [rsp+0x60]
000071709abd8d61  vmovaps xmm8, [rsp+0x70]
000071709abd8d67  vmovaps xmm9, [rsp+0x80]
000071709abd8d70  vmovaps xmm10, [rsp+0x90]
000071709abd8d79  vmovaps xmm11, [rsp+0xA0]
000071709abd8d82  vmovaps xmm12, [rsp+0xB0]
000071709abd8d8b  vmovaps xmm13, [rsp+0xC0]
000071709abd8d94  vmovaps xmm14, [rsp+0xD0]
000071709abd8d9d  vmovaps xmm15, [rsp+0xE0]
000071709abd8da6  add rsp, 0xF0
000071709abd8dad  pop r11
000071709abd8daf  pop r10
000071709abd8db1  pop r9
000071709abd8db3  pop r8
000071709abd8db5  pop rsi
000071709abd8db6  pop rdi
000071709abd8db7  pop rdx
000071709abd8db8  pop rcx
000071709abd8db9  pop rax
000071709abd8dba  add rsp, 0x08
000071709abd8dbe  jmp 0x000071709ABD616B
000071709abd8dc3  sub rsp, 0x08
000071709abd8dc7  push rax
000071709abd8dc8  push rcx
000071709abd8dc9  push rdx
000071709abd8dca  push rdi
000071709abd8dcb  push rsi
000071709abd8dcc  push r8
000071709abd8dce  push r9
000071709abd8dd0  push r10
000071709abd8dd2  push r11
000071709abd8dd4  sub rsp, 0xF0
000071709abd8ddb  vmovaps [rsp], xmm0
000071709abd8de0  vmovaps [rsp+0x10], xmm1
000071709abd8de6  vmovaps [rsp+0x20], xmm2
000071709abd8dec  vmovaps [rsp+0x30], xmm3
000071709abd8df2  vmovaps [rsp+0x40], xmm4
000071709abd8df8  vmovaps [rsp+0x50], xmm5
000071709abd8dfe  vmovaps [rsp+0x60], xmm6
000071709abd8e04  vmovaps [rsp+0x70], xmm7
000071709abd8e0a  vmovaps [rsp+0x80], xmm8
000071709abd8e13  vmovaps [rsp+0x90], xmm10
000071709abd8e1c  vmovaps [rsp+0xA0], xmm11
000071709abd8e25  vmovaps [rsp+0xB0], xmm12
000071709abd8e2e  vmovaps [rsp+0xC0], xmm13
000071709abd8e37  vmovaps [rsp+0xD0], xmm14
000071709abd8e40  vmovaps [rsp+0xE0], xmm15
000071709abd8e49  sub rsp, 0x30
000071709abd8e4d  movaps [rsp], xmm9
000071709abd8e52  movaps [rsp+0x10], xmm2
000071709abd8e57  movaps [rsp+0x20], xmm1
000071709abd8e5c  lea rdi, [rsp]
000071709abd8e60  mov esi, 0x00
000071709abd8e65  mov rax, 0x60B9B2ABC530
000071709abd8e6f  call rax
000071709abd8e71  movaps xmm9, [rsp]
000071709abd8e76  add rsp, 0x30
000071709abd8e7a  vmovaps xmm0, [rsp]
000071709abd8e7f  vmovaps xmm1, [rsp+0x10]
000071709abd8e85  vmovaps xmm2, [rsp+0x20]
000071709abd8e8b  vmovaps xmm3, [rsp+0x30]
000071709abd8e91  vmovaps xmm4, [rsp+0x40]
000071709abd8e97  vmovaps xmm5, [rsp+0x50]
000071709abd8e9d  vmovaps xmm6, [rsp+0x60]
000071709abd8ea3  vmovaps xmm7, [rsp+0x70]
000071709abd8ea9  vmovaps xmm8, [rsp+0x80]
000071709abd8eb2  vmovaps xmm10, [rsp+0x90]
000071709abd8ebb  vmovaps xmm11, [rsp+0xA0]
000071709abd8ec4  vmovaps xmm12, [rsp+0xB0]
000071709abd8ecd  vmovaps xmm13, [rsp+0xC0]
000071709abd8ed6  vmovaps xmm14, [rsp+0xD0]
000071709abd8edf  vmovaps xmm15, [rsp+0xE0]
000071709abd8ee8  add rsp, 0xF0
000071709abd8eef  pop r11
000071709abd8ef1  pop r10
000071709abd8ef3  pop r9
000071709abd8ef5  pop r8
000071709abd8ef7  pop rsi
000071709abd8ef8  pop rdi
000071709abd8ef9  pop rdx
000071709abd8efa  pop rcx
000071709abd8efb  pop rax
000071709abd8efc  add rsp, 0x08
000071709abd8f00  jmp 0x000071709ABD61A1
000071709abd8f05  sub rsp, 0x08
000071709abd8f09  push rax
000071709abd8f0a  push rcx
000071709abd8f0b  push rdx
000071709abd8f0c  push rdi
000071709abd8f0d  push rsi
000071709abd8f0e  push r8
000071709abd8f10  push r9
000071709abd8f12  push r10
000071709abd8f14  push r11
000071709abd8f16  sub rsp, 0xF0
000071709abd8f1d  vmovaps [rsp], xmm0
000071709abd8f22  vmovaps [rsp+0x10], xmm2
000071709abd8f28  vmovaps [rsp+0x20], xmm3
000071709abd8f2e  vmovaps [rsp+0x30], xmm4
000071709abd8f34  vmovaps [rsp+0x40], xmm5
000071709abd8f3a  vmovaps [rsp+0x50], xmm6
000071709abd8f40  vmovaps [rsp+0x60], xmm7
000071709abd8f46  vmovaps [rsp+0x70], xmm8
000071709abd8f4c  vmovaps [rsp+0x80], xmm9
000071709abd8f55  vmovaps [rsp+0x90], xmm10
000071709abd8f5e  vmovaps [rsp+0xA0], xmm11
000071709abd8f67  vmovaps [rsp+0xB0], xmm12
000071709abd8f70  vmovaps [rsp+0xC0], xmm13
000071709abd8f79  vmovaps [rsp+0xD0], xmm14
000071709abd8f82  vmovaps [rsp+0xE0], xmm15
000071709abd8f8b  sub rsp, 0x30
000071709abd8f8f  movaps [rsp], xmm1
000071709abd8f93  movaps [rsp+0x10], xmm15
000071709abd8f99  movaps [rsp+0x20], xmm6
000071709abd8f9e  lea rdi, [rsp]
000071709abd8fa2  mov esi, 0x00
000071709abd8fa7  mov rax, 0x60B9B2ABC530
000071709abd8fb1  call rax
000071709abd8fb3  movaps xmm1, [rsp]
000071709abd8fb7  add rsp, 0x30
000071709abd8fbb  vmovaps xmm0, [rsp]
000071709abd8fc0  vmovaps xmm2, [rsp+0x10]
000071709abd8fc6  vmovaps xmm3, [rsp+0x20]
000071709abd8fcc  vmovaps xmm4, [rsp+0x30]
000071709abd8fd2  vmovaps xmm5, [rsp+0x40]
000071709abd8fd8  vmovaps xmm6, [rsp+0x50]
000071709abd8fde  vmovaps xmm7, [rsp+0x60]
000071709abd8fe4  vmovaps xmm8, [rsp+0x70]
000071709abd8fea  vmovaps xmm9, [rsp+0x80]
000071709abd8ff3  vmovaps xmm10, [rsp+0x90]
000071709abd8ffc  vmovaps xmm11, [rsp+0xA0]
000071709abd9005  vmovaps xmm12, [rsp+0xB0]
000071709abd900e  vmovaps xmm13, [rsp+0xC0]
000071709abd9017  vmovaps xmm14, [rsp+0xD0]
000071709abd9020  vmovaps xmm15, [rsp+0xE0]
000071709abd9029  add rsp, 0xF0
000071709abd9030  pop r11
000071709abd9032  pop r10
000071709abd9034  pop r9
000071709abd9036  pop r8
000071709abd9038  pop rsi
000071709abd9039  pop rdi
000071709abd903a  pop rdx
000071709abd903b  pop rcx
000071709abd903c  pop rax
000071709abd903d  add rsp, 0x08
000071709abd9041  jmp 0x000071709ABD61C2
000071709abd9046  sub rsp, 0x08
000071709abd904a  push rax
000071709abd904b  push rcx
000071709abd904c  push rdx
000071709abd904d  push rdi
000071709abd904e  push rsi
000071709abd904f  push r8
000071709abd9051  push r9
000071709abd9053  push r10
000071709abd9055  push r11
000071709abd9057  sub rsp, 0xF0
000071709abd905e  vmovaps [rsp], xmm0
000071709abd9063  vmovaps [rsp+0x10], xmm1
000071709abd9069  vmovaps [rsp+0x20], xmm2
000071709abd906f  vmovaps [rsp+0x30], xmm3
000071709abd9075  vmovaps [rsp+0x40], xmm4
000071709abd907b  vmovaps [rsp+0x50], xmm5
000071709abd9081  vmovaps [rsp+0x60], xmm6
000071709abd9087  vmovaps [rsp+0x70], xmm7
000071709abd908d  vmovaps [rsp+0x80], xmm8
000071709abd9096  vmovaps [rsp+0x90], xmm9
000071709abd909f  vmovaps [rsp+0xA0], xmm10
000071709abd90a8  vmovaps [rsp+0xB0], xmm11
000071709abd90b1  vmovaps [rsp+0xC0], xmm12
000071709abd90ba  vmovaps [rsp+0xD0], xmm13
000071709abd90c3  vmovaps [rsp+0xE0], xmm14
000071709abd90cc  sub rsp, 0x30
000071709abd90d0  movaps [rsp], xmm15
000071709abd90d5  movaps [rsp+0x10], xmm5
000071709abd90da  movaps [rsp+0x20], xmm3
000071709abd90df  lea rdi, [rsp]
000071709abd90e3  mov esi, 0x00
000071709abd90e8  mov rax, 0x60B9B2ABC530
000071709abd90f2  call rax
000071709abd90f4  movaps xmm15, [rsp]
000071709abd90f9  add rsp, 0x30
000071709abd90fd  vmovaps xmm0, [rsp]
000071709abd9102  vmovaps xmm1, [rsp+0x10]
000071709abd9108  vmovaps xmm2, [rsp+0x20]
000071709abd910e  vmovaps xmm3, [rsp+0x30]
000071709abd9114  vmovaps xmm4, [rsp+0x40]
000071709abd911a  vmovaps xmm5, [rsp+0x50]
000071709abd9120  vmovaps xmm6, [rsp+0x60]
000071709abd9126  vmovaps xmm7, [rsp+0x70]
000071709abd912c  vmovaps xmm8, [rsp+0x80]
000071709abd9135  vmovaps xmm9, [rsp+0x90]
000071709abd913e  vmovaps xmm10, [rsp+0xA0]
000071709abd9147  vmovaps xmm11, [rsp+0xB0]
000071709abd9150  vmovaps xmm12, [rsp+0xC0]
000071709abd9159  vmovaps xmm13, [rsp+0xD0]
000071709abd9162  vmovaps xmm14, [rsp+0xE0]
000071709abd916b  add rsp, 0xF0
000071709abd9172  pop r11
000071709abd9174  pop r10
000071709abd9176  pop r9
000071709abd9178  pop r8
000071709abd917a  pop rsi
000071709abd917b  pop rdi
000071709abd917c  pop rdx
000071709abd917d  pop rcx
000071709abd917e  pop rax
000071709abd917f  add rsp, 0x08
000071709abd9183  jmp 0x000071709ABD61DC
000071709abd9188  sub rsp, 0x08
000071709abd918c  push rax
000071709abd918d  push rcx
000071709abd918e  push rdx
000071709abd918f  push rdi
000071709abd9190  push rsi
000071709abd9191  push r8
000071709abd9193  push r9
000071709abd9195  push r10
000071709abd9197  push r11
000071709abd9199  sub rsp, 0xF0
000071709abd91a0  vmovaps [rsp], xmm0
000071709abd91a5  vmovaps [rsp+0x10], xmm1
000071709abd91ab  vmovaps [rsp+0x20], xmm2
000071709abd91b1  vmovaps [rsp+0x30], xmm3
000071709abd91b7  vmovaps [rsp+0x40], xmm4
000071709abd91bd  vmovaps [rsp+0x50], xmm6
000071709abd91c3  vmovaps [rsp+0x60], xmm7
000071709abd91c9  vmovaps [rsp+0x70], xmm8
000071709abd91cf  vmovaps [rsp+0x80], xmm9
000071709abd91d8  vmovaps [rsp+0x90], xmm10
000071709abd91e1  vmovaps [rsp+0xA0], xmm11
000071709abd91ea  vmovaps [rsp+0xB0], xmm12
000071709abd91f3  vmovaps [rsp+0xC0], xmm13
000071709abd91fc  vmovaps [rsp+0xD0], xmm14
000071709abd9205  vmovaps [rsp+0xE0], xmm15
000071709abd920e  sub rsp, 0x30
000071709abd9212  movaps [rsp], xmm5
000071709abd9216  movaps [rsp+0x10], xmm8
000071709abd921c  movaps [rsp+0x20], xmm6
000071709abd9221  lea rdi, [rsp]
000071709abd9225  mov esi, 0x00
000071709abd922a  mov rax, 0x60B9B2ABC530
000071709abd9234  call rax
000071709abd9236  movaps xmm5, [rsp]
000071709abd923a  add rsp, 0x30
000071709abd923e  vmovaps xmm0, [rsp]
000071709abd9243  vmovaps xmm1, [rsp+0x10]
000071709abd9249  vmovaps xmm2, [rsp+0x20]
000071709abd924f  vmovaps xmm3, [rsp+0x30]
000071709abd9255  vmovaps xmm4, [rsp+0x40]
000071709abd925b  vmovaps xmm6, [rsp+0x50]
000071709abd9261  vmovaps xmm7, [rsp+0x60]
000071709abd9267  vmovaps xmm8, [rsp+0x70]
000071709abd926d  vmovaps xmm9, [rsp+0x80]
000071709abd9276  vmovaps xmm10, [rsp+0x90]
000071709abd927f  vmovaps xmm11, [rsp+0xA0]
000071709abd9288  vmovaps xmm12, [rsp+0xB0]
000071709abd9291  vmovaps xmm13, [rsp+0xC0]
000071709abd929a  vmovaps xmm14, [rsp+0xD0]
000071709abd92a3  vmovaps xmm15, [rsp+0xE0]
000071709abd92ac  add rsp, 0xF0
000071709abd92b3  pop r11
000071709abd92b5  pop r10
000071709abd92b7  pop r9
000071709abd92b9  pop r8
000071709abd92bb  pop rsi
000071709abd92bc  pop rdi
000071709abd92bd  pop rdx
000071709abd92be  pop rcx
000071709abd92bf  pop rax
000071709abd92c0  add rsp, 0x08
000071709abd92c4  jmp 0x000071709ABD6200
000071709abd92c9  sub rsp, 0x08
000071709abd92cd  push rax
000071709abd92ce  push rcx
000071709abd92cf  push rdx
000071709abd92d0  push rdi
000071709abd92d1  push rsi
000071709abd92d2  push r8
000071709abd92d4  push r9
000071709abd92d6  push r10
000071709abd92d8  push r11
000071709abd92da  sub rsp, 0xF0
000071709abd92e1  vmovaps [rsp], xmm0
000071709abd92e6  vmovaps [rsp+0x10], xmm1
000071709abd92ec  vmovaps [rsp+0x20], xmm2
000071709abd92f2  vmovaps [rsp+0x30], xmm3
000071709abd92f8  vmovaps [rsp+0x40], xmm4
000071709abd92fe  vmovaps [rsp+0x50], xmm5
000071709abd9304  vmovaps [rsp+0x60], xmm7
000071709abd930a  vmovaps [rsp+0x70], xmm8
000071709abd9310  vmovaps [rsp+0x80], xmm9
000071709abd9319  vmovaps [rsp+0x90], xmm10
000071709abd9322  vmovaps [rsp+0xA0], xmm11
000071709abd932b  vmovaps [rsp+0xB0], xmm12
000071709abd9334  vmovaps [rsp+0xC0], xmm13
000071709abd933d  vmovaps [rsp+0xD0], xmm14
000071709abd9346  vmovaps [rsp+0xE0], xmm15
000071709abd934f  sub rsp, 0x30
000071709abd9353  movaps [rsp], xmm6
000071709abd9357  movaps [rsp+0x10], xmm10
000071709abd935d  movaps [rsp+0x20], xmm8
000071709abd9363  lea rdi, [rsp]
000071709abd9367  mov esi, 0x00
000071709abd936c  mov rax, 0x60B9B2ABC530
000071709abd9376  call rax
000071709abd9378  movaps xmm6, [rsp]
000071709abd937c  add rsp, 0x30
000071709abd9380  vmovaps xmm0, [rsp]
000071709abd9385  vmovaps xmm1, [rsp+0x10]
000071709abd938b  vmovaps xmm2, [rsp+0x20]
000071709abd9391  vmovaps xmm3, [rsp+0x30]
000071709abd9397  vmovaps xmm4, [rsp+0x40]
000071709abd939d  vmovaps xmm5, [rsp+0x50]
000071709abd93a3  vmovaps xmm7, [rsp+0x60]
000071709abd93a9  vmovaps xmm8, [rsp+0x70]
000071709abd93af  vmovaps xmm9, [rsp+0x80]
000071709abd93b8  vmovaps xmm10, [rsp+0x90]
000071709abd93c1  vmovaps xmm11, [rsp+0xA0]
000071709abd93ca  vmovaps xmm12, [rsp+0xB0]
000071709abd93d3  vmovaps xmm13, [rsp+0xC0]
000071709abd93dc  vmovaps xmm14, [rsp+0xD0]
000071709abd93e5  vmovaps xmm15, [rsp+0xE0]
000071709abd93ee  add rsp, 0xF0
000071709abd93f5  pop r11
000071709abd93f7  pop r10
000071709abd93f9  pop r9
000071709abd93fb  pop r8
000071709abd93fd  pop rsi
000071709abd93fe  pop rdi
000071709abd93ff  pop rdx
000071709abd9400  pop rcx
000071709abd9401  pop rax
000071709abd9402  add rsp, 0x08
000071709abd9406  jmp 0x000071709ABD6225
000071709abd940b  sub rsp, 0x08
000071709abd940f  push rax
000071709abd9410  push rcx
000071709abd9411  push rdx
000071709abd9412  push rdi
000071709abd9413  push rsi
000071709abd9414  push r8
000071709abd9416  push r9
000071709abd9418  push r10
000071709abd941a  push r11
000071709abd941c  sub rsp, 0xF0
000071709abd9423  vmovaps [rsp], xmm0
000071709abd9428  vmovaps [rsp+0x10], xmm1
000071709abd942e  vmovaps [rsp+0x20], xmm2
000071709abd9434  vmovaps [rsp+0x30], xmm3
000071709abd943a  vmovaps [rsp+0x40], xmm4
000071709abd9440  vmovaps [rsp+0x50], xmm5
000071709abd9446  vmovaps [rsp+0x60], xmm6
000071709abd944c  vmovaps [rsp+0x70], xmm7
000071709abd9452  vmovaps [rsp+0x80], xmm8
000071709abd945b  vmovaps [rsp+0x90], xmm9
000071709abd9464  vmovaps [rsp+0xA0], xmm11
000071709abd946d  vmovaps [rsp+0xB0], xmm12
000071709abd9476  vmovaps [rsp+0xC0], xmm13
000071709abd947f  vmovaps [rsp+0xD0], xmm14
000071709abd9488  vmovaps [rsp+0xE0], xmm15
000071709abd9491  sub rsp, 0x30
000071709abd9495  movaps [rsp], xmm10
000071709abd949a  movaps [rsp+0x10], xmm8
000071709abd94a0  movaps [rsp+0x20], xmm14
000071709abd94a6  lea rdi, [rsp]
000071709abd94aa  mov esi, 0x00
000071709abd94af  mov rax, 0x60B9B2ABC530
000071709abd94b9  call rax
000071709abd94bb  movaps xmm10, [rsp]
000071709abd94c0  add rsp, 0x30
000071709abd94c4  vmovaps xmm0, [rsp]
000071709abd94c9  vmovaps xmm1, [rsp+0x10]
000071709abd94cf  vmovaps xmm2, [rsp+0x20]
000071709abd94d5  vmovaps xmm3, [rsp+0x30]
000071709abd94db  vmovaps xmm4, [rsp+0x40]
000071709abd94e1  vmovaps xmm5, [rsp+0x50]
000071709abd94e7  vmovaps xmm6, [rsp+0x60]
000071709abd94ed  vmovaps xmm7, [rsp+0x70]
000071709abd94f3  vmovaps xmm8, [rsp+0x80]
000071709abd94fc  vmovaps xmm9, [rsp+0x90]
000071709abd9505  vmovaps xmm11, [rsp+0xA0]
000071709abd950e  vmovaps xmm12, [rsp+0xB0]
000071709abd9517  vmovaps xmm13, [rsp+0xC0]
000071709abd9520  vmovaps xmm14, [rsp+0xD0]
000071709abd9529  vmovaps xmm15, [rsp+0xE0]
000071709abd9532  add rsp, 0xF0
000071709abd9539  pop r11
000071709abd953b  pop r10
000071709abd953d  pop r9
000071709abd953f  pop r8
000071709abd9541  pop rsi
000071709abd9542  pop rdi
000071709abd9543  pop rdx
000071709abd9544  pop rcx
000071709abd9545  pop rax
000071709abd9546  add rsp, 0x08
000071709abd954a  jmp 0x000071709ABD6245
000071709abd954f  sub rsp, 0x08
000071709abd9553  push rax
000071709abd9554  push rcx
000071709abd9555  push rdx
000071709abd9556  push rdi
000071709abd9557  push rsi
000071709abd9558  push r8
000071709abd955a  push r9
000071709abd955c  push r10
000071709abd955e  push r11
000071709abd9560  sub rsp, 0xF0
000071709abd9567  vmovaps [rsp], xmm0
000071709abd956c  vmovaps [rsp+0x10], xmm1
000071709abd9572  vmovaps [rsp+0x20], xmm2
000071709abd9578  vmovaps [rsp+0x30], xmm3
000071709abd957e  vmovaps [rsp+0x40], xmm4
000071709abd9584  vmovaps [rsp+0x50], xmm5
000071709abd958a  vmovaps [rsp+0x60], xmm6
000071709abd9590  vmovaps [rsp+0x70], xmm7
000071709abd9596  vmovaps [rsp+0x80], xmm8
000071709abd959f  vmovaps [rsp+0x90], xmm9
000071709abd95a8  vmovaps [rsp+0xA0], xmm10
000071709abd95b1  vmovaps [rsp+0xB0], xmm11
000071709abd95ba  vmovaps [rsp+0xC0], xmm12
000071709abd95c3  vmovaps [rsp+0xD0], xmm13
000071709abd95cc  vmovaps [rsp+0xE0], xmm15
000071709abd95d5  sub rsp, 0x30
000071709abd95d9  movaps [rsp], xmm14
000071709abd95de  movaps [rsp+0x10], xmm8
000071709abd95e4  movaps [rsp+0x20], xmm4
000071709abd95e9  lea rdi, [rsp]
000071709abd95ed  mov esi, 0x00
000071709abd95f2  mov rax, 0x60B9B2ABC530
000071709abd95fc  call rax
000071709abd95fe  movaps xmm14, [rsp]
000071709abd9603  add rsp, 0x30
000071709abd9607  vmovaps xmm0, [rsp]
000071709abd960c  vmovaps xmm1, [rsp+0x10]
000071709abd9612  vmovaps xmm2, [rsp+0x20]
000071709abd9618  vmovaps xmm3, [rsp+0x30]
000071709abd961e  vmovaps xmm4, [rsp+0x40]
000071709abd9624  vmovaps xmm5, [rsp+0x50]
000071709abd962a  vmovaps xmm6, [rsp+0x60]
000071709abd9630  vmovaps xmm7, [rsp+0x70]
000071709abd9636  vmovaps xmm8, [rsp+0x80]
000071709abd963f  vmovaps xmm9, [rsp+0x90]
000071709abd9648  vmovaps xmm10, [rsp+0xA0]
000071709abd9651  vmovaps xmm11, [rsp+0xB0]
000071709abd965a  vmovaps xmm12, [rsp+0xC0]
000071709abd9663  vmovaps xmm13, [rsp+0xD0]
000071709abd966c  vmovaps xmm15, [rsp+0xE0]
000071709abd9675  add rsp, 0xF0
000071709abd967c  pop r11
000071709abd967e  pop r10
000071709abd9680  pop r9
000071709abd9682  pop r8
000071709abd9684  pop rsi
000071709abd9685  pop rdi
000071709abd9686  pop rdx
000071709abd9687  pop rcx
000071709abd9688  pop rax
000071709abd9689  add rsp, 0x08
000071709abd968d  jmp 0x000071709ABD6265
000071709abd9692  sub rsp, 0x08
000071709abd9696  push rax
000071709abd9697  push rcx
000071709abd9698  push rdx
000071709abd9699  push rdi
000071709abd969a  push rsi
000071709abd969b  push r8
000071709abd969d  push r9
000071709abd969f  push r10
000071709abd96a1  push r11
000071709abd96a3  sub rsp, 0xF0
000071709abd96aa  vmovaps [rsp], xmm0
000071709abd96af  vmovaps [rsp+0x10], xmm1
000071709abd96b5  vmovaps [rsp+0x20], xmm2
000071709abd96bb  vmovaps [rsp+0x30], xmm3
000071709abd96c1  vmovaps [rsp+0x40], xmm5
000071709abd96c7  vmovaps [rsp+0x50], xmm6
000071709abd96cd  vmovaps [rsp+0x60], xmm7
000071709abd96d3  vmovaps [rsp+0x70], xmm8
000071709abd96d9  vmovaps [rsp+0x80], xmm9
000071709abd96e2  vmovaps [rsp+0x90], xmm10
000071709abd96eb  vmovaps [rsp+0xA0], xmm11
000071709abd96f4  vmovaps [rsp+0xB0], xmm12
000071709abd96fd  vmovaps [rsp+0xC0], xmm13
000071709abd9706  vmovaps [rsp+0xD0], xmm14
000071709abd970f  vmovaps [rsp+0xE0], xmm15
000071709abd9718  sub rsp, 0x30
000071709abd971c  movaps [rsp], xmm4
000071709abd9720  movaps [rsp+0x10], xmm13
000071709abd9726  movaps [rsp+0x20], xmm8
000071709abd972c  lea rdi, [rsp]
000071709abd9730  mov esi, 0x00
000071709abd9735  mov rax, 0x60B9B2ABC530
000071709abd973f  call rax
000071709abd9741  movaps xmm4, [rsp]
000071709abd9745  add rsp, 0x30
000071709abd9749  vmovaps xmm0, [rsp]
000071709abd974e  vmovaps xmm1, [rsp+0x10]
000071709abd9754  vmovaps xmm2, [rsp+0x20]
000071709abd975a  vmovaps xmm3, [rsp+0x30]
000071709abd9760  vmovaps xmm5, [rsp+0x40]
000071709abd9766  vmovaps xmm6, [rsp+0x50]
000071709abd976c  vmovaps xmm7, [rsp+0x60]
000071709abd9772  vmovaps xmm8, [rsp+0x70]
000071709abd9778  vmovaps xmm9, [rsp+0x80]
000071709abd9781  vmovaps xmm10, [rsp+0x90]
000071709abd978a  vmovaps xmm11, [rsp+0xA0]
000071709abd9793  vmovaps xmm12, [rsp+0xB0]
000071709abd979c  vmovaps xmm13, [rsp+0xC0]
000071709abd97a5  vmovaps xmm14, [rsp+0xD0]
000071709abd97ae  vmovaps xmm15, [rsp+0xE0]
000071709abd97b7  add rsp, 0xF0
000071709abd97be  pop r11
000071709abd97c0  pop r10
000071709abd97c2  pop r9
000071709abd97c4  pop r8
000071709abd97c6  pop rsi
000071709abd97c7  pop rdi
000071709abd97c8  pop rdx
000071709abd97c9  pop rcx
000071709abd97ca  pop rax
000071709abd97cb  add rsp, 0x08
000071709abd97cf  jmp 0x000071709ABD628A
000071709abd97d4  sub rsp, 0x08
000071709abd97d8  push rax
000071709abd97d9  push rcx
000071709abd97da  push rdx
000071709abd97db  push rdi
000071709abd97dc  push rsi
000071709abd97dd  push r8
000071709abd97df  push r9
000071709abd97e1  push r10
000071709abd97e3  push r11
000071709abd97e5  sub rsp, 0xF0
000071709abd97ec  vmovaps [rsp], xmm0
000071709abd97f1  vmovaps [rsp+0x10], xmm1
000071709abd97f7  vmovaps [rsp+0x20], xmm2
000071709abd97fd  vmovaps [rsp+0x30], xmm3
000071709abd9803  vmovaps [rsp+0x40], xmm4
000071709abd9809  vmovaps [rsp+0x50], xmm5
000071709abd980f  vmovaps [rsp+0x60], xmm6
000071709abd9815  vmovaps [rsp+0x70], xmm7
000071709abd981b  vmovaps [rsp+0x80], xmm8
000071709abd9824  vmovaps [rsp+0x90], xmm9
000071709abd982d  vmovaps [rsp+0xA0], xmm10
000071709abd9836  vmovaps [rsp+0xB0], xmm11
000071709abd983f  vmovaps [rsp+0xC0], xmm12
000071709abd9848  vmovaps [rsp+0xD0], xmm14
000071709abd9851  vmovaps [rsp+0xE0], xmm15
000071709abd985a  sub rsp, 0x30
000071709abd985e  movaps [rsp], xmm13
000071709abd9863  movaps [rsp+0x10], xmm15
000071709abd9869  movaps [rsp+0x20], xmm9
000071709abd986f  lea rdi, [rsp]
000071709abd9873  mov esi, 0x00
000071709abd9878  mov rax, 0x60B9B2ABC530
000071709abd9882  call rax
000071709abd9884  movaps xmm13, [rsp]
000071709abd9889  add rsp, 0x30
000071709abd988d  vmovaps xmm0, [rsp]
000071709abd9892  vmovaps xmm1, [rsp+0x10]
000071709abd9898  vmovaps xmm2, [rsp+0x20]
000071709abd989e  vmovaps xmm3, [rsp+0x30]
000071709abd98a4  vmovaps xmm4, [rsp+0x40]
000071709abd98aa  vmovaps xmm5, [rsp+0x50]
000071709abd98b0  vmovaps xmm6, [rsp+0x60]
000071709abd98b6  vmovaps xmm7, [rsp+0x70]
000071709abd98bc  vmovaps xmm8, [rsp+0x80]
000071709abd98c5  vmovaps xmm9, [rsp+0x90]
000071709abd98ce  vmovaps xmm10, [rsp+0xA0]
000071709abd98d7  vmovaps xmm11, [rsp+0xB0]
000071709abd98e0  vmovaps xmm12, [rsp+0xC0]
000071709abd98e9  vmovaps xmm14, [rsp+0xD0]
000071709abd98f2  vmovaps xmm15, [rsp+0xE0]
000071709abd98fb  add rsp, 0xF0
000071709abd9902  pop r11
000071709abd9904  pop r10
000071709abd9906  pop r9
000071709abd9908  pop r8
000071709abd990a  pop rsi
000071709abd990b  pop rdi
000071709abd990c  pop rdx
000071709abd990d  pop rcx
000071709abd990e  pop rax
000071709abd990f  add rsp, 0x08
000071709abd9913  jmp 0x000071709ABD62A5
000071709abd9918  sub rsp, 0x08
000071709abd991c  push rax
000071709abd991d  push rcx
000071709abd991e  push rdx
000071709abd991f  push rdi
000071709abd9920  push rsi
000071709abd9921  push r8
000071709abd9923  push r9
000071709abd9925  push r10
000071709abd9927  push r11
000071709abd9929  sub rsp, 0xF0
000071709abd9930  vmovaps [rsp], xmm0
000071709abd9935  vmovaps [rsp+0x10], xmm1
000071709abd993b  vmovaps [rsp+0x20], xmm2
000071709abd9941  vmovaps [rsp+0x30], xmm3
000071709abd9947  vmovaps [rsp+0x40], xmm4
000071709abd994d  vmovaps [rsp+0x50], xmm5
000071709abd9953  vmovaps [rsp+0x60], xmm6
000071709abd9959  vmovaps [rsp+0x70], xmm7
000071709abd995f  vmovaps [rsp+0x80], xmm8
000071709abd9968  vmovaps [rsp+0x90], xmm9
000071709abd9971  vmovaps [rsp+0xA0], xmm10
000071709abd997a  vmovaps [rsp+0xB0], xmm11
000071709abd9983  vmovaps [rsp+0xC0], xmm12
000071709abd998c  vmovaps [rsp+0xD0], xmm13
000071709abd9995  vmovaps [rsp+0xE0], xmm14
000071709abd999e  sub rsp, 0x30
000071709abd99a2  movaps [rsp], xmm15
000071709abd99a7  movaps [rsp+0x10], xmm1
000071709abd99ac  movaps [rsp+0x20], xmm5
000071709abd99b1  lea rdi, [rsp]
000071709abd99b5  mov esi, 0x00
000071709abd99ba  mov rax, 0x60B9B2ABC530
000071709abd99c4  call rax
000071709abd99c6  movaps xmm15, [rsp]
000071709abd99cb  add rsp, 0x30
000071709abd99cf  vmovaps xmm0, [rsp]
000071709abd99d4  vmovaps xmm1, [rsp+0x10]
000071709abd99da  vmovaps xmm2, [rsp+0x20]
000071709abd99e0  vmovaps xmm3, [rsp+0x30]
000071709abd99e6  vmovaps xmm4, [rsp+0x40]
000071709abd99ec  vmovaps xmm5, [rsp+0x50]
000071709abd99f2  vmovaps xmm6, [rsp+0x60]
000071709abd99f8  vmovaps xmm7, [rsp+0x70]
000071709abd99fe  vmovaps xmm8, [rsp+0x80]
000071709abd9a07  vmovaps xmm9, [rsp+0x90]
000071709abd9a10  vmovaps xmm10, [rsp+0xA0]
000071709abd9a19  vmovaps xmm11, [rsp+0xB0]
000071709abd9a22  vmovaps xmm12, [rsp+0xC0]
000071709abd9a2b  vmovaps xmm13, [rsp+0xD0]
000071709abd9a34  vmovaps xmm14, [rsp+0xE0]
000071709abd9a3d  add rsp, 0xF0
000071709abd9a44  pop r11
000071709abd9a46  pop r10
000071709abd9a48  pop r9
000071709abd9a4a  pop r8
000071709abd9a4c  pop rsi
000071709abd9a4d  pop rdi
000071709abd9a4e  pop rdx
000071709abd9a4f  pop rcx
000071709abd9a50  pop rax
000071709abd9a51  add rsp, 0x08
000071709abd9a55  jmp 0x000071709ABD62C0
000071709abd9a5a  call 0x000071709AAD64F0
000071709abd9a5f  jmp 0x000071709ABD631B
000071709abd9a64  sub rsp, 0x08
000071709abd9a68  push rax
000071709abd9a69  push rcx
000071709abd9a6a  push rdx
000071709abd9a6b  push rdi
000071709abd9a6c  push rsi
000071709abd9a6d  push r8
000071709abd9a6f  push r9
000071709abd9a71  push r10
000071709abd9a73  push r11
000071709abd9a75  sub rsp, 0xF0
000071709abd9a7c  vmovaps [rsp], xmm0
000071709abd9a81  vmovaps [rsp+0x10], xmm1
000071709abd9a87  vmovaps [rsp+0x20], xmm2
000071709abd9a8d  vmovaps [rsp+0x30], xmm3
000071709abd9a93  vmovaps [rsp+0x40], xmm4
000071709abd9a99  vmovaps [rsp+0x50], xmm5
000071709abd9a9f  vmovaps [rsp+0x60], xmm6
000071709abd9aa5  vmovaps [rsp+0x70], xmm7
000071709abd9aab  vmovaps [rsp+0x80], xmm8
000071709abd9ab4  vmovaps [rsp+0x90], xmm10
000071709abd9abd  vmovaps [rsp+0xA0], xmm11
000071709abd9ac6  vmovaps [rsp+0xB0], xmm12
000071709abd9acf  vmovaps [rsp+0xC0], xmm13
000071709abd9ad8  vmovaps [rsp+0xD0], xmm14
000071709abd9ae1  vmovaps [rsp+0xE0], xmm15
000071709abd9aea  sub rsp, 0x30
000071709abd9aee  movaps [rsp], xmm9
000071709abd9af3  movaps [rsp+0x10], xmm8
000071709abd9af9  movaps [rsp+0x20], xmm11
000071709abd9aff  lea rdi, [rsp]
000071709abd9b03  mov esi, 0x00
000071709abd9b08  mov rax, 0x60B9B2ABC530
000071709abd9b12  call rax
000071709abd9b14  movaps xmm9, [rsp]
000071709abd9b19  add rsp, 0x30
000071709abd9b1d  vmovaps xmm0, [rsp]
000071709abd9b22  vmovaps xmm1, [rsp+0x10]
000071709abd9b28  vmovaps xmm2, [rsp+0x20]
000071709abd9b2e  vmovaps xmm3, [rsp+0x30]
000071709abd9b34  vmovaps xmm4, [rsp+0x40]
000071709abd9b3a  vmovaps xmm5, [rsp+0x50]
000071709abd9b40  vmovaps xmm6, [rsp+0x60]
000071709abd9b46  vmovaps xmm7, [rsp+0x70]
000071709abd9b4c  vmovaps xmm8, [rsp+0x80]
000071709abd9b55  vmovaps xmm10, [rsp+0x90]
000071709abd9b5e  vmovaps xmm11, [rsp+0xA0]
000071709abd9b67  vmovaps xmm12, [rsp+0xB0]
000071709abd9b70  vmovaps xmm13, [rsp+0xC0]
000071709abd9b79  vmovaps xmm14, [rsp+0xD0]
000071709abd9b82  vmovaps xmm15, [rsp+0xE0]
000071709abd9b8b  add rsp, 0xF0
000071709abd9b92  pop r11
000071709abd9b94  pop r10
000071709abd9b96  pop r9
000071709abd9b98  pop r8
000071709abd9b9a  pop rsi
000071709abd9b9b  pop rdi
000071709abd9b9c  pop rdx
000071709abd9b9d  pop rcx
000071709abd9b9e  pop rax
000071709abd9b9f  add rsp, 0x08
000071709abd9ba3  jmp 0x000071709ABD6352
000071709abd9ba8  sub rsp, 0x08
000071709abd9bac  push rax
000071709abd9bad  push rcx
000071709abd9bae  push rdx
000071709abd9baf  push rdi
000071709abd9bb0  push rsi
000071709abd9bb1  push r8
000071709abd9bb3  push r9
000071709abd9bb5  push r10
000071709abd9bb7  push r11
000071709abd9bb9  sub rsp, 0xF0
000071709abd9bc0  vmovaps [rsp], xmm0
000071709abd9bc5  vmovaps [rsp+0x10], xmm1
000071709abd9bcb  vmovaps [rsp+0x20], xmm2
000071709abd9bd1  vmovaps [rsp+0x30], xmm3
000071709abd9bd7  vmovaps [rsp+0x40], xmm4
000071709abd9bdd  vmovaps [rsp+0x50], xmm5
000071709abd9be3  vmovaps [rsp+0x60], xmm6
000071709abd9be9  vmovaps [rsp+0x70], xmm7
000071709abd9bef  vmovaps [rsp+0x80], xmm8
000071709abd9bf8  vmovaps [rsp+0x90], xmm9
000071709abd9c01  vmovaps [rsp+0xA0], xmm10
000071709abd9c0a  vmovaps [rsp+0xB0], xmm12
000071709abd9c13  vmovaps [rsp+0xC0], xmm13
000071709abd9c1c  vmovaps [rsp+0xD0], xmm14
000071709abd9c25  vmovaps [rsp+0xE0], xmm15
000071709abd9c2e  sub rsp, 0x30
000071709abd9c32  movaps [rsp], xmm11
000071709abd9c37  movaps [rsp+0x10], xmm10
000071709abd9c3d  movaps [rsp+0x20], xmm6
000071709abd9c42  lea rdi, [rsp]
000071709abd9c46  mov esi, 0x00
000071709abd9c4b  mov rax, 0x60B9B2ABC530
000071709abd9c55  call rax
000071709abd9c57  movaps xmm11, [rsp]
000071709abd9c5c  add rsp, 0x30
000071709abd9c60  vmovaps xmm0, [rsp]
000071709abd9c65  vmovaps xmm1, [rsp+0x10]
000071709abd9c6b  vmovaps xmm2, [rsp+0x20]
000071709abd9c71  vmovaps xmm3, [rsp+0x30]
000071709abd9c77  vmovaps xmm4, [rsp+0x40]
000071709abd9c7d  vmovaps xmm5, [rsp+0x50]
000071709abd9c83  vmovaps xmm6, [rsp+0x60]
000071709abd9c89  vmovaps xmm7, [rsp+0x70]
000071709abd9c8f  vmovaps xmm8, [rsp+0x80]
000071709abd9c98  vmovaps xmm9, [rsp+0x90]
000071709abd9ca1  vmovaps xmm10, [rsp+0xA0]
000071709abd9caa  vmovaps xmm12, [rsp+0xB0]
000071709abd9cb3  vmovaps xmm13, [rsp+0xC0]
000071709abd9cbc  vmovaps xmm14, [rsp+0xD0]
000071709abd9cc5  vmovaps xmm15, [rsp+0xE0]
000071709abd9cce  add rsp, 0xF0
000071709abd9cd5  pop r11
000071709abd9cd7  pop r10
000071709abd9cd9  pop r9
000071709abd9cdb  pop r8
000071709abd9cdd  pop rsi
000071709abd9cde  pop rdi
000071709abd9cdf  pop rdx
000071709abd9ce0  pop rcx
000071709abd9ce1  pop rax
000071709abd9ce2  add rsp, 0x08
000071709abd9ce6  jmp 0x000071709ABD636D
000071709abd9ceb  sub rsp, 0x08
000071709abd9cef  push rax
000071709abd9cf0  push rcx
000071709abd9cf1  push rdx
000071709abd9cf2  push rdi
000071709abd9cf3  push rsi
000071709abd9cf4  push r8
000071709abd9cf6  push r9
000071709abd9cf8  push r10
000071709abd9cfa  push r11
000071709abd9cfc  sub rsp, 0xF0
000071709abd9d03  vmovaps [rsp], xmm0
000071709abd9d08  vmovaps [rsp+0x10], xmm1
000071709abd9d0e  vmovaps [rsp+0x20], xmm2
000071709abd9d14  vmovaps [rsp+0x30], xmm3
000071709abd9d1a  vmovaps [rsp+0x40], xmm4
000071709abd9d20  vmovaps [rsp+0x50], xmm5
000071709abd9d26  vmovaps [rsp+0x60], xmm6
000071709abd9d2c  vmovaps [rsp+0x70], xmm7
000071709abd9d32  vmovaps [rsp+0x80], xmm8
000071709abd9d3b  vmovaps [rsp+0x90], xmm9
000071709abd9d44  vmovaps [rsp+0xA0], xmm11
000071709abd9d4d  vmovaps [rsp+0xB0], xmm12
000071709abd9d56  vmovaps [rsp+0xC0], xmm13
000071709abd9d5f  vmovaps [rsp+0xD0], xmm14
000071709abd9d68  vmovaps [rsp+0xE0], xmm15
000071709abd9d71  sub rsp, 0x30
000071709abd9d75  movaps [rsp], xmm10
000071709abd9d7a  movaps [rsp+0x10], xmm14
000071709abd9d80  movaps [rsp+0x20], xmm4
000071709abd9d85  lea rdi, [rsp]
000071709abd9d89  mov esi, 0x00
000071709abd9d8e  mov rax, 0x60B9B2ABC530
000071709abd9d98  call rax
000071709abd9d9a  movaps xmm10, [rsp]
000071709abd9d9f  add rsp, 0x30
000071709abd9da3  vmovaps xmm0, [rsp]
000071709abd9da8  vmovaps xmm1, [rsp+0x10]
000071709abd9dae  vmovaps xmm2, [rsp+0x20]
000071709abd9db4  vmovaps xmm3, [rsp+0x30]
000071709abd9dba  vmovaps xmm4, [rsp+0x40]
000071709abd9dc0  vmovaps xmm5, [rsp+0x50]
000071709abd9dc6  vmovaps xmm6, [rsp+0x60]
000071709abd9dcc  vmovaps xmm7, [rsp+0x70]
000071709abd9dd2  vmovaps xmm8, [rsp+0x80]
000071709abd9ddb  vmovaps xmm9, [rsp+0x90]
000071709abd9de4  vmovaps xmm11, [rsp+0xA0]
000071709abd9ded  vmovaps xmm12, [rsp+0xB0]
000071709abd9df6  vmovaps xmm13, [rsp+0xC0]
000071709abd9dff  vmovaps xmm14, [rsp+0xD0]
000071709abd9e08  vmovaps xmm15, [rsp+0xE0]
000071709abd9e11  add rsp, 0xF0
000071709abd9e18  pop r11
000071709abd9e1a  pop r10
000071709abd9e1c  pop r9
000071709abd9e1e  pop r8
000071709abd9e20  pop rsi
000071709abd9e21  pop rdi
000071709abd9e22  pop rdx
000071709abd9e23  pop rcx
000071709abd9e24  pop rax
000071709abd9e25  add rsp, 0x08
000071709abd9e29  jmp 0x000071709ABD6388
000071709abd9e2e  sub rsp, 0x08
000071709abd9e32  push rax
000071709abd9e33  push rcx
000071709abd9e34  push rdx
000071709abd9e35  push rdi
000071709abd9e36  push rsi
000071709abd9e37  push r8
000071709abd9e39  push r9
000071709abd9e3b  push r10
000071709abd9e3d  push r11
000071709abd9e3f  sub rsp, 0xF0
000071709abd9e46  vmovaps [rsp], xmm0
000071709abd9e4b  vmovaps [rsp+0x10], xmm1
000071709abd9e51  vmovaps [rsp+0x20], xmm2
000071709abd9e57  vmovaps [rsp+0x30], xmm3
000071709abd9e5d  vmovaps [rsp+0x40], xmm4
000071709abd9e63  vmovaps [rsp+0x50], xmm5
000071709abd9e69  vmovaps [rsp+0x60], xmm6
000071709abd9e6f  vmovaps [rsp+0x70], xmm7
000071709abd9e75  vmovaps [rsp+0x80], xmm9
000071709abd9e7e  vmovaps [rsp+0x90], xmm10
000071709abd9e87  vmovaps [rsp+0xA0], xmm11
000071709abd9e90  vmovaps [rsp+0xB0], xmm12
000071709abd9e99  vmovaps [rsp+0xC0], xmm13
000071709abd9ea2  vmovaps [rsp+0xD0], xmm14
000071709abd9eab  vmovaps [rsp+0xE0], xmm15
000071709abd9eb4  sub rsp, 0x30
000071709abd9eb8  movaps [rsp], xmm8
000071709abd9ebd  movaps [rsp+0x10], xmm1
000071709abd9ec2  movaps [rsp+0x20], xmm14
000071709abd9ec8  lea rdi, [rsp]
000071709abd9ecc  mov esi, 0x00
000071709abd9ed1  mov rax, 0x60B9B2ABC530
000071709abd9edb  call rax
000071709abd9edd  movaps xmm8, [rsp]
000071709abd9ee2  add rsp, 0x30
000071709abd9ee6  vmovaps xmm0, [rsp]
000071709abd9eeb  vmovaps xmm1, [rsp+0x10]
000071709abd9ef1  vmovaps xmm2, [rsp+0x20]
000071709abd9ef7  vmovaps xmm3, [rsp+0x30]
000071709abd9efd  vmovaps xmm4, [rsp+0x40]
000071709abd9f03  vmovaps xmm5, [rsp+0x50]
000071709abd9f09  vmovaps xmm6, [rsp+0x60]
000071709abd9f0f  vmovaps xmm7, [rsp+0x70]
000071709abd9f15  vmovaps xmm9, [rsp+0x80]
000071709abd9f1e  vmovaps xmm10, [rsp+0x90]
000071709abd9f27  vmovaps xmm11, [rsp+0xA0]
000071709abd9f30  vmovaps xmm12, [rsp+0xB0]
000071709abd9f39  vmovaps xmm13, [rsp+0xC0]
000071709abd9f42  vmovaps xmm14, [rsp+0xD0]
000071709abd9f4b  vmovaps xmm15, [rsp+0xE0]
000071709abd9f54  add rsp, 0xF0
000071709abd9f5b  pop r11
000071709abd9f5d  pop r10
000071709abd9f5f  pop r9
000071709abd9f61  pop r8
000071709abd9f63  pop rsi
000071709abd9f64  pop rdi
000071709abd9f65  pop rdx
000071709abd9f66  pop rcx
000071709abd9f67  pop rax
000071709abd9f68  add rsp, 0x08
000071709abd9f6c  jmp 0x000071709ABD63AE
000071709abd9f71  sub rsp, 0x08
000071709abd9f75  push rax
000071709abd9f76  push rcx
000071709abd9f77  push rdx
000071709abd9f78  push rdi
000071709abd9f79  push rsi
000071709abd9f7a  push r8
000071709abd9f7c  push r9
000071709abd9f7e  push r10
000071709abd9f80  push r11
000071709abd9f82  sub rsp, 0xF0
000071709abd9f89  vmovaps [rsp], xmm0
000071709abd9f8e  vmovaps [rsp+0x10], xmm1
000071709abd9f94  vmovaps [rsp+0x20], xmm2
000071709abd9f9a  vmovaps [rsp+0x30], xmm3
000071709abd9fa0  vmovaps [rsp+0x40], xmm4
000071709abd9fa6  vmovaps [rsp+0x50], xmm5
000071709abd9fac  vmovaps [rsp+0x60], xmm7
000071709abd9fb2  vmovaps [rsp+0x70], xmm8
000071709abd9fb8  vmovaps [rsp+0x80], xmm9
000071709abd9fc1  vmovaps [rsp+0x90], xmm10
000071709abd9fca  vmovaps [rsp+0xA0], xmm11
000071709abd9fd3  vmovaps [rsp+0xB0], xmm12
000071709abd9fdc  vmovaps [rsp+0xC0], xmm13
000071709abd9fe5  vmovaps [rsp+0xD0], xmm14
000071709abd9fee  vmovaps [rsp+0xE0], xmm15
000071709abd9ff7  sub rsp, 0x30
000071709abd9ffb  movaps [rsp], xmm6
000071709abd9fff  movaps [rsp+0x10], xmm1
000071709abda004  movaps [rsp+0x20], xmm14
000071709abda00a  lea rdi, [rsp]
000071709abda00e  mov esi, 0x00
000071709abda013  mov rax, 0x60B9B2ABC530
000071709abda01d  call rax
000071709abda01f  movaps xmm6, [rsp]
000071709abda023  add rsp, 0x30
000071709abda027  vmovaps xmm0, [rsp]
000071709abda02c  vmovaps xmm1, [rsp+0x10]
000071709abda032  vmovaps xmm2, [rsp+0x20]
000071709abda038  vmovaps xmm3, [rsp+0x30]
000071709abda03e  vmovaps xmm4, [rsp+0x40]
000071709abda044  vmovaps xmm5, [rsp+0x50]
000071709abda04a  vmovaps xmm7, [rsp+0x60]
000071709abda050  vmovaps xmm8, [rsp+0x70]
000071709abda056  vmovaps xmm9, [rsp+0x80]
000071709abda05f  vmovaps xmm10, [rsp+0x90]
000071709abda068  vmovaps xmm11, [rsp+0xA0]
000071709abda071  vmovaps xmm12, [rsp+0xB0]
000071709abda07a  vmovaps xmm13, [rsp+0xC0]
000071709abda083  vmovaps xmm14, [rsp+0xD0]
000071709abda08c  vmovaps xmm15, [rsp+0xE0]
000071709abda095  add rsp, 0xF0
000071709abda09c  pop r11
000071709abda09e  pop r10
000071709abda0a0  pop r9
000071709abda0a2  pop r8
000071709abda0a4  pop rsi
000071709abda0a5  pop rdi
000071709abda0a6  pop rdx
000071709abda0a7  pop rcx
000071709abda0a8  pop rax
000071709abda0a9  add rsp, 0x08
000071709abda0ad  jmp 0x000071709ABD63DA
000071709abda0b2  sub rsp, 0x08
000071709abda0b6  push rax
000071709abda0b7  push rcx
000071709abda0b8  push rdx
000071709abda0b9  push rdi
000071709abda0ba  push rsi
000071709abda0bb  push r8
000071709abda0bd  push r9
000071709abda0bf  push r10
000071709abda0c1  push r11
000071709abda0c3  sub rsp, 0xF0
000071709abda0ca  vmovaps [rsp], xmm0
000071709abda0cf  vmovaps [rsp+0x10], xmm1
000071709abda0d5  vmovaps [rsp+0x20], xmm2
000071709abda0db  vmovaps [rsp+0x30], xmm3
000071709abda0e1  vmovaps [rsp+0x40], xmm4
000071709abda0e7  vmovaps [rsp+0x50], xmm5
000071709abda0ed  vmovaps [rsp+0x60], xmm6
000071709abda0f3  vmovaps [rsp+0x70], xmm7
000071709abda0f9  vmovaps [rsp+0x80], xmm8
000071709abda102  vmovaps [rsp+0x90], xmm9
000071709abda10b  vmovaps [rsp+0xA0], xmm10
000071709abda114  vmovaps [rsp+0xB0], xmm11
000071709abda11d  vmovaps [rsp+0xC0], xmm12
000071709abda126  vmovaps [rsp+0xD0], xmm13
000071709abda12f  vmovaps [rsp+0xE0], xmm15
000071709abda138  sub rsp, 0x30
000071709abda13c  movaps [rsp], xmm14
000071709abda141  movaps [rsp+0x10], xmm12
000071709abda147  movaps [rsp+0x20], xmm1
000071709abda14c  lea rdi, [rsp]
000071709abda150  mov esi, 0x00
000071709abda155  mov rax, 0x60B9B2ABC530
000071709abda15f  call rax
000071709abda161  movaps xmm14, [rsp]
000071709abda166  add rsp, 0x30
000071709abda16a  vmovaps xmm0, [rsp]
000071709abda16f  vmovaps xmm1, [rsp+0x10]
000071709abda175  vmovaps xmm2, [rsp+0x20]
000071709abda17b  vmovaps xmm3, [rsp+0x30]
000071709abda181  vmovaps xmm4, [rsp+0x40]
000071709abda187  vmovaps xmm5, [rsp+0x50]
000071709abda18d  vmovaps xmm6, [rsp+0x60]
000071709abda193  vmovaps xmm7, [rsp+0x70]
000071709abda199  vmovaps xmm8, [rsp+0x80]
000071709abda1a2  vmovaps xmm9, [rsp+0x90]
000071709abda1ab  vmovaps xmm10, [rsp+0xA0]
000071709abda1b4  vmovaps xmm11, [rsp+0xB0]
000071709abda1bd  vmovaps xmm12, [rsp+0xC0]
000071709abda1c6  vmovaps xmm13, [rsp+0xD0]
000071709abda1cf  vmovaps xmm15, [rsp+0xE0]
000071709abda1d8  add rsp, 0xF0
000071709abda1df  pop r11
000071709abda1e1  pop r10
000071709abda1e3  pop r9
000071709abda1e5  pop r8
000071709abda1e7  pop rsi
000071709abda1e8  pop rdi
000071709abda1e9  pop rdx
000071709abda1ea  pop rcx
000071709abda1eb  pop rax
000071709abda1ec  add rsp, 0x08
000071709abda1f0  jmp 0x000071709ABD6400
000071709abda1f5  sub rsp, 0x08
000071709abda1f9  push rax
000071709abda1fa  push rcx
000071709abda1fb  push rdx
000071709abda1fc  push rdi
000071709abda1fd  push rsi
000071709abda1fe  push r8
000071709abda200  push r9
000071709abda202  push r10
000071709abda204  push r11
000071709abda206  sub rsp, 0xF0
000071709abda20d  vmovaps [rsp], xmm0
000071709abda212  vmovaps [rsp+0x10], xmm2
000071709abda218  vmovaps [rsp+0x20], xmm3
000071709abda21e  vmovaps [rsp+0x30], xmm4
000071709abda224  vmovaps [rsp+0x40], xmm5
000071709abda22a  vmovaps [rsp+0x50], xmm6
000071709abda230  vmovaps [rsp+0x60], xmm7
000071709abda236  vmovaps [rsp+0x70], xmm8
000071709abda23c  vmovaps [rsp+0x80], xmm9
000071709abda245  vmovaps [rsp+0x90], xmm10
000071709abda24e  vmovaps [rsp+0xA0], xmm11
000071709abda257  vmovaps [rsp+0xB0], xmm12
000071709abda260  vmovaps [rsp+0xC0], xmm13
000071709abda269  vmovaps [rsp+0xD0], xmm14
000071709abda272  vmovaps [rsp+0xE0], xmm15
000071709abda27b  sub rsp, 0x30
000071709abda27f  movaps [rsp], xmm1
000071709abda283  movaps [rsp+0x10], xmm13
000071709abda289  movaps [rsp+0x20], xmm9
000071709abda28f  lea rdi, [rsp]
000071709abda293  mov esi, 0x00
000071709abda298  mov rax, 0x60B9B2ABC530
000071709abda2a2  call rax
000071709abda2a4  movaps xmm1, [rsp]
000071709abda2a8  add rsp, 0x30
000071709abda2ac  vmovaps xmm0, [rsp]
000071709abda2b1  vmovaps xmm2, [rsp+0x10]
000071709abda2b7  vmovaps xmm3, [rsp+0x20]
000071709abda2bd  vmovaps xmm4, [rsp+0x30]
000071709abda2c3  vmovaps xmm5, [rsp+0x40]
000071709abda2c9  vmovaps xmm6, [rsp+0x50]
000071709abda2cf  vmovaps xmm7, [rsp+0x60]
000071709abda2d5  vmovaps xmm8, [rsp+0x70]
000071709abda2db  vmovaps xmm9, [rsp+0x80]
000071709abda2e4  vmovaps xmm10, [rsp+0x90]
000071709abda2ed  vmovaps xmm11, [rsp+0xA0]
000071709abda2f6  vmovaps xmm12, [rsp+0xB0]
000071709abda2ff  vmovaps xmm13, [rsp+0xC0]
000071709abda308  vmovaps xmm14, [rsp+0xD0]
000071709abda311  vmovaps xmm15, [rsp+0xE0]
000071709abda31a  add rsp, 0xF0
000071709abda321  pop r11
000071709abda323  pop r10
000071709abda325  pop r9
000071709abda327  pop r8
000071709abda329  pop rsi
000071709abda32a  pop rdi
000071709abda32b  pop rdx
000071709abda32c  pop rcx
000071709abda32d  pop rax
000071709abda32e  add rsp, 0x08
000071709abda332  jmp 0x000071709ABD641A
000071709abda337  sub rsp, 0x08
000071709abda33b  push rax
000071709abda33c  push rcx
000071709abda33d  push rdx
000071709abda33e  push rdi
000071709abda33f  push rsi
000071709abda340  push r8
000071709abda342  push r9
000071709abda344  push r10
000071709abda346  push r11
000071709abda348  sub rsp, 0xF0
000071709abda34f  vmovaps [rsp], xmm0
000071709abda354  vmovaps [rsp+0x10], xmm1
000071709abda35a  vmovaps [rsp+0x20], xmm2
000071709abda360  vmovaps [rsp+0x30], xmm3
000071709abda366  vmovaps [rsp+0x40], xmm4
000071709abda36c  vmovaps [rsp+0x50], xmm5
000071709abda372  vmovaps [rsp+0x60], xmm6
000071709abda378  vmovaps [rsp+0x70], xmm7
000071709abda37e  vmovaps [rsp+0x80], xmm8
000071709abda387  vmovaps [rsp+0x90], xmm9
000071709abda390  vmovaps [rsp+0xA0], xmm10
000071709abda399  vmovaps [rsp+0xB0], xmm11
000071709abda3a2  vmovaps [rsp+0xC0], xmm13
000071709abda3ab  vmovaps [rsp+0xD0], xmm14
000071709abda3b4  vmovaps [rsp+0xE0], xmm15
000071709abda3bd  sub rsp, 0x30
000071709abda3c1  movaps [rsp], xmm12
000071709abda3c6  movaps [rsp+0x10], xmm7
000071709abda3cb  movaps [rsp+0x20], xmm13
000071709abda3d1  lea rdi, [rsp]
000071709abda3d5  mov esi, 0x00
000071709abda3da  mov rax, 0x60B9B2ABC530
000071709abda3e4  call rax
000071709abda3e6  movaps xmm12, [rsp]
000071709abda3eb  add rsp, 0x30
000071709abda3ef  vmovaps xmm0, [rsp]
000071709abda3f4  vmovaps xmm1, [rsp+0x10]
000071709abda3fa  vmovaps xmm2, [rsp+0x20]
000071709abda400  vmovaps xmm3, [rsp+0x30]
000071709abda406  vmovaps xmm4, [rsp+0x40]
000071709abda40c  vmovaps xmm5, [rsp+0x50]
000071709abda412  vmovaps xmm6, [rsp+0x60]
000071709abda418  vmovaps xmm7, [rsp+0x70]
000071709abda41e  vmovaps xmm8, [rsp+0x80]
000071709abda427  vmovaps xmm9, [rsp+0x90]
000071709abda430  vmovaps xmm10, [rsp+0xA0]
000071709abda439  vmovaps xmm11, [rsp+0xB0]
000071709abda442  vmovaps xmm13, [rsp+0xC0]
000071709abda44b  vmovaps xmm14, [rsp+0xD0]
000071709abda454  vmovaps xmm15, [rsp+0xE0]
000071709abda45d  add rsp, 0xF0
000071709abda464  pop r11
000071709abda466  pop r10
000071709abda468  pop r9
000071709abda46a  pop r8
000071709abda46c  pop rsi
000071709abda46d  pop rdi
000071709abda46e  pop rdx
000071709abda46f  pop rcx
000071709abda470  pop rax
000071709abda471  add rsp, 0x08
000071709abda475  jmp 0x000071709ABD6441
000071709abda47a  sub rsp, 0x08
000071709abda47e  push rax
000071709abda47f  push rcx
000071709abda480  push rdx
000071709abda481  push rdi
000071709abda482  push rsi
000071709abda483  push r8
000071709abda485  push r9
000071709abda487  push r10
000071709abda489  push r11
000071709abda48b  sub rsp, 0xF0
000071709abda492  vmovaps [rsp], xmm0
000071709abda497  vmovaps [rsp+0x10], xmm1
000071709abda49d  vmovaps [rsp+0x20], xmm2
000071709abda4a3  vmovaps [rsp+0x30], xmm3
000071709abda4a9  vmovaps [rsp+0x40], xmm4
000071709abda4af  vmovaps [rsp+0x50], xmm5
000071709abda4b5  vmovaps [rsp+0x60], xmm6
000071709abda4bb  vmovaps [rsp+0x70], xmm7
000071709abda4c1  vmovaps [rsp+0x80], xmm8
000071709abda4ca  vmovaps [rsp+0x90], xmm9
000071709abda4d3  vmovaps [rsp+0xA0], xmm10
000071709abda4dc  vmovaps [rsp+0xB0], xmm11
000071709abda4e5  vmovaps [rsp+0xC0], xmm12
000071709abda4ee  vmovaps [rsp+0xD0], xmm14
000071709abda4f7  vmovaps [rsp+0xE0], xmm15
000071709abda500  sub rsp, 0x30
000071709abda504  movaps [rsp], xmm13
000071709abda509  movaps [rsp+0x10], xmm15
000071709abda50f  movaps [rsp+0x20], xmm8
000071709abda515  lea rdi, [rsp]
000071709abda519  mov esi, 0x00
000071709abda51e  mov rax, 0x60B9B2ABC530
000071709abda528  call rax
000071709abda52a  movaps xmm13, [rsp]
000071709abda52f  add rsp, 0x30
000071709abda533  vmovaps xmm0, [rsp]
000071709abda538  vmovaps xmm1, [rsp+0x10]
000071709abda53e  vmovaps xmm2, [rsp+0x20]
000071709abda544  vmovaps xmm3, [rsp+0x30]
000071709abda54a  vmovaps xmm4, [rsp+0x40]
000071709abda550  vmovaps xmm5, [rsp+0x50]
000071709abda556  vmovaps xmm6, [rsp+0x60]
000071709abda55c  vmovaps xmm7, [rsp+0x70]
000071709abda562  vmovaps xmm8, [rsp+0x80]
000071709abda56b  vmovaps xmm9, [rsp+0x90]
000071709abda574  vmovaps xmm10, [rsp+0xA0]
000071709abda57d  vmovaps xmm11, [rsp+0xB0]
000071709abda586  vmovaps xmm12, [rsp+0xC0]
000071709abda58f  vmovaps xmm14, [rsp+0xD0]
000071709abda598  vmovaps xmm15, [rsp+0xE0]
000071709abda5a1  add rsp, 0xF0
000071709abda5a8  pop r11
000071709abda5aa  pop r10
000071709abda5ac  pop r9
000071709abda5ae  pop r8
000071709abda5b0  pop rsi
000071709abda5b1  pop rdi
000071709abda5b2  pop rdx
000071709abda5b3  pop rcx
000071709abda5b4  pop rax
000071709abda5b5  add rsp, 0x08
000071709abda5b9  jmp 0x000071709ABD645C
000071709abda5be  sub rsp, 0x08
000071709abda5c2  push rax
000071709abda5c3  push rcx
000071709abda5c4  push rdx
000071709abda5c5  push rdi
000071709abda5c6  push rsi
000071709abda5c7  push r8
000071709abda5c9  push r9
000071709abda5cb  push r10
000071709abda5cd  push r11
000071709abda5cf  sub rsp, 0xF0
000071709abda5d6  vmovaps [rsp], xmm0
000071709abda5db  vmovaps [rsp+0x10], xmm1
000071709abda5e1  vmovaps [rsp+0x20], xmm2
000071709abda5e7  vmovaps [rsp+0x30], xmm3
000071709abda5ed  vmovaps [rsp+0x40], xmm4
000071709abda5f3  vmovaps [rsp+0x50], xmm5
000071709abda5f9  vmovaps [rsp+0x60], xmm6
000071709abda5ff  vmovaps [rsp+0x70], xmm7
000071709abda605  vmovaps [rsp+0x80], xmm9
000071709abda60e  vmovaps [rsp+0x90], xmm10
000071709abda617  vmovaps [rsp+0xA0], xmm11
000071709abda620  vmovaps [rsp+0xB0], xmm12
000071709abda629  vmovaps [rsp+0xC0], xmm13
000071709abda632  vmovaps [rsp+0xD0], xmm14
000071709abda63b  vmovaps [rsp+0xE0], xmm15
000071709abda644  sub rsp, 0x30
000071709abda648  movaps [rsp], xmm8
000071709abda64d  movaps [rsp+0x10], xmm15
000071709abda653  movaps [rsp+0x20], xmm9
000071709abda659  lea rdi, [rsp]
000071709abda65d  mov esi, 0x00
000071709abda662  mov rax, 0x60B9B2ABC530
000071709abda66c  call rax
000071709abda66e  movaps xmm8, [rsp]
000071709abda673  add rsp, 0x30
000071709abda677  vmovaps xmm0, [rsp]
000071709abda67c  vmovaps xmm1, [rsp+0x10]
000071709abda682  vmovaps xmm2, [rsp+0x20]
000071709abda688  vmovaps xmm3, [rsp+0x30]
000071709abda68e  vmovaps xmm4, [rsp+0x40]
000071709abda694  vmovaps xmm5, [rsp+0x50]
000071709abda69a  vmovaps xmm6, [rsp+0x60]
000071709abda6a0  vmovaps xmm7, [rsp+0x70]
000071709abda6a6  vmovaps xmm9, [rsp+0x80]
000071709abda6af  vmovaps xmm10, [rsp+0x90]
000071709abda6b8  vmovaps xmm11, [rsp+0xA0]
000071709abda6c1  vmovaps xmm12, [rsp+0xB0]
000071709abda6ca  vmovaps xmm13, [rsp+0xC0]
000071709abda6d3  vmovaps xmm14, [rsp+0xD0]
000071709abda6dc  vmovaps xmm15, [rsp+0xE0]
000071709abda6e5  add rsp, 0xF0
000071709abda6ec  pop r11
000071709abda6ee  pop r10
000071709abda6f0  pop r9
000071709abda6f2  pop r8
000071709abda6f4  pop rsi
000071709abda6f5  pop rdi
000071709abda6f6  pop rdx
000071709abda6f7  pop rcx
000071709abda6f8  pop rax
000071709abda6f9  add rsp, 0x08
000071709abda6fd  jmp 0x000071709ABD648A
000071709abda702  sub rsp, 0x08
000071709abda706  push rax
000071709abda707  push rcx
000071709abda708  push rdx
000071709abda709  push rdi
000071709abda70a  push rsi
000071709abda70b  push r8
000071709abda70d  push r9
000071709abda70f  push r10
000071709abda711  push r11
000071709abda713  sub rsp, 0xF0
000071709abda71a  vmovaps [rsp], xmm0
000071709abda71f  vmovaps [rsp+0x10], xmm1
000071709abda725  vmovaps [rsp+0x20], xmm2
000071709abda72b  vmovaps [rsp+0x30], xmm3
000071709abda731  vmovaps [rsp+0x40], xmm4
000071709abda737  vmovaps [rsp+0x50], xmm5
000071709abda73d  vmovaps [rsp+0x60], xmm6
000071709abda743  vmovaps [rsp+0x70], xmm7
000071709abda749  vmovaps [rsp+0x80], xmm8
000071709abda752  vmovaps [rsp+0x90], xmm9
000071709abda75b  vmovaps [rsp+0xA0], xmm10
000071709abda764  vmovaps [rsp+0xB0], xmm11
000071709abda76d  vmovaps [rsp+0xC0], xmm12
000071709abda776  vmovaps [rsp+0xD0], xmm13
000071709abda77f  vmovaps [rsp+0xE0], xmm14
000071709abda788  sub rsp, 0x30
000071709abda78c  movaps [rsp], xmm15
000071709abda791  movaps [rsp+0x10], xmm11
000071709abda797  movaps [rsp+0x20], xmm6
000071709abda79c  lea rdi, [rsp]
000071709abda7a0  mov esi, 0x00
000071709abda7a5  mov rax, 0x60B9B2ABC530
000071709abda7af  call rax
000071709abda7b1  movaps xmm15, [rsp]
000071709abda7b6  add rsp, 0x30
000071709abda7ba  vmovaps xmm0, [rsp]
000071709abda7bf  vmovaps xmm1, [rsp+0x10]
000071709abda7c5  vmovaps xmm2, [rsp+0x20]
000071709abda7cb  vmovaps xmm3, [rsp+0x30]
000071709abda7d1  vmovaps xmm4, [rsp+0x40]
000071709abda7d7  vmovaps xmm5, [rsp+0x50]
000071709abda7dd  vmovaps xmm6, [rsp+0x60]
000071709abda7e3  vmovaps xmm7, [rsp+0x70]
000071709abda7e9  vmovaps xmm8, [rsp+0x80]
000071709abda7f2  vmovaps xmm9, [rsp+0x90]
000071709abda7fb  vmovaps xmm10, [rsp+0xA0]
000071709abda804  vmovaps xmm11, [rsp+0xB0]
000071709abda80d  vmovaps xmm12, [rsp+0xC0]
000071709abda816  vmovaps xmm13, [rsp+0xD0]
000071709abda81f  vmovaps xmm14, [rsp+0xE0]
000071709abda828  add rsp, 0xF0
000071709abda82f  pop r11
000071709abda831  pop r10
000071709abda833  pop r9
000071709abda835  pop r8
000071709abda837  pop rsi
000071709abda838  pop rdi
000071709abda839  pop rdx
000071709abda83a  pop rcx
000071709abda83b  pop rax
000071709abda83c  add rsp, 0x08
000071709abda840  jmp 0x000071709ABD64A5
000071709abda845  sub rsp, 0x08
000071709abda849  push rax
000071709abda84a  push rcx
000071709abda84b  push rdx
000071709abda84c  push rdi
000071709abda84d  push rsi
000071709abda84e  push r8
000071709abda850  push r9
000071709abda852  push r10
000071709abda854  push r11
000071709abda856  sub rsp, 0xF0
000071709abda85d  vmovaps [rsp], xmm0
000071709abda862  vmovaps [rsp+0x10], xmm1
000071709abda868  vmovaps [rsp+0x20], xmm2
000071709abda86e  vmovaps [rsp+0x30], xmm3
000071709abda874  vmovaps [rsp+0x40], xmm4
000071709abda87a  vmovaps [rsp+0x50], xmm5
000071709abda880  vmovaps [rsp+0x60], xmm6
000071709abda886  vmovaps [rsp+0x70], xmm8
000071709abda88c  vmovaps [rsp+0x80], xmm9
000071709abda895  vmovaps [rsp+0x90], xmm10
000071709abda89e  vmovaps [rsp+0xA0], xmm11
000071709abda8a7  vmovaps [rsp+0xB0], xmm12
000071709abda8b0  vmovaps [rsp+0xC0], xmm13
000071709abda8b9  vmovaps [rsp+0xD0], xmm14
000071709abda8c2  vmovaps [rsp+0xE0], xmm15
000071709abda8cb  sub rsp, 0x30
000071709abda8cf  movaps [rsp], xmm7
000071709abda8d3  movaps [rsp+0x10], xmm11
000071709abda8d9  movaps [rsp+0x20], xmm9
000071709abda8df  lea rdi, [rsp]
000071709abda8e3  mov esi, 0x00
000071709abda8e8  mov rax, 0x60B9B2ABC530
000071709abda8f2  call rax
000071709abda8f4  movaps xmm7, [rsp]
000071709abda8f8  add rsp, 0x30
000071709abda8fc  vmovaps xmm0, [rsp]
000071709abda901  vmovaps xmm1, [rsp+0x10]
000071709abda907  vmovaps xmm2, [rsp+0x20]
000071709abda90d  vmovaps xmm3, [rsp+0x30]
000071709abda913  vmovaps xmm4, [rsp+0x40]
000071709abda919  vmovaps xmm5, [rsp+0x50]
000071709abda91f  vmovaps xmm6, [rsp+0x60]
000071709abda925  vmovaps xmm8, [rsp+0x70]
000071709abda92b  vmovaps xmm9, [rsp+0x80]
000071709abda934  vmovaps xmm10, [rsp+0x90]
000071709abda93d  vmovaps xmm11, [rsp+0xA0]
000071709abda946  vmovaps xmm12, [rsp+0xB0]
000071709abda94f  vmovaps xmm13, [rsp+0xC0]
000071709abda958  vmovaps xmm14, [rsp+0xD0]
000071709abda961  vmovaps xmm15, [rsp+0xE0]
000071709abda96a  add rsp, 0xF0
000071709abda971  pop r11
000071709abda973  pop r10
000071709abda975  pop r9
000071709abda977  pop r8
000071709abda979  pop rsi
000071709abda97a  pop rdi
000071709abda97b  pop rdx
000071709abda97c  pop rcx
000071709abda97d  pop rax
000071709abda97e  add rsp, 0x08
000071709abda982  jmp 0x000071709ABD64D2
000071709abda987  sub rsp, 0x08
000071709abda98b  push rax
000071709abda98c  push rcx
000071709abda98d  push rdx
000071709abda98e  push rdi
000071709abda98f  push rsi
000071709abda990  push r8
000071709abda992  push r9
000071709abda994  push r10
000071709abda996  push r11
000071709abda998  sub rsp, 0xF0
000071709abda99f  vmovaps [rsp], xmm0
000071709abda9a4  vmovaps [rsp+0x10], xmm1
000071709abda9aa  vmovaps [rsp+0x20], xmm2
000071709abda9b0  vmovaps [rsp+0x30], xmm3
000071709abda9b6  vmovaps [rsp+0x40], xmm4
000071709abda9bc  vmovaps [rsp+0x50], xmm5
000071709abda9c2  vmovaps [rsp+0x60], xmm6
000071709abda9c8  vmovaps [rsp+0x70], xmm7
000071709abda9ce  vmovaps [rsp+0x80], xmm8
000071709abda9d7  vmovaps [rsp+0x90], xmm9
000071709abda9e0  vmovaps [rsp+0xA0], xmm10
000071709abda9e9  vmovaps [rsp+0xB0], xmm12
000071709abda9f2  vmovaps [rsp+0xC0], xmm13
000071709abda9fb  vmovaps [rsp+0xD0], xmm14
000071709abdaa04  vmovaps [rsp+0xE0], xmm15
000071709abdaa0d  sub rsp, 0x30
000071709abdaa11  movaps [rsp], xmm11
000071709abdaa16  movaps [rsp+0x10], xmm10
000071709abdaa1c  movaps [rsp+0x20], xmm14
000071709abdaa22  lea rdi, [rsp]
000071709abdaa26  mov esi, 0x00
000071709abdaa2b  mov rax, 0x60B9B2ABC530
000071709abdaa35  call rax
000071709abdaa37  movaps xmm11, [rsp]
000071709abdaa3c  add rsp, 0x30
000071709abdaa40  vmovaps xmm0, [rsp]
000071709abdaa45  vmovaps xmm1, [rsp+0x10]
000071709abdaa4b  vmovaps xmm2, [rsp+0x20]
000071709abdaa51  vmovaps xmm3, [rsp+0x30]
000071709abdaa57  vmovaps xmm4, [rsp+0x40]
000071709abdaa5d  vmovaps xmm5, [rsp+0x50]
000071709abdaa63  vmovaps xmm6, [rsp+0x60]
000071709abdaa69  vmovaps xmm7, [rsp+0x70]
000071709abdaa6f  vmovaps xmm8, [rsp+0x80]
000071709abdaa78  vmovaps xmm9, [rsp+0x90]
000071709abdaa81  vmovaps xmm10, [rsp+0xA0]
000071709abdaa8a  vmovaps xmm12, [rsp+0xB0]
000071709abdaa93  vmovaps xmm13, [rsp+0xC0]
000071709abdaa9c  vmovaps xmm14, [rsp+0xD0]
000071709abdaaa5  vmovaps xmm15, [rsp+0xE0]
000071709abdaaae  add rsp, 0xF0
000071709abdaab5  pop r11
000071709abdaab7  pop r10
000071709abdaab9  pop r9
000071709abdaabb  pop r8
000071709abdaabd  pop rsi
000071709abdaabe  pop rdi
000071709abdaabf  pop rdx
000071709abdaac0  pop rcx
000071709abdaac1  pop rax
000071709abdaac2  add rsp, 0x08
000071709abdaac6  jmp 0x000071709ABD64ED
000071709abdaacb  call 0x000071709AAE45A0
000071709abdaad0  jmp 0x000071709ABD64F7
000071709abdaad5  sub rsp, 0x08
000071709abdaad9  push rax
000071709abdaada  push rcx
000071709abdaadb  push rdx
000071709abdaadc  push rdi
000071709abdaadd  push rsi
000071709abdaade  push r8
000071709abdaae0  push r9
000071709abdaae2  push r10
000071709abdaae4  push r11
000071709abdaae6  sub rsp, 0xF0
000071709abdaaed  vmovaps [rsp], xmm0
000071709abdaaf2  vmovaps [rsp+0x10], xmm1
000071709abdaaf8  vmovaps [rsp+0x20], xmm2
000071709abdaafe  vmovaps [rsp+0x30], xmm3
000071709abdab04  vmovaps [rsp+0x40], xmm4
000071709abdab0a  vmovaps [rsp+0x50], xmm5
000071709abdab10  vmovaps [rsp+0x60], xmm6
000071709abdab16  vmovaps [rsp+0x70], xmm7
000071709abdab1c  vmovaps [rsp+0x80], xmm8
000071709abdab25  vmovaps [rsp+0x90], xmm9
000071709abdab2e  vmovaps [rsp+0xA0], xmm11
000071709abdab37  vmovaps [rsp+0xB0], xmm12
000071709abdab40  vmovaps [rsp+0xC0], xmm13
000071709abdab49  vmovaps [rsp+0xD0], xmm14
000071709abdab52  vmovaps [rsp+0xE0], xmm15
000071709abdab5b  sub rsp, 0x30
000071709abdab5f  movaps [rsp], xmm10
000071709abdab64  movaps [rsp+0x10], xmm1
000071709abdab69  movaps [rsp+0x20], xmm12
000071709abdab6f  lea rdi, [rsp]
000071709abdab73  mov esi, 0x00
000071709abdab78  mov rax, 0x60B9B2ABC530
000071709abdab82  call rax
000071709abdab84  movaps xmm10, [rsp]
000071709abdab89  add rsp, 0x30
000071709abdab8d  vmovaps xmm0, [rsp]
000071709abdab92  vmovaps xmm1, [rsp+0x10]
000071709abdab98  vmovaps xmm2, [rsp+0x20]
000071709abdab9e  vmovaps xmm3, [rsp+0x30]
000071709abdaba4  vmovaps xmm4, [rsp+0x40]
000071709abdabaa  vmovaps xmm5, [rsp+0x50]
000071709abdabb0  vmovaps xmm6, [rsp+0x60]
000071709abdabb6  vmovaps xmm7, [rsp+0x70]
000071709abdabbc  vmovaps xmm8, [rsp+0x80]
000071709abdabc5  vmovaps xmm9, [rsp+0x90]
000071709abdabce  vmovaps xmm11, [rsp+0xA0]
000071709abdabd7  vmovaps xmm12, [rsp+0xB0]
000071709abdabe0  vmovaps xmm13, [rsp+0xC0]
000071709abdabe9  vmovaps xmm14, [rsp+0xD0]
000071709abdabf2  vmovaps xmm15, [rsp+0xE0]
000071709abdabfb  add rsp, 0xF0
000071709abdac02  pop r11
000071709abdac04  pop r10
000071709abdac06  pop r9
000071709abdac08  pop r8
000071709abdac0a  pop rsi
000071709abdac0b  pop rdi
000071709abdac0c  pop rdx
000071709abdac0d  pop rcx
000071709abdac0e  pop rax
000071709abdac0f  add rsp, 0x08
000071709abdac13  jmp 0x000071709ABD651A
000071709abdac18  sub rsp, 0x08
000071709abdac1c  push rax
000071709abdac1d  push rcx
000071709abdac1e  push rdx
000071709abdac1f  push rdi
000071709abdac20  push rsi
000071709abdac21  push r8
000071709abdac23  push r9
000071709abdac25  push r10
000071709abdac27  push r11
000071709abdac29  sub rsp, 0xF0
000071709abdac30  vmovaps [rsp], xmm0
000071709abdac35  vmovaps [rsp+0x10], xmm1
000071709abdac3b  vmovaps [rsp+0x20], xmm2
000071709abdac41  vmovaps [rsp+0x30], xmm3
000071709abdac47  vmovaps [rsp+0x40], xmm4
000071709abdac4d  vmovaps [rsp+0x50], xmm5
000071709abdac53  vmovaps [rsp+0x60], xmm6
000071709abdac59  vmovaps [rsp+0x70], xmm7
000071709abdac5f  vmovaps [rsp+0x80], xmm8
000071709abdac68  vmovaps [rsp+0x90], xmm9
000071709abdac71  vmovaps [rsp+0xA0], xmm10
000071709abdac7a  vmovaps [rsp+0xB0], xmm11
000071709abdac83  vmovaps [rsp+0xC0], xmm13
000071709abdac8c  vmovaps [rsp+0xD0], xmm14
000071709abdac95  vmovaps [rsp+0xE0], xmm15
000071709abdac9e  sub rsp, 0x30
000071709abdaca2  movaps [rsp], xmm12
000071709abdaca7  movaps [rsp+0x10], xmm14
000071709abdacad  movaps [rsp+0x20], xmm1
000071709abdacb2  lea rdi, [rsp]
000071709abdacb6  mov esi, 0x00
000071709abdacbb  mov rax, 0x60B9B2ABC530
000071709abdacc5  call rax
000071709abdacc7  movaps xmm12, [rsp]
000071709abdaccc  add rsp, 0x30
000071709abdacd0  vmovaps xmm0, [rsp]
000071709abdacd5  vmovaps xmm1, [rsp+0x10]
000071709abdacdb  vmovaps xmm2, [rsp+0x20]
000071709abdace1  vmovaps xmm3, [rsp+0x30]
000071709abdace7  vmovaps xmm4, [rsp+0x40]
000071709abdaced  vmovaps xmm5, [rsp+0x50]
000071709abdacf3  vmovaps xmm6, [rsp+0x60]
000071709abdacf9  vmovaps xmm7, [rsp+0x70]
000071709abdacff  vmovaps xmm8, [rsp+0x80]
000071709abdad08  vmovaps xmm9, [rsp+0x90]
000071709abdad11  vmovaps xmm10, [rsp+0xA0]
000071709abdad1a  vmovaps xmm11, [rsp+0xB0]
000071709abdad23  vmovaps xmm13, [rsp+0xC0]
000071709abdad2c  vmovaps xmm14, [rsp+0xD0]
000071709abdad35  vmovaps xmm15, [rsp+0xE0]
000071709abdad3e  add rsp, 0xF0
000071709abdad45  pop r11
000071709abdad47  pop r10
000071709abdad49  pop r9
000071709abdad4b  pop r8
000071709abdad4d  pop rsi
000071709abdad4e  pop rdi
000071709abdad4f  pop rdx
000071709abdad50  pop rcx
000071709abdad51  pop rax
000071709abdad52  add rsp, 0x08
000071709abdad56  jmp 0x000071709ABD6549
000071709abdad5b  sub rsp, 0x08
000071709abdad5f  push rax
000071709abdad60  push rcx
000071709abdad61  push rdx
000071709abdad62  push rdi
000071709abdad63  push rsi
000071709abdad64  push r8
000071709abdad66  push r9
000071709abdad68  push r10
000071709abdad6a  push r11
000071709abdad6c  sub rsp, 0xF0
000071709abdad73  vmovaps [rsp], xmm0
000071709abdad78  vmovaps [rsp+0x10], xmm1
000071709abdad7e  vmovaps [rsp+0x20], xmm2
000071709abdad84  vmovaps [rsp+0x30], xmm3
000071709abdad8a  vmovaps [rsp+0x40], xmm4
000071709abdad90  vmovaps [rsp+0x50], xmm5
000071709abdad96  vmovaps [rsp+0x60], xmm6
000071709abdad9c  vmovaps [rsp+0x70], xmm7
000071709abdada2  vmovaps [rsp+0x80], xmm8
000071709abdadab  vmovaps [rsp+0x90], xmm9
000071709abdadb4  vmovaps [rsp+0xA0], xmm10
000071709abdadbd  vmovaps [rsp+0xB0], xmm11
000071709abdadc6  vmovaps [rsp+0xC0], xmm12
000071709abdadcf  vmovaps [rsp+0xD0], xmm13
000071709abdadd8  vmovaps [rsp+0xE0], xmm15
000071709abdade1  sub rsp, 0x30
000071709abdade5  movaps [rsp], xmm14
000071709abdadea  movaps [rsp+0x10], xmm9
000071709abdadf0  movaps [rsp+0x20], xmm1
000071709abdadf5  lea rdi, [rsp]
000071709abdadf9  mov esi, 0x00
000071709abdadfe  mov rax, 0x60B9B2ABC530
000071709abdae08  call rax
000071709abdae0a  movaps xmm14, [rsp]
000071709abdae0f  add rsp, 0x30
000071709abdae13  vmovaps xmm0, [rsp]
000071709abdae18  vmovaps xmm1, [rsp+0x10]
000071709abdae1e  vmovaps xmm2, [rsp+0x20]
000071709abdae24  vmovaps xmm3, [rsp+0x30]
000071709abdae2a  vmovaps xmm4, [rsp+0x40]
000071709abdae30  vmovaps xmm5, [rsp+0x50]
000071709abdae36  vmovaps xmm6, [rsp+0x60]
000071709abdae3c  vmovaps xmm7, [rsp+0x70]
000071709abdae42  vmovaps xmm8, [rsp+0x80]
000071709abdae4b  vmovaps xmm9, [rsp+0x90]
000071709abdae54  vmovaps xmm10, [rsp+0xA0]
000071709abdae5d  vmovaps xmm11, [rsp+0xB0]
000071709abdae66  vmovaps xmm12, [rsp+0xC0]
000071709abdae6f  vmovaps xmm13, [rsp+0xD0]
000071709abdae78  vmovaps xmm15, [rsp+0xE0]
000071709abdae81  add rsp, 0xF0
000071709abdae88  pop r11
000071709abdae8a  pop r10
000071709abdae8c  pop r9
000071709abdae8e  pop r8
000071709abdae90  pop rsi
000071709abdae91  pop rdi
000071709abdae92  pop rdx
000071709abdae93  pop rcx
000071709abdae94  pop rax
000071709abdae95  add rsp, 0x08
000071709abdae99  jmp 0x000071709ABD6578
000071709abdae9e  sub rsp, 0x08
000071709abdaea2  push rax
000071709abdaea3  push rcx
000071709abdaea4  push rdx
000071709abdaea5  push rdi
000071709abdaea6  push rsi
000071709abdaea7  push r8
000071709abdaea9  push r9
000071709abdaeab  push r10
000071709abdaead  push r11
000071709abdaeaf  sub rsp, 0xF0
000071709abdaeb6  vmovaps [rsp], xmm0
000071709abdaebb  vmovaps [rsp+0x10], xmm2
000071709abdaec1  vmovaps [rsp+0x20], xmm3
000071709abdaec7  vmovaps [rsp+0x30], xmm4
000071709abdaecd  vmovaps [rsp+0x40], xmm5
000071709abdaed3  vmovaps [rsp+0x50], xmm6
000071709abdaed9  vmovaps [rsp+0x60], xmm7
000071709abdaedf  vmovaps [rsp+0x70], xmm8
000071709abdaee5  vmovaps [rsp+0x80], xmm9
000071709abdaeee  vmovaps [rsp+0x90], xmm10
000071709abdaef7  vmovaps [rsp+0xA0], xmm11
000071709abdaf00  vmovaps [rsp+0xB0], xmm12
000071709abdaf09  vmovaps [rsp+0xC0], xmm13
000071709abdaf12  vmovaps [rsp+0xD0], xmm14
000071709abdaf1b  vmovaps [rsp+0xE0], xmm15
000071709abdaf24  sub rsp, 0x30
000071709abdaf28  movaps [rsp], xmm1
000071709abdaf2c  movaps [rsp+0x10], xmm13
000071709abdaf32  movaps [rsp+0x20], xmm8
000071709abdaf38  lea rdi, [rsp]
000071709abdaf3c  mov esi, 0x00
000071709abdaf41  mov rax, 0x60B9B2ABC530
000071709abdaf4b  call rax
000071709abdaf4d  movaps xmm1, [rsp]
000071709abdaf51  add rsp, 0x30
000071709abdaf55  vmovaps xmm0, [rsp]
000071709abdaf5a  vmovaps xmm2, [rsp+0x10]
000071709abdaf60  vmovaps xmm3, [rsp+0x20]
000071709abdaf66  vmovaps xmm4, [rsp+0x30]
000071709abdaf6c  vmovaps xmm5, [rsp+0x40]
000071709abdaf72  vmovaps xmm6, [rsp+0x50]
000071709abdaf78  vmovaps xmm7, [rsp+0x60]
000071709abdaf7e  vmovaps xmm8, [rsp+0x70]
000071709abdaf84  vmovaps xmm9, [rsp+0x80]
000071709abdaf8d  vmovaps xmm10, [rsp+0x90]
000071709abdaf96  vmovaps xmm11, [rsp+0xA0]
000071709abdaf9f  vmovaps xmm12, [rsp+0xB0]
000071709abdafa8  vmovaps xmm13, [rsp+0xC0]
000071709abdafb1  vmovaps xmm14, [rsp+0xD0]
000071709abdafba  vmovaps xmm15, [rsp+0xE0]
000071709abdafc3  add rsp, 0xF0
000071709abdafca  pop r11
000071709abdafcc  pop r10
000071709abdafce  pop r9
000071709abdafd0  pop r8
000071709abdafd2  pop rsi
000071709abdafd3  pop rdi
000071709abdafd4  pop rdx
000071709abdafd5  pop rcx
000071709abdafd6  pop rax
000071709abdafd7  add rsp, 0x08
000071709abdafdb  jmp 0x000071709ABD659A
000071709abdafe0  call 0x000071709AA0C260
000071709abdafe5  jmp 0x000071709ABD65A8
000071709abdafea  call 0x000071709AADE950
000071709abdafef  jmp 0x000071709ABD65B2
000071709abdaff4  sub rsp, 0x08
000071709abdaff8  push rax
000071709abdaff9  push rcx
000071709abdaffa  push rdx
000071709abdaffb  push rdi
000071709abdaffc  push rsi
000071709abdaffd  push r8
000071709abdafff  push r9
000071709abdb001  push r10
000071709abdb003  push r11
000071709abdb005  sub rsp, 0xF0
000071709abdb00c  vmovaps [rsp], xmm0
000071709abdb011  vmovaps [rsp+0x10], xmm1
000071709abdb017  vmovaps [rsp+0x20], xmm2
000071709abdb01d  vmovaps [rsp+0x30], xmm3
000071709abdb023  vmovaps [rsp+0x40], xmm4
000071709abdb029  vmovaps [rsp+0x50], xmm5
000071709abdb02f  vmovaps [rsp+0x60], xmm6
000071709abdb035  vmovaps [rsp+0x70], xmm7
000071709abdb03b  vmovaps [rsp+0x80], xmm9
000071709abdb044  vmovaps [rsp+0x90], xmm10
000071709abdb04d  vmovaps [rsp+0xA0], xmm11
000071709abdb056  vmovaps [rsp+0xB0], xmm12
000071709abdb05f  vmovaps [rsp+0xC0], xmm13
000071709abdb068  vmovaps [rsp+0xD0], xmm14
000071709abdb071  vmovaps [rsp+0xE0], xmm15
000071709abdb07a  sub rsp, 0x30
000071709abdb07e  movaps [rsp], xmm8
000071709abdb083  movaps [rsp+0x10], xmm15
000071709abdb089  movaps [rsp+0x20], xmm7
000071709abdb08e  lea rdi, [rsp]
000071709abdb092  mov esi, 0x00
000071709abdb097  mov rax, 0x60B9B2ABC530
000071709abdb0a1  call rax
000071709abdb0a3  movaps xmm8, [rsp]
000071709abdb0a8  add rsp, 0x30
000071709abdb0ac  vmovaps xmm0, [rsp]
000071709abdb0b1  vmovaps xmm1, [rsp+0x10]
000071709abdb0b7  vmovaps xmm2, [rsp+0x20]
000071709abdb0bd  vmovaps xmm3, [rsp+0x30]
000071709abdb0c3  vmovaps xmm4, [rsp+0x40]
000071709abdb0c9  vmovaps xmm5, [rsp+0x50]
000071709abdb0cf  vmovaps xmm6, [rsp+0x60]
000071709abdb0d5  vmovaps xmm7, [rsp+0x70]
000071709abdb0db  vmovaps xmm9, [rsp+0x80]
000071709abdb0e4  vmovaps xmm10, [rsp+0x90]
000071709abdb0ed  vmovaps xmm11, [rsp+0xA0]
000071709abdb0f6  vmovaps xmm12, [rsp+0xB0]
000071709abdb0ff  vmovaps xmm13, [rsp+0xC0]
000071709abdb108  vmovaps xmm14, [rsp+0xD0]
000071709abdb111  vmovaps xmm15, [rsp+0xE0]
000071709abdb11a  add rsp, 0xF0
000071709abdb121  pop r11
000071709abdb123  pop r10
000071709abdb125  pop r9
000071709abdb127  pop r8
000071709abdb129  pop rsi
000071709abdb12a  pop rdi
000071709abdb12b  pop rdx
000071709abdb12c  pop rcx
000071709abdb12d  pop rax
000071709abdb12e  add rsp, 0x08
000071709abdb132  jmp 0x000071709ABD65D4
000071709abdb137  sub rsp, 0x08
000071709abdb13b  push rax
000071709abdb13c  push rcx
000071709abdb13d  push rdx
000071709abdb13e  push rdi
000071709abdb13f  push rsi
000071709abdb140  push r8
000071709abdb142  push r9
000071709abdb144  push r10
000071709abdb146  push r11
000071709abdb148  sub rsp, 0xF0
000071709abdb14f  vmovaps [rsp], xmm0
000071709abdb154  vmovaps [rsp+0x10], xmm1
000071709abdb15a  vmovaps [rsp+0x20], xmm2
000071709abdb160  vmovaps [rsp+0x30], xmm3
000071709abdb166  vmovaps [rsp+0x40], xmm4
000071709abdb16c  vmovaps [rsp+0x50], xmm5
000071709abdb172  vmovaps [rsp+0x60], xmm6
000071709abdb178  vmovaps [rsp+0x70], xmm8
000071709abdb17e  vmovaps [rsp+0x80], xmm9
000071709abdb187  vmovaps [rsp+0x90], xmm10
000071709abdb190  vmovaps [rsp+0xA0], xmm11
000071709abdb199  vmovaps [rsp+0xB0], xmm12
000071709abdb1a2  vmovaps [rsp+0xC0], xmm13
000071709abdb1ab  vmovaps [rsp+0xD0], xmm14
000071709abdb1b4  vmovaps [rsp+0xE0], xmm15
000071709abdb1bd  sub rsp, 0x30
000071709abdb1c1  movaps [rsp], xmm7
000071709abdb1c5  movaps [rsp+0x10], xmm9
000071709abdb1cb  movaps [rsp+0x20], xmm15
000071709abdb1d1  lea rdi, [rsp]
000071709abdb1d5  mov esi, 0x00
000071709abdb1da  mov rax, 0x60B9B2ABC530
000071709abdb1e4  call rax
000071709abdb1e6  movaps xmm7, [rsp]
000071709abdb1ea  add rsp, 0x30
000071709abdb1ee  vmovaps xmm0, [rsp]
000071709abdb1f3  vmovaps xmm1, [rsp+0x10]
000071709abdb1f9  vmovaps xmm2, [rsp+0x20]
000071709abdb1ff  vmovaps xmm3, [rsp+0x30]
000071709abdb205  vmovaps xmm4, [rsp+0x40]
000071709abdb20b  vmovaps xmm5, [rsp+0x50]
000071709abdb211  vmovaps xmm6, [rsp+0x60]
000071709abdb217  vmovaps xmm8, [rsp+0x70]
000071709abdb21d  vmovaps xmm9, [rsp+0x80]
000071709abdb226  vmovaps xmm10, [rsp+0x90]
000071709abdb22f  vmovaps xmm11, [rsp+0xA0]
000071709abdb238  vmovaps xmm12, [rsp+0xB0]
000071709abdb241  vmovaps xmm13, [rsp+0xC0]
000071709abdb24a  vmovaps xmm14, [rsp+0xD0]
000071709abdb253  vmovaps xmm15, [rsp+0xE0]
000071709abdb25c  add rsp, 0xF0
000071709abdb263  pop r11
000071709abdb265  pop r10
000071709abdb267  pop r9
000071709abdb269  pop r8
000071709abdb26b  pop rsi
000071709abdb26c  pop rdi
000071709abdb26d  pop rdx
000071709abdb26e  pop rcx
000071709abdb26f  pop rax
000071709abdb270  add rsp, 0x08
000071709abdb274  jmp 0x000071709ABD6601
000071709abdb279  sub rsp, 0x08
000071709abdb27d  push rax
000071709abdb27e  push rcx
000071709abdb27f  push rdx
000071709abdb280  push rdi
000071709abdb281  push rsi
000071709abdb282  push r8
000071709abdb284  push r9
000071709abdb286  push r10
000071709abdb288  push r11
000071709abdb28a  sub rsp, 0xF0
000071709abdb291  vmovaps [rsp], xmm0
000071709abdb296  vmovaps [rsp+0x10], xmm1
000071709abdb29c  vmovaps [rsp+0x20], xmm2
000071709abdb2a2  vmovaps [rsp+0x30], xmm3
000071709abdb2a8  vmovaps [rsp+0x40], xmm4
000071709abdb2ae  vmovaps [rsp+0x50], xmm5
000071709abdb2b4  vmovaps [rsp+0x60], xmm6
000071709abdb2ba  vmovaps [rsp+0x70], xmm7
000071709abdb2c0  vmovaps [rsp+0x80], xmm8
000071709abdb2c9  vmovaps [rsp+0x90], xmm10
000071709abdb2d2  vmovaps [rsp+0xA0], xmm11
000071709abdb2db  vmovaps [rsp+0xB0], xmm12
000071709abdb2e4  vmovaps [rsp+0xC0], xmm13
000071709abdb2ed  vmovaps [rsp+0xD0], xmm14
000071709abdb2f6  vmovaps [rsp+0xE0], xmm15
000071709abdb2ff  sub rsp, 0x30
000071709abdb303  movaps [rsp], xmm9
000071709abdb308  movaps [rsp+0x10], xmm13
000071709abdb30e  movaps [rsp+0x20], xmm15
000071709abdb314  lea rdi, [rsp]
000071709abdb318  mov esi, 0x00
000071709abdb31d  mov rax, 0x60B9B2ABC530
000071709abdb327  call rax
000071709abdb329  movaps xmm9, [rsp]
000071709abdb32e  add rsp, 0x30
000071709abdb332  vmovaps xmm0, [rsp]
000071709abdb337  vmovaps xmm1, [rsp+0x10]
000071709abdb33d  vmovaps xmm2, [rsp+0x20]
000071709abdb343  vmovaps xmm3, [rsp+0x30]
000071709abdb349  vmovaps xmm4, [rsp+0x40]
000071709abdb34f  vmovaps xmm5, [rsp+0x50]
000071709abdb355  vmovaps xmm6, [rsp+0x60]
000071709abdb35b  vmovaps xmm7, [rsp+0x70]
000071709abdb361  vmovaps xmm8, [rsp+0x80]
000071709abdb36a  vmovaps xmm10, [rsp+0x90]
000071709abdb373  vmovaps xmm11, [rsp+0xA0]
000071709abdb37c  vmovaps xmm12, [rsp+0xB0]
000071709abdb385  vmovaps xmm13, [rsp+0xC0]
000071709abdb38e  vmovaps xmm14, [rsp+0xD0]
000071709abdb397  vmovaps xmm15, [rsp+0xE0]
000071709abdb3a0  add rsp, 0xF0
000071709abdb3a7  pop r11
000071709abdb3a9  pop r10
000071709abdb3ab  pop r9
000071709abdb3ad  pop r8
000071709abdb3af  pop rsi
000071709abdb3b0  pop rdi
000071709abdb3b1  pop rdx
000071709abdb3b2  pop rcx
000071709abdb3b3  pop rax
000071709abdb3b4  add rsp, 0x08
000071709abdb3b8  jmp 0x000071709ABD662F
000071709abdb3bd  sub rsp, 0x08
000071709abdb3c1  push rax
000071709abdb3c2  push rcx
000071709abdb3c3  push rdx
000071709abdb3c4  push rdi
000071709abdb3c5  push rsi
000071709abdb3c6  push r8
000071709abdb3c8  push r9
000071709abdb3ca  push r10
000071709abdb3cc  push r11
000071709abdb3ce  sub rsp, 0xF0
000071709abdb3d5  vmovaps [rsp], xmm0
000071709abdb3da  vmovaps [rsp+0x10], xmm1
000071709abdb3e0  vmovaps [rsp+0x20], xmm2
000071709abdb3e6  vmovaps [rsp+0x30], xmm3
000071709abdb3ec  vmovaps [rsp+0x40], xmm4
000071709abdb3f2  vmovaps [rsp+0x50], xmm5
000071709abdb3f8  vmovaps [rsp+0x60], xmm6
000071709abdb3fe  vmovaps [rsp+0x70], xmm7
000071709abdb404  vmovaps [rsp+0x80], xmm8
000071709abdb40d  vmovaps [rsp+0x90], xmm9
000071709abdb416  vmovaps [rsp+0xA0], xmm10
000071709abdb41f  vmovaps [rsp+0xB0], xmm11
000071709abdb428  vmovaps [rsp+0xC0], xmm12
000071709abdb431  vmovaps [rsp+0xD0], xmm13
000071709abdb43a  vmovaps [rsp+0xE0], xmm14
000071709abdb443  sub rsp, 0x30
000071709abdb447  movaps [rsp], xmm15
000071709abdb44c  movaps [rsp+0x10], xmm11
000071709abdb452  movaps [rsp+0x20], xmm12
000071709abdb458  lea rdi, [rsp]
000071709abdb45c  mov esi, 0x00
000071709abdb461  mov rax, 0x60B9B2ABC530
000071709abdb46b  call rax
000071709abdb46d  movaps xmm15, [rsp]
000071709abdb472  add rsp, 0x30
000071709abdb476  vmovaps xmm0, [rsp]
000071709abdb47b  vmovaps xmm1, [rsp+0x10]
000071709abdb481  vmovaps xmm2, [rsp+0x20]
000071709abdb487  vmovaps xmm3, [rsp+0x30]
000071709abdb48d  vmovaps xmm4, [rsp+0x40]
000071709abdb493  vmovaps xmm5, [rsp+0x50]
000071709abdb499  vmovaps xmm6, [rsp+0x60]
000071709abdb49f  vmovaps xmm7, [rsp+0x70]
000071709abdb4a5  vmovaps xmm8, [rsp+0x80]
000071709abdb4ae  vmovaps xmm9, [rsp+0x90]
000071709abdb4b7  vmovaps xmm10, [rsp+0xA0]
000071709abdb4c0  vmovaps xmm11, [rsp+0xB0]
000071709abdb4c9  vmovaps xmm12, [rsp+0xC0]
000071709abdb4d2  vmovaps xmm13, [rsp+0xD0]
000071709abdb4db  vmovaps xmm14, [rsp+0xE0]
000071709abdb4e4  add rsp, 0xF0
000071709abdb4eb  pop r11
000071709abdb4ed  pop r10
000071709abdb4ef  pop r9
000071709abdb4f1  pop r8
000071709abdb4f3  pop rsi
000071709abdb4f4  pop rdi
000071709abdb4f5  pop rdx
000071709abdb4f6  pop rcx
000071709abdb4f7  pop rax
000071709abdb4f8  add rsp, 0x08
000071709abdb4fc  jmp 0x000071709ABD664A
000071709abdb501  sub rsp, 0x08
000071709abdb505  push rax
000071709abdb506  push rcx
000071709abdb507  push rdx
000071709abdb508  push rdi
000071709abdb509  push rsi
000071709abdb50a  push r8
000071709abdb50c  push r9
000071709abdb50e  push r10
000071709abdb510  push r11
000071709abdb512  sub rsp, 0xF0
000071709abdb519  vmovaps [rsp], xmm0
000071709abdb51e  vmovaps [rsp+0x10], xmm1
000071709abdb524  vmovaps [rsp+0x20], xmm2
000071709abdb52a  vmovaps [rsp+0x30], xmm3
000071709abdb530  vmovaps [rsp+0x40], xmm4
000071709abdb536  vmovaps [rsp+0x50], xmm5
000071709abdb53c  vmovaps [rsp+0x60], xmm6
000071709abdb542  vmovaps [rsp+0x70], xmm7
000071709abdb548  vmovaps [rsp+0x80], xmm8
000071709abdb551  vmovaps [rsp+0x90], xmm9
000071709abdb55a  vmovaps [rsp+0xA0], xmm10
000071709abdb563  vmovaps [rsp+0xB0], xmm11
000071709abdb56c  vmovaps [rsp+0xC0], xmm12
000071709abdb575  vmovaps [rsp+0xD0], xmm14
000071709abdb57e  vmovaps [rsp+0xE0], xmm15
000071709abdb587  sub rsp, 0x30
000071709abdb58b  movaps [rsp], xmm13
000071709abdb590  movaps [rsp+0x10], xmm10
000071709abdb596  movaps [rsp+0x20], xmm14
000071709abdb59c  lea rdi, [rsp]
000071709abdb5a0  mov esi, 0x00
000071709abdb5a5  mov rax, 0x60B9B2ABC530
000071709abdb5af  call rax
000071709abdb5b1  movaps xmm13, [rsp]
000071709abdb5b6  add rsp, 0x30
000071709abdb5ba  vmovaps xmm0, [rsp]
000071709abdb5bf  vmovaps xmm1, [rsp+0x10]
000071709abdb5c5  vmovaps xmm2, [rsp+0x20]
000071709abdb5cb  vmovaps xmm3, [rsp+0x30]
000071709abdb5d1  vmovaps xmm4, [rsp+0x40]
000071709abdb5d7  vmovaps xmm5, [rsp+0x50]
000071709abdb5dd  vmovaps xmm6, [rsp+0x60]
000071709abdb5e3  vmovaps xmm7, [rsp+0x70]
000071709abdb5e9  vmovaps xmm8, [rsp+0x80]
000071709abdb5f2  vmovaps xmm9, [rsp+0x90]
000071709abdb5fb  vmovaps xmm10, [rsp+0xA0]
000071709abdb604  vmovaps xmm11, [rsp+0xB0]
000071709abdb60d  vmovaps xmm12, [rsp+0xC0]
000071709abdb616  vmovaps xmm14, [rsp+0xD0]
000071709abdb61f  vmovaps xmm15, [rsp+0xE0]
000071709abdb628  add rsp, 0xF0
000071709abdb62f  pop r11
000071709abdb631  pop r10
000071709abdb633  pop r9
000071709abdb635  pop r8
000071709abdb637  pop rsi
000071709abdb638  pop rdi
000071709abdb639  pop rdx
000071709abdb63a  pop rcx
000071709abdb63b  pop rax
000071709abdb63c  add rsp, 0x08
000071709abdb640  jmp 0x000071709ABD666D
000071709abdb645  sub rsp, 0x08
000071709abdb649  push rax
000071709abdb64a  push rcx
000071709abdb64b  push rdx
000071709abdb64c  push rdi
000071709abdb64d  push rsi
000071709abdb64e  push r8
000071709abdb650  push r9
000071709abdb652  push r10
000071709abdb654  push r11
000071709abdb656  sub rsp, 0xF0
000071709abdb65d  vmovaps [rsp], xmm0
000071709abdb662  vmovaps [rsp+0x10], xmm1
000071709abdb668  vmovaps [rsp+0x20], xmm2
000071709abdb66e  vmovaps [rsp+0x30], xmm3
000071709abdb674  vmovaps [rsp+0x40], xmm4
000071709abdb67a  vmovaps [rsp+0x50], xmm5
000071709abdb680  vmovaps [rsp+0x60], xmm6
000071709abdb686  vmovaps [rsp+0x70], xmm7
000071709abdb68c  vmovaps [rsp+0x80], xmm8
000071709abdb695  vmovaps [rsp+0x90], xmm9
000071709abdb69e  vmovaps [rsp+0xA0], xmm10
000071709abdb6a7  vmovaps [rsp+0xB0], xmm11
000071709abdb6b0  vmovaps [rsp+0xC0], xmm12
000071709abdb6b9  vmovaps [rsp+0xD0], xmm13
000071709abdb6c2  vmovaps [rsp+0xE0], xmm15
000071709abdb6cb  sub rsp, 0x30
000071709abdb6cf  movaps [rsp], xmm14
000071709abdb6d4  movaps [rsp+0x10], xmm1
000071709abdb6d9  movaps [rsp+0x20], xmm7
000071709abdb6de  lea rdi, [rsp]
000071709abdb6e2  mov esi, 0x00
000071709abdb6e7  mov rax, 0x60B9B2ABC530
000071709abdb6f1  call rax
000071709abdb6f3  movaps xmm14, [rsp]
000071709abdb6f8  add rsp, 0x30
000071709abdb6fc  vmovaps xmm0, [rsp]
000071709abdb701  vmovaps xmm1, [rsp+0x10]
000071709abdb707  vmovaps xmm2, [rsp+0x20]
000071709abdb70d  vmovaps xmm3, [rsp+0x30]
000071709abdb713  vmovaps xmm4, [rsp+0x40]
000071709abdb719  vmovaps xmm5, [rsp+0x50]
000071709abdb71f  vmovaps xmm6, [rsp+0x60]
000071709abdb725  vmovaps xmm7, [rsp+0x70]
000071709abdb72b  vmovaps xmm8, [rsp+0x80]
000071709abdb734  vmovaps xmm9, [rsp+0x90]
000071709abdb73d  vmovaps xmm10, [rsp+0xA0]
000071709abdb746  vmovaps xmm11, [rsp+0xB0]
000071709abdb74f  vmovaps xmm12, [rsp+0xC0]
000071709abdb758  vmovaps xmm13, [rsp+0xD0]
000071709abdb761  vmovaps xmm15, [rsp+0xE0]
000071709abdb76a  add rsp, 0xF0
000071709abdb771  pop r11
000071709abdb773  pop r10
000071709abdb775  pop r9
000071709abdb777  pop r8
000071709abdb779  pop rsi
000071709abdb77a  pop rdi
000071709abdb77b  pop rdx
000071709abdb77c  pop rcx
000071709abdb77d  pop rax
000071709abdb77e  add rsp, 0x08
000071709abdb782  jmp 0x000071709ABD6690
000071709abdb787  sub rsp, 0x08
000071709abdb78b  push rax
000071709abdb78c  push rcx
000071709abdb78d  push rdx
000071709abdb78e  push rdi
000071709abdb78f  push rsi
000071709abdb790  push r8
000071709abdb792  push r9
000071709abdb794  push r10
000071709abdb796  push r11
000071709abdb798  sub rsp, 0xF0
000071709abdb79f  vmovaps [rsp], xmm0
000071709abdb7a4  vmovaps [rsp+0x10], xmm2
000071709abdb7aa  vmovaps [rsp+0x20], xmm3
000071709abdb7b0  vmovaps [rsp+0x30], xmm4
000071709abdb7b6  vmovaps [rsp+0x40], xmm5
000071709abdb7bc  vmovaps [rsp+0x50], xmm6
000071709abdb7c2  vmovaps [rsp+0x60], xmm7
000071709abdb7c8  vmovaps [rsp+0x70], xmm8
000071709abdb7ce  vmovaps [rsp+0x80], xmm9
000071709abdb7d7  vmovaps [rsp+0x90], xmm10
000071709abdb7e0  vmovaps [rsp+0xA0], xmm11
000071709abdb7e9  vmovaps [rsp+0xB0], xmm12
000071709abdb7f2  vmovaps [rsp+0xC0], xmm13
000071709abdb7fb  vmovaps [rsp+0xD0], xmm14
000071709abdb804  vmovaps [rsp+0xE0], xmm15
000071709abdb80d  sub rsp, 0x30
000071709abdb811  movaps [rsp], xmm1
000071709abdb815  movaps [rsp+0x10], xmm8
000071709abdb81b  movaps [rsp+0x20], xmm9
000071709abdb821  lea rdi, [rsp]
000071709abdb825  mov esi, 0x00
000071709abdb82a  mov rax, 0x60B9B2ABC530
000071709abdb834  call rax
000071709abdb836  movaps xmm1, [rsp]
000071709abdb83a  add rsp, 0x30
000071709abdb83e  vmovaps xmm0, [rsp]
000071709abdb843  vmovaps xmm2, [rsp+0x10]
000071709abdb849  vmovaps xmm3, [rsp+0x20]
000071709abdb84f  vmovaps xmm4, [rsp+0x30]
000071709abdb855  vmovaps xmm5, [rsp+0x40]
000071709abdb85b  vmovaps xmm6, [rsp+0x50]
000071709abdb861  vmovaps xmm7, [rsp+0x60]
000071709abdb867  vmovaps xmm8, [rsp+0x70]
000071709abdb86d  vmovaps xmm9, [rsp+0x80]
000071709abdb876  vmovaps xmm10, [rsp+0x90]
000071709abdb87f  vmovaps xmm11, [rsp+0xA0]
000071709abdb888  vmovaps xmm12, [rsp+0xB0]
000071709abdb891  vmovaps xmm13, [rsp+0xC0]
000071709abdb89a  vmovaps xmm14, [rsp+0xD0]
000071709abdb8a3  vmovaps xmm15, [rsp+0xE0]
000071709abdb8ac  add rsp, 0xF0
000071709abdb8b3  pop r11
000071709abdb8b5  pop r10
000071709abdb8b7  pop r9
000071709abdb8b9  pop r8
000071709abdb8bb  pop rsi
000071709abdb8bc  pop rdi
000071709abdb8bd  pop rdx
000071709abdb8be  pop rcx
000071709abdb8bf  pop rax
000071709abdb8c0  add rsp, 0x08
000071709abdb8c4  jmp 0x000071709ABD66B2
000071709abdb8c9  call 0x000071709AAB3E40
000071709abdb8ce  jmp 0x000071709ABD66C0
000071709abdb8d3  call 0x000071709AA0C380
000071709abdb8d8  jmp 0x000071709ABD66CA
000071709abdb8dd  call 0x000071709AA0D600
000071709abdb8e2  jmp 0x000071709ABD66D4
000071709abdb8e7  call 0x000071709A9FF540
000071709abdb8ec  jmp 0x000071709ABD66DE
000071709abdb8f1  int3
000071709abdb8f2  nop [rax+rax*1], ax
000071709abdb8fb  nop [rax+rax*1], eax
000071709abdb900  mov eax, [r15+0x48]
000071709abdb904  lea r14d, [eax+0x01]
000071709abdb909  mov [rsp+0x10], r14d
000071709abdb90e  mov r14d, r14d
000071709abdb911  mov [r15+0x48], r14
000071709abdb915  xor eax, eax
000071709abdb917  mov r14d, [rsp+0x10]
000071709abdb91c  cmp r14d, 0x1F4
000071709abdb923  cmc
000071709abdb924  lahf
000071709abdb925  seto al
000071709abdb928  mov [r15+0x108], eax
000071709abdb92f  mov eax, [r15+0x108]
000071709abdb936  sahf
000071709abdb937  jnz 0x000071709ABDB969
000071709abdb939  cmp dword ptr [r15+0x318], 0x00
000071709abdb941  jz 0x000071709ABE1AB0
000071709abdb947  nop [rax+rax*1], ax
000071709abdb950  nop [rax+rax*1], eax
000071709abdb958  mov eax, 0x410450
000071709abdb95d  mov [r15+0x100], rax
000071709abdb964  jmp 0x000071709A9FE110
000071709abdb969  cmp dword ptr [r15+0x318], 0x00
000071709abdb971  jz 0x000071709ABDB9A0
000071709abdb977  nop [rax+rax*1], ax
000071709abdb980  nop [rax+rax*1], eax
000071709abdb988  mov eax, 0x410274
000071709abdb98d  mov [r15+0x100], rax
000071709abdb994  jmp 0x000071709A9FE110
000071709abdb999  int3
000071709abdb99a  int3
000071709abdb99b  nop [rax+rax*1], eax
000071709abdb9a0  mov rax, [r15+0x40]
000071709abdb9a4  movaps xmm1, [r15+0x1D0]
000071709abdb9ac  vmovaps [rsp+0x10], xmm1
000071709abdb9b2  vmovaps xmm15, [rsp+0x10]
000071709abdb9b8  por xmm1, xmm15
000071709abdb9bd  movaps xmm14, [r15+0x1A0]
000071709abdb9c5  vmovaps [rsp+0x10], xmm14
000071709abdb9cb  vmovaps xmm13, [rsp+0x10]
000071709abdb9d1  por xmm14, xmm13
000071709abdb9d6  lea r14, [rax+0x30]
000071709abdb9da  mov r12, [r13+r14*1]
000071709abdb9df  lea r14, [rax+0x38]
000071709abdb9e3  mov r11, [r13+r14*1]
000071709abdb9e8  movq xmm13, r12
000071709abdb9ed  movq xmm12, r11
000071709abdb9f2  movq xmm13, xmm13
000071709abdb9f7  vmovaps [rsp+0x10], xmm13
000071709abdb9fd  movq xmm13, xmm13
000071709abdba02  movaps [r15+0x130], xmm13
000071709abdba0a  movq xmm12, xmm12
000071709abdba0f  vmovaps [rsp+0x20], xmm12
000071709abdba15  movq xmm12, xmm12
000071709abdba1a  movaps [r15+0x280], xmm12
000071709abdba22  movaps xmm13, [r15+0x270]
000071709abdba2a  vmovaps [rsp+0x30], xmm13
000071709abdba30  vmovaps xmm12, [rsp+0x30]
000071709abdba36  por xmm13, xmm12
000071709abdba3b  lea r14, [rax+0x20]
000071709abdba3f  mov r12, [r13+r14*1]
000071709abdba44  lea r14, [rax+0x28]
000071709abdba48  mov r11, [r13+r14*1]
000071709abdba4d  movq xmm12, r12
000071709abdba52  movq xmm11, r11
000071709abdba57  movq xmm12, xmm12
000071709abdba5c  vmovaps [rsp+0x30], xmm12
000071709abdba62  movq xmm12, xmm12
000071709abdba67  movaps [r15+0x150], xmm12
000071709abdba6f  movq xmm11, xmm11
000071709abdba74  vmovaps [rsp+0x40], xmm11
000071709abdba7a  movq xmm11, xmm11
000071709abdba7f  movaps [r15+0x140], xmm11
000071709abdba87  lea r14, [rax+0x10]
000071709abdba8b  mov r12, [r13+r14*1]
000071709abdba90  lea r14, [rax+0x18]
000071709abdba94  mov r11, [r13+r14*1]
000071709abdba99  movq xmm12, r12
000071709abdba9e  movq xmm11, r11
000071709abdbaa3  movq xmm12, xmm12
000071709abdbaa8  vmovaps [rsp+0x50], xmm12
000071709abdbaae  movq xmm12, xmm12
000071709abdbab3  movaps [r15+0x170], xmm12
000071709abdbabb  movq xmm11, xmm11
000071709abdbac0  vmovaps [rsp+0x60], xmm11
000071709abdbac6  movq xmm11, xmm11
000071709abdbacb  movaps [r15+0x160], xmm11
000071709abdbad3  mov r14, [r13+rax*1]
000071709abdbad8  vmovq xmm12, r14
000071709abdbadd  vpbroadcastq xmm12, xmm12
000071709abdbae2  lea r14, [rax+0x08]
000071709abdbae6  mov rax, [r13+r14*1]
000071709abdbaeb  movq xmm11, rax
000071709abdbaf0  movaps [r15+0x230], xmm11
000071709abdbaf8  mov rax, [r15+0xF8]
000071709abdbaff  lea r14, [rax+0x50]
000071709abdbb03  movups xmm11, [r13+r14*1]
000071709abdbb09  lea r14, [rax+0x60]
000071709abdbb0d  movups xmm10, [r13+r14*1]
000071709abdbb13  lea r14, [rax+0x30]
000071709abdbb17  movups xmm9, [r13+r14*1]
000071709abdbb1d  mov r14, [r15+0x50]
000071709abdbb21  mov [r15+0x60], r14
000071709abdbb25  mov qword ptr [r15+0x58], 0x40
000071709abdbb2d  movaps xmm8, xmm12
000071709abdbb31  mulpd xmm8, xmm15
000071709abdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000071709abdbb3c  ptest xmm7, xmm7
000071709abdbb41  jnz 0x000071709ABDC96A
000071709abdbb47  movq xmm15, qword ptr [r15+0x230]
000071709abdbb50  vmovaps [rsp+0x70], xmm15
000071709abdbb56  vpermilpd xmm15, xmm15, 0x00
000071709abdbb5c  movaps xmm7, xmm9
000071709abdbb60  mulpd xmm7, xmm15
000071709abdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000071709abdbb6a  ptest xmm6, xmm6
000071709abdbb6f  jnz 0x000071709ABDCAAE
000071709abdbb75  vxorps xmm15, xmm15, xmm15
000071709abdbb7a  vpbroadcastq xmm15, xmm15
000071709abdbb7f  movaps xmm9, xmm12
000071709abdbb83  mulpd xmm9, xmm10
000071709abdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000071709abdbb8e  ptest xmm6, xmm6
000071709abdbb93  jnz 0x000071709ABDCBF0
000071709abdbb99  movaps xmm10, xmm12
000071709abdbb9d  mulpd xmm10, xmm11
000071709abdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000071709abdbba8  ptest xmm6, xmm6
000071709abdbbad  jnz 0x000071709ABDCD34
000071709abdbbb3  movaps xmm11, [r15+0x1F0]
000071709abdbbbb  movaps xmm6, xmm12
000071709abdbbbf  mulpd xmm6, xmm11
000071709abdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000071709abdbbc9  ptest xmm5, xmm5
000071709abdbbce  jnz 0x000071709ABDCE78
000071709abdbbd4  movaps xmm12, [r15+0x2A0]
000071709abdbbdc  vmovaps [rsp+0x80], xmm12
000071709abdbbe5  vmovaps xmm11, [rsp+0x80]
000071709abdbbee  por xmm12, xmm11
000071709abdbbf3  movaps xmm11, [r15+0x250]
000071709abdbbfb  vmovaps [rsp+0x80], xmm11
000071709abdbc04  vmovaps xmm5, [rsp+0x80]
000071709abdbc0d  por xmm11, xmm5
000071709abdbc12  vmovaps xmm4, [rsp+0x70]
000071709abdbc18  vpermilpd xmm4, xmm4, 0x00
000071709abdbc1e  movaps xmm3, xmm5
000071709abdbc21  mulpd xmm3, xmm4
000071709abdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000071709abdbc2a  ptest xmm2, xmm2
000071709abdbc2f  jnz 0x000071709ABDCFBA
000071709abdbc35  mov [rsp+0x80], rax
000071709abdbc3d  xor eax, eax
000071709abdbc3f  mov r12d, 0x40
000071709abdbc45  mov r11d, 0x200
000071709abdbc4b  cmp r12, r11
000071709abdbc4e  cmc
000071709abdbc4f  lahf
000071709abdbc50  seto al
000071709abdbc53  mov [r15+0x108], eax
000071709abdbc5a  movaps xmm5, xmm8
000071709abdbc5e  addpd xmm5, xmm15
000071709abdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000071709abdbc68  ptest xmm4, xmm4
000071709abdbc6d  jnz 0x000071709ABDD0FA
000071709abdbc73  movaps xmm8, [r15+0x1B0]
000071709abdbc7b  movaps xmm4, xmm9
000071709abdbc7f  addpd xmm4, xmm8
000071709abdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000071709abdbc89  ptest xmm2, xmm2
000071709abdbc8e  jnz 0x000071709ABDD23C
000071709abdbc94  movaps xmm9, xmm10
000071709abdbc98  addpd xmm9, xmm8
000071709abdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000071709abdbca3  ptest xmm2, xmm2
000071709abdbca8  jnz 0x000071709ABDD37E
000071709abdbcae  movaps xmm10, [r15+0x2F0]
000071709abdbcb6  vmovaps [rsp+0x90], xmm10
000071709abdbcbf  vmovaps xmm8, [rsp+0x90]
000071709abdbcc8  por xmm10, xmm8
000071709abdbccd  movaps xmm8, [r15+0x2E0]
000071709abdbcd5  vmovaps [rsp+0x90], xmm8
000071709abdbcde  vmovaps xmm2, [rsp+0x90]
000071709abdbce7  por xmm8, xmm2
000071709abdbcec  movaps xmm2, [r15+0x2D0]
000071709abdbcf4  vmovaps [rsp+0x90], xmm2
000071709abdbcfd  vmovaps [rsp+0xA0], xmm1
000071709abdbd06  vmovaps xmm1, [rsp+0x90]
000071709abdbd0f  por xmm2, xmm1
000071709abdbd13  movaps xmm1, [r15+0x200]
000071709abdbd1b  vmovaps [rsp+0x90], xmm1
000071709abdbd24  vmovaps [rsp+0xB0], xmm15
000071709abdbd2d  vmovaps xmm15, [rsp+0x90]
000071709abdbd36  por xmm1, xmm15
000071709abdbd3b  movaps xmm15, [r15+0x1C0]
000071709abdbd43  vmovaps [rsp+0x90], xmm15
000071709abdbd4c  vmovaps [rsp+0xC0], xmm1
000071709abdbd55  vmovaps xmm1, [rsp+0x90]
000071709abdbd5e  por xmm15, xmm1
000071709abdbd63  movaps xmm1, [r15+0x190]
000071709abdbd6b  vmovaps [rsp+0x90], xmm1
000071709abdbd74  vmovaps [rsp+0xD0], xmm15
000071709abdbd7d  vmovaps xmm15, [rsp+0x90]
000071709abdbd86  por xmm1, xmm15
000071709abdbd8b  movaps xmm15, [r15+0x300]
000071709abdbd93  vmovaps [rsp+0x90], xmm15
000071709abdbd9c  vmovaps [rsp+0xE0], xmm1
000071709abdbda5  vmovaps xmm1, [rsp+0x90]
000071709abdbdae  por xmm15, xmm1
000071709abdbdb3  mov rax, [rsp+0x80]
000071709abdbdbb  lea r12, [rax+0xA0]
000071709abdbdc2  movups xmm1, [r13+r12*1]
000071709abdbdc8  lea r12, [rax+0xB0]
000071709abdbdcf  vmovaps [rsp+0x80], xmm1
000071709abdbdd8  movups xmm1, [r13+r12*1]
000071709abdbdde  vmovaps [rsp+0x90], xmm1
000071709abdbde7  vmovaps [rsp+0xF0], xmm15
000071709abdbdf0  vmovaps xmm15, [rsp+0xB0]
000071709abdbdf9  vmovaps [rsp+0xB0], xmm14
000071709abdbe02  movaps xmm1, xmm6
000071709abdbe05  addpd xmm1, xmm15
000071709abdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000071709abdbe0f  ptest xmm14, xmm14
000071709abdbe15  jnz 0x000071709ABDD4D6
000071709abdbe1b  lea r12, [rax+0xF0]
000071709abdbe22  movups xmm15, [r13+r12*1]
000071709abdbe28  movaps xmm14, xmm4
000071709abdbe2c  addpd xmm14, xmm3
000071709abdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000071709abdbe37  ptest xmm6, xmm6
000071709abdbe3c  jnz 0x000071709ABDD621
000071709abdbe42  movaps xmm6, xmm9
000071709abdbe46  addpd xmm6, xmm7
000071709abdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000071709abdbe4f  ptest xmm4, xmm4
000071709abdbe54  jnz 0x000071709ABDD763
000071709abdbe5a  vmovaps xmm9, [rsp+0x70]
000071709abdbe60  vpermilpd xmm9, xmm9, 0x00
000071709abdbe66  vmovaps xmm4, [rsp+0x90]
000071709abdbe6f  movaps xmm7, xmm4
000071709abdbe72  mulpd xmm7, xmm9
000071709abdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000071709abdbe7c  ptest xmm3, xmm3
000071709abdbe81  jnz 0x000071709ABDD8A4
000071709abdbe87  vmovaps xmm9, [rsp+0x50]
000071709abdbe8d  vpermilpd xmm9, xmm9, 0x00
000071709abdbe93  movaps xmm4, xmm15
000071709abdbe97  mulpd xmm4, xmm9
000071709abdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000071709abdbea1  ptest xmm3, xmm3
000071709abdbea6  jnz 0x000071709ABDD9E5
000071709abdbeac  lea r12, [rax+0xE0]
000071709abdbeb3  movups xmm15, [r13+r12*1]
000071709abdbeb9  vmovaps xmm9, [rsp+0x70]
000071709abdbebf  vpermilpd xmm9, xmm9, 0x00
000071709abdbec5  vmovaps [rsp+0x70], xmm1
000071709abdbecb  vmovaps xmm1, [rsp+0x80]
000071709abdbed4  vmovaps [rsp+0x80], xmm15
000071709abdbedd  movaps xmm3, xmm1
000071709abdbee0  mulpd xmm3, xmm9
000071709abdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000071709abdbeea  ptest xmm15, xmm15
000071709abdbef0  jnz 0x000071709ABDDB31
000071709abdbef6  vmovaps xmm1, [rsp+0xF0]
000071709abdbeff  vmovaps xmm15, [rsp+0xF0]
000071709abdbf08  por xmm1, xmm15
000071709abdbf0d  movaps [r15+0x300], xmm1
000071709abdbf15  vmovaps xmm15, [rsp+0xE0]
000071709abdbf1e  vmovaps xmm9, [rsp+0xE0]
000071709abdbf27  por xmm15, xmm9
000071709abdbf2c  movaps [r15+0x190], xmm15
000071709abdbf34  vmovaps xmm9, [rsp+0x50]
000071709abdbf3a  vpermilpd xmm9, xmm9, 0x00
000071709abdbf40  vmovaps [rsp+0x90], xmm1
000071709abdbf49  vmovaps [rsp+0xE0], xmm15
000071709abdbf52  vmovaps xmm15, [rsp+0x80]
000071709abdbf5b  vmovaps [rsp+0x80], xmm14
000071709abdbf64  movaps xmm1, xmm15
000071709abdbf68  mulpd xmm1, xmm9
000071709abdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000071709abdbf72  ptest xmm14, xmm14
000071709abdbf78  jnz 0x000071709ABDDC72
000071709abdbf7e  lea r12, [rax+0x90]
000071709abdbf85  movups xmm15, [r13+r12*1]
000071709abdbf8b  vmovaps xmm14, [rsp+0xD0]
000071709abdbf94  vmovaps xmm9, [rsp+0xD0]
000071709abdbf9d  por xmm14, xmm9
000071709abdbfa2  movaps [r15+0x1C0], xmm14
000071709abdbfaa  vmovaps xmm9, [rsp+0xC0]
000071709abdbfb3  vmovaps [rsp+0xD0], xmm1
000071709abdbfbc  vmovaps xmm1, [rsp+0xC0]
000071709abdbfc5  por xmm9, xmm1
000071709abdbfca  movaps [r15+0x200], xmm9
000071709abdbfd2  vmovaps [rsp+0xC0], xmm2
000071709abdbfdb  vmovaps xmm1, [rsp+0xC0]
000071709abdbfe4  por xmm2, xmm1
000071709abdbfe8  movaps [r15+0x2D0], xmm2
000071709abdbff0  vmovaps [rsp+0xC0], xmm8
000071709abdbff9  vmovaps xmm1, [rsp+0xC0]
000071709abdc002  por xmm8, xmm1
000071709abdc007  movaps [r15+0x2E0], xmm8
000071709abdc00f  vmovaps [rsp+0xC0], xmm15
000071709abdc018  movaps xmm1, xmm5
000071709abdc01b  addpd xmm1, xmm7
000071709abdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000071709abdc024  ptest xmm15, xmm15
000071709abdc02a  jnz 0x000071709ABDDDBE
000071709abdc030  vmovaps xmm15, [rsp+0x50]
000071709abdc036  vpermilpd xmm15, xmm15, 0x00
000071709abdc03c  vmovaps xmm5, [rsp+0xC0]
000071709abdc045  vmovaps [rsp+0xC0], xmm1
000071709abdc04e  movaps xmm7, xmm5
000071709abdc051  mulpd xmm7, xmm15
000071709abdc056  vcmppd xmm1, xmm7, xmm7, 0x03
000071709abdc05b  ptest xmm1, xmm1
000071709abdc060  jnz 0x000071709ABDDEFE
000071709abdc066  lea r12, [rax+0x80]
000071709abdc06d  movups xmm1, [r13+r12*1]
000071709abdc073  vmovaps xmm5, [rsp+0x70]
000071709abdc079  vmovaps [rsp+0x70], xmm1
000071709abdc07f  movaps xmm15, xmm5
000071709abdc083  addpd xmm15, xmm3
000071709abdc088  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abdc08e  ptest xmm1, xmm1
000071709abdc093  jnz 0x000071709ABDE049
000071709abdc099  vmovaps xmm5, [rsp+0x80]
000071709abdc0a2  movaps xmm1, xmm5
000071709abdc0a5  addpd xmm1, xmm4
000071709abdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000071709abdc0ae  ptest xmm3, xmm3
000071709abdc0b3  jnz 0x000071709ABDE18B
000071709abdc0b9  vmovaps [rsp+0x80], xmm10
000071709abdc0c2  vmovaps xmm5, [rsp+0x80]
000071709abdc0cb  por xmm10, xmm5
000071709abdc0d0  movaps [r15+0x2F0], xmm10
000071709abdc0d8  vmovaps xmm5, [rsp+0x50]
000071709abdc0de  vpermilpd xmm5, xmm5, 0x00
000071709abdc0e4  vmovaps xmm3, [rsp+0x70]
000071709abdc0ea  vmovaps [rsp+0x50], xmm1
000071709abdc0f0  movaps xmm4, xmm3
000071709abdc0f3  mulpd xmm4, xmm5
000071709abdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000071709abdc0fc  ptest xmm1, xmm1
000071709abdc101  jnz 0x000071709ABDE2CB
000071709abdc107  lea r12, [rax+0xD0]
000071709abdc10e  movups xmm1, [r13+r12*1]
000071709abdc114  vmovaps xmm3, [rsp+0xD0]
000071709abdc11d  vmovaps [rsp+0x70], xmm1
000071709abdc123  movaps xmm5, xmm6
000071709abdc126  addpd xmm5, xmm3
000071709abdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000071709abdc12f  ptest xmm1, xmm1
000071709abdc134  jnz 0x000071709ABDE415
000071709abdc13a  vmovaps xmm1, [rsp+0x60]
000071709abdc140  vpermilpd xmm1, xmm1, 0x00
000071709abdc146  movaps xmm6, xmm9
000071709abdc14a  mulpd xmm6, xmm1
000071709abdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000071709abdc153  ptest xmm3, xmm3
000071709abdc158  jnz 0x000071709ABDE555
000071709abdc15e  movaps [r15+0x260], xmm6
000071709abdc166  vxorps xmm1, xmm1, xmm1
000071709abdc16a  vpbroadcastq xmm1, xmm1
000071709abdc16f  movaps [r15+0x1B0], xmm1
000071709abdc177  vmovaps xmm1, [rsp+0x60]
000071709abdc17d  vpermilpd xmm1, xmm1, 0x00
000071709abdc183  vmovaps xmm3, [rsp+0x70]
000071709abdc189  vmovaps [rsp+0x70], xmm15
000071709abdc18f  movaps xmm9, xmm3
000071709abdc193  mulpd xmm9, xmm1
000071709abdc198  vcmppd xmm15, xmm9, xmm9, 0x03
000071709abdc19e  ptest xmm15, xmm15
000071709abdc1a4  jnz 0x000071709ABDE696
000071709abdc1aa  lea r12, [rax+0xC0]
000071709abdc1b1  movups xmm1, [r13+r12*1]
000071709abdc1b7  vmovaps xmm3, [rsp+0xC0]
000071709abdc1c0  vmovaps [rsp+0x80], xmm1
000071709abdc1c9  movaps xmm15, xmm3
000071709abdc1cd  addpd xmm15, xmm7
000071709abdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abdc1d8  ptest xmm1, xmm1
000071709abdc1dd  jnz 0x000071709ABDE7E2
000071709abdc1e3  vmovaps [rsp+0xC0], xmm13
000071709abdc1ec  vmovaps xmm1, [rsp+0xC0]
000071709abdc1f5  por xmm13, xmm1
000071709abdc1fa  movaps [r15+0x270], xmm13
000071709abdc202  vmovaps xmm1, [rsp+0xB0]
000071709abdc20b  vmovaps xmm7, [rsp+0xB0]
000071709abdc214  por xmm1, xmm7
000071709abdc218  movaps [r15+0x1A0], xmm1
000071709abdc220  vmovaps xmm1, [rsp+0x60]
000071709abdc226  vpermilpd xmm1, xmm1, 0x00
000071709abdc22c  vmovaps [rsp+0xB0], xmm1
000071709abdc235  vmovaps xmm1, [rsp+0x80]
000071709abdc23e  vmovaps [rsp+0x80], xmm15
000071709abdc247  vmovaps xmm15, [rsp+0xB0]
000071709abdc250  vmovaps [rsp+0xB0], xmm14
000071709abdc259  movaps xmm3, xmm1
000071709abdc25c  mulpd xmm3, xmm15
000071709abdc261  vcmppd xmm14, xmm3, xmm3, 0x03
000071709abdc266  ptest xmm14, xmm14
000071709abdc26c  jnz 0x000071709ABDE924
000071709abdc272  lea r12, [rax+0x20]
000071709abdc276  movups xmm1, [r13+r12*1]
000071709abdc27c  movaps [r15+0x110], xmm1
000071709abdc284  vmovaps xmm14, [rsp+0x70]
000071709abdc28a  vmovaps [rsp+0x70], xmm1
000071709abdc290  movaps xmm15, xmm14
000071709abdc294  addpd xmm15, xmm4
000071709abdc299  vcmppd xmm1, xmm15, xmm15, 0x03
000071709abdc29f  ptest xmm1, xmm1
000071709abdc2a4  jnz 0x000071709ABDEA6F
000071709abdc2aa  vmovaps xmm1, [rsp+0x60]
000071709abdc2b0  vpermilpd xmm1, xmm1, 0x00
000071709abdc2b6  movaps xmm14, xmm2
000071709abdc2ba  mulpd xmm14, xmm1
000071709abdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000071709abdc2c5  ptest xmm4, xmm4
000071709abdc2ca  jnz 0x000071709ABDEBB2
000071709abdc2d0  vmovaps xmm4, [rsp+0x50]
000071709abdc2d6  movaps xmm1, xmm4
000071709abdc2d9  addpd xmm1, xmm9
000071709abdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000071709abdc2e3  ptest xmm2, xmm2
000071709abdc2e8  jnz 0x000071709ABDECF4
000071709abdc2ee  vmovaps xmm9, [rsp+0x30]
000071709abdc2f4  vpermilpd xmm9, xmm9, 0x00
000071709abdc2fa  vmovaps xmm2, [rsp+0x70]
000071709abdc300  vmovaps [rsp+0x50], xmm1
000071709abdc306  movaps xmm4, xmm2
000071709abdc309  mulpd xmm4, xmm9
000071709abdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000071709abdc313  ptest xmm1, xmm1
000071709abdc318  jnz 0x000071709ABDEE35
000071709abdc31e  vmovaps xmm1, [rsp+0x30]
000071709abdc324  vpermilpd xmm1, xmm1, 0x00
000071709abdc32a  vmovaps xmm2, [rsp+0x90]
000071709abdc333  vmovaps [rsp+0x60], xmm15
000071709abdc339  movaps xmm9, xmm2
000071709abdc33d  mulpd xmm9, xmm1
000071709abdc342  vcmppd xmm15, xmm9, xmm9, 0x03
000071709abdc348  ptest xmm15, xmm15
000071709abdc34e  jnz 0x000071709ABDEF76
000071709abdc354  vmovaps xmm15, [rsp+0x80]
000071709abdc35d  movaps xmm1, xmm15
000071709abdc361  addpd xmm1, xmm6
000071709abdc365  vcmppd xmm2, xmm1, xmm1, 0x03
000071709abdc36a  ptest xmm2, xmm2
000071709abdc36f  jnz 0x000071709ABDF0B8
000071709abdc375  movaps xmm15, xmm5
000071709abdc379  addpd xmm15, xmm3
000071709abdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000071709abdc384  ptest xmm6, xmm6
000071709abdc389  jnz 0x000071709ABDF1F9
000071709abdc38f  vmovaps xmm6, [rsp+0x30]
000071709abdc395  vpermilpd xmm6, xmm6, 0x00
000071709abdc39b  movaps xmm5, xmm8
000071709abdc39f  mulpd xmm5, xmm6
000071709abdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000071709abdc3a8  ptest xmm3, xmm3
000071709abdc3ad  jnz 0x000071709ABDF33B
000071709abdc3b3  vmovaps xmm8, [rsp+0x30]
000071709abdc3b9  vpermilpd xmm8, xmm8, 0x00
000071709abdc3bf  movaps xmm6, xmm10
000071709abdc3c3  mulpd xmm6, xmm8
000071709abdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000071709abdc3cd  ptest xmm3, xmm3
000071709abdc3d2  jnz 0x000071709ABDF47C
000071709abdc3d8  vmovaps xmm8, [rsp+0x60]
000071709abdc3de  movaps xmm10, xmm8
000071709abdc3e2  addpd xmm10, xmm14
000071709abdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000071709abdc3ed  ptest xmm3, xmm3
000071709abdc3f2  jnz 0x000071709ABDF5BE
000071709abdc3f8  vmovaps xmm8, [rsp+0x50]
000071709abdc3fe  movaps xmm14, xmm8
000071709abdc402  addpd xmm14, xmm4
000071709abdc407  vcmppd xmm3, xmm14, xmm14, 0x03
000071709abdc40d  ptest xmm3, xmm3
000071709abdc412  jnz 0x000071709ABDF702
000071709abdc418  vmovaps xmm8, [rsp+0x40]
000071709abdc41e  vpermilpd xmm8, xmm8, 0x00
000071709abdc424  movaps xmm4, xmm13
000071709abdc428  mulpd xmm4, xmm8
000071709abdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000071709abdc432  ptest xmm3, xmm3
000071709abdc437  jnz 0x000071709ABDF845
000071709abdc43d  movaps xmm13, xmm15
000071709abdc441  addpd xmm13, xmm9
000071709abdc446  vcmppd xmm8, xmm13, xmm13, 0x03
000071709abdc44c  ptest xmm8, xmm8
000071709abdc452  jnz 0x000071709ABDF987
000071709abdc458  movaps xmm15, xmm1
000071709abdc45c  addpd xmm15, xmm5
000071709abdc461  vcmppd xmm9, xmm15, xmm15, 0x03
000071709abdc467  ptest xmm9, xmm9
000071709abdc46d  jnz 0x000071709ABDFACB
000071709abdc473  vmovaps [rsp+0x30], xmm11
000071709abdc479  vmovaps xmm1, [rsp+0x30]
000071709abdc47f  por xmm11, xmm1
000071709abdc484  movaps [r15+0x250], xmm11
000071709abdc48c  vmovaps [rsp+0x30], xmm12
000071709abdc492  vmovaps xmm1, [rsp+0x30]
000071709abdc498  por xmm12, xmm1
000071709abdc49d  movaps [r15+0x2A0], xmm12
000071709abdc4a5  vmovaps xmm1, [rsp+0xA0]
000071709abdc4ae  vmovaps xmm11, [rsp+0xA0]
000071709abdc4b7  por xmm1, xmm11
000071709abdc4bc  movaps [r15+0x1D0], xmm1
000071709abdc4c4  lea r12, [rax+0x40]
000071709abdc4c8  movups xmm1, [r13+r12*1]
000071709abdc4ce  movaps [r15+0x2C0], xmm1
000071709abdc4d6  vmovaps xmm11, [rsp+0x40]
000071709abdc4dc  vpermilpd xmm11, xmm11, 0x00
000071709abdc4e2  vmovaps xmm8, [rsp+0xE0]
000071709abdc4eb  movaps xmm9, xmm8
000071709abdc4ef  mulpd xmm9, xmm11
000071709abdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000071709abdc4fa  ptest xmm5, xmm5
000071709abdc4ff  jnz 0x000071709ABDFC17
000071709abdc505  movaps xmm11, xmm10
000071709abdc509  addpd xmm11, xmm6
000071709abdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000071709abdc514  ptest xmm8, xmm8
000071709abdc51a  jnz 0x000071709ABDFD5B
000071709abdc520  movaps xmm10, xmm14
000071709abdc524  addpd xmm10, xmm4
000071709abdc529  vcmppd xmm8, xmm10, xmm10, 0x03
000071709abdc52f  ptest xmm8, xmm8
000071709abdc535  jnz 0x000071709ABDFE9E
000071709abdc53b  vmovaps xmm14, [rsp+0x40]
000071709abdc541  vpermilpd xmm14, xmm14, 0x00
000071709abdc547  movaps xmm8, xmm1
000071709abdc54b  mulpd xmm8, xmm14
000071709abdc550  vcmppd xmm6, xmm8, xmm8, 0x03
000071709abdc556  ptest xmm6, xmm6
000071709abdc55b  jnz 0x000071709ABDFFE1
000071709abdc561  movaps xmm1, [r15+0x2B0]
000071709abdc569  vmovaps xmm14, [rsp+0x40]
000071709abdc56f  vpermilpd xmm14, xmm14, 0x00
000071709abdc575  movaps xmm6, xmm1
000071709abdc578  mulpd xmm6, xmm14
000071709abdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000071709abdc582  ptest xmm5, xmm5
000071709abdc587  jnz 0x000071709ABE0124
000071709abdc58d  vmovaps xmm1, [rsp+0x10]
000071709abdc593  vpermilpd xmm1, xmm1, 0x00
000071709abdc599  movaps xmm14, xmm12
000071709abdc59d  mulpd xmm14, xmm1
000071709abdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000071709abdc5a8  ptest xmm5, xmm5
000071709abdc5ad  jnz 0x000071709ABE0265
000071709abdc5b3  movaps xmm1, xmm13
000071709abdc5b7  addpd xmm1, xmm9
000071709abdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000071709abdc5c1  ptest xmm12, xmm12
000071709abdc5c7  jnz 0x000071709ABE03A8
000071709abdc5cd  vmovaps xmm13, [rsp+0x10]
000071709abdc5d3  vpermilpd xmm13, xmm13, 0x00
000071709abdc5d9  movaps xmm12, xmm7
000071709abdc5dd  mulpd xmm12, xmm13
000071709abdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000071709abdc5e8  ptest xmm9, xmm9
000071709abdc5ee  jnz 0x000071709ABE04EA
000071709abdc5f4  movaps xmm13, xmm15
000071709abdc5f8  addpd xmm13, xmm8
000071709abdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000071709abdc603  ptest xmm9, xmm9
000071709abdc609  jnz 0x000071709ABE062D
000071709abdc60f  movaps xmm15, [r15+0x290]
000071709abdc617  vmovaps xmm9, [rsp+0x10]
000071709abdc61d  vpermilpd xmm9, xmm9, 0x00
000071709abdc623  movaps xmm8, xmm15
000071709abdc627  mulpd xmm8, xmm9
000071709abdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000071709abdc632  ptest xmm7, xmm7
000071709abdc637  jnz 0x000071709ABE0771
000071709abdc63d  movaps xmm15, xmm11
000071709abdc641  addpd xmm15, xmm6
000071709abdc646  vcmppd xmm9, xmm15, xmm15, 0x03
000071709abdc64c  ptest xmm9, xmm9
000071709abdc652  jnz 0x000071709ABE08B5
000071709abdc658  movaps xmm11, [r15+0x1E0]
000071709abdc660  vmovaps xmm9, [rsp+0x10]
000071709abdc666  vpermilpd xmm9, xmm9, 0x00
000071709abdc66c  movaps xmm7, xmm11
000071709abdc670  mulpd xmm7, xmm9
000071709abdc675  vcmppd xmm6, xmm7, xmm7, 0x03
000071709abdc67a  ptest xmm6, xmm6
000071709abdc67f  jnz 0x000071709ABE09F8
000071709abdc685  movaps xmm11, xmm10
000071709abdc689  addpd xmm11, xmm14
000071709abdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000071709abdc694  ptest xmm9, xmm9
000071709abdc69a  jnz 0x000071709ABE0B3A
000071709abdc6a0  lea r12, [rax+0x70]
000071709abdc6a4  movups xmm14, [r13+r12*1]
000071709abdc6aa  movaps [r15+0x240], xmm14
000071709abdc6b2  movaps xmm10, xmm1
000071709abdc6b6  addpd xmm10, xmm12
000071709abdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000071709abdc6c1  ptest xmm9, xmm9
000071709abdc6c7  jnz 0x000071709ABE0C88
000071709abdc6cd  movaps [r15+0x170], xmm10
000071709abdc6d5  vmovaps xmm1, [rsp+0x20]
000071709abdc6db  vpermilpd xmm1, xmm1, 0x00
000071709abdc6e1  movaps xmm12, xmm14
000071709abdc6e5  mulpd xmm12, xmm1
000071709abdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000071709abdc6f0  ptest xmm9, xmm9
000071709abdc6f6  jnz 0x000071709ABE0DCB
000071709abdc6fc  vmovaps xmm1, [rsp+0x20]
000071709abdc702  vpermilpd xmm1, xmm1, 0x00
000071709abdc708  vmovaps xmm9, [rsp+0xB0]
000071709abdc711  movaps xmm14, xmm9
000071709abdc715  mulpd xmm14, xmm1
000071709abdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000071709abdc720  ptest xmm6, xmm6
000071709abdc725  jnz 0x000071709ABE0F0E
000071709abdc72b  movaps [r15+0x180], xmm14
000071709abdc733  movaps xmm1, xmm13
000071709abdc737  addpd xmm1, xmm8
000071709abdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000071709abdc741  ptest xmm9, xmm9
000071709abdc747  jnz 0x000071709ABE1051
000071709abdc74d  movaps [r15+0x210], xmm1
000071709abdc755  movups xmm13, [r13+rax*1]
000071709abdc75b  lea r12, [rax+0x10]
000071709abdc75f  movups xmm9, [r13+r12*1]
000071709abdc765  movaps [r15+0x230], xmm9
000071709abdc76d  movaps xmm8, xmm15
000071709abdc771  addpd xmm8, xmm7
000071709abdc776  vcmppd xmm6, xmm8, xmm8, 0x03
000071709abdc77c  ptest xmm6, xmm6
000071709abdc781  jnz 0x000071709ABE11A7
000071709abdc787  movaps [r15+0x130], xmm8
000071709abdc78f  vmovaps xmm15, [rsp+0x20]
000071709abdc795  vpermilpd xmm15, xmm15, 0x00
000071709abdc79b  movaps xmm7, xmm9
000071709abdc79f  mulpd xmm7, xmm15
000071709abdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000071709abdc7a9  ptest xmm6, xmm6
000071709abdc7ae  jnz 0x000071709ABE12EA
000071709abdc7b4  movaps [r15+0x220], xmm7
000071709abdc7bc  vmovaps xmm15, [rsp+0x20]
000071709abdc7c2  vpermilpd xmm15, xmm15, 0x00
000071709abdc7c8  movaps xmm9, xmm13
000071709abdc7cc  mulpd xmm9, xmm15
000071709abdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000071709abdc7d7  ptest xmm6, xmm6
000071709abdc7dc  jnz 0x000071709ABE142C
000071709abdc7e2  movaps xmm15, xmm11
000071709abdc7e6  addpd xmm15, xmm12
000071709abdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000071709abdc7f1  ptest xmm13, xmm13
000071709abdc7f7  jnz 0x000071709ABE1570
000071709abdc7fd  movaps [r15+0x140], xmm15
000071709abdc805  movaps xmm13, xmm10
000071709abdc809  addpd xmm13, xmm14
000071709abdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000071709abdc814  ptest xmm12, xmm12
000071709abdc81a  jnz 0x000071709ABE16B4
000071709abdc820  movaps [r15+0x150], xmm13
000071709abdc828  movaps xmm14, xmm1
000071709abdc82c  addpd xmm14, xmm7
000071709abdc831  vcmppd xmm12, xmm14, xmm14, 0x03
000071709abdc837  ptest xmm12, xmm12
000071709abdc83d  jnz 0x000071709ABE17F8
000071709abdc843  movaps [r15+0x160], xmm14
000071709abdc84b  movaps xmm1, xmm8
000071709abdc84f  addpd xmm1, xmm9
000071709abdc854  vcmppd xmm12, xmm1, xmm1, 0x03
000071709abdc859  ptest xmm12, xmm12
000071709abdc85f  jnz 0x000071709ABE193A
000071709abdc865  movaps [r15+0x120], xmm1
000071709abdc86d  movups [r13+r14*1], xmm15
000071709abdc873  lea rax, [r14+0x10]
000071709abdc877  movups [r13+rax*1], xmm13
000071709abdc87d  lea rax, [r14+0x20]
000071709abdc881  movups [r13+rax*1], xmm14
000071709abdc887  lea rax, [r14+0x30]
000071709abdc88b  movups [r13+rax*1], xmm1
000071709abdc891  mov eax, [r15+0x108]
000071709abdc898  sahf
000071709abdc899  jnz 0x000071709ABDC8CB
000071709abdc89b  cmp dword ptr [r15+0x318], 0x00
000071709abdc8a3  jz 0x000071709ABDB900
000071709abdc8a9  nop [rax+rax*1], ax
000071709abdc8b2  nop [rax+rax*1], eax
000071709abdc8ba  mov eax, 0x410444
000071709abdc8bf  mov [r15+0x100], rax
000071709abdc8c6  jmp 0x000071709A9FE110
000071709abdc8cb  cmp dword ptr [r15+0x318], 0x00
000071709abdc8d3  jz 0x000071709ABD57E0
000071709abdc8d9  nop [rax+rax*1], ax
000071709abdc8e2  nop [rax+rax*1], eax
000071709abdc8ea  mov eax, 0x410278
000071709abdc8ef  mov [r15+0x100], rax
000071709abdc8f6  jmp 0x000071709A9FE110
000071709abdc8fb  int3
000071709abdc8fc  call 0x000071709AAE27E0
000071709abdc901  jmp 0x000071709ABDB9DF
000071709abdc906  call 0x000071709AAE1570
000071709abdc90b  jmp 0x000071709ABDB9E8
000071709abdc910  call 0x000071709AAE27E0
000071709abdc915  jmp 0x000071709ABDBA44
000071709abdc91a  call 0x000071709AAE1570
000071709abdc91f  jmp 0x000071709ABDBA4D
000071709abdc924  call 0x000071709AAE27E0
000071709abdc929  jmp 0x000071709ABDBA90
000071709abdc92e  call 0x000071709AAE1570
000071709abdc933  jmp 0x000071709ABDBA99
000071709abdc938  call 0x000071709AA0DC20
000071709abdc93d  jmp 0x000071709ABDBAD8
000071709abdc942  call 0x000071709AAD59C0
000071709abdc947  jmp 0x000071709ABDBAEB
000071709abdc94c  call 0x000071709AAE0E30
000071709abdc951  jmp 0x000071709ABDBB09
000071709abdc956  call 0x000071709AADFBC0
000071709abdc95b  jmp 0x000071709ABDBB13
000071709abdc960  call 0x000071709AADE950
000071709abdc965  jmp 0x000071709ABDBB1D
000071709abdc96a  sub rsp, 0x08
000071709abdc96e  push rax
000071709abdc96f  push rcx
000071709abdc970  push rdx
000071709abdc971  push rdi
000071709abdc972  push rsi
000071709abdc973  push r8
000071709abdc975  push r9
000071709abdc977  push r10
000071709abdc979  push r11
000071709abdc97b  sub rsp, 0xF0
000071709abdc982  vmovaps [rsp], xmm0
000071709abdc987  vmovaps [rsp+0x10], xmm1
000071709abdc98d  vmovaps [rsp+0x20], xmm2
000071709abdc993  vmovaps [rsp+0x30], xmm3
000071709abdc999  vmovaps [rsp+0x40], xmm4
000071709abdc99f  vmovaps [rsp+0x50], xmm5
000071709abdc9a5  vmovaps [rsp+0x60], xmm6
000071709abdc9ab  vmovaps [rsp+0x70], xmm7
000071709abdc9b1  vmovaps [rsp+0x80], xmm9
000071709abdc9ba  vmovaps [rsp+0x90], xmm10
000071709abdc9c3  vmovaps [rsp+0xA0], xmm11
000071709abdc9cc  vmovaps [rsp+0xB0], xmm12
000071709abdc9d5  vmovaps [rsp+0xC0], xmm13
000071709abdc9de  vmovaps [rsp+0xD0], xmm14
000071709abdc9e7  vmovaps [rsp+0xE0], xmm15
000071709abdc9f0  sub rsp, 0x30
000071709abdc9f4  movaps [rsp], xmm8
000071709abdc9f9  movaps [rsp+0x10], xmm12
000071709abdc9ff  movaps [rsp+0x20], xmm15
000071709abdca05  lea rdi, [rsp]
000071709abdca09  mov esi, 0x00
000071709abdca0e  mov rax, 0x60B9B2ABC530
000071709abdca18  call rax
000071709abdca1a  movaps xmm8, [rsp]
000071709abdca1f  add rsp, 0x30
000071709abdca23  vmovaps xmm0, [rsp]
000071709abdca28  vmovaps xmm1, [rsp+0x10]
000071709abdca2e  vmovaps xmm2, [rsp+0x20]
000071709abdca34  vmovaps xmm3, [rsp+0x30]
000071709abdca3a  vmovaps xmm4, [rsp+0x40]
000071709abdca40  vmovaps xmm5, [rsp+0x50]
000071709abdca46  vmovaps xmm6, [rsp+0x60]
000071709abdca4c  vmovaps xmm7, [rsp+0x70]
000071709abdca52  vmovaps xmm9, [rsp+0x80]
000071709abdca5b  vmovaps xmm10, [rsp+0x90]
000071709abdca64  vmovaps xmm11, [rsp+0xA0]
000071709abdca6d  vmovaps xmm12, [rsp+0xB0]
000071709abdca76  vmovaps xmm13, [rsp+0xC0]
000071709abdca7f  vmovaps xmm14, [rsp+0xD0]
000071709abdca88  vmovaps xmm15, [rsp+0xE0]
000071709abdca91  add rsp, 0xF0
000071709abdca98  pop r11
000071709abdca9a  pop r10
000071709abdca9c  pop r9
000071709abdca9e  pop r8
000071709abdcaa0  pop rsi
000071709abdcaa1  pop rdi
000071709abdcaa2  pop rdx
000071709abdcaa3  pop rcx
000071709abdcaa4  pop rax
000071709abdcaa5  add rsp, 0x08
000071709abdcaa9  jmp 0x000071709ABDBB47
000071709abdcaae  sub rsp, 0x08
000071709abdcab2  push rax
000071709abdcab3  push rcx
000071709abdcab4  push rdx
000071709abdcab5  push rdi
000071709abdcab6  push rsi
000071709abdcab7  push r8
000071709abdcab9  push r9
000071709abdcabb  push r10
000071709abdcabd  push r11
000071709abdcabf  sub rsp, 0xF0
000071709abdcac6  vmovaps [rsp], xmm0
000071709abdcacb  vmovaps [rsp+0x10], xmm1
000071709abdcad1  vmovaps [rsp+0x20], xmm2
000071709abdcad7  vmovaps [rsp+0x30], xmm3
000071709abdcadd  vmovaps [rsp+0x40], xmm4
000071709abdcae3  vmovaps [rsp+0x50], xmm5
000071709abdcae9  vmovaps [rsp+0x60], xmm6
000071709abdcaef  vmovaps [rsp+0x70], xmm8
000071709abdcaf5  vmovaps [rsp+0x80], xmm9
000071709abdcafe  vmovaps [rsp+0x90], xmm10
000071709abdcb07  vmovaps [rsp+0xA0], xmm11
000071709abdcb10  vmovaps [rsp+0xB0], xmm12
000071709abdcb19  vmovaps [rsp+0xC0], xmm13
000071709abdcb22  vmovaps [rsp+0xD0], xmm14
000071709abdcb2b  vmovaps [rsp+0xE0], xmm15
000071709abdcb34  sub rsp, 0x30
000071709abdcb38  movaps [rsp], xmm7
000071709abdcb3c  movaps [rsp+0x10], xmm9
000071709abdcb42  movaps [rsp+0x20], xmm15
000071709abdcb48  lea rdi, [rsp]
000071709abdcb4c  mov esi, 0x00
000071709abdcb51  mov rax, 0x60B9B2ABC530
000071709abdcb5b  call rax
000071709abdcb5d  movaps xmm7, [rsp]
000071709abdcb61  add rsp, 0x30
000071709abdcb65  vmovaps xmm0, [rsp]
000071709abdcb6a  vmovaps xmm1, [rsp+0x10]
000071709abdcb70  vmovaps xmm2, [rsp+0x20]
000071709abdcb76  vmovaps xmm3, [rsp+0x30]
000071709abdcb7c  vmovaps xmm4, [rsp+0x40]
000071709abdcb82  vmovaps xmm5, [rsp+0x50]
000071709abdcb88  vmovaps xmm6, [rsp+0x60]
000071709abdcb8e  vmovaps xmm8, [rsp+0x70]
000071709abdcb94  vmovaps xmm9, [rsp+0x80]
000071709abdcb9d  vmovaps xmm10, [rsp+0x90]
000071709abdcba6  vmovaps xmm11, [rsp+0xA0]
000071709abdcbaf  vmovaps xmm12, [rsp+0xB0]
000071709abdcbb8  vmovaps xmm13, [rsp+0xC0]
000071709abdcbc1  vmovaps xmm14, [rsp+0xD0]
000071709abdcbca  vmovaps xmm15, [rsp+0xE0]
000071709abdcbd3  add rsp, 0xF0
000071709abdcbda  pop r11
000071709abdcbdc  pop r10
000071709abdcbde  pop r9
000071709abdcbe0  pop r8
000071709abdcbe2  pop rsi
000071709abdcbe3  pop rdi
000071709abdcbe4  pop rdx
000071709abdcbe5  pop rcx
000071709abdcbe6  pop rax
000071709abdcbe7  add rsp, 0x08
000071709abdcbeb  jmp 0x000071709ABDBB75
000071709abdcbf0  sub rsp, 0x08
000071709abdcbf4  push rax
000071709abdcbf5  push rcx
000071709abdcbf6  push rdx
000071709abdcbf7  push rdi
000071709abdcbf8  push rsi
000071709abdcbf9  push r8
000071709abdcbfb  push r9
000071709abdcbfd  push r10
000071709abdcbff  push r11
000071709abdcc01  sub rsp, 0xF0
000071709abdcc08  vmovaps [rsp], xmm0
000071709abdcc0d  vmovaps [rsp+0x10], xmm1
000071709abdcc13  vmovaps [rsp+0x20], xmm2
000071709abdcc19  vmovaps [rsp+0x30], xmm3
000071709abdcc1f  vmovaps [rsp+0x40], xmm4
000071709abdcc25  vmovaps [rsp+0x50], xmm5
000071709abdcc2b  vmovaps [rsp+0x60], xmm6
000071709abdcc31  vmovaps [rsp+0x70], xmm7
000071709abdcc37  vmovaps [rsp+0x80], xmm8
000071709abdcc40  vmovaps [rsp+0x90], xmm10
000071709abdcc49  vmovaps [rsp+0xA0], xmm11
000071709abdcc52  vmovaps [rsp+0xB0], xmm12
000071709abdcc5b  vmovaps [rsp+0xC0], xmm13
000071709abdcc64  vmovaps [rsp+0xD0], xmm14
000071709abdcc6d  vmovaps [rsp+0xE0], xmm15
000071709abdcc76  sub rsp, 0x30
000071709abdcc7a  movaps [rsp], xmm9
000071709abdcc7f  movaps [rsp+0x10], xmm12
000071709abdcc85  movaps [rsp+0x20], xmm10
000071709abdcc8b  lea rdi, [rsp]
000071709abdcc8f  mov esi, 0x00
000071709abdcc94  mov rax, 0x60B9B2ABC530
000071709abdcc9e  call rax
000071709abdcca0  movaps xmm9, [rsp]
000071709abdcca5  add rsp, 0x30
000071709abdcca9  vmovaps xmm0, [rsp]
000071709abdccae  vmovaps xmm1, [rsp+0x10]
000071709abdccb4  vmovaps xmm2, [rsp+0x20]
000071709abdccba  vmovaps xmm3, [rsp+0x30]
000071709abdccc0  vmovaps xmm4, [rsp+0x40]
000071709abdccc6  vmovaps xmm5, [rsp+0x50]
000071709abdcccc  vmovaps xmm6, [rsp+0x60]
000071709abdccd2  vmovaps xmm7, [rsp+0x70]
000071709abdccd8  vmovaps xmm8, [rsp+0x80]
000071709abdcce1  vmovaps xmm10, [rsp+0x90]
000071709abdccea  vmovaps xmm11, [rsp+0xA0]
000071709abdccf3  vmovaps xmm12, [rsp+0xB0]
000071709abdccfc  vmovaps xmm13, [rsp+0xC0]
000071709abdcd05  vmovaps xmm14, [rsp+0xD0]
000071709abdcd0e  vmovaps xmm15, [rsp+0xE0]
000071709abdcd17  add rsp, 0xF0
000071709abdcd1e  pop r11
000071709abdcd20  pop r10
000071709abdcd22  pop r9
000071709abdcd24  pop r8
000071709abdcd26  pop rsi
000071709abdcd27  pop rdi
000071709abdcd28  pop rdx
000071709abdcd29  pop rcx
000071709abdcd2a  pop rax
000071709abdcd2b  add rsp, 0x08
000071709abdcd2f  jmp 0x000071709ABDBB99
000071709abdcd34  sub rsp, 0x08
000071709abdcd38  push rax
000071709abdcd39  push rcx
000071709abdcd3a  push rdx
000071709abdcd3b  push rdi
000071709abdcd3c  push rsi
000071709abdcd3d  push r8
000071709abdcd3f  push r9
000071709abdcd41  push r10
000071709abdcd43  push r11
000071709abdcd45  sub rsp, 0xF0
000071709abdcd4c  vmovaps [rsp], xmm0
000071709abdcd51  vmovaps [rsp+0x10], xmm1
000071709abdcd57  vmovaps [rsp+0x20], xmm2
000071709abdcd5d  vmovaps [rsp+0x30], xmm3
000071709abdcd63  vmovaps [rsp+0x40], xmm4
000071709abdcd69  vmovaps [rsp+0x50], xmm5
000071709abdcd6f  vmovaps [rsp+0x60], xmm6
000071709abdcd75  vmovaps [rsp+0x70], xmm7
000071709abdcd7b  vmovaps [rsp+0x80], xmm8
000071709abdcd84  vmovaps [rsp+0x90], xmm9
000071709abdcd8d  vmovaps [rsp+0xA0], xmm11
000071709abdcd96  vmovaps [rsp+0xB0], xmm12
000071709abdcd9f  vmovaps [rsp+0xC0], xmm13
000071709abdcda8  vmovaps [rsp+0xD0], xmm14
000071709abdcdb1  vmovaps [rsp+0xE0], xmm15
000071709abdcdba  sub rsp, 0x30
000071709abdcdbe  movaps [rsp], xmm10
000071709abdcdc3  movaps [rsp+0x10], xmm12
000071709abdcdc9  movaps [rsp+0x20], xmm11
000071709abdcdcf  lea rdi, [rsp]
000071709abdcdd3  mov esi, 0x00
000071709abdcdd8  mov rax, 0x60B9B2ABC530
000071709abdcde2  call rax
000071709abdcde4  movaps xmm10, [rsp]
000071709abdcde9  add rsp, 0x30
000071709abdcded  vmovaps xmm0, [rsp]
000071709abdcdf2  vmovaps xmm1, [rsp+0x10]
000071709abdcdf8  vmovaps xmm2, [rsp+0x20]
000071709abdcdfe  vmovaps xmm3, [rsp+0x30]
000071709abdce04  vmovaps xmm4, [rsp+0x40]
000071709abdce0a  vmovaps xmm5, [rsp+0x50]
000071709abdce10  vmovaps xmm6, [rsp+0x60]
000071709abdce16  vmovaps xmm7, [rsp+0x70]
000071709abdce1c  vmovaps xmm8, [rsp+0x80]
000071709abdce25  vmovaps xmm9, [rsp+0x90]
000071709abdce2e  vmovaps xmm11, [rsp+0xA0]
000071709abdce37  vmovaps xmm12, [rsp+0xB0]
000071709abdce40  vmovaps xmm13, [rsp+0xC0]
000071709abdce49  vmovaps xmm14, [rsp+0xD0]
000071709abdce52  vmovaps xmm15, [rsp+0xE0]
000071709abdce5b  add rsp, 0xF0
000071709abdce62  pop r11
000071709abdce64  pop r10
000071709abdce66  pop r9
000071709abdce68  pop r8
000071709abdce6a  pop rsi
000071709abdce6b  pop rdi
000071709abdce6c  pop rdx
000071709abdce6d  pop rcx
000071709abdce6e  pop rax
000071709abdce6f  add rsp, 0x08
000071709abdce73  jmp 0x000071709ABDBBB3
000071709abdce78  sub rsp, 0x08
000071709abdce7c  push rax
000071709abdce7d  push rcx
000071709abdce7e  push rdx
000071709abdce7f  push rdi
000071709abdce80  push rsi
000071709abdce81  push r8
000071709abdce83  push r9
000071709abdce85  push r10
000071709abdce87  push r11
000071709abdce89  sub rsp, 0xF0
000071709abdce90  vmovaps [rsp], xmm0
000071709abdce95  vmovaps [rsp+0x10], xmm1
000071709abdce9b  vmovaps [rsp+0x20], xmm2
000071709abdcea1  vmovaps [rsp+0x30], xmm3
000071709abdcea7  vmovaps [rsp+0x40], xmm4
000071709abdcead  vmovaps [rsp+0x50], xmm5
000071709abdceb3  vmovaps [rsp+0x60], xmm7
000071709abdceb9  vmovaps [rsp+0x70], xmm8
000071709abdcebf  vmovaps [rsp+0x80], xmm9
000071709abdcec8  vmovaps [rsp+0x90], xmm10
000071709abdced1  vmovaps [rsp+0xA0], xmm11
000071709abdceda  vmovaps [rsp+0xB0], xmm12
000071709abdcee3  vmovaps [rsp+0xC0], xmm13
000071709abdceec  vmovaps [rsp+0xD0], xmm14
000071709abdcef5  vmovaps [rsp+0xE0], xmm15
000071709abdcefe  sub rsp, 0x30
000071709abdcf02  movaps [rsp], xmm6
000071709abdcf06  movaps [rsp+0x10], xmm12
000071709abdcf0c  movaps [rsp+0x20], xmm11
000071709abdcf12  lea rdi, [rsp]
000071709abdcf16  mov esi, 0x00
000071709abdcf1b  mov rax, 0x60B9B2ABC530
000071709abdcf25  call rax
000071709abdcf27  movaps xmm6, [rsp]
000071709abdcf2b  add rsp, 0x30
000071709abdcf2f  vmovaps xmm0, [rsp]
000071709abdcf34  vmovaps xmm1, [rsp+0x10]
000071709abdcf3a  vmovaps xmm2, [rsp+0x20]
000071709abdcf40  vmovaps xmm3, [rsp+0x30]
000071709abdcf46  vmovaps xmm4, [rsp+0x40]
000071709abdcf4c  vmovaps xmm5, [rsp+0x50]
000071709abdcf52  vmovaps xmm7, [rsp+0x60]
000071709abdcf58  vmovaps xmm8, [rsp+0x70]
000071709abdcf5e  vmovaps xmm9, [rsp+0x80]
000071709abdcf67  vmovaps xmm10, [rsp+0x90]
000071709abdcf70  vmovaps xmm11, [rsp+0xA0]
000071709abdcf79  vmovaps xmm12, [rsp+0xB0]
000071709abdcf82  vmovaps xmm13, [rsp+0xC0]
000071709abdcf8b  vmovaps xmm14, [rsp+0xD0]
000071709abdcf94  vmovaps xmm15, [rsp+0xE0]
000071709abdcf9d  add rsp, 0xF0
000071709abdcfa4  pop r11
000071709abdcfa6  pop r10
000071709abdcfa8  pop r9
000071709abdcfaa  pop r8
000071709abdcfac  pop rsi
000071709abdcfad  pop rdi
000071709abdcfae  pop rdx
000071709abdcfaf  pop rcx
000071709abdcfb0  pop rax
000071709abdcfb1  add rsp, 0x08
000071709abdcfb5  jmp 0x000071709ABDBBD4
000071709abdcfba  sub rsp, 0x08
000071709abdcfbe  push rax
000071709abdcfbf  push rcx
000071709abdcfc0  push rdx
000071709abdcfc1  push rdi
000071709abdcfc2  push rsi
000071709abdcfc3  push r8
000071709abdcfc5  push r9
000071709abdcfc7  push r10
000071709abdcfc9  push r11
000071709abdcfcb  sub rsp, 0xF0
000071709abdcfd2  vmovaps [rsp], xmm0
000071709abdcfd7  vmovaps [rsp+0x10], xmm1
000071709abdcfdd  vmovaps [rsp+0x20], xmm2
000071709abdcfe3  vmovaps [rsp+0x30], xmm4
000071709abdcfe9  vmovaps [rsp+0x40], xmm5
000071709abdcfef  vmovaps [rsp+0x50], xmm6
000071709abdcff5  vmovaps [rsp+0x60], xmm7
000071709abdcffb  vmovaps [rsp+0x70], xmm8
000071709abdd001  vmovaps [rsp+0x80], xmm9
000071709abdd00a  vmovaps [rsp+0x90], xmm10
000071709abdd013  vmovaps [rsp+0xA0], xmm11
000071709abdd01c  vmovaps [rsp+0xB0], xmm12
000071709abdd025  vmovaps [rsp+0xC0], xmm13
000071709abdd02e  vmovaps [rsp+0xD0], xmm14
000071709abdd037  vmovaps [rsp+0xE0], xmm15
000071709abdd040  sub rsp, 0x30
000071709abdd044  movaps [rsp], xmm3
000071709abdd048  movaps [rsp+0x10], xmm5
000071709abdd04d  movaps [rsp+0x20], xmm4
000071709abdd052  lea rdi, [rsp]
000071709abdd056  mov esi, 0x00
000071709abdd05b  mov rax, 0x60B9B2ABC530
000071709abdd065  call rax
000071709abdd067  movaps xmm3, [rsp]
000071709abdd06b  add rsp, 0x30
000071709abdd06f  vmovaps xmm0, [rsp]
000071709abdd074  vmovaps xmm1, [rsp+0x10]
000071709abdd07a  vmovaps xmm2, [rsp+0x20]
000071709abdd080  vmovaps xmm4, [rsp+0x30]
000071709abdd086  vmovaps xmm5, [rsp+0x40]
000071709abdd08c  vmovaps xmm6, [rsp+0x50]
000071709abdd092  vmovaps xmm7, [rsp+0x60]
000071709abdd098  vmovaps xmm8, [rsp+0x70]
000071709abdd09e  vmovaps xmm9, [rsp+0x80]
000071709abdd0a7  vmovaps xmm10, [rsp+0x90]
000071709abdd0b0  vmovaps xmm11, [rsp+0xA0]
000071709abdd0b9  vmovaps xmm12, [rsp+0xB0]
000071709abdd0c2  vmovaps xmm13, [rsp+0xC0]
000071709abdd0cb  vmovaps xmm14, [rsp+0xD0]
000071709abdd0d4  vmovaps xmm15, [rsp+0xE0]
000071709abdd0dd  add rsp, 0xF0
000071709abdd0e4  pop r11
000071709abdd0e6  pop r10
000071709abdd0e8  pop r9
000071709abdd0ea  pop r8
000071709abdd0ec  pop rsi
000071709abdd0ed  pop rdi
000071709abdd0ee  pop rdx
000071709abdd0ef  pop rcx
000071709abdd0f0  pop rax
000071709abdd0f1  add rsp, 0x08
000071709abdd0f5  jmp 0x000071709ABDBC35
000071709abdd0fa  sub rsp, 0x08
000071709abdd0fe  push rax
000071709abdd0ff  push rcx
000071709abdd100  push rdx
000071709abdd101  push rdi
000071709abdd102  push rsi
000071709abdd103  push r8
000071709abdd105  push r9
000071709abdd107  push r10
000071709abdd109  push r11
000071709abdd10b  sub rsp, 0xF0
000071709abdd112  vmovaps [rsp], xmm0
000071709abdd117  vmovaps [rsp+0x10], xmm1
000071709abdd11d  vmovaps [rsp+0x20], xmm2
000071709abdd123  vmovaps [rsp+0x30], xmm3
000071709abdd129  vmovaps [rsp+0x40], xmm4
000071709abdd12f  vmovaps [rsp+0x50], xmm6
000071709abdd135  vmovaps [rsp+0x60], xmm7
000071709abdd13b  vmovaps [rsp+0x70], xmm8
000071709abdd141  vmovaps [rsp+0x80], xmm9
000071709abdd14a  vmovaps [rsp+0x90], xmm10
000071709abdd153  vmovaps [rsp+0xA0], xmm11
000071709abdd15c  vmovaps [rsp+0xB0], xmm12
000071709abdd165  vmovaps [rsp+0xC0], xmm13
000071709abdd16e  vmovaps [rsp+0xD0], xmm14
000071709abdd177  vmovaps [rsp+0xE0], xmm15
000071709abdd180  sub rsp, 0x30
000071709abdd184  movaps [rsp], xmm5
000071709abdd188  movaps [rsp+0x10], xmm8
000071709abdd18e  movaps [rsp+0x20], xmm15
000071709abdd194  lea rdi, [rsp]
000071709abdd198  mov esi, 0x00
000071709abdd19d  mov rax, 0x60B9B2ABC530
000071709abdd1a7  call rax
000071709abdd1a9  movaps xmm5, [rsp]
000071709abdd1ad  add rsp, 0x30
000071709abdd1b1  vmovaps xmm0, [rsp]
000071709abdd1b6  vmovaps xmm1, [rsp+0x10]
000071709abdd1bc  vmovaps xmm2, [rsp+0x20]
000071709abdd1c2  vmovaps xmm3, [rsp+0x30]
000071709abdd1c8  vmovaps xmm4, [rsp+0x40]
000071709abdd1ce  vmovaps xmm6, [rsp+0x50]
000071709abdd1d4  vmovaps xmm7, [rsp+0x60]
000071709abdd1da  vmovaps xmm8, [rsp+0x70]
000071709abdd1e0  vmovaps xmm9, [rsp+0x80]
000071709abdd1e9  vmovaps xmm10, [rsp+0x90]
000071709abdd1f2  vmovaps xmm11, [rsp+0xA0]
000071709abdd1fb  vmovaps xmm12, [rsp+0xB0]
000071709abdd204  vmovaps xmm13, [rsp+0xC0]
000071709abdd20d  vmovaps xmm14, [rsp+0xD0]
000071709abdd216  vmovaps xmm15, [rsp+0xE0]
000071709abdd21f  add rsp, 0xF0
000071709abdd226  pop r11
000071709abdd228  pop r10
000071709abdd22a  pop r9
000071709abdd22c  pop r8
000071709abdd22e  pop rsi
000071709abdd22f  pop rdi
000071709abdd230  pop rdx
000071709abdd231  pop rcx
000071709abdd232  pop rax
000071709abdd233  add rsp, 0x08
000071709abdd237  jmp 0x000071709ABDBC73
000071709abdd23c  sub rsp, 0x08
000071709abdd240  push rax
000071709abdd241  push rcx
000071709abdd242  push rdx
000071709abdd243  push rdi
000071709abdd244  push rsi
000071709abdd245  push r8
000071709abdd247  push r9
000071709abdd249  push r10
000071709abdd24b  push r11
000071709abdd24d  sub rsp, 0xF0
000071709abdd254  vmovaps [rsp], xmm0
000071709abdd259  vmovaps [rsp+0x10], xmm1
000071709abdd25f  vmovaps [rsp+0x20], xmm2
000071709abdd265  vmovaps [rsp+0x30], xmm3
000071709abdd26b  vmovaps [rsp+0x40], xmm5
000071709abdd271  vmovaps [rsp+0x50], xmm6
000071709abdd277  vmovaps [rsp+0x60], xmm7
000071709abdd27d  vmovaps [rsp+0x70], xmm8
000071709abdd283  vmovaps [rsp+0x80], xmm9
000071709abdd28c  vmovaps [rsp+0x90], xmm10
000071709abdd295  vmovaps [rsp+0xA0], xmm11
000071709abdd29e  vmovaps [rsp+0xB0], xmm12
000071709abdd2a7  vmovaps [rsp+0xC0], xmm13
000071709abdd2b0  vmovaps [rsp+0xD0], xmm14
000071709abdd2b9  vmovaps [rsp+0xE0], xmm15
000071709abdd2c2  sub rsp, 0x30
000071709abdd2c6  movaps [rsp], xmm4
000071709abdd2ca  movaps [rsp+0x10], xmm9
000071709abdd2d0  movaps [rsp+0x20], xmm8
000071709abdd2d6  lea rdi, [rsp]
000071709abdd2da  mov esi, 0x00
000071709abdd2df  mov rax, 0x60B9B2ABC530
000071709abdd2e9  call rax
000071709abdd2eb  movaps xmm4, [rsp]
000071709abdd2ef  add rsp, 0x30
000071709abdd2f3  vmovaps xmm0, [rsp]
000071709abdd2f8  vmovaps xmm1, [rsp+0x10]
000071709abdd2fe  vmovaps xmm2, [rsp+0x20]
000071709abdd304  vmovaps xmm3, [rsp+0x30]
000071709abdd30a  vmovaps xmm5, [rsp+0x40]
000071709abdd310  vmovaps xmm6, [rsp+0x50]
000071709abdd316  vmovaps xmm7, [rsp+0x60]
000071709abdd31c  vmovaps xmm8, [rsp+0x70]
000071709abdd322  vmovaps xmm9, [rsp+0x80]
000071709abdd32b  vmovaps xmm10, [rsp+0x90]
000071709abdd334  vmovaps xmm11, [rsp+0xA0]
000071709abdd33d  vmovaps xmm12, [rsp+0xB0]
000071709abdd346  vmovaps xmm13, [rsp+0xC0]
000071709abdd34f  vmovaps xmm14, [rsp+0xD0]
000071709abdd358  vmovaps xmm15, [rsp+0xE0]
000071709abdd361  add rsp, 0xF0
000071709abdd368  pop r11
000071709abdd36a  pop r10
000071709abdd36c  pop r9
000071709abdd36e  pop r8
000071709abdd370  pop rsi
000071709abdd371  pop rdi
000071709abdd372  pop rdx
000071709abdd373  pop rcx
000071709abdd374  pop rax
000071709abdd375  add rsp, 0x08
000071709abdd379  jmp 0x000071709ABDBC94
000071709abdd37e  sub rsp, 0x08
000071709abdd382  push rax
000071709abdd383  push rcx
000071709abdd384  push rdx
000071709abdd385  push rdi
000071709abdd386  push rsi
000071709abdd387  push r8
000071709abdd389  push r9
000071709abdd38b  push r10
000071709abdd38d  push r11
000071709abdd38f  sub rsp, 0xF0
000071709abdd396  vmovaps [rsp], xmm0
000071709abdd39b  vmovaps [rsp+0x10], xmm1
000071709abdd3a1  vmovaps [rsp+0x20], xmm2
000071709abdd3a7  vmovaps [rsp+0x30], xmm3
000071709abdd3ad  vmovaps [rsp+0x40], xmm4
000071709abdd3b3  vmovaps [rsp+0x50], xmm5
000071709abdd3b9  vmovaps [rsp+0x60], xmm6
000071709abdd3bf  vmovaps [rsp+0x70], xmm7
000071709abdd3c5  vmovaps [rsp+0x80], xmm8
000071709abdd3ce  vmovaps [rsp+0x90], xmm10
000071709abdd3d7  vmovaps [rsp+0xA0], xmm11
000071709abdd3e0  vmovaps [rsp+0xB0], xmm12
000071709abdd3e9  vmovaps [rsp+0xC0], xmm13
000071709abdd3f2  vmovaps [rsp+0xD0], xmm14
000071709abdd3fb  vmovaps [rsp+0xE0], xmm15
000071709abdd404  sub rsp, 0x30
000071709abdd408  movaps [rsp], xmm9
000071709abdd40d  movaps [rsp+0x10], xmm10
000071709abdd413  movaps [rsp+0x20], xmm8
000071709abdd419  lea rdi, [rsp]
000071709abdd41d  mov esi, 0x00
000071709abdd422  mov rax, 0x60B9B2ABC530
000071709abdd42c  call rax
000071709abdd42e  movaps xmm9, [rsp]
000071709abdd433  add rsp, 0x30
000071709abdd437  vmovaps xmm0, [rsp]
000071709abdd43c  vmovaps xmm1, [rsp+0x10]
000071709abdd442  vmovaps xmm2, [rsp+0x20]
000071709abdd448  vmovaps xmm3, [rsp+0x30]
000071709abdd44e  vmovaps xmm4, [rsp+0x40]
000071709abdd454  vmovaps xmm5, [rsp+0x50]
000071709abdd45a  vmovaps xmm6, [rsp+0x60]
000071709abdd460  vmovaps xmm7, [rsp+0x70]
000071709abdd466  vmovaps xmm8, [rsp+0x80]
000071709abdd46f  vmovaps xmm10, [rsp+0x90]
000071709abdd478  vmovaps xmm11, [rsp+0xA0]
000071709abdd481  vmovaps xmm12, [rsp+0xB0]
000071709abdd48a  vmovaps xmm13, [rsp+0xC0]
000071709abdd493  vmovaps xmm14, [rsp+0xD0]
000071709abdd49c  vmovaps xmm15, [rsp+0xE0]
000071709abdd4a5  add rsp, 0xF0
000071709abdd4ac  pop r11
000071709abdd4ae  pop r10
000071709abdd4b0  pop r9
000071709abdd4b2  pop r8
000071709abdd4b4  pop rsi
000071709abdd4b5  pop rdi
000071709abdd4b6  pop rdx
000071709abdd4b7  pop rcx
000071709abdd4b8  pop rax
000071709abdd4b9  add rsp, 0x08
000071709abdd4bd  jmp 0x000071709ABDBCAE
000071709abdd4c2  call 0x000071709AAB52F0
000071709abdd4c7  jmp 0x000071709ABDBDC8
000071709abdd4cc  call 0x000071709AAB52F0
000071709abdd4d1  jmp 0x000071709ABDBDDE
000071709abdd4d6  sub rsp, 0x08
000071709abdd4da  push rax
000071709abdd4db  push rcx
000071709abdd4dc  push rdx
000071709abdd4dd  push rdi
000071709abdd4de  push rsi
000071709abdd4df  push r8
000071709abdd4e1  push r9
000071709abdd4e3  push r10
000071709abdd4e5  push r11
000071709abdd4e7  sub rsp, 0xF0
000071709abdd4ee  vmovaps [rsp], xmm0
000071709abdd4f3  vmovaps [rsp+0x10], xmm2
000071709abdd4f9  vmovaps [rsp+0x20], xmm3
000071709abdd4ff  vmovaps [rsp+0x30], xmm4
000071709abdd505  vmovaps [rsp+0x40], xmm5
000071709abdd50b  vmovaps [rsp+0x50], xmm6
000071709abdd511  vmovaps [rsp+0x60], xmm7
000071709abdd517  vmovaps [rsp+0x70], xmm8
000071709abdd51d  vmovaps [rsp+0x80], xmm9
000071709abdd526  vmovaps [rsp+0x90], xmm10
000071709abdd52f  vmovaps [rsp+0xA0], xmm11
000071709abdd538  vmovaps [rsp+0xB0], xmm12
000071709abdd541  vmovaps [rsp+0xC0], xmm13
000071709abdd54a  vmovaps [rsp+0xD0], xmm14
000071709abdd553  vmovaps [rsp+0xE0], xmm15
000071709abdd55c  sub rsp, 0x30
000071709abdd560  movaps [rsp], xmm1
000071709abdd564  movaps [rsp+0x10], xmm6
000071709abdd569  movaps [rsp+0x20], xmm15
000071709abdd56f  lea rdi, [rsp]
000071709abdd573  mov esi, 0x00
000071709abdd578  mov rax, 0x60B9B2ABC530
000071709abdd582  call rax
000071709abdd584  movaps xmm1, [rsp]
000071709abdd588  add rsp, 0x30
000071709abdd58c  vmovaps xmm0, [rsp]
000071709abdd591  vmovaps xmm2, [rsp+0x10]
000071709abdd597  vmovaps xmm3, [rsp+0x20]
000071709abdd59d  vmovaps xmm4, [rsp+0x30]
000071709abdd5a3  vmovaps xmm5, [rsp+0x40]
000071709abdd5a9  vmovaps xmm6, [rsp+0x50]
000071709abdd5af  vmovaps xmm7, [rsp+0x60]
000071709abdd5b5  vmovaps xmm8, [rsp+0x70]
000071709abdd5bb  vmovaps xmm9, [rsp+0x80]
000071709abdd5c4  vmovaps xmm10, [rsp+0x90]
000071709abdd5cd  vmovaps xmm11, [rsp+0xA0]
000071709abdd5d6  vmovaps xmm12, [rsp+0xB0]
000071709abdd5df  vmovaps xmm13, [rsp+0xC0]
000071709abdd5e8  vmovaps xmm14, [rsp+0xD0]
000071709abdd5f1  vmovaps xmm15, [rsp+0xE0]
000071709abdd5fa  add rsp, 0xF0
000071709abdd601  pop r11
000071709abdd603  pop r10
000071709abdd605  pop r9
000071709abdd607  pop r8
000071709abdd609  pop rsi
000071709abdd60a  pop rdi
000071709abdd60b  pop rdx
000071709abdd60c  pop rcx
000071709abdd60d  pop rax
000071709abdd60e  add rsp, 0x08
000071709abdd612  jmp 0x000071709ABDBE1B
000071709abdd617  call 0x000071709AAC4620
000071709abdd61c  jmp 0x000071709ABDBE28
000071709abdd621  sub rsp, 0x08
000071709abdd625  push rax
000071709abdd626  push rcx
000071709abdd627  push rdx
000071709abdd628  push rdi
000071709abdd629  push rsi
000071709abdd62a  push r8
000071709abdd62c  push r9
000071709abdd62e  push r10
000071709abdd630  push r11
000071709abdd632  sub rsp, 0xF0
000071709abdd639  vmovaps [rsp], xmm0
000071709abdd63e  vmovaps [rsp+0x10], xmm1
000071709abdd644  vmovaps [rsp+0x20], xmm2
000071709abdd64a  vmovaps [rsp+0x30], xmm3
000071709abdd650  vmovaps [rsp+0x40], xmm4
000071709abdd656  vmovaps [rsp+0x50], xmm5
000071709abdd65c  vmovaps [rsp+0x60], xmm6
000071709abdd662  vmovaps [rsp+0x70], xmm7
000071709abdd668  vmovaps [rsp+0x80], xmm8
000071709abdd671  vmovaps [rsp+0x90], xmm9
000071709abdd67a  vmovaps [rsp+0xA0], xmm10
000071709abdd683  vmovaps [rsp+0xB0], xmm11
000071709abdd68c  vmovaps [rsp+0xC0], xmm12
000071709abdd695  vmovaps [rsp+0xD0], xmm13
000071709abdd69e  vmovaps [rsp+0xE0], xmm15
000071709abdd6a7  sub rsp, 0x30
000071709abdd6ab  movaps [rsp], xmm14
000071709abdd6b0  movaps [rsp+0x10], xmm4
000071709abdd6b5  movaps [rsp+0x20], xmm3
000071709abdd6ba  lea rdi, [rsp]
000071709abdd6be  mov esi, 0x00
000071709abdd6c3  mov rax, 0x60B9B2ABC530
000071709abdd6cd  call rax
000071709abdd6cf  movaps xmm14, [rsp]
000071709abdd6d4  add rsp, 0x30
000071709abdd6d8  vmovaps xmm0, [rsp]
000071709abdd6dd  vmovaps xmm1, [rsp+0x10]
000071709abdd6e3  vmovaps xmm2, [rsp+0x20]
000071709abdd6e9  vmovaps xmm3, [rsp+0x30]
000071709abdd6ef  vmovaps xmm4, [rsp+0x40]
000071709abdd6f5  vmovaps xmm5, [rsp+0x50]
000071709abdd6fb  vmovaps xmm6, [rsp+0x60]
000071709abdd701  vmovaps xmm7, [rsp+0x70]
000071709abdd707  vmovaps xmm8, [rsp+0x80]
000071709abdd710  vmovaps xmm9, [rsp+0x90]
000071709abdd719  vmovaps xmm10, [rsp+0xA0]
000071709abdd722  vmovaps xmm11, [rsp+0xB0]
000071709abdd72b  vmovaps xmm12, [rsp+0xC0]
000071709abdd734  vmovaps xmm13, [rsp+0xD0]
000071709abdd73d  vmovaps xmm15, [rsp+0xE0]
000071709abdd746  add rsp, 0xF0
000071709abdd74d  pop r11
000071709abdd74f  pop r10
000071709abdd751  pop r9
000071709abdd753  pop r8
000071709abdd755  pop rsi
000071709abdd756  pop rdi
000071709abdd757  pop rdx
000071709abdd758  pop rcx
000071709abdd759  pop rax
000071709abdd75a  add rsp, 0x08
000071709abdd75e  jmp 0x000071709ABDBE42
000071709abdd763  sub rsp, 0x08
000071709abdd767  push rax
000071709abdd768  push rcx
000071709abdd769  push rdx
000071709abdd76a  push rdi
000071709abdd76b  push rsi
000071709abdd76c  push r8
000071709abdd76e  push r9
000071709abdd770  push r10
000071709abdd772  push r11
000071709abdd774  sub rsp, 0xF0
000071709abdd77b  vmovaps [rsp], xmm0
000071709abdd780  vmovaps [rsp+0x10], xmm1
000071709abdd786  vmovaps [rsp+0x20], xmm2
000071709abdd78c  vmovaps [rsp+0x30], xmm3
000071709abdd792  vmovaps [rsp+0x40], xmm4
000071709abdd798  vmovaps [rsp+0x50], xmm5
000071709abdd79e  vmovaps [rsp+0x60], xmm7
000071709abdd7a4  vmovaps [rsp+0x70], xmm8
000071709abdd7aa  vmovaps [rsp+0x80], xmm9
000071709abdd7b3  vmovaps [rsp+0x90], xmm10
000071709abdd7bc  vmovaps [rsp+0xA0], xmm11
000071709abdd7c5  vmovaps [rsp+0xB0], xmm12
000071709abdd7ce  vmovaps [rsp+0xC0], xmm13
000071709abdd7d7  vmovaps [rsp+0xD0], xmm14
000071709abdd7e0  vmovaps [rsp+0xE0], xmm15
000071709abdd7e9  sub rsp, 0x30
000071709abdd7ed  movaps [rsp], xmm6
000071709abdd7f1  movaps [rsp+0x10], xmm9
000071709abdd7f7  movaps [rsp+0x20], xmm7
000071709abdd7fc  lea rdi, [rsp]
000071709abdd800  mov esi, 0x00
000071709abdd805  mov rax, 0x60B9B2ABC530
000071709abdd80f  call rax
000071709abdd811  movaps xmm6, [rsp]
000071709abdd815  add rsp, 0x30
000071709abdd819  vmovaps xmm0, [rsp]
000071709abdd81e  vmovaps xmm1, [rsp+0x10]
000071709abdd824  vmovaps xmm2, [rsp+0x20]
000071709abdd82a  vmovaps xmm3, [rsp+0x30]
000071709abdd830  vmovaps xmm4, [rsp+0x40]
000071709abdd836  vmovaps xmm5, [rsp+0x50]
000071709abdd83c  vmovaps xmm7, [rsp+0x60]
000071709abdd842  vmovaps xmm8, [rsp+0x70]
000071709abdd848  vmovaps xmm9, [rsp+0x80]
000071709abdd851  vmovaps xmm10, [rsp+0x90]
000071709abdd85a  vmovaps xmm11, [rsp+0xA0]
000071709abdd863  vmovaps xmm12, [rsp+0xB0]
000071709abdd86c  vmovaps xmm13, [rsp+0xC0]
000071709abdd875  vmovaps xmm14, [rsp+0xD0]
000071709abdd87e  vmovaps xmm15, [rsp+0xE0]
000071709abdd887  add rsp, 0xF0
000071709abdd88e  pop r11
000071709abdd890  pop r10
000071709abdd892  pop r9
000071709abdd894  pop r8
000071709abdd896  pop rsi
000071709abdd897  pop rdi
000071709abdd898  pop rdx
000071709abdd899  pop rcx
000071709abdd89a  pop rax
000071709abdd89b  add rsp, 0x08
000071709abdd89f  jmp 0x000071709ABDBE5A
000071709abdd8a4  sub rsp, 0x08
000071709abdd8a8  push rax
000071709abdd8a9  push rcx
000071709abdd8aa  push rdx
000071709abdd8ab  push rdi
000071709abdd8ac  push rsi
000071709abdd8ad  push r8
000071709abdd8af  push r9
000071709abdd8b1  push r10
000071709abdd8b3  push r11
000071709abdd8b5  sub rsp, 0xF0
000071709abdd8bc  vmovaps [rsp], xmm0
000071709abdd8c1  vmovaps [rsp+0x10], xmm1
000071709abdd8c7  vmovaps [rsp+0x20], xmm2
000071709abdd8cd  vmovaps [rsp+0x30], xmm3
000071709abdd8d3  vmovaps [rsp+0x40], xmm4
000071709abdd8d9  vmovaps [rsp+0x50], xmm5
000071709abdd8df  vmovaps [rsp+0x60], xmm6
000071709abdd8e5  vmovaps [rsp+0x70], xmm8
000071709abdd8eb  vmovaps [rsp+0x80], xmm9
000071709abdd8f4  vmovaps [rsp+0x90], xmm10
000071709abdd8fd  vmovaps [rsp+0xA0], xmm11
000071709abdd906  vmovaps [rsp+0xB0], xmm12
000071709abdd90f  vmovaps [rsp+0xC0], xmm13
000071709abdd918  vmovaps [rsp+0xD0], xmm14
000071709abdd921  vmovaps [rsp+0xE0], xmm15
000071709abdd92a  sub rsp, 0x30
000071709abdd92e  movaps [rsp], xmm7
000071709abdd932  movaps [rsp+0x10], xmm4
000071709abdd937  movaps [rsp+0x20], xmm9
000071709abdd93d  lea rdi, [rsp]
000071709abdd941  mov esi, 0x00
000071709abdd946  mov rax, 0x60B9B2ABC530
000071709abdd950  call rax
000071709abdd952  movaps xmm7, [rsp]
000071709abdd956  add rsp, 0x30
000071709abdd95a  vmovaps xmm0, [rsp]
000071709abdd95f  vmovaps xmm1, [rsp+0x10]
000071709abdd965  vmovaps xmm2, [rsp+0x20]
000071709abdd96b  vmovaps xmm3, [rsp+0x30]
000071709abdd971  vmovaps xmm4, [rsp+0x40]
000071709abdd977  vmovaps xmm5, [rsp+0x50]
000071709abdd97d  vmovaps xmm6, [rsp+0x60]
000071709abdd983  vmovaps xmm8, [rsp+0x70]
000071709abdd989  vmovaps xmm9, [rsp+0x80]
000071709abdd992  vmovaps xmm10, [rsp+0x90]
000071709abdd99b  vmovaps xmm11, [rsp+0xA0]
000071709abdd9a4  vmovaps xmm12, [rsp+0xB0]
000071709abdd9ad  vmovaps xmm13, [rsp+0xC0]
000071709abdd9b6  vmovaps xmm14, [rsp+0xD0]
000071709abdd9bf  vmovaps xmm15, [rsp+0xE0]
000071709abdd9c8  add rsp, 0xF0
000071709abdd9cf  pop r11
000071709abdd9d1  pop r10
000071709abdd9d3  pop r9
000071709abdd9d5  pop r8
000071709abdd9d7  pop rsi
000071709abdd9d8  pop rdi
000071709abdd9d9  pop rdx
000071709abdd9da  pop rcx
000071709abdd9db  pop rax
000071709abdd9dc  add rsp, 0x08
000071709abdd9e0  jmp 0x000071709ABDBE87
000071709abdd9e5  sub rsp, 0x08
000071709abdd9e9  push rax
000071709abdd9ea  push rcx
000071709abdd9eb  push rdx
000071709abdd9ec  push rdi
000071709abdd9ed  push rsi
000071709abdd9ee  push r8
000071709abdd9f0  push r9
000071709abdd9f2  push r10
000071709abdd9f4  push r11
000071709abdd9f6  sub rsp, 0xF0
000071709abdd9fd  vmovaps [rsp], xmm0
000071709abdda02  vmovaps [rsp+0x10], xmm1
000071709abdda08  vmovaps [rsp+0x20], xmm2
000071709abdda0e  vmovaps [rsp+0x30], xmm3
000071709abdda14  vmovaps [rsp+0x40], xmm5
000071709abdda1a  vmovaps [rsp+0x50], xmm6
000071709abdda20  vmovaps [rsp+0x60], xmm7
000071709abdda26  vmovaps [rsp+0x70], xmm8
000071709abdda2c  vmovaps [rsp+0x80], xmm9
000071709abdda35  vmovaps [rsp+0x90], xmm10
000071709abdda3e  vmovaps [rsp+0xA0], xmm11
000071709abdda47  vmovaps [rsp+0xB0], xmm12
000071709abdda50  vmovaps [rsp+0xC0], xmm13
000071709abdda59  vmovaps [rsp+0xD0], xmm14
000071709abdda62  vmovaps [rsp+0xE0], xmm15
000071709abdda6b  sub rsp, 0x30
000071709abdda6f  movaps [rsp], xmm4
000071709abdda73  movaps [rsp+0x10], xmm15
000071709abdda79  movaps [rsp+0x20], xmm9
000071709abdda7f  lea rdi, [rsp]
000071709abdda83  mov esi, 0x00
000071709abdda88  mov rax, 0x60B9B2ABC530
000071709abdda92  call rax
000071709abdda94  movaps xmm4, [rsp]
000071709abdda98  add rsp, 0x30
000071709abdda9c  vmovaps xmm0, [rsp]
000071709abddaa1  vmovaps xmm1, [rsp+0x10]
000071709abddaa7  vmovaps xmm2, [rsp+0x20]
000071709abddaad  vmovaps xmm3, [rsp+0x30]
000071709abddab3  vmovaps xmm5, [rsp+0x40]
000071709abddab9  vmovaps xmm6, [rsp+0x50]
000071709abddabf  vmovaps xmm7, [rsp+0x60]
000071709abddac5  vmovaps xmm8, [rsp+0x70]
000071709abddacb  vmovaps xmm9, [rsp+0x80]
000071709abddad4  vmovaps xmm10, [rsp+0x90]
000071709abddadd  vmovaps xmm11, [rsp+0xA0]
000071709abddae6  vmovaps xmm12, [rsp+0xB0]
000071709abddaef  vmovaps xmm13, [rsp+0xC0]
000071709abddaf8  vmovaps xmm14, [rsp+0xD0]
000071709abddb01  vmovaps xmm15, [rsp+0xE0]
000071709abddb0a  add rsp, 0xF0
000071709abddb11  pop r11
000071709abddb13  pop r10
000071709abddb15  pop r9
000071709abddb17  pop r8
000071709abddb19  pop rsi
000071709abddb1a  pop rdi
000071709abddb1b  pop rdx
000071709abddb1c  pop rcx
000071709abddb1d  pop rax
000071709abddb1e  add rsp, 0x08
000071709abddb22  jmp 0x000071709ABDBEAC
000071709abddb27  call 0x000071709AAC4620
000071709abddb2c  jmp 0x000071709ABDBEB9
000071709abddb31  sub rsp, 0x08
000071709abddb35  push rax
000071709abddb36  push rcx
000071709abddb37  push rdx
000071709abddb38  push rdi
000071709abddb39  push rsi
000071709abddb3a  push r8
000071709abddb3c  push r9
000071709abddb3e  push r10
000071709abddb40  push r11
000071709abddb42  sub rsp, 0xF0
000071709abddb49  vmovaps [rsp], xmm0
000071709abddb4e  vmovaps [rsp+0x10], xmm1
000071709abddb54  vmovaps [rsp+0x20], xmm2
000071709abddb5a  vmovaps [rsp+0x30], xmm4
000071709abddb60  vmovaps [rsp+0x40], xmm5
000071709abddb66  vmovaps [rsp+0x50], xmm6
000071709abddb6c  vmovaps [rsp+0x60], xmm7
000071709abddb72  vmovaps [rsp+0x70], xmm8
000071709abddb78  vmovaps [rsp+0x80], xmm9
000071709abddb81  vmovaps [rsp+0x90], xmm10
000071709abddb8a  vmovaps [rsp+0xA0], xmm11
000071709abddb93  vmovaps [rsp+0xB0], xmm12
000071709abddb9c  vmovaps [rsp+0xC0], xmm13
000071709abddba5  vmovaps [rsp+0xD0], xmm14
000071709abddbae  vmovaps [rsp+0xE0], xmm15
000071709abddbb7  sub rsp, 0x30
000071709abddbbb  movaps [rsp], xmm3
000071709abddbbf  movaps [rsp+0x10], xmm1
000071709abddbc4  movaps [rsp+0x20], xmm9
000071709abddbca  lea rdi, [rsp]
000071709abddbce  mov esi, 0x00
000071709abddbd3  mov rax, 0x60B9B2ABC530
000071709abddbdd  call rax
000071709abddbdf  movaps xmm3, [rsp]
000071709abddbe3  add rsp, 0x30
000071709abddbe7  vmovaps xmm0, [rsp]
000071709abddbec  vmovaps xmm1, [rsp+0x10]
000071709abddbf2  vmovaps xmm2, [rsp+0x20]
000071709abddbf8  vmovaps xmm4, [rsp+0x30]
000071709abddbfe  vmovaps xmm5, [rsp+0x40]
000071709abddc04  vmovaps xmm6, [rsp+0x50]
000071709abddc0a  vmovaps xmm7, [rsp+0x60]
000071709abddc10  vmovaps xmm8, [rsp+0x70]
000071709abddc16  vmovaps xmm9, [rsp+0x80]
000071709abddc1f  vmovaps xmm10, [rsp+0x90]
000071709abddc28  vmovaps xmm11, [rsp+0xA0]
000071709abddc31  vmovaps xmm12, [rsp+0xB0]
000071709abddc3a  vmovaps xmm13, [rsp+0xC0]
000071709abddc43  vmovaps xmm14, [rsp+0xD0]
000071709abddc4c  vmovaps xmm15, [rsp+0xE0]
000071709abddc55  add rsp, 0xF0
000071709abddc5c  pop r11
000071709abddc5e  pop r10
000071709abddc60  pop r9
000071709abddc62  pop r8
000071709abddc64  pop rsi
000071709abddc65  pop rdi
000071709abddc66  pop rdx
000071709abddc67  pop rcx
000071709abddc68  pop rax
000071709abddc69  add rsp, 0x08
000071709abddc6d  jmp 0x000071709ABDBEF6
000071709abddc72  sub rsp, 0x08
000071709abddc76  push rax
000071709abddc77  push rcx
000071709abddc78  push rdx
000071709abddc79  push rdi
000071709abddc7a  push rsi
000071709abddc7b  push r8
000071709abddc7d  push r9
000071709abddc7f  push r10
000071709abddc81  push r11
000071709abddc83  sub rsp, 0xF0
000071709abddc8a  vmovaps [rsp], xmm0
000071709abddc8f  vmovaps [rsp+0x10], xmm2
000071709abddc95  vmovaps [rsp+0x20], xmm3
000071709abddc9b  vmovaps [rsp+0x30], xmm4
000071709abddca1  vmovaps [rsp+0x40], xmm5
000071709abddca7  vmovaps [rsp+0x50], xmm6
000071709abddcad  vmovaps [rsp+0x60], xmm7
000071709abddcb3  vmovaps [rsp+0x70], xmm8
000071709abddcb9  vmovaps [rsp+0x80], xmm9
000071709abddcc2  vmovaps [rsp+0x90], xmm10
000071709abddccb  vmovaps [rsp+0xA0], xmm11
000071709abddcd4  vmovaps [rsp+0xB0], xmm12
000071709abddcdd  vmovaps [rsp+0xC0], xmm13
000071709abddce6  vmovaps [rsp+0xD0], xmm14
000071709abddcef  vmovaps [rsp+0xE0], xmm15
000071709abddcf8  sub rsp, 0x30
000071709abddcfc  movaps [rsp], xmm1
000071709abddd00  movaps [rsp+0x10], xmm15
000071709abddd06  movaps [rsp+0x20], xmm9
000071709abddd0c  lea rdi, [rsp]
000071709abddd10  mov esi, 0x00
000071709abddd15  mov rax, 0x60B9B2ABC530
000071709abddd1f  call rax
000071709abddd21  movaps xmm1, [rsp]
000071709abddd25  add rsp, 0x30
000071709abddd29  vmovaps xmm0, [rsp]
000071709abddd2e  vmovaps xmm2, [rsp+0x10]
000071709abddd34  vmovaps xmm3, [rsp+0x20]
000071709abddd3a  vmovaps xmm4, [rsp+0x30]
000071709abddd40  vmovaps xmm5, [rsp+0x40]
000071709abddd46  vmovaps xmm6, [rsp+0x50]
000071709abddd4c  vmovaps xmm7, [rsp+0x60]
000071709abddd52  vmovaps xmm8, [rsp+0x70]
000071709abddd58  vmovaps xmm9, [rsp+0x80]
000071709abddd61  vmovaps xmm10, [rsp+0x90]
000071709abddd6a  vmovaps xmm11, [rsp+0xA0]
000071709abddd73  vmovaps xmm12, [rsp+0xB0]
000071709abddd7c  vmovaps xmm13, [rsp+0xC0]
000071709abddd85  vmovaps xmm14, [rsp+0xD0]
000071709abddd8e  vmovaps xmm15, [rsp+0xE0]
000071709abddd97  add rsp, 0xF0
000071709abddd9e  pop r11
000071709abddda0  pop r10
000071709abddda2  pop r9
000071709abddda4  pop r8
000071709abddda6  pop rsi
000071709abddda7  pop rdi
000071709abddda8  pop rdx
000071709abddda9  pop rcx
000071709abdddaa  pop rax
000071709abdddab  add rsp, 0x08
000071709abdddaf  jmp 0x000071709ABDBF7E
000071709abdddb4  call 0x000071709AAC4620
000071709abdddb9  jmp 0x000071709ABDBF8B
000071709abdddbe  sub rsp, 0x08
000071709abdddc2  push rax
000071709abdddc3  push rcx
000071709abdddc4  push rdx
000071709abdddc5  push rdi
000071709abdddc6  push rsi
000071709abdddc7  push r8
000071709abdddc9  push r9
000071709abdddcb  push r10
000071709abdddcd  push r11
000071709abdddcf  sub rsp, 0xF0
000071709abdddd6  vmovaps [rsp], xmm0
000071709abddddb  vmovaps [rsp+0x10], xmm2
000071709abddde1  vmovaps [rsp+0x20], xmm3
000071709abddde7  vmovaps [rsp+0x30], xmm4
000071709abddded  vmovaps [rsp+0x40], xmm5
000071709abdddf3  vmovaps [rsp+0x50], xmm6
000071709abdddf9  vmovaps [rsp+0x60], xmm7
000071709abdddff  vmovaps [rsp+0x70], xmm8
000071709abdde05  vmovaps [rsp+0x80], xmm9
000071709abdde0e  vmovaps [rsp+0x90], xmm10
000071709abdde17  vmovaps [rsp+0xA0], xmm11
000071709abdde20  vmovaps [rsp+0xB0], xmm12
000071709abdde29  vmovaps [rsp+0xC0], xmm13
000071709abdde32  vmovaps [rsp+0xD0], xmm14
000071709abdde3b  vmovaps [rsp+0xE0], xmm15
000071709abdde44  sub rsp, 0x30
000071709abdde48  movaps [rsp], xmm1
000071709abdde4c  movaps [rsp+0x10], xmm5
000071709abdde51  movaps [rsp+0x20], xmm7
000071709abdde56  lea rdi, [rsp]
000071709abdde5a  mov esi, 0x00
000071709abdde5f  mov rax, 0x60B9B2ABC530
000071709abdde69  call rax
000071709abdde6b  movaps xmm1, [rsp]
000071709abdde6f  add rsp, 0x30
000071709abdde73  vmovaps xmm0, [rsp]
000071709abdde78  vmovaps xmm2, [rsp+0x10]
000071709abdde7e  vmovaps xmm3, [rsp+0x20]
000071709abdde84  vmovaps xmm4, [rsp+0x30]
000071709abdde8a  vmovaps xmm5, [rsp+0x40]
000071709abdde90  vmovaps xmm6, [rsp+0x50]
000071709abdde96  vmovaps xmm7, [rsp+0x60]
000071709abdde9c  vmovaps xmm8, [rsp+0x70]
000071709abddea2  vmovaps xmm9, [rsp+0x80]
000071709abddeab  vmovaps xmm10, [rsp+0x90]
000071709abddeb4  vmovaps xmm11, [rsp+0xA0]
000071709abddebd  vmovaps xmm12, [rsp+0xB0]
000071709abddec6  vmovaps xmm13, [rsp+0xC0]
000071709abddecf  vmovaps xmm14, [rsp+0xD0]
000071709abdded8  vmovaps xmm15, [rsp+0xE0]
000071709abddee1  add rsp, 0xF0
000071709abddee8  pop r11
000071709abddeea  pop r10
000071709abddeec  pop r9
000071709abddeee  pop r8
000071709abddef0  pop rsi
000071709abddef1  pop rdi
000071709abddef2  pop rdx
000071709abddef3  pop rcx
000071709abddef4  pop rax
000071709abddef5  add rsp, 0x08
000071709abddef9  jmp 0x000071709ABDC030
000071709abddefe  sub rsp, 0x08
000071709abddf02  push rax
000071709abddf03  push rcx
000071709abddf04  push rdx
000071709abddf05  push rdi
000071709abddf06  push rsi
000071709abddf07  push r8
000071709abddf09  push r9
000071709abddf0b  push r10
000071709abddf0d  push r11
000071709abddf0f  sub rsp, 0xF0
000071709abddf16  vmovaps [rsp], xmm0
000071709abddf1b  vmovaps [rsp+0x10], xmm1
000071709abddf21  vmovaps [rsp+0x20], xmm2
000071709abddf27  vmovaps [rsp+0x30], xmm3
000071709abddf2d  vmovaps [rsp+0x40], xmm4
000071709abddf33  vmovaps [rsp+0x50], xmm5
000071709abddf39  vmovaps [rsp+0x60], xmm6
000071709abddf3f  vmovaps [rsp+0x70], xmm8
000071709abddf45  vmovaps [rsp+0x80], xmm9
000071709abddf4e  vmovaps [rsp+0x90], xmm10
000071709abddf57  vmovaps [rsp+0xA0], xmm11
000071709abddf60  vmovaps [rsp+0xB0], xmm12
000071709abddf69  vmovaps [rsp+0xC0], xmm13
000071709abddf72  vmovaps [rsp+0xD0], xmm14
000071709abddf7b  vmovaps [rsp+0xE0], xmm15
000071709abddf84  sub rsp, 0x30
000071709abddf88  movaps [rsp], xmm7
000071709abddf8c  movaps [rsp+0x10], xmm5
000071709abddf91  movaps [rsp+0x20], xmm15
000071709abddf97  lea rdi, [rsp]
000071709abddf9b  mov esi, 0x00
000071709abddfa0  mov rax, 0x60B9B2ABC530
000071709abddfaa  call rax
000071709abddfac  movaps xmm7, [rsp]
000071709abddfb0  add rsp, 0x30
000071709abddfb4  vmovaps xmm0, [rsp]
000071709abddfb9  vmovaps xmm1, [rsp+0x10]
000071709abddfbf  vmovaps xmm2, [rsp+0x20]
000071709abddfc5  vmovaps xmm3, [rsp+0x30]
000071709abddfcb  vmovaps xmm4, [rsp+0x40]
000071709abddfd1  vmovaps xmm5, [rsp+0x50]
000071709abddfd7  vmovaps xmm6, [rsp+0x60]
000071709abddfdd  vmovaps xmm8, [rsp+0x70]
000071709abddfe3  vmovaps xmm9, [rsp+0x80]
000071709abddfec  vmovaps xmm10, [rsp+0x90]
000071709abddff5  vmovaps xmm11, [rsp+0xA0]
000071709abddffe  vmovaps xmm12, [rsp+0xB0]
000071709abde007  vmovaps xmm13, [rsp+0xC0]
000071709abde010  vmovaps xmm14, [rsp+0xD0]
000071709abde019  vmovaps xmm15, [rsp+0xE0]
000071709abde022  add rsp, 0xF0
000071709abde029  pop r11
000071709abde02b  pop r10
000071709abde02d  pop r9
000071709abde02f  pop r8
000071709abde031  pop rsi
000071709abde032  pop rdi
000071709abde033  pop rdx
000071709abde034  pop rcx
000071709abde035  pop rax
000071709abde036  add rsp, 0x08
000071709abde03a  jmp 0x000071709ABDC066
000071709abde03f  call 0x000071709AAB52F0
000071709abde044  jmp 0x000071709ABDC073
000071709abde049  sub rsp, 0x08
000071709abde04d  push rax
000071709abde04e  push rcx
000071709abde04f  push rdx
000071709abde050  push rdi
000071709abde051  push rsi
000071709abde052  push r8
000071709abde054  push r9
000071709abde056  push r10
000071709abde058  push r11
000071709abde05a  sub rsp, 0xF0
000071709abde061  vmovaps [rsp], xmm0
000071709abde066  vmovaps [rsp+0x10], xmm1
000071709abde06c  vmovaps [rsp+0x20], xmm2
000071709abde072  vmovaps [rsp+0x30], xmm3
000071709abde078  vmovaps [rsp+0x40], xmm4
000071709abde07e  vmovaps [rsp+0x50], xmm5
000071709abde084  vmovaps [rsp+0x60], xmm6
000071709abde08a  vmovaps [rsp+0x70], xmm7
000071709abde090  vmovaps [rsp+0x80], xmm8
000071709abde099  vmovaps [rsp+0x90], xmm9
000071709abde0a2  vmovaps [rsp+0xA0], xmm10
000071709abde0ab  vmovaps [rsp+0xB0], xmm11
000071709abde0b4  vmovaps [rsp+0xC0], xmm12
000071709abde0bd  vmovaps [rsp+0xD0], xmm13
000071709abde0c6  vmovaps [rsp+0xE0], xmm14
000071709abde0cf  sub rsp, 0x30
000071709abde0d3  movaps [rsp], xmm15
000071709abde0d8  movaps [rsp+0x10], xmm5
000071709abde0dd  movaps [rsp+0x20], xmm3
000071709abde0e2  lea rdi, [rsp]
000071709abde0e6  mov esi, 0x00
000071709abde0eb  mov rax, 0x60B9B2ABC530
000071709abde0f5  call rax
000071709abde0f7  movaps xmm15, [rsp]
000071709abde0fc  add rsp, 0x30
000071709abde100  vmovaps xmm0, [rsp]
000071709abde105  vmovaps xmm1, [rsp+0x10]
000071709abde10b  vmovaps xmm2, [rsp+0x20]
000071709abde111  vmovaps xmm3, [rsp+0x30]
000071709abde117  vmovaps xmm4, [rsp+0x40]
000071709abde11d  vmovaps xmm5, [rsp+0x50]
000071709abde123  vmovaps xmm6, [rsp+0x60]
000071709abde129  vmovaps xmm7, [rsp+0x70]
000071709abde12f  vmovaps xmm8, [rsp+0x80]
000071709abde138  vmovaps xmm9, [rsp+0x90]
000071709abde141  vmovaps xmm10, [rsp+0xA0]
000071709abde14a  vmovaps xmm11, [rsp+0xB0]
000071709abde153  vmovaps xmm12, [rsp+0xC0]
000071709abde15c  vmovaps xmm13, [rsp+0xD0]
000071709abde165  vmovaps xmm14, [rsp+0xE0]
000071709abde16e  add rsp, 0xF0
000071709abde175  pop r11
000071709abde177  pop r10
000071709abde179  pop r9
000071709abde17b  pop r8
000071709abde17d  pop rsi
000071709abde17e  pop rdi
000071709abde17f  pop rdx
000071709abde180  pop rcx
000071709abde181  pop rax
000071709abde182  add rsp, 0x08
000071709abde186  jmp 0x000071709ABDC099
000071709abde18b  sub rsp, 0x08
000071709abde18f  push rax
000071709abde190  push rcx
000071709abde191  push rdx
000071709abde192  push rdi
000071709abde193  push rsi
000071709abde194  push r8
000071709abde196  push r9
000071709abde198  push r10
000071709abde19a  push r11
000071709abde19c  sub rsp, 0xF0
000071709abde1a3  vmovaps [rsp], xmm0
000071709abde1a8  vmovaps [rsp+0x10], xmm2
000071709abde1ae  vmovaps [rsp+0x20], xmm3
000071709abde1b4  vmovaps [rsp+0x30], xmm4
000071709abde1ba  vmovaps [rsp+0x40], xmm5
000071709abde1c0  vmovaps [rsp+0x50], xmm6
000071709abde1c6  vmovaps [rsp+0x60], xmm7
000071709abde1cc  vmovaps [rsp+0x70], xmm8
000071709abde1d2  vmovaps [rsp+0x80], xmm9
000071709abde1db  vmovaps [rsp+0x90], xmm10
000071709abde1e4  vmovaps [rsp+0xA0], xmm11
000071709abde1ed  vmovaps [rsp+0xB0], xmm12
000071709abde1f6  vmovaps [rsp+0xC0], xmm13
000071709abde1ff  vmovaps [rsp+0xD0], xmm14
000071709abde208  vmovaps [rsp+0xE0], xmm15
000071709abde211  sub rsp, 0x30
000071709abde215  movaps [rsp], xmm1
000071709abde219  movaps [rsp+0x10], xmm5
000071709abde21e  movaps [rsp+0x20], xmm4
000071709abde223  lea rdi, [rsp]
000071709abde227  mov esi, 0x00
000071709abde22c  mov rax, 0x60B9B2ABC530
000071709abde236  call rax
000071709abde238  movaps xmm1, [rsp]
000071709abde23c  add rsp, 0x30
000071709abde240  vmovaps xmm0, [rsp]
000071709abde245  vmovaps xmm2, [rsp+0x10]
000071709abde24b  vmovaps xmm3, [rsp+0x20]
000071709abde251  vmovaps xmm4, [rsp+0x30]
000071709abde257  vmovaps xmm5, [rsp+0x40]
000071709abde25d  vmovaps xmm6, [rsp+0x50]
000071709abde263  vmovaps xmm7, [rsp+0x60]
000071709abde269  vmovaps xmm8, [rsp+0x70]
000071709abde26f  vmovaps xmm9, [rsp+0x80]
000071709abde278  vmovaps xmm10, [rsp+0x90]
000071709abde281  vmovaps xmm11, [rsp+0xA0]
000071709abde28a  vmovaps xmm12, [rsp+0xB0]
000071709abde293  vmovaps xmm13, [rsp+0xC0]
000071709abde29c  vmovaps xmm14, [rsp+0xD0]
000071709abde2a5  vmovaps xmm15, [rsp+0xE0]
000071709abde2ae  add rsp, 0xF0
000071709abde2b5  pop r11
000071709abde2b7  pop r10
000071709abde2b9  pop r9
000071709abde2bb  pop r8
000071709abde2bd  pop rsi
000071709abde2be  pop rdi
000071709abde2bf  pop rdx
000071709abde2c0  pop rcx
000071709abde2c1  pop rax
000071709abde2c2  add rsp, 0x08
000071709abde2c6  jmp 0x000071709ABDC0B9
000071709abde2cb  sub rsp, 0x08
000071709abde2cf  push rax
000071709abde2d0  push rcx
000071709abde2d1  push rdx
000071709abde2d2  push rdi
000071709abde2d3  push rsi
000071709abde2d4  push r8
000071709abde2d6  push r9
000071709abde2d8  push r10
000071709abde2da  push r11
000071709abde2dc  sub rsp, 0xF0
000071709abde2e3  vmovaps [rsp], xmm0
000071709abde2e8  vmovaps [rsp+0x10], xmm1
000071709abde2ee  vmovaps [rsp+0x20], xmm2
000071709abde2f4  vmovaps [rsp+0x30], xmm3
000071709abde2fa  vmovaps [rsp+0x40], xmm5
000071709abde300  vmovaps [rsp+0x50], xmm6
000071709abde306  vmovaps [rsp+0x60], xmm7
000071709abde30c  vmovaps [rsp+0x70], xmm8
000071709abde312  vmovaps [rsp+0x80], xmm9
000071709abde31b  vmovaps [rsp+0x90], xmm10
000071709abde324  vmovaps [rsp+0xA0], xmm11
000071709abde32d  vmovaps [rsp+0xB0], xmm12
000071709abde336  vmovaps [rsp+0xC0], xmm13
000071709abde33f  vmovaps [rsp+0xD0], xmm14
000071709abde348  vmovaps [rsp+0xE0], xmm15
000071709abde351  sub rsp, 0x30
000071709abde355  movaps [rsp], xmm4
000071709abde359  movaps [rsp+0x10], xmm3
000071709abde35e  movaps [rsp+0x20], xmm5
000071709abde363  lea rdi, [rsp]
000071709abde367  mov esi, 0x00
000071709abde36c  mov rax, 0x60B9B2ABC530
000071709abde376  call rax
000071709abde378  movaps xmm4, [rsp]
000071709abde37c  add rsp, 0x30
000071709abde380  vmovaps xmm0, [rsp]
000071709abde385  vmovaps xmm1, [rsp+0x10]
000071709abde38b  vmovaps xmm2, [rsp+0x20]
000071709abde391  vmovaps xmm3, [rsp+0x30]
000071709abde397  vmovaps xmm5, [rsp+0x40]
000071709abde39d  vmovaps xmm6, [rsp+0x50]
000071709abde3a3  vmovaps xmm7, [rsp+0x60]
000071709abde3a9  vmovaps xmm8, [rsp+0x70]
000071709abde3af  vmovaps xmm9, [rsp+0x80]
000071709abde3b8  vmovaps xmm10, [rsp+0x90]
000071709abde3c1  vmovaps xmm11, [rsp+0xA0]
000071709abde3ca  vmovaps xmm12, [rsp+0xB0]
000071709abde3d3  vmovaps xmm13, [rsp+0xC0]
000071709abde3dc  vmovaps xmm14, [rsp+0xD0]
000071709abde3e5  vmovaps xmm15, [rsp+0xE0]
000071709abde3ee  add rsp, 0xF0
000071709abde3f5  pop r11
000071709abde3f7  pop r10
000071709abde3f9  pop r9
000071709abde3fb  pop r8
000071709abde3fd  pop rsi
000071709abde3fe  pop rdi
000071709abde3ff  pop rdx
000071709abde400  pop rcx
000071709abde401  pop rax
000071709abde402  add rsp, 0x08
000071709abde406  jmp 0x000071709ABDC107
000071709abde40b  call 0x000071709AAB52F0
000071709abde410  jmp 0x000071709ABDC114
000071709abde415  sub rsp, 0x08
000071709abde419  push rax
000071709abde41a  push rcx
000071709abde41b  push rdx
000071709abde41c  push rdi
000071709abde41d  push rsi
000071709abde41e  push r8
000071709abde420  push r9
000071709abde422  push r10
000071709abde424  push r11
000071709abde426  sub rsp, 0xF0
000071709abde42d  vmovaps [rsp], xmm0
000071709abde432  vmovaps [rsp+0x10], xmm1
000071709abde438  vmovaps [rsp+0x20], xmm2
000071709abde43e  vmovaps [rsp+0x30], xmm3
000071709abde444  vmovaps [rsp+0x40], xmm4
000071709abde44a  vmovaps [rsp+0x50], xmm6
000071709abde450  vmovaps [rsp+0x60], xmm7
000071709abde456  vmovaps [rsp+0x70], xmm8
000071709abde45c  vmovaps [rsp+0x80], xmm9
000071709abde465  vmovaps [rsp+0x90], xmm10
000071709abde46e  vmovaps [rsp+0xA0], xmm11
000071709abde477  vmovaps [rsp+0xB0], xmm12
000071709abde480  vmovaps [rsp+0xC0], xmm13
000071709abde489  vmovaps [rsp+0xD0], xmm14
000071709abde492  vmovaps [rsp+0xE0], xmm15
000071709abde49b  sub rsp, 0x30
000071709abde49f  movaps [rsp], xmm5
000071709abde4a3  movaps [rsp+0x10], xmm6
000071709abde4a8  movaps [rsp+0x20], xmm3
000071709abde4ad  lea rdi, [rsp]
000071709abde4b1  mov esi, 0x00
000071709abde4b6  mov rax, 0x60B9B2ABC530
000071709abde4c0  call rax
000071709abde4c2  movaps xmm5, [rsp]
000071709abde4c6  add rsp, 0x30
000071709abde4ca  vmovaps xmm0, [rsp]
000071709abde4cf  vmovaps xmm1, [rsp+0x10]
000071709abde4d5  vmovaps xmm2, [rsp+0x20]
000071709abde4db  vmovaps xmm3, [rsp+0x30]
000071709abde4e1  vmovaps xmm4, [rsp+0x40]
000071709abde4e7  vmovaps xmm6, [rsp+0x50]
000071709abde4ed  vmovaps xmm7, [rsp+0x60]
000071709abde4f3  vmovaps xmm8, [rsp+0x70]
000071709abde4f9  vmovaps xmm9, [rsp+0x80]
000071709abde502  vmovaps xmm10, [rsp+0x90]
000071709abde50b  vmovaps xmm11, [rsp+0xA0]
000071709abde514  vmovaps xmm12, [rsp+0xB0]
000071709abde51d  vmovaps xmm13, [rsp+0xC0]
000071709abde526  vmovaps xmm14, [rsp+0xD0]
000071709abde52f  vmovaps xmm15, [rsp+0xE0]
000071709abde538  add rsp, 0xF0
000071709abde53f  pop r11
000071709abde541  pop r10
000071709abde543  pop r9
000071709abde545  pop r8
000071709abde547  pop rsi
000071709abde548  pop rdi
000071709abde549  pop rdx
000071709abde54a  pop rcx
000071709abde54b  pop rax
000071709abde54c  add rsp, 0x08
000071709abde550  jmp 0x000071709ABDC13A
000071709abde555  sub rsp, 0x08
000071709abde559  push rax
000071709abde55a  push rcx
000071709abde55b  push rdx
000071709abde55c  push rdi
000071709abde55d  push rsi
000071709abde55e  push r8
000071709abde560  push r9
000071709abde562  push r10
000071709abde564  push r11
000071709abde566  sub rsp, 0xF0
000071709abde56d  vmovaps [rsp], xmm0
000071709abde572  vmovaps [rsp+0x10], xmm1
000071709abde578  vmovaps [rsp+0x20], xmm2
000071709abde57e  vmovaps [rsp+0x30], xmm3
000071709abde584  vmovaps [rsp+0x40], xmm4
000071709abde58a  vmovaps [rsp+0x50], xmm5
000071709abde590  vmovaps [rsp+0x60], xmm7
000071709abde596  vmovaps [rsp+0x70], xmm8
000071709abde59c  vmovaps [rsp+0x80], xmm9
000071709abde5a5  vmovaps [rsp+0x90], xmm10
000071709abde5ae  vmovaps [rsp+0xA0], xmm11
000071709abde5b7  vmovaps [rsp+0xB0], xmm12
000071709abde5c0  vmovaps [rsp+0xC0], xmm13
000071709abde5c9  vmovaps [rsp+0xD0], xmm14
000071709abde5d2  vmovaps [rsp+0xE0], xmm15
000071709abde5db  sub rsp, 0x30
000071709abde5df  movaps [rsp], xmm6
000071709abde5e3  movaps [rsp+0x10], xmm9
000071709abde5e9  movaps [rsp+0x20], xmm1
000071709abde5ee  lea rdi, [rsp]
000071709abde5f2  mov esi, 0x00
000071709abde5f7  mov rax, 0x60B9B2ABC530
000071709abde601  call rax
000071709abde603  movaps xmm6, [rsp]
000071709abde607  add rsp, 0x30
000071709abde60b  vmovaps xmm0, [rsp]
000071709abde610  vmovaps xmm1, [rsp+0x10]
000071709abde616  vmovaps xmm2, [rsp+0x20]
000071709abde61c  vmovaps xmm3, [rsp+0x30]
000071709abde622  vmovaps xmm4, [rsp+0x40]
000071709abde628  vmovaps xmm5, [rsp+0x50]
000071709abde62e  vmovaps xmm7, [rsp+0x60]
000071709abde634  vmovaps xmm8, [rsp+0x70]
000071709abde63a  vmovaps xmm9, [rsp+0x80]
000071709abde643  vmovaps xmm10, [rsp+0x90]
000071709abde64c  vmovaps xmm11, [rsp+0xA0]
000071709abde655  vmovaps xmm12, [rsp+0xB0]
000071709abde65e  vmovaps xmm13, [rsp+0xC0]
000071709abde667  vmovaps xmm14, [rsp+0xD0]
000071709abde670  vmovaps xmm15, [rsp+0xE0]
000071709abde679  add rsp, 0xF0
000071709abde680  pop r11
000071709abde682  pop r10
000071709abde684  pop r9
000071709abde686  pop r8
000071709abde688  pop rsi
000071709abde689  pop rdi
000071709abde68a  pop rdx
000071709abde68b  pop rcx
000071709abde68c  pop rax
000071709abde68d  add rsp, 0x08
000071709abde691  jmp 0x000071709ABDC15E
000071709abde696  sub rsp, 0x08
000071709abde69a  push rax
000071709abde69b  push rcx
000071709abde69c  push rdx
000071709abde69d  push rdi
000071709abde69e  push rsi
000071709abde69f  push r8
000071709abde6a1  push r9
000071709abde6a3  push r10
000071709abde6a5  push r11
000071709abde6a7  sub rsp, 0xF0
000071709abde6ae  vmovaps [rsp], xmm0
000071709abde6b3  vmovaps [rsp+0x10], xmm1
000071709abde6b9  vmovaps [rsp+0x20], xmm2
000071709abde6bf  vmovaps [rsp+0x30], xmm3
000071709abde6c5  vmovaps [rsp+0x40], xmm4
000071709abde6cb  vmovaps [rsp+0x50], xmm5
000071709abde6d1  vmovaps [rsp+0x60], xmm6
000071709abde6d7  vmovaps [rsp+0x70], xmm7
000071709abde6dd  vmovaps [rsp+0x80], xmm8
000071709abde6e6  vmovaps [rsp+0x90], xmm10
000071709abde6ef  vmovaps [rsp+0xA0], xmm11
000071709abde6f8  vmovaps [rsp+0xB0], xmm12
000071709abde701  vmovaps [rsp+0xC0], xmm13
000071709abde70a  vmovaps [rsp+0xD0], xmm14
000071709abde713  vmovaps [rsp+0xE0], xmm15
000071709abde71c  sub rsp, 0x30
000071709abde720  movaps [rsp], xmm9
000071709abde725  movaps [rsp+0x10], xmm3
000071709abde72a  movaps [rsp+0x20], xmm1
000071709abde72f  lea rdi, [rsp]
000071709abde733  mov esi, 0x00
000071709abde738  mov rax, 0x60B9B2ABC530
000071709abde742  call rax
000071709abde744  movaps xmm9, [rsp]
000071709abde749  add rsp, 0x30
000071709abde74d  vmovaps xmm0, [rsp]
000071709abde752  vmovaps xmm1, [rsp+0x10]
000071709abde758  vmovaps xmm2, [rsp+0x20]
000071709abde75e  vmovaps xmm3, [rsp+0x30]
000071709abde764  vmovaps xmm4, [rsp+0x40]
000071709abde76a  vmovaps xmm5, [rsp+0x50]
000071709abde770  vmovaps xmm6, [rsp+0x60]
000071709abde776  vmovaps xmm7, [rsp+0x70]
000071709abde77c  vmovaps xmm8, [rsp+0x80]
000071709abde785  vmovaps xmm10, [rsp+0x90]
000071709abde78e  vmovaps xmm11, [rsp+0xA0]
000071709abde797  vmovaps xmm12, [rsp+0xB0]
000071709abde7a0  vmovaps xmm13, [rsp+0xC0]
000071709abde7a9  vmovaps xmm14, [rsp+0xD0]
000071709abde7b2  vmovaps xmm15, [rsp+0xE0]
000071709abde7bb  add rsp, 0xF0
000071709abde7c2  pop r11
000071709abde7c4  pop r10
000071709abde7c6  pop r9
000071709abde7c8  pop r8
000071709abde7ca  pop rsi
000071709abde7cb  pop rdi
000071709abde7cc  pop rdx
000071709abde7cd  pop rcx
000071709abde7ce  pop rax
000071709abde7cf  add rsp, 0x08
000071709abde7d3  jmp 0x000071709ABDC1AA
000071709abde7d8  call 0x000071709AAB52F0
000071709abde7dd  jmp 0x000071709ABDC1B7
000071709abde7e2  sub rsp, 0x08
000071709abde7e6  push rax
000071709abde7e7  push rcx
000071709abde7e8  push rdx
000071709abde7e9  push rdi
000071709abde7ea  push rsi
000071709abde7eb  push r8
000071709abde7ed  push r9
000071709abde7ef  push r10
000071709abde7f1  push r11
000071709abde7f3  sub rsp, 0xF0
000071709abde7fa  vmovaps [rsp], xmm0
000071709abde7ff  vmovaps [rsp+0x10], xmm1
000071709abde805  vmovaps [rsp+0x20], xmm2
000071709abde80b  vmovaps [rsp+0x30], xmm3
000071709abde811  vmovaps [rsp+0x40], xmm4
000071709abde817  vmovaps [rsp+0x50], xmm5
000071709abde81d  vmovaps [rsp+0x60], xmm6
000071709abde823  vmovaps [rsp+0x70], xmm7
000071709abde829  vmovaps [rsp+0x80], xmm8
000071709abde832  vmovaps [rsp+0x90], xmm9
000071709abde83b  vmovaps [rsp+0xA0], xmm10
000071709abde844  vmovaps [rsp+0xB0], xmm11
000071709abde84d  vmovaps [rsp+0xC0], xmm12
000071709abde856  vmovaps [rsp+0xD0], xmm13
000071709abde85f  vmovaps [rsp+0xE0], xmm14
000071709abde868  sub rsp, 0x30
000071709abde86c  movaps [rsp], xmm15
000071709abde871  movaps [rsp+0x10], xmm3
000071709abde876  movaps [rsp+0x20], xmm7
000071709abde87b  lea rdi, [rsp]
000071709abde87f  mov esi, 0x00
000071709abde884  mov rax, 0x60B9B2ABC530
000071709abde88e  call rax
000071709abde890  movaps xmm15, [rsp]
000071709abde895  add rsp, 0x30
000071709abde899  vmovaps xmm0, [rsp]
000071709abde89e  vmovaps xmm1, [rsp+0x10]
000071709abde8a4  vmovaps xmm2, [rsp+0x20]
000071709abde8aa  vmovaps xmm3, [rsp+0x30]
000071709abde8b0  vmovaps xmm4, [rsp+0x40]
000071709abde8b6  vmovaps xmm5, [rsp+0x50]
000071709abde8bc  vmovaps xmm6, [rsp+0x60]
000071709abde8c2  vmovaps xmm7, [rsp+0x70]
000071709abde8c8  vmovaps xmm8, [rsp+0x80]
000071709abde8d1  vmovaps xmm9, [rsp+0x90]
000071709abde8da  vmovaps xmm10, [rsp+0xA0]
000071709abde8e3  vmovaps xmm11, [rsp+0xB0]
000071709abde8ec  vmovaps xmm12, [rsp+0xC0]
000071709abde8f5  vmovaps xmm13, [rsp+0xD0]
000071709abde8fe  vmovaps xmm14, [rsp+0xE0]
000071709abde907  add rsp, 0xF0
000071709abde90e  pop r11
000071709abde910  pop r10
000071709abde912  pop r9
000071709abde914  pop r8
000071709abde916  pop rsi
000071709abde917  pop rdi
000071709abde918  pop rdx
000071709abde919  pop rcx
000071709abde91a  pop rax
000071709abde91b  add rsp, 0x08
000071709abde91f  jmp 0x000071709ABDC1E3
000071709abde924  sub rsp, 0x08
000071709abde928  push rax
000071709abde929  push rcx
000071709abde92a  push rdx
000071709abde92b  push rdi
000071709abde92c  push rsi
000071709abde92d  push r8
000071709abde92f  push r9
000071709abde931  push r10
000071709abde933  push r11
000071709abde935  sub rsp, 0xF0
000071709abde93c  vmovaps [rsp], xmm0
000071709abde941  vmovaps [rsp+0x10], xmm1
000071709abde947  vmovaps [rsp+0x20], xmm2
000071709abde94d  vmovaps [rsp+0x30], xmm4
000071709abde953  vmovaps [rsp+0x40], xmm5
000071709abde959  vmovaps [rsp+0x50], xmm6
000071709abde95f  vmovaps [rsp+0x60], xmm7
000071709abde965  vmovaps [rsp+0x70], xmm8
000071709abde96b  vmovaps [rsp+0x80], xmm9
000071709abde974  vmovaps [rsp+0x90], xmm10
000071709abde97d  vmovaps [rsp+0xA0], xmm11
000071709abde986  vmovaps [rsp+0xB0], xmm12
000071709abde98f  vmovaps [rsp+0xC0], xmm13
000071709abde998  vmovaps [rsp+0xD0], xmm14
000071709abde9a1  vmovaps [rsp+0xE0], xmm15
000071709abde9aa  sub rsp, 0x30
000071709abde9ae  movaps [rsp], xmm3
000071709abde9b2  movaps [rsp+0x10], xmm1
000071709abde9b7  movaps [rsp+0x20], xmm15
000071709abde9bd  lea rdi, [rsp]
000071709abde9c1  mov esi, 0x00
000071709abde9c6  mov rax, 0x60B9B2ABC530
000071709abde9d0  call rax
000071709abde9d2  movaps xmm3, [rsp]
000071709abde9d6  add rsp, 0x30
000071709abde9da  vmovaps xmm0, [rsp]
000071709abde9df  vmovaps xmm1, [rsp+0x10]
000071709abde9e5  vmovaps xmm2, [rsp+0x20]
000071709abde9eb  vmovaps xmm4, [rsp+0x30]
000071709abde9f1  vmovaps xmm5, [rsp+0x40]
000071709abde9f7  vmovaps xmm6, [rsp+0x50]
000071709abde9fd  vmovaps xmm7, [rsp+0x60]
000071709abdea03  vmovaps xmm8, [rsp+0x70]
000071709abdea09  vmovaps xmm9, [rsp+0x80]
000071709abdea12  vmovaps xmm10, [rsp+0x90]
000071709abdea1b  vmovaps xmm11, [rsp+0xA0]
000071709abdea24  vmovaps xmm12, [rsp+0xB0]
000071709abdea2d  vmovaps xmm13, [rsp+0xC0]
000071709abdea36  vmovaps xmm14, [rsp+0xD0]
000071709abdea3f  vmovaps xmm15, [rsp+0xE0]
000071709abdea48  add rsp, 0xF0
000071709abdea4f  pop r11
000071709abdea51  pop r10
000071709abdea53  pop r9
000071709abdea55  pop r8
000071709abdea57  pop rsi
000071709abdea58  pop rdi
000071709abdea59  pop rdx
000071709abdea5a  pop rcx
000071709abdea5b  pop rax
000071709abdea5c  add rsp, 0x08
000071709abdea60  jmp 0x000071709ABDC272
000071709abdea65  call 0x000071709AAB52F0
000071709abdea6a  jmp 0x000071709ABDC27C
000071709abdea6f  sub rsp, 0x08
000071709abdea73  push rax
000071709abdea74  push rcx
000071709abdea75  push rdx
000071709abdea76  push rdi
000071709abdea77  push rsi
000071709abdea78  push r8
000071709abdea7a  push r9
000071709abdea7c  push r10
000071709abdea7e  push r11
000071709abdea80  sub rsp, 0xF0
000071709abdea87  vmovaps [rsp], xmm0
000071709abdea8c  vmovaps [rsp+0x10], xmm1
000071709abdea92  vmovaps [rsp+0x20], xmm2
000071709abdea98  vmovaps [rsp+0x30], xmm3
000071709abdea9e  vmovaps [rsp+0x40], xmm4
000071709abdeaa4  vmovaps [rsp+0x50], xmm5
000071709abdeaaa  vmovaps [rsp+0x60], xmm6
000071709abdeab0  vmovaps [rsp+0x70], xmm7
000071709abdeab6  vmovaps [rsp+0x80], xmm8
000071709abdeabf  vmovaps [rsp+0x90], xmm9
000071709abdeac8  vmovaps [rsp+0xA0], xmm10
000071709abdead1  vmovaps [rsp+0xB0], xmm11
000071709abdeada  vmovaps [rsp+0xC0], xmm12
000071709abdeae3  vmovaps [rsp+0xD0], xmm13
000071709abdeaec  vmovaps [rsp+0xE0], xmm14
000071709abdeaf5  sub rsp, 0x30
000071709abdeaf9  movaps [rsp], xmm15
000071709abdeafe  movaps [rsp+0x10], xmm14
000071709abdeb04  movaps [rsp+0x20], xmm4
000071709abdeb09  lea rdi, [rsp]
000071709abdeb0d  mov esi, 0x00
000071709abdeb12  mov rax, 0x60B9B2ABC530
000071709abdeb1c  call rax
000071709abdeb1e  movaps xmm15, [rsp]
000071709abdeb23  add rsp, 0x30
000071709abdeb27  vmovaps xmm0, [rsp]
000071709abdeb2c  vmovaps xmm1, [rsp+0x10]
000071709abdeb32  vmovaps xmm2, [rsp+0x20]
000071709abdeb38  vmovaps xmm3, [rsp+0x30]
000071709abdeb3e  vmovaps xmm4, [rsp+0x40]
000071709abdeb44  vmovaps xmm5, [rsp+0x50]
000071709abdeb4a  vmovaps xmm6, [rsp+0x60]
000071709abdeb50  vmovaps xmm7, [rsp+0x70]
000071709abdeb56  vmovaps xmm8, [rsp+0x80]
000071709abdeb5f  vmovaps xmm9, [rsp+0x90]
000071709abdeb68  vmovaps xmm10, [rsp+0xA0]
000071709abdeb71  vmovaps xmm11, [rsp+0xB0]
000071709abdeb7a  vmovaps xmm12, [rsp+0xC0]
000071709abdeb83  vmovaps xmm13, [rsp+0xD0]
000071709abdeb8c  vmovaps xmm14, [rsp+0xE0]
000071709abdeb95  add rsp, 0xF0
000071709abdeb9c  pop r11
000071709abdeb9e  pop r10
000071709abdeba0  pop r9
000071709abdeba2  pop r8
000071709abdeba4  pop rsi
000071709abdeba5  pop rdi
000071709abdeba6  pop rdx
000071709abdeba7  pop rcx
000071709abdeba8  pop rax
000071709abdeba9  add rsp, 0x08
000071709abdebad  jmp 0x000071709ABDC2AA
000071709abdebb2  sub rsp, 0x08
000071709abdebb6  push rax
000071709abdebb7  push rcx
000071709abdebb8  push rdx
000071709abdebb9  push rdi
000071709abdebba  push rsi
000071709abdebbb  push r8
000071709abdebbd  push r9
000071709abdebbf  push r10
000071709abdebc1  push r11
000071709abdebc3  sub rsp, 0xF0
000071709abdebca  vmovaps [rsp], xmm0
000071709abdebcf  vmovaps [rsp+0x10], xmm1
000071709abdebd5  vmovaps [rsp+0x20], xmm2
000071709abdebdb  vmovaps [rsp+0x30], xmm3
000071709abdebe1  vmovaps [rsp+0x40], xmm4
000071709abdebe7  vmovaps [rsp+0x50], xmm5
000071709abdebed  vmovaps [rsp+0x60], xmm6
000071709abdebf3  vmovaps [rsp+0x70], xmm7
000071709abdebf9  vmovaps [rsp+0x80], xmm8
000071709abdec02  vmovaps [rsp+0x90], xmm9
000071709abdec0b  vmovaps [rsp+0xA0], xmm10
000071709abdec14  vmovaps [rsp+0xB0], xmm11
000071709abdec1d  vmovaps [rsp+0xC0], xmm12
000071709abdec26  vmovaps [rsp+0xD0], xmm13
000071709abdec2f  vmovaps [rsp+0xE0], xmm15
000071709abdec38  sub rsp, 0x30
000071709abdec3c  movaps [rsp], xmm14
000071709abdec41  movaps [rsp+0x10], xmm2
000071709abdec46  movaps [rsp+0x20], xmm1
000071709abdec4b  lea rdi, [rsp]
000071709abdec4f  mov esi, 0x00
000071709abdec54  mov rax, 0x60B9B2ABC530
000071709abdec5e  call rax
000071709abdec60  movaps xmm14, [rsp]
000071709abdec65  add rsp, 0x30
000071709abdec69  vmovaps xmm0, [rsp]
000071709abdec6e  vmovaps xmm1, [rsp+0x10]
000071709abdec74  vmovaps xmm2, [rsp+0x20]
000071709abdec7a  vmovaps xmm3, [rsp+0x30]
000071709abdec80  vmovaps xmm4, [rsp+0x40]
000071709abdec86  vmovaps xmm5, [rsp+0x50]
000071709abdec8c  vmovaps xmm6, [rsp+0x60]
000071709abdec92  vmovaps xmm7, [rsp+0x70]
000071709abdec98  vmovaps xmm8, [rsp+0x80]
000071709abdeca1  vmovaps xmm9, [rsp+0x90]
000071709abdecaa  vmovaps xmm10, [rsp+0xA0]
000071709abdecb3  vmovaps xmm11, [rsp+0xB0]
000071709abdecbc  vmovaps xmm12, [rsp+0xC0]
000071709abdecc5  vmovaps xmm13, [rsp+0xD0]
000071709abdecce  vmovaps xmm15, [rsp+0xE0]
000071709abdecd7  add rsp, 0xF0
000071709abdecde  pop r11
000071709abdece0  pop r10
000071709abdece2  pop r9
000071709abdece4  pop r8
000071709abdece6  pop rsi
000071709abdece7  pop rdi
000071709abdece8  pop rdx
000071709abdece9  pop rcx
000071709abdecea  pop rax
000071709abdeceb  add rsp, 0x08
000071709abdecef  jmp 0x000071709ABDC2D0
000071709abdecf4  sub rsp, 0x08
000071709abdecf8  push rax
000071709abdecf9  push rcx
000071709abdecfa  push rdx
000071709abdecfb  push rdi
000071709abdecfc  push rsi
000071709abdecfd  push r8
000071709abdecff  push r9
000071709abded01  push r10
000071709abded03  push r11
000071709abded05  sub rsp, 0xF0
000071709abded0c  vmovaps [rsp], xmm0
000071709abded11  vmovaps [rsp+0x10], xmm2
000071709abded17  vmovaps [rsp+0x20], xmm3
000071709abded1d  vmovaps [rsp+0x30], xmm4
000071709abded23  vmovaps [rsp+0x40], xmm5
000071709abded29  vmovaps [rsp+0x50], xmm6
000071709abded2f  vmovaps [rsp+0x60], xmm7
000071709abded35  vmovaps [rsp+0x70], xmm8
000071709abded3b  vmovaps [rsp+0x80], xmm9
000071709abded44  vmovaps [rsp+0x90], xmm10
000071709abded4d  vmovaps [rsp+0xA0], xmm11
000071709abded56  vmovaps [rsp+0xB0], xmm12
000071709abded5f  vmovaps [rsp+0xC0], xmm13
000071709abded68  vmovaps [rsp+0xD0], xmm14
000071709abded71  vmovaps [rsp+0xE0], xmm15
000071709abded7a  sub rsp, 0x30
000071709abded7e  movaps [rsp], xmm1
000071709abded82  movaps [rsp+0x10], xmm4
000071709abded87  movaps [rsp+0x20], xmm9
000071709abded8d  lea rdi, [rsp]
000071709abded91  mov esi, 0x00
000071709abded96  mov rax, 0x60B9B2ABC530
000071709abdeda0  call rax
000071709abdeda2  movaps xmm1, [rsp]
000071709abdeda6  add rsp, 0x30
000071709abdedaa  vmovaps xmm0, [rsp]
000071709abdedaf  vmovaps xmm2, [rsp+0x10]
000071709abdedb5  vmovaps xmm3, [rsp+0x20]
000071709abdedbb  vmovaps xmm4, [rsp+0x30]
000071709abdedc1  vmovaps xmm5, [rsp+0x40]
000071709abdedc7  vmovaps xmm6, [rsp+0x50]
000071709abdedcd  vmovaps xmm7, [rsp+0x60]
000071709abdedd3  vmovaps xmm8, [rsp+0x70]
000071709abdedd9  vmovaps xmm9, [rsp+0x80]
000071709abdede2  vmovaps xmm10, [rsp+0x90]
000071709abdedeb  vmovaps xmm11, [rsp+0xA0]
000071709abdedf4  vmovaps xmm12, [rsp+0xB0]
000071709abdedfd  vmovaps xmm13, [rsp+0xC0]
000071709abdee06  vmovaps xmm14, [rsp+0xD0]
000071709abdee0f  vmovaps xmm15, [rsp+0xE0]
000071709abdee18  add rsp, 0xF0
000071709abdee1f  pop r11
000071709abdee21  pop r10
000071709abdee23  pop r9
000071709abdee25  pop r8
000071709abdee27  pop rsi
000071709abdee28  pop rdi
000071709abdee29  pop rdx
000071709abdee2a  pop rcx
000071709abdee2b  pop rax
000071709abdee2c  add rsp, 0x08
000071709abdee30  jmp 0x000071709ABDC2EE
000071709abdee35  sub rsp, 0x08
000071709abdee39  push rax
000071709abdee3a  push rcx
000071709abdee3b  push rdx
000071709abdee3c  push rdi
000071709abdee3d  push rsi
000071709abdee3e  push r8
000071709abdee40  push r9
000071709abdee42  push r10
000071709abdee44  push r11
000071709abdee46  sub rsp, 0xF0
000071709abdee4d  vmovaps [rsp], xmm0
000071709abdee52  vmovaps [rsp+0x10], xmm1
000071709abdee58  vmovaps [rsp+0x20], xmm2
000071709abdee5e  vmovaps [rsp+0x30], xmm3
000071709abdee64  vmovaps [rsp+0x40], xmm5
000071709abdee6a  vmovaps [rsp+0x50], xmm6
000071709abdee70  vmovaps [rsp+0x60], xmm7
000071709abdee76  vmovaps [rsp+0x70], xmm8
000071709abdee7c  vmovaps [rsp+0x80], xmm9
000071709abdee85  vmovaps [rsp+0x90], xmm10
000071709abdee8e  vmovaps [rsp+0xA0], xmm11
000071709abdee97  vmovaps [rsp+0xB0], xmm12
000071709abdeea0  vmovaps [rsp+0xC0], xmm13
000071709abdeea9  vmovaps [rsp+0xD0], xmm14
000071709abdeeb2  vmovaps [rsp+0xE0], xmm15
000071709abdeebb  sub rsp, 0x30
000071709abdeebf  movaps [rsp], xmm4
000071709abdeec3  movaps [rsp+0x10], xmm2
000071709abdeec8  movaps [rsp+0x20], xmm9
000071709abdeece  lea rdi, [rsp]
000071709abdeed2  mov esi, 0x00
000071709abdeed7  mov rax, 0x60B9B2ABC530
000071709abdeee1  call rax
000071709abdeee3  movaps xmm4, [rsp]
000071709abdeee7  add rsp, 0x30
000071709abdeeeb  vmovaps xmm0, [rsp]
000071709abdeef0  vmovaps xmm1, [rsp+0x10]
000071709abdeef6  vmovaps xmm2, [rsp+0x20]
000071709abdeefc  vmovaps xmm3, [rsp+0x30]
000071709abdef02  vmovaps xmm5, [rsp+0x40]
000071709abdef08  vmovaps xmm6, [rsp+0x50]
000071709abdef0e  vmovaps xmm7, [rsp+0x60]
000071709abdef14  vmovaps xmm8, [rsp+0x70]
000071709abdef1a  vmovaps xmm9, [rsp+0x80]
000071709abdef23  vmovaps xmm10, [rsp+0x90]
000071709abdef2c  vmovaps xmm11, [rsp+0xA0]
000071709abdef35  vmovaps xmm12, [rsp+0xB0]
000071709abdef3e  vmovaps xmm13, [rsp+0xC0]
000071709abdef47  vmovaps xmm14, [rsp+0xD0]
000071709abdef50  vmovaps xmm15, [rsp+0xE0]
000071709abdef59  add rsp, 0xF0
000071709abdef60  pop r11
000071709abdef62  pop r10
000071709abdef64  pop r9
000071709abdef66  pop r8
000071709abdef68  pop rsi
000071709abdef69  pop rdi
000071709abdef6a  pop rdx
000071709abdef6b  pop rcx
000071709abdef6c  pop rax
000071709abdef6d  add rsp, 0x08
000071709abdef71  jmp 0x000071709ABDC31E
000071709abdef76  sub rsp, 0x08
000071709abdef7a  push rax
000071709abdef7b  push rcx
000071709abdef7c  push rdx
000071709abdef7d  push rdi
000071709abdef7e  push rsi
000071709abdef7f  push r8
000071709abdef81  push r9
000071709abdef83  push r10
000071709abdef85  push r11
000071709abdef87  sub rsp, 0xF0
000071709abdef8e  vmovaps [rsp], xmm0
000071709abdef93  vmovaps [rsp+0x10], xmm1
000071709abdef99  vmovaps [rsp+0x20], xmm2
000071709abdef9f  vmovaps [rsp+0x30], xmm3
000071709abdefa5  vmovaps [rsp+0x40], xmm4
000071709abdefab  vmovaps [rsp+0x50], xmm5
000071709abdefb1  vmovaps [rsp+0x60], xmm6
000071709abdefb7  vmovaps [rsp+0x70], xmm7
000071709abdefbd  vmovaps [rsp+0x80], xmm8
000071709abdefc6  vmovaps [rsp+0x90], xmm10
000071709abdefcf  vmovaps [rsp+0xA0], xmm11
000071709abdefd8  vmovaps [rsp+0xB0], xmm12
000071709abdefe1  vmovaps [rsp+0xC0], xmm13
000071709abdefea  vmovaps [rsp+0xD0], xmm14
000071709abdeff3  vmovaps [rsp+0xE0], xmm15
000071709abdeffc  sub rsp, 0x30
000071709abdf000  movaps [rsp], xmm9
000071709abdf005  movaps [rsp+0x10], xmm2
000071709abdf00a  movaps [rsp+0x20], xmm1
000071709abdf00f  lea rdi, [rsp]
000071709abdf013  mov esi, 0x00
000071709abdf018  mov rax, 0x60B9B2ABC530
000071709abdf022  call rax
000071709abdf024  movaps xmm9, [rsp]
000071709abdf029  add rsp, 0x30
000071709abdf02d  vmovaps xmm0, [rsp]
000071709abdf032  vmovaps xmm1, [rsp+0x10]
000071709abdf038  vmovaps xmm2, [rsp+0x20]
000071709abdf03e  vmovaps xmm3, [rsp+0x30]
000071709abdf044  vmovaps xmm4, [rsp+0x40]
000071709abdf04a  vmovaps xmm5, [rsp+0x50]
000071709abdf050  vmovaps xmm6, [rsp+0x60]
000071709abdf056  vmovaps xmm7, [rsp+0x70]
000071709abdf05c  vmovaps xmm8, [rsp+0x80]
000071709abdf065  vmovaps xmm10, [rsp+0x90]
000071709abdf06e  vmovaps xmm11, [rsp+0xA0]
000071709abdf077  vmovaps xmm12, [rsp+0xB0]
000071709abdf080  vmovaps xmm13, [rsp+0xC0]
000071709abdf089  vmovaps xmm14, [rsp+0xD0]
000071709abdf092  vmovaps xmm15, [rsp+0xE0]
000071709abdf09b  add rsp, 0xF0
000071709abdf0a2  pop r11
000071709abdf0a4  pop r10
000071709abdf0a6  pop r9
000071709abdf0a8  pop r8
000071709abdf0aa  pop rsi
000071709abdf0ab  pop rdi
000071709abdf0ac  pop rdx
000071709abdf0ad  pop rcx
000071709abdf0ae  pop rax
000071709abdf0af  add rsp, 0x08
000071709abdf0b3  jmp 0x000071709ABDC354
000071709abdf0b8  sub rsp, 0x08
000071709abdf0bc  push rax
000071709abdf0bd  push rcx
000071709abdf0be  push rdx
000071709abdf0bf  push rdi
000071709abdf0c0  push rsi
000071709abdf0c1  push r8
000071709abdf0c3  push r9
000071709abdf0c5  push r10
000071709abdf0c7  push r11
000071709abdf0c9  sub rsp, 0xF0
000071709abdf0d0  vmovaps [rsp], xmm0
000071709abdf0d5  vmovaps [rsp+0x10], xmm2
000071709abdf0db  vmovaps [rsp+0x20], xmm3
000071709abdf0e1  vmovaps [rsp+0x30], xmm4
000071709abdf0e7  vmovaps [rsp+0x40], xmm5
000071709abdf0ed  vmovaps [rsp+0x50], xmm6
000071709abdf0f3  vmovaps [rsp+0x60], xmm7
000071709abdf0f9  vmovaps [rsp+0x70], xmm8
000071709abdf0ff  vmovaps [rsp+0x80], xmm9
000071709abdf108  vmovaps [rsp+0x90], xmm10
000071709abdf111  vmovaps [rsp+0xA0], xmm11
000071709abdf11a  vmovaps [rsp+0xB0], xmm12
000071709abdf123  vmovaps [rsp+0xC0], xmm13
000071709abdf12c  vmovaps [rsp+0xD0], xmm14
000071709abdf135  vmovaps [rsp+0xE0], xmm15
000071709abdf13e  sub rsp, 0x30
000071709abdf142  movaps [rsp], xmm1
000071709abdf146  movaps [rsp+0x10], xmm15
000071709abdf14c  movaps [rsp+0x20], xmm6
000071709abdf151  lea rdi, [rsp]
000071709abdf155  mov esi, 0x00
000071709abdf15a  mov rax, 0x60B9B2ABC530
000071709abdf164  call rax
000071709abdf166  movaps xmm1, [rsp]
000071709abdf16a  add rsp, 0x30
000071709abdf16e  vmovaps xmm0, [rsp]
000071709abdf173  vmovaps xmm2, [rsp+0x10]
000071709abdf179  vmovaps xmm3, [rsp+0x20]
000071709abdf17f  vmovaps xmm4, [rsp+0x30]
000071709abdf185  vmovaps xmm5, [rsp+0x40]
000071709abdf18b  vmovaps xmm6, [rsp+0x50]
000071709abdf191  vmovaps xmm7, [rsp+0x60]
000071709abdf197  vmovaps xmm8, [rsp+0x70]
000071709abdf19d  vmovaps xmm9, [rsp+0x80]
000071709abdf1a6  vmovaps xmm10, [rsp+0x90]
000071709abdf1af  vmovaps xmm11, [rsp+0xA0]
000071709abdf1b8  vmovaps xmm12, [rsp+0xB0]
000071709abdf1c1  vmovaps xmm13, [rsp+0xC0]
000071709abdf1ca  vmovaps xmm14, [rsp+0xD0]
000071709abdf1d3  vmovaps xmm15, [rsp+0xE0]
000071709abdf1dc  add rsp, 0xF0
000071709abdf1e3  pop r11
000071709abdf1e5  pop r10
000071709abdf1e7  pop r9
000071709abdf1e9  pop r8
000071709abdf1eb  pop rsi
000071709abdf1ec  pop rdi
000071709abdf1ed  pop rdx
000071709abdf1ee  pop rcx
000071709abdf1ef  pop rax
000071709abdf1f0  add rsp, 0x08
000071709abdf1f4  jmp 0x000071709ABDC375
000071709abdf1f9  sub rsp, 0x08
000071709abdf1fd  push rax
000071709abdf1fe  push rcx
000071709abdf1ff  push rdx
000071709abdf200  push rdi
000071709abdf201  push rsi
000071709abdf202  push r8
000071709abdf204  push r9
000071709abdf206  push r10
000071709abdf208  push r11
000071709abdf20a  sub rsp, 0xF0
000071709abdf211  vmovaps [rsp], xmm0
000071709abdf216  vmovaps [rsp+0x10], xmm1
000071709abdf21c  vmovaps [rsp+0x20], xmm2
000071709abdf222  vmovaps [rsp+0x30], xmm3
000071709abdf228  vmovaps [rsp+0x40], xmm4
000071709abdf22e  vmovaps [rsp+0x50], xmm5
000071709abdf234  vmovaps [rsp+0x60], xmm6
000071709abdf23a  vmovaps [rsp+0x70], xmm7
000071709abdf240  vmovaps [rsp+0x80], xmm8
000071709abdf249  vmovaps [rsp+0x90], xmm9
000071709abdf252  vmovaps [rsp+0xA0], xmm10
000071709abdf25b  vmovaps [rsp+0xB0], xmm11
000071709abdf264  vmovaps [rsp+0xC0], xmm12
000071709abdf26d  vmovaps [rsp+0xD0], xmm13
000071709abdf276  vmovaps [rsp+0xE0], xmm14
000071709abdf27f  sub rsp, 0x30
000071709abdf283  movaps [rsp], xmm15
000071709abdf288  movaps [rsp+0x10], xmm5
000071709abdf28d  movaps [rsp+0x20], xmm3
000071709abdf292  lea rdi, [rsp]
000071709abdf296  mov esi, 0x00
000071709abdf29b  mov rax, 0x60B9B2ABC530
000071709abdf2a5  call rax
000071709abdf2a7  movaps xmm15, [rsp]
000071709abdf2ac  add rsp, 0x30
000071709abdf2b0  vmovaps xmm0, [rsp]
000071709abdf2b5  vmovaps xmm1, [rsp+0x10]
000071709abdf2bb  vmovaps xmm2, [rsp+0x20]
000071709abdf2c1  vmovaps xmm3, [rsp+0x30]
000071709abdf2c7  vmovaps xmm4, [rsp+0x40]
000071709abdf2cd  vmovaps xmm5, [rsp+0x50]
000071709abdf2d3  vmovaps xmm6, [rsp+0x60]
000071709abdf2d9  vmovaps xmm7, [rsp+0x70]
000071709abdf2df  vmovaps xmm8, [rsp+0x80]
000071709abdf2e8  vmovaps xmm9, [rsp+0x90]
000071709abdf2f1  vmovaps xmm10, [rsp+0xA0]
000071709abdf2fa  vmovaps xmm11, [rsp+0xB0]
000071709abdf303  vmovaps xmm12, [rsp+0xC0]
000071709abdf30c  vmovaps xmm13, [rsp+0xD0]
000071709abdf315  vmovaps xmm14, [rsp+0xE0]
000071709abdf31e  add rsp, 0xF0
000071709abdf325  pop r11
000071709abdf327  pop r10
000071709abdf329  pop r9
000071709abdf32b  pop r8
000071709abdf32d  pop rsi
000071709abdf32e  pop rdi
000071709abdf32f  pop rdx
000071709abdf330  pop rcx
000071709abdf331  pop rax
000071709abdf332  add rsp, 0x08
000071709abdf336  jmp 0x000071709ABDC38F
000071709abdf33b  sub rsp, 0x08
000071709abdf33f  push rax
000071709abdf340  push rcx
000071709abdf341  push rdx
000071709abdf342  push rdi
000071709abdf343  push rsi
000071709abdf344  push r8
000071709abdf346  push r9
000071709abdf348  push r10
000071709abdf34a  push r11
000071709abdf34c  sub rsp, 0xF0
000071709abdf353  vmovaps [rsp], xmm0
000071709abdf358  vmovaps [rsp+0x10], xmm1
000071709abdf35e  vmovaps [rsp+0x20], xmm2
000071709abdf364  vmovaps [rsp+0x30], xmm3
000071709abdf36a  vmovaps [rsp+0x40], xmm4
000071709abdf370  vmovaps [rsp+0x50], xmm6
000071709abdf376  vmovaps [rsp+0x60], xmm7
000071709abdf37c  vmovaps [rsp+0x70], xmm8
000071709abdf382  vmovaps [rsp+0x80], xmm9
000071709abdf38b  vmovaps [rsp+0x90], xmm10
000071709abdf394  vmovaps [rsp+0xA0], xmm11
000071709abdf39d  vmovaps [rsp+0xB0], xmm12
000071709abdf3a6  vmovaps [rsp+0xC0], xmm13
000071709abdf3af  vmovaps [rsp+0xD0], xmm14
000071709abdf3b8  vmovaps [rsp+0xE0], xmm15
000071709abdf3c1  sub rsp, 0x30
000071709abdf3c5  movaps [rsp], xmm5
000071709abdf3c9  movaps [rsp+0x10], xmm8
000071709abdf3cf  movaps [rsp+0x20], xmm6
000071709abdf3d4  lea rdi, [rsp]
000071709abdf3d8  mov esi, 0x00
000071709abdf3dd  mov rax, 0x60B9B2ABC530
000071709abdf3e7  call rax
000071709abdf3e9  movaps xmm5, [rsp]
000071709abdf3ed  add rsp, 0x30
000071709abdf3f1  vmovaps xmm0, [rsp]
000071709abdf3f6  vmovaps xmm1, [rsp+0x10]
000071709abdf3fc  vmovaps xmm2, [rsp+0x20]
000071709abdf402  vmovaps xmm3, [rsp+0x30]
000071709abdf408  vmovaps xmm4, [rsp+0x40]
000071709abdf40e  vmovaps xmm6, [rsp+0x50]
000071709abdf414  vmovaps xmm7, [rsp+0x60]
000071709abdf41a  vmovaps xmm8, [rsp+0x70]
000071709abdf420  vmovaps xmm9, [rsp+0x80]
000071709abdf429  vmovaps xmm10, [rsp+0x90]
000071709abdf432  vmovaps xmm11, [rsp+0xA0]
000071709abdf43b  vmovaps xmm12, [rsp+0xB0]
000071709abdf444  vmovaps xmm13, [rsp+0xC0]
000071709abdf44d  vmovaps xmm14, [rsp+0xD0]
000071709abdf456  vmovaps xmm15, [rsp+0xE0]
000071709abdf45f  add rsp, 0xF0
000071709abdf466  pop r11
000071709abdf468  pop r10
000071709abdf46a  pop r9
000071709abdf46c  pop r8
000071709abdf46e  pop rsi
000071709abdf46f  pop rdi
000071709abdf470  pop rdx
000071709abdf471  pop rcx
000071709abdf472  pop rax
000071709abdf473  add rsp, 0x08
000071709abdf477  jmp 0x000071709ABDC3B3
000071709abdf47c  sub rsp, 0x08
000071709abdf480  push rax
000071709abdf481  push rcx
000071709abdf482  push rdx
000071709abdf483  push rdi
000071709abdf484  push rsi
000071709abdf485  push r8
000071709abdf487  push r9
000071709abdf489  push r10
000071709abdf48b  push r11
000071709abdf48d  sub rsp, 0xF0
000071709abdf494  vmovaps [rsp], xmm0
000071709abdf499  vmovaps [rsp+0x10], xmm1
000071709abdf49f  vmovaps [rsp+0x20], xmm2
000071709abdf4a5  vmovaps [rsp+0x30], xmm3
000071709abdf4ab  vmovaps [rsp+0x40], xmm4
000071709abdf4b1  vmovaps [rsp+0x50], xmm5
000071709abdf4b7  vmovaps [rsp+0x60], xmm7
000071709abdf4bd  vmovaps [rsp+0x70], xmm8
000071709abdf4c3  vmovaps [rsp+0x80], xmm9
000071709abdf4cc  vmovaps [rsp+0x90], xmm10
000071709abdf4d5  vmovaps [rsp+0xA0], xmm11
000071709abdf4de  vmovaps [rsp+0xB0], xmm12
000071709abdf4e7  vmovaps [rsp+0xC0], xmm13
000071709abdf4f0  vmovaps [rsp+0xD0], xmm14
000071709abdf4f9  vmovaps [rsp+0xE0], xmm15
000071709abdf502  sub rsp, 0x30
000071709abdf506  movaps [rsp], xmm6
000071709abdf50a  movaps [rsp+0x10], xmm10
000071709abdf510  movaps [rsp+0x20], xmm8
000071709abdf516  lea rdi, [rsp]
000071709abdf51a  mov esi, 0x00
000071709abdf51f  mov rax, 0x60B9B2ABC530
000071709abdf529  call rax
000071709abdf52b  movaps xmm6, [rsp]
000071709abdf52f  add rsp, 0x30
000071709abdf533  vmovaps xmm0, [rsp]
000071709abdf538  vmovaps xmm1, [rsp+0x10]
000071709abdf53e  vmovaps xmm2, [rsp+0x20]
000071709abdf544  vmovaps xmm3, [rsp+0x30]
000071709abdf54a  vmovaps xmm4, [rsp+0x40]
000071709abdf550  vmovaps xmm5, [rsp+0x50]
000071709abdf556  vmovaps xmm7, [rsp+0x60]
000071709abdf55c  vmovaps xmm8, [rsp+0x70]
000071709abdf562  vmovaps xmm9, [rsp+0x80]
000071709abdf56b  vmovaps xmm10, [rsp+0x90]
000071709abdf574  vmovaps xmm11, [rsp+0xA0]
000071709abdf57d  vmovaps xmm12, [rsp+0xB0]
000071709abdf586  vmovaps xmm13, [rsp+0xC0]
000071709abdf58f  vmovaps xmm14, [rsp+0xD0]
000071709abdf598  vmovaps xmm15, [rsp+0xE0]
000071709abdf5a1  add rsp, 0xF0
000071709abdf5a8  pop r11
000071709abdf5aa  pop r10
000071709abdf5ac  pop r9
000071709abdf5ae  pop r8
000071709abdf5b0  pop rsi
000071709abdf5b1  pop rdi
000071709abdf5b2  pop rdx
000071709abdf5b3  pop rcx
000071709abdf5b4  pop rax
000071709abdf5b5  add rsp, 0x08
000071709abdf5b9  jmp 0x000071709ABDC3D8
000071709abdf5be  sub rsp, 0x08
000071709abdf5c2  push rax
000071709abdf5c3  push rcx
000071709abdf5c4  push rdx
000071709abdf5c5  push rdi
000071709abdf5c6  push rsi
000071709abdf5c7  push r8
000071709abdf5c9  push r9
000071709abdf5cb  push r10
000071709abdf5cd  push r11
000071709abdf5cf  sub rsp, 0xF0
000071709abdf5d6  vmovaps [rsp], xmm0
000071709abdf5db  vmovaps [rsp+0x10], xmm1
000071709abdf5e1  vmovaps [rsp+0x20], xmm2
000071709abdf5e7  vmovaps [rsp+0x30], xmm3
000071709abdf5ed  vmovaps [rsp+0x40], xmm4
000071709abdf5f3  vmovaps [rsp+0x50], xmm5
000071709abdf5f9  vmovaps [rsp+0x60], xmm6
000071709abdf5ff  vmovaps [rsp+0x70], xmm7
000071709abdf605  vmovaps [rsp+0x80], xmm8
000071709abdf60e  vmovaps [rsp+0x90], xmm9
000071709abdf617  vmovaps [rsp+0xA0], xmm11
000071709abdf620  vmovaps [rsp+0xB0], xmm12
000071709abdf629  vmovaps [rsp+0xC0], xmm13
000071709abdf632  vmovaps [rsp+0xD0], xmm14
000071709abdf63b  vmovaps [rsp+0xE0], xmm15
000071709abdf644  sub rsp, 0x30
000071709abdf648  movaps [rsp], xmm10
000071709abdf64d  movaps [rsp+0x10], xmm8
000071709abdf653  movaps [rsp+0x20], xmm14
000071709abdf659  lea rdi, [rsp]
000071709abdf65d  mov esi, 0x00
000071709abdf662  mov rax, 0x60B9B2ABC530
000071709abdf66c  call rax
000071709abdf66e  movaps xmm10, [rsp]
000071709abdf673  add rsp, 0x30
000071709abdf677  vmovaps xmm0, [rsp]
000071709abdf67c  vmovaps xmm1, [rsp+0x10]
000071709abdf682  vmovaps xmm2, [rsp+0x20]
000071709abdf688  vmovaps xmm3, [rsp+0x30]
000071709abdf68e  vmovaps xmm4, [rsp+0x40]
000071709abdf694  vmovaps xmm5, [rsp+0x50]
000071709abdf69a  vmovaps xmm6, [rsp+0x60]
000071709abdf6a0  vmovaps xmm7, [rsp+0x70]
000071709abdf6a6  vmovaps xmm8, [rsp+0x80]
000071709abdf6af  vmovaps xmm9, [rsp+0x90]
000071709abdf6b8  vmovaps xmm11, [rsp+0xA0]
000071709abdf6c1  vmovaps xmm12, [rsp+0xB0]
000071709abdf6ca  vmovaps xmm13, [rsp+0xC0]
000071709abdf6d3  vmovaps xmm14, [rsp+0xD0]
000071709abdf6dc  vmovaps xmm15, [rsp+0xE0]
000071709abdf6e5  add rsp, 0xF0
000071709abdf6ec  pop r11
000071709abdf6ee  pop r10
000071709abdf6f0  pop r9
000071709abdf6f2  pop r8
000071709abdf6f4  pop rsi
000071709abdf6f5  pop rdi
000071709abdf6f6  pop rdx
000071709abdf6f7  pop rcx
000071709abdf6f8  pop rax
000071709abdf6f9  add rsp, 0x08
000071709abdf6fd  jmp 0x000071709ABDC3F8
000071709abdf702  sub rsp, 0x08
000071709abdf706  push rax
000071709abdf707  push rcx
000071709abdf708  push rdx
000071709abdf709  push rdi
000071709abdf70a  push rsi
000071709abdf70b  push r8
000071709abdf70d  push r9
000071709abdf70f  push r10
000071709abdf711  push r11
000071709abdf713  sub rsp, 0xF0
000071709abdf71a  vmovaps [rsp], xmm0
000071709abdf71f  vmovaps [rsp+0x10], xmm1
000071709abdf725  vmovaps [rsp+0x20], xmm2
000071709abdf72b  vmovaps [rsp+0x30], xmm3
000071709abdf731  vmovaps [rsp+0x40], xmm4
000071709abdf737  vmovaps [rsp+0x50], xmm5
000071709abdf73d  vmovaps [rsp+0x60], xmm6
000071709abdf743  vmovaps [rsp+0x70], xmm7
000071709abdf749  vmovaps [rsp+0x80], xmm8
000071709abdf752  vmovaps [rsp+0x90], xmm9
000071709abdf75b  vmovaps [rsp+0xA0], xmm10
000071709abdf764  vmovaps [rsp+0xB0], xmm11
000071709abdf76d  vmovaps [rsp+0xC0], xmm12
000071709abdf776  vmovaps [rsp+0xD0], xmm13
000071709abdf77f  vmovaps [rsp+0xE0], xmm15
000071709abdf788  sub rsp, 0x30
000071709abdf78c  movaps [rsp], xmm14
000071709abdf791  movaps [rsp+0x10], xmm8
000071709abdf797  movaps [rsp+0x20], xmm4
000071709abdf79c  lea rdi, [rsp]
000071709abdf7a0  mov esi, 0x00
000071709abdf7a5  mov rax, 0x60B9B2ABC530
000071709abdf7af  call rax
000071709abdf7b1  movaps xmm14, [rsp]
000071709abdf7b6  add rsp, 0x30
000071709abdf7ba  vmovaps xmm0, [rsp]
000071709abdf7bf  vmovaps xmm1, [rsp+0x10]
000071709abdf7c5  vmovaps xmm2, [rsp+0x20]
000071709abdf7cb  vmovaps xmm3, [rsp+0x30]
000071709abdf7d1  vmovaps xmm4, [rsp+0x40]
000071709abdf7d7  vmovaps xmm5, [rsp+0x50]
000071709abdf7dd  vmovaps xmm6, [rsp+0x60]
000071709abdf7e3  vmovaps xmm7, [rsp+0x70]
000071709abdf7e9  vmovaps xmm8, [rsp+0x80]
000071709abdf7f2  vmovaps xmm9, [rsp+0x90]
000071709abdf7fb  vmovaps xmm10, [rsp+0xA0]
000071709abdf804  vmovaps xmm11, [rsp+0xB0]
000071709abdf80d  vmovaps xmm12, [rsp+0xC0]
000071709abdf816  vmovaps xmm13, [rsp+0xD0]
000071709abdf81f  vmovaps xmm15, [rsp+0xE0]
000071709abdf828  add rsp, 0xF0
000071709abdf82f  pop r11
000071709abdf831  pop r10
000071709abdf833  pop r9
000071709abdf835  pop r8
000071709abdf837  pop rsi
000071709abdf838  pop rdi
000071709abdf839  pop rdx
000071709abdf83a  pop rcx
000071709abdf83b  pop rax
000071709abdf83c  add rsp, 0x08
000071709abdf840  jmp 0x000071709ABDC418
000071709abdf845  sub rsp, 0x08
000071709abdf849  push rax
000071709abdf84a  push rcx
000071709abdf84b  push rdx
000071709abdf84c  push rdi
000071709abdf84d  push rsi
000071709abdf84e  push r8
000071709abdf850  push r9
000071709abdf852  push r10
000071709abdf854  push r11
000071709abdf856  sub rsp, 0xF0
000071709abdf85d  vmovaps [rsp], xmm0
000071709abdf862  vmovaps [rsp+0x10], xmm1
000071709abdf868  vmovaps [rsp+0x20], xmm2
000071709abdf86e  vmovaps [rsp+0x30], xmm3
000071709abdf874  vmovaps [rsp+0x40], xmm5
000071709abdf87a  vmovaps [rsp+0x50], xmm6
000071709abdf880  vmovaps [rsp+0x60], xmm7
000071709abdf886  vmovaps [rsp+0x70], xmm8
000071709abdf88c  vmovaps [rsp+0x80], xmm9
000071709abdf895  vmovaps [rsp+0x90], xmm10
000071709abdf89e  vmovaps [rsp+0xA0], xmm11
000071709abdf8a7  vmovaps [rsp+0xB0], xmm12
000071709abdf8b0  vmovaps [rsp+0xC0], xmm13
000071709abdf8b9  vmovaps [rsp+0xD0], xmm14
000071709abdf8c2  vmovaps [rsp+0xE0], xmm15
000071709abdf8cb  sub rsp, 0x30
000071709abdf8cf  movaps [rsp], xmm4
000071709abdf8d3  movaps [rsp+0x10], xmm13
000071709abdf8d9  movaps [rsp+0x20], xmm8
000071709abdf8df  lea rdi, [rsp]
000071709abdf8e3  mov esi, 0x00
000071709abdf8e8  mov rax, 0x60B9B2ABC530
000071709abdf8f2  call rax
000071709abdf8f4  movaps xmm4, [rsp]
000071709abdf8f8  add rsp, 0x30
000071709abdf8fc  vmovaps xmm0, [rsp]
000071709abdf901  vmovaps xmm1, [rsp+0x10]
000071709abdf907  vmovaps xmm2, [rsp+0x20]
000071709abdf90d  vmovaps xmm3, [rsp+0x30]
000071709abdf913  vmovaps xmm5, [rsp+0x40]
000071709abdf919  vmovaps xmm6, [rsp+0x50]
000071709abdf91f  vmovaps xmm7, [rsp+0x60]
000071709abdf925  vmovaps xmm8, [rsp+0x70]
000071709abdf92b  vmovaps xmm9, [rsp+0x80]
000071709abdf934  vmovaps xmm10, [rsp+0x90]
000071709abdf93d  vmovaps xmm11, [rsp+0xA0]
000071709abdf946  vmovaps xmm12, [rsp+0xB0]
000071709abdf94f  vmovaps xmm13, [rsp+0xC0]
000071709abdf958  vmovaps xmm14, [rsp+0xD0]
000071709abdf961  vmovaps xmm15, [rsp+0xE0]
000071709abdf96a  add rsp, 0xF0
000071709abdf971  pop r11
000071709abdf973  pop r10
000071709abdf975  pop r9
000071709abdf977  pop r8
000071709abdf979  pop rsi
000071709abdf97a  pop rdi
000071709abdf97b  pop rdx
000071709abdf97c  pop rcx
000071709abdf97d  pop rax
000071709abdf97e  add rsp, 0x08
000071709abdf982  jmp 0x000071709ABDC43D
000071709abdf987  sub rsp, 0x08
000071709abdf98b  push rax
000071709abdf98c  push rcx
000071709abdf98d  push rdx
000071709abdf98e  push rdi
000071709abdf98f  push rsi
000071709abdf990  push r8
000071709abdf992  push r9
000071709abdf994  push r10
000071709abdf996  push r11
000071709abdf998  sub rsp, 0xF0
000071709abdf99f  vmovaps [rsp], xmm0
000071709abdf9a4  vmovaps [rsp+0x10], xmm1
000071709abdf9aa  vmovaps [rsp+0x20], xmm2
000071709abdf9b0  vmovaps [rsp+0x30], xmm3
000071709abdf9b6  vmovaps [rsp+0x40], xmm4
000071709abdf9bc  vmovaps [rsp+0x50], xmm5
000071709abdf9c2  vmovaps [rsp+0x60], xmm6
000071709abdf9c8  vmovaps [rsp+0x70], xmm7
000071709abdf9ce  vmovaps [rsp+0x80], xmm8
000071709abdf9d7  vmovaps [rsp+0x90], xmm9
000071709abdf9e0  vmovaps [rsp+0xA0], xmm10
000071709abdf9e9  vmovaps [rsp+0xB0], xmm11
000071709abdf9f2  vmovaps [rsp+0xC0], xmm12
000071709abdf9fb  vmovaps [rsp+0xD0], xmm14
000071709abdfa04  vmovaps [rsp+0xE0], xmm15
000071709abdfa0d  sub rsp, 0x30
000071709abdfa11  movaps [rsp], xmm13
000071709abdfa16  movaps [rsp+0x10], xmm15
000071709abdfa1c  movaps [rsp+0x20], xmm9
000071709abdfa22  lea rdi, [rsp]
000071709abdfa26  mov esi, 0x00
000071709abdfa2b  mov rax, 0x60B9B2ABC530
000071709abdfa35  call rax
000071709abdfa37  movaps xmm13, [rsp]
000071709abdfa3c  add rsp, 0x30
000071709abdfa40  vmovaps xmm0, [rsp]
000071709abdfa45  vmovaps xmm1, [rsp+0x10]
000071709abdfa4b  vmovaps xmm2, [rsp+0x20]
000071709abdfa51  vmovaps xmm3, [rsp+0x30]
000071709abdfa57  vmovaps xmm4, [rsp+0x40]
000071709abdfa5d  vmovaps xmm5, [rsp+0x50]
000071709abdfa63  vmovaps xmm6, [rsp+0x60]
000071709abdfa69  vmovaps xmm7, [rsp+0x70]
000071709abdfa6f  vmovaps xmm8, [rsp+0x80]
000071709abdfa78  vmovaps xmm9, [rsp+0x90]
000071709abdfa81  vmovaps xmm10, [rsp+0xA0]
000071709abdfa8a  vmovaps xmm11, [rsp+0xB0]
000071709abdfa93  vmovaps xmm12, [rsp+0xC0]
000071709abdfa9c  vmovaps xmm14, [rsp+0xD0]
000071709abdfaa5  vmovaps xmm15, [rsp+0xE0]
000071709abdfaae  add rsp, 0xF0
000071709abdfab5  pop r11
000071709abdfab7  pop r10
000071709abdfab9  pop r9
000071709abdfabb  pop r8
000071709abdfabd  pop rsi
000071709abdfabe  pop rdi
000071709abdfabf  pop rdx
000071709abdfac0  pop rcx
000071709abdfac1  pop rax
000071709abdfac2  add rsp, 0x08
000071709abdfac6  jmp 0x000071709ABDC458
000071709abdfacb  sub rsp, 0x08
000071709abdfacf  push rax
000071709abdfad0  push rcx
000071709abdfad1  push rdx
000071709abdfad2  push rdi
000071709abdfad3  push rsi
000071709abdfad4  push r8
000071709abdfad6  push r9
000071709abdfad8  push r10
000071709abdfada  push r11
000071709abdfadc  sub rsp, 0xF0
000071709abdfae3  vmovaps [rsp], xmm0
000071709abdfae8  vmovaps [rsp+0x10], xmm1
000071709abdfaee  vmovaps [rsp+0x20], xmm2
000071709abdfaf4  vmovaps [rsp+0x30], xmm3
000071709abdfafa  vmovaps [rsp+0x40], xmm4
000071709abdfb00  vmovaps [rsp+0x50], xmm5
000071709abdfb06  vmovaps [rsp+0x60], xmm6
000071709abdfb0c  vmovaps [rsp+0x70], xmm7
000071709abdfb12  vmovaps [rsp+0x80], xmm8
000071709abdfb1b  vmovaps [rsp+0x90], xmm9
000071709abdfb24  vmovaps [rsp+0xA0], xmm10
000071709abdfb2d  vmovaps [rsp+0xB0], xmm11
000071709abdfb36  vmovaps [rsp+0xC0], xmm12
000071709abdfb3f  vmovaps [rsp+0xD0], xmm13
000071709abdfb48  vmovaps [rsp+0xE0], xmm14
000071709abdfb51  sub rsp, 0x30
000071709abdfb55  movaps [rsp], xmm15
000071709abdfb5a  movaps [rsp+0x10], xmm1
000071709abdfb5f  movaps [rsp+0x20], xmm5
000071709abdfb64  lea rdi, [rsp]
000071709abdfb68  mov esi, 0x00
000071709abdfb6d  mov rax, 0x60B9B2ABC530
000071709abdfb77  call rax
000071709abdfb79  movaps xmm15, [rsp]
000071709abdfb7e  add rsp, 0x30
000071709abdfb82  vmovaps xmm0, [rsp]
000071709abdfb87  vmovaps xmm1, [rsp+0x10]
000071709abdfb8d  vmovaps xmm2, [rsp+0x20]
000071709abdfb93  vmovaps xmm3, [rsp+0x30]
000071709abdfb99  vmovaps xmm4, [rsp+0x40]
000071709abdfb9f  vmovaps xmm5, [rsp+0x50]
000071709abdfba5  vmovaps xmm6, [rsp+0x60]
000071709abdfbab  vmovaps xmm7, [rsp+0x70]
000071709abdfbb1  vmovaps xmm8, [rsp+0x80]
000071709abdfbba  vmovaps xmm9, [rsp+0x90]
000071709abdfbc3  vmovaps xmm10, [rsp+0xA0]
000071709abdfbcc  vmovaps xmm11, [rsp+0xB0]
000071709abdfbd5  vmovaps xmm12, [rsp+0xC0]
000071709abdfbde  vmovaps xmm13, [rsp+0xD0]
000071709abdfbe7  vmovaps xmm14, [rsp+0xE0]
000071709abdfbf0  add rsp, 0xF0
000071709abdfbf7  pop r11
000071709abdfbf9  pop r10
000071709abdfbfb  pop r9
000071709abdfbfd  pop r8
000071709abdfbff  pop rsi
000071709abdfc00  pop rdi
000071709abdfc01  pop rdx
000071709abdfc02  pop rcx
000071709abdfc03  pop rax
000071709abdfc04  add rsp, 0x08
000071709abdfc08  jmp 0x000071709ABDC473
000071709abdfc0d  call 0x000071709AAB52F0
000071709abdfc12  jmp 0x000071709ABDC4CE
000071709abdfc17  sub rsp, 0x08
000071709abdfc1b  push rax
000071709abdfc1c  push rcx
000071709abdfc1d  push rdx
000071709abdfc1e  push rdi
000071709abdfc1f  push rsi
000071709abdfc20  push r8
000071709abdfc22  push r9
000071709abdfc24  push r10
000071709abdfc26  push r11
000071709abdfc28  sub rsp, 0xF0
000071709abdfc2f  vmovaps [rsp], xmm0
000071709abdfc34  vmovaps [rsp+0x10], xmm1
000071709abdfc3a  vmovaps [rsp+0x20], xmm2
000071709abdfc40  vmovaps [rsp+0x30], xmm3
000071709abdfc46  vmovaps [rsp+0x40], xmm4
000071709abdfc4c  vmovaps [rsp+0x50], xmm5
000071709abdfc52  vmovaps [rsp+0x60], xmm6
000071709abdfc58  vmovaps [rsp+0x70], xmm7
000071709abdfc5e  vmovaps [rsp+0x80], xmm8
000071709abdfc67  vmovaps [rsp+0x90], xmm10
000071709abdfc70  vmovaps [rsp+0xA0], xmm11
000071709abdfc79  vmovaps [rsp+0xB0], xmm12
000071709abdfc82  vmovaps [rsp+0xC0], xmm13
000071709abdfc8b  vmovaps [rsp+0xD0], xmm14
000071709abdfc94  vmovaps [rsp+0xE0], xmm15
000071709abdfc9d  sub rsp, 0x30
000071709abdfca1  movaps [rsp], xmm9
000071709abdfca6  movaps [rsp+0x10], xmm8
000071709abdfcac  movaps [rsp+0x20], xmm11
000071709abdfcb2  lea rdi, [rsp]
000071709abdfcb6  mov esi, 0x00
000071709abdfcbb  mov rax, 0x60B9B2ABC530
000071709abdfcc5  call rax
000071709abdfcc7  movaps xmm9, [rsp]
000071709abdfccc  add rsp, 0x30
000071709abdfcd0  vmovaps xmm0, [rsp]
000071709abdfcd5  vmovaps xmm1, [rsp+0x10]
000071709abdfcdb  vmovaps xmm2, [rsp+0x20]
000071709abdfce1  vmovaps xmm3, [rsp+0x30]
000071709abdfce7  vmovaps xmm4, [rsp+0x40]
000071709abdfced  vmovaps xmm5, [rsp+0x50]
000071709abdfcf3  vmovaps xmm6, [rsp+0x60]
000071709abdfcf9  vmovaps xmm7, [rsp+0x70]
000071709abdfcff  vmovaps xmm8, [rsp+0x80]
000071709abdfd08  vmovaps xmm10, [rsp+0x90]
000071709abdfd11  vmovaps xmm11, [rsp+0xA0]
000071709abdfd1a  vmovaps xmm12, [rsp+0xB0]
000071709abdfd23  vmovaps xmm13, [rsp+0xC0]
000071709abdfd2c  vmovaps xmm14, [rsp+0xD0]
000071709abdfd35  vmovaps xmm15, [rsp+0xE0]
000071709abdfd3e  add rsp, 0xF0
000071709abdfd45  pop r11
000071709abdfd47  pop r10
000071709abdfd49  pop r9
000071709abdfd4b  pop r8
000071709abdfd4d  pop rsi
000071709abdfd4e  pop rdi
000071709abdfd4f  pop rdx
000071709abdfd50  pop rcx
000071709abdfd51  pop rax
000071709abdfd52  add rsp, 0x08
000071709abdfd56  jmp 0x000071709ABDC505
000071709abdfd5b  sub rsp, 0x08
000071709abdfd5f  push rax
000071709abdfd60  push rcx
000071709abdfd61  push rdx
000071709abdfd62  push rdi
000071709abdfd63  push rsi
000071709abdfd64  push r8
000071709abdfd66  push r9
000071709abdfd68  push r10
000071709abdfd6a  push r11
000071709abdfd6c  sub rsp, 0xF0
000071709abdfd73  vmovaps [rsp], xmm0
000071709abdfd78  vmovaps [rsp+0x10], xmm1
000071709abdfd7e  vmovaps [rsp+0x20], xmm2
000071709abdfd84  vmovaps [rsp+0x30], xmm3
000071709abdfd8a  vmovaps [rsp+0x40], xmm4
000071709abdfd90  vmovaps [rsp+0x50], xmm5
000071709abdfd96  vmovaps [rsp+0x60], xmm6
000071709abdfd9c  vmovaps [rsp+0x70], xmm7
000071709abdfda2  vmovaps [rsp+0x80], xmm8
000071709abdfdab  vmovaps [rsp+0x90], xmm9
000071709abdfdb4  vmovaps [rsp+0xA0], xmm10
000071709abdfdbd  vmovaps [rsp+0xB0], xmm12
000071709abdfdc6  vmovaps [rsp+0xC0], xmm13
000071709abdfdcf  vmovaps [rsp+0xD0], xmm14
000071709abdfdd8  vmovaps [rsp+0xE0], xmm15
000071709abdfde1  sub rsp, 0x30
000071709abdfde5  movaps [rsp], xmm11
000071709abdfdea  movaps [rsp+0x10], xmm10
000071709abdfdf0  movaps [rsp+0x20], xmm6
000071709abdfdf5  lea rdi, [rsp]
000071709abdfdf9  mov esi, 0x00
000071709abdfdfe  mov rax, 0x60B9B2ABC530
000071709abdfe08  call rax
000071709abdfe0a  movaps xmm11, [rsp]
000071709abdfe0f  add rsp, 0x30
000071709abdfe13  vmovaps xmm0, [rsp]
000071709abdfe18  vmovaps xmm1, [rsp+0x10]
000071709abdfe1e  vmovaps xmm2, [rsp+0x20]
000071709abdfe24  vmovaps xmm3, [rsp+0x30]
000071709abdfe2a  vmovaps xmm4, [rsp+0x40]
000071709abdfe30  vmovaps xmm5, [rsp+0x50]
000071709abdfe36  vmovaps xmm6, [rsp+0x60]
000071709abdfe3c  vmovaps xmm7, [rsp+0x70]
000071709abdfe42  vmovaps xmm8, [rsp+0x80]
000071709abdfe4b  vmovaps xmm9, [rsp+0x90]
000071709abdfe54  vmovaps xmm10, [rsp+0xA0]
000071709abdfe5d  vmovaps xmm12, [rsp+0xB0]
000071709abdfe66  vmovaps xmm13, [rsp+0xC0]
000071709abdfe6f  vmovaps xmm14, [rsp+0xD0]
000071709abdfe78  vmovaps xmm15, [rsp+0xE0]
000071709abdfe81  add rsp, 0xF0
000071709abdfe88  pop r11
000071709abdfe8a  pop r10
000071709abdfe8c  pop r9
000071709abdfe8e  pop r8
000071709abdfe90  pop rsi
000071709abdfe91  pop rdi
000071709abdfe92  pop rdx
000071709abdfe93  pop rcx
000071709abdfe94  pop rax
000071709abdfe95  add rsp, 0x08
000071709abdfe99  jmp 0x000071709ABDC520
000071709abdfe9e  sub rsp, 0x08
000071709abdfea2  push rax
000071709abdfea3  push rcx
000071709abdfea4  push rdx
000071709abdfea5  push rdi
000071709abdfea6  push rsi
000071709abdfea7  push r8
000071709abdfea9  push r9
000071709abdfeab  push r10
000071709abdfead  push r11
000071709abdfeaf  sub rsp, 0xF0
000071709abdfeb6  vmovaps [rsp], xmm0
000071709abdfebb  vmovaps [rsp+0x10], xmm1
000071709abdfec1  vmovaps [rsp+0x20], xmm2
000071709abdfec7  vmovaps [rsp+0x30], xmm3
000071709abdfecd  vmovaps [rsp+0x40], xmm4
000071709abdfed3  vmovaps [rsp+0x50], xmm5
000071709abdfed9  vmovaps [rsp+0x60], xmm6
000071709abdfedf  vmovaps [rsp+0x70], xmm7
000071709abdfee5  vmovaps [rsp+0x80], xmm8
000071709abdfeee  vmovaps [rsp+0x90], xmm9
000071709abdfef7  vmovaps [rsp+0xA0], xmm11
000071709abdff00  vmovaps [rsp+0xB0], xmm12
000071709abdff09  vmovaps [rsp+0xC0], xmm13
000071709abdff12  vmovaps [rsp+0xD0], xmm14
000071709abdff1b  vmovaps [rsp+0xE0], xmm15
000071709abdff24  sub rsp, 0x30
000071709abdff28  movaps [rsp], xmm10
000071709abdff2d  movaps [rsp+0x10], xmm14
000071709abdff33  movaps [rsp+0x20], xmm4
000071709abdff38  lea rdi, [rsp]
000071709abdff3c  mov esi, 0x00
000071709abdff41  mov rax, 0x60B9B2ABC530
000071709abdff4b  call rax
000071709abdff4d  movaps xmm10, [rsp]
000071709abdff52  add rsp, 0x30
000071709abdff56  vmovaps xmm0, [rsp]
000071709abdff5b  vmovaps xmm1, [rsp+0x10]
000071709abdff61  vmovaps xmm2, [rsp+0x20]
000071709abdff67  vmovaps xmm3, [rsp+0x30]
000071709abdff6d  vmovaps xmm4, [rsp+0x40]
000071709abdff73  vmovaps xmm5, [rsp+0x50]
000071709abdff79  vmovaps xmm6, [rsp+0x60]
000071709abdff7f  vmovaps xmm7, [rsp+0x70]
000071709abdff85  vmovaps xmm8, [rsp+0x80]
000071709abdff8e  vmovaps xmm9, [rsp+0x90]
000071709abdff97  vmovaps xmm11, [rsp+0xA0]
000071709abdffa0  vmovaps xmm12, [rsp+0xB0]
000071709abdffa9  vmovaps xmm13, [rsp+0xC0]
000071709abdffb2  vmovaps xmm14, [rsp+0xD0]
000071709abdffbb  vmovaps xmm15, [rsp+0xE0]
000071709abdffc4  add rsp, 0xF0
000071709abdffcb  pop r11
000071709abdffcd  pop r10
000071709abdffcf  pop r9
000071709abdffd1  pop r8
000071709abdffd3  pop rsi
000071709abdffd4  pop rdi
000071709abdffd5  pop rdx
000071709abdffd6  pop rcx
000071709abdffd7  pop rax
000071709abdffd8  add rsp, 0x08
000071709abdffdc  jmp 0x000071709ABDC53B
000071709abdffe1  sub rsp, 0x08
000071709abdffe5  push rax
000071709abdffe6  push rcx
000071709abdffe7  push rdx
000071709abdffe8  push rdi
000071709abdffe9  push rsi
000071709abdffea  push r8
000071709abdffec  push r9
000071709abdffee  push r10
000071709abdfff0  push r11
000071709abdfff2  sub rsp, 0xF0
000071709abdfff9  vmovaps [rsp], xmm0
000071709abdfffe  vmovaps [rsp+0x10], xmm1
000071709abe0004  vmovaps [rsp+0x20], xmm2
000071709abe000a  vmovaps [rsp+0x30], xmm3
000071709abe0010  vmovaps [rsp+0x40], xmm4
000071709abe0016  vmovaps [rsp+0x50], xmm5
000071709abe001c  vmovaps [rsp+0x60], xmm6
000071709abe0022  vmovaps [rsp+0x70], xmm7
000071709abe0028  vmovaps [rsp+0x80], xmm9
000071709abe0031  vmovaps [rsp+0x90], xmm10
000071709abe003a  vmovaps [rsp+0xA0], xmm11
000071709abe0043  vmovaps [rsp+0xB0], xmm12
000071709abe004c  vmovaps [rsp+0xC0], xmm13
000071709abe0055  vmovaps [rsp+0xD0], xmm14
000071709abe005e  vmovaps [rsp+0xE0], xmm15
000071709abe0067  sub rsp, 0x30
000071709abe006b  movaps [rsp], xmm8
000071709abe0070  movaps [rsp+0x10], xmm1
000071709abe0075  movaps [rsp+0x20], xmm14
000071709abe007b  lea rdi, [rsp]
000071709abe007f  mov esi, 0x00
000071709abe0084  mov rax, 0x60B9B2ABC530
000071709abe008e  call rax
000071709abe0090  movaps xmm8, [rsp]
000071709abe0095  add rsp, 0x30
000071709abe0099  vmovaps xmm0, [rsp]
000071709abe009e  vmovaps xmm1, [rsp+0x10]
000071709abe00a4  vmovaps xmm2, [rsp+0x20]
000071709abe00aa  vmovaps xmm3, [rsp+0x30]
000071709abe00b0  vmovaps xmm4, [rsp+0x40]
000071709abe00b6  vmovaps xmm5, [rsp+0x50]
000071709abe00bc  vmovaps xmm6, [rsp+0x60]
000071709abe00c2  vmovaps xmm7, [rsp+0x70]
000071709abe00c8  vmovaps xmm9, [rsp+0x80]
000071709abe00d1  vmovaps xmm10, [rsp+0x90]
000071709abe00da  vmovaps xmm11, [rsp+0xA0]
000071709abe00e3  vmovaps xmm12, [rsp+0xB0]
000071709abe00ec  vmovaps xmm13, [rsp+0xC0]
000071709abe00f5  vmovaps xmm14, [rsp+0xD0]
000071709abe00fe  vmovaps xmm15, [rsp+0xE0]
000071709abe0107  add rsp, 0xF0
000071709abe010e  pop r11
000071709abe0110  pop r10
000071709abe0112  pop r9
000071709abe0114  pop r8
000071709abe0116  pop rsi
000071709abe0117  pop rdi
000071709abe0118  pop rdx
000071709abe0119  pop rcx
000071709abe011a  pop rax
000071709abe011b  add rsp, 0x08
000071709abe011f  jmp 0x000071709ABDC561
000071709abe0124  sub rsp, 0x08
000071709abe0128  push rax
000071709abe0129  push rcx
000071709abe012a  push rdx
000071709abe012b  push rdi
000071709abe012c  push rsi
000071709abe012d  push r8
000071709abe012f  push r9
000071709abe0131  push r10
000071709abe0133  push r11
000071709abe0135  sub rsp, 0xF0
000071709abe013c  vmovaps [rsp], xmm0
000071709abe0141  vmovaps [rsp+0x10], xmm1
000071709abe0147  vmovaps [rsp+0x20], xmm2
000071709abe014d  vmovaps [rsp+0x30], xmm3
000071709abe0153  vmovaps [rsp+0x40], xmm4
000071709abe0159  vmovaps [rsp+0x50], xmm5
000071709abe015f  vmovaps [rsp+0x60], xmm7
000071709abe0165  vmovaps [rsp+0x70], xmm8
000071709abe016b  vmovaps [rsp+0x80], xmm9
000071709abe0174  vmovaps [rsp+0x90], xmm10
000071709abe017d  vmovaps [rsp+0xA0], xmm11
000071709abe0186  vmovaps [rsp+0xB0], xmm12
000071709abe018f  vmovaps [rsp+0xC0], xmm13
000071709abe0198  vmovaps [rsp+0xD0], xmm14
000071709abe01a1  vmovaps [rsp+0xE0], xmm15
000071709abe01aa  sub rsp, 0x30
000071709abe01ae  movaps [rsp], xmm6
000071709abe01b2  movaps [rsp+0x10], xmm1
000071709abe01b7  movaps [rsp+0x20], xmm14
000071709abe01bd  lea rdi, [rsp]
000071709abe01c1  mov esi, 0x00
000071709abe01c6  mov rax, 0x60B9B2ABC530
000071709abe01d0  call rax
000071709abe01d2  movaps xmm6, [rsp]
000071709abe01d6  add rsp, 0x30
000071709abe01da  vmovaps xmm0, [rsp]
000071709abe01df  vmovaps xmm1, [rsp+0x10]
000071709abe01e5  vmovaps xmm2, [rsp+0x20]
000071709abe01eb  vmovaps xmm3, [rsp+0x30]
000071709abe01f1  vmovaps xmm4, [rsp+0x40]
000071709abe01f7  vmovaps xmm5, [rsp+0x50]
000071709abe01fd  vmovaps xmm7, [rsp+0x60]
000071709abe0203  vmovaps xmm8, [rsp+0x70]
000071709abe0209  vmovaps xmm9, [rsp+0x80]
000071709abe0212  vmovaps xmm10, [rsp+0x90]
000071709abe021b  vmovaps xmm11, [rsp+0xA0]
000071709abe0224  vmovaps xmm12, [rsp+0xB0]
000071709abe022d  vmovaps xmm13, [rsp+0xC0]
000071709abe0236  vmovaps xmm14, [rsp+0xD0]
000071709abe023f  vmovaps xmm15, [rsp+0xE0]
000071709abe0248  add rsp, 0xF0
000071709abe024f  pop r11
000071709abe0251  pop r10
000071709abe0253  pop r9
000071709abe0255  pop r8
000071709abe0257  pop rsi
000071709abe0258  pop rdi
000071709abe0259  pop rdx
000071709abe025a  pop rcx
000071709abe025b  pop rax
000071709abe025c  add rsp, 0x08
000071709abe0260  jmp 0x000071709ABDC58D
000071709abe0265  sub rsp, 0x08
000071709abe0269  push rax
000071709abe026a  push rcx
000071709abe026b  push rdx
000071709abe026c  push rdi
000071709abe026d  push rsi
000071709abe026e  push r8
000071709abe0270  push r9
000071709abe0272  push r10
000071709abe0274  push r11
000071709abe0276  sub rsp, 0xF0
000071709abe027d  vmovaps [rsp], xmm0
000071709abe0282  vmovaps [rsp+0x10], xmm1
000071709abe0288  vmovaps [rsp+0x20], xmm2
000071709abe028e  vmovaps [rsp+0x30], xmm3
000071709abe0294  vmovaps [rsp+0x40], xmm4
000071709abe029a  vmovaps [rsp+0x50], xmm5
000071709abe02a0  vmovaps [rsp+0x60], xmm6
000071709abe02a6  vmovaps [rsp+0x70], xmm7
000071709abe02ac  vmovaps [rsp+0x80], xmm8
000071709abe02b5  vmovaps [rsp+0x90], xmm9
000071709abe02be  vmovaps [rsp+0xA0], xmm10
000071709abe02c7  vmovaps [rsp+0xB0], xmm11
000071709abe02d0  vmovaps [rsp+0xC0], xmm12
000071709abe02d9  vmovaps [rsp+0xD0], xmm13
000071709abe02e2  vmovaps [rsp+0xE0], xmm15
000071709abe02eb  sub rsp, 0x30
000071709abe02ef  movaps [rsp], xmm14
000071709abe02f4  movaps [rsp+0x10], xmm12
000071709abe02fa  movaps [rsp+0x20], xmm1
000071709abe02ff  lea rdi, [rsp]
000071709abe0303  mov esi, 0x00
000071709abe0308  mov rax, 0x60B9B2ABC530
000071709abe0312  call rax
000071709abe0314  movaps xmm14, [rsp]
000071709abe0319  add rsp, 0x30
000071709abe031d  vmovaps xmm0, [rsp]
000071709abe0322  vmovaps xmm1, [rsp+0x10]
000071709abe0328  vmovaps xmm2, [rsp+0x20]
000071709abe032e  vmovaps xmm3, [rsp+0x30]
000071709abe0334  vmovaps xmm4, [rsp+0x40]
000071709abe033a  vmovaps xmm5, [rsp+0x50]
000071709abe0340  vmovaps xmm6, [rsp+0x60]
000071709abe0346  vmovaps xmm7, [rsp+0x70]
000071709abe034c  vmovaps xmm8, [rsp+0x80]
000071709abe0355  vmovaps xmm9, [rsp+0x90]
000071709abe035e  vmovaps xmm10, [rsp+0xA0]
000071709abe0367  vmovaps xmm11, [rsp+0xB0]
000071709abe0370  vmovaps xmm12, [rsp+0xC0]
000071709abe0379  vmovaps xmm13, [rsp+0xD0]
000071709abe0382  vmovaps xmm15, [rsp+0xE0]
000071709abe038b  add rsp, 0xF0
000071709abe0392  pop r11
000071709abe0394  pop r10
000071709abe0396  pop r9
000071709abe0398  pop r8
000071709abe039a  pop rsi
000071709abe039b  pop rdi
000071709abe039c  pop rdx
000071709abe039d  pop rcx
000071709abe039e  pop rax
000071709abe039f  add rsp, 0x08
000071709abe03a3  jmp 0x000071709ABDC5B3
000071709abe03a8  sub rsp, 0x08
000071709abe03ac  push rax
000071709abe03ad  push rcx
000071709abe03ae  push rdx
000071709abe03af  push rdi
000071709abe03b0  push rsi
000071709abe03b1  push r8
000071709abe03b3  push r9
000071709abe03b5  push r10
000071709abe03b7  push r11
000071709abe03b9  sub rsp, 0xF0
000071709abe03c0  vmovaps [rsp], xmm0
000071709abe03c5  vmovaps [rsp+0x10], xmm2
000071709abe03cb  vmovaps [rsp+0x20], xmm3
000071709abe03d1  vmovaps [rsp+0x30], xmm4
000071709abe03d7  vmovaps [rsp+0x40], xmm5
000071709abe03dd  vmovaps [rsp+0x50], xmm6
000071709abe03e3  vmovaps [rsp+0x60], xmm7
000071709abe03e9  vmovaps [rsp+0x70], xmm8
000071709abe03ef  vmovaps [rsp+0x80], xmm9
000071709abe03f8  vmovaps [rsp+0x90], xmm10
000071709abe0401  vmovaps [rsp+0xA0], xmm11
000071709abe040a  vmovaps [rsp+0xB0], xmm12
000071709abe0413  vmovaps [rsp+0xC0], xmm13
000071709abe041c  vmovaps [rsp+0xD0], xmm14
000071709abe0425  vmovaps [rsp+0xE0], xmm15
000071709abe042e  sub rsp, 0x30
000071709abe0432  movaps [rsp], xmm1
000071709abe0436  movaps [rsp+0x10], xmm13
000071709abe043c  movaps [rsp+0x20], xmm9
000071709abe0442  lea rdi, [rsp]
000071709abe0446  mov esi, 0x00
000071709abe044b  mov rax, 0x60B9B2ABC530
000071709abe0455  call rax
000071709abe0457  movaps xmm1, [rsp]
000071709abe045b  add rsp, 0x30
000071709abe045f  vmovaps xmm0, [rsp]
000071709abe0464  vmovaps xmm2, [rsp+0x10]
000071709abe046a  vmovaps xmm3, [rsp+0x20]
000071709abe0470  vmovaps xmm4, [rsp+0x30]
000071709abe0476  vmovaps xmm5, [rsp+0x40]
000071709abe047c  vmovaps xmm6, [rsp+0x50]
000071709abe0482  vmovaps xmm7, [rsp+0x60]
000071709abe0488  vmovaps xmm8, [rsp+0x70]
000071709abe048e  vmovaps xmm9, [rsp+0x80]
000071709abe0497  vmovaps xmm10, [rsp+0x90]
000071709abe04a0  vmovaps xmm11, [rsp+0xA0]
000071709abe04a9  vmovaps xmm12, [rsp+0xB0]
000071709abe04b2  vmovaps xmm13, [rsp+0xC0]
000071709abe04bb  vmovaps xmm14, [rsp+0xD0]
000071709abe04c4  vmovaps xmm15, [rsp+0xE0]
000071709abe04cd  add rsp, 0xF0
000071709abe04d4  pop r11
000071709abe04d6  pop r10
000071709abe04d8  pop r9
000071709abe04da  pop r8
000071709abe04dc  pop rsi
000071709abe04dd  pop rdi
000071709abe04de  pop rdx
000071709abe04df  pop rcx
000071709abe04e0  pop rax
000071709abe04e1  add rsp, 0x08
000071709abe04e5  jmp 0x000071709ABDC5CD
000071709abe04ea  sub rsp, 0x08
000071709abe04ee  push rax
000071709abe04ef  push rcx
000071709abe04f0  push rdx
000071709abe04f1  push rdi
000071709abe04f2  push rsi
000071709abe04f3  push r8
000071709abe04f5  push r9
000071709abe04f7  push r10
000071709abe04f9  push r11
000071709abe04fb  sub rsp, 0xF0
000071709abe0502  vmovaps [rsp], xmm0
000071709abe0507  vmovaps [rsp+0x10], xmm1
000071709abe050d  vmovaps [rsp+0x20], xmm2
000071709abe0513  vmovaps [rsp+0x30], xmm3
000071709abe0519  vmovaps [rsp+0x40], xmm4
000071709abe051f  vmovaps [rsp+0x50], xmm5
000071709abe0525  vmovaps [rsp+0x60], xmm6
000071709abe052b  vmovaps [rsp+0x70], xmm7
000071709abe0531  vmovaps [rsp+0x80], xmm8
000071709abe053a  vmovaps [rsp+0x90], xmm9
000071709abe0543  vmovaps [rsp+0xA0], xmm10
000071709abe054c  vmovaps [rsp+0xB0], xmm11
000071709abe0555  vmovaps [rsp+0xC0], xmm13
000071709abe055e  vmovaps [rsp+0xD0], xmm14
000071709abe0567  vmovaps [rsp+0xE0], xmm15
000071709abe0570  sub rsp, 0x30
000071709abe0574  movaps [rsp], xmm12
000071709abe0579  movaps [rsp+0x10], xmm7
000071709abe057e  movaps [rsp+0x20], xmm13
000071709abe0584  lea rdi, [rsp]
000071709abe0588  mov esi, 0x00
000071709abe058d  mov rax, 0x60B9B2ABC530
000071709abe0597  call rax
000071709abe0599  movaps xmm12, [rsp]
000071709abe059e  add rsp, 0x30
000071709abe05a2  vmovaps xmm0, [rsp]
000071709abe05a7  vmovaps xmm1, [rsp+0x10]
000071709abe05ad  vmovaps xmm2, [rsp+0x20]
000071709abe05b3  vmovaps xmm3, [rsp+0x30]
000071709abe05b9  vmovaps xmm4, [rsp+0x40]
000071709abe05bf  vmovaps xmm5, [rsp+0x50]
000071709abe05c5  vmovaps xmm6, [rsp+0x60]
000071709abe05cb  vmovaps xmm7, [rsp+0x70]
000071709abe05d1  vmovaps xmm8, [rsp+0x80]
000071709abe05da  vmovaps xmm9, [rsp+0x90]
000071709abe05e3  vmovaps xmm10, [rsp+0xA0]
000071709abe05ec  vmovaps xmm11, [rsp+0xB0]
000071709abe05f5  vmovaps xmm13, [rsp+0xC0]
000071709abe05fe  vmovaps xmm14, [rsp+0xD0]
000071709abe0607  vmovaps xmm15, [rsp+0xE0]
000071709abe0610  add rsp, 0xF0
000071709abe0617  pop r11
000071709abe0619  pop r10
000071709abe061b  pop r9
000071709abe061d  pop r8
000071709abe061f  pop rsi
000071709abe0620  pop rdi
000071709abe0621  pop rdx
000071709abe0622  pop rcx
000071709abe0623  pop rax
000071709abe0624  add rsp, 0x08
000071709abe0628  jmp 0x000071709ABDC5F4
000071709abe062d  sub rsp, 0x08
000071709abe0631  push rax
000071709abe0632  push rcx
000071709abe0633  push rdx
000071709abe0634  push rdi
000071709abe0635  push rsi
000071709abe0636  push r8
000071709abe0638  push r9
000071709abe063a  push r10
000071709abe063c  push r11
000071709abe063e  sub rsp, 0xF0
000071709abe0645  vmovaps [rsp], xmm0
000071709abe064a  vmovaps [rsp+0x10], xmm1
000071709abe0650  vmovaps [rsp+0x20], xmm2
000071709abe0656  vmovaps [rsp+0x30], xmm3
000071709abe065c  vmovaps [rsp+0x40], xmm4
000071709abe0662  vmovaps [rsp+0x50], xmm5
000071709abe0668  vmovaps [rsp+0x60], xmm6
000071709abe066e  vmovaps [rsp+0x70], xmm7
000071709abe0674  vmovaps [rsp+0x80], xmm8
000071709abe067d  vmovaps [rsp+0x90], xmm9
000071709abe0686  vmovaps [rsp+0xA0], xmm10
000071709abe068f  vmovaps [rsp+0xB0], xmm11
000071709abe0698  vmovaps [rsp+0xC0], xmm12
000071709abe06a1  vmovaps [rsp+0xD0], xmm14
000071709abe06aa  vmovaps [rsp+0xE0], xmm15
000071709abe06b3  sub rsp, 0x30
000071709abe06b7  movaps [rsp], xmm13
000071709abe06bc  movaps [rsp+0x10], xmm15
000071709abe06c2  movaps [rsp+0x20], xmm8
000071709abe06c8  lea rdi, [rsp]
000071709abe06cc  mov esi, 0x00
000071709abe06d1  mov rax, 0x60B9B2ABC530
000071709abe06db  call rax
000071709abe06dd  movaps xmm13, [rsp]
000071709abe06e2  add rsp, 0x30
000071709abe06e6  vmovaps xmm0, [rsp]
000071709abe06eb  vmovaps xmm1, [rsp+0x10]
000071709abe06f1  vmovaps xmm2, [rsp+0x20]
000071709abe06f7  vmovaps xmm3, [rsp+0x30]
000071709abe06fd  vmovaps xmm4, [rsp+0x40]
000071709abe0703  vmovaps xmm5, [rsp+0x50]
000071709abe0709  vmovaps xmm6, [rsp+0x60]
000071709abe070f  vmovaps xmm7, [rsp+0x70]
000071709abe0715  vmovaps xmm8, [rsp+0x80]
000071709abe071e  vmovaps xmm9, [rsp+0x90]
000071709abe0727  vmovaps xmm10, [rsp+0xA0]
000071709abe0730  vmovaps xmm11, [rsp+0xB0]
000071709abe0739  vmovaps xmm12, [rsp+0xC0]
000071709abe0742  vmovaps xmm14, [rsp+0xD0]
000071709abe074b  vmovaps xmm15, [rsp+0xE0]
000071709abe0754  add rsp, 0xF0
000071709abe075b  pop r11
000071709abe075d  pop r10
000071709abe075f  pop r9
000071709abe0761  pop r8
000071709abe0763  pop rsi
000071709abe0764  pop rdi
000071709abe0765  pop rdx
000071709abe0766  pop rcx
000071709abe0767  pop rax
000071709abe0768  add rsp, 0x08
000071709abe076c  jmp 0x000071709ABDC60F
000071709abe0771  sub rsp, 0x08
000071709abe0775  push rax
000071709abe0776  push rcx
000071709abe0777  push rdx
000071709abe0778  push rdi
000071709abe0779  push rsi
000071709abe077a  push r8
000071709abe077c  push r9
000071709abe077e  push r10
000071709abe0780  push r11
000071709abe0782  sub rsp, 0xF0
000071709abe0789  vmovaps [rsp], xmm0
000071709abe078e  vmovaps [rsp+0x10], xmm1
000071709abe0794  vmovaps [rsp+0x20], xmm2
000071709abe079a  vmovaps [rsp+0x30], xmm3
000071709abe07a0  vmovaps [rsp+0x40], xmm4
000071709abe07a6  vmovaps [rsp+0x50], xmm5
000071709abe07ac  vmovaps [rsp+0x60], xmm6
000071709abe07b2  vmovaps [rsp+0x70], xmm7
000071709abe07b8  vmovaps [rsp+0x80], xmm9
000071709abe07c1  vmovaps [rsp+0x90], xmm10
000071709abe07ca  vmovaps [rsp+0xA0], xmm11
000071709abe07d3  vmovaps [rsp+0xB0], xmm12
000071709abe07dc  vmovaps [rsp+0xC0], xmm13
000071709abe07e5  vmovaps [rsp+0xD0], xmm14
000071709abe07ee  vmovaps [rsp+0xE0], xmm15
000071709abe07f7  sub rsp, 0x30
000071709abe07fb  movaps [rsp], xmm8
000071709abe0800  movaps [rsp+0x10], xmm15
000071709abe0806  movaps [rsp+0x20], xmm9
000071709abe080c  lea rdi, [rsp]
000071709abe0810  mov esi, 0x00
000071709abe0815  mov rax, 0x60B9B2ABC530
000071709abe081f  call rax
000071709abe0821  movaps xmm8, [rsp]
000071709abe0826  add rsp, 0x30
000071709abe082a  vmovaps xmm0, [rsp]
000071709abe082f  vmovaps xmm1, [rsp+0x10]
000071709abe0835  vmovaps xmm2, [rsp+0x20]
000071709abe083b  vmovaps xmm3, [rsp+0x30]
000071709abe0841  vmovaps xmm4, [rsp+0x40]
000071709abe0847  vmovaps xmm5, [rsp+0x50]
000071709abe084d  vmovaps xmm6, [rsp+0x60]
000071709abe0853  vmovaps xmm7, [rsp+0x70]
000071709abe0859  vmovaps xmm9, [rsp+0x80]
000071709abe0862  vmovaps xmm10, [rsp+0x90]
000071709abe086b  vmovaps xmm11, [rsp+0xA0]
000071709abe0874  vmovaps xmm12, [rsp+0xB0]
000071709abe087d  vmovaps xmm13, [rsp+0xC0]
000071709abe0886  vmovaps xmm14, [rsp+0xD0]
000071709abe088f  vmovaps xmm15, [rsp+0xE0]
000071709abe0898  add rsp, 0xF0
000071709abe089f  pop r11
000071709abe08a1  pop r10
000071709abe08a3  pop r9
000071709abe08a5  pop r8
000071709abe08a7  pop rsi
000071709abe08a8  pop rdi
000071709abe08a9  pop rdx
000071709abe08aa  pop rcx
000071709abe08ab  pop rax
000071709abe08ac  add rsp, 0x08
000071709abe08b0  jmp 0x000071709ABDC63D
000071709abe08b5  sub rsp, 0x08
000071709abe08b9  push rax
000071709abe08ba  push rcx
000071709abe08bb  push rdx
000071709abe08bc  push rdi
000071709abe08bd  push rsi
000071709abe08be  push r8
000071709abe08c0  push r9
000071709abe08c2  push r10
000071709abe08c4  push r11
000071709abe08c6  sub rsp, 0xF0
000071709abe08cd  vmovaps [rsp], xmm0
000071709abe08d2  vmovaps [rsp+0x10], xmm1
000071709abe08d8  vmovaps [rsp+0x20], xmm2
000071709abe08de  vmovaps [rsp+0x30], xmm3
000071709abe08e4  vmovaps [rsp+0x40], xmm4
000071709abe08ea  vmovaps [rsp+0x50], xmm5
000071709abe08f0  vmovaps [rsp+0x60], xmm6
000071709abe08f6  vmovaps [rsp+0x70], xmm7
000071709abe08fc  vmovaps [rsp+0x80], xmm8
000071709abe0905  vmovaps [rsp+0x90], xmm9
000071709abe090e  vmovaps [rsp+0xA0], xmm10
000071709abe0917  vmovaps [rsp+0xB0], xmm11
000071709abe0920  vmovaps [rsp+0xC0], xmm12
000071709abe0929  vmovaps [rsp+0xD0], xmm13
000071709abe0932  vmovaps [rsp+0xE0], xmm14
000071709abe093b  sub rsp, 0x30
000071709abe093f  movaps [rsp], xmm15
000071709abe0944  movaps [rsp+0x10], xmm11
000071709abe094a  movaps [rsp+0x20], xmm6
000071709abe094f  lea rdi, [rsp]
000071709abe0953  mov esi, 0x00
000071709abe0958  mov rax, 0x60B9B2ABC530
000071709abe0962  call rax
000071709abe0964  movaps xmm15, [rsp]
000071709abe0969  add rsp, 0x30
000071709abe096d  vmovaps xmm0, [rsp]
000071709abe0972  vmovaps xmm1, [rsp+0x10]
000071709abe0978  vmovaps xmm2, [rsp+0x20]
000071709abe097e  vmovaps xmm3, [rsp+0x30]
000071709abe0984  vmovaps xmm4, [rsp+0x40]
000071709abe098a  vmovaps xmm5, [rsp+0x50]
000071709abe0990  vmovaps xmm6, [rsp+0x60]
000071709abe0996  vmovaps xmm7, [rsp+0x70]
000071709abe099c  vmovaps xmm8, [rsp+0x80]
000071709abe09a5  vmovaps xmm9, [rsp+0x90]
000071709abe09ae  vmovaps xmm10, [rsp+0xA0]
000071709abe09b7  vmovaps xmm11, [rsp+0xB0]
000071709abe09c0  vmovaps xmm12, [rsp+0xC0]
000071709abe09c9  vmovaps xmm13, [rsp+0xD0]
000071709abe09d2  vmovaps xmm14, [rsp+0xE0]
000071709abe09db  add rsp, 0xF0
000071709abe09e2  pop r11
000071709abe09e4  pop r10
000071709abe09e6  pop r9
000071709abe09e8  pop r8
000071709abe09ea  pop rsi
000071709abe09eb  pop rdi
000071709abe09ec  pop rdx
000071709abe09ed  pop rcx
000071709abe09ee  pop rax
000071709abe09ef  add rsp, 0x08
000071709abe09f3  jmp 0x000071709ABDC658
000071709abe09f8  sub rsp, 0x08
000071709abe09fc  push rax
000071709abe09fd  push rcx
000071709abe09fe  push rdx
000071709abe09ff  push rdi
000071709abe0a00  push rsi
000071709abe0a01  push r8
000071709abe0a03  push r9
000071709abe0a05  push r10
000071709abe0a07  push r11
000071709abe0a09  sub rsp, 0xF0
000071709abe0a10  vmovaps [rsp], xmm0
000071709abe0a15  vmovaps [rsp+0x10], xmm1
000071709abe0a1b  vmovaps [rsp+0x20], xmm2
000071709abe0a21  vmovaps [rsp+0x30], xmm3
000071709abe0a27  vmovaps [rsp+0x40], xmm4
000071709abe0a2d  vmovaps [rsp+0x50], xmm5
000071709abe0a33  vmovaps [rsp+0x60], xmm6
000071709abe0a39  vmovaps [rsp+0x70], xmm8
000071709abe0a3f  vmovaps [rsp+0x80], xmm9
000071709abe0a48  vmovaps [rsp+0x90], xmm10
000071709abe0a51  vmovaps [rsp+0xA0], xmm11
000071709abe0a5a  vmovaps [rsp+0xB0], xmm12
000071709abe0a63  vmovaps [rsp+0xC0], xmm13
000071709abe0a6c  vmovaps [rsp+0xD0], xmm14
000071709abe0a75  vmovaps [rsp+0xE0], xmm15
000071709abe0a7e  sub rsp, 0x30
000071709abe0a82  movaps [rsp], xmm7
000071709abe0a86  movaps [rsp+0x10], xmm11
000071709abe0a8c  movaps [rsp+0x20], xmm9
000071709abe0a92  lea rdi, [rsp]
000071709abe0a96  mov esi, 0x00
000071709abe0a9b  mov rax, 0x60B9B2ABC530
000071709abe0aa5  call rax
000071709abe0aa7  movaps xmm7, [rsp]
000071709abe0aab  add rsp, 0x30
000071709abe0aaf  vmovaps xmm0, [rsp]
000071709abe0ab4  vmovaps xmm1, [rsp+0x10]
000071709abe0aba  vmovaps xmm2, [rsp+0x20]
000071709abe0ac0  vmovaps xmm3, [rsp+0x30]
000071709abe0ac6  vmovaps xmm4, [rsp+0x40]
000071709abe0acc  vmovaps xmm5, [rsp+0x50]
000071709abe0ad2  vmovaps xmm6, [rsp+0x60]
000071709abe0ad8  vmovaps xmm8, [rsp+0x70]
000071709abe0ade  vmovaps xmm9, [rsp+0x80]
000071709abe0ae7  vmovaps xmm10, [rsp+0x90]
000071709abe0af0  vmovaps xmm11, [rsp+0xA0]
000071709abe0af9  vmovaps xmm12, [rsp+0xB0]
000071709abe0b02  vmovaps xmm13, [rsp+0xC0]
000071709abe0b0b  vmovaps xmm14, [rsp+0xD0]
000071709abe0b14  vmovaps xmm15, [rsp+0xE0]
000071709abe0b1d  add rsp, 0xF0
000071709abe0b24  pop r11
000071709abe0b26  pop r10
000071709abe0b28  pop r9
000071709abe0b2a  pop r8
000071709abe0b2c  pop rsi
000071709abe0b2d  pop rdi
000071709abe0b2e  pop rdx
000071709abe0b2f  pop rcx
000071709abe0b30  pop rax
000071709abe0b31  add rsp, 0x08
000071709abe0b35  jmp 0x000071709ABDC685
000071709abe0b3a  sub rsp, 0x08
000071709abe0b3e  push rax
000071709abe0b3f  push rcx
000071709abe0b40  push rdx
000071709abe0b41  push rdi
000071709abe0b42  push rsi
000071709abe0b43  push r8
000071709abe0b45  push r9
000071709abe0b47  push r10
000071709abe0b49  push r11
000071709abe0b4b  sub rsp, 0xF0
000071709abe0b52  vmovaps [rsp], xmm0
000071709abe0b57  vmovaps [rsp+0x10], xmm1
000071709abe0b5d  vmovaps [rsp+0x20], xmm2
000071709abe0b63  vmovaps [rsp+0x30], xmm3
000071709abe0b69  vmovaps [rsp+0x40], xmm4
000071709abe0b6f  vmovaps [rsp+0x50], xmm5
000071709abe0b75  vmovaps [rsp+0x60], xmm6
000071709abe0b7b  vmovaps [rsp+0x70], xmm7
000071709abe0b81  vmovaps [rsp+0x80], xmm8
000071709abe0b8a  vmovaps [rsp+0x90], xmm9
000071709abe0b93  vmovaps [rsp+0xA0], xmm10
000071709abe0b9c  vmovaps [rsp+0xB0], xmm12
000071709abe0ba5  vmovaps [rsp+0xC0], xmm13
000071709abe0bae  vmovaps [rsp+0xD0], xmm14
000071709abe0bb7  vmovaps [rsp+0xE0], xmm15
000071709abe0bc0  sub rsp, 0x30
000071709abe0bc4  movaps [rsp], xmm11
000071709abe0bc9  movaps [rsp+0x10], xmm10
000071709abe0bcf  movaps [rsp+0x20], xmm14
000071709abe0bd5  lea rdi, [rsp]
000071709abe0bd9  mov esi, 0x00
000071709abe0bde  mov rax, 0x60B9B2ABC530
000071709abe0be8  call rax
000071709abe0bea  movaps xmm11, [rsp]
000071709abe0bef  add rsp, 0x30
000071709abe0bf3  vmovaps xmm0, [rsp]
000071709abe0bf8  vmovaps xmm1, [rsp+0x10]
000071709abe0bfe  vmovaps xmm2, [rsp+0x20]
000071709abe0c04  vmovaps xmm3, [rsp+0x30]
000071709abe0c0a  vmovaps xmm4, [rsp+0x40]
000071709abe0c10  vmovaps xmm5, [rsp+0x50]
000071709abe0c16  vmovaps xmm6, [rsp+0x60]
000071709abe0c1c  vmovaps xmm7, [rsp+0x70]
000071709abe0c22  vmovaps xmm8, [rsp+0x80]
000071709abe0c2b  vmovaps xmm9, [rsp+0x90]
000071709abe0c34  vmovaps xmm10, [rsp+0xA0]
000071709abe0c3d  vmovaps xmm12, [rsp+0xB0]
000071709abe0c46  vmovaps xmm13, [rsp+0xC0]
000071709abe0c4f  vmovaps xmm14, [rsp+0xD0]
000071709abe0c58  vmovaps xmm15, [rsp+0xE0]
000071709abe0c61  add rsp, 0xF0
000071709abe0c68  pop r11
000071709abe0c6a  pop r10
000071709abe0c6c  pop r9
000071709abe0c6e  pop r8
000071709abe0c70  pop rsi
000071709abe0c71  pop rdi
000071709abe0c72  pop rdx
000071709abe0c73  pop rcx
000071709abe0c74  pop rax
000071709abe0c75  add rsp, 0x08
000071709abe0c79  jmp 0x000071709ABDC6A0
000071709abe0c7e  call 0x000071709AAC33A0
000071709abe0c83  jmp 0x000071709ABDC6AA
000071709abe0c88  sub rsp, 0x08
000071709abe0c8c  push rax
000071709abe0c8d  push rcx
000071709abe0c8e  push rdx
000071709abe0c8f  push rdi
000071709abe0c90  push rsi
000071709abe0c91  push r8
000071709abe0c93  push r9
000071709abe0c95  push r10
000071709abe0c97  push r11
000071709abe0c99  sub rsp, 0xF0
000071709abe0ca0  vmovaps [rsp], xmm0
000071709abe0ca5  vmovaps [rsp+0x10], xmm1
000071709abe0cab  vmovaps [rsp+0x20], xmm2
000071709abe0cb1  vmovaps [rsp+0x30], xmm3
000071709abe0cb7  vmovaps [rsp+0x40], xmm4
000071709abe0cbd  vmovaps [rsp+0x50], xmm5
000071709abe0cc3  vmovaps [rsp+0x60], xmm6
000071709abe0cc9  vmovaps [rsp+0x70], xmm7
000071709abe0ccf  vmovaps [rsp+0x80], xmm8
000071709abe0cd8  vmovaps [rsp+0x90], xmm9
000071709abe0ce1  vmovaps [rsp+0xA0], xmm11
000071709abe0cea  vmovaps [rsp+0xB0], xmm12
000071709abe0cf3  vmovaps [rsp+0xC0], xmm13
000071709abe0cfc  vmovaps [rsp+0xD0], xmm14
000071709abe0d05  vmovaps [rsp+0xE0], xmm15
000071709abe0d0e  sub rsp, 0x30
000071709abe0d12  movaps [rsp], xmm10
000071709abe0d17  movaps [rsp+0x10], xmm1
000071709abe0d1c  movaps [rsp+0x20], xmm12
000071709abe0d22  lea rdi, [rsp]
000071709abe0d26  mov esi, 0x00
000071709abe0d2b  mov rax, 0x60B9B2ABC530
000071709abe0d35  call rax
000071709abe0d37  movaps xmm10, [rsp]
000071709abe0d3c  add rsp, 0x30
000071709abe0d40  vmovaps xmm0, [rsp]
000071709abe0d45  vmovaps xmm1, [rsp+0x10]
000071709abe0d4b  vmovaps xmm2, [rsp+0x20]
000071709abe0d51  vmovaps xmm3, [rsp+0x30]
000071709abe0d57  vmovaps xmm4, [rsp+0x40]
000071709abe0d5d  vmovaps xmm5, [rsp+0x50]
000071709abe0d63  vmovaps xmm6, [rsp+0x60]
000071709abe0d69  vmovaps xmm7, [rsp+0x70]
000071709abe0d6f  vmovaps xmm8, [rsp+0x80]
000071709abe0d78  vmovaps xmm9, [rsp+0x90]
000071709abe0d81  vmovaps xmm11, [rsp+0xA0]
000071709abe0d8a  vmovaps xmm12, [rsp+0xB0]
000071709abe0d93  vmovaps xmm13, [rsp+0xC0]
000071709abe0d9c  vmovaps xmm14, [rsp+0xD0]
000071709abe0da5  vmovaps xmm15, [rsp+0xE0]
000071709abe0dae  add rsp, 0xF0
000071709abe0db5  pop r11
000071709abe0db7  pop r10
000071709abe0db9  pop r9
000071709abe0dbb  pop r8
000071709abe0dbd  pop rsi
000071709abe0dbe  pop rdi
000071709abe0dbf  pop rdx
000071709abe0dc0  pop rcx
000071709abe0dc1  pop rax
000071709abe0dc2  add rsp, 0x08
000071709abe0dc6  jmp 0x000071709ABDC6CD
000071709abe0dcb  sub rsp, 0x08
000071709abe0dcf  push rax
000071709abe0dd0  push rcx
000071709abe0dd1  push rdx
000071709abe0dd2  push rdi
000071709abe0dd3  push rsi
000071709abe0dd4  push r8
000071709abe0dd6  push r9
000071709abe0dd8  push r10
000071709abe0dda  push r11
000071709abe0ddc  sub rsp, 0xF0
000071709abe0de3  vmovaps [rsp], xmm0
000071709abe0de8  vmovaps [rsp+0x10], xmm1
000071709abe0dee  vmovaps [rsp+0x20], xmm2
000071709abe0df4  vmovaps [rsp+0x30], xmm3
000071709abe0dfa  vmovaps [rsp+0x40], xmm4
000071709abe0e00  vmovaps [rsp+0x50], xmm5
000071709abe0e06  vmovaps [rsp+0x60], xmm6
000071709abe0e0c  vmovaps [rsp+0x70], xmm7
000071709abe0e12  vmovaps [rsp+0x80], xmm8
000071709abe0e1b  vmovaps [rsp+0x90], xmm9
000071709abe0e24  vmovaps [rsp+0xA0], xmm10
000071709abe0e2d  vmovaps [rsp+0xB0], xmm11
000071709abe0e36  vmovaps [rsp+0xC0], xmm13
000071709abe0e3f  vmovaps [rsp+0xD0], xmm14
000071709abe0e48  vmovaps [rsp+0xE0], xmm15
000071709abe0e51  sub rsp, 0x30
000071709abe0e55  movaps [rsp], xmm12
000071709abe0e5a  movaps [rsp+0x10], xmm14
000071709abe0e60  movaps [rsp+0x20], xmm1
000071709abe0e65  lea rdi, [rsp]
000071709abe0e69  mov esi, 0x00
000071709abe0e6e  mov rax, 0x60B9B2ABC530
000071709abe0e78  call rax
000071709abe0e7a  movaps xmm12, [rsp]
000071709abe0e7f  add rsp, 0x30
000071709abe0e83  vmovaps xmm0, [rsp]
000071709abe0e88  vmovaps xmm1, [rsp+0x10]
000071709abe0e8e  vmovaps xmm2, [rsp+0x20]
000071709abe0e94  vmovaps xmm3, [rsp+0x30]
000071709abe0e9a  vmovaps xmm4, [rsp+0x40]
000071709abe0ea0  vmovaps xmm5, [rsp+0x50]
000071709abe0ea6  vmovaps xmm6, [rsp+0x60]
000071709abe0eac  vmovaps xmm7, [rsp+0x70]
000071709abe0eb2  vmovaps xmm8, [rsp+0x80]
000071709abe0ebb  vmovaps xmm9, [rsp+0x90]
000071709abe0ec4  vmovaps xmm10, [rsp+0xA0]
000071709abe0ecd  vmovaps xmm11, [rsp+0xB0]
000071709abe0ed6  vmovaps xmm13, [rsp+0xC0]
000071709abe0edf  vmovaps xmm14, [rsp+0xD0]
000071709abe0ee8  vmovaps xmm15, [rsp+0xE0]
000071709abe0ef1  add rsp, 0xF0
000071709abe0ef8  pop r11
000071709abe0efa  pop r10
000071709abe0efc  pop r9
000071709abe0efe  pop r8
000071709abe0f00  pop rsi
000071709abe0f01  pop rdi
000071709abe0f02  pop rdx
000071709abe0f03  pop rcx
000071709abe0f04  pop rax
000071709abe0f05  add rsp, 0x08
000071709abe0f09  jmp 0x000071709ABDC6FC
000071709abe0f0e  sub rsp, 0x08
000071709abe0f12  push rax
000071709abe0f13  push rcx
000071709abe0f14  push rdx
000071709abe0f15  push rdi
000071709abe0f16  push rsi
000071709abe0f17  push r8
000071709abe0f19  push r9
000071709abe0f1b  push r10
000071709abe0f1d  push r11
000071709abe0f1f  sub rsp, 0xF0
000071709abe0f26  vmovaps [rsp], xmm0
000071709abe0f2b  vmovaps [rsp+0x10], xmm1
000071709abe0f31  vmovaps [rsp+0x20], xmm2
000071709abe0f37  vmovaps [rsp+0x30], xmm3
000071709abe0f3d  vmovaps [rsp+0x40], xmm4
000071709abe0f43  vmovaps [rsp+0x50], xmm5
000071709abe0f49  vmovaps [rsp+0x60], xmm6
000071709abe0f4f  vmovaps [rsp+0x70], xmm7
000071709abe0f55  vmovaps [rsp+0x80], xmm8
000071709abe0f5e  vmovaps [rsp+0x90], xmm9
000071709abe0f67  vmovaps [rsp+0xA0], xmm10
000071709abe0f70  vmovaps [rsp+0xB0], xmm11
000071709abe0f79  vmovaps [rsp+0xC0], xmm12
000071709abe0f82  vmovaps [rsp+0xD0], xmm13
000071709abe0f8b  vmovaps [rsp+0xE0], xmm15
000071709abe0f94  sub rsp, 0x30
000071709abe0f98  movaps [rsp], xmm14
000071709abe0f9d  movaps [rsp+0x10], xmm9
000071709abe0fa3  movaps [rsp+0x20], xmm1
000071709abe0fa8  lea rdi, [rsp]
000071709abe0fac  mov esi, 0x00
000071709abe0fb1  mov rax, 0x60B9B2ABC530
000071709abe0fbb  call rax
000071709abe0fbd  movaps xmm14, [rsp]
000071709abe0fc2  add rsp, 0x30
000071709abe0fc6  vmovaps xmm0, [rsp]
000071709abe0fcb  vmovaps xmm1, [rsp+0x10]
000071709abe0fd1  vmovaps xmm2, [rsp+0x20]
000071709abe0fd7  vmovaps xmm3, [rsp+0x30]
000071709abe0fdd  vmovaps xmm4, [rsp+0x40]
000071709abe0fe3  vmovaps xmm5, [rsp+0x50]
000071709abe0fe9  vmovaps xmm6, [rsp+0x60]
000071709abe0fef  vmovaps xmm7, [rsp+0x70]
000071709abe0ff5  vmovaps xmm8, [rsp+0x80]
000071709abe0ffe  vmovaps xmm9, [rsp+0x90]
000071709abe1007  vmovaps xmm10, [rsp+0xA0]
000071709abe1010  vmovaps xmm11, [rsp+0xB0]
000071709abe1019  vmovaps xmm12, [rsp+0xC0]
000071709abe1022  vmovaps xmm13, [rsp+0xD0]
000071709abe102b  vmovaps xmm15, [rsp+0xE0]
000071709abe1034  add rsp, 0xF0
000071709abe103b  pop r11
000071709abe103d  pop r10
000071709abe103f  pop r9
000071709abe1041  pop r8
000071709abe1043  pop rsi
000071709abe1044  pop rdi
000071709abe1045  pop rdx
000071709abe1046  pop rcx
000071709abe1047  pop rax
000071709abe1048  add rsp, 0x08
000071709abe104c  jmp 0x000071709ABDC72B
000071709abe1051  sub rsp, 0x08
000071709abe1055  push rax
000071709abe1056  push rcx
000071709abe1057  push rdx
000071709abe1058  push rdi
000071709abe1059  push rsi
000071709abe105a  push r8
000071709abe105c  push r9
000071709abe105e  push r10
000071709abe1060  push r11
000071709abe1062  sub rsp, 0xF0
000071709abe1069  vmovaps [rsp], xmm0
000071709abe106e  vmovaps [rsp+0x10], xmm2
000071709abe1074  vmovaps [rsp+0x20], xmm3
000071709abe107a  vmovaps [rsp+0x30], xmm4
000071709abe1080  vmovaps [rsp+0x40], xmm5
000071709abe1086  vmovaps [rsp+0x50], xmm6
000071709abe108c  vmovaps [rsp+0x60], xmm7
000071709abe1092  vmovaps [rsp+0x70], xmm8
000071709abe1098  vmovaps [rsp+0x80], xmm9
000071709abe10a1  vmovaps [rsp+0x90], xmm10
000071709abe10aa  vmovaps [rsp+0xA0], xmm11
000071709abe10b3  vmovaps [rsp+0xB0], xmm12
000071709abe10bc  vmovaps [rsp+0xC0], xmm13
000071709abe10c5  vmovaps [rsp+0xD0], xmm14
000071709abe10ce  vmovaps [rsp+0xE0], xmm15
000071709abe10d7  sub rsp, 0x30
000071709abe10db  movaps [rsp], xmm1
000071709abe10df  movaps [rsp+0x10], xmm13
000071709abe10e5  movaps [rsp+0x20], xmm8
000071709abe10eb  lea rdi, [rsp]
000071709abe10ef  mov esi, 0x00
000071709abe10f4  mov rax, 0x60B9B2ABC530
000071709abe10fe  call rax
000071709abe1100  movaps xmm1, [rsp]
000071709abe1104  add rsp, 0x30
000071709abe1108  vmovaps xmm0, [rsp]
000071709abe110d  vmovaps xmm2, [rsp+0x10]
000071709abe1113  vmovaps xmm3, [rsp+0x20]
000071709abe1119  vmovaps xmm4, [rsp+0x30]
000071709abe111f  vmovaps xmm5, [rsp+0x40]
000071709abe1125  vmovaps xmm6, [rsp+0x50]
000071709abe112b  vmovaps xmm7, [rsp+0x60]
000071709abe1131  vmovaps xmm8, [rsp+0x70]
000071709abe1137  vmovaps xmm9, [rsp+0x80]
000071709abe1140  vmovaps xmm10, [rsp+0x90]
000071709abe1149  vmovaps xmm11, [rsp+0xA0]
000071709abe1152  vmovaps xmm12, [rsp+0xB0]
000071709abe115b  vmovaps xmm13, [rsp+0xC0]
000071709abe1164  vmovaps xmm14, [rsp+0xD0]
000071709abe116d  vmovaps xmm15, [rsp+0xE0]
000071709abe1176  add rsp, 0xF0
000071709abe117d  pop r11
000071709abe117f  pop r10
000071709abe1181  pop r9
000071709abe1183  pop r8
000071709abe1185  pop rsi
000071709abe1186  pop rdi
000071709abe1187  pop rdx
000071709abe1188  pop rcx
000071709abe1189  pop rax
000071709abe118a  add rsp, 0x08
000071709abe118e  jmp 0x000071709ABDC74D
000071709abe1193  call 0x000071709AA0C260
000071709abe1198  jmp 0x000071709ABDC75B
000071709abe119d  call 0x000071709AABD750
000071709abe11a2  jmp 0x000071709ABDC765
000071709abe11a7  sub rsp, 0x08
000071709abe11ab  push rax
000071709abe11ac  push rcx
000071709abe11ad  push rdx
000071709abe11ae  push rdi
000071709abe11af  push rsi
000071709abe11b0  push r8
000071709abe11b2  push r9
000071709abe11b4  push r10
000071709abe11b6  push r11
000071709abe11b8  sub rsp, 0xF0
000071709abe11bf  vmovaps [rsp], xmm0
000071709abe11c4  vmovaps [rsp+0x10], xmm1
000071709abe11ca  vmovaps [rsp+0x20], xmm2
000071709abe11d0  vmovaps [rsp+0x30], xmm3
000071709abe11d6  vmovaps [rsp+0x40], xmm4
000071709abe11dc  vmovaps [rsp+0x50], xmm5
000071709abe11e2  vmovaps [rsp+0x60], xmm6
000071709abe11e8  vmovaps [rsp+0x70], xmm7
000071709abe11ee  vmovaps [rsp+0x80], xmm9
000071709abe11f7  vmovaps [rsp+0x90], xmm10
000071709abe1200  vmovaps [rsp+0xA0], xmm11
000071709abe1209  vmovaps [rsp+0xB0], xmm12
000071709abe1212  vmovaps [rsp+0xC0], xmm13
000071709abe121b  vmovaps [rsp+0xD0], xmm14
000071709abe1224  vmovaps [rsp+0xE0], xmm15
000071709abe122d  sub rsp, 0x30
000071709abe1231  movaps [rsp], xmm8
000071709abe1236  movaps [rsp+0x10], xmm15
000071709abe123c  movaps [rsp+0x20], xmm7
000071709abe1241  lea rdi, [rsp]
000071709abe1245  mov esi, 0x00
000071709abe124a  mov rax, 0x60B9B2ABC530
000071709abe1254  call rax
000071709abe1256  movaps xmm8, [rsp]
000071709abe125b  add rsp, 0x30
000071709abe125f  vmovaps xmm0, [rsp]
000071709abe1264  vmovaps xmm1, [rsp+0x10]
000071709abe126a  vmovaps xmm2, [rsp+0x20]
000071709abe1270  vmovaps xmm3, [rsp+0x30]
000071709abe1276  vmovaps xmm4, [rsp+0x40]
000071709abe127c  vmovaps xmm5, [rsp+0x50]
000071709abe1282  vmovaps xmm6, [rsp+0x60]
000071709abe1288  vmovaps xmm7, [rsp+0x70]
000071709abe128e  vmovaps xmm9, [rsp+0x80]
000071709abe1297  vmovaps xmm10, [rsp+0x90]
000071709abe12a0  vmovaps xmm11, [rsp+0xA0]
000071709abe12a9  vmovaps xmm12, [rsp+0xB0]
000071709abe12b2  vmovaps xmm13, [rsp+0xC0]
000071709abe12bb  vmovaps xmm14, [rsp+0xD0]
000071709abe12c4  vmovaps xmm15, [rsp+0xE0]
000071709abe12cd  add rsp, 0xF0
000071709abe12d4  pop r11
000071709abe12d6  pop r10
000071709abe12d8  pop r9
000071709abe12da  pop r8
000071709abe12dc  pop rsi
000071709abe12dd  pop rdi
000071709abe12de  pop rdx
000071709abe12df  pop rcx
000071709abe12e0  pop rax
000071709abe12e1  add rsp, 0x08
000071709abe12e5  jmp 0x000071709ABDC787
000071709abe12ea  sub rsp, 0x08
000071709abe12ee  push rax
000071709abe12ef  push rcx
000071709abe12f0  push rdx
000071709abe12f1  push rdi
000071709abe12f2  push rsi
000071709abe12f3  push r8
000071709abe12f5  push r9
000071709abe12f7  push r10
000071709abe12f9  push r11
000071709abe12fb  sub rsp, 0xF0
000071709abe1302  vmovaps [rsp], xmm0
000071709abe1307  vmovaps [rsp+0x10], xmm1
000071709abe130d  vmovaps [rsp+0x20], xmm2
000071709abe1313  vmovaps [rsp+0x30], xmm3
000071709abe1319  vmovaps [rsp+0x40], xmm4
000071709abe131f  vmovaps [rsp+0x50], xmm5
000071709abe1325  vmovaps [rsp+0x60], xmm6
000071709abe132b  vmovaps [rsp+0x70], xmm8
000071709abe1331  vmovaps [rsp+0x80], xmm9
000071709abe133a  vmovaps [rsp+0x90], xmm10
000071709abe1343  vmovaps [rsp+0xA0], xmm11
000071709abe134c  vmovaps [rsp+0xB0], xmm12
000071709abe1355  vmovaps [rsp+0xC0], xmm13
000071709abe135e  vmovaps [rsp+0xD0], xmm14
000071709abe1367  vmovaps [rsp+0xE0], xmm15
000071709abe1370  sub rsp, 0x30
000071709abe1374  movaps [rsp], xmm7
000071709abe1378  movaps [rsp+0x10], xmm9
000071709abe137e  movaps [rsp+0x20], xmm15
000071709abe1384  lea rdi, [rsp]
000071709abe1388  mov esi, 0x00
000071709abe138d  mov rax, 0x60B9B2ABC530
000071709abe1397  call rax
000071709abe1399  movaps xmm7, [rsp]
000071709abe139d  add rsp, 0x30
000071709abe13a1  vmovaps xmm0, [rsp]
000071709abe13a6  vmovaps xmm1, [rsp+0x10]
000071709abe13ac  vmovaps xmm2, [rsp+0x20]
000071709abe13b2  vmovaps xmm3, [rsp+0x30]
000071709abe13b8  vmovaps xmm4, [rsp+0x40]
000071709abe13be  vmovaps xmm5, [rsp+0x50]
000071709abe13c4  vmovaps xmm6, [rsp+0x60]
000071709abe13ca  vmovaps xmm8, [rsp+0x70]
000071709abe13d0  vmovaps xmm9, [rsp+0x80]
000071709abe13d9  vmovaps xmm10, [rsp+0x90]
000071709abe13e2  vmovaps xmm11, [rsp+0xA0]
000071709abe13eb  vmovaps xmm12, [rsp+0xB0]
000071709abe13f4  vmovaps xmm13, [rsp+0xC0]
000071709abe13fd  vmovaps xmm14, [rsp+0xD0]
000071709abe1406  vmovaps xmm15, [rsp+0xE0]
000071709abe140f  add rsp, 0xF0
000071709abe1416  pop r11
000071709abe1418  pop r10
000071709abe141a  pop r9
000071709abe141c  pop r8
000071709abe141e  pop rsi
000071709abe141f  pop rdi
000071709abe1420  pop rdx
000071709abe1421  pop rcx
000071709abe1422  pop rax
000071709abe1423  add rsp, 0x08
000071709abe1427  jmp 0x000071709ABDC7B4
000071709abe142c  sub rsp, 0x08
000071709abe1430  push rax
000071709abe1431  push rcx
000071709abe1432  push rdx
000071709abe1433  push rdi
000071709abe1434  push rsi
000071709abe1435  push r8
000071709abe1437  push r9
000071709abe1439  push r10
000071709abe143b  push r11
000071709abe143d  sub rsp, 0xF0
000071709abe1444  vmovaps [rsp], xmm0
000071709abe1449  vmovaps [rsp+0x10], xmm1
000071709abe144f  vmovaps [rsp+0x20], xmm2
000071709abe1455  vmovaps [rsp+0x30], xmm3
000071709abe145b  vmovaps [rsp+0x40], xmm4
000071709abe1461  vmovaps [rsp+0x50], xmm5
000071709abe1467  vmovaps [rsp+0x60], xmm6
000071709abe146d  vmovaps [rsp+0x70], xmm7
000071709abe1473  vmovaps [rsp+0x80], xmm8
000071709abe147c  vmovaps [rsp+0x90], xmm10
000071709abe1485  vmovaps [rsp+0xA0], xmm11
000071709abe148e  vmovaps [rsp+0xB0], xmm12
000071709abe1497  vmovaps [rsp+0xC0], xmm13
000071709abe14a0  vmovaps [rsp+0xD0], xmm14
000071709abe14a9  vmovaps [rsp+0xE0], xmm15
000071709abe14b2  sub rsp, 0x30
000071709abe14b6  movaps [rsp], xmm9
000071709abe14bb  movaps [rsp+0x10], xmm13
000071709abe14c1  movaps [rsp+0x20], xmm15
000071709abe14c7  lea rdi, [rsp]
000071709abe14cb  mov esi, 0x00
000071709abe14d0  mov rax, 0x60B9B2ABC530
000071709abe14da  call rax
000071709abe14dc  movaps xmm9, [rsp]
000071709abe14e1  add rsp, 0x30
000071709abe14e5  vmovaps xmm0, [rsp]
000071709abe14ea  vmovaps xmm1, [rsp+0x10]
000071709abe14f0  vmovaps xmm2, [rsp+0x20]
000071709abe14f6  vmovaps xmm3, [rsp+0x30]
000071709abe14fc  vmovaps xmm4, [rsp+0x40]
000071709abe1502  vmovaps xmm5, [rsp+0x50]
000071709abe1508  vmovaps xmm6, [rsp+0x60]
000071709abe150e  vmovaps xmm7, [rsp+0x70]
000071709abe1514  vmovaps xmm8, [rsp+0x80]
000071709abe151d  vmovaps xmm10, [rsp+0x90]
000071709abe1526  vmovaps xmm11, [rsp+0xA0]
000071709abe152f  vmovaps xmm12, [rsp+0xB0]
000071709abe1538  vmovaps xmm13, [rsp+0xC0]
000071709abe1541  vmovaps xmm14, [rsp+0xD0]
000071709abe154a  vmovaps xmm15, [rsp+0xE0]
000071709abe1553  add rsp, 0xF0
000071709abe155a  pop r11
000071709abe155c  pop r10
000071709abe155e  pop r9
000071709abe1560  pop r8
000071709abe1562  pop rsi
000071709abe1563  pop rdi
000071709abe1564  pop rdx
000071709abe1565  pop rcx
000071709abe1566  pop rax
000071709abe1567  add rsp, 0x08
000071709abe156b  jmp 0x000071709ABDC7E2
000071709abe1570  sub rsp, 0x08
000071709abe1574  push rax
000071709abe1575  push rcx
000071709abe1576  push rdx
000071709abe1577  push rdi
000071709abe1578  push rsi
000071709abe1579  push r8
000071709abe157b  push r9
000071709abe157d  push r10
000071709abe157f  push r11
000071709abe1581  sub rsp, 0xF0
000071709abe1588  vmovaps [rsp], xmm0
000071709abe158d  vmovaps [rsp+0x10], xmm1
000071709abe1593  vmovaps [rsp+0x20], xmm2
000071709abe1599  vmovaps [rsp+0x30], xmm3
000071709abe159f  vmovaps [rsp+0x40], xmm4
000071709abe15a5  vmovaps [rsp+0x50], xmm5
000071709abe15ab  vmovaps [rsp+0x60], xmm6
000071709abe15b1  vmovaps [rsp+0x70], xmm7
000071709abe15b7  vmovaps [rsp+0x80], xmm8
000071709abe15c0  vmovaps [rsp+0x90], xmm9
000071709abe15c9  vmovaps [rsp+0xA0], xmm10
000071709abe15d2  vmovaps [rsp+0xB0], xmm11
000071709abe15db  vmovaps [rsp+0xC0], xmm12
000071709abe15e4  vmovaps [rsp+0xD0], xmm13
000071709abe15ed  vmovaps [rsp+0xE0], xmm14
000071709abe15f6  sub rsp, 0x30
000071709abe15fa  movaps [rsp], xmm15
000071709abe15ff  movaps [rsp+0x10], xmm11
000071709abe1605  movaps [rsp+0x20], xmm12
000071709abe160b  lea rdi, [rsp]
000071709abe160f  mov esi, 0x00
000071709abe1614  mov rax, 0x60B9B2ABC530
000071709abe161e  call rax
000071709abe1620  movaps xmm15, [rsp]
000071709abe1625  add rsp, 0x30
000071709abe1629  vmovaps xmm0, [rsp]
000071709abe162e  vmovaps xmm1, [rsp+0x10]
000071709abe1634  vmovaps xmm2, [rsp+0x20]
000071709abe163a  vmovaps xmm3, [rsp+0x30]
000071709abe1640  vmovaps xmm4, [rsp+0x40]
000071709abe1646  vmovaps xmm5, [rsp+0x50]
000071709abe164c  vmovaps xmm6, [rsp+0x60]
000071709abe1652  vmovaps xmm7, [rsp+0x70]
000071709abe1658  vmovaps xmm8, [rsp+0x80]
000071709abe1661  vmovaps xmm9, [rsp+0x90]
000071709abe166a  vmovaps xmm10, [rsp+0xA0]
000071709abe1673  vmovaps xmm11, [rsp+0xB0]
000071709abe167c  vmovaps xmm12, [rsp+0xC0]
000071709abe1685  vmovaps xmm13, [rsp+0xD0]
000071709abe168e  vmovaps xmm14, [rsp+0xE0]
000071709abe1697  add rsp, 0xF0
000071709abe169e  pop r11
000071709abe16a0  pop r10
000071709abe16a2  pop r9
000071709abe16a4  pop r8
000071709abe16a6  pop rsi
000071709abe16a7  pop rdi
000071709abe16a8  pop rdx
000071709abe16a9  pop rcx
000071709abe16aa  pop rax
000071709abe16ab  add rsp, 0x08
000071709abe16af  jmp 0x000071709ABDC7FD
000071709abe16b4  sub rsp, 0x08
000071709abe16b8  push rax
000071709abe16b9  push rcx
000071709abe16ba  push rdx
000071709abe16bb  push rdi
000071709abe16bc  push rsi
000071709abe16bd  push r8
000071709abe16bf  push r9
000071709abe16c1  push r10
000071709abe16c3  push r11
000071709abe16c5  sub rsp, 0xF0
000071709abe16cc  vmovaps [rsp], xmm0
000071709abe16d1  vmovaps [rsp+0x10], xmm1
000071709abe16d7  vmovaps [rsp+0x20], xmm2
000071709abe16dd  vmovaps [rsp+0x30], xmm3
000071709abe16e3  vmovaps [rsp+0x40], xmm4
000071709abe16e9  vmovaps [rsp+0x50], xmm5
000071709abe16ef  vmovaps [rsp+0x60], xmm6
000071709abe16f5  vmovaps [rsp+0x70], xmm7
000071709abe16fb  vmovaps [rsp+0x80], xmm8
000071709abe1704  vmovaps [rsp+0x90], xmm9
000071709abe170d  vmovaps [rsp+0xA0], xmm10
000071709abe1716  vmovaps [rsp+0xB0], xmm11
000071709abe171f  vmovaps [rsp+0xC0], xmm12
000071709abe1728  vmovaps [rsp+0xD0], xmm14
000071709abe1731  vmovaps [rsp+0xE0], xmm15
000071709abe173a  sub rsp, 0x30
000071709abe173e  movaps [rsp], xmm13
000071709abe1743  movaps [rsp+0x10], xmm10
000071709abe1749  movaps [rsp+0x20], xmm14
000071709abe174f  lea rdi, [rsp]
000071709abe1753  mov esi, 0x00
000071709abe1758  mov rax, 0x60B9B2ABC530
000071709abe1762  call rax
000071709abe1764  movaps xmm13, [rsp]
000071709abe1769  add rsp, 0x30
000071709abe176d  vmovaps xmm0, [rsp]
000071709abe1772  vmovaps xmm1, [rsp+0x10]
000071709abe1778  vmovaps xmm2, [rsp+0x20]
000071709abe177e  vmovaps xmm3, [rsp+0x30]
000071709abe1784  vmovaps xmm4, [rsp+0x40]
000071709abe178a  vmovaps xmm5, [rsp+0x50]
000071709abe1790  vmovaps xmm6, [rsp+0x60]
000071709abe1796  vmovaps xmm7, [rsp+0x70]
000071709abe179c  vmovaps xmm8, [rsp+0x80]
000071709abe17a5  vmovaps xmm9, [rsp+0x90]
000071709abe17ae  vmovaps xmm10, [rsp+0xA0]
000071709abe17b7  vmovaps xmm11, [rsp+0xB0]
000071709abe17c0  vmovaps xmm12, [rsp+0xC0]
000071709abe17c9  vmovaps xmm14, [rsp+0xD0]
000071709abe17d2  vmovaps xmm15, [rsp+0xE0]
000071709abe17db  add rsp, 0xF0
000071709abe17e2  pop r11
000071709abe17e4  pop r10
000071709abe17e6  pop r9
000071709abe17e8  pop r8
000071709abe17ea  pop rsi
000071709abe17eb  pop rdi
000071709abe17ec  pop rdx
000071709abe17ed  pop rcx
000071709abe17ee  pop rax
000071709abe17ef  add rsp, 0x08
000071709abe17f3  jmp 0x000071709ABDC820
000071709abe17f8  sub rsp, 0x08
000071709abe17fc  push rax
000071709abe17fd  push rcx
000071709abe17fe  push rdx
000071709abe17ff  push rdi
000071709abe1800  push rsi
000071709abe1801  push r8
000071709abe1803  push r9
000071709abe1805  push r10
000071709abe1807  push r11
000071709abe1809  sub rsp, 0xF0
000071709abe1810  vmovaps [rsp], xmm0
000071709abe1815  vmovaps [rsp+0x10], xmm1
000071709abe181b  vmovaps [rsp+0x20], xmm2
000071709abe1821  vmovaps [rsp+0x30], xmm3
000071709abe1827  vmovaps [rsp+0x40], xmm4
000071709abe182d  vmovaps [rsp+0x50], xmm5
000071709abe1833  vmovaps [rsp+0x60], xmm6
000071709abe1839  vmovaps [rsp+0x70], xmm7
000071709abe183f  vmovaps [rsp+0x80], xmm8
000071709abe1848  vmovaps [rsp+0x90], xmm9
000071709abe1851  vmovaps [rsp+0xA0], xmm10
000071709abe185a  vmovaps [rsp+0xB0], xmm11
000071709abe1863  vmovaps [rsp+0xC0], xmm12
000071709abe186c  vmovaps [rsp+0xD0], xmm13
000071709abe1875  vmovaps [rsp+0xE0], xmm15
000071709abe187e  sub rsp, 0x30
000071709abe1882  movaps [rsp], xmm14
000071709abe1887  movaps [rsp+0x10], xmm1
000071709abe188c  movaps [rsp+0x20], xmm7
000071709abe1891  lea rdi, [rsp]
000071709abe1895  mov esi, 0x00
000071709abe189a  mov rax, 0x60B9B2ABC530
000071709abe18a4  call rax
000071709abe18a6  movaps xmm14, [rsp]
000071709abe18ab  add rsp, 0x30
000071709abe18af  vmovaps xmm0, [rsp]
000071709abe18b4  vmovaps xmm1, [rsp+0x10]
000071709abe18ba  vmovaps xmm2, [rsp+0x20]
000071709abe18c0  vmovaps xmm3, [rsp+0x30]
000071709abe18c6  vmovaps xmm4, [rsp+0x40]
000071709abe18cc  vmovaps xmm5, [rsp+0x50]
000071709abe18d2  vmovaps xmm6, [rsp+0x60]
000071709abe18d8  vmovaps xmm7, [rsp+0x70]
000071709abe18de  vmovaps xmm8, [rsp+0x80]
000071709abe18e7  vmovaps xmm9, [rsp+0x90]
000071709abe18f0  vmovaps xmm10, [rsp+0xA0]
000071709abe18f9  vmovaps xmm11, [rsp+0xB0]
000071709abe1902  vmovaps xmm12, [rsp+0xC0]
000071709abe190b  vmovaps xmm13, [rsp+0xD0]
000071709abe1914  vmovaps xmm15, [rsp+0xE0]
000071709abe191d  add rsp, 0xF0
000071709abe1924  pop r11
000071709abe1926  pop r10
000071709abe1928  pop r9
000071709abe192a  pop r8
000071709abe192c  pop rsi
000071709abe192d  pop rdi
000071709abe192e  pop rdx
000071709abe192f  pop rcx
000071709abe1930  pop rax
000071709abe1931  add rsp, 0x08
000071709abe1935  jmp 0x000071709ABDC843
000071709abe193a  sub rsp, 0x08
000071709abe193e  push rax
000071709abe193f  push rcx
000071709abe1940  push rdx
000071709abe1941  push rdi
000071709abe1942  push rsi
000071709abe1943  push r8
000071709abe1945  push r9
000071709abe1947  push r10
000071709abe1949  push r11
000071709abe194b  sub rsp, 0xF0
000071709abe1952  vmovaps [rsp], xmm0
000071709abe1957  vmovaps [rsp+0x10], xmm2
000071709abe195d  vmovaps [rsp+0x20], xmm3
000071709abe1963  vmovaps [rsp+0x30], xmm4
000071709abe1969  vmovaps [rsp+0x40], xmm5
000071709abe196f  vmovaps [rsp+0x50], xmm6
000071709abe1975  vmovaps [rsp+0x60], xmm7
000071709abe197b  vmovaps [rsp+0x70], xmm8
000071709abe1981  vmovaps [rsp+0x80], xmm9
000071709abe198a  vmovaps [rsp+0x90], xmm10
000071709abe1993  vmovaps [rsp+0xA0], xmm11
000071709abe199c  vmovaps [rsp+0xB0], xmm12
000071709abe19a5  vmovaps [rsp+0xC0], xmm13
000071709abe19ae  vmovaps [rsp+0xD0], xmm14
000071709abe19b7  vmovaps [rsp+0xE0], xmm15
000071709abe19c0  sub rsp, 0x30
000071709abe19c4  movaps [rsp], xmm1
000071709abe19c8  movaps [rsp+0x10], xmm8
000071709abe19ce  movaps [rsp+0x20], xmm9
000071709abe19d4  lea rdi, [rsp]
000071709abe19d8  mov esi, 0x00
000071709abe19dd  mov rax, 0x60B9B2ABC530
000071709abe19e7  call rax
000071709abe19e9  movaps xmm1, [rsp]
000071709abe19ed  add rsp, 0x30
000071709abe19f1  vmovaps xmm0, [rsp]
000071709abe19f6  vmovaps xmm2, [rsp+0x10]
000071709abe19fc  vmovaps xmm3, [rsp+0x20]
000071709abe1a02  vmovaps xmm4, [rsp+0x30]
000071709abe1a08  vmovaps xmm5, [rsp+0x40]
000071709abe1a0e  vmovaps xmm6, [rsp+0x50]
000071709abe1a14  vmovaps xmm7, [rsp+0x60]
000071709abe1a1a  vmovaps xmm8, [rsp+0x70]
000071709abe1a20  vmovaps xmm9, [rsp+0x80]
000071709abe1a29  vmovaps xmm10, [rsp+0x90]
000071709abe1a32  vmovaps xmm11, [rsp+0xA0]
000071709abe1a3b  vmovaps xmm12, [rsp+0xB0]
000071709abe1a44  vmovaps xmm13, [rsp+0xC0]
000071709abe1a4d  vmovaps xmm14, [rsp+0xD0]
000071709abe1a56  vmovaps xmm15, [rsp+0xE0]
000071709abe1a5f  add rsp, 0xF0
000071709abe1a66  pop r11
000071709abe1a68  pop r10
000071709abe1a6a  pop r9
000071709abe1a6c  pop r8
000071709abe1a6e  pop rsi
000071709abe1a6f  pop rdi
000071709abe1a70  pop rdx
000071709abe1a71  pop rcx
000071709abe1a72  pop rax
000071709abe1a73  add rsp, 0x08
000071709abe1a77  jmp 0x000071709ABDC865
000071709abe1a7c  call 0x000071709AAE5940
000071709abe1a81  jmp 0x000071709ABDC873
000071709abe1a86  call 0x000071709AA0C380
000071709abe1a8b  jmp 0x000071709ABDC87D
000071709abe1a90  call 0x000071709AA0D600
000071709abe1a95  jmp 0x000071709ABDC887
000071709abe1a9a  call 0x000071709A9FF540
000071709abe1a9f  jmp 0x000071709ABDC891
000071709abe1aa4  int3
000071709abe1aa5  nop [rax+rax*1], ax
000071709abe1aae  nop
000071709abe1ab0  mov rax, [r15+0xF8]
000071709abe1ab7  lea r14, [rax+0x140]
000071709abe1abe  mov r12, [r13+r14*1]
000071709abe1ac3  mov [r15+0xE8], r12
000071709abe1aca  lea r14, [rax+0x130]
000071709abe1ad1  mov r12, [r13+r14*1]
000071709abe1ad6  lea r14, [rax+0x138]
000071709abe1add  mov r11, [r13+r14*1]
000071709abe1ae2  movq xmm1, r12
000071709abe1ae7  movq xmm15, r11
000071709abe1aec  movq xmm1, xmm1
000071709abe1af0  movq xmm1, xmm1
000071709abe1af4  movaps [r15+0x1A0], xmm1
000071709abe1afc  movq xmm15, xmm15
000071709abe1b01  movq xmm15, xmm15
000071709abe1b06  movaps [r15+0x190], xmm15
000071709abe1b0e  lea r14, [rax+0x120]
000071709abe1b15  mov r12, [r13+r14*1]
000071709abe1b1a  lea r14, [rax+0x128]
000071709abe1b21  mov r11, [r13+r14*1]
000071709abe1b26  movq xmm1, r12
000071709abe1b2b  movq xmm15, r11
000071709abe1b30  movq xmm1, xmm1
000071709abe1b34  movq xmm1, xmm1
000071709abe1b38  movaps [r15+0x1C0], xmm1
000071709abe1b40  movq xmm15, xmm15
000071709abe1b45  movq xmm15, xmm15
000071709abe1b4a  movaps [r15+0x1B0], xmm15
000071709abe1b52  lea r14, [rax+0x110]
000071709abe1b59  mov r12, [r13+r14*1]
000071709abe1b5e  lea r14, [rax+0x118]
000071709abe1b65  mov r11, [r13+r14*1]
000071709abe1b6a  movq xmm1, r12
000071709abe1b6f  movq xmm15, r11
000071709abe1b74  movq xmm1, xmm1
000071709abe1b78  movq xmm1, xmm1
000071709abe1b7c  movaps [r15+0x1E0], xmm1
000071709abe1b84  movq xmm15, xmm15
000071709abe1b89  movq xmm15, xmm15
000071709abe1b8e  movaps [r15+0x1D0], xmm15
000071709abe1b96  lea r14, [rax+0x100]
000071709abe1b9d  mov r12, [r13+r14*1]
000071709abe1ba2  lea r14, [rax+0x108]
000071709abe1ba9  mov r11, [r13+r14*1]
000071709abe1bae  movq xmm1, r12
000071709abe1bb3  movq xmm15, r11
000071709abe1bb8  movq xmm1, xmm1
000071709abe1bbc  movq xmm1, xmm1
000071709abe1bc0  movaps [r15+0x200], xmm1
000071709abe1bc8  movq xmm15, xmm15
000071709abe1bcd  movq xmm15, xmm15
000071709abe1bd2  movaps [r15+0x1F0], xmm15
000071709abe1bda  mov qword ptr [r15+0x40], 0x430000
000071709abe1be2  mov r14d, 0x430510
000071709abe1be8  mov r12, [r13+r14*1]
000071709abe1bed  movq xmm1, r12
000071709abe1bf2  lea r14, [rax+0x150]
000071709abe1bf9  mov [r15+0xF8], r14
000071709abe1c00  mov rax, [r15+0x50]
000071709abe1c04  movups xmm15, [r13+rax*1]
000071709abe1c0a  movaps [r15+0x120], xmm15
000071709abe1c12  mov qword ptr [r15+0x48], 0x10
000071709abe1c1a  xor eax, eax
000071709abe1c1c  mov r14d, 0x10
000071709abe1c22  mov r12d, 0x200
000071709abe1c28  cmp r14, r12
000071709abe1c2b  cmc
000071709abe1c2c  lahf
000071709abe1c2d  seto al
000071709abe1c30  mov [r15+0x108], eax
000071709abe1c37  pextrq rax, xmm15, 0x01
000071709abe1c3e  movq xmm14, rax
000071709abe1c43  movaps [r15+0x130], xmm14
000071709abe1c4b  movq rax, xmm1
000071709abe1c50  movq r14, xmm15
000071709abe1c55  vmovq xmm1, rax
000071709abe1c5a  vmovq xmm15, r14
000071709abe1c5f  movaps xmm13, xmm1
000071709abe1c63  addsd xmm13, xmm15
000071709abe1c68  ucomisd xmm13, xmm13
000071709abe1c6d  jp 0x000071709ABE1D86
000071709abe1c73  movq xmm13, xmm13
000071709abe1c78  movq rax, xmm13
000071709abe1c7d  movq r14, xmm14
000071709abe1c82  vmovq xmm1, rax
000071709abe1c87  vmovq xmm15, r14
000071709abe1c8c  movaps xmm14, xmm1
000071709abe1c90  addsd xmm14, xmm15
000071709abe1c95  ucomisd xmm14, xmm14
000071709abe1c9a  jp 0x000071709ABE1DCE
000071709abe1ca0  movq xmm14, xmm14
000071709abe1ca5  movaps [r15+0x110], xmm14
000071709abe1cad  mov eax, [r15+0x108]
000071709abe1cb4  sahf
000071709abe1cb5  jnz 0x000071709ABE1CE7
000071709abe1cb7  cmp dword ptr [r15+0x318], 0x00
000071709abe1cbf  jz 0x000071709ABE1FE0
000071709abe1cc5  nop [rax+rax*1], ax
000071709abe1cce  nop [rax+rax*1], eax
000071709abe1cd6  mov eax, 0x410490
000071709abe1cdb  mov [r15+0x100], rax
000071709abe1ce2  jmp 0x000071709A9FE110
000071709abe1ce7  cmp dword ptr [r15+0x318], 0x00
000071709abe1cef  jz 0x000071709ABE1E20
000071709abe1cf5  nop [rax+rax*1], ax
000071709abe1cfe  nop [rax+rax*1], eax
000071709abe1d06  mov eax, 0x410474
000071709abe1d0b  mov [r15+0x100], rax
000071709abe1d12  jmp 0x000071709A9FE110
000071709abe1d17  int3
000071709abe1d18  call 0x000071709AAE27E0
000071709abe1d1d  jmp 0x000071709ABE1AC3
000071709abe1d22  call 0x000071709AAE27E0
000071709abe1d27  jmp 0x000071709ABE1AD6
000071709abe1d2c  call 0x000071709AAE1570
000071709abe1d31  jmp 0x000071709ABE1AE2
000071709abe1d36  call 0x000071709AAE27E0
000071709abe1d3b  jmp 0x000071709ABE1B1A
000071709abe1d40  call 0x000071709AAE1570
000071709abe1d45  jmp 0x000071709ABE1B26
000071709abe1d4a  call 0x000071709AAE27E0
000071709abe1d4f  jmp 0x000071709ABE1B5E
000071709abe1d54  call 0x000071709AAE1570
000071709abe1d59  jmp 0x000071709ABE1B6A
000071709abe1d5e  call 0x000071709AAE27E0
000071709abe1d63  jmp 0x000071709ABE1BA2
000071709abe1d68  call 0x000071709AAE1570
000071709abe1d6d  jmp 0x000071709ABE1BAE
000071709abe1d72  call 0x000071709AAE27E0
000071709abe1d77  jmp 0x000071709ABE1BED
000071709abe1d7c  call 0x000071709AA0E760
000071709abe1d81  jmp 0x000071709ABE1C0A
000071709abe1d86  ucomisd xmm1, xmm15
000071709abe1d8b  jp 0x000071709ABE1D9A
000071709abe1d8d  movaps xmm13, [0x000071709A7FE060]
000071709abe1d95  jmp 0x000071709ABE1C73
000071709abe1d9a  vxorps xmm0, xmm1, xmm15
000071709abe1d9f  pextrw eax, xmm0, 0x03
000071709abe1da4  and eax, 0x7FF8
000071709abe1da9  cmp eax, 0x08
000071709abe1dac  jnz 0x000071709ABE1C73
000071709abe1db2  movq rax, xmm15
000071709abe1db7  shl rax, 0x0D
000071709abe1dbb  jbe 0x000071709ABE1C73
000071709abe1dc1  vorps xmm13, xmm15, [0x000071709A7FE070]
000071709abe1dc9  jmp 0x000071709ABE1C73
000071709abe1dce  ucomisd xmm1, xmm15
000071709abe1dd3  jp 0x000071709ABE1DE2
000071709abe1dd5  movaps xmm14, [0x000071709A7FE060]
000071709abe1ddd  jmp 0x000071709ABE1CA0
000071709abe1de2  vxorps xmm0, xmm1, xmm15
000071709abe1de7  pextrw eax, xmm0, 0x03
000071709abe1dec  and eax, 0x7FF8
000071709abe1df1  cmp eax, 0x08
000071709abe1df4  jnz 0x000071709ABE1CA0
000071709abe1dfa  movq rax, xmm15
000071709abe1dff  shl rax, 0x0D
000071709abe1e03  jbe 0x000071709ABE1CA0
000071709abe1e09  vorps xmm14, xmm15, [0x000071709A7FE070]
000071709abe1e11  jmp 0x000071709ABE1CA0
000071709abe1e16  int3
000071709abe1e17  nop [rax+rax*1], ax
000071709abe1e20  mov rax, [r15+0x48]
000071709abe1e24  mov r14, [r15+0x50]
000071709abe1e28  lea r12, [r14+rax*1]
000071709abe1e2c  movups xmm1, [r13+r12*1]
000071709abe1e32  movaps [r15+0x120], xmm1
000071709abe1e3a  lea r14, [rax+0x10]
000071709abe1e3e  mov [r15+0x48], r14
000071709abe1e42  xor eax, eax
000071709abe1e44  mov r12d, 0x200
000071709abe1e4a  cmp r14, r12
000071709abe1e4d  cmc
000071709abe1e4e  lahf
000071709abe1e4f  seto al
000071709abe1e52  mov [r15+0x108], eax
000071709abe1e59  pextrq rax, xmm1, 0x01
000071709abe1e60  movq xmm15, rax
000071709abe1e65  movaps [r15+0x130], xmm15
000071709abe1e6d  movaps xmm14, [r15+0x110]
000071709abe1e75  movq rax, xmm14
000071709abe1e7a  movq r14, xmm1
000071709abe1e7f  vmovq xmm1, rax
000071709abe1e84  vmovq xmm14, r14
000071709abe1e89  movaps xmm13, xmm1
000071709abe1e8d  addsd xmm13, xmm14
000071709abe1e92  ucomisd xmm13, xmm13
000071709abe1e97  jp 0x000071709ABE1F4C
000071709abe1e9d  movq xmm13, xmm13
000071709abe1ea2  movq rax, xmm13
000071709abe1ea7  movq r14, xmm15
000071709abe1eac  vmovq xmm1, rax
000071709abe1eb1  vmovq xmm15, r14
000071709abe1eb6  movaps xmm14, xmm1
000071709abe1eba  addsd xmm14, xmm15
000071709abe1ebf  ucomisd xmm14, xmm14
000071709abe1ec4  jp 0x000071709ABE1F94
000071709abe1eca  movq xmm14, xmm14
000071709abe1ecf  movaps [r15+0x110], xmm14
000071709abe1ed7  mov eax, [r15+0x108]
000071709abe1ede  sahf
000071709abe1edf  jnz 0x000071709ABE1F11
000071709abe1ee1  cmp dword ptr [r15+0x318], 0x00
000071709abe1ee9  jz 0x000071709ABE1FE0
000071709abe1eef  nop [rax+rax*1], ax
000071709abe1ef8  nop [rax+rax*1], eax
000071709abe1f00  mov eax, 0x410490
000071709abe1f05  mov [r15+0x100], rax
000071709abe1f0c  jmp 0x000071709A9FE110
000071709abe1f11  cmp dword ptr [r15+0x318], 0x00
000071709abe1f19  jz 0x000071709ABE1E20
000071709abe1f1f  nop [rax+rax*1], ax
000071709abe1f28  nop [rax+rax*1], eax
000071709abe1f30  mov eax, 0x410474
000071709abe1f35  mov [r15+0x100], rax
000071709abe1f3c  jmp 0x000071709A9FE110
000071709abe1f41  int3
000071709abe1f42  call 0x000071709AAB52F0
000071709abe1f47  jmp 0x000071709ABE1E32
000071709abe1f4c  ucomisd xmm1, xmm14
000071709abe1f51  jp 0x000071709ABE1F60
000071709abe1f53  movaps xmm13, [0x000071709A7FE060]
000071709abe1f5b  jmp 0x000071709ABE1E9D
000071709abe1f60  vxorps xmm0, xmm1, xmm14
000071709abe1f65  pextrw eax, xmm0, 0x03
000071709abe1f6a  and eax, 0x7FF8
000071709abe1f6f  cmp eax, 0x08
000071709abe1f72  jnz 0x000071709ABE1E9D
000071709abe1f78  movq rax, xmm14
000071709abe1f7d  shl rax, 0x0D
000071709abe1f81  jbe 0x000071709ABE1E9D
000071709abe1f87  vorps xmm13, xmm14, [0x000071709A7FE070]
000071709abe1f8f  jmp 0x000071709ABE1E9D
000071709abe1f94  ucomisd xmm1, xmm15
000071709abe1f99  jp 0x000071709ABE1FA8
000071709abe1f9b  movaps xmm14, [0x000071709A7FE060]
000071709abe1fa3  jmp 0x000071709ABE1ECA
000071709abe1fa8  vxorps xmm0, xmm1, xmm15
000071709abe1fad  pextrw eax, xmm0, 0x03
000071709abe1fb2  and eax, 0x7FF8
000071709abe1fb7  cmp eax, 0x08
000071709abe1fba  jnz 0x000071709ABE1ECA
000071709abe1fc0  movq rax, xmm15
000071709abe1fc5  shl rax, 0x0D
000071709abe1fc9  jbe 0x000071709ABE1ECA
000071709abe1fcf  vorps xmm14, xmm15, [0x000071709A7FE070]
000071709abe1fd7  jmp 0x000071709ABE1ECA
000071709abe1fdc  int3
000071709abe1fdd  nop [rax], eax
000071709abe1fe0  mov rax, [r15+0x40]
000071709abe1fe4  lea r14, [rax+0x510]
000071709abe1feb  movaps xmm1, [r15+0x110]
000071709abe1ff3  movq rax, xmm1
000071709abe1ff8  mov [r13+r14*1], rax
000071709abe1ffd  mov rax, [r15+0xF0]
000071709abe2004  mov [r15+0x100], rax
000071709abe200b  jmp 0x000071709ABCE5C0
000071709abe2010  int3
000071709abe2011  call 0x000071709AAD5EB0
000071709abe2016  jmp 0x000071709ABE1FFD
000071709abe201b  int3
000071709abe201c  nop [rax], eax
000071709abe2020  mov qword ptr [r15+0x100], 0x04
000071709abe202b  mov esi, 0x00
000071709abe2030  mov edx, 0x09
000071709abe2035  mov rdi, 0x7FFD59957700
000071709abe203f  mov rax, 0x60B9B294F970
000071709abe2049  call rax
000071709abe204b  cmp dword ptr [r15+0x318], 0x00
000071709abe2053  jnz 0x000071709A9FE110
000071709abe2059  jmp 0x000071709A9FE0A0
000071709abe205e  int3
000071709abe205f  int3
