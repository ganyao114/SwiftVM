000078eb87dce69b  nop [rax+rax*1], eax
000078eb87dce6a0  vmovaps xmm1, [0x000078EB879FE010]
000078eb87dce6a8  movq xmm1, xmm1
000078eb87dce6ac  movaps [r15+0x110], xmm1
000078eb87dce6b4  vmovaps xmm1, [0x000078EB879FE020]
000078eb87dce6bc  movq xmm1, xmm1
000078eb87dce6c0  movaps [r15+0x120], xmm1
000078eb87dce6c8  mov eax, 0x4204C0
000078eb87dce6cd  mov r14, [r13+rax*1]
000078eb87dce6d2  movq xmm1, r14
000078eb87dce6d7  movaps [r15+0x130], xmm1
000078eb87dce6df  vmovaps xmm1, [0x000078EB879FE030]
000078eb87dce6e7  vpbroadcastq xmm1, xmm1
000078eb87dce6ec  movaps [r15+0x140], xmm1
000078eb87dce6f4  mov qword ptr [r15+0x40], 0x02
000078eb87dce6fc  vmovaps xmm15, [0x000078EB879FE040]
000078eb87dce704  movq xmm15, xmm15
000078eb87dce709  movaps [r15+0x150], xmm15
000078eb87dce711  mov qword ptr [r15+0x58], 0x420000
000078eb87dce719  vmovaps xmm15, [0x000078EB879FE050]
000078eb87dce721  vpbroadcastq xmm15, xmm15
000078eb87dce726  movaps [r15+0x160], xmm15
000078eb87dce72e  mov rax, [r15+0x40]
000078eb87dce732  vmovq xmm14, rax
000078eb87dce737  vpbroadcastq xmm14, xmm14
000078eb87dce73c  movaps [r15+0x170], xmm14
000078eb87dce744  mov eax, 0x4204D0
000078eb87dce749  movups xmm13, [r13+rax*1]
000078eb87dce74f  mov qword ptr [r15+0x40], 0x430518
000078eb87dce757  mov qword ptr [r15+0x50], 0x430720
000078eb87dce75f  vpmovqd xmm12, xmm13
000078eb87dce765  pxor xmm11, xmm11
000078eb87dce76a  punpcklqdq xmm12, xmm11
000078eb87dce76f  movaps [r15+0x210], xmm12
000078eb87dce777  movq xmm12, qword ptr [r15+0x120]
000078eb87dce780  movq xmm11, qword ptr [r15+0x130]
000078eb87dce789  psubd xmm12, xmm11
000078eb87dce78e  movq xmm12, xmm12
000078eb87dce793  paddq xmm13, xmm14
000078eb87dce798  movaps [r15+0x180], xmm13
000078eb87dce7a0  movq xmm14, qword ptr [r15+0x150]
000078eb87dce7a9  paddd xmm11, xmm14
000078eb87dce7ae  movq xmm11, xmm11
000078eb87dce7b3  movq xmm11, xmm11
000078eb87dce7b8  movaps [r15+0x130], xmm11
000078eb87dce7c0  pmovzxdq xmm12, xmm12
000078eb87dce7c6  psllq xmm12, 0x00
000078eb87dce7cc  movq xmm14, qword ptr [r15+0x210]
000078eb87dce7d5  movq xmm13, qword ptr [r15+0x110]
000078eb87dce7de  paddd xmm14, xmm13
000078eb87dce7e3  movq xmm14, xmm14
000078eb87dce7e8  vcvtuqq2pd xmm12, xmm12
000078eb87dce7ee  pmovzxdq xmm14, xmm14
000078eb87dce7f4  psllq xmm14, 0x00
000078eb87dce7fa  vcvtuqq2pd xmm14, xmm14
000078eb87dce800  movaps xmm13, xmm12
000078eb87dce804  mulpd xmm13, xmm1
000078eb87dce809  vcmppd xmm11, xmm13, xmm13, 0x03
000078eb87dce80f  ptest xmm11, xmm11
000078eb87dce815  jnz 0x000078EB87DCE8FF
000078eb87dce81b  movaps [r15+0x220], xmm13
000078eb87dce823  mov eax, 0x430720
000078eb87dce828  movups [r13+rax*1], xmm13
000078eb87dce82e  movaps xmm1, xmm14
000078eb87dce832  mulpd xmm1, xmm15
000078eb87dce837  vcmppd xmm13, xmm1, xmm1, 0x03
000078eb87dce83c  ptest xmm13, xmm13
000078eb87dce842  jnz 0x000078EB87DCEA4C
000078eb87dce848  movaps [r15+0x210], xmm1
000078eb87dce850  mov eax, 0x430518
000078eb87dce855  movups [r13+rax*1], xmm1
000078eb87dce85b  mov qword ptr [r15+0x48], 0x10
000078eb87dce863  xor eax, eax
000078eb87dce865  mov r14d, 0x10
000078eb87dce86b  mov r12d, 0x200
000078eb87dce871  cmp r14, r12
000078eb87dce874  cmc
000078eb87dce875  lahf
000078eb87dce876  seto al
000078eb87dce879  mov [r15+0x108], eax
000078eb87dce880  mov eax, [r15+0x108]
000078eb87dce887  sahf
000078eb87dce888  jnz 0x000078EB87DCE8BA
000078eb87dce88a  cmp dword ptr [r15+0x318], 0x00
000078eb87dce892  jz 0x000078EB87DCEFF0
000078eb87dce898  nop [rax+rax*1], ax
000078eb87dce8a1  nop [rax+rax*1], eax
000078eb87dce8a9  mov eax, 0x4101EC
000078eb87dce8ae  mov [r15+0x100], rax
000078eb87dce8b5  jmp 0x000078EB87BFE110
000078eb87dce8ba  cmp dword ptr [r15+0x318], 0x00
000078eb87dce8c2  jz 0x000078EB87DCEBA0
000078eb87dce8c8  nop [rax+rax*1], ax
000078eb87dce8d1  nop [rax+rax*1], eax
000078eb87dce8d9  mov eax, 0x4101AC
000078eb87dce8de  mov [r15+0x100], rax
000078eb87dce8e5  jmp 0x000078EB87BFE110
000078eb87dce8ea  int3
000078eb87dce8eb  call 0x000078EB87C0DC20
000078eb87dce8f0  jmp 0x000078EB87DCE6D2
000078eb87dce8f5  call 0x000078EB87C0C260
000078eb87dce8fa  jmp 0x000078EB87DCE74F
000078eb87dce8ff  sub rsp, 0x08
000078eb87dce903  push rax
000078eb87dce904  push rcx
000078eb87dce905  push rdx
000078eb87dce906  push rdi
000078eb87dce907  push rsi
000078eb87dce908  push r8
000078eb87dce90a  push r9
000078eb87dce90c  push r10
000078eb87dce90e  push r11
000078eb87dce910  sub rsp, 0xF0
000078eb87dce917  vmovaps [rsp], xmm0
000078eb87dce91c  vmovaps [rsp+0x10], xmm1
000078eb87dce922  vmovaps [rsp+0x20], xmm2
000078eb87dce928  vmovaps [rsp+0x30], xmm3
000078eb87dce92e  vmovaps [rsp+0x40], xmm4
000078eb87dce934  vmovaps [rsp+0x50], xmm5
000078eb87dce93a  vmovaps [rsp+0x60], xmm6
000078eb87dce940  vmovaps [rsp+0x70], xmm7
000078eb87dce946  vmovaps [rsp+0x80], xmm8
000078eb87dce94f  vmovaps [rsp+0x90], xmm9
000078eb87dce958  vmovaps [rsp+0xA0], xmm10
000078eb87dce961  vmovaps [rsp+0xB0], xmm11
000078eb87dce96a  vmovaps [rsp+0xC0], xmm12
000078eb87dce973  vmovaps [rsp+0xD0], xmm14
000078eb87dce97c  vmovaps [rsp+0xE0], xmm15
000078eb87dce985  sub rsp, 0x30
000078eb87dce989  movaps [rsp], xmm13
000078eb87dce98e  movaps [rsp+0x10], xmm12
000078eb87dce994  movaps [rsp+0x20], xmm1
000078eb87dce999  lea rdi, [rsp]
000078eb87dce99d  mov esi, 0x00
000078eb87dce9a2  mov rax, 0x61D341A71530
000078eb87dce9ac  call rax
000078eb87dce9ae  movaps xmm13, [rsp]
000078eb87dce9b3  add rsp, 0x30
000078eb87dce9b7  vmovaps xmm0, [rsp]
000078eb87dce9bc  vmovaps xmm1, [rsp+0x10]
000078eb87dce9c2  vmovaps xmm2, [rsp+0x20]
000078eb87dce9c8  vmovaps xmm3, [rsp+0x30]
000078eb87dce9ce  vmovaps xmm4, [rsp+0x40]
000078eb87dce9d4  vmovaps xmm5, [rsp+0x50]
000078eb87dce9da  vmovaps xmm6, [rsp+0x60]
000078eb87dce9e0  vmovaps xmm7, [rsp+0x70]
000078eb87dce9e6  vmovaps xmm8, [rsp+0x80]
000078eb87dce9ef  vmovaps xmm9, [rsp+0x90]
000078eb87dce9f8  vmovaps xmm10, [rsp+0xA0]
000078eb87dcea01  vmovaps xmm11, [rsp+0xB0]
000078eb87dcea0a  vmovaps xmm12, [rsp+0xC0]
000078eb87dcea13  vmovaps xmm14, [rsp+0xD0]
000078eb87dcea1c  vmovaps xmm15, [rsp+0xE0]
000078eb87dcea25  add rsp, 0xF0
000078eb87dcea2c  pop r11
000078eb87dcea2e  pop r10
000078eb87dcea30  pop r9
000078eb87dcea32  pop r8
000078eb87dcea34  pop rsi
000078eb87dcea35  pop rdi
000078eb87dcea36  pop rdx
000078eb87dcea37  pop rcx
000078eb87dcea38  pop rax
000078eb87dcea39  add rsp, 0x08
000078eb87dcea3d  jmp 0x000078EB87DCE81B
000078eb87dcea42  call 0x000078EB87C0C380
000078eb87dcea47  jmp 0x000078EB87DCE82E
000078eb87dcea4c  sub rsp, 0x08
000078eb87dcea50  push rax
000078eb87dcea51  push rcx
000078eb87dcea52  push rdx
000078eb87dcea53  push rdi
000078eb87dcea54  push rsi
000078eb87dcea55  push r8
000078eb87dcea57  push r9
000078eb87dcea59  push r10
000078eb87dcea5b  push r11
000078eb87dcea5d  sub rsp, 0xF0
000078eb87dcea64  vmovaps [rsp], xmm0
000078eb87dcea69  vmovaps [rsp+0x10], xmm2
000078eb87dcea6f  vmovaps [rsp+0x20], xmm3
000078eb87dcea75  vmovaps [rsp+0x30], xmm4
000078eb87dcea7b  vmovaps [rsp+0x40], xmm5
000078eb87dcea81  vmovaps [rsp+0x50], xmm6
000078eb87dcea87  vmovaps [rsp+0x60], xmm7
000078eb87dcea8d  vmovaps [rsp+0x70], xmm8
000078eb87dcea93  vmovaps [rsp+0x80], xmm9
000078eb87dcea9c  vmovaps [rsp+0x90], xmm10
000078eb87dceaa5  vmovaps [rsp+0xA0], xmm11
000078eb87dceaae  vmovaps [rsp+0xB0], xmm12
000078eb87dceab7  vmovaps [rsp+0xC0], xmm13
000078eb87dceac0  vmovaps [rsp+0xD0], xmm14
000078eb87dceac9  vmovaps [rsp+0xE0], xmm15
000078eb87dcead2  sub rsp, 0x30
000078eb87dcead6  movaps [rsp], xmm1
000078eb87dceada  movaps [rsp+0x10], xmm14
000078eb87dceae0  movaps [rsp+0x20], xmm15
000078eb87dceae6  lea rdi, [rsp]
000078eb87dceaea  mov esi, 0x00
000078eb87dceaef  mov rax, 0x61D341A71530
000078eb87dceaf9  call rax
000078eb87dceafb  movaps xmm1, [rsp]
000078eb87dceaff  add rsp, 0x30
000078eb87dceb03  vmovaps xmm0, [rsp]
000078eb87dceb08  vmovaps xmm2, [rsp+0x10]
000078eb87dceb0e  vmovaps xmm3, [rsp+0x20]
000078eb87dceb14  vmovaps xmm4, [rsp+0x30]
000078eb87dceb1a  vmovaps xmm5, [rsp+0x40]
000078eb87dceb20  vmovaps xmm6, [rsp+0x50]
000078eb87dceb26  vmovaps xmm7, [rsp+0x60]
000078eb87dceb2c  vmovaps xmm8, [rsp+0x70]
000078eb87dceb32  vmovaps xmm9, [rsp+0x80]
000078eb87dceb3b  vmovaps xmm10, [rsp+0x90]
000078eb87dceb44  vmovaps xmm11, [rsp+0xA0]
000078eb87dceb4d  vmovaps xmm12, [rsp+0xB0]
000078eb87dceb56  vmovaps xmm13, [rsp+0xC0]
000078eb87dceb5f  vmovaps xmm14, [rsp+0xD0]
000078eb87dceb68  vmovaps xmm15, [rsp+0xE0]
000078eb87dceb71  add rsp, 0xF0
000078eb87dceb78  pop r11
000078eb87dceb7a  pop r10
000078eb87dceb7c  pop r9
000078eb87dceb7e  pop r8
000078eb87dceb80  pop rsi
000078eb87dceb81  pop rdi
000078eb87dceb82  pop rdx
000078eb87dceb83  pop rcx
000078eb87dceb84  pop rax
000078eb87dceb85  add rsp, 0x08
000078eb87dceb89  jmp 0x000078EB87DCE848
000078eb87dceb8e  call 0x000078EB87BFF540
000078eb87dceb93  jmp 0x000078EB87DCE85B
000078eb87dceb98  int3
000078eb87dceb99  nop [rax], eax
000078eb87dceba0  movaps xmm1, [r15+0x180]
000078eb87dceba8  vpmovqd xmm15, xmm1
000078eb87dcebae  pxor xmm14, xmm14
000078eb87dcebb3  punpcklqdq xmm15, xmm14
000078eb87dcebb8  movaps [r15+0x210], xmm15
000078eb87dcebc0  movq xmm15, qword ptr [r15+0x120]
000078eb87dcebc9  movq xmm14, qword ptr [r15+0x130]
000078eb87dcebd2  psubd xmm15, xmm14
000078eb87dcebd7  movq xmm15, xmm15
000078eb87dcebdc  movaps xmm13, [r15+0x170]
000078eb87dcebe4  paddq xmm1, xmm13
000078eb87dcebe9  movaps [r15+0x180], xmm1
000078eb87dcebf1  movq xmm1, qword ptr [r15+0x150]
000078eb87dcebfa  paddd xmm14, xmm1
000078eb87dcebff  movq xmm14, xmm14
000078eb87dcec04  movq xmm14, xmm14
000078eb87dcec09  movaps [r15+0x130], xmm14
000078eb87dcec11  pmovzxdq xmm15, xmm15
000078eb87dcec17  psllq xmm15, 0x00
000078eb87dcec1d  movq xmm1, qword ptr [r15+0x210]
000078eb87dcec26  movq xmm14, qword ptr [r15+0x110]
000078eb87dcec2f  paddd xmm1, xmm14
000078eb87dcec34  movq xmm1, xmm1
000078eb87dcec38  vcvtuqq2pd xmm15, xmm15
000078eb87dcec3e  pmovzxdq xmm1, xmm1
000078eb87dcec43  psllq xmm1, 0x00
000078eb87dcec48  vcvtuqq2pd xmm1, xmm1
000078eb87dcec4e  movaps xmm14, [r15+0x140]
000078eb87dcec56  movaps xmm13, xmm15
000078eb87dcec5a  mulpd xmm13, xmm14
000078eb87dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000078eb87dcec65  ptest xmm12, xmm12
000078eb87dcec6b  jnz 0x000078EB87DCED4E
000078eb87dcec71  movaps [r15+0x220], xmm13
000078eb87dcec79  mov rax, [r15+0x48]
000078eb87dcec7d  mov r14, [r15+0x50]
000078eb87dcec81  lea r12, [r14+rax*1]
000078eb87dcec85  movups [r13+r12*1], xmm13
000078eb87dcec8b  movaps xmm15, [r15+0x160]
000078eb87dcec93  movaps xmm14, xmm1
000078eb87dcec97  mulpd xmm14, xmm15
000078eb87dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000078eb87dceca2  ptest xmm13, xmm13
000078eb87dceca8  jnz 0x000078EB87DCEE9C
000078eb87dcecae  movaps [r15+0x210], xmm14
000078eb87dcecb6  mov r14, [r15+0x40]
000078eb87dcecba  lea r12, [r14+rax*1]
000078eb87dcecbe  movups [r13+r12*1], xmm14
000078eb87dcecc4  lea r14, [rax+0x10]
000078eb87dcecc8  mov [r15+0x48], r14
000078eb87dceccc  xor eax, eax
000078eb87dcecce  mov r12d, 0x200
000078eb87dcecd4  cmp r14, r12
000078eb87dcecd7  cmc
000078eb87dcecd8  lahf
000078eb87dcecd9  seto al
000078eb87dcecdc  mov [r15+0x108], eax
000078eb87dcece3  mov eax, [r15+0x108]
000078eb87dcecea  sahf
000078eb87dceceb  jnz 0x000078EB87DCED1D
000078eb87dceced  cmp dword ptr [r15+0x318], 0x00
000078eb87dcecf5  jz 0x000078EB87DCEFF0
000078eb87dcecfb  nop [rax+rax*1], ax
000078eb87dced04  nop [rax+rax*1], eax
000078eb87dced0c  mov eax, 0x4101EC
000078eb87dced11  mov [r15+0x100], rax
000078eb87dced18  jmp 0x000078EB87BFE110
000078eb87dced1d  cmp dword ptr [r15+0x318], 0x00
000078eb87dced25  jz 0x000078EB87DCEBA0
000078eb87dced2b  nop [rax+rax*1], ax
000078eb87dced34  nop [rax+rax*1], eax
000078eb87dced3c  mov eax, 0x4101AC
000078eb87dced41  mov [r15+0x100], rax
000078eb87dced48  jmp 0x000078EB87BFE110
000078eb87dced4d  int3
000078eb87dced4e  sub rsp, 0x08
000078eb87dced52  push rax
000078eb87dced53  push rcx
000078eb87dced54  push rdx
000078eb87dced55  push rdi
000078eb87dced56  push rsi
000078eb87dced57  push r8
000078eb87dced59  push r9
000078eb87dced5b  push r10
000078eb87dced5d  push r11
000078eb87dced5f  sub rsp, 0xF0
000078eb87dced66  vmovaps [rsp], xmm0
000078eb87dced6b  vmovaps [rsp+0x10], xmm1
000078eb87dced71  vmovaps [rsp+0x20], xmm2
000078eb87dced77  vmovaps [rsp+0x30], xmm3
000078eb87dced7d  vmovaps [rsp+0x40], xmm4
000078eb87dced83  vmovaps [rsp+0x50], xmm5
000078eb87dced89  vmovaps [rsp+0x60], xmm6
000078eb87dced8f  vmovaps [rsp+0x70], xmm7
000078eb87dced95  vmovaps [rsp+0x80], xmm8
000078eb87dced9e  vmovaps [rsp+0x90], xmm9
000078eb87dceda7  vmovaps [rsp+0xA0], xmm10
000078eb87dcedb0  vmovaps [rsp+0xB0], xmm11
000078eb87dcedb9  vmovaps [rsp+0xC0], xmm12
000078eb87dcedc2  vmovaps [rsp+0xD0], xmm14
000078eb87dcedcb  vmovaps [rsp+0xE0], xmm15
000078eb87dcedd4  sub rsp, 0x30
000078eb87dcedd8  movaps [rsp], xmm13
000078eb87dceddd  movaps [rsp+0x10], xmm15
000078eb87dcede3  movaps [rsp+0x20], xmm14
000078eb87dcede9  lea rdi, [rsp]
000078eb87dceded  mov esi, 0x00
000078eb87dcedf2  mov rax, 0x61D341A71530
000078eb87dcedfc  call rax
000078eb87dcedfe  movaps xmm13, [rsp]
000078eb87dcee03  add rsp, 0x30
000078eb87dcee07  vmovaps xmm0, [rsp]
000078eb87dcee0c  vmovaps xmm1, [rsp+0x10]
000078eb87dcee12  vmovaps xmm2, [rsp+0x20]
000078eb87dcee18  vmovaps xmm3, [rsp+0x30]
000078eb87dcee1e  vmovaps xmm4, [rsp+0x40]
000078eb87dcee24  vmovaps xmm5, [rsp+0x50]
000078eb87dcee2a  vmovaps xmm6, [rsp+0x60]
000078eb87dcee30  vmovaps xmm7, [rsp+0x70]
000078eb87dcee36  vmovaps xmm8, [rsp+0x80]
000078eb87dcee3f  vmovaps xmm9, [rsp+0x90]
000078eb87dcee48  vmovaps xmm10, [rsp+0xA0]
000078eb87dcee51  vmovaps xmm11, [rsp+0xB0]
000078eb87dcee5a  vmovaps xmm12, [rsp+0xC0]
000078eb87dcee63  vmovaps xmm14, [rsp+0xD0]
000078eb87dcee6c  vmovaps xmm15, [rsp+0xE0]
000078eb87dcee75  add rsp, 0xF0
000078eb87dcee7c  pop r11
000078eb87dcee7e  pop r10
000078eb87dcee80  pop r9
000078eb87dcee82  pop r8
000078eb87dcee84  pop rsi
000078eb87dcee85  pop rdi
000078eb87dcee86  pop rdx
000078eb87dcee87  pop rcx
000078eb87dcee88  pop rax
000078eb87dcee89  add rsp, 0x08
000078eb87dcee8d  jmp 0x000078EB87DCEC71
000078eb87dcee92  call 0x000078EB87CC2240
000078eb87dcee97  jmp 0x000078EB87DCEC8B
000078eb87dcee9c  sub rsp, 0x08
000078eb87dceea0  push rax
000078eb87dceea1  push rcx
000078eb87dceea2  push rdx
000078eb87dceea3  push rdi
000078eb87dceea4  push rsi
000078eb87dceea5  push r8
000078eb87dceea7  push r9
000078eb87dceea9  push r10
000078eb87dceeab  push r11
000078eb87dceead  sub rsp, 0xF0
000078eb87dceeb4  vmovaps [rsp], xmm0
000078eb87dceeb9  vmovaps [rsp+0x10], xmm1
000078eb87dceebf  vmovaps [rsp+0x20], xmm2
000078eb87dceec5  vmovaps [rsp+0x30], xmm3
000078eb87dceecb  vmovaps [rsp+0x40], xmm4
000078eb87dceed1  vmovaps [rsp+0x50], xmm5
000078eb87dceed7  vmovaps [rsp+0x60], xmm6
000078eb87dceedd  vmovaps [rsp+0x70], xmm7
000078eb87dceee3  vmovaps [rsp+0x80], xmm8
000078eb87dceeec  vmovaps [rsp+0x90], xmm9
000078eb87dceef5  vmovaps [rsp+0xA0], xmm10
000078eb87dceefe  vmovaps [rsp+0xB0], xmm11
000078eb87dcef07  vmovaps [rsp+0xC0], xmm12
000078eb87dcef10  vmovaps [rsp+0xD0], xmm13
000078eb87dcef19  vmovaps [rsp+0xE0], xmm15
000078eb87dcef22  sub rsp, 0x30
000078eb87dcef26  movaps [rsp], xmm14
000078eb87dcef2b  movaps [rsp+0x10], xmm1
000078eb87dcef30  movaps [rsp+0x20], xmm15
000078eb87dcef36  lea rdi, [rsp]
000078eb87dcef3a  mov esi, 0x00
000078eb87dcef3f  mov rax, 0x61D341A71530
000078eb87dcef49  call rax
000078eb87dcef4b  movaps xmm14, [rsp]
000078eb87dcef50  add rsp, 0x30
000078eb87dcef54  vmovaps xmm0, [rsp]
000078eb87dcef59  vmovaps xmm1, [rsp+0x10]
000078eb87dcef5f  vmovaps xmm2, [rsp+0x20]
000078eb87dcef65  vmovaps xmm3, [rsp+0x30]
000078eb87dcef6b  vmovaps xmm4, [rsp+0x40]
000078eb87dcef71  vmovaps xmm5, [rsp+0x50]
000078eb87dcef77  vmovaps xmm6, [rsp+0x60]
000078eb87dcef7d  vmovaps xmm7, [rsp+0x70]
000078eb87dcef83  vmovaps xmm8, [rsp+0x80]
000078eb87dcef8c  vmovaps xmm9, [rsp+0x90]
000078eb87dcef95  vmovaps xmm10, [rsp+0xA0]
000078eb87dcef9e  vmovaps xmm11, [rsp+0xB0]
000078eb87dcefa7  vmovaps xmm12, [rsp+0xC0]
000078eb87dcefb0  vmovaps xmm13, [rsp+0xD0]
000078eb87dcefb9  vmovaps xmm15, [rsp+0xE0]
000078eb87dcefc2  add rsp, 0xF0
000078eb87dcefc9  pop r11
000078eb87dcefcb  pop r10
000078eb87dcefcd  pop r9
000078eb87dcefcf  pop r8
000078eb87dcefd1  pop rsi
000078eb87dcefd2  pop rdi
000078eb87dcefd3  pop rdx
000078eb87dcefd4  pop rcx
000078eb87dcefd5  pop rax
000078eb87dcefd6  add rsp, 0x08
000078eb87dcefda  jmp 0x000078EB87DCECAE
000078eb87dcefdf  call 0x000078EB87CC34C0
000078eb87dcefe4  jmp 0x000078EB87DCECC4
000078eb87dcefe9  int3
000078eb87dcefea  nop [rax+rax*1], ax
000078eb87dceff0  mov rax, [r15+0xF8]
000078eb87dceff7  lea r14, [rax-0x150]
000078eb87dceffe  mov [r15+0xF8], r14
000078eb87dcf005  mov rax, [r15+0x50]
000078eb87dcf009  lea r12, [rax+0x80]
000078eb87dcf010  movups xmm1, [r13+r12*1]
000078eb87dcf016  lea r12, [rax+0x90]
000078eb87dcf01d  movups xmm15, [r13+r12*1]
000078eb87dcf023  mov qword ptr [r15+0x48], 0x00
000078eb87dcf02b  lea r12, [rax+0x40]
000078eb87dcf02f  movups xmm14, [r13+r12*1]
000078eb87dcf035  lea r12, [rax+0x50]
000078eb87dcf039  movups xmm13, [r13+r12*1]
000078eb87dcf03f  lea r12, [r14+0x120]
000078eb87dcf046  movq xmm12, qword ptr [r15+0x1C0]
000078eb87dcf04f  movq xmm11, qword ptr [r15+0x1B0]
000078eb87dcf058  movq r11, xmm12
000078eb87dcf05d  movq r10, xmm11
000078eb87dcf062  mov [r13+r12*1], r11
000078eb87dcf067  lea r12, [r14+0x128]
000078eb87dcf06e  mov [r13+r12*1], r10
000078eb87dcf073  vxorps xmm12, xmm12, xmm12
000078eb87dcf078  vpbroadcastq xmm12, xmm12
000078eb87dcf07d  lea r12, [r14+0x100]
000078eb87dcf084  movq xmm11, qword ptr [r15+0x200]
000078eb87dcf08d  movq xmm10, qword ptr [r15+0x1F0]
000078eb87dcf096  movq r11, xmm11
000078eb87dcf09b  movq r10, xmm10
000078eb87dcf0a0  mov [r13+r12*1], r11
000078eb87dcf0a5  lea r12, [r14+0x108]
000078eb87dcf0ac  mov [r13+r12*1], r10
000078eb87dcf0b1  lea r12, [r14+0xE0]
000078eb87dcf0b8  movups [r13+r12*1], xmm15
000078eb87dcf0be  lea r12, [r14+0xF0]
000078eb87dcf0c5  movups [r13+r12*1], xmm1
000078eb87dcf0cb  lea r12, [rax+0xC0]
000078eb87dcf0d2  movups xmm1, [r13+r12*1]
000078eb87dcf0d8  lea r12, [rax+0xD0]
000078eb87dcf0df  movups xmm15, [r13+r12*1]
000078eb87dcf0e5  lea r12, [r14+0x110]
000078eb87dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000078eb87dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000078eb87dcf0fe  movq r11, xmm11
000078eb87dcf103  movq r10, xmm10
000078eb87dcf108  mov [r13+r12*1], r11
000078eb87dcf10d  lea r12, [r14+0x118]
000078eb87dcf114  mov [r13+r12*1], r10
000078eb87dcf119  movups xmm11, [r13+rax*1]
000078eb87dcf11f  lea r12, [rax+0x10]
000078eb87dcf123  movups xmm10, [r13+r12*1]
000078eb87dcf129  lea r12, [r14+0x130]
000078eb87dcf130  movq xmm9, qword ptr [r15+0x1A0]
000078eb87dcf139  movq xmm8, qword ptr [r15+0x190]
000078eb87dcf142  movq r11, xmm9
000078eb87dcf147  movq r10, xmm8
000078eb87dcf14c  mov [r13+r12*1], r11
000078eb87dcf151  lea r12, [r14+0x138]
000078eb87dcf158  mov [r13+r12*1], r10
000078eb87dcf15d  lea r12, [rax+0x140]
000078eb87dcf164  movups xmm9, [r13+r12*1]
000078eb87dcf16a  lea r12, [rax+0x150]
000078eb87dcf171  movups xmm8, [r13+r12*1]
000078eb87dcf177  lea r12, [r14+0xC0]
000078eb87dcf17e  movups [r13+r12*1], xmm15
000078eb87dcf184  lea r12, [r14+0xD0]
000078eb87dcf18b  movups [r13+r12*1], xmm1
000078eb87dcf191  lea r12, [rax+0x100]
000078eb87dcf198  movups xmm1, [r13+r12*1]
000078eb87dcf19e  lea r12, [rax+0x110]
000078eb87dcf1a5  movups xmm15, [r13+r12*1]
000078eb87dcf1ab  lea r12, [r14+0x140]
000078eb87dcf1b2  mov r11, [r15+0xE8]
000078eb87dcf1b9  mov [r13+r12*1], r11
000078eb87dcf1be  lea r12, [rax+0x180]
000078eb87dcf1c5  movups xmm7, [r13+r12*1]
000078eb87dcf1cb  lea r12, [rax+0x190]
000078eb87dcf1d2  movups xmm6, [r13+r12*1]
000078eb87dcf1d8  lea r12, [rax+0x1C0]
000078eb87dcf1df  movups xmm5, [r13+r12*1]
000078eb87dcf1e5  lea r12, [rax+0x1D0]
000078eb87dcf1ec  movups xmm4, [r13+r12*1]
000078eb87dcf1f2  lea r12, [r14+0x20]
000078eb87dcf1f6  movups [r13+r12*1], xmm1
000078eb87dcf1fc  lea r12, [r14+0x30]
000078eb87dcf200  movups [r13+r12*1], xmm13
000078eb87dcf206  lea r12, [rax+0x60]
000078eb87dcf20a  movups xmm1, [r13+r12*1]
000078eb87dcf210  lea r12, [rax+0x70]
000078eb87dcf214  movups xmm13, [r13+r12*1]
000078eb87dcf21a  lea r12, [rax+0x20]
000078eb87dcf21e  movups xmm3, [r13+r12*1]
000078eb87dcf224  lea r12, [rax+0x30]
000078eb87dcf228  movups xmm2, [r13+r12*1]
000078eb87dcf22e  movaps [r15+0x1F0], xmm2
000078eb87dcf236  lea r12, [r14+0x60]
000078eb87dcf23a  movups [r13+r12*1], xmm11
000078eb87dcf240  lea r12, [r14+0x70]
000078eb87dcf244  movups [r13+r12*1], xmm5
000078eb87dcf24a  lea r12, [rax+0xE0]
000078eb87dcf251  movups xmm11, [r13+r12*1]
000078eb87dcf257  lea r12, [rax+0xF0]
000078eb87dcf25e  movups xmm5, [r13+r12*1]
000078eb87dcf264  lea r12, [r14+0xA0]
000078eb87dcf26b  movups [r13+r12*1], xmm13
000078eb87dcf271  lea r12, [r14+0xB0]
000078eb87dcf278  movups [r13+r12*1], xmm1
000078eb87dcf27e  lea r12, [rax+0xA0]
000078eb87dcf285  movups xmm1, [r13+r12*1]
000078eb87dcf28b  lea r12, [rax+0xB0]
000078eb87dcf292  movups xmm13, [r13+r12*1]
000078eb87dcf298  lea r12, [rax+0x120]
000078eb87dcf29f  vmovaps [rsp+0x10], xmm1
000078eb87dcf2a5  movups xmm1, [r13+r12*1]
000078eb87dcf2ab  lea r12, [rax+0x130]
000078eb87dcf2b2  vmovaps [rsp+0x20], xmm1
000078eb87dcf2b8  movups xmm1, [r13+r12*1]
000078eb87dcf2be  lea r12, [rax+0x160]
000078eb87dcf2c5  vmovaps [rsp+0x30], xmm1
000078eb87dcf2cb  movups xmm1, [r13+r12*1]
000078eb87dcf2d1  lea r12, [rax+0x170]
000078eb87dcf2d8  vmovaps [rsp+0x40], xmm1
000078eb87dcf2de  movups xmm1, [r13+r12*1]
000078eb87dcf2e4  movaps [r15+0x2B0], xmm1
000078eb87dcf2ec  lea r12, [r14+0x80]
000078eb87dcf2f3  movups [r13+r12*1], xmm13
000078eb87dcf2f9  lea r12, [r14+0x90]
000078eb87dcf300  vmovaps xmm13, [rsp+0x10]
000078eb87dcf306  movups [r13+r12*1], xmm13
000078eb87dcf30c  lea r12, [rax+0x1A0]
000078eb87dcf313  movups xmm13, [r13+r12*1]
000078eb87dcf319  lea r12, [rax+0x1B0]
000078eb87dcf320  vmovaps [rsp+0x10], xmm1
000078eb87dcf326  movups xmm1, [r13+r12*1]
000078eb87dcf32c  movaps [r15+0x290], xmm13
000078eb87dcf334  movaps [r15+0x1E0], xmm1
000078eb87dcf33c  lea r12, [rax+0x1E0]
000078eb87dcf343  vmovaps [rsp+0x50], xmm1
000078eb87dcf349  movups xmm1, [r13+r12*1]
000078eb87dcf34f  lea r12, [rax+0x1F0]
000078eb87dcf356  vmovaps [rsp+0x60], xmm1
000078eb87dcf35c  movups xmm1, [r13+r12*1]
000078eb87dcf362  mov qword ptr [r15+0x50], 0x430920
000078eb87dcf36a  lea rax, [r14+0x40]
000078eb87dcf36e  vmovaps [rsp+0x70], xmm1
000078eb87dcf374  vmovaps xmm1, [rsp+0x40]
000078eb87dcf37a  movups [r13+rax*1], xmm1
000078eb87dcf380  lea rax, [r14+0x50]
000078eb87dcf384  movups [r13+rax*1], xmm10
000078eb87dcf38a  vmovaps xmm1, [rsp+0x70]
000078eb87dcf390  movups [r13+r14*1], xmm1
000078eb87dcf396  lea rax, [r14+0x10]
000078eb87dcf39a  vmovaps xmm1, [rsp+0x60]
000078eb87dcf3a0  movups [r13+rax*1], xmm1
000078eb87dcf3a6  mov rax, [r15+0x40]
000078eb87dcf3aa  vmovaps [rsp+0x40], xmm3
000078eb87dcf3b0  vmovaps xmm1, [rsp+0x40]
000078eb87dcf3b6  por xmm3, xmm1
000078eb87dcf3ba  vmovaps [rsp+0x40], xmm6
000078eb87dcf3c0  vmovaps xmm10, [rsp+0x40]
000078eb87dcf3c6  por xmm6, xmm10
000078eb87dcf3cb  lea r12, [rax+0x30]
000078eb87dcf3cf  mov r11, [r13+r12*1]
000078eb87dcf3d4  lea r12, [rax+0x38]
000078eb87dcf3d8  mov r10, [r13+r12*1]
000078eb87dcf3dd  movq xmm10, r11
000078eb87dcf3e2  vmovaps [rsp+0x40], xmm1
000078eb87dcf3e8  movq xmm1, r10
000078eb87dcf3ed  movq xmm10, xmm10
000078eb87dcf3f2  vmovaps [rsp+0x60], xmm10
000078eb87dcf3f8  movq xmm10, xmm10
000078eb87dcf3fd  movaps [r15+0x130], xmm10
000078eb87dcf405  movq xmm1, xmm1
000078eb87dcf409  vmovaps [rsp+0x70], xmm1
000078eb87dcf40f  movq xmm1, xmm1
000078eb87dcf413  movaps [r15+0x280], xmm1
000078eb87dcf41b  vmovaps [rsp+0x80], xmm9
000078eb87dcf424  vmovaps xmm1, [rsp+0x80]
000078eb87dcf42d  por xmm9, xmm1
000078eb87dcf432  lea r12, [rax+0x20]
000078eb87dcf436  mov r11, [r13+r12*1]
000078eb87dcf43b  lea r12, [rax+0x28]
000078eb87dcf43f  mov r10, [r13+r12*1]
000078eb87dcf444  movq xmm1, r11
000078eb87dcf449  movq xmm10, r10
000078eb87dcf44e  movq xmm1, xmm1
000078eb87dcf452  vmovaps [rsp+0x80], xmm1
000078eb87dcf45b  movq xmm1, xmm1
000078eb87dcf45f  movaps [r15+0x150], xmm1
000078eb87dcf467  movq xmm10, xmm10
000078eb87dcf46c  vmovaps [rsp+0x90], xmm10
000078eb87dcf475  movq xmm10, xmm10
000078eb87dcf47a  movaps [r15+0x140], xmm10
000078eb87dcf482  lea r12, [rax+0x10]
000078eb87dcf486  mov r11, [r13+r12*1]
000078eb87dcf48b  lea r12, [rax+0x18]
000078eb87dcf48f  mov r10, [r13+r12*1]
000078eb87dcf494  movq xmm1, r11
000078eb87dcf499  movq xmm10, r10
000078eb87dcf49e  movq xmm1, xmm1
000078eb87dcf4a2  vmovaps [rsp+0xA0], xmm1
000078eb87dcf4ab  movq xmm1, xmm1
000078eb87dcf4af  movaps [r15+0x170], xmm1
000078eb87dcf4b7  movq xmm10, xmm10
000078eb87dcf4bc  vmovaps [rsp+0xB0], xmm10
000078eb87dcf4c5  movq xmm10, xmm10
000078eb87dcf4ca  movaps [r15+0x160], xmm10
000078eb87dcf4d2  mov r12, [r13+rax*1]
000078eb87dcf4d7  vmovq xmm1, r12
000078eb87dcf4dc  vpbroadcastq xmm1, xmm1
000078eb87dcf4e1  lea r12, [rax+0x08]
000078eb87dcf4e5  mov rax, [r13+r12*1]
000078eb87dcf4ea  movq xmm10, rax
000078eb87dcf4ef  movaps [r15+0x230], xmm10
000078eb87dcf4f7  lea rax, [r14+0x50]
000078eb87dcf4fb  movups xmm10, [r13+rax*1]
000078eb87dcf501  lea rax, [r14+0x60]
000078eb87dcf505  vmovaps [rsp+0xC0], xmm1
000078eb87dcf50e  movups xmm1, [r13+rax*1]
000078eb87dcf514  lea rax, [r14+0x30]
000078eb87dcf518  vmovaps [rsp+0xD0], xmm1
000078eb87dcf521  movups xmm1, [r13+rax*1]
000078eb87dcf527  mov qword ptr [r15+0x60], 0x430920
000078eb87dcf52f  mov qword ptr [r15+0x58], 0x40
000078eb87dcf537  vmovaps [rsp+0xE0], xmm1
000078eb87dcf540  vmovaps [rsp+0xF0], xmm15
000078eb87dcf549  vmovaps xmm15, [rsp+0xC0]
000078eb87dcf552  vmovaps [rsp+0xC0], xmm14
000078eb87dcf55b  vmovaps xmm14, [rsp+0x40]
000078eb87dcf561  vmovaps [rsp+0x40], xmm13
000078eb87dcf567  movaps xmm1, xmm15
000078eb87dcf56b  mulpd xmm1, xmm14
000078eb87dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000078eb87dcf575  ptest xmm13, xmm13
000078eb87dcf57b  jnz 0x000078EB87DD0682
000078eb87dcf581  movq xmm14, qword ptr [r15+0x230]
000078eb87dcf58a  vmovaps [rsp+0x100], xmm14
000078eb87dcf593  vpermilpd xmm14, xmm14, 0x00
000078eb87dcf599  vmovaps [rsp+0x110], xmm1
000078eb87dcf5a2  vmovaps xmm1, [rsp+0xE0]
000078eb87dcf5ab  vmovaps [rsp+0xE0], xmm15
000078eb87dcf5b4  movaps xmm13, xmm1
000078eb87dcf5b8  mulpd xmm13, xmm14
000078eb87dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000078eb87dcf5c3  ptest xmm15, xmm15
000078eb87dcf5c9  jnz 0x000078EB87DD07C4
000078eb87dcf5cf  vxorps xmm1, xmm1, xmm1
000078eb87dcf5d3  vpbroadcastq xmm1, xmm1
000078eb87dcf5d8  vmovaps xmm14, [rsp+0xE0]
000078eb87dcf5e1  vmovaps [rsp+0xE0], xmm1
000078eb87dcf5ea  vmovaps xmm1, [rsp+0xD0]
000078eb87dcf5f3  vmovaps [rsp+0xD0], xmm13
000078eb87dcf5fc  movaps xmm15, xmm14
000078eb87dcf600  mulpd xmm15, xmm1
000078eb87dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000078eb87dcf60b  ptest xmm13, xmm13
000078eb87dcf611  jnz 0x000078EB87DD0907
000078eb87dcf617  movaps xmm1, xmm14
000078eb87dcf61b  mulpd xmm1, xmm10
000078eb87dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000078eb87dcf625  ptest xmm13, xmm13
000078eb87dcf62b  jnz 0x000078EB87DD0A4A
000078eb87dcf631  movaps xmm13, xmm14
000078eb87dcf635  mulpd xmm13, xmm2
000078eb87dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000078eb87dcf640  ptest xmm10, xmm10
000078eb87dcf646  jnz 0x000078EB87DD0B8C
000078eb87dcf64c  vmovaps [rsp+0x120], xmm7
000078eb87dcf655  vmovaps xmm14, [rsp+0x120]
000078eb87dcf65e  por xmm7, xmm14
000078eb87dcf663  vmovaps xmm14, [rsp+0xC0]
000078eb87dcf66c  vmovaps xmm10, [rsp+0xC0]
000078eb87dcf675  por xmm14, xmm10
000078eb87dcf67a  vmovaps xmm2, [rsp+0x100]
000078eb87dcf683  vpermilpd xmm2, xmm2, 0x00
000078eb87dcf689  vmovaps [rsp+0xC0], xmm1
000078eb87dcf692  vmovaps [rsp+0x120], xmm15
000078eb87dcf69b  movaps xmm1, xmm10
000078eb87dcf69f  mulpd xmm1, xmm2
000078eb87dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000078eb87dcf6a8  ptest xmm15, xmm15
000078eb87dcf6ae  jnz 0x000078EB87DD0CCF
000078eb87dcf6b4  xor eax, eax
000078eb87dcf6b6  mov r12d, 0x40
000078eb87dcf6bc  mov r11d, 0x200
000078eb87dcf6c2  cmp r12, r11
000078eb87dcf6c5  cmc
000078eb87dcf6c6  lahf
000078eb87dcf6c7  seto al
000078eb87dcf6ca  mov [r15+0x108], eax
000078eb87dcf6d1  vmovaps xmm10, [rsp+0x110]
000078eb87dcf6da  vmovaps xmm2, [rsp+0xE0]
000078eb87dcf6e3  vmovaps [rsp+0xE0], xmm1
000078eb87dcf6ec  movaps xmm15, xmm10
000078eb87dcf6f0  addpd xmm15, xmm2
000078eb87dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87dcf6fb  ptest xmm1, xmm1
000078eb87dcf700  jnz 0x000078EB87DD0E10
000078eb87dcf706  vmovaps xmm10, [rsp+0x120]
000078eb87dcf70f  vmovaps [rsp+0x110], xmm15
000078eb87dcf718  movaps xmm1, xmm10
000078eb87dcf71c  addpd xmm1, xmm12
000078eb87dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000078eb87dcf726  ptest xmm15, xmm15
000078eb87dcf72c  jnz 0x000078EB87DD0F53
000078eb87dcf732  vmovaps xmm10, [rsp+0xC0]
000078eb87dcf73b  vmovaps [rsp+0xC0], xmm1
000078eb87dcf744  movaps xmm15, xmm10
000078eb87dcf748  addpd xmm15, xmm12
000078eb87dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87dcf753  ptest xmm1, xmm1
000078eb87dcf758  jnz 0x000078EB87DD1095
000078eb87dcf75e  vmovaps xmm1, [rsp+0x30]
000078eb87dcf764  vmovaps xmm12, [rsp+0x30]
000078eb87dcf76a  por xmm1, xmm12
000078eb87dcf76f  vmovaps xmm12, [rsp+0x20]
000078eb87dcf775  vmovaps xmm10, [rsp+0x20]
000078eb87dcf77b  por xmm12, xmm10
000078eb87dcf780  vmovaps [rsp+0x20], xmm5
000078eb87dcf786  vmovaps xmm10, [rsp+0x20]
000078eb87dcf78c  por xmm5, xmm10
000078eb87dcf791  vmovaps [rsp+0x20], xmm11
000078eb87dcf797  vmovaps xmm10, [rsp+0x20]
000078eb87dcf79d  por xmm11, xmm10
000078eb87dcf7a2  vmovaps [rsp+0x20], xmm4
000078eb87dcf7a8  vmovaps xmm10, [rsp+0x20]
000078eb87dcf7ae  por xmm4, xmm10
000078eb87dcf7b3  vmovaps [rsp+0x20], xmm8
000078eb87dcf7b9  vmovaps xmm10, [rsp+0x20]
000078eb87dcf7bf  por xmm8, xmm10
000078eb87dcf7c4  vmovaps xmm10, [rsp+0xF0]
000078eb87dcf7cd  vmovaps [rsp+0x20], xmm1
000078eb87dcf7d3  vmovaps xmm1, [rsp+0xF0]
000078eb87dcf7dc  por xmm10, xmm1
000078eb87dcf7e1  lea rax, [r14+0xA0]
000078eb87dcf7e8  movups xmm1, [r13+rax*1]
000078eb87dcf7ee  lea rax, [r14+0xB0]
000078eb87dcf7f5  vmovaps [rsp+0x30], xmm1
000078eb87dcf7fb  movups xmm1, [r13+rax*1]
000078eb87dcf801  vmovaps [rsp+0xF0], xmm1
000078eb87dcf80a  vmovaps [rsp+0x120], xmm15
000078eb87dcf813  movaps xmm1, xmm13
000078eb87dcf817  addpd xmm1, xmm2
000078eb87dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000078eb87dcf820  ptest xmm15, xmm15
000078eb87dcf826  jnz 0x000078EB87DD11ED
000078eb87dcf82c  lea rax, [r14+0xF0]
000078eb87dcf833  movups xmm15, [r13+rax*1]
000078eb87dcf839  vmovaps xmm2, [rsp+0xC0]
000078eb87dcf842  vmovaps [rsp+0xC0], xmm1
000078eb87dcf84b  vmovaps xmm1, [rsp+0xE0]
000078eb87dcf854  vmovaps [rsp+0xE0], xmm15
000078eb87dcf85d  movaps xmm13, xmm2
000078eb87dcf861  addpd xmm13, xmm1
000078eb87dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000078eb87dcf86c  ptest xmm15, xmm15
000078eb87dcf872  jnz 0x000078EB87DD1338
000078eb87dcf878  vmovaps xmm15, [rsp+0x120]
000078eb87dcf881  vmovaps xmm2, [rsp+0xD0]
000078eb87dcf88a  vmovaps [rsp+0xD0], xmm14
000078eb87dcf893  movaps xmm1, xmm15
000078eb87dcf897  addpd xmm1, xmm2
000078eb87dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000078eb87dcf8a0  ptest xmm14, xmm14
000078eb87dcf8a6  jnz 0x000078EB87DD147A
000078eb87dcf8ac  vmovaps xmm15, [rsp+0x100]
000078eb87dcf8b5  vpermilpd xmm15, xmm15, 0x00
000078eb87dcf8bb  vmovaps xmm2, [rsp+0xF0]
000078eb87dcf8c4  vmovaps [rsp+0xF0], xmm1
000078eb87dcf8cd  movaps xmm14, xmm2
000078eb87dcf8d1  mulpd xmm14, xmm15
000078eb87dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000078eb87dcf8dc  ptest xmm1, xmm1
000078eb87dcf8e1  jnz 0x000078EB87DD15BB
000078eb87dcf8e7  vmovaps xmm1, [rsp+0xA0]
000078eb87dcf8f0  vpermilpd xmm1, xmm1, 0x00
000078eb87dcf8f6  vmovaps xmm2, [rsp+0xE0]
000078eb87dcf8ff  vmovaps [rsp+0xE0], xmm14
000078eb87dcf908  movaps xmm15, xmm2
000078eb87dcf90c  mulpd xmm15, xmm1
000078eb87dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000078eb87dcf917  ptest xmm14, xmm14
000078eb87dcf91d  jnz 0x000078EB87DD16FE
000078eb87dcf923  lea rax, [r14+0xE0]
000078eb87dcf92a  movups xmm1, [r13+rax*1]
000078eb87dcf930  vmovaps xmm14, [rsp+0x100]
000078eb87dcf939  vpermilpd xmm14, xmm14, 0x00
000078eb87dcf93f  vmovaps [rsp+0x100], xmm1
000078eb87dcf948  vmovaps xmm1, [rsp+0x30]
000078eb87dcf94e  vmovaps [rsp+0x30], xmm15
000078eb87dcf954  movaps xmm2, xmm1
000078eb87dcf957  mulpd xmm2, xmm14
000078eb87dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000078eb87dcf961  ptest xmm15, xmm15
000078eb87dcf967  jnz 0x000078EB87DD184A
000078eb87dcf96d  vmovaps [rsp+0x120], xmm10
000078eb87dcf976  vmovaps xmm1, [rsp+0x120]
000078eb87dcf97f  por xmm10, xmm1
000078eb87dcf984  movaps [r15+0x300], xmm10
000078eb87dcf98c  vmovaps [rsp+0x120], xmm8
000078eb87dcf995  vmovaps xmm1, [rsp+0x120]
000078eb87dcf99e  por xmm8, xmm1
000078eb87dcf9a3  movaps [r15+0x190], xmm8
000078eb87dcf9ab  vmovaps xmm1, [rsp+0xA0]
000078eb87dcf9b4  vpermilpd xmm1, xmm1, 0x00
000078eb87dcf9ba  vmovaps xmm14, [rsp+0x100]
000078eb87dcf9c3  vmovaps [rsp+0x100], xmm13
000078eb87dcf9cc  movaps xmm15, xmm14
000078eb87dcf9d0  mulpd xmm15, xmm1
000078eb87dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000078eb87dcf9db  ptest xmm13, xmm13
000078eb87dcf9e1  jnz 0x000078EB87DD198B
000078eb87dcf9e7  lea rax, [r14+0x90]
000078eb87dcf9ee  movups xmm1, [r13+rax*1]
000078eb87dcf9f4  vmovaps [rsp+0x120], xmm4
000078eb87dcf9fd  vmovaps xmm14, [rsp+0x120]
000078eb87dcfa06  por xmm4, xmm14
000078eb87dcfa0b  movaps [r15+0x1C0], xmm4
000078eb87dcfa13  vmovaps [rsp+0x120], xmm11
000078eb87dcfa1c  vmovaps xmm14, [rsp+0x120]
000078eb87dcfa25  por xmm11, xmm14
000078eb87dcfa2a  movaps [r15+0x200], xmm11
000078eb87dcfa32  vmovaps [rsp+0x120], xmm5
000078eb87dcfa3b  vmovaps xmm14, [rsp+0x120]
000078eb87dcfa44  por xmm5, xmm14
000078eb87dcfa49  movaps [r15+0x2D0], xmm5
000078eb87dcfa51  vmovaps [rsp+0x120], xmm12
000078eb87dcfa5a  vmovaps xmm14, [rsp+0x120]
000078eb87dcfa63  por xmm12, xmm14
000078eb87dcfa68  movaps [r15+0x2E0], xmm12
000078eb87dcfa70  vmovaps xmm13, [rsp+0x110]
000078eb87dcfa79  vmovaps [rsp+0x110], xmm1
000078eb87dcfa82  vmovaps xmm1, [rsp+0xE0]
000078eb87dcfa8b  vmovaps [rsp+0xE0], xmm15
000078eb87dcfa94  movaps xmm14, xmm13
000078eb87dcfa98  addpd xmm14, xmm1
000078eb87dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000078eb87dcfaa3  ptest xmm15, xmm15
000078eb87dcfaa9  jnz 0x000078EB87DD1AD8
000078eb87dcfaaf  vmovaps xmm1, [rsp+0xA0]
000078eb87dcfab8  vpermilpd xmm1, xmm1, 0x00
000078eb87dcfabe  vmovaps xmm13, [rsp+0x110]
000078eb87dcfac7  vmovaps [rsp+0x110], xmm14
000078eb87dcfad0  movaps xmm15, xmm13
000078eb87dcfad4  mulpd xmm15, xmm1
000078eb87dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000078eb87dcfadf  ptest xmm14, xmm14
000078eb87dcfae5  jnz 0x000078EB87DD1C1B
000078eb87dcfaeb  lea rax, [r14+0x80]
000078eb87dcfaf2  movups xmm1, [r13+rax*1]
000078eb87dcfaf8  vmovaps xmm13, [rsp+0xC0]
000078eb87dcfb01  vmovaps [rsp+0xC0], xmm1
000078eb87dcfb0a  movaps xmm14, xmm13
000078eb87dcfb0e  addpd xmm14, xmm2
000078eb87dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000078eb87dcfb19  ptest xmm1, xmm1
000078eb87dcfb1e  jnz 0x000078EB87DD1D68
000078eb87dcfb24  vmovaps xmm13, [rsp+0x100]
000078eb87dcfb2d  vmovaps xmm2, [rsp+0x30]
000078eb87dcfb33  vmovaps [rsp+0x30], xmm15
000078eb87dcfb39  movaps xmm1, xmm13
000078eb87dcfb3d  addpd xmm1, xmm2
000078eb87dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000078eb87dcfb46  ptest xmm15, xmm15
000078eb87dcfb4c  jnz 0x000078EB87DD1EAB
000078eb87dcfb52  vmovaps xmm15, [rsp+0x20]
000078eb87dcfb58  vmovaps xmm13, [rsp+0x20]
000078eb87dcfb5e  por xmm15, xmm13
000078eb87dcfb63  movaps [r15+0x2F0], xmm15
000078eb87dcfb6b  vmovaps xmm13, [rsp+0xA0]
000078eb87dcfb74  vpermilpd xmm13, xmm13, 0x00
000078eb87dcfb7a  vmovaps [rsp+0x20], xmm1
000078eb87dcfb80  vmovaps xmm1, [rsp+0xC0]
000078eb87dcfb89  vmovaps [rsp+0xA0], xmm15
000078eb87dcfb92  movaps xmm2, xmm1
000078eb87dcfb95  mulpd xmm2, xmm13
000078eb87dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000078eb87dcfb9f  ptest xmm15, xmm15
000078eb87dcfba5  jnz 0x000078EB87DD1FEC
000078eb87dcfbab  lea rax, [r14+0xD0]
000078eb87dcfbb2  movups xmm1, [r13+rax*1]
000078eb87dcfbb8  vmovaps xmm13, [rsp+0xF0]
000078eb87dcfbc1  vmovaps [rsp+0xC0], xmm1
000078eb87dcfbca  vmovaps xmm1, [rsp+0xE0]
000078eb87dcfbd3  vmovaps [rsp+0xE0], xmm14
000078eb87dcfbdc  movaps xmm15, xmm13
000078eb87dcfbe0  addpd xmm15, xmm1
000078eb87dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000078eb87dcfbeb  ptest xmm14, xmm14
000078eb87dcfbf1  jnz 0x000078EB87DD2137
000078eb87dcfbf7  vmovaps xmm1, [rsp+0xB0]
000078eb87dcfc00  vpermilpd xmm1, xmm1, 0x00
000078eb87dcfc06  movaps xmm14, xmm11
000078eb87dcfc0a  mulpd xmm14, xmm1
000078eb87dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000078eb87dcfc15  ptest xmm13, xmm13
000078eb87dcfc1b  jnz 0x000078EB87DD227A
000078eb87dcfc21  movaps [r15+0x260], xmm14
000078eb87dcfc29  vxorps xmm1, xmm1, xmm1
000078eb87dcfc2d  vpbroadcastq xmm1, xmm1
000078eb87dcfc32  movaps [r15+0x1B0], xmm1
000078eb87dcfc3a  vmovaps xmm1, [rsp+0xB0]
000078eb87dcfc43  vpermilpd xmm1, xmm1, 0x00
000078eb87dcfc49  vmovaps xmm11, [rsp+0xC0]
000078eb87dcfc52  vmovaps [rsp+0xC0], xmm15
000078eb87dcfc5b  movaps xmm13, xmm11
000078eb87dcfc5f  mulpd xmm13, xmm1
000078eb87dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000078eb87dcfc6a  ptest xmm15, xmm15
000078eb87dcfc70  jnz 0x000078EB87DD23BD
000078eb87dcfc76  lea rax, [r14+0xC0]
000078eb87dcfc7d  movups xmm1, [r13+rax*1]
000078eb87dcfc83  vmovaps xmm11, [rsp+0x110]
000078eb87dcfc8c  vmovaps [rsp+0xF0], xmm1
000078eb87dcfc95  vmovaps xmm1, [rsp+0x30]
000078eb87dcfc9b  vmovaps [rsp+0x30], xmm14
000078eb87dcfca1  movaps xmm15, xmm11
000078eb87dcfca5  addpd xmm15, xmm1
000078eb87dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000078eb87dcfcb0  ptest xmm14, xmm14
000078eb87dcfcb6  jnz 0x000078EB87DD250A
000078eb87dcfcbc  vmovaps [rsp+0x100], xmm9
000078eb87dcfcc5  vmovaps xmm1, [rsp+0x100]
000078eb87dcfcce  por xmm9, xmm1
000078eb87dcfcd3  movaps [r15+0x270], xmm9
000078eb87dcfcdb  vmovaps [rsp+0x100], xmm6
000078eb87dcfce4  vmovaps xmm1, [rsp+0x100]
000078eb87dcfced  por xmm6, xmm1
000078eb87dcfcf1  movaps [r15+0x1A0], xmm6
000078eb87dcfcf9  vmovaps xmm14, [rsp+0xB0]
000078eb87dcfd02  vpermilpd xmm14, xmm14, 0x00
000078eb87dcfd08  vmovaps xmm6, [rsp+0xF0]
000078eb87dcfd11  vmovaps [rsp+0xF0], xmm1
000078eb87dcfd1a  movaps xmm11, xmm6
000078eb87dcfd1e  mulpd xmm11, xmm14
000078eb87dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000078eb87dcfd29  ptest xmm1, xmm1
000078eb87dcfd2e  jnz 0x000078EB87DD264D
000078eb87dcfd34  lea rax, [r14+0x20]
000078eb87dcfd38  movups xmm1, [r13+rax*1]
000078eb87dcfd3e  movaps [r15+0x110], xmm1
000078eb87dcfd46  vmovaps xmm6, [rsp+0xE0]
000078eb87dcfd4f  vmovaps [rsp+0xE0], xmm1
000078eb87dcfd58  movaps xmm14, xmm6
000078eb87dcfd5c  addpd xmm14, xmm2
000078eb87dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000078eb87dcfd67  ptest xmm1, xmm1
000078eb87dcfd6c  jnz 0x000078EB87DD279A
000078eb87dcfd72  vmovaps xmm1, [rsp+0xB0]
000078eb87dcfd7b  vpermilpd xmm1, xmm1, 0x00
000078eb87dcfd81  movaps xmm6, xmm5
000078eb87dcfd84  mulpd xmm6, xmm1
000078eb87dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000078eb87dcfd8d  ptest xmm2, xmm2
000078eb87dcfd92  jnz 0x000078EB87DD28DC
000078eb87dcfd98  vmovaps xmm5, [rsp+0x20]
000078eb87dcfd9e  movaps xmm1, xmm5
000078eb87dcfda1  addpd xmm1, xmm13
000078eb87dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000078eb87dcfdab  ptest xmm2, xmm2
000078eb87dcfdb0  jnz 0x000078EB87DD2A1C
000078eb87dcfdb6  vmovaps xmm13, [rsp+0x80]
000078eb87dcfdbf  vpermilpd xmm13, xmm13, 0x00
000078eb87dcfdc5  vmovaps xmm2, [rsp+0xE0]
000078eb87dcfdce  vmovaps [rsp+0x20], xmm1
000078eb87dcfdd4  movaps xmm5, xmm2
000078eb87dcfdd7  mulpd xmm5, xmm13
000078eb87dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000078eb87dcfde1  ptest xmm1, xmm1
000078eb87dcfde6  jnz 0x000078EB87DD2B5D
000078eb87dcfdec  vmovaps xmm1, [rsp+0x80]
000078eb87dcfdf5  vpermilpd xmm1, xmm1, 0x00
000078eb87dcfdfb  movaps xmm13, xmm10
000078eb87dcfdff  mulpd xmm13, xmm1
000078eb87dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000078eb87dcfe0a  ptest xmm2, xmm2
000078eb87dcfe0f  jnz 0x000078EB87DD2C9E
000078eb87dcfe15  vmovaps xmm10, [rsp+0x30]
000078eb87dcfe1b  movaps xmm1, xmm15
000078eb87dcfe1f  addpd xmm1, xmm10
000078eb87dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000078eb87dcfe29  ptest xmm2, xmm2
000078eb87dcfe2e  jnz 0x000078EB87DD2DE1
000078eb87dcfe34  vmovaps xmm10, [rsp+0xC0]
000078eb87dcfe3d  movaps xmm15, xmm10
000078eb87dcfe41  addpd xmm15, xmm11
000078eb87dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000078eb87dcfe4c  ptest xmm2, xmm2
000078eb87dcfe51  jnz 0x000078EB87DD2F23
000078eb87dcfe57  vmovaps xmm11, [rsp+0x80]
000078eb87dcfe60  vpermilpd xmm11, xmm11, 0x00
000078eb87dcfe66  movaps xmm10, xmm12
000078eb87dcfe6a  mulpd xmm10, xmm11
000078eb87dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000078eb87dcfe75  ptest xmm2, xmm2
000078eb87dcfe7a  jnz 0x000078EB87DD3067
000078eb87dcfe80  vmovaps xmm12, [rsp+0x80]
000078eb87dcfe89  vpermilpd xmm12, xmm12, 0x00
000078eb87dcfe8f  vmovaps xmm2, [rsp+0xA0]
000078eb87dcfe98  vmovaps [rsp+0x30], xmm1
000078eb87dcfe9e  movaps xmm11, xmm2
000078eb87dcfea2  mulpd xmm11, xmm12
000078eb87dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000078eb87dcfead  ptest xmm1, xmm1
000078eb87dcfeb2  jnz 0x000078EB87DD31AB
000078eb87dcfeb8  movaps xmm1, xmm14
000078eb87dcfebc  addpd xmm1, xmm6
000078eb87dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000078eb87dcfec5  ptest xmm12, xmm12
000078eb87dcfecb  jnz 0x000078EB87DD32EE
000078eb87dcfed1  vmovaps xmm12, [rsp+0x20]
000078eb87dcfed7  movaps xmm14, xmm12
000078eb87dcfedb  addpd xmm14, xmm5
000078eb87dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000078eb87dcfee6  ptest xmm6, xmm6
000078eb87dcfeeb  jnz 0x000078EB87DD342F
000078eb87dcfef1  vmovaps xmm12, [rsp+0x90]
000078eb87dcfefa  vpermilpd xmm12, xmm12, 0x00
000078eb87dcff00  movaps xmm6, xmm9
000078eb87dcff04  mulpd xmm6, xmm12
000078eb87dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000078eb87dcff0e  ptest xmm5, xmm5
000078eb87dcff13  jnz 0x000078EB87DD3572
000078eb87dcff19  movaps xmm12, xmm15
000078eb87dcff1d  addpd xmm12, xmm13
000078eb87dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000078eb87dcff28  ptest xmm9, xmm9
000078eb87dcff2e  jnz 0x000078EB87DD36B4
000078eb87dcff34  vmovaps xmm13, [rsp+0x30]
000078eb87dcff3a  movaps xmm15, xmm13
000078eb87dcff3e  addpd xmm15, xmm10
000078eb87dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000078eb87dcff49  ptest xmm9, xmm9
000078eb87dcff4f  jnz 0x000078EB87DD37F8
000078eb87dcff55  vmovaps xmm13, [rsp+0xD0]
000078eb87dcff5e  vmovaps xmm10, [rsp+0xD0]
000078eb87dcff67  por xmm13, xmm10
000078eb87dcff6c  movaps [r15+0x250], xmm13
000078eb87dcff74  vmovaps [rsp+0x20], xmm7
000078eb87dcff7a  vmovaps xmm13, [rsp+0x20]
000078eb87dcff80  por xmm7, xmm13
000078eb87dcff85  movaps [r15+0x2A0], xmm7
000078eb87dcff8d  vmovaps [rsp+0x20], xmm3
000078eb87dcff93  vmovaps xmm13, [rsp+0x20]
000078eb87dcff99  por xmm3, xmm13
000078eb87dcff9e  movaps [r15+0x1D0], xmm3
000078eb87dcffa6  lea rax, [r14+0x40]
000078eb87dcffaa  movups xmm13, [r13+rax*1]
000078eb87dcffb0  movaps [r15+0x2C0], xmm13
000078eb87dcffb8  vmovaps xmm10, [rsp+0x90]
000078eb87dcffc1  vpermilpd xmm10, xmm10, 0x00
000078eb87dcffc7  movaps xmm9, xmm8
000078eb87dcffcb  mulpd xmm9, xmm10
000078eb87dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000078eb87dcffd6  ptest xmm5, xmm5
000078eb87dcffdb  jnz 0x000078EB87DD3946
000078eb87dcffe1  movaps xmm10, xmm1
000078eb87dcffe5  addpd xmm10, xmm11
000078eb87dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000078eb87dcfff0  ptest xmm8, xmm8
000078eb87dcfff6  jnz 0x000078EB87DD3A8A
000078eb87dcfffc  movaps xmm1, xmm14
000078eb87dd0000  addpd xmm1, xmm6
000078eb87dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000078eb87dd0009  ptest xmm11, xmm11
000078eb87dd000f  jnz 0x000078EB87DD3BCD
000078eb87dd0015  vmovaps xmm14, [rsp+0x90]
000078eb87dd001e  vpermilpd xmm14, xmm14, 0x00
000078eb87dd0024  movaps xmm11, xmm13
000078eb87dd0028  mulpd xmm11, xmm14
000078eb87dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000078eb87dd0033  ptest xmm8, xmm8
000078eb87dd0039  jnz 0x000078EB87DD3D0E
000078eb87dd003f  vmovaps xmm14, [rsp+0x90]
000078eb87dd0048  vpermilpd xmm14, xmm14, 0x00
000078eb87dd004e  vmovaps xmm8, [rsp+0x10]
000078eb87dd0054  movaps xmm13, xmm8
000078eb87dd0058  mulpd xmm13, xmm14
000078eb87dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000078eb87dd0063  ptest xmm6, xmm6
000078eb87dd0068  jnz 0x000078EB87DD3E52
000078eb87dd006e  vmovaps xmm14, [rsp+0x60]
000078eb87dd0074  vpermilpd xmm14, xmm14, 0x00
000078eb87dd007a  movaps xmm8, xmm7
000078eb87dd007e  mulpd xmm8, xmm14
000078eb87dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000078eb87dd0089  ptest xmm6, xmm6
000078eb87dd008e  jnz 0x000078EB87DD3F96
000078eb87dd0094  movaps xmm14, xmm12
000078eb87dd0098  addpd xmm14, xmm9
000078eb87dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000078eb87dd00a3  ptest xmm7, xmm7
000078eb87dd00a8  jnz 0x000078EB87DD40D9
000078eb87dd00ae  vmovaps xmm12, [rsp+0x60]
000078eb87dd00b4  vpermilpd xmm12, xmm12, 0x00
000078eb87dd00ba  vmovaps xmm7, [rsp+0xF0]
000078eb87dd00c3  movaps xmm9, xmm7
000078eb87dd00c7  mulpd xmm9, xmm12
000078eb87dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000078eb87dd00d2  ptest xmm6, xmm6
000078eb87dd00d7  jnz 0x000078EB87DD421D
000078eb87dd00dd  movaps xmm12, xmm15
000078eb87dd00e1  addpd xmm12, xmm11
000078eb87dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000078eb87dd00ec  ptest xmm7, xmm7
000078eb87dd00f1  jnz 0x000078EB87DD4360
000078eb87dd00f7  vmovaps xmm15, [rsp+0x60]
000078eb87dd00fd  vpermilpd xmm15, xmm15, 0x00
000078eb87dd0103  vmovaps xmm7, [rsp+0x40]
000078eb87dd0109  movaps xmm11, xmm7
000078eb87dd010d  mulpd xmm11, xmm15
000078eb87dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000078eb87dd0118  ptest xmm6, xmm6
000078eb87dd011d  jnz 0x000078EB87DD44A4
000078eb87dd0123  movaps xmm15, xmm10
000078eb87dd0127  addpd xmm15, xmm13
000078eb87dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000078eb87dd0132  ptest xmm7, xmm7
000078eb87dd0137  jnz 0x000078EB87DD45E7
000078eb87dd013d  vmovaps xmm13, [rsp+0x60]
000078eb87dd0143  vpermilpd xmm13, xmm13, 0x00
000078eb87dd0149  vmovaps xmm7, [rsp+0x50]
000078eb87dd014f  movaps xmm10, xmm7
000078eb87dd0153  mulpd xmm10, xmm13
000078eb87dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000078eb87dd015e  ptest xmm6, xmm6
000078eb87dd0163  jnz 0x000078EB87DD472B
000078eb87dd0169  movaps xmm13, xmm1
000078eb87dd016d  addpd xmm13, xmm8
000078eb87dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000078eb87dd0178  ptest xmm7, xmm7
000078eb87dd017d  jnz 0x000078EB87DD486E
000078eb87dd0183  lea rax, [r14+0x70]
000078eb87dd0187  movups xmm1, [r13+rax*1]
000078eb87dd018d  movaps [r15+0x240], xmm1
000078eb87dd0195  movaps xmm8, xmm14
000078eb87dd0199  addpd xmm8, xmm9
000078eb87dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000078eb87dd01a4  ptest xmm7, xmm7
000078eb87dd01a9  jnz 0x000078EB87DD49BB
000078eb87dd01af  movaps [r15+0x170], xmm8
000078eb87dd01b7  vmovaps xmm14, [rsp+0x70]
000078eb87dd01bd  vpermilpd xmm14, xmm14, 0x00
000078eb87dd01c3  movaps xmm9, xmm1
000078eb87dd01c7  mulpd xmm9, xmm14
000078eb87dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000078eb87dd01d2  ptest xmm7, xmm7
000078eb87dd01d7  jnz 0x000078EB87DD4AFF
000078eb87dd01dd  vmovaps xmm1, [rsp+0x70]
000078eb87dd01e3  vpermilpd xmm1, xmm1, 0x00
000078eb87dd01e9  movaps xmm14, xmm4
000078eb87dd01ed  mulpd xmm14, xmm1
000078eb87dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000078eb87dd01f8  ptest xmm7, xmm7
000078eb87dd01fd  jnz 0x000078EB87DD4C42
000078eb87dd0203  movaps [r15+0x180], xmm14
000078eb87dd020b  movaps xmm1, xmm12
000078eb87dd020f  addpd xmm1, xmm11
000078eb87dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000078eb87dd0219  ptest xmm7, xmm7
000078eb87dd021e  jnz 0x000078EB87DD4D84
000078eb87dd0224  movaps [r15+0x210], xmm1
000078eb87dd022c  movups xmm12, [r13+r14*1]
000078eb87dd0232  lea rax, [r14+0x10]
000078eb87dd0236  movups xmm11, [r13+rax*1]
000078eb87dd023c  movaps [r15+0x230], xmm11
000078eb87dd0244  movaps xmm7, xmm15
000078eb87dd0248  addpd xmm7, xmm10
000078eb87dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000078eb87dd0252  ptest xmm6, xmm6
000078eb87dd0257  jnz 0x000078EB87DD4EDA
000078eb87dd025d  movaps [r15+0x130], xmm7
000078eb87dd0265  vmovaps xmm15, [rsp+0x70]
000078eb87dd026b  vpermilpd xmm15, xmm15, 0x00
000078eb87dd0271  movaps xmm10, xmm11
000078eb87dd0275  mulpd xmm10, xmm15
000078eb87dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000078eb87dd0280  ptest xmm6, xmm6
000078eb87dd0285  jnz 0x000078EB87DD501C
000078eb87dd028b  movaps [r15+0x220], xmm10
000078eb87dd0293  vmovaps xmm15, [rsp+0x70]
000078eb87dd0299  vpermilpd xmm15, xmm15, 0x00
000078eb87dd029f  movaps xmm11, xmm12
000078eb87dd02a3  mulpd xmm11, xmm15
000078eb87dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000078eb87dd02ae  ptest xmm6, xmm6
000078eb87dd02b3  jnz 0x000078EB87DD5160
000078eb87dd02b9  movaps xmm15, xmm13
000078eb87dd02bd  addpd xmm15, xmm9
000078eb87dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000078eb87dd02c8  ptest xmm12, xmm12
000078eb87dd02ce  jnz 0x000078EB87DD52A4
000078eb87dd02d4  movaps [r15+0x140], xmm15
000078eb87dd02dc  movaps xmm13, xmm8
000078eb87dd02e0  addpd xmm13, xmm14
000078eb87dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000078eb87dd02eb  ptest xmm12, xmm12
000078eb87dd02f1  jnz 0x000078EB87DD53E8
000078eb87dd02f7  movaps [r15+0x150], xmm13
000078eb87dd02ff  movaps xmm14, xmm1
000078eb87dd0303  addpd xmm14, xmm10
000078eb87dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000078eb87dd030e  ptest xmm12, xmm12
000078eb87dd0314  jnz 0x000078EB87DD552C
000078eb87dd031a  movaps [r15+0x160], xmm14
000078eb87dd0322  movaps xmm1, xmm7
000078eb87dd0325  addpd xmm1, xmm11
000078eb87dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000078eb87dd032f  ptest xmm12, xmm12
000078eb87dd0335  jnz 0x000078EB87DD566F
000078eb87dd033b  movaps [r15+0x120], xmm1
000078eb87dd0343  mov eax, 0x430920
000078eb87dd0348  movups [r13+rax*1], xmm15
000078eb87dd034e  mov eax, 0x430930
000078eb87dd0353  movups [r13+rax*1], xmm13
000078eb87dd0359  mov eax, 0x430940
000078eb87dd035e  movups [r13+rax*1], xmm14
000078eb87dd0364  mov eax, 0x430950
000078eb87dd0369  movups [r13+rax*1], xmm1
000078eb87dd036f  mov eax, [r15+0x108]
000078eb87dd0376  sahf
000078eb87dd0377  jnz 0x000078EB87DD03A9
000078eb87dd0379  cmp dword ptr [r15+0x318], 0x00
000078eb87dd0381  jz 0x000078EB87DDB900
000078eb87dd0387  nop [rax+rax*1], ax
000078eb87dd0390  nop [rax+rax*1], eax
000078eb87dd0398  mov eax, 0x410444
000078eb87dd039d  mov [r15+0x100], rax
000078eb87dd03a4  jmp 0x000078EB87BFE110
000078eb87dd03a9  cmp dword ptr [r15+0x318], 0x00
000078eb87dd03b1  jz 0x000078EB87DD57E0
000078eb87dd03b7  nop [rax+rax*1], ax
000078eb87dd03c0  nop [rax+rax*1], eax
000078eb87dd03c8  mov eax, 0x410278
000078eb87dd03cd  mov [r15+0x100], rax
000078eb87dd03d4  jmp 0x000078EB87BFE110
000078eb87dd03d9  int3
000078eb87dd03da  call 0x000078EB87CB52F0
000078eb87dd03df  jmp 0x000078EB87DCF016
000078eb87dd03e4  call 0x000078EB87CC4620
000078eb87dd03e9  jmp 0x000078EB87DCF023
000078eb87dd03ee  call 0x000078EB87CC33A0
000078eb87dd03f3  jmp 0x000078EB87DCF035
000078eb87dd03f8  call 0x000078EB87CC2120
000078eb87dd03fd  jmp 0x000078EB87DCF03F
000078eb87dd0402  call 0x000078EB87CC0860
000078eb87dd0407  jmp 0x000078EB87DCF067
000078eb87dd040c  call 0x000078EB87CBF5F0
000078eb87dd0411  jmp 0x000078EB87DCF073
000078eb87dd0416  call 0x000078EB87CC0860
000078eb87dd041b  jmp 0x000078EB87DCF0A5
000078eb87dd0420  call 0x000078EB87CBF5F0
000078eb87dd0425  jmp 0x000078EB87DCF0B1
000078eb87dd042a  call 0x000078EB87CC4740
000078eb87dd042f  jmp 0x000078EB87DCF0BE
000078eb87dd0434  call 0x000078EB87CB5400
000078eb87dd0439  jmp 0x000078EB87DCF0CB
000078eb87dd043e  call 0x000078EB87CB52F0
000078eb87dd0443  jmp 0x000078EB87DCF0D8
000078eb87dd0448  call 0x000078EB87CC4620
000078eb87dd044d  jmp 0x000078EB87DCF0E5
000078eb87dd0452  call 0x000078EB87CC0860
000078eb87dd0457  jmp 0x000078EB87DCF10D
000078eb87dd045c  call 0x000078EB87CBF5F0
000078eb87dd0461  jmp 0x000078EB87DCF119
000078eb87dd0466  call 0x000078EB87C09D70
000078eb87dd046b  jmp 0x000078EB87DCF11F
000078eb87dd0470  call 0x000078EB87CBE9C0
000078eb87dd0475  jmp 0x000078EB87DCF129
000078eb87dd047a  call 0x000078EB87CC0860
000078eb87dd047f  jmp 0x000078EB87DCF151
000078eb87dd0484  call 0x000078EB87CBF5F0
000078eb87dd0489  jmp 0x000078EB87DCF15D
000078eb87dd048e  call 0x000078EB87CBD750
000078eb87dd0493  jmp 0x000078EB87DCF16A
000078eb87dd0498  call 0x000078EB87CBC4E0
000078eb87dd049d  jmp 0x000078EB87DCF177
000078eb87dd04a2  call 0x000078EB87CC4740
000078eb87dd04a7  jmp 0x000078EB87DCF184
000078eb87dd04ac  call 0x000078EB87CB5400
000078eb87dd04b1  jmp 0x000078EB87DCF191
000078eb87dd04b6  call 0x000078EB87CB52F0
000078eb87dd04bb  jmp 0x000078EB87DCF19E
000078eb87dd04c0  call 0x000078EB87CC4620
000078eb87dd04c5  jmp 0x000078EB87DCF1AB
000078eb87dd04ca  call 0x000078EB87CC0860
000078eb87dd04cf  jmp 0x000078EB87DCF1BE
000078eb87dd04d4  call 0x000078EB87CBB270
000078eb87dd04d9  jmp 0x000078EB87DCF1CB
000078eb87dd04de  call 0x000078EB87CBA000
000078eb87dd04e3  jmp 0x000078EB87DCF1D8
000078eb87dd04e8  call 0x000078EB87CB8D90
000078eb87dd04ed  jmp 0x000078EB87DCF1E5
000078eb87dd04f2  call 0x000078EB87CB8A20
000078eb87dd04f7  jmp 0x000078EB87DCF1F2
000078eb87dd04fc  call 0x000078EB87CB5400
000078eb87dd0501  jmp 0x000078EB87DCF1FC
000078eb87dd0506  call 0x000078EB87CC2240
000078eb87dd050b  jmp 0x000078EB87DCF206
000078eb87dd0510  call 0x000078EB87CB52F0
000078eb87dd0515  jmp 0x000078EB87DCF210
000078eb87dd051a  call 0x000078EB87CC2120
000078eb87dd051f  jmp 0x000078EB87DCF21A
000078eb87dd0524  call 0x000078EB87CB77B0
000078eb87dd0529  jmp 0x000078EB87DCF224
000078eb87dd052e  call 0x000078EB87CB6550
000078eb87dd0533  jmp 0x000078EB87DCF22E
000078eb87dd0538  call 0x000078EB87CBFD50
000078eb87dd053d  jmp 0x000078EB87DCF240
000078eb87dd0542  call 0x000078EB87CB8EA0
000078eb87dd0547  jmp 0x000078EB87DCF24A
000078eb87dd054c  call 0x000078EB87CBFC30
000078eb87dd0551  jmp 0x000078EB87DCF257
000078eb87dd0556  call 0x000078EB87CB8D90
000078eb87dd055b  jmp 0x000078EB87DCF264
000078eb87dd0560  call 0x000078EB87CC2240
000078eb87dd0565  jmp 0x000078EB87DCF271
000078eb87dd056a  call 0x000078EB87CB5400
000078eb87dd056f  jmp 0x000078EB87DCF27E
000078eb87dd0574  call 0x000078EB87CB52F0
000078eb87dd0579  jmp 0x000078EB87DCF28B
000078eb87dd057e  call 0x000078EB87CC2120
000078eb87dd0583  jmp 0x000078EB87DCF298
000078eb87dd0588  call 0x000078EB87CB52F0
000078eb87dd058d  jmp 0x000078EB87DCF2AB
000078eb87dd0592  call 0x000078EB87CB52F0
000078eb87dd0597  jmp 0x000078EB87DCF2BE
000078eb87dd059c  call 0x000078EB87CB52F0
000078eb87dd05a1  jmp 0x000078EB87DCF2D1
000078eb87dd05a6  call 0x000078EB87CB52F0
000078eb87dd05ab  jmp 0x000078EB87DCF2E4
000078eb87dd05b0  call 0x000078EB87CC2240
000078eb87dd05b5  jmp 0x000078EB87DCF2F9
000078eb87dd05ba  call 0x000078EB87CC2240
000078eb87dd05bf  jmp 0x000078EB87DCF30C
000078eb87dd05c4  call 0x000078EB87CC2120
000078eb87dd05c9  jmp 0x000078EB87DCF319
000078eb87dd05ce  call 0x000078EB87CB52F0
000078eb87dd05d3  jmp 0x000078EB87DCF32C
000078eb87dd05d8  call 0x000078EB87CB52F0
000078eb87dd05dd  jmp 0x000078EB87DCF34F
000078eb87dd05e2  call 0x000078EB87CB52F0
000078eb87dd05e7  jmp 0x000078EB87DCF362
000078eb87dd05ec  call 0x000078EB87BFF540
000078eb87dd05f1  jmp 0x000078EB87DCF380
000078eb87dd05f6  call 0x000078EB87C08C20
000078eb87dd05fb  jmp 0x000078EB87DCF38A
000078eb87dd0600  call 0x000078EB87CD6600
000078eb87dd0605  jmp 0x000078EB87DCF396
000078eb87dd060a  call 0x000078EB87BFF540
000078eb87dd060f  jmp 0x000078EB87DCF3A6
000078eb87dd0614  call 0x000078EB87CC0370
000078eb87dd0619  jmp 0x000078EB87DCF3D4
000078eb87dd061e  call 0x000078EB87CBF100
000078eb87dd0623  jmp 0x000078EB87DCF3DD
000078eb87dd0628  call 0x000078EB87CC0370
000078eb87dd062d  jmp 0x000078EB87DCF43B
000078eb87dd0632  call 0x000078EB87CBF100
000078eb87dd0637  jmp 0x000078EB87DCF444
000078eb87dd063c  call 0x000078EB87CC0370
000078eb87dd0641  jmp 0x000078EB87DCF48B
000078eb87dd0646  call 0x000078EB87CBF100
000078eb87dd064b  jmp 0x000078EB87DCF494
000078eb87dd0650  call 0x000078EB87C0B720
000078eb87dd0655  jmp 0x000078EB87DCF4D7
000078eb87dd065a  call 0x000078EB87CB47C0
000078eb87dd065f  jmp 0x000078EB87DCF4EA
000078eb87dd0664  call 0x000078EB87C08B00
000078eb87dd0669  jmp 0x000078EB87DCF501
000078eb87dd066e  call 0x000078EB87BFF430
000078eb87dd0673  jmp 0x000078EB87DCF514
000078eb87dd0678  call 0x000078EB87BFF430
000078eb87dd067d  jmp 0x000078EB87DCF527
000078eb87dd0682  sub rsp, 0x08
000078eb87dd0686  push rax
000078eb87dd0687  push rcx
000078eb87dd0688  push rdx
000078eb87dd0689  push rdi
000078eb87dd068a  push rsi
000078eb87dd068b  push r8
000078eb87dd068d  push r9
000078eb87dd068f  push r10
000078eb87dd0691  push r11
000078eb87dd0693  sub rsp, 0xF0
000078eb87dd069a  vmovaps [rsp], xmm0
000078eb87dd069f  vmovaps [rsp+0x10], xmm2
000078eb87dd06a5  vmovaps [rsp+0x20], xmm3
000078eb87dd06ab  vmovaps [rsp+0x30], xmm4
000078eb87dd06b1  vmovaps [rsp+0x40], xmm5
000078eb87dd06b7  vmovaps [rsp+0x50], xmm6
000078eb87dd06bd  vmovaps [rsp+0x60], xmm7
000078eb87dd06c3  vmovaps [rsp+0x70], xmm8
000078eb87dd06c9  vmovaps [rsp+0x80], xmm9
000078eb87dd06d2  vmovaps [rsp+0x90], xmm10
000078eb87dd06db  vmovaps [rsp+0xA0], xmm11
000078eb87dd06e4  vmovaps [rsp+0xB0], xmm12
000078eb87dd06ed  vmovaps [rsp+0xC0], xmm13
000078eb87dd06f6  vmovaps [rsp+0xD0], xmm14
000078eb87dd06ff  vmovaps [rsp+0xE0], xmm15
000078eb87dd0708  sub rsp, 0x30
000078eb87dd070c  movaps [rsp], xmm1
000078eb87dd0710  movaps [rsp+0x10], xmm15
000078eb87dd0716  movaps [rsp+0x20], xmm14
000078eb87dd071c  lea rdi, [rsp]
000078eb87dd0720  mov esi, 0x00
000078eb87dd0725  mov rax, 0x61D341A71530
000078eb87dd072f  call rax
000078eb87dd0731  movaps xmm1, [rsp]
000078eb87dd0735  add rsp, 0x30
000078eb87dd0739  vmovaps xmm0, [rsp]
000078eb87dd073e  vmovaps xmm2, [rsp+0x10]
000078eb87dd0744  vmovaps xmm3, [rsp+0x20]
000078eb87dd074a  vmovaps xmm4, [rsp+0x30]
000078eb87dd0750  vmovaps xmm5, [rsp+0x40]
000078eb87dd0756  vmovaps xmm6, [rsp+0x50]
000078eb87dd075c  vmovaps xmm7, [rsp+0x60]
000078eb87dd0762  vmovaps xmm8, [rsp+0x70]
000078eb87dd0768  vmovaps xmm9, [rsp+0x80]
000078eb87dd0771  vmovaps xmm10, [rsp+0x90]
000078eb87dd077a  vmovaps xmm11, [rsp+0xA0]
000078eb87dd0783  vmovaps xmm12, [rsp+0xB0]
000078eb87dd078c  vmovaps xmm13, [rsp+0xC0]
000078eb87dd0795  vmovaps xmm14, [rsp+0xD0]
000078eb87dd079e  vmovaps xmm15, [rsp+0xE0]
000078eb87dd07a7  add rsp, 0xF0
000078eb87dd07ae  pop r11
000078eb87dd07b0  pop r10
000078eb87dd07b2  pop r9
000078eb87dd07b4  pop r8
000078eb87dd07b6  pop rsi
000078eb87dd07b7  pop rdi
000078eb87dd07b8  pop rdx
000078eb87dd07b9  pop rcx
000078eb87dd07ba  pop rax
000078eb87dd07bb  add rsp, 0x08
000078eb87dd07bf  jmp 0x000078EB87DCF581
000078eb87dd07c4  sub rsp, 0x08
000078eb87dd07c8  push rax
000078eb87dd07c9  push rcx
000078eb87dd07ca  push rdx
000078eb87dd07cb  push rdi
000078eb87dd07cc  push rsi
000078eb87dd07cd  push r8
000078eb87dd07cf  push r9
000078eb87dd07d1  push r10
000078eb87dd07d3  push r11
000078eb87dd07d5  sub rsp, 0xF0
000078eb87dd07dc  vmovaps [rsp], xmm0
000078eb87dd07e1  vmovaps [rsp+0x10], xmm1
000078eb87dd07e7  vmovaps [rsp+0x20], xmm2
000078eb87dd07ed  vmovaps [rsp+0x30], xmm3
000078eb87dd07f3  vmovaps [rsp+0x40], xmm4
000078eb87dd07f9  vmovaps [rsp+0x50], xmm5
000078eb87dd07ff  vmovaps [rsp+0x60], xmm6
000078eb87dd0805  vmovaps [rsp+0x70], xmm7
000078eb87dd080b  vmovaps [rsp+0x80], xmm8
000078eb87dd0814  vmovaps [rsp+0x90], xmm9
000078eb87dd081d  vmovaps [rsp+0xA0], xmm10
000078eb87dd0826  vmovaps [rsp+0xB0], xmm11
000078eb87dd082f  vmovaps [rsp+0xC0], xmm12
000078eb87dd0838  vmovaps [rsp+0xD0], xmm14
000078eb87dd0841  vmovaps [rsp+0xE0], xmm15
000078eb87dd084a  sub rsp, 0x30
000078eb87dd084e  movaps [rsp], xmm13
000078eb87dd0853  movaps [rsp+0x10], xmm1
000078eb87dd0858  movaps [rsp+0x20], xmm14
000078eb87dd085e  lea rdi, [rsp]
000078eb87dd0862  mov esi, 0x00
000078eb87dd0867  mov rax, 0x61D341A71530
000078eb87dd0871  call rax
000078eb87dd0873  movaps xmm13, [rsp]
000078eb87dd0878  add rsp, 0x30
000078eb87dd087c  vmovaps xmm0, [rsp]
000078eb87dd0881  vmovaps xmm1, [rsp+0x10]
000078eb87dd0887  vmovaps xmm2, [rsp+0x20]
000078eb87dd088d  vmovaps xmm3, [rsp+0x30]
000078eb87dd0893  vmovaps xmm4, [rsp+0x40]
000078eb87dd0899  vmovaps xmm5, [rsp+0x50]
000078eb87dd089f  vmovaps xmm6, [rsp+0x60]
000078eb87dd08a5  vmovaps xmm7, [rsp+0x70]
000078eb87dd08ab  vmovaps xmm8, [rsp+0x80]
000078eb87dd08b4  vmovaps xmm9, [rsp+0x90]
000078eb87dd08bd  vmovaps xmm10, [rsp+0xA0]
000078eb87dd08c6  vmovaps xmm11, [rsp+0xB0]
000078eb87dd08cf  vmovaps xmm12, [rsp+0xC0]
000078eb87dd08d8  vmovaps xmm14, [rsp+0xD0]
000078eb87dd08e1  vmovaps xmm15, [rsp+0xE0]
000078eb87dd08ea  add rsp, 0xF0
000078eb87dd08f1  pop r11
000078eb87dd08f3  pop r10
000078eb87dd08f5  pop r9
000078eb87dd08f7  pop r8
000078eb87dd08f9  pop rsi
000078eb87dd08fa  pop rdi
000078eb87dd08fb  pop rdx
000078eb87dd08fc  pop rcx
000078eb87dd08fd  pop rax
000078eb87dd08fe  add rsp, 0x08
000078eb87dd0902  jmp 0x000078EB87DCF5CF
000078eb87dd0907  sub rsp, 0x08
000078eb87dd090b  push rax
000078eb87dd090c  push rcx
000078eb87dd090d  push rdx
000078eb87dd090e  push rdi
000078eb87dd090f  push rsi
000078eb87dd0910  push r8
000078eb87dd0912  push r9
000078eb87dd0914  push r10
000078eb87dd0916  push r11
000078eb87dd0918  sub rsp, 0xF0
000078eb87dd091f  vmovaps [rsp], xmm0
000078eb87dd0924  vmovaps [rsp+0x10], xmm1
000078eb87dd092a  vmovaps [rsp+0x20], xmm2
000078eb87dd0930  vmovaps [rsp+0x30], xmm3
000078eb87dd0936  vmovaps [rsp+0x40], xmm4
000078eb87dd093c  vmovaps [rsp+0x50], xmm5
000078eb87dd0942  vmovaps [rsp+0x60], xmm6
000078eb87dd0948  vmovaps [rsp+0x70], xmm7
000078eb87dd094e  vmovaps [rsp+0x80], xmm8
000078eb87dd0957  vmovaps [rsp+0x90], xmm9
000078eb87dd0960  vmovaps [rsp+0xA0], xmm10
000078eb87dd0969  vmovaps [rsp+0xB0], xmm11
000078eb87dd0972  vmovaps [rsp+0xC0], xmm12
000078eb87dd097b  vmovaps [rsp+0xD0], xmm13
000078eb87dd0984  vmovaps [rsp+0xE0], xmm14
000078eb87dd098d  sub rsp, 0x30
000078eb87dd0991  movaps [rsp], xmm15
000078eb87dd0996  movaps [rsp+0x10], xmm14
000078eb87dd099c  movaps [rsp+0x20], xmm1
000078eb87dd09a1  lea rdi, [rsp]
000078eb87dd09a5  mov esi, 0x00
000078eb87dd09aa  mov rax, 0x61D341A71530
000078eb87dd09b4  call rax
000078eb87dd09b6  movaps xmm15, [rsp]
000078eb87dd09bb  add rsp, 0x30
000078eb87dd09bf  vmovaps xmm0, [rsp]
000078eb87dd09c4  vmovaps xmm1, [rsp+0x10]
000078eb87dd09ca  vmovaps xmm2, [rsp+0x20]
000078eb87dd09d0  vmovaps xmm3, [rsp+0x30]
000078eb87dd09d6  vmovaps xmm4, [rsp+0x40]
000078eb87dd09dc  vmovaps xmm5, [rsp+0x50]
000078eb87dd09e2  vmovaps xmm6, [rsp+0x60]
000078eb87dd09e8  vmovaps xmm7, [rsp+0x70]
000078eb87dd09ee  vmovaps xmm8, [rsp+0x80]
000078eb87dd09f7  vmovaps xmm9, [rsp+0x90]
000078eb87dd0a00  vmovaps xmm10, [rsp+0xA0]
000078eb87dd0a09  vmovaps xmm11, [rsp+0xB0]
000078eb87dd0a12  vmovaps xmm12, [rsp+0xC0]
000078eb87dd0a1b  vmovaps xmm13, [rsp+0xD0]
000078eb87dd0a24  vmovaps xmm14, [rsp+0xE0]
000078eb87dd0a2d  add rsp, 0xF0
000078eb87dd0a34  pop r11
000078eb87dd0a36  pop r10
000078eb87dd0a38  pop r9
000078eb87dd0a3a  pop r8
000078eb87dd0a3c  pop rsi
000078eb87dd0a3d  pop rdi
000078eb87dd0a3e  pop rdx
000078eb87dd0a3f  pop rcx
000078eb87dd0a40  pop rax
000078eb87dd0a41  add rsp, 0x08
000078eb87dd0a45  jmp 0x000078EB87DCF617
000078eb87dd0a4a  sub rsp, 0x08
000078eb87dd0a4e  push rax
000078eb87dd0a4f  push rcx
000078eb87dd0a50  push rdx
000078eb87dd0a51  push rdi
000078eb87dd0a52  push rsi
000078eb87dd0a53  push r8
000078eb87dd0a55  push r9
000078eb87dd0a57  push r10
000078eb87dd0a59  push r11
000078eb87dd0a5b  sub rsp, 0xF0
000078eb87dd0a62  vmovaps [rsp], xmm0
000078eb87dd0a67  vmovaps [rsp+0x10], xmm2
000078eb87dd0a6d  vmovaps [rsp+0x20], xmm3
000078eb87dd0a73  vmovaps [rsp+0x30], xmm4
000078eb87dd0a79  vmovaps [rsp+0x40], xmm5
000078eb87dd0a7f  vmovaps [rsp+0x50], xmm6
000078eb87dd0a85  vmovaps [rsp+0x60], xmm7
000078eb87dd0a8b  vmovaps [rsp+0x70], xmm8
000078eb87dd0a91  vmovaps [rsp+0x80], xmm9
000078eb87dd0a9a  vmovaps [rsp+0x90], xmm10
000078eb87dd0aa3  vmovaps [rsp+0xA0], xmm11
000078eb87dd0aac  vmovaps [rsp+0xB0], xmm12
000078eb87dd0ab5  vmovaps [rsp+0xC0], xmm13
000078eb87dd0abe  vmovaps [rsp+0xD0], xmm14
000078eb87dd0ac7  vmovaps [rsp+0xE0], xmm15
000078eb87dd0ad0  sub rsp, 0x30
000078eb87dd0ad4  movaps [rsp], xmm1
000078eb87dd0ad8  movaps [rsp+0x10], xmm14
000078eb87dd0ade  movaps [rsp+0x20], xmm10
000078eb87dd0ae4  lea rdi, [rsp]
000078eb87dd0ae8  mov esi, 0x00
000078eb87dd0aed  mov rax, 0x61D341A71530
000078eb87dd0af7  call rax
000078eb87dd0af9  movaps xmm1, [rsp]
000078eb87dd0afd  add rsp, 0x30
000078eb87dd0b01  vmovaps xmm0, [rsp]
000078eb87dd0b06  vmovaps xmm2, [rsp+0x10]
000078eb87dd0b0c  vmovaps xmm3, [rsp+0x20]
000078eb87dd0b12  vmovaps xmm4, [rsp+0x30]
000078eb87dd0b18  vmovaps xmm5, [rsp+0x40]
000078eb87dd0b1e  vmovaps xmm6, [rsp+0x50]
000078eb87dd0b24  vmovaps xmm7, [rsp+0x60]
000078eb87dd0b2a  vmovaps xmm8, [rsp+0x70]
000078eb87dd0b30  vmovaps xmm9, [rsp+0x80]
000078eb87dd0b39  vmovaps xmm10, [rsp+0x90]
000078eb87dd0b42  vmovaps xmm11, [rsp+0xA0]
000078eb87dd0b4b  vmovaps xmm12, [rsp+0xB0]
000078eb87dd0b54  vmovaps xmm13, [rsp+0xC0]
000078eb87dd0b5d  vmovaps xmm14, [rsp+0xD0]
000078eb87dd0b66  vmovaps xmm15, [rsp+0xE0]
000078eb87dd0b6f  add rsp, 0xF0
000078eb87dd0b76  pop r11
000078eb87dd0b78  pop r10
000078eb87dd0b7a  pop r9
000078eb87dd0b7c  pop r8
000078eb87dd0b7e  pop rsi
000078eb87dd0b7f  pop rdi
000078eb87dd0b80  pop rdx
000078eb87dd0b81  pop rcx
000078eb87dd0b82  pop rax
000078eb87dd0b83  add rsp, 0x08
000078eb87dd0b87  jmp 0x000078EB87DCF631
000078eb87dd0b8c  sub rsp, 0x08
000078eb87dd0b90  push rax
000078eb87dd0b91  push rcx
000078eb87dd0b92  push rdx
000078eb87dd0b93  push rdi
000078eb87dd0b94  push rsi
000078eb87dd0b95  push r8
000078eb87dd0b97  push r9
000078eb87dd0b99  push r10
000078eb87dd0b9b  push r11
000078eb87dd0b9d  sub rsp, 0xF0
000078eb87dd0ba4  vmovaps [rsp], xmm0
000078eb87dd0ba9  vmovaps [rsp+0x10], xmm1
000078eb87dd0baf  vmovaps [rsp+0x20], xmm2
000078eb87dd0bb5  vmovaps [rsp+0x30], xmm3
000078eb87dd0bbb  vmovaps [rsp+0x40], xmm4
000078eb87dd0bc1  vmovaps [rsp+0x50], xmm5
000078eb87dd0bc7  vmovaps [rsp+0x60], xmm6
000078eb87dd0bcd  vmovaps [rsp+0x70], xmm7
000078eb87dd0bd3  vmovaps [rsp+0x80], xmm8
000078eb87dd0bdc  vmovaps [rsp+0x90], xmm9
000078eb87dd0be5  vmovaps [rsp+0xA0], xmm10
000078eb87dd0bee  vmovaps [rsp+0xB0], xmm11
000078eb87dd0bf7  vmovaps [rsp+0xC0], xmm12
000078eb87dd0c00  vmovaps [rsp+0xD0], xmm14
000078eb87dd0c09  vmovaps [rsp+0xE0], xmm15
000078eb87dd0c12  sub rsp, 0x30
000078eb87dd0c16  movaps [rsp], xmm13
000078eb87dd0c1b  movaps [rsp+0x10], xmm14
000078eb87dd0c21  movaps [rsp+0x20], xmm2
000078eb87dd0c26  lea rdi, [rsp]
000078eb87dd0c2a  mov esi, 0x00
000078eb87dd0c2f  mov rax, 0x61D341A71530
000078eb87dd0c39  call rax
000078eb87dd0c3b  movaps xmm13, [rsp]
000078eb87dd0c40  add rsp, 0x30
000078eb87dd0c44  vmovaps xmm0, [rsp]
000078eb87dd0c49  vmovaps xmm1, [rsp+0x10]
000078eb87dd0c4f  vmovaps xmm2, [rsp+0x20]
000078eb87dd0c55  vmovaps xmm3, [rsp+0x30]
000078eb87dd0c5b  vmovaps xmm4, [rsp+0x40]
000078eb87dd0c61  vmovaps xmm5, [rsp+0x50]
000078eb87dd0c67  vmovaps xmm6, [rsp+0x60]
000078eb87dd0c6d  vmovaps xmm7, [rsp+0x70]
000078eb87dd0c73  vmovaps xmm8, [rsp+0x80]
000078eb87dd0c7c  vmovaps xmm9, [rsp+0x90]
000078eb87dd0c85  vmovaps xmm10, [rsp+0xA0]
000078eb87dd0c8e  vmovaps xmm11, [rsp+0xB0]
000078eb87dd0c97  vmovaps xmm12, [rsp+0xC0]
000078eb87dd0ca0  vmovaps xmm14, [rsp+0xD0]
000078eb87dd0ca9  vmovaps xmm15, [rsp+0xE0]
000078eb87dd0cb2  add rsp, 0xF0
000078eb87dd0cb9  pop r11
000078eb87dd0cbb  pop r10
000078eb87dd0cbd  pop r9
000078eb87dd0cbf  pop r8
000078eb87dd0cc1  pop rsi
000078eb87dd0cc2  pop rdi
000078eb87dd0cc3  pop rdx
000078eb87dd0cc4  pop rcx
000078eb87dd0cc5  pop rax
000078eb87dd0cc6  add rsp, 0x08
000078eb87dd0cca  jmp 0x000078EB87DCF64C
000078eb87dd0ccf  sub rsp, 0x08
000078eb87dd0cd3  push rax
000078eb87dd0cd4  push rcx
000078eb87dd0cd5  push rdx
000078eb87dd0cd6  push rdi
000078eb87dd0cd7  push rsi
000078eb87dd0cd8  push r8
000078eb87dd0cda  push r9
000078eb87dd0cdc  push r10
000078eb87dd0cde  push r11
000078eb87dd0ce0  sub rsp, 0xF0
000078eb87dd0ce7  vmovaps [rsp], xmm0
000078eb87dd0cec  vmovaps [rsp+0x10], xmm2
000078eb87dd0cf2  vmovaps [rsp+0x20], xmm3
000078eb87dd0cf8  vmovaps [rsp+0x30], xmm4
000078eb87dd0cfe  vmovaps [rsp+0x40], xmm5
000078eb87dd0d04  vmovaps [rsp+0x50], xmm6
000078eb87dd0d0a  vmovaps [rsp+0x60], xmm7
000078eb87dd0d10  vmovaps [rsp+0x70], xmm8
000078eb87dd0d16  vmovaps [rsp+0x80], xmm9
000078eb87dd0d1f  vmovaps [rsp+0x90], xmm10
000078eb87dd0d28  vmovaps [rsp+0xA0], xmm11
000078eb87dd0d31  vmovaps [rsp+0xB0], xmm12
000078eb87dd0d3a  vmovaps [rsp+0xC0], xmm13
000078eb87dd0d43  vmovaps [rsp+0xD0], xmm14
000078eb87dd0d4c  vmovaps [rsp+0xE0], xmm15
000078eb87dd0d55  sub rsp, 0x30
000078eb87dd0d59  movaps [rsp], xmm1
000078eb87dd0d5d  movaps [rsp+0x10], xmm10
000078eb87dd0d63  movaps [rsp+0x20], xmm2
000078eb87dd0d68  lea rdi, [rsp]
000078eb87dd0d6c  mov esi, 0x00
000078eb87dd0d71  mov rax, 0x61D341A71530
000078eb87dd0d7b  call rax
000078eb87dd0d7d  movaps xmm1, [rsp]
000078eb87dd0d81  add rsp, 0x30
000078eb87dd0d85  vmovaps xmm0, [rsp]
000078eb87dd0d8a  vmovaps xmm2, [rsp+0x10]
000078eb87dd0d90  vmovaps xmm3, [rsp+0x20]
000078eb87dd0d96  vmovaps xmm4, [rsp+0x30]
000078eb87dd0d9c  vmovaps xmm5, [rsp+0x40]
000078eb87dd0da2  vmovaps xmm6, [rsp+0x50]
000078eb87dd0da8  vmovaps xmm7, [rsp+0x60]
000078eb87dd0dae  vmovaps xmm8, [rsp+0x70]
000078eb87dd0db4  vmovaps xmm9, [rsp+0x80]
000078eb87dd0dbd  vmovaps xmm10, [rsp+0x90]
000078eb87dd0dc6  vmovaps xmm11, [rsp+0xA0]
000078eb87dd0dcf  vmovaps xmm12, [rsp+0xB0]
000078eb87dd0dd8  vmovaps xmm13, [rsp+0xC0]
000078eb87dd0de1  vmovaps xmm14, [rsp+0xD0]
000078eb87dd0dea  vmovaps xmm15, [rsp+0xE0]
000078eb87dd0df3  add rsp, 0xF0
000078eb87dd0dfa  pop r11
000078eb87dd0dfc  pop r10
000078eb87dd0dfe  pop r9
000078eb87dd0e00  pop r8
000078eb87dd0e02  pop rsi
000078eb87dd0e03  pop rdi
000078eb87dd0e04  pop rdx
000078eb87dd0e05  pop rcx
000078eb87dd0e06  pop rax
000078eb87dd0e07  add rsp, 0x08
000078eb87dd0e0b  jmp 0x000078EB87DCF6B4
000078eb87dd0e10  sub rsp, 0x08
000078eb87dd0e14  push rax
000078eb87dd0e15  push rcx
000078eb87dd0e16  push rdx
000078eb87dd0e17  push rdi
000078eb87dd0e18  push rsi
000078eb87dd0e19  push r8
000078eb87dd0e1b  push r9
000078eb87dd0e1d  push r10
000078eb87dd0e1f  push r11
000078eb87dd0e21  sub rsp, 0xF0
000078eb87dd0e28  vmovaps [rsp], xmm0
000078eb87dd0e2d  vmovaps [rsp+0x10], xmm1
000078eb87dd0e33  vmovaps [rsp+0x20], xmm2
000078eb87dd0e39  vmovaps [rsp+0x30], xmm3
000078eb87dd0e3f  vmovaps [rsp+0x40], xmm4
000078eb87dd0e45  vmovaps [rsp+0x50], xmm5
000078eb87dd0e4b  vmovaps [rsp+0x60], xmm6
000078eb87dd0e51  vmovaps [rsp+0x70], xmm7
000078eb87dd0e57  vmovaps [rsp+0x80], xmm8
000078eb87dd0e60  vmovaps [rsp+0x90], xmm9
000078eb87dd0e69  vmovaps [rsp+0xA0], xmm10
000078eb87dd0e72  vmovaps [rsp+0xB0], xmm11
000078eb87dd0e7b  vmovaps [rsp+0xC0], xmm12
000078eb87dd0e84  vmovaps [rsp+0xD0], xmm13
000078eb87dd0e8d  vmovaps [rsp+0xE0], xmm14
000078eb87dd0e96  sub rsp, 0x30
000078eb87dd0e9a  movaps [rsp], xmm15
000078eb87dd0e9f  movaps [rsp+0x10], xmm10
000078eb87dd0ea5  movaps [rsp+0x20], xmm2
000078eb87dd0eaa  lea rdi, [rsp]
000078eb87dd0eae  mov esi, 0x00
000078eb87dd0eb3  mov rax, 0x61D341A71530
000078eb87dd0ebd  call rax
000078eb87dd0ebf  movaps xmm15, [rsp]
000078eb87dd0ec4  add rsp, 0x30
000078eb87dd0ec8  vmovaps xmm0, [rsp]
000078eb87dd0ecd  vmovaps xmm1, [rsp+0x10]
000078eb87dd0ed3  vmovaps xmm2, [rsp+0x20]
000078eb87dd0ed9  vmovaps xmm3, [rsp+0x30]
000078eb87dd0edf  vmovaps xmm4, [rsp+0x40]
000078eb87dd0ee5  vmovaps xmm5, [rsp+0x50]
000078eb87dd0eeb  vmovaps xmm6, [rsp+0x60]
000078eb87dd0ef1  vmovaps xmm7, [rsp+0x70]
000078eb87dd0ef7  vmovaps xmm8, [rsp+0x80]
000078eb87dd0f00  vmovaps xmm9, [rsp+0x90]
000078eb87dd0f09  vmovaps xmm10, [rsp+0xA0]
000078eb87dd0f12  vmovaps xmm11, [rsp+0xB0]
000078eb87dd0f1b  vmovaps xmm12, [rsp+0xC0]
000078eb87dd0f24  vmovaps xmm13, [rsp+0xD0]
000078eb87dd0f2d  vmovaps xmm14, [rsp+0xE0]
000078eb87dd0f36  add rsp, 0xF0
000078eb87dd0f3d  pop r11
000078eb87dd0f3f  pop r10
000078eb87dd0f41  pop r9
000078eb87dd0f43  pop r8
000078eb87dd0f45  pop rsi
000078eb87dd0f46  pop rdi
000078eb87dd0f47  pop rdx
000078eb87dd0f48  pop rcx
000078eb87dd0f49  pop rax
000078eb87dd0f4a  add rsp, 0x08
000078eb87dd0f4e  jmp 0x000078EB87DCF706
000078eb87dd0f53  sub rsp, 0x08
000078eb87dd0f57  push rax
000078eb87dd0f58  push rcx
000078eb87dd0f59  push rdx
000078eb87dd0f5a  push rdi
000078eb87dd0f5b  push rsi
000078eb87dd0f5c  push r8
000078eb87dd0f5e  push r9
000078eb87dd0f60  push r10
000078eb87dd0f62  push r11
000078eb87dd0f64  sub rsp, 0xF0
000078eb87dd0f6b  vmovaps [rsp], xmm0
000078eb87dd0f70  vmovaps [rsp+0x10], xmm2
000078eb87dd0f76  vmovaps [rsp+0x20], xmm3
000078eb87dd0f7c  vmovaps [rsp+0x30], xmm4
000078eb87dd0f82  vmovaps [rsp+0x40], xmm5
000078eb87dd0f88  vmovaps [rsp+0x50], xmm6
000078eb87dd0f8e  vmovaps [rsp+0x60], xmm7
000078eb87dd0f94  vmovaps [rsp+0x70], xmm8
000078eb87dd0f9a  vmovaps [rsp+0x80], xmm9
000078eb87dd0fa3  vmovaps [rsp+0x90], xmm10
000078eb87dd0fac  vmovaps [rsp+0xA0], xmm11
000078eb87dd0fb5  vmovaps [rsp+0xB0], xmm12
000078eb87dd0fbe  vmovaps [rsp+0xC0], xmm13
000078eb87dd0fc7  vmovaps [rsp+0xD0], xmm14
000078eb87dd0fd0  vmovaps [rsp+0xE0], xmm15
000078eb87dd0fd9  sub rsp, 0x30
000078eb87dd0fdd  movaps [rsp], xmm1
000078eb87dd0fe1  movaps [rsp+0x10], xmm10
000078eb87dd0fe7  movaps [rsp+0x20], xmm12
000078eb87dd0fed  lea rdi, [rsp]
000078eb87dd0ff1  mov esi, 0x00
000078eb87dd0ff6  mov rax, 0x61D341A71530
000078eb87dd1000  call rax
000078eb87dd1002  movaps xmm1, [rsp]
000078eb87dd1006  add rsp, 0x30
000078eb87dd100a  vmovaps xmm0, [rsp]
000078eb87dd100f  vmovaps xmm2, [rsp+0x10]
000078eb87dd1015  vmovaps xmm3, [rsp+0x20]
000078eb87dd101b  vmovaps xmm4, [rsp+0x30]
000078eb87dd1021  vmovaps xmm5, [rsp+0x40]
000078eb87dd1027  vmovaps xmm6, [rsp+0x50]
000078eb87dd102d  vmovaps xmm7, [rsp+0x60]
000078eb87dd1033  vmovaps xmm8, [rsp+0x70]
000078eb87dd1039  vmovaps xmm9, [rsp+0x80]
000078eb87dd1042  vmovaps xmm10, [rsp+0x90]
000078eb87dd104b  vmovaps xmm11, [rsp+0xA0]
000078eb87dd1054  vmovaps xmm12, [rsp+0xB0]
000078eb87dd105d  vmovaps xmm13, [rsp+0xC0]
000078eb87dd1066  vmovaps xmm14, [rsp+0xD0]
000078eb87dd106f  vmovaps xmm15, [rsp+0xE0]
000078eb87dd1078  add rsp, 0xF0
000078eb87dd107f  pop r11
000078eb87dd1081  pop r10
000078eb87dd1083  pop r9
000078eb87dd1085  pop r8
000078eb87dd1087  pop rsi
000078eb87dd1088  pop rdi
000078eb87dd1089  pop rdx
000078eb87dd108a  pop rcx
000078eb87dd108b  pop rax
000078eb87dd108c  add rsp, 0x08
000078eb87dd1090  jmp 0x000078EB87DCF732
000078eb87dd1095  sub rsp, 0x08
000078eb87dd1099  push rax
000078eb87dd109a  push rcx
000078eb87dd109b  push rdx
000078eb87dd109c  push rdi
000078eb87dd109d  push rsi
000078eb87dd109e  push r8
000078eb87dd10a0  push r9
000078eb87dd10a2  push r10
000078eb87dd10a4  push r11
000078eb87dd10a6  sub rsp, 0xF0
000078eb87dd10ad  vmovaps [rsp], xmm0
000078eb87dd10b2  vmovaps [rsp+0x10], xmm1
000078eb87dd10b8  vmovaps [rsp+0x20], xmm2
000078eb87dd10be  vmovaps [rsp+0x30], xmm3
000078eb87dd10c4  vmovaps [rsp+0x40], xmm4
000078eb87dd10ca  vmovaps [rsp+0x50], xmm5
000078eb87dd10d0  vmovaps [rsp+0x60], xmm6
000078eb87dd10d6  vmovaps [rsp+0x70], xmm7
000078eb87dd10dc  vmovaps [rsp+0x80], xmm8
000078eb87dd10e5  vmovaps [rsp+0x90], xmm9
000078eb87dd10ee  vmovaps [rsp+0xA0], xmm10
000078eb87dd10f7  vmovaps [rsp+0xB0], xmm11
000078eb87dd1100  vmovaps [rsp+0xC0], xmm12
000078eb87dd1109  vmovaps [rsp+0xD0], xmm13
000078eb87dd1112  vmovaps [rsp+0xE0], xmm14
000078eb87dd111b  sub rsp, 0x30
000078eb87dd111f  movaps [rsp], xmm15
000078eb87dd1124  movaps [rsp+0x10], xmm10
000078eb87dd112a  movaps [rsp+0x20], xmm12
000078eb87dd1130  lea rdi, [rsp]
000078eb87dd1134  mov esi, 0x00
000078eb87dd1139  mov rax, 0x61D341A71530
000078eb87dd1143  call rax
000078eb87dd1145  movaps xmm15, [rsp]
000078eb87dd114a  add rsp, 0x30
000078eb87dd114e  vmovaps xmm0, [rsp]
000078eb87dd1153  vmovaps xmm1, [rsp+0x10]
000078eb87dd1159  vmovaps xmm2, [rsp+0x20]
000078eb87dd115f  vmovaps xmm3, [rsp+0x30]
000078eb87dd1165  vmovaps xmm4, [rsp+0x40]
000078eb87dd116b  vmovaps xmm5, [rsp+0x50]
000078eb87dd1171  vmovaps xmm6, [rsp+0x60]
000078eb87dd1177  vmovaps xmm7, [rsp+0x70]
000078eb87dd117d  vmovaps xmm8, [rsp+0x80]
000078eb87dd1186  vmovaps xmm9, [rsp+0x90]
000078eb87dd118f  vmovaps xmm10, [rsp+0xA0]
000078eb87dd1198  vmovaps xmm11, [rsp+0xB0]
000078eb87dd11a1  vmovaps xmm12, [rsp+0xC0]
000078eb87dd11aa  vmovaps xmm13, [rsp+0xD0]
000078eb87dd11b3  vmovaps xmm14, [rsp+0xE0]
000078eb87dd11bc  add rsp, 0xF0
000078eb87dd11c3  pop r11
000078eb87dd11c5  pop r10
000078eb87dd11c7  pop r9
000078eb87dd11c9  pop r8
000078eb87dd11cb  pop rsi
000078eb87dd11cc  pop rdi
000078eb87dd11cd  pop rdx
000078eb87dd11ce  pop rcx
000078eb87dd11cf  pop rax
000078eb87dd11d0  add rsp, 0x08
000078eb87dd11d4  jmp 0x000078EB87DCF75E
000078eb87dd11d9  call 0x000078EB87BFF430
000078eb87dd11de  jmp 0x000078EB87DCF7EE
000078eb87dd11e3  call 0x000078EB87BFF430
000078eb87dd11e8  jmp 0x000078EB87DCF801
000078eb87dd11ed  sub rsp, 0x08
000078eb87dd11f1  push rax
000078eb87dd11f2  push rcx
000078eb87dd11f3  push rdx
000078eb87dd11f4  push rdi
000078eb87dd11f5  push rsi
000078eb87dd11f6  push r8
000078eb87dd11f8  push r9
000078eb87dd11fa  push r10
000078eb87dd11fc  push r11
000078eb87dd11fe  sub rsp, 0xF0
000078eb87dd1205  vmovaps [rsp], xmm0
000078eb87dd120a  vmovaps [rsp+0x10], xmm2
000078eb87dd1210  vmovaps [rsp+0x20], xmm3
000078eb87dd1216  vmovaps [rsp+0x30], xmm4
000078eb87dd121c  vmovaps [rsp+0x40], xmm5
000078eb87dd1222  vmovaps [rsp+0x50], xmm6
000078eb87dd1228  vmovaps [rsp+0x60], xmm7
000078eb87dd122e  vmovaps [rsp+0x70], xmm8
000078eb87dd1234  vmovaps [rsp+0x80], xmm9
000078eb87dd123d  vmovaps [rsp+0x90], xmm10
000078eb87dd1246  vmovaps [rsp+0xA0], xmm11
000078eb87dd124f  vmovaps [rsp+0xB0], xmm12
000078eb87dd1258  vmovaps [rsp+0xC0], xmm13
000078eb87dd1261  vmovaps [rsp+0xD0], xmm14
000078eb87dd126a  vmovaps [rsp+0xE0], xmm15
000078eb87dd1273  sub rsp, 0x30
000078eb87dd1277  movaps [rsp], xmm1
000078eb87dd127b  movaps [rsp+0x10], xmm13
000078eb87dd1281  movaps [rsp+0x20], xmm2
000078eb87dd1286  lea rdi, [rsp]
000078eb87dd128a  mov esi, 0x00
000078eb87dd128f  mov rax, 0x61D341A71530
000078eb87dd1299  call rax
000078eb87dd129b  movaps xmm1, [rsp]
000078eb87dd129f  add rsp, 0x30
000078eb87dd12a3  vmovaps xmm0, [rsp]
000078eb87dd12a8  vmovaps xmm2, [rsp+0x10]
000078eb87dd12ae  vmovaps xmm3, [rsp+0x20]
000078eb87dd12b4  vmovaps xmm4, [rsp+0x30]
000078eb87dd12ba  vmovaps xmm5, [rsp+0x40]
000078eb87dd12c0  vmovaps xmm6, [rsp+0x50]
000078eb87dd12c6  vmovaps xmm7, [rsp+0x60]
000078eb87dd12cc  vmovaps xmm8, [rsp+0x70]
000078eb87dd12d2  vmovaps xmm9, [rsp+0x80]
000078eb87dd12db  vmovaps xmm10, [rsp+0x90]
000078eb87dd12e4  vmovaps xmm11, [rsp+0xA0]
000078eb87dd12ed  vmovaps xmm12, [rsp+0xB0]
000078eb87dd12f6  vmovaps xmm13, [rsp+0xC0]
000078eb87dd12ff  vmovaps xmm14, [rsp+0xD0]
000078eb87dd1308  vmovaps xmm15, [rsp+0xE0]
000078eb87dd1311  add rsp, 0xF0
000078eb87dd1318  pop r11
000078eb87dd131a  pop r10
000078eb87dd131c  pop r9
000078eb87dd131e  pop r8
000078eb87dd1320  pop rsi
000078eb87dd1321  pop rdi
000078eb87dd1322  pop rdx
000078eb87dd1323  pop rcx
000078eb87dd1324  pop rax
000078eb87dd1325  add rsp, 0x08
000078eb87dd1329  jmp 0x000078EB87DCF82C
000078eb87dd132e  call 0x000078EB87C0E760
000078eb87dd1333  jmp 0x000078EB87DCF839
000078eb87dd1338  sub rsp, 0x08
000078eb87dd133c  push rax
000078eb87dd133d  push rcx
000078eb87dd133e  push rdx
000078eb87dd133f  push rdi
000078eb87dd1340  push rsi
000078eb87dd1341  push r8
000078eb87dd1343  push r9
000078eb87dd1345  push r10
000078eb87dd1347  push r11
000078eb87dd1349  sub rsp, 0xF0
000078eb87dd1350  vmovaps [rsp], xmm0
000078eb87dd1355  vmovaps [rsp+0x10], xmm1
000078eb87dd135b  vmovaps [rsp+0x20], xmm2
000078eb87dd1361  vmovaps [rsp+0x30], xmm3
000078eb87dd1367  vmovaps [rsp+0x40], xmm4
000078eb87dd136d  vmovaps [rsp+0x50], xmm5
000078eb87dd1373  vmovaps [rsp+0x60], xmm6
000078eb87dd1379  vmovaps [rsp+0x70], xmm7
000078eb87dd137f  vmovaps [rsp+0x80], xmm8
000078eb87dd1388  vmovaps [rsp+0x90], xmm9
000078eb87dd1391  vmovaps [rsp+0xA0], xmm10
000078eb87dd139a  vmovaps [rsp+0xB0], xmm11
000078eb87dd13a3  vmovaps [rsp+0xC0], xmm12
000078eb87dd13ac  vmovaps [rsp+0xD0], xmm14
000078eb87dd13b5  vmovaps [rsp+0xE0], xmm15
000078eb87dd13be  sub rsp, 0x30
000078eb87dd13c2  movaps [rsp], xmm13
000078eb87dd13c7  movaps [rsp+0x10], xmm2
000078eb87dd13cc  movaps [rsp+0x20], xmm1
000078eb87dd13d1  lea rdi, [rsp]
000078eb87dd13d5  mov esi, 0x00
000078eb87dd13da  mov rax, 0x61D341A71530
000078eb87dd13e4  call rax
000078eb87dd13e6  movaps xmm13, [rsp]
000078eb87dd13eb  add rsp, 0x30
000078eb87dd13ef  vmovaps xmm0, [rsp]
000078eb87dd13f4  vmovaps xmm1, [rsp+0x10]
000078eb87dd13fa  vmovaps xmm2, [rsp+0x20]
000078eb87dd1400  vmovaps xmm3, [rsp+0x30]
000078eb87dd1406  vmovaps xmm4, [rsp+0x40]
000078eb87dd140c  vmovaps xmm5, [rsp+0x50]
000078eb87dd1412  vmovaps xmm6, [rsp+0x60]
000078eb87dd1418  vmovaps xmm7, [rsp+0x70]
000078eb87dd141e  vmovaps xmm8, [rsp+0x80]
000078eb87dd1427  vmovaps xmm9, [rsp+0x90]
000078eb87dd1430  vmovaps xmm10, [rsp+0xA0]
000078eb87dd1439  vmovaps xmm11, [rsp+0xB0]
000078eb87dd1442  vmovaps xmm12, [rsp+0xC0]
000078eb87dd144b  vmovaps xmm14, [rsp+0xD0]
000078eb87dd1454  vmovaps xmm15, [rsp+0xE0]
000078eb87dd145d  add rsp, 0xF0
000078eb87dd1464  pop r11
000078eb87dd1466  pop r10
000078eb87dd1468  pop r9
000078eb87dd146a  pop r8
000078eb87dd146c  pop rsi
000078eb87dd146d  pop rdi
000078eb87dd146e  pop rdx
000078eb87dd146f  pop rcx
000078eb87dd1470  pop rax
000078eb87dd1471  add rsp, 0x08
000078eb87dd1475  jmp 0x000078EB87DCF878
000078eb87dd147a  sub rsp, 0x08
000078eb87dd147e  push rax
000078eb87dd147f  push rcx
000078eb87dd1480  push rdx
000078eb87dd1481  push rdi
000078eb87dd1482  push rsi
000078eb87dd1483  push r8
000078eb87dd1485  push r9
000078eb87dd1487  push r10
000078eb87dd1489  push r11
000078eb87dd148b  sub rsp, 0xF0
000078eb87dd1492  vmovaps [rsp], xmm0
000078eb87dd1497  vmovaps [rsp+0x10], xmm2
000078eb87dd149d  vmovaps [rsp+0x20], xmm3
000078eb87dd14a3  vmovaps [rsp+0x30], xmm4
000078eb87dd14a9  vmovaps [rsp+0x40], xmm5
000078eb87dd14af  vmovaps [rsp+0x50], xmm6
000078eb87dd14b5  vmovaps [rsp+0x60], xmm7
000078eb87dd14bb  vmovaps [rsp+0x70], xmm8
000078eb87dd14c1  vmovaps [rsp+0x80], xmm9
000078eb87dd14ca  vmovaps [rsp+0x90], xmm10
000078eb87dd14d3  vmovaps [rsp+0xA0], xmm11
000078eb87dd14dc  vmovaps [rsp+0xB0], xmm12
000078eb87dd14e5  vmovaps [rsp+0xC0], xmm13
000078eb87dd14ee  vmovaps [rsp+0xD0], xmm14
000078eb87dd14f7  vmovaps [rsp+0xE0], xmm15
000078eb87dd1500  sub rsp, 0x30
000078eb87dd1504  movaps [rsp], xmm1
000078eb87dd1508  movaps [rsp+0x10], xmm15
000078eb87dd150e  movaps [rsp+0x20], xmm2
000078eb87dd1513  lea rdi, [rsp]
000078eb87dd1517  mov esi, 0x00
000078eb87dd151c  mov rax, 0x61D341A71530
000078eb87dd1526  call rax
000078eb87dd1528  movaps xmm1, [rsp]
000078eb87dd152c  add rsp, 0x30
000078eb87dd1530  vmovaps xmm0, [rsp]
000078eb87dd1535  vmovaps xmm2, [rsp+0x10]
000078eb87dd153b  vmovaps xmm3, [rsp+0x20]
000078eb87dd1541  vmovaps xmm4, [rsp+0x30]
000078eb87dd1547  vmovaps xmm5, [rsp+0x40]
000078eb87dd154d  vmovaps xmm6, [rsp+0x50]
000078eb87dd1553  vmovaps xmm7, [rsp+0x60]
000078eb87dd1559  vmovaps xmm8, [rsp+0x70]
000078eb87dd155f  vmovaps xmm9, [rsp+0x80]
000078eb87dd1568  vmovaps xmm10, [rsp+0x90]
000078eb87dd1571  vmovaps xmm11, [rsp+0xA0]
000078eb87dd157a  vmovaps xmm12, [rsp+0xB0]
000078eb87dd1583  vmovaps xmm13, [rsp+0xC0]
000078eb87dd158c  vmovaps xmm14, [rsp+0xD0]
000078eb87dd1595  vmovaps xmm15, [rsp+0xE0]
000078eb87dd159e  add rsp, 0xF0
000078eb87dd15a5  pop r11
000078eb87dd15a7  pop r10
000078eb87dd15a9  pop r9
000078eb87dd15ab  pop r8
000078eb87dd15ad  pop rsi
000078eb87dd15ae  pop rdi
000078eb87dd15af  pop rdx
000078eb87dd15b0  pop rcx
000078eb87dd15b1  pop rax
000078eb87dd15b2  add rsp, 0x08
000078eb87dd15b6  jmp 0x000078EB87DCF8AC
000078eb87dd15bb  sub rsp, 0x08
000078eb87dd15bf  push rax
000078eb87dd15c0  push rcx
000078eb87dd15c1  push rdx
000078eb87dd15c2  push rdi
000078eb87dd15c3  push rsi
000078eb87dd15c4  push r8
000078eb87dd15c6  push r9
000078eb87dd15c8  push r10
000078eb87dd15ca  push r11
000078eb87dd15cc  sub rsp, 0xF0
000078eb87dd15d3  vmovaps [rsp], xmm0
000078eb87dd15d8  vmovaps [rsp+0x10], xmm1
000078eb87dd15de  vmovaps [rsp+0x20], xmm2
000078eb87dd15e4  vmovaps [rsp+0x30], xmm3
000078eb87dd15ea  vmovaps [rsp+0x40], xmm4
000078eb87dd15f0  vmovaps [rsp+0x50], xmm5
000078eb87dd15f6  vmovaps [rsp+0x60], xmm6
000078eb87dd15fc  vmovaps [rsp+0x70], xmm7
000078eb87dd1602  vmovaps [rsp+0x80], xmm8
000078eb87dd160b  vmovaps [rsp+0x90], xmm9
000078eb87dd1614  vmovaps [rsp+0xA0], xmm10
000078eb87dd161d  vmovaps [rsp+0xB0], xmm11
000078eb87dd1626  vmovaps [rsp+0xC0], xmm12
000078eb87dd162f  vmovaps [rsp+0xD0], xmm13
000078eb87dd1638  vmovaps [rsp+0xE0], xmm15
000078eb87dd1641  sub rsp, 0x30
000078eb87dd1645  movaps [rsp], xmm14
000078eb87dd164a  movaps [rsp+0x10], xmm2
000078eb87dd164f  movaps [rsp+0x20], xmm15
000078eb87dd1655  lea rdi, [rsp]
000078eb87dd1659  mov esi, 0x00
000078eb87dd165e  mov rax, 0x61D341A71530
000078eb87dd1668  call rax
000078eb87dd166a  movaps xmm14, [rsp]
000078eb87dd166f  add rsp, 0x30
000078eb87dd1673  vmovaps xmm0, [rsp]
000078eb87dd1678  vmovaps xmm1, [rsp+0x10]
000078eb87dd167e  vmovaps xmm2, [rsp+0x20]
000078eb87dd1684  vmovaps xmm3, [rsp+0x30]
000078eb87dd168a  vmovaps xmm4, [rsp+0x40]
000078eb87dd1690  vmovaps xmm5, [rsp+0x50]
000078eb87dd1696  vmovaps xmm6, [rsp+0x60]
000078eb87dd169c  vmovaps xmm7, [rsp+0x70]
000078eb87dd16a2  vmovaps xmm8, [rsp+0x80]
000078eb87dd16ab  vmovaps xmm9, [rsp+0x90]
000078eb87dd16b4  vmovaps xmm10, [rsp+0xA0]
000078eb87dd16bd  vmovaps xmm11, [rsp+0xB0]
000078eb87dd16c6  vmovaps xmm12, [rsp+0xC0]
000078eb87dd16cf  vmovaps xmm13, [rsp+0xD0]
000078eb87dd16d8  vmovaps xmm15, [rsp+0xE0]
000078eb87dd16e1  add rsp, 0xF0
000078eb87dd16e8  pop r11
000078eb87dd16ea  pop r10
000078eb87dd16ec  pop r9
000078eb87dd16ee  pop r8
000078eb87dd16f0  pop rsi
000078eb87dd16f1  pop rdi
000078eb87dd16f2  pop rdx
000078eb87dd16f3  pop rcx
000078eb87dd16f4  pop rax
000078eb87dd16f5  add rsp, 0x08
000078eb87dd16f9  jmp 0x000078EB87DCF8E7
000078eb87dd16fe  sub rsp, 0x08
000078eb87dd1702  push rax
000078eb87dd1703  push rcx
000078eb87dd1704  push rdx
000078eb87dd1705  push rdi
000078eb87dd1706  push rsi
000078eb87dd1707  push r8
000078eb87dd1709  push r9
000078eb87dd170b  push r10
000078eb87dd170d  push r11
000078eb87dd170f  sub rsp, 0xF0
000078eb87dd1716  vmovaps [rsp], xmm0
000078eb87dd171b  vmovaps [rsp+0x10], xmm1
000078eb87dd1721  vmovaps [rsp+0x20], xmm2
000078eb87dd1727  vmovaps [rsp+0x30], xmm3
000078eb87dd172d  vmovaps [rsp+0x40], xmm4
000078eb87dd1733  vmovaps [rsp+0x50], xmm5
000078eb87dd1739  vmovaps [rsp+0x60], xmm6
000078eb87dd173f  vmovaps [rsp+0x70], xmm7
000078eb87dd1745  vmovaps [rsp+0x80], xmm8
000078eb87dd174e  vmovaps [rsp+0x90], xmm9
000078eb87dd1757  vmovaps [rsp+0xA0], xmm10
000078eb87dd1760  vmovaps [rsp+0xB0], xmm11
000078eb87dd1769  vmovaps [rsp+0xC0], xmm12
000078eb87dd1772  vmovaps [rsp+0xD0], xmm13
000078eb87dd177b  vmovaps [rsp+0xE0], xmm14
000078eb87dd1784  sub rsp, 0x30
000078eb87dd1788  movaps [rsp], xmm15
000078eb87dd178d  movaps [rsp+0x10], xmm2
000078eb87dd1792  movaps [rsp+0x20], xmm1
000078eb87dd1797  lea rdi, [rsp]
000078eb87dd179b  mov esi, 0x00
000078eb87dd17a0  mov rax, 0x61D341A71530
000078eb87dd17aa  call rax
000078eb87dd17ac  movaps xmm15, [rsp]
000078eb87dd17b1  add rsp, 0x30
000078eb87dd17b5  vmovaps xmm0, [rsp]
000078eb87dd17ba  vmovaps xmm1, [rsp+0x10]
000078eb87dd17c0  vmovaps xmm2, [rsp+0x20]
000078eb87dd17c6  vmovaps xmm3, [rsp+0x30]
000078eb87dd17cc  vmovaps xmm4, [rsp+0x40]
000078eb87dd17d2  vmovaps xmm5, [rsp+0x50]
000078eb87dd17d8  vmovaps xmm6, [rsp+0x60]
000078eb87dd17de  vmovaps xmm7, [rsp+0x70]
000078eb87dd17e4  vmovaps xmm8, [rsp+0x80]
000078eb87dd17ed  vmovaps xmm9, [rsp+0x90]
000078eb87dd17f6  vmovaps xmm10, [rsp+0xA0]
000078eb87dd17ff  vmovaps xmm11, [rsp+0xB0]
000078eb87dd1808  vmovaps xmm12, [rsp+0xC0]
000078eb87dd1811  vmovaps xmm13, [rsp+0xD0]
000078eb87dd181a  vmovaps xmm14, [rsp+0xE0]
000078eb87dd1823  add rsp, 0xF0
000078eb87dd182a  pop r11
000078eb87dd182c  pop r10
000078eb87dd182e  pop r9
000078eb87dd1830  pop r8
000078eb87dd1832  pop rsi
000078eb87dd1833  pop rdi
000078eb87dd1834  pop rdx
000078eb87dd1835  pop rcx
000078eb87dd1836  pop rax
000078eb87dd1837  add rsp, 0x08
000078eb87dd183b  jmp 0x000078EB87DCF923
000078eb87dd1840  call 0x000078EB87BFF430
000078eb87dd1845  jmp 0x000078EB87DCF930
000078eb87dd184a  sub rsp, 0x08
000078eb87dd184e  push rax
000078eb87dd184f  push rcx
000078eb87dd1850  push rdx
000078eb87dd1851  push rdi
000078eb87dd1852  push rsi
000078eb87dd1853  push r8
000078eb87dd1855  push r9
000078eb87dd1857  push r10
000078eb87dd1859  push r11
000078eb87dd185b  sub rsp, 0xF0
000078eb87dd1862  vmovaps [rsp], xmm0
000078eb87dd1867  vmovaps [rsp+0x10], xmm1
000078eb87dd186d  vmovaps [rsp+0x20], xmm3
000078eb87dd1873  vmovaps [rsp+0x30], xmm4
000078eb87dd1879  vmovaps [rsp+0x40], xmm5
000078eb87dd187f  vmovaps [rsp+0x50], xmm6
000078eb87dd1885  vmovaps [rsp+0x60], xmm7
000078eb87dd188b  vmovaps [rsp+0x70], xmm8
000078eb87dd1891  vmovaps [rsp+0x80], xmm9
000078eb87dd189a  vmovaps [rsp+0x90], xmm10
000078eb87dd18a3  vmovaps [rsp+0xA0], xmm11
000078eb87dd18ac  vmovaps [rsp+0xB0], xmm12
000078eb87dd18b5  vmovaps [rsp+0xC0], xmm13
000078eb87dd18be  vmovaps [rsp+0xD0], xmm14
000078eb87dd18c7  vmovaps [rsp+0xE0], xmm15
000078eb87dd18d0  sub rsp, 0x30
000078eb87dd18d4  movaps [rsp], xmm2
000078eb87dd18d8  movaps [rsp+0x10], xmm1
000078eb87dd18dd  movaps [rsp+0x20], xmm14
000078eb87dd18e3  lea rdi, [rsp]
000078eb87dd18e7  mov esi, 0x00
000078eb87dd18ec  mov rax, 0x61D341A71530
000078eb87dd18f6  call rax
000078eb87dd18f8  movaps xmm2, [rsp]
000078eb87dd18fc  add rsp, 0x30
000078eb87dd1900  vmovaps xmm0, [rsp]
000078eb87dd1905  vmovaps xmm1, [rsp+0x10]
000078eb87dd190b  vmovaps xmm3, [rsp+0x20]
000078eb87dd1911  vmovaps xmm4, [rsp+0x30]
000078eb87dd1917  vmovaps xmm5, [rsp+0x40]
000078eb87dd191d  vmovaps xmm6, [rsp+0x50]
000078eb87dd1923  vmovaps xmm7, [rsp+0x60]
000078eb87dd1929  vmovaps xmm8, [rsp+0x70]
000078eb87dd192f  vmovaps xmm9, [rsp+0x80]
000078eb87dd1938  vmovaps xmm10, [rsp+0x90]
000078eb87dd1941  vmovaps xmm11, [rsp+0xA0]
000078eb87dd194a  vmovaps xmm12, [rsp+0xB0]
000078eb87dd1953  vmovaps xmm13, [rsp+0xC0]
000078eb87dd195c  vmovaps xmm14, [rsp+0xD0]
000078eb87dd1965  vmovaps xmm15, [rsp+0xE0]
000078eb87dd196e  add rsp, 0xF0
000078eb87dd1975  pop r11
000078eb87dd1977  pop r10
000078eb87dd1979  pop r9
000078eb87dd197b  pop r8
000078eb87dd197d  pop rsi
000078eb87dd197e  pop rdi
000078eb87dd197f  pop rdx
000078eb87dd1980  pop rcx
000078eb87dd1981  pop rax
000078eb87dd1982  add rsp, 0x08
000078eb87dd1986  jmp 0x000078EB87DCF96D
000078eb87dd198b  sub rsp, 0x08
000078eb87dd198f  push rax
000078eb87dd1990  push rcx
000078eb87dd1991  push rdx
000078eb87dd1992  push rdi
000078eb87dd1993  push rsi
000078eb87dd1994  push r8
000078eb87dd1996  push r9
000078eb87dd1998  push r10
000078eb87dd199a  push r11
000078eb87dd199c  sub rsp, 0xF0
000078eb87dd19a3  vmovaps [rsp], xmm0
000078eb87dd19a8  vmovaps [rsp+0x10], xmm1
000078eb87dd19ae  vmovaps [rsp+0x20], xmm2
000078eb87dd19b4  vmovaps [rsp+0x30], xmm3
000078eb87dd19ba  vmovaps [rsp+0x40], xmm4
000078eb87dd19c0  vmovaps [rsp+0x50], xmm5
000078eb87dd19c6  vmovaps [rsp+0x60], xmm6
000078eb87dd19cc  vmovaps [rsp+0x70], xmm7
000078eb87dd19d2  vmovaps [rsp+0x80], xmm8
000078eb87dd19db  vmovaps [rsp+0x90], xmm9
000078eb87dd19e4  vmovaps [rsp+0xA0], xmm10
000078eb87dd19ed  vmovaps [rsp+0xB0], xmm11
000078eb87dd19f6  vmovaps [rsp+0xC0], xmm12
000078eb87dd19ff  vmovaps [rsp+0xD0], xmm13
000078eb87dd1a08  vmovaps [rsp+0xE0], xmm14
000078eb87dd1a11  sub rsp, 0x30
000078eb87dd1a15  movaps [rsp], xmm15
000078eb87dd1a1a  movaps [rsp+0x10], xmm14
000078eb87dd1a20  movaps [rsp+0x20], xmm1
000078eb87dd1a25  lea rdi, [rsp]
000078eb87dd1a29  mov esi, 0x00
000078eb87dd1a2e  mov rax, 0x61D341A71530
000078eb87dd1a38  call rax
000078eb87dd1a3a  movaps xmm15, [rsp]
000078eb87dd1a3f  add rsp, 0x30
000078eb87dd1a43  vmovaps xmm0, [rsp]
000078eb87dd1a48  vmovaps xmm1, [rsp+0x10]
000078eb87dd1a4e  vmovaps xmm2, [rsp+0x20]
000078eb87dd1a54  vmovaps xmm3, [rsp+0x30]
000078eb87dd1a5a  vmovaps xmm4, [rsp+0x40]
000078eb87dd1a60  vmovaps xmm5, [rsp+0x50]
000078eb87dd1a66  vmovaps xmm6, [rsp+0x60]
000078eb87dd1a6c  vmovaps xmm7, [rsp+0x70]
000078eb87dd1a72  vmovaps xmm8, [rsp+0x80]
000078eb87dd1a7b  vmovaps xmm9, [rsp+0x90]
000078eb87dd1a84  vmovaps xmm10, [rsp+0xA0]
000078eb87dd1a8d  vmovaps xmm11, [rsp+0xB0]
000078eb87dd1a96  vmovaps xmm12, [rsp+0xC0]
000078eb87dd1a9f  vmovaps xmm13, [rsp+0xD0]
000078eb87dd1aa8  vmovaps xmm14, [rsp+0xE0]
000078eb87dd1ab1  add rsp, 0xF0
000078eb87dd1ab8  pop r11
000078eb87dd1aba  pop r10
000078eb87dd1abc  pop r9
000078eb87dd1abe  pop r8
000078eb87dd1ac0  pop rsi
000078eb87dd1ac1  pop rdi
000078eb87dd1ac2  pop rdx
000078eb87dd1ac3  pop rcx
000078eb87dd1ac4  pop rax
000078eb87dd1ac5  add rsp, 0x08
000078eb87dd1ac9  jmp 0x000078EB87DCF9E7
000078eb87dd1ace  call 0x000078EB87BFF430
000078eb87dd1ad3  jmp 0x000078EB87DCF9F4
000078eb87dd1ad8  sub rsp, 0x08
000078eb87dd1adc  push rax
000078eb87dd1add  push rcx
000078eb87dd1ade  push rdx
000078eb87dd1adf  push rdi
000078eb87dd1ae0  push rsi
000078eb87dd1ae1  push r8
000078eb87dd1ae3  push r9
000078eb87dd1ae5  push r10
000078eb87dd1ae7  push r11
000078eb87dd1ae9  sub rsp, 0xF0
000078eb87dd1af0  vmovaps [rsp], xmm0
000078eb87dd1af5  vmovaps [rsp+0x10], xmm1
000078eb87dd1afb  vmovaps [rsp+0x20], xmm2
000078eb87dd1b01  vmovaps [rsp+0x30], xmm3
000078eb87dd1b07  vmovaps [rsp+0x40], xmm4
000078eb87dd1b0d  vmovaps [rsp+0x50], xmm5
000078eb87dd1b13  vmovaps [rsp+0x60], xmm6
000078eb87dd1b19  vmovaps [rsp+0x70], xmm7
000078eb87dd1b1f  vmovaps [rsp+0x80], xmm8
000078eb87dd1b28  vmovaps [rsp+0x90], xmm9
000078eb87dd1b31  vmovaps [rsp+0xA0], xmm10
000078eb87dd1b3a  vmovaps [rsp+0xB0], xmm11
000078eb87dd1b43  vmovaps [rsp+0xC0], xmm12
000078eb87dd1b4c  vmovaps [rsp+0xD0], xmm13
000078eb87dd1b55  vmovaps [rsp+0xE0], xmm15
000078eb87dd1b5e  sub rsp, 0x30
000078eb87dd1b62  movaps [rsp], xmm14
000078eb87dd1b67  movaps [rsp+0x10], xmm13
000078eb87dd1b6d  movaps [rsp+0x20], xmm1
000078eb87dd1b72  lea rdi, [rsp]
000078eb87dd1b76  mov esi, 0x00
000078eb87dd1b7b  mov rax, 0x61D341A71530
000078eb87dd1b85  call rax
000078eb87dd1b87  movaps xmm14, [rsp]
000078eb87dd1b8c  add rsp, 0x30
000078eb87dd1b90  vmovaps xmm0, [rsp]
000078eb87dd1b95  vmovaps xmm1, [rsp+0x10]
000078eb87dd1b9b  vmovaps xmm2, [rsp+0x20]
000078eb87dd1ba1  vmovaps xmm3, [rsp+0x30]
000078eb87dd1ba7  vmovaps xmm4, [rsp+0x40]
000078eb87dd1bad  vmovaps xmm5, [rsp+0x50]
000078eb87dd1bb3  vmovaps xmm6, [rsp+0x60]
000078eb87dd1bb9  vmovaps xmm7, [rsp+0x70]
000078eb87dd1bbf  vmovaps xmm8, [rsp+0x80]
000078eb87dd1bc8  vmovaps xmm9, [rsp+0x90]
000078eb87dd1bd1  vmovaps xmm10, [rsp+0xA0]
000078eb87dd1bda  vmovaps xmm11, [rsp+0xB0]
000078eb87dd1be3  vmovaps xmm12, [rsp+0xC0]
000078eb87dd1bec  vmovaps xmm13, [rsp+0xD0]
000078eb87dd1bf5  vmovaps xmm15, [rsp+0xE0]
000078eb87dd1bfe  add rsp, 0xF0
000078eb87dd1c05  pop r11
000078eb87dd1c07  pop r10
000078eb87dd1c09  pop r9
000078eb87dd1c0b  pop r8
000078eb87dd1c0d  pop rsi
000078eb87dd1c0e  pop rdi
000078eb87dd1c0f  pop rdx
000078eb87dd1c10  pop rcx
000078eb87dd1c11  pop rax
000078eb87dd1c12  add rsp, 0x08
000078eb87dd1c16  jmp 0x000078EB87DCFAAF
000078eb87dd1c1b  sub rsp, 0x08
000078eb87dd1c1f  push rax
000078eb87dd1c20  push rcx
000078eb87dd1c21  push rdx
000078eb87dd1c22  push rdi
000078eb87dd1c23  push rsi
000078eb87dd1c24  push r8
000078eb87dd1c26  push r9
000078eb87dd1c28  push r10
000078eb87dd1c2a  push r11
000078eb87dd1c2c  sub rsp, 0xF0
000078eb87dd1c33  vmovaps [rsp], xmm0
000078eb87dd1c38  vmovaps [rsp+0x10], xmm1
000078eb87dd1c3e  vmovaps [rsp+0x20], xmm2
000078eb87dd1c44  vmovaps [rsp+0x30], xmm3
000078eb87dd1c4a  vmovaps [rsp+0x40], xmm4
000078eb87dd1c50  vmovaps [rsp+0x50], xmm5
000078eb87dd1c56  vmovaps [rsp+0x60], xmm6
000078eb87dd1c5c  vmovaps [rsp+0x70], xmm7
000078eb87dd1c62  vmovaps [rsp+0x80], xmm8
000078eb87dd1c6b  vmovaps [rsp+0x90], xmm9
000078eb87dd1c74  vmovaps [rsp+0xA0], xmm10
000078eb87dd1c7d  vmovaps [rsp+0xB0], xmm11
000078eb87dd1c86  vmovaps [rsp+0xC0], xmm12
000078eb87dd1c8f  vmovaps [rsp+0xD0], xmm13
000078eb87dd1c98  vmovaps [rsp+0xE0], xmm14
000078eb87dd1ca1  sub rsp, 0x30
000078eb87dd1ca5  movaps [rsp], xmm15
000078eb87dd1caa  movaps [rsp+0x10], xmm13
000078eb87dd1cb0  movaps [rsp+0x20], xmm1
000078eb87dd1cb5  lea rdi, [rsp]
000078eb87dd1cb9  mov esi, 0x00
000078eb87dd1cbe  mov rax, 0x61D341A71530
000078eb87dd1cc8  call rax
000078eb87dd1cca  movaps xmm15, [rsp]
000078eb87dd1ccf  add rsp, 0x30
000078eb87dd1cd3  vmovaps xmm0, [rsp]
000078eb87dd1cd8  vmovaps xmm1, [rsp+0x10]
000078eb87dd1cde  vmovaps xmm2, [rsp+0x20]
000078eb87dd1ce4  vmovaps xmm3, [rsp+0x30]
000078eb87dd1cea  vmovaps xmm4, [rsp+0x40]
000078eb87dd1cf0  vmovaps xmm5, [rsp+0x50]
000078eb87dd1cf6  vmovaps xmm6, [rsp+0x60]
000078eb87dd1cfc  vmovaps xmm7, [rsp+0x70]
000078eb87dd1d02  vmovaps xmm8, [rsp+0x80]
000078eb87dd1d0b  vmovaps xmm9, [rsp+0x90]
000078eb87dd1d14  vmovaps xmm10, [rsp+0xA0]
000078eb87dd1d1d  vmovaps xmm11, [rsp+0xB0]
000078eb87dd1d26  vmovaps xmm12, [rsp+0xC0]
000078eb87dd1d2f  vmovaps xmm13, [rsp+0xD0]
000078eb87dd1d38  vmovaps xmm14, [rsp+0xE0]
000078eb87dd1d41  add rsp, 0xF0
000078eb87dd1d48  pop r11
000078eb87dd1d4a  pop r10
000078eb87dd1d4c  pop r9
000078eb87dd1d4e  pop r8
000078eb87dd1d50  pop rsi
000078eb87dd1d51  pop rdi
000078eb87dd1d52  pop rdx
000078eb87dd1d53  pop rcx
000078eb87dd1d54  pop rax
000078eb87dd1d55  add rsp, 0x08
000078eb87dd1d59  jmp 0x000078EB87DCFAEB
000078eb87dd1d5e  call 0x000078EB87BFF430
000078eb87dd1d63  jmp 0x000078EB87DCFAF8
000078eb87dd1d68  sub rsp, 0x08
000078eb87dd1d6c  push rax
000078eb87dd1d6d  push rcx
000078eb87dd1d6e  push rdx
000078eb87dd1d6f  push rdi
000078eb87dd1d70  push rsi
000078eb87dd1d71  push r8
000078eb87dd1d73  push r9
000078eb87dd1d75  push r10
000078eb87dd1d77  push r11
000078eb87dd1d79  sub rsp, 0xF0
000078eb87dd1d80  vmovaps [rsp], xmm0
000078eb87dd1d85  vmovaps [rsp+0x10], xmm1
000078eb87dd1d8b  vmovaps [rsp+0x20], xmm2
000078eb87dd1d91  vmovaps [rsp+0x30], xmm3
000078eb87dd1d97  vmovaps [rsp+0x40], xmm4
000078eb87dd1d9d  vmovaps [rsp+0x50], xmm5
000078eb87dd1da3  vmovaps [rsp+0x60], xmm6
000078eb87dd1da9  vmovaps [rsp+0x70], xmm7
000078eb87dd1daf  vmovaps [rsp+0x80], xmm8
000078eb87dd1db8  vmovaps [rsp+0x90], xmm9
000078eb87dd1dc1  vmovaps [rsp+0xA0], xmm10
000078eb87dd1dca  vmovaps [rsp+0xB0], xmm11
000078eb87dd1dd3  vmovaps [rsp+0xC0], xmm12
000078eb87dd1ddc  vmovaps [rsp+0xD0], xmm13
000078eb87dd1de5  vmovaps [rsp+0xE0], xmm15
000078eb87dd1dee  sub rsp, 0x30
000078eb87dd1df2  movaps [rsp], xmm14
000078eb87dd1df7  movaps [rsp+0x10], xmm13
000078eb87dd1dfd  movaps [rsp+0x20], xmm2
000078eb87dd1e02  lea rdi, [rsp]
000078eb87dd1e06  mov esi, 0x00
000078eb87dd1e0b  mov rax, 0x61D341A71530
000078eb87dd1e15  call rax
000078eb87dd1e17  movaps xmm14, [rsp]
000078eb87dd1e1c  add rsp, 0x30
000078eb87dd1e20  vmovaps xmm0, [rsp]
000078eb87dd1e25  vmovaps xmm1, [rsp+0x10]
000078eb87dd1e2b  vmovaps xmm2, [rsp+0x20]
000078eb87dd1e31  vmovaps xmm3, [rsp+0x30]
000078eb87dd1e37  vmovaps xmm4, [rsp+0x40]
000078eb87dd1e3d  vmovaps xmm5, [rsp+0x50]
000078eb87dd1e43  vmovaps xmm6, [rsp+0x60]
000078eb87dd1e49  vmovaps xmm7, [rsp+0x70]
000078eb87dd1e4f  vmovaps xmm8, [rsp+0x80]
000078eb87dd1e58  vmovaps xmm9, [rsp+0x90]
000078eb87dd1e61  vmovaps xmm10, [rsp+0xA0]
000078eb87dd1e6a  vmovaps xmm11, [rsp+0xB0]
000078eb87dd1e73  vmovaps xmm12, [rsp+0xC0]
000078eb87dd1e7c  vmovaps xmm13, [rsp+0xD0]
000078eb87dd1e85  vmovaps xmm15, [rsp+0xE0]
000078eb87dd1e8e  add rsp, 0xF0
000078eb87dd1e95  pop r11
000078eb87dd1e97  pop r10
000078eb87dd1e99  pop r9
000078eb87dd1e9b  pop r8
000078eb87dd1e9d  pop rsi
000078eb87dd1e9e  pop rdi
000078eb87dd1e9f  pop rdx
000078eb87dd1ea0  pop rcx
000078eb87dd1ea1  pop rax
000078eb87dd1ea2  add rsp, 0x08
000078eb87dd1ea6  jmp 0x000078EB87DCFB24
000078eb87dd1eab  sub rsp, 0x08
000078eb87dd1eaf  push rax
000078eb87dd1eb0  push rcx
000078eb87dd1eb1  push rdx
000078eb87dd1eb2  push rdi
000078eb87dd1eb3  push rsi
000078eb87dd1eb4  push r8
000078eb87dd1eb6  push r9
000078eb87dd1eb8  push r10
000078eb87dd1eba  push r11
000078eb87dd1ebc  sub rsp, 0xF0
000078eb87dd1ec3  vmovaps [rsp], xmm0
000078eb87dd1ec8  vmovaps [rsp+0x10], xmm2
000078eb87dd1ece  vmovaps [rsp+0x20], xmm3
000078eb87dd1ed4  vmovaps [rsp+0x30], xmm4
000078eb87dd1eda  vmovaps [rsp+0x40], xmm5
000078eb87dd1ee0  vmovaps [rsp+0x50], xmm6
000078eb87dd1ee6  vmovaps [rsp+0x60], xmm7
000078eb87dd1eec  vmovaps [rsp+0x70], xmm8
000078eb87dd1ef2  vmovaps [rsp+0x80], xmm9
000078eb87dd1efb  vmovaps [rsp+0x90], xmm10
000078eb87dd1f04  vmovaps [rsp+0xA0], xmm11
000078eb87dd1f0d  vmovaps [rsp+0xB0], xmm12
000078eb87dd1f16  vmovaps [rsp+0xC0], xmm13
000078eb87dd1f1f  vmovaps [rsp+0xD0], xmm14
000078eb87dd1f28  vmovaps [rsp+0xE0], xmm15
000078eb87dd1f31  sub rsp, 0x30
000078eb87dd1f35  movaps [rsp], xmm1
000078eb87dd1f39  movaps [rsp+0x10], xmm13
000078eb87dd1f3f  movaps [rsp+0x20], xmm2
000078eb87dd1f44  lea rdi, [rsp]
000078eb87dd1f48  mov esi, 0x00
000078eb87dd1f4d  mov rax, 0x61D341A71530
000078eb87dd1f57  call rax
000078eb87dd1f59  movaps xmm1, [rsp]
000078eb87dd1f5d  add rsp, 0x30
000078eb87dd1f61  vmovaps xmm0, [rsp]
000078eb87dd1f66  vmovaps xmm2, [rsp+0x10]
000078eb87dd1f6c  vmovaps xmm3, [rsp+0x20]
000078eb87dd1f72  vmovaps xmm4, [rsp+0x30]
000078eb87dd1f78  vmovaps xmm5, [rsp+0x40]
000078eb87dd1f7e  vmovaps xmm6, [rsp+0x50]
000078eb87dd1f84  vmovaps xmm7, [rsp+0x60]
000078eb87dd1f8a  vmovaps xmm8, [rsp+0x70]
000078eb87dd1f90  vmovaps xmm9, [rsp+0x80]
000078eb87dd1f99  vmovaps xmm10, [rsp+0x90]
000078eb87dd1fa2  vmovaps xmm11, [rsp+0xA0]
000078eb87dd1fab  vmovaps xmm12, [rsp+0xB0]
000078eb87dd1fb4  vmovaps xmm13, [rsp+0xC0]
000078eb87dd1fbd  vmovaps xmm14, [rsp+0xD0]
000078eb87dd1fc6  vmovaps xmm15, [rsp+0xE0]
000078eb87dd1fcf  add rsp, 0xF0
000078eb87dd1fd6  pop r11
000078eb87dd1fd8  pop r10
000078eb87dd1fda  pop r9
000078eb87dd1fdc  pop r8
000078eb87dd1fde  pop rsi
000078eb87dd1fdf  pop rdi
000078eb87dd1fe0  pop rdx
000078eb87dd1fe1  pop rcx
000078eb87dd1fe2  pop rax
000078eb87dd1fe3  add rsp, 0x08
000078eb87dd1fe7  jmp 0x000078EB87DCFB52
000078eb87dd1fec  sub rsp, 0x08
000078eb87dd1ff0  push rax
000078eb87dd1ff1  push rcx
000078eb87dd1ff2  push rdx
000078eb87dd1ff3  push rdi
000078eb87dd1ff4  push rsi
000078eb87dd1ff5  push r8
000078eb87dd1ff7  push r9
000078eb87dd1ff9  push r10
000078eb87dd1ffb  push r11
000078eb87dd1ffd  sub rsp, 0xF0
000078eb87dd2004  vmovaps [rsp], xmm0
000078eb87dd2009  vmovaps [rsp+0x10], xmm1
000078eb87dd200f  vmovaps [rsp+0x20], xmm3
000078eb87dd2015  vmovaps [rsp+0x30], xmm4
000078eb87dd201b  vmovaps [rsp+0x40], xmm5
000078eb87dd2021  vmovaps [rsp+0x50], xmm6
000078eb87dd2027  vmovaps [rsp+0x60], xmm7
000078eb87dd202d  vmovaps [rsp+0x70], xmm8
000078eb87dd2033  vmovaps [rsp+0x80], xmm9
000078eb87dd203c  vmovaps [rsp+0x90], xmm10
000078eb87dd2045  vmovaps [rsp+0xA0], xmm11
000078eb87dd204e  vmovaps [rsp+0xB0], xmm12
000078eb87dd2057  vmovaps [rsp+0xC0], xmm13
000078eb87dd2060  vmovaps [rsp+0xD0], xmm14
000078eb87dd2069  vmovaps [rsp+0xE0], xmm15
000078eb87dd2072  sub rsp, 0x30
000078eb87dd2076  movaps [rsp], xmm2
000078eb87dd207a  movaps [rsp+0x10], xmm1
000078eb87dd207f  movaps [rsp+0x20], xmm13
000078eb87dd2085  lea rdi, [rsp]
000078eb87dd2089  mov esi, 0x00
000078eb87dd208e  mov rax, 0x61D341A71530
000078eb87dd2098  call rax
000078eb87dd209a  movaps xmm2, [rsp]
000078eb87dd209e  add rsp, 0x30
000078eb87dd20a2  vmovaps xmm0, [rsp]
000078eb87dd20a7  vmovaps xmm1, [rsp+0x10]
000078eb87dd20ad  vmovaps xmm3, [rsp+0x20]
000078eb87dd20b3  vmovaps xmm4, [rsp+0x30]
000078eb87dd20b9  vmovaps xmm5, [rsp+0x40]
000078eb87dd20bf  vmovaps xmm6, [rsp+0x50]
000078eb87dd20c5  vmovaps xmm7, [rsp+0x60]
000078eb87dd20cb  vmovaps xmm8, [rsp+0x70]
000078eb87dd20d1  vmovaps xmm9, [rsp+0x80]
000078eb87dd20da  vmovaps xmm10, [rsp+0x90]
000078eb87dd20e3  vmovaps xmm11, [rsp+0xA0]
000078eb87dd20ec  vmovaps xmm12, [rsp+0xB0]
000078eb87dd20f5  vmovaps xmm13, [rsp+0xC0]
000078eb87dd20fe  vmovaps xmm14, [rsp+0xD0]
000078eb87dd2107  vmovaps xmm15, [rsp+0xE0]
000078eb87dd2110  add rsp, 0xF0
000078eb87dd2117  pop r11
000078eb87dd2119  pop r10
000078eb87dd211b  pop r9
000078eb87dd211d  pop r8
000078eb87dd211f  pop rsi
000078eb87dd2120  pop rdi
000078eb87dd2121  pop rdx
000078eb87dd2122  pop rcx
000078eb87dd2123  pop rax
000078eb87dd2124  add rsp, 0x08
000078eb87dd2128  jmp 0x000078EB87DCFBAB
000078eb87dd212d  call 0x000078EB87BFF430
000078eb87dd2132  jmp 0x000078EB87DCFBB8
000078eb87dd2137  sub rsp, 0x08
000078eb87dd213b  push rax
000078eb87dd213c  push rcx
000078eb87dd213d  push rdx
000078eb87dd213e  push rdi
000078eb87dd213f  push rsi
000078eb87dd2140  push r8
000078eb87dd2142  push r9
000078eb87dd2144  push r10
000078eb87dd2146  push r11
000078eb87dd2148  sub rsp, 0xF0
000078eb87dd214f  vmovaps [rsp], xmm0
000078eb87dd2154  vmovaps [rsp+0x10], xmm1
000078eb87dd215a  vmovaps [rsp+0x20], xmm2
000078eb87dd2160  vmovaps [rsp+0x30], xmm3
000078eb87dd2166  vmovaps [rsp+0x40], xmm4
000078eb87dd216c  vmovaps [rsp+0x50], xmm5
000078eb87dd2172  vmovaps [rsp+0x60], xmm6
000078eb87dd2178  vmovaps [rsp+0x70], xmm7
000078eb87dd217e  vmovaps [rsp+0x80], xmm8
000078eb87dd2187  vmovaps [rsp+0x90], xmm9
000078eb87dd2190  vmovaps [rsp+0xA0], xmm10
000078eb87dd2199  vmovaps [rsp+0xB0], xmm11
000078eb87dd21a2  vmovaps [rsp+0xC0], xmm12
000078eb87dd21ab  vmovaps [rsp+0xD0], xmm13
000078eb87dd21b4  vmovaps [rsp+0xE0], xmm14
000078eb87dd21bd  sub rsp, 0x30
000078eb87dd21c1  movaps [rsp], xmm15
000078eb87dd21c6  movaps [rsp+0x10], xmm13
000078eb87dd21cc  movaps [rsp+0x20], xmm1
000078eb87dd21d1  lea rdi, [rsp]
000078eb87dd21d5  mov esi, 0x00
000078eb87dd21da  mov rax, 0x61D341A71530
000078eb87dd21e4  call rax
000078eb87dd21e6  movaps xmm15, [rsp]
000078eb87dd21eb  add rsp, 0x30
000078eb87dd21ef  vmovaps xmm0, [rsp]
000078eb87dd21f4  vmovaps xmm1, [rsp+0x10]
000078eb87dd21fa  vmovaps xmm2, [rsp+0x20]
000078eb87dd2200  vmovaps xmm3, [rsp+0x30]
000078eb87dd2206  vmovaps xmm4, [rsp+0x40]
000078eb87dd220c  vmovaps xmm5, [rsp+0x50]
000078eb87dd2212  vmovaps xmm6, [rsp+0x60]
000078eb87dd2218  vmovaps xmm7, [rsp+0x70]
000078eb87dd221e  vmovaps xmm8, [rsp+0x80]
000078eb87dd2227  vmovaps xmm9, [rsp+0x90]
000078eb87dd2230  vmovaps xmm10, [rsp+0xA0]
000078eb87dd2239  vmovaps xmm11, [rsp+0xB0]
000078eb87dd2242  vmovaps xmm12, [rsp+0xC0]
000078eb87dd224b  vmovaps xmm13, [rsp+0xD0]
000078eb87dd2254  vmovaps xmm14, [rsp+0xE0]
000078eb87dd225d  add rsp, 0xF0
000078eb87dd2264  pop r11
000078eb87dd2266  pop r10
000078eb87dd2268  pop r9
000078eb87dd226a  pop r8
000078eb87dd226c  pop rsi
000078eb87dd226d  pop rdi
000078eb87dd226e  pop rdx
000078eb87dd226f  pop rcx
000078eb87dd2270  pop rax
000078eb87dd2271  add rsp, 0x08
000078eb87dd2275  jmp 0x000078EB87DCFBF7
000078eb87dd227a  sub rsp, 0x08
000078eb87dd227e  push rax
000078eb87dd227f  push rcx
000078eb87dd2280  push rdx
000078eb87dd2281  push rdi
000078eb87dd2282  push rsi
000078eb87dd2283  push r8
000078eb87dd2285  push r9
000078eb87dd2287  push r10
000078eb87dd2289  push r11
000078eb87dd228b  sub rsp, 0xF0
000078eb87dd2292  vmovaps [rsp], xmm0
000078eb87dd2297  vmovaps [rsp+0x10], xmm1
000078eb87dd229d  vmovaps [rsp+0x20], xmm2
000078eb87dd22a3  vmovaps [rsp+0x30], xmm3
000078eb87dd22a9  vmovaps [rsp+0x40], xmm4
000078eb87dd22af  vmovaps [rsp+0x50], xmm5
000078eb87dd22b5  vmovaps [rsp+0x60], xmm6
000078eb87dd22bb  vmovaps [rsp+0x70], xmm7
000078eb87dd22c1  vmovaps [rsp+0x80], xmm8
000078eb87dd22ca  vmovaps [rsp+0x90], xmm9
000078eb87dd22d3  vmovaps [rsp+0xA0], xmm10
000078eb87dd22dc  vmovaps [rsp+0xB0], xmm11
000078eb87dd22e5  vmovaps [rsp+0xC0], xmm12
000078eb87dd22ee  vmovaps [rsp+0xD0], xmm13
000078eb87dd22f7  vmovaps [rsp+0xE0], xmm15
000078eb87dd2300  sub rsp, 0x30
000078eb87dd2304  movaps [rsp], xmm14
000078eb87dd2309  movaps [rsp+0x10], xmm11
000078eb87dd230f  movaps [rsp+0x20], xmm1
000078eb87dd2314  lea rdi, [rsp]
000078eb87dd2318  mov esi, 0x00
000078eb87dd231d  mov rax, 0x61D341A71530
000078eb87dd2327  call rax
000078eb87dd2329  movaps xmm14, [rsp]
000078eb87dd232e  add rsp, 0x30
000078eb87dd2332  vmovaps xmm0, [rsp]
000078eb87dd2337  vmovaps xmm1, [rsp+0x10]
000078eb87dd233d  vmovaps xmm2, [rsp+0x20]
000078eb87dd2343  vmovaps xmm3, [rsp+0x30]
000078eb87dd2349  vmovaps xmm4, [rsp+0x40]
000078eb87dd234f  vmovaps xmm5, [rsp+0x50]
000078eb87dd2355  vmovaps xmm6, [rsp+0x60]
000078eb87dd235b  vmovaps xmm7, [rsp+0x70]
000078eb87dd2361  vmovaps xmm8, [rsp+0x80]
000078eb87dd236a  vmovaps xmm9, [rsp+0x90]
000078eb87dd2373  vmovaps xmm10, [rsp+0xA0]
000078eb87dd237c  vmovaps xmm11, [rsp+0xB0]
000078eb87dd2385  vmovaps xmm12, [rsp+0xC0]
000078eb87dd238e  vmovaps xmm13, [rsp+0xD0]
000078eb87dd2397  vmovaps xmm15, [rsp+0xE0]
000078eb87dd23a0  add rsp, 0xF0
000078eb87dd23a7  pop r11
000078eb87dd23a9  pop r10
000078eb87dd23ab  pop r9
000078eb87dd23ad  pop r8
000078eb87dd23af  pop rsi
000078eb87dd23b0  pop rdi
000078eb87dd23b1  pop rdx
000078eb87dd23b2  pop rcx
000078eb87dd23b3  pop rax
000078eb87dd23b4  add rsp, 0x08
000078eb87dd23b8  jmp 0x000078EB87DCFC21
000078eb87dd23bd  sub rsp, 0x08
000078eb87dd23c1  push rax
000078eb87dd23c2  push rcx
000078eb87dd23c3  push rdx
000078eb87dd23c4  push rdi
000078eb87dd23c5  push rsi
000078eb87dd23c6  push r8
000078eb87dd23c8  push r9
000078eb87dd23ca  push r10
000078eb87dd23cc  push r11
000078eb87dd23ce  sub rsp, 0xF0
000078eb87dd23d5  vmovaps [rsp], xmm0
000078eb87dd23da  vmovaps [rsp+0x10], xmm1
000078eb87dd23e0  vmovaps [rsp+0x20], xmm2
000078eb87dd23e6  vmovaps [rsp+0x30], xmm3
000078eb87dd23ec  vmovaps [rsp+0x40], xmm4
000078eb87dd23f2  vmovaps [rsp+0x50], xmm5
000078eb87dd23f8  vmovaps [rsp+0x60], xmm6
000078eb87dd23fe  vmovaps [rsp+0x70], xmm7
000078eb87dd2404  vmovaps [rsp+0x80], xmm8
000078eb87dd240d  vmovaps [rsp+0x90], xmm9
000078eb87dd2416  vmovaps [rsp+0xA0], xmm10
000078eb87dd241f  vmovaps [rsp+0xB0], xmm11
000078eb87dd2428  vmovaps [rsp+0xC0], xmm12
000078eb87dd2431  vmovaps [rsp+0xD0], xmm14
000078eb87dd243a  vmovaps [rsp+0xE0], xmm15
000078eb87dd2443  sub rsp, 0x30
000078eb87dd2447  movaps [rsp], xmm13
000078eb87dd244c  movaps [rsp+0x10], xmm11
000078eb87dd2452  movaps [rsp+0x20], xmm1
000078eb87dd2457  lea rdi, [rsp]
000078eb87dd245b  mov esi, 0x00
000078eb87dd2460  mov rax, 0x61D341A71530
000078eb87dd246a  call rax
000078eb87dd246c  movaps xmm13, [rsp]
000078eb87dd2471  add rsp, 0x30
000078eb87dd2475  vmovaps xmm0, [rsp]
000078eb87dd247a  vmovaps xmm1, [rsp+0x10]
000078eb87dd2480  vmovaps xmm2, [rsp+0x20]
000078eb87dd2486  vmovaps xmm3, [rsp+0x30]
000078eb87dd248c  vmovaps xmm4, [rsp+0x40]
000078eb87dd2492  vmovaps xmm5, [rsp+0x50]
000078eb87dd2498  vmovaps xmm6, [rsp+0x60]
000078eb87dd249e  vmovaps xmm7, [rsp+0x70]
000078eb87dd24a4  vmovaps xmm8, [rsp+0x80]
000078eb87dd24ad  vmovaps xmm9, [rsp+0x90]
000078eb87dd24b6  vmovaps xmm10, [rsp+0xA0]
000078eb87dd24bf  vmovaps xmm11, [rsp+0xB0]
000078eb87dd24c8  vmovaps xmm12, [rsp+0xC0]
000078eb87dd24d1  vmovaps xmm14, [rsp+0xD0]
000078eb87dd24da  vmovaps xmm15, [rsp+0xE0]
000078eb87dd24e3  add rsp, 0xF0
000078eb87dd24ea  pop r11
000078eb87dd24ec  pop r10
000078eb87dd24ee  pop r9
000078eb87dd24f0  pop r8
000078eb87dd24f2  pop rsi
000078eb87dd24f3  pop rdi
000078eb87dd24f4  pop rdx
000078eb87dd24f5  pop rcx
000078eb87dd24f6  pop rax
000078eb87dd24f7  add rsp, 0x08
000078eb87dd24fb  jmp 0x000078EB87DCFC76
000078eb87dd2500  call 0x000078EB87BFF430
000078eb87dd2505  jmp 0x000078EB87DCFC83
000078eb87dd250a  sub rsp, 0x08
000078eb87dd250e  push rax
000078eb87dd250f  push rcx
000078eb87dd2510  push rdx
000078eb87dd2511  push rdi
000078eb87dd2512  push rsi
000078eb87dd2513  push r8
000078eb87dd2515  push r9
000078eb87dd2517  push r10
000078eb87dd2519  push r11
000078eb87dd251b  sub rsp, 0xF0
000078eb87dd2522  vmovaps [rsp], xmm0
000078eb87dd2527  vmovaps [rsp+0x10], xmm1
000078eb87dd252d  vmovaps [rsp+0x20], xmm2
000078eb87dd2533  vmovaps [rsp+0x30], xmm3
000078eb87dd2539  vmovaps [rsp+0x40], xmm4
000078eb87dd253f  vmovaps [rsp+0x50], xmm5
000078eb87dd2545  vmovaps [rsp+0x60], xmm6
000078eb87dd254b  vmovaps [rsp+0x70], xmm7
000078eb87dd2551  vmovaps [rsp+0x80], xmm8
000078eb87dd255a  vmovaps [rsp+0x90], xmm9
000078eb87dd2563  vmovaps [rsp+0xA0], xmm10
000078eb87dd256c  vmovaps [rsp+0xB0], xmm11
000078eb87dd2575  vmovaps [rsp+0xC0], xmm12
000078eb87dd257e  vmovaps [rsp+0xD0], xmm13
000078eb87dd2587  vmovaps [rsp+0xE0], xmm14
000078eb87dd2590  sub rsp, 0x30
000078eb87dd2594  movaps [rsp], xmm15
000078eb87dd2599  movaps [rsp+0x10], xmm11
000078eb87dd259f  movaps [rsp+0x20], xmm1
000078eb87dd25a4  lea rdi, [rsp]
000078eb87dd25a8  mov esi, 0x00
000078eb87dd25ad  mov rax, 0x61D341A71530
000078eb87dd25b7  call rax
000078eb87dd25b9  movaps xmm15, [rsp]
000078eb87dd25be  add rsp, 0x30
000078eb87dd25c2  vmovaps xmm0, [rsp]
000078eb87dd25c7  vmovaps xmm1, [rsp+0x10]
000078eb87dd25cd  vmovaps xmm2, [rsp+0x20]
000078eb87dd25d3  vmovaps xmm3, [rsp+0x30]
000078eb87dd25d9  vmovaps xmm4, [rsp+0x40]
000078eb87dd25df  vmovaps xmm5, [rsp+0x50]
000078eb87dd25e5  vmovaps xmm6, [rsp+0x60]
000078eb87dd25eb  vmovaps xmm7, [rsp+0x70]
000078eb87dd25f1  vmovaps xmm8, [rsp+0x80]
000078eb87dd25fa  vmovaps xmm9, [rsp+0x90]
000078eb87dd2603  vmovaps xmm10, [rsp+0xA0]
000078eb87dd260c  vmovaps xmm11, [rsp+0xB0]
000078eb87dd2615  vmovaps xmm12, [rsp+0xC0]
000078eb87dd261e  vmovaps xmm13, [rsp+0xD0]
000078eb87dd2627  vmovaps xmm14, [rsp+0xE0]
000078eb87dd2630  add rsp, 0xF0
000078eb87dd2637  pop r11
000078eb87dd2639  pop r10
000078eb87dd263b  pop r9
000078eb87dd263d  pop r8
000078eb87dd263f  pop rsi
000078eb87dd2640  pop rdi
000078eb87dd2641  pop rdx
000078eb87dd2642  pop rcx
000078eb87dd2643  pop rax
000078eb87dd2644  add rsp, 0x08
000078eb87dd2648  jmp 0x000078EB87DCFCBC
000078eb87dd264d  sub rsp, 0x08
000078eb87dd2651  push rax
000078eb87dd2652  push rcx
000078eb87dd2653  push rdx
000078eb87dd2654  push rdi
000078eb87dd2655  push rsi
000078eb87dd2656  push r8
000078eb87dd2658  push r9
000078eb87dd265a  push r10
000078eb87dd265c  push r11
000078eb87dd265e  sub rsp, 0xF0
000078eb87dd2665  vmovaps [rsp], xmm0
000078eb87dd266a  vmovaps [rsp+0x10], xmm1
000078eb87dd2670  vmovaps [rsp+0x20], xmm2
000078eb87dd2676  vmovaps [rsp+0x30], xmm3
000078eb87dd267c  vmovaps [rsp+0x40], xmm4
000078eb87dd2682  vmovaps [rsp+0x50], xmm5
000078eb87dd2688  vmovaps [rsp+0x60], xmm6
000078eb87dd268e  vmovaps [rsp+0x70], xmm7
000078eb87dd2694  vmovaps [rsp+0x80], xmm8
000078eb87dd269d  vmovaps [rsp+0x90], xmm9
000078eb87dd26a6  vmovaps [rsp+0xA0], xmm10
000078eb87dd26af  vmovaps [rsp+0xB0], xmm12
000078eb87dd26b8  vmovaps [rsp+0xC0], xmm13
000078eb87dd26c1  vmovaps [rsp+0xD0], xmm14
000078eb87dd26ca  vmovaps [rsp+0xE0], xmm15
000078eb87dd26d3  sub rsp, 0x30
000078eb87dd26d7  movaps [rsp], xmm11
000078eb87dd26dc  movaps [rsp+0x10], xmm6
000078eb87dd26e1  movaps [rsp+0x20], xmm14
000078eb87dd26e7  lea rdi, [rsp]
000078eb87dd26eb  mov esi, 0x00
000078eb87dd26f0  mov rax, 0x61D341A71530
000078eb87dd26fa  call rax
000078eb87dd26fc  movaps xmm11, [rsp]
000078eb87dd2701  add rsp, 0x30
000078eb87dd2705  vmovaps xmm0, [rsp]
000078eb87dd270a  vmovaps xmm1, [rsp+0x10]
000078eb87dd2710  vmovaps xmm2, [rsp+0x20]
000078eb87dd2716  vmovaps xmm3, [rsp+0x30]
000078eb87dd271c  vmovaps xmm4, [rsp+0x40]
000078eb87dd2722  vmovaps xmm5, [rsp+0x50]
000078eb87dd2728  vmovaps xmm6, [rsp+0x60]
000078eb87dd272e  vmovaps xmm7, [rsp+0x70]
000078eb87dd2734  vmovaps xmm8, [rsp+0x80]
000078eb87dd273d  vmovaps xmm9, [rsp+0x90]
000078eb87dd2746  vmovaps xmm10, [rsp+0xA0]
000078eb87dd274f  vmovaps xmm12, [rsp+0xB0]
000078eb87dd2758  vmovaps xmm13, [rsp+0xC0]
000078eb87dd2761  vmovaps xmm14, [rsp+0xD0]
000078eb87dd276a  vmovaps xmm15, [rsp+0xE0]
000078eb87dd2773  add rsp, 0xF0
000078eb87dd277a  pop r11
000078eb87dd277c  pop r10
000078eb87dd277e  pop r9
000078eb87dd2780  pop r8
000078eb87dd2782  pop rsi
000078eb87dd2783  pop rdi
000078eb87dd2784  pop rdx
000078eb87dd2785  pop rcx
000078eb87dd2786  pop rax
000078eb87dd2787  add rsp, 0x08
000078eb87dd278b  jmp 0x000078EB87DCFD34
000078eb87dd2790  call 0x000078EB87BFF430
000078eb87dd2795  jmp 0x000078EB87DCFD3E
000078eb87dd279a  sub rsp, 0x08
000078eb87dd279e  push rax
000078eb87dd279f  push rcx
000078eb87dd27a0  push rdx
000078eb87dd27a1  push rdi
000078eb87dd27a2  push rsi
000078eb87dd27a3  push r8
000078eb87dd27a5  push r9
000078eb87dd27a7  push r10
000078eb87dd27a9  push r11
000078eb87dd27ab  sub rsp, 0xF0
000078eb87dd27b2  vmovaps [rsp], xmm0
000078eb87dd27b7  vmovaps [rsp+0x10], xmm1
000078eb87dd27bd  vmovaps [rsp+0x20], xmm2
000078eb87dd27c3  vmovaps [rsp+0x30], xmm3
000078eb87dd27c9  vmovaps [rsp+0x40], xmm4
000078eb87dd27cf  vmovaps [rsp+0x50], xmm5
000078eb87dd27d5  vmovaps [rsp+0x60], xmm6
000078eb87dd27db  vmovaps [rsp+0x70], xmm7
000078eb87dd27e1  vmovaps [rsp+0x80], xmm8
000078eb87dd27ea  vmovaps [rsp+0x90], xmm9
000078eb87dd27f3  vmovaps [rsp+0xA0], xmm10
000078eb87dd27fc  vmovaps [rsp+0xB0], xmm11
000078eb87dd2805  vmovaps [rsp+0xC0], xmm12
000078eb87dd280e  vmovaps [rsp+0xD0], xmm13
000078eb87dd2817  vmovaps [rsp+0xE0], xmm15
000078eb87dd2820  sub rsp, 0x30
000078eb87dd2824  movaps [rsp], xmm14
000078eb87dd2829  movaps [rsp+0x10], xmm6
000078eb87dd282e  movaps [rsp+0x20], xmm2
000078eb87dd2833  lea rdi, [rsp]
000078eb87dd2837  mov esi, 0x00
000078eb87dd283c  mov rax, 0x61D341A71530
000078eb87dd2846  call rax
000078eb87dd2848  movaps xmm14, [rsp]
000078eb87dd284d  add rsp, 0x30
000078eb87dd2851  vmovaps xmm0, [rsp]
000078eb87dd2856  vmovaps xmm1, [rsp+0x10]
000078eb87dd285c  vmovaps xmm2, [rsp+0x20]
000078eb87dd2862  vmovaps xmm3, [rsp+0x30]
000078eb87dd2868  vmovaps xmm4, [rsp+0x40]
000078eb87dd286e  vmovaps xmm5, [rsp+0x50]
000078eb87dd2874  vmovaps xmm6, [rsp+0x60]
000078eb87dd287a  vmovaps xmm7, [rsp+0x70]
000078eb87dd2880  vmovaps xmm8, [rsp+0x80]
000078eb87dd2889  vmovaps xmm9, [rsp+0x90]
000078eb87dd2892  vmovaps xmm10, [rsp+0xA0]
000078eb87dd289b  vmovaps xmm11, [rsp+0xB0]
000078eb87dd28a4  vmovaps xmm12, [rsp+0xC0]
000078eb87dd28ad  vmovaps xmm13, [rsp+0xD0]
000078eb87dd28b6  vmovaps xmm15, [rsp+0xE0]
000078eb87dd28bf  add rsp, 0xF0
000078eb87dd28c6  pop r11
000078eb87dd28c8  pop r10
000078eb87dd28ca  pop r9
000078eb87dd28cc  pop r8
000078eb87dd28ce  pop rsi
000078eb87dd28cf  pop rdi
000078eb87dd28d0  pop rdx
000078eb87dd28d1  pop rcx
000078eb87dd28d2  pop rax
000078eb87dd28d3  add rsp, 0x08
000078eb87dd28d7  jmp 0x000078EB87DCFD72
000078eb87dd28dc  sub rsp, 0x08
000078eb87dd28e0  push rax
000078eb87dd28e1  push rcx
000078eb87dd28e2  push rdx
000078eb87dd28e3  push rdi
000078eb87dd28e4  push rsi
000078eb87dd28e5  push r8
000078eb87dd28e7  push r9
000078eb87dd28e9  push r10
000078eb87dd28eb  push r11
000078eb87dd28ed  sub rsp, 0xF0
000078eb87dd28f4  vmovaps [rsp], xmm0
000078eb87dd28f9  vmovaps [rsp+0x10], xmm1
000078eb87dd28ff  vmovaps [rsp+0x20], xmm2
000078eb87dd2905  vmovaps [rsp+0x30], xmm3
000078eb87dd290b  vmovaps [rsp+0x40], xmm4
000078eb87dd2911  vmovaps [rsp+0x50], xmm5
000078eb87dd2917  vmovaps [rsp+0x60], xmm7
000078eb87dd291d  vmovaps [rsp+0x70], xmm8
000078eb87dd2923  vmovaps [rsp+0x80], xmm9
000078eb87dd292c  vmovaps [rsp+0x90], xmm10
000078eb87dd2935  vmovaps [rsp+0xA0], xmm11
000078eb87dd293e  vmovaps [rsp+0xB0], xmm12
000078eb87dd2947  vmovaps [rsp+0xC0], xmm13
000078eb87dd2950  vmovaps [rsp+0xD0], xmm14
000078eb87dd2959  vmovaps [rsp+0xE0], xmm15
000078eb87dd2962  sub rsp, 0x30
000078eb87dd2966  movaps [rsp], xmm6
000078eb87dd296a  movaps [rsp+0x10], xmm5
000078eb87dd296f  movaps [rsp+0x20], xmm1
000078eb87dd2974  lea rdi, [rsp]
000078eb87dd2978  mov esi, 0x00
000078eb87dd297d  mov rax, 0x61D341A71530
000078eb87dd2987  call rax
000078eb87dd2989  movaps xmm6, [rsp]
000078eb87dd298d  add rsp, 0x30
000078eb87dd2991  vmovaps xmm0, [rsp]
000078eb87dd2996  vmovaps xmm1, [rsp+0x10]
000078eb87dd299c  vmovaps xmm2, [rsp+0x20]
000078eb87dd29a2  vmovaps xmm3, [rsp+0x30]
000078eb87dd29a8  vmovaps xmm4, [rsp+0x40]
000078eb87dd29ae  vmovaps xmm5, [rsp+0x50]
000078eb87dd29b4  vmovaps xmm7, [rsp+0x60]
000078eb87dd29ba  vmovaps xmm8, [rsp+0x70]
000078eb87dd29c0  vmovaps xmm9, [rsp+0x80]
000078eb87dd29c9  vmovaps xmm10, [rsp+0x90]
000078eb87dd29d2  vmovaps xmm11, [rsp+0xA0]
000078eb87dd29db  vmovaps xmm12, [rsp+0xB0]
000078eb87dd29e4  vmovaps xmm13, [rsp+0xC0]
000078eb87dd29ed  vmovaps xmm14, [rsp+0xD0]
000078eb87dd29f6  vmovaps xmm15, [rsp+0xE0]
000078eb87dd29ff  add rsp, 0xF0
000078eb87dd2a06  pop r11
000078eb87dd2a08  pop r10
000078eb87dd2a0a  pop r9
000078eb87dd2a0c  pop r8
000078eb87dd2a0e  pop rsi
000078eb87dd2a0f  pop rdi
000078eb87dd2a10  pop rdx
000078eb87dd2a11  pop rcx
000078eb87dd2a12  pop rax
000078eb87dd2a13  add rsp, 0x08
000078eb87dd2a17  jmp 0x000078EB87DCFD98
000078eb87dd2a1c  sub rsp, 0x08
000078eb87dd2a20  push rax
000078eb87dd2a21  push rcx
000078eb87dd2a22  push rdx
000078eb87dd2a23  push rdi
000078eb87dd2a24  push rsi
000078eb87dd2a25  push r8
000078eb87dd2a27  push r9
000078eb87dd2a29  push r10
000078eb87dd2a2b  push r11
000078eb87dd2a2d  sub rsp, 0xF0
000078eb87dd2a34  vmovaps [rsp], xmm0
000078eb87dd2a39  vmovaps [rsp+0x10], xmm2
000078eb87dd2a3f  vmovaps [rsp+0x20], xmm3
000078eb87dd2a45  vmovaps [rsp+0x30], xmm4
000078eb87dd2a4b  vmovaps [rsp+0x40], xmm5
000078eb87dd2a51  vmovaps [rsp+0x50], xmm6
000078eb87dd2a57  vmovaps [rsp+0x60], xmm7
000078eb87dd2a5d  vmovaps [rsp+0x70], xmm8
000078eb87dd2a63  vmovaps [rsp+0x80], xmm9
000078eb87dd2a6c  vmovaps [rsp+0x90], xmm10
000078eb87dd2a75  vmovaps [rsp+0xA0], xmm11
000078eb87dd2a7e  vmovaps [rsp+0xB0], xmm12
000078eb87dd2a87  vmovaps [rsp+0xC0], xmm13
000078eb87dd2a90  vmovaps [rsp+0xD0], xmm14
000078eb87dd2a99  vmovaps [rsp+0xE0], xmm15
000078eb87dd2aa2  sub rsp, 0x30
000078eb87dd2aa6  movaps [rsp], xmm1
000078eb87dd2aaa  movaps [rsp+0x10], xmm5
000078eb87dd2aaf  movaps [rsp+0x20], xmm13
000078eb87dd2ab5  lea rdi, [rsp]
000078eb87dd2ab9  mov esi, 0x00
000078eb87dd2abe  mov rax, 0x61D341A71530
000078eb87dd2ac8  call rax
000078eb87dd2aca  movaps xmm1, [rsp]
000078eb87dd2ace  add rsp, 0x30
000078eb87dd2ad2  vmovaps xmm0, [rsp]
000078eb87dd2ad7  vmovaps xmm2, [rsp+0x10]
000078eb87dd2add  vmovaps xmm3, [rsp+0x20]
000078eb87dd2ae3  vmovaps xmm4, [rsp+0x30]
000078eb87dd2ae9  vmovaps xmm5, [rsp+0x40]
000078eb87dd2aef  vmovaps xmm6, [rsp+0x50]
000078eb87dd2af5  vmovaps xmm7, [rsp+0x60]
000078eb87dd2afb  vmovaps xmm8, [rsp+0x70]
000078eb87dd2b01  vmovaps xmm9, [rsp+0x80]
000078eb87dd2b0a  vmovaps xmm10, [rsp+0x90]
000078eb87dd2b13  vmovaps xmm11, [rsp+0xA0]
000078eb87dd2b1c  vmovaps xmm12, [rsp+0xB0]
000078eb87dd2b25  vmovaps xmm13, [rsp+0xC0]
000078eb87dd2b2e  vmovaps xmm14, [rsp+0xD0]
000078eb87dd2b37  vmovaps xmm15, [rsp+0xE0]
000078eb87dd2b40  add rsp, 0xF0
000078eb87dd2b47  pop r11
000078eb87dd2b49  pop r10
000078eb87dd2b4b  pop r9
000078eb87dd2b4d  pop r8
000078eb87dd2b4f  pop rsi
000078eb87dd2b50  pop rdi
000078eb87dd2b51  pop rdx
000078eb87dd2b52  pop rcx
000078eb87dd2b53  pop rax
000078eb87dd2b54  add rsp, 0x08
000078eb87dd2b58  jmp 0x000078EB87DCFDB6
000078eb87dd2b5d  sub rsp, 0x08
000078eb87dd2b61  push rax
000078eb87dd2b62  push rcx
000078eb87dd2b63  push rdx
000078eb87dd2b64  push rdi
000078eb87dd2b65  push rsi
000078eb87dd2b66  push r8
000078eb87dd2b68  push r9
000078eb87dd2b6a  push r10
000078eb87dd2b6c  push r11
000078eb87dd2b6e  sub rsp, 0xF0
000078eb87dd2b75  vmovaps [rsp], xmm0
000078eb87dd2b7a  vmovaps [rsp+0x10], xmm1
000078eb87dd2b80  vmovaps [rsp+0x20], xmm2
000078eb87dd2b86  vmovaps [rsp+0x30], xmm3
000078eb87dd2b8c  vmovaps [rsp+0x40], xmm4
000078eb87dd2b92  vmovaps [rsp+0x50], xmm6
000078eb87dd2b98  vmovaps [rsp+0x60], xmm7
000078eb87dd2b9e  vmovaps [rsp+0x70], xmm8
000078eb87dd2ba4  vmovaps [rsp+0x80], xmm9
000078eb87dd2bad  vmovaps [rsp+0x90], xmm10
000078eb87dd2bb6  vmovaps [rsp+0xA0], xmm11
000078eb87dd2bbf  vmovaps [rsp+0xB0], xmm12
000078eb87dd2bc8  vmovaps [rsp+0xC0], xmm13
000078eb87dd2bd1  vmovaps [rsp+0xD0], xmm14
000078eb87dd2bda  vmovaps [rsp+0xE0], xmm15
000078eb87dd2be3  sub rsp, 0x30
000078eb87dd2be7  movaps [rsp], xmm5
000078eb87dd2beb  movaps [rsp+0x10], xmm2
000078eb87dd2bf0  movaps [rsp+0x20], xmm13
000078eb87dd2bf6  lea rdi, [rsp]
000078eb87dd2bfa  mov esi, 0x00
000078eb87dd2bff  mov rax, 0x61D341A71530
000078eb87dd2c09  call rax
000078eb87dd2c0b  movaps xmm5, [rsp]
000078eb87dd2c0f  add rsp, 0x30
000078eb87dd2c13  vmovaps xmm0, [rsp]
000078eb87dd2c18  vmovaps xmm1, [rsp+0x10]
000078eb87dd2c1e  vmovaps xmm2, [rsp+0x20]
000078eb87dd2c24  vmovaps xmm3, [rsp+0x30]
000078eb87dd2c2a  vmovaps xmm4, [rsp+0x40]
000078eb87dd2c30  vmovaps xmm6, [rsp+0x50]
000078eb87dd2c36  vmovaps xmm7, [rsp+0x60]
000078eb87dd2c3c  vmovaps xmm8, [rsp+0x70]
000078eb87dd2c42  vmovaps xmm9, [rsp+0x80]
000078eb87dd2c4b  vmovaps xmm10, [rsp+0x90]
000078eb87dd2c54  vmovaps xmm11, [rsp+0xA0]
000078eb87dd2c5d  vmovaps xmm12, [rsp+0xB0]
000078eb87dd2c66  vmovaps xmm13, [rsp+0xC0]
000078eb87dd2c6f  vmovaps xmm14, [rsp+0xD0]
000078eb87dd2c78  vmovaps xmm15, [rsp+0xE0]
000078eb87dd2c81  add rsp, 0xF0
000078eb87dd2c88  pop r11
000078eb87dd2c8a  pop r10
000078eb87dd2c8c  pop r9
000078eb87dd2c8e  pop r8
000078eb87dd2c90  pop rsi
000078eb87dd2c91  pop rdi
000078eb87dd2c92  pop rdx
000078eb87dd2c93  pop rcx
000078eb87dd2c94  pop rax
000078eb87dd2c95  add rsp, 0x08
000078eb87dd2c99  jmp 0x000078EB87DCFDEC
000078eb87dd2c9e  sub rsp, 0x08
000078eb87dd2ca2  push rax
000078eb87dd2ca3  push rcx
000078eb87dd2ca4  push rdx
000078eb87dd2ca5  push rdi
000078eb87dd2ca6  push rsi
000078eb87dd2ca7  push r8
000078eb87dd2ca9  push r9
000078eb87dd2cab  push r10
000078eb87dd2cad  push r11
000078eb87dd2caf  sub rsp, 0xF0
000078eb87dd2cb6  vmovaps [rsp], xmm0
000078eb87dd2cbb  vmovaps [rsp+0x10], xmm1
000078eb87dd2cc1  vmovaps [rsp+0x20], xmm2
000078eb87dd2cc7  vmovaps [rsp+0x30], xmm3
000078eb87dd2ccd  vmovaps [rsp+0x40], xmm4
000078eb87dd2cd3  vmovaps [rsp+0x50], xmm5
000078eb87dd2cd9  vmovaps [rsp+0x60], xmm6
000078eb87dd2cdf  vmovaps [rsp+0x70], xmm7
000078eb87dd2ce5  vmovaps [rsp+0x80], xmm8
000078eb87dd2cee  vmovaps [rsp+0x90], xmm9
000078eb87dd2cf7  vmovaps [rsp+0xA0], xmm10
000078eb87dd2d00  vmovaps [rsp+0xB0], xmm11
000078eb87dd2d09  vmovaps [rsp+0xC0], xmm12
000078eb87dd2d12  vmovaps [rsp+0xD0], xmm14
000078eb87dd2d1b  vmovaps [rsp+0xE0], xmm15
000078eb87dd2d24  sub rsp, 0x30
000078eb87dd2d28  movaps [rsp], xmm13
000078eb87dd2d2d  movaps [rsp+0x10], xmm10
000078eb87dd2d33  movaps [rsp+0x20], xmm1
000078eb87dd2d38  lea rdi, [rsp]
000078eb87dd2d3c  mov esi, 0x00
000078eb87dd2d41  mov rax, 0x61D341A71530
000078eb87dd2d4b  call rax
000078eb87dd2d4d  movaps xmm13, [rsp]
000078eb87dd2d52  add rsp, 0x30
000078eb87dd2d56  vmovaps xmm0, [rsp]
000078eb87dd2d5b  vmovaps xmm1, [rsp+0x10]
000078eb87dd2d61  vmovaps xmm2, [rsp+0x20]
000078eb87dd2d67  vmovaps xmm3, [rsp+0x30]
000078eb87dd2d6d  vmovaps xmm4, [rsp+0x40]
000078eb87dd2d73  vmovaps xmm5, [rsp+0x50]
000078eb87dd2d79  vmovaps xmm6, [rsp+0x60]
000078eb87dd2d7f  vmovaps xmm7, [rsp+0x70]
000078eb87dd2d85  vmovaps xmm8, [rsp+0x80]
000078eb87dd2d8e  vmovaps xmm9, [rsp+0x90]
000078eb87dd2d97  vmovaps xmm10, [rsp+0xA0]
000078eb87dd2da0  vmovaps xmm11, [rsp+0xB0]
000078eb87dd2da9  vmovaps xmm12, [rsp+0xC0]
000078eb87dd2db2  vmovaps xmm14, [rsp+0xD0]
000078eb87dd2dbb  vmovaps xmm15, [rsp+0xE0]
000078eb87dd2dc4  add rsp, 0xF0
000078eb87dd2dcb  pop r11
000078eb87dd2dcd  pop r10
000078eb87dd2dcf  pop r9
000078eb87dd2dd1  pop r8
000078eb87dd2dd3  pop rsi
000078eb87dd2dd4  pop rdi
000078eb87dd2dd5  pop rdx
000078eb87dd2dd6  pop rcx
000078eb87dd2dd7  pop rax
000078eb87dd2dd8  add rsp, 0x08
000078eb87dd2ddc  jmp 0x000078EB87DCFE15
000078eb87dd2de1  sub rsp, 0x08
000078eb87dd2de5  push rax
000078eb87dd2de6  push rcx
000078eb87dd2de7  push rdx
000078eb87dd2de8  push rdi
000078eb87dd2de9  push rsi
000078eb87dd2dea  push r8
000078eb87dd2dec  push r9
000078eb87dd2dee  push r10
000078eb87dd2df0  push r11
000078eb87dd2df2  sub rsp, 0xF0
000078eb87dd2df9  vmovaps [rsp], xmm0
000078eb87dd2dfe  vmovaps [rsp+0x10], xmm2
000078eb87dd2e04  vmovaps [rsp+0x20], xmm3
000078eb87dd2e0a  vmovaps [rsp+0x30], xmm4
000078eb87dd2e10  vmovaps [rsp+0x40], xmm5
000078eb87dd2e16  vmovaps [rsp+0x50], xmm6
000078eb87dd2e1c  vmovaps [rsp+0x60], xmm7
000078eb87dd2e22  vmovaps [rsp+0x70], xmm8
000078eb87dd2e28  vmovaps [rsp+0x80], xmm9
000078eb87dd2e31  vmovaps [rsp+0x90], xmm10
000078eb87dd2e3a  vmovaps [rsp+0xA0], xmm11
000078eb87dd2e43  vmovaps [rsp+0xB0], xmm12
000078eb87dd2e4c  vmovaps [rsp+0xC0], xmm13
000078eb87dd2e55  vmovaps [rsp+0xD0], xmm14
000078eb87dd2e5e  vmovaps [rsp+0xE0], xmm15
000078eb87dd2e67  sub rsp, 0x30
000078eb87dd2e6b  movaps [rsp], xmm1
000078eb87dd2e6f  movaps [rsp+0x10], xmm15
000078eb87dd2e75  movaps [rsp+0x20], xmm10
000078eb87dd2e7b  lea rdi, [rsp]
000078eb87dd2e7f  mov esi, 0x00
000078eb87dd2e84  mov rax, 0x61D341A71530
000078eb87dd2e8e  call rax
000078eb87dd2e90  movaps xmm1, [rsp]
000078eb87dd2e94  add rsp, 0x30
000078eb87dd2e98  vmovaps xmm0, [rsp]
000078eb87dd2e9d  vmovaps xmm2, [rsp+0x10]
000078eb87dd2ea3  vmovaps xmm3, [rsp+0x20]
000078eb87dd2ea9  vmovaps xmm4, [rsp+0x30]
000078eb87dd2eaf  vmovaps xmm5, [rsp+0x40]
000078eb87dd2eb5  vmovaps xmm6, [rsp+0x50]
000078eb87dd2ebb  vmovaps xmm7, [rsp+0x60]
000078eb87dd2ec1  vmovaps xmm8, [rsp+0x70]
000078eb87dd2ec7  vmovaps xmm9, [rsp+0x80]
000078eb87dd2ed0  vmovaps xmm10, [rsp+0x90]
000078eb87dd2ed9  vmovaps xmm11, [rsp+0xA0]
000078eb87dd2ee2  vmovaps xmm12, [rsp+0xB0]
000078eb87dd2eeb  vmovaps xmm13, [rsp+0xC0]
000078eb87dd2ef4  vmovaps xmm14, [rsp+0xD0]
000078eb87dd2efd  vmovaps xmm15, [rsp+0xE0]
000078eb87dd2f06  add rsp, 0xF0
000078eb87dd2f0d  pop r11
000078eb87dd2f0f  pop r10
000078eb87dd2f11  pop r9
000078eb87dd2f13  pop r8
000078eb87dd2f15  pop rsi
000078eb87dd2f16  pop rdi
000078eb87dd2f17  pop rdx
000078eb87dd2f18  pop rcx
000078eb87dd2f19  pop rax
000078eb87dd2f1a  add rsp, 0x08
000078eb87dd2f1e  jmp 0x000078EB87DCFE34
000078eb87dd2f23  sub rsp, 0x08
000078eb87dd2f27  push rax
000078eb87dd2f28  push rcx
000078eb87dd2f29  push rdx
000078eb87dd2f2a  push rdi
000078eb87dd2f2b  push rsi
000078eb87dd2f2c  push r8
000078eb87dd2f2e  push r9
000078eb87dd2f30  push r10
000078eb87dd2f32  push r11
000078eb87dd2f34  sub rsp, 0xF0
000078eb87dd2f3b  vmovaps [rsp], xmm0
000078eb87dd2f40  vmovaps [rsp+0x10], xmm1
000078eb87dd2f46  vmovaps [rsp+0x20], xmm2
000078eb87dd2f4c  vmovaps [rsp+0x30], xmm3
000078eb87dd2f52  vmovaps [rsp+0x40], xmm4
000078eb87dd2f58  vmovaps [rsp+0x50], xmm5
000078eb87dd2f5e  vmovaps [rsp+0x60], xmm6
000078eb87dd2f64  vmovaps [rsp+0x70], xmm7
000078eb87dd2f6a  vmovaps [rsp+0x80], xmm8
000078eb87dd2f73  vmovaps [rsp+0x90], xmm9
000078eb87dd2f7c  vmovaps [rsp+0xA0], xmm10
000078eb87dd2f85  vmovaps [rsp+0xB0], xmm11
000078eb87dd2f8e  vmovaps [rsp+0xC0], xmm12
000078eb87dd2f97  vmovaps [rsp+0xD0], xmm13
000078eb87dd2fa0  vmovaps [rsp+0xE0], xmm14
000078eb87dd2fa9  sub rsp, 0x30
000078eb87dd2fad  movaps [rsp], xmm15
000078eb87dd2fb2  movaps [rsp+0x10], xmm10
000078eb87dd2fb8  movaps [rsp+0x20], xmm11
000078eb87dd2fbe  lea rdi, [rsp]
000078eb87dd2fc2  mov esi, 0x00
000078eb87dd2fc7  mov rax, 0x61D341A71530
000078eb87dd2fd1  call rax
000078eb87dd2fd3  movaps xmm15, [rsp]
000078eb87dd2fd8  add rsp, 0x30
000078eb87dd2fdc  vmovaps xmm0, [rsp]
000078eb87dd2fe1  vmovaps xmm1, [rsp+0x10]
000078eb87dd2fe7  vmovaps xmm2, [rsp+0x20]
000078eb87dd2fed  vmovaps xmm3, [rsp+0x30]
000078eb87dd2ff3  vmovaps xmm4, [rsp+0x40]
000078eb87dd2ff9  vmovaps xmm5, [rsp+0x50]
000078eb87dd2fff  vmovaps xmm6, [rsp+0x60]
000078eb87dd3005  vmovaps xmm7, [rsp+0x70]
000078eb87dd300b  vmovaps xmm8, [rsp+0x80]
000078eb87dd3014  vmovaps xmm9, [rsp+0x90]
000078eb87dd301d  vmovaps xmm10, [rsp+0xA0]
000078eb87dd3026  vmovaps xmm11, [rsp+0xB0]
000078eb87dd302f  vmovaps xmm12, [rsp+0xC0]
000078eb87dd3038  vmovaps xmm13, [rsp+0xD0]
000078eb87dd3041  vmovaps xmm14, [rsp+0xE0]
000078eb87dd304a  add rsp, 0xF0
000078eb87dd3051  pop r11
000078eb87dd3053  pop r10
000078eb87dd3055  pop r9
000078eb87dd3057  pop r8
000078eb87dd3059  pop rsi
000078eb87dd305a  pop rdi
000078eb87dd305b  pop rdx
000078eb87dd305c  pop rcx
000078eb87dd305d  pop rax
000078eb87dd305e  add rsp, 0x08
000078eb87dd3062  jmp 0x000078EB87DCFE57
000078eb87dd3067  sub rsp, 0x08
000078eb87dd306b  push rax
000078eb87dd306c  push rcx
000078eb87dd306d  push rdx
000078eb87dd306e  push rdi
000078eb87dd306f  push rsi
000078eb87dd3070  push r8
000078eb87dd3072  push r9
000078eb87dd3074  push r10
000078eb87dd3076  push r11
000078eb87dd3078  sub rsp, 0xF0
000078eb87dd307f  vmovaps [rsp], xmm0
000078eb87dd3084  vmovaps [rsp+0x10], xmm1
000078eb87dd308a  vmovaps [rsp+0x20], xmm2
000078eb87dd3090  vmovaps [rsp+0x30], xmm3
000078eb87dd3096  vmovaps [rsp+0x40], xmm4
000078eb87dd309c  vmovaps [rsp+0x50], xmm5
000078eb87dd30a2  vmovaps [rsp+0x60], xmm6
000078eb87dd30a8  vmovaps [rsp+0x70], xmm7
000078eb87dd30ae  vmovaps [rsp+0x80], xmm8
000078eb87dd30b7  vmovaps [rsp+0x90], xmm9
000078eb87dd30c0  vmovaps [rsp+0xA0], xmm11
000078eb87dd30c9  vmovaps [rsp+0xB0], xmm12
000078eb87dd30d2  vmovaps [rsp+0xC0], xmm13
000078eb87dd30db  vmovaps [rsp+0xD0], xmm14
000078eb87dd30e4  vmovaps [rsp+0xE0], xmm15
000078eb87dd30ed  sub rsp, 0x30
000078eb87dd30f1  movaps [rsp], xmm10
000078eb87dd30f6  movaps [rsp+0x10], xmm12
000078eb87dd30fc  movaps [rsp+0x20], xmm11
000078eb87dd3102  lea rdi, [rsp]
000078eb87dd3106  mov esi, 0x00
000078eb87dd310b  mov rax, 0x61D341A71530
000078eb87dd3115  call rax
000078eb87dd3117  movaps xmm10, [rsp]
000078eb87dd311c  add rsp, 0x30
000078eb87dd3120  vmovaps xmm0, [rsp]
000078eb87dd3125  vmovaps xmm1, [rsp+0x10]
000078eb87dd312b  vmovaps xmm2, [rsp+0x20]
000078eb87dd3131  vmovaps xmm3, [rsp+0x30]
000078eb87dd3137  vmovaps xmm4, [rsp+0x40]
000078eb87dd313d  vmovaps xmm5, [rsp+0x50]
000078eb87dd3143  vmovaps xmm6, [rsp+0x60]
000078eb87dd3149  vmovaps xmm7, [rsp+0x70]
000078eb87dd314f  vmovaps xmm8, [rsp+0x80]
000078eb87dd3158  vmovaps xmm9, [rsp+0x90]
000078eb87dd3161  vmovaps xmm11, [rsp+0xA0]
000078eb87dd316a  vmovaps xmm12, [rsp+0xB0]
000078eb87dd3173  vmovaps xmm13, [rsp+0xC0]
000078eb87dd317c  vmovaps xmm14, [rsp+0xD0]
000078eb87dd3185  vmovaps xmm15, [rsp+0xE0]
000078eb87dd318e  add rsp, 0xF0
000078eb87dd3195  pop r11
000078eb87dd3197  pop r10
000078eb87dd3199  pop r9
000078eb87dd319b  pop r8
000078eb87dd319d  pop rsi
000078eb87dd319e  pop rdi
000078eb87dd319f  pop rdx
000078eb87dd31a0  pop rcx
000078eb87dd31a1  pop rax
000078eb87dd31a2  add rsp, 0x08
000078eb87dd31a6  jmp 0x000078EB87DCFE80
000078eb87dd31ab  sub rsp, 0x08
000078eb87dd31af  push rax
000078eb87dd31b0  push rcx
000078eb87dd31b1  push rdx
000078eb87dd31b2  push rdi
000078eb87dd31b3  push rsi
000078eb87dd31b4  push r8
000078eb87dd31b6  push r9
000078eb87dd31b8  push r10
000078eb87dd31ba  push r11
000078eb87dd31bc  sub rsp, 0xF0
000078eb87dd31c3  vmovaps [rsp], xmm0
000078eb87dd31c8  vmovaps [rsp+0x10], xmm1
000078eb87dd31ce  vmovaps [rsp+0x20], xmm2
000078eb87dd31d4  vmovaps [rsp+0x30], xmm3
000078eb87dd31da  vmovaps [rsp+0x40], xmm4
000078eb87dd31e0  vmovaps [rsp+0x50], xmm5
000078eb87dd31e6  vmovaps [rsp+0x60], xmm6
000078eb87dd31ec  vmovaps [rsp+0x70], xmm7
000078eb87dd31f2  vmovaps [rsp+0x80], xmm8
000078eb87dd31fb  vmovaps [rsp+0x90], xmm9
000078eb87dd3204  vmovaps [rsp+0xA0], xmm10
000078eb87dd320d  vmovaps [rsp+0xB0], xmm12
000078eb87dd3216  vmovaps [rsp+0xC0], xmm13
000078eb87dd321f  vmovaps [rsp+0xD0], xmm14
000078eb87dd3228  vmovaps [rsp+0xE0], xmm15
000078eb87dd3231  sub rsp, 0x30
000078eb87dd3235  movaps [rsp], xmm11
000078eb87dd323a  movaps [rsp+0x10], xmm2
000078eb87dd323f  movaps [rsp+0x20], xmm12
000078eb87dd3245  lea rdi, [rsp]
000078eb87dd3249  mov esi, 0x00
000078eb87dd324e  mov rax, 0x61D341A71530
000078eb87dd3258  call rax
000078eb87dd325a  movaps xmm11, [rsp]
000078eb87dd325f  add rsp, 0x30
000078eb87dd3263  vmovaps xmm0, [rsp]
000078eb87dd3268  vmovaps xmm1, [rsp+0x10]
000078eb87dd326e  vmovaps xmm2, [rsp+0x20]
000078eb87dd3274  vmovaps xmm3, [rsp+0x30]
000078eb87dd327a  vmovaps xmm4, [rsp+0x40]
000078eb87dd3280  vmovaps xmm5, [rsp+0x50]
000078eb87dd3286  vmovaps xmm6, [rsp+0x60]
000078eb87dd328c  vmovaps xmm7, [rsp+0x70]
000078eb87dd3292  vmovaps xmm8, [rsp+0x80]
000078eb87dd329b  vmovaps xmm9, [rsp+0x90]
000078eb87dd32a4  vmovaps xmm10, [rsp+0xA0]
000078eb87dd32ad  vmovaps xmm12, [rsp+0xB0]
000078eb87dd32b6  vmovaps xmm13, [rsp+0xC0]
000078eb87dd32bf  vmovaps xmm14, [rsp+0xD0]
000078eb87dd32c8  vmovaps xmm15, [rsp+0xE0]
000078eb87dd32d1  add rsp, 0xF0
000078eb87dd32d8  pop r11
000078eb87dd32da  pop r10
000078eb87dd32dc  pop r9
000078eb87dd32de  pop r8
000078eb87dd32e0  pop rsi
000078eb87dd32e1  pop rdi
000078eb87dd32e2  pop rdx
000078eb87dd32e3  pop rcx
000078eb87dd32e4  pop rax
000078eb87dd32e5  add rsp, 0x08
000078eb87dd32e9  jmp 0x000078EB87DCFEB8
000078eb87dd32ee  sub rsp, 0x08
000078eb87dd32f2  push rax
000078eb87dd32f3  push rcx
000078eb87dd32f4  push rdx
000078eb87dd32f5  push rdi
000078eb87dd32f6  push rsi
000078eb87dd32f7  push r8
000078eb87dd32f9  push r9
000078eb87dd32fb  push r10
000078eb87dd32fd  push r11
000078eb87dd32ff  sub rsp, 0xF0
000078eb87dd3306  vmovaps [rsp], xmm0
000078eb87dd330b  vmovaps [rsp+0x10], xmm2
000078eb87dd3311  vmovaps [rsp+0x20], xmm3
000078eb87dd3317  vmovaps [rsp+0x30], xmm4
000078eb87dd331d  vmovaps [rsp+0x40], xmm5
000078eb87dd3323  vmovaps [rsp+0x50], xmm6
000078eb87dd3329  vmovaps [rsp+0x60], xmm7
000078eb87dd332f  vmovaps [rsp+0x70], xmm8
000078eb87dd3335  vmovaps [rsp+0x80], xmm9
000078eb87dd333e  vmovaps [rsp+0x90], xmm10
000078eb87dd3347  vmovaps [rsp+0xA0], xmm11
000078eb87dd3350  vmovaps [rsp+0xB0], xmm12
000078eb87dd3359  vmovaps [rsp+0xC0], xmm13
000078eb87dd3362  vmovaps [rsp+0xD0], xmm14
000078eb87dd336b  vmovaps [rsp+0xE0], xmm15
000078eb87dd3374  sub rsp, 0x30
000078eb87dd3378  movaps [rsp], xmm1
000078eb87dd337c  movaps [rsp+0x10], xmm14
000078eb87dd3382  movaps [rsp+0x20], xmm6
000078eb87dd3387  lea rdi, [rsp]
000078eb87dd338b  mov esi, 0x00
000078eb87dd3390  mov rax, 0x61D341A71530
000078eb87dd339a  call rax
000078eb87dd339c  movaps xmm1, [rsp]
000078eb87dd33a0  add rsp, 0x30
000078eb87dd33a4  vmovaps xmm0, [rsp]
000078eb87dd33a9  vmovaps xmm2, [rsp+0x10]
000078eb87dd33af  vmovaps xmm3, [rsp+0x20]
000078eb87dd33b5  vmovaps xmm4, [rsp+0x30]
000078eb87dd33bb  vmovaps xmm5, [rsp+0x40]
000078eb87dd33c1  vmovaps xmm6, [rsp+0x50]
000078eb87dd33c7  vmovaps xmm7, [rsp+0x60]
000078eb87dd33cd  vmovaps xmm8, [rsp+0x70]
000078eb87dd33d3  vmovaps xmm9, [rsp+0x80]
000078eb87dd33dc  vmovaps xmm10, [rsp+0x90]
000078eb87dd33e5  vmovaps xmm11, [rsp+0xA0]
000078eb87dd33ee  vmovaps xmm12, [rsp+0xB0]
000078eb87dd33f7  vmovaps xmm13, [rsp+0xC0]
000078eb87dd3400  vmovaps xmm14, [rsp+0xD0]
000078eb87dd3409  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3412  add rsp, 0xF0
000078eb87dd3419  pop r11
000078eb87dd341b  pop r10
000078eb87dd341d  pop r9
000078eb87dd341f  pop r8
000078eb87dd3421  pop rsi
000078eb87dd3422  pop rdi
000078eb87dd3423  pop rdx
000078eb87dd3424  pop rcx
000078eb87dd3425  pop rax
000078eb87dd3426  add rsp, 0x08
000078eb87dd342a  jmp 0x000078EB87DCFED1
000078eb87dd342f  sub rsp, 0x08
000078eb87dd3433  push rax
000078eb87dd3434  push rcx
000078eb87dd3435  push rdx
000078eb87dd3436  push rdi
000078eb87dd3437  push rsi
000078eb87dd3438  push r8
000078eb87dd343a  push r9
000078eb87dd343c  push r10
000078eb87dd343e  push r11
000078eb87dd3440  sub rsp, 0xF0
000078eb87dd3447  vmovaps [rsp], xmm0
000078eb87dd344c  vmovaps [rsp+0x10], xmm1
000078eb87dd3452  vmovaps [rsp+0x20], xmm2
000078eb87dd3458  vmovaps [rsp+0x30], xmm3
000078eb87dd345e  vmovaps [rsp+0x40], xmm4
000078eb87dd3464  vmovaps [rsp+0x50], xmm5
000078eb87dd346a  vmovaps [rsp+0x60], xmm6
000078eb87dd3470  vmovaps [rsp+0x70], xmm7
000078eb87dd3476  vmovaps [rsp+0x80], xmm8
000078eb87dd347f  vmovaps [rsp+0x90], xmm9
000078eb87dd3488  vmovaps [rsp+0xA0], xmm10
000078eb87dd3491  vmovaps [rsp+0xB0], xmm11
000078eb87dd349a  vmovaps [rsp+0xC0], xmm12
000078eb87dd34a3  vmovaps [rsp+0xD0], xmm13
000078eb87dd34ac  vmovaps [rsp+0xE0], xmm15
000078eb87dd34b5  sub rsp, 0x30
000078eb87dd34b9  movaps [rsp], xmm14
000078eb87dd34be  movaps [rsp+0x10], xmm12
000078eb87dd34c4  movaps [rsp+0x20], xmm5
000078eb87dd34c9  lea rdi, [rsp]
000078eb87dd34cd  mov esi, 0x00
000078eb87dd34d2  mov rax, 0x61D341A71530
000078eb87dd34dc  call rax
000078eb87dd34de  movaps xmm14, [rsp]
000078eb87dd34e3  add rsp, 0x30
000078eb87dd34e7  vmovaps xmm0, [rsp]
000078eb87dd34ec  vmovaps xmm1, [rsp+0x10]
000078eb87dd34f2  vmovaps xmm2, [rsp+0x20]
000078eb87dd34f8  vmovaps xmm3, [rsp+0x30]
000078eb87dd34fe  vmovaps xmm4, [rsp+0x40]
000078eb87dd3504  vmovaps xmm5, [rsp+0x50]
000078eb87dd350a  vmovaps xmm6, [rsp+0x60]
000078eb87dd3510  vmovaps xmm7, [rsp+0x70]
000078eb87dd3516  vmovaps xmm8, [rsp+0x80]
000078eb87dd351f  vmovaps xmm9, [rsp+0x90]
000078eb87dd3528  vmovaps xmm10, [rsp+0xA0]
000078eb87dd3531  vmovaps xmm11, [rsp+0xB0]
000078eb87dd353a  vmovaps xmm12, [rsp+0xC0]
000078eb87dd3543  vmovaps xmm13, [rsp+0xD0]
000078eb87dd354c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3555  add rsp, 0xF0
000078eb87dd355c  pop r11
000078eb87dd355e  pop r10
000078eb87dd3560  pop r9
000078eb87dd3562  pop r8
000078eb87dd3564  pop rsi
000078eb87dd3565  pop rdi
000078eb87dd3566  pop rdx
000078eb87dd3567  pop rcx
000078eb87dd3568  pop rax
000078eb87dd3569  add rsp, 0x08
000078eb87dd356d  jmp 0x000078EB87DCFEF1
000078eb87dd3572  sub rsp, 0x08
000078eb87dd3576  push rax
000078eb87dd3577  push rcx
000078eb87dd3578  push rdx
000078eb87dd3579  push rdi
000078eb87dd357a  push rsi
000078eb87dd357b  push r8
000078eb87dd357d  push r9
000078eb87dd357f  push r10
000078eb87dd3581  push r11
000078eb87dd3583  sub rsp, 0xF0
000078eb87dd358a  vmovaps [rsp], xmm0
000078eb87dd358f  vmovaps [rsp+0x10], xmm1
000078eb87dd3595  vmovaps [rsp+0x20], xmm2
000078eb87dd359b  vmovaps [rsp+0x30], xmm3
000078eb87dd35a1  vmovaps [rsp+0x40], xmm4
000078eb87dd35a7  vmovaps [rsp+0x50], xmm5
000078eb87dd35ad  vmovaps [rsp+0x60], xmm7
000078eb87dd35b3  vmovaps [rsp+0x70], xmm8
000078eb87dd35b9  vmovaps [rsp+0x80], xmm9
000078eb87dd35c2  vmovaps [rsp+0x90], xmm10
000078eb87dd35cb  vmovaps [rsp+0xA0], xmm11
000078eb87dd35d4  vmovaps [rsp+0xB0], xmm12
000078eb87dd35dd  vmovaps [rsp+0xC0], xmm13
000078eb87dd35e6  vmovaps [rsp+0xD0], xmm14
000078eb87dd35ef  vmovaps [rsp+0xE0], xmm15
000078eb87dd35f8  sub rsp, 0x30
000078eb87dd35fc  movaps [rsp], xmm6
000078eb87dd3600  movaps [rsp+0x10], xmm9
000078eb87dd3606  movaps [rsp+0x20], xmm12
000078eb87dd360c  lea rdi, [rsp]
000078eb87dd3610  mov esi, 0x00
000078eb87dd3615  mov rax, 0x61D341A71530
000078eb87dd361f  call rax
000078eb87dd3621  movaps xmm6, [rsp]
000078eb87dd3625  add rsp, 0x30
000078eb87dd3629  vmovaps xmm0, [rsp]
000078eb87dd362e  vmovaps xmm1, [rsp+0x10]
000078eb87dd3634  vmovaps xmm2, [rsp+0x20]
000078eb87dd363a  vmovaps xmm3, [rsp+0x30]
000078eb87dd3640  vmovaps xmm4, [rsp+0x40]
000078eb87dd3646  vmovaps xmm5, [rsp+0x50]
000078eb87dd364c  vmovaps xmm7, [rsp+0x60]
000078eb87dd3652  vmovaps xmm8, [rsp+0x70]
000078eb87dd3658  vmovaps xmm9, [rsp+0x80]
000078eb87dd3661  vmovaps xmm10, [rsp+0x90]
000078eb87dd366a  vmovaps xmm11, [rsp+0xA0]
000078eb87dd3673  vmovaps xmm12, [rsp+0xB0]
000078eb87dd367c  vmovaps xmm13, [rsp+0xC0]
000078eb87dd3685  vmovaps xmm14, [rsp+0xD0]
000078eb87dd368e  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3697  add rsp, 0xF0
000078eb87dd369e  pop r11
000078eb87dd36a0  pop r10
000078eb87dd36a2  pop r9
000078eb87dd36a4  pop r8
000078eb87dd36a6  pop rsi
000078eb87dd36a7  pop rdi
000078eb87dd36a8  pop rdx
000078eb87dd36a9  pop rcx
000078eb87dd36aa  pop rax
000078eb87dd36ab  add rsp, 0x08
000078eb87dd36af  jmp 0x000078EB87DCFF19
000078eb87dd36b4  sub rsp, 0x08
000078eb87dd36b8  push rax
000078eb87dd36b9  push rcx
000078eb87dd36ba  push rdx
000078eb87dd36bb  push rdi
000078eb87dd36bc  push rsi
000078eb87dd36bd  push r8
000078eb87dd36bf  push r9
000078eb87dd36c1  push r10
000078eb87dd36c3  push r11
000078eb87dd36c5  sub rsp, 0xF0
000078eb87dd36cc  vmovaps [rsp], xmm0
000078eb87dd36d1  vmovaps [rsp+0x10], xmm1
000078eb87dd36d7  vmovaps [rsp+0x20], xmm2
000078eb87dd36dd  vmovaps [rsp+0x30], xmm3
000078eb87dd36e3  vmovaps [rsp+0x40], xmm4
000078eb87dd36e9  vmovaps [rsp+0x50], xmm5
000078eb87dd36ef  vmovaps [rsp+0x60], xmm6
000078eb87dd36f5  vmovaps [rsp+0x70], xmm7
000078eb87dd36fb  vmovaps [rsp+0x80], xmm8
000078eb87dd3704  vmovaps [rsp+0x90], xmm9
000078eb87dd370d  vmovaps [rsp+0xA0], xmm10
000078eb87dd3716  vmovaps [rsp+0xB0], xmm11
000078eb87dd371f  vmovaps [rsp+0xC0], xmm13
000078eb87dd3728  vmovaps [rsp+0xD0], xmm14
000078eb87dd3731  vmovaps [rsp+0xE0], xmm15
000078eb87dd373a  sub rsp, 0x30
000078eb87dd373e  movaps [rsp], xmm12
000078eb87dd3743  movaps [rsp+0x10], xmm15
000078eb87dd3749  movaps [rsp+0x20], xmm13
000078eb87dd374f  lea rdi, [rsp]
000078eb87dd3753  mov esi, 0x00
000078eb87dd3758  mov rax, 0x61D341A71530
000078eb87dd3762  call rax
000078eb87dd3764  movaps xmm12, [rsp]
000078eb87dd3769  add rsp, 0x30
000078eb87dd376d  vmovaps xmm0, [rsp]
000078eb87dd3772  vmovaps xmm1, [rsp+0x10]
000078eb87dd3778  vmovaps xmm2, [rsp+0x20]
000078eb87dd377e  vmovaps xmm3, [rsp+0x30]
000078eb87dd3784  vmovaps xmm4, [rsp+0x40]
000078eb87dd378a  vmovaps xmm5, [rsp+0x50]
000078eb87dd3790  vmovaps xmm6, [rsp+0x60]
000078eb87dd3796  vmovaps xmm7, [rsp+0x70]
000078eb87dd379c  vmovaps xmm8, [rsp+0x80]
000078eb87dd37a5  vmovaps xmm9, [rsp+0x90]
000078eb87dd37ae  vmovaps xmm10, [rsp+0xA0]
000078eb87dd37b7  vmovaps xmm11, [rsp+0xB0]
000078eb87dd37c0  vmovaps xmm13, [rsp+0xC0]
000078eb87dd37c9  vmovaps xmm14, [rsp+0xD0]
000078eb87dd37d2  vmovaps xmm15, [rsp+0xE0]
000078eb87dd37db  add rsp, 0xF0
000078eb87dd37e2  pop r11
000078eb87dd37e4  pop r10
000078eb87dd37e6  pop r9
000078eb87dd37e8  pop r8
000078eb87dd37ea  pop rsi
000078eb87dd37eb  pop rdi
000078eb87dd37ec  pop rdx
000078eb87dd37ed  pop rcx
000078eb87dd37ee  pop rax
000078eb87dd37ef  add rsp, 0x08
000078eb87dd37f3  jmp 0x000078EB87DCFF34
000078eb87dd37f8  sub rsp, 0x08
000078eb87dd37fc  push rax
000078eb87dd37fd  push rcx
000078eb87dd37fe  push rdx
000078eb87dd37ff  push rdi
000078eb87dd3800  push rsi
000078eb87dd3801  push r8
000078eb87dd3803  push r9
000078eb87dd3805  push r10
000078eb87dd3807  push r11
000078eb87dd3809  sub rsp, 0xF0
000078eb87dd3810  vmovaps [rsp], xmm0
000078eb87dd3815  vmovaps [rsp+0x10], xmm1
000078eb87dd381b  vmovaps [rsp+0x20], xmm2
000078eb87dd3821  vmovaps [rsp+0x30], xmm3
000078eb87dd3827  vmovaps [rsp+0x40], xmm4
000078eb87dd382d  vmovaps [rsp+0x50], xmm5
000078eb87dd3833  vmovaps [rsp+0x60], xmm6
000078eb87dd3839  vmovaps [rsp+0x70], xmm7
000078eb87dd383f  vmovaps [rsp+0x80], xmm8
000078eb87dd3848  vmovaps [rsp+0x90], xmm9
000078eb87dd3851  vmovaps [rsp+0xA0], xmm10
000078eb87dd385a  vmovaps [rsp+0xB0], xmm11
000078eb87dd3863  vmovaps [rsp+0xC0], xmm12
000078eb87dd386c  vmovaps [rsp+0xD0], xmm13
000078eb87dd3875  vmovaps [rsp+0xE0], xmm14
000078eb87dd387e  sub rsp, 0x30
000078eb87dd3882  movaps [rsp], xmm15
000078eb87dd3887  movaps [rsp+0x10], xmm13
000078eb87dd388d  movaps [rsp+0x20], xmm10
000078eb87dd3893  lea rdi, [rsp]
000078eb87dd3897  mov esi, 0x00
000078eb87dd389c  mov rax, 0x61D341A71530
000078eb87dd38a6  call rax
000078eb87dd38a8  movaps xmm15, [rsp]
000078eb87dd38ad  add rsp, 0x30
000078eb87dd38b1  vmovaps xmm0, [rsp]
000078eb87dd38b6  vmovaps xmm1, [rsp+0x10]
000078eb87dd38bc  vmovaps xmm2, [rsp+0x20]
000078eb87dd38c2  vmovaps xmm3, [rsp+0x30]
000078eb87dd38c8  vmovaps xmm4, [rsp+0x40]
000078eb87dd38ce  vmovaps xmm5, [rsp+0x50]
000078eb87dd38d4  vmovaps xmm6, [rsp+0x60]
000078eb87dd38da  vmovaps xmm7, [rsp+0x70]
000078eb87dd38e0  vmovaps xmm8, [rsp+0x80]
000078eb87dd38e9  vmovaps xmm9, [rsp+0x90]
000078eb87dd38f2  vmovaps xmm10, [rsp+0xA0]
000078eb87dd38fb  vmovaps xmm11, [rsp+0xB0]
000078eb87dd3904  vmovaps xmm12, [rsp+0xC0]
000078eb87dd390d  vmovaps xmm13, [rsp+0xD0]
000078eb87dd3916  vmovaps xmm14, [rsp+0xE0]
000078eb87dd391f  add rsp, 0xF0
000078eb87dd3926  pop r11
000078eb87dd3928  pop r10
000078eb87dd392a  pop r9
000078eb87dd392c  pop r8
000078eb87dd392e  pop rsi
000078eb87dd392f  pop rdi
000078eb87dd3930  pop rdx
000078eb87dd3931  pop rcx
000078eb87dd3932  pop rax
000078eb87dd3933  add rsp, 0x08
000078eb87dd3937  jmp 0x000078EB87DCFF55
000078eb87dd393c  call 0x000078EB87C0C260
000078eb87dd3941  jmp 0x000078EB87DCFFB0
000078eb87dd3946  sub rsp, 0x08
000078eb87dd394a  push rax
000078eb87dd394b  push rcx
000078eb87dd394c  push rdx
000078eb87dd394d  push rdi
000078eb87dd394e  push rsi
000078eb87dd394f  push r8
000078eb87dd3951  push r9
000078eb87dd3953  push r10
000078eb87dd3955  push r11
000078eb87dd3957  sub rsp, 0xF0
000078eb87dd395e  vmovaps [rsp], xmm0
000078eb87dd3963  vmovaps [rsp+0x10], xmm1
000078eb87dd3969  vmovaps [rsp+0x20], xmm2
000078eb87dd396f  vmovaps [rsp+0x30], xmm3
000078eb87dd3975  vmovaps [rsp+0x40], xmm4
000078eb87dd397b  vmovaps [rsp+0x50], xmm5
000078eb87dd3981  vmovaps [rsp+0x60], xmm6
000078eb87dd3987  vmovaps [rsp+0x70], xmm7
000078eb87dd398d  vmovaps [rsp+0x80], xmm8
000078eb87dd3996  vmovaps [rsp+0x90], xmm10
000078eb87dd399f  vmovaps [rsp+0xA0], xmm11
000078eb87dd39a8  vmovaps [rsp+0xB0], xmm12
000078eb87dd39b1  vmovaps [rsp+0xC0], xmm13
000078eb87dd39ba  vmovaps [rsp+0xD0], xmm14
000078eb87dd39c3  vmovaps [rsp+0xE0], xmm15
000078eb87dd39cc  sub rsp, 0x30
000078eb87dd39d0  movaps [rsp], xmm9
000078eb87dd39d5  movaps [rsp+0x10], xmm8
000078eb87dd39db  movaps [rsp+0x20], xmm10
000078eb87dd39e1  lea rdi, [rsp]
000078eb87dd39e5  mov esi, 0x00
000078eb87dd39ea  mov rax, 0x61D341A71530
000078eb87dd39f4  call rax
000078eb87dd39f6  movaps xmm9, [rsp]
000078eb87dd39fb  add rsp, 0x30
000078eb87dd39ff  vmovaps xmm0, [rsp]
000078eb87dd3a04  vmovaps xmm1, [rsp+0x10]
000078eb87dd3a0a  vmovaps xmm2, [rsp+0x20]
000078eb87dd3a10  vmovaps xmm3, [rsp+0x30]
000078eb87dd3a16  vmovaps xmm4, [rsp+0x40]
000078eb87dd3a1c  vmovaps xmm5, [rsp+0x50]
000078eb87dd3a22  vmovaps xmm6, [rsp+0x60]
000078eb87dd3a28  vmovaps xmm7, [rsp+0x70]
000078eb87dd3a2e  vmovaps xmm8, [rsp+0x80]
000078eb87dd3a37  vmovaps xmm10, [rsp+0x90]
000078eb87dd3a40  vmovaps xmm11, [rsp+0xA0]
000078eb87dd3a49  vmovaps xmm12, [rsp+0xB0]
000078eb87dd3a52  vmovaps xmm13, [rsp+0xC0]
000078eb87dd3a5b  vmovaps xmm14, [rsp+0xD0]
000078eb87dd3a64  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3a6d  add rsp, 0xF0
000078eb87dd3a74  pop r11
000078eb87dd3a76  pop r10
000078eb87dd3a78  pop r9
000078eb87dd3a7a  pop r8
000078eb87dd3a7c  pop rsi
000078eb87dd3a7d  pop rdi
000078eb87dd3a7e  pop rdx
000078eb87dd3a7f  pop rcx
000078eb87dd3a80  pop rax
000078eb87dd3a81  add rsp, 0x08
000078eb87dd3a85  jmp 0x000078EB87DCFFE1
000078eb87dd3a8a  sub rsp, 0x08
000078eb87dd3a8e  push rax
000078eb87dd3a8f  push rcx
000078eb87dd3a90  push rdx
000078eb87dd3a91  push rdi
000078eb87dd3a92  push rsi
000078eb87dd3a93  push r8
000078eb87dd3a95  push r9
000078eb87dd3a97  push r10
000078eb87dd3a99  push r11
000078eb87dd3a9b  sub rsp, 0xF0
000078eb87dd3aa2  vmovaps [rsp], xmm0
000078eb87dd3aa7  vmovaps [rsp+0x10], xmm1
000078eb87dd3aad  vmovaps [rsp+0x20], xmm2
000078eb87dd3ab3  vmovaps [rsp+0x30], xmm3
000078eb87dd3ab9  vmovaps [rsp+0x40], xmm4
000078eb87dd3abf  vmovaps [rsp+0x50], xmm5
000078eb87dd3ac5  vmovaps [rsp+0x60], xmm6
000078eb87dd3acb  vmovaps [rsp+0x70], xmm7
000078eb87dd3ad1  vmovaps [rsp+0x80], xmm8
000078eb87dd3ada  vmovaps [rsp+0x90], xmm9
000078eb87dd3ae3  vmovaps [rsp+0xA0], xmm11
000078eb87dd3aec  vmovaps [rsp+0xB0], xmm12
000078eb87dd3af5  vmovaps [rsp+0xC0], xmm13
000078eb87dd3afe  vmovaps [rsp+0xD0], xmm14
000078eb87dd3b07  vmovaps [rsp+0xE0], xmm15
000078eb87dd3b10  sub rsp, 0x30
000078eb87dd3b14  movaps [rsp], xmm10
000078eb87dd3b19  movaps [rsp+0x10], xmm1
000078eb87dd3b1e  movaps [rsp+0x20], xmm11
000078eb87dd3b24  lea rdi, [rsp]
000078eb87dd3b28  mov esi, 0x00
000078eb87dd3b2d  mov rax, 0x61D341A71530
000078eb87dd3b37  call rax
000078eb87dd3b39  movaps xmm10, [rsp]
000078eb87dd3b3e  add rsp, 0x30
000078eb87dd3b42  vmovaps xmm0, [rsp]
000078eb87dd3b47  vmovaps xmm1, [rsp+0x10]
000078eb87dd3b4d  vmovaps xmm2, [rsp+0x20]
000078eb87dd3b53  vmovaps xmm3, [rsp+0x30]
000078eb87dd3b59  vmovaps xmm4, [rsp+0x40]
000078eb87dd3b5f  vmovaps xmm5, [rsp+0x50]
000078eb87dd3b65  vmovaps xmm6, [rsp+0x60]
000078eb87dd3b6b  vmovaps xmm7, [rsp+0x70]
000078eb87dd3b71  vmovaps xmm8, [rsp+0x80]
000078eb87dd3b7a  vmovaps xmm9, [rsp+0x90]
000078eb87dd3b83  vmovaps xmm11, [rsp+0xA0]
000078eb87dd3b8c  vmovaps xmm12, [rsp+0xB0]
000078eb87dd3b95  vmovaps xmm13, [rsp+0xC0]
000078eb87dd3b9e  vmovaps xmm14, [rsp+0xD0]
000078eb87dd3ba7  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3bb0  add rsp, 0xF0
000078eb87dd3bb7  pop r11
000078eb87dd3bb9  pop r10
000078eb87dd3bbb  pop r9
000078eb87dd3bbd  pop r8
000078eb87dd3bbf  pop rsi
000078eb87dd3bc0  pop rdi
000078eb87dd3bc1  pop rdx
000078eb87dd3bc2  pop rcx
000078eb87dd3bc3  pop rax
000078eb87dd3bc4  add rsp, 0x08
000078eb87dd3bc8  jmp 0x000078EB87DCFFFC
000078eb87dd3bcd  sub rsp, 0x08
000078eb87dd3bd1  push rax
000078eb87dd3bd2  push rcx
000078eb87dd3bd3  push rdx
000078eb87dd3bd4  push rdi
000078eb87dd3bd5  push rsi
000078eb87dd3bd6  push r8
000078eb87dd3bd8  push r9
000078eb87dd3bda  push r10
000078eb87dd3bdc  push r11
000078eb87dd3bde  sub rsp, 0xF0
000078eb87dd3be5  vmovaps [rsp], xmm0
000078eb87dd3bea  vmovaps [rsp+0x10], xmm2
000078eb87dd3bf0  vmovaps [rsp+0x20], xmm3
000078eb87dd3bf6  vmovaps [rsp+0x30], xmm4
000078eb87dd3bfc  vmovaps [rsp+0x40], xmm5
000078eb87dd3c02  vmovaps [rsp+0x50], xmm6
000078eb87dd3c08  vmovaps [rsp+0x60], xmm7
000078eb87dd3c0e  vmovaps [rsp+0x70], xmm8
000078eb87dd3c14  vmovaps [rsp+0x80], xmm9
000078eb87dd3c1d  vmovaps [rsp+0x90], xmm10
000078eb87dd3c26  vmovaps [rsp+0xA0], xmm11
000078eb87dd3c2f  vmovaps [rsp+0xB0], xmm12
000078eb87dd3c38  vmovaps [rsp+0xC0], xmm13
000078eb87dd3c41  vmovaps [rsp+0xD0], xmm14
000078eb87dd3c4a  vmovaps [rsp+0xE0], xmm15
000078eb87dd3c53  sub rsp, 0x30
000078eb87dd3c57  movaps [rsp], xmm1
000078eb87dd3c5b  movaps [rsp+0x10], xmm14
000078eb87dd3c61  movaps [rsp+0x20], xmm6
000078eb87dd3c66  lea rdi, [rsp]
000078eb87dd3c6a  mov esi, 0x00
000078eb87dd3c6f  mov rax, 0x61D341A71530
000078eb87dd3c79  call rax
000078eb87dd3c7b  movaps xmm1, [rsp]
000078eb87dd3c7f  add rsp, 0x30
000078eb87dd3c83  vmovaps xmm0, [rsp]
000078eb87dd3c88  vmovaps xmm2, [rsp+0x10]
000078eb87dd3c8e  vmovaps xmm3, [rsp+0x20]
000078eb87dd3c94  vmovaps xmm4, [rsp+0x30]
000078eb87dd3c9a  vmovaps xmm5, [rsp+0x40]
000078eb87dd3ca0  vmovaps xmm6, [rsp+0x50]
000078eb87dd3ca6  vmovaps xmm7, [rsp+0x60]
000078eb87dd3cac  vmovaps xmm8, [rsp+0x70]
000078eb87dd3cb2  vmovaps xmm9, [rsp+0x80]
000078eb87dd3cbb  vmovaps xmm10, [rsp+0x90]
000078eb87dd3cc4  vmovaps xmm11, [rsp+0xA0]
000078eb87dd3ccd  vmovaps xmm12, [rsp+0xB0]
000078eb87dd3cd6  vmovaps xmm13, [rsp+0xC0]
000078eb87dd3cdf  vmovaps xmm14, [rsp+0xD0]
000078eb87dd3ce8  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3cf1  add rsp, 0xF0
000078eb87dd3cf8  pop r11
000078eb87dd3cfa  pop r10
000078eb87dd3cfc  pop r9
000078eb87dd3cfe  pop r8
000078eb87dd3d00  pop rsi
000078eb87dd3d01  pop rdi
000078eb87dd3d02  pop rdx
000078eb87dd3d03  pop rcx
000078eb87dd3d04  pop rax
000078eb87dd3d05  add rsp, 0x08
000078eb87dd3d09  jmp 0x000078EB87DD0015
000078eb87dd3d0e  sub rsp, 0x08
000078eb87dd3d12  push rax
000078eb87dd3d13  push rcx
000078eb87dd3d14  push rdx
000078eb87dd3d15  push rdi
000078eb87dd3d16  push rsi
000078eb87dd3d17  push r8
000078eb87dd3d19  push r9
000078eb87dd3d1b  push r10
000078eb87dd3d1d  push r11
000078eb87dd3d1f  sub rsp, 0xF0
000078eb87dd3d26  vmovaps [rsp], xmm0
000078eb87dd3d2b  vmovaps [rsp+0x10], xmm1
000078eb87dd3d31  vmovaps [rsp+0x20], xmm2
000078eb87dd3d37  vmovaps [rsp+0x30], xmm3
000078eb87dd3d3d  vmovaps [rsp+0x40], xmm4
000078eb87dd3d43  vmovaps [rsp+0x50], xmm5
000078eb87dd3d49  vmovaps [rsp+0x60], xmm6
000078eb87dd3d4f  vmovaps [rsp+0x70], xmm7
000078eb87dd3d55  vmovaps [rsp+0x80], xmm8
000078eb87dd3d5e  vmovaps [rsp+0x90], xmm9
000078eb87dd3d67  vmovaps [rsp+0xA0], xmm10
000078eb87dd3d70  vmovaps [rsp+0xB0], xmm12
000078eb87dd3d79  vmovaps [rsp+0xC0], xmm13
000078eb87dd3d82  vmovaps [rsp+0xD0], xmm14
000078eb87dd3d8b  vmovaps [rsp+0xE0], xmm15
000078eb87dd3d94  sub rsp, 0x30
000078eb87dd3d98  movaps [rsp], xmm11
000078eb87dd3d9d  movaps [rsp+0x10], xmm13
000078eb87dd3da3  movaps [rsp+0x20], xmm14
000078eb87dd3da9  lea rdi, [rsp]
000078eb87dd3dad  mov esi, 0x00
000078eb87dd3db2  mov rax, 0x61D341A71530
000078eb87dd3dbc  call rax
000078eb87dd3dbe  movaps xmm11, [rsp]
000078eb87dd3dc3  add rsp, 0x30
000078eb87dd3dc7  vmovaps xmm0, [rsp]
000078eb87dd3dcc  vmovaps xmm1, [rsp+0x10]
000078eb87dd3dd2  vmovaps xmm2, [rsp+0x20]
000078eb87dd3dd8  vmovaps xmm3, [rsp+0x30]
000078eb87dd3dde  vmovaps xmm4, [rsp+0x40]
000078eb87dd3de4  vmovaps xmm5, [rsp+0x50]
000078eb87dd3dea  vmovaps xmm6, [rsp+0x60]
000078eb87dd3df0  vmovaps xmm7, [rsp+0x70]
000078eb87dd3df6  vmovaps xmm8, [rsp+0x80]
000078eb87dd3dff  vmovaps xmm9, [rsp+0x90]
000078eb87dd3e08  vmovaps xmm10, [rsp+0xA0]
000078eb87dd3e11  vmovaps xmm12, [rsp+0xB0]
000078eb87dd3e1a  vmovaps xmm13, [rsp+0xC0]
000078eb87dd3e23  vmovaps xmm14, [rsp+0xD0]
000078eb87dd3e2c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3e35  add rsp, 0xF0
000078eb87dd3e3c  pop r11
000078eb87dd3e3e  pop r10
000078eb87dd3e40  pop r9
000078eb87dd3e42  pop r8
000078eb87dd3e44  pop rsi
000078eb87dd3e45  pop rdi
000078eb87dd3e46  pop rdx
000078eb87dd3e47  pop rcx
000078eb87dd3e48  pop rax
000078eb87dd3e49  add rsp, 0x08
000078eb87dd3e4d  jmp 0x000078EB87DD003F
000078eb87dd3e52  sub rsp, 0x08
000078eb87dd3e56  push rax
000078eb87dd3e57  push rcx
000078eb87dd3e58  push rdx
000078eb87dd3e59  push rdi
000078eb87dd3e5a  push rsi
000078eb87dd3e5b  push r8
000078eb87dd3e5d  push r9
000078eb87dd3e5f  push r10
000078eb87dd3e61  push r11
000078eb87dd3e63  sub rsp, 0xF0
000078eb87dd3e6a  vmovaps [rsp], xmm0
000078eb87dd3e6f  vmovaps [rsp+0x10], xmm1
000078eb87dd3e75  vmovaps [rsp+0x20], xmm2
000078eb87dd3e7b  vmovaps [rsp+0x30], xmm3
000078eb87dd3e81  vmovaps [rsp+0x40], xmm4
000078eb87dd3e87  vmovaps [rsp+0x50], xmm5
000078eb87dd3e8d  vmovaps [rsp+0x60], xmm6
000078eb87dd3e93  vmovaps [rsp+0x70], xmm7
000078eb87dd3e99  vmovaps [rsp+0x80], xmm8
000078eb87dd3ea2  vmovaps [rsp+0x90], xmm9
000078eb87dd3eab  vmovaps [rsp+0xA0], xmm10
000078eb87dd3eb4  vmovaps [rsp+0xB0], xmm11
000078eb87dd3ebd  vmovaps [rsp+0xC0], xmm12
000078eb87dd3ec6  vmovaps [rsp+0xD0], xmm14
000078eb87dd3ecf  vmovaps [rsp+0xE0], xmm15
000078eb87dd3ed8  sub rsp, 0x30
000078eb87dd3edc  movaps [rsp], xmm13
000078eb87dd3ee1  movaps [rsp+0x10], xmm8
000078eb87dd3ee7  movaps [rsp+0x20], xmm14
000078eb87dd3eed  lea rdi, [rsp]
000078eb87dd3ef1  mov esi, 0x00
000078eb87dd3ef6  mov rax, 0x61D341A71530
000078eb87dd3f00  call rax
000078eb87dd3f02  movaps xmm13, [rsp]
000078eb87dd3f07  add rsp, 0x30
000078eb87dd3f0b  vmovaps xmm0, [rsp]
000078eb87dd3f10  vmovaps xmm1, [rsp+0x10]
000078eb87dd3f16  vmovaps xmm2, [rsp+0x20]
000078eb87dd3f1c  vmovaps xmm3, [rsp+0x30]
000078eb87dd3f22  vmovaps xmm4, [rsp+0x40]
000078eb87dd3f28  vmovaps xmm5, [rsp+0x50]
000078eb87dd3f2e  vmovaps xmm6, [rsp+0x60]
000078eb87dd3f34  vmovaps xmm7, [rsp+0x70]
000078eb87dd3f3a  vmovaps xmm8, [rsp+0x80]
000078eb87dd3f43  vmovaps xmm9, [rsp+0x90]
000078eb87dd3f4c  vmovaps xmm10, [rsp+0xA0]
000078eb87dd3f55  vmovaps xmm11, [rsp+0xB0]
000078eb87dd3f5e  vmovaps xmm12, [rsp+0xC0]
000078eb87dd3f67  vmovaps xmm14, [rsp+0xD0]
000078eb87dd3f70  vmovaps xmm15, [rsp+0xE0]
000078eb87dd3f79  add rsp, 0xF0
000078eb87dd3f80  pop r11
000078eb87dd3f82  pop r10
000078eb87dd3f84  pop r9
000078eb87dd3f86  pop r8
000078eb87dd3f88  pop rsi
000078eb87dd3f89  pop rdi
000078eb87dd3f8a  pop rdx
000078eb87dd3f8b  pop rcx
000078eb87dd3f8c  pop rax
000078eb87dd3f8d  add rsp, 0x08
000078eb87dd3f91  jmp 0x000078EB87DD006E
000078eb87dd3f96  sub rsp, 0x08
000078eb87dd3f9a  push rax
000078eb87dd3f9b  push rcx
000078eb87dd3f9c  push rdx
000078eb87dd3f9d  push rdi
000078eb87dd3f9e  push rsi
000078eb87dd3f9f  push r8
000078eb87dd3fa1  push r9
000078eb87dd3fa3  push r10
000078eb87dd3fa5  push r11
000078eb87dd3fa7  sub rsp, 0xF0
000078eb87dd3fae  vmovaps [rsp], xmm0
000078eb87dd3fb3  vmovaps [rsp+0x10], xmm1
000078eb87dd3fb9  vmovaps [rsp+0x20], xmm2
000078eb87dd3fbf  vmovaps [rsp+0x30], xmm3
000078eb87dd3fc5  vmovaps [rsp+0x40], xmm4
000078eb87dd3fcb  vmovaps [rsp+0x50], xmm5
000078eb87dd3fd1  vmovaps [rsp+0x60], xmm6
000078eb87dd3fd7  vmovaps [rsp+0x70], xmm7
000078eb87dd3fdd  vmovaps [rsp+0x80], xmm9
000078eb87dd3fe6  vmovaps [rsp+0x90], xmm10
000078eb87dd3fef  vmovaps [rsp+0xA0], xmm11
000078eb87dd3ff8  vmovaps [rsp+0xB0], xmm12
000078eb87dd4001  vmovaps [rsp+0xC0], xmm13
000078eb87dd400a  vmovaps [rsp+0xD0], xmm14
000078eb87dd4013  vmovaps [rsp+0xE0], xmm15
000078eb87dd401c  sub rsp, 0x30
000078eb87dd4020  movaps [rsp], xmm8
000078eb87dd4025  movaps [rsp+0x10], xmm7
000078eb87dd402a  movaps [rsp+0x20], xmm14
000078eb87dd4030  lea rdi, [rsp]
000078eb87dd4034  mov esi, 0x00
000078eb87dd4039  mov rax, 0x61D341A71530
000078eb87dd4043  call rax
000078eb87dd4045  movaps xmm8, [rsp]
000078eb87dd404a  add rsp, 0x30
000078eb87dd404e  vmovaps xmm0, [rsp]
000078eb87dd4053  vmovaps xmm1, [rsp+0x10]
000078eb87dd4059  vmovaps xmm2, [rsp+0x20]
000078eb87dd405f  vmovaps xmm3, [rsp+0x30]
000078eb87dd4065  vmovaps xmm4, [rsp+0x40]
000078eb87dd406b  vmovaps xmm5, [rsp+0x50]
000078eb87dd4071  vmovaps xmm6, [rsp+0x60]
000078eb87dd4077  vmovaps xmm7, [rsp+0x70]
000078eb87dd407d  vmovaps xmm9, [rsp+0x80]
000078eb87dd4086  vmovaps xmm10, [rsp+0x90]
000078eb87dd408f  vmovaps xmm11, [rsp+0xA0]
000078eb87dd4098  vmovaps xmm12, [rsp+0xB0]
000078eb87dd40a1  vmovaps xmm13, [rsp+0xC0]
000078eb87dd40aa  vmovaps xmm14, [rsp+0xD0]
000078eb87dd40b3  vmovaps xmm15, [rsp+0xE0]
000078eb87dd40bc  add rsp, 0xF0
000078eb87dd40c3  pop r11
000078eb87dd40c5  pop r10
000078eb87dd40c7  pop r9
000078eb87dd40c9  pop r8
000078eb87dd40cb  pop rsi
000078eb87dd40cc  pop rdi
000078eb87dd40cd  pop rdx
000078eb87dd40ce  pop rcx
000078eb87dd40cf  pop rax
000078eb87dd40d0  add rsp, 0x08
000078eb87dd40d4  jmp 0x000078EB87DD0094
000078eb87dd40d9  sub rsp, 0x08
000078eb87dd40dd  push rax
000078eb87dd40de  push rcx
000078eb87dd40df  push rdx
000078eb87dd40e0  push rdi
000078eb87dd40e1  push rsi
000078eb87dd40e2  push r8
000078eb87dd40e4  push r9
000078eb87dd40e6  push r10
000078eb87dd40e8  push r11
000078eb87dd40ea  sub rsp, 0xF0
000078eb87dd40f1  vmovaps [rsp], xmm0
000078eb87dd40f6  vmovaps [rsp+0x10], xmm1
000078eb87dd40fc  vmovaps [rsp+0x20], xmm2
000078eb87dd4102  vmovaps [rsp+0x30], xmm3
000078eb87dd4108  vmovaps [rsp+0x40], xmm4
000078eb87dd410e  vmovaps [rsp+0x50], xmm5
000078eb87dd4114  vmovaps [rsp+0x60], xmm6
000078eb87dd411a  vmovaps [rsp+0x70], xmm7
000078eb87dd4120  vmovaps [rsp+0x80], xmm8
000078eb87dd4129  vmovaps [rsp+0x90], xmm9
000078eb87dd4132  vmovaps [rsp+0xA0], xmm10
000078eb87dd413b  vmovaps [rsp+0xB0], xmm11
000078eb87dd4144  vmovaps [rsp+0xC0], xmm12
000078eb87dd414d  vmovaps [rsp+0xD0], xmm13
000078eb87dd4156  vmovaps [rsp+0xE0], xmm15
000078eb87dd415f  sub rsp, 0x30
000078eb87dd4163  movaps [rsp], xmm14
000078eb87dd4168  movaps [rsp+0x10], xmm12
000078eb87dd416e  movaps [rsp+0x20], xmm9
000078eb87dd4174  lea rdi, [rsp]
000078eb87dd4178  mov esi, 0x00
000078eb87dd417d  mov rax, 0x61D341A71530
000078eb87dd4187  call rax
000078eb87dd4189  movaps xmm14, [rsp]
000078eb87dd418e  add rsp, 0x30
000078eb87dd4192  vmovaps xmm0, [rsp]
000078eb87dd4197  vmovaps xmm1, [rsp+0x10]
000078eb87dd419d  vmovaps xmm2, [rsp+0x20]
000078eb87dd41a3  vmovaps xmm3, [rsp+0x30]
000078eb87dd41a9  vmovaps xmm4, [rsp+0x40]
000078eb87dd41af  vmovaps xmm5, [rsp+0x50]
000078eb87dd41b5  vmovaps xmm6, [rsp+0x60]
000078eb87dd41bb  vmovaps xmm7, [rsp+0x70]
000078eb87dd41c1  vmovaps xmm8, [rsp+0x80]
000078eb87dd41ca  vmovaps xmm9, [rsp+0x90]
000078eb87dd41d3  vmovaps xmm10, [rsp+0xA0]
000078eb87dd41dc  vmovaps xmm11, [rsp+0xB0]
000078eb87dd41e5  vmovaps xmm12, [rsp+0xC0]
000078eb87dd41ee  vmovaps xmm13, [rsp+0xD0]
000078eb87dd41f7  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4200  add rsp, 0xF0
000078eb87dd4207  pop r11
000078eb87dd4209  pop r10
000078eb87dd420b  pop r9
000078eb87dd420d  pop r8
000078eb87dd420f  pop rsi
000078eb87dd4210  pop rdi
000078eb87dd4211  pop rdx
000078eb87dd4212  pop rcx
000078eb87dd4213  pop rax
000078eb87dd4214  add rsp, 0x08
000078eb87dd4218  jmp 0x000078EB87DD00AE
000078eb87dd421d  sub rsp, 0x08
000078eb87dd4221  push rax
000078eb87dd4222  push rcx
000078eb87dd4223  push rdx
000078eb87dd4224  push rdi
000078eb87dd4225  push rsi
000078eb87dd4226  push r8
000078eb87dd4228  push r9
000078eb87dd422a  push r10
000078eb87dd422c  push r11
000078eb87dd422e  sub rsp, 0xF0
000078eb87dd4235  vmovaps [rsp], xmm0
000078eb87dd423a  vmovaps [rsp+0x10], xmm1
000078eb87dd4240  vmovaps [rsp+0x20], xmm2
000078eb87dd4246  vmovaps [rsp+0x30], xmm3
000078eb87dd424c  vmovaps [rsp+0x40], xmm4
000078eb87dd4252  vmovaps [rsp+0x50], xmm5
000078eb87dd4258  vmovaps [rsp+0x60], xmm6
000078eb87dd425e  vmovaps [rsp+0x70], xmm7
000078eb87dd4264  vmovaps [rsp+0x80], xmm8
000078eb87dd426d  vmovaps [rsp+0x90], xmm10
000078eb87dd4276  vmovaps [rsp+0xA0], xmm11
000078eb87dd427f  vmovaps [rsp+0xB0], xmm12
000078eb87dd4288  vmovaps [rsp+0xC0], xmm13
000078eb87dd4291  vmovaps [rsp+0xD0], xmm14
000078eb87dd429a  vmovaps [rsp+0xE0], xmm15
000078eb87dd42a3  sub rsp, 0x30
000078eb87dd42a7  movaps [rsp], xmm9
000078eb87dd42ac  movaps [rsp+0x10], xmm7
000078eb87dd42b1  movaps [rsp+0x20], xmm12
000078eb87dd42b7  lea rdi, [rsp]
000078eb87dd42bb  mov esi, 0x00
000078eb87dd42c0  mov rax, 0x61D341A71530
000078eb87dd42ca  call rax
000078eb87dd42cc  movaps xmm9, [rsp]
000078eb87dd42d1  add rsp, 0x30
000078eb87dd42d5  vmovaps xmm0, [rsp]
000078eb87dd42da  vmovaps xmm1, [rsp+0x10]
000078eb87dd42e0  vmovaps xmm2, [rsp+0x20]
000078eb87dd42e6  vmovaps xmm3, [rsp+0x30]
000078eb87dd42ec  vmovaps xmm4, [rsp+0x40]
000078eb87dd42f2  vmovaps xmm5, [rsp+0x50]
000078eb87dd42f8  vmovaps xmm6, [rsp+0x60]
000078eb87dd42fe  vmovaps xmm7, [rsp+0x70]
000078eb87dd4304  vmovaps xmm8, [rsp+0x80]
000078eb87dd430d  vmovaps xmm10, [rsp+0x90]
000078eb87dd4316  vmovaps xmm11, [rsp+0xA0]
000078eb87dd431f  vmovaps xmm12, [rsp+0xB0]
000078eb87dd4328  vmovaps xmm13, [rsp+0xC0]
000078eb87dd4331  vmovaps xmm14, [rsp+0xD0]
000078eb87dd433a  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4343  add rsp, 0xF0
000078eb87dd434a  pop r11
000078eb87dd434c  pop r10
000078eb87dd434e  pop r9
000078eb87dd4350  pop r8
000078eb87dd4352  pop rsi
000078eb87dd4353  pop rdi
000078eb87dd4354  pop rdx
000078eb87dd4355  pop rcx
000078eb87dd4356  pop rax
000078eb87dd4357  add rsp, 0x08
000078eb87dd435b  jmp 0x000078EB87DD00DD
000078eb87dd4360  sub rsp, 0x08
000078eb87dd4364  push rax
000078eb87dd4365  push rcx
000078eb87dd4366  push rdx
000078eb87dd4367  push rdi
000078eb87dd4368  push rsi
000078eb87dd4369  push r8
000078eb87dd436b  push r9
000078eb87dd436d  push r10
000078eb87dd436f  push r11
000078eb87dd4371  sub rsp, 0xF0
000078eb87dd4378  vmovaps [rsp], xmm0
000078eb87dd437d  vmovaps [rsp+0x10], xmm1
000078eb87dd4383  vmovaps [rsp+0x20], xmm2
000078eb87dd4389  vmovaps [rsp+0x30], xmm3
000078eb87dd438f  vmovaps [rsp+0x40], xmm4
000078eb87dd4395  vmovaps [rsp+0x50], xmm5
000078eb87dd439b  vmovaps [rsp+0x60], xmm6
000078eb87dd43a1  vmovaps [rsp+0x70], xmm7
000078eb87dd43a7  vmovaps [rsp+0x80], xmm8
000078eb87dd43b0  vmovaps [rsp+0x90], xmm9
000078eb87dd43b9  vmovaps [rsp+0xA0], xmm10
000078eb87dd43c2  vmovaps [rsp+0xB0], xmm11
000078eb87dd43cb  vmovaps [rsp+0xC0], xmm13
000078eb87dd43d4  vmovaps [rsp+0xD0], xmm14
000078eb87dd43dd  vmovaps [rsp+0xE0], xmm15
000078eb87dd43e6  sub rsp, 0x30
000078eb87dd43ea  movaps [rsp], xmm12
000078eb87dd43ef  movaps [rsp+0x10], xmm15
000078eb87dd43f5  movaps [rsp+0x20], xmm11
000078eb87dd43fb  lea rdi, [rsp]
000078eb87dd43ff  mov esi, 0x00
000078eb87dd4404  mov rax, 0x61D341A71530
000078eb87dd440e  call rax
000078eb87dd4410  movaps xmm12, [rsp]
000078eb87dd4415  add rsp, 0x30
000078eb87dd4419  vmovaps xmm0, [rsp]
000078eb87dd441e  vmovaps xmm1, [rsp+0x10]
000078eb87dd4424  vmovaps xmm2, [rsp+0x20]
000078eb87dd442a  vmovaps xmm3, [rsp+0x30]
000078eb87dd4430  vmovaps xmm4, [rsp+0x40]
000078eb87dd4436  vmovaps xmm5, [rsp+0x50]
000078eb87dd443c  vmovaps xmm6, [rsp+0x60]
000078eb87dd4442  vmovaps xmm7, [rsp+0x70]
000078eb87dd4448  vmovaps xmm8, [rsp+0x80]
000078eb87dd4451  vmovaps xmm9, [rsp+0x90]
000078eb87dd445a  vmovaps xmm10, [rsp+0xA0]
000078eb87dd4463  vmovaps xmm11, [rsp+0xB0]
000078eb87dd446c  vmovaps xmm13, [rsp+0xC0]
000078eb87dd4475  vmovaps xmm14, [rsp+0xD0]
000078eb87dd447e  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4487  add rsp, 0xF0
000078eb87dd448e  pop r11
000078eb87dd4490  pop r10
000078eb87dd4492  pop r9
000078eb87dd4494  pop r8
000078eb87dd4496  pop rsi
000078eb87dd4497  pop rdi
000078eb87dd4498  pop rdx
000078eb87dd4499  pop rcx
000078eb87dd449a  pop rax
000078eb87dd449b  add rsp, 0x08
000078eb87dd449f  jmp 0x000078EB87DD00F7
000078eb87dd44a4  sub rsp, 0x08
000078eb87dd44a8  push rax
000078eb87dd44a9  push rcx
000078eb87dd44aa  push rdx
000078eb87dd44ab  push rdi
000078eb87dd44ac  push rsi
000078eb87dd44ad  push r8
000078eb87dd44af  push r9
000078eb87dd44b1  push r10
000078eb87dd44b3  push r11
000078eb87dd44b5  sub rsp, 0xF0
000078eb87dd44bc  vmovaps [rsp], xmm0
000078eb87dd44c1  vmovaps [rsp+0x10], xmm1
000078eb87dd44c7  vmovaps [rsp+0x20], xmm2
000078eb87dd44cd  vmovaps [rsp+0x30], xmm3
000078eb87dd44d3  vmovaps [rsp+0x40], xmm4
000078eb87dd44d9  vmovaps [rsp+0x50], xmm5
000078eb87dd44df  vmovaps [rsp+0x60], xmm6
000078eb87dd44e5  vmovaps [rsp+0x70], xmm7
000078eb87dd44eb  vmovaps [rsp+0x80], xmm8
000078eb87dd44f4  vmovaps [rsp+0x90], xmm9
000078eb87dd44fd  vmovaps [rsp+0xA0], xmm10
000078eb87dd4506  vmovaps [rsp+0xB0], xmm12
000078eb87dd450f  vmovaps [rsp+0xC0], xmm13
000078eb87dd4518  vmovaps [rsp+0xD0], xmm14
000078eb87dd4521  vmovaps [rsp+0xE0], xmm15
000078eb87dd452a  sub rsp, 0x30
000078eb87dd452e  movaps [rsp], xmm11
000078eb87dd4533  movaps [rsp+0x10], xmm7
000078eb87dd4538  movaps [rsp+0x20], xmm15
000078eb87dd453e  lea rdi, [rsp]
000078eb87dd4542  mov esi, 0x00
000078eb87dd4547  mov rax, 0x61D341A71530
000078eb87dd4551  call rax
000078eb87dd4553  movaps xmm11, [rsp]
000078eb87dd4558  add rsp, 0x30
000078eb87dd455c  vmovaps xmm0, [rsp]
000078eb87dd4561  vmovaps xmm1, [rsp+0x10]
000078eb87dd4567  vmovaps xmm2, [rsp+0x20]
000078eb87dd456d  vmovaps xmm3, [rsp+0x30]
000078eb87dd4573  vmovaps xmm4, [rsp+0x40]
000078eb87dd4579  vmovaps xmm5, [rsp+0x50]
000078eb87dd457f  vmovaps xmm6, [rsp+0x60]
000078eb87dd4585  vmovaps xmm7, [rsp+0x70]
000078eb87dd458b  vmovaps xmm8, [rsp+0x80]
000078eb87dd4594  vmovaps xmm9, [rsp+0x90]
000078eb87dd459d  vmovaps xmm10, [rsp+0xA0]
000078eb87dd45a6  vmovaps xmm12, [rsp+0xB0]
000078eb87dd45af  vmovaps xmm13, [rsp+0xC0]
000078eb87dd45b8  vmovaps xmm14, [rsp+0xD0]
000078eb87dd45c1  vmovaps xmm15, [rsp+0xE0]
000078eb87dd45ca  add rsp, 0xF0
000078eb87dd45d1  pop r11
000078eb87dd45d3  pop r10
000078eb87dd45d5  pop r9
000078eb87dd45d7  pop r8
000078eb87dd45d9  pop rsi
000078eb87dd45da  pop rdi
000078eb87dd45db  pop rdx
000078eb87dd45dc  pop rcx
000078eb87dd45dd  pop rax
000078eb87dd45de  add rsp, 0x08
000078eb87dd45e2  jmp 0x000078EB87DD0123
000078eb87dd45e7  sub rsp, 0x08
000078eb87dd45eb  push rax
000078eb87dd45ec  push rcx
000078eb87dd45ed  push rdx
000078eb87dd45ee  push rdi
000078eb87dd45ef  push rsi
000078eb87dd45f0  push r8
000078eb87dd45f2  push r9
000078eb87dd45f4  push r10
000078eb87dd45f6  push r11
000078eb87dd45f8  sub rsp, 0xF0
000078eb87dd45ff  vmovaps [rsp], xmm0
000078eb87dd4604  vmovaps [rsp+0x10], xmm1
000078eb87dd460a  vmovaps [rsp+0x20], xmm2
000078eb87dd4610  vmovaps [rsp+0x30], xmm3
000078eb87dd4616  vmovaps [rsp+0x40], xmm4
000078eb87dd461c  vmovaps [rsp+0x50], xmm5
000078eb87dd4622  vmovaps [rsp+0x60], xmm6
000078eb87dd4628  vmovaps [rsp+0x70], xmm7
000078eb87dd462e  vmovaps [rsp+0x80], xmm8
000078eb87dd4637  vmovaps [rsp+0x90], xmm9
000078eb87dd4640  vmovaps [rsp+0xA0], xmm10
000078eb87dd4649  vmovaps [rsp+0xB0], xmm11
000078eb87dd4652  vmovaps [rsp+0xC0], xmm12
000078eb87dd465b  vmovaps [rsp+0xD0], xmm13
000078eb87dd4664  vmovaps [rsp+0xE0], xmm14
000078eb87dd466d  sub rsp, 0x30
000078eb87dd4671  movaps [rsp], xmm15
000078eb87dd4676  movaps [rsp+0x10], xmm10
000078eb87dd467c  movaps [rsp+0x20], xmm13
000078eb87dd4682  lea rdi, [rsp]
000078eb87dd4686  mov esi, 0x00
000078eb87dd468b  mov rax, 0x61D341A71530
000078eb87dd4695  call rax
000078eb87dd4697  movaps xmm15, [rsp]
000078eb87dd469c  add rsp, 0x30
000078eb87dd46a0  vmovaps xmm0, [rsp]
000078eb87dd46a5  vmovaps xmm1, [rsp+0x10]
000078eb87dd46ab  vmovaps xmm2, [rsp+0x20]
000078eb87dd46b1  vmovaps xmm3, [rsp+0x30]
000078eb87dd46b7  vmovaps xmm4, [rsp+0x40]
000078eb87dd46bd  vmovaps xmm5, [rsp+0x50]
000078eb87dd46c3  vmovaps xmm6, [rsp+0x60]
000078eb87dd46c9  vmovaps xmm7, [rsp+0x70]
000078eb87dd46cf  vmovaps xmm8, [rsp+0x80]
000078eb87dd46d8  vmovaps xmm9, [rsp+0x90]
000078eb87dd46e1  vmovaps xmm10, [rsp+0xA0]
000078eb87dd46ea  vmovaps xmm11, [rsp+0xB0]
000078eb87dd46f3  vmovaps xmm12, [rsp+0xC0]
000078eb87dd46fc  vmovaps xmm13, [rsp+0xD0]
000078eb87dd4705  vmovaps xmm14, [rsp+0xE0]
000078eb87dd470e  add rsp, 0xF0
000078eb87dd4715  pop r11
000078eb87dd4717  pop r10
000078eb87dd4719  pop r9
000078eb87dd471b  pop r8
000078eb87dd471d  pop rsi
000078eb87dd471e  pop rdi
000078eb87dd471f  pop rdx
000078eb87dd4720  pop rcx
000078eb87dd4721  pop rax
000078eb87dd4722  add rsp, 0x08
000078eb87dd4726  jmp 0x000078EB87DD013D
000078eb87dd472b  sub rsp, 0x08
000078eb87dd472f  push rax
000078eb87dd4730  push rcx
000078eb87dd4731  push rdx
000078eb87dd4732  push rdi
000078eb87dd4733  push rsi
000078eb87dd4734  push r8
000078eb87dd4736  push r9
000078eb87dd4738  push r10
000078eb87dd473a  push r11
000078eb87dd473c  sub rsp, 0xF0
000078eb87dd4743  vmovaps [rsp], xmm0
000078eb87dd4748  vmovaps [rsp+0x10], xmm1
000078eb87dd474e  vmovaps [rsp+0x20], xmm2
000078eb87dd4754  vmovaps [rsp+0x30], xmm3
000078eb87dd475a  vmovaps [rsp+0x40], xmm4
000078eb87dd4760  vmovaps [rsp+0x50], xmm5
000078eb87dd4766  vmovaps [rsp+0x60], xmm6
000078eb87dd476c  vmovaps [rsp+0x70], xmm7
000078eb87dd4772  vmovaps [rsp+0x80], xmm8
000078eb87dd477b  vmovaps [rsp+0x90], xmm9
000078eb87dd4784  vmovaps [rsp+0xA0], xmm11
000078eb87dd478d  vmovaps [rsp+0xB0], xmm12
000078eb87dd4796  vmovaps [rsp+0xC0], xmm13
000078eb87dd479f  vmovaps [rsp+0xD0], xmm14
000078eb87dd47a8  vmovaps [rsp+0xE0], xmm15
000078eb87dd47b1  sub rsp, 0x30
000078eb87dd47b5  movaps [rsp], xmm10
000078eb87dd47ba  movaps [rsp+0x10], xmm7
000078eb87dd47bf  movaps [rsp+0x20], xmm13
000078eb87dd47c5  lea rdi, [rsp]
000078eb87dd47c9  mov esi, 0x00
000078eb87dd47ce  mov rax, 0x61D341A71530
000078eb87dd47d8  call rax
000078eb87dd47da  movaps xmm10, [rsp]
000078eb87dd47df  add rsp, 0x30
000078eb87dd47e3  vmovaps xmm0, [rsp]
000078eb87dd47e8  vmovaps xmm1, [rsp+0x10]
000078eb87dd47ee  vmovaps xmm2, [rsp+0x20]
000078eb87dd47f4  vmovaps xmm3, [rsp+0x30]
000078eb87dd47fa  vmovaps xmm4, [rsp+0x40]
000078eb87dd4800  vmovaps xmm5, [rsp+0x50]
000078eb87dd4806  vmovaps xmm6, [rsp+0x60]
000078eb87dd480c  vmovaps xmm7, [rsp+0x70]
000078eb87dd4812  vmovaps xmm8, [rsp+0x80]
000078eb87dd481b  vmovaps xmm9, [rsp+0x90]
000078eb87dd4824  vmovaps xmm11, [rsp+0xA0]
000078eb87dd482d  vmovaps xmm12, [rsp+0xB0]
000078eb87dd4836  vmovaps xmm13, [rsp+0xC0]
000078eb87dd483f  vmovaps xmm14, [rsp+0xD0]
000078eb87dd4848  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4851  add rsp, 0xF0
000078eb87dd4858  pop r11
000078eb87dd485a  pop r10
000078eb87dd485c  pop r9
000078eb87dd485e  pop r8
000078eb87dd4860  pop rsi
000078eb87dd4861  pop rdi
000078eb87dd4862  pop rdx
000078eb87dd4863  pop rcx
000078eb87dd4864  pop rax
000078eb87dd4865  add rsp, 0x08
000078eb87dd4869  jmp 0x000078EB87DD0169
000078eb87dd486e  sub rsp, 0x08
000078eb87dd4872  push rax
000078eb87dd4873  push rcx
000078eb87dd4874  push rdx
000078eb87dd4875  push rdi
000078eb87dd4876  push rsi
000078eb87dd4877  push r8
000078eb87dd4879  push r9
000078eb87dd487b  push r10
000078eb87dd487d  push r11
000078eb87dd487f  sub rsp, 0xF0
000078eb87dd4886  vmovaps [rsp], xmm0
000078eb87dd488b  vmovaps [rsp+0x10], xmm1
000078eb87dd4891  vmovaps [rsp+0x20], xmm2
000078eb87dd4897  vmovaps [rsp+0x30], xmm3
000078eb87dd489d  vmovaps [rsp+0x40], xmm4
000078eb87dd48a3  vmovaps [rsp+0x50], xmm5
000078eb87dd48a9  vmovaps [rsp+0x60], xmm6
000078eb87dd48af  vmovaps [rsp+0x70], xmm7
000078eb87dd48b5  vmovaps [rsp+0x80], xmm8
000078eb87dd48be  vmovaps [rsp+0x90], xmm9
000078eb87dd48c7  vmovaps [rsp+0xA0], xmm10
000078eb87dd48d0  vmovaps [rsp+0xB0], xmm11
000078eb87dd48d9  vmovaps [rsp+0xC0], xmm12
000078eb87dd48e2  vmovaps [rsp+0xD0], xmm14
000078eb87dd48eb  vmovaps [rsp+0xE0], xmm15
000078eb87dd48f4  sub rsp, 0x30
000078eb87dd48f8  movaps [rsp], xmm13
000078eb87dd48fd  movaps [rsp+0x10], xmm1
000078eb87dd4902  movaps [rsp+0x20], xmm8
000078eb87dd4908  lea rdi, [rsp]
000078eb87dd490c  mov esi, 0x00
000078eb87dd4911  mov rax, 0x61D341A71530
000078eb87dd491b  call rax
000078eb87dd491d  movaps xmm13, [rsp]
000078eb87dd4922  add rsp, 0x30
000078eb87dd4926  vmovaps xmm0, [rsp]
000078eb87dd492b  vmovaps xmm1, [rsp+0x10]
000078eb87dd4931  vmovaps xmm2, [rsp+0x20]
000078eb87dd4937  vmovaps xmm3, [rsp+0x30]
000078eb87dd493d  vmovaps xmm4, [rsp+0x40]
000078eb87dd4943  vmovaps xmm5, [rsp+0x50]
000078eb87dd4949  vmovaps xmm6, [rsp+0x60]
000078eb87dd494f  vmovaps xmm7, [rsp+0x70]
000078eb87dd4955  vmovaps xmm8, [rsp+0x80]
000078eb87dd495e  vmovaps xmm9, [rsp+0x90]
000078eb87dd4967  vmovaps xmm10, [rsp+0xA0]
000078eb87dd4970  vmovaps xmm11, [rsp+0xB0]
000078eb87dd4979  vmovaps xmm12, [rsp+0xC0]
000078eb87dd4982  vmovaps xmm14, [rsp+0xD0]
000078eb87dd498b  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4994  add rsp, 0xF0
000078eb87dd499b  pop r11
000078eb87dd499d  pop r10
000078eb87dd499f  pop r9
000078eb87dd49a1  pop r8
000078eb87dd49a3  pop rsi
000078eb87dd49a4  pop rdi
000078eb87dd49a5  pop rdx
000078eb87dd49a6  pop rcx
000078eb87dd49a7  pop rax
000078eb87dd49a8  add rsp, 0x08
000078eb87dd49ac  jmp 0x000078EB87DD0183
000078eb87dd49b1  call 0x000078EB87BFF430
000078eb87dd49b6  jmp 0x000078EB87DD018D
000078eb87dd49bb  sub rsp, 0x08
000078eb87dd49bf  push rax
000078eb87dd49c0  push rcx
000078eb87dd49c1  push rdx
000078eb87dd49c2  push rdi
000078eb87dd49c3  push rsi
000078eb87dd49c4  push r8
000078eb87dd49c6  push r9
000078eb87dd49c8  push r10
000078eb87dd49ca  push r11
000078eb87dd49cc  sub rsp, 0xF0
000078eb87dd49d3  vmovaps [rsp], xmm0
000078eb87dd49d8  vmovaps [rsp+0x10], xmm1
000078eb87dd49de  vmovaps [rsp+0x20], xmm2
000078eb87dd49e4  vmovaps [rsp+0x30], xmm3
000078eb87dd49ea  vmovaps [rsp+0x40], xmm4
000078eb87dd49f0  vmovaps [rsp+0x50], xmm5
000078eb87dd49f6  vmovaps [rsp+0x60], xmm6
000078eb87dd49fc  vmovaps [rsp+0x70], xmm7
000078eb87dd4a02  vmovaps [rsp+0x80], xmm9
000078eb87dd4a0b  vmovaps [rsp+0x90], xmm10
000078eb87dd4a14  vmovaps [rsp+0xA0], xmm11
000078eb87dd4a1d  vmovaps [rsp+0xB0], xmm12
000078eb87dd4a26  vmovaps [rsp+0xC0], xmm13
000078eb87dd4a2f  vmovaps [rsp+0xD0], xmm14
000078eb87dd4a38  vmovaps [rsp+0xE0], xmm15
000078eb87dd4a41  sub rsp, 0x30
000078eb87dd4a45  movaps [rsp], xmm8
000078eb87dd4a4a  movaps [rsp+0x10], xmm14
000078eb87dd4a50  movaps [rsp+0x20], xmm9
000078eb87dd4a56  lea rdi, [rsp]
000078eb87dd4a5a  mov esi, 0x00
000078eb87dd4a5f  mov rax, 0x61D341A71530
000078eb87dd4a69  call rax
000078eb87dd4a6b  movaps xmm8, [rsp]
000078eb87dd4a70  add rsp, 0x30
000078eb87dd4a74  vmovaps xmm0, [rsp]
000078eb87dd4a79  vmovaps xmm1, [rsp+0x10]
000078eb87dd4a7f  vmovaps xmm2, [rsp+0x20]
000078eb87dd4a85  vmovaps xmm3, [rsp+0x30]
000078eb87dd4a8b  vmovaps xmm4, [rsp+0x40]
000078eb87dd4a91  vmovaps xmm5, [rsp+0x50]
000078eb87dd4a97  vmovaps xmm6, [rsp+0x60]
000078eb87dd4a9d  vmovaps xmm7, [rsp+0x70]
000078eb87dd4aa3  vmovaps xmm9, [rsp+0x80]
000078eb87dd4aac  vmovaps xmm10, [rsp+0x90]
000078eb87dd4ab5  vmovaps xmm11, [rsp+0xA0]
000078eb87dd4abe  vmovaps xmm12, [rsp+0xB0]
000078eb87dd4ac7  vmovaps xmm13, [rsp+0xC0]
000078eb87dd4ad0  vmovaps xmm14, [rsp+0xD0]
000078eb87dd4ad9  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4ae2  add rsp, 0xF0
000078eb87dd4ae9  pop r11
000078eb87dd4aeb  pop r10
000078eb87dd4aed  pop r9
000078eb87dd4aef  pop r8
000078eb87dd4af1  pop rsi
000078eb87dd4af2  pop rdi
000078eb87dd4af3  pop rdx
000078eb87dd4af4  pop rcx
000078eb87dd4af5  pop rax
000078eb87dd4af6  add rsp, 0x08
000078eb87dd4afa  jmp 0x000078EB87DD01AF
000078eb87dd4aff  sub rsp, 0x08
000078eb87dd4b03  push rax
000078eb87dd4b04  push rcx
000078eb87dd4b05  push rdx
000078eb87dd4b06  push rdi
000078eb87dd4b07  push rsi
000078eb87dd4b08  push r8
000078eb87dd4b0a  push r9
000078eb87dd4b0c  push r10
000078eb87dd4b0e  push r11
000078eb87dd4b10  sub rsp, 0xF0
000078eb87dd4b17  vmovaps [rsp], xmm0
000078eb87dd4b1c  vmovaps [rsp+0x10], xmm1
000078eb87dd4b22  vmovaps [rsp+0x20], xmm2
000078eb87dd4b28  vmovaps [rsp+0x30], xmm3
000078eb87dd4b2e  vmovaps [rsp+0x40], xmm4
000078eb87dd4b34  vmovaps [rsp+0x50], xmm5
000078eb87dd4b3a  vmovaps [rsp+0x60], xmm6
000078eb87dd4b40  vmovaps [rsp+0x70], xmm7
000078eb87dd4b46  vmovaps [rsp+0x80], xmm8
000078eb87dd4b4f  vmovaps [rsp+0x90], xmm10
000078eb87dd4b58  vmovaps [rsp+0xA0], xmm11
000078eb87dd4b61  vmovaps [rsp+0xB0], xmm12
000078eb87dd4b6a  vmovaps [rsp+0xC0], xmm13
000078eb87dd4b73  vmovaps [rsp+0xD0], xmm14
000078eb87dd4b7c  vmovaps [rsp+0xE0], xmm15
000078eb87dd4b85  sub rsp, 0x30
000078eb87dd4b89  movaps [rsp], xmm9
000078eb87dd4b8e  movaps [rsp+0x10], xmm1
000078eb87dd4b93  movaps [rsp+0x20], xmm14
000078eb87dd4b99  lea rdi, [rsp]
000078eb87dd4b9d  mov esi, 0x00
000078eb87dd4ba2  mov rax, 0x61D341A71530
000078eb87dd4bac  call rax
000078eb87dd4bae  movaps xmm9, [rsp]
000078eb87dd4bb3  add rsp, 0x30
000078eb87dd4bb7  vmovaps xmm0, [rsp]
000078eb87dd4bbc  vmovaps xmm1, [rsp+0x10]
000078eb87dd4bc2  vmovaps xmm2, [rsp+0x20]
000078eb87dd4bc8  vmovaps xmm3, [rsp+0x30]
000078eb87dd4bce  vmovaps xmm4, [rsp+0x40]
000078eb87dd4bd4  vmovaps xmm5, [rsp+0x50]
000078eb87dd4bda  vmovaps xmm6, [rsp+0x60]
000078eb87dd4be0  vmovaps xmm7, [rsp+0x70]
000078eb87dd4be6  vmovaps xmm8, [rsp+0x80]
000078eb87dd4bef  vmovaps xmm10, [rsp+0x90]
000078eb87dd4bf8  vmovaps xmm11, [rsp+0xA0]
000078eb87dd4c01  vmovaps xmm12, [rsp+0xB0]
000078eb87dd4c0a  vmovaps xmm13, [rsp+0xC0]
000078eb87dd4c13  vmovaps xmm14, [rsp+0xD0]
000078eb87dd4c1c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4c25  add rsp, 0xF0
000078eb87dd4c2c  pop r11
000078eb87dd4c2e  pop r10
000078eb87dd4c30  pop r9
000078eb87dd4c32  pop r8
000078eb87dd4c34  pop rsi
000078eb87dd4c35  pop rdi
000078eb87dd4c36  pop rdx
000078eb87dd4c37  pop rcx
000078eb87dd4c38  pop rax
000078eb87dd4c39  add rsp, 0x08
000078eb87dd4c3d  jmp 0x000078EB87DD01DD
000078eb87dd4c42  sub rsp, 0x08
000078eb87dd4c46  push rax
000078eb87dd4c47  push rcx
000078eb87dd4c48  push rdx
000078eb87dd4c49  push rdi
000078eb87dd4c4a  push rsi
000078eb87dd4c4b  push r8
000078eb87dd4c4d  push r9
000078eb87dd4c4f  push r10
000078eb87dd4c51  push r11
000078eb87dd4c53  sub rsp, 0xF0
000078eb87dd4c5a  vmovaps [rsp], xmm0
000078eb87dd4c5f  vmovaps [rsp+0x10], xmm1
000078eb87dd4c65  vmovaps [rsp+0x20], xmm2
000078eb87dd4c6b  vmovaps [rsp+0x30], xmm3
000078eb87dd4c71  vmovaps [rsp+0x40], xmm4
000078eb87dd4c77  vmovaps [rsp+0x50], xmm5
000078eb87dd4c7d  vmovaps [rsp+0x60], xmm6
000078eb87dd4c83  vmovaps [rsp+0x70], xmm7
000078eb87dd4c89  vmovaps [rsp+0x80], xmm8
000078eb87dd4c92  vmovaps [rsp+0x90], xmm9
000078eb87dd4c9b  vmovaps [rsp+0xA0], xmm10
000078eb87dd4ca4  vmovaps [rsp+0xB0], xmm11
000078eb87dd4cad  vmovaps [rsp+0xC0], xmm12
000078eb87dd4cb6  vmovaps [rsp+0xD0], xmm13
000078eb87dd4cbf  vmovaps [rsp+0xE0], xmm15
000078eb87dd4cc8  sub rsp, 0x30
000078eb87dd4ccc  movaps [rsp], xmm14
000078eb87dd4cd1  movaps [rsp+0x10], xmm4
000078eb87dd4cd6  movaps [rsp+0x20], xmm1
000078eb87dd4cdb  lea rdi, [rsp]
000078eb87dd4cdf  mov esi, 0x00
000078eb87dd4ce4  mov rax, 0x61D341A71530
000078eb87dd4cee  call rax
000078eb87dd4cf0  movaps xmm14, [rsp]
000078eb87dd4cf5  add rsp, 0x30
000078eb87dd4cf9  vmovaps xmm0, [rsp]
000078eb87dd4cfe  vmovaps xmm1, [rsp+0x10]
000078eb87dd4d04  vmovaps xmm2, [rsp+0x20]
000078eb87dd4d0a  vmovaps xmm3, [rsp+0x30]
000078eb87dd4d10  vmovaps xmm4, [rsp+0x40]
000078eb87dd4d16  vmovaps xmm5, [rsp+0x50]
000078eb87dd4d1c  vmovaps xmm6, [rsp+0x60]
000078eb87dd4d22  vmovaps xmm7, [rsp+0x70]
000078eb87dd4d28  vmovaps xmm8, [rsp+0x80]
000078eb87dd4d31  vmovaps xmm9, [rsp+0x90]
000078eb87dd4d3a  vmovaps xmm10, [rsp+0xA0]
000078eb87dd4d43  vmovaps xmm11, [rsp+0xB0]
000078eb87dd4d4c  vmovaps xmm12, [rsp+0xC0]
000078eb87dd4d55  vmovaps xmm13, [rsp+0xD0]
000078eb87dd4d5e  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4d67  add rsp, 0xF0
000078eb87dd4d6e  pop r11
000078eb87dd4d70  pop r10
000078eb87dd4d72  pop r9
000078eb87dd4d74  pop r8
000078eb87dd4d76  pop rsi
000078eb87dd4d77  pop rdi
000078eb87dd4d78  pop rdx
000078eb87dd4d79  pop rcx
000078eb87dd4d7a  pop rax
000078eb87dd4d7b  add rsp, 0x08
000078eb87dd4d7f  jmp 0x000078EB87DD0203
000078eb87dd4d84  sub rsp, 0x08
000078eb87dd4d88  push rax
000078eb87dd4d89  push rcx
000078eb87dd4d8a  push rdx
000078eb87dd4d8b  push rdi
000078eb87dd4d8c  push rsi
000078eb87dd4d8d  push r8
000078eb87dd4d8f  push r9
000078eb87dd4d91  push r10
000078eb87dd4d93  push r11
000078eb87dd4d95  sub rsp, 0xF0
000078eb87dd4d9c  vmovaps [rsp], xmm0
000078eb87dd4da1  vmovaps [rsp+0x10], xmm2
000078eb87dd4da7  vmovaps [rsp+0x20], xmm3
000078eb87dd4dad  vmovaps [rsp+0x30], xmm4
000078eb87dd4db3  vmovaps [rsp+0x40], xmm5
000078eb87dd4db9  vmovaps [rsp+0x50], xmm6
000078eb87dd4dbf  vmovaps [rsp+0x60], xmm7
000078eb87dd4dc5  vmovaps [rsp+0x70], xmm8
000078eb87dd4dcb  vmovaps [rsp+0x80], xmm9
000078eb87dd4dd4  vmovaps [rsp+0x90], xmm10
000078eb87dd4ddd  vmovaps [rsp+0xA0], xmm11
000078eb87dd4de6  vmovaps [rsp+0xB0], xmm12
000078eb87dd4def  vmovaps [rsp+0xC0], xmm13
000078eb87dd4df8  vmovaps [rsp+0xD0], xmm14
000078eb87dd4e01  vmovaps [rsp+0xE0], xmm15
000078eb87dd4e0a  sub rsp, 0x30
000078eb87dd4e0e  movaps [rsp], xmm1
000078eb87dd4e12  movaps [rsp+0x10], xmm12
000078eb87dd4e18  movaps [rsp+0x20], xmm11
000078eb87dd4e1e  lea rdi, [rsp]
000078eb87dd4e22  mov esi, 0x00
000078eb87dd4e27  mov rax, 0x61D341A71530
000078eb87dd4e31  call rax
000078eb87dd4e33  movaps xmm1, [rsp]
000078eb87dd4e37  add rsp, 0x30
000078eb87dd4e3b  vmovaps xmm0, [rsp]
000078eb87dd4e40  vmovaps xmm2, [rsp+0x10]
000078eb87dd4e46  vmovaps xmm3, [rsp+0x20]
000078eb87dd4e4c  vmovaps xmm4, [rsp+0x30]
000078eb87dd4e52  vmovaps xmm5, [rsp+0x40]
000078eb87dd4e58  vmovaps xmm6, [rsp+0x50]
000078eb87dd4e5e  vmovaps xmm7, [rsp+0x60]
000078eb87dd4e64  vmovaps xmm8, [rsp+0x70]
000078eb87dd4e6a  vmovaps xmm9, [rsp+0x80]
000078eb87dd4e73  vmovaps xmm10, [rsp+0x90]
000078eb87dd4e7c  vmovaps xmm11, [rsp+0xA0]
000078eb87dd4e85  vmovaps xmm12, [rsp+0xB0]
000078eb87dd4e8e  vmovaps xmm13, [rsp+0xC0]
000078eb87dd4e97  vmovaps xmm14, [rsp+0xD0]
000078eb87dd4ea0  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4ea9  add rsp, 0xF0
000078eb87dd4eb0  pop r11
000078eb87dd4eb2  pop r10
000078eb87dd4eb4  pop r9
000078eb87dd4eb6  pop r8
000078eb87dd4eb8  pop rsi
000078eb87dd4eb9  pop rdi
000078eb87dd4eba  pop rdx
000078eb87dd4ebb  pop rcx
000078eb87dd4ebc  pop rax
000078eb87dd4ebd  add rsp, 0x08
000078eb87dd4ec1  jmp 0x000078EB87DD0224
000078eb87dd4ec6  call 0x000078EB87CE20A0
000078eb87dd4ecb  jmp 0x000078EB87DD0232
000078eb87dd4ed0  call 0x000078EB87C09D70
000078eb87dd4ed5  jmp 0x000078EB87DD023C
000078eb87dd4eda  sub rsp, 0x08
000078eb87dd4ede  push rax
000078eb87dd4edf  push rcx
000078eb87dd4ee0  push rdx
000078eb87dd4ee1  push rdi
000078eb87dd4ee2  push rsi
000078eb87dd4ee3  push r8
000078eb87dd4ee5  push r9
000078eb87dd4ee7  push r10
000078eb87dd4ee9  push r11
000078eb87dd4eeb  sub rsp, 0xF0
000078eb87dd4ef2  vmovaps [rsp], xmm0
000078eb87dd4ef7  vmovaps [rsp+0x10], xmm1
000078eb87dd4efd  vmovaps [rsp+0x20], xmm2
000078eb87dd4f03  vmovaps [rsp+0x30], xmm3
000078eb87dd4f09  vmovaps [rsp+0x40], xmm4
000078eb87dd4f0f  vmovaps [rsp+0x50], xmm5
000078eb87dd4f15  vmovaps [rsp+0x60], xmm6
000078eb87dd4f1b  vmovaps [rsp+0x70], xmm8
000078eb87dd4f21  vmovaps [rsp+0x80], xmm9
000078eb87dd4f2a  vmovaps [rsp+0x90], xmm10
000078eb87dd4f33  vmovaps [rsp+0xA0], xmm11
000078eb87dd4f3c  vmovaps [rsp+0xB0], xmm12
000078eb87dd4f45  vmovaps [rsp+0xC0], xmm13
000078eb87dd4f4e  vmovaps [rsp+0xD0], xmm14
000078eb87dd4f57  vmovaps [rsp+0xE0], xmm15
000078eb87dd4f60  sub rsp, 0x30
000078eb87dd4f64  movaps [rsp], xmm7
000078eb87dd4f68  movaps [rsp+0x10], xmm15
000078eb87dd4f6e  movaps [rsp+0x20], xmm10
000078eb87dd4f74  lea rdi, [rsp]
000078eb87dd4f78  mov esi, 0x00
000078eb87dd4f7d  mov rax, 0x61D341A71530
000078eb87dd4f87  call rax
000078eb87dd4f89  movaps xmm7, [rsp]
000078eb87dd4f8d  add rsp, 0x30
000078eb87dd4f91  vmovaps xmm0, [rsp]
000078eb87dd4f96  vmovaps xmm1, [rsp+0x10]
000078eb87dd4f9c  vmovaps xmm2, [rsp+0x20]
000078eb87dd4fa2  vmovaps xmm3, [rsp+0x30]
000078eb87dd4fa8  vmovaps xmm4, [rsp+0x40]
000078eb87dd4fae  vmovaps xmm5, [rsp+0x50]
000078eb87dd4fb4  vmovaps xmm6, [rsp+0x60]
000078eb87dd4fba  vmovaps xmm8, [rsp+0x70]
000078eb87dd4fc0  vmovaps xmm9, [rsp+0x80]
000078eb87dd4fc9  vmovaps xmm10, [rsp+0x90]
000078eb87dd4fd2  vmovaps xmm11, [rsp+0xA0]
000078eb87dd4fdb  vmovaps xmm12, [rsp+0xB0]
000078eb87dd4fe4  vmovaps xmm13, [rsp+0xC0]
000078eb87dd4fed  vmovaps xmm14, [rsp+0xD0]
000078eb87dd4ff6  vmovaps xmm15, [rsp+0xE0]
000078eb87dd4fff  add rsp, 0xF0
000078eb87dd5006  pop r11
000078eb87dd5008  pop r10
000078eb87dd500a  pop r9
000078eb87dd500c  pop r8
000078eb87dd500e  pop rsi
000078eb87dd500f  pop rdi
000078eb87dd5010  pop rdx
000078eb87dd5011  pop rcx
000078eb87dd5012  pop rax
000078eb87dd5013  add rsp, 0x08
000078eb87dd5017  jmp 0x000078EB87DD025D
000078eb87dd501c  sub rsp, 0x08
000078eb87dd5020  push rax
000078eb87dd5021  push rcx
000078eb87dd5022  push rdx
000078eb87dd5023  push rdi
000078eb87dd5024  push rsi
000078eb87dd5025  push r8
000078eb87dd5027  push r9
000078eb87dd5029  push r10
000078eb87dd502b  push r11
000078eb87dd502d  sub rsp, 0xF0
000078eb87dd5034  vmovaps [rsp], xmm0
000078eb87dd5039  vmovaps [rsp+0x10], xmm1
000078eb87dd503f  vmovaps [rsp+0x20], xmm2
000078eb87dd5045  vmovaps [rsp+0x30], xmm3
000078eb87dd504b  vmovaps [rsp+0x40], xmm4
000078eb87dd5051  vmovaps [rsp+0x50], xmm5
000078eb87dd5057  vmovaps [rsp+0x60], xmm6
000078eb87dd505d  vmovaps [rsp+0x70], xmm7
000078eb87dd5063  vmovaps [rsp+0x80], xmm8
000078eb87dd506c  vmovaps [rsp+0x90], xmm9
000078eb87dd5075  vmovaps [rsp+0xA0], xmm11
000078eb87dd507e  vmovaps [rsp+0xB0], xmm12
000078eb87dd5087  vmovaps [rsp+0xC0], xmm13
000078eb87dd5090  vmovaps [rsp+0xD0], xmm14
000078eb87dd5099  vmovaps [rsp+0xE0], xmm15
000078eb87dd50a2  sub rsp, 0x30
000078eb87dd50a6  movaps [rsp], xmm10
000078eb87dd50ab  movaps [rsp+0x10], xmm11
000078eb87dd50b1  movaps [rsp+0x20], xmm15
000078eb87dd50b7  lea rdi, [rsp]
000078eb87dd50bb  mov esi, 0x00
000078eb87dd50c0  mov rax, 0x61D341A71530
000078eb87dd50ca  call rax
000078eb87dd50cc  movaps xmm10, [rsp]
000078eb87dd50d1  add rsp, 0x30
000078eb87dd50d5  vmovaps xmm0, [rsp]
000078eb87dd50da  vmovaps xmm1, [rsp+0x10]
000078eb87dd50e0  vmovaps xmm2, [rsp+0x20]
000078eb87dd50e6  vmovaps xmm3, [rsp+0x30]
000078eb87dd50ec  vmovaps xmm4, [rsp+0x40]
000078eb87dd50f2  vmovaps xmm5, [rsp+0x50]
000078eb87dd50f8  vmovaps xmm6, [rsp+0x60]
000078eb87dd50fe  vmovaps xmm7, [rsp+0x70]
000078eb87dd5104  vmovaps xmm8, [rsp+0x80]
000078eb87dd510d  vmovaps xmm9, [rsp+0x90]
000078eb87dd5116  vmovaps xmm11, [rsp+0xA0]
000078eb87dd511f  vmovaps xmm12, [rsp+0xB0]
000078eb87dd5128  vmovaps xmm13, [rsp+0xC0]
000078eb87dd5131  vmovaps xmm14, [rsp+0xD0]
000078eb87dd513a  vmovaps xmm15, [rsp+0xE0]
000078eb87dd5143  add rsp, 0xF0
000078eb87dd514a  pop r11
000078eb87dd514c  pop r10
000078eb87dd514e  pop r9
000078eb87dd5150  pop r8
000078eb87dd5152  pop rsi
000078eb87dd5153  pop rdi
000078eb87dd5154  pop rdx
000078eb87dd5155  pop rcx
000078eb87dd5156  pop rax
000078eb87dd5157  add rsp, 0x08
000078eb87dd515b  jmp 0x000078EB87DD028B
000078eb87dd5160  sub rsp, 0x08
000078eb87dd5164  push rax
000078eb87dd5165  push rcx
000078eb87dd5166  push rdx
000078eb87dd5167  push rdi
000078eb87dd5168  push rsi
000078eb87dd5169  push r8
000078eb87dd516b  push r9
000078eb87dd516d  push r10
000078eb87dd516f  push r11
000078eb87dd5171  sub rsp, 0xF0
000078eb87dd5178  vmovaps [rsp], xmm0
000078eb87dd517d  vmovaps [rsp+0x10], xmm1
000078eb87dd5183  vmovaps [rsp+0x20], xmm2
000078eb87dd5189  vmovaps [rsp+0x30], xmm3
000078eb87dd518f  vmovaps [rsp+0x40], xmm4
000078eb87dd5195  vmovaps [rsp+0x50], xmm5
000078eb87dd519b  vmovaps [rsp+0x60], xmm6
000078eb87dd51a1  vmovaps [rsp+0x70], xmm7
000078eb87dd51a7  vmovaps [rsp+0x80], xmm8
000078eb87dd51b0  vmovaps [rsp+0x90], xmm9
000078eb87dd51b9  vmovaps [rsp+0xA0], xmm10
000078eb87dd51c2  vmovaps [rsp+0xB0], xmm12
000078eb87dd51cb  vmovaps [rsp+0xC0], xmm13
000078eb87dd51d4  vmovaps [rsp+0xD0], xmm14
000078eb87dd51dd  vmovaps [rsp+0xE0], xmm15
000078eb87dd51e6  sub rsp, 0x30
000078eb87dd51ea  movaps [rsp], xmm11
000078eb87dd51ef  movaps [rsp+0x10], xmm12
000078eb87dd51f5  movaps [rsp+0x20], xmm15
000078eb87dd51fb  lea rdi, [rsp]
000078eb87dd51ff  mov esi, 0x00
000078eb87dd5204  mov rax, 0x61D341A71530
000078eb87dd520e  call rax
000078eb87dd5210  movaps xmm11, [rsp]
000078eb87dd5215  add rsp, 0x30
000078eb87dd5219  vmovaps xmm0, [rsp]
000078eb87dd521e  vmovaps xmm1, [rsp+0x10]
000078eb87dd5224  vmovaps xmm2, [rsp+0x20]
000078eb87dd522a  vmovaps xmm3, [rsp+0x30]
000078eb87dd5230  vmovaps xmm4, [rsp+0x40]
000078eb87dd5236  vmovaps xmm5, [rsp+0x50]
000078eb87dd523c  vmovaps xmm6, [rsp+0x60]
000078eb87dd5242  vmovaps xmm7, [rsp+0x70]
000078eb87dd5248  vmovaps xmm8, [rsp+0x80]
000078eb87dd5251  vmovaps xmm9, [rsp+0x90]
000078eb87dd525a  vmovaps xmm10, [rsp+0xA0]
000078eb87dd5263  vmovaps xmm12, [rsp+0xB0]
000078eb87dd526c  vmovaps xmm13, [rsp+0xC0]
000078eb87dd5275  vmovaps xmm14, [rsp+0xD0]
000078eb87dd527e  vmovaps xmm15, [rsp+0xE0]
000078eb87dd5287  add rsp, 0xF0
000078eb87dd528e  pop r11
000078eb87dd5290  pop r10
000078eb87dd5292  pop r9
000078eb87dd5294  pop r8
000078eb87dd5296  pop rsi
000078eb87dd5297  pop rdi
000078eb87dd5298  pop rdx
000078eb87dd5299  pop rcx
000078eb87dd529a  pop rax
000078eb87dd529b  add rsp, 0x08
000078eb87dd529f  jmp 0x000078EB87DD02B9
000078eb87dd52a4  sub rsp, 0x08
000078eb87dd52a8  push rax
000078eb87dd52a9  push rcx
000078eb87dd52aa  push rdx
000078eb87dd52ab  push rdi
000078eb87dd52ac  push rsi
000078eb87dd52ad  push r8
000078eb87dd52af  push r9
000078eb87dd52b1  push r10
000078eb87dd52b3  push r11
000078eb87dd52b5  sub rsp, 0xF0
000078eb87dd52bc  vmovaps [rsp], xmm0
000078eb87dd52c1  vmovaps [rsp+0x10], xmm1
000078eb87dd52c7  vmovaps [rsp+0x20], xmm2
000078eb87dd52cd  vmovaps [rsp+0x30], xmm3
000078eb87dd52d3  vmovaps [rsp+0x40], xmm4
000078eb87dd52d9  vmovaps [rsp+0x50], xmm5
000078eb87dd52df  vmovaps [rsp+0x60], xmm6
000078eb87dd52e5  vmovaps [rsp+0x70], xmm7
000078eb87dd52eb  vmovaps [rsp+0x80], xmm8
000078eb87dd52f4  vmovaps [rsp+0x90], xmm9
000078eb87dd52fd  vmovaps [rsp+0xA0], xmm10
000078eb87dd5306  vmovaps [rsp+0xB0], xmm11
000078eb87dd530f  vmovaps [rsp+0xC0], xmm12
000078eb87dd5318  vmovaps [rsp+0xD0], xmm13
000078eb87dd5321  vmovaps [rsp+0xE0], xmm14
000078eb87dd532a  sub rsp, 0x30
000078eb87dd532e  movaps [rsp], xmm15
000078eb87dd5333  movaps [rsp+0x10], xmm13
000078eb87dd5339  movaps [rsp+0x20], xmm9
000078eb87dd533f  lea rdi, [rsp]
000078eb87dd5343  mov esi, 0x00
000078eb87dd5348  mov rax, 0x61D341A71530
000078eb87dd5352  call rax
000078eb87dd5354  movaps xmm15, [rsp]
000078eb87dd5359  add rsp, 0x30
000078eb87dd535d  vmovaps xmm0, [rsp]
000078eb87dd5362  vmovaps xmm1, [rsp+0x10]
000078eb87dd5368  vmovaps xmm2, [rsp+0x20]
000078eb87dd536e  vmovaps xmm3, [rsp+0x30]
000078eb87dd5374  vmovaps xmm4, [rsp+0x40]
000078eb87dd537a  vmovaps xmm5, [rsp+0x50]
000078eb87dd5380  vmovaps xmm6, [rsp+0x60]
000078eb87dd5386  vmovaps xmm7, [rsp+0x70]
000078eb87dd538c  vmovaps xmm8, [rsp+0x80]
000078eb87dd5395  vmovaps xmm9, [rsp+0x90]
000078eb87dd539e  vmovaps xmm10, [rsp+0xA0]
000078eb87dd53a7  vmovaps xmm11, [rsp+0xB0]
000078eb87dd53b0  vmovaps xmm12, [rsp+0xC0]
000078eb87dd53b9  vmovaps xmm13, [rsp+0xD0]
000078eb87dd53c2  vmovaps xmm14, [rsp+0xE0]
000078eb87dd53cb  add rsp, 0xF0
000078eb87dd53d2  pop r11
000078eb87dd53d4  pop r10
000078eb87dd53d6  pop r9
000078eb87dd53d8  pop r8
000078eb87dd53da  pop rsi
000078eb87dd53db  pop rdi
000078eb87dd53dc  pop rdx
000078eb87dd53dd  pop rcx
000078eb87dd53de  pop rax
000078eb87dd53df  add rsp, 0x08
000078eb87dd53e3  jmp 0x000078EB87DD02D4
000078eb87dd53e8  sub rsp, 0x08
000078eb87dd53ec  push rax
000078eb87dd53ed  push rcx
000078eb87dd53ee  push rdx
000078eb87dd53ef  push rdi
000078eb87dd53f0  push rsi
000078eb87dd53f1  push r8
000078eb87dd53f3  push r9
000078eb87dd53f5  push r10
000078eb87dd53f7  push r11
000078eb87dd53f9  sub rsp, 0xF0
000078eb87dd5400  vmovaps [rsp], xmm0
000078eb87dd5405  vmovaps [rsp+0x10], xmm1
000078eb87dd540b  vmovaps [rsp+0x20], xmm2
000078eb87dd5411  vmovaps [rsp+0x30], xmm3
000078eb87dd5417  vmovaps [rsp+0x40], xmm4
000078eb87dd541d  vmovaps [rsp+0x50], xmm5
000078eb87dd5423  vmovaps [rsp+0x60], xmm6
000078eb87dd5429  vmovaps [rsp+0x70], xmm7
000078eb87dd542f  vmovaps [rsp+0x80], xmm8
000078eb87dd5438  vmovaps [rsp+0x90], xmm9
000078eb87dd5441  vmovaps [rsp+0xA0], xmm10
000078eb87dd544a  vmovaps [rsp+0xB0], xmm11
000078eb87dd5453  vmovaps [rsp+0xC0], xmm12
000078eb87dd545c  vmovaps [rsp+0xD0], xmm14
000078eb87dd5465  vmovaps [rsp+0xE0], xmm15
000078eb87dd546e  sub rsp, 0x30
000078eb87dd5472  movaps [rsp], xmm13
000078eb87dd5477  movaps [rsp+0x10], xmm8
000078eb87dd547d  movaps [rsp+0x20], xmm14
000078eb87dd5483  lea rdi, [rsp]
000078eb87dd5487  mov esi, 0x00
000078eb87dd548c  mov rax, 0x61D341A71530
000078eb87dd5496  call rax
000078eb87dd5498  movaps xmm13, [rsp]
000078eb87dd549d  add rsp, 0x30
000078eb87dd54a1  vmovaps xmm0, [rsp]
000078eb87dd54a6  vmovaps xmm1, [rsp+0x10]
000078eb87dd54ac  vmovaps xmm2, [rsp+0x20]
000078eb87dd54b2  vmovaps xmm3, [rsp+0x30]
000078eb87dd54b8  vmovaps xmm4, [rsp+0x40]
000078eb87dd54be  vmovaps xmm5, [rsp+0x50]
000078eb87dd54c4  vmovaps xmm6, [rsp+0x60]
000078eb87dd54ca  vmovaps xmm7, [rsp+0x70]
000078eb87dd54d0  vmovaps xmm8, [rsp+0x80]
000078eb87dd54d9  vmovaps xmm9, [rsp+0x90]
000078eb87dd54e2  vmovaps xmm10, [rsp+0xA0]
000078eb87dd54eb  vmovaps xmm11, [rsp+0xB0]
000078eb87dd54f4  vmovaps xmm12, [rsp+0xC0]
000078eb87dd54fd  vmovaps xmm14, [rsp+0xD0]
000078eb87dd5506  vmovaps xmm15, [rsp+0xE0]
000078eb87dd550f  add rsp, 0xF0
000078eb87dd5516  pop r11
000078eb87dd5518  pop r10
000078eb87dd551a  pop r9
000078eb87dd551c  pop r8
000078eb87dd551e  pop rsi
000078eb87dd551f  pop rdi
000078eb87dd5520  pop rdx
000078eb87dd5521  pop rcx
000078eb87dd5522  pop rax
000078eb87dd5523  add rsp, 0x08
000078eb87dd5527  jmp 0x000078EB87DD02F7
000078eb87dd552c  sub rsp, 0x08
000078eb87dd5530  push rax
000078eb87dd5531  push rcx
000078eb87dd5532  push rdx
000078eb87dd5533  push rdi
000078eb87dd5534  push rsi
000078eb87dd5535  push r8
000078eb87dd5537  push r9
000078eb87dd5539  push r10
000078eb87dd553b  push r11
000078eb87dd553d  sub rsp, 0xF0
000078eb87dd5544  vmovaps [rsp], xmm0
000078eb87dd5549  vmovaps [rsp+0x10], xmm1
000078eb87dd554f  vmovaps [rsp+0x20], xmm2
000078eb87dd5555  vmovaps [rsp+0x30], xmm3
000078eb87dd555b  vmovaps [rsp+0x40], xmm4
000078eb87dd5561  vmovaps [rsp+0x50], xmm5
000078eb87dd5567  vmovaps [rsp+0x60], xmm6
000078eb87dd556d  vmovaps [rsp+0x70], xmm7
000078eb87dd5573  vmovaps [rsp+0x80], xmm8
000078eb87dd557c  vmovaps [rsp+0x90], xmm9
000078eb87dd5585  vmovaps [rsp+0xA0], xmm10
000078eb87dd558e  vmovaps [rsp+0xB0], xmm11
000078eb87dd5597  vmovaps [rsp+0xC0], xmm12
000078eb87dd55a0  vmovaps [rsp+0xD0], xmm13
000078eb87dd55a9  vmovaps [rsp+0xE0], xmm15
000078eb87dd55b2  sub rsp, 0x30
000078eb87dd55b6  movaps [rsp], xmm14
000078eb87dd55bb  movaps [rsp+0x10], xmm1
000078eb87dd55c0  movaps [rsp+0x20], xmm10
000078eb87dd55c6  lea rdi, [rsp]
000078eb87dd55ca  mov esi, 0x00
000078eb87dd55cf  mov rax, 0x61D341A71530
000078eb87dd55d9  call rax
000078eb87dd55db  movaps xmm14, [rsp]
000078eb87dd55e0  add rsp, 0x30
000078eb87dd55e4  vmovaps xmm0, [rsp]
000078eb87dd55e9  vmovaps xmm1, [rsp+0x10]
000078eb87dd55ef  vmovaps xmm2, [rsp+0x20]
000078eb87dd55f5  vmovaps xmm3, [rsp+0x30]
000078eb87dd55fb  vmovaps xmm4, [rsp+0x40]
000078eb87dd5601  vmovaps xmm5, [rsp+0x50]
000078eb87dd5607  vmovaps xmm6, [rsp+0x60]
000078eb87dd560d  vmovaps xmm7, [rsp+0x70]
000078eb87dd5613  vmovaps xmm8, [rsp+0x80]
000078eb87dd561c  vmovaps xmm9, [rsp+0x90]
000078eb87dd5625  vmovaps xmm10, [rsp+0xA0]
000078eb87dd562e  vmovaps xmm11, [rsp+0xB0]
000078eb87dd5637  vmovaps xmm12, [rsp+0xC0]
000078eb87dd5640  vmovaps xmm13, [rsp+0xD0]
000078eb87dd5649  vmovaps xmm15, [rsp+0xE0]
000078eb87dd5652  add rsp, 0xF0
000078eb87dd5659  pop r11
000078eb87dd565b  pop r10
000078eb87dd565d  pop r9
000078eb87dd565f  pop r8
000078eb87dd5661  pop rsi
000078eb87dd5662  pop rdi
000078eb87dd5663  pop rdx
000078eb87dd5664  pop rcx
000078eb87dd5665  pop rax
000078eb87dd5666  add rsp, 0x08
000078eb87dd566a  jmp 0x000078EB87DD031A
000078eb87dd566f  sub rsp, 0x08
000078eb87dd5673  push rax
000078eb87dd5674  push rcx
000078eb87dd5675  push rdx
000078eb87dd5676  push rdi
000078eb87dd5677  push rsi
000078eb87dd5678  push r8
000078eb87dd567a  push r9
000078eb87dd567c  push r10
000078eb87dd567e  push r11
000078eb87dd5680  sub rsp, 0xF0
000078eb87dd5687  vmovaps [rsp], xmm0
000078eb87dd568c  vmovaps [rsp+0x10], xmm2
000078eb87dd5692  vmovaps [rsp+0x20], xmm3
000078eb87dd5698  vmovaps [rsp+0x30], xmm4
000078eb87dd569e  vmovaps [rsp+0x40], xmm5
000078eb87dd56a4  vmovaps [rsp+0x50], xmm6
000078eb87dd56aa  vmovaps [rsp+0x60], xmm7
000078eb87dd56b0  vmovaps [rsp+0x70], xmm8
000078eb87dd56b6  vmovaps [rsp+0x80], xmm9
000078eb87dd56bf  vmovaps [rsp+0x90], xmm10
000078eb87dd56c8  vmovaps [rsp+0xA0], xmm11
000078eb87dd56d1  vmovaps [rsp+0xB0], xmm12
000078eb87dd56da  vmovaps [rsp+0xC0], xmm13
000078eb87dd56e3  vmovaps [rsp+0xD0], xmm14
000078eb87dd56ec  vmovaps [rsp+0xE0], xmm15
000078eb87dd56f5  sub rsp, 0x30
000078eb87dd56f9  movaps [rsp], xmm1
000078eb87dd56fd  movaps [rsp+0x10], xmm7
000078eb87dd5702  movaps [rsp+0x20], xmm11
000078eb87dd5708  lea rdi, [rsp]
000078eb87dd570c  mov esi, 0x00
000078eb87dd5711  mov rax, 0x61D341A71530
000078eb87dd571b  call rax
000078eb87dd571d  movaps xmm1, [rsp]
000078eb87dd5721  add rsp, 0x30
000078eb87dd5725  vmovaps xmm0, [rsp]
000078eb87dd572a  vmovaps xmm2, [rsp+0x10]
000078eb87dd5730  vmovaps xmm3, [rsp+0x20]
000078eb87dd5736  vmovaps xmm4, [rsp+0x30]
000078eb87dd573c  vmovaps xmm5, [rsp+0x40]
000078eb87dd5742  vmovaps xmm6, [rsp+0x50]
000078eb87dd5748  vmovaps xmm7, [rsp+0x60]
000078eb87dd574e  vmovaps xmm8, [rsp+0x70]
000078eb87dd5754  vmovaps xmm9, [rsp+0x80]
000078eb87dd575d  vmovaps xmm10, [rsp+0x90]
000078eb87dd5766  vmovaps xmm11, [rsp+0xA0]
000078eb87dd576f  vmovaps xmm12, [rsp+0xB0]
000078eb87dd5778  vmovaps xmm13, [rsp+0xC0]
000078eb87dd5781  vmovaps xmm14, [rsp+0xD0]
000078eb87dd578a  vmovaps xmm15, [rsp+0xE0]
000078eb87dd5793  add rsp, 0xF0
000078eb87dd579a  pop r11
000078eb87dd579c  pop r10
000078eb87dd579e  pop r9
000078eb87dd57a0  pop r8
000078eb87dd57a2  pop rsi
000078eb87dd57a3  pop rdi
000078eb87dd57a4  pop rdx
000078eb87dd57a5  pop rcx
000078eb87dd57a6  pop rax
000078eb87dd57a7  add rsp, 0x08
000078eb87dd57ab  jmp 0x000078EB87DD033B
000078eb87dd57b0  call 0x000078EB87C0E880
000078eb87dd57b5  jmp 0x000078EB87DD034E
000078eb87dd57ba  call 0x000078EB87C0C380
000078eb87dd57bf  jmp 0x000078EB87DD0359
000078eb87dd57c4  call 0x000078EB87C0D600
000078eb87dd57c9  jmp 0x000078EB87DD0364
000078eb87dd57ce  call 0x000078EB87BFF540
000078eb87dd57d3  jmp 0x000078EB87DD036F
000078eb87dd57d8  int3
000078eb87dd57d9  nop [rax], eax
000078eb87dd57e0  mov rax, [r15+0x40]
000078eb87dd57e4  mov r14, [r15+0x58]
000078eb87dd57e8  lea r12, [rax+r14*1]
000078eb87dd57ec  movaps xmm1, [r15+0x1D0]
000078eb87dd57f4  vmovaps [rsp+0x10], xmm1
000078eb87dd57fa  vmovaps xmm15, [rsp+0x10]
000078eb87dd5800  por xmm1, xmm15
000078eb87dd5805  movaps xmm14, [r15+0x1A0]
000078eb87dd580d  vmovaps [rsp+0x10], xmm14
000078eb87dd5813  vmovaps xmm13, [rsp+0x10]
000078eb87dd5819  por xmm14, xmm13
000078eb87dd581e  lea rax, [r12+0x30]
000078eb87dd5823  mov r11, [r13+rax*1]
000078eb87dd5828  lea rax, [r12+0x38]
000078eb87dd582d  mov r10, [r13+rax*1]
000078eb87dd5832  movq xmm13, r11
000078eb87dd5837  movq xmm12, r10
000078eb87dd583c  movq xmm13, xmm13
000078eb87dd5841  vmovaps [rsp+0x10], xmm13
000078eb87dd5847  movq xmm13, xmm13
000078eb87dd584c  movaps [r15+0x130], xmm13
000078eb87dd5854  movq xmm12, xmm12
000078eb87dd5859  vmovaps [rsp+0x20], xmm12
000078eb87dd585f  movq xmm12, xmm12
000078eb87dd5864  movaps [r15+0x280], xmm12
000078eb87dd586c  movaps xmm13, [r15+0x270]
000078eb87dd5874  vmovaps [rsp+0x30], xmm13
000078eb87dd587a  vmovaps xmm12, [rsp+0x30]
000078eb87dd5880  por xmm13, xmm12
000078eb87dd5885  lea rax, [r12+0x20]
000078eb87dd588a  mov r11, [r13+rax*1]
000078eb87dd588f  lea rax, [r12+0x28]
000078eb87dd5894  mov r10, [r13+rax*1]
000078eb87dd5899  movq xmm12, r11
000078eb87dd589e  movq xmm11, r10
000078eb87dd58a3  movq xmm12, xmm12
000078eb87dd58a8  vmovaps [rsp+0x30], xmm12
000078eb87dd58ae  movq xmm12, xmm12
000078eb87dd58b3  movaps [r15+0x150], xmm12
000078eb87dd58bb  movq xmm11, xmm11
000078eb87dd58c0  vmovaps [rsp+0x40], xmm11
000078eb87dd58c6  movq xmm11, xmm11
000078eb87dd58cb  movaps [r15+0x140], xmm11
000078eb87dd58d3  lea rax, [r12+0x10]
000078eb87dd58d8  mov r11, [r13+rax*1]
000078eb87dd58dd  lea rax, [r12+0x18]
000078eb87dd58e2  mov r10, [r13+rax*1]
000078eb87dd58e7  movq xmm12, r11
000078eb87dd58ec  movq xmm11, r10
000078eb87dd58f1  movq xmm12, xmm12
000078eb87dd58f6  vmovaps [rsp+0x50], xmm12
000078eb87dd58fc  movq xmm12, xmm12
000078eb87dd5901  movaps [r15+0x170], xmm12
000078eb87dd5909  movq xmm11, xmm11
000078eb87dd590e  vmovaps [rsp+0x60], xmm11
000078eb87dd5914  movq xmm11, xmm11
000078eb87dd5919  movaps [r15+0x160], xmm11
000078eb87dd5921  mov rax, [r13+r12*1]
000078eb87dd5926  vmovq xmm12, rax
000078eb87dd592b  vpbroadcastq xmm12, xmm12
000078eb87dd5930  lea rax, [r12+0x08]
000078eb87dd5935  mov r12, [r13+rax*1]
000078eb87dd593a  movq xmm11, r12
000078eb87dd593f  movaps [r15+0x230], xmm11
000078eb87dd5947  mov rax, [r15+0xF8]
000078eb87dd594e  lea r12, [rax+0x50]
000078eb87dd5952  movups xmm11, [r13+r12*1]
000078eb87dd5958  lea r12, [rax+0x60]
000078eb87dd595c  movups xmm10, [r13+r12*1]
000078eb87dd5962  lea r12, [rax+0x30]
000078eb87dd5966  movups xmm9, [r13+r12*1]
000078eb87dd596c  mov r12, [r15+0x50]
000078eb87dd5970  lea r11, [r12+r14*1]
000078eb87dd5974  mov [r15+0x60], r11
000078eb87dd5978  lea r12, [r14+0x40]
000078eb87dd597c  mov [r15+0x58], r12
000078eb87dd5980  movaps xmm8, xmm12
000078eb87dd5984  mulpd xmm8, xmm15
000078eb87dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000078eb87dd598f  ptest xmm7, xmm7
000078eb87dd5994  jnz 0x000078EB87DD67B7
000078eb87dd599a  movq xmm15, qword ptr [r15+0x230]
000078eb87dd59a3  vmovaps [rsp+0x70], xmm15
000078eb87dd59a9  vpermilpd xmm15, xmm15, 0x00
000078eb87dd59af  movaps xmm7, xmm9
000078eb87dd59b3  mulpd xmm7, xmm15
000078eb87dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000078eb87dd59bd  ptest xmm6, xmm6
000078eb87dd59c2  jnz 0x000078EB87DD68FB
000078eb87dd59c8  vxorps xmm15, xmm15, xmm15
000078eb87dd59cd  vpbroadcastq xmm15, xmm15
000078eb87dd59d2  movaps xmm9, xmm12
000078eb87dd59d6  mulpd xmm9, xmm10
000078eb87dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000078eb87dd59e1  ptest xmm6, xmm6
000078eb87dd59e6  jnz 0x000078EB87DD6A3D
000078eb87dd59ec  movaps xmm10, xmm12
000078eb87dd59f0  mulpd xmm10, xmm11
000078eb87dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000078eb87dd59fb  ptest xmm6, xmm6
000078eb87dd5a00  jnz 0x000078EB87DD6B81
000078eb87dd5a06  movaps xmm11, [r15+0x1F0]
000078eb87dd5a0e  movaps xmm6, xmm12
000078eb87dd5a12  mulpd xmm6, xmm11
000078eb87dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000078eb87dd5a1c  ptest xmm5, xmm5
000078eb87dd5a21  jnz 0x000078EB87DD6CC5
000078eb87dd5a27  movaps xmm12, [r15+0x2A0]
000078eb87dd5a2f  vmovaps [rsp+0x80], xmm12
000078eb87dd5a38  vmovaps xmm11, [rsp+0x80]
000078eb87dd5a41  por xmm12, xmm11
000078eb87dd5a46  movaps xmm11, [r15+0x250]
000078eb87dd5a4e  vmovaps [rsp+0x80], xmm11
000078eb87dd5a57  vmovaps xmm5, [rsp+0x80]
000078eb87dd5a60  por xmm11, xmm5
000078eb87dd5a65  vmovaps xmm4, [rsp+0x70]
000078eb87dd5a6b  vpermilpd xmm4, xmm4, 0x00
000078eb87dd5a71  movaps xmm3, xmm5
000078eb87dd5a74  mulpd xmm3, xmm4
000078eb87dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000078eb87dd5a7d  ptest xmm2, xmm2
000078eb87dd5a82  jnz 0x000078EB87DD6E07
000078eb87dd5a88  mov [rsp+0x80], rax
000078eb87dd5a90  xor eax, eax
000078eb87dd5a92  mov r14d, 0x200
000078eb87dd5a98  cmp r12, r14
000078eb87dd5a9b  cmc
000078eb87dd5a9c  lahf
000078eb87dd5a9d  seto al
000078eb87dd5aa0  mov [r15+0x108], eax
000078eb87dd5aa7  movaps xmm5, xmm8
000078eb87dd5aab  addpd xmm5, xmm15
000078eb87dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000078eb87dd5ab5  ptest xmm4, xmm4
000078eb87dd5aba  jnz 0x000078EB87DD6F47
000078eb87dd5ac0  movaps xmm8, [r15+0x1B0]
000078eb87dd5ac8  movaps xmm4, xmm9
000078eb87dd5acc  addpd xmm4, xmm8
000078eb87dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000078eb87dd5ad6  ptest xmm2, xmm2
000078eb87dd5adb  jnz 0x000078EB87DD7089
000078eb87dd5ae1  movaps xmm9, xmm10
000078eb87dd5ae5  addpd xmm9, xmm8
000078eb87dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000078eb87dd5af0  ptest xmm2, xmm2
000078eb87dd5af5  jnz 0x000078EB87DD71CB
000078eb87dd5afb  movaps xmm10, [r15+0x2F0]
000078eb87dd5b03  vmovaps [rsp+0x90], xmm10
000078eb87dd5b0c  vmovaps xmm8, [rsp+0x90]
000078eb87dd5b15  por xmm10, xmm8
000078eb87dd5b1a  movaps xmm8, [r15+0x2E0]
000078eb87dd5b22  vmovaps [rsp+0x90], xmm8
000078eb87dd5b2b  vmovaps xmm2, [rsp+0x90]
000078eb87dd5b34  por xmm8, xmm2
000078eb87dd5b39  movaps xmm2, [r15+0x2D0]
000078eb87dd5b41  vmovaps [rsp+0x90], xmm2
000078eb87dd5b4a  vmovaps [rsp+0xA0], xmm1
000078eb87dd5b53  vmovaps xmm1, [rsp+0x90]
000078eb87dd5b5c  por xmm2, xmm1
000078eb87dd5b60  movaps xmm1, [r15+0x200]
000078eb87dd5b68  vmovaps [rsp+0x90], xmm1
000078eb87dd5b71  vmovaps [rsp+0xB0], xmm15
000078eb87dd5b7a  vmovaps xmm15, [rsp+0x90]
000078eb87dd5b83  por xmm1, xmm15
000078eb87dd5b88  movaps xmm15, [r15+0x1C0]
000078eb87dd5b90  vmovaps [rsp+0x90], xmm15
000078eb87dd5b99  vmovaps [rsp+0xC0], xmm1
000078eb87dd5ba2  vmovaps xmm1, [rsp+0x90]
000078eb87dd5bab  por xmm15, xmm1
000078eb87dd5bb0  movaps xmm1, [r15+0x190]
000078eb87dd5bb8  vmovaps [rsp+0x90], xmm1
000078eb87dd5bc1  vmovaps [rsp+0xD0], xmm15
000078eb87dd5bca  vmovaps xmm15, [rsp+0x90]
000078eb87dd5bd3  por xmm1, xmm15
000078eb87dd5bd8  movaps xmm15, [r15+0x300]
000078eb87dd5be0  vmovaps [rsp+0x90], xmm15
000078eb87dd5be9  vmovaps [rsp+0xE0], xmm1
000078eb87dd5bf2  vmovaps xmm1, [rsp+0x90]
000078eb87dd5bfb  por xmm15, xmm1
000078eb87dd5c00  mov rax, [rsp+0x80]
000078eb87dd5c08  lea r14, [rax+0xA0]
000078eb87dd5c0f  movups xmm1, [r13+r14*1]
000078eb87dd5c15  lea r14, [rax+0xB0]
000078eb87dd5c1c  vmovaps [rsp+0x80], xmm1
000078eb87dd5c25  movups xmm1, [r13+r14*1]
000078eb87dd5c2b  vmovaps [rsp+0x90], xmm1
000078eb87dd5c34  vmovaps [rsp+0xF0], xmm15
000078eb87dd5c3d  vmovaps xmm15, [rsp+0xB0]
000078eb87dd5c46  vmovaps [rsp+0xB0], xmm14
000078eb87dd5c4f  movaps xmm1, xmm6
000078eb87dd5c52  addpd xmm1, xmm15
000078eb87dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000078eb87dd5c5c  ptest xmm14, xmm14
000078eb87dd5c62  jnz 0x000078EB87DD7323
000078eb87dd5c68  lea r14, [rax+0xF0]
000078eb87dd5c6f  movups xmm15, [r13+r14*1]
000078eb87dd5c75  movaps xmm14, xmm4
000078eb87dd5c79  addpd xmm14, xmm3
000078eb87dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000078eb87dd5c84  ptest xmm6, xmm6
000078eb87dd5c89  jnz 0x000078EB87DD746E
000078eb87dd5c8f  movaps xmm6, xmm9
000078eb87dd5c93  addpd xmm6, xmm7
000078eb87dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000078eb87dd5c9c  ptest xmm4, xmm4
000078eb87dd5ca1  jnz 0x000078EB87DD75B0
000078eb87dd5ca7  vmovaps xmm9, [rsp+0x70]
000078eb87dd5cad  vpermilpd xmm9, xmm9, 0x00
000078eb87dd5cb3  vmovaps xmm4, [rsp+0x90]
000078eb87dd5cbc  movaps xmm7, xmm4
000078eb87dd5cbf  mulpd xmm7, xmm9
000078eb87dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000078eb87dd5cc9  ptest xmm3, xmm3
000078eb87dd5cce  jnz 0x000078EB87DD76F1
000078eb87dd5cd4  vmovaps xmm9, [rsp+0x50]
000078eb87dd5cda  vpermilpd xmm9, xmm9, 0x00
000078eb87dd5ce0  movaps xmm4, xmm15
000078eb87dd5ce4  mulpd xmm4, xmm9
000078eb87dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000078eb87dd5cee  ptest xmm3, xmm3
000078eb87dd5cf3  jnz 0x000078EB87DD7832
000078eb87dd5cf9  lea r14, [rax+0xE0]
000078eb87dd5d00  movups xmm15, [r13+r14*1]
000078eb87dd5d06  vmovaps xmm9, [rsp+0x70]
000078eb87dd5d0c  vpermilpd xmm9, xmm9, 0x00
000078eb87dd5d12  vmovaps [rsp+0x70], xmm1
000078eb87dd5d18  vmovaps xmm1, [rsp+0x80]
000078eb87dd5d21  vmovaps [rsp+0x80], xmm15
000078eb87dd5d2a  movaps xmm3, xmm1
000078eb87dd5d2d  mulpd xmm3, xmm9
000078eb87dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000078eb87dd5d37  ptest xmm15, xmm15
000078eb87dd5d3d  jnz 0x000078EB87DD797E
000078eb87dd5d43  vmovaps xmm1, [rsp+0xF0]
000078eb87dd5d4c  vmovaps xmm15, [rsp+0xF0]
000078eb87dd5d55  por xmm1, xmm15
000078eb87dd5d5a  movaps [r15+0x300], xmm1
000078eb87dd5d62  vmovaps xmm15, [rsp+0xE0]
000078eb87dd5d6b  vmovaps xmm9, [rsp+0xE0]
000078eb87dd5d74  por xmm15, xmm9
000078eb87dd5d79  movaps [r15+0x190], xmm15
000078eb87dd5d81  vmovaps xmm9, [rsp+0x50]
000078eb87dd5d87  vpermilpd xmm9, xmm9, 0x00
000078eb87dd5d8d  vmovaps [rsp+0x90], xmm1
000078eb87dd5d96  vmovaps [rsp+0xE0], xmm15
000078eb87dd5d9f  vmovaps xmm15, [rsp+0x80]
000078eb87dd5da8  vmovaps [rsp+0x80], xmm14
000078eb87dd5db1  movaps xmm1, xmm15
000078eb87dd5db5  mulpd xmm1, xmm9
000078eb87dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000078eb87dd5dbf  ptest xmm14, xmm14
000078eb87dd5dc5  jnz 0x000078EB87DD7ABF
000078eb87dd5dcb  lea r14, [rax+0x90]
000078eb87dd5dd2  movups xmm15, [r13+r14*1]
000078eb87dd5dd8  vmovaps xmm14, [rsp+0xD0]
000078eb87dd5de1  vmovaps xmm9, [rsp+0xD0]
000078eb87dd5dea  por xmm14, xmm9
000078eb87dd5def  movaps [r15+0x1C0], xmm14
000078eb87dd5df7  vmovaps xmm9, [rsp+0xC0]
000078eb87dd5e00  vmovaps [rsp+0xD0], xmm1
000078eb87dd5e09  vmovaps xmm1, [rsp+0xC0]
000078eb87dd5e12  por xmm9, xmm1
000078eb87dd5e17  movaps [r15+0x200], xmm9
000078eb87dd5e1f  vmovaps [rsp+0xC0], xmm2
000078eb87dd5e28  vmovaps xmm1, [rsp+0xC0]
000078eb87dd5e31  por xmm2, xmm1
000078eb87dd5e35  movaps [r15+0x2D0], xmm2
000078eb87dd5e3d  vmovaps [rsp+0xC0], xmm8
000078eb87dd5e46  vmovaps xmm1, [rsp+0xC0]
000078eb87dd5e4f  por xmm8, xmm1
000078eb87dd5e54  movaps [r15+0x2E0], xmm8
000078eb87dd5e5c  vmovaps [rsp+0xC0], xmm15
000078eb87dd5e65  movaps xmm1, xmm5
000078eb87dd5e68  addpd xmm1, xmm7
000078eb87dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000078eb87dd5e71  ptest xmm15, xmm15
000078eb87dd5e77  jnz 0x000078EB87DD7C0B
000078eb87dd5e7d  vmovaps xmm15, [rsp+0x50]
000078eb87dd5e83  vpermilpd xmm15, xmm15, 0x00
000078eb87dd5e89  vmovaps xmm5, [rsp+0xC0]
000078eb87dd5e92  vmovaps [rsp+0xC0], xmm1
000078eb87dd5e9b  movaps xmm7, xmm5
000078eb87dd5e9e  mulpd xmm7, xmm15
000078eb87dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000078eb87dd5ea8  ptest xmm1, xmm1
000078eb87dd5ead  jnz 0x000078EB87DD7D4B
000078eb87dd5eb3  lea r14, [rax+0x80]
000078eb87dd5eba  movups xmm1, [r13+r14*1]
000078eb87dd5ec0  vmovaps xmm5, [rsp+0x70]
000078eb87dd5ec6  vmovaps [rsp+0x70], xmm1
000078eb87dd5ecc  movaps xmm15, xmm5
000078eb87dd5ed0  addpd xmm15, xmm3
000078eb87dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87dd5edb  ptest xmm1, xmm1
000078eb87dd5ee0  jnz 0x000078EB87DD7E96
000078eb87dd5ee6  vmovaps xmm5, [rsp+0x80]
000078eb87dd5eef  movaps xmm1, xmm5
000078eb87dd5ef2  addpd xmm1, xmm4
000078eb87dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000078eb87dd5efb  ptest xmm3, xmm3
000078eb87dd5f00  jnz 0x000078EB87DD7FD8
000078eb87dd5f06  vmovaps [rsp+0x80], xmm10
000078eb87dd5f0f  vmovaps xmm5, [rsp+0x80]
000078eb87dd5f18  por xmm10, xmm5
000078eb87dd5f1d  movaps [r15+0x2F0], xmm10
000078eb87dd5f25  vmovaps xmm5, [rsp+0x50]
000078eb87dd5f2b  vpermilpd xmm5, xmm5, 0x00
000078eb87dd5f31  vmovaps xmm3, [rsp+0x70]
000078eb87dd5f37  vmovaps [rsp+0x50], xmm1
000078eb87dd5f3d  movaps xmm4, xmm3
000078eb87dd5f40  mulpd xmm4, xmm5
000078eb87dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000078eb87dd5f49  ptest xmm1, xmm1
000078eb87dd5f4e  jnz 0x000078EB87DD8118
000078eb87dd5f54  lea r14, [rax+0xD0]
000078eb87dd5f5b  movups xmm1, [r13+r14*1]
000078eb87dd5f61  vmovaps xmm3, [rsp+0xD0]
000078eb87dd5f6a  vmovaps [rsp+0x70], xmm1
000078eb87dd5f70  movaps xmm5, xmm6
000078eb87dd5f73  addpd xmm5, xmm3
000078eb87dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000078eb87dd5f7c  ptest xmm1, xmm1
000078eb87dd5f81  jnz 0x000078EB87DD8262
000078eb87dd5f87  vmovaps xmm1, [rsp+0x60]
000078eb87dd5f8d  vpermilpd xmm1, xmm1, 0x00
000078eb87dd5f93  movaps xmm6, xmm9
000078eb87dd5f97  mulpd xmm6, xmm1
000078eb87dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000078eb87dd5fa0  ptest xmm3, xmm3
000078eb87dd5fa5  jnz 0x000078EB87DD83A2
000078eb87dd5fab  movaps [r15+0x260], xmm6
000078eb87dd5fb3  vxorps xmm1, xmm1, xmm1
000078eb87dd5fb7  vpbroadcastq xmm1, xmm1
000078eb87dd5fbc  movaps [r15+0x1B0], xmm1
000078eb87dd5fc4  vmovaps xmm1, [rsp+0x60]
000078eb87dd5fca  vpermilpd xmm1, xmm1, 0x00
000078eb87dd5fd0  vmovaps xmm3, [rsp+0x70]
000078eb87dd5fd6  vmovaps [rsp+0x70], xmm15
000078eb87dd5fdc  movaps xmm9, xmm3
000078eb87dd5fe0  mulpd xmm9, xmm1
000078eb87dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000078eb87dd5feb  ptest xmm15, xmm15
000078eb87dd5ff1  jnz 0x000078EB87DD84E3
000078eb87dd5ff7  lea r14, [rax+0xC0]
000078eb87dd5ffe  movups xmm1, [r13+r14*1]
000078eb87dd6004  vmovaps xmm3, [rsp+0xC0]
000078eb87dd600d  vmovaps [rsp+0x80], xmm1
000078eb87dd6016  movaps xmm15, xmm3
000078eb87dd601a  addpd xmm15, xmm7
000078eb87dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87dd6025  ptest xmm1, xmm1
000078eb87dd602a  jnz 0x000078EB87DD862F
000078eb87dd6030  vmovaps [rsp+0xC0], xmm13
000078eb87dd6039  vmovaps xmm1, [rsp+0xC0]
000078eb87dd6042  por xmm13, xmm1
000078eb87dd6047  movaps [r15+0x270], xmm13
000078eb87dd604f  vmovaps xmm1, [rsp+0xB0]
000078eb87dd6058  vmovaps xmm7, [rsp+0xB0]
000078eb87dd6061  por xmm1, xmm7
000078eb87dd6065  movaps [r15+0x1A0], xmm1
000078eb87dd606d  vmovaps xmm1, [rsp+0x60]
000078eb87dd6073  vpermilpd xmm1, xmm1, 0x00
000078eb87dd6079  vmovaps [rsp+0xB0], xmm1
000078eb87dd6082  vmovaps xmm1, [rsp+0x80]
000078eb87dd608b  vmovaps [rsp+0x80], xmm15
000078eb87dd6094  vmovaps xmm15, [rsp+0xB0]
000078eb87dd609d  vmovaps [rsp+0xB0], xmm14
000078eb87dd60a6  movaps xmm3, xmm1
000078eb87dd60a9  mulpd xmm3, xmm15
000078eb87dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000078eb87dd60b3  ptest xmm14, xmm14
000078eb87dd60b9  jnz 0x000078EB87DD8771
000078eb87dd60bf  lea r14, [rax+0x20]
000078eb87dd60c3  movups xmm1, [r13+r14*1]
000078eb87dd60c9  movaps [r15+0x110], xmm1
000078eb87dd60d1  vmovaps xmm14, [rsp+0x70]
000078eb87dd60d7  vmovaps [rsp+0x70], xmm1
000078eb87dd60dd  movaps xmm15, xmm14
000078eb87dd60e1  addpd xmm15, xmm4
000078eb87dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87dd60ec  ptest xmm1, xmm1
000078eb87dd60f1  jnz 0x000078EB87DD88BC
000078eb87dd60f7  vmovaps xmm1, [rsp+0x60]
000078eb87dd60fd  vpermilpd xmm1, xmm1, 0x00
000078eb87dd6103  movaps xmm14, xmm2
000078eb87dd6107  mulpd xmm14, xmm1
000078eb87dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000078eb87dd6112  ptest xmm4, xmm4
000078eb87dd6117  jnz 0x000078EB87DD89FF
000078eb87dd611d  vmovaps xmm4, [rsp+0x50]
000078eb87dd6123  movaps xmm1, xmm4
000078eb87dd6126  addpd xmm1, xmm9
000078eb87dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000078eb87dd6130  ptest xmm2, xmm2
000078eb87dd6135  jnz 0x000078EB87DD8B41
000078eb87dd613b  vmovaps xmm9, [rsp+0x30]
000078eb87dd6141  vpermilpd xmm9, xmm9, 0x00
000078eb87dd6147  vmovaps xmm2, [rsp+0x70]
000078eb87dd614d  vmovaps [rsp+0x50], xmm1
000078eb87dd6153  movaps xmm4, xmm2
000078eb87dd6156  mulpd xmm4, xmm9
000078eb87dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000078eb87dd6160  ptest xmm1, xmm1
000078eb87dd6165  jnz 0x000078EB87DD8C82
000078eb87dd616b  vmovaps xmm1, [rsp+0x30]
000078eb87dd6171  vpermilpd xmm1, xmm1, 0x00
000078eb87dd6177  vmovaps xmm2, [rsp+0x90]
000078eb87dd6180  vmovaps [rsp+0x60], xmm15
000078eb87dd6186  movaps xmm9, xmm2
000078eb87dd618a  mulpd xmm9, xmm1
000078eb87dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000078eb87dd6195  ptest xmm15, xmm15
000078eb87dd619b  jnz 0x000078EB87DD8DC3
000078eb87dd61a1  vmovaps xmm15, [rsp+0x80]
000078eb87dd61aa  movaps xmm1, xmm15
000078eb87dd61ae  addpd xmm1, xmm6
000078eb87dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000078eb87dd61b7  ptest xmm2, xmm2
000078eb87dd61bc  jnz 0x000078EB87DD8F05
000078eb87dd61c2  movaps xmm15, xmm5
000078eb87dd61c6  addpd xmm15, xmm3
000078eb87dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000078eb87dd61d1  ptest xmm6, xmm6
000078eb87dd61d6  jnz 0x000078EB87DD9046
000078eb87dd61dc  vmovaps xmm6, [rsp+0x30]
000078eb87dd61e2  vpermilpd xmm6, xmm6, 0x00
000078eb87dd61e8  movaps xmm5, xmm8
000078eb87dd61ec  mulpd xmm5, xmm6
000078eb87dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000078eb87dd61f5  ptest xmm3, xmm3
000078eb87dd61fa  jnz 0x000078EB87DD9188
000078eb87dd6200  vmovaps xmm8, [rsp+0x30]
000078eb87dd6206  vpermilpd xmm8, xmm8, 0x00
000078eb87dd620c  movaps xmm6, xmm10
000078eb87dd6210  mulpd xmm6, xmm8
000078eb87dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000078eb87dd621a  ptest xmm3, xmm3
000078eb87dd621f  jnz 0x000078EB87DD92C9
000078eb87dd6225  vmovaps xmm8, [rsp+0x60]
000078eb87dd622b  movaps xmm10, xmm8
000078eb87dd622f  addpd xmm10, xmm14
000078eb87dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000078eb87dd623a  ptest xmm3, xmm3
000078eb87dd623f  jnz 0x000078EB87DD940B
000078eb87dd6245  vmovaps xmm8, [rsp+0x50]
000078eb87dd624b  movaps xmm14, xmm8
000078eb87dd624f  addpd xmm14, xmm4
000078eb87dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000078eb87dd625a  ptest xmm3, xmm3
000078eb87dd625f  jnz 0x000078EB87DD954F
000078eb87dd6265  vmovaps xmm8, [rsp+0x40]
000078eb87dd626b  vpermilpd xmm8, xmm8, 0x00
000078eb87dd6271  movaps xmm4, xmm13
000078eb87dd6275  mulpd xmm4, xmm8
000078eb87dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000078eb87dd627f  ptest xmm3, xmm3
000078eb87dd6284  jnz 0x000078EB87DD9692
000078eb87dd628a  movaps xmm13, xmm15
000078eb87dd628e  addpd xmm13, xmm9
000078eb87dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000078eb87dd6299  ptest xmm8, xmm8
000078eb87dd629f  jnz 0x000078EB87DD97D4
000078eb87dd62a5  movaps xmm15, xmm1
000078eb87dd62a9  addpd xmm15, xmm5
000078eb87dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000078eb87dd62b4  ptest xmm9, xmm9
000078eb87dd62ba  jnz 0x000078EB87DD9918
000078eb87dd62c0  vmovaps [rsp+0x30], xmm11
000078eb87dd62c6  vmovaps xmm1, [rsp+0x30]
000078eb87dd62cc  por xmm11, xmm1
000078eb87dd62d1  movaps [r15+0x250], xmm11
000078eb87dd62d9  vmovaps [rsp+0x30], xmm12
000078eb87dd62df  vmovaps xmm1, [rsp+0x30]
000078eb87dd62e5  por xmm12, xmm1
000078eb87dd62ea  movaps [r15+0x2A0], xmm12
000078eb87dd62f2  vmovaps xmm1, [rsp+0xA0]
000078eb87dd62fb  vmovaps xmm11, [rsp+0xA0]
000078eb87dd6304  por xmm1, xmm11
000078eb87dd6309  movaps [r15+0x1D0], xmm1
000078eb87dd6311  lea r14, [rax+0x40]
000078eb87dd6315  movups xmm1, [r13+r14*1]
000078eb87dd631b  movaps [r15+0x2C0], xmm1
000078eb87dd6323  vmovaps xmm11, [rsp+0x40]
000078eb87dd6329  vpermilpd xmm11, xmm11, 0x00
000078eb87dd632f  vmovaps xmm8, [rsp+0xE0]
000078eb87dd6338  movaps xmm9, xmm8
000078eb87dd633c  mulpd xmm9, xmm11
000078eb87dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000078eb87dd6347  ptest xmm5, xmm5
000078eb87dd634c  jnz 0x000078EB87DD9A64
000078eb87dd6352  movaps xmm11, xmm10
000078eb87dd6356  addpd xmm11, xmm6
000078eb87dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000078eb87dd6361  ptest xmm8, xmm8
000078eb87dd6367  jnz 0x000078EB87DD9BA8
000078eb87dd636d  movaps xmm10, xmm14
000078eb87dd6371  addpd xmm10, xmm4
000078eb87dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000078eb87dd637c  ptest xmm8, xmm8
000078eb87dd6382  jnz 0x000078EB87DD9CEB
000078eb87dd6388  vmovaps xmm14, [rsp+0x40]
000078eb87dd638e  vpermilpd xmm14, xmm14, 0x00
000078eb87dd6394  movaps xmm8, xmm1
000078eb87dd6398  mulpd xmm8, xmm14
000078eb87dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000078eb87dd63a3  ptest xmm6, xmm6
000078eb87dd63a8  jnz 0x000078EB87DD9E2E
000078eb87dd63ae  movaps xmm1, [r15+0x2B0]
000078eb87dd63b6  vmovaps xmm14, [rsp+0x40]
000078eb87dd63bc  vpermilpd xmm14, xmm14, 0x00
000078eb87dd63c2  movaps xmm6, xmm1
000078eb87dd63c5  mulpd xmm6, xmm14
000078eb87dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000078eb87dd63cf  ptest xmm5, xmm5
000078eb87dd63d4  jnz 0x000078EB87DD9F71
000078eb87dd63da  vmovaps xmm1, [rsp+0x10]
000078eb87dd63e0  vpermilpd xmm1, xmm1, 0x00
000078eb87dd63e6  movaps xmm14, xmm12
000078eb87dd63ea  mulpd xmm14, xmm1
000078eb87dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000078eb87dd63f5  ptest xmm5, xmm5
000078eb87dd63fa  jnz 0x000078EB87DDA0B2
000078eb87dd6400  movaps xmm1, xmm13
000078eb87dd6404  addpd xmm1, xmm9
000078eb87dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000078eb87dd640e  ptest xmm12, xmm12
000078eb87dd6414  jnz 0x000078EB87DDA1F5
000078eb87dd641a  vmovaps xmm13, [rsp+0x10]
000078eb87dd6420  vpermilpd xmm13, xmm13, 0x00
000078eb87dd6426  movaps xmm12, xmm7
000078eb87dd642a  mulpd xmm12, xmm13
000078eb87dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000078eb87dd6435  ptest xmm9, xmm9
000078eb87dd643b  jnz 0x000078EB87DDA337
000078eb87dd6441  movaps xmm13, xmm15
000078eb87dd6445  addpd xmm13, xmm8
000078eb87dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000078eb87dd6450  ptest xmm9, xmm9
000078eb87dd6456  jnz 0x000078EB87DDA47A
000078eb87dd645c  movaps xmm15, [r15+0x290]
000078eb87dd6464  vmovaps xmm9, [rsp+0x10]
000078eb87dd646a  vpermilpd xmm9, xmm9, 0x00
000078eb87dd6470  movaps xmm8, xmm15
000078eb87dd6474  mulpd xmm8, xmm9
000078eb87dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000078eb87dd647f  ptest xmm7, xmm7
000078eb87dd6484  jnz 0x000078EB87DDA5BE
000078eb87dd648a  movaps xmm15, xmm11
000078eb87dd648e  addpd xmm15, xmm6
000078eb87dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000078eb87dd6499  ptest xmm9, xmm9
000078eb87dd649f  jnz 0x000078EB87DDA702
000078eb87dd64a5  movaps xmm11, [r15+0x1E0]
000078eb87dd64ad  vmovaps xmm9, [rsp+0x10]
000078eb87dd64b3  vpermilpd xmm9, xmm9, 0x00
000078eb87dd64b9  movaps xmm7, xmm11
000078eb87dd64bd  mulpd xmm7, xmm9
000078eb87dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000078eb87dd64c7  ptest xmm6, xmm6
000078eb87dd64cc  jnz 0x000078EB87DDA845
000078eb87dd64d2  movaps xmm11, xmm10
000078eb87dd64d6  addpd xmm11, xmm14
000078eb87dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000078eb87dd64e1  ptest xmm9, xmm9
000078eb87dd64e7  jnz 0x000078EB87DDA987
000078eb87dd64ed  lea r14, [rax+0x70]
000078eb87dd64f1  movups xmm14, [r13+r14*1]
000078eb87dd64f7  movaps [r15+0x240], xmm14
000078eb87dd64ff  movaps xmm10, xmm1
000078eb87dd6503  addpd xmm10, xmm12
000078eb87dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000078eb87dd650e  ptest xmm9, xmm9
000078eb87dd6514  jnz 0x000078EB87DDAAD5
000078eb87dd651a  movaps [r15+0x170], xmm10
000078eb87dd6522  vmovaps xmm1, [rsp+0x20]
000078eb87dd6528  vpermilpd xmm1, xmm1, 0x00
000078eb87dd652e  movaps xmm12, xmm14
000078eb87dd6532  mulpd xmm12, xmm1
000078eb87dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000078eb87dd653d  ptest xmm9, xmm9
000078eb87dd6543  jnz 0x000078EB87DDAC18
000078eb87dd6549  vmovaps xmm1, [rsp+0x20]
000078eb87dd654f  vpermilpd xmm1, xmm1, 0x00
000078eb87dd6555  vmovaps xmm9, [rsp+0xB0]
000078eb87dd655e  movaps xmm14, xmm9
000078eb87dd6562  mulpd xmm14, xmm1
000078eb87dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000078eb87dd656d  ptest xmm6, xmm6
000078eb87dd6572  jnz 0x000078EB87DDAD5B
000078eb87dd6578  movaps [r15+0x180], xmm14
000078eb87dd6580  movaps xmm1, xmm13
000078eb87dd6584  addpd xmm1, xmm8
000078eb87dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000078eb87dd658e  ptest xmm9, xmm9
000078eb87dd6594  jnz 0x000078EB87DDAE9E
000078eb87dd659a  movaps [r15+0x210], xmm1
000078eb87dd65a2  movups xmm13, [r13+rax*1]
000078eb87dd65a8  lea r14, [rax+0x10]
000078eb87dd65ac  movups xmm9, [r13+r14*1]
000078eb87dd65b2  movaps [r15+0x230], xmm9
000078eb87dd65ba  movaps xmm8, xmm15
000078eb87dd65be  addpd xmm8, xmm7
000078eb87dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000078eb87dd65c9  ptest xmm6, xmm6
000078eb87dd65ce  jnz 0x000078EB87DDAFF4
000078eb87dd65d4  movaps [r15+0x130], xmm8
000078eb87dd65dc  vmovaps xmm15, [rsp+0x20]
000078eb87dd65e2  vpermilpd xmm15, xmm15, 0x00
000078eb87dd65e8  movaps xmm7, xmm9
000078eb87dd65ec  mulpd xmm7, xmm15
000078eb87dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000078eb87dd65f6  ptest xmm6, xmm6
000078eb87dd65fb  jnz 0x000078EB87DDB137
000078eb87dd6601  movaps [r15+0x220], xmm7
000078eb87dd6609  vmovaps xmm15, [rsp+0x20]
000078eb87dd660f  vpermilpd xmm15, xmm15, 0x00
000078eb87dd6615  movaps xmm9, xmm13
000078eb87dd6619  mulpd xmm9, xmm15
000078eb87dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000078eb87dd6624  ptest xmm6, xmm6
000078eb87dd6629  jnz 0x000078EB87DDB279
000078eb87dd662f  movaps xmm15, xmm11
000078eb87dd6633  addpd xmm15, xmm12
000078eb87dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000078eb87dd663e  ptest xmm13, xmm13
000078eb87dd6644  jnz 0x000078EB87DDB3BD
000078eb87dd664a  movaps [r15+0x140], xmm15
000078eb87dd6652  movaps xmm13, xmm10
000078eb87dd6656  addpd xmm13, xmm14
000078eb87dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000078eb87dd6661  ptest xmm12, xmm12
000078eb87dd6667  jnz 0x000078EB87DDB501
000078eb87dd666d  movaps [r15+0x150], xmm13
000078eb87dd6675  movaps xmm14, xmm1
000078eb87dd6679  addpd xmm14, xmm7
000078eb87dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000078eb87dd6684  ptest xmm12, xmm12
000078eb87dd668a  jnz 0x000078EB87DDB645
000078eb87dd6690  movaps [r15+0x160], xmm14
000078eb87dd6698  movaps xmm1, xmm8
000078eb87dd669c  addpd xmm1, xmm9
000078eb87dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000078eb87dd66a6  ptest xmm12, xmm12
000078eb87dd66ac  jnz 0x000078EB87DDB787
000078eb87dd66b2  movaps [r15+0x120], xmm1
000078eb87dd66ba  movups [r13+r11*1], xmm15
000078eb87dd66c0  lea rax, [r11+0x10]
000078eb87dd66c4  movups [r13+rax*1], xmm13
000078eb87dd66ca  lea rax, [r11+0x20]
000078eb87dd66ce  movups [r13+rax*1], xmm14
000078eb87dd66d4  lea rax, [r11+0x30]
000078eb87dd66d8  movups [r13+rax*1], xmm1
000078eb87dd66de  mov eax, [r15+0x108]
000078eb87dd66e5  sahf
000078eb87dd66e6  jnz 0x000078EB87DD6718
000078eb87dd66e8  cmp dword ptr [r15+0x318], 0x00
000078eb87dd66f0  jz 0x000078EB87DDB900
000078eb87dd66f6  nop [rax+rax*1], ax
000078eb87dd66ff  nop [rax+rax*1], eax
000078eb87dd6707  mov eax, 0x410444
000078eb87dd670c  mov [r15+0x100], rax
000078eb87dd6713  jmp 0x000078EB87BFE110
000078eb87dd6718  cmp dword ptr [r15+0x318], 0x00
000078eb87dd6720  jz 0x000078EB87DD57E0
000078eb87dd6726  nop [rax+rax*1], ax
000078eb87dd672f  nop [rax+rax*1], eax
000078eb87dd6737  mov eax, 0x410278
000078eb87dd673c  mov [r15+0x100], rax
000078eb87dd6743  jmp 0x000078EB87BFE110
000078eb87dd6748  int3
000078eb87dd6749  call 0x000078EB87C0A4B0
000078eb87dd674e  jmp 0x000078EB87DD5828
000078eb87dd6753  call 0x000078EB87C09240
000078eb87dd6758  jmp 0x000078EB87DD5832
000078eb87dd675d  call 0x000078EB87C0A4B0
000078eb87dd6762  jmp 0x000078EB87DD588F
000078eb87dd6767  call 0x000078EB87C09240
000078eb87dd676c  jmp 0x000078EB87DD5899
000078eb87dd6771  call 0x000078EB87C0A4B0
000078eb87dd6776  jmp 0x000078EB87DD58DD
000078eb87dd677b  call 0x000078EB87C09240
000078eb87dd6780  jmp 0x000078EB87DD58E7
000078eb87dd6785  call 0x000078EB87CB47C0
000078eb87dd678a  jmp 0x000078EB87DD5926
000078eb87dd678f  call 0x000078EB87C0B720
000078eb87dd6794  jmp 0x000078EB87DD593A
000078eb87dd6799  call 0x000078EB87CBFC30
000078eb87dd679e  jmp 0x000078EB87DD5958
000078eb87dd67a3  call 0x000078EB87CBE9C0
000078eb87dd67a8  jmp 0x000078EB87DD5962
000078eb87dd67ad  call 0x000078EB87CBD750
000078eb87dd67b2  jmp 0x000078EB87DD596C
000078eb87dd67b7  sub rsp, 0x08
000078eb87dd67bb  push rax
000078eb87dd67bc  push rcx
000078eb87dd67bd  push rdx
000078eb87dd67be  push rdi
000078eb87dd67bf  push rsi
000078eb87dd67c0  push r8
000078eb87dd67c2  push r9
000078eb87dd67c4  push r10
000078eb87dd67c6  push r11
000078eb87dd67c8  sub rsp, 0xF0
000078eb87dd67cf  vmovaps [rsp], xmm0
000078eb87dd67d4  vmovaps [rsp+0x10], xmm1
000078eb87dd67da  vmovaps [rsp+0x20], xmm2
000078eb87dd67e0  vmovaps [rsp+0x30], xmm3
000078eb87dd67e6  vmovaps [rsp+0x40], xmm4
000078eb87dd67ec  vmovaps [rsp+0x50], xmm5
000078eb87dd67f2  vmovaps [rsp+0x60], xmm6
000078eb87dd67f8  vmovaps [rsp+0x70], xmm7
000078eb87dd67fe  vmovaps [rsp+0x80], xmm9
000078eb87dd6807  vmovaps [rsp+0x90], xmm10
000078eb87dd6810  vmovaps [rsp+0xA0], xmm11
000078eb87dd6819  vmovaps [rsp+0xB0], xmm12
000078eb87dd6822  vmovaps [rsp+0xC0], xmm13
000078eb87dd682b  vmovaps [rsp+0xD0], xmm14
000078eb87dd6834  vmovaps [rsp+0xE0], xmm15
000078eb87dd683d  sub rsp, 0x30
000078eb87dd6841  movaps [rsp], xmm8
000078eb87dd6846  movaps [rsp+0x10], xmm12
000078eb87dd684c  movaps [rsp+0x20], xmm15
000078eb87dd6852  lea rdi, [rsp]
000078eb87dd6856  mov esi, 0x00
000078eb87dd685b  mov rax, 0x61D341A71530
000078eb87dd6865  call rax
000078eb87dd6867  movaps xmm8, [rsp]
000078eb87dd686c  add rsp, 0x30
000078eb87dd6870  vmovaps xmm0, [rsp]
000078eb87dd6875  vmovaps xmm1, [rsp+0x10]
000078eb87dd687b  vmovaps xmm2, [rsp+0x20]
000078eb87dd6881  vmovaps xmm3, [rsp+0x30]
000078eb87dd6887  vmovaps xmm4, [rsp+0x40]
000078eb87dd688d  vmovaps xmm5, [rsp+0x50]
000078eb87dd6893  vmovaps xmm6, [rsp+0x60]
000078eb87dd6899  vmovaps xmm7, [rsp+0x70]
000078eb87dd689f  vmovaps xmm9, [rsp+0x80]
000078eb87dd68a8  vmovaps xmm10, [rsp+0x90]
000078eb87dd68b1  vmovaps xmm11, [rsp+0xA0]
000078eb87dd68ba  vmovaps xmm12, [rsp+0xB0]
000078eb87dd68c3  vmovaps xmm13, [rsp+0xC0]
000078eb87dd68cc  vmovaps xmm14, [rsp+0xD0]
000078eb87dd68d5  vmovaps xmm15, [rsp+0xE0]
000078eb87dd68de  add rsp, 0xF0
000078eb87dd68e5  pop r11
000078eb87dd68e7  pop r10
000078eb87dd68e9  pop r9
000078eb87dd68eb  pop r8
000078eb87dd68ed  pop rsi
000078eb87dd68ee  pop rdi
000078eb87dd68ef  pop rdx
000078eb87dd68f0  pop rcx
000078eb87dd68f1  pop rax
000078eb87dd68f2  add rsp, 0x08
000078eb87dd68f6  jmp 0x000078EB87DD599A
000078eb87dd68fb  sub rsp, 0x08
000078eb87dd68ff  push rax
000078eb87dd6900  push rcx
000078eb87dd6901  push rdx
000078eb87dd6902  push rdi
000078eb87dd6903  push rsi
000078eb87dd6904  push r8
000078eb87dd6906  push r9
000078eb87dd6908  push r10
000078eb87dd690a  push r11
000078eb87dd690c  sub rsp, 0xF0
000078eb87dd6913  vmovaps [rsp], xmm0
000078eb87dd6918  vmovaps [rsp+0x10], xmm1
000078eb87dd691e  vmovaps [rsp+0x20], xmm2
000078eb87dd6924  vmovaps [rsp+0x30], xmm3
000078eb87dd692a  vmovaps [rsp+0x40], xmm4
000078eb87dd6930  vmovaps [rsp+0x50], xmm5
000078eb87dd6936  vmovaps [rsp+0x60], xmm6
000078eb87dd693c  vmovaps [rsp+0x70], xmm8
000078eb87dd6942  vmovaps [rsp+0x80], xmm9
000078eb87dd694b  vmovaps [rsp+0x90], xmm10
000078eb87dd6954  vmovaps [rsp+0xA0], xmm11
000078eb87dd695d  vmovaps [rsp+0xB0], xmm12
000078eb87dd6966  vmovaps [rsp+0xC0], xmm13
000078eb87dd696f  vmovaps [rsp+0xD0], xmm14
000078eb87dd6978  vmovaps [rsp+0xE0], xmm15
000078eb87dd6981  sub rsp, 0x30
000078eb87dd6985  movaps [rsp], xmm7
000078eb87dd6989  movaps [rsp+0x10], xmm9
000078eb87dd698f  movaps [rsp+0x20], xmm15
000078eb87dd6995  lea rdi, [rsp]
000078eb87dd6999  mov esi, 0x00
000078eb87dd699e  mov rax, 0x61D341A71530
000078eb87dd69a8  call rax
000078eb87dd69aa  movaps xmm7, [rsp]
000078eb87dd69ae  add rsp, 0x30
000078eb87dd69b2  vmovaps xmm0, [rsp]
000078eb87dd69b7  vmovaps xmm1, [rsp+0x10]
000078eb87dd69bd  vmovaps xmm2, [rsp+0x20]
000078eb87dd69c3  vmovaps xmm3, [rsp+0x30]
000078eb87dd69c9  vmovaps xmm4, [rsp+0x40]
000078eb87dd69cf  vmovaps xmm5, [rsp+0x50]
000078eb87dd69d5  vmovaps xmm6, [rsp+0x60]
000078eb87dd69db  vmovaps xmm8, [rsp+0x70]
000078eb87dd69e1  vmovaps xmm9, [rsp+0x80]
000078eb87dd69ea  vmovaps xmm10, [rsp+0x90]
000078eb87dd69f3  vmovaps xmm11, [rsp+0xA0]
000078eb87dd69fc  vmovaps xmm12, [rsp+0xB0]
000078eb87dd6a05  vmovaps xmm13, [rsp+0xC0]
000078eb87dd6a0e  vmovaps xmm14, [rsp+0xD0]
000078eb87dd6a17  vmovaps xmm15, [rsp+0xE0]
000078eb87dd6a20  add rsp, 0xF0
000078eb87dd6a27  pop r11
000078eb87dd6a29  pop r10
000078eb87dd6a2b  pop r9
000078eb87dd6a2d  pop r8
000078eb87dd6a2f  pop rsi
000078eb87dd6a30  pop rdi
000078eb87dd6a31  pop rdx
000078eb87dd6a32  pop rcx
000078eb87dd6a33  pop rax
000078eb87dd6a34  add rsp, 0x08
000078eb87dd6a38  jmp 0x000078EB87DD59C8
000078eb87dd6a3d  sub rsp, 0x08
000078eb87dd6a41  push rax
000078eb87dd6a42  push rcx
000078eb87dd6a43  push rdx
000078eb87dd6a44  push rdi
000078eb87dd6a45  push rsi
000078eb87dd6a46  push r8
000078eb87dd6a48  push r9
000078eb87dd6a4a  push r10
000078eb87dd6a4c  push r11
000078eb87dd6a4e  sub rsp, 0xF0
000078eb87dd6a55  vmovaps [rsp], xmm0
000078eb87dd6a5a  vmovaps [rsp+0x10], xmm1
000078eb87dd6a60  vmovaps [rsp+0x20], xmm2
000078eb87dd6a66  vmovaps [rsp+0x30], xmm3
000078eb87dd6a6c  vmovaps [rsp+0x40], xmm4
000078eb87dd6a72  vmovaps [rsp+0x50], xmm5
000078eb87dd6a78  vmovaps [rsp+0x60], xmm6
000078eb87dd6a7e  vmovaps [rsp+0x70], xmm7
000078eb87dd6a84  vmovaps [rsp+0x80], xmm8
000078eb87dd6a8d  vmovaps [rsp+0x90], xmm10
000078eb87dd6a96  vmovaps [rsp+0xA0], xmm11
000078eb87dd6a9f  vmovaps [rsp+0xB0], xmm12
000078eb87dd6aa8  vmovaps [rsp+0xC0], xmm13
000078eb87dd6ab1  vmovaps [rsp+0xD0], xmm14
000078eb87dd6aba  vmovaps [rsp+0xE0], xmm15
000078eb87dd6ac3  sub rsp, 0x30
000078eb87dd6ac7  movaps [rsp], xmm9
000078eb87dd6acc  movaps [rsp+0x10], xmm12
000078eb87dd6ad2  movaps [rsp+0x20], xmm10
000078eb87dd6ad8  lea rdi, [rsp]
000078eb87dd6adc  mov esi, 0x00
000078eb87dd6ae1  mov rax, 0x61D341A71530
000078eb87dd6aeb  call rax
000078eb87dd6aed  movaps xmm9, [rsp]
000078eb87dd6af2  add rsp, 0x30
000078eb87dd6af6  vmovaps xmm0, [rsp]
000078eb87dd6afb  vmovaps xmm1, [rsp+0x10]
000078eb87dd6b01  vmovaps xmm2, [rsp+0x20]
000078eb87dd6b07  vmovaps xmm3, [rsp+0x30]
000078eb87dd6b0d  vmovaps xmm4, [rsp+0x40]
000078eb87dd6b13  vmovaps xmm5, [rsp+0x50]
000078eb87dd6b19  vmovaps xmm6, [rsp+0x60]
000078eb87dd6b1f  vmovaps xmm7, [rsp+0x70]
000078eb87dd6b25  vmovaps xmm8, [rsp+0x80]
000078eb87dd6b2e  vmovaps xmm10, [rsp+0x90]
000078eb87dd6b37  vmovaps xmm11, [rsp+0xA0]
000078eb87dd6b40  vmovaps xmm12, [rsp+0xB0]
000078eb87dd6b49  vmovaps xmm13, [rsp+0xC0]
000078eb87dd6b52  vmovaps xmm14, [rsp+0xD0]
000078eb87dd6b5b  vmovaps xmm15, [rsp+0xE0]
000078eb87dd6b64  add rsp, 0xF0
000078eb87dd6b6b  pop r11
000078eb87dd6b6d  pop r10
000078eb87dd6b6f  pop r9
000078eb87dd6b71  pop r8
000078eb87dd6b73  pop rsi
000078eb87dd6b74  pop rdi
000078eb87dd6b75  pop rdx
000078eb87dd6b76  pop rcx
000078eb87dd6b77  pop rax
000078eb87dd6b78  add rsp, 0x08
000078eb87dd6b7c  jmp 0x000078EB87DD59EC
000078eb87dd6b81  sub rsp, 0x08
000078eb87dd6b85  push rax
000078eb87dd6b86  push rcx
000078eb87dd6b87  push rdx
000078eb87dd6b88  push rdi
000078eb87dd6b89  push rsi
000078eb87dd6b8a  push r8
000078eb87dd6b8c  push r9
000078eb87dd6b8e  push r10
000078eb87dd6b90  push r11
000078eb87dd6b92  sub rsp, 0xF0
000078eb87dd6b99  vmovaps [rsp], xmm0
000078eb87dd6b9e  vmovaps [rsp+0x10], xmm1
000078eb87dd6ba4  vmovaps [rsp+0x20], xmm2
000078eb87dd6baa  vmovaps [rsp+0x30], xmm3
000078eb87dd6bb0  vmovaps [rsp+0x40], xmm4
000078eb87dd6bb6  vmovaps [rsp+0x50], xmm5
000078eb87dd6bbc  vmovaps [rsp+0x60], xmm6
000078eb87dd6bc2  vmovaps [rsp+0x70], xmm7
000078eb87dd6bc8  vmovaps [rsp+0x80], xmm8
000078eb87dd6bd1  vmovaps [rsp+0x90], xmm9
000078eb87dd6bda  vmovaps [rsp+0xA0], xmm11
000078eb87dd6be3  vmovaps [rsp+0xB0], xmm12
000078eb87dd6bec  vmovaps [rsp+0xC0], xmm13
000078eb87dd6bf5  vmovaps [rsp+0xD0], xmm14
000078eb87dd6bfe  vmovaps [rsp+0xE0], xmm15
000078eb87dd6c07  sub rsp, 0x30
000078eb87dd6c0b  movaps [rsp], xmm10
000078eb87dd6c10  movaps [rsp+0x10], xmm12
000078eb87dd6c16  movaps [rsp+0x20], xmm11
000078eb87dd6c1c  lea rdi, [rsp]
000078eb87dd6c20  mov esi, 0x00
000078eb87dd6c25  mov rax, 0x61D341A71530
000078eb87dd6c2f  call rax
000078eb87dd6c31  movaps xmm10, [rsp]
000078eb87dd6c36  add rsp, 0x30
000078eb87dd6c3a  vmovaps xmm0, [rsp]
000078eb87dd6c3f  vmovaps xmm1, [rsp+0x10]
000078eb87dd6c45  vmovaps xmm2, [rsp+0x20]
000078eb87dd6c4b  vmovaps xmm3, [rsp+0x30]
000078eb87dd6c51  vmovaps xmm4, [rsp+0x40]
000078eb87dd6c57  vmovaps xmm5, [rsp+0x50]
000078eb87dd6c5d  vmovaps xmm6, [rsp+0x60]
000078eb87dd6c63  vmovaps xmm7, [rsp+0x70]
000078eb87dd6c69  vmovaps xmm8, [rsp+0x80]
000078eb87dd6c72  vmovaps xmm9, [rsp+0x90]
000078eb87dd6c7b  vmovaps xmm11, [rsp+0xA0]
000078eb87dd6c84  vmovaps xmm12, [rsp+0xB0]
000078eb87dd6c8d  vmovaps xmm13, [rsp+0xC0]
000078eb87dd6c96  vmovaps xmm14, [rsp+0xD0]
000078eb87dd6c9f  vmovaps xmm15, [rsp+0xE0]
000078eb87dd6ca8  add rsp, 0xF0
000078eb87dd6caf  pop r11
000078eb87dd6cb1  pop r10
000078eb87dd6cb3  pop r9
000078eb87dd6cb5  pop r8
000078eb87dd6cb7  pop rsi
000078eb87dd6cb8  pop rdi
000078eb87dd6cb9  pop rdx
000078eb87dd6cba  pop rcx
000078eb87dd6cbb  pop rax
000078eb87dd6cbc  add rsp, 0x08
000078eb87dd6cc0  jmp 0x000078EB87DD5A06
000078eb87dd6cc5  sub rsp, 0x08
000078eb87dd6cc9  push rax
000078eb87dd6cca  push rcx
000078eb87dd6ccb  push rdx
000078eb87dd6ccc  push rdi
000078eb87dd6ccd  push rsi
000078eb87dd6cce  push r8
000078eb87dd6cd0  push r9
000078eb87dd6cd2  push r10
000078eb87dd6cd4  push r11
000078eb87dd6cd6  sub rsp, 0xF0
000078eb87dd6cdd  vmovaps [rsp], xmm0
000078eb87dd6ce2  vmovaps [rsp+0x10], xmm1
000078eb87dd6ce8  vmovaps [rsp+0x20], xmm2
000078eb87dd6cee  vmovaps [rsp+0x30], xmm3
000078eb87dd6cf4  vmovaps [rsp+0x40], xmm4
000078eb87dd6cfa  vmovaps [rsp+0x50], xmm5
000078eb87dd6d00  vmovaps [rsp+0x60], xmm7
000078eb87dd6d06  vmovaps [rsp+0x70], xmm8
000078eb87dd6d0c  vmovaps [rsp+0x80], xmm9
000078eb87dd6d15  vmovaps [rsp+0x90], xmm10
000078eb87dd6d1e  vmovaps [rsp+0xA0], xmm11
000078eb87dd6d27  vmovaps [rsp+0xB0], xmm12
000078eb87dd6d30  vmovaps [rsp+0xC0], xmm13
000078eb87dd6d39  vmovaps [rsp+0xD0], xmm14
000078eb87dd6d42  vmovaps [rsp+0xE0], xmm15
000078eb87dd6d4b  sub rsp, 0x30
000078eb87dd6d4f  movaps [rsp], xmm6
000078eb87dd6d53  movaps [rsp+0x10], xmm12
000078eb87dd6d59  movaps [rsp+0x20], xmm11
000078eb87dd6d5f  lea rdi, [rsp]
000078eb87dd6d63  mov esi, 0x00
000078eb87dd6d68  mov rax, 0x61D341A71530
000078eb87dd6d72  call rax
000078eb87dd6d74  movaps xmm6, [rsp]
000078eb87dd6d78  add rsp, 0x30
000078eb87dd6d7c  vmovaps xmm0, [rsp]
000078eb87dd6d81  vmovaps xmm1, [rsp+0x10]
000078eb87dd6d87  vmovaps xmm2, [rsp+0x20]
000078eb87dd6d8d  vmovaps xmm3, [rsp+0x30]
000078eb87dd6d93  vmovaps xmm4, [rsp+0x40]
000078eb87dd6d99  vmovaps xmm5, [rsp+0x50]
000078eb87dd6d9f  vmovaps xmm7, [rsp+0x60]
000078eb87dd6da5  vmovaps xmm8, [rsp+0x70]
000078eb87dd6dab  vmovaps xmm9, [rsp+0x80]
000078eb87dd6db4  vmovaps xmm10, [rsp+0x90]
000078eb87dd6dbd  vmovaps xmm11, [rsp+0xA0]
000078eb87dd6dc6  vmovaps xmm12, [rsp+0xB0]
000078eb87dd6dcf  vmovaps xmm13, [rsp+0xC0]
000078eb87dd6dd8  vmovaps xmm14, [rsp+0xD0]
000078eb87dd6de1  vmovaps xmm15, [rsp+0xE0]
000078eb87dd6dea  add rsp, 0xF0
000078eb87dd6df1  pop r11
000078eb87dd6df3  pop r10
000078eb87dd6df5  pop r9
000078eb87dd6df7  pop r8
000078eb87dd6df9  pop rsi
000078eb87dd6dfa  pop rdi
000078eb87dd6dfb  pop rdx
000078eb87dd6dfc  pop rcx
000078eb87dd6dfd  pop rax
000078eb87dd6dfe  add rsp, 0x08
000078eb87dd6e02  jmp 0x000078EB87DD5A27
000078eb87dd6e07  sub rsp, 0x08
000078eb87dd6e0b  push rax
000078eb87dd6e0c  push rcx
000078eb87dd6e0d  push rdx
000078eb87dd6e0e  push rdi
000078eb87dd6e0f  push rsi
000078eb87dd6e10  push r8
000078eb87dd6e12  push r9
000078eb87dd6e14  push r10
000078eb87dd6e16  push r11
000078eb87dd6e18  sub rsp, 0xF0
000078eb87dd6e1f  vmovaps [rsp], xmm0
000078eb87dd6e24  vmovaps [rsp+0x10], xmm1
000078eb87dd6e2a  vmovaps [rsp+0x20], xmm2
000078eb87dd6e30  vmovaps [rsp+0x30], xmm4
000078eb87dd6e36  vmovaps [rsp+0x40], xmm5
000078eb87dd6e3c  vmovaps [rsp+0x50], xmm6
000078eb87dd6e42  vmovaps [rsp+0x60], xmm7
000078eb87dd6e48  vmovaps [rsp+0x70], xmm8
000078eb87dd6e4e  vmovaps [rsp+0x80], xmm9
000078eb87dd6e57  vmovaps [rsp+0x90], xmm10
000078eb87dd6e60  vmovaps [rsp+0xA0], xmm11
000078eb87dd6e69  vmovaps [rsp+0xB0], xmm12
000078eb87dd6e72  vmovaps [rsp+0xC0], xmm13
000078eb87dd6e7b  vmovaps [rsp+0xD0], xmm14
000078eb87dd6e84  vmovaps [rsp+0xE0], xmm15
000078eb87dd6e8d  sub rsp, 0x30
000078eb87dd6e91  movaps [rsp], xmm3
000078eb87dd6e95  movaps [rsp+0x10], xmm5
000078eb87dd6e9a  movaps [rsp+0x20], xmm4
000078eb87dd6e9f  lea rdi, [rsp]
000078eb87dd6ea3  mov esi, 0x00
000078eb87dd6ea8  mov rax, 0x61D341A71530
000078eb87dd6eb2  call rax
000078eb87dd6eb4  movaps xmm3, [rsp]
000078eb87dd6eb8  add rsp, 0x30
000078eb87dd6ebc  vmovaps xmm0, [rsp]
000078eb87dd6ec1  vmovaps xmm1, [rsp+0x10]
000078eb87dd6ec7  vmovaps xmm2, [rsp+0x20]
000078eb87dd6ecd  vmovaps xmm4, [rsp+0x30]
000078eb87dd6ed3  vmovaps xmm5, [rsp+0x40]
000078eb87dd6ed9  vmovaps xmm6, [rsp+0x50]
000078eb87dd6edf  vmovaps xmm7, [rsp+0x60]
000078eb87dd6ee5  vmovaps xmm8, [rsp+0x70]
000078eb87dd6eeb  vmovaps xmm9, [rsp+0x80]
000078eb87dd6ef4  vmovaps xmm10, [rsp+0x90]
000078eb87dd6efd  vmovaps xmm11, [rsp+0xA0]
000078eb87dd6f06  vmovaps xmm12, [rsp+0xB0]
000078eb87dd6f0f  vmovaps xmm13, [rsp+0xC0]
000078eb87dd6f18  vmovaps xmm14, [rsp+0xD0]
000078eb87dd6f21  vmovaps xmm15, [rsp+0xE0]
000078eb87dd6f2a  add rsp, 0xF0
000078eb87dd6f31  pop r11
000078eb87dd6f33  pop r10
000078eb87dd6f35  pop r9
000078eb87dd6f37  pop r8
000078eb87dd6f39  pop rsi
000078eb87dd6f3a  pop rdi
000078eb87dd6f3b  pop rdx
000078eb87dd6f3c  pop rcx
000078eb87dd6f3d  pop rax
000078eb87dd6f3e  add rsp, 0x08
000078eb87dd6f42  jmp 0x000078EB87DD5A88
000078eb87dd6f47  sub rsp, 0x08
000078eb87dd6f4b  push rax
000078eb87dd6f4c  push rcx
000078eb87dd6f4d  push rdx
000078eb87dd6f4e  push rdi
000078eb87dd6f4f  push rsi
000078eb87dd6f50  push r8
000078eb87dd6f52  push r9
000078eb87dd6f54  push r10
000078eb87dd6f56  push r11
000078eb87dd6f58  sub rsp, 0xF0
000078eb87dd6f5f  vmovaps [rsp], xmm0
000078eb87dd6f64  vmovaps [rsp+0x10], xmm1
000078eb87dd6f6a  vmovaps [rsp+0x20], xmm2
000078eb87dd6f70  vmovaps [rsp+0x30], xmm3
000078eb87dd6f76  vmovaps [rsp+0x40], xmm4
000078eb87dd6f7c  vmovaps [rsp+0x50], xmm6
000078eb87dd6f82  vmovaps [rsp+0x60], xmm7
000078eb87dd6f88  vmovaps [rsp+0x70], xmm8
000078eb87dd6f8e  vmovaps [rsp+0x80], xmm9
000078eb87dd6f97  vmovaps [rsp+0x90], xmm10
000078eb87dd6fa0  vmovaps [rsp+0xA0], xmm11
000078eb87dd6fa9  vmovaps [rsp+0xB0], xmm12
000078eb87dd6fb2  vmovaps [rsp+0xC0], xmm13
000078eb87dd6fbb  vmovaps [rsp+0xD0], xmm14
000078eb87dd6fc4  vmovaps [rsp+0xE0], xmm15
000078eb87dd6fcd  sub rsp, 0x30
000078eb87dd6fd1  movaps [rsp], xmm5
000078eb87dd6fd5  movaps [rsp+0x10], xmm8
000078eb87dd6fdb  movaps [rsp+0x20], xmm15
000078eb87dd6fe1  lea rdi, [rsp]
000078eb87dd6fe5  mov esi, 0x00
000078eb87dd6fea  mov rax, 0x61D341A71530
000078eb87dd6ff4  call rax
000078eb87dd6ff6  movaps xmm5, [rsp]
000078eb87dd6ffa  add rsp, 0x30
000078eb87dd6ffe  vmovaps xmm0, [rsp]
000078eb87dd7003  vmovaps xmm1, [rsp+0x10]
000078eb87dd7009  vmovaps xmm2, [rsp+0x20]
000078eb87dd700f  vmovaps xmm3, [rsp+0x30]
000078eb87dd7015  vmovaps xmm4, [rsp+0x40]
000078eb87dd701b  vmovaps xmm6, [rsp+0x50]
000078eb87dd7021  vmovaps xmm7, [rsp+0x60]
000078eb87dd7027  vmovaps xmm8, [rsp+0x70]
000078eb87dd702d  vmovaps xmm9, [rsp+0x80]
000078eb87dd7036  vmovaps xmm10, [rsp+0x90]
000078eb87dd703f  vmovaps xmm11, [rsp+0xA0]
000078eb87dd7048  vmovaps xmm12, [rsp+0xB0]
000078eb87dd7051  vmovaps xmm13, [rsp+0xC0]
000078eb87dd705a  vmovaps xmm14, [rsp+0xD0]
000078eb87dd7063  vmovaps xmm15, [rsp+0xE0]
000078eb87dd706c  add rsp, 0xF0
000078eb87dd7073  pop r11
000078eb87dd7075  pop r10
000078eb87dd7077  pop r9
000078eb87dd7079  pop r8
000078eb87dd707b  pop rsi
000078eb87dd707c  pop rdi
000078eb87dd707d  pop rdx
000078eb87dd707e  pop rcx
000078eb87dd707f  pop rax
000078eb87dd7080  add rsp, 0x08
000078eb87dd7084  jmp 0x000078EB87DD5AC0
000078eb87dd7089  sub rsp, 0x08
000078eb87dd708d  push rax
000078eb87dd708e  push rcx
000078eb87dd708f  push rdx
000078eb87dd7090  push rdi
000078eb87dd7091  push rsi
000078eb87dd7092  push r8
000078eb87dd7094  push r9
000078eb87dd7096  push r10
000078eb87dd7098  push r11
000078eb87dd709a  sub rsp, 0xF0
000078eb87dd70a1  vmovaps [rsp], xmm0
000078eb87dd70a6  vmovaps [rsp+0x10], xmm1
000078eb87dd70ac  vmovaps [rsp+0x20], xmm2
000078eb87dd70b2  vmovaps [rsp+0x30], xmm3
000078eb87dd70b8  vmovaps [rsp+0x40], xmm5
000078eb87dd70be  vmovaps [rsp+0x50], xmm6
000078eb87dd70c4  vmovaps [rsp+0x60], xmm7
000078eb87dd70ca  vmovaps [rsp+0x70], xmm8
000078eb87dd70d0  vmovaps [rsp+0x80], xmm9
000078eb87dd70d9  vmovaps [rsp+0x90], xmm10
000078eb87dd70e2  vmovaps [rsp+0xA0], xmm11
000078eb87dd70eb  vmovaps [rsp+0xB0], xmm12
000078eb87dd70f4  vmovaps [rsp+0xC0], xmm13
000078eb87dd70fd  vmovaps [rsp+0xD0], xmm14
000078eb87dd7106  vmovaps [rsp+0xE0], xmm15
000078eb87dd710f  sub rsp, 0x30
000078eb87dd7113  movaps [rsp], xmm4
000078eb87dd7117  movaps [rsp+0x10], xmm9
000078eb87dd711d  movaps [rsp+0x20], xmm8
000078eb87dd7123  lea rdi, [rsp]
000078eb87dd7127  mov esi, 0x00
000078eb87dd712c  mov rax, 0x61D341A71530
000078eb87dd7136  call rax
000078eb87dd7138  movaps xmm4, [rsp]
000078eb87dd713c  add rsp, 0x30
000078eb87dd7140  vmovaps xmm0, [rsp]
000078eb87dd7145  vmovaps xmm1, [rsp+0x10]
000078eb87dd714b  vmovaps xmm2, [rsp+0x20]
000078eb87dd7151  vmovaps xmm3, [rsp+0x30]
000078eb87dd7157  vmovaps xmm5, [rsp+0x40]
000078eb87dd715d  vmovaps xmm6, [rsp+0x50]
000078eb87dd7163  vmovaps xmm7, [rsp+0x60]
000078eb87dd7169  vmovaps xmm8, [rsp+0x70]
000078eb87dd716f  vmovaps xmm9, [rsp+0x80]
000078eb87dd7178  vmovaps xmm10, [rsp+0x90]
000078eb87dd7181  vmovaps xmm11, [rsp+0xA0]
000078eb87dd718a  vmovaps xmm12, [rsp+0xB0]
000078eb87dd7193  vmovaps xmm13, [rsp+0xC0]
000078eb87dd719c  vmovaps xmm14, [rsp+0xD0]
000078eb87dd71a5  vmovaps xmm15, [rsp+0xE0]
000078eb87dd71ae  add rsp, 0xF0
000078eb87dd71b5  pop r11
000078eb87dd71b7  pop r10
000078eb87dd71b9  pop r9
000078eb87dd71bb  pop r8
000078eb87dd71bd  pop rsi
000078eb87dd71be  pop rdi
000078eb87dd71bf  pop rdx
000078eb87dd71c0  pop rcx
000078eb87dd71c1  pop rax
000078eb87dd71c2  add rsp, 0x08
000078eb87dd71c6  jmp 0x000078EB87DD5AE1
000078eb87dd71cb  sub rsp, 0x08
000078eb87dd71cf  push rax
000078eb87dd71d0  push rcx
000078eb87dd71d1  push rdx
000078eb87dd71d2  push rdi
000078eb87dd71d3  push rsi
000078eb87dd71d4  push r8
000078eb87dd71d6  push r9
000078eb87dd71d8  push r10
000078eb87dd71da  push r11
000078eb87dd71dc  sub rsp, 0xF0
000078eb87dd71e3  vmovaps [rsp], xmm0
000078eb87dd71e8  vmovaps [rsp+0x10], xmm1
000078eb87dd71ee  vmovaps [rsp+0x20], xmm2
000078eb87dd71f4  vmovaps [rsp+0x30], xmm3
000078eb87dd71fa  vmovaps [rsp+0x40], xmm4
000078eb87dd7200  vmovaps [rsp+0x50], xmm5
000078eb87dd7206  vmovaps [rsp+0x60], xmm6
000078eb87dd720c  vmovaps [rsp+0x70], xmm7
000078eb87dd7212  vmovaps [rsp+0x80], xmm8
000078eb87dd721b  vmovaps [rsp+0x90], xmm10
000078eb87dd7224  vmovaps [rsp+0xA0], xmm11
000078eb87dd722d  vmovaps [rsp+0xB0], xmm12
000078eb87dd7236  vmovaps [rsp+0xC0], xmm13
000078eb87dd723f  vmovaps [rsp+0xD0], xmm14
000078eb87dd7248  vmovaps [rsp+0xE0], xmm15
000078eb87dd7251  sub rsp, 0x30
000078eb87dd7255  movaps [rsp], xmm9
000078eb87dd725a  movaps [rsp+0x10], xmm10
000078eb87dd7260  movaps [rsp+0x20], xmm8
000078eb87dd7266  lea rdi, [rsp]
000078eb87dd726a  mov esi, 0x00
000078eb87dd726f  mov rax, 0x61D341A71530
000078eb87dd7279  call rax
000078eb87dd727b  movaps xmm9, [rsp]
000078eb87dd7280  add rsp, 0x30
000078eb87dd7284  vmovaps xmm0, [rsp]
000078eb87dd7289  vmovaps xmm1, [rsp+0x10]
000078eb87dd728f  vmovaps xmm2, [rsp+0x20]
000078eb87dd7295  vmovaps xmm3, [rsp+0x30]
000078eb87dd729b  vmovaps xmm4, [rsp+0x40]
000078eb87dd72a1  vmovaps xmm5, [rsp+0x50]
000078eb87dd72a7  vmovaps xmm6, [rsp+0x60]
000078eb87dd72ad  vmovaps xmm7, [rsp+0x70]
000078eb87dd72b3  vmovaps xmm8, [rsp+0x80]
000078eb87dd72bc  vmovaps xmm10, [rsp+0x90]
000078eb87dd72c5  vmovaps xmm11, [rsp+0xA0]
000078eb87dd72ce  vmovaps xmm12, [rsp+0xB0]
000078eb87dd72d7  vmovaps xmm13, [rsp+0xC0]
000078eb87dd72e0  vmovaps xmm14, [rsp+0xD0]
000078eb87dd72e9  vmovaps xmm15, [rsp+0xE0]
000078eb87dd72f2  add rsp, 0xF0
000078eb87dd72f9  pop r11
000078eb87dd72fb  pop r10
000078eb87dd72fd  pop r9
000078eb87dd72ff  pop r8
000078eb87dd7301  pop rsi
000078eb87dd7302  pop rdi
000078eb87dd7303  pop rdx
000078eb87dd7304  pop rcx
000078eb87dd7305  pop rax
000078eb87dd7306  add rsp, 0x08
000078eb87dd730a  jmp 0x000078EB87DD5AFB
000078eb87dd730f  call 0x000078EB87CD64F0
000078eb87dd7314  jmp 0x000078EB87DD5C15
000078eb87dd7319  call 0x000078EB87CD64F0
000078eb87dd731e  jmp 0x000078EB87DD5C2B
000078eb87dd7323  sub rsp, 0x08
000078eb87dd7327  push rax
000078eb87dd7328  push rcx
000078eb87dd7329  push rdx
000078eb87dd732a  push rdi
000078eb87dd732b  push rsi
000078eb87dd732c  push r8
000078eb87dd732e  push r9
000078eb87dd7330  push r10
000078eb87dd7332  push r11
000078eb87dd7334  sub rsp, 0xF0
000078eb87dd733b  vmovaps [rsp], xmm0
000078eb87dd7340  vmovaps [rsp+0x10], xmm2
000078eb87dd7346  vmovaps [rsp+0x20], xmm3
000078eb87dd734c  vmovaps [rsp+0x30], xmm4
000078eb87dd7352  vmovaps [rsp+0x40], xmm5
000078eb87dd7358  vmovaps [rsp+0x50], xmm6
000078eb87dd735e  vmovaps [rsp+0x60], xmm7
000078eb87dd7364  vmovaps [rsp+0x70], xmm8
000078eb87dd736a  vmovaps [rsp+0x80], xmm9
000078eb87dd7373  vmovaps [rsp+0x90], xmm10
000078eb87dd737c  vmovaps [rsp+0xA0], xmm11
000078eb87dd7385  vmovaps [rsp+0xB0], xmm12
000078eb87dd738e  vmovaps [rsp+0xC0], xmm13
000078eb87dd7397  vmovaps [rsp+0xD0], xmm14
000078eb87dd73a0  vmovaps [rsp+0xE0], xmm15
000078eb87dd73a9  sub rsp, 0x30
000078eb87dd73ad  movaps [rsp], xmm1
000078eb87dd73b1  movaps [rsp+0x10], xmm6
000078eb87dd73b6  movaps [rsp+0x20], xmm15
000078eb87dd73bc  lea rdi, [rsp]
000078eb87dd73c0  mov esi, 0x00
000078eb87dd73c5  mov rax, 0x61D341A71530
000078eb87dd73cf  call rax
000078eb87dd73d1  movaps xmm1, [rsp]
000078eb87dd73d5  add rsp, 0x30
000078eb87dd73d9  vmovaps xmm0, [rsp]
000078eb87dd73de  vmovaps xmm2, [rsp+0x10]
000078eb87dd73e4  vmovaps xmm3, [rsp+0x20]
000078eb87dd73ea  vmovaps xmm4, [rsp+0x30]
000078eb87dd73f0  vmovaps xmm5, [rsp+0x40]
000078eb87dd73f6  vmovaps xmm6, [rsp+0x50]
000078eb87dd73fc  vmovaps xmm7, [rsp+0x60]
000078eb87dd7402  vmovaps xmm8, [rsp+0x70]
000078eb87dd7408  vmovaps xmm9, [rsp+0x80]
000078eb87dd7411  vmovaps xmm10, [rsp+0x90]
000078eb87dd741a  vmovaps xmm11, [rsp+0xA0]
000078eb87dd7423  vmovaps xmm12, [rsp+0xB0]
000078eb87dd742c  vmovaps xmm13, [rsp+0xC0]
000078eb87dd7435  vmovaps xmm14, [rsp+0xD0]
000078eb87dd743e  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7447  add rsp, 0xF0
000078eb87dd744e  pop r11
000078eb87dd7450  pop r10
000078eb87dd7452  pop r9
000078eb87dd7454  pop r8
000078eb87dd7456  pop rsi
000078eb87dd7457  pop rdi
000078eb87dd7458  pop rdx
000078eb87dd7459  pop rcx
000078eb87dd745a  pop rax
000078eb87dd745b  add rsp, 0x08
000078eb87dd745f  jmp 0x000078EB87DD5C68
000078eb87dd7464  call 0x000078EB87CE5820
000078eb87dd7469  jmp 0x000078EB87DD5C75
000078eb87dd746e  sub rsp, 0x08
000078eb87dd7472  push rax
000078eb87dd7473  push rcx
000078eb87dd7474  push rdx
000078eb87dd7475  push rdi
000078eb87dd7476  push rsi
000078eb87dd7477  push r8
000078eb87dd7479  push r9
000078eb87dd747b  push r10
000078eb87dd747d  push r11
000078eb87dd747f  sub rsp, 0xF0
000078eb87dd7486  vmovaps [rsp], xmm0
000078eb87dd748b  vmovaps [rsp+0x10], xmm1
000078eb87dd7491  vmovaps [rsp+0x20], xmm2
000078eb87dd7497  vmovaps [rsp+0x30], xmm3
000078eb87dd749d  vmovaps [rsp+0x40], xmm4
000078eb87dd74a3  vmovaps [rsp+0x50], xmm5
000078eb87dd74a9  vmovaps [rsp+0x60], xmm6
000078eb87dd74af  vmovaps [rsp+0x70], xmm7
000078eb87dd74b5  vmovaps [rsp+0x80], xmm8
000078eb87dd74be  vmovaps [rsp+0x90], xmm9
000078eb87dd74c7  vmovaps [rsp+0xA0], xmm10
000078eb87dd74d0  vmovaps [rsp+0xB0], xmm11
000078eb87dd74d9  vmovaps [rsp+0xC0], xmm12
000078eb87dd74e2  vmovaps [rsp+0xD0], xmm13
000078eb87dd74eb  vmovaps [rsp+0xE0], xmm15
000078eb87dd74f4  sub rsp, 0x30
000078eb87dd74f8  movaps [rsp], xmm14
000078eb87dd74fd  movaps [rsp+0x10], xmm4
000078eb87dd7502  movaps [rsp+0x20], xmm3
000078eb87dd7507  lea rdi, [rsp]
000078eb87dd750b  mov esi, 0x00
000078eb87dd7510  mov rax, 0x61D341A71530
000078eb87dd751a  call rax
000078eb87dd751c  movaps xmm14, [rsp]
000078eb87dd7521  add rsp, 0x30
000078eb87dd7525  vmovaps xmm0, [rsp]
000078eb87dd752a  vmovaps xmm1, [rsp+0x10]
000078eb87dd7530  vmovaps xmm2, [rsp+0x20]
000078eb87dd7536  vmovaps xmm3, [rsp+0x30]
000078eb87dd753c  vmovaps xmm4, [rsp+0x40]
000078eb87dd7542  vmovaps xmm5, [rsp+0x50]
000078eb87dd7548  vmovaps xmm6, [rsp+0x60]
000078eb87dd754e  vmovaps xmm7, [rsp+0x70]
000078eb87dd7554  vmovaps xmm8, [rsp+0x80]
000078eb87dd755d  vmovaps xmm9, [rsp+0x90]
000078eb87dd7566  vmovaps xmm10, [rsp+0xA0]
000078eb87dd756f  vmovaps xmm11, [rsp+0xB0]
000078eb87dd7578  vmovaps xmm12, [rsp+0xC0]
000078eb87dd7581  vmovaps xmm13, [rsp+0xD0]
000078eb87dd758a  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7593  add rsp, 0xF0
000078eb87dd759a  pop r11
000078eb87dd759c  pop r10
000078eb87dd759e  pop r9
000078eb87dd75a0  pop r8
000078eb87dd75a2  pop rsi
000078eb87dd75a3  pop rdi
000078eb87dd75a4  pop rdx
000078eb87dd75a5  pop rcx
000078eb87dd75a6  pop rax
000078eb87dd75a7  add rsp, 0x08
000078eb87dd75ab  jmp 0x000078EB87DD5C8F
000078eb87dd75b0  sub rsp, 0x08
000078eb87dd75b4  push rax
000078eb87dd75b5  push rcx
000078eb87dd75b6  push rdx
000078eb87dd75b7  push rdi
000078eb87dd75b8  push rsi
000078eb87dd75b9  push r8
000078eb87dd75bb  push r9
000078eb87dd75bd  push r10
000078eb87dd75bf  push r11
000078eb87dd75c1  sub rsp, 0xF0
000078eb87dd75c8  vmovaps [rsp], xmm0
000078eb87dd75cd  vmovaps [rsp+0x10], xmm1
000078eb87dd75d3  vmovaps [rsp+0x20], xmm2
000078eb87dd75d9  vmovaps [rsp+0x30], xmm3
000078eb87dd75df  vmovaps [rsp+0x40], xmm4
000078eb87dd75e5  vmovaps [rsp+0x50], xmm5
000078eb87dd75eb  vmovaps [rsp+0x60], xmm7
000078eb87dd75f1  vmovaps [rsp+0x70], xmm8
000078eb87dd75f7  vmovaps [rsp+0x80], xmm9
000078eb87dd7600  vmovaps [rsp+0x90], xmm10
000078eb87dd7609  vmovaps [rsp+0xA0], xmm11
000078eb87dd7612  vmovaps [rsp+0xB0], xmm12
000078eb87dd761b  vmovaps [rsp+0xC0], xmm13
000078eb87dd7624  vmovaps [rsp+0xD0], xmm14
000078eb87dd762d  vmovaps [rsp+0xE0], xmm15
000078eb87dd7636  sub rsp, 0x30
000078eb87dd763a  movaps [rsp], xmm6
000078eb87dd763e  movaps [rsp+0x10], xmm9
000078eb87dd7644  movaps [rsp+0x20], xmm7
000078eb87dd7649  lea rdi, [rsp]
000078eb87dd764d  mov esi, 0x00
000078eb87dd7652  mov rax, 0x61D341A71530
000078eb87dd765c  call rax
000078eb87dd765e  movaps xmm6, [rsp]
000078eb87dd7662  add rsp, 0x30
000078eb87dd7666  vmovaps xmm0, [rsp]
000078eb87dd766b  vmovaps xmm1, [rsp+0x10]
000078eb87dd7671  vmovaps xmm2, [rsp+0x20]
000078eb87dd7677  vmovaps xmm3, [rsp+0x30]
000078eb87dd767d  vmovaps xmm4, [rsp+0x40]
000078eb87dd7683  vmovaps xmm5, [rsp+0x50]
000078eb87dd7689  vmovaps xmm7, [rsp+0x60]
000078eb87dd768f  vmovaps xmm8, [rsp+0x70]
000078eb87dd7695  vmovaps xmm9, [rsp+0x80]
000078eb87dd769e  vmovaps xmm10, [rsp+0x90]
000078eb87dd76a7  vmovaps xmm11, [rsp+0xA0]
000078eb87dd76b0  vmovaps xmm12, [rsp+0xB0]
000078eb87dd76b9  vmovaps xmm13, [rsp+0xC0]
000078eb87dd76c2  vmovaps xmm14, [rsp+0xD0]
000078eb87dd76cb  vmovaps xmm15, [rsp+0xE0]
000078eb87dd76d4  add rsp, 0xF0
000078eb87dd76db  pop r11
000078eb87dd76dd  pop r10
000078eb87dd76df  pop r9
000078eb87dd76e1  pop r8
000078eb87dd76e3  pop rsi
000078eb87dd76e4  pop rdi
000078eb87dd76e5  pop rdx
000078eb87dd76e6  pop rcx
000078eb87dd76e7  pop rax
000078eb87dd76e8  add rsp, 0x08
000078eb87dd76ec  jmp 0x000078EB87DD5CA7
000078eb87dd76f1  sub rsp, 0x08
000078eb87dd76f5  push rax
000078eb87dd76f6  push rcx
000078eb87dd76f7  push rdx
000078eb87dd76f8  push rdi
000078eb87dd76f9  push rsi
000078eb87dd76fa  push r8
000078eb87dd76fc  push r9
000078eb87dd76fe  push r10
000078eb87dd7700  push r11
000078eb87dd7702  sub rsp, 0xF0
000078eb87dd7709  vmovaps [rsp], xmm0
000078eb87dd770e  vmovaps [rsp+0x10], xmm1
000078eb87dd7714  vmovaps [rsp+0x20], xmm2
000078eb87dd771a  vmovaps [rsp+0x30], xmm3
000078eb87dd7720  vmovaps [rsp+0x40], xmm4
000078eb87dd7726  vmovaps [rsp+0x50], xmm5
000078eb87dd772c  vmovaps [rsp+0x60], xmm6
000078eb87dd7732  vmovaps [rsp+0x70], xmm8
000078eb87dd7738  vmovaps [rsp+0x80], xmm9
000078eb87dd7741  vmovaps [rsp+0x90], xmm10
000078eb87dd774a  vmovaps [rsp+0xA0], xmm11
000078eb87dd7753  vmovaps [rsp+0xB0], xmm12
000078eb87dd775c  vmovaps [rsp+0xC0], xmm13
000078eb87dd7765  vmovaps [rsp+0xD0], xmm14
000078eb87dd776e  vmovaps [rsp+0xE0], xmm15
000078eb87dd7777  sub rsp, 0x30
000078eb87dd777b  movaps [rsp], xmm7
000078eb87dd777f  movaps [rsp+0x10], xmm4
000078eb87dd7784  movaps [rsp+0x20], xmm9
000078eb87dd778a  lea rdi, [rsp]
000078eb87dd778e  mov esi, 0x00
000078eb87dd7793  mov rax, 0x61D341A71530
000078eb87dd779d  call rax
000078eb87dd779f  movaps xmm7, [rsp]
000078eb87dd77a3  add rsp, 0x30
000078eb87dd77a7  vmovaps xmm0, [rsp]
000078eb87dd77ac  vmovaps xmm1, [rsp+0x10]
000078eb87dd77b2  vmovaps xmm2, [rsp+0x20]
000078eb87dd77b8  vmovaps xmm3, [rsp+0x30]
000078eb87dd77be  vmovaps xmm4, [rsp+0x40]
000078eb87dd77c4  vmovaps xmm5, [rsp+0x50]
000078eb87dd77ca  vmovaps xmm6, [rsp+0x60]
000078eb87dd77d0  vmovaps xmm8, [rsp+0x70]
000078eb87dd77d6  vmovaps xmm9, [rsp+0x80]
000078eb87dd77df  vmovaps xmm10, [rsp+0x90]
000078eb87dd77e8  vmovaps xmm11, [rsp+0xA0]
000078eb87dd77f1  vmovaps xmm12, [rsp+0xB0]
000078eb87dd77fa  vmovaps xmm13, [rsp+0xC0]
000078eb87dd7803  vmovaps xmm14, [rsp+0xD0]
000078eb87dd780c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7815  add rsp, 0xF0
000078eb87dd781c  pop r11
000078eb87dd781e  pop r10
000078eb87dd7820  pop r9
000078eb87dd7822  pop r8
000078eb87dd7824  pop rsi
000078eb87dd7825  pop rdi
000078eb87dd7826  pop rdx
000078eb87dd7827  pop rcx
000078eb87dd7828  pop rax
000078eb87dd7829  add rsp, 0x08
000078eb87dd782d  jmp 0x000078EB87DD5CD4
000078eb87dd7832  sub rsp, 0x08
000078eb87dd7836  push rax
000078eb87dd7837  push rcx
000078eb87dd7838  push rdx
000078eb87dd7839  push rdi
000078eb87dd783a  push rsi
000078eb87dd783b  push r8
000078eb87dd783d  push r9
000078eb87dd783f  push r10
000078eb87dd7841  push r11
000078eb87dd7843  sub rsp, 0xF0
000078eb87dd784a  vmovaps [rsp], xmm0
000078eb87dd784f  vmovaps [rsp+0x10], xmm1
000078eb87dd7855  vmovaps [rsp+0x20], xmm2
000078eb87dd785b  vmovaps [rsp+0x30], xmm3
000078eb87dd7861  vmovaps [rsp+0x40], xmm5
000078eb87dd7867  vmovaps [rsp+0x50], xmm6
000078eb87dd786d  vmovaps [rsp+0x60], xmm7
000078eb87dd7873  vmovaps [rsp+0x70], xmm8
000078eb87dd7879  vmovaps [rsp+0x80], xmm9
000078eb87dd7882  vmovaps [rsp+0x90], xmm10
000078eb87dd788b  vmovaps [rsp+0xA0], xmm11
000078eb87dd7894  vmovaps [rsp+0xB0], xmm12
000078eb87dd789d  vmovaps [rsp+0xC0], xmm13
000078eb87dd78a6  vmovaps [rsp+0xD0], xmm14
000078eb87dd78af  vmovaps [rsp+0xE0], xmm15
000078eb87dd78b8  sub rsp, 0x30
000078eb87dd78bc  movaps [rsp], xmm4
000078eb87dd78c0  movaps [rsp+0x10], xmm15
000078eb87dd78c6  movaps [rsp+0x20], xmm9
000078eb87dd78cc  lea rdi, [rsp]
000078eb87dd78d0  mov esi, 0x00
000078eb87dd78d5  mov rax, 0x61D341A71530
000078eb87dd78df  call rax
000078eb87dd78e1  movaps xmm4, [rsp]
000078eb87dd78e5  add rsp, 0x30
000078eb87dd78e9  vmovaps xmm0, [rsp]
000078eb87dd78ee  vmovaps xmm1, [rsp+0x10]
000078eb87dd78f4  vmovaps xmm2, [rsp+0x20]
000078eb87dd78fa  vmovaps xmm3, [rsp+0x30]
000078eb87dd7900  vmovaps xmm5, [rsp+0x40]
000078eb87dd7906  vmovaps xmm6, [rsp+0x50]
000078eb87dd790c  vmovaps xmm7, [rsp+0x60]
000078eb87dd7912  vmovaps xmm8, [rsp+0x70]
000078eb87dd7918  vmovaps xmm9, [rsp+0x80]
000078eb87dd7921  vmovaps xmm10, [rsp+0x90]
000078eb87dd792a  vmovaps xmm11, [rsp+0xA0]
000078eb87dd7933  vmovaps xmm12, [rsp+0xB0]
000078eb87dd793c  vmovaps xmm13, [rsp+0xC0]
000078eb87dd7945  vmovaps xmm14, [rsp+0xD0]
000078eb87dd794e  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7957  add rsp, 0xF0
000078eb87dd795e  pop r11
000078eb87dd7960  pop r10
000078eb87dd7962  pop r9
000078eb87dd7964  pop r8
000078eb87dd7966  pop rsi
000078eb87dd7967  pop rdi
000078eb87dd7968  pop rdx
000078eb87dd7969  pop rcx
000078eb87dd796a  pop rax
000078eb87dd796b  add rsp, 0x08
000078eb87dd796f  jmp 0x000078EB87DD5CF9
000078eb87dd7974  call 0x000078EB87CE5820
000078eb87dd7979  jmp 0x000078EB87DD5D06
000078eb87dd797e  sub rsp, 0x08
000078eb87dd7982  push rax
000078eb87dd7983  push rcx
000078eb87dd7984  push rdx
000078eb87dd7985  push rdi
000078eb87dd7986  push rsi
000078eb87dd7987  push r8
000078eb87dd7989  push r9
000078eb87dd798b  push r10
000078eb87dd798d  push r11
000078eb87dd798f  sub rsp, 0xF0
000078eb87dd7996  vmovaps [rsp], xmm0
000078eb87dd799b  vmovaps [rsp+0x10], xmm1
000078eb87dd79a1  vmovaps [rsp+0x20], xmm2
000078eb87dd79a7  vmovaps [rsp+0x30], xmm4
000078eb87dd79ad  vmovaps [rsp+0x40], xmm5
000078eb87dd79b3  vmovaps [rsp+0x50], xmm6
000078eb87dd79b9  vmovaps [rsp+0x60], xmm7
000078eb87dd79bf  vmovaps [rsp+0x70], xmm8
000078eb87dd79c5  vmovaps [rsp+0x80], xmm9
000078eb87dd79ce  vmovaps [rsp+0x90], xmm10
000078eb87dd79d7  vmovaps [rsp+0xA0], xmm11
000078eb87dd79e0  vmovaps [rsp+0xB0], xmm12
000078eb87dd79e9  vmovaps [rsp+0xC0], xmm13
000078eb87dd79f2  vmovaps [rsp+0xD0], xmm14
000078eb87dd79fb  vmovaps [rsp+0xE0], xmm15
000078eb87dd7a04  sub rsp, 0x30
000078eb87dd7a08  movaps [rsp], xmm3
000078eb87dd7a0c  movaps [rsp+0x10], xmm1
000078eb87dd7a11  movaps [rsp+0x20], xmm9
000078eb87dd7a17  lea rdi, [rsp]
000078eb87dd7a1b  mov esi, 0x00
000078eb87dd7a20  mov rax, 0x61D341A71530
000078eb87dd7a2a  call rax
000078eb87dd7a2c  movaps xmm3, [rsp]
000078eb87dd7a30  add rsp, 0x30
000078eb87dd7a34  vmovaps xmm0, [rsp]
000078eb87dd7a39  vmovaps xmm1, [rsp+0x10]
000078eb87dd7a3f  vmovaps xmm2, [rsp+0x20]
000078eb87dd7a45  vmovaps xmm4, [rsp+0x30]
000078eb87dd7a4b  vmovaps xmm5, [rsp+0x40]
000078eb87dd7a51  vmovaps xmm6, [rsp+0x50]
000078eb87dd7a57  vmovaps xmm7, [rsp+0x60]
000078eb87dd7a5d  vmovaps xmm8, [rsp+0x70]
000078eb87dd7a63  vmovaps xmm9, [rsp+0x80]
000078eb87dd7a6c  vmovaps xmm10, [rsp+0x90]
000078eb87dd7a75  vmovaps xmm11, [rsp+0xA0]
000078eb87dd7a7e  vmovaps xmm12, [rsp+0xB0]
000078eb87dd7a87  vmovaps xmm13, [rsp+0xC0]
000078eb87dd7a90  vmovaps xmm14, [rsp+0xD0]
000078eb87dd7a99  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7aa2  add rsp, 0xF0
000078eb87dd7aa9  pop r11
000078eb87dd7aab  pop r10
000078eb87dd7aad  pop r9
000078eb87dd7aaf  pop r8
000078eb87dd7ab1  pop rsi
000078eb87dd7ab2  pop rdi
000078eb87dd7ab3  pop rdx
000078eb87dd7ab4  pop rcx
000078eb87dd7ab5  pop rax
000078eb87dd7ab6  add rsp, 0x08
000078eb87dd7aba  jmp 0x000078EB87DD5D43
000078eb87dd7abf  sub rsp, 0x08
000078eb87dd7ac3  push rax
000078eb87dd7ac4  push rcx
000078eb87dd7ac5  push rdx
000078eb87dd7ac6  push rdi
000078eb87dd7ac7  push rsi
000078eb87dd7ac8  push r8
000078eb87dd7aca  push r9
000078eb87dd7acc  push r10
000078eb87dd7ace  push r11
000078eb87dd7ad0  sub rsp, 0xF0
000078eb87dd7ad7  vmovaps [rsp], xmm0
000078eb87dd7adc  vmovaps [rsp+0x10], xmm2
000078eb87dd7ae2  vmovaps [rsp+0x20], xmm3
000078eb87dd7ae8  vmovaps [rsp+0x30], xmm4
000078eb87dd7aee  vmovaps [rsp+0x40], xmm5
000078eb87dd7af4  vmovaps [rsp+0x50], xmm6
000078eb87dd7afa  vmovaps [rsp+0x60], xmm7
000078eb87dd7b00  vmovaps [rsp+0x70], xmm8
000078eb87dd7b06  vmovaps [rsp+0x80], xmm9
000078eb87dd7b0f  vmovaps [rsp+0x90], xmm10
000078eb87dd7b18  vmovaps [rsp+0xA0], xmm11
000078eb87dd7b21  vmovaps [rsp+0xB0], xmm12
000078eb87dd7b2a  vmovaps [rsp+0xC0], xmm13
000078eb87dd7b33  vmovaps [rsp+0xD0], xmm14
000078eb87dd7b3c  vmovaps [rsp+0xE0], xmm15
000078eb87dd7b45  sub rsp, 0x30
000078eb87dd7b49  movaps [rsp], xmm1
000078eb87dd7b4d  movaps [rsp+0x10], xmm15
000078eb87dd7b53  movaps [rsp+0x20], xmm9
000078eb87dd7b59  lea rdi, [rsp]
000078eb87dd7b5d  mov esi, 0x00
000078eb87dd7b62  mov rax, 0x61D341A71530
000078eb87dd7b6c  call rax
000078eb87dd7b6e  movaps xmm1, [rsp]
000078eb87dd7b72  add rsp, 0x30
000078eb87dd7b76  vmovaps xmm0, [rsp]
000078eb87dd7b7b  vmovaps xmm2, [rsp+0x10]
000078eb87dd7b81  vmovaps xmm3, [rsp+0x20]
000078eb87dd7b87  vmovaps xmm4, [rsp+0x30]
000078eb87dd7b8d  vmovaps xmm5, [rsp+0x40]
000078eb87dd7b93  vmovaps xmm6, [rsp+0x50]
000078eb87dd7b99  vmovaps xmm7, [rsp+0x60]
000078eb87dd7b9f  vmovaps xmm8, [rsp+0x70]
000078eb87dd7ba5  vmovaps xmm9, [rsp+0x80]
000078eb87dd7bae  vmovaps xmm10, [rsp+0x90]
000078eb87dd7bb7  vmovaps xmm11, [rsp+0xA0]
000078eb87dd7bc0  vmovaps xmm12, [rsp+0xB0]
000078eb87dd7bc9  vmovaps xmm13, [rsp+0xC0]
000078eb87dd7bd2  vmovaps xmm14, [rsp+0xD0]
000078eb87dd7bdb  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7be4  add rsp, 0xF0
000078eb87dd7beb  pop r11
000078eb87dd7bed  pop r10
000078eb87dd7bef  pop r9
000078eb87dd7bf1  pop r8
000078eb87dd7bf3  pop rsi
000078eb87dd7bf4  pop rdi
000078eb87dd7bf5  pop rdx
000078eb87dd7bf6  pop rcx
000078eb87dd7bf7  pop rax
000078eb87dd7bf8  add rsp, 0x08
000078eb87dd7bfc  jmp 0x000078EB87DD5DCB
000078eb87dd7c01  call 0x000078EB87CE5820
000078eb87dd7c06  jmp 0x000078EB87DD5DD8
000078eb87dd7c0b  sub rsp, 0x08
000078eb87dd7c0f  push rax
000078eb87dd7c10  push rcx
000078eb87dd7c11  push rdx
000078eb87dd7c12  push rdi
000078eb87dd7c13  push rsi
000078eb87dd7c14  push r8
000078eb87dd7c16  push r9
000078eb87dd7c18  push r10
000078eb87dd7c1a  push r11
000078eb87dd7c1c  sub rsp, 0xF0
000078eb87dd7c23  vmovaps [rsp], xmm0
000078eb87dd7c28  vmovaps [rsp+0x10], xmm2
000078eb87dd7c2e  vmovaps [rsp+0x20], xmm3
000078eb87dd7c34  vmovaps [rsp+0x30], xmm4
000078eb87dd7c3a  vmovaps [rsp+0x40], xmm5
000078eb87dd7c40  vmovaps [rsp+0x50], xmm6
000078eb87dd7c46  vmovaps [rsp+0x60], xmm7
000078eb87dd7c4c  vmovaps [rsp+0x70], xmm8
000078eb87dd7c52  vmovaps [rsp+0x80], xmm9
000078eb87dd7c5b  vmovaps [rsp+0x90], xmm10
000078eb87dd7c64  vmovaps [rsp+0xA0], xmm11
000078eb87dd7c6d  vmovaps [rsp+0xB0], xmm12
000078eb87dd7c76  vmovaps [rsp+0xC0], xmm13
000078eb87dd7c7f  vmovaps [rsp+0xD0], xmm14
000078eb87dd7c88  vmovaps [rsp+0xE0], xmm15
000078eb87dd7c91  sub rsp, 0x30
000078eb87dd7c95  movaps [rsp], xmm1
000078eb87dd7c99  movaps [rsp+0x10], xmm5
000078eb87dd7c9e  movaps [rsp+0x20], xmm7
000078eb87dd7ca3  lea rdi, [rsp]
000078eb87dd7ca7  mov esi, 0x00
000078eb87dd7cac  mov rax, 0x61D341A71530
000078eb87dd7cb6  call rax
000078eb87dd7cb8  movaps xmm1, [rsp]
000078eb87dd7cbc  add rsp, 0x30
000078eb87dd7cc0  vmovaps xmm0, [rsp]
000078eb87dd7cc5  vmovaps xmm2, [rsp+0x10]
000078eb87dd7ccb  vmovaps xmm3, [rsp+0x20]
000078eb87dd7cd1  vmovaps xmm4, [rsp+0x30]
000078eb87dd7cd7  vmovaps xmm5, [rsp+0x40]
000078eb87dd7cdd  vmovaps xmm6, [rsp+0x50]
000078eb87dd7ce3  vmovaps xmm7, [rsp+0x60]
000078eb87dd7ce9  vmovaps xmm8, [rsp+0x70]
000078eb87dd7cef  vmovaps xmm9, [rsp+0x80]
000078eb87dd7cf8  vmovaps xmm10, [rsp+0x90]
000078eb87dd7d01  vmovaps xmm11, [rsp+0xA0]
000078eb87dd7d0a  vmovaps xmm12, [rsp+0xB0]
000078eb87dd7d13  vmovaps xmm13, [rsp+0xC0]
000078eb87dd7d1c  vmovaps xmm14, [rsp+0xD0]
000078eb87dd7d25  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7d2e  add rsp, 0xF0
000078eb87dd7d35  pop r11
000078eb87dd7d37  pop r10
000078eb87dd7d39  pop r9
000078eb87dd7d3b  pop r8
000078eb87dd7d3d  pop rsi
000078eb87dd7d3e  pop rdi
000078eb87dd7d3f  pop rdx
000078eb87dd7d40  pop rcx
000078eb87dd7d41  pop rax
000078eb87dd7d42  add rsp, 0x08
000078eb87dd7d46  jmp 0x000078EB87DD5E7D
000078eb87dd7d4b  sub rsp, 0x08
000078eb87dd7d4f  push rax
000078eb87dd7d50  push rcx
000078eb87dd7d51  push rdx
000078eb87dd7d52  push rdi
000078eb87dd7d53  push rsi
000078eb87dd7d54  push r8
000078eb87dd7d56  push r9
000078eb87dd7d58  push r10
000078eb87dd7d5a  push r11
000078eb87dd7d5c  sub rsp, 0xF0
000078eb87dd7d63  vmovaps [rsp], xmm0
000078eb87dd7d68  vmovaps [rsp+0x10], xmm1
000078eb87dd7d6e  vmovaps [rsp+0x20], xmm2
000078eb87dd7d74  vmovaps [rsp+0x30], xmm3
000078eb87dd7d7a  vmovaps [rsp+0x40], xmm4
000078eb87dd7d80  vmovaps [rsp+0x50], xmm5
000078eb87dd7d86  vmovaps [rsp+0x60], xmm6
000078eb87dd7d8c  vmovaps [rsp+0x70], xmm8
000078eb87dd7d92  vmovaps [rsp+0x80], xmm9
000078eb87dd7d9b  vmovaps [rsp+0x90], xmm10
000078eb87dd7da4  vmovaps [rsp+0xA0], xmm11
000078eb87dd7dad  vmovaps [rsp+0xB0], xmm12
000078eb87dd7db6  vmovaps [rsp+0xC0], xmm13
000078eb87dd7dbf  vmovaps [rsp+0xD0], xmm14
000078eb87dd7dc8  vmovaps [rsp+0xE0], xmm15
000078eb87dd7dd1  sub rsp, 0x30
000078eb87dd7dd5  movaps [rsp], xmm7
000078eb87dd7dd9  movaps [rsp+0x10], xmm5
000078eb87dd7dde  movaps [rsp+0x20], xmm15
000078eb87dd7de4  lea rdi, [rsp]
000078eb87dd7de8  mov esi, 0x00
000078eb87dd7ded  mov rax, 0x61D341A71530
000078eb87dd7df7  call rax
000078eb87dd7df9  movaps xmm7, [rsp]
000078eb87dd7dfd  add rsp, 0x30
000078eb87dd7e01  vmovaps xmm0, [rsp]
000078eb87dd7e06  vmovaps xmm1, [rsp+0x10]
000078eb87dd7e0c  vmovaps xmm2, [rsp+0x20]
000078eb87dd7e12  vmovaps xmm3, [rsp+0x30]
000078eb87dd7e18  vmovaps xmm4, [rsp+0x40]
000078eb87dd7e1e  vmovaps xmm5, [rsp+0x50]
000078eb87dd7e24  vmovaps xmm6, [rsp+0x60]
000078eb87dd7e2a  vmovaps xmm8, [rsp+0x70]
000078eb87dd7e30  vmovaps xmm9, [rsp+0x80]
000078eb87dd7e39  vmovaps xmm10, [rsp+0x90]
000078eb87dd7e42  vmovaps xmm11, [rsp+0xA0]
000078eb87dd7e4b  vmovaps xmm12, [rsp+0xB0]
000078eb87dd7e54  vmovaps xmm13, [rsp+0xC0]
000078eb87dd7e5d  vmovaps xmm14, [rsp+0xD0]
000078eb87dd7e66  vmovaps xmm15, [rsp+0xE0]
000078eb87dd7e6f  add rsp, 0xF0
000078eb87dd7e76  pop r11
000078eb87dd7e78  pop r10
000078eb87dd7e7a  pop r9
000078eb87dd7e7c  pop r8
000078eb87dd7e7e  pop rsi
000078eb87dd7e7f  pop rdi
000078eb87dd7e80  pop rdx
000078eb87dd7e81  pop rcx
000078eb87dd7e82  pop rax
000078eb87dd7e83  add rsp, 0x08
000078eb87dd7e87  jmp 0x000078EB87DD5EB3
000078eb87dd7e8c  call 0x000078EB87CD64F0
000078eb87dd7e91  jmp 0x000078EB87DD5EC0
000078eb87dd7e96  sub rsp, 0x08
000078eb87dd7e9a  push rax
000078eb87dd7e9b  push rcx
000078eb87dd7e9c  push rdx
000078eb87dd7e9d  push rdi
000078eb87dd7e9e  push rsi
000078eb87dd7e9f  push r8
000078eb87dd7ea1  push r9
000078eb87dd7ea3  push r10
000078eb87dd7ea5  push r11
000078eb87dd7ea7  sub rsp, 0xF0
000078eb87dd7eae  vmovaps [rsp], xmm0
000078eb87dd7eb3  vmovaps [rsp+0x10], xmm1
000078eb87dd7eb9  vmovaps [rsp+0x20], xmm2
000078eb87dd7ebf  vmovaps [rsp+0x30], xmm3
000078eb87dd7ec5  vmovaps [rsp+0x40], xmm4
000078eb87dd7ecb  vmovaps [rsp+0x50], xmm5
000078eb87dd7ed1  vmovaps [rsp+0x60], xmm6
000078eb87dd7ed7  vmovaps [rsp+0x70], xmm7
000078eb87dd7edd  vmovaps [rsp+0x80], xmm8
000078eb87dd7ee6  vmovaps [rsp+0x90], xmm9
000078eb87dd7eef  vmovaps [rsp+0xA0], xmm10
000078eb87dd7ef8  vmovaps [rsp+0xB0], xmm11
000078eb87dd7f01  vmovaps [rsp+0xC0], xmm12
000078eb87dd7f0a  vmovaps [rsp+0xD0], xmm13
000078eb87dd7f13  vmovaps [rsp+0xE0], xmm14
000078eb87dd7f1c  sub rsp, 0x30
000078eb87dd7f20  movaps [rsp], xmm15
000078eb87dd7f25  movaps [rsp+0x10], xmm5
000078eb87dd7f2a  movaps [rsp+0x20], xmm3
000078eb87dd7f2f  lea rdi, [rsp]
000078eb87dd7f33  mov esi, 0x00
000078eb87dd7f38  mov rax, 0x61D341A71530
000078eb87dd7f42  call rax
000078eb87dd7f44  movaps xmm15, [rsp]
000078eb87dd7f49  add rsp, 0x30
000078eb87dd7f4d  vmovaps xmm0, [rsp]
000078eb87dd7f52  vmovaps xmm1, [rsp+0x10]
000078eb87dd7f58  vmovaps xmm2, [rsp+0x20]
000078eb87dd7f5e  vmovaps xmm3, [rsp+0x30]
000078eb87dd7f64  vmovaps xmm4, [rsp+0x40]
000078eb87dd7f6a  vmovaps xmm5, [rsp+0x50]
000078eb87dd7f70  vmovaps xmm6, [rsp+0x60]
000078eb87dd7f76  vmovaps xmm7, [rsp+0x70]
000078eb87dd7f7c  vmovaps xmm8, [rsp+0x80]
000078eb87dd7f85  vmovaps xmm9, [rsp+0x90]
000078eb87dd7f8e  vmovaps xmm10, [rsp+0xA0]
000078eb87dd7f97  vmovaps xmm11, [rsp+0xB0]
000078eb87dd7fa0  vmovaps xmm12, [rsp+0xC0]
000078eb87dd7fa9  vmovaps xmm13, [rsp+0xD0]
000078eb87dd7fb2  vmovaps xmm14, [rsp+0xE0]
000078eb87dd7fbb  add rsp, 0xF0
000078eb87dd7fc2  pop r11
000078eb87dd7fc4  pop r10
000078eb87dd7fc6  pop r9
000078eb87dd7fc8  pop r8
000078eb87dd7fca  pop rsi
000078eb87dd7fcb  pop rdi
000078eb87dd7fcc  pop rdx
000078eb87dd7fcd  pop rcx
000078eb87dd7fce  pop rax
000078eb87dd7fcf  add rsp, 0x08
000078eb87dd7fd3  jmp 0x000078EB87DD5EE6
000078eb87dd7fd8  sub rsp, 0x08
000078eb87dd7fdc  push rax
000078eb87dd7fdd  push rcx
000078eb87dd7fde  push rdx
000078eb87dd7fdf  push rdi
000078eb87dd7fe0  push rsi
000078eb87dd7fe1  push r8
000078eb87dd7fe3  push r9
000078eb87dd7fe5  push r10
000078eb87dd7fe7  push r11
000078eb87dd7fe9  sub rsp, 0xF0
000078eb87dd7ff0  vmovaps [rsp], xmm0
000078eb87dd7ff5  vmovaps [rsp+0x10], xmm2
000078eb87dd7ffb  vmovaps [rsp+0x20], xmm3
000078eb87dd8001  vmovaps [rsp+0x30], xmm4
000078eb87dd8007  vmovaps [rsp+0x40], xmm5
000078eb87dd800d  vmovaps [rsp+0x50], xmm6
000078eb87dd8013  vmovaps [rsp+0x60], xmm7
000078eb87dd8019  vmovaps [rsp+0x70], xmm8
000078eb87dd801f  vmovaps [rsp+0x80], xmm9
000078eb87dd8028  vmovaps [rsp+0x90], xmm10
000078eb87dd8031  vmovaps [rsp+0xA0], xmm11
000078eb87dd803a  vmovaps [rsp+0xB0], xmm12
000078eb87dd8043  vmovaps [rsp+0xC0], xmm13
000078eb87dd804c  vmovaps [rsp+0xD0], xmm14
000078eb87dd8055  vmovaps [rsp+0xE0], xmm15
000078eb87dd805e  sub rsp, 0x30
000078eb87dd8062  movaps [rsp], xmm1
000078eb87dd8066  movaps [rsp+0x10], xmm5
000078eb87dd806b  movaps [rsp+0x20], xmm4
000078eb87dd8070  lea rdi, [rsp]
000078eb87dd8074  mov esi, 0x00
000078eb87dd8079  mov rax, 0x61D341A71530
000078eb87dd8083  call rax
000078eb87dd8085  movaps xmm1, [rsp]
000078eb87dd8089  add rsp, 0x30
000078eb87dd808d  vmovaps xmm0, [rsp]
000078eb87dd8092  vmovaps xmm2, [rsp+0x10]
000078eb87dd8098  vmovaps xmm3, [rsp+0x20]
000078eb87dd809e  vmovaps xmm4, [rsp+0x30]
000078eb87dd80a4  vmovaps xmm5, [rsp+0x40]
000078eb87dd80aa  vmovaps xmm6, [rsp+0x50]
000078eb87dd80b0  vmovaps xmm7, [rsp+0x60]
000078eb87dd80b6  vmovaps xmm8, [rsp+0x70]
000078eb87dd80bc  vmovaps xmm9, [rsp+0x80]
000078eb87dd80c5  vmovaps xmm10, [rsp+0x90]
000078eb87dd80ce  vmovaps xmm11, [rsp+0xA0]
000078eb87dd80d7  vmovaps xmm12, [rsp+0xB0]
000078eb87dd80e0  vmovaps xmm13, [rsp+0xC0]
000078eb87dd80e9  vmovaps xmm14, [rsp+0xD0]
000078eb87dd80f2  vmovaps xmm15, [rsp+0xE0]
000078eb87dd80fb  add rsp, 0xF0
000078eb87dd8102  pop r11
000078eb87dd8104  pop r10
000078eb87dd8106  pop r9
000078eb87dd8108  pop r8
000078eb87dd810a  pop rsi
000078eb87dd810b  pop rdi
000078eb87dd810c  pop rdx
000078eb87dd810d  pop rcx
000078eb87dd810e  pop rax
000078eb87dd810f  add rsp, 0x08
000078eb87dd8113  jmp 0x000078EB87DD5F06
000078eb87dd8118  sub rsp, 0x08
000078eb87dd811c  push rax
000078eb87dd811d  push rcx
000078eb87dd811e  push rdx
000078eb87dd811f  push rdi
000078eb87dd8120  push rsi
000078eb87dd8121  push r8
000078eb87dd8123  push r9
000078eb87dd8125  push r10
000078eb87dd8127  push r11
000078eb87dd8129  sub rsp, 0xF0
000078eb87dd8130  vmovaps [rsp], xmm0
000078eb87dd8135  vmovaps [rsp+0x10], xmm1
000078eb87dd813b  vmovaps [rsp+0x20], xmm2
000078eb87dd8141  vmovaps [rsp+0x30], xmm3
000078eb87dd8147  vmovaps [rsp+0x40], xmm5
000078eb87dd814d  vmovaps [rsp+0x50], xmm6
000078eb87dd8153  vmovaps [rsp+0x60], xmm7
000078eb87dd8159  vmovaps [rsp+0x70], xmm8
000078eb87dd815f  vmovaps [rsp+0x80], xmm9
000078eb87dd8168  vmovaps [rsp+0x90], xmm10
000078eb87dd8171  vmovaps [rsp+0xA0], xmm11
000078eb87dd817a  vmovaps [rsp+0xB0], xmm12
000078eb87dd8183  vmovaps [rsp+0xC0], xmm13
000078eb87dd818c  vmovaps [rsp+0xD0], xmm14
000078eb87dd8195  vmovaps [rsp+0xE0], xmm15
000078eb87dd819e  sub rsp, 0x30
000078eb87dd81a2  movaps [rsp], xmm4
000078eb87dd81a6  movaps [rsp+0x10], xmm3
000078eb87dd81ab  movaps [rsp+0x20], xmm5
000078eb87dd81b0  lea rdi, [rsp]
000078eb87dd81b4  mov esi, 0x00
000078eb87dd81b9  mov rax, 0x61D341A71530
000078eb87dd81c3  call rax
000078eb87dd81c5  movaps xmm4, [rsp]
000078eb87dd81c9  add rsp, 0x30
000078eb87dd81cd  vmovaps xmm0, [rsp]
000078eb87dd81d2  vmovaps xmm1, [rsp+0x10]
000078eb87dd81d8  vmovaps xmm2, [rsp+0x20]
000078eb87dd81de  vmovaps xmm3, [rsp+0x30]
000078eb87dd81e4  vmovaps xmm5, [rsp+0x40]
000078eb87dd81ea  vmovaps xmm6, [rsp+0x50]
000078eb87dd81f0  vmovaps xmm7, [rsp+0x60]
000078eb87dd81f6  vmovaps xmm8, [rsp+0x70]
000078eb87dd81fc  vmovaps xmm9, [rsp+0x80]
000078eb87dd8205  vmovaps xmm10, [rsp+0x90]
000078eb87dd820e  vmovaps xmm11, [rsp+0xA0]
000078eb87dd8217  vmovaps xmm12, [rsp+0xB0]
000078eb87dd8220  vmovaps xmm13, [rsp+0xC0]
000078eb87dd8229  vmovaps xmm14, [rsp+0xD0]
000078eb87dd8232  vmovaps xmm15, [rsp+0xE0]
000078eb87dd823b  add rsp, 0xF0
000078eb87dd8242  pop r11
000078eb87dd8244  pop r10
000078eb87dd8246  pop r9
000078eb87dd8248  pop r8
000078eb87dd824a  pop rsi
000078eb87dd824b  pop rdi
000078eb87dd824c  pop rdx
000078eb87dd824d  pop rcx
000078eb87dd824e  pop rax
000078eb87dd824f  add rsp, 0x08
000078eb87dd8253  jmp 0x000078EB87DD5F54
000078eb87dd8258  call 0x000078EB87CD64F0
000078eb87dd825d  jmp 0x000078EB87DD5F61
000078eb87dd8262  sub rsp, 0x08
000078eb87dd8266  push rax
000078eb87dd8267  push rcx
000078eb87dd8268  push rdx
000078eb87dd8269  push rdi
000078eb87dd826a  push rsi
000078eb87dd826b  push r8
000078eb87dd826d  push r9
000078eb87dd826f  push r10
000078eb87dd8271  push r11
000078eb87dd8273  sub rsp, 0xF0
000078eb87dd827a  vmovaps [rsp], xmm0
000078eb87dd827f  vmovaps [rsp+0x10], xmm1
000078eb87dd8285  vmovaps [rsp+0x20], xmm2
000078eb87dd828b  vmovaps [rsp+0x30], xmm3
000078eb87dd8291  vmovaps [rsp+0x40], xmm4
000078eb87dd8297  vmovaps [rsp+0x50], xmm6
000078eb87dd829d  vmovaps [rsp+0x60], xmm7
000078eb87dd82a3  vmovaps [rsp+0x70], xmm8
000078eb87dd82a9  vmovaps [rsp+0x80], xmm9
000078eb87dd82b2  vmovaps [rsp+0x90], xmm10
000078eb87dd82bb  vmovaps [rsp+0xA0], xmm11
000078eb87dd82c4  vmovaps [rsp+0xB0], xmm12
000078eb87dd82cd  vmovaps [rsp+0xC0], xmm13
000078eb87dd82d6  vmovaps [rsp+0xD0], xmm14
000078eb87dd82df  vmovaps [rsp+0xE0], xmm15
000078eb87dd82e8  sub rsp, 0x30
000078eb87dd82ec  movaps [rsp], xmm5
000078eb87dd82f0  movaps [rsp+0x10], xmm6
000078eb87dd82f5  movaps [rsp+0x20], xmm3
000078eb87dd82fa  lea rdi, [rsp]
000078eb87dd82fe  mov esi, 0x00
000078eb87dd8303  mov rax, 0x61D341A71530
000078eb87dd830d  call rax
000078eb87dd830f  movaps xmm5, [rsp]
000078eb87dd8313  add rsp, 0x30
000078eb87dd8317  vmovaps xmm0, [rsp]
000078eb87dd831c  vmovaps xmm1, [rsp+0x10]
000078eb87dd8322  vmovaps xmm2, [rsp+0x20]
000078eb87dd8328  vmovaps xmm3, [rsp+0x30]
000078eb87dd832e  vmovaps xmm4, [rsp+0x40]
000078eb87dd8334  vmovaps xmm6, [rsp+0x50]
000078eb87dd833a  vmovaps xmm7, [rsp+0x60]
000078eb87dd8340  vmovaps xmm8, [rsp+0x70]
000078eb87dd8346  vmovaps xmm9, [rsp+0x80]
000078eb87dd834f  vmovaps xmm10, [rsp+0x90]
000078eb87dd8358  vmovaps xmm11, [rsp+0xA0]
000078eb87dd8361  vmovaps xmm12, [rsp+0xB0]
000078eb87dd836a  vmovaps xmm13, [rsp+0xC0]
000078eb87dd8373  vmovaps xmm14, [rsp+0xD0]
000078eb87dd837c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd8385  add rsp, 0xF0
000078eb87dd838c  pop r11
000078eb87dd838e  pop r10
000078eb87dd8390  pop r9
000078eb87dd8392  pop r8
000078eb87dd8394  pop rsi
000078eb87dd8395  pop rdi
000078eb87dd8396  pop rdx
000078eb87dd8397  pop rcx
000078eb87dd8398  pop rax
000078eb87dd8399  add rsp, 0x08
000078eb87dd839d  jmp 0x000078EB87DD5F87
000078eb87dd83a2  sub rsp, 0x08
000078eb87dd83a6  push rax
000078eb87dd83a7  push rcx
000078eb87dd83a8  push rdx
000078eb87dd83a9  push rdi
000078eb87dd83aa  push rsi
000078eb87dd83ab  push r8
000078eb87dd83ad  push r9
000078eb87dd83af  push r10
000078eb87dd83b1  push r11
000078eb87dd83b3  sub rsp, 0xF0
000078eb87dd83ba  vmovaps [rsp], xmm0
000078eb87dd83bf  vmovaps [rsp+0x10], xmm1
000078eb87dd83c5  vmovaps [rsp+0x20], xmm2
000078eb87dd83cb  vmovaps [rsp+0x30], xmm3
000078eb87dd83d1  vmovaps [rsp+0x40], xmm4
000078eb87dd83d7  vmovaps [rsp+0x50], xmm5
000078eb87dd83dd  vmovaps [rsp+0x60], xmm7
000078eb87dd83e3  vmovaps [rsp+0x70], xmm8
000078eb87dd83e9  vmovaps [rsp+0x80], xmm9
000078eb87dd83f2  vmovaps [rsp+0x90], xmm10
000078eb87dd83fb  vmovaps [rsp+0xA0], xmm11
000078eb87dd8404  vmovaps [rsp+0xB0], xmm12
000078eb87dd840d  vmovaps [rsp+0xC0], xmm13
000078eb87dd8416  vmovaps [rsp+0xD0], xmm14
000078eb87dd841f  vmovaps [rsp+0xE0], xmm15
000078eb87dd8428  sub rsp, 0x30
000078eb87dd842c  movaps [rsp], xmm6
000078eb87dd8430  movaps [rsp+0x10], xmm9
000078eb87dd8436  movaps [rsp+0x20], xmm1
000078eb87dd843b  lea rdi, [rsp]
000078eb87dd843f  mov esi, 0x00
000078eb87dd8444  mov rax, 0x61D341A71530
000078eb87dd844e  call rax
000078eb87dd8450  movaps xmm6, [rsp]
000078eb87dd8454  add rsp, 0x30
000078eb87dd8458  vmovaps xmm0, [rsp]
000078eb87dd845d  vmovaps xmm1, [rsp+0x10]
000078eb87dd8463  vmovaps xmm2, [rsp+0x20]
000078eb87dd8469  vmovaps xmm3, [rsp+0x30]
000078eb87dd846f  vmovaps xmm4, [rsp+0x40]
000078eb87dd8475  vmovaps xmm5, [rsp+0x50]
000078eb87dd847b  vmovaps xmm7, [rsp+0x60]
000078eb87dd8481  vmovaps xmm8, [rsp+0x70]
000078eb87dd8487  vmovaps xmm9, [rsp+0x80]
000078eb87dd8490  vmovaps xmm10, [rsp+0x90]
000078eb87dd8499  vmovaps xmm11, [rsp+0xA0]
000078eb87dd84a2  vmovaps xmm12, [rsp+0xB0]
000078eb87dd84ab  vmovaps xmm13, [rsp+0xC0]
000078eb87dd84b4  vmovaps xmm14, [rsp+0xD0]
000078eb87dd84bd  vmovaps xmm15, [rsp+0xE0]
000078eb87dd84c6  add rsp, 0xF0
000078eb87dd84cd  pop r11
000078eb87dd84cf  pop r10
000078eb87dd84d1  pop r9
000078eb87dd84d3  pop r8
000078eb87dd84d5  pop rsi
000078eb87dd84d6  pop rdi
000078eb87dd84d7  pop rdx
000078eb87dd84d8  pop rcx
000078eb87dd84d9  pop rax
000078eb87dd84da  add rsp, 0x08
000078eb87dd84de  jmp 0x000078EB87DD5FAB
000078eb87dd84e3  sub rsp, 0x08
000078eb87dd84e7  push rax
000078eb87dd84e8  push rcx
000078eb87dd84e9  push rdx
000078eb87dd84ea  push rdi
000078eb87dd84eb  push rsi
000078eb87dd84ec  push r8
000078eb87dd84ee  push r9
000078eb87dd84f0  push r10
000078eb87dd84f2  push r11
000078eb87dd84f4  sub rsp, 0xF0
000078eb87dd84fb  vmovaps [rsp], xmm0
000078eb87dd8500  vmovaps [rsp+0x10], xmm1
000078eb87dd8506  vmovaps [rsp+0x20], xmm2
000078eb87dd850c  vmovaps [rsp+0x30], xmm3
000078eb87dd8512  vmovaps [rsp+0x40], xmm4
000078eb87dd8518  vmovaps [rsp+0x50], xmm5
000078eb87dd851e  vmovaps [rsp+0x60], xmm6
000078eb87dd8524  vmovaps [rsp+0x70], xmm7
000078eb87dd852a  vmovaps [rsp+0x80], xmm8
000078eb87dd8533  vmovaps [rsp+0x90], xmm10
000078eb87dd853c  vmovaps [rsp+0xA0], xmm11
000078eb87dd8545  vmovaps [rsp+0xB0], xmm12
000078eb87dd854e  vmovaps [rsp+0xC0], xmm13
000078eb87dd8557  vmovaps [rsp+0xD0], xmm14
000078eb87dd8560  vmovaps [rsp+0xE0], xmm15
000078eb87dd8569  sub rsp, 0x30
000078eb87dd856d  movaps [rsp], xmm9
000078eb87dd8572  movaps [rsp+0x10], xmm3
000078eb87dd8577  movaps [rsp+0x20], xmm1
000078eb87dd857c  lea rdi, [rsp]
000078eb87dd8580  mov esi, 0x00
000078eb87dd8585  mov rax, 0x61D341A71530
000078eb87dd858f  call rax
000078eb87dd8591  movaps xmm9, [rsp]
000078eb87dd8596  add rsp, 0x30
000078eb87dd859a  vmovaps xmm0, [rsp]
000078eb87dd859f  vmovaps xmm1, [rsp+0x10]
000078eb87dd85a5  vmovaps xmm2, [rsp+0x20]
000078eb87dd85ab  vmovaps xmm3, [rsp+0x30]
000078eb87dd85b1  vmovaps xmm4, [rsp+0x40]
000078eb87dd85b7  vmovaps xmm5, [rsp+0x50]
000078eb87dd85bd  vmovaps xmm6, [rsp+0x60]
000078eb87dd85c3  vmovaps xmm7, [rsp+0x70]
000078eb87dd85c9  vmovaps xmm8, [rsp+0x80]
000078eb87dd85d2  vmovaps xmm10, [rsp+0x90]
000078eb87dd85db  vmovaps xmm11, [rsp+0xA0]
000078eb87dd85e4  vmovaps xmm12, [rsp+0xB0]
000078eb87dd85ed  vmovaps xmm13, [rsp+0xC0]
000078eb87dd85f6  vmovaps xmm14, [rsp+0xD0]
000078eb87dd85ff  vmovaps xmm15, [rsp+0xE0]
000078eb87dd8608  add rsp, 0xF0
000078eb87dd860f  pop r11
000078eb87dd8611  pop r10
000078eb87dd8613  pop r9
000078eb87dd8615  pop r8
000078eb87dd8617  pop rsi
000078eb87dd8618  pop rdi
000078eb87dd8619  pop rdx
000078eb87dd861a  pop rcx
000078eb87dd861b  pop rax
000078eb87dd861c  add rsp, 0x08
000078eb87dd8620  jmp 0x000078EB87DD5FF7
000078eb87dd8625  call 0x000078EB87CD64F0
000078eb87dd862a  jmp 0x000078EB87DD6004
000078eb87dd862f  sub rsp, 0x08
000078eb87dd8633  push rax
000078eb87dd8634  push rcx
000078eb87dd8635  push rdx
000078eb87dd8636  push rdi
000078eb87dd8637  push rsi
000078eb87dd8638  push r8
000078eb87dd863a  push r9
000078eb87dd863c  push r10
000078eb87dd863e  push r11
000078eb87dd8640  sub rsp, 0xF0
000078eb87dd8647  vmovaps [rsp], xmm0
000078eb87dd864c  vmovaps [rsp+0x10], xmm1
000078eb87dd8652  vmovaps [rsp+0x20], xmm2
000078eb87dd8658  vmovaps [rsp+0x30], xmm3
000078eb87dd865e  vmovaps [rsp+0x40], xmm4
000078eb87dd8664  vmovaps [rsp+0x50], xmm5
000078eb87dd866a  vmovaps [rsp+0x60], xmm6
000078eb87dd8670  vmovaps [rsp+0x70], xmm7
000078eb87dd8676  vmovaps [rsp+0x80], xmm8
000078eb87dd867f  vmovaps [rsp+0x90], xmm9
000078eb87dd8688  vmovaps [rsp+0xA0], xmm10
000078eb87dd8691  vmovaps [rsp+0xB0], xmm11
000078eb87dd869a  vmovaps [rsp+0xC0], xmm12
000078eb87dd86a3  vmovaps [rsp+0xD0], xmm13
000078eb87dd86ac  vmovaps [rsp+0xE0], xmm14
000078eb87dd86b5  sub rsp, 0x30
000078eb87dd86b9  movaps [rsp], xmm15
000078eb87dd86be  movaps [rsp+0x10], xmm3
000078eb87dd86c3  movaps [rsp+0x20], xmm7
000078eb87dd86c8  lea rdi, [rsp]
000078eb87dd86cc  mov esi, 0x00
000078eb87dd86d1  mov rax, 0x61D341A71530
000078eb87dd86db  call rax
000078eb87dd86dd  movaps xmm15, [rsp]
000078eb87dd86e2  add rsp, 0x30
000078eb87dd86e6  vmovaps xmm0, [rsp]
000078eb87dd86eb  vmovaps xmm1, [rsp+0x10]
000078eb87dd86f1  vmovaps xmm2, [rsp+0x20]
000078eb87dd86f7  vmovaps xmm3, [rsp+0x30]
000078eb87dd86fd  vmovaps xmm4, [rsp+0x40]
000078eb87dd8703  vmovaps xmm5, [rsp+0x50]
000078eb87dd8709  vmovaps xmm6, [rsp+0x60]
000078eb87dd870f  vmovaps xmm7, [rsp+0x70]
000078eb87dd8715  vmovaps xmm8, [rsp+0x80]
000078eb87dd871e  vmovaps xmm9, [rsp+0x90]
000078eb87dd8727  vmovaps xmm10, [rsp+0xA0]
000078eb87dd8730  vmovaps xmm11, [rsp+0xB0]
000078eb87dd8739  vmovaps xmm12, [rsp+0xC0]
000078eb87dd8742  vmovaps xmm13, [rsp+0xD0]
000078eb87dd874b  vmovaps xmm14, [rsp+0xE0]
000078eb87dd8754  add rsp, 0xF0
000078eb87dd875b  pop r11
000078eb87dd875d  pop r10
000078eb87dd875f  pop r9
000078eb87dd8761  pop r8
000078eb87dd8763  pop rsi
000078eb87dd8764  pop rdi
000078eb87dd8765  pop rdx
000078eb87dd8766  pop rcx
000078eb87dd8767  pop rax
000078eb87dd8768  add rsp, 0x08
000078eb87dd876c  jmp 0x000078EB87DD6030
000078eb87dd8771  sub rsp, 0x08
000078eb87dd8775  push rax
000078eb87dd8776  push rcx
000078eb87dd8777  push rdx
000078eb87dd8778  push rdi
000078eb87dd8779  push rsi
000078eb87dd877a  push r8
000078eb87dd877c  push r9
000078eb87dd877e  push r10
000078eb87dd8780  push r11
000078eb87dd8782  sub rsp, 0xF0
000078eb87dd8789  vmovaps [rsp], xmm0
000078eb87dd878e  vmovaps [rsp+0x10], xmm1
000078eb87dd8794  vmovaps [rsp+0x20], xmm2
000078eb87dd879a  vmovaps [rsp+0x30], xmm4
000078eb87dd87a0  vmovaps [rsp+0x40], xmm5
000078eb87dd87a6  vmovaps [rsp+0x50], xmm6
000078eb87dd87ac  vmovaps [rsp+0x60], xmm7
000078eb87dd87b2  vmovaps [rsp+0x70], xmm8
000078eb87dd87b8  vmovaps [rsp+0x80], xmm9
000078eb87dd87c1  vmovaps [rsp+0x90], xmm10
000078eb87dd87ca  vmovaps [rsp+0xA0], xmm11
000078eb87dd87d3  vmovaps [rsp+0xB0], xmm12
000078eb87dd87dc  vmovaps [rsp+0xC0], xmm13
000078eb87dd87e5  vmovaps [rsp+0xD0], xmm14
000078eb87dd87ee  vmovaps [rsp+0xE0], xmm15
000078eb87dd87f7  sub rsp, 0x30
000078eb87dd87fb  movaps [rsp], xmm3
000078eb87dd87ff  movaps [rsp+0x10], xmm1
000078eb87dd8804  movaps [rsp+0x20], xmm15
000078eb87dd880a  lea rdi, [rsp]
000078eb87dd880e  mov esi, 0x00
000078eb87dd8813  mov rax, 0x61D341A71530
000078eb87dd881d  call rax
000078eb87dd881f  movaps xmm3, [rsp]
000078eb87dd8823  add rsp, 0x30
000078eb87dd8827  vmovaps xmm0, [rsp]
000078eb87dd882c  vmovaps xmm1, [rsp+0x10]
000078eb87dd8832  vmovaps xmm2, [rsp+0x20]
000078eb87dd8838  vmovaps xmm4, [rsp+0x30]
000078eb87dd883e  vmovaps xmm5, [rsp+0x40]
000078eb87dd8844  vmovaps xmm6, [rsp+0x50]
000078eb87dd884a  vmovaps xmm7, [rsp+0x60]
000078eb87dd8850  vmovaps xmm8, [rsp+0x70]
000078eb87dd8856  vmovaps xmm9, [rsp+0x80]
000078eb87dd885f  vmovaps xmm10, [rsp+0x90]
000078eb87dd8868  vmovaps xmm11, [rsp+0xA0]
000078eb87dd8871  vmovaps xmm12, [rsp+0xB0]
000078eb87dd887a  vmovaps xmm13, [rsp+0xC0]
000078eb87dd8883  vmovaps xmm14, [rsp+0xD0]
000078eb87dd888c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd8895  add rsp, 0xF0
000078eb87dd889c  pop r11
000078eb87dd889e  pop r10
000078eb87dd88a0  pop r9
000078eb87dd88a2  pop r8
000078eb87dd88a4  pop rsi
000078eb87dd88a5  pop rdi
000078eb87dd88a6  pop rdx
000078eb87dd88a7  pop rcx
000078eb87dd88a8  pop rax
000078eb87dd88a9  add rsp, 0x08
000078eb87dd88ad  jmp 0x000078EB87DD60BF
000078eb87dd88b2  call 0x000078EB87CD64F0
000078eb87dd88b7  jmp 0x000078EB87DD60C9
000078eb87dd88bc  sub rsp, 0x08
000078eb87dd88c0  push rax
000078eb87dd88c1  push rcx
000078eb87dd88c2  push rdx
000078eb87dd88c3  push rdi
000078eb87dd88c4  push rsi
000078eb87dd88c5  push r8
000078eb87dd88c7  push r9
000078eb87dd88c9  push r10
000078eb87dd88cb  push r11
000078eb87dd88cd  sub rsp, 0xF0
000078eb87dd88d4  vmovaps [rsp], xmm0
000078eb87dd88d9  vmovaps [rsp+0x10], xmm1
000078eb87dd88df  vmovaps [rsp+0x20], xmm2
000078eb87dd88e5  vmovaps [rsp+0x30], xmm3
000078eb87dd88eb  vmovaps [rsp+0x40], xmm4
000078eb87dd88f1  vmovaps [rsp+0x50], xmm5
000078eb87dd88f7  vmovaps [rsp+0x60], xmm6
000078eb87dd88fd  vmovaps [rsp+0x70], xmm7
000078eb87dd8903  vmovaps [rsp+0x80], xmm8
000078eb87dd890c  vmovaps [rsp+0x90], xmm9
000078eb87dd8915  vmovaps [rsp+0xA0], xmm10
000078eb87dd891e  vmovaps [rsp+0xB0], xmm11
000078eb87dd8927  vmovaps [rsp+0xC0], xmm12
000078eb87dd8930  vmovaps [rsp+0xD0], xmm13
000078eb87dd8939  vmovaps [rsp+0xE0], xmm14
000078eb87dd8942  sub rsp, 0x30
000078eb87dd8946  movaps [rsp], xmm15
000078eb87dd894b  movaps [rsp+0x10], xmm14
000078eb87dd8951  movaps [rsp+0x20], xmm4
000078eb87dd8956  lea rdi, [rsp]
000078eb87dd895a  mov esi, 0x00
000078eb87dd895f  mov rax, 0x61D341A71530
000078eb87dd8969  call rax
000078eb87dd896b  movaps xmm15, [rsp]
000078eb87dd8970  add rsp, 0x30
000078eb87dd8974  vmovaps xmm0, [rsp]
000078eb87dd8979  vmovaps xmm1, [rsp+0x10]
000078eb87dd897f  vmovaps xmm2, [rsp+0x20]
000078eb87dd8985  vmovaps xmm3, [rsp+0x30]
000078eb87dd898b  vmovaps xmm4, [rsp+0x40]
000078eb87dd8991  vmovaps xmm5, [rsp+0x50]
000078eb87dd8997  vmovaps xmm6, [rsp+0x60]
000078eb87dd899d  vmovaps xmm7, [rsp+0x70]
000078eb87dd89a3  vmovaps xmm8, [rsp+0x80]
000078eb87dd89ac  vmovaps xmm9, [rsp+0x90]
000078eb87dd89b5  vmovaps xmm10, [rsp+0xA0]
000078eb87dd89be  vmovaps xmm11, [rsp+0xB0]
000078eb87dd89c7  vmovaps xmm12, [rsp+0xC0]
000078eb87dd89d0  vmovaps xmm13, [rsp+0xD0]
000078eb87dd89d9  vmovaps xmm14, [rsp+0xE0]
000078eb87dd89e2  add rsp, 0xF0
000078eb87dd89e9  pop r11
000078eb87dd89eb  pop r10
000078eb87dd89ed  pop r9
000078eb87dd89ef  pop r8
000078eb87dd89f1  pop rsi
000078eb87dd89f2  pop rdi
000078eb87dd89f3  pop rdx
000078eb87dd89f4  pop rcx
000078eb87dd89f5  pop rax
000078eb87dd89f6  add rsp, 0x08
000078eb87dd89fa  jmp 0x000078EB87DD60F7
000078eb87dd89ff  sub rsp, 0x08
000078eb87dd8a03  push rax
000078eb87dd8a04  push rcx
000078eb87dd8a05  push rdx
000078eb87dd8a06  push rdi
000078eb87dd8a07  push rsi
000078eb87dd8a08  push r8
000078eb87dd8a0a  push r9
000078eb87dd8a0c  push r10
000078eb87dd8a0e  push r11
000078eb87dd8a10  sub rsp, 0xF0
000078eb87dd8a17  vmovaps [rsp], xmm0
000078eb87dd8a1c  vmovaps [rsp+0x10], xmm1
000078eb87dd8a22  vmovaps [rsp+0x20], xmm2
000078eb87dd8a28  vmovaps [rsp+0x30], xmm3
000078eb87dd8a2e  vmovaps [rsp+0x40], xmm4
000078eb87dd8a34  vmovaps [rsp+0x50], xmm5
000078eb87dd8a3a  vmovaps [rsp+0x60], xmm6
000078eb87dd8a40  vmovaps [rsp+0x70], xmm7
000078eb87dd8a46  vmovaps [rsp+0x80], xmm8
000078eb87dd8a4f  vmovaps [rsp+0x90], xmm9
000078eb87dd8a58  vmovaps [rsp+0xA0], xmm10
000078eb87dd8a61  vmovaps [rsp+0xB0], xmm11
000078eb87dd8a6a  vmovaps [rsp+0xC0], xmm12
000078eb87dd8a73  vmovaps [rsp+0xD0], xmm13
000078eb87dd8a7c  vmovaps [rsp+0xE0], xmm15
000078eb87dd8a85  sub rsp, 0x30
000078eb87dd8a89  movaps [rsp], xmm14
000078eb87dd8a8e  movaps [rsp+0x10], xmm2
000078eb87dd8a93  movaps [rsp+0x20], xmm1
000078eb87dd8a98  lea rdi, [rsp]
000078eb87dd8a9c  mov esi, 0x00
000078eb87dd8aa1  mov rax, 0x61D341A71530
000078eb87dd8aab  call rax
000078eb87dd8aad  movaps xmm14, [rsp]
000078eb87dd8ab2  add rsp, 0x30
000078eb87dd8ab6  vmovaps xmm0, [rsp]
000078eb87dd8abb  vmovaps xmm1, [rsp+0x10]
000078eb87dd8ac1  vmovaps xmm2, [rsp+0x20]
000078eb87dd8ac7  vmovaps xmm3, [rsp+0x30]
000078eb87dd8acd  vmovaps xmm4, [rsp+0x40]
000078eb87dd8ad3  vmovaps xmm5, [rsp+0x50]
000078eb87dd8ad9  vmovaps xmm6, [rsp+0x60]
000078eb87dd8adf  vmovaps xmm7, [rsp+0x70]
000078eb87dd8ae5  vmovaps xmm8, [rsp+0x80]
000078eb87dd8aee  vmovaps xmm9, [rsp+0x90]
000078eb87dd8af7  vmovaps xmm10, [rsp+0xA0]
000078eb87dd8b00  vmovaps xmm11, [rsp+0xB0]
000078eb87dd8b09  vmovaps xmm12, [rsp+0xC0]
000078eb87dd8b12  vmovaps xmm13, [rsp+0xD0]
000078eb87dd8b1b  vmovaps xmm15, [rsp+0xE0]
000078eb87dd8b24  add rsp, 0xF0
000078eb87dd8b2b  pop r11
000078eb87dd8b2d  pop r10
000078eb87dd8b2f  pop r9
000078eb87dd8b31  pop r8
000078eb87dd8b33  pop rsi
000078eb87dd8b34  pop rdi
000078eb87dd8b35  pop rdx
000078eb87dd8b36  pop rcx
000078eb87dd8b37  pop rax
000078eb87dd8b38  add rsp, 0x08
000078eb87dd8b3c  jmp 0x000078EB87DD611D
000078eb87dd8b41  sub rsp, 0x08
000078eb87dd8b45  push rax
000078eb87dd8b46  push rcx
000078eb87dd8b47  push rdx
000078eb87dd8b48  push rdi
000078eb87dd8b49  push rsi
000078eb87dd8b4a  push r8
000078eb87dd8b4c  push r9
000078eb87dd8b4e  push r10
000078eb87dd8b50  push r11
000078eb87dd8b52  sub rsp, 0xF0
000078eb87dd8b59  vmovaps [rsp], xmm0
000078eb87dd8b5e  vmovaps [rsp+0x10], xmm2
000078eb87dd8b64  vmovaps [rsp+0x20], xmm3
000078eb87dd8b6a  vmovaps [rsp+0x30], xmm4
000078eb87dd8b70  vmovaps [rsp+0x40], xmm5
000078eb87dd8b76  vmovaps [rsp+0x50], xmm6
000078eb87dd8b7c  vmovaps [rsp+0x60], xmm7
000078eb87dd8b82  vmovaps [rsp+0x70], xmm8
000078eb87dd8b88  vmovaps [rsp+0x80], xmm9
000078eb87dd8b91  vmovaps [rsp+0x90], xmm10
000078eb87dd8b9a  vmovaps [rsp+0xA0], xmm11
000078eb87dd8ba3  vmovaps [rsp+0xB0], xmm12
000078eb87dd8bac  vmovaps [rsp+0xC0], xmm13
000078eb87dd8bb5  vmovaps [rsp+0xD0], xmm14
000078eb87dd8bbe  vmovaps [rsp+0xE0], xmm15
000078eb87dd8bc7  sub rsp, 0x30
000078eb87dd8bcb  movaps [rsp], xmm1
000078eb87dd8bcf  movaps [rsp+0x10], xmm4
000078eb87dd8bd4  movaps [rsp+0x20], xmm9
000078eb87dd8bda  lea rdi, [rsp]
000078eb87dd8bde  mov esi, 0x00
000078eb87dd8be3  mov rax, 0x61D341A71530
000078eb87dd8bed  call rax
000078eb87dd8bef  movaps xmm1, [rsp]
000078eb87dd8bf3  add rsp, 0x30
000078eb87dd8bf7  vmovaps xmm0, [rsp]
000078eb87dd8bfc  vmovaps xmm2, [rsp+0x10]
000078eb87dd8c02  vmovaps xmm3, [rsp+0x20]
000078eb87dd8c08  vmovaps xmm4, [rsp+0x30]
000078eb87dd8c0e  vmovaps xmm5, [rsp+0x40]
000078eb87dd8c14  vmovaps xmm6, [rsp+0x50]
000078eb87dd8c1a  vmovaps xmm7, [rsp+0x60]
000078eb87dd8c20  vmovaps xmm8, [rsp+0x70]
000078eb87dd8c26  vmovaps xmm9, [rsp+0x80]
000078eb87dd8c2f  vmovaps xmm10, [rsp+0x90]
000078eb87dd8c38  vmovaps xmm11, [rsp+0xA0]
000078eb87dd8c41  vmovaps xmm12, [rsp+0xB0]
000078eb87dd8c4a  vmovaps xmm13, [rsp+0xC0]
000078eb87dd8c53  vmovaps xmm14, [rsp+0xD0]
000078eb87dd8c5c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd8c65  add rsp, 0xF0
000078eb87dd8c6c  pop r11
000078eb87dd8c6e  pop r10
000078eb87dd8c70  pop r9
000078eb87dd8c72  pop r8
000078eb87dd8c74  pop rsi
000078eb87dd8c75  pop rdi
000078eb87dd8c76  pop rdx
000078eb87dd8c77  pop rcx
000078eb87dd8c78  pop rax
000078eb87dd8c79  add rsp, 0x08
000078eb87dd8c7d  jmp 0x000078EB87DD613B
000078eb87dd8c82  sub rsp, 0x08
000078eb87dd8c86  push rax
000078eb87dd8c87  push rcx
000078eb87dd8c88  push rdx
000078eb87dd8c89  push rdi
000078eb87dd8c8a  push rsi
000078eb87dd8c8b  push r8
000078eb87dd8c8d  push r9
000078eb87dd8c8f  push r10
000078eb87dd8c91  push r11
000078eb87dd8c93  sub rsp, 0xF0
000078eb87dd8c9a  vmovaps [rsp], xmm0
000078eb87dd8c9f  vmovaps [rsp+0x10], xmm1
000078eb87dd8ca5  vmovaps [rsp+0x20], xmm2
000078eb87dd8cab  vmovaps [rsp+0x30], xmm3
000078eb87dd8cb1  vmovaps [rsp+0x40], xmm5
000078eb87dd8cb7  vmovaps [rsp+0x50], xmm6
000078eb87dd8cbd  vmovaps [rsp+0x60], xmm7
000078eb87dd8cc3  vmovaps [rsp+0x70], xmm8
000078eb87dd8cc9  vmovaps [rsp+0x80], xmm9
000078eb87dd8cd2  vmovaps [rsp+0x90], xmm10
000078eb87dd8cdb  vmovaps [rsp+0xA0], xmm11
000078eb87dd8ce4  vmovaps [rsp+0xB0], xmm12
000078eb87dd8ced  vmovaps [rsp+0xC0], xmm13
000078eb87dd8cf6  vmovaps [rsp+0xD0], xmm14
000078eb87dd8cff  vmovaps [rsp+0xE0], xmm15
000078eb87dd8d08  sub rsp, 0x30
000078eb87dd8d0c  movaps [rsp], xmm4
000078eb87dd8d10  movaps [rsp+0x10], xmm2
000078eb87dd8d15  movaps [rsp+0x20], xmm9
000078eb87dd8d1b  lea rdi, [rsp]
000078eb87dd8d1f  mov esi, 0x00
000078eb87dd8d24  mov rax, 0x61D341A71530
000078eb87dd8d2e  call rax
000078eb87dd8d30  movaps xmm4, [rsp]
000078eb87dd8d34  add rsp, 0x30
000078eb87dd8d38  vmovaps xmm0, [rsp]
000078eb87dd8d3d  vmovaps xmm1, [rsp+0x10]
000078eb87dd8d43  vmovaps xmm2, [rsp+0x20]
000078eb87dd8d49  vmovaps xmm3, [rsp+0x30]
000078eb87dd8d4f  vmovaps xmm5, [rsp+0x40]
000078eb87dd8d55  vmovaps xmm6, [rsp+0x50]
000078eb87dd8d5b  vmovaps xmm7, [rsp+0x60]
000078eb87dd8d61  vmovaps xmm8, [rsp+0x70]
000078eb87dd8d67  vmovaps xmm9, [rsp+0x80]
000078eb87dd8d70  vmovaps xmm10, [rsp+0x90]
000078eb87dd8d79  vmovaps xmm11, [rsp+0xA0]
000078eb87dd8d82  vmovaps xmm12, [rsp+0xB0]
000078eb87dd8d8b  vmovaps xmm13, [rsp+0xC0]
000078eb87dd8d94  vmovaps xmm14, [rsp+0xD0]
000078eb87dd8d9d  vmovaps xmm15, [rsp+0xE0]
000078eb87dd8da6  add rsp, 0xF0
000078eb87dd8dad  pop r11
000078eb87dd8daf  pop r10
000078eb87dd8db1  pop r9
000078eb87dd8db3  pop r8
000078eb87dd8db5  pop rsi
000078eb87dd8db6  pop rdi
000078eb87dd8db7  pop rdx
000078eb87dd8db8  pop rcx
000078eb87dd8db9  pop rax
000078eb87dd8dba  add rsp, 0x08
000078eb87dd8dbe  jmp 0x000078EB87DD616B
000078eb87dd8dc3  sub rsp, 0x08
000078eb87dd8dc7  push rax
000078eb87dd8dc8  push rcx
000078eb87dd8dc9  push rdx
000078eb87dd8dca  push rdi
000078eb87dd8dcb  push rsi
000078eb87dd8dcc  push r8
000078eb87dd8dce  push r9
000078eb87dd8dd0  push r10
000078eb87dd8dd2  push r11
000078eb87dd8dd4  sub rsp, 0xF0
000078eb87dd8ddb  vmovaps [rsp], xmm0
000078eb87dd8de0  vmovaps [rsp+0x10], xmm1
000078eb87dd8de6  vmovaps [rsp+0x20], xmm2
000078eb87dd8dec  vmovaps [rsp+0x30], xmm3
000078eb87dd8df2  vmovaps [rsp+0x40], xmm4
000078eb87dd8df8  vmovaps [rsp+0x50], xmm5
000078eb87dd8dfe  vmovaps [rsp+0x60], xmm6
000078eb87dd8e04  vmovaps [rsp+0x70], xmm7
000078eb87dd8e0a  vmovaps [rsp+0x80], xmm8
000078eb87dd8e13  vmovaps [rsp+0x90], xmm10
000078eb87dd8e1c  vmovaps [rsp+0xA0], xmm11
000078eb87dd8e25  vmovaps [rsp+0xB0], xmm12
000078eb87dd8e2e  vmovaps [rsp+0xC0], xmm13
000078eb87dd8e37  vmovaps [rsp+0xD0], xmm14
000078eb87dd8e40  vmovaps [rsp+0xE0], xmm15
000078eb87dd8e49  sub rsp, 0x30
000078eb87dd8e4d  movaps [rsp], xmm9
000078eb87dd8e52  movaps [rsp+0x10], xmm2
000078eb87dd8e57  movaps [rsp+0x20], xmm1
000078eb87dd8e5c  lea rdi, [rsp]
000078eb87dd8e60  mov esi, 0x00
000078eb87dd8e65  mov rax, 0x61D341A71530
000078eb87dd8e6f  call rax
000078eb87dd8e71  movaps xmm9, [rsp]
000078eb87dd8e76  add rsp, 0x30
000078eb87dd8e7a  vmovaps xmm0, [rsp]
000078eb87dd8e7f  vmovaps xmm1, [rsp+0x10]
000078eb87dd8e85  vmovaps xmm2, [rsp+0x20]
000078eb87dd8e8b  vmovaps xmm3, [rsp+0x30]
000078eb87dd8e91  vmovaps xmm4, [rsp+0x40]
000078eb87dd8e97  vmovaps xmm5, [rsp+0x50]
000078eb87dd8e9d  vmovaps xmm6, [rsp+0x60]
000078eb87dd8ea3  vmovaps xmm7, [rsp+0x70]
000078eb87dd8ea9  vmovaps xmm8, [rsp+0x80]
000078eb87dd8eb2  vmovaps xmm10, [rsp+0x90]
000078eb87dd8ebb  vmovaps xmm11, [rsp+0xA0]
000078eb87dd8ec4  vmovaps xmm12, [rsp+0xB0]
000078eb87dd8ecd  vmovaps xmm13, [rsp+0xC0]
000078eb87dd8ed6  vmovaps xmm14, [rsp+0xD0]
000078eb87dd8edf  vmovaps xmm15, [rsp+0xE0]
000078eb87dd8ee8  add rsp, 0xF0
000078eb87dd8eef  pop r11
000078eb87dd8ef1  pop r10
000078eb87dd8ef3  pop r9
000078eb87dd8ef5  pop r8
000078eb87dd8ef7  pop rsi
000078eb87dd8ef8  pop rdi
000078eb87dd8ef9  pop rdx
000078eb87dd8efa  pop rcx
000078eb87dd8efb  pop rax
000078eb87dd8efc  add rsp, 0x08
000078eb87dd8f00  jmp 0x000078EB87DD61A1
000078eb87dd8f05  sub rsp, 0x08
000078eb87dd8f09  push rax
000078eb87dd8f0a  push rcx
000078eb87dd8f0b  push rdx
000078eb87dd8f0c  push rdi
000078eb87dd8f0d  push rsi
000078eb87dd8f0e  push r8
000078eb87dd8f10  push r9
000078eb87dd8f12  push r10
000078eb87dd8f14  push r11
000078eb87dd8f16  sub rsp, 0xF0
000078eb87dd8f1d  vmovaps [rsp], xmm0
000078eb87dd8f22  vmovaps [rsp+0x10], xmm2
000078eb87dd8f28  vmovaps [rsp+0x20], xmm3
000078eb87dd8f2e  vmovaps [rsp+0x30], xmm4
000078eb87dd8f34  vmovaps [rsp+0x40], xmm5
000078eb87dd8f3a  vmovaps [rsp+0x50], xmm6
000078eb87dd8f40  vmovaps [rsp+0x60], xmm7
000078eb87dd8f46  vmovaps [rsp+0x70], xmm8
000078eb87dd8f4c  vmovaps [rsp+0x80], xmm9
000078eb87dd8f55  vmovaps [rsp+0x90], xmm10
000078eb87dd8f5e  vmovaps [rsp+0xA0], xmm11
000078eb87dd8f67  vmovaps [rsp+0xB0], xmm12
000078eb87dd8f70  vmovaps [rsp+0xC0], xmm13
000078eb87dd8f79  vmovaps [rsp+0xD0], xmm14
000078eb87dd8f82  vmovaps [rsp+0xE0], xmm15
000078eb87dd8f8b  sub rsp, 0x30
000078eb87dd8f8f  movaps [rsp], xmm1
000078eb87dd8f93  movaps [rsp+0x10], xmm15
000078eb87dd8f99  movaps [rsp+0x20], xmm6
000078eb87dd8f9e  lea rdi, [rsp]
000078eb87dd8fa2  mov esi, 0x00
000078eb87dd8fa7  mov rax, 0x61D341A71530
000078eb87dd8fb1  call rax
000078eb87dd8fb3  movaps xmm1, [rsp]
000078eb87dd8fb7  add rsp, 0x30
000078eb87dd8fbb  vmovaps xmm0, [rsp]
000078eb87dd8fc0  vmovaps xmm2, [rsp+0x10]
000078eb87dd8fc6  vmovaps xmm3, [rsp+0x20]
000078eb87dd8fcc  vmovaps xmm4, [rsp+0x30]
000078eb87dd8fd2  vmovaps xmm5, [rsp+0x40]
000078eb87dd8fd8  vmovaps xmm6, [rsp+0x50]
000078eb87dd8fde  vmovaps xmm7, [rsp+0x60]
000078eb87dd8fe4  vmovaps xmm8, [rsp+0x70]
000078eb87dd8fea  vmovaps xmm9, [rsp+0x80]
000078eb87dd8ff3  vmovaps xmm10, [rsp+0x90]
000078eb87dd8ffc  vmovaps xmm11, [rsp+0xA0]
000078eb87dd9005  vmovaps xmm12, [rsp+0xB0]
000078eb87dd900e  vmovaps xmm13, [rsp+0xC0]
000078eb87dd9017  vmovaps xmm14, [rsp+0xD0]
000078eb87dd9020  vmovaps xmm15, [rsp+0xE0]
000078eb87dd9029  add rsp, 0xF0
000078eb87dd9030  pop r11
000078eb87dd9032  pop r10
000078eb87dd9034  pop r9
000078eb87dd9036  pop r8
000078eb87dd9038  pop rsi
000078eb87dd9039  pop rdi
000078eb87dd903a  pop rdx
000078eb87dd903b  pop rcx
000078eb87dd903c  pop rax
000078eb87dd903d  add rsp, 0x08
000078eb87dd9041  jmp 0x000078EB87DD61C2
000078eb87dd9046  sub rsp, 0x08
000078eb87dd904a  push rax
000078eb87dd904b  push rcx
000078eb87dd904c  push rdx
000078eb87dd904d  push rdi
000078eb87dd904e  push rsi
000078eb87dd904f  push r8
000078eb87dd9051  push r9
000078eb87dd9053  push r10
000078eb87dd9055  push r11
000078eb87dd9057  sub rsp, 0xF0
000078eb87dd905e  vmovaps [rsp], xmm0
000078eb87dd9063  vmovaps [rsp+0x10], xmm1
000078eb87dd9069  vmovaps [rsp+0x20], xmm2
000078eb87dd906f  vmovaps [rsp+0x30], xmm3
000078eb87dd9075  vmovaps [rsp+0x40], xmm4
000078eb87dd907b  vmovaps [rsp+0x50], xmm5
000078eb87dd9081  vmovaps [rsp+0x60], xmm6
000078eb87dd9087  vmovaps [rsp+0x70], xmm7
000078eb87dd908d  vmovaps [rsp+0x80], xmm8
000078eb87dd9096  vmovaps [rsp+0x90], xmm9
000078eb87dd909f  vmovaps [rsp+0xA0], xmm10
000078eb87dd90a8  vmovaps [rsp+0xB0], xmm11
000078eb87dd90b1  vmovaps [rsp+0xC0], xmm12
000078eb87dd90ba  vmovaps [rsp+0xD0], xmm13
000078eb87dd90c3  vmovaps [rsp+0xE0], xmm14
000078eb87dd90cc  sub rsp, 0x30
000078eb87dd90d0  movaps [rsp], xmm15
000078eb87dd90d5  movaps [rsp+0x10], xmm5
000078eb87dd90da  movaps [rsp+0x20], xmm3
000078eb87dd90df  lea rdi, [rsp]
000078eb87dd90e3  mov esi, 0x00
000078eb87dd90e8  mov rax, 0x61D341A71530
000078eb87dd90f2  call rax
000078eb87dd90f4  movaps xmm15, [rsp]
000078eb87dd90f9  add rsp, 0x30
000078eb87dd90fd  vmovaps xmm0, [rsp]
000078eb87dd9102  vmovaps xmm1, [rsp+0x10]
000078eb87dd9108  vmovaps xmm2, [rsp+0x20]
000078eb87dd910e  vmovaps xmm3, [rsp+0x30]
000078eb87dd9114  vmovaps xmm4, [rsp+0x40]
000078eb87dd911a  vmovaps xmm5, [rsp+0x50]
000078eb87dd9120  vmovaps xmm6, [rsp+0x60]
000078eb87dd9126  vmovaps xmm7, [rsp+0x70]
000078eb87dd912c  vmovaps xmm8, [rsp+0x80]
000078eb87dd9135  vmovaps xmm9, [rsp+0x90]
000078eb87dd913e  vmovaps xmm10, [rsp+0xA0]
000078eb87dd9147  vmovaps xmm11, [rsp+0xB0]
000078eb87dd9150  vmovaps xmm12, [rsp+0xC0]
000078eb87dd9159  vmovaps xmm13, [rsp+0xD0]
000078eb87dd9162  vmovaps xmm14, [rsp+0xE0]
000078eb87dd916b  add rsp, 0xF0
000078eb87dd9172  pop r11
000078eb87dd9174  pop r10
000078eb87dd9176  pop r9
000078eb87dd9178  pop r8
000078eb87dd917a  pop rsi
000078eb87dd917b  pop rdi
000078eb87dd917c  pop rdx
000078eb87dd917d  pop rcx
000078eb87dd917e  pop rax
000078eb87dd917f  add rsp, 0x08
000078eb87dd9183  jmp 0x000078EB87DD61DC
000078eb87dd9188  sub rsp, 0x08
000078eb87dd918c  push rax
000078eb87dd918d  push rcx
000078eb87dd918e  push rdx
000078eb87dd918f  push rdi
000078eb87dd9190  push rsi
000078eb87dd9191  push r8
000078eb87dd9193  push r9
000078eb87dd9195  push r10
000078eb87dd9197  push r11
000078eb87dd9199  sub rsp, 0xF0
000078eb87dd91a0  vmovaps [rsp], xmm0
000078eb87dd91a5  vmovaps [rsp+0x10], xmm1
000078eb87dd91ab  vmovaps [rsp+0x20], xmm2
000078eb87dd91b1  vmovaps [rsp+0x30], xmm3
000078eb87dd91b7  vmovaps [rsp+0x40], xmm4
000078eb87dd91bd  vmovaps [rsp+0x50], xmm6
000078eb87dd91c3  vmovaps [rsp+0x60], xmm7
000078eb87dd91c9  vmovaps [rsp+0x70], xmm8
000078eb87dd91cf  vmovaps [rsp+0x80], xmm9
000078eb87dd91d8  vmovaps [rsp+0x90], xmm10
000078eb87dd91e1  vmovaps [rsp+0xA0], xmm11
000078eb87dd91ea  vmovaps [rsp+0xB0], xmm12
000078eb87dd91f3  vmovaps [rsp+0xC0], xmm13
000078eb87dd91fc  vmovaps [rsp+0xD0], xmm14
000078eb87dd9205  vmovaps [rsp+0xE0], xmm15
000078eb87dd920e  sub rsp, 0x30
000078eb87dd9212  movaps [rsp], xmm5
000078eb87dd9216  movaps [rsp+0x10], xmm8
000078eb87dd921c  movaps [rsp+0x20], xmm6
000078eb87dd9221  lea rdi, [rsp]
000078eb87dd9225  mov esi, 0x00
000078eb87dd922a  mov rax, 0x61D341A71530
000078eb87dd9234  call rax
000078eb87dd9236  movaps xmm5, [rsp]
000078eb87dd923a  add rsp, 0x30
000078eb87dd923e  vmovaps xmm0, [rsp]
000078eb87dd9243  vmovaps xmm1, [rsp+0x10]
000078eb87dd9249  vmovaps xmm2, [rsp+0x20]
000078eb87dd924f  vmovaps xmm3, [rsp+0x30]
000078eb87dd9255  vmovaps xmm4, [rsp+0x40]
000078eb87dd925b  vmovaps xmm6, [rsp+0x50]
000078eb87dd9261  vmovaps xmm7, [rsp+0x60]
000078eb87dd9267  vmovaps xmm8, [rsp+0x70]
000078eb87dd926d  vmovaps xmm9, [rsp+0x80]
000078eb87dd9276  vmovaps xmm10, [rsp+0x90]
000078eb87dd927f  vmovaps xmm11, [rsp+0xA0]
000078eb87dd9288  vmovaps xmm12, [rsp+0xB0]
000078eb87dd9291  vmovaps xmm13, [rsp+0xC0]
000078eb87dd929a  vmovaps xmm14, [rsp+0xD0]
000078eb87dd92a3  vmovaps xmm15, [rsp+0xE0]
000078eb87dd92ac  add rsp, 0xF0
000078eb87dd92b3  pop r11
000078eb87dd92b5  pop r10
000078eb87dd92b7  pop r9
000078eb87dd92b9  pop r8
000078eb87dd92bb  pop rsi
000078eb87dd92bc  pop rdi
000078eb87dd92bd  pop rdx
000078eb87dd92be  pop rcx
000078eb87dd92bf  pop rax
000078eb87dd92c0  add rsp, 0x08
000078eb87dd92c4  jmp 0x000078EB87DD6200
000078eb87dd92c9  sub rsp, 0x08
000078eb87dd92cd  push rax
000078eb87dd92ce  push rcx
000078eb87dd92cf  push rdx
000078eb87dd92d0  push rdi
000078eb87dd92d1  push rsi
000078eb87dd92d2  push r8
000078eb87dd92d4  push r9
000078eb87dd92d6  push r10
000078eb87dd92d8  push r11
000078eb87dd92da  sub rsp, 0xF0
000078eb87dd92e1  vmovaps [rsp], xmm0
000078eb87dd92e6  vmovaps [rsp+0x10], xmm1
000078eb87dd92ec  vmovaps [rsp+0x20], xmm2
000078eb87dd92f2  vmovaps [rsp+0x30], xmm3
000078eb87dd92f8  vmovaps [rsp+0x40], xmm4
000078eb87dd92fe  vmovaps [rsp+0x50], xmm5
000078eb87dd9304  vmovaps [rsp+0x60], xmm7
000078eb87dd930a  vmovaps [rsp+0x70], xmm8
000078eb87dd9310  vmovaps [rsp+0x80], xmm9
000078eb87dd9319  vmovaps [rsp+0x90], xmm10
000078eb87dd9322  vmovaps [rsp+0xA0], xmm11
000078eb87dd932b  vmovaps [rsp+0xB0], xmm12
000078eb87dd9334  vmovaps [rsp+0xC0], xmm13
000078eb87dd933d  vmovaps [rsp+0xD0], xmm14
000078eb87dd9346  vmovaps [rsp+0xE0], xmm15
000078eb87dd934f  sub rsp, 0x30
000078eb87dd9353  movaps [rsp], xmm6
000078eb87dd9357  movaps [rsp+0x10], xmm10
000078eb87dd935d  movaps [rsp+0x20], xmm8
000078eb87dd9363  lea rdi, [rsp]
000078eb87dd9367  mov esi, 0x00
000078eb87dd936c  mov rax, 0x61D341A71530
000078eb87dd9376  call rax
000078eb87dd9378  movaps xmm6, [rsp]
000078eb87dd937c  add rsp, 0x30
000078eb87dd9380  vmovaps xmm0, [rsp]
000078eb87dd9385  vmovaps xmm1, [rsp+0x10]
000078eb87dd938b  vmovaps xmm2, [rsp+0x20]
000078eb87dd9391  vmovaps xmm3, [rsp+0x30]
000078eb87dd9397  vmovaps xmm4, [rsp+0x40]
000078eb87dd939d  vmovaps xmm5, [rsp+0x50]
000078eb87dd93a3  vmovaps xmm7, [rsp+0x60]
000078eb87dd93a9  vmovaps xmm8, [rsp+0x70]
000078eb87dd93af  vmovaps xmm9, [rsp+0x80]
000078eb87dd93b8  vmovaps xmm10, [rsp+0x90]
000078eb87dd93c1  vmovaps xmm11, [rsp+0xA0]
000078eb87dd93ca  vmovaps xmm12, [rsp+0xB0]
000078eb87dd93d3  vmovaps xmm13, [rsp+0xC0]
000078eb87dd93dc  vmovaps xmm14, [rsp+0xD0]
000078eb87dd93e5  vmovaps xmm15, [rsp+0xE0]
000078eb87dd93ee  add rsp, 0xF0
000078eb87dd93f5  pop r11
000078eb87dd93f7  pop r10
000078eb87dd93f9  pop r9
000078eb87dd93fb  pop r8
000078eb87dd93fd  pop rsi
000078eb87dd93fe  pop rdi
000078eb87dd93ff  pop rdx
000078eb87dd9400  pop rcx
000078eb87dd9401  pop rax
000078eb87dd9402  add rsp, 0x08
000078eb87dd9406  jmp 0x000078EB87DD6225
000078eb87dd940b  sub rsp, 0x08
000078eb87dd940f  push rax
000078eb87dd9410  push rcx
000078eb87dd9411  push rdx
000078eb87dd9412  push rdi
000078eb87dd9413  push rsi
000078eb87dd9414  push r8
000078eb87dd9416  push r9
000078eb87dd9418  push r10
000078eb87dd941a  push r11
000078eb87dd941c  sub rsp, 0xF0
000078eb87dd9423  vmovaps [rsp], xmm0
000078eb87dd9428  vmovaps [rsp+0x10], xmm1
000078eb87dd942e  vmovaps [rsp+0x20], xmm2
000078eb87dd9434  vmovaps [rsp+0x30], xmm3
000078eb87dd943a  vmovaps [rsp+0x40], xmm4
000078eb87dd9440  vmovaps [rsp+0x50], xmm5
000078eb87dd9446  vmovaps [rsp+0x60], xmm6
000078eb87dd944c  vmovaps [rsp+0x70], xmm7
000078eb87dd9452  vmovaps [rsp+0x80], xmm8
000078eb87dd945b  vmovaps [rsp+0x90], xmm9
000078eb87dd9464  vmovaps [rsp+0xA0], xmm11
000078eb87dd946d  vmovaps [rsp+0xB0], xmm12
000078eb87dd9476  vmovaps [rsp+0xC0], xmm13
000078eb87dd947f  vmovaps [rsp+0xD0], xmm14
000078eb87dd9488  vmovaps [rsp+0xE0], xmm15
000078eb87dd9491  sub rsp, 0x30
000078eb87dd9495  movaps [rsp], xmm10
000078eb87dd949a  movaps [rsp+0x10], xmm8
000078eb87dd94a0  movaps [rsp+0x20], xmm14
000078eb87dd94a6  lea rdi, [rsp]
000078eb87dd94aa  mov esi, 0x00
000078eb87dd94af  mov rax, 0x61D341A71530
000078eb87dd94b9  call rax
000078eb87dd94bb  movaps xmm10, [rsp]
000078eb87dd94c0  add rsp, 0x30
000078eb87dd94c4  vmovaps xmm0, [rsp]
000078eb87dd94c9  vmovaps xmm1, [rsp+0x10]
000078eb87dd94cf  vmovaps xmm2, [rsp+0x20]
000078eb87dd94d5  vmovaps xmm3, [rsp+0x30]
000078eb87dd94db  vmovaps xmm4, [rsp+0x40]
000078eb87dd94e1  vmovaps xmm5, [rsp+0x50]
000078eb87dd94e7  vmovaps xmm6, [rsp+0x60]
000078eb87dd94ed  vmovaps xmm7, [rsp+0x70]
000078eb87dd94f3  vmovaps xmm8, [rsp+0x80]
000078eb87dd94fc  vmovaps xmm9, [rsp+0x90]
000078eb87dd9505  vmovaps xmm11, [rsp+0xA0]
000078eb87dd950e  vmovaps xmm12, [rsp+0xB0]
000078eb87dd9517  vmovaps xmm13, [rsp+0xC0]
000078eb87dd9520  vmovaps xmm14, [rsp+0xD0]
000078eb87dd9529  vmovaps xmm15, [rsp+0xE0]
000078eb87dd9532  add rsp, 0xF0
000078eb87dd9539  pop r11
000078eb87dd953b  pop r10
000078eb87dd953d  pop r9
000078eb87dd953f  pop r8
000078eb87dd9541  pop rsi
000078eb87dd9542  pop rdi
000078eb87dd9543  pop rdx
000078eb87dd9544  pop rcx
000078eb87dd9545  pop rax
000078eb87dd9546  add rsp, 0x08
000078eb87dd954a  jmp 0x000078EB87DD6245
000078eb87dd954f  sub rsp, 0x08
000078eb87dd9553  push rax
000078eb87dd9554  push rcx
000078eb87dd9555  push rdx
000078eb87dd9556  push rdi
000078eb87dd9557  push rsi
000078eb87dd9558  push r8
000078eb87dd955a  push r9
000078eb87dd955c  push r10
000078eb87dd955e  push r11
000078eb87dd9560  sub rsp, 0xF0
000078eb87dd9567  vmovaps [rsp], xmm0
000078eb87dd956c  vmovaps [rsp+0x10], xmm1
000078eb87dd9572  vmovaps [rsp+0x20], xmm2
000078eb87dd9578  vmovaps [rsp+0x30], xmm3
000078eb87dd957e  vmovaps [rsp+0x40], xmm4
000078eb87dd9584  vmovaps [rsp+0x50], xmm5
000078eb87dd958a  vmovaps [rsp+0x60], xmm6
000078eb87dd9590  vmovaps [rsp+0x70], xmm7
000078eb87dd9596  vmovaps [rsp+0x80], xmm8
000078eb87dd959f  vmovaps [rsp+0x90], xmm9
000078eb87dd95a8  vmovaps [rsp+0xA0], xmm10
000078eb87dd95b1  vmovaps [rsp+0xB0], xmm11
000078eb87dd95ba  vmovaps [rsp+0xC0], xmm12
000078eb87dd95c3  vmovaps [rsp+0xD0], xmm13
000078eb87dd95cc  vmovaps [rsp+0xE0], xmm15
000078eb87dd95d5  sub rsp, 0x30
000078eb87dd95d9  movaps [rsp], xmm14
000078eb87dd95de  movaps [rsp+0x10], xmm8
000078eb87dd95e4  movaps [rsp+0x20], xmm4
000078eb87dd95e9  lea rdi, [rsp]
000078eb87dd95ed  mov esi, 0x00
000078eb87dd95f2  mov rax, 0x61D341A71530
000078eb87dd95fc  call rax
000078eb87dd95fe  movaps xmm14, [rsp]
000078eb87dd9603  add rsp, 0x30
000078eb87dd9607  vmovaps xmm0, [rsp]
000078eb87dd960c  vmovaps xmm1, [rsp+0x10]
000078eb87dd9612  vmovaps xmm2, [rsp+0x20]
000078eb87dd9618  vmovaps xmm3, [rsp+0x30]
000078eb87dd961e  vmovaps xmm4, [rsp+0x40]
000078eb87dd9624  vmovaps xmm5, [rsp+0x50]
000078eb87dd962a  vmovaps xmm6, [rsp+0x60]
000078eb87dd9630  vmovaps xmm7, [rsp+0x70]
000078eb87dd9636  vmovaps xmm8, [rsp+0x80]
000078eb87dd963f  vmovaps xmm9, [rsp+0x90]
000078eb87dd9648  vmovaps xmm10, [rsp+0xA0]
000078eb87dd9651  vmovaps xmm11, [rsp+0xB0]
000078eb87dd965a  vmovaps xmm12, [rsp+0xC0]
000078eb87dd9663  vmovaps xmm13, [rsp+0xD0]
000078eb87dd966c  vmovaps xmm15, [rsp+0xE0]
000078eb87dd9675  add rsp, 0xF0
000078eb87dd967c  pop r11
000078eb87dd967e  pop r10
000078eb87dd9680  pop r9
000078eb87dd9682  pop r8
000078eb87dd9684  pop rsi
000078eb87dd9685  pop rdi
000078eb87dd9686  pop rdx
000078eb87dd9687  pop rcx
000078eb87dd9688  pop rax
000078eb87dd9689  add rsp, 0x08
000078eb87dd968d  jmp 0x000078EB87DD6265
000078eb87dd9692  sub rsp, 0x08
000078eb87dd9696  push rax
000078eb87dd9697  push rcx
000078eb87dd9698  push rdx
000078eb87dd9699  push rdi
000078eb87dd969a  push rsi
000078eb87dd969b  push r8
000078eb87dd969d  push r9
000078eb87dd969f  push r10
000078eb87dd96a1  push r11
000078eb87dd96a3  sub rsp, 0xF0
000078eb87dd96aa  vmovaps [rsp], xmm0
000078eb87dd96af  vmovaps [rsp+0x10], xmm1
000078eb87dd96b5  vmovaps [rsp+0x20], xmm2
000078eb87dd96bb  vmovaps [rsp+0x30], xmm3
000078eb87dd96c1  vmovaps [rsp+0x40], xmm5
000078eb87dd96c7  vmovaps [rsp+0x50], xmm6
000078eb87dd96cd  vmovaps [rsp+0x60], xmm7
000078eb87dd96d3  vmovaps [rsp+0x70], xmm8
000078eb87dd96d9  vmovaps [rsp+0x80], xmm9
000078eb87dd96e2  vmovaps [rsp+0x90], xmm10
000078eb87dd96eb  vmovaps [rsp+0xA0], xmm11
000078eb87dd96f4  vmovaps [rsp+0xB0], xmm12
000078eb87dd96fd  vmovaps [rsp+0xC0], xmm13
000078eb87dd9706  vmovaps [rsp+0xD0], xmm14
000078eb87dd970f  vmovaps [rsp+0xE0], xmm15
000078eb87dd9718  sub rsp, 0x30
000078eb87dd971c  movaps [rsp], xmm4
000078eb87dd9720  movaps [rsp+0x10], xmm13
000078eb87dd9726  movaps [rsp+0x20], xmm8
000078eb87dd972c  lea rdi, [rsp]
000078eb87dd9730  mov esi, 0x00
000078eb87dd9735  mov rax, 0x61D341A71530
000078eb87dd973f  call rax
000078eb87dd9741  movaps xmm4, [rsp]
000078eb87dd9745  add rsp, 0x30
000078eb87dd9749  vmovaps xmm0, [rsp]
000078eb87dd974e  vmovaps xmm1, [rsp+0x10]
000078eb87dd9754  vmovaps xmm2, [rsp+0x20]
000078eb87dd975a  vmovaps xmm3, [rsp+0x30]
000078eb87dd9760  vmovaps xmm5, [rsp+0x40]
000078eb87dd9766  vmovaps xmm6, [rsp+0x50]
000078eb87dd976c  vmovaps xmm7, [rsp+0x60]
000078eb87dd9772  vmovaps xmm8, [rsp+0x70]
000078eb87dd9778  vmovaps xmm9, [rsp+0x80]
000078eb87dd9781  vmovaps xmm10, [rsp+0x90]
000078eb87dd978a  vmovaps xmm11, [rsp+0xA0]
000078eb87dd9793  vmovaps xmm12, [rsp+0xB0]
000078eb87dd979c  vmovaps xmm13, [rsp+0xC0]
000078eb87dd97a5  vmovaps xmm14, [rsp+0xD0]
000078eb87dd97ae  vmovaps xmm15, [rsp+0xE0]
000078eb87dd97b7  add rsp, 0xF0
000078eb87dd97be  pop r11
000078eb87dd97c0  pop r10
000078eb87dd97c2  pop r9
000078eb87dd97c4  pop r8
000078eb87dd97c6  pop rsi
000078eb87dd97c7  pop rdi
000078eb87dd97c8  pop rdx
000078eb87dd97c9  pop rcx
000078eb87dd97ca  pop rax
000078eb87dd97cb  add rsp, 0x08
000078eb87dd97cf  jmp 0x000078EB87DD628A
000078eb87dd97d4  sub rsp, 0x08
000078eb87dd97d8  push rax
000078eb87dd97d9  push rcx
000078eb87dd97da  push rdx
000078eb87dd97db  push rdi
000078eb87dd97dc  push rsi
000078eb87dd97dd  push r8
000078eb87dd97df  push r9
000078eb87dd97e1  push r10
000078eb87dd97e3  push r11
000078eb87dd97e5  sub rsp, 0xF0
000078eb87dd97ec  vmovaps [rsp], xmm0
000078eb87dd97f1  vmovaps [rsp+0x10], xmm1
000078eb87dd97f7  vmovaps [rsp+0x20], xmm2
000078eb87dd97fd  vmovaps [rsp+0x30], xmm3
000078eb87dd9803  vmovaps [rsp+0x40], xmm4
000078eb87dd9809  vmovaps [rsp+0x50], xmm5
000078eb87dd980f  vmovaps [rsp+0x60], xmm6
000078eb87dd9815  vmovaps [rsp+0x70], xmm7
000078eb87dd981b  vmovaps [rsp+0x80], xmm8
000078eb87dd9824  vmovaps [rsp+0x90], xmm9
000078eb87dd982d  vmovaps [rsp+0xA0], xmm10
000078eb87dd9836  vmovaps [rsp+0xB0], xmm11
000078eb87dd983f  vmovaps [rsp+0xC0], xmm12
000078eb87dd9848  vmovaps [rsp+0xD0], xmm14
000078eb87dd9851  vmovaps [rsp+0xE0], xmm15
000078eb87dd985a  sub rsp, 0x30
000078eb87dd985e  movaps [rsp], xmm13
000078eb87dd9863  movaps [rsp+0x10], xmm15
000078eb87dd9869  movaps [rsp+0x20], xmm9
000078eb87dd986f  lea rdi, [rsp]
000078eb87dd9873  mov esi, 0x00
000078eb87dd9878  mov rax, 0x61D341A71530
000078eb87dd9882  call rax
000078eb87dd9884  movaps xmm13, [rsp]
000078eb87dd9889  add rsp, 0x30
000078eb87dd988d  vmovaps xmm0, [rsp]
000078eb87dd9892  vmovaps xmm1, [rsp+0x10]
000078eb87dd9898  vmovaps xmm2, [rsp+0x20]
000078eb87dd989e  vmovaps xmm3, [rsp+0x30]
000078eb87dd98a4  vmovaps xmm4, [rsp+0x40]
000078eb87dd98aa  vmovaps xmm5, [rsp+0x50]
000078eb87dd98b0  vmovaps xmm6, [rsp+0x60]
000078eb87dd98b6  vmovaps xmm7, [rsp+0x70]
000078eb87dd98bc  vmovaps xmm8, [rsp+0x80]
000078eb87dd98c5  vmovaps xmm9, [rsp+0x90]
000078eb87dd98ce  vmovaps xmm10, [rsp+0xA0]
000078eb87dd98d7  vmovaps xmm11, [rsp+0xB0]
000078eb87dd98e0  vmovaps xmm12, [rsp+0xC0]
000078eb87dd98e9  vmovaps xmm14, [rsp+0xD0]
000078eb87dd98f2  vmovaps xmm15, [rsp+0xE0]
000078eb87dd98fb  add rsp, 0xF0
000078eb87dd9902  pop r11
000078eb87dd9904  pop r10
000078eb87dd9906  pop r9
000078eb87dd9908  pop r8
000078eb87dd990a  pop rsi
000078eb87dd990b  pop rdi
000078eb87dd990c  pop rdx
000078eb87dd990d  pop rcx
000078eb87dd990e  pop rax
000078eb87dd990f  add rsp, 0x08
000078eb87dd9913  jmp 0x000078EB87DD62A5
000078eb87dd9918  sub rsp, 0x08
000078eb87dd991c  push rax
000078eb87dd991d  push rcx
000078eb87dd991e  push rdx
000078eb87dd991f  push rdi
000078eb87dd9920  push rsi
000078eb87dd9921  push r8
000078eb87dd9923  push r9
000078eb87dd9925  push r10
000078eb87dd9927  push r11
000078eb87dd9929  sub rsp, 0xF0
000078eb87dd9930  vmovaps [rsp], xmm0
000078eb87dd9935  vmovaps [rsp+0x10], xmm1
000078eb87dd993b  vmovaps [rsp+0x20], xmm2
000078eb87dd9941  vmovaps [rsp+0x30], xmm3
000078eb87dd9947  vmovaps [rsp+0x40], xmm4
000078eb87dd994d  vmovaps [rsp+0x50], xmm5
000078eb87dd9953  vmovaps [rsp+0x60], xmm6
000078eb87dd9959  vmovaps [rsp+0x70], xmm7
000078eb87dd995f  vmovaps [rsp+0x80], xmm8
000078eb87dd9968  vmovaps [rsp+0x90], xmm9
000078eb87dd9971  vmovaps [rsp+0xA0], xmm10
000078eb87dd997a  vmovaps [rsp+0xB0], xmm11
000078eb87dd9983  vmovaps [rsp+0xC0], xmm12
000078eb87dd998c  vmovaps [rsp+0xD0], xmm13
000078eb87dd9995  vmovaps [rsp+0xE0], xmm14
000078eb87dd999e  sub rsp, 0x30
000078eb87dd99a2  movaps [rsp], xmm15
000078eb87dd99a7  movaps [rsp+0x10], xmm1
000078eb87dd99ac  movaps [rsp+0x20], xmm5
000078eb87dd99b1  lea rdi, [rsp]
000078eb87dd99b5  mov esi, 0x00
000078eb87dd99ba  mov rax, 0x61D341A71530
000078eb87dd99c4  call rax
000078eb87dd99c6  movaps xmm15, [rsp]
000078eb87dd99cb  add rsp, 0x30
000078eb87dd99cf  vmovaps xmm0, [rsp]
000078eb87dd99d4  vmovaps xmm1, [rsp+0x10]
000078eb87dd99da  vmovaps xmm2, [rsp+0x20]
000078eb87dd99e0  vmovaps xmm3, [rsp+0x30]
000078eb87dd99e6  vmovaps xmm4, [rsp+0x40]
000078eb87dd99ec  vmovaps xmm5, [rsp+0x50]
000078eb87dd99f2  vmovaps xmm6, [rsp+0x60]
000078eb87dd99f8  vmovaps xmm7, [rsp+0x70]
000078eb87dd99fe  vmovaps xmm8, [rsp+0x80]
000078eb87dd9a07  vmovaps xmm9, [rsp+0x90]
000078eb87dd9a10  vmovaps xmm10, [rsp+0xA0]
000078eb87dd9a19  vmovaps xmm11, [rsp+0xB0]
000078eb87dd9a22  vmovaps xmm12, [rsp+0xC0]
000078eb87dd9a2b  vmovaps xmm13, [rsp+0xD0]
000078eb87dd9a34  vmovaps xmm14, [rsp+0xE0]
000078eb87dd9a3d  add rsp, 0xF0
000078eb87dd9a44  pop r11
000078eb87dd9a46  pop r10
000078eb87dd9a48  pop r9
000078eb87dd9a4a  pop r8
000078eb87dd9a4c  pop rsi
000078eb87dd9a4d  pop rdi
000078eb87dd9a4e  pop rdx
000078eb87dd9a4f  pop rcx
000078eb87dd9a50  pop rax
000078eb87dd9a51  add rsp, 0x08
000078eb87dd9a55  jmp 0x000078EB87DD62C0
000078eb87dd9a5a  call 0x000078EB87CD64F0
000078eb87dd9a5f  jmp 0x000078EB87DD631B
000078eb87dd9a64  sub rsp, 0x08
000078eb87dd9a68  push rax
000078eb87dd9a69  push rcx
000078eb87dd9a6a  push rdx
000078eb87dd9a6b  push rdi
000078eb87dd9a6c  push rsi
000078eb87dd9a6d  push r8
000078eb87dd9a6f  push r9
000078eb87dd9a71  push r10
000078eb87dd9a73  push r11
000078eb87dd9a75  sub rsp, 0xF0
000078eb87dd9a7c  vmovaps [rsp], xmm0
000078eb87dd9a81  vmovaps [rsp+0x10], xmm1
000078eb87dd9a87  vmovaps [rsp+0x20], xmm2
000078eb87dd9a8d  vmovaps [rsp+0x30], xmm3
000078eb87dd9a93  vmovaps [rsp+0x40], xmm4
000078eb87dd9a99  vmovaps [rsp+0x50], xmm5
000078eb87dd9a9f  vmovaps [rsp+0x60], xmm6
000078eb87dd9aa5  vmovaps [rsp+0x70], xmm7
000078eb87dd9aab  vmovaps [rsp+0x80], xmm8
000078eb87dd9ab4  vmovaps [rsp+0x90], xmm10
000078eb87dd9abd  vmovaps [rsp+0xA0], xmm11
000078eb87dd9ac6  vmovaps [rsp+0xB0], xmm12
000078eb87dd9acf  vmovaps [rsp+0xC0], xmm13
000078eb87dd9ad8  vmovaps [rsp+0xD0], xmm14
000078eb87dd9ae1  vmovaps [rsp+0xE0], xmm15
000078eb87dd9aea  sub rsp, 0x30
000078eb87dd9aee  movaps [rsp], xmm9
000078eb87dd9af3  movaps [rsp+0x10], xmm8
000078eb87dd9af9  movaps [rsp+0x20], xmm11
000078eb87dd9aff  lea rdi, [rsp]
000078eb87dd9b03  mov esi, 0x00
000078eb87dd9b08  mov rax, 0x61D341A71530
000078eb87dd9b12  call rax
000078eb87dd9b14  movaps xmm9, [rsp]
000078eb87dd9b19  add rsp, 0x30
000078eb87dd9b1d  vmovaps xmm0, [rsp]
000078eb87dd9b22  vmovaps xmm1, [rsp+0x10]
000078eb87dd9b28  vmovaps xmm2, [rsp+0x20]
000078eb87dd9b2e  vmovaps xmm3, [rsp+0x30]
000078eb87dd9b34  vmovaps xmm4, [rsp+0x40]
000078eb87dd9b3a  vmovaps xmm5, [rsp+0x50]
000078eb87dd9b40  vmovaps xmm6, [rsp+0x60]
000078eb87dd9b46  vmovaps xmm7, [rsp+0x70]
000078eb87dd9b4c  vmovaps xmm8, [rsp+0x80]
000078eb87dd9b55  vmovaps xmm10, [rsp+0x90]
000078eb87dd9b5e  vmovaps xmm11, [rsp+0xA0]
000078eb87dd9b67  vmovaps xmm12, [rsp+0xB0]
000078eb87dd9b70  vmovaps xmm13, [rsp+0xC0]
000078eb87dd9b79  vmovaps xmm14, [rsp+0xD0]
000078eb87dd9b82  vmovaps xmm15, [rsp+0xE0]
000078eb87dd9b8b  add rsp, 0xF0
000078eb87dd9b92  pop r11
000078eb87dd9b94  pop r10
000078eb87dd9b96  pop r9
000078eb87dd9b98  pop r8
000078eb87dd9b9a  pop rsi
000078eb87dd9b9b  pop rdi
000078eb87dd9b9c  pop rdx
000078eb87dd9b9d  pop rcx
000078eb87dd9b9e  pop rax
000078eb87dd9b9f  add rsp, 0x08
000078eb87dd9ba3  jmp 0x000078EB87DD6352
000078eb87dd9ba8  sub rsp, 0x08
000078eb87dd9bac  push rax
000078eb87dd9bad  push rcx
000078eb87dd9bae  push rdx
000078eb87dd9baf  push rdi
000078eb87dd9bb0  push rsi
000078eb87dd9bb1  push r8
000078eb87dd9bb3  push r9
000078eb87dd9bb5  push r10
000078eb87dd9bb7  push r11
000078eb87dd9bb9  sub rsp, 0xF0
000078eb87dd9bc0  vmovaps [rsp], xmm0
000078eb87dd9bc5  vmovaps [rsp+0x10], xmm1
000078eb87dd9bcb  vmovaps [rsp+0x20], xmm2
000078eb87dd9bd1  vmovaps [rsp+0x30], xmm3
000078eb87dd9bd7  vmovaps [rsp+0x40], xmm4
000078eb87dd9bdd  vmovaps [rsp+0x50], xmm5
000078eb87dd9be3  vmovaps [rsp+0x60], xmm6
000078eb87dd9be9  vmovaps [rsp+0x70], xmm7
000078eb87dd9bef  vmovaps [rsp+0x80], xmm8
000078eb87dd9bf8  vmovaps [rsp+0x90], xmm9
000078eb87dd9c01  vmovaps [rsp+0xA0], xmm10
000078eb87dd9c0a  vmovaps [rsp+0xB0], xmm12
000078eb87dd9c13  vmovaps [rsp+0xC0], xmm13
000078eb87dd9c1c  vmovaps [rsp+0xD0], xmm14
000078eb87dd9c25  vmovaps [rsp+0xE0], xmm15
000078eb87dd9c2e  sub rsp, 0x30
000078eb87dd9c32  movaps [rsp], xmm11
000078eb87dd9c37  movaps [rsp+0x10], xmm10
000078eb87dd9c3d  movaps [rsp+0x20], xmm6
000078eb87dd9c42  lea rdi, [rsp]
000078eb87dd9c46  mov esi, 0x00
000078eb87dd9c4b  mov rax, 0x61D341A71530
000078eb87dd9c55  call rax
000078eb87dd9c57  movaps xmm11, [rsp]
000078eb87dd9c5c  add rsp, 0x30
000078eb87dd9c60  vmovaps xmm0, [rsp]
000078eb87dd9c65  vmovaps xmm1, [rsp+0x10]
000078eb87dd9c6b  vmovaps xmm2, [rsp+0x20]
000078eb87dd9c71  vmovaps xmm3, [rsp+0x30]
000078eb87dd9c77  vmovaps xmm4, [rsp+0x40]
000078eb87dd9c7d  vmovaps xmm5, [rsp+0x50]
000078eb87dd9c83  vmovaps xmm6, [rsp+0x60]
000078eb87dd9c89  vmovaps xmm7, [rsp+0x70]
000078eb87dd9c8f  vmovaps xmm8, [rsp+0x80]
000078eb87dd9c98  vmovaps xmm9, [rsp+0x90]
000078eb87dd9ca1  vmovaps xmm10, [rsp+0xA0]
000078eb87dd9caa  vmovaps xmm12, [rsp+0xB0]
000078eb87dd9cb3  vmovaps xmm13, [rsp+0xC0]
000078eb87dd9cbc  vmovaps xmm14, [rsp+0xD0]
000078eb87dd9cc5  vmovaps xmm15, [rsp+0xE0]
000078eb87dd9cce  add rsp, 0xF0
000078eb87dd9cd5  pop r11
000078eb87dd9cd7  pop r10
000078eb87dd9cd9  pop r9
000078eb87dd9cdb  pop r8
000078eb87dd9cdd  pop rsi
000078eb87dd9cde  pop rdi
000078eb87dd9cdf  pop rdx
000078eb87dd9ce0  pop rcx
000078eb87dd9ce1  pop rax
000078eb87dd9ce2  add rsp, 0x08
000078eb87dd9ce6  jmp 0x000078EB87DD636D
000078eb87dd9ceb  sub rsp, 0x08
000078eb87dd9cef  push rax
000078eb87dd9cf0  push rcx
000078eb87dd9cf1  push rdx
000078eb87dd9cf2  push rdi
000078eb87dd9cf3  push rsi
000078eb87dd9cf4  push r8
000078eb87dd9cf6  push r9
000078eb87dd9cf8  push r10
000078eb87dd9cfa  push r11
000078eb87dd9cfc  sub rsp, 0xF0
000078eb87dd9d03  vmovaps [rsp], xmm0
000078eb87dd9d08  vmovaps [rsp+0x10], xmm1
000078eb87dd9d0e  vmovaps [rsp+0x20], xmm2
000078eb87dd9d14  vmovaps [rsp+0x30], xmm3
000078eb87dd9d1a  vmovaps [rsp+0x40], xmm4
000078eb87dd9d20  vmovaps [rsp+0x50], xmm5
000078eb87dd9d26  vmovaps [rsp+0x60], xmm6
000078eb87dd9d2c  vmovaps [rsp+0x70], xmm7
000078eb87dd9d32  vmovaps [rsp+0x80], xmm8
000078eb87dd9d3b  vmovaps [rsp+0x90], xmm9
000078eb87dd9d44  vmovaps [rsp+0xA0], xmm11
000078eb87dd9d4d  vmovaps [rsp+0xB0], xmm12
000078eb87dd9d56  vmovaps [rsp+0xC0], xmm13
000078eb87dd9d5f  vmovaps [rsp+0xD0], xmm14
000078eb87dd9d68  vmovaps [rsp+0xE0], xmm15
000078eb87dd9d71  sub rsp, 0x30
000078eb87dd9d75  movaps [rsp], xmm10
000078eb87dd9d7a  movaps [rsp+0x10], xmm14
000078eb87dd9d80  movaps [rsp+0x20], xmm4
000078eb87dd9d85  lea rdi, [rsp]
000078eb87dd9d89  mov esi, 0x00
000078eb87dd9d8e  mov rax, 0x61D341A71530
000078eb87dd9d98  call rax
000078eb87dd9d9a  movaps xmm10, [rsp]
000078eb87dd9d9f  add rsp, 0x30
000078eb87dd9da3  vmovaps xmm0, [rsp]
000078eb87dd9da8  vmovaps xmm1, [rsp+0x10]
000078eb87dd9dae  vmovaps xmm2, [rsp+0x20]
000078eb87dd9db4  vmovaps xmm3, [rsp+0x30]
000078eb87dd9dba  vmovaps xmm4, [rsp+0x40]
000078eb87dd9dc0  vmovaps xmm5, [rsp+0x50]
000078eb87dd9dc6  vmovaps xmm6, [rsp+0x60]
000078eb87dd9dcc  vmovaps xmm7, [rsp+0x70]
000078eb87dd9dd2  vmovaps xmm8, [rsp+0x80]
000078eb87dd9ddb  vmovaps xmm9, [rsp+0x90]
000078eb87dd9de4  vmovaps xmm11, [rsp+0xA0]
000078eb87dd9ded  vmovaps xmm12, [rsp+0xB0]
000078eb87dd9df6  vmovaps xmm13, [rsp+0xC0]
000078eb87dd9dff  vmovaps xmm14, [rsp+0xD0]
000078eb87dd9e08  vmovaps xmm15, [rsp+0xE0]
000078eb87dd9e11  add rsp, 0xF0
000078eb87dd9e18  pop r11
000078eb87dd9e1a  pop r10
000078eb87dd9e1c  pop r9
000078eb87dd9e1e  pop r8
000078eb87dd9e20  pop rsi
000078eb87dd9e21  pop rdi
000078eb87dd9e22  pop rdx
000078eb87dd9e23  pop rcx
000078eb87dd9e24  pop rax
000078eb87dd9e25  add rsp, 0x08
000078eb87dd9e29  jmp 0x000078EB87DD6388
000078eb87dd9e2e  sub rsp, 0x08
000078eb87dd9e32  push rax
000078eb87dd9e33  push rcx
000078eb87dd9e34  push rdx
000078eb87dd9e35  push rdi
000078eb87dd9e36  push rsi
000078eb87dd9e37  push r8
000078eb87dd9e39  push r9
000078eb87dd9e3b  push r10
000078eb87dd9e3d  push r11
000078eb87dd9e3f  sub rsp, 0xF0
000078eb87dd9e46  vmovaps [rsp], xmm0
000078eb87dd9e4b  vmovaps [rsp+0x10], xmm1
000078eb87dd9e51  vmovaps [rsp+0x20], xmm2
000078eb87dd9e57  vmovaps [rsp+0x30], xmm3
000078eb87dd9e5d  vmovaps [rsp+0x40], xmm4
000078eb87dd9e63  vmovaps [rsp+0x50], xmm5
000078eb87dd9e69  vmovaps [rsp+0x60], xmm6
000078eb87dd9e6f  vmovaps [rsp+0x70], xmm7
000078eb87dd9e75  vmovaps [rsp+0x80], xmm9
000078eb87dd9e7e  vmovaps [rsp+0x90], xmm10
000078eb87dd9e87  vmovaps [rsp+0xA0], xmm11
000078eb87dd9e90  vmovaps [rsp+0xB0], xmm12
000078eb87dd9e99  vmovaps [rsp+0xC0], xmm13
000078eb87dd9ea2  vmovaps [rsp+0xD0], xmm14
000078eb87dd9eab  vmovaps [rsp+0xE0], xmm15
000078eb87dd9eb4  sub rsp, 0x30
000078eb87dd9eb8  movaps [rsp], xmm8
000078eb87dd9ebd  movaps [rsp+0x10], xmm1
000078eb87dd9ec2  movaps [rsp+0x20], xmm14
000078eb87dd9ec8  lea rdi, [rsp]
000078eb87dd9ecc  mov esi, 0x00
000078eb87dd9ed1  mov rax, 0x61D341A71530
000078eb87dd9edb  call rax
000078eb87dd9edd  movaps xmm8, [rsp]
000078eb87dd9ee2  add rsp, 0x30
000078eb87dd9ee6  vmovaps xmm0, [rsp]
000078eb87dd9eeb  vmovaps xmm1, [rsp+0x10]
000078eb87dd9ef1  vmovaps xmm2, [rsp+0x20]
000078eb87dd9ef7  vmovaps xmm3, [rsp+0x30]
000078eb87dd9efd  vmovaps xmm4, [rsp+0x40]
000078eb87dd9f03  vmovaps xmm5, [rsp+0x50]
000078eb87dd9f09  vmovaps xmm6, [rsp+0x60]
000078eb87dd9f0f  vmovaps xmm7, [rsp+0x70]
000078eb87dd9f15  vmovaps xmm9, [rsp+0x80]
000078eb87dd9f1e  vmovaps xmm10, [rsp+0x90]
000078eb87dd9f27  vmovaps xmm11, [rsp+0xA0]
000078eb87dd9f30  vmovaps xmm12, [rsp+0xB0]
000078eb87dd9f39  vmovaps xmm13, [rsp+0xC0]
000078eb87dd9f42  vmovaps xmm14, [rsp+0xD0]
000078eb87dd9f4b  vmovaps xmm15, [rsp+0xE0]
000078eb87dd9f54  add rsp, 0xF0
000078eb87dd9f5b  pop r11
000078eb87dd9f5d  pop r10
000078eb87dd9f5f  pop r9
000078eb87dd9f61  pop r8
000078eb87dd9f63  pop rsi
000078eb87dd9f64  pop rdi
000078eb87dd9f65  pop rdx
000078eb87dd9f66  pop rcx
000078eb87dd9f67  pop rax
000078eb87dd9f68  add rsp, 0x08
000078eb87dd9f6c  jmp 0x000078EB87DD63AE
000078eb87dd9f71  sub rsp, 0x08
000078eb87dd9f75  push rax
000078eb87dd9f76  push rcx
000078eb87dd9f77  push rdx
000078eb87dd9f78  push rdi
000078eb87dd9f79  push rsi
000078eb87dd9f7a  push r8
000078eb87dd9f7c  push r9
000078eb87dd9f7e  push r10
000078eb87dd9f80  push r11
000078eb87dd9f82  sub rsp, 0xF0
000078eb87dd9f89  vmovaps [rsp], xmm0
000078eb87dd9f8e  vmovaps [rsp+0x10], xmm1
000078eb87dd9f94  vmovaps [rsp+0x20], xmm2
000078eb87dd9f9a  vmovaps [rsp+0x30], xmm3
000078eb87dd9fa0  vmovaps [rsp+0x40], xmm4
000078eb87dd9fa6  vmovaps [rsp+0x50], xmm5
000078eb87dd9fac  vmovaps [rsp+0x60], xmm7
000078eb87dd9fb2  vmovaps [rsp+0x70], xmm8
000078eb87dd9fb8  vmovaps [rsp+0x80], xmm9
000078eb87dd9fc1  vmovaps [rsp+0x90], xmm10
000078eb87dd9fca  vmovaps [rsp+0xA0], xmm11
000078eb87dd9fd3  vmovaps [rsp+0xB0], xmm12
000078eb87dd9fdc  vmovaps [rsp+0xC0], xmm13
000078eb87dd9fe5  vmovaps [rsp+0xD0], xmm14
000078eb87dd9fee  vmovaps [rsp+0xE0], xmm15
000078eb87dd9ff7  sub rsp, 0x30
000078eb87dd9ffb  movaps [rsp], xmm6
000078eb87dd9fff  movaps [rsp+0x10], xmm1
000078eb87dda004  movaps [rsp+0x20], xmm14
000078eb87dda00a  lea rdi, [rsp]
000078eb87dda00e  mov esi, 0x00
000078eb87dda013  mov rax, 0x61D341A71530
000078eb87dda01d  call rax
000078eb87dda01f  movaps xmm6, [rsp]
000078eb87dda023  add rsp, 0x30
000078eb87dda027  vmovaps xmm0, [rsp]
000078eb87dda02c  vmovaps xmm1, [rsp+0x10]
000078eb87dda032  vmovaps xmm2, [rsp+0x20]
000078eb87dda038  vmovaps xmm3, [rsp+0x30]
000078eb87dda03e  vmovaps xmm4, [rsp+0x40]
000078eb87dda044  vmovaps xmm5, [rsp+0x50]
000078eb87dda04a  vmovaps xmm7, [rsp+0x60]
000078eb87dda050  vmovaps xmm8, [rsp+0x70]
000078eb87dda056  vmovaps xmm9, [rsp+0x80]
000078eb87dda05f  vmovaps xmm10, [rsp+0x90]
000078eb87dda068  vmovaps xmm11, [rsp+0xA0]
000078eb87dda071  vmovaps xmm12, [rsp+0xB0]
000078eb87dda07a  vmovaps xmm13, [rsp+0xC0]
000078eb87dda083  vmovaps xmm14, [rsp+0xD0]
000078eb87dda08c  vmovaps xmm15, [rsp+0xE0]
000078eb87dda095  add rsp, 0xF0
000078eb87dda09c  pop r11
000078eb87dda09e  pop r10
000078eb87dda0a0  pop r9
000078eb87dda0a2  pop r8
000078eb87dda0a4  pop rsi
000078eb87dda0a5  pop rdi
000078eb87dda0a6  pop rdx
000078eb87dda0a7  pop rcx
000078eb87dda0a8  pop rax
000078eb87dda0a9  add rsp, 0x08
000078eb87dda0ad  jmp 0x000078EB87DD63DA
000078eb87dda0b2  sub rsp, 0x08
000078eb87dda0b6  push rax
000078eb87dda0b7  push rcx
000078eb87dda0b8  push rdx
000078eb87dda0b9  push rdi
000078eb87dda0ba  push rsi
000078eb87dda0bb  push r8
000078eb87dda0bd  push r9
000078eb87dda0bf  push r10
000078eb87dda0c1  push r11
000078eb87dda0c3  sub rsp, 0xF0
000078eb87dda0ca  vmovaps [rsp], xmm0
000078eb87dda0cf  vmovaps [rsp+0x10], xmm1
000078eb87dda0d5  vmovaps [rsp+0x20], xmm2
000078eb87dda0db  vmovaps [rsp+0x30], xmm3
000078eb87dda0e1  vmovaps [rsp+0x40], xmm4
000078eb87dda0e7  vmovaps [rsp+0x50], xmm5
000078eb87dda0ed  vmovaps [rsp+0x60], xmm6
000078eb87dda0f3  vmovaps [rsp+0x70], xmm7
000078eb87dda0f9  vmovaps [rsp+0x80], xmm8
000078eb87dda102  vmovaps [rsp+0x90], xmm9
000078eb87dda10b  vmovaps [rsp+0xA0], xmm10
000078eb87dda114  vmovaps [rsp+0xB0], xmm11
000078eb87dda11d  vmovaps [rsp+0xC0], xmm12
000078eb87dda126  vmovaps [rsp+0xD0], xmm13
000078eb87dda12f  vmovaps [rsp+0xE0], xmm15
000078eb87dda138  sub rsp, 0x30
000078eb87dda13c  movaps [rsp], xmm14
000078eb87dda141  movaps [rsp+0x10], xmm12
000078eb87dda147  movaps [rsp+0x20], xmm1
000078eb87dda14c  lea rdi, [rsp]
000078eb87dda150  mov esi, 0x00
000078eb87dda155  mov rax, 0x61D341A71530
000078eb87dda15f  call rax
000078eb87dda161  movaps xmm14, [rsp]
000078eb87dda166  add rsp, 0x30
000078eb87dda16a  vmovaps xmm0, [rsp]
000078eb87dda16f  vmovaps xmm1, [rsp+0x10]
000078eb87dda175  vmovaps xmm2, [rsp+0x20]
000078eb87dda17b  vmovaps xmm3, [rsp+0x30]
000078eb87dda181  vmovaps xmm4, [rsp+0x40]
000078eb87dda187  vmovaps xmm5, [rsp+0x50]
000078eb87dda18d  vmovaps xmm6, [rsp+0x60]
000078eb87dda193  vmovaps xmm7, [rsp+0x70]
000078eb87dda199  vmovaps xmm8, [rsp+0x80]
000078eb87dda1a2  vmovaps xmm9, [rsp+0x90]
000078eb87dda1ab  vmovaps xmm10, [rsp+0xA0]
000078eb87dda1b4  vmovaps xmm11, [rsp+0xB0]
000078eb87dda1bd  vmovaps xmm12, [rsp+0xC0]
000078eb87dda1c6  vmovaps xmm13, [rsp+0xD0]
000078eb87dda1cf  vmovaps xmm15, [rsp+0xE0]
000078eb87dda1d8  add rsp, 0xF0
000078eb87dda1df  pop r11
000078eb87dda1e1  pop r10
000078eb87dda1e3  pop r9
000078eb87dda1e5  pop r8
000078eb87dda1e7  pop rsi
000078eb87dda1e8  pop rdi
000078eb87dda1e9  pop rdx
000078eb87dda1ea  pop rcx
000078eb87dda1eb  pop rax
000078eb87dda1ec  add rsp, 0x08
000078eb87dda1f0  jmp 0x000078EB87DD6400
000078eb87dda1f5  sub rsp, 0x08
000078eb87dda1f9  push rax
000078eb87dda1fa  push rcx
000078eb87dda1fb  push rdx
000078eb87dda1fc  push rdi
000078eb87dda1fd  push rsi
000078eb87dda1fe  push r8
000078eb87dda200  push r9
000078eb87dda202  push r10
000078eb87dda204  push r11
000078eb87dda206  sub rsp, 0xF0
000078eb87dda20d  vmovaps [rsp], xmm0
000078eb87dda212  vmovaps [rsp+0x10], xmm2
000078eb87dda218  vmovaps [rsp+0x20], xmm3
000078eb87dda21e  vmovaps [rsp+0x30], xmm4
000078eb87dda224  vmovaps [rsp+0x40], xmm5
000078eb87dda22a  vmovaps [rsp+0x50], xmm6
000078eb87dda230  vmovaps [rsp+0x60], xmm7
000078eb87dda236  vmovaps [rsp+0x70], xmm8
000078eb87dda23c  vmovaps [rsp+0x80], xmm9
000078eb87dda245  vmovaps [rsp+0x90], xmm10
000078eb87dda24e  vmovaps [rsp+0xA0], xmm11
000078eb87dda257  vmovaps [rsp+0xB0], xmm12
000078eb87dda260  vmovaps [rsp+0xC0], xmm13
000078eb87dda269  vmovaps [rsp+0xD0], xmm14
000078eb87dda272  vmovaps [rsp+0xE0], xmm15
000078eb87dda27b  sub rsp, 0x30
000078eb87dda27f  movaps [rsp], xmm1
000078eb87dda283  movaps [rsp+0x10], xmm13
000078eb87dda289  movaps [rsp+0x20], xmm9
000078eb87dda28f  lea rdi, [rsp]
000078eb87dda293  mov esi, 0x00
000078eb87dda298  mov rax, 0x61D341A71530
000078eb87dda2a2  call rax
000078eb87dda2a4  movaps xmm1, [rsp]
000078eb87dda2a8  add rsp, 0x30
000078eb87dda2ac  vmovaps xmm0, [rsp]
000078eb87dda2b1  vmovaps xmm2, [rsp+0x10]
000078eb87dda2b7  vmovaps xmm3, [rsp+0x20]
000078eb87dda2bd  vmovaps xmm4, [rsp+0x30]
000078eb87dda2c3  vmovaps xmm5, [rsp+0x40]
000078eb87dda2c9  vmovaps xmm6, [rsp+0x50]
000078eb87dda2cf  vmovaps xmm7, [rsp+0x60]
000078eb87dda2d5  vmovaps xmm8, [rsp+0x70]
000078eb87dda2db  vmovaps xmm9, [rsp+0x80]
000078eb87dda2e4  vmovaps xmm10, [rsp+0x90]
000078eb87dda2ed  vmovaps xmm11, [rsp+0xA0]
000078eb87dda2f6  vmovaps xmm12, [rsp+0xB0]
000078eb87dda2ff  vmovaps xmm13, [rsp+0xC0]
000078eb87dda308  vmovaps xmm14, [rsp+0xD0]
000078eb87dda311  vmovaps xmm15, [rsp+0xE0]
000078eb87dda31a  add rsp, 0xF0
000078eb87dda321  pop r11
000078eb87dda323  pop r10
000078eb87dda325  pop r9
000078eb87dda327  pop r8
000078eb87dda329  pop rsi
000078eb87dda32a  pop rdi
000078eb87dda32b  pop rdx
000078eb87dda32c  pop rcx
000078eb87dda32d  pop rax
000078eb87dda32e  add rsp, 0x08
000078eb87dda332  jmp 0x000078EB87DD641A
000078eb87dda337  sub rsp, 0x08
000078eb87dda33b  push rax
000078eb87dda33c  push rcx
000078eb87dda33d  push rdx
000078eb87dda33e  push rdi
000078eb87dda33f  push rsi
000078eb87dda340  push r8
000078eb87dda342  push r9
000078eb87dda344  push r10
000078eb87dda346  push r11
000078eb87dda348  sub rsp, 0xF0
000078eb87dda34f  vmovaps [rsp], xmm0
000078eb87dda354  vmovaps [rsp+0x10], xmm1
000078eb87dda35a  vmovaps [rsp+0x20], xmm2
000078eb87dda360  vmovaps [rsp+0x30], xmm3
000078eb87dda366  vmovaps [rsp+0x40], xmm4
000078eb87dda36c  vmovaps [rsp+0x50], xmm5
000078eb87dda372  vmovaps [rsp+0x60], xmm6
000078eb87dda378  vmovaps [rsp+0x70], xmm7
000078eb87dda37e  vmovaps [rsp+0x80], xmm8
000078eb87dda387  vmovaps [rsp+0x90], xmm9
000078eb87dda390  vmovaps [rsp+0xA0], xmm10
000078eb87dda399  vmovaps [rsp+0xB0], xmm11
000078eb87dda3a2  vmovaps [rsp+0xC0], xmm13
000078eb87dda3ab  vmovaps [rsp+0xD0], xmm14
000078eb87dda3b4  vmovaps [rsp+0xE0], xmm15
000078eb87dda3bd  sub rsp, 0x30
000078eb87dda3c1  movaps [rsp], xmm12
000078eb87dda3c6  movaps [rsp+0x10], xmm7
000078eb87dda3cb  movaps [rsp+0x20], xmm13
000078eb87dda3d1  lea rdi, [rsp]
000078eb87dda3d5  mov esi, 0x00
000078eb87dda3da  mov rax, 0x61D341A71530
000078eb87dda3e4  call rax
000078eb87dda3e6  movaps xmm12, [rsp]
000078eb87dda3eb  add rsp, 0x30
000078eb87dda3ef  vmovaps xmm0, [rsp]
000078eb87dda3f4  vmovaps xmm1, [rsp+0x10]
000078eb87dda3fa  vmovaps xmm2, [rsp+0x20]
000078eb87dda400  vmovaps xmm3, [rsp+0x30]
000078eb87dda406  vmovaps xmm4, [rsp+0x40]
000078eb87dda40c  vmovaps xmm5, [rsp+0x50]
000078eb87dda412  vmovaps xmm6, [rsp+0x60]
000078eb87dda418  vmovaps xmm7, [rsp+0x70]
000078eb87dda41e  vmovaps xmm8, [rsp+0x80]
000078eb87dda427  vmovaps xmm9, [rsp+0x90]
000078eb87dda430  vmovaps xmm10, [rsp+0xA0]
000078eb87dda439  vmovaps xmm11, [rsp+0xB0]
000078eb87dda442  vmovaps xmm13, [rsp+0xC0]
000078eb87dda44b  vmovaps xmm14, [rsp+0xD0]
000078eb87dda454  vmovaps xmm15, [rsp+0xE0]
000078eb87dda45d  add rsp, 0xF0
000078eb87dda464  pop r11
000078eb87dda466  pop r10
000078eb87dda468  pop r9
000078eb87dda46a  pop r8
000078eb87dda46c  pop rsi
000078eb87dda46d  pop rdi
000078eb87dda46e  pop rdx
000078eb87dda46f  pop rcx
000078eb87dda470  pop rax
000078eb87dda471  add rsp, 0x08
000078eb87dda475  jmp 0x000078EB87DD6441
000078eb87dda47a  sub rsp, 0x08
000078eb87dda47e  push rax
000078eb87dda47f  push rcx
000078eb87dda480  push rdx
000078eb87dda481  push rdi
000078eb87dda482  push rsi
000078eb87dda483  push r8
000078eb87dda485  push r9
000078eb87dda487  push r10
000078eb87dda489  push r11
000078eb87dda48b  sub rsp, 0xF0
000078eb87dda492  vmovaps [rsp], xmm0
000078eb87dda497  vmovaps [rsp+0x10], xmm1
000078eb87dda49d  vmovaps [rsp+0x20], xmm2
000078eb87dda4a3  vmovaps [rsp+0x30], xmm3
000078eb87dda4a9  vmovaps [rsp+0x40], xmm4
000078eb87dda4af  vmovaps [rsp+0x50], xmm5
000078eb87dda4b5  vmovaps [rsp+0x60], xmm6
000078eb87dda4bb  vmovaps [rsp+0x70], xmm7
000078eb87dda4c1  vmovaps [rsp+0x80], xmm8
000078eb87dda4ca  vmovaps [rsp+0x90], xmm9
000078eb87dda4d3  vmovaps [rsp+0xA0], xmm10
000078eb87dda4dc  vmovaps [rsp+0xB0], xmm11
000078eb87dda4e5  vmovaps [rsp+0xC0], xmm12
000078eb87dda4ee  vmovaps [rsp+0xD0], xmm14
000078eb87dda4f7  vmovaps [rsp+0xE0], xmm15
000078eb87dda500  sub rsp, 0x30
000078eb87dda504  movaps [rsp], xmm13
000078eb87dda509  movaps [rsp+0x10], xmm15
000078eb87dda50f  movaps [rsp+0x20], xmm8
000078eb87dda515  lea rdi, [rsp]
000078eb87dda519  mov esi, 0x00
000078eb87dda51e  mov rax, 0x61D341A71530
000078eb87dda528  call rax
000078eb87dda52a  movaps xmm13, [rsp]
000078eb87dda52f  add rsp, 0x30
000078eb87dda533  vmovaps xmm0, [rsp]
000078eb87dda538  vmovaps xmm1, [rsp+0x10]
000078eb87dda53e  vmovaps xmm2, [rsp+0x20]
000078eb87dda544  vmovaps xmm3, [rsp+0x30]
000078eb87dda54a  vmovaps xmm4, [rsp+0x40]
000078eb87dda550  vmovaps xmm5, [rsp+0x50]
000078eb87dda556  vmovaps xmm6, [rsp+0x60]
000078eb87dda55c  vmovaps xmm7, [rsp+0x70]
000078eb87dda562  vmovaps xmm8, [rsp+0x80]
000078eb87dda56b  vmovaps xmm9, [rsp+0x90]
000078eb87dda574  vmovaps xmm10, [rsp+0xA0]
000078eb87dda57d  vmovaps xmm11, [rsp+0xB0]
000078eb87dda586  vmovaps xmm12, [rsp+0xC0]
000078eb87dda58f  vmovaps xmm14, [rsp+0xD0]
000078eb87dda598  vmovaps xmm15, [rsp+0xE0]
000078eb87dda5a1  add rsp, 0xF0
000078eb87dda5a8  pop r11
000078eb87dda5aa  pop r10
000078eb87dda5ac  pop r9
000078eb87dda5ae  pop r8
000078eb87dda5b0  pop rsi
000078eb87dda5b1  pop rdi
000078eb87dda5b2  pop rdx
000078eb87dda5b3  pop rcx
000078eb87dda5b4  pop rax
000078eb87dda5b5  add rsp, 0x08
000078eb87dda5b9  jmp 0x000078EB87DD645C
000078eb87dda5be  sub rsp, 0x08
000078eb87dda5c2  push rax
000078eb87dda5c3  push rcx
000078eb87dda5c4  push rdx
000078eb87dda5c5  push rdi
000078eb87dda5c6  push rsi
000078eb87dda5c7  push r8
000078eb87dda5c9  push r9
000078eb87dda5cb  push r10
000078eb87dda5cd  push r11
000078eb87dda5cf  sub rsp, 0xF0
000078eb87dda5d6  vmovaps [rsp], xmm0
000078eb87dda5db  vmovaps [rsp+0x10], xmm1
000078eb87dda5e1  vmovaps [rsp+0x20], xmm2
000078eb87dda5e7  vmovaps [rsp+0x30], xmm3
000078eb87dda5ed  vmovaps [rsp+0x40], xmm4
000078eb87dda5f3  vmovaps [rsp+0x50], xmm5
000078eb87dda5f9  vmovaps [rsp+0x60], xmm6
000078eb87dda5ff  vmovaps [rsp+0x70], xmm7
000078eb87dda605  vmovaps [rsp+0x80], xmm9
000078eb87dda60e  vmovaps [rsp+0x90], xmm10
000078eb87dda617  vmovaps [rsp+0xA0], xmm11
000078eb87dda620  vmovaps [rsp+0xB0], xmm12
000078eb87dda629  vmovaps [rsp+0xC0], xmm13
000078eb87dda632  vmovaps [rsp+0xD0], xmm14
000078eb87dda63b  vmovaps [rsp+0xE0], xmm15
000078eb87dda644  sub rsp, 0x30
000078eb87dda648  movaps [rsp], xmm8
000078eb87dda64d  movaps [rsp+0x10], xmm15
000078eb87dda653  movaps [rsp+0x20], xmm9
000078eb87dda659  lea rdi, [rsp]
000078eb87dda65d  mov esi, 0x00
000078eb87dda662  mov rax, 0x61D341A71530
000078eb87dda66c  call rax
000078eb87dda66e  movaps xmm8, [rsp]
000078eb87dda673  add rsp, 0x30
000078eb87dda677  vmovaps xmm0, [rsp]
000078eb87dda67c  vmovaps xmm1, [rsp+0x10]
000078eb87dda682  vmovaps xmm2, [rsp+0x20]
000078eb87dda688  vmovaps xmm3, [rsp+0x30]
000078eb87dda68e  vmovaps xmm4, [rsp+0x40]
000078eb87dda694  vmovaps xmm5, [rsp+0x50]
000078eb87dda69a  vmovaps xmm6, [rsp+0x60]
000078eb87dda6a0  vmovaps xmm7, [rsp+0x70]
000078eb87dda6a6  vmovaps xmm9, [rsp+0x80]
000078eb87dda6af  vmovaps xmm10, [rsp+0x90]
000078eb87dda6b8  vmovaps xmm11, [rsp+0xA0]
000078eb87dda6c1  vmovaps xmm12, [rsp+0xB0]
000078eb87dda6ca  vmovaps xmm13, [rsp+0xC0]
000078eb87dda6d3  vmovaps xmm14, [rsp+0xD0]
000078eb87dda6dc  vmovaps xmm15, [rsp+0xE0]
000078eb87dda6e5  add rsp, 0xF0
000078eb87dda6ec  pop r11
000078eb87dda6ee  pop r10
000078eb87dda6f0  pop r9
000078eb87dda6f2  pop r8
000078eb87dda6f4  pop rsi
000078eb87dda6f5  pop rdi
000078eb87dda6f6  pop rdx
000078eb87dda6f7  pop rcx
000078eb87dda6f8  pop rax
000078eb87dda6f9  add rsp, 0x08
000078eb87dda6fd  jmp 0x000078EB87DD648A
000078eb87dda702  sub rsp, 0x08
000078eb87dda706  push rax
000078eb87dda707  push rcx
000078eb87dda708  push rdx
000078eb87dda709  push rdi
000078eb87dda70a  push rsi
000078eb87dda70b  push r8
000078eb87dda70d  push r9
000078eb87dda70f  push r10
000078eb87dda711  push r11
000078eb87dda713  sub rsp, 0xF0
000078eb87dda71a  vmovaps [rsp], xmm0
000078eb87dda71f  vmovaps [rsp+0x10], xmm1
000078eb87dda725  vmovaps [rsp+0x20], xmm2
000078eb87dda72b  vmovaps [rsp+0x30], xmm3
000078eb87dda731  vmovaps [rsp+0x40], xmm4
000078eb87dda737  vmovaps [rsp+0x50], xmm5
000078eb87dda73d  vmovaps [rsp+0x60], xmm6
000078eb87dda743  vmovaps [rsp+0x70], xmm7
000078eb87dda749  vmovaps [rsp+0x80], xmm8
000078eb87dda752  vmovaps [rsp+0x90], xmm9
000078eb87dda75b  vmovaps [rsp+0xA0], xmm10
000078eb87dda764  vmovaps [rsp+0xB0], xmm11
000078eb87dda76d  vmovaps [rsp+0xC0], xmm12
000078eb87dda776  vmovaps [rsp+0xD0], xmm13
000078eb87dda77f  vmovaps [rsp+0xE0], xmm14
000078eb87dda788  sub rsp, 0x30
000078eb87dda78c  movaps [rsp], xmm15
000078eb87dda791  movaps [rsp+0x10], xmm11
000078eb87dda797  movaps [rsp+0x20], xmm6
000078eb87dda79c  lea rdi, [rsp]
000078eb87dda7a0  mov esi, 0x00
000078eb87dda7a5  mov rax, 0x61D341A71530
000078eb87dda7af  call rax
000078eb87dda7b1  movaps xmm15, [rsp]
000078eb87dda7b6  add rsp, 0x30
000078eb87dda7ba  vmovaps xmm0, [rsp]
000078eb87dda7bf  vmovaps xmm1, [rsp+0x10]
000078eb87dda7c5  vmovaps xmm2, [rsp+0x20]
000078eb87dda7cb  vmovaps xmm3, [rsp+0x30]
000078eb87dda7d1  vmovaps xmm4, [rsp+0x40]
000078eb87dda7d7  vmovaps xmm5, [rsp+0x50]
000078eb87dda7dd  vmovaps xmm6, [rsp+0x60]
000078eb87dda7e3  vmovaps xmm7, [rsp+0x70]
000078eb87dda7e9  vmovaps xmm8, [rsp+0x80]
000078eb87dda7f2  vmovaps xmm9, [rsp+0x90]
000078eb87dda7fb  vmovaps xmm10, [rsp+0xA0]
000078eb87dda804  vmovaps xmm11, [rsp+0xB0]
000078eb87dda80d  vmovaps xmm12, [rsp+0xC0]
000078eb87dda816  vmovaps xmm13, [rsp+0xD0]
000078eb87dda81f  vmovaps xmm14, [rsp+0xE0]
000078eb87dda828  add rsp, 0xF0
000078eb87dda82f  pop r11
000078eb87dda831  pop r10
000078eb87dda833  pop r9
000078eb87dda835  pop r8
000078eb87dda837  pop rsi
000078eb87dda838  pop rdi
000078eb87dda839  pop rdx
000078eb87dda83a  pop rcx
000078eb87dda83b  pop rax
000078eb87dda83c  add rsp, 0x08
000078eb87dda840  jmp 0x000078EB87DD64A5
000078eb87dda845  sub rsp, 0x08
000078eb87dda849  push rax
000078eb87dda84a  push rcx
000078eb87dda84b  push rdx
000078eb87dda84c  push rdi
000078eb87dda84d  push rsi
000078eb87dda84e  push r8
000078eb87dda850  push r9
000078eb87dda852  push r10
000078eb87dda854  push r11
000078eb87dda856  sub rsp, 0xF0
000078eb87dda85d  vmovaps [rsp], xmm0
000078eb87dda862  vmovaps [rsp+0x10], xmm1
000078eb87dda868  vmovaps [rsp+0x20], xmm2
000078eb87dda86e  vmovaps [rsp+0x30], xmm3
000078eb87dda874  vmovaps [rsp+0x40], xmm4
000078eb87dda87a  vmovaps [rsp+0x50], xmm5
000078eb87dda880  vmovaps [rsp+0x60], xmm6
000078eb87dda886  vmovaps [rsp+0x70], xmm8
000078eb87dda88c  vmovaps [rsp+0x80], xmm9
000078eb87dda895  vmovaps [rsp+0x90], xmm10
000078eb87dda89e  vmovaps [rsp+0xA0], xmm11
000078eb87dda8a7  vmovaps [rsp+0xB0], xmm12
000078eb87dda8b0  vmovaps [rsp+0xC0], xmm13
000078eb87dda8b9  vmovaps [rsp+0xD0], xmm14
000078eb87dda8c2  vmovaps [rsp+0xE0], xmm15
000078eb87dda8cb  sub rsp, 0x30
000078eb87dda8cf  movaps [rsp], xmm7
000078eb87dda8d3  movaps [rsp+0x10], xmm11
000078eb87dda8d9  movaps [rsp+0x20], xmm9
000078eb87dda8df  lea rdi, [rsp]
000078eb87dda8e3  mov esi, 0x00
000078eb87dda8e8  mov rax, 0x61D341A71530
000078eb87dda8f2  call rax
000078eb87dda8f4  movaps xmm7, [rsp]
000078eb87dda8f8  add rsp, 0x30
000078eb87dda8fc  vmovaps xmm0, [rsp]
000078eb87dda901  vmovaps xmm1, [rsp+0x10]
000078eb87dda907  vmovaps xmm2, [rsp+0x20]
000078eb87dda90d  vmovaps xmm3, [rsp+0x30]
000078eb87dda913  vmovaps xmm4, [rsp+0x40]
000078eb87dda919  vmovaps xmm5, [rsp+0x50]
000078eb87dda91f  vmovaps xmm6, [rsp+0x60]
000078eb87dda925  vmovaps xmm8, [rsp+0x70]
000078eb87dda92b  vmovaps xmm9, [rsp+0x80]
000078eb87dda934  vmovaps xmm10, [rsp+0x90]
000078eb87dda93d  vmovaps xmm11, [rsp+0xA0]
000078eb87dda946  vmovaps xmm12, [rsp+0xB0]
000078eb87dda94f  vmovaps xmm13, [rsp+0xC0]
000078eb87dda958  vmovaps xmm14, [rsp+0xD0]
000078eb87dda961  vmovaps xmm15, [rsp+0xE0]
000078eb87dda96a  add rsp, 0xF0
000078eb87dda971  pop r11
000078eb87dda973  pop r10
000078eb87dda975  pop r9
000078eb87dda977  pop r8
000078eb87dda979  pop rsi
000078eb87dda97a  pop rdi
000078eb87dda97b  pop rdx
000078eb87dda97c  pop rcx
000078eb87dda97d  pop rax
000078eb87dda97e  add rsp, 0x08
000078eb87dda982  jmp 0x000078EB87DD64D2
000078eb87dda987  sub rsp, 0x08
000078eb87dda98b  push rax
000078eb87dda98c  push rcx
000078eb87dda98d  push rdx
000078eb87dda98e  push rdi
000078eb87dda98f  push rsi
000078eb87dda990  push r8
000078eb87dda992  push r9
000078eb87dda994  push r10
000078eb87dda996  push r11
000078eb87dda998  sub rsp, 0xF0
000078eb87dda99f  vmovaps [rsp], xmm0
000078eb87dda9a4  vmovaps [rsp+0x10], xmm1
000078eb87dda9aa  vmovaps [rsp+0x20], xmm2
000078eb87dda9b0  vmovaps [rsp+0x30], xmm3
000078eb87dda9b6  vmovaps [rsp+0x40], xmm4
000078eb87dda9bc  vmovaps [rsp+0x50], xmm5
000078eb87dda9c2  vmovaps [rsp+0x60], xmm6
000078eb87dda9c8  vmovaps [rsp+0x70], xmm7
000078eb87dda9ce  vmovaps [rsp+0x80], xmm8
000078eb87dda9d7  vmovaps [rsp+0x90], xmm9
000078eb87dda9e0  vmovaps [rsp+0xA0], xmm10
000078eb87dda9e9  vmovaps [rsp+0xB0], xmm12
000078eb87dda9f2  vmovaps [rsp+0xC0], xmm13
000078eb87dda9fb  vmovaps [rsp+0xD0], xmm14
000078eb87ddaa04  vmovaps [rsp+0xE0], xmm15
000078eb87ddaa0d  sub rsp, 0x30
000078eb87ddaa11  movaps [rsp], xmm11
000078eb87ddaa16  movaps [rsp+0x10], xmm10
000078eb87ddaa1c  movaps [rsp+0x20], xmm14
000078eb87ddaa22  lea rdi, [rsp]
000078eb87ddaa26  mov esi, 0x00
000078eb87ddaa2b  mov rax, 0x61D341A71530
000078eb87ddaa35  call rax
000078eb87ddaa37  movaps xmm11, [rsp]
000078eb87ddaa3c  add rsp, 0x30
000078eb87ddaa40  vmovaps xmm0, [rsp]
000078eb87ddaa45  vmovaps xmm1, [rsp+0x10]
000078eb87ddaa4b  vmovaps xmm2, [rsp+0x20]
000078eb87ddaa51  vmovaps xmm3, [rsp+0x30]
000078eb87ddaa57  vmovaps xmm4, [rsp+0x40]
000078eb87ddaa5d  vmovaps xmm5, [rsp+0x50]
000078eb87ddaa63  vmovaps xmm6, [rsp+0x60]
000078eb87ddaa69  vmovaps xmm7, [rsp+0x70]
000078eb87ddaa6f  vmovaps xmm8, [rsp+0x80]
000078eb87ddaa78  vmovaps xmm9, [rsp+0x90]
000078eb87ddaa81  vmovaps xmm10, [rsp+0xA0]
000078eb87ddaa8a  vmovaps xmm12, [rsp+0xB0]
000078eb87ddaa93  vmovaps xmm13, [rsp+0xC0]
000078eb87ddaa9c  vmovaps xmm14, [rsp+0xD0]
000078eb87ddaaa5  vmovaps xmm15, [rsp+0xE0]
000078eb87ddaaae  add rsp, 0xF0
000078eb87ddaab5  pop r11
000078eb87ddaab7  pop r10
000078eb87ddaab9  pop r9
000078eb87ddaabb  pop r8
000078eb87ddaabd  pop rsi
000078eb87ddaabe  pop rdi
000078eb87ddaabf  pop rdx
000078eb87ddaac0  pop rcx
000078eb87ddaac1  pop rax
000078eb87ddaac2  add rsp, 0x08
000078eb87ddaac6  jmp 0x000078EB87DD64ED
000078eb87ddaacb  call 0x000078EB87CE45A0
000078eb87ddaad0  jmp 0x000078EB87DD64F7
000078eb87ddaad5  sub rsp, 0x08
000078eb87ddaad9  push rax
000078eb87ddaada  push rcx
000078eb87ddaadb  push rdx
000078eb87ddaadc  push rdi
000078eb87ddaadd  push rsi
000078eb87ddaade  push r8
000078eb87ddaae0  push r9
000078eb87ddaae2  push r10
000078eb87ddaae4  push r11
000078eb87ddaae6  sub rsp, 0xF0
000078eb87ddaaed  vmovaps [rsp], xmm0
000078eb87ddaaf2  vmovaps [rsp+0x10], xmm1
000078eb87ddaaf8  vmovaps [rsp+0x20], xmm2
000078eb87ddaafe  vmovaps [rsp+0x30], xmm3
000078eb87ddab04  vmovaps [rsp+0x40], xmm4
000078eb87ddab0a  vmovaps [rsp+0x50], xmm5
000078eb87ddab10  vmovaps [rsp+0x60], xmm6
000078eb87ddab16  vmovaps [rsp+0x70], xmm7
000078eb87ddab1c  vmovaps [rsp+0x80], xmm8
000078eb87ddab25  vmovaps [rsp+0x90], xmm9
000078eb87ddab2e  vmovaps [rsp+0xA0], xmm11
000078eb87ddab37  vmovaps [rsp+0xB0], xmm12
000078eb87ddab40  vmovaps [rsp+0xC0], xmm13
000078eb87ddab49  vmovaps [rsp+0xD0], xmm14
000078eb87ddab52  vmovaps [rsp+0xE0], xmm15
000078eb87ddab5b  sub rsp, 0x30
000078eb87ddab5f  movaps [rsp], xmm10
000078eb87ddab64  movaps [rsp+0x10], xmm1
000078eb87ddab69  movaps [rsp+0x20], xmm12
000078eb87ddab6f  lea rdi, [rsp]
000078eb87ddab73  mov esi, 0x00
000078eb87ddab78  mov rax, 0x61D341A71530
000078eb87ddab82  call rax
000078eb87ddab84  movaps xmm10, [rsp]
000078eb87ddab89  add rsp, 0x30
000078eb87ddab8d  vmovaps xmm0, [rsp]
000078eb87ddab92  vmovaps xmm1, [rsp+0x10]
000078eb87ddab98  vmovaps xmm2, [rsp+0x20]
000078eb87ddab9e  vmovaps xmm3, [rsp+0x30]
000078eb87ddaba4  vmovaps xmm4, [rsp+0x40]
000078eb87ddabaa  vmovaps xmm5, [rsp+0x50]
000078eb87ddabb0  vmovaps xmm6, [rsp+0x60]
000078eb87ddabb6  vmovaps xmm7, [rsp+0x70]
000078eb87ddabbc  vmovaps xmm8, [rsp+0x80]
000078eb87ddabc5  vmovaps xmm9, [rsp+0x90]
000078eb87ddabce  vmovaps xmm11, [rsp+0xA0]
000078eb87ddabd7  vmovaps xmm12, [rsp+0xB0]
000078eb87ddabe0  vmovaps xmm13, [rsp+0xC0]
000078eb87ddabe9  vmovaps xmm14, [rsp+0xD0]
000078eb87ddabf2  vmovaps xmm15, [rsp+0xE0]
000078eb87ddabfb  add rsp, 0xF0
000078eb87ddac02  pop r11
000078eb87ddac04  pop r10
000078eb87ddac06  pop r9
000078eb87ddac08  pop r8
000078eb87ddac0a  pop rsi
000078eb87ddac0b  pop rdi
000078eb87ddac0c  pop rdx
000078eb87ddac0d  pop rcx
000078eb87ddac0e  pop rax
000078eb87ddac0f  add rsp, 0x08
000078eb87ddac13  jmp 0x000078EB87DD651A
000078eb87ddac18  sub rsp, 0x08
000078eb87ddac1c  push rax
000078eb87ddac1d  push rcx
000078eb87ddac1e  push rdx
000078eb87ddac1f  push rdi
000078eb87ddac20  push rsi
000078eb87ddac21  push r8
000078eb87ddac23  push r9
000078eb87ddac25  push r10
000078eb87ddac27  push r11
000078eb87ddac29  sub rsp, 0xF0
000078eb87ddac30  vmovaps [rsp], xmm0
000078eb87ddac35  vmovaps [rsp+0x10], xmm1
000078eb87ddac3b  vmovaps [rsp+0x20], xmm2
000078eb87ddac41  vmovaps [rsp+0x30], xmm3
000078eb87ddac47  vmovaps [rsp+0x40], xmm4
000078eb87ddac4d  vmovaps [rsp+0x50], xmm5
000078eb87ddac53  vmovaps [rsp+0x60], xmm6
000078eb87ddac59  vmovaps [rsp+0x70], xmm7
000078eb87ddac5f  vmovaps [rsp+0x80], xmm8
000078eb87ddac68  vmovaps [rsp+0x90], xmm9
000078eb87ddac71  vmovaps [rsp+0xA0], xmm10
000078eb87ddac7a  vmovaps [rsp+0xB0], xmm11
000078eb87ddac83  vmovaps [rsp+0xC0], xmm13
000078eb87ddac8c  vmovaps [rsp+0xD0], xmm14
000078eb87ddac95  vmovaps [rsp+0xE0], xmm15
000078eb87ddac9e  sub rsp, 0x30
000078eb87ddaca2  movaps [rsp], xmm12
000078eb87ddaca7  movaps [rsp+0x10], xmm14
000078eb87ddacad  movaps [rsp+0x20], xmm1
000078eb87ddacb2  lea rdi, [rsp]
000078eb87ddacb6  mov esi, 0x00
000078eb87ddacbb  mov rax, 0x61D341A71530
000078eb87ddacc5  call rax
000078eb87ddacc7  movaps xmm12, [rsp]
000078eb87ddaccc  add rsp, 0x30
000078eb87ddacd0  vmovaps xmm0, [rsp]
000078eb87ddacd5  vmovaps xmm1, [rsp+0x10]
000078eb87ddacdb  vmovaps xmm2, [rsp+0x20]
000078eb87ddace1  vmovaps xmm3, [rsp+0x30]
000078eb87ddace7  vmovaps xmm4, [rsp+0x40]
000078eb87ddaced  vmovaps xmm5, [rsp+0x50]
000078eb87ddacf3  vmovaps xmm6, [rsp+0x60]
000078eb87ddacf9  vmovaps xmm7, [rsp+0x70]
000078eb87ddacff  vmovaps xmm8, [rsp+0x80]
000078eb87ddad08  vmovaps xmm9, [rsp+0x90]
000078eb87ddad11  vmovaps xmm10, [rsp+0xA0]
000078eb87ddad1a  vmovaps xmm11, [rsp+0xB0]
000078eb87ddad23  vmovaps xmm13, [rsp+0xC0]
000078eb87ddad2c  vmovaps xmm14, [rsp+0xD0]
000078eb87ddad35  vmovaps xmm15, [rsp+0xE0]
000078eb87ddad3e  add rsp, 0xF0
000078eb87ddad45  pop r11
000078eb87ddad47  pop r10
000078eb87ddad49  pop r9
000078eb87ddad4b  pop r8
000078eb87ddad4d  pop rsi
000078eb87ddad4e  pop rdi
000078eb87ddad4f  pop rdx
000078eb87ddad50  pop rcx
000078eb87ddad51  pop rax
000078eb87ddad52  add rsp, 0x08
000078eb87ddad56  jmp 0x000078EB87DD6549
000078eb87ddad5b  sub rsp, 0x08
000078eb87ddad5f  push rax
000078eb87ddad60  push rcx
000078eb87ddad61  push rdx
000078eb87ddad62  push rdi
000078eb87ddad63  push rsi
000078eb87ddad64  push r8
000078eb87ddad66  push r9
000078eb87ddad68  push r10
000078eb87ddad6a  push r11
000078eb87ddad6c  sub rsp, 0xF0
000078eb87ddad73  vmovaps [rsp], xmm0
000078eb87ddad78  vmovaps [rsp+0x10], xmm1
000078eb87ddad7e  vmovaps [rsp+0x20], xmm2
000078eb87ddad84  vmovaps [rsp+0x30], xmm3
000078eb87ddad8a  vmovaps [rsp+0x40], xmm4
000078eb87ddad90  vmovaps [rsp+0x50], xmm5
000078eb87ddad96  vmovaps [rsp+0x60], xmm6
000078eb87ddad9c  vmovaps [rsp+0x70], xmm7
000078eb87ddada2  vmovaps [rsp+0x80], xmm8
000078eb87ddadab  vmovaps [rsp+0x90], xmm9
000078eb87ddadb4  vmovaps [rsp+0xA0], xmm10
000078eb87ddadbd  vmovaps [rsp+0xB0], xmm11
000078eb87ddadc6  vmovaps [rsp+0xC0], xmm12
000078eb87ddadcf  vmovaps [rsp+0xD0], xmm13
000078eb87ddadd8  vmovaps [rsp+0xE0], xmm15
000078eb87ddade1  sub rsp, 0x30
000078eb87ddade5  movaps [rsp], xmm14
000078eb87ddadea  movaps [rsp+0x10], xmm9
000078eb87ddadf0  movaps [rsp+0x20], xmm1
000078eb87ddadf5  lea rdi, [rsp]
000078eb87ddadf9  mov esi, 0x00
000078eb87ddadfe  mov rax, 0x61D341A71530
000078eb87ddae08  call rax
000078eb87ddae0a  movaps xmm14, [rsp]
000078eb87ddae0f  add rsp, 0x30
000078eb87ddae13  vmovaps xmm0, [rsp]
000078eb87ddae18  vmovaps xmm1, [rsp+0x10]
000078eb87ddae1e  vmovaps xmm2, [rsp+0x20]
000078eb87ddae24  vmovaps xmm3, [rsp+0x30]
000078eb87ddae2a  vmovaps xmm4, [rsp+0x40]
000078eb87ddae30  vmovaps xmm5, [rsp+0x50]
000078eb87ddae36  vmovaps xmm6, [rsp+0x60]
000078eb87ddae3c  vmovaps xmm7, [rsp+0x70]
000078eb87ddae42  vmovaps xmm8, [rsp+0x80]
000078eb87ddae4b  vmovaps xmm9, [rsp+0x90]
000078eb87ddae54  vmovaps xmm10, [rsp+0xA0]
000078eb87ddae5d  vmovaps xmm11, [rsp+0xB0]
000078eb87ddae66  vmovaps xmm12, [rsp+0xC0]
000078eb87ddae6f  vmovaps xmm13, [rsp+0xD0]
000078eb87ddae78  vmovaps xmm15, [rsp+0xE0]
000078eb87ddae81  add rsp, 0xF0
000078eb87ddae88  pop r11
000078eb87ddae8a  pop r10
000078eb87ddae8c  pop r9
000078eb87ddae8e  pop r8
000078eb87ddae90  pop rsi
000078eb87ddae91  pop rdi
000078eb87ddae92  pop rdx
000078eb87ddae93  pop rcx
000078eb87ddae94  pop rax
000078eb87ddae95  add rsp, 0x08
000078eb87ddae99  jmp 0x000078EB87DD6578
000078eb87ddae9e  sub rsp, 0x08
000078eb87ddaea2  push rax
000078eb87ddaea3  push rcx
000078eb87ddaea4  push rdx
000078eb87ddaea5  push rdi
000078eb87ddaea6  push rsi
000078eb87ddaea7  push r8
000078eb87ddaea9  push r9
000078eb87ddaeab  push r10
000078eb87ddaead  push r11
000078eb87ddaeaf  sub rsp, 0xF0
000078eb87ddaeb6  vmovaps [rsp], xmm0
000078eb87ddaebb  vmovaps [rsp+0x10], xmm2
000078eb87ddaec1  vmovaps [rsp+0x20], xmm3
000078eb87ddaec7  vmovaps [rsp+0x30], xmm4
000078eb87ddaecd  vmovaps [rsp+0x40], xmm5
000078eb87ddaed3  vmovaps [rsp+0x50], xmm6
000078eb87ddaed9  vmovaps [rsp+0x60], xmm7
000078eb87ddaedf  vmovaps [rsp+0x70], xmm8
000078eb87ddaee5  vmovaps [rsp+0x80], xmm9
000078eb87ddaeee  vmovaps [rsp+0x90], xmm10
000078eb87ddaef7  vmovaps [rsp+0xA0], xmm11
000078eb87ddaf00  vmovaps [rsp+0xB0], xmm12
000078eb87ddaf09  vmovaps [rsp+0xC0], xmm13
000078eb87ddaf12  vmovaps [rsp+0xD0], xmm14
000078eb87ddaf1b  vmovaps [rsp+0xE0], xmm15
000078eb87ddaf24  sub rsp, 0x30
000078eb87ddaf28  movaps [rsp], xmm1
000078eb87ddaf2c  movaps [rsp+0x10], xmm13
000078eb87ddaf32  movaps [rsp+0x20], xmm8
000078eb87ddaf38  lea rdi, [rsp]
000078eb87ddaf3c  mov esi, 0x00
000078eb87ddaf41  mov rax, 0x61D341A71530
000078eb87ddaf4b  call rax
000078eb87ddaf4d  movaps xmm1, [rsp]
000078eb87ddaf51  add rsp, 0x30
000078eb87ddaf55  vmovaps xmm0, [rsp]
000078eb87ddaf5a  vmovaps xmm2, [rsp+0x10]
000078eb87ddaf60  vmovaps xmm3, [rsp+0x20]
000078eb87ddaf66  vmovaps xmm4, [rsp+0x30]
000078eb87ddaf6c  vmovaps xmm5, [rsp+0x40]
000078eb87ddaf72  vmovaps xmm6, [rsp+0x50]
000078eb87ddaf78  vmovaps xmm7, [rsp+0x60]
000078eb87ddaf7e  vmovaps xmm8, [rsp+0x70]
000078eb87ddaf84  vmovaps xmm9, [rsp+0x80]
000078eb87ddaf8d  vmovaps xmm10, [rsp+0x90]
000078eb87ddaf96  vmovaps xmm11, [rsp+0xA0]
000078eb87ddaf9f  vmovaps xmm12, [rsp+0xB0]
000078eb87ddafa8  vmovaps xmm13, [rsp+0xC0]
000078eb87ddafb1  vmovaps xmm14, [rsp+0xD0]
000078eb87ddafba  vmovaps xmm15, [rsp+0xE0]
000078eb87ddafc3  add rsp, 0xF0
000078eb87ddafca  pop r11
000078eb87ddafcc  pop r10
000078eb87ddafce  pop r9
000078eb87ddafd0  pop r8
000078eb87ddafd2  pop rsi
000078eb87ddafd3  pop rdi
000078eb87ddafd4  pop rdx
000078eb87ddafd5  pop rcx
000078eb87ddafd6  pop rax
000078eb87ddafd7  add rsp, 0x08
000078eb87ddafdb  jmp 0x000078EB87DD659A
000078eb87ddafe0  call 0x000078EB87C0C260
000078eb87ddafe5  jmp 0x000078EB87DD65A8
000078eb87ddafea  call 0x000078EB87CDE950
000078eb87ddafef  jmp 0x000078EB87DD65B2
000078eb87ddaff4  sub rsp, 0x08
000078eb87ddaff8  push rax
000078eb87ddaff9  push rcx
000078eb87ddaffa  push rdx
000078eb87ddaffb  push rdi
000078eb87ddaffc  push rsi
000078eb87ddaffd  push r8
000078eb87ddafff  push r9
000078eb87ddb001  push r10
000078eb87ddb003  push r11
000078eb87ddb005  sub rsp, 0xF0
000078eb87ddb00c  vmovaps [rsp], xmm0
000078eb87ddb011  vmovaps [rsp+0x10], xmm1
000078eb87ddb017  vmovaps [rsp+0x20], xmm2
000078eb87ddb01d  vmovaps [rsp+0x30], xmm3
000078eb87ddb023  vmovaps [rsp+0x40], xmm4
000078eb87ddb029  vmovaps [rsp+0x50], xmm5
000078eb87ddb02f  vmovaps [rsp+0x60], xmm6
000078eb87ddb035  vmovaps [rsp+0x70], xmm7
000078eb87ddb03b  vmovaps [rsp+0x80], xmm9
000078eb87ddb044  vmovaps [rsp+0x90], xmm10
000078eb87ddb04d  vmovaps [rsp+0xA0], xmm11
000078eb87ddb056  vmovaps [rsp+0xB0], xmm12
000078eb87ddb05f  vmovaps [rsp+0xC0], xmm13
000078eb87ddb068  vmovaps [rsp+0xD0], xmm14
000078eb87ddb071  vmovaps [rsp+0xE0], xmm15
000078eb87ddb07a  sub rsp, 0x30
000078eb87ddb07e  movaps [rsp], xmm8
000078eb87ddb083  movaps [rsp+0x10], xmm15
000078eb87ddb089  movaps [rsp+0x20], xmm7
000078eb87ddb08e  lea rdi, [rsp]
000078eb87ddb092  mov esi, 0x00
000078eb87ddb097  mov rax, 0x61D341A71530
000078eb87ddb0a1  call rax
000078eb87ddb0a3  movaps xmm8, [rsp]
000078eb87ddb0a8  add rsp, 0x30
000078eb87ddb0ac  vmovaps xmm0, [rsp]
000078eb87ddb0b1  vmovaps xmm1, [rsp+0x10]
000078eb87ddb0b7  vmovaps xmm2, [rsp+0x20]
000078eb87ddb0bd  vmovaps xmm3, [rsp+0x30]
000078eb87ddb0c3  vmovaps xmm4, [rsp+0x40]
000078eb87ddb0c9  vmovaps xmm5, [rsp+0x50]
000078eb87ddb0cf  vmovaps xmm6, [rsp+0x60]
000078eb87ddb0d5  vmovaps xmm7, [rsp+0x70]
000078eb87ddb0db  vmovaps xmm9, [rsp+0x80]
000078eb87ddb0e4  vmovaps xmm10, [rsp+0x90]
000078eb87ddb0ed  vmovaps xmm11, [rsp+0xA0]
000078eb87ddb0f6  vmovaps xmm12, [rsp+0xB0]
000078eb87ddb0ff  vmovaps xmm13, [rsp+0xC0]
000078eb87ddb108  vmovaps xmm14, [rsp+0xD0]
000078eb87ddb111  vmovaps xmm15, [rsp+0xE0]
000078eb87ddb11a  add rsp, 0xF0
000078eb87ddb121  pop r11
000078eb87ddb123  pop r10
000078eb87ddb125  pop r9
000078eb87ddb127  pop r8
000078eb87ddb129  pop rsi
000078eb87ddb12a  pop rdi
000078eb87ddb12b  pop rdx
000078eb87ddb12c  pop rcx
000078eb87ddb12d  pop rax
000078eb87ddb12e  add rsp, 0x08
000078eb87ddb132  jmp 0x000078EB87DD65D4
000078eb87ddb137  sub rsp, 0x08
000078eb87ddb13b  push rax
000078eb87ddb13c  push rcx
000078eb87ddb13d  push rdx
000078eb87ddb13e  push rdi
000078eb87ddb13f  push rsi
000078eb87ddb140  push r8
000078eb87ddb142  push r9
000078eb87ddb144  push r10
000078eb87ddb146  push r11
000078eb87ddb148  sub rsp, 0xF0
000078eb87ddb14f  vmovaps [rsp], xmm0
000078eb87ddb154  vmovaps [rsp+0x10], xmm1
000078eb87ddb15a  vmovaps [rsp+0x20], xmm2
000078eb87ddb160  vmovaps [rsp+0x30], xmm3
000078eb87ddb166  vmovaps [rsp+0x40], xmm4
000078eb87ddb16c  vmovaps [rsp+0x50], xmm5
000078eb87ddb172  vmovaps [rsp+0x60], xmm6
000078eb87ddb178  vmovaps [rsp+0x70], xmm8
000078eb87ddb17e  vmovaps [rsp+0x80], xmm9
000078eb87ddb187  vmovaps [rsp+0x90], xmm10
000078eb87ddb190  vmovaps [rsp+0xA0], xmm11
000078eb87ddb199  vmovaps [rsp+0xB0], xmm12
000078eb87ddb1a2  vmovaps [rsp+0xC0], xmm13
000078eb87ddb1ab  vmovaps [rsp+0xD0], xmm14
000078eb87ddb1b4  vmovaps [rsp+0xE0], xmm15
000078eb87ddb1bd  sub rsp, 0x30
000078eb87ddb1c1  movaps [rsp], xmm7
000078eb87ddb1c5  movaps [rsp+0x10], xmm9
000078eb87ddb1cb  movaps [rsp+0x20], xmm15
000078eb87ddb1d1  lea rdi, [rsp]
000078eb87ddb1d5  mov esi, 0x00
000078eb87ddb1da  mov rax, 0x61D341A71530
000078eb87ddb1e4  call rax
000078eb87ddb1e6  movaps xmm7, [rsp]
000078eb87ddb1ea  add rsp, 0x30
000078eb87ddb1ee  vmovaps xmm0, [rsp]
000078eb87ddb1f3  vmovaps xmm1, [rsp+0x10]
000078eb87ddb1f9  vmovaps xmm2, [rsp+0x20]
000078eb87ddb1ff  vmovaps xmm3, [rsp+0x30]
000078eb87ddb205  vmovaps xmm4, [rsp+0x40]
000078eb87ddb20b  vmovaps xmm5, [rsp+0x50]
000078eb87ddb211  vmovaps xmm6, [rsp+0x60]
000078eb87ddb217  vmovaps xmm8, [rsp+0x70]
000078eb87ddb21d  vmovaps xmm9, [rsp+0x80]
000078eb87ddb226  vmovaps xmm10, [rsp+0x90]
000078eb87ddb22f  vmovaps xmm11, [rsp+0xA0]
000078eb87ddb238  vmovaps xmm12, [rsp+0xB0]
000078eb87ddb241  vmovaps xmm13, [rsp+0xC0]
000078eb87ddb24a  vmovaps xmm14, [rsp+0xD0]
000078eb87ddb253  vmovaps xmm15, [rsp+0xE0]
000078eb87ddb25c  add rsp, 0xF0
000078eb87ddb263  pop r11
000078eb87ddb265  pop r10
000078eb87ddb267  pop r9
000078eb87ddb269  pop r8
000078eb87ddb26b  pop rsi
000078eb87ddb26c  pop rdi
000078eb87ddb26d  pop rdx
000078eb87ddb26e  pop rcx
000078eb87ddb26f  pop rax
000078eb87ddb270  add rsp, 0x08
000078eb87ddb274  jmp 0x000078EB87DD6601
000078eb87ddb279  sub rsp, 0x08
000078eb87ddb27d  push rax
000078eb87ddb27e  push rcx
000078eb87ddb27f  push rdx
000078eb87ddb280  push rdi
000078eb87ddb281  push rsi
000078eb87ddb282  push r8
000078eb87ddb284  push r9
000078eb87ddb286  push r10
000078eb87ddb288  push r11
000078eb87ddb28a  sub rsp, 0xF0
000078eb87ddb291  vmovaps [rsp], xmm0
000078eb87ddb296  vmovaps [rsp+0x10], xmm1
000078eb87ddb29c  vmovaps [rsp+0x20], xmm2
000078eb87ddb2a2  vmovaps [rsp+0x30], xmm3
000078eb87ddb2a8  vmovaps [rsp+0x40], xmm4
000078eb87ddb2ae  vmovaps [rsp+0x50], xmm5
000078eb87ddb2b4  vmovaps [rsp+0x60], xmm6
000078eb87ddb2ba  vmovaps [rsp+0x70], xmm7
000078eb87ddb2c0  vmovaps [rsp+0x80], xmm8
000078eb87ddb2c9  vmovaps [rsp+0x90], xmm10
000078eb87ddb2d2  vmovaps [rsp+0xA0], xmm11
000078eb87ddb2db  vmovaps [rsp+0xB0], xmm12
000078eb87ddb2e4  vmovaps [rsp+0xC0], xmm13
000078eb87ddb2ed  vmovaps [rsp+0xD0], xmm14
000078eb87ddb2f6  vmovaps [rsp+0xE0], xmm15
000078eb87ddb2ff  sub rsp, 0x30
000078eb87ddb303  movaps [rsp], xmm9
000078eb87ddb308  movaps [rsp+0x10], xmm13
000078eb87ddb30e  movaps [rsp+0x20], xmm15
000078eb87ddb314  lea rdi, [rsp]
000078eb87ddb318  mov esi, 0x00
000078eb87ddb31d  mov rax, 0x61D341A71530
000078eb87ddb327  call rax
000078eb87ddb329  movaps xmm9, [rsp]
000078eb87ddb32e  add rsp, 0x30
000078eb87ddb332  vmovaps xmm0, [rsp]
000078eb87ddb337  vmovaps xmm1, [rsp+0x10]
000078eb87ddb33d  vmovaps xmm2, [rsp+0x20]
000078eb87ddb343  vmovaps xmm3, [rsp+0x30]
000078eb87ddb349  vmovaps xmm4, [rsp+0x40]
000078eb87ddb34f  vmovaps xmm5, [rsp+0x50]
000078eb87ddb355  vmovaps xmm6, [rsp+0x60]
000078eb87ddb35b  vmovaps xmm7, [rsp+0x70]
000078eb87ddb361  vmovaps xmm8, [rsp+0x80]
000078eb87ddb36a  vmovaps xmm10, [rsp+0x90]
000078eb87ddb373  vmovaps xmm11, [rsp+0xA0]
000078eb87ddb37c  vmovaps xmm12, [rsp+0xB0]
000078eb87ddb385  vmovaps xmm13, [rsp+0xC0]
000078eb87ddb38e  vmovaps xmm14, [rsp+0xD0]
000078eb87ddb397  vmovaps xmm15, [rsp+0xE0]
000078eb87ddb3a0  add rsp, 0xF0
000078eb87ddb3a7  pop r11
000078eb87ddb3a9  pop r10
000078eb87ddb3ab  pop r9
000078eb87ddb3ad  pop r8
000078eb87ddb3af  pop rsi
000078eb87ddb3b0  pop rdi
000078eb87ddb3b1  pop rdx
000078eb87ddb3b2  pop rcx
000078eb87ddb3b3  pop rax
000078eb87ddb3b4  add rsp, 0x08
000078eb87ddb3b8  jmp 0x000078EB87DD662F
000078eb87ddb3bd  sub rsp, 0x08
000078eb87ddb3c1  push rax
000078eb87ddb3c2  push rcx
000078eb87ddb3c3  push rdx
000078eb87ddb3c4  push rdi
000078eb87ddb3c5  push rsi
000078eb87ddb3c6  push r8
000078eb87ddb3c8  push r9
000078eb87ddb3ca  push r10
000078eb87ddb3cc  push r11
000078eb87ddb3ce  sub rsp, 0xF0
000078eb87ddb3d5  vmovaps [rsp], xmm0
000078eb87ddb3da  vmovaps [rsp+0x10], xmm1
000078eb87ddb3e0  vmovaps [rsp+0x20], xmm2
000078eb87ddb3e6  vmovaps [rsp+0x30], xmm3
000078eb87ddb3ec  vmovaps [rsp+0x40], xmm4
000078eb87ddb3f2  vmovaps [rsp+0x50], xmm5
000078eb87ddb3f8  vmovaps [rsp+0x60], xmm6
000078eb87ddb3fe  vmovaps [rsp+0x70], xmm7
000078eb87ddb404  vmovaps [rsp+0x80], xmm8
000078eb87ddb40d  vmovaps [rsp+0x90], xmm9
000078eb87ddb416  vmovaps [rsp+0xA0], xmm10
000078eb87ddb41f  vmovaps [rsp+0xB0], xmm11
000078eb87ddb428  vmovaps [rsp+0xC0], xmm12
000078eb87ddb431  vmovaps [rsp+0xD0], xmm13
000078eb87ddb43a  vmovaps [rsp+0xE0], xmm14
000078eb87ddb443  sub rsp, 0x30
000078eb87ddb447  movaps [rsp], xmm15
000078eb87ddb44c  movaps [rsp+0x10], xmm11
000078eb87ddb452  movaps [rsp+0x20], xmm12
000078eb87ddb458  lea rdi, [rsp]
000078eb87ddb45c  mov esi, 0x00
000078eb87ddb461  mov rax, 0x61D341A71530
000078eb87ddb46b  call rax
000078eb87ddb46d  movaps xmm15, [rsp]
000078eb87ddb472  add rsp, 0x30
000078eb87ddb476  vmovaps xmm0, [rsp]
000078eb87ddb47b  vmovaps xmm1, [rsp+0x10]
000078eb87ddb481  vmovaps xmm2, [rsp+0x20]
000078eb87ddb487  vmovaps xmm3, [rsp+0x30]
000078eb87ddb48d  vmovaps xmm4, [rsp+0x40]
000078eb87ddb493  vmovaps xmm5, [rsp+0x50]
000078eb87ddb499  vmovaps xmm6, [rsp+0x60]
000078eb87ddb49f  vmovaps xmm7, [rsp+0x70]
000078eb87ddb4a5  vmovaps xmm8, [rsp+0x80]
000078eb87ddb4ae  vmovaps xmm9, [rsp+0x90]
000078eb87ddb4b7  vmovaps xmm10, [rsp+0xA0]
000078eb87ddb4c0  vmovaps xmm11, [rsp+0xB0]
000078eb87ddb4c9  vmovaps xmm12, [rsp+0xC0]
000078eb87ddb4d2  vmovaps xmm13, [rsp+0xD0]
000078eb87ddb4db  vmovaps xmm14, [rsp+0xE0]
000078eb87ddb4e4  add rsp, 0xF0
000078eb87ddb4eb  pop r11
000078eb87ddb4ed  pop r10
000078eb87ddb4ef  pop r9
000078eb87ddb4f1  pop r8
000078eb87ddb4f3  pop rsi
000078eb87ddb4f4  pop rdi
000078eb87ddb4f5  pop rdx
000078eb87ddb4f6  pop rcx
000078eb87ddb4f7  pop rax
000078eb87ddb4f8  add rsp, 0x08
000078eb87ddb4fc  jmp 0x000078EB87DD664A
000078eb87ddb501  sub rsp, 0x08
000078eb87ddb505  push rax
000078eb87ddb506  push rcx
000078eb87ddb507  push rdx
000078eb87ddb508  push rdi
000078eb87ddb509  push rsi
000078eb87ddb50a  push r8
000078eb87ddb50c  push r9
000078eb87ddb50e  push r10
000078eb87ddb510  push r11
000078eb87ddb512  sub rsp, 0xF0
000078eb87ddb519  vmovaps [rsp], xmm0
000078eb87ddb51e  vmovaps [rsp+0x10], xmm1
000078eb87ddb524  vmovaps [rsp+0x20], xmm2
000078eb87ddb52a  vmovaps [rsp+0x30], xmm3
000078eb87ddb530  vmovaps [rsp+0x40], xmm4
000078eb87ddb536  vmovaps [rsp+0x50], xmm5
000078eb87ddb53c  vmovaps [rsp+0x60], xmm6
000078eb87ddb542  vmovaps [rsp+0x70], xmm7
000078eb87ddb548  vmovaps [rsp+0x80], xmm8
000078eb87ddb551  vmovaps [rsp+0x90], xmm9
000078eb87ddb55a  vmovaps [rsp+0xA0], xmm10
000078eb87ddb563  vmovaps [rsp+0xB0], xmm11
000078eb87ddb56c  vmovaps [rsp+0xC0], xmm12
000078eb87ddb575  vmovaps [rsp+0xD0], xmm14
000078eb87ddb57e  vmovaps [rsp+0xE0], xmm15
000078eb87ddb587  sub rsp, 0x30
000078eb87ddb58b  movaps [rsp], xmm13
000078eb87ddb590  movaps [rsp+0x10], xmm10
000078eb87ddb596  movaps [rsp+0x20], xmm14
000078eb87ddb59c  lea rdi, [rsp]
000078eb87ddb5a0  mov esi, 0x00
000078eb87ddb5a5  mov rax, 0x61D341A71530
000078eb87ddb5af  call rax
000078eb87ddb5b1  movaps xmm13, [rsp]
000078eb87ddb5b6  add rsp, 0x30
000078eb87ddb5ba  vmovaps xmm0, [rsp]
000078eb87ddb5bf  vmovaps xmm1, [rsp+0x10]
000078eb87ddb5c5  vmovaps xmm2, [rsp+0x20]
000078eb87ddb5cb  vmovaps xmm3, [rsp+0x30]
000078eb87ddb5d1  vmovaps xmm4, [rsp+0x40]
000078eb87ddb5d7  vmovaps xmm5, [rsp+0x50]
000078eb87ddb5dd  vmovaps xmm6, [rsp+0x60]
000078eb87ddb5e3  vmovaps xmm7, [rsp+0x70]
000078eb87ddb5e9  vmovaps xmm8, [rsp+0x80]
000078eb87ddb5f2  vmovaps xmm9, [rsp+0x90]
000078eb87ddb5fb  vmovaps xmm10, [rsp+0xA0]
000078eb87ddb604  vmovaps xmm11, [rsp+0xB0]
000078eb87ddb60d  vmovaps xmm12, [rsp+0xC0]
000078eb87ddb616  vmovaps xmm14, [rsp+0xD0]
000078eb87ddb61f  vmovaps xmm15, [rsp+0xE0]
000078eb87ddb628  add rsp, 0xF0
000078eb87ddb62f  pop r11
000078eb87ddb631  pop r10
000078eb87ddb633  pop r9
000078eb87ddb635  pop r8
000078eb87ddb637  pop rsi
000078eb87ddb638  pop rdi
000078eb87ddb639  pop rdx
000078eb87ddb63a  pop rcx
000078eb87ddb63b  pop rax
000078eb87ddb63c  add rsp, 0x08
000078eb87ddb640  jmp 0x000078EB87DD666D
000078eb87ddb645  sub rsp, 0x08
000078eb87ddb649  push rax
000078eb87ddb64a  push rcx
000078eb87ddb64b  push rdx
000078eb87ddb64c  push rdi
000078eb87ddb64d  push rsi
000078eb87ddb64e  push r8
000078eb87ddb650  push r9
000078eb87ddb652  push r10
000078eb87ddb654  push r11
000078eb87ddb656  sub rsp, 0xF0
000078eb87ddb65d  vmovaps [rsp], xmm0
000078eb87ddb662  vmovaps [rsp+0x10], xmm1
000078eb87ddb668  vmovaps [rsp+0x20], xmm2
000078eb87ddb66e  vmovaps [rsp+0x30], xmm3
000078eb87ddb674  vmovaps [rsp+0x40], xmm4
000078eb87ddb67a  vmovaps [rsp+0x50], xmm5
000078eb87ddb680  vmovaps [rsp+0x60], xmm6
000078eb87ddb686  vmovaps [rsp+0x70], xmm7
000078eb87ddb68c  vmovaps [rsp+0x80], xmm8
000078eb87ddb695  vmovaps [rsp+0x90], xmm9
000078eb87ddb69e  vmovaps [rsp+0xA0], xmm10
000078eb87ddb6a7  vmovaps [rsp+0xB0], xmm11
000078eb87ddb6b0  vmovaps [rsp+0xC0], xmm12
000078eb87ddb6b9  vmovaps [rsp+0xD0], xmm13
000078eb87ddb6c2  vmovaps [rsp+0xE0], xmm15
000078eb87ddb6cb  sub rsp, 0x30
000078eb87ddb6cf  movaps [rsp], xmm14
000078eb87ddb6d4  movaps [rsp+0x10], xmm1
000078eb87ddb6d9  movaps [rsp+0x20], xmm7
000078eb87ddb6de  lea rdi, [rsp]
000078eb87ddb6e2  mov esi, 0x00
000078eb87ddb6e7  mov rax, 0x61D341A71530
000078eb87ddb6f1  call rax
000078eb87ddb6f3  movaps xmm14, [rsp]
000078eb87ddb6f8  add rsp, 0x30
000078eb87ddb6fc  vmovaps xmm0, [rsp]
000078eb87ddb701  vmovaps xmm1, [rsp+0x10]
000078eb87ddb707  vmovaps xmm2, [rsp+0x20]
000078eb87ddb70d  vmovaps xmm3, [rsp+0x30]
000078eb87ddb713  vmovaps xmm4, [rsp+0x40]
000078eb87ddb719  vmovaps xmm5, [rsp+0x50]
000078eb87ddb71f  vmovaps xmm6, [rsp+0x60]
000078eb87ddb725  vmovaps xmm7, [rsp+0x70]
000078eb87ddb72b  vmovaps xmm8, [rsp+0x80]
000078eb87ddb734  vmovaps xmm9, [rsp+0x90]
000078eb87ddb73d  vmovaps xmm10, [rsp+0xA0]
000078eb87ddb746  vmovaps xmm11, [rsp+0xB0]
000078eb87ddb74f  vmovaps xmm12, [rsp+0xC0]
000078eb87ddb758  vmovaps xmm13, [rsp+0xD0]
000078eb87ddb761  vmovaps xmm15, [rsp+0xE0]
000078eb87ddb76a  add rsp, 0xF0
000078eb87ddb771  pop r11
000078eb87ddb773  pop r10
000078eb87ddb775  pop r9
000078eb87ddb777  pop r8
000078eb87ddb779  pop rsi
000078eb87ddb77a  pop rdi
000078eb87ddb77b  pop rdx
000078eb87ddb77c  pop rcx
000078eb87ddb77d  pop rax
000078eb87ddb77e  add rsp, 0x08
000078eb87ddb782  jmp 0x000078EB87DD6690
000078eb87ddb787  sub rsp, 0x08
000078eb87ddb78b  push rax
000078eb87ddb78c  push rcx
000078eb87ddb78d  push rdx
000078eb87ddb78e  push rdi
000078eb87ddb78f  push rsi
000078eb87ddb790  push r8
000078eb87ddb792  push r9
000078eb87ddb794  push r10
000078eb87ddb796  push r11
000078eb87ddb798  sub rsp, 0xF0
000078eb87ddb79f  vmovaps [rsp], xmm0
000078eb87ddb7a4  vmovaps [rsp+0x10], xmm2
000078eb87ddb7aa  vmovaps [rsp+0x20], xmm3
000078eb87ddb7b0  vmovaps [rsp+0x30], xmm4
000078eb87ddb7b6  vmovaps [rsp+0x40], xmm5
000078eb87ddb7bc  vmovaps [rsp+0x50], xmm6
000078eb87ddb7c2  vmovaps [rsp+0x60], xmm7
000078eb87ddb7c8  vmovaps [rsp+0x70], xmm8
000078eb87ddb7ce  vmovaps [rsp+0x80], xmm9
000078eb87ddb7d7  vmovaps [rsp+0x90], xmm10
000078eb87ddb7e0  vmovaps [rsp+0xA0], xmm11
000078eb87ddb7e9  vmovaps [rsp+0xB0], xmm12
000078eb87ddb7f2  vmovaps [rsp+0xC0], xmm13
000078eb87ddb7fb  vmovaps [rsp+0xD0], xmm14
000078eb87ddb804  vmovaps [rsp+0xE0], xmm15
000078eb87ddb80d  sub rsp, 0x30
000078eb87ddb811  movaps [rsp], xmm1
000078eb87ddb815  movaps [rsp+0x10], xmm8
000078eb87ddb81b  movaps [rsp+0x20], xmm9
000078eb87ddb821  lea rdi, [rsp]
000078eb87ddb825  mov esi, 0x00
000078eb87ddb82a  mov rax, 0x61D341A71530
000078eb87ddb834  call rax
000078eb87ddb836  movaps xmm1, [rsp]
000078eb87ddb83a  add rsp, 0x30
000078eb87ddb83e  vmovaps xmm0, [rsp]
000078eb87ddb843  vmovaps xmm2, [rsp+0x10]
000078eb87ddb849  vmovaps xmm3, [rsp+0x20]
000078eb87ddb84f  vmovaps xmm4, [rsp+0x30]
000078eb87ddb855  vmovaps xmm5, [rsp+0x40]
000078eb87ddb85b  vmovaps xmm6, [rsp+0x50]
000078eb87ddb861  vmovaps xmm7, [rsp+0x60]
000078eb87ddb867  vmovaps xmm8, [rsp+0x70]
000078eb87ddb86d  vmovaps xmm9, [rsp+0x80]
000078eb87ddb876  vmovaps xmm10, [rsp+0x90]
000078eb87ddb87f  vmovaps xmm11, [rsp+0xA0]
000078eb87ddb888  vmovaps xmm12, [rsp+0xB0]
000078eb87ddb891  vmovaps xmm13, [rsp+0xC0]
000078eb87ddb89a  vmovaps xmm14, [rsp+0xD0]
000078eb87ddb8a3  vmovaps xmm15, [rsp+0xE0]
000078eb87ddb8ac  add rsp, 0xF0
000078eb87ddb8b3  pop r11
000078eb87ddb8b5  pop r10
000078eb87ddb8b7  pop r9
000078eb87ddb8b9  pop r8
000078eb87ddb8bb  pop rsi
000078eb87ddb8bc  pop rdi
000078eb87ddb8bd  pop rdx
000078eb87ddb8be  pop rcx
000078eb87ddb8bf  pop rax
000078eb87ddb8c0  add rsp, 0x08
000078eb87ddb8c4  jmp 0x000078EB87DD66B2
000078eb87ddb8c9  call 0x000078EB87CB3E40
000078eb87ddb8ce  jmp 0x000078EB87DD66C0
000078eb87ddb8d3  call 0x000078EB87C0C380
000078eb87ddb8d8  jmp 0x000078EB87DD66CA
000078eb87ddb8dd  call 0x000078EB87C0D600
000078eb87ddb8e2  jmp 0x000078EB87DD66D4
000078eb87ddb8e7  call 0x000078EB87BFF540
000078eb87ddb8ec  jmp 0x000078EB87DD66DE
000078eb87ddb8f1  int3
000078eb87ddb8f2  nop [rax+rax*1], ax
000078eb87ddb8fb  nop [rax+rax*1], eax
000078eb87ddb900  mov eax, [r15+0x48]
000078eb87ddb904  lea r14d, [eax+0x01]
000078eb87ddb909  mov [rsp+0x10], r14d
000078eb87ddb90e  mov r14d, r14d
000078eb87ddb911  mov [r15+0x48], r14
000078eb87ddb915  xor eax, eax
000078eb87ddb917  mov r14d, [rsp+0x10]
000078eb87ddb91c  cmp r14d, 0x1F4
000078eb87ddb923  cmc
000078eb87ddb924  lahf
000078eb87ddb925  seto al
000078eb87ddb928  mov [r15+0x108], eax
000078eb87ddb92f  mov eax, [r15+0x108]
000078eb87ddb936  sahf
000078eb87ddb937  jnz 0x000078EB87DDB969
000078eb87ddb939  cmp dword ptr [r15+0x318], 0x00
000078eb87ddb941  jz 0x000078EB87DE1AB0
000078eb87ddb947  nop [rax+rax*1], ax
000078eb87ddb950  nop [rax+rax*1], eax
000078eb87ddb958  mov eax, 0x410450
000078eb87ddb95d  mov [r15+0x100], rax
000078eb87ddb964  jmp 0x000078EB87BFE110
000078eb87ddb969  cmp dword ptr [r15+0x318], 0x00
000078eb87ddb971  jz 0x000078EB87DDB9A0
000078eb87ddb977  nop [rax+rax*1], ax
000078eb87ddb980  nop [rax+rax*1], eax
000078eb87ddb988  mov eax, 0x410274
000078eb87ddb98d  mov [r15+0x100], rax
000078eb87ddb994  jmp 0x000078EB87BFE110
000078eb87ddb999  int3
000078eb87ddb99a  int3
000078eb87ddb99b  nop [rax+rax*1], eax
000078eb87ddb9a0  mov rax, [r15+0x40]
000078eb87ddb9a4  movaps xmm1, [r15+0x1D0]
000078eb87ddb9ac  vmovaps [rsp+0x10], xmm1
000078eb87ddb9b2  vmovaps xmm15, [rsp+0x10]
000078eb87ddb9b8  por xmm1, xmm15
000078eb87ddb9bd  movaps xmm14, [r15+0x1A0]
000078eb87ddb9c5  vmovaps [rsp+0x10], xmm14
000078eb87ddb9cb  vmovaps xmm13, [rsp+0x10]
000078eb87ddb9d1  por xmm14, xmm13
000078eb87ddb9d6  lea r14, [rax+0x30]
000078eb87ddb9da  mov r12, [r13+r14*1]
000078eb87ddb9df  lea r14, [rax+0x38]
000078eb87ddb9e3  mov r11, [r13+r14*1]
000078eb87ddb9e8  movq xmm13, r12
000078eb87ddb9ed  movq xmm12, r11
000078eb87ddb9f2  movq xmm13, xmm13
000078eb87ddb9f7  vmovaps [rsp+0x10], xmm13
000078eb87ddb9fd  movq xmm13, xmm13
000078eb87ddba02  movaps [r15+0x130], xmm13
000078eb87ddba0a  movq xmm12, xmm12
000078eb87ddba0f  vmovaps [rsp+0x20], xmm12
000078eb87ddba15  movq xmm12, xmm12
000078eb87ddba1a  movaps [r15+0x280], xmm12
000078eb87ddba22  movaps xmm13, [r15+0x270]
000078eb87ddba2a  vmovaps [rsp+0x30], xmm13
000078eb87ddba30  vmovaps xmm12, [rsp+0x30]
000078eb87ddba36  por xmm13, xmm12
000078eb87ddba3b  lea r14, [rax+0x20]
000078eb87ddba3f  mov r12, [r13+r14*1]
000078eb87ddba44  lea r14, [rax+0x28]
000078eb87ddba48  mov r11, [r13+r14*1]
000078eb87ddba4d  movq xmm12, r12
000078eb87ddba52  movq xmm11, r11
000078eb87ddba57  movq xmm12, xmm12
000078eb87ddba5c  vmovaps [rsp+0x30], xmm12
000078eb87ddba62  movq xmm12, xmm12
000078eb87ddba67  movaps [r15+0x150], xmm12
000078eb87ddba6f  movq xmm11, xmm11
000078eb87ddba74  vmovaps [rsp+0x40], xmm11
000078eb87ddba7a  movq xmm11, xmm11
000078eb87ddba7f  movaps [r15+0x140], xmm11
000078eb87ddba87  lea r14, [rax+0x10]
000078eb87ddba8b  mov r12, [r13+r14*1]
000078eb87ddba90  lea r14, [rax+0x18]
000078eb87ddba94  mov r11, [r13+r14*1]
000078eb87ddba99  movq xmm12, r12
000078eb87ddba9e  movq xmm11, r11
000078eb87ddbaa3  movq xmm12, xmm12
000078eb87ddbaa8  vmovaps [rsp+0x50], xmm12
000078eb87ddbaae  movq xmm12, xmm12
000078eb87ddbab3  movaps [r15+0x170], xmm12
000078eb87ddbabb  movq xmm11, xmm11
000078eb87ddbac0  vmovaps [rsp+0x60], xmm11
000078eb87ddbac6  movq xmm11, xmm11
000078eb87ddbacb  movaps [r15+0x160], xmm11
000078eb87ddbad3  mov r14, [r13+rax*1]
000078eb87ddbad8  vmovq xmm12, r14
000078eb87ddbadd  vpbroadcastq xmm12, xmm12
000078eb87ddbae2  lea r14, [rax+0x08]
000078eb87ddbae6  mov rax, [r13+r14*1]
000078eb87ddbaeb  movq xmm11, rax
000078eb87ddbaf0  movaps [r15+0x230], xmm11
000078eb87ddbaf8  mov rax, [r15+0xF8]
000078eb87ddbaff  lea r14, [rax+0x50]
000078eb87ddbb03  movups xmm11, [r13+r14*1]
000078eb87ddbb09  lea r14, [rax+0x60]
000078eb87ddbb0d  movups xmm10, [r13+r14*1]
000078eb87ddbb13  lea r14, [rax+0x30]
000078eb87ddbb17  movups xmm9, [r13+r14*1]
000078eb87ddbb1d  mov r14, [r15+0x50]
000078eb87ddbb21  mov [r15+0x60], r14
000078eb87ddbb25  mov qword ptr [r15+0x58], 0x40
000078eb87ddbb2d  movaps xmm8, xmm12
000078eb87ddbb31  mulpd xmm8, xmm15
000078eb87ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000078eb87ddbb3c  ptest xmm7, xmm7
000078eb87ddbb41  jnz 0x000078EB87DDC96A
000078eb87ddbb47  movq xmm15, qword ptr [r15+0x230]
000078eb87ddbb50  vmovaps [rsp+0x70], xmm15
000078eb87ddbb56  vpermilpd xmm15, xmm15, 0x00
000078eb87ddbb5c  movaps xmm7, xmm9
000078eb87ddbb60  mulpd xmm7, xmm15
000078eb87ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000078eb87ddbb6a  ptest xmm6, xmm6
000078eb87ddbb6f  jnz 0x000078EB87DDCAAE
000078eb87ddbb75  vxorps xmm15, xmm15, xmm15
000078eb87ddbb7a  vpbroadcastq xmm15, xmm15
000078eb87ddbb7f  movaps xmm9, xmm12
000078eb87ddbb83  mulpd xmm9, xmm10
000078eb87ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000078eb87ddbb8e  ptest xmm6, xmm6
000078eb87ddbb93  jnz 0x000078EB87DDCBF0
000078eb87ddbb99  movaps xmm10, xmm12
000078eb87ddbb9d  mulpd xmm10, xmm11
000078eb87ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000078eb87ddbba8  ptest xmm6, xmm6
000078eb87ddbbad  jnz 0x000078EB87DDCD34
000078eb87ddbbb3  movaps xmm11, [r15+0x1F0]
000078eb87ddbbbb  movaps xmm6, xmm12
000078eb87ddbbbf  mulpd xmm6, xmm11
000078eb87ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000078eb87ddbbc9  ptest xmm5, xmm5
000078eb87ddbbce  jnz 0x000078EB87DDCE78
000078eb87ddbbd4  movaps xmm12, [r15+0x2A0]
000078eb87ddbbdc  vmovaps [rsp+0x80], xmm12
000078eb87ddbbe5  vmovaps xmm11, [rsp+0x80]
000078eb87ddbbee  por xmm12, xmm11
000078eb87ddbbf3  movaps xmm11, [r15+0x250]
000078eb87ddbbfb  vmovaps [rsp+0x80], xmm11
000078eb87ddbc04  vmovaps xmm5, [rsp+0x80]
000078eb87ddbc0d  por xmm11, xmm5
000078eb87ddbc12  vmovaps xmm4, [rsp+0x70]
000078eb87ddbc18  vpermilpd xmm4, xmm4, 0x00
000078eb87ddbc1e  movaps xmm3, xmm5
000078eb87ddbc21  mulpd xmm3, xmm4
000078eb87ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000078eb87ddbc2a  ptest xmm2, xmm2
000078eb87ddbc2f  jnz 0x000078EB87DDCFBA
000078eb87ddbc35  mov [rsp+0x80], rax
000078eb87ddbc3d  xor eax, eax
000078eb87ddbc3f  mov r12d, 0x40
000078eb87ddbc45  mov r11d, 0x200
000078eb87ddbc4b  cmp r12, r11
000078eb87ddbc4e  cmc
000078eb87ddbc4f  lahf
000078eb87ddbc50  seto al
000078eb87ddbc53  mov [r15+0x108], eax
000078eb87ddbc5a  movaps xmm5, xmm8
000078eb87ddbc5e  addpd xmm5, xmm15
000078eb87ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000078eb87ddbc68  ptest xmm4, xmm4
000078eb87ddbc6d  jnz 0x000078EB87DDD0FA
000078eb87ddbc73  movaps xmm8, [r15+0x1B0]
000078eb87ddbc7b  movaps xmm4, xmm9
000078eb87ddbc7f  addpd xmm4, xmm8
000078eb87ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000078eb87ddbc89  ptest xmm2, xmm2
000078eb87ddbc8e  jnz 0x000078EB87DDD23C
000078eb87ddbc94  movaps xmm9, xmm10
000078eb87ddbc98  addpd xmm9, xmm8
000078eb87ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000078eb87ddbca3  ptest xmm2, xmm2
000078eb87ddbca8  jnz 0x000078EB87DDD37E
000078eb87ddbcae  movaps xmm10, [r15+0x2F0]
000078eb87ddbcb6  vmovaps [rsp+0x90], xmm10
000078eb87ddbcbf  vmovaps xmm8, [rsp+0x90]
000078eb87ddbcc8  por xmm10, xmm8
000078eb87ddbccd  movaps xmm8, [r15+0x2E0]
000078eb87ddbcd5  vmovaps [rsp+0x90], xmm8
000078eb87ddbcde  vmovaps xmm2, [rsp+0x90]
000078eb87ddbce7  por xmm8, xmm2
000078eb87ddbcec  movaps xmm2, [r15+0x2D0]
000078eb87ddbcf4  vmovaps [rsp+0x90], xmm2
000078eb87ddbcfd  vmovaps [rsp+0xA0], xmm1
000078eb87ddbd06  vmovaps xmm1, [rsp+0x90]
000078eb87ddbd0f  por xmm2, xmm1
000078eb87ddbd13  movaps xmm1, [r15+0x200]
000078eb87ddbd1b  vmovaps [rsp+0x90], xmm1
000078eb87ddbd24  vmovaps [rsp+0xB0], xmm15
000078eb87ddbd2d  vmovaps xmm15, [rsp+0x90]
000078eb87ddbd36  por xmm1, xmm15
000078eb87ddbd3b  movaps xmm15, [r15+0x1C0]
000078eb87ddbd43  vmovaps [rsp+0x90], xmm15
000078eb87ddbd4c  vmovaps [rsp+0xC0], xmm1
000078eb87ddbd55  vmovaps xmm1, [rsp+0x90]
000078eb87ddbd5e  por xmm15, xmm1
000078eb87ddbd63  movaps xmm1, [r15+0x190]
000078eb87ddbd6b  vmovaps [rsp+0x90], xmm1
000078eb87ddbd74  vmovaps [rsp+0xD0], xmm15
000078eb87ddbd7d  vmovaps xmm15, [rsp+0x90]
000078eb87ddbd86  por xmm1, xmm15
000078eb87ddbd8b  movaps xmm15, [r15+0x300]
000078eb87ddbd93  vmovaps [rsp+0x90], xmm15
000078eb87ddbd9c  vmovaps [rsp+0xE0], xmm1
000078eb87ddbda5  vmovaps xmm1, [rsp+0x90]
000078eb87ddbdae  por xmm15, xmm1
000078eb87ddbdb3  mov rax, [rsp+0x80]
000078eb87ddbdbb  lea r12, [rax+0xA0]
000078eb87ddbdc2  movups xmm1, [r13+r12*1]
000078eb87ddbdc8  lea r12, [rax+0xB0]
000078eb87ddbdcf  vmovaps [rsp+0x80], xmm1
000078eb87ddbdd8  movups xmm1, [r13+r12*1]
000078eb87ddbdde  vmovaps [rsp+0x90], xmm1
000078eb87ddbde7  vmovaps [rsp+0xF0], xmm15
000078eb87ddbdf0  vmovaps xmm15, [rsp+0xB0]
000078eb87ddbdf9  vmovaps [rsp+0xB0], xmm14
000078eb87ddbe02  movaps xmm1, xmm6
000078eb87ddbe05  addpd xmm1, xmm15
000078eb87ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000078eb87ddbe0f  ptest xmm14, xmm14
000078eb87ddbe15  jnz 0x000078EB87DDD4D6
000078eb87ddbe1b  lea r12, [rax+0xF0]
000078eb87ddbe22  movups xmm15, [r13+r12*1]
000078eb87ddbe28  movaps xmm14, xmm4
000078eb87ddbe2c  addpd xmm14, xmm3
000078eb87ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000078eb87ddbe37  ptest xmm6, xmm6
000078eb87ddbe3c  jnz 0x000078EB87DDD621
000078eb87ddbe42  movaps xmm6, xmm9
000078eb87ddbe46  addpd xmm6, xmm7
000078eb87ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000078eb87ddbe4f  ptest xmm4, xmm4
000078eb87ddbe54  jnz 0x000078EB87DDD763
000078eb87ddbe5a  vmovaps xmm9, [rsp+0x70]
000078eb87ddbe60  vpermilpd xmm9, xmm9, 0x00
000078eb87ddbe66  vmovaps xmm4, [rsp+0x90]
000078eb87ddbe6f  movaps xmm7, xmm4
000078eb87ddbe72  mulpd xmm7, xmm9
000078eb87ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000078eb87ddbe7c  ptest xmm3, xmm3
000078eb87ddbe81  jnz 0x000078EB87DDD8A4
000078eb87ddbe87  vmovaps xmm9, [rsp+0x50]
000078eb87ddbe8d  vpermilpd xmm9, xmm9, 0x00
000078eb87ddbe93  movaps xmm4, xmm15
000078eb87ddbe97  mulpd xmm4, xmm9
000078eb87ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000078eb87ddbea1  ptest xmm3, xmm3
000078eb87ddbea6  jnz 0x000078EB87DDD9E5
000078eb87ddbeac  lea r12, [rax+0xE0]
000078eb87ddbeb3  movups xmm15, [r13+r12*1]
000078eb87ddbeb9  vmovaps xmm9, [rsp+0x70]
000078eb87ddbebf  vpermilpd xmm9, xmm9, 0x00
000078eb87ddbec5  vmovaps [rsp+0x70], xmm1
000078eb87ddbecb  vmovaps xmm1, [rsp+0x80]
000078eb87ddbed4  vmovaps [rsp+0x80], xmm15
000078eb87ddbedd  movaps xmm3, xmm1
000078eb87ddbee0  mulpd xmm3, xmm9
000078eb87ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000078eb87ddbeea  ptest xmm15, xmm15
000078eb87ddbef0  jnz 0x000078EB87DDDB31
000078eb87ddbef6  vmovaps xmm1, [rsp+0xF0]
000078eb87ddbeff  vmovaps xmm15, [rsp+0xF0]
000078eb87ddbf08  por xmm1, xmm15
000078eb87ddbf0d  movaps [r15+0x300], xmm1
000078eb87ddbf15  vmovaps xmm15, [rsp+0xE0]
000078eb87ddbf1e  vmovaps xmm9, [rsp+0xE0]
000078eb87ddbf27  por xmm15, xmm9
000078eb87ddbf2c  movaps [r15+0x190], xmm15
000078eb87ddbf34  vmovaps xmm9, [rsp+0x50]
000078eb87ddbf3a  vpermilpd xmm9, xmm9, 0x00
000078eb87ddbf40  vmovaps [rsp+0x90], xmm1
000078eb87ddbf49  vmovaps [rsp+0xE0], xmm15
000078eb87ddbf52  vmovaps xmm15, [rsp+0x80]
000078eb87ddbf5b  vmovaps [rsp+0x80], xmm14
000078eb87ddbf64  movaps xmm1, xmm15
000078eb87ddbf68  mulpd xmm1, xmm9
000078eb87ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000078eb87ddbf72  ptest xmm14, xmm14
000078eb87ddbf78  jnz 0x000078EB87DDDC72
000078eb87ddbf7e  lea r12, [rax+0x90]
000078eb87ddbf85  movups xmm15, [r13+r12*1]
000078eb87ddbf8b  vmovaps xmm14, [rsp+0xD0]
000078eb87ddbf94  vmovaps xmm9, [rsp+0xD0]
000078eb87ddbf9d  por xmm14, xmm9
000078eb87ddbfa2  movaps [r15+0x1C0], xmm14
000078eb87ddbfaa  vmovaps xmm9, [rsp+0xC0]
000078eb87ddbfb3  vmovaps [rsp+0xD0], xmm1
000078eb87ddbfbc  vmovaps xmm1, [rsp+0xC0]
000078eb87ddbfc5  por xmm9, xmm1
000078eb87ddbfca  movaps [r15+0x200], xmm9
000078eb87ddbfd2  vmovaps [rsp+0xC0], xmm2
000078eb87ddbfdb  vmovaps xmm1, [rsp+0xC0]
000078eb87ddbfe4  por xmm2, xmm1
000078eb87ddbfe8  movaps [r15+0x2D0], xmm2
000078eb87ddbff0  vmovaps [rsp+0xC0], xmm8
000078eb87ddbff9  vmovaps xmm1, [rsp+0xC0]
000078eb87ddc002  por xmm8, xmm1
000078eb87ddc007  movaps [r15+0x2E0], xmm8
000078eb87ddc00f  vmovaps [rsp+0xC0], xmm15
000078eb87ddc018  movaps xmm1, xmm5
000078eb87ddc01b  addpd xmm1, xmm7
000078eb87ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000078eb87ddc024  ptest xmm15, xmm15
000078eb87ddc02a  jnz 0x000078EB87DDDDBE
000078eb87ddc030  vmovaps xmm15, [rsp+0x50]
000078eb87ddc036  vpermilpd xmm15, xmm15, 0x00
000078eb87ddc03c  vmovaps xmm5, [rsp+0xC0]
000078eb87ddc045  vmovaps [rsp+0xC0], xmm1
000078eb87ddc04e  movaps xmm7, xmm5
000078eb87ddc051  mulpd xmm7, xmm15
000078eb87ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000078eb87ddc05b  ptest xmm1, xmm1
000078eb87ddc060  jnz 0x000078EB87DDDEFE
000078eb87ddc066  lea r12, [rax+0x80]
000078eb87ddc06d  movups xmm1, [r13+r12*1]
000078eb87ddc073  vmovaps xmm5, [rsp+0x70]
000078eb87ddc079  vmovaps [rsp+0x70], xmm1
000078eb87ddc07f  movaps xmm15, xmm5
000078eb87ddc083  addpd xmm15, xmm3
000078eb87ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87ddc08e  ptest xmm1, xmm1
000078eb87ddc093  jnz 0x000078EB87DDE049
000078eb87ddc099  vmovaps xmm5, [rsp+0x80]
000078eb87ddc0a2  movaps xmm1, xmm5
000078eb87ddc0a5  addpd xmm1, xmm4
000078eb87ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000078eb87ddc0ae  ptest xmm3, xmm3
000078eb87ddc0b3  jnz 0x000078EB87DDE18B
000078eb87ddc0b9  vmovaps [rsp+0x80], xmm10
000078eb87ddc0c2  vmovaps xmm5, [rsp+0x80]
000078eb87ddc0cb  por xmm10, xmm5
000078eb87ddc0d0  movaps [r15+0x2F0], xmm10
000078eb87ddc0d8  vmovaps xmm5, [rsp+0x50]
000078eb87ddc0de  vpermilpd xmm5, xmm5, 0x00
000078eb87ddc0e4  vmovaps xmm3, [rsp+0x70]
000078eb87ddc0ea  vmovaps [rsp+0x50], xmm1
000078eb87ddc0f0  movaps xmm4, xmm3
000078eb87ddc0f3  mulpd xmm4, xmm5
000078eb87ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000078eb87ddc0fc  ptest xmm1, xmm1
000078eb87ddc101  jnz 0x000078EB87DDE2CB
000078eb87ddc107  lea r12, [rax+0xD0]
000078eb87ddc10e  movups xmm1, [r13+r12*1]
000078eb87ddc114  vmovaps xmm3, [rsp+0xD0]
000078eb87ddc11d  vmovaps [rsp+0x70], xmm1
000078eb87ddc123  movaps xmm5, xmm6
000078eb87ddc126  addpd xmm5, xmm3
000078eb87ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000078eb87ddc12f  ptest xmm1, xmm1
000078eb87ddc134  jnz 0x000078EB87DDE415
000078eb87ddc13a  vmovaps xmm1, [rsp+0x60]
000078eb87ddc140  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc146  movaps xmm6, xmm9
000078eb87ddc14a  mulpd xmm6, xmm1
000078eb87ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000078eb87ddc153  ptest xmm3, xmm3
000078eb87ddc158  jnz 0x000078EB87DDE555
000078eb87ddc15e  movaps [r15+0x260], xmm6
000078eb87ddc166  vxorps xmm1, xmm1, xmm1
000078eb87ddc16a  vpbroadcastq xmm1, xmm1
000078eb87ddc16f  movaps [r15+0x1B0], xmm1
000078eb87ddc177  vmovaps xmm1, [rsp+0x60]
000078eb87ddc17d  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc183  vmovaps xmm3, [rsp+0x70]
000078eb87ddc189  vmovaps [rsp+0x70], xmm15
000078eb87ddc18f  movaps xmm9, xmm3
000078eb87ddc193  mulpd xmm9, xmm1
000078eb87ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000078eb87ddc19e  ptest xmm15, xmm15
000078eb87ddc1a4  jnz 0x000078EB87DDE696
000078eb87ddc1aa  lea r12, [rax+0xC0]
000078eb87ddc1b1  movups xmm1, [r13+r12*1]
000078eb87ddc1b7  vmovaps xmm3, [rsp+0xC0]
000078eb87ddc1c0  vmovaps [rsp+0x80], xmm1
000078eb87ddc1c9  movaps xmm15, xmm3
000078eb87ddc1cd  addpd xmm15, xmm7
000078eb87ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87ddc1d8  ptest xmm1, xmm1
000078eb87ddc1dd  jnz 0x000078EB87DDE7E2
000078eb87ddc1e3  vmovaps [rsp+0xC0], xmm13
000078eb87ddc1ec  vmovaps xmm1, [rsp+0xC0]
000078eb87ddc1f5  por xmm13, xmm1
000078eb87ddc1fa  movaps [r15+0x270], xmm13
000078eb87ddc202  vmovaps xmm1, [rsp+0xB0]
000078eb87ddc20b  vmovaps xmm7, [rsp+0xB0]
000078eb87ddc214  por xmm1, xmm7
000078eb87ddc218  movaps [r15+0x1A0], xmm1
000078eb87ddc220  vmovaps xmm1, [rsp+0x60]
000078eb87ddc226  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc22c  vmovaps [rsp+0xB0], xmm1
000078eb87ddc235  vmovaps xmm1, [rsp+0x80]
000078eb87ddc23e  vmovaps [rsp+0x80], xmm15
000078eb87ddc247  vmovaps xmm15, [rsp+0xB0]
000078eb87ddc250  vmovaps [rsp+0xB0], xmm14
000078eb87ddc259  movaps xmm3, xmm1
000078eb87ddc25c  mulpd xmm3, xmm15
000078eb87ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000078eb87ddc266  ptest xmm14, xmm14
000078eb87ddc26c  jnz 0x000078EB87DDE924
000078eb87ddc272  lea r12, [rax+0x20]
000078eb87ddc276  movups xmm1, [r13+r12*1]
000078eb87ddc27c  movaps [r15+0x110], xmm1
000078eb87ddc284  vmovaps xmm14, [rsp+0x70]
000078eb87ddc28a  vmovaps [rsp+0x70], xmm1
000078eb87ddc290  movaps xmm15, xmm14
000078eb87ddc294  addpd xmm15, xmm4
000078eb87ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000078eb87ddc29f  ptest xmm1, xmm1
000078eb87ddc2a4  jnz 0x000078EB87DDEA6F
000078eb87ddc2aa  vmovaps xmm1, [rsp+0x60]
000078eb87ddc2b0  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc2b6  movaps xmm14, xmm2
000078eb87ddc2ba  mulpd xmm14, xmm1
000078eb87ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000078eb87ddc2c5  ptest xmm4, xmm4
000078eb87ddc2ca  jnz 0x000078EB87DDEBB2
000078eb87ddc2d0  vmovaps xmm4, [rsp+0x50]
000078eb87ddc2d6  movaps xmm1, xmm4
000078eb87ddc2d9  addpd xmm1, xmm9
000078eb87ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000078eb87ddc2e3  ptest xmm2, xmm2
000078eb87ddc2e8  jnz 0x000078EB87DDECF4
000078eb87ddc2ee  vmovaps xmm9, [rsp+0x30]
000078eb87ddc2f4  vpermilpd xmm9, xmm9, 0x00
000078eb87ddc2fa  vmovaps xmm2, [rsp+0x70]
000078eb87ddc300  vmovaps [rsp+0x50], xmm1
000078eb87ddc306  movaps xmm4, xmm2
000078eb87ddc309  mulpd xmm4, xmm9
000078eb87ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000078eb87ddc313  ptest xmm1, xmm1
000078eb87ddc318  jnz 0x000078EB87DDEE35
000078eb87ddc31e  vmovaps xmm1, [rsp+0x30]
000078eb87ddc324  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc32a  vmovaps xmm2, [rsp+0x90]
000078eb87ddc333  vmovaps [rsp+0x60], xmm15
000078eb87ddc339  movaps xmm9, xmm2
000078eb87ddc33d  mulpd xmm9, xmm1
000078eb87ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000078eb87ddc348  ptest xmm15, xmm15
000078eb87ddc34e  jnz 0x000078EB87DDEF76
000078eb87ddc354  vmovaps xmm15, [rsp+0x80]
000078eb87ddc35d  movaps xmm1, xmm15
000078eb87ddc361  addpd xmm1, xmm6
000078eb87ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000078eb87ddc36a  ptest xmm2, xmm2
000078eb87ddc36f  jnz 0x000078EB87DDF0B8
000078eb87ddc375  movaps xmm15, xmm5
000078eb87ddc379  addpd xmm15, xmm3
000078eb87ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000078eb87ddc384  ptest xmm6, xmm6
000078eb87ddc389  jnz 0x000078EB87DDF1F9
000078eb87ddc38f  vmovaps xmm6, [rsp+0x30]
000078eb87ddc395  vpermilpd xmm6, xmm6, 0x00
000078eb87ddc39b  movaps xmm5, xmm8
000078eb87ddc39f  mulpd xmm5, xmm6
000078eb87ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000078eb87ddc3a8  ptest xmm3, xmm3
000078eb87ddc3ad  jnz 0x000078EB87DDF33B
000078eb87ddc3b3  vmovaps xmm8, [rsp+0x30]
000078eb87ddc3b9  vpermilpd xmm8, xmm8, 0x00
000078eb87ddc3bf  movaps xmm6, xmm10
000078eb87ddc3c3  mulpd xmm6, xmm8
000078eb87ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000078eb87ddc3cd  ptest xmm3, xmm3
000078eb87ddc3d2  jnz 0x000078EB87DDF47C
000078eb87ddc3d8  vmovaps xmm8, [rsp+0x60]
000078eb87ddc3de  movaps xmm10, xmm8
000078eb87ddc3e2  addpd xmm10, xmm14
000078eb87ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000078eb87ddc3ed  ptest xmm3, xmm3
000078eb87ddc3f2  jnz 0x000078EB87DDF5BE
000078eb87ddc3f8  vmovaps xmm8, [rsp+0x50]
000078eb87ddc3fe  movaps xmm14, xmm8
000078eb87ddc402  addpd xmm14, xmm4
000078eb87ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000078eb87ddc40d  ptest xmm3, xmm3
000078eb87ddc412  jnz 0x000078EB87DDF702
000078eb87ddc418  vmovaps xmm8, [rsp+0x40]
000078eb87ddc41e  vpermilpd xmm8, xmm8, 0x00
000078eb87ddc424  movaps xmm4, xmm13
000078eb87ddc428  mulpd xmm4, xmm8
000078eb87ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000078eb87ddc432  ptest xmm3, xmm3
000078eb87ddc437  jnz 0x000078EB87DDF845
000078eb87ddc43d  movaps xmm13, xmm15
000078eb87ddc441  addpd xmm13, xmm9
000078eb87ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000078eb87ddc44c  ptest xmm8, xmm8
000078eb87ddc452  jnz 0x000078EB87DDF987
000078eb87ddc458  movaps xmm15, xmm1
000078eb87ddc45c  addpd xmm15, xmm5
000078eb87ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000078eb87ddc467  ptest xmm9, xmm9
000078eb87ddc46d  jnz 0x000078EB87DDFACB
000078eb87ddc473  vmovaps [rsp+0x30], xmm11
000078eb87ddc479  vmovaps xmm1, [rsp+0x30]
000078eb87ddc47f  por xmm11, xmm1
000078eb87ddc484  movaps [r15+0x250], xmm11
000078eb87ddc48c  vmovaps [rsp+0x30], xmm12
000078eb87ddc492  vmovaps xmm1, [rsp+0x30]
000078eb87ddc498  por xmm12, xmm1
000078eb87ddc49d  movaps [r15+0x2A0], xmm12
000078eb87ddc4a5  vmovaps xmm1, [rsp+0xA0]
000078eb87ddc4ae  vmovaps xmm11, [rsp+0xA0]
000078eb87ddc4b7  por xmm1, xmm11
000078eb87ddc4bc  movaps [r15+0x1D0], xmm1
000078eb87ddc4c4  lea r12, [rax+0x40]
000078eb87ddc4c8  movups xmm1, [r13+r12*1]
000078eb87ddc4ce  movaps [r15+0x2C0], xmm1
000078eb87ddc4d6  vmovaps xmm11, [rsp+0x40]
000078eb87ddc4dc  vpermilpd xmm11, xmm11, 0x00
000078eb87ddc4e2  vmovaps xmm8, [rsp+0xE0]
000078eb87ddc4eb  movaps xmm9, xmm8
000078eb87ddc4ef  mulpd xmm9, xmm11
000078eb87ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000078eb87ddc4fa  ptest xmm5, xmm5
000078eb87ddc4ff  jnz 0x000078EB87DDFC17
000078eb87ddc505  movaps xmm11, xmm10
000078eb87ddc509  addpd xmm11, xmm6
000078eb87ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000078eb87ddc514  ptest xmm8, xmm8
000078eb87ddc51a  jnz 0x000078EB87DDFD5B
000078eb87ddc520  movaps xmm10, xmm14
000078eb87ddc524  addpd xmm10, xmm4
000078eb87ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000078eb87ddc52f  ptest xmm8, xmm8
000078eb87ddc535  jnz 0x000078EB87DDFE9E
000078eb87ddc53b  vmovaps xmm14, [rsp+0x40]
000078eb87ddc541  vpermilpd xmm14, xmm14, 0x00
000078eb87ddc547  movaps xmm8, xmm1
000078eb87ddc54b  mulpd xmm8, xmm14
000078eb87ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000078eb87ddc556  ptest xmm6, xmm6
000078eb87ddc55b  jnz 0x000078EB87DDFFE1
000078eb87ddc561  movaps xmm1, [r15+0x2B0]
000078eb87ddc569  vmovaps xmm14, [rsp+0x40]
000078eb87ddc56f  vpermilpd xmm14, xmm14, 0x00
000078eb87ddc575  movaps xmm6, xmm1
000078eb87ddc578  mulpd xmm6, xmm14
000078eb87ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000078eb87ddc582  ptest xmm5, xmm5
000078eb87ddc587  jnz 0x000078EB87DE0124
000078eb87ddc58d  vmovaps xmm1, [rsp+0x10]
000078eb87ddc593  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc599  movaps xmm14, xmm12
000078eb87ddc59d  mulpd xmm14, xmm1
000078eb87ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000078eb87ddc5a8  ptest xmm5, xmm5
000078eb87ddc5ad  jnz 0x000078EB87DE0265
000078eb87ddc5b3  movaps xmm1, xmm13
000078eb87ddc5b7  addpd xmm1, xmm9
000078eb87ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000078eb87ddc5c1  ptest xmm12, xmm12
000078eb87ddc5c7  jnz 0x000078EB87DE03A8
000078eb87ddc5cd  vmovaps xmm13, [rsp+0x10]
000078eb87ddc5d3  vpermilpd xmm13, xmm13, 0x00
000078eb87ddc5d9  movaps xmm12, xmm7
000078eb87ddc5dd  mulpd xmm12, xmm13
000078eb87ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000078eb87ddc5e8  ptest xmm9, xmm9
000078eb87ddc5ee  jnz 0x000078EB87DE04EA
000078eb87ddc5f4  movaps xmm13, xmm15
000078eb87ddc5f8  addpd xmm13, xmm8
000078eb87ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000078eb87ddc603  ptest xmm9, xmm9
000078eb87ddc609  jnz 0x000078EB87DE062D
000078eb87ddc60f  movaps xmm15, [r15+0x290]
000078eb87ddc617  vmovaps xmm9, [rsp+0x10]
000078eb87ddc61d  vpermilpd xmm9, xmm9, 0x00
000078eb87ddc623  movaps xmm8, xmm15
000078eb87ddc627  mulpd xmm8, xmm9
000078eb87ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000078eb87ddc632  ptest xmm7, xmm7
000078eb87ddc637  jnz 0x000078EB87DE0771
000078eb87ddc63d  movaps xmm15, xmm11
000078eb87ddc641  addpd xmm15, xmm6
000078eb87ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000078eb87ddc64c  ptest xmm9, xmm9
000078eb87ddc652  jnz 0x000078EB87DE08B5
000078eb87ddc658  movaps xmm11, [r15+0x1E0]
000078eb87ddc660  vmovaps xmm9, [rsp+0x10]
000078eb87ddc666  vpermilpd xmm9, xmm9, 0x00
000078eb87ddc66c  movaps xmm7, xmm11
000078eb87ddc670  mulpd xmm7, xmm9
000078eb87ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000078eb87ddc67a  ptest xmm6, xmm6
000078eb87ddc67f  jnz 0x000078EB87DE09F8
000078eb87ddc685  movaps xmm11, xmm10
000078eb87ddc689  addpd xmm11, xmm14
000078eb87ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000078eb87ddc694  ptest xmm9, xmm9
000078eb87ddc69a  jnz 0x000078EB87DE0B3A
000078eb87ddc6a0  lea r12, [rax+0x70]
000078eb87ddc6a4  movups xmm14, [r13+r12*1]
000078eb87ddc6aa  movaps [r15+0x240], xmm14
000078eb87ddc6b2  movaps xmm10, xmm1
000078eb87ddc6b6  addpd xmm10, xmm12
000078eb87ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000078eb87ddc6c1  ptest xmm9, xmm9
000078eb87ddc6c7  jnz 0x000078EB87DE0C88
000078eb87ddc6cd  movaps [r15+0x170], xmm10
000078eb87ddc6d5  vmovaps xmm1, [rsp+0x20]
000078eb87ddc6db  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc6e1  movaps xmm12, xmm14
000078eb87ddc6e5  mulpd xmm12, xmm1
000078eb87ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000078eb87ddc6f0  ptest xmm9, xmm9
000078eb87ddc6f6  jnz 0x000078EB87DE0DCB
000078eb87ddc6fc  vmovaps xmm1, [rsp+0x20]
000078eb87ddc702  vpermilpd xmm1, xmm1, 0x00
000078eb87ddc708  vmovaps xmm9, [rsp+0xB0]
000078eb87ddc711  movaps xmm14, xmm9
000078eb87ddc715  mulpd xmm14, xmm1
000078eb87ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000078eb87ddc720  ptest xmm6, xmm6
000078eb87ddc725  jnz 0x000078EB87DE0F0E
000078eb87ddc72b  movaps [r15+0x180], xmm14
000078eb87ddc733  movaps xmm1, xmm13
000078eb87ddc737  addpd xmm1, xmm8
000078eb87ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000078eb87ddc741  ptest xmm9, xmm9
000078eb87ddc747  jnz 0x000078EB87DE1051
000078eb87ddc74d  movaps [r15+0x210], xmm1
000078eb87ddc755  movups xmm13, [r13+rax*1]
000078eb87ddc75b  lea r12, [rax+0x10]
000078eb87ddc75f  movups xmm9, [r13+r12*1]
000078eb87ddc765  movaps [r15+0x230], xmm9
000078eb87ddc76d  movaps xmm8, xmm15
000078eb87ddc771  addpd xmm8, xmm7
000078eb87ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000078eb87ddc77c  ptest xmm6, xmm6
000078eb87ddc781  jnz 0x000078EB87DE11A7
000078eb87ddc787  movaps [r15+0x130], xmm8
000078eb87ddc78f  vmovaps xmm15, [rsp+0x20]
000078eb87ddc795  vpermilpd xmm15, xmm15, 0x00
000078eb87ddc79b  movaps xmm7, xmm9
000078eb87ddc79f  mulpd xmm7, xmm15
000078eb87ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000078eb87ddc7a9  ptest xmm6, xmm6
000078eb87ddc7ae  jnz 0x000078EB87DE12EA
000078eb87ddc7b4  movaps [r15+0x220], xmm7
000078eb87ddc7bc  vmovaps xmm15, [rsp+0x20]
000078eb87ddc7c2  vpermilpd xmm15, xmm15, 0x00
000078eb87ddc7c8  movaps xmm9, xmm13
000078eb87ddc7cc  mulpd xmm9, xmm15
000078eb87ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000078eb87ddc7d7  ptest xmm6, xmm6
000078eb87ddc7dc  jnz 0x000078EB87DE142C
000078eb87ddc7e2  movaps xmm15, xmm11
000078eb87ddc7e6  addpd xmm15, xmm12
000078eb87ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000078eb87ddc7f1  ptest xmm13, xmm13
000078eb87ddc7f7  jnz 0x000078EB87DE1570
000078eb87ddc7fd  movaps [r15+0x140], xmm15
000078eb87ddc805  movaps xmm13, xmm10
000078eb87ddc809  addpd xmm13, xmm14
000078eb87ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000078eb87ddc814  ptest xmm12, xmm12
000078eb87ddc81a  jnz 0x000078EB87DE16B4
000078eb87ddc820  movaps [r15+0x150], xmm13
000078eb87ddc828  movaps xmm14, xmm1
000078eb87ddc82c  addpd xmm14, xmm7
000078eb87ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000078eb87ddc837  ptest xmm12, xmm12
000078eb87ddc83d  jnz 0x000078EB87DE17F8
000078eb87ddc843  movaps [r15+0x160], xmm14
000078eb87ddc84b  movaps xmm1, xmm8
000078eb87ddc84f  addpd xmm1, xmm9
000078eb87ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000078eb87ddc859  ptest xmm12, xmm12
000078eb87ddc85f  jnz 0x000078EB87DE193A
000078eb87ddc865  movaps [r15+0x120], xmm1
000078eb87ddc86d  movups [r13+r14*1], xmm15
000078eb87ddc873  lea rax, [r14+0x10]
000078eb87ddc877  movups [r13+rax*1], xmm13
000078eb87ddc87d  lea rax, [r14+0x20]
000078eb87ddc881  movups [r13+rax*1], xmm14
000078eb87ddc887  lea rax, [r14+0x30]
000078eb87ddc88b  movups [r13+rax*1], xmm1
000078eb87ddc891  mov eax, [r15+0x108]
000078eb87ddc898  sahf
000078eb87ddc899  jnz 0x000078EB87DDC8CB
000078eb87ddc89b  cmp dword ptr [r15+0x318], 0x00
000078eb87ddc8a3  jz 0x000078EB87DDB900
000078eb87ddc8a9  nop [rax+rax*1], ax
000078eb87ddc8b2  nop [rax+rax*1], eax
000078eb87ddc8ba  mov eax, 0x410444
000078eb87ddc8bf  mov [r15+0x100], rax
000078eb87ddc8c6  jmp 0x000078EB87BFE110
000078eb87ddc8cb  cmp dword ptr [r15+0x318], 0x00
000078eb87ddc8d3  jz 0x000078EB87DD57E0
000078eb87ddc8d9  nop [rax+rax*1], ax
000078eb87ddc8e2  nop [rax+rax*1], eax
000078eb87ddc8ea  mov eax, 0x410278
000078eb87ddc8ef  mov [r15+0x100], rax
000078eb87ddc8f6  jmp 0x000078EB87BFE110
000078eb87ddc8fb  int3
000078eb87ddc8fc  call 0x000078EB87CE27E0
000078eb87ddc901  jmp 0x000078EB87DDB9DF
000078eb87ddc906  call 0x000078EB87CE1570
000078eb87ddc90b  jmp 0x000078EB87DDB9E8
000078eb87ddc910  call 0x000078EB87CE27E0
000078eb87ddc915  jmp 0x000078EB87DDBA44
000078eb87ddc91a  call 0x000078EB87CE1570
000078eb87ddc91f  jmp 0x000078EB87DDBA4D
000078eb87ddc924  call 0x000078EB87CE27E0
000078eb87ddc929  jmp 0x000078EB87DDBA90
000078eb87ddc92e  call 0x000078EB87CE1570
000078eb87ddc933  jmp 0x000078EB87DDBA99
000078eb87ddc938  call 0x000078EB87C0DC20
000078eb87ddc93d  jmp 0x000078EB87DDBAD8
000078eb87ddc942  call 0x000078EB87CD59C0
000078eb87ddc947  jmp 0x000078EB87DDBAEB
000078eb87ddc94c  call 0x000078EB87CE0E30
000078eb87ddc951  jmp 0x000078EB87DDBB09
000078eb87ddc956  call 0x000078EB87CDFBC0
000078eb87ddc95b  jmp 0x000078EB87DDBB13
000078eb87ddc960  call 0x000078EB87CDE950
000078eb87ddc965  jmp 0x000078EB87DDBB1D
000078eb87ddc96a  sub rsp, 0x08
000078eb87ddc96e  push rax
000078eb87ddc96f  push rcx
000078eb87ddc970  push rdx
000078eb87ddc971  push rdi
000078eb87ddc972  push rsi
000078eb87ddc973  push r8
000078eb87ddc975  push r9
000078eb87ddc977  push r10
000078eb87ddc979  push r11
000078eb87ddc97b  sub rsp, 0xF0
000078eb87ddc982  vmovaps [rsp], xmm0
000078eb87ddc987  vmovaps [rsp+0x10], xmm1
000078eb87ddc98d  vmovaps [rsp+0x20], xmm2
000078eb87ddc993  vmovaps [rsp+0x30], xmm3
000078eb87ddc999  vmovaps [rsp+0x40], xmm4
000078eb87ddc99f  vmovaps [rsp+0x50], xmm5
000078eb87ddc9a5  vmovaps [rsp+0x60], xmm6
000078eb87ddc9ab  vmovaps [rsp+0x70], xmm7
000078eb87ddc9b1  vmovaps [rsp+0x80], xmm9
000078eb87ddc9ba  vmovaps [rsp+0x90], xmm10
000078eb87ddc9c3  vmovaps [rsp+0xA0], xmm11
000078eb87ddc9cc  vmovaps [rsp+0xB0], xmm12
000078eb87ddc9d5  vmovaps [rsp+0xC0], xmm13
000078eb87ddc9de  vmovaps [rsp+0xD0], xmm14
000078eb87ddc9e7  vmovaps [rsp+0xE0], xmm15
000078eb87ddc9f0  sub rsp, 0x30
000078eb87ddc9f4  movaps [rsp], xmm8
000078eb87ddc9f9  movaps [rsp+0x10], xmm12
000078eb87ddc9ff  movaps [rsp+0x20], xmm15
000078eb87ddca05  lea rdi, [rsp]
000078eb87ddca09  mov esi, 0x00
000078eb87ddca0e  mov rax, 0x61D341A71530
000078eb87ddca18  call rax
000078eb87ddca1a  movaps xmm8, [rsp]
000078eb87ddca1f  add rsp, 0x30
000078eb87ddca23  vmovaps xmm0, [rsp]
000078eb87ddca28  vmovaps xmm1, [rsp+0x10]
000078eb87ddca2e  vmovaps xmm2, [rsp+0x20]
000078eb87ddca34  vmovaps xmm3, [rsp+0x30]
000078eb87ddca3a  vmovaps xmm4, [rsp+0x40]
000078eb87ddca40  vmovaps xmm5, [rsp+0x50]
000078eb87ddca46  vmovaps xmm6, [rsp+0x60]
000078eb87ddca4c  vmovaps xmm7, [rsp+0x70]
000078eb87ddca52  vmovaps xmm9, [rsp+0x80]
000078eb87ddca5b  vmovaps xmm10, [rsp+0x90]
000078eb87ddca64  vmovaps xmm11, [rsp+0xA0]
000078eb87ddca6d  vmovaps xmm12, [rsp+0xB0]
000078eb87ddca76  vmovaps xmm13, [rsp+0xC0]
000078eb87ddca7f  vmovaps xmm14, [rsp+0xD0]
000078eb87ddca88  vmovaps xmm15, [rsp+0xE0]
000078eb87ddca91  add rsp, 0xF0
000078eb87ddca98  pop r11
000078eb87ddca9a  pop r10
000078eb87ddca9c  pop r9
000078eb87ddca9e  pop r8
000078eb87ddcaa0  pop rsi
000078eb87ddcaa1  pop rdi
000078eb87ddcaa2  pop rdx
000078eb87ddcaa3  pop rcx
000078eb87ddcaa4  pop rax
000078eb87ddcaa5  add rsp, 0x08
000078eb87ddcaa9  jmp 0x000078EB87DDBB47
000078eb87ddcaae  sub rsp, 0x08
000078eb87ddcab2  push rax
000078eb87ddcab3  push rcx
000078eb87ddcab4  push rdx
000078eb87ddcab5  push rdi
000078eb87ddcab6  push rsi
000078eb87ddcab7  push r8
000078eb87ddcab9  push r9
000078eb87ddcabb  push r10
000078eb87ddcabd  push r11
000078eb87ddcabf  sub rsp, 0xF0
000078eb87ddcac6  vmovaps [rsp], xmm0
000078eb87ddcacb  vmovaps [rsp+0x10], xmm1
000078eb87ddcad1  vmovaps [rsp+0x20], xmm2
000078eb87ddcad7  vmovaps [rsp+0x30], xmm3
000078eb87ddcadd  vmovaps [rsp+0x40], xmm4
000078eb87ddcae3  vmovaps [rsp+0x50], xmm5
000078eb87ddcae9  vmovaps [rsp+0x60], xmm6
000078eb87ddcaef  vmovaps [rsp+0x70], xmm8
000078eb87ddcaf5  vmovaps [rsp+0x80], xmm9
000078eb87ddcafe  vmovaps [rsp+0x90], xmm10
000078eb87ddcb07  vmovaps [rsp+0xA0], xmm11
000078eb87ddcb10  vmovaps [rsp+0xB0], xmm12
000078eb87ddcb19  vmovaps [rsp+0xC0], xmm13
000078eb87ddcb22  vmovaps [rsp+0xD0], xmm14
000078eb87ddcb2b  vmovaps [rsp+0xE0], xmm15
000078eb87ddcb34  sub rsp, 0x30
000078eb87ddcb38  movaps [rsp], xmm7
000078eb87ddcb3c  movaps [rsp+0x10], xmm9
000078eb87ddcb42  movaps [rsp+0x20], xmm15
000078eb87ddcb48  lea rdi, [rsp]
000078eb87ddcb4c  mov esi, 0x00
000078eb87ddcb51  mov rax, 0x61D341A71530
000078eb87ddcb5b  call rax
000078eb87ddcb5d  movaps xmm7, [rsp]
000078eb87ddcb61  add rsp, 0x30
000078eb87ddcb65  vmovaps xmm0, [rsp]
000078eb87ddcb6a  vmovaps xmm1, [rsp+0x10]
000078eb87ddcb70  vmovaps xmm2, [rsp+0x20]
000078eb87ddcb76  vmovaps xmm3, [rsp+0x30]
000078eb87ddcb7c  vmovaps xmm4, [rsp+0x40]
000078eb87ddcb82  vmovaps xmm5, [rsp+0x50]
000078eb87ddcb88  vmovaps xmm6, [rsp+0x60]
000078eb87ddcb8e  vmovaps xmm8, [rsp+0x70]
000078eb87ddcb94  vmovaps xmm9, [rsp+0x80]
000078eb87ddcb9d  vmovaps xmm10, [rsp+0x90]
000078eb87ddcba6  vmovaps xmm11, [rsp+0xA0]
000078eb87ddcbaf  vmovaps xmm12, [rsp+0xB0]
000078eb87ddcbb8  vmovaps xmm13, [rsp+0xC0]
000078eb87ddcbc1  vmovaps xmm14, [rsp+0xD0]
000078eb87ddcbca  vmovaps xmm15, [rsp+0xE0]
000078eb87ddcbd3  add rsp, 0xF0
000078eb87ddcbda  pop r11
000078eb87ddcbdc  pop r10
000078eb87ddcbde  pop r9
000078eb87ddcbe0  pop r8
000078eb87ddcbe2  pop rsi
000078eb87ddcbe3  pop rdi
000078eb87ddcbe4  pop rdx
000078eb87ddcbe5  pop rcx
000078eb87ddcbe6  pop rax
000078eb87ddcbe7  add rsp, 0x08
000078eb87ddcbeb  jmp 0x000078EB87DDBB75
000078eb87ddcbf0  sub rsp, 0x08
000078eb87ddcbf4  push rax
000078eb87ddcbf5  push rcx
000078eb87ddcbf6  push rdx
000078eb87ddcbf7  push rdi
000078eb87ddcbf8  push rsi
000078eb87ddcbf9  push r8
000078eb87ddcbfb  push r9
000078eb87ddcbfd  push r10
000078eb87ddcbff  push r11
000078eb87ddcc01  sub rsp, 0xF0
000078eb87ddcc08  vmovaps [rsp], xmm0
000078eb87ddcc0d  vmovaps [rsp+0x10], xmm1
000078eb87ddcc13  vmovaps [rsp+0x20], xmm2
000078eb87ddcc19  vmovaps [rsp+0x30], xmm3
000078eb87ddcc1f  vmovaps [rsp+0x40], xmm4
000078eb87ddcc25  vmovaps [rsp+0x50], xmm5
000078eb87ddcc2b  vmovaps [rsp+0x60], xmm6
000078eb87ddcc31  vmovaps [rsp+0x70], xmm7
000078eb87ddcc37  vmovaps [rsp+0x80], xmm8
000078eb87ddcc40  vmovaps [rsp+0x90], xmm10
000078eb87ddcc49  vmovaps [rsp+0xA0], xmm11
000078eb87ddcc52  vmovaps [rsp+0xB0], xmm12
000078eb87ddcc5b  vmovaps [rsp+0xC0], xmm13
000078eb87ddcc64  vmovaps [rsp+0xD0], xmm14
000078eb87ddcc6d  vmovaps [rsp+0xE0], xmm15
000078eb87ddcc76  sub rsp, 0x30
000078eb87ddcc7a  movaps [rsp], xmm9
000078eb87ddcc7f  movaps [rsp+0x10], xmm12
000078eb87ddcc85  movaps [rsp+0x20], xmm10
000078eb87ddcc8b  lea rdi, [rsp]
000078eb87ddcc8f  mov esi, 0x00
000078eb87ddcc94  mov rax, 0x61D341A71530
000078eb87ddcc9e  call rax
000078eb87ddcca0  movaps xmm9, [rsp]
000078eb87ddcca5  add rsp, 0x30
000078eb87ddcca9  vmovaps xmm0, [rsp]
000078eb87ddccae  vmovaps xmm1, [rsp+0x10]
000078eb87ddccb4  vmovaps xmm2, [rsp+0x20]
000078eb87ddccba  vmovaps xmm3, [rsp+0x30]
000078eb87ddccc0  vmovaps xmm4, [rsp+0x40]
000078eb87ddccc6  vmovaps xmm5, [rsp+0x50]
000078eb87ddcccc  vmovaps xmm6, [rsp+0x60]
000078eb87ddccd2  vmovaps xmm7, [rsp+0x70]
000078eb87ddccd8  vmovaps xmm8, [rsp+0x80]
000078eb87ddcce1  vmovaps xmm10, [rsp+0x90]
000078eb87ddccea  vmovaps xmm11, [rsp+0xA0]
000078eb87ddccf3  vmovaps xmm12, [rsp+0xB0]
000078eb87ddccfc  vmovaps xmm13, [rsp+0xC0]
000078eb87ddcd05  vmovaps xmm14, [rsp+0xD0]
000078eb87ddcd0e  vmovaps xmm15, [rsp+0xE0]
000078eb87ddcd17  add rsp, 0xF0
000078eb87ddcd1e  pop r11
000078eb87ddcd20  pop r10
000078eb87ddcd22  pop r9
000078eb87ddcd24  pop r8
000078eb87ddcd26  pop rsi
000078eb87ddcd27  pop rdi
000078eb87ddcd28  pop rdx
000078eb87ddcd29  pop rcx
000078eb87ddcd2a  pop rax
000078eb87ddcd2b  add rsp, 0x08
000078eb87ddcd2f  jmp 0x000078EB87DDBB99
000078eb87ddcd34  sub rsp, 0x08
000078eb87ddcd38  push rax
000078eb87ddcd39  push rcx
000078eb87ddcd3a  push rdx
000078eb87ddcd3b  push rdi
000078eb87ddcd3c  push rsi
000078eb87ddcd3d  push r8
000078eb87ddcd3f  push r9
000078eb87ddcd41  push r10
000078eb87ddcd43  push r11
000078eb87ddcd45  sub rsp, 0xF0
000078eb87ddcd4c  vmovaps [rsp], xmm0
000078eb87ddcd51  vmovaps [rsp+0x10], xmm1
000078eb87ddcd57  vmovaps [rsp+0x20], xmm2
000078eb87ddcd5d  vmovaps [rsp+0x30], xmm3
000078eb87ddcd63  vmovaps [rsp+0x40], xmm4
000078eb87ddcd69  vmovaps [rsp+0x50], xmm5
000078eb87ddcd6f  vmovaps [rsp+0x60], xmm6
000078eb87ddcd75  vmovaps [rsp+0x70], xmm7
000078eb87ddcd7b  vmovaps [rsp+0x80], xmm8
000078eb87ddcd84  vmovaps [rsp+0x90], xmm9
000078eb87ddcd8d  vmovaps [rsp+0xA0], xmm11
000078eb87ddcd96  vmovaps [rsp+0xB0], xmm12
000078eb87ddcd9f  vmovaps [rsp+0xC0], xmm13
000078eb87ddcda8  vmovaps [rsp+0xD0], xmm14
000078eb87ddcdb1  vmovaps [rsp+0xE0], xmm15
000078eb87ddcdba  sub rsp, 0x30
000078eb87ddcdbe  movaps [rsp], xmm10
000078eb87ddcdc3  movaps [rsp+0x10], xmm12
000078eb87ddcdc9  movaps [rsp+0x20], xmm11
000078eb87ddcdcf  lea rdi, [rsp]
000078eb87ddcdd3  mov esi, 0x00
000078eb87ddcdd8  mov rax, 0x61D341A71530
000078eb87ddcde2  call rax
000078eb87ddcde4  movaps xmm10, [rsp]
000078eb87ddcde9  add rsp, 0x30
000078eb87ddcded  vmovaps xmm0, [rsp]
000078eb87ddcdf2  vmovaps xmm1, [rsp+0x10]
000078eb87ddcdf8  vmovaps xmm2, [rsp+0x20]
000078eb87ddcdfe  vmovaps xmm3, [rsp+0x30]
000078eb87ddce04  vmovaps xmm4, [rsp+0x40]
000078eb87ddce0a  vmovaps xmm5, [rsp+0x50]
000078eb87ddce10  vmovaps xmm6, [rsp+0x60]
000078eb87ddce16  vmovaps xmm7, [rsp+0x70]
000078eb87ddce1c  vmovaps xmm8, [rsp+0x80]
000078eb87ddce25  vmovaps xmm9, [rsp+0x90]
000078eb87ddce2e  vmovaps xmm11, [rsp+0xA0]
000078eb87ddce37  vmovaps xmm12, [rsp+0xB0]
000078eb87ddce40  vmovaps xmm13, [rsp+0xC0]
000078eb87ddce49  vmovaps xmm14, [rsp+0xD0]
000078eb87ddce52  vmovaps xmm15, [rsp+0xE0]
000078eb87ddce5b  add rsp, 0xF0
000078eb87ddce62  pop r11
000078eb87ddce64  pop r10
000078eb87ddce66  pop r9
000078eb87ddce68  pop r8
000078eb87ddce6a  pop rsi
000078eb87ddce6b  pop rdi
000078eb87ddce6c  pop rdx
000078eb87ddce6d  pop rcx
000078eb87ddce6e  pop rax
000078eb87ddce6f  add rsp, 0x08
000078eb87ddce73  jmp 0x000078EB87DDBBB3
000078eb87ddce78  sub rsp, 0x08
000078eb87ddce7c  push rax
000078eb87ddce7d  push rcx
000078eb87ddce7e  push rdx
000078eb87ddce7f  push rdi
000078eb87ddce80  push rsi
000078eb87ddce81  push r8
000078eb87ddce83  push r9
000078eb87ddce85  push r10
000078eb87ddce87  push r11
000078eb87ddce89  sub rsp, 0xF0
000078eb87ddce90  vmovaps [rsp], xmm0
000078eb87ddce95  vmovaps [rsp+0x10], xmm1
000078eb87ddce9b  vmovaps [rsp+0x20], xmm2
000078eb87ddcea1  vmovaps [rsp+0x30], xmm3
000078eb87ddcea7  vmovaps [rsp+0x40], xmm4
000078eb87ddcead  vmovaps [rsp+0x50], xmm5
000078eb87ddceb3  vmovaps [rsp+0x60], xmm7
000078eb87ddceb9  vmovaps [rsp+0x70], xmm8
000078eb87ddcebf  vmovaps [rsp+0x80], xmm9
000078eb87ddcec8  vmovaps [rsp+0x90], xmm10
000078eb87ddced1  vmovaps [rsp+0xA0], xmm11
000078eb87ddceda  vmovaps [rsp+0xB0], xmm12
000078eb87ddcee3  vmovaps [rsp+0xC0], xmm13
000078eb87ddceec  vmovaps [rsp+0xD0], xmm14
000078eb87ddcef5  vmovaps [rsp+0xE0], xmm15
000078eb87ddcefe  sub rsp, 0x30
000078eb87ddcf02  movaps [rsp], xmm6
000078eb87ddcf06  movaps [rsp+0x10], xmm12
000078eb87ddcf0c  movaps [rsp+0x20], xmm11
000078eb87ddcf12  lea rdi, [rsp]
000078eb87ddcf16  mov esi, 0x00
000078eb87ddcf1b  mov rax, 0x61D341A71530
000078eb87ddcf25  call rax
000078eb87ddcf27  movaps xmm6, [rsp]
000078eb87ddcf2b  add rsp, 0x30
000078eb87ddcf2f  vmovaps xmm0, [rsp]
000078eb87ddcf34  vmovaps xmm1, [rsp+0x10]
000078eb87ddcf3a  vmovaps xmm2, [rsp+0x20]
000078eb87ddcf40  vmovaps xmm3, [rsp+0x30]
000078eb87ddcf46  vmovaps xmm4, [rsp+0x40]
000078eb87ddcf4c  vmovaps xmm5, [rsp+0x50]
000078eb87ddcf52  vmovaps xmm7, [rsp+0x60]
000078eb87ddcf58  vmovaps xmm8, [rsp+0x70]
000078eb87ddcf5e  vmovaps xmm9, [rsp+0x80]
000078eb87ddcf67  vmovaps xmm10, [rsp+0x90]
000078eb87ddcf70  vmovaps xmm11, [rsp+0xA0]
000078eb87ddcf79  vmovaps xmm12, [rsp+0xB0]
000078eb87ddcf82  vmovaps xmm13, [rsp+0xC0]
000078eb87ddcf8b  vmovaps xmm14, [rsp+0xD0]
000078eb87ddcf94  vmovaps xmm15, [rsp+0xE0]
000078eb87ddcf9d  add rsp, 0xF0
000078eb87ddcfa4  pop r11
000078eb87ddcfa6  pop r10
000078eb87ddcfa8  pop r9
000078eb87ddcfaa  pop r8
000078eb87ddcfac  pop rsi
000078eb87ddcfad  pop rdi
000078eb87ddcfae  pop rdx
000078eb87ddcfaf  pop rcx
000078eb87ddcfb0  pop rax
000078eb87ddcfb1  add rsp, 0x08
000078eb87ddcfb5  jmp 0x000078EB87DDBBD4
000078eb87ddcfba  sub rsp, 0x08
000078eb87ddcfbe  push rax
000078eb87ddcfbf  push rcx
000078eb87ddcfc0  push rdx
000078eb87ddcfc1  push rdi
000078eb87ddcfc2  push rsi
000078eb87ddcfc3  push r8
000078eb87ddcfc5  push r9
000078eb87ddcfc7  push r10
000078eb87ddcfc9  push r11
000078eb87ddcfcb  sub rsp, 0xF0
000078eb87ddcfd2  vmovaps [rsp], xmm0
000078eb87ddcfd7  vmovaps [rsp+0x10], xmm1
000078eb87ddcfdd  vmovaps [rsp+0x20], xmm2
000078eb87ddcfe3  vmovaps [rsp+0x30], xmm4
000078eb87ddcfe9  vmovaps [rsp+0x40], xmm5
000078eb87ddcfef  vmovaps [rsp+0x50], xmm6
000078eb87ddcff5  vmovaps [rsp+0x60], xmm7
000078eb87ddcffb  vmovaps [rsp+0x70], xmm8
000078eb87ddd001  vmovaps [rsp+0x80], xmm9
000078eb87ddd00a  vmovaps [rsp+0x90], xmm10
000078eb87ddd013  vmovaps [rsp+0xA0], xmm11
000078eb87ddd01c  vmovaps [rsp+0xB0], xmm12
000078eb87ddd025  vmovaps [rsp+0xC0], xmm13
000078eb87ddd02e  vmovaps [rsp+0xD0], xmm14
000078eb87ddd037  vmovaps [rsp+0xE0], xmm15
000078eb87ddd040  sub rsp, 0x30
000078eb87ddd044  movaps [rsp], xmm3
000078eb87ddd048  movaps [rsp+0x10], xmm5
000078eb87ddd04d  movaps [rsp+0x20], xmm4
000078eb87ddd052  lea rdi, [rsp]
000078eb87ddd056  mov esi, 0x00
000078eb87ddd05b  mov rax, 0x61D341A71530
000078eb87ddd065  call rax
000078eb87ddd067  movaps xmm3, [rsp]
000078eb87ddd06b  add rsp, 0x30
000078eb87ddd06f  vmovaps xmm0, [rsp]
000078eb87ddd074  vmovaps xmm1, [rsp+0x10]
000078eb87ddd07a  vmovaps xmm2, [rsp+0x20]
000078eb87ddd080  vmovaps xmm4, [rsp+0x30]
000078eb87ddd086  vmovaps xmm5, [rsp+0x40]
000078eb87ddd08c  vmovaps xmm6, [rsp+0x50]
000078eb87ddd092  vmovaps xmm7, [rsp+0x60]
000078eb87ddd098  vmovaps xmm8, [rsp+0x70]
000078eb87ddd09e  vmovaps xmm9, [rsp+0x80]
000078eb87ddd0a7  vmovaps xmm10, [rsp+0x90]
000078eb87ddd0b0  vmovaps xmm11, [rsp+0xA0]
000078eb87ddd0b9  vmovaps xmm12, [rsp+0xB0]
000078eb87ddd0c2  vmovaps xmm13, [rsp+0xC0]
000078eb87ddd0cb  vmovaps xmm14, [rsp+0xD0]
000078eb87ddd0d4  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd0dd  add rsp, 0xF0
000078eb87ddd0e4  pop r11
000078eb87ddd0e6  pop r10
000078eb87ddd0e8  pop r9
000078eb87ddd0ea  pop r8
000078eb87ddd0ec  pop rsi
000078eb87ddd0ed  pop rdi
000078eb87ddd0ee  pop rdx
000078eb87ddd0ef  pop rcx
000078eb87ddd0f0  pop rax
000078eb87ddd0f1  add rsp, 0x08
000078eb87ddd0f5  jmp 0x000078EB87DDBC35
000078eb87ddd0fa  sub rsp, 0x08
000078eb87ddd0fe  push rax
000078eb87ddd0ff  push rcx
000078eb87ddd100  push rdx
000078eb87ddd101  push rdi
000078eb87ddd102  push rsi
000078eb87ddd103  push r8
000078eb87ddd105  push r9
000078eb87ddd107  push r10
000078eb87ddd109  push r11
000078eb87ddd10b  sub rsp, 0xF0
000078eb87ddd112  vmovaps [rsp], xmm0
000078eb87ddd117  vmovaps [rsp+0x10], xmm1
000078eb87ddd11d  vmovaps [rsp+0x20], xmm2
000078eb87ddd123  vmovaps [rsp+0x30], xmm3
000078eb87ddd129  vmovaps [rsp+0x40], xmm4
000078eb87ddd12f  vmovaps [rsp+0x50], xmm6
000078eb87ddd135  vmovaps [rsp+0x60], xmm7
000078eb87ddd13b  vmovaps [rsp+0x70], xmm8
000078eb87ddd141  vmovaps [rsp+0x80], xmm9
000078eb87ddd14a  vmovaps [rsp+0x90], xmm10
000078eb87ddd153  vmovaps [rsp+0xA0], xmm11
000078eb87ddd15c  vmovaps [rsp+0xB0], xmm12
000078eb87ddd165  vmovaps [rsp+0xC0], xmm13
000078eb87ddd16e  vmovaps [rsp+0xD0], xmm14
000078eb87ddd177  vmovaps [rsp+0xE0], xmm15
000078eb87ddd180  sub rsp, 0x30
000078eb87ddd184  movaps [rsp], xmm5
000078eb87ddd188  movaps [rsp+0x10], xmm8
000078eb87ddd18e  movaps [rsp+0x20], xmm15
000078eb87ddd194  lea rdi, [rsp]
000078eb87ddd198  mov esi, 0x00
000078eb87ddd19d  mov rax, 0x61D341A71530
000078eb87ddd1a7  call rax
000078eb87ddd1a9  movaps xmm5, [rsp]
000078eb87ddd1ad  add rsp, 0x30
000078eb87ddd1b1  vmovaps xmm0, [rsp]
000078eb87ddd1b6  vmovaps xmm1, [rsp+0x10]
000078eb87ddd1bc  vmovaps xmm2, [rsp+0x20]
000078eb87ddd1c2  vmovaps xmm3, [rsp+0x30]
000078eb87ddd1c8  vmovaps xmm4, [rsp+0x40]
000078eb87ddd1ce  vmovaps xmm6, [rsp+0x50]
000078eb87ddd1d4  vmovaps xmm7, [rsp+0x60]
000078eb87ddd1da  vmovaps xmm8, [rsp+0x70]
000078eb87ddd1e0  vmovaps xmm9, [rsp+0x80]
000078eb87ddd1e9  vmovaps xmm10, [rsp+0x90]
000078eb87ddd1f2  vmovaps xmm11, [rsp+0xA0]
000078eb87ddd1fb  vmovaps xmm12, [rsp+0xB0]
000078eb87ddd204  vmovaps xmm13, [rsp+0xC0]
000078eb87ddd20d  vmovaps xmm14, [rsp+0xD0]
000078eb87ddd216  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd21f  add rsp, 0xF0
000078eb87ddd226  pop r11
000078eb87ddd228  pop r10
000078eb87ddd22a  pop r9
000078eb87ddd22c  pop r8
000078eb87ddd22e  pop rsi
000078eb87ddd22f  pop rdi
000078eb87ddd230  pop rdx
000078eb87ddd231  pop rcx
000078eb87ddd232  pop rax
000078eb87ddd233  add rsp, 0x08
000078eb87ddd237  jmp 0x000078EB87DDBC73
000078eb87ddd23c  sub rsp, 0x08
000078eb87ddd240  push rax
000078eb87ddd241  push rcx
000078eb87ddd242  push rdx
000078eb87ddd243  push rdi
000078eb87ddd244  push rsi
000078eb87ddd245  push r8
000078eb87ddd247  push r9
000078eb87ddd249  push r10
000078eb87ddd24b  push r11
000078eb87ddd24d  sub rsp, 0xF0
000078eb87ddd254  vmovaps [rsp], xmm0
000078eb87ddd259  vmovaps [rsp+0x10], xmm1
000078eb87ddd25f  vmovaps [rsp+0x20], xmm2
000078eb87ddd265  vmovaps [rsp+0x30], xmm3
000078eb87ddd26b  vmovaps [rsp+0x40], xmm5
000078eb87ddd271  vmovaps [rsp+0x50], xmm6
000078eb87ddd277  vmovaps [rsp+0x60], xmm7
000078eb87ddd27d  vmovaps [rsp+0x70], xmm8
000078eb87ddd283  vmovaps [rsp+0x80], xmm9
000078eb87ddd28c  vmovaps [rsp+0x90], xmm10
000078eb87ddd295  vmovaps [rsp+0xA0], xmm11
000078eb87ddd29e  vmovaps [rsp+0xB0], xmm12
000078eb87ddd2a7  vmovaps [rsp+0xC0], xmm13
000078eb87ddd2b0  vmovaps [rsp+0xD0], xmm14
000078eb87ddd2b9  vmovaps [rsp+0xE0], xmm15
000078eb87ddd2c2  sub rsp, 0x30
000078eb87ddd2c6  movaps [rsp], xmm4
000078eb87ddd2ca  movaps [rsp+0x10], xmm9
000078eb87ddd2d0  movaps [rsp+0x20], xmm8
000078eb87ddd2d6  lea rdi, [rsp]
000078eb87ddd2da  mov esi, 0x00
000078eb87ddd2df  mov rax, 0x61D341A71530
000078eb87ddd2e9  call rax
000078eb87ddd2eb  movaps xmm4, [rsp]
000078eb87ddd2ef  add rsp, 0x30
000078eb87ddd2f3  vmovaps xmm0, [rsp]
000078eb87ddd2f8  vmovaps xmm1, [rsp+0x10]
000078eb87ddd2fe  vmovaps xmm2, [rsp+0x20]
000078eb87ddd304  vmovaps xmm3, [rsp+0x30]
000078eb87ddd30a  vmovaps xmm5, [rsp+0x40]
000078eb87ddd310  vmovaps xmm6, [rsp+0x50]
000078eb87ddd316  vmovaps xmm7, [rsp+0x60]
000078eb87ddd31c  vmovaps xmm8, [rsp+0x70]
000078eb87ddd322  vmovaps xmm9, [rsp+0x80]
000078eb87ddd32b  vmovaps xmm10, [rsp+0x90]
000078eb87ddd334  vmovaps xmm11, [rsp+0xA0]
000078eb87ddd33d  vmovaps xmm12, [rsp+0xB0]
000078eb87ddd346  vmovaps xmm13, [rsp+0xC0]
000078eb87ddd34f  vmovaps xmm14, [rsp+0xD0]
000078eb87ddd358  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd361  add rsp, 0xF0
000078eb87ddd368  pop r11
000078eb87ddd36a  pop r10
000078eb87ddd36c  pop r9
000078eb87ddd36e  pop r8
000078eb87ddd370  pop rsi
000078eb87ddd371  pop rdi
000078eb87ddd372  pop rdx
000078eb87ddd373  pop rcx
000078eb87ddd374  pop rax
000078eb87ddd375  add rsp, 0x08
000078eb87ddd379  jmp 0x000078EB87DDBC94
000078eb87ddd37e  sub rsp, 0x08
000078eb87ddd382  push rax
000078eb87ddd383  push rcx
000078eb87ddd384  push rdx
000078eb87ddd385  push rdi
000078eb87ddd386  push rsi
000078eb87ddd387  push r8
000078eb87ddd389  push r9
000078eb87ddd38b  push r10
000078eb87ddd38d  push r11
000078eb87ddd38f  sub rsp, 0xF0
000078eb87ddd396  vmovaps [rsp], xmm0
000078eb87ddd39b  vmovaps [rsp+0x10], xmm1
000078eb87ddd3a1  vmovaps [rsp+0x20], xmm2
000078eb87ddd3a7  vmovaps [rsp+0x30], xmm3
000078eb87ddd3ad  vmovaps [rsp+0x40], xmm4
000078eb87ddd3b3  vmovaps [rsp+0x50], xmm5
000078eb87ddd3b9  vmovaps [rsp+0x60], xmm6
000078eb87ddd3bf  vmovaps [rsp+0x70], xmm7
000078eb87ddd3c5  vmovaps [rsp+0x80], xmm8
000078eb87ddd3ce  vmovaps [rsp+0x90], xmm10
000078eb87ddd3d7  vmovaps [rsp+0xA0], xmm11
000078eb87ddd3e0  vmovaps [rsp+0xB0], xmm12
000078eb87ddd3e9  vmovaps [rsp+0xC0], xmm13
000078eb87ddd3f2  vmovaps [rsp+0xD0], xmm14
000078eb87ddd3fb  vmovaps [rsp+0xE0], xmm15
000078eb87ddd404  sub rsp, 0x30
000078eb87ddd408  movaps [rsp], xmm9
000078eb87ddd40d  movaps [rsp+0x10], xmm10
000078eb87ddd413  movaps [rsp+0x20], xmm8
000078eb87ddd419  lea rdi, [rsp]
000078eb87ddd41d  mov esi, 0x00
000078eb87ddd422  mov rax, 0x61D341A71530
000078eb87ddd42c  call rax
000078eb87ddd42e  movaps xmm9, [rsp]
000078eb87ddd433  add rsp, 0x30
000078eb87ddd437  vmovaps xmm0, [rsp]
000078eb87ddd43c  vmovaps xmm1, [rsp+0x10]
000078eb87ddd442  vmovaps xmm2, [rsp+0x20]
000078eb87ddd448  vmovaps xmm3, [rsp+0x30]
000078eb87ddd44e  vmovaps xmm4, [rsp+0x40]
000078eb87ddd454  vmovaps xmm5, [rsp+0x50]
000078eb87ddd45a  vmovaps xmm6, [rsp+0x60]
000078eb87ddd460  vmovaps xmm7, [rsp+0x70]
000078eb87ddd466  vmovaps xmm8, [rsp+0x80]
000078eb87ddd46f  vmovaps xmm10, [rsp+0x90]
000078eb87ddd478  vmovaps xmm11, [rsp+0xA0]
000078eb87ddd481  vmovaps xmm12, [rsp+0xB0]
000078eb87ddd48a  vmovaps xmm13, [rsp+0xC0]
000078eb87ddd493  vmovaps xmm14, [rsp+0xD0]
000078eb87ddd49c  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd4a5  add rsp, 0xF0
000078eb87ddd4ac  pop r11
000078eb87ddd4ae  pop r10
000078eb87ddd4b0  pop r9
000078eb87ddd4b2  pop r8
000078eb87ddd4b4  pop rsi
000078eb87ddd4b5  pop rdi
000078eb87ddd4b6  pop rdx
000078eb87ddd4b7  pop rcx
000078eb87ddd4b8  pop rax
000078eb87ddd4b9  add rsp, 0x08
000078eb87ddd4bd  jmp 0x000078EB87DDBCAE
000078eb87ddd4c2  call 0x000078EB87CB52F0
000078eb87ddd4c7  jmp 0x000078EB87DDBDC8
000078eb87ddd4cc  call 0x000078EB87CB52F0
000078eb87ddd4d1  jmp 0x000078EB87DDBDDE
000078eb87ddd4d6  sub rsp, 0x08
000078eb87ddd4da  push rax
000078eb87ddd4db  push rcx
000078eb87ddd4dc  push rdx
000078eb87ddd4dd  push rdi
000078eb87ddd4de  push rsi
000078eb87ddd4df  push r8
000078eb87ddd4e1  push r9
000078eb87ddd4e3  push r10
000078eb87ddd4e5  push r11
000078eb87ddd4e7  sub rsp, 0xF0
000078eb87ddd4ee  vmovaps [rsp], xmm0
000078eb87ddd4f3  vmovaps [rsp+0x10], xmm2
000078eb87ddd4f9  vmovaps [rsp+0x20], xmm3
000078eb87ddd4ff  vmovaps [rsp+0x30], xmm4
000078eb87ddd505  vmovaps [rsp+0x40], xmm5
000078eb87ddd50b  vmovaps [rsp+0x50], xmm6
000078eb87ddd511  vmovaps [rsp+0x60], xmm7
000078eb87ddd517  vmovaps [rsp+0x70], xmm8
000078eb87ddd51d  vmovaps [rsp+0x80], xmm9
000078eb87ddd526  vmovaps [rsp+0x90], xmm10
000078eb87ddd52f  vmovaps [rsp+0xA0], xmm11
000078eb87ddd538  vmovaps [rsp+0xB0], xmm12
000078eb87ddd541  vmovaps [rsp+0xC0], xmm13
000078eb87ddd54a  vmovaps [rsp+0xD0], xmm14
000078eb87ddd553  vmovaps [rsp+0xE0], xmm15
000078eb87ddd55c  sub rsp, 0x30
000078eb87ddd560  movaps [rsp], xmm1
000078eb87ddd564  movaps [rsp+0x10], xmm6
000078eb87ddd569  movaps [rsp+0x20], xmm15
000078eb87ddd56f  lea rdi, [rsp]
000078eb87ddd573  mov esi, 0x00
000078eb87ddd578  mov rax, 0x61D341A71530
000078eb87ddd582  call rax
000078eb87ddd584  movaps xmm1, [rsp]
000078eb87ddd588  add rsp, 0x30
000078eb87ddd58c  vmovaps xmm0, [rsp]
000078eb87ddd591  vmovaps xmm2, [rsp+0x10]
000078eb87ddd597  vmovaps xmm3, [rsp+0x20]
000078eb87ddd59d  vmovaps xmm4, [rsp+0x30]
000078eb87ddd5a3  vmovaps xmm5, [rsp+0x40]
000078eb87ddd5a9  vmovaps xmm6, [rsp+0x50]
000078eb87ddd5af  vmovaps xmm7, [rsp+0x60]
000078eb87ddd5b5  vmovaps xmm8, [rsp+0x70]
000078eb87ddd5bb  vmovaps xmm9, [rsp+0x80]
000078eb87ddd5c4  vmovaps xmm10, [rsp+0x90]
000078eb87ddd5cd  vmovaps xmm11, [rsp+0xA0]
000078eb87ddd5d6  vmovaps xmm12, [rsp+0xB0]
000078eb87ddd5df  vmovaps xmm13, [rsp+0xC0]
000078eb87ddd5e8  vmovaps xmm14, [rsp+0xD0]
000078eb87ddd5f1  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd5fa  add rsp, 0xF0
000078eb87ddd601  pop r11
000078eb87ddd603  pop r10
000078eb87ddd605  pop r9
000078eb87ddd607  pop r8
000078eb87ddd609  pop rsi
000078eb87ddd60a  pop rdi
000078eb87ddd60b  pop rdx
000078eb87ddd60c  pop rcx
000078eb87ddd60d  pop rax
000078eb87ddd60e  add rsp, 0x08
000078eb87ddd612  jmp 0x000078EB87DDBE1B
000078eb87ddd617  call 0x000078EB87CC4620
000078eb87ddd61c  jmp 0x000078EB87DDBE28
000078eb87ddd621  sub rsp, 0x08
000078eb87ddd625  push rax
000078eb87ddd626  push rcx
000078eb87ddd627  push rdx
000078eb87ddd628  push rdi
000078eb87ddd629  push rsi
000078eb87ddd62a  push r8
000078eb87ddd62c  push r9
000078eb87ddd62e  push r10
000078eb87ddd630  push r11
000078eb87ddd632  sub rsp, 0xF0
000078eb87ddd639  vmovaps [rsp], xmm0
000078eb87ddd63e  vmovaps [rsp+0x10], xmm1
000078eb87ddd644  vmovaps [rsp+0x20], xmm2
000078eb87ddd64a  vmovaps [rsp+0x30], xmm3
000078eb87ddd650  vmovaps [rsp+0x40], xmm4
000078eb87ddd656  vmovaps [rsp+0x50], xmm5
000078eb87ddd65c  vmovaps [rsp+0x60], xmm6
000078eb87ddd662  vmovaps [rsp+0x70], xmm7
000078eb87ddd668  vmovaps [rsp+0x80], xmm8
000078eb87ddd671  vmovaps [rsp+0x90], xmm9
000078eb87ddd67a  vmovaps [rsp+0xA0], xmm10
000078eb87ddd683  vmovaps [rsp+0xB0], xmm11
000078eb87ddd68c  vmovaps [rsp+0xC0], xmm12
000078eb87ddd695  vmovaps [rsp+0xD0], xmm13
000078eb87ddd69e  vmovaps [rsp+0xE0], xmm15
000078eb87ddd6a7  sub rsp, 0x30
000078eb87ddd6ab  movaps [rsp], xmm14
000078eb87ddd6b0  movaps [rsp+0x10], xmm4
000078eb87ddd6b5  movaps [rsp+0x20], xmm3
000078eb87ddd6ba  lea rdi, [rsp]
000078eb87ddd6be  mov esi, 0x00
000078eb87ddd6c3  mov rax, 0x61D341A71530
000078eb87ddd6cd  call rax
000078eb87ddd6cf  movaps xmm14, [rsp]
000078eb87ddd6d4  add rsp, 0x30
000078eb87ddd6d8  vmovaps xmm0, [rsp]
000078eb87ddd6dd  vmovaps xmm1, [rsp+0x10]
000078eb87ddd6e3  vmovaps xmm2, [rsp+0x20]
000078eb87ddd6e9  vmovaps xmm3, [rsp+0x30]
000078eb87ddd6ef  vmovaps xmm4, [rsp+0x40]
000078eb87ddd6f5  vmovaps xmm5, [rsp+0x50]
000078eb87ddd6fb  vmovaps xmm6, [rsp+0x60]
000078eb87ddd701  vmovaps xmm7, [rsp+0x70]
000078eb87ddd707  vmovaps xmm8, [rsp+0x80]
000078eb87ddd710  vmovaps xmm9, [rsp+0x90]
000078eb87ddd719  vmovaps xmm10, [rsp+0xA0]
000078eb87ddd722  vmovaps xmm11, [rsp+0xB0]
000078eb87ddd72b  vmovaps xmm12, [rsp+0xC0]
000078eb87ddd734  vmovaps xmm13, [rsp+0xD0]
000078eb87ddd73d  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd746  add rsp, 0xF0
000078eb87ddd74d  pop r11
000078eb87ddd74f  pop r10
000078eb87ddd751  pop r9
000078eb87ddd753  pop r8
000078eb87ddd755  pop rsi
000078eb87ddd756  pop rdi
000078eb87ddd757  pop rdx
000078eb87ddd758  pop rcx
000078eb87ddd759  pop rax
000078eb87ddd75a  add rsp, 0x08
000078eb87ddd75e  jmp 0x000078EB87DDBE42
000078eb87ddd763  sub rsp, 0x08
000078eb87ddd767  push rax
000078eb87ddd768  push rcx
000078eb87ddd769  push rdx
000078eb87ddd76a  push rdi
000078eb87ddd76b  push rsi
000078eb87ddd76c  push r8
000078eb87ddd76e  push r9
000078eb87ddd770  push r10
000078eb87ddd772  push r11
000078eb87ddd774  sub rsp, 0xF0
000078eb87ddd77b  vmovaps [rsp], xmm0
000078eb87ddd780  vmovaps [rsp+0x10], xmm1
000078eb87ddd786  vmovaps [rsp+0x20], xmm2
000078eb87ddd78c  vmovaps [rsp+0x30], xmm3
000078eb87ddd792  vmovaps [rsp+0x40], xmm4
000078eb87ddd798  vmovaps [rsp+0x50], xmm5
000078eb87ddd79e  vmovaps [rsp+0x60], xmm7
000078eb87ddd7a4  vmovaps [rsp+0x70], xmm8
000078eb87ddd7aa  vmovaps [rsp+0x80], xmm9
000078eb87ddd7b3  vmovaps [rsp+0x90], xmm10
000078eb87ddd7bc  vmovaps [rsp+0xA0], xmm11
000078eb87ddd7c5  vmovaps [rsp+0xB0], xmm12
000078eb87ddd7ce  vmovaps [rsp+0xC0], xmm13
000078eb87ddd7d7  vmovaps [rsp+0xD0], xmm14
000078eb87ddd7e0  vmovaps [rsp+0xE0], xmm15
000078eb87ddd7e9  sub rsp, 0x30
000078eb87ddd7ed  movaps [rsp], xmm6
000078eb87ddd7f1  movaps [rsp+0x10], xmm9
000078eb87ddd7f7  movaps [rsp+0x20], xmm7
000078eb87ddd7fc  lea rdi, [rsp]
000078eb87ddd800  mov esi, 0x00
000078eb87ddd805  mov rax, 0x61D341A71530
000078eb87ddd80f  call rax
000078eb87ddd811  movaps xmm6, [rsp]
000078eb87ddd815  add rsp, 0x30
000078eb87ddd819  vmovaps xmm0, [rsp]
000078eb87ddd81e  vmovaps xmm1, [rsp+0x10]
000078eb87ddd824  vmovaps xmm2, [rsp+0x20]
000078eb87ddd82a  vmovaps xmm3, [rsp+0x30]
000078eb87ddd830  vmovaps xmm4, [rsp+0x40]
000078eb87ddd836  vmovaps xmm5, [rsp+0x50]
000078eb87ddd83c  vmovaps xmm7, [rsp+0x60]
000078eb87ddd842  vmovaps xmm8, [rsp+0x70]
000078eb87ddd848  vmovaps xmm9, [rsp+0x80]
000078eb87ddd851  vmovaps xmm10, [rsp+0x90]
000078eb87ddd85a  vmovaps xmm11, [rsp+0xA0]
000078eb87ddd863  vmovaps xmm12, [rsp+0xB0]
000078eb87ddd86c  vmovaps xmm13, [rsp+0xC0]
000078eb87ddd875  vmovaps xmm14, [rsp+0xD0]
000078eb87ddd87e  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd887  add rsp, 0xF0
000078eb87ddd88e  pop r11
000078eb87ddd890  pop r10
000078eb87ddd892  pop r9
000078eb87ddd894  pop r8
000078eb87ddd896  pop rsi
000078eb87ddd897  pop rdi
000078eb87ddd898  pop rdx
000078eb87ddd899  pop rcx
000078eb87ddd89a  pop rax
000078eb87ddd89b  add rsp, 0x08
000078eb87ddd89f  jmp 0x000078EB87DDBE5A
000078eb87ddd8a4  sub rsp, 0x08
000078eb87ddd8a8  push rax
000078eb87ddd8a9  push rcx
000078eb87ddd8aa  push rdx
000078eb87ddd8ab  push rdi
000078eb87ddd8ac  push rsi
000078eb87ddd8ad  push r8
000078eb87ddd8af  push r9
000078eb87ddd8b1  push r10
000078eb87ddd8b3  push r11
000078eb87ddd8b5  sub rsp, 0xF0
000078eb87ddd8bc  vmovaps [rsp], xmm0
000078eb87ddd8c1  vmovaps [rsp+0x10], xmm1
000078eb87ddd8c7  vmovaps [rsp+0x20], xmm2
000078eb87ddd8cd  vmovaps [rsp+0x30], xmm3
000078eb87ddd8d3  vmovaps [rsp+0x40], xmm4
000078eb87ddd8d9  vmovaps [rsp+0x50], xmm5
000078eb87ddd8df  vmovaps [rsp+0x60], xmm6
000078eb87ddd8e5  vmovaps [rsp+0x70], xmm8
000078eb87ddd8eb  vmovaps [rsp+0x80], xmm9
000078eb87ddd8f4  vmovaps [rsp+0x90], xmm10
000078eb87ddd8fd  vmovaps [rsp+0xA0], xmm11
000078eb87ddd906  vmovaps [rsp+0xB0], xmm12
000078eb87ddd90f  vmovaps [rsp+0xC0], xmm13
000078eb87ddd918  vmovaps [rsp+0xD0], xmm14
000078eb87ddd921  vmovaps [rsp+0xE0], xmm15
000078eb87ddd92a  sub rsp, 0x30
000078eb87ddd92e  movaps [rsp], xmm7
000078eb87ddd932  movaps [rsp+0x10], xmm4
000078eb87ddd937  movaps [rsp+0x20], xmm9
000078eb87ddd93d  lea rdi, [rsp]
000078eb87ddd941  mov esi, 0x00
000078eb87ddd946  mov rax, 0x61D341A71530
000078eb87ddd950  call rax
000078eb87ddd952  movaps xmm7, [rsp]
000078eb87ddd956  add rsp, 0x30
000078eb87ddd95a  vmovaps xmm0, [rsp]
000078eb87ddd95f  vmovaps xmm1, [rsp+0x10]
000078eb87ddd965  vmovaps xmm2, [rsp+0x20]
000078eb87ddd96b  vmovaps xmm3, [rsp+0x30]
000078eb87ddd971  vmovaps xmm4, [rsp+0x40]
000078eb87ddd977  vmovaps xmm5, [rsp+0x50]
000078eb87ddd97d  vmovaps xmm6, [rsp+0x60]
000078eb87ddd983  vmovaps xmm8, [rsp+0x70]
000078eb87ddd989  vmovaps xmm9, [rsp+0x80]
000078eb87ddd992  vmovaps xmm10, [rsp+0x90]
000078eb87ddd99b  vmovaps xmm11, [rsp+0xA0]
000078eb87ddd9a4  vmovaps xmm12, [rsp+0xB0]
000078eb87ddd9ad  vmovaps xmm13, [rsp+0xC0]
000078eb87ddd9b6  vmovaps xmm14, [rsp+0xD0]
000078eb87ddd9bf  vmovaps xmm15, [rsp+0xE0]
000078eb87ddd9c8  add rsp, 0xF0
000078eb87ddd9cf  pop r11
000078eb87ddd9d1  pop r10
000078eb87ddd9d3  pop r9
000078eb87ddd9d5  pop r8
000078eb87ddd9d7  pop rsi
000078eb87ddd9d8  pop rdi
000078eb87ddd9d9  pop rdx
000078eb87ddd9da  pop rcx
000078eb87ddd9db  pop rax
000078eb87ddd9dc  add rsp, 0x08
000078eb87ddd9e0  jmp 0x000078EB87DDBE87
000078eb87ddd9e5  sub rsp, 0x08
000078eb87ddd9e9  push rax
000078eb87ddd9ea  push rcx
000078eb87ddd9eb  push rdx
000078eb87ddd9ec  push rdi
000078eb87ddd9ed  push rsi
000078eb87ddd9ee  push r8
000078eb87ddd9f0  push r9
000078eb87ddd9f2  push r10
000078eb87ddd9f4  push r11
000078eb87ddd9f6  sub rsp, 0xF0
000078eb87ddd9fd  vmovaps [rsp], xmm0
000078eb87ddda02  vmovaps [rsp+0x10], xmm1
000078eb87ddda08  vmovaps [rsp+0x20], xmm2
000078eb87ddda0e  vmovaps [rsp+0x30], xmm3
000078eb87ddda14  vmovaps [rsp+0x40], xmm5
000078eb87ddda1a  vmovaps [rsp+0x50], xmm6
000078eb87ddda20  vmovaps [rsp+0x60], xmm7
000078eb87ddda26  vmovaps [rsp+0x70], xmm8
000078eb87ddda2c  vmovaps [rsp+0x80], xmm9
000078eb87ddda35  vmovaps [rsp+0x90], xmm10
000078eb87ddda3e  vmovaps [rsp+0xA0], xmm11
000078eb87ddda47  vmovaps [rsp+0xB0], xmm12
000078eb87ddda50  vmovaps [rsp+0xC0], xmm13
000078eb87ddda59  vmovaps [rsp+0xD0], xmm14
000078eb87ddda62  vmovaps [rsp+0xE0], xmm15
000078eb87ddda6b  sub rsp, 0x30
000078eb87ddda6f  movaps [rsp], xmm4
000078eb87ddda73  movaps [rsp+0x10], xmm15
000078eb87ddda79  movaps [rsp+0x20], xmm9
000078eb87ddda7f  lea rdi, [rsp]
000078eb87ddda83  mov esi, 0x00
000078eb87ddda88  mov rax, 0x61D341A71530
000078eb87ddda92  call rax
000078eb87ddda94  movaps xmm4, [rsp]
000078eb87ddda98  add rsp, 0x30
000078eb87ddda9c  vmovaps xmm0, [rsp]
000078eb87dddaa1  vmovaps xmm1, [rsp+0x10]
000078eb87dddaa7  vmovaps xmm2, [rsp+0x20]
000078eb87dddaad  vmovaps xmm3, [rsp+0x30]
000078eb87dddab3  vmovaps xmm5, [rsp+0x40]
000078eb87dddab9  vmovaps xmm6, [rsp+0x50]
000078eb87dddabf  vmovaps xmm7, [rsp+0x60]
000078eb87dddac5  vmovaps xmm8, [rsp+0x70]
000078eb87dddacb  vmovaps xmm9, [rsp+0x80]
000078eb87dddad4  vmovaps xmm10, [rsp+0x90]
000078eb87dddadd  vmovaps xmm11, [rsp+0xA0]
000078eb87dddae6  vmovaps xmm12, [rsp+0xB0]
000078eb87dddaef  vmovaps xmm13, [rsp+0xC0]
000078eb87dddaf8  vmovaps xmm14, [rsp+0xD0]
000078eb87dddb01  vmovaps xmm15, [rsp+0xE0]
000078eb87dddb0a  add rsp, 0xF0
000078eb87dddb11  pop r11
000078eb87dddb13  pop r10
000078eb87dddb15  pop r9
000078eb87dddb17  pop r8
000078eb87dddb19  pop rsi
000078eb87dddb1a  pop rdi
000078eb87dddb1b  pop rdx
000078eb87dddb1c  pop rcx
000078eb87dddb1d  pop rax
000078eb87dddb1e  add rsp, 0x08
000078eb87dddb22  jmp 0x000078EB87DDBEAC
000078eb87dddb27  call 0x000078EB87CC4620
000078eb87dddb2c  jmp 0x000078EB87DDBEB9
000078eb87dddb31  sub rsp, 0x08
000078eb87dddb35  push rax
000078eb87dddb36  push rcx
000078eb87dddb37  push rdx
000078eb87dddb38  push rdi
000078eb87dddb39  push rsi
000078eb87dddb3a  push r8
000078eb87dddb3c  push r9
000078eb87dddb3e  push r10
000078eb87dddb40  push r11
000078eb87dddb42  sub rsp, 0xF0
000078eb87dddb49  vmovaps [rsp], xmm0
000078eb87dddb4e  vmovaps [rsp+0x10], xmm1
000078eb87dddb54  vmovaps [rsp+0x20], xmm2
000078eb87dddb5a  vmovaps [rsp+0x30], xmm4
000078eb87dddb60  vmovaps [rsp+0x40], xmm5
000078eb87dddb66  vmovaps [rsp+0x50], xmm6
000078eb87dddb6c  vmovaps [rsp+0x60], xmm7
000078eb87dddb72  vmovaps [rsp+0x70], xmm8
000078eb87dddb78  vmovaps [rsp+0x80], xmm9
000078eb87dddb81  vmovaps [rsp+0x90], xmm10
000078eb87dddb8a  vmovaps [rsp+0xA0], xmm11
000078eb87dddb93  vmovaps [rsp+0xB0], xmm12
000078eb87dddb9c  vmovaps [rsp+0xC0], xmm13
000078eb87dddba5  vmovaps [rsp+0xD0], xmm14
000078eb87dddbae  vmovaps [rsp+0xE0], xmm15
000078eb87dddbb7  sub rsp, 0x30
000078eb87dddbbb  movaps [rsp], xmm3
000078eb87dddbbf  movaps [rsp+0x10], xmm1
000078eb87dddbc4  movaps [rsp+0x20], xmm9
000078eb87dddbca  lea rdi, [rsp]
000078eb87dddbce  mov esi, 0x00
000078eb87dddbd3  mov rax, 0x61D341A71530
000078eb87dddbdd  call rax
000078eb87dddbdf  movaps xmm3, [rsp]
000078eb87dddbe3  add rsp, 0x30
000078eb87dddbe7  vmovaps xmm0, [rsp]
000078eb87dddbec  vmovaps xmm1, [rsp+0x10]
000078eb87dddbf2  vmovaps xmm2, [rsp+0x20]
000078eb87dddbf8  vmovaps xmm4, [rsp+0x30]
000078eb87dddbfe  vmovaps xmm5, [rsp+0x40]
000078eb87dddc04  vmovaps xmm6, [rsp+0x50]
000078eb87dddc0a  vmovaps xmm7, [rsp+0x60]
000078eb87dddc10  vmovaps xmm8, [rsp+0x70]
000078eb87dddc16  vmovaps xmm9, [rsp+0x80]
000078eb87dddc1f  vmovaps xmm10, [rsp+0x90]
000078eb87dddc28  vmovaps xmm11, [rsp+0xA0]
000078eb87dddc31  vmovaps xmm12, [rsp+0xB0]
000078eb87dddc3a  vmovaps xmm13, [rsp+0xC0]
000078eb87dddc43  vmovaps xmm14, [rsp+0xD0]
000078eb87dddc4c  vmovaps xmm15, [rsp+0xE0]
000078eb87dddc55  add rsp, 0xF0
000078eb87dddc5c  pop r11
000078eb87dddc5e  pop r10
000078eb87dddc60  pop r9
000078eb87dddc62  pop r8
000078eb87dddc64  pop rsi
000078eb87dddc65  pop rdi
000078eb87dddc66  pop rdx
000078eb87dddc67  pop rcx
000078eb87dddc68  pop rax
000078eb87dddc69  add rsp, 0x08
000078eb87dddc6d  jmp 0x000078EB87DDBEF6
000078eb87dddc72  sub rsp, 0x08
000078eb87dddc76  push rax
000078eb87dddc77  push rcx
000078eb87dddc78  push rdx
000078eb87dddc79  push rdi
000078eb87dddc7a  push rsi
000078eb87dddc7b  push r8
000078eb87dddc7d  push r9
000078eb87dddc7f  push r10
000078eb87dddc81  push r11
000078eb87dddc83  sub rsp, 0xF0
000078eb87dddc8a  vmovaps [rsp], xmm0
000078eb87dddc8f  vmovaps [rsp+0x10], xmm2
000078eb87dddc95  vmovaps [rsp+0x20], xmm3
000078eb87dddc9b  vmovaps [rsp+0x30], xmm4
000078eb87dddca1  vmovaps [rsp+0x40], xmm5
000078eb87dddca7  vmovaps [rsp+0x50], xmm6
000078eb87dddcad  vmovaps [rsp+0x60], xmm7
000078eb87dddcb3  vmovaps [rsp+0x70], xmm8
000078eb87dddcb9  vmovaps [rsp+0x80], xmm9
000078eb87dddcc2  vmovaps [rsp+0x90], xmm10
000078eb87dddccb  vmovaps [rsp+0xA0], xmm11
000078eb87dddcd4  vmovaps [rsp+0xB0], xmm12
000078eb87dddcdd  vmovaps [rsp+0xC0], xmm13
000078eb87dddce6  vmovaps [rsp+0xD0], xmm14
000078eb87dddcef  vmovaps [rsp+0xE0], xmm15
000078eb87dddcf8  sub rsp, 0x30
000078eb87dddcfc  movaps [rsp], xmm1
000078eb87dddd00  movaps [rsp+0x10], xmm15
000078eb87dddd06  movaps [rsp+0x20], xmm9
000078eb87dddd0c  lea rdi, [rsp]
000078eb87dddd10  mov esi, 0x00
000078eb87dddd15  mov rax, 0x61D341A71530
000078eb87dddd1f  call rax
000078eb87dddd21  movaps xmm1, [rsp]
000078eb87dddd25  add rsp, 0x30
000078eb87dddd29  vmovaps xmm0, [rsp]
000078eb87dddd2e  vmovaps xmm2, [rsp+0x10]
000078eb87dddd34  vmovaps xmm3, [rsp+0x20]
000078eb87dddd3a  vmovaps xmm4, [rsp+0x30]
000078eb87dddd40  vmovaps xmm5, [rsp+0x40]
000078eb87dddd46  vmovaps xmm6, [rsp+0x50]
000078eb87dddd4c  vmovaps xmm7, [rsp+0x60]
000078eb87dddd52  vmovaps xmm8, [rsp+0x70]
000078eb87dddd58  vmovaps xmm9, [rsp+0x80]
000078eb87dddd61  vmovaps xmm10, [rsp+0x90]
000078eb87dddd6a  vmovaps xmm11, [rsp+0xA0]
000078eb87dddd73  vmovaps xmm12, [rsp+0xB0]
000078eb87dddd7c  vmovaps xmm13, [rsp+0xC0]
000078eb87dddd85  vmovaps xmm14, [rsp+0xD0]
000078eb87dddd8e  vmovaps xmm15, [rsp+0xE0]
000078eb87dddd97  add rsp, 0xF0
000078eb87dddd9e  pop r11
000078eb87dddda0  pop r10
000078eb87dddda2  pop r9
000078eb87dddda4  pop r8
000078eb87dddda6  pop rsi
000078eb87dddda7  pop rdi
000078eb87dddda8  pop rdx
000078eb87dddda9  pop rcx
000078eb87ddddaa  pop rax
000078eb87ddddab  add rsp, 0x08
000078eb87ddddaf  jmp 0x000078EB87DDBF7E
000078eb87ddddb4  call 0x000078EB87CC4620
000078eb87ddddb9  jmp 0x000078EB87DDBF8B
000078eb87ddddbe  sub rsp, 0x08
000078eb87ddddc2  push rax
000078eb87ddddc3  push rcx
000078eb87ddddc4  push rdx
000078eb87ddddc5  push rdi
000078eb87ddddc6  push rsi
000078eb87ddddc7  push r8
000078eb87ddddc9  push r9
000078eb87ddddcb  push r10
000078eb87ddddcd  push r11
000078eb87ddddcf  sub rsp, 0xF0
000078eb87ddddd6  vmovaps [rsp], xmm0
000078eb87dddddb  vmovaps [rsp+0x10], xmm2
000078eb87dddde1  vmovaps [rsp+0x20], xmm3
000078eb87dddde7  vmovaps [rsp+0x30], xmm4
000078eb87dddded  vmovaps [rsp+0x40], xmm5
000078eb87ddddf3  vmovaps [rsp+0x50], xmm6
000078eb87ddddf9  vmovaps [rsp+0x60], xmm7
000078eb87ddddff  vmovaps [rsp+0x70], xmm8
000078eb87ddde05  vmovaps [rsp+0x80], xmm9
000078eb87ddde0e  vmovaps [rsp+0x90], xmm10
000078eb87ddde17  vmovaps [rsp+0xA0], xmm11
000078eb87ddde20  vmovaps [rsp+0xB0], xmm12
000078eb87ddde29  vmovaps [rsp+0xC0], xmm13
000078eb87ddde32  vmovaps [rsp+0xD0], xmm14
000078eb87ddde3b  vmovaps [rsp+0xE0], xmm15
000078eb87ddde44  sub rsp, 0x30
000078eb87ddde48  movaps [rsp], xmm1
000078eb87ddde4c  movaps [rsp+0x10], xmm5
000078eb87ddde51  movaps [rsp+0x20], xmm7
000078eb87ddde56  lea rdi, [rsp]
000078eb87ddde5a  mov esi, 0x00
000078eb87ddde5f  mov rax, 0x61D341A71530
000078eb87ddde69  call rax
000078eb87ddde6b  movaps xmm1, [rsp]
000078eb87ddde6f  add rsp, 0x30
000078eb87ddde73  vmovaps xmm0, [rsp]
000078eb87ddde78  vmovaps xmm2, [rsp+0x10]
000078eb87ddde7e  vmovaps xmm3, [rsp+0x20]
000078eb87ddde84  vmovaps xmm4, [rsp+0x30]
000078eb87ddde8a  vmovaps xmm5, [rsp+0x40]
000078eb87ddde90  vmovaps xmm6, [rsp+0x50]
000078eb87ddde96  vmovaps xmm7, [rsp+0x60]
000078eb87ddde9c  vmovaps xmm8, [rsp+0x70]
000078eb87dddea2  vmovaps xmm9, [rsp+0x80]
000078eb87dddeab  vmovaps xmm10, [rsp+0x90]
000078eb87dddeb4  vmovaps xmm11, [rsp+0xA0]
000078eb87dddebd  vmovaps xmm12, [rsp+0xB0]
000078eb87dddec6  vmovaps xmm13, [rsp+0xC0]
000078eb87dddecf  vmovaps xmm14, [rsp+0xD0]
000078eb87ddded8  vmovaps xmm15, [rsp+0xE0]
000078eb87dddee1  add rsp, 0xF0
000078eb87dddee8  pop r11
000078eb87dddeea  pop r10
000078eb87dddeec  pop r9
000078eb87dddeee  pop r8
000078eb87dddef0  pop rsi
000078eb87dddef1  pop rdi
000078eb87dddef2  pop rdx
000078eb87dddef3  pop rcx
000078eb87dddef4  pop rax
000078eb87dddef5  add rsp, 0x08
000078eb87dddef9  jmp 0x000078EB87DDC030
000078eb87dddefe  sub rsp, 0x08
000078eb87dddf02  push rax
000078eb87dddf03  push rcx
000078eb87dddf04  push rdx
000078eb87dddf05  push rdi
000078eb87dddf06  push rsi
000078eb87dddf07  push r8
000078eb87dddf09  push r9
000078eb87dddf0b  push r10
000078eb87dddf0d  push r11
000078eb87dddf0f  sub rsp, 0xF0
000078eb87dddf16  vmovaps [rsp], xmm0
000078eb87dddf1b  vmovaps [rsp+0x10], xmm1
000078eb87dddf21  vmovaps [rsp+0x20], xmm2
000078eb87dddf27  vmovaps [rsp+0x30], xmm3
000078eb87dddf2d  vmovaps [rsp+0x40], xmm4
000078eb87dddf33  vmovaps [rsp+0x50], xmm5
000078eb87dddf39  vmovaps [rsp+0x60], xmm6
000078eb87dddf3f  vmovaps [rsp+0x70], xmm8
000078eb87dddf45  vmovaps [rsp+0x80], xmm9
000078eb87dddf4e  vmovaps [rsp+0x90], xmm10
000078eb87dddf57  vmovaps [rsp+0xA0], xmm11
000078eb87dddf60  vmovaps [rsp+0xB0], xmm12
000078eb87dddf69  vmovaps [rsp+0xC0], xmm13
000078eb87dddf72  vmovaps [rsp+0xD0], xmm14
000078eb87dddf7b  vmovaps [rsp+0xE0], xmm15
000078eb87dddf84  sub rsp, 0x30
000078eb87dddf88  movaps [rsp], xmm7
000078eb87dddf8c  movaps [rsp+0x10], xmm5
000078eb87dddf91  movaps [rsp+0x20], xmm15
000078eb87dddf97  lea rdi, [rsp]
000078eb87dddf9b  mov esi, 0x00
000078eb87dddfa0  mov rax, 0x61D341A71530
000078eb87dddfaa  call rax
000078eb87dddfac  movaps xmm7, [rsp]
000078eb87dddfb0  add rsp, 0x30
000078eb87dddfb4  vmovaps xmm0, [rsp]
000078eb87dddfb9  vmovaps xmm1, [rsp+0x10]
000078eb87dddfbf  vmovaps xmm2, [rsp+0x20]
000078eb87dddfc5  vmovaps xmm3, [rsp+0x30]
000078eb87dddfcb  vmovaps xmm4, [rsp+0x40]
000078eb87dddfd1  vmovaps xmm5, [rsp+0x50]
000078eb87dddfd7  vmovaps xmm6, [rsp+0x60]
000078eb87dddfdd  vmovaps xmm8, [rsp+0x70]
000078eb87dddfe3  vmovaps xmm9, [rsp+0x80]
000078eb87dddfec  vmovaps xmm10, [rsp+0x90]
000078eb87dddff5  vmovaps xmm11, [rsp+0xA0]
000078eb87dddffe  vmovaps xmm12, [rsp+0xB0]
000078eb87dde007  vmovaps xmm13, [rsp+0xC0]
000078eb87dde010  vmovaps xmm14, [rsp+0xD0]
000078eb87dde019  vmovaps xmm15, [rsp+0xE0]
000078eb87dde022  add rsp, 0xF0
000078eb87dde029  pop r11
000078eb87dde02b  pop r10
000078eb87dde02d  pop r9
000078eb87dde02f  pop r8
000078eb87dde031  pop rsi
000078eb87dde032  pop rdi
000078eb87dde033  pop rdx
000078eb87dde034  pop rcx
000078eb87dde035  pop rax
000078eb87dde036  add rsp, 0x08
000078eb87dde03a  jmp 0x000078EB87DDC066
000078eb87dde03f  call 0x000078EB87CB52F0
000078eb87dde044  jmp 0x000078EB87DDC073
000078eb87dde049  sub rsp, 0x08
000078eb87dde04d  push rax
000078eb87dde04e  push rcx
000078eb87dde04f  push rdx
000078eb87dde050  push rdi
000078eb87dde051  push rsi
000078eb87dde052  push r8
000078eb87dde054  push r9
000078eb87dde056  push r10
000078eb87dde058  push r11
000078eb87dde05a  sub rsp, 0xF0
000078eb87dde061  vmovaps [rsp], xmm0
000078eb87dde066  vmovaps [rsp+0x10], xmm1
000078eb87dde06c  vmovaps [rsp+0x20], xmm2
000078eb87dde072  vmovaps [rsp+0x30], xmm3
000078eb87dde078  vmovaps [rsp+0x40], xmm4
000078eb87dde07e  vmovaps [rsp+0x50], xmm5
000078eb87dde084  vmovaps [rsp+0x60], xmm6
000078eb87dde08a  vmovaps [rsp+0x70], xmm7
000078eb87dde090  vmovaps [rsp+0x80], xmm8
000078eb87dde099  vmovaps [rsp+0x90], xmm9
000078eb87dde0a2  vmovaps [rsp+0xA0], xmm10
000078eb87dde0ab  vmovaps [rsp+0xB0], xmm11
000078eb87dde0b4  vmovaps [rsp+0xC0], xmm12
000078eb87dde0bd  vmovaps [rsp+0xD0], xmm13
000078eb87dde0c6  vmovaps [rsp+0xE0], xmm14
000078eb87dde0cf  sub rsp, 0x30
000078eb87dde0d3  movaps [rsp], xmm15
000078eb87dde0d8  movaps [rsp+0x10], xmm5
000078eb87dde0dd  movaps [rsp+0x20], xmm3
000078eb87dde0e2  lea rdi, [rsp]
000078eb87dde0e6  mov esi, 0x00
000078eb87dde0eb  mov rax, 0x61D341A71530
000078eb87dde0f5  call rax
000078eb87dde0f7  movaps xmm15, [rsp]
000078eb87dde0fc  add rsp, 0x30
000078eb87dde100  vmovaps xmm0, [rsp]
000078eb87dde105  vmovaps xmm1, [rsp+0x10]
000078eb87dde10b  vmovaps xmm2, [rsp+0x20]
000078eb87dde111  vmovaps xmm3, [rsp+0x30]
000078eb87dde117  vmovaps xmm4, [rsp+0x40]
000078eb87dde11d  vmovaps xmm5, [rsp+0x50]
000078eb87dde123  vmovaps xmm6, [rsp+0x60]
000078eb87dde129  vmovaps xmm7, [rsp+0x70]
000078eb87dde12f  vmovaps xmm8, [rsp+0x80]
000078eb87dde138  vmovaps xmm9, [rsp+0x90]
000078eb87dde141  vmovaps xmm10, [rsp+0xA0]
000078eb87dde14a  vmovaps xmm11, [rsp+0xB0]
000078eb87dde153  vmovaps xmm12, [rsp+0xC0]
000078eb87dde15c  vmovaps xmm13, [rsp+0xD0]
000078eb87dde165  vmovaps xmm14, [rsp+0xE0]
000078eb87dde16e  add rsp, 0xF0
000078eb87dde175  pop r11
000078eb87dde177  pop r10
000078eb87dde179  pop r9
000078eb87dde17b  pop r8
000078eb87dde17d  pop rsi
000078eb87dde17e  pop rdi
000078eb87dde17f  pop rdx
000078eb87dde180  pop rcx
000078eb87dde181  pop rax
000078eb87dde182  add rsp, 0x08
000078eb87dde186  jmp 0x000078EB87DDC099
000078eb87dde18b  sub rsp, 0x08
000078eb87dde18f  push rax
000078eb87dde190  push rcx
000078eb87dde191  push rdx
000078eb87dde192  push rdi
000078eb87dde193  push rsi
000078eb87dde194  push r8
000078eb87dde196  push r9
000078eb87dde198  push r10
000078eb87dde19a  push r11
000078eb87dde19c  sub rsp, 0xF0
000078eb87dde1a3  vmovaps [rsp], xmm0
000078eb87dde1a8  vmovaps [rsp+0x10], xmm2
000078eb87dde1ae  vmovaps [rsp+0x20], xmm3
000078eb87dde1b4  vmovaps [rsp+0x30], xmm4
000078eb87dde1ba  vmovaps [rsp+0x40], xmm5
000078eb87dde1c0  vmovaps [rsp+0x50], xmm6
000078eb87dde1c6  vmovaps [rsp+0x60], xmm7
000078eb87dde1cc  vmovaps [rsp+0x70], xmm8
000078eb87dde1d2  vmovaps [rsp+0x80], xmm9
000078eb87dde1db  vmovaps [rsp+0x90], xmm10
000078eb87dde1e4  vmovaps [rsp+0xA0], xmm11
000078eb87dde1ed  vmovaps [rsp+0xB0], xmm12
000078eb87dde1f6  vmovaps [rsp+0xC0], xmm13
000078eb87dde1ff  vmovaps [rsp+0xD0], xmm14
000078eb87dde208  vmovaps [rsp+0xE0], xmm15
000078eb87dde211  sub rsp, 0x30
000078eb87dde215  movaps [rsp], xmm1
000078eb87dde219  movaps [rsp+0x10], xmm5
000078eb87dde21e  movaps [rsp+0x20], xmm4
000078eb87dde223  lea rdi, [rsp]
000078eb87dde227  mov esi, 0x00
000078eb87dde22c  mov rax, 0x61D341A71530
000078eb87dde236  call rax
000078eb87dde238  movaps xmm1, [rsp]
000078eb87dde23c  add rsp, 0x30
000078eb87dde240  vmovaps xmm0, [rsp]
000078eb87dde245  vmovaps xmm2, [rsp+0x10]
000078eb87dde24b  vmovaps xmm3, [rsp+0x20]
000078eb87dde251  vmovaps xmm4, [rsp+0x30]
000078eb87dde257  vmovaps xmm5, [rsp+0x40]
000078eb87dde25d  vmovaps xmm6, [rsp+0x50]
000078eb87dde263  vmovaps xmm7, [rsp+0x60]
000078eb87dde269  vmovaps xmm8, [rsp+0x70]
000078eb87dde26f  vmovaps xmm9, [rsp+0x80]
000078eb87dde278  vmovaps xmm10, [rsp+0x90]
000078eb87dde281  vmovaps xmm11, [rsp+0xA0]
000078eb87dde28a  vmovaps xmm12, [rsp+0xB0]
000078eb87dde293  vmovaps xmm13, [rsp+0xC0]
000078eb87dde29c  vmovaps xmm14, [rsp+0xD0]
000078eb87dde2a5  vmovaps xmm15, [rsp+0xE0]
000078eb87dde2ae  add rsp, 0xF0
000078eb87dde2b5  pop r11
000078eb87dde2b7  pop r10
000078eb87dde2b9  pop r9
000078eb87dde2bb  pop r8
000078eb87dde2bd  pop rsi
000078eb87dde2be  pop rdi
000078eb87dde2bf  pop rdx
000078eb87dde2c0  pop rcx
000078eb87dde2c1  pop rax
000078eb87dde2c2  add rsp, 0x08
000078eb87dde2c6  jmp 0x000078EB87DDC0B9
000078eb87dde2cb  sub rsp, 0x08
000078eb87dde2cf  push rax
000078eb87dde2d0  push rcx
000078eb87dde2d1  push rdx
000078eb87dde2d2  push rdi
000078eb87dde2d3  push rsi
000078eb87dde2d4  push r8
000078eb87dde2d6  push r9
000078eb87dde2d8  push r10
000078eb87dde2da  push r11
000078eb87dde2dc  sub rsp, 0xF0
000078eb87dde2e3  vmovaps [rsp], xmm0
000078eb87dde2e8  vmovaps [rsp+0x10], xmm1
000078eb87dde2ee  vmovaps [rsp+0x20], xmm2
000078eb87dde2f4  vmovaps [rsp+0x30], xmm3
000078eb87dde2fa  vmovaps [rsp+0x40], xmm5
000078eb87dde300  vmovaps [rsp+0x50], xmm6
000078eb87dde306  vmovaps [rsp+0x60], xmm7
000078eb87dde30c  vmovaps [rsp+0x70], xmm8
000078eb87dde312  vmovaps [rsp+0x80], xmm9
000078eb87dde31b  vmovaps [rsp+0x90], xmm10
000078eb87dde324  vmovaps [rsp+0xA0], xmm11
000078eb87dde32d  vmovaps [rsp+0xB0], xmm12
000078eb87dde336  vmovaps [rsp+0xC0], xmm13
000078eb87dde33f  vmovaps [rsp+0xD0], xmm14
000078eb87dde348  vmovaps [rsp+0xE0], xmm15
000078eb87dde351  sub rsp, 0x30
000078eb87dde355  movaps [rsp], xmm4
000078eb87dde359  movaps [rsp+0x10], xmm3
000078eb87dde35e  movaps [rsp+0x20], xmm5
000078eb87dde363  lea rdi, [rsp]
000078eb87dde367  mov esi, 0x00
000078eb87dde36c  mov rax, 0x61D341A71530
000078eb87dde376  call rax
000078eb87dde378  movaps xmm4, [rsp]
000078eb87dde37c  add rsp, 0x30
000078eb87dde380  vmovaps xmm0, [rsp]
000078eb87dde385  vmovaps xmm1, [rsp+0x10]
000078eb87dde38b  vmovaps xmm2, [rsp+0x20]
000078eb87dde391  vmovaps xmm3, [rsp+0x30]
000078eb87dde397  vmovaps xmm5, [rsp+0x40]
000078eb87dde39d  vmovaps xmm6, [rsp+0x50]
000078eb87dde3a3  vmovaps xmm7, [rsp+0x60]
000078eb87dde3a9  vmovaps xmm8, [rsp+0x70]
000078eb87dde3af  vmovaps xmm9, [rsp+0x80]
000078eb87dde3b8  vmovaps xmm10, [rsp+0x90]
000078eb87dde3c1  vmovaps xmm11, [rsp+0xA0]
000078eb87dde3ca  vmovaps xmm12, [rsp+0xB0]
000078eb87dde3d3  vmovaps xmm13, [rsp+0xC0]
000078eb87dde3dc  vmovaps xmm14, [rsp+0xD0]
000078eb87dde3e5  vmovaps xmm15, [rsp+0xE0]
000078eb87dde3ee  add rsp, 0xF0
000078eb87dde3f5  pop r11
000078eb87dde3f7  pop r10
000078eb87dde3f9  pop r9
000078eb87dde3fb  pop r8
000078eb87dde3fd  pop rsi
000078eb87dde3fe  pop rdi
000078eb87dde3ff  pop rdx
000078eb87dde400  pop rcx
000078eb87dde401  pop rax
000078eb87dde402  add rsp, 0x08
000078eb87dde406  jmp 0x000078EB87DDC107
000078eb87dde40b  call 0x000078EB87CB52F0
000078eb87dde410  jmp 0x000078EB87DDC114
000078eb87dde415  sub rsp, 0x08
000078eb87dde419  push rax
000078eb87dde41a  push rcx
000078eb87dde41b  push rdx
000078eb87dde41c  push rdi
000078eb87dde41d  push rsi
000078eb87dde41e  push r8
000078eb87dde420  push r9
000078eb87dde422  push r10
000078eb87dde424  push r11
000078eb87dde426  sub rsp, 0xF0
000078eb87dde42d  vmovaps [rsp], xmm0
000078eb87dde432  vmovaps [rsp+0x10], xmm1
000078eb87dde438  vmovaps [rsp+0x20], xmm2
000078eb87dde43e  vmovaps [rsp+0x30], xmm3
000078eb87dde444  vmovaps [rsp+0x40], xmm4
000078eb87dde44a  vmovaps [rsp+0x50], xmm6
000078eb87dde450  vmovaps [rsp+0x60], xmm7
000078eb87dde456  vmovaps [rsp+0x70], xmm8
000078eb87dde45c  vmovaps [rsp+0x80], xmm9
000078eb87dde465  vmovaps [rsp+0x90], xmm10
000078eb87dde46e  vmovaps [rsp+0xA0], xmm11
000078eb87dde477  vmovaps [rsp+0xB0], xmm12
000078eb87dde480  vmovaps [rsp+0xC0], xmm13
000078eb87dde489  vmovaps [rsp+0xD0], xmm14
000078eb87dde492  vmovaps [rsp+0xE0], xmm15
000078eb87dde49b  sub rsp, 0x30
000078eb87dde49f  movaps [rsp], xmm5
000078eb87dde4a3  movaps [rsp+0x10], xmm6
000078eb87dde4a8  movaps [rsp+0x20], xmm3
000078eb87dde4ad  lea rdi, [rsp]
000078eb87dde4b1  mov esi, 0x00
000078eb87dde4b6  mov rax, 0x61D341A71530
000078eb87dde4c0  call rax
000078eb87dde4c2  movaps xmm5, [rsp]
000078eb87dde4c6  add rsp, 0x30
000078eb87dde4ca  vmovaps xmm0, [rsp]
000078eb87dde4cf  vmovaps xmm1, [rsp+0x10]
000078eb87dde4d5  vmovaps xmm2, [rsp+0x20]
000078eb87dde4db  vmovaps xmm3, [rsp+0x30]
000078eb87dde4e1  vmovaps xmm4, [rsp+0x40]
000078eb87dde4e7  vmovaps xmm6, [rsp+0x50]
000078eb87dde4ed  vmovaps xmm7, [rsp+0x60]
000078eb87dde4f3  vmovaps xmm8, [rsp+0x70]
000078eb87dde4f9  vmovaps xmm9, [rsp+0x80]
000078eb87dde502  vmovaps xmm10, [rsp+0x90]
000078eb87dde50b  vmovaps xmm11, [rsp+0xA0]
000078eb87dde514  vmovaps xmm12, [rsp+0xB0]
000078eb87dde51d  vmovaps xmm13, [rsp+0xC0]
000078eb87dde526  vmovaps xmm14, [rsp+0xD0]
000078eb87dde52f  vmovaps xmm15, [rsp+0xE0]
000078eb87dde538  add rsp, 0xF0
000078eb87dde53f  pop r11
000078eb87dde541  pop r10
000078eb87dde543  pop r9
000078eb87dde545  pop r8
000078eb87dde547  pop rsi
000078eb87dde548  pop rdi
000078eb87dde549  pop rdx
000078eb87dde54a  pop rcx
000078eb87dde54b  pop rax
000078eb87dde54c  add rsp, 0x08
000078eb87dde550  jmp 0x000078EB87DDC13A
000078eb87dde555  sub rsp, 0x08
000078eb87dde559  push rax
000078eb87dde55a  push rcx
000078eb87dde55b  push rdx
000078eb87dde55c  push rdi
000078eb87dde55d  push rsi
000078eb87dde55e  push r8
000078eb87dde560  push r9
000078eb87dde562  push r10
000078eb87dde564  push r11
000078eb87dde566  sub rsp, 0xF0
000078eb87dde56d  vmovaps [rsp], xmm0
000078eb87dde572  vmovaps [rsp+0x10], xmm1
000078eb87dde578  vmovaps [rsp+0x20], xmm2
000078eb87dde57e  vmovaps [rsp+0x30], xmm3
000078eb87dde584  vmovaps [rsp+0x40], xmm4
000078eb87dde58a  vmovaps [rsp+0x50], xmm5
000078eb87dde590  vmovaps [rsp+0x60], xmm7
000078eb87dde596  vmovaps [rsp+0x70], xmm8
000078eb87dde59c  vmovaps [rsp+0x80], xmm9
000078eb87dde5a5  vmovaps [rsp+0x90], xmm10
000078eb87dde5ae  vmovaps [rsp+0xA0], xmm11
000078eb87dde5b7  vmovaps [rsp+0xB0], xmm12
000078eb87dde5c0  vmovaps [rsp+0xC0], xmm13
000078eb87dde5c9  vmovaps [rsp+0xD0], xmm14
000078eb87dde5d2  vmovaps [rsp+0xE0], xmm15
000078eb87dde5db  sub rsp, 0x30
000078eb87dde5df  movaps [rsp], xmm6
000078eb87dde5e3  movaps [rsp+0x10], xmm9
000078eb87dde5e9  movaps [rsp+0x20], xmm1
000078eb87dde5ee  lea rdi, [rsp]
000078eb87dde5f2  mov esi, 0x00
000078eb87dde5f7  mov rax, 0x61D341A71530
000078eb87dde601  call rax
000078eb87dde603  movaps xmm6, [rsp]
000078eb87dde607  add rsp, 0x30
000078eb87dde60b  vmovaps xmm0, [rsp]
000078eb87dde610  vmovaps xmm1, [rsp+0x10]
000078eb87dde616  vmovaps xmm2, [rsp+0x20]
000078eb87dde61c  vmovaps xmm3, [rsp+0x30]
000078eb87dde622  vmovaps xmm4, [rsp+0x40]
000078eb87dde628  vmovaps xmm5, [rsp+0x50]
000078eb87dde62e  vmovaps xmm7, [rsp+0x60]
000078eb87dde634  vmovaps xmm8, [rsp+0x70]
000078eb87dde63a  vmovaps xmm9, [rsp+0x80]
000078eb87dde643  vmovaps xmm10, [rsp+0x90]
000078eb87dde64c  vmovaps xmm11, [rsp+0xA0]
000078eb87dde655  vmovaps xmm12, [rsp+0xB0]
000078eb87dde65e  vmovaps xmm13, [rsp+0xC0]
000078eb87dde667  vmovaps xmm14, [rsp+0xD0]
000078eb87dde670  vmovaps xmm15, [rsp+0xE0]
000078eb87dde679  add rsp, 0xF0
000078eb87dde680  pop r11
000078eb87dde682  pop r10
000078eb87dde684  pop r9
000078eb87dde686  pop r8
000078eb87dde688  pop rsi
000078eb87dde689  pop rdi
000078eb87dde68a  pop rdx
000078eb87dde68b  pop rcx
000078eb87dde68c  pop rax
000078eb87dde68d  add rsp, 0x08
000078eb87dde691  jmp 0x000078EB87DDC15E
000078eb87dde696  sub rsp, 0x08
000078eb87dde69a  push rax
000078eb87dde69b  push rcx
000078eb87dde69c  push rdx
000078eb87dde69d  push rdi
000078eb87dde69e  push rsi
000078eb87dde69f  push r8
000078eb87dde6a1  push r9
000078eb87dde6a3  push r10
000078eb87dde6a5  push r11
000078eb87dde6a7  sub rsp, 0xF0
000078eb87dde6ae  vmovaps [rsp], xmm0
000078eb87dde6b3  vmovaps [rsp+0x10], xmm1
000078eb87dde6b9  vmovaps [rsp+0x20], xmm2
000078eb87dde6bf  vmovaps [rsp+0x30], xmm3
000078eb87dde6c5  vmovaps [rsp+0x40], xmm4
000078eb87dde6cb  vmovaps [rsp+0x50], xmm5
000078eb87dde6d1  vmovaps [rsp+0x60], xmm6
000078eb87dde6d7  vmovaps [rsp+0x70], xmm7
000078eb87dde6dd  vmovaps [rsp+0x80], xmm8
000078eb87dde6e6  vmovaps [rsp+0x90], xmm10
000078eb87dde6ef  vmovaps [rsp+0xA0], xmm11
000078eb87dde6f8  vmovaps [rsp+0xB0], xmm12
000078eb87dde701  vmovaps [rsp+0xC0], xmm13
000078eb87dde70a  vmovaps [rsp+0xD0], xmm14
000078eb87dde713  vmovaps [rsp+0xE0], xmm15
000078eb87dde71c  sub rsp, 0x30
000078eb87dde720  movaps [rsp], xmm9
000078eb87dde725  movaps [rsp+0x10], xmm3
000078eb87dde72a  movaps [rsp+0x20], xmm1
000078eb87dde72f  lea rdi, [rsp]
000078eb87dde733  mov esi, 0x00
000078eb87dde738  mov rax, 0x61D341A71530
000078eb87dde742  call rax
000078eb87dde744  movaps xmm9, [rsp]
000078eb87dde749  add rsp, 0x30
000078eb87dde74d  vmovaps xmm0, [rsp]
000078eb87dde752  vmovaps xmm1, [rsp+0x10]
000078eb87dde758  vmovaps xmm2, [rsp+0x20]
000078eb87dde75e  vmovaps xmm3, [rsp+0x30]
000078eb87dde764  vmovaps xmm4, [rsp+0x40]
000078eb87dde76a  vmovaps xmm5, [rsp+0x50]
000078eb87dde770  vmovaps xmm6, [rsp+0x60]
000078eb87dde776  vmovaps xmm7, [rsp+0x70]
000078eb87dde77c  vmovaps xmm8, [rsp+0x80]
000078eb87dde785  vmovaps xmm10, [rsp+0x90]
000078eb87dde78e  vmovaps xmm11, [rsp+0xA0]
000078eb87dde797  vmovaps xmm12, [rsp+0xB0]
000078eb87dde7a0  vmovaps xmm13, [rsp+0xC0]
000078eb87dde7a9  vmovaps xmm14, [rsp+0xD0]
000078eb87dde7b2  vmovaps xmm15, [rsp+0xE0]
000078eb87dde7bb  add rsp, 0xF0
000078eb87dde7c2  pop r11
000078eb87dde7c4  pop r10
000078eb87dde7c6  pop r9
000078eb87dde7c8  pop r8
000078eb87dde7ca  pop rsi
000078eb87dde7cb  pop rdi
000078eb87dde7cc  pop rdx
000078eb87dde7cd  pop rcx
000078eb87dde7ce  pop rax
000078eb87dde7cf  add rsp, 0x08
000078eb87dde7d3  jmp 0x000078EB87DDC1AA
000078eb87dde7d8  call 0x000078EB87CB52F0
000078eb87dde7dd  jmp 0x000078EB87DDC1B7
000078eb87dde7e2  sub rsp, 0x08
000078eb87dde7e6  push rax
000078eb87dde7e7  push rcx
000078eb87dde7e8  push rdx
000078eb87dde7e9  push rdi
000078eb87dde7ea  push rsi
000078eb87dde7eb  push r8
000078eb87dde7ed  push r9
000078eb87dde7ef  push r10
000078eb87dde7f1  push r11
000078eb87dde7f3  sub rsp, 0xF0
000078eb87dde7fa  vmovaps [rsp], xmm0
000078eb87dde7ff  vmovaps [rsp+0x10], xmm1
000078eb87dde805  vmovaps [rsp+0x20], xmm2
000078eb87dde80b  vmovaps [rsp+0x30], xmm3
000078eb87dde811  vmovaps [rsp+0x40], xmm4
000078eb87dde817  vmovaps [rsp+0x50], xmm5
000078eb87dde81d  vmovaps [rsp+0x60], xmm6
000078eb87dde823  vmovaps [rsp+0x70], xmm7
000078eb87dde829  vmovaps [rsp+0x80], xmm8
000078eb87dde832  vmovaps [rsp+0x90], xmm9
000078eb87dde83b  vmovaps [rsp+0xA0], xmm10
000078eb87dde844  vmovaps [rsp+0xB0], xmm11
000078eb87dde84d  vmovaps [rsp+0xC0], xmm12
000078eb87dde856  vmovaps [rsp+0xD0], xmm13
000078eb87dde85f  vmovaps [rsp+0xE0], xmm14
000078eb87dde868  sub rsp, 0x30
000078eb87dde86c  movaps [rsp], xmm15
000078eb87dde871  movaps [rsp+0x10], xmm3
000078eb87dde876  movaps [rsp+0x20], xmm7
000078eb87dde87b  lea rdi, [rsp]
000078eb87dde87f  mov esi, 0x00
000078eb87dde884  mov rax, 0x61D341A71530
000078eb87dde88e  call rax
000078eb87dde890  movaps xmm15, [rsp]
000078eb87dde895  add rsp, 0x30
000078eb87dde899  vmovaps xmm0, [rsp]
000078eb87dde89e  vmovaps xmm1, [rsp+0x10]
000078eb87dde8a4  vmovaps xmm2, [rsp+0x20]
000078eb87dde8aa  vmovaps xmm3, [rsp+0x30]
000078eb87dde8b0  vmovaps xmm4, [rsp+0x40]
000078eb87dde8b6  vmovaps xmm5, [rsp+0x50]
000078eb87dde8bc  vmovaps xmm6, [rsp+0x60]
000078eb87dde8c2  vmovaps xmm7, [rsp+0x70]
000078eb87dde8c8  vmovaps xmm8, [rsp+0x80]
000078eb87dde8d1  vmovaps xmm9, [rsp+0x90]
000078eb87dde8da  vmovaps xmm10, [rsp+0xA0]
000078eb87dde8e3  vmovaps xmm11, [rsp+0xB0]
000078eb87dde8ec  vmovaps xmm12, [rsp+0xC0]
000078eb87dde8f5  vmovaps xmm13, [rsp+0xD0]
000078eb87dde8fe  vmovaps xmm14, [rsp+0xE0]
000078eb87dde907  add rsp, 0xF0
000078eb87dde90e  pop r11
000078eb87dde910  pop r10
000078eb87dde912  pop r9
000078eb87dde914  pop r8
000078eb87dde916  pop rsi
000078eb87dde917  pop rdi
000078eb87dde918  pop rdx
000078eb87dde919  pop rcx
000078eb87dde91a  pop rax
000078eb87dde91b  add rsp, 0x08
000078eb87dde91f  jmp 0x000078EB87DDC1E3
000078eb87dde924  sub rsp, 0x08
000078eb87dde928  push rax
000078eb87dde929  push rcx
000078eb87dde92a  push rdx
000078eb87dde92b  push rdi
000078eb87dde92c  push rsi
000078eb87dde92d  push r8
000078eb87dde92f  push r9
000078eb87dde931  push r10
000078eb87dde933  push r11
000078eb87dde935  sub rsp, 0xF0
000078eb87dde93c  vmovaps [rsp], xmm0
000078eb87dde941  vmovaps [rsp+0x10], xmm1
000078eb87dde947  vmovaps [rsp+0x20], xmm2
000078eb87dde94d  vmovaps [rsp+0x30], xmm4
000078eb87dde953  vmovaps [rsp+0x40], xmm5
000078eb87dde959  vmovaps [rsp+0x50], xmm6
000078eb87dde95f  vmovaps [rsp+0x60], xmm7
000078eb87dde965  vmovaps [rsp+0x70], xmm8
000078eb87dde96b  vmovaps [rsp+0x80], xmm9
000078eb87dde974  vmovaps [rsp+0x90], xmm10
000078eb87dde97d  vmovaps [rsp+0xA0], xmm11
000078eb87dde986  vmovaps [rsp+0xB0], xmm12
000078eb87dde98f  vmovaps [rsp+0xC0], xmm13
000078eb87dde998  vmovaps [rsp+0xD0], xmm14
000078eb87dde9a1  vmovaps [rsp+0xE0], xmm15
000078eb87dde9aa  sub rsp, 0x30
000078eb87dde9ae  movaps [rsp], xmm3
000078eb87dde9b2  movaps [rsp+0x10], xmm1
000078eb87dde9b7  movaps [rsp+0x20], xmm15
000078eb87dde9bd  lea rdi, [rsp]
000078eb87dde9c1  mov esi, 0x00
000078eb87dde9c6  mov rax, 0x61D341A71530
000078eb87dde9d0  call rax
000078eb87dde9d2  movaps xmm3, [rsp]
000078eb87dde9d6  add rsp, 0x30
000078eb87dde9da  vmovaps xmm0, [rsp]
000078eb87dde9df  vmovaps xmm1, [rsp+0x10]
000078eb87dde9e5  vmovaps xmm2, [rsp+0x20]
000078eb87dde9eb  vmovaps xmm4, [rsp+0x30]
000078eb87dde9f1  vmovaps xmm5, [rsp+0x40]
000078eb87dde9f7  vmovaps xmm6, [rsp+0x50]
000078eb87dde9fd  vmovaps xmm7, [rsp+0x60]
000078eb87ddea03  vmovaps xmm8, [rsp+0x70]
000078eb87ddea09  vmovaps xmm9, [rsp+0x80]
000078eb87ddea12  vmovaps xmm10, [rsp+0x90]
000078eb87ddea1b  vmovaps xmm11, [rsp+0xA0]
000078eb87ddea24  vmovaps xmm12, [rsp+0xB0]
000078eb87ddea2d  vmovaps xmm13, [rsp+0xC0]
000078eb87ddea36  vmovaps xmm14, [rsp+0xD0]
000078eb87ddea3f  vmovaps xmm15, [rsp+0xE0]
000078eb87ddea48  add rsp, 0xF0
000078eb87ddea4f  pop r11
000078eb87ddea51  pop r10
000078eb87ddea53  pop r9
000078eb87ddea55  pop r8
000078eb87ddea57  pop rsi
000078eb87ddea58  pop rdi
000078eb87ddea59  pop rdx
000078eb87ddea5a  pop rcx
000078eb87ddea5b  pop rax
000078eb87ddea5c  add rsp, 0x08
000078eb87ddea60  jmp 0x000078EB87DDC272
000078eb87ddea65  call 0x000078EB87CB52F0
000078eb87ddea6a  jmp 0x000078EB87DDC27C
000078eb87ddea6f  sub rsp, 0x08
000078eb87ddea73  push rax
000078eb87ddea74  push rcx
000078eb87ddea75  push rdx
000078eb87ddea76  push rdi
000078eb87ddea77  push rsi
000078eb87ddea78  push r8
000078eb87ddea7a  push r9
000078eb87ddea7c  push r10
000078eb87ddea7e  push r11
000078eb87ddea80  sub rsp, 0xF0
000078eb87ddea87  vmovaps [rsp], xmm0
000078eb87ddea8c  vmovaps [rsp+0x10], xmm1
000078eb87ddea92  vmovaps [rsp+0x20], xmm2
000078eb87ddea98  vmovaps [rsp+0x30], xmm3
000078eb87ddea9e  vmovaps [rsp+0x40], xmm4
000078eb87ddeaa4  vmovaps [rsp+0x50], xmm5
000078eb87ddeaaa  vmovaps [rsp+0x60], xmm6
000078eb87ddeab0  vmovaps [rsp+0x70], xmm7
000078eb87ddeab6  vmovaps [rsp+0x80], xmm8
000078eb87ddeabf  vmovaps [rsp+0x90], xmm9
000078eb87ddeac8  vmovaps [rsp+0xA0], xmm10
000078eb87ddead1  vmovaps [rsp+0xB0], xmm11
000078eb87ddeada  vmovaps [rsp+0xC0], xmm12
000078eb87ddeae3  vmovaps [rsp+0xD0], xmm13
000078eb87ddeaec  vmovaps [rsp+0xE0], xmm14
000078eb87ddeaf5  sub rsp, 0x30
000078eb87ddeaf9  movaps [rsp], xmm15
000078eb87ddeafe  movaps [rsp+0x10], xmm14
000078eb87ddeb04  movaps [rsp+0x20], xmm4
000078eb87ddeb09  lea rdi, [rsp]
000078eb87ddeb0d  mov esi, 0x00
000078eb87ddeb12  mov rax, 0x61D341A71530
000078eb87ddeb1c  call rax
000078eb87ddeb1e  movaps xmm15, [rsp]
000078eb87ddeb23  add rsp, 0x30
000078eb87ddeb27  vmovaps xmm0, [rsp]
000078eb87ddeb2c  vmovaps xmm1, [rsp+0x10]
000078eb87ddeb32  vmovaps xmm2, [rsp+0x20]
000078eb87ddeb38  vmovaps xmm3, [rsp+0x30]
000078eb87ddeb3e  vmovaps xmm4, [rsp+0x40]
000078eb87ddeb44  vmovaps xmm5, [rsp+0x50]
000078eb87ddeb4a  vmovaps xmm6, [rsp+0x60]
000078eb87ddeb50  vmovaps xmm7, [rsp+0x70]
000078eb87ddeb56  vmovaps xmm8, [rsp+0x80]
000078eb87ddeb5f  vmovaps xmm9, [rsp+0x90]
000078eb87ddeb68  vmovaps xmm10, [rsp+0xA0]
000078eb87ddeb71  vmovaps xmm11, [rsp+0xB0]
000078eb87ddeb7a  vmovaps xmm12, [rsp+0xC0]
000078eb87ddeb83  vmovaps xmm13, [rsp+0xD0]
000078eb87ddeb8c  vmovaps xmm14, [rsp+0xE0]
000078eb87ddeb95  add rsp, 0xF0
000078eb87ddeb9c  pop r11
000078eb87ddeb9e  pop r10
000078eb87ddeba0  pop r9
000078eb87ddeba2  pop r8
000078eb87ddeba4  pop rsi
000078eb87ddeba5  pop rdi
000078eb87ddeba6  pop rdx
000078eb87ddeba7  pop rcx
000078eb87ddeba8  pop rax
000078eb87ddeba9  add rsp, 0x08
000078eb87ddebad  jmp 0x000078EB87DDC2AA
000078eb87ddebb2  sub rsp, 0x08
000078eb87ddebb6  push rax
000078eb87ddebb7  push rcx
000078eb87ddebb8  push rdx
000078eb87ddebb9  push rdi
000078eb87ddebba  push rsi
000078eb87ddebbb  push r8
000078eb87ddebbd  push r9
000078eb87ddebbf  push r10
000078eb87ddebc1  push r11
000078eb87ddebc3  sub rsp, 0xF0
000078eb87ddebca  vmovaps [rsp], xmm0
000078eb87ddebcf  vmovaps [rsp+0x10], xmm1
000078eb87ddebd5  vmovaps [rsp+0x20], xmm2
000078eb87ddebdb  vmovaps [rsp+0x30], xmm3
000078eb87ddebe1  vmovaps [rsp+0x40], xmm4
000078eb87ddebe7  vmovaps [rsp+0x50], xmm5
000078eb87ddebed  vmovaps [rsp+0x60], xmm6
000078eb87ddebf3  vmovaps [rsp+0x70], xmm7
000078eb87ddebf9  vmovaps [rsp+0x80], xmm8
000078eb87ddec02  vmovaps [rsp+0x90], xmm9
000078eb87ddec0b  vmovaps [rsp+0xA0], xmm10
000078eb87ddec14  vmovaps [rsp+0xB0], xmm11
000078eb87ddec1d  vmovaps [rsp+0xC0], xmm12
000078eb87ddec26  vmovaps [rsp+0xD0], xmm13
000078eb87ddec2f  vmovaps [rsp+0xE0], xmm15
000078eb87ddec38  sub rsp, 0x30
000078eb87ddec3c  movaps [rsp], xmm14
000078eb87ddec41  movaps [rsp+0x10], xmm2
000078eb87ddec46  movaps [rsp+0x20], xmm1
000078eb87ddec4b  lea rdi, [rsp]
000078eb87ddec4f  mov esi, 0x00
000078eb87ddec54  mov rax, 0x61D341A71530
000078eb87ddec5e  call rax
000078eb87ddec60  movaps xmm14, [rsp]
000078eb87ddec65  add rsp, 0x30
000078eb87ddec69  vmovaps xmm0, [rsp]
000078eb87ddec6e  vmovaps xmm1, [rsp+0x10]
000078eb87ddec74  vmovaps xmm2, [rsp+0x20]
000078eb87ddec7a  vmovaps xmm3, [rsp+0x30]
000078eb87ddec80  vmovaps xmm4, [rsp+0x40]
000078eb87ddec86  vmovaps xmm5, [rsp+0x50]
000078eb87ddec8c  vmovaps xmm6, [rsp+0x60]
000078eb87ddec92  vmovaps xmm7, [rsp+0x70]
000078eb87ddec98  vmovaps xmm8, [rsp+0x80]
000078eb87ddeca1  vmovaps xmm9, [rsp+0x90]
000078eb87ddecaa  vmovaps xmm10, [rsp+0xA0]
000078eb87ddecb3  vmovaps xmm11, [rsp+0xB0]
000078eb87ddecbc  vmovaps xmm12, [rsp+0xC0]
000078eb87ddecc5  vmovaps xmm13, [rsp+0xD0]
000078eb87ddecce  vmovaps xmm15, [rsp+0xE0]
000078eb87ddecd7  add rsp, 0xF0
000078eb87ddecde  pop r11
000078eb87ddece0  pop r10
000078eb87ddece2  pop r9
000078eb87ddece4  pop r8
000078eb87ddece6  pop rsi
000078eb87ddece7  pop rdi
000078eb87ddece8  pop rdx
000078eb87ddece9  pop rcx
000078eb87ddecea  pop rax
000078eb87ddeceb  add rsp, 0x08
000078eb87ddecef  jmp 0x000078EB87DDC2D0
000078eb87ddecf4  sub rsp, 0x08
000078eb87ddecf8  push rax
000078eb87ddecf9  push rcx
000078eb87ddecfa  push rdx
000078eb87ddecfb  push rdi
000078eb87ddecfc  push rsi
000078eb87ddecfd  push r8
000078eb87ddecff  push r9
000078eb87dded01  push r10
000078eb87dded03  push r11
000078eb87dded05  sub rsp, 0xF0
000078eb87dded0c  vmovaps [rsp], xmm0
000078eb87dded11  vmovaps [rsp+0x10], xmm2
000078eb87dded17  vmovaps [rsp+0x20], xmm3
000078eb87dded1d  vmovaps [rsp+0x30], xmm4
000078eb87dded23  vmovaps [rsp+0x40], xmm5
000078eb87dded29  vmovaps [rsp+0x50], xmm6
000078eb87dded2f  vmovaps [rsp+0x60], xmm7
000078eb87dded35  vmovaps [rsp+0x70], xmm8
000078eb87dded3b  vmovaps [rsp+0x80], xmm9
000078eb87dded44  vmovaps [rsp+0x90], xmm10
000078eb87dded4d  vmovaps [rsp+0xA0], xmm11
000078eb87dded56  vmovaps [rsp+0xB0], xmm12
000078eb87dded5f  vmovaps [rsp+0xC0], xmm13
000078eb87dded68  vmovaps [rsp+0xD0], xmm14
000078eb87dded71  vmovaps [rsp+0xE0], xmm15
000078eb87dded7a  sub rsp, 0x30
000078eb87dded7e  movaps [rsp], xmm1
000078eb87dded82  movaps [rsp+0x10], xmm4
000078eb87dded87  movaps [rsp+0x20], xmm9
000078eb87dded8d  lea rdi, [rsp]
000078eb87dded91  mov esi, 0x00
000078eb87dded96  mov rax, 0x61D341A71530
000078eb87ddeda0  call rax
000078eb87ddeda2  movaps xmm1, [rsp]
000078eb87ddeda6  add rsp, 0x30
000078eb87ddedaa  vmovaps xmm0, [rsp]
000078eb87ddedaf  vmovaps xmm2, [rsp+0x10]
000078eb87ddedb5  vmovaps xmm3, [rsp+0x20]
000078eb87ddedbb  vmovaps xmm4, [rsp+0x30]
000078eb87ddedc1  vmovaps xmm5, [rsp+0x40]
000078eb87ddedc7  vmovaps xmm6, [rsp+0x50]
000078eb87ddedcd  vmovaps xmm7, [rsp+0x60]
000078eb87ddedd3  vmovaps xmm8, [rsp+0x70]
000078eb87ddedd9  vmovaps xmm9, [rsp+0x80]
000078eb87ddede2  vmovaps xmm10, [rsp+0x90]
000078eb87ddedeb  vmovaps xmm11, [rsp+0xA0]
000078eb87ddedf4  vmovaps xmm12, [rsp+0xB0]
000078eb87ddedfd  vmovaps xmm13, [rsp+0xC0]
000078eb87ddee06  vmovaps xmm14, [rsp+0xD0]
000078eb87ddee0f  vmovaps xmm15, [rsp+0xE0]
000078eb87ddee18  add rsp, 0xF0
000078eb87ddee1f  pop r11
000078eb87ddee21  pop r10
000078eb87ddee23  pop r9
000078eb87ddee25  pop r8
000078eb87ddee27  pop rsi
000078eb87ddee28  pop rdi
000078eb87ddee29  pop rdx
000078eb87ddee2a  pop rcx
000078eb87ddee2b  pop rax
000078eb87ddee2c  add rsp, 0x08
000078eb87ddee30  jmp 0x000078EB87DDC2EE
000078eb87ddee35  sub rsp, 0x08
000078eb87ddee39  push rax
000078eb87ddee3a  push rcx
000078eb87ddee3b  push rdx
000078eb87ddee3c  push rdi
000078eb87ddee3d  push rsi
000078eb87ddee3e  push r8
000078eb87ddee40  push r9
000078eb87ddee42  push r10
000078eb87ddee44  push r11
000078eb87ddee46  sub rsp, 0xF0
000078eb87ddee4d  vmovaps [rsp], xmm0
000078eb87ddee52  vmovaps [rsp+0x10], xmm1
000078eb87ddee58  vmovaps [rsp+0x20], xmm2
000078eb87ddee5e  vmovaps [rsp+0x30], xmm3
000078eb87ddee64  vmovaps [rsp+0x40], xmm5
000078eb87ddee6a  vmovaps [rsp+0x50], xmm6
000078eb87ddee70  vmovaps [rsp+0x60], xmm7
000078eb87ddee76  vmovaps [rsp+0x70], xmm8
000078eb87ddee7c  vmovaps [rsp+0x80], xmm9
000078eb87ddee85  vmovaps [rsp+0x90], xmm10
000078eb87ddee8e  vmovaps [rsp+0xA0], xmm11
000078eb87ddee97  vmovaps [rsp+0xB0], xmm12
000078eb87ddeea0  vmovaps [rsp+0xC0], xmm13
000078eb87ddeea9  vmovaps [rsp+0xD0], xmm14
000078eb87ddeeb2  vmovaps [rsp+0xE0], xmm15
000078eb87ddeebb  sub rsp, 0x30
000078eb87ddeebf  movaps [rsp], xmm4
000078eb87ddeec3  movaps [rsp+0x10], xmm2
000078eb87ddeec8  movaps [rsp+0x20], xmm9
000078eb87ddeece  lea rdi, [rsp]
000078eb87ddeed2  mov esi, 0x00
000078eb87ddeed7  mov rax, 0x61D341A71530
000078eb87ddeee1  call rax
000078eb87ddeee3  movaps xmm4, [rsp]
000078eb87ddeee7  add rsp, 0x30
000078eb87ddeeeb  vmovaps xmm0, [rsp]
000078eb87ddeef0  vmovaps xmm1, [rsp+0x10]
000078eb87ddeef6  vmovaps xmm2, [rsp+0x20]
000078eb87ddeefc  vmovaps xmm3, [rsp+0x30]
000078eb87ddef02  vmovaps xmm5, [rsp+0x40]
000078eb87ddef08  vmovaps xmm6, [rsp+0x50]
000078eb87ddef0e  vmovaps xmm7, [rsp+0x60]
000078eb87ddef14  vmovaps xmm8, [rsp+0x70]
000078eb87ddef1a  vmovaps xmm9, [rsp+0x80]
000078eb87ddef23  vmovaps xmm10, [rsp+0x90]
000078eb87ddef2c  vmovaps xmm11, [rsp+0xA0]
000078eb87ddef35  vmovaps xmm12, [rsp+0xB0]
000078eb87ddef3e  vmovaps xmm13, [rsp+0xC0]
000078eb87ddef47  vmovaps xmm14, [rsp+0xD0]
000078eb87ddef50  vmovaps xmm15, [rsp+0xE0]
000078eb87ddef59  add rsp, 0xF0
000078eb87ddef60  pop r11
000078eb87ddef62  pop r10
000078eb87ddef64  pop r9
000078eb87ddef66  pop r8
000078eb87ddef68  pop rsi
000078eb87ddef69  pop rdi
000078eb87ddef6a  pop rdx
000078eb87ddef6b  pop rcx
000078eb87ddef6c  pop rax
000078eb87ddef6d  add rsp, 0x08
000078eb87ddef71  jmp 0x000078EB87DDC31E
000078eb87ddef76  sub rsp, 0x08
000078eb87ddef7a  push rax
000078eb87ddef7b  push rcx
000078eb87ddef7c  push rdx
000078eb87ddef7d  push rdi
000078eb87ddef7e  push rsi
000078eb87ddef7f  push r8
000078eb87ddef81  push r9
000078eb87ddef83  push r10
000078eb87ddef85  push r11
000078eb87ddef87  sub rsp, 0xF0
000078eb87ddef8e  vmovaps [rsp], xmm0
000078eb87ddef93  vmovaps [rsp+0x10], xmm1
000078eb87ddef99  vmovaps [rsp+0x20], xmm2
000078eb87ddef9f  vmovaps [rsp+0x30], xmm3
000078eb87ddefa5  vmovaps [rsp+0x40], xmm4
000078eb87ddefab  vmovaps [rsp+0x50], xmm5
000078eb87ddefb1  vmovaps [rsp+0x60], xmm6
000078eb87ddefb7  vmovaps [rsp+0x70], xmm7
000078eb87ddefbd  vmovaps [rsp+0x80], xmm8
000078eb87ddefc6  vmovaps [rsp+0x90], xmm10
000078eb87ddefcf  vmovaps [rsp+0xA0], xmm11
000078eb87ddefd8  vmovaps [rsp+0xB0], xmm12
000078eb87ddefe1  vmovaps [rsp+0xC0], xmm13
000078eb87ddefea  vmovaps [rsp+0xD0], xmm14
000078eb87ddeff3  vmovaps [rsp+0xE0], xmm15
000078eb87ddeffc  sub rsp, 0x30
000078eb87ddf000  movaps [rsp], xmm9
000078eb87ddf005  movaps [rsp+0x10], xmm2
000078eb87ddf00a  movaps [rsp+0x20], xmm1
000078eb87ddf00f  lea rdi, [rsp]
000078eb87ddf013  mov esi, 0x00
000078eb87ddf018  mov rax, 0x61D341A71530
000078eb87ddf022  call rax
000078eb87ddf024  movaps xmm9, [rsp]
000078eb87ddf029  add rsp, 0x30
000078eb87ddf02d  vmovaps xmm0, [rsp]
000078eb87ddf032  vmovaps xmm1, [rsp+0x10]
000078eb87ddf038  vmovaps xmm2, [rsp+0x20]
000078eb87ddf03e  vmovaps xmm3, [rsp+0x30]
000078eb87ddf044  vmovaps xmm4, [rsp+0x40]
000078eb87ddf04a  vmovaps xmm5, [rsp+0x50]
000078eb87ddf050  vmovaps xmm6, [rsp+0x60]
000078eb87ddf056  vmovaps xmm7, [rsp+0x70]
000078eb87ddf05c  vmovaps xmm8, [rsp+0x80]
000078eb87ddf065  vmovaps xmm10, [rsp+0x90]
000078eb87ddf06e  vmovaps xmm11, [rsp+0xA0]
000078eb87ddf077  vmovaps xmm12, [rsp+0xB0]
000078eb87ddf080  vmovaps xmm13, [rsp+0xC0]
000078eb87ddf089  vmovaps xmm14, [rsp+0xD0]
000078eb87ddf092  vmovaps xmm15, [rsp+0xE0]
000078eb87ddf09b  add rsp, 0xF0
000078eb87ddf0a2  pop r11
000078eb87ddf0a4  pop r10
000078eb87ddf0a6  pop r9
000078eb87ddf0a8  pop r8
000078eb87ddf0aa  pop rsi
000078eb87ddf0ab  pop rdi
000078eb87ddf0ac  pop rdx
000078eb87ddf0ad  pop rcx
000078eb87ddf0ae  pop rax
000078eb87ddf0af  add rsp, 0x08
000078eb87ddf0b3  jmp 0x000078EB87DDC354
000078eb87ddf0b8  sub rsp, 0x08
000078eb87ddf0bc  push rax
000078eb87ddf0bd  push rcx
000078eb87ddf0be  push rdx
000078eb87ddf0bf  push rdi
000078eb87ddf0c0  push rsi
000078eb87ddf0c1  push r8
000078eb87ddf0c3  push r9
000078eb87ddf0c5  push r10
000078eb87ddf0c7  push r11
000078eb87ddf0c9  sub rsp, 0xF0
000078eb87ddf0d0  vmovaps [rsp], xmm0
000078eb87ddf0d5  vmovaps [rsp+0x10], xmm2
000078eb87ddf0db  vmovaps [rsp+0x20], xmm3
000078eb87ddf0e1  vmovaps [rsp+0x30], xmm4
000078eb87ddf0e7  vmovaps [rsp+0x40], xmm5
000078eb87ddf0ed  vmovaps [rsp+0x50], xmm6
000078eb87ddf0f3  vmovaps [rsp+0x60], xmm7
000078eb87ddf0f9  vmovaps [rsp+0x70], xmm8
000078eb87ddf0ff  vmovaps [rsp+0x80], xmm9
000078eb87ddf108  vmovaps [rsp+0x90], xmm10
000078eb87ddf111  vmovaps [rsp+0xA0], xmm11
000078eb87ddf11a  vmovaps [rsp+0xB0], xmm12
000078eb87ddf123  vmovaps [rsp+0xC0], xmm13
000078eb87ddf12c  vmovaps [rsp+0xD0], xmm14
000078eb87ddf135  vmovaps [rsp+0xE0], xmm15
000078eb87ddf13e  sub rsp, 0x30
000078eb87ddf142  movaps [rsp], xmm1
000078eb87ddf146  movaps [rsp+0x10], xmm15
000078eb87ddf14c  movaps [rsp+0x20], xmm6
000078eb87ddf151  lea rdi, [rsp]
000078eb87ddf155  mov esi, 0x00
000078eb87ddf15a  mov rax, 0x61D341A71530
000078eb87ddf164  call rax
000078eb87ddf166  movaps xmm1, [rsp]
000078eb87ddf16a  add rsp, 0x30
000078eb87ddf16e  vmovaps xmm0, [rsp]
000078eb87ddf173  vmovaps xmm2, [rsp+0x10]
000078eb87ddf179  vmovaps xmm3, [rsp+0x20]
000078eb87ddf17f  vmovaps xmm4, [rsp+0x30]
000078eb87ddf185  vmovaps xmm5, [rsp+0x40]
000078eb87ddf18b  vmovaps xmm6, [rsp+0x50]
000078eb87ddf191  vmovaps xmm7, [rsp+0x60]
000078eb87ddf197  vmovaps xmm8, [rsp+0x70]
000078eb87ddf19d  vmovaps xmm9, [rsp+0x80]
000078eb87ddf1a6  vmovaps xmm10, [rsp+0x90]
000078eb87ddf1af  vmovaps xmm11, [rsp+0xA0]
000078eb87ddf1b8  vmovaps xmm12, [rsp+0xB0]
000078eb87ddf1c1  vmovaps xmm13, [rsp+0xC0]
000078eb87ddf1ca  vmovaps xmm14, [rsp+0xD0]
000078eb87ddf1d3  vmovaps xmm15, [rsp+0xE0]
000078eb87ddf1dc  add rsp, 0xF0
000078eb87ddf1e3  pop r11
000078eb87ddf1e5  pop r10
000078eb87ddf1e7  pop r9
000078eb87ddf1e9  pop r8
000078eb87ddf1eb  pop rsi
000078eb87ddf1ec  pop rdi
000078eb87ddf1ed  pop rdx
000078eb87ddf1ee  pop rcx
000078eb87ddf1ef  pop rax
000078eb87ddf1f0  add rsp, 0x08
000078eb87ddf1f4  jmp 0x000078EB87DDC375
000078eb87ddf1f9  sub rsp, 0x08
000078eb87ddf1fd  push rax
000078eb87ddf1fe  push rcx
000078eb87ddf1ff  push rdx
000078eb87ddf200  push rdi
000078eb87ddf201  push rsi
000078eb87ddf202  push r8
000078eb87ddf204  push r9
000078eb87ddf206  push r10
000078eb87ddf208  push r11
000078eb87ddf20a  sub rsp, 0xF0
000078eb87ddf211  vmovaps [rsp], xmm0
000078eb87ddf216  vmovaps [rsp+0x10], xmm1
000078eb87ddf21c  vmovaps [rsp+0x20], xmm2
000078eb87ddf222  vmovaps [rsp+0x30], xmm3
000078eb87ddf228  vmovaps [rsp+0x40], xmm4
000078eb87ddf22e  vmovaps [rsp+0x50], xmm5
000078eb87ddf234  vmovaps [rsp+0x60], xmm6
000078eb87ddf23a  vmovaps [rsp+0x70], xmm7
000078eb87ddf240  vmovaps [rsp+0x80], xmm8
000078eb87ddf249  vmovaps [rsp+0x90], xmm9
000078eb87ddf252  vmovaps [rsp+0xA0], xmm10
000078eb87ddf25b  vmovaps [rsp+0xB0], xmm11
000078eb87ddf264  vmovaps [rsp+0xC0], xmm12
000078eb87ddf26d  vmovaps [rsp+0xD0], xmm13
000078eb87ddf276  vmovaps [rsp+0xE0], xmm14
000078eb87ddf27f  sub rsp, 0x30
000078eb87ddf283  movaps [rsp], xmm15
000078eb87ddf288  movaps [rsp+0x10], xmm5
000078eb87ddf28d  movaps [rsp+0x20], xmm3
000078eb87ddf292  lea rdi, [rsp]
000078eb87ddf296  mov esi, 0x00
000078eb87ddf29b  mov rax, 0x61D341A71530
000078eb87ddf2a5  call rax
000078eb87ddf2a7  movaps xmm15, [rsp]
000078eb87ddf2ac  add rsp, 0x30
000078eb87ddf2b0  vmovaps xmm0, [rsp]
000078eb87ddf2b5  vmovaps xmm1, [rsp+0x10]
000078eb87ddf2bb  vmovaps xmm2, [rsp+0x20]
000078eb87ddf2c1  vmovaps xmm3, [rsp+0x30]
000078eb87ddf2c7  vmovaps xmm4, [rsp+0x40]
000078eb87ddf2cd  vmovaps xmm5, [rsp+0x50]
000078eb87ddf2d3  vmovaps xmm6, [rsp+0x60]
000078eb87ddf2d9  vmovaps xmm7, [rsp+0x70]
000078eb87ddf2df  vmovaps xmm8, [rsp+0x80]
000078eb87ddf2e8  vmovaps xmm9, [rsp+0x90]
000078eb87ddf2f1  vmovaps xmm10, [rsp+0xA0]
000078eb87ddf2fa  vmovaps xmm11, [rsp+0xB0]
000078eb87ddf303  vmovaps xmm12, [rsp+0xC0]
000078eb87ddf30c  vmovaps xmm13, [rsp+0xD0]
000078eb87ddf315  vmovaps xmm14, [rsp+0xE0]
000078eb87ddf31e  add rsp, 0xF0
000078eb87ddf325  pop r11
000078eb87ddf327  pop r10
000078eb87ddf329  pop r9
000078eb87ddf32b  pop r8
000078eb87ddf32d  pop rsi
000078eb87ddf32e  pop rdi
000078eb87ddf32f  pop rdx
000078eb87ddf330  pop rcx
000078eb87ddf331  pop rax
000078eb87ddf332  add rsp, 0x08
000078eb87ddf336  jmp 0x000078EB87DDC38F
000078eb87ddf33b  sub rsp, 0x08
000078eb87ddf33f  push rax
000078eb87ddf340  push rcx
000078eb87ddf341  push rdx
000078eb87ddf342  push rdi
000078eb87ddf343  push rsi
000078eb87ddf344  push r8
000078eb87ddf346  push r9
000078eb87ddf348  push r10
000078eb87ddf34a  push r11
000078eb87ddf34c  sub rsp, 0xF0
000078eb87ddf353  vmovaps [rsp], xmm0
000078eb87ddf358  vmovaps [rsp+0x10], xmm1
000078eb87ddf35e  vmovaps [rsp+0x20], xmm2
000078eb87ddf364  vmovaps [rsp+0x30], xmm3
000078eb87ddf36a  vmovaps [rsp+0x40], xmm4
000078eb87ddf370  vmovaps [rsp+0x50], xmm6
000078eb87ddf376  vmovaps [rsp+0x60], xmm7
000078eb87ddf37c  vmovaps [rsp+0x70], xmm8
000078eb87ddf382  vmovaps [rsp+0x80], xmm9
000078eb87ddf38b  vmovaps [rsp+0x90], xmm10
000078eb87ddf394  vmovaps [rsp+0xA0], xmm11
000078eb87ddf39d  vmovaps [rsp+0xB0], xmm12
000078eb87ddf3a6  vmovaps [rsp+0xC0], xmm13
000078eb87ddf3af  vmovaps [rsp+0xD0], xmm14
000078eb87ddf3b8  vmovaps [rsp+0xE0], xmm15
000078eb87ddf3c1  sub rsp, 0x30
000078eb87ddf3c5  movaps [rsp], xmm5
000078eb87ddf3c9  movaps [rsp+0x10], xmm8
000078eb87ddf3cf  movaps [rsp+0x20], xmm6
000078eb87ddf3d4  lea rdi, [rsp]
000078eb87ddf3d8  mov esi, 0x00
000078eb87ddf3dd  mov rax, 0x61D341A71530
000078eb87ddf3e7  call rax
000078eb87ddf3e9  movaps xmm5, [rsp]
000078eb87ddf3ed  add rsp, 0x30
000078eb87ddf3f1  vmovaps xmm0, [rsp]
000078eb87ddf3f6  vmovaps xmm1, [rsp+0x10]
000078eb87ddf3fc  vmovaps xmm2, [rsp+0x20]
000078eb87ddf402  vmovaps xmm3, [rsp+0x30]
000078eb87ddf408  vmovaps xmm4, [rsp+0x40]
000078eb87ddf40e  vmovaps xmm6, [rsp+0x50]
000078eb87ddf414  vmovaps xmm7, [rsp+0x60]
000078eb87ddf41a  vmovaps xmm8, [rsp+0x70]
000078eb87ddf420  vmovaps xmm9, [rsp+0x80]
000078eb87ddf429  vmovaps xmm10, [rsp+0x90]
000078eb87ddf432  vmovaps xmm11, [rsp+0xA0]
000078eb87ddf43b  vmovaps xmm12, [rsp+0xB0]
000078eb87ddf444  vmovaps xmm13, [rsp+0xC0]
000078eb87ddf44d  vmovaps xmm14, [rsp+0xD0]
000078eb87ddf456  vmovaps xmm15, [rsp+0xE0]
000078eb87ddf45f  add rsp, 0xF0
000078eb87ddf466  pop r11
000078eb87ddf468  pop r10
000078eb87ddf46a  pop r9
000078eb87ddf46c  pop r8
000078eb87ddf46e  pop rsi
000078eb87ddf46f  pop rdi
000078eb87ddf470  pop rdx
000078eb87ddf471  pop rcx
000078eb87ddf472  pop rax
000078eb87ddf473  add rsp, 0x08
000078eb87ddf477  jmp 0x000078EB87DDC3B3
000078eb87ddf47c  sub rsp, 0x08
000078eb87ddf480  push rax
000078eb87ddf481  push rcx
000078eb87ddf482  push rdx
000078eb87ddf483  push rdi
000078eb87ddf484  push rsi
000078eb87ddf485  push r8
000078eb87ddf487  push r9
000078eb87ddf489  push r10
000078eb87ddf48b  push r11
000078eb87ddf48d  sub rsp, 0xF0
000078eb87ddf494  vmovaps [rsp], xmm0
000078eb87ddf499  vmovaps [rsp+0x10], xmm1
000078eb87ddf49f  vmovaps [rsp+0x20], xmm2
000078eb87ddf4a5  vmovaps [rsp+0x30], xmm3
000078eb87ddf4ab  vmovaps [rsp+0x40], xmm4
000078eb87ddf4b1  vmovaps [rsp+0x50], xmm5
000078eb87ddf4b7  vmovaps [rsp+0x60], xmm7
000078eb87ddf4bd  vmovaps [rsp+0x70], xmm8
000078eb87ddf4c3  vmovaps [rsp+0x80], xmm9
000078eb87ddf4cc  vmovaps [rsp+0x90], xmm10
000078eb87ddf4d5  vmovaps [rsp+0xA0], xmm11
000078eb87ddf4de  vmovaps [rsp+0xB0], xmm12
000078eb87ddf4e7  vmovaps [rsp+0xC0], xmm13
000078eb87ddf4f0  vmovaps [rsp+0xD0], xmm14
000078eb87ddf4f9  vmovaps [rsp+0xE0], xmm15
000078eb87ddf502  sub rsp, 0x30
000078eb87ddf506  movaps [rsp], xmm6
000078eb87ddf50a  movaps [rsp+0x10], xmm10
000078eb87ddf510  movaps [rsp+0x20], xmm8
000078eb87ddf516  lea rdi, [rsp]
000078eb87ddf51a  mov esi, 0x00
000078eb87ddf51f  mov rax, 0x61D341A71530
000078eb87ddf529  call rax
000078eb87ddf52b  movaps xmm6, [rsp]
000078eb87ddf52f  add rsp, 0x30
000078eb87ddf533  vmovaps xmm0, [rsp]
000078eb87ddf538  vmovaps xmm1, [rsp+0x10]
000078eb87ddf53e  vmovaps xmm2, [rsp+0x20]
000078eb87ddf544  vmovaps xmm3, [rsp+0x30]
000078eb87ddf54a  vmovaps xmm4, [rsp+0x40]
000078eb87ddf550  vmovaps xmm5, [rsp+0x50]
000078eb87ddf556  vmovaps xmm7, [rsp+0x60]
000078eb87ddf55c  vmovaps xmm8, [rsp+0x70]
000078eb87ddf562  vmovaps xmm9, [rsp+0x80]
000078eb87ddf56b  vmovaps xmm10, [rsp+0x90]
000078eb87ddf574  vmovaps xmm11, [rsp+0xA0]
000078eb87ddf57d  vmovaps xmm12, [rsp+0xB0]
000078eb87ddf586  vmovaps xmm13, [rsp+0xC0]
000078eb87ddf58f  vmovaps xmm14, [rsp+0xD0]
000078eb87ddf598  vmovaps xmm15, [rsp+0xE0]
000078eb87ddf5a1  add rsp, 0xF0
000078eb87ddf5a8  pop r11
000078eb87ddf5aa  pop r10
000078eb87ddf5ac  pop r9
000078eb87ddf5ae  pop r8
000078eb87ddf5b0  pop rsi
000078eb87ddf5b1  pop rdi
000078eb87ddf5b2  pop rdx
000078eb87ddf5b3  pop rcx
000078eb87ddf5b4  pop rax
000078eb87ddf5b5  add rsp, 0x08
000078eb87ddf5b9  jmp 0x000078EB87DDC3D8
000078eb87ddf5be  sub rsp, 0x08
000078eb87ddf5c2  push rax
000078eb87ddf5c3  push rcx
000078eb87ddf5c4  push rdx
000078eb87ddf5c5  push rdi
000078eb87ddf5c6  push rsi
000078eb87ddf5c7  push r8
000078eb87ddf5c9  push r9
000078eb87ddf5cb  push r10
000078eb87ddf5cd  push r11
000078eb87ddf5cf  sub rsp, 0xF0
000078eb87ddf5d6  vmovaps [rsp], xmm0
000078eb87ddf5db  vmovaps [rsp+0x10], xmm1
000078eb87ddf5e1  vmovaps [rsp+0x20], xmm2
000078eb87ddf5e7  vmovaps [rsp+0x30], xmm3
000078eb87ddf5ed  vmovaps [rsp+0x40], xmm4
000078eb87ddf5f3  vmovaps [rsp+0x50], xmm5
000078eb87ddf5f9  vmovaps [rsp+0x60], xmm6
000078eb87ddf5ff  vmovaps [rsp+0x70], xmm7
000078eb87ddf605  vmovaps [rsp+0x80], xmm8
000078eb87ddf60e  vmovaps [rsp+0x90], xmm9
000078eb87ddf617  vmovaps [rsp+0xA0], xmm11
000078eb87ddf620  vmovaps [rsp+0xB0], xmm12
000078eb87ddf629  vmovaps [rsp+0xC0], xmm13
000078eb87ddf632  vmovaps [rsp+0xD0], xmm14
000078eb87ddf63b  vmovaps [rsp+0xE0], xmm15
000078eb87ddf644  sub rsp, 0x30
000078eb87ddf648  movaps [rsp], xmm10
000078eb87ddf64d  movaps [rsp+0x10], xmm8
000078eb87ddf653  movaps [rsp+0x20], xmm14
000078eb87ddf659  lea rdi, [rsp]
000078eb87ddf65d  mov esi, 0x00
000078eb87ddf662  mov rax, 0x61D341A71530
000078eb87ddf66c  call rax
000078eb87ddf66e  movaps xmm10, [rsp]
000078eb87ddf673  add rsp, 0x30
000078eb87ddf677  vmovaps xmm0, [rsp]
000078eb87ddf67c  vmovaps xmm1, [rsp+0x10]
000078eb87ddf682  vmovaps xmm2, [rsp+0x20]
000078eb87ddf688  vmovaps xmm3, [rsp+0x30]
000078eb87ddf68e  vmovaps xmm4, [rsp+0x40]
000078eb87ddf694  vmovaps xmm5, [rsp+0x50]
000078eb87ddf69a  vmovaps xmm6, [rsp+0x60]
000078eb87ddf6a0  vmovaps xmm7, [rsp+0x70]
000078eb87ddf6a6  vmovaps xmm8, [rsp+0x80]
000078eb87ddf6af  vmovaps xmm9, [rsp+0x90]
000078eb87ddf6b8  vmovaps xmm11, [rsp+0xA0]
000078eb87ddf6c1  vmovaps xmm12, [rsp+0xB0]
000078eb87ddf6ca  vmovaps xmm13, [rsp+0xC0]
000078eb87ddf6d3  vmovaps xmm14, [rsp+0xD0]
000078eb87ddf6dc  vmovaps xmm15, [rsp+0xE0]
000078eb87ddf6e5  add rsp, 0xF0
000078eb87ddf6ec  pop r11
000078eb87ddf6ee  pop r10
000078eb87ddf6f0  pop r9
000078eb87ddf6f2  pop r8
000078eb87ddf6f4  pop rsi
000078eb87ddf6f5  pop rdi
000078eb87ddf6f6  pop rdx
000078eb87ddf6f7  pop rcx
000078eb87ddf6f8  pop rax
000078eb87ddf6f9  add rsp, 0x08
000078eb87ddf6fd  jmp 0x000078EB87DDC3F8
000078eb87ddf702  sub rsp, 0x08
000078eb87ddf706  push rax
000078eb87ddf707  push rcx
000078eb87ddf708  push rdx
000078eb87ddf709  push rdi
000078eb87ddf70a  push rsi
000078eb87ddf70b  push r8
000078eb87ddf70d  push r9
000078eb87ddf70f  push r10
000078eb87ddf711  push r11
000078eb87ddf713  sub rsp, 0xF0
000078eb87ddf71a  vmovaps [rsp], xmm0
000078eb87ddf71f  vmovaps [rsp+0x10], xmm1
000078eb87ddf725  vmovaps [rsp+0x20], xmm2
000078eb87ddf72b  vmovaps [rsp+0x30], xmm3
000078eb87ddf731  vmovaps [rsp+0x40], xmm4
000078eb87ddf737  vmovaps [rsp+0x50], xmm5
000078eb87ddf73d  vmovaps [rsp+0x60], xmm6
000078eb87ddf743  vmovaps [rsp+0x70], xmm7
000078eb87ddf749  vmovaps [rsp+0x80], xmm8
000078eb87ddf752  vmovaps [rsp+0x90], xmm9
000078eb87ddf75b  vmovaps [rsp+0xA0], xmm10
000078eb87ddf764  vmovaps [rsp+0xB0], xmm11
000078eb87ddf76d  vmovaps [rsp+0xC0], xmm12
000078eb87ddf776  vmovaps [rsp+0xD0], xmm13
000078eb87ddf77f  vmovaps [rsp+0xE0], xmm15
000078eb87ddf788  sub rsp, 0x30
000078eb87ddf78c  movaps [rsp], xmm14
000078eb87ddf791  movaps [rsp+0x10], xmm8
000078eb87ddf797  movaps [rsp+0x20], xmm4
000078eb87ddf79c  lea rdi, [rsp]
000078eb87ddf7a0  mov esi, 0x00
000078eb87ddf7a5  mov rax, 0x61D341A71530
000078eb87ddf7af  call rax
000078eb87ddf7b1  movaps xmm14, [rsp]
000078eb87ddf7b6  add rsp, 0x30
000078eb87ddf7ba  vmovaps xmm0, [rsp]
000078eb87ddf7bf  vmovaps xmm1, [rsp+0x10]
000078eb87ddf7c5  vmovaps xmm2, [rsp+0x20]
000078eb87ddf7cb  vmovaps xmm3, [rsp+0x30]
000078eb87ddf7d1  vmovaps xmm4, [rsp+0x40]
000078eb87ddf7d7  vmovaps xmm5, [rsp+0x50]
000078eb87ddf7dd  vmovaps xmm6, [rsp+0x60]
000078eb87ddf7e3  vmovaps xmm7, [rsp+0x70]
000078eb87ddf7e9  vmovaps xmm8, [rsp+0x80]
000078eb87ddf7f2  vmovaps xmm9, [rsp+0x90]
000078eb87ddf7fb  vmovaps xmm10, [rsp+0xA0]
000078eb87ddf804  vmovaps xmm11, [rsp+0xB0]
000078eb87ddf80d  vmovaps xmm12, [rsp+0xC0]
000078eb87ddf816  vmovaps xmm13, [rsp+0xD0]
000078eb87ddf81f  vmovaps xmm15, [rsp+0xE0]
000078eb87ddf828  add rsp, 0xF0
000078eb87ddf82f  pop r11
000078eb87ddf831  pop r10
000078eb87ddf833  pop r9
000078eb87ddf835  pop r8
000078eb87ddf837  pop rsi
000078eb87ddf838  pop rdi
000078eb87ddf839  pop rdx
000078eb87ddf83a  pop rcx
000078eb87ddf83b  pop rax
000078eb87ddf83c  add rsp, 0x08
000078eb87ddf840  jmp 0x000078EB87DDC418
000078eb87ddf845  sub rsp, 0x08
000078eb87ddf849  push rax
000078eb87ddf84a  push rcx
000078eb87ddf84b  push rdx
000078eb87ddf84c  push rdi
000078eb87ddf84d  push rsi
000078eb87ddf84e  push r8
000078eb87ddf850  push r9
000078eb87ddf852  push r10
000078eb87ddf854  push r11
000078eb87ddf856  sub rsp, 0xF0
000078eb87ddf85d  vmovaps [rsp], xmm0
000078eb87ddf862  vmovaps [rsp+0x10], xmm1
000078eb87ddf868  vmovaps [rsp+0x20], xmm2
000078eb87ddf86e  vmovaps [rsp+0x30], xmm3
000078eb87ddf874  vmovaps [rsp+0x40], xmm5
000078eb87ddf87a  vmovaps [rsp+0x50], xmm6
000078eb87ddf880  vmovaps [rsp+0x60], xmm7
000078eb87ddf886  vmovaps [rsp+0x70], xmm8
000078eb87ddf88c  vmovaps [rsp+0x80], xmm9
000078eb87ddf895  vmovaps [rsp+0x90], xmm10
000078eb87ddf89e  vmovaps [rsp+0xA0], xmm11
000078eb87ddf8a7  vmovaps [rsp+0xB0], xmm12
000078eb87ddf8b0  vmovaps [rsp+0xC0], xmm13
000078eb87ddf8b9  vmovaps [rsp+0xD0], xmm14
000078eb87ddf8c2  vmovaps [rsp+0xE0], xmm15
000078eb87ddf8cb  sub rsp, 0x30
000078eb87ddf8cf  movaps [rsp], xmm4
000078eb87ddf8d3  movaps [rsp+0x10], xmm13
000078eb87ddf8d9  movaps [rsp+0x20], xmm8
000078eb87ddf8df  lea rdi, [rsp]
000078eb87ddf8e3  mov esi, 0x00
000078eb87ddf8e8  mov rax, 0x61D341A71530
000078eb87ddf8f2  call rax
000078eb87ddf8f4  movaps xmm4, [rsp]
000078eb87ddf8f8  add rsp, 0x30
000078eb87ddf8fc  vmovaps xmm0, [rsp]
000078eb87ddf901  vmovaps xmm1, [rsp+0x10]
000078eb87ddf907  vmovaps xmm2, [rsp+0x20]
000078eb87ddf90d  vmovaps xmm3, [rsp+0x30]
000078eb87ddf913  vmovaps xmm5, [rsp+0x40]
000078eb87ddf919  vmovaps xmm6, [rsp+0x50]
000078eb87ddf91f  vmovaps xmm7, [rsp+0x60]
000078eb87ddf925  vmovaps xmm8, [rsp+0x70]
000078eb87ddf92b  vmovaps xmm9, [rsp+0x80]
000078eb87ddf934  vmovaps xmm10, [rsp+0x90]
000078eb87ddf93d  vmovaps xmm11, [rsp+0xA0]
000078eb87ddf946  vmovaps xmm12, [rsp+0xB0]
000078eb87ddf94f  vmovaps xmm13, [rsp+0xC0]
000078eb87ddf958  vmovaps xmm14, [rsp+0xD0]
000078eb87ddf961  vmovaps xmm15, [rsp+0xE0]
000078eb87ddf96a  add rsp, 0xF0
000078eb87ddf971  pop r11
000078eb87ddf973  pop r10
000078eb87ddf975  pop r9
000078eb87ddf977  pop r8
000078eb87ddf979  pop rsi
000078eb87ddf97a  pop rdi
000078eb87ddf97b  pop rdx
000078eb87ddf97c  pop rcx
000078eb87ddf97d  pop rax
000078eb87ddf97e  add rsp, 0x08
000078eb87ddf982  jmp 0x000078EB87DDC43D
000078eb87ddf987  sub rsp, 0x08
000078eb87ddf98b  push rax
000078eb87ddf98c  push rcx
000078eb87ddf98d  push rdx
000078eb87ddf98e  push rdi
000078eb87ddf98f  push rsi
000078eb87ddf990  push r8
000078eb87ddf992  push r9
000078eb87ddf994  push r10
000078eb87ddf996  push r11
000078eb87ddf998  sub rsp, 0xF0
000078eb87ddf99f  vmovaps [rsp], xmm0
000078eb87ddf9a4  vmovaps [rsp+0x10], xmm1
000078eb87ddf9aa  vmovaps [rsp+0x20], xmm2
000078eb87ddf9b0  vmovaps [rsp+0x30], xmm3
000078eb87ddf9b6  vmovaps [rsp+0x40], xmm4
000078eb87ddf9bc  vmovaps [rsp+0x50], xmm5
000078eb87ddf9c2  vmovaps [rsp+0x60], xmm6
000078eb87ddf9c8  vmovaps [rsp+0x70], xmm7
000078eb87ddf9ce  vmovaps [rsp+0x80], xmm8
000078eb87ddf9d7  vmovaps [rsp+0x90], xmm9
000078eb87ddf9e0  vmovaps [rsp+0xA0], xmm10
000078eb87ddf9e9  vmovaps [rsp+0xB0], xmm11
000078eb87ddf9f2  vmovaps [rsp+0xC0], xmm12
000078eb87ddf9fb  vmovaps [rsp+0xD0], xmm14
000078eb87ddfa04  vmovaps [rsp+0xE0], xmm15
000078eb87ddfa0d  sub rsp, 0x30
000078eb87ddfa11  movaps [rsp], xmm13
000078eb87ddfa16  movaps [rsp+0x10], xmm15
000078eb87ddfa1c  movaps [rsp+0x20], xmm9
000078eb87ddfa22  lea rdi, [rsp]
000078eb87ddfa26  mov esi, 0x00
000078eb87ddfa2b  mov rax, 0x61D341A71530
000078eb87ddfa35  call rax
000078eb87ddfa37  movaps xmm13, [rsp]
000078eb87ddfa3c  add rsp, 0x30
000078eb87ddfa40  vmovaps xmm0, [rsp]
000078eb87ddfa45  vmovaps xmm1, [rsp+0x10]
000078eb87ddfa4b  vmovaps xmm2, [rsp+0x20]
000078eb87ddfa51  vmovaps xmm3, [rsp+0x30]
000078eb87ddfa57  vmovaps xmm4, [rsp+0x40]
000078eb87ddfa5d  vmovaps xmm5, [rsp+0x50]
000078eb87ddfa63  vmovaps xmm6, [rsp+0x60]
000078eb87ddfa69  vmovaps xmm7, [rsp+0x70]
000078eb87ddfa6f  vmovaps xmm8, [rsp+0x80]
000078eb87ddfa78  vmovaps xmm9, [rsp+0x90]
000078eb87ddfa81  vmovaps xmm10, [rsp+0xA0]
000078eb87ddfa8a  vmovaps xmm11, [rsp+0xB0]
000078eb87ddfa93  vmovaps xmm12, [rsp+0xC0]
000078eb87ddfa9c  vmovaps xmm14, [rsp+0xD0]
000078eb87ddfaa5  vmovaps xmm15, [rsp+0xE0]
000078eb87ddfaae  add rsp, 0xF0
000078eb87ddfab5  pop r11
000078eb87ddfab7  pop r10
000078eb87ddfab9  pop r9
000078eb87ddfabb  pop r8
000078eb87ddfabd  pop rsi
000078eb87ddfabe  pop rdi
000078eb87ddfabf  pop rdx
000078eb87ddfac0  pop rcx
000078eb87ddfac1  pop rax
000078eb87ddfac2  add rsp, 0x08
000078eb87ddfac6  jmp 0x000078EB87DDC458
000078eb87ddfacb  sub rsp, 0x08
000078eb87ddfacf  push rax
000078eb87ddfad0  push rcx
000078eb87ddfad1  push rdx
000078eb87ddfad2  push rdi
000078eb87ddfad3  push rsi
000078eb87ddfad4  push r8
000078eb87ddfad6  push r9
000078eb87ddfad8  push r10
000078eb87ddfada  push r11
000078eb87ddfadc  sub rsp, 0xF0
000078eb87ddfae3  vmovaps [rsp], xmm0
000078eb87ddfae8  vmovaps [rsp+0x10], xmm1
000078eb87ddfaee  vmovaps [rsp+0x20], xmm2
000078eb87ddfaf4  vmovaps [rsp+0x30], xmm3
000078eb87ddfafa  vmovaps [rsp+0x40], xmm4
000078eb87ddfb00  vmovaps [rsp+0x50], xmm5
000078eb87ddfb06  vmovaps [rsp+0x60], xmm6
000078eb87ddfb0c  vmovaps [rsp+0x70], xmm7
000078eb87ddfb12  vmovaps [rsp+0x80], xmm8
000078eb87ddfb1b  vmovaps [rsp+0x90], xmm9
000078eb87ddfb24  vmovaps [rsp+0xA0], xmm10
000078eb87ddfb2d  vmovaps [rsp+0xB0], xmm11
000078eb87ddfb36  vmovaps [rsp+0xC0], xmm12
000078eb87ddfb3f  vmovaps [rsp+0xD0], xmm13
000078eb87ddfb48  vmovaps [rsp+0xE0], xmm14
000078eb87ddfb51  sub rsp, 0x30
000078eb87ddfb55  movaps [rsp], xmm15
000078eb87ddfb5a  movaps [rsp+0x10], xmm1
000078eb87ddfb5f  movaps [rsp+0x20], xmm5
000078eb87ddfb64  lea rdi, [rsp]
000078eb87ddfb68  mov esi, 0x00
000078eb87ddfb6d  mov rax, 0x61D341A71530
000078eb87ddfb77  call rax
000078eb87ddfb79  movaps xmm15, [rsp]
000078eb87ddfb7e  add rsp, 0x30
000078eb87ddfb82  vmovaps xmm0, [rsp]
000078eb87ddfb87  vmovaps xmm1, [rsp+0x10]
000078eb87ddfb8d  vmovaps xmm2, [rsp+0x20]
000078eb87ddfb93  vmovaps xmm3, [rsp+0x30]
000078eb87ddfb99  vmovaps xmm4, [rsp+0x40]
000078eb87ddfb9f  vmovaps xmm5, [rsp+0x50]
000078eb87ddfba5  vmovaps xmm6, [rsp+0x60]
000078eb87ddfbab  vmovaps xmm7, [rsp+0x70]
000078eb87ddfbb1  vmovaps xmm8, [rsp+0x80]
000078eb87ddfbba  vmovaps xmm9, [rsp+0x90]
000078eb87ddfbc3  vmovaps xmm10, [rsp+0xA0]
000078eb87ddfbcc  vmovaps xmm11, [rsp+0xB0]
000078eb87ddfbd5  vmovaps xmm12, [rsp+0xC0]
000078eb87ddfbde  vmovaps xmm13, [rsp+0xD0]
000078eb87ddfbe7  vmovaps xmm14, [rsp+0xE0]
000078eb87ddfbf0  add rsp, 0xF0
000078eb87ddfbf7  pop r11
000078eb87ddfbf9  pop r10
000078eb87ddfbfb  pop r9
000078eb87ddfbfd  pop r8
000078eb87ddfbff  pop rsi
000078eb87ddfc00  pop rdi
000078eb87ddfc01  pop rdx
000078eb87ddfc02  pop rcx
000078eb87ddfc03  pop rax
000078eb87ddfc04  add rsp, 0x08
000078eb87ddfc08  jmp 0x000078EB87DDC473
000078eb87ddfc0d  call 0x000078EB87CB52F0
000078eb87ddfc12  jmp 0x000078EB87DDC4CE
000078eb87ddfc17  sub rsp, 0x08
000078eb87ddfc1b  push rax
000078eb87ddfc1c  push rcx
000078eb87ddfc1d  push rdx
000078eb87ddfc1e  push rdi
000078eb87ddfc1f  push rsi
000078eb87ddfc20  push r8
000078eb87ddfc22  push r9
000078eb87ddfc24  push r10
000078eb87ddfc26  push r11
000078eb87ddfc28  sub rsp, 0xF0
000078eb87ddfc2f  vmovaps [rsp], xmm0
000078eb87ddfc34  vmovaps [rsp+0x10], xmm1
000078eb87ddfc3a  vmovaps [rsp+0x20], xmm2
000078eb87ddfc40  vmovaps [rsp+0x30], xmm3
000078eb87ddfc46  vmovaps [rsp+0x40], xmm4
000078eb87ddfc4c  vmovaps [rsp+0x50], xmm5
000078eb87ddfc52  vmovaps [rsp+0x60], xmm6
000078eb87ddfc58  vmovaps [rsp+0x70], xmm7
000078eb87ddfc5e  vmovaps [rsp+0x80], xmm8
000078eb87ddfc67  vmovaps [rsp+0x90], xmm10
000078eb87ddfc70  vmovaps [rsp+0xA0], xmm11
000078eb87ddfc79  vmovaps [rsp+0xB0], xmm12
000078eb87ddfc82  vmovaps [rsp+0xC0], xmm13
000078eb87ddfc8b  vmovaps [rsp+0xD0], xmm14
000078eb87ddfc94  vmovaps [rsp+0xE0], xmm15
000078eb87ddfc9d  sub rsp, 0x30
000078eb87ddfca1  movaps [rsp], xmm9
000078eb87ddfca6  movaps [rsp+0x10], xmm8
000078eb87ddfcac  movaps [rsp+0x20], xmm11
000078eb87ddfcb2  lea rdi, [rsp]
000078eb87ddfcb6  mov esi, 0x00
000078eb87ddfcbb  mov rax, 0x61D341A71530
000078eb87ddfcc5  call rax
000078eb87ddfcc7  movaps xmm9, [rsp]
000078eb87ddfccc  add rsp, 0x30
000078eb87ddfcd0  vmovaps xmm0, [rsp]
000078eb87ddfcd5  vmovaps xmm1, [rsp+0x10]
000078eb87ddfcdb  vmovaps xmm2, [rsp+0x20]
000078eb87ddfce1  vmovaps xmm3, [rsp+0x30]
000078eb87ddfce7  vmovaps xmm4, [rsp+0x40]
000078eb87ddfced  vmovaps xmm5, [rsp+0x50]
000078eb87ddfcf3  vmovaps xmm6, [rsp+0x60]
000078eb87ddfcf9  vmovaps xmm7, [rsp+0x70]
000078eb87ddfcff  vmovaps xmm8, [rsp+0x80]
000078eb87ddfd08  vmovaps xmm10, [rsp+0x90]
000078eb87ddfd11  vmovaps xmm11, [rsp+0xA0]
000078eb87ddfd1a  vmovaps xmm12, [rsp+0xB0]
000078eb87ddfd23  vmovaps xmm13, [rsp+0xC0]
000078eb87ddfd2c  vmovaps xmm14, [rsp+0xD0]
000078eb87ddfd35  vmovaps xmm15, [rsp+0xE0]
000078eb87ddfd3e  add rsp, 0xF0
000078eb87ddfd45  pop r11
000078eb87ddfd47  pop r10
000078eb87ddfd49  pop r9
000078eb87ddfd4b  pop r8
000078eb87ddfd4d  pop rsi
000078eb87ddfd4e  pop rdi
000078eb87ddfd4f  pop rdx
000078eb87ddfd50  pop rcx
000078eb87ddfd51  pop rax
000078eb87ddfd52  add rsp, 0x08
000078eb87ddfd56  jmp 0x000078EB87DDC505
000078eb87ddfd5b  sub rsp, 0x08
000078eb87ddfd5f  push rax
000078eb87ddfd60  push rcx
000078eb87ddfd61  push rdx
000078eb87ddfd62  push rdi
000078eb87ddfd63  push rsi
000078eb87ddfd64  push r8
000078eb87ddfd66  push r9
000078eb87ddfd68  push r10
000078eb87ddfd6a  push r11
000078eb87ddfd6c  sub rsp, 0xF0
000078eb87ddfd73  vmovaps [rsp], xmm0
000078eb87ddfd78  vmovaps [rsp+0x10], xmm1
000078eb87ddfd7e  vmovaps [rsp+0x20], xmm2
000078eb87ddfd84  vmovaps [rsp+0x30], xmm3
000078eb87ddfd8a  vmovaps [rsp+0x40], xmm4
000078eb87ddfd90  vmovaps [rsp+0x50], xmm5
000078eb87ddfd96  vmovaps [rsp+0x60], xmm6
000078eb87ddfd9c  vmovaps [rsp+0x70], xmm7
000078eb87ddfda2  vmovaps [rsp+0x80], xmm8
000078eb87ddfdab  vmovaps [rsp+0x90], xmm9
000078eb87ddfdb4  vmovaps [rsp+0xA0], xmm10
000078eb87ddfdbd  vmovaps [rsp+0xB0], xmm12
000078eb87ddfdc6  vmovaps [rsp+0xC0], xmm13
000078eb87ddfdcf  vmovaps [rsp+0xD0], xmm14
000078eb87ddfdd8  vmovaps [rsp+0xE0], xmm15
000078eb87ddfde1  sub rsp, 0x30
000078eb87ddfde5  movaps [rsp], xmm11
000078eb87ddfdea  movaps [rsp+0x10], xmm10
000078eb87ddfdf0  movaps [rsp+0x20], xmm6
000078eb87ddfdf5  lea rdi, [rsp]
000078eb87ddfdf9  mov esi, 0x00
000078eb87ddfdfe  mov rax, 0x61D341A71530
000078eb87ddfe08  call rax
000078eb87ddfe0a  movaps xmm11, [rsp]
000078eb87ddfe0f  add rsp, 0x30
000078eb87ddfe13  vmovaps xmm0, [rsp]
000078eb87ddfe18  vmovaps xmm1, [rsp+0x10]
000078eb87ddfe1e  vmovaps xmm2, [rsp+0x20]
000078eb87ddfe24  vmovaps xmm3, [rsp+0x30]
000078eb87ddfe2a  vmovaps xmm4, [rsp+0x40]
000078eb87ddfe30  vmovaps xmm5, [rsp+0x50]
000078eb87ddfe36  vmovaps xmm6, [rsp+0x60]
000078eb87ddfe3c  vmovaps xmm7, [rsp+0x70]
000078eb87ddfe42  vmovaps xmm8, [rsp+0x80]
000078eb87ddfe4b  vmovaps xmm9, [rsp+0x90]
000078eb87ddfe54  vmovaps xmm10, [rsp+0xA0]
000078eb87ddfe5d  vmovaps xmm12, [rsp+0xB0]
000078eb87ddfe66  vmovaps xmm13, [rsp+0xC0]
000078eb87ddfe6f  vmovaps xmm14, [rsp+0xD0]
000078eb87ddfe78  vmovaps xmm15, [rsp+0xE0]
000078eb87ddfe81  add rsp, 0xF0
000078eb87ddfe88  pop r11
000078eb87ddfe8a  pop r10
000078eb87ddfe8c  pop r9
000078eb87ddfe8e  pop r8
000078eb87ddfe90  pop rsi
000078eb87ddfe91  pop rdi
000078eb87ddfe92  pop rdx
000078eb87ddfe93  pop rcx
000078eb87ddfe94  pop rax
000078eb87ddfe95  add rsp, 0x08
000078eb87ddfe99  jmp 0x000078EB87DDC520
000078eb87ddfe9e  sub rsp, 0x08
000078eb87ddfea2  push rax
000078eb87ddfea3  push rcx
000078eb87ddfea4  push rdx
000078eb87ddfea5  push rdi
000078eb87ddfea6  push rsi
000078eb87ddfea7  push r8
000078eb87ddfea9  push r9
000078eb87ddfeab  push r10
000078eb87ddfead  push r11
000078eb87ddfeaf  sub rsp, 0xF0
000078eb87ddfeb6  vmovaps [rsp], xmm0
000078eb87ddfebb  vmovaps [rsp+0x10], xmm1
000078eb87ddfec1  vmovaps [rsp+0x20], xmm2
000078eb87ddfec7  vmovaps [rsp+0x30], xmm3
000078eb87ddfecd  vmovaps [rsp+0x40], xmm4
000078eb87ddfed3  vmovaps [rsp+0x50], xmm5
000078eb87ddfed9  vmovaps [rsp+0x60], xmm6
000078eb87ddfedf  vmovaps [rsp+0x70], xmm7
000078eb87ddfee5  vmovaps [rsp+0x80], xmm8
000078eb87ddfeee  vmovaps [rsp+0x90], xmm9
000078eb87ddfef7  vmovaps [rsp+0xA0], xmm11
000078eb87ddff00  vmovaps [rsp+0xB0], xmm12
000078eb87ddff09  vmovaps [rsp+0xC0], xmm13
000078eb87ddff12  vmovaps [rsp+0xD0], xmm14
000078eb87ddff1b  vmovaps [rsp+0xE0], xmm15
000078eb87ddff24  sub rsp, 0x30
000078eb87ddff28  movaps [rsp], xmm10
000078eb87ddff2d  movaps [rsp+0x10], xmm14
000078eb87ddff33  movaps [rsp+0x20], xmm4
000078eb87ddff38  lea rdi, [rsp]
000078eb87ddff3c  mov esi, 0x00
000078eb87ddff41  mov rax, 0x61D341A71530
000078eb87ddff4b  call rax
000078eb87ddff4d  movaps xmm10, [rsp]
000078eb87ddff52  add rsp, 0x30
000078eb87ddff56  vmovaps xmm0, [rsp]
000078eb87ddff5b  vmovaps xmm1, [rsp+0x10]
000078eb87ddff61  vmovaps xmm2, [rsp+0x20]
000078eb87ddff67  vmovaps xmm3, [rsp+0x30]
000078eb87ddff6d  vmovaps xmm4, [rsp+0x40]
000078eb87ddff73  vmovaps xmm5, [rsp+0x50]
000078eb87ddff79  vmovaps xmm6, [rsp+0x60]
000078eb87ddff7f  vmovaps xmm7, [rsp+0x70]
000078eb87ddff85  vmovaps xmm8, [rsp+0x80]
000078eb87ddff8e  vmovaps xmm9, [rsp+0x90]
000078eb87ddff97  vmovaps xmm11, [rsp+0xA0]
000078eb87ddffa0  vmovaps xmm12, [rsp+0xB0]
000078eb87ddffa9  vmovaps xmm13, [rsp+0xC0]
000078eb87ddffb2  vmovaps xmm14, [rsp+0xD0]
000078eb87ddffbb  vmovaps xmm15, [rsp+0xE0]
000078eb87ddffc4  add rsp, 0xF0
000078eb87ddffcb  pop r11
000078eb87ddffcd  pop r10
000078eb87ddffcf  pop r9
000078eb87ddffd1  pop r8
000078eb87ddffd3  pop rsi
000078eb87ddffd4  pop rdi
000078eb87ddffd5  pop rdx
000078eb87ddffd6  pop rcx
000078eb87ddffd7  pop rax
000078eb87ddffd8  add rsp, 0x08
000078eb87ddffdc  jmp 0x000078EB87DDC53B
000078eb87ddffe1  sub rsp, 0x08
000078eb87ddffe5  push rax
000078eb87ddffe6  push rcx
000078eb87ddffe7  push rdx
000078eb87ddffe8  push rdi
000078eb87ddffe9  push rsi
000078eb87ddffea  push r8
000078eb87ddffec  push r9
000078eb87ddffee  push r10
000078eb87ddfff0  push r11
000078eb87ddfff2  sub rsp, 0xF0
000078eb87ddfff9  vmovaps [rsp], xmm0
000078eb87ddfffe  vmovaps [rsp+0x10], xmm1
000078eb87de0004  vmovaps [rsp+0x20], xmm2
000078eb87de000a  vmovaps [rsp+0x30], xmm3
000078eb87de0010  vmovaps [rsp+0x40], xmm4
000078eb87de0016  vmovaps [rsp+0x50], xmm5
000078eb87de001c  vmovaps [rsp+0x60], xmm6
000078eb87de0022  vmovaps [rsp+0x70], xmm7
000078eb87de0028  vmovaps [rsp+0x80], xmm9
000078eb87de0031  vmovaps [rsp+0x90], xmm10
000078eb87de003a  vmovaps [rsp+0xA0], xmm11
000078eb87de0043  vmovaps [rsp+0xB0], xmm12
000078eb87de004c  vmovaps [rsp+0xC0], xmm13
000078eb87de0055  vmovaps [rsp+0xD0], xmm14
000078eb87de005e  vmovaps [rsp+0xE0], xmm15
000078eb87de0067  sub rsp, 0x30
000078eb87de006b  movaps [rsp], xmm8
000078eb87de0070  movaps [rsp+0x10], xmm1
000078eb87de0075  movaps [rsp+0x20], xmm14
000078eb87de007b  lea rdi, [rsp]
000078eb87de007f  mov esi, 0x00
000078eb87de0084  mov rax, 0x61D341A71530
000078eb87de008e  call rax
000078eb87de0090  movaps xmm8, [rsp]
000078eb87de0095  add rsp, 0x30
000078eb87de0099  vmovaps xmm0, [rsp]
000078eb87de009e  vmovaps xmm1, [rsp+0x10]
000078eb87de00a4  vmovaps xmm2, [rsp+0x20]
000078eb87de00aa  vmovaps xmm3, [rsp+0x30]
000078eb87de00b0  vmovaps xmm4, [rsp+0x40]
000078eb87de00b6  vmovaps xmm5, [rsp+0x50]
000078eb87de00bc  vmovaps xmm6, [rsp+0x60]
000078eb87de00c2  vmovaps xmm7, [rsp+0x70]
000078eb87de00c8  vmovaps xmm9, [rsp+0x80]
000078eb87de00d1  vmovaps xmm10, [rsp+0x90]
000078eb87de00da  vmovaps xmm11, [rsp+0xA0]
000078eb87de00e3  vmovaps xmm12, [rsp+0xB0]
000078eb87de00ec  vmovaps xmm13, [rsp+0xC0]
000078eb87de00f5  vmovaps xmm14, [rsp+0xD0]
000078eb87de00fe  vmovaps xmm15, [rsp+0xE0]
000078eb87de0107  add rsp, 0xF0
000078eb87de010e  pop r11
000078eb87de0110  pop r10
000078eb87de0112  pop r9
000078eb87de0114  pop r8
000078eb87de0116  pop rsi
000078eb87de0117  pop rdi
000078eb87de0118  pop rdx
000078eb87de0119  pop rcx
000078eb87de011a  pop rax
000078eb87de011b  add rsp, 0x08
000078eb87de011f  jmp 0x000078EB87DDC561
000078eb87de0124  sub rsp, 0x08
000078eb87de0128  push rax
000078eb87de0129  push rcx
000078eb87de012a  push rdx
000078eb87de012b  push rdi
000078eb87de012c  push rsi
000078eb87de012d  push r8
000078eb87de012f  push r9
000078eb87de0131  push r10
000078eb87de0133  push r11
000078eb87de0135  sub rsp, 0xF0
000078eb87de013c  vmovaps [rsp], xmm0
000078eb87de0141  vmovaps [rsp+0x10], xmm1
000078eb87de0147  vmovaps [rsp+0x20], xmm2
000078eb87de014d  vmovaps [rsp+0x30], xmm3
000078eb87de0153  vmovaps [rsp+0x40], xmm4
000078eb87de0159  vmovaps [rsp+0x50], xmm5
000078eb87de015f  vmovaps [rsp+0x60], xmm7
000078eb87de0165  vmovaps [rsp+0x70], xmm8
000078eb87de016b  vmovaps [rsp+0x80], xmm9
000078eb87de0174  vmovaps [rsp+0x90], xmm10
000078eb87de017d  vmovaps [rsp+0xA0], xmm11
000078eb87de0186  vmovaps [rsp+0xB0], xmm12
000078eb87de018f  vmovaps [rsp+0xC0], xmm13
000078eb87de0198  vmovaps [rsp+0xD0], xmm14
000078eb87de01a1  vmovaps [rsp+0xE0], xmm15
000078eb87de01aa  sub rsp, 0x30
000078eb87de01ae  movaps [rsp], xmm6
000078eb87de01b2  movaps [rsp+0x10], xmm1
000078eb87de01b7  movaps [rsp+0x20], xmm14
000078eb87de01bd  lea rdi, [rsp]
000078eb87de01c1  mov esi, 0x00
000078eb87de01c6  mov rax, 0x61D341A71530
000078eb87de01d0  call rax
000078eb87de01d2  movaps xmm6, [rsp]
000078eb87de01d6  add rsp, 0x30
000078eb87de01da  vmovaps xmm0, [rsp]
000078eb87de01df  vmovaps xmm1, [rsp+0x10]
000078eb87de01e5  vmovaps xmm2, [rsp+0x20]
000078eb87de01eb  vmovaps xmm3, [rsp+0x30]
000078eb87de01f1  vmovaps xmm4, [rsp+0x40]
000078eb87de01f7  vmovaps xmm5, [rsp+0x50]
000078eb87de01fd  vmovaps xmm7, [rsp+0x60]
000078eb87de0203  vmovaps xmm8, [rsp+0x70]
000078eb87de0209  vmovaps xmm9, [rsp+0x80]
000078eb87de0212  vmovaps xmm10, [rsp+0x90]
000078eb87de021b  vmovaps xmm11, [rsp+0xA0]
000078eb87de0224  vmovaps xmm12, [rsp+0xB0]
000078eb87de022d  vmovaps xmm13, [rsp+0xC0]
000078eb87de0236  vmovaps xmm14, [rsp+0xD0]
000078eb87de023f  vmovaps xmm15, [rsp+0xE0]
000078eb87de0248  add rsp, 0xF0
000078eb87de024f  pop r11
000078eb87de0251  pop r10
000078eb87de0253  pop r9
000078eb87de0255  pop r8
000078eb87de0257  pop rsi
000078eb87de0258  pop rdi
000078eb87de0259  pop rdx
000078eb87de025a  pop rcx
000078eb87de025b  pop rax
000078eb87de025c  add rsp, 0x08
000078eb87de0260  jmp 0x000078EB87DDC58D
000078eb87de0265  sub rsp, 0x08
000078eb87de0269  push rax
000078eb87de026a  push rcx
000078eb87de026b  push rdx
000078eb87de026c  push rdi
000078eb87de026d  push rsi
000078eb87de026e  push r8
000078eb87de0270  push r9
000078eb87de0272  push r10
000078eb87de0274  push r11
000078eb87de0276  sub rsp, 0xF0
000078eb87de027d  vmovaps [rsp], xmm0
000078eb87de0282  vmovaps [rsp+0x10], xmm1
000078eb87de0288  vmovaps [rsp+0x20], xmm2
000078eb87de028e  vmovaps [rsp+0x30], xmm3
000078eb87de0294  vmovaps [rsp+0x40], xmm4
000078eb87de029a  vmovaps [rsp+0x50], xmm5
000078eb87de02a0  vmovaps [rsp+0x60], xmm6
000078eb87de02a6  vmovaps [rsp+0x70], xmm7
000078eb87de02ac  vmovaps [rsp+0x80], xmm8
000078eb87de02b5  vmovaps [rsp+0x90], xmm9
000078eb87de02be  vmovaps [rsp+0xA0], xmm10
000078eb87de02c7  vmovaps [rsp+0xB0], xmm11
000078eb87de02d0  vmovaps [rsp+0xC0], xmm12
000078eb87de02d9  vmovaps [rsp+0xD0], xmm13
000078eb87de02e2  vmovaps [rsp+0xE0], xmm15
000078eb87de02eb  sub rsp, 0x30
000078eb87de02ef  movaps [rsp], xmm14
000078eb87de02f4  movaps [rsp+0x10], xmm12
000078eb87de02fa  movaps [rsp+0x20], xmm1
000078eb87de02ff  lea rdi, [rsp]
000078eb87de0303  mov esi, 0x00
000078eb87de0308  mov rax, 0x61D341A71530
000078eb87de0312  call rax
000078eb87de0314  movaps xmm14, [rsp]
000078eb87de0319  add rsp, 0x30
000078eb87de031d  vmovaps xmm0, [rsp]
000078eb87de0322  vmovaps xmm1, [rsp+0x10]
000078eb87de0328  vmovaps xmm2, [rsp+0x20]
000078eb87de032e  vmovaps xmm3, [rsp+0x30]
000078eb87de0334  vmovaps xmm4, [rsp+0x40]
000078eb87de033a  vmovaps xmm5, [rsp+0x50]
000078eb87de0340  vmovaps xmm6, [rsp+0x60]
000078eb87de0346  vmovaps xmm7, [rsp+0x70]
000078eb87de034c  vmovaps xmm8, [rsp+0x80]
000078eb87de0355  vmovaps xmm9, [rsp+0x90]
000078eb87de035e  vmovaps xmm10, [rsp+0xA0]
000078eb87de0367  vmovaps xmm11, [rsp+0xB0]
000078eb87de0370  vmovaps xmm12, [rsp+0xC0]
000078eb87de0379  vmovaps xmm13, [rsp+0xD0]
000078eb87de0382  vmovaps xmm15, [rsp+0xE0]
000078eb87de038b  add rsp, 0xF0
000078eb87de0392  pop r11
000078eb87de0394  pop r10
000078eb87de0396  pop r9
000078eb87de0398  pop r8
000078eb87de039a  pop rsi
000078eb87de039b  pop rdi
000078eb87de039c  pop rdx
000078eb87de039d  pop rcx
000078eb87de039e  pop rax
000078eb87de039f  add rsp, 0x08
000078eb87de03a3  jmp 0x000078EB87DDC5B3
000078eb87de03a8  sub rsp, 0x08
000078eb87de03ac  push rax
000078eb87de03ad  push rcx
000078eb87de03ae  push rdx
000078eb87de03af  push rdi
000078eb87de03b0  push rsi
000078eb87de03b1  push r8
000078eb87de03b3  push r9
000078eb87de03b5  push r10
000078eb87de03b7  push r11
000078eb87de03b9  sub rsp, 0xF0
000078eb87de03c0  vmovaps [rsp], xmm0
000078eb87de03c5  vmovaps [rsp+0x10], xmm2
000078eb87de03cb  vmovaps [rsp+0x20], xmm3
000078eb87de03d1  vmovaps [rsp+0x30], xmm4
000078eb87de03d7  vmovaps [rsp+0x40], xmm5
000078eb87de03dd  vmovaps [rsp+0x50], xmm6
000078eb87de03e3  vmovaps [rsp+0x60], xmm7
000078eb87de03e9  vmovaps [rsp+0x70], xmm8
000078eb87de03ef  vmovaps [rsp+0x80], xmm9
000078eb87de03f8  vmovaps [rsp+0x90], xmm10
000078eb87de0401  vmovaps [rsp+0xA0], xmm11
000078eb87de040a  vmovaps [rsp+0xB0], xmm12
000078eb87de0413  vmovaps [rsp+0xC0], xmm13
000078eb87de041c  vmovaps [rsp+0xD0], xmm14
000078eb87de0425  vmovaps [rsp+0xE0], xmm15
000078eb87de042e  sub rsp, 0x30
000078eb87de0432  movaps [rsp], xmm1
000078eb87de0436  movaps [rsp+0x10], xmm13
000078eb87de043c  movaps [rsp+0x20], xmm9
000078eb87de0442  lea rdi, [rsp]
000078eb87de0446  mov esi, 0x00
000078eb87de044b  mov rax, 0x61D341A71530
000078eb87de0455  call rax
000078eb87de0457  movaps xmm1, [rsp]
000078eb87de045b  add rsp, 0x30
000078eb87de045f  vmovaps xmm0, [rsp]
000078eb87de0464  vmovaps xmm2, [rsp+0x10]
000078eb87de046a  vmovaps xmm3, [rsp+0x20]
000078eb87de0470  vmovaps xmm4, [rsp+0x30]
000078eb87de0476  vmovaps xmm5, [rsp+0x40]
000078eb87de047c  vmovaps xmm6, [rsp+0x50]
000078eb87de0482  vmovaps xmm7, [rsp+0x60]
000078eb87de0488  vmovaps xmm8, [rsp+0x70]
000078eb87de048e  vmovaps xmm9, [rsp+0x80]
000078eb87de0497  vmovaps xmm10, [rsp+0x90]
000078eb87de04a0  vmovaps xmm11, [rsp+0xA0]
000078eb87de04a9  vmovaps xmm12, [rsp+0xB0]
000078eb87de04b2  vmovaps xmm13, [rsp+0xC0]
000078eb87de04bb  vmovaps xmm14, [rsp+0xD0]
000078eb87de04c4  vmovaps xmm15, [rsp+0xE0]
000078eb87de04cd  add rsp, 0xF0
000078eb87de04d4  pop r11
000078eb87de04d6  pop r10
000078eb87de04d8  pop r9
000078eb87de04da  pop r8
000078eb87de04dc  pop rsi
000078eb87de04dd  pop rdi
000078eb87de04de  pop rdx
000078eb87de04df  pop rcx
000078eb87de04e0  pop rax
000078eb87de04e1  add rsp, 0x08
000078eb87de04e5  jmp 0x000078EB87DDC5CD
000078eb87de04ea  sub rsp, 0x08
000078eb87de04ee  push rax
000078eb87de04ef  push rcx
000078eb87de04f0  push rdx
000078eb87de04f1  push rdi
000078eb87de04f2  push rsi
000078eb87de04f3  push r8
000078eb87de04f5  push r9
000078eb87de04f7  push r10
000078eb87de04f9  push r11
000078eb87de04fb  sub rsp, 0xF0
000078eb87de0502  vmovaps [rsp], xmm0
000078eb87de0507  vmovaps [rsp+0x10], xmm1
000078eb87de050d  vmovaps [rsp+0x20], xmm2
000078eb87de0513  vmovaps [rsp+0x30], xmm3
000078eb87de0519  vmovaps [rsp+0x40], xmm4
000078eb87de051f  vmovaps [rsp+0x50], xmm5
000078eb87de0525  vmovaps [rsp+0x60], xmm6
000078eb87de052b  vmovaps [rsp+0x70], xmm7
000078eb87de0531  vmovaps [rsp+0x80], xmm8
000078eb87de053a  vmovaps [rsp+0x90], xmm9
000078eb87de0543  vmovaps [rsp+0xA0], xmm10
000078eb87de054c  vmovaps [rsp+0xB0], xmm11
000078eb87de0555  vmovaps [rsp+0xC0], xmm13
000078eb87de055e  vmovaps [rsp+0xD0], xmm14
000078eb87de0567  vmovaps [rsp+0xE0], xmm15
000078eb87de0570  sub rsp, 0x30
000078eb87de0574  movaps [rsp], xmm12
000078eb87de0579  movaps [rsp+0x10], xmm7
000078eb87de057e  movaps [rsp+0x20], xmm13
000078eb87de0584  lea rdi, [rsp]
000078eb87de0588  mov esi, 0x00
000078eb87de058d  mov rax, 0x61D341A71530
000078eb87de0597  call rax
000078eb87de0599  movaps xmm12, [rsp]
000078eb87de059e  add rsp, 0x30
000078eb87de05a2  vmovaps xmm0, [rsp]
000078eb87de05a7  vmovaps xmm1, [rsp+0x10]
000078eb87de05ad  vmovaps xmm2, [rsp+0x20]
000078eb87de05b3  vmovaps xmm3, [rsp+0x30]
000078eb87de05b9  vmovaps xmm4, [rsp+0x40]
000078eb87de05bf  vmovaps xmm5, [rsp+0x50]
000078eb87de05c5  vmovaps xmm6, [rsp+0x60]
000078eb87de05cb  vmovaps xmm7, [rsp+0x70]
000078eb87de05d1  vmovaps xmm8, [rsp+0x80]
000078eb87de05da  vmovaps xmm9, [rsp+0x90]
000078eb87de05e3  vmovaps xmm10, [rsp+0xA0]
000078eb87de05ec  vmovaps xmm11, [rsp+0xB0]
000078eb87de05f5  vmovaps xmm13, [rsp+0xC0]
000078eb87de05fe  vmovaps xmm14, [rsp+0xD0]
000078eb87de0607  vmovaps xmm15, [rsp+0xE0]
000078eb87de0610  add rsp, 0xF0
000078eb87de0617  pop r11
000078eb87de0619  pop r10
000078eb87de061b  pop r9
000078eb87de061d  pop r8
000078eb87de061f  pop rsi
000078eb87de0620  pop rdi
000078eb87de0621  pop rdx
000078eb87de0622  pop rcx
000078eb87de0623  pop rax
000078eb87de0624  add rsp, 0x08
000078eb87de0628  jmp 0x000078EB87DDC5F4
000078eb87de062d  sub rsp, 0x08
000078eb87de0631  push rax
000078eb87de0632  push rcx
000078eb87de0633  push rdx
000078eb87de0634  push rdi
000078eb87de0635  push rsi
000078eb87de0636  push r8
000078eb87de0638  push r9
000078eb87de063a  push r10
000078eb87de063c  push r11
000078eb87de063e  sub rsp, 0xF0
000078eb87de0645  vmovaps [rsp], xmm0
000078eb87de064a  vmovaps [rsp+0x10], xmm1
000078eb87de0650  vmovaps [rsp+0x20], xmm2
000078eb87de0656  vmovaps [rsp+0x30], xmm3
000078eb87de065c  vmovaps [rsp+0x40], xmm4
000078eb87de0662  vmovaps [rsp+0x50], xmm5
000078eb87de0668  vmovaps [rsp+0x60], xmm6
000078eb87de066e  vmovaps [rsp+0x70], xmm7
000078eb87de0674  vmovaps [rsp+0x80], xmm8
000078eb87de067d  vmovaps [rsp+0x90], xmm9
000078eb87de0686  vmovaps [rsp+0xA0], xmm10
000078eb87de068f  vmovaps [rsp+0xB0], xmm11
000078eb87de0698  vmovaps [rsp+0xC0], xmm12
000078eb87de06a1  vmovaps [rsp+0xD0], xmm14
000078eb87de06aa  vmovaps [rsp+0xE0], xmm15
000078eb87de06b3  sub rsp, 0x30
000078eb87de06b7  movaps [rsp], xmm13
000078eb87de06bc  movaps [rsp+0x10], xmm15
000078eb87de06c2  movaps [rsp+0x20], xmm8
000078eb87de06c8  lea rdi, [rsp]
000078eb87de06cc  mov esi, 0x00
000078eb87de06d1  mov rax, 0x61D341A71530
000078eb87de06db  call rax
000078eb87de06dd  movaps xmm13, [rsp]
000078eb87de06e2  add rsp, 0x30
000078eb87de06e6  vmovaps xmm0, [rsp]
000078eb87de06eb  vmovaps xmm1, [rsp+0x10]
000078eb87de06f1  vmovaps xmm2, [rsp+0x20]
000078eb87de06f7  vmovaps xmm3, [rsp+0x30]
000078eb87de06fd  vmovaps xmm4, [rsp+0x40]
000078eb87de0703  vmovaps xmm5, [rsp+0x50]
000078eb87de0709  vmovaps xmm6, [rsp+0x60]
000078eb87de070f  vmovaps xmm7, [rsp+0x70]
000078eb87de0715  vmovaps xmm8, [rsp+0x80]
000078eb87de071e  vmovaps xmm9, [rsp+0x90]
000078eb87de0727  vmovaps xmm10, [rsp+0xA0]
000078eb87de0730  vmovaps xmm11, [rsp+0xB0]
000078eb87de0739  vmovaps xmm12, [rsp+0xC0]
000078eb87de0742  vmovaps xmm14, [rsp+0xD0]
000078eb87de074b  vmovaps xmm15, [rsp+0xE0]
000078eb87de0754  add rsp, 0xF0
000078eb87de075b  pop r11
000078eb87de075d  pop r10
000078eb87de075f  pop r9
000078eb87de0761  pop r8
000078eb87de0763  pop rsi
000078eb87de0764  pop rdi
000078eb87de0765  pop rdx
000078eb87de0766  pop rcx
000078eb87de0767  pop rax
000078eb87de0768  add rsp, 0x08
000078eb87de076c  jmp 0x000078EB87DDC60F
000078eb87de0771  sub rsp, 0x08
000078eb87de0775  push rax
000078eb87de0776  push rcx
000078eb87de0777  push rdx
000078eb87de0778  push rdi
000078eb87de0779  push rsi
000078eb87de077a  push r8
000078eb87de077c  push r9
000078eb87de077e  push r10
000078eb87de0780  push r11
000078eb87de0782  sub rsp, 0xF0
000078eb87de0789  vmovaps [rsp], xmm0
000078eb87de078e  vmovaps [rsp+0x10], xmm1
000078eb87de0794  vmovaps [rsp+0x20], xmm2
000078eb87de079a  vmovaps [rsp+0x30], xmm3
000078eb87de07a0  vmovaps [rsp+0x40], xmm4
000078eb87de07a6  vmovaps [rsp+0x50], xmm5
000078eb87de07ac  vmovaps [rsp+0x60], xmm6
000078eb87de07b2  vmovaps [rsp+0x70], xmm7
000078eb87de07b8  vmovaps [rsp+0x80], xmm9
000078eb87de07c1  vmovaps [rsp+0x90], xmm10
000078eb87de07ca  vmovaps [rsp+0xA0], xmm11
000078eb87de07d3  vmovaps [rsp+0xB0], xmm12
000078eb87de07dc  vmovaps [rsp+0xC0], xmm13
000078eb87de07e5  vmovaps [rsp+0xD0], xmm14
000078eb87de07ee  vmovaps [rsp+0xE0], xmm15
000078eb87de07f7  sub rsp, 0x30
000078eb87de07fb  movaps [rsp], xmm8
000078eb87de0800  movaps [rsp+0x10], xmm15
000078eb87de0806  movaps [rsp+0x20], xmm9
000078eb87de080c  lea rdi, [rsp]
000078eb87de0810  mov esi, 0x00
000078eb87de0815  mov rax, 0x61D341A71530
000078eb87de081f  call rax
000078eb87de0821  movaps xmm8, [rsp]
000078eb87de0826  add rsp, 0x30
000078eb87de082a  vmovaps xmm0, [rsp]
000078eb87de082f  vmovaps xmm1, [rsp+0x10]
000078eb87de0835  vmovaps xmm2, [rsp+0x20]
000078eb87de083b  vmovaps xmm3, [rsp+0x30]
000078eb87de0841  vmovaps xmm4, [rsp+0x40]
000078eb87de0847  vmovaps xmm5, [rsp+0x50]
000078eb87de084d  vmovaps xmm6, [rsp+0x60]
000078eb87de0853  vmovaps xmm7, [rsp+0x70]
000078eb87de0859  vmovaps xmm9, [rsp+0x80]
000078eb87de0862  vmovaps xmm10, [rsp+0x90]
000078eb87de086b  vmovaps xmm11, [rsp+0xA0]
000078eb87de0874  vmovaps xmm12, [rsp+0xB0]
000078eb87de087d  vmovaps xmm13, [rsp+0xC0]
000078eb87de0886  vmovaps xmm14, [rsp+0xD0]
000078eb87de088f  vmovaps xmm15, [rsp+0xE0]
000078eb87de0898  add rsp, 0xF0
000078eb87de089f  pop r11
000078eb87de08a1  pop r10
000078eb87de08a3  pop r9
000078eb87de08a5  pop r8
000078eb87de08a7  pop rsi
000078eb87de08a8  pop rdi
000078eb87de08a9  pop rdx
000078eb87de08aa  pop rcx
000078eb87de08ab  pop rax
000078eb87de08ac  add rsp, 0x08
000078eb87de08b0  jmp 0x000078EB87DDC63D
000078eb87de08b5  sub rsp, 0x08
000078eb87de08b9  push rax
000078eb87de08ba  push rcx
000078eb87de08bb  push rdx
000078eb87de08bc  push rdi
000078eb87de08bd  push rsi
000078eb87de08be  push r8
000078eb87de08c0  push r9
000078eb87de08c2  push r10
000078eb87de08c4  push r11
000078eb87de08c6  sub rsp, 0xF0
000078eb87de08cd  vmovaps [rsp], xmm0
000078eb87de08d2  vmovaps [rsp+0x10], xmm1
000078eb87de08d8  vmovaps [rsp+0x20], xmm2
000078eb87de08de  vmovaps [rsp+0x30], xmm3
000078eb87de08e4  vmovaps [rsp+0x40], xmm4
000078eb87de08ea  vmovaps [rsp+0x50], xmm5
000078eb87de08f0  vmovaps [rsp+0x60], xmm6
000078eb87de08f6  vmovaps [rsp+0x70], xmm7
000078eb87de08fc  vmovaps [rsp+0x80], xmm8
000078eb87de0905  vmovaps [rsp+0x90], xmm9
000078eb87de090e  vmovaps [rsp+0xA0], xmm10
000078eb87de0917  vmovaps [rsp+0xB0], xmm11
000078eb87de0920  vmovaps [rsp+0xC0], xmm12
000078eb87de0929  vmovaps [rsp+0xD0], xmm13
000078eb87de0932  vmovaps [rsp+0xE0], xmm14
000078eb87de093b  sub rsp, 0x30
000078eb87de093f  movaps [rsp], xmm15
000078eb87de0944  movaps [rsp+0x10], xmm11
000078eb87de094a  movaps [rsp+0x20], xmm6
000078eb87de094f  lea rdi, [rsp]
000078eb87de0953  mov esi, 0x00
000078eb87de0958  mov rax, 0x61D341A71530
000078eb87de0962  call rax
000078eb87de0964  movaps xmm15, [rsp]
000078eb87de0969  add rsp, 0x30
000078eb87de096d  vmovaps xmm0, [rsp]
000078eb87de0972  vmovaps xmm1, [rsp+0x10]
000078eb87de0978  vmovaps xmm2, [rsp+0x20]
000078eb87de097e  vmovaps xmm3, [rsp+0x30]
000078eb87de0984  vmovaps xmm4, [rsp+0x40]
000078eb87de098a  vmovaps xmm5, [rsp+0x50]
000078eb87de0990  vmovaps xmm6, [rsp+0x60]
000078eb87de0996  vmovaps xmm7, [rsp+0x70]
000078eb87de099c  vmovaps xmm8, [rsp+0x80]
000078eb87de09a5  vmovaps xmm9, [rsp+0x90]
000078eb87de09ae  vmovaps xmm10, [rsp+0xA0]
000078eb87de09b7  vmovaps xmm11, [rsp+0xB0]
000078eb87de09c0  vmovaps xmm12, [rsp+0xC0]
000078eb87de09c9  vmovaps xmm13, [rsp+0xD0]
000078eb87de09d2  vmovaps xmm14, [rsp+0xE0]
000078eb87de09db  add rsp, 0xF0
000078eb87de09e2  pop r11
000078eb87de09e4  pop r10
000078eb87de09e6  pop r9
000078eb87de09e8  pop r8
000078eb87de09ea  pop rsi
000078eb87de09eb  pop rdi
000078eb87de09ec  pop rdx
000078eb87de09ed  pop rcx
000078eb87de09ee  pop rax
000078eb87de09ef  add rsp, 0x08
000078eb87de09f3  jmp 0x000078EB87DDC658
000078eb87de09f8  sub rsp, 0x08
000078eb87de09fc  push rax
000078eb87de09fd  push rcx
000078eb87de09fe  push rdx
000078eb87de09ff  push rdi
000078eb87de0a00  push rsi
000078eb87de0a01  push r8
000078eb87de0a03  push r9
000078eb87de0a05  push r10
000078eb87de0a07  push r11
000078eb87de0a09  sub rsp, 0xF0
000078eb87de0a10  vmovaps [rsp], xmm0
000078eb87de0a15  vmovaps [rsp+0x10], xmm1
000078eb87de0a1b  vmovaps [rsp+0x20], xmm2
000078eb87de0a21  vmovaps [rsp+0x30], xmm3
000078eb87de0a27  vmovaps [rsp+0x40], xmm4
000078eb87de0a2d  vmovaps [rsp+0x50], xmm5
000078eb87de0a33  vmovaps [rsp+0x60], xmm6
000078eb87de0a39  vmovaps [rsp+0x70], xmm8
000078eb87de0a3f  vmovaps [rsp+0x80], xmm9
000078eb87de0a48  vmovaps [rsp+0x90], xmm10
000078eb87de0a51  vmovaps [rsp+0xA0], xmm11
000078eb87de0a5a  vmovaps [rsp+0xB0], xmm12
000078eb87de0a63  vmovaps [rsp+0xC0], xmm13
000078eb87de0a6c  vmovaps [rsp+0xD0], xmm14
000078eb87de0a75  vmovaps [rsp+0xE0], xmm15
000078eb87de0a7e  sub rsp, 0x30
000078eb87de0a82  movaps [rsp], xmm7
000078eb87de0a86  movaps [rsp+0x10], xmm11
000078eb87de0a8c  movaps [rsp+0x20], xmm9
000078eb87de0a92  lea rdi, [rsp]
000078eb87de0a96  mov esi, 0x00
000078eb87de0a9b  mov rax, 0x61D341A71530
000078eb87de0aa5  call rax
000078eb87de0aa7  movaps xmm7, [rsp]
000078eb87de0aab  add rsp, 0x30
000078eb87de0aaf  vmovaps xmm0, [rsp]
000078eb87de0ab4  vmovaps xmm1, [rsp+0x10]
000078eb87de0aba  vmovaps xmm2, [rsp+0x20]
000078eb87de0ac0  vmovaps xmm3, [rsp+0x30]
000078eb87de0ac6  vmovaps xmm4, [rsp+0x40]
000078eb87de0acc  vmovaps xmm5, [rsp+0x50]
000078eb87de0ad2  vmovaps xmm6, [rsp+0x60]
000078eb87de0ad8  vmovaps xmm8, [rsp+0x70]
000078eb87de0ade  vmovaps xmm9, [rsp+0x80]
000078eb87de0ae7  vmovaps xmm10, [rsp+0x90]
000078eb87de0af0  vmovaps xmm11, [rsp+0xA0]
000078eb87de0af9  vmovaps xmm12, [rsp+0xB0]
000078eb87de0b02  vmovaps xmm13, [rsp+0xC0]
000078eb87de0b0b  vmovaps xmm14, [rsp+0xD0]
000078eb87de0b14  vmovaps xmm15, [rsp+0xE0]
000078eb87de0b1d  add rsp, 0xF0
000078eb87de0b24  pop r11
000078eb87de0b26  pop r10
000078eb87de0b28  pop r9
000078eb87de0b2a  pop r8
000078eb87de0b2c  pop rsi
000078eb87de0b2d  pop rdi
000078eb87de0b2e  pop rdx
000078eb87de0b2f  pop rcx
000078eb87de0b30  pop rax
000078eb87de0b31  add rsp, 0x08
000078eb87de0b35  jmp 0x000078EB87DDC685
000078eb87de0b3a  sub rsp, 0x08
000078eb87de0b3e  push rax
000078eb87de0b3f  push rcx
000078eb87de0b40  push rdx
000078eb87de0b41  push rdi
000078eb87de0b42  push rsi
000078eb87de0b43  push r8
000078eb87de0b45  push r9
000078eb87de0b47  push r10
000078eb87de0b49  push r11
000078eb87de0b4b  sub rsp, 0xF0
000078eb87de0b52  vmovaps [rsp], xmm0
000078eb87de0b57  vmovaps [rsp+0x10], xmm1
000078eb87de0b5d  vmovaps [rsp+0x20], xmm2
000078eb87de0b63  vmovaps [rsp+0x30], xmm3
000078eb87de0b69  vmovaps [rsp+0x40], xmm4
000078eb87de0b6f  vmovaps [rsp+0x50], xmm5
000078eb87de0b75  vmovaps [rsp+0x60], xmm6
000078eb87de0b7b  vmovaps [rsp+0x70], xmm7
000078eb87de0b81  vmovaps [rsp+0x80], xmm8
000078eb87de0b8a  vmovaps [rsp+0x90], xmm9
000078eb87de0b93  vmovaps [rsp+0xA0], xmm10
000078eb87de0b9c  vmovaps [rsp+0xB0], xmm12
000078eb87de0ba5  vmovaps [rsp+0xC0], xmm13
000078eb87de0bae  vmovaps [rsp+0xD0], xmm14
000078eb87de0bb7  vmovaps [rsp+0xE0], xmm15
000078eb87de0bc0  sub rsp, 0x30
000078eb87de0bc4  movaps [rsp], xmm11
000078eb87de0bc9  movaps [rsp+0x10], xmm10
000078eb87de0bcf  movaps [rsp+0x20], xmm14
000078eb87de0bd5  lea rdi, [rsp]
000078eb87de0bd9  mov esi, 0x00
000078eb87de0bde  mov rax, 0x61D341A71530
000078eb87de0be8  call rax
000078eb87de0bea  movaps xmm11, [rsp]
000078eb87de0bef  add rsp, 0x30
000078eb87de0bf3  vmovaps xmm0, [rsp]
000078eb87de0bf8  vmovaps xmm1, [rsp+0x10]
000078eb87de0bfe  vmovaps xmm2, [rsp+0x20]
000078eb87de0c04  vmovaps xmm3, [rsp+0x30]
000078eb87de0c0a  vmovaps xmm4, [rsp+0x40]
000078eb87de0c10  vmovaps xmm5, [rsp+0x50]
000078eb87de0c16  vmovaps xmm6, [rsp+0x60]
000078eb87de0c1c  vmovaps xmm7, [rsp+0x70]
000078eb87de0c22  vmovaps xmm8, [rsp+0x80]
000078eb87de0c2b  vmovaps xmm9, [rsp+0x90]
000078eb87de0c34  vmovaps xmm10, [rsp+0xA0]
000078eb87de0c3d  vmovaps xmm12, [rsp+0xB0]
000078eb87de0c46  vmovaps xmm13, [rsp+0xC0]
000078eb87de0c4f  vmovaps xmm14, [rsp+0xD0]
000078eb87de0c58  vmovaps xmm15, [rsp+0xE0]
000078eb87de0c61  add rsp, 0xF0
000078eb87de0c68  pop r11
000078eb87de0c6a  pop r10
000078eb87de0c6c  pop r9
000078eb87de0c6e  pop r8
000078eb87de0c70  pop rsi
000078eb87de0c71  pop rdi
000078eb87de0c72  pop rdx
000078eb87de0c73  pop rcx
000078eb87de0c74  pop rax
000078eb87de0c75  add rsp, 0x08
000078eb87de0c79  jmp 0x000078EB87DDC6A0
000078eb87de0c7e  call 0x000078EB87CC33A0
000078eb87de0c83  jmp 0x000078EB87DDC6AA
000078eb87de0c88  sub rsp, 0x08
000078eb87de0c8c  push rax
000078eb87de0c8d  push rcx
000078eb87de0c8e  push rdx
000078eb87de0c8f  push rdi
000078eb87de0c90  push rsi
000078eb87de0c91  push r8
000078eb87de0c93  push r9
000078eb87de0c95  push r10
000078eb87de0c97  push r11
000078eb87de0c99  sub rsp, 0xF0
000078eb87de0ca0  vmovaps [rsp], xmm0
000078eb87de0ca5  vmovaps [rsp+0x10], xmm1
000078eb87de0cab  vmovaps [rsp+0x20], xmm2
000078eb87de0cb1  vmovaps [rsp+0x30], xmm3
000078eb87de0cb7  vmovaps [rsp+0x40], xmm4
000078eb87de0cbd  vmovaps [rsp+0x50], xmm5
000078eb87de0cc3  vmovaps [rsp+0x60], xmm6
000078eb87de0cc9  vmovaps [rsp+0x70], xmm7
000078eb87de0ccf  vmovaps [rsp+0x80], xmm8
000078eb87de0cd8  vmovaps [rsp+0x90], xmm9
000078eb87de0ce1  vmovaps [rsp+0xA0], xmm11
000078eb87de0cea  vmovaps [rsp+0xB0], xmm12
000078eb87de0cf3  vmovaps [rsp+0xC0], xmm13
000078eb87de0cfc  vmovaps [rsp+0xD0], xmm14
000078eb87de0d05  vmovaps [rsp+0xE0], xmm15
000078eb87de0d0e  sub rsp, 0x30
000078eb87de0d12  movaps [rsp], xmm10
000078eb87de0d17  movaps [rsp+0x10], xmm1
000078eb87de0d1c  movaps [rsp+0x20], xmm12
000078eb87de0d22  lea rdi, [rsp]
000078eb87de0d26  mov esi, 0x00
000078eb87de0d2b  mov rax, 0x61D341A71530
000078eb87de0d35  call rax
000078eb87de0d37  movaps xmm10, [rsp]
000078eb87de0d3c  add rsp, 0x30
000078eb87de0d40  vmovaps xmm0, [rsp]
000078eb87de0d45  vmovaps xmm1, [rsp+0x10]
000078eb87de0d4b  vmovaps xmm2, [rsp+0x20]
000078eb87de0d51  vmovaps xmm3, [rsp+0x30]
000078eb87de0d57  vmovaps xmm4, [rsp+0x40]
000078eb87de0d5d  vmovaps xmm5, [rsp+0x50]
000078eb87de0d63  vmovaps xmm6, [rsp+0x60]
000078eb87de0d69  vmovaps xmm7, [rsp+0x70]
000078eb87de0d6f  vmovaps xmm8, [rsp+0x80]
000078eb87de0d78  vmovaps xmm9, [rsp+0x90]
000078eb87de0d81  vmovaps xmm11, [rsp+0xA0]
000078eb87de0d8a  vmovaps xmm12, [rsp+0xB0]
000078eb87de0d93  vmovaps xmm13, [rsp+0xC0]
000078eb87de0d9c  vmovaps xmm14, [rsp+0xD0]
000078eb87de0da5  vmovaps xmm15, [rsp+0xE0]
000078eb87de0dae  add rsp, 0xF0
000078eb87de0db5  pop r11
000078eb87de0db7  pop r10
000078eb87de0db9  pop r9
000078eb87de0dbb  pop r8
000078eb87de0dbd  pop rsi
000078eb87de0dbe  pop rdi
000078eb87de0dbf  pop rdx
000078eb87de0dc0  pop rcx
000078eb87de0dc1  pop rax
000078eb87de0dc2  add rsp, 0x08
000078eb87de0dc6  jmp 0x000078EB87DDC6CD
000078eb87de0dcb  sub rsp, 0x08
000078eb87de0dcf  push rax
000078eb87de0dd0  push rcx
000078eb87de0dd1  push rdx
000078eb87de0dd2  push rdi
000078eb87de0dd3  push rsi
000078eb87de0dd4  push r8
000078eb87de0dd6  push r9
000078eb87de0dd8  push r10
000078eb87de0dda  push r11
000078eb87de0ddc  sub rsp, 0xF0
000078eb87de0de3  vmovaps [rsp], xmm0
000078eb87de0de8  vmovaps [rsp+0x10], xmm1
000078eb87de0dee  vmovaps [rsp+0x20], xmm2
000078eb87de0df4  vmovaps [rsp+0x30], xmm3
000078eb87de0dfa  vmovaps [rsp+0x40], xmm4
000078eb87de0e00  vmovaps [rsp+0x50], xmm5
000078eb87de0e06  vmovaps [rsp+0x60], xmm6
000078eb87de0e0c  vmovaps [rsp+0x70], xmm7
000078eb87de0e12  vmovaps [rsp+0x80], xmm8
000078eb87de0e1b  vmovaps [rsp+0x90], xmm9
000078eb87de0e24  vmovaps [rsp+0xA0], xmm10
000078eb87de0e2d  vmovaps [rsp+0xB0], xmm11
000078eb87de0e36  vmovaps [rsp+0xC0], xmm13
000078eb87de0e3f  vmovaps [rsp+0xD0], xmm14
000078eb87de0e48  vmovaps [rsp+0xE0], xmm15
000078eb87de0e51  sub rsp, 0x30
000078eb87de0e55  movaps [rsp], xmm12
000078eb87de0e5a  movaps [rsp+0x10], xmm14
000078eb87de0e60  movaps [rsp+0x20], xmm1
000078eb87de0e65  lea rdi, [rsp]
000078eb87de0e69  mov esi, 0x00
000078eb87de0e6e  mov rax, 0x61D341A71530
000078eb87de0e78  call rax
000078eb87de0e7a  movaps xmm12, [rsp]
000078eb87de0e7f  add rsp, 0x30
000078eb87de0e83  vmovaps xmm0, [rsp]
000078eb87de0e88  vmovaps xmm1, [rsp+0x10]
000078eb87de0e8e  vmovaps xmm2, [rsp+0x20]
000078eb87de0e94  vmovaps xmm3, [rsp+0x30]
000078eb87de0e9a  vmovaps xmm4, [rsp+0x40]
000078eb87de0ea0  vmovaps xmm5, [rsp+0x50]
000078eb87de0ea6  vmovaps xmm6, [rsp+0x60]
000078eb87de0eac  vmovaps xmm7, [rsp+0x70]
000078eb87de0eb2  vmovaps xmm8, [rsp+0x80]
000078eb87de0ebb  vmovaps xmm9, [rsp+0x90]
000078eb87de0ec4  vmovaps xmm10, [rsp+0xA0]
000078eb87de0ecd  vmovaps xmm11, [rsp+0xB0]
000078eb87de0ed6  vmovaps xmm13, [rsp+0xC0]
000078eb87de0edf  vmovaps xmm14, [rsp+0xD0]
000078eb87de0ee8  vmovaps xmm15, [rsp+0xE0]
000078eb87de0ef1  add rsp, 0xF0
000078eb87de0ef8  pop r11
000078eb87de0efa  pop r10
000078eb87de0efc  pop r9
000078eb87de0efe  pop r8
000078eb87de0f00  pop rsi
000078eb87de0f01  pop rdi
000078eb87de0f02  pop rdx
000078eb87de0f03  pop rcx
000078eb87de0f04  pop rax
000078eb87de0f05  add rsp, 0x08
000078eb87de0f09  jmp 0x000078EB87DDC6FC
000078eb87de0f0e  sub rsp, 0x08
000078eb87de0f12  push rax
000078eb87de0f13  push rcx
000078eb87de0f14  push rdx
000078eb87de0f15  push rdi
000078eb87de0f16  push rsi
000078eb87de0f17  push r8
000078eb87de0f19  push r9
000078eb87de0f1b  push r10
000078eb87de0f1d  push r11
000078eb87de0f1f  sub rsp, 0xF0
000078eb87de0f26  vmovaps [rsp], xmm0
000078eb87de0f2b  vmovaps [rsp+0x10], xmm1
000078eb87de0f31  vmovaps [rsp+0x20], xmm2
000078eb87de0f37  vmovaps [rsp+0x30], xmm3
000078eb87de0f3d  vmovaps [rsp+0x40], xmm4
000078eb87de0f43  vmovaps [rsp+0x50], xmm5
000078eb87de0f49  vmovaps [rsp+0x60], xmm6
000078eb87de0f4f  vmovaps [rsp+0x70], xmm7
000078eb87de0f55  vmovaps [rsp+0x80], xmm8
000078eb87de0f5e  vmovaps [rsp+0x90], xmm9
000078eb87de0f67  vmovaps [rsp+0xA0], xmm10
000078eb87de0f70  vmovaps [rsp+0xB0], xmm11
000078eb87de0f79  vmovaps [rsp+0xC0], xmm12
000078eb87de0f82  vmovaps [rsp+0xD0], xmm13
000078eb87de0f8b  vmovaps [rsp+0xE0], xmm15
000078eb87de0f94  sub rsp, 0x30
000078eb87de0f98  movaps [rsp], xmm14
000078eb87de0f9d  movaps [rsp+0x10], xmm9
000078eb87de0fa3  movaps [rsp+0x20], xmm1
000078eb87de0fa8  lea rdi, [rsp]
000078eb87de0fac  mov esi, 0x00
000078eb87de0fb1  mov rax, 0x61D341A71530
000078eb87de0fbb  call rax
000078eb87de0fbd  movaps xmm14, [rsp]
000078eb87de0fc2  add rsp, 0x30
000078eb87de0fc6  vmovaps xmm0, [rsp]
000078eb87de0fcb  vmovaps xmm1, [rsp+0x10]
000078eb87de0fd1  vmovaps xmm2, [rsp+0x20]
000078eb87de0fd7  vmovaps xmm3, [rsp+0x30]
000078eb87de0fdd  vmovaps xmm4, [rsp+0x40]
000078eb87de0fe3  vmovaps xmm5, [rsp+0x50]
000078eb87de0fe9  vmovaps xmm6, [rsp+0x60]
000078eb87de0fef  vmovaps xmm7, [rsp+0x70]
000078eb87de0ff5  vmovaps xmm8, [rsp+0x80]
000078eb87de0ffe  vmovaps xmm9, [rsp+0x90]
000078eb87de1007  vmovaps xmm10, [rsp+0xA0]
000078eb87de1010  vmovaps xmm11, [rsp+0xB0]
000078eb87de1019  vmovaps xmm12, [rsp+0xC0]
000078eb87de1022  vmovaps xmm13, [rsp+0xD0]
000078eb87de102b  vmovaps xmm15, [rsp+0xE0]
000078eb87de1034  add rsp, 0xF0
000078eb87de103b  pop r11
000078eb87de103d  pop r10
000078eb87de103f  pop r9
000078eb87de1041  pop r8
000078eb87de1043  pop rsi
000078eb87de1044  pop rdi
000078eb87de1045  pop rdx
000078eb87de1046  pop rcx
000078eb87de1047  pop rax
000078eb87de1048  add rsp, 0x08
000078eb87de104c  jmp 0x000078EB87DDC72B
000078eb87de1051  sub rsp, 0x08
000078eb87de1055  push rax
000078eb87de1056  push rcx
000078eb87de1057  push rdx
000078eb87de1058  push rdi
000078eb87de1059  push rsi
000078eb87de105a  push r8
000078eb87de105c  push r9
000078eb87de105e  push r10
000078eb87de1060  push r11
000078eb87de1062  sub rsp, 0xF0
000078eb87de1069  vmovaps [rsp], xmm0
000078eb87de106e  vmovaps [rsp+0x10], xmm2
000078eb87de1074  vmovaps [rsp+0x20], xmm3
000078eb87de107a  vmovaps [rsp+0x30], xmm4
000078eb87de1080  vmovaps [rsp+0x40], xmm5
000078eb87de1086  vmovaps [rsp+0x50], xmm6
000078eb87de108c  vmovaps [rsp+0x60], xmm7
000078eb87de1092  vmovaps [rsp+0x70], xmm8
000078eb87de1098  vmovaps [rsp+0x80], xmm9
000078eb87de10a1  vmovaps [rsp+0x90], xmm10
000078eb87de10aa  vmovaps [rsp+0xA0], xmm11
000078eb87de10b3  vmovaps [rsp+0xB0], xmm12
000078eb87de10bc  vmovaps [rsp+0xC0], xmm13
000078eb87de10c5  vmovaps [rsp+0xD0], xmm14
000078eb87de10ce  vmovaps [rsp+0xE0], xmm15
000078eb87de10d7  sub rsp, 0x30
000078eb87de10db  movaps [rsp], xmm1
000078eb87de10df  movaps [rsp+0x10], xmm13
000078eb87de10e5  movaps [rsp+0x20], xmm8
000078eb87de10eb  lea rdi, [rsp]
000078eb87de10ef  mov esi, 0x00
000078eb87de10f4  mov rax, 0x61D341A71530
000078eb87de10fe  call rax
000078eb87de1100  movaps xmm1, [rsp]
000078eb87de1104  add rsp, 0x30
000078eb87de1108  vmovaps xmm0, [rsp]
000078eb87de110d  vmovaps xmm2, [rsp+0x10]
000078eb87de1113  vmovaps xmm3, [rsp+0x20]
000078eb87de1119  vmovaps xmm4, [rsp+0x30]
000078eb87de111f  vmovaps xmm5, [rsp+0x40]
000078eb87de1125  vmovaps xmm6, [rsp+0x50]
000078eb87de112b  vmovaps xmm7, [rsp+0x60]
000078eb87de1131  vmovaps xmm8, [rsp+0x70]
000078eb87de1137  vmovaps xmm9, [rsp+0x80]
000078eb87de1140  vmovaps xmm10, [rsp+0x90]
000078eb87de1149  vmovaps xmm11, [rsp+0xA0]
000078eb87de1152  vmovaps xmm12, [rsp+0xB0]
000078eb87de115b  vmovaps xmm13, [rsp+0xC0]
000078eb87de1164  vmovaps xmm14, [rsp+0xD0]
000078eb87de116d  vmovaps xmm15, [rsp+0xE0]
000078eb87de1176  add rsp, 0xF0
000078eb87de117d  pop r11
000078eb87de117f  pop r10
000078eb87de1181  pop r9
000078eb87de1183  pop r8
000078eb87de1185  pop rsi
000078eb87de1186  pop rdi
000078eb87de1187  pop rdx
000078eb87de1188  pop rcx
000078eb87de1189  pop rax
000078eb87de118a  add rsp, 0x08
000078eb87de118e  jmp 0x000078EB87DDC74D
000078eb87de1193  call 0x000078EB87C0C260
000078eb87de1198  jmp 0x000078EB87DDC75B
000078eb87de119d  call 0x000078EB87CBD750
000078eb87de11a2  jmp 0x000078EB87DDC765
000078eb87de11a7  sub rsp, 0x08
000078eb87de11ab  push rax
000078eb87de11ac  push rcx
000078eb87de11ad  push rdx
000078eb87de11ae  push rdi
000078eb87de11af  push rsi
000078eb87de11b0  push r8
000078eb87de11b2  push r9
000078eb87de11b4  push r10
000078eb87de11b6  push r11
000078eb87de11b8  sub rsp, 0xF0
000078eb87de11bf  vmovaps [rsp], xmm0
000078eb87de11c4  vmovaps [rsp+0x10], xmm1
000078eb87de11ca  vmovaps [rsp+0x20], xmm2
000078eb87de11d0  vmovaps [rsp+0x30], xmm3
000078eb87de11d6  vmovaps [rsp+0x40], xmm4
000078eb87de11dc  vmovaps [rsp+0x50], xmm5
000078eb87de11e2  vmovaps [rsp+0x60], xmm6
000078eb87de11e8  vmovaps [rsp+0x70], xmm7
000078eb87de11ee  vmovaps [rsp+0x80], xmm9
000078eb87de11f7  vmovaps [rsp+0x90], xmm10
000078eb87de1200  vmovaps [rsp+0xA0], xmm11
000078eb87de1209  vmovaps [rsp+0xB0], xmm12
000078eb87de1212  vmovaps [rsp+0xC0], xmm13
000078eb87de121b  vmovaps [rsp+0xD0], xmm14
000078eb87de1224  vmovaps [rsp+0xE0], xmm15
000078eb87de122d  sub rsp, 0x30
000078eb87de1231  movaps [rsp], xmm8
000078eb87de1236  movaps [rsp+0x10], xmm15
000078eb87de123c  movaps [rsp+0x20], xmm7
000078eb87de1241  lea rdi, [rsp]
000078eb87de1245  mov esi, 0x00
000078eb87de124a  mov rax, 0x61D341A71530
000078eb87de1254  call rax
000078eb87de1256  movaps xmm8, [rsp]
000078eb87de125b  add rsp, 0x30
000078eb87de125f  vmovaps xmm0, [rsp]
000078eb87de1264  vmovaps xmm1, [rsp+0x10]
000078eb87de126a  vmovaps xmm2, [rsp+0x20]
000078eb87de1270  vmovaps xmm3, [rsp+0x30]
000078eb87de1276  vmovaps xmm4, [rsp+0x40]
000078eb87de127c  vmovaps xmm5, [rsp+0x50]
000078eb87de1282  vmovaps xmm6, [rsp+0x60]
000078eb87de1288  vmovaps xmm7, [rsp+0x70]
000078eb87de128e  vmovaps xmm9, [rsp+0x80]
000078eb87de1297  vmovaps xmm10, [rsp+0x90]
000078eb87de12a0  vmovaps xmm11, [rsp+0xA0]
000078eb87de12a9  vmovaps xmm12, [rsp+0xB0]
000078eb87de12b2  vmovaps xmm13, [rsp+0xC0]
000078eb87de12bb  vmovaps xmm14, [rsp+0xD0]
000078eb87de12c4  vmovaps xmm15, [rsp+0xE0]
000078eb87de12cd  add rsp, 0xF0
000078eb87de12d4  pop r11
000078eb87de12d6  pop r10
000078eb87de12d8  pop r9
000078eb87de12da  pop r8
000078eb87de12dc  pop rsi
000078eb87de12dd  pop rdi
000078eb87de12de  pop rdx
000078eb87de12df  pop rcx
000078eb87de12e0  pop rax
000078eb87de12e1  add rsp, 0x08
000078eb87de12e5  jmp 0x000078EB87DDC787
000078eb87de12ea  sub rsp, 0x08
000078eb87de12ee  push rax
000078eb87de12ef  push rcx
000078eb87de12f0  push rdx
000078eb87de12f1  push rdi
000078eb87de12f2  push rsi
000078eb87de12f3  push r8
000078eb87de12f5  push r9
000078eb87de12f7  push r10
000078eb87de12f9  push r11
000078eb87de12fb  sub rsp, 0xF0
000078eb87de1302  vmovaps [rsp], xmm0
000078eb87de1307  vmovaps [rsp+0x10], xmm1
000078eb87de130d  vmovaps [rsp+0x20], xmm2
000078eb87de1313  vmovaps [rsp+0x30], xmm3
000078eb87de1319  vmovaps [rsp+0x40], xmm4
000078eb87de131f  vmovaps [rsp+0x50], xmm5
000078eb87de1325  vmovaps [rsp+0x60], xmm6
000078eb87de132b  vmovaps [rsp+0x70], xmm8
000078eb87de1331  vmovaps [rsp+0x80], xmm9
000078eb87de133a  vmovaps [rsp+0x90], xmm10
000078eb87de1343  vmovaps [rsp+0xA0], xmm11
000078eb87de134c  vmovaps [rsp+0xB0], xmm12
000078eb87de1355  vmovaps [rsp+0xC0], xmm13
000078eb87de135e  vmovaps [rsp+0xD0], xmm14
000078eb87de1367  vmovaps [rsp+0xE0], xmm15
000078eb87de1370  sub rsp, 0x30
000078eb87de1374  movaps [rsp], xmm7
000078eb87de1378  movaps [rsp+0x10], xmm9
000078eb87de137e  movaps [rsp+0x20], xmm15
000078eb87de1384  lea rdi, [rsp]
000078eb87de1388  mov esi, 0x00
000078eb87de138d  mov rax, 0x61D341A71530
000078eb87de1397  call rax
000078eb87de1399  movaps xmm7, [rsp]
000078eb87de139d  add rsp, 0x30
000078eb87de13a1  vmovaps xmm0, [rsp]
000078eb87de13a6  vmovaps xmm1, [rsp+0x10]
000078eb87de13ac  vmovaps xmm2, [rsp+0x20]
000078eb87de13b2  vmovaps xmm3, [rsp+0x30]
000078eb87de13b8  vmovaps xmm4, [rsp+0x40]
000078eb87de13be  vmovaps xmm5, [rsp+0x50]
000078eb87de13c4  vmovaps xmm6, [rsp+0x60]
000078eb87de13ca  vmovaps xmm8, [rsp+0x70]
000078eb87de13d0  vmovaps xmm9, [rsp+0x80]
000078eb87de13d9  vmovaps xmm10, [rsp+0x90]
000078eb87de13e2  vmovaps xmm11, [rsp+0xA0]
000078eb87de13eb  vmovaps xmm12, [rsp+0xB0]
000078eb87de13f4  vmovaps xmm13, [rsp+0xC0]
000078eb87de13fd  vmovaps xmm14, [rsp+0xD0]
000078eb87de1406  vmovaps xmm15, [rsp+0xE0]
000078eb87de140f  add rsp, 0xF0
000078eb87de1416  pop r11
000078eb87de1418  pop r10
000078eb87de141a  pop r9
000078eb87de141c  pop r8
000078eb87de141e  pop rsi
000078eb87de141f  pop rdi
000078eb87de1420  pop rdx
000078eb87de1421  pop rcx
000078eb87de1422  pop rax
000078eb87de1423  add rsp, 0x08
000078eb87de1427  jmp 0x000078EB87DDC7B4
000078eb87de142c  sub rsp, 0x08
000078eb87de1430  push rax
000078eb87de1431  push rcx
000078eb87de1432  push rdx
000078eb87de1433  push rdi
000078eb87de1434  push rsi
000078eb87de1435  push r8
000078eb87de1437  push r9
000078eb87de1439  push r10
000078eb87de143b  push r11
000078eb87de143d  sub rsp, 0xF0
000078eb87de1444  vmovaps [rsp], xmm0
000078eb87de1449  vmovaps [rsp+0x10], xmm1
000078eb87de144f  vmovaps [rsp+0x20], xmm2
000078eb87de1455  vmovaps [rsp+0x30], xmm3
000078eb87de145b  vmovaps [rsp+0x40], xmm4
000078eb87de1461  vmovaps [rsp+0x50], xmm5
000078eb87de1467  vmovaps [rsp+0x60], xmm6
000078eb87de146d  vmovaps [rsp+0x70], xmm7
000078eb87de1473  vmovaps [rsp+0x80], xmm8
000078eb87de147c  vmovaps [rsp+0x90], xmm10
000078eb87de1485  vmovaps [rsp+0xA0], xmm11
000078eb87de148e  vmovaps [rsp+0xB0], xmm12
000078eb87de1497  vmovaps [rsp+0xC0], xmm13
000078eb87de14a0  vmovaps [rsp+0xD0], xmm14
000078eb87de14a9  vmovaps [rsp+0xE0], xmm15
000078eb87de14b2  sub rsp, 0x30
000078eb87de14b6  movaps [rsp], xmm9
000078eb87de14bb  movaps [rsp+0x10], xmm13
000078eb87de14c1  movaps [rsp+0x20], xmm15
000078eb87de14c7  lea rdi, [rsp]
000078eb87de14cb  mov esi, 0x00
000078eb87de14d0  mov rax, 0x61D341A71530
000078eb87de14da  call rax
000078eb87de14dc  movaps xmm9, [rsp]
000078eb87de14e1  add rsp, 0x30
000078eb87de14e5  vmovaps xmm0, [rsp]
000078eb87de14ea  vmovaps xmm1, [rsp+0x10]
000078eb87de14f0  vmovaps xmm2, [rsp+0x20]
000078eb87de14f6  vmovaps xmm3, [rsp+0x30]
000078eb87de14fc  vmovaps xmm4, [rsp+0x40]
000078eb87de1502  vmovaps xmm5, [rsp+0x50]
000078eb87de1508  vmovaps xmm6, [rsp+0x60]
000078eb87de150e  vmovaps xmm7, [rsp+0x70]
000078eb87de1514  vmovaps xmm8, [rsp+0x80]
000078eb87de151d  vmovaps xmm10, [rsp+0x90]
000078eb87de1526  vmovaps xmm11, [rsp+0xA0]
000078eb87de152f  vmovaps xmm12, [rsp+0xB0]
000078eb87de1538  vmovaps xmm13, [rsp+0xC0]
000078eb87de1541  vmovaps xmm14, [rsp+0xD0]
000078eb87de154a  vmovaps xmm15, [rsp+0xE0]
000078eb87de1553  add rsp, 0xF0
000078eb87de155a  pop r11
000078eb87de155c  pop r10
000078eb87de155e  pop r9
000078eb87de1560  pop r8
000078eb87de1562  pop rsi
000078eb87de1563  pop rdi
000078eb87de1564  pop rdx
000078eb87de1565  pop rcx
000078eb87de1566  pop rax
000078eb87de1567  add rsp, 0x08
000078eb87de156b  jmp 0x000078EB87DDC7E2
000078eb87de1570  sub rsp, 0x08
000078eb87de1574  push rax
000078eb87de1575  push rcx
000078eb87de1576  push rdx
000078eb87de1577  push rdi
000078eb87de1578  push rsi
000078eb87de1579  push r8
000078eb87de157b  push r9
000078eb87de157d  push r10
000078eb87de157f  push r11
000078eb87de1581  sub rsp, 0xF0
000078eb87de1588  vmovaps [rsp], xmm0
000078eb87de158d  vmovaps [rsp+0x10], xmm1
000078eb87de1593  vmovaps [rsp+0x20], xmm2
000078eb87de1599  vmovaps [rsp+0x30], xmm3
000078eb87de159f  vmovaps [rsp+0x40], xmm4
000078eb87de15a5  vmovaps [rsp+0x50], xmm5
000078eb87de15ab  vmovaps [rsp+0x60], xmm6
000078eb87de15b1  vmovaps [rsp+0x70], xmm7
000078eb87de15b7  vmovaps [rsp+0x80], xmm8
000078eb87de15c0  vmovaps [rsp+0x90], xmm9
000078eb87de15c9  vmovaps [rsp+0xA0], xmm10
000078eb87de15d2  vmovaps [rsp+0xB0], xmm11
000078eb87de15db  vmovaps [rsp+0xC0], xmm12
000078eb87de15e4  vmovaps [rsp+0xD0], xmm13
000078eb87de15ed  vmovaps [rsp+0xE0], xmm14
000078eb87de15f6  sub rsp, 0x30
000078eb87de15fa  movaps [rsp], xmm15
000078eb87de15ff  movaps [rsp+0x10], xmm11
000078eb87de1605  movaps [rsp+0x20], xmm12
000078eb87de160b  lea rdi, [rsp]
000078eb87de160f  mov esi, 0x00
000078eb87de1614  mov rax, 0x61D341A71530
000078eb87de161e  call rax
000078eb87de1620  movaps xmm15, [rsp]
000078eb87de1625  add rsp, 0x30
000078eb87de1629  vmovaps xmm0, [rsp]
000078eb87de162e  vmovaps xmm1, [rsp+0x10]
000078eb87de1634  vmovaps xmm2, [rsp+0x20]
000078eb87de163a  vmovaps xmm3, [rsp+0x30]
000078eb87de1640  vmovaps xmm4, [rsp+0x40]
000078eb87de1646  vmovaps xmm5, [rsp+0x50]
000078eb87de164c  vmovaps xmm6, [rsp+0x60]
000078eb87de1652  vmovaps xmm7, [rsp+0x70]
000078eb87de1658  vmovaps xmm8, [rsp+0x80]
000078eb87de1661  vmovaps xmm9, [rsp+0x90]
000078eb87de166a  vmovaps xmm10, [rsp+0xA0]
000078eb87de1673  vmovaps xmm11, [rsp+0xB0]
000078eb87de167c  vmovaps xmm12, [rsp+0xC0]
000078eb87de1685  vmovaps xmm13, [rsp+0xD0]
000078eb87de168e  vmovaps xmm14, [rsp+0xE0]
000078eb87de1697  add rsp, 0xF0
000078eb87de169e  pop r11
000078eb87de16a0  pop r10
000078eb87de16a2  pop r9
000078eb87de16a4  pop r8
000078eb87de16a6  pop rsi
000078eb87de16a7  pop rdi
000078eb87de16a8  pop rdx
000078eb87de16a9  pop rcx
000078eb87de16aa  pop rax
000078eb87de16ab  add rsp, 0x08
000078eb87de16af  jmp 0x000078EB87DDC7FD
000078eb87de16b4  sub rsp, 0x08
000078eb87de16b8  push rax
000078eb87de16b9  push rcx
000078eb87de16ba  push rdx
000078eb87de16bb  push rdi
000078eb87de16bc  push rsi
000078eb87de16bd  push r8
000078eb87de16bf  push r9
000078eb87de16c1  push r10
000078eb87de16c3  push r11
000078eb87de16c5  sub rsp, 0xF0
000078eb87de16cc  vmovaps [rsp], xmm0
000078eb87de16d1  vmovaps [rsp+0x10], xmm1
000078eb87de16d7  vmovaps [rsp+0x20], xmm2
000078eb87de16dd  vmovaps [rsp+0x30], xmm3
000078eb87de16e3  vmovaps [rsp+0x40], xmm4
000078eb87de16e9  vmovaps [rsp+0x50], xmm5
000078eb87de16ef  vmovaps [rsp+0x60], xmm6
000078eb87de16f5  vmovaps [rsp+0x70], xmm7
000078eb87de16fb  vmovaps [rsp+0x80], xmm8
000078eb87de1704  vmovaps [rsp+0x90], xmm9
000078eb87de170d  vmovaps [rsp+0xA0], xmm10
000078eb87de1716  vmovaps [rsp+0xB0], xmm11
000078eb87de171f  vmovaps [rsp+0xC0], xmm12
000078eb87de1728  vmovaps [rsp+0xD0], xmm14
000078eb87de1731  vmovaps [rsp+0xE0], xmm15
000078eb87de173a  sub rsp, 0x30
000078eb87de173e  movaps [rsp], xmm13
000078eb87de1743  movaps [rsp+0x10], xmm10
000078eb87de1749  movaps [rsp+0x20], xmm14
000078eb87de174f  lea rdi, [rsp]
000078eb87de1753  mov esi, 0x00
000078eb87de1758  mov rax, 0x61D341A71530
000078eb87de1762  call rax
000078eb87de1764  movaps xmm13, [rsp]
000078eb87de1769  add rsp, 0x30
000078eb87de176d  vmovaps xmm0, [rsp]
000078eb87de1772  vmovaps xmm1, [rsp+0x10]
000078eb87de1778  vmovaps xmm2, [rsp+0x20]
000078eb87de177e  vmovaps xmm3, [rsp+0x30]
000078eb87de1784  vmovaps xmm4, [rsp+0x40]
000078eb87de178a  vmovaps xmm5, [rsp+0x50]
000078eb87de1790  vmovaps xmm6, [rsp+0x60]
000078eb87de1796  vmovaps xmm7, [rsp+0x70]
000078eb87de179c  vmovaps xmm8, [rsp+0x80]
000078eb87de17a5  vmovaps xmm9, [rsp+0x90]
000078eb87de17ae  vmovaps xmm10, [rsp+0xA0]
000078eb87de17b7  vmovaps xmm11, [rsp+0xB0]
000078eb87de17c0  vmovaps xmm12, [rsp+0xC0]
000078eb87de17c9  vmovaps xmm14, [rsp+0xD0]
000078eb87de17d2  vmovaps xmm15, [rsp+0xE0]
000078eb87de17db  add rsp, 0xF0
000078eb87de17e2  pop r11
000078eb87de17e4  pop r10
000078eb87de17e6  pop r9
000078eb87de17e8  pop r8
000078eb87de17ea  pop rsi
000078eb87de17eb  pop rdi
000078eb87de17ec  pop rdx
000078eb87de17ed  pop rcx
000078eb87de17ee  pop rax
000078eb87de17ef  add rsp, 0x08
000078eb87de17f3  jmp 0x000078EB87DDC820
000078eb87de17f8  sub rsp, 0x08
000078eb87de17fc  push rax
000078eb87de17fd  push rcx
000078eb87de17fe  push rdx
000078eb87de17ff  push rdi
000078eb87de1800  push rsi
000078eb87de1801  push r8
000078eb87de1803  push r9
000078eb87de1805  push r10
000078eb87de1807  push r11
000078eb87de1809  sub rsp, 0xF0
000078eb87de1810  vmovaps [rsp], xmm0
000078eb87de1815  vmovaps [rsp+0x10], xmm1
000078eb87de181b  vmovaps [rsp+0x20], xmm2
000078eb87de1821  vmovaps [rsp+0x30], xmm3
000078eb87de1827  vmovaps [rsp+0x40], xmm4
000078eb87de182d  vmovaps [rsp+0x50], xmm5
000078eb87de1833  vmovaps [rsp+0x60], xmm6
000078eb87de1839  vmovaps [rsp+0x70], xmm7
000078eb87de183f  vmovaps [rsp+0x80], xmm8
000078eb87de1848  vmovaps [rsp+0x90], xmm9
000078eb87de1851  vmovaps [rsp+0xA0], xmm10
000078eb87de185a  vmovaps [rsp+0xB0], xmm11
000078eb87de1863  vmovaps [rsp+0xC0], xmm12
000078eb87de186c  vmovaps [rsp+0xD0], xmm13
000078eb87de1875  vmovaps [rsp+0xE0], xmm15
000078eb87de187e  sub rsp, 0x30
000078eb87de1882  movaps [rsp], xmm14
000078eb87de1887  movaps [rsp+0x10], xmm1
000078eb87de188c  movaps [rsp+0x20], xmm7
000078eb87de1891  lea rdi, [rsp]
000078eb87de1895  mov esi, 0x00
000078eb87de189a  mov rax, 0x61D341A71530
000078eb87de18a4  call rax
000078eb87de18a6  movaps xmm14, [rsp]
000078eb87de18ab  add rsp, 0x30
000078eb87de18af  vmovaps xmm0, [rsp]
000078eb87de18b4  vmovaps xmm1, [rsp+0x10]
000078eb87de18ba  vmovaps xmm2, [rsp+0x20]
000078eb87de18c0  vmovaps xmm3, [rsp+0x30]
000078eb87de18c6  vmovaps xmm4, [rsp+0x40]
000078eb87de18cc  vmovaps xmm5, [rsp+0x50]
000078eb87de18d2  vmovaps xmm6, [rsp+0x60]
000078eb87de18d8  vmovaps xmm7, [rsp+0x70]
000078eb87de18de  vmovaps xmm8, [rsp+0x80]
000078eb87de18e7  vmovaps xmm9, [rsp+0x90]
000078eb87de18f0  vmovaps xmm10, [rsp+0xA0]
000078eb87de18f9  vmovaps xmm11, [rsp+0xB0]
000078eb87de1902  vmovaps xmm12, [rsp+0xC0]
000078eb87de190b  vmovaps xmm13, [rsp+0xD0]
000078eb87de1914  vmovaps xmm15, [rsp+0xE0]
000078eb87de191d  add rsp, 0xF0
000078eb87de1924  pop r11
000078eb87de1926  pop r10
000078eb87de1928  pop r9
000078eb87de192a  pop r8
000078eb87de192c  pop rsi
000078eb87de192d  pop rdi
000078eb87de192e  pop rdx
000078eb87de192f  pop rcx
000078eb87de1930  pop rax
000078eb87de1931  add rsp, 0x08
000078eb87de1935  jmp 0x000078EB87DDC843
000078eb87de193a  sub rsp, 0x08
000078eb87de193e  push rax
000078eb87de193f  push rcx
000078eb87de1940  push rdx
000078eb87de1941  push rdi
000078eb87de1942  push rsi
000078eb87de1943  push r8
000078eb87de1945  push r9
000078eb87de1947  push r10
000078eb87de1949  push r11
000078eb87de194b  sub rsp, 0xF0
000078eb87de1952  vmovaps [rsp], xmm0
000078eb87de1957  vmovaps [rsp+0x10], xmm2
000078eb87de195d  vmovaps [rsp+0x20], xmm3
000078eb87de1963  vmovaps [rsp+0x30], xmm4
000078eb87de1969  vmovaps [rsp+0x40], xmm5
000078eb87de196f  vmovaps [rsp+0x50], xmm6
000078eb87de1975  vmovaps [rsp+0x60], xmm7
000078eb87de197b  vmovaps [rsp+0x70], xmm8
000078eb87de1981  vmovaps [rsp+0x80], xmm9
000078eb87de198a  vmovaps [rsp+0x90], xmm10
000078eb87de1993  vmovaps [rsp+0xA0], xmm11
000078eb87de199c  vmovaps [rsp+0xB0], xmm12
000078eb87de19a5  vmovaps [rsp+0xC0], xmm13
000078eb87de19ae  vmovaps [rsp+0xD0], xmm14
000078eb87de19b7  vmovaps [rsp+0xE0], xmm15
000078eb87de19c0  sub rsp, 0x30
000078eb87de19c4  movaps [rsp], xmm1
000078eb87de19c8  movaps [rsp+0x10], xmm8
000078eb87de19ce  movaps [rsp+0x20], xmm9
000078eb87de19d4  lea rdi, [rsp]
000078eb87de19d8  mov esi, 0x00
000078eb87de19dd  mov rax, 0x61D341A71530
000078eb87de19e7  call rax
000078eb87de19e9  movaps xmm1, [rsp]
000078eb87de19ed  add rsp, 0x30
000078eb87de19f1  vmovaps xmm0, [rsp]
000078eb87de19f6  vmovaps xmm2, [rsp+0x10]
000078eb87de19fc  vmovaps xmm3, [rsp+0x20]
000078eb87de1a02  vmovaps xmm4, [rsp+0x30]
000078eb87de1a08  vmovaps xmm5, [rsp+0x40]
000078eb87de1a0e  vmovaps xmm6, [rsp+0x50]
000078eb87de1a14  vmovaps xmm7, [rsp+0x60]
000078eb87de1a1a  vmovaps xmm8, [rsp+0x70]
000078eb87de1a20  vmovaps xmm9, [rsp+0x80]
000078eb87de1a29  vmovaps xmm10, [rsp+0x90]
000078eb87de1a32  vmovaps xmm11, [rsp+0xA0]
000078eb87de1a3b  vmovaps xmm12, [rsp+0xB0]
000078eb87de1a44  vmovaps xmm13, [rsp+0xC0]
000078eb87de1a4d  vmovaps xmm14, [rsp+0xD0]
000078eb87de1a56  vmovaps xmm15, [rsp+0xE0]
000078eb87de1a5f  add rsp, 0xF0
000078eb87de1a66  pop r11
000078eb87de1a68  pop r10
000078eb87de1a6a  pop r9
000078eb87de1a6c  pop r8
000078eb87de1a6e  pop rsi
000078eb87de1a6f  pop rdi
000078eb87de1a70  pop rdx
000078eb87de1a71  pop rcx
000078eb87de1a72  pop rax
000078eb87de1a73  add rsp, 0x08
000078eb87de1a77  jmp 0x000078EB87DDC865
000078eb87de1a7c  call 0x000078EB87CE5940
000078eb87de1a81  jmp 0x000078EB87DDC873
000078eb87de1a86  call 0x000078EB87C0C380
000078eb87de1a8b  jmp 0x000078EB87DDC87D
000078eb87de1a90  call 0x000078EB87C0D600
000078eb87de1a95  jmp 0x000078EB87DDC887
000078eb87de1a9a  call 0x000078EB87BFF540
000078eb87de1a9f  jmp 0x000078EB87DDC891
000078eb87de1aa4  int3
000078eb87de1aa5  nop [rax+rax*1], ax
000078eb87de1aae  nop
000078eb87de1ab0  mov rax, [r15+0xF8]
000078eb87de1ab7  lea r14, [rax+0x140]
000078eb87de1abe  mov r12, [r13+r14*1]
000078eb87de1ac3  mov [r15+0xE8], r12
000078eb87de1aca  lea r14, [rax+0x130]
000078eb87de1ad1  mov r12, [r13+r14*1]
000078eb87de1ad6  lea r14, [rax+0x138]
000078eb87de1add  mov r11, [r13+r14*1]
000078eb87de1ae2  movq xmm1, r12
000078eb87de1ae7  movq xmm15, r11
000078eb87de1aec  movq xmm1, xmm1
000078eb87de1af0  movq xmm1, xmm1
000078eb87de1af4  movaps [r15+0x1A0], xmm1
000078eb87de1afc  movq xmm15, xmm15
000078eb87de1b01  movq xmm15, xmm15
000078eb87de1b06  movaps [r15+0x190], xmm15
000078eb87de1b0e  lea r14, [rax+0x120]
000078eb87de1b15  mov r12, [r13+r14*1]
000078eb87de1b1a  lea r14, [rax+0x128]
000078eb87de1b21  mov r11, [r13+r14*1]
000078eb87de1b26  movq xmm1, r12
000078eb87de1b2b  movq xmm15, r11
000078eb87de1b30  movq xmm1, xmm1
000078eb87de1b34  movq xmm1, xmm1
000078eb87de1b38  movaps [r15+0x1C0], xmm1
000078eb87de1b40  movq xmm15, xmm15
000078eb87de1b45  movq xmm15, xmm15
000078eb87de1b4a  movaps [r15+0x1B0], xmm15
000078eb87de1b52  lea r14, [rax+0x110]
000078eb87de1b59  mov r12, [r13+r14*1]
000078eb87de1b5e  lea r14, [rax+0x118]
000078eb87de1b65  mov r11, [r13+r14*1]
000078eb87de1b6a  movq xmm1, r12
000078eb87de1b6f  movq xmm15, r11
000078eb87de1b74  movq xmm1, xmm1
000078eb87de1b78  movq xmm1, xmm1
000078eb87de1b7c  movaps [r15+0x1E0], xmm1
000078eb87de1b84  movq xmm15, xmm15
000078eb87de1b89  movq xmm15, xmm15
000078eb87de1b8e  movaps [r15+0x1D0], xmm15
000078eb87de1b96  lea r14, [rax+0x100]
000078eb87de1b9d  mov r12, [r13+r14*1]
000078eb87de1ba2  lea r14, [rax+0x108]
000078eb87de1ba9  mov r11, [r13+r14*1]
000078eb87de1bae  movq xmm1, r12
000078eb87de1bb3  movq xmm15, r11
000078eb87de1bb8  movq xmm1, xmm1
000078eb87de1bbc  movq xmm1, xmm1
000078eb87de1bc0  movaps [r15+0x200], xmm1
000078eb87de1bc8  movq xmm15, xmm15
000078eb87de1bcd  movq xmm15, xmm15
000078eb87de1bd2  movaps [r15+0x1F0], xmm15
000078eb87de1bda  mov qword ptr [r15+0x40], 0x430000
000078eb87de1be2  mov r14d, 0x430510
000078eb87de1be8  mov r12, [r13+r14*1]
000078eb87de1bed  movq xmm1, r12
000078eb87de1bf2  lea r14, [rax+0x150]
000078eb87de1bf9  mov [r15+0xF8], r14
000078eb87de1c00  mov rax, [r15+0x50]
000078eb87de1c04  movups xmm15, [r13+rax*1]
000078eb87de1c0a  movaps [r15+0x120], xmm15
000078eb87de1c12  mov qword ptr [r15+0x48], 0x10
000078eb87de1c1a  xor eax, eax
000078eb87de1c1c  mov r14d, 0x10
000078eb87de1c22  mov r12d, 0x200
000078eb87de1c28  cmp r14, r12
000078eb87de1c2b  cmc
000078eb87de1c2c  lahf
000078eb87de1c2d  seto al
000078eb87de1c30  mov [r15+0x108], eax
000078eb87de1c37  pextrq rax, xmm15, 0x01
000078eb87de1c3e  movq xmm14, rax
000078eb87de1c43  movaps [r15+0x130], xmm14
000078eb87de1c4b  movq rax, xmm1
000078eb87de1c50  movq r14, xmm15
000078eb87de1c55  vmovq xmm1, rax
000078eb87de1c5a  vmovq xmm15, r14
000078eb87de1c5f  movaps xmm13, xmm1
000078eb87de1c63  addsd xmm13, xmm15
000078eb87de1c68  ucomisd xmm13, xmm13
000078eb87de1c6d  jp 0x000078EB87DE1D86
000078eb87de1c73  movq xmm13, xmm13
000078eb87de1c78  movq rax, xmm13
000078eb87de1c7d  movq r14, xmm14
000078eb87de1c82  vmovq xmm1, rax
000078eb87de1c87  vmovq xmm15, r14
000078eb87de1c8c  movaps xmm14, xmm1
000078eb87de1c90  addsd xmm14, xmm15
000078eb87de1c95  ucomisd xmm14, xmm14
000078eb87de1c9a  jp 0x000078EB87DE1DCE
000078eb87de1ca0  movq xmm14, xmm14
000078eb87de1ca5  movaps [r15+0x110], xmm14
000078eb87de1cad  mov eax, [r15+0x108]
000078eb87de1cb4  sahf
000078eb87de1cb5  jnz 0x000078EB87DE1CE7
000078eb87de1cb7  cmp dword ptr [r15+0x318], 0x00
000078eb87de1cbf  jz 0x000078EB87DE1FE0
000078eb87de1cc5  nop [rax+rax*1], ax
000078eb87de1cce  nop [rax+rax*1], eax
000078eb87de1cd6  mov eax, 0x410490
000078eb87de1cdb  mov [r15+0x100], rax
000078eb87de1ce2  jmp 0x000078EB87BFE110
000078eb87de1ce7  cmp dword ptr [r15+0x318], 0x00
000078eb87de1cef  jz 0x000078EB87DE1E20
000078eb87de1cf5  nop [rax+rax*1], ax
000078eb87de1cfe  nop [rax+rax*1], eax
000078eb87de1d06  mov eax, 0x410474
000078eb87de1d0b  mov [r15+0x100], rax
000078eb87de1d12  jmp 0x000078EB87BFE110
000078eb87de1d17  int3
000078eb87de1d18  call 0x000078EB87CE27E0
000078eb87de1d1d  jmp 0x000078EB87DE1AC3
000078eb87de1d22  call 0x000078EB87CE27E0
000078eb87de1d27  jmp 0x000078EB87DE1AD6
000078eb87de1d2c  call 0x000078EB87CE1570
000078eb87de1d31  jmp 0x000078EB87DE1AE2
000078eb87de1d36  call 0x000078EB87CE27E0
000078eb87de1d3b  jmp 0x000078EB87DE1B1A
000078eb87de1d40  call 0x000078EB87CE1570
000078eb87de1d45  jmp 0x000078EB87DE1B26
000078eb87de1d4a  call 0x000078EB87CE27E0
000078eb87de1d4f  jmp 0x000078EB87DE1B5E
000078eb87de1d54  call 0x000078EB87CE1570
000078eb87de1d59  jmp 0x000078EB87DE1B6A
000078eb87de1d5e  call 0x000078EB87CE27E0
000078eb87de1d63  jmp 0x000078EB87DE1BA2
000078eb87de1d68  call 0x000078EB87CE1570
000078eb87de1d6d  jmp 0x000078EB87DE1BAE
000078eb87de1d72  call 0x000078EB87CE27E0
000078eb87de1d77  jmp 0x000078EB87DE1BED
000078eb87de1d7c  call 0x000078EB87C0E760
000078eb87de1d81  jmp 0x000078EB87DE1C0A
000078eb87de1d86  ucomisd xmm1, xmm15
000078eb87de1d8b  jp 0x000078EB87DE1D9A
000078eb87de1d8d  movaps xmm13, [0x000078EB879FE060]
000078eb87de1d95  jmp 0x000078EB87DE1C73
000078eb87de1d9a  vxorps xmm0, xmm1, xmm15
000078eb87de1d9f  pextrw eax, xmm0, 0x03
000078eb87de1da4  and eax, 0x7FF8
000078eb87de1da9  cmp eax, 0x08
000078eb87de1dac  jnz 0x000078EB87DE1C73
000078eb87de1db2  movq rax, xmm15
000078eb87de1db7  shl rax, 0x0D
000078eb87de1dbb  jbe 0x000078EB87DE1C73
000078eb87de1dc1  vorps xmm13, xmm15, [0x000078EB879FE070]
000078eb87de1dc9  jmp 0x000078EB87DE1C73
000078eb87de1dce  ucomisd xmm1, xmm15
000078eb87de1dd3  jp 0x000078EB87DE1DE2
000078eb87de1dd5  movaps xmm14, [0x000078EB879FE060]
000078eb87de1ddd  jmp 0x000078EB87DE1CA0
000078eb87de1de2  vxorps xmm0, xmm1, xmm15
000078eb87de1de7  pextrw eax, xmm0, 0x03
000078eb87de1dec  and eax, 0x7FF8
000078eb87de1df1  cmp eax, 0x08
000078eb87de1df4  jnz 0x000078EB87DE1CA0
000078eb87de1dfa  movq rax, xmm15
000078eb87de1dff  shl rax, 0x0D
000078eb87de1e03  jbe 0x000078EB87DE1CA0
000078eb87de1e09  vorps xmm14, xmm15, [0x000078EB879FE070]
000078eb87de1e11  jmp 0x000078EB87DE1CA0
000078eb87de1e16  int3
000078eb87de1e17  nop [rax+rax*1], ax
000078eb87de1e20  mov rax, [r15+0x48]
000078eb87de1e24  mov r14, [r15+0x50]
000078eb87de1e28  lea r12, [r14+rax*1]
000078eb87de1e2c  movups xmm1, [r13+r12*1]
000078eb87de1e32  movaps [r15+0x120], xmm1
000078eb87de1e3a  lea r14, [rax+0x10]
000078eb87de1e3e  mov [r15+0x48], r14
000078eb87de1e42  xor eax, eax
000078eb87de1e44  mov r12d, 0x200
000078eb87de1e4a  cmp r14, r12
000078eb87de1e4d  cmc
000078eb87de1e4e  lahf
000078eb87de1e4f  seto al
000078eb87de1e52  mov [r15+0x108], eax
000078eb87de1e59  pextrq rax, xmm1, 0x01
000078eb87de1e60  movq xmm15, rax
000078eb87de1e65  movaps [r15+0x130], xmm15
000078eb87de1e6d  movaps xmm14, [r15+0x110]
000078eb87de1e75  movq rax, xmm14
000078eb87de1e7a  movq r14, xmm1
000078eb87de1e7f  vmovq xmm1, rax
000078eb87de1e84  vmovq xmm14, r14
000078eb87de1e89  movaps xmm13, xmm1
000078eb87de1e8d  addsd xmm13, xmm14
000078eb87de1e92  ucomisd xmm13, xmm13
000078eb87de1e97  jp 0x000078EB87DE1F4C
000078eb87de1e9d  movq xmm13, xmm13
000078eb87de1ea2  movq rax, xmm13
000078eb87de1ea7  movq r14, xmm15
000078eb87de1eac  vmovq xmm1, rax
000078eb87de1eb1  vmovq xmm15, r14
000078eb87de1eb6  movaps xmm14, xmm1
000078eb87de1eba  addsd xmm14, xmm15
000078eb87de1ebf  ucomisd xmm14, xmm14
000078eb87de1ec4  jp 0x000078EB87DE1F94
000078eb87de1eca  movq xmm14, xmm14
000078eb87de1ecf  movaps [r15+0x110], xmm14
000078eb87de1ed7  mov eax, [r15+0x108]
000078eb87de1ede  sahf
000078eb87de1edf  jnz 0x000078EB87DE1F11
000078eb87de1ee1  cmp dword ptr [r15+0x318], 0x00
000078eb87de1ee9  jz 0x000078EB87DE1FE0
000078eb87de1eef  nop [rax+rax*1], ax
000078eb87de1ef8  nop [rax+rax*1], eax
000078eb87de1f00  mov eax, 0x410490
000078eb87de1f05  mov [r15+0x100], rax
000078eb87de1f0c  jmp 0x000078EB87BFE110
000078eb87de1f11  cmp dword ptr [r15+0x318], 0x00
000078eb87de1f19  jz 0x000078EB87DE1E20
000078eb87de1f1f  nop [rax+rax*1], ax
000078eb87de1f28  nop [rax+rax*1], eax
000078eb87de1f30  mov eax, 0x410474
000078eb87de1f35  mov [r15+0x100], rax
000078eb87de1f3c  jmp 0x000078EB87BFE110
000078eb87de1f41  int3
000078eb87de1f42  call 0x000078EB87CB52F0
000078eb87de1f47  jmp 0x000078EB87DE1E32
000078eb87de1f4c  ucomisd xmm1, xmm14
000078eb87de1f51  jp 0x000078EB87DE1F60
000078eb87de1f53  movaps xmm13, [0x000078EB879FE060]
000078eb87de1f5b  jmp 0x000078EB87DE1E9D
000078eb87de1f60  vxorps xmm0, xmm1, xmm14
000078eb87de1f65  pextrw eax, xmm0, 0x03
000078eb87de1f6a  and eax, 0x7FF8
000078eb87de1f6f  cmp eax, 0x08
000078eb87de1f72  jnz 0x000078EB87DE1E9D
000078eb87de1f78  movq rax, xmm14
000078eb87de1f7d  shl rax, 0x0D
000078eb87de1f81  jbe 0x000078EB87DE1E9D
000078eb87de1f87  vorps xmm13, xmm14, [0x000078EB879FE070]
000078eb87de1f8f  jmp 0x000078EB87DE1E9D
000078eb87de1f94  ucomisd xmm1, xmm15
000078eb87de1f99  jp 0x000078EB87DE1FA8
000078eb87de1f9b  movaps xmm14, [0x000078EB879FE060]
000078eb87de1fa3  jmp 0x000078EB87DE1ECA
000078eb87de1fa8  vxorps xmm0, xmm1, xmm15
000078eb87de1fad  pextrw eax, xmm0, 0x03
000078eb87de1fb2  and eax, 0x7FF8
000078eb87de1fb7  cmp eax, 0x08
000078eb87de1fba  jnz 0x000078EB87DE1ECA
000078eb87de1fc0  movq rax, xmm15
000078eb87de1fc5  shl rax, 0x0D
000078eb87de1fc9  jbe 0x000078EB87DE1ECA
000078eb87de1fcf  vorps xmm14, xmm15, [0x000078EB879FE070]
000078eb87de1fd7  jmp 0x000078EB87DE1ECA
000078eb87de1fdc  int3
000078eb87de1fdd  nop [rax], eax
000078eb87de1fe0  mov rax, [r15+0x40]
000078eb87de1fe4  lea r14, [rax+0x510]
000078eb87de1feb  movaps xmm1, [r15+0x110]
000078eb87de1ff3  movq rax, xmm1
000078eb87de1ff8  mov [r13+r14*1], rax
000078eb87de1ffd  mov rax, [r15+0xF0]
000078eb87de2004  mov [r15+0x100], rax
000078eb87de200b  jmp 0x000078EB87DCE5C0
000078eb87de2010  int3
000078eb87de2011  call 0x000078EB87CD5EB0
000078eb87de2016  jmp 0x000078EB87DE1FFD
000078eb87de201b  int3
000078eb87de201c  nop [rax], eax
000078eb87de2020  mov qword ptr [r15+0x100], 0x04
000078eb87de202b  mov esi, 0x00
000078eb87de2030  mov edx, 0x09
000078eb87de2035  mov rdi, 0x7FFE7927C980
000078eb87de203f  mov rax, 0x61D341904970
000078eb87de2049  call rax
000078eb87de204b  cmp dword ptr [r15+0x318], 0x00
000078eb87de2053  jnz 0x000078EB87BFE110
000078eb87de2059  jmp 0x000078EB87BFE0A0
000078eb87de205e  int3
000078eb87de205f  int3
