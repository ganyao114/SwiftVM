000075aec0bce69b  nop [rax+rax*1], eax
000075aec0bce6a0  vmovaps xmm1, [0x000075AEC07FE010]
000075aec0bce6a8  movq xmm1, xmm1
000075aec0bce6ac  movaps [r15+0x110], xmm1
000075aec0bce6b4  vmovaps xmm1, [0x000075AEC07FE020]
000075aec0bce6bc  movq xmm1, xmm1
000075aec0bce6c0  movaps [r15+0x120], xmm1
000075aec0bce6c8  mov eax, 0x4204C0
000075aec0bce6cd  mov r14, [r13+rax*1]
000075aec0bce6d2  movq xmm1, r14
000075aec0bce6d7  movaps [r15+0x130], xmm1
000075aec0bce6df  vmovaps xmm1, [0x000075AEC07FE030]
000075aec0bce6e7  vpbroadcastq xmm1, xmm1
000075aec0bce6ec  movaps [r15+0x140], xmm1
000075aec0bce6f4  mov qword ptr [r15+0x40], 0x02
000075aec0bce6fc  vmovaps xmm15, [0x000075AEC07FE040]
000075aec0bce704  movq xmm15, xmm15
000075aec0bce709  movaps [r15+0x150], xmm15
000075aec0bce711  mov qword ptr [r15+0x58], 0x420000
000075aec0bce719  vmovaps xmm15, [0x000075AEC07FE050]
000075aec0bce721  vpbroadcastq xmm15, xmm15
000075aec0bce726  movaps [r15+0x160], xmm15
000075aec0bce72e  mov rax, [r15+0x40]
000075aec0bce732  vmovq xmm14, rax
000075aec0bce737  vpbroadcastq xmm14, xmm14
000075aec0bce73c  movaps [r15+0x170], xmm14
000075aec0bce744  mov eax, 0x4204D0
000075aec0bce749  movups xmm13, [r13+rax*1]
000075aec0bce74f  mov qword ptr [r15+0x40], 0x430518
000075aec0bce757  mov qword ptr [r15+0x50], 0x430720
000075aec0bce75f  vpmovqd xmm12, xmm13
000075aec0bce765  pxor xmm11, xmm11
000075aec0bce76a  punpcklqdq xmm12, xmm11
000075aec0bce76f  movaps [r15+0x210], xmm12
000075aec0bce777  movq xmm12, qword ptr [r15+0x120]
000075aec0bce780  movq xmm11, qword ptr [r15+0x130]
000075aec0bce789  psubd xmm12, xmm11
000075aec0bce78e  movq xmm12, xmm12
000075aec0bce793  paddq xmm13, xmm14
000075aec0bce798  movaps [r15+0x180], xmm13
000075aec0bce7a0  movq xmm14, qword ptr [r15+0x150]
000075aec0bce7a9  paddd xmm11, xmm14
000075aec0bce7ae  movq xmm11, xmm11
000075aec0bce7b3  movq xmm11, xmm11
000075aec0bce7b8  movaps [r15+0x130], xmm11
000075aec0bce7c0  pmovzxdq xmm12, xmm12
000075aec0bce7c6  psllq xmm12, 0x00
000075aec0bce7cc  movq xmm14, qword ptr [r15+0x210]
000075aec0bce7d5  movq xmm13, qword ptr [r15+0x110]
000075aec0bce7de  paddd xmm14, xmm13
000075aec0bce7e3  movq xmm14, xmm14
000075aec0bce7e8  vcvtuqq2pd xmm12, xmm12
000075aec0bce7ee  pmovzxdq xmm14, xmm14
000075aec0bce7f4  psllq xmm14, 0x00
000075aec0bce7fa  vcvtuqq2pd xmm14, xmm14
000075aec0bce800  movaps xmm13, xmm12
000075aec0bce804  mulpd xmm13, xmm1
000075aec0bce809  vcmppd xmm11, xmm13, xmm13, 0x03
000075aec0bce80f  ptest xmm11, xmm11
000075aec0bce815  jnz 0x000075AEC0BCE8FF
000075aec0bce81b  movaps [r15+0x220], xmm13
000075aec0bce823  mov eax, 0x430720
000075aec0bce828  movups [r13+rax*1], xmm13
000075aec0bce82e  movaps xmm1, xmm14
000075aec0bce832  mulpd xmm1, xmm15
000075aec0bce837  vcmppd xmm13, xmm1, xmm1, 0x03
000075aec0bce83c  ptest xmm13, xmm13
000075aec0bce842  jnz 0x000075AEC0BCEA4C
000075aec0bce848  movaps [r15+0x210], xmm1
000075aec0bce850  mov eax, 0x430518
000075aec0bce855  movups [r13+rax*1], xmm1
000075aec0bce85b  mov qword ptr [r15+0x48], 0x10
000075aec0bce863  xor eax, eax
000075aec0bce865  mov r14d, 0x10
000075aec0bce86b  mov r12d, 0x200
000075aec0bce871  cmp r14, r12
000075aec0bce874  cmc
000075aec0bce875  lahf
000075aec0bce876  seto al
000075aec0bce879  mov [r15+0x108], eax
000075aec0bce880  mov eax, [r15+0x108]
000075aec0bce887  sahf
000075aec0bce888  jnz 0x000075AEC0BCE8BA
000075aec0bce88a  cmp dword ptr [r15+0x318], 0x00
000075aec0bce892  jz 0x000075AEC0BCEFF0
000075aec0bce898  nop [rax+rax*1], ax
000075aec0bce8a1  nop [rax+rax*1], eax
000075aec0bce8a9  mov eax, 0x4101EC
000075aec0bce8ae  mov [r15+0x100], rax
000075aec0bce8b5  jmp 0x000075AEC09FE110
000075aec0bce8ba  cmp dword ptr [r15+0x318], 0x00
000075aec0bce8c2  jz 0x000075AEC0BCEBA0
000075aec0bce8c8  nop [rax+rax*1], ax
000075aec0bce8d1  nop [rax+rax*1], eax
000075aec0bce8d9  mov eax, 0x4101AC
000075aec0bce8de  mov [r15+0x100], rax
000075aec0bce8e5  jmp 0x000075AEC09FE110
000075aec0bce8ea  int3
000075aec0bce8eb  call 0x000075AEC0A0DC20
000075aec0bce8f0  jmp 0x000075AEC0BCE6D2
000075aec0bce8f5  call 0x000075AEC0A0C260
000075aec0bce8fa  jmp 0x000075AEC0BCE74F
000075aec0bce8ff  sub rsp, 0x08
000075aec0bce903  push rax
000075aec0bce904  push rcx
000075aec0bce905  push rdx
000075aec0bce906  push rdi
000075aec0bce907  push rsi
000075aec0bce908  push r8
000075aec0bce90a  push r9
000075aec0bce90c  push r10
000075aec0bce90e  push r11
000075aec0bce910  sub rsp, 0xF0
000075aec0bce917  vmovaps [rsp], xmm0
000075aec0bce91c  vmovaps [rsp+0x10], xmm1
000075aec0bce922  vmovaps [rsp+0x20], xmm2
000075aec0bce928  vmovaps [rsp+0x30], xmm3
000075aec0bce92e  vmovaps [rsp+0x40], xmm4
000075aec0bce934  vmovaps [rsp+0x50], xmm5
000075aec0bce93a  vmovaps [rsp+0x60], xmm6
000075aec0bce940  vmovaps [rsp+0x70], xmm7
000075aec0bce946  vmovaps [rsp+0x80], xmm8
000075aec0bce94f  vmovaps [rsp+0x90], xmm9
000075aec0bce958  vmovaps [rsp+0xA0], xmm10
000075aec0bce961  vmovaps [rsp+0xB0], xmm11
000075aec0bce96a  vmovaps [rsp+0xC0], xmm12
000075aec0bce973  vmovaps [rsp+0xD0], xmm14
000075aec0bce97c  vmovaps [rsp+0xE0], xmm15
000075aec0bce985  sub rsp, 0x30
000075aec0bce989  movaps [rsp], xmm13
000075aec0bce98e  movaps [rsp+0x10], xmm12
000075aec0bce994  movaps [rsp+0x20], xmm1
000075aec0bce999  lea rdi, [rsp]
000075aec0bce99d  mov esi, 0x00
000075aec0bce9a2  mov rax, 0x57F4B31E6530
000075aec0bce9ac  call rax
000075aec0bce9ae  movaps xmm13, [rsp]
000075aec0bce9b3  add rsp, 0x30
000075aec0bce9b7  vmovaps xmm0, [rsp]
000075aec0bce9bc  vmovaps xmm1, [rsp+0x10]
000075aec0bce9c2  vmovaps xmm2, [rsp+0x20]
000075aec0bce9c8  vmovaps xmm3, [rsp+0x30]
000075aec0bce9ce  vmovaps xmm4, [rsp+0x40]
000075aec0bce9d4  vmovaps xmm5, [rsp+0x50]
000075aec0bce9da  vmovaps xmm6, [rsp+0x60]
000075aec0bce9e0  vmovaps xmm7, [rsp+0x70]
000075aec0bce9e6  vmovaps xmm8, [rsp+0x80]
000075aec0bce9ef  vmovaps xmm9, [rsp+0x90]
000075aec0bce9f8  vmovaps xmm10, [rsp+0xA0]
000075aec0bcea01  vmovaps xmm11, [rsp+0xB0]
000075aec0bcea0a  vmovaps xmm12, [rsp+0xC0]
000075aec0bcea13  vmovaps xmm14, [rsp+0xD0]
000075aec0bcea1c  vmovaps xmm15, [rsp+0xE0]
000075aec0bcea25  add rsp, 0xF0
000075aec0bcea2c  pop r11
000075aec0bcea2e  pop r10
000075aec0bcea30  pop r9
000075aec0bcea32  pop r8
000075aec0bcea34  pop rsi
000075aec0bcea35  pop rdi
000075aec0bcea36  pop rdx
000075aec0bcea37  pop rcx
000075aec0bcea38  pop rax
000075aec0bcea39  add rsp, 0x08
000075aec0bcea3d  jmp 0x000075AEC0BCE81B
000075aec0bcea42  call 0x000075AEC0A0C380
000075aec0bcea47  jmp 0x000075AEC0BCE82E
000075aec0bcea4c  sub rsp, 0x08
000075aec0bcea50  push rax
000075aec0bcea51  push rcx
000075aec0bcea52  push rdx
000075aec0bcea53  push rdi
000075aec0bcea54  push rsi
000075aec0bcea55  push r8
000075aec0bcea57  push r9
000075aec0bcea59  push r10
000075aec0bcea5b  push r11
000075aec0bcea5d  sub rsp, 0xF0
000075aec0bcea64  vmovaps [rsp], xmm0
000075aec0bcea69  vmovaps [rsp+0x10], xmm2
000075aec0bcea6f  vmovaps [rsp+0x20], xmm3
000075aec0bcea75  vmovaps [rsp+0x30], xmm4
000075aec0bcea7b  vmovaps [rsp+0x40], xmm5
000075aec0bcea81  vmovaps [rsp+0x50], xmm6
000075aec0bcea87  vmovaps [rsp+0x60], xmm7
000075aec0bcea8d  vmovaps [rsp+0x70], xmm8
000075aec0bcea93  vmovaps [rsp+0x80], xmm9
000075aec0bcea9c  vmovaps [rsp+0x90], xmm10
000075aec0bceaa5  vmovaps [rsp+0xA0], xmm11
000075aec0bceaae  vmovaps [rsp+0xB0], xmm12
000075aec0bceab7  vmovaps [rsp+0xC0], xmm13
000075aec0bceac0  vmovaps [rsp+0xD0], xmm14
000075aec0bceac9  vmovaps [rsp+0xE0], xmm15
000075aec0bcead2  sub rsp, 0x30
000075aec0bcead6  movaps [rsp], xmm1
000075aec0bceada  movaps [rsp+0x10], xmm14
000075aec0bceae0  movaps [rsp+0x20], xmm15
000075aec0bceae6  lea rdi, [rsp]
000075aec0bceaea  mov esi, 0x00
000075aec0bceaef  mov rax, 0x57F4B31E6530
000075aec0bceaf9  call rax
000075aec0bceafb  movaps xmm1, [rsp]
000075aec0bceaff  add rsp, 0x30
000075aec0bceb03  vmovaps xmm0, [rsp]
000075aec0bceb08  vmovaps xmm2, [rsp+0x10]
000075aec0bceb0e  vmovaps xmm3, [rsp+0x20]
000075aec0bceb14  vmovaps xmm4, [rsp+0x30]
000075aec0bceb1a  vmovaps xmm5, [rsp+0x40]
000075aec0bceb20  vmovaps xmm6, [rsp+0x50]
000075aec0bceb26  vmovaps xmm7, [rsp+0x60]
000075aec0bceb2c  vmovaps xmm8, [rsp+0x70]
000075aec0bceb32  vmovaps xmm9, [rsp+0x80]
000075aec0bceb3b  vmovaps xmm10, [rsp+0x90]
000075aec0bceb44  vmovaps xmm11, [rsp+0xA0]
000075aec0bceb4d  vmovaps xmm12, [rsp+0xB0]
000075aec0bceb56  vmovaps xmm13, [rsp+0xC0]
000075aec0bceb5f  vmovaps xmm14, [rsp+0xD0]
000075aec0bceb68  vmovaps xmm15, [rsp+0xE0]
000075aec0bceb71  add rsp, 0xF0
000075aec0bceb78  pop r11
000075aec0bceb7a  pop r10
000075aec0bceb7c  pop r9
000075aec0bceb7e  pop r8
000075aec0bceb80  pop rsi
000075aec0bceb81  pop rdi
000075aec0bceb82  pop rdx
000075aec0bceb83  pop rcx
000075aec0bceb84  pop rax
000075aec0bceb85  add rsp, 0x08
000075aec0bceb89  jmp 0x000075AEC0BCE848
000075aec0bceb8e  call 0x000075AEC09FF540
000075aec0bceb93  jmp 0x000075AEC0BCE85B
000075aec0bceb98  int3
000075aec0bceb99  nop [rax], eax
000075aec0bceba0  movaps xmm1, [r15+0x180]
000075aec0bceba8  vpmovqd xmm15, xmm1
000075aec0bcebae  pxor xmm14, xmm14
000075aec0bcebb3  punpcklqdq xmm15, xmm14
000075aec0bcebb8  movaps [r15+0x210], xmm15
000075aec0bcebc0  movq xmm15, qword ptr [r15+0x120]
000075aec0bcebc9  movq xmm14, qword ptr [r15+0x130]
000075aec0bcebd2  psubd xmm15, xmm14
000075aec0bcebd7  movq xmm15, xmm15
000075aec0bcebdc  movaps xmm13, [r15+0x170]
000075aec0bcebe4  paddq xmm1, xmm13
000075aec0bcebe9  movaps [r15+0x180], xmm1
000075aec0bcebf1  movq xmm1, qword ptr [r15+0x150]
000075aec0bcebfa  paddd xmm14, xmm1
000075aec0bcebff  movq xmm14, xmm14
000075aec0bcec04  movq xmm14, xmm14
000075aec0bcec09  movaps [r15+0x130], xmm14
000075aec0bcec11  pmovzxdq xmm15, xmm15
000075aec0bcec17  psllq xmm15, 0x00
000075aec0bcec1d  movq xmm1, qword ptr [r15+0x210]
000075aec0bcec26  movq xmm14, qword ptr [r15+0x110]
000075aec0bcec2f  paddd xmm1, xmm14
000075aec0bcec34  movq xmm1, xmm1
000075aec0bcec38  vcvtuqq2pd xmm15, xmm15
000075aec0bcec3e  pmovzxdq xmm1, xmm1
000075aec0bcec43  psllq xmm1, 0x00
000075aec0bcec48  vcvtuqq2pd xmm1, xmm1
000075aec0bcec4e  movaps xmm14, [r15+0x140]
000075aec0bcec56  movaps xmm13, xmm15
000075aec0bcec5a  mulpd xmm13, xmm14
000075aec0bcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000075aec0bcec65  ptest xmm12, xmm12
000075aec0bcec6b  jnz 0x000075AEC0BCED4E
000075aec0bcec71  movaps [r15+0x220], xmm13
000075aec0bcec79  mov rax, [r15+0x48]
000075aec0bcec7d  mov r14, [r15+0x50]
000075aec0bcec81  lea r12, [r14+rax*1]
000075aec0bcec85  movups [r13+r12*1], xmm13
000075aec0bcec8b  movaps xmm15, [r15+0x160]
000075aec0bcec93  movaps xmm14, xmm1
000075aec0bcec97  mulpd xmm14, xmm15
000075aec0bcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000075aec0bceca2  ptest xmm13, xmm13
000075aec0bceca8  jnz 0x000075AEC0BCEE9C
000075aec0bcecae  movaps [r15+0x210], xmm14
000075aec0bcecb6  mov r14, [r15+0x40]
000075aec0bcecba  lea r12, [r14+rax*1]
000075aec0bcecbe  movups [r13+r12*1], xmm14
000075aec0bcecc4  lea r14, [rax+0x10]
000075aec0bcecc8  mov [r15+0x48], r14
000075aec0bceccc  xor eax, eax
000075aec0bcecce  mov r12d, 0x200
000075aec0bcecd4  cmp r14, r12
000075aec0bcecd7  cmc
000075aec0bcecd8  lahf
000075aec0bcecd9  seto al
000075aec0bcecdc  mov [r15+0x108], eax
000075aec0bcece3  mov eax, [r15+0x108]
000075aec0bcecea  sahf
000075aec0bceceb  jnz 0x000075AEC0BCED1D
000075aec0bceced  cmp dword ptr [r15+0x318], 0x00
000075aec0bcecf5  jz 0x000075AEC0BCEFF0
000075aec0bcecfb  nop [rax+rax*1], ax
000075aec0bced04  nop [rax+rax*1], eax
000075aec0bced0c  mov eax, 0x4101EC
000075aec0bced11  mov [r15+0x100], rax
000075aec0bced18  jmp 0x000075AEC09FE110
000075aec0bced1d  cmp dword ptr [r15+0x318], 0x00
000075aec0bced25  jz 0x000075AEC0BCEBA0
000075aec0bced2b  nop [rax+rax*1], ax
000075aec0bced34  nop [rax+rax*1], eax
000075aec0bced3c  mov eax, 0x4101AC
000075aec0bced41  mov [r15+0x100], rax
000075aec0bced48  jmp 0x000075AEC09FE110
000075aec0bced4d  int3
000075aec0bced4e  sub rsp, 0x08
000075aec0bced52  push rax
000075aec0bced53  push rcx
000075aec0bced54  push rdx
000075aec0bced55  push rdi
000075aec0bced56  push rsi
000075aec0bced57  push r8
000075aec0bced59  push r9
000075aec0bced5b  push r10
000075aec0bced5d  push r11
000075aec0bced5f  sub rsp, 0xF0
000075aec0bced66  vmovaps [rsp], xmm0
000075aec0bced6b  vmovaps [rsp+0x10], xmm1
000075aec0bced71  vmovaps [rsp+0x20], xmm2
000075aec0bced77  vmovaps [rsp+0x30], xmm3
000075aec0bced7d  vmovaps [rsp+0x40], xmm4
000075aec0bced83  vmovaps [rsp+0x50], xmm5
000075aec0bced89  vmovaps [rsp+0x60], xmm6
000075aec0bced8f  vmovaps [rsp+0x70], xmm7
000075aec0bced95  vmovaps [rsp+0x80], xmm8
000075aec0bced9e  vmovaps [rsp+0x90], xmm9
000075aec0bceda7  vmovaps [rsp+0xA0], xmm10
000075aec0bcedb0  vmovaps [rsp+0xB0], xmm11
000075aec0bcedb9  vmovaps [rsp+0xC0], xmm12
000075aec0bcedc2  vmovaps [rsp+0xD0], xmm14
000075aec0bcedcb  vmovaps [rsp+0xE0], xmm15
000075aec0bcedd4  sub rsp, 0x30
000075aec0bcedd8  movaps [rsp], xmm13
000075aec0bceddd  movaps [rsp+0x10], xmm15
000075aec0bcede3  movaps [rsp+0x20], xmm14
000075aec0bcede9  lea rdi, [rsp]
000075aec0bceded  mov esi, 0x00
000075aec0bcedf2  mov rax, 0x57F4B31E6530
000075aec0bcedfc  call rax
000075aec0bcedfe  movaps xmm13, [rsp]
000075aec0bcee03  add rsp, 0x30
000075aec0bcee07  vmovaps xmm0, [rsp]
000075aec0bcee0c  vmovaps xmm1, [rsp+0x10]
000075aec0bcee12  vmovaps xmm2, [rsp+0x20]
000075aec0bcee18  vmovaps xmm3, [rsp+0x30]
000075aec0bcee1e  vmovaps xmm4, [rsp+0x40]
000075aec0bcee24  vmovaps xmm5, [rsp+0x50]
000075aec0bcee2a  vmovaps xmm6, [rsp+0x60]
000075aec0bcee30  vmovaps xmm7, [rsp+0x70]
000075aec0bcee36  vmovaps xmm8, [rsp+0x80]
000075aec0bcee3f  vmovaps xmm9, [rsp+0x90]
000075aec0bcee48  vmovaps xmm10, [rsp+0xA0]
000075aec0bcee51  vmovaps xmm11, [rsp+0xB0]
000075aec0bcee5a  vmovaps xmm12, [rsp+0xC0]
000075aec0bcee63  vmovaps xmm14, [rsp+0xD0]
000075aec0bcee6c  vmovaps xmm15, [rsp+0xE0]
000075aec0bcee75  add rsp, 0xF0
000075aec0bcee7c  pop r11
000075aec0bcee7e  pop r10
000075aec0bcee80  pop r9
000075aec0bcee82  pop r8
000075aec0bcee84  pop rsi
000075aec0bcee85  pop rdi
000075aec0bcee86  pop rdx
000075aec0bcee87  pop rcx
000075aec0bcee88  pop rax
000075aec0bcee89  add rsp, 0x08
000075aec0bcee8d  jmp 0x000075AEC0BCEC71
000075aec0bcee92  call 0x000075AEC0AC2240
000075aec0bcee97  jmp 0x000075AEC0BCEC8B
000075aec0bcee9c  sub rsp, 0x08
000075aec0bceea0  push rax
000075aec0bceea1  push rcx
000075aec0bceea2  push rdx
000075aec0bceea3  push rdi
000075aec0bceea4  push rsi
000075aec0bceea5  push r8
000075aec0bceea7  push r9
000075aec0bceea9  push r10
000075aec0bceeab  push r11
000075aec0bceead  sub rsp, 0xF0
000075aec0bceeb4  vmovaps [rsp], xmm0
000075aec0bceeb9  vmovaps [rsp+0x10], xmm1
000075aec0bceebf  vmovaps [rsp+0x20], xmm2
000075aec0bceec5  vmovaps [rsp+0x30], xmm3
000075aec0bceecb  vmovaps [rsp+0x40], xmm4
000075aec0bceed1  vmovaps [rsp+0x50], xmm5
000075aec0bceed7  vmovaps [rsp+0x60], xmm6
000075aec0bceedd  vmovaps [rsp+0x70], xmm7
000075aec0bceee3  vmovaps [rsp+0x80], xmm8
000075aec0bceeec  vmovaps [rsp+0x90], xmm9
000075aec0bceef5  vmovaps [rsp+0xA0], xmm10
000075aec0bceefe  vmovaps [rsp+0xB0], xmm11
000075aec0bcef07  vmovaps [rsp+0xC0], xmm12
000075aec0bcef10  vmovaps [rsp+0xD0], xmm13
000075aec0bcef19  vmovaps [rsp+0xE0], xmm15
000075aec0bcef22  sub rsp, 0x30
000075aec0bcef26  movaps [rsp], xmm14
000075aec0bcef2b  movaps [rsp+0x10], xmm1
000075aec0bcef30  movaps [rsp+0x20], xmm15
000075aec0bcef36  lea rdi, [rsp]
000075aec0bcef3a  mov esi, 0x00
000075aec0bcef3f  mov rax, 0x57F4B31E6530
000075aec0bcef49  call rax
000075aec0bcef4b  movaps xmm14, [rsp]
000075aec0bcef50  add rsp, 0x30
000075aec0bcef54  vmovaps xmm0, [rsp]
000075aec0bcef59  vmovaps xmm1, [rsp+0x10]
000075aec0bcef5f  vmovaps xmm2, [rsp+0x20]
000075aec0bcef65  vmovaps xmm3, [rsp+0x30]
000075aec0bcef6b  vmovaps xmm4, [rsp+0x40]
000075aec0bcef71  vmovaps xmm5, [rsp+0x50]
000075aec0bcef77  vmovaps xmm6, [rsp+0x60]
000075aec0bcef7d  vmovaps xmm7, [rsp+0x70]
000075aec0bcef83  vmovaps xmm8, [rsp+0x80]
000075aec0bcef8c  vmovaps xmm9, [rsp+0x90]
000075aec0bcef95  vmovaps xmm10, [rsp+0xA0]
000075aec0bcef9e  vmovaps xmm11, [rsp+0xB0]
000075aec0bcefa7  vmovaps xmm12, [rsp+0xC0]
000075aec0bcefb0  vmovaps xmm13, [rsp+0xD0]
000075aec0bcefb9  vmovaps xmm15, [rsp+0xE0]
000075aec0bcefc2  add rsp, 0xF0
000075aec0bcefc9  pop r11
000075aec0bcefcb  pop r10
000075aec0bcefcd  pop r9
000075aec0bcefcf  pop r8
000075aec0bcefd1  pop rsi
000075aec0bcefd2  pop rdi
000075aec0bcefd3  pop rdx
000075aec0bcefd4  pop rcx
000075aec0bcefd5  pop rax
000075aec0bcefd6  add rsp, 0x08
000075aec0bcefda  jmp 0x000075AEC0BCECAE
000075aec0bcefdf  call 0x000075AEC0AC34C0
000075aec0bcefe4  jmp 0x000075AEC0BCECC4
000075aec0bcefe9  int3
000075aec0bcefea  nop [rax+rax*1], ax
000075aec0bceff0  mov rax, [r15+0xF8]
000075aec0bceff7  lea r14, [rax-0x150]
000075aec0bceffe  mov [r15+0xF8], r14
000075aec0bcf005  mov rax, [r15+0x50]
000075aec0bcf009  lea r12, [rax+0x80]
000075aec0bcf010  movups xmm1, [r13+r12*1]
000075aec0bcf016  lea r12, [rax+0x90]
000075aec0bcf01d  movups xmm15, [r13+r12*1]
000075aec0bcf023  mov qword ptr [r15+0x48], 0x00
000075aec0bcf02b  lea r12, [rax+0x40]
000075aec0bcf02f  movups xmm14, [r13+r12*1]
000075aec0bcf035  lea r12, [rax+0x50]
000075aec0bcf039  movups xmm13, [r13+r12*1]
000075aec0bcf03f  lea r12, [r14+0x120]
000075aec0bcf046  movq xmm12, qword ptr [r15+0x1C0]
000075aec0bcf04f  movq xmm11, qword ptr [r15+0x1B0]
000075aec0bcf058  movq r11, xmm12
000075aec0bcf05d  movq r10, xmm11
000075aec0bcf062  mov [r13+r12*1], r11
000075aec0bcf067  lea r12, [r14+0x128]
000075aec0bcf06e  mov [r13+r12*1], r10
000075aec0bcf073  vxorps xmm12, xmm12, xmm12
000075aec0bcf078  vpbroadcastq xmm12, xmm12
000075aec0bcf07d  lea r12, [r14+0x100]
000075aec0bcf084  movq xmm11, qword ptr [r15+0x200]
000075aec0bcf08d  movq xmm10, qword ptr [r15+0x1F0]
000075aec0bcf096  movq r11, xmm11
000075aec0bcf09b  movq r10, xmm10
000075aec0bcf0a0  mov [r13+r12*1], r11
000075aec0bcf0a5  lea r12, [r14+0x108]
000075aec0bcf0ac  mov [r13+r12*1], r10
000075aec0bcf0b1  lea r12, [r14+0xE0]
000075aec0bcf0b8  movups [r13+r12*1], xmm15
000075aec0bcf0be  lea r12, [r14+0xF0]
000075aec0bcf0c5  movups [r13+r12*1], xmm1
000075aec0bcf0cb  lea r12, [rax+0xC0]
000075aec0bcf0d2  movups xmm1, [r13+r12*1]
000075aec0bcf0d8  lea r12, [rax+0xD0]
000075aec0bcf0df  movups xmm15, [r13+r12*1]
000075aec0bcf0e5  lea r12, [r14+0x110]
000075aec0bcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000075aec0bcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000075aec0bcf0fe  movq r11, xmm11
000075aec0bcf103  movq r10, xmm10
000075aec0bcf108  mov [r13+r12*1], r11
000075aec0bcf10d  lea r12, [r14+0x118]
000075aec0bcf114  mov [r13+r12*1], r10
000075aec0bcf119  movups xmm11, [r13+rax*1]
000075aec0bcf11f  lea r12, [rax+0x10]
000075aec0bcf123  movups xmm10, [r13+r12*1]
000075aec0bcf129  lea r12, [r14+0x130]
000075aec0bcf130  movq xmm9, qword ptr [r15+0x1A0]
000075aec0bcf139  movq xmm8, qword ptr [r15+0x190]
000075aec0bcf142  movq r11, xmm9
000075aec0bcf147  movq r10, xmm8
000075aec0bcf14c  mov [r13+r12*1], r11
000075aec0bcf151  lea r12, [r14+0x138]
000075aec0bcf158  mov [r13+r12*1], r10
000075aec0bcf15d  lea r12, [rax+0x140]
000075aec0bcf164  movups xmm9, [r13+r12*1]
000075aec0bcf16a  lea r12, [rax+0x150]
000075aec0bcf171  movups xmm8, [r13+r12*1]
000075aec0bcf177  lea r12, [r14+0xC0]
000075aec0bcf17e  movups [r13+r12*1], xmm15
000075aec0bcf184  lea r12, [r14+0xD0]
000075aec0bcf18b  movups [r13+r12*1], xmm1
000075aec0bcf191  lea r12, [rax+0x100]
000075aec0bcf198  movups xmm1, [r13+r12*1]
000075aec0bcf19e  lea r12, [rax+0x110]
000075aec0bcf1a5  movups xmm15, [r13+r12*1]
000075aec0bcf1ab  lea r12, [r14+0x140]
000075aec0bcf1b2  mov r11, [r15+0xE8]
000075aec0bcf1b9  mov [r13+r12*1], r11
000075aec0bcf1be  lea r12, [rax+0x180]
000075aec0bcf1c5  movups xmm7, [r13+r12*1]
000075aec0bcf1cb  lea r12, [rax+0x190]
000075aec0bcf1d2  movups xmm6, [r13+r12*1]
000075aec0bcf1d8  lea r12, [rax+0x1C0]
000075aec0bcf1df  movups xmm5, [r13+r12*1]
000075aec0bcf1e5  lea r12, [rax+0x1D0]
000075aec0bcf1ec  movups xmm4, [r13+r12*1]
000075aec0bcf1f2  lea r12, [r14+0x20]
000075aec0bcf1f6  movups [r13+r12*1], xmm1
000075aec0bcf1fc  lea r12, [r14+0x30]
000075aec0bcf200  movups [r13+r12*1], xmm13
000075aec0bcf206  lea r12, [rax+0x60]
000075aec0bcf20a  movups xmm1, [r13+r12*1]
000075aec0bcf210  lea r12, [rax+0x70]
000075aec0bcf214  movups xmm13, [r13+r12*1]
000075aec0bcf21a  lea r12, [rax+0x20]
000075aec0bcf21e  movups xmm3, [r13+r12*1]
000075aec0bcf224  lea r12, [rax+0x30]
000075aec0bcf228  movups xmm2, [r13+r12*1]
000075aec0bcf22e  movaps [r15+0x1F0], xmm2
000075aec0bcf236  lea r12, [r14+0x60]
000075aec0bcf23a  movups [r13+r12*1], xmm11
000075aec0bcf240  lea r12, [r14+0x70]
000075aec0bcf244  movups [r13+r12*1], xmm5
000075aec0bcf24a  lea r12, [rax+0xE0]
000075aec0bcf251  movups xmm11, [r13+r12*1]
000075aec0bcf257  lea r12, [rax+0xF0]
000075aec0bcf25e  movups xmm5, [r13+r12*1]
000075aec0bcf264  lea r12, [r14+0xA0]
000075aec0bcf26b  movups [r13+r12*1], xmm13
000075aec0bcf271  lea r12, [r14+0xB0]
000075aec0bcf278  movups [r13+r12*1], xmm1
000075aec0bcf27e  lea r12, [rax+0xA0]
000075aec0bcf285  movups xmm1, [r13+r12*1]
000075aec0bcf28b  lea r12, [rax+0xB0]
000075aec0bcf292  movups xmm13, [r13+r12*1]
000075aec0bcf298  lea r12, [rax+0x120]
000075aec0bcf29f  vmovaps [rsp+0x10], xmm1
000075aec0bcf2a5  movups xmm1, [r13+r12*1]
000075aec0bcf2ab  lea r12, [rax+0x130]
000075aec0bcf2b2  vmovaps [rsp+0x20], xmm1
000075aec0bcf2b8  movups xmm1, [r13+r12*1]
000075aec0bcf2be  lea r12, [rax+0x160]
000075aec0bcf2c5  vmovaps [rsp+0x30], xmm1
000075aec0bcf2cb  movups xmm1, [r13+r12*1]
000075aec0bcf2d1  lea r12, [rax+0x170]
000075aec0bcf2d8  vmovaps [rsp+0x40], xmm1
000075aec0bcf2de  movups xmm1, [r13+r12*1]
000075aec0bcf2e4  movaps [r15+0x2B0], xmm1
000075aec0bcf2ec  lea r12, [r14+0x80]
000075aec0bcf2f3  movups [r13+r12*1], xmm13
000075aec0bcf2f9  lea r12, [r14+0x90]
000075aec0bcf300  vmovaps xmm13, [rsp+0x10]
000075aec0bcf306  movups [r13+r12*1], xmm13
000075aec0bcf30c  lea r12, [rax+0x1A0]
000075aec0bcf313  movups xmm13, [r13+r12*1]
000075aec0bcf319  lea r12, [rax+0x1B0]
000075aec0bcf320  vmovaps [rsp+0x10], xmm1
000075aec0bcf326  movups xmm1, [r13+r12*1]
000075aec0bcf32c  movaps [r15+0x290], xmm13
000075aec0bcf334  movaps [r15+0x1E0], xmm1
000075aec0bcf33c  lea r12, [rax+0x1E0]
000075aec0bcf343  vmovaps [rsp+0x50], xmm1
000075aec0bcf349  movups xmm1, [r13+r12*1]
000075aec0bcf34f  lea r12, [rax+0x1F0]
000075aec0bcf356  vmovaps [rsp+0x60], xmm1
000075aec0bcf35c  movups xmm1, [r13+r12*1]
000075aec0bcf362  mov qword ptr [r15+0x50], 0x430920
000075aec0bcf36a  lea rax, [r14+0x40]
000075aec0bcf36e  vmovaps [rsp+0x70], xmm1
000075aec0bcf374  vmovaps xmm1, [rsp+0x40]
000075aec0bcf37a  movups [r13+rax*1], xmm1
000075aec0bcf380  lea rax, [r14+0x50]
000075aec0bcf384  movups [r13+rax*1], xmm10
000075aec0bcf38a  vmovaps xmm1, [rsp+0x70]
000075aec0bcf390  movups [r13+r14*1], xmm1
000075aec0bcf396  lea rax, [r14+0x10]
000075aec0bcf39a  vmovaps xmm1, [rsp+0x60]
000075aec0bcf3a0  movups [r13+rax*1], xmm1
000075aec0bcf3a6  mov rax, [r15+0x40]
000075aec0bcf3aa  vmovaps [rsp+0x40], xmm3
000075aec0bcf3b0  vmovaps xmm1, [rsp+0x40]
000075aec0bcf3b6  por xmm3, xmm1
000075aec0bcf3ba  vmovaps [rsp+0x40], xmm6
000075aec0bcf3c0  vmovaps xmm10, [rsp+0x40]
000075aec0bcf3c6  por xmm6, xmm10
000075aec0bcf3cb  lea r12, [rax+0x30]
000075aec0bcf3cf  mov r11, [r13+r12*1]
000075aec0bcf3d4  lea r12, [rax+0x38]
000075aec0bcf3d8  mov r10, [r13+r12*1]
000075aec0bcf3dd  movq xmm10, r11
000075aec0bcf3e2  vmovaps [rsp+0x40], xmm1
000075aec0bcf3e8  movq xmm1, r10
000075aec0bcf3ed  movq xmm10, xmm10
000075aec0bcf3f2  vmovaps [rsp+0x60], xmm10
000075aec0bcf3f8  movq xmm10, xmm10
000075aec0bcf3fd  movaps [r15+0x130], xmm10
000075aec0bcf405  movq xmm1, xmm1
000075aec0bcf409  vmovaps [rsp+0x70], xmm1
000075aec0bcf40f  movq xmm1, xmm1
000075aec0bcf413  movaps [r15+0x280], xmm1
000075aec0bcf41b  vmovaps [rsp+0x80], xmm9
000075aec0bcf424  vmovaps xmm1, [rsp+0x80]
000075aec0bcf42d  por xmm9, xmm1
000075aec0bcf432  lea r12, [rax+0x20]
000075aec0bcf436  mov r11, [r13+r12*1]
000075aec0bcf43b  lea r12, [rax+0x28]
000075aec0bcf43f  mov r10, [r13+r12*1]
000075aec0bcf444  movq xmm1, r11
000075aec0bcf449  movq xmm10, r10
000075aec0bcf44e  movq xmm1, xmm1
000075aec0bcf452  vmovaps [rsp+0x80], xmm1
000075aec0bcf45b  movq xmm1, xmm1
000075aec0bcf45f  movaps [r15+0x150], xmm1
000075aec0bcf467  movq xmm10, xmm10
000075aec0bcf46c  vmovaps [rsp+0x90], xmm10
000075aec0bcf475  movq xmm10, xmm10
000075aec0bcf47a  movaps [r15+0x140], xmm10
000075aec0bcf482  lea r12, [rax+0x10]
000075aec0bcf486  mov r11, [r13+r12*1]
000075aec0bcf48b  lea r12, [rax+0x18]
000075aec0bcf48f  mov r10, [r13+r12*1]
000075aec0bcf494  movq xmm1, r11
000075aec0bcf499  movq xmm10, r10
000075aec0bcf49e  movq xmm1, xmm1
000075aec0bcf4a2  vmovaps [rsp+0xA0], xmm1
000075aec0bcf4ab  movq xmm1, xmm1
000075aec0bcf4af  movaps [r15+0x170], xmm1
000075aec0bcf4b7  movq xmm10, xmm10
000075aec0bcf4bc  vmovaps [rsp+0xB0], xmm10
000075aec0bcf4c5  movq xmm10, xmm10
000075aec0bcf4ca  movaps [r15+0x160], xmm10
000075aec0bcf4d2  mov r12, [r13+rax*1]
000075aec0bcf4d7  vmovq xmm1, r12
000075aec0bcf4dc  vpbroadcastq xmm1, xmm1
000075aec0bcf4e1  lea r12, [rax+0x08]
000075aec0bcf4e5  mov rax, [r13+r12*1]
000075aec0bcf4ea  movq xmm10, rax
000075aec0bcf4ef  movaps [r15+0x230], xmm10
000075aec0bcf4f7  lea rax, [r14+0x50]
000075aec0bcf4fb  movups xmm10, [r13+rax*1]
000075aec0bcf501  lea rax, [r14+0x60]
000075aec0bcf505  vmovaps [rsp+0xC0], xmm1
000075aec0bcf50e  movups xmm1, [r13+rax*1]
000075aec0bcf514  lea rax, [r14+0x30]
000075aec0bcf518  vmovaps [rsp+0xD0], xmm1
000075aec0bcf521  movups xmm1, [r13+rax*1]
000075aec0bcf527  mov qword ptr [r15+0x60], 0x430920
000075aec0bcf52f  mov qword ptr [r15+0x58], 0x40
000075aec0bcf537  vmovaps [rsp+0xE0], xmm1
000075aec0bcf540  vmovaps [rsp+0xF0], xmm15
000075aec0bcf549  vmovaps xmm15, [rsp+0xC0]
000075aec0bcf552  vmovaps [rsp+0xC0], xmm14
000075aec0bcf55b  vmovaps xmm14, [rsp+0x40]
000075aec0bcf561  vmovaps [rsp+0x40], xmm13
000075aec0bcf567  movaps xmm1, xmm15
000075aec0bcf56b  mulpd xmm1, xmm14
000075aec0bcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000075aec0bcf575  ptest xmm13, xmm13
000075aec0bcf57b  jnz 0x000075AEC0BD0682
000075aec0bcf581  movq xmm14, qword ptr [r15+0x230]
000075aec0bcf58a  vmovaps [rsp+0x100], xmm14
000075aec0bcf593  vpermilpd xmm14, xmm14, 0x00
000075aec0bcf599  vmovaps [rsp+0x110], xmm1
000075aec0bcf5a2  vmovaps xmm1, [rsp+0xE0]
000075aec0bcf5ab  vmovaps [rsp+0xE0], xmm15
000075aec0bcf5b4  movaps xmm13, xmm1
000075aec0bcf5b8  mulpd xmm13, xmm14
000075aec0bcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000075aec0bcf5c3  ptest xmm15, xmm15
000075aec0bcf5c9  jnz 0x000075AEC0BD07C4
000075aec0bcf5cf  vxorps xmm1, xmm1, xmm1
000075aec0bcf5d3  vpbroadcastq xmm1, xmm1
000075aec0bcf5d8  vmovaps xmm14, [rsp+0xE0]
000075aec0bcf5e1  vmovaps [rsp+0xE0], xmm1
000075aec0bcf5ea  vmovaps xmm1, [rsp+0xD0]
000075aec0bcf5f3  vmovaps [rsp+0xD0], xmm13
000075aec0bcf5fc  movaps xmm15, xmm14
000075aec0bcf600  mulpd xmm15, xmm1
000075aec0bcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000075aec0bcf60b  ptest xmm13, xmm13
000075aec0bcf611  jnz 0x000075AEC0BD0907
000075aec0bcf617  movaps xmm1, xmm14
000075aec0bcf61b  mulpd xmm1, xmm10
000075aec0bcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000075aec0bcf625  ptest xmm13, xmm13
000075aec0bcf62b  jnz 0x000075AEC0BD0A4A
000075aec0bcf631  movaps xmm13, xmm14
000075aec0bcf635  mulpd xmm13, xmm2
000075aec0bcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000075aec0bcf640  ptest xmm10, xmm10
000075aec0bcf646  jnz 0x000075AEC0BD0B8C
000075aec0bcf64c  vmovaps [rsp+0x120], xmm7
000075aec0bcf655  vmovaps xmm14, [rsp+0x120]
000075aec0bcf65e  por xmm7, xmm14
000075aec0bcf663  vmovaps xmm14, [rsp+0xC0]
000075aec0bcf66c  vmovaps xmm10, [rsp+0xC0]
000075aec0bcf675  por xmm14, xmm10
000075aec0bcf67a  vmovaps xmm2, [rsp+0x100]
000075aec0bcf683  vpermilpd xmm2, xmm2, 0x00
000075aec0bcf689  vmovaps [rsp+0xC0], xmm1
000075aec0bcf692  vmovaps [rsp+0x120], xmm15
000075aec0bcf69b  movaps xmm1, xmm10
000075aec0bcf69f  mulpd xmm1, xmm2
000075aec0bcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000075aec0bcf6a8  ptest xmm15, xmm15
000075aec0bcf6ae  jnz 0x000075AEC0BD0CCF
000075aec0bcf6b4  xor eax, eax
000075aec0bcf6b6  mov r12d, 0x40
000075aec0bcf6bc  mov r11d, 0x200
000075aec0bcf6c2  cmp r12, r11
000075aec0bcf6c5  cmc
000075aec0bcf6c6  lahf
000075aec0bcf6c7  seto al
000075aec0bcf6ca  mov [r15+0x108], eax
000075aec0bcf6d1  vmovaps xmm10, [rsp+0x110]
000075aec0bcf6da  vmovaps xmm2, [rsp+0xE0]
000075aec0bcf6e3  vmovaps [rsp+0xE0], xmm1
000075aec0bcf6ec  movaps xmm15, xmm10
000075aec0bcf6f0  addpd xmm15, xmm2
000075aec0bcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bcf6fb  ptest xmm1, xmm1
000075aec0bcf700  jnz 0x000075AEC0BD0E10
000075aec0bcf706  vmovaps xmm10, [rsp+0x120]
000075aec0bcf70f  vmovaps [rsp+0x110], xmm15
000075aec0bcf718  movaps xmm1, xmm10
000075aec0bcf71c  addpd xmm1, xmm12
000075aec0bcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000075aec0bcf726  ptest xmm15, xmm15
000075aec0bcf72c  jnz 0x000075AEC0BD0F53
000075aec0bcf732  vmovaps xmm10, [rsp+0xC0]
000075aec0bcf73b  vmovaps [rsp+0xC0], xmm1
000075aec0bcf744  movaps xmm15, xmm10
000075aec0bcf748  addpd xmm15, xmm12
000075aec0bcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bcf753  ptest xmm1, xmm1
000075aec0bcf758  jnz 0x000075AEC0BD1095
000075aec0bcf75e  vmovaps xmm1, [rsp+0x30]
000075aec0bcf764  vmovaps xmm12, [rsp+0x30]
000075aec0bcf76a  por xmm1, xmm12
000075aec0bcf76f  vmovaps xmm12, [rsp+0x20]
000075aec0bcf775  vmovaps xmm10, [rsp+0x20]
000075aec0bcf77b  por xmm12, xmm10
000075aec0bcf780  vmovaps [rsp+0x20], xmm5
000075aec0bcf786  vmovaps xmm10, [rsp+0x20]
000075aec0bcf78c  por xmm5, xmm10
000075aec0bcf791  vmovaps [rsp+0x20], xmm11
000075aec0bcf797  vmovaps xmm10, [rsp+0x20]
000075aec0bcf79d  por xmm11, xmm10
000075aec0bcf7a2  vmovaps [rsp+0x20], xmm4
000075aec0bcf7a8  vmovaps xmm10, [rsp+0x20]
000075aec0bcf7ae  por xmm4, xmm10
000075aec0bcf7b3  vmovaps [rsp+0x20], xmm8
000075aec0bcf7b9  vmovaps xmm10, [rsp+0x20]
000075aec0bcf7bf  por xmm8, xmm10
000075aec0bcf7c4  vmovaps xmm10, [rsp+0xF0]
000075aec0bcf7cd  vmovaps [rsp+0x20], xmm1
000075aec0bcf7d3  vmovaps xmm1, [rsp+0xF0]
000075aec0bcf7dc  por xmm10, xmm1
000075aec0bcf7e1  lea rax, [r14+0xA0]
000075aec0bcf7e8  movups xmm1, [r13+rax*1]
000075aec0bcf7ee  lea rax, [r14+0xB0]
000075aec0bcf7f5  vmovaps [rsp+0x30], xmm1
000075aec0bcf7fb  movups xmm1, [r13+rax*1]
000075aec0bcf801  vmovaps [rsp+0xF0], xmm1
000075aec0bcf80a  vmovaps [rsp+0x120], xmm15
000075aec0bcf813  movaps xmm1, xmm13
000075aec0bcf817  addpd xmm1, xmm2
000075aec0bcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000075aec0bcf820  ptest xmm15, xmm15
000075aec0bcf826  jnz 0x000075AEC0BD11ED
000075aec0bcf82c  lea rax, [r14+0xF0]
000075aec0bcf833  movups xmm15, [r13+rax*1]
000075aec0bcf839  vmovaps xmm2, [rsp+0xC0]
000075aec0bcf842  vmovaps [rsp+0xC0], xmm1
000075aec0bcf84b  vmovaps xmm1, [rsp+0xE0]
000075aec0bcf854  vmovaps [rsp+0xE0], xmm15
000075aec0bcf85d  movaps xmm13, xmm2
000075aec0bcf861  addpd xmm13, xmm1
000075aec0bcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000075aec0bcf86c  ptest xmm15, xmm15
000075aec0bcf872  jnz 0x000075AEC0BD1338
000075aec0bcf878  vmovaps xmm15, [rsp+0x120]
000075aec0bcf881  vmovaps xmm2, [rsp+0xD0]
000075aec0bcf88a  vmovaps [rsp+0xD0], xmm14
000075aec0bcf893  movaps xmm1, xmm15
000075aec0bcf897  addpd xmm1, xmm2
000075aec0bcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000075aec0bcf8a0  ptest xmm14, xmm14
000075aec0bcf8a6  jnz 0x000075AEC0BD147A
000075aec0bcf8ac  vmovaps xmm15, [rsp+0x100]
000075aec0bcf8b5  vpermilpd xmm15, xmm15, 0x00
000075aec0bcf8bb  vmovaps xmm2, [rsp+0xF0]
000075aec0bcf8c4  vmovaps [rsp+0xF0], xmm1
000075aec0bcf8cd  movaps xmm14, xmm2
000075aec0bcf8d1  mulpd xmm14, xmm15
000075aec0bcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000075aec0bcf8dc  ptest xmm1, xmm1
000075aec0bcf8e1  jnz 0x000075AEC0BD15BB
000075aec0bcf8e7  vmovaps xmm1, [rsp+0xA0]
000075aec0bcf8f0  vpermilpd xmm1, xmm1, 0x00
000075aec0bcf8f6  vmovaps xmm2, [rsp+0xE0]
000075aec0bcf8ff  vmovaps [rsp+0xE0], xmm14
000075aec0bcf908  movaps xmm15, xmm2
000075aec0bcf90c  mulpd xmm15, xmm1
000075aec0bcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000075aec0bcf917  ptest xmm14, xmm14
000075aec0bcf91d  jnz 0x000075AEC0BD16FE
000075aec0bcf923  lea rax, [r14+0xE0]
000075aec0bcf92a  movups xmm1, [r13+rax*1]
000075aec0bcf930  vmovaps xmm14, [rsp+0x100]
000075aec0bcf939  vpermilpd xmm14, xmm14, 0x00
000075aec0bcf93f  vmovaps [rsp+0x100], xmm1
000075aec0bcf948  vmovaps xmm1, [rsp+0x30]
000075aec0bcf94e  vmovaps [rsp+0x30], xmm15
000075aec0bcf954  movaps xmm2, xmm1
000075aec0bcf957  mulpd xmm2, xmm14
000075aec0bcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000075aec0bcf961  ptest xmm15, xmm15
000075aec0bcf967  jnz 0x000075AEC0BD184A
000075aec0bcf96d  vmovaps [rsp+0x120], xmm10
000075aec0bcf976  vmovaps xmm1, [rsp+0x120]
000075aec0bcf97f  por xmm10, xmm1
000075aec0bcf984  movaps [r15+0x300], xmm10
000075aec0bcf98c  vmovaps [rsp+0x120], xmm8
000075aec0bcf995  vmovaps xmm1, [rsp+0x120]
000075aec0bcf99e  por xmm8, xmm1
000075aec0bcf9a3  movaps [r15+0x190], xmm8
000075aec0bcf9ab  vmovaps xmm1, [rsp+0xA0]
000075aec0bcf9b4  vpermilpd xmm1, xmm1, 0x00
000075aec0bcf9ba  vmovaps xmm14, [rsp+0x100]
000075aec0bcf9c3  vmovaps [rsp+0x100], xmm13
000075aec0bcf9cc  movaps xmm15, xmm14
000075aec0bcf9d0  mulpd xmm15, xmm1
000075aec0bcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000075aec0bcf9db  ptest xmm13, xmm13
000075aec0bcf9e1  jnz 0x000075AEC0BD198B
000075aec0bcf9e7  lea rax, [r14+0x90]
000075aec0bcf9ee  movups xmm1, [r13+rax*1]
000075aec0bcf9f4  vmovaps [rsp+0x120], xmm4
000075aec0bcf9fd  vmovaps xmm14, [rsp+0x120]
000075aec0bcfa06  por xmm4, xmm14
000075aec0bcfa0b  movaps [r15+0x1C0], xmm4
000075aec0bcfa13  vmovaps [rsp+0x120], xmm11
000075aec0bcfa1c  vmovaps xmm14, [rsp+0x120]
000075aec0bcfa25  por xmm11, xmm14
000075aec0bcfa2a  movaps [r15+0x200], xmm11
000075aec0bcfa32  vmovaps [rsp+0x120], xmm5
000075aec0bcfa3b  vmovaps xmm14, [rsp+0x120]
000075aec0bcfa44  por xmm5, xmm14
000075aec0bcfa49  movaps [r15+0x2D0], xmm5
000075aec0bcfa51  vmovaps [rsp+0x120], xmm12
000075aec0bcfa5a  vmovaps xmm14, [rsp+0x120]
000075aec0bcfa63  por xmm12, xmm14
000075aec0bcfa68  movaps [r15+0x2E0], xmm12
000075aec0bcfa70  vmovaps xmm13, [rsp+0x110]
000075aec0bcfa79  vmovaps [rsp+0x110], xmm1
000075aec0bcfa82  vmovaps xmm1, [rsp+0xE0]
000075aec0bcfa8b  vmovaps [rsp+0xE0], xmm15
000075aec0bcfa94  movaps xmm14, xmm13
000075aec0bcfa98  addpd xmm14, xmm1
000075aec0bcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000075aec0bcfaa3  ptest xmm15, xmm15
000075aec0bcfaa9  jnz 0x000075AEC0BD1AD8
000075aec0bcfaaf  vmovaps xmm1, [rsp+0xA0]
000075aec0bcfab8  vpermilpd xmm1, xmm1, 0x00
000075aec0bcfabe  vmovaps xmm13, [rsp+0x110]
000075aec0bcfac7  vmovaps [rsp+0x110], xmm14
000075aec0bcfad0  movaps xmm15, xmm13
000075aec0bcfad4  mulpd xmm15, xmm1
000075aec0bcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000075aec0bcfadf  ptest xmm14, xmm14
000075aec0bcfae5  jnz 0x000075AEC0BD1C1B
000075aec0bcfaeb  lea rax, [r14+0x80]
000075aec0bcfaf2  movups xmm1, [r13+rax*1]
000075aec0bcfaf8  vmovaps xmm13, [rsp+0xC0]
000075aec0bcfb01  vmovaps [rsp+0xC0], xmm1
000075aec0bcfb0a  movaps xmm14, xmm13
000075aec0bcfb0e  addpd xmm14, xmm2
000075aec0bcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000075aec0bcfb19  ptest xmm1, xmm1
000075aec0bcfb1e  jnz 0x000075AEC0BD1D68
000075aec0bcfb24  vmovaps xmm13, [rsp+0x100]
000075aec0bcfb2d  vmovaps xmm2, [rsp+0x30]
000075aec0bcfb33  vmovaps [rsp+0x30], xmm15
000075aec0bcfb39  movaps xmm1, xmm13
000075aec0bcfb3d  addpd xmm1, xmm2
000075aec0bcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000075aec0bcfb46  ptest xmm15, xmm15
000075aec0bcfb4c  jnz 0x000075AEC0BD1EAB
000075aec0bcfb52  vmovaps xmm15, [rsp+0x20]
000075aec0bcfb58  vmovaps xmm13, [rsp+0x20]
000075aec0bcfb5e  por xmm15, xmm13
000075aec0bcfb63  movaps [r15+0x2F0], xmm15
000075aec0bcfb6b  vmovaps xmm13, [rsp+0xA0]
000075aec0bcfb74  vpermilpd xmm13, xmm13, 0x00
000075aec0bcfb7a  vmovaps [rsp+0x20], xmm1
000075aec0bcfb80  vmovaps xmm1, [rsp+0xC0]
000075aec0bcfb89  vmovaps [rsp+0xA0], xmm15
000075aec0bcfb92  movaps xmm2, xmm1
000075aec0bcfb95  mulpd xmm2, xmm13
000075aec0bcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000075aec0bcfb9f  ptest xmm15, xmm15
000075aec0bcfba5  jnz 0x000075AEC0BD1FEC
000075aec0bcfbab  lea rax, [r14+0xD0]
000075aec0bcfbb2  movups xmm1, [r13+rax*1]
000075aec0bcfbb8  vmovaps xmm13, [rsp+0xF0]
000075aec0bcfbc1  vmovaps [rsp+0xC0], xmm1
000075aec0bcfbca  vmovaps xmm1, [rsp+0xE0]
000075aec0bcfbd3  vmovaps [rsp+0xE0], xmm14
000075aec0bcfbdc  movaps xmm15, xmm13
000075aec0bcfbe0  addpd xmm15, xmm1
000075aec0bcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000075aec0bcfbeb  ptest xmm14, xmm14
000075aec0bcfbf1  jnz 0x000075AEC0BD2137
000075aec0bcfbf7  vmovaps xmm1, [rsp+0xB0]
000075aec0bcfc00  vpermilpd xmm1, xmm1, 0x00
000075aec0bcfc06  movaps xmm14, xmm11
000075aec0bcfc0a  mulpd xmm14, xmm1
000075aec0bcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000075aec0bcfc15  ptest xmm13, xmm13
000075aec0bcfc1b  jnz 0x000075AEC0BD227A
000075aec0bcfc21  movaps [r15+0x260], xmm14
000075aec0bcfc29  vxorps xmm1, xmm1, xmm1
000075aec0bcfc2d  vpbroadcastq xmm1, xmm1
000075aec0bcfc32  movaps [r15+0x1B0], xmm1
000075aec0bcfc3a  vmovaps xmm1, [rsp+0xB0]
000075aec0bcfc43  vpermilpd xmm1, xmm1, 0x00
000075aec0bcfc49  vmovaps xmm11, [rsp+0xC0]
000075aec0bcfc52  vmovaps [rsp+0xC0], xmm15
000075aec0bcfc5b  movaps xmm13, xmm11
000075aec0bcfc5f  mulpd xmm13, xmm1
000075aec0bcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000075aec0bcfc6a  ptest xmm15, xmm15
000075aec0bcfc70  jnz 0x000075AEC0BD23BD
000075aec0bcfc76  lea rax, [r14+0xC0]
000075aec0bcfc7d  movups xmm1, [r13+rax*1]
000075aec0bcfc83  vmovaps xmm11, [rsp+0x110]
000075aec0bcfc8c  vmovaps [rsp+0xF0], xmm1
000075aec0bcfc95  vmovaps xmm1, [rsp+0x30]
000075aec0bcfc9b  vmovaps [rsp+0x30], xmm14
000075aec0bcfca1  movaps xmm15, xmm11
000075aec0bcfca5  addpd xmm15, xmm1
000075aec0bcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000075aec0bcfcb0  ptest xmm14, xmm14
000075aec0bcfcb6  jnz 0x000075AEC0BD250A
000075aec0bcfcbc  vmovaps [rsp+0x100], xmm9
000075aec0bcfcc5  vmovaps xmm1, [rsp+0x100]
000075aec0bcfcce  por xmm9, xmm1
000075aec0bcfcd3  movaps [r15+0x270], xmm9
000075aec0bcfcdb  vmovaps [rsp+0x100], xmm6
000075aec0bcfce4  vmovaps xmm1, [rsp+0x100]
000075aec0bcfced  por xmm6, xmm1
000075aec0bcfcf1  movaps [r15+0x1A0], xmm6
000075aec0bcfcf9  vmovaps xmm14, [rsp+0xB0]
000075aec0bcfd02  vpermilpd xmm14, xmm14, 0x00
000075aec0bcfd08  vmovaps xmm6, [rsp+0xF0]
000075aec0bcfd11  vmovaps [rsp+0xF0], xmm1
000075aec0bcfd1a  movaps xmm11, xmm6
000075aec0bcfd1e  mulpd xmm11, xmm14
000075aec0bcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000075aec0bcfd29  ptest xmm1, xmm1
000075aec0bcfd2e  jnz 0x000075AEC0BD264D
000075aec0bcfd34  lea rax, [r14+0x20]
000075aec0bcfd38  movups xmm1, [r13+rax*1]
000075aec0bcfd3e  movaps [r15+0x110], xmm1
000075aec0bcfd46  vmovaps xmm6, [rsp+0xE0]
000075aec0bcfd4f  vmovaps [rsp+0xE0], xmm1
000075aec0bcfd58  movaps xmm14, xmm6
000075aec0bcfd5c  addpd xmm14, xmm2
000075aec0bcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000075aec0bcfd67  ptest xmm1, xmm1
000075aec0bcfd6c  jnz 0x000075AEC0BD279A
000075aec0bcfd72  vmovaps xmm1, [rsp+0xB0]
000075aec0bcfd7b  vpermilpd xmm1, xmm1, 0x00
000075aec0bcfd81  movaps xmm6, xmm5
000075aec0bcfd84  mulpd xmm6, xmm1
000075aec0bcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000075aec0bcfd8d  ptest xmm2, xmm2
000075aec0bcfd92  jnz 0x000075AEC0BD28DC
000075aec0bcfd98  vmovaps xmm5, [rsp+0x20]
000075aec0bcfd9e  movaps xmm1, xmm5
000075aec0bcfda1  addpd xmm1, xmm13
000075aec0bcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000075aec0bcfdab  ptest xmm2, xmm2
000075aec0bcfdb0  jnz 0x000075AEC0BD2A1C
000075aec0bcfdb6  vmovaps xmm13, [rsp+0x80]
000075aec0bcfdbf  vpermilpd xmm13, xmm13, 0x00
000075aec0bcfdc5  vmovaps xmm2, [rsp+0xE0]
000075aec0bcfdce  vmovaps [rsp+0x20], xmm1
000075aec0bcfdd4  movaps xmm5, xmm2
000075aec0bcfdd7  mulpd xmm5, xmm13
000075aec0bcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000075aec0bcfde1  ptest xmm1, xmm1
000075aec0bcfde6  jnz 0x000075AEC0BD2B5D
000075aec0bcfdec  vmovaps xmm1, [rsp+0x80]
000075aec0bcfdf5  vpermilpd xmm1, xmm1, 0x00
000075aec0bcfdfb  movaps xmm13, xmm10
000075aec0bcfdff  mulpd xmm13, xmm1
000075aec0bcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000075aec0bcfe0a  ptest xmm2, xmm2
000075aec0bcfe0f  jnz 0x000075AEC0BD2C9E
000075aec0bcfe15  vmovaps xmm10, [rsp+0x30]
000075aec0bcfe1b  movaps xmm1, xmm15
000075aec0bcfe1f  addpd xmm1, xmm10
000075aec0bcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000075aec0bcfe29  ptest xmm2, xmm2
000075aec0bcfe2e  jnz 0x000075AEC0BD2DE1
000075aec0bcfe34  vmovaps xmm10, [rsp+0xC0]
000075aec0bcfe3d  movaps xmm15, xmm10
000075aec0bcfe41  addpd xmm15, xmm11
000075aec0bcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000075aec0bcfe4c  ptest xmm2, xmm2
000075aec0bcfe51  jnz 0x000075AEC0BD2F23
000075aec0bcfe57  vmovaps xmm11, [rsp+0x80]
000075aec0bcfe60  vpermilpd xmm11, xmm11, 0x00
000075aec0bcfe66  movaps xmm10, xmm12
000075aec0bcfe6a  mulpd xmm10, xmm11
000075aec0bcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000075aec0bcfe75  ptest xmm2, xmm2
000075aec0bcfe7a  jnz 0x000075AEC0BD3067
000075aec0bcfe80  vmovaps xmm12, [rsp+0x80]
000075aec0bcfe89  vpermilpd xmm12, xmm12, 0x00
000075aec0bcfe8f  vmovaps xmm2, [rsp+0xA0]
000075aec0bcfe98  vmovaps [rsp+0x30], xmm1
000075aec0bcfe9e  movaps xmm11, xmm2
000075aec0bcfea2  mulpd xmm11, xmm12
000075aec0bcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000075aec0bcfead  ptest xmm1, xmm1
000075aec0bcfeb2  jnz 0x000075AEC0BD31AB
000075aec0bcfeb8  movaps xmm1, xmm14
000075aec0bcfebc  addpd xmm1, xmm6
000075aec0bcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000075aec0bcfec5  ptest xmm12, xmm12
000075aec0bcfecb  jnz 0x000075AEC0BD32EE
000075aec0bcfed1  vmovaps xmm12, [rsp+0x20]
000075aec0bcfed7  movaps xmm14, xmm12
000075aec0bcfedb  addpd xmm14, xmm5
000075aec0bcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000075aec0bcfee6  ptest xmm6, xmm6
000075aec0bcfeeb  jnz 0x000075AEC0BD342F
000075aec0bcfef1  vmovaps xmm12, [rsp+0x90]
000075aec0bcfefa  vpermilpd xmm12, xmm12, 0x00
000075aec0bcff00  movaps xmm6, xmm9
000075aec0bcff04  mulpd xmm6, xmm12
000075aec0bcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000075aec0bcff0e  ptest xmm5, xmm5
000075aec0bcff13  jnz 0x000075AEC0BD3572
000075aec0bcff19  movaps xmm12, xmm15
000075aec0bcff1d  addpd xmm12, xmm13
000075aec0bcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000075aec0bcff28  ptest xmm9, xmm9
000075aec0bcff2e  jnz 0x000075AEC0BD36B4
000075aec0bcff34  vmovaps xmm13, [rsp+0x30]
000075aec0bcff3a  movaps xmm15, xmm13
000075aec0bcff3e  addpd xmm15, xmm10
000075aec0bcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000075aec0bcff49  ptest xmm9, xmm9
000075aec0bcff4f  jnz 0x000075AEC0BD37F8
000075aec0bcff55  vmovaps xmm13, [rsp+0xD0]
000075aec0bcff5e  vmovaps xmm10, [rsp+0xD0]
000075aec0bcff67  por xmm13, xmm10
000075aec0bcff6c  movaps [r15+0x250], xmm13
000075aec0bcff74  vmovaps [rsp+0x20], xmm7
000075aec0bcff7a  vmovaps xmm13, [rsp+0x20]
000075aec0bcff80  por xmm7, xmm13
000075aec0bcff85  movaps [r15+0x2A0], xmm7
000075aec0bcff8d  vmovaps [rsp+0x20], xmm3
000075aec0bcff93  vmovaps xmm13, [rsp+0x20]
000075aec0bcff99  por xmm3, xmm13
000075aec0bcff9e  movaps [r15+0x1D0], xmm3
000075aec0bcffa6  lea rax, [r14+0x40]
000075aec0bcffaa  movups xmm13, [r13+rax*1]
000075aec0bcffb0  movaps [r15+0x2C0], xmm13
000075aec0bcffb8  vmovaps xmm10, [rsp+0x90]
000075aec0bcffc1  vpermilpd xmm10, xmm10, 0x00
000075aec0bcffc7  movaps xmm9, xmm8
000075aec0bcffcb  mulpd xmm9, xmm10
000075aec0bcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000075aec0bcffd6  ptest xmm5, xmm5
000075aec0bcffdb  jnz 0x000075AEC0BD3946
000075aec0bcffe1  movaps xmm10, xmm1
000075aec0bcffe5  addpd xmm10, xmm11
000075aec0bcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000075aec0bcfff0  ptest xmm8, xmm8
000075aec0bcfff6  jnz 0x000075AEC0BD3A8A
000075aec0bcfffc  movaps xmm1, xmm14
000075aec0bd0000  addpd xmm1, xmm6
000075aec0bd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000075aec0bd0009  ptest xmm11, xmm11
000075aec0bd000f  jnz 0x000075AEC0BD3BCD
000075aec0bd0015  vmovaps xmm14, [rsp+0x90]
000075aec0bd001e  vpermilpd xmm14, xmm14, 0x00
000075aec0bd0024  movaps xmm11, xmm13
000075aec0bd0028  mulpd xmm11, xmm14
000075aec0bd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000075aec0bd0033  ptest xmm8, xmm8
000075aec0bd0039  jnz 0x000075AEC0BD3D0E
000075aec0bd003f  vmovaps xmm14, [rsp+0x90]
000075aec0bd0048  vpermilpd xmm14, xmm14, 0x00
000075aec0bd004e  vmovaps xmm8, [rsp+0x10]
000075aec0bd0054  movaps xmm13, xmm8
000075aec0bd0058  mulpd xmm13, xmm14
000075aec0bd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000075aec0bd0063  ptest xmm6, xmm6
000075aec0bd0068  jnz 0x000075AEC0BD3E52
000075aec0bd006e  vmovaps xmm14, [rsp+0x60]
000075aec0bd0074  vpermilpd xmm14, xmm14, 0x00
000075aec0bd007a  movaps xmm8, xmm7
000075aec0bd007e  mulpd xmm8, xmm14
000075aec0bd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000075aec0bd0089  ptest xmm6, xmm6
000075aec0bd008e  jnz 0x000075AEC0BD3F96
000075aec0bd0094  movaps xmm14, xmm12
000075aec0bd0098  addpd xmm14, xmm9
000075aec0bd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000075aec0bd00a3  ptest xmm7, xmm7
000075aec0bd00a8  jnz 0x000075AEC0BD40D9
000075aec0bd00ae  vmovaps xmm12, [rsp+0x60]
000075aec0bd00b4  vpermilpd xmm12, xmm12, 0x00
000075aec0bd00ba  vmovaps xmm7, [rsp+0xF0]
000075aec0bd00c3  movaps xmm9, xmm7
000075aec0bd00c7  mulpd xmm9, xmm12
000075aec0bd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000075aec0bd00d2  ptest xmm6, xmm6
000075aec0bd00d7  jnz 0x000075AEC0BD421D
000075aec0bd00dd  movaps xmm12, xmm15
000075aec0bd00e1  addpd xmm12, xmm11
000075aec0bd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000075aec0bd00ec  ptest xmm7, xmm7
000075aec0bd00f1  jnz 0x000075AEC0BD4360
000075aec0bd00f7  vmovaps xmm15, [rsp+0x60]
000075aec0bd00fd  vpermilpd xmm15, xmm15, 0x00
000075aec0bd0103  vmovaps xmm7, [rsp+0x40]
000075aec0bd0109  movaps xmm11, xmm7
000075aec0bd010d  mulpd xmm11, xmm15
000075aec0bd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000075aec0bd0118  ptest xmm6, xmm6
000075aec0bd011d  jnz 0x000075AEC0BD44A4
000075aec0bd0123  movaps xmm15, xmm10
000075aec0bd0127  addpd xmm15, xmm13
000075aec0bd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000075aec0bd0132  ptest xmm7, xmm7
000075aec0bd0137  jnz 0x000075AEC0BD45E7
000075aec0bd013d  vmovaps xmm13, [rsp+0x60]
000075aec0bd0143  vpermilpd xmm13, xmm13, 0x00
000075aec0bd0149  vmovaps xmm7, [rsp+0x50]
000075aec0bd014f  movaps xmm10, xmm7
000075aec0bd0153  mulpd xmm10, xmm13
000075aec0bd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000075aec0bd015e  ptest xmm6, xmm6
000075aec0bd0163  jnz 0x000075AEC0BD472B
000075aec0bd0169  movaps xmm13, xmm1
000075aec0bd016d  addpd xmm13, xmm8
000075aec0bd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000075aec0bd0178  ptest xmm7, xmm7
000075aec0bd017d  jnz 0x000075AEC0BD486E
000075aec0bd0183  lea rax, [r14+0x70]
000075aec0bd0187  movups xmm1, [r13+rax*1]
000075aec0bd018d  movaps [r15+0x240], xmm1
000075aec0bd0195  movaps xmm8, xmm14
000075aec0bd0199  addpd xmm8, xmm9
000075aec0bd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000075aec0bd01a4  ptest xmm7, xmm7
000075aec0bd01a9  jnz 0x000075AEC0BD49BB
000075aec0bd01af  movaps [r15+0x170], xmm8
000075aec0bd01b7  vmovaps xmm14, [rsp+0x70]
000075aec0bd01bd  vpermilpd xmm14, xmm14, 0x00
000075aec0bd01c3  movaps xmm9, xmm1
000075aec0bd01c7  mulpd xmm9, xmm14
000075aec0bd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000075aec0bd01d2  ptest xmm7, xmm7
000075aec0bd01d7  jnz 0x000075AEC0BD4AFF
000075aec0bd01dd  vmovaps xmm1, [rsp+0x70]
000075aec0bd01e3  vpermilpd xmm1, xmm1, 0x00
000075aec0bd01e9  movaps xmm14, xmm4
000075aec0bd01ed  mulpd xmm14, xmm1
000075aec0bd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000075aec0bd01f8  ptest xmm7, xmm7
000075aec0bd01fd  jnz 0x000075AEC0BD4C42
000075aec0bd0203  movaps [r15+0x180], xmm14
000075aec0bd020b  movaps xmm1, xmm12
000075aec0bd020f  addpd xmm1, xmm11
000075aec0bd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000075aec0bd0219  ptest xmm7, xmm7
000075aec0bd021e  jnz 0x000075AEC0BD4D84
000075aec0bd0224  movaps [r15+0x210], xmm1
000075aec0bd022c  movups xmm12, [r13+r14*1]
000075aec0bd0232  lea rax, [r14+0x10]
000075aec0bd0236  movups xmm11, [r13+rax*1]
000075aec0bd023c  movaps [r15+0x230], xmm11
000075aec0bd0244  movaps xmm7, xmm15
000075aec0bd0248  addpd xmm7, xmm10
000075aec0bd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000075aec0bd0252  ptest xmm6, xmm6
000075aec0bd0257  jnz 0x000075AEC0BD4EDA
000075aec0bd025d  movaps [r15+0x130], xmm7
000075aec0bd0265  vmovaps xmm15, [rsp+0x70]
000075aec0bd026b  vpermilpd xmm15, xmm15, 0x00
000075aec0bd0271  movaps xmm10, xmm11
000075aec0bd0275  mulpd xmm10, xmm15
000075aec0bd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000075aec0bd0280  ptest xmm6, xmm6
000075aec0bd0285  jnz 0x000075AEC0BD501C
000075aec0bd028b  movaps [r15+0x220], xmm10
000075aec0bd0293  vmovaps xmm15, [rsp+0x70]
000075aec0bd0299  vpermilpd xmm15, xmm15, 0x00
000075aec0bd029f  movaps xmm11, xmm12
000075aec0bd02a3  mulpd xmm11, xmm15
000075aec0bd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000075aec0bd02ae  ptest xmm6, xmm6
000075aec0bd02b3  jnz 0x000075AEC0BD5160
000075aec0bd02b9  movaps xmm15, xmm13
000075aec0bd02bd  addpd xmm15, xmm9
000075aec0bd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000075aec0bd02c8  ptest xmm12, xmm12
000075aec0bd02ce  jnz 0x000075AEC0BD52A4
000075aec0bd02d4  movaps [r15+0x140], xmm15
000075aec0bd02dc  movaps xmm13, xmm8
000075aec0bd02e0  addpd xmm13, xmm14
000075aec0bd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000075aec0bd02eb  ptest xmm12, xmm12
000075aec0bd02f1  jnz 0x000075AEC0BD53E8
000075aec0bd02f7  movaps [r15+0x150], xmm13
000075aec0bd02ff  movaps xmm14, xmm1
000075aec0bd0303  addpd xmm14, xmm10
000075aec0bd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000075aec0bd030e  ptest xmm12, xmm12
000075aec0bd0314  jnz 0x000075AEC0BD552C
000075aec0bd031a  movaps [r15+0x160], xmm14
000075aec0bd0322  movaps xmm1, xmm7
000075aec0bd0325  addpd xmm1, xmm11
000075aec0bd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000075aec0bd032f  ptest xmm12, xmm12
000075aec0bd0335  jnz 0x000075AEC0BD566F
000075aec0bd033b  movaps [r15+0x120], xmm1
000075aec0bd0343  mov eax, 0x430920
000075aec0bd0348  movups [r13+rax*1], xmm15
000075aec0bd034e  mov eax, 0x430930
000075aec0bd0353  movups [r13+rax*1], xmm13
000075aec0bd0359  mov eax, 0x430940
000075aec0bd035e  movups [r13+rax*1], xmm14
000075aec0bd0364  mov eax, 0x430950
000075aec0bd0369  movups [r13+rax*1], xmm1
000075aec0bd036f  mov eax, [r15+0x108]
000075aec0bd0376  sahf
000075aec0bd0377  jnz 0x000075AEC0BD03A9
000075aec0bd0379  cmp dword ptr [r15+0x318], 0x00
000075aec0bd0381  jz 0x000075AEC0BDB900
000075aec0bd0387  nop [rax+rax*1], ax
000075aec0bd0390  nop [rax+rax*1], eax
000075aec0bd0398  mov eax, 0x410444
000075aec0bd039d  mov [r15+0x100], rax
000075aec0bd03a4  jmp 0x000075AEC09FE110
000075aec0bd03a9  cmp dword ptr [r15+0x318], 0x00
000075aec0bd03b1  jz 0x000075AEC0BD57E0
000075aec0bd03b7  nop [rax+rax*1], ax
000075aec0bd03c0  nop [rax+rax*1], eax
000075aec0bd03c8  mov eax, 0x410278
000075aec0bd03cd  mov [r15+0x100], rax
000075aec0bd03d4  jmp 0x000075AEC09FE110
000075aec0bd03d9  int3
000075aec0bd03da  call 0x000075AEC0AB52F0
000075aec0bd03df  jmp 0x000075AEC0BCF016
000075aec0bd03e4  call 0x000075AEC0AC4620
000075aec0bd03e9  jmp 0x000075AEC0BCF023
000075aec0bd03ee  call 0x000075AEC0AC33A0
000075aec0bd03f3  jmp 0x000075AEC0BCF035
000075aec0bd03f8  call 0x000075AEC0AC2120
000075aec0bd03fd  jmp 0x000075AEC0BCF03F
000075aec0bd0402  call 0x000075AEC0AC0860
000075aec0bd0407  jmp 0x000075AEC0BCF067
000075aec0bd040c  call 0x000075AEC0ABF5F0
000075aec0bd0411  jmp 0x000075AEC0BCF073
000075aec0bd0416  call 0x000075AEC0AC0860
000075aec0bd041b  jmp 0x000075AEC0BCF0A5
000075aec0bd0420  call 0x000075AEC0ABF5F0
000075aec0bd0425  jmp 0x000075AEC0BCF0B1
000075aec0bd042a  call 0x000075AEC0AC4740
000075aec0bd042f  jmp 0x000075AEC0BCF0BE
000075aec0bd0434  call 0x000075AEC0AB5400
000075aec0bd0439  jmp 0x000075AEC0BCF0CB
000075aec0bd043e  call 0x000075AEC0AB52F0
000075aec0bd0443  jmp 0x000075AEC0BCF0D8
000075aec0bd0448  call 0x000075AEC0AC4620
000075aec0bd044d  jmp 0x000075AEC0BCF0E5
000075aec0bd0452  call 0x000075AEC0AC0860
000075aec0bd0457  jmp 0x000075AEC0BCF10D
000075aec0bd045c  call 0x000075AEC0ABF5F0
000075aec0bd0461  jmp 0x000075AEC0BCF119
000075aec0bd0466  call 0x000075AEC0A09D70
000075aec0bd046b  jmp 0x000075AEC0BCF11F
000075aec0bd0470  call 0x000075AEC0ABE9C0
000075aec0bd0475  jmp 0x000075AEC0BCF129
000075aec0bd047a  call 0x000075AEC0AC0860
000075aec0bd047f  jmp 0x000075AEC0BCF151
000075aec0bd0484  call 0x000075AEC0ABF5F0
000075aec0bd0489  jmp 0x000075AEC0BCF15D
000075aec0bd048e  call 0x000075AEC0ABD750
000075aec0bd0493  jmp 0x000075AEC0BCF16A
000075aec0bd0498  call 0x000075AEC0ABC4E0
000075aec0bd049d  jmp 0x000075AEC0BCF177
000075aec0bd04a2  call 0x000075AEC0AC4740
000075aec0bd04a7  jmp 0x000075AEC0BCF184
000075aec0bd04ac  call 0x000075AEC0AB5400
000075aec0bd04b1  jmp 0x000075AEC0BCF191
000075aec0bd04b6  call 0x000075AEC0AB52F0
000075aec0bd04bb  jmp 0x000075AEC0BCF19E
000075aec0bd04c0  call 0x000075AEC0AC4620
000075aec0bd04c5  jmp 0x000075AEC0BCF1AB
000075aec0bd04ca  call 0x000075AEC0AC0860
000075aec0bd04cf  jmp 0x000075AEC0BCF1BE
000075aec0bd04d4  call 0x000075AEC0ABB270
000075aec0bd04d9  jmp 0x000075AEC0BCF1CB
000075aec0bd04de  call 0x000075AEC0ABA000
000075aec0bd04e3  jmp 0x000075AEC0BCF1D8
000075aec0bd04e8  call 0x000075AEC0AB8D90
000075aec0bd04ed  jmp 0x000075AEC0BCF1E5
000075aec0bd04f2  call 0x000075AEC0AB8A20
000075aec0bd04f7  jmp 0x000075AEC0BCF1F2
000075aec0bd04fc  call 0x000075AEC0AB5400
000075aec0bd0501  jmp 0x000075AEC0BCF1FC
000075aec0bd0506  call 0x000075AEC0AC2240
000075aec0bd050b  jmp 0x000075AEC0BCF206
000075aec0bd0510  call 0x000075AEC0AB52F0
000075aec0bd0515  jmp 0x000075AEC0BCF210
000075aec0bd051a  call 0x000075AEC0AC2120
000075aec0bd051f  jmp 0x000075AEC0BCF21A
000075aec0bd0524  call 0x000075AEC0AB77B0
000075aec0bd0529  jmp 0x000075AEC0BCF224
000075aec0bd052e  call 0x000075AEC0AB6550
000075aec0bd0533  jmp 0x000075AEC0BCF22E
000075aec0bd0538  call 0x000075AEC0ABFD50
000075aec0bd053d  jmp 0x000075AEC0BCF240
000075aec0bd0542  call 0x000075AEC0AB8EA0
000075aec0bd0547  jmp 0x000075AEC0BCF24A
000075aec0bd054c  call 0x000075AEC0ABFC30
000075aec0bd0551  jmp 0x000075AEC0BCF257
000075aec0bd0556  call 0x000075AEC0AB8D90
000075aec0bd055b  jmp 0x000075AEC0BCF264
000075aec0bd0560  call 0x000075AEC0AC2240
000075aec0bd0565  jmp 0x000075AEC0BCF271
000075aec0bd056a  call 0x000075AEC0AB5400
000075aec0bd056f  jmp 0x000075AEC0BCF27E
000075aec0bd0574  call 0x000075AEC0AB52F0
000075aec0bd0579  jmp 0x000075AEC0BCF28B
000075aec0bd057e  call 0x000075AEC0AC2120
000075aec0bd0583  jmp 0x000075AEC0BCF298
000075aec0bd0588  call 0x000075AEC0AB52F0
000075aec0bd058d  jmp 0x000075AEC0BCF2AB
000075aec0bd0592  call 0x000075AEC0AB52F0
000075aec0bd0597  jmp 0x000075AEC0BCF2BE
000075aec0bd059c  call 0x000075AEC0AB52F0
000075aec0bd05a1  jmp 0x000075AEC0BCF2D1
000075aec0bd05a6  call 0x000075AEC0AB52F0
000075aec0bd05ab  jmp 0x000075AEC0BCF2E4
000075aec0bd05b0  call 0x000075AEC0AC2240
000075aec0bd05b5  jmp 0x000075AEC0BCF2F9
000075aec0bd05ba  call 0x000075AEC0AC2240
000075aec0bd05bf  jmp 0x000075AEC0BCF30C
000075aec0bd05c4  call 0x000075AEC0AC2120
000075aec0bd05c9  jmp 0x000075AEC0BCF319
000075aec0bd05ce  call 0x000075AEC0AB52F0
000075aec0bd05d3  jmp 0x000075AEC0BCF32C
000075aec0bd05d8  call 0x000075AEC0AB52F0
000075aec0bd05dd  jmp 0x000075AEC0BCF34F
000075aec0bd05e2  call 0x000075AEC0AB52F0
000075aec0bd05e7  jmp 0x000075AEC0BCF362
000075aec0bd05ec  call 0x000075AEC09FF540
000075aec0bd05f1  jmp 0x000075AEC0BCF380
000075aec0bd05f6  call 0x000075AEC0A08C20
000075aec0bd05fb  jmp 0x000075AEC0BCF38A
000075aec0bd0600  call 0x000075AEC0AD6600
000075aec0bd0605  jmp 0x000075AEC0BCF396
000075aec0bd060a  call 0x000075AEC09FF540
000075aec0bd060f  jmp 0x000075AEC0BCF3A6
000075aec0bd0614  call 0x000075AEC0AC0370
000075aec0bd0619  jmp 0x000075AEC0BCF3D4
000075aec0bd061e  call 0x000075AEC0ABF100
000075aec0bd0623  jmp 0x000075AEC0BCF3DD
000075aec0bd0628  call 0x000075AEC0AC0370
000075aec0bd062d  jmp 0x000075AEC0BCF43B
000075aec0bd0632  call 0x000075AEC0ABF100
000075aec0bd0637  jmp 0x000075AEC0BCF444
000075aec0bd063c  call 0x000075AEC0AC0370
000075aec0bd0641  jmp 0x000075AEC0BCF48B
000075aec0bd0646  call 0x000075AEC0ABF100
000075aec0bd064b  jmp 0x000075AEC0BCF494
000075aec0bd0650  call 0x000075AEC0A0B720
000075aec0bd0655  jmp 0x000075AEC0BCF4D7
000075aec0bd065a  call 0x000075AEC0AB47C0
000075aec0bd065f  jmp 0x000075AEC0BCF4EA
000075aec0bd0664  call 0x000075AEC0A08B00
000075aec0bd0669  jmp 0x000075AEC0BCF501
000075aec0bd066e  call 0x000075AEC09FF430
000075aec0bd0673  jmp 0x000075AEC0BCF514
000075aec0bd0678  call 0x000075AEC09FF430
000075aec0bd067d  jmp 0x000075AEC0BCF527
000075aec0bd0682  sub rsp, 0x08
000075aec0bd0686  push rax
000075aec0bd0687  push rcx
000075aec0bd0688  push rdx
000075aec0bd0689  push rdi
000075aec0bd068a  push rsi
000075aec0bd068b  push r8
000075aec0bd068d  push r9
000075aec0bd068f  push r10
000075aec0bd0691  push r11
000075aec0bd0693  sub rsp, 0xF0
000075aec0bd069a  vmovaps [rsp], xmm0
000075aec0bd069f  vmovaps [rsp+0x10], xmm2
000075aec0bd06a5  vmovaps [rsp+0x20], xmm3
000075aec0bd06ab  vmovaps [rsp+0x30], xmm4
000075aec0bd06b1  vmovaps [rsp+0x40], xmm5
000075aec0bd06b7  vmovaps [rsp+0x50], xmm6
000075aec0bd06bd  vmovaps [rsp+0x60], xmm7
000075aec0bd06c3  vmovaps [rsp+0x70], xmm8
000075aec0bd06c9  vmovaps [rsp+0x80], xmm9
000075aec0bd06d2  vmovaps [rsp+0x90], xmm10
000075aec0bd06db  vmovaps [rsp+0xA0], xmm11
000075aec0bd06e4  vmovaps [rsp+0xB0], xmm12
000075aec0bd06ed  vmovaps [rsp+0xC0], xmm13
000075aec0bd06f6  vmovaps [rsp+0xD0], xmm14
000075aec0bd06ff  vmovaps [rsp+0xE0], xmm15
000075aec0bd0708  sub rsp, 0x30
000075aec0bd070c  movaps [rsp], xmm1
000075aec0bd0710  movaps [rsp+0x10], xmm15
000075aec0bd0716  movaps [rsp+0x20], xmm14
000075aec0bd071c  lea rdi, [rsp]
000075aec0bd0720  mov esi, 0x00
000075aec0bd0725  mov rax, 0x57F4B31E6530
000075aec0bd072f  call rax
000075aec0bd0731  movaps xmm1, [rsp]
000075aec0bd0735  add rsp, 0x30
000075aec0bd0739  vmovaps xmm0, [rsp]
000075aec0bd073e  vmovaps xmm2, [rsp+0x10]
000075aec0bd0744  vmovaps xmm3, [rsp+0x20]
000075aec0bd074a  vmovaps xmm4, [rsp+0x30]
000075aec0bd0750  vmovaps xmm5, [rsp+0x40]
000075aec0bd0756  vmovaps xmm6, [rsp+0x50]
000075aec0bd075c  vmovaps xmm7, [rsp+0x60]
000075aec0bd0762  vmovaps xmm8, [rsp+0x70]
000075aec0bd0768  vmovaps xmm9, [rsp+0x80]
000075aec0bd0771  vmovaps xmm10, [rsp+0x90]
000075aec0bd077a  vmovaps xmm11, [rsp+0xA0]
000075aec0bd0783  vmovaps xmm12, [rsp+0xB0]
000075aec0bd078c  vmovaps xmm13, [rsp+0xC0]
000075aec0bd0795  vmovaps xmm14, [rsp+0xD0]
000075aec0bd079e  vmovaps xmm15, [rsp+0xE0]
000075aec0bd07a7  add rsp, 0xF0
000075aec0bd07ae  pop r11
000075aec0bd07b0  pop r10
000075aec0bd07b2  pop r9
000075aec0bd07b4  pop r8
000075aec0bd07b6  pop rsi
000075aec0bd07b7  pop rdi
000075aec0bd07b8  pop rdx
000075aec0bd07b9  pop rcx
000075aec0bd07ba  pop rax
000075aec0bd07bb  add rsp, 0x08
000075aec0bd07bf  jmp 0x000075AEC0BCF581
000075aec0bd07c4  sub rsp, 0x08
000075aec0bd07c8  push rax
000075aec0bd07c9  push rcx
000075aec0bd07ca  push rdx
000075aec0bd07cb  push rdi
000075aec0bd07cc  push rsi
000075aec0bd07cd  push r8
000075aec0bd07cf  push r9
000075aec0bd07d1  push r10
000075aec0bd07d3  push r11
000075aec0bd07d5  sub rsp, 0xF0
000075aec0bd07dc  vmovaps [rsp], xmm0
000075aec0bd07e1  vmovaps [rsp+0x10], xmm1
000075aec0bd07e7  vmovaps [rsp+0x20], xmm2
000075aec0bd07ed  vmovaps [rsp+0x30], xmm3
000075aec0bd07f3  vmovaps [rsp+0x40], xmm4
000075aec0bd07f9  vmovaps [rsp+0x50], xmm5
000075aec0bd07ff  vmovaps [rsp+0x60], xmm6
000075aec0bd0805  vmovaps [rsp+0x70], xmm7
000075aec0bd080b  vmovaps [rsp+0x80], xmm8
000075aec0bd0814  vmovaps [rsp+0x90], xmm9
000075aec0bd081d  vmovaps [rsp+0xA0], xmm10
000075aec0bd0826  vmovaps [rsp+0xB0], xmm11
000075aec0bd082f  vmovaps [rsp+0xC0], xmm12
000075aec0bd0838  vmovaps [rsp+0xD0], xmm14
000075aec0bd0841  vmovaps [rsp+0xE0], xmm15
000075aec0bd084a  sub rsp, 0x30
000075aec0bd084e  movaps [rsp], xmm13
000075aec0bd0853  movaps [rsp+0x10], xmm1
000075aec0bd0858  movaps [rsp+0x20], xmm14
000075aec0bd085e  lea rdi, [rsp]
000075aec0bd0862  mov esi, 0x00
000075aec0bd0867  mov rax, 0x57F4B31E6530
000075aec0bd0871  call rax
000075aec0bd0873  movaps xmm13, [rsp]
000075aec0bd0878  add rsp, 0x30
000075aec0bd087c  vmovaps xmm0, [rsp]
000075aec0bd0881  vmovaps xmm1, [rsp+0x10]
000075aec0bd0887  vmovaps xmm2, [rsp+0x20]
000075aec0bd088d  vmovaps xmm3, [rsp+0x30]
000075aec0bd0893  vmovaps xmm4, [rsp+0x40]
000075aec0bd0899  vmovaps xmm5, [rsp+0x50]
000075aec0bd089f  vmovaps xmm6, [rsp+0x60]
000075aec0bd08a5  vmovaps xmm7, [rsp+0x70]
000075aec0bd08ab  vmovaps xmm8, [rsp+0x80]
000075aec0bd08b4  vmovaps xmm9, [rsp+0x90]
000075aec0bd08bd  vmovaps xmm10, [rsp+0xA0]
000075aec0bd08c6  vmovaps xmm11, [rsp+0xB0]
000075aec0bd08cf  vmovaps xmm12, [rsp+0xC0]
000075aec0bd08d8  vmovaps xmm14, [rsp+0xD0]
000075aec0bd08e1  vmovaps xmm15, [rsp+0xE0]
000075aec0bd08ea  add rsp, 0xF0
000075aec0bd08f1  pop r11
000075aec0bd08f3  pop r10
000075aec0bd08f5  pop r9
000075aec0bd08f7  pop r8
000075aec0bd08f9  pop rsi
000075aec0bd08fa  pop rdi
000075aec0bd08fb  pop rdx
000075aec0bd08fc  pop rcx
000075aec0bd08fd  pop rax
000075aec0bd08fe  add rsp, 0x08
000075aec0bd0902  jmp 0x000075AEC0BCF5CF
000075aec0bd0907  sub rsp, 0x08
000075aec0bd090b  push rax
000075aec0bd090c  push rcx
000075aec0bd090d  push rdx
000075aec0bd090e  push rdi
000075aec0bd090f  push rsi
000075aec0bd0910  push r8
000075aec0bd0912  push r9
000075aec0bd0914  push r10
000075aec0bd0916  push r11
000075aec0bd0918  sub rsp, 0xF0
000075aec0bd091f  vmovaps [rsp], xmm0
000075aec0bd0924  vmovaps [rsp+0x10], xmm1
000075aec0bd092a  vmovaps [rsp+0x20], xmm2
000075aec0bd0930  vmovaps [rsp+0x30], xmm3
000075aec0bd0936  vmovaps [rsp+0x40], xmm4
000075aec0bd093c  vmovaps [rsp+0x50], xmm5
000075aec0bd0942  vmovaps [rsp+0x60], xmm6
000075aec0bd0948  vmovaps [rsp+0x70], xmm7
000075aec0bd094e  vmovaps [rsp+0x80], xmm8
000075aec0bd0957  vmovaps [rsp+0x90], xmm9
000075aec0bd0960  vmovaps [rsp+0xA0], xmm10
000075aec0bd0969  vmovaps [rsp+0xB0], xmm11
000075aec0bd0972  vmovaps [rsp+0xC0], xmm12
000075aec0bd097b  vmovaps [rsp+0xD0], xmm13
000075aec0bd0984  vmovaps [rsp+0xE0], xmm14
000075aec0bd098d  sub rsp, 0x30
000075aec0bd0991  movaps [rsp], xmm15
000075aec0bd0996  movaps [rsp+0x10], xmm14
000075aec0bd099c  movaps [rsp+0x20], xmm1
000075aec0bd09a1  lea rdi, [rsp]
000075aec0bd09a5  mov esi, 0x00
000075aec0bd09aa  mov rax, 0x57F4B31E6530
000075aec0bd09b4  call rax
000075aec0bd09b6  movaps xmm15, [rsp]
000075aec0bd09bb  add rsp, 0x30
000075aec0bd09bf  vmovaps xmm0, [rsp]
000075aec0bd09c4  vmovaps xmm1, [rsp+0x10]
000075aec0bd09ca  vmovaps xmm2, [rsp+0x20]
000075aec0bd09d0  vmovaps xmm3, [rsp+0x30]
000075aec0bd09d6  vmovaps xmm4, [rsp+0x40]
000075aec0bd09dc  vmovaps xmm5, [rsp+0x50]
000075aec0bd09e2  vmovaps xmm6, [rsp+0x60]
000075aec0bd09e8  vmovaps xmm7, [rsp+0x70]
000075aec0bd09ee  vmovaps xmm8, [rsp+0x80]
000075aec0bd09f7  vmovaps xmm9, [rsp+0x90]
000075aec0bd0a00  vmovaps xmm10, [rsp+0xA0]
000075aec0bd0a09  vmovaps xmm11, [rsp+0xB0]
000075aec0bd0a12  vmovaps xmm12, [rsp+0xC0]
000075aec0bd0a1b  vmovaps xmm13, [rsp+0xD0]
000075aec0bd0a24  vmovaps xmm14, [rsp+0xE0]
000075aec0bd0a2d  add rsp, 0xF0
000075aec0bd0a34  pop r11
000075aec0bd0a36  pop r10
000075aec0bd0a38  pop r9
000075aec0bd0a3a  pop r8
000075aec0bd0a3c  pop rsi
000075aec0bd0a3d  pop rdi
000075aec0bd0a3e  pop rdx
000075aec0bd0a3f  pop rcx
000075aec0bd0a40  pop rax
000075aec0bd0a41  add rsp, 0x08
000075aec0bd0a45  jmp 0x000075AEC0BCF617
000075aec0bd0a4a  sub rsp, 0x08
000075aec0bd0a4e  push rax
000075aec0bd0a4f  push rcx
000075aec0bd0a50  push rdx
000075aec0bd0a51  push rdi
000075aec0bd0a52  push rsi
000075aec0bd0a53  push r8
000075aec0bd0a55  push r9
000075aec0bd0a57  push r10
000075aec0bd0a59  push r11
000075aec0bd0a5b  sub rsp, 0xF0
000075aec0bd0a62  vmovaps [rsp], xmm0
000075aec0bd0a67  vmovaps [rsp+0x10], xmm2
000075aec0bd0a6d  vmovaps [rsp+0x20], xmm3
000075aec0bd0a73  vmovaps [rsp+0x30], xmm4
000075aec0bd0a79  vmovaps [rsp+0x40], xmm5
000075aec0bd0a7f  vmovaps [rsp+0x50], xmm6
000075aec0bd0a85  vmovaps [rsp+0x60], xmm7
000075aec0bd0a8b  vmovaps [rsp+0x70], xmm8
000075aec0bd0a91  vmovaps [rsp+0x80], xmm9
000075aec0bd0a9a  vmovaps [rsp+0x90], xmm10
000075aec0bd0aa3  vmovaps [rsp+0xA0], xmm11
000075aec0bd0aac  vmovaps [rsp+0xB0], xmm12
000075aec0bd0ab5  vmovaps [rsp+0xC0], xmm13
000075aec0bd0abe  vmovaps [rsp+0xD0], xmm14
000075aec0bd0ac7  vmovaps [rsp+0xE0], xmm15
000075aec0bd0ad0  sub rsp, 0x30
000075aec0bd0ad4  movaps [rsp], xmm1
000075aec0bd0ad8  movaps [rsp+0x10], xmm14
000075aec0bd0ade  movaps [rsp+0x20], xmm10
000075aec0bd0ae4  lea rdi, [rsp]
000075aec0bd0ae8  mov esi, 0x00
000075aec0bd0aed  mov rax, 0x57F4B31E6530
000075aec0bd0af7  call rax
000075aec0bd0af9  movaps xmm1, [rsp]
000075aec0bd0afd  add rsp, 0x30
000075aec0bd0b01  vmovaps xmm0, [rsp]
000075aec0bd0b06  vmovaps xmm2, [rsp+0x10]
000075aec0bd0b0c  vmovaps xmm3, [rsp+0x20]
000075aec0bd0b12  vmovaps xmm4, [rsp+0x30]
000075aec0bd0b18  vmovaps xmm5, [rsp+0x40]
000075aec0bd0b1e  vmovaps xmm6, [rsp+0x50]
000075aec0bd0b24  vmovaps xmm7, [rsp+0x60]
000075aec0bd0b2a  vmovaps xmm8, [rsp+0x70]
000075aec0bd0b30  vmovaps xmm9, [rsp+0x80]
000075aec0bd0b39  vmovaps xmm10, [rsp+0x90]
000075aec0bd0b42  vmovaps xmm11, [rsp+0xA0]
000075aec0bd0b4b  vmovaps xmm12, [rsp+0xB0]
000075aec0bd0b54  vmovaps xmm13, [rsp+0xC0]
000075aec0bd0b5d  vmovaps xmm14, [rsp+0xD0]
000075aec0bd0b66  vmovaps xmm15, [rsp+0xE0]
000075aec0bd0b6f  add rsp, 0xF0
000075aec0bd0b76  pop r11
000075aec0bd0b78  pop r10
000075aec0bd0b7a  pop r9
000075aec0bd0b7c  pop r8
000075aec0bd0b7e  pop rsi
000075aec0bd0b7f  pop rdi
000075aec0bd0b80  pop rdx
000075aec0bd0b81  pop rcx
000075aec0bd0b82  pop rax
000075aec0bd0b83  add rsp, 0x08
000075aec0bd0b87  jmp 0x000075AEC0BCF631
000075aec0bd0b8c  sub rsp, 0x08
000075aec0bd0b90  push rax
000075aec0bd0b91  push rcx
000075aec0bd0b92  push rdx
000075aec0bd0b93  push rdi
000075aec0bd0b94  push rsi
000075aec0bd0b95  push r8
000075aec0bd0b97  push r9
000075aec0bd0b99  push r10
000075aec0bd0b9b  push r11
000075aec0bd0b9d  sub rsp, 0xF0
000075aec0bd0ba4  vmovaps [rsp], xmm0
000075aec0bd0ba9  vmovaps [rsp+0x10], xmm1
000075aec0bd0baf  vmovaps [rsp+0x20], xmm2
000075aec0bd0bb5  vmovaps [rsp+0x30], xmm3
000075aec0bd0bbb  vmovaps [rsp+0x40], xmm4
000075aec0bd0bc1  vmovaps [rsp+0x50], xmm5
000075aec0bd0bc7  vmovaps [rsp+0x60], xmm6
000075aec0bd0bcd  vmovaps [rsp+0x70], xmm7
000075aec0bd0bd3  vmovaps [rsp+0x80], xmm8
000075aec0bd0bdc  vmovaps [rsp+0x90], xmm9
000075aec0bd0be5  vmovaps [rsp+0xA0], xmm10
000075aec0bd0bee  vmovaps [rsp+0xB0], xmm11
000075aec0bd0bf7  vmovaps [rsp+0xC0], xmm12
000075aec0bd0c00  vmovaps [rsp+0xD0], xmm14
000075aec0bd0c09  vmovaps [rsp+0xE0], xmm15
000075aec0bd0c12  sub rsp, 0x30
000075aec0bd0c16  movaps [rsp], xmm13
000075aec0bd0c1b  movaps [rsp+0x10], xmm14
000075aec0bd0c21  movaps [rsp+0x20], xmm2
000075aec0bd0c26  lea rdi, [rsp]
000075aec0bd0c2a  mov esi, 0x00
000075aec0bd0c2f  mov rax, 0x57F4B31E6530
000075aec0bd0c39  call rax
000075aec0bd0c3b  movaps xmm13, [rsp]
000075aec0bd0c40  add rsp, 0x30
000075aec0bd0c44  vmovaps xmm0, [rsp]
000075aec0bd0c49  vmovaps xmm1, [rsp+0x10]
000075aec0bd0c4f  vmovaps xmm2, [rsp+0x20]
000075aec0bd0c55  vmovaps xmm3, [rsp+0x30]
000075aec0bd0c5b  vmovaps xmm4, [rsp+0x40]
000075aec0bd0c61  vmovaps xmm5, [rsp+0x50]
000075aec0bd0c67  vmovaps xmm6, [rsp+0x60]
000075aec0bd0c6d  vmovaps xmm7, [rsp+0x70]
000075aec0bd0c73  vmovaps xmm8, [rsp+0x80]
000075aec0bd0c7c  vmovaps xmm9, [rsp+0x90]
000075aec0bd0c85  vmovaps xmm10, [rsp+0xA0]
000075aec0bd0c8e  vmovaps xmm11, [rsp+0xB0]
000075aec0bd0c97  vmovaps xmm12, [rsp+0xC0]
000075aec0bd0ca0  vmovaps xmm14, [rsp+0xD0]
000075aec0bd0ca9  vmovaps xmm15, [rsp+0xE0]
000075aec0bd0cb2  add rsp, 0xF0
000075aec0bd0cb9  pop r11
000075aec0bd0cbb  pop r10
000075aec0bd0cbd  pop r9
000075aec0bd0cbf  pop r8
000075aec0bd0cc1  pop rsi
000075aec0bd0cc2  pop rdi
000075aec0bd0cc3  pop rdx
000075aec0bd0cc4  pop rcx
000075aec0bd0cc5  pop rax
000075aec0bd0cc6  add rsp, 0x08
000075aec0bd0cca  jmp 0x000075AEC0BCF64C
000075aec0bd0ccf  sub rsp, 0x08
000075aec0bd0cd3  push rax
000075aec0bd0cd4  push rcx
000075aec0bd0cd5  push rdx
000075aec0bd0cd6  push rdi
000075aec0bd0cd7  push rsi
000075aec0bd0cd8  push r8
000075aec0bd0cda  push r9
000075aec0bd0cdc  push r10
000075aec0bd0cde  push r11
000075aec0bd0ce0  sub rsp, 0xF0
000075aec0bd0ce7  vmovaps [rsp], xmm0
000075aec0bd0cec  vmovaps [rsp+0x10], xmm2
000075aec0bd0cf2  vmovaps [rsp+0x20], xmm3
000075aec0bd0cf8  vmovaps [rsp+0x30], xmm4
000075aec0bd0cfe  vmovaps [rsp+0x40], xmm5
000075aec0bd0d04  vmovaps [rsp+0x50], xmm6
000075aec0bd0d0a  vmovaps [rsp+0x60], xmm7
000075aec0bd0d10  vmovaps [rsp+0x70], xmm8
000075aec0bd0d16  vmovaps [rsp+0x80], xmm9
000075aec0bd0d1f  vmovaps [rsp+0x90], xmm10
000075aec0bd0d28  vmovaps [rsp+0xA0], xmm11
000075aec0bd0d31  vmovaps [rsp+0xB0], xmm12
000075aec0bd0d3a  vmovaps [rsp+0xC0], xmm13
000075aec0bd0d43  vmovaps [rsp+0xD0], xmm14
000075aec0bd0d4c  vmovaps [rsp+0xE0], xmm15
000075aec0bd0d55  sub rsp, 0x30
000075aec0bd0d59  movaps [rsp], xmm1
000075aec0bd0d5d  movaps [rsp+0x10], xmm10
000075aec0bd0d63  movaps [rsp+0x20], xmm2
000075aec0bd0d68  lea rdi, [rsp]
000075aec0bd0d6c  mov esi, 0x00
000075aec0bd0d71  mov rax, 0x57F4B31E6530
000075aec0bd0d7b  call rax
000075aec0bd0d7d  movaps xmm1, [rsp]
000075aec0bd0d81  add rsp, 0x30
000075aec0bd0d85  vmovaps xmm0, [rsp]
000075aec0bd0d8a  vmovaps xmm2, [rsp+0x10]
000075aec0bd0d90  vmovaps xmm3, [rsp+0x20]
000075aec0bd0d96  vmovaps xmm4, [rsp+0x30]
000075aec0bd0d9c  vmovaps xmm5, [rsp+0x40]
000075aec0bd0da2  vmovaps xmm6, [rsp+0x50]
000075aec0bd0da8  vmovaps xmm7, [rsp+0x60]
000075aec0bd0dae  vmovaps xmm8, [rsp+0x70]
000075aec0bd0db4  vmovaps xmm9, [rsp+0x80]
000075aec0bd0dbd  vmovaps xmm10, [rsp+0x90]
000075aec0bd0dc6  vmovaps xmm11, [rsp+0xA0]
000075aec0bd0dcf  vmovaps xmm12, [rsp+0xB0]
000075aec0bd0dd8  vmovaps xmm13, [rsp+0xC0]
000075aec0bd0de1  vmovaps xmm14, [rsp+0xD0]
000075aec0bd0dea  vmovaps xmm15, [rsp+0xE0]
000075aec0bd0df3  add rsp, 0xF0
000075aec0bd0dfa  pop r11
000075aec0bd0dfc  pop r10
000075aec0bd0dfe  pop r9
000075aec0bd0e00  pop r8
000075aec0bd0e02  pop rsi
000075aec0bd0e03  pop rdi
000075aec0bd0e04  pop rdx
000075aec0bd0e05  pop rcx
000075aec0bd0e06  pop rax
000075aec0bd0e07  add rsp, 0x08
000075aec0bd0e0b  jmp 0x000075AEC0BCF6B4
000075aec0bd0e10  sub rsp, 0x08
000075aec0bd0e14  push rax
000075aec0bd0e15  push rcx
000075aec0bd0e16  push rdx
000075aec0bd0e17  push rdi
000075aec0bd0e18  push rsi
000075aec0bd0e19  push r8
000075aec0bd0e1b  push r9
000075aec0bd0e1d  push r10
000075aec0bd0e1f  push r11
000075aec0bd0e21  sub rsp, 0xF0
000075aec0bd0e28  vmovaps [rsp], xmm0
000075aec0bd0e2d  vmovaps [rsp+0x10], xmm1
000075aec0bd0e33  vmovaps [rsp+0x20], xmm2
000075aec0bd0e39  vmovaps [rsp+0x30], xmm3
000075aec0bd0e3f  vmovaps [rsp+0x40], xmm4
000075aec0bd0e45  vmovaps [rsp+0x50], xmm5
000075aec0bd0e4b  vmovaps [rsp+0x60], xmm6
000075aec0bd0e51  vmovaps [rsp+0x70], xmm7
000075aec0bd0e57  vmovaps [rsp+0x80], xmm8
000075aec0bd0e60  vmovaps [rsp+0x90], xmm9
000075aec0bd0e69  vmovaps [rsp+0xA0], xmm10
000075aec0bd0e72  vmovaps [rsp+0xB0], xmm11
000075aec0bd0e7b  vmovaps [rsp+0xC0], xmm12
000075aec0bd0e84  vmovaps [rsp+0xD0], xmm13
000075aec0bd0e8d  vmovaps [rsp+0xE0], xmm14
000075aec0bd0e96  sub rsp, 0x30
000075aec0bd0e9a  movaps [rsp], xmm15
000075aec0bd0e9f  movaps [rsp+0x10], xmm10
000075aec0bd0ea5  movaps [rsp+0x20], xmm2
000075aec0bd0eaa  lea rdi, [rsp]
000075aec0bd0eae  mov esi, 0x00
000075aec0bd0eb3  mov rax, 0x57F4B31E6530
000075aec0bd0ebd  call rax
000075aec0bd0ebf  movaps xmm15, [rsp]
000075aec0bd0ec4  add rsp, 0x30
000075aec0bd0ec8  vmovaps xmm0, [rsp]
000075aec0bd0ecd  vmovaps xmm1, [rsp+0x10]
000075aec0bd0ed3  vmovaps xmm2, [rsp+0x20]
000075aec0bd0ed9  vmovaps xmm3, [rsp+0x30]
000075aec0bd0edf  vmovaps xmm4, [rsp+0x40]
000075aec0bd0ee5  vmovaps xmm5, [rsp+0x50]
000075aec0bd0eeb  vmovaps xmm6, [rsp+0x60]
000075aec0bd0ef1  vmovaps xmm7, [rsp+0x70]
000075aec0bd0ef7  vmovaps xmm8, [rsp+0x80]
000075aec0bd0f00  vmovaps xmm9, [rsp+0x90]
000075aec0bd0f09  vmovaps xmm10, [rsp+0xA0]
000075aec0bd0f12  vmovaps xmm11, [rsp+0xB0]
000075aec0bd0f1b  vmovaps xmm12, [rsp+0xC0]
000075aec0bd0f24  vmovaps xmm13, [rsp+0xD0]
000075aec0bd0f2d  vmovaps xmm14, [rsp+0xE0]
000075aec0bd0f36  add rsp, 0xF0
000075aec0bd0f3d  pop r11
000075aec0bd0f3f  pop r10
000075aec0bd0f41  pop r9
000075aec0bd0f43  pop r8
000075aec0bd0f45  pop rsi
000075aec0bd0f46  pop rdi
000075aec0bd0f47  pop rdx
000075aec0bd0f48  pop rcx
000075aec0bd0f49  pop rax
000075aec0bd0f4a  add rsp, 0x08
000075aec0bd0f4e  jmp 0x000075AEC0BCF706
000075aec0bd0f53  sub rsp, 0x08
000075aec0bd0f57  push rax
000075aec0bd0f58  push rcx
000075aec0bd0f59  push rdx
000075aec0bd0f5a  push rdi
000075aec0bd0f5b  push rsi
000075aec0bd0f5c  push r8
000075aec0bd0f5e  push r9
000075aec0bd0f60  push r10
000075aec0bd0f62  push r11
000075aec0bd0f64  sub rsp, 0xF0
000075aec0bd0f6b  vmovaps [rsp], xmm0
000075aec0bd0f70  vmovaps [rsp+0x10], xmm2
000075aec0bd0f76  vmovaps [rsp+0x20], xmm3
000075aec0bd0f7c  vmovaps [rsp+0x30], xmm4
000075aec0bd0f82  vmovaps [rsp+0x40], xmm5
000075aec0bd0f88  vmovaps [rsp+0x50], xmm6
000075aec0bd0f8e  vmovaps [rsp+0x60], xmm7
000075aec0bd0f94  vmovaps [rsp+0x70], xmm8
000075aec0bd0f9a  vmovaps [rsp+0x80], xmm9
000075aec0bd0fa3  vmovaps [rsp+0x90], xmm10
000075aec0bd0fac  vmovaps [rsp+0xA0], xmm11
000075aec0bd0fb5  vmovaps [rsp+0xB0], xmm12
000075aec0bd0fbe  vmovaps [rsp+0xC0], xmm13
000075aec0bd0fc7  vmovaps [rsp+0xD0], xmm14
000075aec0bd0fd0  vmovaps [rsp+0xE0], xmm15
000075aec0bd0fd9  sub rsp, 0x30
000075aec0bd0fdd  movaps [rsp], xmm1
000075aec0bd0fe1  movaps [rsp+0x10], xmm10
000075aec0bd0fe7  movaps [rsp+0x20], xmm12
000075aec0bd0fed  lea rdi, [rsp]
000075aec0bd0ff1  mov esi, 0x00
000075aec0bd0ff6  mov rax, 0x57F4B31E6530
000075aec0bd1000  call rax
000075aec0bd1002  movaps xmm1, [rsp]
000075aec0bd1006  add rsp, 0x30
000075aec0bd100a  vmovaps xmm0, [rsp]
000075aec0bd100f  vmovaps xmm2, [rsp+0x10]
000075aec0bd1015  vmovaps xmm3, [rsp+0x20]
000075aec0bd101b  vmovaps xmm4, [rsp+0x30]
000075aec0bd1021  vmovaps xmm5, [rsp+0x40]
000075aec0bd1027  vmovaps xmm6, [rsp+0x50]
000075aec0bd102d  vmovaps xmm7, [rsp+0x60]
000075aec0bd1033  vmovaps xmm8, [rsp+0x70]
000075aec0bd1039  vmovaps xmm9, [rsp+0x80]
000075aec0bd1042  vmovaps xmm10, [rsp+0x90]
000075aec0bd104b  vmovaps xmm11, [rsp+0xA0]
000075aec0bd1054  vmovaps xmm12, [rsp+0xB0]
000075aec0bd105d  vmovaps xmm13, [rsp+0xC0]
000075aec0bd1066  vmovaps xmm14, [rsp+0xD0]
000075aec0bd106f  vmovaps xmm15, [rsp+0xE0]
000075aec0bd1078  add rsp, 0xF0
000075aec0bd107f  pop r11
000075aec0bd1081  pop r10
000075aec0bd1083  pop r9
000075aec0bd1085  pop r8
000075aec0bd1087  pop rsi
000075aec0bd1088  pop rdi
000075aec0bd1089  pop rdx
000075aec0bd108a  pop rcx
000075aec0bd108b  pop rax
000075aec0bd108c  add rsp, 0x08
000075aec0bd1090  jmp 0x000075AEC0BCF732
000075aec0bd1095  sub rsp, 0x08
000075aec0bd1099  push rax
000075aec0bd109a  push rcx
000075aec0bd109b  push rdx
000075aec0bd109c  push rdi
000075aec0bd109d  push rsi
000075aec0bd109e  push r8
000075aec0bd10a0  push r9
000075aec0bd10a2  push r10
000075aec0bd10a4  push r11
000075aec0bd10a6  sub rsp, 0xF0
000075aec0bd10ad  vmovaps [rsp], xmm0
000075aec0bd10b2  vmovaps [rsp+0x10], xmm1
000075aec0bd10b8  vmovaps [rsp+0x20], xmm2
000075aec0bd10be  vmovaps [rsp+0x30], xmm3
000075aec0bd10c4  vmovaps [rsp+0x40], xmm4
000075aec0bd10ca  vmovaps [rsp+0x50], xmm5
000075aec0bd10d0  vmovaps [rsp+0x60], xmm6
000075aec0bd10d6  vmovaps [rsp+0x70], xmm7
000075aec0bd10dc  vmovaps [rsp+0x80], xmm8
000075aec0bd10e5  vmovaps [rsp+0x90], xmm9
000075aec0bd10ee  vmovaps [rsp+0xA0], xmm10
000075aec0bd10f7  vmovaps [rsp+0xB0], xmm11
000075aec0bd1100  vmovaps [rsp+0xC0], xmm12
000075aec0bd1109  vmovaps [rsp+0xD0], xmm13
000075aec0bd1112  vmovaps [rsp+0xE0], xmm14
000075aec0bd111b  sub rsp, 0x30
000075aec0bd111f  movaps [rsp], xmm15
000075aec0bd1124  movaps [rsp+0x10], xmm10
000075aec0bd112a  movaps [rsp+0x20], xmm12
000075aec0bd1130  lea rdi, [rsp]
000075aec0bd1134  mov esi, 0x00
000075aec0bd1139  mov rax, 0x57F4B31E6530
000075aec0bd1143  call rax
000075aec0bd1145  movaps xmm15, [rsp]
000075aec0bd114a  add rsp, 0x30
000075aec0bd114e  vmovaps xmm0, [rsp]
000075aec0bd1153  vmovaps xmm1, [rsp+0x10]
000075aec0bd1159  vmovaps xmm2, [rsp+0x20]
000075aec0bd115f  vmovaps xmm3, [rsp+0x30]
000075aec0bd1165  vmovaps xmm4, [rsp+0x40]
000075aec0bd116b  vmovaps xmm5, [rsp+0x50]
000075aec0bd1171  vmovaps xmm6, [rsp+0x60]
000075aec0bd1177  vmovaps xmm7, [rsp+0x70]
000075aec0bd117d  vmovaps xmm8, [rsp+0x80]
000075aec0bd1186  vmovaps xmm9, [rsp+0x90]
000075aec0bd118f  vmovaps xmm10, [rsp+0xA0]
000075aec0bd1198  vmovaps xmm11, [rsp+0xB0]
000075aec0bd11a1  vmovaps xmm12, [rsp+0xC0]
000075aec0bd11aa  vmovaps xmm13, [rsp+0xD0]
000075aec0bd11b3  vmovaps xmm14, [rsp+0xE0]
000075aec0bd11bc  add rsp, 0xF0
000075aec0bd11c3  pop r11
000075aec0bd11c5  pop r10
000075aec0bd11c7  pop r9
000075aec0bd11c9  pop r8
000075aec0bd11cb  pop rsi
000075aec0bd11cc  pop rdi
000075aec0bd11cd  pop rdx
000075aec0bd11ce  pop rcx
000075aec0bd11cf  pop rax
000075aec0bd11d0  add rsp, 0x08
000075aec0bd11d4  jmp 0x000075AEC0BCF75E
000075aec0bd11d9  call 0x000075AEC09FF430
000075aec0bd11de  jmp 0x000075AEC0BCF7EE
000075aec0bd11e3  call 0x000075AEC09FF430
000075aec0bd11e8  jmp 0x000075AEC0BCF801
000075aec0bd11ed  sub rsp, 0x08
000075aec0bd11f1  push rax
000075aec0bd11f2  push rcx
000075aec0bd11f3  push rdx
000075aec0bd11f4  push rdi
000075aec0bd11f5  push rsi
000075aec0bd11f6  push r8
000075aec0bd11f8  push r9
000075aec0bd11fa  push r10
000075aec0bd11fc  push r11
000075aec0bd11fe  sub rsp, 0xF0
000075aec0bd1205  vmovaps [rsp], xmm0
000075aec0bd120a  vmovaps [rsp+0x10], xmm2
000075aec0bd1210  vmovaps [rsp+0x20], xmm3
000075aec0bd1216  vmovaps [rsp+0x30], xmm4
000075aec0bd121c  vmovaps [rsp+0x40], xmm5
000075aec0bd1222  vmovaps [rsp+0x50], xmm6
000075aec0bd1228  vmovaps [rsp+0x60], xmm7
000075aec0bd122e  vmovaps [rsp+0x70], xmm8
000075aec0bd1234  vmovaps [rsp+0x80], xmm9
000075aec0bd123d  vmovaps [rsp+0x90], xmm10
000075aec0bd1246  vmovaps [rsp+0xA0], xmm11
000075aec0bd124f  vmovaps [rsp+0xB0], xmm12
000075aec0bd1258  vmovaps [rsp+0xC0], xmm13
000075aec0bd1261  vmovaps [rsp+0xD0], xmm14
000075aec0bd126a  vmovaps [rsp+0xE0], xmm15
000075aec0bd1273  sub rsp, 0x30
000075aec0bd1277  movaps [rsp], xmm1
000075aec0bd127b  movaps [rsp+0x10], xmm13
000075aec0bd1281  movaps [rsp+0x20], xmm2
000075aec0bd1286  lea rdi, [rsp]
000075aec0bd128a  mov esi, 0x00
000075aec0bd128f  mov rax, 0x57F4B31E6530
000075aec0bd1299  call rax
000075aec0bd129b  movaps xmm1, [rsp]
000075aec0bd129f  add rsp, 0x30
000075aec0bd12a3  vmovaps xmm0, [rsp]
000075aec0bd12a8  vmovaps xmm2, [rsp+0x10]
000075aec0bd12ae  vmovaps xmm3, [rsp+0x20]
000075aec0bd12b4  vmovaps xmm4, [rsp+0x30]
000075aec0bd12ba  vmovaps xmm5, [rsp+0x40]
000075aec0bd12c0  vmovaps xmm6, [rsp+0x50]
000075aec0bd12c6  vmovaps xmm7, [rsp+0x60]
000075aec0bd12cc  vmovaps xmm8, [rsp+0x70]
000075aec0bd12d2  vmovaps xmm9, [rsp+0x80]
000075aec0bd12db  vmovaps xmm10, [rsp+0x90]
000075aec0bd12e4  vmovaps xmm11, [rsp+0xA0]
000075aec0bd12ed  vmovaps xmm12, [rsp+0xB0]
000075aec0bd12f6  vmovaps xmm13, [rsp+0xC0]
000075aec0bd12ff  vmovaps xmm14, [rsp+0xD0]
000075aec0bd1308  vmovaps xmm15, [rsp+0xE0]
000075aec0bd1311  add rsp, 0xF0
000075aec0bd1318  pop r11
000075aec0bd131a  pop r10
000075aec0bd131c  pop r9
000075aec0bd131e  pop r8
000075aec0bd1320  pop rsi
000075aec0bd1321  pop rdi
000075aec0bd1322  pop rdx
000075aec0bd1323  pop rcx
000075aec0bd1324  pop rax
000075aec0bd1325  add rsp, 0x08
000075aec0bd1329  jmp 0x000075AEC0BCF82C
000075aec0bd132e  call 0x000075AEC0A0E760
000075aec0bd1333  jmp 0x000075AEC0BCF839
000075aec0bd1338  sub rsp, 0x08
000075aec0bd133c  push rax
000075aec0bd133d  push rcx
000075aec0bd133e  push rdx
000075aec0bd133f  push rdi
000075aec0bd1340  push rsi
000075aec0bd1341  push r8
000075aec0bd1343  push r9
000075aec0bd1345  push r10
000075aec0bd1347  push r11
000075aec0bd1349  sub rsp, 0xF0
000075aec0bd1350  vmovaps [rsp], xmm0
000075aec0bd1355  vmovaps [rsp+0x10], xmm1
000075aec0bd135b  vmovaps [rsp+0x20], xmm2
000075aec0bd1361  vmovaps [rsp+0x30], xmm3
000075aec0bd1367  vmovaps [rsp+0x40], xmm4
000075aec0bd136d  vmovaps [rsp+0x50], xmm5
000075aec0bd1373  vmovaps [rsp+0x60], xmm6
000075aec0bd1379  vmovaps [rsp+0x70], xmm7
000075aec0bd137f  vmovaps [rsp+0x80], xmm8
000075aec0bd1388  vmovaps [rsp+0x90], xmm9
000075aec0bd1391  vmovaps [rsp+0xA0], xmm10
000075aec0bd139a  vmovaps [rsp+0xB0], xmm11
000075aec0bd13a3  vmovaps [rsp+0xC0], xmm12
000075aec0bd13ac  vmovaps [rsp+0xD0], xmm14
000075aec0bd13b5  vmovaps [rsp+0xE0], xmm15
000075aec0bd13be  sub rsp, 0x30
000075aec0bd13c2  movaps [rsp], xmm13
000075aec0bd13c7  movaps [rsp+0x10], xmm2
000075aec0bd13cc  movaps [rsp+0x20], xmm1
000075aec0bd13d1  lea rdi, [rsp]
000075aec0bd13d5  mov esi, 0x00
000075aec0bd13da  mov rax, 0x57F4B31E6530
000075aec0bd13e4  call rax
000075aec0bd13e6  movaps xmm13, [rsp]
000075aec0bd13eb  add rsp, 0x30
000075aec0bd13ef  vmovaps xmm0, [rsp]
000075aec0bd13f4  vmovaps xmm1, [rsp+0x10]
000075aec0bd13fa  vmovaps xmm2, [rsp+0x20]
000075aec0bd1400  vmovaps xmm3, [rsp+0x30]
000075aec0bd1406  vmovaps xmm4, [rsp+0x40]
000075aec0bd140c  vmovaps xmm5, [rsp+0x50]
000075aec0bd1412  vmovaps xmm6, [rsp+0x60]
000075aec0bd1418  vmovaps xmm7, [rsp+0x70]
000075aec0bd141e  vmovaps xmm8, [rsp+0x80]
000075aec0bd1427  vmovaps xmm9, [rsp+0x90]
000075aec0bd1430  vmovaps xmm10, [rsp+0xA0]
000075aec0bd1439  vmovaps xmm11, [rsp+0xB0]
000075aec0bd1442  vmovaps xmm12, [rsp+0xC0]
000075aec0bd144b  vmovaps xmm14, [rsp+0xD0]
000075aec0bd1454  vmovaps xmm15, [rsp+0xE0]
000075aec0bd145d  add rsp, 0xF0
000075aec0bd1464  pop r11
000075aec0bd1466  pop r10
000075aec0bd1468  pop r9
000075aec0bd146a  pop r8
000075aec0bd146c  pop rsi
000075aec0bd146d  pop rdi
000075aec0bd146e  pop rdx
000075aec0bd146f  pop rcx
000075aec0bd1470  pop rax
000075aec0bd1471  add rsp, 0x08
000075aec0bd1475  jmp 0x000075AEC0BCF878
000075aec0bd147a  sub rsp, 0x08
000075aec0bd147e  push rax
000075aec0bd147f  push rcx
000075aec0bd1480  push rdx
000075aec0bd1481  push rdi
000075aec0bd1482  push rsi
000075aec0bd1483  push r8
000075aec0bd1485  push r9
000075aec0bd1487  push r10
000075aec0bd1489  push r11
000075aec0bd148b  sub rsp, 0xF0
000075aec0bd1492  vmovaps [rsp], xmm0
000075aec0bd1497  vmovaps [rsp+0x10], xmm2
000075aec0bd149d  vmovaps [rsp+0x20], xmm3
000075aec0bd14a3  vmovaps [rsp+0x30], xmm4
000075aec0bd14a9  vmovaps [rsp+0x40], xmm5
000075aec0bd14af  vmovaps [rsp+0x50], xmm6
000075aec0bd14b5  vmovaps [rsp+0x60], xmm7
000075aec0bd14bb  vmovaps [rsp+0x70], xmm8
000075aec0bd14c1  vmovaps [rsp+0x80], xmm9
000075aec0bd14ca  vmovaps [rsp+0x90], xmm10
000075aec0bd14d3  vmovaps [rsp+0xA0], xmm11
000075aec0bd14dc  vmovaps [rsp+0xB0], xmm12
000075aec0bd14e5  vmovaps [rsp+0xC0], xmm13
000075aec0bd14ee  vmovaps [rsp+0xD0], xmm14
000075aec0bd14f7  vmovaps [rsp+0xE0], xmm15
000075aec0bd1500  sub rsp, 0x30
000075aec0bd1504  movaps [rsp], xmm1
000075aec0bd1508  movaps [rsp+0x10], xmm15
000075aec0bd150e  movaps [rsp+0x20], xmm2
000075aec0bd1513  lea rdi, [rsp]
000075aec0bd1517  mov esi, 0x00
000075aec0bd151c  mov rax, 0x57F4B31E6530
000075aec0bd1526  call rax
000075aec0bd1528  movaps xmm1, [rsp]
000075aec0bd152c  add rsp, 0x30
000075aec0bd1530  vmovaps xmm0, [rsp]
000075aec0bd1535  vmovaps xmm2, [rsp+0x10]
000075aec0bd153b  vmovaps xmm3, [rsp+0x20]
000075aec0bd1541  vmovaps xmm4, [rsp+0x30]
000075aec0bd1547  vmovaps xmm5, [rsp+0x40]
000075aec0bd154d  vmovaps xmm6, [rsp+0x50]
000075aec0bd1553  vmovaps xmm7, [rsp+0x60]
000075aec0bd1559  vmovaps xmm8, [rsp+0x70]
000075aec0bd155f  vmovaps xmm9, [rsp+0x80]
000075aec0bd1568  vmovaps xmm10, [rsp+0x90]
000075aec0bd1571  vmovaps xmm11, [rsp+0xA0]
000075aec0bd157a  vmovaps xmm12, [rsp+0xB0]
000075aec0bd1583  vmovaps xmm13, [rsp+0xC0]
000075aec0bd158c  vmovaps xmm14, [rsp+0xD0]
000075aec0bd1595  vmovaps xmm15, [rsp+0xE0]
000075aec0bd159e  add rsp, 0xF0
000075aec0bd15a5  pop r11
000075aec0bd15a7  pop r10
000075aec0bd15a9  pop r9
000075aec0bd15ab  pop r8
000075aec0bd15ad  pop rsi
000075aec0bd15ae  pop rdi
000075aec0bd15af  pop rdx
000075aec0bd15b0  pop rcx
000075aec0bd15b1  pop rax
000075aec0bd15b2  add rsp, 0x08
000075aec0bd15b6  jmp 0x000075AEC0BCF8AC
000075aec0bd15bb  sub rsp, 0x08
000075aec0bd15bf  push rax
000075aec0bd15c0  push rcx
000075aec0bd15c1  push rdx
000075aec0bd15c2  push rdi
000075aec0bd15c3  push rsi
000075aec0bd15c4  push r8
000075aec0bd15c6  push r9
000075aec0bd15c8  push r10
000075aec0bd15ca  push r11
000075aec0bd15cc  sub rsp, 0xF0
000075aec0bd15d3  vmovaps [rsp], xmm0
000075aec0bd15d8  vmovaps [rsp+0x10], xmm1
000075aec0bd15de  vmovaps [rsp+0x20], xmm2
000075aec0bd15e4  vmovaps [rsp+0x30], xmm3
000075aec0bd15ea  vmovaps [rsp+0x40], xmm4
000075aec0bd15f0  vmovaps [rsp+0x50], xmm5
000075aec0bd15f6  vmovaps [rsp+0x60], xmm6
000075aec0bd15fc  vmovaps [rsp+0x70], xmm7
000075aec0bd1602  vmovaps [rsp+0x80], xmm8
000075aec0bd160b  vmovaps [rsp+0x90], xmm9
000075aec0bd1614  vmovaps [rsp+0xA0], xmm10
000075aec0bd161d  vmovaps [rsp+0xB0], xmm11
000075aec0bd1626  vmovaps [rsp+0xC0], xmm12
000075aec0bd162f  vmovaps [rsp+0xD0], xmm13
000075aec0bd1638  vmovaps [rsp+0xE0], xmm15
000075aec0bd1641  sub rsp, 0x30
000075aec0bd1645  movaps [rsp], xmm14
000075aec0bd164a  movaps [rsp+0x10], xmm2
000075aec0bd164f  movaps [rsp+0x20], xmm15
000075aec0bd1655  lea rdi, [rsp]
000075aec0bd1659  mov esi, 0x00
000075aec0bd165e  mov rax, 0x57F4B31E6530
000075aec0bd1668  call rax
000075aec0bd166a  movaps xmm14, [rsp]
000075aec0bd166f  add rsp, 0x30
000075aec0bd1673  vmovaps xmm0, [rsp]
000075aec0bd1678  vmovaps xmm1, [rsp+0x10]
000075aec0bd167e  vmovaps xmm2, [rsp+0x20]
000075aec0bd1684  vmovaps xmm3, [rsp+0x30]
000075aec0bd168a  vmovaps xmm4, [rsp+0x40]
000075aec0bd1690  vmovaps xmm5, [rsp+0x50]
000075aec0bd1696  vmovaps xmm6, [rsp+0x60]
000075aec0bd169c  vmovaps xmm7, [rsp+0x70]
000075aec0bd16a2  vmovaps xmm8, [rsp+0x80]
000075aec0bd16ab  vmovaps xmm9, [rsp+0x90]
000075aec0bd16b4  vmovaps xmm10, [rsp+0xA0]
000075aec0bd16bd  vmovaps xmm11, [rsp+0xB0]
000075aec0bd16c6  vmovaps xmm12, [rsp+0xC0]
000075aec0bd16cf  vmovaps xmm13, [rsp+0xD0]
000075aec0bd16d8  vmovaps xmm15, [rsp+0xE0]
000075aec0bd16e1  add rsp, 0xF0
000075aec0bd16e8  pop r11
000075aec0bd16ea  pop r10
000075aec0bd16ec  pop r9
000075aec0bd16ee  pop r8
000075aec0bd16f0  pop rsi
000075aec0bd16f1  pop rdi
000075aec0bd16f2  pop rdx
000075aec0bd16f3  pop rcx
000075aec0bd16f4  pop rax
000075aec0bd16f5  add rsp, 0x08
000075aec0bd16f9  jmp 0x000075AEC0BCF8E7
000075aec0bd16fe  sub rsp, 0x08
000075aec0bd1702  push rax
000075aec0bd1703  push rcx
000075aec0bd1704  push rdx
000075aec0bd1705  push rdi
000075aec0bd1706  push rsi
000075aec0bd1707  push r8
000075aec0bd1709  push r9
000075aec0bd170b  push r10
000075aec0bd170d  push r11
000075aec0bd170f  sub rsp, 0xF0
000075aec0bd1716  vmovaps [rsp], xmm0
000075aec0bd171b  vmovaps [rsp+0x10], xmm1
000075aec0bd1721  vmovaps [rsp+0x20], xmm2
000075aec0bd1727  vmovaps [rsp+0x30], xmm3
000075aec0bd172d  vmovaps [rsp+0x40], xmm4
000075aec0bd1733  vmovaps [rsp+0x50], xmm5
000075aec0bd1739  vmovaps [rsp+0x60], xmm6
000075aec0bd173f  vmovaps [rsp+0x70], xmm7
000075aec0bd1745  vmovaps [rsp+0x80], xmm8
000075aec0bd174e  vmovaps [rsp+0x90], xmm9
000075aec0bd1757  vmovaps [rsp+0xA0], xmm10
000075aec0bd1760  vmovaps [rsp+0xB0], xmm11
000075aec0bd1769  vmovaps [rsp+0xC0], xmm12
000075aec0bd1772  vmovaps [rsp+0xD0], xmm13
000075aec0bd177b  vmovaps [rsp+0xE0], xmm14
000075aec0bd1784  sub rsp, 0x30
000075aec0bd1788  movaps [rsp], xmm15
000075aec0bd178d  movaps [rsp+0x10], xmm2
000075aec0bd1792  movaps [rsp+0x20], xmm1
000075aec0bd1797  lea rdi, [rsp]
000075aec0bd179b  mov esi, 0x00
000075aec0bd17a0  mov rax, 0x57F4B31E6530
000075aec0bd17aa  call rax
000075aec0bd17ac  movaps xmm15, [rsp]
000075aec0bd17b1  add rsp, 0x30
000075aec0bd17b5  vmovaps xmm0, [rsp]
000075aec0bd17ba  vmovaps xmm1, [rsp+0x10]
000075aec0bd17c0  vmovaps xmm2, [rsp+0x20]
000075aec0bd17c6  vmovaps xmm3, [rsp+0x30]
000075aec0bd17cc  vmovaps xmm4, [rsp+0x40]
000075aec0bd17d2  vmovaps xmm5, [rsp+0x50]
000075aec0bd17d8  vmovaps xmm6, [rsp+0x60]
000075aec0bd17de  vmovaps xmm7, [rsp+0x70]
000075aec0bd17e4  vmovaps xmm8, [rsp+0x80]
000075aec0bd17ed  vmovaps xmm9, [rsp+0x90]
000075aec0bd17f6  vmovaps xmm10, [rsp+0xA0]
000075aec0bd17ff  vmovaps xmm11, [rsp+0xB0]
000075aec0bd1808  vmovaps xmm12, [rsp+0xC0]
000075aec0bd1811  vmovaps xmm13, [rsp+0xD0]
000075aec0bd181a  vmovaps xmm14, [rsp+0xE0]
000075aec0bd1823  add rsp, 0xF0
000075aec0bd182a  pop r11
000075aec0bd182c  pop r10
000075aec0bd182e  pop r9
000075aec0bd1830  pop r8
000075aec0bd1832  pop rsi
000075aec0bd1833  pop rdi
000075aec0bd1834  pop rdx
000075aec0bd1835  pop rcx
000075aec0bd1836  pop rax
000075aec0bd1837  add rsp, 0x08
000075aec0bd183b  jmp 0x000075AEC0BCF923
000075aec0bd1840  call 0x000075AEC09FF430
000075aec0bd1845  jmp 0x000075AEC0BCF930
000075aec0bd184a  sub rsp, 0x08
000075aec0bd184e  push rax
000075aec0bd184f  push rcx
000075aec0bd1850  push rdx
000075aec0bd1851  push rdi
000075aec0bd1852  push rsi
000075aec0bd1853  push r8
000075aec0bd1855  push r9
000075aec0bd1857  push r10
000075aec0bd1859  push r11
000075aec0bd185b  sub rsp, 0xF0
000075aec0bd1862  vmovaps [rsp], xmm0
000075aec0bd1867  vmovaps [rsp+0x10], xmm1
000075aec0bd186d  vmovaps [rsp+0x20], xmm3
000075aec0bd1873  vmovaps [rsp+0x30], xmm4
000075aec0bd1879  vmovaps [rsp+0x40], xmm5
000075aec0bd187f  vmovaps [rsp+0x50], xmm6
000075aec0bd1885  vmovaps [rsp+0x60], xmm7
000075aec0bd188b  vmovaps [rsp+0x70], xmm8
000075aec0bd1891  vmovaps [rsp+0x80], xmm9
000075aec0bd189a  vmovaps [rsp+0x90], xmm10
000075aec0bd18a3  vmovaps [rsp+0xA0], xmm11
000075aec0bd18ac  vmovaps [rsp+0xB0], xmm12
000075aec0bd18b5  vmovaps [rsp+0xC0], xmm13
000075aec0bd18be  vmovaps [rsp+0xD0], xmm14
000075aec0bd18c7  vmovaps [rsp+0xE0], xmm15
000075aec0bd18d0  sub rsp, 0x30
000075aec0bd18d4  movaps [rsp], xmm2
000075aec0bd18d8  movaps [rsp+0x10], xmm1
000075aec0bd18dd  movaps [rsp+0x20], xmm14
000075aec0bd18e3  lea rdi, [rsp]
000075aec0bd18e7  mov esi, 0x00
000075aec0bd18ec  mov rax, 0x57F4B31E6530
000075aec0bd18f6  call rax
000075aec0bd18f8  movaps xmm2, [rsp]
000075aec0bd18fc  add rsp, 0x30
000075aec0bd1900  vmovaps xmm0, [rsp]
000075aec0bd1905  vmovaps xmm1, [rsp+0x10]
000075aec0bd190b  vmovaps xmm3, [rsp+0x20]
000075aec0bd1911  vmovaps xmm4, [rsp+0x30]
000075aec0bd1917  vmovaps xmm5, [rsp+0x40]
000075aec0bd191d  vmovaps xmm6, [rsp+0x50]
000075aec0bd1923  vmovaps xmm7, [rsp+0x60]
000075aec0bd1929  vmovaps xmm8, [rsp+0x70]
000075aec0bd192f  vmovaps xmm9, [rsp+0x80]
000075aec0bd1938  vmovaps xmm10, [rsp+0x90]
000075aec0bd1941  vmovaps xmm11, [rsp+0xA0]
000075aec0bd194a  vmovaps xmm12, [rsp+0xB0]
000075aec0bd1953  vmovaps xmm13, [rsp+0xC0]
000075aec0bd195c  vmovaps xmm14, [rsp+0xD0]
000075aec0bd1965  vmovaps xmm15, [rsp+0xE0]
000075aec0bd196e  add rsp, 0xF0
000075aec0bd1975  pop r11
000075aec0bd1977  pop r10
000075aec0bd1979  pop r9
000075aec0bd197b  pop r8
000075aec0bd197d  pop rsi
000075aec0bd197e  pop rdi
000075aec0bd197f  pop rdx
000075aec0bd1980  pop rcx
000075aec0bd1981  pop rax
000075aec0bd1982  add rsp, 0x08
000075aec0bd1986  jmp 0x000075AEC0BCF96D
000075aec0bd198b  sub rsp, 0x08
000075aec0bd198f  push rax
000075aec0bd1990  push rcx
000075aec0bd1991  push rdx
000075aec0bd1992  push rdi
000075aec0bd1993  push rsi
000075aec0bd1994  push r8
000075aec0bd1996  push r9
000075aec0bd1998  push r10
000075aec0bd199a  push r11
000075aec0bd199c  sub rsp, 0xF0
000075aec0bd19a3  vmovaps [rsp], xmm0
000075aec0bd19a8  vmovaps [rsp+0x10], xmm1
000075aec0bd19ae  vmovaps [rsp+0x20], xmm2
000075aec0bd19b4  vmovaps [rsp+0x30], xmm3
000075aec0bd19ba  vmovaps [rsp+0x40], xmm4
000075aec0bd19c0  vmovaps [rsp+0x50], xmm5
000075aec0bd19c6  vmovaps [rsp+0x60], xmm6
000075aec0bd19cc  vmovaps [rsp+0x70], xmm7
000075aec0bd19d2  vmovaps [rsp+0x80], xmm8
000075aec0bd19db  vmovaps [rsp+0x90], xmm9
000075aec0bd19e4  vmovaps [rsp+0xA0], xmm10
000075aec0bd19ed  vmovaps [rsp+0xB0], xmm11
000075aec0bd19f6  vmovaps [rsp+0xC0], xmm12
000075aec0bd19ff  vmovaps [rsp+0xD0], xmm13
000075aec0bd1a08  vmovaps [rsp+0xE0], xmm14
000075aec0bd1a11  sub rsp, 0x30
000075aec0bd1a15  movaps [rsp], xmm15
000075aec0bd1a1a  movaps [rsp+0x10], xmm14
000075aec0bd1a20  movaps [rsp+0x20], xmm1
000075aec0bd1a25  lea rdi, [rsp]
000075aec0bd1a29  mov esi, 0x00
000075aec0bd1a2e  mov rax, 0x57F4B31E6530
000075aec0bd1a38  call rax
000075aec0bd1a3a  movaps xmm15, [rsp]
000075aec0bd1a3f  add rsp, 0x30
000075aec0bd1a43  vmovaps xmm0, [rsp]
000075aec0bd1a48  vmovaps xmm1, [rsp+0x10]
000075aec0bd1a4e  vmovaps xmm2, [rsp+0x20]
000075aec0bd1a54  vmovaps xmm3, [rsp+0x30]
000075aec0bd1a5a  vmovaps xmm4, [rsp+0x40]
000075aec0bd1a60  vmovaps xmm5, [rsp+0x50]
000075aec0bd1a66  vmovaps xmm6, [rsp+0x60]
000075aec0bd1a6c  vmovaps xmm7, [rsp+0x70]
000075aec0bd1a72  vmovaps xmm8, [rsp+0x80]
000075aec0bd1a7b  vmovaps xmm9, [rsp+0x90]
000075aec0bd1a84  vmovaps xmm10, [rsp+0xA0]
000075aec0bd1a8d  vmovaps xmm11, [rsp+0xB0]
000075aec0bd1a96  vmovaps xmm12, [rsp+0xC0]
000075aec0bd1a9f  vmovaps xmm13, [rsp+0xD0]
000075aec0bd1aa8  vmovaps xmm14, [rsp+0xE0]
000075aec0bd1ab1  add rsp, 0xF0
000075aec0bd1ab8  pop r11
000075aec0bd1aba  pop r10
000075aec0bd1abc  pop r9
000075aec0bd1abe  pop r8
000075aec0bd1ac0  pop rsi
000075aec0bd1ac1  pop rdi
000075aec0bd1ac2  pop rdx
000075aec0bd1ac3  pop rcx
000075aec0bd1ac4  pop rax
000075aec0bd1ac5  add rsp, 0x08
000075aec0bd1ac9  jmp 0x000075AEC0BCF9E7
000075aec0bd1ace  call 0x000075AEC09FF430
000075aec0bd1ad3  jmp 0x000075AEC0BCF9F4
000075aec0bd1ad8  sub rsp, 0x08
000075aec0bd1adc  push rax
000075aec0bd1add  push rcx
000075aec0bd1ade  push rdx
000075aec0bd1adf  push rdi
000075aec0bd1ae0  push rsi
000075aec0bd1ae1  push r8
000075aec0bd1ae3  push r9
000075aec0bd1ae5  push r10
000075aec0bd1ae7  push r11
000075aec0bd1ae9  sub rsp, 0xF0
000075aec0bd1af0  vmovaps [rsp], xmm0
000075aec0bd1af5  vmovaps [rsp+0x10], xmm1
000075aec0bd1afb  vmovaps [rsp+0x20], xmm2
000075aec0bd1b01  vmovaps [rsp+0x30], xmm3
000075aec0bd1b07  vmovaps [rsp+0x40], xmm4
000075aec0bd1b0d  vmovaps [rsp+0x50], xmm5
000075aec0bd1b13  vmovaps [rsp+0x60], xmm6
000075aec0bd1b19  vmovaps [rsp+0x70], xmm7
000075aec0bd1b1f  vmovaps [rsp+0x80], xmm8
000075aec0bd1b28  vmovaps [rsp+0x90], xmm9
000075aec0bd1b31  vmovaps [rsp+0xA0], xmm10
000075aec0bd1b3a  vmovaps [rsp+0xB0], xmm11
000075aec0bd1b43  vmovaps [rsp+0xC0], xmm12
000075aec0bd1b4c  vmovaps [rsp+0xD0], xmm13
000075aec0bd1b55  vmovaps [rsp+0xE0], xmm15
000075aec0bd1b5e  sub rsp, 0x30
000075aec0bd1b62  movaps [rsp], xmm14
000075aec0bd1b67  movaps [rsp+0x10], xmm13
000075aec0bd1b6d  movaps [rsp+0x20], xmm1
000075aec0bd1b72  lea rdi, [rsp]
000075aec0bd1b76  mov esi, 0x00
000075aec0bd1b7b  mov rax, 0x57F4B31E6530
000075aec0bd1b85  call rax
000075aec0bd1b87  movaps xmm14, [rsp]
000075aec0bd1b8c  add rsp, 0x30
000075aec0bd1b90  vmovaps xmm0, [rsp]
000075aec0bd1b95  vmovaps xmm1, [rsp+0x10]
000075aec0bd1b9b  vmovaps xmm2, [rsp+0x20]
000075aec0bd1ba1  vmovaps xmm3, [rsp+0x30]
000075aec0bd1ba7  vmovaps xmm4, [rsp+0x40]
000075aec0bd1bad  vmovaps xmm5, [rsp+0x50]
000075aec0bd1bb3  vmovaps xmm6, [rsp+0x60]
000075aec0bd1bb9  vmovaps xmm7, [rsp+0x70]
000075aec0bd1bbf  vmovaps xmm8, [rsp+0x80]
000075aec0bd1bc8  vmovaps xmm9, [rsp+0x90]
000075aec0bd1bd1  vmovaps xmm10, [rsp+0xA0]
000075aec0bd1bda  vmovaps xmm11, [rsp+0xB0]
000075aec0bd1be3  vmovaps xmm12, [rsp+0xC0]
000075aec0bd1bec  vmovaps xmm13, [rsp+0xD0]
000075aec0bd1bf5  vmovaps xmm15, [rsp+0xE0]
000075aec0bd1bfe  add rsp, 0xF0
000075aec0bd1c05  pop r11
000075aec0bd1c07  pop r10
000075aec0bd1c09  pop r9
000075aec0bd1c0b  pop r8
000075aec0bd1c0d  pop rsi
000075aec0bd1c0e  pop rdi
000075aec0bd1c0f  pop rdx
000075aec0bd1c10  pop rcx
000075aec0bd1c11  pop rax
000075aec0bd1c12  add rsp, 0x08
000075aec0bd1c16  jmp 0x000075AEC0BCFAAF
000075aec0bd1c1b  sub rsp, 0x08
000075aec0bd1c1f  push rax
000075aec0bd1c20  push rcx
000075aec0bd1c21  push rdx
000075aec0bd1c22  push rdi
000075aec0bd1c23  push rsi
000075aec0bd1c24  push r8
000075aec0bd1c26  push r9
000075aec0bd1c28  push r10
000075aec0bd1c2a  push r11
000075aec0bd1c2c  sub rsp, 0xF0
000075aec0bd1c33  vmovaps [rsp], xmm0
000075aec0bd1c38  vmovaps [rsp+0x10], xmm1
000075aec0bd1c3e  vmovaps [rsp+0x20], xmm2
000075aec0bd1c44  vmovaps [rsp+0x30], xmm3
000075aec0bd1c4a  vmovaps [rsp+0x40], xmm4
000075aec0bd1c50  vmovaps [rsp+0x50], xmm5
000075aec0bd1c56  vmovaps [rsp+0x60], xmm6
000075aec0bd1c5c  vmovaps [rsp+0x70], xmm7
000075aec0bd1c62  vmovaps [rsp+0x80], xmm8
000075aec0bd1c6b  vmovaps [rsp+0x90], xmm9
000075aec0bd1c74  vmovaps [rsp+0xA0], xmm10
000075aec0bd1c7d  vmovaps [rsp+0xB0], xmm11
000075aec0bd1c86  vmovaps [rsp+0xC0], xmm12
000075aec0bd1c8f  vmovaps [rsp+0xD0], xmm13
000075aec0bd1c98  vmovaps [rsp+0xE0], xmm14
000075aec0bd1ca1  sub rsp, 0x30
000075aec0bd1ca5  movaps [rsp], xmm15
000075aec0bd1caa  movaps [rsp+0x10], xmm13
000075aec0bd1cb0  movaps [rsp+0x20], xmm1
000075aec0bd1cb5  lea rdi, [rsp]
000075aec0bd1cb9  mov esi, 0x00
000075aec0bd1cbe  mov rax, 0x57F4B31E6530
000075aec0bd1cc8  call rax
000075aec0bd1cca  movaps xmm15, [rsp]
000075aec0bd1ccf  add rsp, 0x30
000075aec0bd1cd3  vmovaps xmm0, [rsp]
000075aec0bd1cd8  vmovaps xmm1, [rsp+0x10]
000075aec0bd1cde  vmovaps xmm2, [rsp+0x20]
000075aec0bd1ce4  vmovaps xmm3, [rsp+0x30]
000075aec0bd1cea  vmovaps xmm4, [rsp+0x40]
000075aec0bd1cf0  vmovaps xmm5, [rsp+0x50]
000075aec0bd1cf6  vmovaps xmm6, [rsp+0x60]
000075aec0bd1cfc  vmovaps xmm7, [rsp+0x70]
000075aec0bd1d02  vmovaps xmm8, [rsp+0x80]
000075aec0bd1d0b  vmovaps xmm9, [rsp+0x90]
000075aec0bd1d14  vmovaps xmm10, [rsp+0xA0]
000075aec0bd1d1d  vmovaps xmm11, [rsp+0xB0]
000075aec0bd1d26  vmovaps xmm12, [rsp+0xC0]
000075aec0bd1d2f  vmovaps xmm13, [rsp+0xD0]
000075aec0bd1d38  vmovaps xmm14, [rsp+0xE0]
000075aec0bd1d41  add rsp, 0xF0
000075aec0bd1d48  pop r11
000075aec0bd1d4a  pop r10
000075aec0bd1d4c  pop r9
000075aec0bd1d4e  pop r8
000075aec0bd1d50  pop rsi
000075aec0bd1d51  pop rdi
000075aec0bd1d52  pop rdx
000075aec0bd1d53  pop rcx
000075aec0bd1d54  pop rax
000075aec0bd1d55  add rsp, 0x08
000075aec0bd1d59  jmp 0x000075AEC0BCFAEB
000075aec0bd1d5e  call 0x000075AEC09FF430
000075aec0bd1d63  jmp 0x000075AEC0BCFAF8
000075aec0bd1d68  sub rsp, 0x08
000075aec0bd1d6c  push rax
000075aec0bd1d6d  push rcx
000075aec0bd1d6e  push rdx
000075aec0bd1d6f  push rdi
000075aec0bd1d70  push rsi
000075aec0bd1d71  push r8
000075aec0bd1d73  push r9
000075aec0bd1d75  push r10
000075aec0bd1d77  push r11
000075aec0bd1d79  sub rsp, 0xF0
000075aec0bd1d80  vmovaps [rsp], xmm0
000075aec0bd1d85  vmovaps [rsp+0x10], xmm1
000075aec0bd1d8b  vmovaps [rsp+0x20], xmm2
000075aec0bd1d91  vmovaps [rsp+0x30], xmm3
000075aec0bd1d97  vmovaps [rsp+0x40], xmm4
000075aec0bd1d9d  vmovaps [rsp+0x50], xmm5
000075aec0bd1da3  vmovaps [rsp+0x60], xmm6
000075aec0bd1da9  vmovaps [rsp+0x70], xmm7
000075aec0bd1daf  vmovaps [rsp+0x80], xmm8
000075aec0bd1db8  vmovaps [rsp+0x90], xmm9
000075aec0bd1dc1  vmovaps [rsp+0xA0], xmm10
000075aec0bd1dca  vmovaps [rsp+0xB0], xmm11
000075aec0bd1dd3  vmovaps [rsp+0xC0], xmm12
000075aec0bd1ddc  vmovaps [rsp+0xD0], xmm13
000075aec0bd1de5  vmovaps [rsp+0xE0], xmm15
000075aec0bd1dee  sub rsp, 0x30
000075aec0bd1df2  movaps [rsp], xmm14
000075aec0bd1df7  movaps [rsp+0x10], xmm13
000075aec0bd1dfd  movaps [rsp+0x20], xmm2
000075aec0bd1e02  lea rdi, [rsp]
000075aec0bd1e06  mov esi, 0x00
000075aec0bd1e0b  mov rax, 0x57F4B31E6530
000075aec0bd1e15  call rax
000075aec0bd1e17  movaps xmm14, [rsp]
000075aec0bd1e1c  add rsp, 0x30
000075aec0bd1e20  vmovaps xmm0, [rsp]
000075aec0bd1e25  vmovaps xmm1, [rsp+0x10]
000075aec0bd1e2b  vmovaps xmm2, [rsp+0x20]
000075aec0bd1e31  vmovaps xmm3, [rsp+0x30]
000075aec0bd1e37  vmovaps xmm4, [rsp+0x40]
000075aec0bd1e3d  vmovaps xmm5, [rsp+0x50]
000075aec0bd1e43  vmovaps xmm6, [rsp+0x60]
000075aec0bd1e49  vmovaps xmm7, [rsp+0x70]
000075aec0bd1e4f  vmovaps xmm8, [rsp+0x80]
000075aec0bd1e58  vmovaps xmm9, [rsp+0x90]
000075aec0bd1e61  vmovaps xmm10, [rsp+0xA0]
000075aec0bd1e6a  vmovaps xmm11, [rsp+0xB0]
000075aec0bd1e73  vmovaps xmm12, [rsp+0xC0]
000075aec0bd1e7c  vmovaps xmm13, [rsp+0xD0]
000075aec0bd1e85  vmovaps xmm15, [rsp+0xE0]
000075aec0bd1e8e  add rsp, 0xF0
000075aec0bd1e95  pop r11
000075aec0bd1e97  pop r10
000075aec0bd1e99  pop r9
000075aec0bd1e9b  pop r8
000075aec0bd1e9d  pop rsi
000075aec0bd1e9e  pop rdi
000075aec0bd1e9f  pop rdx
000075aec0bd1ea0  pop rcx
000075aec0bd1ea1  pop rax
000075aec0bd1ea2  add rsp, 0x08
000075aec0bd1ea6  jmp 0x000075AEC0BCFB24
000075aec0bd1eab  sub rsp, 0x08
000075aec0bd1eaf  push rax
000075aec0bd1eb0  push rcx
000075aec0bd1eb1  push rdx
000075aec0bd1eb2  push rdi
000075aec0bd1eb3  push rsi
000075aec0bd1eb4  push r8
000075aec0bd1eb6  push r9
000075aec0bd1eb8  push r10
000075aec0bd1eba  push r11
000075aec0bd1ebc  sub rsp, 0xF0
000075aec0bd1ec3  vmovaps [rsp], xmm0
000075aec0bd1ec8  vmovaps [rsp+0x10], xmm2
000075aec0bd1ece  vmovaps [rsp+0x20], xmm3
000075aec0bd1ed4  vmovaps [rsp+0x30], xmm4
000075aec0bd1eda  vmovaps [rsp+0x40], xmm5
000075aec0bd1ee0  vmovaps [rsp+0x50], xmm6
000075aec0bd1ee6  vmovaps [rsp+0x60], xmm7
000075aec0bd1eec  vmovaps [rsp+0x70], xmm8
000075aec0bd1ef2  vmovaps [rsp+0x80], xmm9
000075aec0bd1efb  vmovaps [rsp+0x90], xmm10
000075aec0bd1f04  vmovaps [rsp+0xA0], xmm11
000075aec0bd1f0d  vmovaps [rsp+0xB0], xmm12
000075aec0bd1f16  vmovaps [rsp+0xC0], xmm13
000075aec0bd1f1f  vmovaps [rsp+0xD0], xmm14
000075aec0bd1f28  vmovaps [rsp+0xE0], xmm15
000075aec0bd1f31  sub rsp, 0x30
000075aec0bd1f35  movaps [rsp], xmm1
000075aec0bd1f39  movaps [rsp+0x10], xmm13
000075aec0bd1f3f  movaps [rsp+0x20], xmm2
000075aec0bd1f44  lea rdi, [rsp]
000075aec0bd1f48  mov esi, 0x00
000075aec0bd1f4d  mov rax, 0x57F4B31E6530
000075aec0bd1f57  call rax
000075aec0bd1f59  movaps xmm1, [rsp]
000075aec0bd1f5d  add rsp, 0x30
000075aec0bd1f61  vmovaps xmm0, [rsp]
000075aec0bd1f66  vmovaps xmm2, [rsp+0x10]
000075aec0bd1f6c  vmovaps xmm3, [rsp+0x20]
000075aec0bd1f72  vmovaps xmm4, [rsp+0x30]
000075aec0bd1f78  vmovaps xmm5, [rsp+0x40]
000075aec0bd1f7e  vmovaps xmm6, [rsp+0x50]
000075aec0bd1f84  vmovaps xmm7, [rsp+0x60]
000075aec0bd1f8a  vmovaps xmm8, [rsp+0x70]
000075aec0bd1f90  vmovaps xmm9, [rsp+0x80]
000075aec0bd1f99  vmovaps xmm10, [rsp+0x90]
000075aec0bd1fa2  vmovaps xmm11, [rsp+0xA0]
000075aec0bd1fab  vmovaps xmm12, [rsp+0xB0]
000075aec0bd1fb4  vmovaps xmm13, [rsp+0xC0]
000075aec0bd1fbd  vmovaps xmm14, [rsp+0xD0]
000075aec0bd1fc6  vmovaps xmm15, [rsp+0xE0]
000075aec0bd1fcf  add rsp, 0xF0
000075aec0bd1fd6  pop r11
000075aec0bd1fd8  pop r10
000075aec0bd1fda  pop r9
000075aec0bd1fdc  pop r8
000075aec0bd1fde  pop rsi
000075aec0bd1fdf  pop rdi
000075aec0bd1fe0  pop rdx
000075aec0bd1fe1  pop rcx
000075aec0bd1fe2  pop rax
000075aec0bd1fe3  add rsp, 0x08
000075aec0bd1fe7  jmp 0x000075AEC0BCFB52
000075aec0bd1fec  sub rsp, 0x08
000075aec0bd1ff0  push rax
000075aec0bd1ff1  push rcx
000075aec0bd1ff2  push rdx
000075aec0bd1ff3  push rdi
000075aec0bd1ff4  push rsi
000075aec0bd1ff5  push r8
000075aec0bd1ff7  push r9
000075aec0bd1ff9  push r10
000075aec0bd1ffb  push r11
000075aec0bd1ffd  sub rsp, 0xF0
000075aec0bd2004  vmovaps [rsp], xmm0
000075aec0bd2009  vmovaps [rsp+0x10], xmm1
000075aec0bd200f  vmovaps [rsp+0x20], xmm3
000075aec0bd2015  vmovaps [rsp+0x30], xmm4
000075aec0bd201b  vmovaps [rsp+0x40], xmm5
000075aec0bd2021  vmovaps [rsp+0x50], xmm6
000075aec0bd2027  vmovaps [rsp+0x60], xmm7
000075aec0bd202d  vmovaps [rsp+0x70], xmm8
000075aec0bd2033  vmovaps [rsp+0x80], xmm9
000075aec0bd203c  vmovaps [rsp+0x90], xmm10
000075aec0bd2045  vmovaps [rsp+0xA0], xmm11
000075aec0bd204e  vmovaps [rsp+0xB0], xmm12
000075aec0bd2057  vmovaps [rsp+0xC0], xmm13
000075aec0bd2060  vmovaps [rsp+0xD0], xmm14
000075aec0bd2069  vmovaps [rsp+0xE0], xmm15
000075aec0bd2072  sub rsp, 0x30
000075aec0bd2076  movaps [rsp], xmm2
000075aec0bd207a  movaps [rsp+0x10], xmm1
000075aec0bd207f  movaps [rsp+0x20], xmm13
000075aec0bd2085  lea rdi, [rsp]
000075aec0bd2089  mov esi, 0x00
000075aec0bd208e  mov rax, 0x57F4B31E6530
000075aec0bd2098  call rax
000075aec0bd209a  movaps xmm2, [rsp]
000075aec0bd209e  add rsp, 0x30
000075aec0bd20a2  vmovaps xmm0, [rsp]
000075aec0bd20a7  vmovaps xmm1, [rsp+0x10]
000075aec0bd20ad  vmovaps xmm3, [rsp+0x20]
000075aec0bd20b3  vmovaps xmm4, [rsp+0x30]
000075aec0bd20b9  vmovaps xmm5, [rsp+0x40]
000075aec0bd20bf  vmovaps xmm6, [rsp+0x50]
000075aec0bd20c5  vmovaps xmm7, [rsp+0x60]
000075aec0bd20cb  vmovaps xmm8, [rsp+0x70]
000075aec0bd20d1  vmovaps xmm9, [rsp+0x80]
000075aec0bd20da  vmovaps xmm10, [rsp+0x90]
000075aec0bd20e3  vmovaps xmm11, [rsp+0xA0]
000075aec0bd20ec  vmovaps xmm12, [rsp+0xB0]
000075aec0bd20f5  vmovaps xmm13, [rsp+0xC0]
000075aec0bd20fe  vmovaps xmm14, [rsp+0xD0]
000075aec0bd2107  vmovaps xmm15, [rsp+0xE0]
000075aec0bd2110  add rsp, 0xF0
000075aec0bd2117  pop r11
000075aec0bd2119  pop r10
000075aec0bd211b  pop r9
000075aec0bd211d  pop r8
000075aec0bd211f  pop rsi
000075aec0bd2120  pop rdi
000075aec0bd2121  pop rdx
000075aec0bd2122  pop rcx
000075aec0bd2123  pop rax
000075aec0bd2124  add rsp, 0x08
000075aec0bd2128  jmp 0x000075AEC0BCFBAB
000075aec0bd212d  call 0x000075AEC09FF430
000075aec0bd2132  jmp 0x000075AEC0BCFBB8
000075aec0bd2137  sub rsp, 0x08
000075aec0bd213b  push rax
000075aec0bd213c  push rcx
000075aec0bd213d  push rdx
000075aec0bd213e  push rdi
000075aec0bd213f  push rsi
000075aec0bd2140  push r8
000075aec0bd2142  push r9
000075aec0bd2144  push r10
000075aec0bd2146  push r11
000075aec0bd2148  sub rsp, 0xF0
000075aec0bd214f  vmovaps [rsp], xmm0
000075aec0bd2154  vmovaps [rsp+0x10], xmm1
000075aec0bd215a  vmovaps [rsp+0x20], xmm2
000075aec0bd2160  vmovaps [rsp+0x30], xmm3
000075aec0bd2166  vmovaps [rsp+0x40], xmm4
000075aec0bd216c  vmovaps [rsp+0x50], xmm5
000075aec0bd2172  vmovaps [rsp+0x60], xmm6
000075aec0bd2178  vmovaps [rsp+0x70], xmm7
000075aec0bd217e  vmovaps [rsp+0x80], xmm8
000075aec0bd2187  vmovaps [rsp+0x90], xmm9
000075aec0bd2190  vmovaps [rsp+0xA0], xmm10
000075aec0bd2199  vmovaps [rsp+0xB0], xmm11
000075aec0bd21a2  vmovaps [rsp+0xC0], xmm12
000075aec0bd21ab  vmovaps [rsp+0xD0], xmm13
000075aec0bd21b4  vmovaps [rsp+0xE0], xmm14
000075aec0bd21bd  sub rsp, 0x30
000075aec0bd21c1  movaps [rsp], xmm15
000075aec0bd21c6  movaps [rsp+0x10], xmm13
000075aec0bd21cc  movaps [rsp+0x20], xmm1
000075aec0bd21d1  lea rdi, [rsp]
000075aec0bd21d5  mov esi, 0x00
000075aec0bd21da  mov rax, 0x57F4B31E6530
000075aec0bd21e4  call rax
000075aec0bd21e6  movaps xmm15, [rsp]
000075aec0bd21eb  add rsp, 0x30
000075aec0bd21ef  vmovaps xmm0, [rsp]
000075aec0bd21f4  vmovaps xmm1, [rsp+0x10]
000075aec0bd21fa  vmovaps xmm2, [rsp+0x20]
000075aec0bd2200  vmovaps xmm3, [rsp+0x30]
000075aec0bd2206  vmovaps xmm4, [rsp+0x40]
000075aec0bd220c  vmovaps xmm5, [rsp+0x50]
000075aec0bd2212  vmovaps xmm6, [rsp+0x60]
000075aec0bd2218  vmovaps xmm7, [rsp+0x70]
000075aec0bd221e  vmovaps xmm8, [rsp+0x80]
000075aec0bd2227  vmovaps xmm9, [rsp+0x90]
000075aec0bd2230  vmovaps xmm10, [rsp+0xA0]
000075aec0bd2239  vmovaps xmm11, [rsp+0xB0]
000075aec0bd2242  vmovaps xmm12, [rsp+0xC0]
000075aec0bd224b  vmovaps xmm13, [rsp+0xD0]
000075aec0bd2254  vmovaps xmm14, [rsp+0xE0]
000075aec0bd225d  add rsp, 0xF0
000075aec0bd2264  pop r11
000075aec0bd2266  pop r10
000075aec0bd2268  pop r9
000075aec0bd226a  pop r8
000075aec0bd226c  pop rsi
000075aec0bd226d  pop rdi
000075aec0bd226e  pop rdx
000075aec0bd226f  pop rcx
000075aec0bd2270  pop rax
000075aec0bd2271  add rsp, 0x08
000075aec0bd2275  jmp 0x000075AEC0BCFBF7
000075aec0bd227a  sub rsp, 0x08
000075aec0bd227e  push rax
000075aec0bd227f  push rcx
000075aec0bd2280  push rdx
000075aec0bd2281  push rdi
000075aec0bd2282  push rsi
000075aec0bd2283  push r8
000075aec0bd2285  push r9
000075aec0bd2287  push r10
000075aec0bd2289  push r11
000075aec0bd228b  sub rsp, 0xF0
000075aec0bd2292  vmovaps [rsp], xmm0
000075aec0bd2297  vmovaps [rsp+0x10], xmm1
000075aec0bd229d  vmovaps [rsp+0x20], xmm2
000075aec0bd22a3  vmovaps [rsp+0x30], xmm3
000075aec0bd22a9  vmovaps [rsp+0x40], xmm4
000075aec0bd22af  vmovaps [rsp+0x50], xmm5
000075aec0bd22b5  vmovaps [rsp+0x60], xmm6
000075aec0bd22bb  vmovaps [rsp+0x70], xmm7
000075aec0bd22c1  vmovaps [rsp+0x80], xmm8
000075aec0bd22ca  vmovaps [rsp+0x90], xmm9
000075aec0bd22d3  vmovaps [rsp+0xA0], xmm10
000075aec0bd22dc  vmovaps [rsp+0xB0], xmm11
000075aec0bd22e5  vmovaps [rsp+0xC0], xmm12
000075aec0bd22ee  vmovaps [rsp+0xD0], xmm13
000075aec0bd22f7  vmovaps [rsp+0xE0], xmm15
000075aec0bd2300  sub rsp, 0x30
000075aec0bd2304  movaps [rsp], xmm14
000075aec0bd2309  movaps [rsp+0x10], xmm11
000075aec0bd230f  movaps [rsp+0x20], xmm1
000075aec0bd2314  lea rdi, [rsp]
000075aec0bd2318  mov esi, 0x00
000075aec0bd231d  mov rax, 0x57F4B31E6530
000075aec0bd2327  call rax
000075aec0bd2329  movaps xmm14, [rsp]
000075aec0bd232e  add rsp, 0x30
000075aec0bd2332  vmovaps xmm0, [rsp]
000075aec0bd2337  vmovaps xmm1, [rsp+0x10]
000075aec0bd233d  vmovaps xmm2, [rsp+0x20]
000075aec0bd2343  vmovaps xmm3, [rsp+0x30]
000075aec0bd2349  vmovaps xmm4, [rsp+0x40]
000075aec0bd234f  vmovaps xmm5, [rsp+0x50]
000075aec0bd2355  vmovaps xmm6, [rsp+0x60]
000075aec0bd235b  vmovaps xmm7, [rsp+0x70]
000075aec0bd2361  vmovaps xmm8, [rsp+0x80]
000075aec0bd236a  vmovaps xmm9, [rsp+0x90]
000075aec0bd2373  vmovaps xmm10, [rsp+0xA0]
000075aec0bd237c  vmovaps xmm11, [rsp+0xB0]
000075aec0bd2385  vmovaps xmm12, [rsp+0xC0]
000075aec0bd238e  vmovaps xmm13, [rsp+0xD0]
000075aec0bd2397  vmovaps xmm15, [rsp+0xE0]
000075aec0bd23a0  add rsp, 0xF0
000075aec0bd23a7  pop r11
000075aec0bd23a9  pop r10
000075aec0bd23ab  pop r9
000075aec0bd23ad  pop r8
000075aec0bd23af  pop rsi
000075aec0bd23b0  pop rdi
000075aec0bd23b1  pop rdx
000075aec0bd23b2  pop rcx
000075aec0bd23b3  pop rax
000075aec0bd23b4  add rsp, 0x08
000075aec0bd23b8  jmp 0x000075AEC0BCFC21
000075aec0bd23bd  sub rsp, 0x08
000075aec0bd23c1  push rax
000075aec0bd23c2  push rcx
000075aec0bd23c3  push rdx
000075aec0bd23c4  push rdi
000075aec0bd23c5  push rsi
000075aec0bd23c6  push r8
000075aec0bd23c8  push r9
000075aec0bd23ca  push r10
000075aec0bd23cc  push r11
000075aec0bd23ce  sub rsp, 0xF0
000075aec0bd23d5  vmovaps [rsp], xmm0
000075aec0bd23da  vmovaps [rsp+0x10], xmm1
000075aec0bd23e0  vmovaps [rsp+0x20], xmm2
000075aec0bd23e6  vmovaps [rsp+0x30], xmm3
000075aec0bd23ec  vmovaps [rsp+0x40], xmm4
000075aec0bd23f2  vmovaps [rsp+0x50], xmm5
000075aec0bd23f8  vmovaps [rsp+0x60], xmm6
000075aec0bd23fe  vmovaps [rsp+0x70], xmm7
000075aec0bd2404  vmovaps [rsp+0x80], xmm8
000075aec0bd240d  vmovaps [rsp+0x90], xmm9
000075aec0bd2416  vmovaps [rsp+0xA0], xmm10
000075aec0bd241f  vmovaps [rsp+0xB0], xmm11
000075aec0bd2428  vmovaps [rsp+0xC0], xmm12
000075aec0bd2431  vmovaps [rsp+0xD0], xmm14
000075aec0bd243a  vmovaps [rsp+0xE0], xmm15
000075aec0bd2443  sub rsp, 0x30
000075aec0bd2447  movaps [rsp], xmm13
000075aec0bd244c  movaps [rsp+0x10], xmm11
000075aec0bd2452  movaps [rsp+0x20], xmm1
000075aec0bd2457  lea rdi, [rsp]
000075aec0bd245b  mov esi, 0x00
000075aec0bd2460  mov rax, 0x57F4B31E6530
000075aec0bd246a  call rax
000075aec0bd246c  movaps xmm13, [rsp]
000075aec0bd2471  add rsp, 0x30
000075aec0bd2475  vmovaps xmm0, [rsp]
000075aec0bd247a  vmovaps xmm1, [rsp+0x10]
000075aec0bd2480  vmovaps xmm2, [rsp+0x20]
000075aec0bd2486  vmovaps xmm3, [rsp+0x30]
000075aec0bd248c  vmovaps xmm4, [rsp+0x40]
000075aec0bd2492  vmovaps xmm5, [rsp+0x50]
000075aec0bd2498  vmovaps xmm6, [rsp+0x60]
000075aec0bd249e  vmovaps xmm7, [rsp+0x70]
000075aec0bd24a4  vmovaps xmm8, [rsp+0x80]
000075aec0bd24ad  vmovaps xmm9, [rsp+0x90]
000075aec0bd24b6  vmovaps xmm10, [rsp+0xA0]
000075aec0bd24bf  vmovaps xmm11, [rsp+0xB0]
000075aec0bd24c8  vmovaps xmm12, [rsp+0xC0]
000075aec0bd24d1  vmovaps xmm14, [rsp+0xD0]
000075aec0bd24da  vmovaps xmm15, [rsp+0xE0]
000075aec0bd24e3  add rsp, 0xF0
000075aec0bd24ea  pop r11
000075aec0bd24ec  pop r10
000075aec0bd24ee  pop r9
000075aec0bd24f0  pop r8
000075aec0bd24f2  pop rsi
000075aec0bd24f3  pop rdi
000075aec0bd24f4  pop rdx
000075aec0bd24f5  pop rcx
000075aec0bd24f6  pop rax
000075aec0bd24f7  add rsp, 0x08
000075aec0bd24fb  jmp 0x000075AEC0BCFC76
000075aec0bd2500  call 0x000075AEC09FF430
000075aec0bd2505  jmp 0x000075AEC0BCFC83
000075aec0bd250a  sub rsp, 0x08
000075aec0bd250e  push rax
000075aec0bd250f  push rcx
000075aec0bd2510  push rdx
000075aec0bd2511  push rdi
000075aec0bd2512  push rsi
000075aec0bd2513  push r8
000075aec0bd2515  push r9
000075aec0bd2517  push r10
000075aec0bd2519  push r11
000075aec0bd251b  sub rsp, 0xF0
000075aec0bd2522  vmovaps [rsp], xmm0
000075aec0bd2527  vmovaps [rsp+0x10], xmm1
000075aec0bd252d  vmovaps [rsp+0x20], xmm2
000075aec0bd2533  vmovaps [rsp+0x30], xmm3
000075aec0bd2539  vmovaps [rsp+0x40], xmm4
000075aec0bd253f  vmovaps [rsp+0x50], xmm5
000075aec0bd2545  vmovaps [rsp+0x60], xmm6
000075aec0bd254b  vmovaps [rsp+0x70], xmm7
000075aec0bd2551  vmovaps [rsp+0x80], xmm8
000075aec0bd255a  vmovaps [rsp+0x90], xmm9
000075aec0bd2563  vmovaps [rsp+0xA0], xmm10
000075aec0bd256c  vmovaps [rsp+0xB0], xmm11
000075aec0bd2575  vmovaps [rsp+0xC0], xmm12
000075aec0bd257e  vmovaps [rsp+0xD0], xmm13
000075aec0bd2587  vmovaps [rsp+0xE0], xmm14
000075aec0bd2590  sub rsp, 0x30
000075aec0bd2594  movaps [rsp], xmm15
000075aec0bd2599  movaps [rsp+0x10], xmm11
000075aec0bd259f  movaps [rsp+0x20], xmm1
000075aec0bd25a4  lea rdi, [rsp]
000075aec0bd25a8  mov esi, 0x00
000075aec0bd25ad  mov rax, 0x57F4B31E6530
000075aec0bd25b7  call rax
000075aec0bd25b9  movaps xmm15, [rsp]
000075aec0bd25be  add rsp, 0x30
000075aec0bd25c2  vmovaps xmm0, [rsp]
000075aec0bd25c7  vmovaps xmm1, [rsp+0x10]
000075aec0bd25cd  vmovaps xmm2, [rsp+0x20]
000075aec0bd25d3  vmovaps xmm3, [rsp+0x30]
000075aec0bd25d9  vmovaps xmm4, [rsp+0x40]
000075aec0bd25df  vmovaps xmm5, [rsp+0x50]
000075aec0bd25e5  vmovaps xmm6, [rsp+0x60]
000075aec0bd25eb  vmovaps xmm7, [rsp+0x70]
000075aec0bd25f1  vmovaps xmm8, [rsp+0x80]
000075aec0bd25fa  vmovaps xmm9, [rsp+0x90]
000075aec0bd2603  vmovaps xmm10, [rsp+0xA0]
000075aec0bd260c  vmovaps xmm11, [rsp+0xB0]
000075aec0bd2615  vmovaps xmm12, [rsp+0xC0]
000075aec0bd261e  vmovaps xmm13, [rsp+0xD0]
000075aec0bd2627  vmovaps xmm14, [rsp+0xE0]
000075aec0bd2630  add rsp, 0xF0
000075aec0bd2637  pop r11
000075aec0bd2639  pop r10
000075aec0bd263b  pop r9
000075aec0bd263d  pop r8
000075aec0bd263f  pop rsi
000075aec0bd2640  pop rdi
000075aec0bd2641  pop rdx
000075aec0bd2642  pop rcx
000075aec0bd2643  pop rax
000075aec0bd2644  add rsp, 0x08
000075aec0bd2648  jmp 0x000075AEC0BCFCBC
000075aec0bd264d  sub rsp, 0x08
000075aec0bd2651  push rax
000075aec0bd2652  push rcx
000075aec0bd2653  push rdx
000075aec0bd2654  push rdi
000075aec0bd2655  push rsi
000075aec0bd2656  push r8
000075aec0bd2658  push r9
000075aec0bd265a  push r10
000075aec0bd265c  push r11
000075aec0bd265e  sub rsp, 0xF0
000075aec0bd2665  vmovaps [rsp], xmm0
000075aec0bd266a  vmovaps [rsp+0x10], xmm1
000075aec0bd2670  vmovaps [rsp+0x20], xmm2
000075aec0bd2676  vmovaps [rsp+0x30], xmm3
000075aec0bd267c  vmovaps [rsp+0x40], xmm4
000075aec0bd2682  vmovaps [rsp+0x50], xmm5
000075aec0bd2688  vmovaps [rsp+0x60], xmm6
000075aec0bd268e  vmovaps [rsp+0x70], xmm7
000075aec0bd2694  vmovaps [rsp+0x80], xmm8
000075aec0bd269d  vmovaps [rsp+0x90], xmm9
000075aec0bd26a6  vmovaps [rsp+0xA0], xmm10
000075aec0bd26af  vmovaps [rsp+0xB0], xmm12
000075aec0bd26b8  vmovaps [rsp+0xC0], xmm13
000075aec0bd26c1  vmovaps [rsp+0xD0], xmm14
000075aec0bd26ca  vmovaps [rsp+0xE0], xmm15
000075aec0bd26d3  sub rsp, 0x30
000075aec0bd26d7  movaps [rsp], xmm11
000075aec0bd26dc  movaps [rsp+0x10], xmm6
000075aec0bd26e1  movaps [rsp+0x20], xmm14
000075aec0bd26e7  lea rdi, [rsp]
000075aec0bd26eb  mov esi, 0x00
000075aec0bd26f0  mov rax, 0x57F4B31E6530
000075aec0bd26fa  call rax
000075aec0bd26fc  movaps xmm11, [rsp]
000075aec0bd2701  add rsp, 0x30
000075aec0bd2705  vmovaps xmm0, [rsp]
000075aec0bd270a  vmovaps xmm1, [rsp+0x10]
000075aec0bd2710  vmovaps xmm2, [rsp+0x20]
000075aec0bd2716  vmovaps xmm3, [rsp+0x30]
000075aec0bd271c  vmovaps xmm4, [rsp+0x40]
000075aec0bd2722  vmovaps xmm5, [rsp+0x50]
000075aec0bd2728  vmovaps xmm6, [rsp+0x60]
000075aec0bd272e  vmovaps xmm7, [rsp+0x70]
000075aec0bd2734  vmovaps xmm8, [rsp+0x80]
000075aec0bd273d  vmovaps xmm9, [rsp+0x90]
000075aec0bd2746  vmovaps xmm10, [rsp+0xA0]
000075aec0bd274f  vmovaps xmm12, [rsp+0xB0]
000075aec0bd2758  vmovaps xmm13, [rsp+0xC0]
000075aec0bd2761  vmovaps xmm14, [rsp+0xD0]
000075aec0bd276a  vmovaps xmm15, [rsp+0xE0]
000075aec0bd2773  add rsp, 0xF0
000075aec0bd277a  pop r11
000075aec0bd277c  pop r10
000075aec0bd277e  pop r9
000075aec0bd2780  pop r8
000075aec0bd2782  pop rsi
000075aec0bd2783  pop rdi
000075aec0bd2784  pop rdx
000075aec0bd2785  pop rcx
000075aec0bd2786  pop rax
000075aec0bd2787  add rsp, 0x08
000075aec0bd278b  jmp 0x000075AEC0BCFD34
000075aec0bd2790  call 0x000075AEC09FF430
000075aec0bd2795  jmp 0x000075AEC0BCFD3E
000075aec0bd279a  sub rsp, 0x08
000075aec0bd279e  push rax
000075aec0bd279f  push rcx
000075aec0bd27a0  push rdx
000075aec0bd27a1  push rdi
000075aec0bd27a2  push rsi
000075aec0bd27a3  push r8
000075aec0bd27a5  push r9
000075aec0bd27a7  push r10
000075aec0bd27a9  push r11
000075aec0bd27ab  sub rsp, 0xF0
000075aec0bd27b2  vmovaps [rsp], xmm0
000075aec0bd27b7  vmovaps [rsp+0x10], xmm1
000075aec0bd27bd  vmovaps [rsp+0x20], xmm2
000075aec0bd27c3  vmovaps [rsp+0x30], xmm3
000075aec0bd27c9  vmovaps [rsp+0x40], xmm4
000075aec0bd27cf  vmovaps [rsp+0x50], xmm5
000075aec0bd27d5  vmovaps [rsp+0x60], xmm6
000075aec0bd27db  vmovaps [rsp+0x70], xmm7
000075aec0bd27e1  vmovaps [rsp+0x80], xmm8
000075aec0bd27ea  vmovaps [rsp+0x90], xmm9
000075aec0bd27f3  vmovaps [rsp+0xA0], xmm10
000075aec0bd27fc  vmovaps [rsp+0xB0], xmm11
000075aec0bd2805  vmovaps [rsp+0xC0], xmm12
000075aec0bd280e  vmovaps [rsp+0xD0], xmm13
000075aec0bd2817  vmovaps [rsp+0xE0], xmm15
000075aec0bd2820  sub rsp, 0x30
000075aec0bd2824  movaps [rsp], xmm14
000075aec0bd2829  movaps [rsp+0x10], xmm6
000075aec0bd282e  movaps [rsp+0x20], xmm2
000075aec0bd2833  lea rdi, [rsp]
000075aec0bd2837  mov esi, 0x00
000075aec0bd283c  mov rax, 0x57F4B31E6530
000075aec0bd2846  call rax
000075aec0bd2848  movaps xmm14, [rsp]
000075aec0bd284d  add rsp, 0x30
000075aec0bd2851  vmovaps xmm0, [rsp]
000075aec0bd2856  vmovaps xmm1, [rsp+0x10]
000075aec0bd285c  vmovaps xmm2, [rsp+0x20]
000075aec0bd2862  vmovaps xmm3, [rsp+0x30]
000075aec0bd2868  vmovaps xmm4, [rsp+0x40]
000075aec0bd286e  vmovaps xmm5, [rsp+0x50]
000075aec0bd2874  vmovaps xmm6, [rsp+0x60]
000075aec0bd287a  vmovaps xmm7, [rsp+0x70]
000075aec0bd2880  vmovaps xmm8, [rsp+0x80]
000075aec0bd2889  vmovaps xmm9, [rsp+0x90]
000075aec0bd2892  vmovaps xmm10, [rsp+0xA0]
000075aec0bd289b  vmovaps xmm11, [rsp+0xB0]
000075aec0bd28a4  vmovaps xmm12, [rsp+0xC0]
000075aec0bd28ad  vmovaps xmm13, [rsp+0xD0]
000075aec0bd28b6  vmovaps xmm15, [rsp+0xE0]
000075aec0bd28bf  add rsp, 0xF0
000075aec0bd28c6  pop r11
000075aec0bd28c8  pop r10
000075aec0bd28ca  pop r9
000075aec0bd28cc  pop r8
000075aec0bd28ce  pop rsi
000075aec0bd28cf  pop rdi
000075aec0bd28d0  pop rdx
000075aec0bd28d1  pop rcx
000075aec0bd28d2  pop rax
000075aec0bd28d3  add rsp, 0x08
000075aec0bd28d7  jmp 0x000075AEC0BCFD72
000075aec0bd28dc  sub rsp, 0x08
000075aec0bd28e0  push rax
000075aec0bd28e1  push rcx
000075aec0bd28e2  push rdx
000075aec0bd28e3  push rdi
000075aec0bd28e4  push rsi
000075aec0bd28e5  push r8
000075aec0bd28e7  push r9
000075aec0bd28e9  push r10
000075aec0bd28eb  push r11
000075aec0bd28ed  sub rsp, 0xF0
000075aec0bd28f4  vmovaps [rsp], xmm0
000075aec0bd28f9  vmovaps [rsp+0x10], xmm1
000075aec0bd28ff  vmovaps [rsp+0x20], xmm2
000075aec0bd2905  vmovaps [rsp+0x30], xmm3
000075aec0bd290b  vmovaps [rsp+0x40], xmm4
000075aec0bd2911  vmovaps [rsp+0x50], xmm5
000075aec0bd2917  vmovaps [rsp+0x60], xmm7
000075aec0bd291d  vmovaps [rsp+0x70], xmm8
000075aec0bd2923  vmovaps [rsp+0x80], xmm9
000075aec0bd292c  vmovaps [rsp+0x90], xmm10
000075aec0bd2935  vmovaps [rsp+0xA0], xmm11
000075aec0bd293e  vmovaps [rsp+0xB0], xmm12
000075aec0bd2947  vmovaps [rsp+0xC0], xmm13
000075aec0bd2950  vmovaps [rsp+0xD0], xmm14
000075aec0bd2959  vmovaps [rsp+0xE0], xmm15
000075aec0bd2962  sub rsp, 0x30
000075aec0bd2966  movaps [rsp], xmm6
000075aec0bd296a  movaps [rsp+0x10], xmm5
000075aec0bd296f  movaps [rsp+0x20], xmm1
000075aec0bd2974  lea rdi, [rsp]
000075aec0bd2978  mov esi, 0x00
000075aec0bd297d  mov rax, 0x57F4B31E6530
000075aec0bd2987  call rax
000075aec0bd2989  movaps xmm6, [rsp]
000075aec0bd298d  add rsp, 0x30
000075aec0bd2991  vmovaps xmm0, [rsp]
000075aec0bd2996  vmovaps xmm1, [rsp+0x10]
000075aec0bd299c  vmovaps xmm2, [rsp+0x20]
000075aec0bd29a2  vmovaps xmm3, [rsp+0x30]
000075aec0bd29a8  vmovaps xmm4, [rsp+0x40]
000075aec0bd29ae  vmovaps xmm5, [rsp+0x50]
000075aec0bd29b4  vmovaps xmm7, [rsp+0x60]
000075aec0bd29ba  vmovaps xmm8, [rsp+0x70]
000075aec0bd29c0  vmovaps xmm9, [rsp+0x80]
000075aec0bd29c9  vmovaps xmm10, [rsp+0x90]
000075aec0bd29d2  vmovaps xmm11, [rsp+0xA0]
000075aec0bd29db  vmovaps xmm12, [rsp+0xB0]
000075aec0bd29e4  vmovaps xmm13, [rsp+0xC0]
000075aec0bd29ed  vmovaps xmm14, [rsp+0xD0]
000075aec0bd29f6  vmovaps xmm15, [rsp+0xE0]
000075aec0bd29ff  add rsp, 0xF0
000075aec0bd2a06  pop r11
000075aec0bd2a08  pop r10
000075aec0bd2a0a  pop r9
000075aec0bd2a0c  pop r8
000075aec0bd2a0e  pop rsi
000075aec0bd2a0f  pop rdi
000075aec0bd2a10  pop rdx
000075aec0bd2a11  pop rcx
000075aec0bd2a12  pop rax
000075aec0bd2a13  add rsp, 0x08
000075aec0bd2a17  jmp 0x000075AEC0BCFD98
000075aec0bd2a1c  sub rsp, 0x08
000075aec0bd2a20  push rax
000075aec0bd2a21  push rcx
000075aec0bd2a22  push rdx
000075aec0bd2a23  push rdi
000075aec0bd2a24  push rsi
000075aec0bd2a25  push r8
000075aec0bd2a27  push r9
000075aec0bd2a29  push r10
000075aec0bd2a2b  push r11
000075aec0bd2a2d  sub rsp, 0xF0
000075aec0bd2a34  vmovaps [rsp], xmm0
000075aec0bd2a39  vmovaps [rsp+0x10], xmm2
000075aec0bd2a3f  vmovaps [rsp+0x20], xmm3
000075aec0bd2a45  vmovaps [rsp+0x30], xmm4
000075aec0bd2a4b  vmovaps [rsp+0x40], xmm5
000075aec0bd2a51  vmovaps [rsp+0x50], xmm6
000075aec0bd2a57  vmovaps [rsp+0x60], xmm7
000075aec0bd2a5d  vmovaps [rsp+0x70], xmm8
000075aec0bd2a63  vmovaps [rsp+0x80], xmm9
000075aec0bd2a6c  vmovaps [rsp+0x90], xmm10
000075aec0bd2a75  vmovaps [rsp+0xA0], xmm11
000075aec0bd2a7e  vmovaps [rsp+0xB0], xmm12
000075aec0bd2a87  vmovaps [rsp+0xC0], xmm13
000075aec0bd2a90  vmovaps [rsp+0xD0], xmm14
000075aec0bd2a99  vmovaps [rsp+0xE0], xmm15
000075aec0bd2aa2  sub rsp, 0x30
000075aec0bd2aa6  movaps [rsp], xmm1
000075aec0bd2aaa  movaps [rsp+0x10], xmm5
000075aec0bd2aaf  movaps [rsp+0x20], xmm13
000075aec0bd2ab5  lea rdi, [rsp]
000075aec0bd2ab9  mov esi, 0x00
000075aec0bd2abe  mov rax, 0x57F4B31E6530
000075aec0bd2ac8  call rax
000075aec0bd2aca  movaps xmm1, [rsp]
000075aec0bd2ace  add rsp, 0x30
000075aec0bd2ad2  vmovaps xmm0, [rsp]
000075aec0bd2ad7  vmovaps xmm2, [rsp+0x10]
000075aec0bd2add  vmovaps xmm3, [rsp+0x20]
000075aec0bd2ae3  vmovaps xmm4, [rsp+0x30]
000075aec0bd2ae9  vmovaps xmm5, [rsp+0x40]
000075aec0bd2aef  vmovaps xmm6, [rsp+0x50]
000075aec0bd2af5  vmovaps xmm7, [rsp+0x60]
000075aec0bd2afb  vmovaps xmm8, [rsp+0x70]
000075aec0bd2b01  vmovaps xmm9, [rsp+0x80]
000075aec0bd2b0a  vmovaps xmm10, [rsp+0x90]
000075aec0bd2b13  vmovaps xmm11, [rsp+0xA0]
000075aec0bd2b1c  vmovaps xmm12, [rsp+0xB0]
000075aec0bd2b25  vmovaps xmm13, [rsp+0xC0]
000075aec0bd2b2e  vmovaps xmm14, [rsp+0xD0]
000075aec0bd2b37  vmovaps xmm15, [rsp+0xE0]
000075aec0bd2b40  add rsp, 0xF0
000075aec0bd2b47  pop r11
000075aec0bd2b49  pop r10
000075aec0bd2b4b  pop r9
000075aec0bd2b4d  pop r8
000075aec0bd2b4f  pop rsi
000075aec0bd2b50  pop rdi
000075aec0bd2b51  pop rdx
000075aec0bd2b52  pop rcx
000075aec0bd2b53  pop rax
000075aec0bd2b54  add rsp, 0x08
000075aec0bd2b58  jmp 0x000075AEC0BCFDB6
000075aec0bd2b5d  sub rsp, 0x08
000075aec0bd2b61  push rax
000075aec0bd2b62  push rcx
000075aec0bd2b63  push rdx
000075aec0bd2b64  push rdi
000075aec0bd2b65  push rsi
000075aec0bd2b66  push r8
000075aec0bd2b68  push r9
000075aec0bd2b6a  push r10
000075aec0bd2b6c  push r11
000075aec0bd2b6e  sub rsp, 0xF0
000075aec0bd2b75  vmovaps [rsp], xmm0
000075aec0bd2b7a  vmovaps [rsp+0x10], xmm1
000075aec0bd2b80  vmovaps [rsp+0x20], xmm2
000075aec0bd2b86  vmovaps [rsp+0x30], xmm3
000075aec0bd2b8c  vmovaps [rsp+0x40], xmm4
000075aec0bd2b92  vmovaps [rsp+0x50], xmm6
000075aec0bd2b98  vmovaps [rsp+0x60], xmm7
000075aec0bd2b9e  vmovaps [rsp+0x70], xmm8
000075aec0bd2ba4  vmovaps [rsp+0x80], xmm9
000075aec0bd2bad  vmovaps [rsp+0x90], xmm10
000075aec0bd2bb6  vmovaps [rsp+0xA0], xmm11
000075aec0bd2bbf  vmovaps [rsp+0xB0], xmm12
000075aec0bd2bc8  vmovaps [rsp+0xC0], xmm13
000075aec0bd2bd1  vmovaps [rsp+0xD0], xmm14
000075aec0bd2bda  vmovaps [rsp+0xE0], xmm15
000075aec0bd2be3  sub rsp, 0x30
000075aec0bd2be7  movaps [rsp], xmm5
000075aec0bd2beb  movaps [rsp+0x10], xmm2
000075aec0bd2bf0  movaps [rsp+0x20], xmm13
000075aec0bd2bf6  lea rdi, [rsp]
000075aec0bd2bfa  mov esi, 0x00
000075aec0bd2bff  mov rax, 0x57F4B31E6530
000075aec0bd2c09  call rax
000075aec0bd2c0b  movaps xmm5, [rsp]
000075aec0bd2c0f  add rsp, 0x30
000075aec0bd2c13  vmovaps xmm0, [rsp]
000075aec0bd2c18  vmovaps xmm1, [rsp+0x10]
000075aec0bd2c1e  vmovaps xmm2, [rsp+0x20]
000075aec0bd2c24  vmovaps xmm3, [rsp+0x30]
000075aec0bd2c2a  vmovaps xmm4, [rsp+0x40]
000075aec0bd2c30  vmovaps xmm6, [rsp+0x50]
000075aec0bd2c36  vmovaps xmm7, [rsp+0x60]
000075aec0bd2c3c  vmovaps xmm8, [rsp+0x70]
000075aec0bd2c42  vmovaps xmm9, [rsp+0x80]
000075aec0bd2c4b  vmovaps xmm10, [rsp+0x90]
000075aec0bd2c54  vmovaps xmm11, [rsp+0xA0]
000075aec0bd2c5d  vmovaps xmm12, [rsp+0xB0]
000075aec0bd2c66  vmovaps xmm13, [rsp+0xC0]
000075aec0bd2c6f  vmovaps xmm14, [rsp+0xD0]
000075aec0bd2c78  vmovaps xmm15, [rsp+0xE0]
000075aec0bd2c81  add rsp, 0xF0
000075aec0bd2c88  pop r11
000075aec0bd2c8a  pop r10
000075aec0bd2c8c  pop r9
000075aec0bd2c8e  pop r8
000075aec0bd2c90  pop rsi
000075aec0bd2c91  pop rdi
000075aec0bd2c92  pop rdx
000075aec0bd2c93  pop rcx
000075aec0bd2c94  pop rax
000075aec0bd2c95  add rsp, 0x08
000075aec0bd2c99  jmp 0x000075AEC0BCFDEC
000075aec0bd2c9e  sub rsp, 0x08
000075aec0bd2ca2  push rax
000075aec0bd2ca3  push rcx
000075aec0bd2ca4  push rdx
000075aec0bd2ca5  push rdi
000075aec0bd2ca6  push rsi
000075aec0bd2ca7  push r8
000075aec0bd2ca9  push r9
000075aec0bd2cab  push r10
000075aec0bd2cad  push r11
000075aec0bd2caf  sub rsp, 0xF0
000075aec0bd2cb6  vmovaps [rsp], xmm0
000075aec0bd2cbb  vmovaps [rsp+0x10], xmm1
000075aec0bd2cc1  vmovaps [rsp+0x20], xmm2
000075aec0bd2cc7  vmovaps [rsp+0x30], xmm3
000075aec0bd2ccd  vmovaps [rsp+0x40], xmm4
000075aec0bd2cd3  vmovaps [rsp+0x50], xmm5
000075aec0bd2cd9  vmovaps [rsp+0x60], xmm6
000075aec0bd2cdf  vmovaps [rsp+0x70], xmm7
000075aec0bd2ce5  vmovaps [rsp+0x80], xmm8
000075aec0bd2cee  vmovaps [rsp+0x90], xmm9
000075aec0bd2cf7  vmovaps [rsp+0xA0], xmm10
000075aec0bd2d00  vmovaps [rsp+0xB0], xmm11
000075aec0bd2d09  vmovaps [rsp+0xC0], xmm12
000075aec0bd2d12  vmovaps [rsp+0xD0], xmm14
000075aec0bd2d1b  vmovaps [rsp+0xE0], xmm15
000075aec0bd2d24  sub rsp, 0x30
000075aec0bd2d28  movaps [rsp], xmm13
000075aec0bd2d2d  movaps [rsp+0x10], xmm10
000075aec0bd2d33  movaps [rsp+0x20], xmm1
000075aec0bd2d38  lea rdi, [rsp]
000075aec0bd2d3c  mov esi, 0x00
000075aec0bd2d41  mov rax, 0x57F4B31E6530
000075aec0bd2d4b  call rax
000075aec0bd2d4d  movaps xmm13, [rsp]
000075aec0bd2d52  add rsp, 0x30
000075aec0bd2d56  vmovaps xmm0, [rsp]
000075aec0bd2d5b  vmovaps xmm1, [rsp+0x10]
000075aec0bd2d61  vmovaps xmm2, [rsp+0x20]
000075aec0bd2d67  vmovaps xmm3, [rsp+0x30]
000075aec0bd2d6d  vmovaps xmm4, [rsp+0x40]
000075aec0bd2d73  vmovaps xmm5, [rsp+0x50]
000075aec0bd2d79  vmovaps xmm6, [rsp+0x60]
000075aec0bd2d7f  vmovaps xmm7, [rsp+0x70]
000075aec0bd2d85  vmovaps xmm8, [rsp+0x80]
000075aec0bd2d8e  vmovaps xmm9, [rsp+0x90]
000075aec0bd2d97  vmovaps xmm10, [rsp+0xA0]
000075aec0bd2da0  vmovaps xmm11, [rsp+0xB0]
000075aec0bd2da9  vmovaps xmm12, [rsp+0xC0]
000075aec0bd2db2  vmovaps xmm14, [rsp+0xD0]
000075aec0bd2dbb  vmovaps xmm15, [rsp+0xE0]
000075aec0bd2dc4  add rsp, 0xF0
000075aec0bd2dcb  pop r11
000075aec0bd2dcd  pop r10
000075aec0bd2dcf  pop r9
000075aec0bd2dd1  pop r8
000075aec0bd2dd3  pop rsi
000075aec0bd2dd4  pop rdi
000075aec0bd2dd5  pop rdx
000075aec0bd2dd6  pop rcx
000075aec0bd2dd7  pop rax
000075aec0bd2dd8  add rsp, 0x08
000075aec0bd2ddc  jmp 0x000075AEC0BCFE15
000075aec0bd2de1  sub rsp, 0x08
000075aec0bd2de5  push rax
000075aec0bd2de6  push rcx
000075aec0bd2de7  push rdx
000075aec0bd2de8  push rdi
000075aec0bd2de9  push rsi
000075aec0bd2dea  push r8
000075aec0bd2dec  push r9
000075aec0bd2dee  push r10
000075aec0bd2df0  push r11
000075aec0bd2df2  sub rsp, 0xF0
000075aec0bd2df9  vmovaps [rsp], xmm0
000075aec0bd2dfe  vmovaps [rsp+0x10], xmm2
000075aec0bd2e04  vmovaps [rsp+0x20], xmm3
000075aec0bd2e0a  vmovaps [rsp+0x30], xmm4
000075aec0bd2e10  vmovaps [rsp+0x40], xmm5
000075aec0bd2e16  vmovaps [rsp+0x50], xmm6
000075aec0bd2e1c  vmovaps [rsp+0x60], xmm7
000075aec0bd2e22  vmovaps [rsp+0x70], xmm8
000075aec0bd2e28  vmovaps [rsp+0x80], xmm9
000075aec0bd2e31  vmovaps [rsp+0x90], xmm10
000075aec0bd2e3a  vmovaps [rsp+0xA0], xmm11
000075aec0bd2e43  vmovaps [rsp+0xB0], xmm12
000075aec0bd2e4c  vmovaps [rsp+0xC0], xmm13
000075aec0bd2e55  vmovaps [rsp+0xD0], xmm14
000075aec0bd2e5e  vmovaps [rsp+0xE0], xmm15
000075aec0bd2e67  sub rsp, 0x30
000075aec0bd2e6b  movaps [rsp], xmm1
000075aec0bd2e6f  movaps [rsp+0x10], xmm15
000075aec0bd2e75  movaps [rsp+0x20], xmm10
000075aec0bd2e7b  lea rdi, [rsp]
000075aec0bd2e7f  mov esi, 0x00
000075aec0bd2e84  mov rax, 0x57F4B31E6530
000075aec0bd2e8e  call rax
000075aec0bd2e90  movaps xmm1, [rsp]
000075aec0bd2e94  add rsp, 0x30
000075aec0bd2e98  vmovaps xmm0, [rsp]
000075aec0bd2e9d  vmovaps xmm2, [rsp+0x10]
000075aec0bd2ea3  vmovaps xmm3, [rsp+0x20]
000075aec0bd2ea9  vmovaps xmm4, [rsp+0x30]
000075aec0bd2eaf  vmovaps xmm5, [rsp+0x40]
000075aec0bd2eb5  vmovaps xmm6, [rsp+0x50]
000075aec0bd2ebb  vmovaps xmm7, [rsp+0x60]
000075aec0bd2ec1  vmovaps xmm8, [rsp+0x70]
000075aec0bd2ec7  vmovaps xmm9, [rsp+0x80]
000075aec0bd2ed0  vmovaps xmm10, [rsp+0x90]
000075aec0bd2ed9  vmovaps xmm11, [rsp+0xA0]
000075aec0bd2ee2  vmovaps xmm12, [rsp+0xB0]
000075aec0bd2eeb  vmovaps xmm13, [rsp+0xC0]
000075aec0bd2ef4  vmovaps xmm14, [rsp+0xD0]
000075aec0bd2efd  vmovaps xmm15, [rsp+0xE0]
000075aec0bd2f06  add rsp, 0xF0
000075aec0bd2f0d  pop r11
000075aec0bd2f0f  pop r10
000075aec0bd2f11  pop r9
000075aec0bd2f13  pop r8
000075aec0bd2f15  pop rsi
000075aec0bd2f16  pop rdi
000075aec0bd2f17  pop rdx
000075aec0bd2f18  pop rcx
000075aec0bd2f19  pop rax
000075aec0bd2f1a  add rsp, 0x08
000075aec0bd2f1e  jmp 0x000075AEC0BCFE34
000075aec0bd2f23  sub rsp, 0x08
000075aec0bd2f27  push rax
000075aec0bd2f28  push rcx
000075aec0bd2f29  push rdx
000075aec0bd2f2a  push rdi
000075aec0bd2f2b  push rsi
000075aec0bd2f2c  push r8
000075aec0bd2f2e  push r9
000075aec0bd2f30  push r10
000075aec0bd2f32  push r11
000075aec0bd2f34  sub rsp, 0xF0
000075aec0bd2f3b  vmovaps [rsp], xmm0
000075aec0bd2f40  vmovaps [rsp+0x10], xmm1
000075aec0bd2f46  vmovaps [rsp+0x20], xmm2
000075aec0bd2f4c  vmovaps [rsp+0x30], xmm3
000075aec0bd2f52  vmovaps [rsp+0x40], xmm4
000075aec0bd2f58  vmovaps [rsp+0x50], xmm5
000075aec0bd2f5e  vmovaps [rsp+0x60], xmm6
000075aec0bd2f64  vmovaps [rsp+0x70], xmm7
000075aec0bd2f6a  vmovaps [rsp+0x80], xmm8
000075aec0bd2f73  vmovaps [rsp+0x90], xmm9
000075aec0bd2f7c  vmovaps [rsp+0xA0], xmm10
000075aec0bd2f85  vmovaps [rsp+0xB0], xmm11
000075aec0bd2f8e  vmovaps [rsp+0xC0], xmm12
000075aec0bd2f97  vmovaps [rsp+0xD0], xmm13
000075aec0bd2fa0  vmovaps [rsp+0xE0], xmm14
000075aec0bd2fa9  sub rsp, 0x30
000075aec0bd2fad  movaps [rsp], xmm15
000075aec0bd2fb2  movaps [rsp+0x10], xmm10
000075aec0bd2fb8  movaps [rsp+0x20], xmm11
000075aec0bd2fbe  lea rdi, [rsp]
000075aec0bd2fc2  mov esi, 0x00
000075aec0bd2fc7  mov rax, 0x57F4B31E6530
000075aec0bd2fd1  call rax
000075aec0bd2fd3  movaps xmm15, [rsp]
000075aec0bd2fd8  add rsp, 0x30
000075aec0bd2fdc  vmovaps xmm0, [rsp]
000075aec0bd2fe1  vmovaps xmm1, [rsp+0x10]
000075aec0bd2fe7  vmovaps xmm2, [rsp+0x20]
000075aec0bd2fed  vmovaps xmm3, [rsp+0x30]
000075aec0bd2ff3  vmovaps xmm4, [rsp+0x40]
000075aec0bd2ff9  vmovaps xmm5, [rsp+0x50]
000075aec0bd2fff  vmovaps xmm6, [rsp+0x60]
000075aec0bd3005  vmovaps xmm7, [rsp+0x70]
000075aec0bd300b  vmovaps xmm8, [rsp+0x80]
000075aec0bd3014  vmovaps xmm9, [rsp+0x90]
000075aec0bd301d  vmovaps xmm10, [rsp+0xA0]
000075aec0bd3026  vmovaps xmm11, [rsp+0xB0]
000075aec0bd302f  vmovaps xmm12, [rsp+0xC0]
000075aec0bd3038  vmovaps xmm13, [rsp+0xD0]
000075aec0bd3041  vmovaps xmm14, [rsp+0xE0]
000075aec0bd304a  add rsp, 0xF0
000075aec0bd3051  pop r11
000075aec0bd3053  pop r10
000075aec0bd3055  pop r9
000075aec0bd3057  pop r8
000075aec0bd3059  pop rsi
000075aec0bd305a  pop rdi
000075aec0bd305b  pop rdx
000075aec0bd305c  pop rcx
000075aec0bd305d  pop rax
000075aec0bd305e  add rsp, 0x08
000075aec0bd3062  jmp 0x000075AEC0BCFE57
000075aec0bd3067  sub rsp, 0x08
000075aec0bd306b  push rax
000075aec0bd306c  push rcx
000075aec0bd306d  push rdx
000075aec0bd306e  push rdi
000075aec0bd306f  push rsi
000075aec0bd3070  push r8
000075aec0bd3072  push r9
000075aec0bd3074  push r10
000075aec0bd3076  push r11
000075aec0bd3078  sub rsp, 0xF0
000075aec0bd307f  vmovaps [rsp], xmm0
000075aec0bd3084  vmovaps [rsp+0x10], xmm1
000075aec0bd308a  vmovaps [rsp+0x20], xmm2
000075aec0bd3090  vmovaps [rsp+0x30], xmm3
000075aec0bd3096  vmovaps [rsp+0x40], xmm4
000075aec0bd309c  vmovaps [rsp+0x50], xmm5
000075aec0bd30a2  vmovaps [rsp+0x60], xmm6
000075aec0bd30a8  vmovaps [rsp+0x70], xmm7
000075aec0bd30ae  vmovaps [rsp+0x80], xmm8
000075aec0bd30b7  vmovaps [rsp+0x90], xmm9
000075aec0bd30c0  vmovaps [rsp+0xA0], xmm11
000075aec0bd30c9  vmovaps [rsp+0xB0], xmm12
000075aec0bd30d2  vmovaps [rsp+0xC0], xmm13
000075aec0bd30db  vmovaps [rsp+0xD0], xmm14
000075aec0bd30e4  vmovaps [rsp+0xE0], xmm15
000075aec0bd30ed  sub rsp, 0x30
000075aec0bd30f1  movaps [rsp], xmm10
000075aec0bd30f6  movaps [rsp+0x10], xmm12
000075aec0bd30fc  movaps [rsp+0x20], xmm11
000075aec0bd3102  lea rdi, [rsp]
000075aec0bd3106  mov esi, 0x00
000075aec0bd310b  mov rax, 0x57F4B31E6530
000075aec0bd3115  call rax
000075aec0bd3117  movaps xmm10, [rsp]
000075aec0bd311c  add rsp, 0x30
000075aec0bd3120  vmovaps xmm0, [rsp]
000075aec0bd3125  vmovaps xmm1, [rsp+0x10]
000075aec0bd312b  vmovaps xmm2, [rsp+0x20]
000075aec0bd3131  vmovaps xmm3, [rsp+0x30]
000075aec0bd3137  vmovaps xmm4, [rsp+0x40]
000075aec0bd313d  vmovaps xmm5, [rsp+0x50]
000075aec0bd3143  vmovaps xmm6, [rsp+0x60]
000075aec0bd3149  vmovaps xmm7, [rsp+0x70]
000075aec0bd314f  vmovaps xmm8, [rsp+0x80]
000075aec0bd3158  vmovaps xmm9, [rsp+0x90]
000075aec0bd3161  vmovaps xmm11, [rsp+0xA0]
000075aec0bd316a  vmovaps xmm12, [rsp+0xB0]
000075aec0bd3173  vmovaps xmm13, [rsp+0xC0]
000075aec0bd317c  vmovaps xmm14, [rsp+0xD0]
000075aec0bd3185  vmovaps xmm15, [rsp+0xE0]
000075aec0bd318e  add rsp, 0xF0
000075aec0bd3195  pop r11
000075aec0bd3197  pop r10
000075aec0bd3199  pop r9
000075aec0bd319b  pop r8
000075aec0bd319d  pop rsi
000075aec0bd319e  pop rdi
000075aec0bd319f  pop rdx
000075aec0bd31a0  pop rcx
000075aec0bd31a1  pop rax
000075aec0bd31a2  add rsp, 0x08
000075aec0bd31a6  jmp 0x000075AEC0BCFE80
000075aec0bd31ab  sub rsp, 0x08
000075aec0bd31af  push rax
000075aec0bd31b0  push rcx
000075aec0bd31b1  push rdx
000075aec0bd31b2  push rdi
000075aec0bd31b3  push rsi
000075aec0bd31b4  push r8
000075aec0bd31b6  push r9
000075aec0bd31b8  push r10
000075aec0bd31ba  push r11
000075aec0bd31bc  sub rsp, 0xF0
000075aec0bd31c3  vmovaps [rsp], xmm0
000075aec0bd31c8  vmovaps [rsp+0x10], xmm1
000075aec0bd31ce  vmovaps [rsp+0x20], xmm2
000075aec0bd31d4  vmovaps [rsp+0x30], xmm3
000075aec0bd31da  vmovaps [rsp+0x40], xmm4
000075aec0bd31e0  vmovaps [rsp+0x50], xmm5
000075aec0bd31e6  vmovaps [rsp+0x60], xmm6
000075aec0bd31ec  vmovaps [rsp+0x70], xmm7
000075aec0bd31f2  vmovaps [rsp+0x80], xmm8
000075aec0bd31fb  vmovaps [rsp+0x90], xmm9
000075aec0bd3204  vmovaps [rsp+0xA0], xmm10
000075aec0bd320d  vmovaps [rsp+0xB0], xmm12
000075aec0bd3216  vmovaps [rsp+0xC0], xmm13
000075aec0bd321f  vmovaps [rsp+0xD0], xmm14
000075aec0bd3228  vmovaps [rsp+0xE0], xmm15
000075aec0bd3231  sub rsp, 0x30
000075aec0bd3235  movaps [rsp], xmm11
000075aec0bd323a  movaps [rsp+0x10], xmm2
000075aec0bd323f  movaps [rsp+0x20], xmm12
000075aec0bd3245  lea rdi, [rsp]
000075aec0bd3249  mov esi, 0x00
000075aec0bd324e  mov rax, 0x57F4B31E6530
000075aec0bd3258  call rax
000075aec0bd325a  movaps xmm11, [rsp]
000075aec0bd325f  add rsp, 0x30
000075aec0bd3263  vmovaps xmm0, [rsp]
000075aec0bd3268  vmovaps xmm1, [rsp+0x10]
000075aec0bd326e  vmovaps xmm2, [rsp+0x20]
000075aec0bd3274  vmovaps xmm3, [rsp+0x30]
000075aec0bd327a  vmovaps xmm4, [rsp+0x40]
000075aec0bd3280  vmovaps xmm5, [rsp+0x50]
000075aec0bd3286  vmovaps xmm6, [rsp+0x60]
000075aec0bd328c  vmovaps xmm7, [rsp+0x70]
000075aec0bd3292  vmovaps xmm8, [rsp+0x80]
000075aec0bd329b  vmovaps xmm9, [rsp+0x90]
000075aec0bd32a4  vmovaps xmm10, [rsp+0xA0]
000075aec0bd32ad  vmovaps xmm12, [rsp+0xB0]
000075aec0bd32b6  vmovaps xmm13, [rsp+0xC0]
000075aec0bd32bf  vmovaps xmm14, [rsp+0xD0]
000075aec0bd32c8  vmovaps xmm15, [rsp+0xE0]
000075aec0bd32d1  add rsp, 0xF0
000075aec0bd32d8  pop r11
000075aec0bd32da  pop r10
000075aec0bd32dc  pop r9
000075aec0bd32de  pop r8
000075aec0bd32e0  pop rsi
000075aec0bd32e1  pop rdi
000075aec0bd32e2  pop rdx
000075aec0bd32e3  pop rcx
000075aec0bd32e4  pop rax
000075aec0bd32e5  add rsp, 0x08
000075aec0bd32e9  jmp 0x000075AEC0BCFEB8
000075aec0bd32ee  sub rsp, 0x08
000075aec0bd32f2  push rax
000075aec0bd32f3  push rcx
000075aec0bd32f4  push rdx
000075aec0bd32f5  push rdi
000075aec0bd32f6  push rsi
000075aec0bd32f7  push r8
000075aec0bd32f9  push r9
000075aec0bd32fb  push r10
000075aec0bd32fd  push r11
000075aec0bd32ff  sub rsp, 0xF0
000075aec0bd3306  vmovaps [rsp], xmm0
000075aec0bd330b  vmovaps [rsp+0x10], xmm2
000075aec0bd3311  vmovaps [rsp+0x20], xmm3
000075aec0bd3317  vmovaps [rsp+0x30], xmm4
000075aec0bd331d  vmovaps [rsp+0x40], xmm5
000075aec0bd3323  vmovaps [rsp+0x50], xmm6
000075aec0bd3329  vmovaps [rsp+0x60], xmm7
000075aec0bd332f  vmovaps [rsp+0x70], xmm8
000075aec0bd3335  vmovaps [rsp+0x80], xmm9
000075aec0bd333e  vmovaps [rsp+0x90], xmm10
000075aec0bd3347  vmovaps [rsp+0xA0], xmm11
000075aec0bd3350  vmovaps [rsp+0xB0], xmm12
000075aec0bd3359  vmovaps [rsp+0xC0], xmm13
000075aec0bd3362  vmovaps [rsp+0xD0], xmm14
000075aec0bd336b  vmovaps [rsp+0xE0], xmm15
000075aec0bd3374  sub rsp, 0x30
000075aec0bd3378  movaps [rsp], xmm1
000075aec0bd337c  movaps [rsp+0x10], xmm14
000075aec0bd3382  movaps [rsp+0x20], xmm6
000075aec0bd3387  lea rdi, [rsp]
000075aec0bd338b  mov esi, 0x00
000075aec0bd3390  mov rax, 0x57F4B31E6530
000075aec0bd339a  call rax
000075aec0bd339c  movaps xmm1, [rsp]
000075aec0bd33a0  add rsp, 0x30
000075aec0bd33a4  vmovaps xmm0, [rsp]
000075aec0bd33a9  vmovaps xmm2, [rsp+0x10]
000075aec0bd33af  vmovaps xmm3, [rsp+0x20]
000075aec0bd33b5  vmovaps xmm4, [rsp+0x30]
000075aec0bd33bb  vmovaps xmm5, [rsp+0x40]
000075aec0bd33c1  vmovaps xmm6, [rsp+0x50]
000075aec0bd33c7  vmovaps xmm7, [rsp+0x60]
000075aec0bd33cd  vmovaps xmm8, [rsp+0x70]
000075aec0bd33d3  vmovaps xmm9, [rsp+0x80]
000075aec0bd33dc  vmovaps xmm10, [rsp+0x90]
000075aec0bd33e5  vmovaps xmm11, [rsp+0xA0]
000075aec0bd33ee  vmovaps xmm12, [rsp+0xB0]
000075aec0bd33f7  vmovaps xmm13, [rsp+0xC0]
000075aec0bd3400  vmovaps xmm14, [rsp+0xD0]
000075aec0bd3409  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3412  add rsp, 0xF0
000075aec0bd3419  pop r11
000075aec0bd341b  pop r10
000075aec0bd341d  pop r9
000075aec0bd341f  pop r8
000075aec0bd3421  pop rsi
000075aec0bd3422  pop rdi
000075aec0bd3423  pop rdx
000075aec0bd3424  pop rcx
000075aec0bd3425  pop rax
000075aec0bd3426  add rsp, 0x08
000075aec0bd342a  jmp 0x000075AEC0BCFED1
000075aec0bd342f  sub rsp, 0x08
000075aec0bd3433  push rax
000075aec0bd3434  push rcx
000075aec0bd3435  push rdx
000075aec0bd3436  push rdi
000075aec0bd3437  push rsi
000075aec0bd3438  push r8
000075aec0bd343a  push r9
000075aec0bd343c  push r10
000075aec0bd343e  push r11
000075aec0bd3440  sub rsp, 0xF0
000075aec0bd3447  vmovaps [rsp], xmm0
000075aec0bd344c  vmovaps [rsp+0x10], xmm1
000075aec0bd3452  vmovaps [rsp+0x20], xmm2
000075aec0bd3458  vmovaps [rsp+0x30], xmm3
000075aec0bd345e  vmovaps [rsp+0x40], xmm4
000075aec0bd3464  vmovaps [rsp+0x50], xmm5
000075aec0bd346a  vmovaps [rsp+0x60], xmm6
000075aec0bd3470  vmovaps [rsp+0x70], xmm7
000075aec0bd3476  vmovaps [rsp+0x80], xmm8
000075aec0bd347f  vmovaps [rsp+0x90], xmm9
000075aec0bd3488  vmovaps [rsp+0xA0], xmm10
000075aec0bd3491  vmovaps [rsp+0xB0], xmm11
000075aec0bd349a  vmovaps [rsp+0xC0], xmm12
000075aec0bd34a3  vmovaps [rsp+0xD0], xmm13
000075aec0bd34ac  vmovaps [rsp+0xE0], xmm15
000075aec0bd34b5  sub rsp, 0x30
000075aec0bd34b9  movaps [rsp], xmm14
000075aec0bd34be  movaps [rsp+0x10], xmm12
000075aec0bd34c4  movaps [rsp+0x20], xmm5
000075aec0bd34c9  lea rdi, [rsp]
000075aec0bd34cd  mov esi, 0x00
000075aec0bd34d2  mov rax, 0x57F4B31E6530
000075aec0bd34dc  call rax
000075aec0bd34de  movaps xmm14, [rsp]
000075aec0bd34e3  add rsp, 0x30
000075aec0bd34e7  vmovaps xmm0, [rsp]
000075aec0bd34ec  vmovaps xmm1, [rsp+0x10]
000075aec0bd34f2  vmovaps xmm2, [rsp+0x20]
000075aec0bd34f8  vmovaps xmm3, [rsp+0x30]
000075aec0bd34fe  vmovaps xmm4, [rsp+0x40]
000075aec0bd3504  vmovaps xmm5, [rsp+0x50]
000075aec0bd350a  vmovaps xmm6, [rsp+0x60]
000075aec0bd3510  vmovaps xmm7, [rsp+0x70]
000075aec0bd3516  vmovaps xmm8, [rsp+0x80]
000075aec0bd351f  vmovaps xmm9, [rsp+0x90]
000075aec0bd3528  vmovaps xmm10, [rsp+0xA0]
000075aec0bd3531  vmovaps xmm11, [rsp+0xB0]
000075aec0bd353a  vmovaps xmm12, [rsp+0xC0]
000075aec0bd3543  vmovaps xmm13, [rsp+0xD0]
000075aec0bd354c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3555  add rsp, 0xF0
000075aec0bd355c  pop r11
000075aec0bd355e  pop r10
000075aec0bd3560  pop r9
000075aec0bd3562  pop r8
000075aec0bd3564  pop rsi
000075aec0bd3565  pop rdi
000075aec0bd3566  pop rdx
000075aec0bd3567  pop rcx
000075aec0bd3568  pop rax
000075aec0bd3569  add rsp, 0x08
000075aec0bd356d  jmp 0x000075AEC0BCFEF1
000075aec0bd3572  sub rsp, 0x08
000075aec0bd3576  push rax
000075aec0bd3577  push rcx
000075aec0bd3578  push rdx
000075aec0bd3579  push rdi
000075aec0bd357a  push rsi
000075aec0bd357b  push r8
000075aec0bd357d  push r9
000075aec0bd357f  push r10
000075aec0bd3581  push r11
000075aec0bd3583  sub rsp, 0xF0
000075aec0bd358a  vmovaps [rsp], xmm0
000075aec0bd358f  vmovaps [rsp+0x10], xmm1
000075aec0bd3595  vmovaps [rsp+0x20], xmm2
000075aec0bd359b  vmovaps [rsp+0x30], xmm3
000075aec0bd35a1  vmovaps [rsp+0x40], xmm4
000075aec0bd35a7  vmovaps [rsp+0x50], xmm5
000075aec0bd35ad  vmovaps [rsp+0x60], xmm7
000075aec0bd35b3  vmovaps [rsp+0x70], xmm8
000075aec0bd35b9  vmovaps [rsp+0x80], xmm9
000075aec0bd35c2  vmovaps [rsp+0x90], xmm10
000075aec0bd35cb  vmovaps [rsp+0xA0], xmm11
000075aec0bd35d4  vmovaps [rsp+0xB0], xmm12
000075aec0bd35dd  vmovaps [rsp+0xC0], xmm13
000075aec0bd35e6  vmovaps [rsp+0xD0], xmm14
000075aec0bd35ef  vmovaps [rsp+0xE0], xmm15
000075aec0bd35f8  sub rsp, 0x30
000075aec0bd35fc  movaps [rsp], xmm6
000075aec0bd3600  movaps [rsp+0x10], xmm9
000075aec0bd3606  movaps [rsp+0x20], xmm12
000075aec0bd360c  lea rdi, [rsp]
000075aec0bd3610  mov esi, 0x00
000075aec0bd3615  mov rax, 0x57F4B31E6530
000075aec0bd361f  call rax
000075aec0bd3621  movaps xmm6, [rsp]
000075aec0bd3625  add rsp, 0x30
000075aec0bd3629  vmovaps xmm0, [rsp]
000075aec0bd362e  vmovaps xmm1, [rsp+0x10]
000075aec0bd3634  vmovaps xmm2, [rsp+0x20]
000075aec0bd363a  vmovaps xmm3, [rsp+0x30]
000075aec0bd3640  vmovaps xmm4, [rsp+0x40]
000075aec0bd3646  vmovaps xmm5, [rsp+0x50]
000075aec0bd364c  vmovaps xmm7, [rsp+0x60]
000075aec0bd3652  vmovaps xmm8, [rsp+0x70]
000075aec0bd3658  vmovaps xmm9, [rsp+0x80]
000075aec0bd3661  vmovaps xmm10, [rsp+0x90]
000075aec0bd366a  vmovaps xmm11, [rsp+0xA0]
000075aec0bd3673  vmovaps xmm12, [rsp+0xB0]
000075aec0bd367c  vmovaps xmm13, [rsp+0xC0]
000075aec0bd3685  vmovaps xmm14, [rsp+0xD0]
000075aec0bd368e  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3697  add rsp, 0xF0
000075aec0bd369e  pop r11
000075aec0bd36a0  pop r10
000075aec0bd36a2  pop r9
000075aec0bd36a4  pop r8
000075aec0bd36a6  pop rsi
000075aec0bd36a7  pop rdi
000075aec0bd36a8  pop rdx
000075aec0bd36a9  pop rcx
000075aec0bd36aa  pop rax
000075aec0bd36ab  add rsp, 0x08
000075aec0bd36af  jmp 0x000075AEC0BCFF19
000075aec0bd36b4  sub rsp, 0x08
000075aec0bd36b8  push rax
000075aec0bd36b9  push rcx
000075aec0bd36ba  push rdx
000075aec0bd36bb  push rdi
000075aec0bd36bc  push rsi
000075aec0bd36bd  push r8
000075aec0bd36bf  push r9
000075aec0bd36c1  push r10
000075aec0bd36c3  push r11
000075aec0bd36c5  sub rsp, 0xF0
000075aec0bd36cc  vmovaps [rsp], xmm0
000075aec0bd36d1  vmovaps [rsp+0x10], xmm1
000075aec0bd36d7  vmovaps [rsp+0x20], xmm2
000075aec0bd36dd  vmovaps [rsp+0x30], xmm3
000075aec0bd36e3  vmovaps [rsp+0x40], xmm4
000075aec0bd36e9  vmovaps [rsp+0x50], xmm5
000075aec0bd36ef  vmovaps [rsp+0x60], xmm6
000075aec0bd36f5  vmovaps [rsp+0x70], xmm7
000075aec0bd36fb  vmovaps [rsp+0x80], xmm8
000075aec0bd3704  vmovaps [rsp+0x90], xmm9
000075aec0bd370d  vmovaps [rsp+0xA0], xmm10
000075aec0bd3716  vmovaps [rsp+0xB0], xmm11
000075aec0bd371f  vmovaps [rsp+0xC0], xmm13
000075aec0bd3728  vmovaps [rsp+0xD0], xmm14
000075aec0bd3731  vmovaps [rsp+0xE0], xmm15
000075aec0bd373a  sub rsp, 0x30
000075aec0bd373e  movaps [rsp], xmm12
000075aec0bd3743  movaps [rsp+0x10], xmm15
000075aec0bd3749  movaps [rsp+0x20], xmm13
000075aec0bd374f  lea rdi, [rsp]
000075aec0bd3753  mov esi, 0x00
000075aec0bd3758  mov rax, 0x57F4B31E6530
000075aec0bd3762  call rax
000075aec0bd3764  movaps xmm12, [rsp]
000075aec0bd3769  add rsp, 0x30
000075aec0bd376d  vmovaps xmm0, [rsp]
000075aec0bd3772  vmovaps xmm1, [rsp+0x10]
000075aec0bd3778  vmovaps xmm2, [rsp+0x20]
000075aec0bd377e  vmovaps xmm3, [rsp+0x30]
000075aec0bd3784  vmovaps xmm4, [rsp+0x40]
000075aec0bd378a  vmovaps xmm5, [rsp+0x50]
000075aec0bd3790  vmovaps xmm6, [rsp+0x60]
000075aec0bd3796  vmovaps xmm7, [rsp+0x70]
000075aec0bd379c  vmovaps xmm8, [rsp+0x80]
000075aec0bd37a5  vmovaps xmm9, [rsp+0x90]
000075aec0bd37ae  vmovaps xmm10, [rsp+0xA0]
000075aec0bd37b7  vmovaps xmm11, [rsp+0xB0]
000075aec0bd37c0  vmovaps xmm13, [rsp+0xC0]
000075aec0bd37c9  vmovaps xmm14, [rsp+0xD0]
000075aec0bd37d2  vmovaps xmm15, [rsp+0xE0]
000075aec0bd37db  add rsp, 0xF0
000075aec0bd37e2  pop r11
000075aec0bd37e4  pop r10
000075aec0bd37e6  pop r9
000075aec0bd37e8  pop r8
000075aec0bd37ea  pop rsi
000075aec0bd37eb  pop rdi
000075aec0bd37ec  pop rdx
000075aec0bd37ed  pop rcx
000075aec0bd37ee  pop rax
000075aec0bd37ef  add rsp, 0x08
000075aec0bd37f3  jmp 0x000075AEC0BCFF34
000075aec0bd37f8  sub rsp, 0x08
000075aec0bd37fc  push rax
000075aec0bd37fd  push rcx
000075aec0bd37fe  push rdx
000075aec0bd37ff  push rdi
000075aec0bd3800  push rsi
000075aec0bd3801  push r8
000075aec0bd3803  push r9
000075aec0bd3805  push r10
000075aec0bd3807  push r11
000075aec0bd3809  sub rsp, 0xF0
000075aec0bd3810  vmovaps [rsp], xmm0
000075aec0bd3815  vmovaps [rsp+0x10], xmm1
000075aec0bd381b  vmovaps [rsp+0x20], xmm2
000075aec0bd3821  vmovaps [rsp+0x30], xmm3
000075aec0bd3827  vmovaps [rsp+0x40], xmm4
000075aec0bd382d  vmovaps [rsp+0x50], xmm5
000075aec0bd3833  vmovaps [rsp+0x60], xmm6
000075aec0bd3839  vmovaps [rsp+0x70], xmm7
000075aec0bd383f  vmovaps [rsp+0x80], xmm8
000075aec0bd3848  vmovaps [rsp+0x90], xmm9
000075aec0bd3851  vmovaps [rsp+0xA0], xmm10
000075aec0bd385a  vmovaps [rsp+0xB0], xmm11
000075aec0bd3863  vmovaps [rsp+0xC0], xmm12
000075aec0bd386c  vmovaps [rsp+0xD0], xmm13
000075aec0bd3875  vmovaps [rsp+0xE0], xmm14
000075aec0bd387e  sub rsp, 0x30
000075aec0bd3882  movaps [rsp], xmm15
000075aec0bd3887  movaps [rsp+0x10], xmm13
000075aec0bd388d  movaps [rsp+0x20], xmm10
000075aec0bd3893  lea rdi, [rsp]
000075aec0bd3897  mov esi, 0x00
000075aec0bd389c  mov rax, 0x57F4B31E6530
000075aec0bd38a6  call rax
000075aec0bd38a8  movaps xmm15, [rsp]
000075aec0bd38ad  add rsp, 0x30
000075aec0bd38b1  vmovaps xmm0, [rsp]
000075aec0bd38b6  vmovaps xmm1, [rsp+0x10]
000075aec0bd38bc  vmovaps xmm2, [rsp+0x20]
000075aec0bd38c2  vmovaps xmm3, [rsp+0x30]
000075aec0bd38c8  vmovaps xmm4, [rsp+0x40]
000075aec0bd38ce  vmovaps xmm5, [rsp+0x50]
000075aec0bd38d4  vmovaps xmm6, [rsp+0x60]
000075aec0bd38da  vmovaps xmm7, [rsp+0x70]
000075aec0bd38e0  vmovaps xmm8, [rsp+0x80]
000075aec0bd38e9  vmovaps xmm9, [rsp+0x90]
000075aec0bd38f2  vmovaps xmm10, [rsp+0xA0]
000075aec0bd38fb  vmovaps xmm11, [rsp+0xB0]
000075aec0bd3904  vmovaps xmm12, [rsp+0xC0]
000075aec0bd390d  vmovaps xmm13, [rsp+0xD0]
000075aec0bd3916  vmovaps xmm14, [rsp+0xE0]
000075aec0bd391f  add rsp, 0xF0
000075aec0bd3926  pop r11
000075aec0bd3928  pop r10
000075aec0bd392a  pop r9
000075aec0bd392c  pop r8
000075aec0bd392e  pop rsi
000075aec0bd392f  pop rdi
000075aec0bd3930  pop rdx
000075aec0bd3931  pop rcx
000075aec0bd3932  pop rax
000075aec0bd3933  add rsp, 0x08
000075aec0bd3937  jmp 0x000075AEC0BCFF55
000075aec0bd393c  call 0x000075AEC0A0C260
000075aec0bd3941  jmp 0x000075AEC0BCFFB0
000075aec0bd3946  sub rsp, 0x08
000075aec0bd394a  push rax
000075aec0bd394b  push rcx
000075aec0bd394c  push rdx
000075aec0bd394d  push rdi
000075aec0bd394e  push rsi
000075aec0bd394f  push r8
000075aec0bd3951  push r9
000075aec0bd3953  push r10
000075aec0bd3955  push r11
000075aec0bd3957  sub rsp, 0xF0
000075aec0bd395e  vmovaps [rsp], xmm0
000075aec0bd3963  vmovaps [rsp+0x10], xmm1
000075aec0bd3969  vmovaps [rsp+0x20], xmm2
000075aec0bd396f  vmovaps [rsp+0x30], xmm3
000075aec0bd3975  vmovaps [rsp+0x40], xmm4
000075aec0bd397b  vmovaps [rsp+0x50], xmm5
000075aec0bd3981  vmovaps [rsp+0x60], xmm6
000075aec0bd3987  vmovaps [rsp+0x70], xmm7
000075aec0bd398d  vmovaps [rsp+0x80], xmm8
000075aec0bd3996  vmovaps [rsp+0x90], xmm10
000075aec0bd399f  vmovaps [rsp+0xA0], xmm11
000075aec0bd39a8  vmovaps [rsp+0xB0], xmm12
000075aec0bd39b1  vmovaps [rsp+0xC0], xmm13
000075aec0bd39ba  vmovaps [rsp+0xD0], xmm14
000075aec0bd39c3  vmovaps [rsp+0xE0], xmm15
000075aec0bd39cc  sub rsp, 0x30
000075aec0bd39d0  movaps [rsp], xmm9
000075aec0bd39d5  movaps [rsp+0x10], xmm8
000075aec0bd39db  movaps [rsp+0x20], xmm10
000075aec0bd39e1  lea rdi, [rsp]
000075aec0bd39e5  mov esi, 0x00
000075aec0bd39ea  mov rax, 0x57F4B31E6530
000075aec0bd39f4  call rax
000075aec0bd39f6  movaps xmm9, [rsp]
000075aec0bd39fb  add rsp, 0x30
000075aec0bd39ff  vmovaps xmm0, [rsp]
000075aec0bd3a04  vmovaps xmm1, [rsp+0x10]
000075aec0bd3a0a  vmovaps xmm2, [rsp+0x20]
000075aec0bd3a10  vmovaps xmm3, [rsp+0x30]
000075aec0bd3a16  vmovaps xmm4, [rsp+0x40]
000075aec0bd3a1c  vmovaps xmm5, [rsp+0x50]
000075aec0bd3a22  vmovaps xmm6, [rsp+0x60]
000075aec0bd3a28  vmovaps xmm7, [rsp+0x70]
000075aec0bd3a2e  vmovaps xmm8, [rsp+0x80]
000075aec0bd3a37  vmovaps xmm10, [rsp+0x90]
000075aec0bd3a40  vmovaps xmm11, [rsp+0xA0]
000075aec0bd3a49  vmovaps xmm12, [rsp+0xB0]
000075aec0bd3a52  vmovaps xmm13, [rsp+0xC0]
000075aec0bd3a5b  vmovaps xmm14, [rsp+0xD0]
000075aec0bd3a64  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3a6d  add rsp, 0xF0
000075aec0bd3a74  pop r11
000075aec0bd3a76  pop r10
000075aec0bd3a78  pop r9
000075aec0bd3a7a  pop r8
000075aec0bd3a7c  pop rsi
000075aec0bd3a7d  pop rdi
000075aec0bd3a7e  pop rdx
000075aec0bd3a7f  pop rcx
000075aec0bd3a80  pop rax
000075aec0bd3a81  add rsp, 0x08
000075aec0bd3a85  jmp 0x000075AEC0BCFFE1
000075aec0bd3a8a  sub rsp, 0x08
000075aec0bd3a8e  push rax
000075aec0bd3a8f  push rcx
000075aec0bd3a90  push rdx
000075aec0bd3a91  push rdi
000075aec0bd3a92  push rsi
000075aec0bd3a93  push r8
000075aec0bd3a95  push r9
000075aec0bd3a97  push r10
000075aec0bd3a99  push r11
000075aec0bd3a9b  sub rsp, 0xF0
000075aec0bd3aa2  vmovaps [rsp], xmm0
000075aec0bd3aa7  vmovaps [rsp+0x10], xmm1
000075aec0bd3aad  vmovaps [rsp+0x20], xmm2
000075aec0bd3ab3  vmovaps [rsp+0x30], xmm3
000075aec0bd3ab9  vmovaps [rsp+0x40], xmm4
000075aec0bd3abf  vmovaps [rsp+0x50], xmm5
000075aec0bd3ac5  vmovaps [rsp+0x60], xmm6
000075aec0bd3acb  vmovaps [rsp+0x70], xmm7
000075aec0bd3ad1  vmovaps [rsp+0x80], xmm8
000075aec0bd3ada  vmovaps [rsp+0x90], xmm9
000075aec0bd3ae3  vmovaps [rsp+0xA0], xmm11
000075aec0bd3aec  vmovaps [rsp+0xB0], xmm12
000075aec0bd3af5  vmovaps [rsp+0xC0], xmm13
000075aec0bd3afe  vmovaps [rsp+0xD0], xmm14
000075aec0bd3b07  vmovaps [rsp+0xE0], xmm15
000075aec0bd3b10  sub rsp, 0x30
000075aec0bd3b14  movaps [rsp], xmm10
000075aec0bd3b19  movaps [rsp+0x10], xmm1
000075aec0bd3b1e  movaps [rsp+0x20], xmm11
000075aec0bd3b24  lea rdi, [rsp]
000075aec0bd3b28  mov esi, 0x00
000075aec0bd3b2d  mov rax, 0x57F4B31E6530
000075aec0bd3b37  call rax
000075aec0bd3b39  movaps xmm10, [rsp]
000075aec0bd3b3e  add rsp, 0x30
000075aec0bd3b42  vmovaps xmm0, [rsp]
000075aec0bd3b47  vmovaps xmm1, [rsp+0x10]
000075aec0bd3b4d  vmovaps xmm2, [rsp+0x20]
000075aec0bd3b53  vmovaps xmm3, [rsp+0x30]
000075aec0bd3b59  vmovaps xmm4, [rsp+0x40]
000075aec0bd3b5f  vmovaps xmm5, [rsp+0x50]
000075aec0bd3b65  vmovaps xmm6, [rsp+0x60]
000075aec0bd3b6b  vmovaps xmm7, [rsp+0x70]
000075aec0bd3b71  vmovaps xmm8, [rsp+0x80]
000075aec0bd3b7a  vmovaps xmm9, [rsp+0x90]
000075aec0bd3b83  vmovaps xmm11, [rsp+0xA0]
000075aec0bd3b8c  vmovaps xmm12, [rsp+0xB0]
000075aec0bd3b95  vmovaps xmm13, [rsp+0xC0]
000075aec0bd3b9e  vmovaps xmm14, [rsp+0xD0]
000075aec0bd3ba7  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3bb0  add rsp, 0xF0
000075aec0bd3bb7  pop r11
000075aec0bd3bb9  pop r10
000075aec0bd3bbb  pop r9
000075aec0bd3bbd  pop r8
000075aec0bd3bbf  pop rsi
000075aec0bd3bc0  pop rdi
000075aec0bd3bc1  pop rdx
000075aec0bd3bc2  pop rcx
000075aec0bd3bc3  pop rax
000075aec0bd3bc4  add rsp, 0x08
000075aec0bd3bc8  jmp 0x000075AEC0BCFFFC
000075aec0bd3bcd  sub rsp, 0x08
000075aec0bd3bd1  push rax
000075aec0bd3bd2  push rcx
000075aec0bd3bd3  push rdx
000075aec0bd3bd4  push rdi
000075aec0bd3bd5  push rsi
000075aec0bd3bd6  push r8
000075aec0bd3bd8  push r9
000075aec0bd3bda  push r10
000075aec0bd3bdc  push r11
000075aec0bd3bde  sub rsp, 0xF0
000075aec0bd3be5  vmovaps [rsp], xmm0
000075aec0bd3bea  vmovaps [rsp+0x10], xmm2
000075aec0bd3bf0  vmovaps [rsp+0x20], xmm3
000075aec0bd3bf6  vmovaps [rsp+0x30], xmm4
000075aec0bd3bfc  vmovaps [rsp+0x40], xmm5
000075aec0bd3c02  vmovaps [rsp+0x50], xmm6
000075aec0bd3c08  vmovaps [rsp+0x60], xmm7
000075aec0bd3c0e  vmovaps [rsp+0x70], xmm8
000075aec0bd3c14  vmovaps [rsp+0x80], xmm9
000075aec0bd3c1d  vmovaps [rsp+0x90], xmm10
000075aec0bd3c26  vmovaps [rsp+0xA0], xmm11
000075aec0bd3c2f  vmovaps [rsp+0xB0], xmm12
000075aec0bd3c38  vmovaps [rsp+0xC0], xmm13
000075aec0bd3c41  vmovaps [rsp+0xD0], xmm14
000075aec0bd3c4a  vmovaps [rsp+0xE0], xmm15
000075aec0bd3c53  sub rsp, 0x30
000075aec0bd3c57  movaps [rsp], xmm1
000075aec0bd3c5b  movaps [rsp+0x10], xmm14
000075aec0bd3c61  movaps [rsp+0x20], xmm6
000075aec0bd3c66  lea rdi, [rsp]
000075aec0bd3c6a  mov esi, 0x00
000075aec0bd3c6f  mov rax, 0x57F4B31E6530
000075aec0bd3c79  call rax
000075aec0bd3c7b  movaps xmm1, [rsp]
000075aec0bd3c7f  add rsp, 0x30
000075aec0bd3c83  vmovaps xmm0, [rsp]
000075aec0bd3c88  vmovaps xmm2, [rsp+0x10]
000075aec0bd3c8e  vmovaps xmm3, [rsp+0x20]
000075aec0bd3c94  vmovaps xmm4, [rsp+0x30]
000075aec0bd3c9a  vmovaps xmm5, [rsp+0x40]
000075aec0bd3ca0  vmovaps xmm6, [rsp+0x50]
000075aec0bd3ca6  vmovaps xmm7, [rsp+0x60]
000075aec0bd3cac  vmovaps xmm8, [rsp+0x70]
000075aec0bd3cb2  vmovaps xmm9, [rsp+0x80]
000075aec0bd3cbb  vmovaps xmm10, [rsp+0x90]
000075aec0bd3cc4  vmovaps xmm11, [rsp+0xA0]
000075aec0bd3ccd  vmovaps xmm12, [rsp+0xB0]
000075aec0bd3cd6  vmovaps xmm13, [rsp+0xC0]
000075aec0bd3cdf  vmovaps xmm14, [rsp+0xD0]
000075aec0bd3ce8  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3cf1  add rsp, 0xF0
000075aec0bd3cf8  pop r11
000075aec0bd3cfa  pop r10
000075aec0bd3cfc  pop r9
000075aec0bd3cfe  pop r8
000075aec0bd3d00  pop rsi
000075aec0bd3d01  pop rdi
000075aec0bd3d02  pop rdx
000075aec0bd3d03  pop rcx
000075aec0bd3d04  pop rax
000075aec0bd3d05  add rsp, 0x08
000075aec0bd3d09  jmp 0x000075AEC0BD0015
000075aec0bd3d0e  sub rsp, 0x08
000075aec0bd3d12  push rax
000075aec0bd3d13  push rcx
000075aec0bd3d14  push rdx
000075aec0bd3d15  push rdi
000075aec0bd3d16  push rsi
000075aec0bd3d17  push r8
000075aec0bd3d19  push r9
000075aec0bd3d1b  push r10
000075aec0bd3d1d  push r11
000075aec0bd3d1f  sub rsp, 0xF0
000075aec0bd3d26  vmovaps [rsp], xmm0
000075aec0bd3d2b  vmovaps [rsp+0x10], xmm1
000075aec0bd3d31  vmovaps [rsp+0x20], xmm2
000075aec0bd3d37  vmovaps [rsp+0x30], xmm3
000075aec0bd3d3d  vmovaps [rsp+0x40], xmm4
000075aec0bd3d43  vmovaps [rsp+0x50], xmm5
000075aec0bd3d49  vmovaps [rsp+0x60], xmm6
000075aec0bd3d4f  vmovaps [rsp+0x70], xmm7
000075aec0bd3d55  vmovaps [rsp+0x80], xmm8
000075aec0bd3d5e  vmovaps [rsp+0x90], xmm9
000075aec0bd3d67  vmovaps [rsp+0xA0], xmm10
000075aec0bd3d70  vmovaps [rsp+0xB0], xmm12
000075aec0bd3d79  vmovaps [rsp+0xC0], xmm13
000075aec0bd3d82  vmovaps [rsp+0xD0], xmm14
000075aec0bd3d8b  vmovaps [rsp+0xE0], xmm15
000075aec0bd3d94  sub rsp, 0x30
000075aec0bd3d98  movaps [rsp], xmm11
000075aec0bd3d9d  movaps [rsp+0x10], xmm13
000075aec0bd3da3  movaps [rsp+0x20], xmm14
000075aec0bd3da9  lea rdi, [rsp]
000075aec0bd3dad  mov esi, 0x00
000075aec0bd3db2  mov rax, 0x57F4B31E6530
000075aec0bd3dbc  call rax
000075aec0bd3dbe  movaps xmm11, [rsp]
000075aec0bd3dc3  add rsp, 0x30
000075aec0bd3dc7  vmovaps xmm0, [rsp]
000075aec0bd3dcc  vmovaps xmm1, [rsp+0x10]
000075aec0bd3dd2  vmovaps xmm2, [rsp+0x20]
000075aec0bd3dd8  vmovaps xmm3, [rsp+0x30]
000075aec0bd3dde  vmovaps xmm4, [rsp+0x40]
000075aec0bd3de4  vmovaps xmm5, [rsp+0x50]
000075aec0bd3dea  vmovaps xmm6, [rsp+0x60]
000075aec0bd3df0  vmovaps xmm7, [rsp+0x70]
000075aec0bd3df6  vmovaps xmm8, [rsp+0x80]
000075aec0bd3dff  vmovaps xmm9, [rsp+0x90]
000075aec0bd3e08  vmovaps xmm10, [rsp+0xA0]
000075aec0bd3e11  vmovaps xmm12, [rsp+0xB0]
000075aec0bd3e1a  vmovaps xmm13, [rsp+0xC0]
000075aec0bd3e23  vmovaps xmm14, [rsp+0xD0]
000075aec0bd3e2c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3e35  add rsp, 0xF0
000075aec0bd3e3c  pop r11
000075aec0bd3e3e  pop r10
000075aec0bd3e40  pop r9
000075aec0bd3e42  pop r8
000075aec0bd3e44  pop rsi
000075aec0bd3e45  pop rdi
000075aec0bd3e46  pop rdx
000075aec0bd3e47  pop rcx
000075aec0bd3e48  pop rax
000075aec0bd3e49  add rsp, 0x08
000075aec0bd3e4d  jmp 0x000075AEC0BD003F
000075aec0bd3e52  sub rsp, 0x08
000075aec0bd3e56  push rax
000075aec0bd3e57  push rcx
000075aec0bd3e58  push rdx
000075aec0bd3e59  push rdi
000075aec0bd3e5a  push rsi
000075aec0bd3e5b  push r8
000075aec0bd3e5d  push r9
000075aec0bd3e5f  push r10
000075aec0bd3e61  push r11
000075aec0bd3e63  sub rsp, 0xF0
000075aec0bd3e6a  vmovaps [rsp], xmm0
000075aec0bd3e6f  vmovaps [rsp+0x10], xmm1
000075aec0bd3e75  vmovaps [rsp+0x20], xmm2
000075aec0bd3e7b  vmovaps [rsp+0x30], xmm3
000075aec0bd3e81  vmovaps [rsp+0x40], xmm4
000075aec0bd3e87  vmovaps [rsp+0x50], xmm5
000075aec0bd3e8d  vmovaps [rsp+0x60], xmm6
000075aec0bd3e93  vmovaps [rsp+0x70], xmm7
000075aec0bd3e99  vmovaps [rsp+0x80], xmm8
000075aec0bd3ea2  vmovaps [rsp+0x90], xmm9
000075aec0bd3eab  vmovaps [rsp+0xA0], xmm10
000075aec0bd3eb4  vmovaps [rsp+0xB0], xmm11
000075aec0bd3ebd  vmovaps [rsp+0xC0], xmm12
000075aec0bd3ec6  vmovaps [rsp+0xD0], xmm14
000075aec0bd3ecf  vmovaps [rsp+0xE0], xmm15
000075aec0bd3ed8  sub rsp, 0x30
000075aec0bd3edc  movaps [rsp], xmm13
000075aec0bd3ee1  movaps [rsp+0x10], xmm8
000075aec0bd3ee7  movaps [rsp+0x20], xmm14
000075aec0bd3eed  lea rdi, [rsp]
000075aec0bd3ef1  mov esi, 0x00
000075aec0bd3ef6  mov rax, 0x57F4B31E6530
000075aec0bd3f00  call rax
000075aec0bd3f02  movaps xmm13, [rsp]
000075aec0bd3f07  add rsp, 0x30
000075aec0bd3f0b  vmovaps xmm0, [rsp]
000075aec0bd3f10  vmovaps xmm1, [rsp+0x10]
000075aec0bd3f16  vmovaps xmm2, [rsp+0x20]
000075aec0bd3f1c  vmovaps xmm3, [rsp+0x30]
000075aec0bd3f22  vmovaps xmm4, [rsp+0x40]
000075aec0bd3f28  vmovaps xmm5, [rsp+0x50]
000075aec0bd3f2e  vmovaps xmm6, [rsp+0x60]
000075aec0bd3f34  vmovaps xmm7, [rsp+0x70]
000075aec0bd3f3a  vmovaps xmm8, [rsp+0x80]
000075aec0bd3f43  vmovaps xmm9, [rsp+0x90]
000075aec0bd3f4c  vmovaps xmm10, [rsp+0xA0]
000075aec0bd3f55  vmovaps xmm11, [rsp+0xB0]
000075aec0bd3f5e  vmovaps xmm12, [rsp+0xC0]
000075aec0bd3f67  vmovaps xmm14, [rsp+0xD0]
000075aec0bd3f70  vmovaps xmm15, [rsp+0xE0]
000075aec0bd3f79  add rsp, 0xF0
000075aec0bd3f80  pop r11
000075aec0bd3f82  pop r10
000075aec0bd3f84  pop r9
000075aec0bd3f86  pop r8
000075aec0bd3f88  pop rsi
000075aec0bd3f89  pop rdi
000075aec0bd3f8a  pop rdx
000075aec0bd3f8b  pop rcx
000075aec0bd3f8c  pop rax
000075aec0bd3f8d  add rsp, 0x08
000075aec0bd3f91  jmp 0x000075AEC0BD006E
000075aec0bd3f96  sub rsp, 0x08
000075aec0bd3f9a  push rax
000075aec0bd3f9b  push rcx
000075aec0bd3f9c  push rdx
000075aec0bd3f9d  push rdi
000075aec0bd3f9e  push rsi
000075aec0bd3f9f  push r8
000075aec0bd3fa1  push r9
000075aec0bd3fa3  push r10
000075aec0bd3fa5  push r11
000075aec0bd3fa7  sub rsp, 0xF0
000075aec0bd3fae  vmovaps [rsp], xmm0
000075aec0bd3fb3  vmovaps [rsp+0x10], xmm1
000075aec0bd3fb9  vmovaps [rsp+0x20], xmm2
000075aec0bd3fbf  vmovaps [rsp+0x30], xmm3
000075aec0bd3fc5  vmovaps [rsp+0x40], xmm4
000075aec0bd3fcb  vmovaps [rsp+0x50], xmm5
000075aec0bd3fd1  vmovaps [rsp+0x60], xmm6
000075aec0bd3fd7  vmovaps [rsp+0x70], xmm7
000075aec0bd3fdd  vmovaps [rsp+0x80], xmm9
000075aec0bd3fe6  vmovaps [rsp+0x90], xmm10
000075aec0bd3fef  vmovaps [rsp+0xA0], xmm11
000075aec0bd3ff8  vmovaps [rsp+0xB0], xmm12
000075aec0bd4001  vmovaps [rsp+0xC0], xmm13
000075aec0bd400a  vmovaps [rsp+0xD0], xmm14
000075aec0bd4013  vmovaps [rsp+0xE0], xmm15
000075aec0bd401c  sub rsp, 0x30
000075aec0bd4020  movaps [rsp], xmm8
000075aec0bd4025  movaps [rsp+0x10], xmm7
000075aec0bd402a  movaps [rsp+0x20], xmm14
000075aec0bd4030  lea rdi, [rsp]
000075aec0bd4034  mov esi, 0x00
000075aec0bd4039  mov rax, 0x57F4B31E6530
000075aec0bd4043  call rax
000075aec0bd4045  movaps xmm8, [rsp]
000075aec0bd404a  add rsp, 0x30
000075aec0bd404e  vmovaps xmm0, [rsp]
000075aec0bd4053  vmovaps xmm1, [rsp+0x10]
000075aec0bd4059  vmovaps xmm2, [rsp+0x20]
000075aec0bd405f  vmovaps xmm3, [rsp+0x30]
000075aec0bd4065  vmovaps xmm4, [rsp+0x40]
000075aec0bd406b  vmovaps xmm5, [rsp+0x50]
000075aec0bd4071  vmovaps xmm6, [rsp+0x60]
000075aec0bd4077  vmovaps xmm7, [rsp+0x70]
000075aec0bd407d  vmovaps xmm9, [rsp+0x80]
000075aec0bd4086  vmovaps xmm10, [rsp+0x90]
000075aec0bd408f  vmovaps xmm11, [rsp+0xA0]
000075aec0bd4098  vmovaps xmm12, [rsp+0xB0]
000075aec0bd40a1  vmovaps xmm13, [rsp+0xC0]
000075aec0bd40aa  vmovaps xmm14, [rsp+0xD0]
000075aec0bd40b3  vmovaps xmm15, [rsp+0xE0]
000075aec0bd40bc  add rsp, 0xF0
000075aec0bd40c3  pop r11
000075aec0bd40c5  pop r10
000075aec0bd40c7  pop r9
000075aec0bd40c9  pop r8
000075aec0bd40cb  pop rsi
000075aec0bd40cc  pop rdi
000075aec0bd40cd  pop rdx
000075aec0bd40ce  pop rcx
000075aec0bd40cf  pop rax
000075aec0bd40d0  add rsp, 0x08
000075aec0bd40d4  jmp 0x000075AEC0BD0094
000075aec0bd40d9  sub rsp, 0x08
000075aec0bd40dd  push rax
000075aec0bd40de  push rcx
000075aec0bd40df  push rdx
000075aec0bd40e0  push rdi
000075aec0bd40e1  push rsi
000075aec0bd40e2  push r8
000075aec0bd40e4  push r9
000075aec0bd40e6  push r10
000075aec0bd40e8  push r11
000075aec0bd40ea  sub rsp, 0xF0
000075aec0bd40f1  vmovaps [rsp], xmm0
000075aec0bd40f6  vmovaps [rsp+0x10], xmm1
000075aec0bd40fc  vmovaps [rsp+0x20], xmm2
000075aec0bd4102  vmovaps [rsp+0x30], xmm3
000075aec0bd4108  vmovaps [rsp+0x40], xmm4
000075aec0bd410e  vmovaps [rsp+0x50], xmm5
000075aec0bd4114  vmovaps [rsp+0x60], xmm6
000075aec0bd411a  vmovaps [rsp+0x70], xmm7
000075aec0bd4120  vmovaps [rsp+0x80], xmm8
000075aec0bd4129  vmovaps [rsp+0x90], xmm9
000075aec0bd4132  vmovaps [rsp+0xA0], xmm10
000075aec0bd413b  vmovaps [rsp+0xB0], xmm11
000075aec0bd4144  vmovaps [rsp+0xC0], xmm12
000075aec0bd414d  vmovaps [rsp+0xD0], xmm13
000075aec0bd4156  vmovaps [rsp+0xE0], xmm15
000075aec0bd415f  sub rsp, 0x30
000075aec0bd4163  movaps [rsp], xmm14
000075aec0bd4168  movaps [rsp+0x10], xmm12
000075aec0bd416e  movaps [rsp+0x20], xmm9
000075aec0bd4174  lea rdi, [rsp]
000075aec0bd4178  mov esi, 0x00
000075aec0bd417d  mov rax, 0x57F4B31E6530
000075aec0bd4187  call rax
000075aec0bd4189  movaps xmm14, [rsp]
000075aec0bd418e  add rsp, 0x30
000075aec0bd4192  vmovaps xmm0, [rsp]
000075aec0bd4197  vmovaps xmm1, [rsp+0x10]
000075aec0bd419d  vmovaps xmm2, [rsp+0x20]
000075aec0bd41a3  vmovaps xmm3, [rsp+0x30]
000075aec0bd41a9  vmovaps xmm4, [rsp+0x40]
000075aec0bd41af  vmovaps xmm5, [rsp+0x50]
000075aec0bd41b5  vmovaps xmm6, [rsp+0x60]
000075aec0bd41bb  vmovaps xmm7, [rsp+0x70]
000075aec0bd41c1  vmovaps xmm8, [rsp+0x80]
000075aec0bd41ca  vmovaps xmm9, [rsp+0x90]
000075aec0bd41d3  vmovaps xmm10, [rsp+0xA0]
000075aec0bd41dc  vmovaps xmm11, [rsp+0xB0]
000075aec0bd41e5  vmovaps xmm12, [rsp+0xC0]
000075aec0bd41ee  vmovaps xmm13, [rsp+0xD0]
000075aec0bd41f7  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4200  add rsp, 0xF0
000075aec0bd4207  pop r11
000075aec0bd4209  pop r10
000075aec0bd420b  pop r9
000075aec0bd420d  pop r8
000075aec0bd420f  pop rsi
000075aec0bd4210  pop rdi
000075aec0bd4211  pop rdx
000075aec0bd4212  pop rcx
000075aec0bd4213  pop rax
000075aec0bd4214  add rsp, 0x08
000075aec0bd4218  jmp 0x000075AEC0BD00AE
000075aec0bd421d  sub rsp, 0x08
000075aec0bd4221  push rax
000075aec0bd4222  push rcx
000075aec0bd4223  push rdx
000075aec0bd4224  push rdi
000075aec0bd4225  push rsi
000075aec0bd4226  push r8
000075aec0bd4228  push r9
000075aec0bd422a  push r10
000075aec0bd422c  push r11
000075aec0bd422e  sub rsp, 0xF0
000075aec0bd4235  vmovaps [rsp], xmm0
000075aec0bd423a  vmovaps [rsp+0x10], xmm1
000075aec0bd4240  vmovaps [rsp+0x20], xmm2
000075aec0bd4246  vmovaps [rsp+0x30], xmm3
000075aec0bd424c  vmovaps [rsp+0x40], xmm4
000075aec0bd4252  vmovaps [rsp+0x50], xmm5
000075aec0bd4258  vmovaps [rsp+0x60], xmm6
000075aec0bd425e  vmovaps [rsp+0x70], xmm7
000075aec0bd4264  vmovaps [rsp+0x80], xmm8
000075aec0bd426d  vmovaps [rsp+0x90], xmm10
000075aec0bd4276  vmovaps [rsp+0xA0], xmm11
000075aec0bd427f  vmovaps [rsp+0xB0], xmm12
000075aec0bd4288  vmovaps [rsp+0xC0], xmm13
000075aec0bd4291  vmovaps [rsp+0xD0], xmm14
000075aec0bd429a  vmovaps [rsp+0xE0], xmm15
000075aec0bd42a3  sub rsp, 0x30
000075aec0bd42a7  movaps [rsp], xmm9
000075aec0bd42ac  movaps [rsp+0x10], xmm7
000075aec0bd42b1  movaps [rsp+0x20], xmm12
000075aec0bd42b7  lea rdi, [rsp]
000075aec0bd42bb  mov esi, 0x00
000075aec0bd42c0  mov rax, 0x57F4B31E6530
000075aec0bd42ca  call rax
000075aec0bd42cc  movaps xmm9, [rsp]
000075aec0bd42d1  add rsp, 0x30
000075aec0bd42d5  vmovaps xmm0, [rsp]
000075aec0bd42da  vmovaps xmm1, [rsp+0x10]
000075aec0bd42e0  vmovaps xmm2, [rsp+0x20]
000075aec0bd42e6  vmovaps xmm3, [rsp+0x30]
000075aec0bd42ec  vmovaps xmm4, [rsp+0x40]
000075aec0bd42f2  vmovaps xmm5, [rsp+0x50]
000075aec0bd42f8  vmovaps xmm6, [rsp+0x60]
000075aec0bd42fe  vmovaps xmm7, [rsp+0x70]
000075aec0bd4304  vmovaps xmm8, [rsp+0x80]
000075aec0bd430d  vmovaps xmm10, [rsp+0x90]
000075aec0bd4316  vmovaps xmm11, [rsp+0xA0]
000075aec0bd431f  vmovaps xmm12, [rsp+0xB0]
000075aec0bd4328  vmovaps xmm13, [rsp+0xC0]
000075aec0bd4331  vmovaps xmm14, [rsp+0xD0]
000075aec0bd433a  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4343  add rsp, 0xF0
000075aec0bd434a  pop r11
000075aec0bd434c  pop r10
000075aec0bd434e  pop r9
000075aec0bd4350  pop r8
000075aec0bd4352  pop rsi
000075aec0bd4353  pop rdi
000075aec0bd4354  pop rdx
000075aec0bd4355  pop rcx
000075aec0bd4356  pop rax
000075aec0bd4357  add rsp, 0x08
000075aec0bd435b  jmp 0x000075AEC0BD00DD
000075aec0bd4360  sub rsp, 0x08
000075aec0bd4364  push rax
000075aec0bd4365  push rcx
000075aec0bd4366  push rdx
000075aec0bd4367  push rdi
000075aec0bd4368  push rsi
000075aec0bd4369  push r8
000075aec0bd436b  push r9
000075aec0bd436d  push r10
000075aec0bd436f  push r11
000075aec0bd4371  sub rsp, 0xF0
000075aec0bd4378  vmovaps [rsp], xmm0
000075aec0bd437d  vmovaps [rsp+0x10], xmm1
000075aec0bd4383  vmovaps [rsp+0x20], xmm2
000075aec0bd4389  vmovaps [rsp+0x30], xmm3
000075aec0bd438f  vmovaps [rsp+0x40], xmm4
000075aec0bd4395  vmovaps [rsp+0x50], xmm5
000075aec0bd439b  vmovaps [rsp+0x60], xmm6
000075aec0bd43a1  vmovaps [rsp+0x70], xmm7
000075aec0bd43a7  vmovaps [rsp+0x80], xmm8
000075aec0bd43b0  vmovaps [rsp+0x90], xmm9
000075aec0bd43b9  vmovaps [rsp+0xA0], xmm10
000075aec0bd43c2  vmovaps [rsp+0xB0], xmm11
000075aec0bd43cb  vmovaps [rsp+0xC0], xmm13
000075aec0bd43d4  vmovaps [rsp+0xD0], xmm14
000075aec0bd43dd  vmovaps [rsp+0xE0], xmm15
000075aec0bd43e6  sub rsp, 0x30
000075aec0bd43ea  movaps [rsp], xmm12
000075aec0bd43ef  movaps [rsp+0x10], xmm15
000075aec0bd43f5  movaps [rsp+0x20], xmm11
000075aec0bd43fb  lea rdi, [rsp]
000075aec0bd43ff  mov esi, 0x00
000075aec0bd4404  mov rax, 0x57F4B31E6530
000075aec0bd440e  call rax
000075aec0bd4410  movaps xmm12, [rsp]
000075aec0bd4415  add rsp, 0x30
000075aec0bd4419  vmovaps xmm0, [rsp]
000075aec0bd441e  vmovaps xmm1, [rsp+0x10]
000075aec0bd4424  vmovaps xmm2, [rsp+0x20]
000075aec0bd442a  vmovaps xmm3, [rsp+0x30]
000075aec0bd4430  vmovaps xmm4, [rsp+0x40]
000075aec0bd4436  vmovaps xmm5, [rsp+0x50]
000075aec0bd443c  vmovaps xmm6, [rsp+0x60]
000075aec0bd4442  vmovaps xmm7, [rsp+0x70]
000075aec0bd4448  vmovaps xmm8, [rsp+0x80]
000075aec0bd4451  vmovaps xmm9, [rsp+0x90]
000075aec0bd445a  vmovaps xmm10, [rsp+0xA0]
000075aec0bd4463  vmovaps xmm11, [rsp+0xB0]
000075aec0bd446c  vmovaps xmm13, [rsp+0xC0]
000075aec0bd4475  vmovaps xmm14, [rsp+0xD0]
000075aec0bd447e  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4487  add rsp, 0xF0
000075aec0bd448e  pop r11
000075aec0bd4490  pop r10
000075aec0bd4492  pop r9
000075aec0bd4494  pop r8
000075aec0bd4496  pop rsi
000075aec0bd4497  pop rdi
000075aec0bd4498  pop rdx
000075aec0bd4499  pop rcx
000075aec0bd449a  pop rax
000075aec0bd449b  add rsp, 0x08
000075aec0bd449f  jmp 0x000075AEC0BD00F7
000075aec0bd44a4  sub rsp, 0x08
000075aec0bd44a8  push rax
000075aec0bd44a9  push rcx
000075aec0bd44aa  push rdx
000075aec0bd44ab  push rdi
000075aec0bd44ac  push rsi
000075aec0bd44ad  push r8
000075aec0bd44af  push r9
000075aec0bd44b1  push r10
000075aec0bd44b3  push r11
000075aec0bd44b5  sub rsp, 0xF0
000075aec0bd44bc  vmovaps [rsp], xmm0
000075aec0bd44c1  vmovaps [rsp+0x10], xmm1
000075aec0bd44c7  vmovaps [rsp+0x20], xmm2
000075aec0bd44cd  vmovaps [rsp+0x30], xmm3
000075aec0bd44d3  vmovaps [rsp+0x40], xmm4
000075aec0bd44d9  vmovaps [rsp+0x50], xmm5
000075aec0bd44df  vmovaps [rsp+0x60], xmm6
000075aec0bd44e5  vmovaps [rsp+0x70], xmm7
000075aec0bd44eb  vmovaps [rsp+0x80], xmm8
000075aec0bd44f4  vmovaps [rsp+0x90], xmm9
000075aec0bd44fd  vmovaps [rsp+0xA0], xmm10
000075aec0bd4506  vmovaps [rsp+0xB0], xmm12
000075aec0bd450f  vmovaps [rsp+0xC0], xmm13
000075aec0bd4518  vmovaps [rsp+0xD0], xmm14
000075aec0bd4521  vmovaps [rsp+0xE0], xmm15
000075aec0bd452a  sub rsp, 0x30
000075aec0bd452e  movaps [rsp], xmm11
000075aec0bd4533  movaps [rsp+0x10], xmm7
000075aec0bd4538  movaps [rsp+0x20], xmm15
000075aec0bd453e  lea rdi, [rsp]
000075aec0bd4542  mov esi, 0x00
000075aec0bd4547  mov rax, 0x57F4B31E6530
000075aec0bd4551  call rax
000075aec0bd4553  movaps xmm11, [rsp]
000075aec0bd4558  add rsp, 0x30
000075aec0bd455c  vmovaps xmm0, [rsp]
000075aec0bd4561  vmovaps xmm1, [rsp+0x10]
000075aec0bd4567  vmovaps xmm2, [rsp+0x20]
000075aec0bd456d  vmovaps xmm3, [rsp+0x30]
000075aec0bd4573  vmovaps xmm4, [rsp+0x40]
000075aec0bd4579  vmovaps xmm5, [rsp+0x50]
000075aec0bd457f  vmovaps xmm6, [rsp+0x60]
000075aec0bd4585  vmovaps xmm7, [rsp+0x70]
000075aec0bd458b  vmovaps xmm8, [rsp+0x80]
000075aec0bd4594  vmovaps xmm9, [rsp+0x90]
000075aec0bd459d  vmovaps xmm10, [rsp+0xA0]
000075aec0bd45a6  vmovaps xmm12, [rsp+0xB0]
000075aec0bd45af  vmovaps xmm13, [rsp+0xC0]
000075aec0bd45b8  vmovaps xmm14, [rsp+0xD0]
000075aec0bd45c1  vmovaps xmm15, [rsp+0xE0]
000075aec0bd45ca  add rsp, 0xF0
000075aec0bd45d1  pop r11
000075aec0bd45d3  pop r10
000075aec0bd45d5  pop r9
000075aec0bd45d7  pop r8
000075aec0bd45d9  pop rsi
000075aec0bd45da  pop rdi
000075aec0bd45db  pop rdx
000075aec0bd45dc  pop rcx
000075aec0bd45dd  pop rax
000075aec0bd45de  add rsp, 0x08
000075aec0bd45e2  jmp 0x000075AEC0BD0123
000075aec0bd45e7  sub rsp, 0x08
000075aec0bd45eb  push rax
000075aec0bd45ec  push rcx
000075aec0bd45ed  push rdx
000075aec0bd45ee  push rdi
000075aec0bd45ef  push rsi
000075aec0bd45f0  push r8
000075aec0bd45f2  push r9
000075aec0bd45f4  push r10
000075aec0bd45f6  push r11
000075aec0bd45f8  sub rsp, 0xF0
000075aec0bd45ff  vmovaps [rsp], xmm0
000075aec0bd4604  vmovaps [rsp+0x10], xmm1
000075aec0bd460a  vmovaps [rsp+0x20], xmm2
000075aec0bd4610  vmovaps [rsp+0x30], xmm3
000075aec0bd4616  vmovaps [rsp+0x40], xmm4
000075aec0bd461c  vmovaps [rsp+0x50], xmm5
000075aec0bd4622  vmovaps [rsp+0x60], xmm6
000075aec0bd4628  vmovaps [rsp+0x70], xmm7
000075aec0bd462e  vmovaps [rsp+0x80], xmm8
000075aec0bd4637  vmovaps [rsp+0x90], xmm9
000075aec0bd4640  vmovaps [rsp+0xA0], xmm10
000075aec0bd4649  vmovaps [rsp+0xB0], xmm11
000075aec0bd4652  vmovaps [rsp+0xC0], xmm12
000075aec0bd465b  vmovaps [rsp+0xD0], xmm13
000075aec0bd4664  vmovaps [rsp+0xE0], xmm14
000075aec0bd466d  sub rsp, 0x30
000075aec0bd4671  movaps [rsp], xmm15
000075aec0bd4676  movaps [rsp+0x10], xmm10
000075aec0bd467c  movaps [rsp+0x20], xmm13
000075aec0bd4682  lea rdi, [rsp]
000075aec0bd4686  mov esi, 0x00
000075aec0bd468b  mov rax, 0x57F4B31E6530
000075aec0bd4695  call rax
000075aec0bd4697  movaps xmm15, [rsp]
000075aec0bd469c  add rsp, 0x30
000075aec0bd46a0  vmovaps xmm0, [rsp]
000075aec0bd46a5  vmovaps xmm1, [rsp+0x10]
000075aec0bd46ab  vmovaps xmm2, [rsp+0x20]
000075aec0bd46b1  vmovaps xmm3, [rsp+0x30]
000075aec0bd46b7  vmovaps xmm4, [rsp+0x40]
000075aec0bd46bd  vmovaps xmm5, [rsp+0x50]
000075aec0bd46c3  vmovaps xmm6, [rsp+0x60]
000075aec0bd46c9  vmovaps xmm7, [rsp+0x70]
000075aec0bd46cf  vmovaps xmm8, [rsp+0x80]
000075aec0bd46d8  vmovaps xmm9, [rsp+0x90]
000075aec0bd46e1  vmovaps xmm10, [rsp+0xA0]
000075aec0bd46ea  vmovaps xmm11, [rsp+0xB0]
000075aec0bd46f3  vmovaps xmm12, [rsp+0xC0]
000075aec0bd46fc  vmovaps xmm13, [rsp+0xD0]
000075aec0bd4705  vmovaps xmm14, [rsp+0xE0]
000075aec0bd470e  add rsp, 0xF0
000075aec0bd4715  pop r11
000075aec0bd4717  pop r10
000075aec0bd4719  pop r9
000075aec0bd471b  pop r8
000075aec0bd471d  pop rsi
000075aec0bd471e  pop rdi
000075aec0bd471f  pop rdx
000075aec0bd4720  pop rcx
000075aec0bd4721  pop rax
000075aec0bd4722  add rsp, 0x08
000075aec0bd4726  jmp 0x000075AEC0BD013D
000075aec0bd472b  sub rsp, 0x08
000075aec0bd472f  push rax
000075aec0bd4730  push rcx
000075aec0bd4731  push rdx
000075aec0bd4732  push rdi
000075aec0bd4733  push rsi
000075aec0bd4734  push r8
000075aec0bd4736  push r9
000075aec0bd4738  push r10
000075aec0bd473a  push r11
000075aec0bd473c  sub rsp, 0xF0
000075aec0bd4743  vmovaps [rsp], xmm0
000075aec0bd4748  vmovaps [rsp+0x10], xmm1
000075aec0bd474e  vmovaps [rsp+0x20], xmm2
000075aec0bd4754  vmovaps [rsp+0x30], xmm3
000075aec0bd475a  vmovaps [rsp+0x40], xmm4
000075aec0bd4760  vmovaps [rsp+0x50], xmm5
000075aec0bd4766  vmovaps [rsp+0x60], xmm6
000075aec0bd476c  vmovaps [rsp+0x70], xmm7
000075aec0bd4772  vmovaps [rsp+0x80], xmm8
000075aec0bd477b  vmovaps [rsp+0x90], xmm9
000075aec0bd4784  vmovaps [rsp+0xA0], xmm11
000075aec0bd478d  vmovaps [rsp+0xB0], xmm12
000075aec0bd4796  vmovaps [rsp+0xC0], xmm13
000075aec0bd479f  vmovaps [rsp+0xD0], xmm14
000075aec0bd47a8  vmovaps [rsp+0xE0], xmm15
000075aec0bd47b1  sub rsp, 0x30
000075aec0bd47b5  movaps [rsp], xmm10
000075aec0bd47ba  movaps [rsp+0x10], xmm7
000075aec0bd47bf  movaps [rsp+0x20], xmm13
000075aec0bd47c5  lea rdi, [rsp]
000075aec0bd47c9  mov esi, 0x00
000075aec0bd47ce  mov rax, 0x57F4B31E6530
000075aec0bd47d8  call rax
000075aec0bd47da  movaps xmm10, [rsp]
000075aec0bd47df  add rsp, 0x30
000075aec0bd47e3  vmovaps xmm0, [rsp]
000075aec0bd47e8  vmovaps xmm1, [rsp+0x10]
000075aec0bd47ee  vmovaps xmm2, [rsp+0x20]
000075aec0bd47f4  vmovaps xmm3, [rsp+0x30]
000075aec0bd47fa  vmovaps xmm4, [rsp+0x40]
000075aec0bd4800  vmovaps xmm5, [rsp+0x50]
000075aec0bd4806  vmovaps xmm6, [rsp+0x60]
000075aec0bd480c  vmovaps xmm7, [rsp+0x70]
000075aec0bd4812  vmovaps xmm8, [rsp+0x80]
000075aec0bd481b  vmovaps xmm9, [rsp+0x90]
000075aec0bd4824  vmovaps xmm11, [rsp+0xA0]
000075aec0bd482d  vmovaps xmm12, [rsp+0xB0]
000075aec0bd4836  vmovaps xmm13, [rsp+0xC0]
000075aec0bd483f  vmovaps xmm14, [rsp+0xD0]
000075aec0bd4848  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4851  add rsp, 0xF0
000075aec0bd4858  pop r11
000075aec0bd485a  pop r10
000075aec0bd485c  pop r9
000075aec0bd485e  pop r8
000075aec0bd4860  pop rsi
000075aec0bd4861  pop rdi
000075aec0bd4862  pop rdx
000075aec0bd4863  pop rcx
000075aec0bd4864  pop rax
000075aec0bd4865  add rsp, 0x08
000075aec0bd4869  jmp 0x000075AEC0BD0169
000075aec0bd486e  sub rsp, 0x08
000075aec0bd4872  push rax
000075aec0bd4873  push rcx
000075aec0bd4874  push rdx
000075aec0bd4875  push rdi
000075aec0bd4876  push rsi
000075aec0bd4877  push r8
000075aec0bd4879  push r9
000075aec0bd487b  push r10
000075aec0bd487d  push r11
000075aec0bd487f  sub rsp, 0xF0
000075aec0bd4886  vmovaps [rsp], xmm0
000075aec0bd488b  vmovaps [rsp+0x10], xmm1
000075aec0bd4891  vmovaps [rsp+0x20], xmm2
000075aec0bd4897  vmovaps [rsp+0x30], xmm3
000075aec0bd489d  vmovaps [rsp+0x40], xmm4
000075aec0bd48a3  vmovaps [rsp+0x50], xmm5
000075aec0bd48a9  vmovaps [rsp+0x60], xmm6
000075aec0bd48af  vmovaps [rsp+0x70], xmm7
000075aec0bd48b5  vmovaps [rsp+0x80], xmm8
000075aec0bd48be  vmovaps [rsp+0x90], xmm9
000075aec0bd48c7  vmovaps [rsp+0xA0], xmm10
000075aec0bd48d0  vmovaps [rsp+0xB0], xmm11
000075aec0bd48d9  vmovaps [rsp+0xC0], xmm12
000075aec0bd48e2  vmovaps [rsp+0xD0], xmm14
000075aec0bd48eb  vmovaps [rsp+0xE0], xmm15
000075aec0bd48f4  sub rsp, 0x30
000075aec0bd48f8  movaps [rsp], xmm13
000075aec0bd48fd  movaps [rsp+0x10], xmm1
000075aec0bd4902  movaps [rsp+0x20], xmm8
000075aec0bd4908  lea rdi, [rsp]
000075aec0bd490c  mov esi, 0x00
000075aec0bd4911  mov rax, 0x57F4B31E6530
000075aec0bd491b  call rax
000075aec0bd491d  movaps xmm13, [rsp]
000075aec0bd4922  add rsp, 0x30
000075aec0bd4926  vmovaps xmm0, [rsp]
000075aec0bd492b  vmovaps xmm1, [rsp+0x10]
000075aec0bd4931  vmovaps xmm2, [rsp+0x20]
000075aec0bd4937  vmovaps xmm3, [rsp+0x30]
000075aec0bd493d  vmovaps xmm4, [rsp+0x40]
000075aec0bd4943  vmovaps xmm5, [rsp+0x50]
000075aec0bd4949  vmovaps xmm6, [rsp+0x60]
000075aec0bd494f  vmovaps xmm7, [rsp+0x70]
000075aec0bd4955  vmovaps xmm8, [rsp+0x80]
000075aec0bd495e  vmovaps xmm9, [rsp+0x90]
000075aec0bd4967  vmovaps xmm10, [rsp+0xA0]
000075aec0bd4970  vmovaps xmm11, [rsp+0xB0]
000075aec0bd4979  vmovaps xmm12, [rsp+0xC0]
000075aec0bd4982  vmovaps xmm14, [rsp+0xD0]
000075aec0bd498b  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4994  add rsp, 0xF0
000075aec0bd499b  pop r11
000075aec0bd499d  pop r10
000075aec0bd499f  pop r9
000075aec0bd49a1  pop r8
000075aec0bd49a3  pop rsi
000075aec0bd49a4  pop rdi
000075aec0bd49a5  pop rdx
000075aec0bd49a6  pop rcx
000075aec0bd49a7  pop rax
000075aec0bd49a8  add rsp, 0x08
000075aec0bd49ac  jmp 0x000075AEC0BD0183
000075aec0bd49b1  call 0x000075AEC09FF430
000075aec0bd49b6  jmp 0x000075AEC0BD018D
000075aec0bd49bb  sub rsp, 0x08
000075aec0bd49bf  push rax
000075aec0bd49c0  push rcx
000075aec0bd49c1  push rdx
000075aec0bd49c2  push rdi
000075aec0bd49c3  push rsi
000075aec0bd49c4  push r8
000075aec0bd49c6  push r9
000075aec0bd49c8  push r10
000075aec0bd49ca  push r11
000075aec0bd49cc  sub rsp, 0xF0
000075aec0bd49d3  vmovaps [rsp], xmm0
000075aec0bd49d8  vmovaps [rsp+0x10], xmm1
000075aec0bd49de  vmovaps [rsp+0x20], xmm2
000075aec0bd49e4  vmovaps [rsp+0x30], xmm3
000075aec0bd49ea  vmovaps [rsp+0x40], xmm4
000075aec0bd49f0  vmovaps [rsp+0x50], xmm5
000075aec0bd49f6  vmovaps [rsp+0x60], xmm6
000075aec0bd49fc  vmovaps [rsp+0x70], xmm7
000075aec0bd4a02  vmovaps [rsp+0x80], xmm9
000075aec0bd4a0b  vmovaps [rsp+0x90], xmm10
000075aec0bd4a14  vmovaps [rsp+0xA0], xmm11
000075aec0bd4a1d  vmovaps [rsp+0xB0], xmm12
000075aec0bd4a26  vmovaps [rsp+0xC0], xmm13
000075aec0bd4a2f  vmovaps [rsp+0xD0], xmm14
000075aec0bd4a38  vmovaps [rsp+0xE0], xmm15
000075aec0bd4a41  sub rsp, 0x30
000075aec0bd4a45  movaps [rsp], xmm8
000075aec0bd4a4a  movaps [rsp+0x10], xmm14
000075aec0bd4a50  movaps [rsp+0x20], xmm9
000075aec0bd4a56  lea rdi, [rsp]
000075aec0bd4a5a  mov esi, 0x00
000075aec0bd4a5f  mov rax, 0x57F4B31E6530
000075aec0bd4a69  call rax
000075aec0bd4a6b  movaps xmm8, [rsp]
000075aec0bd4a70  add rsp, 0x30
000075aec0bd4a74  vmovaps xmm0, [rsp]
000075aec0bd4a79  vmovaps xmm1, [rsp+0x10]
000075aec0bd4a7f  vmovaps xmm2, [rsp+0x20]
000075aec0bd4a85  vmovaps xmm3, [rsp+0x30]
000075aec0bd4a8b  vmovaps xmm4, [rsp+0x40]
000075aec0bd4a91  vmovaps xmm5, [rsp+0x50]
000075aec0bd4a97  vmovaps xmm6, [rsp+0x60]
000075aec0bd4a9d  vmovaps xmm7, [rsp+0x70]
000075aec0bd4aa3  vmovaps xmm9, [rsp+0x80]
000075aec0bd4aac  vmovaps xmm10, [rsp+0x90]
000075aec0bd4ab5  vmovaps xmm11, [rsp+0xA0]
000075aec0bd4abe  vmovaps xmm12, [rsp+0xB0]
000075aec0bd4ac7  vmovaps xmm13, [rsp+0xC0]
000075aec0bd4ad0  vmovaps xmm14, [rsp+0xD0]
000075aec0bd4ad9  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4ae2  add rsp, 0xF0
000075aec0bd4ae9  pop r11
000075aec0bd4aeb  pop r10
000075aec0bd4aed  pop r9
000075aec0bd4aef  pop r8
000075aec0bd4af1  pop rsi
000075aec0bd4af2  pop rdi
000075aec0bd4af3  pop rdx
000075aec0bd4af4  pop rcx
000075aec0bd4af5  pop rax
000075aec0bd4af6  add rsp, 0x08
000075aec0bd4afa  jmp 0x000075AEC0BD01AF
000075aec0bd4aff  sub rsp, 0x08
000075aec0bd4b03  push rax
000075aec0bd4b04  push rcx
000075aec0bd4b05  push rdx
000075aec0bd4b06  push rdi
000075aec0bd4b07  push rsi
000075aec0bd4b08  push r8
000075aec0bd4b0a  push r9
000075aec0bd4b0c  push r10
000075aec0bd4b0e  push r11
000075aec0bd4b10  sub rsp, 0xF0
000075aec0bd4b17  vmovaps [rsp], xmm0
000075aec0bd4b1c  vmovaps [rsp+0x10], xmm1
000075aec0bd4b22  vmovaps [rsp+0x20], xmm2
000075aec0bd4b28  vmovaps [rsp+0x30], xmm3
000075aec0bd4b2e  vmovaps [rsp+0x40], xmm4
000075aec0bd4b34  vmovaps [rsp+0x50], xmm5
000075aec0bd4b3a  vmovaps [rsp+0x60], xmm6
000075aec0bd4b40  vmovaps [rsp+0x70], xmm7
000075aec0bd4b46  vmovaps [rsp+0x80], xmm8
000075aec0bd4b4f  vmovaps [rsp+0x90], xmm10
000075aec0bd4b58  vmovaps [rsp+0xA0], xmm11
000075aec0bd4b61  vmovaps [rsp+0xB0], xmm12
000075aec0bd4b6a  vmovaps [rsp+0xC0], xmm13
000075aec0bd4b73  vmovaps [rsp+0xD0], xmm14
000075aec0bd4b7c  vmovaps [rsp+0xE0], xmm15
000075aec0bd4b85  sub rsp, 0x30
000075aec0bd4b89  movaps [rsp], xmm9
000075aec0bd4b8e  movaps [rsp+0x10], xmm1
000075aec0bd4b93  movaps [rsp+0x20], xmm14
000075aec0bd4b99  lea rdi, [rsp]
000075aec0bd4b9d  mov esi, 0x00
000075aec0bd4ba2  mov rax, 0x57F4B31E6530
000075aec0bd4bac  call rax
000075aec0bd4bae  movaps xmm9, [rsp]
000075aec0bd4bb3  add rsp, 0x30
000075aec0bd4bb7  vmovaps xmm0, [rsp]
000075aec0bd4bbc  vmovaps xmm1, [rsp+0x10]
000075aec0bd4bc2  vmovaps xmm2, [rsp+0x20]
000075aec0bd4bc8  vmovaps xmm3, [rsp+0x30]
000075aec0bd4bce  vmovaps xmm4, [rsp+0x40]
000075aec0bd4bd4  vmovaps xmm5, [rsp+0x50]
000075aec0bd4bda  vmovaps xmm6, [rsp+0x60]
000075aec0bd4be0  vmovaps xmm7, [rsp+0x70]
000075aec0bd4be6  vmovaps xmm8, [rsp+0x80]
000075aec0bd4bef  vmovaps xmm10, [rsp+0x90]
000075aec0bd4bf8  vmovaps xmm11, [rsp+0xA0]
000075aec0bd4c01  vmovaps xmm12, [rsp+0xB0]
000075aec0bd4c0a  vmovaps xmm13, [rsp+0xC0]
000075aec0bd4c13  vmovaps xmm14, [rsp+0xD0]
000075aec0bd4c1c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4c25  add rsp, 0xF0
000075aec0bd4c2c  pop r11
000075aec0bd4c2e  pop r10
000075aec0bd4c30  pop r9
000075aec0bd4c32  pop r8
000075aec0bd4c34  pop rsi
000075aec0bd4c35  pop rdi
000075aec0bd4c36  pop rdx
000075aec0bd4c37  pop rcx
000075aec0bd4c38  pop rax
000075aec0bd4c39  add rsp, 0x08
000075aec0bd4c3d  jmp 0x000075AEC0BD01DD
000075aec0bd4c42  sub rsp, 0x08
000075aec0bd4c46  push rax
000075aec0bd4c47  push rcx
000075aec0bd4c48  push rdx
000075aec0bd4c49  push rdi
000075aec0bd4c4a  push rsi
000075aec0bd4c4b  push r8
000075aec0bd4c4d  push r9
000075aec0bd4c4f  push r10
000075aec0bd4c51  push r11
000075aec0bd4c53  sub rsp, 0xF0
000075aec0bd4c5a  vmovaps [rsp], xmm0
000075aec0bd4c5f  vmovaps [rsp+0x10], xmm1
000075aec0bd4c65  vmovaps [rsp+0x20], xmm2
000075aec0bd4c6b  vmovaps [rsp+0x30], xmm3
000075aec0bd4c71  vmovaps [rsp+0x40], xmm4
000075aec0bd4c77  vmovaps [rsp+0x50], xmm5
000075aec0bd4c7d  vmovaps [rsp+0x60], xmm6
000075aec0bd4c83  vmovaps [rsp+0x70], xmm7
000075aec0bd4c89  vmovaps [rsp+0x80], xmm8
000075aec0bd4c92  vmovaps [rsp+0x90], xmm9
000075aec0bd4c9b  vmovaps [rsp+0xA0], xmm10
000075aec0bd4ca4  vmovaps [rsp+0xB0], xmm11
000075aec0bd4cad  vmovaps [rsp+0xC0], xmm12
000075aec0bd4cb6  vmovaps [rsp+0xD0], xmm13
000075aec0bd4cbf  vmovaps [rsp+0xE0], xmm15
000075aec0bd4cc8  sub rsp, 0x30
000075aec0bd4ccc  movaps [rsp], xmm14
000075aec0bd4cd1  movaps [rsp+0x10], xmm4
000075aec0bd4cd6  movaps [rsp+0x20], xmm1
000075aec0bd4cdb  lea rdi, [rsp]
000075aec0bd4cdf  mov esi, 0x00
000075aec0bd4ce4  mov rax, 0x57F4B31E6530
000075aec0bd4cee  call rax
000075aec0bd4cf0  movaps xmm14, [rsp]
000075aec0bd4cf5  add rsp, 0x30
000075aec0bd4cf9  vmovaps xmm0, [rsp]
000075aec0bd4cfe  vmovaps xmm1, [rsp+0x10]
000075aec0bd4d04  vmovaps xmm2, [rsp+0x20]
000075aec0bd4d0a  vmovaps xmm3, [rsp+0x30]
000075aec0bd4d10  vmovaps xmm4, [rsp+0x40]
000075aec0bd4d16  vmovaps xmm5, [rsp+0x50]
000075aec0bd4d1c  vmovaps xmm6, [rsp+0x60]
000075aec0bd4d22  vmovaps xmm7, [rsp+0x70]
000075aec0bd4d28  vmovaps xmm8, [rsp+0x80]
000075aec0bd4d31  vmovaps xmm9, [rsp+0x90]
000075aec0bd4d3a  vmovaps xmm10, [rsp+0xA0]
000075aec0bd4d43  vmovaps xmm11, [rsp+0xB0]
000075aec0bd4d4c  vmovaps xmm12, [rsp+0xC0]
000075aec0bd4d55  vmovaps xmm13, [rsp+0xD0]
000075aec0bd4d5e  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4d67  add rsp, 0xF0
000075aec0bd4d6e  pop r11
000075aec0bd4d70  pop r10
000075aec0bd4d72  pop r9
000075aec0bd4d74  pop r8
000075aec0bd4d76  pop rsi
000075aec0bd4d77  pop rdi
000075aec0bd4d78  pop rdx
000075aec0bd4d79  pop rcx
000075aec0bd4d7a  pop rax
000075aec0bd4d7b  add rsp, 0x08
000075aec0bd4d7f  jmp 0x000075AEC0BD0203
000075aec0bd4d84  sub rsp, 0x08
000075aec0bd4d88  push rax
000075aec0bd4d89  push rcx
000075aec0bd4d8a  push rdx
000075aec0bd4d8b  push rdi
000075aec0bd4d8c  push rsi
000075aec0bd4d8d  push r8
000075aec0bd4d8f  push r9
000075aec0bd4d91  push r10
000075aec0bd4d93  push r11
000075aec0bd4d95  sub rsp, 0xF0
000075aec0bd4d9c  vmovaps [rsp], xmm0
000075aec0bd4da1  vmovaps [rsp+0x10], xmm2
000075aec0bd4da7  vmovaps [rsp+0x20], xmm3
000075aec0bd4dad  vmovaps [rsp+0x30], xmm4
000075aec0bd4db3  vmovaps [rsp+0x40], xmm5
000075aec0bd4db9  vmovaps [rsp+0x50], xmm6
000075aec0bd4dbf  vmovaps [rsp+0x60], xmm7
000075aec0bd4dc5  vmovaps [rsp+0x70], xmm8
000075aec0bd4dcb  vmovaps [rsp+0x80], xmm9
000075aec0bd4dd4  vmovaps [rsp+0x90], xmm10
000075aec0bd4ddd  vmovaps [rsp+0xA0], xmm11
000075aec0bd4de6  vmovaps [rsp+0xB0], xmm12
000075aec0bd4def  vmovaps [rsp+0xC0], xmm13
000075aec0bd4df8  vmovaps [rsp+0xD0], xmm14
000075aec0bd4e01  vmovaps [rsp+0xE0], xmm15
000075aec0bd4e0a  sub rsp, 0x30
000075aec0bd4e0e  movaps [rsp], xmm1
000075aec0bd4e12  movaps [rsp+0x10], xmm12
000075aec0bd4e18  movaps [rsp+0x20], xmm11
000075aec0bd4e1e  lea rdi, [rsp]
000075aec0bd4e22  mov esi, 0x00
000075aec0bd4e27  mov rax, 0x57F4B31E6530
000075aec0bd4e31  call rax
000075aec0bd4e33  movaps xmm1, [rsp]
000075aec0bd4e37  add rsp, 0x30
000075aec0bd4e3b  vmovaps xmm0, [rsp]
000075aec0bd4e40  vmovaps xmm2, [rsp+0x10]
000075aec0bd4e46  vmovaps xmm3, [rsp+0x20]
000075aec0bd4e4c  vmovaps xmm4, [rsp+0x30]
000075aec0bd4e52  vmovaps xmm5, [rsp+0x40]
000075aec0bd4e58  vmovaps xmm6, [rsp+0x50]
000075aec0bd4e5e  vmovaps xmm7, [rsp+0x60]
000075aec0bd4e64  vmovaps xmm8, [rsp+0x70]
000075aec0bd4e6a  vmovaps xmm9, [rsp+0x80]
000075aec0bd4e73  vmovaps xmm10, [rsp+0x90]
000075aec0bd4e7c  vmovaps xmm11, [rsp+0xA0]
000075aec0bd4e85  vmovaps xmm12, [rsp+0xB0]
000075aec0bd4e8e  vmovaps xmm13, [rsp+0xC0]
000075aec0bd4e97  vmovaps xmm14, [rsp+0xD0]
000075aec0bd4ea0  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4ea9  add rsp, 0xF0
000075aec0bd4eb0  pop r11
000075aec0bd4eb2  pop r10
000075aec0bd4eb4  pop r9
000075aec0bd4eb6  pop r8
000075aec0bd4eb8  pop rsi
000075aec0bd4eb9  pop rdi
000075aec0bd4eba  pop rdx
000075aec0bd4ebb  pop rcx
000075aec0bd4ebc  pop rax
000075aec0bd4ebd  add rsp, 0x08
000075aec0bd4ec1  jmp 0x000075AEC0BD0224
000075aec0bd4ec6  call 0x000075AEC0AE20A0
000075aec0bd4ecb  jmp 0x000075AEC0BD0232
000075aec0bd4ed0  call 0x000075AEC0A09D70
000075aec0bd4ed5  jmp 0x000075AEC0BD023C
000075aec0bd4eda  sub rsp, 0x08
000075aec0bd4ede  push rax
000075aec0bd4edf  push rcx
000075aec0bd4ee0  push rdx
000075aec0bd4ee1  push rdi
000075aec0bd4ee2  push rsi
000075aec0bd4ee3  push r8
000075aec0bd4ee5  push r9
000075aec0bd4ee7  push r10
000075aec0bd4ee9  push r11
000075aec0bd4eeb  sub rsp, 0xF0
000075aec0bd4ef2  vmovaps [rsp], xmm0
000075aec0bd4ef7  vmovaps [rsp+0x10], xmm1
000075aec0bd4efd  vmovaps [rsp+0x20], xmm2
000075aec0bd4f03  vmovaps [rsp+0x30], xmm3
000075aec0bd4f09  vmovaps [rsp+0x40], xmm4
000075aec0bd4f0f  vmovaps [rsp+0x50], xmm5
000075aec0bd4f15  vmovaps [rsp+0x60], xmm6
000075aec0bd4f1b  vmovaps [rsp+0x70], xmm8
000075aec0bd4f21  vmovaps [rsp+0x80], xmm9
000075aec0bd4f2a  vmovaps [rsp+0x90], xmm10
000075aec0bd4f33  vmovaps [rsp+0xA0], xmm11
000075aec0bd4f3c  vmovaps [rsp+0xB0], xmm12
000075aec0bd4f45  vmovaps [rsp+0xC0], xmm13
000075aec0bd4f4e  vmovaps [rsp+0xD0], xmm14
000075aec0bd4f57  vmovaps [rsp+0xE0], xmm15
000075aec0bd4f60  sub rsp, 0x30
000075aec0bd4f64  movaps [rsp], xmm7
000075aec0bd4f68  movaps [rsp+0x10], xmm15
000075aec0bd4f6e  movaps [rsp+0x20], xmm10
000075aec0bd4f74  lea rdi, [rsp]
000075aec0bd4f78  mov esi, 0x00
000075aec0bd4f7d  mov rax, 0x57F4B31E6530
000075aec0bd4f87  call rax
000075aec0bd4f89  movaps xmm7, [rsp]
000075aec0bd4f8d  add rsp, 0x30
000075aec0bd4f91  vmovaps xmm0, [rsp]
000075aec0bd4f96  vmovaps xmm1, [rsp+0x10]
000075aec0bd4f9c  vmovaps xmm2, [rsp+0x20]
000075aec0bd4fa2  vmovaps xmm3, [rsp+0x30]
000075aec0bd4fa8  vmovaps xmm4, [rsp+0x40]
000075aec0bd4fae  vmovaps xmm5, [rsp+0x50]
000075aec0bd4fb4  vmovaps xmm6, [rsp+0x60]
000075aec0bd4fba  vmovaps xmm8, [rsp+0x70]
000075aec0bd4fc0  vmovaps xmm9, [rsp+0x80]
000075aec0bd4fc9  vmovaps xmm10, [rsp+0x90]
000075aec0bd4fd2  vmovaps xmm11, [rsp+0xA0]
000075aec0bd4fdb  vmovaps xmm12, [rsp+0xB0]
000075aec0bd4fe4  vmovaps xmm13, [rsp+0xC0]
000075aec0bd4fed  vmovaps xmm14, [rsp+0xD0]
000075aec0bd4ff6  vmovaps xmm15, [rsp+0xE0]
000075aec0bd4fff  add rsp, 0xF0
000075aec0bd5006  pop r11
000075aec0bd5008  pop r10
000075aec0bd500a  pop r9
000075aec0bd500c  pop r8
000075aec0bd500e  pop rsi
000075aec0bd500f  pop rdi
000075aec0bd5010  pop rdx
000075aec0bd5011  pop rcx
000075aec0bd5012  pop rax
000075aec0bd5013  add rsp, 0x08
000075aec0bd5017  jmp 0x000075AEC0BD025D
000075aec0bd501c  sub rsp, 0x08
000075aec0bd5020  push rax
000075aec0bd5021  push rcx
000075aec0bd5022  push rdx
000075aec0bd5023  push rdi
000075aec0bd5024  push rsi
000075aec0bd5025  push r8
000075aec0bd5027  push r9
000075aec0bd5029  push r10
000075aec0bd502b  push r11
000075aec0bd502d  sub rsp, 0xF0
000075aec0bd5034  vmovaps [rsp], xmm0
000075aec0bd5039  vmovaps [rsp+0x10], xmm1
000075aec0bd503f  vmovaps [rsp+0x20], xmm2
000075aec0bd5045  vmovaps [rsp+0x30], xmm3
000075aec0bd504b  vmovaps [rsp+0x40], xmm4
000075aec0bd5051  vmovaps [rsp+0x50], xmm5
000075aec0bd5057  vmovaps [rsp+0x60], xmm6
000075aec0bd505d  vmovaps [rsp+0x70], xmm7
000075aec0bd5063  vmovaps [rsp+0x80], xmm8
000075aec0bd506c  vmovaps [rsp+0x90], xmm9
000075aec0bd5075  vmovaps [rsp+0xA0], xmm11
000075aec0bd507e  vmovaps [rsp+0xB0], xmm12
000075aec0bd5087  vmovaps [rsp+0xC0], xmm13
000075aec0bd5090  vmovaps [rsp+0xD0], xmm14
000075aec0bd5099  vmovaps [rsp+0xE0], xmm15
000075aec0bd50a2  sub rsp, 0x30
000075aec0bd50a6  movaps [rsp], xmm10
000075aec0bd50ab  movaps [rsp+0x10], xmm11
000075aec0bd50b1  movaps [rsp+0x20], xmm15
000075aec0bd50b7  lea rdi, [rsp]
000075aec0bd50bb  mov esi, 0x00
000075aec0bd50c0  mov rax, 0x57F4B31E6530
000075aec0bd50ca  call rax
000075aec0bd50cc  movaps xmm10, [rsp]
000075aec0bd50d1  add rsp, 0x30
000075aec0bd50d5  vmovaps xmm0, [rsp]
000075aec0bd50da  vmovaps xmm1, [rsp+0x10]
000075aec0bd50e0  vmovaps xmm2, [rsp+0x20]
000075aec0bd50e6  vmovaps xmm3, [rsp+0x30]
000075aec0bd50ec  vmovaps xmm4, [rsp+0x40]
000075aec0bd50f2  vmovaps xmm5, [rsp+0x50]
000075aec0bd50f8  vmovaps xmm6, [rsp+0x60]
000075aec0bd50fe  vmovaps xmm7, [rsp+0x70]
000075aec0bd5104  vmovaps xmm8, [rsp+0x80]
000075aec0bd510d  vmovaps xmm9, [rsp+0x90]
000075aec0bd5116  vmovaps xmm11, [rsp+0xA0]
000075aec0bd511f  vmovaps xmm12, [rsp+0xB0]
000075aec0bd5128  vmovaps xmm13, [rsp+0xC0]
000075aec0bd5131  vmovaps xmm14, [rsp+0xD0]
000075aec0bd513a  vmovaps xmm15, [rsp+0xE0]
000075aec0bd5143  add rsp, 0xF0
000075aec0bd514a  pop r11
000075aec0bd514c  pop r10
000075aec0bd514e  pop r9
000075aec0bd5150  pop r8
000075aec0bd5152  pop rsi
000075aec0bd5153  pop rdi
000075aec0bd5154  pop rdx
000075aec0bd5155  pop rcx
000075aec0bd5156  pop rax
000075aec0bd5157  add rsp, 0x08
000075aec0bd515b  jmp 0x000075AEC0BD028B
000075aec0bd5160  sub rsp, 0x08
000075aec0bd5164  push rax
000075aec0bd5165  push rcx
000075aec0bd5166  push rdx
000075aec0bd5167  push rdi
000075aec0bd5168  push rsi
000075aec0bd5169  push r8
000075aec0bd516b  push r9
000075aec0bd516d  push r10
000075aec0bd516f  push r11
000075aec0bd5171  sub rsp, 0xF0
000075aec0bd5178  vmovaps [rsp], xmm0
000075aec0bd517d  vmovaps [rsp+0x10], xmm1
000075aec0bd5183  vmovaps [rsp+0x20], xmm2
000075aec0bd5189  vmovaps [rsp+0x30], xmm3
000075aec0bd518f  vmovaps [rsp+0x40], xmm4
000075aec0bd5195  vmovaps [rsp+0x50], xmm5
000075aec0bd519b  vmovaps [rsp+0x60], xmm6
000075aec0bd51a1  vmovaps [rsp+0x70], xmm7
000075aec0bd51a7  vmovaps [rsp+0x80], xmm8
000075aec0bd51b0  vmovaps [rsp+0x90], xmm9
000075aec0bd51b9  vmovaps [rsp+0xA0], xmm10
000075aec0bd51c2  vmovaps [rsp+0xB0], xmm12
000075aec0bd51cb  vmovaps [rsp+0xC0], xmm13
000075aec0bd51d4  vmovaps [rsp+0xD0], xmm14
000075aec0bd51dd  vmovaps [rsp+0xE0], xmm15
000075aec0bd51e6  sub rsp, 0x30
000075aec0bd51ea  movaps [rsp], xmm11
000075aec0bd51ef  movaps [rsp+0x10], xmm12
000075aec0bd51f5  movaps [rsp+0x20], xmm15
000075aec0bd51fb  lea rdi, [rsp]
000075aec0bd51ff  mov esi, 0x00
000075aec0bd5204  mov rax, 0x57F4B31E6530
000075aec0bd520e  call rax
000075aec0bd5210  movaps xmm11, [rsp]
000075aec0bd5215  add rsp, 0x30
000075aec0bd5219  vmovaps xmm0, [rsp]
000075aec0bd521e  vmovaps xmm1, [rsp+0x10]
000075aec0bd5224  vmovaps xmm2, [rsp+0x20]
000075aec0bd522a  vmovaps xmm3, [rsp+0x30]
000075aec0bd5230  vmovaps xmm4, [rsp+0x40]
000075aec0bd5236  vmovaps xmm5, [rsp+0x50]
000075aec0bd523c  vmovaps xmm6, [rsp+0x60]
000075aec0bd5242  vmovaps xmm7, [rsp+0x70]
000075aec0bd5248  vmovaps xmm8, [rsp+0x80]
000075aec0bd5251  vmovaps xmm9, [rsp+0x90]
000075aec0bd525a  vmovaps xmm10, [rsp+0xA0]
000075aec0bd5263  vmovaps xmm12, [rsp+0xB0]
000075aec0bd526c  vmovaps xmm13, [rsp+0xC0]
000075aec0bd5275  vmovaps xmm14, [rsp+0xD0]
000075aec0bd527e  vmovaps xmm15, [rsp+0xE0]
000075aec0bd5287  add rsp, 0xF0
000075aec0bd528e  pop r11
000075aec0bd5290  pop r10
000075aec0bd5292  pop r9
000075aec0bd5294  pop r8
000075aec0bd5296  pop rsi
000075aec0bd5297  pop rdi
000075aec0bd5298  pop rdx
000075aec0bd5299  pop rcx
000075aec0bd529a  pop rax
000075aec0bd529b  add rsp, 0x08
000075aec0bd529f  jmp 0x000075AEC0BD02B9
000075aec0bd52a4  sub rsp, 0x08
000075aec0bd52a8  push rax
000075aec0bd52a9  push rcx
000075aec0bd52aa  push rdx
000075aec0bd52ab  push rdi
000075aec0bd52ac  push rsi
000075aec0bd52ad  push r8
000075aec0bd52af  push r9
000075aec0bd52b1  push r10
000075aec0bd52b3  push r11
000075aec0bd52b5  sub rsp, 0xF0
000075aec0bd52bc  vmovaps [rsp], xmm0
000075aec0bd52c1  vmovaps [rsp+0x10], xmm1
000075aec0bd52c7  vmovaps [rsp+0x20], xmm2
000075aec0bd52cd  vmovaps [rsp+0x30], xmm3
000075aec0bd52d3  vmovaps [rsp+0x40], xmm4
000075aec0bd52d9  vmovaps [rsp+0x50], xmm5
000075aec0bd52df  vmovaps [rsp+0x60], xmm6
000075aec0bd52e5  vmovaps [rsp+0x70], xmm7
000075aec0bd52eb  vmovaps [rsp+0x80], xmm8
000075aec0bd52f4  vmovaps [rsp+0x90], xmm9
000075aec0bd52fd  vmovaps [rsp+0xA0], xmm10
000075aec0bd5306  vmovaps [rsp+0xB0], xmm11
000075aec0bd530f  vmovaps [rsp+0xC0], xmm12
000075aec0bd5318  vmovaps [rsp+0xD0], xmm13
000075aec0bd5321  vmovaps [rsp+0xE0], xmm14
000075aec0bd532a  sub rsp, 0x30
000075aec0bd532e  movaps [rsp], xmm15
000075aec0bd5333  movaps [rsp+0x10], xmm13
000075aec0bd5339  movaps [rsp+0x20], xmm9
000075aec0bd533f  lea rdi, [rsp]
000075aec0bd5343  mov esi, 0x00
000075aec0bd5348  mov rax, 0x57F4B31E6530
000075aec0bd5352  call rax
000075aec0bd5354  movaps xmm15, [rsp]
000075aec0bd5359  add rsp, 0x30
000075aec0bd535d  vmovaps xmm0, [rsp]
000075aec0bd5362  vmovaps xmm1, [rsp+0x10]
000075aec0bd5368  vmovaps xmm2, [rsp+0x20]
000075aec0bd536e  vmovaps xmm3, [rsp+0x30]
000075aec0bd5374  vmovaps xmm4, [rsp+0x40]
000075aec0bd537a  vmovaps xmm5, [rsp+0x50]
000075aec0bd5380  vmovaps xmm6, [rsp+0x60]
000075aec0bd5386  vmovaps xmm7, [rsp+0x70]
000075aec0bd538c  vmovaps xmm8, [rsp+0x80]
000075aec0bd5395  vmovaps xmm9, [rsp+0x90]
000075aec0bd539e  vmovaps xmm10, [rsp+0xA0]
000075aec0bd53a7  vmovaps xmm11, [rsp+0xB0]
000075aec0bd53b0  vmovaps xmm12, [rsp+0xC0]
000075aec0bd53b9  vmovaps xmm13, [rsp+0xD0]
000075aec0bd53c2  vmovaps xmm14, [rsp+0xE0]
000075aec0bd53cb  add rsp, 0xF0
000075aec0bd53d2  pop r11
000075aec0bd53d4  pop r10
000075aec0bd53d6  pop r9
000075aec0bd53d8  pop r8
000075aec0bd53da  pop rsi
000075aec0bd53db  pop rdi
000075aec0bd53dc  pop rdx
000075aec0bd53dd  pop rcx
000075aec0bd53de  pop rax
000075aec0bd53df  add rsp, 0x08
000075aec0bd53e3  jmp 0x000075AEC0BD02D4
000075aec0bd53e8  sub rsp, 0x08
000075aec0bd53ec  push rax
000075aec0bd53ed  push rcx
000075aec0bd53ee  push rdx
000075aec0bd53ef  push rdi
000075aec0bd53f0  push rsi
000075aec0bd53f1  push r8
000075aec0bd53f3  push r9
000075aec0bd53f5  push r10
000075aec0bd53f7  push r11
000075aec0bd53f9  sub rsp, 0xF0
000075aec0bd5400  vmovaps [rsp], xmm0
000075aec0bd5405  vmovaps [rsp+0x10], xmm1
000075aec0bd540b  vmovaps [rsp+0x20], xmm2
000075aec0bd5411  vmovaps [rsp+0x30], xmm3
000075aec0bd5417  vmovaps [rsp+0x40], xmm4
000075aec0bd541d  vmovaps [rsp+0x50], xmm5
000075aec0bd5423  vmovaps [rsp+0x60], xmm6
000075aec0bd5429  vmovaps [rsp+0x70], xmm7
000075aec0bd542f  vmovaps [rsp+0x80], xmm8
000075aec0bd5438  vmovaps [rsp+0x90], xmm9
000075aec0bd5441  vmovaps [rsp+0xA0], xmm10
000075aec0bd544a  vmovaps [rsp+0xB0], xmm11
000075aec0bd5453  vmovaps [rsp+0xC0], xmm12
000075aec0bd545c  vmovaps [rsp+0xD0], xmm14
000075aec0bd5465  vmovaps [rsp+0xE0], xmm15
000075aec0bd546e  sub rsp, 0x30
000075aec0bd5472  movaps [rsp], xmm13
000075aec0bd5477  movaps [rsp+0x10], xmm8
000075aec0bd547d  movaps [rsp+0x20], xmm14
000075aec0bd5483  lea rdi, [rsp]
000075aec0bd5487  mov esi, 0x00
000075aec0bd548c  mov rax, 0x57F4B31E6530
000075aec0bd5496  call rax
000075aec0bd5498  movaps xmm13, [rsp]
000075aec0bd549d  add rsp, 0x30
000075aec0bd54a1  vmovaps xmm0, [rsp]
000075aec0bd54a6  vmovaps xmm1, [rsp+0x10]
000075aec0bd54ac  vmovaps xmm2, [rsp+0x20]
000075aec0bd54b2  vmovaps xmm3, [rsp+0x30]
000075aec0bd54b8  vmovaps xmm4, [rsp+0x40]
000075aec0bd54be  vmovaps xmm5, [rsp+0x50]
000075aec0bd54c4  vmovaps xmm6, [rsp+0x60]
000075aec0bd54ca  vmovaps xmm7, [rsp+0x70]
000075aec0bd54d0  vmovaps xmm8, [rsp+0x80]
000075aec0bd54d9  vmovaps xmm9, [rsp+0x90]
000075aec0bd54e2  vmovaps xmm10, [rsp+0xA0]
000075aec0bd54eb  vmovaps xmm11, [rsp+0xB0]
000075aec0bd54f4  vmovaps xmm12, [rsp+0xC0]
000075aec0bd54fd  vmovaps xmm14, [rsp+0xD0]
000075aec0bd5506  vmovaps xmm15, [rsp+0xE0]
000075aec0bd550f  add rsp, 0xF0
000075aec0bd5516  pop r11
000075aec0bd5518  pop r10
000075aec0bd551a  pop r9
000075aec0bd551c  pop r8
000075aec0bd551e  pop rsi
000075aec0bd551f  pop rdi
000075aec0bd5520  pop rdx
000075aec0bd5521  pop rcx
000075aec0bd5522  pop rax
000075aec0bd5523  add rsp, 0x08
000075aec0bd5527  jmp 0x000075AEC0BD02F7
000075aec0bd552c  sub rsp, 0x08
000075aec0bd5530  push rax
000075aec0bd5531  push rcx
000075aec0bd5532  push rdx
000075aec0bd5533  push rdi
000075aec0bd5534  push rsi
000075aec0bd5535  push r8
000075aec0bd5537  push r9
000075aec0bd5539  push r10
000075aec0bd553b  push r11
000075aec0bd553d  sub rsp, 0xF0
000075aec0bd5544  vmovaps [rsp], xmm0
000075aec0bd5549  vmovaps [rsp+0x10], xmm1
000075aec0bd554f  vmovaps [rsp+0x20], xmm2
000075aec0bd5555  vmovaps [rsp+0x30], xmm3
000075aec0bd555b  vmovaps [rsp+0x40], xmm4
000075aec0bd5561  vmovaps [rsp+0x50], xmm5
000075aec0bd5567  vmovaps [rsp+0x60], xmm6
000075aec0bd556d  vmovaps [rsp+0x70], xmm7
000075aec0bd5573  vmovaps [rsp+0x80], xmm8
000075aec0bd557c  vmovaps [rsp+0x90], xmm9
000075aec0bd5585  vmovaps [rsp+0xA0], xmm10
000075aec0bd558e  vmovaps [rsp+0xB0], xmm11
000075aec0bd5597  vmovaps [rsp+0xC0], xmm12
000075aec0bd55a0  vmovaps [rsp+0xD0], xmm13
000075aec0bd55a9  vmovaps [rsp+0xE0], xmm15
000075aec0bd55b2  sub rsp, 0x30
000075aec0bd55b6  movaps [rsp], xmm14
000075aec0bd55bb  movaps [rsp+0x10], xmm1
000075aec0bd55c0  movaps [rsp+0x20], xmm10
000075aec0bd55c6  lea rdi, [rsp]
000075aec0bd55ca  mov esi, 0x00
000075aec0bd55cf  mov rax, 0x57F4B31E6530
000075aec0bd55d9  call rax
000075aec0bd55db  movaps xmm14, [rsp]
000075aec0bd55e0  add rsp, 0x30
000075aec0bd55e4  vmovaps xmm0, [rsp]
000075aec0bd55e9  vmovaps xmm1, [rsp+0x10]
000075aec0bd55ef  vmovaps xmm2, [rsp+0x20]
000075aec0bd55f5  vmovaps xmm3, [rsp+0x30]
000075aec0bd55fb  vmovaps xmm4, [rsp+0x40]
000075aec0bd5601  vmovaps xmm5, [rsp+0x50]
000075aec0bd5607  vmovaps xmm6, [rsp+0x60]
000075aec0bd560d  vmovaps xmm7, [rsp+0x70]
000075aec0bd5613  vmovaps xmm8, [rsp+0x80]
000075aec0bd561c  vmovaps xmm9, [rsp+0x90]
000075aec0bd5625  vmovaps xmm10, [rsp+0xA0]
000075aec0bd562e  vmovaps xmm11, [rsp+0xB0]
000075aec0bd5637  vmovaps xmm12, [rsp+0xC0]
000075aec0bd5640  vmovaps xmm13, [rsp+0xD0]
000075aec0bd5649  vmovaps xmm15, [rsp+0xE0]
000075aec0bd5652  add rsp, 0xF0
000075aec0bd5659  pop r11
000075aec0bd565b  pop r10
000075aec0bd565d  pop r9
000075aec0bd565f  pop r8
000075aec0bd5661  pop rsi
000075aec0bd5662  pop rdi
000075aec0bd5663  pop rdx
000075aec0bd5664  pop rcx
000075aec0bd5665  pop rax
000075aec0bd5666  add rsp, 0x08
000075aec0bd566a  jmp 0x000075AEC0BD031A
000075aec0bd566f  sub rsp, 0x08
000075aec0bd5673  push rax
000075aec0bd5674  push rcx
000075aec0bd5675  push rdx
000075aec0bd5676  push rdi
000075aec0bd5677  push rsi
000075aec0bd5678  push r8
000075aec0bd567a  push r9
000075aec0bd567c  push r10
000075aec0bd567e  push r11
000075aec0bd5680  sub rsp, 0xF0
000075aec0bd5687  vmovaps [rsp], xmm0
000075aec0bd568c  vmovaps [rsp+0x10], xmm2
000075aec0bd5692  vmovaps [rsp+0x20], xmm3
000075aec0bd5698  vmovaps [rsp+0x30], xmm4
000075aec0bd569e  vmovaps [rsp+0x40], xmm5
000075aec0bd56a4  vmovaps [rsp+0x50], xmm6
000075aec0bd56aa  vmovaps [rsp+0x60], xmm7
000075aec0bd56b0  vmovaps [rsp+0x70], xmm8
000075aec0bd56b6  vmovaps [rsp+0x80], xmm9
000075aec0bd56bf  vmovaps [rsp+0x90], xmm10
000075aec0bd56c8  vmovaps [rsp+0xA0], xmm11
000075aec0bd56d1  vmovaps [rsp+0xB0], xmm12
000075aec0bd56da  vmovaps [rsp+0xC0], xmm13
000075aec0bd56e3  vmovaps [rsp+0xD0], xmm14
000075aec0bd56ec  vmovaps [rsp+0xE0], xmm15
000075aec0bd56f5  sub rsp, 0x30
000075aec0bd56f9  movaps [rsp], xmm1
000075aec0bd56fd  movaps [rsp+0x10], xmm7
000075aec0bd5702  movaps [rsp+0x20], xmm11
000075aec0bd5708  lea rdi, [rsp]
000075aec0bd570c  mov esi, 0x00
000075aec0bd5711  mov rax, 0x57F4B31E6530
000075aec0bd571b  call rax
000075aec0bd571d  movaps xmm1, [rsp]
000075aec0bd5721  add rsp, 0x30
000075aec0bd5725  vmovaps xmm0, [rsp]
000075aec0bd572a  vmovaps xmm2, [rsp+0x10]
000075aec0bd5730  vmovaps xmm3, [rsp+0x20]
000075aec0bd5736  vmovaps xmm4, [rsp+0x30]
000075aec0bd573c  vmovaps xmm5, [rsp+0x40]
000075aec0bd5742  vmovaps xmm6, [rsp+0x50]
000075aec0bd5748  vmovaps xmm7, [rsp+0x60]
000075aec0bd574e  vmovaps xmm8, [rsp+0x70]
000075aec0bd5754  vmovaps xmm9, [rsp+0x80]
000075aec0bd575d  vmovaps xmm10, [rsp+0x90]
000075aec0bd5766  vmovaps xmm11, [rsp+0xA0]
000075aec0bd576f  vmovaps xmm12, [rsp+0xB0]
000075aec0bd5778  vmovaps xmm13, [rsp+0xC0]
000075aec0bd5781  vmovaps xmm14, [rsp+0xD0]
000075aec0bd578a  vmovaps xmm15, [rsp+0xE0]
000075aec0bd5793  add rsp, 0xF0
000075aec0bd579a  pop r11
000075aec0bd579c  pop r10
000075aec0bd579e  pop r9
000075aec0bd57a0  pop r8
000075aec0bd57a2  pop rsi
000075aec0bd57a3  pop rdi
000075aec0bd57a4  pop rdx
000075aec0bd57a5  pop rcx
000075aec0bd57a6  pop rax
000075aec0bd57a7  add rsp, 0x08
000075aec0bd57ab  jmp 0x000075AEC0BD033B
000075aec0bd57b0  call 0x000075AEC0A0E880
000075aec0bd57b5  jmp 0x000075AEC0BD034E
000075aec0bd57ba  call 0x000075AEC0A0C380
000075aec0bd57bf  jmp 0x000075AEC0BD0359
000075aec0bd57c4  call 0x000075AEC0A0D600
000075aec0bd57c9  jmp 0x000075AEC0BD0364
000075aec0bd57ce  call 0x000075AEC09FF540
000075aec0bd57d3  jmp 0x000075AEC0BD036F
000075aec0bd57d8  int3
000075aec0bd57d9  nop [rax], eax
000075aec0bd57e0  mov rax, [r15+0x40]
000075aec0bd57e4  mov r14, [r15+0x58]
000075aec0bd57e8  lea r12, [rax+r14*1]
000075aec0bd57ec  movaps xmm1, [r15+0x1D0]
000075aec0bd57f4  vmovaps [rsp+0x10], xmm1
000075aec0bd57fa  vmovaps xmm15, [rsp+0x10]
000075aec0bd5800  por xmm1, xmm15
000075aec0bd5805  movaps xmm14, [r15+0x1A0]
000075aec0bd580d  vmovaps [rsp+0x10], xmm14
000075aec0bd5813  vmovaps xmm13, [rsp+0x10]
000075aec0bd5819  por xmm14, xmm13
000075aec0bd581e  lea rax, [r12+0x30]
000075aec0bd5823  mov r11, [r13+rax*1]
000075aec0bd5828  lea rax, [r12+0x38]
000075aec0bd582d  mov r10, [r13+rax*1]
000075aec0bd5832  movq xmm13, r11
000075aec0bd5837  movq xmm12, r10
000075aec0bd583c  movq xmm13, xmm13
000075aec0bd5841  vmovaps [rsp+0x10], xmm13
000075aec0bd5847  movq xmm13, xmm13
000075aec0bd584c  movaps [r15+0x130], xmm13
000075aec0bd5854  movq xmm12, xmm12
000075aec0bd5859  vmovaps [rsp+0x20], xmm12
000075aec0bd585f  movq xmm12, xmm12
000075aec0bd5864  movaps [r15+0x280], xmm12
000075aec0bd586c  movaps xmm13, [r15+0x270]
000075aec0bd5874  vmovaps [rsp+0x30], xmm13
000075aec0bd587a  vmovaps xmm12, [rsp+0x30]
000075aec0bd5880  por xmm13, xmm12
000075aec0bd5885  lea rax, [r12+0x20]
000075aec0bd588a  mov r11, [r13+rax*1]
000075aec0bd588f  lea rax, [r12+0x28]
000075aec0bd5894  mov r10, [r13+rax*1]
000075aec0bd5899  movq xmm12, r11
000075aec0bd589e  movq xmm11, r10
000075aec0bd58a3  movq xmm12, xmm12
000075aec0bd58a8  vmovaps [rsp+0x30], xmm12
000075aec0bd58ae  movq xmm12, xmm12
000075aec0bd58b3  movaps [r15+0x150], xmm12
000075aec0bd58bb  movq xmm11, xmm11
000075aec0bd58c0  vmovaps [rsp+0x40], xmm11
000075aec0bd58c6  movq xmm11, xmm11
000075aec0bd58cb  movaps [r15+0x140], xmm11
000075aec0bd58d3  lea rax, [r12+0x10]
000075aec0bd58d8  mov r11, [r13+rax*1]
000075aec0bd58dd  lea rax, [r12+0x18]
000075aec0bd58e2  mov r10, [r13+rax*1]
000075aec0bd58e7  movq xmm12, r11
000075aec0bd58ec  movq xmm11, r10
000075aec0bd58f1  movq xmm12, xmm12
000075aec0bd58f6  vmovaps [rsp+0x50], xmm12
000075aec0bd58fc  movq xmm12, xmm12
000075aec0bd5901  movaps [r15+0x170], xmm12
000075aec0bd5909  movq xmm11, xmm11
000075aec0bd590e  vmovaps [rsp+0x60], xmm11
000075aec0bd5914  movq xmm11, xmm11
000075aec0bd5919  movaps [r15+0x160], xmm11
000075aec0bd5921  mov rax, [r13+r12*1]
000075aec0bd5926  vmovq xmm12, rax
000075aec0bd592b  vpbroadcastq xmm12, xmm12
000075aec0bd5930  lea rax, [r12+0x08]
000075aec0bd5935  mov r12, [r13+rax*1]
000075aec0bd593a  movq xmm11, r12
000075aec0bd593f  movaps [r15+0x230], xmm11
000075aec0bd5947  mov rax, [r15+0xF8]
000075aec0bd594e  lea r12, [rax+0x50]
000075aec0bd5952  movups xmm11, [r13+r12*1]
000075aec0bd5958  lea r12, [rax+0x60]
000075aec0bd595c  movups xmm10, [r13+r12*1]
000075aec0bd5962  lea r12, [rax+0x30]
000075aec0bd5966  movups xmm9, [r13+r12*1]
000075aec0bd596c  mov r12, [r15+0x50]
000075aec0bd5970  lea r11, [r12+r14*1]
000075aec0bd5974  mov [r15+0x60], r11
000075aec0bd5978  lea r12, [r14+0x40]
000075aec0bd597c  mov [r15+0x58], r12
000075aec0bd5980  movaps xmm8, xmm12
000075aec0bd5984  mulpd xmm8, xmm15
000075aec0bd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000075aec0bd598f  ptest xmm7, xmm7
000075aec0bd5994  jnz 0x000075AEC0BD67B7
000075aec0bd599a  movq xmm15, qword ptr [r15+0x230]
000075aec0bd59a3  vmovaps [rsp+0x70], xmm15
000075aec0bd59a9  vpermilpd xmm15, xmm15, 0x00
000075aec0bd59af  movaps xmm7, xmm9
000075aec0bd59b3  mulpd xmm7, xmm15
000075aec0bd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000075aec0bd59bd  ptest xmm6, xmm6
000075aec0bd59c2  jnz 0x000075AEC0BD68FB
000075aec0bd59c8  vxorps xmm15, xmm15, xmm15
000075aec0bd59cd  vpbroadcastq xmm15, xmm15
000075aec0bd59d2  movaps xmm9, xmm12
000075aec0bd59d6  mulpd xmm9, xmm10
000075aec0bd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000075aec0bd59e1  ptest xmm6, xmm6
000075aec0bd59e6  jnz 0x000075AEC0BD6A3D
000075aec0bd59ec  movaps xmm10, xmm12
000075aec0bd59f0  mulpd xmm10, xmm11
000075aec0bd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000075aec0bd59fb  ptest xmm6, xmm6
000075aec0bd5a00  jnz 0x000075AEC0BD6B81
000075aec0bd5a06  movaps xmm11, [r15+0x1F0]
000075aec0bd5a0e  movaps xmm6, xmm12
000075aec0bd5a12  mulpd xmm6, xmm11
000075aec0bd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000075aec0bd5a1c  ptest xmm5, xmm5
000075aec0bd5a21  jnz 0x000075AEC0BD6CC5
000075aec0bd5a27  movaps xmm12, [r15+0x2A0]
000075aec0bd5a2f  vmovaps [rsp+0x80], xmm12
000075aec0bd5a38  vmovaps xmm11, [rsp+0x80]
000075aec0bd5a41  por xmm12, xmm11
000075aec0bd5a46  movaps xmm11, [r15+0x250]
000075aec0bd5a4e  vmovaps [rsp+0x80], xmm11
000075aec0bd5a57  vmovaps xmm5, [rsp+0x80]
000075aec0bd5a60  por xmm11, xmm5
000075aec0bd5a65  vmovaps xmm4, [rsp+0x70]
000075aec0bd5a6b  vpermilpd xmm4, xmm4, 0x00
000075aec0bd5a71  movaps xmm3, xmm5
000075aec0bd5a74  mulpd xmm3, xmm4
000075aec0bd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000075aec0bd5a7d  ptest xmm2, xmm2
000075aec0bd5a82  jnz 0x000075AEC0BD6E07
000075aec0bd5a88  mov [rsp+0x80], rax
000075aec0bd5a90  xor eax, eax
000075aec0bd5a92  mov r14d, 0x200
000075aec0bd5a98  cmp r12, r14
000075aec0bd5a9b  cmc
000075aec0bd5a9c  lahf
000075aec0bd5a9d  seto al
000075aec0bd5aa0  mov [r15+0x108], eax
000075aec0bd5aa7  movaps xmm5, xmm8
000075aec0bd5aab  addpd xmm5, xmm15
000075aec0bd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000075aec0bd5ab5  ptest xmm4, xmm4
000075aec0bd5aba  jnz 0x000075AEC0BD6F47
000075aec0bd5ac0  movaps xmm8, [r15+0x1B0]
000075aec0bd5ac8  movaps xmm4, xmm9
000075aec0bd5acc  addpd xmm4, xmm8
000075aec0bd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000075aec0bd5ad6  ptest xmm2, xmm2
000075aec0bd5adb  jnz 0x000075AEC0BD7089
000075aec0bd5ae1  movaps xmm9, xmm10
000075aec0bd5ae5  addpd xmm9, xmm8
000075aec0bd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000075aec0bd5af0  ptest xmm2, xmm2
000075aec0bd5af5  jnz 0x000075AEC0BD71CB
000075aec0bd5afb  movaps xmm10, [r15+0x2F0]
000075aec0bd5b03  vmovaps [rsp+0x90], xmm10
000075aec0bd5b0c  vmovaps xmm8, [rsp+0x90]
000075aec0bd5b15  por xmm10, xmm8
000075aec0bd5b1a  movaps xmm8, [r15+0x2E0]
000075aec0bd5b22  vmovaps [rsp+0x90], xmm8
000075aec0bd5b2b  vmovaps xmm2, [rsp+0x90]
000075aec0bd5b34  por xmm8, xmm2
000075aec0bd5b39  movaps xmm2, [r15+0x2D0]
000075aec0bd5b41  vmovaps [rsp+0x90], xmm2
000075aec0bd5b4a  vmovaps [rsp+0xA0], xmm1
000075aec0bd5b53  vmovaps xmm1, [rsp+0x90]
000075aec0bd5b5c  por xmm2, xmm1
000075aec0bd5b60  movaps xmm1, [r15+0x200]
000075aec0bd5b68  vmovaps [rsp+0x90], xmm1
000075aec0bd5b71  vmovaps [rsp+0xB0], xmm15
000075aec0bd5b7a  vmovaps xmm15, [rsp+0x90]
000075aec0bd5b83  por xmm1, xmm15
000075aec0bd5b88  movaps xmm15, [r15+0x1C0]
000075aec0bd5b90  vmovaps [rsp+0x90], xmm15
000075aec0bd5b99  vmovaps [rsp+0xC0], xmm1
000075aec0bd5ba2  vmovaps xmm1, [rsp+0x90]
000075aec0bd5bab  por xmm15, xmm1
000075aec0bd5bb0  movaps xmm1, [r15+0x190]
000075aec0bd5bb8  vmovaps [rsp+0x90], xmm1
000075aec0bd5bc1  vmovaps [rsp+0xD0], xmm15
000075aec0bd5bca  vmovaps xmm15, [rsp+0x90]
000075aec0bd5bd3  por xmm1, xmm15
000075aec0bd5bd8  movaps xmm15, [r15+0x300]
000075aec0bd5be0  vmovaps [rsp+0x90], xmm15
000075aec0bd5be9  vmovaps [rsp+0xE0], xmm1
000075aec0bd5bf2  vmovaps xmm1, [rsp+0x90]
000075aec0bd5bfb  por xmm15, xmm1
000075aec0bd5c00  mov rax, [rsp+0x80]
000075aec0bd5c08  lea r14, [rax+0xA0]
000075aec0bd5c0f  movups xmm1, [r13+r14*1]
000075aec0bd5c15  lea r14, [rax+0xB0]
000075aec0bd5c1c  vmovaps [rsp+0x80], xmm1
000075aec0bd5c25  movups xmm1, [r13+r14*1]
000075aec0bd5c2b  vmovaps [rsp+0x90], xmm1
000075aec0bd5c34  vmovaps [rsp+0xF0], xmm15
000075aec0bd5c3d  vmovaps xmm15, [rsp+0xB0]
000075aec0bd5c46  vmovaps [rsp+0xB0], xmm14
000075aec0bd5c4f  movaps xmm1, xmm6
000075aec0bd5c52  addpd xmm1, xmm15
000075aec0bd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000075aec0bd5c5c  ptest xmm14, xmm14
000075aec0bd5c62  jnz 0x000075AEC0BD7323
000075aec0bd5c68  lea r14, [rax+0xF0]
000075aec0bd5c6f  movups xmm15, [r13+r14*1]
000075aec0bd5c75  movaps xmm14, xmm4
000075aec0bd5c79  addpd xmm14, xmm3
000075aec0bd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000075aec0bd5c84  ptest xmm6, xmm6
000075aec0bd5c89  jnz 0x000075AEC0BD746E
000075aec0bd5c8f  movaps xmm6, xmm9
000075aec0bd5c93  addpd xmm6, xmm7
000075aec0bd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000075aec0bd5c9c  ptest xmm4, xmm4
000075aec0bd5ca1  jnz 0x000075AEC0BD75B0
000075aec0bd5ca7  vmovaps xmm9, [rsp+0x70]
000075aec0bd5cad  vpermilpd xmm9, xmm9, 0x00
000075aec0bd5cb3  vmovaps xmm4, [rsp+0x90]
000075aec0bd5cbc  movaps xmm7, xmm4
000075aec0bd5cbf  mulpd xmm7, xmm9
000075aec0bd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000075aec0bd5cc9  ptest xmm3, xmm3
000075aec0bd5cce  jnz 0x000075AEC0BD76F1
000075aec0bd5cd4  vmovaps xmm9, [rsp+0x50]
000075aec0bd5cda  vpermilpd xmm9, xmm9, 0x00
000075aec0bd5ce0  movaps xmm4, xmm15
000075aec0bd5ce4  mulpd xmm4, xmm9
000075aec0bd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000075aec0bd5cee  ptest xmm3, xmm3
000075aec0bd5cf3  jnz 0x000075AEC0BD7832
000075aec0bd5cf9  lea r14, [rax+0xE0]
000075aec0bd5d00  movups xmm15, [r13+r14*1]
000075aec0bd5d06  vmovaps xmm9, [rsp+0x70]
000075aec0bd5d0c  vpermilpd xmm9, xmm9, 0x00
000075aec0bd5d12  vmovaps [rsp+0x70], xmm1
000075aec0bd5d18  vmovaps xmm1, [rsp+0x80]
000075aec0bd5d21  vmovaps [rsp+0x80], xmm15
000075aec0bd5d2a  movaps xmm3, xmm1
000075aec0bd5d2d  mulpd xmm3, xmm9
000075aec0bd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000075aec0bd5d37  ptest xmm15, xmm15
000075aec0bd5d3d  jnz 0x000075AEC0BD797E
000075aec0bd5d43  vmovaps xmm1, [rsp+0xF0]
000075aec0bd5d4c  vmovaps xmm15, [rsp+0xF0]
000075aec0bd5d55  por xmm1, xmm15
000075aec0bd5d5a  movaps [r15+0x300], xmm1
000075aec0bd5d62  vmovaps xmm15, [rsp+0xE0]
000075aec0bd5d6b  vmovaps xmm9, [rsp+0xE0]
000075aec0bd5d74  por xmm15, xmm9
000075aec0bd5d79  movaps [r15+0x190], xmm15
000075aec0bd5d81  vmovaps xmm9, [rsp+0x50]
000075aec0bd5d87  vpermilpd xmm9, xmm9, 0x00
000075aec0bd5d8d  vmovaps [rsp+0x90], xmm1
000075aec0bd5d96  vmovaps [rsp+0xE0], xmm15
000075aec0bd5d9f  vmovaps xmm15, [rsp+0x80]
000075aec0bd5da8  vmovaps [rsp+0x80], xmm14
000075aec0bd5db1  movaps xmm1, xmm15
000075aec0bd5db5  mulpd xmm1, xmm9
000075aec0bd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000075aec0bd5dbf  ptest xmm14, xmm14
000075aec0bd5dc5  jnz 0x000075AEC0BD7ABF
000075aec0bd5dcb  lea r14, [rax+0x90]
000075aec0bd5dd2  movups xmm15, [r13+r14*1]
000075aec0bd5dd8  vmovaps xmm14, [rsp+0xD0]
000075aec0bd5de1  vmovaps xmm9, [rsp+0xD0]
000075aec0bd5dea  por xmm14, xmm9
000075aec0bd5def  movaps [r15+0x1C0], xmm14
000075aec0bd5df7  vmovaps xmm9, [rsp+0xC0]
000075aec0bd5e00  vmovaps [rsp+0xD0], xmm1
000075aec0bd5e09  vmovaps xmm1, [rsp+0xC0]
000075aec0bd5e12  por xmm9, xmm1
000075aec0bd5e17  movaps [r15+0x200], xmm9
000075aec0bd5e1f  vmovaps [rsp+0xC0], xmm2
000075aec0bd5e28  vmovaps xmm1, [rsp+0xC0]
000075aec0bd5e31  por xmm2, xmm1
000075aec0bd5e35  movaps [r15+0x2D0], xmm2
000075aec0bd5e3d  vmovaps [rsp+0xC0], xmm8
000075aec0bd5e46  vmovaps xmm1, [rsp+0xC0]
000075aec0bd5e4f  por xmm8, xmm1
000075aec0bd5e54  movaps [r15+0x2E0], xmm8
000075aec0bd5e5c  vmovaps [rsp+0xC0], xmm15
000075aec0bd5e65  movaps xmm1, xmm5
000075aec0bd5e68  addpd xmm1, xmm7
000075aec0bd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000075aec0bd5e71  ptest xmm15, xmm15
000075aec0bd5e77  jnz 0x000075AEC0BD7C0B
000075aec0bd5e7d  vmovaps xmm15, [rsp+0x50]
000075aec0bd5e83  vpermilpd xmm15, xmm15, 0x00
000075aec0bd5e89  vmovaps xmm5, [rsp+0xC0]
000075aec0bd5e92  vmovaps [rsp+0xC0], xmm1
000075aec0bd5e9b  movaps xmm7, xmm5
000075aec0bd5e9e  mulpd xmm7, xmm15
000075aec0bd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000075aec0bd5ea8  ptest xmm1, xmm1
000075aec0bd5ead  jnz 0x000075AEC0BD7D4B
000075aec0bd5eb3  lea r14, [rax+0x80]
000075aec0bd5eba  movups xmm1, [r13+r14*1]
000075aec0bd5ec0  vmovaps xmm5, [rsp+0x70]
000075aec0bd5ec6  vmovaps [rsp+0x70], xmm1
000075aec0bd5ecc  movaps xmm15, xmm5
000075aec0bd5ed0  addpd xmm15, xmm3
000075aec0bd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bd5edb  ptest xmm1, xmm1
000075aec0bd5ee0  jnz 0x000075AEC0BD7E96
000075aec0bd5ee6  vmovaps xmm5, [rsp+0x80]
000075aec0bd5eef  movaps xmm1, xmm5
000075aec0bd5ef2  addpd xmm1, xmm4
000075aec0bd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000075aec0bd5efb  ptest xmm3, xmm3
000075aec0bd5f00  jnz 0x000075AEC0BD7FD8
000075aec0bd5f06  vmovaps [rsp+0x80], xmm10
000075aec0bd5f0f  vmovaps xmm5, [rsp+0x80]
000075aec0bd5f18  por xmm10, xmm5
000075aec0bd5f1d  movaps [r15+0x2F0], xmm10
000075aec0bd5f25  vmovaps xmm5, [rsp+0x50]
000075aec0bd5f2b  vpermilpd xmm5, xmm5, 0x00
000075aec0bd5f31  vmovaps xmm3, [rsp+0x70]
000075aec0bd5f37  vmovaps [rsp+0x50], xmm1
000075aec0bd5f3d  movaps xmm4, xmm3
000075aec0bd5f40  mulpd xmm4, xmm5
000075aec0bd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000075aec0bd5f49  ptest xmm1, xmm1
000075aec0bd5f4e  jnz 0x000075AEC0BD8118
000075aec0bd5f54  lea r14, [rax+0xD0]
000075aec0bd5f5b  movups xmm1, [r13+r14*1]
000075aec0bd5f61  vmovaps xmm3, [rsp+0xD0]
000075aec0bd5f6a  vmovaps [rsp+0x70], xmm1
000075aec0bd5f70  movaps xmm5, xmm6
000075aec0bd5f73  addpd xmm5, xmm3
000075aec0bd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000075aec0bd5f7c  ptest xmm1, xmm1
000075aec0bd5f81  jnz 0x000075AEC0BD8262
000075aec0bd5f87  vmovaps xmm1, [rsp+0x60]
000075aec0bd5f8d  vpermilpd xmm1, xmm1, 0x00
000075aec0bd5f93  movaps xmm6, xmm9
000075aec0bd5f97  mulpd xmm6, xmm1
000075aec0bd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000075aec0bd5fa0  ptest xmm3, xmm3
000075aec0bd5fa5  jnz 0x000075AEC0BD83A2
000075aec0bd5fab  movaps [r15+0x260], xmm6
000075aec0bd5fb3  vxorps xmm1, xmm1, xmm1
000075aec0bd5fb7  vpbroadcastq xmm1, xmm1
000075aec0bd5fbc  movaps [r15+0x1B0], xmm1
000075aec0bd5fc4  vmovaps xmm1, [rsp+0x60]
000075aec0bd5fca  vpermilpd xmm1, xmm1, 0x00
000075aec0bd5fd0  vmovaps xmm3, [rsp+0x70]
000075aec0bd5fd6  vmovaps [rsp+0x70], xmm15
000075aec0bd5fdc  movaps xmm9, xmm3
000075aec0bd5fe0  mulpd xmm9, xmm1
000075aec0bd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000075aec0bd5feb  ptest xmm15, xmm15
000075aec0bd5ff1  jnz 0x000075AEC0BD84E3
000075aec0bd5ff7  lea r14, [rax+0xC0]
000075aec0bd5ffe  movups xmm1, [r13+r14*1]
000075aec0bd6004  vmovaps xmm3, [rsp+0xC0]
000075aec0bd600d  vmovaps [rsp+0x80], xmm1
000075aec0bd6016  movaps xmm15, xmm3
000075aec0bd601a  addpd xmm15, xmm7
000075aec0bd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bd6025  ptest xmm1, xmm1
000075aec0bd602a  jnz 0x000075AEC0BD862F
000075aec0bd6030  vmovaps [rsp+0xC0], xmm13
000075aec0bd6039  vmovaps xmm1, [rsp+0xC0]
000075aec0bd6042  por xmm13, xmm1
000075aec0bd6047  movaps [r15+0x270], xmm13
000075aec0bd604f  vmovaps xmm1, [rsp+0xB0]
000075aec0bd6058  vmovaps xmm7, [rsp+0xB0]
000075aec0bd6061  por xmm1, xmm7
000075aec0bd6065  movaps [r15+0x1A0], xmm1
000075aec0bd606d  vmovaps xmm1, [rsp+0x60]
000075aec0bd6073  vpermilpd xmm1, xmm1, 0x00
000075aec0bd6079  vmovaps [rsp+0xB0], xmm1
000075aec0bd6082  vmovaps xmm1, [rsp+0x80]
000075aec0bd608b  vmovaps [rsp+0x80], xmm15
000075aec0bd6094  vmovaps xmm15, [rsp+0xB0]
000075aec0bd609d  vmovaps [rsp+0xB0], xmm14
000075aec0bd60a6  movaps xmm3, xmm1
000075aec0bd60a9  mulpd xmm3, xmm15
000075aec0bd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000075aec0bd60b3  ptest xmm14, xmm14
000075aec0bd60b9  jnz 0x000075AEC0BD8771
000075aec0bd60bf  lea r14, [rax+0x20]
000075aec0bd60c3  movups xmm1, [r13+r14*1]
000075aec0bd60c9  movaps [r15+0x110], xmm1
000075aec0bd60d1  vmovaps xmm14, [rsp+0x70]
000075aec0bd60d7  vmovaps [rsp+0x70], xmm1
000075aec0bd60dd  movaps xmm15, xmm14
000075aec0bd60e1  addpd xmm15, xmm4
000075aec0bd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bd60ec  ptest xmm1, xmm1
000075aec0bd60f1  jnz 0x000075AEC0BD88BC
000075aec0bd60f7  vmovaps xmm1, [rsp+0x60]
000075aec0bd60fd  vpermilpd xmm1, xmm1, 0x00
000075aec0bd6103  movaps xmm14, xmm2
000075aec0bd6107  mulpd xmm14, xmm1
000075aec0bd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000075aec0bd6112  ptest xmm4, xmm4
000075aec0bd6117  jnz 0x000075AEC0BD89FF
000075aec0bd611d  vmovaps xmm4, [rsp+0x50]
000075aec0bd6123  movaps xmm1, xmm4
000075aec0bd6126  addpd xmm1, xmm9
000075aec0bd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000075aec0bd6130  ptest xmm2, xmm2
000075aec0bd6135  jnz 0x000075AEC0BD8B41
000075aec0bd613b  vmovaps xmm9, [rsp+0x30]
000075aec0bd6141  vpermilpd xmm9, xmm9, 0x00
000075aec0bd6147  vmovaps xmm2, [rsp+0x70]
000075aec0bd614d  vmovaps [rsp+0x50], xmm1
000075aec0bd6153  movaps xmm4, xmm2
000075aec0bd6156  mulpd xmm4, xmm9
000075aec0bd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000075aec0bd6160  ptest xmm1, xmm1
000075aec0bd6165  jnz 0x000075AEC0BD8C82
000075aec0bd616b  vmovaps xmm1, [rsp+0x30]
000075aec0bd6171  vpermilpd xmm1, xmm1, 0x00
000075aec0bd6177  vmovaps xmm2, [rsp+0x90]
000075aec0bd6180  vmovaps [rsp+0x60], xmm15
000075aec0bd6186  movaps xmm9, xmm2
000075aec0bd618a  mulpd xmm9, xmm1
000075aec0bd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000075aec0bd6195  ptest xmm15, xmm15
000075aec0bd619b  jnz 0x000075AEC0BD8DC3
000075aec0bd61a1  vmovaps xmm15, [rsp+0x80]
000075aec0bd61aa  movaps xmm1, xmm15
000075aec0bd61ae  addpd xmm1, xmm6
000075aec0bd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000075aec0bd61b7  ptest xmm2, xmm2
000075aec0bd61bc  jnz 0x000075AEC0BD8F05
000075aec0bd61c2  movaps xmm15, xmm5
000075aec0bd61c6  addpd xmm15, xmm3
000075aec0bd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000075aec0bd61d1  ptest xmm6, xmm6
000075aec0bd61d6  jnz 0x000075AEC0BD9046
000075aec0bd61dc  vmovaps xmm6, [rsp+0x30]
000075aec0bd61e2  vpermilpd xmm6, xmm6, 0x00
000075aec0bd61e8  movaps xmm5, xmm8
000075aec0bd61ec  mulpd xmm5, xmm6
000075aec0bd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000075aec0bd61f5  ptest xmm3, xmm3
000075aec0bd61fa  jnz 0x000075AEC0BD9188
000075aec0bd6200  vmovaps xmm8, [rsp+0x30]
000075aec0bd6206  vpermilpd xmm8, xmm8, 0x00
000075aec0bd620c  movaps xmm6, xmm10
000075aec0bd6210  mulpd xmm6, xmm8
000075aec0bd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000075aec0bd621a  ptest xmm3, xmm3
000075aec0bd621f  jnz 0x000075AEC0BD92C9
000075aec0bd6225  vmovaps xmm8, [rsp+0x60]
000075aec0bd622b  movaps xmm10, xmm8
000075aec0bd622f  addpd xmm10, xmm14
000075aec0bd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000075aec0bd623a  ptest xmm3, xmm3
000075aec0bd623f  jnz 0x000075AEC0BD940B
000075aec0bd6245  vmovaps xmm8, [rsp+0x50]
000075aec0bd624b  movaps xmm14, xmm8
000075aec0bd624f  addpd xmm14, xmm4
000075aec0bd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000075aec0bd625a  ptest xmm3, xmm3
000075aec0bd625f  jnz 0x000075AEC0BD954F
000075aec0bd6265  vmovaps xmm8, [rsp+0x40]
000075aec0bd626b  vpermilpd xmm8, xmm8, 0x00
000075aec0bd6271  movaps xmm4, xmm13
000075aec0bd6275  mulpd xmm4, xmm8
000075aec0bd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000075aec0bd627f  ptest xmm3, xmm3
000075aec0bd6284  jnz 0x000075AEC0BD9692
000075aec0bd628a  movaps xmm13, xmm15
000075aec0bd628e  addpd xmm13, xmm9
000075aec0bd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000075aec0bd6299  ptest xmm8, xmm8
000075aec0bd629f  jnz 0x000075AEC0BD97D4
000075aec0bd62a5  movaps xmm15, xmm1
000075aec0bd62a9  addpd xmm15, xmm5
000075aec0bd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000075aec0bd62b4  ptest xmm9, xmm9
000075aec0bd62ba  jnz 0x000075AEC0BD9918
000075aec0bd62c0  vmovaps [rsp+0x30], xmm11
000075aec0bd62c6  vmovaps xmm1, [rsp+0x30]
000075aec0bd62cc  por xmm11, xmm1
000075aec0bd62d1  movaps [r15+0x250], xmm11
000075aec0bd62d9  vmovaps [rsp+0x30], xmm12
000075aec0bd62df  vmovaps xmm1, [rsp+0x30]
000075aec0bd62e5  por xmm12, xmm1
000075aec0bd62ea  movaps [r15+0x2A0], xmm12
000075aec0bd62f2  vmovaps xmm1, [rsp+0xA0]
000075aec0bd62fb  vmovaps xmm11, [rsp+0xA0]
000075aec0bd6304  por xmm1, xmm11
000075aec0bd6309  movaps [r15+0x1D0], xmm1
000075aec0bd6311  lea r14, [rax+0x40]
000075aec0bd6315  movups xmm1, [r13+r14*1]
000075aec0bd631b  movaps [r15+0x2C0], xmm1
000075aec0bd6323  vmovaps xmm11, [rsp+0x40]
000075aec0bd6329  vpermilpd xmm11, xmm11, 0x00
000075aec0bd632f  vmovaps xmm8, [rsp+0xE0]
000075aec0bd6338  movaps xmm9, xmm8
000075aec0bd633c  mulpd xmm9, xmm11
000075aec0bd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000075aec0bd6347  ptest xmm5, xmm5
000075aec0bd634c  jnz 0x000075AEC0BD9A64
000075aec0bd6352  movaps xmm11, xmm10
000075aec0bd6356  addpd xmm11, xmm6
000075aec0bd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000075aec0bd6361  ptest xmm8, xmm8
000075aec0bd6367  jnz 0x000075AEC0BD9BA8
000075aec0bd636d  movaps xmm10, xmm14
000075aec0bd6371  addpd xmm10, xmm4
000075aec0bd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000075aec0bd637c  ptest xmm8, xmm8
000075aec0bd6382  jnz 0x000075AEC0BD9CEB
000075aec0bd6388  vmovaps xmm14, [rsp+0x40]
000075aec0bd638e  vpermilpd xmm14, xmm14, 0x00
000075aec0bd6394  movaps xmm8, xmm1
000075aec0bd6398  mulpd xmm8, xmm14
000075aec0bd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000075aec0bd63a3  ptest xmm6, xmm6
000075aec0bd63a8  jnz 0x000075AEC0BD9E2E
000075aec0bd63ae  movaps xmm1, [r15+0x2B0]
000075aec0bd63b6  vmovaps xmm14, [rsp+0x40]
000075aec0bd63bc  vpermilpd xmm14, xmm14, 0x00
000075aec0bd63c2  movaps xmm6, xmm1
000075aec0bd63c5  mulpd xmm6, xmm14
000075aec0bd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000075aec0bd63cf  ptest xmm5, xmm5
000075aec0bd63d4  jnz 0x000075AEC0BD9F71
000075aec0bd63da  vmovaps xmm1, [rsp+0x10]
000075aec0bd63e0  vpermilpd xmm1, xmm1, 0x00
000075aec0bd63e6  movaps xmm14, xmm12
000075aec0bd63ea  mulpd xmm14, xmm1
000075aec0bd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000075aec0bd63f5  ptest xmm5, xmm5
000075aec0bd63fa  jnz 0x000075AEC0BDA0B2
000075aec0bd6400  movaps xmm1, xmm13
000075aec0bd6404  addpd xmm1, xmm9
000075aec0bd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000075aec0bd640e  ptest xmm12, xmm12
000075aec0bd6414  jnz 0x000075AEC0BDA1F5
000075aec0bd641a  vmovaps xmm13, [rsp+0x10]
000075aec0bd6420  vpermilpd xmm13, xmm13, 0x00
000075aec0bd6426  movaps xmm12, xmm7
000075aec0bd642a  mulpd xmm12, xmm13
000075aec0bd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000075aec0bd6435  ptest xmm9, xmm9
000075aec0bd643b  jnz 0x000075AEC0BDA337
000075aec0bd6441  movaps xmm13, xmm15
000075aec0bd6445  addpd xmm13, xmm8
000075aec0bd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000075aec0bd6450  ptest xmm9, xmm9
000075aec0bd6456  jnz 0x000075AEC0BDA47A
000075aec0bd645c  movaps xmm15, [r15+0x290]
000075aec0bd6464  vmovaps xmm9, [rsp+0x10]
000075aec0bd646a  vpermilpd xmm9, xmm9, 0x00
000075aec0bd6470  movaps xmm8, xmm15
000075aec0bd6474  mulpd xmm8, xmm9
000075aec0bd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000075aec0bd647f  ptest xmm7, xmm7
000075aec0bd6484  jnz 0x000075AEC0BDA5BE
000075aec0bd648a  movaps xmm15, xmm11
000075aec0bd648e  addpd xmm15, xmm6
000075aec0bd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000075aec0bd6499  ptest xmm9, xmm9
000075aec0bd649f  jnz 0x000075AEC0BDA702
000075aec0bd64a5  movaps xmm11, [r15+0x1E0]
000075aec0bd64ad  vmovaps xmm9, [rsp+0x10]
000075aec0bd64b3  vpermilpd xmm9, xmm9, 0x00
000075aec0bd64b9  movaps xmm7, xmm11
000075aec0bd64bd  mulpd xmm7, xmm9
000075aec0bd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000075aec0bd64c7  ptest xmm6, xmm6
000075aec0bd64cc  jnz 0x000075AEC0BDA845
000075aec0bd64d2  movaps xmm11, xmm10
000075aec0bd64d6  addpd xmm11, xmm14
000075aec0bd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000075aec0bd64e1  ptest xmm9, xmm9
000075aec0bd64e7  jnz 0x000075AEC0BDA987
000075aec0bd64ed  lea r14, [rax+0x70]
000075aec0bd64f1  movups xmm14, [r13+r14*1]
000075aec0bd64f7  movaps [r15+0x240], xmm14
000075aec0bd64ff  movaps xmm10, xmm1
000075aec0bd6503  addpd xmm10, xmm12
000075aec0bd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000075aec0bd650e  ptest xmm9, xmm9
000075aec0bd6514  jnz 0x000075AEC0BDAAD5
000075aec0bd651a  movaps [r15+0x170], xmm10
000075aec0bd6522  vmovaps xmm1, [rsp+0x20]
000075aec0bd6528  vpermilpd xmm1, xmm1, 0x00
000075aec0bd652e  movaps xmm12, xmm14
000075aec0bd6532  mulpd xmm12, xmm1
000075aec0bd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000075aec0bd653d  ptest xmm9, xmm9
000075aec0bd6543  jnz 0x000075AEC0BDAC18
000075aec0bd6549  vmovaps xmm1, [rsp+0x20]
000075aec0bd654f  vpermilpd xmm1, xmm1, 0x00
000075aec0bd6555  vmovaps xmm9, [rsp+0xB0]
000075aec0bd655e  movaps xmm14, xmm9
000075aec0bd6562  mulpd xmm14, xmm1
000075aec0bd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000075aec0bd656d  ptest xmm6, xmm6
000075aec0bd6572  jnz 0x000075AEC0BDAD5B
000075aec0bd6578  movaps [r15+0x180], xmm14
000075aec0bd6580  movaps xmm1, xmm13
000075aec0bd6584  addpd xmm1, xmm8
000075aec0bd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000075aec0bd658e  ptest xmm9, xmm9
000075aec0bd6594  jnz 0x000075AEC0BDAE9E
000075aec0bd659a  movaps [r15+0x210], xmm1
000075aec0bd65a2  movups xmm13, [r13+rax*1]
000075aec0bd65a8  lea r14, [rax+0x10]
000075aec0bd65ac  movups xmm9, [r13+r14*1]
000075aec0bd65b2  movaps [r15+0x230], xmm9
000075aec0bd65ba  movaps xmm8, xmm15
000075aec0bd65be  addpd xmm8, xmm7
000075aec0bd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000075aec0bd65c9  ptest xmm6, xmm6
000075aec0bd65ce  jnz 0x000075AEC0BDAFF4
000075aec0bd65d4  movaps [r15+0x130], xmm8
000075aec0bd65dc  vmovaps xmm15, [rsp+0x20]
000075aec0bd65e2  vpermilpd xmm15, xmm15, 0x00
000075aec0bd65e8  movaps xmm7, xmm9
000075aec0bd65ec  mulpd xmm7, xmm15
000075aec0bd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000075aec0bd65f6  ptest xmm6, xmm6
000075aec0bd65fb  jnz 0x000075AEC0BDB137
000075aec0bd6601  movaps [r15+0x220], xmm7
000075aec0bd6609  vmovaps xmm15, [rsp+0x20]
000075aec0bd660f  vpermilpd xmm15, xmm15, 0x00
000075aec0bd6615  movaps xmm9, xmm13
000075aec0bd6619  mulpd xmm9, xmm15
000075aec0bd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000075aec0bd6624  ptest xmm6, xmm6
000075aec0bd6629  jnz 0x000075AEC0BDB279
000075aec0bd662f  movaps xmm15, xmm11
000075aec0bd6633  addpd xmm15, xmm12
000075aec0bd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000075aec0bd663e  ptest xmm13, xmm13
000075aec0bd6644  jnz 0x000075AEC0BDB3BD
000075aec0bd664a  movaps [r15+0x140], xmm15
000075aec0bd6652  movaps xmm13, xmm10
000075aec0bd6656  addpd xmm13, xmm14
000075aec0bd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000075aec0bd6661  ptest xmm12, xmm12
000075aec0bd6667  jnz 0x000075AEC0BDB501
000075aec0bd666d  movaps [r15+0x150], xmm13
000075aec0bd6675  movaps xmm14, xmm1
000075aec0bd6679  addpd xmm14, xmm7
000075aec0bd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000075aec0bd6684  ptest xmm12, xmm12
000075aec0bd668a  jnz 0x000075AEC0BDB645
000075aec0bd6690  movaps [r15+0x160], xmm14
000075aec0bd6698  movaps xmm1, xmm8
000075aec0bd669c  addpd xmm1, xmm9
000075aec0bd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000075aec0bd66a6  ptest xmm12, xmm12
000075aec0bd66ac  jnz 0x000075AEC0BDB787
000075aec0bd66b2  movaps [r15+0x120], xmm1
000075aec0bd66ba  movups [r13+r11*1], xmm15
000075aec0bd66c0  lea rax, [r11+0x10]
000075aec0bd66c4  movups [r13+rax*1], xmm13
000075aec0bd66ca  lea rax, [r11+0x20]
000075aec0bd66ce  movups [r13+rax*1], xmm14
000075aec0bd66d4  lea rax, [r11+0x30]
000075aec0bd66d8  movups [r13+rax*1], xmm1
000075aec0bd66de  mov eax, [r15+0x108]
000075aec0bd66e5  sahf
000075aec0bd66e6  jnz 0x000075AEC0BD6718
000075aec0bd66e8  cmp dword ptr [r15+0x318], 0x00
000075aec0bd66f0  jz 0x000075AEC0BDB900
000075aec0bd66f6  nop [rax+rax*1], ax
000075aec0bd66ff  nop [rax+rax*1], eax
000075aec0bd6707  mov eax, 0x410444
000075aec0bd670c  mov [r15+0x100], rax
000075aec0bd6713  jmp 0x000075AEC09FE110
000075aec0bd6718  cmp dword ptr [r15+0x318], 0x00
000075aec0bd6720  jz 0x000075AEC0BD57E0
000075aec0bd6726  nop [rax+rax*1], ax
000075aec0bd672f  nop [rax+rax*1], eax
000075aec0bd6737  mov eax, 0x410278
000075aec0bd673c  mov [r15+0x100], rax
000075aec0bd6743  jmp 0x000075AEC09FE110
000075aec0bd6748  int3
000075aec0bd6749  call 0x000075AEC0A0A4B0
000075aec0bd674e  jmp 0x000075AEC0BD5828
000075aec0bd6753  call 0x000075AEC0A09240
000075aec0bd6758  jmp 0x000075AEC0BD5832
000075aec0bd675d  call 0x000075AEC0A0A4B0
000075aec0bd6762  jmp 0x000075AEC0BD588F
000075aec0bd6767  call 0x000075AEC0A09240
000075aec0bd676c  jmp 0x000075AEC0BD5899
000075aec0bd6771  call 0x000075AEC0A0A4B0
000075aec0bd6776  jmp 0x000075AEC0BD58DD
000075aec0bd677b  call 0x000075AEC0A09240
000075aec0bd6780  jmp 0x000075AEC0BD58E7
000075aec0bd6785  call 0x000075AEC0AB47C0
000075aec0bd678a  jmp 0x000075AEC0BD5926
000075aec0bd678f  call 0x000075AEC0A0B720
000075aec0bd6794  jmp 0x000075AEC0BD593A
000075aec0bd6799  call 0x000075AEC0ABFC30
000075aec0bd679e  jmp 0x000075AEC0BD5958
000075aec0bd67a3  call 0x000075AEC0ABE9C0
000075aec0bd67a8  jmp 0x000075AEC0BD5962
000075aec0bd67ad  call 0x000075AEC0ABD750
000075aec0bd67b2  jmp 0x000075AEC0BD596C
000075aec0bd67b7  sub rsp, 0x08
000075aec0bd67bb  push rax
000075aec0bd67bc  push rcx
000075aec0bd67bd  push rdx
000075aec0bd67be  push rdi
000075aec0bd67bf  push rsi
000075aec0bd67c0  push r8
000075aec0bd67c2  push r9
000075aec0bd67c4  push r10
000075aec0bd67c6  push r11
000075aec0bd67c8  sub rsp, 0xF0
000075aec0bd67cf  vmovaps [rsp], xmm0
000075aec0bd67d4  vmovaps [rsp+0x10], xmm1
000075aec0bd67da  vmovaps [rsp+0x20], xmm2
000075aec0bd67e0  vmovaps [rsp+0x30], xmm3
000075aec0bd67e6  vmovaps [rsp+0x40], xmm4
000075aec0bd67ec  vmovaps [rsp+0x50], xmm5
000075aec0bd67f2  vmovaps [rsp+0x60], xmm6
000075aec0bd67f8  vmovaps [rsp+0x70], xmm7
000075aec0bd67fe  vmovaps [rsp+0x80], xmm9
000075aec0bd6807  vmovaps [rsp+0x90], xmm10
000075aec0bd6810  vmovaps [rsp+0xA0], xmm11
000075aec0bd6819  vmovaps [rsp+0xB0], xmm12
000075aec0bd6822  vmovaps [rsp+0xC0], xmm13
000075aec0bd682b  vmovaps [rsp+0xD0], xmm14
000075aec0bd6834  vmovaps [rsp+0xE0], xmm15
000075aec0bd683d  sub rsp, 0x30
000075aec0bd6841  movaps [rsp], xmm8
000075aec0bd6846  movaps [rsp+0x10], xmm12
000075aec0bd684c  movaps [rsp+0x20], xmm15
000075aec0bd6852  lea rdi, [rsp]
000075aec0bd6856  mov esi, 0x00
000075aec0bd685b  mov rax, 0x57F4B31E6530
000075aec0bd6865  call rax
000075aec0bd6867  movaps xmm8, [rsp]
000075aec0bd686c  add rsp, 0x30
000075aec0bd6870  vmovaps xmm0, [rsp]
000075aec0bd6875  vmovaps xmm1, [rsp+0x10]
000075aec0bd687b  vmovaps xmm2, [rsp+0x20]
000075aec0bd6881  vmovaps xmm3, [rsp+0x30]
000075aec0bd6887  vmovaps xmm4, [rsp+0x40]
000075aec0bd688d  vmovaps xmm5, [rsp+0x50]
000075aec0bd6893  vmovaps xmm6, [rsp+0x60]
000075aec0bd6899  vmovaps xmm7, [rsp+0x70]
000075aec0bd689f  vmovaps xmm9, [rsp+0x80]
000075aec0bd68a8  vmovaps xmm10, [rsp+0x90]
000075aec0bd68b1  vmovaps xmm11, [rsp+0xA0]
000075aec0bd68ba  vmovaps xmm12, [rsp+0xB0]
000075aec0bd68c3  vmovaps xmm13, [rsp+0xC0]
000075aec0bd68cc  vmovaps xmm14, [rsp+0xD0]
000075aec0bd68d5  vmovaps xmm15, [rsp+0xE0]
000075aec0bd68de  add rsp, 0xF0
000075aec0bd68e5  pop r11
000075aec0bd68e7  pop r10
000075aec0bd68e9  pop r9
000075aec0bd68eb  pop r8
000075aec0bd68ed  pop rsi
000075aec0bd68ee  pop rdi
000075aec0bd68ef  pop rdx
000075aec0bd68f0  pop rcx
000075aec0bd68f1  pop rax
000075aec0bd68f2  add rsp, 0x08
000075aec0bd68f6  jmp 0x000075AEC0BD599A
000075aec0bd68fb  sub rsp, 0x08
000075aec0bd68ff  push rax
000075aec0bd6900  push rcx
000075aec0bd6901  push rdx
000075aec0bd6902  push rdi
000075aec0bd6903  push rsi
000075aec0bd6904  push r8
000075aec0bd6906  push r9
000075aec0bd6908  push r10
000075aec0bd690a  push r11
000075aec0bd690c  sub rsp, 0xF0
000075aec0bd6913  vmovaps [rsp], xmm0
000075aec0bd6918  vmovaps [rsp+0x10], xmm1
000075aec0bd691e  vmovaps [rsp+0x20], xmm2
000075aec0bd6924  vmovaps [rsp+0x30], xmm3
000075aec0bd692a  vmovaps [rsp+0x40], xmm4
000075aec0bd6930  vmovaps [rsp+0x50], xmm5
000075aec0bd6936  vmovaps [rsp+0x60], xmm6
000075aec0bd693c  vmovaps [rsp+0x70], xmm8
000075aec0bd6942  vmovaps [rsp+0x80], xmm9
000075aec0bd694b  vmovaps [rsp+0x90], xmm10
000075aec0bd6954  vmovaps [rsp+0xA0], xmm11
000075aec0bd695d  vmovaps [rsp+0xB0], xmm12
000075aec0bd6966  vmovaps [rsp+0xC0], xmm13
000075aec0bd696f  vmovaps [rsp+0xD0], xmm14
000075aec0bd6978  vmovaps [rsp+0xE0], xmm15
000075aec0bd6981  sub rsp, 0x30
000075aec0bd6985  movaps [rsp], xmm7
000075aec0bd6989  movaps [rsp+0x10], xmm9
000075aec0bd698f  movaps [rsp+0x20], xmm15
000075aec0bd6995  lea rdi, [rsp]
000075aec0bd6999  mov esi, 0x00
000075aec0bd699e  mov rax, 0x57F4B31E6530
000075aec0bd69a8  call rax
000075aec0bd69aa  movaps xmm7, [rsp]
000075aec0bd69ae  add rsp, 0x30
000075aec0bd69b2  vmovaps xmm0, [rsp]
000075aec0bd69b7  vmovaps xmm1, [rsp+0x10]
000075aec0bd69bd  vmovaps xmm2, [rsp+0x20]
000075aec0bd69c3  vmovaps xmm3, [rsp+0x30]
000075aec0bd69c9  vmovaps xmm4, [rsp+0x40]
000075aec0bd69cf  vmovaps xmm5, [rsp+0x50]
000075aec0bd69d5  vmovaps xmm6, [rsp+0x60]
000075aec0bd69db  vmovaps xmm8, [rsp+0x70]
000075aec0bd69e1  vmovaps xmm9, [rsp+0x80]
000075aec0bd69ea  vmovaps xmm10, [rsp+0x90]
000075aec0bd69f3  vmovaps xmm11, [rsp+0xA0]
000075aec0bd69fc  vmovaps xmm12, [rsp+0xB0]
000075aec0bd6a05  vmovaps xmm13, [rsp+0xC0]
000075aec0bd6a0e  vmovaps xmm14, [rsp+0xD0]
000075aec0bd6a17  vmovaps xmm15, [rsp+0xE0]
000075aec0bd6a20  add rsp, 0xF0
000075aec0bd6a27  pop r11
000075aec0bd6a29  pop r10
000075aec0bd6a2b  pop r9
000075aec0bd6a2d  pop r8
000075aec0bd6a2f  pop rsi
000075aec0bd6a30  pop rdi
000075aec0bd6a31  pop rdx
000075aec0bd6a32  pop rcx
000075aec0bd6a33  pop rax
000075aec0bd6a34  add rsp, 0x08
000075aec0bd6a38  jmp 0x000075AEC0BD59C8
000075aec0bd6a3d  sub rsp, 0x08
000075aec0bd6a41  push rax
000075aec0bd6a42  push rcx
000075aec0bd6a43  push rdx
000075aec0bd6a44  push rdi
000075aec0bd6a45  push rsi
000075aec0bd6a46  push r8
000075aec0bd6a48  push r9
000075aec0bd6a4a  push r10
000075aec0bd6a4c  push r11
000075aec0bd6a4e  sub rsp, 0xF0
000075aec0bd6a55  vmovaps [rsp], xmm0
000075aec0bd6a5a  vmovaps [rsp+0x10], xmm1
000075aec0bd6a60  vmovaps [rsp+0x20], xmm2
000075aec0bd6a66  vmovaps [rsp+0x30], xmm3
000075aec0bd6a6c  vmovaps [rsp+0x40], xmm4
000075aec0bd6a72  vmovaps [rsp+0x50], xmm5
000075aec0bd6a78  vmovaps [rsp+0x60], xmm6
000075aec0bd6a7e  vmovaps [rsp+0x70], xmm7
000075aec0bd6a84  vmovaps [rsp+0x80], xmm8
000075aec0bd6a8d  vmovaps [rsp+0x90], xmm10
000075aec0bd6a96  vmovaps [rsp+0xA0], xmm11
000075aec0bd6a9f  vmovaps [rsp+0xB0], xmm12
000075aec0bd6aa8  vmovaps [rsp+0xC0], xmm13
000075aec0bd6ab1  vmovaps [rsp+0xD0], xmm14
000075aec0bd6aba  vmovaps [rsp+0xE0], xmm15
000075aec0bd6ac3  sub rsp, 0x30
000075aec0bd6ac7  movaps [rsp], xmm9
000075aec0bd6acc  movaps [rsp+0x10], xmm12
000075aec0bd6ad2  movaps [rsp+0x20], xmm10
000075aec0bd6ad8  lea rdi, [rsp]
000075aec0bd6adc  mov esi, 0x00
000075aec0bd6ae1  mov rax, 0x57F4B31E6530
000075aec0bd6aeb  call rax
000075aec0bd6aed  movaps xmm9, [rsp]
000075aec0bd6af2  add rsp, 0x30
000075aec0bd6af6  vmovaps xmm0, [rsp]
000075aec0bd6afb  vmovaps xmm1, [rsp+0x10]
000075aec0bd6b01  vmovaps xmm2, [rsp+0x20]
000075aec0bd6b07  vmovaps xmm3, [rsp+0x30]
000075aec0bd6b0d  vmovaps xmm4, [rsp+0x40]
000075aec0bd6b13  vmovaps xmm5, [rsp+0x50]
000075aec0bd6b19  vmovaps xmm6, [rsp+0x60]
000075aec0bd6b1f  vmovaps xmm7, [rsp+0x70]
000075aec0bd6b25  vmovaps xmm8, [rsp+0x80]
000075aec0bd6b2e  vmovaps xmm10, [rsp+0x90]
000075aec0bd6b37  vmovaps xmm11, [rsp+0xA0]
000075aec0bd6b40  vmovaps xmm12, [rsp+0xB0]
000075aec0bd6b49  vmovaps xmm13, [rsp+0xC0]
000075aec0bd6b52  vmovaps xmm14, [rsp+0xD0]
000075aec0bd6b5b  vmovaps xmm15, [rsp+0xE0]
000075aec0bd6b64  add rsp, 0xF0
000075aec0bd6b6b  pop r11
000075aec0bd6b6d  pop r10
000075aec0bd6b6f  pop r9
000075aec0bd6b71  pop r8
000075aec0bd6b73  pop rsi
000075aec0bd6b74  pop rdi
000075aec0bd6b75  pop rdx
000075aec0bd6b76  pop rcx
000075aec0bd6b77  pop rax
000075aec0bd6b78  add rsp, 0x08
000075aec0bd6b7c  jmp 0x000075AEC0BD59EC
000075aec0bd6b81  sub rsp, 0x08
000075aec0bd6b85  push rax
000075aec0bd6b86  push rcx
000075aec0bd6b87  push rdx
000075aec0bd6b88  push rdi
000075aec0bd6b89  push rsi
000075aec0bd6b8a  push r8
000075aec0bd6b8c  push r9
000075aec0bd6b8e  push r10
000075aec0bd6b90  push r11
000075aec0bd6b92  sub rsp, 0xF0
000075aec0bd6b99  vmovaps [rsp], xmm0
000075aec0bd6b9e  vmovaps [rsp+0x10], xmm1
000075aec0bd6ba4  vmovaps [rsp+0x20], xmm2
000075aec0bd6baa  vmovaps [rsp+0x30], xmm3
000075aec0bd6bb0  vmovaps [rsp+0x40], xmm4
000075aec0bd6bb6  vmovaps [rsp+0x50], xmm5
000075aec0bd6bbc  vmovaps [rsp+0x60], xmm6
000075aec0bd6bc2  vmovaps [rsp+0x70], xmm7
000075aec0bd6bc8  vmovaps [rsp+0x80], xmm8
000075aec0bd6bd1  vmovaps [rsp+0x90], xmm9
000075aec0bd6bda  vmovaps [rsp+0xA0], xmm11
000075aec0bd6be3  vmovaps [rsp+0xB0], xmm12
000075aec0bd6bec  vmovaps [rsp+0xC0], xmm13
000075aec0bd6bf5  vmovaps [rsp+0xD0], xmm14
000075aec0bd6bfe  vmovaps [rsp+0xE0], xmm15
000075aec0bd6c07  sub rsp, 0x30
000075aec0bd6c0b  movaps [rsp], xmm10
000075aec0bd6c10  movaps [rsp+0x10], xmm12
000075aec0bd6c16  movaps [rsp+0x20], xmm11
000075aec0bd6c1c  lea rdi, [rsp]
000075aec0bd6c20  mov esi, 0x00
000075aec0bd6c25  mov rax, 0x57F4B31E6530
000075aec0bd6c2f  call rax
000075aec0bd6c31  movaps xmm10, [rsp]
000075aec0bd6c36  add rsp, 0x30
000075aec0bd6c3a  vmovaps xmm0, [rsp]
000075aec0bd6c3f  vmovaps xmm1, [rsp+0x10]
000075aec0bd6c45  vmovaps xmm2, [rsp+0x20]
000075aec0bd6c4b  vmovaps xmm3, [rsp+0x30]
000075aec0bd6c51  vmovaps xmm4, [rsp+0x40]
000075aec0bd6c57  vmovaps xmm5, [rsp+0x50]
000075aec0bd6c5d  vmovaps xmm6, [rsp+0x60]
000075aec0bd6c63  vmovaps xmm7, [rsp+0x70]
000075aec0bd6c69  vmovaps xmm8, [rsp+0x80]
000075aec0bd6c72  vmovaps xmm9, [rsp+0x90]
000075aec0bd6c7b  vmovaps xmm11, [rsp+0xA0]
000075aec0bd6c84  vmovaps xmm12, [rsp+0xB0]
000075aec0bd6c8d  vmovaps xmm13, [rsp+0xC0]
000075aec0bd6c96  vmovaps xmm14, [rsp+0xD0]
000075aec0bd6c9f  vmovaps xmm15, [rsp+0xE0]
000075aec0bd6ca8  add rsp, 0xF0
000075aec0bd6caf  pop r11
000075aec0bd6cb1  pop r10
000075aec0bd6cb3  pop r9
000075aec0bd6cb5  pop r8
000075aec0bd6cb7  pop rsi
000075aec0bd6cb8  pop rdi
000075aec0bd6cb9  pop rdx
000075aec0bd6cba  pop rcx
000075aec0bd6cbb  pop rax
000075aec0bd6cbc  add rsp, 0x08
000075aec0bd6cc0  jmp 0x000075AEC0BD5A06
000075aec0bd6cc5  sub rsp, 0x08
000075aec0bd6cc9  push rax
000075aec0bd6cca  push rcx
000075aec0bd6ccb  push rdx
000075aec0bd6ccc  push rdi
000075aec0bd6ccd  push rsi
000075aec0bd6cce  push r8
000075aec0bd6cd0  push r9
000075aec0bd6cd2  push r10
000075aec0bd6cd4  push r11
000075aec0bd6cd6  sub rsp, 0xF0
000075aec0bd6cdd  vmovaps [rsp], xmm0
000075aec0bd6ce2  vmovaps [rsp+0x10], xmm1
000075aec0bd6ce8  vmovaps [rsp+0x20], xmm2
000075aec0bd6cee  vmovaps [rsp+0x30], xmm3
000075aec0bd6cf4  vmovaps [rsp+0x40], xmm4
000075aec0bd6cfa  vmovaps [rsp+0x50], xmm5
000075aec0bd6d00  vmovaps [rsp+0x60], xmm7
000075aec0bd6d06  vmovaps [rsp+0x70], xmm8
000075aec0bd6d0c  vmovaps [rsp+0x80], xmm9
000075aec0bd6d15  vmovaps [rsp+0x90], xmm10
000075aec0bd6d1e  vmovaps [rsp+0xA0], xmm11
000075aec0bd6d27  vmovaps [rsp+0xB0], xmm12
000075aec0bd6d30  vmovaps [rsp+0xC0], xmm13
000075aec0bd6d39  vmovaps [rsp+0xD0], xmm14
000075aec0bd6d42  vmovaps [rsp+0xE0], xmm15
000075aec0bd6d4b  sub rsp, 0x30
000075aec0bd6d4f  movaps [rsp], xmm6
000075aec0bd6d53  movaps [rsp+0x10], xmm12
000075aec0bd6d59  movaps [rsp+0x20], xmm11
000075aec0bd6d5f  lea rdi, [rsp]
000075aec0bd6d63  mov esi, 0x00
000075aec0bd6d68  mov rax, 0x57F4B31E6530
000075aec0bd6d72  call rax
000075aec0bd6d74  movaps xmm6, [rsp]
000075aec0bd6d78  add rsp, 0x30
000075aec0bd6d7c  vmovaps xmm0, [rsp]
000075aec0bd6d81  vmovaps xmm1, [rsp+0x10]
000075aec0bd6d87  vmovaps xmm2, [rsp+0x20]
000075aec0bd6d8d  vmovaps xmm3, [rsp+0x30]
000075aec0bd6d93  vmovaps xmm4, [rsp+0x40]
000075aec0bd6d99  vmovaps xmm5, [rsp+0x50]
000075aec0bd6d9f  vmovaps xmm7, [rsp+0x60]
000075aec0bd6da5  vmovaps xmm8, [rsp+0x70]
000075aec0bd6dab  vmovaps xmm9, [rsp+0x80]
000075aec0bd6db4  vmovaps xmm10, [rsp+0x90]
000075aec0bd6dbd  vmovaps xmm11, [rsp+0xA0]
000075aec0bd6dc6  vmovaps xmm12, [rsp+0xB0]
000075aec0bd6dcf  vmovaps xmm13, [rsp+0xC0]
000075aec0bd6dd8  vmovaps xmm14, [rsp+0xD0]
000075aec0bd6de1  vmovaps xmm15, [rsp+0xE0]
000075aec0bd6dea  add rsp, 0xF0
000075aec0bd6df1  pop r11
000075aec0bd6df3  pop r10
000075aec0bd6df5  pop r9
000075aec0bd6df7  pop r8
000075aec0bd6df9  pop rsi
000075aec0bd6dfa  pop rdi
000075aec0bd6dfb  pop rdx
000075aec0bd6dfc  pop rcx
000075aec0bd6dfd  pop rax
000075aec0bd6dfe  add rsp, 0x08
000075aec0bd6e02  jmp 0x000075AEC0BD5A27
000075aec0bd6e07  sub rsp, 0x08
000075aec0bd6e0b  push rax
000075aec0bd6e0c  push rcx
000075aec0bd6e0d  push rdx
000075aec0bd6e0e  push rdi
000075aec0bd6e0f  push rsi
000075aec0bd6e10  push r8
000075aec0bd6e12  push r9
000075aec0bd6e14  push r10
000075aec0bd6e16  push r11
000075aec0bd6e18  sub rsp, 0xF0
000075aec0bd6e1f  vmovaps [rsp], xmm0
000075aec0bd6e24  vmovaps [rsp+0x10], xmm1
000075aec0bd6e2a  vmovaps [rsp+0x20], xmm2
000075aec0bd6e30  vmovaps [rsp+0x30], xmm4
000075aec0bd6e36  vmovaps [rsp+0x40], xmm5
000075aec0bd6e3c  vmovaps [rsp+0x50], xmm6
000075aec0bd6e42  vmovaps [rsp+0x60], xmm7
000075aec0bd6e48  vmovaps [rsp+0x70], xmm8
000075aec0bd6e4e  vmovaps [rsp+0x80], xmm9
000075aec0bd6e57  vmovaps [rsp+0x90], xmm10
000075aec0bd6e60  vmovaps [rsp+0xA0], xmm11
000075aec0bd6e69  vmovaps [rsp+0xB0], xmm12
000075aec0bd6e72  vmovaps [rsp+0xC0], xmm13
000075aec0bd6e7b  vmovaps [rsp+0xD0], xmm14
000075aec0bd6e84  vmovaps [rsp+0xE0], xmm15
000075aec0bd6e8d  sub rsp, 0x30
000075aec0bd6e91  movaps [rsp], xmm3
000075aec0bd6e95  movaps [rsp+0x10], xmm5
000075aec0bd6e9a  movaps [rsp+0x20], xmm4
000075aec0bd6e9f  lea rdi, [rsp]
000075aec0bd6ea3  mov esi, 0x00
000075aec0bd6ea8  mov rax, 0x57F4B31E6530
000075aec0bd6eb2  call rax
000075aec0bd6eb4  movaps xmm3, [rsp]
000075aec0bd6eb8  add rsp, 0x30
000075aec0bd6ebc  vmovaps xmm0, [rsp]
000075aec0bd6ec1  vmovaps xmm1, [rsp+0x10]
000075aec0bd6ec7  vmovaps xmm2, [rsp+0x20]
000075aec0bd6ecd  vmovaps xmm4, [rsp+0x30]
000075aec0bd6ed3  vmovaps xmm5, [rsp+0x40]
000075aec0bd6ed9  vmovaps xmm6, [rsp+0x50]
000075aec0bd6edf  vmovaps xmm7, [rsp+0x60]
000075aec0bd6ee5  vmovaps xmm8, [rsp+0x70]
000075aec0bd6eeb  vmovaps xmm9, [rsp+0x80]
000075aec0bd6ef4  vmovaps xmm10, [rsp+0x90]
000075aec0bd6efd  vmovaps xmm11, [rsp+0xA0]
000075aec0bd6f06  vmovaps xmm12, [rsp+0xB0]
000075aec0bd6f0f  vmovaps xmm13, [rsp+0xC0]
000075aec0bd6f18  vmovaps xmm14, [rsp+0xD0]
000075aec0bd6f21  vmovaps xmm15, [rsp+0xE0]
000075aec0bd6f2a  add rsp, 0xF0
000075aec0bd6f31  pop r11
000075aec0bd6f33  pop r10
000075aec0bd6f35  pop r9
000075aec0bd6f37  pop r8
000075aec0bd6f39  pop rsi
000075aec0bd6f3a  pop rdi
000075aec0bd6f3b  pop rdx
000075aec0bd6f3c  pop rcx
000075aec0bd6f3d  pop rax
000075aec0bd6f3e  add rsp, 0x08
000075aec0bd6f42  jmp 0x000075AEC0BD5A88
000075aec0bd6f47  sub rsp, 0x08
000075aec0bd6f4b  push rax
000075aec0bd6f4c  push rcx
000075aec0bd6f4d  push rdx
000075aec0bd6f4e  push rdi
000075aec0bd6f4f  push rsi
000075aec0bd6f50  push r8
000075aec0bd6f52  push r9
000075aec0bd6f54  push r10
000075aec0bd6f56  push r11
000075aec0bd6f58  sub rsp, 0xF0
000075aec0bd6f5f  vmovaps [rsp], xmm0
000075aec0bd6f64  vmovaps [rsp+0x10], xmm1
000075aec0bd6f6a  vmovaps [rsp+0x20], xmm2
000075aec0bd6f70  vmovaps [rsp+0x30], xmm3
000075aec0bd6f76  vmovaps [rsp+0x40], xmm4
000075aec0bd6f7c  vmovaps [rsp+0x50], xmm6
000075aec0bd6f82  vmovaps [rsp+0x60], xmm7
000075aec0bd6f88  vmovaps [rsp+0x70], xmm8
000075aec0bd6f8e  vmovaps [rsp+0x80], xmm9
000075aec0bd6f97  vmovaps [rsp+0x90], xmm10
000075aec0bd6fa0  vmovaps [rsp+0xA0], xmm11
000075aec0bd6fa9  vmovaps [rsp+0xB0], xmm12
000075aec0bd6fb2  vmovaps [rsp+0xC0], xmm13
000075aec0bd6fbb  vmovaps [rsp+0xD0], xmm14
000075aec0bd6fc4  vmovaps [rsp+0xE0], xmm15
000075aec0bd6fcd  sub rsp, 0x30
000075aec0bd6fd1  movaps [rsp], xmm5
000075aec0bd6fd5  movaps [rsp+0x10], xmm8
000075aec0bd6fdb  movaps [rsp+0x20], xmm15
000075aec0bd6fe1  lea rdi, [rsp]
000075aec0bd6fe5  mov esi, 0x00
000075aec0bd6fea  mov rax, 0x57F4B31E6530
000075aec0bd6ff4  call rax
000075aec0bd6ff6  movaps xmm5, [rsp]
000075aec0bd6ffa  add rsp, 0x30
000075aec0bd6ffe  vmovaps xmm0, [rsp]
000075aec0bd7003  vmovaps xmm1, [rsp+0x10]
000075aec0bd7009  vmovaps xmm2, [rsp+0x20]
000075aec0bd700f  vmovaps xmm3, [rsp+0x30]
000075aec0bd7015  vmovaps xmm4, [rsp+0x40]
000075aec0bd701b  vmovaps xmm6, [rsp+0x50]
000075aec0bd7021  vmovaps xmm7, [rsp+0x60]
000075aec0bd7027  vmovaps xmm8, [rsp+0x70]
000075aec0bd702d  vmovaps xmm9, [rsp+0x80]
000075aec0bd7036  vmovaps xmm10, [rsp+0x90]
000075aec0bd703f  vmovaps xmm11, [rsp+0xA0]
000075aec0bd7048  vmovaps xmm12, [rsp+0xB0]
000075aec0bd7051  vmovaps xmm13, [rsp+0xC0]
000075aec0bd705a  vmovaps xmm14, [rsp+0xD0]
000075aec0bd7063  vmovaps xmm15, [rsp+0xE0]
000075aec0bd706c  add rsp, 0xF0
000075aec0bd7073  pop r11
000075aec0bd7075  pop r10
000075aec0bd7077  pop r9
000075aec0bd7079  pop r8
000075aec0bd707b  pop rsi
000075aec0bd707c  pop rdi
000075aec0bd707d  pop rdx
000075aec0bd707e  pop rcx
000075aec0bd707f  pop rax
000075aec0bd7080  add rsp, 0x08
000075aec0bd7084  jmp 0x000075AEC0BD5AC0
000075aec0bd7089  sub rsp, 0x08
000075aec0bd708d  push rax
000075aec0bd708e  push rcx
000075aec0bd708f  push rdx
000075aec0bd7090  push rdi
000075aec0bd7091  push rsi
000075aec0bd7092  push r8
000075aec0bd7094  push r9
000075aec0bd7096  push r10
000075aec0bd7098  push r11
000075aec0bd709a  sub rsp, 0xF0
000075aec0bd70a1  vmovaps [rsp], xmm0
000075aec0bd70a6  vmovaps [rsp+0x10], xmm1
000075aec0bd70ac  vmovaps [rsp+0x20], xmm2
000075aec0bd70b2  vmovaps [rsp+0x30], xmm3
000075aec0bd70b8  vmovaps [rsp+0x40], xmm5
000075aec0bd70be  vmovaps [rsp+0x50], xmm6
000075aec0bd70c4  vmovaps [rsp+0x60], xmm7
000075aec0bd70ca  vmovaps [rsp+0x70], xmm8
000075aec0bd70d0  vmovaps [rsp+0x80], xmm9
000075aec0bd70d9  vmovaps [rsp+0x90], xmm10
000075aec0bd70e2  vmovaps [rsp+0xA0], xmm11
000075aec0bd70eb  vmovaps [rsp+0xB0], xmm12
000075aec0bd70f4  vmovaps [rsp+0xC0], xmm13
000075aec0bd70fd  vmovaps [rsp+0xD0], xmm14
000075aec0bd7106  vmovaps [rsp+0xE0], xmm15
000075aec0bd710f  sub rsp, 0x30
000075aec0bd7113  movaps [rsp], xmm4
000075aec0bd7117  movaps [rsp+0x10], xmm9
000075aec0bd711d  movaps [rsp+0x20], xmm8
000075aec0bd7123  lea rdi, [rsp]
000075aec0bd7127  mov esi, 0x00
000075aec0bd712c  mov rax, 0x57F4B31E6530
000075aec0bd7136  call rax
000075aec0bd7138  movaps xmm4, [rsp]
000075aec0bd713c  add rsp, 0x30
000075aec0bd7140  vmovaps xmm0, [rsp]
000075aec0bd7145  vmovaps xmm1, [rsp+0x10]
000075aec0bd714b  vmovaps xmm2, [rsp+0x20]
000075aec0bd7151  vmovaps xmm3, [rsp+0x30]
000075aec0bd7157  vmovaps xmm5, [rsp+0x40]
000075aec0bd715d  vmovaps xmm6, [rsp+0x50]
000075aec0bd7163  vmovaps xmm7, [rsp+0x60]
000075aec0bd7169  vmovaps xmm8, [rsp+0x70]
000075aec0bd716f  vmovaps xmm9, [rsp+0x80]
000075aec0bd7178  vmovaps xmm10, [rsp+0x90]
000075aec0bd7181  vmovaps xmm11, [rsp+0xA0]
000075aec0bd718a  vmovaps xmm12, [rsp+0xB0]
000075aec0bd7193  vmovaps xmm13, [rsp+0xC0]
000075aec0bd719c  vmovaps xmm14, [rsp+0xD0]
000075aec0bd71a5  vmovaps xmm15, [rsp+0xE0]
000075aec0bd71ae  add rsp, 0xF0
000075aec0bd71b5  pop r11
000075aec0bd71b7  pop r10
000075aec0bd71b9  pop r9
000075aec0bd71bb  pop r8
000075aec0bd71bd  pop rsi
000075aec0bd71be  pop rdi
000075aec0bd71bf  pop rdx
000075aec0bd71c0  pop rcx
000075aec0bd71c1  pop rax
000075aec0bd71c2  add rsp, 0x08
000075aec0bd71c6  jmp 0x000075AEC0BD5AE1
000075aec0bd71cb  sub rsp, 0x08
000075aec0bd71cf  push rax
000075aec0bd71d0  push rcx
000075aec0bd71d1  push rdx
000075aec0bd71d2  push rdi
000075aec0bd71d3  push rsi
000075aec0bd71d4  push r8
000075aec0bd71d6  push r9
000075aec0bd71d8  push r10
000075aec0bd71da  push r11
000075aec0bd71dc  sub rsp, 0xF0
000075aec0bd71e3  vmovaps [rsp], xmm0
000075aec0bd71e8  vmovaps [rsp+0x10], xmm1
000075aec0bd71ee  vmovaps [rsp+0x20], xmm2
000075aec0bd71f4  vmovaps [rsp+0x30], xmm3
000075aec0bd71fa  vmovaps [rsp+0x40], xmm4
000075aec0bd7200  vmovaps [rsp+0x50], xmm5
000075aec0bd7206  vmovaps [rsp+0x60], xmm6
000075aec0bd720c  vmovaps [rsp+0x70], xmm7
000075aec0bd7212  vmovaps [rsp+0x80], xmm8
000075aec0bd721b  vmovaps [rsp+0x90], xmm10
000075aec0bd7224  vmovaps [rsp+0xA0], xmm11
000075aec0bd722d  vmovaps [rsp+0xB0], xmm12
000075aec0bd7236  vmovaps [rsp+0xC0], xmm13
000075aec0bd723f  vmovaps [rsp+0xD0], xmm14
000075aec0bd7248  vmovaps [rsp+0xE0], xmm15
000075aec0bd7251  sub rsp, 0x30
000075aec0bd7255  movaps [rsp], xmm9
000075aec0bd725a  movaps [rsp+0x10], xmm10
000075aec0bd7260  movaps [rsp+0x20], xmm8
000075aec0bd7266  lea rdi, [rsp]
000075aec0bd726a  mov esi, 0x00
000075aec0bd726f  mov rax, 0x57F4B31E6530
000075aec0bd7279  call rax
000075aec0bd727b  movaps xmm9, [rsp]
000075aec0bd7280  add rsp, 0x30
000075aec0bd7284  vmovaps xmm0, [rsp]
000075aec0bd7289  vmovaps xmm1, [rsp+0x10]
000075aec0bd728f  vmovaps xmm2, [rsp+0x20]
000075aec0bd7295  vmovaps xmm3, [rsp+0x30]
000075aec0bd729b  vmovaps xmm4, [rsp+0x40]
000075aec0bd72a1  vmovaps xmm5, [rsp+0x50]
000075aec0bd72a7  vmovaps xmm6, [rsp+0x60]
000075aec0bd72ad  vmovaps xmm7, [rsp+0x70]
000075aec0bd72b3  vmovaps xmm8, [rsp+0x80]
000075aec0bd72bc  vmovaps xmm10, [rsp+0x90]
000075aec0bd72c5  vmovaps xmm11, [rsp+0xA0]
000075aec0bd72ce  vmovaps xmm12, [rsp+0xB0]
000075aec0bd72d7  vmovaps xmm13, [rsp+0xC0]
000075aec0bd72e0  vmovaps xmm14, [rsp+0xD0]
000075aec0bd72e9  vmovaps xmm15, [rsp+0xE0]
000075aec0bd72f2  add rsp, 0xF0
000075aec0bd72f9  pop r11
000075aec0bd72fb  pop r10
000075aec0bd72fd  pop r9
000075aec0bd72ff  pop r8
000075aec0bd7301  pop rsi
000075aec0bd7302  pop rdi
000075aec0bd7303  pop rdx
000075aec0bd7304  pop rcx
000075aec0bd7305  pop rax
000075aec0bd7306  add rsp, 0x08
000075aec0bd730a  jmp 0x000075AEC0BD5AFB
000075aec0bd730f  call 0x000075AEC0AD64F0
000075aec0bd7314  jmp 0x000075AEC0BD5C15
000075aec0bd7319  call 0x000075AEC0AD64F0
000075aec0bd731e  jmp 0x000075AEC0BD5C2B
000075aec0bd7323  sub rsp, 0x08
000075aec0bd7327  push rax
000075aec0bd7328  push rcx
000075aec0bd7329  push rdx
000075aec0bd732a  push rdi
000075aec0bd732b  push rsi
000075aec0bd732c  push r8
000075aec0bd732e  push r9
000075aec0bd7330  push r10
000075aec0bd7332  push r11
000075aec0bd7334  sub rsp, 0xF0
000075aec0bd733b  vmovaps [rsp], xmm0
000075aec0bd7340  vmovaps [rsp+0x10], xmm2
000075aec0bd7346  vmovaps [rsp+0x20], xmm3
000075aec0bd734c  vmovaps [rsp+0x30], xmm4
000075aec0bd7352  vmovaps [rsp+0x40], xmm5
000075aec0bd7358  vmovaps [rsp+0x50], xmm6
000075aec0bd735e  vmovaps [rsp+0x60], xmm7
000075aec0bd7364  vmovaps [rsp+0x70], xmm8
000075aec0bd736a  vmovaps [rsp+0x80], xmm9
000075aec0bd7373  vmovaps [rsp+0x90], xmm10
000075aec0bd737c  vmovaps [rsp+0xA0], xmm11
000075aec0bd7385  vmovaps [rsp+0xB0], xmm12
000075aec0bd738e  vmovaps [rsp+0xC0], xmm13
000075aec0bd7397  vmovaps [rsp+0xD0], xmm14
000075aec0bd73a0  vmovaps [rsp+0xE0], xmm15
000075aec0bd73a9  sub rsp, 0x30
000075aec0bd73ad  movaps [rsp], xmm1
000075aec0bd73b1  movaps [rsp+0x10], xmm6
000075aec0bd73b6  movaps [rsp+0x20], xmm15
000075aec0bd73bc  lea rdi, [rsp]
000075aec0bd73c0  mov esi, 0x00
000075aec0bd73c5  mov rax, 0x57F4B31E6530
000075aec0bd73cf  call rax
000075aec0bd73d1  movaps xmm1, [rsp]
000075aec0bd73d5  add rsp, 0x30
000075aec0bd73d9  vmovaps xmm0, [rsp]
000075aec0bd73de  vmovaps xmm2, [rsp+0x10]
000075aec0bd73e4  vmovaps xmm3, [rsp+0x20]
000075aec0bd73ea  vmovaps xmm4, [rsp+0x30]
000075aec0bd73f0  vmovaps xmm5, [rsp+0x40]
000075aec0bd73f6  vmovaps xmm6, [rsp+0x50]
000075aec0bd73fc  vmovaps xmm7, [rsp+0x60]
000075aec0bd7402  vmovaps xmm8, [rsp+0x70]
000075aec0bd7408  vmovaps xmm9, [rsp+0x80]
000075aec0bd7411  vmovaps xmm10, [rsp+0x90]
000075aec0bd741a  vmovaps xmm11, [rsp+0xA0]
000075aec0bd7423  vmovaps xmm12, [rsp+0xB0]
000075aec0bd742c  vmovaps xmm13, [rsp+0xC0]
000075aec0bd7435  vmovaps xmm14, [rsp+0xD0]
000075aec0bd743e  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7447  add rsp, 0xF0
000075aec0bd744e  pop r11
000075aec0bd7450  pop r10
000075aec0bd7452  pop r9
000075aec0bd7454  pop r8
000075aec0bd7456  pop rsi
000075aec0bd7457  pop rdi
000075aec0bd7458  pop rdx
000075aec0bd7459  pop rcx
000075aec0bd745a  pop rax
000075aec0bd745b  add rsp, 0x08
000075aec0bd745f  jmp 0x000075AEC0BD5C68
000075aec0bd7464  call 0x000075AEC0AE5820
000075aec0bd7469  jmp 0x000075AEC0BD5C75
000075aec0bd746e  sub rsp, 0x08
000075aec0bd7472  push rax
000075aec0bd7473  push rcx
000075aec0bd7474  push rdx
000075aec0bd7475  push rdi
000075aec0bd7476  push rsi
000075aec0bd7477  push r8
000075aec0bd7479  push r9
000075aec0bd747b  push r10
000075aec0bd747d  push r11
000075aec0bd747f  sub rsp, 0xF0
000075aec0bd7486  vmovaps [rsp], xmm0
000075aec0bd748b  vmovaps [rsp+0x10], xmm1
000075aec0bd7491  vmovaps [rsp+0x20], xmm2
000075aec0bd7497  vmovaps [rsp+0x30], xmm3
000075aec0bd749d  vmovaps [rsp+0x40], xmm4
000075aec0bd74a3  vmovaps [rsp+0x50], xmm5
000075aec0bd74a9  vmovaps [rsp+0x60], xmm6
000075aec0bd74af  vmovaps [rsp+0x70], xmm7
000075aec0bd74b5  vmovaps [rsp+0x80], xmm8
000075aec0bd74be  vmovaps [rsp+0x90], xmm9
000075aec0bd74c7  vmovaps [rsp+0xA0], xmm10
000075aec0bd74d0  vmovaps [rsp+0xB0], xmm11
000075aec0bd74d9  vmovaps [rsp+0xC0], xmm12
000075aec0bd74e2  vmovaps [rsp+0xD0], xmm13
000075aec0bd74eb  vmovaps [rsp+0xE0], xmm15
000075aec0bd74f4  sub rsp, 0x30
000075aec0bd74f8  movaps [rsp], xmm14
000075aec0bd74fd  movaps [rsp+0x10], xmm4
000075aec0bd7502  movaps [rsp+0x20], xmm3
000075aec0bd7507  lea rdi, [rsp]
000075aec0bd750b  mov esi, 0x00
000075aec0bd7510  mov rax, 0x57F4B31E6530
000075aec0bd751a  call rax
000075aec0bd751c  movaps xmm14, [rsp]
000075aec0bd7521  add rsp, 0x30
000075aec0bd7525  vmovaps xmm0, [rsp]
000075aec0bd752a  vmovaps xmm1, [rsp+0x10]
000075aec0bd7530  vmovaps xmm2, [rsp+0x20]
000075aec0bd7536  vmovaps xmm3, [rsp+0x30]
000075aec0bd753c  vmovaps xmm4, [rsp+0x40]
000075aec0bd7542  vmovaps xmm5, [rsp+0x50]
000075aec0bd7548  vmovaps xmm6, [rsp+0x60]
000075aec0bd754e  vmovaps xmm7, [rsp+0x70]
000075aec0bd7554  vmovaps xmm8, [rsp+0x80]
000075aec0bd755d  vmovaps xmm9, [rsp+0x90]
000075aec0bd7566  vmovaps xmm10, [rsp+0xA0]
000075aec0bd756f  vmovaps xmm11, [rsp+0xB0]
000075aec0bd7578  vmovaps xmm12, [rsp+0xC0]
000075aec0bd7581  vmovaps xmm13, [rsp+0xD0]
000075aec0bd758a  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7593  add rsp, 0xF0
000075aec0bd759a  pop r11
000075aec0bd759c  pop r10
000075aec0bd759e  pop r9
000075aec0bd75a0  pop r8
000075aec0bd75a2  pop rsi
000075aec0bd75a3  pop rdi
000075aec0bd75a4  pop rdx
000075aec0bd75a5  pop rcx
000075aec0bd75a6  pop rax
000075aec0bd75a7  add rsp, 0x08
000075aec0bd75ab  jmp 0x000075AEC0BD5C8F
000075aec0bd75b0  sub rsp, 0x08
000075aec0bd75b4  push rax
000075aec0bd75b5  push rcx
000075aec0bd75b6  push rdx
000075aec0bd75b7  push rdi
000075aec0bd75b8  push rsi
000075aec0bd75b9  push r8
000075aec0bd75bb  push r9
000075aec0bd75bd  push r10
000075aec0bd75bf  push r11
000075aec0bd75c1  sub rsp, 0xF0
000075aec0bd75c8  vmovaps [rsp], xmm0
000075aec0bd75cd  vmovaps [rsp+0x10], xmm1
000075aec0bd75d3  vmovaps [rsp+0x20], xmm2
000075aec0bd75d9  vmovaps [rsp+0x30], xmm3
000075aec0bd75df  vmovaps [rsp+0x40], xmm4
000075aec0bd75e5  vmovaps [rsp+0x50], xmm5
000075aec0bd75eb  vmovaps [rsp+0x60], xmm7
000075aec0bd75f1  vmovaps [rsp+0x70], xmm8
000075aec0bd75f7  vmovaps [rsp+0x80], xmm9
000075aec0bd7600  vmovaps [rsp+0x90], xmm10
000075aec0bd7609  vmovaps [rsp+0xA0], xmm11
000075aec0bd7612  vmovaps [rsp+0xB0], xmm12
000075aec0bd761b  vmovaps [rsp+0xC0], xmm13
000075aec0bd7624  vmovaps [rsp+0xD0], xmm14
000075aec0bd762d  vmovaps [rsp+0xE0], xmm15
000075aec0bd7636  sub rsp, 0x30
000075aec0bd763a  movaps [rsp], xmm6
000075aec0bd763e  movaps [rsp+0x10], xmm9
000075aec0bd7644  movaps [rsp+0x20], xmm7
000075aec0bd7649  lea rdi, [rsp]
000075aec0bd764d  mov esi, 0x00
000075aec0bd7652  mov rax, 0x57F4B31E6530
000075aec0bd765c  call rax
000075aec0bd765e  movaps xmm6, [rsp]
000075aec0bd7662  add rsp, 0x30
000075aec0bd7666  vmovaps xmm0, [rsp]
000075aec0bd766b  vmovaps xmm1, [rsp+0x10]
000075aec0bd7671  vmovaps xmm2, [rsp+0x20]
000075aec0bd7677  vmovaps xmm3, [rsp+0x30]
000075aec0bd767d  vmovaps xmm4, [rsp+0x40]
000075aec0bd7683  vmovaps xmm5, [rsp+0x50]
000075aec0bd7689  vmovaps xmm7, [rsp+0x60]
000075aec0bd768f  vmovaps xmm8, [rsp+0x70]
000075aec0bd7695  vmovaps xmm9, [rsp+0x80]
000075aec0bd769e  vmovaps xmm10, [rsp+0x90]
000075aec0bd76a7  vmovaps xmm11, [rsp+0xA0]
000075aec0bd76b0  vmovaps xmm12, [rsp+0xB0]
000075aec0bd76b9  vmovaps xmm13, [rsp+0xC0]
000075aec0bd76c2  vmovaps xmm14, [rsp+0xD0]
000075aec0bd76cb  vmovaps xmm15, [rsp+0xE0]
000075aec0bd76d4  add rsp, 0xF0
000075aec0bd76db  pop r11
000075aec0bd76dd  pop r10
000075aec0bd76df  pop r9
000075aec0bd76e1  pop r8
000075aec0bd76e3  pop rsi
000075aec0bd76e4  pop rdi
000075aec0bd76e5  pop rdx
000075aec0bd76e6  pop rcx
000075aec0bd76e7  pop rax
000075aec0bd76e8  add rsp, 0x08
000075aec0bd76ec  jmp 0x000075AEC0BD5CA7
000075aec0bd76f1  sub rsp, 0x08
000075aec0bd76f5  push rax
000075aec0bd76f6  push rcx
000075aec0bd76f7  push rdx
000075aec0bd76f8  push rdi
000075aec0bd76f9  push rsi
000075aec0bd76fa  push r8
000075aec0bd76fc  push r9
000075aec0bd76fe  push r10
000075aec0bd7700  push r11
000075aec0bd7702  sub rsp, 0xF0
000075aec0bd7709  vmovaps [rsp], xmm0
000075aec0bd770e  vmovaps [rsp+0x10], xmm1
000075aec0bd7714  vmovaps [rsp+0x20], xmm2
000075aec0bd771a  vmovaps [rsp+0x30], xmm3
000075aec0bd7720  vmovaps [rsp+0x40], xmm4
000075aec0bd7726  vmovaps [rsp+0x50], xmm5
000075aec0bd772c  vmovaps [rsp+0x60], xmm6
000075aec0bd7732  vmovaps [rsp+0x70], xmm8
000075aec0bd7738  vmovaps [rsp+0x80], xmm9
000075aec0bd7741  vmovaps [rsp+0x90], xmm10
000075aec0bd774a  vmovaps [rsp+0xA0], xmm11
000075aec0bd7753  vmovaps [rsp+0xB0], xmm12
000075aec0bd775c  vmovaps [rsp+0xC0], xmm13
000075aec0bd7765  vmovaps [rsp+0xD0], xmm14
000075aec0bd776e  vmovaps [rsp+0xE0], xmm15
000075aec0bd7777  sub rsp, 0x30
000075aec0bd777b  movaps [rsp], xmm7
000075aec0bd777f  movaps [rsp+0x10], xmm4
000075aec0bd7784  movaps [rsp+0x20], xmm9
000075aec0bd778a  lea rdi, [rsp]
000075aec0bd778e  mov esi, 0x00
000075aec0bd7793  mov rax, 0x57F4B31E6530
000075aec0bd779d  call rax
000075aec0bd779f  movaps xmm7, [rsp]
000075aec0bd77a3  add rsp, 0x30
000075aec0bd77a7  vmovaps xmm0, [rsp]
000075aec0bd77ac  vmovaps xmm1, [rsp+0x10]
000075aec0bd77b2  vmovaps xmm2, [rsp+0x20]
000075aec0bd77b8  vmovaps xmm3, [rsp+0x30]
000075aec0bd77be  vmovaps xmm4, [rsp+0x40]
000075aec0bd77c4  vmovaps xmm5, [rsp+0x50]
000075aec0bd77ca  vmovaps xmm6, [rsp+0x60]
000075aec0bd77d0  vmovaps xmm8, [rsp+0x70]
000075aec0bd77d6  vmovaps xmm9, [rsp+0x80]
000075aec0bd77df  vmovaps xmm10, [rsp+0x90]
000075aec0bd77e8  vmovaps xmm11, [rsp+0xA0]
000075aec0bd77f1  vmovaps xmm12, [rsp+0xB0]
000075aec0bd77fa  vmovaps xmm13, [rsp+0xC0]
000075aec0bd7803  vmovaps xmm14, [rsp+0xD0]
000075aec0bd780c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7815  add rsp, 0xF0
000075aec0bd781c  pop r11
000075aec0bd781e  pop r10
000075aec0bd7820  pop r9
000075aec0bd7822  pop r8
000075aec0bd7824  pop rsi
000075aec0bd7825  pop rdi
000075aec0bd7826  pop rdx
000075aec0bd7827  pop rcx
000075aec0bd7828  pop rax
000075aec0bd7829  add rsp, 0x08
000075aec0bd782d  jmp 0x000075AEC0BD5CD4
000075aec0bd7832  sub rsp, 0x08
000075aec0bd7836  push rax
000075aec0bd7837  push rcx
000075aec0bd7838  push rdx
000075aec0bd7839  push rdi
000075aec0bd783a  push rsi
000075aec0bd783b  push r8
000075aec0bd783d  push r9
000075aec0bd783f  push r10
000075aec0bd7841  push r11
000075aec0bd7843  sub rsp, 0xF0
000075aec0bd784a  vmovaps [rsp], xmm0
000075aec0bd784f  vmovaps [rsp+0x10], xmm1
000075aec0bd7855  vmovaps [rsp+0x20], xmm2
000075aec0bd785b  vmovaps [rsp+0x30], xmm3
000075aec0bd7861  vmovaps [rsp+0x40], xmm5
000075aec0bd7867  vmovaps [rsp+0x50], xmm6
000075aec0bd786d  vmovaps [rsp+0x60], xmm7
000075aec0bd7873  vmovaps [rsp+0x70], xmm8
000075aec0bd7879  vmovaps [rsp+0x80], xmm9
000075aec0bd7882  vmovaps [rsp+0x90], xmm10
000075aec0bd788b  vmovaps [rsp+0xA0], xmm11
000075aec0bd7894  vmovaps [rsp+0xB0], xmm12
000075aec0bd789d  vmovaps [rsp+0xC0], xmm13
000075aec0bd78a6  vmovaps [rsp+0xD0], xmm14
000075aec0bd78af  vmovaps [rsp+0xE0], xmm15
000075aec0bd78b8  sub rsp, 0x30
000075aec0bd78bc  movaps [rsp], xmm4
000075aec0bd78c0  movaps [rsp+0x10], xmm15
000075aec0bd78c6  movaps [rsp+0x20], xmm9
000075aec0bd78cc  lea rdi, [rsp]
000075aec0bd78d0  mov esi, 0x00
000075aec0bd78d5  mov rax, 0x57F4B31E6530
000075aec0bd78df  call rax
000075aec0bd78e1  movaps xmm4, [rsp]
000075aec0bd78e5  add rsp, 0x30
000075aec0bd78e9  vmovaps xmm0, [rsp]
000075aec0bd78ee  vmovaps xmm1, [rsp+0x10]
000075aec0bd78f4  vmovaps xmm2, [rsp+0x20]
000075aec0bd78fa  vmovaps xmm3, [rsp+0x30]
000075aec0bd7900  vmovaps xmm5, [rsp+0x40]
000075aec0bd7906  vmovaps xmm6, [rsp+0x50]
000075aec0bd790c  vmovaps xmm7, [rsp+0x60]
000075aec0bd7912  vmovaps xmm8, [rsp+0x70]
000075aec0bd7918  vmovaps xmm9, [rsp+0x80]
000075aec0bd7921  vmovaps xmm10, [rsp+0x90]
000075aec0bd792a  vmovaps xmm11, [rsp+0xA0]
000075aec0bd7933  vmovaps xmm12, [rsp+0xB0]
000075aec0bd793c  vmovaps xmm13, [rsp+0xC0]
000075aec0bd7945  vmovaps xmm14, [rsp+0xD0]
000075aec0bd794e  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7957  add rsp, 0xF0
000075aec0bd795e  pop r11
000075aec0bd7960  pop r10
000075aec0bd7962  pop r9
000075aec0bd7964  pop r8
000075aec0bd7966  pop rsi
000075aec0bd7967  pop rdi
000075aec0bd7968  pop rdx
000075aec0bd7969  pop rcx
000075aec0bd796a  pop rax
000075aec0bd796b  add rsp, 0x08
000075aec0bd796f  jmp 0x000075AEC0BD5CF9
000075aec0bd7974  call 0x000075AEC0AE5820
000075aec0bd7979  jmp 0x000075AEC0BD5D06
000075aec0bd797e  sub rsp, 0x08
000075aec0bd7982  push rax
000075aec0bd7983  push rcx
000075aec0bd7984  push rdx
000075aec0bd7985  push rdi
000075aec0bd7986  push rsi
000075aec0bd7987  push r8
000075aec0bd7989  push r9
000075aec0bd798b  push r10
000075aec0bd798d  push r11
000075aec0bd798f  sub rsp, 0xF0
000075aec0bd7996  vmovaps [rsp], xmm0
000075aec0bd799b  vmovaps [rsp+0x10], xmm1
000075aec0bd79a1  vmovaps [rsp+0x20], xmm2
000075aec0bd79a7  vmovaps [rsp+0x30], xmm4
000075aec0bd79ad  vmovaps [rsp+0x40], xmm5
000075aec0bd79b3  vmovaps [rsp+0x50], xmm6
000075aec0bd79b9  vmovaps [rsp+0x60], xmm7
000075aec0bd79bf  vmovaps [rsp+0x70], xmm8
000075aec0bd79c5  vmovaps [rsp+0x80], xmm9
000075aec0bd79ce  vmovaps [rsp+0x90], xmm10
000075aec0bd79d7  vmovaps [rsp+0xA0], xmm11
000075aec0bd79e0  vmovaps [rsp+0xB0], xmm12
000075aec0bd79e9  vmovaps [rsp+0xC0], xmm13
000075aec0bd79f2  vmovaps [rsp+0xD0], xmm14
000075aec0bd79fb  vmovaps [rsp+0xE0], xmm15
000075aec0bd7a04  sub rsp, 0x30
000075aec0bd7a08  movaps [rsp], xmm3
000075aec0bd7a0c  movaps [rsp+0x10], xmm1
000075aec0bd7a11  movaps [rsp+0x20], xmm9
000075aec0bd7a17  lea rdi, [rsp]
000075aec0bd7a1b  mov esi, 0x00
000075aec0bd7a20  mov rax, 0x57F4B31E6530
000075aec0bd7a2a  call rax
000075aec0bd7a2c  movaps xmm3, [rsp]
000075aec0bd7a30  add rsp, 0x30
000075aec0bd7a34  vmovaps xmm0, [rsp]
000075aec0bd7a39  vmovaps xmm1, [rsp+0x10]
000075aec0bd7a3f  vmovaps xmm2, [rsp+0x20]
000075aec0bd7a45  vmovaps xmm4, [rsp+0x30]
000075aec0bd7a4b  vmovaps xmm5, [rsp+0x40]
000075aec0bd7a51  vmovaps xmm6, [rsp+0x50]
000075aec0bd7a57  vmovaps xmm7, [rsp+0x60]
000075aec0bd7a5d  vmovaps xmm8, [rsp+0x70]
000075aec0bd7a63  vmovaps xmm9, [rsp+0x80]
000075aec0bd7a6c  vmovaps xmm10, [rsp+0x90]
000075aec0bd7a75  vmovaps xmm11, [rsp+0xA0]
000075aec0bd7a7e  vmovaps xmm12, [rsp+0xB0]
000075aec0bd7a87  vmovaps xmm13, [rsp+0xC0]
000075aec0bd7a90  vmovaps xmm14, [rsp+0xD0]
000075aec0bd7a99  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7aa2  add rsp, 0xF0
000075aec0bd7aa9  pop r11
000075aec0bd7aab  pop r10
000075aec0bd7aad  pop r9
000075aec0bd7aaf  pop r8
000075aec0bd7ab1  pop rsi
000075aec0bd7ab2  pop rdi
000075aec0bd7ab3  pop rdx
000075aec0bd7ab4  pop rcx
000075aec0bd7ab5  pop rax
000075aec0bd7ab6  add rsp, 0x08
000075aec0bd7aba  jmp 0x000075AEC0BD5D43
000075aec0bd7abf  sub rsp, 0x08
000075aec0bd7ac3  push rax
000075aec0bd7ac4  push rcx
000075aec0bd7ac5  push rdx
000075aec0bd7ac6  push rdi
000075aec0bd7ac7  push rsi
000075aec0bd7ac8  push r8
000075aec0bd7aca  push r9
000075aec0bd7acc  push r10
000075aec0bd7ace  push r11
000075aec0bd7ad0  sub rsp, 0xF0
000075aec0bd7ad7  vmovaps [rsp], xmm0
000075aec0bd7adc  vmovaps [rsp+0x10], xmm2
000075aec0bd7ae2  vmovaps [rsp+0x20], xmm3
000075aec0bd7ae8  vmovaps [rsp+0x30], xmm4
000075aec0bd7aee  vmovaps [rsp+0x40], xmm5
000075aec0bd7af4  vmovaps [rsp+0x50], xmm6
000075aec0bd7afa  vmovaps [rsp+0x60], xmm7
000075aec0bd7b00  vmovaps [rsp+0x70], xmm8
000075aec0bd7b06  vmovaps [rsp+0x80], xmm9
000075aec0bd7b0f  vmovaps [rsp+0x90], xmm10
000075aec0bd7b18  vmovaps [rsp+0xA0], xmm11
000075aec0bd7b21  vmovaps [rsp+0xB0], xmm12
000075aec0bd7b2a  vmovaps [rsp+0xC0], xmm13
000075aec0bd7b33  vmovaps [rsp+0xD0], xmm14
000075aec0bd7b3c  vmovaps [rsp+0xE0], xmm15
000075aec0bd7b45  sub rsp, 0x30
000075aec0bd7b49  movaps [rsp], xmm1
000075aec0bd7b4d  movaps [rsp+0x10], xmm15
000075aec0bd7b53  movaps [rsp+0x20], xmm9
000075aec0bd7b59  lea rdi, [rsp]
000075aec0bd7b5d  mov esi, 0x00
000075aec0bd7b62  mov rax, 0x57F4B31E6530
000075aec0bd7b6c  call rax
000075aec0bd7b6e  movaps xmm1, [rsp]
000075aec0bd7b72  add rsp, 0x30
000075aec0bd7b76  vmovaps xmm0, [rsp]
000075aec0bd7b7b  vmovaps xmm2, [rsp+0x10]
000075aec0bd7b81  vmovaps xmm3, [rsp+0x20]
000075aec0bd7b87  vmovaps xmm4, [rsp+0x30]
000075aec0bd7b8d  vmovaps xmm5, [rsp+0x40]
000075aec0bd7b93  vmovaps xmm6, [rsp+0x50]
000075aec0bd7b99  vmovaps xmm7, [rsp+0x60]
000075aec0bd7b9f  vmovaps xmm8, [rsp+0x70]
000075aec0bd7ba5  vmovaps xmm9, [rsp+0x80]
000075aec0bd7bae  vmovaps xmm10, [rsp+0x90]
000075aec0bd7bb7  vmovaps xmm11, [rsp+0xA0]
000075aec0bd7bc0  vmovaps xmm12, [rsp+0xB0]
000075aec0bd7bc9  vmovaps xmm13, [rsp+0xC0]
000075aec0bd7bd2  vmovaps xmm14, [rsp+0xD0]
000075aec0bd7bdb  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7be4  add rsp, 0xF0
000075aec0bd7beb  pop r11
000075aec0bd7bed  pop r10
000075aec0bd7bef  pop r9
000075aec0bd7bf1  pop r8
000075aec0bd7bf3  pop rsi
000075aec0bd7bf4  pop rdi
000075aec0bd7bf5  pop rdx
000075aec0bd7bf6  pop rcx
000075aec0bd7bf7  pop rax
000075aec0bd7bf8  add rsp, 0x08
000075aec0bd7bfc  jmp 0x000075AEC0BD5DCB
000075aec0bd7c01  call 0x000075AEC0AE5820
000075aec0bd7c06  jmp 0x000075AEC0BD5DD8
000075aec0bd7c0b  sub rsp, 0x08
000075aec0bd7c0f  push rax
000075aec0bd7c10  push rcx
000075aec0bd7c11  push rdx
000075aec0bd7c12  push rdi
000075aec0bd7c13  push rsi
000075aec0bd7c14  push r8
000075aec0bd7c16  push r9
000075aec0bd7c18  push r10
000075aec0bd7c1a  push r11
000075aec0bd7c1c  sub rsp, 0xF0
000075aec0bd7c23  vmovaps [rsp], xmm0
000075aec0bd7c28  vmovaps [rsp+0x10], xmm2
000075aec0bd7c2e  vmovaps [rsp+0x20], xmm3
000075aec0bd7c34  vmovaps [rsp+0x30], xmm4
000075aec0bd7c3a  vmovaps [rsp+0x40], xmm5
000075aec0bd7c40  vmovaps [rsp+0x50], xmm6
000075aec0bd7c46  vmovaps [rsp+0x60], xmm7
000075aec0bd7c4c  vmovaps [rsp+0x70], xmm8
000075aec0bd7c52  vmovaps [rsp+0x80], xmm9
000075aec0bd7c5b  vmovaps [rsp+0x90], xmm10
000075aec0bd7c64  vmovaps [rsp+0xA0], xmm11
000075aec0bd7c6d  vmovaps [rsp+0xB0], xmm12
000075aec0bd7c76  vmovaps [rsp+0xC0], xmm13
000075aec0bd7c7f  vmovaps [rsp+0xD0], xmm14
000075aec0bd7c88  vmovaps [rsp+0xE0], xmm15
000075aec0bd7c91  sub rsp, 0x30
000075aec0bd7c95  movaps [rsp], xmm1
000075aec0bd7c99  movaps [rsp+0x10], xmm5
000075aec0bd7c9e  movaps [rsp+0x20], xmm7
000075aec0bd7ca3  lea rdi, [rsp]
000075aec0bd7ca7  mov esi, 0x00
000075aec0bd7cac  mov rax, 0x57F4B31E6530
000075aec0bd7cb6  call rax
000075aec0bd7cb8  movaps xmm1, [rsp]
000075aec0bd7cbc  add rsp, 0x30
000075aec0bd7cc0  vmovaps xmm0, [rsp]
000075aec0bd7cc5  vmovaps xmm2, [rsp+0x10]
000075aec0bd7ccb  vmovaps xmm3, [rsp+0x20]
000075aec0bd7cd1  vmovaps xmm4, [rsp+0x30]
000075aec0bd7cd7  vmovaps xmm5, [rsp+0x40]
000075aec0bd7cdd  vmovaps xmm6, [rsp+0x50]
000075aec0bd7ce3  vmovaps xmm7, [rsp+0x60]
000075aec0bd7ce9  vmovaps xmm8, [rsp+0x70]
000075aec0bd7cef  vmovaps xmm9, [rsp+0x80]
000075aec0bd7cf8  vmovaps xmm10, [rsp+0x90]
000075aec0bd7d01  vmovaps xmm11, [rsp+0xA0]
000075aec0bd7d0a  vmovaps xmm12, [rsp+0xB0]
000075aec0bd7d13  vmovaps xmm13, [rsp+0xC0]
000075aec0bd7d1c  vmovaps xmm14, [rsp+0xD0]
000075aec0bd7d25  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7d2e  add rsp, 0xF0
000075aec0bd7d35  pop r11
000075aec0bd7d37  pop r10
000075aec0bd7d39  pop r9
000075aec0bd7d3b  pop r8
000075aec0bd7d3d  pop rsi
000075aec0bd7d3e  pop rdi
000075aec0bd7d3f  pop rdx
000075aec0bd7d40  pop rcx
000075aec0bd7d41  pop rax
000075aec0bd7d42  add rsp, 0x08
000075aec0bd7d46  jmp 0x000075AEC0BD5E7D
000075aec0bd7d4b  sub rsp, 0x08
000075aec0bd7d4f  push rax
000075aec0bd7d50  push rcx
000075aec0bd7d51  push rdx
000075aec0bd7d52  push rdi
000075aec0bd7d53  push rsi
000075aec0bd7d54  push r8
000075aec0bd7d56  push r9
000075aec0bd7d58  push r10
000075aec0bd7d5a  push r11
000075aec0bd7d5c  sub rsp, 0xF0
000075aec0bd7d63  vmovaps [rsp], xmm0
000075aec0bd7d68  vmovaps [rsp+0x10], xmm1
000075aec0bd7d6e  vmovaps [rsp+0x20], xmm2
000075aec0bd7d74  vmovaps [rsp+0x30], xmm3
000075aec0bd7d7a  vmovaps [rsp+0x40], xmm4
000075aec0bd7d80  vmovaps [rsp+0x50], xmm5
000075aec0bd7d86  vmovaps [rsp+0x60], xmm6
000075aec0bd7d8c  vmovaps [rsp+0x70], xmm8
000075aec0bd7d92  vmovaps [rsp+0x80], xmm9
000075aec0bd7d9b  vmovaps [rsp+0x90], xmm10
000075aec0bd7da4  vmovaps [rsp+0xA0], xmm11
000075aec0bd7dad  vmovaps [rsp+0xB0], xmm12
000075aec0bd7db6  vmovaps [rsp+0xC0], xmm13
000075aec0bd7dbf  vmovaps [rsp+0xD0], xmm14
000075aec0bd7dc8  vmovaps [rsp+0xE0], xmm15
000075aec0bd7dd1  sub rsp, 0x30
000075aec0bd7dd5  movaps [rsp], xmm7
000075aec0bd7dd9  movaps [rsp+0x10], xmm5
000075aec0bd7dde  movaps [rsp+0x20], xmm15
000075aec0bd7de4  lea rdi, [rsp]
000075aec0bd7de8  mov esi, 0x00
000075aec0bd7ded  mov rax, 0x57F4B31E6530
000075aec0bd7df7  call rax
000075aec0bd7df9  movaps xmm7, [rsp]
000075aec0bd7dfd  add rsp, 0x30
000075aec0bd7e01  vmovaps xmm0, [rsp]
000075aec0bd7e06  vmovaps xmm1, [rsp+0x10]
000075aec0bd7e0c  vmovaps xmm2, [rsp+0x20]
000075aec0bd7e12  vmovaps xmm3, [rsp+0x30]
000075aec0bd7e18  vmovaps xmm4, [rsp+0x40]
000075aec0bd7e1e  vmovaps xmm5, [rsp+0x50]
000075aec0bd7e24  vmovaps xmm6, [rsp+0x60]
000075aec0bd7e2a  vmovaps xmm8, [rsp+0x70]
000075aec0bd7e30  vmovaps xmm9, [rsp+0x80]
000075aec0bd7e39  vmovaps xmm10, [rsp+0x90]
000075aec0bd7e42  vmovaps xmm11, [rsp+0xA0]
000075aec0bd7e4b  vmovaps xmm12, [rsp+0xB0]
000075aec0bd7e54  vmovaps xmm13, [rsp+0xC0]
000075aec0bd7e5d  vmovaps xmm14, [rsp+0xD0]
000075aec0bd7e66  vmovaps xmm15, [rsp+0xE0]
000075aec0bd7e6f  add rsp, 0xF0
000075aec0bd7e76  pop r11
000075aec0bd7e78  pop r10
000075aec0bd7e7a  pop r9
000075aec0bd7e7c  pop r8
000075aec0bd7e7e  pop rsi
000075aec0bd7e7f  pop rdi
000075aec0bd7e80  pop rdx
000075aec0bd7e81  pop rcx
000075aec0bd7e82  pop rax
000075aec0bd7e83  add rsp, 0x08
000075aec0bd7e87  jmp 0x000075AEC0BD5EB3
000075aec0bd7e8c  call 0x000075AEC0AD64F0
000075aec0bd7e91  jmp 0x000075AEC0BD5EC0
000075aec0bd7e96  sub rsp, 0x08
000075aec0bd7e9a  push rax
000075aec0bd7e9b  push rcx
000075aec0bd7e9c  push rdx
000075aec0bd7e9d  push rdi
000075aec0bd7e9e  push rsi
000075aec0bd7e9f  push r8
000075aec0bd7ea1  push r9
000075aec0bd7ea3  push r10
000075aec0bd7ea5  push r11
000075aec0bd7ea7  sub rsp, 0xF0
000075aec0bd7eae  vmovaps [rsp], xmm0
000075aec0bd7eb3  vmovaps [rsp+0x10], xmm1
000075aec0bd7eb9  vmovaps [rsp+0x20], xmm2
000075aec0bd7ebf  vmovaps [rsp+0x30], xmm3
000075aec0bd7ec5  vmovaps [rsp+0x40], xmm4
000075aec0bd7ecb  vmovaps [rsp+0x50], xmm5
000075aec0bd7ed1  vmovaps [rsp+0x60], xmm6
000075aec0bd7ed7  vmovaps [rsp+0x70], xmm7
000075aec0bd7edd  vmovaps [rsp+0x80], xmm8
000075aec0bd7ee6  vmovaps [rsp+0x90], xmm9
000075aec0bd7eef  vmovaps [rsp+0xA0], xmm10
000075aec0bd7ef8  vmovaps [rsp+0xB0], xmm11
000075aec0bd7f01  vmovaps [rsp+0xC0], xmm12
000075aec0bd7f0a  vmovaps [rsp+0xD0], xmm13
000075aec0bd7f13  vmovaps [rsp+0xE0], xmm14
000075aec0bd7f1c  sub rsp, 0x30
000075aec0bd7f20  movaps [rsp], xmm15
000075aec0bd7f25  movaps [rsp+0x10], xmm5
000075aec0bd7f2a  movaps [rsp+0x20], xmm3
000075aec0bd7f2f  lea rdi, [rsp]
000075aec0bd7f33  mov esi, 0x00
000075aec0bd7f38  mov rax, 0x57F4B31E6530
000075aec0bd7f42  call rax
000075aec0bd7f44  movaps xmm15, [rsp]
000075aec0bd7f49  add rsp, 0x30
000075aec0bd7f4d  vmovaps xmm0, [rsp]
000075aec0bd7f52  vmovaps xmm1, [rsp+0x10]
000075aec0bd7f58  vmovaps xmm2, [rsp+0x20]
000075aec0bd7f5e  vmovaps xmm3, [rsp+0x30]
000075aec0bd7f64  vmovaps xmm4, [rsp+0x40]
000075aec0bd7f6a  vmovaps xmm5, [rsp+0x50]
000075aec0bd7f70  vmovaps xmm6, [rsp+0x60]
000075aec0bd7f76  vmovaps xmm7, [rsp+0x70]
000075aec0bd7f7c  vmovaps xmm8, [rsp+0x80]
000075aec0bd7f85  vmovaps xmm9, [rsp+0x90]
000075aec0bd7f8e  vmovaps xmm10, [rsp+0xA0]
000075aec0bd7f97  vmovaps xmm11, [rsp+0xB0]
000075aec0bd7fa0  vmovaps xmm12, [rsp+0xC0]
000075aec0bd7fa9  vmovaps xmm13, [rsp+0xD0]
000075aec0bd7fb2  vmovaps xmm14, [rsp+0xE0]
000075aec0bd7fbb  add rsp, 0xF0
000075aec0bd7fc2  pop r11
000075aec0bd7fc4  pop r10
000075aec0bd7fc6  pop r9
000075aec0bd7fc8  pop r8
000075aec0bd7fca  pop rsi
000075aec0bd7fcb  pop rdi
000075aec0bd7fcc  pop rdx
000075aec0bd7fcd  pop rcx
000075aec0bd7fce  pop rax
000075aec0bd7fcf  add rsp, 0x08
000075aec0bd7fd3  jmp 0x000075AEC0BD5EE6
000075aec0bd7fd8  sub rsp, 0x08
000075aec0bd7fdc  push rax
000075aec0bd7fdd  push rcx
000075aec0bd7fde  push rdx
000075aec0bd7fdf  push rdi
000075aec0bd7fe0  push rsi
000075aec0bd7fe1  push r8
000075aec0bd7fe3  push r9
000075aec0bd7fe5  push r10
000075aec0bd7fe7  push r11
000075aec0bd7fe9  sub rsp, 0xF0
000075aec0bd7ff0  vmovaps [rsp], xmm0
000075aec0bd7ff5  vmovaps [rsp+0x10], xmm2
000075aec0bd7ffb  vmovaps [rsp+0x20], xmm3
000075aec0bd8001  vmovaps [rsp+0x30], xmm4
000075aec0bd8007  vmovaps [rsp+0x40], xmm5
000075aec0bd800d  vmovaps [rsp+0x50], xmm6
000075aec0bd8013  vmovaps [rsp+0x60], xmm7
000075aec0bd8019  vmovaps [rsp+0x70], xmm8
000075aec0bd801f  vmovaps [rsp+0x80], xmm9
000075aec0bd8028  vmovaps [rsp+0x90], xmm10
000075aec0bd8031  vmovaps [rsp+0xA0], xmm11
000075aec0bd803a  vmovaps [rsp+0xB0], xmm12
000075aec0bd8043  vmovaps [rsp+0xC0], xmm13
000075aec0bd804c  vmovaps [rsp+0xD0], xmm14
000075aec0bd8055  vmovaps [rsp+0xE0], xmm15
000075aec0bd805e  sub rsp, 0x30
000075aec0bd8062  movaps [rsp], xmm1
000075aec0bd8066  movaps [rsp+0x10], xmm5
000075aec0bd806b  movaps [rsp+0x20], xmm4
000075aec0bd8070  lea rdi, [rsp]
000075aec0bd8074  mov esi, 0x00
000075aec0bd8079  mov rax, 0x57F4B31E6530
000075aec0bd8083  call rax
000075aec0bd8085  movaps xmm1, [rsp]
000075aec0bd8089  add rsp, 0x30
000075aec0bd808d  vmovaps xmm0, [rsp]
000075aec0bd8092  vmovaps xmm2, [rsp+0x10]
000075aec0bd8098  vmovaps xmm3, [rsp+0x20]
000075aec0bd809e  vmovaps xmm4, [rsp+0x30]
000075aec0bd80a4  vmovaps xmm5, [rsp+0x40]
000075aec0bd80aa  vmovaps xmm6, [rsp+0x50]
000075aec0bd80b0  vmovaps xmm7, [rsp+0x60]
000075aec0bd80b6  vmovaps xmm8, [rsp+0x70]
000075aec0bd80bc  vmovaps xmm9, [rsp+0x80]
000075aec0bd80c5  vmovaps xmm10, [rsp+0x90]
000075aec0bd80ce  vmovaps xmm11, [rsp+0xA0]
000075aec0bd80d7  vmovaps xmm12, [rsp+0xB0]
000075aec0bd80e0  vmovaps xmm13, [rsp+0xC0]
000075aec0bd80e9  vmovaps xmm14, [rsp+0xD0]
000075aec0bd80f2  vmovaps xmm15, [rsp+0xE0]
000075aec0bd80fb  add rsp, 0xF0
000075aec0bd8102  pop r11
000075aec0bd8104  pop r10
000075aec0bd8106  pop r9
000075aec0bd8108  pop r8
000075aec0bd810a  pop rsi
000075aec0bd810b  pop rdi
000075aec0bd810c  pop rdx
000075aec0bd810d  pop rcx
000075aec0bd810e  pop rax
000075aec0bd810f  add rsp, 0x08
000075aec0bd8113  jmp 0x000075AEC0BD5F06
000075aec0bd8118  sub rsp, 0x08
000075aec0bd811c  push rax
000075aec0bd811d  push rcx
000075aec0bd811e  push rdx
000075aec0bd811f  push rdi
000075aec0bd8120  push rsi
000075aec0bd8121  push r8
000075aec0bd8123  push r9
000075aec0bd8125  push r10
000075aec0bd8127  push r11
000075aec0bd8129  sub rsp, 0xF0
000075aec0bd8130  vmovaps [rsp], xmm0
000075aec0bd8135  vmovaps [rsp+0x10], xmm1
000075aec0bd813b  vmovaps [rsp+0x20], xmm2
000075aec0bd8141  vmovaps [rsp+0x30], xmm3
000075aec0bd8147  vmovaps [rsp+0x40], xmm5
000075aec0bd814d  vmovaps [rsp+0x50], xmm6
000075aec0bd8153  vmovaps [rsp+0x60], xmm7
000075aec0bd8159  vmovaps [rsp+0x70], xmm8
000075aec0bd815f  vmovaps [rsp+0x80], xmm9
000075aec0bd8168  vmovaps [rsp+0x90], xmm10
000075aec0bd8171  vmovaps [rsp+0xA0], xmm11
000075aec0bd817a  vmovaps [rsp+0xB0], xmm12
000075aec0bd8183  vmovaps [rsp+0xC0], xmm13
000075aec0bd818c  vmovaps [rsp+0xD0], xmm14
000075aec0bd8195  vmovaps [rsp+0xE0], xmm15
000075aec0bd819e  sub rsp, 0x30
000075aec0bd81a2  movaps [rsp], xmm4
000075aec0bd81a6  movaps [rsp+0x10], xmm3
000075aec0bd81ab  movaps [rsp+0x20], xmm5
000075aec0bd81b0  lea rdi, [rsp]
000075aec0bd81b4  mov esi, 0x00
000075aec0bd81b9  mov rax, 0x57F4B31E6530
000075aec0bd81c3  call rax
000075aec0bd81c5  movaps xmm4, [rsp]
000075aec0bd81c9  add rsp, 0x30
000075aec0bd81cd  vmovaps xmm0, [rsp]
000075aec0bd81d2  vmovaps xmm1, [rsp+0x10]
000075aec0bd81d8  vmovaps xmm2, [rsp+0x20]
000075aec0bd81de  vmovaps xmm3, [rsp+0x30]
000075aec0bd81e4  vmovaps xmm5, [rsp+0x40]
000075aec0bd81ea  vmovaps xmm6, [rsp+0x50]
000075aec0bd81f0  vmovaps xmm7, [rsp+0x60]
000075aec0bd81f6  vmovaps xmm8, [rsp+0x70]
000075aec0bd81fc  vmovaps xmm9, [rsp+0x80]
000075aec0bd8205  vmovaps xmm10, [rsp+0x90]
000075aec0bd820e  vmovaps xmm11, [rsp+0xA0]
000075aec0bd8217  vmovaps xmm12, [rsp+0xB0]
000075aec0bd8220  vmovaps xmm13, [rsp+0xC0]
000075aec0bd8229  vmovaps xmm14, [rsp+0xD0]
000075aec0bd8232  vmovaps xmm15, [rsp+0xE0]
000075aec0bd823b  add rsp, 0xF0
000075aec0bd8242  pop r11
000075aec0bd8244  pop r10
000075aec0bd8246  pop r9
000075aec0bd8248  pop r8
000075aec0bd824a  pop rsi
000075aec0bd824b  pop rdi
000075aec0bd824c  pop rdx
000075aec0bd824d  pop rcx
000075aec0bd824e  pop rax
000075aec0bd824f  add rsp, 0x08
000075aec0bd8253  jmp 0x000075AEC0BD5F54
000075aec0bd8258  call 0x000075AEC0AD64F0
000075aec0bd825d  jmp 0x000075AEC0BD5F61
000075aec0bd8262  sub rsp, 0x08
000075aec0bd8266  push rax
000075aec0bd8267  push rcx
000075aec0bd8268  push rdx
000075aec0bd8269  push rdi
000075aec0bd826a  push rsi
000075aec0bd826b  push r8
000075aec0bd826d  push r9
000075aec0bd826f  push r10
000075aec0bd8271  push r11
000075aec0bd8273  sub rsp, 0xF0
000075aec0bd827a  vmovaps [rsp], xmm0
000075aec0bd827f  vmovaps [rsp+0x10], xmm1
000075aec0bd8285  vmovaps [rsp+0x20], xmm2
000075aec0bd828b  vmovaps [rsp+0x30], xmm3
000075aec0bd8291  vmovaps [rsp+0x40], xmm4
000075aec0bd8297  vmovaps [rsp+0x50], xmm6
000075aec0bd829d  vmovaps [rsp+0x60], xmm7
000075aec0bd82a3  vmovaps [rsp+0x70], xmm8
000075aec0bd82a9  vmovaps [rsp+0x80], xmm9
000075aec0bd82b2  vmovaps [rsp+0x90], xmm10
000075aec0bd82bb  vmovaps [rsp+0xA0], xmm11
000075aec0bd82c4  vmovaps [rsp+0xB0], xmm12
000075aec0bd82cd  vmovaps [rsp+0xC0], xmm13
000075aec0bd82d6  vmovaps [rsp+0xD0], xmm14
000075aec0bd82df  vmovaps [rsp+0xE0], xmm15
000075aec0bd82e8  sub rsp, 0x30
000075aec0bd82ec  movaps [rsp], xmm5
000075aec0bd82f0  movaps [rsp+0x10], xmm6
000075aec0bd82f5  movaps [rsp+0x20], xmm3
000075aec0bd82fa  lea rdi, [rsp]
000075aec0bd82fe  mov esi, 0x00
000075aec0bd8303  mov rax, 0x57F4B31E6530
000075aec0bd830d  call rax
000075aec0bd830f  movaps xmm5, [rsp]
000075aec0bd8313  add rsp, 0x30
000075aec0bd8317  vmovaps xmm0, [rsp]
000075aec0bd831c  vmovaps xmm1, [rsp+0x10]
000075aec0bd8322  vmovaps xmm2, [rsp+0x20]
000075aec0bd8328  vmovaps xmm3, [rsp+0x30]
000075aec0bd832e  vmovaps xmm4, [rsp+0x40]
000075aec0bd8334  vmovaps xmm6, [rsp+0x50]
000075aec0bd833a  vmovaps xmm7, [rsp+0x60]
000075aec0bd8340  vmovaps xmm8, [rsp+0x70]
000075aec0bd8346  vmovaps xmm9, [rsp+0x80]
000075aec0bd834f  vmovaps xmm10, [rsp+0x90]
000075aec0bd8358  vmovaps xmm11, [rsp+0xA0]
000075aec0bd8361  vmovaps xmm12, [rsp+0xB0]
000075aec0bd836a  vmovaps xmm13, [rsp+0xC0]
000075aec0bd8373  vmovaps xmm14, [rsp+0xD0]
000075aec0bd837c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd8385  add rsp, 0xF0
000075aec0bd838c  pop r11
000075aec0bd838e  pop r10
000075aec0bd8390  pop r9
000075aec0bd8392  pop r8
000075aec0bd8394  pop rsi
000075aec0bd8395  pop rdi
000075aec0bd8396  pop rdx
000075aec0bd8397  pop rcx
000075aec0bd8398  pop rax
000075aec0bd8399  add rsp, 0x08
000075aec0bd839d  jmp 0x000075AEC0BD5F87
000075aec0bd83a2  sub rsp, 0x08
000075aec0bd83a6  push rax
000075aec0bd83a7  push rcx
000075aec0bd83a8  push rdx
000075aec0bd83a9  push rdi
000075aec0bd83aa  push rsi
000075aec0bd83ab  push r8
000075aec0bd83ad  push r9
000075aec0bd83af  push r10
000075aec0bd83b1  push r11
000075aec0bd83b3  sub rsp, 0xF0
000075aec0bd83ba  vmovaps [rsp], xmm0
000075aec0bd83bf  vmovaps [rsp+0x10], xmm1
000075aec0bd83c5  vmovaps [rsp+0x20], xmm2
000075aec0bd83cb  vmovaps [rsp+0x30], xmm3
000075aec0bd83d1  vmovaps [rsp+0x40], xmm4
000075aec0bd83d7  vmovaps [rsp+0x50], xmm5
000075aec0bd83dd  vmovaps [rsp+0x60], xmm7
000075aec0bd83e3  vmovaps [rsp+0x70], xmm8
000075aec0bd83e9  vmovaps [rsp+0x80], xmm9
000075aec0bd83f2  vmovaps [rsp+0x90], xmm10
000075aec0bd83fb  vmovaps [rsp+0xA0], xmm11
000075aec0bd8404  vmovaps [rsp+0xB0], xmm12
000075aec0bd840d  vmovaps [rsp+0xC0], xmm13
000075aec0bd8416  vmovaps [rsp+0xD0], xmm14
000075aec0bd841f  vmovaps [rsp+0xE0], xmm15
000075aec0bd8428  sub rsp, 0x30
000075aec0bd842c  movaps [rsp], xmm6
000075aec0bd8430  movaps [rsp+0x10], xmm9
000075aec0bd8436  movaps [rsp+0x20], xmm1
000075aec0bd843b  lea rdi, [rsp]
000075aec0bd843f  mov esi, 0x00
000075aec0bd8444  mov rax, 0x57F4B31E6530
000075aec0bd844e  call rax
000075aec0bd8450  movaps xmm6, [rsp]
000075aec0bd8454  add rsp, 0x30
000075aec0bd8458  vmovaps xmm0, [rsp]
000075aec0bd845d  vmovaps xmm1, [rsp+0x10]
000075aec0bd8463  vmovaps xmm2, [rsp+0x20]
000075aec0bd8469  vmovaps xmm3, [rsp+0x30]
000075aec0bd846f  vmovaps xmm4, [rsp+0x40]
000075aec0bd8475  vmovaps xmm5, [rsp+0x50]
000075aec0bd847b  vmovaps xmm7, [rsp+0x60]
000075aec0bd8481  vmovaps xmm8, [rsp+0x70]
000075aec0bd8487  vmovaps xmm9, [rsp+0x80]
000075aec0bd8490  vmovaps xmm10, [rsp+0x90]
000075aec0bd8499  vmovaps xmm11, [rsp+0xA0]
000075aec0bd84a2  vmovaps xmm12, [rsp+0xB0]
000075aec0bd84ab  vmovaps xmm13, [rsp+0xC0]
000075aec0bd84b4  vmovaps xmm14, [rsp+0xD0]
000075aec0bd84bd  vmovaps xmm15, [rsp+0xE0]
000075aec0bd84c6  add rsp, 0xF0
000075aec0bd84cd  pop r11
000075aec0bd84cf  pop r10
000075aec0bd84d1  pop r9
000075aec0bd84d3  pop r8
000075aec0bd84d5  pop rsi
000075aec0bd84d6  pop rdi
000075aec0bd84d7  pop rdx
000075aec0bd84d8  pop rcx
000075aec0bd84d9  pop rax
000075aec0bd84da  add rsp, 0x08
000075aec0bd84de  jmp 0x000075AEC0BD5FAB
000075aec0bd84e3  sub rsp, 0x08
000075aec0bd84e7  push rax
000075aec0bd84e8  push rcx
000075aec0bd84e9  push rdx
000075aec0bd84ea  push rdi
000075aec0bd84eb  push rsi
000075aec0bd84ec  push r8
000075aec0bd84ee  push r9
000075aec0bd84f0  push r10
000075aec0bd84f2  push r11
000075aec0bd84f4  sub rsp, 0xF0
000075aec0bd84fb  vmovaps [rsp], xmm0
000075aec0bd8500  vmovaps [rsp+0x10], xmm1
000075aec0bd8506  vmovaps [rsp+0x20], xmm2
000075aec0bd850c  vmovaps [rsp+0x30], xmm3
000075aec0bd8512  vmovaps [rsp+0x40], xmm4
000075aec0bd8518  vmovaps [rsp+0x50], xmm5
000075aec0bd851e  vmovaps [rsp+0x60], xmm6
000075aec0bd8524  vmovaps [rsp+0x70], xmm7
000075aec0bd852a  vmovaps [rsp+0x80], xmm8
000075aec0bd8533  vmovaps [rsp+0x90], xmm10
000075aec0bd853c  vmovaps [rsp+0xA0], xmm11
000075aec0bd8545  vmovaps [rsp+0xB0], xmm12
000075aec0bd854e  vmovaps [rsp+0xC0], xmm13
000075aec0bd8557  vmovaps [rsp+0xD0], xmm14
000075aec0bd8560  vmovaps [rsp+0xE0], xmm15
000075aec0bd8569  sub rsp, 0x30
000075aec0bd856d  movaps [rsp], xmm9
000075aec0bd8572  movaps [rsp+0x10], xmm3
000075aec0bd8577  movaps [rsp+0x20], xmm1
000075aec0bd857c  lea rdi, [rsp]
000075aec0bd8580  mov esi, 0x00
000075aec0bd8585  mov rax, 0x57F4B31E6530
000075aec0bd858f  call rax
000075aec0bd8591  movaps xmm9, [rsp]
000075aec0bd8596  add rsp, 0x30
000075aec0bd859a  vmovaps xmm0, [rsp]
000075aec0bd859f  vmovaps xmm1, [rsp+0x10]
000075aec0bd85a5  vmovaps xmm2, [rsp+0x20]
000075aec0bd85ab  vmovaps xmm3, [rsp+0x30]
000075aec0bd85b1  vmovaps xmm4, [rsp+0x40]
000075aec0bd85b7  vmovaps xmm5, [rsp+0x50]
000075aec0bd85bd  vmovaps xmm6, [rsp+0x60]
000075aec0bd85c3  vmovaps xmm7, [rsp+0x70]
000075aec0bd85c9  vmovaps xmm8, [rsp+0x80]
000075aec0bd85d2  vmovaps xmm10, [rsp+0x90]
000075aec0bd85db  vmovaps xmm11, [rsp+0xA0]
000075aec0bd85e4  vmovaps xmm12, [rsp+0xB0]
000075aec0bd85ed  vmovaps xmm13, [rsp+0xC0]
000075aec0bd85f6  vmovaps xmm14, [rsp+0xD0]
000075aec0bd85ff  vmovaps xmm15, [rsp+0xE0]
000075aec0bd8608  add rsp, 0xF0
000075aec0bd860f  pop r11
000075aec0bd8611  pop r10
000075aec0bd8613  pop r9
000075aec0bd8615  pop r8
000075aec0bd8617  pop rsi
000075aec0bd8618  pop rdi
000075aec0bd8619  pop rdx
000075aec0bd861a  pop rcx
000075aec0bd861b  pop rax
000075aec0bd861c  add rsp, 0x08
000075aec0bd8620  jmp 0x000075AEC0BD5FF7
000075aec0bd8625  call 0x000075AEC0AD64F0
000075aec0bd862a  jmp 0x000075AEC0BD6004
000075aec0bd862f  sub rsp, 0x08
000075aec0bd8633  push rax
000075aec0bd8634  push rcx
000075aec0bd8635  push rdx
000075aec0bd8636  push rdi
000075aec0bd8637  push rsi
000075aec0bd8638  push r8
000075aec0bd863a  push r9
000075aec0bd863c  push r10
000075aec0bd863e  push r11
000075aec0bd8640  sub rsp, 0xF0
000075aec0bd8647  vmovaps [rsp], xmm0
000075aec0bd864c  vmovaps [rsp+0x10], xmm1
000075aec0bd8652  vmovaps [rsp+0x20], xmm2
000075aec0bd8658  vmovaps [rsp+0x30], xmm3
000075aec0bd865e  vmovaps [rsp+0x40], xmm4
000075aec0bd8664  vmovaps [rsp+0x50], xmm5
000075aec0bd866a  vmovaps [rsp+0x60], xmm6
000075aec0bd8670  vmovaps [rsp+0x70], xmm7
000075aec0bd8676  vmovaps [rsp+0x80], xmm8
000075aec0bd867f  vmovaps [rsp+0x90], xmm9
000075aec0bd8688  vmovaps [rsp+0xA0], xmm10
000075aec0bd8691  vmovaps [rsp+0xB0], xmm11
000075aec0bd869a  vmovaps [rsp+0xC0], xmm12
000075aec0bd86a3  vmovaps [rsp+0xD0], xmm13
000075aec0bd86ac  vmovaps [rsp+0xE0], xmm14
000075aec0bd86b5  sub rsp, 0x30
000075aec0bd86b9  movaps [rsp], xmm15
000075aec0bd86be  movaps [rsp+0x10], xmm3
000075aec0bd86c3  movaps [rsp+0x20], xmm7
000075aec0bd86c8  lea rdi, [rsp]
000075aec0bd86cc  mov esi, 0x00
000075aec0bd86d1  mov rax, 0x57F4B31E6530
000075aec0bd86db  call rax
000075aec0bd86dd  movaps xmm15, [rsp]
000075aec0bd86e2  add rsp, 0x30
000075aec0bd86e6  vmovaps xmm0, [rsp]
000075aec0bd86eb  vmovaps xmm1, [rsp+0x10]
000075aec0bd86f1  vmovaps xmm2, [rsp+0x20]
000075aec0bd86f7  vmovaps xmm3, [rsp+0x30]
000075aec0bd86fd  vmovaps xmm4, [rsp+0x40]
000075aec0bd8703  vmovaps xmm5, [rsp+0x50]
000075aec0bd8709  vmovaps xmm6, [rsp+0x60]
000075aec0bd870f  vmovaps xmm7, [rsp+0x70]
000075aec0bd8715  vmovaps xmm8, [rsp+0x80]
000075aec0bd871e  vmovaps xmm9, [rsp+0x90]
000075aec0bd8727  vmovaps xmm10, [rsp+0xA0]
000075aec0bd8730  vmovaps xmm11, [rsp+0xB0]
000075aec0bd8739  vmovaps xmm12, [rsp+0xC0]
000075aec0bd8742  vmovaps xmm13, [rsp+0xD0]
000075aec0bd874b  vmovaps xmm14, [rsp+0xE0]
000075aec0bd8754  add rsp, 0xF0
000075aec0bd875b  pop r11
000075aec0bd875d  pop r10
000075aec0bd875f  pop r9
000075aec0bd8761  pop r8
000075aec0bd8763  pop rsi
000075aec0bd8764  pop rdi
000075aec0bd8765  pop rdx
000075aec0bd8766  pop rcx
000075aec0bd8767  pop rax
000075aec0bd8768  add rsp, 0x08
000075aec0bd876c  jmp 0x000075AEC0BD6030
000075aec0bd8771  sub rsp, 0x08
000075aec0bd8775  push rax
000075aec0bd8776  push rcx
000075aec0bd8777  push rdx
000075aec0bd8778  push rdi
000075aec0bd8779  push rsi
000075aec0bd877a  push r8
000075aec0bd877c  push r9
000075aec0bd877e  push r10
000075aec0bd8780  push r11
000075aec0bd8782  sub rsp, 0xF0
000075aec0bd8789  vmovaps [rsp], xmm0
000075aec0bd878e  vmovaps [rsp+0x10], xmm1
000075aec0bd8794  vmovaps [rsp+0x20], xmm2
000075aec0bd879a  vmovaps [rsp+0x30], xmm4
000075aec0bd87a0  vmovaps [rsp+0x40], xmm5
000075aec0bd87a6  vmovaps [rsp+0x50], xmm6
000075aec0bd87ac  vmovaps [rsp+0x60], xmm7
000075aec0bd87b2  vmovaps [rsp+0x70], xmm8
000075aec0bd87b8  vmovaps [rsp+0x80], xmm9
000075aec0bd87c1  vmovaps [rsp+0x90], xmm10
000075aec0bd87ca  vmovaps [rsp+0xA0], xmm11
000075aec0bd87d3  vmovaps [rsp+0xB0], xmm12
000075aec0bd87dc  vmovaps [rsp+0xC0], xmm13
000075aec0bd87e5  vmovaps [rsp+0xD0], xmm14
000075aec0bd87ee  vmovaps [rsp+0xE0], xmm15
000075aec0bd87f7  sub rsp, 0x30
000075aec0bd87fb  movaps [rsp], xmm3
000075aec0bd87ff  movaps [rsp+0x10], xmm1
000075aec0bd8804  movaps [rsp+0x20], xmm15
000075aec0bd880a  lea rdi, [rsp]
000075aec0bd880e  mov esi, 0x00
000075aec0bd8813  mov rax, 0x57F4B31E6530
000075aec0bd881d  call rax
000075aec0bd881f  movaps xmm3, [rsp]
000075aec0bd8823  add rsp, 0x30
000075aec0bd8827  vmovaps xmm0, [rsp]
000075aec0bd882c  vmovaps xmm1, [rsp+0x10]
000075aec0bd8832  vmovaps xmm2, [rsp+0x20]
000075aec0bd8838  vmovaps xmm4, [rsp+0x30]
000075aec0bd883e  vmovaps xmm5, [rsp+0x40]
000075aec0bd8844  vmovaps xmm6, [rsp+0x50]
000075aec0bd884a  vmovaps xmm7, [rsp+0x60]
000075aec0bd8850  vmovaps xmm8, [rsp+0x70]
000075aec0bd8856  vmovaps xmm9, [rsp+0x80]
000075aec0bd885f  vmovaps xmm10, [rsp+0x90]
000075aec0bd8868  vmovaps xmm11, [rsp+0xA0]
000075aec0bd8871  vmovaps xmm12, [rsp+0xB0]
000075aec0bd887a  vmovaps xmm13, [rsp+0xC0]
000075aec0bd8883  vmovaps xmm14, [rsp+0xD0]
000075aec0bd888c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd8895  add rsp, 0xF0
000075aec0bd889c  pop r11
000075aec0bd889e  pop r10
000075aec0bd88a0  pop r9
000075aec0bd88a2  pop r8
000075aec0bd88a4  pop rsi
000075aec0bd88a5  pop rdi
000075aec0bd88a6  pop rdx
000075aec0bd88a7  pop rcx
000075aec0bd88a8  pop rax
000075aec0bd88a9  add rsp, 0x08
000075aec0bd88ad  jmp 0x000075AEC0BD60BF
000075aec0bd88b2  call 0x000075AEC0AD64F0
000075aec0bd88b7  jmp 0x000075AEC0BD60C9
000075aec0bd88bc  sub rsp, 0x08
000075aec0bd88c0  push rax
000075aec0bd88c1  push rcx
000075aec0bd88c2  push rdx
000075aec0bd88c3  push rdi
000075aec0bd88c4  push rsi
000075aec0bd88c5  push r8
000075aec0bd88c7  push r9
000075aec0bd88c9  push r10
000075aec0bd88cb  push r11
000075aec0bd88cd  sub rsp, 0xF0
000075aec0bd88d4  vmovaps [rsp], xmm0
000075aec0bd88d9  vmovaps [rsp+0x10], xmm1
000075aec0bd88df  vmovaps [rsp+0x20], xmm2
000075aec0bd88e5  vmovaps [rsp+0x30], xmm3
000075aec0bd88eb  vmovaps [rsp+0x40], xmm4
000075aec0bd88f1  vmovaps [rsp+0x50], xmm5
000075aec0bd88f7  vmovaps [rsp+0x60], xmm6
000075aec0bd88fd  vmovaps [rsp+0x70], xmm7
000075aec0bd8903  vmovaps [rsp+0x80], xmm8
000075aec0bd890c  vmovaps [rsp+0x90], xmm9
000075aec0bd8915  vmovaps [rsp+0xA0], xmm10
000075aec0bd891e  vmovaps [rsp+0xB0], xmm11
000075aec0bd8927  vmovaps [rsp+0xC0], xmm12
000075aec0bd8930  vmovaps [rsp+0xD0], xmm13
000075aec0bd8939  vmovaps [rsp+0xE0], xmm14
000075aec0bd8942  sub rsp, 0x30
000075aec0bd8946  movaps [rsp], xmm15
000075aec0bd894b  movaps [rsp+0x10], xmm14
000075aec0bd8951  movaps [rsp+0x20], xmm4
000075aec0bd8956  lea rdi, [rsp]
000075aec0bd895a  mov esi, 0x00
000075aec0bd895f  mov rax, 0x57F4B31E6530
000075aec0bd8969  call rax
000075aec0bd896b  movaps xmm15, [rsp]
000075aec0bd8970  add rsp, 0x30
000075aec0bd8974  vmovaps xmm0, [rsp]
000075aec0bd8979  vmovaps xmm1, [rsp+0x10]
000075aec0bd897f  vmovaps xmm2, [rsp+0x20]
000075aec0bd8985  vmovaps xmm3, [rsp+0x30]
000075aec0bd898b  vmovaps xmm4, [rsp+0x40]
000075aec0bd8991  vmovaps xmm5, [rsp+0x50]
000075aec0bd8997  vmovaps xmm6, [rsp+0x60]
000075aec0bd899d  vmovaps xmm7, [rsp+0x70]
000075aec0bd89a3  vmovaps xmm8, [rsp+0x80]
000075aec0bd89ac  vmovaps xmm9, [rsp+0x90]
000075aec0bd89b5  vmovaps xmm10, [rsp+0xA0]
000075aec0bd89be  vmovaps xmm11, [rsp+0xB0]
000075aec0bd89c7  vmovaps xmm12, [rsp+0xC0]
000075aec0bd89d0  vmovaps xmm13, [rsp+0xD0]
000075aec0bd89d9  vmovaps xmm14, [rsp+0xE0]
000075aec0bd89e2  add rsp, 0xF0
000075aec0bd89e9  pop r11
000075aec0bd89eb  pop r10
000075aec0bd89ed  pop r9
000075aec0bd89ef  pop r8
000075aec0bd89f1  pop rsi
000075aec0bd89f2  pop rdi
000075aec0bd89f3  pop rdx
000075aec0bd89f4  pop rcx
000075aec0bd89f5  pop rax
000075aec0bd89f6  add rsp, 0x08
000075aec0bd89fa  jmp 0x000075AEC0BD60F7
000075aec0bd89ff  sub rsp, 0x08
000075aec0bd8a03  push rax
000075aec0bd8a04  push rcx
000075aec0bd8a05  push rdx
000075aec0bd8a06  push rdi
000075aec0bd8a07  push rsi
000075aec0bd8a08  push r8
000075aec0bd8a0a  push r9
000075aec0bd8a0c  push r10
000075aec0bd8a0e  push r11
000075aec0bd8a10  sub rsp, 0xF0
000075aec0bd8a17  vmovaps [rsp], xmm0
000075aec0bd8a1c  vmovaps [rsp+0x10], xmm1
000075aec0bd8a22  vmovaps [rsp+0x20], xmm2
000075aec0bd8a28  vmovaps [rsp+0x30], xmm3
000075aec0bd8a2e  vmovaps [rsp+0x40], xmm4
000075aec0bd8a34  vmovaps [rsp+0x50], xmm5
000075aec0bd8a3a  vmovaps [rsp+0x60], xmm6
000075aec0bd8a40  vmovaps [rsp+0x70], xmm7
000075aec0bd8a46  vmovaps [rsp+0x80], xmm8
000075aec0bd8a4f  vmovaps [rsp+0x90], xmm9
000075aec0bd8a58  vmovaps [rsp+0xA0], xmm10
000075aec0bd8a61  vmovaps [rsp+0xB0], xmm11
000075aec0bd8a6a  vmovaps [rsp+0xC0], xmm12
000075aec0bd8a73  vmovaps [rsp+0xD0], xmm13
000075aec0bd8a7c  vmovaps [rsp+0xE0], xmm15
000075aec0bd8a85  sub rsp, 0x30
000075aec0bd8a89  movaps [rsp], xmm14
000075aec0bd8a8e  movaps [rsp+0x10], xmm2
000075aec0bd8a93  movaps [rsp+0x20], xmm1
000075aec0bd8a98  lea rdi, [rsp]
000075aec0bd8a9c  mov esi, 0x00
000075aec0bd8aa1  mov rax, 0x57F4B31E6530
000075aec0bd8aab  call rax
000075aec0bd8aad  movaps xmm14, [rsp]
000075aec0bd8ab2  add rsp, 0x30
000075aec0bd8ab6  vmovaps xmm0, [rsp]
000075aec0bd8abb  vmovaps xmm1, [rsp+0x10]
000075aec0bd8ac1  vmovaps xmm2, [rsp+0x20]
000075aec0bd8ac7  vmovaps xmm3, [rsp+0x30]
000075aec0bd8acd  vmovaps xmm4, [rsp+0x40]
000075aec0bd8ad3  vmovaps xmm5, [rsp+0x50]
000075aec0bd8ad9  vmovaps xmm6, [rsp+0x60]
000075aec0bd8adf  vmovaps xmm7, [rsp+0x70]
000075aec0bd8ae5  vmovaps xmm8, [rsp+0x80]
000075aec0bd8aee  vmovaps xmm9, [rsp+0x90]
000075aec0bd8af7  vmovaps xmm10, [rsp+0xA0]
000075aec0bd8b00  vmovaps xmm11, [rsp+0xB0]
000075aec0bd8b09  vmovaps xmm12, [rsp+0xC0]
000075aec0bd8b12  vmovaps xmm13, [rsp+0xD0]
000075aec0bd8b1b  vmovaps xmm15, [rsp+0xE0]
000075aec0bd8b24  add rsp, 0xF0
000075aec0bd8b2b  pop r11
000075aec0bd8b2d  pop r10
000075aec0bd8b2f  pop r9
000075aec0bd8b31  pop r8
000075aec0bd8b33  pop rsi
000075aec0bd8b34  pop rdi
000075aec0bd8b35  pop rdx
000075aec0bd8b36  pop rcx
000075aec0bd8b37  pop rax
000075aec0bd8b38  add rsp, 0x08
000075aec0bd8b3c  jmp 0x000075AEC0BD611D
000075aec0bd8b41  sub rsp, 0x08
000075aec0bd8b45  push rax
000075aec0bd8b46  push rcx
000075aec0bd8b47  push rdx
000075aec0bd8b48  push rdi
000075aec0bd8b49  push rsi
000075aec0bd8b4a  push r8
000075aec0bd8b4c  push r9
000075aec0bd8b4e  push r10
000075aec0bd8b50  push r11
000075aec0bd8b52  sub rsp, 0xF0
000075aec0bd8b59  vmovaps [rsp], xmm0
000075aec0bd8b5e  vmovaps [rsp+0x10], xmm2
000075aec0bd8b64  vmovaps [rsp+0x20], xmm3
000075aec0bd8b6a  vmovaps [rsp+0x30], xmm4
000075aec0bd8b70  vmovaps [rsp+0x40], xmm5
000075aec0bd8b76  vmovaps [rsp+0x50], xmm6
000075aec0bd8b7c  vmovaps [rsp+0x60], xmm7
000075aec0bd8b82  vmovaps [rsp+0x70], xmm8
000075aec0bd8b88  vmovaps [rsp+0x80], xmm9
000075aec0bd8b91  vmovaps [rsp+0x90], xmm10
000075aec0bd8b9a  vmovaps [rsp+0xA0], xmm11
000075aec0bd8ba3  vmovaps [rsp+0xB0], xmm12
000075aec0bd8bac  vmovaps [rsp+0xC0], xmm13
000075aec0bd8bb5  vmovaps [rsp+0xD0], xmm14
000075aec0bd8bbe  vmovaps [rsp+0xE0], xmm15
000075aec0bd8bc7  sub rsp, 0x30
000075aec0bd8bcb  movaps [rsp], xmm1
000075aec0bd8bcf  movaps [rsp+0x10], xmm4
000075aec0bd8bd4  movaps [rsp+0x20], xmm9
000075aec0bd8bda  lea rdi, [rsp]
000075aec0bd8bde  mov esi, 0x00
000075aec0bd8be3  mov rax, 0x57F4B31E6530
000075aec0bd8bed  call rax
000075aec0bd8bef  movaps xmm1, [rsp]
000075aec0bd8bf3  add rsp, 0x30
000075aec0bd8bf7  vmovaps xmm0, [rsp]
000075aec0bd8bfc  vmovaps xmm2, [rsp+0x10]
000075aec0bd8c02  vmovaps xmm3, [rsp+0x20]
000075aec0bd8c08  vmovaps xmm4, [rsp+0x30]
000075aec0bd8c0e  vmovaps xmm5, [rsp+0x40]
000075aec0bd8c14  vmovaps xmm6, [rsp+0x50]
000075aec0bd8c1a  vmovaps xmm7, [rsp+0x60]
000075aec0bd8c20  vmovaps xmm8, [rsp+0x70]
000075aec0bd8c26  vmovaps xmm9, [rsp+0x80]
000075aec0bd8c2f  vmovaps xmm10, [rsp+0x90]
000075aec0bd8c38  vmovaps xmm11, [rsp+0xA0]
000075aec0bd8c41  vmovaps xmm12, [rsp+0xB0]
000075aec0bd8c4a  vmovaps xmm13, [rsp+0xC0]
000075aec0bd8c53  vmovaps xmm14, [rsp+0xD0]
000075aec0bd8c5c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd8c65  add rsp, 0xF0
000075aec0bd8c6c  pop r11
000075aec0bd8c6e  pop r10
000075aec0bd8c70  pop r9
000075aec0bd8c72  pop r8
000075aec0bd8c74  pop rsi
000075aec0bd8c75  pop rdi
000075aec0bd8c76  pop rdx
000075aec0bd8c77  pop rcx
000075aec0bd8c78  pop rax
000075aec0bd8c79  add rsp, 0x08
000075aec0bd8c7d  jmp 0x000075AEC0BD613B
000075aec0bd8c82  sub rsp, 0x08
000075aec0bd8c86  push rax
000075aec0bd8c87  push rcx
000075aec0bd8c88  push rdx
000075aec0bd8c89  push rdi
000075aec0bd8c8a  push rsi
000075aec0bd8c8b  push r8
000075aec0bd8c8d  push r9
000075aec0bd8c8f  push r10
000075aec0bd8c91  push r11
000075aec0bd8c93  sub rsp, 0xF0
000075aec0bd8c9a  vmovaps [rsp], xmm0
000075aec0bd8c9f  vmovaps [rsp+0x10], xmm1
000075aec0bd8ca5  vmovaps [rsp+0x20], xmm2
000075aec0bd8cab  vmovaps [rsp+0x30], xmm3
000075aec0bd8cb1  vmovaps [rsp+0x40], xmm5
000075aec0bd8cb7  vmovaps [rsp+0x50], xmm6
000075aec0bd8cbd  vmovaps [rsp+0x60], xmm7
000075aec0bd8cc3  vmovaps [rsp+0x70], xmm8
000075aec0bd8cc9  vmovaps [rsp+0x80], xmm9
000075aec0bd8cd2  vmovaps [rsp+0x90], xmm10
000075aec0bd8cdb  vmovaps [rsp+0xA0], xmm11
000075aec0bd8ce4  vmovaps [rsp+0xB0], xmm12
000075aec0bd8ced  vmovaps [rsp+0xC0], xmm13
000075aec0bd8cf6  vmovaps [rsp+0xD0], xmm14
000075aec0bd8cff  vmovaps [rsp+0xE0], xmm15
000075aec0bd8d08  sub rsp, 0x30
000075aec0bd8d0c  movaps [rsp], xmm4
000075aec0bd8d10  movaps [rsp+0x10], xmm2
000075aec0bd8d15  movaps [rsp+0x20], xmm9
000075aec0bd8d1b  lea rdi, [rsp]
000075aec0bd8d1f  mov esi, 0x00
000075aec0bd8d24  mov rax, 0x57F4B31E6530
000075aec0bd8d2e  call rax
000075aec0bd8d30  movaps xmm4, [rsp]
000075aec0bd8d34  add rsp, 0x30
000075aec0bd8d38  vmovaps xmm0, [rsp]
000075aec0bd8d3d  vmovaps xmm1, [rsp+0x10]
000075aec0bd8d43  vmovaps xmm2, [rsp+0x20]
000075aec0bd8d49  vmovaps xmm3, [rsp+0x30]
000075aec0bd8d4f  vmovaps xmm5, [rsp+0x40]
000075aec0bd8d55  vmovaps xmm6, [rsp+0x50]
000075aec0bd8d5b  vmovaps xmm7, [rsp+0x60]
000075aec0bd8d61  vmovaps xmm8, [rsp+0x70]
000075aec0bd8d67  vmovaps xmm9, [rsp+0x80]
000075aec0bd8d70  vmovaps xmm10, [rsp+0x90]
000075aec0bd8d79  vmovaps xmm11, [rsp+0xA0]
000075aec0bd8d82  vmovaps xmm12, [rsp+0xB0]
000075aec0bd8d8b  vmovaps xmm13, [rsp+0xC0]
000075aec0bd8d94  vmovaps xmm14, [rsp+0xD0]
000075aec0bd8d9d  vmovaps xmm15, [rsp+0xE0]
000075aec0bd8da6  add rsp, 0xF0
000075aec0bd8dad  pop r11
000075aec0bd8daf  pop r10
000075aec0bd8db1  pop r9
000075aec0bd8db3  pop r8
000075aec0bd8db5  pop rsi
000075aec0bd8db6  pop rdi
000075aec0bd8db7  pop rdx
000075aec0bd8db8  pop rcx
000075aec0bd8db9  pop rax
000075aec0bd8dba  add rsp, 0x08
000075aec0bd8dbe  jmp 0x000075AEC0BD616B
000075aec0bd8dc3  sub rsp, 0x08
000075aec0bd8dc7  push rax
000075aec0bd8dc8  push rcx
000075aec0bd8dc9  push rdx
000075aec0bd8dca  push rdi
000075aec0bd8dcb  push rsi
000075aec0bd8dcc  push r8
000075aec0bd8dce  push r9
000075aec0bd8dd0  push r10
000075aec0bd8dd2  push r11
000075aec0bd8dd4  sub rsp, 0xF0
000075aec0bd8ddb  vmovaps [rsp], xmm0
000075aec0bd8de0  vmovaps [rsp+0x10], xmm1
000075aec0bd8de6  vmovaps [rsp+0x20], xmm2
000075aec0bd8dec  vmovaps [rsp+0x30], xmm3
000075aec0bd8df2  vmovaps [rsp+0x40], xmm4
000075aec0bd8df8  vmovaps [rsp+0x50], xmm5
000075aec0bd8dfe  vmovaps [rsp+0x60], xmm6
000075aec0bd8e04  vmovaps [rsp+0x70], xmm7
000075aec0bd8e0a  vmovaps [rsp+0x80], xmm8
000075aec0bd8e13  vmovaps [rsp+0x90], xmm10
000075aec0bd8e1c  vmovaps [rsp+0xA0], xmm11
000075aec0bd8e25  vmovaps [rsp+0xB0], xmm12
000075aec0bd8e2e  vmovaps [rsp+0xC0], xmm13
000075aec0bd8e37  vmovaps [rsp+0xD0], xmm14
000075aec0bd8e40  vmovaps [rsp+0xE0], xmm15
000075aec0bd8e49  sub rsp, 0x30
000075aec0bd8e4d  movaps [rsp], xmm9
000075aec0bd8e52  movaps [rsp+0x10], xmm2
000075aec0bd8e57  movaps [rsp+0x20], xmm1
000075aec0bd8e5c  lea rdi, [rsp]
000075aec0bd8e60  mov esi, 0x00
000075aec0bd8e65  mov rax, 0x57F4B31E6530
000075aec0bd8e6f  call rax
000075aec0bd8e71  movaps xmm9, [rsp]
000075aec0bd8e76  add rsp, 0x30
000075aec0bd8e7a  vmovaps xmm0, [rsp]
000075aec0bd8e7f  vmovaps xmm1, [rsp+0x10]
000075aec0bd8e85  vmovaps xmm2, [rsp+0x20]
000075aec0bd8e8b  vmovaps xmm3, [rsp+0x30]
000075aec0bd8e91  vmovaps xmm4, [rsp+0x40]
000075aec0bd8e97  vmovaps xmm5, [rsp+0x50]
000075aec0bd8e9d  vmovaps xmm6, [rsp+0x60]
000075aec0bd8ea3  vmovaps xmm7, [rsp+0x70]
000075aec0bd8ea9  vmovaps xmm8, [rsp+0x80]
000075aec0bd8eb2  vmovaps xmm10, [rsp+0x90]
000075aec0bd8ebb  vmovaps xmm11, [rsp+0xA0]
000075aec0bd8ec4  vmovaps xmm12, [rsp+0xB0]
000075aec0bd8ecd  vmovaps xmm13, [rsp+0xC0]
000075aec0bd8ed6  vmovaps xmm14, [rsp+0xD0]
000075aec0bd8edf  vmovaps xmm15, [rsp+0xE0]
000075aec0bd8ee8  add rsp, 0xF0
000075aec0bd8eef  pop r11
000075aec0bd8ef1  pop r10
000075aec0bd8ef3  pop r9
000075aec0bd8ef5  pop r8
000075aec0bd8ef7  pop rsi
000075aec0bd8ef8  pop rdi
000075aec0bd8ef9  pop rdx
000075aec0bd8efa  pop rcx
000075aec0bd8efb  pop rax
000075aec0bd8efc  add rsp, 0x08
000075aec0bd8f00  jmp 0x000075AEC0BD61A1
000075aec0bd8f05  sub rsp, 0x08
000075aec0bd8f09  push rax
000075aec0bd8f0a  push rcx
000075aec0bd8f0b  push rdx
000075aec0bd8f0c  push rdi
000075aec0bd8f0d  push rsi
000075aec0bd8f0e  push r8
000075aec0bd8f10  push r9
000075aec0bd8f12  push r10
000075aec0bd8f14  push r11
000075aec0bd8f16  sub rsp, 0xF0
000075aec0bd8f1d  vmovaps [rsp], xmm0
000075aec0bd8f22  vmovaps [rsp+0x10], xmm2
000075aec0bd8f28  vmovaps [rsp+0x20], xmm3
000075aec0bd8f2e  vmovaps [rsp+0x30], xmm4
000075aec0bd8f34  vmovaps [rsp+0x40], xmm5
000075aec0bd8f3a  vmovaps [rsp+0x50], xmm6
000075aec0bd8f40  vmovaps [rsp+0x60], xmm7
000075aec0bd8f46  vmovaps [rsp+0x70], xmm8
000075aec0bd8f4c  vmovaps [rsp+0x80], xmm9
000075aec0bd8f55  vmovaps [rsp+0x90], xmm10
000075aec0bd8f5e  vmovaps [rsp+0xA0], xmm11
000075aec0bd8f67  vmovaps [rsp+0xB0], xmm12
000075aec0bd8f70  vmovaps [rsp+0xC0], xmm13
000075aec0bd8f79  vmovaps [rsp+0xD0], xmm14
000075aec0bd8f82  vmovaps [rsp+0xE0], xmm15
000075aec0bd8f8b  sub rsp, 0x30
000075aec0bd8f8f  movaps [rsp], xmm1
000075aec0bd8f93  movaps [rsp+0x10], xmm15
000075aec0bd8f99  movaps [rsp+0x20], xmm6
000075aec0bd8f9e  lea rdi, [rsp]
000075aec0bd8fa2  mov esi, 0x00
000075aec0bd8fa7  mov rax, 0x57F4B31E6530
000075aec0bd8fb1  call rax
000075aec0bd8fb3  movaps xmm1, [rsp]
000075aec0bd8fb7  add rsp, 0x30
000075aec0bd8fbb  vmovaps xmm0, [rsp]
000075aec0bd8fc0  vmovaps xmm2, [rsp+0x10]
000075aec0bd8fc6  vmovaps xmm3, [rsp+0x20]
000075aec0bd8fcc  vmovaps xmm4, [rsp+0x30]
000075aec0bd8fd2  vmovaps xmm5, [rsp+0x40]
000075aec0bd8fd8  vmovaps xmm6, [rsp+0x50]
000075aec0bd8fde  vmovaps xmm7, [rsp+0x60]
000075aec0bd8fe4  vmovaps xmm8, [rsp+0x70]
000075aec0bd8fea  vmovaps xmm9, [rsp+0x80]
000075aec0bd8ff3  vmovaps xmm10, [rsp+0x90]
000075aec0bd8ffc  vmovaps xmm11, [rsp+0xA0]
000075aec0bd9005  vmovaps xmm12, [rsp+0xB0]
000075aec0bd900e  vmovaps xmm13, [rsp+0xC0]
000075aec0bd9017  vmovaps xmm14, [rsp+0xD0]
000075aec0bd9020  vmovaps xmm15, [rsp+0xE0]
000075aec0bd9029  add rsp, 0xF0
000075aec0bd9030  pop r11
000075aec0bd9032  pop r10
000075aec0bd9034  pop r9
000075aec0bd9036  pop r8
000075aec0bd9038  pop rsi
000075aec0bd9039  pop rdi
000075aec0bd903a  pop rdx
000075aec0bd903b  pop rcx
000075aec0bd903c  pop rax
000075aec0bd903d  add rsp, 0x08
000075aec0bd9041  jmp 0x000075AEC0BD61C2
000075aec0bd9046  sub rsp, 0x08
000075aec0bd904a  push rax
000075aec0bd904b  push rcx
000075aec0bd904c  push rdx
000075aec0bd904d  push rdi
000075aec0bd904e  push rsi
000075aec0bd904f  push r8
000075aec0bd9051  push r9
000075aec0bd9053  push r10
000075aec0bd9055  push r11
000075aec0bd9057  sub rsp, 0xF0
000075aec0bd905e  vmovaps [rsp], xmm0
000075aec0bd9063  vmovaps [rsp+0x10], xmm1
000075aec0bd9069  vmovaps [rsp+0x20], xmm2
000075aec0bd906f  vmovaps [rsp+0x30], xmm3
000075aec0bd9075  vmovaps [rsp+0x40], xmm4
000075aec0bd907b  vmovaps [rsp+0x50], xmm5
000075aec0bd9081  vmovaps [rsp+0x60], xmm6
000075aec0bd9087  vmovaps [rsp+0x70], xmm7
000075aec0bd908d  vmovaps [rsp+0x80], xmm8
000075aec0bd9096  vmovaps [rsp+0x90], xmm9
000075aec0bd909f  vmovaps [rsp+0xA0], xmm10
000075aec0bd90a8  vmovaps [rsp+0xB0], xmm11
000075aec0bd90b1  vmovaps [rsp+0xC0], xmm12
000075aec0bd90ba  vmovaps [rsp+0xD0], xmm13
000075aec0bd90c3  vmovaps [rsp+0xE0], xmm14
000075aec0bd90cc  sub rsp, 0x30
000075aec0bd90d0  movaps [rsp], xmm15
000075aec0bd90d5  movaps [rsp+0x10], xmm5
000075aec0bd90da  movaps [rsp+0x20], xmm3
000075aec0bd90df  lea rdi, [rsp]
000075aec0bd90e3  mov esi, 0x00
000075aec0bd90e8  mov rax, 0x57F4B31E6530
000075aec0bd90f2  call rax
000075aec0bd90f4  movaps xmm15, [rsp]
000075aec0bd90f9  add rsp, 0x30
000075aec0bd90fd  vmovaps xmm0, [rsp]
000075aec0bd9102  vmovaps xmm1, [rsp+0x10]
000075aec0bd9108  vmovaps xmm2, [rsp+0x20]
000075aec0bd910e  vmovaps xmm3, [rsp+0x30]
000075aec0bd9114  vmovaps xmm4, [rsp+0x40]
000075aec0bd911a  vmovaps xmm5, [rsp+0x50]
000075aec0bd9120  vmovaps xmm6, [rsp+0x60]
000075aec0bd9126  vmovaps xmm7, [rsp+0x70]
000075aec0bd912c  vmovaps xmm8, [rsp+0x80]
000075aec0bd9135  vmovaps xmm9, [rsp+0x90]
000075aec0bd913e  vmovaps xmm10, [rsp+0xA0]
000075aec0bd9147  vmovaps xmm11, [rsp+0xB0]
000075aec0bd9150  vmovaps xmm12, [rsp+0xC0]
000075aec0bd9159  vmovaps xmm13, [rsp+0xD0]
000075aec0bd9162  vmovaps xmm14, [rsp+0xE0]
000075aec0bd916b  add rsp, 0xF0
000075aec0bd9172  pop r11
000075aec0bd9174  pop r10
000075aec0bd9176  pop r9
000075aec0bd9178  pop r8
000075aec0bd917a  pop rsi
000075aec0bd917b  pop rdi
000075aec0bd917c  pop rdx
000075aec0bd917d  pop rcx
000075aec0bd917e  pop rax
000075aec0bd917f  add rsp, 0x08
000075aec0bd9183  jmp 0x000075AEC0BD61DC
000075aec0bd9188  sub rsp, 0x08
000075aec0bd918c  push rax
000075aec0bd918d  push rcx
000075aec0bd918e  push rdx
000075aec0bd918f  push rdi
000075aec0bd9190  push rsi
000075aec0bd9191  push r8
000075aec0bd9193  push r9
000075aec0bd9195  push r10
000075aec0bd9197  push r11
000075aec0bd9199  sub rsp, 0xF0
000075aec0bd91a0  vmovaps [rsp], xmm0
000075aec0bd91a5  vmovaps [rsp+0x10], xmm1
000075aec0bd91ab  vmovaps [rsp+0x20], xmm2
000075aec0bd91b1  vmovaps [rsp+0x30], xmm3
000075aec0bd91b7  vmovaps [rsp+0x40], xmm4
000075aec0bd91bd  vmovaps [rsp+0x50], xmm6
000075aec0bd91c3  vmovaps [rsp+0x60], xmm7
000075aec0bd91c9  vmovaps [rsp+0x70], xmm8
000075aec0bd91cf  vmovaps [rsp+0x80], xmm9
000075aec0bd91d8  vmovaps [rsp+0x90], xmm10
000075aec0bd91e1  vmovaps [rsp+0xA0], xmm11
000075aec0bd91ea  vmovaps [rsp+0xB0], xmm12
000075aec0bd91f3  vmovaps [rsp+0xC0], xmm13
000075aec0bd91fc  vmovaps [rsp+0xD0], xmm14
000075aec0bd9205  vmovaps [rsp+0xE0], xmm15
000075aec0bd920e  sub rsp, 0x30
000075aec0bd9212  movaps [rsp], xmm5
000075aec0bd9216  movaps [rsp+0x10], xmm8
000075aec0bd921c  movaps [rsp+0x20], xmm6
000075aec0bd9221  lea rdi, [rsp]
000075aec0bd9225  mov esi, 0x00
000075aec0bd922a  mov rax, 0x57F4B31E6530
000075aec0bd9234  call rax
000075aec0bd9236  movaps xmm5, [rsp]
000075aec0bd923a  add rsp, 0x30
000075aec0bd923e  vmovaps xmm0, [rsp]
000075aec0bd9243  vmovaps xmm1, [rsp+0x10]
000075aec0bd9249  vmovaps xmm2, [rsp+0x20]
000075aec0bd924f  vmovaps xmm3, [rsp+0x30]
000075aec0bd9255  vmovaps xmm4, [rsp+0x40]
000075aec0bd925b  vmovaps xmm6, [rsp+0x50]
000075aec0bd9261  vmovaps xmm7, [rsp+0x60]
000075aec0bd9267  vmovaps xmm8, [rsp+0x70]
000075aec0bd926d  vmovaps xmm9, [rsp+0x80]
000075aec0bd9276  vmovaps xmm10, [rsp+0x90]
000075aec0bd927f  vmovaps xmm11, [rsp+0xA0]
000075aec0bd9288  vmovaps xmm12, [rsp+0xB0]
000075aec0bd9291  vmovaps xmm13, [rsp+0xC0]
000075aec0bd929a  vmovaps xmm14, [rsp+0xD0]
000075aec0bd92a3  vmovaps xmm15, [rsp+0xE0]
000075aec0bd92ac  add rsp, 0xF0
000075aec0bd92b3  pop r11
000075aec0bd92b5  pop r10
000075aec0bd92b7  pop r9
000075aec0bd92b9  pop r8
000075aec0bd92bb  pop rsi
000075aec0bd92bc  pop rdi
000075aec0bd92bd  pop rdx
000075aec0bd92be  pop rcx
000075aec0bd92bf  pop rax
000075aec0bd92c0  add rsp, 0x08
000075aec0bd92c4  jmp 0x000075AEC0BD6200
000075aec0bd92c9  sub rsp, 0x08
000075aec0bd92cd  push rax
000075aec0bd92ce  push rcx
000075aec0bd92cf  push rdx
000075aec0bd92d0  push rdi
000075aec0bd92d1  push rsi
000075aec0bd92d2  push r8
000075aec0bd92d4  push r9
000075aec0bd92d6  push r10
000075aec0bd92d8  push r11
000075aec0bd92da  sub rsp, 0xF0
000075aec0bd92e1  vmovaps [rsp], xmm0
000075aec0bd92e6  vmovaps [rsp+0x10], xmm1
000075aec0bd92ec  vmovaps [rsp+0x20], xmm2
000075aec0bd92f2  vmovaps [rsp+0x30], xmm3
000075aec0bd92f8  vmovaps [rsp+0x40], xmm4
000075aec0bd92fe  vmovaps [rsp+0x50], xmm5
000075aec0bd9304  vmovaps [rsp+0x60], xmm7
000075aec0bd930a  vmovaps [rsp+0x70], xmm8
000075aec0bd9310  vmovaps [rsp+0x80], xmm9
000075aec0bd9319  vmovaps [rsp+0x90], xmm10
000075aec0bd9322  vmovaps [rsp+0xA0], xmm11
000075aec0bd932b  vmovaps [rsp+0xB0], xmm12
000075aec0bd9334  vmovaps [rsp+0xC0], xmm13
000075aec0bd933d  vmovaps [rsp+0xD0], xmm14
000075aec0bd9346  vmovaps [rsp+0xE0], xmm15
000075aec0bd934f  sub rsp, 0x30
000075aec0bd9353  movaps [rsp], xmm6
000075aec0bd9357  movaps [rsp+0x10], xmm10
000075aec0bd935d  movaps [rsp+0x20], xmm8
000075aec0bd9363  lea rdi, [rsp]
000075aec0bd9367  mov esi, 0x00
000075aec0bd936c  mov rax, 0x57F4B31E6530
000075aec0bd9376  call rax
000075aec0bd9378  movaps xmm6, [rsp]
000075aec0bd937c  add rsp, 0x30
000075aec0bd9380  vmovaps xmm0, [rsp]
000075aec0bd9385  vmovaps xmm1, [rsp+0x10]
000075aec0bd938b  vmovaps xmm2, [rsp+0x20]
000075aec0bd9391  vmovaps xmm3, [rsp+0x30]
000075aec0bd9397  vmovaps xmm4, [rsp+0x40]
000075aec0bd939d  vmovaps xmm5, [rsp+0x50]
000075aec0bd93a3  vmovaps xmm7, [rsp+0x60]
000075aec0bd93a9  vmovaps xmm8, [rsp+0x70]
000075aec0bd93af  vmovaps xmm9, [rsp+0x80]
000075aec0bd93b8  vmovaps xmm10, [rsp+0x90]
000075aec0bd93c1  vmovaps xmm11, [rsp+0xA0]
000075aec0bd93ca  vmovaps xmm12, [rsp+0xB0]
000075aec0bd93d3  vmovaps xmm13, [rsp+0xC0]
000075aec0bd93dc  vmovaps xmm14, [rsp+0xD0]
000075aec0bd93e5  vmovaps xmm15, [rsp+0xE0]
000075aec0bd93ee  add rsp, 0xF0
000075aec0bd93f5  pop r11
000075aec0bd93f7  pop r10
000075aec0bd93f9  pop r9
000075aec0bd93fb  pop r8
000075aec0bd93fd  pop rsi
000075aec0bd93fe  pop rdi
000075aec0bd93ff  pop rdx
000075aec0bd9400  pop rcx
000075aec0bd9401  pop rax
000075aec0bd9402  add rsp, 0x08
000075aec0bd9406  jmp 0x000075AEC0BD6225
000075aec0bd940b  sub rsp, 0x08
000075aec0bd940f  push rax
000075aec0bd9410  push rcx
000075aec0bd9411  push rdx
000075aec0bd9412  push rdi
000075aec0bd9413  push rsi
000075aec0bd9414  push r8
000075aec0bd9416  push r9
000075aec0bd9418  push r10
000075aec0bd941a  push r11
000075aec0bd941c  sub rsp, 0xF0
000075aec0bd9423  vmovaps [rsp], xmm0
000075aec0bd9428  vmovaps [rsp+0x10], xmm1
000075aec0bd942e  vmovaps [rsp+0x20], xmm2
000075aec0bd9434  vmovaps [rsp+0x30], xmm3
000075aec0bd943a  vmovaps [rsp+0x40], xmm4
000075aec0bd9440  vmovaps [rsp+0x50], xmm5
000075aec0bd9446  vmovaps [rsp+0x60], xmm6
000075aec0bd944c  vmovaps [rsp+0x70], xmm7
000075aec0bd9452  vmovaps [rsp+0x80], xmm8
000075aec0bd945b  vmovaps [rsp+0x90], xmm9
000075aec0bd9464  vmovaps [rsp+0xA0], xmm11
000075aec0bd946d  vmovaps [rsp+0xB0], xmm12
000075aec0bd9476  vmovaps [rsp+0xC0], xmm13
000075aec0bd947f  vmovaps [rsp+0xD0], xmm14
000075aec0bd9488  vmovaps [rsp+0xE0], xmm15
000075aec0bd9491  sub rsp, 0x30
000075aec0bd9495  movaps [rsp], xmm10
000075aec0bd949a  movaps [rsp+0x10], xmm8
000075aec0bd94a0  movaps [rsp+0x20], xmm14
000075aec0bd94a6  lea rdi, [rsp]
000075aec0bd94aa  mov esi, 0x00
000075aec0bd94af  mov rax, 0x57F4B31E6530
000075aec0bd94b9  call rax
000075aec0bd94bb  movaps xmm10, [rsp]
000075aec0bd94c0  add rsp, 0x30
000075aec0bd94c4  vmovaps xmm0, [rsp]
000075aec0bd94c9  vmovaps xmm1, [rsp+0x10]
000075aec0bd94cf  vmovaps xmm2, [rsp+0x20]
000075aec0bd94d5  vmovaps xmm3, [rsp+0x30]
000075aec0bd94db  vmovaps xmm4, [rsp+0x40]
000075aec0bd94e1  vmovaps xmm5, [rsp+0x50]
000075aec0bd94e7  vmovaps xmm6, [rsp+0x60]
000075aec0bd94ed  vmovaps xmm7, [rsp+0x70]
000075aec0bd94f3  vmovaps xmm8, [rsp+0x80]
000075aec0bd94fc  vmovaps xmm9, [rsp+0x90]
000075aec0bd9505  vmovaps xmm11, [rsp+0xA0]
000075aec0bd950e  vmovaps xmm12, [rsp+0xB0]
000075aec0bd9517  vmovaps xmm13, [rsp+0xC0]
000075aec0bd9520  vmovaps xmm14, [rsp+0xD0]
000075aec0bd9529  vmovaps xmm15, [rsp+0xE0]
000075aec0bd9532  add rsp, 0xF0
000075aec0bd9539  pop r11
000075aec0bd953b  pop r10
000075aec0bd953d  pop r9
000075aec0bd953f  pop r8
000075aec0bd9541  pop rsi
000075aec0bd9542  pop rdi
000075aec0bd9543  pop rdx
000075aec0bd9544  pop rcx
000075aec0bd9545  pop rax
000075aec0bd9546  add rsp, 0x08
000075aec0bd954a  jmp 0x000075AEC0BD6245
000075aec0bd954f  sub rsp, 0x08
000075aec0bd9553  push rax
000075aec0bd9554  push rcx
000075aec0bd9555  push rdx
000075aec0bd9556  push rdi
000075aec0bd9557  push rsi
000075aec0bd9558  push r8
000075aec0bd955a  push r9
000075aec0bd955c  push r10
000075aec0bd955e  push r11
000075aec0bd9560  sub rsp, 0xF0
000075aec0bd9567  vmovaps [rsp], xmm0
000075aec0bd956c  vmovaps [rsp+0x10], xmm1
000075aec0bd9572  vmovaps [rsp+0x20], xmm2
000075aec0bd9578  vmovaps [rsp+0x30], xmm3
000075aec0bd957e  vmovaps [rsp+0x40], xmm4
000075aec0bd9584  vmovaps [rsp+0x50], xmm5
000075aec0bd958a  vmovaps [rsp+0x60], xmm6
000075aec0bd9590  vmovaps [rsp+0x70], xmm7
000075aec0bd9596  vmovaps [rsp+0x80], xmm8
000075aec0bd959f  vmovaps [rsp+0x90], xmm9
000075aec0bd95a8  vmovaps [rsp+0xA0], xmm10
000075aec0bd95b1  vmovaps [rsp+0xB0], xmm11
000075aec0bd95ba  vmovaps [rsp+0xC0], xmm12
000075aec0bd95c3  vmovaps [rsp+0xD0], xmm13
000075aec0bd95cc  vmovaps [rsp+0xE0], xmm15
000075aec0bd95d5  sub rsp, 0x30
000075aec0bd95d9  movaps [rsp], xmm14
000075aec0bd95de  movaps [rsp+0x10], xmm8
000075aec0bd95e4  movaps [rsp+0x20], xmm4
000075aec0bd95e9  lea rdi, [rsp]
000075aec0bd95ed  mov esi, 0x00
000075aec0bd95f2  mov rax, 0x57F4B31E6530
000075aec0bd95fc  call rax
000075aec0bd95fe  movaps xmm14, [rsp]
000075aec0bd9603  add rsp, 0x30
000075aec0bd9607  vmovaps xmm0, [rsp]
000075aec0bd960c  vmovaps xmm1, [rsp+0x10]
000075aec0bd9612  vmovaps xmm2, [rsp+0x20]
000075aec0bd9618  vmovaps xmm3, [rsp+0x30]
000075aec0bd961e  vmovaps xmm4, [rsp+0x40]
000075aec0bd9624  vmovaps xmm5, [rsp+0x50]
000075aec0bd962a  vmovaps xmm6, [rsp+0x60]
000075aec0bd9630  vmovaps xmm7, [rsp+0x70]
000075aec0bd9636  vmovaps xmm8, [rsp+0x80]
000075aec0bd963f  vmovaps xmm9, [rsp+0x90]
000075aec0bd9648  vmovaps xmm10, [rsp+0xA0]
000075aec0bd9651  vmovaps xmm11, [rsp+0xB0]
000075aec0bd965a  vmovaps xmm12, [rsp+0xC0]
000075aec0bd9663  vmovaps xmm13, [rsp+0xD0]
000075aec0bd966c  vmovaps xmm15, [rsp+0xE0]
000075aec0bd9675  add rsp, 0xF0
000075aec0bd967c  pop r11
000075aec0bd967e  pop r10
000075aec0bd9680  pop r9
000075aec0bd9682  pop r8
000075aec0bd9684  pop rsi
000075aec0bd9685  pop rdi
000075aec0bd9686  pop rdx
000075aec0bd9687  pop rcx
000075aec0bd9688  pop rax
000075aec0bd9689  add rsp, 0x08
000075aec0bd968d  jmp 0x000075AEC0BD6265
000075aec0bd9692  sub rsp, 0x08
000075aec0bd9696  push rax
000075aec0bd9697  push rcx
000075aec0bd9698  push rdx
000075aec0bd9699  push rdi
000075aec0bd969a  push rsi
000075aec0bd969b  push r8
000075aec0bd969d  push r9
000075aec0bd969f  push r10
000075aec0bd96a1  push r11
000075aec0bd96a3  sub rsp, 0xF0
000075aec0bd96aa  vmovaps [rsp], xmm0
000075aec0bd96af  vmovaps [rsp+0x10], xmm1
000075aec0bd96b5  vmovaps [rsp+0x20], xmm2
000075aec0bd96bb  vmovaps [rsp+0x30], xmm3
000075aec0bd96c1  vmovaps [rsp+0x40], xmm5
000075aec0bd96c7  vmovaps [rsp+0x50], xmm6
000075aec0bd96cd  vmovaps [rsp+0x60], xmm7
000075aec0bd96d3  vmovaps [rsp+0x70], xmm8
000075aec0bd96d9  vmovaps [rsp+0x80], xmm9
000075aec0bd96e2  vmovaps [rsp+0x90], xmm10
000075aec0bd96eb  vmovaps [rsp+0xA0], xmm11
000075aec0bd96f4  vmovaps [rsp+0xB0], xmm12
000075aec0bd96fd  vmovaps [rsp+0xC0], xmm13
000075aec0bd9706  vmovaps [rsp+0xD0], xmm14
000075aec0bd970f  vmovaps [rsp+0xE0], xmm15
000075aec0bd9718  sub rsp, 0x30
000075aec0bd971c  movaps [rsp], xmm4
000075aec0bd9720  movaps [rsp+0x10], xmm13
000075aec0bd9726  movaps [rsp+0x20], xmm8
000075aec0bd972c  lea rdi, [rsp]
000075aec0bd9730  mov esi, 0x00
000075aec0bd9735  mov rax, 0x57F4B31E6530
000075aec0bd973f  call rax
000075aec0bd9741  movaps xmm4, [rsp]
000075aec0bd9745  add rsp, 0x30
000075aec0bd9749  vmovaps xmm0, [rsp]
000075aec0bd974e  vmovaps xmm1, [rsp+0x10]
000075aec0bd9754  vmovaps xmm2, [rsp+0x20]
000075aec0bd975a  vmovaps xmm3, [rsp+0x30]
000075aec0bd9760  vmovaps xmm5, [rsp+0x40]
000075aec0bd9766  vmovaps xmm6, [rsp+0x50]
000075aec0bd976c  vmovaps xmm7, [rsp+0x60]
000075aec0bd9772  vmovaps xmm8, [rsp+0x70]
000075aec0bd9778  vmovaps xmm9, [rsp+0x80]
000075aec0bd9781  vmovaps xmm10, [rsp+0x90]
000075aec0bd978a  vmovaps xmm11, [rsp+0xA0]
000075aec0bd9793  vmovaps xmm12, [rsp+0xB0]
000075aec0bd979c  vmovaps xmm13, [rsp+0xC0]
000075aec0bd97a5  vmovaps xmm14, [rsp+0xD0]
000075aec0bd97ae  vmovaps xmm15, [rsp+0xE0]
000075aec0bd97b7  add rsp, 0xF0
000075aec0bd97be  pop r11
000075aec0bd97c0  pop r10
000075aec0bd97c2  pop r9
000075aec0bd97c4  pop r8
000075aec0bd97c6  pop rsi
000075aec0bd97c7  pop rdi
000075aec0bd97c8  pop rdx
000075aec0bd97c9  pop rcx
000075aec0bd97ca  pop rax
000075aec0bd97cb  add rsp, 0x08
000075aec0bd97cf  jmp 0x000075AEC0BD628A
000075aec0bd97d4  sub rsp, 0x08
000075aec0bd97d8  push rax
000075aec0bd97d9  push rcx
000075aec0bd97da  push rdx
000075aec0bd97db  push rdi
000075aec0bd97dc  push rsi
000075aec0bd97dd  push r8
000075aec0bd97df  push r9
000075aec0bd97e1  push r10
000075aec0bd97e3  push r11
000075aec0bd97e5  sub rsp, 0xF0
000075aec0bd97ec  vmovaps [rsp], xmm0
000075aec0bd97f1  vmovaps [rsp+0x10], xmm1
000075aec0bd97f7  vmovaps [rsp+0x20], xmm2
000075aec0bd97fd  vmovaps [rsp+0x30], xmm3
000075aec0bd9803  vmovaps [rsp+0x40], xmm4
000075aec0bd9809  vmovaps [rsp+0x50], xmm5
000075aec0bd980f  vmovaps [rsp+0x60], xmm6
000075aec0bd9815  vmovaps [rsp+0x70], xmm7
000075aec0bd981b  vmovaps [rsp+0x80], xmm8
000075aec0bd9824  vmovaps [rsp+0x90], xmm9
000075aec0bd982d  vmovaps [rsp+0xA0], xmm10
000075aec0bd9836  vmovaps [rsp+0xB0], xmm11
000075aec0bd983f  vmovaps [rsp+0xC0], xmm12
000075aec0bd9848  vmovaps [rsp+0xD0], xmm14
000075aec0bd9851  vmovaps [rsp+0xE0], xmm15
000075aec0bd985a  sub rsp, 0x30
000075aec0bd985e  movaps [rsp], xmm13
000075aec0bd9863  movaps [rsp+0x10], xmm15
000075aec0bd9869  movaps [rsp+0x20], xmm9
000075aec0bd986f  lea rdi, [rsp]
000075aec0bd9873  mov esi, 0x00
000075aec0bd9878  mov rax, 0x57F4B31E6530
000075aec0bd9882  call rax
000075aec0bd9884  movaps xmm13, [rsp]
000075aec0bd9889  add rsp, 0x30
000075aec0bd988d  vmovaps xmm0, [rsp]
000075aec0bd9892  vmovaps xmm1, [rsp+0x10]
000075aec0bd9898  vmovaps xmm2, [rsp+0x20]
000075aec0bd989e  vmovaps xmm3, [rsp+0x30]
000075aec0bd98a4  vmovaps xmm4, [rsp+0x40]
000075aec0bd98aa  vmovaps xmm5, [rsp+0x50]
000075aec0bd98b0  vmovaps xmm6, [rsp+0x60]
000075aec0bd98b6  vmovaps xmm7, [rsp+0x70]
000075aec0bd98bc  vmovaps xmm8, [rsp+0x80]
000075aec0bd98c5  vmovaps xmm9, [rsp+0x90]
000075aec0bd98ce  vmovaps xmm10, [rsp+0xA0]
000075aec0bd98d7  vmovaps xmm11, [rsp+0xB0]
000075aec0bd98e0  vmovaps xmm12, [rsp+0xC0]
000075aec0bd98e9  vmovaps xmm14, [rsp+0xD0]
000075aec0bd98f2  vmovaps xmm15, [rsp+0xE0]
000075aec0bd98fb  add rsp, 0xF0
000075aec0bd9902  pop r11
000075aec0bd9904  pop r10
000075aec0bd9906  pop r9
000075aec0bd9908  pop r8
000075aec0bd990a  pop rsi
000075aec0bd990b  pop rdi
000075aec0bd990c  pop rdx
000075aec0bd990d  pop rcx
000075aec0bd990e  pop rax
000075aec0bd990f  add rsp, 0x08
000075aec0bd9913  jmp 0x000075AEC0BD62A5
000075aec0bd9918  sub rsp, 0x08
000075aec0bd991c  push rax
000075aec0bd991d  push rcx
000075aec0bd991e  push rdx
000075aec0bd991f  push rdi
000075aec0bd9920  push rsi
000075aec0bd9921  push r8
000075aec0bd9923  push r9
000075aec0bd9925  push r10
000075aec0bd9927  push r11
000075aec0bd9929  sub rsp, 0xF0
000075aec0bd9930  vmovaps [rsp], xmm0
000075aec0bd9935  vmovaps [rsp+0x10], xmm1
000075aec0bd993b  vmovaps [rsp+0x20], xmm2
000075aec0bd9941  vmovaps [rsp+0x30], xmm3
000075aec0bd9947  vmovaps [rsp+0x40], xmm4
000075aec0bd994d  vmovaps [rsp+0x50], xmm5
000075aec0bd9953  vmovaps [rsp+0x60], xmm6
000075aec0bd9959  vmovaps [rsp+0x70], xmm7
000075aec0bd995f  vmovaps [rsp+0x80], xmm8
000075aec0bd9968  vmovaps [rsp+0x90], xmm9
000075aec0bd9971  vmovaps [rsp+0xA0], xmm10
000075aec0bd997a  vmovaps [rsp+0xB0], xmm11
000075aec0bd9983  vmovaps [rsp+0xC0], xmm12
000075aec0bd998c  vmovaps [rsp+0xD0], xmm13
000075aec0bd9995  vmovaps [rsp+0xE0], xmm14
000075aec0bd999e  sub rsp, 0x30
000075aec0bd99a2  movaps [rsp], xmm15
000075aec0bd99a7  movaps [rsp+0x10], xmm1
000075aec0bd99ac  movaps [rsp+0x20], xmm5
000075aec0bd99b1  lea rdi, [rsp]
000075aec0bd99b5  mov esi, 0x00
000075aec0bd99ba  mov rax, 0x57F4B31E6530
000075aec0bd99c4  call rax
000075aec0bd99c6  movaps xmm15, [rsp]
000075aec0bd99cb  add rsp, 0x30
000075aec0bd99cf  vmovaps xmm0, [rsp]
000075aec0bd99d4  vmovaps xmm1, [rsp+0x10]
000075aec0bd99da  vmovaps xmm2, [rsp+0x20]
000075aec0bd99e0  vmovaps xmm3, [rsp+0x30]
000075aec0bd99e6  vmovaps xmm4, [rsp+0x40]
000075aec0bd99ec  vmovaps xmm5, [rsp+0x50]
000075aec0bd99f2  vmovaps xmm6, [rsp+0x60]
000075aec0bd99f8  vmovaps xmm7, [rsp+0x70]
000075aec0bd99fe  vmovaps xmm8, [rsp+0x80]
000075aec0bd9a07  vmovaps xmm9, [rsp+0x90]
000075aec0bd9a10  vmovaps xmm10, [rsp+0xA0]
000075aec0bd9a19  vmovaps xmm11, [rsp+0xB0]
000075aec0bd9a22  vmovaps xmm12, [rsp+0xC0]
000075aec0bd9a2b  vmovaps xmm13, [rsp+0xD0]
000075aec0bd9a34  vmovaps xmm14, [rsp+0xE0]
000075aec0bd9a3d  add rsp, 0xF0
000075aec0bd9a44  pop r11
000075aec0bd9a46  pop r10
000075aec0bd9a48  pop r9
000075aec0bd9a4a  pop r8
000075aec0bd9a4c  pop rsi
000075aec0bd9a4d  pop rdi
000075aec0bd9a4e  pop rdx
000075aec0bd9a4f  pop rcx
000075aec0bd9a50  pop rax
000075aec0bd9a51  add rsp, 0x08
000075aec0bd9a55  jmp 0x000075AEC0BD62C0
000075aec0bd9a5a  call 0x000075AEC0AD64F0
000075aec0bd9a5f  jmp 0x000075AEC0BD631B
000075aec0bd9a64  sub rsp, 0x08
000075aec0bd9a68  push rax
000075aec0bd9a69  push rcx
000075aec0bd9a6a  push rdx
000075aec0bd9a6b  push rdi
000075aec0bd9a6c  push rsi
000075aec0bd9a6d  push r8
000075aec0bd9a6f  push r9
000075aec0bd9a71  push r10
000075aec0bd9a73  push r11
000075aec0bd9a75  sub rsp, 0xF0
000075aec0bd9a7c  vmovaps [rsp], xmm0
000075aec0bd9a81  vmovaps [rsp+0x10], xmm1
000075aec0bd9a87  vmovaps [rsp+0x20], xmm2
000075aec0bd9a8d  vmovaps [rsp+0x30], xmm3
000075aec0bd9a93  vmovaps [rsp+0x40], xmm4
000075aec0bd9a99  vmovaps [rsp+0x50], xmm5
000075aec0bd9a9f  vmovaps [rsp+0x60], xmm6
000075aec0bd9aa5  vmovaps [rsp+0x70], xmm7
000075aec0bd9aab  vmovaps [rsp+0x80], xmm8
000075aec0bd9ab4  vmovaps [rsp+0x90], xmm10
000075aec0bd9abd  vmovaps [rsp+0xA0], xmm11
000075aec0bd9ac6  vmovaps [rsp+0xB0], xmm12
000075aec0bd9acf  vmovaps [rsp+0xC0], xmm13
000075aec0bd9ad8  vmovaps [rsp+0xD0], xmm14
000075aec0bd9ae1  vmovaps [rsp+0xE0], xmm15
000075aec0bd9aea  sub rsp, 0x30
000075aec0bd9aee  movaps [rsp], xmm9
000075aec0bd9af3  movaps [rsp+0x10], xmm8
000075aec0bd9af9  movaps [rsp+0x20], xmm11
000075aec0bd9aff  lea rdi, [rsp]
000075aec0bd9b03  mov esi, 0x00
000075aec0bd9b08  mov rax, 0x57F4B31E6530
000075aec0bd9b12  call rax
000075aec0bd9b14  movaps xmm9, [rsp]
000075aec0bd9b19  add rsp, 0x30
000075aec0bd9b1d  vmovaps xmm0, [rsp]
000075aec0bd9b22  vmovaps xmm1, [rsp+0x10]
000075aec0bd9b28  vmovaps xmm2, [rsp+0x20]
000075aec0bd9b2e  vmovaps xmm3, [rsp+0x30]
000075aec0bd9b34  vmovaps xmm4, [rsp+0x40]
000075aec0bd9b3a  vmovaps xmm5, [rsp+0x50]
000075aec0bd9b40  vmovaps xmm6, [rsp+0x60]
000075aec0bd9b46  vmovaps xmm7, [rsp+0x70]
000075aec0bd9b4c  vmovaps xmm8, [rsp+0x80]
000075aec0bd9b55  vmovaps xmm10, [rsp+0x90]
000075aec0bd9b5e  vmovaps xmm11, [rsp+0xA0]
000075aec0bd9b67  vmovaps xmm12, [rsp+0xB0]
000075aec0bd9b70  vmovaps xmm13, [rsp+0xC0]
000075aec0bd9b79  vmovaps xmm14, [rsp+0xD0]
000075aec0bd9b82  vmovaps xmm15, [rsp+0xE0]
000075aec0bd9b8b  add rsp, 0xF0
000075aec0bd9b92  pop r11
000075aec0bd9b94  pop r10
000075aec0bd9b96  pop r9
000075aec0bd9b98  pop r8
000075aec0bd9b9a  pop rsi
000075aec0bd9b9b  pop rdi
000075aec0bd9b9c  pop rdx
000075aec0bd9b9d  pop rcx
000075aec0bd9b9e  pop rax
000075aec0bd9b9f  add rsp, 0x08
000075aec0bd9ba3  jmp 0x000075AEC0BD6352
000075aec0bd9ba8  sub rsp, 0x08
000075aec0bd9bac  push rax
000075aec0bd9bad  push rcx
000075aec0bd9bae  push rdx
000075aec0bd9baf  push rdi
000075aec0bd9bb0  push rsi
000075aec0bd9bb1  push r8
000075aec0bd9bb3  push r9
000075aec0bd9bb5  push r10
000075aec0bd9bb7  push r11
000075aec0bd9bb9  sub rsp, 0xF0
000075aec0bd9bc0  vmovaps [rsp], xmm0
000075aec0bd9bc5  vmovaps [rsp+0x10], xmm1
000075aec0bd9bcb  vmovaps [rsp+0x20], xmm2
000075aec0bd9bd1  vmovaps [rsp+0x30], xmm3
000075aec0bd9bd7  vmovaps [rsp+0x40], xmm4
000075aec0bd9bdd  vmovaps [rsp+0x50], xmm5
000075aec0bd9be3  vmovaps [rsp+0x60], xmm6
000075aec0bd9be9  vmovaps [rsp+0x70], xmm7
000075aec0bd9bef  vmovaps [rsp+0x80], xmm8
000075aec0bd9bf8  vmovaps [rsp+0x90], xmm9
000075aec0bd9c01  vmovaps [rsp+0xA0], xmm10
000075aec0bd9c0a  vmovaps [rsp+0xB0], xmm12
000075aec0bd9c13  vmovaps [rsp+0xC0], xmm13
000075aec0bd9c1c  vmovaps [rsp+0xD0], xmm14
000075aec0bd9c25  vmovaps [rsp+0xE0], xmm15
000075aec0bd9c2e  sub rsp, 0x30
000075aec0bd9c32  movaps [rsp], xmm11
000075aec0bd9c37  movaps [rsp+0x10], xmm10
000075aec0bd9c3d  movaps [rsp+0x20], xmm6
000075aec0bd9c42  lea rdi, [rsp]
000075aec0bd9c46  mov esi, 0x00
000075aec0bd9c4b  mov rax, 0x57F4B31E6530
000075aec0bd9c55  call rax
000075aec0bd9c57  movaps xmm11, [rsp]
000075aec0bd9c5c  add rsp, 0x30
000075aec0bd9c60  vmovaps xmm0, [rsp]
000075aec0bd9c65  vmovaps xmm1, [rsp+0x10]
000075aec0bd9c6b  vmovaps xmm2, [rsp+0x20]
000075aec0bd9c71  vmovaps xmm3, [rsp+0x30]
000075aec0bd9c77  vmovaps xmm4, [rsp+0x40]
000075aec0bd9c7d  vmovaps xmm5, [rsp+0x50]
000075aec0bd9c83  vmovaps xmm6, [rsp+0x60]
000075aec0bd9c89  vmovaps xmm7, [rsp+0x70]
000075aec0bd9c8f  vmovaps xmm8, [rsp+0x80]
000075aec0bd9c98  vmovaps xmm9, [rsp+0x90]
000075aec0bd9ca1  vmovaps xmm10, [rsp+0xA0]
000075aec0bd9caa  vmovaps xmm12, [rsp+0xB0]
000075aec0bd9cb3  vmovaps xmm13, [rsp+0xC0]
000075aec0bd9cbc  vmovaps xmm14, [rsp+0xD0]
000075aec0bd9cc5  vmovaps xmm15, [rsp+0xE0]
000075aec0bd9cce  add rsp, 0xF0
000075aec0bd9cd5  pop r11
000075aec0bd9cd7  pop r10
000075aec0bd9cd9  pop r9
000075aec0bd9cdb  pop r8
000075aec0bd9cdd  pop rsi
000075aec0bd9cde  pop rdi
000075aec0bd9cdf  pop rdx
000075aec0bd9ce0  pop rcx
000075aec0bd9ce1  pop rax
000075aec0bd9ce2  add rsp, 0x08
000075aec0bd9ce6  jmp 0x000075AEC0BD636D
000075aec0bd9ceb  sub rsp, 0x08
000075aec0bd9cef  push rax
000075aec0bd9cf0  push rcx
000075aec0bd9cf1  push rdx
000075aec0bd9cf2  push rdi
000075aec0bd9cf3  push rsi
000075aec0bd9cf4  push r8
000075aec0bd9cf6  push r9
000075aec0bd9cf8  push r10
000075aec0bd9cfa  push r11
000075aec0bd9cfc  sub rsp, 0xF0
000075aec0bd9d03  vmovaps [rsp], xmm0
000075aec0bd9d08  vmovaps [rsp+0x10], xmm1
000075aec0bd9d0e  vmovaps [rsp+0x20], xmm2
000075aec0bd9d14  vmovaps [rsp+0x30], xmm3
000075aec0bd9d1a  vmovaps [rsp+0x40], xmm4
000075aec0bd9d20  vmovaps [rsp+0x50], xmm5
000075aec0bd9d26  vmovaps [rsp+0x60], xmm6
000075aec0bd9d2c  vmovaps [rsp+0x70], xmm7
000075aec0bd9d32  vmovaps [rsp+0x80], xmm8
000075aec0bd9d3b  vmovaps [rsp+0x90], xmm9
000075aec0bd9d44  vmovaps [rsp+0xA0], xmm11
000075aec0bd9d4d  vmovaps [rsp+0xB0], xmm12
000075aec0bd9d56  vmovaps [rsp+0xC0], xmm13
000075aec0bd9d5f  vmovaps [rsp+0xD0], xmm14
000075aec0bd9d68  vmovaps [rsp+0xE0], xmm15
000075aec0bd9d71  sub rsp, 0x30
000075aec0bd9d75  movaps [rsp], xmm10
000075aec0bd9d7a  movaps [rsp+0x10], xmm14
000075aec0bd9d80  movaps [rsp+0x20], xmm4
000075aec0bd9d85  lea rdi, [rsp]
000075aec0bd9d89  mov esi, 0x00
000075aec0bd9d8e  mov rax, 0x57F4B31E6530
000075aec0bd9d98  call rax
000075aec0bd9d9a  movaps xmm10, [rsp]
000075aec0bd9d9f  add rsp, 0x30
000075aec0bd9da3  vmovaps xmm0, [rsp]
000075aec0bd9da8  vmovaps xmm1, [rsp+0x10]
000075aec0bd9dae  vmovaps xmm2, [rsp+0x20]
000075aec0bd9db4  vmovaps xmm3, [rsp+0x30]
000075aec0bd9dba  vmovaps xmm4, [rsp+0x40]
000075aec0bd9dc0  vmovaps xmm5, [rsp+0x50]
000075aec0bd9dc6  vmovaps xmm6, [rsp+0x60]
000075aec0bd9dcc  vmovaps xmm7, [rsp+0x70]
000075aec0bd9dd2  vmovaps xmm8, [rsp+0x80]
000075aec0bd9ddb  vmovaps xmm9, [rsp+0x90]
000075aec0bd9de4  vmovaps xmm11, [rsp+0xA0]
000075aec0bd9ded  vmovaps xmm12, [rsp+0xB0]
000075aec0bd9df6  vmovaps xmm13, [rsp+0xC0]
000075aec0bd9dff  vmovaps xmm14, [rsp+0xD0]
000075aec0bd9e08  vmovaps xmm15, [rsp+0xE0]
000075aec0bd9e11  add rsp, 0xF0
000075aec0bd9e18  pop r11
000075aec0bd9e1a  pop r10
000075aec0bd9e1c  pop r9
000075aec0bd9e1e  pop r8
000075aec0bd9e20  pop rsi
000075aec0bd9e21  pop rdi
000075aec0bd9e22  pop rdx
000075aec0bd9e23  pop rcx
000075aec0bd9e24  pop rax
000075aec0bd9e25  add rsp, 0x08
000075aec0bd9e29  jmp 0x000075AEC0BD6388
000075aec0bd9e2e  sub rsp, 0x08
000075aec0bd9e32  push rax
000075aec0bd9e33  push rcx
000075aec0bd9e34  push rdx
000075aec0bd9e35  push rdi
000075aec0bd9e36  push rsi
000075aec0bd9e37  push r8
000075aec0bd9e39  push r9
000075aec0bd9e3b  push r10
000075aec0bd9e3d  push r11
000075aec0bd9e3f  sub rsp, 0xF0
000075aec0bd9e46  vmovaps [rsp], xmm0
000075aec0bd9e4b  vmovaps [rsp+0x10], xmm1
000075aec0bd9e51  vmovaps [rsp+0x20], xmm2
000075aec0bd9e57  vmovaps [rsp+0x30], xmm3
000075aec0bd9e5d  vmovaps [rsp+0x40], xmm4
000075aec0bd9e63  vmovaps [rsp+0x50], xmm5
000075aec0bd9e69  vmovaps [rsp+0x60], xmm6
000075aec0bd9e6f  vmovaps [rsp+0x70], xmm7
000075aec0bd9e75  vmovaps [rsp+0x80], xmm9
000075aec0bd9e7e  vmovaps [rsp+0x90], xmm10
000075aec0bd9e87  vmovaps [rsp+0xA0], xmm11
000075aec0bd9e90  vmovaps [rsp+0xB0], xmm12
000075aec0bd9e99  vmovaps [rsp+0xC0], xmm13
000075aec0bd9ea2  vmovaps [rsp+0xD0], xmm14
000075aec0bd9eab  vmovaps [rsp+0xE0], xmm15
000075aec0bd9eb4  sub rsp, 0x30
000075aec0bd9eb8  movaps [rsp], xmm8
000075aec0bd9ebd  movaps [rsp+0x10], xmm1
000075aec0bd9ec2  movaps [rsp+0x20], xmm14
000075aec0bd9ec8  lea rdi, [rsp]
000075aec0bd9ecc  mov esi, 0x00
000075aec0bd9ed1  mov rax, 0x57F4B31E6530
000075aec0bd9edb  call rax
000075aec0bd9edd  movaps xmm8, [rsp]
000075aec0bd9ee2  add rsp, 0x30
000075aec0bd9ee6  vmovaps xmm0, [rsp]
000075aec0bd9eeb  vmovaps xmm1, [rsp+0x10]
000075aec0bd9ef1  vmovaps xmm2, [rsp+0x20]
000075aec0bd9ef7  vmovaps xmm3, [rsp+0x30]
000075aec0bd9efd  vmovaps xmm4, [rsp+0x40]
000075aec0bd9f03  vmovaps xmm5, [rsp+0x50]
000075aec0bd9f09  vmovaps xmm6, [rsp+0x60]
000075aec0bd9f0f  vmovaps xmm7, [rsp+0x70]
000075aec0bd9f15  vmovaps xmm9, [rsp+0x80]
000075aec0bd9f1e  vmovaps xmm10, [rsp+0x90]
000075aec0bd9f27  vmovaps xmm11, [rsp+0xA0]
000075aec0bd9f30  vmovaps xmm12, [rsp+0xB0]
000075aec0bd9f39  vmovaps xmm13, [rsp+0xC0]
000075aec0bd9f42  vmovaps xmm14, [rsp+0xD0]
000075aec0bd9f4b  vmovaps xmm15, [rsp+0xE0]
000075aec0bd9f54  add rsp, 0xF0
000075aec0bd9f5b  pop r11
000075aec0bd9f5d  pop r10
000075aec0bd9f5f  pop r9
000075aec0bd9f61  pop r8
000075aec0bd9f63  pop rsi
000075aec0bd9f64  pop rdi
000075aec0bd9f65  pop rdx
000075aec0bd9f66  pop rcx
000075aec0bd9f67  pop rax
000075aec0bd9f68  add rsp, 0x08
000075aec0bd9f6c  jmp 0x000075AEC0BD63AE
000075aec0bd9f71  sub rsp, 0x08
000075aec0bd9f75  push rax
000075aec0bd9f76  push rcx
000075aec0bd9f77  push rdx
000075aec0bd9f78  push rdi
000075aec0bd9f79  push rsi
000075aec0bd9f7a  push r8
000075aec0bd9f7c  push r9
000075aec0bd9f7e  push r10
000075aec0bd9f80  push r11
000075aec0bd9f82  sub rsp, 0xF0
000075aec0bd9f89  vmovaps [rsp], xmm0
000075aec0bd9f8e  vmovaps [rsp+0x10], xmm1
000075aec0bd9f94  vmovaps [rsp+0x20], xmm2
000075aec0bd9f9a  vmovaps [rsp+0x30], xmm3
000075aec0bd9fa0  vmovaps [rsp+0x40], xmm4
000075aec0bd9fa6  vmovaps [rsp+0x50], xmm5
000075aec0bd9fac  vmovaps [rsp+0x60], xmm7
000075aec0bd9fb2  vmovaps [rsp+0x70], xmm8
000075aec0bd9fb8  vmovaps [rsp+0x80], xmm9
000075aec0bd9fc1  vmovaps [rsp+0x90], xmm10
000075aec0bd9fca  vmovaps [rsp+0xA0], xmm11
000075aec0bd9fd3  vmovaps [rsp+0xB0], xmm12
000075aec0bd9fdc  vmovaps [rsp+0xC0], xmm13
000075aec0bd9fe5  vmovaps [rsp+0xD0], xmm14
000075aec0bd9fee  vmovaps [rsp+0xE0], xmm15
000075aec0bd9ff7  sub rsp, 0x30
000075aec0bd9ffb  movaps [rsp], xmm6
000075aec0bd9fff  movaps [rsp+0x10], xmm1
000075aec0bda004  movaps [rsp+0x20], xmm14
000075aec0bda00a  lea rdi, [rsp]
000075aec0bda00e  mov esi, 0x00
000075aec0bda013  mov rax, 0x57F4B31E6530
000075aec0bda01d  call rax
000075aec0bda01f  movaps xmm6, [rsp]
000075aec0bda023  add rsp, 0x30
000075aec0bda027  vmovaps xmm0, [rsp]
000075aec0bda02c  vmovaps xmm1, [rsp+0x10]
000075aec0bda032  vmovaps xmm2, [rsp+0x20]
000075aec0bda038  vmovaps xmm3, [rsp+0x30]
000075aec0bda03e  vmovaps xmm4, [rsp+0x40]
000075aec0bda044  vmovaps xmm5, [rsp+0x50]
000075aec0bda04a  vmovaps xmm7, [rsp+0x60]
000075aec0bda050  vmovaps xmm8, [rsp+0x70]
000075aec0bda056  vmovaps xmm9, [rsp+0x80]
000075aec0bda05f  vmovaps xmm10, [rsp+0x90]
000075aec0bda068  vmovaps xmm11, [rsp+0xA0]
000075aec0bda071  vmovaps xmm12, [rsp+0xB0]
000075aec0bda07a  vmovaps xmm13, [rsp+0xC0]
000075aec0bda083  vmovaps xmm14, [rsp+0xD0]
000075aec0bda08c  vmovaps xmm15, [rsp+0xE0]
000075aec0bda095  add rsp, 0xF0
000075aec0bda09c  pop r11
000075aec0bda09e  pop r10
000075aec0bda0a0  pop r9
000075aec0bda0a2  pop r8
000075aec0bda0a4  pop rsi
000075aec0bda0a5  pop rdi
000075aec0bda0a6  pop rdx
000075aec0bda0a7  pop rcx
000075aec0bda0a8  pop rax
000075aec0bda0a9  add rsp, 0x08
000075aec0bda0ad  jmp 0x000075AEC0BD63DA
000075aec0bda0b2  sub rsp, 0x08
000075aec0bda0b6  push rax
000075aec0bda0b7  push rcx
000075aec0bda0b8  push rdx
000075aec0bda0b9  push rdi
000075aec0bda0ba  push rsi
000075aec0bda0bb  push r8
000075aec0bda0bd  push r9
000075aec0bda0bf  push r10
000075aec0bda0c1  push r11
000075aec0bda0c3  sub rsp, 0xF0
000075aec0bda0ca  vmovaps [rsp], xmm0
000075aec0bda0cf  vmovaps [rsp+0x10], xmm1
000075aec0bda0d5  vmovaps [rsp+0x20], xmm2
000075aec0bda0db  vmovaps [rsp+0x30], xmm3
000075aec0bda0e1  vmovaps [rsp+0x40], xmm4
000075aec0bda0e7  vmovaps [rsp+0x50], xmm5
000075aec0bda0ed  vmovaps [rsp+0x60], xmm6
000075aec0bda0f3  vmovaps [rsp+0x70], xmm7
000075aec0bda0f9  vmovaps [rsp+0x80], xmm8
000075aec0bda102  vmovaps [rsp+0x90], xmm9
000075aec0bda10b  vmovaps [rsp+0xA0], xmm10
000075aec0bda114  vmovaps [rsp+0xB0], xmm11
000075aec0bda11d  vmovaps [rsp+0xC0], xmm12
000075aec0bda126  vmovaps [rsp+0xD0], xmm13
000075aec0bda12f  vmovaps [rsp+0xE0], xmm15
000075aec0bda138  sub rsp, 0x30
000075aec0bda13c  movaps [rsp], xmm14
000075aec0bda141  movaps [rsp+0x10], xmm12
000075aec0bda147  movaps [rsp+0x20], xmm1
000075aec0bda14c  lea rdi, [rsp]
000075aec0bda150  mov esi, 0x00
000075aec0bda155  mov rax, 0x57F4B31E6530
000075aec0bda15f  call rax
000075aec0bda161  movaps xmm14, [rsp]
000075aec0bda166  add rsp, 0x30
000075aec0bda16a  vmovaps xmm0, [rsp]
000075aec0bda16f  vmovaps xmm1, [rsp+0x10]
000075aec0bda175  vmovaps xmm2, [rsp+0x20]
000075aec0bda17b  vmovaps xmm3, [rsp+0x30]
000075aec0bda181  vmovaps xmm4, [rsp+0x40]
000075aec0bda187  vmovaps xmm5, [rsp+0x50]
000075aec0bda18d  vmovaps xmm6, [rsp+0x60]
000075aec0bda193  vmovaps xmm7, [rsp+0x70]
000075aec0bda199  vmovaps xmm8, [rsp+0x80]
000075aec0bda1a2  vmovaps xmm9, [rsp+0x90]
000075aec0bda1ab  vmovaps xmm10, [rsp+0xA0]
000075aec0bda1b4  vmovaps xmm11, [rsp+0xB0]
000075aec0bda1bd  vmovaps xmm12, [rsp+0xC0]
000075aec0bda1c6  vmovaps xmm13, [rsp+0xD0]
000075aec0bda1cf  vmovaps xmm15, [rsp+0xE0]
000075aec0bda1d8  add rsp, 0xF0
000075aec0bda1df  pop r11
000075aec0bda1e1  pop r10
000075aec0bda1e3  pop r9
000075aec0bda1e5  pop r8
000075aec0bda1e7  pop rsi
000075aec0bda1e8  pop rdi
000075aec0bda1e9  pop rdx
000075aec0bda1ea  pop rcx
000075aec0bda1eb  pop rax
000075aec0bda1ec  add rsp, 0x08
000075aec0bda1f0  jmp 0x000075AEC0BD6400
000075aec0bda1f5  sub rsp, 0x08
000075aec0bda1f9  push rax
000075aec0bda1fa  push rcx
000075aec0bda1fb  push rdx
000075aec0bda1fc  push rdi
000075aec0bda1fd  push rsi
000075aec0bda1fe  push r8
000075aec0bda200  push r9
000075aec0bda202  push r10
000075aec0bda204  push r11
000075aec0bda206  sub rsp, 0xF0
000075aec0bda20d  vmovaps [rsp], xmm0
000075aec0bda212  vmovaps [rsp+0x10], xmm2
000075aec0bda218  vmovaps [rsp+0x20], xmm3
000075aec0bda21e  vmovaps [rsp+0x30], xmm4
000075aec0bda224  vmovaps [rsp+0x40], xmm5
000075aec0bda22a  vmovaps [rsp+0x50], xmm6
000075aec0bda230  vmovaps [rsp+0x60], xmm7
000075aec0bda236  vmovaps [rsp+0x70], xmm8
000075aec0bda23c  vmovaps [rsp+0x80], xmm9
000075aec0bda245  vmovaps [rsp+0x90], xmm10
000075aec0bda24e  vmovaps [rsp+0xA0], xmm11
000075aec0bda257  vmovaps [rsp+0xB0], xmm12
000075aec0bda260  vmovaps [rsp+0xC0], xmm13
000075aec0bda269  vmovaps [rsp+0xD0], xmm14
000075aec0bda272  vmovaps [rsp+0xE0], xmm15
000075aec0bda27b  sub rsp, 0x30
000075aec0bda27f  movaps [rsp], xmm1
000075aec0bda283  movaps [rsp+0x10], xmm13
000075aec0bda289  movaps [rsp+0x20], xmm9
000075aec0bda28f  lea rdi, [rsp]
000075aec0bda293  mov esi, 0x00
000075aec0bda298  mov rax, 0x57F4B31E6530
000075aec0bda2a2  call rax
000075aec0bda2a4  movaps xmm1, [rsp]
000075aec0bda2a8  add rsp, 0x30
000075aec0bda2ac  vmovaps xmm0, [rsp]
000075aec0bda2b1  vmovaps xmm2, [rsp+0x10]
000075aec0bda2b7  vmovaps xmm3, [rsp+0x20]
000075aec0bda2bd  vmovaps xmm4, [rsp+0x30]
000075aec0bda2c3  vmovaps xmm5, [rsp+0x40]
000075aec0bda2c9  vmovaps xmm6, [rsp+0x50]
000075aec0bda2cf  vmovaps xmm7, [rsp+0x60]
000075aec0bda2d5  vmovaps xmm8, [rsp+0x70]
000075aec0bda2db  vmovaps xmm9, [rsp+0x80]
000075aec0bda2e4  vmovaps xmm10, [rsp+0x90]
000075aec0bda2ed  vmovaps xmm11, [rsp+0xA0]
000075aec0bda2f6  vmovaps xmm12, [rsp+0xB0]
000075aec0bda2ff  vmovaps xmm13, [rsp+0xC0]
000075aec0bda308  vmovaps xmm14, [rsp+0xD0]
000075aec0bda311  vmovaps xmm15, [rsp+0xE0]
000075aec0bda31a  add rsp, 0xF0
000075aec0bda321  pop r11
000075aec0bda323  pop r10
000075aec0bda325  pop r9
000075aec0bda327  pop r8
000075aec0bda329  pop rsi
000075aec0bda32a  pop rdi
000075aec0bda32b  pop rdx
000075aec0bda32c  pop rcx
000075aec0bda32d  pop rax
000075aec0bda32e  add rsp, 0x08
000075aec0bda332  jmp 0x000075AEC0BD641A
000075aec0bda337  sub rsp, 0x08
000075aec0bda33b  push rax
000075aec0bda33c  push rcx
000075aec0bda33d  push rdx
000075aec0bda33e  push rdi
000075aec0bda33f  push rsi
000075aec0bda340  push r8
000075aec0bda342  push r9
000075aec0bda344  push r10
000075aec0bda346  push r11
000075aec0bda348  sub rsp, 0xF0
000075aec0bda34f  vmovaps [rsp], xmm0
000075aec0bda354  vmovaps [rsp+0x10], xmm1
000075aec0bda35a  vmovaps [rsp+0x20], xmm2
000075aec0bda360  vmovaps [rsp+0x30], xmm3
000075aec0bda366  vmovaps [rsp+0x40], xmm4
000075aec0bda36c  vmovaps [rsp+0x50], xmm5
000075aec0bda372  vmovaps [rsp+0x60], xmm6
000075aec0bda378  vmovaps [rsp+0x70], xmm7
000075aec0bda37e  vmovaps [rsp+0x80], xmm8
000075aec0bda387  vmovaps [rsp+0x90], xmm9
000075aec0bda390  vmovaps [rsp+0xA0], xmm10
000075aec0bda399  vmovaps [rsp+0xB0], xmm11
000075aec0bda3a2  vmovaps [rsp+0xC0], xmm13
000075aec0bda3ab  vmovaps [rsp+0xD0], xmm14
000075aec0bda3b4  vmovaps [rsp+0xE0], xmm15
000075aec0bda3bd  sub rsp, 0x30
000075aec0bda3c1  movaps [rsp], xmm12
000075aec0bda3c6  movaps [rsp+0x10], xmm7
000075aec0bda3cb  movaps [rsp+0x20], xmm13
000075aec0bda3d1  lea rdi, [rsp]
000075aec0bda3d5  mov esi, 0x00
000075aec0bda3da  mov rax, 0x57F4B31E6530
000075aec0bda3e4  call rax
000075aec0bda3e6  movaps xmm12, [rsp]
000075aec0bda3eb  add rsp, 0x30
000075aec0bda3ef  vmovaps xmm0, [rsp]
000075aec0bda3f4  vmovaps xmm1, [rsp+0x10]
000075aec0bda3fa  vmovaps xmm2, [rsp+0x20]
000075aec0bda400  vmovaps xmm3, [rsp+0x30]
000075aec0bda406  vmovaps xmm4, [rsp+0x40]
000075aec0bda40c  vmovaps xmm5, [rsp+0x50]
000075aec0bda412  vmovaps xmm6, [rsp+0x60]
000075aec0bda418  vmovaps xmm7, [rsp+0x70]
000075aec0bda41e  vmovaps xmm8, [rsp+0x80]
000075aec0bda427  vmovaps xmm9, [rsp+0x90]
000075aec0bda430  vmovaps xmm10, [rsp+0xA0]
000075aec0bda439  vmovaps xmm11, [rsp+0xB0]
000075aec0bda442  vmovaps xmm13, [rsp+0xC0]
000075aec0bda44b  vmovaps xmm14, [rsp+0xD0]
000075aec0bda454  vmovaps xmm15, [rsp+0xE0]
000075aec0bda45d  add rsp, 0xF0
000075aec0bda464  pop r11
000075aec0bda466  pop r10
000075aec0bda468  pop r9
000075aec0bda46a  pop r8
000075aec0bda46c  pop rsi
000075aec0bda46d  pop rdi
000075aec0bda46e  pop rdx
000075aec0bda46f  pop rcx
000075aec0bda470  pop rax
000075aec0bda471  add rsp, 0x08
000075aec0bda475  jmp 0x000075AEC0BD6441
000075aec0bda47a  sub rsp, 0x08
000075aec0bda47e  push rax
000075aec0bda47f  push rcx
000075aec0bda480  push rdx
000075aec0bda481  push rdi
000075aec0bda482  push rsi
000075aec0bda483  push r8
000075aec0bda485  push r9
000075aec0bda487  push r10
000075aec0bda489  push r11
000075aec0bda48b  sub rsp, 0xF0
000075aec0bda492  vmovaps [rsp], xmm0
000075aec0bda497  vmovaps [rsp+0x10], xmm1
000075aec0bda49d  vmovaps [rsp+0x20], xmm2
000075aec0bda4a3  vmovaps [rsp+0x30], xmm3
000075aec0bda4a9  vmovaps [rsp+0x40], xmm4
000075aec0bda4af  vmovaps [rsp+0x50], xmm5
000075aec0bda4b5  vmovaps [rsp+0x60], xmm6
000075aec0bda4bb  vmovaps [rsp+0x70], xmm7
000075aec0bda4c1  vmovaps [rsp+0x80], xmm8
000075aec0bda4ca  vmovaps [rsp+0x90], xmm9
000075aec0bda4d3  vmovaps [rsp+0xA0], xmm10
000075aec0bda4dc  vmovaps [rsp+0xB0], xmm11
000075aec0bda4e5  vmovaps [rsp+0xC0], xmm12
000075aec0bda4ee  vmovaps [rsp+0xD0], xmm14
000075aec0bda4f7  vmovaps [rsp+0xE0], xmm15
000075aec0bda500  sub rsp, 0x30
000075aec0bda504  movaps [rsp], xmm13
000075aec0bda509  movaps [rsp+0x10], xmm15
000075aec0bda50f  movaps [rsp+0x20], xmm8
000075aec0bda515  lea rdi, [rsp]
000075aec0bda519  mov esi, 0x00
000075aec0bda51e  mov rax, 0x57F4B31E6530
000075aec0bda528  call rax
000075aec0bda52a  movaps xmm13, [rsp]
000075aec0bda52f  add rsp, 0x30
000075aec0bda533  vmovaps xmm0, [rsp]
000075aec0bda538  vmovaps xmm1, [rsp+0x10]
000075aec0bda53e  vmovaps xmm2, [rsp+0x20]
000075aec0bda544  vmovaps xmm3, [rsp+0x30]
000075aec0bda54a  vmovaps xmm4, [rsp+0x40]
000075aec0bda550  vmovaps xmm5, [rsp+0x50]
000075aec0bda556  vmovaps xmm6, [rsp+0x60]
000075aec0bda55c  vmovaps xmm7, [rsp+0x70]
000075aec0bda562  vmovaps xmm8, [rsp+0x80]
000075aec0bda56b  vmovaps xmm9, [rsp+0x90]
000075aec0bda574  vmovaps xmm10, [rsp+0xA0]
000075aec0bda57d  vmovaps xmm11, [rsp+0xB0]
000075aec0bda586  vmovaps xmm12, [rsp+0xC0]
000075aec0bda58f  vmovaps xmm14, [rsp+0xD0]
000075aec0bda598  vmovaps xmm15, [rsp+0xE0]
000075aec0bda5a1  add rsp, 0xF0
000075aec0bda5a8  pop r11
000075aec0bda5aa  pop r10
000075aec0bda5ac  pop r9
000075aec0bda5ae  pop r8
000075aec0bda5b0  pop rsi
000075aec0bda5b1  pop rdi
000075aec0bda5b2  pop rdx
000075aec0bda5b3  pop rcx
000075aec0bda5b4  pop rax
000075aec0bda5b5  add rsp, 0x08
000075aec0bda5b9  jmp 0x000075AEC0BD645C
000075aec0bda5be  sub rsp, 0x08
000075aec0bda5c2  push rax
000075aec0bda5c3  push rcx
000075aec0bda5c4  push rdx
000075aec0bda5c5  push rdi
000075aec0bda5c6  push rsi
000075aec0bda5c7  push r8
000075aec0bda5c9  push r9
000075aec0bda5cb  push r10
000075aec0bda5cd  push r11
000075aec0bda5cf  sub rsp, 0xF0
000075aec0bda5d6  vmovaps [rsp], xmm0
000075aec0bda5db  vmovaps [rsp+0x10], xmm1
000075aec0bda5e1  vmovaps [rsp+0x20], xmm2
000075aec0bda5e7  vmovaps [rsp+0x30], xmm3
000075aec0bda5ed  vmovaps [rsp+0x40], xmm4
000075aec0bda5f3  vmovaps [rsp+0x50], xmm5
000075aec0bda5f9  vmovaps [rsp+0x60], xmm6
000075aec0bda5ff  vmovaps [rsp+0x70], xmm7
000075aec0bda605  vmovaps [rsp+0x80], xmm9
000075aec0bda60e  vmovaps [rsp+0x90], xmm10
000075aec0bda617  vmovaps [rsp+0xA0], xmm11
000075aec0bda620  vmovaps [rsp+0xB0], xmm12
000075aec0bda629  vmovaps [rsp+0xC0], xmm13
000075aec0bda632  vmovaps [rsp+0xD0], xmm14
000075aec0bda63b  vmovaps [rsp+0xE0], xmm15
000075aec0bda644  sub rsp, 0x30
000075aec0bda648  movaps [rsp], xmm8
000075aec0bda64d  movaps [rsp+0x10], xmm15
000075aec0bda653  movaps [rsp+0x20], xmm9
000075aec0bda659  lea rdi, [rsp]
000075aec0bda65d  mov esi, 0x00
000075aec0bda662  mov rax, 0x57F4B31E6530
000075aec0bda66c  call rax
000075aec0bda66e  movaps xmm8, [rsp]
000075aec0bda673  add rsp, 0x30
000075aec0bda677  vmovaps xmm0, [rsp]
000075aec0bda67c  vmovaps xmm1, [rsp+0x10]
000075aec0bda682  vmovaps xmm2, [rsp+0x20]
000075aec0bda688  vmovaps xmm3, [rsp+0x30]
000075aec0bda68e  vmovaps xmm4, [rsp+0x40]
000075aec0bda694  vmovaps xmm5, [rsp+0x50]
000075aec0bda69a  vmovaps xmm6, [rsp+0x60]
000075aec0bda6a0  vmovaps xmm7, [rsp+0x70]
000075aec0bda6a6  vmovaps xmm9, [rsp+0x80]
000075aec0bda6af  vmovaps xmm10, [rsp+0x90]
000075aec0bda6b8  vmovaps xmm11, [rsp+0xA0]
000075aec0bda6c1  vmovaps xmm12, [rsp+0xB0]
000075aec0bda6ca  vmovaps xmm13, [rsp+0xC0]
000075aec0bda6d3  vmovaps xmm14, [rsp+0xD0]
000075aec0bda6dc  vmovaps xmm15, [rsp+0xE0]
000075aec0bda6e5  add rsp, 0xF0
000075aec0bda6ec  pop r11
000075aec0bda6ee  pop r10
000075aec0bda6f0  pop r9
000075aec0bda6f2  pop r8
000075aec0bda6f4  pop rsi
000075aec0bda6f5  pop rdi
000075aec0bda6f6  pop rdx
000075aec0bda6f7  pop rcx
000075aec0bda6f8  pop rax
000075aec0bda6f9  add rsp, 0x08
000075aec0bda6fd  jmp 0x000075AEC0BD648A
000075aec0bda702  sub rsp, 0x08
000075aec0bda706  push rax
000075aec0bda707  push rcx
000075aec0bda708  push rdx
000075aec0bda709  push rdi
000075aec0bda70a  push rsi
000075aec0bda70b  push r8
000075aec0bda70d  push r9
000075aec0bda70f  push r10
000075aec0bda711  push r11
000075aec0bda713  sub rsp, 0xF0
000075aec0bda71a  vmovaps [rsp], xmm0
000075aec0bda71f  vmovaps [rsp+0x10], xmm1
000075aec0bda725  vmovaps [rsp+0x20], xmm2
000075aec0bda72b  vmovaps [rsp+0x30], xmm3
000075aec0bda731  vmovaps [rsp+0x40], xmm4
000075aec0bda737  vmovaps [rsp+0x50], xmm5
000075aec0bda73d  vmovaps [rsp+0x60], xmm6
000075aec0bda743  vmovaps [rsp+0x70], xmm7
000075aec0bda749  vmovaps [rsp+0x80], xmm8
000075aec0bda752  vmovaps [rsp+0x90], xmm9
000075aec0bda75b  vmovaps [rsp+0xA0], xmm10
000075aec0bda764  vmovaps [rsp+0xB0], xmm11
000075aec0bda76d  vmovaps [rsp+0xC0], xmm12
000075aec0bda776  vmovaps [rsp+0xD0], xmm13
000075aec0bda77f  vmovaps [rsp+0xE0], xmm14
000075aec0bda788  sub rsp, 0x30
000075aec0bda78c  movaps [rsp], xmm15
000075aec0bda791  movaps [rsp+0x10], xmm11
000075aec0bda797  movaps [rsp+0x20], xmm6
000075aec0bda79c  lea rdi, [rsp]
000075aec0bda7a0  mov esi, 0x00
000075aec0bda7a5  mov rax, 0x57F4B31E6530
000075aec0bda7af  call rax
000075aec0bda7b1  movaps xmm15, [rsp]
000075aec0bda7b6  add rsp, 0x30
000075aec0bda7ba  vmovaps xmm0, [rsp]
000075aec0bda7bf  vmovaps xmm1, [rsp+0x10]
000075aec0bda7c5  vmovaps xmm2, [rsp+0x20]
000075aec0bda7cb  vmovaps xmm3, [rsp+0x30]
000075aec0bda7d1  vmovaps xmm4, [rsp+0x40]
000075aec0bda7d7  vmovaps xmm5, [rsp+0x50]
000075aec0bda7dd  vmovaps xmm6, [rsp+0x60]
000075aec0bda7e3  vmovaps xmm7, [rsp+0x70]
000075aec0bda7e9  vmovaps xmm8, [rsp+0x80]
000075aec0bda7f2  vmovaps xmm9, [rsp+0x90]
000075aec0bda7fb  vmovaps xmm10, [rsp+0xA0]
000075aec0bda804  vmovaps xmm11, [rsp+0xB0]
000075aec0bda80d  vmovaps xmm12, [rsp+0xC0]
000075aec0bda816  vmovaps xmm13, [rsp+0xD0]
000075aec0bda81f  vmovaps xmm14, [rsp+0xE0]
000075aec0bda828  add rsp, 0xF0
000075aec0bda82f  pop r11
000075aec0bda831  pop r10
000075aec0bda833  pop r9
000075aec0bda835  pop r8
000075aec0bda837  pop rsi
000075aec0bda838  pop rdi
000075aec0bda839  pop rdx
000075aec0bda83a  pop rcx
000075aec0bda83b  pop rax
000075aec0bda83c  add rsp, 0x08
000075aec0bda840  jmp 0x000075AEC0BD64A5
000075aec0bda845  sub rsp, 0x08
000075aec0bda849  push rax
000075aec0bda84a  push rcx
000075aec0bda84b  push rdx
000075aec0bda84c  push rdi
000075aec0bda84d  push rsi
000075aec0bda84e  push r8
000075aec0bda850  push r9
000075aec0bda852  push r10
000075aec0bda854  push r11
000075aec0bda856  sub rsp, 0xF0
000075aec0bda85d  vmovaps [rsp], xmm0
000075aec0bda862  vmovaps [rsp+0x10], xmm1
000075aec0bda868  vmovaps [rsp+0x20], xmm2
000075aec0bda86e  vmovaps [rsp+0x30], xmm3
000075aec0bda874  vmovaps [rsp+0x40], xmm4
000075aec0bda87a  vmovaps [rsp+0x50], xmm5
000075aec0bda880  vmovaps [rsp+0x60], xmm6
000075aec0bda886  vmovaps [rsp+0x70], xmm8
000075aec0bda88c  vmovaps [rsp+0x80], xmm9
000075aec0bda895  vmovaps [rsp+0x90], xmm10
000075aec0bda89e  vmovaps [rsp+0xA0], xmm11
000075aec0bda8a7  vmovaps [rsp+0xB0], xmm12
000075aec0bda8b0  vmovaps [rsp+0xC0], xmm13
000075aec0bda8b9  vmovaps [rsp+0xD0], xmm14
000075aec0bda8c2  vmovaps [rsp+0xE0], xmm15
000075aec0bda8cb  sub rsp, 0x30
000075aec0bda8cf  movaps [rsp], xmm7
000075aec0bda8d3  movaps [rsp+0x10], xmm11
000075aec0bda8d9  movaps [rsp+0x20], xmm9
000075aec0bda8df  lea rdi, [rsp]
000075aec0bda8e3  mov esi, 0x00
000075aec0bda8e8  mov rax, 0x57F4B31E6530
000075aec0bda8f2  call rax
000075aec0bda8f4  movaps xmm7, [rsp]
000075aec0bda8f8  add rsp, 0x30
000075aec0bda8fc  vmovaps xmm0, [rsp]
000075aec0bda901  vmovaps xmm1, [rsp+0x10]
000075aec0bda907  vmovaps xmm2, [rsp+0x20]
000075aec0bda90d  vmovaps xmm3, [rsp+0x30]
000075aec0bda913  vmovaps xmm4, [rsp+0x40]
000075aec0bda919  vmovaps xmm5, [rsp+0x50]
000075aec0bda91f  vmovaps xmm6, [rsp+0x60]
000075aec0bda925  vmovaps xmm8, [rsp+0x70]
000075aec0bda92b  vmovaps xmm9, [rsp+0x80]
000075aec0bda934  vmovaps xmm10, [rsp+0x90]
000075aec0bda93d  vmovaps xmm11, [rsp+0xA0]
000075aec0bda946  vmovaps xmm12, [rsp+0xB0]
000075aec0bda94f  vmovaps xmm13, [rsp+0xC0]
000075aec0bda958  vmovaps xmm14, [rsp+0xD0]
000075aec0bda961  vmovaps xmm15, [rsp+0xE0]
000075aec0bda96a  add rsp, 0xF0
000075aec0bda971  pop r11
000075aec0bda973  pop r10
000075aec0bda975  pop r9
000075aec0bda977  pop r8
000075aec0bda979  pop rsi
000075aec0bda97a  pop rdi
000075aec0bda97b  pop rdx
000075aec0bda97c  pop rcx
000075aec0bda97d  pop rax
000075aec0bda97e  add rsp, 0x08
000075aec0bda982  jmp 0x000075AEC0BD64D2
000075aec0bda987  sub rsp, 0x08
000075aec0bda98b  push rax
000075aec0bda98c  push rcx
000075aec0bda98d  push rdx
000075aec0bda98e  push rdi
000075aec0bda98f  push rsi
000075aec0bda990  push r8
000075aec0bda992  push r9
000075aec0bda994  push r10
000075aec0bda996  push r11
000075aec0bda998  sub rsp, 0xF0
000075aec0bda99f  vmovaps [rsp], xmm0
000075aec0bda9a4  vmovaps [rsp+0x10], xmm1
000075aec0bda9aa  vmovaps [rsp+0x20], xmm2
000075aec0bda9b0  vmovaps [rsp+0x30], xmm3
000075aec0bda9b6  vmovaps [rsp+0x40], xmm4
000075aec0bda9bc  vmovaps [rsp+0x50], xmm5
000075aec0bda9c2  vmovaps [rsp+0x60], xmm6
000075aec0bda9c8  vmovaps [rsp+0x70], xmm7
000075aec0bda9ce  vmovaps [rsp+0x80], xmm8
000075aec0bda9d7  vmovaps [rsp+0x90], xmm9
000075aec0bda9e0  vmovaps [rsp+0xA0], xmm10
000075aec0bda9e9  vmovaps [rsp+0xB0], xmm12
000075aec0bda9f2  vmovaps [rsp+0xC0], xmm13
000075aec0bda9fb  vmovaps [rsp+0xD0], xmm14
000075aec0bdaa04  vmovaps [rsp+0xE0], xmm15
000075aec0bdaa0d  sub rsp, 0x30
000075aec0bdaa11  movaps [rsp], xmm11
000075aec0bdaa16  movaps [rsp+0x10], xmm10
000075aec0bdaa1c  movaps [rsp+0x20], xmm14
000075aec0bdaa22  lea rdi, [rsp]
000075aec0bdaa26  mov esi, 0x00
000075aec0bdaa2b  mov rax, 0x57F4B31E6530
000075aec0bdaa35  call rax
000075aec0bdaa37  movaps xmm11, [rsp]
000075aec0bdaa3c  add rsp, 0x30
000075aec0bdaa40  vmovaps xmm0, [rsp]
000075aec0bdaa45  vmovaps xmm1, [rsp+0x10]
000075aec0bdaa4b  vmovaps xmm2, [rsp+0x20]
000075aec0bdaa51  vmovaps xmm3, [rsp+0x30]
000075aec0bdaa57  vmovaps xmm4, [rsp+0x40]
000075aec0bdaa5d  vmovaps xmm5, [rsp+0x50]
000075aec0bdaa63  vmovaps xmm6, [rsp+0x60]
000075aec0bdaa69  vmovaps xmm7, [rsp+0x70]
000075aec0bdaa6f  vmovaps xmm8, [rsp+0x80]
000075aec0bdaa78  vmovaps xmm9, [rsp+0x90]
000075aec0bdaa81  vmovaps xmm10, [rsp+0xA0]
000075aec0bdaa8a  vmovaps xmm12, [rsp+0xB0]
000075aec0bdaa93  vmovaps xmm13, [rsp+0xC0]
000075aec0bdaa9c  vmovaps xmm14, [rsp+0xD0]
000075aec0bdaaa5  vmovaps xmm15, [rsp+0xE0]
000075aec0bdaaae  add rsp, 0xF0
000075aec0bdaab5  pop r11
000075aec0bdaab7  pop r10
000075aec0bdaab9  pop r9
000075aec0bdaabb  pop r8
000075aec0bdaabd  pop rsi
000075aec0bdaabe  pop rdi
000075aec0bdaabf  pop rdx
000075aec0bdaac0  pop rcx
000075aec0bdaac1  pop rax
000075aec0bdaac2  add rsp, 0x08
000075aec0bdaac6  jmp 0x000075AEC0BD64ED
000075aec0bdaacb  call 0x000075AEC0AE45A0
000075aec0bdaad0  jmp 0x000075AEC0BD64F7
000075aec0bdaad5  sub rsp, 0x08
000075aec0bdaad9  push rax
000075aec0bdaada  push rcx
000075aec0bdaadb  push rdx
000075aec0bdaadc  push rdi
000075aec0bdaadd  push rsi
000075aec0bdaade  push r8
000075aec0bdaae0  push r9
000075aec0bdaae2  push r10
000075aec0bdaae4  push r11
000075aec0bdaae6  sub rsp, 0xF0
000075aec0bdaaed  vmovaps [rsp], xmm0
000075aec0bdaaf2  vmovaps [rsp+0x10], xmm1
000075aec0bdaaf8  vmovaps [rsp+0x20], xmm2
000075aec0bdaafe  vmovaps [rsp+0x30], xmm3
000075aec0bdab04  vmovaps [rsp+0x40], xmm4
000075aec0bdab0a  vmovaps [rsp+0x50], xmm5
000075aec0bdab10  vmovaps [rsp+0x60], xmm6
000075aec0bdab16  vmovaps [rsp+0x70], xmm7
000075aec0bdab1c  vmovaps [rsp+0x80], xmm8
000075aec0bdab25  vmovaps [rsp+0x90], xmm9
000075aec0bdab2e  vmovaps [rsp+0xA0], xmm11
000075aec0bdab37  vmovaps [rsp+0xB0], xmm12
000075aec0bdab40  vmovaps [rsp+0xC0], xmm13
000075aec0bdab49  vmovaps [rsp+0xD0], xmm14
000075aec0bdab52  vmovaps [rsp+0xE0], xmm15
000075aec0bdab5b  sub rsp, 0x30
000075aec0bdab5f  movaps [rsp], xmm10
000075aec0bdab64  movaps [rsp+0x10], xmm1
000075aec0bdab69  movaps [rsp+0x20], xmm12
000075aec0bdab6f  lea rdi, [rsp]
000075aec0bdab73  mov esi, 0x00
000075aec0bdab78  mov rax, 0x57F4B31E6530
000075aec0bdab82  call rax
000075aec0bdab84  movaps xmm10, [rsp]
000075aec0bdab89  add rsp, 0x30
000075aec0bdab8d  vmovaps xmm0, [rsp]
000075aec0bdab92  vmovaps xmm1, [rsp+0x10]
000075aec0bdab98  vmovaps xmm2, [rsp+0x20]
000075aec0bdab9e  vmovaps xmm3, [rsp+0x30]
000075aec0bdaba4  vmovaps xmm4, [rsp+0x40]
000075aec0bdabaa  vmovaps xmm5, [rsp+0x50]
000075aec0bdabb0  vmovaps xmm6, [rsp+0x60]
000075aec0bdabb6  vmovaps xmm7, [rsp+0x70]
000075aec0bdabbc  vmovaps xmm8, [rsp+0x80]
000075aec0bdabc5  vmovaps xmm9, [rsp+0x90]
000075aec0bdabce  vmovaps xmm11, [rsp+0xA0]
000075aec0bdabd7  vmovaps xmm12, [rsp+0xB0]
000075aec0bdabe0  vmovaps xmm13, [rsp+0xC0]
000075aec0bdabe9  vmovaps xmm14, [rsp+0xD0]
000075aec0bdabf2  vmovaps xmm15, [rsp+0xE0]
000075aec0bdabfb  add rsp, 0xF0
000075aec0bdac02  pop r11
000075aec0bdac04  pop r10
000075aec0bdac06  pop r9
000075aec0bdac08  pop r8
000075aec0bdac0a  pop rsi
000075aec0bdac0b  pop rdi
000075aec0bdac0c  pop rdx
000075aec0bdac0d  pop rcx
000075aec0bdac0e  pop rax
000075aec0bdac0f  add rsp, 0x08
000075aec0bdac13  jmp 0x000075AEC0BD651A
000075aec0bdac18  sub rsp, 0x08
000075aec0bdac1c  push rax
000075aec0bdac1d  push rcx
000075aec0bdac1e  push rdx
000075aec0bdac1f  push rdi
000075aec0bdac20  push rsi
000075aec0bdac21  push r8
000075aec0bdac23  push r9
000075aec0bdac25  push r10
000075aec0bdac27  push r11
000075aec0bdac29  sub rsp, 0xF0
000075aec0bdac30  vmovaps [rsp], xmm0
000075aec0bdac35  vmovaps [rsp+0x10], xmm1
000075aec0bdac3b  vmovaps [rsp+0x20], xmm2
000075aec0bdac41  vmovaps [rsp+0x30], xmm3
000075aec0bdac47  vmovaps [rsp+0x40], xmm4
000075aec0bdac4d  vmovaps [rsp+0x50], xmm5
000075aec0bdac53  vmovaps [rsp+0x60], xmm6
000075aec0bdac59  vmovaps [rsp+0x70], xmm7
000075aec0bdac5f  vmovaps [rsp+0x80], xmm8
000075aec0bdac68  vmovaps [rsp+0x90], xmm9
000075aec0bdac71  vmovaps [rsp+0xA0], xmm10
000075aec0bdac7a  vmovaps [rsp+0xB0], xmm11
000075aec0bdac83  vmovaps [rsp+0xC0], xmm13
000075aec0bdac8c  vmovaps [rsp+0xD0], xmm14
000075aec0bdac95  vmovaps [rsp+0xE0], xmm15
000075aec0bdac9e  sub rsp, 0x30
000075aec0bdaca2  movaps [rsp], xmm12
000075aec0bdaca7  movaps [rsp+0x10], xmm14
000075aec0bdacad  movaps [rsp+0x20], xmm1
000075aec0bdacb2  lea rdi, [rsp]
000075aec0bdacb6  mov esi, 0x00
000075aec0bdacbb  mov rax, 0x57F4B31E6530
000075aec0bdacc5  call rax
000075aec0bdacc7  movaps xmm12, [rsp]
000075aec0bdaccc  add rsp, 0x30
000075aec0bdacd0  vmovaps xmm0, [rsp]
000075aec0bdacd5  vmovaps xmm1, [rsp+0x10]
000075aec0bdacdb  vmovaps xmm2, [rsp+0x20]
000075aec0bdace1  vmovaps xmm3, [rsp+0x30]
000075aec0bdace7  vmovaps xmm4, [rsp+0x40]
000075aec0bdaced  vmovaps xmm5, [rsp+0x50]
000075aec0bdacf3  vmovaps xmm6, [rsp+0x60]
000075aec0bdacf9  vmovaps xmm7, [rsp+0x70]
000075aec0bdacff  vmovaps xmm8, [rsp+0x80]
000075aec0bdad08  vmovaps xmm9, [rsp+0x90]
000075aec0bdad11  vmovaps xmm10, [rsp+0xA0]
000075aec0bdad1a  vmovaps xmm11, [rsp+0xB0]
000075aec0bdad23  vmovaps xmm13, [rsp+0xC0]
000075aec0bdad2c  vmovaps xmm14, [rsp+0xD0]
000075aec0bdad35  vmovaps xmm15, [rsp+0xE0]
000075aec0bdad3e  add rsp, 0xF0
000075aec0bdad45  pop r11
000075aec0bdad47  pop r10
000075aec0bdad49  pop r9
000075aec0bdad4b  pop r8
000075aec0bdad4d  pop rsi
000075aec0bdad4e  pop rdi
000075aec0bdad4f  pop rdx
000075aec0bdad50  pop rcx
000075aec0bdad51  pop rax
000075aec0bdad52  add rsp, 0x08
000075aec0bdad56  jmp 0x000075AEC0BD6549
000075aec0bdad5b  sub rsp, 0x08
000075aec0bdad5f  push rax
000075aec0bdad60  push rcx
000075aec0bdad61  push rdx
000075aec0bdad62  push rdi
000075aec0bdad63  push rsi
000075aec0bdad64  push r8
000075aec0bdad66  push r9
000075aec0bdad68  push r10
000075aec0bdad6a  push r11
000075aec0bdad6c  sub rsp, 0xF0
000075aec0bdad73  vmovaps [rsp], xmm0
000075aec0bdad78  vmovaps [rsp+0x10], xmm1
000075aec0bdad7e  vmovaps [rsp+0x20], xmm2
000075aec0bdad84  vmovaps [rsp+0x30], xmm3
000075aec0bdad8a  vmovaps [rsp+0x40], xmm4
000075aec0bdad90  vmovaps [rsp+0x50], xmm5
000075aec0bdad96  vmovaps [rsp+0x60], xmm6
000075aec0bdad9c  vmovaps [rsp+0x70], xmm7
000075aec0bdada2  vmovaps [rsp+0x80], xmm8
000075aec0bdadab  vmovaps [rsp+0x90], xmm9
000075aec0bdadb4  vmovaps [rsp+0xA0], xmm10
000075aec0bdadbd  vmovaps [rsp+0xB0], xmm11
000075aec0bdadc6  vmovaps [rsp+0xC0], xmm12
000075aec0bdadcf  vmovaps [rsp+0xD0], xmm13
000075aec0bdadd8  vmovaps [rsp+0xE0], xmm15
000075aec0bdade1  sub rsp, 0x30
000075aec0bdade5  movaps [rsp], xmm14
000075aec0bdadea  movaps [rsp+0x10], xmm9
000075aec0bdadf0  movaps [rsp+0x20], xmm1
000075aec0bdadf5  lea rdi, [rsp]
000075aec0bdadf9  mov esi, 0x00
000075aec0bdadfe  mov rax, 0x57F4B31E6530
000075aec0bdae08  call rax
000075aec0bdae0a  movaps xmm14, [rsp]
000075aec0bdae0f  add rsp, 0x30
000075aec0bdae13  vmovaps xmm0, [rsp]
000075aec0bdae18  vmovaps xmm1, [rsp+0x10]
000075aec0bdae1e  vmovaps xmm2, [rsp+0x20]
000075aec0bdae24  vmovaps xmm3, [rsp+0x30]
000075aec0bdae2a  vmovaps xmm4, [rsp+0x40]
000075aec0bdae30  vmovaps xmm5, [rsp+0x50]
000075aec0bdae36  vmovaps xmm6, [rsp+0x60]
000075aec0bdae3c  vmovaps xmm7, [rsp+0x70]
000075aec0bdae42  vmovaps xmm8, [rsp+0x80]
000075aec0bdae4b  vmovaps xmm9, [rsp+0x90]
000075aec0bdae54  vmovaps xmm10, [rsp+0xA0]
000075aec0bdae5d  vmovaps xmm11, [rsp+0xB0]
000075aec0bdae66  vmovaps xmm12, [rsp+0xC0]
000075aec0bdae6f  vmovaps xmm13, [rsp+0xD0]
000075aec0bdae78  vmovaps xmm15, [rsp+0xE0]
000075aec0bdae81  add rsp, 0xF0
000075aec0bdae88  pop r11
000075aec0bdae8a  pop r10
000075aec0bdae8c  pop r9
000075aec0bdae8e  pop r8
000075aec0bdae90  pop rsi
000075aec0bdae91  pop rdi
000075aec0bdae92  pop rdx
000075aec0bdae93  pop rcx
000075aec0bdae94  pop rax
000075aec0bdae95  add rsp, 0x08
000075aec0bdae99  jmp 0x000075AEC0BD6578
000075aec0bdae9e  sub rsp, 0x08
000075aec0bdaea2  push rax
000075aec0bdaea3  push rcx
000075aec0bdaea4  push rdx
000075aec0bdaea5  push rdi
000075aec0bdaea6  push rsi
000075aec0bdaea7  push r8
000075aec0bdaea9  push r9
000075aec0bdaeab  push r10
000075aec0bdaead  push r11
000075aec0bdaeaf  sub rsp, 0xF0
000075aec0bdaeb6  vmovaps [rsp], xmm0
000075aec0bdaebb  vmovaps [rsp+0x10], xmm2
000075aec0bdaec1  vmovaps [rsp+0x20], xmm3
000075aec0bdaec7  vmovaps [rsp+0x30], xmm4
000075aec0bdaecd  vmovaps [rsp+0x40], xmm5
000075aec0bdaed3  vmovaps [rsp+0x50], xmm6
000075aec0bdaed9  vmovaps [rsp+0x60], xmm7
000075aec0bdaedf  vmovaps [rsp+0x70], xmm8
000075aec0bdaee5  vmovaps [rsp+0x80], xmm9
000075aec0bdaeee  vmovaps [rsp+0x90], xmm10
000075aec0bdaef7  vmovaps [rsp+0xA0], xmm11
000075aec0bdaf00  vmovaps [rsp+0xB0], xmm12
000075aec0bdaf09  vmovaps [rsp+0xC0], xmm13
000075aec0bdaf12  vmovaps [rsp+0xD0], xmm14
000075aec0bdaf1b  vmovaps [rsp+0xE0], xmm15
000075aec0bdaf24  sub rsp, 0x30
000075aec0bdaf28  movaps [rsp], xmm1
000075aec0bdaf2c  movaps [rsp+0x10], xmm13
000075aec0bdaf32  movaps [rsp+0x20], xmm8
000075aec0bdaf38  lea rdi, [rsp]
000075aec0bdaf3c  mov esi, 0x00
000075aec0bdaf41  mov rax, 0x57F4B31E6530
000075aec0bdaf4b  call rax
000075aec0bdaf4d  movaps xmm1, [rsp]
000075aec0bdaf51  add rsp, 0x30
000075aec0bdaf55  vmovaps xmm0, [rsp]
000075aec0bdaf5a  vmovaps xmm2, [rsp+0x10]
000075aec0bdaf60  vmovaps xmm3, [rsp+0x20]
000075aec0bdaf66  vmovaps xmm4, [rsp+0x30]
000075aec0bdaf6c  vmovaps xmm5, [rsp+0x40]
000075aec0bdaf72  vmovaps xmm6, [rsp+0x50]
000075aec0bdaf78  vmovaps xmm7, [rsp+0x60]
000075aec0bdaf7e  vmovaps xmm8, [rsp+0x70]
000075aec0bdaf84  vmovaps xmm9, [rsp+0x80]
000075aec0bdaf8d  vmovaps xmm10, [rsp+0x90]
000075aec0bdaf96  vmovaps xmm11, [rsp+0xA0]
000075aec0bdaf9f  vmovaps xmm12, [rsp+0xB0]
000075aec0bdafa8  vmovaps xmm13, [rsp+0xC0]
000075aec0bdafb1  vmovaps xmm14, [rsp+0xD0]
000075aec0bdafba  vmovaps xmm15, [rsp+0xE0]
000075aec0bdafc3  add rsp, 0xF0
000075aec0bdafca  pop r11
000075aec0bdafcc  pop r10
000075aec0bdafce  pop r9
000075aec0bdafd0  pop r8
000075aec0bdafd2  pop rsi
000075aec0bdafd3  pop rdi
000075aec0bdafd4  pop rdx
000075aec0bdafd5  pop rcx
000075aec0bdafd6  pop rax
000075aec0bdafd7  add rsp, 0x08
000075aec0bdafdb  jmp 0x000075AEC0BD659A
000075aec0bdafe0  call 0x000075AEC0A0C260
000075aec0bdafe5  jmp 0x000075AEC0BD65A8
000075aec0bdafea  call 0x000075AEC0ADE950
000075aec0bdafef  jmp 0x000075AEC0BD65B2
000075aec0bdaff4  sub rsp, 0x08
000075aec0bdaff8  push rax
000075aec0bdaff9  push rcx
000075aec0bdaffa  push rdx
000075aec0bdaffb  push rdi
000075aec0bdaffc  push rsi
000075aec0bdaffd  push r8
000075aec0bdafff  push r9
000075aec0bdb001  push r10
000075aec0bdb003  push r11
000075aec0bdb005  sub rsp, 0xF0
000075aec0bdb00c  vmovaps [rsp], xmm0
000075aec0bdb011  vmovaps [rsp+0x10], xmm1
000075aec0bdb017  vmovaps [rsp+0x20], xmm2
000075aec0bdb01d  vmovaps [rsp+0x30], xmm3
000075aec0bdb023  vmovaps [rsp+0x40], xmm4
000075aec0bdb029  vmovaps [rsp+0x50], xmm5
000075aec0bdb02f  vmovaps [rsp+0x60], xmm6
000075aec0bdb035  vmovaps [rsp+0x70], xmm7
000075aec0bdb03b  vmovaps [rsp+0x80], xmm9
000075aec0bdb044  vmovaps [rsp+0x90], xmm10
000075aec0bdb04d  vmovaps [rsp+0xA0], xmm11
000075aec0bdb056  vmovaps [rsp+0xB0], xmm12
000075aec0bdb05f  vmovaps [rsp+0xC0], xmm13
000075aec0bdb068  vmovaps [rsp+0xD0], xmm14
000075aec0bdb071  vmovaps [rsp+0xE0], xmm15
000075aec0bdb07a  sub rsp, 0x30
000075aec0bdb07e  movaps [rsp], xmm8
000075aec0bdb083  movaps [rsp+0x10], xmm15
000075aec0bdb089  movaps [rsp+0x20], xmm7
000075aec0bdb08e  lea rdi, [rsp]
000075aec0bdb092  mov esi, 0x00
000075aec0bdb097  mov rax, 0x57F4B31E6530
000075aec0bdb0a1  call rax
000075aec0bdb0a3  movaps xmm8, [rsp]
000075aec0bdb0a8  add rsp, 0x30
000075aec0bdb0ac  vmovaps xmm0, [rsp]
000075aec0bdb0b1  vmovaps xmm1, [rsp+0x10]
000075aec0bdb0b7  vmovaps xmm2, [rsp+0x20]
000075aec0bdb0bd  vmovaps xmm3, [rsp+0x30]
000075aec0bdb0c3  vmovaps xmm4, [rsp+0x40]
000075aec0bdb0c9  vmovaps xmm5, [rsp+0x50]
000075aec0bdb0cf  vmovaps xmm6, [rsp+0x60]
000075aec0bdb0d5  vmovaps xmm7, [rsp+0x70]
000075aec0bdb0db  vmovaps xmm9, [rsp+0x80]
000075aec0bdb0e4  vmovaps xmm10, [rsp+0x90]
000075aec0bdb0ed  vmovaps xmm11, [rsp+0xA0]
000075aec0bdb0f6  vmovaps xmm12, [rsp+0xB0]
000075aec0bdb0ff  vmovaps xmm13, [rsp+0xC0]
000075aec0bdb108  vmovaps xmm14, [rsp+0xD0]
000075aec0bdb111  vmovaps xmm15, [rsp+0xE0]
000075aec0bdb11a  add rsp, 0xF0
000075aec0bdb121  pop r11
000075aec0bdb123  pop r10
000075aec0bdb125  pop r9
000075aec0bdb127  pop r8
000075aec0bdb129  pop rsi
000075aec0bdb12a  pop rdi
000075aec0bdb12b  pop rdx
000075aec0bdb12c  pop rcx
000075aec0bdb12d  pop rax
000075aec0bdb12e  add rsp, 0x08
000075aec0bdb132  jmp 0x000075AEC0BD65D4
000075aec0bdb137  sub rsp, 0x08
000075aec0bdb13b  push rax
000075aec0bdb13c  push rcx
000075aec0bdb13d  push rdx
000075aec0bdb13e  push rdi
000075aec0bdb13f  push rsi
000075aec0bdb140  push r8
000075aec0bdb142  push r9
000075aec0bdb144  push r10
000075aec0bdb146  push r11
000075aec0bdb148  sub rsp, 0xF0
000075aec0bdb14f  vmovaps [rsp], xmm0
000075aec0bdb154  vmovaps [rsp+0x10], xmm1
000075aec0bdb15a  vmovaps [rsp+0x20], xmm2
000075aec0bdb160  vmovaps [rsp+0x30], xmm3
000075aec0bdb166  vmovaps [rsp+0x40], xmm4
000075aec0bdb16c  vmovaps [rsp+0x50], xmm5
000075aec0bdb172  vmovaps [rsp+0x60], xmm6
000075aec0bdb178  vmovaps [rsp+0x70], xmm8
000075aec0bdb17e  vmovaps [rsp+0x80], xmm9
000075aec0bdb187  vmovaps [rsp+0x90], xmm10
000075aec0bdb190  vmovaps [rsp+0xA0], xmm11
000075aec0bdb199  vmovaps [rsp+0xB0], xmm12
000075aec0bdb1a2  vmovaps [rsp+0xC0], xmm13
000075aec0bdb1ab  vmovaps [rsp+0xD0], xmm14
000075aec0bdb1b4  vmovaps [rsp+0xE0], xmm15
000075aec0bdb1bd  sub rsp, 0x30
000075aec0bdb1c1  movaps [rsp], xmm7
000075aec0bdb1c5  movaps [rsp+0x10], xmm9
000075aec0bdb1cb  movaps [rsp+0x20], xmm15
000075aec0bdb1d1  lea rdi, [rsp]
000075aec0bdb1d5  mov esi, 0x00
000075aec0bdb1da  mov rax, 0x57F4B31E6530
000075aec0bdb1e4  call rax
000075aec0bdb1e6  movaps xmm7, [rsp]
000075aec0bdb1ea  add rsp, 0x30
000075aec0bdb1ee  vmovaps xmm0, [rsp]
000075aec0bdb1f3  vmovaps xmm1, [rsp+0x10]
000075aec0bdb1f9  vmovaps xmm2, [rsp+0x20]
000075aec0bdb1ff  vmovaps xmm3, [rsp+0x30]
000075aec0bdb205  vmovaps xmm4, [rsp+0x40]
000075aec0bdb20b  vmovaps xmm5, [rsp+0x50]
000075aec0bdb211  vmovaps xmm6, [rsp+0x60]
000075aec0bdb217  vmovaps xmm8, [rsp+0x70]
000075aec0bdb21d  vmovaps xmm9, [rsp+0x80]
000075aec0bdb226  vmovaps xmm10, [rsp+0x90]
000075aec0bdb22f  vmovaps xmm11, [rsp+0xA0]
000075aec0bdb238  vmovaps xmm12, [rsp+0xB0]
000075aec0bdb241  vmovaps xmm13, [rsp+0xC0]
000075aec0bdb24a  vmovaps xmm14, [rsp+0xD0]
000075aec0bdb253  vmovaps xmm15, [rsp+0xE0]
000075aec0bdb25c  add rsp, 0xF0
000075aec0bdb263  pop r11
000075aec0bdb265  pop r10
000075aec0bdb267  pop r9
000075aec0bdb269  pop r8
000075aec0bdb26b  pop rsi
000075aec0bdb26c  pop rdi
000075aec0bdb26d  pop rdx
000075aec0bdb26e  pop rcx
000075aec0bdb26f  pop rax
000075aec0bdb270  add rsp, 0x08
000075aec0bdb274  jmp 0x000075AEC0BD6601
000075aec0bdb279  sub rsp, 0x08
000075aec0bdb27d  push rax
000075aec0bdb27e  push rcx
000075aec0bdb27f  push rdx
000075aec0bdb280  push rdi
000075aec0bdb281  push rsi
000075aec0bdb282  push r8
000075aec0bdb284  push r9
000075aec0bdb286  push r10
000075aec0bdb288  push r11
000075aec0bdb28a  sub rsp, 0xF0
000075aec0bdb291  vmovaps [rsp], xmm0
000075aec0bdb296  vmovaps [rsp+0x10], xmm1
000075aec0bdb29c  vmovaps [rsp+0x20], xmm2
000075aec0bdb2a2  vmovaps [rsp+0x30], xmm3
000075aec0bdb2a8  vmovaps [rsp+0x40], xmm4
000075aec0bdb2ae  vmovaps [rsp+0x50], xmm5
000075aec0bdb2b4  vmovaps [rsp+0x60], xmm6
000075aec0bdb2ba  vmovaps [rsp+0x70], xmm7
000075aec0bdb2c0  vmovaps [rsp+0x80], xmm8
000075aec0bdb2c9  vmovaps [rsp+0x90], xmm10
000075aec0bdb2d2  vmovaps [rsp+0xA0], xmm11
000075aec0bdb2db  vmovaps [rsp+0xB0], xmm12
000075aec0bdb2e4  vmovaps [rsp+0xC0], xmm13
000075aec0bdb2ed  vmovaps [rsp+0xD0], xmm14
000075aec0bdb2f6  vmovaps [rsp+0xE0], xmm15
000075aec0bdb2ff  sub rsp, 0x30
000075aec0bdb303  movaps [rsp], xmm9
000075aec0bdb308  movaps [rsp+0x10], xmm13
000075aec0bdb30e  movaps [rsp+0x20], xmm15
000075aec0bdb314  lea rdi, [rsp]
000075aec0bdb318  mov esi, 0x00
000075aec0bdb31d  mov rax, 0x57F4B31E6530
000075aec0bdb327  call rax
000075aec0bdb329  movaps xmm9, [rsp]
000075aec0bdb32e  add rsp, 0x30
000075aec0bdb332  vmovaps xmm0, [rsp]
000075aec0bdb337  vmovaps xmm1, [rsp+0x10]
000075aec0bdb33d  vmovaps xmm2, [rsp+0x20]
000075aec0bdb343  vmovaps xmm3, [rsp+0x30]
000075aec0bdb349  vmovaps xmm4, [rsp+0x40]
000075aec0bdb34f  vmovaps xmm5, [rsp+0x50]
000075aec0bdb355  vmovaps xmm6, [rsp+0x60]
000075aec0bdb35b  vmovaps xmm7, [rsp+0x70]
000075aec0bdb361  vmovaps xmm8, [rsp+0x80]
000075aec0bdb36a  vmovaps xmm10, [rsp+0x90]
000075aec0bdb373  vmovaps xmm11, [rsp+0xA0]
000075aec0bdb37c  vmovaps xmm12, [rsp+0xB0]
000075aec0bdb385  vmovaps xmm13, [rsp+0xC0]
000075aec0bdb38e  vmovaps xmm14, [rsp+0xD0]
000075aec0bdb397  vmovaps xmm15, [rsp+0xE0]
000075aec0bdb3a0  add rsp, 0xF0
000075aec0bdb3a7  pop r11
000075aec0bdb3a9  pop r10
000075aec0bdb3ab  pop r9
000075aec0bdb3ad  pop r8
000075aec0bdb3af  pop rsi
000075aec0bdb3b0  pop rdi
000075aec0bdb3b1  pop rdx
000075aec0bdb3b2  pop rcx
000075aec0bdb3b3  pop rax
000075aec0bdb3b4  add rsp, 0x08
000075aec0bdb3b8  jmp 0x000075AEC0BD662F
000075aec0bdb3bd  sub rsp, 0x08
000075aec0bdb3c1  push rax
000075aec0bdb3c2  push rcx
000075aec0bdb3c3  push rdx
000075aec0bdb3c4  push rdi
000075aec0bdb3c5  push rsi
000075aec0bdb3c6  push r8
000075aec0bdb3c8  push r9
000075aec0bdb3ca  push r10
000075aec0bdb3cc  push r11
000075aec0bdb3ce  sub rsp, 0xF0
000075aec0bdb3d5  vmovaps [rsp], xmm0
000075aec0bdb3da  vmovaps [rsp+0x10], xmm1
000075aec0bdb3e0  vmovaps [rsp+0x20], xmm2
000075aec0bdb3e6  vmovaps [rsp+0x30], xmm3
000075aec0bdb3ec  vmovaps [rsp+0x40], xmm4
000075aec0bdb3f2  vmovaps [rsp+0x50], xmm5
000075aec0bdb3f8  vmovaps [rsp+0x60], xmm6
000075aec0bdb3fe  vmovaps [rsp+0x70], xmm7
000075aec0bdb404  vmovaps [rsp+0x80], xmm8
000075aec0bdb40d  vmovaps [rsp+0x90], xmm9
000075aec0bdb416  vmovaps [rsp+0xA0], xmm10
000075aec0bdb41f  vmovaps [rsp+0xB0], xmm11
000075aec0bdb428  vmovaps [rsp+0xC0], xmm12
000075aec0bdb431  vmovaps [rsp+0xD0], xmm13
000075aec0bdb43a  vmovaps [rsp+0xE0], xmm14
000075aec0bdb443  sub rsp, 0x30
000075aec0bdb447  movaps [rsp], xmm15
000075aec0bdb44c  movaps [rsp+0x10], xmm11
000075aec0bdb452  movaps [rsp+0x20], xmm12
000075aec0bdb458  lea rdi, [rsp]
000075aec0bdb45c  mov esi, 0x00
000075aec0bdb461  mov rax, 0x57F4B31E6530
000075aec0bdb46b  call rax
000075aec0bdb46d  movaps xmm15, [rsp]
000075aec0bdb472  add rsp, 0x30
000075aec0bdb476  vmovaps xmm0, [rsp]
000075aec0bdb47b  vmovaps xmm1, [rsp+0x10]
000075aec0bdb481  vmovaps xmm2, [rsp+0x20]
000075aec0bdb487  vmovaps xmm3, [rsp+0x30]
000075aec0bdb48d  vmovaps xmm4, [rsp+0x40]
000075aec0bdb493  vmovaps xmm5, [rsp+0x50]
000075aec0bdb499  vmovaps xmm6, [rsp+0x60]
000075aec0bdb49f  vmovaps xmm7, [rsp+0x70]
000075aec0bdb4a5  vmovaps xmm8, [rsp+0x80]
000075aec0bdb4ae  vmovaps xmm9, [rsp+0x90]
000075aec0bdb4b7  vmovaps xmm10, [rsp+0xA0]
000075aec0bdb4c0  vmovaps xmm11, [rsp+0xB0]
000075aec0bdb4c9  vmovaps xmm12, [rsp+0xC0]
000075aec0bdb4d2  vmovaps xmm13, [rsp+0xD0]
000075aec0bdb4db  vmovaps xmm14, [rsp+0xE0]
000075aec0bdb4e4  add rsp, 0xF0
000075aec0bdb4eb  pop r11
000075aec0bdb4ed  pop r10
000075aec0bdb4ef  pop r9
000075aec0bdb4f1  pop r8
000075aec0bdb4f3  pop rsi
000075aec0bdb4f4  pop rdi
000075aec0bdb4f5  pop rdx
000075aec0bdb4f6  pop rcx
000075aec0bdb4f7  pop rax
000075aec0bdb4f8  add rsp, 0x08
000075aec0bdb4fc  jmp 0x000075AEC0BD664A
000075aec0bdb501  sub rsp, 0x08
000075aec0bdb505  push rax
000075aec0bdb506  push rcx
000075aec0bdb507  push rdx
000075aec0bdb508  push rdi
000075aec0bdb509  push rsi
000075aec0bdb50a  push r8
000075aec0bdb50c  push r9
000075aec0bdb50e  push r10
000075aec0bdb510  push r11
000075aec0bdb512  sub rsp, 0xF0
000075aec0bdb519  vmovaps [rsp], xmm0
000075aec0bdb51e  vmovaps [rsp+0x10], xmm1
000075aec0bdb524  vmovaps [rsp+0x20], xmm2
000075aec0bdb52a  vmovaps [rsp+0x30], xmm3
000075aec0bdb530  vmovaps [rsp+0x40], xmm4
000075aec0bdb536  vmovaps [rsp+0x50], xmm5
000075aec0bdb53c  vmovaps [rsp+0x60], xmm6
000075aec0bdb542  vmovaps [rsp+0x70], xmm7
000075aec0bdb548  vmovaps [rsp+0x80], xmm8
000075aec0bdb551  vmovaps [rsp+0x90], xmm9
000075aec0bdb55a  vmovaps [rsp+0xA0], xmm10
000075aec0bdb563  vmovaps [rsp+0xB0], xmm11
000075aec0bdb56c  vmovaps [rsp+0xC0], xmm12
000075aec0bdb575  vmovaps [rsp+0xD0], xmm14
000075aec0bdb57e  vmovaps [rsp+0xE0], xmm15
000075aec0bdb587  sub rsp, 0x30
000075aec0bdb58b  movaps [rsp], xmm13
000075aec0bdb590  movaps [rsp+0x10], xmm10
000075aec0bdb596  movaps [rsp+0x20], xmm14
000075aec0bdb59c  lea rdi, [rsp]
000075aec0bdb5a0  mov esi, 0x00
000075aec0bdb5a5  mov rax, 0x57F4B31E6530
000075aec0bdb5af  call rax
000075aec0bdb5b1  movaps xmm13, [rsp]
000075aec0bdb5b6  add rsp, 0x30
000075aec0bdb5ba  vmovaps xmm0, [rsp]
000075aec0bdb5bf  vmovaps xmm1, [rsp+0x10]
000075aec0bdb5c5  vmovaps xmm2, [rsp+0x20]
000075aec0bdb5cb  vmovaps xmm3, [rsp+0x30]
000075aec0bdb5d1  vmovaps xmm4, [rsp+0x40]
000075aec0bdb5d7  vmovaps xmm5, [rsp+0x50]
000075aec0bdb5dd  vmovaps xmm6, [rsp+0x60]
000075aec0bdb5e3  vmovaps xmm7, [rsp+0x70]
000075aec0bdb5e9  vmovaps xmm8, [rsp+0x80]
000075aec0bdb5f2  vmovaps xmm9, [rsp+0x90]
000075aec0bdb5fb  vmovaps xmm10, [rsp+0xA0]
000075aec0bdb604  vmovaps xmm11, [rsp+0xB0]
000075aec0bdb60d  vmovaps xmm12, [rsp+0xC0]
000075aec0bdb616  vmovaps xmm14, [rsp+0xD0]
000075aec0bdb61f  vmovaps xmm15, [rsp+0xE0]
000075aec0bdb628  add rsp, 0xF0
000075aec0bdb62f  pop r11
000075aec0bdb631  pop r10
000075aec0bdb633  pop r9
000075aec0bdb635  pop r8
000075aec0bdb637  pop rsi
000075aec0bdb638  pop rdi
000075aec0bdb639  pop rdx
000075aec0bdb63a  pop rcx
000075aec0bdb63b  pop rax
000075aec0bdb63c  add rsp, 0x08
000075aec0bdb640  jmp 0x000075AEC0BD666D
000075aec0bdb645  sub rsp, 0x08
000075aec0bdb649  push rax
000075aec0bdb64a  push rcx
000075aec0bdb64b  push rdx
000075aec0bdb64c  push rdi
000075aec0bdb64d  push rsi
000075aec0bdb64e  push r8
000075aec0bdb650  push r9
000075aec0bdb652  push r10
000075aec0bdb654  push r11
000075aec0bdb656  sub rsp, 0xF0
000075aec0bdb65d  vmovaps [rsp], xmm0
000075aec0bdb662  vmovaps [rsp+0x10], xmm1
000075aec0bdb668  vmovaps [rsp+0x20], xmm2
000075aec0bdb66e  vmovaps [rsp+0x30], xmm3
000075aec0bdb674  vmovaps [rsp+0x40], xmm4
000075aec0bdb67a  vmovaps [rsp+0x50], xmm5
000075aec0bdb680  vmovaps [rsp+0x60], xmm6
000075aec0bdb686  vmovaps [rsp+0x70], xmm7
000075aec0bdb68c  vmovaps [rsp+0x80], xmm8
000075aec0bdb695  vmovaps [rsp+0x90], xmm9
000075aec0bdb69e  vmovaps [rsp+0xA0], xmm10
000075aec0bdb6a7  vmovaps [rsp+0xB0], xmm11
000075aec0bdb6b0  vmovaps [rsp+0xC0], xmm12
000075aec0bdb6b9  vmovaps [rsp+0xD0], xmm13
000075aec0bdb6c2  vmovaps [rsp+0xE0], xmm15
000075aec0bdb6cb  sub rsp, 0x30
000075aec0bdb6cf  movaps [rsp], xmm14
000075aec0bdb6d4  movaps [rsp+0x10], xmm1
000075aec0bdb6d9  movaps [rsp+0x20], xmm7
000075aec0bdb6de  lea rdi, [rsp]
000075aec0bdb6e2  mov esi, 0x00
000075aec0bdb6e7  mov rax, 0x57F4B31E6530
000075aec0bdb6f1  call rax
000075aec0bdb6f3  movaps xmm14, [rsp]
000075aec0bdb6f8  add rsp, 0x30
000075aec0bdb6fc  vmovaps xmm0, [rsp]
000075aec0bdb701  vmovaps xmm1, [rsp+0x10]
000075aec0bdb707  vmovaps xmm2, [rsp+0x20]
000075aec0bdb70d  vmovaps xmm3, [rsp+0x30]
000075aec0bdb713  vmovaps xmm4, [rsp+0x40]
000075aec0bdb719  vmovaps xmm5, [rsp+0x50]
000075aec0bdb71f  vmovaps xmm6, [rsp+0x60]
000075aec0bdb725  vmovaps xmm7, [rsp+0x70]
000075aec0bdb72b  vmovaps xmm8, [rsp+0x80]
000075aec0bdb734  vmovaps xmm9, [rsp+0x90]
000075aec0bdb73d  vmovaps xmm10, [rsp+0xA0]
000075aec0bdb746  vmovaps xmm11, [rsp+0xB0]
000075aec0bdb74f  vmovaps xmm12, [rsp+0xC0]
000075aec0bdb758  vmovaps xmm13, [rsp+0xD0]
000075aec0bdb761  vmovaps xmm15, [rsp+0xE0]
000075aec0bdb76a  add rsp, 0xF0
000075aec0bdb771  pop r11
000075aec0bdb773  pop r10
000075aec0bdb775  pop r9
000075aec0bdb777  pop r8
000075aec0bdb779  pop rsi
000075aec0bdb77a  pop rdi
000075aec0bdb77b  pop rdx
000075aec0bdb77c  pop rcx
000075aec0bdb77d  pop rax
000075aec0bdb77e  add rsp, 0x08
000075aec0bdb782  jmp 0x000075AEC0BD6690
000075aec0bdb787  sub rsp, 0x08
000075aec0bdb78b  push rax
000075aec0bdb78c  push rcx
000075aec0bdb78d  push rdx
000075aec0bdb78e  push rdi
000075aec0bdb78f  push rsi
000075aec0bdb790  push r8
000075aec0bdb792  push r9
000075aec0bdb794  push r10
000075aec0bdb796  push r11
000075aec0bdb798  sub rsp, 0xF0
000075aec0bdb79f  vmovaps [rsp], xmm0
000075aec0bdb7a4  vmovaps [rsp+0x10], xmm2
000075aec0bdb7aa  vmovaps [rsp+0x20], xmm3
000075aec0bdb7b0  vmovaps [rsp+0x30], xmm4
000075aec0bdb7b6  vmovaps [rsp+0x40], xmm5
000075aec0bdb7bc  vmovaps [rsp+0x50], xmm6
000075aec0bdb7c2  vmovaps [rsp+0x60], xmm7
000075aec0bdb7c8  vmovaps [rsp+0x70], xmm8
000075aec0bdb7ce  vmovaps [rsp+0x80], xmm9
000075aec0bdb7d7  vmovaps [rsp+0x90], xmm10
000075aec0bdb7e0  vmovaps [rsp+0xA0], xmm11
000075aec0bdb7e9  vmovaps [rsp+0xB0], xmm12
000075aec0bdb7f2  vmovaps [rsp+0xC0], xmm13
000075aec0bdb7fb  vmovaps [rsp+0xD0], xmm14
000075aec0bdb804  vmovaps [rsp+0xE0], xmm15
000075aec0bdb80d  sub rsp, 0x30
000075aec0bdb811  movaps [rsp], xmm1
000075aec0bdb815  movaps [rsp+0x10], xmm8
000075aec0bdb81b  movaps [rsp+0x20], xmm9
000075aec0bdb821  lea rdi, [rsp]
000075aec0bdb825  mov esi, 0x00
000075aec0bdb82a  mov rax, 0x57F4B31E6530
000075aec0bdb834  call rax
000075aec0bdb836  movaps xmm1, [rsp]
000075aec0bdb83a  add rsp, 0x30
000075aec0bdb83e  vmovaps xmm0, [rsp]
000075aec0bdb843  vmovaps xmm2, [rsp+0x10]
000075aec0bdb849  vmovaps xmm3, [rsp+0x20]
000075aec0bdb84f  vmovaps xmm4, [rsp+0x30]
000075aec0bdb855  vmovaps xmm5, [rsp+0x40]
000075aec0bdb85b  vmovaps xmm6, [rsp+0x50]
000075aec0bdb861  vmovaps xmm7, [rsp+0x60]
000075aec0bdb867  vmovaps xmm8, [rsp+0x70]
000075aec0bdb86d  vmovaps xmm9, [rsp+0x80]
000075aec0bdb876  vmovaps xmm10, [rsp+0x90]
000075aec0bdb87f  vmovaps xmm11, [rsp+0xA0]
000075aec0bdb888  vmovaps xmm12, [rsp+0xB0]
000075aec0bdb891  vmovaps xmm13, [rsp+0xC0]
000075aec0bdb89a  vmovaps xmm14, [rsp+0xD0]
000075aec0bdb8a3  vmovaps xmm15, [rsp+0xE0]
000075aec0bdb8ac  add rsp, 0xF0
000075aec0bdb8b3  pop r11
000075aec0bdb8b5  pop r10
000075aec0bdb8b7  pop r9
000075aec0bdb8b9  pop r8
000075aec0bdb8bb  pop rsi
000075aec0bdb8bc  pop rdi
000075aec0bdb8bd  pop rdx
000075aec0bdb8be  pop rcx
000075aec0bdb8bf  pop rax
000075aec0bdb8c0  add rsp, 0x08
000075aec0bdb8c4  jmp 0x000075AEC0BD66B2
000075aec0bdb8c9  call 0x000075AEC0AB3E40
000075aec0bdb8ce  jmp 0x000075AEC0BD66C0
000075aec0bdb8d3  call 0x000075AEC0A0C380
000075aec0bdb8d8  jmp 0x000075AEC0BD66CA
000075aec0bdb8dd  call 0x000075AEC0A0D600
000075aec0bdb8e2  jmp 0x000075AEC0BD66D4
000075aec0bdb8e7  call 0x000075AEC09FF540
000075aec0bdb8ec  jmp 0x000075AEC0BD66DE
000075aec0bdb8f1  int3
000075aec0bdb8f2  nop [rax+rax*1], ax
000075aec0bdb8fb  nop [rax+rax*1], eax
000075aec0bdb900  mov eax, [r15+0x48]
000075aec0bdb904  lea r14d, [eax+0x01]
000075aec0bdb909  mov [rsp+0x10], r14d
000075aec0bdb90e  mov r14d, r14d
000075aec0bdb911  mov [r15+0x48], r14
000075aec0bdb915  xor eax, eax
000075aec0bdb917  mov r14d, [rsp+0x10]
000075aec0bdb91c  cmp r14d, 0x1F4
000075aec0bdb923  cmc
000075aec0bdb924  lahf
000075aec0bdb925  seto al
000075aec0bdb928  mov [r15+0x108], eax
000075aec0bdb92f  mov eax, [r15+0x108]
000075aec0bdb936  sahf
000075aec0bdb937  jnz 0x000075AEC0BDB969
000075aec0bdb939  cmp dword ptr [r15+0x318], 0x00
000075aec0bdb941  jz 0x000075AEC0BE1AB0
000075aec0bdb947  nop [rax+rax*1], ax
000075aec0bdb950  nop [rax+rax*1], eax
000075aec0bdb958  mov eax, 0x410450
000075aec0bdb95d  mov [r15+0x100], rax
000075aec0bdb964  jmp 0x000075AEC09FE110
000075aec0bdb969  cmp dword ptr [r15+0x318], 0x00
000075aec0bdb971  jz 0x000075AEC0BDB9A0
000075aec0bdb977  nop [rax+rax*1], ax
000075aec0bdb980  nop [rax+rax*1], eax
000075aec0bdb988  mov eax, 0x410274
000075aec0bdb98d  mov [r15+0x100], rax
000075aec0bdb994  jmp 0x000075AEC09FE110
000075aec0bdb999  int3
000075aec0bdb99a  int3
000075aec0bdb99b  nop [rax+rax*1], eax
000075aec0bdb9a0  mov rax, [r15+0x40]
000075aec0bdb9a4  movaps xmm1, [r15+0x1D0]
000075aec0bdb9ac  vmovaps [rsp+0x10], xmm1
000075aec0bdb9b2  vmovaps xmm15, [rsp+0x10]
000075aec0bdb9b8  por xmm1, xmm15
000075aec0bdb9bd  movaps xmm14, [r15+0x1A0]
000075aec0bdb9c5  vmovaps [rsp+0x10], xmm14
000075aec0bdb9cb  vmovaps xmm13, [rsp+0x10]
000075aec0bdb9d1  por xmm14, xmm13
000075aec0bdb9d6  lea r14, [rax+0x30]
000075aec0bdb9da  mov r12, [r13+r14*1]
000075aec0bdb9df  lea r14, [rax+0x38]
000075aec0bdb9e3  mov r11, [r13+r14*1]
000075aec0bdb9e8  movq xmm13, r12
000075aec0bdb9ed  movq xmm12, r11
000075aec0bdb9f2  movq xmm13, xmm13
000075aec0bdb9f7  vmovaps [rsp+0x10], xmm13
000075aec0bdb9fd  movq xmm13, xmm13
000075aec0bdba02  movaps [r15+0x130], xmm13
000075aec0bdba0a  movq xmm12, xmm12
000075aec0bdba0f  vmovaps [rsp+0x20], xmm12
000075aec0bdba15  movq xmm12, xmm12
000075aec0bdba1a  movaps [r15+0x280], xmm12
000075aec0bdba22  movaps xmm13, [r15+0x270]
000075aec0bdba2a  vmovaps [rsp+0x30], xmm13
000075aec0bdba30  vmovaps xmm12, [rsp+0x30]
000075aec0bdba36  por xmm13, xmm12
000075aec0bdba3b  lea r14, [rax+0x20]
000075aec0bdba3f  mov r12, [r13+r14*1]
000075aec0bdba44  lea r14, [rax+0x28]
000075aec0bdba48  mov r11, [r13+r14*1]
000075aec0bdba4d  movq xmm12, r12
000075aec0bdba52  movq xmm11, r11
000075aec0bdba57  movq xmm12, xmm12
000075aec0bdba5c  vmovaps [rsp+0x30], xmm12
000075aec0bdba62  movq xmm12, xmm12
000075aec0bdba67  movaps [r15+0x150], xmm12
000075aec0bdba6f  movq xmm11, xmm11
000075aec0bdba74  vmovaps [rsp+0x40], xmm11
000075aec0bdba7a  movq xmm11, xmm11
000075aec0bdba7f  movaps [r15+0x140], xmm11
000075aec0bdba87  lea r14, [rax+0x10]
000075aec0bdba8b  mov r12, [r13+r14*1]
000075aec0bdba90  lea r14, [rax+0x18]
000075aec0bdba94  mov r11, [r13+r14*1]
000075aec0bdba99  movq xmm12, r12
000075aec0bdba9e  movq xmm11, r11
000075aec0bdbaa3  movq xmm12, xmm12
000075aec0bdbaa8  vmovaps [rsp+0x50], xmm12
000075aec0bdbaae  movq xmm12, xmm12
000075aec0bdbab3  movaps [r15+0x170], xmm12
000075aec0bdbabb  movq xmm11, xmm11
000075aec0bdbac0  vmovaps [rsp+0x60], xmm11
000075aec0bdbac6  movq xmm11, xmm11
000075aec0bdbacb  movaps [r15+0x160], xmm11
000075aec0bdbad3  mov r14, [r13+rax*1]
000075aec0bdbad8  vmovq xmm12, r14
000075aec0bdbadd  vpbroadcastq xmm12, xmm12
000075aec0bdbae2  lea r14, [rax+0x08]
000075aec0bdbae6  mov rax, [r13+r14*1]
000075aec0bdbaeb  movq xmm11, rax
000075aec0bdbaf0  movaps [r15+0x230], xmm11
000075aec0bdbaf8  mov rax, [r15+0xF8]
000075aec0bdbaff  lea r14, [rax+0x50]
000075aec0bdbb03  movups xmm11, [r13+r14*1]
000075aec0bdbb09  lea r14, [rax+0x60]
000075aec0bdbb0d  movups xmm10, [r13+r14*1]
000075aec0bdbb13  lea r14, [rax+0x30]
000075aec0bdbb17  movups xmm9, [r13+r14*1]
000075aec0bdbb1d  mov r14, [r15+0x50]
000075aec0bdbb21  mov [r15+0x60], r14
000075aec0bdbb25  mov qword ptr [r15+0x58], 0x40
000075aec0bdbb2d  movaps xmm8, xmm12
000075aec0bdbb31  mulpd xmm8, xmm15
000075aec0bdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000075aec0bdbb3c  ptest xmm7, xmm7
000075aec0bdbb41  jnz 0x000075AEC0BDC96A
000075aec0bdbb47  movq xmm15, qword ptr [r15+0x230]
000075aec0bdbb50  vmovaps [rsp+0x70], xmm15
000075aec0bdbb56  vpermilpd xmm15, xmm15, 0x00
000075aec0bdbb5c  movaps xmm7, xmm9
000075aec0bdbb60  mulpd xmm7, xmm15
000075aec0bdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000075aec0bdbb6a  ptest xmm6, xmm6
000075aec0bdbb6f  jnz 0x000075AEC0BDCAAE
000075aec0bdbb75  vxorps xmm15, xmm15, xmm15
000075aec0bdbb7a  vpbroadcastq xmm15, xmm15
000075aec0bdbb7f  movaps xmm9, xmm12
000075aec0bdbb83  mulpd xmm9, xmm10
000075aec0bdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000075aec0bdbb8e  ptest xmm6, xmm6
000075aec0bdbb93  jnz 0x000075AEC0BDCBF0
000075aec0bdbb99  movaps xmm10, xmm12
000075aec0bdbb9d  mulpd xmm10, xmm11
000075aec0bdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000075aec0bdbba8  ptest xmm6, xmm6
000075aec0bdbbad  jnz 0x000075AEC0BDCD34
000075aec0bdbbb3  movaps xmm11, [r15+0x1F0]
000075aec0bdbbbb  movaps xmm6, xmm12
000075aec0bdbbbf  mulpd xmm6, xmm11
000075aec0bdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000075aec0bdbbc9  ptest xmm5, xmm5
000075aec0bdbbce  jnz 0x000075AEC0BDCE78
000075aec0bdbbd4  movaps xmm12, [r15+0x2A0]
000075aec0bdbbdc  vmovaps [rsp+0x80], xmm12
000075aec0bdbbe5  vmovaps xmm11, [rsp+0x80]
000075aec0bdbbee  por xmm12, xmm11
000075aec0bdbbf3  movaps xmm11, [r15+0x250]
000075aec0bdbbfb  vmovaps [rsp+0x80], xmm11
000075aec0bdbc04  vmovaps xmm5, [rsp+0x80]
000075aec0bdbc0d  por xmm11, xmm5
000075aec0bdbc12  vmovaps xmm4, [rsp+0x70]
000075aec0bdbc18  vpermilpd xmm4, xmm4, 0x00
000075aec0bdbc1e  movaps xmm3, xmm5
000075aec0bdbc21  mulpd xmm3, xmm4
000075aec0bdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000075aec0bdbc2a  ptest xmm2, xmm2
000075aec0bdbc2f  jnz 0x000075AEC0BDCFBA
000075aec0bdbc35  mov [rsp+0x80], rax
000075aec0bdbc3d  xor eax, eax
000075aec0bdbc3f  mov r12d, 0x40
000075aec0bdbc45  mov r11d, 0x200
000075aec0bdbc4b  cmp r12, r11
000075aec0bdbc4e  cmc
000075aec0bdbc4f  lahf
000075aec0bdbc50  seto al
000075aec0bdbc53  mov [r15+0x108], eax
000075aec0bdbc5a  movaps xmm5, xmm8
000075aec0bdbc5e  addpd xmm5, xmm15
000075aec0bdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000075aec0bdbc68  ptest xmm4, xmm4
000075aec0bdbc6d  jnz 0x000075AEC0BDD0FA
000075aec0bdbc73  movaps xmm8, [r15+0x1B0]
000075aec0bdbc7b  movaps xmm4, xmm9
000075aec0bdbc7f  addpd xmm4, xmm8
000075aec0bdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000075aec0bdbc89  ptest xmm2, xmm2
000075aec0bdbc8e  jnz 0x000075AEC0BDD23C
000075aec0bdbc94  movaps xmm9, xmm10
000075aec0bdbc98  addpd xmm9, xmm8
000075aec0bdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000075aec0bdbca3  ptest xmm2, xmm2
000075aec0bdbca8  jnz 0x000075AEC0BDD37E
000075aec0bdbcae  movaps xmm10, [r15+0x2F0]
000075aec0bdbcb6  vmovaps [rsp+0x90], xmm10
000075aec0bdbcbf  vmovaps xmm8, [rsp+0x90]
000075aec0bdbcc8  por xmm10, xmm8
000075aec0bdbccd  movaps xmm8, [r15+0x2E0]
000075aec0bdbcd5  vmovaps [rsp+0x90], xmm8
000075aec0bdbcde  vmovaps xmm2, [rsp+0x90]
000075aec0bdbce7  por xmm8, xmm2
000075aec0bdbcec  movaps xmm2, [r15+0x2D0]
000075aec0bdbcf4  vmovaps [rsp+0x90], xmm2
000075aec0bdbcfd  vmovaps [rsp+0xA0], xmm1
000075aec0bdbd06  vmovaps xmm1, [rsp+0x90]
000075aec0bdbd0f  por xmm2, xmm1
000075aec0bdbd13  movaps xmm1, [r15+0x200]
000075aec0bdbd1b  vmovaps [rsp+0x90], xmm1
000075aec0bdbd24  vmovaps [rsp+0xB0], xmm15
000075aec0bdbd2d  vmovaps xmm15, [rsp+0x90]
000075aec0bdbd36  por xmm1, xmm15
000075aec0bdbd3b  movaps xmm15, [r15+0x1C0]
000075aec0bdbd43  vmovaps [rsp+0x90], xmm15
000075aec0bdbd4c  vmovaps [rsp+0xC0], xmm1
000075aec0bdbd55  vmovaps xmm1, [rsp+0x90]
000075aec0bdbd5e  por xmm15, xmm1
000075aec0bdbd63  movaps xmm1, [r15+0x190]
000075aec0bdbd6b  vmovaps [rsp+0x90], xmm1
000075aec0bdbd74  vmovaps [rsp+0xD0], xmm15
000075aec0bdbd7d  vmovaps xmm15, [rsp+0x90]
000075aec0bdbd86  por xmm1, xmm15
000075aec0bdbd8b  movaps xmm15, [r15+0x300]
000075aec0bdbd93  vmovaps [rsp+0x90], xmm15
000075aec0bdbd9c  vmovaps [rsp+0xE0], xmm1
000075aec0bdbda5  vmovaps xmm1, [rsp+0x90]
000075aec0bdbdae  por xmm15, xmm1
000075aec0bdbdb3  mov rax, [rsp+0x80]
000075aec0bdbdbb  lea r12, [rax+0xA0]
000075aec0bdbdc2  movups xmm1, [r13+r12*1]
000075aec0bdbdc8  lea r12, [rax+0xB0]
000075aec0bdbdcf  vmovaps [rsp+0x80], xmm1
000075aec0bdbdd8  movups xmm1, [r13+r12*1]
000075aec0bdbdde  vmovaps [rsp+0x90], xmm1
000075aec0bdbde7  vmovaps [rsp+0xF0], xmm15
000075aec0bdbdf0  vmovaps xmm15, [rsp+0xB0]
000075aec0bdbdf9  vmovaps [rsp+0xB0], xmm14
000075aec0bdbe02  movaps xmm1, xmm6
000075aec0bdbe05  addpd xmm1, xmm15
000075aec0bdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000075aec0bdbe0f  ptest xmm14, xmm14
000075aec0bdbe15  jnz 0x000075AEC0BDD4D6
000075aec0bdbe1b  lea r12, [rax+0xF0]
000075aec0bdbe22  movups xmm15, [r13+r12*1]
000075aec0bdbe28  movaps xmm14, xmm4
000075aec0bdbe2c  addpd xmm14, xmm3
000075aec0bdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000075aec0bdbe37  ptest xmm6, xmm6
000075aec0bdbe3c  jnz 0x000075AEC0BDD621
000075aec0bdbe42  movaps xmm6, xmm9
000075aec0bdbe46  addpd xmm6, xmm7
000075aec0bdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000075aec0bdbe4f  ptest xmm4, xmm4
000075aec0bdbe54  jnz 0x000075AEC0BDD763
000075aec0bdbe5a  vmovaps xmm9, [rsp+0x70]
000075aec0bdbe60  vpermilpd xmm9, xmm9, 0x00
000075aec0bdbe66  vmovaps xmm4, [rsp+0x90]
000075aec0bdbe6f  movaps xmm7, xmm4
000075aec0bdbe72  mulpd xmm7, xmm9
000075aec0bdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000075aec0bdbe7c  ptest xmm3, xmm3
000075aec0bdbe81  jnz 0x000075AEC0BDD8A4
000075aec0bdbe87  vmovaps xmm9, [rsp+0x50]
000075aec0bdbe8d  vpermilpd xmm9, xmm9, 0x00
000075aec0bdbe93  movaps xmm4, xmm15
000075aec0bdbe97  mulpd xmm4, xmm9
000075aec0bdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000075aec0bdbea1  ptest xmm3, xmm3
000075aec0bdbea6  jnz 0x000075AEC0BDD9E5
000075aec0bdbeac  lea r12, [rax+0xE0]
000075aec0bdbeb3  movups xmm15, [r13+r12*1]
000075aec0bdbeb9  vmovaps xmm9, [rsp+0x70]
000075aec0bdbebf  vpermilpd xmm9, xmm9, 0x00
000075aec0bdbec5  vmovaps [rsp+0x70], xmm1
000075aec0bdbecb  vmovaps xmm1, [rsp+0x80]
000075aec0bdbed4  vmovaps [rsp+0x80], xmm15
000075aec0bdbedd  movaps xmm3, xmm1
000075aec0bdbee0  mulpd xmm3, xmm9
000075aec0bdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000075aec0bdbeea  ptest xmm15, xmm15
000075aec0bdbef0  jnz 0x000075AEC0BDDB31
000075aec0bdbef6  vmovaps xmm1, [rsp+0xF0]
000075aec0bdbeff  vmovaps xmm15, [rsp+0xF0]
000075aec0bdbf08  por xmm1, xmm15
000075aec0bdbf0d  movaps [r15+0x300], xmm1
000075aec0bdbf15  vmovaps xmm15, [rsp+0xE0]
000075aec0bdbf1e  vmovaps xmm9, [rsp+0xE0]
000075aec0bdbf27  por xmm15, xmm9
000075aec0bdbf2c  movaps [r15+0x190], xmm15
000075aec0bdbf34  vmovaps xmm9, [rsp+0x50]
000075aec0bdbf3a  vpermilpd xmm9, xmm9, 0x00
000075aec0bdbf40  vmovaps [rsp+0x90], xmm1
000075aec0bdbf49  vmovaps [rsp+0xE0], xmm15
000075aec0bdbf52  vmovaps xmm15, [rsp+0x80]
000075aec0bdbf5b  vmovaps [rsp+0x80], xmm14
000075aec0bdbf64  movaps xmm1, xmm15
000075aec0bdbf68  mulpd xmm1, xmm9
000075aec0bdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000075aec0bdbf72  ptest xmm14, xmm14
000075aec0bdbf78  jnz 0x000075AEC0BDDC72
000075aec0bdbf7e  lea r12, [rax+0x90]
000075aec0bdbf85  movups xmm15, [r13+r12*1]
000075aec0bdbf8b  vmovaps xmm14, [rsp+0xD0]
000075aec0bdbf94  vmovaps xmm9, [rsp+0xD0]
000075aec0bdbf9d  por xmm14, xmm9
000075aec0bdbfa2  movaps [r15+0x1C0], xmm14
000075aec0bdbfaa  vmovaps xmm9, [rsp+0xC0]
000075aec0bdbfb3  vmovaps [rsp+0xD0], xmm1
000075aec0bdbfbc  vmovaps xmm1, [rsp+0xC0]
000075aec0bdbfc5  por xmm9, xmm1
000075aec0bdbfca  movaps [r15+0x200], xmm9
000075aec0bdbfd2  vmovaps [rsp+0xC0], xmm2
000075aec0bdbfdb  vmovaps xmm1, [rsp+0xC0]
000075aec0bdbfe4  por xmm2, xmm1
000075aec0bdbfe8  movaps [r15+0x2D0], xmm2
000075aec0bdbff0  vmovaps [rsp+0xC0], xmm8
000075aec0bdbff9  vmovaps xmm1, [rsp+0xC0]
000075aec0bdc002  por xmm8, xmm1
000075aec0bdc007  movaps [r15+0x2E0], xmm8
000075aec0bdc00f  vmovaps [rsp+0xC0], xmm15
000075aec0bdc018  movaps xmm1, xmm5
000075aec0bdc01b  addpd xmm1, xmm7
000075aec0bdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000075aec0bdc024  ptest xmm15, xmm15
000075aec0bdc02a  jnz 0x000075AEC0BDDDBE
000075aec0bdc030  vmovaps xmm15, [rsp+0x50]
000075aec0bdc036  vpermilpd xmm15, xmm15, 0x00
000075aec0bdc03c  vmovaps xmm5, [rsp+0xC0]
000075aec0bdc045  vmovaps [rsp+0xC0], xmm1
000075aec0bdc04e  movaps xmm7, xmm5
000075aec0bdc051  mulpd xmm7, xmm15
000075aec0bdc056  vcmppd xmm1, xmm7, xmm7, 0x03
000075aec0bdc05b  ptest xmm1, xmm1
000075aec0bdc060  jnz 0x000075AEC0BDDEFE
000075aec0bdc066  lea r12, [rax+0x80]
000075aec0bdc06d  movups xmm1, [r13+r12*1]
000075aec0bdc073  vmovaps xmm5, [rsp+0x70]
000075aec0bdc079  vmovaps [rsp+0x70], xmm1
000075aec0bdc07f  movaps xmm15, xmm5
000075aec0bdc083  addpd xmm15, xmm3
000075aec0bdc088  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bdc08e  ptest xmm1, xmm1
000075aec0bdc093  jnz 0x000075AEC0BDE049
000075aec0bdc099  vmovaps xmm5, [rsp+0x80]
000075aec0bdc0a2  movaps xmm1, xmm5
000075aec0bdc0a5  addpd xmm1, xmm4
000075aec0bdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000075aec0bdc0ae  ptest xmm3, xmm3
000075aec0bdc0b3  jnz 0x000075AEC0BDE18B
000075aec0bdc0b9  vmovaps [rsp+0x80], xmm10
000075aec0bdc0c2  vmovaps xmm5, [rsp+0x80]
000075aec0bdc0cb  por xmm10, xmm5
000075aec0bdc0d0  movaps [r15+0x2F0], xmm10
000075aec0bdc0d8  vmovaps xmm5, [rsp+0x50]
000075aec0bdc0de  vpermilpd xmm5, xmm5, 0x00
000075aec0bdc0e4  vmovaps xmm3, [rsp+0x70]
000075aec0bdc0ea  vmovaps [rsp+0x50], xmm1
000075aec0bdc0f0  movaps xmm4, xmm3
000075aec0bdc0f3  mulpd xmm4, xmm5
000075aec0bdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000075aec0bdc0fc  ptest xmm1, xmm1
000075aec0bdc101  jnz 0x000075AEC0BDE2CB
000075aec0bdc107  lea r12, [rax+0xD0]
000075aec0bdc10e  movups xmm1, [r13+r12*1]
000075aec0bdc114  vmovaps xmm3, [rsp+0xD0]
000075aec0bdc11d  vmovaps [rsp+0x70], xmm1
000075aec0bdc123  movaps xmm5, xmm6
000075aec0bdc126  addpd xmm5, xmm3
000075aec0bdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000075aec0bdc12f  ptest xmm1, xmm1
000075aec0bdc134  jnz 0x000075AEC0BDE415
000075aec0bdc13a  vmovaps xmm1, [rsp+0x60]
000075aec0bdc140  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc146  movaps xmm6, xmm9
000075aec0bdc14a  mulpd xmm6, xmm1
000075aec0bdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000075aec0bdc153  ptest xmm3, xmm3
000075aec0bdc158  jnz 0x000075AEC0BDE555
000075aec0bdc15e  movaps [r15+0x260], xmm6
000075aec0bdc166  vxorps xmm1, xmm1, xmm1
000075aec0bdc16a  vpbroadcastq xmm1, xmm1
000075aec0bdc16f  movaps [r15+0x1B0], xmm1
000075aec0bdc177  vmovaps xmm1, [rsp+0x60]
000075aec0bdc17d  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc183  vmovaps xmm3, [rsp+0x70]
000075aec0bdc189  vmovaps [rsp+0x70], xmm15
000075aec0bdc18f  movaps xmm9, xmm3
000075aec0bdc193  mulpd xmm9, xmm1
000075aec0bdc198  vcmppd xmm15, xmm9, xmm9, 0x03
000075aec0bdc19e  ptest xmm15, xmm15
000075aec0bdc1a4  jnz 0x000075AEC0BDE696
000075aec0bdc1aa  lea r12, [rax+0xC0]
000075aec0bdc1b1  movups xmm1, [r13+r12*1]
000075aec0bdc1b7  vmovaps xmm3, [rsp+0xC0]
000075aec0bdc1c0  vmovaps [rsp+0x80], xmm1
000075aec0bdc1c9  movaps xmm15, xmm3
000075aec0bdc1cd  addpd xmm15, xmm7
000075aec0bdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bdc1d8  ptest xmm1, xmm1
000075aec0bdc1dd  jnz 0x000075AEC0BDE7E2
000075aec0bdc1e3  vmovaps [rsp+0xC0], xmm13
000075aec0bdc1ec  vmovaps xmm1, [rsp+0xC0]
000075aec0bdc1f5  por xmm13, xmm1
000075aec0bdc1fa  movaps [r15+0x270], xmm13
000075aec0bdc202  vmovaps xmm1, [rsp+0xB0]
000075aec0bdc20b  vmovaps xmm7, [rsp+0xB0]
000075aec0bdc214  por xmm1, xmm7
000075aec0bdc218  movaps [r15+0x1A0], xmm1
000075aec0bdc220  vmovaps xmm1, [rsp+0x60]
000075aec0bdc226  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc22c  vmovaps [rsp+0xB0], xmm1
000075aec0bdc235  vmovaps xmm1, [rsp+0x80]
000075aec0bdc23e  vmovaps [rsp+0x80], xmm15
000075aec0bdc247  vmovaps xmm15, [rsp+0xB0]
000075aec0bdc250  vmovaps [rsp+0xB0], xmm14
000075aec0bdc259  movaps xmm3, xmm1
000075aec0bdc25c  mulpd xmm3, xmm15
000075aec0bdc261  vcmppd xmm14, xmm3, xmm3, 0x03
000075aec0bdc266  ptest xmm14, xmm14
000075aec0bdc26c  jnz 0x000075AEC0BDE924
000075aec0bdc272  lea r12, [rax+0x20]
000075aec0bdc276  movups xmm1, [r13+r12*1]
000075aec0bdc27c  movaps [r15+0x110], xmm1
000075aec0bdc284  vmovaps xmm14, [rsp+0x70]
000075aec0bdc28a  vmovaps [rsp+0x70], xmm1
000075aec0bdc290  movaps xmm15, xmm14
000075aec0bdc294  addpd xmm15, xmm4
000075aec0bdc299  vcmppd xmm1, xmm15, xmm15, 0x03
000075aec0bdc29f  ptest xmm1, xmm1
000075aec0bdc2a4  jnz 0x000075AEC0BDEA6F
000075aec0bdc2aa  vmovaps xmm1, [rsp+0x60]
000075aec0bdc2b0  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc2b6  movaps xmm14, xmm2
000075aec0bdc2ba  mulpd xmm14, xmm1
000075aec0bdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000075aec0bdc2c5  ptest xmm4, xmm4
000075aec0bdc2ca  jnz 0x000075AEC0BDEBB2
000075aec0bdc2d0  vmovaps xmm4, [rsp+0x50]
000075aec0bdc2d6  movaps xmm1, xmm4
000075aec0bdc2d9  addpd xmm1, xmm9
000075aec0bdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000075aec0bdc2e3  ptest xmm2, xmm2
000075aec0bdc2e8  jnz 0x000075AEC0BDECF4
000075aec0bdc2ee  vmovaps xmm9, [rsp+0x30]
000075aec0bdc2f4  vpermilpd xmm9, xmm9, 0x00
000075aec0bdc2fa  vmovaps xmm2, [rsp+0x70]
000075aec0bdc300  vmovaps [rsp+0x50], xmm1
000075aec0bdc306  movaps xmm4, xmm2
000075aec0bdc309  mulpd xmm4, xmm9
000075aec0bdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000075aec0bdc313  ptest xmm1, xmm1
000075aec0bdc318  jnz 0x000075AEC0BDEE35
000075aec0bdc31e  vmovaps xmm1, [rsp+0x30]
000075aec0bdc324  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc32a  vmovaps xmm2, [rsp+0x90]
000075aec0bdc333  vmovaps [rsp+0x60], xmm15
000075aec0bdc339  movaps xmm9, xmm2
000075aec0bdc33d  mulpd xmm9, xmm1
000075aec0bdc342  vcmppd xmm15, xmm9, xmm9, 0x03
000075aec0bdc348  ptest xmm15, xmm15
000075aec0bdc34e  jnz 0x000075AEC0BDEF76
000075aec0bdc354  vmovaps xmm15, [rsp+0x80]
000075aec0bdc35d  movaps xmm1, xmm15
000075aec0bdc361  addpd xmm1, xmm6
000075aec0bdc365  vcmppd xmm2, xmm1, xmm1, 0x03
000075aec0bdc36a  ptest xmm2, xmm2
000075aec0bdc36f  jnz 0x000075AEC0BDF0B8
000075aec0bdc375  movaps xmm15, xmm5
000075aec0bdc379  addpd xmm15, xmm3
000075aec0bdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000075aec0bdc384  ptest xmm6, xmm6
000075aec0bdc389  jnz 0x000075AEC0BDF1F9
000075aec0bdc38f  vmovaps xmm6, [rsp+0x30]
000075aec0bdc395  vpermilpd xmm6, xmm6, 0x00
000075aec0bdc39b  movaps xmm5, xmm8
000075aec0bdc39f  mulpd xmm5, xmm6
000075aec0bdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000075aec0bdc3a8  ptest xmm3, xmm3
000075aec0bdc3ad  jnz 0x000075AEC0BDF33B
000075aec0bdc3b3  vmovaps xmm8, [rsp+0x30]
000075aec0bdc3b9  vpermilpd xmm8, xmm8, 0x00
000075aec0bdc3bf  movaps xmm6, xmm10
000075aec0bdc3c3  mulpd xmm6, xmm8
000075aec0bdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000075aec0bdc3cd  ptest xmm3, xmm3
000075aec0bdc3d2  jnz 0x000075AEC0BDF47C
000075aec0bdc3d8  vmovaps xmm8, [rsp+0x60]
000075aec0bdc3de  movaps xmm10, xmm8
000075aec0bdc3e2  addpd xmm10, xmm14
000075aec0bdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000075aec0bdc3ed  ptest xmm3, xmm3
000075aec0bdc3f2  jnz 0x000075AEC0BDF5BE
000075aec0bdc3f8  vmovaps xmm8, [rsp+0x50]
000075aec0bdc3fe  movaps xmm14, xmm8
000075aec0bdc402  addpd xmm14, xmm4
000075aec0bdc407  vcmppd xmm3, xmm14, xmm14, 0x03
000075aec0bdc40d  ptest xmm3, xmm3
000075aec0bdc412  jnz 0x000075AEC0BDF702
000075aec0bdc418  vmovaps xmm8, [rsp+0x40]
000075aec0bdc41e  vpermilpd xmm8, xmm8, 0x00
000075aec0bdc424  movaps xmm4, xmm13
000075aec0bdc428  mulpd xmm4, xmm8
000075aec0bdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000075aec0bdc432  ptest xmm3, xmm3
000075aec0bdc437  jnz 0x000075AEC0BDF845
000075aec0bdc43d  movaps xmm13, xmm15
000075aec0bdc441  addpd xmm13, xmm9
000075aec0bdc446  vcmppd xmm8, xmm13, xmm13, 0x03
000075aec0bdc44c  ptest xmm8, xmm8
000075aec0bdc452  jnz 0x000075AEC0BDF987
000075aec0bdc458  movaps xmm15, xmm1
000075aec0bdc45c  addpd xmm15, xmm5
000075aec0bdc461  vcmppd xmm9, xmm15, xmm15, 0x03
000075aec0bdc467  ptest xmm9, xmm9
000075aec0bdc46d  jnz 0x000075AEC0BDFACB
000075aec0bdc473  vmovaps [rsp+0x30], xmm11
000075aec0bdc479  vmovaps xmm1, [rsp+0x30]
000075aec0bdc47f  por xmm11, xmm1
000075aec0bdc484  movaps [r15+0x250], xmm11
000075aec0bdc48c  vmovaps [rsp+0x30], xmm12
000075aec0bdc492  vmovaps xmm1, [rsp+0x30]
000075aec0bdc498  por xmm12, xmm1
000075aec0bdc49d  movaps [r15+0x2A0], xmm12
000075aec0bdc4a5  vmovaps xmm1, [rsp+0xA0]
000075aec0bdc4ae  vmovaps xmm11, [rsp+0xA0]
000075aec0bdc4b7  por xmm1, xmm11
000075aec0bdc4bc  movaps [r15+0x1D0], xmm1
000075aec0bdc4c4  lea r12, [rax+0x40]
000075aec0bdc4c8  movups xmm1, [r13+r12*1]
000075aec0bdc4ce  movaps [r15+0x2C0], xmm1
000075aec0bdc4d6  vmovaps xmm11, [rsp+0x40]
000075aec0bdc4dc  vpermilpd xmm11, xmm11, 0x00
000075aec0bdc4e2  vmovaps xmm8, [rsp+0xE0]
000075aec0bdc4eb  movaps xmm9, xmm8
000075aec0bdc4ef  mulpd xmm9, xmm11
000075aec0bdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000075aec0bdc4fa  ptest xmm5, xmm5
000075aec0bdc4ff  jnz 0x000075AEC0BDFC17
000075aec0bdc505  movaps xmm11, xmm10
000075aec0bdc509  addpd xmm11, xmm6
000075aec0bdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000075aec0bdc514  ptest xmm8, xmm8
000075aec0bdc51a  jnz 0x000075AEC0BDFD5B
000075aec0bdc520  movaps xmm10, xmm14
000075aec0bdc524  addpd xmm10, xmm4
000075aec0bdc529  vcmppd xmm8, xmm10, xmm10, 0x03
000075aec0bdc52f  ptest xmm8, xmm8
000075aec0bdc535  jnz 0x000075AEC0BDFE9E
000075aec0bdc53b  vmovaps xmm14, [rsp+0x40]
000075aec0bdc541  vpermilpd xmm14, xmm14, 0x00
000075aec0bdc547  movaps xmm8, xmm1
000075aec0bdc54b  mulpd xmm8, xmm14
000075aec0bdc550  vcmppd xmm6, xmm8, xmm8, 0x03
000075aec0bdc556  ptest xmm6, xmm6
000075aec0bdc55b  jnz 0x000075AEC0BDFFE1
000075aec0bdc561  movaps xmm1, [r15+0x2B0]
000075aec0bdc569  vmovaps xmm14, [rsp+0x40]
000075aec0bdc56f  vpermilpd xmm14, xmm14, 0x00
000075aec0bdc575  movaps xmm6, xmm1
000075aec0bdc578  mulpd xmm6, xmm14
000075aec0bdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000075aec0bdc582  ptest xmm5, xmm5
000075aec0bdc587  jnz 0x000075AEC0BE0124
000075aec0bdc58d  vmovaps xmm1, [rsp+0x10]
000075aec0bdc593  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc599  movaps xmm14, xmm12
000075aec0bdc59d  mulpd xmm14, xmm1
000075aec0bdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000075aec0bdc5a8  ptest xmm5, xmm5
000075aec0bdc5ad  jnz 0x000075AEC0BE0265
000075aec0bdc5b3  movaps xmm1, xmm13
000075aec0bdc5b7  addpd xmm1, xmm9
000075aec0bdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000075aec0bdc5c1  ptest xmm12, xmm12
000075aec0bdc5c7  jnz 0x000075AEC0BE03A8
000075aec0bdc5cd  vmovaps xmm13, [rsp+0x10]
000075aec0bdc5d3  vpermilpd xmm13, xmm13, 0x00
000075aec0bdc5d9  movaps xmm12, xmm7
000075aec0bdc5dd  mulpd xmm12, xmm13
000075aec0bdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000075aec0bdc5e8  ptest xmm9, xmm9
000075aec0bdc5ee  jnz 0x000075AEC0BE04EA
000075aec0bdc5f4  movaps xmm13, xmm15
000075aec0bdc5f8  addpd xmm13, xmm8
000075aec0bdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000075aec0bdc603  ptest xmm9, xmm9
000075aec0bdc609  jnz 0x000075AEC0BE062D
000075aec0bdc60f  movaps xmm15, [r15+0x290]
000075aec0bdc617  vmovaps xmm9, [rsp+0x10]
000075aec0bdc61d  vpermilpd xmm9, xmm9, 0x00
000075aec0bdc623  movaps xmm8, xmm15
000075aec0bdc627  mulpd xmm8, xmm9
000075aec0bdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000075aec0bdc632  ptest xmm7, xmm7
000075aec0bdc637  jnz 0x000075AEC0BE0771
000075aec0bdc63d  movaps xmm15, xmm11
000075aec0bdc641  addpd xmm15, xmm6
000075aec0bdc646  vcmppd xmm9, xmm15, xmm15, 0x03
000075aec0bdc64c  ptest xmm9, xmm9
000075aec0bdc652  jnz 0x000075AEC0BE08B5
000075aec0bdc658  movaps xmm11, [r15+0x1E0]
000075aec0bdc660  vmovaps xmm9, [rsp+0x10]
000075aec0bdc666  vpermilpd xmm9, xmm9, 0x00
000075aec0bdc66c  movaps xmm7, xmm11
000075aec0bdc670  mulpd xmm7, xmm9
000075aec0bdc675  vcmppd xmm6, xmm7, xmm7, 0x03
000075aec0bdc67a  ptest xmm6, xmm6
000075aec0bdc67f  jnz 0x000075AEC0BE09F8
000075aec0bdc685  movaps xmm11, xmm10
000075aec0bdc689  addpd xmm11, xmm14
000075aec0bdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000075aec0bdc694  ptest xmm9, xmm9
000075aec0bdc69a  jnz 0x000075AEC0BE0B3A
000075aec0bdc6a0  lea r12, [rax+0x70]
000075aec0bdc6a4  movups xmm14, [r13+r12*1]
000075aec0bdc6aa  movaps [r15+0x240], xmm14
000075aec0bdc6b2  movaps xmm10, xmm1
000075aec0bdc6b6  addpd xmm10, xmm12
000075aec0bdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000075aec0bdc6c1  ptest xmm9, xmm9
000075aec0bdc6c7  jnz 0x000075AEC0BE0C88
000075aec0bdc6cd  movaps [r15+0x170], xmm10
000075aec0bdc6d5  vmovaps xmm1, [rsp+0x20]
000075aec0bdc6db  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc6e1  movaps xmm12, xmm14
000075aec0bdc6e5  mulpd xmm12, xmm1
000075aec0bdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000075aec0bdc6f0  ptest xmm9, xmm9
000075aec0bdc6f6  jnz 0x000075AEC0BE0DCB
000075aec0bdc6fc  vmovaps xmm1, [rsp+0x20]
000075aec0bdc702  vpermilpd xmm1, xmm1, 0x00
000075aec0bdc708  vmovaps xmm9, [rsp+0xB0]
000075aec0bdc711  movaps xmm14, xmm9
000075aec0bdc715  mulpd xmm14, xmm1
000075aec0bdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000075aec0bdc720  ptest xmm6, xmm6
000075aec0bdc725  jnz 0x000075AEC0BE0F0E
000075aec0bdc72b  movaps [r15+0x180], xmm14
000075aec0bdc733  movaps xmm1, xmm13
000075aec0bdc737  addpd xmm1, xmm8
000075aec0bdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000075aec0bdc741  ptest xmm9, xmm9
000075aec0bdc747  jnz 0x000075AEC0BE1051
000075aec0bdc74d  movaps [r15+0x210], xmm1
000075aec0bdc755  movups xmm13, [r13+rax*1]
000075aec0bdc75b  lea r12, [rax+0x10]
000075aec0bdc75f  movups xmm9, [r13+r12*1]
000075aec0bdc765  movaps [r15+0x230], xmm9
000075aec0bdc76d  movaps xmm8, xmm15
000075aec0bdc771  addpd xmm8, xmm7
000075aec0bdc776  vcmppd xmm6, xmm8, xmm8, 0x03
000075aec0bdc77c  ptest xmm6, xmm6
000075aec0bdc781  jnz 0x000075AEC0BE11A7
000075aec0bdc787  movaps [r15+0x130], xmm8
000075aec0bdc78f  vmovaps xmm15, [rsp+0x20]
000075aec0bdc795  vpermilpd xmm15, xmm15, 0x00
000075aec0bdc79b  movaps xmm7, xmm9
000075aec0bdc79f  mulpd xmm7, xmm15
000075aec0bdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000075aec0bdc7a9  ptest xmm6, xmm6
000075aec0bdc7ae  jnz 0x000075AEC0BE12EA
000075aec0bdc7b4  movaps [r15+0x220], xmm7
000075aec0bdc7bc  vmovaps xmm15, [rsp+0x20]
000075aec0bdc7c2  vpermilpd xmm15, xmm15, 0x00
000075aec0bdc7c8  movaps xmm9, xmm13
000075aec0bdc7cc  mulpd xmm9, xmm15
000075aec0bdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000075aec0bdc7d7  ptest xmm6, xmm6
000075aec0bdc7dc  jnz 0x000075AEC0BE142C
000075aec0bdc7e2  movaps xmm15, xmm11
000075aec0bdc7e6  addpd xmm15, xmm12
000075aec0bdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000075aec0bdc7f1  ptest xmm13, xmm13
000075aec0bdc7f7  jnz 0x000075AEC0BE1570
000075aec0bdc7fd  movaps [r15+0x140], xmm15
000075aec0bdc805  movaps xmm13, xmm10
000075aec0bdc809  addpd xmm13, xmm14
000075aec0bdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000075aec0bdc814  ptest xmm12, xmm12
000075aec0bdc81a  jnz 0x000075AEC0BE16B4
000075aec0bdc820  movaps [r15+0x150], xmm13
000075aec0bdc828  movaps xmm14, xmm1
000075aec0bdc82c  addpd xmm14, xmm7
000075aec0bdc831  vcmppd xmm12, xmm14, xmm14, 0x03
000075aec0bdc837  ptest xmm12, xmm12
000075aec0bdc83d  jnz 0x000075AEC0BE17F8
000075aec0bdc843  movaps [r15+0x160], xmm14
000075aec0bdc84b  movaps xmm1, xmm8
000075aec0bdc84f  addpd xmm1, xmm9
000075aec0bdc854  vcmppd xmm12, xmm1, xmm1, 0x03
000075aec0bdc859  ptest xmm12, xmm12
000075aec0bdc85f  jnz 0x000075AEC0BE193A
000075aec0bdc865  movaps [r15+0x120], xmm1
000075aec0bdc86d  movups [r13+r14*1], xmm15
000075aec0bdc873  lea rax, [r14+0x10]
000075aec0bdc877  movups [r13+rax*1], xmm13
000075aec0bdc87d  lea rax, [r14+0x20]
000075aec0bdc881  movups [r13+rax*1], xmm14
000075aec0bdc887  lea rax, [r14+0x30]
000075aec0bdc88b  movups [r13+rax*1], xmm1
000075aec0bdc891  mov eax, [r15+0x108]
000075aec0bdc898  sahf
000075aec0bdc899  jnz 0x000075AEC0BDC8CB
000075aec0bdc89b  cmp dword ptr [r15+0x318], 0x00
000075aec0bdc8a3  jz 0x000075AEC0BDB900
000075aec0bdc8a9  nop [rax+rax*1], ax
000075aec0bdc8b2  nop [rax+rax*1], eax
000075aec0bdc8ba  mov eax, 0x410444
000075aec0bdc8bf  mov [r15+0x100], rax
000075aec0bdc8c6  jmp 0x000075AEC09FE110
000075aec0bdc8cb  cmp dword ptr [r15+0x318], 0x00
000075aec0bdc8d3  jz 0x000075AEC0BD57E0
000075aec0bdc8d9  nop [rax+rax*1], ax
000075aec0bdc8e2  nop [rax+rax*1], eax
000075aec0bdc8ea  mov eax, 0x410278
000075aec0bdc8ef  mov [r15+0x100], rax
000075aec0bdc8f6  jmp 0x000075AEC09FE110
000075aec0bdc8fb  int3
000075aec0bdc8fc  call 0x000075AEC0AE27E0
000075aec0bdc901  jmp 0x000075AEC0BDB9DF
000075aec0bdc906  call 0x000075AEC0AE1570
000075aec0bdc90b  jmp 0x000075AEC0BDB9E8
000075aec0bdc910  call 0x000075AEC0AE27E0
000075aec0bdc915  jmp 0x000075AEC0BDBA44
000075aec0bdc91a  call 0x000075AEC0AE1570
000075aec0bdc91f  jmp 0x000075AEC0BDBA4D
000075aec0bdc924  call 0x000075AEC0AE27E0
000075aec0bdc929  jmp 0x000075AEC0BDBA90
000075aec0bdc92e  call 0x000075AEC0AE1570
000075aec0bdc933  jmp 0x000075AEC0BDBA99
000075aec0bdc938  call 0x000075AEC0A0DC20
000075aec0bdc93d  jmp 0x000075AEC0BDBAD8
000075aec0bdc942  call 0x000075AEC0AD59C0
000075aec0bdc947  jmp 0x000075AEC0BDBAEB
000075aec0bdc94c  call 0x000075AEC0AE0E30
000075aec0bdc951  jmp 0x000075AEC0BDBB09
000075aec0bdc956  call 0x000075AEC0ADFBC0
000075aec0bdc95b  jmp 0x000075AEC0BDBB13
000075aec0bdc960  call 0x000075AEC0ADE950
000075aec0bdc965  jmp 0x000075AEC0BDBB1D
000075aec0bdc96a  sub rsp, 0x08
000075aec0bdc96e  push rax
000075aec0bdc96f  push rcx
000075aec0bdc970  push rdx
000075aec0bdc971  push rdi
000075aec0bdc972  push rsi
000075aec0bdc973  push r8
000075aec0bdc975  push r9
000075aec0bdc977  push r10
000075aec0bdc979  push r11
000075aec0bdc97b  sub rsp, 0xF0
000075aec0bdc982  vmovaps [rsp], xmm0
000075aec0bdc987  vmovaps [rsp+0x10], xmm1
000075aec0bdc98d  vmovaps [rsp+0x20], xmm2
000075aec0bdc993  vmovaps [rsp+0x30], xmm3
000075aec0bdc999  vmovaps [rsp+0x40], xmm4
000075aec0bdc99f  vmovaps [rsp+0x50], xmm5
000075aec0bdc9a5  vmovaps [rsp+0x60], xmm6
000075aec0bdc9ab  vmovaps [rsp+0x70], xmm7
000075aec0bdc9b1  vmovaps [rsp+0x80], xmm9
000075aec0bdc9ba  vmovaps [rsp+0x90], xmm10
000075aec0bdc9c3  vmovaps [rsp+0xA0], xmm11
000075aec0bdc9cc  vmovaps [rsp+0xB0], xmm12
000075aec0bdc9d5  vmovaps [rsp+0xC0], xmm13
000075aec0bdc9de  vmovaps [rsp+0xD0], xmm14
000075aec0bdc9e7  vmovaps [rsp+0xE0], xmm15
000075aec0bdc9f0  sub rsp, 0x30
000075aec0bdc9f4  movaps [rsp], xmm8
000075aec0bdc9f9  movaps [rsp+0x10], xmm12
000075aec0bdc9ff  movaps [rsp+0x20], xmm15
000075aec0bdca05  lea rdi, [rsp]
000075aec0bdca09  mov esi, 0x00
000075aec0bdca0e  mov rax, 0x57F4B31E6530
000075aec0bdca18  call rax
000075aec0bdca1a  movaps xmm8, [rsp]
000075aec0bdca1f  add rsp, 0x30
000075aec0bdca23  vmovaps xmm0, [rsp]
000075aec0bdca28  vmovaps xmm1, [rsp+0x10]
000075aec0bdca2e  vmovaps xmm2, [rsp+0x20]
000075aec0bdca34  vmovaps xmm3, [rsp+0x30]
000075aec0bdca3a  vmovaps xmm4, [rsp+0x40]
000075aec0bdca40  vmovaps xmm5, [rsp+0x50]
000075aec0bdca46  vmovaps xmm6, [rsp+0x60]
000075aec0bdca4c  vmovaps xmm7, [rsp+0x70]
000075aec0bdca52  vmovaps xmm9, [rsp+0x80]
000075aec0bdca5b  vmovaps xmm10, [rsp+0x90]
000075aec0bdca64  vmovaps xmm11, [rsp+0xA0]
000075aec0bdca6d  vmovaps xmm12, [rsp+0xB0]
000075aec0bdca76  vmovaps xmm13, [rsp+0xC0]
000075aec0bdca7f  vmovaps xmm14, [rsp+0xD0]
000075aec0bdca88  vmovaps xmm15, [rsp+0xE0]
000075aec0bdca91  add rsp, 0xF0
000075aec0bdca98  pop r11
000075aec0bdca9a  pop r10
000075aec0bdca9c  pop r9
000075aec0bdca9e  pop r8
000075aec0bdcaa0  pop rsi
000075aec0bdcaa1  pop rdi
000075aec0bdcaa2  pop rdx
000075aec0bdcaa3  pop rcx
000075aec0bdcaa4  pop rax
000075aec0bdcaa5  add rsp, 0x08
000075aec0bdcaa9  jmp 0x000075AEC0BDBB47
000075aec0bdcaae  sub rsp, 0x08
000075aec0bdcab2  push rax
000075aec0bdcab3  push rcx
000075aec0bdcab4  push rdx
000075aec0bdcab5  push rdi
000075aec0bdcab6  push rsi
000075aec0bdcab7  push r8
000075aec0bdcab9  push r9
000075aec0bdcabb  push r10
000075aec0bdcabd  push r11
000075aec0bdcabf  sub rsp, 0xF0
000075aec0bdcac6  vmovaps [rsp], xmm0
000075aec0bdcacb  vmovaps [rsp+0x10], xmm1
000075aec0bdcad1  vmovaps [rsp+0x20], xmm2
000075aec0bdcad7  vmovaps [rsp+0x30], xmm3
000075aec0bdcadd  vmovaps [rsp+0x40], xmm4
000075aec0bdcae3  vmovaps [rsp+0x50], xmm5
000075aec0bdcae9  vmovaps [rsp+0x60], xmm6
000075aec0bdcaef  vmovaps [rsp+0x70], xmm8
000075aec0bdcaf5  vmovaps [rsp+0x80], xmm9
000075aec0bdcafe  vmovaps [rsp+0x90], xmm10
000075aec0bdcb07  vmovaps [rsp+0xA0], xmm11
000075aec0bdcb10  vmovaps [rsp+0xB0], xmm12
000075aec0bdcb19  vmovaps [rsp+0xC0], xmm13
000075aec0bdcb22  vmovaps [rsp+0xD0], xmm14
000075aec0bdcb2b  vmovaps [rsp+0xE0], xmm15
000075aec0bdcb34  sub rsp, 0x30
000075aec0bdcb38  movaps [rsp], xmm7
000075aec0bdcb3c  movaps [rsp+0x10], xmm9
000075aec0bdcb42  movaps [rsp+0x20], xmm15
000075aec0bdcb48  lea rdi, [rsp]
000075aec0bdcb4c  mov esi, 0x00
000075aec0bdcb51  mov rax, 0x57F4B31E6530
000075aec0bdcb5b  call rax
000075aec0bdcb5d  movaps xmm7, [rsp]
000075aec0bdcb61  add rsp, 0x30
000075aec0bdcb65  vmovaps xmm0, [rsp]
000075aec0bdcb6a  vmovaps xmm1, [rsp+0x10]
000075aec0bdcb70  vmovaps xmm2, [rsp+0x20]
000075aec0bdcb76  vmovaps xmm3, [rsp+0x30]
000075aec0bdcb7c  vmovaps xmm4, [rsp+0x40]
000075aec0bdcb82  vmovaps xmm5, [rsp+0x50]
000075aec0bdcb88  vmovaps xmm6, [rsp+0x60]
000075aec0bdcb8e  vmovaps xmm8, [rsp+0x70]
000075aec0bdcb94  vmovaps xmm9, [rsp+0x80]
000075aec0bdcb9d  vmovaps xmm10, [rsp+0x90]
000075aec0bdcba6  vmovaps xmm11, [rsp+0xA0]
000075aec0bdcbaf  vmovaps xmm12, [rsp+0xB0]
000075aec0bdcbb8  vmovaps xmm13, [rsp+0xC0]
000075aec0bdcbc1  vmovaps xmm14, [rsp+0xD0]
000075aec0bdcbca  vmovaps xmm15, [rsp+0xE0]
000075aec0bdcbd3  add rsp, 0xF0
000075aec0bdcbda  pop r11
000075aec0bdcbdc  pop r10
000075aec0bdcbde  pop r9
000075aec0bdcbe0  pop r8
000075aec0bdcbe2  pop rsi
000075aec0bdcbe3  pop rdi
000075aec0bdcbe4  pop rdx
000075aec0bdcbe5  pop rcx
000075aec0bdcbe6  pop rax
000075aec0bdcbe7  add rsp, 0x08
000075aec0bdcbeb  jmp 0x000075AEC0BDBB75
000075aec0bdcbf0  sub rsp, 0x08
000075aec0bdcbf4  push rax
000075aec0bdcbf5  push rcx
000075aec0bdcbf6  push rdx
000075aec0bdcbf7  push rdi
000075aec0bdcbf8  push rsi
000075aec0bdcbf9  push r8
000075aec0bdcbfb  push r9
000075aec0bdcbfd  push r10
000075aec0bdcbff  push r11
000075aec0bdcc01  sub rsp, 0xF0
000075aec0bdcc08  vmovaps [rsp], xmm0
000075aec0bdcc0d  vmovaps [rsp+0x10], xmm1
000075aec0bdcc13  vmovaps [rsp+0x20], xmm2
000075aec0bdcc19  vmovaps [rsp+0x30], xmm3
000075aec0bdcc1f  vmovaps [rsp+0x40], xmm4
000075aec0bdcc25  vmovaps [rsp+0x50], xmm5
000075aec0bdcc2b  vmovaps [rsp+0x60], xmm6
000075aec0bdcc31  vmovaps [rsp+0x70], xmm7
000075aec0bdcc37  vmovaps [rsp+0x80], xmm8
000075aec0bdcc40  vmovaps [rsp+0x90], xmm10
000075aec0bdcc49  vmovaps [rsp+0xA0], xmm11
000075aec0bdcc52  vmovaps [rsp+0xB0], xmm12
000075aec0bdcc5b  vmovaps [rsp+0xC0], xmm13
000075aec0bdcc64  vmovaps [rsp+0xD0], xmm14
000075aec0bdcc6d  vmovaps [rsp+0xE0], xmm15
000075aec0bdcc76  sub rsp, 0x30
000075aec0bdcc7a  movaps [rsp], xmm9
000075aec0bdcc7f  movaps [rsp+0x10], xmm12
000075aec0bdcc85  movaps [rsp+0x20], xmm10
000075aec0bdcc8b  lea rdi, [rsp]
000075aec0bdcc8f  mov esi, 0x00
000075aec0bdcc94  mov rax, 0x57F4B31E6530
000075aec0bdcc9e  call rax
000075aec0bdcca0  movaps xmm9, [rsp]
000075aec0bdcca5  add rsp, 0x30
000075aec0bdcca9  vmovaps xmm0, [rsp]
000075aec0bdccae  vmovaps xmm1, [rsp+0x10]
000075aec0bdccb4  vmovaps xmm2, [rsp+0x20]
000075aec0bdccba  vmovaps xmm3, [rsp+0x30]
000075aec0bdccc0  vmovaps xmm4, [rsp+0x40]
000075aec0bdccc6  vmovaps xmm5, [rsp+0x50]
000075aec0bdcccc  vmovaps xmm6, [rsp+0x60]
000075aec0bdccd2  vmovaps xmm7, [rsp+0x70]
000075aec0bdccd8  vmovaps xmm8, [rsp+0x80]
000075aec0bdcce1  vmovaps xmm10, [rsp+0x90]
000075aec0bdccea  vmovaps xmm11, [rsp+0xA0]
000075aec0bdccf3  vmovaps xmm12, [rsp+0xB0]
000075aec0bdccfc  vmovaps xmm13, [rsp+0xC0]
000075aec0bdcd05  vmovaps xmm14, [rsp+0xD0]
000075aec0bdcd0e  vmovaps xmm15, [rsp+0xE0]
000075aec0bdcd17  add rsp, 0xF0
000075aec0bdcd1e  pop r11
000075aec0bdcd20  pop r10
000075aec0bdcd22  pop r9
000075aec0bdcd24  pop r8
000075aec0bdcd26  pop rsi
000075aec0bdcd27  pop rdi
000075aec0bdcd28  pop rdx
000075aec0bdcd29  pop rcx
000075aec0bdcd2a  pop rax
000075aec0bdcd2b  add rsp, 0x08
000075aec0bdcd2f  jmp 0x000075AEC0BDBB99
000075aec0bdcd34  sub rsp, 0x08
000075aec0bdcd38  push rax
000075aec0bdcd39  push rcx
000075aec0bdcd3a  push rdx
000075aec0bdcd3b  push rdi
000075aec0bdcd3c  push rsi
000075aec0bdcd3d  push r8
000075aec0bdcd3f  push r9
000075aec0bdcd41  push r10
000075aec0bdcd43  push r11
000075aec0bdcd45  sub rsp, 0xF0
000075aec0bdcd4c  vmovaps [rsp], xmm0
000075aec0bdcd51  vmovaps [rsp+0x10], xmm1
000075aec0bdcd57  vmovaps [rsp+0x20], xmm2
000075aec0bdcd5d  vmovaps [rsp+0x30], xmm3
000075aec0bdcd63  vmovaps [rsp+0x40], xmm4
000075aec0bdcd69  vmovaps [rsp+0x50], xmm5
000075aec0bdcd6f  vmovaps [rsp+0x60], xmm6
000075aec0bdcd75  vmovaps [rsp+0x70], xmm7
000075aec0bdcd7b  vmovaps [rsp+0x80], xmm8
000075aec0bdcd84  vmovaps [rsp+0x90], xmm9
000075aec0bdcd8d  vmovaps [rsp+0xA0], xmm11
000075aec0bdcd96  vmovaps [rsp+0xB0], xmm12
000075aec0bdcd9f  vmovaps [rsp+0xC0], xmm13
000075aec0bdcda8  vmovaps [rsp+0xD0], xmm14
000075aec0bdcdb1  vmovaps [rsp+0xE0], xmm15
000075aec0bdcdba  sub rsp, 0x30
000075aec0bdcdbe  movaps [rsp], xmm10
000075aec0bdcdc3  movaps [rsp+0x10], xmm12
000075aec0bdcdc9  movaps [rsp+0x20], xmm11
000075aec0bdcdcf  lea rdi, [rsp]
000075aec0bdcdd3  mov esi, 0x00
000075aec0bdcdd8  mov rax, 0x57F4B31E6530
000075aec0bdcde2  call rax
000075aec0bdcde4  movaps xmm10, [rsp]
000075aec0bdcde9  add rsp, 0x30
000075aec0bdcded  vmovaps xmm0, [rsp]
000075aec0bdcdf2  vmovaps xmm1, [rsp+0x10]
000075aec0bdcdf8  vmovaps xmm2, [rsp+0x20]
000075aec0bdcdfe  vmovaps xmm3, [rsp+0x30]
000075aec0bdce04  vmovaps xmm4, [rsp+0x40]
000075aec0bdce0a  vmovaps xmm5, [rsp+0x50]
000075aec0bdce10  vmovaps xmm6, [rsp+0x60]
000075aec0bdce16  vmovaps xmm7, [rsp+0x70]
000075aec0bdce1c  vmovaps xmm8, [rsp+0x80]
000075aec0bdce25  vmovaps xmm9, [rsp+0x90]
000075aec0bdce2e  vmovaps xmm11, [rsp+0xA0]
000075aec0bdce37  vmovaps xmm12, [rsp+0xB0]
000075aec0bdce40  vmovaps xmm13, [rsp+0xC0]
000075aec0bdce49  vmovaps xmm14, [rsp+0xD0]
000075aec0bdce52  vmovaps xmm15, [rsp+0xE0]
000075aec0bdce5b  add rsp, 0xF0
000075aec0bdce62  pop r11
000075aec0bdce64  pop r10
000075aec0bdce66  pop r9
000075aec0bdce68  pop r8
000075aec0bdce6a  pop rsi
000075aec0bdce6b  pop rdi
000075aec0bdce6c  pop rdx
000075aec0bdce6d  pop rcx
000075aec0bdce6e  pop rax
000075aec0bdce6f  add rsp, 0x08
000075aec0bdce73  jmp 0x000075AEC0BDBBB3
000075aec0bdce78  sub rsp, 0x08
000075aec0bdce7c  push rax
000075aec0bdce7d  push rcx
000075aec0bdce7e  push rdx
000075aec0bdce7f  push rdi
000075aec0bdce80  push rsi
000075aec0bdce81  push r8
000075aec0bdce83  push r9
000075aec0bdce85  push r10
000075aec0bdce87  push r11
000075aec0bdce89  sub rsp, 0xF0
000075aec0bdce90  vmovaps [rsp], xmm0
000075aec0bdce95  vmovaps [rsp+0x10], xmm1
000075aec0bdce9b  vmovaps [rsp+0x20], xmm2
000075aec0bdcea1  vmovaps [rsp+0x30], xmm3
000075aec0bdcea7  vmovaps [rsp+0x40], xmm4
000075aec0bdcead  vmovaps [rsp+0x50], xmm5
000075aec0bdceb3  vmovaps [rsp+0x60], xmm7
000075aec0bdceb9  vmovaps [rsp+0x70], xmm8
000075aec0bdcebf  vmovaps [rsp+0x80], xmm9
000075aec0bdcec8  vmovaps [rsp+0x90], xmm10
000075aec0bdced1  vmovaps [rsp+0xA0], xmm11
000075aec0bdceda  vmovaps [rsp+0xB0], xmm12
000075aec0bdcee3  vmovaps [rsp+0xC0], xmm13
000075aec0bdceec  vmovaps [rsp+0xD0], xmm14
000075aec0bdcef5  vmovaps [rsp+0xE0], xmm15
000075aec0bdcefe  sub rsp, 0x30
000075aec0bdcf02  movaps [rsp], xmm6
000075aec0bdcf06  movaps [rsp+0x10], xmm12
000075aec0bdcf0c  movaps [rsp+0x20], xmm11
000075aec0bdcf12  lea rdi, [rsp]
000075aec0bdcf16  mov esi, 0x00
000075aec0bdcf1b  mov rax, 0x57F4B31E6530
000075aec0bdcf25  call rax
000075aec0bdcf27  movaps xmm6, [rsp]
000075aec0bdcf2b  add rsp, 0x30
000075aec0bdcf2f  vmovaps xmm0, [rsp]
000075aec0bdcf34  vmovaps xmm1, [rsp+0x10]
000075aec0bdcf3a  vmovaps xmm2, [rsp+0x20]
000075aec0bdcf40  vmovaps xmm3, [rsp+0x30]
000075aec0bdcf46  vmovaps xmm4, [rsp+0x40]
000075aec0bdcf4c  vmovaps xmm5, [rsp+0x50]
000075aec0bdcf52  vmovaps xmm7, [rsp+0x60]
000075aec0bdcf58  vmovaps xmm8, [rsp+0x70]
000075aec0bdcf5e  vmovaps xmm9, [rsp+0x80]
000075aec0bdcf67  vmovaps xmm10, [rsp+0x90]
000075aec0bdcf70  vmovaps xmm11, [rsp+0xA0]
000075aec0bdcf79  vmovaps xmm12, [rsp+0xB0]
000075aec0bdcf82  vmovaps xmm13, [rsp+0xC0]
000075aec0bdcf8b  vmovaps xmm14, [rsp+0xD0]
000075aec0bdcf94  vmovaps xmm15, [rsp+0xE0]
000075aec0bdcf9d  add rsp, 0xF0
000075aec0bdcfa4  pop r11
000075aec0bdcfa6  pop r10
000075aec0bdcfa8  pop r9
000075aec0bdcfaa  pop r8
000075aec0bdcfac  pop rsi
000075aec0bdcfad  pop rdi
000075aec0bdcfae  pop rdx
000075aec0bdcfaf  pop rcx
000075aec0bdcfb0  pop rax
000075aec0bdcfb1  add rsp, 0x08
000075aec0bdcfb5  jmp 0x000075AEC0BDBBD4
000075aec0bdcfba  sub rsp, 0x08
000075aec0bdcfbe  push rax
000075aec0bdcfbf  push rcx
000075aec0bdcfc0  push rdx
000075aec0bdcfc1  push rdi
000075aec0bdcfc2  push rsi
000075aec0bdcfc3  push r8
000075aec0bdcfc5  push r9
000075aec0bdcfc7  push r10
000075aec0bdcfc9  push r11
000075aec0bdcfcb  sub rsp, 0xF0
000075aec0bdcfd2  vmovaps [rsp], xmm0
000075aec0bdcfd7  vmovaps [rsp+0x10], xmm1
000075aec0bdcfdd  vmovaps [rsp+0x20], xmm2
000075aec0bdcfe3  vmovaps [rsp+0x30], xmm4
000075aec0bdcfe9  vmovaps [rsp+0x40], xmm5
000075aec0bdcfef  vmovaps [rsp+0x50], xmm6
000075aec0bdcff5  vmovaps [rsp+0x60], xmm7
000075aec0bdcffb  vmovaps [rsp+0x70], xmm8
000075aec0bdd001  vmovaps [rsp+0x80], xmm9
000075aec0bdd00a  vmovaps [rsp+0x90], xmm10
000075aec0bdd013  vmovaps [rsp+0xA0], xmm11
000075aec0bdd01c  vmovaps [rsp+0xB0], xmm12
000075aec0bdd025  vmovaps [rsp+0xC0], xmm13
000075aec0bdd02e  vmovaps [rsp+0xD0], xmm14
000075aec0bdd037  vmovaps [rsp+0xE0], xmm15
000075aec0bdd040  sub rsp, 0x30
000075aec0bdd044  movaps [rsp], xmm3
000075aec0bdd048  movaps [rsp+0x10], xmm5
000075aec0bdd04d  movaps [rsp+0x20], xmm4
000075aec0bdd052  lea rdi, [rsp]
000075aec0bdd056  mov esi, 0x00
000075aec0bdd05b  mov rax, 0x57F4B31E6530
000075aec0bdd065  call rax
000075aec0bdd067  movaps xmm3, [rsp]
000075aec0bdd06b  add rsp, 0x30
000075aec0bdd06f  vmovaps xmm0, [rsp]
000075aec0bdd074  vmovaps xmm1, [rsp+0x10]
000075aec0bdd07a  vmovaps xmm2, [rsp+0x20]
000075aec0bdd080  vmovaps xmm4, [rsp+0x30]
000075aec0bdd086  vmovaps xmm5, [rsp+0x40]
000075aec0bdd08c  vmovaps xmm6, [rsp+0x50]
000075aec0bdd092  vmovaps xmm7, [rsp+0x60]
000075aec0bdd098  vmovaps xmm8, [rsp+0x70]
000075aec0bdd09e  vmovaps xmm9, [rsp+0x80]
000075aec0bdd0a7  vmovaps xmm10, [rsp+0x90]
000075aec0bdd0b0  vmovaps xmm11, [rsp+0xA0]
000075aec0bdd0b9  vmovaps xmm12, [rsp+0xB0]
000075aec0bdd0c2  vmovaps xmm13, [rsp+0xC0]
000075aec0bdd0cb  vmovaps xmm14, [rsp+0xD0]
000075aec0bdd0d4  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd0dd  add rsp, 0xF0
000075aec0bdd0e4  pop r11
000075aec0bdd0e6  pop r10
000075aec0bdd0e8  pop r9
000075aec0bdd0ea  pop r8
000075aec0bdd0ec  pop rsi
000075aec0bdd0ed  pop rdi
000075aec0bdd0ee  pop rdx
000075aec0bdd0ef  pop rcx
000075aec0bdd0f0  pop rax
000075aec0bdd0f1  add rsp, 0x08
000075aec0bdd0f5  jmp 0x000075AEC0BDBC35
000075aec0bdd0fa  sub rsp, 0x08
000075aec0bdd0fe  push rax
000075aec0bdd0ff  push rcx
000075aec0bdd100  push rdx
000075aec0bdd101  push rdi
000075aec0bdd102  push rsi
000075aec0bdd103  push r8
000075aec0bdd105  push r9
000075aec0bdd107  push r10
000075aec0bdd109  push r11
000075aec0bdd10b  sub rsp, 0xF0
000075aec0bdd112  vmovaps [rsp], xmm0
000075aec0bdd117  vmovaps [rsp+0x10], xmm1
000075aec0bdd11d  vmovaps [rsp+0x20], xmm2
000075aec0bdd123  vmovaps [rsp+0x30], xmm3
000075aec0bdd129  vmovaps [rsp+0x40], xmm4
000075aec0bdd12f  vmovaps [rsp+0x50], xmm6
000075aec0bdd135  vmovaps [rsp+0x60], xmm7
000075aec0bdd13b  vmovaps [rsp+0x70], xmm8
000075aec0bdd141  vmovaps [rsp+0x80], xmm9
000075aec0bdd14a  vmovaps [rsp+0x90], xmm10
000075aec0bdd153  vmovaps [rsp+0xA0], xmm11
000075aec0bdd15c  vmovaps [rsp+0xB0], xmm12
000075aec0bdd165  vmovaps [rsp+0xC0], xmm13
000075aec0bdd16e  vmovaps [rsp+0xD0], xmm14
000075aec0bdd177  vmovaps [rsp+0xE0], xmm15
000075aec0bdd180  sub rsp, 0x30
000075aec0bdd184  movaps [rsp], xmm5
000075aec0bdd188  movaps [rsp+0x10], xmm8
000075aec0bdd18e  movaps [rsp+0x20], xmm15
000075aec0bdd194  lea rdi, [rsp]
000075aec0bdd198  mov esi, 0x00
000075aec0bdd19d  mov rax, 0x57F4B31E6530
000075aec0bdd1a7  call rax
000075aec0bdd1a9  movaps xmm5, [rsp]
000075aec0bdd1ad  add rsp, 0x30
000075aec0bdd1b1  vmovaps xmm0, [rsp]
000075aec0bdd1b6  vmovaps xmm1, [rsp+0x10]
000075aec0bdd1bc  vmovaps xmm2, [rsp+0x20]
000075aec0bdd1c2  vmovaps xmm3, [rsp+0x30]
000075aec0bdd1c8  vmovaps xmm4, [rsp+0x40]
000075aec0bdd1ce  vmovaps xmm6, [rsp+0x50]
000075aec0bdd1d4  vmovaps xmm7, [rsp+0x60]
000075aec0bdd1da  vmovaps xmm8, [rsp+0x70]
000075aec0bdd1e0  vmovaps xmm9, [rsp+0x80]
000075aec0bdd1e9  vmovaps xmm10, [rsp+0x90]
000075aec0bdd1f2  vmovaps xmm11, [rsp+0xA0]
000075aec0bdd1fb  vmovaps xmm12, [rsp+0xB0]
000075aec0bdd204  vmovaps xmm13, [rsp+0xC0]
000075aec0bdd20d  vmovaps xmm14, [rsp+0xD0]
000075aec0bdd216  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd21f  add rsp, 0xF0
000075aec0bdd226  pop r11
000075aec0bdd228  pop r10
000075aec0bdd22a  pop r9
000075aec0bdd22c  pop r8
000075aec0bdd22e  pop rsi
000075aec0bdd22f  pop rdi
000075aec0bdd230  pop rdx
000075aec0bdd231  pop rcx
000075aec0bdd232  pop rax
000075aec0bdd233  add rsp, 0x08
000075aec0bdd237  jmp 0x000075AEC0BDBC73
000075aec0bdd23c  sub rsp, 0x08
000075aec0bdd240  push rax
000075aec0bdd241  push rcx
000075aec0bdd242  push rdx
000075aec0bdd243  push rdi
000075aec0bdd244  push rsi
000075aec0bdd245  push r8
000075aec0bdd247  push r9
000075aec0bdd249  push r10
000075aec0bdd24b  push r11
000075aec0bdd24d  sub rsp, 0xF0
000075aec0bdd254  vmovaps [rsp], xmm0
000075aec0bdd259  vmovaps [rsp+0x10], xmm1
000075aec0bdd25f  vmovaps [rsp+0x20], xmm2
000075aec0bdd265  vmovaps [rsp+0x30], xmm3
000075aec0bdd26b  vmovaps [rsp+0x40], xmm5
000075aec0bdd271  vmovaps [rsp+0x50], xmm6
000075aec0bdd277  vmovaps [rsp+0x60], xmm7
000075aec0bdd27d  vmovaps [rsp+0x70], xmm8
000075aec0bdd283  vmovaps [rsp+0x80], xmm9
000075aec0bdd28c  vmovaps [rsp+0x90], xmm10
000075aec0bdd295  vmovaps [rsp+0xA0], xmm11
000075aec0bdd29e  vmovaps [rsp+0xB0], xmm12
000075aec0bdd2a7  vmovaps [rsp+0xC0], xmm13
000075aec0bdd2b0  vmovaps [rsp+0xD0], xmm14
000075aec0bdd2b9  vmovaps [rsp+0xE0], xmm15
000075aec0bdd2c2  sub rsp, 0x30
000075aec0bdd2c6  movaps [rsp], xmm4
000075aec0bdd2ca  movaps [rsp+0x10], xmm9
000075aec0bdd2d0  movaps [rsp+0x20], xmm8
000075aec0bdd2d6  lea rdi, [rsp]
000075aec0bdd2da  mov esi, 0x00
000075aec0bdd2df  mov rax, 0x57F4B31E6530
000075aec0bdd2e9  call rax
000075aec0bdd2eb  movaps xmm4, [rsp]
000075aec0bdd2ef  add rsp, 0x30
000075aec0bdd2f3  vmovaps xmm0, [rsp]
000075aec0bdd2f8  vmovaps xmm1, [rsp+0x10]
000075aec0bdd2fe  vmovaps xmm2, [rsp+0x20]
000075aec0bdd304  vmovaps xmm3, [rsp+0x30]
000075aec0bdd30a  vmovaps xmm5, [rsp+0x40]
000075aec0bdd310  vmovaps xmm6, [rsp+0x50]
000075aec0bdd316  vmovaps xmm7, [rsp+0x60]
000075aec0bdd31c  vmovaps xmm8, [rsp+0x70]
000075aec0bdd322  vmovaps xmm9, [rsp+0x80]
000075aec0bdd32b  vmovaps xmm10, [rsp+0x90]
000075aec0bdd334  vmovaps xmm11, [rsp+0xA0]
000075aec0bdd33d  vmovaps xmm12, [rsp+0xB0]
000075aec0bdd346  vmovaps xmm13, [rsp+0xC0]
000075aec0bdd34f  vmovaps xmm14, [rsp+0xD0]
000075aec0bdd358  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd361  add rsp, 0xF0
000075aec0bdd368  pop r11
000075aec0bdd36a  pop r10
000075aec0bdd36c  pop r9
000075aec0bdd36e  pop r8
000075aec0bdd370  pop rsi
000075aec0bdd371  pop rdi
000075aec0bdd372  pop rdx
000075aec0bdd373  pop rcx
000075aec0bdd374  pop rax
000075aec0bdd375  add rsp, 0x08
000075aec0bdd379  jmp 0x000075AEC0BDBC94
000075aec0bdd37e  sub rsp, 0x08
000075aec0bdd382  push rax
000075aec0bdd383  push rcx
000075aec0bdd384  push rdx
000075aec0bdd385  push rdi
000075aec0bdd386  push rsi
000075aec0bdd387  push r8
000075aec0bdd389  push r9
000075aec0bdd38b  push r10
000075aec0bdd38d  push r11
000075aec0bdd38f  sub rsp, 0xF0
000075aec0bdd396  vmovaps [rsp], xmm0
000075aec0bdd39b  vmovaps [rsp+0x10], xmm1
000075aec0bdd3a1  vmovaps [rsp+0x20], xmm2
000075aec0bdd3a7  vmovaps [rsp+0x30], xmm3
000075aec0bdd3ad  vmovaps [rsp+0x40], xmm4
000075aec0bdd3b3  vmovaps [rsp+0x50], xmm5
000075aec0bdd3b9  vmovaps [rsp+0x60], xmm6
000075aec0bdd3bf  vmovaps [rsp+0x70], xmm7
000075aec0bdd3c5  vmovaps [rsp+0x80], xmm8
000075aec0bdd3ce  vmovaps [rsp+0x90], xmm10
000075aec0bdd3d7  vmovaps [rsp+0xA0], xmm11
000075aec0bdd3e0  vmovaps [rsp+0xB0], xmm12
000075aec0bdd3e9  vmovaps [rsp+0xC0], xmm13
000075aec0bdd3f2  vmovaps [rsp+0xD0], xmm14
000075aec0bdd3fb  vmovaps [rsp+0xE0], xmm15
000075aec0bdd404  sub rsp, 0x30
000075aec0bdd408  movaps [rsp], xmm9
000075aec0bdd40d  movaps [rsp+0x10], xmm10
000075aec0bdd413  movaps [rsp+0x20], xmm8
000075aec0bdd419  lea rdi, [rsp]
000075aec0bdd41d  mov esi, 0x00
000075aec0bdd422  mov rax, 0x57F4B31E6530
000075aec0bdd42c  call rax
000075aec0bdd42e  movaps xmm9, [rsp]
000075aec0bdd433  add rsp, 0x30
000075aec0bdd437  vmovaps xmm0, [rsp]
000075aec0bdd43c  vmovaps xmm1, [rsp+0x10]
000075aec0bdd442  vmovaps xmm2, [rsp+0x20]
000075aec0bdd448  vmovaps xmm3, [rsp+0x30]
000075aec0bdd44e  vmovaps xmm4, [rsp+0x40]
000075aec0bdd454  vmovaps xmm5, [rsp+0x50]
000075aec0bdd45a  vmovaps xmm6, [rsp+0x60]
000075aec0bdd460  vmovaps xmm7, [rsp+0x70]
000075aec0bdd466  vmovaps xmm8, [rsp+0x80]
000075aec0bdd46f  vmovaps xmm10, [rsp+0x90]
000075aec0bdd478  vmovaps xmm11, [rsp+0xA0]
000075aec0bdd481  vmovaps xmm12, [rsp+0xB0]
000075aec0bdd48a  vmovaps xmm13, [rsp+0xC0]
000075aec0bdd493  vmovaps xmm14, [rsp+0xD0]
000075aec0bdd49c  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd4a5  add rsp, 0xF0
000075aec0bdd4ac  pop r11
000075aec0bdd4ae  pop r10
000075aec0bdd4b0  pop r9
000075aec0bdd4b2  pop r8
000075aec0bdd4b4  pop rsi
000075aec0bdd4b5  pop rdi
000075aec0bdd4b6  pop rdx
000075aec0bdd4b7  pop rcx
000075aec0bdd4b8  pop rax
000075aec0bdd4b9  add rsp, 0x08
000075aec0bdd4bd  jmp 0x000075AEC0BDBCAE
000075aec0bdd4c2  call 0x000075AEC0AB52F0
000075aec0bdd4c7  jmp 0x000075AEC0BDBDC8
000075aec0bdd4cc  call 0x000075AEC0AB52F0
000075aec0bdd4d1  jmp 0x000075AEC0BDBDDE
000075aec0bdd4d6  sub rsp, 0x08
000075aec0bdd4da  push rax
000075aec0bdd4db  push rcx
000075aec0bdd4dc  push rdx
000075aec0bdd4dd  push rdi
000075aec0bdd4de  push rsi
000075aec0bdd4df  push r8
000075aec0bdd4e1  push r9
000075aec0bdd4e3  push r10
000075aec0bdd4e5  push r11
000075aec0bdd4e7  sub rsp, 0xF0
000075aec0bdd4ee  vmovaps [rsp], xmm0
000075aec0bdd4f3  vmovaps [rsp+0x10], xmm2
000075aec0bdd4f9  vmovaps [rsp+0x20], xmm3
000075aec0bdd4ff  vmovaps [rsp+0x30], xmm4
000075aec0bdd505  vmovaps [rsp+0x40], xmm5
000075aec0bdd50b  vmovaps [rsp+0x50], xmm6
000075aec0bdd511  vmovaps [rsp+0x60], xmm7
000075aec0bdd517  vmovaps [rsp+0x70], xmm8
000075aec0bdd51d  vmovaps [rsp+0x80], xmm9
000075aec0bdd526  vmovaps [rsp+0x90], xmm10
000075aec0bdd52f  vmovaps [rsp+0xA0], xmm11
000075aec0bdd538  vmovaps [rsp+0xB0], xmm12
000075aec0bdd541  vmovaps [rsp+0xC0], xmm13
000075aec0bdd54a  vmovaps [rsp+0xD0], xmm14
000075aec0bdd553  vmovaps [rsp+0xE0], xmm15
000075aec0bdd55c  sub rsp, 0x30
000075aec0bdd560  movaps [rsp], xmm1
000075aec0bdd564  movaps [rsp+0x10], xmm6
000075aec0bdd569  movaps [rsp+0x20], xmm15
000075aec0bdd56f  lea rdi, [rsp]
000075aec0bdd573  mov esi, 0x00
000075aec0bdd578  mov rax, 0x57F4B31E6530
000075aec0bdd582  call rax
000075aec0bdd584  movaps xmm1, [rsp]
000075aec0bdd588  add rsp, 0x30
000075aec0bdd58c  vmovaps xmm0, [rsp]
000075aec0bdd591  vmovaps xmm2, [rsp+0x10]
000075aec0bdd597  vmovaps xmm3, [rsp+0x20]
000075aec0bdd59d  vmovaps xmm4, [rsp+0x30]
000075aec0bdd5a3  vmovaps xmm5, [rsp+0x40]
000075aec0bdd5a9  vmovaps xmm6, [rsp+0x50]
000075aec0bdd5af  vmovaps xmm7, [rsp+0x60]
000075aec0bdd5b5  vmovaps xmm8, [rsp+0x70]
000075aec0bdd5bb  vmovaps xmm9, [rsp+0x80]
000075aec0bdd5c4  vmovaps xmm10, [rsp+0x90]
000075aec0bdd5cd  vmovaps xmm11, [rsp+0xA0]
000075aec0bdd5d6  vmovaps xmm12, [rsp+0xB0]
000075aec0bdd5df  vmovaps xmm13, [rsp+0xC0]
000075aec0bdd5e8  vmovaps xmm14, [rsp+0xD0]
000075aec0bdd5f1  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd5fa  add rsp, 0xF0
000075aec0bdd601  pop r11
000075aec0bdd603  pop r10
000075aec0bdd605  pop r9
000075aec0bdd607  pop r8
000075aec0bdd609  pop rsi
000075aec0bdd60a  pop rdi
000075aec0bdd60b  pop rdx
000075aec0bdd60c  pop rcx
000075aec0bdd60d  pop rax
000075aec0bdd60e  add rsp, 0x08
000075aec0bdd612  jmp 0x000075AEC0BDBE1B
000075aec0bdd617  call 0x000075AEC0AC4620
000075aec0bdd61c  jmp 0x000075AEC0BDBE28
000075aec0bdd621  sub rsp, 0x08
000075aec0bdd625  push rax
000075aec0bdd626  push rcx
000075aec0bdd627  push rdx
000075aec0bdd628  push rdi
000075aec0bdd629  push rsi
000075aec0bdd62a  push r8
000075aec0bdd62c  push r9
000075aec0bdd62e  push r10
000075aec0bdd630  push r11
000075aec0bdd632  sub rsp, 0xF0
000075aec0bdd639  vmovaps [rsp], xmm0
000075aec0bdd63e  vmovaps [rsp+0x10], xmm1
000075aec0bdd644  vmovaps [rsp+0x20], xmm2
000075aec0bdd64a  vmovaps [rsp+0x30], xmm3
000075aec0bdd650  vmovaps [rsp+0x40], xmm4
000075aec0bdd656  vmovaps [rsp+0x50], xmm5
000075aec0bdd65c  vmovaps [rsp+0x60], xmm6
000075aec0bdd662  vmovaps [rsp+0x70], xmm7
000075aec0bdd668  vmovaps [rsp+0x80], xmm8
000075aec0bdd671  vmovaps [rsp+0x90], xmm9
000075aec0bdd67a  vmovaps [rsp+0xA0], xmm10
000075aec0bdd683  vmovaps [rsp+0xB0], xmm11
000075aec0bdd68c  vmovaps [rsp+0xC0], xmm12
000075aec0bdd695  vmovaps [rsp+0xD0], xmm13
000075aec0bdd69e  vmovaps [rsp+0xE0], xmm15
000075aec0bdd6a7  sub rsp, 0x30
000075aec0bdd6ab  movaps [rsp], xmm14
000075aec0bdd6b0  movaps [rsp+0x10], xmm4
000075aec0bdd6b5  movaps [rsp+0x20], xmm3
000075aec0bdd6ba  lea rdi, [rsp]
000075aec0bdd6be  mov esi, 0x00
000075aec0bdd6c3  mov rax, 0x57F4B31E6530
000075aec0bdd6cd  call rax
000075aec0bdd6cf  movaps xmm14, [rsp]
000075aec0bdd6d4  add rsp, 0x30
000075aec0bdd6d8  vmovaps xmm0, [rsp]
000075aec0bdd6dd  vmovaps xmm1, [rsp+0x10]
000075aec0bdd6e3  vmovaps xmm2, [rsp+0x20]
000075aec0bdd6e9  vmovaps xmm3, [rsp+0x30]
000075aec0bdd6ef  vmovaps xmm4, [rsp+0x40]
000075aec0bdd6f5  vmovaps xmm5, [rsp+0x50]
000075aec0bdd6fb  vmovaps xmm6, [rsp+0x60]
000075aec0bdd701  vmovaps xmm7, [rsp+0x70]
000075aec0bdd707  vmovaps xmm8, [rsp+0x80]
000075aec0bdd710  vmovaps xmm9, [rsp+0x90]
000075aec0bdd719  vmovaps xmm10, [rsp+0xA0]
000075aec0bdd722  vmovaps xmm11, [rsp+0xB0]
000075aec0bdd72b  vmovaps xmm12, [rsp+0xC0]
000075aec0bdd734  vmovaps xmm13, [rsp+0xD0]
000075aec0bdd73d  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd746  add rsp, 0xF0
000075aec0bdd74d  pop r11
000075aec0bdd74f  pop r10
000075aec0bdd751  pop r9
000075aec0bdd753  pop r8
000075aec0bdd755  pop rsi
000075aec0bdd756  pop rdi
000075aec0bdd757  pop rdx
000075aec0bdd758  pop rcx
000075aec0bdd759  pop rax
000075aec0bdd75a  add rsp, 0x08
000075aec0bdd75e  jmp 0x000075AEC0BDBE42
000075aec0bdd763  sub rsp, 0x08
000075aec0bdd767  push rax
000075aec0bdd768  push rcx
000075aec0bdd769  push rdx
000075aec0bdd76a  push rdi
000075aec0bdd76b  push rsi
000075aec0bdd76c  push r8
000075aec0bdd76e  push r9
000075aec0bdd770  push r10
000075aec0bdd772  push r11
000075aec0bdd774  sub rsp, 0xF0
000075aec0bdd77b  vmovaps [rsp], xmm0
000075aec0bdd780  vmovaps [rsp+0x10], xmm1
000075aec0bdd786  vmovaps [rsp+0x20], xmm2
000075aec0bdd78c  vmovaps [rsp+0x30], xmm3
000075aec0bdd792  vmovaps [rsp+0x40], xmm4
000075aec0bdd798  vmovaps [rsp+0x50], xmm5
000075aec0bdd79e  vmovaps [rsp+0x60], xmm7
000075aec0bdd7a4  vmovaps [rsp+0x70], xmm8
000075aec0bdd7aa  vmovaps [rsp+0x80], xmm9
000075aec0bdd7b3  vmovaps [rsp+0x90], xmm10
000075aec0bdd7bc  vmovaps [rsp+0xA0], xmm11
000075aec0bdd7c5  vmovaps [rsp+0xB0], xmm12
000075aec0bdd7ce  vmovaps [rsp+0xC0], xmm13
000075aec0bdd7d7  vmovaps [rsp+0xD0], xmm14
000075aec0bdd7e0  vmovaps [rsp+0xE0], xmm15
000075aec0bdd7e9  sub rsp, 0x30
000075aec0bdd7ed  movaps [rsp], xmm6
000075aec0bdd7f1  movaps [rsp+0x10], xmm9
000075aec0bdd7f7  movaps [rsp+0x20], xmm7
000075aec0bdd7fc  lea rdi, [rsp]
000075aec0bdd800  mov esi, 0x00
000075aec0bdd805  mov rax, 0x57F4B31E6530
000075aec0bdd80f  call rax
000075aec0bdd811  movaps xmm6, [rsp]
000075aec0bdd815  add rsp, 0x30
000075aec0bdd819  vmovaps xmm0, [rsp]
000075aec0bdd81e  vmovaps xmm1, [rsp+0x10]
000075aec0bdd824  vmovaps xmm2, [rsp+0x20]
000075aec0bdd82a  vmovaps xmm3, [rsp+0x30]
000075aec0bdd830  vmovaps xmm4, [rsp+0x40]
000075aec0bdd836  vmovaps xmm5, [rsp+0x50]
000075aec0bdd83c  vmovaps xmm7, [rsp+0x60]
000075aec0bdd842  vmovaps xmm8, [rsp+0x70]
000075aec0bdd848  vmovaps xmm9, [rsp+0x80]
000075aec0bdd851  vmovaps xmm10, [rsp+0x90]
000075aec0bdd85a  vmovaps xmm11, [rsp+0xA0]
000075aec0bdd863  vmovaps xmm12, [rsp+0xB0]
000075aec0bdd86c  vmovaps xmm13, [rsp+0xC0]
000075aec0bdd875  vmovaps xmm14, [rsp+0xD0]
000075aec0bdd87e  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd887  add rsp, 0xF0
000075aec0bdd88e  pop r11
000075aec0bdd890  pop r10
000075aec0bdd892  pop r9
000075aec0bdd894  pop r8
000075aec0bdd896  pop rsi
000075aec0bdd897  pop rdi
000075aec0bdd898  pop rdx
000075aec0bdd899  pop rcx
000075aec0bdd89a  pop rax
000075aec0bdd89b  add rsp, 0x08
000075aec0bdd89f  jmp 0x000075AEC0BDBE5A
000075aec0bdd8a4  sub rsp, 0x08
000075aec0bdd8a8  push rax
000075aec0bdd8a9  push rcx
000075aec0bdd8aa  push rdx
000075aec0bdd8ab  push rdi
000075aec0bdd8ac  push rsi
000075aec0bdd8ad  push r8
000075aec0bdd8af  push r9
000075aec0bdd8b1  push r10
000075aec0bdd8b3  push r11
000075aec0bdd8b5  sub rsp, 0xF0
000075aec0bdd8bc  vmovaps [rsp], xmm0
000075aec0bdd8c1  vmovaps [rsp+0x10], xmm1
000075aec0bdd8c7  vmovaps [rsp+0x20], xmm2
000075aec0bdd8cd  vmovaps [rsp+0x30], xmm3
000075aec0bdd8d3  vmovaps [rsp+0x40], xmm4
000075aec0bdd8d9  vmovaps [rsp+0x50], xmm5
000075aec0bdd8df  vmovaps [rsp+0x60], xmm6
000075aec0bdd8e5  vmovaps [rsp+0x70], xmm8
000075aec0bdd8eb  vmovaps [rsp+0x80], xmm9
000075aec0bdd8f4  vmovaps [rsp+0x90], xmm10
000075aec0bdd8fd  vmovaps [rsp+0xA0], xmm11
000075aec0bdd906  vmovaps [rsp+0xB0], xmm12
000075aec0bdd90f  vmovaps [rsp+0xC0], xmm13
000075aec0bdd918  vmovaps [rsp+0xD0], xmm14
000075aec0bdd921  vmovaps [rsp+0xE0], xmm15
000075aec0bdd92a  sub rsp, 0x30
000075aec0bdd92e  movaps [rsp], xmm7
000075aec0bdd932  movaps [rsp+0x10], xmm4
000075aec0bdd937  movaps [rsp+0x20], xmm9
000075aec0bdd93d  lea rdi, [rsp]
000075aec0bdd941  mov esi, 0x00
000075aec0bdd946  mov rax, 0x57F4B31E6530
000075aec0bdd950  call rax
000075aec0bdd952  movaps xmm7, [rsp]
000075aec0bdd956  add rsp, 0x30
000075aec0bdd95a  vmovaps xmm0, [rsp]
000075aec0bdd95f  vmovaps xmm1, [rsp+0x10]
000075aec0bdd965  vmovaps xmm2, [rsp+0x20]
000075aec0bdd96b  vmovaps xmm3, [rsp+0x30]
000075aec0bdd971  vmovaps xmm4, [rsp+0x40]
000075aec0bdd977  vmovaps xmm5, [rsp+0x50]
000075aec0bdd97d  vmovaps xmm6, [rsp+0x60]
000075aec0bdd983  vmovaps xmm8, [rsp+0x70]
000075aec0bdd989  vmovaps xmm9, [rsp+0x80]
000075aec0bdd992  vmovaps xmm10, [rsp+0x90]
000075aec0bdd99b  vmovaps xmm11, [rsp+0xA0]
000075aec0bdd9a4  vmovaps xmm12, [rsp+0xB0]
000075aec0bdd9ad  vmovaps xmm13, [rsp+0xC0]
000075aec0bdd9b6  vmovaps xmm14, [rsp+0xD0]
000075aec0bdd9bf  vmovaps xmm15, [rsp+0xE0]
000075aec0bdd9c8  add rsp, 0xF0
000075aec0bdd9cf  pop r11
000075aec0bdd9d1  pop r10
000075aec0bdd9d3  pop r9
000075aec0bdd9d5  pop r8
000075aec0bdd9d7  pop rsi
000075aec0bdd9d8  pop rdi
000075aec0bdd9d9  pop rdx
000075aec0bdd9da  pop rcx
000075aec0bdd9db  pop rax
000075aec0bdd9dc  add rsp, 0x08
000075aec0bdd9e0  jmp 0x000075AEC0BDBE87
000075aec0bdd9e5  sub rsp, 0x08
000075aec0bdd9e9  push rax
000075aec0bdd9ea  push rcx
000075aec0bdd9eb  push rdx
000075aec0bdd9ec  push rdi
000075aec0bdd9ed  push rsi
000075aec0bdd9ee  push r8
000075aec0bdd9f0  push r9
000075aec0bdd9f2  push r10
000075aec0bdd9f4  push r11
000075aec0bdd9f6  sub rsp, 0xF0
000075aec0bdd9fd  vmovaps [rsp], xmm0
000075aec0bdda02  vmovaps [rsp+0x10], xmm1
000075aec0bdda08  vmovaps [rsp+0x20], xmm2
000075aec0bdda0e  vmovaps [rsp+0x30], xmm3
000075aec0bdda14  vmovaps [rsp+0x40], xmm5
000075aec0bdda1a  vmovaps [rsp+0x50], xmm6
000075aec0bdda20  vmovaps [rsp+0x60], xmm7
000075aec0bdda26  vmovaps [rsp+0x70], xmm8
000075aec0bdda2c  vmovaps [rsp+0x80], xmm9
000075aec0bdda35  vmovaps [rsp+0x90], xmm10
000075aec0bdda3e  vmovaps [rsp+0xA0], xmm11
000075aec0bdda47  vmovaps [rsp+0xB0], xmm12
000075aec0bdda50  vmovaps [rsp+0xC0], xmm13
000075aec0bdda59  vmovaps [rsp+0xD0], xmm14
000075aec0bdda62  vmovaps [rsp+0xE0], xmm15
000075aec0bdda6b  sub rsp, 0x30
000075aec0bdda6f  movaps [rsp], xmm4
000075aec0bdda73  movaps [rsp+0x10], xmm15
000075aec0bdda79  movaps [rsp+0x20], xmm9
000075aec0bdda7f  lea rdi, [rsp]
000075aec0bdda83  mov esi, 0x00
000075aec0bdda88  mov rax, 0x57F4B31E6530
000075aec0bdda92  call rax
000075aec0bdda94  movaps xmm4, [rsp]
000075aec0bdda98  add rsp, 0x30
000075aec0bdda9c  vmovaps xmm0, [rsp]
000075aec0bddaa1  vmovaps xmm1, [rsp+0x10]
000075aec0bddaa7  vmovaps xmm2, [rsp+0x20]
000075aec0bddaad  vmovaps xmm3, [rsp+0x30]
000075aec0bddab3  vmovaps xmm5, [rsp+0x40]
000075aec0bddab9  vmovaps xmm6, [rsp+0x50]
000075aec0bddabf  vmovaps xmm7, [rsp+0x60]
000075aec0bddac5  vmovaps xmm8, [rsp+0x70]
000075aec0bddacb  vmovaps xmm9, [rsp+0x80]
000075aec0bddad4  vmovaps xmm10, [rsp+0x90]
000075aec0bddadd  vmovaps xmm11, [rsp+0xA0]
000075aec0bddae6  vmovaps xmm12, [rsp+0xB0]
000075aec0bddaef  vmovaps xmm13, [rsp+0xC0]
000075aec0bddaf8  vmovaps xmm14, [rsp+0xD0]
000075aec0bddb01  vmovaps xmm15, [rsp+0xE0]
000075aec0bddb0a  add rsp, 0xF0
000075aec0bddb11  pop r11
000075aec0bddb13  pop r10
000075aec0bddb15  pop r9
000075aec0bddb17  pop r8
000075aec0bddb19  pop rsi
000075aec0bddb1a  pop rdi
000075aec0bddb1b  pop rdx
000075aec0bddb1c  pop rcx
000075aec0bddb1d  pop rax
000075aec0bddb1e  add rsp, 0x08
000075aec0bddb22  jmp 0x000075AEC0BDBEAC
000075aec0bddb27  call 0x000075AEC0AC4620
000075aec0bddb2c  jmp 0x000075AEC0BDBEB9
000075aec0bddb31  sub rsp, 0x08
000075aec0bddb35  push rax
000075aec0bddb36  push rcx
000075aec0bddb37  push rdx
000075aec0bddb38  push rdi
000075aec0bddb39  push rsi
000075aec0bddb3a  push r8
000075aec0bddb3c  push r9
000075aec0bddb3e  push r10
000075aec0bddb40  push r11
000075aec0bddb42  sub rsp, 0xF0
000075aec0bddb49  vmovaps [rsp], xmm0
000075aec0bddb4e  vmovaps [rsp+0x10], xmm1
000075aec0bddb54  vmovaps [rsp+0x20], xmm2
000075aec0bddb5a  vmovaps [rsp+0x30], xmm4
000075aec0bddb60  vmovaps [rsp+0x40], xmm5
000075aec0bddb66  vmovaps [rsp+0x50], xmm6
000075aec0bddb6c  vmovaps [rsp+0x60], xmm7
000075aec0bddb72  vmovaps [rsp+0x70], xmm8
000075aec0bddb78  vmovaps [rsp+0x80], xmm9
000075aec0bddb81  vmovaps [rsp+0x90], xmm10
000075aec0bddb8a  vmovaps [rsp+0xA0], xmm11
000075aec0bddb93  vmovaps [rsp+0xB0], xmm12
000075aec0bddb9c  vmovaps [rsp+0xC0], xmm13
000075aec0bddba5  vmovaps [rsp+0xD0], xmm14
000075aec0bddbae  vmovaps [rsp+0xE0], xmm15
000075aec0bddbb7  sub rsp, 0x30
000075aec0bddbbb  movaps [rsp], xmm3
000075aec0bddbbf  movaps [rsp+0x10], xmm1
000075aec0bddbc4  movaps [rsp+0x20], xmm9
000075aec0bddbca  lea rdi, [rsp]
000075aec0bddbce  mov esi, 0x00
000075aec0bddbd3  mov rax, 0x57F4B31E6530
000075aec0bddbdd  call rax
000075aec0bddbdf  movaps xmm3, [rsp]
000075aec0bddbe3  add rsp, 0x30
000075aec0bddbe7  vmovaps xmm0, [rsp]
000075aec0bddbec  vmovaps xmm1, [rsp+0x10]
000075aec0bddbf2  vmovaps xmm2, [rsp+0x20]
000075aec0bddbf8  vmovaps xmm4, [rsp+0x30]
000075aec0bddbfe  vmovaps xmm5, [rsp+0x40]
000075aec0bddc04  vmovaps xmm6, [rsp+0x50]
000075aec0bddc0a  vmovaps xmm7, [rsp+0x60]
000075aec0bddc10  vmovaps xmm8, [rsp+0x70]
000075aec0bddc16  vmovaps xmm9, [rsp+0x80]
000075aec0bddc1f  vmovaps xmm10, [rsp+0x90]
000075aec0bddc28  vmovaps xmm11, [rsp+0xA0]
000075aec0bddc31  vmovaps xmm12, [rsp+0xB0]
000075aec0bddc3a  vmovaps xmm13, [rsp+0xC0]
000075aec0bddc43  vmovaps xmm14, [rsp+0xD0]
000075aec0bddc4c  vmovaps xmm15, [rsp+0xE0]
000075aec0bddc55  add rsp, 0xF0
000075aec0bddc5c  pop r11
000075aec0bddc5e  pop r10
000075aec0bddc60  pop r9
000075aec0bddc62  pop r8
000075aec0bddc64  pop rsi
000075aec0bddc65  pop rdi
000075aec0bddc66  pop rdx
000075aec0bddc67  pop rcx
000075aec0bddc68  pop rax
000075aec0bddc69  add rsp, 0x08
000075aec0bddc6d  jmp 0x000075AEC0BDBEF6
000075aec0bddc72  sub rsp, 0x08
000075aec0bddc76  push rax
000075aec0bddc77  push rcx
000075aec0bddc78  push rdx
000075aec0bddc79  push rdi
000075aec0bddc7a  push rsi
000075aec0bddc7b  push r8
000075aec0bddc7d  push r9
000075aec0bddc7f  push r10
000075aec0bddc81  push r11
000075aec0bddc83  sub rsp, 0xF0
000075aec0bddc8a  vmovaps [rsp], xmm0
000075aec0bddc8f  vmovaps [rsp+0x10], xmm2
000075aec0bddc95  vmovaps [rsp+0x20], xmm3
000075aec0bddc9b  vmovaps [rsp+0x30], xmm4
000075aec0bddca1  vmovaps [rsp+0x40], xmm5
000075aec0bddca7  vmovaps [rsp+0x50], xmm6
000075aec0bddcad  vmovaps [rsp+0x60], xmm7
000075aec0bddcb3  vmovaps [rsp+0x70], xmm8
000075aec0bddcb9  vmovaps [rsp+0x80], xmm9
000075aec0bddcc2  vmovaps [rsp+0x90], xmm10
000075aec0bddccb  vmovaps [rsp+0xA0], xmm11
000075aec0bddcd4  vmovaps [rsp+0xB0], xmm12
000075aec0bddcdd  vmovaps [rsp+0xC0], xmm13
000075aec0bddce6  vmovaps [rsp+0xD0], xmm14
000075aec0bddcef  vmovaps [rsp+0xE0], xmm15
000075aec0bddcf8  sub rsp, 0x30
000075aec0bddcfc  movaps [rsp], xmm1
000075aec0bddd00  movaps [rsp+0x10], xmm15
000075aec0bddd06  movaps [rsp+0x20], xmm9
000075aec0bddd0c  lea rdi, [rsp]
000075aec0bddd10  mov esi, 0x00
000075aec0bddd15  mov rax, 0x57F4B31E6530
000075aec0bddd1f  call rax
000075aec0bddd21  movaps xmm1, [rsp]
000075aec0bddd25  add rsp, 0x30
000075aec0bddd29  vmovaps xmm0, [rsp]
000075aec0bddd2e  vmovaps xmm2, [rsp+0x10]
000075aec0bddd34  vmovaps xmm3, [rsp+0x20]
000075aec0bddd3a  vmovaps xmm4, [rsp+0x30]
000075aec0bddd40  vmovaps xmm5, [rsp+0x40]
000075aec0bddd46  vmovaps xmm6, [rsp+0x50]
000075aec0bddd4c  vmovaps xmm7, [rsp+0x60]
000075aec0bddd52  vmovaps xmm8, [rsp+0x70]
000075aec0bddd58  vmovaps xmm9, [rsp+0x80]
000075aec0bddd61  vmovaps xmm10, [rsp+0x90]
000075aec0bddd6a  vmovaps xmm11, [rsp+0xA0]
000075aec0bddd73  vmovaps xmm12, [rsp+0xB0]
000075aec0bddd7c  vmovaps xmm13, [rsp+0xC0]
000075aec0bddd85  vmovaps xmm14, [rsp+0xD0]
000075aec0bddd8e  vmovaps xmm15, [rsp+0xE0]
000075aec0bddd97  add rsp, 0xF0
000075aec0bddd9e  pop r11
000075aec0bddda0  pop r10
000075aec0bddda2  pop r9
000075aec0bddda4  pop r8
000075aec0bddda6  pop rsi
000075aec0bddda7  pop rdi
000075aec0bddda8  pop rdx
000075aec0bddda9  pop rcx
000075aec0bdddaa  pop rax
000075aec0bdddab  add rsp, 0x08
000075aec0bdddaf  jmp 0x000075AEC0BDBF7E
000075aec0bdddb4  call 0x000075AEC0AC4620
000075aec0bdddb9  jmp 0x000075AEC0BDBF8B
000075aec0bdddbe  sub rsp, 0x08
000075aec0bdddc2  push rax
000075aec0bdddc3  push rcx
000075aec0bdddc4  push rdx
000075aec0bdddc5  push rdi
000075aec0bdddc6  push rsi
000075aec0bdddc7  push r8
000075aec0bdddc9  push r9
000075aec0bdddcb  push r10
000075aec0bdddcd  push r11
000075aec0bdddcf  sub rsp, 0xF0
000075aec0bdddd6  vmovaps [rsp], xmm0
000075aec0bddddb  vmovaps [rsp+0x10], xmm2
000075aec0bddde1  vmovaps [rsp+0x20], xmm3
000075aec0bddde7  vmovaps [rsp+0x30], xmm4
000075aec0bddded  vmovaps [rsp+0x40], xmm5
000075aec0bdddf3  vmovaps [rsp+0x50], xmm6
000075aec0bdddf9  vmovaps [rsp+0x60], xmm7
000075aec0bdddff  vmovaps [rsp+0x70], xmm8
000075aec0bdde05  vmovaps [rsp+0x80], xmm9
000075aec0bdde0e  vmovaps [rsp+0x90], xmm10
000075aec0bdde17  vmovaps [rsp+0xA0], xmm11
000075aec0bdde20  vmovaps [rsp+0xB0], xmm12
000075aec0bdde29  vmovaps [rsp+0xC0], xmm13
000075aec0bdde32  vmovaps [rsp+0xD0], xmm14
000075aec0bdde3b  vmovaps [rsp+0xE0], xmm15
000075aec0bdde44  sub rsp, 0x30
000075aec0bdde48  movaps [rsp], xmm1
000075aec0bdde4c  movaps [rsp+0x10], xmm5
000075aec0bdde51  movaps [rsp+0x20], xmm7
000075aec0bdde56  lea rdi, [rsp]
000075aec0bdde5a  mov esi, 0x00
000075aec0bdde5f  mov rax, 0x57F4B31E6530
000075aec0bdde69  call rax
000075aec0bdde6b  movaps xmm1, [rsp]
000075aec0bdde6f  add rsp, 0x30
000075aec0bdde73  vmovaps xmm0, [rsp]
000075aec0bdde78  vmovaps xmm2, [rsp+0x10]
000075aec0bdde7e  vmovaps xmm3, [rsp+0x20]
000075aec0bdde84  vmovaps xmm4, [rsp+0x30]
000075aec0bdde8a  vmovaps xmm5, [rsp+0x40]
000075aec0bdde90  vmovaps xmm6, [rsp+0x50]
000075aec0bdde96  vmovaps xmm7, [rsp+0x60]
000075aec0bdde9c  vmovaps xmm8, [rsp+0x70]
000075aec0bddea2  vmovaps xmm9, [rsp+0x80]
000075aec0bddeab  vmovaps xmm10, [rsp+0x90]
000075aec0bddeb4  vmovaps xmm11, [rsp+0xA0]
000075aec0bddebd  vmovaps xmm12, [rsp+0xB0]
000075aec0bddec6  vmovaps xmm13, [rsp+0xC0]
000075aec0bddecf  vmovaps xmm14, [rsp+0xD0]
000075aec0bdded8  vmovaps xmm15, [rsp+0xE0]
000075aec0bddee1  add rsp, 0xF0
000075aec0bddee8  pop r11
000075aec0bddeea  pop r10
000075aec0bddeec  pop r9
000075aec0bddeee  pop r8
000075aec0bddef0  pop rsi
000075aec0bddef1  pop rdi
000075aec0bddef2  pop rdx
000075aec0bddef3  pop rcx
000075aec0bddef4  pop rax
000075aec0bddef5  add rsp, 0x08
000075aec0bddef9  jmp 0x000075AEC0BDC030
000075aec0bddefe  sub rsp, 0x08
000075aec0bddf02  push rax
000075aec0bddf03  push rcx
000075aec0bddf04  push rdx
000075aec0bddf05  push rdi
000075aec0bddf06  push rsi
000075aec0bddf07  push r8
000075aec0bddf09  push r9
000075aec0bddf0b  push r10
000075aec0bddf0d  push r11
000075aec0bddf0f  sub rsp, 0xF0
000075aec0bddf16  vmovaps [rsp], xmm0
000075aec0bddf1b  vmovaps [rsp+0x10], xmm1
000075aec0bddf21  vmovaps [rsp+0x20], xmm2
000075aec0bddf27  vmovaps [rsp+0x30], xmm3
000075aec0bddf2d  vmovaps [rsp+0x40], xmm4
000075aec0bddf33  vmovaps [rsp+0x50], xmm5
000075aec0bddf39  vmovaps [rsp+0x60], xmm6
000075aec0bddf3f  vmovaps [rsp+0x70], xmm8
000075aec0bddf45  vmovaps [rsp+0x80], xmm9
000075aec0bddf4e  vmovaps [rsp+0x90], xmm10
000075aec0bddf57  vmovaps [rsp+0xA0], xmm11
000075aec0bddf60  vmovaps [rsp+0xB0], xmm12
000075aec0bddf69  vmovaps [rsp+0xC0], xmm13
000075aec0bddf72  vmovaps [rsp+0xD0], xmm14
000075aec0bddf7b  vmovaps [rsp+0xE0], xmm15
000075aec0bddf84  sub rsp, 0x30
000075aec0bddf88  movaps [rsp], xmm7
000075aec0bddf8c  movaps [rsp+0x10], xmm5
000075aec0bddf91  movaps [rsp+0x20], xmm15
000075aec0bddf97  lea rdi, [rsp]
000075aec0bddf9b  mov esi, 0x00
000075aec0bddfa0  mov rax, 0x57F4B31E6530
000075aec0bddfaa  call rax
000075aec0bddfac  movaps xmm7, [rsp]
000075aec0bddfb0  add rsp, 0x30
000075aec0bddfb4  vmovaps xmm0, [rsp]
000075aec0bddfb9  vmovaps xmm1, [rsp+0x10]
000075aec0bddfbf  vmovaps xmm2, [rsp+0x20]
000075aec0bddfc5  vmovaps xmm3, [rsp+0x30]
000075aec0bddfcb  vmovaps xmm4, [rsp+0x40]
000075aec0bddfd1  vmovaps xmm5, [rsp+0x50]
000075aec0bddfd7  vmovaps xmm6, [rsp+0x60]
000075aec0bddfdd  vmovaps xmm8, [rsp+0x70]
000075aec0bddfe3  vmovaps xmm9, [rsp+0x80]
000075aec0bddfec  vmovaps xmm10, [rsp+0x90]
000075aec0bddff5  vmovaps xmm11, [rsp+0xA0]
000075aec0bddffe  vmovaps xmm12, [rsp+0xB0]
000075aec0bde007  vmovaps xmm13, [rsp+0xC0]
000075aec0bde010  vmovaps xmm14, [rsp+0xD0]
000075aec0bde019  vmovaps xmm15, [rsp+0xE0]
000075aec0bde022  add rsp, 0xF0
000075aec0bde029  pop r11
000075aec0bde02b  pop r10
000075aec0bde02d  pop r9
000075aec0bde02f  pop r8
000075aec0bde031  pop rsi
000075aec0bde032  pop rdi
000075aec0bde033  pop rdx
000075aec0bde034  pop rcx
000075aec0bde035  pop rax
000075aec0bde036  add rsp, 0x08
000075aec0bde03a  jmp 0x000075AEC0BDC066
000075aec0bde03f  call 0x000075AEC0AB52F0
000075aec0bde044  jmp 0x000075AEC0BDC073
000075aec0bde049  sub rsp, 0x08
000075aec0bde04d  push rax
000075aec0bde04e  push rcx
000075aec0bde04f  push rdx
000075aec0bde050  push rdi
000075aec0bde051  push rsi
000075aec0bde052  push r8
000075aec0bde054  push r9
000075aec0bde056  push r10
000075aec0bde058  push r11
000075aec0bde05a  sub rsp, 0xF0
000075aec0bde061  vmovaps [rsp], xmm0
000075aec0bde066  vmovaps [rsp+0x10], xmm1
000075aec0bde06c  vmovaps [rsp+0x20], xmm2
000075aec0bde072  vmovaps [rsp+0x30], xmm3
000075aec0bde078  vmovaps [rsp+0x40], xmm4
000075aec0bde07e  vmovaps [rsp+0x50], xmm5
000075aec0bde084  vmovaps [rsp+0x60], xmm6
000075aec0bde08a  vmovaps [rsp+0x70], xmm7
000075aec0bde090  vmovaps [rsp+0x80], xmm8
000075aec0bde099  vmovaps [rsp+0x90], xmm9
000075aec0bde0a2  vmovaps [rsp+0xA0], xmm10
000075aec0bde0ab  vmovaps [rsp+0xB0], xmm11
000075aec0bde0b4  vmovaps [rsp+0xC0], xmm12
000075aec0bde0bd  vmovaps [rsp+0xD0], xmm13
000075aec0bde0c6  vmovaps [rsp+0xE0], xmm14
000075aec0bde0cf  sub rsp, 0x30
000075aec0bde0d3  movaps [rsp], xmm15
000075aec0bde0d8  movaps [rsp+0x10], xmm5
000075aec0bde0dd  movaps [rsp+0x20], xmm3
000075aec0bde0e2  lea rdi, [rsp]
000075aec0bde0e6  mov esi, 0x00
000075aec0bde0eb  mov rax, 0x57F4B31E6530
000075aec0bde0f5  call rax
000075aec0bde0f7  movaps xmm15, [rsp]
000075aec0bde0fc  add rsp, 0x30
000075aec0bde100  vmovaps xmm0, [rsp]
000075aec0bde105  vmovaps xmm1, [rsp+0x10]
000075aec0bde10b  vmovaps xmm2, [rsp+0x20]
000075aec0bde111  vmovaps xmm3, [rsp+0x30]
000075aec0bde117  vmovaps xmm4, [rsp+0x40]
000075aec0bde11d  vmovaps xmm5, [rsp+0x50]
000075aec0bde123  vmovaps xmm6, [rsp+0x60]
000075aec0bde129  vmovaps xmm7, [rsp+0x70]
000075aec0bde12f  vmovaps xmm8, [rsp+0x80]
000075aec0bde138  vmovaps xmm9, [rsp+0x90]
000075aec0bde141  vmovaps xmm10, [rsp+0xA0]
000075aec0bde14a  vmovaps xmm11, [rsp+0xB0]
000075aec0bde153  vmovaps xmm12, [rsp+0xC0]
000075aec0bde15c  vmovaps xmm13, [rsp+0xD0]
000075aec0bde165  vmovaps xmm14, [rsp+0xE0]
000075aec0bde16e  add rsp, 0xF0
000075aec0bde175  pop r11
000075aec0bde177  pop r10
000075aec0bde179  pop r9
000075aec0bde17b  pop r8
000075aec0bde17d  pop rsi
000075aec0bde17e  pop rdi
000075aec0bde17f  pop rdx
000075aec0bde180  pop rcx
000075aec0bde181  pop rax
000075aec0bde182  add rsp, 0x08
000075aec0bde186  jmp 0x000075AEC0BDC099
000075aec0bde18b  sub rsp, 0x08
000075aec0bde18f  push rax
000075aec0bde190  push rcx
000075aec0bde191  push rdx
000075aec0bde192  push rdi
000075aec0bde193  push rsi
000075aec0bde194  push r8
000075aec0bde196  push r9
000075aec0bde198  push r10
000075aec0bde19a  push r11
000075aec0bde19c  sub rsp, 0xF0
000075aec0bde1a3  vmovaps [rsp], xmm0
000075aec0bde1a8  vmovaps [rsp+0x10], xmm2
000075aec0bde1ae  vmovaps [rsp+0x20], xmm3
000075aec0bde1b4  vmovaps [rsp+0x30], xmm4
000075aec0bde1ba  vmovaps [rsp+0x40], xmm5
000075aec0bde1c0  vmovaps [rsp+0x50], xmm6
000075aec0bde1c6  vmovaps [rsp+0x60], xmm7
000075aec0bde1cc  vmovaps [rsp+0x70], xmm8
000075aec0bde1d2  vmovaps [rsp+0x80], xmm9
000075aec0bde1db  vmovaps [rsp+0x90], xmm10
000075aec0bde1e4  vmovaps [rsp+0xA0], xmm11
000075aec0bde1ed  vmovaps [rsp+0xB0], xmm12
000075aec0bde1f6  vmovaps [rsp+0xC0], xmm13
000075aec0bde1ff  vmovaps [rsp+0xD0], xmm14
000075aec0bde208  vmovaps [rsp+0xE0], xmm15
000075aec0bde211  sub rsp, 0x30
000075aec0bde215  movaps [rsp], xmm1
000075aec0bde219  movaps [rsp+0x10], xmm5
000075aec0bde21e  movaps [rsp+0x20], xmm4
000075aec0bde223  lea rdi, [rsp]
000075aec0bde227  mov esi, 0x00
000075aec0bde22c  mov rax, 0x57F4B31E6530
000075aec0bde236  call rax
000075aec0bde238  movaps xmm1, [rsp]
000075aec0bde23c  add rsp, 0x30
000075aec0bde240  vmovaps xmm0, [rsp]
000075aec0bde245  vmovaps xmm2, [rsp+0x10]
000075aec0bde24b  vmovaps xmm3, [rsp+0x20]
000075aec0bde251  vmovaps xmm4, [rsp+0x30]
000075aec0bde257  vmovaps xmm5, [rsp+0x40]
000075aec0bde25d  vmovaps xmm6, [rsp+0x50]
000075aec0bde263  vmovaps xmm7, [rsp+0x60]
000075aec0bde269  vmovaps xmm8, [rsp+0x70]
000075aec0bde26f  vmovaps xmm9, [rsp+0x80]
000075aec0bde278  vmovaps xmm10, [rsp+0x90]
000075aec0bde281  vmovaps xmm11, [rsp+0xA0]
000075aec0bde28a  vmovaps xmm12, [rsp+0xB0]
000075aec0bde293  vmovaps xmm13, [rsp+0xC0]
000075aec0bde29c  vmovaps xmm14, [rsp+0xD0]
000075aec0bde2a5  vmovaps xmm15, [rsp+0xE0]
000075aec0bde2ae  add rsp, 0xF0
000075aec0bde2b5  pop r11
000075aec0bde2b7  pop r10
000075aec0bde2b9  pop r9
000075aec0bde2bb  pop r8
000075aec0bde2bd  pop rsi
000075aec0bde2be  pop rdi
000075aec0bde2bf  pop rdx
000075aec0bde2c0  pop rcx
000075aec0bde2c1  pop rax
000075aec0bde2c2  add rsp, 0x08
000075aec0bde2c6  jmp 0x000075AEC0BDC0B9
000075aec0bde2cb  sub rsp, 0x08
000075aec0bde2cf  push rax
000075aec0bde2d0  push rcx
000075aec0bde2d1  push rdx
000075aec0bde2d2  push rdi
000075aec0bde2d3  push rsi
000075aec0bde2d4  push r8
000075aec0bde2d6  push r9
000075aec0bde2d8  push r10
000075aec0bde2da  push r11
000075aec0bde2dc  sub rsp, 0xF0
000075aec0bde2e3  vmovaps [rsp], xmm0
000075aec0bde2e8  vmovaps [rsp+0x10], xmm1
000075aec0bde2ee  vmovaps [rsp+0x20], xmm2
000075aec0bde2f4  vmovaps [rsp+0x30], xmm3
000075aec0bde2fa  vmovaps [rsp+0x40], xmm5
000075aec0bde300  vmovaps [rsp+0x50], xmm6
000075aec0bde306  vmovaps [rsp+0x60], xmm7
000075aec0bde30c  vmovaps [rsp+0x70], xmm8
000075aec0bde312  vmovaps [rsp+0x80], xmm9
000075aec0bde31b  vmovaps [rsp+0x90], xmm10
000075aec0bde324  vmovaps [rsp+0xA0], xmm11
000075aec0bde32d  vmovaps [rsp+0xB0], xmm12
000075aec0bde336  vmovaps [rsp+0xC0], xmm13
000075aec0bde33f  vmovaps [rsp+0xD0], xmm14
000075aec0bde348  vmovaps [rsp+0xE0], xmm15
000075aec0bde351  sub rsp, 0x30
000075aec0bde355  movaps [rsp], xmm4
000075aec0bde359  movaps [rsp+0x10], xmm3
000075aec0bde35e  movaps [rsp+0x20], xmm5
000075aec0bde363  lea rdi, [rsp]
000075aec0bde367  mov esi, 0x00
000075aec0bde36c  mov rax, 0x57F4B31E6530
000075aec0bde376  call rax
000075aec0bde378  movaps xmm4, [rsp]
000075aec0bde37c  add rsp, 0x30
000075aec0bde380  vmovaps xmm0, [rsp]
000075aec0bde385  vmovaps xmm1, [rsp+0x10]
000075aec0bde38b  vmovaps xmm2, [rsp+0x20]
000075aec0bde391  vmovaps xmm3, [rsp+0x30]
000075aec0bde397  vmovaps xmm5, [rsp+0x40]
000075aec0bde39d  vmovaps xmm6, [rsp+0x50]
000075aec0bde3a3  vmovaps xmm7, [rsp+0x60]
000075aec0bde3a9  vmovaps xmm8, [rsp+0x70]
000075aec0bde3af  vmovaps xmm9, [rsp+0x80]
000075aec0bde3b8  vmovaps xmm10, [rsp+0x90]
000075aec0bde3c1  vmovaps xmm11, [rsp+0xA0]
000075aec0bde3ca  vmovaps xmm12, [rsp+0xB0]
000075aec0bde3d3  vmovaps xmm13, [rsp+0xC0]
000075aec0bde3dc  vmovaps xmm14, [rsp+0xD0]
000075aec0bde3e5  vmovaps xmm15, [rsp+0xE0]
000075aec0bde3ee  add rsp, 0xF0
000075aec0bde3f5  pop r11
000075aec0bde3f7  pop r10
000075aec0bde3f9  pop r9
000075aec0bde3fb  pop r8
000075aec0bde3fd  pop rsi
000075aec0bde3fe  pop rdi
000075aec0bde3ff  pop rdx
000075aec0bde400  pop rcx
000075aec0bde401  pop rax
000075aec0bde402  add rsp, 0x08
000075aec0bde406  jmp 0x000075AEC0BDC107
000075aec0bde40b  call 0x000075AEC0AB52F0
000075aec0bde410  jmp 0x000075AEC0BDC114
000075aec0bde415  sub rsp, 0x08
000075aec0bde419  push rax
000075aec0bde41a  push rcx
000075aec0bde41b  push rdx
000075aec0bde41c  push rdi
000075aec0bde41d  push rsi
000075aec0bde41e  push r8
000075aec0bde420  push r9
000075aec0bde422  push r10
000075aec0bde424  push r11
000075aec0bde426  sub rsp, 0xF0
000075aec0bde42d  vmovaps [rsp], xmm0
000075aec0bde432  vmovaps [rsp+0x10], xmm1
000075aec0bde438  vmovaps [rsp+0x20], xmm2
000075aec0bde43e  vmovaps [rsp+0x30], xmm3
000075aec0bde444  vmovaps [rsp+0x40], xmm4
000075aec0bde44a  vmovaps [rsp+0x50], xmm6
000075aec0bde450  vmovaps [rsp+0x60], xmm7
000075aec0bde456  vmovaps [rsp+0x70], xmm8
000075aec0bde45c  vmovaps [rsp+0x80], xmm9
000075aec0bde465  vmovaps [rsp+0x90], xmm10
000075aec0bde46e  vmovaps [rsp+0xA0], xmm11
000075aec0bde477  vmovaps [rsp+0xB0], xmm12
000075aec0bde480  vmovaps [rsp+0xC0], xmm13
000075aec0bde489  vmovaps [rsp+0xD0], xmm14
000075aec0bde492  vmovaps [rsp+0xE0], xmm15
000075aec0bde49b  sub rsp, 0x30
000075aec0bde49f  movaps [rsp], xmm5
000075aec0bde4a3  movaps [rsp+0x10], xmm6
000075aec0bde4a8  movaps [rsp+0x20], xmm3
000075aec0bde4ad  lea rdi, [rsp]
000075aec0bde4b1  mov esi, 0x00
000075aec0bde4b6  mov rax, 0x57F4B31E6530
000075aec0bde4c0  call rax
000075aec0bde4c2  movaps xmm5, [rsp]
000075aec0bde4c6  add rsp, 0x30
000075aec0bde4ca  vmovaps xmm0, [rsp]
000075aec0bde4cf  vmovaps xmm1, [rsp+0x10]
000075aec0bde4d5  vmovaps xmm2, [rsp+0x20]
000075aec0bde4db  vmovaps xmm3, [rsp+0x30]
000075aec0bde4e1  vmovaps xmm4, [rsp+0x40]
000075aec0bde4e7  vmovaps xmm6, [rsp+0x50]
000075aec0bde4ed  vmovaps xmm7, [rsp+0x60]
000075aec0bde4f3  vmovaps xmm8, [rsp+0x70]
000075aec0bde4f9  vmovaps xmm9, [rsp+0x80]
000075aec0bde502  vmovaps xmm10, [rsp+0x90]
000075aec0bde50b  vmovaps xmm11, [rsp+0xA0]
000075aec0bde514  vmovaps xmm12, [rsp+0xB0]
000075aec0bde51d  vmovaps xmm13, [rsp+0xC0]
000075aec0bde526  vmovaps xmm14, [rsp+0xD0]
000075aec0bde52f  vmovaps xmm15, [rsp+0xE0]
000075aec0bde538  add rsp, 0xF0
000075aec0bde53f  pop r11
000075aec0bde541  pop r10
000075aec0bde543  pop r9
000075aec0bde545  pop r8
000075aec0bde547  pop rsi
000075aec0bde548  pop rdi
000075aec0bde549  pop rdx
000075aec0bde54a  pop rcx
000075aec0bde54b  pop rax
000075aec0bde54c  add rsp, 0x08
000075aec0bde550  jmp 0x000075AEC0BDC13A
000075aec0bde555  sub rsp, 0x08
000075aec0bde559  push rax
000075aec0bde55a  push rcx
000075aec0bde55b  push rdx
000075aec0bde55c  push rdi
000075aec0bde55d  push rsi
000075aec0bde55e  push r8
000075aec0bde560  push r9
000075aec0bde562  push r10
000075aec0bde564  push r11
000075aec0bde566  sub rsp, 0xF0
000075aec0bde56d  vmovaps [rsp], xmm0
000075aec0bde572  vmovaps [rsp+0x10], xmm1
000075aec0bde578  vmovaps [rsp+0x20], xmm2
000075aec0bde57e  vmovaps [rsp+0x30], xmm3
000075aec0bde584  vmovaps [rsp+0x40], xmm4
000075aec0bde58a  vmovaps [rsp+0x50], xmm5
000075aec0bde590  vmovaps [rsp+0x60], xmm7
000075aec0bde596  vmovaps [rsp+0x70], xmm8
000075aec0bde59c  vmovaps [rsp+0x80], xmm9
000075aec0bde5a5  vmovaps [rsp+0x90], xmm10
000075aec0bde5ae  vmovaps [rsp+0xA0], xmm11
000075aec0bde5b7  vmovaps [rsp+0xB0], xmm12
000075aec0bde5c0  vmovaps [rsp+0xC0], xmm13
000075aec0bde5c9  vmovaps [rsp+0xD0], xmm14
000075aec0bde5d2  vmovaps [rsp+0xE0], xmm15
000075aec0bde5db  sub rsp, 0x30
000075aec0bde5df  movaps [rsp], xmm6
000075aec0bde5e3  movaps [rsp+0x10], xmm9
000075aec0bde5e9  movaps [rsp+0x20], xmm1
000075aec0bde5ee  lea rdi, [rsp]
000075aec0bde5f2  mov esi, 0x00
000075aec0bde5f7  mov rax, 0x57F4B31E6530
000075aec0bde601  call rax
000075aec0bde603  movaps xmm6, [rsp]
000075aec0bde607  add rsp, 0x30
000075aec0bde60b  vmovaps xmm0, [rsp]
000075aec0bde610  vmovaps xmm1, [rsp+0x10]
000075aec0bde616  vmovaps xmm2, [rsp+0x20]
000075aec0bde61c  vmovaps xmm3, [rsp+0x30]
000075aec0bde622  vmovaps xmm4, [rsp+0x40]
000075aec0bde628  vmovaps xmm5, [rsp+0x50]
000075aec0bde62e  vmovaps xmm7, [rsp+0x60]
000075aec0bde634  vmovaps xmm8, [rsp+0x70]
000075aec0bde63a  vmovaps xmm9, [rsp+0x80]
000075aec0bde643  vmovaps xmm10, [rsp+0x90]
000075aec0bde64c  vmovaps xmm11, [rsp+0xA0]
000075aec0bde655  vmovaps xmm12, [rsp+0xB0]
000075aec0bde65e  vmovaps xmm13, [rsp+0xC0]
000075aec0bde667  vmovaps xmm14, [rsp+0xD0]
000075aec0bde670  vmovaps xmm15, [rsp+0xE0]
000075aec0bde679  add rsp, 0xF0
000075aec0bde680  pop r11
000075aec0bde682  pop r10
000075aec0bde684  pop r9
000075aec0bde686  pop r8
000075aec0bde688  pop rsi
000075aec0bde689  pop rdi
000075aec0bde68a  pop rdx
000075aec0bde68b  pop rcx
000075aec0bde68c  pop rax
000075aec0bde68d  add rsp, 0x08
000075aec0bde691  jmp 0x000075AEC0BDC15E
000075aec0bde696  sub rsp, 0x08
000075aec0bde69a  push rax
000075aec0bde69b  push rcx
000075aec0bde69c  push rdx
000075aec0bde69d  push rdi
000075aec0bde69e  push rsi
000075aec0bde69f  push r8
000075aec0bde6a1  push r9
000075aec0bde6a3  push r10
000075aec0bde6a5  push r11
000075aec0bde6a7  sub rsp, 0xF0
000075aec0bde6ae  vmovaps [rsp], xmm0
000075aec0bde6b3  vmovaps [rsp+0x10], xmm1
000075aec0bde6b9  vmovaps [rsp+0x20], xmm2
000075aec0bde6bf  vmovaps [rsp+0x30], xmm3
000075aec0bde6c5  vmovaps [rsp+0x40], xmm4
000075aec0bde6cb  vmovaps [rsp+0x50], xmm5
000075aec0bde6d1  vmovaps [rsp+0x60], xmm6
000075aec0bde6d7  vmovaps [rsp+0x70], xmm7
000075aec0bde6dd  vmovaps [rsp+0x80], xmm8
000075aec0bde6e6  vmovaps [rsp+0x90], xmm10
000075aec0bde6ef  vmovaps [rsp+0xA0], xmm11
000075aec0bde6f8  vmovaps [rsp+0xB0], xmm12
000075aec0bde701  vmovaps [rsp+0xC0], xmm13
000075aec0bde70a  vmovaps [rsp+0xD0], xmm14
000075aec0bde713  vmovaps [rsp+0xE0], xmm15
000075aec0bde71c  sub rsp, 0x30
000075aec0bde720  movaps [rsp], xmm9
000075aec0bde725  movaps [rsp+0x10], xmm3
000075aec0bde72a  movaps [rsp+0x20], xmm1
000075aec0bde72f  lea rdi, [rsp]
000075aec0bde733  mov esi, 0x00
000075aec0bde738  mov rax, 0x57F4B31E6530
000075aec0bde742  call rax
000075aec0bde744  movaps xmm9, [rsp]
000075aec0bde749  add rsp, 0x30
000075aec0bde74d  vmovaps xmm0, [rsp]
000075aec0bde752  vmovaps xmm1, [rsp+0x10]
000075aec0bde758  vmovaps xmm2, [rsp+0x20]
000075aec0bde75e  vmovaps xmm3, [rsp+0x30]
000075aec0bde764  vmovaps xmm4, [rsp+0x40]
000075aec0bde76a  vmovaps xmm5, [rsp+0x50]
000075aec0bde770  vmovaps xmm6, [rsp+0x60]
000075aec0bde776  vmovaps xmm7, [rsp+0x70]
000075aec0bde77c  vmovaps xmm8, [rsp+0x80]
000075aec0bde785  vmovaps xmm10, [rsp+0x90]
000075aec0bde78e  vmovaps xmm11, [rsp+0xA0]
000075aec0bde797  vmovaps xmm12, [rsp+0xB0]
000075aec0bde7a0  vmovaps xmm13, [rsp+0xC0]
000075aec0bde7a9  vmovaps xmm14, [rsp+0xD0]
000075aec0bde7b2  vmovaps xmm15, [rsp+0xE0]
000075aec0bde7bb  add rsp, 0xF0
000075aec0bde7c2  pop r11
000075aec0bde7c4  pop r10
000075aec0bde7c6  pop r9
000075aec0bde7c8  pop r8
000075aec0bde7ca  pop rsi
000075aec0bde7cb  pop rdi
000075aec0bde7cc  pop rdx
000075aec0bde7cd  pop rcx
000075aec0bde7ce  pop rax
000075aec0bde7cf  add rsp, 0x08
000075aec0bde7d3  jmp 0x000075AEC0BDC1AA
000075aec0bde7d8  call 0x000075AEC0AB52F0
000075aec0bde7dd  jmp 0x000075AEC0BDC1B7
000075aec0bde7e2  sub rsp, 0x08
000075aec0bde7e6  push rax
000075aec0bde7e7  push rcx
000075aec0bde7e8  push rdx
000075aec0bde7e9  push rdi
000075aec0bde7ea  push rsi
000075aec0bde7eb  push r8
000075aec0bde7ed  push r9
000075aec0bde7ef  push r10
000075aec0bde7f1  push r11
000075aec0bde7f3  sub rsp, 0xF0
000075aec0bde7fa  vmovaps [rsp], xmm0
000075aec0bde7ff  vmovaps [rsp+0x10], xmm1
000075aec0bde805  vmovaps [rsp+0x20], xmm2
000075aec0bde80b  vmovaps [rsp+0x30], xmm3
000075aec0bde811  vmovaps [rsp+0x40], xmm4
000075aec0bde817  vmovaps [rsp+0x50], xmm5
000075aec0bde81d  vmovaps [rsp+0x60], xmm6
000075aec0bde823  vmovaps [rsp+0x70], xmm7
000075aec0bde829  vmovaps [rsp+0x80], xmm8
000075aec0bde832  vmovaps [rsp+0x90], xmm9
000075aec0bde83b  vmovaps [rsp+0xA0], xmm10
000075aec0bde844  vmovaps [rsp+0xB0], xmm11
000075aec0bde84d  vmovaps [rsp+0xC0], xmm12
000075aec0bde856  vmovaps [rsp+0xD0], xmm13
000075aec0bde85f  vmovaps [rsp+0xE0], xmm14
000075aec0bde868  sub rsp, 0x30
000075aec0bde86c  movaps [rsp], xmm15
000075aec0bde871  movaps [rsp+0x10], xmm3
000075aec0bde876  movaps [rsp+0x20], xmm7
000075aec0bde87b  lea rdi, [rsp]
000075aec0bde87f  mov esi, 0x00
000075aec0bde884  mov rax, 0x57F4B31E6530
000075aec0bde88e  call rax
000075aec0bde890  movaps xmm15, [rsp]
000075aec0bde895  add rsp, 0x30
000075aec0bde899  vmovaps xmm0, [rsp]
000075aec0bde89e  vmovaps xmm1, [rsp+0x10]
000075aec0bde8a4  vmovaps xmm2, [rsp+0x20]
000075aec0bde8aa  vmovaps xmm3, [rsp+0x30]
000075aec0bde8b0  vmovaps xmm4, [rsp+0x40]
000075aec0bde8b6  vmovaps xmm5, [rsp+0x50]
000075aec0bde8bc  vmovaps xmm6, [rsp+0x60]
000075aec0bde8c2  vmovaps xmm7, [rsp+0x70]
000075aec0bde8c8  vmovaps xmm8, [rsp+0x80]
000075aec0bde8d1  vmovaps xmm9, [rsp+0x90]
000075aec0bde8da  vmovaps xmm10, [rsp+0xA0]
000075aec0bde8e3  vmovaps xmm11, [rsp+0xB0]
000075aec0bde8ec  vmovaps xmm12, [rsp+0xC0]
000075aec0bde8f5  vmovaps xmm13, [rsp+0xD0]
000075aec0bde8fe  vmovaps xmm14, [rsp+0xE0]
000075aec0bde907  add rsp, 0xF0
000075aec0bde90e  pop r11
000075aec0bde910  pop r10
000075aec0bde912  pop r9
000075aec0bde914  pop r8
000075aec0bde916  pop rsi
000075aec0bde917  pop rdi
000075aec0bde918  pop rdx
000075aec0bde919  pop rcx
000075aec0bde91a  pop rax
000075aec0bde91b  add rsp, 0x08
000075aec0bde91f  jmp 0x000075AEC0BDC1E3
000075aec0bde924  sub rsp, 0x08
000075aec0bde928  push rax
000075aec0bde929  push rcx
000075aec0bde92a  push rdx
000075aec0bde92b  push rdi
000075aec0bde92c  push rsi
000075aec0bde92d  push r8
000075aec0bde92f  push r9
000075aec0bde931  push r10
000075aec0bde933  push r11
000075aec0bde935  sub rsp, 0xF0
000075aec0bde93c  vmovaps [rsp], xmm0
000075aec0bde941  vmovaps [rsp+0x10], xmm1
000075aec0bde947  vmovaps [rsp+0x20], xmm2
000075aec0bde94d  vmovaps [rsp+0x30], xmm4
000075aec0bde953  vmovaps [rsp+0x40], xmm5
000075aec0bde959  vmovaps [rsp+0x50], xmm6
000075aec0bde95f  vmovaps [rsp+0x60], xmm7
000075aec0bde965  vmovaps [rsp+0x70], xmm8
000075aec0bde96b  vmovaps [rsp+0x80], xmm9
000075aec0bde974  vmovaps [rsp+0x90], xmm10
000075aec0bde97d  vmovaps [rsp+0xA0], xmm11
000075aec0bde986  vmovaps [rsp+0xB0], xmm12
000075aec0bde98f  vmovaps [rsp+0xC0], xmm13
000075aec0bde998  vmovaps [rsp+0xD0], xmm14
000075aec0bde9a1  vmovaps [rsp+0xE0], xmm15
000075aec0bde9aa  sub rsp, 0x30
000075aec0bde9ae  movaps [rsp], xmm3
000075aec0bde9b2  movaps [rsp+0x10], xmm1
000075aec0bde9b7  movaps [rsp+0x20], xmm15
000075aec0bde9bd  lea rdi, [rsp]
000075aec0bde9c1  mov esi, 0x00
000075aec0bde9c6  mov rax, 0x57F4B31E6530
000075aec0bde9d0  call rax
000075aec0bde9d2  movaps xmm3, [rsp]
000075aec0bde9d6  add rsp, 0x30
000075aec0bde9da  vmovaps xmm0, [rsp]
000075aec0bde9df  vmovaps xmm1, [rsp+0x10]
000075aec0bde9e5  vmovaps xmm2, [rsp+0x20]
000075aec0bde9eb  vmovaps xmm4, [rsp+0x30]
000075aec0bde9f1  vmovaps xmm5, [rsp+0x40]
000075aec0bde9f7  vmovaps xmm6, [rsp+0x50]
000075aec0bde9fd  vmovaps xmm7, [rsp+0x60]
000075aec0bdea03  vmovaps xmm8, [rsp+0x70]
000075aec0bdea09  vmovaps xmm9, [rsp+0x80]
000075aec0bdea12  vmovaps xmm10, [rsp+0x90]
000075aec0bdea1b  vmovaps xmm11, [rsp+0xA0]
000075aec0bdea24  vmovaps xmm12, [rsp+0xB0]
000075aec0bdea2d  vmovaps xmm13, [rsp+0xC0]
000075aec0bdea36  vmovaps xmm14, [rsp+0xD0]
000075aec0bdea3f  vmovaps xmm15, [rsp+0xE0]
000075aec0bdea48  add rsp, 0xF0
000075aec0bdea4f  pop r11
000075aec0bdea51  pop r10
000075aec0bdea53  pop r9
000075aec0bdea55  pop r8
000075aec0bdea57  pop rsi
000075aec0bdea58  pop rdi
000075aec0bdea59  pop rdx
000075aec0bdea5a  pop rcx
000075aec0bdea5b  pop rax
000075aec0bdea5c  add rsp, 0x08
000075aec0bdea60  jmp 0x000075AEC0BDC272
000075aec0bdea65  call 0x000075AEC0AB52F0
000075aec0bdea6a  jmp 0x000075AEC0BDC27C
000075aec0bdea6f  sub rsp, 0x08
000075aec0bdea73  push rax
000075aec0bdea74  push rcx
000075aec0bdea75  push rdx
000075aec0bdea76  push rdi
000075aec0bdea77  push rsi
000075aec0bdea78  push r8
000075aec0bdea7a  push r9
000075aec0bdea7c  push r10
000075aec0bdea7e  push r11
000075aec0bdea80  sub rsp, 0xF0
000075aec0bdea87  vmovaps [rsp], xmm0
000075aec0bdea8c  vmovaps [rsp+0x10], xmm1
000075aec0bdea92  vmovaps [rsp+0x20], xmm2
000075aec0bdea98  vmovaps [rsp+0x30], xmm3
000075aec0bdea9e  vmovaps [rsp+0x40], xmm4
000075aec0bdeaa4  vmovaps [rsp+0x50], xmm5
000075aec0bdeaaa  vmovaps [rsp+0x60], xmm6
000075aec0bdeab0  vmovaps [rsp+0x70], xmm7
000075aec0bdeab6  vmovaps [rsp+0x80], xmm8
000075aec0bdeabf  vmovaps [rsp+0x90], xmm9
000075aec0bdeac8  vmovaps [rsp+0xA0], xmm10
000075aec0bdead1  vmovaps [rsp+0xB0], xmm11
000075aec0bdeada  vmovaps [rsp+0xC0], xmm12
000075aec0bdeae3  vmovaps [rsp+0xD0], xmm13
000075aec0bdeaec  vmovaps [rsp+0xE0], xmm14
000075aec0bdeaf5  sub rsp, 0x30
000075aec0bdeaf9  movaps [rsp], xmm15
000075aec0bdeafe  movaps [rsp+0x10], xmm14
000075aec0bdeb04  movaps [rsp+0x20], xmm4
000075aec0bdeb09  lea rdi, [rsp]
000075aec0bdeb0d  mov esi, 0x00
000075aec0bdeb12  mov rax, 0x57F4B31E6530
000075aec0bdeb1c  call rax
000075aec0bdeb1e  movaps xmm15, [rsp]
000075aec0bdeb23  add rsp, 0x30
000075aec0bdeb27  vmovaps xmm0, [rsp]
000075aec0bdeb2c  vmovaps xmm1, [rsp+0x10]
000075aec0bdeb32  vmovaps xmm2, [rsp+0x20]
000075aec0bdeb38  vmovaps xmm3, [rsp+0x30]
000075aec0bdeb3e  vmovaps xmm4, [rsp+0x40]
000075aec0bdeb44  vmovaps xmm5, [rsp+0x50]
000075aec0bdeb4a  vmovaps xmm6, [rsp+0x60]
000075aec0bdeb50  vmovaps xmm7, [rsp+0x70]
000075aec0bdeb56  vmovaps xmm8, [rsp+0x80]
000075aec0bdeb5f  vmovaps xmm9, [rsp+0x90]
000075aec0bdeb68  vmovaps xmm10, [rsp+0xA0]
000075aec0bdeb71  vmovaps xmm11, [rsp+0xB0]
000075aec0bdeb7a  vmovaps xmm12, [rsp+0xC0]
000075aec0bdeb83  vmovaps xmm13, [rsp+0xD0]
000075aec0bdeb8c  vmovaps xmm14, [rsp+0xE0]
000075aec0bdeb95  add rsp, 0xF0
000075aec0bdeb9c  pop r11
000075aec0bdeb9e  pop r10
000075aec0bdeba0  pop r9
000075aec0bdeba2  pop r8
000075aec0bdeba4  pop rsi
000075aec0bdeba5  pop rdi
000075aec0bdeba6  pop rdx
000075aec0bdeba7  pop rcx
000075aec0bdeba8  pop rax
000075aec0bdeba9  add rsp, 0x08
000075aec0bdebad  jmp 0x000075AEC0BDC2AA
000075aec0bdebb2  sub rsp, 0x08
000075aec0bdebb6  push rax
000075aec0bdebb7  push rcx
000075aec0bdebb8  push rdx
000075aec0bdebb9  push rdi
000075aec0bdebba  push rsi
000075aec0bdebbb  push r8
000075aec0bdebbd  push r9
000075aec0bdebbf  push r10
000075aec0bdebc1  push r11
000075aec0bdebc3  sub rsp, 0xF0
000075aec0bdebca  vmovaps [rsp], xmm0
000075aec0bdebcf  vmovaps [rsp+0x10], xmm1
000075aec0bdebd5  vmovaps [rsp+0x20], xmm2
000075aec0bdebdb  vmovaps [rsp+0x30], xmm3
000075aec0bdebe1  vmovaps [rsp+0x40], xmm4
000075aec0bdebe7  vmovaps [rsp+0x50], xmm5
000075aec0bdebed  vmovaps [rsp+0x60], xmm6
000075aec0bdebf3  vmovaps [rsp+0x70], xmm7
000075aec0bdebf9  vmovaps [rsp+0x80], xmm8
000075aec0bdec02  vmovaps [rsp+0x90], xmm9
000075aec0bdec0b  vmovaps [rsp+0xA0], xmm10
000075aec0bdec14  vmovaps [rsp+0xB0], xmm11
000075aec0bdec1d  vmovaps [rsp+0xC0], xmm12
000075aec0bdec26  vmovaps [rsp+0xD0], xmm13
000075aec0bdec2f  vmovaps [rsp+0xE0], xmm15
000075aec0bdec38  sub rsp, 0x30
000075aec0bdec3c  movaps [rsp], xmm14
000075aec0bdec41  movaps [rsp+0x10], xmm2
000075aec0bdec46  movaps [rsp+0x20], xmm1
000075aec0bdec4b  lea rdi, [rsp]
000075aec0bdec4f  mov esi, 0x00
000075aec0bdec54  mov rax, 0x57F4B31E6530
000075aec0bdec5e  call rax
000075aec0bdec60  movaps xmm14, [rsp]
000075aec0bdec65  add rsp, 0x30
000075aec0bdec69  vmovaps xmm0, [rsp]
000075aec0bdec6e  vmovaps xmm1, [rsp+0x10]
000075aec0bdec74  vmovaps xmm2, [rsp+0x20]
000075aec0bdec7a  vmovaps xmm3, [rsp+0x30]
000075aec0bdec80  vmovaps xmm4, [rsp+0x40]
000075aec0bdec86  vmovaps xmm5, [rsp+0x50]
000075aec0bdec8c  vmovaps xmm6, [rsp+0x60]
000075aec0bdec92  vmovaps xmm7, [rsp+0x70]
000075aec0bdec98  vmovaps xmm8, [rsp+0x80]
000075aec0bdeca1  vmovaps xmm9, [rsp+0x90]
000075aec0bdecaa  vmovaps xmm10, [rsp+0xA0]
000075aec0bdecb3  vmovaps xmm11, [rsp+0xB0]
000075aec0bdecbc  vmovaps xmm12, [rsp+0xC0]
000075aec0bdecc5  vmovaps xmm13, [rsp+0xD0]
000075aec0bdecce  vmovaps xmm15, [rsp+0xE0]
000075aec0bdecd7  add rsp, 0xF0
000075aec0bdecde  pop r11
000075aec0bdece0  pop r10
000075aec0bdece2  pop r9
000075aec0bdece4  pop r8
000075aec0bdece6  pop rsi
000075aec0bdece7  pop rdi
000075aec0bdece8  pop rdx
000075aec0bdece9  pop rcx
000075aec0bdecea  pop rax
000075aec0bdeceb  add rsp, 0x08
000075aec0bdecef  jmp 0x000075AEC0BDC2D0
000075aec0bdecf4  sub rsp, 0x08
000075aec0bdecf8  push rax
000075aec0bdecf9  push rcx
000075aec0bdecfa  push rdx
000075aec0bdecfb  push rdi
000075aec0bdecfc  push rsi
000075aec0bdecfd  push r8
000075aec0bdecff  push r9
000075aec0bded01  push r10
000075aec0bded03  push r11
000075aec0bded05  sub rsp, 0xF0
000075aec0bded0c  vmovaps [rsp], xmm0
000075aec0bded11  vmovaps [rsp+0x10], xmm2
000075aec0bded17  vmovaps [rsp+0x20], xmm3
000075aec0bded1d  vmovaps [rsp+0x30], xmm4
000075aec0bded23  vmovaps [rsp+0x40], xmm5
000075aec0bded29  vmovaps [rsp+0x50], xmm6
000075aec0bded2f  vmovaps [rsp+0x60], xmm7
000075aec0bded35  vmovaps [rsp+0x70], xmm8
000075aec0bded3b  vmovaps [rsp+0x80], xmm9
000075aec0bded44  vmovaps [rsp+0x90], xmm10
000075aec0bded4d  vmovaps [rsp+0xA0], xmm11
000075aec0bded56  vmovaps [rsp+0xB0], xmm12
000075aec0bded5f  vmovaps [rsp+0xC0], xmm13
000075aec0bded68  vmovaps [rsp+0xD0], xmm14
000075aec0bded71  vmovaps [rsp+0xE0], xmm15
000075aec0bded7a  sub rsp, 0x30
000075aec0bded7e  movaps [rsp], xmm1
000075aec0bded82  movaps [rsp+0x10], xmm4
000075aec0bded87  movaps [rsp+0x20], xmm9
000075aec0bded8d  lea rdi, [rsp]
000075aec0bded91  mov esi, 0x00
000075aec0bded96  mov rax, 0x57F4B31E6530
000075aec0bdeda0  call rax
000075aec0bdeda2  movaps xmm1, [rsp]
000075aec0bdeda6  add rsp, 0x30
000075aec0bdedaa  vmovaps xmm0, [rsp]
000075aec0bdedaf  vmovaps xmm2, [rsp+0x10]
000075aec0bdedb5  vmovaps xmm3, [rsp+0x20]
000075aec0bdedbb  vmovaps xmm4, [rsp+0x30]
000075aec0bdedc1  vmovaps xmm5, [rsp+0x40]
000075aec0bdedc7  vmovaps xmm6, [rsp+0x50]
000075aec0bdedcd  vmovaps xmm7, [rsp+0x60]
000075aec0bdedd3  vmovaps xmm8, [rsp+0x70]
000075aec0bdedd9  vmovaps xmm9, [rsp+0x80]
000075aec0bdede2  vmovaps xmm10, [rsp+0x90]
000075aec0bdedeb  vmovaps xmm11, [rsp+0xA0]
000075aec0bdedf4  vmovaps xmm12, [rsp+0xB0]
000075aec0bdedfd  vmovaps xmm13, [rsp+0xC0]
000075aec0bdee06  vmovaps xmm14, [rsp+0xD0]
000075aec0bdee0f  vmovaps xmm15, [rsp+0xE0]
000075aec0bdee18  add rsp, 0xF0
000075aec0bdee1f  pop r11
000075aec0bdee21  pop r10
000075aec0bdee23  pop r9
000075aec0bdee25  pop r8
000075aec0bdee27  pop rsi
000075aec0bdee28  pop rdi
000075aec0bdee29  pop rdx
000075aec0bdee2a  pop rcx
000075aec0bdee2b  pop rax
000075aec0bdee2c  add rsp, 0x08
000075aec0bdee30  jmp 0x000075AEC0BDC2EE
000075aec0bdee35  sub rsp, 0x08
000075aec0bdee39  push rax
000075aec0bdee3a  push rcx
000075aec0bdee3b  push rdx
000075aec0bdee3c  push rdi
000075aec0bdee3d  push rsi
000075aec0bdee3e  push r8
000075aec0bdee40  push r9
000075aec0bdee42  push r10
000075aec0bdee44  push r11
000075aec0bdee46  sub rsp, 0xF0
000075aec0bdee4d  vmovaps [rsp], xmm0
000075aec0bdee52  vmovaps [rsp+0x10], xmm1
000075aec0bdee58  vmovaps [rsp+0x20], xmm2
000075aec0bdee5e  vmovaps [rsp+0x30], xmm3
000075aec0bdee64  vmovaps [rsp+0x40], xmm5
000075aec0bdee6a  vmovaps [rsp+0x50], xmm6
000075aec0bdee70  vmovaps [rsp+0x60], xmm7
000075aec0bdee76  vmovaps [rsp+0x70], xmm8
000075aec0bdee7c  vmovaps [rsp+0x80], xmm9
000075aec0bdee85  vmovaps [rsp+0x90], xmm10
000075aec0bdee8e  vmovaps [rsp+0xA0], xmm11
000075aec0bdee97  vmovaps [rsp+0xB0], xmm12
000075aec0bdeea0  vmovaps [rsp+0xC0], xmm13
000075aec0bdeea9  vmovaps [rsp+0xD0], xmm14
000075aec0bdeeb2  vmovaps [rsp+0xE0], xmm15
000075aec0bdeebb  sub rsp, 0x30
000075aec0bdeebf  movaps [rsp], xmm4
000075aec0bdeec3  movaps [rsp+0x10], xmm2
000075aec0bdeec8  movaps [rsp+0x20], xmm9
000075aec0bdeece  lea rdi, [rsp]
000075aec0bdeed2  mov esi, 0x00
000075aec0bdeed7  mov rax, 0x57F4B31E6530
000075aec0bdeee1  call rax
000075aec0bdeee3  movaps xmm4, [rsp]
000075aec0bdeee7  add rsp, 0x30
000075aec0bdeeeb  vmovaps xmm0, [rsp]
000075aec0bdeef0  vmovaps xmm1, [rsp+0x10]
000075aec0bdeef6  vmovaps xmm2, [rsp+0x20]
000075aec0bdeefc  vmovaps xmm3, [rsp+0x30]
000075aec0bdef02  vmovaps xmm5, [rsp+0x40]
000075aec0bdef08  vmovaps xmm6, [rsp+0x50]
000075aec0bdef0e  vmovaps xmm7, [rsp+0x60]
000075aec0bdef14  vmovaps xmm8, [rsp+0x70]
000075aec0bdef1a  vmovaps xmm9, [rsp+0x80]
000075aec0bdef23  vmovaps xmm10, [rsp+0x90]
000075aec0bdef2c  vmovaps xmm11, [rsp+0xA0]
000075aec0bdef35  vmovaps xmm12, [rsp+0xB0]
000075aec0bdef3e  vmovaps xmm13, [rsp+0xC0]
000075aec0bdef47  vmovaps xmm14, [rsp+0xD0]
000075aec0bdef50  vmovaps xmm15, [rsp+0xE0]
000075aec0bdef59  add rsp, 0xF0
000075aec0bdef60  pop r11
000075aec0bdef62  pop r10
000075aec0bdef64  pop r9
000075aec0bdef66  pop r8
000075aec0bdef68  pop rsi
000075aec0bdef69  pop rdi
000075aec0bdef6a  pop rdx
000075aec0bdef6b  pop rcx
000075aec0bdef6c  pop rax
000075aec0bdef6d  add rsp, 0x08
000075aec0bdef71  jmp 0x000075AEC0BDC31E
000075aec0bdef76  sub rsp, 0x08
000075aec0bdef7a  push rax
000075aec0bdef7b  push rcx
000075aec0bdef7c  push rdx
000075aec0bdef7d  push rdi
000075aec0bdef7e  push rsi
000075aec0bdef7f  push r8
000075aec0bdef81  push r9
000075aec0bdef83  push r10
000075aec0bdef85  push r11
000075aec0bdef87  sub rsp, 0xF0
000075aec0bdef8e  vmovaps [rsp], xmm0
000075aec0bdef93  vmovaps [rsp+0x10], xmm1
000075aec0bdef99  vmovaps [rsp+0x20], xmm2
000075aec0bdef9f  vmovaps [rsp+0x30], xmm3
000075aec0bdefa5  vmovaps [rsp+0x40], xmm4
000075aec0bdefab  vmovaps [rsp+0x50], xmm5
000075aec0bdefb1  vmovaps [rsp+0x60], xmm6
000075aec0bdefb7  vmovaps [rsp+0x70], xmm7
000075aec0bdefbd  vmovaps [rsp+0x80], xmm8
000075aec0bdefc6  vmovaps [rsp+0x90], xmm10
000075aec0bdefcf  vmovaps [rsp+0xA0], xmm11
000075aec0bdefd8  vmovaps [rsp+0xB0], xmm12
000075aec0bdefe1  vmovaps [rsp+0xC0], xmm13
000075aec0bdefea  vmovaps [rsp+0xD0], xmm14
000075aec0bdeff3  vmovaps [rsp+0xE0], xmm15
000075aec0bdeffc  sub rsp, 0x30
000075aec0bdf000  movaps [rsp], xmm9
000075aec0bdf005  movaps [rsp+0x10], xmm2
000075aec0bdf00a  movaps [rsp+0x20], xmm1
000075aec0bdf00f  lea rdi, [rsp]
000075aec0bdf013  mov esi, 0x00
000075aec0bdf018  mov rax, 0x57F4B31E6530
000075aec0bdf022  call rax
000075aec0bdf024  movaps xmm9, [rsp]
000075aec0bdf029  add rsp, 0x30
000075aec0bdf02d  vmovaps xmm0, [rsp]
000075aec0bdf032  vmovaps xmm1, [rsp+0x10]
000075aec0bdf038  vmovaps xmm2, [rsp+0x20]
000075aec0bdf03e  vmovaps xmm3, [rsp+0x30]
000075aec0bdf044  vmovaps xmm4, [rsp+0x40]
000075aec0bdf04a  vmovaps xmm5, [rsp+0x50]
000075aec0bdf050  vmovaps xmm6, [rsp+0x60]
000075aec0bdf056  vmovaps xmm7, [rsp+0x70]
000075aec0bdf05c  vmovaps xmm8, [rsp+0x80]
000075aec0bdf065  vmovaps xmm10, [rsp+0x90]
000075aec0bdf06e  vmovaps xmm11, [rsp+0xA0]
000075aec0bdf077  vmovaps xmm12, [rsp+0xB0]
000075aec0bdf080  vmovaps xmm13, [rsp+0xC0]
000075aec0bdf089  vmovaps xmm14, [rsp+0xD0]
000075aec0bdf092  vmovaps xmm15, [rsp+0xE0]
000075aec0bdf09b  add rsp, 0xF0
000075aec0bdf0a2  pop r11
000075aec0bdf0a4  pop r10
000075aec0bdf0a6  pop r9
000075aec0bdf0a8  pop r8
000075aec0bdf0aa  pop rsi
000075aec0bdf0ab  pop rdi
000075aec0bdf0ac  pop rdx
000075aec0bdf0ad  pop rcx
000075aec0bdf0ae  pop rax
000075aec0bdf0af  add rsp, 0x08
000075aec0bdf0b3  jmp 0x000075AEC0BDC354
000075aec0bdf0b8  sub rsp, 0x08
000075aec0bdf0bc  push rax
000075aec0bdf0bd  push rcx
000075aec0bdf0be  push rdx
000075aec0bdf0bf  push rdi
000075aec0bdf0c0  push rsi
000075aec0bdf0c1  push r8
000075aec0bdf0c3  push r9
000075aec0bdf0c5  push r10
000075aec0bdf0c7  push r11
000075aec0bdf0c9  sub rsp, 0xF0
000075aec0bdf0d0  vmovaps [rsp], xmm0
000075aec0bdf0d5  vmovaps [rsp+0x10], xmm2
000075aec0bdf0db  vmovaps [rsp+0x20], xmm3
000075aec0bdf0e1  vmovaps [rsp+0x30], xmm4
000075aec0bdf0e7  vmovaps [rsp+0x40], xmm5
000075aec0bdf0ed  vmovaps [rsp+0x50], xmm6
000075aec0bdf0f3  vmovaps [rsp+0x60], xmm7
000075aec0bdf0f9  vmovaps [rsp+0x70], xmm8
000075aec0bdf0ff  vmovaps [rsp+0x80], xmm9
000075aec0bdf108  vmovaps [rsp+0x90], xmm10
000075aec0bdf111  vmovaps [rsp+0xA0], xmm11
000075aec0bdf11a  vmovaps [rsp+0xB0], xmm12
000075aec0bdf123  vmovaps [rsp+0xC0], xmm13
000075aec0bdf12c  vmovaps [rsp+0xD0], xmm14
000075aec0bdf135  vmovaps [rsp+0xE0], xmm15
000075aec0bdf13e  sub rsp, 0x30
000075aec0bdf142  movaps [rsp], xmm1
000075aec0bdf146  movaps [rsp+0x10], xmm15
000075aec0bdf14c  movaps [rsp+0x20], xmm6
000075aec0bdf151  lea rdi, [rsp]
000075aec0bdf155  mov esi, 0x00
000075aec0bdf15a  mov rax, 0x57F4B31E6530
000075aec0bdf164  call rax
000075aec0bdf166  movaps xmm1, [rsp]
000075aec0bdf16a  add rsp, 0x30
000075aec0bdf16e  vmovaps xmm0, [rsp]
000075aec0bdf173  vmovaps xmm2, [rsp+0x10]
000075aec0bdf179  vmovaps xmm3, [rsp+0x20]
000075aec0bdf17f  vmovaps xmm4, [rsp+0x30]
000075aec0bdf185  vmovaps xmm5, [rsp+0x40]
000075aec0bdf18b  vmovaps xmm6, [rsp+0x50]
000075aec0bdf191  vmovaps xmm7, [rsp+0x60]
000075aec0bdf197  vmovaps xmm8, [rsp+0x70]
000075aec0bdf19d  vmovaps xmm9, [rsp+0x80]
000075aec0bdf1a6  vmovaps xmm10, [rsp+0x90]
000075aec0bdf1af  vmovaps xmm11, [rsp+0xA0]
000075aec0bdf1b8  vmovaps xmm12, [rsp+0xB0]
000075aec0bdf1c1  vmovaps xmm13, [rsp+0xC0]
000075aec0bdf1ca  vmovaps xmm14, [rsp+0xD0]
000075aec0bdf1d3  vmovaps xmm15, [rsp+0xE0]
000075aec0bdf1dc  add rsp, 0xF0
000075aec0bdf1e3  pop r11
000075aec0bdf1e5  pop r10
000075aec0bdf1e7  pop r9
000075aec0bdf1e9  pop r8
000075aec0bdf1eb  pop rsi
000075aec0bdf1ec  pop rdi
000075aec0bdf1ed  pop rdx
000075aec0bdf1ee  pop rcx
000075aec0bdf1ef  pop rax
000075aec0bdf1f0  add rsp, 0x08
000075aec0bdf1f4  jmp 0x000075AEC0BDC375
000075aec0bdf1f9  sub rsp, 0x08
000075aec0bdf1fd  push rax
000075aec0bdf1fe  push rcx
000075aec0bdf1ff  push rdx
000075aec0bdf200  push rdi
000075aec0bdf201  push rsi
000075aec0bdf202  push r8
000075aec0bdf204  push r9
000075aec0bdf206  push r10
000075aec0bdf208  push r11
000075aec0bdf20a  sub rsp, 0xF0
000075aec0bdf211  vmovaps [rsp], xmm0
000075aec0bdf216  vmovaps [rsp+0x10], xmm1
000075aec0bdf21c  vmovaps [rsp+0x20], xmm2
000075aec0bdf222  vmovaps [rsp+0x30], xmm3
000075aec0bdf228  vmovaps [rsp+0x40], xmm4
000075aec0bdf22e  vmovaps [rsp+0x50], xmm5
000075aec0bdf234  vmovaps [rsp+0x60], xmm6
000075aec0bdf23a  vmovaps [rsp+0x70], xmm7
000075aec0bdf240  vmovaps [rsp+0x80], xmm8
000075aec0bdf249  vmovaps [rsp+0x90], xmm9
000075aec0bdf252  vmovaps [rsp+0xA0], xmm10
000075aec0bdf25b  vmovaps [rsp+0xB0], xmm11
000075aec0bdf264  vmovaps [rsp+0xC0], xmm12
000075aec0bdf26d  vmovaps [rsp+0xD0], xmm13
000075aec0bdf276  vmovaps [rsp+0xE0], xmm14
000075aec0bdf27f  sub rsp, 0x30
000075aec0bdf283  movaps [rsp], xmm15
000075aec0bdf288  movaps [rsp+0x10], xmm5
000075aec0bdf28d  movaps [rsp+0x20], xmm3
000075aec0bdf292  lea rdi, [rsp]
000075aec0bdf296  mov esi, 0x00
000075aec0bdf29b  mov rax, 0x57F4B31E6530
000075aec0bdf2a5  call rax
000075aec0bdf2a7  movaps xmm15, [rsp]
000075aec0bdf2ac  add rsp, 0x30
000075aec0bdf2b0  vmovaps xmm0, [rsp]
000075aec0bdf2b5  vmovaps xmm1, [rsp+0x10]
000075aec0bdf2bb  vmovaps xmm2, [rsp+0x20]
000075aec0bdf2c1  vmovaps xmm3, [rsp+0x30]
000075aec0bdf2c7  vmovaps xmm4, [rsp+0x40]
000075aec0bdf2cd  vmovaps xmm5, [rsp+0x50]
000075aec0bdf2d3  vmovaps xmm6, [rsp+0x60]
000075aec0bdf2d9  vmovaps xmm7, [rsp+0x70]
000075aec0bdf2df  vmovaps xmm8, [rsp+0x80]
000075aec0bdf2e8  vmovaps xmm9, [rsp+0x90]
000075aec0bdf2f1  vmovaps xmm10, [rsp+0xA0]
000075aec0bdf2fa  vmovaps xmm11, [rsp+0xB0]
000075aec0bdf303  vmovaps xmm12, [rsp+0xC0]
000075aec0bdf30c  vmovaps xmm13, [rsp+0xD0]
000075aec0bdf315  vmovaps xmm14, [rsp+0xE0]
000075aec0bdf31e  add rsp, 0xF0
000075aec0bdf325  pop r11
000075aec0bdf327  pop r10
000075aec0bdf329  pop r9
000075aec0bdf32b  pop r8
000075aec0bdf32d  pop rsi
000075aec0bdf32e  pop rdi
000075aec0bdf32f  pop rdx
000075aec0bdf330  pop rcx
000075aec0bdf331  pop rax
000075aec0bdf332  add rsp, 0x08
000075aec0bdf336  jmp 0x000075AEC0BDC38F
000075aec0bdf33b  sub rsp, 0x08
000075aec0bdf33f  push rax
000075aec0bdf340  push rcx
000075aec0bdf341  push rdx
000075aec0bdf342  push rdi
000075aec0bdf343  push rsi
000075aec0bdf344  push r8
000075aec0bdf346  push r9
000075aec0bdf348  push r10
000075aec0bdf34a  push r11
000075aec0bdf34c  sub rsp, 0xF0
000075aec0bdf353  vmovaps [rsp], xmm0
000075aec0bdf358  vmovaps [rsp+0x10], xmm1
000075aec0bdf35e  vmovaps [rsp+0x20], xmm2
000075aec0bdf364  vmovaps [rsp+0x30], xmm3
000075aec0bdf36a  vmovaps [rsp+0x40], xmm4
000075aec0bdf370  vmovaps [rsp+0x50], xmm6
000075aec0bdf376  vmovaps [rsp+0x60], xmm7
000075aec0bdf37c  vmovaps [rsp+0x70], xmm8
000075aec0bdf382  vmovaps [rsp+0x80], xmm9
000075aec0bdf38b  vmovaps [rsp+0x90], xmm10
000075aec0bdf394  vmovaps [rsp+0xA0], xmm11
000075aec0bdf39d  vmovaps [rsp+0xB0], xmm12
000075aec0bdf3a6  vmovaps [rsp+0xC0], xmm13
000075aec0bdf3af  vmovaps [rsp+0xD0], xmm14
000075aec0bdf3b8  vmovaps [rsp+0xE0], xmm15
000075aec0bdf3c1  sub rsp, 0x30
000075aec0bdf3c5  movaps [rsp], xmm5
000075aec0bdf3c9  movaps [rsp+0x10], xmm8
000075aec0bdf3cf  movaps [rsp+0x20], xmm6
000075aec0bdf3d4  lea rdi, [rsp]
000075aec0bdf3d8  mov esi, 0x00
000075aec0bdf3dd  mov rax, 0x57F4B31E6530
000075aec0bdf3e7  call rax
000075aec0bdf3e9  movaps xmm5, [rsp]
000075aec0bdf3ed  add rsp, 0x30
000075aec0bdf3f1  vmovaps xmm0, [rsp]
000075aec0bdf3f6  vmovaps xmm1, [rsp+0x10]
000075aec0bdf3fc  vmovaps xmm2, [rsp+0x20]
000075aec0bdf402  vmovaps xmm3, [rsp+0x30]
000075aec0bdf408  vmovaps xmm4, [rsp+0x40]
000075aec0bdf40e  vmovaps xmm6, [rsp+0x50]
000075aec0bdf414  vmovaps xmm7, [rsp+0x60]
000075aec0bdf41a  vmovaps xmm8, [rsp+0x70]
000075aec0bdf420  vmovaps xmm9, [rsp+0x80]
000075aec0bdf429  vmovaps xmm10, [rsp+0x90]
000075aec0bdf432  vmovaps xmm11, [rsp+0xA0]
000075aec0bdf43b  vmovaps xmm12, [rsp+0xB0]
000075aec0bdf444  vmovaps xmm13, [rsp+0xC0]
000075aec0bdf44d  vmovaps xmm14, [rsp+0xD0]
000075aec0bdf456  vmovaps xmm15, [rsp+0xE0]
000075aec0bdf45f  add rsp, 0xF0
000075aec0bdf466  pop r11
000075aec0bdf468  pop r10
000075aec0bdf46a  pop r9
000075aec0bdf46c  pop r8
000075aec0bdf46e  pop rsi
000075aec0bdf46f  pop rdi
000075aec0bdf470  pop rdx
000075aec0bdf471  pop rcx
000075aec0bdf472  pop rax
000075aec0bdf473  add rsp, 0x08
000075aec0bdf477  jmp 0x000075AEC0BDC3B3
000075aec0bdf47c  sub rsp, 0x08
000075aec0bdf480  push rax
000075aec0bdf481  push rcx
000075aec0bdf482  push rdx
000075aec0bdf483  push rdi
000075aec0bdf484  push rsi
000075aec0bdf485  push r8
000075aec0bdf487  push r9
000075aec0bdf489  push r10
000075aec0bdf48b  push r11
000075aec0bdf48d  sub rsp, 0xF0
000075aec0bdf494  vmovaps [rsp], xmm0
000075aec0bdf499  vmovaps [rsp+0x10], xmm1
000075aec0bdf49f  vmovaps [rsp+0x20], xmm2
000075aec0bdf4a5  vmovaps [rsp+0x30], xmm3
000075aec0bdf4ab  vmovaps [rsp+0x40], xmm4
000075aec0bdf4b1  vmovaps [rsp+0x50], xmm5
000075aec0bdf4b7  vmovaps [rsp+0x60], xmm7
000075aec0bdf4bd  vmovaps [rsp+0x70], xmm8
000075aec0bdf4c3  vmovaps [rsp+0x80], xmm9
000075aec0bdf4cc  vmovaps [rsp+0x90], xmm10
000075aec0bdf4d5  vmovaps [rsp+0xA0], xmm11
000075aec0bdf4de  vmovaps [rsp+0xB0], xmm12
000075aec0bdf4e7  vmovaps [rsp+0xC0], xmm13
000075aec0bdf4f0  vmovaps [rsp+0xD0], xmm14
000075aec0bdf4f9  vmovaps [rsp+0xE0], xmm15
000075aec0bdf502  sub rsp, 0x30
000075aec0bdf506  movaps [rsp], xmm6
000075aec0bdf50a  movaps [rsp+0x10], xmm10
000075aec0bdf510  movaps [rsp+0x20], xmm8
000075aec0bdf516  lea rdi, [rsp]
000075aec0bdf51a  mov esi, 0x00
000075aec0bdf51f  mov rax, 0x57F4B31E6530
000075aec0bdf529  call rax
000075aec0bdf52b  movaps xmm6, [rsp]
000075aec0bdf52f  add rsp, 0x30
000075aec0bdf533  vmovaps xmm0, [rsp]
000075aec0bdf538  vmovaps xmm1, [rsp+0x10]
000075aec0bdf53e  vmovaps xmm2, [rsp+0x20]
000075aec0bdf544  vmovaps xmm3, [rsp+0x30]
000075aec0bdf54a  vmovaps xmm4, [rsp+0x40]
000075aec0bdf550  vmovaps xmm5, [rsp+0x50]
000075aec0bdf556  vmovaps xmm7, [rsp+0x60]
000075aec0bdf55c  vmovaps xmm8, [rsp+0x70]
000075aec0bdf562  vmovaps xmm9, [rsp+0x80]
000075aec0bdf56b  vmovaps xmm10, [rsp+0x90]
000075aec0bdf574  vmovaps xmm11, [rsp+0xA0]
000075aec0bdf57d  vmovaps xmm12, [rsp+0xB0]
000075aec0bdf586  vmovaps xmm13, [rsp+0xC0]
000075aec0bdf58f  vmovaps xmm14, [rsp+0xD0]
000075aec0bdf598  vmovaps xmm15, [rsp+0xE0]
000075aec0bdf5a1  add rsp, 0xF0
000075aec0bdf5a8  pop r11
000075aec0bdf5aa  pop r10
000075aec0bdf5ac  pop r9
000075aec0bdf5ae  pop r8
000075aec0bdf5b0  pop rsi
000075aec0bdf5b1  pop rdi
000075aec0bdf5b2  pop rdx
000075aec0bdf5b3  pop rcx
000075aec0bdf5b4  pop rax
000075aec0bdf5b5  add rsp, 0x08
000075aec0bdf5b9  jmp 0x000075AEC0BDC3D8
000075aec0bdf5be  sub rsp, 0x08
000075aec0bdf5c2  push rax
000075aec0bdf5c3  push rcx
000075aec0bdf5c4  push rdx
000075aec0bdf5c5  push rdi
000075aec0bdf5c6  push rsi
000075aec0bdf5c7  push r8
000075aec0bdf5c9  push r9
000075aec0bdf5cb  push r10
000075aec0bdf5cd  push r11
000075aec0bdf5cf  sub rsp, 0xF0
000075aec0bdf5d6  vmovaps [rsp], xmm0
000075aec0bdf5db  vmovaps [rsp+0x10], xmm1
000075aec0bdf5e1  vmovaps [rsp+0x20], xmm2
000075aec0bdf5e7  vmovaps [rsp+0x30], xmm3
000075aec0bdf5ed  vmovaps [rsp+0x40], xmm4
000075aec0bdf5f3  vmovaps [rsp+0x50], xmm5
000075aec0bdf5f9  vmovaps [rsp+0x60], xmm6
000075aec0bdf5ff  vmovaps [rsp+0x70], xmm7
000075aec0bdf605  vmovaps [rsp+0x80], xmm8
000075aec0bdf60e  vmovaps [rsp+0x90], xmm9
000075aec0bdf617  vmovaps [rsp+0xA0], xmm11
000075aec0bdf620  vmovaps [rsp+0xB0], xmm12
000075aec0bdf629  vmovaps [rsp+0xC0], xmm13
000075aec0bdf632  vmovaps [rsp+0xD0], xmm14
000075aec0bdf63b  vmovaps [rsp+0xE0], xmm15
000075aec0bdf644  sub rsp, 0x30
000075aec0bdf648  movaps [rsp], xmm10
000075aec0bdf64d  movaps [rsp+0x10], xmm8
000075aec0bdf653  movaps [rsp+0x20], xmm14
000075aec0bdf659  lea rdi, [rsp]
000075aec0bdf65d  mov esi, 0x00
000075aec0bdf662  mov rax, 0x57F4B31E6530
000075aec0bdf66c  call rax
000075aec0bdf66e  movaps xmm10, [rsp]
000075aec0bdf673  add rsp, 0x30
000075aec0bdf677  vmovaps xmm0, [rsp]
000075aec0bdf67c  vmovaps xmm1, [rsp+0x10]
000075aec0bdf682  vmovaps xmm2, [rsp+0x20]
000075aec0bdf688  vmovaps xmm3, [rsp+0x30]
000075aec0bdf68e  vmovaps xmm4, [rsp+0x40]
000075aec0bdf694  vmovaps xmm5, [rsp+0x50]
000075aec0bdf69a  vmovaps xmm6, [rsp+0x60]
000075aec0bdf6a0  vmovaps xmm7, [rsp+0x70]
000075aec0bdf6a6  vmovaps xmm8, [rsp+0x80]
000075aec0bdf6af  vmovaps xmm9, [rsp+0x90]
000075aec0bdf6b8  vmovaps xmm11, [rsp+0xA0]
000075aec0bdf6c1  vmovaps xmm12, [rsp+0xB0]
000075aec0bdf6ca  vmovaps xmm13, [rsp+0xC0]
000075aec0bdf6d3  vmovaps xmm14, [rsp+0xD0]
000075aec0bdf6dc  vmovaps xmm15, [rsp+0xE0]
000075aec0bdf6e5  add rsp, 0xF0
000075aec0bdf6ec  pop r11
000075aec0bdf6ee  pop r10
000075aec0bdf6f0  pop r9
000075aec0bdf6f2  pop r8
000075aec0bdf6f4  pop rsi
000075aec0bdf6f5  pop rdi
000075aec0bdf6f6  pop rdx
000075aec0bdf6f7  pop rcx
000075aec0bdf6f8  pop rax
000075aec0bdf6f9  add rsp, 0x08
000075aec0bdf6fd  jmp 0x000075AEC0BDC3F8
000075aec0bdf702  sub rsp, 0x08
000075aec0bdf706  push rax
000075aec0bdf707  push rcx
000075aec0bdf708  push rdx
000075aec0bdf709  push rdi
000075aec0bdf70a  push rsi
000075aec0bdf70b  push r8
000075aec0bdf70d  push r9
000075aec0bdf70f  push r10
000075aec0bdf711  push r11
000075aec0bdf713  sub rsp, 0xF0
000075aec0bdf71a  vmovaps [rsp], xmm0
000075aec0bdf71f  vmovaps [rsp+0x10], xmm1
000075aec0bdf725  vmovaps [rsp+0x20], xmm2
000075aec0bdf72b  vmovaps [rsp+0x30], xmm3
000075aec0bdf731  vmovaps [rsp+0x40], xmm4
000075aec0bdf737  vmovaps [rsp+0x50], xmm5
000075aec0bdf73d  vmovaps [rsp+0x60], xmm6
000075aec0bdf743  vmovaps [rsp+0x70], xmm7
000075aec0bdf749  vmovaps [rsp+0x80], xmm8
000075aec0bdf752  vmovaps [rsp+0x90], xmm9
000075aec0bdf75b  vmovaps [rsp+0xA0], xmm10
000075aec0bdf764  vmovaps [rsp+0xB0], xmm11
000075aec0bdf76d  vmovaps [rsp+0xC0], xmm12
000075aec0bdf776  vmovaps [rsp+0xD0], xmm13
000075aec0bdf77f  vmovaps [rsp+0xE0], xmm15
000075aec0bdf788  sub rsp, 0x30
000075aec0bdf78c  movaps [rsp], xmm14
000075aec0bdf791  movaps [rsp+0x10], xmm8
000075aec0bdf797  movaps [rsp+0x20], xmm4
000075aec0bdf79c  lea rdi, [rsp]
000075aec0bdf7a0  mov esi, 0x00
000075aec0bdf7a5  mov rax, 0x57F4B31E6530
000075aec0bdf7af  call rax
000075aec0bdf7b1  movaps xmm14, [rsp]
000075aec0bdf7b6  add rsp, 0x30
000075aec0bdf7ba  vmovaps xmm0, [rsp]
000075aec0bdf7bf  vmovaps xmm1, [rsp+0x10]
000075aec0bdf7c5  vmovaps xmm2, [rsp+0x20]
000075aec0bdf7cb  vmovaps xmm3, [rsp+0x30]
000075aec0bdf7d1  vmovaps xmm4, [rsp+0x40]
000075aec0bdf7d7  vmovaps xmm5, [rsp+0x50]
000075aec0bdf7dd  vmovaps xmm6, [rsp+0x60]
000075aec0bdf7e3  vmovaps xmm7, [rsp+0x70]
000075aec0bdf7e9  vmovaps xmm8, [rsp+0x80]
000075aec0bdf7f2  vmovaps xmm9, [rsp+0x90]
000075aec0bdf7fb  vmovaps xmm10, [rsp+0xA0]
000075aec0bdf804  vmovaps xmm11, [rsp+0xB0]
000075aec0bdf80d  vmovaps xmm12, [rsp+0xC0]
000075aec0bdf816  vmovaps xmm13, [rsp+0xD0]
000075aec0bdf81f  vmovaps xmm15, [rsp+0xE0]
000075aec0bdf828  add rsp, 0xF0
000075aec0bdf82f  pop r11
000075aec0bdf831  pop r10
000075aec0bdf833  pop r9
000075aec0bdf835  pop r8
000075aec0bdf837  pop rsi
000075aec0bdf838  pop rdi
000075aec0bdf839  pop rdx
000075aec0bdf83a  pop rcx
000075aec0bdf83b  pop rax
000075aec0bdf83c  add rsp, 0x08
000075aec0bdf840  jmp 0x000075AEC0BDC418
000075aec0bdf845  sub rsp, 0x08
000075aec0bdf849  push rax
000075aec0bdf84a  push rcx
000075aec0bdf84b  push rdx
000075aec0bdf84c  push rdi
000075aec0bdf84d  push rsi
000075aec0bdf84e  push r8
000075aec0bdf850  push r9
000075aec0bdf852  push r10
000075aec0bdf854  push r11
000075aec0bdf856  sub rsp, 0xF0
000075aec0bdf85d  vmovaps [rsp], xmm0
000075aec0bdf862  vmovaps [rsp+0x10], xmm1
000075aec0bdf868  vmovaps [rsp+0x20], xmm2
000075aec0bdf86e  vmovaps [rsp+0x30], xmm3
000075aec0bdf874  vmovaps [rsp+0x40], xmm5
000075aec0bdf87a  vmovaps [rsp+0x50], xmm6
000075aec0bdf880  vmovaps [rsp+0x60], xmm7
000075aec0bdf886  vmovaps [rsp+0x70], xmm8
000075aec0bdf88c  vmovaps [rsp+0x80], xmm9
000075aec0bdf895  vmovaps [rsp+0x90], xmm10
000075aec0bdf89e  vmovaps [rsp+0xA0], xmm11
000075aec0bdf8a7  vmovaps [rsp+0xB0], xmm12
000075aec0bdf8b0  vmovaps [rsp+0xC0], xmm13
000075aec0bdf8b9  vmovaps [rsp+0xD0], xmm14
000075aec0bdf8c2  vmovaps [rsp+0xE0], xmm15
000075aec0bdf8cb  sub rsp, 0x30
000075aec0bdf8cf  movaps [rsp], xmm4
000075aec0bdf8d3  movaps [rsp+0x10], xmm13
000075aec0bdf8d9  movaps [rsp+0x20], xmm8
000075aec0bdf8df  lea rdi, [rsp]
000075aec0bdf8e3  mov esi, 0x00
000075aec0bdf8e8  mov rax, 0x57F4B31E6530
000075aec0bdf8f2  call rax
000075aec0bdf8f4  movaps xmm4, [rsp]
000075aec0bdf8f8  add rsp, 0x30
000075aec0bdf8fc  vmovaps xmm0, [rsp]
000075aec0bdf901  vmovaps xmm1, [rsp+0x10]
000075aec0bdf907  vmovaps xmm2, [rsp+0x20]
000075aec0bdf90d  vmovaps xmm3, [rsp+0x30]
000075aec0bdf913  vmovaps xmm5, [rsp+0x40]
000075aec0bdf919  vmovaps xmm6, [rsp+0x50]
000075aec0bdf91f  vmovaps xmm7, [rsp+0x60]
000075aec0bdf925  vmovaps xmm8, [rsp+0x70]
000075aec0bdf92b  vmovaps xmm9, [rsp+0x80]
000075aec0bdf934  vmovaps xmm10, [rsp+0x90]
000075aec0bdf93d  vmovaps xmm11, [rsp+0xA0]
000075aec0bdf946  vmovaps xmm12, [rsp+0xB0]
000075aec0bdf94f  vmovaps xmm13, [rsp+0xC0]
000075aec0bdf958  vmovaps xmm14, [rsp+0xD0]
000075aec0bdf961  vmovaps xmm15, [rsp+0xE0]
000075aec0bdf96a  add rsp, 0xF0
000075aec0bdf971  pop r11
000075aec0bdf973  pop r10
000075aec0bdf975  pop r9
000075aec0bdf977  pop r8
000075aec0bdf979  pop rsi
000075aec0bdf97a  pop rdi
000075aec0bdf97b  pop rdx
000075aec0bdf97c  pop rcx
000075aec0bdf97d  pop rax
000075aec0bdf97e  add rsp, 0x08
000075aec0bdf982  jmp 0x000075AEC0BDC43D
000075aec0bdf987  sub rsp, 0x08
000075aec0bdf98b  push rax
000075aec0bdf98c  push rcx
000075aec0bdf98d  push rdx
000075aec0bdf98e  push rdi
000075aec0bdf98f  push rsi
000075aec0bdf990  push r8
000075aec0bdf992  push r9
000075aec0bdf994  push r10
000075aec0bdf996  push r11
000075aec0bdf998  sub rsp, 0xF0
000075aec0bdf99f  vmovaps [rsp], xmm0
000075aec0bdf9a4  vmovaps [rsp+0x10], xmm1
000075aec0bdf9aa  vmovaps [rsp+0x20], xmm2
000075aec0bdf9b0  vmovaps [rsp+0x30], xmm3
000075aec0bdf9b6  vmovaps [rsp+0x40], xmm4
000075aec0bdf9bc  vmovaps [rsp+0x50], xmm5
000075aec0bdf9c2  vmovaps [rsp+0x60], xmm6
000075aec0bdf9c8  vmovaps [rsp+0x70], xmm7
000075aec0bdf9ce  vmovaps [rsp+0x80], xmm8
000075aec0bdf9d7  vmovaps [rsp+0x90], xmm9
000075aec0bdf9e0  vmovaps [rsp+0xA0], xmm10
000075aec0bdf9e9  vmovaps [rsp+0xB0], xmm11
000075aec0bdf9f2  vmovaps [rsp+0xC0], xmm12
000075aec0bdf9fb  vmovaps [rsp+0xD0], xmm14
000075aec0bdfa04  vmovaps [rsp+0xE0], xmm15
000075aec0bdfa0d  sub rsp, 0x30
000075aec0bdfa11  movaps [rsp], xmm13
000075aec0bdfa16  movaps [rsp+0x10], xmm15
000075aec0bdfa1c  movaps [rsp+0x20], xmm9
000075aec0bdfa22  lea rdi, [rsp]
000075aec0bdfa26  mov esi, 0x00
000075aec0bdfa2b  mov rax, 0x57F4B31E6530
000075aec0bdfa35  call rax
000075aec0bdfa37  movaps xmm13, [rsp]
000075aec0bdfa3c  add rsp, 0x30
000075aec0bdfa40  vmovaps xmm0, [rsp]
000075aec0bdfa45  vmovaps xmm1, [rsp+0x10]
000075aec0bdfa4b  vmovaps xmm2, [rsp+0x20]
000075aec0bdfa51  vmovaps xmm3, [rsp+0x30]
000075aec0bdfa57  vmovaps xmm4, [rsp+0x40]
000075aec0bdfa5d  vmovaps xmm5, [rsp+0x50]
000075aec0bdfa63  vmovaps xmm6, [rsp+0x60]
000075aec0bdfa69  vmovaps xmm7, [rsp+0x70]
000075aec0bdfa6f  vmovaps xmm8, [rsp+0x80]
000075aec0bdfa78  vmovaps xmm9, [rsp+0x90]
000075aec0bdfa81  vmovaps xmm10, [rsp+0xA0]
000075aec0bdfa8a  vmovaps xmm11, [rsp+0xB0]
000075aec0bdfa93  vmovaps xmm12, [rsp+0xC0]
000075aec0bdfa9c  vmovaps xmm14, [rsp+0xD0]
000075aec0bdfaa5  vmovaps xmm15, [rsp+0xE0]
000075aec0bdfaae  add rsp, 0xF0
000075aec0bdfab5  pop r11
000075aec0bdfab7  pop r10
000075aec0bdfab9  pop r9
000075aec0bdfabb  pop r8
000075aec0bdfabd  pop rsi
000075aec0bdfabe  pop rdi
000075aec0bdfabf  pop rdx
000075aec0bdfac0  pop rcx
000075aec0bdfac1  pop rax
000075aec0bdfac2  add rsp, 0x08
000075aec0bdfac6  jmp 0x000075AEC0BDC458
000075aec0bdfacb  sub rsp, 0x08
000075aec0bdfacf  push rax
000075aec0bdfad0  push rcx
000075aec0bdfad1  push rdx
000075aec0bdfad2  push rdi
000075aec0bdfad3  push rsi
000075aec0bdfad4  push r8
000075aec0bdfad6  push r9
000075aec0bdfad8  push r10
000075aec0bdfada  push r11
000075aec0bdfadc  sub rsp, 0xF0
000075aec0bdfae3  vmovaps [rsp], xmm0
000075aec0bdfae8  vmovaps [rsp+0x10], xmm1
000075aec0bdfaee  vmovaps [rsp+0x20], xmm2
000075aec0bdfaf4  vmovaps [rsp+0x30], xmm3
000075aec0bdfafa  vmovaps [rsp+0x40], xmm4
000075aec0bdfb00  vmovaps [rsp+0x50], xmm5
000075aec0bdfb06  vmovaps [rsp+0x60], xmm6
000075aec0bdfb0c  vmovaps [rsp+0x70], xmm7
000075aec0bdfb12  vmovaps [rsp+0x80], xmm8
000075aec0bdfb1b  vmovaps [rsp+0x90], xmm9
000075aec0bdfb24  vmovaps [rsp+0xA0], xmm10
000075aec0bdfb2d  vmovaps [rsp+0xB0], xmm11
000075aec0bdfb36  vmovaps [rsp+0xC0], xmm12
000075aec0bdfb3f  vmovaps [rsp+0xD0], xmm13
000075aec0bdfb48  vmovaps [rsp+0xE0], xmm14
000075aec0bdfb51  sub rsp, 0x30
000075aec0bdfb55  movaps [rsp], xmm15
000075aec0bdfb5a  movaps [rsp+0x10], xmm1
000075aec0bdfb5f  movaps [rsp+0x20], xmm5
000075aec0bdfb64  lea rdi, [rsp]
000075aec0bdfb68  mov esi, 0x00
000075aec0bdfb6d  mov rax, 0x57F4B31E6530
000075aec0bdfb77  call rax
000075aec0bdfb79  movaps xmm15, [rsp]
000075aec0bdfb7e  add rsp, 0x30
000075aec0bdfb82  vmovaps xmm0, [rsp]
000075aec0bdfb87  vmovaps xmm1, [rsp+0x10]
000075aec0bdfb8d  vmovaps xmm2, [rsp+0x20]
000075aec0bdfb93  vmovaps xmm3, [rsp+0x30]
000075aec0bdfb99  vmovaps xmm4, [rsp+0x40]
000075aec0bdfb9f  vmovaps xmm5, [rsp+0x50]
000075aec0bdfba5  vmovaps xmm6, [rsp+0x60]
000075aec0bdfbab  vmovaps xmm7, [rsp+0x70]
000075aec0bdfbb1  vmovaps xmm8, [rsp+0x80]
000075aec0bdfbba  vmovaps xmm9, [rsp+0x90]
000075aec0bdfbc3  vmovaps xmm10, [rsp+0xA0]
000075aec0bdfbcc  vmovaps xmm11, [rsp+0xB0]
000075aec0bdfbd5  vmovaps xmm12, [rsp+0xC0]
000075aec0bdfbde  vmovaps xmm13, [rsp+0xD0]
000075aec0bdfbe7  vmovaps xmm14, [rsp+0xE0]
000075aec0bdfbf0  add rsp, 0xF0
000075aec0bdfbf7  pop r11
000075aec0bdfbf9  pop r10
000075aec0bdfbfb  pop r9
000075aec0bdfbfd  pop r8
000075aec0bdfbff  pop rsi
000075aec0bdfc00  pop rdi
000075aec0bdfc01  pop rdx
000075aec0bdfc02  pop rcx
000075aec0bdfc03  pop rax
000075aec0bdfc04  add rsp, 0x08
000075aec0bdfc08  jmp 0x000075AEC0BDC473
000075aec0bdfc0d  call 0x000075AEC0AB52F0
000075aec0bdfc12  jmp 0x000075AEC0BDC4CE
000075aec0bdfc17  sub rsp, 0x08
000075aec0bdfc1b  push rax
000075aec0bdfc1c  push rcx
000075aec0bdfc1d  push rdx
000075aec0bdfc1e  push rdi
000075aec0bdfc1f  push rsi
000075aec0bdfc20  push r8
000075aec0bdfc22  push r9
000075aec0bdfc24  push r10
000075aec0bdfc26  push r11
000075aec0bdfc28  sub rsp, 0xF0
000075aec0bdfc2f  vmovaps [rsp], xmm0
000075aec0bdfc34  vmovaps [rsp+0x10], xmm1
000075aec0bdfc3a  vmovaps [rsp+0x20], xmm2
000075aec0bdfc40  vmovaps [rsp+0x30], xmm3
000075aec0bdfc46  vmovaps [rsp+0x40], xmm4
000075aec0bdfc4c  vmovaps [rsp+0x50], xmm5
000075aec0bdfc52  vmovaps [rsp+0x60], xmm6
000075aec0bdfc58  vmovaps [rsp+0x70], xmm7
000075aec0bdfc5e  vmovaps [rsp+0x80], xmm8
000075aec0bdfc67  vmovaps [rsp+0x90], xmm10
000075aec0bdfc70  vmovaps [rsp+0xA0], xmm11
000075aec0bdfc79  vmovaps [rsp+0xB0], xmm12
000075aec0bdfc82  vmovaps [rsp+0xC0], xmm13
000075aec0bdfc8b  vmovaps [rsp+0xD0], xmm14
000075aec0bdfc94  vmovaps [rsp+0xE0], xmm15
000075aec0bdfc9d  sub rsp, 0x30
000075aec0bdfca1  movaps [rsp], xmm9
000075aec0bdfca6  movaps [rsp+0x10], xmm8
000075aec0bdfcac  movaps [rsp+0x20], xmm11
000075aec0bdfcb2  lea rdi, [rsp]
000075aec0bdfcb6  mov esi, 0x00
000075aec0bdfcbb  mov rax, 0x57F4B31E6530
000075aec0bdfcc5  call rax
000075aec0bdfcc7  movaps xmm9, [rsp]
000075aec0bdfccc  add rsp, 0x30
000075aec0bdfcd0  vmovaps xmm0, [rsp]
000075aec0bdfcd5  vmovaps xmm1, [rsp+0x10]
000075aec0bdfcdb  vmovaps xmm2, [rsp+0x20]
000075aec0bdfce1  vmovaps xmm3, [rsp+0x30]
000075aec0bdfce7  vmovaps xmm4, [rsp+0x40]
000075aec0bdfced  vmovaps xmm5, [rsp+0x50]
000075aec0bdfcf3  vmovaps xmm6, [rsp+0x60]
000075aec0bdfcf9  vmovaps xmm7, [rsp+0x70]
000075aec0bdfcff  vmovaps xmm8, [rsp+0x80]
000075aec0bdfd08  vmovaps xmm10, [rsp+0x90]
000075aec0bdfd11  vmovaps xmm11, [rsp+0xA0]
000075aec0bdfd1a  vmovaps xmm12, [rsp+0xB0]
000075aec0bdfd23  vmovaps xmm13, [rsp+0xC0]
000075aec0bdfd2c  vmovaps xmm14, [rsp+0xD0]
000075aec0bdfd35  vmovaps xmm15, [rsp+0xE0]
000075aec0bdfd3e  add rsp, 0xF0
000075aec0bdfd45  pop r11
000075aec0bdfd47  pop r10
000075aec0bdfd49  pop r9
000075aec0bdfd4b  pop r8
000075aec0bdfd4d  pop rsi
000075aec0bdfd4e  pop rdi
000075aec0bdfd4f  pop rdx
000075aec0bdfd50  pop rcx
000075aec0bdfd51  pop rax
000075aec0bdfd52  add rsp, 0x08
000075aec0bdfd56  jmp 0x000075AEC0BDC505
000075aec0bdfd5b  sub rsp, 0x08
000075aec0bdfd5f  push rax
000075aec0bdfd60  push rcx
000075aec0bdfd61  push rdx
000075aec0bdfd62  push rdi
000075aec0bdfd63  push rsi
000075aec0bdfd64  push r8
000075aec0bdfd66  push r9
000075aec0bdfd68  push r10
000075aec0bdfd6a  push r11
000075aec0bdfd6c  sub rsp, 0xF0
000075aec0bdfd73  vmovaps [rsp], xmm0
000075aec0bdfd78  vmovaps [rsp+0x10], xmm1
000075aec0bdfd7e  vmovaps [rsp+0x20], xmm2
000075aec0bdfd84  vmovaps [rsp+0x30], xmm3
000075aec0bdfd8a  vmovaps [rsp+0x40], xmm4
000075aec0bdfd90  vmovaps [rsp+0x50], xmm5
000075aec0bdfd96  vmovaps [rsp+0x60], xmm6
000075aec0bdfd9c  vmovaps [rsp+0x70], xmm7
000075aec0bdfda2  vmovaps [rsp+0x80], xmm8
000075aec0bdfdab  vmovaps [rsp+0x90], xmm9
000075aec0bdfdb4  vmovaps [rsp+0xA0], xmm10
000075aec0bdfdbd  vmovaps [rsp+0xB0], xmm12
000075aec0bdfdc6  vmovaps [rsp+0xC0], xmm13
000075aec0bdfdcf  vmovaps [rsp+0xD0], xmm14
000075aec0bdfdd8  vmovaps [rsp+0xE0], xmm15
000075aec0bdfde1  sub rsp, 0x30
000075aec0bdfde5  movaps [rsp], xmm11
000075aec0bdfdea  movaps [rsp+0x10], xmm10
000075aec0bdfdf0  movaps [rsp+0x20], xmm6
000075aec0bdfdf5  lea rdi, [rsp]
000075aec0bdfdf9  mov esi, 0x00
000075aec0bdfdfe  mov rax, 0x57F4B31E6530
000075aec0bdfe08  call rax
000075aec0bdfe0a  movaps xmm11, [rsp]
000075aec0bdfe0f  add rsp, 0x30
000075aec0bdfe13  vmovaps xmm0, [rsp]
000075aec0bdfe18  vmovaps xmm1, [rsp+0x10]
000075aec0bdfe1e  vmovaps xmm2, [rsp+0x20]
000075aec0bdfe24  vmovaps xmm3, [rsp+0x30]
000075aec0bdfe2a  vmovaps xmm4, [rsp+0x40]
000075aec0bdfe30  vmovaps xmm5, [rsp+0x50]
000075aec0bdfe36  vmovaps xmm6, [rsp+0x60]
000075aec0bdfe3c  vmovaps xmm7, [rsp+0x70]
000075aec0bdfe42  vmovaps xmm8, [rsp+0x80]
000075aec0bdfe4b  vmovaps xmm9, [rsp+0x90]
000075aec0bdfe54  vmovaps xmm10, [rsp+0xA0]
000075aec0bdfe5d  vmovaps xmm12, [rsp+0xB0]
000075aec0bdfe66  vmovaps xmm13, [rsp+0xC0]
000075aec0bdfe6f  vmovaps xmm14, [rsp+0xD0]
000075aec0bdfe78  vmovaps xmm15, [rsp+0xE0]
000075aec0bdfe81  add rsp, 0xF0
000075aec0bdfe88  pop r11
000075aec0bdfe8a  pop r10
000075aec0bdfe8c  pop r9
000075aec0bdfe8e  pop r8
000075aec0bdfe90  pop rsi
000075aec0bdfe91  pop rdi
000075aec0bdfe92  pop rdx
000075aec0bdfe93  pop rcx
000075aec0bdfe94  pop rax
000075aec0bdfe95  add rsp, 0x08
000075aec0bdfe99  jmp 0x000075AEC0BDC520
000075aec0bdfe9e  sub rsp, 0x08
000075aec0bdfea2  push rax
000075aec0bdfea3  push rcx
000075aec0bdfea4  push rdx
000075aec0bdfea5  push rdi
000075aec0bdfea6  push rsi
000075aec0bdfea7  push r8
000075aec0bdfea9  push r9
000075aec0bdfeab  push r10
000075aec0bdfead  push r11
000075aec0bdfeaf  sub rsp, 0xF0
000075aec0bdfeb6  vmovaps [rsp], xmm0
000075aec0bdfebb  vmovaps [rsp+0x10], xmm1
000075aec0bdfec1  vmovaps [rsp+0x20], xmm2
000075aec0bdfec7  vmovaps [rsp+0x30], xmm3
000075aec0bdfecd  vmovaps [rsp+0x40], xmm4
000075aec0bdfed3  vmovaps [rsp+0x50], xmm5
000075aec0bdfed9  vmovaps [rsp+0x60], xmm6
000075aec0bdfedf  vmovaps [rsp+0x70], xmm7
000075aec0bdfee5  vmovaps [rsp+0x80], xmm8
000075aec0bdfeee  vmovaps [rsp+0x90], xmm9
000075aec0bdfef7  vmovaps [rsp+0xA0], xmm11
000075aec0bdff00  vmovaps [rsp+0xB0], xmm12
000075aec0bdff09  vmovaps [rsp+0xC0], xmm13
000075aec0bdff12  vmovaps [rsp+0xD0], xmm14
000075aec0bdff1b  vmovaps [rsp+0xE0], xmm15
000075aec0bdff24  sub rsp, 0x30
000075aec0bdff28  movaps [rsp], xmm10
000075aec0bdff2d  movaps [rsp+0x10], xmm14
000075aec0bdff33  movaps [rsp+0x20], xmm4
000075aec0bdff38  lea rdi, [rsp]
000075aec0bdff3c  mov esi, 0x00
000075aec0bdff41  mov rax, 0x57F4B31E6530
000075aec0bdff4b  call rax
000075aec0bdff4d  movaps xmm10, [rsp]
000075aec0bdff52  add rsp, 0x30
000075aec0bdff56  vmovaps xmm0, [rsp]
000075aec0bdff5b  vmovaps xmm1, [rsp+0x10]
000075aec0bdff61  vmovaps xmm2, [rsp+0x20]
000075aec0bdff67  vmovaps xmm3, [rsp+0x30]
000075aec0bdff6d  vmovaps xmm4, [rsp+0x40]
000075aec0bdff73  vmovaps xmm5, [rsp+0x50]
000075aec0bdff79  vmovaps xmm6, [rsp+0x60]
000075aec0bdff7f  vmovaps xmm7, [rsp+0x70]
000075aec0bdff85  vmovaps xmm8, [rsp+0x80]
000075aec0bdff8e  vmovaps xmm9, [rsp+0x90]
000075aec0bdff97  vmovaps xmm11, [rsp+0xA0]
000075aec0bdffa0  vmovaps xmm12, [rsp+0xB0]
000075aec0bdffa9  vmovaps xmm13, [rsp+0xC0]
000075aec0bdffb2  vmovaps xmm14, [rsp+0xD0]
000075aec0bdffbb  vmovaps xmm15, [rsp+0xE0]
000075aec0bdffc4  add rsp, 0xF0
000075aec0bdffcb  pop r11
000075aec0bdffcd  pop r10
000075aec0bdffcf  pop r9
000075aec0bdffd1  pop r8
000075aec0bdffd3  pop rsi
000075aec0bdffd4  pop rdi
000075aec0bdffd5  pop rdx
000075aec0bdffd6  pop rcx
000075aec0bdffd7  pop rax
000075aec0bdffd8  add rsp, 0x08
000075aec0bdffdc  jmp 0x000075AEC0BDC53B
000075aec0bdffe1  sub rsp, 0x08
000075aec0bdffe5  push rax
000075aec0bdffe6  push rcx
000075aec0bdffe7  push rdx
000075aec0bdffe8  push rdi
000075aec0bdffe9  push rsi
000075aec0bdffea  push r8
000075aec0bdffec  push r9
000075aec0bdffee  push r10
000075aec0bdfff0  push r11
000075aec0bdfff2  sub rsp, 0xF0
000075aec0bdfff9  vmovaps [rsp], xmm0
000075aec0bdfffe  vmovaps [rsp+0x10], xmm1
000075aec0be0004  vmovaps [rsp+0x20], xmm2
000075aec0be000a  vmovaps [rsp+0x30], xmm3
000075aec0be0010  vmovaps [rsp+0x40], xmm4
000075aec0be0016  vmovaps [rsp+0x50], xmm5
000075aec0be001c  vmovaps [rsp+0x60], xmm6
000075aec0be0022  vmovaps [rsp+0x70], xmm7
000075aec0be0028  vmovaps [rsp+0x80], xmm9
000075aec0be0031  vmovaps [rsp+0x90], xmm10
000075aec0be003a  vmovaps [rsp+0xA0], xmm11
000075aec0be0043  vmovaps [rsp+0xB0], xmm12
000075aec0be004c  vmovaps [rsp+0xC0], xmm13
000075aec0be0055  vmovaps [rsp+0xD0], xmm14
000075aec0be005e  vmovaps [rsp+0xE0], xmm15
000075aec0be0067  sub rsp, 0x30
000075aec0be006b  movaps [rsp], xmm8
000075aec0be0070  movaps [rsp+0x10], xmm1
000075aec0be0075  movaps [rsp+0x20], xmm14
000075aec0be007b  lea rdi, [rsp]
000075aec0be007f  mov esi, 0x00
000075aec0be0084  mov rax, 0x57F4B31E6530
000075aec0be008e  call rax
000075aec0be0090  movaps xmm8, [rsp]
000075aec0be0095  add rsp, 0x30
000075aec0be0099  vmovaps xmm0, [rsp]
000075aec0be009e  vmovaps xmm1, [rsp+0x10]
000075aec0be00a4  vmovaps xmm2, [rsp+0x20]
000075aec0be00aa  vmovaps xmm3, [rsp+0x30]
000075aec0be00b0  vmovaps xmm4, [rsp+0x40]
000075aec0be00b6  vmovaps xmm5, [rsp+0x50]
000075aec0be00bc  vmovaps xmm6, [rsp+0x60]
000075aec0be00c2  vmovaps xmm7, [rsp+0x70]
000075aec0be00c8  vmovaps xmm9, [rsp+0x80]
000075aec0be00d1  vmovaps xmm10, [rsp+0x90]
000075aec0be00da  vmovaps xmm11, [rsp+0xA0]
000075aec0be00e3  vmovaps xmm12, [rsp+0xB0]
000075aec0be00ec  vmovaps xmm13, [rsp+0xC0]
000075aec0be00f5  vmovaps xmm14, [rsp+0xD0]
000075aec0be00fe  vmovaps xmm15, [rsp+0xE0]
000075aec0be0107  add rsp, 0xF0
000075aec0be010e  pop r11
000075aec0be0110  pop r10
000075aec0be0112  pop r9
000075aec0be0114  pop r8
000075aec0be0116  pop rsi
000075aec0be0117  pop rdi
000075aec0be0118  pop rdx
000075aec0be0119  pop rcx
000075aec0be011a  pop rax
000075aec0be011b  add rsp, 0x08
000075aec0be011f  jmp 0x000075AEC0BDC561
000075aec0be0124  sub rsp, 0x08
000075aec0be0128  push rax
000075aec0be0129  push rcx
000075aec0be012a  push rdx
000075aec0be012b  push rdi
000075aec0be012c  push rsi
000075aec0be012d  push r8
000075aec0be012f  push r9
000075aec0be0131  push r10
000075aec0be0133  push r11
000075aec0be0135  sub rsp, 0xF0
000075aec0be013c  vmovaps [rsp], xmm0
000075aec0be0141  vmovaps [rsp+0x10], xmm1
000075aec0be0147  vmovaps [rsp+0x20], xmm2
000075aec0be014d  vmovaps [rsp+0x30], xmm3
000075aec0be0153  vmovaps [rsp+0x40], xmm4
000075aec0be0159  vmovaps [rsp+0x50], xmm5
000075aec0be015f  vmovaps [rsp+0x60], xmm7
000075aec0be0165  vmovaps [rsp+0x70], xmm8
000075aec0be016b  vmovaps [rsp+0x80], xmm9
000075aec0be0174  vmovaps [rsp+0x90], xmm10
000075aec0be017d  vmovaps [rsp+0xA0], xmm11
000075aec0be0186  vmovaps [rsp+0xB0], xmm12
000075aec0be018f  vmovaps [rsp+0xC0], xmm13
000075aec0be0198  vmovaps [rsp+0xD0], xmm14
000075aec0be01a1  vmovaps [rsp+0xE0], xmm15
000075aec0be01aa  sub rsp, 0x30
000075aec0be01ae  movaps [rsp], xmm6
000075aec0be01b2  movaps [rsp+0x10], xmm1
000075aec0be01b7  movaps [rsp+0x20], xmm14
000075aec0be01bd  lea rdi, [rsp]
000075aec0be01c1  mov esi, 0x00
000075aec0be01c6  mov rax, 0x57F4B31E6530
000075aec0be01d0  call rax
000075aec0be01d2  movaps xmm6, [rsp]
000075aec0be01d6  add rsp, 0x30
000075aec0be01da  vmovaps xmm0, [rsp]
000075aec0be01df  vmovaps xmm1, [rsp+0x10]
000075aec0be01e5  vmovaps xmm2, [rsp+0x20]
000075aec0be01eb  vmovaps xmm3, [rsp+0x30]
000075aec0be01f1  vmovaps xmm4, [rsp+0x40]
000075aec0be01f7  vmovaps xmm5, [rsp+0x50]
000075aec0be01fd  vmovaps xmm7, [rsp+0x60]
000075aec0be0203  vmovaps xmm8, [rsp+0x70]
000075aec0be0209  vmovaps xmm9, [rsp+0x80]
000075aec0be0212  vmovaps xmm10, [rsp+0x90]
000075aec0be021b  vmovaps xmm11, [rsp+0xA0]
000075aec0be0224  vmovaps xmm12, [rsp+0xB0]
000075aec0be022d  vmovaps xmm13, [rsp+0xC0]
000075aec0be0236  vmovaps xmm14, [rsp+0xD0]
000075aec0be023f  vmovaps xmm15, [rsp+0xE0]
000075aec0be0248  add rsp, 0xF0
000075aec0be024f  pop r11
000075aec0be0251  pop r10
000075aec0be0253  pop r9
000075aec0be0255  pop r8
000075aec0be0257  pop rsi
000075aec0be0258  pop rdi
000075aec0be0259  pop rdx
000075aec0be025a  pop rcx
000075aec0be025b  pop rax
000075aec0be025c  add rsp, 0x08
000075aec0be0260  jmp 0x000075AEC0BDC58D
000075aec0be0265  sub rsp, 0x08
000075aec0be0269  push rax
000075aec0be026a  push rcx
000075aec0be026b  push rdx
000075aec0be026c  push rdi
000075aec0be026d  push rsi
000075aec0be026e  push r8
000075aec0be0270  push r9
000075aec0be0272  push r10
000075aec0be0274  push r11
000075aec0be0276  sub rsp, 0xF0
000075aec0be027d  vmovaps [rsp], xmm0
000075aec0be0282  vmovaps [rsp+0x10], xmm1
000075aec0be0288  vmovaps [rsp+0x20], xmm2
000075aec0be028e  vmovaps [rsp+0x30], xmm3
000075aec0be0294  vmovaps [rsp+0x40], xmm4
000075aec0be029a  vmovaps [rsp+0x50], xmm5
000075aec0be02a0  vmovaps [rsp+0x60], xmm6
000075aec0be02a6  vmovaps [rsp+0x70], xmm7
000075aec0be02ac  vmovaps [rsp+0x80], xmm8
000075aec0be02b5  vmovaps [rsp+0x90], xmm9
000075aec0be02be  vmovaps [rsp+0xA0], xmm10
000075aec0be02c7  vmovaps [rsp+0xB0], xmm11
000075aec0be02d0  vmovaps [rsp+0xC0], xmm12
000075aec0be02d9  vmovaps [rsp+0xD0], xmm13
000075aec0be02e2  vmovaps [rsp+0xE0], xmm15
000075aec0be02eb  sub rsp, 0x30
000075aec0be02ef  movaps [rsp], xmm14
000075aec0be02f4  movaps [rsp+0x10], xmm12
000075aec0be02fa  movaps [rsp+0x20], xmm1
000075aec0be02ff  lea rdi, [rsp]
000075aec0be0303  mov esi, 0x00
000075aec0be0308  mov rax, 0x57F4B31E6530
000075aec0be0312  call rax
000075aec0be0314  movaps xmm14, [rsp]
000075aec0be0319  add rsp, 0x30
000075aec0be031d  vmovaps xmm0, [rsp]
000075aec0be0322  vmovaps xmm1, [rsp+0x10]
000075aec0be0328  vmovaps xmm2, [rsp+0x20]
000075aec0be032e  vmovaps xmm3, [rsp+0x30]
000075aec0be0334  vmovaps xmm4, [rsp+0x40]
000075aec0be033a  vmovaps xmm5, [rsp+0x50]
000075aec0be0340  vmovaps xmm6, [rsp+0x60]
000075aec0be0346  vmovaps xmm7, [rsp+0x70]
000075aec0be034c  vmovaps xmm8, [rsp+0x80]
000075aec0be0355  vmovaps xmm9, [rsp+0x90]
000075aec0be035e  vmovaps xmm10, [rsp+0xA0]
000075aec0be0367  vmovaps xmm11, [rsp+0xB0]
000075aec0be0370  vmovaps xmm12, [rsp+0xC0]
000075aec0be0379  vmovaps xmm13, [rsp+0xD0]
000075aec0be0382  vmovaps xmm15, [rsp+0xE0]
000075aec0be038b  add rsp, 0xF0
000075aec0be0392  pop r11
000075aec0be0394  pop r10
000075aec0be0396  pop r9
000075aec0be0398  pop r8
000075aec0be039a  pop rsi
000075aec0be039b  pop rdi
000075aec0be039c  pop rdx
000075aec0be039d  pop rcx
000075aec0be039e  pop rax
000075aec0be039f  add rsp, 0x08
000075aec0be03a3  jmp 0x000075AEC0BDC5B3
000075aec0be03a8  sub rsp, 0x08
000075aec0be03ac  push rax
000075aec0be03ad  push rcx
000075aec0be03ae  push rdx
000075aec0be03af  push rdi
000075aec0be03b0  push rsi
000075aec0be03b1  push r8
000075aec0be03b3  push r9
000075aec0be03b5  push r10
000075aec0be03b7  push r11
000075aec0be03b9  sub rsp, 0xF0
000075aec0be03c0  vmovaps [rsp], xmm0
000075aec0be03c5  vmovaps [rsp+0x10], xmm2
000075aec0be03cb  vmovaps [rsp+0x20], xmm3
000075aec0be03d1  vmovaps [rsp+0x30], xmm4
000075aec0be03d7  vmovaps [rsp+0x40], xmm5
000075aec0be03dd  vmovaps [rsp+0x50], xmm6
000075aec0be03e3  vmovaps [rsp+0x60], xmm7
000075aec0be03e9  vmovaps [rsp+0x70], xmm8
000075aec0be03ef  vmovaps [rsp+0x80], xmm9
000075aec0be03f8  vmovaps [rsp+0x90], xmm10
000075aec0be0401  vmovaps [rsp+0xA0], xmm11
000075aec0be040a  vmovaps [rsp+0xB0], xmm12
000075aec0be0413  vmovaps [rsp+0xC0], xmm13
000075aec0be041c  vmovaps [rsp+0xD0], xmm14
000075aec0be0425  vmovaps [rsp+0xE0], xmm15
000075aec0be042e  sub rsp, 0x30
000075aec0be0432  movaps [rsp], xmm1
000075aec0be0436  movaps [rsp+0x10], xmm13
000075aec0be043c  movaps [rsp+0x20], xmm9
000075aec0be0442  lea rdi, [rsp]
000075aec0be0446  mov esi, 0x00
000075aec0be044b  mov rax, 0x57F4B31E6530
000075aec0be0455  call rax
000075aec0be0457  movaps xmm1, [rsp]
000075aec0be045b  add rsp, 0x30
000075aec0be045f  vmovaps xmm0, [rsp]
000075aec0be0464  vmovaps xmm2, [rsp+0x10]
000075aec0be046a  vmovaps xmm3, [rsp+0x20]
000075aec0be0470  vmovaps xmm4, [rsp+0x30]
000075aec0be0476  vmovaps xmm5, [rsp+0x40]
000075aec0be047c  vmovaps xmm6, [rsp+0x50]
000075aec0be0482  vmovaps xmm7, [rsp+0x60]
000075aec0be0488  vmovaps xmm8, [rsp+0x70]
000075aec0be048e  vmovaps xmm9, [rsp+0x80]
000075aec0be0497  vmovaps xmm10, [rsp+0x90]
000075aec0be04a0  vmovaps xmm11, [rsp+0xA0]
000075aec0be04a9  vmovaps xmm12, [rsp+0xB0]
000075aec0be04b2  vmovaps xmm13, [rsp+0xC0]
000075aec0be04bb  vmovaps xmm14, [rsp+0xD0]
000075aec0be04c4  vmovaps xmm15, [rsp+0xE0]
000075aec0be04cd  add rsp, 0xF0
000075aec0be04d4  pop r11
000075aec0be04d6  pop r10
000075aec0be04d8  pop r9
000075aec0be04da  pop r8
000075aec0be04dc  pop rsi
000075aec0be04dd  pop rdi
000075aec0be04de  pop rdx
000075aec0be04df  pop rcx
000075aec0be04e0  pop rax
000075aec0be04e1  add rsp, 0x08
000075aec0be04e5  jmp 0x000075AEC0BDC5CD
000075aec0be04ea  sub rsp, 0x08
000075aec0be04ee  push rax
000075aec0be04ef  push rcx
000075aec0be04f0  push rdx
000075aec0be04f1  push rdi
000075aec0be04f2  push rsi
000075aec0be04f3  push r8
000075aec0be04f5  push r9
000075aec0be04f7  push r10
000075aec0be04f9  push r11
000075aec0be04fb  sub rsp, 0xF0
000075aec0be0502  vmovaps [rsp], xmm0
000075aec0be0507  vmovaps [rsp+0x10], xmm1
000075aec0be050d  vmovaps [rsp+0x20], xmm2
000075aec0be0513  vmovaps [rsp+0x30], xmm3
000075aec0be0519  vmovaps [rsp+0x40], xmm4
000075aec0be051f  vmovaps [rsp+0x50], xmm5
000075aec0be0525  vmovaps [rsp+0x60], xmm6
000075aec0be052b  vmovaps [rsp+0x70], xmm7
000075aec0be0531  vmovaps [rsp+0x80], xmm8
000075aec0be053a  vmovaps [rsp+0x90], xmm9
000075aec0be0543  vmovaps [rsp+0xA0], xmm10
000075aec0be054c  vmovaps [rsp+0xB0], xmm11
000075aec0be0555  vmovaps [rsp+0xC0], xmm13
000075aec0be055e  vmovaps [rsp+0xD0], xmm14
000075aec0be0567  vmovaps [rsp+0xE0], xmm15
000075aec0be0570  sub rsp, 0x30
000075aec0be0574  movaps [rsp], xmm12
000075aec0be0579  movaps [rsp+0x10], xmm7
000075aec0be057e  movaps [rsp+0x20], xmm13
000075aec0be0584  lea rdi, [rsp]
000075aec0be0588  mov esi, 0x00
000075aec0be058d  mov rax, 0x57F4B31E6530
000075aec0be0597  call rax
000075aec0be0599  movaps xmm12, [rsp]
000075aec0be059e  add rsp, 0x30
000075aec0be05a2  vmovaps xmm0, [rsp]
000075aec0be05a7  vmovaps xmm1, [rsp+0x10]
000075aec0be05ad  vmovaps xmm2, [rsp+0x20]
000075aec0be05b3  vmovaps xmm3, [rsp+0x30]
000075aec0be05b9  vmovaps xmm4, [rsp+0x40]
000075aec0be05bf  vmovaps xmm5, [rsp+0x50]
000075aec0be05c5  vmovaps xmm6, [rsp+0x60]
000075aec0be05cb  vmovaps xmm7, [rsp+0x70]
000075aec0be05d1  vmovaps xmm8, [rsp+0x80]
000075aec0be05da  vmovaps xmm9, [rsp+0x90]
000075aec0be05e3  vmovaps xmm10, [rsp+0xA0]
000075aec0be05ec  vmovaps xmm11, [rsp+0xB0]
000075aec0be05f5  vmovaps xmm13, [rsp+0xC0]
000075aec0be05fe  vmovaps xmm14, [rsp+0xD0]
000075aec0be0607  vmovaps xmm15, [rsp+0xE0]
000075aec0be0610  add rsp, 0xF0
000075aec0be0617  pop r11
000075aec0be0619  pop r10
000075aec0be061b  pop r9
000075aec0be061d  pop r8
000075aec0be061f  pop rsi
000075aec0be0620  pop rdi
000075aec0be0621  pop rdx
000075aec0be0622  pop rcx
000075aec0be0623  pop rax
000075aec0be0624  add rsp, 0x08
000075aec0be0628  jmp 0x000075AEC0BDC5F4
000075aec0be062d  sub rsp, 0x08
000075aec0be0631  push rax
000075aec0be0632  push rcx
000075aec0be0633  push rdx
000075aec0be0634  push rdi
000075aec0be0635  push rsi
000075aec0be0636  push r8
000075aec0be0638  push r9
000075aec0be063a  push r10
000075aec0be063c  push r11
000075aec0be063e  sub rsp, 0xF0
000075aec0be0645  vmovaps [rsp], xmm0
000075aec0be064a  vmovaps [rsp+0x10], xmm1
000075aec0be0650  vmovaps [rsp+0x20], xmm2
000075aec0be0656  vmovaps [rsp+0x30], xmm3
000075aec0be065c  vmovaps [rsp+0x40], xmm4
000075aec0be0662  vmovaps [rsp+0x50], xmm5
000075aec0be0668  vmovaps [rsp+0x60], xmm6
000075aec0be066e  vmovaps [rsp+0x70], xmm7
000075aec0be0674  vmovaps [rsp+0x80], xmm8
000075aec0be067d  vmovaps [rsp+0x90], xmm9
000075aec0be0686  vmovaps [rsp+0xA0], xmm10
000075aec0be068f  vmovaps [rsp+0xB0], xmm11
000075aec0be0698  vmovaps [rsp+0xC0], xmm12
000075aec0be06a1  vmovaps [rsp+0xD0], xmm14
000075aec0be06aa  vmovaps [rsp+0xE0], xmm15
000075aec0be06b3  sub rsp, 0x30
000075aec0be06b7  movaps [rsp], xmm13
000075aec0be06bc  movaps [rsp+0x10], xmm15
000075aec0be06c2  movaps [rsp+0x20], xmm8
000075aec0be06c8  lea rdi, [rsp]
000075aec0be06cc  mov esi, 0x00
000075aec0be06d1  mov rax, 0x57F4B31E6530
000075aec0be06db  call rax
000075aec0be06dd  movaps xmm13, [rsp]
000075aec0be06e2  add rsp, 0x30
000075aec0be06e6  vmovaps xmm0, [rsp]
000075aec0be06eb  vmovaps xmm1, [rsp+0x10]
000075aec0be06f1  vmovaps xmm2, [rsp+0x20]
000075aec0be06f7  vmovaps xmm3, [rsp+0x30]
000075aec0be06fd  vmovaps xmm4, [rsp+0x40]
000075aec0be0703  vmovaps xmm5, [rsp+0x50]
000075aec0be0709  vmovaps xmm6, [rsp+0x60]
000075aec0be070f  vmovaps xmm7, [rsp+0x70]
000075aec0be0715  vmovaps xmm8, [rsp+0x80]
000075aec0be071e  vmovaps xmm9, [rsp+0x90]
000075aec0be0727  vmovaps xmm10, [rsp+0xA0]
000075aec0be0730  vmovaps xmm11, [rsp+0xB0]
000075aec0be0739  vmovaps xmm12, [rsp+0xC0]
000075aec0be0742  vmovaps xmm14, [rsp+0xD0]
000075aec0be074b  vmovaps xmm15, [rsp+0xE0]
000075aec0be0754  add rsp, 0xF0
000075aec0be075b  pop r11
000075aec0be075d  pop r10
000075aec0be075f  pop r9
000075aec0be0761  pop r8
000075aec0be0763  pop rsi
000075aec0be0764  pop rdi
000075aec0be0765  pop rdx
000075aec0be0766  pop rcx
000075aec0be0767  pop rax
000075aec0be0768  add rsp, 0x08
000075aec0be076c  jmp 0x000075AEC0BDC60F
000075aec0be0771  sub rsp, 0x08
000075aec0be0775  push rax
000075aec0be0776  push rcx
000075aec0be0777  push rdx
000075aec0be0778  push rdi
000075aec0be0779  push rsi
000075aec0be077a  push r8
000075aec0be077c  push r9
000075aec0be077e  push r10
000075aec0be0780  push r11
000075aec0be0782  sub rsp, 0xF0
000075aec0be0789  vmovaps [rsp], xmm0
000075aec0be078e  vmovaps [rsp+0x10], xmm1
000075aec0be0794  vmovaps [rsp+0x20], xmm2
000075aec0be079a  vmovaps [rsp+0x30], xmm3
000075aec0be07a0  vmovaps [rsp+0x40], xmm4
000075aec0be07a6  vmovaps [rsp+0x50], xmm5
000075aec0be07ac  vmovaps [rsp+0x60], xmm6
000075aec0be07b2  vmovaps [rsp+0x70], xmm7
000075aec0be07b8  vmovaps [rsp+0x80], xmm9
000075aec0be07c1  vmovaps [rsp+0x90], xmm10
000075aec0be07ca  vmovaps [rsp+0xA0], xmm11
000075aec0be07d3  vmovaps [rsp+0xB0], xmm12
000075aec0be07dc  vmovaps [rsp+0xC0], xmm13
000075aec0be07e5  vmovaps [rsp+0xD0], xmm14
000075aec0be07ee  vmovaps [rsp+0xE0], xmm15
000075aec0be07f7  sub rsp, 0x30
000075aec0be07fb  movaps [rsp], xmm8
000075aec0be0800  movaps [rsp+0x10], xmm15
000075aec0be0806  movaps [rsp+0x20], xmm9
000075aec0be080c  lea rdi, [rsp]
000075aec0be0810  mov esi, 0x00
000075aec0be0815  mov rax, 0x57F4B31E6530
000075aec0be081f  call rax
000075aec0be0821  movaps xmm8, [rsp]
000075aec0be0826  add rsp, 0x30
000075aec0be082a  vmovaps xmm0, [rsp]
000075aec0be082f  vmovaps xmm1, [rsp+0x10]
000075aec0be0835  vmovaps xmm2, [rsp+0x20]
000075aec0be083b  vmovaps xmm3, [rsp+0x30]
000075aec0be0841  vmovaps xmm4, [rsp+0x40]
000075aec0be0847  vmovaps xmm5, [rsp+0x50]
000075aec0be084d  vmovaps xmm6, [rsp+0x60]
000075aec0be0853  vmovaps xmm7, [rsp+0x70]
000075aec0be0859  vmovaps xmm9, [rsp+0x80]
000075aec0be0862  vmovaps xmm10, [rsp+0x90]
000075aec0be086b  vmovaps xmm11, [rsp+0xA0]
000075aec0be0874  vmovaps xmm12, [rsp+0xB0]
000075aec0be087d  vmovaps xmm13, [rsp+0xC0]
000075aec0be0886  vmovaps xmm14, [rsp+0xD0]
000075aec0be088f  vmovaps xmm15, [rsp+0xE0]
000075aec0be0898  add rsp, 0xF0
000075aec0be089f  pop r11
000075aec0be08a1  pop r10
000075aec0be08a3  pop r9
000075aec0be08a5  pop r8
000075aec0be08a7  pop rsi
000075aec0be08a8  pop rdi
000075aec0be08a9  pop rdx
000075aec0be08aa  pop rcx
000075aec0be08ab  pop rax
000075aec0be08ac  add rsp, 0x08
000075aec0be08b0  jmp 0x000075AEC0BDC63D
000075aec0be08b5  sub rsp, 0x08
000075aec0be08b9  push rax
000075aec0be08ba  push rcx
000075aec0be08bb  push rdx
000075aec0be08bc  push rdi
000075aec0be08bd  push rsi
000075aec0be08be  push r8
000075aec0be08c0  push r9
000075aec0be08c2  push r10
000075aec0be08c4  push r11
000075aec0be08c6  sub rsp, 0xF0
000075aec0be08cd  vmovaps [rsp], xmm0
000075aec0be08d2  vmovaps [rsp+0x10], xmm1
000075aec0be08d8  vmovaps [rsp+0x20], xmm2
000075aec0be08de  vmovaps [rsp+0x30], xmm3
000075aec0be08e4  vmovaps [rsp+0x40], xmm4
000075aec0be08ea  vmovaps [rsp+0x50], xmm5
000075aec0be08f0  vmovaps [rsp+0x60], xmm6
000075aec0be08f6  vmovaps [rsp+0x70], xmm7
000075aec0be08fc  vmovaps [rsp+0x80], xmm8
000075aec0be0905  vmovaps [rsp+0x90], xmm9
000075aec0be090e  vmovaps [rsp+0xA0], xmm10
000075aec0be0917  vmovaps [rsp+0xB0], xmm11
000075aec0be0920  vmovaps [rsp+0xC0], xmm12
000075aec0be0929  vmovaps [rsp+0xD0], xmm13
000075aec0be0932  vmovaps [rsp+0xE0], xmm14
000075aec0be093b  sub rsp, 0x30
000075aec0be093f  movaps [rsp], xmm15
000075aec0be0944  movaps [rsp+0x10], xmm11
000075aec0be094a  movaps [rsp+0x20], xmm6
000075aec0be094f  lea rdi, [rsp]
000075aec0be0953  mov esi, 0x00
000075aec0be0958  mov rax, 0x57F4B31E6530
000075aec0be0962  call rax
000075aec0be0964  movaps xmm15, [rsp]
000075aec0be0969  add rsp, 0x30
000075aec0be096d  vmovaps xmm0, [rsp]
000075aec0be0972  vmovaps xmm1, [rsp+0x10]
000075aec0be0978  vmovaps xmm2, [rsp+0x20]
000075aec0be097e  vmovaps xmm3, [rsp+0x30]
000075aec0be0984  vmovaps xmm4, [rsp+0x40]
000075aec0be098a  vmovaps xmm5, [rsp+0x50]
000075aec0be0990  vmovaps xmm6, [rsp+0x60]
000075aec0be0996  vmovaps xmm7, [rsp+0x70]
000075aec0be099c  vmovaps xmm8, [rsp+0x80]
000075aec0be09a5  vmovaps xmm9, [rsp+0x90]
000075aec0be09ae  vmovaps xmm10, [rsp+0xA0]
000075aec0be09b7  vmovaps xmm11, [rsp+0xB0]
000075aec0be09c0  vmovaps xmm12, [rsp+0xC0]
000075aec0be09c9  vmovaps xmm13, [rsp+0xD0]
000075aec0be09d2  vmovaps xmm14, [rsp+0xE0]
000075aec0be09db  add rsp, 0xF0
000075aec0be09e2  pop r11
000075aec0be09e4  pop r10
000075aec0be09e6  pop r9
000075aec0be09e8  pop r8
000075aec0be09ea  pop rsi
000075aec0be09eb  pop rdi
000075aec0be09ec  pop rdx
000075aec0be09ed  pop rcx
000075aec0be09ee  pop rax
000075aec0be09ef  add rsp, 0x08
000075aec0be09f3  jmp 0x000075AEC0BDC658
000075aec0be09f8  sub rsp, 0x08
000075aec0be09fc  push rax
000075aec0be09fd  push rcx
000075aec0be09fe  push rdx
000075aec0be09ff  push rdi
000075aec0be0a00  push rsi
000075aec0be0a01  push r8
000075aec0be0a03  push r9
000075aec0be0a05  push r10
000075aec0be0a07  push r11
000075aec0be0a09  sub rsp, 0xF0
000075aec0be0a10  vmovaps [rsp], xmm0
000075aec0be0a15  vmovaps [rsp+0x10], xmm1
000075aec0be0a1b  vmovaps [rsp+0x20], xmm2
000075aec0be0a21  vmovaps [rsp+0x30], xmm3
000075aec0be0a27  vmovaps [rsp+0x40], xmm4
000075aec0be0a2d  vmovaps [rsp+0x50], xmm5
000075aec0be0a33  vmovaps [rsp+0x60], xmm6
000075aec0be0a39  vmovaps [rsp+0x70], xmm8
000075aec0be0a3f  vmovaps [rsp+0x80], xmm9
000075aec0be0a48  vmovaps [rsp+0x90], xmm10
000075aec0be0a51  vmovaps [rsp+0xA0], xmm11
000075aec0be0a5a  vmovaps [rsp+0xB0], xmm12
000075aec0be0a63  vmovaps [rsp+0xC0], xmm13
000075aec0be0a6c  vmovaps [rsp+0xD0], xmm14
000075aec0be0a75  vmovaps [rsp+0xE0], xmm15
000075aec0be0a7e  sub rsp, 0x30
000075aec0be0a82  movaps [rsp], xmm7
000075aec0be0a86  movaps [rsp+0x10], xmm11
000075aec0be0a8c  movaps [rsp+0x20], xmm9
000075aec0be0a92  lea rdi, [rsp]
000075aec0be0a96  mov esi, 0x00
000075aec0be0a9b  mov rax, 0x57F4B31E6530
000075aec0be0aa5  call rax
000075aec0be0aa7  movaps xmm7, [rsp]
000075aec0be0aab  add rsp, 0x30
000075aec0be0aaf  vmovaps xmm0, [rsp]
000075aec0be0ab4  vmovaps xmm1, [rsp+0x10]
000075aec0be0aba  vmovaps xmm2, [rsp+0x20]
000075aec0be0ac0  vmovaps xmm3, [rsp+0x30]
000075aec0be0ac6  vmovaps xmm4, [rsp+0x40]
000075aec0be0acc  vmovaps xmm5, [rsp+0x50]
000075aec0be0ad2  vmovaps xmm6, [rsp+0x60]
000075aec0be0ad8  vmovaps xmm8, [rsp+0x70]
000075aec0be0ade  vmovaps xmm9, [rsp+0x80]
000075aec0be0ae7  vmovaps xmm10, [rsp+0x90]
000075aec0be0af0  vmovaps xmm11, [rsp+0xA0]
000075aec0be0af9  vmovaps xmm12, [rsp+0xB0]
000075aec0be0b02  vmovaps xmm13, [rsp+0xC0]
000075aec0be0b0b  vmovaps xmm14, [rsp+0xD0]
000075aec0be0b14  vmovaps xmm15, [rsp+0xE0]
000075aec0be0b1d  add rsp, 0xF0
000075aec0be0b24  pop r11
000075aec0be0b26  pop r10
000075aec0be0b28  pop r9
000075aec0be0b2a  pop r8
000075aec0be0b2c  pop rsi
000075aec0be0b2d  pop rdi
000075aec0be0b2e  pop rdx
000075aec0be0b2f  pop rcx
000075aec0be0b30  pop rax
000075aec0be0b31  add rsp, 0x08
000075aec0be0b35  jmp 0x000075AEC0BDC685
000075aec0be0b3a  sub rsp, 0x08
000075aec0be0b3e  push rax
000075aec0be0b3f  push rcx
000075aec0be0b40  push rdx
000075aec0be0b41  push rdi
000075aec0be0b42  push rsi
000075aec0be0b43  push r8
000075aec0be0b45  push r9
000075aec0be0b47  push r10
000075aec0be0b49  push r11
000075aec0be0b4b  sub rsp, 0xF0
000075aec0be0b52  vmovaps [rsp], xmm0
000075aec0be0b57  vmovaps [rsp+0x10], xmm1
000075aec0be0b5d  vmovaps [rsp+0x20], xmm2
000075aec0be0b63  vmovaps [rsp+0x30], xmm3
000075aec0be0b69  vmovaps [rsp+0x40], xmm4
000075aec0be0b6f  vmovaps [rsp+0x50], xmm5
000075aec0be0b75  vmovaps [rsp+0x60], xmm6
000075aec0be0b7b  vmovaps [rsp+0x70], xmm7
000075aec0be0b81  vmovaps [rsp+0x80], xmm8
000075aec0be0b8a  vmovaps [rsp+0x90], xmm9
000075aec0be0b93  vmovaps [rsp+0xA0], xmm10
000075aec0be0b9c  vmovaps [rsp+0xB0], xmm12
000075aec0be0ba5  vmovaps [rsp+0xC0], xmm13
000075aec0be0bae  vmovaps [rsp+0xD0], xmm14
000075aec0be0bb7  vmovaps [rsp+0xE0], xmm15
000075aec0be0bc0  sub rsp, 0x30
000075aec0be0bc4  movaps [rsp], xmm11
000075aec0be0bc9  movaps [rsp+0x10], xmm10
000075aec0be0bcf  movaps [rsp+0x20], xmm14
000075aec0be0bd5  lea rdi, [rsp]
000075aec0be0bd9  mov esi, 0x00
000075aec0be0bde  mov rax, 0x57F4B31E6530
000075aec0be0be8  call rax
000075aec0be0bea  movaps xmm11, [rsp]
000075aec0be0bef  add rsp, 0x30
000075aec0be0bf3  vmovaps xmm0, [rsp]
000075aec0be0bf8  vmovaps xmm1, [rsp+0x10]
000075aec0be0bfe  vmovaps xmm2, [rsp+0x20]
000075aec0be0c04  vmovaps xmm3, [rsp+0x30]
000075aec0be0c0a  vmovaps xmm4, [rsp+0x40]
000075aec0be0c10  vmovaps xmm5, [rsp+0x50]
000075aec0be0c16  vmovaps xmm6, [rsp+0x60]
000075aec0be0c1c  vmovaps xmm7, [rsp+0x70]
000075aec0be0c22  vmovaps xmm8, [rsp+0x80]
000075aec0be0c2b  vmovaps xmm9, [rsp+0x90]
000075aec0be0c34  vmovaps xmm10, [rsp+0xA0]
000075aec0be0c3d  vmovaps xmm12, [rsp+0xB0]
000075aec0be0c46  vmovaps xmm13, [rsp+0xC0]
000075aec0be0c4f  vmovaps xmm14, [rsp+0xD0]
000075aec0be0c58  vmovaps xmm15, [rsp+0xE0]
000075aec0be0c61  add rsp, 0xF0
000075aec0be0c68  pop r11
000075aec0be0c6a  pop r10
000075aec0be0c6c  pop r9
000075aec0be0c6e  pop r8
000075aec0be0c70  pop rsi
000075aec0be0c71  pop rdi
000075aec0be0c72  pop rdx
000075aec0be0c73  pop rcx
000075aec0be0c74  pop rax
000075aec0be0c75  add rsp, 0x08
000075aec0be0c79  jmp 0x000075AEC0BDC6A0
000075aec0be0c7e  call 0x000075AEC0AC33A0
000075aec0be0c83  jmp 0x000075AEC0BDC6AA
000075aec0be0c88  sub rsp, 0x08
000075aec0be0c8c  push rax
000075aec0be0c8d  push rcx
000075aec0be0c8e  push rdx
000075aec0be0c8f  push rdi
000075aec0be0c90  push rsi
000075aec0be0c91  push r8
000075aec0be0c93  push r9
000075aec0be0c95  push r10
000075aec0be0c97  push r11
000075aec0be0c99  sub rsp, 0xF0
000075aec0be0ca0  vmovaps [rsp], xmm0
000075aec0be0ca5  vmovaps [rsp+0x10], xmm1
000075aec0be0cab  vmovaps [rsp+0x20], xmm2
000075aec0be0cb1  vmovaps [rsp+0x30], xmm3
000075aec0be0cb7  vmovaps [rsp+0x40], xmm4
000075aec0be0cbd  vmovaps [rsp+0x50], xmm5
000075aec0be0cc3  vmovaps [rsp+0x60], xmm6
000075aec0be0cc9  vmovaps [rsp+0x70], xmm7
000075aec0be0ccf  vmovaps [rsp+0x80], xmm8
000075aec0be0cd8  vmovaps [rsp+0x90], xmm9
000075aec0be0ce1  vmovaps [rsp+0xA0], xmm11
000075aec0be0cea  vmovaps [rsp+0xB0], xmm12
000075aec0be0cf3  vmovaps [rsp+0xC0], xmm13
000075aec0be0cfc  vmovaps [rsp+0xD0], xmm14
000075aec0be0d05  vmovaps [rsp+0xE0], xmm15
000075aec0be0d0e  sub rsp, 0x30
000075aec0be0d12  movaps [rsp], xmm10
000075aec0be0d17  movaps [rsp+0x10], xmm1
000075aec0be0d1c  movaps [rsp+0x20], xmm12
000075aec0be0d22  lea rdi, [rsp]
000075aec0be0d26  mov esi, 0x00
000075aec0be0d2b  mov rax, 0x57F4B31E6530
000075aec0be0d35  call rax
000075aec0be0d37  movaps xmm10, [rsp]
000075aec0be0d3c  add rsp, 0x30
000075aec0be0d40  vmovaps xmm0, [rsp]
000075aec0be0d45  vmovaps xmm1, [rsp+0x10]
000075aec0be0d4b  vmovaps xmm2, [rsp+0x20]
000075aec0be0d51  vmovaps xmm3, [rsp+0x30]
000075aec0be0d57  vmovaps xmm4, [rsp+0x40]
000075aec0be0d5d  vmovaps xmm5, [rsp+0x50]
000075aec0be0d63  vmovaps xmm6, [rsp+0x60]
000075aec0be0d69  vmovaps xmm7, [rsp+0x70]
000075aec0be0d6f  vmovaps xmm8, [rsp+0x80]
000075aec0be0d78  vmovaps xmm9, [rsp+0x90]
000075aec0be0d81  vmovaps xmm11, [rsp+0xA0]
000075aec0be0d8a  vmovaps xmm12, [rsp+0xB0]
000075aec0be0d93  vmovaps xmm13, [rsp+0xC0]
000075aec0be0d9c  vmovaps xmm14, [rsp+0xD0]
000075aec0be0da5  vmovaps xmm15, [rsp+0xE0]
000075aec0be0dae  add rsp, 0xF0
000075aec0be0db5  pop r11
000075aec0be0db7  pop r10
000075aec0be0db9  pop r9
000075aec0be0dbb  pop r8
000075aec0be0dbd  pop rsi
000075aec0be0dbe  pop rdi
000075aec0be0dbf  pop rdx
000075aec0be0dc0  pop rcx
000075aec0be0dc1  pop rax
000075aec0be0dc2  add rsp, 0x08
000075aec0be0dc6  jmp 0x000075AEC0BDC6CD
000075aec0be0dcb  sub rsp, 0x08
000075aec0be0dcf  push rax
000075aec0be0dd0  push rcx
000075aec0be0dd1  push rdx
000075aec0be0dd2  push rdi
000075aec0be0dd3  push rsi
000075aec0be0dd4  push r8
000075aec0be0dd6  push r9
000075aec0be0dd8  push r10
000075aec0be0dda  push r11
000075aec0be0ddc  sub rsp, 0xF0
000075aec0be0de3  vmovaps [rsp], xmm0
000075aec0be0de8  vmovaps [rsp+0x10], xmm1
000075aec0be0dee  vmovaps [rsp+0x20], xmm2
000075aec0be0df4  vmovaps [rsp+0x30], xmm3
000075aec0be0dfa  vmovaps [rsp+0x40], xmm4
000075aec0be0e00  vmovaps [rsp+0x50], xmm5
000075aec0be0e06  vmovaps [rsp+0x60], xmm6
000075aec0be0e0c  vmovaps [rsp+0x70], xmm7
000075aec0be0e12  vmovaps [rsp+0x80], xmm8
000075aec0be0e1b  vmovaps [rsp+0x90], xmm9
000075aec0be0e24  vmovaps [rsp+0xA0], xmm10
000075aec0be0e2d  vmovaps [rsp+0xB0], xmm11
000075aec0be0e36  vmovaps [rsp+0xC0], xmm13
000075aec0be0e3f  vmovaps [rsp+0xD0], xmm14
000075aec0be0e48  vmovaps [rsp+0xE0], xmm15
000075aec0be0e51  sub rsp, 0x30
000075aec0be0e55  movaps [rsp], xmm12
000075aec0be0e5a  movaps [rsp+0x10], xmm14
000075aec0be0e60  movaps [rsp+0x20], xmm1
000075aec0be0e65  lea rdi, [rsp]
000075aec0be0e69  mov esi, 0x00
000075aec0be0e6e  mov rax, 0x57F4B31E6530
000075aec0be0e78  call rax
000075aec0be0e7a  movaps xmm12, [rsp]
000075aec0be0e7f  add rsp, 0x30
000075aec0be0e83  vmovaps xmm0, [rsp]
000075aec0be0e88  vmovaps xmm1, [rsp+0x10]
000075aec0be0e8e  vmovaps xmm2, [rsp+0x20]
000075aec0be0e94  vmovaps xmm3, [rsp+0x30]
000075aec0be0e9a  vmovaps xmm4, [rsp+0x40]
000075aec0be0ea0  vmovaps xmm5, [rsp+0x50]
000075aec0be0ea6  vmovaps xmm6, [rsp+0x60]
000075aec0be0eac  vmovaps xmm7, [rsp+0x70]
000075aec0be0eb2  vmovaps xmm8, [rsp+0x80]
000075aec0be0ebb  vmovaps xmm9, [rsp+0x90]
000075aec0be0ec4  vmovaps xmm10, [rsp+0xA0]
000075aec0be0ecd  vmovaps xmm11, [rsp+0xB0]
000075aec0be0ed6  vmovaps xmm13, [rsp+0xC0]
000075aec0be0edf  vmovaps xmm14, [rsp+0xD0]
000075aec0be0ee8  vmovaps xmm15, [rsp+0xE0]
000075aec0be0ef1  add rsp, 0xF0
000075aec0be0ef8  pop r11
000075aec0be0efa  pop r10
000075aec0be0efc  pop r9
000075aec0be0efe  pop r8
000075aec0be0f00  pop rsi
000075aec0be0f01  pop rdi
000075aec0be0f02  pop rdx
000075aec0be0f03  pop rcx
000075aec0be0f04  pop rax
000075aec0be0f05  add rsp, 0x08
000075aec0be0f09  jmp 0x000075AEC0BDC6FC
000075aec0be0f0e  sub rsp, 0x08
000075aec0be0f12  push rax
000075aec0be0f13  push rcx
000075aec0be0f14  push rdx
000075aec0be0f15  push rdi
000075aec0be0f16  push rsi
000075aec0be0f17  push r8
000075aec0be0f19  push r9
000075aec0be0f1b  push r10
000075aec0be0f1d  push r11
000075aec0be0f1f  sub rsp, 0xF0
000075aec0be0f26  vmovaps [rsp], xmm0
000075aec0be0f2b  vmovaps [rsp+0x10], xmm1
000075aec0be0f31  vmovaps [rsp+0x20], xmm2
000075aec0be0f37  vmovaps [rsp+0x30], xmm3
000075aec0be0f3d  vmovaps [rsp+0x40], xmm4
000075aec0be0f43  vmovaps [rsp+0x50], xmm5
000075aec0be0f49  vmovaps [rsp+0x60], xmm6
000075aec0be0f4f  vmovaps [rsp+0x70], xmm7
000075aec0be0f55  vmovaps [rsp+0x80], xmm8
000075aec0be0f5e  vmovaps [rsp+0x90], xmm9
000075aec0be0f67  vmovaps [rsp+0xA0], xmm10
000075aec0be0f70  vmovaps [rsp+0xB0], xmm11
000075aec0be0f79  vmovaps [rsp+0xC0], xmm12
000075aec0be0f82  vmovaps [rsp+0xD0], xmm13
000075aec0be0f8b  vmovaps [rsp+0xE0], xmm15
000075aec0be0f94  sub rsp, 0x30
000075aec0be0f98  movaps [rsp], xmm14
000075aec0be0f9d  movaps [rsp+0x10], xmm9
000075aec0be0fa3  movaps [rsp+0x20], xmm1
000075aec0be0fa8  lea rdi, [rsp]
000075aec0be0fac  mov esi, 0x00
000075aec0be0fb1  mov rax, 0x57F4B31E6530
000075aec0be0fbb  call rax
000075aec0be0fbd  movaps xmm14, [rsp]
000075aec0be0fc2  add rsp, 0x30
000075aec0be0fc6  vmovaps xmm0, [rsp]
000075aec0be0fcb  vmovaps xmm1, [rsp+0x10]
000075aec0be0fd1  vmovaps xmm2, [rsp+0x20]
000075aec0be0fd7  vmovaps xmm3, [rsp+0x30]
000075aec0be0fdd  vmovaps xmm4, [rsp+0x40]
000075aec0be0fe3  vmovaps xmm5, [rsp+0x50]
000075aec0be0fe9  vmovaps xmm6, [rsp+0x60]
000075aec0be0fef  vmovaps xmm7, [rsp+0x70]
000075aec0be0ff5  vmovaps xmm8, [rsp+0x80]
000075aec0be0ffe  vmovaps xmm9, [rsp+0x90]
000075aec0be1007  vmovaps xmm10, [rsp+0xA0]
000075aec0be1010  vmovaps xmm11, [rsp+0xB0]
000075aec0be1019  vmovaps xmm12, [rsp+0xC0]
000075aec0be1022  vmovaps xmm13, [rsp+0xD0]
000075aec0be102b  vmovaps xmm15, [rsp+0xE0]
000075aec0be1034  add rsp, 0xF0
000075aec0be103b  pop r11
000075aec0be103d  pop r10
000075aec0be103f  pop r9
000075aec0be1041  pop r8
000075aec0be1043  pop rsi
000075aec0be1044  pop rdi
000075aec0be1045  pop rdx
000075aec0be1046  pop rcx
000075aec0be1047  pop rax
000075aec0be1048  add rsp, 0x08
000075aec0be104c  jmp 0x000075AEC0BDC72B
000075aec0be1051  sub rsp, 0x08
000075aec0be1055  push rax
000075aec0be1056  push rcx
000075aec0be1057  push rdx
000075aec0be1058  push rdi
000075aec0be1059  push rsi
000075aec0be105a  push r8
000075aec0be105c  push r9
000075aec0be105e  push r10
000075aec0be1060  push r11
000075aec0be1062  sub rsp, 0xF0
000075aec0be1069  vmovaps [rsp], xmm0
000075aec0be106e  vmovaps [rsp+0x10], xmm2
000075aec0be1074  vmovaps [rsp+0x20], xmm3
000075aec0be107a  vmovaps [rsp+0x30], xmm4
000075aec0be1080  vmovaps [rsp+0x40], xmm5
000075aec0be1086  vmovaps [rsp+0x50], xmm6
000075aec0be108c  vmovaps [rsp+0x60], xmm7
000075aec0be1092  vmovaps [rsp+0x70], xmm8
000075aec0be1098  vmovaps [rsp+0x80], xmm9
000075aec0be10a1  vmovaps [rsp+0x90], xmm10
000075aec0be10aa  vmovaps [rsp+0xA0], xmm11
000075aec0be10b3  vmovaps [rsp+0xB0], xmm12
000075aec0be10bc  vmovaps [rsp+0xC0], xmm13
000075aec0be10c5  vmovaps [rsp+0xD0], xmm14
000075aec0be10ce  vmovaps [rsp+0xE0], xmm15
000075aec0be10d7  sub rsp, 0x30
000075aec0be10db  movaps [rsp], xmm1
000075aec0be10df  movaps [rsp+0x10], xmm13
000075aec0be10e5  movaps [rsp+0x20], xmm8
000075aec0be10eb  lea rdi, [rsp]
000075aec0be10ef  mov esi, 0x00
000075aec0be10f4  mov rax, 0x57F4B31E6530
000075aec0be10fe  call rax
000075aec0be1100  movaps xmm1, [rsp]
000075aec0be1104  add rsp, 0x30
000075aec0be1108  vmovaps xmm0, [rsp]
000075aec0be110d  vmovaps xmm2, [rsp+0x10]
000075aec0be1113  vmovaps xmm3, [rsp+0x20]
000075aec0be1119  vmovaps xmm4, [rsp+0x30]
000075aec0be111f  vmovaps xmm5, [rsp+0x40]
000075aec0be1125  vmovaps xmm6, [rsp+0x50]
000075aec0be112b  vmovaps xmm7, [rsp+0x60]
000075aec0be1131  vmovaps xmm8, [rsp+0x70]
000075aec0be1137  vmovaps xmm9, [rsp+0x80]
000075aec0be1140  vmovaps xmm10, [rsp+0x90]
000075aec0be1149  vmovaps xmm11, [rsp+0xA0]
000075aec0be1152  vmovaps xmm12, [rsp+0xB0]
000075aec0be115b  vmovaps xmm13, [rsp+0xC0]
000075aec0be1164  vmovaps xmm14, [rsp+0xD0]
000075aec0be116d  vmovaps xmm15, [rsp+0xE0]
000075aec0be1176  add rsp, 0xF0
000075aec0be117d  pop r11
000075aec0be117f  pop r10
000075aec0be1181  pop r9
000075aec0be1183  pop r8
000075aec0be1185  pop rsi
000075aec0be1186  pop rdi
000075aec0be1187  pop rdx
000075aec0be1188  pop rcx
000075aec0be1189  pop rax
000075aec0be118a  add rsp, 0x08
000075aec0be118e  jmp 0x000075AEC0BDC74D
000075aec0be1193  call 0x000075AEC0A0C260
000075aec0be1198  jmp 0x000075AEC0BDC75B
000075aec0be119d  call 0x000075AEC0ABD750
000075aec0be11a2  jmp 0x000075AEC0BDC765
000075aec0be11a7  sub rsp, 0x08
000075aec0be11ab  push rax
000075aec0be11ac  push rcx
000075aec0be11ad  push rdx
000075aec0be11ae  push rdi
000075aec0be11af  push rsi
000075aec0be11b0  push r8
000075aec0be11b2  push r9
000075aec0be11b4  push r10
000075aec0be11b6  push r11
000075aec0be11b8  sub rsp, 0xF0
000075aec0be11bf  vmovaps [rsp], xmm0
000075aec0be11c4  vmovaps [rsp+0x10], xmm1
000075aec0be11ca  vmovaps [rsp+0x20], xmm2
000075aec0be11d0  vmovaps [rsp+0x30], xmm3
000075aec0be11d6  vmovaps [rsp+0x40], xmm4
000075aec0be11dc  vmovaps [rsp+0x50], xmm5
000075aec0be11e2  vmovaps [rsp+0x60], xmm6
000075aec0be11e8  vmovaps [rsp+0x70], xmm7
000075aec0be11ee  vmovaps [rsp+0x80], xmm9
000075aec0be11f7  vmovaps [rsp+0x90], xmm10
000075aec0be1200  vmovaps [rsp+0xA0], xmm11
000075aec0be1209  vmovaps [rsp+0xB0], xmm12
000075aec0be1212  vmovaps [rsp+0xC0], xmm13
000075aec0be121b  vmovaps [rsp+0xD0], xmm14
000075aec0be1224  vmovaps [rsp+0xE0], xmm15
000075aec0be122d  sub rsp, 0x30
000075aec0be1231  movaps [rsp], xmm8
000075aec0be1236  movaps [rsp+0x10], xmm15
000075aec0be123c  movaps [rsp+0x20], xmm7
000075aec0be1241  lea rdi, [rsp]
000075aec0be1245  mov esi, 0x00
000075aec0be124a  mov rax, 0x57F4B31E6530
000075aec0be1254  call rax
000075aec0be1256  movaps xmm8, [rsp]
000075aec0be125b  add rsp, 0x30
000075aec0be125f  vmovaps xmm0, [rsp]
000075aec0be1264  vmovaps xmm1, [rsp+0x10]
000075aec0be126a  vmovaps xmm2, [rsp+0x20]
000075aec0be1270  vmovaps xmm3, [rsp+0x30]
000075aec0be1276  vmovaps xmm4, [rsp+0x40]
000075aec0be127c  vmovaps xmm5, [rsp+0x50]
000075aec0be1282  vmovaps xmm6, [rsp+0x60]
000075aec0be1288  vmovaps xmm7, [rsp+0x70]
000075aec0be128e  vmovaps xmm9, [rsp+0x80]
000075aec0be1297  vmovaps xmm10, [rsp+0x90]
000075aec0be12a0  vmovaps xmm11, [rsp+0xA0]
000075aec0be12a9  vmovaps xmm12, [rsp+0xB0]
000075aec0be12b2  vmovaps xmm13, [rsp+0xC0]
000075aec0be12bb  vmovaps xmm14, [rsp+0xD0]
000075aec0be12c4  vmovaps xmm15, [rsp+0xE0]
000075aec0be12cd  add rsp, 0xF0
000075aec0be12d4  pop r11
000075aec0be12d6  pop r10
000075aec0be12d8  pop r9
000075aec0be12da  pop r8
000075aec0be12dc  pop rsi
000075aec0be12dd  pop rdi
000075aec0be12de  pop rdx
000075aec0be12df  pop rcx
000075aec0be12e0  pop rax
000075aec0be12e1  add rsp, 0x08
000075aec0be12e5  jmp 0x000075AEC0BDC787
000075aec0be12ea  sub rsp, 0x08
000075aec0be12ee  push rax
000075aec0be12ef  push rcx
000075aec0be12f0  push rdx
000075aec0be12f1  push rdi
000075aec0be12f2  push rsi
000075aec0be12f3  push r8
000075aec0be12f5  push r9
000075aec0be12f7  push r10
000075aec0be12f9  push r11
000075aec0be12fb  sub rsp, 0xF0
000075aec0be1302  vmovaps [rsp], xmm0
000075aec0be1307  vmovaps [rsp+0x10], xmm1
000075aec0be130d  vmovaps [rsp+0x20], xmm2
000075aec0be1313  vmovaps [rsp+0x30], xmm3
000075aec0be1319  vmovaps [rsp+0x40], xmm4
000075aec0be131f  vmovaps [rsp+0x50], xmm5
000075aec0be1325  vmovaps [rsp+0x60], xmm6
000075aec0be132b  vmovaps [rsp+0x70], xmm8
000075aec0be1331  vmovaps [rsp+0x80], xmm9
000075aec0be133a  vmovaps [rsp+0x90], xmm10
000075aec0be1343  vmovaps [rsp+0xA0], xmm11
000075aec0be134c  vmovaps [rsp+0xB0], xmm12
000075aec0be1355  vmovaps [rsp+0xC0], xmm13
000075aec0be135e  vmovaps [rsp+0xD0], xmm14
000075aec0be1367  vmovaps [rsp+0xE0], xmm15
000075aec0be1370  sub rsp, 0x30
000075aec0be1374  movaps [rsp], xmm7
000075aec0be1378  movaps [rsp+0x10], xmm9
000075aec0be137e  movaps [rsp+0x20], xmm15
000075aec0be1384  lea rdi, [rsp]
000075aec0be1388  mov esi, 0x00
000075aec0be138d  mov rax, 0x57F4B31E6530
000075aec0be1397  call rax
000075aec0be1399  movaps xmm7, [rsp]
000075aec0be139d  add rsp, 0x30
000075aec0be13a1  vmovaps xmm0, [rsp]
000075aec0be13a6  vmovaps xmm1, [rsp+0x10]
000075aec0be13ac  vmovaps xmm2, [rsp+0x20]
000075aec0be13b2  vmovaps xmm3, [rsp+0x30]
000075aec0be13b8  vmovaps xmm4, [rsp+0x40]
000075aec0be13be  vmovaps xmm5, [rsp+0x50]
000075aec0be13c4  vmovaps xmm6, [rsp+0x60]
000075aec0be13ca  vmovaps xmm8, [rsp+0x70]
000075aec0be13d0  vmovaps xmm9, [rsp+0x80]
000075aec0be13d9  vmovaps xmm10, [rsp+0x90]
000075aec0be13e2  vmovaps xmm11, [rsp+0xA0]
000075aec0be13eb  vmovaps xmm12, [rsp+0xB0]
000075aec0be13f4  vmovaps xmm13, [rsp+0xC0]
000075aec0be13fd  vmovaps xmm14, [rsp+0xD0]
000075aec0be1406  vmovaps xmm15, [rsp+0xE0]
000075aec0be140f  add rsp, 0xF0
000075aec0be1416  pop r11
000075aec0be1418  pop r10
000075aec0be141a  pop r9
000075aec0be141c  pop r8
000075aec0be141e  pop rsi
000075aec0be141f  pop rdi
000075aec0be1420  pop rdx
000075aec0be1421  pop rcx
000075aec0be1422  pop rax
000075aec0be1423  add rsp, 0x08
000075aec0be1427  jmp 0x000075AEC0BDC7B4
000075aec0be142c  sub rsp, 0x08
000075aec0be1430  push rax
000075aec0be1431  push rcx
000075aec0be1432  push rdx
000075aec0be1433  push rdi
000075aec0be1434  push rsi
000075aec0be1435  push r8
000075aec0be1437  push r9
000075aec0be1439  push r10
000075aec0be143b  push r11
000075aec0be143d  sub rsp, 0xF0
000075aec0be1444  vmovaps [rsp], xmm0
000075aec0be1449  vmovaps [rsp+0x10], xmm1
000075aec0be144f  vmovaps [rsp+0x20], xmm2
000075aec0be1455  vmovaps [rsp+0x30], xmm3
000075aec0be145b  vmovaps [rsp+0x40], xmm4
000075aec0be1461  vmovaps [rsp+0x50], xmm5
000075aec0be1467  vmovaps [rsp+0x60], xmm6
000075aec0be146d  vmovaps [rsp+0x70], xmm7
000075aec0be1473  vmovaps [rsp+0x80], xmm8
000075aec0be147c  vmovaps [rsp+0x90], xmm10
000075aec0be1485  vmovaps [rsp+0xA0], xmm11
000075aec0be148e  vmovaps [rsp+0xB0], xmm12
000075aec0be1497  vmovaps [rsp+0xC0], xmm13
000075aec0be14a0  vmovaps [rsp+0xD0], xmm14
000075aec0be14a9  vmovaps [rsp+0xE0], xmm15
000075aec0be14b2  sub rsp, 0x30
000075aec0be14b6  movaps [rsp], xmm9
000075aec0be14bb  movaps [rsp+0x10], xmm13
000075aec0be14c1  movaps [rsp+0x20], xmm15
000075aec0be14c7  lea rdi, [rsp]
000075aec0be14cb  mov esi, 0x00
000075aec0be14d0  mov rax, 0x57F4B31E6530
000075aec0be14da  call rax
000075aec0be14dc  movaps xmm9, [rsp]
000075aec0be14e1  add rsp, 0x30
000075aec0be14e5  vmovaps xmm0, [rsp]
000075aec0be14ea  vmovaps xmm1, [rsp+0x10]
000075aec0be14f0  vmovaps xmm2, [rsp+0x20]
000075aec0be14f6  vmovaps xmm3, [rsp+0x30]
000075aec0be14fc  vmovaps xmm4, [rsp+0x40]
000075aec0be1502  vmovaps xmm5, [rsp+0x50]
000075aec0be1508  vmovaps xmm6, [rsp+0x60]
000075aec0be150e  vmovaps xmm7, [rsp+0x70]
000075aec0be1514  vmovaps xmm8, [rsp+0x80]
000075aec0be151d  vmovaps xmm10, [rsp+0x90]
000075aec0be1526  vmovaps xmm11, [rsp+0xA0]
000075aec0be152f  vmovaps xmm12, [rsp+0xB0]
000075aec0be1538  vmovaps xmm13, [rsp+0xC0]
000075aec0be1541  vmovaps xmm14, [rsp+0xD0]
000075aec0be154a  vmovaps xmm15, [rsp+0xE0]
000075aec0be1553  add rsp, 0xF0
000075aec0be155a  pop r11
000075aec0be155c  pop r10
000075aec0be155e  pop r9
000075aec0be1560  pop r8
000075aec0be1562  pop rsi
000075aec0be1563  pop rdi
000075aec0be1564  pop rdx
000075aec0be1565  pop rcx
000075aec0be1566  pop rax
000075aec0be1567  add rsp, 0x08
000075aec0be156b  jmp 0x000075AEC0BDC7E2
000075aec0be1570  sub rsp, 0x08
000075aec0be1574  push rax
000075aec0be1575  push rcx
000075aec0be1576  push rdx
000075aec0be1577  push rdi
000075aec0be1578  push rsi
000075aec0be1579  push r8
000075aec0be157b  push r9
000075aec0be157d  push r10
000075aec0be157f  push r11
000075aec0be1581  sub rsp, 0xF0
000075aec0be1588  vmovaps [rsp], xmm0
000075aec0be158d  vmovaps [rsp+0x10], xmm1
000075aec0be1593  vmovaps [rsp+0x20], xmm2
000075aec0be1599  vmovaps [rsp+0x30], xmm3
000075aec0be159f  vmovaps [rsp+0x40], xmm4
000075aec0be15a5  vmovaps [rsp+0x50], xmm5
000075aec0be15ab  vmovaps [rsp+0x60], xmm6
000075aec0be15b1  vmovaps [rsp+0x70], xmm7
000075aec0be15b7  vmovaps [rsp+0x80], xmm8
000075aec0be15c0  vmovaps [rsp+0x90], xmm9
000075aec0be15c9  vmovaps [rsp+0xA0], xmm10
000075aec0be15d2  vmovaps [rsp+0xB0], xmm11
000075aec0be15db  vmovaps [rsp+0xC0], xmm12
000075aec0be15e4  vmovaps [rsp+0xD0], xmm13
000075aec0be15ed  vmovaps [rsp+0xE0], xmm14
000075aec0be15f6  sub rsp, 0x30
000075aec0be15fa  movaps [rsp], xmm15
000075aec0be15ff  movaps [rsp+0x10], xmm11
000075aec0be1605  movaps [rsp+0x20], xmm12
000075aec0be160b  lea rdi, [rsp]
000075aec0be160f  mov esi, 0x00
000075aec0be1614  mov rax, 0x57F4B31E6530
000075aec0be161e  call rax
000075aec0be1620  movaps xmm15, [rsp]
000075aec0be1625  add rsp, 0x30
000075aec0be1629  vmovaps xmm0, [rsp]
000075aec0be162e  vmovaps xmm1, [rsp+0x10]
000075aec0be1634  vmovaps xmm2, [rsp+0x20]
000075aec0be163a  vmovaps xmm3, [rsp+0x30]
000075aec0be1640  vmovaps xmm4, [rsp+0x40]
000075aec0be1646  vmovaps xmm5, [rsp+0x50]
000075aec0be164c  vmovaps xmm6, [rsp+0x60]
000075aec0be1652  vmovaps xmm7, [rsp+0x70]
000075aec0be1658  vmovaps xmm8, [rsp+0x80]
000075aec0be1661  vmovaps xmm9, [rsp+0x90]
000075aec0be166a  vmovaps xmm10, [rsp+0xA0]
000075aec0be1673  vmovaps xmm11, [rsp+0xB0]
000075aec0be167c  vmovaps xmm12, [rsp+0xC0]
000075aec0be1685  vmovaps xmm13, [rsp+0xD0]
000075aec0be168e  vmovaps xmm14, [rsp+0xE0]
000075aec0be1697  add rsp, 0xF0
000075aec0be169e  pop r11
000075aec0be16a0  pop r10
000075aec0be16a2  pop r9
000075aec0be16a4  pop r8
000075aec0be16a6  pop rsi
000075aec0be16a7  pop rdi
000075aec0be16a8  pop rdx
000075aec0be16a9  pop rcx
000075aec0be16aa  pop rax
000075aec0be16ab  add rsp, 0x08
000075aec0be16af  jmp 0x000075AEC0BDC7FD
000075aec0be16b4  sub rsp, 0x08
000075aec0be16b8  push rax
000075aec0be16b9  push rcx
000075aec0be16ba  push rdx
000075aec0be16bb  push rdi
000075aec0be16bc  push rsi
000075aec0be16bd  push r8
000075aec0be16bf  push r9
000075aec0be16c1  push r10
000075aec0be16c3  push r11
000075aec0be16c5  sub rsp, 0xF0
000075aec0be16cc  vmovaps [rsp], xmm0
000075aec0be16d1  vmovaps [rsp+0x10], xmm1
000075aec0be16d7  vmovaps [rsp+0x20], xmm2
000075aec0be16dd  vmovaps [rsp+0x30], xmm3
000075aec0be16e3  vmovaps [rsp+0x40], xmm4
000075aec0be16e9  vmovaps [rsp+0x50], xmm5
000075aec0be16ef  vmovaps [rsp+0x60], xmm6
000075aec0be16f5  vmovaps [rsp+0x70], xmm7
000075aec0be16fb  vmovaps [rsp+0x80], xmm8
000075aec0be1704  vmovaps [rsp+0x90], xmm9
000075aec0be170d  vmovaps [rsp+0xA0], xmm10
000075aec0be1716  vmovaps [rsp+0xB0], xmm11
000075aec0be171f  vmovaps [rsp+0xC0], xmm12
000075aec0be1728  vmovaps [rsp+0xD0], xmm14
000075aec0be1731  vmovaps [rsp+0xE0], xmm15
000075aec0be173a  sub rsp, 0x30
000075aec0be173e  movaps [rsp], xmm13
000075aec0be1743  movaps [rsp+0x10], xmm10
000075aec0be1749  movaps [rsp+0x20], xmm14
000075aec0be174f  lea rdi, [rsp]
000075aec0be1753  mov esi, 0x00
000075aec0be1758  mov rax, 0x57F4B31E6530
000075aec0be1762  call rax
000075aec0be1764  movaps xmm13, [rsp]
000075aec0be1769  add rsp, 0x30
000075aec0be176d  vmovaps xmm0, [rsp]
000075aec0be1772  vmovaps xmm1, [rsp+0x10]
000075aec0be1778  vmovaps xmm2, [rsp+0x20]
000075aec0be177e  vmovaps xmm3, [rsp+0x30]
000075aec0be1784  vmovaps xmm4, [rsp+0x40]
000075aec0be178a  vmovaps xmm5, [rsp+0x50]
000075aec0be1790  vmovaps xmm6, [rsp+0x60]
000075aec0be1796  vmovaps xmm7, [rsp+0x70]
000075aec0be179c  vmovaps xmm8, [rsp+0x80]
000075aec0be17a5  vmovaps xmm9, [rsp+0x90]
000075aec0be17ae  vmovaps xmm10, [rsp+0xA0]
000075aec0be17b7  vmovaps xmm11, [rsp+0xB0]
000075aec0be17c0  vmovaps xmm12, [rsp+0xC0]
000075aec0be17c9  vmovaps xmm14, [rsp+0xD0]
000075aec0be17d2  vmovaps xmm15, [rsp+0xE0]
000075aec0be17db  add rsp, 0xF0
000075aec0be17e2  pop r11
000075aec0be17e4  pop r10
000075aec0be17e6  pop r9
000075aec0be17e8  pop r8
000075aec0be17ea  pop rsi
000075aec0be17eb  pop rdi
000075aec0be17ec  pop rdx
000075aec0be17ed  pop rcx
000075aec0be17ee  pop rax
000075aec0be17ef  add rsp, 0x08
000075aec0be17f3  jmp 0x000075AEC0BDC820
000075aec0be17f8  sub rsp, 0x08
000075aec0be17fc  push rax
000075aec0be17fd  push rcx
000075aec0be17fe  push rdx
000075aec0be17ff  push rdi
000075aec0be1800  push rsi
000075aec0be1801  push r8
000075aec0be1803  push r9
000075aec0be1805  push r10
000075aec0be1807  push r11
000075aec0be1809  sub rsp, 0xF0
000075aec0be1810  vmovaps [rsp], xmm0
000075aec0be1815  vmovaps [rsp+0x10], xmm1
000075aec0be181b  vmovaps [rsp+0x20], xmm2
000075aec0be1821  vmovaps [rsp+0x30], xmm3
000075aec0be1827  vmovaps [rsp+0x40], xmm4
000075aec0be182d  vmovaps [rsp+0x50], xmm5
000075aec0be1833  vmovaps [rsp+0x60], xmm6
000075aec0be1839  vmovaps [rsp+0x70], xmm7
000075aec0be183f  vmovaps [rsp+0x80], xmm8
000075aec0be1848  vmovaps [rsp+0x90], xmm9
000075aec0be1851  vmovaps [rsp+0xA0], xmm10
000075aec0be185a  vmovaps [rsp+0xB0], xmm11
000075aec0be1863  vmovaps [rsp+0xC0], xmm12
000075aec0be186c  vmovaps [rsp+0xD0], xmm13
000075aec0be1875  vmovaps [rsp+0xE0], xmm15
000075aec0be187e  sub rsp, 0x30
000075aec0be1882  movaps [rsp], xmm14
000075aec0be1887  movaps [rsp+0x10], xmm1
000075aec0be188c  movaps [rsp+0x20], xmm7
000075aec0be1891  lea rdi, [rsp]
000075aec0be1895  mov esi, 0x00
000075aec0be189a  mov rax, 0x57F4B31E6530
000075aec0be18a4  call rax
000075aec0be18a6  movaps xmm14, [rsp]
000075aec0be18ab  add rsp, 0x30
000075aec0be18af  vmovaps xmm0, [rsp]
000075aec0be18b4  vmovaps xmm1, [rsp+0x10]
000075aec0be18ba  vmovaps xmm2, [rsp+0x20]
000075aec0be18c0  vmovaps xmm3, [rsp+0x30]
000075aec0be18c6  vmovaps xmm4, [rsp+0x40]
000075aec0be18cc  vmovaps xmm5, [rsp+0x50]
000075aec0be18d2  vmovaps xmm6, [rsp+0x60]
000075aec0be18d8  vmovaps xmm7, [rsp+0x70]
000075aec0be18de  vmovaps xmm8, [rsp+0x80]
000075aec0be18e7  vmovaps xmm9, [rsp+0x90]
000075aec0be18f0  vmovaps xmm10, [rsp+0xA0]
000075aec0be18f9  vmovaps xmm11, [rsp+0xB0]
000075aec0be1902  vmovaps xmm12, [rsp+0xC0]
000075aec0be190b  vmovaps xmm13, [rsp+0xD0]
000075aec0be1914  vmovaps xmm15, [rsp+0xE0]
000075aec0be191d  add rsp, 0xF0
000075aec0be1924  pop r11
000075aec0be1926  pop r10
000075aec0be1928  pop r9
000075aec0be192a  pop r8
000075aec0be192c  pop rsi
000075aec0be192d  pop rdi
000075aec0be192e  pop rdx
000075aec0be192f  pop rcx
000075aec0be1930  pop rax
000075aec0be1931  add rsp, 0x08
000075aec0be1935  jmp 0x000075AEC0BDC843
000075aec0be193a  sub rsp, 0x08
000075aec0be193e  push rax
000075aec0be193f  push rcx
000075aec0be1940  push rdx
000075aec0be1941  push rdi
000075aec0be1942  push rsi
000075aec0be1943  push r8
000075aec0be1945  push r9
000075aec0be1947  push r10
000075aec0be1949  push r11
000075aec0be194b  sub rsp, 0xF0
000075aec0be1952  vmovaps [rsp], xmm0
000075aec0be1957  vmovaps [rsp+0x10], xmm2
000075aec0be195d  vmovaps [rsp+0x20], xmm3
000075aec0be1963  vmovaps [rsp+0x30], xmm4
000075aec0be1969  vmovaps [rsp+0x40], xmm5
000075aec0be196f  vmovaps [rsp+0x50], xmm6
000075aec0be1975  vmovaps [rsp+0x60], xmm7
000075aec0be197b  vmovaps [rsp+0x70], xmm8
000075aec0be1981  vmovaps [rsp+0x80], xmm9
000075aec0be198a  vmovaps [rsp+0x90], xmm10
000075aec0be1993  vmovaps [rsp+0xA0], xmm11
000075aec0be199c  vmovaps [rsp+0xB0], xmm12
000075aec0be19a5  vmovaps [rsp+0xC0], xmm13
000075aec0be19ae  vmovaps [rsp+0xD0], xmm14
000075aec0be19b7  vmovaps [rsp+0xE0], xmm15
000075aec0be19c0  sub rsp, 0x30
000075aec0be19c4  movaps [rsp], xmm1
000075aec0be19c8  movaps [rsp+0x10], xmm8
000075aec0be19ce  movaps [rsp+0x20], xmm9
000075aec0be19d4  lea rdi, [rsp]
000075aec0be19d8  mov esi, 0x00
000075aec0be19dd  mov rax, 0x57F4B31E6530
000075aec0be19e7  call rax
000075aec0be19e9  movaps xmm1, [rsp]
000075aec0be19ed  add rsp, 0x30
000075aec0be19f1  vmovaps xmm0, [rsp]
000075aec0be19f6  vmovaps xmm2, [rsp+0x10]
000075aec0be19fc  vmovaps xmm3, [rsp+0x20]
000075aec0be1a02  vmovaps xmm4, [rsp+0x30]
000075aec0be1a08  vmovaps xmm5, [rsp+0x40]
000075aec0be1a0e  vmovaps xmm6, [rsp+0x50]
000075aec0be1a14  vmovaps xmm7, [rsp+0x60]
000075aec0be1a1a  vmovaps xmm8, [rsp+0x70]
000075aec0be1a20  vmovaps xmm9, [rsp+0x80]
000075aec0be1a29  vmovaps xmm10, [rsp+0x90]
000075aec0be1a32  vmovaps xmm11, [rsp+0xA0]
000075aec0be1a3b  vmovaps xmm12, [rsp+0xB0]
000075aec0be1a44  vmovaps xmm13, [rsp+0xC0]
000075aec0be1a4d  vmovaps xmm14, [rsp+0xD0]
000075aec0be1a56  vmovaps xmm15, [rsp+0xE0]
000075aec0be1a5f  add rsp, 0xF0
000075aec0be1a66  pop r11
000075aec0be1a68  pop r10
000075aec0be1a6a  pop r9
000075aec0be1a6c  pop r8
000075aec0be1a6e  pop rsi
000075aec0be1a6f  pop rdi
000075aec0be1a70  pop rdx
000075aec0be1a71  pop rcx
000075aec0be1a72  pop rax
000075aec0be1a73  add rsp, 0x08
000075aec0be1a77  jmp 0x000075AEC0BDC865
000075aec0be1a7c  call 0x000075AEC0AE5940
000075aec0be1a81  jmp 0x000075AEC0BDC873
000075aec0be1a86  call 0x000075AEC0A0C380
000075aec0be1a8b  jmp 0x000075AEC0BDC87D
000075aec0be1a90  call 0x000075AEC0A0D600
000075aec0be1a95  jmp 0x000075AEC0BDC887
000075aec0be1a9a  call 0x000075AEC09FF540
000075aec0be1a9f  jmp 0x000075AEC0BDC891
000075aec0be1aa4  int3
000075aec0be1aa5  nop [rax+rax*1], ax
000075aec0be1aae  nop
000075aec0be1ab0  mov rax, [r15+0xF8]
000075aec0be1ab7  lea r14, [rax+0x140]
000075aec0be1abe  mov r12, [r13+r14*1]
000075aec0be1ac3  mov [r15+0xE8], r12
000075aec0be1aca  lea r14, [rax+0x130]
000075aec0be1ad1  mov r12, [r13+r14*1]
000075aec0be1ad6  lea r14, [rax+0x138]
000075aec0be1add  mov r11, [r13+r14*1]
000075aec0be1ae2  movq xmm1, r12
000075aec0be1ae7  movq xmm15, r11
000075aec0be1aec  movq xmm1, xmm1
000075aec0be1af0  movq xmm1, xmm1
000075aec0be1af4  movaps [r15+0x1A0], xmm1
000075aec0be1afc  movq xmm15, xmm15
000075aec0be1b01  movq xmm15, xmm15
000075aec0be1b06  movaps [r15+0x190], xmm15
000075aec0be1b0e  lea r14, [rax+0x120]
000075aec0be1b15  mov r12, [r13+r14*1]
000075aec0be1b1a  lea r14, [rax+0x128]
000075aec0be1b21  mov r11, [r13+r14*1]
000075aec0be1b26  movq xmm1, r12
000075aec0be1b2b  movq xmm15, r11
000075aec0be1b30  movq xmm1, xmm1
000075aec0be1b34  movq xmm1, xmm1
000075aec0be1b38  movaps [r15+0x1C0], xmm1
000075aec0be1b40  movq xmm15, xmm15
000075aec0be1b45  movq xmm15, xmm15
000075aec0be1b4a  movaps [r15+0x1B0], xmm15
000075aec0be1b52  lea r14, [rax+0x110]
000075aec0be1b59  mov r12, [r13+r14*1]
000075aec0be1b5e  lea r14, [rax+0x118]
000075aec0be1b65  mov r11, [r13+r14*1]
000075aec0be1b6a  movq xmm1, r12
000075aec0be1b6f  movq xmm15, r11
000075aec0be1b74  movq xmm1, xmm1
000075aec0be1b78  movq xmm1, xmm1
000075aec0be1b7c  movaps [r15+0x1E0], xmm1
000075aec0be1b84  movq xmm15, xmm15
000075aec0be1b89  movq xmm15, xmm15
000075aec0be1b8e  movaps [r15+0x1D0], xmm15
000075aec0be1b96  lea r14, [rax+0x100]
000075aec0be1b9d  mov r12, [r13+r14*1]
000075aec0be1ba2  lea r14, [rax+0x108]
000075aec0be1ba9  mov r11, [r13+r14*1]
000075aec0be1bae  movq xmm1, r12
000075aec0be1bb3  movq xmm15, r11
000075aec0be1bb8  movq xmm1, xmm1
000075aec0be1bbc  movq xmm1, xmm1
000075aec0be1bc0  movaps [r15+0x200], xmm1
000075aec0be1bc8  movq xmm15, xmm15
000075aec0be1bcd  movq xmm15, xmm15
000075aec0be1bd2  movaps [r15+0x1F0], xmm15
000075aec0be1bda  mov qword ptr [r15+0x40], 0x430000
000075aec0be1be2  mov r14d, 0x430510
000075aec0be1be8  mov r12, [r13+r14*1]
000075aec0be1bed  movq xmm1, r12
000075aec0be1bf2  lea r14, [rax+0x150]
000075aec0be1bf9  mov [r15+0xF8], r14
000075aec0be1c00  mov rax, [r15+0x50]
000075aec0be1c04  movups xmm15, [r13+rax*1]
000075aec0be1c0a  movaps [r15+0x120], xmm15
000075aec0be1c12  mov qword ptr [r15+0x48], 0x10
000075aec0be1c1a  xor eax, eax
000075aec0be1c1c  mov r14d, 0x10
000075aec0be1c22  mov r12d, 0x200
000075aec0be1c28  cmp r14, r12
000075aec0be1c2b  cmc
000075aec0be1c2c  lahf
000075aec0be1c2d  seto al
000075aec0be1c30  mov [r15+0x108], eax
000075aec0be1c37  pextrq rax, xmm15, 0x01
000075aec0be1c3e  movq xmm14, rax
000075aec0be1c43  movaps [r15+0x130], xmm14
000075aec0be1c4b  movq rax, xmm1
000075aec0be1c50  movq r14, xmm15
000075aec0be1c55  vmovq xmm1, rax
000075aec0be1c5a  vmovq xmm15, r14
000075aec0be1c5f  movaps xmm13, xmm1
000075aec0be1c63  addsd xmm13, xmm15
000075aec0be1c68  ucomisd xmm13, xmm13
000075aec0be1c6d  jp 0x000075AEC0BE1D86
000075aec0be1c73  movq xmm13, xmm13
000075aec0be1c78  movq rax, xmm13
000075aec0be1c7d  movq r14, xmm14
000075aec0be1c82  vmovq xmm1, rax
000075aec0be1c87  vmovq xmm15, r14
000075aec0be1c8c  movaps xmm14, xmm1
000075aec0be1c90  addsd xmm14, xmm15
000075aec0be1c95  ucomisd xmm14, xmm14
000075aec0be1c9a  jp 0x000075AEC0BE1DCE
000075aec0be1ca0  movq xmm14, xmm14
000075aec0be1ca5  movaps [r15+0x110], xmm14
000075aec0be1cad  mov eax, [r15+0x108]
000075aec0be1cb4  sahf
000075aec0be1cb5  jnz 0x000075AEC0BE1CE7
000075aec0be1cb7  cmp dword ptr [r15+0x318], 0x00
000075aec0be1cbf  jz 0x000075AEC0BE1FE0
000075aec0be1cc5  nop [rax+rax*1], ax
000075aec0be1cce  nop [rax+rax*1], eax
000075aec0be1cd6  mov eax, 0x410490
000075aec0be1cdb  mov [r15+0x100], rax
000075aec0be1ce2  jmp 0x000075AEC09FE110
000075aec0be1ce7  cmp dword ptr [r15+0x318], 0x00
000075aec0be1cef  jz 0x000075AEC0BE1E20
000075aec0be1cf5  nop [rax+rax*1], ax
000075aec0be1cfe  nop [rax+rax*1], eax
000075aec0be1d06  mov eax, 0x410474
000075aec0be1d0b  mov [r15+0x100], rax
000075aec0be1d12  jmp 0x000075AEC09FE110
000075aec0be1d17  int3
000075aec0be1d18  call 0x000075AEC0AE27E0
000075aec0be1d1d  jmp 0x000075AEC0BE1AC3
000075aec0be1d22  call 0x000075AEC0AE27E0
000075aec0be1d27  jmp 0x000075AEC0BE1AD6
000075aec0be1d2c  call 0x000075AEC0AE1570
000075aec0be1d31  jmp 0x000075AEC0BE1AE2
000075aec0be1d36  call 0x000075AEC0AE27E0
000075aec0be1d3b  jmp 0x000075AEC0BE1B1A
000075aec0be1d40  call 0x000075AEC0AE1570
000075aec0be1d45  jmp 0x000075AEC0BE1B26
000075aec0be1d4a  call 0x000075AEC0AE27E0
000075aec0be1d4f  jmp 0x000075AEC0BE1B5E
000075aec0be1d54  call 0x000075AEC0AE1570
000075aec0be1d59  jmp 0x000075AEC0BE1B6A
000075aec0be1d5e  call 0x000075AEC0AE27E0
000075aec0be1d63  jmp 0x000075AEC0BE1BA2
000075aec0be1d68  call 0x000075AEC0AE1570
000075aec0be1d6d  jmp 0x000075AEC0BE1BAE
000075aec0be1d72  call 0x000075AEC0AE27E0
000075aec0be1d77  jmp 0x000075AEC0BE1BED
000075aec0be1d7c  call 0x000075AEC0A0E760
000075aec0be1d81  jmp 0x000075AEC0BE1C0A
000075aec0be1d86  ucomisd xmm1, xmm15
000075aec0be1d8b  jp 0x000075AEC0BE1D9A
000075aec0be1d8d  movaps xmm13, [0x000075AEC07FE060]
000075aec0be1d95  jmp 0x000075AEC0BE1C73
000075aec0be1d9a  vxorps xmm0, xmm1, xmm15
000075aec0be1d9f  pextrw eax, xmm0, 0x03
000075aec0be1da4  and eax, 0x7FF8
000075aec0be1da9  cmp eax, 0x08
000075aec0be1dac  jnz 0x000075AEC0BE1C73
000075aec0be1db2  movq rax, xmm15
000075aec0be1db7  shl rax, 0x0D
000075aec0be1dbb  jbe 0x000075AEC0BE1C73
000075aec0be1dc1  vorps xmm13, xmm15, [0x000075AEC07FE070]
000075aec0be1dc9  jmp 0x000075AEC0BE1C73
000075aec0be1dce  ucomisd xmm1, xmm15
000075aec0be1dd3  jp 0x000075AEC0BE1DE2
000075aec0be1dd5  movaps xmm14, [0x000075AEC07FE060]
000075aec0be1ddd  jmp 0x000075AEC0BE1CA0
000075aec0be1de2  vxorps xmm0, xmm1, xmm15
000075aec0be1de7  pextrw eax, xmm0, 0x03
000075aec0be1dec  and eax, 0x7FF8
000075aec0be1df1  cmp eax, 0x08
000075aec0be1df4  jnz 0x000075AEC0BE1CA0
000075aec0be1dfa  movq rax, xmm15
000075aec0be1dff  shl rax, 0x0D
000075aec0be1e03  jbe 0x000075AEC0BE1CA0
000075aec0be1e09  vorps xmm14, xmm15, [0x000075AEC07FE070]
000075aec0be1e11  jmp 0x000075AEC0BE1CA0
000075aec0be1e16  int3
000075aec0be1e17  nop [rax+rax*1], ax
000075aec0be1e20  mov rax, [r15+0x48]
000075aec0be1e24  mov r14, [r15+0x50]
000075aec0be1e28  lea r12, [r14+rax*1]
000075aec0be1e2c  movups xmm1, [r13+r12*1]
000075aec0be1e32  movaps [r15+0x120], xmm1
000075aec0be1e3a  lea r14, [rax+0x10]
000075aec0be1e3e  mov [r15+0x48], r14
000075aec0be1e42  xor eax, eax
000075aec0be1e44  mov r12d, 0x200
000075aec0be1e4a  cmp r14, r12
000075aec0be1e4d  cmc
000075aec0be1e4e  lahf
000075aec0be1e4f  seto al
000075aec0be1e52  mov [r15+0x108], eax
000075aec0be1e59  pextrq rax, xmm1, 0x01
000075aec0be1e60  movq xmm15, rax
000075aec0be1e65  movaps [r15+0x130], xmm15
000075aec0be1e6d  movaps xmm14, [r15+0x110]
000075aec0be1e75  movq rax, xmm14
000075aec0be1e7a  movq r14, xmm1
000075aec0be1e7f  vmovq xmm1, rax
000075aec0be1e84  vmovq xmm14, r14
000075aec0be1e89  movaps xmm13, xmm1
000075aec0be1e8d  addsd xmm13, xmm14
000075aec0be1e92  ucomisd xmm13, xmm13
000075aec0be1e97  jp 0x000075AEC0BE1F4C
000075aec0be1e9d  movq xmm13, xmm13
000075aec0be1ea2  movq rax, xmm13
000075aec0be1ea7  movq r14, xmm15
000075aec0be1eac  vmovq xmm1, rax
000075aec0be1eb1  vmovq xmm15, r14
000075aec0be1eb6  movaps xmm14, xmm1
000075aec0be1eba  addsd xmm14, xmm15
000075aec0be1ebf  ucomisd xmm14, xmm14
000075aec0be1ec4  jp 0x000075AEC0BE1F94
000075aec0be1eca  movq xmm14, xmm14
000075aec0be1ecf  movaps [r15+0x110], xmm14
000075aec0be1ed7  mov eax, [r15+0x108]
000075aec0be1ede  sahf
000075aec0be1edf  jnz 0x000075AEC0BE1F11
000075aec0be1ee1  cmp dword ptr [r15+0x318], 0x00
000075aec0be1ee9  jz 0x000075AEC0BE1FE0
000075aec0be1eef  nop [rax+rax*1], ax
000075aec0be1ef8  nop [rax+rax*1], eax
000075aec0be1f00  mov eax, 0x410490
000075aec0be1f05  mov [r15+0x100], rax
000075aec0be1f0c  jmp 0x000075AEC09FE110
000075aec0be1f11  cmp dword ptr [r15+0x318], 0x00
000075aec0be1f19  jz 0x000075AEC0BE1E20
000075aec0be1f1f  nop [rax+rax*1], ax
000075aec0be1f28  nop [rax+rax*1], eax
000075aec0be1f30  mov eax, 0x410474
000075aec0be1f35  mov [r15+0x100], rax
000075aec0be1f3c  jmp 0x000075AEC09FE110
000075aec0be1f41  int3
000075aec0be1f42  call 0x000075AEC0AB52F0
000075aec0be1f47  jmp 0x000075AEC0BE1E32
000075aec0be1f4c  ucomisd xmm1, xmm14
000075aec0be1f51  jp 0x000075AEC0BE1F60
000075aec0be1f53  movaps xmm13, [0x000075AEC07FE060]
000075aec0be1f5b  jmp 0x000075AEC0BE1E9D
000075aec0be1f60  vxorps xmm0, xmm1, xmm14
000075aec0be1f65  pextrw eax, xmm0, 0x03
000075aec0be1f6a  and eax, 0x7FF8
000075aec0be1f6f  cmp eax, 0x08
000075aec0be1f72  jnz 0x000075AEC0BE1E9D
000075aec0be1f78  movq rax, xmm14
000075aec0be1f7d  shl rax, 0x0D
000075aec0be1f81  jbe 0x000075AEC0BE1E9D
000075aec0be1f87  vorps xmm13, xmm14, [0x000075AEC07FE070]
000075aec0be1f8f  jmp 0x000075AEC0BE1E9D
000075aec0be1f94  ucomisd xmm1, xmm15
000075aec0be1f99  jp 0x000075AEC0BE1FA8
000075aec0be1f9b  movaps xmm14, [0x000075AEC07FE060]
000075aec0be1fa3  jmp 0x000075AEC0BE1ECA
000075aec0be1fa8  vxorps xmm0, xmm1, xmm15
000075aec0be1fad  pextrw eax, xmm0, 0x03
000075aec0be1fb2  and eax, 0x7FF8
000075aec0be1fb7  cmp eax, 0x08
000075aec0be1fba  jnz 0x000075AEC0BE1ECA
000075aec0be1fc0  movq rax, xmm15
000075aec0be1fc5  shl rax, 0x0D
000075aec0be1fc9  jbe 0x000075AEC0BE1ECA
000075aec0be1fcf  vorps xmm14, xmm15, [0x000075AEC07FE070]
000075aec0be1fd7  jmp 0x000075AEC0BE1ECA
000075aec0be1fdc  int3
000075aec0be1fdd  nop [rax], eax
000075aec0be1fe0  mov rax, [r15+0x40]
000075aec0be1fe4  lea r14, [rax+0x510]
000075aec0be1feb  movaps xmm1, [r15+0x110]
000075aec0be1ff3  movq rax, xmm1
000075aec0be1ff8  mov [r13+r14*1], rax
000075aec0be1ffd  mov rax, [r15+0xF0]
000075aec0be2004  mov [r15+0x100], rax
000075aec0be200b  jmp 0x000075AEC0BCE5C0
000075aec0be2010  int3
000075aec0be2011  call 0x000075AEC0AD5EB0
000075aec0be2016  jmp 0x000075AEC0BE1FFD
000075aec0be201b  int3
000075aec0be201c  nop [rax], eax
000075aec0be2020  mov qword ptr [r15+0x100], 0x04
000075aec0be202b  mov esi, 0x00
000075aec0be2030  mov edx, 0x09
000075aec0be2035  mov rdi, 0x7FFF3EF60DE0
000075aec0be203f  mov rax, 0x57F4B3079970
000075aec0be2049  call rax
000075aec0be204b  cmp dword ptr [r15+0x318], 0x00
000075aec0be2053  jnz 0x000075AEC09FE110
000075aec0be2059  jmp 0x000075AEC09FE0A0
000075aec0be205e  int3
000075aec0be205f  int3
