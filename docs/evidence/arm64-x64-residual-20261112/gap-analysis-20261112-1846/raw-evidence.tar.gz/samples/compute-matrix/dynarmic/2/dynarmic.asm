00007f4e3fdce69b  nop [rax+rax*1], eax
00007f4e3fdce6a0  vmovaps xmm1, [0x00007F4E3F9FE010]
00007f4e3fdce6a8  movq xmm1, xmm1
00007f4e3fdce6ac  movaps [r15+0x110], xmm1
00007f4e3fdce6b4  vmovaps xmm1, [0x00007F4E3F9FE020]
00007f4e3fdce6bc  movq xmm1, xmm1
00007f4e3fdce6c0  movaps [r15+0x120], xmm1
00007f4e3fdce6c8  mov eax, 0x4204C0
00007f4e3fdce6cd  mov r14, [r13+rax*1]
00007f4e3fdce6d2  movq xmm1, r14
00007f4e3fdce6d7  movaps [r15+0x130], xmm1
00007f4e3fdce6df  vmovaps xmm1, [0x00007F4E3F9FE030]
00007f4e3fdce6e7  vpbroadcastq xmm1, xmm1
00007f4e3fdce6ec  movaps [r15+0x140], xmm1
00007f4e3fdce6f4  mov qword ptr [r15+0x40], 0x02
00007f4e3fdce6fc  vmovaps xmm15, [0x00007F4E3F9FE040]
00007f4e3fdce704  movq xmm15, xmm15
00007f4e3fdce709  movaps [r15+0x150], xmm15
00007f4e3fdce711  mov qword ptr [r15+0x58], 0x420000
00007f4e3fdce719  vmovaps xmm15, [0x00007F4E3F9FE050]
00007f4e3fdce721  vpbroadcastq xmm15, xmm15
00007f4e3fdce726  movaps [r15+0x160], xmm15
00007f4e3fdce72e  mov rax, [r15+0x40]
00007f4e3fdce732  vmovq xmm14, rax
00007f4e3fdce737  vpbroadcastq xmm14, xmm14
00007f4e3fdce73c  movaps [r15+0x170], xmm14
00007f4e3fdce744  mov eax, 0x4204D0
00007f4e3fdce749  movups xmm13, [r13+rax*1]
00007f4e3fdce74f  mov qword ptr [r15+0x40], 0x430518
00007f4e3fdce757  mov qword ptr [r15+0x50], 0x430720
00007f4e3fdce75f  vpmovqd xmm12, xmm13
00007f4e3fdce765  pxor xmm11, xmm11
00007f4e3fdce76a  punpcklqdq xmm12, xmm11
00007f4e3fdce76f  movaps [r15+0x210], xmm12
00007f4e3fdce777  movq xmm12, qword ptr [r15+0x120]
00007f4e3fdce780  movq xmm11, qword ptr [r15+0x130]
00007f4e3fdce789  psubd xmm12, xmm11
00007f4e3fdce78e  movq xmm12, xmm12
00007f4e3fdce793  paddq xmm13, xmm14
00007f4e3fdce798  movaps [r15+0x180], xmm13
00007f4e3fdce7a0  movq xmm14, qword ptr [r15+0x150]
00007f4e3fdce7a9  paddd xmm11, xmm14
00007f4e3fdce7ae  movq xmm11, xmm11
00007f4e3fdce7b3  movq xmm11, xmm11
00007f4e3fdce7b8  movaps [r15+0x130], xmm11
00007f4e3fdce7c0  pmovzxdq xmm12, xmm12
00007f4e3fdce7c6  psllq xmm12, 0x00
00007f4e3fdce7cc  movq xmm14, qword ptr [r15+0x210]
00007f4e3fdce7d5  movq xmm13, qword ptr [r15+0x110]
00007f4e3fdce7de  paddd xmm14, xmm13
00007f4e3fdce7e3  movq xmm14, xmm14
00007f4e3fdce7e8  vcvtuqq2pd xmm12, xmm12
00007f4e3fdce7ee  pmovzxdq xmm14, xmm14
00007f4e3fdce7f4  psllq xmm14, 0x00
00007f4e3fdce7fa  vcvtuqq2pd xmm14, xmm14
00007f4e3fdce800  movaps xmm13, xmm12
00007f4e3fdce804  mulpd xmm13, xmm1
00007f4e3fdce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f4e3fdce80f  ptest xmm11, xmm11
00007f4e3fdce815  jnz 0x00007F4E3FDCE8FF
00007f4e3fdce81b  movaps [r15+0x220], xmm13
00007f4e3fdce823  mov eax, 0x430720
00007f4e3fdce828  movups [r13+rax*1], xmm13
00007f4e3fdce82e  movaps xmm1, xmm14
00007f4e3fdce832  mulpd xmm1, xmm15
00007f4e3fdce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f4e3fdce83c  ptest xmm13, xmm13
00007f4e3fdce842  jnz 0x00007F4E3FDCEA4C
00007f4e3fdce848  movaps [r15+0x210], xmm1
00007f4e3fdce850  mov eax, 0x430518
00007f4e3fdce855  movups [r13+rax*1], xmm1
00007f4e3fdce85b  mov qword ptr [r15+0x48], 0x10
00007f4e3fdce863  xor eax, eax
00007f4e3fdce865  mov r14d, 0x10
00007f4e3fdce86b  mov r12d, 0x200
00007f4e3fdce871  cmp r14, r12
00007f4e3fdce874  cmc
00007f4e3fdce875  lahf
00007f4e3fdce876  seto al
00007f4e3fdce879  mov [r15+0x108], eax
00007f4e3fdce880  mov eax, [r15+0x108]
00007f4e3fdce887  sahf
00007f4e3fdce888  jnz 0x00007F4E3FDCE8BA
00007f4e3fdce88a  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdce892  jz 0x00007F4E3FDCEFF0
00007f4e3fdce898  nop [rax+rax*1], ax
00007f4e3fdce8a1  nop [rax+rax*1], eax
00007f4e3fdce8a9  mov eax, 0x4101EC
00007f4e3fdce8ae  mov [r15+0x100], rax
00007f4e3fdce8b5  jmp 0x00007F4E3FBFE110
00007f4e3fdce8ba  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdce8c2  jz 0x00007F4E3FDCEBA0
00007f4e3fdce8c8  nop [rax+rax*1], ax
00007f4e3fdce8d1  nop [rax+rax*1], eax
00007f4e3fdce8d9  mov eax, 0x4101AC
00007f4e3fdce8de  mov [r15+0x100], rax
00007f4e3fdce8e5  jmp 0x00007F4E3FBFE110
00007f4e3fdce8ea  int3
00007f4e3fdce8eb  call 0x00007F4E3FC0DC20
00007f4e3fdce8f0  jmp 0x00007F4E3FDCE6D2
00007f4e3fdce8f5  call 0x00007F4E3FC0C260
00007f4e3fdce8fa  jmp 0x00007F4E3FDCE74F
00007f4e3fdce8ff  sub rsp, 0x08
00007f4e3fdce903  push rax
00007f4e3fdce904  push rcx
00007f4e3fdce905  push rdx
00007f4e3fdce906  push rdi
00007f4e3fdce907  push rsi
00007f4e3fdce908  push r8
00007f4e3fdce90a  push r9
00007f4e3fdce90c  push r10
00007f4e3fdce90e  push r11
00007f4e3fdce910  sub rsp, 0xF0
00007f4e3fdce917  vmovaps [rsp], xmm0
00007f4e3fdce91c  vmovaps [rsp+0x10], xmm1
00007f4e3fdce922  vmovaps [rsp+0x20], xmm2
00007f4e3fdce928  vmovaps [rsp+0x30], xmm3
00007f4e3fdce92e  vmovaps [rsp+0x40], xmm4
00007f4e3fdce934  vmovaps [rsp+0x50], xmm5
00007f4e3fdce93a  vmovaps [rsp+0x60], xmm6
00007f4e3fdce940  vmovaps [rsp+0x70], xmm7
00007f4e3fdce946  vmovaps [rsp+0x80], xmm8
00007f4e3fdce94f  vmovaps [rsp+0x90], xmm9
00007f4e3fdce958  vmovaps [rsp+0xA0], xmm10
00007f4e3fdce961  vmovaps [rsp+0xB0], xmm11
00007f4e3fdce96a  vmovaps [rsp+0xC0], xmm12
00007f4e3fdce973  vmovaps [rsp+0xD0], xmm14
00007f4e3fdce97c  vmovaps [rsp+0xE0], xmm15
00007f4e3fdce985  sub rsp, 0x30
00007f4e3fdce989  movaps [rsp], xmm13
00007f4e3fdce98e  movaps [rsp+0x10], xmm12
00007f4e3fdce994  movaps [rsp+0x20], xmm1
00007f4e3fdce999  lea rdi, [rsp]
00007f4e3fdce99d  mov esi, 0x00
00007f4e3fdce9a2  mov rax, 0x5D97141E9530
00007f4e3fdce9ac  call rax
00007f4e3fdce9ae  movaps xmm13, [rsp]
00007f4e3fdce9b3  add rsp, 0x30
00007f4e3fdce9b7  vmovaps xmm0, [rsp]
00007f4e3fdce9bc  vmovaps xmm1, [rsp+0x10]
00007f4e3fdce9c2  vmovaps xmm2, [rsp+0x20]
00007f4e3fdce9c8  vmovaps xmm3, [rsp+0x30]
00007f4e3fdce9ce  vmovaps xmm4, [rsp+0x40]
00007f4e3fdce9d4  vmovaps xmm5, [rsp+0x50]
00007f4e3fdce9da  vmovaps xmm6, [rsp+0x60]
00007f4e3fdce9e0  vmovaps xmm7, [rsp+0x70]
00007f4e3fdce9e6  vmovaps xmm8, [rsp+0x80]
00007f4e3fdce9ef  vmovaps xmm9, [rsp+0x90]
00007f4e3fdce9f8  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdcea01  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdcea0a  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdcea13  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdcea1c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdcea25  add rsp, 0xF0
00007f4e3fdcea2c  pop r11
00007f4e3fdcea2e  pop r10
00007f4e3fdcea30  pop r9
00007f4e3fdcea32  pop r8
00007f4e3fdcea34  pop rsi
00007f4e3fdcea35  pop rdi
00007f4e3fdcea36  pop rdx
00007f4e3fdcea37  pop rcx
00007f4e3fdcea38  pop rax
00007f4e3fdcea39  add rsp, 0x08
00007f4e3fdcea3d  jmp 0x00007F4E3FDCE81B
00007f4e3fdcea42  call 0x00007F4E3FC0C380
00007f4e3fdcea47  jmp 0x00007F4E3FDCE82E
00007f4e3fdcea4c  sub rsp, 0x08
00007f4e3fdcea50  push rax
00007f4e3fdcea51  push rcx
00007f4e3fdcea52  push rdx
00007f4e3fdcea53  push rdi
00007f4e3fdcea54  push rsi
00007f4e3fdcea55  push r8
00007f4e3fdcea57  push r9
00007f4e3fdcea59  push r10
00007f4e3fdcea5b  push r11
00007f4e3fdcea5d  sub rsp, 0xF0
00007f4e3fdcea64  vmovaps [rsp], xmm0
00007f4e3fdcea69  vmovaps [rsp+0x10], xmm2
00007f4e3fdcea6f  vmovaps [rsp+0x20], xmm3
00007f4e3fdcea75  vmovaps [rsp+0x30], xmm4
00007f4e3fdcea7b  vmovaps [rsp+0x40], xmm5
00007f4e3fdcea81  vmovaps [rsp+0x50], xmm6
00007f4e3fdcea87  vmovaps [rsp+0x60], xmm7
00007f4e3fdcea8d  vmovaps [rsp+0x70], xmm8
00007f4e3fdcea93  vmovaps [rsp+0x80], xmm9
00007f4e3fdcea9c  vmovaps [rsp+0x90], xmm10
00007f4e3fdceaa5  vmovaps [rsp+0xA0], xmm11
00007f4e3fdceaae  vmovaps [rsp+0xB0], xmm12
00007f4e3fdceab7  vmovaps [rsp+0xC0], xmm13
00007f4e3fdceac0  vmovaps [rsp+0xD0], xmm14
00007f4e3fdceac9  vmovaps [rsp+0xE0], xmm15
00007f4e3fdcead2  sub rsp, 0x30
00007f4e3fdcead6  movaps [rsp], xmm1
00007f4e3fdceada  movaps [rsp+0x10], xmm14
00007f4e3fdceae0  movaps [rsp+0x20], xmm15
00007f4e3fdceae6  lea rdi, [rsp]
00007f4e3fdceaea  mov esi, 0x00
00007f4e3fdceaef  mov rax, 0x5D97141E9530
00007f4e3fdceaf9  call rax
00007f4e3fdceafb  movaps xmm1, [rsp]
00007f4e3fdceaff  add rsp, 0x30
00007f4e3fdceb03  vmovaps xmm0, [rsp]
00007f4e3fdceb08  vmovaps xmm2, [rsp+0x10]
00007f4e3fdceb0e  vmovaps xmm3, [rsp+0x20]
00007f4e3fdceb14  vmovaps xmm4, [rsp+0x30]
00007f4e3fdceb1a  vmovaps xmm5, [rsp+0x40]
00007f4e3fdceb20  vmovaps xmm6, [rsp+0x50]
00007f4e3fdceb26  vmovaps xmm7, [rsp+0x60]
00007f4e3fdceb2c  vmovaps xmm8, [rsp+0x70]
00007f4e3fdceb32  vmovaps xmm9, [rsp+0x80]
00007f4e3fdceb3b  vmovaps xmm10, [rsp+0x90]
00007f4e3fdceb44  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdceb4d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdceb56  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdceb5f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdceb68  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdceb71  add rsp, 0xF0
00007f4e3fdceb78  pop r11
00007f4e3fdceb7a  pop r10
00007f4e3fdceb7c  pop r9
00007f4e3fdceb7e  pop r8
00007f4e3fdceb80  pop rsi
00007f4e3fdceb81  pop rdi
00007f4e3fdceb82  pop rdx
00007f4e3fdceb83  pop rcx
00007f4e3fdceb84  pop rax
00007f4e3fdceb85  add rsp, 0x08
00007f4e3fdceb89  jmp 0x00007F4E3FDCE848
00007f4e3fdceb8e  call 0x00007F4E3FBFF540
00007f4e3fdceb93  jmp 0x00007F4E3FDCE85B
00007f4e3fdceb98  int3
00007f4e3fdceb99  nop [rax], eax
00007f4e3fdceba0  movaps xmm1, [r15+0x180]
00007f4e3fdceba8  vpmovqd xmm15, xmm1
00007f4e3fdcebae  pxor xmm14, xmm14
00007f4e3fdcebb3  punpcklqdq xmm15, xmm14
00007f4e3fdcebb8  movaps [r15+0x210], xmm15
00007f4e3fdcebc0  movq xmm15, qword ptr [r15+0x120]
00007f4e3fdcebc9  movq xmm14, qword ptr [r15+0x130]
00007f4e3fdcebd2  psubd xmm15, xmm14
00007f4e3fdcebd7  movq xmm15, xmm15
00007f4e3fdcebdc  movaps xmm13, [r15+0x170]
00007f4e3fdcebe4  paddq xmm1, xmm13
00007f4e3fdcebe9  movaps [r15+0x180], xmm1
00007f4e3fdcebf1  movq xmm1, qword ptr [r15+0x150]
00007f4e3fdcebfa  paddd xmm14, xmm1
00007f4e3fdcebff  movq xmm14, xmm14
00007f4e3fdcec04  movq xmm14, xmm14
00007f4e3fdcec09  movaps [r15+0x130], xmm14
00007f4e3fdcec11  pmovzxdq xmm15, xmm15
00007f4e3fdcec17  psllq xmm15, 0x00
00007f4e3fdcec1d  movq xmm1, qword ptr [r15+0x210]
00007f4e3fdcec26  movq xmm14, qword ptr [r15+0x110]
00007f4e3fdcec2f  paddd xmm1, xmm14
00007f4e3fdcec34  movq xmm1, xmm1
00007f4e3fdcec38  vcvtuqq2pd xmm15, xmm15
00007f4e3fdcec3e  pmovzxdq xmm1, xmm1
00007f4e3fdcec43  psllq xmm1, 0x00
00007f4e3fdcec48  vcvtuqq2pd xmm1, xmm1
00007f4e3fdcec4e  movaps xmm14, [r15+0x140]
00007f4e3fdcec56  movaps xmm13, xmm15
00007f4e3fdcec5a  mulpd xmm13, xmm14
00007f4e3fdcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4e3fdcec65  ptest xmm12, xmm12
00007f4e3fdcec6b  jnz 0x00007F4E3FDCED4E
00007f4e3fdcec71  movaps [r15+0x220], xmm13
00007f4e3fdcec79  mov rax, [r15+0x48]
00007f4e3fdcec7d  mov r14, [r15+0x50]
00007f4e3fdcec81  lea r12, [r14+rax*1]
00007f4e3fdcec85  movups [r13+r12*1], xmm13
00007f4e3fdcec8b  movaps xmm15, [r15+0x160]
00007f4e3fdcec93  movaps xmm14, xmm1
00007f4e3fdcec97  mulpd xmm14, xmm15
00007f4e3fdcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f4e3fdceca2  ptest xmm13, xmm13
00007f4e3fdceca8  jnz 0x00007F4E3FDCEE9C
00007f4e3fdcecae  movaps [r15+0x210], xmm14
00007f4e3fdcecb6  mov r14, [r15+0x40]
00007f4e3fdcecba  lea r12, [r14+rax*1]
00007f4e3fdcecbe  movups [r13+r12*1], xmm14
00007f4e3fdcecc4  lea r14, [rax+0x10]
00007f4e3fdcecc8  mov [r15+0x48], r14
00007f4e3fdceccc  xor eax, eax
00007f4e3fdcecce  mov r12d, 0x200
00007f4e3fdcecd4  cmp r14, r12
00007f4e3fdcecd7  cmc
00007f4e3fdcecd8  lahf
00007f4e3fdcecd9  seto al
00007f4e3fdcecdc  mov [r15+0x108], eax
00007f4e3fdcece3  mov eax, [r15+0x108]
00007f4e3fdcecea  sahf
00007f4e3fdceceb  jnz 0x00007F4E3FDCED1D
00007f4e3fdceced  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdcecf5  jz 0x00007F4E3FDCEFF0
00007f4e3fdcecfb  nop [rax+rax*1], ax
00007f4e3fdced04  nop [rax+rax*1], eax
00007f4e3fdced0c  mov eax, 0x4101EC
00007f4e3fdced11  mov [r15+0x100], rax
00007f4e3fdced18  jmp 0x00007F4E3FBFE110
00007f4e3fdced1d  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdced25  jz 0x00007F4E3FDCEBA0
00007f4e3fdced2b  nop [rax+rax*1], ax
00007f4e3fdced34  nop [rax+rax*1], eax
00007f4e3fdced3c  mov eax, 0x4101AC
00007f4e3fdced41  mov [r15+0x100], rax
00007f4e3fdced48  jmp 0x00007F4E3FBFE110
00007f4e3fdced4d  int3
00007f4e3fdced4e  sub rsp, 0x08
00007f4e3fdced52  push rax
00007f4e3fdced53  push rcx
00007f4e3fdced54  push rdx
00007f4e3fdced55  push rdi
00007f4e3fdced56  push rsi
00007f4e3fdced57  push r8
00007f4e3fdced59  push r9
00007f4e3fdced5b  push r10
00007f4e3fdced5d  push r11
00007f4e3fdced5f  sub rsp, 0xF0
00007f4e3fdced66  vmovaps [rsp], xmm0
00007f4e3fdced6b  vmovaps [rsp+0x10], xmm1
00007f4e3fdced71  vmovaps [rsp+0x20], xmm2
00007f4e3fdced77  vmovaps [rsp+0x30], xmm3
00007f4e3fdced7d  vmovaps [rsp+0x40], xmm4
00007f4e3fdced83  vmovaps [rsp+0x50], xmm5
00007f4e3fdced89  vmovaps [rsp+0x60], xmm6
00007f4e3fdced8f  vmovaps [rsp+0x70], xmm7
00007f4e3fdced95  vmovaps [rsp+0x80], xmm8
00007f4e3fdced9e  vmovaps [rsp+0x90], xmm9
00007f4e3fdceda7  vmovaps [rsp+0xA0], xmm10
00007f4e3fdcedb0  vmovaps [rsp+0xB0], xmm11
00007f4e3fdcedb9  vmovaps [rsp+0xC0], xmm12
00007f4e3fdcedc2  vmovaps [rsp+0xD0], xmm14
00007f4e3fdcedcb  vmovaps [rsp+0xE0], xmm15
00007f4e3fdcedd4  sub rsp, 0x30
00007f4e3fdcedd8  movaps [rsp], xmm13
00007f4e3fdceddd  movaps [rsp+0x10], xmm15
00007f4e3fdcede3  movaps [rsp+0x20], xmm14
00007f4e3fdcede9  lea rdi, [rsp]
00007f4e3fdceded  mov esi, 0x00
00007f4e3fdcedf2  mov rax, 0x5D97141E9530
00007f4e3fdcedfc  call rax
00007f4e3fdcedfe  movaps xmm13, [rsp]
00007f4e3fdcee03  add rsp, 0x30
00007f4e3fdcee07  vmovaps xmm0, [rsp]
00007f4e3fdcee0c  vmovaps xmm1, [rsp+0x10]
00007f4e3fdcee12  vmovaps xmm2, [rsp+0x20]
00007f4e3fdcee18  vmovaps xmm3, [rsp+0x30]
00007f4e3fdcee1e  vmovaps xmm4, [rsp+0x40]
00007f4e3fdcee24  vmovaps xmm5, [rsp+0x50]
00007f4e3fdcee2a  vmovaps xmm6, [rsp+0x60]
00007f4e3fdcee30  vmovaps xmm7, [rsp+0x70]
00007f4e3fdcee36  vmovaps xmm8, [rsp+0x80]
00007f4e3fdcee3f  vmovaps xmm9, [rsp+0x90]
00007f4e3fdcee48  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdcee51  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdcee5a  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdcee63  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdcee6c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdcee75  add rsp, 0xF0
00007f4e3fdcee7c  pop r11
00007f4e3fdcee7e  pop r10
00007f4e3fdcee80  pop r9
00007f4e3fdcee82  pop r8
00007f4e3fdcee84  pop rsi
00007f4e3fdcee85  pop rdi
00007f4e3fdcee86  pop rdx
00007f4e3fdcee87  pop rcx
00007f4e3fdcee88  pop rax
00007f4e3fdcee89  add rsp, 0x08
00007f4e3fdcee8d  jmp 0x00007F4E3FDCEC71
00007f4e3fdcee92  call 0x00007F4E3FCC2240
00007f4e3fdcee97  jmp 0x00007F4E3FDCEC8B
00007f4e3fdcee9c  sub rsp, 0x08
00007f4e3fdceea0  push rax
00007f4e3fdceea1  push rcx
00007f4e3fdceea2  push rdx
00007f4e3fdceea3  push rdi
00007f4e3fdceea4  push rsi
00007f4e3fdceea5  push r8
00007f4e3fdceea7  push r9
00007f4e3fdceea9  push r10
00007f4e3fdceeab  push r11
00007f4e3fdceead  sub rsp, 0xF0
00007f4e3fdceeb4  vmovaps [rsp], xmm0
00007f4e3fdceeb9  vmovaps [rsp+0x10], xmm1
00007f4e3fdceebf  vmovaps [rsp+0x20], xmm2
00007f4e3fdceec5  vmovaps [rsp+0x30], xmm3
00007f4e3fdceecb  vmovaps [rsp+0x40], xmm4
00007f4e3fdceed1  vmovaps [rsp+0x50], xmm5
00007f4e3fdceed7  vmovaps [rsp+0x60], xmm6
00007f4e3fdceedd  vmovaps [rsp+0x70], xmm7
00007f4e3fdceee3  vmovaps [rsp+0x80], xmm8
00007f4e3fdceeec  vmovaps [rsp+0x90], xmm9
00007f4e3fdceef5  vmovaps [rsp+0xA0], xmm10
00007f4e3fdceefe  vmovaps [rsp+0xB0], xmm11
00007f4e3fdcef07  vmovaps [rsp+0xC0], xmm12
00007f4e3fdcef10  vmovaps [rsp+0xD0], xmm13
00007f4e3fdcef19  vmovaps [rsp+0xE0], xmm15
00007f4e3fdcef22  sub rsp, 0x30
00007f4e3fdcef26  movaps [rsp], xmm14
00007f4e3fdcef2b  movaps [rsp+0x10], xmm1
00007f4e3fdcef30  movaps [rsp+0x20], xmm15
00007f4e3fdcef36  lea rdi, [rsp]
00007f4e3fdcef3a  mov esi, 0x00
00007f4e3fdcef3f  mov rax, 0x5D97141E9530
00007f4e3fdcef49  call rax
00007f4e3fdcef4b  movaps xmm14, [rsp]
00007f4e3fdcef50  add rsp, 0x30
00007f4e3fdcef54  vmovaps xmm0, [rsp]
00007f4e3fdcef59  vmovaps xmm1, [rsp+0x10]
00007f4e3fdcef5f  vmovaps xmm2, [rsp+0x20]
00007f4e3fdcef65  vmovaps xmm3, [rsp+0x30]
00007f4e3fdcef6b  vmovaps xmm4, [rsp+0x40]
00007f4e3fdcef71  vmovaps xmm5, [rsp+0x50]
00007f4e3fdcef77  vmovaps xmm6, [rsp+0x60]
00007f4e3fdcef7d  vmovaps xmm7, [rsp+0x70]
00007f4e3fdcef83  vmovaps xmm8, [rsp+0x80]
00007f4e3fdcef8c  vmovaps xmm9, [rsp+0x90]
00007f4e3fdcef95  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdcef9e  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdcefa7  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdcefb0  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdcefb9  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdcefc2  add rsp, 0xF0
00007f4e3fdcefc9  pop r11
00007f4e3fdcefcb  pop r10
00007f4e3fdcefcd  pop r9
00007f4e3fdcefcf  pop r8
00007f4e3fdcefd1  pop rsi
00007f4e3fdcefd2  pop rdi
00007f4e3fdcefd3  pop rdx
00007f4e3fdcefd4  pop rcx
00007f4e3fdcefd5  pop rax
00007f4e3fdcefd6  add rsp, 0x08
00007f4e3fdcefda  jmp 0x00007F4E3FDCECAE
00007f4e3fdcefdf  call 0x00007F4E3FCC34C0
00007f4e3fdcefe4  jmp 0x00007F4E3FDCECC4
00007f4e3fdcefe9  int3
00007f4e3fdcefea  nop [rax+rax*1], ax
00007f4e3fdceff0  mov rax, [r15+0xF8]
00007f4e3fdceff7  lea r14, [rax-0x150]
00007f4e3fdceffe  mov [r15+0xF8], r14
00007f4e3fdcf005  mov rax, [r15+0x50]
00007f4e3fdcf009  lea r12, [rax+0x80]
00007f4e3fdcf010  movups xmm1, [r13+r12*1]
00007f4e3fdcf016  lea r12, [rax+0x90]
00007f4e3fdcf01d  movups xmm15, [r13+r12*1]
00007f4e3fdcf023  mov qword ptr [r15+0x48], 0x00
00007f4e3fdcf02b  lea r12, [rax+0x40]
00007f4e3fdcf02f  movups xmm14, [r13+r12*1]
00007f4e3fdcf035  lea r12, [rax+0x50]
00007f4e3fdcf039  movups xmm13, [r13+r12*1]
00007f4e3fdcf03f  lea r12, [r14+0x120]
00007f4e3fdcf046  movq xmm12, qword ptr [r15+0x1C0]
00007f4e3fdcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f4e3fdcf058  movq r11, xmm12
00007f4e3fdcf05d  movq r10, xmm11
00007f4e3fdcf062  mov [r13+r12*1], r11
00007f4e3fdcf067  lea r12, [r14+0x128]
00007f4e3fdcf06e  mov [r13+r12*1], r10
00007f4e3fdcf073  vxorps xmm12, xmm12, xmm12
00007f4e3fdcf078  vpbroadcastq xmm12, xmm12
00007f4e3fdcf07d  lea r12, [r14+0x100]
00007f4e3fdcf084  movq xmm11, qword ptr [r15+0x200]
00007f4e3fdcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f4e3fdcf096  movq r11, xmm11
00007f4e3fdcf09b  movq r10, xmm10
00007f4e3fdcf0a0  mov [r13+r12*1], r11
00007f4e3fdcf0a5  lea r12, [r14+0x108]
00007f4e3fdcf0ac  mov [r13+r12*1], r10
00007f4e3fdcf0b1  lea r12, [r14+0xE0]
00007f4e3fdcf0b8  movups [r13+r12*1], xmm15
00007f4e3fdcf0be  lea r12, [r14+0xF0]
00007f4e3fdcf0c5  movups [r13+r12*1], xmm1
00007f4e3fdcf0cb  lea r12, [rax+0xC0]
00007f4e3fdcf0d2  movups xmm1, [r13+r12*1]
00007f4e3fdcf0d8  lea r12, [rax+0xD0]
00007f4e3fdcf0df  movups xmm15, [r13+r12*1]
00007f4e3fdcf0e5  lea r12, [r14+0x110]
00007f4e3fdcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f4e3fdcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f4e3fdcf0fe  movq r11, xmm11
00007f4e3fdcf103  movq r10, xmm10
00007f4e3fdcf108  mov [r13+r12*1], r11
00007f4e3fdcf10d  lea r12, [r14+0x118]
00007f4e3fdcf114  mov [r13+r12*1], r10
00007f4e3fdcf119  movups xmm11, [r13+rax*1]
00007f4e3fdcf11f  lea r12, [rax+0x10]
00007f4e3fdcf123  movups xmm10, [r13+r12*1]
00007f4e3fdcf129  lea r12, [r14+0x130]
00007f4e3fdcf130  movq xmm9, qword ptr [r15+0x1A0]
00007f4e3fdcf139  movq xmm8, qword ptr [r15+0x190]
00007f4e3fdcf142  movq r11, xmm9
00007f4e3fdcf147  movq r10, xmm8
00007f4e3fdcf14c  mov [r13+r12*1], r11
00007f4e3fdcf151  lea r12, [r14+0x138]
00007f4e3fdcf158  mov [r13+r12*1], r10
00007f4e3fdcf15d  lea r12, [rax+0x140]
00007f4e3fdcf164  movups xmm9, [r13+r12*1]
00007f4e3fdcf16a  lea r12, [rax+0x150]
00007f4e3fdcf171  movups xmm8, [r13+r12*1]
00007f4e3fdcf177  lea r12, [r14+0xC0]
00007f4e3fdcf17e  movups [r13+r12*1], xmm15
00007f4e3fdcf184  lea r12, [r14+0xD0]
00007f4e3fdcf18b  movups [r13+r12*1], xmm1
00007f4e3fdcf191  lea r12, [rax+0x100]
00007f4e3fdcf198  movups xmm1, [r13+r12*1]
00007f4e3fdcf19e  lea r12, [rax+0x110]
00007f4e3fdcf1a5  movups xmm15, [r13+r12*1]
00007f4e3fdcf1ab  lea r12, [r14+0x140]
00007f4e3fdcf1b2  mov r11, [r15+0xE8]
00007f4e3fdcf1b9  mov [r13+r12*1], r11
00007f4e3fdcf1be  lea r12, [rax+0x180]
00007f4e3fdcf1c5  movups xmm7, [r13+r12*1]
00007f4e3fdcf1cb  lea r12, [rax+0x190]
00007f4e3fdcf1d2  movups xmm6, [r13+r12*1]
00007f4e3fdcf1d8  lea r12, [rax+0x1C0]
00007f4e3fdcf1df  movups xmm5, [r13+r12*1]
00007f4e3fdcf1e5  lea r12, [rax+0x1D0]
00007f4e3fdcf1ec  movups xmm4, [r13+r12*1]
00007f4e3fdcf1f2  lea r12, [r14+0x20]
00007f4e3fdcf1f6  movups [r13+r12*1], xmm1
00007f4e3fdcf1fc  lea r12, [r14+0x30]
00007f4e3fdcf200  movups [r13+r12*1], xmm13
00007f4e3fdcf206  lea r12, [rax+0x60]
00007f4e3fdcf20a  movups xmm1, [r13+r12*1]
00007f4e3fdcf210  lea r12, [rax+0x70]
00007f4e3fdcf214  movups xmm13, [r13+r12*1]
00007f4e3fdcf21a  lea r12, [rax+0x20]
00007f4e3fdcf21e  movups xmm3, [r13+r12*1]
00007f4e3fdcf224  lea r12, [rax+0x30]
00007f4e3fdcf228  movups xmm2, [r13+r12*1]
00007f4e3fdcf22e  movaps [r15+0x1F0], xmm2
00007f4e3fdcf236  lea r12, [r14+0x60]
00007f4e3fdcf23a  movups [r13+r12*1], xmm11
00007f4e3fdcf240  lea r12, [r14+0x70]
00007f4e3fdcf244  movups [r13+r12*1], xmm5
00007f4e3fdcf24a  lea r12, [rax+0xE0]
00007f4e3fdcf251  movups xmm11, [r13+r12*1]
00007f4e3fdcf257  lea r12, [rax+0xF0]
00007f4e3fdcf25e  movups xmm5, [r13+r12*1]
00007f4e3fdcf264  lea r12, [r14+0xA0]
00007f4e3fdcf26b  movups [r13+r12*1], xmm13
00007f4e3fdcf271  lea r12, [r14+0xB0]
00007f4e3fdcf278  movups [r13+r12*1], xmm1
00007f4e3fdcf27e  lea r12, [rax+0xA0]
00007f4e3fdcf285  movups xmm1, [r13+r12*1]
00007f4e3fdcf28b  lea r12, [rax+0xB0]
00007f4e3fdcf292  movups xmm13, [r13+r12*1]
00007f4e3fdcf298  lea r12, [rax+0x120]
00007f4e3fdcf29f  vmovaps [rsp+0x10], xmm1
00007f4e3fdcf2a5  movups xmm1, [r13+r12*1]
00007f4e3fdcf2ab  lea r12, [rax+0x130]
00007f4e3fdcf2b2  vmovaps [rsp+0x20], xmm1
00007f4e3fdcf2b8  movups xmm1, [r13+r12*1]
00007f4e3fdcf2be  lea r12, [rax+0x160]
00007f4e3fdcf2c5  vmovaps [rsp+0x30], xmm1
00007f4e3fdcf2cb  movups xmm1, [r13+r12*1]
00007f4e3fdcf2d1  lea r12, [rax+0x170]
00007f4e3fdcf2d8  vmovaps [rsp+0x40], xmm1
00007f4e3fdcf2de  movups xmm1, [r13+r12*1]
00007f4e3fdcf2e4  movaps [r15+0x2B0], xmm1
00007f4e3fdcf2ec  lea r12, [r14+0x80]
00007f4e3fdcf2f3  movups [r13+r12*1], xmm13
00007f4e3fdcf2f9  lea r12, [r14+0x90]
00007f4e3fdcf300  vmovaps xmm13, [rsp+0x10]
00007f4e3fdcf306  movups [r13+r12*1], xmm13
00007f4e3fdcf30c  lea r12, [rax+0x1A0]
00007f4e3fdcf313  movups xmm13, [r13+r12*1]
00007f4e3fdcf319  lea r12, [rax+0x1B0]
00007f4e3fdcf320  vmovaps [rsp+0x10], xmm1
00007f4e3fdcf326  movups xmm1, [r13+r12*1]
00007f4e3fdcf32c  movaps [r15+0x290], xmm13
00007f4e3fdcf334  movaps [r15+0x1E0], xmm1
00007f4e3fdcf33c  lea r12, [rax+0x1E0]
00007f4e3fdcf343  vmovaps [rsp+0x50], xmm1
00007f4e3fdcf349  movups xmm1, [r13+r12*1]
00007f4e3fdcf34f  lea r12, [rax+0x1F0]
00007f4e3fdcf356  vmovaps [rsp+0x60], xmm1
00007f4e3fdcf35c  movups xmm1, [r13+r12*1]
00007f4e3fdcf362  mov qword ptr [r15+0x50], 0x430920
00007f4e3fdcf36a  lea rax, [r14+0x40]
00007f4e3fdcf36e  vmovaps [rsp+0x70], xmm1
00007f4e3fdcf374  vmovaps xmm1, [rsp+0x40]
00007f4e3fdcf37a  movups [r13+rax*1], xmm1
00007f4e3fdcf380  lea rax, [r14+0x50]
00007f4e3fdcf384  movups [r13+rax*1], xmm10
00007f4e3fdcf38a  vmovaps xmm1, [rsp+0x70]
00007f4e3fdcf390  movups [r13+r14*1], xmm1
00007f4e3fdcf396  lea rax, [r14+0x10]
00007f4e3fdcf39a  vmovaps xmm1, [rsp+0x60]
00007f4e3fdcf3a0  movups [r13+rax*1], xmm1
00007f4e3fdcf3a6  mov rax, [r15+0x40]
00007f4e3fdcf3aa  vmovaps [rsp+0x40], xmm3
00007f4e3fdcf3b0  vmovaps xmm1, [rsp+0x40]
00007f4e3fdcf3b6  por xmm3, xmm1
00007f4e3fdcf3ba  vmovaps [rsp+0x40], xmm6
00007f4e3fdcf3c0  vmovaps xmm10, [rsp+0x40]
00007f4e3fdcf3c6  por xmm6, xmm10
00007f4e3fdcf3cb  lea r12, [rax+0x30]
00007f4e3fdcf3cf  mov r11, [r13+r12*1]
00007f4e3fdcf3d4  lea r12, [rax+0x38]
00007f4e3fdcf3d8  mov r10, [r13+r12*1]
00007f4e3fdcf3dd  movq xmm10, r11
00007f4e3fdcf3e2  vmovaps [rsp+0x40], xmm1
00007f4e3fdcf3e8  movq xmm1, r10
00007f4e3fdcf3ed  movq xmm10, xmm10
00007f4e3fdcf3f2  vmovaps [rsp+0x60], xmm10
00007f4e3fdcf3f8  movq xmm10, xmm10
00007f4e3fdcf3fd  movaps [r15+0x130], xmm10
00007f4e3fdcf405  movq xmm1, xmm1
00007f4e3fdcf409  vmovaps [rsp+0x70], xmm1
00007f4e3fdcf40f  movq xmm1, xmm1
00007f4e3fdcf413  movaps [r15+0x280], xmm1
00007f4e3fdcf41b  vmovaps [rsp+0x80], xmm9
00007f4e3fdcf424  vmovaps xmm1, [rsp+0x80]
00007f4e3fdcf42d  por xmm9, xmm1
00007f4e3fdcf432  lea r12, [rax+0x20]
00007f4e3fdcf436  mov r11, [r13+r12*1]
00007f4e3fdcf43b  lea r12, [rax+0x28]
00007f4e3fdcf43f  mov r10, [r13+r12*1]
00007f4e3fdcf444  movq xmm1, r11
00007f4e3fdcf449  movq xmm10, r10
00007f4e3fdcf44e  movq xmm1, xmm1
00007f4e3fdcf452  vmovaps [rsp+0x80], xmm1
00007f4e3fdcf45b  movq xmm1, xmm1
00007f4e3fdcf45f  movaps [r15+0x150], xmm1
00007f4e3fdcf467  movq xmm10, xmm10
00007f4e3fdcf46c  vmovaps [rsp+0x90], xmm10
00007f4e3fdcf475  movq xmm10, xmm10
00007f4e3fdcf47a  movaps [r15+0x140], xmm10
00007f4e3fdcf482  lea r12, [rax+0x10]
00007f4e3fdcf486  mov r11, [r13+r12*1]
00007f4e3fdcf48b  lea r12, [rax+0x18]
00007f4e3fdcf48f  mov r10, [r13+r12*1]
00007f4e3fdcf494  movq xmm1, r11
00007f4e3fdcf499  movq xmm10, r10
00007f4e3fdcf49e  movq xmm1, xmm1
00007f4e3fdcf4a2  vmovaps [rsp+0xA0], xmm1
00007f4e3fdcf4ab  movq xmm1, xmm1
00007f4e3fdcf4af  movaps [r15+0x170], xmm1
00007f4e3fdcf4b7  movq xmm10, xmm10
00007f4e3fdcf4bc  vmovaps [rsp+0xB0], xmm10
00007f4e3fdcf4c5  movq xmm10, xmm10
00007f4e3fdcf4ca  movaps [r15+0x160], xmm10
00007f4e3fdcf4d2  mov r12, [r13+rax*1]
00007f4e3fdcf4d7  vmovq xmm1, r12
00007f4e3fdcf4dc  vpbroadcastq xmm1, xmm1
00007f4e3fdcf4e1  lea r12, [rax+0x08]
00007f4e3fdcf4e5  mov rax, [r13+r12*1]
00007f4e3fdcf4ea  movq xmm10, rax
00007f4e3fdcf4ef  movaps [r15+0x230], xmm10
00007f4e3fdcf4f7  lea rax, [r14+0x50]
00007f4e3fdcf4fb  movups xmm10, [r13+rax*1]
00007f4e3fdcf501  lea rax, [r14+0x60]
00007f4e3fdcf505  vmovaps [rsp+0xC0], xmm1
00007f4e3fdcf50e  movups xmm1, [r13+rax*1]
00007f4e3fdcf514  lea rax, [r14+0x30]
00007f4e3fdcf518  vmovaps [rsp+0xD0], xmm1
00007f4e3fdcf521  movups xmm1, [r13+rax*1]
00007f4e3fdcf527  mov qword ptr [r15+0x60], 0x430920
00007f4e3fdcf52f  mov qword ptr [r15+0x58], 0x40
00007f4e3fdcf537  vmovaps [rsp+0xE0], xmm1
00007f4e3fdcf540  vmovaps [rsp+0xF0], xmm15
00007f4e3fdcf549  vmovaps xmm15, [rsp+0xC0]
00007f4e3fdcf552  vmovaps [rsp+0xC0], xmm14
00007f4e3fdcf55b  vmovaps xmm14, [rsp+0x40]
00007f4e3fdcf561  vmovaps [rsp+0x40], xmm13
00007f4e3fdcf567  movaps xmm1, xmm15
00007f4e3fdcf56b  mulpd xmm1, xmm14
00007f4e3fdcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f4e3fdcf575  ptest xmm13, xmm13
00007f4e3fdcf57b  jnz 0x00007F4E3FDD0682
00007f4e3fdcf581  movq xmm14, qword ptr [r15+0x230]
00007f4e3fdcf58a  vmovaps [rsp+0x100], xmm14
00007f4e3fdcf593  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdcf599  vmovaps [rsp+0x110], xmm1
00007f4e3fdcf5a2  vmovaps xmm1, [rsp+0xE0]
00007f4e3fdcf5ab  vmovaps [rsp+0xE0], xmm15
00007f4e3fdcf5b4  movaps xmm13, xmm1
00007f4e3fdcf5b8  mulpd xmm13, xmm14
00007f4e3fdcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f4e3fdcf5c3  ptest xmm15, xmm15
00007f4e3fdcf5c9  jnz 0x00007F4E3FDD07C4
00007f4e3fdcf5cf  vxorps xmm1, xmm1, xmm1
00007f4e3fdcf5d3  vpbroadcastq xmm1, xmm1
00007f4e3fdcf5d8  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdcf5e1  vmovaps [rsp+0xE0], xmm1
00007f4e3fdcf5ea  vmovaps xmm1, [rsp+0xD0]
00007f4e3fdcf5f3  vmovaps [rsp+0xD0], xmm13
00007f4e3fdcf5fc  movaps xmm15, xmm14
00007f4e3fdcf600  mulpd xmm15, xmm1
00007f4e3fdcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f4e3fdcf60b  ptest xmm13, xmm13
00007f4e3fdcf611  jnz 0x00007F4E3FDD0907
00007f4e3fdcf617  movaps xmm1, xmm14
00007f4e3fdcf61b  mulpd xmm1, xmm10
00007f4e3fdcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f4e3fdcf625  ptest xmm13, xmm13
00007f4e3fdcf62b  jnz 0x00007F4E3FDD0A4A
00007f4e3fdcf631  movaps xmm13, xmm14
00007f4e3fdcf635  mulpd xmm13, xmm2
00007f4e3fdcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f4e3fdcf640  ptest xmm10, xmm10
00007f4e3fdcf646  jnz 0x00007F4E3FDD0B8C
00007f4e3fdcf64c  vmovaps [rsp+0x120], xmm7
00007f4e3fdcf655  vmovaps xmm14, [rsp+0x120]
00007f4e3fdcf65e  por xmm7, xmm14
00007f4e3fdcf663  vmovaps xmm14, [rsp+0xC0]
00007f4e3fdcf66c  vmovaps xmm10, [rsp+0xC0]
00007f4e3fdcf675  por xmm14, xmm10
00007f4e3fdcf67a  vmovaps xmm2, [rsp+0x100]
00007f4e3fdcf683  vpermilpd xmm2, xmm2, 0x00
00007f4e3fdcf689  vmovaps [rsp+0xC0], xmm1
00007f4e3fdcf692  vmovaps [rsp+0x120], xmm15
00007f4e3fdcf69b  movaps xmm1, xmm10
00007f4e3fdcf69f  mulpd xmm1, xmm2
00007f4e3fdcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f4e3fdcf6a8  ptest xmm15, xmm15
00007f4e3fdcf6ae  jnz 0x00007F4E3FDD0CCF
00007f4e3fdcf6b4  xor eax, eax
00007f4e3fdcf6b6  mov r12d, 0x40
00007f4e3fdcf6bc  mov r11d, 0x200
00007f4e3fdcf6c2  cmp r12, r11
00007f4e3fdcf6c5  cmc
00007f4e3fdcf6c6  lahf
00007f4e3fdcf6c7  seto al
00007f4e3fdcf6ca  mov [r15+0x108], eax
00007f4e3fdcf6d1  vmovaps xmm10, [rsp+0x110]
00007f4e3fdcf6da  vmovaps xmm2, [rsp+0xE0]
00007f4e3fdcf6e3  vmovaps [rsp+0xE0], xmm1
00007f4e3fdcf6ec  movaps xmm15, xmm10
00007f4e3fdcf6f0  addpd xmm15, xmm2
00007f4e3fdcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fdcf6fb  ptest xmm1, xmm1
00007f4e3fdcf700  jnz 0x00007F4E3FDD0E10
00007f4e3fdcf706  vmovaps xmm10, [rsp+0x120]
00007f4e3fdcf70f  vmovaps [rsp+0x110], xmm15
00007f4e3fdcf718  movaps xmm1, xmm10
00007f4e3fdcf71c  addpd xmm1, xmm12
00007f4e3fdcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f4e3fdcf726  ptest xmm15, xmm15
00007f4e3fdcf72c  jnz 0x00007F4E3FDD0F53
00007f4e3fdcf732  vmovaps xmm10, [rsp+0xC0]
00007f4e3fdcf73b  vmovaps [rsp+0xC0], xmm1
00007f4e3fdcf744  movaps xmm15, xmm10
00007f4e3fdcf748  addpd xmm15, xmm12
00007f4e3fdcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fdcf753  ptest xmm1, xmm1
00007f4e3fdcf758  jnz 0x00007F4E3FDD1095
00007f4e3fdcf75e  vmovaps xmm1, [rsp+0x30]
00007f4e3fdcf764  vmovaps xmm12, [rsp+0x30]
00007f4e3fdcf76a  por xmm1, xmm12
00007f4e3fdcf76f  vmovaps xmm12, [rsp+0x20]
00007f4e3fdcf775  vmovaps xmm10, [rsp+0x20]
00007f4e3fdcf77b  por xmm12, xmm10
00007f4e3fdcf780  vmovaps [rsp+0x20], xmm5
00007f4e3fdcf786  vmovaps xmm10, [rsp+0x20]
00007f4e3fdcf78c  por xmm5, xmm10
00007f4e3fdcf791  vmovaps [rsp+0x20], xmm11
00007f4e3fdcf797  vmovaps xmm10, [rsp+0x20]
00007f4e3fdcf79d  por xmm11, xmm10
00007f4e3fdcf7a2  vmovaps [rsp+0x20], xmm4
00007f4e3fdcf7a8  vmovaps xmm10, [rsp+0x20]
00007f4e3fdcf7ae  por xmm4, xmm10
00007f4e3fdcf7b3  vmovaps [rsp+0x20], xmm8
00007f4e3fdcf7b9  vmovaps xmm10, [rsp+0x20]
00007f4e3fdcf7bf  por xmm8, xmm10
00007f4e3fdcf7c4  vmovaps xmm10, [rsp+0xF0]
00007f4e3fdcf7cd  vmovaps [rsp+0x20], xmm1
00007f4e3fdcf7d3  vmovaps xmm1, [rsp+0xF0]
00007f4e3fdcf7dc  por xmm10, xmm1
00007f4e3fdcf7e1  lea rax, [r14+0xA0]
00007f4e3fdcf7e8  movups xmm1, [r13+rax*1]
00007f4e3fdcf7ee  lea rax, [r14+0xB0]
00007f4e3fdcf7f5  vmovaps [rsp+0x30], xmm1
00007f4e3fdcf7fb  movups xmm1, [r13+rax*1]
00007f4e3fdcf801  vmovaps [rsp+0xF0], xmm1
00007f4e3fdcf80a  vmovaps [rsp+0x120], xmm15
00007f4e3fdcf813  movaps xmm1, xmm13
00007f4e3fdcf817  addpd xmm1, xmm2
00007f4e3fdcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f4e3fdcf820  ptest xmm15, xmm15
00007f4e3fdcf826  jnz 0x00007F4E3FDD11ED
00007f4e3fdcf82c  lea rax, [r14+0xF0]
00007f4e3fdcf833  movups xmm15, [r13+rax*1]
00007f4e3fdcf839  vmovaps xmm2, [rsp+0xC0]
00007f4e3fdcf842  vmovaps [rsp+0xC0], xmm1
00007f4e3fdcf84b  vmovaps xmm1, [rsp+0xE0]
00007f4e3fdcf854  vmovaps [rsp+0xE0], xmm15
00007f4e3fdcf85d  movaps xmm13, xmm2
00007f4e3fdcf861  addpd xmm13, xmm1
00007f4e3fdcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f4e3fdcf86c  ptest xmm15, xmm15
00007f4e3fdcf872  jnz 0x00007F4E3FDD1338
00007f4e3fdcf878  vmovaps xmm15, [rsp+0x120]
00007f4e3fdcf881  vmovaps xmm2, [rsp+0xD0]
00007f4e3fdcf88a  vmovaps [rsp+0xD0], xmm14
00007f4e3fdcf893  movaps xmm1, xmm15
00007f4e3fdcf897  addpd xmm1, xmm2
00007f4e3fdcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f4e3fdcf8a0  ptest xmm14, xmm14
00007f4e3fdcf8a6  jnz 0x00007F4E3FDD147A
00007f4e3fdcf8ac  vmovaps xmm15, [rsp+0x100]
00007f4e3fdcf8b5  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdcf8bb  vmovaps xmm2, [rsp+0xF0]
00007f4e3fdcf8c4  vmovaps [rsp+0xF0], xmm1
00007f4e3fdcf8cd  movaps xmm14, xmm2
00007f4e3fdcf8d1  mulpd xmm14, xmm15
00007f4e3fdcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f4e3fdcf8dc  ptest xmm1, xmm1
00007f4e3fdcf8e1  jnz 0x00007F4E3FDD15BB
00007f4e3fdcf8e7  vmovaps xmm1, [rsp+0xA0]
00007f4e3fdcf8f0  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdcf8f6  vmovaps xmm2, [rsp+0xE0]
00007f4e3fdcf8ff  vmovaps [rsp+0xE0], xmm14
00007f4e3fdcf908  movaps xmm15, xmm2
00007f4e3fdcf90c  mulpd xmm15, xmm1
00007f4e3fdcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f4e3fdcf917  ptest xmm14, xmm14
00007f4e3fdcf91d  jnz 0x00007F4E3FDD16FE
00007f4e3fdcf923  lea rax, [r14+0xE0]
00007f4e3fdcf92a  movups xmm1, [r13+rax*1]
00007f4e3fdcf930  vmovaps xmm14, [rsp+0x100]
00007f4e3fdcf939  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdcf93f  vmovaps [rsp+0x100], xmm1
00007f4e3fdcf948  vmovaps xmm1, [rsp+0x30]
00007f4e3fdcf94e  vmovaps [rsp+0x30], xmm15
00007f4e3fdcf954  movaps xmm2, xmm1
00007f4e3fdcf957  mulpd xmm2, xmm14
00007f4e3fdcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f4e3fdcf961  ptest xmm15, xmm15
00007f4e3fdcf967  jnz 0x00007F4E3FDD184A
00007f4e3fdcf96d  vmovaps [rsp+0x120], xmm10
00007f4e3fdcf976  vmovaps xmm1, [rsp+0x120]
00007f4e3fdcf97f  por xmm10, xmm1
00007f4e3fdcf984  movaps [r15+0x300], xmm10
00007f4e3fdcf98c  vmovaps [rsp+0x120], xmm8
00007f4e3fdcf995  vmovaps xmm1, [rsp+0x120]
00007f4e3fdcf99e  por xmm8, xmm1
00007f4e3fdcf9a3  movaps [r15+0x190], xmm8
00007f4e3fdcf9ab  vmovaps xmm1, [rsp+0xA0]
00007f4e3fdcf9b4  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdcf9ba  vmovaps xmm14, [rsp+0x100]
00007f4e3fdcf9c3  vmovaps [rsp+0x100], xmm13
00007f4e3fdcf9cc  movaps xmm15, xmm14
00007f4e3fdcf9d0  mulpd xmm15, xmm1
00007f4e3fdcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f4e3fdcf9db  ptest xmm13, xmm13
00007f4e3fdcf9e1  jnz 0x00007F4E3FDD198B
00007f4e3fdcf9e7  lea rax, [r14+0x90]
00007f4e3fdcf9ee  movups xmm1, [r13+rax*1]
00007f4e3fdcf9f4  vmovaps [rsp+0x120], xmm4
00007f4e3fdcf9fd  vmovaps xmm14, [rsp+0x120]
00007f4e3fdcfa06  por xmm4, xmm14
00007f4e3fdcfa0b  movaps [r15+0x1C0], xmm4
00007f4e3fdcfa13  vmovaps [rsp+0x120], xmm11
00007f4e3fdcfa1c  vmovaps xmm14, [rsp+0x120]
00007f4e3fdcfa25  por xmm11, xmm14
00007f4e3fdcfa2a  movaps [r15+0x200], xmm11
00007f4e3fdcfa32  vmovaps [rsp+0x120], xmm5
00007f4e3fdcfa3b  vmovaps xmm14, [rsp+0x120]
00007f4e3fdcfa44  por xmm5, xmm14
00007f4e3fdcfa49  movaps [r15+0x2D0], xmm5
00007f4e3fdcfa51  vmovaps [rsp+0x120], xmm12
00007f4e3fdcfa5a  vmovaps xmm14, [rsp+0x120]
00007f4e3fdcfa63  por xmm12, xmm14
00007f4e3fdcfa68  movaps [r15+0x2E0], xmm12
00007f4e3fdcfa70  vmovaps xmm13, [rsp+0x110]
00007f4e3fdcfa79  vmovaps [rsp+0x110], xmm1
00007f4e3fdcfa82  vmovaps xmm1, [rsp+0xE0]
00007f4e3fdcfa8b  vmovaps [rsp+0xE0], xmm15
00007f4e3fdcfa94  movaps xmm14, xmm13
00007f4e3fdcfa98  addpd xmm14, xmm1
00007f4e3fdcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f4e3fdcfaa3  ptest xmm15, xmm15
00007f4e3fdcfaa9  jnz 0x00007F4E3FDD1AD8
00007f4e3fdcfaaf  vmovaps xmm1, [rsp+0xA0]
00007f4e3fdcfab8  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdcfabe  vmovaps xmm13, [rsp+0x110]
00007f4e3fdcfac7  vmovaps [rsp+0x110], xmm14
00007f4e3fdcfad0  movaps xmm15, xmm13
00007f4e3fdcfad4  mulpd xmm15, xmm1
00007f4e3fdcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f4e3fdcfadf  ptest xmm14, xmm14
00007f4e3fdcfae5  jnz 0x00007F4E3FDD1C1B
00007f4e3fdcfaeb  lea rax, [r14+0x80]
00007f4e3fdcfaf2  movups xmm1, [r13+rax*1]
00007f4e3fdcfaf8  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdcfb01  vmovaps [rsp+0xC0], xmm1
00007f4e3fdcfb0a  movaps xmm14, xmm13
00007f4e3fdcfb0e  addpd xmm14, xmm2
00007f4e3fdcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f4e3fdcfb19  ptest xmm1, xmm1
00007f4e3fdcfb1e  jnz 0x00007F4E3FDD1D68
00007f4e3fdcfb24  vmovaps xmm13, [rsp+0x100]
00007f4e3fdcfb2d  vmovaps xmm2, [rsp+0x30]
00007f4e3fdcfb33  vmovaps [rsp+0x30], xmm15
00007f4e3fdcfb39  movaps xmm1, xmm13
00007f4e3fdcfb3d  addpd xmm1, xmm2
00007f4e3fdcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f4e3fdcfb46  ptest xmm15, xmm15
00007f4e3fdcfb4c  jnz 0x00007F4E3FDD1EAB
00007f4e3fdcfb52  vmovaps xmm15, [rsp+0x20]
00007f4e3fdcfb58  vmovaps xmm13, [rsp+0x20]
00007f4e3fdcfb5e  por xmm15, xmm13
00007f4e3fdcfb63  movaps [r15+0x2F0], xmm15
00007f4e3fdcfb6b  vmovaps xmm13, [rsp+0xA0]
00007f4e3fdcfb74  vpermilpd xmm13, xmm13, 0x00
00007f4e3fdcfb7a  vmovaps [rsp+0x20], xmm1
00007f4e3fdcfb80  vmovaps xmm1, [rsp+0xC0]
00007f4e3fdcfb89  vmovaps [rsp+0xA0], xmm15
00007f4e3fdcfb92  movaps xmm2, xmm1
00007f4e3fdcfb95  mulpd xmm2, xmm13
00007f4e3fdcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f4e3fdcfb9f  ptest xmm15, xmm15
00007f4e3fdcfba5  jnz 0x00007F4E3FDD1FEC
00007f4e3fdcfbab  lea rax, [r14+0xD0]
00007f4e3fdcfbb2  movups xmm1, [r13+rax*1]
00007f4e3fdcfbb8  vmovaps xmm13, [rsp+0xF0]
00007f4e3fdcfbc1  vmovaps [rsp+0xC0], xmm1
00007f4e3fdcfbca  vmovaps xmm1, [rsp+0xE0]
00007f4e3fdcfbd3  vmovaps [rsp+0xE0], xmm14
00007f4e3fdcfbdc  movaps xmm15, xmm13
00007f4e3fdcfbe0  addpd xmm15, xmm1
00007f4e3fdcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f4e3fdcfbeb  ptest xmm14, xmm14
00007f4e3fdcfbf1  jnz 0x00007F4E3FDD2137
00007f4e3fdcfbf7  vmovaps xmm1, [rsp+0xB0]
00007f4e3fdcfc00  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdcfc06  movaps xmm14, xmm11
00007f4e3fdcfc0a  mulpd xmm14, xmm1
00007f4e3fdcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f4e3fdcfc15  ptest xmm13, xmm13
00007f4e3fdcfc1b  jnz 0x00007F4E3FDD227A
00007f4e3fdcfc21  movaps [r15+0x260], xmm14
00007f4e3fdcfc29  vxorps xmm1, xmm1, xmm1
00007f4e3fdcfc2d  vpbroadcastq xmm1, xmm1
00007f4e3fdcfc32  movaps [r15+0x1B0], xmm1
00007f4e3fdcfc3a  vmovaps xmm1, [rsp+0xB0]
00007f4e3fdcfc43  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdcfc49  vmovaps xmm11, [rsp+0xC0]
00007f4e3fdcfc52  vmovaps [rsp+0xC0], xmm15
00007f4e3fdcfc5b  movaps xmm13, xmm11
00007f4e3fdcfc5f  mulpd xmm13, xmm1
00007f4e3fdcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f4e3fdcfc6a  ptest xmm15, xmm15
00007f4e3fdcfc70  jnz 0x00007F4E3FDD23BD
00007f4e3fdcfc76  lea rax, [r14+0xC0]
00007f4e3fdcfc7d  movups xmm1, [r13+rax*1]
00007f4e3fdcfc83  vmovaps xmm11, [rsp+0x110]
00007f4e3fdcfc8c  vmovaps [rsp+0xF0], xmm1
00007f4e3fdcfc95  vmovaps xmm1, [rsp+0x30]
00007f4e3fdcfc9b  vmovaps [rsp+0x30], xmm14
00007f4e3fdcfca1  movaps xmm15, xmm11
00007f4e3fdcfca5  addpd xmm15, xmm1
00007f4e3fdcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f4e3fdcfcb0  ptest xmm14, xmm14
00007f4e3fdcfcb6  jnz 0x00007F4E3FDD250A
00007f4e3fdcfcbc  vmovaps [rsp+0x100], xmm9
00007f4e3fdcfcc5  vmovaps xmm1, [rsp+0x100]
00007f4e3fdcfcce  por xmm9, xmm1
00007f4e3fdcfcd3  movaps [r15+0x270], xmm9
00007f4e3fdcfcdb  vmovaps [rsp+0x100], xmm6
00007f4e3fdcfce4  vmovaps xmm1, [rsp+0x100]
00007f4e3fdcfced  por xmm6, xmm1
00007f4e3fdcfcf1  movaps [r15+0x1A0], xmm6
00007f4e3fdcfcf9  vmovaps xmm14, [rsp+0xB0]
00007f4e3fdcfd02  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdcfd08  vmovaps xmm6, [rsp+0xF0]
00007f4e3fdcfd11  vmovaps [rsp+0xF0], xmm1
00007f4e3fdcfd1a  movaps xmm11, xmm6
00007f4e3fdcfd1e  mulpd xmm11, xmm14
00007f4e3fdcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f4e3fdcfd29  ptest xmm1, xmm1
00007f4e3fdcfd2e  jnz 0x00007F4E3FDD264D
00007f4e3fdcfd34  lea rax, [r14+0x20]
00007f4e3fdcfd38  movups xmm1, [r13+rax*1]
00007f4e3fdcfd3e  movaps [r15+0x110], xmm1
00007f4e3fdcfd46  vmovaps xmm6, [rsp+0xE0]
00007f4e3fdcfd4f  vmovaps [rsp+0xE0], xmm1
00007f4e3fdcfd58  movaps xmm14, xmm6
00007f4e3fdcfd5c  addpd xmm14, xmm2
00007f4e3fdcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f4e3fdcfd67  ptest xmm1, xmm1
00007f4e3fdcfd6c  jnz 0x00007F4E3FDD279A
00007f4e3fdcfd72  vmovaps xmm1, [rsp+0xB0]
00007f4e3fdcfd7b  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdcfd81  movaps xmm6, xmm5
00007f4e3fdcfd84  mulpd xmm6, xmm1
00007f4e3fdcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f4e3fdcfd8d  ptest xmm2, xmm2
00007f4e3fdcfd92  jnz 0x00007F4E3FDD28DC
00007f4e3fdcfd98  vmovaps xmm5, [rsp+0x20]
00007f4e3fdcfd9e  movaps xmm1, xmm5
00007f4e3fdcfda1  addpd xmm1, xmm13
00007f4e3fdcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f4e3fdcfdab  ptest xmm2, xmm2
00007f4e3fdcfdb0  jnz 0x00007F4E3FDD2A1C
00007f4e3fdcfdb6  vmovaps xmm13, [rsp+0x80]
00007f4e3fdcfdbf  vpermilpd xmm13, xmm13, 0x00
00007f4e3fdcfdc5  vmovaps xmm2, [rsp+0xE0]
00007f4e3fdcfdce  vmovaps [rsp+0x20], xmm1
00007f4e3fdcfdd4  movaps xmm5, xmm2
00007f4e3fdcfdd7  mulpd xmm5, xmm13
00007f4e3fdcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f4e3fdcfde1  ptest xmm1, xmm1
00007f4e3fdcfde6  jnz 0x00007F4E3FDD2B5D
00007f4e3fdcfdec  vmovaps xmm1, [rsp+0x80]
00007f4e3fdcfdf5  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdcfdfb  movaps xmm13, xmm10
00007f4e3fdcfdff  mulpd xmm13, xmm1
00007f4e3fdcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f4e3fdcfe0a  ptest xmm2, xmm2
00007f4e3fdcfe0f  jnz 0x00007F4E3FDD2C9E
00007f4e3fdcfe15  vmovaps xmm10, [rsp+0x30]
00007f4e3fdcfe1b  movaps xmm1, xmm15
00007f4e3fdcfe1f  addpd xmm1, xmm10
00007f4e3fdcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f4e3fdcfe29  ptest xmm2, xmm2
00007f4e3fdcfe2e  jnz 0x00007F4E3FDD2DE1
00007f4e3fdcfe34  vmovaps xmm10, [rsp+0xC0]
00007f4e3fdcfe3d  movaps xmm15, xmm10
00007f4e3fdcfe41  addpd xmm15, xmm11
00007f4e3fdcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f4e3fdcfe4c  ptest xmm2, xmm2
00007f4e3fdcfe51  jnz 0x00007F4E3FDD2F23
00007f4e3fdcfe57  vmovaps xmm11, [rsp+0x80]
00007f4e3fdcfe60  vpermilpd xmm11, xmm11, 0x00
00007f4e3fdcfe66  movaps xmm10, xmm12
00007f4e3fdcfe6a  mulpd xmm10, xmm11
00007f4e3fdcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f4e3fdcfe75  ptest xmm2, xmm2
00007f4e3fdcfe7a  jnz 0x00007F4E3FDD3067
00007f4e3fdcfe80  vmovaps xmm12, [rsp+0x80]
00007f4e3fdcfe89  vpermilpd xmm12, xmm12, 0x00
00007f4e3fdcfe8f  vmovaps xmm2, [rsp+0xA0]
00007f4e3fdcfe98  vmovaps [rsp+0x30], xmm1
00007f4e3fdcfe9e  movaps xmm11, xmm2
00007f4e3fdcfea2  mulpd xmm11, xmm12
00007f4e3fdcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f4e3fdcfead  ptest xmm1, xmm1
00007f4e3fdcfeb2  jnz 0x00007F4E3FDD31AB
00007f4e3fdcfeb8  movaps xmm1, xmm14
00007f4e3fdcfebc  addpd xmm1, xmm6
00007f4e3fdcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f4e3fdcfec5  ptest xmm12, xmm12
00007f4e3fdcfecb  jnz 0x00007F4E3FDD32EE
00007f4e3fdcfed1  vmovaps xmm12, [rsp+0x20]
00007f4e3fdcfed7  movaps xmm14, xmm12
00007f4e3fdcfedb  addpd xmm14, xmm5
00007f4e3fdcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f4e3fdcfee6  ptest xmm6, xmm6
00007f4e3fdcfeeb  jnz 0x00007F4E3FDD342F
00007f4e3fdcfef1  vmovaps xmm12, [rsp+0x90]
00007f4e3fdcfefa  vpermilpd xmm12, xmm12, 0x00
00007f4e3fdcff00  movaps xmm6, xmm9
00007f4e3fdcff04  mulpd xmm6, xmm12
00007f4e3fdcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f4e3fdcff0e  ptest xmm5, xmm5
00007f4e3fdcff13  jnz 0x00007F4E3FDD3572
00007f4e3fdcff19  movaps xmm12, xmm15
00007f4e3fdcff1d  addpd xmm12, xmm13
00007f4e3fdcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4e3fdcff28  ptest xmm9, xmm9
00007f4e3fdcff2e  jnz 0x00007F4E3FDD36B4
00007f4e3fdcff34  vmovaps xmm13, [rsp+0x30]
00007f4e3fdcff3a  movaps xmm15, xmm13
00007f4e3fdcff3e  addpd xmm15, xmm10
00007f4e3fdcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f4e3fdcff49  ptest xmm9, xmm9
00007f4e3fdcff4f  jnz 0x00007F4E3FDD37F8
00007f4e3fdcff55  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdcff5e  vmovaps xmm10, [rsp+0xD0]
00007f4e3fdcff67  por xmm13, xmm10
00007f4e3fdcff6c  movaps [r15+0x250], xmm13
00007f4e3fdcff74  vmovaps [rsp+0x20], xmm7
00007f4e3fdcff7a  vmovaps xmm13, [rsp+0x20]
00007f4e3fdcff80  por xmm7, xmm13
00007f4e3fdcff85  movaps [r15+0x2A0], xmm7
00007f4e3fdcff8d  vmovaps [rsp+0x20], xmm3
00007f4e3fdcff93  vmovaps xmm13, [rsp+0x20]
00007f4e3fdcff99  por xmm3, xmm13
00007f4e3fdcff9e  movaps [r15+0x1D0], xmm3
00007f4e3fdcffa6  lea rax, [r14+0x40]
00007f4e3fdcffaa  movups xmm13, [r13+rax*1]
00007f4e3fdcffb0  movaps [r15+0x2C0], xmm13
00007f4e3fdcffb8  vmovaps xmm10, [rsp+0x90]
00007f4e3fdcffc1  vpermilpd xmm10, xmm10, 0x00
00007f4e3fdcffc7  movaps xmm9, xmm8
00007f4e3fdcffcb  mulpd xmm9, xmm10
00007f4e3fdcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f4e3fdcffd6  ptest xmm5, xmm5
00007f4e3fdcffdb  jnz 0x00007F4E3FDD3946
00007f4e3fdcffe1  movaps xmm10, xmm1
00007f4e3fdcffe5  addpd xmm10, xmm11
00007f4e3fdcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f4e3fdcfff0  ptest xmm8, xmm8
00007f4e3fdcfff6  jnz 0x00007F4E3FDD3A8A
00007f4e3fdcfffc  movaps xmm1, xmm14
00007f4e3fdd0000  addpd xmm1, xmm6
00007f4e3fdd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f4e3fdd0009  ptest xmm11, xmm11
00007f4e3fdd000f  jnz 0x00007F4E3FDD3BCD
00007f4e3fdd0015  vmovaps xmm14, [rsp+0x90]
00007f4e3fdd001e  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdd0024  movaps xmm11, xmm13
00007f4e3fdd0028  mulpd xmm11, xmm14
00007f4e3fdd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f4e3fdd0033  ptest xmm8, xmm8
00007f4e3fdd0039  jnz 0x00007F4E3FDD3D0E
00007f4e3fdd003f  vmovaps xmm14, [rsp+0x90]
00007f4e3fdd0048  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdd004e  vmovaps xmm8, [rsp+0x10]
00007f4e3fdd0054  movaps xmm13, xmm8
00007f4e3fdd0058  mulpd xmm13, xmm14
00007f4e3fdd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f4e3fdd0063  ptest xmm6, xmm6
00007f4e3fdd0068  jnz 0x00007F4E3FDD3E52
00007f4e3fdd006e  vmovaps xmm14, [rsp+0x60]
00007f4e3fdd0074  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdd007a  movaps xmm8, xmm7
00007f4e3fdd007e  mulpd xmm8, xmm14
00007f4e3fdd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4e3fdd0089  ptest xmm6, xmm6
00007f4e3fdd008e  jnz 0x00007F4E3FDD3F96
00007f4e3fdd0094  movaps xmm14, xmm12
00007f4e3fdd0098  addpd xmm14, xmm9
00007f4e3fdd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f4e3fdd00a3  ptest xmm7, xmm7
00007f4e3fdd00a8  jnz 0x00007F4E3FDD40D9
00007f4e3fdd00ae  vmovaps xmm12, [rsp+0x60]
00007f4e3fdd00b4  vpermilpd xmm12, xmm12, 0x00
00007f4e3fdd00ba  vmovaps xmm7, [rsp+0xF0]
00007f4e3fdd00c3  movaps xmm9, xmm7
00007f4e3fdd00c7  mulpd xmm9, xmm12
00007f4e3fdd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f4e3fdd00d2  ptest xmm6, xmm6
00007f4e3fdd00d7  jnz 0x00007F4E3FDD421D
00007f4e3fdd00dd  movaps xmm12, xmm15
00007f4e3fdd00e1  addpd xmm12, xmm11
00007f4e3fdd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f4e3fdd00ec  ptest xmm7, xmm7
00007f4e3fdd00f1  jnz 0x00007F4E3FDD4360
00007f4e3fdd00f7  vmovaps xmm15, [rsp+0x60]
00007f4e3fdd00fd  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdd0103  vmovaps xmm7, [rsp+0x40]
00007f4e3fdd0109  movaps xmm11, xmm7
00007f4e3fdd010d  mulpd xmm11, xmm15
00007f4e3fdd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f4e3fdd0118  ptest xmm6, xmm6
00007f4e3fdd011d  jnz 0x00007F4E3FDD44A4
00007f4e3fdd0123  movaps xmm15, xmm10
00007f4e3fdd0127  addpd xmm15, xmm13
00007f4e3fdd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f4e3fdd0132  ptest xmm7, xmm7
00007f4e3fdd0137  jnz 0x00007F4E3FDD45E7
00007f4e3fdd013d  vmovaps xmm13, [rsp+0x60]
00007f4e3fdd0143  vpermilpd xmm13, xmm13, 0x00
00007f4e3fdd0149  vmovaps xmm7, [rsp+0x50]
00007f4e3fdd014f  movaps xmm10, xmm7
00007f4e3fdd0153  mulpd xmm10, xmm13
00007f4e3fdd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f4e3fdd015e  ptest xmm6, xmm6
00007f4e3fdd0163  jnz 0x00007F4E3FDD472B
00007f4e3fdd0169  movaps xmm13, xmm1
00007f4e3fdd016d  addpd xmm13, xmm8
00007f4e3fdd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f4e3fdd0178  ptest xmm7, xmm7
00007f4e3fdd017d  jnz 0x00007F4E3FDD486E
00007f4e3fdd0183  lea rax, [r14+0x70]
00007f4e3fdd0187  movups xmm1, [r13+rax*1]
00007f4e3fdd018d  movaps [r15+0x240], xmm1
00007f4e3fdd0195  movaps xmm8, xmm14
00007f4e3fdd0199  addpd xmm8, xmm9
00007f4e3fdd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f4e3fdd01a4  ptest xmm7, xmm7
00007f4e3fdd01a9  jnz 0x00007F4E3FDD49BB
00007f4e3fdd01af  movaps [r15+0x170], xmm8
00007f4e3fdd01b7  vmovaps xmm14, [rsp+0x70]
00007f4e3fdd01bd  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdd01c3  movaps xmm9, xmm1
00007f4e3fdd01c7  mulpd xmm9, xmm14
00007f4e3fdd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f4e3fdd01d2  ptest xmm7, xmm7
00007f4e3fdd01d7  jnz 0x00007F4E3FDD4AFF
00007f4e3fdd01dd  vmovaps xmm1, [rsp+0x70]
00007f4e3fdd01e3  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd01e9  movaps xmm14, xmm4
00007f4e3fdd01ed  mulpd xmm14, xmm1
00007f4e3fdd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f4e3fdd01f8  ptest xmm7, xmm7
00007f4e3fdd01fd  jnz 0x00007F4E3FDD4C42
00007f4e3fdd0203  movaps [r15+0x180], xmm14
00007f4e3fdd020b  movaps xmm1, xmm12
00007f4e3fdd020f  addpd xmm1, xmm11
00007f4e3fdd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f4e3fdd0219  ptest xmm7, xmm7
00007f4e3fdd021e  jnz 0x00007F4E3FDD4D84
00007f4e3fdd0224  movaps [r15+0x210], xmm1
00007f4e3fdd022c  movups xmm12, [r13+r14*1]
00007f4e3fdd0232  lea rax, [r14+0x10]
00007f4e3fdd0236  movups xmm11, [r13+rax*1]
00007f4e3fdd023c  movaps [r15+0x230], xmm11
00007f4e3fdd0244  movaps xmm7, xmm15
00007f4e3fdd0248  addpd xmm7, xmm10
00007f4e3fdd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4e3fdd0252  ptest xmm6, xmm6
00007f4e3fdd0257  jnz 0x00007F4E3FDD4EDA
00007f4e3fdd025d  movaps [r15+0x130], xmm7
00007f4e3fdd0265  vmovaps xmm15, [rsp+0x70]
00007f4e3fdd026b  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdd0271  movaps xmm10, xmm11
00007f4e3fdd0275  mulpd xmm10, xmm15
00007f4e3fdd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f4e3fdd0280  ptest xmm6, xmm6
00007f4e3fdd0285  jnz 0x00007F4E3FDD501C
00007f4e3fdd028b  movaps [r15+0x220], xmm10
00007f4e3fdd0293  vmovaps xmm15, [rsp+0x70]
00007f4e3fdd0299  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdd029f  movaps xmm11, xmm12
00007f4e3fdd02a3  mulpd xmm11, xmm15
00007f4e3fdd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f4e3fdd02ae  ptest xmm6, xmm6
00007f4e3fdd02b3  jnz 0x00007F4E3FDD5160
00007f4e3fdd02b9  movaps xmm15, xmm13
00007f4e3fdd02bd  addpd xmm15, xmm9
00007f4e3fdd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f4e3fdd02c8  ptest xmm12, xmm12
00007f4e3fdd02ce  jnz 0x00007F4E3FDD52A4
00007f4e3fdd02d4  movaps [r15+0x140], xmm15
00007f4e3fdd02dc  movaps xmm13, xmm8
00007f4e3fdd02e0  addpd xmm13, xmm14
00007f4e3fdd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4e3fdd02eb  ptest xmm12, xmm12
00007f4e3fdd02f1  jnz 0x00007F4E3FDD53E8
00007f4e3fdd02f7  movaps [r15+0x150], xmm13
00007f4e3fdd02ff  movaps xmm14, xmm1
00007f4e3fdd0303  addpd xmm14, xmm10
00007f4e3fdd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f4e3fdd030e  ptest xmm12, xmm12
00007f4e3fdd0314  jnz 0x00007F4E3FDD552C
00007f4e3fdd031a  movaps [r15+0x160], xmm14
00007f4e3fdd0322  movaps xmm1, xmm7
00007f4e3fdd0325  addpd xmm1, xmm11
00007f4e3fdd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f4e3fdd032f  ptest xmm12, xmm12
00007f4e3fdd0335  jnz 0x00007F4E3FDD566F
00007f4e3fdd033b  movaps [r15+0x120], xmm1
00007f4e3fdd0343  mov eax, 0x430920
00007f4e3fdd0348  movups [r13+rax*1], xmm15
00007f4e3fdd034e  mov eax, 0x430930
00007f4e3fdd0353  movups [r13+rax*1], xmm13
00007f4e3fdd0359  mov eax, 0x430940
00007f4e3fdd035e  movups [r13+rax*1], xmm14
00007f4e3fdd0364  mov eax, 0x430950
00007f4e3fdd0369  movups [r13+rax*1], xmm1
00007f4e3fdd036f  mov eax, [r15+0x108]
00007f4e3fdd0376  sahf
00007f4e3fdd0377  jnz 0x00007F4E3FDD03A9
00007f4e3fdd0379  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdd0381  jz 0x00007F4E3FDDB900
00007f4e3fdd0387  nop [rax+rax*1], ax
00007f4e3fdd0390  nop [rax+rax*1], eax
00007f4e3fdd0398  mov eax, 0x410444
00007f4e3fdd039d  mov [r15+0x100], rax
00007f4e3fdd03a4  jmp 0x00007F4E3FBFE110
00007f4e3fdd03a9  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdd03b1  jz 0x00007F4E3FDD57E0
00007f4e3fdd03b7  nop [rax+rax*1], ax
00007f4e3fdd03c0  nop [rax+rax*1], eax
00007f4e3fdd03c8  mov eax, 0x410278
00007f4e3fdd03cd  mov [r15+0x100], rax
00007f4e3fdd03d4  jmp 0x00007F4E3FBFE110
00007f4e3fdd03d9  int3
00007f4e3fdd03da  call 0x00007F4E3FCB52F0
00007f4e3fdd03df  jmp 0x00007F4E3FDCF016
00007f4e3fdd03e4  call 0x00007F4E3FCC4620
00007f4e3fdd03e9  jmp 0x00007F4E3FDCF023
00007f4e3fdd03ee  call 0x00007F4E3FCC33A0
00007f4e3fdd03f3  jmp 0x00007F4E3FDCF035
00007f4e3fdd03f8  call 0x00007F4E3FCC2120
00007f4e3fdd03fd  jmp 0x00007F4E3FDCF03F
00007f4e3fdd0402  call 0x00007F4E3FCC0860
00007f4e3fdd0407  jmp 0x00007F4E3FDCF067
00007f4e3fdd040c  call 0x00007F4E3FCBF5F0
00007f4e3fdd0411  jmp 0x00007F4E3FDCF073
00007f4e3fdd0416  call 0x00007F4E3FCC0860
00007f4e3fdd041b  jmp 0x00007F4E3FDCF0A5
00007f4e3fdd0420  call 0x00007F4E3FCBF5F0
00007f4e3fdd0425  jmp 0x00007F4E3FDCF0B1
00007f4e3fdd042a  call 0x00007F4E3FCC4740
00007f4e3fdd042f  jmp 0x00007F4E3FDCF0BE
00007f4e3fdd0434  call 0x00007F4E3FCB5400
00007f4e3fdd0439  jmp 0x00007F4E3FDCF0CB
00007f4e3fdd043e  call 0x00007F4E3FCB52F0
00007f4e3fdd0443  jmp 0x00007F4E3FDCF0D8
00007f4e3fdd0448  call 0x00007F4E3FCC4620
00007f4e3fdd044d  jmp 0x00007F4E3FDCF0E5
00007f4e3fdd0452  call 0x00007F4E3FCC0860
00007f4e3fdd0457  jmp 0x00007F4E3FDCF10D
00007f4e3fdd045c  call 0x00007F4E3FCBF5F0
00007f4e3fdd0461  jmp 0x00007F4E3FDCF119
00007f4e3fdd0466  call 0x00007F4E3FC09D70
00007f4e3fdd046b  jmp 0x00007F4E3FDCF11F
00007f4e3fdd0470  call 0x00007F4E3FCBE9C0
00007f4e3fdd0475  jmp 0x00007F4E3FDCF129
00007f4e3fdd047a  call 0x00007F4E3FCC0860
00007f4e3fdd047f  jmp 0x00007F4E3FDCF151
00007f4e3fdd0484  call 0x00007F4E3FCBF5F0
00007f4e3fdd0489  jmp 0x00007F4E3FDCF15D
00007f4e3fdd048e  call 0x00007F4E3FCBD750
00007f4e3fdd0493  jmp 0x00007F4E3FDCF16A
00007f4e3fdd0498  call 0x00007F4E3FCBC4E0
00007f4e3fdd049d  jmp 0x00007F4E3FDCF177
00007f4e3fdd04a2  call 0x00007F4E3FCC4740
00007f4e3fdd04a7  jmp 0x00007F4E3FDCF184
00007f4e3fdd04ac  call 0x00007F4E3FCB5400
00007f4e3fdd04b1  jmp 0x00007F4E3FDCF191
00007f4e3fdd04b6  call 0x00007F4E3FCB52F0
00007f4e3fdd04bb  jmp 0x00007F4E3FDCF19E
00007f4e3fdd04c0  call 0x00007F4E3FCC4620
00007f4e3fdd04c5  jmp 0x00007F4E3FDCF1AB
00007f4e3fdd04ca  call 0x00007F4E3FCC0860
00007f4e3fdd04cf  jmp 0x00007F4E3FDCF1BE
00007f4e3fdd04d4  call 0x00007F4E3FCBB270
00007f4e3fdd04d9  jmp 0x00007F4E3FDCF1CB
00007f4e3fdd04de  call 0x00007F4E3FCBA000
00007f4e3fdd04e3  jmp 0x00007F4E3FDCF1D8
00007f4e3fdd04e8  call 0x00007F4E3FCB8D90
00007f4e3fdd04ed  jmp 0x00007F4E3FDCF1E5
00007f4e3fdd04f2  call 0x00007F4E3FCB8A20
00007f4e3fdd04f7  jmp 0x00007F4E3FDCF1F2
00007f4e3fdd04fc  call 0x00007F4E3FCB5400
00007f4e3fdd0501  jmp 0x00007F4E3FDCF1FC
00007f4e3fdd0506  call 0x00007F4E3FCC2240
00007f4e3fdd050b  jmp 0x00007F4E3FDCF206
00007f4e3fdd0510  call 0x00007F4E3FCB52F0
00007f4e3fdd0515  jmp 0x00007F4E3FDCF210
00007f4e3fdd051a  call 0x00007F4E3FCC2120
00007f4e3fdd051f  jmp 0x00007F4E3FDCF21A
00007f4e3fdd0524  call 0x00007F4E3FCB77B0
00007f4e3fdd0529  jmp 0x00007F4E3FDCF224
00007f4e3fdd052e  call 0x00007F4E3FCB6550
00007f4e3fdd0533  jmp 0x00007F4E3FDCF22E
00007f4e3fdd0538  call 0x00007F4E3FCBFD50
00007f4e3fdd053d  jmp 0x00007F4E3FDCF240
00007f4e3fdd0542  call 0x00007F4E3FCB8EA0
00007f4e3fdd0547  jmp 0x00007F4E3FDCF24A
00007f4e3fdd054c  call 0x00007F4E3FCBFC30
00007f4e3fdd0551  jmp 0x00007F4E3FDCF257
00007f4e3fdd0556  call 0x00007F4E3FCB8D90
00007f4e3fdd055b  jmp 0x00007F4E3FDCF264
00007f4e3fdd0560  call 0x00007F4E3FCC2240
00007f4e3fdd0565  jmp 0x00007F4E3FDCF271
00007f4e3fdd056a  call 0x00007F4E3FCB5400
00007f4e3fdd056f  jmp 0x00007F4E3FDCF27E
00007f4e3fdd0574  call 0x00007F4E3FCB52F0
00007f4e3fdd0579  jmp 0x00007F4E3FDCF28B
00007f4e3fdd057e  call 0x00007F4E3FCC2120
00007f4e3fdd0583  jmp 0x00007F4E3FDCF298
00007f4e3fdd0588  call 0x00007F4E3FCB52F0
00007f4e3fdd058d  jmp 0x00007F4E3FDCF2AB
00007f4e3fdd0592  call 0x00007F4E3FCB52F0
00007f4e3fdd0597  jmp 0x00007F4E3FDCF2BE
00007f4e3fdd059c  call 0x00007F4E3FCB52F0
00007f4e3fdd05a1  jmp 0x00007F4E3FDCF2D1
00007f4e3fdd05a6  call 0x00007F4E3FCB52F0
00007f4e3fdd05ab  jmp 0x00007F4E3FDCF2E4
00007f4e3fdd05b0  call 0x00007F4E3FCC2240
00007f4e3fdd05b5  jmp 0x00007F4E3FDCF2F9
00007f4e3fdd05ba  call 0x00007F4E3FCC2240
00007f4e3fdd05bf  jmp 0x00007F4E3FDCF30C
00007f4e3fdd05c4  call 0x00007F4E3FCC2120
00007f4e3fdd05c9  jmp 0x00007F4E3FDCF319
00007f4e3fdd05ce  call 0x00007F4E3FCB52F0
00007f4e3fdd05d3  jmp 0x00007F4E3FDCF32C
00007f4e3fdd05d8  call 0x00007F4E3FCB52F0
00007f4e3fdd05dd  jmp 0x00007F4E3FDCF34F
00007f4e3fdd05e2  call 0x00007F4E3FCB52F0
00007f4e3fdd05e7  jmp 0x00007F4E3FDCF362
00007f4e3fdd05ec  call 0x00007F4E3FBFF540
00007f4e3fdd05f1  jmp 0x00007F4E3FDCF380
00007f4e3fdd05f6  call 0x00007F4E3FC08C20
00007f4e3fdd05fb  jmp 0x00007F4E3FDCF38A
00007f4e3fdd0600  call 0x00007F4E3FCD6600
00007f4e3fdd0605  jmp 0x00007F4E3FDCF396
00007f4e3fdd060a  call 0x00007F4E3FBFF540
00007f4e3fdd060f  jmp 0x00007F4E3FDCF3A6
00007f4e3fdd0614  call 0x00007F4E3FCC0370
00007f4e3fdd0619  jmp 0x00007F4E3FDCF3D4
00007f4e3fdd061e  call 0x00007F4E3FCBF100
00007f4e3fdd0623  jmp 0x00007F4E3FDCF3DD
00007f4e3fdd0628  call 0x00007F4E3FCC0370
00007f4e3fdd062d  jmp 0x00007F4E3FDCF43B
00007f4e3fdd0632  call 0x00007F4E3FCBF100
00007f4e3fdd0637  jmp 0x00007F4E3FDCF444
00007f4e3fdd063c  call 0x00007F4E3FCC0370
00007f4e3fdd0641  jmp 0x00007F4E3FDCF48B
00007f4e3fdd0646  call 0x00007F4E3FCBF100
00007f4e3fdd064b  jmp 0x00007F4E3FDCF494
00007f4e3fdd0650  call 0x00007F4E3FC0B720
00007f4e3fdd0655  jmp 0x00007F4E3FDCF4D7
00007f4e3fdd065a  call 0x00007F4E3FCB47C0
00007f4e3fdd065f  jmp 0x00007F4E3FDCF4EA
00007f4e3fdd0664  call 0x00007F4E3FC08B00
00007f4e3fdd0669  jmp 0x00007F4E3FDCF501
00007f4e3fdd066e  call 0x00007F4E3FBFF430
00007f4e3fdd0673  jmp 0x00007F4E3FDCF514
00007f4e3fdd0678  call 0x00007F4E3FBFF430
00007f4e3fdd067d  jmp 0x00007F4E3FDCF527
00007f4e3fdd0682  sub rsp, 0x08
00007f4e3fdd0686  push rax
00007f4e3fdd0687  push rcx
00007f4e3fdd0688  push rdx
00007f4e3fdd0689  push rdi
00007f4e3fdd068a  push rsi
00007f4e3fdd068b  push r8
00007f4e3fdd068d  push r9
00007f4e3fdd068f  push r10
00007f4e3fdd0691  push r11
00007f4e3fdd0693  sub rsp, 0xF0
00007f4e3fdd069a  vmovaps [rsp], xmm0
00007f4e3fdd069f  vmovaps [rsp+0x10], xmm2
00007f4e3fdd06a5  vmovaps [rsp+0x20], xmm3
00007f4e3fdd06ab  vmovaps [rsp+0x30], xmm4
00007f4e3fdd06b1  vmovaps [rsp+0x40], xmm5
00007f4e3fdd06b7  vmovaps [rsp+0x50], xmm6
00007f4e3fdd06bd  vmovaps [rsp+0x60], xmm7
00007f4e3fdd06c3  vmovaps [rsp+0x70], xmm8
00007f4e3fdd06c9  vmovaps [rsp+0x80], xmm9
00007f4e3fdd06d2  vmovaps [rsp+0x90], xmm10
00007f4e3fdd06db  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd06e4  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd06ed  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd06f6  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd06ff  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd0708  sub rsp, 0x30
00007f4e3fdd070c  movaps [rsp], xmm1
00007f4e3fdd0710  movaps [rsp+0x10], xmm15
00007f4e3fdd0716  movaps [rsp+0x20], xmm14
00007f4e3fdd071c  lea rdi, [rsp]
00007f4e3fdd0720  mov esi, 0x00
00007f4e3fdd0725  mov rax, 0x5D97141E9530
00007f4e3fdd072f  call rax
00007f4e3fdd0731  movaps xmm1, [rsp]
00007f4e3fdd0735  add rsp, 0x30
00007f4e3fdd0739  vmovaps xmm0, [rsp]
00007f4e3fdd073e  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd0744  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd074a  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd0750  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd0756  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd075c  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd0762  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd0768  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd0771  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd077a  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd0783  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd078c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd0795  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd079e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd07a7  add rsp, 0xF0
00007f4e3fdd07ae  pop r11
00007f4e3fdd07b0  pop r10
00007f4e3fdd07b2  pop r9
00007f4e3fdd07b4  pop r8
00007f4e3fdd07b6  pop rsi
00007f4e3fdd07b7  pop rdi
00007f4e3fdd07b8  pop rdx
00007f4e3fdd07b9  pop rcx
00007f4e3fdd07ba  pop rax
00007f4e3fdd07bb  add rsp, 0x08
00007f4e3fdd07bf  jmp 0x00007F4E3FDCF581
00007f4e3fdd07c4  sub rsp, 0x08
00007f4e3fdd07c8  push rax
00007f4e3fdd07c9  push rcx
00007f4e3fdd07ca  push rdx
00007f4e3fdd07cb  push rdi
00007f4e3fdd07cc  push rsi
00007f4e3fdd07cd  push r8
00007f4e3fdd07cf  push r9
00007f4e3fdd07d1  push r10
00007f4e3fdd07d3  push r11
00007f4e3fdd07d5  sub rsp, 0xF0
00007f4e3fdd07dc  vmovaps [rsp], xmm0
00007f4e3fdd07e1  vmovaps [rsp+0x10], xmm1
00007f4e3fdd07e7  vmovaps [rsp+0x20], xmm2
00007f4e3fdd07ed  vmovaps [rsp+0x30], xmm3
00007f4e3fdd07f3  vmovaps [rsp+0x40], xmm4
00007f4e3fdd07f9  vmovaps [rsp+0x50], xmm5
00007f4e3fdd07ff  vmovaps [rsp+0x60], xmm6
00007f4e3fdd0805  vmovaps [rsp+0x70], xmm7
00007f4e3fdd080b  vmovaps [rsp+0x80], xmm8
00007f4e3fdd0814  vmovaps [rsp+0x90], xmm9
00007f4e3fdd081d  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd0826  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd082f  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd0838  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd0841  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd084a  sub rsp, 0x30
00007f4e3fdd084e  movaps [rsp], xmm13
00007f4e3fdd0853  movaps [rsp+0x10], xmm1
00007f4e3fdd0858  movaps [rsp+0x20], xmm14
00007f4e3fdd085e  lea rdi, [rsp]
00007f4e3fdd0862  mov esi, 0x00
00007f4e3fdd0867  mov rax, 0x5D97141E9530
00007f4e3fdd0871  call rax
00007f4e3fdd0873  movaps xmm13, [rsp]
00007f4e3fdd0878  add rsp, 0x30
00007f4e3fdd087c  vmovaps xmm0, [rsp]
00007f4e3fdd0881  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd0887  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd088d  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd0893  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd0899  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd089f  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd08a5  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd08ab  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd08b4  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd08bd  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd08c6  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd08cf  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd08d8  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd08e1  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd08ea  add rsp, 0xF0
00007f4e3fdd08f1  pop r11
00007f4e3fdd08f3  pop r10
00007f4e3fdd08f5  pop r9
00007f4e3fdd08f7  pop r8
00007f4e3fdd08f9  pop rsi
00007f4e3fdd08fa  pop rdi
00007f4e3fdd08fb  pop rdx
00007f4e3fdd08fc  pop rcx
00007f4e3fdd08fd  pop rax
00007f4e3fdd08fe  add rsp, 0x08
00007f4e3fdd0902  jmp 0x00007F4E3FDCF5CF
00007f4e3fdd0907  sub rsp, 0x08
00007f4e3fdd090b  push rax
00007f4e3fdd090c  push rcx
00007f4e3fdd090d  push rdx
00007f4e3fdd090e  push rdi
00007f4e3fdd090f  push rsi
00007f4e3fdd0910  push r8
00007f4e3fdd0912  push r9
00007f4e3fdd0914  push r10
00007f4e3fdd0916  push r11
00007f4e3fdd0918  sub rsp, 0xF0
00007f4e3fdd091f  vmovaps [rsp], xmm0
00007f4e3fdd0924  vmovaps [rsp+0x10], xmm1
00007f4e3fdd092a  vmovaps [rsp+0x20], xmm2
00007f4e3fdd0930  vmovaps [rsp+0x30], xmm3
00007f4e3fdd0936  vmovaps [rsp+0x40], xmm4
00007f4e3fdd093c  vmovaps [rsp+0x50], xmm5
00007f4e3fdd0942  vmovaps [rsp+0x60], xmm6
00007f4e3fdd0948  vmovaps [rsp+0x70], xmm7
00007f4e3fdd094e  vmovaps [rsp+0x80], xmm8
00007f4e3fdd0957  vmovaps [rsp+0x90], xmm9
00007f4e3fdd0960  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd0969  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd0972  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd097b  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd0984  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd098d  sub rsp, 0x30
00007f4e3fdd0991  movaps [rsp], xmm15
00007f4e3fdd0996  movaps [rsp+0x10], xmm14
00007f4e3fdd099c  movaps [rsp+0x20], xmm1
00007f4e3fdd09a1  lea rdi, [rsp]
00007f4e3fdd09a5  mov esi, 0x00
00007f4e3fdd09aa  mov rax, 0x5D97141E9530
00007f4e3fdd09b4  call rax
00007f4e3fdd09b6  movaps xmm15, [rsp]
00007f4e3fdd09bb  add rsp, 0x30
00007f4e3fdd09bf  vmovaps xmm0, [rsp]
00007f4e3fdd09c4  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd09ca  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd09d0  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd09d6  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd09dc  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd09e2  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd09e8  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd09ee  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd09f7  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd0a00  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd0a09  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd0a12  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd0a1b  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd0a24  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd0a2d  add rsp, 0xF0
00007f4e3fdd0a34  pop r11
00007f4e3fdd0a36  pop r10
00007f4e3fdd0a38  pop r9
00007f4e3fdd0a3a  pop r8
00007f4e3fdd0a3c  pop rsi
00007f4e3fdd0a3d  pop rdi
00007f4e3fdd0a3e  pop rdx
00007f4e3fdd0a3f  pop rcx
00007f4e3fdd0a40  pop rax
00007f4e3fdd0a41  add rsp, 0x08
00007f4e3fdd0a45  jmp 0x00007F4E3FDCF617
00007f4e3fdd0a4a  sub rsp, 0x08
00007f4e3fdd0a4e  push rax
00007f4e3fdd0a4f  push rcx
00007f4e3fdd0a50  push rdx
00007f4e3fdd0a51  push rdi
00007f4e3fdd0a52  push rsi
00007f4e3fdd0a53  push r8
00007f4e3fdd0a55  push r9
00007f4e3fdd0a57  push r10
00007f4e3fdd0a59  push r11
00007f4e3fdd0a5b  sub rsp, 0xF0
00007f4e3fdd0a62  vmovaps [rsp], xmm0
00007f4e3fdd0a67  vmovaps [rsp+0x10], xmm2
00007f4e3fdd0a6d  vmovaps [rsp+0x20], xmm3
00007f4e3fdd0a73  vmovaps [rsp+0x30], xmm4
00007f4e3fdd0a79  vmovaps [rsp+0x40], xmm5
00007f4e3fdd0a7f  vmovaps [rsp+0x50], xmm6
00007f4e3fdd0a85  vmovaps [rsp+0x60], xmm7
00007f4e3fdd0a8b  vmovaps [rsp+0x70], xmm8
00007f4e3fdd0a91  vmovaps [rsp+0x80], xmm9
00007f4e3fdd0a9a  vmovaps [rsp+0x90], xmm10
00007f4e3fdd0aa3  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd0aac  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd0ab5  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd0abe  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd0ac7  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd0ad0  sub rsp, 0x30
00007f4e3fdd0ad4  movaps [rsp], xmm1
00007f4e3fdd0ad8  movaps [rsp+0x10], xmm14
00007f4e3fdd0ade  movaps [rsp+0x20], xmm10
00007f4e3fdd0ae4  lea rdi, [rsp]
00007f4e3fdd0ae8  mov esi, 0x00
00007f4e3fdd0aed  mov rax, 0x5D97141E9530
00007f4e3fdd0af7  call rax
00007f4e3fdd0af9  movaps xmm1, [rsp]
00007f4e3fdd0afd  add rsp, 0x30
00007f4e3fdd0b01  vmovaps xmm0, [rsp]
00007f4e3fdd0b06  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd0b0c  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd0b12  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd0b18  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd0b1e  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd0b24  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd0b2a  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd0b30  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd0b39  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd0b42  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd0b4b  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd0b54  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd0b5d  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd0b66  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd0b6f  add rsp, 0xF0
00007f4e3fdd0b76  pop r11
00007f4e3fdd0b78  pop r10
00007f4e3fdd0b7a  pop r9
00007f4e3fdd0b7c  pop r8
00007f4e3fdd0b7e  pop rsi
00007f4e3fdd0b7f  pop rdi
00007f4e3fdd0b80  pop rdx
00007f4e3fdd0b81  pop rcx
00007f4e3fdd0b82  pop rax
00007f4e3fdd0b83  add rsp, 0x08
00007f4e3fdd0b87  jmp 0x00007F4E3FDCF631
00007f4e3fdd0b8c  sub rsp, 0x08
00007f4e3fdd0b90  push rax
00007f4e3fdd0b91  push rcx
00007f4e3fdd0b92  push rdx
00007f4e3fdd0b93  push rdi
00007f4e3fdd0b94  push rsi
00007f4e3fdd0b95  push r8
00007f4e3fdd0b97  push r9
00007f4e3fdd0b99  push r10
00007f4e3fdd0b9b  push r11
00007f4e3fdd0b9d  sub rsp, 0xF0
00007f4e3fdd0ba4  vmovaps [rsp], xmm0
00007f4e3fdd0ba9  vmovaps [rsp+0x10], xmm1
00007f4e3fdd0baf  vmovaps [rsp+0x20], xmm2
00007f4e3fdd0bb5  vmovaps [rsp+0x30], xmm3
00007f4e3fdd0bbb  vmovaps [rsp+0x40], xmm4
00007f4e3fdd0bc1  vmovaps [rsp+0x50], xmm5
00007f4e3fdd0bc7  vmovaps [rsp+0x60], xmm6
00007f4e3fdd0bcd  vmovaps [rsp+0x70], xmm7
00007f4e3fdd0bd3  vmovaps [rsp+0x80], xmm8
00007f4e3fdd0bdc  vmovaps [rsp+0x90], xmm9
00007f4e3fdd0be5  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd0bee  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd0bf7  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd0c00  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd0c09  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd0c12  sub rsp, 0x30
00007f4e3fdd0c16  movaps [rsp], xmm13
00007f4e3fdd0c1b  movaps [rsp+0x10], xmm14
00007f4e3fdd0c21  movaps [rsp+0x20], xmm2
00007f4e3fdd0c26  lea rdi, [rsp]
00007f4e3fdd0c2a  mov esi, 0x00
00007f4e3fdd0c2f  mov rax, 0x5D97141E9530
00007f4e3fdd0c39  call rax
00007f4e3fdd0c3b  movaps xmm13, [rsp]
00007f4e3fdd0c40  add rsp, 0x30
00007f4e3fdd0c44  vmovaps xmm0, [rsp]
00007f4e3fdd0c49  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd0c4f  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd0c55  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd0c5b  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd0c61  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd0c67  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd0c6d  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd0c73  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd0c7c  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd0c85  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd0c8e  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd0c97  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd0ca0  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd0ca9  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd0cb2  add rsp, 0xF0
00007f4e3fdd0cb9  pop r11
00007f4e3fdd0cbb  pop r10
00007f4e3fdd0cbd  pop r9
00007f4e3fdd0cbf  pop r8
00007f4e3fdd0cc1  pop rsi
00007f4e3fdd0cc2  pop rdi
00007f4e3fdd0cc3  pop rdx
00007f4e3fdd0cc4  pop rcx
00007f4e3fdd0cc5  pop rax
00007f4e3fdd0cc6  add rsp, 0x08
00007f4e3fdd0cca  jmp 0x00007F4E3FDCF64C
00007f4e3fdd0ccf  sub rsp, 0x08
00007f4e3fdd0cd3  push rax
00007f4e3fdd0cd4  push rcx
00007f4e3fdd0cd5  push rdx
00007f4e3fdd0cd6  push rdi
00007f4e3fdd0cd7  push rsi
00007f4e3fdd0cd8  push r8
00007f4e3fdd0cda  push r9
00007f4e3fdd0cdc  push r10
00007f4e3fdd0cde  push r11
00007f4e3fdd0ce0  sub rsp, 0xF0
00007f4e3fdd0ce7  vmovaps [rsp], xmm0
00007f4e3fdd0cec  vmovaps [rsp+0x10], xmm2
00007f4e3fdd0cf2  vmovaps [rsp+0x20], xmm3
00007f4e3fdd0cf8  vmovaps [rsp+0x30], xmm4
00007f4e3fdd0cfe  vmovaps [rsp+0x40], xmm5
00007f4e3fdd0d04  vmovaps [rsp+0x50], xmm6
00007f4e3fdd0d0a  vmovaps [rsp+0x60], xmm7
00007f4e3fdd0d10  vmovaps [rsp+0x70], xmm8
00007f4e3fdd0d16  vmovaps [rsp+0x80], xmm9
00007f4e3fdd0d1f  vmovaps [rsp+0x90], xmm10
00007f4e3fdd0d28  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd0d31  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd0d3a  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd0d43  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd0d4c  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd0d55  sub rsp, 0x30
00007f4e3fdd0d59  movaps [rsp], xmm1
00007f4e3fdd0d5d  movaps [rsp+0x10], xmm10
00007f4e3fdd0d63  movaps [rsp+0x20], xmm2
00007f4e3fdd0d68  lea rdi, [rsp]
00007f4e3fdd0d6c  mov esi, 0x00
00007f4e3fdd0d71  mov rax, 0x5D97141E9530
00007f4e3fdd0d7b  call rax
00007f4e3fdd0d7d  movaps xmm1, [rsp]
00007f4e3fdd0d81  add rsp, 0x30
00007f4e3fdd0d85  vmovaps xmm0, [rsp]
00007f4e3fdd0d8a  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd0d90  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd0d96  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd0d9c  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd0da2  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd0da8  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd0dae  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd0db4  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd0dbd  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd0dc6  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd0dcf  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd0dd8  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd0de1  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd0dea  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd0df3  add rsp, 0xF0
00007f4e3fdd0dfa  pop r11
00007f4e3fdd0dfc  pop r10
00007f4e3fdd0dfe  pop r9
00007f4e3fdd0e00  pop r8
00007f4e3fdd0e02  pop rsi
00007f4e3fdd0e03  pop rdi
00007f4e3fdd0e04  pop rdx
00007f4e3fdd0e05  pop rcx
00007f4e3fdd0e06  pop rax
00007f4e3fdd0e07  add rsp, 0x08
00007f4e3fdd0e0b  jmp 0x00007F4E3FDCF6B4
00007f4e3fdd0e10  sub rsp, 0x08
00007f4e3fdd0e14  push rax
00007f4e3fdd0e15  push rcx
00007f4e3fdd0e16  push rdx
00007f4e3fdd0e17  push rdi
00007f4e3fdd0e18  push rsi
00007f4e3fdd0e19  push r8
00007f4e3fdd0e1b  push r9
00007f4e3fdd0e1d  push r10
00007f4e3fdd0e1f  push r11
00007f4e3fdd0e21  sub rsp, 0xF0
00007f4e3fdd0e28  vmovaps [rsp], xmm0
00007f4e3fdd0e2d  vmovaps [rsp+0x10], xmm1
00007f4e3fdd0e33  vmovaps [rsp+0x20], xmm2
00007f4e3fdd0e39  vmovaps [rsp+0x30], xmm3
00007f4e3fdd0e3f  vmovaps [rsp+0x40], xmm4
00007f4e3fdd0e45  vmovaps [rsp+0x50], xmm5
00007f4e3fdd0e4b  vmovaps [rsp+0x60], xmm6
00007f4e3fdd0e51  vmovaps [rsp+0x70], xmm7
00007f4e3fdd0e57  vmovaps [rsp+0x80], xmm8
00007f4e3fdd0e60  vmovaps [rsp+0x90], xmm9
00007f4e3fdd0e69  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd0e72  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd0e7b  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd0e84  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd0e8d  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd0e96  sub rsp, 0x30
00007f4e3fdd0e9a  movaps [rsp], xmm15
00007f4e3fdd0e9f  movaps [rsp+0x10], xmm10
00007f4e3fdd0ea5  movaps [rsp+0x20], xmm2
00007f4e3fdd0eaa  lea rdi, [rsp]
00007f4e3fdd0eae  mov esi, 0x00
00007f4e3fdd0eb3  mov rax, 0x5D97141E9530
00007f4e3fdd0ebd  call rax
00007f4e3fdd0ebf  movaps xmm15, [rsp]
00007f4e3fdd0ec4  add rsp, 0x30
00007f4e3fdd0ec8  vmovaps xmm0, [rsp]
00007f4e3fdd0ecd  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd0ed3  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd0ed9  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd0edf  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd0ee5  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd0eeb  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd0ef1  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd0ef7  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd0f00  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd0f09  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd0f12  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd0f1b  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd0f24  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd0f2d  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd0f36  add rsp, 0xF0
00007f4e3fdd0f3d  pop r11
00007f4e3fdd0f3f  pop r10
00007f4e3fdd0f41  pop r9
00007f4e3fdd0f43  pop r8
00007f4e3fdd0f45  pop rsi
00007f4e3fdd0f46  pop rdi
00007f4e3fdd0f47  pop rdx
00007f4e3fdd0f48  pop rcx
00007f4e3fdd0f49  pop rax
00007f4e3fdd0f4a  add rsp, 0x08
00007f4e3fdd0f4e  jmp 0x00007F4E3FDCF706
00007f4e3fdd0f53  sub rsp, 0x08
00007f4e3fdd0f57  push rax
00007f4e3fdd0f58  push rcx
00007f4e3fdd0f59  push rdx
00007f4e3fdd0f5a  push rdi
00007f4e3fdd0f5b  push rsi
00007f4e3fdd0f5c  push r8
00007f4e3fdd0f5e  push r9
00007f4e3fdd0f60  push r10
00007f4e3fdd0f62  push r11
00007f4e3fdd0f64  sub rsp, 0xF0
00007f4e3fdd0f6b  vmovaps [rsp], xmm0
00007f4e3fdd0f70  vmovaps [rsp+0x10], xmm2
00007f4e3fdd0f76  vmovaps [rsp+0x20], xmm3
00007f4e3fdd0f7c  vmovaps [rsp+0x30], xmm4
00007f4e3fdd0f82  vmovaps [rsp+0x40], xmm5
00007f4e3fdd0f88  vmovaps [rsp+0x50], xmm6
00007f4e3fdd0f8e  vmovaps [rsp+0x60], xmm7
00007f4e3fdd0f94  vmovaps [rsp+0x70], xmm8
00007f4e3fdd0f9a  vmovaps [rsp+0x80], xmm9
00007f4e3fdd0fa3  vmovaps [rsp+0x90], xmm10
00007f4e3fdd0fac  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd0fb5  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd0fbe  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd0fc7  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd0fd0  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd0fd9  sub rsp, 0x30
00007f4e3fdd0fdd  movaps [rsp], xmm1
00007f4e3fdd0fe1  movaps [rsp+0x10], xmm10
00007f4e3fdd0fe7  movaps [rsp+0x20], xmm12
00007f4e3fdd0fed  lea rdi, [rsp]
00007f4e3fdd0ff1  mov esi, 0x00
00007f4e3fdd0ff6  mov rax, 0x5D97141E9530
00007f4e3fdd1000  call rax
00007f4e3fdd1002  movaps xmm1, [rsp]
00007f4e3fdd1006  add rsp, 0x30
00007f4e3fdd100a  vmovaps xmm0, [rsp]
00007f4e3fdd100f  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd1015  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd101b  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd1021  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd1027  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd102d  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd1033  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd1039  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd1042  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd104b  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd1054  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd105d  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd1066  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd106f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd1078  add rsp, 0xF0
00007f4e3fdd107f  pop r11
00007f4e3fdd1081  pop r10
00007f4e3fdd1083  pop r9
00007f4e3fdd1085  pop r8
00007f4e3fdd1087  pop rsi
00007f4e3fdd1088  pop rdi
00007f4e3fdd1089  pop rdx
00007f4e3fdd108a  pop rcx
00007f4e3fdd108b  pop rax
00007f4e3fdd108c  add rsp, 0x08
00007f4e3fdd1090  jmp 0x00007F4E3FDCF732
00007f4e3fdd1095  sub rsp, 0x08
00007f4e3fdd1099  push rax
00007f4e3fdd109a  push rcx
00007f4e3fdd109b  push rdx
00007f4e3fdd109c  push rdi
00007f4e3fdd109d  push rsi
00007f4e3fdd109e  push r8
00007f4e3fdd10a0  push r9
00007f4e3fdd10a2  push r10
00007f4e3fdd10a4  push r11
00007f4e3fdd10a6  sub rsp, 0xF0
00007f4e3fdd10ad  vmovaps [rsp], xmm0
00007f4e3fdd10b2  vmovaps [rsp+0x10], xmm1
00007f4e3fdd10b8  vmovaps [rsp+0x20], xmm2
00007f4e3fdd10be  vmovaps [rsp+0x30], xmm3
00007f4e3fdd10c4  vmovaps [rsp+0x40], xmm4
00007f4e3fdd10ca  vmovaps [rsp+0x50], xmm5
00007f4e3fdd10d0  vmovaps [rsp+0x60], xmm6
00007f4e3fdd10d6  vmovaps [rsp+0x70], xmm7
00007f4e3fdd10dc  vmovaps [rsp+0x80], xmm8
00007f4e3fdd10e5  vmovaps [rsp+0x90], xmm9
00007f4e3fdd10ee  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd10f7  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd1100  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd1109  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd1112  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd111b  sub rsp, 0x30
00007f4e3fdd111f  movaps [rsp], xmm15
00007f4e3fdd1124  movaps [rsp+0x10], xmm10
00007f4e3fdd112a  movaps [rsp+0x20], xmm12
00007f4e3fdd1130  lea rdi, [rsp]
00007f4e3fdd1134  mov esi, 0x00
00007f4e3fdd1139  mov rax, 0x5D97141E9530
00007f4e3fdd1143  call rax
00007f4e3fdd1145  movaps xmm15, [rsp]
00007f4e3fdd114a  add rsp, 0x30
00007f4e3fdd114e  vmovaps xmm0, [rsp]
00007f4e3fdd1153  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd1159  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd115f  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd1165  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd116b  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd1171  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd1177  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd117d  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd1186  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd118f  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd1198  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd11a1  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd11aa  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd11b3  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd11bc  add rsp, 0xF0
00007f4e3fdd11c3  pop r11
00007f4e3fdd11c5  pop r10
00007f4e3fdd11c7  pop r9
00007f4e3fdd11c9  pop r8
00007f4e3fdd11cb  pop rsi
00007f4e3fdd11cc  pop rdi
00007f4e3fdd11cd  pop rdx
00007f4e3fdd11ce  pop rcx
00007f4e3fdd11cf  pop rax
00007f4e3fdd11d0  add rsp, 0x08
00007f4e3fdd11d4  jmp 0x00007F4E3FDCF75E
00007f4e3fdd11d9  call 0x00007F4E3FBFF430
00007f4e3fdd11de  jmp 0x00007F4E3FDCF7EE
00007f4e3fdd11e3  call 0x00007F4E3FBFF430
00007f4e3fdd11e8  jmp 0x00007F4E3FDCF801
00007f4e3fdd11ed  sub rsp, 0x08
00007f4e3fdd11f1  push rax
00007f4e3fdd11f2  push rcx
00007f4e3fdd11f3  push rdx
00007f4e3fdd11f4  push rdi
00007f4e3fdd11f5  push rsi
00007f4e3fdd11f6  push r8
00007f4e3fdd11f8  push r9
00007f4e3fdd11fa  push r10
00007f4e3fdd11fc  push r11
00007f4e3fdd11fe  sub rsp, 0xF0
00007f4e3fdd1205  vmovaps [rsp], xmm0
00007f4e3fdd120a  vmovaps [rsp+0x10], xmm2
00007f4e3fdd1210  vmovaps [rsp+0x20], xmm3
00007f4e3fdd1216  vmovaps [rsp+0x30], xmm4
00007f4e3fdd121c  vmovaps [rsp+0x40], xmm5
00007f4e3fdd1222  vmovaps [rsp+0x50], xmm6
00007f4e3fdd1228  vmovaps [rsp+0x60], xmm7
00007f4e3fdd122e  vmovaps [rsp+0x70], xmm8
00007f4e3fdd1234  vmovaps [rsp+0x80], xmm9
00007f4e3fdd123d  vmovaps [rsp+0x90], xmm10
00007f4e3fdd1246  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd124f  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd1258  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd1261  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd126a  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd1273  sub rsp, 0x30
00007f4e3fdd1277  movaps [rsp], xmm1
00007f4e3fdd127b  movaps [rsp+0x10], xmm13
00007f4e3fdd1281  movaps [rsp+0x20], xmm2
00007f4e3fdd1286  lea rdi, [rsp]
00007f4e3fdd128a  mov esi, 0x00
00007f4e3fdd128f  mov rax, 0x5D97141E9530
00007f4e3fdd1299  call rax
00007f4e3fdd129b  movaps xmm1, [rsp]
00007f4e3fdd129f  add rsp, 0x30
00007f4e3fdd12a3  vmovaps xmm0, [rsp]
00007f4e3fdd12a8  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd12ae  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd12b4  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd12ba  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd12c0  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd12c6  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd12cc  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd12d2  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd12db  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd12e4  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd12ed  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd12f6  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd12ff  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd1308  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd1311  add rsp, 0xF0
00007f4e3fdd1318  pop r11
00007f4e3fdd131a  pop r10
00007f4e3fdd131c  pop r9
00007f4e3fdd131e  pop r8
00007f4e3fdd1320  pop rsi
00007f4e3fdd1321  pop rdi
00007f4e3fdd1322  pop rdx
00007f4e3fdd1323  pop rcx
00007f4e3fdd1324  pop rax
00007f4e3fdd1325  add rsp, 0x08
00007f4e3fdd1329  jmp 0x00007F4E3FDCF82C
00007f4e3fdd132e  call 0x00007F4E3FC0E760
00007f4e3fdd1333  jmp 0x00007F4E3FDCF839
00007f4e3fdd1338  sub rsp, 0x08
00007f4e3fdd133c  push rax
00007f4e3fdd133d  push rcx
00007f4e3fdd133e  push rdx
00007f4e3fdd133f  push rdi
00007f4e3fdd1340  push rsi
00007f4e3fdd1341  push r8
00007f4e3fdd1343  push r9
00007f4e3fdd1345  push r10
00007f4e3fdd1347  push r11
00007f4e3fdd1349  sub rsp, 0xF0
00007f4e3fdd1350  vmovaps [rsp], xmm0
00007f4e3fdd1355  vmovaps [rsp+0x10], xmm1
00007f4e3fdd135b  vmovaps [rsp+0x20], xmm2
00007f4e3fdd1361  vmovaps [rsp+0x30], xmm3
00007f4e3fdd1367  vmovaps [rsp+0x40], xmm4
00007f4e3fdd136d  vmovaps [rsp+0x50], xmm5
00007f4e3fdd1373  vmovaps [rsp+0x60], xmm6
00007f4e3fdd1379  vmovaps [rsp+0x70], xmm7
00007f4e3fdd137f  vmovaps [rsp+0x80], xmm8
00007f4e3fdd1388  vmovaps [rsp+0x90], xmm9
00007f4e3fdd1391  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd139a  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd13a3  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd13ac  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd13b5  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd13be  sub rsp, 0x30
00007f4e3fdd13c2  movaps [rsp], xmm13
00007f4e3fdd13c7  movaps [rsp+0x10], xmm2
00007f4e3fdd13cc  movaps [rsp+0x20], xmm1
00007f4e3fdd13d1  lea rdi, [rsp]
00007f4e3fdd13d5  mov esi, 0x00
00007f4e3fdd13da  mov rax, 0x5D97141E9530
00007f4e3fdd13e4  call rax
00007f4e3fdd13e6  movaps xmm13, [rsp]
00007f4e3fdd13eb  add rsp, 0x30
00007f4e3fdd13ef  vmovaps xmm0, [rsp]
00007f4e3fdd13f4  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd13fa  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd1400  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd1406  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd140c  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd1412  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd1418  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd141e  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd1427  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd1430  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd1439  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd1442  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd144b  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd1454  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd145d  add rsp, 0xF0
00007f4e3fdd1464  pop r11
00007f4e3fdd1466  pop r10
00007f4e3fdd1468  pop r9
00007f4e3fdd146a  pop r8
00007f4e3fdd146c  pop rsi
00007f4e3fdd146d  pop rdi
00007f4e3fdd146e  pop rdx
00007f4e3fdd146f  pop rcx
00007f4e3fdd1470  pop rax
00007f4e3fdd1471  add rsp, 0x08
00007f4e3fdd1475  jmp 0x00007F4E3FDCF878
00007f4e3fdd147a  sub rsp, 0x08
00007f4e3fdd147e  push rax
00007f4e3fdd147f  push rcx
00007f4e3fdd1480  push rdx
00007f4e3fdd1481  push rdi
00007f4e3fdd1482  push rsi
00007f4e3fdd1483  push r8
00007f4e3fdd1485  push r9
00007f4e3fdd1487  push r10
00007f4e3fdd1489  push r11
00007f4e3fdd148b  sub rsp, 0xF0
00007f4e3fdd1492  vmovaps [rsp], xmm0
00007f4e3fdd1497  vmovaps [rsp+0x10], xmm2
00007f4e3fdd149d  vmovaps [rsp+0x20], xmm3
00007f4e3fdd14a3  vmovaps [rsp+0x30], xmm4
00007f4e3fdd14a9  vmovaps [rsp+0x40], xmm5
00007f4e3fdd14af  vmovaps [rsp+0x50], xmm6
00007f4e3fdd14b5  vmovaps [rsp+0x60], xmm7
00007f4e3fdd14bb  vmovaps [rsp+0x70], xmm8
00007f4e3fdd14c1  vmovaps [rsp+0x80], xmm9
00007f4e3fdd14ca  vmovaps [rsp+0x90], xmm10
00007f4e3fdd14d3  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd14dc  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd14e5  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd14ee  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd14f7  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd1500  sub rsp, 0x30
00007f4e3fdd1504  movaps [rsp], xmm1
00007f4e3fdd1508  movaps [rsp+0x10], xmm15
00007f4e3fdd150e  movaps [rsp+0x20], xmm2
00007f4e3fdd1513  lea rdi, [rsp]
00007f4e3fdd1517  mov esi, 0x00
00007f4e3fdd151c  mov rax, 0x5D97141E9530
00007f4e3fdd1526  call rax
00007f4e3fdd1528  movaps xmm1, [rsp]
00007f4e3fdd152c  add rsp, 0x30
00007f4e3fdd1530  vmovaps xmm0, [rsp]
00007f4e3fdd1535  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd153b  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd1541  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd1547  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd154d  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd1553  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd1559  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd155f  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd1568  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd1571  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd157a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd1583  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd158c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd1595  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd159e  add rsp, 0xF0
00007f4e3fdd15a5  pop r11
00007f4e3fdd15a7  pop r10
00007f4e3fdd15a9  pop r9
00007f4e3fdd15ab  pop r8
00007f4e3fdd15ad  pop rsi
00007f4e3fdd15ae  pop rdi
00007f4e3fdd15af  pop rdx
00007f4e3fdd15b0  pop rcx
00007f4e3fdd15b1  pop rax
00007f4e3fdd15b2  add rsp, 0x08
00007f4e3fdd15b6  jmp 0x00007F4E3FDCF8AC
00007f4e3fdd15bb  sub rsp, 0x08
00007f4e3fdd15bf  push rax
00007f4e3fdd15c0  push rcx
00007f4e3fdd15c1  push rdx
00007f4e3fdd15c2  push rdi
00007f4e3fdd15c3  push rsi
00007f4e3fdd15c4  push r8
00007f4e3fdd15c6  push r9
00007f4e3fdd15c8  push r10
00007f4e3fdd15ca  push r11
00007f4e3fdd15cc  sub rsp, 0xF0
00007f4e3fdd15d3  vmovaps [rsp], xmm0
00007f4e3fdd15d8  vmovaps [rsp+0x10], xmm1
00007f4e3fdd15de  vmovaps [rsp+0x20], xmm2
00007f4e3fdd15e4  vmovaps [rsp+0x30], xmm3
00007f4e3fdd15ea  vmovaps [rsp+0x40], xmm4
00007f4e3fdd15f0  vmovaps [rsp+0x50], xmm5
00007f4e3fdd15f6  vmovaps [rsp+0x60], xmm6
00007f4e3fdd15fc  vmovaps [rsp+0x70], xmm7
00007f4e3fdd1602  vmovaps [rsp+0x80], xmm8
00007f4e3fdd160b  vmovaps [rsp+0x90], xmm9
00007f4e3fdd1614  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd161d  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd1626  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd162f  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd1638  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd1641  sub rsp, 0x30
00007f4e3fdd1645  movaps [rsp], xmm14
00007f4e3fdd164a  movaps [rsp+0x10], xmm2
00007f4e3fdd164f  movaps [rsp+0x20], xmm15
00007f4e3fdd1655  lea rdi, [rsp]
00007f4e3fdd1659  mov esi, 0x00
00007f4e3fdd165e  mov rax, 0x5D97141E9530
00007f4e3fdd1668  call rax
00007f4e3fdd166a  movaps xmm14, [rsp]
00007f4e3fdd166f  add rsp, 0x30
00007f4e3fdd1673  vmovaps xmm0, [rsp]
00007f4e3fdd1678  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd167e  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd1684  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd168a  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd1690  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd1696  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd169c  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd16a2  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd16ab  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd16b4  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd16bd  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd16c6  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd16cf  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd16d8  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd16e1  add rsp, 0xF0
00007f4e3fdd16e8  pop r11
00007f4e3fdd16ea  pop r10
00007f4e3fdd16ec  pop r9
00007f4e3fdd16ee  pop r8
00007f4e3fdd16f0  pop rsi
00007f4e3fdd16f1  pop rdi
00007f4e3fdd16f2  pop rdx
00007f4e3fdd16f3  pop rcx
00007f4e3fdd16f4  pop rax
00007f4e3fdd16f5  add rsp, 0x08
00007f4e3fdd16f9  jmp 0x00007F4E3FDCF8E7
00007f4e3fdd16fe  sub rsp, 0x08
00007f4e3fdd1702  push rax
00007f4e3fdd1703  push rcx
00007f4e3fdd1704  push rdx
00007f4e3fdd1705  push rdi
00007f4e3fdd1706  push rsi
00007f4e3fdd1707  push r8
00007f4e3fdd1709  push r9
00007f4e3fdd170b  push r10
00007f4e3fdd170d  push r11
00007f4e3fdd170f  sub rsp, 0xF0
00007f4e3fdd1716  vmovaps [rsp], xmm0
00007f4e3fdd171b  vmovaps [rsp+0x10], xmm1
00007f4e3fdd1721  vmovaps [rsp+0x20], xmm2
00007f4e3fdd1727  vmovaps [rsp+0x30], xmm3
00007f4e3fdd172d  vmovaps [rsp+0x40], xmm4
00007f4e3fdd1733  vmovaps [rsp+0x50], xmm5
00007f4e3fdd1739  vmovaps [rsp+0x60], xmm6
00007f4e3fdd173f  vmovaps [rsp+0x70], xmm7
00007f4e3fdd1745  vmovaps [rsp+0x80], xmm8
00007f4e3fdd174e  vmovaps [rsp+0x90], xmm9
00007f4e3fdd1757  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd1760  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd1769  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd1772  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd177b  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd1784  sub rsp, 0x30
00007f4e3fdd1788  movaps [rsp], xmm15
00007f4e3fdd178d  movaps [rsp+0x10], xmm2
00007f4e3fdd1792  movaps [rsp+0x20], xmm1
00007f4e3fdd1797  lea rdi, [rsp]
00007f4e3fdd179b  mov esi, 0x00
00007f4e3fdd17a0  mov rax, 0x5D97141E9530
00007f4e3fdd17aa  call rax
00007f4e3fdd17ac  movaps xmm15, [rsp]
00007f4e3fdd17b1  add rsp, 0x30
00007f4e3fdd17b5  vmovaps xmm0, [rsp]
00007f4e3fdd17ba  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd17c0  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd17c6  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd17cc  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd17d2  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd17d8  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd17de  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd17e4  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd17ed  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd17f6  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd17ff  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd1808  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd1811  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd181a  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd1823  add rsp, 0xF0
00007f4e3fdd182a  pop r11
00007f4e3fdd182c  pop r10
00007f4e3fdd182e  pop r9
00007f4e3fdd1830  pop r8
00007f4e3fdd1832  pop rsi
00007f4e3fdd1833  pop rdi
00007f4e3fdd1834  pop rdx
00007f4e3fdd1835  pop rcx
00007f4e3fdd1836  pop rax
00007f4e3fdd1837  add rsp, 0x08
00007f4e3fdd183b  jmp 0x00007F4E3FDCF923
00007f4e3fdd1840  call 0x00007F4E3FBFF430
00007f4e3fdd1845  jmp 0x00007F4E3FDCF930
00007f4e3fdd184a  sub rsp, 0x08
00007f4e3fdd184e  push rax
00007f4e3fdd184f  push rcx
00007f4e3fdd1850  push rdx
00007f4e3fdd1851  push rdi
00007f4e3fdd1852  push rsi
00007f4e3fdd1853  push r8
00007f4e3fdd1855  push r9
00007f4e3fdd1857  push r10
00007f4e3fdd1859  push r11
00007f4e3fdd185b  sub rsp, 0xF0
00007f4e3fdd1862  vmovaps [rsp], xmm0
00007f4e3fdd1867  vmovaps [rsp+0x10], xmm1
00007f4e3fdd186d  vmovaps [rsp+0x20], xmm3
00007f4e3fdd1873  vmovaps [rsp+0x30], xmm4
00007f4e3fdd1879  vmovaps [rsp+0x40], xmm5
00007f4e3fdd187f  vmovaps [rsp+0x50], xmm6
00007f4e3fdd1885  vmovaps [rsp+0x60], xmm7
00007f4e3fdd188b  vmovaps [rsp+0x70], xmm8
00007f4e3fdd1891  vmovaps [rsp+0x80], xmm9
00007f4e3fdd189a  vmovaps [rsp+0x90], xmm10
00007f4e3fdd18a3  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd18ac  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd18b5  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd18be  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd18c7  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd18d0  sub rsp, 0x30
00007f4e3fdd18d4  movaps [rsp], xmm2
00007f4e3fdd18d8  movaps [rsp+0x10], xmm1
00007f4e3fdd18dd  movaps [rsp+0x20], xmm14
00007f4e3fdd18e3  lea rdi, [rsp]
00007f4e3fdd18e7  mov esi, 0x00
00007f4e3fdd18ec  mov rax, 0x5D97141E9530
00007f4e3fdd18f6  call rax
00007f4e3fdd18f8  movaps xmm2, [rsp]
00007f4e3fdd18fc  add rsp, 0x30
00007f4e3fdd1900  vmovaps xmm0, [rsp]
00007f4e3fdd1905  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd190b  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd1911  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd1917  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd191d  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd1923  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd1929  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd192f  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd1938  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd1941  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd194a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd1953  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd195c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd1965  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd196e  add rsp, 0xF0
00007f4e3fdd1975  pop r11
00007f4e3fdd1977  pop r10
00007f4e3fdd1979  pop r9
00007f4e3fdd197b  pop r8
00007f4e3fdd197d  pop rsi
00007f4e3fdd197e  pop rdi
00007f4e3fdd197f  pop rdx
00007f4e3fdd1980  pop rcx
00007f4e3fdd1981  pop rax
00007f4e3fdd1982  add rsp, 0x08
00007f4e3fdd1986  jmp 0x00007F4E3FDCF96D
00007f4e3fdd198b  sub rsp, 0x08
00007f4e3fdd198f  push rax
00007f4e3fdd1990  push rcx
00007f4e3fdd1991  push rdx
00007f4e3fdd1992  push rdi
00007f4e3fdd1993  push rsi
00007f4e3fdd1994  push r8
00007f4e3fdd1996  push r9
00007f4e3fdd1998  push r10
00007f4e3fdd199a  push r11
00007f4e3fdd199c  sub rsp, 0xF0
00007f4e3fdd19a3  vmovaps [rsp], xmm0
00007f4e3fdd19a8  vmovaps [rsp+0x10], xmm1
00007f4e3fdd19ae  vmovaps [rsp+0x20], xmm2
00007f4e3fdd19b4  vmovaps [rsp+0x30], xmm3
00007f4e3fdd19ba  vmovaps [rsp+0x40], xmm4
00007f4e3fdd19c0  vmovaps [rsp+0x50], xmm5
00007f4e3fdd19c6  vmovaps [rsp+0x60], xmm6
00007f4e3fdd19cc  vmovaps [rsp+0x70], xmm7
00007f4e3fdd19d2  vmovaps [rsp+0x80], xmm8
00007f4e3fdd19db  vmovaps [rsp+0x90], xmm9
00007f4e3fdd19e4  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd19ed  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd19f6  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd19ff  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd1a08  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd1a11  sub rsp, 0x30
00007f4e3fdd1a15  movaps [rsp], xmm15
00007f4e3fdd1a1a  movaps [rsp+0x10], xmm14
00007f4e3fdd1a20  movaps [rsp+0x20], xmm1
00007f4e3fdd1a25  lea rdi, [rsp]
00007f4e3fdd1a29  mov esi, 0x00
00007f4e3fdd1a2e  mov rax, 0x5D97141E9530
00007f4e3fdd1a38  call rax
00007f4e3fdd1a3a  movaps xmm15, [rsp]
00007f4e3fdd1a3f  add rsp, 0x30
00007f4e3fdd1a43  vmovaps xmm0, [rsp]
00007f4e3fdd1a48  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd1a4e  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd1a54  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd1a5a  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd1a60  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd1a66  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd1a6c  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd1a72  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd1a7b  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd1a84  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd1a8d  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd1a96  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd1a9f  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd1aa8  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd1ab1  add rsp, 0xF0
00007f4e3fdd1ab8  pop r11
00007f4e3fdd1aba  pop r10
00007f4e3fdd1abc  pop r9
00007f4e3fdd1abe  pop r8
00007f4e3fdd1ac0  pop rsi
00007f4e3fdd1ac1  pop rdi
00007f4e3fdd1ac2  pop rdx
00007f4e3fdd1ac3  pop rcx
00007f4e3fdd1ac4  pop rax
00007f4e3fdd1ac5  add rsp, 0x08
00007f4e3fdd1ac9  jmp 0x00007F4E3FDCF9E7
00007f4e3fdd1ace  call 0x00007F4E3FBFF430
00007f4e3fdd1ad3  jmp 0x00007F4E3FDCF9F4
00007f4e3fdd1ad8  sub rsp, 0x08
00007f4e3fdd1adc  push rax
00007f4e3fdd1add  push rcx
00007f4e3fdd1ade  push rdx
00007f4e3fdd1adf  push rdi
00007f4e3fdd1ae0  push rsi
00007f4e3fdd1ae1  push r8
00007f4e3fdd1ae3  push r9
00007f4e3fdd1ae5  push r10
00007f4e3fdd1ae7  push r11
00007f4e3fdd1ae9  sub rsp, 0xF0
00007f4e3fdd1af0  vmovaps [rsp], xmm0
00007f4e3fdd1af5  vmovaps [rsp+0x10], xmm1
00007f4e3fdd1afb  vmovaps [rsp+0x20], xmm2
00007f4e3fdd1b01  vmovaps [rsp+0x30], xmm3
00007f4e3fdd1b07  vmovaps [rsp+0x40], xmm4
00007f4e3fdd1b0d  vmovaps [rsp+0x50], xmm5
00007f4e3fdd1b13  vmovaps [rsp+0x60], xmm6
00007f4e3fdd1b19  vmovaps [rsp+0x70], xmm7
00007f4e3fdd1b1f  vmovaps [rsp+0x80], xmm8
00007f4e3fdd1b28  vmovaps [rsp+0x90], xmm9
00007f4e3fdd1b31  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd1b3a  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd1b43  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd1b4c  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd1b55  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd1b5e  sub rsp, 0x30
00007f4e3fdd1b62  movaps [rsp], xmm14
00007f4e3fdd1b67  movaps [rsp+0x10], xmm13
00007f4e3fdd1b6d  movaps [rsp+0x20], xmm1
00007f4e3fdd1b72  lea rdi, [rsp]
00007f4e3fdd1b76  mov esi, 0x00
00007f4e3fdd1b7b  mov rax, 0x5D97141E9530
00007f4e3fdd1b85  call rax
00007f4e3fdd1b87  movaps xmm14, [rsp]
00007f4e3fdd1b8c  add rsp, 0x30
00007f4e3fdd1b90  vmovaps xmm0, [rsp]
00007f4e3fdd1b95  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd1b9b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd1ba1  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd1ba7  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd1bad  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd1bb3  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd1bb9  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd1bbf  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd1bc8  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd1bd1  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd1bda  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd1be3  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd1bec  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd1bf5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd1bfe  add rsp, 0xF0
00007f4e3fdd1c05  pop r11
00007f4e3fdd1c07  pop r10
00007f4e3fdd1c09  pop r9
00007f4e3fdd1c0b  pop r8
00007f4e3fdd1c0d  pop rsi
00007f4e3fdd1c0e  pop rdi
00007f4e3fdd1c0f  pop rdx
00007f4e3fdd1c10  pop rcx
00007f4e3fdd1c11  pop rax
00007f4e3fdd1c12  add rsp, 0x08
00007f4e3fdd1c16  jmp 0x00007F4E3FDCFAAF
00007f4e3fdd1c1b  sub rsp, 0x08
00007f4e3fdd1c1f  push rax
00007f4e3fdd1c20  push rcx
00007f4e3fdd1c21  push rdx
00007f4e3fdd1c22  push rdi
00007f4e3fdd1c23  push rsi
00007f4e3fdd1c24  push r8
00007f4e3fdd1c26  push r9
00007f4e3fdd1c28  push r10
00007f4e3fdd1c2a  push r11
00007f4e3fdd1c2c  sub rsp, 0xF0
00007f4e3fdd1c33  vmovaps [rsp], xmm0
00007f4e3fdd1c38  vmovaps [rsp+0x10], xmm1
00007f4e3fdd1c3e  vmovaps [rsp+0x20], xmm2
00007f4e3fdd1c44  vmovaps [rsp+0x30], xmm3
00007f4e3fdd1c4a  vmovaps [rsp+0x40], xmm4
00007f4e3fdd1c50  vmovaps [rsp+0x50], xmm5
00007f4e3fdd1c56  vmovaps [rsp+0x60], xmm6
00007f4e3fdd1c5c  vmovaps [rsp+0x70], xmm7
00007f4e3fdd1c62  vmovaps [rsp+0x80], xmm8
00007f4e3fdd1c6b  vmovaps [rsp+0x90], xmm9
00007f4e3fdd1c74  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd1c7d  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd1c86  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd1c8f  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd1c98  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd1ca1  sub rsp, 0x30
00007f4e3fdd1ca5  movaps [rsp], xmm15
00007f4e3fdd1caa  movaps [rsp+0x10], xmm13
00007f4e3fdd1cb0  movaps [rsp+0x20], xmm1
00007f4e3fdd1cb5  lea rdi, [rsp]
00007f4e3fdd1cb9  mov esi, 0x00
00007f4e3fdd1cbe  mov rax, 0x5D97141E9530
00007f4e3fdd1cc8  call rax
00007f4e3fdd1cca  movaps xmm15, [rsp]
00007f4e3fdd1ccf  add rsp, 0x30
00007f4e3fdd1cd3  vmovaps xmm0, [rsp]
00007f4e3fdd1cd8  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd1cde  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd1ce4  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd1cea  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd1cf0  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd1cf6  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd1cfc  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd1d02  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd1d0b  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd1d14  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd1d1d  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd1d26  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd1d2f  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd1d38  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd1d41  add rsp, 0xF0
00007f4e3fdd1d48  pop r11
00007f4e3fdd1d4a  pop r10
00007f4e3fdd1d4c  pop r9
00007f4e3fdd1d4e  pop r8
00007f4e3fdd1d50  pop rsi
00007f4e3fdd1d51  pop rdi
00007f4e3fdd1d52  pop rdx
00007f4e3fdd1d53  pop rcx
00007f4e3fdd1d54  pop rax
00007f4e3fdd1d55  add rsp, 0x08
00007f4e3fdd1d59  jmp 0x00007F4E3FDCFAEB
00007f4e3fdd1d5e  call 0x00007F4E3FBFF430
00007f4e3fdd1d63  jmp 0x00007F4E3FDCFAF8
00007f4e3fdd1d68  sub rsp, 0x08
00007f4e3fdd1d6c  push rax
00007f4e3fdd1d6d  push rcx
00007f4e3fdd1d6e  push rdx
00007f4e3fdd1d6f  push rdi
00007f4e3fdd1d70  push rsi
00007f4e3fdd1d71  push r8
00007f4e3fdd1d73  push r9
00007f4e3fdd1d75  push r10
00007f4e3fdd1d77  push r11
00007f4e3fdd1d79  sub rsp, 0xF0
00007f4e3fdd1d80  vmovaps [rsp], xmm0
00007f4e3fdd1d85  vmovaps [rsp+0x10], xmm1
00007f4e3fdd1d8b  vmovaps [rsp+0x20], xmm2
00007f4e3fdd1d91  vmovaps [rsp+0x30], xmm3
00007f4e3fdd1d97  vmovaps [rsp+0x40], xmm4
00007f4e3fdd1d9d  vmovaps [rsp+0x50], xmm5
00007f4e3fdd1da3  vmovaps [rsp+0x60], xmm6
00007f4e3fdd1da9  vmovaps [rsp+0x70], xmm7
00007f4e3fdd1daf  vmovaps [rsp+0x80], xmm8
00007f4e3fdd1db8  vmovaps [rsp+0x90], xmm9
00007f4e3fdd1dc1  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd1dca  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd1dd3  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd1ddc  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd1de5  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd1dee  sub rsp, 0x30
00007f4e3fdd1df2  movaps [rsp], xmm14
00007f4e3fdd1df7  movaps [rsp+0x10], xmm13
00007f4e3fdd1dfd  movaps [rsp+0x20], xmm2
00007f4e3fdd1e02  lea rdi, [rsp]
00007f4e3fdd1e06  mov esi, 0x00
00007f4e3fdd1e0b  mov rax, 0x5D97141E9530
00007f4e3fdd1e15  call rax
00007f4e3fdd1e17  movaps xmm14, [rsp]
00007f4e3fdd1e1c  add rsp, 0x30
00007f4e3fdd1e20  vmovaps xmm0, [rsp]
00007f4e3fdd1e25  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd1e2b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd1e31  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd1e37  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd1e3d  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd1e43  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd1e49  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd1e4f  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd1e58  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd1e61  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd1e6a  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd1e73  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd1e7c  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd1e85  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd1e8e  add rsp, 0xF0
00007f4e3fdd1e95  pop r11
00007f4e3fdd1e97  pop r10
00007f4e3fdd1e99  pop r9
00007f4e3fdd1e9b  pop r8
00007f4e3fdd1e9d  pop rsi
00007f4e3fdd1e9e  pop rdi
00007f4e3fdd1e9f  pop rdx
00007f4e3fdd1ea0  pop rcx
00007f4e3fdd1ea1  pop rax
00007f4e3fdd1ea2  add rsp, 0x08
00007f4e3fdd1ea6  jmp 0x00007F4E3FDCFB24
00007f4e3fdd1eab  sub rsp, 0x08
00007f4e3fdd1eaf  push rax
00007f4e3fdd1eb0  push rcx
00007f4e3fdd1eb1  push rdx
00007f4e3fdd1eb2  push rdi
00007f4e3fdd1eb3  push rsi
00007f4e3fdd1eb4  push r8
00007f4e3fdd1eb6  push r9
00007f4e3fdd1eb8  push r10
00007f4e3fdd1eba  push r11
00007f4e3fdd1ebc  sub rsp, 0xF0
00007f4e3fdd1ec3  vmovaps [rsp], xmm0
00007f4e3fdd1ec8  vmovaps [rsp+0x10], xmm2
00007f4e3fdd1ece  vmovaps [rsp+0x20], xmm3
00007f4e3fdd1ed4  vmovaps [rsp+0x30], xmm4
00007f4e3fdd1eda  vmovaps [rsp+0x40], xmm5
00007f4e3fdd1ee0  vmovaps [rsp+0x50], xmm6
00007f4e3fdd1ee6  vmovaps [rsp+0x60], xmm7
00007f4e3fdd1eec  vmovaps [rsp+0x70], xmm8
00007f4e3fdd1ef2  vmovaps [rsp+0x80], xmm9
00007f4e3fdd1efb  vmovaps [rsp+0x90], xmm10
00007f4e3fdd1f04  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd1f0d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd1f16  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd1f1f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd1f28  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd1f31  sub rsp, 0x30
00007f4e3fdd1f35  movaps [rsp], xmm1
00007f4e3fdd1f39  movaps [rsp+0x10], xmm13
00007f4e3fdd1f3f  movaps [rsp+0x20], xmm2
00007f4e3fdd1f44  lea rdi, [rsp]
00007f4e3fdd1f48  mov esi, 0x00
00007f4e3fdd1f4d  mov rax, 0x5D97141E9530
00007f4e3fdd1f57  call rax
00007f4e3fdd1f59  movaps xmm1, [rsp]
00007f4e3fdd1f5d  add rsp, 0x30
00007f4e3fdd1f61  vmovaps xmm0, [rsp]
00007f4e3fdd1f66  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd1f6c  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd1f72  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd1f78  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd1f7e  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd1f84  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd1f8a  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd1f90  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd1f99  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd1fa2  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd1fab  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd1fb4  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd1fbd  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd1fc6  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd1fcf  add rsp, 0xF0
00007f4e3fdd1fd6  pop r11
00007f4e3fdd1fd8  pop r10
00007f4e3fdd1fda  pop r9
00007f4e3fdd1fdc  pop r8
00007f4e3fdd1fde  pop rsi
00007f4e3fdd1fdf  pop rdi
00007f4e3fdd1fe0  pop rdx
00007f4e3fdd1fe1  pop rcx
00007f4e3fdd1fe2  pop rax
00007f4e3fdd1fe3  add rsp, 0x08
00007f4e3fdd1fe7  jmp 0x00007F4E3FDCFB52
00007f4e3fdd1fec  sub rsp, 0x08
00007f4e3fdd1ff0  push rax
00007f4e3fdd1ff1  push rcx
00007f4e3fdd1ff2  push rdx
00007f4e3fdd1ff3  push rdi
00007f4e3fdd1ff4  push rsi
00007f4e3fdd1ff5  push r8
00007f4e3fdd1ff7  push r9
00007f4e3fdd1ff9  push r10
00007f4e3fdd1ffb  push r11
00007f4e3fdd1ffd  sub rsp, 0xF0
00007f4e3fdd2004  vmovaps [rsp], xmm0
00007f4e3fdd2009  vmovaps [rsp+0x10], xmm1
00007f4e3fdd200f  vmovaps [rsp+0x20], xmm3
00007f4e3fdd2015  vmovaps [rsp+0x30], xmm4
00007f4e3fdd201b  vmovaps [rsp+0x40], xmm5
00007f4e3fdd2021  vmovaps [rsp+0x50], xmm6
00007f4e3fdd2027  vmovaps [rsp+0x60], xmm7
00007f4e3fdd202d  vmovaps [rsp+0x70], xmm8
00007f4e3fdd2033  vmovaps [rsp+0x80], xmm9
00007f4e3fdd203c  vmovaps [rsp+0x90], xmm10
00007f4e3fdd2045  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd204e  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd2057  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd2060  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd2069  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2072  sub rsp, 0x30
00007f4e3fdd2076  movaps [rsp], xmm2
00007f4e3fdd207a  movaps [rsp+0x10], xmm1
00007f4e3fdd207f  movaps [rsp+0x20], xmm13
00007f4e3fdd2085  lea rdi, [rsp]
00007f4e3fdd2089  mov esi, 0x00
00007f4e3fdd208e  mov rax, 0x5D97141E9530
00007f4e3fdd2098  call rax
00007f4e3fdd209a  movaps xmm2, [rsp]
00007f4e3fdd209e  add rsp, 0x30
00007f4e3fdd20a2  vmovaps xmm0, [rsp]
00007f4e3fdd20a7  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd20ad  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd20b3  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd20b9  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd20bf  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd20c5  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd20cb  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd20d1  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd20da  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd20e3  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd20ec  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd20f5  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd20fe  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd2107  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd2110  add rsp, 0xF0
00007f4e3fdd2117  pop r11
00007f4e3fdd2119  pop r10
00007f4e3fdd211b  pop r9
00007f4e3fdd211d  pop r8
00007f4e3fdd211f  pop rsi
00007f4e3fdd2120  pop rdi
00007f4e3fdd2121  pop rdx
00007f4e3fdd2122  pop rcx
00007f4e3fdd2123  pop rax
00007f4e3fdd2124  add rsp, 0x08
00007f4e3fdd2128  jmp 0x00007F4E3FDCFBAB
00007f4e3fdd212d  call 0x00007F4E3FBFF430
00007f4e3fdd2132  jmp 0x00007F4E3FDCFBB8
00007f4e3fdd2137  sub rsp, 0x08
00007f4e3fdd213b  push rax
00007f4e3fdd213c  push rcx
00007f4e3fdd213d  push rdx
00007f4e3fdd213e  push rdi
00007f4e3fdd213f  push rsi
00007f4e3fdd2140  push r8
00007f4e3fdd2142  push r9
00007f4e3fdd2144  push r10
00007f4e3fdd2146  push r11
00007f4e3fdd2148  sub rsp, 0xF0
00007f4e3fdd214f  vmovaps [rsp], xmm0
00007f4e3fdd2154  vmovaps [rsp+0x10], xmm1
00007f4e3fdd215a  vmovaps [rsp+0x20], xmm2
00007f4e3fdd2160  vmovaps [rsp+0x30], xmm3
00007f4e3fdd2166  vmovaps [rsp+0x40], xmm4
00007f4e3fdd216c  vmovaps [rsp+0x50], xmm5
00007f4e3fdd2172  vmovaps [rsp+0x60], xmm6
00007f4e3fdd2178  vmovaps [rsp+0x70], xmm7
00007f4e3fdd217e  vmovaps [rsp+0x80], xmm8
00007f4e3fdd2187  vmovaps [rsp+0x90], xmm9
00007f4e3fdd2190  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd2199  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd21a2  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd21ab  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd21b4  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd21bd  sub rsp, 0x30
00007f4e3fdd21c1  movaps [rsp], xmm15
00007f4e3fdd21c6  movaps [rsp+0x10], xmm13
00007f4e3fdd21cc  movaps [rsp+0x20], xmm1
00007f4e3fdd21d1  lea rdi, [rsp]
00007f4e3fdd21d5  mov esi, 0x00
00007f4e3fdd21da  mov rax, 0x5D97141E9530
00007f4e3fdd21e4  call rax
00007f4e3fdd21e6  movaps xmm15, [rsp]
00007f4e3fdd21eb  add rsp, 0x30
00007f4e3fdd21ef  vmovaps xmm0, [rsp]
00007f4e3fdd21f4  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd21fa  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2200  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd2206  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd220c  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd2212  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd2218  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd221e  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd2227  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd2230  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd2239  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd2242  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd224b  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd2254  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd225d  add rsp, 0xF0
00007f4e3fdd2264  pop r11
00007f4e3fdd2266  pop r10
00007f4e3fdd2268  pop r9
00007f4e3fdd226a  pop r8
00007f4e3fdd226c  pop rsi
00007f4e3fdd226d  pop rdi
00007f4e3fdd226e  pop rdx
00007f4e3fdd226f  pop rcx
00007f4e3fdd2270  pop rax
00007f4e3fdd2271  add rsp, 0x08
00007f4e3fdd2275  jmp 0x00007F4E3FDCFBF7
00007f4e3fdd227a  sub rsp, 0x08
00007f4e3fdd227e  push rax
00007f4e3fdd227f  push rcx
00007f4e3fdd2280  push rdx
00007f4e3fdd2281  push rdi
00007f4e3fdd2282  push rsi
00007f4e3fdd2283  push r8
00007f4e3fdd2285  push r9
00007f4e3fdd2287  push r10
00007f4e3fdd2289  push r11
00007f4e3fdd228b  sub rsp, 0xF0
00007f4e3fdd2292  vmovaps [rsp], xmm0
00007f4e3fdd2297  vmovaps [rsp+0x10], xmm1
00007f4e3fdd229d  vmovaps [rsp+0x20], xmm2
00007f4e3fdd22a3  vmovaps [rsp+0x30], xmm3
00007f4e3fdd22a9  vmovaps [rsp+0x40], xmm4
00007f4e3fdd22af  vmovaps [rsp+0x50], xmm5
00007f4e3fdd22b5  vmovaps [rsp+0x60], xmm6
00007f4e3fdd22bb  vmovaps [rsp+0x70], xmm7
00007f4e3fdd22c1  vmovaps [rsp+0x80], xmm8
00007f4e3fdd22ca  vmovaps [rsp+0x90], xmm9
00007f4e3fdd22d3  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd22dc  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd22e5  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd22ee  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd22f7  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2300  sub rsp, 0x30
00007f4e3fdd2304  movaps [rsp], xmm14
00007f4e3fdd2309  movaps [rsp+0x10], xmm11
00007f4e3fdd230f  movaps [rsp+0x20], xmm1
00007f4e3fdd2314  lea rdi, [rsp]
00007f4e3fdd2318  mov esi, 0x00
00007f4e3fdd231d  mov rax, 0x5D97141E9530
00007f4e3fdd2327  call rax
00007f4e3fdd2329  movaps xmm14, [rsp]
00007f4e3fdd232e  add rsp, 0x30
00007f4e3fdd2332  vmovaps xmm0, [rsp]
00007f4e3fdd2337  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd233d  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2343  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd2349  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd234f  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd2355  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd235b  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd2361  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd236a  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd2373  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd237c  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd2385  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd238e  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd2397  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd23a0  add rsp, 0xF0
00007f4e3fdd23a7  pop r11
00007f4e3fdd23a9  pop r10
00007f4e3fdd23ab  pop r9
00007f4e3fdd23ad  pop r8
00007f4e3fdd23af  pop rsi
00007f4e3fdd23b0  pop rdi
00007f4e3fdd23b1  pop rdx
00007f4e3fdd23b2  pop rcx
00007f4e3fdd23b3  pop rax
00007f4e3fdd23b4  add rsp, 0x08
00007f4e3fdd23b8  jmp 0x00007F4E3FDCFC21
00007f4e3fdd23bd  sub rsp, 0x08
00007f4e3fdd23c1  push rax
00007f4e3fdd23c2  push rcx
00007f4e3fdd23c3  push rdx
00007f4e3fdd23c4  push rdi
00007f4e3fdd23c5  push rsi
00007f4e3fdd23c6  push r8
00007f4e3fdd23c8  push r9
00007f4e3fdd23ca  push r10
00007f4e3fdd23cc  push r11
00007f4e3fdd23ce  sub rsp, 0xF0
00007f4e3fdd23d5  vmovaps [rsp], xmm0
00007f4e3fdd23da  vmovaps [rsp+0x10], xmm1
00007f4e3fdd23e0  vmovaps [rsp+0x20], xmm2
00007f4e3fdd23e6  vmovaps [rsp+0x30], xmm3
00007f4e3fdd23ec  vmovaps [rsp+0x40], xmm4
00007f4e3fdd23f2  vmovaps [rsp+0x50], xmm5
00007f4e3fdd23f8  vmovaps [rsp+0x60], xmm6
00007f4e3fdd23fe  vmovaps [rsp+0x70], xmm7
00007f4e3fdd2404  vmovaps [rsp+0x80], xmm8
00007f4e3fdd240d  vmovaps [rsp+0x90], xmm9
00007f4e3fdd2416  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd241f  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd2428  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd2431  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd243a  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2443  sub rsp, 0x30
00007f4e3fdd2447  movaps [rsp], xmm13
00007f4e3fdd244c  movaps [rsp+0x10], xmm11
00007f4e3fdd2452  movaps [rsp+0x20], xmm1
00007f4e3fdd2457  lea rdi, [rsp]
00007f4e3fdd245b  mov esi, 0x00
00007f4e3fdd2460  mov rax, 0x5D97141E9530
00007f4e3fdd246a  call rax
00007f4e3fdd246c  movaps xmm13, [rsp]
00007f4e3fdd2471  add rsp, 0x30
00007f4e3fdd2475  vmovaps xmm0, [rsp]
00007f4e3fdd247a  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd2480  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2486  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd248c  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd2492  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd2498  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd249e  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd24a4  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd24ad  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd24b6  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd24bf  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd24c8  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd24d1  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd24da  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd24e3  add rsp, 0xF0
00007f4e3fdd24ea  pop r11
00007f4e3fdd24ec  pop r10
00007f4e3fdd24ee  pop r9
00007f4e3fdd24f0  pop r8
00007f4e3fdd24f2  pop rsi
00007f4e3fdd24f3  pop rdi
00007f4e3fdd24f4  pop rdx
00007f4e3fdd24f5  pop rcx
00007f4e3fdd24f6  pop rax
00007f4e3fdd24f7  add rsp, 0x08
00007f4e3fdd24fb  jmp 0x00007F4E3FDCFC76
00007f4e3fdd2500  call 0x00007F4E3FBFF430
00007f4e3fdd2505  jmp 0x00007F4E3FDCFC83
00007f4e3fdd250a  sub rsp, 0x08
00007f4e3fdd250e  push rax
00007f4e3fdd250f  push rcx
00007f4e3fdd2510  push rdx
00007f4e3fdd2511  push rdi
00007f4e3fdd2512  push rsi
00007f4e3fdd2513  push r8
00007f4e3fdd2515  push r9
00007f4e3fdd2517  push r10
00007f4e3fdd2519  push r11
00007f4e3fdd251b  sub rsp, 0xF0
00007f4e3fdd2522  vmovaps [rsp], xmm0
00007f4e3fdd2527  vmovaps [rsp+0x10], xmm1
00007f4e3fdd252d  vmovaps [rsp+0x20], xmm2
00007f4e3fdd2533  vmovaps [rsp+0x30], xmm3
00007f4e3fdd2539  vmovaps [rsp+0x40], xmm4
00007f4e3fdd253f  vmovaps [rsp+0x50], xmm5
00007f4e3fdd2545  vmovaps [rsp+0x60], xmm6
00007f4e3fdd254b  vmovaps [rsp+0x70], xmm7
00007f4e3fdd2551  vmovaps [rsp+0x80], xmm8
00007f4e3fdd255a  vmovaps [rsp+0x90], xmm9
00007f4e3fdd2563  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd256c  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd2575  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd257e  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd2587  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd2590  sub rsp, 0x30
00007f4e3fdd2594  movaps [rsp], xmm15
00007f4e3fdd2599  movaps [rsp+0x10], xmm11
00007f4e3fdd259f  movaps [rsp+0x20], xmm1
00007f4e3fdd25a4  lea rdi, [rsp]
00007f4e3fdd25a8  mov esi, 0x00
00007f4e3fdd25ad  mov rax, 0x5D97141E9530
00007f4e3fdd25b7  call rax
00007f4e3fdd25b9  movaps xmm15, [rsp]
00007f4e3fdd25be  add rsp, 0x30
00007f4e3fdd25c2  vmovaps xmm0, [rsp]
00007f4e3fdd25c7  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd25cd  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd25d3  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd25d9  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd25df  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd25e5  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd25eb  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd25f1  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd25fa  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd2603  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd260c  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd2615  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd261e  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd2627  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd2630  add rsp, 0xF0
00007f4e3fdd2637  pop r11
00007f4e3fdd2639  pop r10
00007f4e3fdd263b  pop r9
00007f4e3fdd263d  pop r8
00007f4e3fdd263f  pop rsi
00007f4e3fdd2640  pop rdi
00007f4e3fdd2641  pop rdx
00007f4e3fdd2642  pop rcx
00007f4e3fdd2643  pop rax
00007f4e3fdd2644  add rsp, 0x08
00007f4e3fdd2648  jmp 0x00007F4E3FDCFCBC
00007f4e3fdd264d  sub rsp, 0x08
00007f4e3fdd2651  push rax
00007f4e3fdd2652  push rcx
00007f4e3fdd2653  push rdx
00007f4e3fdd2654  push rdi
00007f4e3fdd2655  push rsi
00007f4e3fdd2656  push r8
00007f4e3fdd2658  push r9
00007f4e3fdd265a  push r10
00007f4e3fdd265c  push r11
00007f4e3fdd265e  sub rsp, 0xF0
00007f4e3fdd2665  vmovaps [rsp], xmm0
00007f4e3fdd266a  vmovaps [rsp+0x10], xmm1
00007f4e3fdd2670  vmovaps [rsp+0x20], xmm2
00007f4e3fdd2676  vmovaps [rsp+0x30], xmm3
00007f4e3fdd267c  vmovaps [rsp+0x40], xmm4
00007f4e3fdd2682  vmovaps [rsp+0x50], xmm5
00007f4e3fdd2688  vmovaps [rsp+0x60], xmm6
00007f4e3fdd268e  vmovaps [rsp+0x70], xmm7
00007f4e3fdd2694  vmovaps [rsp+0x80], xmm8
00007f4e3fdd269d  vmovaps [rsp+0x90], xmm9
00007f4e3fdd26a6  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd26af  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd26b8  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd26c1  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd26ca  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd26d3  sub rsp, 0x30
00007f4e3fdd26d7  movaps [rsp], xmm11
00007f4e3fdd26dc  movaps [rsp+0x10], xmm6
00007f4e3fdd26e1  movaps [rsp+0x20], xmm14
00007f4e3fdd26e7  lea rdi, [rsp]
00007f4e3fdd26eb  mov esi, 0x00
00007f4e3fdd26f0  mov rax, 0x5D97141E9530
00007f4e3fdd26fa  call rax
00007f4e3fdd26fc  movaps xmm11, [rsp]
00007f4e3fdd2701  add rsp, 0x30
00007f4e3fdd2705  vmovaps xmm0, [rsp]
00007f4e3fdd270a  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd2710  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2716  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd271c  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd2722  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd2728  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd272e  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd2734  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd273d  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd2746  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd274f  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd2758  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd2761  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd276a  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd2773  add rsp, 0xF0
00007f4e3fdd277a  pop r11
00007f4e3fdd277c  pop r10
00007f4e3fdd277e  pop r9
00007f4e3fdd2780  pop r8
00007f4e3fdd2782  pop rsi
00007f4e3fdd2783  pop rdi
00007f4e3fdd2784  pop rdx
00007f4e3fdd2785  pop rcx
00007f4e3fdd2786  pop rax
00007f4e3fdd2787  add rsp, 0x08
00007f4e3fdd278b  jmp 0x00007F4E3FDCFD34
00007f4e3fdd2790  call 0x00007F4E3FBFF430
00007f4e3fdd2795  jmp 0x00007F4E3FDCFD3E
00007f4e3fdd279a  sub rsp, 0x08
00007f4e3fdd279e  push rax
00007f4e3fdd279f  push rcx
00007f4e3fdd27a0  push rdx
00007f4e3fdd27a1  push rdi
00007f4e3fdd27a2  push rsi
00007f4e3fdd27a3  push r8
00007f4e3fdd27a5  push r9
00007f4e3fdd27a7  push r10
00007f4e3fdd27a9  push r11
00007f4e3fdd27ab  sub rsp, 0xF0
00007f4e3fdd27b2  vmovaps [rsp], xmm0
00007f4e3fdd27b7  vmovaps [rsp+0x10], xmm1
00007f4e3fdd27bd  vmovaps [rsp+0x20], xmm2
00007f4e3fdd27c3  vmovaps [rsp+0x30], xmm3
00007f4e3fdd27c9  vmovaps [rsp+0x40], xmm4
00007f4e3fdd27cf  vmovaps [rsp+0x50], xmm5
00007f4e3fdd27d5  vmovaps [rsp+0x60], xmm6
00007f4e3fdd27db  vmovaps [rsp+0x70], xmm7
00007f4e3fdd27e1  vmovaps [rsp+0x80], xmm8
00007f4e3fdd27ea  vmovaps [rsp+0x90], xmm9
00007f4e3fdd27f3  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd27fc  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd2805  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd280e  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd2817  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2820  sub rsp, 0x30
00007f4e3fdd2824  movaps [rsp], xmm14
00007f4e3fdd2829  movaps [rsp+0x10], xmm6
00007f4e3fdd282e  movaps [rsp+0x20], xmm2
00007f4e3fdd2833  lea rdi, [rsp]
00007f4e3fdd2837  mov esi, 0x00
00007f4e3fdd283c  mov rax, 0x5D97141E9530
00007f4e3fdd2846  call rax
00007f4e3fdd2848  movaps xmm14, [rsp]
00007f4e3fdd284d  add rsp, 0x30
00007f4e3fdd2851  vmovaps xmm0, [rsp]
00007f4e3fdd2856  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd285c  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2862  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd2868  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd286e  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd2874  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd287a  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd2880  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd2889  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd2892  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd289b  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd28a4  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd28ad  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd28b6  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd28bf  add rsp, 0xF0
00007f4e3fdd28c6  pop r11
00007f4e3fdd28c8  pop r10
00007f4e3fdd28ca  pop r9
00007f4e3fdd28cc  pop r8
00007f4e3fdd28ce  pop rsi
00007f4e3fdd28cf  pop rdi
00007f4e3fdd28d0  pop rdx
00007f4e3fdd28d1  pop rcx
00007f4e3fdd28d2  pop rax
00007f4e3fdd28d3  add rsp, 0x08
00007f4e3fdd28d7  jmp 0x00007F4E3FDCFD72
00007f4e3fdd28dc  sub rsp, 0x08
00007f4e3fdd28e0  push rax
00007f4e3fdd28e1  push rcx
00007f4e3fdd28e2  push rdx
00007f4e3fdd28e3  push rdi
00007f4e3fdd28e4  push rsi
00007f4e3fdd28e5  push r8
00007f4e3fdd28e7  push r9
00007f4e3fdd28e9  push r10
00007f4e3fdd28eb  push r11
00007f4e3fdd28ed  sub rsp, 0xF0
00007f4e3fdd28f4  vmovaps [rsp], xmm0
00007f4e3fdd28f9  vmovaps [rsp+0x10], xmm1
00007f4e3fdd28ff  vmovaps [rsp+0x20], xmm2
00007f4e3fdd2905  vmovaps [rsp+0x30], xmm3
00007f4e3fdd290b  vmovaps [rsp+0x40], xmm4
00007f4e3fdd2911  vmovaps [rsp+0x50], xmm5
00007f4e3fdd2917  vmovaps [rsp+0x60], xmm7
00007f4e3fdd291d  vmovaps [rsp+0x70], xmm8
00007f4e3fdd2923  vmovaps [rsp+0x80], xmm9
00007f4e3fdd292c  vmovaps [rsp+0x90], xmm10
00007f4e3fdd2935  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd293e  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd2947  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd2950  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd2959  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2962  sub rsp, 0x30
00007f4e3fdd2966  movaps [rsp], xmm6
00007f4e3fdd296a  movaps [rsp+0x10], xmm5
00007f4e3fdd296f  movaps [rsp+0x20], xmm1
00007f4e3fdd2974  lea rdi, [rsp]
00007f4e3fdd2978  mov esi, 0x00
00007f4e3fdd297d  mov rax, 0x5D97141E9530
00007f4e3fdd2987  call rax
00007f4e3fdd2989  movaps xmm6, [rsp]
00007f4e3fdd298d  add rsp, 0x30
00007f4e3fdd2991  vmovaps xmm0, [rsp]
00007f4e3fdd2996  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd299c  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd29a2  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd29a8  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd29ae  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd29b4  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd29ba  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd29c0  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd29c9  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd29d2  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd29db  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd29e4  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd29ed  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd29f6  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd29ff  add rsp, 0xF0
00007f4e3fdd2a06  pop r11
00007f4e3fdd2a08  pop r10
00007f4e3fdd2a0a  pop r9
00007f4e3fdd2a0c  pop r8
00007f4e3fdd2a0e  pop rsi
00007f4e3fdd2a0f  pop rdi
00007f4e3fdd2a10  pop rdx
00007f4e3fdd2a11  pop rcx
00007f4e3fdd2a12  pop rax
00007f4e3fdd2a13  add rsp, 0x08
00007f4e3fdd2a17  jmp 0x00007F4E3FDCFD98
00007f4e3fdd2a1c  sub rsp, 0x08
00007f4e3fdd2a20  push rax
00007f4e3fdd2a21  push rcx
00007f4e3fdd2a22  push rdx
00007f4e3fdd2a23  push rdi
00007f4e3fdd2a24  push rsi
00007f4e3fdd2a25  push r8
00007f4e3fdd2a27  push r9
00007f4e3fdd2a29  push r10
00007f4e3fdd2a2b  push r11
00007f4e3fdd2a2d  sub rsp, 0xF0
00007f4e3fdd2a34  vmovaps [rsp], xmm0
00007f4e3fdd2a39  vmovaps [rsp+0x10], xmm2
00007f4e3fdd2a3f  vmovaps [rsp+0x20], xmm3
00007f4e3fdd2a45  vmovaps [rsp+0x30], xmm4
00007f4e3fdd2a4b  vmovaps [rsp+0x40], xmm5
00007f4e3fdd2a51  vmovaps [rsp+0x50], xmm6
00007f4e3fdd2a57  vmovaps [rsp+0x60], xmm7
00007f4e3fdd2a5d  vmovaps [rsp+0x70], xmm8
00007f4e3fdd2a63  vmovaps [rsp+0x80], xmm9
00007f4e3fdd2a6c  vmovaps [rsp+0x90], xmm10
00007f4e3fdd2a75  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd2a7e  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd2a87  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd2a90  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd2a99  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2aa2  sub rsp, 0x30
00007f4e3fdd2aa6  movaps [rsp], xmm1
00007f4e3fdd2aaa  movaps [rsp+0x10], xmm5
00007f4e3fdd2aaf  movaps [rsp+0x20], xmm13
00007f4e3fdd2ab5  lea rdi, [rsp]
00007f4e3fdd2ab9  mov esi, 0x00
00007f4e3fdd2abe  mov rax, 0x5D97141E9530
00007f4e3fdd2ac8  call rax
00007f4e3fdd2aca  movaps xmm1, [rsp]
00007f4e3fdd2ace  add rsp, 0x30
00007f4e3fdd2ad2  vmovaps xmm0, [rsp]
00007f4e3fdd2ad7  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd2add  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd2ae3  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd2ae9  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd2aef  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd2af5  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd2afb  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd2b01  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd2b0a  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd2b13  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd2b1c  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd2b25  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd2b2e  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd2b37  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd2b40  add rsp, 0xF0
00007f4e3fdd2b47  pop r11
00007f4e3fdd2b49  pop r10
00007f4e3fdd2b4b  pop r9
00007f4e3fdd2b4d  pop r8
00007f4e3fdd2b4f  pop rsi
00007f4e3fdd2b50  pop rdi
00007f4e3fdd2b51  pop rdx
00007f4e3fdd2b52  pop rcx
00007f4e3fdd2b53  pop rax
00007f4e3fdd2b54  add rsp, 0x08
00007f4e3fdd2b58  jmp 0x00007F4E3FDCFDB6
00007f4e3fdd2b5d  sub rsp, 0x08
00007f4e3fdd2b61  push rax
00007f4e3fdd2b62  push rcx
00007f4e3fdd2b63  push rdx
00007f4e3fdd2b64  push rdi
00007f4e3fdd2b65  push rsi
00007f4e3fdd2b66  push r8
00007f4e3fdd2b68  push r9
00007f4e3fdd2b6a  push r10
00007f4e3fdd2b6c  push r11
00007f4e3fdd2b6e  sub rsp, 0xF0
00007f4e3fdd2b75  vmovaps [rsp], xmm0
00007f4e3fdd2b7a  vmovaps [rsp+0x10], xmm1
00007f4e3fdd2b80  vmovaps [rsp+0x20], xmm2
00007f4e3fdd2b86  vmovaps [rsp+0x30], xmm3
00007f4e3fdd2b8c  vmovaps [rsp+0x40], xmm4
00007f4e3fdd2b92  vmovaps [rsp+0x50], xmm6
00007f4e3fdd2b98  vmovaps [rsp+0x60], xmm7
00007f4e3fdd2b9e  vmovaps [rsp+0x70], xmm8
00007f4e3fdd2ba4  vmovaps [rsp+0x80], xmm9
00007f4e3fdd2bad  vmovaps [rsp+0x90], xmm10
00007f4e3fdd2bb6  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd2bbf  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd2bc8  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd2bd1  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd2bda  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2be3  sub rsp, 0x30
00007f4e3fdd2be7  movaps [rsp], xmm5
00007f4e3fdd2beb  movaps [rsp+0x10], xmm2
00007f4e3fdd2bf0  movaps [rsp+0x20], xmm13
00007f4e3fdd2bf6  lea rdi, [rsp]
00007f4e3fdd2bfa  mov esi, 0x00
00007f4e3fdd2bff  mov rax, 0x5D97141E9530
00007f4e3fdd2c09  call rax
00007f4e3fdd2c0b  movaps xmm5, [rsp]
00007f4e3fdd2c0f  add rsp, 0x30
00007f4e3fdd2c13  vmovaps xmm0, [rsp]
00007f4e3fdd2c18  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd2c1e  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2c24  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd2c2a  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd2c30  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd2c36  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd2c3c  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd2c42  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd2c4b  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd2c54  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd2c5d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd2c66  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd2c6f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd2c78  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd2c81  add rsp, 0xF0
00007f4e3fdd2c88  pop r11
00007f4e3fdd2c8a  pop r10
00007f4e3fdd2c8c  pop r9
00007f4e3fdd2c8e  pop r8
00007f4e3fdd2c90  pop rsi
00007f4e3fdd2c91  pop rdi
00007f4e3fdd2c92  pop rdx
00007f4e3fdd2c93  pop rcx
00007f4e3fdd2c94  pop rax
00007f4e3fdd2c95  add rsp, 0x08
00007f4e3fdd2c99  jmp 0x00007F4E3FDCFDEC
00007f4e3fdd2c9e  sub rsp, 0x08
00007f4e3fdd2ca2  push rax
00007f4e3fdd2ca3  push rcx
00007f4e3fdd2ca4  push rdx
00007f4e3fdd2ca5  push rdi
00007f4e3fdd2ca6  push rsi
00007f4e3fdd2ca7  push r8
00007f4e3fdd2ca9  push r9
00007f4e3fdd2cab  push r10
00007f4e3fdd2cad  push r11
00007f4e3fdd2caf  sub rsp, 0xF0
00007f4e3fdd2cb6  vmovaps [rsp], xmm0
00007f4e3fdd2cbb  vmovaps [rsp+0x10], xmm1
00007f4e3fdd2cc1  vmovaps [rsp+0x20], xmm2
00007f4e3fdd2cc7  vmovaps [rsp+0x30], xmm3
00007f4e3fdd2ccd  vmovaps [rsp+0x40], xmm4
00007f4e3fdd2cd3  vmovaps [rsp+0x50], xmm5
00007f4e3fdd2cd9  vmovaps [rsp+0x60], xmm6
00007f4e3fdd2cdf  vmovaps [rsp+0x70], xmm7
00007f4e3fdd2ce5  vmovaps [rsp+0x80], xmm8
00007f4e3fdd2cee  vmovaps [rsp+0x90], xmm9
00007f4e3fdd2cf7  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd2d00  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd2d09  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd2d12  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd2d1b  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2d24  sub rsp, 0x30
00007f4e3fdd2d28  movaps [rsp], xmm13
00007f4e3fdd2d2d  movaps [rsp+0x10], xmm10
00007f4e3fdd2d33  movaps [rsp+0x20], xmm1
00007f4e3fdd2d38  lea rdi, [rsp]
00007f4e3fdd2d3c  mov esi, 0x00
00007f4e3fdd2d41  mov rax, 0x5D97141E9530
00007f4e3fdd2d4b  call rax
00007f4e3fdd2d4d  movaps xmm13, [rsp]
00007f4e3fdd2d52  add rsp, 0x30
00007f4e3fdd2d56  vmovaps xmm0, [rsp]
00007f4e3fdd2d5b  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd2d61  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2d67  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd2d6d  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd2d73  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd2d79  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd2d7f  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd2d85  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd2d8e  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd2d97  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd2da0  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd2da9  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd2db2  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd2dbb  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd2dc4  add rsp, 0xF0
00007f4e3fdd2dcb  pop r11
00007f4e3fdd2dcd  pop r10
00007f4e3fdd2dcf  pop r9
00007f4e3fdd2dd1  pop r8
00007f4e3fdd2dd3  pop rsi
00007f4e3fdd2dd4  pop rdi
00007f4e3fdd2dd5  pop rdx
00007f4e3fdd2dd6  pop rcx
00007f4e3fdd2dd7  pop rax
00007f4e3fdd2dd8  add rsp, 0x08
00007f4e3fdd2ddc  jmp 0x00007F4E3FDCFE15
00007f4e3fdd2de1  sub rsp, 0x08
00007f4e3fdd2de5  push rax
00007f4e3fdd2de6  push rcx
00007f4e3fdd2de7  push rdx
00007f4e3fdd2de8  push rdi
00007f4e3fdd2de9  push rsi
00007f4e3fdd2dea  push r8
00007f4e3fdd2dec  push r9
00007f4e3fdd2dee  push r10
00007f4e3fdd2df0  push r11
00007f4e3fdd2df2  sub rsp, 0xF0
00007f4e3fdd2df9  vmovaps [rsp], xmm0
00007f4e3fdd2dfe  vmovaps [rsp+0x10], xmm2
00007f4e3fdd2e04  vmovaps [rsp+0x20], xmm3
00007f4e3fdd2e0a  vmovaps [rsp+0x30], xmm4
00007f4e3fdd2e10  vmovaps [rsp+0x40], xmm5
00007f4e3fdd2e16  vmovaps [rsp+0x50], xmm6
00007f4e3fdd2e1c  vmovaps [rsp+0x60], xmm7
00007f4e3fdd2e22  vmovaps [rsp+0x70], xmm8
00007f4e3fdd2e28  vmovaps [rsp+0x80], xmm9
00007f4e3fdd2e31  vmovaps [rsp+0x90], xmm10
00007f4e3fdd2e3a  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd2e43  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd2e4c  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd2e55  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd2e5e  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd2e67  sub rsp, 0x30
00007f4e3fdd2e6b  movaps [rsp], xmm1
00007f4e3fdd2e6f  movaps [rsp+0x10], xmm15
00007f4e3fdd2e75  movaps [rsp+0x20], xmm10
00007f4e3fdd2e7b  lea rdi, [rsp]
00007f4e3fdd2e7f  mov esi, 0x00
00007f4e3fdd2e84  mov rax, 0x5D97141E9530
00007f4e3fdd2e8e  call rax
00007f4e3fdd2e90  movaps xmm1, [rsp]
00007f4e3fdd2e94  add rsp, 0x30
00007f4e3fdd2e98  vmovaps xmm0, [rsp]
00007f4e3fdd2e9d  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd2ea3  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd2ea9  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd2eaf  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd2eb5  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd2ebb  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd2ec1  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd2ec7  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd2ed0  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd2ed9  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd2ee2  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd2eeb  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd2ef4  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd2efd  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd2f06  add rsp, 0xF0
00007f4e3fdd2f0d  pop r11
00007f4e3fdd2f0f  pop r10
00007f4e3fdd2f11  pop r9
00007f4e3fdd2f13  pop r8
00007f4e3fdd2f15  pop rsi
00007f4e3fdd2f16  pop rdi
00007f4e3fdd2f17  pop rdx
00007f4e3fdd2f18  pop rcx
00007f4e3fdd2f19  pop rax
00007f4e3fdd2f1a  add rsp, 0x08
00007f4e3fdd2f1e  jmp 0x00007F4E3FDCFE34
00007f4e3fdd2f23  sub rsp, 0x08
00007f4e3fdd2f27  push rax
00007f4e3fdd2f28  push rcx
00007f4e3fdd2f29  push rdx
00007f4e3fdd2f2a  push rdi
00007f4e3fdd2f2b  push rsi
00007f4e3fdd2f2c  push r8
00007f4e3fdd2f2e  push r9
00007f4e3fdd2f30  push r10
00007f4e3fdd2f32  push r11
00007f4e3fdd2f34  sub rsp, 0xF0
00007f4e3fdd2f3b  vmovaps [rsp], xmm0
00007f4e3fdd2f40  vmovaps [rsp+0x10], xmm1
00007f4e3fdd2f46  vmovaps [rsp+0x20], xmm2
00007f4e3fdd2f4c  vmovaps [rsp+0x30], xmm3
00007f4e3fdd2f52  vmovaps [rsp+0x40], xmm4
00007f4e3fdd2f58  vmovaps [rsp+0x50], xmm5
00007f4e3fdd2f5e  vmovaps [rsp+0x60], xmm6
00007f4e3fdd2f64  vmovaps [rsp+0x70], xmm7
00007f4e3fdd2f6a  vmovaps [rsp+0x80], xmm8
00007f4e3fdd2f73  vmovaps [rsp+0x90], xmm9
00007f4e3fdd2f7c  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd2f85  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd2f8e  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd2f97  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd2fa0  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd2fa9  sub rsp, 0x30
00007f4e3fdd2fad  movaps [rsp], xmm15
00007f4e3fdd2fb2  movaps [rsp+0x10], xmm10
00007f4e3fdd2fb8  movaps [rsp+0x20], xmm11
00007f4e3fdd2fbe  lea rdi, [rsp]
00007f4e3fdd2fc2  mov esi, 0x00
00007f4e3fdd2fc7  mov rax, 0x5D97141E9530
00007f4e3fdd2fd1  call rax
00007f4e3fdd2fd3  movaps xmm15, [rsp]
00007f4e3fdd2fd8  add rsp, 0x30
00007f4e3fdd2fdc  vmovaps xmm0, [rsp]
00007f4e3fdd2fe1  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd2fe7  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd2fed  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd2ff3  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd2ff9  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd2fff  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3005  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd300b  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd3014  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd301d  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd3026  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd302f  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd3038  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd3041  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd304a  add rsp, 0xF0
00007f4e3fdd3051  pop r11
00007f4e3fdd3053  pop r10
00007f4e3fdd3055  pop r9
00007f4e3fdd3057  pop r8
00007f4e3fdd3059  pop rsi
00007f4e3fdd305a  pop rdi
00007f4e3fdd305b  pop rdx
00007f4e3fdd305c  pop rcx
00007f4e3fdd305d  pop rax
00007f4e3fdd305e  add rsp, 0x08
00007f4e3fdd3062  jmp 0x00007F4E3FDCFE57
00007f4e3fdd3067  sub rsp, 0x08
00007f4e3fdd306b  push rax
00007f4e3fdd306c  push rcx
00007f4e3fdd306d  push rdx
00007f4e3fdd306e  push rdi
00007f4e3fdd306f  push rsi
00007f4e3fdd3070  push r8
00007f4e3fdd3072  push r9
00007f4e3fdd3074  push r10
00007f4e3fdd3076  push r11
00007f4e3fdd3078  sub rsp, 0xF0
00007f4e3fdd307f  vmovaps [rsp], xmm0
00007f4e3fdd3084  vmovaps [rsp+0x10], xmm1
00007f4e3fdd308a  vmovaps [rsp+0x20], xmm2
00007f4e3fdd3090  vmovaps [rsp+0x30], xmm3
00007f4e3fdd3096  vmovaps [rsp+0x40], xmm4
00007f4e3fdd309c  vmovaps [rsp+0x50], xmm5
00007f4e3fdd30a2  vmovaps [rsp+0x60], xmm6
00007f4e3fdd30a8  vmovaps [rsp+0x70], xmm7
00007f4e3fdd30ae  vmovaps [rsp+0x80], xmm8
00007f4e3fdd30b7  vmovaps [rsp+0x90], xmm9
00007f4e3fdd30c0  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd30c9  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd30d2  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd30db  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd30e4  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd30ed  sub rsp, 0x30
00007f4e3fdd30f1  movaps [rsp], xmm10
00007f4e3fdd30f6  movaps [rsp+0x10], xmm12
00007f4e3fdd30fc  movaps [rsp+0x20], xmm11
00007f4e3fdd3102  lea rdi, [rsp]
00007f4e3fdd3106  mov esi, 0x00
00007f4e3fdd310b  mov rax, 0x5D97141E9530
00007f4e3fdd3115  call rax
00007f4e3fdd3117  movaps xmm10, [rsp]
00007f4e3fdd311c  add rsp, 0x30
00007f4e3fdd3120  vmovaps xmm0, [rsp]
00007f4e3fdd3125  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd312b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd3131  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd3137  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd313d  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd3143  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3149  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd314f  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd3158  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd3161  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd316a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd3173  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd317c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd3185  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd318e  add rsp, 0xF0
00007f4e3fdd3195  pop r11
00007f4e3fdd3197  pop r10
00007f4e3fdd3199  pop r9
00007f4e3fdd319b  pop r8
00007f4e3fdd319d  pop rsi
00007f4e3fdd319e  pop rdi
00007f4e3fdd319f  pop rdx
00007f4e3fdd31a0  pop rcx
00007f4e3fdd31a1  pop rax
00007f4e3fdd31a2  add rsp, 0x08
00007f4e3fdd31a6  jmp 0x00007F4E3FDCFE80
00007f4e3fdd31ab  sub rsp, 0x08
00007f4e3fdd31af  push rax
00007f4e3fdd31b0  push rcx
00007f4e3fdd31b1  push rdx
00007f4e3fdd31b2  push rdi
00007f4e3fdd31b3  push rsi
00007f4e3fdd31b4  push r8
00007f4e3fdd31b6  push r9
00007f4e3fdd31b8  push r10
00007f4e3fdd31ba  push r11
00007f4e3fdd31bc  sub rsp, 0xF0
00007f4e3fdd31c3  vmovaps [rsp], xmm0
00007f4e3fdd31c8  vmovaps [rsp+0x10], xmm1
00007f4e3fdd31ce  vmovaps [rsp+0x20], xmm2
00007f4e3fdd31d4  vmovaps [rsp+0x30], xmm3
00007f4e3fdd31da  vmovaps [rsp+0x40], xmm4
00007f4e3fdd31e0  vmovaps [rsp+0x50], xmm5
00007f4e3fdd31e6  vmovaps [rsp+0x60], xmm6
00007f4e3fdd31ec  vmovaps [rsp+0x70], xmm7
00007f4e3fdd31f2  vmovaps [rsp+0x80], xmm8
00007f4e3fdd31fb  vmovaps [rsp+0x90], xmm9
00007f4e3fdd3204  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd320d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd3216  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd321f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd3228  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd3231  sub rsp, 0x30
00007f4e3fdd3235  movaps [rsp], xmm11
00007f4e3fdd323a  movaps [rsp+0x10], xmm2
00007f4e3fdd323f  movaps [rsp+0x20], xmm12
00007f4e3fdd3245  lea rdi, [rsp]
00007f4e3fdd3249  mov esi, 0x00
00007f4e3fdd324e  mov rax, 0x5D97141E9530
00007f4e3fdd3258  call rax
00007f4e3fdd325a  movaps xmm11, [rsp]
00007f4e3fdd325f  add rsp, 0x30
00007f4e3fdd3263  vmovaps xmm0, [rsp]
00007f4e3fdd3268  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd326e  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd3274  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd327a  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd3280  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd3286  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd328c  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd3292  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd329b  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd32a4  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd32ad  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd32b6  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd32bf  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd32c8  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd32d1  add rsp, 0xF0
00007f4e3fdd32d8  pop r11
00007f4e3fdd32da  pop r10
00007f4e3fdd32dc  pop r9
00007f4e3fdd32de  pop r8
00007f4e3fdd32e0  pop rsi
00007f4e3fdd32e1  pop rdi
00007f4e3fdd32e2  pop rdx
00007f4e3fdd32e3  pop rcx
00007f4e3fdd32e4  pop rax
00007f4e3fdd32e5  add rsp, 0x08
00007f4e3fdd32e9  jmp 0x00007F4E3FDCFEB8
00007f4e3fdd32ee  sub rsp, 0x08
00007f4e3fdd32f2  push rax
00007f4e3fdd32f3  push rcx
00007f4e3fdd32f4  push rdx
00007f4e3fdd32f5  push rdi
00007f4e3fdd32f6  push rsi
00007f4e3fdd32f7  push r8
00007f4e3fdd32f9  push r9
00007f4e3fdd32fb  push r10
00007f4e3fdd32fd  push r11
00007f4e3fdd32ff  sub rsp, 0xF0
00007f4e3fdd3306  vmovaps [rsp], xmm0
00007f4e3fdd330b  vmovaps [rsp+0x10], xmm2
00007f4e3fdd3311  vmovaps [rsp+0x20], xmm3
00007f4e3fdd3317  vmovaps [rsp+0x30], xmm4
00007f4e3fdd331d  vmovaps [rsp+0x40], xmm5
00007f4e3fdd3323  vmovaps [rsp+0x50], xmm6
00007f4e3fdd3329  vmovaps [rsp+0x60], xmm7
00007f4e3fdd332f  vmovaps [rsp+0x70], xmm8
00007f4e3fdd3335  vmovaps [rsp+0x80], xmm9
00007f4e3fdd333e  vmovaps [rsp+0x90], xmm10
00007f4e3fdd3347  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd3350  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd3359  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd3362  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd336b  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd3374  sub rsp, 0x30
00007f4e3fdd3378  movaps [rsp], xmm1
00007f4e3fdd337c  movaps [rsp+0x10], xmm14
00007f4e3fdd3382  movaps [rsp+0x20], xmm6
00007f4e3fdd3387  lea rdi, [rsp]
00007f4e3fdd338b  mov esi, 0x00
00007f4e3fdd3390  mov rax, 0x5D97141E9530
00007f4e3fdd339a  call rax
00007f4e3fdd339c  movaps xmm1, [rsp]
00007f4e3fdd33a0  add rsp, 0x30
00007f4e3fdd33a4  vmovaps xmm0, [rsp]
00007f4e3fdd33a9  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd33af  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd33b5  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd33bb  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd33c1  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd33c7  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd33cd  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd33d3  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd33dc  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd33e5  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd33ee  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd33f7  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd3400  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd3409  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3412  add rsp, 0xF0
00007f4e3fdd3419  pop r11
00007f4e3fdd341b  pop r10
00007f4e3fdd341d  pop r9
00007f4e3fdd341f  pop r8
00007f4e3fdd3421  pop rsi
00007f4e3fdd3422  pop rdi
00007f4e3fdd3423  pop rdx
00007f4e3fdd3424  pop rcx
00007f4e3fdd3425  pop rax
00007f4e3fdd3426  add rsp, 0x08
00007f4e3fdd342a  jmp 0x00007F4E3FDCFED1
00007f4e3fdd342f  sub rsp, 0x08
00007f4e3fdd3433  push rax
00007f4e3fdd3434  push rcx
00007f4e3fdd3435  push rdx
00007f4e3fdd3436  push rdi
00007f4e3fdd3437  push rsi
00007f4e3fdd3438  push r8
00007f4e3fdd343a  push r9
00007f4e3fdd343c  push r10
00007f4e3fdd343e  push r11
00007f4e3fdd3440  sub rsp, 0xF0
00007f4e3fdd3447  vmovaps [rsp], xmm0
00007f4e3fdd344c  vmovaps [rsp+0x10], xmm1
00007f4e3fdd3452  vmovaps [rsp+0x20], xmm2
00007f4e3fdd3458  vmovaps [rsp+0x30], xmm3
00007f4e3fdd345e  vmovaps [rsp+0x40], xmm4
00007f4e3fdd3464  vmovaps [rsp+0x50], xmm5
00007f4e3fdd346a  vmovaps [rsp+0x60], xmm6
00007f4e3fdd3470  vmovaps [rsp+0x70], xmm7
00007f4e3fdd3476  vmovaps [rsp+0x80], xmm8
00007f4e3fdd347f  vmovaps [rsp+0x90], xmm9
00007f4e3fdd3488  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd3491  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd349a  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd34a3  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd34ac  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd34b5  sub rsp, 0x30
00007f4e3fdd34b9  movaps [rsp], xmm14
00007f4e3fdd34be  movaps [rsp+0x10], xmm12
00007f4e3fdd34c4  movaps [rsp+0x20], xmm5
00007f4e3fdd34c9  lea rdi, [rsp]
00007f4e3fdd34cd  mov esi, 0x00
00007f4e3fdd34d2  mov rax, 0x5D97141E9530
00007f4e3fdd34dc  call rax
00007f4e3fdd34de  movaps xmm14, [rsp]
00007f4e3fdd34e3  add rsp, 0x30
00007f4e3fdd34e7  vmovaps xmm0, [rsp]
00007f4e3fdd34ec  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd34f2  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd34f8  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd34fe  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd3504  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd350a  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3510  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd3516  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd351f  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd3528  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd3531  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd353a  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd3543  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd354c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3555  add rsp, 0xF0
00007f4e3fdd355c  pop r11
00007f4e3fdd355e  pop r10
00007f4e3fdd3560  pop r9
00007f4e3fdd3562  pop r8
00007f4e3fdd3564  pop rsi
00007f4e3fdd3565  pop rdi
00007f4e3fdd3566  pop rdx
00007f4e3fdd3567  pop rcx
00007f4e3fdd3568  pop rax
00007f4e3fdd3569  add rsp, 0x08
00007f4e3fdd356d  jmp 0x00007F4E3FDCFEF1
00007f4e3fdd3572  sub rsp, 0x08
00007f4e3fdd3576  push rax
00007f4e3fdd3577  push rcx
00007f4e3fdd3578  push rdx
00007f4e3fdd3579  push rdi
00007f4e3fdd357a  push rsi
00007f4e3fdd357b  push r8
00007f4e3fdd357d  push r9
00007f4e3fdd357f  push r10
00007f4e3fdd3581  push r11
00007f4e3fdd3583  sub rsp, 0xF0
00007f4e3fdd358a  vmovaps [rsp], xmm0
00007f4e3fdd358f  vmovaps [rsp+0x10], xmm1
00007f4e3fdd3595  vmovaps [rsp+0x20], xmm2
00007f4e3fdd359b  vmovaps [rsp+0x30], xmm3
00007f4e3fdd35a1  vmovaps [rsp+0x40], xmm4
00007f4e3fdd35a7  vmovaps [rsp+0x50], xmm5
00007f4e3fdd35ad  vmovaps [rsp+0x60], xmm7
00007f4e3fdd35b3  vmovaps [rsp+0x70], xmm8
00007f4e3fdd35b9  vmovaps [rsp+0x80], xmm9
00007f4e3fdd35c2  vmovaps [rsp+0x90], xmm10
00007f4e3fdd35cb  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd35d4  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd35dd  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd35e6  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd35ef  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd35f8  sub rsp, 0x30
00007f4e3fdd35fc  movaps [rsp], xmm6
00007f4e3fdd3600  movaps [rsp+0x10], xmm9
00007f4e3fdd3606  movaps [rsp+0x20], xmm12
00007f4e3fdd360c  lea rdi, [rsp]
00007f4e3fdd3610  mov esi, 0x00
00007f4e3fdd3615  mov rax, 0x5D97141E9530
00007f4e3fdd361f  call rax
00007f4e3fdd3621  movaps xmm6, [rsp]
00007f4e3fdd3625  add rsp, 0x30
00007f4e3fdd3629  vmovaps xmm0, [rsp]
00007f4e3fdd362e  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd3634  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd363a  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd3640  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd3646  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd364c  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd3652  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd3658  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd3661  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd366a  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd3673  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd367c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd3685  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd368e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3697  add rsp, 0xF0
00007f4e3fdd369e  pop r11
00007f4e3fdd36a0  pop r10
00007f4e3fdd36a2  pop r9
00007f4e3fdd36a4  pop r8
00007f4e3fdd36a6  pop rsi
00007f4e3fdd36a7  pop rdi
00007f4e3fdd36a8  pop rdx
00007f4e3fdd36a9  pop rcx
00007f4e3fdd36aa  pop rax
00007f4e3fdd36ab  add rsp, 0x08
00007f4e3fdd36af  jmp 0x00007F4E3FDCFF19
00007f4e3fdd36b4  sub rsp, 0x08
00007f4e3fdd36b8  push rax
00007f4e3fdd36b9  push rcx
00007f4e3fdd36ba  push rdx
00007f4e3fdd36bb  push rdi
00007f4e3fdd36bc  push rsi
00007f4e3fdd36bd  push r8
00007f4e3fdd36bf  push r9
00007f4e3fdd36c1  push r10
00007f4e3fdd36c3  push r11
00007f4e3fdd36c5  sub rsp, 0xF0
00007f4e3fdd36cc  vmovaps [rsp], xmm0
00007f4e3fdd36d1  vmovaps [rsp+0x10], xmm1
00007f4e3fdd36d7  vmovaps [rsp+0x20], xmm2
00007f4e3fdd36dd  vmovaps [rsp+0x30], xmm3
00007f4e3fdd36e3  vmovaps [rsp+0x40], xmm4
00007f4e3fdd36e9  vmovaps [rsp+0x50], xmm5
00007f4e3fdd36ef  vmovaps [rsp+0x60], xmm6
00007f4e3fdd36f5  vmovaps [rsp+0x70], xmm7
00007f4e3fdd36fb  vmovaps [rsp+0x80], xmm8
00007f4e3fdd3704  vmovaps [rsp+0x90], xmm9
00007f4e3fdd370d  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd3716  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd371f  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd3728  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd3731  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd373a  sub rsp, 0x30
00007f4e3fdd373e  movaps [rsp], xmm12
00007f4e3fdd3743  movaps [rsp+0x10], xmm15
00007f4e3fdd3749  movaps [rsp+0x20], xmm13
00007f4e3fdd374f  lea rdi, [rsp]
00007f4e3fdd3753  mov esi, 0x00
00007f4e3fdd3758  mov rax, 0x5D97141E9530
00007f4e3fdd3762  call rax
00007f4e3fdd3764  movaps xmm12, [rsp]
00007f4e3fdd3769  add rsp, 0x30
00007f4e3fdd376d  vmovaps xmm0, [rsp]
00007f4e3fdd3772  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd3778  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd377e  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd3784  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd378a  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd3790  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3796  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd379c  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd37a5  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd37ae  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd37b7  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd37c0  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd37c9  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd37d2  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd37db  add rsp, 0xF0
00007f4e3fdd37e2  pop r11
00007f4e3fdd37e4  pop r10
00007f4e3fdd37e6  pop r9
00007f4e3fdd37e8  pop r8
00007f4e3fdd37ea  pop rsi
00007f4e3fdd37eb  pop rdi
00007f4e3fdd37ec  pop rdx
00007f4e3fdd37ed  pop rcx
00007f4e3fdd37ee  pop rax
00007f4e3fdd37ef  add rsp, 0x08
00007f4e3fdd37f3  jmp 0x00007F4E3FDCFF34
00007f4e3fdd37f8  sub rsp, 0x08
00007f4e3fdd37fc  push rax
00007f4e3fdd37fd  push rcx
00007f4e3fdd37fe  push rdx
00007f4e3fdd37ff  push rdi
00007f4e3fdd3800  push rsi
00007f4e3fdd3801  push r8
00007f4e3fdd3803  push r9
00007f4e3fdd3805  push r10
00007f4e3fdd3807  push r11
00007f4e3fdd3809  sub rsp, 0xF0
00007f4e3fdd3810  vmovaps [rsp], xmm0
00007f4e3fdd3815  vmovaps [rsp+0x10], xmm1
00007f4e3fdd381b  vmovaps [rsp+0x20], xmm2
00007f4e3fdd3821  vmovaps [rsp+0x30], xmm3
00007f4e3fdd3827  vmovaps [rsp+0x40], xmm4
00007f4e3fdd382d  vmovaps [rsp+0x50], xmm5
00007f4e3fdd3833  vmovaps [rsp+0x60], xmm6
00007f4e3fdd3839  vmovaps [rsp+0x70], xmm7
00007f4e3fdd383f  vmovaps [rsp+0x80], xmm8
00007f4e3fdd3848  vmovaps [rsp+0x90], xmm9
00007f4e3fdd3851  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd385a  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd3863  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd386c  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd3875  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd387e  sub rsp, 0x30
00007f4e3fdd3882  movaps [rsp], xmm15
00007f4e3fdd3887  movaps [rsp+0x10], xmm13
00007f4e3fdd388d  movaps [rsp+0x20], xmm10
00007f4e3fdd3893  lea rdi, [rsp]
00007f4e3fdd3897  mov esi, 0x00
00007f4e3fdd389c  mov rax, 0x5D97141E9530
00007f4e3fdd38a6  call rax
00007f4e3fdd38a8  movaps xmm15, [rsp]
00007f4e3fdd38ad  add rsp, 0x30
00007f4e3fdd38b1  vmovaps xmm0, [rsp]
00007f4e3fdd38b6  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd38bc  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd38c2  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd38c8  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd38ce  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd38d4  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd38da  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd38e0  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd38e9  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd38f2  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd38fb  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd3904  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd390d  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd3916  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd391f  add rsp, 0xF0
00007f4e3fdd3926  pop r11
00007f4e3fdd3928  pop r10
00007f4e3fdd392a  pop r9
00007f4e3fdd392c  pop r8
00007f4e3fdd392e  pop rsi
00007f4e3fdd392f  pop rdi
00007f4e3fdd3930  pop rdx
00007f4e3fdd3931  pop rcx
00007f4e3fdd3932  pop rax
00007f4e3fdd3933  add rsp, 0x08
00007f4e3fdd3937  jmp 0x00007F4E3FDCFF55
00007f4e3fdd393c  call 0x00007F4E3FC0C260
00007f4e3fdd3941  jmp 0x00007F4E3FDCFFB0
00007f4e3fdd3946  sub rsp, 0x08
00007f4e3fdd394a  push rax
00007f4e3fdd394b  push rcx
00007f4e3fdd394c  push rdx
00007f4e3fdd394d  push rdi
00007f4e3fdd394e  push rsi
00007f4e3fdd394f  push r8
00007f4e3fdd3951  push r9
00007f4e3fdd3953  push r10
00007f4e3fdd3955  push r11
00007f4e3fdd3957  sub rsp, 0xF0
00007f4e3fdd395e  vmovaps [rsp], xmm0
00007f4e3fdd3963  vmovaps [rsp+0x10], xmm1
00007f4e3fdd3969  vmovaps [rsp+0x20], xmm2
00007f4e3fdd396f  vmovaps [rsp+0x30], xmm3
00007f4e3fdd3975  vmovaps [rsp+0x40], xmm4
00007f4e3fdd397b  vmovaps [rsp+0x50], xmm5
00007f4e3fdd3981  vmovaps [rsp+0x60], xmm6
00007f4e3fdd3987  vmovaps [rsp+0x70], xmm7
00007f4e3fdd398d  vmovaps [rsp+0x80], xmm8
00007f4e3fdd3996  vmovaps [rsp+0x90], xmm10
00007f4e3fdd399f  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd39a8  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd39b1  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd39ba  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd39c3  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd39cc  sub rsp, 0x30
00007f4e3fdd39d0  movaps [rsp], xmm9
00007f4e3fdd39d5  movaps [rsp+0x10], xmm8
00007f4e3fdd39db  movaps [rsp+0x20], xmm10
00007f4e3fdd39e1  lea rdi, [rsp]
00007f4e3fdd39e5  mov esi, 0x00
00007f4e3fdd39ea  mov rax, 0x5D97141E9530
00007f4e3fdd39f4  call rax
00007f4e3fdd39f6  movaps xmm9, [rsp]
00007f4e3fdd39fb  add rsp, 0x30
00007f4e3fdd39ff  vmovaps xmm0, [rsp]
00007f4e3fdd3a04  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd3a0a  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd3a10  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd3a16  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd3a1c  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd3a22  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3a28  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd3a2e  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd3a37  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd3a40  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd3a49  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd3a52  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd3a5b  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd3a64  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3a6d  add rsp, 0xF0
00007f4e3fdd3a74  pop r11
00007f4e3fdd3a76  pop r10
00007f4e3fdd3a78  pop r9
00007f4e3fdd3a7a  pop r8
00007f4e3fdd3a7c  pop rsi
00007f4e3fdd3a7d  pop rdi
00007f4e3fdd3a7e  pop rdx
00007f4e3fdd3a7f  pop rcx
00007f4e3fdd3a80  pop rax
00007f4e3fdd3a81  add rsp, 0x08
00007f4e3fdd3a85  jmp 0x00007F4E3FDCFFE1
00007f4e3fdd3a8a  sub rsp, 0x08
00007f4e3fdd3a8e  push rax
00007f4e3fdd3a8f  push rcx
00007f4e3fdd3a90  push rdx
00007f4e3fdd3a91  push rdi
00007f4e3fdd3a92  push rsi
00007f4e3fdd3a93  push r8
00007f4e3fdd3a95  push r9
00007f4e3fdd3a97  push r10
00007f4e3fdd3a99  push r11
00007f4e3fdd3a9b  sub rsp, 0xF0
00007f4e3fdd3aa2  vmovaps [rsp], xmm0
00007f4e3fdd3aa7  vmovaps [rsp+0x10], xmm1
00007f4e3fdd3aad  vmovaps [rsp+0x20], xmm2
00007f4e3fdd3ab3  vmovaps [rsp+0x30], xmm3
00007f4e3fdd3ab9  vmovaps [rsp+0x40], xmm4
00007f4e3fdd3abf  vmovaps [rsp+0x50], xmm5
00007f4e3fdd3ac5  vmovaps [rsp+0x60], xmm6
00007f4e3fdd3acb  vmovaps [rsp+0x70], xmm7
00007f4e3fdd3ad1  vmovaps [rsp+0x80], xmm8
00007f4e3fdd3ada  vmovaps [rsp+0x90], xmm9
00007f4e3fdd3ae3  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd3aec  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd3af5  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd3afe  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd3b07  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd3b10  sub rsp, 0x30
00007f4e3fdd3b14  movaps [rsp], xmm10
00007f4e3fdd3b19  movaps [rsp+0x10], xmm1
00007f4e3fdd3b1e  movaps [rsp+0x20], xmm11
00007f4e3fdd3b24  lea rdi, [rsp]
00007f4e3fdd3b28  mov esi, 0x00
00007f4e3fdd3b2d  mov rax, 0x5D97141E9530
00007f4e3fdd3b37  call rax
00007f4e3fdd3b39  movaps xmm10, [rsp]
00007f4e3fdd3b3e  add rsp, 0x30
00007f4e3fdd3b42  vmovaps xmm0, [rsp]
00007f4e3fdd3b47  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd3b4d  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd3b53  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd3b59  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd3b5f  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd3b65  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3b6b  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd3b71  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd3b7a  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd3b83  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd3b8c  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd3b95  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd3b9e  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd3ba7  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3bb0  add rsp, 0xF0
00007f4e3fdd3bb7  pop r11
00007f4e3fdd3bb9  pop r10
00007f4e3fdd3bbb  pop r9
00007f4e3fdd3bbd  pop r8
00007f4e3fdd3bbf  pop rsi
00007f4e3fdd3bc0  pop rdi
00007f4e3fdd3bc1  pop rdx
00007f4e3fdd3bc2  pop rcx
00007f4e3fdd3bc3  pop rax
00007f4e3fdd3bc4  add rsp, 0x08
00007f4e3fdd3bc8  jmp 0x00007F4E3FDCFFFC
00007f4e3fdd3bcd  sub rsp, 0x08
00007f4e3fdd3bd1  push rax
00007f4e3fdd3bd2  push rcx
00007f4e3fdd3bd3  push rdx
00007f4e3fdd3bd4  push rdi
00007f4e3fdd3bd5  push rsi
00007f4e3fdd3bd6  push r8
00007f4e3fdd3bd8  push r9
00007f4e3fdd3bda  push r10
00007f4e3fdd3bdc  push r11
00007f4e3fdd3bde  sub rsp, 0xF0
00007f4e3fdd3be5  vmovaps [rsp], xmm0
00007f4e3fdd3bea  vmovaps [rsp+0x10], xmm2
00007f4e3fdd3bf0  vmovaps [rsp+0x20], xmm3
00007f4e3fdd3bf6  vmovaps [rsp+0x30], xmm4
00007f4e3fdd3bfc  vmovaps [rsp+0x40], xmm5
00007f4e3fdd3c02  vmovaps [rsp+0x50], xmm6
00007f4e3fdd3c08  vmovaps [rsp+0x60], xmm7
00007f4e3fdd3c0e  vmovaps [rsp+0x70], xmm8
00007f4e3fdd3c14  vmovaps [rsp+0x80], xmm9
00007f4e3fdd3c1d  vmovaps [rsp+0x90], xmm10
00007f4e3fdd3c26  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd3c2f  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd3c38  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd3c41  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd3c4a  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd3c53  sub rsp, 0x30
00007f4e3fdd3c57  movaps [rsp], xmm1
00007f4e3fdd3c5b  movaps [rsp+0x10], xmm14
00007f4e3fdd3c61  movaps [rsp+0x20], xmm6
00007f4e3fdd3c66  lea rdi, [rsp]
00007f4e3fdd3c6a  mov esi, 0x00
00007f4e3fdd3c6f  mov rax, 0x5D97141E9530
00007f4e3fdd3c79  call rax
00007f4e3fdd3c7b  movaps xmm1, [rsp]
00007f4e3fdd3c7f  add rsp, 0x30
00007f4e3fdd3c83  vmovaps xmm0, [rsp]
00007f4e3fdd3c88  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd3c8e  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd3c94  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd3c9a  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd3ca0  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd3ca6  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd3cac  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd3cb2  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd3cbb  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd3cc4  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd3ccd  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd3cd6  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd3cdf  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd3ce8  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3cf1  add rsp, 0xF0
00007f4e3fdd3cf8  pop r11
00007f4e3fdd3cfa  pop r10
00007f4e3fdd3cfc  pop r9
00007f4e3fdd3cfe  pop r8
00007f4e3fdd3d00  pop rsi
00007f4e3fdd3d01  pop rdi
00007f4e3fdd3d02  pop rdx
00007f4e3fdd3d03  pop rcx
00007f4e3fdd3d04  pop rax
00007f4e3fdd3d05  add rsp, 0x08
00007f4e3fdd3d09  jmp 0x00007F4E3FDD0015
00007f4e3fdd3d0e  sub rsp, 0x08
00007f4e3fdd3d12  push rax
00007f4e3fdd3d13  push rcx
00007f4e3fdd3d14  push rdx
00007f4e3fdd3d15  push rdi
00007f4e3fdd3d16  push rsi
00007f4e3fdd3d17  push r8
00007f4e3fdd3d19  push r9
00007f4e3fdd3d1b  push r10
00007f4e3fdd3d1d  push r11
00007f4e3fdd3d1f  sub rsp, 0xF0
00007f4e3fdd3d26  vmovaps [rsp], xmm0
00007f4e3fdd3d2b  vmovaps [rsp+0x10], xmm1
00007f4e3fdd3d31  vmovaps [rsp+0x20], xmm2
00007f4e3fdd3d37  vmovaps [rsp+0x30], xmm3
00007f4e3fdd3d3d  vmovaps [rsp+0x40], xmm4
00007f4e3fdd3d43  vmovaps [rsp+0x50], xmm5
00007f4e3fdd3d49  vmovaps [rsp+0x60], xmm6
00007f4e3fdd3d4f  vmovaps [rsp+0x70], xmm7
00007f4e3fdd3d55  vmovaps [rsp+0x80], xmm8
00007f4e3fdd3d5e  vmovaps [rsp+0x90], xmm9
00007f4e3fdd3d67  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd3d70  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd3d79  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd3d82  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd3d8b  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd3d94  sub rsp, 0x30
00007f4e3fdd3d98  movaps [rsp], xmm11
00007f4e3fdd3d9d  movaps [rsp+0x10], xmm13
00007f4e3fdd3da3  movaps [rsp+0x20], xmm14
00007f4e3fdd3da9  lea rdi, [rsp]
00007f4e3fdd3dad  mov esi, 0x00
00007f4e3fdd3db2  mov rax, 0x5D97141E9530
00007f4e3fdd3dbc  call rax
00007f4e3fdd3dbe  movaps xmm11, [rsp]
00007f4e3fdd3dc3  add rsp, 0x30
00007f4e3fdd3dc7  vmovaps xmm0, [rsp]
00007f4e3fdd3dcc  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd3dd2  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd3dd8  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd3dde  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd3de4  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd3dea  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3df0  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd3df6  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd3dff  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd3e08  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd3e11  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd3e1a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd3e23  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd3e2c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3e35  add rsp, 0xF0
00007f4e3fdd3e3c  pop r11
00007f4e3fdd3e3e  pop r10
00007f4e3fdd3e40  pop r9
00007f4e3fdd3e42  pop r8
00007f4e3fdd3e44  pop rsi
00007f4e3fdd3e45  pop rdi
00007f4e3fdd3e46  pop rdx
00007f4e3fdd3e47  pop rcx
00007f4e3fdd3e48  pop rax
00007f4e3fdd3e49  add rsp, 0x08
00007f4e3fdd3e4d  jmp 0x00007F4E3FDD003F
00007f4e3fdd3e52  sub rsp, 0x08
00007f4e3fdd3e56  push rax
00007f4e3fdd3e57  push rcx
00007f4e3fdd3e58  push rdx
00007f4e3fdd3e59  push rdi
00007f4e3fdd3e5a  push rsi
00007f4e3fdd3e5b  push r8
00007f4e3fdd3e5d  push r9
00007f4e3fdd3e5f  push r10
00007f4e3fdd3e61  push r11
00007f4e3fdd3e63  sub rsp, 0xF0
00007f4e3fdd3e6a  vmovaps [rsp], xmm0
00007f4e3fdd3e6f  vmovaps [rsp+0x10], xmm1
00007f4e3fdd3e75  vmovaps [rsp+0x20], xmm2
00007f4e3fdd3e7b  vmovaps [rsp+0x30], xmm3
00007f4e3fdd3e81  vmovaps [rsp+0x40], xmm4
00007f4e3fdd3e87  vmovaps [rsp+0x50], xmm5
00007f4e3fdd3e8d  vmovaps [rsp+0x60], xmm6
00007f4e3fdd3e93  vmovaps [rsp+0x70], xmm7
00007f4e3fdd3e99  vmovaps [rsp+0x80], xmm8
00007f4e3fdd3ea2  vmovaps [rsp+0x90], xmm9
00007f4e3fdd3eab  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd3eb4  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd3ebd  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd3ec6  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd3ecf  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd3ed8  sub rsp, 0x30
00007f4e3fdd3edc  movaps [rsp], xmm13
00007f4e3fdd3ee1  movaps [rsp+0x10], xmm8
00007f4e3fdd3ee7  movaps [rsp+0x20], xmm14
00007f4e3fdd3eed  lea rdi, [rsp]
00007f4e3fdd3ef1  mov esi, 0x00
00007f4e3fdd3ef6  mov rax, 0x5D97141E9530
00007f4e3fdd3f00  call rax
00007f4e3fdd3f02  movaps xmm13, [rsp]
00007f4e3fdd3f07  add rsp, 0x30
00007f4e3fdd3f0b  vmovaps xmm0, [rsp]
00007f4e3fdd3f10  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd3f16  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd3f1c  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd3f22  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd3f28  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd3f2e  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd3f34  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd3f3a  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd3f43  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd3f4c  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd3f55  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd3f5e  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd3f67  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd3f70  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd3f79  add rsp, 0xF0
00007f4e3fdd3f80  pop r11
00007f4e3fdd3f82  pop r10
00007f4e3fdd3f84  pop r9
00007f4e3fdd3f86  pop r8
00007f4e3fdd3f88  pop rsi
00007f4e3fdd3f89  pop rdi
00007f4e3fdd3f8a  pop rdx
00007f4e3fdd3f8b  pop rcx
00007f4e3fdd3f8c  pop rax
00007f4e3fdd3f8d  add rsp, 0x08
00007f4e3fdd3f91  jmp 0x00007F4E3FDD006E
00007f4e3fdd3f96  sub rsp, 0x08
00007f4e3fdd3f9a  push rax
00007f4e3fdd3f9b  push rcx
00007f4e3fdd3f9c  push rdx
00007f4e3fdd3f9d  push rdi
00007f4e3fdd3f9e  push rsi
00007f4e3fdd3f9f  push r8
00007f4e3fdd3fa1  push r9
00007f4e3fdd3fa3  push r10
00007f4e3fdd3fa5  push r11
00007f4e3fdd3fa7  sub rsp, 0xF0
00007f4e3fdd3fae  vmovaps [rsp], xmm0
00007f4e3fdd3fb3  vmovaps [rsp+0x10], xmm1
00007f4e3fdd3fb9  vmovaps [rsp+0x20], xmm2
00007f4e3fdd3fbf  vmovaps [rsp+0x30], xmm3
00007f4e3fdd3fc5  vmovaps [rsp+0x40], xmm4
00007f4e3fdd3fcb  vmovaps [rsp+0x50], xmm5
00007f4e3fdd3fd1  vmovaps [rsp+0x60], xmm6
00007f4e3fdd3fd7  vmovaps [rsp+0x70], xmm7
00007f4e3fdd3fdd  vmovaps [rsp+0x80], xmm9
00007f4e3fdd3fe6  vmovaps [rsp+0x90], xmm10
00007f4e3fdd3fef  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd3ff8  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd4001  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd400a  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd4013  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd401c  sub rsp, 0x30
00007f4e3fdd4020  movaps [rsp], xmm8
00007f4e3fdd4025  movaps [rsp+0x10], xmm7
00007f4e3fdd402a  movaps [rsp+0x20], xmm14
00007f4e3fdd4030  lea rdi, [rsp]
00007f4e3fdd4034  mov esi, 0x00
00007f4e3fdd4039  mov rax, 0x5D97141E9530
00007f4e3fdd4043  call rax
00007f4e3fdd4045  movaps xmm8, [rsp]
00007f4e3fdd404a  add rsp, 0x30
00007f4e3fdd404e  vmovaps xmm0, [rsp]
00007f4e3fdd4053  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4059  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd405f  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd4065  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd406b  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd4071  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd4077  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd407d  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd4086  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd408f  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd4098  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd40a1  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd40aa  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd40b3  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd40bc  add rsp, 0xF0
00007f4e3fdd40c3  pop r11
00007f4e3fdd40c5  pop r10
00007f4e3fdd40c7  pop r9
00007f4e3fdd40c9  pop r8
00007f4e3fdd40cb  pop rsi
00007f4e3fdd40cc  pop rdi
00007f4e3fdd40cd  pop rdx
00007f4e3fdd40ce  pop rcx
00007f4e3fdd40cf  pop rax
00007f4e3fdd40d0  add rsp, 0x08
00007f4e3fdd40d4  jmp 0x00007F4E3FDD0094
00007f4e3fdd40d9  sub rsp, 0x08
00007f4e3fdd40dd  push rax
00007f4e3fdd40de  push rcx
00007f4e3fdd40df  push rdx
00007f4e3fdd40e0  push rdi
00007f4e3fdd40e1  push rsi
00007f4e3fdd40e2  push r8
00007f4e3fdd40e4  push r9
00007f4e3fdd40e6  push r10
00007f4e3fdd40e8  push r11
00007f4e3fdd40ea  sub rsp, 0xF0
00007f4e3fdd40f1  vmovaps [rsp], xmm0
00007f4e3fdd40f6  vmovaps [rsp+0x10], xmm1
00007f4e3fdd40fc  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4102  vmovaps [rsp+0x30], xmm3
00007f4e3fdd4108  vmovaps [rsp+0x40], xmm4
00007f4e3fdd410e  vmovaps [rsp+0x50], xmm5
00007f4e3fdd4114  vmovaps [rsp+0x60], xmm6
00007f4e3fdd411a  vmovaps [rsp+0x70], xmm7
00007f4e3fdd4120  vmovaps [rsp+0x80], xmm8
00007f4e3fdd4129  vmovaps [rsp+0x90], xmm9
00007f4e3fdd4132  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd413b  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd4144  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd414d  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd4156  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd415f  sub rsp, 0x30
00007f4e3fdd4163  movaps [rsp], xmm14
00007f4e3fdd4168  movaps [rsp+0x10], xmm12
00007f4e3fdd416e  movaps [rsp+0x20], xmm9
00007f4e3fdd4174  lea rdi, [rsp]
00007f4e3fdd4178  mov esi, 0x00
00007f4e3fdd417d  mov rax, 0x5D97141E9530
00007f4e3fdd4187  call rax
00007f4e3fdd4189  movaps xmm14, [rsp]
00007f4e3fdd418e  add rsp, 0x30
00007f4e3fdd4192  vmovaps xmm0, [rsp]
00007f4e3fdd4197  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd419d  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd41a3  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd41a9  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd41af  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd41b5  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd41bb  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd41c1  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd41ca  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd41d3  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd41dc  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd41e5  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd41ee  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd41f7  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4200  add rsp, 0xF0
00007f4e3fdd4207  pop r11
00007f4e3fdd4209  pop r10
00007f4e3fdd420b  pop r9
00007f4e3fdd420d  pop r8
00007f4e3fdd420f  pop rsi
00007f4e3fdd4210  pop rdi
00007f4e3fdd4211  pop rdx
00007f4e3fdd4212  pop rcx
00007f4e3fdd4213  pop rax
00007f4e3fdd4214  add rsp, 0x08
00007f4e3fdd4218  jmp 0x00007F4E3FDD00AE
00007f4e3fdd421d  sub rsp, 0x08
00007f4e3fdd4221  push rax
00007f4e3fdd4222  push rcx
00007f4e3fdd4223  push rdx
00007f4e3fdd4224  push rdi
00007f4e3fdd4225  push rsi
00007f4e3fdd4226  push r8
00007f4e3fdd4228  push r9
00007f4e3fdd422a  push r10
00007f4e3fdd422c  push r11
00007f4e3fdd422e  sub rsp, 0xF0
00007f4e3fdd4235  vmovaps [rsp], xmm0
00007f4e3fdd423a  vmovaps [rsp+0x10], xmm1
00007f4e3fdd4240  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4246  vmovaps [rsp+0x30], xmm3
00007f4e3fdd424c  vmovaps [rsp+0x40], xmm4
00007f4e3fdd4252  vmovaps [rsp+0x50], xmm5
00007f4e3fdd4258  vmovaps [rsp+0x60], xmm6
00007f4e3fdd425e  vmovaps [rsp+0x70], xmm7
00007f4e3fdd4264  vmovaps [rsp+0x80], xmm8
00007f4e3fdd426d  vmovaps [rsp+0x90], xmm10
00007f4e3fdd4276  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd427f  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd4288  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd4291  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd429a  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd42a3  sub rsp, 0x30
00007f4e3fdd42a7  movaps [rsp], xmm9
00007f4e3fdd42ac  movaps [rsp+0x10], xmm7
00007f4e3fdd42b1  movaps [rsp+0x20], xmm12
00007f4e3fdd42b7  lea rdi, [rsp]
00007f4e3fdd42bb  mov esi, 0x00
00007f4e3fdd42c0  mov rax, 0x5D97141E9530
00007f4e3fdd42ca  call rax
00007f4e3fdd42cc  movaps xmm9, [rsp]
00007f4e3fdd42d1  add rsp, 0x30
00007f4e3fdd42d5  vmovaps xmm0, [rsp]
00007f4e3fdd42da  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd42e0  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd42e6  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd42ec  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd42f2  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd42f8  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd42fe  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd4304  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd430d  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd4316  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd431f  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd4328  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd4331  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd433a  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4343  add rsp, 0xF0
00007f4e3fdd434a  pop r11
00007f4e3fdd434c  pop r10
00007f4e3fdd434e  pop r9
00007f4e3fdd4350  pop r8
00007f4e3fdd4352  pop rsi
00007f4e3fdd4353  pop rdi
00007f4e3fdd4354  pop rdx
00007f4e3fdd4355  pop rcx
00007f4e3fdd4356  pop rax
00007f4e3fdd4357  add rsp, 0x08
00007f4e3fdd435b  jmp 0x00007F4E3FDD00DD
00007f4e3fdd4360  sub rsp, 0x08
00007f4e3fdd4364  push rax
00007f4e3fdd4365  push rcx
00007f4e3fdd4366  push rdx
00007f4e3fdd4367  push rdi
00007f4e3fdd4368  push rsi
00007f4e3fdd4369  push r8
00007f4e3fdd436b  push r9
00007f4e3fdd436d  push r10
00007f4e3fdd436f  push r11
00007f4e3fdd4371  sub rsp, 0xF0
00007f4e3fdd4378  vmovaps [rsp], xmm0
00007f4e3fdd437d  vmovaps [rsp+0x10], xmm1
00007f4e3fdd4383  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4389  vmovaps [rsp+0x30], xmm3
00007f4e3fdd438f  vmovaps [rsp+0x40], xmm4
00007f4e3fdd4395  vmovaps [rsp+0x50], xmm5
00007f4e3fdd439b  vmovaps [rsp+0x60], xmm6
00007f4e3fdd43a1  vmovaps [rsp+0x70], xmm7
00007f4e3fdd43a7  vmovaps [rsp+0x80], xmm8
00007f4e3fdd43b0  vmovaps [rsp+0x90], xmm9
00007f4e3fdd43b9  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd43c2  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd43cb  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd43d4  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd43dd  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd43e6  sub rsp, 0x30
00007f4e3fdd43ea  movaps [rsp], xmm12
00007f4e3fdd43ef  movaps [rsp+0x10], xmm15
00007f4e3fdd43f5  movaps [rsp+0x20], xmm11
00007f4e3fdd43fb  lea rdi, [rsp]
00007f4e3fdd43ff  mov esi, 0x00
00007f4e3fdd4404  mov rax, 0x5D97141E9530
00007f4e3fdd440e  call rax
00007f4e3fdd4410  movaps xmm12, [rsp]
00007f4e3fdd4415  add rsp, 0x30
00007f4e3fdd4419  vmovaps xmm0, [rsp]
00007f4e3fdd441e  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4424  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd442a  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd4430  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4436  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd443c  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd4442  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd4448  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd4451  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd445a  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd4463  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd446c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd4475  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd447e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4487  add rsp, 0xF0
00007f4e3fdd448e  pop r11
00007f4e3fdd4490  pop r10
00007f4e3fdd4492  pop r9
00007f4e3fdd4494  pop r8
00007f4e3fdd4496  pop rsi
00007f4e3fdd4497  pop rdi
00007f4e3fdd4498  pop rdx
00007f4e3fdd4499  pop rcx
00007f4e3fdd449a  pop rax
00007f4e3fdd449b  add rsp, 0x08
00007f4e3fdd449f  jmp 0x00007F4E3FDD00F7
00007f4e3fdd44a4  sub rsp, 0x08
00007f4e3fdd44a8  push rax
00007f4e3fdd44a9  push rcx
00007f4e3fdd44aa  push rdx
00007f4e3fdd44ab  push rdi
00007f4e3fdd44ac  push rsi
00007f4e3fdd44ad  push r8
00007f4e3fdd44af  push r9
00007f4e3fdd44b1  push r10
00007f4e3fdd44b3  push r11
00007f4e3fdd44b5  sub rsp, 0xF0
00007f4e3fdd44bc  vmovaps [rsp], xmm0
00007f4e3fdd44c1  vmovaps [rsp+0x10], xmm1
00007f4e3fdd44c7  vmovaps [rsp+0x20], xmm2
00007f4e3fdd44cd  vmovaps [rsp+0x30], xmm3
00007f4e3fdd44d3  vmovaps [rsp+0x40], xmm4
00007f4e3fdd44d9  vmovaps [rsp+0x50], xmm5
00007f4e3fdd44df  vmovaps [rsp+0x60], xmm6
00007f4e3fdd44e5  vmovaps [rsp+0x70], xmm7
00007f4e3fdd44eb  vmovaps [rsp+0x80], xmm8
00007f4e3fdd44f4  vmovaps [rsp+0x90], xmm9
00007f4e3fdd44fd  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd4506  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd450f  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd4518  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd4521  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd452a  sub rsp, 0x30
00007f4e3fdd452e  movaps [rsp], xmm11
00007f4e3fdd4533  movaps [rsp+0x10], xmm7
00007f4e3fdd4538  movaps [rsp+0x20], xmm15
00007f4e3fdd453e  lea rdi, [rsp]
00007f4e3fdd4542  mov esi, 0x00
00007f4e3fdd4547  mov rax, 0x5D97141E9530
00007f4e3fdd4551  call rax
00007f4e3fdd4553  movaps xmm11, [rsp]
00007f4e3fdd4558  add rsp, 0x30
00007f4e3fdd455c  vmovaps xmm0, [rsp]
00007f4e3fdd4561  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4567  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd456d  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd4573  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4579  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd457f  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd4585  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd458b  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd4594  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd459d  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd45a6  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd45af  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd45b8  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd45c1  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd45ca  add rsp, 0xF0
00007f4e3fdd45d1  pop r11
00007f4e3fdd45d3  pop r10
00007f4e3fdd45d5  pop r9
00007f4e3fdd45d7  pop r8
00007f4e3fdd45d9  pop rsi
00007f4e3fdd45da  pop rdi
00007f4e3fdd45db  pop rdx
00007f4e3fdd45dc  pop rcx
00007f4e3fdd45dd  pop rax
00007f4e3fdd45de  add rsp, 0x08
00007f4e3fdd45e2  jmp 0x00007F4E3FDD0123
00007f4e3fdd45e7  sub rsp, 0x08
00007f4e3fdd45eb  push rax
00007f4e3fdd45ec  push rcx
00007f4e3fdd45ed  push rdx
00007f4e3fdd45ee  push rdi
00007f4e3fdd45ef  push rsi
00007f4e3fdd45f0  push r8
00007f4e3fdd45f2  push r9
00007f4e3fdd45f4  push r10
00007f4e3fdd45f6  push r11
00007f4e3fdd45f8  sub rsp, 0xF0
00007f4e3fdd45ff  vmovaps [rsp], xmm0
00007f4e3fdd4604  vmovaps [rsp+0x10], xmm1
00007f4e3fdd460a  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4610  vmovaps [rsp+0x30], xmm3
00007f4e3fdd4616  vmovaps [rsp+0x40], xmm4
00007f4e3fdd461c  vmovaps [rsp+0x50], xmm5
00007f4e3fdd4622  vmovaps [rsp+0x60], xmm6
00007f4e3fdd4628  vmovaps [rsp+0x70], xmm7
00007f4e3fdd462e  vmovaps [rsp+0x80], xmm8
00007f4e3fdd4637  vmovaps [rsp+0x90], xmm9
00007f4e3fdd4640  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd4649  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd4652  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd465b  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd4664  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd466d  sub rsp, 0x30
00007f4e3fdd4671  movaps [rsp], xmm15
00007f4e3fdd4676  movaps [rsp+0x10], xmm10
00007f4e3fdd467c  movaps [rsp+0x20], xmm13
00007f4e3fdd4682  lea rdi, [rsp]
00007f4e3fdd4686  mov esi, 0x00
00007f4e3fdd468b  mov rax, 0x5D97141E9530
00007f4e3fdd4695  call rax
00007f4e3fdd4697  movaps xmm15, [rsp]
00007f4e3fdd469c  add rsp, 0x30
00007f4e3fdd46a0  vmovaps xmm0, [rsp]
00007f4e3fdd46a5  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd46ab  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd46b1  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd46b7  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd46bd  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd46c3  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd46c9  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd46cf  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd46d8  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd46e1  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd46ea  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd46f3  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd46fc  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd4705  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd470e  add rsp, 0xF0
00007f4e3fdd4715  pop r11
00007f4e3fdd4717  pop r10
00007f4e3fdd4719  pop r9
00007f4e3fdd471b  pop r8
00007f4e3fdd471d  pop rsi
00007f4e3fdd471e  pop rdi
00007f4e3fdd471f  pop rdx
00007f4e3fdd4720  pop rcx
00007f4e3fdd4721  pop rax
00007f4e3fdd4722  add rsp, 0x08
00007f4e3fdd4726  jmp 0x00007F4E3FDD013D
00007f4e3fdd472b  sub rsp, 0x08
00007f4e3fdd472f  push rax
00007f4e3fdd4730  push rcx
00007f4e3fdd4731  push rdx
00007f4e3fdd4732  push rdi
00007f4e3fdd4733  push rsi
00007f4e3fdd4734  push r8
00007f4e3fdd4736  push r9
00007f4e3fdd4738  push r10
00007f4e3fdd473a  push r11
00007f4e3fdd473c  sub rsp, 0xF0
00007f4e3fdd4743  vmovaps [rsp], xmm0
00007f4e3fdd4748  vmovaps [rsp+0x10], xmm1
00007f4e3fdd474e  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4754  vmovaps [rsp+0x30], xmm3
00007f4e3fdd475a  vmovaps [rsp+0x40], xmm4
00007f4e3fdd4760  vmovaps [rsp+0x50], xmm5
00007f4e3fdd4766  vmovaps [rsp+0x60], xmm6
00007f4e3fdd476c  vmovaps [rsp+0x70], xmm7
00007f4e3fdd4772  vmovaps [rsp+0x80], xmm8
00007f4e3fdd477b  vmovaps [rsp+0x90], xmm9
00007f4e3fdd4784  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd478d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd4796  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd479f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd47a8  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd47b1  sub rsp, 0x30
00007f4e3fdd47b5  movaps [rsp], xmm10
00007f4e3fdd47ba  movaps [rsp+0x10], xmm7
00007f4e3fdd47bf  movaps [rsp+0x20], xmm13
00007f4e3fdd47c5  lea rdi, [rsp]
00007f4e3fdd47c9  mov esi, 0x00
00007f4e3fdd47ce  mov rax, 0x5D97141E9530
00007f4e3fdd47d8  call rax
00007f4e3fdd47da  movaps xmm10, [rsp]
00007f4e3fdd47df  add rsp, 0x30
00007f4e3fdd47e3  vmovaps xmm0, [rsp]
00007f4e3fdd47e8  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd47ee  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd47f4  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd47fa  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4800  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd4806  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd480c  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd4812  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd481b  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd4824  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd482d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd4836  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd483f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd4848  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4851  add rsp, 0xF0
00007f4e3fdd4858  pop r11
00007f4e3fdd485a  pop r10
00007f4e3fdd485c  pop r9
00007f4e3fdd485e  pop r8
00007f4e3fdd4860  pop rsi
00007f4e3fdd4861  pop rdi
00007f4e3fdd4862  pop rdx
00007f4e3fdd4863  pop rcx
00007f4e3fdd4864  pop rax
00007f4e3fdd4865  add rsp, 0x08
00007f4e3fdd4869  jmp 0x00007F4E3FDD0169
00007f4e3fdd486e  sub rsp, 0x08
00007f4e3fdd4872  push rax
00007f4e3fdd4873  push rcx
00007f4e3fdd4874  push rdx
00007f4e3fdd4875  push rdi
00007f4e3fdd4876  push rsi
00007f4e3fdd4877  push r8
00007f4e3fdd4879  push r9
00007f4e3fdd487b  push r10
00007f4e3fdd487d  push r11
00007f4e3fdd487f  sub rsp, 0xF0
00007f4e3fdd4886  vmovaps [rsp], xmm0
00007f4e3fdd488b  vmovaps [rsp+0x10], xmm1
00007f4e3fdd4891  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4897  vmovaps [rsp+0x30], xmm3
00007f4e3fdd489d  vmovaps [rsp+0x40], xmm4
00007f4e3fdd48a3  vmovaps [rsp+0x50], xmm5
00007f4e3fdd48a9  vmovaps [rsp+0x60], xmm6
00007f4e3fdd48af  vmovaps [rsp+0x70], xmm7
00007f4e3fdd48b5  vmovaps [rsp+0x80], xmm8
00007f4e3fdd48be  vmovaps [rsp+0x90], xmm9
00007f4e3fdd48c7  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd48d0  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd48d9  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd48e2  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd48eb  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd48f4  sub rsp, 0x30
00007f4e3fdd48f8  movaps [rsp], xmm13
00007f4e3fdd48fd  movaps [rsp+0x10], xmm1
00007f4e3fdd4902  movaps [rsp+0x20], xmm8
00007f4e3fdd4908  lea rdi, [rsp]
00007f4e3fdd490c  mov esi, 0x00
00007f4e3fdd4911  mov rax, 0x5D97141E9530
00007f4e3fdd491b  call rax
00007f4e3fdd491d  movaps xmm13, [rsp]
00007f4e3fdd4922  add rsp, 0x30
00007f4e3fdd4926  vmovaps xmm0, [rsp]
00007f4e3fdd492b  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4931  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd4937  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd493d  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4943  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd4949  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd494f  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd4955  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd495e  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd4967  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd4970  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd4979  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd4982  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd498b  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4994  add rsp, 0xF0
00007f4e3fdd499b  pop r11
00007f4e3fdd499d  pop r10
00007f4e3fdd499f  pop r9
00007f4e3fdd49a1  pop r8
00007f4e3fdd49a3  pop rsi
00007f4e3fdd49a4  pop rdi
00007f4e3fdd49a5  pop rdx
00007f4e3fdd49a6  pop rcx
00007f4e3fdd49a7  pop rax
00007f4e3fdd49a8  add rsp, 0x08
00007f4e3fdd49ac  jmp 0x00007F4E3FDD0183
00007f4e3fdd49b1  call 0x00007F4E3FBFF430
00007f4e3fdd49b6  jmp 0x00007F4E3FDD018D
00007f4e3fdd49bb  sub rsp, 0x08
00007f4e3fdd49bf  push rax
00007f4e3fdd49c0  push rcx
00007f4e3fdd49c1  push rdx
00007f4e3fdd49c2  push rdi
00007f4e3fdd49c3  push rsi
00007f4e3fdd49c4  push r8
00007f4e3fdd49c6  push r9
00007f4e3fdd49c8  push r10
00007f4e3fdd49ca  push r11
00007f4e3fdd49cc  sub rsp, 0xF0
00007f4e3fdd49d3  vmovaps [rsp], xmm0
00007f4e3fdd49d8  vmovaps [rsp+0x10], xmm1
00007f4e3fdd49de  vmovaps [rsp+0x20], xmm2
00007f4e3fdd49e4  vmovaps [rsp+0x30], xmm3
00007f4e3fdd49ea  vmovaps [rsp+0x40], xmm4
00007f4e3fdd49f0  vmovaps [rsp+0x50], xmm5
00007f4e3fdd49f6  vmovaps [rsp+0x60], xmm6
00007f4e3fdd49fc  vmovaps [rsp+0x70], xmm7
00007f4e3fdd4a02  vmovaps [rsp+0x80], xmm9
00007f4e3fdd4a0b  vmovaps [rsp+0x90], xmm10
00007f4e3fdd4a14  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd4a1d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd4a26  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd4a2f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd4a38  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd4a41  sub rsp, 0x30
00007f4e3fdd4a45  movaps [rsp], xmm8
00007f4e3fdd4a4a  movaps [rsp+0x10], xmm14
00007f4e3fdd4a50  movaps [rsp+0x20], xmm9
00007f4e3fdd4a56  lea rdi, [rsp]
00007f4e3fdd4a5a  mov esi, 0x00
00007f4e3fdd4a5f  mov rax, 0x5D97141E9530
00007f4e3fdd4a69  call rax
00007f4e3fdd4a6b  movaps xmm8, [rsp]
00007f4e3fdd4a70  add rsp, 0x30
00007f4e3fdd4a74  vmovaps xmm0, [rsp]
00007f4e3fdd4a79  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4a7f  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd4a85  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd4a8b  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4a91  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd4a97  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd4a9d  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd4aa3  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd4aac  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd4ab5  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd4abe  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd4ac7  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd4ad0  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd4ad9  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4ae2  add rsp, 0xF0
00007f4e3fdd4ae9  pop r11
00007f4e3fdd4aeb  pop r10
00007f4e3fdd4aed  pop r9
00007f4e3fdd4aef  pop r8
00007f4e3fdd4af1  pop rsi
00007f4e3fdd4af2  pop rdi
00007f4e3fdd4af3  pop rdx
00007f4e3fdd4af4  pop rcx
00007f4e3fdd4af5  pop rax
00007f4e3fdd4af6  add rsp, 0x08
00007f4e3fdd4afa  jmp 0x00007F4E3FDD01AF
00007f4e3fdd4aff  sub rsp, 0x08
00007f4e3fdd4b03  push rax
00007f4e3fdd4b04  push rcx
00007f4e3fdd4b05  push rdx
00007f4e3fdd4b06  push rdi
00007f4e3fdd4b07  push rsi
00007f4e3fdd4b08  push r8
00007f4e3fdd4b0a  push r9
00007f4e3fdd4b0c  push r10
00007f4e3fdd4b0e  push r11
00007f4e3fdd4b10  sub rsp, 0xF0
00007f4e3fdd4b17  vmovaps [rsp], xmm0
00007f4e3fdd4b1c  vmovaps [rsp+0x10], xmm1
00007f4e3fdd4b22  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4b28  vmovaps [rsp+0x30], xmm3
00007f4e3fdd4b2e  vmovaps [rsp+0x40], xmm4
00007f4e3fdd4b34  vmovaps [rsp+0x50], xmm5
00007f4e3fdd4b3a  vmovaps [rsp+0x60], xmm6
00007f4e3fdd4b40  vmovaps [rsp+0x70], xmm7
00007f4e3fdd4b46  vmovaps [rsp+0x80], xmm8
00007f4e3fdd4b4f  vmovaps [rsp+0x90], xmm10
00007f4e3fdd4b58  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd4b61  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd4b6a  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd4b73  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd4b7c  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd4b85  sub rsp, 0x30
00007f4e3fdd4b89  movaps [rsp], xmm9
00007f4e3fdd4b8e  movaps [rsp+0x10], xmm1
00007f4e3fdd4b93  movaps [rsp+0x20], xmm14
00007f4e3fdd4b99  lea rdi, [rsp]
00007f4e3fdd4b9d  mov esi, 0x00
00007f4e3fdd4ba2  mov rax, 0x5D97141E9530
00007f4e3fdd4bac  call rax
00007f4e3fdd4bae  movaps xmm9, [rsp]
00007f4e3fdd4bb3  add rsp, 0x30
00007f4e3fdd4bb7  vmovaps xmm0, [rsp]
00007f4e3fdd4bbc  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4bc2  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd4bc8  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd4bce  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4bd4  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd4bda  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd4be0  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd4be6  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd4bef  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd4bf8  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd4c01  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd4c0a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd4c13  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd4c1c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4c25  add rsp, 0xF0
00007f4e3fdd4c2c  pop r11
00007f4e3fdd4c2e  pop r10
00007f4e3fdd4c30  pop r9
00007f4e3fdd4c32  pop r8
00007f4e3fdd4c34  pop rsi
00007f4e3fdd4c35  pop rdi
00007f4e3fdd4c36  pop rdx
00007f4e3fdd4c37  pop rcx
00007f4e3fdd4c38  pop rax
00007f4e3fdd4c39  add rsp, 0x08
00007f4e3fdd4c3d  jmp 0x00007F4E3FDD01DD
00007f4e3fdd4c42  sub rsp, 0x08
00007f4e3fdd4c46  push rax
00007f4e3fdd4c47  push rcx
00007f4e3fdd4c48  push rdx
00007f4e3fdd4c49  push rdi
00007f4e3fdd4c4a  push rsi
00007f4e3fdd4c4b  push r8
00007f4e3fdd4c4d  push r9
00007f4e3fdd4c4f  push r10
00007f4e3fdd4c51  push r11
00007f4e3fdd4c53  sub rsp, 0xF0
00007f4e3fdd4c5a  vmovaps [rsp], xmm0
00007f4e3fdd4c5f  vmovaps [rsp+0x10], xmm1
00007f4e3fdd4c65  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4c6b  vmovaps [rsp+0x30], xmm3
00007f4e3fdd4c71  vmovaps [rsp+0x40], xmm4
00007f4e3fdd4c77  vmovaps [rsp+0x50], xmm5
00007f4e3fdd4c7d  vmovaps [rsp+0x60], xmm6
00007f4e3fdd4c83  vmovaps [rsp+0x70], xmm7
00007f4e3fdd4c89  vmovaps [rsp+0x80], xmm8
00007f4e3fdd4c92  vmovaps [rsp+0x90], xmm9
00007f4e3fdd4c9b  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd4ca4  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd4cad  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd4cb6  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd4cbf  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd4cc8  sub rsp, 0x30
00007f4e3fdd4ccc  movaps [rsp], xmm14
00007f4e3fdd4cd1  movaps [rsp+0x10], xmm4
00007f4e3fdd4cd6  movaps [rsp+0x20], xmm1
00007f4e3fdd4cdb  lea rdi, [rsp]
00007f4e3fdd4cdf  mov esi, 0x00
00007f4e3fdd4ce4  mov rax, 0x5D97141E9530
00007f4e3fdd4cee  call rax
00007f4e3fdd4cf0  movaps xmm14, [rsp]
00007f4e3fdd4cf5  add rsp, 0x30
00007f4e3fdd4cf9  vmovaps xmm0, [rsp]
00007f4e3fdd4cfe  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4d04  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd4d0a  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd4d10  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4d16  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd4d1c  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd4d22  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd4d28  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd4d31  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd4d3a  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd4d43  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd4d4c  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd4d55  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd4d5e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4d67  add rsp, 0xF0
00007f4e3fdd4d6e  pop r11
00007f4e3fdd4d70  pop r10
00007f4e3fdd4d72  pop r9
00007f4e3fdd4d74  pop r8
00007f4e3fdd4d76  pop rsi
00007f4e3fdd4d77  pop rdi
00007f4e3fdd4d78  pop rdx
00007f4e3fdd4d79  pop rcx
00007f4e3fdd4d7a  pop rax
00007f4e3fdd4d7b  add rsp, 0x08
00007f4e3fdd4d7f  jmp 0x00007F4E3FDD0203
00007f4e3fdd4d84  sub rsp, 0x08
00007f4e3fdd4d88  push rax
00007f4e3fdd4d89  push rcx
00007f4e3fdd4d8a  push rdx
00007f4e3fdd4d8b  push rdi
00007f4e3fdd4d8c  push rsi
00007f4e3fdd4d8d  push r8
00007f4e3fdd4d8f  push r9
00007f4e3fdd4d91  push r10
00007f4e3fdd4d93  push r11
00007f4e3fdd4d95  sub rsp, 0xF0
00007f4e3fdd4d9c  vmovaps [rsp], xmm0
00007f4e3fdd4da1  vmovaps [rsp+0x10], xmm2
00007f4e3fdd4da7  vmovaps [rsp+0x20], xmm3
00007f4e3fdd4dad  vmovaps [rsp+0x30], xmm4
00007f4e3fdd4db3  vmovaps [rsp+0x40], xmm5
00007f4e3fdd4db9  vmovaps [rsp+0x50], xmm6
00007f4e3fdd4dbf  vmovaps [rsp+0x60], xmm7
00007f4e3fdd4dc5  vmovaps [rsp+0x70], xmm8
00007f4e3fdd4dcb  vmovaps [rsp+0x80], xmm9
00007f4e3fdd4dd4  vmovaps [rsp+0x90], xmm10
00007f4e3fdd4ddd  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd4de6  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd4def  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd4df8  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd4e01  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd4e0a  sub rsp, 0x30
00007f4e3fdd4e0e  movaps [rsp], xmm1
00007f4e3fdd4e12  movaps [rsp+0x10], xmm12
00007f4e3fdd4e18  movaps [rsp+0x20], xmm11
00007f4e3fdd4e1e  lea rdi, [rsp]
00007f4e3fdd4e22  mov esi, 0x00
00007f4e3fdd4e27  mov rax, 0x5D97141E9530
00007f4e3fdd4e31  call rax
00007f4e3fdd4e33  movaps xmm1, [rsp]
00007f4e3fdd4e37  add rsp, 0x30
00007f4e3fdd4e3b  vmovaps xmm0, [rsp]
00007f4e3fdd4e40  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd4e46  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd4e4c  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd4e52  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd4e58  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd4e5e  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd4e64  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd4e6a  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd4e73  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd4e7c  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd4e85  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd4e8e  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd4e97  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd4ea0  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4ea9  add rsp, 0xF0
00007f4e3fdd4eb0  pop r11
00007f4e3fdd4eb2  pop r10
00007f4e3fdd4eb4  pop r9
00007f4e3fdd4eb6  pop r8
00007f4e3fdd4eb8  pop rsi
00007f4e3fdd4eb9  pop rdi
00007f4e3fdd4eba  pop rdx
00007f4e3fdd4ebb  pop rcx
00007f4e3fdd4ebc  pop rax
00007f4e3fdd4ebd  add rsp, 0x08
00007f4e3fdd4ec1  jmp 0x00007F4E3FDD0224
00007f4e3fdd4ec6  call 0x00007F4E3FCE20A0
00007f4e3fdd4ecb  jmp 0x00007F4E3FDD0232
00007f4e3fdd4ed0  call 0x00007F4E3FC09D70
00007f4e3fdd4ed5  jmp 0x00007F4E3FDD023C
00007f4e3fdd4eda  sub rsp, 0x08
00007f4e3fdd4ede  push rax
00007f4e3fdd4edf  push rcx
00007f4e3fdd4ee0  push rdx
00007f4e3fdd4ee1  push rdi
00007f4e3fdd4ee2  push rsi
00007f4e3fdd4ee3  push r8
00007f4e3fdd4ee5  push r9
00007f4e3fdd4ee7  push r10
00007f4e3fdd4ee9  push r11
00007f4e3fdd4eeb  sub rsp, 0xF0
00007f4e3fdd4ef2  vmovaps [rsp], xmm0
00007f4e3fdd4ef7  vmovaps [rsp+0x10], xmm1
00007f4e3fdd4efd  vmovaps [rsp+0x20], xmm2
00007f4e3fdd4f03  vmovaps [rsp+0x30], xmm3
00007f4e3fdd4f09  vmovaps [rsp+0x40], xmm4
00007f4e3fdd4f0f  vmovaps [rsp+0x50], xmm5
00007f4e3fdd4f15  vmovaps [rsp+0x60], xmm6
00007f4e3fdd4f1b  vmovaps [rsp+0x70], xmm8
00007f4e3fdd4f21  vmovaps [rsp+0x80], xmm9
00007f4e3fdd4f2a  vmovaps [rsp+0x90], xmm10
00007f4e3fdd4f33  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd4f3c  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd4f45  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd4f4e  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd4f57  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd4f60  sub rsp, 0x30
00007f4e3fdd4f64  movaps [rsp], xmm7
00007f4e3fdd4f68  movaps [rsp+0x10], xmm15
00007f4e3fdd4f6e  movaps [rsp+0x20], xmm10
00007f4e3fdd4f74  lea rdi, [rsp]
00007f4e3fdd4f78  mov esi, 0x00
00007f4e3fdd4f7d  mov rax, 0x5D97141E9530
00007f4e3fdd4f87  call rax
00007f4e3fdd4f89  movaps xmm7, [rsp]
00007f4e3fdd4f8d  add rsp, 0x30
00007f4e3fdd4f91  vmovaps xmm0, [rsp]
00007f4e3fdd4f96  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd4f9c  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd4fa2  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd4fa8  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd4fae  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd4fb4  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd4fba  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd4fc0  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd4fc9  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd4fd2  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd4fdb  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd4fe4  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd4fed  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd4ff6  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd4fff  add rsp, 0xF0
00007f4e3fdd5006  pop r11
00007f4e3fdd5008  pop r10
00007f4e3fdd500a  pop r9
00007f4e3fdd500c  pop r8
00007f4e3fdd500e  pop rsi
00007f4e3fdd500f  pop rdi
00007f4e3fdd5010  pop rdx
00007f4e3fdd5011  pop rcx
00007f4e3fdd5012  pop rax
00007f4e3fdd5013  add rsp, 0x08
00007f4e3fdd5017  jmp 0x00007F4E3FDD025D
00007f4e3fdd501c  sub rsp, 0x08
00007f4e3fdd5020  push rax
00007f4e3fdd5021  push rcx
00007f4e3fdd5022  push rdx
00007f4e3fdd5023  push rdi
00007f4e3fdd5024  push rsi
00007f4e3fdd5025  push r8
00007f4e3fdd5027  push r9
00007f4e3fdd5029  push r10
00007f4e3fdd502b  push r11
00007f4e3fdd502d  sub rsp, 0xF0
00007f4e3fdd5034  vmovaps [rsp], xmm0
00007f4e3fdd5039  vmovaps [rsp+0x10], xmm1
00007f4e3fdd503f  vmovaps [rsp+0x20], xmm2
00007f4e3fdd5045  vmovaps [rsp+0x30], xmm3
00007f4e3fdd504b  vmovaps [rsp+0x40], xmm4
00007f4e3fdd5051  vmovaps [rsp+0x50], xmm5
00007f4e3fdd5057  vmovaps [rsp+0x60], xmm6
00007f4e3fdd505d  vmovaps [rsp+0x70], xmm7
00007f4e3fdd5063  vmovaps [rsp+0x80], xmm8
00007f4e3fdd506c  vmovaps [rsp+0x90], xmm9
00007f4e3fdd5075  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd507e  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd5087  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd5090  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd5099  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd50a2  sub rsp, 0x30
00007f4e3fdd50a6  movaps [rsp], xmm10
00007f4e3fdd50ab  movaps [rsp+0x10], xmm11
00007f4e3fdd50b1  movaps [rsp+0x20], xmm15
00007f4e3fdd50b7  lea rdi, [rsp]
00007f4e3fdd50bb  mov esi, 0x00
00007f4e3fdd50c0  mov rax, 0x5D97141E9530
00007f4e3fdd50ca  call rax
00007f4e3fdd50cc  movaps xmm10, [rsp]
00007f4e3fdd50d1  add rsp, 0x30
00007f4e3fdd50d5  vmovaps xmm0, [rsp]
00007f4e3fdd50da  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd50e0  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd50e6  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd50ec  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd50f2  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd50f8  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd50fe  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd5104  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd510d  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd5116  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd511f  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd5128  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd5131  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd513a  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd5143  add rsp, 0xF0
00007f4e3fdd514a  pop r11
00007f4e3fdd514c  pop r10
00007f4e3fdd514e  pop r9
00007f4e3fdd5150  pop r8
00007f4e3fdd5152  pop rsi
00007f4e3fdd5153  pop rdi
00007f4e3fdd5154  pop rdx
00007f4e3fdd5155  pop rcx
00007f4e3fdd5156  pop rax
00007f4e3fdd5157  add rsp, 0x08
00007f4e3fdd515b  jmp 0x00007F4E3FDD028B
00007f4e3fdd5160  sub rsp, 0x08
00007f4e3fdd5164  push rax
00007f4e3fdd5165  push rcx
00007f4e3fdd5166  push rdx
00007f4e3fdd5167  push rdi
00007f4e3fdd5168  push rsi
00007f4e3fdd5169  push r8
00007f4e3fdd516b  push r9
00007f4e3fdd516d  push r10
00007f4e3fdd516f  push r11
00007f4e3fdd5171  sub rsp, 0xF0
00007f4e3fdd5178  vmovaps [rsp], xmm0
00007f4e3fdd517d  vmovaps [rsp+0x10], xmm1
00007f4e3fdd5183  vmovaps [rsp+0x20], xmm2
00007f4e3fdd5189  vmovaps [rsp+0x30], xmm3
00007f4e3fdd518f  vmovaps [rsp+0x40], xmm4
00007f4e3fdd5195  vmovaps [rsp+0x50], xmm5
00007f4e3fdd519b  vmovaps [rsp+0x60], xmm6
00007f4e3fdd51a1  vmovaps [rsp+0x70], xmm7
00007f4e3fdd51a7  vmovaps [rsp+0x80], xmm8
00007f4e3fdd51b0  vmovaps [rsp+0x90], xmm9
00007f4e3fdd51b9  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd51c2  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd51cb  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd51d4  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd51dd  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd51e6  sub rsp, 0x30
00007f4e3fdd51ea  movaps [rsp], xmm11
00007f4e3fdd51ef  movaps [rsp+0x10], xmm12
00007f4e3fdd51f5  movaps [rsp+0x20], xmm15
00007f4e3fdd51fb  lea rdi, [rsp]
00007f4e3fdd51ff  mov esi, 0x00
00007f4e3fdd5204  mov rax, 0x5D97141E9530
00007f4e3fdd520e  call rax
00007f4e3fdd5210  movaps xmm11, [rsp]
00007f4e3fdd5215  add rsp, 0x30
00007f4e3fdd5219  vmovaps xmm0, [rsp]
00007f4e3fdd521e  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd5224  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd522a  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd5230  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd5236  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd523c  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd5242  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd5248  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd5251  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd525a  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd5263  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd526c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd5275  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd527e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd5287  add rsp, 0xF0
00007f4e3fdd528e  pop r11
00007f4e3fdd5290  pop r10
00007f4e3fdd5292  pop r9
00007f4e3fdd5294  pop r8
00007f4e3fdd5296  pop rsi
00007f4e3fdd5297  pop rdi
00007f4e3fdd5298  pop rdx
00007f4e3fdd5299  pop rcx
00007f4e3fdd529a  pop rax
00007f4e3fdd529b  add rsp, 0x08
00007f4e3fdd529f  jmp 0x00007F4E3FDD02B9
00007f4e3fdd52a4  sub rsp, 0x08
00007f4e3fdd52a8  push rax
00007f4e3fdd52a9  push rcx
00007f4e3fdd52aa  push rdx
00007f4e3fdd52ab  push rdi
00007f4e3fdd52ac  push rsi
00007f4e3fdd52ad  push r8
00007f4e3fdd52af  push r9
00007f4e3fdd52b1  push r10
00007f4e3fdd52b3  push r11
00007f4e3fdd52b5  sub rsp, 0xF0
00007f4e3fdd52bc  vmovaps [rsp], xmm0
00007f4e3fdd52c1  vmovaps [rsp+0x10], xmm1
00007f4e3fdd52c7  vmovaps [rsp+0x20], xmm2
00007f4e3fdd52cd  vmovaps [rsp+0x30], xmm3
00007f4e3fdd52d3  vmovaps [rsp+0x40], xmm4
00007f4e3fdd52d9  vmovaps [rsp+0x50], xmm5
00007f4e3fdd52df  vmovaps [rsp+0x60], xmm6
00007f4e3fdd52e5  vmovaps [rsp+0x70], xmm7
00007f4e3fdd52eb  vmovaps [rsp+0x80], xmm8
00007f4e3fdd52f4  vmovaps [rsp+0x90], xmm9
00007f4e3fdd52fd  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd5306  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd530f  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd5318  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd5321  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd532a  sub rsp, 0x30
00007f4e3fdd532e  movaps [rsp], xmm15
00007f4e3fdd5333  movaps [rsp+0x10], xmm13
00007f4e3fdd5339  movaps [rsp+0x20], xmm9
00007f4e3fdd533f  lea rdi, [rsp]
00007f4e3fdd5343  mov esi, 0x00
00007f4e3fdd5348  mov rax, 0x5D97141E9530
00007f4e3fdd5352  call rax
00007f4e3fdd5354  movaps xmm15, [rsp]
00007f4e3fdd5359  add rsp, 0x30
00007f4e3fdd535d  vmovaps xmm0, [rsp]
00007f4e3fdd5362  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd5368  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd536e  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd5374  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd537a  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd5380  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd5386  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd538c  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd5395  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd539e  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd53a7  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd53b0  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd53b9  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd53c2  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd53cb  add rsp, 0xF0
00007f4e3fdd53d2  pop r11
00007f4e3fdd53d4  pop r10
00007f4e3fdd53d6  pop r9
00007f4e3fdd53d8  pop r8
00007f4e3fdd53da  pop rsi
00007f4e3fdd53db  pop rdi
00007f4e3fdd53dc  pop rdx
00007f4e3fdd53dd  pop rcx
00007f4e3fdd53de  pop rax
00007f4e3fdd53df  add rsp, 0x08
00007f4e3fdd53e3  jmp 0x00007F4E3FDD02D4
00007f4e3fdd53e8  sub rsp, 0x08
00007f4e3fdd53ec  push rax
00007f4e3fdd53ed  push rcx
00007f4e3fdd53ee  push rdx
00007f4e3fdd53ef  push rdi
00007f4e3fdd53f0  push rsi
00007f4e3fdd53f1  push r8
00007f4e3fdd53f3  push r9
00007f4e3fdd53f5  push r10
00007f4e3fdd53f7  push r11
00007f4e3fdd53f9  sub rsp, 0xF0
00007f4e3fdd5400  vmovaps [rsp], xmm0
00007f4e3fdd5405  vmovaps [rsp+0x10], xmm1
00007f4e3fdd540b  vmovaps [rsp+0x20], xmm2
00007f4e3fdd5411  vmovaps [rsp+0x30], xmm3
00007f4e3fdd5417  vmovaps [rsp+0x40], xmm4
00007f4e3fdd541d  vmovaps [rsp+0x50], xmm5
00007f4e3fdd5423  vmovaps [rsp+0x60], xmm6
00007f4e3fdd5429  vmovaps [rsp+0x70], xmm7
00007f4e3fdd542f  vmovaps [rsp+0x80], xmm8
00007f4e3fdd5438  vmovaps [rsp+0x90], xmm9
00007f4e3fdd5441  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd544a  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd5453  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd545c  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd5465  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd546e  sub rsp, 0x30
00007f4e3fdd5472  movaps [rsp], xmm13
00007f4e3fdd5477  movaps [rsp+0x10], xmm8
00007f4e3fdd547d  movaps [rsp+0x20], xmm14
00007f4e3fdd5483  lea rdi, [rsp]
00007f4e3fdd5487  mov esi, 0x00
00007f4e3fdd548c  mov rax, 0x5D97141E9530
00007f4e3fdd5496  call rax
00007f4e3fdd5498  movaps xmm13, [rsp]
00007f4e3fdd549d  add rsp, 0x30
00007f4e3fdd54a1  vmovaps xmm0, [rsp]
00007f4e3fdd54a6  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd54ac  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd54b2  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd54b8  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd54be  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd54c4  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd54ca  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd54d0  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd54d9  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd54e2  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd54eb  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd54f4  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd54fd  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd5506  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd550f  add rsp, 0xF0
00007f4e3fdd5516  pop r11
00007f4e3fdd5518  pop r10
00007f4e3fdd551a  pop r9
00007f4e3fdd551c  pop r8
00007f4e3fdd551e  pop rsi
00007f4e3fdd551f  pop rdi
00007f4e3fdd5520  pop rdx
00007f4e3fdd5521  pop rcx
00007f4e3fdd5522  pop rax
00007f4e3fdd5523  add rsp, 0x08
00007f4e3fdd5527  jmp 0x00007F4E3FDD02F7
00007f4e3fdd552c  sub rsp, 0x08
00007f4e3fdd5530  push rax
00007f4e3fdd5531  push rcx
00007f4e3fdd5532  push rdx
00007f4e3fdd5533  push rdi
00007f4e3fdd5534  push rsi
00007f4e3fdd5535  push r8
00007f4e3fdd5537  push r9
00007f4e3fdd5539  push r10
00007f4e3fdd553b  push r11
00007f4e3fdd553d  sub rsp, 0xF0
00007f4e3fdd5544  vmovaps [rsp], xmm0
00007f4e3fdd5549  vmovaps [rsp+0x10], xmm1
00007f4e3fdd554f  vmovaps [rsp+0x20], xmm2
00007f4e3fdd5555  vmovaps [rsp+0x30], xmm3
00007f4e3fdd555b  vmovaps [rsp+0x40], xmm4
00007f4e3fdd5561  vmovaps [rsp+0x50], xmm5
00007f4e3fdd5567  vmovaps [rsp+0x60], xmm6
00007f4e3fdd556d  vmovaps [rsp+0x70], xmm7
00007f4e3fdd5573  vmovaps [rsp+0x80], xmm8
00007f4e3fdd557c  vmovaps [rsp+0x90], xmm9
00007f4e3fdd5585  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd558e  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd5597  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd55a0  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd55a9  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd55b2  sub rsp, 0x30
00007f4e3fdd55b6  movaps [rsp], xmm14
00007f4e3fdd55bb  movaps [rsp+0x10], xmm1
00007f4e3fdd55c0  movaps [rsp+0x20], xmm10
00007f4e3fdd55c6  lea rdi, [rsp]
00007f4e3fdd55ca  mov esi, 0x00
00007f4e3fdd55cf  mov rax, 0x5D97141E9530
00007f4e3fdd55d9  call rax
00007f4e3fdd55db  movaps xmm14, [rsp]
00007f4e3fdd55e0  add rsp, 0x30
00007f4e3fdd55e4  vmovaps xmm0, [rsp]
00007f4e3fdd55e9  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd55ef  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd55f5  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd55fb  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd5601  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd5607  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd560d  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd5613  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd561c  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd5625  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd562e  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd5637  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd5640  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd5649  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd5652  add rsp, 0xF0
00007f4e3fdd5659  pop r11
00007f4e3fdd565b  pop r10
00007f4e3fdd565d  pop r9
00007f4e3fdd565f  pop r8
00007f4e3fdd5661  pop rsi
00007f4e3fdd5662  pop rdi
00007f4e3fdd5663  pop rdx
00007f4e3fdd5664  pop rcx
00007f4e3fdd5665  pop rax
00007f4e3fdd5666  add rsp, 0x08
00007f4e3fdd566a  jmp 0x00007F4E3FDD031A
00007f4e3fdd566f  sub rsp, 0x08
00007f4e3fdd5673  push rax
00007f4e3fdd5674  push rcx
00007f4e3fdd5675  push rdx
00007f4e3fdd5676  push rdi
00007f4e3fdd5677  push rsi
00007f4e3fdd5678  push r8
00007f4e3fdd567a  push r9
00007f4e3fdd567c  push r10
00007f4e3fdd567e  push r11
00007f4e3fdd5680  sub rsp, 0xF0
00007f4e3fdd5687  vmovaps [rsp], xmm0
00007f4e3fdd568c  vmovaps [rsp+0x10], xmm2
00007f4e3fdd5692  vmovaps [rsp+0x20], xmm3
00007f4e3fdd5698  vmovaps [rsp+0x30], xmm4
00007f4e3fdd569e  vmovaps [rsp+0x40], xmm5
00007f4e3fdd56a4  vmovaps [rsp+0x50], xmm6
00007f4e3fdd56aa  vmovaps [rsp+0x60], xmm7
00007f4e3fdd56b0  vmovaps [rsp+0x70], xmm8
00007f4e3fdd56b6  vmovaps [rsp+0x80], xmm9
00007f4e3fdd56bf  vmovaps [rsp+0x90], xmm10
00007f4e3fdd56c8  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd56d1  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd56da  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd56e3  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd56ec  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd56f5  sub rsp, 0x30
00007f4e3fdd56f9  movaps [rsp], xmm1
00007f4e3fdd56fd  movaps [rsp+0x10], xmm7
00007f4e3fdd5702  movaps [rsp+0x20], xmm11
00007f4e3fdd5708  lea rdi, [rsp]
00007f4e3fdd570c  mov esi, 0x00
00007f4e3fdd5711  mov rax, 0x5D97141E9530
00007f4e3fdd571b  call rax
00007f4e3fdd571d  movaps xmm1, [rsp]
00007f4e3fdd5721  add rsp, 0x30
00007f4e3fdd5725  vmovaps xmm0, [rsp]
00007f4e3fdd572a  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd5730  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd5736  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd573c  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd5742  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd5748  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd574e  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd5754  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd575d  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd5766  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd576f  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd5778  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd5781  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd578a  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd5793  add rsp, 0xF0
00007f4e3fdd579a  pop r11
00007f4e3fdd579c  pop r10
00007f4e3fdd579e  pop r9
00007f4e3fdd57a0  pop r8
00007f4e3fdd57a2  pop rsi
00007f4e3fdd57a3  pop rdi
00007f4e3fdd57a4  pop rdx
00007f4e3fdd57a5  pop rcx
00007f4e3fdd57a6  pop rax
00007f4e3fdd57a7  add rsp, 0x08
00007f4e3fdd57ab  jmp 0x00007F4E3FDD033B
00007f4e3fdd57b0  call 0x00007F4E3FC0E880
00007f4e3fdd57b5  jmp 0x00007F4E3FDD034E
00007f4e3fdd57ba  call 0x00007F4E3FC0C380
00007f4e3fdd57bf  jmp 0x00007F4E3FDD0359
00007f4e3fdd57c4  call 0x00007F4E3FC0D600
00007f4e3fdd57c9  jmp 0x00007F4E3FDD0364
00007f4e3fdd57ce  call 0x00007F4E3FBFF540
00007f4e3fdd57d3  jmp 0x00007F4E3FDD036F
00007f4e3fdd57d8  int3
00007f4e3fdd57d9  nop [rax], eax
00007f4e3fdd57e0  mov rax, [r15+0x40]
00007f4e3fdd57e4  mov r14, [r15+0x58]
00007f4e3fdd57e8  lea r12, [rax+r14*1]
00007f4e3fdd57ec  movaps xmm1, [r15+0x1D0]
00007f4e3fdd57f4  vmovaps [rsp+0x10], xmm1
00007f4e3fdd57fa  vmovaps xmm15, [rsp+0x10]
00007f4e3fdd5800  por xmm1, xmm15
00007f4e3fdd5805  movaps xmm14, [r15+0x1A0]
00007f4e3fdd580d  vmovaps [rsp+0x10], xmm14
00007f4e3fdd5813  vmovaps xmm13, [rsp+0x10]
00007f4e3fdd5819  por xmm14, xmm13
00007f4e3fdd581e  lea rax, [r12+0x30]
00007f4e3fdd5823  mov r11, [r13+rax*1]
00007f4e3fdd5828  lea rax, [r12+0x38]
00007f4e3fdd582d  mov r10, [r13+rax*1]
00007f4e3fdd5832  movq xmm13, r11
00007f4e3fdd5837  movq xmm12, r10
00007f4e3fdd583c  movq xmm13, xmm13
00007f4e3fdd5841  vmovaps [rsp+0x10], xmm13
00007f4e3fdd5847  movq xmm13, xmm13
00007f4e3fdd584c  movaps [r15+0x130], xmm13
00007f4e3fdd5854  movq xmm12, xmm12
00007f4e3fdd5859  vmovaps [rsp+0x20], xmm12
00007f4e3fdd585f  movq xmm12, xmm12
00007f4e3fdd5864  movaps [r15+0x280], xmm12
00007f4e3fdd586c  movaps xmm13, [r15+0x270]
00007f4e3fdd5874  vmovaps [rsp+0x30], xmm13
00007f4e3fdd587a  vmovaps xmm12, [rsp+0x30]
00007f4e3fdd5880  por xmm13, xmm12
00007f4e3fdd5885  lea rax, [r12+0x20]
00007f4e3fdd588a  mov r11, [r13+rax*1]
00007f4e3fdd588f  lea rax, [r12+0x28]
00007f4e3fdd5894  mov r10, [r13+rax*1]
00007f4e3fdd5899  movq xmm12, r11
00007f4e3fdd589e  movq xmm11, r10
00007f4e3fdd58a3  movq xmm12, xmm12
00007f4e3fdd58a8  vmovaps [rsp+0x30], xmm12
00007f4e3fdd58ae  movq xmm12, xmm12
00007f4e3fdd58b3  movaps [r15+0x150], xmm12
00007f4e3fdd58bb  movq xmm11, xmm11
00007f4e3fdd58c0  vmovaps [rsp+0x40], xmm11
00007f4e3fdd58c6  movq xmm11, xmm11
00007f4e3fdd58cb  movaps [r15+0x140], xmm11
00007f4e3fdd58d3  lea rax, [r12+0x10]
00007f4e3fdd58d8  mov r11, [r13+rax*1]
00007f4e3fdd58dd  lea rax, [r12+0x18]
00007f4e3fdd58e2  mov r10, [r13+rax*1]
00007f4e3fdd58e7  movq xmm12, r11
00007f4e3fdd58ec  movq xmm11, r10
00007f4e3fdd58f1  movq xmm12, xmm12
00007f4e3fdd58f6  vmovaps [rsp+0x50], xmm12
00007f4e3fdd58fc  movq xmm12, xmm12
00007f4e3fdd5901  movaps [r15+0x170], xmm12
00007f4e3fdd5909  movq xmm11, xmm11
00007f4e3fdd590e  vmovaps [rsp+0x60], xmm11
00007f4e3fdd5914  movq xmm11, xmm11
00007f4e3fdd5919  movaps [r15+0x160], xmm11
00007f4e3fdd5921  mov rax, [r13+r12*1]
00007f4e3fdd5926  vmovq xmm12, rax
00007f4e3fdd592b  vpbroadcastq xmm12, xmm12
00007f4e3fdd5930  lea rax, [r12+0x08]
00007f4e3fdd5935  mov r12, [r13+rax*1]
00007f4e3fdd593a  movq xmm11, r12
00007f4e3fdd593f  movaps [r15+0x230], xmm11
00007f4e3fdd5947  mov rax, [r15+0xF8]
00007f4e3fdd594e  lea r12, [rax+0x50]
00007f4e3fdd5952  movups xmm11, [r13+r12*1]
00007f4e3fdd5958  lea r12, [rax+0x60]
00007f4e3fdd595c  movups xmm10, [r13+r12*1]
00007f4e3fdd5962  lea r12, [rax+0x30]
00007f4e3fdd5966  movups xmm9, [r13+r12*1]
00007f4e3fdd596c  mov r12, [r15+0x50]
00007f4e3fdd5970  lea r11, [r12+r14*1]
00007f4e3fdd5974  mov [r15+0x60], r11
00007f4e3fdd5978  lea r12, [r14+0x40]
00007f4e3fdd597c  mov [r15+0x58], r12
00007f4e3fdd5980  movaps xmm8, xmm12
00007f4e3fdd5984  mulpd xmm8, xmm15
00007f4e3fdd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f4e3fdd598f  ptest xmm7, xmm7
00007f4e3fdd5994  jnz 0x00007F4E3FDD67B7
00007f4e3fdd599a  movq xmm15, qword ptr [r15+0x230]
00007f4e3fdd59a3  vmovaps [rsp+0x70], xmm15
00007f4e3fdd59a9  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdd59af  movaps xmm7, xmm9
00007f4e3fdd59b3  mulpd xmm7, xmm15
00007f4e3fdd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4e3fdd59bd  ptest xmm6, xmm6
00007f4e3fdd59c2  jnz 0x00007F4E3FDD68FB
00007f4e3fdd59c8  vxorps xmm15, xmm15, xmm15
00007f4e3fdd59cd  vpbroadcastq xmm15, xmm15
00007f4e3fdd59d2  movaps xmm9, xmm12
00007f4e3fdd59d6  mulpd xmm9, xmm10
00007f4e3fdd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f4e3fdd59e1  ptest xmm6, xmm6
00007f4e3fdd59e6  jnz 0x00007F4E3FDD6A3D
00007f4e3fdd59ec  movaps xmm10, xmm12
00007f4e3fdd59f0  mulpd xmm10, xmm11
00007f4e3fdd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f4e3fdd59fb  ptest xmm6, xmm6
00007f4e3fdd5a00  jnz 0x00007F4E3FDD6B81
00007f4e3fdd5a06  movaps xmm11, [r15+0x1F0]
00007f4e3fdd5a0e  movaps xmm6, xmm12
00007f4e3fdd5a12  mulpd xmm6, xmm11
00007f4e3fdd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f4e3fdd5a1c  ptest xmm5, xmm5
00007f4e3fdd5a21  jnz 0x00007F4E3FDD6CC5
00007f4e3fdd5a27  movaps xmm12, [r15+0x2A0]
00007f4e3fdd5a2f  vmovaps [rsp+0x80], xmm12
00007f4e3fdd5a38  vmovaps xmm11, [rsp+0x80]
00007f4e3fdd5a41  por xmm12, xmm11
00007f4e3fdd5a46  movaps xmm11, [r15+0x250]
00007f4e3fdd5a4e  vmovaps [rsp+0x80], xmm11
00007f4e3fdd5a57  vmovaps xmm5, [rsp+0x80]
00007f4e3fdd5a60  por xmm11, xmm5
00007f4e3fdd5a65  vmovaps xmm4, [rsp+0x70]
00007f4e3fdd5a6b  vpermilpd xmm4, xmm4, 0x00
00007f4e3fdd5a71  movaps xmm3, xmm5
00007f4e3fdd5a74  mulpd xmm3, xmm4
00007f4e3fdd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f4e3fdd5a7d  ptest xmm2, xmm2
00007f4e3fdd5a82  jnz 0x00007F4E3FDD6E07
00007f4e3fdd5a88  mov [rsp+0x80], rax
00007f4e3fdd5a90  xor eax, eax
00007f4e3fdd5a92  mov r14d, 0x200
00007f4e3fdd5a98  cmp r12, r14
00007f4e3fdd5a9b  cmc
00007f4e3fdd5a9c  lahf
00007f4e3fdd5a9d  seto al
00007f4e3fdd5aa0  mov [r15+0x108], eax
00007f4e3fdd5aa7  movaps xmm5, xmm8
00007f4e3fdd5aab  addpd xmm5, xmm15
00007f4e3fdd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f4e3fdd5ab5  ptest xmm4, xmm4
00007f4e3fdd5aba  jnz 0x00007F4E3FDD6F47
00007f4e3fdd5ac0  movaps xmm8, [r15+0x1B0]
00007f4e3fdd5ac8  movaps xmm4, xmm9
00007f4e3fdd5acc  addpd xmm4, xmm8
00007f4e3fdd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f4e3fdd5ad6  ptest xmm2, xmm2
00007f4e3fdd5adb  jnz 0x00007F4E3FDD7089
00007f4e3fdd5ae1  movaps xmm9, xmm10
00007f4e3fdd5ae5  addpd xmm9, xmm8
00007f4e3fdd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f4e3fdd5af0  ptest xmm2, xmm2
00007f4e3fdd5af5  jnz 0x00007F4E3FDD71CB
00007f4e3fdd5afb  movaps xmm10, [r15+0x2F0]
00007f4e3fdd5b03  vmovaps [rsp+0x90], xmm10
00007f4e3fdd5b0c  vmovaps xmm8, [rsp+0x90]
00007f4e3fdd5b15  por xmm10, xmm8
00007f4e3fdd5b1a  movaps xmm8, [r15+0x2E0]
00007f4e3fdd5b22  vmovaps [rsp+0x90], xmm8
00007f4e3fdd5b2b  vmovaps xmm2, [rsp+0x90]
00007f4e3fdd5b34  por xmm8, xmm2
00007f4e3fdd5b39  movaps xmm2, [r15+0x2D0]
00007f4e3fdd5b41  vmovaps [rsp+0x90], xmm2
00007f4e3fdd5b4a  vmovaps [rsp+0xA0], xmm1
00007f4e3fdd5b53  vmovaps xmm1, [rsp+0x90]
00007f4e3fdd5b5c  por xmm2, xmm1
00007f4e3fdd5b60  movaps xmm1, [r15+0x200]
00007f4e3fdd5b68  vmovaps [rsp+0x90], xmm1
00007f4e3fdd5b71  vmovaps [rsp+0xB0], xmm15
00007f4e3fdd5b7a  vmovaps xmm15, [rsp+0x90]
00007f4e3fdd5b83  por xmm1, xmm15
00007f4e3fdd5b88  movaps xmm15, [r15+0x1C0]
00007f4e3fdd5b90  vmovaps [rsp+0x90], xmm15
00007f4e3fdd5b99  vmovaps [rsp+0xC0], xmm1
00007f4e3fdd5ba2  vmovaps xmm1, [rsp+0x90]
00007f4e3fdd5bab  por xmm15, xmm1
00007f4e3fdd5bb0  movaps xmm1, [r15+0x190]
00007f4e3fdd5bb8  vmovaps [rsp+0x90], xmm1
00007f4e3fdd5bc1  vmovaps [rsp+0xD0], xmm15
00007f4e3fdd5bca  vmovaps xmm15, [rsp+0x90]
00007f4e3fdd5bd3  por xmm1, xmm15
00007f4e3fdd5bd8  movaps xmm15, [r15+0x300]
00007f4e3fdd5be0  vmovaps [rsp+0x90], xmm15
00007f4e3fdd5be9  vmovaps [rsp+0xE0], xmm1
00007f4e3fdd5bf2  vmovaps xmm1, [rsp+0x90]
00007f4e3fdd5bfb  por xmm15, xmm1
00007f4e3fdd5c00  mov rax, [rsp+0x80]
00007f4e3fdd5c08  lea r14, [rax+0xA0]
00007f4e3fdd5c0f  movups xmm1, [r13+r14*1]
00007f4e3fdd5c15  lea r14, [rax+0xB0]
00007f4e3fdd5c1c  vmovaps [rsp+0x80], xmm1
00007f4e3fdd5c25  movups xmm1, [r13+r14*1]
00007f4e3fdd5c2b  vmovaps [rsp+0x90], xmm1
00007f4e3fdd5c34  vmovaps [rsp+0xF0], xmm15
00007f4e3fdd5c3d  vmovaps xmm15, [rsp+0xB0]
00007f4e3fdd5c46  vmovaps [rsp+0xB0], xmm14
00007f4e3fdd5c4f  movaps xmm1, xmm6
00007f4e3fdd5c52  addpd xmm1, xmm15
00007f4e3fdd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f4e3fdd5c5c  ptest xmm14, xmm14
00007f4e3fdd5c62  jnz 0x00007F4E3FDD7323
00007f4e3fdd5c68  lea r14, [rax+0xF0]
00007f4e3fdd5c6f  movups xmm15, [r13+r14*1]
00007f4e3fdd5c75  movaps xmm14, xmm4
00007f4e3fdd5c79  addpd xmm14, xmm3
00007f4e3fdd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f4e3fdd5c84  ptest xmm6, xmm6
00007f4e3fdd5c89  jnz 0x00007F4E3FDD746E
00007f4e3fdd5c8f  movaps xmm6, xmm9
00007f4e3fdd5c93  addpd xmm6, xmm7
00007f4e3fdd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f4e3fdd5c9c  ptest xmm4, xmm4
00007f4e3fdd5ca1  jnz 0x00007F4E3FDD75B0
00007f4e3fdd5ca7  vmovaps xmm9, [rsp+0x70]
00007f4e3fdd5cad  vpermilpd xmm9, xmm9, 0x00
00007f4e3fdd5cb3  vmovaps xmm4, [rsp+0x90]
00007f4e3fdd5cbc  movaps xmm7, xmm4
00007f4e3fdd5cbf  mulpd xmm7, xmm9
00007f4e3fdd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f4e3fdd5cc9  ptest xmm3, xmm3
00007f4e3fdd5cce  jnz 0x00007F4E3FDD76F1
00007f4e3fdd5cd4  vmovaps xmm9, [rsp+0x50]
00007f4e3fdd5cda  vpermilpd xmm9, xmm9, 0x00
00007f4e3fdd5ce0  movaps xmm4, xmm15
00007f4e3fdd5ce4  mulpd xmm4, xmm9
00007f4e3fdd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f4e3fdd5cee  ptest xmm3, xmm3
00007f4e3fdd5cf3  jnz 0x00007F4E3FDD7832
00007f4e3fdd5cf9  lea r14, [rax+0xE0]
00007f4e3fdd5d00  movups xmm15, [r13+r14*1]
00007f4e3fdd5d06  vmovaps xmm9, [rsp+0x70]
00007f4e3fdd5d0c  vpermilpd xmm9, xmm9, 0x00
00007f4e3fdd5d12  vmovaps [rsp+0x70], xmm1
00007f4e3fdd5d18  vmovaps xmm1, [rsp+0x80]
00007f4e3fdd5d21  vmovaps [rsp+0x80], xmm15
00007f4e3fdd5d2a  movaps xmm3, xmm1
00007f4e3fdd5d2d  mulpd xmm3, xmm9
00007f4e3fdd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f4e3fdd5d37  ptest xmm15, xmm15
00007f4e3fdd5d3d  jnz 0x00007F4E3FDD797E
00007f4e3fdd5d43  vmovaps xmm1, [rsp+0xF0]
00007f4e3fdd5d4c  vmovaps xmm15, [rsp+0xF0]
00007f4e3fdd5d55  por xmm1, xmm15
00007f4e3fdd5d5a  movaps [r15+0x300], xmm1
00007f4e3fdd5d62  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd5d6b  vmovaps xmm9, [rsp+0xE0]
00007f4e3fdd5d74  por xmm15, xmm9
00007f4e3fdd5d79  movaps [r15+0x190], xmm15
00007f4e3fdd5d81  vmovaps xmm9, [rsp+0x50]
00007f4e3fdd5d87  vpermilpd xmm9, xmm9, 0x00
00007f4e3fdd5d8d  vmovaps [rsp+0x90], xmm1
00007f4e3fdd5d96  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd5d9f  vmovaps xmm15, [rsp+0x80]
00007f4e3fdd5da8  vmovaps [rsp+0x80], xmm14
00007f4e3fdd5db1  movaps xmm1, xmm15
00007f4e3fdd5db5  mulpd xmm1, xmm9
00007f4e3fdd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f4e3fdd5dbf  ptest xmm14, xmm14
00007f4e3fdd5dc5  jnz 0x00007F4E3FDD7ABF
00007f4e3fdd5dcb  lea r14, [rax+0x90]
00007f4e3fdd5dd2  movups xmm15, [r13+r14*1]
00007f4e3fdd5dd8  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd5de1  vmovaps xmm9, [rsp+0xD0]
00007f4e3fdd5dea  por xmm14, xmm9
00007f4e3fdd5def  movaps [r15+0x1C0], xmm14
00007f4e3fdd5df7  vmovaps xmm9, [rsp+0xC0]
00007f4e3fdd5e00  vmovaps [rsp+0xD0], xmm1
00007f4e3fdd5e09  vmovaps xmm1, [rsp+0xC0]
00007f4e3fdd5e12  por xmm9, xmm1
00007f4e3fdd5e17  movaps [r15+0x200], xmm9
00007f4e3fdd5e1f  vmovaps [rsp+0xC0], xmm2
00007f4e3fdd5e28  vmovaps xmm1, [rsp+0xC0]
00007f4e3fdd5e31  por xmm2, xmm1
00007f4e3fdd5e35  movaps [r15+0x2D0], xmm2
00007f4e3fdd5e3d  vmovaps [rsp+0xC0], xmm8
00007f4e3fdd5e46  vmovaps xmm1, [rsp+0xC0]
00007f4e3fdd5e4f  por xmm8, xmm1
00007f4e3fdd5e54  movaps [r15+0x2E0], xmm8
00007f4e3fdd5e5c  vmovaps [rsp+0xC0], xmm15
00007f4e3fdd5e65  movaps xmm1, xmm5
00007f4e3fdd5e68  addpd xmm1, xmm7
00007f4e3fdd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f4e3fdd5e71  ptest xmm15, xmm15
00007f4e3fdd5e77  jnz 0x00007F4E3FDD7C0B
00007f4e3fdd5e7d  vmovaps xmm15, [rsp+0x50]
00007f4e3fdd5e83  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdd5e89  vmovaps xmm5, [rsp+0xC0]
00007f4e3fdd5e92  vmovaps [rsp+0xC0], xmm1
00007f4e3fdd5e9b  movaps xmm7, xmm5
00007f4e3fdd5e9e  mulpd xmm7, xmm15
00007f4e3fdd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f4e3fdd5ea8  ptest xmm1, xmm1
00007f4e3fdd5ead  jnz 0x00007F4E3FDD7D4B
00007f4e3fdd5eb3  lea r14, [rax+0x80]
00007f4e3fdd5eba  movups xmm1, [r13+r14*1]
00007f4e3fdd5ec0  vmovaps xmm5, [rsp+0x70]
00007f4e3fdd5ec6  vmovaps [rsp+0x70], xmm1
00007f4e3fdd5ecc  movaps xmm15, xmm5
00007f4e3fdd5ed0  addpd xmm15, xmm3
00007f4e3fdd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fdd5edb  ptest xmm1, xmm1
00007f4e3fdd5ee0  jnz 0x00007F4E3FDD7E96
00007f4e3fdd5ee6  vmovaps xmm5, [rsp+0x80]
00007f4e3fdd5eef  movaps xmm1, xmm5
00007f4e3fdd5ef2  addpd xmm1, xmm4
00007f4e3fdd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f4e3fdd5efb  ptest xmm3, xmm3
00007f4e3fdd5f00  jnz 0x00007F4E3FDD7FD8
00007f4e3fdd5f06  vmovaps [rsp+0x80], xmm10
00007f4e3fdd5f0f  vmovaps xmm5, [rsp+0x80]
00007f4e3fdd5f18  por xmm10, xmm5
00007f4e3fdd5f1d  movaps [r15+0x2F0], xmm10
00007f4e3fdd5f25  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd5f2b  vpermilpd xmm5, xmm5, 0x00
00007f4e3fdd5f31  vmovaps xmm3, [rsp+0x70]
00007f4e3fdd5f37  vmovaps [rsp+0x50], xmm1
00007f4e3fdd5f3d  movaps xmm4, xmm3
00007f4e3fdd5f40  mulpd xmm4, xmm5
00007f4e3fdd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f4e3fdd5f49  ptest xmm1, xmm1
00007f4e3fdd5f4e  jnz 0x00007F4E3FDD8118
00007f4e3fdd5f54  lea r14, [rax+0xD0]
00007f4e3fdd5f5b  movups xmm1, [r13+r14*1]
00007f4e3fdd5f61  vmovaps xmm3, [rsp+0xD0]
00007f4e3fdd5f6a  vmovaps [rsp+0x70], xmm1
00007f4e3fdd5f70  movaps xmm5, xmm6
00007f4e3fdd5f73  addpd xmm5, xmm3
00007f4e3fdd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f4e3fdd5f7c  ptest xmm1, xmm1
00007f4e3fdd5f81  jnz 0x00007F4E3FDD8262
00007f4e3fdd5f87  vmovaps xmm1, [rsp+0x60]
00007f4e3fdd5f8d  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd5f93  movaps xmm6, xmm9
00007f4e3fdd5f97  mulpd xmm6, xmm1
00007f4e3fdd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f4e3fdd5fa0  ptest xmm3, xmm3
00007f4e3fdd5fa5  jnz 0x00007F4E3FDD83A2
00007f4e3fdd5fab  movaps [r15+0x260], xmm6
00007f4e3fdd5fb3  vxorps xmm1, xmm1, xmm1
00007f4e3fdd5fb7  vpbroadcastq xmm1, xmm1
00007f4e3fdd5fbc  movaps [r15+0x1B0], xmm1
00007f4e3fdd5fc4  vmovaps xmm1, [rsp+0x60]
00007f4e3fdd5fca  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd5fd0  vmovaps xmm3, [rsp+0x70]
00007f4e3fdd5fd6  vmovaps [rsp+0x70], xmm15
00007f4e3fdd5fdc  movaps xmm9, xmm3
00007f4e3fdd5fe0  mulpd xmm9, xmm1
00007f4e3fdd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f4e3fdd5feb  ptest xmm15, xmm15
00007f4e3fdd5ff1  jnz 0x00007F4E3FDD84E3
00007f4e3fdd5ff7  lea r14, [rax+0xC0]
00007f4e3fdd5ffe  movups xmm1, [r13+r14*1]
00007f4e3fdd6004  vmovaps xmm3, [rsp+0xC0]
00007f4e3fdd600d  vmovaps [rsp+0x80], xmm1
00007f4e3fdd6016  movaps xmm15, xmm3
00007f4e3fdd601a  addpd xmm15, xmm7
00007f4e3fdd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fdd6025  ptest xmm1, xmm1
00007f4e3fdd602a  jnz 0x00007F4E3FDD862F
00007f4e3fdd6030  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd6039  vmovaps xmm1, [rsp+0xC0]
00007f4e3fdd6042  por xmm13, xmm1
00007f4e3fdd6047  movaps [r15+0x270], xmm13
00007f4e3fdd604f  vmovaps xmm1, [rsp+0xB0]
00007f4e3fdd6058  vmovaps xmm7, [rsp+0xB0]
00007f4e3fdd6061  por xmm1, xmm7
00007f4e3fdd6065  movaps [r15+0x1A0], xmm1
00007f4e3fdd606d  vmovaps xmm1, [rsp+0x60]
00007f4e3fdd6073  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd6079  vmovaps [rsp+0xB0], xmm1
00007f4e3fdd6082  vmovaps xmm1, [rsp+0x80]
00007f4e3fdd608b  vmovaps [rsp+0x80], xmm15
00007f4e3fdd6094  vmovaps xmm15, [rsp+0xB0]
00007f4e3fdd609d  vmovaps [rsp+0xB0], xmm14
00007f4e3fdd60a6  movaps xmm3, xmm1
00007f4e3fdd60a9  mulpd xmm3, xmm15
00007f4e3fdd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f4e3fdd60b3  ptest xmm14, xmm14
00007f4e3fdd60b9  jnz 0x00007F4E3FDD8771
00007f4e3fdd60bf  lea r14, [rax+0x20]
00007f4e3fdd60c3  movups xmm1, [r13+r14*1]
00007f4e3fdd60c9  movaps [r15+0x110], xmm1
00007f4e3fdd60d1  vmovaps xmm14, [rsp+0x70]
00007f4e3fdd60d7  vmovaps [rsp+0x70], xmm1
00007f4e3fdd60dd  movaps xmm15, xmm14
00007f4e3fdd60e1  addpd xmm15, xmm4
00007f4e3fdd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fdd60ec  ptest xmm1, xmm1
00007f4e3fdd60f1  jnz 0x00007F4E3FDD88BC
00007f4e3fdd60f7  vmovaps xmm1, [rsp+0x60]
00007f4e3fdd60fd  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd6103  movaps xmm14, xmm2
00007f4e3fdd6107  mulpd xmm14, xmm1
00007f4e3fdd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f4e3fdd6112  ptest xmm4, xmm4
00007f4e3fdd6117  jnz 0x00007F4E3FDD89FF
00007f4e3fdd611d  vmovaps xmm4, [rsp+0x50]
00007f4e3fdd6123  movaps xmm1, xmm4
00007f4e3fdd6126  addpd xmm1, xmm9
00007f4e3fdd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f4e3fdd6130  ptest xmm2, xmm2
00007f4e3fdd6135  jnz 0x00007F4E3FDD8B41
00007f4e3fdd613b  vmovaps xmm9, [rsp+0x30]
00007f4e3fdd6141  vpermilpd xmm9, xmm9, 0x00
00007f4e3fdd6147  vmovaps xmm2, [rsp+0x70]
00007f4e3fdd614d  vmovaps [rsp+0x50], xmm1
00007f4e3fdd6153  movaps xmm4, xmm2
00007f4e3fdd6156  mulpd xmm4, xmm9
00007f4e3fdd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f4e3fdd6160  ptest xmm1, xmm1
00007f4e3fdd6165  jnz 0x00007F4E3FDD8C82
00007f4e3fdd616b  vmovaps xmm1, [rsp+0x30]
00007f4e3fdd6171  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd6177  vmovaps xmm2, [rsp+0x90]
00007f4e3fdd6180  vmovaps [rsp+0x60], xmm15
00007f4e3fdd6186  movaps xmm9, xmm2
00007f4e3fdd618a  mulpd xmm9, xmm1
00007f4e3fdd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f4e3fdd6195  ptest xmm15, xmm15
00007f4e3fdd619b  jnz 0x00007F4E3FDD8DC3
00007f4e3fdd61a1  vmovaps xmm15, [rsp+0x80]
00007f4e3fdd61aa  movaps xmm1, xmm15
00007f4e3fdd61ae  addpd xmm1, xmm6
00007f4e3fdd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f4e3fdd61b7  ptest xmm2, xmm2
00007f4e3fdd61bc  jnz 0x00007F4E3FDD8F05
00007f4e3fdd61c2  movaps xmm15, xmm5
00007f4e3fdd61c6  addpd xmm15, xmm3
00007f4e3fdd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f4e3fdd61d1  ptest xmm6, xmm6
00007f4e3fdd61d6  jnz 0x00007F4E3FDD9046
00007f4e3fdd61dc  vmovaps xmm6, [rsp+0x30]
00007f4e3fdd61e2  vpermilpd xmm6, xmm6, 0x00
00007f4e3fdd61e8  movaps xmm5, xmm8
00007f4e3fdd61ec  mulpd xmm5, xmm6
00007f4e3fdd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f4e3fdd61f5  ptest xmm3, xmm3
00007f4e3fdd61fa  jnz 0x00007F4E3FDD9188
00007f4e3fdd6200  vmovaps xmm8, [rsp+0x30]
00007f4e3fdd6206  vpermilpd xmm8, xmm8, 0x00
00007f4e3fdd620c  movaps xmm6, xmm10
00007f4e3fdd6210  mulpd xmm6, xmm8
00007f4e3fdd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f4e3fdd621a  ptest xmm3, xmm3
00007f4e3fdd621f  jnz 0x00007F4E3FDD92C9
00007f4e3fdd6225  vmovaps xmm8, [rsp+0x60]
00007f4e3fdd622b  movaps xmm10, xmm8
00007f4e3fdd622f  addpd xmm10, xmm14
00007f4e3fdd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f4e3fdd623a  ptest xmm3, xmm3
00007f4e3fdd623f  jnz 0x00007F4E3FDD940B
00007f4e3fdd6245  vmovaps xmm8, [rsp+0x50]
00007f4e3fdd624b  movaps xmm14, xmm8
00007f4e3fdd624f  addpd xmm14, xmm4
00007f4e3fdd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f4e3fdd625a  ptest xmm3, xmm3
00007f4e3fdd625f  jnz 0x00007F4E3FDD954F
00007f4e3fdd6265  vmovaps xmm8, [rsp+0x40]
00007f4e3fdd626b  vpermilpd xmm8, xmm8, 0x00
00007f4e3fdd6271  movaps xmm4, xmm13
00007f4e3fdd6275  mulpd xmm4, xmm8
00007f4e3fdd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f4e3fdd627f  ptest xmm3, xmm3
00007f4e3fdd6284  jnz 0x00007F4E3FDD9692
00007f4e3fdd628a  movaps xmm13, xmm15
00007f4e3fdd628e  addpd xmm13, xmm9
00007f4e3fdd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f4e3fdd6299  ptest xmm8, xmm8
00007f4e3fdd629f  jnz 0x00007F4E3FDD97D4
00007f4e3fdd62a5  movaps xmm15, xmm1
00007f4e3fdd62a9  addpd xmm15, xmm5
00007f4e3fdd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f4e3fdd62b4  ptest xmm9, xmm9
00007f4e3fdd62ba  jnz 0x00007F4E3FDD9918
00007f4e3fdd62c0  vmovaps [rsp+0x30], xmm11
00007f4e3fdd62c6  vmovaps xmm1, [rsp+0x30]
00007f4e3fdd62cc  por xmm11, xmm1
00007f4e3fdd62d1  movaps [r15+0x250], xmm11
00007f4e3fdd62d9  vmovaps [rsp+0x30], xmm12
00007f4e3fdd62df  vmovaps xmm1, [rsp+0x30]
00007f4e3fdd62e5  por xmm12, xmm1
00007f4e3fdd62ea  movaps [r15+0x2A0], xmm12
00007f4e3fdd62f2  vmovaps xmm1, [rsp+0xA0]
00007f4e3fdd62fb  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd6304  por xmm1, xmm11
00007f4e3fdd6309  movaps [r15+0x1D0], xmm1
00007f4e3fdd6311  lea r14, [rax+0x40]
00007f4e3fdd6315  movups xmm1, [r13+r14*1]
00007f4e3fdd631b  movaps [r15+0x2C0], xmm1
00007f4e3fdd6323  vmovaps xmm11, [rsp+0x40]
00007f4e3fdd6329  vpermilpd xmm11, xmm11, 0x00
00007f4e3fdd632f  vmovaps xmm8, [rsp+0xE0]
00007f4e3fdd6338  movaps xmm9, xmm8
00007f4e3fdd633c  mulpd xmm9, xmm11
00007f4e3fdd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f4e3fdd6347  ptest xmm5, xmm5
00007f4e3fdd634c  jnz 0x00007F4E3FDD9A64
00007f4e3fdd6352  movaps xmm11, xmm10
00007f4e3fdd6356  addpd xmm11, xmm6
00007f4e3fdd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f4e3fdd6361  ptest xmm8, xmm8
00007f4e3fdd6367  jnz 0x00007F4E3FDD9BA8
00007f4e3fdd636d  movaps xmm10, xmm14
00007f4e3fdd6371  addpd xmm10, xmm4
00007f4e3fdd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f4e3fdd637c  ptest xmm8, xmm8
00007f4e3fdd6382  jnz 0x00007F4E3FDD9CEB
00007f4e3fdd6388  vmovaps xmm14, [rsp+0x40]
00007f4e3fdd638e  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdd6394  movaps xmm8, xmm1
00007f4e3fdd6398  mulpd xmm8, xmm14
00007f4e3fdd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4e3fdd63a3  ptest xmm6, xmm6
00007f4e3fdd63a8  jnz 0x00007F4E3FDD9E2E
00007f4e3fdd63ae  movaps xmm1, [r15+0x2B0]
00007f4e3fdd63b6  vmovaps xmm14, [rsp+0x40]
00007f4e3fdd63bc  vpermilpd xmm14, xmm14, 0x00
00007f4e3fdd63c2  movaps xmm6, xmm1
00007f4e3fdd63c5  mulpd xmm6, xmm14
00007f4e3fdd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f4e3fdd63cf  ptest xmm5, xmm5
00007f4e3fdd63d4  jnz 0x00007F4E3FDD9F71
00007f4e3fdd63da  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd63e0  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd63e6  movaps xmm14, xmm12
00007f4e3fdd63ea  mulpd xmm14, xmm1
00007f4e3fdd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f4e3fdd63f5  ptest xmm5, xmm5
00007f4e3fdd63fa  jnz 0x00007F4E3FDDA0B2
00007f4e3fdd6400  movaps xmm1, xmm13
00007f4e3fdd6404  addpd xmm1, xmm9
00007f4e3fdd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f4e3fdd640e  ptest xmm12, xmm12
00007f4e3fdd6414  jnz 0x00007F4E3FDDA1F5
00007f4e3fdd641a  vmovaps xmm13, [rsp+0x10]
00007f4e3fdd6420  vpermilpd xmm13, xmm13, 0x00
00007f4e3fdd6426  movaps xmm12, xmm7
00007f4e3fdd642a  mulpd xmm12, xmm13
00007f4e3fdd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4e3fdd6435  ptest xmm9, xmm9
00007f4e3fdd643b  jnz 0x00007F4E3FDDA337
00007f4e3fdd6441  movaps xmm13, xmm15
00007f4e3fdd6445  addpd xmm13, xmm8
00007f4e3fdd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f4e3fdd6450  ptest xmm9, xmm9
00007f4e3fdd6456  jnz 0x00007F4E3FDDA47A
00007f4e3fdd645c  movaps xmm15, [r15+0x290]
00007f4e3fdd6464  vmovaps xmm9, [rsp+0x10]
00007f4e3fdd646a  vpermilpd xmm9, xmm9, 0x00
00007f4e3fdd6470  movaps xmm8, xmm15
00007f4e3fdd6474  mulpd xmm8, xmm9
00007f4e3fdd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f4e3fdd647f  ptest xmm7, xmm7
00007f4e3fdd6484  jnz 0x00007F4E3FDDA5BE
00007f4e3fdd648a  movaps xmm15, xmm11
00007f4e3fdd648e  addpd xmm15, xmm6
00007f4e3fdd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f4e3fdd6499  ptest xmm9, xmm9
00007f4e3fdd649f  jnz 0x00007F4E3FDDA702
00007f4e3fdd64a5  movaps xmm11, [r15+0x1E0]
00007f4e3fdd64ad  vmovaps xmm9, [rsp+0x10]
00007f4e3fdd64b3  vpermilpd xmm9, xmm9, 0x00
00007f4e3fdd64b9  movaps xmm7, xmm11
00007f4e3fdd64bd  mulpd xmm7, xmm9
00007f4e3fdd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4e3fdd64c7  ptest xmm6, xmm6
00007f4e3fdd64cc  jnz 0x00007F4E3FDDA845
00007f4e3fdd64d2  movaps xmm11, xmm10
00007f4e3fdd64d6  addpd xmm11, xmm14
00007f4e3fdd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f4e3fdd64e1  ptest xmm9, xmm9
00007f4e3fdd64e7  jnz 0x00007F4E3FDDA987
00007f4e3fdd64ed  lea r14, [rax+0x70]
00007f4e3fdd64f1  movups xmm14, [r13+r14*1]
00007f4e3fdd64f7  movaps [r15+0x240], xmm14
00007f4e3fdd64ff  movaps xmm10, xmm1
00007f4e3fdd6503  addpd xmm10, xmm12
00007f4e3fdd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f4e3fdd650e  ptest xmm9, xmm9
00007f4e3fdd6514  jnz 0x00007F4E3FDDAAD5
00007f4e3fdd651a  movaps [r15+0x170], xmm10
00007f4e3fdd6522  vmovaps xmm1, [rsp+0x20]
00007f4e3fdd6528  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd652e  movaps xmm12, xmm14
00007f4e3fdd6532  mulpd xmm12, xmm1
00007f4e3fdd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4e3fdd653d  ptest xmm9, xmm9
00007f4e3fdd6543  jnz 0x00007F4E3FDDAC18
00007f4e3fdd6549  vmovaps xmm1, [rsp+0x20]
00007f4e3fdd654f  vpermilpd xmm1, xmm1, 0x00
00007f4e3fdd6555  vmovaps xmm9, [rsp+0xB0]
00007f4e3fdd655e  movaps xmm14, xmm9
00007f4e3fdd6562  mulpd xmm14, xmm1
00007f4e3fdd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f4e3fdd656d  ptest xmm6, xmm6
00007f4e3fdd6572  jnz 0x00007F4E3FDDAD5B
00007f4e3fdd6578  movaps [r15+0x180], xmm14
00007f4e3fdd6580  movaps xmm1, xmm13
00007f4e3fdd6584  addpd xmm1, xmm8
00007f4e3fdd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f4e3fdd658e  ptest xmm9, xmm9
00007f4e3fdd6594  jnz 0x00007F4E3FDDAE9E
00007f4e3fdd659a  movaps [r15+0x210], xmm1
00007f4e3fdd65a2  movups xmm13, [r13+rax*1]
00007f4e3fdd65a8  lea r14, [rax+0x10]
00007f4e3fdd65ac  movups xmm9, [r13+r14*1]
00007f4e3fdd65b2  movaps [r15+0x230], xmm9
00007f4e3fdd65ba  movaps xmm8, xmm15
00007f4e3fdd65be  addpd xmm8, xmm7
00007f4e3fdd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4e3fdd65c9  ptest xmm6, xmm6
00007f4e3fdd65ce  jnz 0x00007F4E3FDDAFF4
00007f4e3fdd65d4  movaps [r15+0x130], xmm8
00007f4e3fdd65dc  vmovaps xmm15, [rsp+0x20]
00007f4e3fdd65e2  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdd65e8  movaps xmm7, xmm9
00007f4e3fdd65ec  mulpd xmm7, xmm15
00007f4e3fdd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4e3fdd65f6  ptest xmm6, xmm6
00007f4e3fdd65fb  jnz 0x00007F4E3FDDB137
00007f4e3fdd6601  movaps [r15+0x220], xmm7
00007f4e3fdd6609  vmovaps xmm15, [rsp+0x20]
00007f4e3fdd660f  vpermilpd xmm15, xmm15, 0x00
00007f4e3fdd6615  movaps xmm9, xmm13
00007f4e3fdd6619  mulpd xmm9, xmm15
00007f4e3fdd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f4e3fdd6624  ptest xmm6, xmm6
00007f4e3fdd6629  jnz 0x00007F4E3FDDB279
00007f4e3fdd662f  movaps xmm15, xmm11
00007f4e3fdd6633  addpd xmm15, xmm12
00007f4e3fdd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f4e3fdd663e  ptest xmm13, xmm13
00007f4e3fdd6644  jnz 0x00007F4E3FDDB3BD
00007f4e3fdd664a  movaps [r15+0x140], xmm15
00007f4e3fdd6652  movaps xmm13, xmm10
00007f4e3fdd6656  addpd xmm13, xmm14
00007f4e3fdd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4e3fdd6661  ptest xmm12, xmm12
00007f4e3fdd6667  jnz 0x00007F4E3FDDB501
00007f4e3fdd666d  movaps [r15+0x150], xmm13
00007f4e3fdd6675  movaps xmm14, xmm1
00007f4e3fdd6679  addpd xmm14, xmm7
00007f4e3fdd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f4e3fdd6684  ptest xmm12, xmm12
00007f4e3fdd668a  jnz 0x00007F4E3FDDB645
00007f4e3fdd6690  movaps [r15+0x160], xmm14
00007f4e3fdd6698  movaps xmm1, xmm8
00007f4e3fdd669c  addpd xmm1, xmm9
00007f4e3fdd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f4e3fdd66a6  ptest xmm12, xmm12
00007f4e3fdd66ac  jnz 0x00007F4E3FDDB787
00007f4e3fdd66b2  movaps [r15+0x120], xmm1
00007f4e3fdd66ba  movups [r13+r11*1], xmm15
00007f4e3fdd66c0  lea rax, [r11+0x10]
00007f4e3fdd66c4  movups [r13+rax*1], xmm13
00007f4e3fdd66ca  lea rax, [r11+0x20]
00007f4e3fdd66ce  movups [r13+rax*1], xmm14
00007f4e3fdd66d4  lea rax, [r11+0x30]
00007f4e3fdd66d8  movups [r13+rax*1], xmm1
00007f4e3fdd66de  mov eax, [r15+0x108]
00007f4e3fdd66e5  sahf
00007f4e3fdd66e6  jnz 0x00007F4E3FDD6718
00007f4e3fdd66e8  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdd66f0  jz 0x00007F4E3FDDB900
00007f4e3fdd66f6  nop [rax+rax*1], ax
00007f4e3fdd66ff  nop [rax+rax*1], eax
00007f4e3fdd6707  mov eax, 0x410444
00007f4e3fdd670c  mov [r15+0x100], rax
00007f4e3fdd6713  jmp 0x00007F4E3FBFE110
00007f4e3fdd6718  cmp dword ptr [r15+0x318], 0x00
00007f4e3fdd6720  jz 0x00007F4E3FDD57E0
00007f4e3fdd6726  nop [rax+rax*1], ax
00007f4e3fdd672f  nop [rax+rax*1], eax
00007f4e3fdd6737  mov eax, 0x410278
00007f4e3fdd673c  mov [r15+0x100], rax
00007f4e3fdd6743  jmp 0x00007F4E3FBFE110
00007f4e3fdd6748  int3
00007f4e3fdd6749  call 0x00007F4E3FC0A4B0
00007f4e3fdd674e  jmp 0x00007F4E3FDD5828
00007f4e3fdd6753  call 0x00007F4E3FC09240
00007f4e3fdd6758  jmp 0x00007F4E3FDD5832
00007f4e3fdd675d  call 0x00007F4E3FC0A4B0
00007f4e3fdd6762  jmp 0x00007F4E3FDD588F
00007f4e3fdd6767  call 0x00007F4E3FC09240
00007f4e3fdd676c  jmp 0x00007F4E3FDD5899
00007f4e3fdd6771  call 0x00007F4E3FC0A4B0
00007f4e3fdd6776  jmp 0x00007F4E3FDD58DD
00007f4e3fdd677b  call 0x00007F4E3FC09240
00007f4e3fdd6780  jmp 0x00007F4E3FDD58E7
00007f4e3fdd6785  call 0x00007F4E3FCB47C0
00007f4e3fdd678a  jmp 0x00007F4E3FDD5926
00007f4e3fdd678f  call 0x00007F4E3FC0B720
00007f4e3fdd6794  jmp 0x00007F4E3FDD593A
00007f4e3fdd6799  call 0x00007F4E3FCBFC30
00007f4e3fdd679e  jmp 0x00007F4E3FDD5958
00007f4e3fdd67a3  call 0x00007F4E3FCBE9C0
00007f4e3fdd67a8  jmp 0x00007F4E3FDD5962
00007f4e3fdd67ad  call 0x00007F4E3FCBD750
00007f4e3fdd67b2  jmp 0x00007F4E3FDD596C
00007f4e3fdd67b7  sub rsp, 0x08
00007f4e3fdd67bb  push rax
00007f4e3fdd67bc  push rcx
00007f4e3fdd67bd  push rdx
00007f4e3fdd67be  push rdi
00007f4e3fdd67bf  push rsi
00007f4e3fdd67c0  push r8
00007f4e3fdd67c2  push r9
00007f4e3fdd67c4  push r10
00007f4e3fdd67c6  push r11
00007f4e3fdd67c8  sub rsp, 0xF0
00007f4e3fdd67cf  vmovaps [rsp], xmm0
00007f4e3fdd67d4  vmovaps [rsp+0x10], xmm1
00007f4e3fdd67da  vmovaps [rsp+0x20], xmm2
00007f4e3fdd67e0  vmovaps [rsp+0x30], xmm3
00007f4e3fdd67e6  vmovaps [rsp+0x40], xmm4
00007f4e3fdd67ec  vmovaps [rsp+0x50], xmm5
00007f4e3fdd67f2  vmovaps [rsp+0x60], xmm6
00007f4e3fdd67f8  vmovaps [rsp+0x70], xmm7
00007f4e3fdd67fe  vmovaps [rsp+0x80], xmm9
00007f4e3fdd6807  vmovaps [rsp+0x90], xmm10
00007f4e3fdd6810  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd6819  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd6822  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd682b  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd6834  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd683d  sub rsp, 0x30
00007f4e3fdd6841  movaps [rsp], xmm8
00007f4e3fdd6846  movaps [rsp+0x10], xmm12
00007f4e3fdd684c  movaps [rsp+0x20], xmm15
00007f4e3fdd6852  lea rdi, [rsp]
00007f4e3fdd6856  mov esi, 0x00
00007f4e3fdd685b  mov rax, 0x5D97141E9530
00007f4e3fdd6865  call rax
00007f4e3fdd6867  movaps xmm8, [rsp]
00007f4e3fdd686c  add rsp, 0x30
00007f4e3fdd6870  vmovaps xmm0, [rsp]
00007f4e3fdd6875  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd687b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd6881  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd6887  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd688d  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd6893  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd6899  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd689f  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd68a8  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd68b1  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd68ba  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd68c3  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd68cc  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd68d5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd68de  add rsp, 0xF0
00007f4e3fdd68e5  pop r11
00007f4e3fdd68e7  pop r10
00007f4e3fdd68e9  pop r9
00007f4e3fdd68eb  pop r8
00007f4e3fdd68ed  pop rsi
00007f4e3fdd68ee  pop rdi
00007f4e3fdd68ef  pop rdx
00007f4e3fdd68f0  pop rcx
00007f4e3fdd68f1  pop rax
00007f4e3fdd68f2  add rsp, 0x08
00007f4e3fdd68f6  jmp 0x00007F4E3FDD599A
00007f4e3fdd68fb  sub rsp, 0x08
00007f4e3fdd68ff  push rax
00007f4e3fdd6900  push rcx
00007f4e3fdd6901  push rdx
00007f4e3fdd6902  push rdi
00007f4e3fdd6903  push rsi
00007f4e3fdd6904  push r8
00007f4e3fdd6906  push r9
00007f4e3fdd6908  push r10
00007f4e3fdd690a  push r11
00007f4e3fdd690c  sub rsp, 0xF0
00007f4e3fdd6913  vmovaps [rsp], xmm0
00007f4e3fdd6918  vmovaps [rsp+0x10], xmm1
00007f4e3fdd691e  vmovaps [rsp+0x20], xmm2
00007f4e3fdd6924  vmovaps [rsp+0x30], xmm3
00007f4e3fdd692a  vmovaps [rsp+0x40], xmm4
00007f4e3fdd6930  vmovaps [rsp+0x50], xmm5
00007f4e3fdd6936  vmovaps [rsp+0x60], xmm6
00007f4e3fdd693c  vmovaps [rsp+0x70], xmm8
00007f4e3fdd6942  vmovaps [rsp+0x80], xmm9
00007f4e3fdd694b  vmovaps [rsp+0x90], xmm10
00007f4e3fdd6954  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd695d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd6966  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd696f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd6978  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd6981  sub rsp, 0x30
00007f4e3fdd6985  movaps [rsp], xmm7
00007f4e3fdd6989  movaps [rsp+0x10], xmm9
00007f4e3fdd698f  movaps [rsp+0x20], xmm15
00007f4e3fdd6995  lea rdi, [rsp]
00007f4e3fdd6999  mov esi, 0x00
00007f4e3fdd699e  mov rax, 0x5D97141E9530
00007f4e3fdd69a8  call rax
00007f4e3fdd69aa  movaps xmm7, [rsp]
00007f4e3fdd69ae  add rsp, 0x30
00007f4e3fdd69b2  vmovaps xmm0, [rsp]
00007f4e3fdd69b7  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd69bd  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd69c3  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd69c9  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd69cf  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd69d5  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd69db  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd69e1  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd69ea  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd69f3  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd69fc  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd6a05  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd6a0e  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd6a17  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd6a20  add rsp, 0xF0
00007f4e3fdd6a27  pop r11
00007f4e3fdd6a29  pop r10
00007f4e3fdd6a2b  pop r9
00007f4e3fdd6a2d  pop r8
00007f4e3fdd6a2f  pop rsi
00007f4e3fdd6a30  pop rdi
00007f4e3fdd6a31  pop rdx
00007f4e3fdd6a32  pop rcx
00007f4e3fdd6a33  pop rax
00007f4e3fdd6a34  add rsp, 0x08
00007f4e3fdd6a38  jmp 0x00007F4E3FDD59C8
00007f4e3fdd6a3d  sub rsp, 0x08
00007f4e3fdd6a41  push rax
00007f4e3fdd6a42  push rcx
00007f4e3fdd6a43  push rdx
00007f4e3fdd6a44  push rdi
00007f4e3fdd6a45  push rsi
00007f4e3fdd6a46  push r8
00007f4e3fdd6a48  push r9
00007f4e3fdd6a4a  push r10
00007f4e3fdd6a4c  push r11
00007f4e3fdd6a4e  sub rsp, 0xF0
00007f4e3fdd6a55  vmovaps [rsp], xmm0
00007f4e3fdd6a5a  vmovaps [rsp+0x10], xmm1
00007f4e3fdd6a60  vmovaps [rsp+0x20], xmm2
00007f4e3fdd6a66  vmovaps [rsp+0x30], xmm3
00007f4e3fdd6a6c  vmovaps [rsp+0x40], xmm4
00007f4e3fdd6a72  vmovaps [rsp+0x50], xmm5
00007f4e3fdd6a78  vmovaps [rsp+0x60], xmm6
00007f4e3fdd6a7e  vmovaps [rsp+0x70], xmm7
00007f4e3fdd6a84  vmovaps [rsp+0x80], xmm8
00007f4e3fdd6a8d  vmovaps [rsp+0x90], xmm10
00007f4e3fdd6a96  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd6a9f  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd6aa8  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd6ab1  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd6aba  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd6ac3  sub rsp, 0x30
00007f4e3fdd6ac7  movaps [rsp], xmm9
00007f4e3fdd6acc  movaps [rsp+0x10], xmm12
00007f4e3fdd6ad2  movaps [rsp+0x20], xmm10
00007f4e3fdd6ad8  lea rdi, [rsp]
00007f4e3fdd6adc  mov esi, 0x00
00007f4e3fdd6ae1  mov rax, 0x5D97141E9530
00007f4e3fdd6aeb  call rax
00007f4e3fdd6aed  movaps xmm9, [rsp]
00007f4e3fdd6af2  add rsp, 0x30
00007f4e3fdd6af6  vmovaps xmm0, [rsp]
00007f4e3fdd6afb  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd6b01  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd6b07  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd6b0d  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd6b13  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd6b19  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd6b1f  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd6b25  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd6b2e  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd6b37  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd6b40  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd6b49  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd6b52  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd6b5b  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd6b64  add rsp, 0xF0
00007f4e3fdd6b6b  pop r11
00007f4e3fdd6b6d  pop r10
00007f4e3fdd6b6f  pop r9
00007f4e3fdd6b71  pop r8
00007f4e3fdd6b73  pop rsi
00007f4e3fdd6b74  pop rdi
00007f4e3fdd6b75  pop rdx
00007f4e3fdd6b76  pop rcx
00007f4e3fdd6b77  pop rax
00007f4e3fdd6b78  add rsp, 0x08
00007f4e3fdd6b7c  jmp 0x00007F4E3FDD59EC
00007f4e3fdd6b81  sub rsp, 0x08
00007f4e3fdd6b85  push rax
00007f4e3fdd6b86  push rcx
00007f4e3fdd6b87  push rdx
00007f4e3fdd6b88  push rdi
00007f4e3fdd6b89  push rsi
00007f4e3fdd6b8a  push r8
00007f4e3fdd6b8c  push r9
00007f4e3fdd6b8e  push r10
00007f4e3fdd6b90  push r11
00007f4e3fdd6b92  sub rsp, 0xF0
00007f4e3fdd6b99  vmovaps [rsp], xmm0
00007f4e3fdd6b9e  vmovaps [rsp+0x10], xmm1
00007f4e3fdd6ba4  vmovaps [rsp+0x20], xmm2
00007f4e3fdd6baa  vmovaps [rsp+0x30], xmm3
00007f4e3fdd6bb0  vmovaps [rsp+0x40], xmm4
00007f4e3fdd6bb6  vmovaps [rsp+0x50], xmm5
00007f4e3fdd6bbc  vmovaps [rsp+0x60], xmm6
00007f4e3fdd6bc2  vmovaps [rsp+0x70], xmm7
00007f4e3fdd6bc8  vmovaps [rsp+0x80], xmm8
00007f4e3fdd6bd1  vmovaps [rsp+0x90], xmm9
00007f4e3fdd6bda  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd6be3  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd6bec  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd6bf5  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd6bfe  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd6c07  sub rsp, 0x30
00007f4e3fdd6c0b  movaps [rsp], xmm10
00007f4e3fdd6c10  movaps [rsp+0x10], xmm12
00007f4e3fdd6c16  movaps [rsp+0x20], xmm11
00007f4e3fdd6c1c  lea rdi, [rsp]
00007f4e3fdd6c20  mov esi, 0x00
00007f4e3fdd6c25  mov rax, 0x5D97141E9530
00007f4e3fdd6c2f  call rax
00007f4e3fdd6c31  movaps xmm10, [rsp]
00007f4e3fdd6c36  add rsp, 0x30
00007f4e3fdd6c3a  vmovaps xmm0, [rsp]
00007f4e3fdd6c3f  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd6c45  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd6c4b  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd6c51  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd6c57  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd6c5d  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd6c63  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd6c69  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd6c72  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd6c7b  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd6c84  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd6c8d  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd6c96  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd6c9f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd6ca8  add rsp, 0xF0
00007f4e3fdd6caf  pop r11
00007f4e3fdd6cb1  pop r10
00007f4e3fdd6cb3  pop r9
00007f4e3fdd6cb5  pop r8
00007f4e3fdd6cb7  pop rsi
00007f4e3fdd6cb8  pop rdi
00007f4e3fdd6cb9  pop rdx
00007f4e3fdd6cba  pop rcx
00007f4e3fdd6cbb  pop rax
00007f4e3fdd6cbc  add rsp, 0x08
00007f4e3fdd6cc0  jmp 0x00007F4E3FDD5A06
00007f4e3fdd6cc5  sub rsp, 0x08
00007f4e3fdd6cc9  push rax
00007f4e3fdd6cca  push rcx
00007f4e3fdd6ccb  push rdx
00007f4e3fdd6ccc  push rdi
00007f4e3fdd6ccd  push rsi
00007f4e3fdd6cce  push r8
00007f4e3fdd6cd0  push r9
00007f4e3fdd6cd2  push r10
00007f4e3fdd6cd4  push r11
00007f4e3fdd6cd6  sub rsp, 0xF0
00007f4e3fdd6cdd  vmovaps [rsp], xmm0
00007f4e3fdd6ce2  vmovaps [rsp+0x10], xmm1
00007f4e3fdd6ce8  vmovaps [rsp+0x20], xmm2
00007f4e3fdd6cee  vmovaps [rsp+0x30], xmm3
00007f4e3fdd6cf4  vmovaps [rsp+0x40], xmm4
00007f4e3fdd6cfa  vmovaps [rsp+0x50], xmm5
00007f4e3fdd6d00  vmovaps [rsp+0x60], xmm7
00007f4e3fdd6d06  vmovaps [rsp+0x70], xmm8
00007f4e3fdd6d0c  vmovaps [rsp+0x80], xmm9
00007f4e3fdd6d15  vmovaps [rsp+0x90], xmm10
00007f4e3fdd6d1e  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd6d27  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd6d30  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd6d39  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd6d42  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd6d4b  sub rsp, 0x30
00007f4e3fdd6d4f  movaps [rsp], xmm6
00007f4e3fdd6d53  movaps [rsp+0x10], xmm12
00007f4e3fdd6d59  movaps [rsp+0x20], xmm11
00007f4e3fdd6d5f  lea rdi, [rsp]
00007f4e3fdd6d63  mov esi, 0x00
00007f4e3fdd6d68  mov rax, 0x5D97141E9530
00007f4e3fdd6d72  call rax
00007f4e3fdd6d74  movaps xmm6, [rsp]
00007f4e3fdd6d78  add rsp, 0x30
00007f4e3fdd6d7c  vmovaps xmm0, [rsp]
00007f4e3fdd6d81  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd6d87  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd6d8d  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd6d93  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd6d99  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd6d9f  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd6da5  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd6dab  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd6db4  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd6dbd  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd6dc6  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd6dcf  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd6dd8  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd6de1  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd6dea  add rsp, 0xF0
00007f4e3fdd6df1  pop r11
00007f4e3fdd6df3  pop r10
00007f4e3fdd6df5  pop r9
00007f4e3fdd6df7  pop r8
00007f4e3fdd6df9  pop rsi
00007f4e3fdd6dfa  pop rdi
00007f4e3fdd6dfb  pop rdx
00007f4e3fdd6dfc  pop rcx
00007f4e3fdd6dfd  pop rax
00007f4e3fdd6dfe  add rsp, 0x08
00007f4e3fdd6e02  jmp 0x00007F4E3FDD5A27
00007f4e3fdd6e07  sub rsp, 0x08
00007f4e3fdd6e0b  push rax
00007f4e3fdd6e0c  push rcx
00007f4e3fdd6e0d  push rdx
00007f4e3fdd6e0e  push rdi
00007f4e3fdd6e0f  push rsi
00007f4e3fdd6e10  push r8
00007f4e3fdd6e12  push r9
00007f4e3fdd6e14  push r10
00007f4e3fdd6e16  push r11
00007f4e3fdd6e18  sub rsp, 0xF0
00007f4e3fdd6e1f  vmovaps [rsp], xmm0
00007f4e3fdd6e24  vmovaps [rsp+0x10], xmm1
00007f4e3fdd6e2a  vmovaps [rsp+0x20], xmm2
00007f4e3fdd6e30  vmovaps [rsp+0x30], xmm4
00007f4e3fdd6e36  vmovaps [rsp+0x40], xmm5
00007f4e3fdd6e3c  vmovaps [rsp+0x50], xmm6
00007f4e3fdd6e42  vmovaps [rsp+0x60], xmm7
00007f4e3fdd6e48  vmovaps [rsp+0x70], xmm8
00007f4e3fdd6e4e  vmovaps [rsp+0x80], xmm9
00007f4e3fdd6e57  vmovaps [rsp+0x90], xmm10
00007f4e3fdd6e60  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd6e69  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd6e72  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd6e7b  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd6e84  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd6e8d  sub rsp, 0x30
00007f4e3fdd6e91  movaps [rsp], xmm3
00007f4e3fdd6e95  movaps [rsp+0x10], xmm5
00007f4e3fdd6e9a  movaps [rsp+0x20], xmm4
00007f4e3fdd6e9f  lea rdi, [rsp]
00007f4e3fdd6ea3  mov esi, 0x00
00007f4e3fdd6ea8  mov rax, 0x5D97141E9530
00007f4e3fdd6eb2  call rax
00007f4e3fdd6eb4  movaps xmm3, [rsp]
00007f4e3fdd6eb8  add rsp, 0x30
00007f4e3fdd6ebc  vmovaps xmm0, [rsp]
00007f4e3fdd6ec1  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd6ec7  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd6ecd  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd6ed3  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd6ed9  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd6edf  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd6ee5  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd6eeb  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd6ef4  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd6efd  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd6f06  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd6f0f  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd6f18  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd6f21  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd6f2a  add rsp, 0xF0
00007f4e3fdd6f31  pop r11
00007f4e3fdd6f33  pop r10
00007f4e3fdd6f35  pop r9
00007f4e3fdd6f37  pop r8
00007f4e3fdd6f39  pop rsi
00007f4e3fdd6f3a  pop rdi
00007f4e3fdd6f3b  pop rdx
00007f4e3fdd6f3c  pop rcx
00007f4e3fdd6f3d  pop rax
00007f4e3fdd6f3e  add rsp, 0x08
00007f4e3fdd6f42  jmp 0x00007F4E3FDD5A88
00007f4e3fdd6f47  sub rsp, 0x08
00007f4e3fdd6f4b  push rax
00007f4e3fdd6f4c  push rcx
00007f4e3fdd6f4d  push rdx
00007f4e3fdd6f4e  push rdi
00007f4e3fdd6f4f  push rsi
00007f4e3fdd6f50  push r8
00007f4e3fdd6f52  push r9
00007f4e3fdd6f54  push r10
00007f4e3fdd6f56  push r11
00007f4e3fdd6f58  sub rsp, 0xF0
00007f4e3fdd6f5f  vmovaps [rsp], xmm0
00007f4e3fdd6f64  vmovaps [rsp+0x10], xmm1
00007f4e3fdd6f6a  vmovaps [rsp+0x20], xmm2
00007f4e3fdd6f70  vmovaps [rsp+0x30], xmm3
00007f4e3fdd6f76  vmovaps [rsp+0x40], xmm4
00007f4e3fdd6f7c  vmovaps [rsp+0x50], xmm6
00007f4e3fdd6f82  vmovaps [rsp+0x60], xmm7
00007f4e3fdd6f88  vmovaps [rsp+0x70], xmm8
00007f4e3fdd6f8e  vmovaps [rsp+0x80], xmm9
00007f4e3fdd6f97  vmovaps [rsp+0x90], xmm10
00007f4e3fdd6fa0  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd6fa9  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd6fb2  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd6fbb  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd6fc4  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd6fcd  sub rsp, 0x30
00007f4e3fdd6fd1  movaps [rsp], xmm5
00007f4e3fdd6fd5  movaps [rsp+0x10], xmm8
00007f4e3fdd6fdb  movaps [rsp+0x20], xmm15
00007f4e3fdd6fe1  lea rdi, [rsp]
00007f4e3fdd6fe5  mov esi, 0x00
00007f4e3fdd6fea  mov rax, 0x5D97141E9530
00007f4e3fdd6ff4  call rax
00007f4e3fdd6ff6  movaps xmm5, [rsp]
00007f4e3fdd6ffa  add rsp, 0x30
00007f4e3fdd6ffe  vmovaps xmm0, [rsp]
00007f4e3fdd7003  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd7009  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd700f  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd7015  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd701b  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd7021  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd7027  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd702d  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7036  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd703f  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd7048  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd7051  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd705a  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd7063  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd706c  add rsp, 0xF0
00007f4e3fdd7073  pop r11
00007f4e3fdd7075  pop r10
00007f4e3fdd7077  pop r9
00007f4e3fdd7079  pop r8
00007f4e3fdd707b  pop rsi
00007f4e3fdd707c  pop rdi
00007f4e3fdd707d  pop rdx
00007f4e3fdd707e  pop rcx
00007f4e3fdd707f  pop rax
00007f4e3fdd7080  add rsp, 0x08
00007f4e3fdd7084  jmp 0x00007F4E3FDD5AC0
00007f4e3fdd7089  sub rsp, 0x08
00007f4e3fdd708d  push rax
00007f4e3fdd708e  push rcx
00007f4e3fdd708f  push rdx
00007f4e3fdd7090  push rdi
00007f4e3fdd7091  push rsi
00007f4e3fdd7092  push r8
00007f4e3fdd7094  push r9
00007f4e3fdd7096  push r10
00007f4e3fdd7098  push r11
00007f4e3fdd709a  sub rsp, 0xF0
00007f4e3fdd70a1  vmovaps [rsp], xmm0
00007f4e3fdd70a6  vmovaps [rsp+0x10], xmm1
00007f4e3fdd70ac  vmovaps [rsp+0x20], xmm2
00007f4e3fdd70b2  vmovaps [rsp+0x30], xmm3
00007f4e3fdd70b8  vmovaps [rsp+0x40], xmm5
00007f4e3fdd70be  vmovaps [rsp+0x50], xmm6
00007f4e3fdd70c4  vmovaps [rsp+0x60], xmm7
00007f4e3fdd70ca  vmovaps [rsp+0x70], xmm8
00007f4e3fdd70d0  vmovaps [rsp+0x80], xmm9
00007f4e3fdd70d9  vmovaps [rsp+0x90], xmm10
00007f4e3fdd70e2  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd70eb  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd70f4  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd70fd  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd7106  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd710f  sub rsp, 0x30
00007f4e3fdd7113  movaps [rsp], xmm4
00007f4e3fdd7117  movaps [rsp+0x10], xmm9
00007f4e3fdd711d  movaps [rsp+0x20], xmm8
00007f4e3fdd7123  lea rdi, [rsp]
00007f4e3fdd7127  mov esi, 0x00
00007f4e3fdd712c  mov rax, 0x5D97141E9530
00007f4e3fdd7136  call rax
00007f4e3fdd7138  movaps xmm4, [rsp]
00007f4e3fdd713c  add rsp, 0x30
00007f4e3fdd7140  vmovaps xmm0, [rsp]
00007f4e3fdd7145  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd714b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd7151  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd7157  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd715d  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd7163  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd7169  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd716f  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7178  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd7181  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd718a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd7193  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd719c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd71a5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd71ae  add rsp, 0xF0
00007f4e3fdd71b5  pop r11
00007f4e3fdd71b7  pop r10
00007f4e3fdd71b9  pop r9
00007f4e3fdd71bb  pop r8
00007f4e3fdd71bd  pop rsi
00007f4e3fdd71be  pop rdi
00007f4e3fdd71bf  pop rdx
00007f4e3fdd71c0  pop rcx
00007f4e3fdd71c1  pop rax
00007f4e3fdd71c2  add rsp, 0x08
00007f4e3fdd71c6  jmp 0x00007F4E3FDD5AE1
00007f4e3fdd71cb  sub rsp, 0x08
00007f4e3fdd71cf  push rax
00007f4e3fdd71d0  push rcx
00007f4e3fdd71d1  push rdx
00007f4e3fdd71d2  push rdi
00007f4e3fdd71d3  push rsi
00007f4e3fdd71d4  push r8
00007f4e3fdd71d6  push r9
00007f4e3fdd71d8  push r10
00007f4e3fdd71da  push r11
00007f4e3fdd71dc  sub rsp, 0xF0
00007f4e3fdd71e3  vmovaps [rsp], xmm0
00007f4e3fdd71e8  vmovaps [rsp+0x10], xmm1
00007f4e3fdd71ee  vmovaps [rsp+0x20], xmm2
00007f4e3fdd71f4  vmovaps [rsp+0x30], xmm3
00007f4e3fdd71fa  vmovaps [rsp+0x40], xmm4
00007f4e3fdd7200  vmovaps [rsp+0x50], xmm5
00007f4e3fdd7206  vmovaps [rsp+0x60], xmm6
00007f4e3fdd720c  vmovaps [rsp+0x70], xmm7
00007f4e3fdd7212  vmovaps [rsp+0x80], xmm8
00007f4e3fdd721b  vmovaps [rsp+0x90], xmm10
00007f4e3fdd7224  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd722d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd7236  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd723f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd7248  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd7251  sub rsp, 0x30
00007f4e3fdd7255  movaps [rsp], xmm9
00007f4e3fdd725a  movaps [rsp+0x10], xmm10
00007f4e3fdd7260  movaps [rsp+0x20], xmm8
00007f4e3fdd7266  lea rdi, [rsp]
00007f4e3fdd726a  mov esi, 0x00
00007f4e3fdd726f  mov rax, 0x5D97141E9530
00007f4e3fdd7279  call rax
00007f4e3fdd727b  movaps xmm9, [rsp]
00007f4e3fdd7280  add rsp, 0x30
00007f4e3fdd7284  vmovaps xmm0, [rsp]
00007f4e3fdd7289  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd728f  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd7295  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd729b  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd72a1  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd72a7  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd72ad  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd72b3  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd72bc  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd72c5  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd72ce  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd72d7  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd72e0  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd72e9  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd72f2  add rsp, 0xF0
00007f4e3fdd72f9  pop r11
00007f4e3fdd72fb  pop r10
00007f4e3fdd72fd  pop r9
00007f4e3fdd72ff  pop r8
00007f4e3fdd7301  pop rsi
00007f4e3fdd7302  pop rdi
00007f4e3fdd7303  pop rdx
00007f4e3fdd7304  pop rcx
00007f4e3fdd7305  pop rax
00007f4e3fdd7306  add rsp, 0x08
00007f4e3fdd730a  jmp 0x00007F4E3FDD5AFB
00007f4e3fdd730f  call 0x00007F4E3FCD64F0
00007f4e3fdd7314  jmp 0x00007F4E3FDD5C15
00007f4e3fdd7319  call 0x00007F4E3FCD64F0
00007f4e3fdd731e  jmp 0x00007F4E3FDD5C2B
00007f4e3fdd7323  sub rsp, 0x08
00007f4e3fdd7327  push rax
00007f4e3fdd7328  push rcx
00007f4e3fdd7329  push rdx
00007f4e3fdd732a  push rdi
00007f4e3fdd732b  push rsi
00007f4e3fdd732c  push r8
00007f4e3fdd732e  push r9
00007f4e3fdd7330  push r10
00007f4e3fdd7332  push r11
00007f4e3fdd7334  sub rsp, 0xF0
00007f4e3fdd733b  vmovaps [rsp], xmm0
00007f4e3fdd7340  vmovaps [rsp+0x10], xmm2
00007f4e3fdd7346  vmovaps [rsp+0x20], xmm3
00007f4e3fdd734c  vmovaps [rsp+0x30], xmm4
00007f4e3fdd7352  vmovaps [rsp+0x40], xmm5
00007f4e3fdd7358  vmovaps [rsp+0x50], xmm6
00007f4e3fdd735e  vmovaps [rsp+0x60], xmm7
00007f4e3fdd7364  vmovaps [rsp+0x70], xmm8
00007f4e3fdd736a  vmovaps [rsp+0x80], xmm9
00007f4e3fdd7373  vmovaps [rsp+0x90], xmm10
00007f4e3fdd737c  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd7385  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd738e  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd7397  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd73a0  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd73a9  sub rsp, 0x30
00007f4e3fdd73ad  movaps [rsp], xmm1
00007f4e3fdd73b1  movaps [rsp+0x10], xmm6
00007f4e3fdd73b6  movaps [rsp+0x20], xmm15
00007f4e3fdd73bc  lea rdi, [rsp]
00007f4e3fdd73c0  mov esi, 0x00
00007f4e3fdd73c5  mov rax, 0x5D97141E9530
00007f4e3fdd73cf  call rax
00007f4e3fdd73d1  movaps xmm1, [rsp]
00007f4e3fdd73d5  add rsp, 0x30
00007f4e3fdd73d9  vmovaps xmm0, [rsp]
00007f4e3fdd73de  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd73e4  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd73ea  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd73f0  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd73f6  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd73fc  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd7402  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd7408  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7411  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd741a  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd7423  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd742c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd7435  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd743e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7447  add rsp, 0xF0
00007f4e3fdd744e  pop r11
00007f4e3fdd7450  pop r10
00007f4e3fdd7452  pop r9
00007f4e3fdd7454  pop r8
00007f4e3fdd7456  pop rsi
00007f4e3fdd7457  pop rdi
00007f4e3fdd7458  pop rdx
00007f4e3fdd7459  pop rcx
00007f4e3fdd745a  pop rax
00007f4e3fdd745b  add rsp, 0x08
00007f4e3fdd745f  jmp 0x00007F4E3FDD5C68
00007f4e3fdd7464  call 0x00007F4E3FCE5820
00007f4e3fdd7469  jmp 0x00007F4E3FDD5C75
00007f4e3fdd746e  sub rsp, 0x08
00007f4e3fdd7472  push rax
00007f4e3fdd7473  push rcx
00007f4e3fdd7474  push rdx
00007f4e3fdd7475  push rdi
00007f4e3fdd7476  push rsi
00007f4e3fdd7477  push r8
00007f4e3fdd7479  push r9
00007f4e3fdd747b  push r10
00007f4e3fdd747d  push r11
00007f4e3fdd747f  sub rsp, 0xF0
00007f4e3fdd7486  vmovaps [rsp], xmm0
00007f4e3fdd748b  vmovaps [rsp+0x10], xmm1
00007f4e3fdd7491  vmovaps [rsp+0x20], xmm2
00007f4e3fdd7497  vmovaps [rsp+0x30], xmm3
00007f4e3fdd749d  vmovaps [rsp+0x40], xmm4
00007f4e3fdd74a3  vmovaps [rsp+0x50], xmm5
00007f4e3fdd74a9  vmovaps [rsp+0x60], xmm6
00007f4e3fdd74af  vmovaps [rsp+0x70], xmm7
00007f4e3fdd74b5  vmovaps [rsp+0x80], xmm8
00007f4e3fdd74be  vmovaps [rsp+0x90], xmm9
00007f4e3fdd74c7  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd74d0  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd74d9  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd74e2  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd74eb  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd74f4  sub rsp, 0x30
00007f4e3fdd74f8  movaps [rsp], xmm14
00007f4e3fdd74fd  movaps [rsp+0x10], xmm4
00007f4e3fdd7502  movaps [rsp+0x20], xmm3
00007f4e3fdd7507  lea rdi, [rsp]
00007f4e3fdd750b  mov esi, 0x00
00007f4e3fdd7510  mov rax, 0x5D97141E9530
00007f4e3fdd751a  call rax
00007f4e3fdd751c  movaps xmm14, [rsp]
00007f4e3fdd7521  add rsp, 0x30
00007f4e3fdd7525  vmovaps xmm0, [rsp]
00007f4e3fdd752a  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd7530  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd7536  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd753c  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd7542  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd7548  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd754e  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd7554  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd755d  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd7566  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd756f  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd7578  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd7581  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd758a  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7593  add rsp, 0xF0
00007f4e3fdd759a  pop r11
00007f4e3fdd759c  pop r10
00007f4e3fdd759e  pop r9
00007f4e3fdd75a0  pop r8
00007f4e3fdd75a2  pop rsi
00007f4e3fdd75a3  pop rdi
00007f4e3fdd75a4  pop rdx
00007f4e3fdd75a5  pop rcx
00007f4e3fdd75a6  pop rax
00007f4e3fdd75a7  add rsp, 0x08
00007f4e3fdd75ab  jmp 0x00007F4E3FDD5C8F
00007f4e3fdd75b0  sub rsp, 0x08
00007f4e3fdd75b4  push rax
00007f4e3fdd75b5  push rcx
00007f4e3fdd75b6  push rdx
00007f4e3fdd75b7  push rdi
00007f4e3fdd75b8  push rsi
00007f4e3fdd75b9  push r8
00007f4e3fdd75bb  push r9
00007f4e3fdd75bd  push r10
00007f4e3fdd75bf  push r11
00007f4e3fdd75c1  sub rsp, 0xF0
00007f4e3fdd75c8  vmovaps [rsp], xmm0
00007f4e3fdd75cd  vmovaps [rsp+0x10], xmm1
00007f4e3fdd75d3  vmovaps [rsp+0x20], xmm2
00007f4e3fdd75d9  vmovaps [rsp+0x30], xmm3
00007f4e3fdd75df  vmovaps [rsp+0x40], xmm4
00007f4e3fdd75e5  vmovaps [rsp+0x50], xmm5
00007f4e3fdd75eb  vmovaps [rsp+0x60], xmm7
00007f4e3fdd75f1  vmovaps [rsp+0x70], xmm8
00007f4e3fdd75f7  vmovaps [rsp+0x80], xmm9
00007f4e3fdd7600  vmovaps [rsp+0x90], xmm10
00007f4e3fdd7609  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd7612  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd761b  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd7624  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd762d  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd7636  sub rsp, 0x30
00007f4e3fdd763a  movaps [rsp], xmm6
00007f4e3fdd763e  movaps [rsp+0x10], xmm9
00007f4e3fdd7644  movaps [rsp+0x20], xmm7
00007f4e3fdd7649  lea rdi, [rsp]
00007f4e3fdd764d  mov esi, 0x00
00007f4e3fdd7652  mov rax, 0x5D97141E9530
00007f4e3fdd765c  call rax
00007f4e3fdd765e  movaps xmm6, [rsp]
00007f4e3fdd7662  add rsp, 0x30
00007f4e3fdd7666  vmovaps xmm0, [rsp]
00007f4e3fdd766b  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd7671  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd7677  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd767d  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd7683  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd7689  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd768f  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd7695  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd769e  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd76a7  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd76b0  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd76b9  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd76c2  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd76cb  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd76d4  add rsp, 0xF0
00007f4e3fdd76db  pop r11
00007f4e3fdd76dd  pop r10
00007f4e3fdd76df  pop r9
00007f4e3fdd76e1  pop r8
00007f4e3fdd76e3  pop rsi
00007f4e3fdd76e4  pop rdi
00007f4e3fdd76e5  pop rdx
00007f4e3fdd76e6  pop rcx
00007f4e3fdd76e7  pop rax
00007f4e3fdd76e8  add rsp, 0x08
00007f4e3fdd76ec  jmp 0x00007F4E3FDD5CA7
00007f4e3fdd76f1  sub rsp, 0x08
00007f4e3fdd76f5  push rax
00007f4e3fdd76f6  push rcx
00007f4e3fdd76f7  push rdx
00007f4e3fdd76f8  push rdi
00007f4e3fdd76f9  push rsi
00007f4e3fdd76fa  push r8
00007f4e3fdd76fc  push r9
00007f4e3fdd76fe  push r10
00007f4e3fdd7700  push r11
00007f4e3fdd7702  sub rsp, 0xF0
00007f4e3fdd7709  vmovaps [rsp], xmm0
00007f4e3fdd770e  vmovaps [rsp+0x10], xmm1
00007f4e3fdd7714  vmovaps [rsp+0x20], xmm2
00007f4e3fdd771a  vmovaps [rsp+0x30], xmm3
00007f4e3fdd7720  vmovaps [rsp+0x40], xmm4
00007f4e3fdd7726  vmovaps [rsp+0x50], xmm5
00007f4e3fdd772c  vmovaps [rsp+0x60], xmm6
00007f4e3fdd7732  vmovaps [rsp+0x70], xmm8
00007f4e3fdd7738  vmovaps [rsp+0x80], xmm9
00007f4e3fdd7741  vmovaps [rsp+0x90], xmm10
00007f4e3fdd774a  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd7753  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd775c  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd7765  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd776e  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd7777  sub rsp, 0x30
00007f4e3fdd777b  movaps [rsp], xmm7
00007f4e3fdd777f  movaps [rsp+0x10], xmm4
00007f4e3fdd7784  movaps [rsp+0x20], xmm9
00007f4e3fdd778a  lea rdi, [rsp]
00007f4e3fdd778e  mov esi, 0x00
00007f4e3fdd7793  mov rax, 0x5D97141E9530
00007f4e3fdd779d  call rax
00007f4e3fdd779f  movaps xmm7, [rsp]
00007f4e3fdd77a3  add rsp, 0x30
00007f4e3fdd77a7  vmovaps xmm0, [rsp]
00007f4e3fdd77ac  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd77b2  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd77b8  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd77be  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd77c4  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd77ca  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd77d0  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd77d6  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd77df  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd77e8  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd77f1  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd77fa  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd7803  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd780c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7815  add rsp, 0xF0
00007f4e3fdd781c  pop r11
00007f4e3fdd781e  pop r10
00007f4e3fdd7820  pop r9
00007f4e3fdd7822  pop r8
00007f4e3fdd7824  pop rsi
00007f4e3fdd7825  pop rdi
00007f4e3fdd7826  pop rdx
00007f4e3fdd7827  pop rcx
00007f4e3fdd7828  pop rax
00007f4e3fdd7829  add rsp, 0x08
00007f4e3fdd782d  jmp 0x00007F4E3FDD5CD4
00007f4e3fdd7832  sub rsp, 0x08
00007f4e3fdd7836  push rax
00007f4e3fdd7837  push rcx
00007f4e3fdd7838  push rdx
00007f4e3fdd7839  push rdi
00007f4e3fdd783a  push rsi
00007f4e3fdd783b  push r8
00007f4e3fdd783d  push r9
00007f4e3fdd783f  push r10
00007f4e3fdd7841  push r11
00007f4e3fdd7843  sub rsp, 0xF0
00007f4e3fdd784a  vmovaps [rsp], xmm0
00007f4e3fdd784f  vmovaps [rsp+0x10], xmm1
00007f4e3fdd7855  vmovaps [rsp+0x20], xmm2
00007f4e3fdd785b  vmovaps [rsp+0x30], xmm3
00007f4e3fdd7861  vmovaps [rsp+0x40], xmm5
00007f4e3fdd7867  vmovaps [rsp+0x50], xmm6
00007f4e3fdd786d  vmovaps [rsp+0x60], xmm7
00007f4e3fdd7873  vmovaps [rsp+0x70], xmm8
00007f4e3fdd7879  vmovaps [rsp+0x80], xmm9
00007f4e3fdd7882  vmovaps [rsp+0x90], xmm10
00007f4e3fdd788b  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd7894  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd789d  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd78a6  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd78af  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd78b8  sub rsp, 0x30
00007f4e3fdd78bc  movaps [rsp], xmm4
00007f4e3fdd78c0  movaps [rsp+0x10], xmm15
00007f4e3fdd78c6  movaps [rsp+0x20], xmm9
00007f4e3fdd78cc  lea rdi, [rsp]
00007f4e3fdd78d0  mov esi, 0x00
00007f4e3fdd78d5  mov rax, 0x5D97141E9530
00007f4e3fdd78df  call rax
00007f4e3fdd78e1  movaps xmm4, [rsp]
00007f4e3fdd78e5  add rsp, 0x30
00007f4e3fdd78e9  vmovaps xmm0, [rsp]
00007f4e3fdd78ee  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd78f4  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd78fa  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd7900  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd7906  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd790c  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd7912  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd7918  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7921  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd792a  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd7933  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd793c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd7945  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd794e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7957  add rsp, 0xF0
00007f4e3fdd795e  pop r11
00007f4e3fdd7960  pop r10
00007f4e3fdd7962  pop r9
00007f4e3fdd7964  pop r8
00007f4e3fdd7966  pop rsi
00007f4e3fdd7967  pop rdi
00007f4e3fdd7968  pop rdx
00007f4e3fdd7969  pop rcx
00007f4e3fdd796a  pop rax
00007f4e3fdd796b  add rsp, 0x08
00007f4e3fdd796f  jmp 0x00007F4E3FDD5CF9
00007f4e3fdd7974  call 0x00007F4E3FCE5820
00007f4e3fdd7979  jmp 0x00007F4E3FDD5D06
00007f4e3fdd797e  sub rsp, 0x08
00007f4e3fdd7982  push rax
00007f4e3fdd7983  push rcx
00007f4e3fdd7984  push rdx
00007f4e3fdd7985  push rdi
00007f4e3fdd7986  push rsi
00007f4e3fdd7987  push r8
00007f4e3fdd7989  push r9
00007f4e3fdd798b  push r10
00007f4e3fdd798d  push r11
00007f4e3fdd798f  sub rsp, 0xF0
00007f4e3fdd7996  vmovaps [rsp], xmm0
00007f4e3fdd799b  vmovaps [rsp+0x10], xmm1
00007f4e3fdd79a1  vmovaps [rsp+0x20], xmm2
00007f4e3fdd79a7  vmovaps [rsp+0x30], xmm4
00007f4e3fdd79ad  vmovaps [rsp+0x40], xmm5
00007f4e3fdd79b3  vmovaps [rsp+0x50], xmm6
00007f4e3fdd79b9  vmovaps [rsp+0x60], xmm7
00007f4e3fdd79bf  vmovaps [rsp+0x70], xmm8
00007f4e3fdd79c5  vmovaps [rsp+0x80], xmm9
00007f4e3fdd79ce  vmovaps [rsp+0x90], xmm10
00007f4e3fdd79d7  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd79e0  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd79e9  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd79f2  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd79fb  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd7a04  sub rsp, 0x30
00007f4e3fdd7a08  movaps [rsp], xmm3
00007f4e3fdd7a0c  movaps [rsp+0x10], xmm1
00007f4e3fdd7a11  movaps [rsp+0x20], xmm9
00007f4e3fdd7a17  lea rdi, [rsp]
00007f4e3fdd7a1b  mov esi, 0x00
00007f4e3fdd7a20  mov rax, 0x5D97141E9530
00007f4e3fdd7a2a  call rax
00007f4e3fdd7a2c  movaps xmm3, [rsp]
00007f4e3fdd7a30  add rsp, 0x30
00007f4e3fdd7a34  vmovaps xmm0, [rsp]
00007f4e3fdd7a39  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd7a3f  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd7a45  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd7a4b  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd7a51  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd7a57  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd7a5d  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd7a63  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7a6c  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd7a75  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd7a7e  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd7a87  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd7a90  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd7a99  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7aa2  add rsp, 0xF0
00007f4e3fdd7aa9  pop r11
00007f4e3fdd7aab  pop r10
00007f4e3fdd7aad  pop r9
00007f4e3fdd7aaf  pop r8
00007f4e3fdd7ab1  pop rsi
00007f4e3fdd7ab2  pop rdi
00007f4e3fdd7ab3  pop rdx
00007f4e3fdd7ab4  pop rcx
00007f4e3fdd7ab5  pop rax
00007f4e3fdd7ab6  add rsp, 0x08
00007f4e3fdd7aba  jmp 0x00007F4E3FDD5D43
00007f4e3fdd7abf  sub rsp, 0x08
00007f4e3fdd7ac3  push rax
00007f4e3fdd7ac4  push rcx
00007f4e3fdd7ac5  push rdx
00007f4e3fdd7ac6  push rdi
00007f4e3fdd7ac7  push rsi
00007f4e3fdd7ac8  push r8
00007f4e3fdd7aca  push r9
00007f4e3fdd7acc  push r10
00007f4e3fdd7ace  push r11
00007f4e3fdd7ad0  sub rsp, 0xF0
00007f4e3fdd7ad7  vmovaps [rsp], xmm0
00007f4e3fdd7adc  vmovaps [rsp+0x10], xmm2
00007f4e3fdd7ae2  vmovaps [rsp+0x20], xmm3
00007f4e3fdd7ae8  vmovaps [rsp+0x30], xmm4
00007f4e3fdd7aee  vmovaps [rsp+0x40], xmm5
00007f4e3fdd7af4  vmovaps [rsp+0x50], xmm6
00007f4e3fdd7afa  vmovaps [rsp+0x60], xmm7
00007f4e3fdd7b00  vmovaps [rsp+0x70], xmm8
00007f4e3fdd7b06  vmovaps [rsp+0x80], xmm9
00007f4e3fdd7b0f  vmovaps [rsp+0x90], xmm10
00007f4e3fdd7b18  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd7b21  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd7b2a  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd7b33  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd7b3c  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd7b45  sub rsp, 0x30
00007f4e3fdd7b49  movaps [rsp], xmm1
00007f4e3fdd7b4d  movaps [rsp+0x10], xmm15
00007f4e3fdd7b53  movaps [rsp+0x20], xmm9
00007f4e3fdd7b59  lea rdi, [rsp]
00007f4e3fdd7b5d  mov esi, 0x00
00007f4e3fdd7b62  mov rax, 0x5D97141E9530
00007f4e3fdd7b6c  call rax
00007f4e3fdd7b6e  movaps xmm1, [rsp]
00007f4e3fdd7b72  add rsp, 0x30
00007f4e3fdd7b76  vmovaps xmm0, [rsp]
00007f4e3fdd7b7b  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd7b81  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd7b87  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd7b8d  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd7b93  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd7b99  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd7b9f  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd7ba5  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7bae  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd7bb7  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd7bc0  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd7bc9  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd7bd2  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd7bdb  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7be4  add rsp, 0xF0
00007f4e3fdd7beb  pop r11
00007f4e3fdd7bed  pop r10
00007f4e3fdd7bef  pop r9
00007f4e3fdd7bf1  pop r8
00007f4e3fdd7bf3  pop rsi
00007f4e3fdd7bf4  pop rdi
00007f4e3fdd7bf5  pop rdx
00007f4e3fdd7bf6  pop rcx
00007f4e3fdd7bf7  pop rax
00007f4e3fdd7bf8  add rsp, 0x08
00007f4e3fdd7bfc  jmp 0x00007F4E3FDD5DCB
00007f4e3fdd7c01  call 0x00007F4E3FCE5820
00007f4e3fdd7c06  jmp 0x00007F4E3FDD5DD8
00007f4e3fdd7c0b  sub rsp, 0x08
00007f4e3fdd7c0f  push rax
00007f4e3fdd7c10  push rcx
00007f4e3fdd7c11  push rdx
00007f4e3fdd7c12  push rdi
00007f4e3fdd7c13  push rsi
00007f4e3fdd7c14  push r8
00007f4e3fdd7c16  push r9
00007f4e3fdd7c18  push r10
00007f4e3fdd7c1a  push r11
00007f4e3fdd7c1c  sub rsp, 0xF0
00007f4e3fdd7c23  vmovaps [rsp], xmm0
00007f4e3fdd7c28  vmovaps [rsp+0x10], xmm2
00007f4e3fdd7c2e  vmovaps [rsp+0x20], xmm3
00007f4e3fdd7c34  vmovaps [rsp+0x30], xmm4
00007f4e3fdd7c3a  vmovaps [rsp+0x40], xmm5
00007f4e3fdd7c40  vmovaps [rsp+0x50], xmm6
00007f4e3fdd7c46  vmovaps [rsp+0x60], xmm7
00007f4e3fdd7c4c  vmovaps [rsp+0x70], xmm8
00007f4e3fdd7c52  vmovaps [rsp+0x80], xmm9
00007f4e3fdd7c5b  vmovaps [rsp+0x90], xmm10
00007f4e3fdd7c64  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd7c6d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd7c76  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd7c7f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd7c88  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd7c91  sub rsp, 0x30
00007f4e3fdd7c95  movaps [rsp], xmm1
00007f4e3fdd7c99  movaps [rsp+0x10], xmm5
00007f4e3fdd7c9e  movaps [rsp+0x20], xmm7
00007f4e3fdd7ca3  lea rdi, [rsp]
00007f4e3fdd7ca7  mov esi, 0x00
00007f4e3fdd7cac  mov rax, 0x5D97141E9530
00007f4e3fdd7cb6  call rax
00007f4e3fdd7cb8  movaps xmm1, [rsp]
00007f4e3fdd7cbc  add rsp, 0x30
00007f4e3fdd7cc0  vmovaps xmm0, [rsp]
00007f4e3fdd7cc5  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd7ccb  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd7cd1  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd7cd7  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd7cdd  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd7ce3  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd7ce9  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd7cef  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7cf8  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd7d01  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd7d0a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd7d13  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd7d1c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd7d25  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7d2e  add rsp, 0xF0
00007f4e3fdd7d35  pop r11
00007f4e3fdd7d37  pop r10
00007f4e3fdd7d39  pop r9
00007f4e3fdd7d3b  pop r8
00007f4e3fdd7d3d  pop rsi
00007f4e3fdd7d3e  pop rdi
00007f4e3fdd7d3f  pop rdx
00007f4e3fdd7d40  pop rcx
00007f4e3fdd7d41  pop rax
00007f4e3fdd7d42  add rsp, 0x08
00007f4e3fdd7d46  jmp 0x00007F4E3FDD5E7D
00007f4e3fdd7d4b  sub rsp, 0x08
00007f4e3fdd7d4f  push rax
00007f4e3fdd7d50  push rcx
00007f4e3fdd7d51  push rdx
00007f4e3fdd7d52  push rdi
00007f4e3fdd7d53  push rsi
00007f4e3fdd7d54  push r8
00007f4e3fdd7d56  push r9
00007f4e3fdd7d58  push r10
00007f4e3fdd7d5a  push r11
00007f4e3fdd7d5c  sub rsp, 0xF0
00007f4e3fdd7d63  vmovaps [rsp], xmm0
00007f4e3fdd7d68  vmovaps [rsp+0x10], xmm1
00007f4e3fdd7d6e  vmovaps [rsp+0x20], xmm2
00007f4e3fdd7d74  vmovaps [rsp+0x30], xmm3
00007f4e3fdd7d7a  vmovaps [rsp+0x40], xmm4
00007f4e3fdd7d80  vmovaps [rsp+0x50], xmm5
00007f4e3fdd7d86  vmovaps [rsp+0x60], xmm6
00007f4e3fdd7d8c  vmovaps [rsp+0x70], xmm8
00007f4e3fdd7d92  vmovaps [rsp+0x80], xmm9
00007f4e3fdd7d9b  vmovaps [rsp+0x90], xmm10
00007f4e3fdd7da4  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd7dad  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd7db6  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd7dbf  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd7dc8  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd7dd1  sub rsp, 0x30
00007f4e3fdd7dd5  movaps [rsp], xmm7
00007f4e3fdd7dd9  movaps [rsp+0x10], xmm5
00007f4e3fdd7dde  movaps [rsp+0x20], xmm15
00007f4e3fdd7de4  lea rdi, [rsp]
00007f4e3fdd7de8  mov esi, 0x00
00007f4e3fdd7ded  mov rax, 0x5D97141E9530
00007f4e3fdd7df7  call rax
00007f4e3fdd7df9  movaps xmm7, [rsp]
00007f4e3fdd7dfd  add rsp, 0x30
00007f4e3fdd7e01  vmovaps xmm0, [rsp]
00007f4e3fdd7e06  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd7e0c  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd7e12  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd7e18  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd7e1e  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd7e24  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd7e2a  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd7e30  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd7e39  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd7e42  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd7e4b  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd7e54  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd7e5d  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd7e66  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd7e6f  add rsp, 0xF0
00007f4e3fdd7e76  pop r11
00007f4e3fdd7e78  pop r10
00007f4e3fdd7e7a  pop r9
00007f4e3fdd7e7c  pop r8
00007f4e3fdd7e7e  pop rsi
00007f4e3fdd7e7f  pop rdi
00007f4e3fdd7e80  pop rdx
00007f4e3fdd7e81  pop rcx
00007f4e3fdd7e82  pop rax
00007f4e3fdd7e83  add rsp, 0x08
00007f4e3fdd7e87  jmp 0x00007F4E3FDD5EB3
00007f4e3fdd7e8c  call 0x00007F4E3FCD64F0
00007f4e3fdd7e91  jmp 0x00007F4E3FDD5EC0
00007f4e3fdd7e96  sub rsp, 0x08
00007f4e3fdd7e9a  push rax
00007f4e3fdd7e9b  push rcx
00007f4e3fdd7e9c  push rdx
00007f4e3fdd7e9d  push rdi
00007f4e3fdd7e9e  push rsi
00007f4e3fdd7e9f  push r8
00007f4e3fdd7ea1  push r9
00007f4e3fdd7ea3  push r10
00007f4e3fdd7ea5  push r11
00007f4e3fdd7ea7  sub rsp, 0xF0
00007f4e3fdd7eae  vmovaps [rsp], xmm0
00007f4e3fdd7eb3  vmovaps [rsp+0x10], xmm1
00007f4e3fdd7eb9  vmovaps [rsp+0x20], xmm2
00007f4e3fdd7ebf  vmovaps [rsp+0x30], xmm3
00007f4e3fdd7ec5  vmovaps [rsp+0x40], xmm4
00007f4e3fdd7ecb  vmovaps [rsp+0x50], xmm5
00007f4e3fdd7ed1  vmovaps [rsp+0x60], xmm6
00007f4e3fdd7ed7  vmovaps [rsp+0x70], xmm7
00007f4e3fdd7edd  vmovaps [rsp+0x80], xmm8
00007f4e3fdd7ee6  vmovaps [rsp+0x90], xmm9
00007f4e3fdd7eef  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd7ef8  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd7f01  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd7f0a  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd7f13  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd7f1c  sub rsp, 0x30
00007f4e3fdd7f20  movaps [rsp], xmm15
00007f4e3fdd7f25  movaps [rsp+0x10], xmm5
00007f4e3fdd7f2a  movaps [rsp+0x20], xmm3
00007f4e3fdd7f2f  lea rdi, [rsp]
00007f4e3fdd7f33  mov esi, 0x00
00007f4e3fdd7f38  mov rax, 0x5D97141E9530
00007f4e3fdd7f42  call rax
00007f4e3fdd7f44  movaps xmm15, [rsp]
00007f4e3fdd7f49  add rsp, 0x30
00007f4e3fdd7f4d  vmovaps xmm0, [rsp]
00007f4e3fdd7f52  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd7f58  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd7f5e  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd7f64  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd7f6a  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd7f70  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd7f76  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd7f7c  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd7f85  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd7f8e  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd7f97  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd7fa0  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd7fa9  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd7fb2  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd7fbb  add rsp, 0xF0
00007f4e3fdd7fc2  pop r11
00007f4e3fdd7fc4  pop r10
00007f4e3fdd7fc6  pop r9
00007f4e3fdd7fc8  pop r8
00007f4e3fdd7fca  pop rsi
00007f4e3fdd7fcb  pop rdi
00007f4e3fdd7fcc  pop rdx
00007f4e3fdd7fcd  pop rcx
00007f4e3fdd7fce  pop rax
00007f4e3fdd7fcf  add rsp, 0x08
00007f4e3fdd7fd3  jmp 0x00007F4E3FDD5EE6
00007f4e3fdd7fd8  sub rsp, 0x08
00007f4e3fdd7fdc  push rax
00007f4e3fdd7fdd  push rcx
00007f4e3fdd7fde  push rdx
00007f4e3fdd7fdf  push rdi
00007f4e3fdd7fe0  push rsi
00007f4e3fdd7fe1  push r8
00007f4e3fdd7fe3  push r9
00007f4e3fdd7fe5  push r10
00007f4e3fdd7fe7  push r11
00007f4e3fdd7fe9  sub rsp, 0xF0
00007f4e3fdd7ff0  vmovaps [rsp], xmm0
00007f4e3fdd7ff5  vmovaps [rsp+0x10], xmm2
00007f4e3fdd7ffb  vmovaps [rsp+0x20], xmm3
00007f4e3fdd8001  vmovaps [rsp+0x30], xmm4
00007f4e3fdd8007  vmovaps [rsp+0x40], xmm5
00007f4e3fdd800d  vmovaps [rsp+0x50], xmm6
00007f4e3fdd8013  vmovaps [rsp+0x60], xmm7
00007f4e3fdd8019  vmovaps [rsp+0x70], xmm8
00007f4e3fdd801f  vmovaps [rsp+0x80], xmm9
00007f4e3fdd8028  vmovaps [rsp+0x90], xmm10
00007f4e3fdd8031  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd803a  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd8043  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd804c  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd8055  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd805e  sub rsp, 0x30
00007f4e3fdd8062  movaps [rsp], xmm1
00007f4e3fdd8066  movaps [rsp+0x10], xmm5
00007f4e3fdd806b  movaps [rsp+0x20], xmm4
00007f4e3fdd8070  lea rdi, [rsp]
00007f4e3fdd8074  mov esi, 0x00
00007f4e3fdd8079  mov rax, 0x5D97141E9530
00007f4e3fdd8083  call rax
00007f4e3fdd8085  movaps xmm1, [rsp]
00007f4e3fdd8089  add rsp, 0x30
00007f4e3fdd808d  vmovaps xmm0, [rsp]
00007f4e3fdd8092  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd8098  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd809e  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd80a4  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd80aa  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd80b0  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd80b6  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd80bc  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd80c5  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd80ce  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd80d7  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd80e0  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd80e9  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd80f2  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd80fb  add rsp, 0xF0
00007f4e3fdd8102  pop r11
00007f4e3fdd8104  pop r10
00007f4e3fdd8106  pop r9
00007f4e3fdd8108  pop r8
00007f4e3fdd810a  pop rsi
00007f4e3fdd810b  pop rdi
00007f4e3fdd810c  pop rdx
00007f4e3fdd810d  pop rcx
00007f4e3fdd810e  pop rax
00007f4e3fdd810f  add rsp, 0x08
00007f4e3fdd8113  jmp 0x00007F4E3FDD5F06
00007f4e3fdd8118  sub rsp, 0x08
00007f4e3fdd811c  push rax
00007f4e3fdd811d  push rcx
00007f4e3fdd811e  push rdx
00007f4e3fdd811f  push rdi
00007f4e3fdd8120  push rsi
00007f4e3fdd8121  push r8
00007f4e3fdd8123  push r9
00007f4e3fdd8125  push r10
00007f4e3fdd8127  push r11
00007f4e3fdd8129  sub rsp, 0xF0
00007f4e3fdd8130  vmovaps [rsp], xmm0
00007f4e3fdd8135  vmovaps [rsp+0x10], xmm1
00007f4e3fdd813b  vmovaps [rsp+0x20], xmm2
00007f4e3fdd8141  vmovaps [rsp+0x30], xmm3
00007f4e3fdd8147  vmovaps [rsp+0x40], xmm5
00007f4e3fdd814d  vmovaps [rsp+0x50], xmm6
00007f4e3fdd8153  vmovaps [rsp+0x60], xmm7
00007f4e3fdd8159  vmovaps [rsp+0x70], xmm8
00007f4e3fdd815f  vmovaps [rsp+0x80], xmm9
00007f4e3fdd8168  vmovaps [rsp+0x90], xmm10
00007f4e3fdd8171  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd817a  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd8183  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd818c  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd8195  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd819e  sub rsp, 0x30
00007f4e3fdd81a2  movaps [rsp], xmm4
00007f4e3fdd81a6  movaps [rsp+0x10], xmm3
00007f4e3fdd81ab  movaps [rsp+0x20], xmm5
00007f4e3fdd81b0  lea rdi, [rsp]
00007f4e3fdd81b4  mov esi, 0x00
00007f4e3fdd81b9  mov rax, 0x5D97141E9530
00007f4e3fdd81c3  call rax
00007f4e3fdd81c5  movaps xmm4, [rsp]
00007f4e3fdd81c9  add rsp, 0x30
00007f4e3fdd81cd  vmovaps xmm0, [rsp]
00007f4e3fdd81d2  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd81d8  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd81de  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd81e4  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd81ea  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd81f0  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd81f6  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd81fc  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd8205  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd820e  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd8217  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd8220  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd8229  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd8232  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd823b  add rsp, 0xF0
00007f4e3fdd8242  pop r11
00007f4e3fdd8244  pop r10
00007f4e3fdd8246  pop r9
00007f4e3fdd8248  pop r8
00007f4e3fdd824a  pop rsi
00007f4e3fdd824b  pop rdi
00007f4e3fdd824c  pop rdx
00007f4e3fdd824d  pop rcx
00007f4e3fdd824e  pop rax
00007f4e3fdd824f  add rsp, 0x08
00007f4e3fdd8253  jmp 0x00007F4E3FDD5F54
00007f4e3fdd8258  call 0x00007F4E3FCD64F0
00007f4e3fdd825d  jmp 0x00007F4E3FDD5F61
00007f4e3fdd8262  sub rsp, 0x08
00007f4e3fdd8266  push rax
00007f4e3fdd8267  push rcx
00007f4e3fdd8268  push rdx
00007f4e3fdd8269  push rdi
00007f4e3fdd826a  push rsi
00007f4e3fdd826b  push r8
00007f4e3fdd826d  push r9
00007f4e3fdd826f  push r10
00007f4e3fdd8271  push r11
00007f4e3fdd8273  sub rsp, 0xF0
00007f4e3fdd827a  vmovaps [rsp], xmm0
00007f4e3fdd827f  vmovaps [rsp+0x10], xmm1
00007f4e3fdd8285  vmovaps [rsp+0x20], xmm2
00007f4e3fdd828b  vmovaps [rsp+0x30], xmm3
00007f4e3fdd8291  vmovaps [rsp+0x40], xmm4
00007f4e3fdd8297  vmovaps [rsp+0x50], xmm6
00007f4e3fdd829d  vmovaps [rsp+0x60], xmm7
00007f4e3fdd82a3  vmovaps [rsp+0x70], xmm8
00007f4e3fdd82a9  vmovaps [rsp+0x80], xmm9
00007f4e3fdd82b2  vmovaps [rsp+0x90], xmm10
00007f4e3fdd82bb  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd82c4  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd82cd  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd82d6  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd82df  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd82e8  sub rsp, 0x30
00007f4e3fdd82ec  movaps [rsp], xmm5
00007f4e3fdd82f0  movaps [rsp+0x10], xmm6
00007f4e3fdd82f5  movaps [rsp+0x20], xmm3
00007f4e3fdd82fa  lea rdi, [rsp]
00007f4e3fdd82fe  mov esi, 0x00
00007f4e3fdd8303  mov rax, 0x5D97141E9530
00007f4e3fdd830d  call rax
00007f4e3fdd830f  movaps xmm5, [rsp]
00007f4e3fdd8313  add rsp, 0x30
00007f4e3fdd8317  vmovaps xmm0, [rsp]
00007f4e3fdd831c  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd8322  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd8328  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd832e  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd8334  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd833a  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd8340  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd8346  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd834f  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd8358  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd8361  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd836a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd8373  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd837c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd8385  add rsp, 0xF0
00007f4e3fdd838c  pop r11
00007f4e3fdd838e  pop r10
00007f4e3fdd8390  pop r9
00007f4e3fdd8392  pop r8
00007f4e3fdd8394  pop rsi
00007f4e3fdd8395  pop rdi
00007f4e3fdd8396  pop rdx
00007f4e3fdd8397  pop rcx
00007f4e3fdd8398  pop rax
00007f4e3fdd8399  add rsp, 0x08
00007f4e3fdd839d  jmp 0x00007F4E3FDD5F87
00007f4e3fdd83a2  sub rsp, 0x08
00007f4e3fdd83a6  push rax
00007f4e3fdd83a7  push rcx
00007f4e3fdd83a8  push rdx
00007f4e3fdd83a9  push rdi
00007f4e3fdd83aa  push rsi
00007f4e3fdd83ab  push r8
00007f4e3fdd83ad  push r9
00007f4e3fdd83af  push r10
00007f4e3fdd83b1  push r11
00007f4e3fdd83b3  sub rsp, 0xF0
00007f4e3fdd83ba  vmovaps [rsp], xmm0
00007f4e3fdd83bf  vmovaps [rsp+0x10], xmm1
00007f4e3fdd83c5  vmovaps [rsp+0x20], xmm2
00007f4e3fdd83cb  vmovaps [rsp+0x30], xmm3
00007f4e3fdd83d1  vmovaps [rsp+0x40], xmm4
00007f4e3fdd83d7  vmovaps [rsp+0x50], xmm5
00007f4e3fdd83dd  vmovaps [rsp+0x60], xmm7
00007f4e3fdd83e3  vmovaps [rsp+0x70], xmm8
00007f4e3fdd83e9  vmovaps [rsp+0x80], xmm9
00007f4e3fdd83f2  vmovaps [rsp+0x90], xmm10
00007f4e3fdd83fb  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd8404  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd840d  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd8416  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd841f  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd8428  sub rsp, 0x30
00007f4e3fdd842c  movaps [rsp], xmm6
00007f4e3fdd8430  movaps [rsp+0x10], xmm9
00007f4e3fdd8436  movaps [rsp+0x20], xmm1
00007f4e3fdd843b  lea rdi, [rsp]
00007f4e3fdd843f  mov esi, 0x00
00007f4e3fdd8444  mov rax, 0x5D97141E9530
00007f4e3fdd844e  call rax
00007f4e3fdd8450  movaps xmm6, [rsp]
00007f4e3fdd8454  add rsp, 0x30
00007f4e3fdd8458  vmovaps xmm0, [rsp]
00007f4e3fdd845d  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd8463  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd8469  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd846f  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd8475  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd847b  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd8481  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd8487  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd8490  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd8499  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd84a2  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd84ab  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd84b4  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd84bd  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd84c6  add rsp, 0xF0
00007f4e3fdd84cd  pop r11
00007f4e3fdd84cf  pop r10
00007f4e3fdd84d1  pop r9
00007f4e3fdd84d3  pop r8
00007f4e3fdd84d5  pop rsi
00007f4e3fdd84d6  pop rdi
00007f4e3fdd84d7  pop rdx
00007f4e3fdd84d8  pop rcx
00007f4e3fdd84d9  pop rax
00007f4e3fdd84da  add rsp, 0x08
00007f4e3fdd84de  jmp 0x00007F4E3FDD5FAB
00007f4e3fdd84e3  sub rsp, 0x08
00007f4e3fdd84e7  push rax
00007f4e3fdd84e8  push rcx
00007f4e3fdd84e9  push rdx
00007f4e3fdd84ea  push rdi
00007f4e3fdd84eb  push rsi
00007f4e3fdd84ec  push r8
00007f4e3fdd84ee  push r9
00007f4e3fdd84f0  push r10
00007f4e3fdd84f2  push r11
00007f4e3fdd84f4  sub rsp, 0xF0
00007f4e3fdd84fb  vmovaps [rsp], xmm0
00007f4e3fdd8500  vmovaps [rsp+0x10], xmm1
00007f4e3fdd8506  vmovaps [rsp+0x20], xmm2
00007f4e3fdd850c  vmovaps [rsp+0x30], xmm3
00007f4e3fdd8512  vmovaps [rsp+0x40], xmm4
00007f4e3fdd8518  vmovaps [rsp+0x50], xmm5
00007f4e3fdd851e  vmovaps [rsp+0x60], xmm6
00007f4e3fdd8524  vmovaps [rsp+0x70], xmm7
00007f4e3fdd852a  vmovaps [rsp+0x80], xmm8
00007f4e3fdd8533  vmovaps [rsp+0x90], xmm10
00007f4e3fdd853c  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd8545  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd854e  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd8557  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd8560  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd8569  sub rsp, 0x30
00007f4e3fdd856d  movaps [rsp], xmm9
00007f4e3fdd8572  movaps [rsp+0x10], xmm3
00007f4e3fdd8577  movaps [rsp+0x20], xmm1
00007f4e3fdd857c  lea rdi, [rsp]
00007f4e3fdd8580  mov esi, 0x00
00007f4e3fdd8585  mov rax, 0x5D97141E9530
00007f4e3fdd858f  call rax
00007f4e3fdd8591  movaps xmm9, [rsp]
00007f4e3fdd8596  add rsp, 0x30
00007f4e3fdd859a  vmovaps xmm0, [rsp]
00007f4e3fdd859f  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd85a5  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd85ab  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd85b1  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd85b7  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd85bd  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd85c3  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd85c9  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd85d2  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd85db  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd85e4  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd85ed  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd85f6  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd85ff  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd8608  add rsp, 0xF0
00007f4e3fdd860f  pop r11
00007f4e3fdd8611  pop r10
00007f4e3fdd8613  pop r9
00007f4e3fdd8615  pop r8
00007f4e3fdd8617  pop rsi
00007f4e3fdd8618  pop rdi
00007f4e3fdd8619  pop rdx
00007f4e3fdd861a  pop rcx
00007f4e3fdd861b  pop rax
00007f4e3fdd861c  add rsp, 0x08
00007f4e3fdd8620  jmp 0x00007F4E3FDD5FF7
00007f4e3fdd8625  call 0x00007F4E3FCD64F0
00007f4e3fdd862a  jmp 0x00007F4E3FDD6004
00007f4e3fdd862f  sub rsp, 0x08
00007f4e3fdd8633  push rax
00007f4e3fdd8634  push rcx
00007f4e3fdd8635  push rdx
00007f4e3fdd8636  push rdi
00007f4e3fdd8637  push rsi
00007f4e3fdd8638  push r8
00007f4e3fdd863a  push r9
00007f4e3fdd863c  push r10
00007f4e3fdd863e  push r11
00007f4e3fdd8640  sub rsp, 0xF0
00007f4e3fdd8647  vmovaps [rsp], xmm0
00007f4e3fdd864c  vmovaps [rsp+0x10], xmm1
00007f4e3fdd8652  vmovaps [rsp+0x20], xmm2
00007f4e3fdd8658  vmovaps [rsp+0x30], xmm3
00007f4e3fdd865e  vmovaps [rsp+0x40], xmm4
00007f4e3fdd8664  vmovaps [rsp+0x50], xmm5
00007f4e3fdd866a  vmovaps [rsp+0x60], xmm6
00007f4e3fdd8670  vmovaps [rsp+0x70], xmm7
00007f4e3fdd8676  vmovaps [rsp+0x80], xmm8
00007f4e3fdd867f  vmovaps [rsp+0x90], xmm9
00007f4e3fdd8688  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd8691  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd869a  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd86a3  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd86ac  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd86b5  sub rsp, 0x30
00007f4e3fdd86b9  movaps [rsp], xmm15
00007f4e3fdd86be  movaps [rsp+0x10], xmm3
00007f4e3fdd86c3  movaps [rsp+0x20], xmm7
00007f4e3fdd86c8  lea rdi, [rsp]
00007f4e3fdd86cc  mov esi, 0x00
00007f4e3fdd86d1  mov rax, 0x5D97141E9530
00007f4e3fdd86db  call rax
00007f4e3fdd86dd  movaps xmm15, [rsp]
00007f4e3fdd86e2  add rsp, 0x30
00007f4e3fdd86e6  vmovaps xmm0, [rsp]
00007f4e3fdd86eb  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd86f1  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd86f7  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd86fd  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd8703  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd8709  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd870f  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd8715  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd871e  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd8727  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd8730  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd8739  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd8742  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd874b  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd8754  add rsp, 0xF0
00007f4e3fdd875b  pop r11
00007f4e3fdd875d  pop r10
00007f4e3fdd875f  pop r9
00007f4e3fdd8761  pop r8
00007f4e3fdd8763  pop rsi
00007f4e3fdd8764  pop rdi
00007f4e3fdd8765  pop rdx
00007f4e3fdd8766  pop rcx
00007f4e3fdd8767  pop rax
00007f4e3fdd8768  add rsp, 0x08
00007f4e3fdd876c  jmp 0x00007F4E3FDD6030
00007f4e3fdd8771  sub rsp, 0x08
00007f4e3fdd8775  push rax
00007f4e3fdd8776  push rcx
00007f4e3fdd8777  push rdx
00007f4e3fdd8778  push rdi
00007f4e3fdd8779  push rsi
00007f4e3fdd877a  push r8
00007f4e3fdd877c  push r9
00007f4e3fdd877e  push r10
00007f4e3fdd8780  push r11
00007f4e3fdd8782  sub rsp, 0xF0
00007f4e3fdd8789  vmovaps [rsp], xmm0
00007f4e3fdd878e  vmovaps [rsp+0x10], xmm1
00007f4e3fdd8794  vmovaps [rsp+0x20], xmm2
00007f4e3fdd879a  vmovaps [rsp+0x30], xmm4
00007f4e3fdd87a0  vmovaps [rsp+0x40], xmm5
00007f4e3fdd87a6  vmovaps [rsp+0x50], xmm6
00007f4e3fdd87ac  vmovaps [rsp+0x60], xmm7
00007f4e3fdd87b2  vmovaps [rsp+0x70], xmm8
00007f4e3fdd87b8  vmovaps [rsp+0x80], xmm9
00007f4e3fdd87c1  vmovaps [rsp+0x90], xmm10
00007f4e3fdd87ca  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd87d3  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd87dc  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd87e5  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd87ee  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd87f7  sub rsp, 0x30
00007f4e3fdd87fb  movaps [rsp], xmm3
00007f4e3fdd87ff  movaps [rsp+0x10], xmm1
00007f4e3fdd8804  movaps [rsp+0x20], xmm15
00007f4e3fdd880a  lea rdi, [rsp]
00007f4e3fdd880e  mov esi, 0x00
00007f4e3fdd8813  mov rax, 0x5D97141E9530
00007f4e3fdd881d  call rax
00007f4e3fdd881f  movaps xmm3, [rsp]
00007f4e3fdd8823  add rsp, 0x30
00007f4e3fdd8827  vmovaps xmm0, [rsp]
00007f4e3fdd882c  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd8832  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd8838  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd883e  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd8844  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd884a  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd8850  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd8856  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd885f  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd8868  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd8871  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd887a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd8883  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd888c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd8895  add rsp, 0xF0
00007f4e3fdd889c  pop r11
00007f4e3fdd889e  pop r10
00007f4e3fdd88a0  pop r9
00007f4e3fdd88a2  pop r8
00007f4e3fdd88a4  pop rsi
00007f4e3fdd88a5  pop rdi
00007f4e3fdd88a6  pop rdx
00007f4e3fdd88a7  pop rcx
00007f4e3fdd88a8  pop rax
00007f4e3fdd88a9  add rsp, 0x08
00007f4e3fdd88ad  jmp 0x00007F4E3FDD60BF
00007f4e3fdd88b2  call 0x00007F4E3FCD64F0
00007f4e3fdd88b7  jmp 0x00007F4E3FDD60C9
00007f4e3fdd88bc  sub rsp, 0x08
00007f4e3fdd88c0  push rax
00007f4e3fdd88c1  push rcx
00007f4e3fdd88c2  push rdx
00007f4e3fdd88c3  push rdi
00007f4e3fdd88c4  push rsi
00007f4e3fdd88c5  push r8
00007f4e3fdd88c7  push r9
00007f4e3fdd88c9  push r10
00007f4e3fdd88cb  push r11
00007f4e3fdd88cd  sub rsp, 0xF0
00007f4e3fdd88d4  vmovaps [rsp], xmm0
00007f4e3fdd88d9  vmovaps [rsp+0x10], xmm1
00007f4e3fdd88df  vmovaps [rsp+0x20], xmm2
00007f4e3fdd88e5  vmovaps [rsp+0x30], xmm3
00007f4e3fdd88eb  vmovaps [rsp+0x40], xmm4
00007f4e3fdd88f1  vmovaps [rsp+0x50], xmm5
00007f4e3fdd88f7  vmovaps [rsp+0x60], xmm6
00007f4e3fdd88fd  vmovaps [rsp+0x70], xmm7
00007f4e3fdd8903  vmovaps [rsp+0x80], xmm8
00007f4e3fdd890c  vmovaps [rsp+0x90], xmm9
00007f4e3fdd8915  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd891e  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd8927  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd8930  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd8939  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd8942  sub rsp, 0x30
00007f4e3fdd8946  movaps [rsp], xmm15
00007f4e3fdd894b  movaps [rsp+0x10], xmm14
00007f4e3fdd8951  movaps [rsp+0x20], xmm4
00007f4e3fdd8956  lea rdi, [rsp]
00007f4e3fdd895a  mov esi, 0x00
00007f4e3fdd895f  mov rax, 0x5D97141E9530
00007f4e3fdd8969  call rax
00007f4e3fdd896b  movaps xmm15, [rsp]
00007f4e3fdd8970  add rsp, 0x30
00007f4e3fdd8974  vmovaps xmm0, [rsp]
00007f4e3fdd8979  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd897f  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd8985  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd898b  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd8991  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd8997  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd899d  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd89a3  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd89ac  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd89b5  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd89be  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd89c7  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd89d0  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd89d9  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd89e2  add rsp, 0xF0
00007f4e3fdd89e9  pop r11
00007f4e3fdd89eb  pop r10
00007f4e3fdd89ed  pop r9
00007f4e3fdd89ef  pop r8
00007f4e3fdd89f1  pop rsi
00007f4e3fdd89f2  pop rdi
00007f4e3fdd89f3  pop rdx
00007f4e3fdd89f4  pop rcx
00007f4e3fdd89f5  pop rax
00007f4e3fdd89f6  add rsp, 0x08
00007f4e3fdd89fa  jmp 0x00007F4E3FDD60F7
00007f4e3fdd89ff  sub rsp, 0x08
00007f4e3fdd8a03  push rax
00007f4e3fdd8a04  push rcx
00007f4e3fdd8a05  push rdx
00007f4e3fdd8a06  push rdi
00007f4e3fdd8a07  push rsi
00007f4e3fdd8a08  push r8
00007f4e3fdd8a0a  push r9
00007f4e3fdd8a0c  push r10
00007f4e3fdd8a0e  push r11
00007f4e3fdd8a10  sub rsp, 0xF0
00007f4e3fdd8a17  vmovaps [rsp], xmm0
00007f4e3fdd8a1c  vmovaps [rsp+0x10], xmm1
00007f4e3fdd8a22  vmovaps [rsp+0x20], xmm2
00007f4e3fdd8a28  vmovaps [rsp+0x30], xmm3
00007f4e3fdd8a2e  vmovaps [rsp+0x40], xmm4
00007f4e3fdd8a34  vmovaps [rsp+0x50], xmm5
00007f4e3fdd8a3a  vmovaps [rsp+0x60], xmm6
00007f4e3fdd8a40  vmovaps [rsp+0x70], xmm7
00007f4e3fdd8a46  vmovaps [rsp+0x80], xmm8
00007f4e3fdd8a4f  vmovaps [rsp+0x90], xmm9
00007f4e3fdd8a58  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd8a61  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd8a6a  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd8a73  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd8a7c  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd8a85  sub rsp, 0x30
00007f4e3fdd8a89  movaps [rsp], xmm14
00007f4e3fdd8a8e  movaps [rsp+0x10], xmm2
00007f4e3fdd8a93  movaps [rsp+0x20], xmm1
00007f4e3fdd8a98  lea rdi, [rsp]
00007f4e3fdd8a9c  mov esi, 0x00
00007f4e3fdd8aa1  mov rax, 0x5D97141E9530
00007f4e3fdd8aab  call rax
00007f4e3fdd8aad  movaps xmm14, [rsp]
00007f4e3fdd8ab2  add rsp, 0x30
00007f4e3fdd8ab6  vmovaps xmm0, [rsp]
00007f4e3fdd8abb  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd8ac1  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd8ac7  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd8acd  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd8ad3  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd8ad9  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd8adf  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd8ae5  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd8aee  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd8af7  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd8b00  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd8b09  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd8b12  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd8b1b  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd8b24  add rsp, 0xF0
00007f4e3fdd8b2b  pop r11
00007f4e3fdd8b2d  pop r10
00007f4e3fdd8b2f  pop r9
00007f4e3fdd8b31  pop r8
00007f4e3fdd8b33  pop rsi
00007f4e3fdd8b34  pop rdi
00007f4e3fdd8b35  pop rdx
00007f4e3fdd8b36  pop rcx
00007f4e3fdd8b37  pop rax
00007f4e3fdd8b38  add rsp, 0x08
00007f4e3fdd8b3c  jmp 0x00007F4E3FDD611D
00007f4e3fdd8b41  sub rsp, 0x08
00007f4e3fdd8b45  push rax
00007f4e3fdd8b46  push rcx
00007f4e3fdd8b47  push rdx
00007f4e3fdd8b48  push rdi
00007f4e3fdd8b49  push rsi
00007f4e3fdd8b4a  push r8
00007f4e3fdd8b4c  push r9
00007f4e3fdd8b4e  push r10
00007f4e3fdd8b50  push r11
00007f4e3fdd8b52  sub rsp, 0xF0
00007f4e3fdd8b59  vmovaps [rsp], xmm0
00007f4e3fdd8b5e  vmovaps [rsp+0x10], xmm2
00007f4e3fdd8b64  vmovaps [rsp+0x20], xmm3
00007f4e3fdd8b6a  vmovaps [rsp+0x30], xmm4
00007f4e3fdd8b70  vmovaps [rsp+0x40], xmm5
00007f4e3fdd8b76  vmovaps [rsp+0x50], xmm6
00007f4e3fdd8b7c  vmovaps [rsp+0x60], xmm7
00007f4e3fdd8b82  vmovaps [rsp+0x70], xmm8
00007f4e3fdd8b88  vmovaps [rsp+0x80], xmm9
00007f4e3fdd8b91  vmovaps [rsp+0x90], xmm10
00007f4e3fdd8b9a  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd8ba3  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd8bac  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd8bb5  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd8bbe  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd8bc7  sub rsp, 0x30
00007f4e3fdd8bcb  movaps [rsp], xmm1
00007f4e3fdd8bcf  movaps [rsp+0x10], xmm4
00007f4e3fdd8bd4  movaps [rsp+0x20], xmm9
00007f4e3fdd8bda  lea rdi, [rsp]
00007f4e3fdd8bde  mov esi, 0x00
00007f4e3fdd8be3  mov rax, 0x5D97141E9530
00007f4e3fdd8bed  call rax
00007f4e3fdd8bef  movaps xmm1, [rsp]
00007f4e3fdd8bf3  add rsp, 0x30
00007f4e3fdd8bf7  vmovaps xmm0, [rsp]
00007f4e3fdd8bfc  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd8c02  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd8c08  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd8c0e  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd8c14  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd8c1a  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd8c20  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd8c26  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd8c2f  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd8c38  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd8c41  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd8c4a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd8c53  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd8c5c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd8c65  add rsp, 0xF0
00007f4e3fdd8c6c  pop r11
00007f4e3fdd8c6e  pop r10
00007f4e3fdd8c70  pop r9
00007f4e3fdd8c72  pop r8
00007f4e3fdd8c74  pop rsi
00007f4e3fdd8c75  pop rdi
00007f4e3fdd8c76  pop rdx
00007f4e3fdd8c77  pop rcx
00007f4e3fdd8c78  pop rax
00007f4e3fdd8c79  add rsp, 0x08
00007f4e3fdd8c7d  jmp 0x00007F4E3FDD613B
00007f4e3fdd8c82  sub rsp, 0x08
00007f4e3fdd8c86  push rax
00007f4e3fdd8c87  push rcx
00007f4e3fdd8c88  push rdx
00007f4e3fdd8c89  push rdi
00007f4e3fdd8c8a  push rsi
00007f4e3fdd8c8b  push r8
00007f4e3fdd8c8d  push r9
00007f4e3fdd8c8f  push r10
00007f4e3fdd8c91  push r11
00007f4e3fdd8c93  sub rsp, 0xF0
00007f4e3fdd8c9a  vmovaps [rsp], xmm0
00007f4e3fdd8c9f  vmovaps [rsp+0x10], xmm1
00007f4e3fdd8ca5  vmovaps [rsp+0x20], xmm2
00007f4e3fdd8cab  vmovaps [rsp+0x30], xmm3
00007f4e3fdd8cb1  vmovaps [rsp+0x40], xmm5
00007f4e3fdd8cb7  vmovaps [rsp+0x50], xmm6
00007f4e3fdd8cbd  vmovaps [rsp+0x60], xmm7
00007f4e3fdd8cc3  vmovaps [rsp+0x70], xmm8
00007f4e3fdd8cc9  vmovaps [rsp+0x80], xmm9
00007f4e3fdd8cd2  vmovaps [rsp+0x90], xmm10
00007f4e3fdd8cdb  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd8ce4  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd8ced  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd8cf6  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd8cff  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd8d08  sub rsp, 0x30
00007f4e3fdd8d0c  movaps [rsp], xmm4
00007f4e3fdd8d10  movaps [rsp+0x10], xmm2
00007f4e3fdd8d15  movaps [rsp+0x20], xmm9
00007f4e3fdd8d1b  lea rdi, [rsp]
00007f4e3fdd8d1f  mov esi, 0x00
00007f4e3fdd8d24  mov rax, 0x5D97141E9530
00007f4e3fdd8d2e  call rax
00007f4e3fdd8d30  movaps xmm4, [rsp]
00007f4e3fdd8d34  add rsp, 0x30
00007f4e3fdd8d38  vmovaps xmm0, [rsp]
00007f4e3fdd8d3d  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd8d43  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd8d49  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd8d4f  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd8d55  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd8d5b  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd8d61  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd8d67  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd8d70  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd8d79  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd8d82  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd8d8b  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd8d94  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd8d9d  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd8da6  add rsp, 0xF0
00007f4e3fdd8dad  pop r11
00007f4e3fdd8daf  pop r10
00007f4e3fdd8db1  pop r9
00007f4e3fdd8db3  pop r8
00007f4e3fdd8db5  pop rsi
00007f4e3fdd8db6  pop rdi
00007f4e3fdd8db7  pop rdx
00007f4e3fdd8db8  pop rcx
00007f4e3fdd8db9  pop rax
00007f4e3fdd8dba  add rsp, 0x08
00007f4e3fdd8dbe  jmp 0x00007F4E3FDD616B
00007f4e3fdd8dc3  sub rsp, 0x08
00007f4e3fdd8dc7  push rax
00007f4e3fdd8dc8  push rcx
00007f4e3fdd8dc9  push rdx
00007f4e3fdd8dca  push rdi
00007f4e3fdd8dcb  push rsi
00007f4e3fdd8dcc  push r8
00007f4e3fdd8dce  push r9
00007f4e3fdd8dd0  push r10
00007f4e3fdd8dd2  push r11
00007f4e3fdd8dd4  sub rsp, 0xF0
00007f4e3fdd8ddb  vmovaps [rsp], xmm0
00007f4e3fdd8de0  vmovaps [rsp+0x10], xmm1
00007f4e3fdd8de6  vmovaps [rsp+0x20], xmm2
00007f4e3fdd8dec  vmovaps [rsp+0x30], xmm3
00007f4e3fdd8df2  vmovaps [rsp+0x40], xmm4
00007f4e3fdd8df8  vmovaps [rsp+0x50], xmm5
00007f4e3fdd8dfe  vmovaps [rsp+0x60], xmm6
00007f4e3fdd8e04  vmovaps [rsp+0x70], xmm7
00007f4e3fdd8e0a  vmovaps [rsp+0x80], xmm8
00007f4e3fdd8e13  vmovaps [rsp+0x90], xmm10
00007f4e3fdd8e1c  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd8e25  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd8e2e  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd8e37  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd8e40  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd8e49  sub rsp, 0x30
00007f4e3fdd8e4d  movaps [rsp], xmm9
00007f4e3fdd8e52  movaps [rsp+0x10], xmm2
00007f4e3fdd8e57  movaps [rsp+0x20], xmm1
00007f4e3fdd8e5c  lea rdi, [rsp]
00007f4e3fdd8e60  mov esi, 0x00
00007f4e3fdd8e65  mov rax, 0x5D97141E9530
00007f4e3fdd8e6f  call rax
00007f4e3fdd8e71  movaps xmm9, [rsp]
00007f4e3fdd8e76  add rsp, 0x30
00007f4e3fdd8e7a  vmovaps xmm0, [rsp]
00007f4e3fdd8e7f  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd8e85  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd8e8b  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd8e91  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd8e97  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd8e9d  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd8ea3  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd8ea9  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd8eb2  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd8ebb  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd8ec4  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd8ecd  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd8ed6  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd8edf  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd8ee8  add rsp, 0xF0
00007f4e3fdd8eef  pop r11
00007f4e3fdd8ef1  pop r10
00007f4e3fdd8ef3  pop r9
00007f4e3fdd8ef5  pop r8
00007f4e3fdd8ef7  pop rsi
00007f4e3fdd8ef8  pop rdi
00007f4e3fdd8ef9  pop rdx
00007f4e3fdd8efa  pop rcx
00007f4e3fdd8efb  pop rax
00007f4e3fdd8efc  add rsp, 0x08
00007f4e3fdd8f00  jmp 0x00007F4E3FDD61A1
00007f4e3fdd8f05  sub rsp, 0x08
00007f4e3fdd8f09  push rax
00007f4e3fdd8f0a  push rcx
00007f4e3fdd8f0b  push rdx
00007f4e3fdd8f0c  push rdi
00007f4e3fdd8f0d  push rsi
00007f4e3fdd8f0e  push r8
00007f4e3fdd8f10  push r9
00007f4e3fdd8f12  push r10
00007f4e3fdd8f14  push r11
00007f4e3fdd8f16  sub rsp, 0xF0
00007f4e3fdd8f1d  vmovaps [rsp], xmm0
00007f4e3fdd8f22  vmovaps [rsp+0x10], xmm2
00007f4e3fdd8f28  vmovaps [rsp+0x20], xmm3
00007f4e3fdd8f2e  vmovaps [rsp+0x30], xmm4
00007f4e3fdd8f34  vmovaps [rsp+0x40], xmm5
00007f4e3fdd8f3a  vmovaps [rsp+0x50], xmm6
00007f4e3fdd8f40  vmovaps [rsp+0x60], xmm7
00007f4e3fdd8f46  vmovaps [rsp+0x70], xmm8
00007f4e3fdd8f4c  vmovaps [rsp+0x80], xmm9
00007f4e3fdd8f55  vmovaps [rsp+0x90], xmm10
00007f4e3fdd8f5e  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd8f67  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd8f70  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd8f79  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd8f82  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd8f8b  sub rsp, 0x30
00007f4e3fdd8f8f  movaps [rsp], xmm1
00007f4e3fdd8f93  movaps [rsp+0x10], xmm15
00007f4e3fdd8f99  movaps [rsp+0x20], xmm6
00007f4e3fdd8f9e  lea rdi, [rsp]
00007f4e3fdd8fa2  mov esi, 0x00
00007f4e3fdd8fa7  mov rax, 0x5D97141E9530
00007f4e3fdd8fb1  call rax
00007f4e3fdd8fb3  movaps xmm1, [rsp]
00007f4e3fdd8fb7  add rsp, 0x30
00007f4e3fdd8fbb  vmovaps xmm0, [rsp]
00007f4e3fdd8fc0  vmovaps xmm2, [rsp+0x10]
00007f4e3fdd8fc6  vmovaps xmm3, [rsp+0x20]
00007f4e3fdd8fcc  vmovaps xmm4, [rsp+0x30]
00007f4e3fdd8fd2  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd8fd8  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd8fde  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd8fe4  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd8fea  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd8ff3  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd8ffc  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd9005  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd900e  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd9017  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd9020  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd9029  add rsp, 0xF0
00007f4e3fdd9030  pop r11
00007f4e3fdd9032  pop r10
00007f4e3fdd9034  pop r9
00007f4e3fdd9036  pop r8
00007f4e3fdd9038  pop rsi
00007f4e3fdd9039  pop rdi
00007f4e3fdd903a  pop rdx
00007f4e3fdd903b  pop rcx
00007f4e3fdd903c  pop rax
00007f4e3fdd903d  add rsp, 0x08
00007f4e3fdd9041  jmp 0x00007F4E3FDD61C2
00007f4e3fdd9046  sub rsp, 0x08
00007f4e3fdd904a  push rax
00007f4e3fdd904b  push rcx
00007f4e3fdd904c  push rdx
00007f4e3fdd904d  push rdi
00007f4e3fdd904e  push rsi
00007f4e3fdd904f  push r8
00007f4e3fdd9051  push r9
00007f4e3fdd9053  push r10
00007f4e3fdd9055  push r11
00007f4e3fdd9057  sub rsp, 0xF0
00007f4e3fdd905e  vmovaps [rsp], xmm0
00007f4e3fdd9063  vmovaps [rsp+0x10], xmm1
00007f4e3fdd9069  vmovaps [rsp+0x20], xmm2
00007f4e3fdd906f  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9075  vmovaps [rsp+0x40], xmm4
00007f4e3fdd907b  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9081  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9087  vmovaps [rsp+0x70], xmm7
00007f4e3fdd908d  vmovaps [rsp+0x80], xmm8
00007f4e3fdd9096  vmovaps [rsp+0x90], xmm9
00007f4e3fdd909f  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd90a8  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd90b1  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd90ba  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd90c3  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd90cc  sub rsp, 0x30
00007f4e3fdd90d0  movaps [rsp], xmm15
00007f4e3fdd90d5  movaps [rsp+0x10], xmm5
00007f4e3fdd90da  movaps [rsp+0x20], xmm3
00007f4e3fdd90df  lea rdi, [rsp]
00007f4e3fdd90e3  mov esi, 0x00
00007f4e3fdd90e8  mov rax, 0x5D97141E9530
00007f4e3fdd90f2  call rax
00007f4e3fdd90f4  movaps xmm15, [rsp]
00007f4e3fdd90f9  add rsp, 0x30
00007f4e3fdd90fd  vmovaps xmm0, [rsp]
00007f4e3fdd9102  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9108  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd910e  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9114  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd911a  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd9120  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd9126  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd912c  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd9135  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd913e  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd9147  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd9150  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd9159  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd9162  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd916b  add rsp, 0xF0
00007f4e3fdd9172  pop r11
00007f4e3fdd9174  pop r10
00007f4e3fdd9176  pop r9
00007f4e3fdd9178  pop r8
00007f4e3fdd917a  pop rsi
00007f4e3fdd917b  pop rdi
00007f4e3fdd917c  pop rdx
00007f4e3fdd917d  pop rcx
00007f4e3fdd917e  pop rax
00007f4e3fdd917f  add rsp, 0x08
00007f4e3fdd9183  jmp 0x00007F4E3FDD61DC
00007f4e3fdd9188  sub rsp, 0x08
00007f4e3fdd918c  push rax
00007f4e3fdd918d  push rcx
00007f4e3fdd918e  push rdx
00007f4e3fdd918f  push rdi
00007f4e3fdd9190  push rsi
00007f4e3fdd9191  push r8
00007f4e3fdd9193  push r9
00007f4e3fdd9195  push r10
00007f4e3fdd9197  push r11
00007f4e3fdd9199  sub rsp, 0xF0
00007f4e3fdd91a0  vmovaps [rsp], xmm0
00007f4e3fdd91a5  vmovaps [rsp+0x10], xmm1
00007f4e3fdd91ab  vmovaps [rsp+0x20], xmm2
00007f4e3fdd91b1  vmovaps [rsp+0x30], xmm3
00007f4e3fdd91b7  vmovaps [rsp+0x40], xmm4
00007f4e3fdd91bd  vmovaps [rsp+0x50], xmm6
00007f4e3fdd91c3  vmovaps [rsp+0x60], xmm7
00007f4e3fdd91c9  vmovaps [rsp+0x70], xmm8
00007f4e3fdd91cf  vmovaps [rsp+0x80], xmm9
00007f4e3fdd91d8  vmovaps [rsp+0x90], xmm10
00007f4e3fdd91e1  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd91ea  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd91f3  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd91fc  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9205  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd920e  sub rsp, 0x30
00007f4e3fdd9212  movaps [rsp], xmm5
00007f4e3fdd9216  movaps [rsp+0x10], xmm8
00007f4e3fdd921c  movaps [rsp+0x20], xmm6
00007f4e3fdd9221  lea rdi, [rsp]
00007f4e3fdd9225  mov esi, 0x00
00007f4e3fdd922a  mov rax, 0x5D97141E9530
00007f4e3fdd9234  call rax
00007f4e3fdd9236  movaps xmm5, [rsp]
00007f4e3fdd923a  add rsp, 0x30
00007f4e3fdd923e  vmovaps xmm0, [rsp]
00007f4e3fdd9243  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9249  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd924f  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9255  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd925b  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd9261  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd9267  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd926d  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd9276  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd927f  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd9288  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd9291  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd929a  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd92a3  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd92ac  add rsp, 0xF0
00007f4e3fdd92b3  pop r11
00007f4e3fdd92b5  pop r10
00007f4e3fdd92b7  pop r9
00007f4e3fdd92b9  pop r8
00007f4e3fdd92bb  pop rsi
00007f4e3fdd92bc  pop rdi
00007f4e3fdd92bd  pop rdx
00007f4e3fdd92be  pop rcx
00007f4e3fdd92bf  pop rax
00007f4e3fdd92c0  add rsp, 0x08
00007f4e3fdd92c4  jmp 0x00007F4E3FDD6200
00007f4e3fdd92c9  sub rsp, 0x08
00007f4e3fdd92cd  push rax
00007f4e3fdd92ce  push rcx
00007f4e3fdd92cf  push rdx
00007f4e3fdd92d0  push rdi
00007f4e3fdd92d1  push rsi
00007f4e3fdd92d2  push r8
00007f4e3fdd92d4  push r9
00007f4e3fdd92d6  push r10
00007f4e3fdd92d8  push r11
00007f4e3fdd92da  sub rsp, 0xF0
00007f4e3fdd92e1  vmovaps [rsp], xmm0
00007f4e3fdd92e6  vmovaps [rsp+0x10], xmm1
00007f4e3fdd92ec  vmovaps [rsp+0x20], xmm2
00007f4e3fdd92f2  vmovaps [rsp+0x30], xmm3
00007f4e3fdd92f8  vmovaps [rsp+0x40], xmm4
00007f4e3fdd92fe  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9304  vmovaps [rsp+0x60], xmm7
00007f4e3fdd930a  vmovaps [rsp+0x70], xmm8
00007f4e3fdd9310  vmovaps [rsp+0x80], xmm9
00007f4e3fdd9319  vmovaps [rsp+0x90], xmm10
00007f4e3fdd9322  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd932b  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd9334  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd933d  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9346  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd934f  sub rsp, 0x30
00007f4e3fdd9353  movaps [rsp], xmm6
00007f4e3fdd9357  movaps [rsp+0x10], xmm10
00007f4e3fdd935d  movaps [rsp+0x20], xmm8
00007f4e3fdd9363  lea rdi, [rsp]
00007f4e3fdd9367  mov esi, 0x00
00007f4e3fdd936c  mov rax, 0x5D97141E9530
00007f4e3fdd9376  call rax
00007f4e3fdd9378  movaps xmm6, [rsp]
00007f4e3fdd937c  add rsp, 0x30
00007f4e3fdd9380  vmovaps xmm0, [rsp]
00007f4e3fdd9385  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd938b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd9391  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9397  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd939d  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd93a3  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd93a9  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd93af  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd93b8  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd93c1  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd93ca  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd93d3  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd93dc  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd93e5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd93ee  add rsp, 0xF0
00007f4e3fdd93f5  pop r11
00007f4e3fdd93f7  pop r10
00007f4e3fdd93f9  pop r9
00007f4e3fdd93fb  pop r8
00007f4e3fdd93fd  pop rsi
00007f4e3fdd93fe  pop rdi
00007f4e3fdd93ff  pop rdx
00007f4e3fdd9400  pop rcx
00007f4e3fdd9401  pop rax
00007f4e3fdd9402  add rsp, 0x08
00007f4e3fdd9406  jmp 0x00007F4E3FDD6225
00007f4e3fdd940b  sub rsp, 0x08
00007f4e3fdd940f  push rax
00007f4e3fdd9410  push rcx
00007f4e3fdd9411  push rdx
00007f4e3fdd9412  push rdi
00007f4e3fdd9413  push rsi
00007f4e3fdd9414  push r8
00007f4e3fdd9416  push r9
00007f4e3fdd9418  push r10
00007f4e3fdd941a  push r11
00007f4e3fdd941c  sub rsp, 0xF0
00007f4e3fdd9423  vmovaps [rsp], xmm0
00007f4e3fdd9428  vmovaps [rsp+0x10], xmm1
00007f4e3fdd942e  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9434  vmovaps [rsp+0x30], xmm3
00007f4e3fdd943a  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9440  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9446  vmovaps [rsp+0x60], xmm6
00007f4e3fdd944c  vmovaps [rsp+0x70], xmm7
00007f4e3fdd9452  vmovaps [rsp+0x80], xmm8
00007f4e3fdd945b  vmovaps [rsp+0x90], xmm9
00007f4e3fdd9464  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd946d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd9476  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd947f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9488  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd9491  sub rsp, 0x30
00007f4e3fdd9495  movaps [rsp], xmm10
00007f4e3fdd949a  movaps [rsp+0x10], xmm8
00007f4e3fdd94a0  movaps [rsp+0x20], xmm14
00007f4e3fdd94a6  lea rdi, [rsp]
00007f4e3fdd94aa  mov esi, 0x00
00007f4e3fdd94af  mov rax, 0x5D97141E9530
00007f4e3fdd94b9  call rax
00007f4e3fdd94bb  movaps xmm10, [rsp]
00007f4e3fdd94c0  add rsp, 0x30
00007f4e3fdd94c4  vmovaps xmm0, [rsp]
00007f4e3fdd94c9  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd94cf  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd94d5  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd94db  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd94e1  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd94e7  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd94ed  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd94f3  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd94fc  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd9505  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd950e  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd9517  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd9520  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd9529  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd9532  add rsp, 0xF0
00007f4e3fdd9539  pop r11
00007f4e3fdd953b  pop r10
00007f4e3fdd953d  pop r9
00007f4e3fdd953f  pop r8
00007f4e3fdd9541  pop rsi
00007f4e3fdd9542  pop rdi
00007f4e3fdd9543  pop rdx
00007f4e3fdd9544  pop rcx
00007f4e3fdd9545  pop rax
00007f4e3fdd9546  add rsp, 0x08
00007f4e3fdd954a  jmp 0x00007F4E3FDD6245
00007f4e3fdd954f  sub rsp, 0x08
00007f4e3fdd9553  push rax
00007f4e3fdd9554  push rcx
00007f4e3fdd9555  push rdx
00007f4e3fdd9556  push rdi
00007f4e3fdd9557  push rsi
00007f4e3fdd9558  push r8
00007f4e3fdd955a  push r9
00007f4e3fdd955c  push r10
00007f4e3fdd955e  push r11
00007f4e3fdd9560  sub rsp, 0xF0
00007f4e3fdd9567  vmovaps [rsp], xmm0
00007f4e3fdd956c  vmovaps [rsp+0x10], xmm1
00007f4e3fdd9572  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9578  vmovaps [rsp+0x30], xmm3
00007f4e3fdd957e  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9584  vmovaps [rsp+0x50], xmm5
00007f4e3fdd958a  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9590  vmovaps [rsp+0x70], xmm7
00007f4e3fdd9596  vmovaps [rsp+0x80], xmm8
00007f4e3fdd959f  vmovaps [rsp+0x90], xmm9
00007f4e3fdd95a8  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd95b1  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd95ba  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd95c3  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd95cc  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd95d5  sub rsp, 0x30
00007f4e3fdd95d9  movaps [rsp], xmm14
00007f4e3fdd95de  movaps [rsp+0x10], xmm8
00007f4e3fdd95e4  movaps [rsp+0x20], xmm4
00007f4e3fdd95e9  lea rdi, [rsp]
00007f4e3fdd95ed  mov esi, 0x00
00007f4e3fdd95f2  mov rax, 0x5D97141E9530
00007f4e3fdd95fc  call rax
00007f4e3fdd95fe  movaps xmm14, [rsp]
00007f4e3fdd9603  add rsp, 0x30
00007f4e3fdd9607  vmovaps xmm0, [rsp]
00007f4e3fdd960c  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9612  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd9618  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd961e  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd9624  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd962a  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd9630  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd9636  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd963f  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd9648  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd9651  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd965a  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd9663  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd966c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd9675  add rsp, 0xF0
00007f4e3fdd967c  pop r11
00007f4e3fdd967e  pop r10
00007f4e3fdd9680  pop r9
00007f4e3fdd9682  pop r8
00007f4e3fdd9684  pop rsi
00007f4e3fdd9685  pop rdi
00007f4e3fdd9686  pop rdx
00007f4e3fdd9687  pop rcx
00007f4e3fdd9688  pop rax
00007f4e3fdd9689  add rsp, 0x08
00007f4e3fdd968d  jmp 0x00007F4E3FDD6265
00007f4e3fdd9692  sub rsp, 0x08
00007f4e3fdd9696  push rax
00007f4e3fdd9697  push rcx
00007f4e3fdd9698  push rdx
00007f4e3fdd9699  push rdi
00007f4e3fdd969a  push rsi
00007f4e3fdd969b  push r8
00007f4e3fdd969d  push r9
00007f4e3fdd969f  push r10
00007f4e3fdd96a1  push r11
00007f4e3fdd96a3  sub rsp, 0xF0
00007f4e3fdd96aa  vmovaps [rsp], xmm0
00007f4e3fdd96af  vmovaps [rsp+0x10], xmm1
00007f4e3fdd96b5  vmovaps [rsp+0x20], xmm2
00007f4e3fdd96bb  vmovaps [rsp+0x30], xmm3
00007f4e3fdd96c1  vmovaps [rsp+0x40], xmm5
00007f4e3fdd96c7  vmovaps [rsp+0x50], xmm6
00007f4e3fdd96cd  vmovaps [rsp+0x60], xmm7
00007f4e3fdd96d3  vmovaps [rsp+0x70], xmm8
00007f4e3fdd96d9  vmovaps [rsp+0x80], xmm9
00007f4e3fdd96e2  vmovaps [rsp+0x90], xmm10
00007f4e3fdd96eb  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd96f4  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd96fd  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd9706  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd970f  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd9718  sub rsp, 0x30
00007f4e3fdd971c  movaps [rsp], xmm4
00007f4e3fdd9720  movaps [rsp+0x10], xmm13
00007f4e3fdd9726  movaps [rsp+0x20], xmm8
00007f4e3fdd972c  lea rdi, [rsp]
00007f4e3fdd9730  mov esi, 0x00
00007f4e3fdd9735  mov rax, 0x5D97141E9530
00007f4e3fdd973f  call rax
00007f4e3fdd9741  movaps xmm4, [rsp]
00007f4e3fdd9745  add rsp, 0x30
00007f4e3fdd9749  vmovaps xmm0, [rsp]
00007f4e3fdd974e  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9754  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd975a  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9760  vmovaps xmm5, [rsp+0x40]
00007f4e3fdd9766  vmovaps xmm6, [rsp+0x50]
00007f4e3fdd976c  vmovaps xmm7, [rsp+0x60]
00007f4e3fdd9772  vmovaps xmm8, [rsp+0x70]
00007f4e3fdd9778  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd9781  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd978a  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd9793  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd979c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd97a5  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd97ae  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd97b7  add rsp, 0xF0
00007f4e3fdd97be  pop r11
00007f4e3fdd97c0  pop r10
00007f4e3fdd97c2  pop r9
00007f4e3fdd97c4  pop r8
00007f4e3fdd97c6  pop rsi
00007f4e3fdd97c7  pop rdi
00007f4e3fdd97c8  pop rdx
00007f4e3fdd97c9  pop rcx
00007f4e3fdd97ca  pop rax
00007f4e3fdd97cb  add rsp, 0x08
00007f4e3fdd97cf  jmp 0x00007F4E3FDD628A
00007f4e3fdd97d4  sub rsp, 0x08
00007f4e3fdd97d8  push rax
00007f4e3fdd97d9  push rcx
00007f4e3fdd97da  push rdx
00007f4e3fdd97db  push rdi
00007f4e3fdd97dc  push rsi
00007f4e3fdd97dd  push r8
00007f4e3fdd97df  push r9
00007f4e3fdd97e1  push r10
00007f4e3fdd97e3  push r11
00007f4e3fdd97e5  sub rsp, 0xF0
00007f4e3fdd97ec  vmovaps [rsp], xmm0
00007f4e3fdd97f1  vmovaps [rsp+0x10], xmm1
00007f4e3fdd97f7  vmovaps [rsp+0x20], xmm2
00007f4e3fdd97fd  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9803  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9809  vmovaps [rsp+0x50], xmm5
00007f4e3fdd980f  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9815  vmovaps [rsp+0x70], xmm7
00007f4e3fdd981b  vmovaps [rsp+0x80], xmm8
00007f4e3fdd9824  vmovaps [rsp+0x90], xmm9
00007f4e3fdd982d  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd9836  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd983f  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd9848  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9851  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd985a  sub rsp, 0x30
00007f4e3fdd985e  movaps [rsp], xmm13
00007f4e3fdd9863  movaps [rsp+0x10], xmm15
00007f4e3fdd9869  movaps [rsp+0x20], xmm9
00007f4e3fdd986f  lea rdi, [rsp]
00007f4e3fdd9873  mov esi, 0x00
00007f4e3fdd9878  mov rax, 0x5D97141E9530
00007f4e3fdd9882  call rax
00007f4e3fdd9884  movaps xmm13, [rsp]
00007f4e3fdd9889  add rsp, 0x30
00007f4e3fdd988d  vmovaps xmm0, [rsp]
00007f4e3fdd9892  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9898  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd989e  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd98a4  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd98aa  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd98b0  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd98b6  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd98bc  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd98c5  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd98ce  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd98d7  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd98e0  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd98e9  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd98f2  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd98fb  add rsp, 0xF0
00007f4e3fdd9902  pop r11
00007f4e3fdd9904  pop r10
00007f4e3fdd9906  pop r9
00007f4e3fdd9908  pop r8
00007f4e3fdd990a  pop rsi
00007f4e3fdd990b  pop rdi
00007f4e3fdd990c  pop rdx
00007f4e3fdd990d  pop rcx
00007f4e3fdd990e  pop rax
00007f4e3fdd990f  add rsp, 0x08
00007f4e3fdd9913  jmp 0x00007F4E3FDD62A5
00007f4e3fdd9918  sub rsp, 0x08
00007f4e3fdd991c  push rax
00007f4e3fdd991d  push rcx
00007f4e3fdd991e  push rdx
00007f4e3fdd991f  push rdi
00007f4e3fdd9920  push rsi
00007f4e3fdd9921  push r8
00007f4e3fdd9923  push r9
00007f4e3fdd9925  push r10
00007f4e3fdd9927  push r11
00007f4e3fdd9929  sub rsp, 0xF0
00007f4e3fdd9930  vmovaps [rsp], xmm0
00007f4e3fdd9935  vmovaps [rsp+0x10], xmm1
00007f4e3fdd993b  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9941  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9947  vmovaps [rsp+0x40], xmm4
00007f4e3fdd994d  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9953  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9959  vmovaps [rsp+0x70], xmm7
00007f4e3fdd995f  vmovaps [rsp+0x80], xmm8
00007f4e3fdd9968  vmovaps [rsp+0x90], xmm9
00007f4e3fdd9971  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd997a  vmovaps [rsp+0xB0], xmm11
00007f4e3fdd9983  vmovaps [rsp+0xC0], xmm12
00007f4e3fdd998c  vmovaps [rsp+0xD0], xmm13
00007f4e3fdd9995  vmovaps [rsp+0xE0], xmm14
00007f4e3fdd999e  sub rsp, 0x30
00007f4e3fdd99a2  movaps [rsp], xmm15
00007f4e3fdd99a7  movaps [rsp+0x10], xmm1
00007f4e3fdd99ac  movaps [rsp+0x20], xmm5
00007f4e3fdd99b1  lea rdi, [rsp]
00007f4e3fdd99b5  mov esi, 0x00
00007f4e3fdd99ba  mov rax, 0x5D97141E9530
00007f4e3fdd99c4  call rax
00007f4e3fdd99c6  movaps xmm15, [rsp]
00007f4e3fdd99cb  add rsp, 0x30
00007f4e3fdd99cf  vmovaps xmm0, [rsp]
00007f4e3fdd99d4  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd99da  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd99e0  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd99e6  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd99ec  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd99f2  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd99f8  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd99fe  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd9a07  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd9a10  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd9a19  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdd9a22  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdd9a2b  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdd9a34  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdd9a3d  add rsp, 0xF0
00007f4e3fdd9a44  pop r11
00007f4e3fdd9a46  pop r10
00007f4e3fdd9a48  pop r9
00007f4e3fdd9a4a  pop r8
00007f4e3fdd9a4c  pop rsi
00007f4e3fdd9a4d  pop rdi
00007f4e3fdd9a4e  pop rdx
00007f4e3fdd9a4f  pop rcx
00007f4e3fdd9a50  pop rax
00007f4e3fdd9a51  add rsp, 0x08
00007f4e3fdd9a55  jmp 0x00007F4E3FDD62C0
00007f4e3fdd9a5a  call 0x00007F4E3FCD64F0
00007f4e3fdd9a5f  jmp 0x00007F4E3FDD631B
00007f4e3fdd9a64  sub rsp, 0x08
00007f4e3fdd9a68  push rax
00007f4e3fdd9a69  push rcx
00007f4e3fdd9a6a  push rdx
00007f4e3fdd9a6b  push rdi
00007f4e3fdd9a6c  push rsi
00007f4e3fdd9a6d  push r8
00007f4e3fdd9a6f  push r9
00007f4e3fdd9a71  push r10
00007f4e3fdd9a73  push r11
00007f4e3fdd9a75  sub rsp, 0xF0
00007f4e3fdd9a7c  vmovaps [rsp], xmm0
00007f4e3fdd9a81  vmovaps [rsp+0x10], xmm1
00007f4e3fdd9a87  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9a8d  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9a93  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9a99  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9a9f  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9aa5  vmovaps [rsp+0x70], xmm7
00007f4e3fdd9aab  vmovaps [rsp+0x80], xmm8
00007f4e3fdd9ab4  vmovaps [rsp+0x90], xmm10
00007f4e3fdd9abd  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd9ac6  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd9acf  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd9ad8  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9ae1  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd9aea  sub rsp, 0x30
00007f4e3fdd9aee  movaps [rsp], xmm9
00007f4e3fdd9af3  movaps [rsp+0x10], xmm8
00007f4e3fdd9af9  movaps [rsp+0x20], xmm11
00007f4e3fdd9aff  lea rdi, [rsp]
00007f4e3fdd9b03  mov esi, 0x00
00007f4e3fdd9b08  mov rax, 0x5D97141E9530
00007f4e3fdd9b12  call rax
00007f4e3fdd9b14  movaps xmm9, [rsp]
00007f4e3fdd9b19  add rsp, 0x30
00007f4e3fdd9b1d  vmovaps xmm0, [rsp]
00007f4e3fdd9b22  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9b28  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd9b2e  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9b34  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd9b3a  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd9b40  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd9b46  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd9b4c  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd9b55  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd9b5e  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd9b67  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd9b70  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd9b79  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd9b82  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd9b8b  add rsp, 0xF0
00007f4e3fdd9b92  pop r11
00007f4e3fdd9b94  pop r10
00007f4e3fdd9b96  pop r9
00007f4e3fdd9b98  pop r8
00007f4e3fdd9b9a  pop rsi
00007f4e3fdd9b9b  pop rdi
00007f4e3fdd9b9c  pop rdx
00007f4e3fdd9b9d  pop rcx
00007f4e3fdd9b9e  pop rax
00007f4e3fdd9b9f  add rsp, 0x08
00007f4e3fdd9ba3  jmp 0x00007F4E3FDD6352
00007f4e3fdd9ba8  sub rsp, 0x08
00007f4e3fdd9bac  push rax
00007f4e3fdd9bad  push rcx
00007f4e3fdd9bae  push rdx
00007f4e3fdd9baf  push rdi
00007f4e3fdd9bb0  push rsi
00007f4e3fdd9bb1  push r8
00007f4e3fdd9bb3  push r9
00007f4e3fdd9bb5  push r10
00007f4e3fdd9bb7  push r11
00007f4e3fdd9bb9  sub rsp, 0xF0
00007f4e3fdd9bc0  vmovaps [rsp], xmm0
00007f4e3fdd9bc5  vmovaps [rsp+0x10], xmm1
00007f4e3fdd9bcb  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9bd1  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9bd7  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9bdd  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9be3  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9be9  vmovaps [rsp+0x70], xmm7
00007f4e3fdd9bef  vmovaps [rsp+0x80], xmm8
00007f4e3fdd9bf8  vmovaps [rsp+0x90], xmm9
00007f4e3fdd9c01  vmovaps [rsp+0xA0], xmm10
00007f4e3fdd9c0a  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd9c13  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd9c1c  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9c25  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd9c2e  sub rsp, 0x30
00007f4e3fdd9c32  movaps [rsp], xmm11
00007f4e3fdd9c37  movaps [rsp+0x10], xmm10
00007f4e3fdd9c3d  movaps [rsp+0x20], xmm6
00007f4e3fdd9c42  lea rdi, [rsp]
00007f4e3fdd9c46  mov esi, 0x00
00007f4e3fdd9c4b  mov rax, 0x5D97141E9530
00007f4e3fdd9c55  call rax
00007f4e3fdd9c57  movaps xmm11, [rsp]
00007f4e3fdd9c5c  add rsp, 0x30
00007f4e3fdd9c60  vmovaps xmm0, [rsp]
00007f4e3fdd9c65  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9c6b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd9c71  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9c77  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd9c7d  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd9c83  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd9c89  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd9c8f  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd9c98  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd9ca1  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdd9caa  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd9cb3  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd9cbc  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd9cc5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd9cce  add rsp, 0xF0
00007f4e3fdd9cd5  pop r11
00007f4e3fdd9cd7  pop r10
00007f4e3fdd9cd9  pop r9
00007f4e3fdd9cdb  pop r8
00007f4e3fdd9cdd  pop rsi
00007f4e3fdd9cde  pop rdi
00007f4e3fdd9cdf  pop rdx
00007f4e3fdd9ce0  pop rcx
00007f4e3fdd9ce1  pop rax
00007f4e3fdd9ce2  add rsp, 0x08
00007f4e3fdd9ce6  jmp 0x00007F4E3FDD636D
00007f4e3fdd9ceb  sub rsp, 0x08
00007f4e3fdd9cef  push rax
00007f4e3fdd9cf0  push rcx
00007f4e3fdd9cf1  push rdx
00007f4e3fdd9cf2  push rdi
00007f4e3fdd9cf3  push rsi
00007f4e3fdd9cf4  push r8
00007f4e3fdd9cf6  push r9
00007f4e3fdd9cf8  push r10
00007f4e3fdd9cfa  push r11
00007f4e3fdd9cfc  sub rsp, 0xF0
00007f4e3fdd9d03  vmovaps [rsp], xmm0
00007f4e3fdd9d08  vmovaps [rsp+0x10], xmm1
00007f4e3fdd9d0e  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9d14  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9d1a  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9d20  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9d26  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9d2c  vmovaps [rsp+0x70], xmm7
00007f4e3fdd9d32  vmovaps [rsp+0x80], xmm8
00007f4e3fdd9d3b  vmovaps [rsp+0x90], xmm9
00007f4e3fdd9d44  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd9d4d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd9d56  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd9d5f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9d68  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd9d71  sub rsp, 0x30
00007f4e3fdd9d75  movaps [rsp], xmm10
00007f4e3fdd9d7a  movaps [rsp+0x10], xmm14
00007f4e3fdd9d80  movaps [rsp+0x20], xmm4
00007f4e3fdd9d85  lea rdi, [rsp]
00007f4e3fdd9d89  mov esi, 0x00
00007f4e3fdd9d8e  mov rax, 0x5D97141E9530
00007f4e3fdd9d98  call rax
00007f4e3fdd9d9a  movaps xmm10, [rsp]
00007f4e3fdd9d9f  add rsp, 0x30
00007f4e3fdd9da3  vmovaps xmm0, [rsp]
00007f4e3fdd9da8  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9dae  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd9db4  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9dba  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd9dc0  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd9dc6  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd9dcc  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd9dd2  vmovaps xmm8, [rsp+0x80]
00007f4e3fdd9ddb  vmovaps xmm9, [rsp+0x90]
00007f4e3fdd9de4  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd9ded  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd9df6  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd9dff  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd9e08  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd9e11  add rsp, 0xF0
00007f4e3fdd9e18  pop r11
00007f4e3fdd9e1a  pop r10
00007f4e3fdd9e1c  pop r9
00007f4e3fdd9e1e  pop r8
00007f4e3fdd9e20  pop rsi
00007f4e3fdd9e21  pop rdi
00007f4e3fdd9e22  pop rdx
00007f4e3fdd9e23  pop rcx
00007f4e3fdd9e24  pop rax
00007f4e3fdd9e25  add rsp, 0x08
00007f4e3fdd9e29  jmp 0x00007F4E3FDD6388
00007f4e3fdd9e2e  sub rsp, 0x08
00007f4e3fdd9e32  push rax
00007f4e3fdd9e33  push rcx
00007f4e3fdd9e34  push rdx
00007f4e3fdd9e35  push rdi
00007f4e3fdd9e36  push rsi
00007f4e3fdd9e37  push r8
00007f4e3fdd9e39  push r9
00007f4e3fdd9e3b  push r10
00007f4e3fdd9e3d  push r11
00007f4e3fdd9e3f  sub rsp, 0xF0
00007f4e3fdd9e46  vmovaps [rsp], xmm0
00007f4e3fdd9e4b  vmovaps [rsp+0x10], xmm1
00007f4e3fdd9e51  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9e57  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9e5d  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9e63  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9e69  vmovaps [rsp+0x60], xmm6
00007f4e3fdd9e6f  vmovaps [rsp+0x70], xmm7
00007f4e3fdd9e75  vmovaps [rsp+0x80], xmm9
00007f4e3fdd9e7e  vmovaps [rsp+0x90], xmm10
00007f4e3fdd9e87  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd9e90  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd9e99  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd9ea2  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9eab  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd9eb4  sub rsp, 0x30
00007f4e3fdd9eb8  movaps [rsp], xmm8
00007f4e3fdd9ebd  movaps [rsp+0x10], xmm1
00007f4e3fdd9ec2  movaps [rsp+0x20], xmm14
00007f4e3fdd9ec8  lea rdi, [rsp]
00007f4e3fdd9ecc  mov esi, 0x00
00007f4e3fdd9ed1  mov rax, 0x5D97141E9530
00007f4e3fdd9edb  call rax
00007f4e3fdd9edd  movaps xmm8, [rsp]
00007f4e3fdd9ee2  add rsp, 0x30
00007f4e3fdd9ee6  vmovaps xmm0, [rsp]
00007f4e3fdd9eeb  vmovaps xmm1, [rsp+0x10]
00007f4e3fdd9ef1  vmovaps xmm2, [rsp+0x20]
00007f4e3fdd9ef7  vmovaps xmm3, [rsp+0x30]
00007f4e3fdd9efd  vmovaps xmm4, [rsp+0x40]
00007f4e3fdd9f03  vmovaps xmm5, [rsp+0x50]
00007f4e3fdd9f09  vmovaps xmm6, [rsp+0x60]
00007f4e3fdd9f0f  vmovaps xmm7, [rsp+0x70]
00007f4e3fdd9f15  vmovaps xmm9, [rsp+0x80]
00007f4e3fdd9f1e  vmovaps xmm10, [rsp+0x90]
00007f4e3fdd9f27  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdd9f30  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdd9f39  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdd9f42  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdd9f4b  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdd9f54  add rsp, 0xF0
00007f4e3fdd9f5b  pop r11
00007f4e3fdd9f5d  pop r10
00007f4e3fdd9f5f  pop r9
00007f4e3fdd9f61  pop r8
00007f4e3fdd9f63  pop rsi
00007f4e3fdd9f64  pop rdi
00007f4e3fdd9f65  pop rdx
00007f4e3fdd9f66  pop rcx
00007f4e3fdd9f67  pop rax
00007f4e3fdd9f68  add rsp, 0x08
00007f4e3fdd9f6c  jmp 0x00007F4E3FDD63AE
00007f4e3fdd9f71  sub rsp, 0x08
00007f4e3fdd9f75  push rax
00007f4e3fdd9f76  push rcx
00007f4e3fdd9f77  push rdx
00007f4e3fdd9f78  push rdi
00007f4e3fdd9f79  push rsi
00007f4e3fdd9f7a  push r8
00007f4e3fdd9f7c  push r9
00007f4e3fdd9f7e  push r10
00007f4e3fdd9f80  push r11
00007f4e3fdd9f82  sub rsp, 0xF0
00007f4e3fdd9f89  vmovaps [rsp], xmm0
00007f4e3fdd9f8e  vmovaps [rsp+0x10], xmm1
00007f4e3fdd9f94  vmovaps [rsp+0x20], xmm2
00007f4e3fdd9f9a  vmovaps [rsp+0x30], xmm3
00007f4e3fdd9fa0  vmovaps [rsp+0x40], xmm4
00007f4e3fdd9fa6  vmovaps [rsp+0x50], xmm5
00007f4e3fdd9fac  vmovaps [rsp+0x60], xmm7
00007f4e3fdd9fb2  vmovaps [rsp+0x70], xmm8
00007f4e3fdd9fb8  vmovaps [rsp+0x80], xmm9
00007f4e3fdd9fc1  vmovaps [rsp+0x90], xmm10
00007f4e3fdd9fca  vmovaps [rsp+0xA0], xmm11
00007f4e3fdd9fd3  vmovaps [rsp+0xB0], xmm12
00007f4e3fdd9fdc  vmovaps [rsp+0xC0], xmm13
00007f4e3fdd9fe5  vmovaps [rsp+0xD0], xmm14
00007f4e3fdd9fee  vmovaps [rsp+0xE0], xmm15
00007f4e3fdd9ff7  sub rsp, 0x30
00007f4e3fdd9ffb  movaps [rsp], xmm6
00007f4e3fdd9fff  movaps [rsp+0x10], xmm1
00007f4e3fdda004  movaps [rsp+0x20], xmm14
00007f4e3fdda00a  lea rdi, [rsp]
00007f4e3fdda00e  mov esi, 0x00
00007f4e3fdda013  mov rax, 0x5D97141E9530
00007f4e3fdda01d  call rax
00007f4e3fdda01f  movaps xmm6, [rsp]
00007f4e3fdda023  add rsp, 0x30
00007f4e3fdda027  vmovaps xmm0, [rsp]
00007f4e3fdda02c  vmovaps xmm1, [rsp+0x10]
00007f4e3fdda032  vmovaps xmm2, [rsp+0x20]
00007f4e3fdda038  vmovaps xmm3, [rsp+0x30]
00007f4e3fdda03e  vmovaps xmm4, [rsp+0x40]
00007f4e3fdda044  vmovaps xmm5, [rsp+0x50]
00007f4e3fdda04a  vmovaps xmm7, [rsp+0x60]
00007f4e3fdda050  vmovaps xmm8, [rsp+0x70]
00007f4e3fdda056  vmovaps xmm9, [rsp+0x80]
00007f4e3fdda05f  vmovaps xmm10, [rsp+0x90]
00007f4e3fdda068  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdda071  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdda07a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdda083  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdda08c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdda095  add rsp, 0xF0
00007f4e3fdda09c  pop r11
00007f4e3fdda09e  pop r10
00007f4e3fdda0a0  pop r9
00007f4e3fdda0a2  pop r8
00007f4e3fdda0a4  pop rsi
00007f4e3fdda0a5  pop rdi
00007f4e3fdda0a6  pop rdx
00007f4e3fdda0a7  pop rcx
00007f4e3fdda0a8  pop rax
00007f4e3fdda0a9  add rsp, 0x08
00007f4e3fdda0ad  jmp 0x00007F4E3FDD63DA
00007f4e3fdda0b2  sub rsp, 0x08
00007f4e3fdda0b6  push rax
00007f4e3fdda0b7  push rcx
00007f4e3fdda0b8  push rdx
00007f4e3fdda0b9  push rdi
00007f4e3fdda0ba  push rsi
00007f4e3fdda0bb  push r8
00007f4e3fdda0bd  push r9
00007f4e3fdda0bf  push r10
00007f4e3fdda0c1  push r11
00007f4e3fdda0c3  sub rsp, 0xF0
00007f4e3fdda0ca  vmovaps [rsp], xmm0
00007f4e3fdda0cf  vmovaps [rsp+0x10], xmm1
00007f4e3fdda0d5  vmovaps [rsp+0x20], xmm2
00007f4e3fdda0db  vmovaps [rsp+0x30], xmm3
00007f4e3fdda0e1  vmovaps [rsp+0x40], xmm4
00007f4e3fdda0e7  vmovaps [rsp+0x50], xmm5
00007f4e3fdda0ed  vmovaps [rsp+0x60], xmm6
00007f4e3fdda0f3  vmovaps [rsp+0x70], xmm7
00007f4e3fdda0f9  vmovaps [rsp+0x80], xmm8
00007f4e3fdda102  vmovaps [rsp+0x90], xmm9
00007f4e3fdda10b  vmovaps [rsp+0xA0], xmm10
00007f4e3fdda114  vmovaps [rsp+0xB0], xmm11
00007f4e3fdda11d  vmovaps [rsp+0xC0], xmm12
00007f4e3fdda126  vmovaps [rsp+0xD0], xmm13
00007f4e3fdda12f  vmovaps [rsp+0xE0], xmm15
00007f4e3fdda138  sub rsp, 0x30
00007f4e3fdda13c  movaps [rsp], xmm14
00007f4e3fdda141  movaps [rsp+0x10], xmm12
00007f4e3fdda147  movaps [rsp+0x20], xmm1
00007f4e3fdda14c  lea rdi, [rsp]
00007f4e3fdda150  mov esi, 0x00
00007f4e3fdda155  mov rax, 0x5D97141E9530
00007f4e3fdda15f  call rax
00007f4e3fdda161  movaps xmm14, [rsp]
00007f4e3fdda166  add rsp, 0x30
00007f4e3fdda16a  vmovaps xmm0, [rsp]
00007f4e3fdda16f  vmovaps xmm1, [rsp+0x10]
00007f4e3fdda175  vmovaps xmm2, [rsp+0x20]
00007f4e3fdda17b  vmovaps xmm3, [rsp+0x30]
00007f4e3fdda181  vmovaps xmm4, [rsp+0x40]
00007f4e3fdda187  vmovaps xmm5, [rsp+0x50]
00007f4e3fdda18d  vmovaps xmm6, [rsp+0x60]
00007f4e3fdda193  vmovaps xmm7, [rsp+0x70]
00007f4e3fdda199  vmovaps xmm8, [rsp+0x80]
00007f4e3fdda1a2  vmovaps xmm9, [rsp+0x90]
00007f4e3fdda1ab  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdda1b4  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdda1bd  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdda1c6  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdda1cf  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdda1d8  add rsp, 0xF0
00007f4e3fdda1df  pop r11
00007f4e3fdda1e1  pop r10
00007f4e3fdda1e3  pop r9
00007f4e3fdda1e5  pop r8
00007f4e3fdda1e7  pop rsi
00007f4e3fdda1e8  pop rdi
00007f4e3fdda1e9  pop rdx
00007f4e3fdda1ea  pop rcx
00007f4e3fdda1eb  pop rax
00007f4e3fdda1ec  add rsp, 0x08
00007f4e3fdda1f0  jmp 0x00007F4E3FDD6400
00007f4e3fdda1f5  sub rsp, 0x08
00007f4e3fdda1f9  push rax
00007f4e3fdda1fa  push rcx
00007f4e3fdda1fb  push rdx
00007f4e3fdda1fc  push rdi
00007f4e3fdda1fd  push rsi
00007f4e3fdda1fe  push r8
00007f4e3fdda200  push r9
00007f4e3fdda202  push r10
00007f4e3fdda204  push r11
00007f4e3fdda206  sub rsp, 0xF0
00007f4e3fdda20d  vmovaps [rsp], xmm0
00007f4e3fdda212  vmovaps [rsp+0x10], xmm2
00007f4e3fdda218  vmovaps [rsp+0x20], xmm3
00007f4e3fdda21e  vmovaps [rsp+0x30], xmm4
00007f4e3fdda224  vmovaps [rsp+0x40], xmm5
00007f4e3fdda22a  vmovaps [rsp+0x50], xmm6
00007f4e3fdda230  vmovaps [rsp+0x60], xmm7
00007f4e3fdda236  vmovaps [rsp+0x70], xmm8
00007f4e3fdda23c  vmovaps [rsp+0x80], xmm9
00007f4e3fdda245  vmovaps [rsp+0x90], xmm10
00007f4e3fdda24e  vmovaps [rsp+0xA0], xmm11
00007f4e3fdda257  vmovaps [rsp+0xB0], xmm12
00007f4e3fdda260  vmovaps [rsp+0xC0], xmm13
00007f4e3fdda269  vmovaps [rsp+0xD0], xmm14
00007f4e3fdda272  vmovaps [rsp+0xE0], xmm15
00007f4e3fdda27b  sub rsp, 0x30
00007f4e3fdda27f  movaps [rsp], xmm1
00007f4e3fdda283  movaps [rsp+0x10], xmm13
00007f4e3fdda289  movaps [rsp+0x20], xmm9
00007f4e3fdda28f  lea rdi, [rsp]
00007f4e3fdda293  mov esi, 0x00
00007f4e3fdda298  mov rax, 0x5D97141E9530
00007f4e3fdda2a2  call rax
00007f4e3fdda2a4  movaps xmm1, [rsp]
00007f4e3fdda2a8  add rsp, 0x30
00007f4e3fdda2ac  vmovaps xmm0, [rsp]
00007f4e3fdda2b1  vmovaps xmm2, [rsp+0x10]
00007f4e3fdda2b7  vmovaps xmm3, [rsp+0x20]
00007f4e3fdda2bd  vmovaps xmm4, [rsp+0x30]
00007f4e3fdda2c3  vmovaps xmm5, [rsp+0x40]
00007f4e3fdda2c9  vmovaps xmm6, [rsp+0x50]
00007f4e3fdda2cf  vmovaps xmm7, [rsp+0x60]
00007f4e3fdda2d5  vmovaps xmm8, [rsp+0x70]
00007f4e3fdda2db  vmovaps xmm9, [rsp+0x80]
00007f4e3fdda2e4  vmovaps xmm10, [rsp+0x90]
00007f4e3fdda2ed  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdda2f6  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdda2ff  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdda308  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdda311  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdda31a  add rsp, 0xF0
00007f4e3fdda321  pop r11
00007f4e3fdda323  pop r10
00007f4e3fdda325  pop r9
00007f4e3fdda327  pop r8
00007f4e3fdda329  pop rsi
00007f4e3fdda32a  pop rdi
00007f4e3fdda32b  pop rdx
00007f4e3fdda32c  pop rcx
00007f4e3fdda32d  pop rax
00007f4e3fdda32e  add rsp, 0x08
00007f4e3fdda332  jmp 0x00007F4E3FDD641A
00007f4e3fdda337  sub rsp, 0x08
00007f4e3fdda33b  push rax
00007f4e3fdda33c  push rcx
00007f4e3fdda33d  push rdx
00007f4e3fdda33e  push rdi
00007f4e3fdda33f  push rsi
00007f4e3fdda340  push r8
00007f4e3fdda342  push r9
00007f4e3fdda344  push r10
00007f4e3fdda346  push r11
00007f4e3fdda348  sub rsp, 0xF0
00007f4e3fdda34f  vmovaps [rsp], xmm0
00007f4e3fdda354  vmovaps [rsp+0x10], xmm1
00007f4e3fdda35a  vmovaps [rsp+0x20], xmm2
00007f4e3fdda360  vmovaps [rsp+0x30], xmm3
00007f4e3fdda366  vmovaps [rsp+0x40], xmm4
00007f4e3fdda36c  vmovaps [rsp+0x50], xmm5
00007f4e3fdda372  vmovaps [rsp+0x60], xmm6
00007f4e3fdda378  vmovaps [rsp+0x70], xmm7
00007f4e3fdda37e  vmovaps [rsp+0x80], xmm8
00007f4e3fdda387  vmovaps [rsp+0x90], xmm9
00007f4e3fdda390  vmovaps [rsp+0xA0], xmm10
00007f4e3fdda399  vmovaps [rsp+0xB0], xmm11
00007f4e3fdda3a2  vmovaps [rsp+0xC0], xmm13
00007f4e3fdda3ab  vmovaps [rsp+0xD0], xmm14
00007f4e3fdda3b4  vmovaps [rsp+0xE0], xmm15
00007f4e3fdda3bd  sub rsp, 0x30
00007f4e3fdda3c1  movaps [rsp], xmm12
00007f4e3fdda3c6  movaps [rsp+0x10], xmm7
00007f4e3fdda3cb  movaps [rsp+0x20], xmm13
00007f4e3fdda3d1  lea rdi, [rsp]
00007f4e3fdda3d5  mov esi, 0x00
00007f4e3fdda3da  mov rax, 0x5D97141E9530
00007f4e3fdda3e4  call rax
00007f4e3fdda3e6  movaps xmm12, [rsp]
00007f4e3fdda3eb  add rsp, 0x30
00007f4e3fdda3ef  vmovaps xmm0, [rsp]
00007f4e3fdda3f4  vmovaps xmm1, [rsp+0x10]
00007f4e3fdda3fa  vmovaps xmm2, [rsp+0x20]
00007f4e3fdda400  vmovaps xmm3, [rsp+0x30]
00007f4e3fdda406  vmovaps xmm4, [rsp+0x40]
00007f4e3fdda40c  vmovaps xmm5, [rsp+0x50]
00007f4e3fdda412  vmovaps xmm6, [rsp+0x60]
00007f4e3fdda418  vmovaps xmm7, [rsp+0x70]
00007f4e3fdda41e  vmovaps xmm8, [rsp+0x80]
00007f4e3fdda427  vmovaps xmm9, [rsp+0x90]
00007f4e3fdda430  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdda439  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdda442  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdda44b  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdda454  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdda45d  add rsp, 0xF0
00007f4e3fdda464  pop r11
00007f4e3fdda466  pop r10
00007f4e3fdda468  pop r9
00007f4e3fdda46a  pop r8
00007f4e3fdda46c  pop rsi
00007f4e3fdda46d  pop rdi
00007f4e3fdda46e  pop rdx
00007f4e3fdda46f  pop rcx
00007f4e3fdda470  pop rax
00007f4e3fdda471  add rsp, 0x08
00007f4e3fdda475  jmp 0x00007F4E3FDD6441
00007f4e3fdda47a  sub rsp, 0x08
00007f4e3fdda47e  push rax
00007f4e3fdda47f  push rcx
00007f4e3fdda480  push rdx
00007f4e3fdda481  push rdi
00007f4e3fdda482  push rsi
00007f4e3fdda483  push r8
00007f4e3fdda485  push r9
00007f4e3fdda487  push r10
00007f4e3fdda489  push r11
00007f4e3fdda48b  sub rsp, 0xF0
00007f4e3fdda492  vmovaps [rsp], xmm0
00007f4e3fdda497  vmovaps [rsp+0x10], xmm1
00007f4e3fdda49d  vmovaps [rsp+0x20], xmm2
00007f4e3fdda4a3  vmovaps [rsp+0x30], xmm3
00007f4e3fdda4a9  vmovaps [rsp+0x40], xmm4
00007f4e3fdda4af  vmovaps [rsp+0x50], xmm5
00007f4e3fdda4b5  vmovaps [rsp+0x60], xmm6
00007f4e3fdda4bb  vmovaps [rsp+0x70], xmm7
00007f4e3fdda4c1  vmovaps [rsp+0x80], xmm8
00007f4e3fdda4ca  vmovaps [rsp+0x90], xmm9
00007f4e3fdda4d3  vmovaps [rsp+0xA0], xmm10
00007f4e3fdda4dc  vmovaps [rsp+0xB0], xmm11
00007f4e3fdda4e5  vmovaps [rsp+0xC0], xmm12
00007f4e3fdda4ee  vmovaps [rsp+0xD0], xmm14
00007f4e3fdda4f7  vmovaps [rsp+0xE0], xmm15
00007f4e3fdda500  sub rsp, 0x30
00007f4e3fdda504  movaps [rsp], xmm13
00007f4e3fdda509  movaps [rsp+0x10], xmm15
00007f4e3fdda50f  movaps [rsp+0x20], xmm8
00007f4e3fdda515  lea rdi, [rsp]
00007f4e3fdda519  mov esi, 0x00
00007f4e3fdda51e  mov rax, 0x5D97141E9530
00007f4e3fdda528  call rax
00007f4e3fdda52a  movaps xmm13, [rsp]
00007f4e3fdda52f  add rsp, 0x30
00007f4e3fdda533  vmovaps xmm0, [rsp]
00007f4e3fdda538  vmovaps xmm1, [rsp+0x10]
00007f4e3fdda53e  vmovaps xmm2, [rsp+0x20]
00007f4e3fdda544  vmovaps xmm3, [rsp+0x30]
00007f4e3fdda54a  vmovaps xmm4, [rsp+0x40]
00007f4e3fdda550  vmovaps xmm5, [rsp+0x50]
00007f4e3fdda556  vmovaps xmm6, [rsp+0x60]
00007f4e3fdda55c  vmovaps xmm7, [rsp+0x70]
00007f4e3fdda562  vmovaps xmm8, [rsp+0x80]
00007f4e3fdda56b  vmovaps xmm9, [rsp+0x90]
00007f4e3fdda574  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdda57d  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdda586  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdda58f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdda598  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdda5a1  add rsp, 0xF0
00007f4e3fdda5a8  pop r11
00007f4e3fdda5aa  pop r10
00007f4e3fdda5ac  pop r9
00007f4e3fdda5ae  pop r8
00007f4e3fdda5b0  pop rsi
00007f4e3fdda5b1  pop rdi
00007f4e3fdda5b2  pop rdx
00007f4e3fdda5b3  pop rcx
00007f4e3fdda5b4  pop rax
00007f4e3fdda5b5  add rsp, 0x08
00007f4e3fdda5b9  jmp 0x00007F4E3FDD645C
00007f4e3fdda5be  sub rsp, 0x08
00007f4e3fdda5c2  push rax
00007f4e3fdda5c3  push rcx
00007f4e3fdda5c4  push rdx
00007f4e3fdda5c5  push rdi
00007f4e3fdda5c6  push rsi
00007f4e3fdda5c7  push r8
00007f4e3fdda5c9  push r9
00007f4e3fdda5cb  push r10
00007f4e3fdda5cd  push r11
00007f4e3fdda5cf  sub rsp, 0xF0
00007f4e3fdda5d6  vmovaps [rsp], xmm0
00007f4e3fdda5db  vmovaps [rsp+0x10], xmm1
00007f4e3fdda5e1  vmovaps [rsp+0x20], xmm2
00007f4e3fdda5e7  vmovaps [rsp+0x30], xmm3
00007f4e3fdda5ed  vmovaps [rsp+0x40], xmm4
00007f4e3fdda5f3  vmovaps [rsp+0x50], xmm5
00007f4e3fdda5f9  vmovaps [rsp+0x60], xmm6
00007f4e3fdda5ff  vmovaps [rsp+0x70], xmm7
00007f4e3fdda605  vmovaps [rsp+0x80], xmm9
00007f4e3fdda60e  vmovaps [rsp+0x90], xmm10
00007f4e3fdda617  vmovaps [rsp+0xA0], xmm11
00007f4e3fdda620  vmovaps [rsp+0xB0], xmm12
00007f4e3fdda629  vmovaps [rsp+0xC0], xmm13
00007f4e3fdda632  vmovaps [rsp+0xD0], xmm14
00007f4e3fdda63b  vmovaps [rsp+0xE0], xmm15
00007f4e3fdda644  sub rsp, 0x30
00007f4e3fdda648  movaps [rsp], xmm8
00007f4e3fdda64d  movaps [rsp+0x10], xmm15
00007f4e3fdda653  movaps [rsp+0x20], xmm9
00007f4e3fdda659  lea rdi, [rsp]
00007f4e3fdda65d  mov esi, 0x00
00007f4e3fdda662  mov rax, 0x5D97141E9530
00007f4e3fdda66c  call rax
00007f4e3fdda66e  movaps xmm8, [rsp]
00007f4e3fdda673  add rsp, 0x30
00007f4e3fdda677  vmovaps xmm0, [rsp]
00007f4e3fdda67c  vmovaps xmm1, [rsp+0x10]
00007f4e3fdda682  vmovaps xmm2, [rsp+0x20]
00007f4e3fdda688  vmovaps xmm3, [rsp+0x30]
00007f4e3fdda68e  vmovaps xmm4, [rsp+0x40]
00007f4e3fdda694  vmovaps xmm5, [rsp+0x50]
00007f4e3fdda69a  vmovaps xmm6, [rsp+0x60]
00007f4e3fdda6a0  vmovaps xmm7, [rsp+0x70]
00007f4e3fdda6a6  vmovaps xmm9, [rsp+0x80]
00007f4e3fdda6af  vmovaps xmm10, [rsp+0x90]
00007f4e3fdda6b8  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdda6c1  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdda6ca  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdda6d3  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdda6dc  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdda6e5  add rsp, 0xF0
00007f4e3fdda6ec  pop r11
00007f4e3fdda6ee  pop r10
00007f4e3fdda6f0  pop r9
00007f4e3fdda6f2  pop r8
00007f4e3fdda6f4  pop rsi
00007f4e3fdda6f5  pop rdi
00007f4e3fdda6f6  pop rdx
00007f4e3fdda6f7  pop rcx
00007f4e3fdda6f8  pop rax
00007f4e3fdda6f9  add rsp, 0x08
00007f4e3fdda6fd  jmp 0x00007F4E3FDD648A
00007f4e3fdda702  sub rsp, 0x08
00007f4e3fdda706  push rax
00007f4e3fdda707  push rcx
00007f4e3fdda708  push rdx
00007f4e3fdda709  push rdi
00007f4e3fdda70a  push rsi
00007f4e3fdda70b  push r8
00007f4e3fdda70d  push r9
00007f4e3fdda70f  push r10
00007f4e3fdda711  push r11
00007f4e3fdda713  sub rsp, 0xF0
00007f4e3fdda71a  vmovaps [rsp], xmm0
00007f4e3fdda71f  vmovaps [rsp+0x10], xmm1
00007f4e3fdda725  vmovaps [rsp+0x20], xmm2
00007f4e3fdda72b  vmovaps [rsp+0x30], xmm3
00007f4e3fdda731  vmovaps [rsp+0x40], xmm4
00007f4e3fdda737  vmovaps [rsp+0x50], xmm5
00007f4e3fdda73d  vmovaps [rsp+0x60], xmm6
00007f4e3fdda743  vmovaps [rsp+0x70], xmm7
00007f4e3fdda749  vmovaps [rsp+0x80], xmm8
00007f4e3fdda752  vmovaps [rsp+0x90], xmm9
00007f4e3fdda75b  vmovaps [rsp+0xA0], xmm10
00007f4e3fdda764  vmovaps [rsp+0xB0], xmm11
00007f4e3fdda76d  vmovaps [rsp+0xC0], xmm12
00007f4e3fdda776  vmovaps [rsp+0xD0], xmm13
00007f4e3fdda77f  vmovaps [rsp+0xE0], xmm14
00007f4e3fdda788  sub rsp, 0x30
00007f4e3fdda78c  movaps [rsp], xmm15
00007f4e3fdda791  movaps [rsp+0x10], xmm11
00007f4e3fdda797  movaps [rsp+0x20], xmm6
00007f4e3fdda79c  lea rdi, [rsp]
00007f4e3fdda7a0  mov esi, 0x00
00007f4e3fdda7a5  mov rax, 0x5D97141E9530
00007f4e3fdda7af  call rax
00007f4e3fdda7b1  movaps xmm15, [rsp]
00007f4e3fdda7b6  add rsp, 0x30
00007f4e3fdda7ba  vmovaps xmm0, [rsp]
00007f4e3fdda7bf  vmovaps xmm1, [rsp+0x10]
00007f4e3fdda7c5  vmovaps xmm2, [rsp+0x20]
00007f4e3fdda7cb  vmovaps xmm3, [rsp+0x30]
00007f4e3fdda7d1  vmovaps xmm4, [rsp+0x40]
00007f4e3fdda7d7  vmovaps xmm5, [rsp+0x50]
00007f4e3fdda7dd  vmovaps xmm6, [rsp+0x60]
00007f4e3fdda7e3  vmovaps xmm7, [rsp+0x70]
00007f4e3fdda7e9  vmovaps xmm8, [rsp+0x80]
00007f4e3fdda7f2  vmovaps xmm9, [rsp+0x90]
00007f4e3fdda7fb  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdda804  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdda80d  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdda816  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdda81f  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdda828  add rsp, 0xF0
00007f4e3fdda82f  pop r11
00007f4e3fdda831  pop r10
00007f4e3fdda833  pop r9
00007f4e3fdda835  pop r8
00007f4e3fdda837  pop rsi
00007f4e3fdda838  pop rdi
00007f4e3fdda839  pop rdx
00007f4e3fdda83a  pop rcx
00007f4e3fdda83b  pop rax
00007f4e3fdda83c  add rsp, 0x08
00007f4e3fdda840  jmp 0x00007F4E3FDD64A5
00007f4e3fdda845  sub rsp, 0x08
00007f4e3fdda849  push rax
00007f4e3fdda84a  push rcx
00007f4e3fdda84b  push rdx
00007f4e3fdda84c  push rdi
00007f4e3fdda84d  push rsi
00007f4e3fdda84e  push r8
00007f4e3fdda850  push r9
00007f4e3fdda852  push r10
00007f4e3fdda854  push r11
00007f4e3fdda856  sub rsp, 0xF0
00007f4e3fdda85d  vmovaps [rsp], xmm0
00007f4e3fdda862  vmovaps [rsp+0x10], xmm1
00007f4e3fdda868  vmovaps [rsp+0x20], xmm2
00007f4e3fdda86e  vmovaps [rsp+0x30], xmm3
00007f4e3fdda874  vmovaps [rsp+0x40], xmm4
00007f4e3fdda87a  vmovaps [rsp+0x50], xmm5
00007f4e3fdda880  vmovaps [rsp+0x60], xmm6
00007f4e3fdda886  vmovaps [rsp+0x70], xmm8
00007f4e3fdda88c  vmovaps [rsp+0x80], xmm9
00007f4e3fdda895  vmovaps [rsp+0x90], xmm10
00007f4e3fdda89e  vmovaps [rsp+0xA0], xmm11
00007f4e3fdda8a7  vmovaps [rsp+0xB0], xmm12
00007f4e3fdda8b0  vmovaps [rsp+0xC0], xmm13
00007f4e3fdda8b9  vmovaps [rsp+0xD0], xmm14
00007f4e3fdda8c2  vmovaps [rsp+0xE0], xmm15
00007f4e3fdda8cb  sub rsp, 0x30
00007f4e3fdda8cf  movaps [rsp], xmm7
00007f4e3fdda8d3  movaps [rsp+0x10], xmm11
00007f4e3fdda8d9  movaps [rsp+0x20], xmm9
00007f4e3fdda8df  lea rdi, [rsp]
00007f4e3fdda8e3  mov esi, 0x00
00007f4e3fdda8e8  mov rax, 0x5D97141E9530
00007f4e3fdda8f2  call rax
00007f4e3fdda8f4  movaps xmm7, [rsp]
00007f4e3fdda8f8  add rsp, 0x30
00007f4e3fdda8fc  vmovaps xmm0, [rsp]
00007f4e3fdda901  vmovaps xmm1, [rsp+0x10]
00007f4e3fdda907  vmovaps xmm2, [rsp+0x20]
00007f4e3fdda90d  vmovaps xmm3, [rsp+0x30]
00007f4e3fdda913  vmovaps xmm4, [rsp+0x40]
00007f4e3fdda919  vmovaps xmm5, [rsp+0x50]
00007f4e3fdda91f  vmovaps xmm6, [rsp+0x60]
00007f4e3fdda925  vmovaps xmm8, [rsp+0x70]
00007f4e3fdda92b  vmovaps xmm9, [rsp+0x80]
00007f4e3fdda934  vmovaps xmm10, [rsp+0x90]
00007f4e3fdda93d  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdda946  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdda94f  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdda958  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdda961  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdda96a  add rsp, 0xF0
00007f4e3fdda971  pop r11
00007f4e3fdda973  pop r10
00007f4e3fdda975  pop r9
00007f4e3fdda977  pop r8
00007f4e3fdda979  pop rsi
00007f4e3fdda97a  pop rdi
00007f4e3fdda97b  pop rdx
00007f4e3fdda97c  pop rcx
00007f4e3fdda97d  pop rax
00007f4e3fdda97e  add rsp, 0x08
00007f4e3fdda982  jmp 0x00007F4E3FDD64D2
00007f4e3fdda987  sub rsp, 0x08
00007f4e3fdda98b  push rax
00007f4e3fdda98c  push rcx
00007f4e3fdda98d  push rdx
00007f4e3fdda98e  push rdi
00007f4e3fdda98f  push rsi
00007f4e3fdda990  push r8
00007f4e3fdda992  push r9
00007f4e3fdda994  push r10
00007f4e3fdda996  push r11
00007f4e3fdda998  sub rsp, 0xF0
00007f4e3fdda99f  vmovaps [rsp], xmm0
00007f4e3fdda9a4  vmovaps [rsp+0x10], xmm1
00007f4e3fdda9aa  vmovaps [rsp+0x20], xmm2
00007f4e3fdda9b0  vmovaps [rsp+0x30], xmm3
00007f4e3fdda9b6  vmovaps [rsp+0x40], xmm4
00007f4e3fdda9bc  vmovaps [rsp+0x50], xmm5
00007f4e3fdda9c2  vmovaps [rsp+0x60], xmm6
00007f4e3fdda9c8  vmovaps [rsp+0x70], xmm7
00007f4e3fdda9ce  vmovaps [rsp+0x80], xmm8
00007f4e3fdda9d7  vmovaps [rsp+0x90], xmm9
00007f4e3fdda9e0  vmovaps [rsp+0xA0], xmm10
00007f4e3fdda9e9  vmovaps [rsp+0xB0], xmm12
00007f4e3fdda9f2  vmovaps [rsp+0xC0], xmm13
00007f4e3fdda9fb  vmovaps [rsp+0xD0], xmm14
00007f4e3fddaa04  vmovaps [rsp+0xE0], xmm15
00007f4e3fddaa0d  sub rsp, 0x30
00007f4e3fddaa11  movaps [rsp], xmm11
00007f4e3fddaa16  movaps [rsp+0x10], xmm10
00007f4e3fddaa1c  movaps [rsp+0x20], xmm14
00007f4e3fddaa22  lea rdi, [rsp]
00007f4e3fddaa26  mov esi, 0x00
00007f4e3fddaa2b  mov rax, 0x5D97141E9530
00007f4e3fddaa35  call rax
00007f4e3fddaa37  movaps xmm11, [rsp]
00007f4e3fddaa3c  add rsp, 0x30
00007f4e3fddaa40  vmovaps xmm0, [rsp]
00007f4e3fddaa45  vmovaps xmm1, [rsp+0x10]
00007f4e3fddaa4b  vmovaps xmm2, [rsp+0x20]
00007f4e3fddaa51  vmovaps xmm3, [rsp+0x30]
00007f4e3fddaa57  vmovaps xmm4, [rsp+0x40]
00007f4e3fddaa5d  vmovaps xmm5, [rsp+0x50]
00007f4e3fddaa63  vmovaps xmm6, [rsp+0x60]
00007f4e3fddaa69  vmovaps xmm7, [rsp+0x70]
00007f4e3fddaa6f  vmovaps xmm8, [rsp+0x80]
00007f4e3fddaa78  vmovaps xmm9, [rsp+0x90]
00007f4e3fddaa81  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddaa8a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddaa93  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddaa9c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddaaa5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddaaae  add rsp, 0xF0
00007f4e3fddaab5  pop r11
00007f4e3fddaab7  pop r10
00007f4e3fddaab9  pop r9
00007f4e3fddaabb  pop r8
00007f4e3fddaabd  pop rsi
00007f4e3fddaabe  pop rdi
00007f4e3fddaabf  pop rdx
00007f4e3fddaac0  pop rcx
00007f4e3fddaac1  pop rax
00007f4e3fddaac2  add rsp, 0x08
00007f4e3fddaac6  jmp 0x00007F4E3FDD64ED
00007f4e3fddaacb  call 0x00007F4E3FCE45A0
00007f4e3fddaad0  jmp 0x00007F4E3FDD64F7
00007f4e3fddaad5  sub rsp, 0x08
00007f4e3fddaad9  push rax
00007f4e3fddaada  push rcx
00007f4e3fddaadb  push rdx
00007f4e3fddaadc  push rdi
00007f4e3fddaadd  push rsi
00007f4e3fddaade  push r8
00007f4e3fddaae0  push r9
00007f4e3fddaae2  push r10
00007f4e3fddaae4  push r11
00007f4e3fddaae6  sub rsp, 0xF0
00007f4e3fddaaed  vmovaps [rsp], xmm0
00007f4e3fddaaf2  vmovaps [rsp+0x10], xmm1
00007f4e3fddaaf8  vmovaps [rsp+0x20], xmm2
00007f4e3fddaafe  vmovaps [rsp+0x30], xmm3
00007f4e3fddab04  vmovaps [rsp+0x40], xmm4
00007f4e3fddab0a  vmovaps [rsp+0x50], xmm5
00007f4e3fddab10  vmovaps [rsp+0x60], xmm6
00007f4e3fddab16  vmovaps [rsp+0x70], xmm7
00007f4e3fddab1c  vmovaps [rsp+0x80], xmm8
00007f4e3fddab25  vmovaps [rsp+0x90], xmm9
00007f4e3fddab2e  vmovaps [rsp+0xA0], xmm11
00007f4e3fddab37  vmovaps [rsp+0xB0], xmm12
00007f4e3fddab40  vmovaps [rsp+0xC0], xmm13
00007f4e3fddab49  vmovaps [rsp+0xD0], xmm14
00007f4e3fddab52  vmovaps [rsp+0xE0], xmm15
00007f4e3fddab5b  sub rsp, 0x30
00007f4e3fddab5f  movaps [rsp], xmm10
00007f4e3fddab64  movaps [rsp+0x10], xmm1
00007f4e3fddab69  movaps [rsp+0x20], xmm12
00007f4e3fddab6f  lea rdi, [rsp]
00007f4e3fddab73  mov esi, 0x00
00007f4e3fddab78  mov rax, 0x5D97141E9530
00007f4e3fddab82  call rax
00007f4e3fddab84  movaps xmm10, [rsp]
00007f4e3fddab89  add rsp, 0x30
00007f4e3fddab8d  vmovaps xmm0, [rsp]
00007f4e3fddab92  vmovaps xmm1, [rsp+0x10]
00007f4e3fddab98  vmovaps xmm2, [rsp+0x20]
00007f4e3fddab9e  vmovaps xmm3, [rsp+0x30]
00007f4e3fddaba4  vmovaps xmm4, [rsp+0x40]
00007f4e3fddabaa  vmovaps xmm5, [rsp+0x50]
00007f4e3fddabb0  vmovaps xmm6, [rsp+0x60]
00007f4e3fddabb6  vmovaps xmm7, [rsp+0x70]
00007f4e3fddabbc  vmovaps xmm8, [rsp+0x80]
00007f4e3fddabc5  vmovaps xmm9, [rsp+0x90]
00007f4e3fddabce  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddabd7  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddabe0  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddabe9  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddabf2  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddabfb  add rsp, 0xF0
00007f4e3fddac02  pop r11
00007f4e3fddac04  pop r10
00007f4e3fddac06  pop r9
00007f4e3fddac08  pop r8
00007f4e3fddac0a  pop rsi
00007f4e3fddac0b  pop rdi
00007f4e3fddac0c  pop rdx
00007f4e3fddac0d  pop rcx
00007f4e3fddac0e  pop rax
00007f4e3fddac0f  add rsp, 0x08
00007f4e3fddac13  jmp 0x00007F4E3FDD651A
00007f4e3fddac18  sub rsp, 0x08
00007f4e3fddac1c  push rax
00007f4e3fddac1d  push rcx
00007f4e3fddac1e  push rdx
00007f4e3fddac1f  push rdi
00007f4e3fddac20  push rsi
00007f4e3fddac21  push r8
00007f4e3fddac23  push r9
00007f4e3fddac25  push r10
00007f4e3fddac27  push r11
00007f4e3fddac29  sub rsp, 0xF0
00007f4e3fddac30  vmovaps [rsp], xmm0
00007f4e3fddac35  vmovaps [rsp+0x10], xmm1
00007f4e3fddac3b  vmovaps [rsp+0x20], xmm2
00007f4e3fddac41  vmovaps [rsp+0x30], xmm3
00007f4e3fddac47  vmovaps [rsp+0x40], xmm4
00007f4e3fddac4d  vmovaps [rsp+0x50], xmm5
00007f4e3fddac53  vmovaps [rsp+0x60], xmm6
00007f4e3fddac59  vmovaps [rsp+0x70], xmm7
00007f4e3fddac5f  vmovaps [rsp+0x80], xmm8
00007f4e3fddac68  vmovaps [rsp+0x90], xmm9
00007f4e3fddac71  vmovaps [rsp+0xA0], xmm10
00007f4e3fddac7a  vmovaps [rsp+0xB0], xmm11
00007f4e3fddac83  vmovaps [rsp+0xC0], xmm13
00007f4e3fddac8c  vmovaps [rsp+0xD0], xmm14
00007f4e3fddac95  vmovaps [rsp+0xE0], xmm15
00007f4e3fddac9e  sub rsp, 0x30
00007f4e3fddaca2  movaps [rsp], xmm12
00007f4e3fddaca7  movaps [rsp+0x10], xmm14
00007f4e3fddacad  movaps [rsp+0x20], xmm1
00007f4e3fddacb2  lea rdi, [rsp]
00007f4e3fddacb6  mov esi, 0x00
00007f4e3fddacbb  mov rax, 0x5D97141E9530
00007f4e3fddacc5  call rax
00007f4e3fddacc7  movaps xmm12, [rsp]
00007f4e3fddaccc  add rsp, 0x30
00007f4e3fddacd0  vmovaps xmm0, [rsp]
00007f4e3fddacd5  vmovaps xmm1, [rsp+0x10]
00007f4e3fddacdb  vmovaps xmm2, [rsp+0x20]
00007f4e3fddace1  vmovaps xmm3, [rsp+0x30]
00007f4e3fddace7  vmovaps xmm4, [rsp+0x40]
00007f4e3fddaced  vmovaps xmm5, [rsp+0x50]
00007f4e3fddacf3  vmovaps xmm6, [rsp+0x60]
00007f4e3fddacf9  vmovaps xmm7, [rsp+0x70]
00007f4e3fddacff  vmovaps xmm8, [rsp+0x80]
00007f4e3fddad08  vmovaps xmm9, [rsp+0x90]
00007f4e3fddad11  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddad1a  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddad23  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddad2c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddad35  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddad3e  add rsp, 0xF0
00007f4e3fddad45  pop r11
00007f4e3fddad47  pop r10
00007f4e3fddad49  pop r9
00007f4e3fddad4b  pop r8
00007f4e3fddad4d  pop rsi
00007f4e3fddad4e  pop rdi
00007f4e3fddad4f  pop rdx
00007f4e3fddad50  pop rcx
00007f4e3fddad51  pop rax
00007f4e3fddad52  add rsp, 0x08
00007f4e3fddad56  jmp 0x00007F4E3FDD6549
00007f4e3fddad5b  sub rsp, 0x08
00007f4e3fddad5f  push rax
00007f4e3fddad60  push rcx
00007f4e3fddad61  push rdx
00007f4e3fddad62  push rdi
00007f4e3fddad63  push rsi
00007f4e3fddad64  push r8
00007f4e3fddad66  push r9
00007f4e3fddad68  push r10
00007f4e3fddad6a  push r11
00007f4e3fddad6c  sub rsp, 0xF0
00007f4e3fddad73  vmovaps [rsp], xmm0
00007f4e3fddad78  vmovaps [rsp+0x10], xmm1
00007f4e3fddad7e  vmovaps [rsp+0x20], xmm2
00007f4e3fddad84  vmovaps [rsp+0x30], xmm3
00007f4e3fddad8a  vmovaps [rsp+0x40], xmm4
00007f4e3fddad90  vmovaps [rsp+0x50], xmm5
00007f4e3fddad96  vmovaps [rsp+0x60], xmm6
00007f4e3fddad9c  vmovaps [rsp+0x70], xmm7
00007f4e3fddada2  vmovaps [rsp+0x80], xmm8
00007f4e3fddadab  vmovaps [rsp+0x90], xmm9
00007f4e3fddadb4  vmovaps [rsp+0xA0], xmm10
00007f4e3fddadbd  vmovaps [rsp+0xB0], xmm11
00007f4e3fddadc6  vmovaps [rsp+0xC0], xmm12
00007f4e3fddadcf  vmovaps [rsp+0xD0], xmm13
00007f4e3fddadd8  vmovaps [rsp+0xE0], xmm15
00007f4e3fddade1  sub rsp, 0x30
00007f4e3fddade5  movaps [rsp], xmm14
00007f4e3fddadea  movaps [rsp+0x10], xmm9
00007f4e3fddadf0  movaps [rsp+0x20], xmm1
00007f4e3fddadf5  lea rdi, [rsp]
00007f4e3fddadf9  mov esi, 0x00
00007f4e3fddadfe  mov rax, 0x5D97141E9530
00007f4e3fddae08  call rax
00007f4e3fddae0a  movaps xmm14, [rsp]
00007f4e3fddae0f  add rsp, 0x30
00007f4e3fddae13  vmovaps xmm0, [rsp]
00007f4e3fddae18  vmovaps xmm1, [rsp+0x10]
00007f4e3fddae1e  vmovaps xmm2, [rsp+0x20]
00007f4e3fddae24  vmovaps xmm3, [rsp+0x30]
00007f4e3fddae2a  vmovaps xmm4, [rsp+0x40]
00007f4e3fddae30  vmovaps xmm5, [rsp+0x50]
00007f4e3fddae36  vmovaps xmm6, [rsp+0x60]
00007f4e3fddae3c  vmovaps xmm7, [rsp+0x70]
00007f4e3fddae42  vmovaps xmm8, [rsp+0x80]
00007f4e3fddae4b  vmovaps xmm9, [rsp+0x90]
00007f4e3fddae54  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddae5d  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddae66  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddae6f  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddae78  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddae81  add rsp, 0xF0
00007f4e3fddae88  pop r11
00007f4e3fddae8a  pop r10
00007f4e3fddae8c  pop r9
00007f4e3fddae8e  pop r8
00007f4e3fddae90  pop rsi
00007f4e3fddae91  pop rdi
00007f4e3fddae92  pop rdx
00007f4e3fddae93  pop rcx
00007f4e3fddae94  pop rax
00007f4e3fddae95  add rsp, 0x08
00007f4e3fddae99  jmp 0x00007F4E3FDD6578
00007f4e3fddae9e  sub rsp, 0x08
00007f4e3fddaea2  push rax
00007f4e3fddaea3  push rcx
00007f4e3fddaea4  push rdx
00007f4e3fddaea5  push rdi
00007f4e3fddaea6  push rsi
00007f4e3fddaea7  push r8
00007f4e3fddaea9  push r9
00007f4e3fddaeab  push r10
00007f4e3fddaead  push r11
00007f4e3fddaeaf  sub rsp, 0xF0
00007f4e3fddaeb6  vmovaps [rsp], xmm0
00007f4e3fddaebb  vmovaps [rsp+0x10], xmm2
00007f4e3fddaec1  vmovaps [rsp+0x20], xmm3
00007f4e3fddaec7  vmovaps [rsp+0x30], xmm4
00007f4e3fddaecd  vmovaps [rsp+0x40], xmm5
00007f4e3fddaed3  vmovaps [rsp+0x50], xmm6
00007f4e3fddaed9  vmovaps [rsp+0x60], xmm7
00007f4e3fddaedf  vmovaps [rsp+0x70], xmm8
00007f4e3fddaee5  vmovaps [rsp+0x80], xmm9
00007f4e3fddaeee  vmovaps [rsp+0x90], xmm10
00007f4e3fddaef7  vmovaps [rsp+0xA0], xmm11
00007f4e3fddaf00  vmovaps [rsp+0xB0], xmm12
00007f4e3fddaf09  vmovaps [rsp+0xC0], xmm13
00007f4e3fddaf12  vmovaps [rsp+0xD0], xmm14
00007f4e3fddaf1b  vmovaps [rsp+0xE0], xmm15
00007f4e3fddaf24  sub rsp, 0x30
00007f4e3fddaf28  movaps [rsp], xmm1
00007f4e3fddaf2c  movaps [rsp+0x10], xmm13
00007f4e3fddaf32  movaps [rsp+0x20], xmm8
00007f4e3fddaf38  lea rdi, [rsp]
00007f4e3fddaf3c  mov esi, 0x00
00007f4e3fddaf41  mov rax, 0x5D97141E9530
00007f4e3fddaf4b  call rax
00007f4e3fddaf4d  movaps xmm1, [rsp]
00007f4e3fddaf51  add rsp, 0x30
00007f4e3fddaf55  vmovaps xmm0, [rsp]
00007f4e3fddaf5a  vmovaps xmm2, [rsp+0x10]
00007f4e3fddaf60  vmovaps xmm3, [rsp+0x20]
00007f4e3fddaf66  vmovaps xmm4, [rsp+0x30]
00007f4e3fddaf6c  vmovaps xmm5, [rsp+0x40]
00007f4e3fddaf72  vmovaps xmm6, [rsp+0x50]
00007f4e3fddaf78  vmovaps xmm7, [rsp+0x60]
00007f4e3fddaf7e  vmovaps xmm8, [rsp+0x70]
00007f4e3fddaf84  vmovaps xmm9, [rsp+0x80]
00007f4e3fddaf8d  vmovaps xmm10, [rsp+0x90]
00007f4e3fddaf96  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddaf9f  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddafa8  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddafb1  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddafba  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddafc3  add rsp, 0xF0
00007f4e3fddafca  pop r11
00007f4e3fddafcc  pop r10
00007f4e3fddafce  pop r9
00007f4e3fddafd0  pop r8
00007f4e3fddafd2  pop rsi
00007f4e3fddafd3  pop rdi
00007f4e3fddafd4  pop rdx
00007f4e3fddafd5  pop rcx
00007f4e3fddafd6  pop rax
00007f4e3fddafd7  add rsp, 0x08
00007f4e3fddafdb  jmp 0x00007F4E3FDD659A
00007f4e3fddafe0  call 0x00007F4E3FC0C260
00007f4e3fddafe5  jmp 0x00007F4E3FDD65A8
00007f4e3fddafea  call 0x00007F4E3FCDE950
00007f4e3fddafef  jmp 0x00007F4E3FDD65B2
00007f4e3fddaff4  sub rsp, 0x08
00007f4e3fddaff8  push rax
00007f4e3fddaff9  push rcx
00007f4e3fddaffa  push rdx
00007f4e3fddaffb  push rdi
00007f4e3fddaffc  push rsi
00007f4e3fddaffd  push r8
00007f4e3fddafff  push r9
00007f4e3fddb001  push r10
00007f4e3fddb003  push r11
00007f4e3fddb005  sub rsp, 0xF0
00007f4e3fddb00c  vmovaps [rsp], xmm0
00007f4e3fddb011  vmovaps [rsp+0x10], xmm1
00007f4e3fddb017  vmovaps [rsp+0x20], xmm2
00007f4e3fddb01d  vmovaps [rsp+0x30], xmm3
00007f4e3fddb023  vmovaps [rsp+0x40], xmm4
00007f4e3fddb029  vmovaps [rsp+0x50], xmm5
00007f4e3fddb02f  vmovaps [rsp+0x60], xmm6
00007f4e3fddb035  vmovaps [rsp+0x70], xmm7
00007f4e3fddb03b  vmovaps [rsp+0x80], xmm9
00007f4e3fddb044  vmovaps [rsp+0x90], xmm10
00007f4e3fddb04d  vmovaps [rsp+0xA0], xmm11
00007f4e3fddb056  vmovaps [rsp+0xB0], xmm12
00007f4e3fddb05f  vmovaps [rsp+0xC0], xmm13
00007f4e3fddb068  vmovaps [rsp+0xD0], xmm14
00007f4e3fddb071  vmovaps [rsp+0xE0], xmm15
00007f4e3fddb07a  sub rsp, 0x30
00007f4e3fddb07e  movaps [rsp], xmm8
00007f4e3fddb083  movaps [rsp+0x10], xmm15
00007f4e3fddb089  movaps [rsp+0x20], xmm7
00007f4e3fddb08e  lea rdi, [rsp]
00007f4e3fddb092  mov esi, 0x00
00007f4e3fddb097  mov rax, 0x5D97141E9530
00007f4e3fddb0a1  call rax
00007f4e3fddb0a3  movaps xmm8, [rsp]
00007f4e3fddb0a8  add rsp, 0x30
00007f4e3fddb0ac  vmovaps xmm0, [rsp]
00007f4e3fddb0b1  vmovaps xmm1, [rsp+0x10]
00007f4e3fddb0b7  vmovaps xmm2, [rsp+0x20]
00007f4e3fddb0bd  vmovaps xmm3, [rsp+0x30]
00007f4e3fddb0c3  vmovaps xmm4, [rsp+0x40]
00007f4e3fddb0c9  vmovaps xmm5, [rsp+0x50]
00007f4e3fddb0cf  vmovaps xmm6, [rsp+0x60]
00007f4e3fddb0d5  vmovaps xmm7, [rsp+0x70]
00007f4e3fddb0db  vmovaps xmm9, [rsp+0x80]
00007f4e3fddb0e4  vmovaps xmm10, [rsp+0x90]
00007f4e3fddb0ed  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddb0f6  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddb0ff  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddb108  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddb111  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddb11a  add rsp, 0xF0
00007f4e3fddb121  pop r11
00007f4e3fddb123  pop r10
00007f4e3fddb125  pop r9
00007f4e3fddb127  pop r8
00007f4e3fddb129  pop rsi
00007f4e3fddb12a  pop rdi
00007f4e3fddb12b  pop rdx
00007f4e3fddb12c  pop rcx
00007f4e3fddb12d  pop rax
00007f4e3fddb12e  add rsp, 0x08
00007f4e3fddb132  jmp 0x00007F4E3FDD65D4
00007f4e3fddb137  sub rsp, 0x08
00007f4e3fddb13b  push rax
00007f4e3fddb13c  push rcx
00007f4e3fddb13d  push rdx
00007f4e3fddb13e  push rdi
00007f4e3fddb13f  push rsi
00007f4e3fddb140  push r8
00007f4e3fddb142  push r9
00007f4e3fddb144  push r10
00007f4e3fddb146  push r11
00007f4e3fddb148  sub rsp, 0xF0
00007f4e3fddb14f  vmovaps [rsp], xmm0
00007f4e3fddb154  vmovaps [rsp+0x10], xmm1
00007f4e3fddb15a  vmovaps [rsp+0x20], xmm2
00007f4e3fddb160  vmovaps [rsp+0x30], xmm3
00007f4e3fddb166  vmovaps [rsp+0x40], xmm4
00007f4e3fddb16c  vmovaps [rsp+0x50], xmm5
00007f4e3fddb172  vmovaps [rsp+0x60], xmm6
00007f4e3fddb178  vmovaps [rsp+0x70], xmm8
00007f4e3fddb17e  vmovaps [rsp+0x80], xmm9
00007f4e3fddb187  vmovaps [rsp+0x90], xmm10
00007f4e3fddb190  vmovaps [rsp+0xA0], xmm11
00007f4e3fddb199  vmovaps [rsp+0xB0], xmm12
00007f4e3fddb1a2  vmovaps [rsp+0xC0], xmm13
00007f4e3fddb1ab  vmovaps [rsp+0xD0], xmm14
00007f4e3fddb1b4  vmovaps [rsp+0xE0], xmm15
00007f4e3fddb1bd  sub rsp, 0x30
00007f4e3fddb1c1  movaps [rsp], xmm7
00007f4e3fddb1c5  movaps [rsp+0x10], xmm9
00007f4e3fddb1cb  movaps [rsp+0x20], xmm15
00007f4e3fddb1d1  lea rdi, [rsp]
00007f4e3fddb1d5  mov esi, 0x00
00007f4e3fddb1da  mov rax, 0x5D97141E9530
00007f4e3fddb1e4  call rax
00007f4e3fddb1e6  movaps xmm7, [rsp]
00007f4e3fddb1ea  add rsp, 0x30
00007f4e3fddb1ee  vmovaps xmm0, [rsp]
00007f4e3fddb1f3  vmovaps xmm1, [rsp+0x10]
00007f4e3fddb1f9  vmovaps xmm2, [rsp+0x20]
00007f4e3fddb1ff  vmovaps xmm3, [rsp+0x30]
00007f4e3fddb205  vmovaps xmm4, [rsp+0x40]
00007f4e3fddb20b  vmovaps xmm5, [rsp+0x50]
00007f4e3fddb211  vmovaps xmm6, [rsp+0x60]
00007f4e3fddb217  vmovaps xmm8, [rsp+0x70]
00007f4e3fddb21d  vmovaps xmm9, [rsp+0x80]
00007f4e3fddb226  vmovaps xmm10, [rsp+0x90]
00007f4e3fddb22f  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddb238  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddb241  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddb24a  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddb253  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddb25c  add rsp, 0xF0
00007f4e3fddb263  pop r11
00007f4e3fddb265  pop r10
00007f4e3fddb267  pop r9
00007f4e3fddb269  pop r8
00007f4e3fddb26b  pop rsi
00007f4e3fddb26c  pop rdi
00007f4e3fddb26d  pop rdx
00007f4e3fddb26e  pop rcx
00007f4e3fddb26f  pop rax
00007f4e3fddb270  add rsp, 0x08
00007f4e3fddb274  jmp 0x00007F4E3FDD6601
00007f4e3fddb279  sub rsp, 0x08
00007f4e3fddb27d  push rax
00007f4e3fddb27e  push rcx
00007f4e3fddb27f  push rdx
00007f4e3fddb280  push rdi
00007f4e3fddb281  push rsi
00007f4e3fddb282  push r8
00007f4e3fddb284  push r9
00007f4e3fddb286  push r10
00007f4e3fddb288  push r11
00007f4e3fddb28a  sub rsp, 0xF0
00007f4e3fddb291  vmovaps [rsp], xmm0
00007f4e3fddb296  vmovaps [rsp+0x10], xmm1
00007f4e3fddb29c  vmovaps [rsp+0x20], xmm2
00007f4e3fddb2a2  vmovaps [rsp+0x30], xmm3
00007f4e3fddb2a8  vmovaps [rsp+0x40], xmm4
00007f4e3fddb2ae  vmovaps [rsp+0x50], xmm5
00007f4e3fddb2b4  vmovaps [rsp+0x60], xmm6
00007f4e3fddb2ba  vmovaps [rsp+0x70], xmm7
00007f4e3fddb2c0  vmovaps [rsp+0x80], xmm8
00007f4e3fddb2c9  vmovaps [rsp+0x90], xmm10
00007f4e3fddb2d2  vmovaps [rsp+0xA0], xmm11
00007f4e3fddb2db  vmovaps [rsp+0xB0], xmm12
00007f4e3fddb2e4  vmovaps [rsp+0xC0], xmm13
00007f4e3fddb2ed  vmovaps [rsp+0xD0], xmm14
00007f4e3fddb2f6  vmovaps [rsp+0xE0], xmm15
00007f4e3fddb2ff  sub rsp, 0x30
00007f4e3fddb303  movaps [rsp], xmm9
00007f4e3fddb308  movaps [rsp+0x10], xmm13
00007f4e3fddb30e  movaps [rsp+0x20], xmm15
00007f4e3fddb314  lea rdi, [rsp]
00007f4e3fddb318  mov esi, 0x00
00007f4e3fddb31d  mov rax, 0x5D97141E9530
00007f4e3fddb327  call rax
00007f4e3fddb329  movaps xmm9, [rsp]
00007f4e3fddb32e  add rsp, 0x30
00007f4e3fddb332  vmovaps xmm0, [rsp]
00007f4e3fddb337  vmovaps xmm1, [rsp+0x10]
00007f4e3fddb33d  vmovaps xmm2, [rsp+0x20]
00007f4e3fddb343  vmovaps xmm3, [rsp+0x30]
00007f4e3fddb349  vmovaps xmm4, [rsp+0x40]
00007f4e3fddb34f  vmovaps xmm5, [rsp+0x50]
00007f4e3fddb355  vmovaps xmm6, [rsp+0x60]
00007f4e3fddb35b  vmovaps xmm7, [rsp+0x70]
00007f4e3fddb361  vmovaps xmm8, [rsp+0x80]
00007f4e3fddb36a  vmovaps xmm10, [rsp+0x90]
00007f4e3fddb373  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddb37c  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddb385  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddb38e  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddb397  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddb3a0  add rsp, 0xF0
00007f4e3fddb3a7  pop r11
00007f4e3fddb3a9  pop r10
00007f4e3fddb3ab  pop r9
00007f4e3fddb3ad  pop r8
00007f4e3fddb3af  pop rsi
00007f4e3fddb3b0  pop rdi
00007f4e3fddb3b1  pop rdx
00007f4e3fddb3b2  pop rcx
00007f4e3fddb3b3  pop rax
00007f4e3fddb3b4  add rsp, 0x08
00007f4e3fddb3b8  jmp 0x00007F4E3FDD662F
00007f4e3fddb3bd  sub rsp, 0x08
00007f4e3fddb3c1  push rax
00007f4e3fddb3c2  push rcx
00007f4e3fddb3c3  push rdx
00007f4e3fddb3c4  push rdi
00007f4e3fddb3c5  push rsi
00007f4e3fddb3c6  push r8
00007f4e3fddb3c8  push r9
00007f4e3fddb3ca  push r10
00007f4e3fddb3cc  push r11
00007f4e3fddb3ce  sub rsp, 0xF0
00007f4e3fddb3d5  vmovaps [rsp], xmm0
00007f4e3fddb3da  vmovaps [rsp+0x10], xmm1
00007f4e3fddb3e0  vmovaps [rsp+0x20], xmm2
00007f4e3fddb3e6  vmovaps [rsp+0x30], xmm3
00007f4e3fddb3ec  vmovaps [rsp+0x40], xmm4
00007f4e3fddb3f2  vmovaps [rsp+0x50], xmm5
00007f4e3fddb3f8  vmovaps [rsp+0x60], xmm6
00007f4e3fddb3fe  vmovaps [rsp+0x70], xmm7
00007f4e3fddb404  vmovaps [rsp+0x80], xmm8
00007f4e3fddb40d  vmovaps [rsp+0x90], xmm9
00007f4e3fddb416  vmovaps [rsp+0xA0], xmm10
00007f4e3fddb41f  vmovaps [rsp+0xB0], xmm11
00007f4e3fddb428  vmovaps [rsp+0xC0], xmm12
00007f4e3fddb431  vmovaps [rsp+0xD0], xmm13
00007f4e3fddb43a  vmovaps [rsp+0xE0], xmm14
00007f4e3fddb443  sub rsp, 0x30
00007f4e3fddb447  movaps [rsp], xmm15
00007f4e3fddb44c  movaps [rsp+0x10], xmm11
00007f4e3fddb452  movaps [rsp+0x20], xmm12
00007f4e3fddb458  lea rdi, [rsp]
00007f4e3fddb45c  mov esi, 0x00
00007f4e3fddb461  mov rax, 0x5D97141E9530
00007f4e3fddb46b  call rax
00007f4e3fddb46d  movaps xmm15, [rsp]
00007f4e3fddb472  add rsp, 0x30
00007f4e3fddb476  vmovaps xmm0, [rsp]
00007f4e3fddb47b  vmovaps xmm1, [rsp+0x10]
00007f4e3fddb481  vmovaps xmm2, [rsp+0x20]
00007f4e3fddb487  vmovaps xmm3, [rsp+0x30]
00007f4e3fddb48d  vmovaps xmm4, [rsp+0x40]
00007f4e3fddb493  vmovaps xmm5, [rsp+0x50]
00007f4e3fddb499  vmovaps xmm6, [rsp+0x60]
00007f4e3fddb49f  vmovaps xmm7, [rsp+0x70]
00007f4e3fddb4a5  vmovaps xmm8, [rsp+0x80]
00007f4e3fddb4ae  vmovaps xmm9, [rsp+0x90]
00007f4e3fddb4b7  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddb4c0  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddb4c9  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddb4d2  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddb4db  vmovaps xmm14, [rsp+0xE0]
00007f4e3fddb4e4  add rsp, 0xF0
00007f4e3fddb4eb  pop r11
00007f4e3fddb4ed  pop r10
00007f4e3fddb4ef  pop r9
00007f4e3fddb4f1  pop r8
00007f4e3fddb4f3  pop rsi
00007f4e3fddb4f4  pop rdi
00007f4e3fddb4f5  pop rdx
00007f4e3fddb4f6  pop rcx
00007f4e3fddb4f7  pop rax
00007f4e3fddb4f8  add rsp, 0x08
00007f4e3fddb4fc  jmp 0x00007F4E3FDD664A
00007f4e3fddb501  sub rsp, 0x08
00007f4e3fddb505  push rax
00007f4e3fddb506  push rcx
00007f4e3fddb507  push rdx
00007f4e3fddb508  push rdi
00007f4e3fddb509  push rsi
00007f4e3fddb50a  push r8
00007f4e3fddb50c  push r9
00007f4e3fddb50e  push r10
00007f4e3fddb510  push r11
00007f4e3fddb512  sub rsp, 0xF0
00007f4e3fddb519  vmovaps [rsp], xmm0
00007f4e3fddb51e  vmovaps [rsp+0x10], xmm1
00007f4e3fddb524  vmovaps [rsp+0x20], xmm2
00007f4e3fddb52a  vmovaps [rsp+0x30], xmm3
00007f4e3fddb530  vmovaps [rsp+0x40], xmm4
00007f4e3fddb536  vmovaps [rsp+0x50], xmm5
00007f4e3fddb53c  vmovaps [rsp+0x60], xmm6
00007f4e3fddb542  vmovaps [rsp+0x70], xmm7
00007f4e3fddb548  vmovaps [rsp+0x80], xmm8
00007f4e3fddb551  vmovaps [rsp+0x90], xmm9
00007f4e3fddb55a  vmovaps [rsp+0xA0], xmm10
00007f4e3fddb563  vmovaps [rsp+0xB0], xmm11
00007f4e3fddb56c  vmovaps [rsp+0xC0], xmm12
00007f4e3fddb575  vmovaps [rsp+0xD0], xmm14
00007f4e3fddb57e  vmovaps [rsp+0xE0], xmm15
00007f4e3fddb587  sub rsp, 0x30
00007f4e3fddb58b  movaps [rsp], xmm13
00007f4e3fddb590  movaps [rsp+0x10], xmm10
00007f4e3fddb596  movaps [rsp+0x20], xmm14
00007f4e3fddb59c  lea rdi, [rsp]
00007f4e3fddb5a0  mov esi, 0x00
00007f4e3fddb5a5  mov rax, 0x5D97141E9530
00007f4e3fddb5af  call rax
00007f4e3fddb5b1  movaps xmm13, [rsp]
00007f4e3fddb5b6  add rsp, 0x30
00007f4e3fddb5ba  vmovaps xmm0, [rsp]
00007f4e3fddb5bf  vmovaps xmm1, [rsp+0x10]
00007f4e3fddb5c5  vmovaps xmm2, [rsp+0x20]
00007f4e3fddb5cb  vmovaps xmm3, [rsp+0x30]
00007f4e3fddb5d1  vmovaps xmm4, [rsp+0x40]
00007f4e3fddb5d7  vmovaps xmm5, [rsp+0x50]
00007f4e3fddb5dd  vmovaps xmm6, [rsp+0x60]
00007f4e3fddb5e3  vmovaps xmm7, [rsp+0x70]
00007f4e3fddb5e9  vmovaps xmm8, [rsp+0x80]
00007f4e3fddb5f2  vmovaps xmm9, [rsp+0x90]
00007f4e3fddb5fb  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddb604  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddb60d  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddb616  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddb61f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddb628  add rsp, 0xF0
00007f4e3fddb62f  pop r11
00007f4e3fddb631  pop r10
00007f4e3fddb633  pop r9
00007f4e3fddb635  pop r8
00007f4e3fddb637  pop rsi
00007f4e3fddb638  pop rdi
00007f4e3fddb639  pop rdx
00007f4e3fddb63a  pop rcx
00007f4e3fddb63b  pop rax
00007f4e3fddb63c  add rsp, 0x08
00007f4e3fddb640  jmp 0x00007F4E3FDD666D
00007f4e3fddb645  sub rsp, 0x08
00007f4e3fddb649  push rax
00007f4e3fddb64a  push rcx
00007f4e3fddb64b  push rdx
00007f4e3fddb64c  push rdi
00007f4e3fddb64d  push rsi
00007f4e3fddb64e  push r8
00007f4e3fddb650  push r9
00007f4e3fddb652  push r10
00007f4e3fddb654  push r11
00007f4e3fddb656  sub rsp, 0xF0
00007f4e3fddb65d  vmovaps [rsp], xmm0
00007f4e3fddb662  vmovaps [rsp+0x10], xmm1
00007f4e3fddb668  vmovaps [rsp+0x20], xmm2
00007f4e3fddb66e  vmovaps [rsp+0x30], xmm3
00007f4e3fddb674  vmovaps [rsp+0x40], xmm4
00007f4e3fddb67a  vmovaps [rsp+0x50], xmm5
00007f4e3fddb680  vmovaps [rsp+0x60], xmm6
00007f4e3fddb686  vmovaps [rsp+0x70], xmm7
00007f4e3fddb68c  vmovaps [rsp+0x80], xmm8
00007f4e3fddb695  vmovaps [rsp+0x90], xmm9
00007f4e3fddb69e  vmovaps [rsp+0xA0], xmm10
00007f4e3fddb6a7  vmovaps [rsp+0xB0], xmm11
00007f4e3fddb6b0  vmovaps [rsp+0xC0], xmm12
00007f4e3fddb6b9  vmovaps [rsp+0xD0], xmm13
00007f4e3fddb6c2  vmovaps [rsp+0xE0], xmm15
00007f4e3fddb6cb  sub rsp, 0x30
00007f4e3fddb6cf  movaps [rsp], xmm14
00007f4e3fddb6d4  movaps [rsp+0x10], xmm1
00007f4e3fddb6d9  movaps [rsp+0x20], xmm7
00007f4e3fddb6de  lea rdi, [rsp]
00007f4e3fddb6e2  mov esi, 0x00
00007f4e3fddb6e7  mov rax, 0x5D97141E9530
00007f4e3fddb6f1  call rax
00007f4e3fddb6f3  movaps xmm14, [rsp]
00007f4e3fddb6f8  add rsp, 0x30
00007f4e3fddb6fc  vmovaps xmm0, [rsp]
00007f4e3fddb701  vmovaps xmm1, [rsp+0x10]
00007f4e3fddb707  vmovaps xmm2, [rsp+0x20]
00007f4e3fddb70d  vmovaps xmm3, [rsp+0x30]
00007f4e3fddb713  vmovaps xmm4, [rsp+0x40]
00007f4e3fddb719  vmovaps xmm5, [rsp+0x50]
00007f4e3fddb71f  vmovaps xmm6, [rsp+0x60]
00007f4e3fddb725  vmovaps xmm7, [rsp+0x70]
00007f4e3fddb72b  vmovaps xmm8, [rsp+0x80]
00007f4e3fddb734  vmovaps xmm9, [rsp+0x90]
00007f4e3fddb73d  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddb746  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddb74f  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddb758  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddb761  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddb76a  add rsp, 0xF0
00007f4e3fddb771  pop r11
00007f4e3fddb773  pop r10
00007f4e3fddb775  pop r9
00007f4e3fddb777  pop r8
00007f4e3fddb779  pop rsi
00007f4e3fddb77a  pop rdi
00007f4e3fddb77b  pop rdx
00007f4e3fddb77c  pop rcx
00007f4e3fddb77d  pop rax
00007f4e3fddb77e  add rsp, 0x08
00007f4e3fddb782  jmp 0x00007F4E3FDD6690
00007f4e3fddb787  sub rsp, 0x08
00007f4e3fddb78b  push rax
00007f4e3fddb78c  push rcx
00007f4e3fddb78d  push rdx
00007f4e3fddb78e  push rdi
00007f4e3fddb78f  push rsi
00007f4e3fddb790  push r8
00007f4e3fddb792  push r9
00007f4e3fddb794  push r10
00007f4e3fddb796  push r11
00007f4e3fddb798  sub rsp, 0xF0
00007f4e3fddb79f  vmovaps [rsp], xmm0
00007f4e3fddb7a4  vmovaps [rsp+0x10], xmm2
00007f4e3fddb7aa  vmovaps [rsp+0x20], xmm3
00007f4e3fddb7b0  vmovaps [rsp+0x30], xmm4
00007f4e3fddb7b6  vmovaps [rsp+0x40], xmm5
00007f4e3fddb7bc  vmovaps [rsp+0x50], xmm6
00007f4e3fddb7c2  vmovaps [rsp+0x60], xmm7
00007f4e3fddb7c8  vmovaps [rsp+0x70], xmm8
00007f4e3fddb7ce  vmovaps [rsp+0x80], xmm9
00007f4e3fddb7d7  vmovaps [rsp+0x90], xmm10
00007f4e3fddb7e0  vmovaps [rsp+0xA0], xmm11
00007f4e3fddb7e9  vmovaps [rsp+0xB0], xmm12
00007f4e3fddb7f2  vmovaps [rsp+0xC0], xmm13
00007f4e3fddb7fb  vmovaps [rsp+0xD0], xmm14
00007f4e3fddb804  vmovaps [rsp+0xE0], xmm15
00007f4e3fddb80d  sub rsp, 0x30
00007f4e3fddb811  movaps [rsp], xmm1
00007f4e3fddb815  movaps [rsp+0x10], xmm8
00007f4e3fddb81b  movaps [rsp+0x20], xmm9
00007f4e3fddb821  lea rdi, [rsp]
00007f4e3fddb825  mov esi, 0x00
00007f4e3fddb82a  mov rax, 0x5D97141E9530
00007f4e3fddb834  call rax
00007f4e3fddb836  movaps xmm1, [rsp]
00007f4e3fddb83a  add rsp, 0x30
00007f4e3fddb83e  vmovaps xmm0, [rsp]
00007f4e3fddb843  vmovaps xmm2, [rsp+0x10]
00007f4e3fddb849  vmovaps xmm3, [rsp+0x20]
00007f4e3fddb84f  vmovaps xmm4, [rsp+0x30]
00007f4e3fddb855  vmovaps xmm5, [rsp+0x40]
00007f4e3fddb85b  vmovaps xmm6, [rsp+0x50]
00007f4e3fddb861  vmovaps xmm7, [rsp+0x60]
00007f4e3fddb867  vmovaps xmm8, [rsp+0x70]
00007f4e3fddb86d  vmovaps xmm9, [rsp+0x80]
00007f4e3fddb876  vmovaps xmm10, [rsp+0x90]
00007f4e3fddb87f  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddb888  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddb891  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddb89a  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddb8a3  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddb8ac  add rsp, 0xF0
00007f4e3fddb8b3  pop r11
00007f4e3fddb8b5  pop r10
00007f4e3fddb8b7  pop r9
00007f4e3fddb8b9  pop r8
00007f4e3fddb8bb  pop rsi
00007f4e3fddb8bc  pop rdi
00007f4e3fddb8bd  pop rdx
00007f4e3fddb8be  pop rcx
00007f4e3fddb8bf  pop rax
00007f4e3fddb8c0  add rsp, 0x08
00007f4e3fddb8c4  jmp 0x00007F4E3FDD66B2
00007f4e3fddb8c9  call 0x00007F4E3FCB3E40
00007f4e3fddb8ce  jmp 0x00007F4E3FDD66C0
00007f4e3fddb8d3  call 0x00007F4E3FC0C380
00007f4e3fddb8d8  jmp 0x00007F4E3FDD66CA
00007f4e3fddb8dd  call 0x00007F4E3FC0D600
00007f4e3fddb8e2  jmp 0x00007F4E3FDD66D4
00007f4e3fddb8e7  call 0x00007F4E3FBFF540
00007f4e3fddb8ec  jmp 0x00007F4E3FDD66DE
00007f4e3fddb8f1  int3
00007f4e3fddb8f2  nop [rax+rax*1], ax
00007f4e3fddb8fb  nop [rax+rax*1], eax
00007f4e3fddb900  mov eax, [r15+0x48]
00007f4e3fddb904  lea r14d, [eax+0x01]
00007f4e3fddb909  mov [rsp+0x10], r14d
00007f4e3fddb90e  mov r14d, r14d
00007f4e3fddb911  mov [r15+0x48], r14
00007f4e3fddb915  xor eax, eax
00007f4e3fddb917  mov r14d, [rsp+0x10]
00007f4e3fddb91c  cmp r14d, 0x1F4
00007f4e3fddb923  cmc
00007f4e3fddb924  lahf
00007f4e3fddb925  seto al
00007f4e3fddb928  mov [r15+0x108], eax
00007f4e3fddb92f  mov eax, [r15+0x108]
00007f4e3fddb936  sahf
00007f4e3fddb937  jnz 0x00007F4E3FDDB969
00007f4e3fddb939  cmp dword ptr [r15+0x318], 0x00
00007f4e3fddb941  jz 0x00007F4E3FDE1AB0
00007f4e3fddb947  nop [rax+rax*1], ax
00007f4e3fddb950  nop [rax+rax*1], eax
00007f4e3fddb958  mov eax, 0x410450
00007f4e3fddb95d  mov [r15+0x100], rax
00007f4e3fddb964  jmp 0x00007F4E3FBFE110
00007f4e3fddb969  cmp dword ptr [r15+0x318], 0x00
00007f4e3fddb971  jz 0x00007F4E3FDDB9A0
00007f4e3fddb977  nop [rax+rax*1], ax
00007f4e3fddb980  nop [rax+rax*1], eax
00007f4e3fddb988  mov eax, 0x410274
00007f4e3fddb98d  mov [r15+0x100], rax
00007f4e3fddb994  jmp 0x00007F4E3FBFE110
00007f4e3fddb999  int3
00007f4e3fddb99a  int3
00007f4e3fddb99b  nop [rax+rax*1], eax
00007f4e3fddb9a0  mov rax, [r15+0x40]
00007f4e3fddb9a4  movaps xmm1, [r15+0x1D0]
00007f4e3fddb9ac  vmovaps [rsp+0x10], xmm1
00007f4e3fddb9b2  vmovaps xmm15, [rsp+0x10]
00007f4e3fddb9b8  por xmm1, xmm15
00007f4e3fddb9bd  movaps xmm14, [r15+0x1A0]
00007f4e3fddb9c5  vmovaps [rsp+0x10], xmm14
00007f4e3fddb9cb  vmovaps xmm13, [rsp+0x10]
00007f4e3fddb9d1  por xmm14, xmm13
00007f4e3fddb9d6  lea r14, [rax+0x30]
00007f4e3fddb9da  mov r12, [r13+r14*1]
00007f4e3fddb9df  lea r14, [rax+0x38]
00007f4e3fddb9e3  mov r11, [r13+r14*1]
00007f4e3fddb9e8  movq xmm13, r12
00007f4e3fddb9ed  movq xmm12, r11
00007f4e3fddb9f2  movq xmm13, xmm13
00007f4e3fddb9f7  vmovaps [rsp+0x10], xmm13
00007f4e3fddb9fd  movq xmm13, xmm13
00007f4e3fddba02  movaps [r15+0x130], xmm13
00007f4e3fddba0a  movq xmm12, xmm12
00007f4e3fddba0f  vmovaps [rsp+0x20], xmm12
00007f4e3fddba15  movq xmm12, xmm12
00007f4e3fddba1a  movaps [r15+0x280], xmm12
00007f4e3fddba22  movaps xmm13, [r15+0x270]
00007f4e3fddba2a  vmovaps [rsp+0x30], xmm13
00007f4e3fddba30  vmovaps xmm12, [rsp+0x30]
00007f4e3fddba36  por xmm13, xmm12
00007f4e3fddba3b  lea r14, [rax+0x20]
00007f4e3fddba3f  mov r12, [r13+r14*1]
00007f4e3fddba44  lea r14, [rax+0x28]
00007f4e3fddba48  mov r11, [r13+r14*1]
00007f4e3fddba4d  movq xmm12, r12
00007f4e3fddba52  movq xmm11, r11
00007f4e3fddba57  movq xmm12, xmm12
00007f4e3fddba5c  vmovaps [rsp+0x30], xmm12
00007f4e3fddba62  movq xmm12, xmm12
00007f4e3fddba67  movaps [r15+0x150], xmm12
00007f4e3fddba6f  movq xmm11, xmm11
00007f4e3fddba74  vmovaps [rsp+0x40], xmm11
00007f4e3fddba7a  movq xmm11, xmm11
00007f4e3fddba7f  movaps [r15+0x140], xmm11
00007f4e3fddba87  lea r14, [rax+0x10]
00007f4e3fddba8b  mov r12, [r13+r14*1]
00007f4e3fddba90  lea r14, [rax+0x18]
00007f4e3fddba94  mov r11, [r13+r14*1]
00007f4e3fddba99  movq xmm12, r12
00007f4e3fddba9e  movq xmm11, r11
00007f4e3fddbaa3  movq xmm12, xmm12
00007f4e3fddbaa8  vmovaps [rsp+0x50], xmm12
00007f4e3fddbaae  movq xmm12, xmm12
00007f4e3fddbab3  movaps [r15+0x170], xmm12
00007f4e3fddbabb  movq xmm11, xmm11
00007f4e3fddbac0  vmovaps [rsp+0x60], xmm11
00007f4e3fddbac6  movq xmm11, xmm11
00007f4e3fddbacb  movaps [r15+0x160], xmm11
00007f4e3fddbad3  mov r14, [r13+rax*1]
00007f4e3fddbad8  vmovq xmm12, r14
00007f4e3fddbadd  vpbroadcastq xmm12, xmm12
00007f4e3fddbae2  lea r14, [rax+0x08]
00007f4e3fddbae6  mov rax, [r13+r14*1]
00007f4e3fddbaeb  movq xmm11, rax
00007f4e3fddbaf0  movaps [r15+0x230], xmm11
00007f4e3fddbaf8  mov rax, [r15+0xF8]
00007f4e3fddbaff  lea r14, [rax+0x50]
00007f4e3fddbb03  movups xmm11, [r13+r14*1]
00007f4e3fddbb09  lea r14, [rax+0x60]
00007f4e3fddbb0d  movups xmm10, [r13+r14*1]
00007f4e3fddbb13  lea r14, [rax+0x30]
00007f4e3fddbb17  movups xmm9, [r13+r14*1]
00007f4e3fddbb1d  mov r14, [r15+0x50]
00007f4e3fddbb21  mov [r15+0x60], r14
00007f4e3fddbb25  mov qword ptr [r15+0x58], 0x40
00007f4e3fddbb2d  movaps xmm8, xmm12
00007f4e3fddbb31  mulpd xmm8, xmm15
00007f4e3fddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f4e3fddbb3c  ptest xmm7, xmm7
00007f4e3fddbb41  jnz 0x00007F4E3FDDC96A
00007f4e3fddbb47  movq xmm15, qword ptr [r15+0x230]
00007f4e3fddbb50  vmovaps [rsp+0x70], xmm15
00007f4e3fddbb56  vpermilpd xmm15, xmm15, 0x00
00007f4e3fddbb5c  movaps xmm7, xmm9
00007f4e3fddbb60  mulpd xmm7, xmm15
00007f4e3fddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4e3fddbb6a  ptest xmm6, xmm6
00007f4e3fddbb6f  jnz 0x00007F4E3FDDCAAE
00007f4e3fddbb75  vxorps xmm15, xmm15, xmm15
00007f4e3fddbb7a  vpbroadcastq xmm15, xmm15
00007f4e3fddbb7f  movaps xmm9, xmm12
00007f4e3fddbb83  mulpd xmm9, xmm10
00007f4e3fddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f4e3fddbb8e  ptest xmm6, xmm6
00007f4e3fddbb93  jnz 0x00007F4E3FDDCBF0
00007f4e3fddbb99  movaps xmm10, xmm12
00007f4e3fddbb9d  mulpd xmm10, xmm11
00007f4e3fddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f4e3fddbba8  ptest xmm6, xmm6
00007f4e3fddbbad  jnz 0x00007F4E3FDDCD34
00007f4e3fddbbb3  movaps xmm11, [r15+0x1F0]
00007f4e3fddbbbb  movaps xmm6, xmm12
00007f4e3fddbbbf  mulpd xmm6, xmm11
00007f4e3fddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f4e3fddbbc9  ptest xmm5, xmm5
00007f4e3fddbbce  jnz 0x00007F4E3FDDCE78
00007f4e3fddbbd4  movaps xmm12, [r15+0x2A0]
00007f4e3fddbbdc  vmovaps [rsp+0x80], xmm12
00007f4e3fddbbe5  vmovaps xmm11, [rsp+0x80]
00007f4e3fddbbee  por xmm12, xmm11
00007f4e3fddbbf3  movaps xmm11, [r15+0x250]
00007f4e3fddbbfb  vmovaps [rsp+0x80], xmm11
00007f4e3fddbc04  vmovaps xmm5, [rsp+0x80]
00007f4e3fddbc0d  por xmm11, xmm5
00007f4e3fddbc12  vmovaps xmm4, [rsp+0x70]
00007f4e3fddbc18  vpermilpd xmm4, xmm4, 0x00
00007f4e3fddbc1e  movaps xmm3, xmm5
00007f4e3fddbc21  mulpd xmm3, xmm4
00007f4e3fddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f4e3fddbc2a  ptest xmm2, xmm2
00007f4e3fddbc2f  jnz 0x00007F4E3FDDCFBA
00007f4e3fddbc35  mov [rsp+0x80], rax
00007f4e3fddbc3d  xor eax, eax
00007f4e3fddbc3f  mov r12d, 0x40
00007f4e3fddbc45  mov r11d, 0x200
00007f4e3fddbc4b  cmp r12, r11
00007f4e3fddbc4e  cmc
00007f4e3fddbc4f  lahf
00007f4e3fddbc50  seto al
00007f4e3fddbc53  mov [r15+0x108], eax
00007f4e3fddbc5a  movaps xmm5, xmm8
00007f4e3fddbc5e  addpd xmm5, xmm15
00007f4e3fddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f4e3fddbc68  ptest xmm4, xmm4
00007f4e3fddbc6d  jnz 0x00007F4E3FDDD0FA
00007f4e3fddbc73  movaps xmm8, [r15+0x1B0]
00007f4e3fddbc7b  movaps xmm4, xmm9
00007f4e3fddbc7f  addpd xmm4, xmm8
00007f4e3fddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f4e3fddbc89  ptest xmm2, xmm2
00007f4e3fddbc8e  jnz 0x00007F4E3FDDD23C
00007f4e3fddbc94  movaps xmm9, xmm10
00007f4e3fddbc98  addpd xmm9, xmm8
00007f4e3fddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f4e3fddbca3  ptest xmm2, xmm2
00007f4e3fddbca8  jnz 0x00007F4E3FDDD37E
00007f4e3fddbcae  movaps xmm10, [r15+0x2F0]
00007f4e3fddbcb6  vmovaps [rsp+0x90], xmm10
00007f4e3fddbcbf  vmovaps xmm8, [rsp+0x90]
00007f4e3fddbcc8  por xmm10, xmm8
00007f4e3fddbccd  movaps xmm8, [r15+0x2E0]
00007f4e3fddbcd5  vmovaps [rsp+0x90], xmm8
00007f4e3fddbcde  vmovaps xmm2, [rsp+0x90]
00007f4e3fddbce7  por xmm8, xmm2
00007f4e3fddbcec  movaps xmm2, [r15+0x2D0]
00007f4e3fddbcf4  vmovaps [rsp+0x90], xmm2
00007f4e3fddbcfd  vmovaps [rsp+0xA0], xmm1
00007f4e3fddbd06  vmovaps xmm1, [rsp+0x90]
00007f4e3fddbd0f  por xmm2, xmm1
00007f4e3fddbd13  movaps xmm1, [r15+0x200]
00007f4e3fddbd1b  vmovaps [rsp+0x90], xmm1
00007f4e3fddbd24  vmovaps [rsp+0xB0], xmm15
00007f4e3fddbd2d  vmovaps xmm15, [rsp+0x90]
00007f4e3fddbd36  por xmm1, xmm15
00007f4e3fddbd3b  movaps xmm15, [r15+0x1C0]
00007f4e3fddbd43  vmovaps [rsp+0x90], xmm15
00007f4e3fddbd4c  vmovaps [rsp+0xC0], xmm1
00007f4e3fddbd55  vmovaps xmm1, [rsp+0x90]
00007f4e3fddbd5e  por xmm15, xmm1
00007f4e3fddbd63  movaps xmm1, [r15+0x190]
00007f4e3fddbd6b  vmovaps [rsp+0x90], xmm1
00007f4e3fddbd74  vmovaps [rsp+0xD0], xmm15
00007f4e3fddbd7d  vmovaps xmm15, [rsp+0x90]
00007f4e3fddbd86  por xmm1, xmm15
00007f4e3fddbd8b  movaps xmm15, [r15+0x300]
00007f4e3fddbd93  vmovaps [rsp+0x90], xmm15
00007f4e3fddbd9c  vmovaps [rsp+0xE0], xmm1
00007f4e3fddbda5  vmovaps xmm1, [rsp+0x90]
00007f4e3fddbdae  por xmm15, xmm1
00007f4e3fddbdb3  mov rax, [rsp+0x80]
00007f4e3fddbdbb  lea r12, [rax+0xA0]
00007f4e3fddbdc2  movups xmm1, [r13+r12*1]
00007f4e3fddbdc8  lea r12, [rax+0xB0]
00007f4e3fddbdcf  vmovaps [rsp+0x80], xmm1
00007f4e3fddbdd8  movups xmm1, [r13+r12*1]
00007f4e3fddbdde  vmovaps [rsp+0x90], xmm1
00007f4e3fddbde7  vmovaps [rsp+0xF0], xmm15
00007f4e3fddbdf0  vmovaps xmm15, [rsp+0xB0]
00007f4e3fddbdf9  vmovaps [rsp+0xB0], xmm14
00007f4e3fddbe02  movaps xmm1, xmm6
00007f4e3fddbe05  addpd xmm1, xmm15
00007f4e3fddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f4e3fddbe0f  ptest xmm14, xmm14
00007f4e3fddbe15  jnz 0x00007F4E3FDDD4D6
00007f4e3fddbe1b  lea r12, [rax+0xF0]
00007f4e3fddbe22  movups xmm15, [r13+r12*1]
00007f4e3fddbe28  movaps xmm14, xmm4
00007f4e3fddbe2c  addpd xmm14, xmm3
00007f4e3fddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f4e3fddbe37  ptest xmm6, xmm6
00007f4e3fddbe3c  jnz 0x00007F4E3FDDD621
00007f4e3fddbe42  movaps xmm6, xmm9
00007f4e3fddbe46  addpd xmm6, xmm7
00007f4e3fddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f4e3fddbe4f  ptest xmm4, xmm4
00007f4e3fddbe54  jnz 0x00007F4E3FDDD763
00007f4e3fddbe5a  vmovaps xmm9, [rsp+0x70]
00007f4e3fddbe60  vpermilpd xmm9, xmm9, 0x00
00007f4e3fddbe66  vmovaps xmm4, [rsp+0x90]
00007f4e3fddbe6f  movaps xmm7, xmm4
00007f4e3fddbe72  mulpd xmm7, xmm9
00007f4e3fddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f4e3fddbe7c  ptest xmm3, xmm3
00007f4e3fddbe81  jnz 0x00007F4E3FDDD8A4
00007f4e3fddbe87  vmovaps xmm9, [rsp+0x50]
00007f4e3fddbe8d  vpermilpd xmm9, xmm9, 0x00
00007f4e3fddbe93  movaps xmm4, xmm15
00007f4e3fddbe97  mulpd xmm4, xmm9
00007f4e3fddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f4e3fddbea1  ptest xmm3, xmm3
00007f4e3fddbea6  jnz 0x00007F4E3FDDD9E5
00007f4e3fddbeac  lea r12, [rax+0xE0]
00007f4e3fddbeb3  movups xmm15, [r13+r12*1]
00007f4e3fddbeb9  vmovaps xmm9, [rsp+0x70]
00007f4e3fddbebf  vpermilpd xmm9, xmm9, 0x00
00007f4e3fddbec5  vmovaps [rsp+0x70], xmm1
00007f4e3fddbecb  vmovaps xmm1, [rsp+0x80]
00007f4e3fddbed4  vmovaps [rsp+0x80], xmm15
00007f4e3fddbedd  movaps xmm3, xmm1
00007f4e3fddbee0  mulpd xmm3, xmm9
00007f4e3fddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f4e3fddbeea  ptest xmm15, xmm15
00007f4e3fddbef0  jnz 0x00007F4E3FDDDB31
00007f4e3fddbef6  vmovaps xmm1, [rsp+0xF0]
00007f4e3fddbeff  vmovaps xmm15, [rsp+0xF0]
00007f4e3fddbf08  por xmm1, xmm15
00007f4e3fddbf0d  movaps [r15+0x300], xmm1
00007f4e3fddbf15  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddbf1e  vmovaps xmm9, [rsp+0xE0]
00007f4e3fddbf27  por xmm15, xmm9
00007f4e3fddbf2c  movaps [r15+0x190], xmm15
00007f4e3fddbf34  vmovaps xmm9, [rsp+0x50]
00007f4e3fddbf3a  vpermilpd xmm9, xmm9, 0x00
00007f4e3fddbf40  vmovaps [rsp+0x90], xmm1
00007f4e3fddbf49  vmovaps [rsp+0xE0], xmm15
00007f4e3fddbf52  vmovaps xmm15, [rsp+0x80]
00007f4e3fddbf5b  vmovaps [rsp+0x80], xmm14
00007f4e3fddbf64  movaps xmm1, xmm15
00007f4e3fddbf68  mulpd xmm1, xmm9
00007f4e3fddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f4e3fddbf72  ptest xmm14, xmm14
00007f4e3fddbf78  jnz 0x00007F4E3FDDDC72
00007f4e3fddbf7e  lea r12, [rax+0x90]
00007f4e3fddbf85  movups xmm15, [r13+r12*1]
00007f4e3fddbf8b  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddbf94  vmovaps xmm9, [rsp+0xD0]
00007f4e3fddbf9d  por xmm14, xmm9
00007f4e3fddbfa2  movaps [r15+0x1C0], xmm14
00007f4e3fddbfaa  vmovaps xmm9, [rsp+0xC0]
00007f4e3fddbfb3  vmovaps [rsp+0xD0], xmm1
00007f4e3fddbfbc  vmovaps xmm1, [rsp+0xC0]
00007f4e3fddbfc5  por xmm9, xmm1
00007f4e3fddbfca  movaps [r15+0x200], xmm9
00007f4e3fddbfd2  vmovaps [rsp+0xC0], xmm2
00007f4e3fddbfdb  vmovaps xmm1, [rsp+0xC0]
00007f4e3fddbfe4  por xmm2, xmm1
00007f4e3fddbfe8  movaps [r15+0x2D0], xmm2
00007f4e3fddbff0  vmovaps [rsp+0xC0], xmm8
00007f4e3fddbff9  vmovaps xmm1, [rsp+0xC0]
00007f4e3fddc002  por xmm8, xmm1
00007f4e3fddc007  movaps [r15+0x2E0], xmm8
00007f4e3fddc00f  vmovaps [rsp+0xC0], xmm15
00007f4e3fddc018  movaps xmm1, xmm5
00007f4e3fddc01b  addpd xmm1, xmm7
00007f4e3fddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f4e3fddc024  ptest xmm15, xmm15
00007f4e3fddc02a  jnz 0x00007F4E3FDDDDBE
00007f4e3fddc030  vmovaps xmm15, [rsp+0x50]
00007f4e3fddc036  vpermilpd xmm15, xmm15, 0x00
00007f4e3fddc03c  vmovaps xmm5, [rsp+0xC0]
00007f4e3fddc045  vmovaps [rsp+0xC0], xmm1
00007f4e3fddc04e  movaps xmm7, xmm5
00007f4e3fddc051  mulpd xmm7, xmm15
00007f4e3fddc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f4e3fddc05b  ptest xmm1, xmm1
00007f4e3fddc060  jnz 0x00007F4E3FDDDEFE
00007f4e3fddc066  lea r12, [rax+0x80]
00007f4e3fddc06d  movups xmm1, [r13+r12*1]
00007f4e3fddc073  vmovaps xmm5, [rsp+0x70]
00007f4e3fddc079  vmovaps [rsp+0x70], xmm1
00007f4e3fddc07f  movaps xmm15, xmm5
00007f4e3fddc083  addpd xmm15, xmm3
00007f4e3fddc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fddc08e  ptest xmm1, xmm1
00007f4e3fddc093  jnz 0x00007F4E3FDDE049
00007f4e3fddc099  vmovaps xmm5, [rsp+0x80]
00007f4e3fddc0a2  movaps xmm1, xmm5
00007f4e3fddc0a5  addpd xmm1, xmm4
00007f4e3fddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f4e3fddc0ae  ptest xmm3, xmm3
00007f4e3fddc0b3  jnz 0x00007F4E3FDDE18B
00007f4e3fddc0b9  vmovaps [rsp+0x80], xmm10
00007f4e3fddc0c2  vmovaps xmm5, [rsp+0x80]
00007f4e3fddc0cb  por xmm10, xmm5
00007f4e3fddc0d0  movaps [r15+0x2F0], xmm10
00007f4e3fddc0d8  vmovaps xmm5, [rsp+0x50]
00007f4e3fddc0de  vpermilpd xmm5, xmm5, 0x00
00007f4e3fddc0e4  vmovaps xmm3, [rsp+0x70]
00007f4e3fddc0ea  vmovaps [rsp+0x50], xmm1
00007f4e3fddc0f0  movaps xmm4, xmm3
00007f4e3fddc0f3  mulpd xmm4, xmm5
00007f4e3fddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f4e3fddc0fc  ptest xmm1, xmm1
00007f4e3fddc101  jnz 0x00007F4E3FDDE2CB
00007f4e3fddc107  lea r12, [rax+0xD0]
00007f4e3fddc10e  movups xmm1, [r13+r12*1]
00007f4e3fddc114  vmovaps xmm3, [rsp+0xD0]
00007f4e3fddc11d  vmovaps [rsp+0x70], xmm1
00007f4e3fddc123  movaps xmm5, xmm6
00007f4e3fddc126  addpd xmm5, xmm3
00007f4e3fddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f4e3fddc12f  ptest xmm1, xmm1
00007f4e3fddc134  jnz 0x00007F4E3FDDE415
00007f4e3fddc13a  vmovaps xmm1, [rsp+0x60]
00007f4e3fddc140  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc146  movaps xmm6, xmm9
00007f4e3fddc14a  mulpd xmm6, xmm1
00007f4e3fddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f4e3fddc153  ptest xmm3, xmm3
00007f4e3fddc158  jnz 0x00007F4E3FDDE555
00007f4e3fddc15e  movaps [r15+0x260], xmm6
00007f4e3fddc166  vxorps xmm1, xmm1, xmm1
00007f4e3fddc16a  vpbroadcastq xmm1, xmm1
00007f4e3fddc16f  movaps [r15+0x1B0], xmm1
00007f4e3fddc177  vmovaps xmm1, [rsp+0x60]
00007f4e3fddc17d  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc183  vmovaps xmm3, [rsp+0x70]
00007f4e3fddc189  vmovaps [rsp+0x70], xmm15
00007f4e3fddc18f  movaps xmm9, xmm3
00007f4e3fddc193  mulpd xmm9, xmm1
00007f4e3fddc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f4e3fddc19e  ptest xmm15, xmm15
00007f4e3fddc1a4  jnz 0x00007F4E3FDDE696
00007f4e3fddc1aa  lea r12, [rax+0xC0]
00007f4e3fddc1b1  movups xmm1, [r13+r12*1]
00007f4e3fddc1b7  vmovaps xmm3, [rsp+0xC0]
00007f4e3fddc1c0  vmovaps [rsp+0x80], xmm1
00007f4e3fddc1c9  movaps xmm15, xmm3
00007f4e3fddc1cd  addpd xmm15, xmm7
00007f4e3fddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fddc1d8  ptest xmm1, xmm1
00007f4e3fddc1dd  jnz 0x00007F4E3FDDE7E2
00007f4e3fddc1e3  vmovaps [rsp+0xC0], xmm13
00007f4e3fddc1ec  vmovaps xmm1, [rsp+0xC0]
00007f4e3fddc1f5  por xmm13, xmm1
00007f4e3fddc1fa  movaps [r15+0x270], xmm13
00007f4e3fddc202  vmovaps xmm1, [rsp+0xB0]
00007f4e3fddc20b  vmovaps xmm7, [rsp+0xB0]
00007f4e3fddc214  por xmm1, xmm7
00007f4e3fddc218  movaps [r15+0x1A0], xmm1
00007f4e3fddc220  vmovaps xmm1, [rsp+0x60]
00007f4e3fddc226  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc22c  vmovaps [rsp+0xB0], xmm1
00007f4e3fddc235  vmovaps xmm1, [rsp+0x80]
00007f4e3fddc23e  vmovaps [rsp+0x80], xmm15
00007f4e3fddc247  vmovaps xmm15, [rsp+0xB0]
00007f4e3fddc250  vmovaps [rsp+0xB0], xmm14
00007f4e3fddc259  movaps xmm3, xmm1
00007f4e3fddc25c  mulpd xmm3, xmm15
00007f4e3fddc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f4e3fddc266  ptest xmm14, xmm14
00007f4e3fddc26c  jnz 0x00007F4E3FDDE924
00007f4e3fddc272  lea r12, [rax+0x20]
00007f4e3fddc276  movups xmm1, [r13+r12*1]
00007f4e3fddc27c  movaps [r15+0x110], xmm1
00007f4e3fddc284  vmovaps xmm14, [rsp+0x70]
00007f4e3fddc28a  vmovaps [rsp+0x70], xmm1
00007f4e3fddc290  movaps xmm15, xmm14
00007f4e3fddc294  addpd xmm15, xmm4
00007f4e3fddc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f4e3fddc29f  ptest xmm1, xmm1
00007f4e3fddc2a4  jnz 0x00007F4E3FDDEA6F
00007f4e3fddc2aa  vmovaps xmm1, [rsp+0x60]
00007f4e3fddc2b0  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc2b6  movaps xmm14, xmm2
00007f4e3fddc2ba  mulpd xmm14, xmm1
00007f4e3fddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f4e3fddc2c5  ptest xmm4, xmm4
00007f4e3fddc2ca  jnz 0x00007F4E3FDDEBB2
00007f4e3fddc2d0  vmovaps xmm4, [rsp+0x50]
00007f4e3fddc2d6  movaps xmm1, xmm4
00007f4e3fddc2d9  addpd xmm1, xmm9
00007f4e3fddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f4e3fddc2e3  ptest xmm2, xmm2
00007f4e3fddc2e8  jnz 0x00007F4E3FDDECF4
00007f4e3fddc2ee  vmovaps xmm9, [rsp+0x30]
00007f4e3fddc2f4  vpermilpd xmm9, xmm9, 0x00
00007f4e3fddc2fa  vmovaps xmm2, [rsp+0x70]
00007f4e3fddc300  vmovaps [rsp+0x50], xmm1
00007f4e3fddc306  movaps xmm4, xmm2
00007f4e3fddc309  mulpd xmm4, xmm9
00007f4e3fddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f4e3fddc313  ptest xmm1, xmm1
00007f4e3fddc318  jnz 0x00007F4E3FDDEE35
00007f4e3fddc31e  vmovaps xmm1, [rsp+0x30]
00007f4e3fddc324  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc32a  vmovaps xmm2, [rsp+0x90]
00007f4e3fddc333  vmovaps [rsp+0x60], xmm15
00007f4e3fddc339  movaps xmm9, xmm2
00007f4e3fddc33d  mulpd xmm9, xmm1
00007f4e3fddc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f4e3fddc348  ptest xmm15, xmm15
00007f4e3fddc34e  jnz 0x00007F4E3FDDEF76
00007f4e3fddc354  vmovaps xmm15, [rsp+0x80]
00007f4e3fddc35d  movaps xmm1, xmm15
00007f4e3fddc361  addpd xmm1, xmm6
00007f4e3fddc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f4e3fddc36a  ptest xmm2, xmm2
00007f4e3fddc36f  jnz 0x00007F4E3FDDF0B8
00007f4e3fddc375  movaps xmm15, xmm5
00007f4e3fddc379  addpd xmm15, xmm3
00007f4e3fddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f4e3fddc384  ptest xmm6, xmm6
00007f4e3fddc389  jnz 0x00007F4E3FDDF1F9
00007f4e3fddc38f  vmovaps xmm6, [rsp+0x30]
00007f4e3fddc395  vpermilpd xmm6, xmm6, 0x00
00007f4e3fddc39b  movaps xmm5, xmm8
00007f4e3fddc39f  mulpd xmm5, xmm6
00007f4e3fddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f4e3fddc3a8  ptest xmm3, xmm3
00007f4e3fddc3ad  jnz 0x00007F4E3FDDF33B
00007f4e3fddc3b3  vmovaps xmm8, [rsp+0x30]
00007f4e3fddc3b9  vpermilpd xmm8, xmm8, 0x00
00007f4e3fddc3bf  movaps xmm6, xmm10
00007f4e3fddc3c3  mulpd xmm6, xmm8
00007f4e3fddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f4e3fddc3cd  ptest xmm3, xmm3
00007f4e3fddc3d2  jnz 0x00007F4E3FDDF47C
00007f4e3fddc3d8  vmovaps xmm8, [rsp+0x60]
00007f4e3fddc3de  movaps xmm10, xmm8
00007f4e3fddc3e2  addpd xmm10, xmm14
00007f4e3fddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f4e3fddc3ed  ptest xmm3, xmm3
00007f4e3fddc3f2  jnz 0x00007F4E3FDDF5BE
00007f4e3fddc3f8  vmovaps xmm8, [rsp+0x50]
00007f4e3fddc3fe  movaps xmm14, xmm8
00007f4e3fddc402  addpd xmm14, xmm4
00007f4e3fddc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f4e3fddc40d  ptest xmm3, xmm3
00007f4e3fddc412  jnz 0x00007F4E3FDDF702
00007f4e3fddc418  vmovaps xmm8, [rsp+0x40]
00007f4e3fddc41e  vpermilpd xmm8, xmm8, 0x00
00007f4e3fddc424  movaps xmm4, xmm13
00007f4e3fddc428  mulpd xmm4, xmm8
00007f4e3fddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f4e3fddc432  ptest xmm3, xmm3
00007f4e3fddc437  jnz 0x00007F4E3FDDF845
00007f4e3fddc43d  movaps xmm13, xmm15
00007f4e3fddc441  addpd xmm13, xmm9
00007f4e3fddc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f4e3fddc44c  ptest xmm8, xmm8
00007f4e3fddc452  jnz 0x00007F4E3FDDF987
00007f4e3fddc458  movaps xmm15, xmm1
00007f4e3fddc45c  addpd xmm15, xmm5
00007f4e3fddc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f4e3fddc467  ptest xmm9, xmm9
00007f4e3fddc46d  jnz 0x00007F4E3FDDFACB
00007f4e3fddc473  vmovaps [rsp+0x30], xmm11
00007f4e3fddc479  vmovaps xmm1, [rsp+0x30]
00007f4e3fddc47f  por xmm11, xmm1
00007f4e3fddc484  movaps [r15+0x250], xmm11
00007f4e3fddc48c  vmovaps [rsp+0x30], xmm12
00007f4e3fddc492  vmovaps xmm1, [rsp+0x30]
00007f4e3fddc498  por xmm12, xmm1
00007f4e3fddc49d  movaps [r15+0x2A0], xmm12
00007f4e3fddc4a5  vmovaps xmm1, [rsp+0xA0]
00007f4e3fddc4ae  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddc4b7  por xmm1, xmm11
00007f4e3fddc4bc  movaps [r15+0x1D0], xmm1
00007f4e3fddc4c4  lea r12, [rax+0x40]
00007f4e3fddc4c8  movups xmm1, [r13+r12*1]
00007f4e3fddc4ce  movaps [r15+0x2C0], xmm1
00007f4e3fddc4d6  vmovaps xmm11, [rsp+0x40]
00007f4e3fddc4dc  vpermilpd xmm11, xmm11, 0x00
00007f4e3fddc4e2  vmovaps xmm8, [rsp+0xE0]
00007f4e3fddc4eb  movaps xmm9, xmm8
00007f4e3fddc4ef  mulpd xmm9, xmm11
00007f4e3fddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f4e3fddc4fa  ptest xmm5, xmm5
00007f4e3fddc4ff  jnz 0x00007F4E3FDDFC17
00007f4e3fddc505  movaps xmm11, xmm10
00007f4e3fddc509  addpd xmm11, xmm6
00007f4e3fddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f4e3fddc514  ptest xmm8, xmm8
00007f4e3fddc51a  jnz 0x00007F4E3FDDFD5B
00007f4e3fddc520  movaps xmm10, xmm14
00007f4e3fddc524  addpd xmm10, xmm4
00007f4e3fddc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f4e3fddc52f  ptest xmm8, xmm8
00007f4e3fddc535  jnz 0x00007F4E3FDDFE9E
00007f4e3fddc53b  vmovaps xmm14, [rsp+0x40]
00007f4e3fddc541  vpermilpd xmm14, xmm14, 0x00
00007f4e3fddc547  movaps xmm8, xmm1
00007f4e3fddc54b  mulpd xmm8, xmm14
00007f4e3fddc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4e3fddc556  ptest xmm6, xmm6
00007f4e3fddc55b  jnz 0x00007F4E3FDDFFE1
00007f4e3fddc561  movaps xmm1, [r15+0x2B0]
00007f4e3fddc569  vmovaps xmm14, [rsp+0x40]
00007f4e3fddc56f  vpermilpd xmm14, xmm14, 0x00
00007f4e3fddc575  movaps xmm6, xmm1
00007f4e3fddc578  mulpd xmm6, xmm14
00007f4e3fddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f4e3fddc582  ptest xmm5, xmm5
00007f4e3fddc587  jnz 0x00007F4E3FDE0124
00007f4e3fddc58d  vmovaps xmm1, [rsp+0x10]
00007f4e3fddc593  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc599  movaps xmm14, xmm12
00007f4e3fddc59d  mulpd xmm14, xmm1
00007f4e3fddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f4e3fddc5a8  ptest xmm5, xmm5
00007f4e3fddc5ad  jnz 0x00007F4E3FDE0265
00007f4e3fddc5b3  movaps xmm1, xmm13
00007f4e3fddc5b7  addpd xmm1, xmm9
00007f4e3fddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f4e3fddc5c1  ptest xmm12, xmm12
00007f4e3fddc5c7  jnz 0x00007F4E3FDE03A8
00007f4e3fddc5cd  vmovaps xmm13, [rsp+0x10]
00007f4e3fddc5d3  vpermilpd xmm13, xmm13, 0x00
00007f4e3fddc5d9  movaps xmm12, xmm7
00007f4e3fddc5dd  mulpd xmm12, xmm13
00007f4e3fddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4e3fddc5e8  ptest xmm9, xmm9
00007f4e3fddc5ee  jnz 0x00007F4E3FDE04EA
00007f4e3fddc5f4  movaps xmm13, xmm15
00007f4e3fddc5f8  addpd xmm13, xmm8
00007f4e3fddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f4e3fddc603  ptest xmm9, xmm9
00007f4e3fddc609  jnz 0x00007F4E3FDE062D
00007f4e3fddc60f  movaps xmm15, [r15+0x290]
00007f4e3fddc617  vmovaps xmm9, [rsp+0x10]
00007f4e3fddc61d  vpermilpd xmm9, xmm9, 0x00
00007f4e3fddc623  movaps xmm8, xmm15
00007f4e3fddc627  mulpd xmm8, xmm9
00007f4e3fddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f4e3fddc632  ptest xmm7, xmm7
00007f4e3fddc637  jnz 0x00007F4E3FDE0771
00007f4e3fddc63d  movaps xmm15, xmm11
00007f4e3fddc641  addpd xmm15, xmm6
00007f4e3fddc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f4e3fddc64c  ptest xmm9, xmm9
00007f4e3fddc652  jnz 0x00007F4E3FDE08B5
00007f4e3fddc658  movaps xmm11, [r15+0x1E0]
00007f4e3fddc660  vmovaps xmm9, [rsp+0x10]
00007f4e3fddc666  vpermilpd xmm9, xmm9, 0x00
00007f4e3fddc66c  movaps xmm7, xmm11
00007f4e3fddc670  mulpd xmm7, xmm9
00007f4e3fddc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4e3fddc67a  ptest xmm6, xmm6
00007f4e3fddc67f  jnz 0x00007F4E3FDE09F8
00007f4e3fddc685  movaps xmm11, xmm10
00007f4e3fddc689  addpd xmm11, xmm14
00007f4e3fddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f4e3fddc694  ptest xmm9, xmm9
00007f4e3fddc69a  jnz 0x00007F4E3FDE0B3A
00007f4e3fddc6a0  lea r12, [rax+0x70]
00007f4e3fddc6a4  movups xmm14, [r13+r12*1]
00007f4e3fddc6aa  movaps [r15+0x240], xmm14
00007f4e3fddc6b2  movaps xmm10, xmm1
00007f4e3fddc6b6  addpd xmm10, xmm12
00007f4e3fddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f4e3fddc6c1  ptest xmm9, xmm9
00007f4e3fddc6c7  jnz 0x00007F4E3FDE0C88
00007f4e3fddc6cd  movaps [r15+0x170], xmm10
00007f4e3fddc6d5  vmovaps xmm1, [rsp+0x20]
00007f4e3fddc6db  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc6e1  movaps xmm12, xmm14
00007f4e3fddc6e5  mulpd xmm12, xmm1
00007f4e3fddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f4e3fddc6f0  ptest xmm9, xmm9
00007f4e3fddc6f6  jnz 0x00007F4E3FDE0DCB
00007f4e3fddc6fc  vmovaps xmm1, [rsp+0x20]
00007f4e3fddc702  vpermilpd xmm1, xmm1, 0x00
00007f4e3fddc708  vmovaps xmm9, [rsp+0xB0]
00007f4e3fddc711  movaps xmm14, xmm9
00007f4e3fddc715  mulpd xmm14, xmm1
00007f4e3fddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f4e3fddc720  ptest xmm6, xmm6
00007f4e3fddc725  jnz 0x00007F4E3FDE0F0E
00007f4e3fddc72b  movaps [r15+0x180], xmm14
00007f4e3fddc733  movaps xmm1, xmm13
00007f4e3fddc737  addpd xmm1, xmm8
00007f4e3fddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f4e3fddc741  ptest xmm9, xmm9
00007f4e3fddc747  jnz 0x00007F4E3FDE1051
00007f4e3fddc74d  movaps [r15+0x210], xmm1
00007f4e3fddc755  movups xmm13, [r13+rax*1]
00007f4e3fddc75b  lea r12, [rax+0x10]
00007f4e3fddc75f  movups xmm9, [r13+r12*1]
00007f4e3fddc765  movaps [r15+0x230], xmm9
00007f4e3fddc76d  movaps xmm8, xmm15
00007f4e3fddc771  addpd xmm8, xmm7
00007f4e3fddc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f4e3fddc77c  ptest xmm6, xmm6
00007f4e3fddc781  jnz 0x00007F4E3FDE11A7
00007f4e3fddc787  movaps [r15+0x130], xmm8
00007f4e3fddc78f  vmovaps xmm15, [rsp+0x20]
00007f4e3fddc795  vpermilpd xmm15, xmm15, 0x00
00007f4e3fddc79b  movaps xmm7, xmm9
00007f4e3fddc79f  mulpd xmm7, xmm15
00007f4e3fddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f4e3fddc7a9  ptest xmm6, xmm6
00007f4e3fddc7ae  jnz 0x00007F4E3FDE12EA
00007f4e3fddc7b4  movaps [r15+0x220], xmm7
00007f4e3fddc7bc  vmovaps xmm15, [rsp+0x20]
00007f4e3fddc7c2  vpermilpd xmm15, xmm15, 0x00
00007f4e3fddc7c8  movaps xmm9, xmm13
00007f4e3fddc7cc  mulpd xmm9, xmm15
00007f4e3fddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f4e3fddc7d7  ptest xmm6, xmm6
00007f4e3fddc7dc  jnz 0x00007F4E3FDE142C
00007f4e3fddc7e2  movaps xmm15, xmm11
00007f4e3fddc7e6  addpd xmm15, xmm12
00007f4e3fddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f4e3fddc7f1  ptest xmm13, xmm13
00007f4e3fddc7f7  jnz 0x00007F4E3FDE1570
00007f4e3fddc7fd  movaps [r15+0x140], xmm15
00007f4e3fddc805  movaps xmm13, xmm10
00007f4e3fddc809  addpd xmm13, xmm14
00007f4e3fddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f4e3fddc814  ptest xmm12, xmm12
00007f4e3fddc81a  jnz 0x00007F4E3FDE16B4
00007f4e3fddc820  movaps [r15+0x150], xmm13
00007f4e3fddc828  movaps xmm14, xmm1
00007f4e3fddc82c  addpd xmm14, xmm7
00007f4e3fddc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f4e3fddc837  ptest xmm12, xmm12
00007f4e3fddc83d  jnz 0x00007F4E3FDE17F8
00007f4e3fddc843  movaps [r15+0x160], xmm14
00007f4e3fddc84b  movaps xmm1, xmm8
00007f4e3fddc84f  addpd xmm1, xmm9
00007f4e3fddc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f4e3fddc859  ptest xmm12, xmm12
00007f4e3fddc85f  jnz 0x00007F4E3FDE193A
00007f4e3fddc865  movaps [r15+0x120], xmm1
00007f4e3fddc86d  movups [r13+r14*1], xmm15
00007f4e3fddc873  lea rax, [r14+0x10]
00007f4e3fddc877  movups [r13+rax*1], xmm13
00007f4e3fddc87d  lea rax, [r14+0x20]
00007f4e3fddc881  movups [r13+rax*1], xmm14
00007f4e3fddc887  lea rax, [r14+0x30]
00007f4e3fddc88b  movups [r13+rax*1], xmm1
00007f4e3fddc891  mov eax, [r15+0x108]
00007f4e3fddc898  sahf
00007f4e3fddc899  jnz 0x00007F4E3FDDC8CB
00007f4e3fddc89b  cmp dword ptr [r15+0x318], 0x00
00007f4e3fddc8a3  jz 0x00007F4E3FDDB900
00007f4e3fddc8a9  nop [rax+rax*1], ax
00007f4e3fddc8b2  nop [rax+rax*1], eax
00007f4e3fddc8ba  mov eax, 0x410444
00007f4e3fddc8bf  mov [r15+0x100], rax
00007f4e3fddc8c6  jmp 0x00007F4E3FBFE110
00007f4e3fddc8cb  cmp dword ptr [r15+0x318], 0x00
00007f4e3fddc8d3  jz 0x00007F4E3FDD57E0
00007f4e3fddc8d9  nop [rax+rax*1], ax
00007f4e3fddc8e2  nop [rax+rax*1], eax
00007f4e3fddc8ea  mov eax, 0x410278
00007f4e3fddc8ef  mov [r15+0x100], rax
00007f4e3fddc8f6  jmp 0x00007F4E3FBFE110
00007f4e3fddc8fb  int3
00007f4e3fddc8fc  call 0x00007F4E3FCE27E0
00007f4e3fddc901  jmp 0x00007F4E3FDDB9DF
00007f4e3fddc906  call 0x00007F4E3FCE1570
00007f4e3fddc90b  jmp 0x00007F4E3FDDB9E8
00007f4e3fddc910  call 0x00007F4E3FCE27E0
00007f4e3fddc915  jmp 0x00007F4E3FDDBA44
00007f4e3fddc91a  call 0x00007F4E3FCE1570
00007f4e3fddc91f  jmp 0x00007F4E3FDDBA4D
00007f4e3fddc924  call 0x00007F4E3FCE27E0
00007f4e3fddc929  jmp 0x00007F4E3FDDBA90
00007f4e3fddc92e  call 0x00007F4E3FCE1570
00007f4e3fddc933  jmp 0x00007F4E3FDDBA99
00007f4e3fddc938  call 0x00007F4E3FC0DC20
00007f4e3fddc93d  jmp 0x00007F4E3FDDBAD8
00007f4e3fddc942  call 0x00007F4E3FCD59C0
00007f4e3fddc947  jmp 0x00007F4E3FDDBAEB
00007f4e3fddc94c  call 0x00007F4E3FCE0E30
00007f4e3fddc951  jmp 0x00007F4E3FDDBB09
00007f4e3fddc956  call 0x00007F4E3FCDFBC0
00007f4e3fddc95b  jmp 0x00007F4E3FDDBB13
00007f4e3fddc960  call 0x00007F4E3FCDE950
00007f4e3fddc965  jmp 0x00007F4E3FDDBB1D
00007f4e3fddc96a  sub rsp, 0x08
00007f4e3fddc96e  push rax
00007f4e3fddc96f  push rcx
00007f4e3fddc970  push rdx
00007f4e3fddc971  push rdi
00007f4e3fddc972  push rsi
00007f4e3fddc973  push r8
00007f4e3fddc975  push r9
00007f4e3fddc977  push r10
00007f4e3fddc979  push r11
00007f4e3fddc97b  sub rsp, 0xF0
00007f4e3fddc982  vmovaps [rsp], xmm0
00007f4e3fddc987  vmovaps [rsp+0x10], xmm1
00007f4e3fddc98d  vmovaps [rsp+0x20], xmm2
00007f4e3fddc993  vmovaps [rsp+0x30], xmm3
00007f4e3fddc999  vmovaps [rsp+0x40], xmm4
00007f4e3fddc99f  vmovaps [rsp+0x50], xmm5
00007f4e3fddc9a5  vmovaps [rsp+0x60], xmm6
00007f4e3fddc9ab  vmovaps [rsp+0x70], xmm7
00007f4e3fddc9b1  vmovaps [rsp+0x80], xmm9
00007f4e3fddc9ba  vmovaps [rsp+0x90], xmm10
00007f4e3fddc9c3  vmovaps [rsp+0xA0], xmm11
00007f4e3fddc9cc  vmovaps [rsp+0xB0], xmm12
00007f4e3fddc9d5  vmovaps [rsp+0xC0], xmm13
00007f4e3fddc9de  vmovaps [rsp+0xD0], xmm14
00007f4e3fddc9e7  vmovaps [rsp+0xE0], xmm15
00007f4e3fddc9f0  sub rsp, 0x30
00007f4e3fddc9f4  movaps [rsp], xmm8
00007f4e3fddc9f9  movaps [rsp+0x10], xmm12
00007f4e3fddc9ff  movaps [rsp+0x20], xmm15
00007f4e3fddca05  lea rdi, [rsp]
00007f4e3fddca09  mov esi, 0x00
00007f4e3fddca0e  mov rax, 0x5D97141E9530
00007f4e3fddca18  call rax
00007f4e3fddca1a  movaps xmm8, [rsp]
00007f4e3fddca1f  add rsp, 0x30
00007f4e3fddca23  vmovaps xmm0, [rsp]
00007f4e3fddca28  vmovaps xmm1, [rsp+0x10]
00007f4e3fddca2e  vmovaps xmm2, [rsp+0x20]
00007f4e3fddca34  vmovaps xmm3, [rsp+0x30]
00007f4e3fddca3a  vmovaps xmm4, [rsp+0x40]
00007f4e3fddca40  vmovaps xmm5, [rsp+0x50]
00007f4e3fddca46  vmovaps xmm6, [rsp+0x60]
00007f4e3fddca4c  vmovaps xmm7, [rsp+0x70]
00007f4e3fddca52  vmovaps xmm9, [rsp+0x80]
00007f4e3fddca5b  vmovaps xmm10, [rsp+0x90]
00007f4e3fddca64  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddca6d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddca76  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddca7f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddca88  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddca91  add rsp, 0xF0
00007f4e3fddca98  pop r11
00007f4e3fddca9a  pop r10
00007f4e3fddca9c  pop r9
00007f4e3fddca9e  pop r8
00007f4e3fddcaa0  pop rsi
00007f4e3fddcaa1  pop rdi
00007f4e3fddcaa2  pop rdx
00007f4e3fddcaa3  pop rcx
00007f4e3fddcaa4  pop rax
00007f4e3fddcaa5  add rsp, 0x08
00007f4e3fddcaa9  jmp 0x00007F4E3FDDBB47
00007f4e3fddcaae  sub rsp, 0x08
00007f4e3fddcab2  push rax
00007f4e3fddcab3  push rcx
00007f4e3fddcab4  push rdx
00007f4e3fddcab5  push rdi
00007f4e3fddcab6  push rsi
00007f4e3fddcab7  push r8
00007f4e3fddcab9  push r9
00007f4e3fddcabb  push r10
00007f4e3fddcabd  push r11
00007f4e3fddcabf  sub rsp, 0xF0
00007f4e3fddcac6  vmovaps [rsp], xmm0
00007f4e3fddcacb  vmovaps [rsp+0x10], xmm1
00007f4e3fddcad1  vmovaps [rsp+0x20], xmm2
00007f4e3fddcad7  vmovaps [rsp+0x30], xmm3
00007f4e3fddcadd  vmovaps [rsp+0x40], xmm4
00007f4e3fddcae3  vmovaps [rsp+0x50], xmm5
00007f4e3fddcae9  vmovaps [rsp+0x60], xmm6
00007f4e3fddcaef  vmovaps [rsp+0x70], xmm8
00007f4e3fddcaf5  vmovaps [rsp+0x80], xmm9
00007f4e3fddcafe  vmovaps [rsp+0x90], xmm10
00007f4e3fddcb07  vmovaps [rsp+0xA0], xmm11
00007f4e3fddcb10  vmovaps [rsp+0xB0], xmm12
00007f4e3fddcb19  vmovaps [rsp+0xC0], xmm13
00007f4e3fddcb22  vmovaps [rsp+0xD0], xmm14
00007f4e3fddcb2b  vmovaps [rsp+0xE0], xmm15
00007f4e3fddcb34  sub rsp, 0x30
00007f4e3fddcb38  movaps [rsp], xmm7
00007f4e3fddcb3c  movaps [rsp+0x10], xmm9
00007f4e3fddcb42  movaps [rsp+0x20], xmm15
00007f4e3fddcb48  lea rdi, [rsp]
00007f4e3fddcb4c  mov esi, 0x00
00007f4e3fddcb51  mov rax, 0x5D97141E9530
00007f4e3fddcb5b  call rax
00007f4e3fddcb5d  movaps xmm7, [rsp]
00007f4e3fddcb61  add rsp, 0x30
00007f4e3fddcb65  vmovaps xmm0, [rsp]
00007f4e3fddcb6a  vmovaps xmm1, [rsp+0x10]
00007f4e3fddcb70  vmovaps xmm2, [rsp+0x20]
00007f4e3fddcb76  vmovaps xmm3, [rsp+0x30]
00007f4e3fddcb7c  vmovaps xmm4, [rsp+0x40]
00007f4e3fddcb82  vmovaps xmm5, [rsp+0x50]
00007f4e3fddcb88  vmovaps xmm6, [rsp+0x60]
00007f4e3fddcb8e  vmovaps xmm8, [rsp+0x70]
00007f4e3fddcb94  vmovaps xmm9, [rsp+0x80]
00007f4e3fddcb9d  vmovaps xmm10, [rsp+0x90]
00007f4e3fddcba6  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddcbaf  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddcbb8  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddcbc1  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddcbca  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddcbd3  add rsp, 0xF0
00007f4e3fddcbda  pop r11
00007f4e3fddcbdc  pop r10
00007f4e3fddcbde  pop r9
00007f4e3fddcbe0  pop r8
00007f4e3fddcbe2  pop rsi
00007f4e3fddcbe3  pop rdi
00007f4e3fddcbe4  pop rdx
00007f4e3fddcbe5  pop rcx
00007f4e3fddcbe6  pop rax
00007f4e3fddcbe7  add rsp, 0x08
00007f4e3fddcbeb  jmp 0x00007F4E3FDDBB75
00007f4e3fddcbf0  sub rsp, 0x08
00007f4e3fddcbf4  push rax
00007f4e3fddcbf5  push rcx
00007f4e3fddcbf6  push rdx
00007f4e3fddcbf7  push rdi
00007f4e3fddcbf8  push rsi
00007f4e3fddcbf9  push r8
00007f4e3fddcbfb  push r9
00007f4e3fddcbfd  push r10
00007f4e3fddcbff  push r11
00007f4e3fddcc01  sub rsp, 0xF0
00007f4e3fddcc08  vmovaps [rsp], xmm0
00007f4e3fddcc0d  vmovaps [rsp+0x10], xmm1
00007f4e3fddcc13  vmovaps [rsp+0x20], xmm2
00007f4e3fddcc19  vmovaps [rsp+0x30], xmm3
00007f4e3fddcc1f  vmovaps [rsp+0x40], xmm4
00007f4e3fddcc25  vmovaps [rsp+0x50], xmm5
00007f4e3fddcc2b  vmovaps [rsp+0x60], xmm6
00007f4e3fddcc31  vmovaps [rsp+0x70], xmm7
00007f4e3fddcc37  vmovaps [rsp+0x80], xmm8
00007f4e3fddcc40  vmovaps [rsp+0x90], xmm10
00007f4e3fddcc49  vmovaps [rsp+0xA0], xmm11
00007f4e3fddcc52  vmovaps [rsp+0xB0], xmm12
00007f4e3fddcc5b  vmovaps [rsp+0xC0], xmm13
00007f4e3fddcc64  vmovaps [rsp+0xD0], xmm14
00007f4e3fddcc6d  vmovaps [rsp+0xE0], xmm15
00007f4e3fddcc76  sub rsp, 0x30
00007f4e3fddcc7a  movaps [rsp], xmm9
00007f4e3fddcc7f  movaps [rsp+0x10], xmm12
00007f4e3fddcc85  movaps [rsp+0x20], xmm10
00007f4e3fddcc8b  lea rdi, [rsp]
00007f4e3fddcc8f  mov esi, 0x00
00007f4e3fddcc94  mov rax, 0x5D97141E9530
00007f4e3fddcc9e  call rax
00007f4e3fddcca0  movaps xmm9, [rsp]
00007f4e3fddcca5  add rsp, 0x30
00007f4e3fddcca9  vmovaps xmm0, [rsp]
00007f4e3fddccae  vmovaps xmm1, [rsp+0x10]
00007f4e3fddccb4  vmovaps xmm2, [rsp+0x20]
00007f4e3fddccba  vmovaps xmm3, [rsp+0x30]
00007f4e3fddccc0  vmovaps xmm4, [rsp+0x40]
00007f4e3fddccc6  vmovaps xmm5, [rsp+0x50]
00007f4e3fddcccc  vmovaps xmm6, [rsp+0x60]
00007f4e3fddccd2  vmovaps xmm7, [rsp+0x70]
00007f4e3fddccd8  vmovaps xmm8, [rsp+0x80]
00007f4e3fddcce1  vmovaps xmm10, [rsp+0x90]
00007f4e3fddccea  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddccf3  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddccfc  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddcd05  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddcd0e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddcd17  add rsp, 0xF0
00007f4e3fddcd1e  pop r11
00007f4e3fddcd20  pop r10
00007f4e3fddcd22  pop r9
00007f4e3fddcd24  pop r8
00007f4e3fddcd26  pop rsi
00007f4e3fddcd27  pop rdi
00007f4e3fddcd28  pop rdx
00007f4e3fddcd29  pop rcx
00007f4e3fddcd2a  pop rax
00007f4e3fddcd2b  add rsp, 0x08
00007f4e3fddcd2f  jmp 0x00007F4E3FDDBB99
00007f4e3fddcd34  sub rsp, 0x08
00007f4e3fddcd38  push rax
00007f4e3fddcd39  push rcx
00007f4e3fddcd3a  push rdx
00007f4e3fddcd3b  push rdi
00007f4e3fddcd3c  push rsi
00007f4e3fddcd3d  push r8
00007f4e3fddcd3f  push r9
00007f4e3fddcd41  push r10
00007f4e3fddcd43  push r11
00007f4e3fddcd45  sub rsp, 0xF0
00007f4e3fddcd4c  vmovaps [rsp], xmm0
00007f4e3fddcd51  vmovaps [rsp+0x10], xmm1
00007f4e3fddcd57  vmovaps [rsp+0x20], xmm2
00007f4e3fddcd5d  vmovaps [rsp+0x30], xmm3
00007f4e3fddcd63  vmovaps [rsp+0x40], xmm4
00007f4e3fddcd69  vmovaps [rsp+0x50], xmm5
00007f4e3fddcd6f  vmovaps [rsp+0x60], xmm6
00007f4e3fddcd75  vmovaps [rsp+0x70], xmm7
00007f4e3fddcd7b  vmovaps [rsp+0x80], xmm8
00007f4e3fddcd84  vmovaps [rsp+0x90], xmm9
00007f4e3fddcd8d  vmovaps [rsp+0xA0], xmm11
00007f4e3fddcd96  vmovaps [rsp+0xB0], xmm12
00007f4e3fddcd9f  vmovaps [rsp+0xC0], xmm13
00007f4e3fddcda8  vmovaps [rsp+0xD0], xmm14
00007f4e3fddcdb1  vmovaps [rsp+0xE0], xmm15
00007f4e3fddcdba  sub rsp, 0x30
00007f4e3fddcdbe  movaps [rsp], xmm10
00007f4e3fddcdc3  movaps [rsp+0x10], xmm12
00007f4e3fddcdc9  movaps [rsp+0x20], xmm11
00007f4e3fddcdcf  lea rdi, [rsp]
00007f4e3fddcdd3  mov esi, 0x00
00007f4e3fddcdd8  mov rax, 0x5D97141E9530
00007f4e3fddcde2  call rax
00007f4e3fddcde4  movaps xmm10, [rsp]
00007f4e3fddcde9  add rsp, 0x30
00007f4e3fddcded  vmovaps xmm0, [rsp]
00007f4e3fddcdf2  vmovaps xmm1, [rsp+0x10]
00007f4e3fddcdf8  vmovaps xmm2, [rsp+0x20]
00007f4e3fddcdfe  vmovaps xmm3, [rsp+0x30]
00007f4e3fddce04  vmovaps xmm4, [rsp+0x40]
00007f4e3fddce0a  vmovaps xmm5, [rsp+0x50]
00007f4e3fddce10  vmovaps xmm6, [rsp+0x60]
00007f4e3fddce16  vmovaps xmm7, [rsp+0x70]
00007f4e3fddce1c  vmovaps xmm8, [rsp+0x80]
00007f4e3fddce25  vmovaps xmm9, [rsp+0x90]
00007f4e3fddce2e  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddce37  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddce40  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddce49  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddce52  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddce5b  add rsp, 0xF0
00007f4e3fddce62  pop r11
00007f4e3fddce64  pop r10
00007f4e3fddce66  pop r9
00007f4e3fddce68  pop r8
00007f4e3fddce6a  pop rsi
00007f4e3fddce6b  pop rdi
00007f4e3fddce6c  pop rdx
00007f4e3fddce6d  pop rcx
00007f4e3fddce6e  pop rax
00007f4e3fddce6f  add rsp, 0x08
00007f4e3fddce73  jmp 0x00007F4E3FDDBBB3
00007f4e3fddce78  sub rsp, 0x08
00007f4e3fddce7c  push rax
00007f4e3fddce7d  push rcx
00007f4e3fddce7e  push rdx
00007f4e3fddce7f  push rdi
00007f4e3fddce80  push rsi
00007f4e3fddce81  push r8
00007f4e3fddce83  push r9
00007f4e3fddce85  push r10
00007f4e3fddce87  push r11
00007f4e3fddce89  sub rsp, 0xF0
00007f4e3fddce90  vmovaps [rsp], xmm0
00007f4e3fddce95  vmovaps [rsp+0x10], xmm1
00007f4e3fddce9b  vmovaps [rsp+0x20], xmm2
00007f4e3fddcea1  vmovaps [rsp+0x30], xmm3
00007f4e3fddcea7  vmovaps [rsp+0x40], xmm4
00007f4e3fddcead  vmovaps [rsp+0x50], xmm5
00007f4e3fddceb3  vmovaps [rsp+0x60], xmm7
00007f4e3fddceb9  vmovaps [rsp+0x70], xmm8
00007f4e3fddcebf  vmovaps [rsp+0x80], xmm9
00007f4e3fddcec8  vmovaps [rsp+0x90], xmm10
00007f4e3fddced1  vmovaps [rsp+0xA0], xmm11
00007f4e3fddceda  vmovaps [rsp+0xB0], xmm12
00007f4e3fddcee3  vmovaps [rsp+0xC0], xmm13
00007f4e3fddceec  vmovaps [rsp+0xD0], xmm14
00007f4e3fddcef5  vmovaps [rsp+0xE0], xmm15
00007f4e3fddcefe  sub rsp, 0x30
00007f4e3fddcf02  movaps [rsp], xmm6
00007f4e3fddcf06  movaps [rsp+0x10], xmm12
00007f4e3fddcf0c  movaps [rsp+0x20], xmm11
00007f4e3fddcf12  lea rdi, [rsp]
00007f4e3fddcf16  mov esi, 0x00
00007f4e3fddcf1b  mov rax, 0x5D97141E9530
00007f4e3fddcf25  call rax
00007f4e3fddcf27  movaps xmm6, [rsp]
00007f4e3fddcf2b  add rsp, 0x30
00007f4e3fddcf2f  vmovaps xmm0, [rsp]
00007f4e3fddcf34  vmovaps xmm1, [rsp+0x10]
00007f4e3fddcf3a  vmovaps xmm2, [rsp+0x20]
00007f4e3fddcf40  vmovaps xmm3, [rsp+0x30]
00007f4e3fddcf46  vmovaps xmm4, [rsp+0x40]
00007f4e3fddcf4c  vmovaps xmm5, [rsp+0x50]
00007f4e3fddcf52  vmovaps xmm7, [rsp+0x60]
00007f4e3fddcf58  vmovaps xmm8, [rsp+0x70]
00007f4e3fddcf5e  vmovaps xmm9, [rsp+0x80]
00007f4e3fddcf67  vmovaps xmm10, [rsp+0x90]
00007f4e3fddcf70  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddcf79  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddcf82  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddcf8b  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddcf94  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddcf9d  add rsp, 0xF0
00007f4e3fddcfa4  pop r11
00007f4e3fddcfa6  pop r10
00007f4e3fddcfa8  pop r9
00007f4e3fddcfaa  pop r8
00007f4e3fddcfac  pop rsi
00007f4e3fddcfad  pop rdi
00007f4e3fddcfae  pop rdx
00007f4e3fddcfaf  pop rcx
00007f4e3fddcfb0  pop rax
00007f4e3fddcfb1  add rsp, 0x08
00007f4e3fddcfb5  jmp 0x00007F4E3FDDBBD4
00007f4e3fddcfba  sub rsp, 0x08
00007f4e3fddcfbe  push rax
00007f4e3fddcfbf  push rcx
00007f4e3fddcfc0  push rdx
00007f4e3fddcfc1  push rdi
00007f4e3fddcfc2  push rsi
00007f4e3fddcfc3  push r8
00007f4e3fddcfc5  push r9
00007f4e3fddcfc7  push r10
00007f4e3fddcfc9  push r11
00007f4e3fddcfcb  sub rsp, 0xF0
00007f4e3fddcfd2  vmovaps [rsp], xmm0
00007f4e3fddcfd7  vmovaps [rsp+0x10], xmm1
00007f4e3fddcfdd  vmovaps [rsp+0x20], xmm2
00007f4e3fddcfe3  vmovaps [rsp+0x30], xmm4
00007f4e3fddcfe9  vmovaps [rsp+0x40], xmm5
00007f4e3fddcfef  vmovaps [rsp+0x50], xmm6
00007f4e3fddcff5  vmovaps [rsp+0x60], xmm7
00007f4e3fddcffb  vmovaps [rsp+0x70], xmm8
00007f4e3fddd001  vmovaps [rsp+0x80], xmm9
00007f4e3fddd00a  vmovaps [rsp+0x90], xmm10
00007f4e3fddd013  vmovaps [rsp+0xA0], xmm11
00007f4e3fddd01c  vmovaps [rsp+0xB0], xmm12
00007f4e3fddd025  vmovaps [rsp+0xC0], xmm13
00007f4e3fddd02e  vmovaps [rsp+0xD0], xmm14
00007f4e3fddd037  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd040  sub rsp, 0x30
00007f4e3fddd044  movaps [rsp], xmm3
00007f4e3fddd048  movaps [rsp+0x10], xmm5
00007f4e3fddd04d  movaps [rsp+0x20], xmm4
00007f4e3fddd052  lea rdi, [rsp]
00007f4e3fddd056  mov esi, 0x00
00007f4e3fddd05b  mov rax, 0x5D97141E9530
00007f4e3fddd065  call rax
00007f4e3fddd067  movaps xmm3, [rsp]
00007f4e3fddd06b  add rsp, 0x30
00007f4e3fddd06f  vmovaps xmm0, [rsp]
00007f4e3fddd074  vmovaps xmm1, [rsp+0x10]
00007f4e3fddd07a  vmovaps xmm2, [rsp+0x20]
00007f4e3fddd080  vmovaps xmm4, [rsp+0x30]
00007f4e3fddd086  vmovaps xmm5, [rsp+0x40]
00007f4e3fddd08c  vmovaps xmm6, [rsp+0x50]
00007f4e3fddd092  vmovaps xmm7, [rsp+0x60]
00007f4e3fddd098  vmovaps xmm8, [rsp+0x70]
00007f4e3fddd09e  vmovaps xmm9, [rsp+0x80]
00007f4e3fddd0a7  vmovaps xmm10, [rsp+0x90]
00007f4e3fddd0b0  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddd0b9  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddd0c2  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddd0cb  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddd0d4  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd0dd  add rsp, 0xF0
00007f4e3fddd0e4  pop r11
00007f4e3fddd0e6  pop r10
00007f4e3fddd0e8  pop r9
00007f4e3fddd0ea  pop r8
00007f4e3fddd0ec  pop rsi
00007f4e3fddd0ed  pop rdi
00007f4e3fddd0ee  pop rdx
00007f4e3fddd0ef  pop rcx
00007f4e3fddd0f0  pop rax
00007f4e3fddd0f1  add rsp, 0x08
00007f4e3fddd0f5  jmp 0x00007F4E3FDDBC35
00007f4e3fddd0fa  sub rsp, 0x08
00007f4e3fddd0fe  push rax
00007f4e3fddd0ff  push rcx
00007f4e3fddd100  push rdx
00007f4e3fddd101  push rdi
00007f4e3fddd102  push rsi
00007f4e3fddd103  push r8
00007f4e3fddd105  push r9
00007f4e3fddd107  push r10
00007f4e3fddd109  push r11
00007f4e3fddd10b  sub rsp, 0xF0
00007f4e3fddd112  vmovaps [rsp], xmm0
00007f4e3fddd117  vmovaps [rsp+0x10], xmm1
00007f4e3fddd11d  vmovaps [rsp+0x20], xmm2
00007f4e3fddd123  vmovaps [rsp+0x30], xmm3
00007f4e3fddd129  vmovaps [rsp+0x40], xmm4
00007f4e3fddd12f  vmovaps [rsp+0x50], xmm6
00007f4e3fddd135  vmovaps [rsp+0x60], xmm7
00007f4e3fddd13b  vmovaps [rsp+0x70], xmm8
00007f4e3fddd141  vmovaps [rsp+0x80], xmm9
00007f4e3fddd14a  vmovaps [rsp+0x90], xmm10
00007f4e3fddd153  vmovaps [rsp+0xA0], xmm11
00007f4e3fddd15c  vmovaps [rsp+0xB0], xmm12
00007f4e3fddd165  vmovaps [rsp+0xC0], xmm13
00007f4e3fddd16e  vmovaps [rsp+0xD0], xmm14
00007f4e3fddd177  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd180  sub rsp, 0x30
00007f4e3fddd184  movaps [rsp], xmm5
00007f4e3fddd188  movaps [rsp+0x10], xmm8
00007f4e3fddd18e  movaps [rsp+0x20], xmm15
00007f4e3fddd194  lea rdi, [rsp]
00007f4e3fddd198  mov esi, 0x00
00007f4e3fddd19d  mov rax, 0x5D97141E9530
00007f4e3fddd1a7  call rax
00007f4e3fddd1a9  movaps xmm5, [rsp]
00007f4e3fddd1ad  add rsp, 0x30
00007f4e3fddd1b1  vmovaps xmm0, [rsp]
00007f4e3fddd1b6  vmovaps xmm1, [rsp+0x10]
00007f4e3fddd1bc  vmovaps xmm2, [rsp+0x20]
00007f4e3fddd1c2  vmovaps xmm3, [rsp+0x30]
00007f4e3fddd1c8  vmovaps xmm4, [rsp+0x40]
00007f4e3fddd1ce  vmovaps xmm6, [rsp+0x50]
00007f4e3fddd1d4  vmovaps xmm7, [rsp+0x60]
00007f4e3fddd1da  vmovaps xmm8, [rsp+0x70]
00007f4e3fddd1e0  vmovaps xmm9, [rsp+0x80]
00007f4e3fddd1e9  vmovaps xmm10, [rsp+0x90]
00007f4e3fddd1f2  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddd1fb  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddd204  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddd20d  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddd216  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd21f  add rsp, 0xF0
00007f4e3fddd226  pop r11
00007f4e3fddd228  pop r10
00007f4e3fddd22a  pop r9
00007f4e3fddd22c  pop r8
00007f4e3fddd22e  pop rsi
00007f4e3fddd22f  pop rdi
00007f4e3fddd230  pop rdx
00007f4e3fddd231  pop rcx
00007f4e3fddd232  pop rax
00007f4e3fddd233  add rsp, 0x08
00007f4e3fddd237  jmp 0x00007F4E3FDDBC73
00007f4e3fddd23c  sub rsp, 0x08
00007f4e3fddd240  push rax
00007f4e3fddd241  push rcx
00007f4e3fddd242  push rdx
00007f4e3fddd243  push rdi
00007f4e3fddd244  push rsi
00007f4e3fddd245  push r8
00007f4e3fddd247  push r9
00007f4e3fddd249  push r10
00007f4e3fddd24b  push r11
00007f4e3fddd24d  sub rsp, 0xF0
00007f4e3fddd254  vmovaps [rsp], xmm0
00007f4e3fddd259  vmovaps [rsp+0x10], xmm1
00007f4e3fddd25f  vmovaps [rsp+0x20], xmm2
00007f4e3fddd265  vmovaps [rsp+0x30], xmm3
00007f4e3fddd26b  vmovaps [rsp+0x40], xmm5
00007f4e3fddd271  vmovaps [rsp+0x50], xmm6
00007f4e3fddd277  vmovaps [rsp+0x60], xmm7
00007f4e3fddd27d  vmovaps [rsp+0x70], xmm8
00007f4e3fddd283  vmovaps [rsp+0x80], xmm9
00007f4e3fddd28c  vmovaps [rsp+0x90], xmm10
00007f4e3fddd295  vmovaps [rsp+0xA0], xmm11
00007f4e3fddd29e  vmovaps [rsp+0xB0], xmm12
00007f4e3fddd2a7  vmovaps [rsp+0xC0], xmm13
00007f4e3fddd2b0  vmovaps [rsp+0xD0], xmm14
00007f4e3fddd2b9  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd2c2  sub rsp, 0x30
00007f4e3fddd2c6  movaps [rsp], xmm4
00007f4e3fddd2ca  movaps [rsp+0x10], xmm9
00007f4e3fddd2d0  movaps [rsp+0x20], xmm8
00007f4e3fddd2d6  lea rdi, [rsp]
00007f4e3fddd2da  mov esi, 0x00
00007f4e3fddd2df  mov rax, 0x5D97141E9530
00007f4e3fddd2e9  call rax
00007f4e3fddd2eb  movaps xmm4, [rsp]
00007f4e3fddd2ef  add rsp, 0x30
00007f4e3fddd2f3  vmovaps xmm0, [rsp]
00007f4e3fddd2f8  vmovaps xmm1, [rsp+0x10]
00007f4e3fddd2fe  vmovaps xmm2, [rsp+0x20]
00007f4e3fddd304  vmovaps xmm3, [rsp+0x30]
00007f4e3fddd30a  vmovaps xmm5, [rsp+0x40]
00007f4e3fddd310  vmovaps xmm6, [rsp+0x50]
00007f4e3fddd316  vmovaps xmm7, [rsp+0x60]
00007f4e3fddd31c  vmovaps xmm8, [rsp+0x70]
00007f4e3fddd322  vmovaps xmm9, [rsp+0x80]
00007f4e3fddd32b  vmovaps xmm10, [rsp+0x90]
00007f4e3fddd334  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddd33d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddd346  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddd34f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddd358  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd361  add rsp, 0xF0
00007f4e3fddd368  pop r11
00007f4e3fddd36a  pop r10
00007f4e3fddd36c  pop r9
00007f4e3fddd36e  pop r8
00007f4e3fddd370  pop rsi
00007f4e3fddd371  pop rdi
00007f4e3fddd372  pop rdx
00007f4e3fddd373  pop rcx
00007f4e3fddd374  pop rax
00007f4e3fddd375  add rsp, 0x08
00007f4e3fddd379  jmp 0x00007F4E3FDDBC94
00007f4e3fddd37e  sub rsp, 0x08
00007f4e3fddd382  push rax
00007f4e3fddd383  push rcx
00007f4e3fddd384  push rdx
00007f4e3fddd385  push rdi
00007f4e3fddd386  push rsi
00007f4e3fddd387  push r8
00007f4e3fddd389  push r9
00007f4e3fddd38b  push r10
00007f4e3fddd38d  push r11
00007f4e3fddd38f  sub rsp, 0xF0
00007f4e3fddd396  vmovaps [rsp], xmm0
00007f4e3fddd39b  vmovaps [rsp+0x10], xmm1
00007f4e3fddd3a1  vmovaps [rsp+0x20], xmm2
00007f4e3fddd3a7  vmovaps [rsp+0x30], xmm3
00007f4e3fddd3ad  vmovaps [rsp+0x40], xmm4
00007f4e3fddd3b3  vmovaps [rsp+0x50], xmm5
00007f4e3fddd3b9  vmovaps [rsp+0x60], xmm6
00007f4e3fddd3bf  vmovaps [rsp+0x70], xmm7
00007f4e3fddd3c5  vmovaps [rsp+0x80], xmm8
00007f4e3fddd3ce  vmovaps [rsp+0x90], xmm10
00007f4e3fddd3d7  vmovaps [rsp+0xA0], xmm11
00007f4e3fddd3e0  vmovaps [rsp+0xB0], xmm12
00007f4e3fddd3e9  vmovaps [rsp+0xC0], xmm13
00007f4e3fddd3f2  vmovaps [rsp+0xD0], xmm14
00007f4e3fddd3fb  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd404  sub rsp, 0x30
00007f4e3fddd408  movaps [rsp], xmm9
00007f4e3fddd40d  movaps [rsp+0x10], xmm10
00007f4e3fddd413  movaps [rsp+0x20], xmm8
00007f4e3fddd419  lea rdi, [rsp]
00007f4e3fddd41d  mov esi, 0x00
00007f4e3fddd422  mov rax, 0x5D97141E9530
00007f4e3fddd42c  call rax
00007f4e3fddd42e  movaps xmm9, [rsp]
00007f4e3fddd433  add rsp, 0x30
00007f4e3fddd437  vmovaps xmm0, [rsp]
00007f4e3fddd43c  vmovaps xmm1, [rsp+0x10]
00007f4e3fddd442  vmovaps xmm2, [rsp+0x20]
00007f4e3fddd448  vmovaps xmm3, [rsp+0x30]
00007f4e3fddd44e  vmovaps xmm4, [rsp+0x40]
00007f4e3fddd454  vmovaps xmm5, [rsp+0x50]
00007f4e3fddd45a  vmovaps xmm6, [rsp+0x60]
00007f4e3fddd460  vmovaps xmm7, [rsp+0x70]
00007f4e3fddd466  vmovaps xmm8, [rsp+0x80]
00007f4e3fddd46f  vmovaps xmm10, [rsp+0x90]
00007f4e3fddd478  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddd481  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddd48a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddd493  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddd49c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd4a5  add rsp, 0xF0
00007f4e3fddd4ac  pop r11
00007f4e3fddd4ae  pop r10
00007f4e3fddd4b0  pop r9
00007f4e3fddd4b2  pop r8
00007f4e3fddd4b4  pop rsi
00007f4e3fddd4b5  pop rdi
00007f4e3fddd4b6  pop rdx
00007f4e3fddd4b7  pop rcx
00007f4e3fddd4b8  pop rax
00007f4e3fddd4b9  add rsp, 0x08
00007f4e3fddd4bd  jmp 0x00007F4E3FDDBCAE
00007f4e3fddd4c2  call 0x00007F4E3FCB52F0
00007f4e3fddd4c7  jmp 0x00007F4E3FDDBDC8
00007f4e3fddd4cc  call 0x00007F4E3FCB52F0
00007f4e3fddd4d1  jmp 0x00007F4E3FDDBDDE
00007f4e3fddd4d6  sub rsp, 0x08
00007f4e3fddd4da  push rax
00007f4e3fddd4db  push rcx
00007f4e3fddd4dc  push rdx
00007f4e3fddd4dd  push rdi
00007f4e3fddd4de  push rsi
00007f4e3fddd4df  push r8
00007f4e3fddd4e1  push r9
00007f4e3fddd4e3  push r10
00007f4e3fddd4e5  push r11
00007f4e3fddd4e7  sub rsp, 0xF0
00007f4e3fddd4ee  vmovaps [rsp], xmm0
00007f4e3fddd4f3  vmovaps [rsp+0x10], xmm2
00007f4e3fddd4f9  vmovaps [rsp+0x20], xmm3
00007f4e3fddd4ff  vmovaps [rsp+0x30], xmm4
00007f4e3fddd505  vmovaps [rsp+0x40], xmm5
00007f4e3fddd50b  vmovaps [rsp+0x50], xmm6
00007f4e3fddd511  vmovaps [rsp+0x60], xmm7
00007f4e3fddd517  vmovaps [rsp+0x70], xmm8
00007f4e3fddd51d  vmovaps [rsp+0x80], xmm9
00007f4e3fddd526  vmovaps [rsp+0x90], xmm10
00007f4e3fddd52f  vmovaps [rsp+0xA0], xmm11
00007f4e3fddd538  vmovaps [rsp+0xB0], xmm12
00007f4e3fddd541  vmovaps [rsp+0xC0], xmm13
00007f4e3fddd54a  vmovaps [rsp+0xD0], xmm14
00007f4e3fddd553  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd55c  sub rsp, 0x30
00007f4e3fddd560  movaps [rsp], xmm1
00007f4e3fddd564  movaps [rsp+0x10], xmm6
00007f4e3fddd569  movaps [rsp+0x20], xmm15
00007f4e3fddd56f  lea rdi, [rsp]
00007f4e3fddd573  mov esi, 0x00
00007f4e3fddd578  mov rax, 0x5D97141E9530
00007f4e3fddd582  call rax
00007f4e3fddd584  movaps xmm1, [rsp]
00007f4e3fddd588  add rsp, 0x30
00007f4e3fddd58c  vmovaps xmm0, [rsp]
00007f4e3fddd591  vmovaps xmm2, [rsp+0x10]
00007f4e3fddd597  vmovaps xmm3, [rsp+0x20]
00007f4e3fddd59d  vmovaps xmm4, [rsp+0x30]
00007f4e3fddd5a3  vmovaps xmm5, [rsp+0x40]
00007f4e3fddd5a9  vmovaps xmm6, [rsp+0x50]
00007f4e3fddd5af  vmovaps xmm7, [rsp+0x60]
00007f4e3fddd5b5  vmovaps xmm8, [rsp+0x70]
00007f4e3fddd5bb  vmovaps xmm9, [rsp+0x80]
00007f4e3fddd5c4  vmovaps xmm10, [rsp+0x90]
00007f4e3fddd5cd  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddd5d6  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddd5df  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddd5e8  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddd5f1  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd5fa  add rsp, 0xF0
00007f4e3fddd601  pop r11
00007f4e3fddd603  pop r10
00007f4e3fddd605  pop r9
00007f4e3fddd607  pop r8
00007f4e3fddd609  pop rsi
00007f4e3fddd60a  pop rdi
00007f4e3fddd60b  pop rdx
00007f4e3fddd60c  pop rcx
00007f4e3fddd60d  pop rax
00007f4e3fddd60e  add rsp, 0x08
00007f4e3fddd612  jmp 0x00007F4E3FDDBE1B
00007f4e3fddd617  call 0x00007F4E3FCC4620
00007f4e3fddd61c  jmp 0x00007F4E3FDDBE28
00007f4e3fddd621  sub rsp, 0x08
00007f4e3fddd625  push rax
00007f4e3fddd626  push rcx
00007f4e3fddd627  push rdx
00007f4e3fddd628  push rdi
00007f4e3fddd629  push rsi
00007f4e3fddd62a  push r8
00007f4e3fddd62c  push r9
00007f4e3fddd62e  push r10
00007f4e3fddd630  push r11
00007f4e3fddd632  sub rsp, 0xF0
00007f4e3fddd639  vmovaps [rsp], xmm0
00007f4e3fddd63e  vmovaps [rsp+0x10], xmm1
00007f4e3fddd644  vmovaps [rsp+0x20], xmm2
00007f4e3fddd64a  vmovaps [rsp+0x30], xmm3
00007f4e3fddd650  vmovaps [rsp+0x40], xmm4
00007f4e3fddd656  vmovaps [rsp+0x50], xmm5
00007f4e3fddd65c  vmovaps [rsp+0x60], xmm6
00007f4e3fddd662  vmovaps [rsp+0x70], xmm7
00007f4e3fddd668  vmovaps [rsp+0x80], xmm8
00007f4e3fddd671  vmovaps [rsp+0x90], xmm9
00007f4e3fddd67a  vmovaps [rsp+0xA0], xmm10
00007f4e3fddd683  vmovaps [rsp+0xB0], xmm11
00007f4e3fddd68c  vmovaps [rsp+0xC0], xmm12
00007f4e3fddd695  vmovaps [rsp+0xD0], xmm13
00007f4e3fddd69e  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd6a7  sub rsp, 0x30
00007f4e3fddd6ab  movaps [rsp], xmm14
00007f4e3fddd6b0  movaps [rsp+0x10], xmm4
00007f4e3fddd6b5  movaps [rsp+0x20], xmm3
00007f4e3fddd6ba  lea rdi, [rsp]
00007f4e3fddd6be  mov esi, 0x00
00007f4e3fddd6c3  mov rax, 0x5D97141E9530
00007f4e3fddd6cd  call rax
00007f4e3fddd6cf  movaps xmm14, [rsp]
00007f4e3fddd6d4  add rsp, 0x30
00007f4e3fddd6d8  vmovaps xmm0, [rsp]
00007f4e3fddd6dd  vmovaps xmm1, [rsp+0x10]
00007f4e3fddd6e3  vmovaps xmm2, [rsp+0x20]
00007f4e3fddd6e9  vmovaps xmm3, [rsp+0x30]
00007f4e3fddd6ef  vmovaps xmm4, [rsp+0x40]
00007f4e3fddd6f5  vmovaps xmm5, [rsp+0x50]
00007f4e3fddd6fb  vmovaps xmm6, [rsp+0x60]
00007f4e3fddd701  vmovaps xmm7, [rsp+0x70]
00007f4e3fddd707  vmovaps xmm8, [rsp+0x80]
00007f4e3fddd710  vmovaps xmm9, [rsp+0x90]
00007f4e3fddd719  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddd722  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddd72b  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddd734  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddd73d  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd746  add rsp, 0xF0
00007f4e3fddd74d  pop r11
00007f4e3fddd74f  pop r10
00007f4e3fddd751  pop r9
00007f4e3fddd753  pop r8
00007f4e3fddd755  pop rsi
00007f4e3fddd756  pop rdi
00007f4e3fddd757  pop rdx
00007f4e3fddd758  pop rcx
00007f4e3fddd759  pop rax
00007f4e3fddd75a  add rsp, 0x08
00007f4e3fddd75e  jmp 0x00007F4E3FDDBE42
00007f4e3fddd763  sub rsp, 0x08
00007f4e3fddd767  push rax
00007f4e3fddd768  push rcx
00007f4e3fddd769  push rdx
00007f4e3fddd76a  push rdi
00007f4e3fddd76b  push rsi
00007f4e3fddd76c  push r8
00007f4e3fddd76e  push r9
00007f4e3fddd770  push r10
00007f4e3fddd772  push r11
00007f4e3fddd774  sub rsp, 0xF0
00007f4e3fddd77b  vmovaps [rsp], xmm0
00007f4e3fddd780  vmovaps [rsp+0x10], xmm1
00007f4e3fddd786  vmovaps [rsp+0x20], xmm2
00007f4e3fddd78c  vmovaps [rsp+0x30], xmm3
00007f4e3fddd792  vmovaps [rsp+0x40], xmm4
00007f4e3fddd798  vmovaps [rsp+0x50], xmm5
00007f4e3fddd79e  vmovaps [rsp+0x60], xmm7
00007f4e3fddd7a4  vmovaps [rsp+0x70], xmm8
00007f4e3fddd7aa  vmovaps [rsp+0x80], xmm9
00007f4e3fddd7b3  vmovaps [rsp+0x90], xmm10
00007f4e3fddd7bc  vmovaps [rsp+0xA0], xmm11
00007f4e3fddd7c5  vmovaps [rsp+0xB0], xmm12
00007f4e3fddd7ce  vmovaps [rsp+0xC0], xmm13
00007f4e3fddd7d7  vmovaps [rsp+0xD0], xmm14
00007f4e3fddd7e0  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd7e9  sub rsp, 0x30
00007f4e3fddd7ed  movaps [rsp], xmm6
00007f4e3fddd7f1  movaps [rsp+0x10], xmm9
00007f4e3fddd7f7  movaps [rsp+0x20], xmm7
00007f4e3fddd7fc  lea rdi, [rsp]
00007f4e3fddd800  mov esi, 0x00
00007f4e3fddd805  mov rax, 0x5D97141E9530
00007f4e3fddd80f  call rax
00007f4e3fddd811  movaps xmm6, [rsp]
00007f4e3fddd815  add rsp, 0x30
00007f4e3fddd819  vmovaps xmm0, [rsp]
00007f4e3fddd81e  vmovaps xmm1, [rsp+0x10]
00007f4e3fddd824  vmovaps xmm2, [rsp+0x20]
00007f4e3fddd82a  vmovaps xmm3, [rsp+0x30]
00007f4e3fddd830  vmovaps xmm4, [rsp+0x40]
00007f4e3fddd836  vmovaps xmm5, [rsp+0x50]
00007f4e3fddd83c  vmovaps xmm7, [rsp+0x60]
00007f4e3fddd842  vmovaps xmm8, [rsp+0x70]
00007f4e3fddd848  vmovaps xmm9, [rsp+0x80]
00007f4e3fddd851  vmovaps xmm10, [rsp+0x90]
00007f4e3fddd85a  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddd863  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddd86c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddd875  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddd87e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd887  add rsp, 0xF0
00007f4e3fddd88e  pop r11
00007f4e3fddd890  pop r10
00007f4e3fddd892  pop r9
00007f4e3fddd894  pop r8
00007f4e3fddd896  pop rsi
00007f4e3fddd897  pop rdi
00007f4e3fddd898  pop rdx
00007f4e3fddd899  pop rcx
00007f4e3fddd89a  pop rax
00007f4e3fddd89b  add rsp, 0x08
00007f4e3fddd89f  jmp 0x00007F4E3FDDBE5A
00007f4e3fddd8a4  sub rsp, 0x08
00007f4e3fddd8a8  push rax
00007f4e3fddd8a9  push rcx
00007f4e3fddd8aa  push rdx
00007f4e3fddd8ab  push rdi
00007f4e3fddd8ac  push rsi
00007f4e3fddd8ad  push r8
00007f4e3fddd8af  push r9
00007f4e3fddd8b1  push r10
00007f4e3fddd8b3  push r11
00007f4e3fddd8b5  sub rsp, 0xF0
00007f4e3fddd8bc  vmovaps [rsp], xmm0
00007f4e3fddd8c1  vmovaps [rsp+0x10], xmm1
00007f4e3fddd8c7  vmovaps [rsp+0x20], xmm2
00007f4e3fddd8cd  vmovaps [rsp+0x30], xmm3
00007f4e3fddd8d3  vmovaps [rsp+0x40], xmm4
00007f4e3fddd8d9  vmovaps [rsp+0x50], xmm5
00007f4e3fddd8df  vmovaps [rsp+0x60], xmm6
00007f4e3fddd8e5  vmovaps [rsp+0x70], xmm8
00007f4e3fddd8eb  vmovaps [rsp+0x80], xmm9
00007f4e3fddd8f4  vmovaps [rsp+0x90], xmm10
00007f4e3fddd8fd  vmovaps [rsp+0xA0], xmm11
00007f4e3fddd906  vmovaps [rsp+0xB0], xmm12
00007f4e3fddd90f  vmovaps [rsp+0xC0], xmm13
00007f4e3fddd918  vmovaps [rsp+0xD0], xmm14
00007f4e3fddd921  vmovaps [rsp+0xE0], xmm15
00007f4e3fddd92a  sub rsp, 0x30
00007f4e3fddd92e  movaps [rsp], xmm7
00007f4e3fddd932  movaps [rsp+0x10], xmm4
00007f4e3fddd937  movaps [rsp+0x20], xmm9
00007f4e3fddd93d  lea rdi, [rsp]
00007f4e3fddd941  mov esi, 0x00
00007f4e3fddd946  mov rax, 0x5D97141E9530
00007f4e3fddd950  call rax
00007f4e3fddd952  movaps xmm7, [rsp]
00007f4e3fddd956  add rsp, 0x30
00007f4e3fddd95a  vmovaps xmm0, [rsp]
00007f4e3fddd95f  vmovaps xmm1, [rsp+0x10]
00007f4e3fddd965  vmovaps xmm2, [rsp+0x20]
00007f4e3fddd96b  vmovaps xmm3, [rsp+0x30]
00007f4e3fddd971  vmovaps xmm4, [rsp+0x40]
00007f4e3fddd977  vmovaps xmm5, [rsp+0x50]
00007f4e3fddd97d  vmovaps xmm6, [rsp+0x60]
00007f4e3fddd983  vmovaps xmm8, [rsp+0x70]
00007f4e3fddd989  vmovaps xmm9, [rsp+0x80]
00007f4e3fddd992  vmovaps xmm10, [rsp+0x90]
00007f4e3fddd99b  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddd9a4  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddd9ad  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddd9b6  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddd9bf  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddd9c8  add rsp, 0xF0
00007f4e3fddd9cf  pop r11
00007f4e3fddd9d1  pop r10
00007f4e3fddd9d3  pop r9
00007f4e3fddd9d5  pop r8
00007f4e3fddd9d7  pop rsi
00007f4e3fddd9d8  pop rdi
00007f4e3fddd9d9  pop rdx
00007f4e3fddd9da  pop rcx
00007f4e3fddd9db  pop rax
00007f4e3fddd9dc  add rsp, 0x08
00007f4e3fddd9e0  jmp 0x00007F4E3FDDBE87
00007f4e3fddd9e5  sub rsp, 0x08
00007f4e3fddd9e9  push rax
00007f4e3fddd9ea  push rcx
00007f4e3fddd9eb  push rdx
00007f4e3fddd9ec  push rdi
00007f4e3fddd9ed  push rsi
00007f4e3fddd9ee  push r8
00007f4e3fddd9f0  push r9
00007f4e3fddd9f2  push r10
00007f4e3fddd9f4  push r11
00007f4e3fddd9f6  sub rsp, 0xF0
00007f4e3fddd9fd  vmovaps [rsp], xmm0
00007f4e3fddda02  vmovaps [rsp+0x10], xmm1
00007f4e3fddda08  vmovaps [rsp+0x20], xmm2
00007f4e3fddda0e  vmovaps [rsp+0x30], xmm3
00007f4e3fddda14  vmovaps [rsp+0x40], xmm5
00007f4e3fddda1a  vmovaps [rsp+0x50], xmm6
00007f4e3fddda20  vmovaps [rsp+0x60], xmm7
00007f4e3fddda26  vmovaps [rsp+0x70], xmm8
00007f4e3fddda2c  vmovaps [rsp+0x80], xmm9
00007f4e3fddda35  vmovaps [rsp+0x90], xmm10
00007f4e3fddda3e  vmovaps [rsp+0xA0], xmm11
00007f4e3fddda47  vmovaps [rsp+0xB0], xmm12
00007f4e3fddda50  vmovaps [rsp+0xC0], xmm13
00007f4e3fddda59  vmovaps [rsp+0xD0], xmm14
00007f4e3fddda62  vmovaps [rsp+0xE0], xmm15
00007f4e3fddda6b  sub rsp, 0x30
00007f4e3fddda6f  movaps [rsp], xmm4
00007f4e3fddda73  movaps [rsp+0x10], xmm15
00007f4e3fddda79  movaps [rsp+0x20], xmm9
00007f4e3fddda7f  lea rdi, [rsp]
00007f4e3fddda83  mov esi, 0x00
00007f4e3fddda88  mov rax, 0x5D97141E9530
00007f4e3fddda92  call rax
00007f4e3fddda94  movaps xmm4, [rsp]
00007f4e3fddda98  add rsp, 0x30
00007f4e3fddda9c  vmovaps xmm0, [rsp]
00007f4e3fdddaa1  vmovaps xmm1, [rsp+0x10]
00007f4e3fdddaa7  vmovaps xmm2, [rsp+0x20]
00007f4e3fdddaad  vmovaps xmm3, [rsp+0x30]
00007f4e3fdddab3  vmovaps xmm5, [rsp+0x40]
00007f4e3fdddab9  vmovaps xmm6, [rsp+0x50]
00007f4e3fdddabf  vmovaps xmm7, [rsp+0x60]
00007f4e3fdddac5  vmovaps xmm8, [rsp+0x70]
00007f4e3fdddacb  vmovaps xmm9, [rsp+0x80]
00007f4e3fdddad4  vmovaps xmm10, [rsp+0x90]
00007f4e3fdddadd  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdddae6  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdddaef  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdddaf8  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdddb01  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdddb0a  add rsp, 0xF0
00007f4e3fdddb11  pop r11
00007f4e3fdddb13  pop r10
00007f4e3fdddb15  pop r9
00007f4e3fdddb17  pop r8
00007f4e3fdddb19  pop rsi
00007f4e3fdddb1a  pop rdi
00007f4e3fdddb1b  pop rdx
00007f4e3fdddb1c  pop rcx
00007f4e3fdddb1d  pop rax
00007f4e3fdddb1e  add rsp, 0x08
00007f4e3fdddb22  jmp 0x00007F4E3FDDBEAC
00007f4e3fdddb27  call 0x00007F4E3FCC4620
00007f4e3fdddb2c  jmp 0x00007F4E3FDDBEB9
00007f4e3fdddb31  sub rsp, 0x08
00007f4e3fdddb35  push rax
00007f4e3fdddb36  push rcx
00007f4e3fdddb37  push rdx
00007f4e3fdddb38  push rdi
00007f4e3fdddb39  push rsi
00007f4e3fdddb3a  push r8
00007f4e3fdddb3c  push r9
00007f4e3fdddb3e  push r10
00007f4e3fdddb40  push r11
00007f4e3fdddb42  sub rsp, 0xF0
00007f4e3fdddb49  vmovaps [rsp], xmm0
00007f4e3fdddb4e  vmovaps [rsp+0x10], xmm1
00007f4e3fdddb54  vmovaps [rsp+0x20], xmm2
00007f4e3fdddb5a  vmovaps [rsp+0x30], xmm4
00007f4e3fdddb60  vmovaps [rsp+0x40], xmm5
00007f4e3fdddb66  vmovaps [rsp+0x50], xmm6
00007f4e3fdddb6c  vmovaps [rsp+0x60], xmm7
00007f4e3fdddb72  vmovaps [rsp+0x70], xmm8
00007f4e3fdddb78  vmovaps [rsp+0x80], xmm9
00007f4e3fdddb81  vmovaps [rsp+0x90], xmm10
00007f4e3fdddb8a  vmovaps [rsp+0xA0], xmm11
00007f4e3fdddb93  vmovaps [rsp+0xB0], xmm12
00007f4e3fdddb9c  vmovaps [rsp+0xC0], xmm13
00007f4e3fdddba5  vmovaps [rsp+0xD0], xmm14
00007f4e3fdddbae  vmovaps [rsp+0xE0], xmm15
00007f4e3fdddbb7  sub rsp, 0x30
00007f4e3fdddbbb  movaps [rsp], xmm3
00007f4e3fdddbbf  movaps [rsp+0x10], xmm1
00007f4e3fdddbc4  movaps [rsp+0x20], xmm9
00007f4e3fdddbca  lea rdi, [rsp]
00007f4e3fdddbce  mov esi, 0x00
00007f4e3fdddbd3  mov rax, 0x5D97141E9530
00007f4e3fdddbdd  call rax
00007f4e3fdddbdf  movaps xmm3, [rsp]
00007f4e3fdddbe3  add rsp, 0x30
00007f4e3fdddbe7  vmovaps xmm0, [rsp]
00007f4e3fdddbec  vmovaps xmm1, [rsp+0x10]
00007f4e3fdddbf2  vmovaps xmm2, [rsp+0x20]
00007f4e3fdddbf8  vmovaps xmm4, [rsp+0x30]
00007f4e3fdddbfe  vmovaps xmm5, [rsp+0x40]
00007f4e3fdddc04  vmovaps xmm6, [rsp+0x50]
00007f4e3fdddc0a  vmovaps xmm7, [rsp+0x60]
00007f4e3fdddc10  vmovaps xmm8, [rsp+0x70]
00007f4e3fdddc16  vmovaps xmm9, [rsp+0x80]
00007f4e3fdddc1f  vmovaps xmm10, [rsp+0x90]
00007f4e3fdddc28  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdddc31  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdddc3a  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdddc43  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdddc4c  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdddc55  add rsp, 0xF0
00007f4e3fdddc5c  pop r11
00007f4e3fdddc5e  pop r10
00007f4e3fdddc60  pop r9
00007f4e3fdddc62  pop r8
00007f4e3fdddc64  pop rsi
00007f4e3fdddc65  pop rdi
00007f4e3fdddc66  pop rdx
00007f4e3fdddc67  pop rcx
00007f4e3fdddc68  pop rax
00007f4e3fdddc69  add rsp, 0x08
00007f4e3fdddc6d  jmp 0x00007F4E3FDDBEF6
00007f4e3fdddc72  sub rsp, 0x08
00007f4e3fdddc76  push rax
00007f4e3fdddc77  push rcx
00007f4e3fdddc78  push rdx
00007f4e3fdddc79  push rdi
00007f4e3fdddc7a  push rsi
00007f4e3fdddc7b  push r8
00007f4e3fdddc7d  push r9
00007f4e3fdddc7f  push r10
00007f4e3fdddc81  push r11
00007f4e3fdddc83  sub rsp, 0xF0
00007f4e3fdddc8a  vmovaps [rsp], xmm0
00007f4e3fdddc8f  vmovaps [rsp+0x10], xmm2
00007f4e3fdddc95  vmovaps [rsp+0x20], xmm3
00007f4e3fdddc9b  vmovaps [rsp+0x30], xmm4
00007f4e3fdddca1  vmovaps [rsp+0x40], xmm5
00007f4e3fdddca7  vmovaps [rsp+0x50], xmm6
00007f4e3fdddcad  vmovaps [rsp+0x60], xmm7
00007f4e3fdddcb3  vmovaps [rsp+0x70], xmm8
00007f4e3fdddcb9  vmovaps [rsp+0x80], xmm9
00007f4e3fdddcc2  vmovaps [rsp+0x90], xmm10
00007f4e3fdddccb  vmovaps [rsp+0xA0], xmm11
00007f4e3fdddcd4  vmovaps [rsp+0xB0], xmm12
00007f4e3fdddcdd  vmovaps [rsp+0xC0], xmm13
00007f4e3fdddce6  vmovaps [rsp+0xD0], xmm14
00007f4e3fdddcef  vmovaps [rsp+0xE0], xmm15
00007f4e3fdddcf8  sub rsp, 0x30
00007f4e3fdddcfc  movaps [rsp], xmm1
00007f4e3fdddd00  movaps [rsp+0x10], xmm15
00007f4e3fdddd06  movaps [rsp+0x20], xmm9
00007f4e3fdddd0c  lea rdi, [rsp]
00007f4e3fdddd10  mov esi, 0x00
00007f4e3fdddd15  mov rax, 0x5D97141E9530
00007f4e3fdddd1f  call rax
00007f4e3fdddd21  movaps xmm1, [rsp]
00007f4e3fdddd25  add rsp, 0x30
00007f4e3fdddd29  vmovaps xmm0, [rsp]
00007f4e3fdddd2e  vmovaps xmm2, [rsp+0x10]
00007f4e3fdddd34  vmovaps xmm3, [rsp+0x20]
00007f4e3fdddd3a  vmovaps xmm4, [rsp+0x30]
00007f4e3fdddd40  vmovaps xmm5, [rsp+0x40]
00007f4e3fdddd46  vmovaps xmm6, [rsp+0x50]
00007f4e3fdddd4c  vmovaps xmm7, [rsp+0x60]
00007f4e3fdddd52  vmovaps xmm8, [rsp+0x70]
00007f4e3fdddd58  vmovaps xmm9, [rsp+0x80]
00007f4e3fdddd61  vmovaps xmm10, [rsp+0x90]
00007f4e3fdddd6a  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdddd73  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdddd7c  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdddd85  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdddd8e  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdddd97  add rsp, 0xF0
00007f4e3fdddd9e  pop r11
00007f4e3fdddda0  pop r10
00007f4e3fdddda2  pop r9
00007f4e3fdddda4  pop r8
00007f4e3fdddda6  pop rsi
00007f4e3fdddda7  pop rdi
00007f4e3fdddda8  pop rdx
00007f4e3fdddda9  pop rcx
00007f4e3fddddaa  pop rax
00007f4e3fddddab  add rsp, 0x08
00007f4e3fddddaf  jmp 0x00007F4E3FDDBF7E
00007f4e3fddddb4  call 0x00007F4E3FCC4620
00007f4e3fddddb9  jmp 0x00007F4E3FDDBF8B
00007f4e3fddddbe  sub rsp, 0x08
00007f4e3fddddc2  push rax
00007f4e3fddddc3  push rcx
00007f4e3fddddc4  push rdx
00007f4e3fddddc5  push rdi
00007f4e3fddddc6  push rsi
00007f4e3fddddc7  push r8
00007f4e3fddddc9  push r9
00007f4e3fddddcb  push r10
00007f4e3fddddcd  push r11
00007f4e3fddddcf  sub rsp, 0xF0
00007f4e3fddddd6  vmovaps [rsp], xmm0
00007f4e3fdddddb  vmovaps [rsp+0x10], xmm2
00007f4e3fdddde1  vmovaps [rsp+0x20], xmm3
00007f4e3fdddde7  vmovaps [rsp+0x30], xmm4
00007f4e3fdddded  vmovaps [rsp+0x40], xmm5
00007f4e3fddddf3  vmovaps [rsp+0x50], xmm6
00007f4e3fddddf9  vmovaps [rsp+0x60], xmm7
00007f4e3fddddff  vmovaps [rsp+0x70], xmm8
00007f4e3fddde05  vmovaps [rsp+0x80], xmm9
00007f4e3fddde0e  vmovaps [rsp+0x90], xmm10
00007f4e3fddde17  vmovaps [rsp+0xA0], xmm11
00007f4e3fddde20  vmovaps [rsp+0xB0], xmm12
00007f4e3fddde29  vmovaps [rsp+0xC0], xmm13
00007f4e3fddde32  vmovaps [rsp+0xD0], xmm14
00007f4e3fddde3b  vmovaps [rsp+0xE0], xmm15
00007f4e3fddde44  sub rsp, 0x30
00007f4e3fddde48  movaps [rsp], xmm1
00007f4e3fddde4c  movaps [rsp+0x10], xmm5
00007f4e3fddde51  movaps [rsp+0x20], xmm7
00007f4e3fddde56  lea rdi, [rsp]
00007f4e3fddde5a  mov esi, 0x00
00007f4e3fddde5f  mov rax, 0x5D97141E9530
00007f4e3fddde69  call rax
00007f4e3fddde6b  movaps xmm1, [rsp]
00007f4e3fddde6f  add rsp, 0x30
00007f4e3fddde73  vmovaps xmm0, [rsp]
00007f4e3fddde78  vmovaps xmm2, [rsp+0x10]
00007f4e3fddde7e  vmovaps xmm3, [rsp+0x20]
00007f4e3fddde84  vmovaps xmm4, [rsp+0x30]
00007f4e3fddde8a  vmovaps xmm5, [rsp+0x40]
00007f4e3fddde90  vmovaps xmm6, [rsp+0x50]
00007f4e3fddde96  vmovaps xmm7, [rsp+0x60]
00007f4e3fddde9c  vmovaps xmm8, [rsp+0x70]
00007f4e3fdddea2  vmovaps xmm9, [rsp+0x80]
00007f4e3fdddeab  vmovaps xmm10, [rsp+0x90]
00007f4e3fdddeb4  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdddebd  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdddec6  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdddecf  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddded8  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdddee1  add rsp, 0xF0
00007f4e3fdddee8  pop r11
00007f4e3fdddeea  pop r10
00007f4e3fdddeec  pop r9
00007f4e3fdddeee  pop r8
00007f4e3fdddef0  pop rsi
00007f4e3fdddef1  pop rdi
00007f4e3fdddef2  pop rdx
00007f4e3fdddef3  pop rcx
00007f4e3fdddef4  pop rax
00007f4e3fdddef5  add rsp, 0x08
00007f4e3fdddef9  jmp 0x00007F4E3FDDC030
00007f4e3fdddefe  sub rsp, 0x08
00007f4e3fdddf02  push rax
00007f4e3fdddf03  push rcx
00007f4e3fdddf04  push rdx
00007f4e3fdddf05  push rdi
00007f4e3fdddf06  push rsi
00007f4e3fdddf07  push r8
00007f4e3fdddf09  push r9
00007f4e3fdddf0b  push r10
00007f4e3fdddf0d  push r11
00007f4e3fdddf0f  sub rsp, 0xF0
00007f4e3fdddf16  vmovaps [rsp], xmm0
00007f4e3fdddf1b  vmovaps [rsp+0x10], xmm1
00007f4e3fdddf21  vmovaps [rsp+0x20], xmm2
00007f4e3fdddf27  vmovaps [rsp+0x30], xmm3
00007f4e3fdddf2d  vmovaps [rsp+0x40], xmm4
00007f4e3fdddf33  vmovaps [rsp+0x50], xmm5
00007f4e3fdddf39  vmovaps [rsp+0x60], xmm6
00007f4e3fdddf3f  vmovaps [rsp+0x70], xmm8
00007f4e3fdddf45  vmovaps [rsp+0x80], xmm9
00007f4e3fdddf4e  vmovaps [rsp+0x90], xmm10
00007f4e3fdddf57  vmovaps [rsp+0xA0], xmm11
00007f4e3fdddf60  vmovaps [rsp+0xB0], xmm12
00007f4e3fdddf69  vmovaps [rsp+0xC0], xmm13
00007f4e3fdddf72  vmovaps [rsp+0xD0], xmm14
00007f4e3fdddf7b  vmovaps [rsp+0xE0], xmm15
00007f4e3fdddf84  sub rsp, 0x30
00007f4e3fdddf88  movaps [rsp], xmm7
00007f4e3fdddf8c  movaps [rsp+0x10], xmm5
00007f4e3fdddf91  movaps [rsp+0x20], xmm15
00007f4e3fdddf97  lea rdi, [rsp]
00007f4e3fdddf9b  mov esi, 0x00
00007f4e3fdddfa0  mov rax, 0x5D97141E9530
00007f4e3fdddfaa  call rax
00007f4e3fdddfac  movaps xmm7, [rsp]
00007f4e3fdddfb0  add rsp, 0x30
00007f4e3fdddfb4  vmovaps xmm0, [rsp]
00007f4e3fdddfb9  vmovaps xmm1, [rsp+0x10]
00007f4e3fdddfbf  vmovaps xmm2, [rsp+0x20]
00007f4e3fdddfc5  vmovaps xmm3, [rsp+0x30]
00007f4e3fdddfcb  vmovaps xmm4, [rsp+0x40]
00007f4e3fdddfd1  vmovaps xmm5, [rsp+0x50]
00007f4e3fdddfd7  vmovaps xmm6, [rsp+0x60]
00007f4e3fdddfdd  vmovaps xmm8, [rsp+0x70]
00007f4e3fdddfe3  vmovaps xmm9, [rsp+0x80]
00007f4e3fdddfec  vmovaps xmm10, [rsp+0x90]
00007f4e3fdddff5  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdddffe  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdde007  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdde010  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdde019  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdde022  add rsp, 0xF0
00007f4e3fdde029  pop r11
00007f4e3fdde02b  pop r10
00007f4e3fdde02d  pop r9
00007f4e3fdde02f  pop r8
00007f4e3fdde031  pop rsi
00007f4e3fdde032  pop rdi
00007f4e3fdde033  pop rdx
00007f4e3fdde034  pop rcx
00007f4e3fdde035  pop rax
00007f4e3fdde036  add rsp, 0x08
00007f4e3fdde03a  jmp 0x00007F4E3FDDC066
00007f4e3fdde03f  call 0x00007F4E3FCB52F0
00007f4e3fdde044  jmp 0x00007F4E3FDDC073
00007f4e3fdde049  sub rsp, 0x08
00007f4e3fdde04d  push rax
00007f4e3fdde04e  push rcx
00007f4e3fdde04f  push rdx
00007f4e3fdde050  push rdi
00007f4e3fdde051  push rsi
00007f4e3fdde052  push r8
00007f4e3fdde054  push r9
00007f4e3fdde056  push r10
00007f4e3fdde058  push r11
00007f4e3fdde05a  sub rsp, 0xF0
00007f4e3fdde061  vmovaps [rsp], xmm0
00007f4e3fdde066  vmovaps [rsp+0x10], xmm1
00007f4e3fdde06c  vmovaps [rsp+0x20], xmm2
00007f4e3fdde072  vmovaps [rsp+0x30], xmm3
00007f4e3fdde078  vmovaps [rsp+0x40], xmm4
00007f4e3fdde07e  vmovaps [rsp+0x50], xmm5
00007f4e3fdde084  vmovaps [rsp+0x60], xmm6
00007f4e3fdde08a  vmovaps [rsp+0x70], xmm7
00007f4e3fdde090  vmovaps [rsp+0x80], xmm8
00007f4e3fdde099  vmovaps [rsp+0x90], xmm9
00007f4e3fdde0a2  vmovaps [rsp+0xA0], xmm10
00007f4e3fdde0ab  vmovaps [rsp+0xB0], xmm11
00007f4e3fdde0b4  vmovaps [rsp+0xC0], xmm12
00007f4e3fdde0bd  vmovaps [rsp+0xD0], xmm13
00007f4e3fdde0c6  vmovaps [rsp+0xE0], xmm14
00007f4e3fdde0cf  sub rsp, 0x30
00007f4e3fdde0d3  movaps [rsp], xmm15
00007f4e3fdde0d8  movaps [rsp+0x10], xmm5
00007f4e3fdde0dd  movaps [rsp+0x20], xmm3
00007f4e3fdde0e2  lea rdi, [rsp]
00007f4e3fdde0e6  mov esi, 0x00
00007f4e3fdde0eb  mov rax, 0x5D97141E9530
00007f4e3fdde0f5  call rax
00007f4e3fdde0f7  movaps xmm15, [rsp]
00007f4e3fdde0fc  add rsp, 0x30
00007f4e3fdde100  vmovaps xmm0, [rsp]
00007f4e3fdde105  vmovaps xmm1, [rsp+0x10]
00007f4e3fdde10b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdde111  vmovaps xmm3, [rsp+0x30]
00007f4e3fdde117  vmovaps xmm4, [rsp+0x40]
00007f4e3fdde11d  vmovaps xmm5, [rsp+0x50]
00007f4e3fdde123  vmovaps xmm6, [rsp+0x60]
00007f4e3fdde129  vmovaps xmm7, [rsp+0x70]
00007f4e3fdde12f  vmovaps xmm8, [rsp+0x80]
00007f4e3fdde138  vmovaps xmm9, [rsp+0x90]
00007f4e3fdde141  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdde14a  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdde153  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdde15c  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdde165  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdde16e  add rsp, 0xF0
00007f4e3fdde175  pop r11
00007f4e3fdde177  pop r10
00007f4e3fdde179  pop r9
00007f4e3fdde17b  pop r8
00007f4e3fdde17d  pop rsi
00007f4e3fdde17e  pop rdi
00007f4e3fdde17f  pop rdx
00007f4e3fdde180  pop rcx
00007f4e3fdde181  pop rax
00007f4e3fdde182  add rsp, 0x08
00007f4e3fdde186  jmp 0x00007F4E3FDDC099
00007f4e3fdde18b  sub rsp, 0x08
00007f4e3fdde18f  push rax
00007f4e3fdde190  push rcx
00007f4e3fdde191  push rdx
00007f4e3fdde192  push rdi
00007f4e3fdde193  push rsi
00007f4e3fdde194  push r8
00007f4e3fdde196  push r9
00007f4e3fdde198  push r10
00007f4e3fdde19a  push r11
00007f4e3fdde19c  sub rsp, 0xF0
00007f4e3fdde1a3  vmovaps [rsp], xmm0
00007f4e3fdde1a8  vmovaps [rsp+0x10], xmm2
00007f4e3fdde1ae  vmovaps [rsp+0x20], xmm3
00007f4e3fdde1b4  vmovaps [rsp+0x30], xmm4
00007f4e3fdde1ba  vmovaps [rsp+0x40], xmm5
00007f4e3fdde1c0  vmovaps [rsp+0x50], xmm6
00007f4e3fdde1c6  vmovaps [rsp+0x60], xmm7
00007f4e3fdde1cc  vmovaps [rsp+0x70], xmm8
00007f4e3fdde1d2  vmovaps [rsp+0x80], xmm9
00007f4e3fdde1db  vmovaps [rsp+0x90], xmm10
00007f4e3fdde1e4  vmovaps [rsp+0xA0], xmm11
00007f4e3fdde1ed  vmovaps [rsp+0xB0], xmm12
00007f4e3fdde1f6  vmovaps [rsp+0xC0], xmm13
00007f4e3fdde1ff  vmovaps [rsp+0xD0], xmm14
00007f4e3fdde208  vmovaps [rsp+0xE0], xmm15
00007f4e3fdde211  sub rsp, 0x30
00007f4e3fdde215  movaps [rsp], xmm1
00007f4e3fdde219  movaps [rsp+0x10], xmm5
00007f4e3fdde21e  movaps [rsp+0x20], xmm4
00007f4e3fdde223  lea rdi, [rsp]
00007f4e3fdde227  mov esi, 0x00
00007f4e3fdde22c  mov rax, 0x5D97141E9530
00007f4e3fdde236  call rax
00007f4e3fdde238  movaps xmm1, [rsp]
00007f4e3fdde23c  add rsp, 0x30
00007f4e3fdde240  vmovaps xmm0, [rsp]
00007f4e3fdde245  vmovaps xmm2, [rsp+0x10]
00007f4e3fdde24b  vmovaps xmm3, [rsp+0x20]
00007f4e3fdde251  vmovaps xmm4, [rsp+0x30]
00007f4e3fdde257  vmovaps xmm5, [rsp+0x40]
00007f4e3fdde25d  vmovaps xmm6, [rsp+0x50]
00007f4e3fdde263  vmovaps xmm7, [rsp+0x60]
00007f4e3fdde269  vmovaps xmm8, [rsp+0x70]
00007f4e3fdde26f  vmovaps xmm9, [rsp+0x80]
00007f4e3fdde278  vmovaps xmm10, [rsp+0x90]
00007f4e3fdde281  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdde28a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdde293  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdde29c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdde2a5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdde2ae  add rsp, 0xF0
00007f4e3fdde2b5  pop r11
00007f4e3fdde2b7  pop r10
00007f4e3fdde2b9  pop r9
00007f4e3fdde2bb  pop r8
00007f4e3fdde2bd  pop rsi
00007f4e3fdde2be  pop rdi
00007f4e3fdde2bf  pop rdx
00007f4e3fdde2c0  pop rcx
00007f4e3fdde2c1  pop rax
00007f4e3fdde2c2  add rsp, 0x08
00007f4e3fdde2c6  jmp 0x00007F4E3FDDC0B9
00007f4e3fdde2cb  sub rsp, 0x08
00007f4e3fdde2cf  push rax
00007f4e3fdde2d0  push rcx
00007f4e3fdde2d1  push rdx
00007f4e3fdde2d2  push rdi
00007f4e3fdde2d3  push rsi
00007f4e3fdde2d4  push r8
00007f4e3fdde2d6  push r9
00007f4e3fdde2d8  push r10
00007f4e3fdde2da  push r11
00007f4e3fdde2dc  sub rsp, 0xF0
00007f4e3fdde2e3  vmovaps [rsp], xmm0
00007f4e3fdde2e8  vmovaps [rsp+0x10], xmm1
00007f4e3fdde2ee  vmovaps [rsp+0x20], xmm2
00007f4e3fdde2f4  vmovaps [rsp+0x30], xmm3
00007f4e3fdde2fa  vmovaps [rsp+0x40], xmm5
00007f4e3fdde300  vmovaps [rsp+0x50], xmm6
00007f4e3fdde306  vmovaps [rsp+0x60], xmm7
00007f4e3fdde30c  vmovaps [rsp+0x70], xmm8
00007f4e3fdde312  vmovaps [rsp+0x80], xmm9
00007f4e3fdde31b  vmovaps [rsp+0x90], xmm10
00007f4e3fdde324  vmovaps [rsp+0xA0], xmm11
00007f4e3fdde32d  vmovaps [rsp+0xB0], xmm12
00007f4e3fdde336  vmovaps [rsp+0xC0], xmm13
00007f4e3fdde33f  vmovaps [rsp+0xD0], xmm14
00007f4e3fdde348  vmovaps [rsp+0xE0], xmm15
00007f4e3fdde351  sub rsp, 0x30
00007f4e3fdde355  movaps [rsp], xmm4
00007f4e3fdde359  movaps [rsp+0x10], xmm3
00007f4e3fdde35e  movaps [rsp+0x20], xmm5
00007f4e3fdde363  lea rdi, [rsp]
00007f4e3fdde367  mov esi, 0x00
00007f4e3fdde36c  mov rax, 0x5D97141E9530
00007f4e3fdde376  call rax
00007f4e3fdde378  movaps xmm4, [rsp]
00007f4e3fdde37c  add rsp, 0x30
00007f4e3fdde380  vmovaps xmm0, [rsp]
00007f4e3fdde385  vmovaps xmm1, [rsp+0x10]
00007f4e3fdde38b  vmovaps xmm2, [rsp+0x20]
00007f4e3fdde391  vmovaps xmm3, [rsp+0x30]
00007f4e3fdde397  vmovaps xmm5, [rsp+0x40]
00007f4e3fdde39d  vmovaps xmm6, [rsp+0x50]
00007f4e3fdde3a3  vmovaps xmm7, [rsp+0x60]
00007f4e3fdde3a9  vmovaps xmm8, [rsp+0x70]
00007f4e3fdde3af  vmovaps xmm9, [rsp+0x80]
00007f4e3fdde3b8  vmovaps xmm10, [rsp+0x90]
00007f4e3fdde3c1  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdde3ca  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdde3d3  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdde3dc  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdde3e5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdde3ee  add rsp, 0xF0
00007f4e3fdde3f5  pop r11
00007f4e3fdde3f7  pop r10
00007f4e3fdde3f9  pop r9
00007f4e3fdde3fb  pop r8
00007f4e3fdde3fd  pop rsi
00007f4e3fdde3fe  pop rdi
00007f4e3fdde3ff  pop rdx
00007f4e3fdde400  pop rcx
00007f4e3fdde401  pop rax
00007f4e3fdde402  add rsp, 0x08
00007f4e3fdde406  jmp 0x00007F4E3FDDC107
00007f4e3fdde40b  call 0x00007F4E3FCB52F0
00007f4e3fdde410  jmp 0x00007F4E3FDDC114
00007f4e3fdde415  sub rsp, 0x08
00007f4e3fdde419  push rax
00007f4e3fdde41a  push rcx
00007f4e3fdde41b  push rdx
00007f4e3fdde41c  push rdi
00007f4e3fdde41d  push rsi
00007f4e3fdde41e  push r8
00007f4e3fdde420  push r9
00007f4e3fdde422  push r10
00007f4e3fdde424  push r11
00007f4e3fdde426  sub rsp, 0xF0
00007f4e3fdde42d  vmovaps [rsp], xmm0
00007f4e3fdde432  vmovaps [rsp+0x10], xmm1
00007f4e3fdde438  vmovaps [rsp+0x20], xmm2
00007f4e3fdde43e  vmovaps [rsp+0x30], xmm3
00007f4e3fdde444  vmovaps [rsp+0x40], xmm4
00007f4e3fdde44a  vmovaps [rsp+0x50], xmm6
00007f4e3fdde450  vmovaps [rsp+0x60], xmm7
00007f4e3fdde456  vmovaps [rsp+0x70], xmm8
00007f4e3fdde45c  vmovaps [rsp+0x80], xmm9
00007f4e3fdde465  vmovaps [rsp+0x90], xmm10
00007f4e3fdde46e  vmovaps [rsp+0xA0], xmm11
00007f4e3fdde477  vmovaps [rsp+0xB0], xmm12
00007f4e3fdde480  vmovaps [rsp+0xC0], xmm13
00007f4e3fdde489  vmovaps [rsp+0xD0], xmm14
00007f4e3fdde492  vmovaps [rsp+0xE0], xmm15
00007f4e3fdde49b  sub rsp, 0x30
00007f4e3fdde49f  movaps [rsp], xmm5
00007f4e3fdde4a3  movaps [rsp+0x10], xmm6
00007f4e3fdde4a8  movaps [rsp+0x20], xmm3
00007f4e3fdde4ad  lea rdi, [rsp]
00007f4e3fdde4b1  mov esi, 0x00
00007f4e3fdde4b6  mov rax, 0x5D97141E9530
00007f4e3fdde4c0  call rax
00007f4e3fdde4c2  movaps xmm5, [rsp]
00007f4e3fdde4c6  add rsp, 0x30
00007f4e3fdde4ca  vmovaps xmm0, [rsp]
00007f4e3fdde4cf  vmovaps xmm1, [rsp+0x10]
00007f4e3fdde4d5  vmovaps xmm2, [rsp+0x20]
00007f4e3fdde4db  vmovaps xmm3, [rsp+0x30]
00007f4e3fdde4e1  vmovaps xmm4, [rsp+0x40]
00007f4e3fdde4e7  vmovaps xmm6, [rsp+0x50]
00007f4e3fdde4ed  vmovaps xmm7, [rsp+0x60]
00007f4e3fdde4f3  vmovaps xmm8, [rsp+0x70]
00007f4e3fdde4f9  vmovaps xmm9, [rsp+0x80]
00007f4e3fdde502  vmovaps xmm10, [rsp+0x90]
00007f4e3fdde50b  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdde514  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdde51d  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdde526  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdde52f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdde538  add rsp, 0xF0
00007f4e3fdde53f  pop r11
00007f4e3fdde541  pop r10
00007f4e3fdde543  pop r9
00007f4e3fdde545  pop r8
00007f4e3fdde547  pop rsi
00007f4e3fdde548  pop rdi
00007f4e3fdde549  pop rdx
00007f4e3fdde54a  pop rcx
00007f4e3fdde54b  pop rax
00007f4e3fdde54c  add rsp, 0x08
00007f4e3fdde550  jmp 0x00007F4E3FDDC13A
00007f4e3fdde555  sub rsp, 0x08
00007f4e3fdde559  push rax
00007f4e3fdde55a  push rcx
00007f4e3fdde55b  push rdx
00007f4e3fdde55c  push rdi
00007f4e3fdde55d  push rsi
00007f4e3fdde55e  push r8
00007f4e3fdde560  push r9
00007f4e3fdde562  push r10
00007f4e3fdde564  push r11
00007f4e3fdde566  sub rsp, 0xF0
00007f4e3fdde56d  vmovaps [rsp], xmm0
00007f4e3fdde572  vmovaps [rsp+0x10], xmm1
00007f4e3fdde578  vmovaps [rsp+0x20], xmm2
00007f4e3fdde57e  vmovaps [rsp+0x30], xmm3
00007f4e3fdde584  vmovaps [rsp+0x40], xmm4
00007f4e3fdde58a  vmovaps [rsp+0x50], xmm5
00007f4e3fdde590  vmovaps [rsp+0x60], xmm7
00007f4e3fdde596  vmovaps [rsp+0x70], xmm8
00007f4e3fdde59c  vmovaps [rsp+0x80], xmm9
00007f4e3fdde5a5  vmovaps [rsp+0x90], xmm10
00007f4e3fdde5ae  vmovaps [rsp+0xA0], xmm11
00007f4e3fdde5b7  vmovaps [rsp+0xB0], xmm12
00007f4e3fdde5c0  vmovaps [rsp+0xC0], xmm13
00007f4e3fdde5c9  vmovaps [rsp+0xD0], xmm14
00007f4e3fdde5d2  vmovaps [rsp+0xE0], xmm15
00007f4e3fdde5db  sub rsp, 0x30
00007f4e3fdde5df  movaps [rsp], xmm6
00007f4e3fdde5e3  movaps [rsp+0x10], xmm9
00007f4e3fdde5e9  movaps [rsp+0x20], xmm1
00007f4e3fdde5ee  lea rdi, [rsp]
00007f4e3fdde5f2  mov esi, 0x00
00007f4e3fdde5f7  mov rax, 0x5D97141E9530
00007f4e3fdde601  call rax
00007f4e3fdde603  movaps xmm6, [rsp]
00007f4e3fdde607  add rsp, 0x30
00007f4e3fdde60b  vmovaps xmm0, [rsp]
00007f4e3fdde610  vmovaps xmm1, [rsp+0x10]
00007f4e3fdde616  vmovaps xmm2, [rsp+0x20]
00007f4e3fdde61c  vmovaps xmm3, [rsp+0x30]
00007f4e3fdde622  vmovaps xmm4, [rsp+0x40]
00007f4e3fdde628  vmovaps xmm5, [rsp+0x50]
00007f4e3fdde62e  vmovaps xmm7, [rsp+0x60]
00007f4e3fdde634  vmovaps xmm8, [rsp+0x70]
00007f4e3fdde63a  vmovaps xmm9, [rsp+0x80]
00007f4e3fdde643  vmovaps xmm10, [rsp+0x90]
00007f4e3fdde64c  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdde655  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdde65e  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdde667  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdde670  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdde679  add rsp, 0xF0
00007f4e3fdde680  pop r11
00007f4e3fdde682  pop r10
00007f4e3fdde684  pop r9
00007f4e3fdde686  pop r8
00007f4e3fdde688  pop rsi
00007f4e3fdde689  pop rdi
00007f4e3fdde68a  pop rdx
00007f4e3fdde68b  pop rcx
00007f4e3fdde68c  pop rax
00007f4e3fdde68d  add rsp, 0x08
00007f4e3fdde691  jmp 0x00007F4E3FDDC15E
00007f4e3fdde696  sub rsp, 0x08
00007f4e3fdde69a  push rax
00007f4e3fdde69b  push rcx
00007f4e3fdde69c  push rdx
00007f4e3fdde69d  push rdi
00007f4e3fdde69e  push rsi
00007f4e3fdde69f  push r8
00007f4e3fdde6a1  push r9
00007f4e3fdde6a3  push r10
00007f4e3fdde6a5  push r11
00007f4e3fdde6a7  sub rsp, 0xF0
00007f4e3fdde6ae  vmovaps [rsp], xmm0
00007f4e3fdde6b3  vmovaps [rsp+0x10], xmm1
00007f4e3fdde6b9  vmovaps [rsp+0x20], xmm2
00007f4e3fdde6bf  vmovaps [rsp+0x30], xmm3
00007f4e3fdde6c5  vmovaps [rsp+0x40], xmm4
00007f4e3fdde6cb  vmovaps [rsp+0x50], xmm5
00007f4e3fdde6d1  vmovaps [rsp+0x60], xmm6
00007f4e3fdde6d7  vmovaps [rsp+0x70], xmm7
00007f4e3fdde6dd  vmovaps [rsp+0x80], xmm8
00007f4e3fdde6e6  vmovaps [rsp+0x90], xmm10
00007f4e3fdde6ef  vmovaps [rsp+0xA0], xmm11
00007f4e3fdde6f8  vmovaps [rsp+0xB0], xmm12
00007f4e3fdde701  vmovaps [rsp+0xC0], xmm13
00007f4e3fdde70a  vmovaps [rsp+0xD0], xmm14
00007f4e3fdde713  vmovaps [rsp+0xE0], xmm15
00007f4e3fdde71c  sub rsp, 0x30
00007f4e3fdde720  movaps [rsp], xmm9
00007f4e3fdde725  movaps [rsp+0x10], xmm3
00007f4e3fdde72a  movaps [rsp+0x20], xmm1
00007f4e3fdde72f  lea rdi, [rsp]
00007f4e3fdde733  mov esi, 0x00
00007f4e3fdde738  mov rax, 0x5D97141E9530
00007f4e3fdde742  call rax
00007f4e3fdde744  movaps xmm9, [rsp]
00007f4e3fdde749  add rsp, 0x30
00007f4e3fdde74d  vmovaps xmm0, [rsp]
00007f4e3fdde752  vmovaps xmm1, [rsp+0x10]
00007f4e3fdde758  vmovaps xmm2, [rsp+0x20]
00007f4e3fdde75e  vmovaps xmm3, [rsp+0x30]
00007f4e3fdde764  vmovaps xmm4, [rsp+0x40]
00007f4e3fdde76a  vmovaps xmm5, [rsp+0x50]
00007f4e3fdde770  vmovaps xmm6, [rsp+0x60]
00007f4e3fdde776  vmovaps xmm7, [rsp+0x70]
00007f4e3fdde77c  vmovaps xmm8, [rsp+0x80]
00007f4e3fdde785  vmovaps xmm10, [rsp+0x90]
00007f4e3fdde78e  vmovaps xmm11, [rsp+0xA0]
00007f4e3fdde797  vmovaps xmm12, [rsp+0xB0]
00007f4e3fdde7a0  vmovaps xmm13, [rsp+0xC0]
00007f4e3fdde7a9  vmovaps xmm14, [rsp+0xD0]
00007f4e3fdde7b2  vmovaps xmm15, [rsp+0xE0]
00007f4e3fdde7bb  add rsp, 0xF0
00007f4e3fdde7c2  pop r11
00007f4e3fdde7c4  pop r10
00007f4e3fdde7c6  pop r9
00007f4e3fdde7c8  pop r8
00007f4e3fdde7ca  pop rsi
00007f4e3fdde7cb  pop rdi
00007f4e3fdde7cc  pop rdx
00007f4e3fdde7cd  pop rcx
00007f4e3fdde7ce  pop rax
00007f4e3fdde7cf  add rsp, 0x08
00007f4e3fdde7d3  jmp 0x00007F4E3FDDC1AA
00007f4e3fdde7d8  call 0x00007F4E3FCB52F0
00007f4e3fdde7dd  jmp 0x00007F4E3FDDC1B7
00007f4e3fdde7e2  sub rsp, 0x08
00007f4e3fdde7e6  push rax
00007f4e3fdde7e7  push rcx
00007f4e3fdde7e8  push rdx
00007f4e3fdde7e9  push rdi
00007f4e3fdde7ea  push rsi
00007f4e3fdde7eb  push r8
00007f4e3fdde7ed  push r9
00007f4e3fdde7ef  push r10
00007f4e3fdde7f1  push r11
00007f4e3fdde7f3  sub rsp, 0xF0
00007f4e3fdde7fa  vmovaps [rsp], xmm0
00007f4e3fdde7ff  vmovaps [rsp+0x10], xmm1
00007f4e3fdde805  vmovaps [rsp+0x20], xmm2
00007f4e3fdde80b  vmovaps [rsp+0x30], xmm3
00007f4e3fdde811  vmovaps [rsp+0x40], xmm4
00007f4e3fdde817  vmovaps [rsp+0x50], xmm5
00007f4e3fdde81d  vmovaps [rsp+0x60], xmm6
00007f4e3fdde823  vmovaps [rsp+0x70], xmm7
00007f4e3fdde829  vmovaps [rsp+0x80], xmm8
00007f4e3fdde832  vmovaps [rsp+0x90], xmm9
00007f4e3fdde83b  vmovaps [rsp+0xA0], xmm10
00007f4e3fdde844  vmovaps [rsp+0xB0], xmm11
00007f4e3fdde84d  vmovaps [rsp+0xC0], xmm12
00007f4e3fdde856  vmovaps [rsp+0xD0], xmm13
00007f4e3fdde85f  vmovaps [rsp+0xE0], xmm14
00007f4e3fdde868  sub rsp, 0x30
00007f4e3fdde86c  movaps [rsp], xmm15
00007f4e3fdde871  movaps [rsp+0x10], xmm3
00007f4e3fdde876  movaps [rsp+0x20], xmm7
00007f4e3fdde87b  lea rdi, [rsp]
00007f4e3fdde87f  mov esi, 0x00
00007f4e3fdde884  mov rax, 0x5D97141E9530
00007f4e3fdde88e  call rax
00007f4e3fdde890  movaps xmm15, [rsp]
00007f4e3fdde895  add rsp, 0x30
00007f4e3fdde899  vmovaps xmm0, [rsp]
00007f4e3fdde89e  vmovaps xmm1, [rsp+0x10]
00007f4e3fdde8a4  vmovaps xmm2, [rsp+0x20]
00007f4e3fdde8aa  vmovaps xmm3, [rsp+0x30]
00007f4e3fdde8b0  vmovaps xmm4, [rsp+0x40]
00007f4e3fdde8b6  vmovaps xmm5, [rsp+0x50]
00007f4e3fdde8bc  vmovaps xmm6, [rsp+0x60]
00007f4e3fdde8c2  vmovaps xmm7, [rsp+0x70]
00007f4e3fdde8c8  vmovaps xmm8, [rsp+0x80]
00007f4e3fdde8d1  vmovaps xmm9, [rsp+0x90]
00007f4e3fdde8da  vmovaps xmm10, [rsp+0xA0]
00007f4e3fdde8e3  vmovaps xmm11, [rsp+0xB0]
00007f4e3fdde8ec  vmovaps xmm12, [rsp+0xC0]
00007f4e3fdde8f5  vmovaps xmm13, [rsp+0xD0]
00007f4e3fdde8fe  vmovaps xmm14, [rsp+0xE0]
00007f4e3fdde907  add rsp, 0xF0
00007f4e3fdde90e  pop r11
00007f4e3fdde910  pop r10
00007f4e3fdde912  pop r9
00007f4e3fdde914  pop r8
00007f4e3fdde916  pop rsi
00007f4e3fdde917  pop rdi
00007f4e3fdde918  pop rdx
00007f4e3fdde919  pop rcx
00007f4e3fdde91a  pop rax
00007f4e3fdde91b  add rsp, 0x08
00007f4e3fdde91f  jmp 0x00007F4E3FDDC1E3
00007f4e3fdde924  sub rsp, 0x08
00007f4e3fdde928  push rax
00007f4e3fdde929  push rcx
00007f4e3fdde92a  push rdx
00007f4e3fdde92b  push rdi
00007f4e3fdde92c  push rsi
00007f4e3fdde92d  push r8
00007f4e3fdde92f  push r9
00007f4e3fdde931  push r10
00007f4e3fdde933  push r11
00007f4e3fdde935  sub rsp, 0xF0
00007f4e3fdde93c  vmovaps [rsp], xmm0
00007f4e3fdde941  vmovaps [rsp+0x10], xmm1
00007f4e3fdde947  vmovaps [rsp+0x20], xmm2
00007f4e3fdde94d  vmovaps [rsp+0x30], xmm4
00007f4e3fdde953  vmovaps [rsp+0x40], xmm5
00007f4e3fdde959  vmovaps [rsp+0x50], xmm6
00007f4e3fdde95f  vmovaps [rsp+0x60], xmm7
00007f4e3fdde965  vmovaps [rsp+0x70], xmm8
00007f4e3fdde96b  vmovaps [rsp+0x80], xmm9
00007f4e3fdde974  vmovaps [rsp+0x90], xmm10
00007f4e3fdde97d  vmovaps [rsp+0xA0], xmm11
00007f4e3fdde986  vmovaps [rsp+0xB0], xmm12
00007f4e3fdde98f  vmovaps [rsp+0xC0], xmm13
00007f4e3fdde998  vmovaps [rsp+0xD0], xmm14
00007f4e3fdde9a1  vmovaps [rsp+0xE0], xmm15
00007f4e3fdde9aa  sub rsp, 0x30
00007f4e3fdde9ae  movaps [rsp], xmm3
00007f4e3fdde9b2  movaps [rsp+0x10], xmm1
00007f4e3fdde9b7  movaps [rsp+0x20], xmm15
00007f4e3fdde9bd  lea rdi, [rsp]
00007f4e3fdde9c1  mov esi, 0x00
00007f4e3fdde9c6  mov rax, 0x5D97141E9530
00007f4e3fdde9d0  call rax
00007f4e3fdde9d2  movaps xmm3, [rsp]
00007f4e3fdde9d6  add rsp, 0x30
00007f4e3fdde9da  vmovaps xmm0, [rsp]
00007f4e3fdde9df  vmovaps xmm1, [rsp+0x10]
00007f4e3fdde9e5  vmovaps xmm2, [rsp+0x20]
00007f4e3fdde9eb  vmovaps xmm4, [rsp+0x30]
00007f4e3fdde9f1  vmovaps xmm5, [rsp+0x40]
00007f4e3fdde9f7  vmovaps xmm6, [rsp+0x50]
00007f4e3fdde9fd  vmovaps xmm7, [rsp+0x60]
00007f4e3fddea03  vmovaps xmm8, [rsp+0x70]
00007f4e3fddea09  vmovaps xmm9, [rsp+0x80]
00007f4e3fddea12  vmovaps xmm10, [rsp+0x90]
00007f4e3fddea1b  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddea24  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddea2d  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddea36  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddea3f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddea48  add rsp, 0xF0
00007f4e3fddea4f  pop r11
00007f4e3fddea51  pop r10
00007f4e3fddea53  pop r9
00007f4e3fddea55  pop r8
00007f4e3fddea57  pop rsi
00007f4e3fddea58  pop rdi
00007f4e3fddea59  pop rdx
00007f4e3fddea5a  pop rcx
00007f4e3fddea5b  pop rax
00007f4e3fddea5c  add rsp, 0x08
00007f4e3fddea60  jmp 0x00007F4E3FDDC272
00007f4e3fddea65  call 0x00007F4E3FCB52F0
00007f4e3fddea6a  jmp 0x00007F4E3FDDC27C
00007f4e3fddea6f  sub rsp, 0x08
00007f4e3fddea73  push rax
00007f4e3fddea74  push rcx
00007f4e3fddea75  push rdx
00007f4e3fddea76  push rdi
00007f4e3fddea77  push rsi
00007f4e3fddea78  push r8
00007f4e3fddea7a  push r9
00007f4e3fddea7c  push r10
00007f4e3fddea7e  push r11
00007f4e3fddea80  sub rsp, 0xF0
00007f4e3fddea87  vmovaps [rsp], xmm0
00007f4e3fddea8c  vmovaps [rsp+0x10], xmm1
00007f4e3fddea92  vmovaps [rsp+0x20], xmm2
00007f4e3fddea98  vmovaps [rsp+0x30], xmm3
00007f4e3fddea9e  vmovaps [rsp+0x40], xmm4
00007f4e3fddeaa4  vmovaps [rsp+0x50], xmm5
00007f4e3fddeaaa  vmovaps [rsp+0x60], xmm6
00007f4e3fddeab0  vmovaps [rsp+0x70], xmm7
00007f4e3fddeab6  vmovaps [rsp+0x80], xmm8
00007f4e3fddeabf  vmovaps [rsp+0x90], xmm9
00007f4e3fddeac8  vmovaps [rsp+0xA0], xmm10
00007f4e3fddead1  vmovaps [rsp+0xB0], xmm11
00007f4e3fddeada  vmovaps [rsp+0xC0], xmm12
00007f4e3fddeae3  vmovaps [rsp+0xD0], xmm13
00007f4e3fddeaec  vmovaps [rsp+0xE0], xmm14
00007f4e3fddeaf5  sub rsp, 0x30
00007f4e3fddeaf9  movaps [rsp], xmm15
00007f4e3fddeafe  movaps [rsp+0x10], xmm14
00007f4e3fddeb04  movaps [rsp+0x20], xmm4
00007f4e3fddeb09  lea rdi, [rsp]
00007f4e3fddeb0d  mov esi, 0x00
00007f4e3fddeb12  mov rax, 0x5D97141E9530
00007f4e3fddeb1c  call rax
00007f4e3fddeb1e  movaps xmm15, [rsp]
00007f4e3fddeb23  add rsp, 0x30
00007f4e3fddeb27  vmovaps xmm0, [rsp]
00007f4e3fddeb2c  vmovaps xmm1, [rsp+0x10]
00007f4e3fddeb32  vmovaps xmm2, [rsp+0x20]
00007f4e3fddeb38  vmovaps xmm3, [rsp+0x30]
00007f4e3fddeb3e  vmovaps xmm4, [rsp+0x40]
00007f4e3fddeb44  vmovaps xmm5, [rsp+0x50]
00007f4e3fddeb4a  vmovaps xmm6, [rsp+0x60]
00007f4e3fddeb50  vmovaps xmm7, [rsp+0x70]
00007f4e3fddeb56  vmovaps xmm8, [rsp+0x80]
00007f4e3fddeb5f  vmovaps xmm9, [rsp+0x90]
00007f4e3fddeb68  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddeb71  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddeb7a  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddeb83  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddeb8c  vmovaps xmm14, [rsp+0xE0]
00007f4e3fddeb95  add rsp, 0xF0
00007f4e3fddeb9c  pop r11
00007f4e3fddeb9e  pop r10
00007f4e3fddeba0  pop r9
00007f4e3fddeba2  pop r8
00007f4e3fddeba4  pop rsi
00007f4e3fddeba5  pop rdi
00007f4e3fddeba6  pop rdx
00007f4e3fddeba7  pop rcx
00007f4e3fddeba8  pop rax
00007f4e3fddeba9  add rsp, 0x08
00007f4e3fddebad  jmp 0x00007F4E3FDDC2AA
00007f4e3fddebb2  sub rsp, 0x08
00007f4e3fddebb6  push rax
00007f4e3fddebb7  push rcx
00007f4e3fddebb8  push rdx
00007f4e3fddebb9  push rdi
00007f4e3fddebba  push rsi
00007f4e3fddebbb  push r8
00007f4e3fddebbd  push r9
00007f4e3fddebbf  push r10
00007f4e3fddebc1  push r11
00007f4e3fddebc3  sub rsp, 0xF0
00007f4e3fddebca  vmovaps [rsp], xmm0
00007f4e3fddebcf  vmovaps [rsp+0x10], xmm1
00007f4e3fddebd5  vmovaps [rsp+0x20], xmm2
00007f4e3fddebdb  vmovaps [rsp+0x30], xmm3
00007f4e3fddebe1  vmovaps [rsp+0x40], xmm4
00007f4e3fddebe7  vmovaps [rsp+0x50], xmm5
00007f4e3fddebed  vmovaps [rsp+0x60], xmm6
00007f4e3fddebf3  vmovaps [rsp+0x70], xmm7
00007f4e3fddebf9  vmovaps [rsp+0x80], xmm8
00007f4e3fddec02  vmovaps [rsp+0x90], xmm9
00007f4e3fddec0b  vmovaps [rsp+0xA0], xmm10
00007f4e3fddec14  vmovaps [rsp+0xB0], xmm11
00007f4e3fddec1d  vmovaps [rsp+0xC0], xmm12
00007f4e3fddec26  vmovaps [rsp+0xD0], xmm13
00007f4e3fddec2f  vmovaps [rsp+0xE0], xmm15
00007f4e3fddec38  sub rsp, 0x30
00007f4e3fddec3c  movaps [rsp], xmm14
00007f4e3fddec41  movaps [rsp+0x10], xmm2
00007f4e3fddec46  movaps [rsp+0x20], xmm1
00007f4e3fddec4b  lea rdi, [rsp]
00007f4e3fddec4f  mov esi, 0x00
00007f4e3fddec54  mov rax, 0x5D97141E9530
00007f4e3fddec5e  call rax
00007f4e3fddec60  movaps xmm14, [rsp]
00007f4e3fddec65  add rsp, 0x30
00007f4e3fddec69  vmovaps xmm0, [rsp]
00007f4e3fddec6e  vmovaps xmm1, [rsp+0x10]
00007f4e3fddec74  vmovaps xmm2, [rsp+0x20]
00007f4e3fddec7a  vmovaps xmm3, [rsp+0x30]
00007f4e3fddec80  vmovaps xmm4, [rsp+0x40]
00007f4e3fddec86  vmovaps xmm5, [rsp+0x50]
00007f4e3fddec8c  vmovaps xmm6, [rsp+0x60]
00007f4e3fddec92  vmovaps xmm7, [rsp+0x70]
00007f4e3fddec98  vmovaps xmm8, [rsp+0x80]
00007f4e3fddeca1  vmovaps xmm9, [rsp+0x90]
00007f4e3fddecaa  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddecb3  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddecbc  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddecc5  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddecce  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddecd7  add rsp, 0xF0
00007f4e3fddecde  pop r11
00007f4e3fddece0  pop r10
00007f4e3fddece2  pop r9
00007f4e3fddece4  pop r8
00007f4e3fddece6  pop rsi
00007f4e3fddece7  pop rdi
00007f4e3fddece8  pop rdx
00007f4e3fddece9  pop rcx
00007f4e3fddecea  pop rax
00007f4e3fddeceb  add rsp, 0x08
00007f4e3fddecef  jmp 0x00007F4E3FDDC2D0
00007f4e3fddecf4  sub rsp, 0x08
00007f4e3fddecf8  push rax
00007f4e3fddecf9  push rcx
00007f4e3fddecfa  push rdx
00007f4e3fddecfb  push rdi
00007f4e3fddecfc  push rsi
00007f4e3fddecfd  push r8
00007f4e3fddecff  push r9
00007f4e3fdded01  push r10
00007f4e3fdded03  push r11
00007f4e3fdded05  sub rsp, 0xF0
00007f4e3fdded0c  vmovaps [rsp], xmm0
00007f4e3fdded11  vmovaps [rsp+0x10], xmm2
00007f4e3fdded17  vmovaps [rsp+0x20], xmm3
00007f4e3fdded1d  vmovaps [rsp+0x30], xmm4
00007f4e3fdded23  vmovaps [rsp+0x40], xmm5
00007f4e3fdded29  vmovaps [rsp+0x50], xmm6
00007f4e3fdded2f  vmovaps [rsp+0x60], xmm7
00007f4e3fdded35  vmovaps [rsp+0x70], xmm8
00007f4e3fdded3b  vmovaps [rsp+0x80], xmm9
00007f4e3fdded44  vmovaps [rsp+0x90], xmm10
00007f4e3fdded4d  vmovaps [rsp+0xA0], xmm11
00007f4e3fdded56  vmovaps [rsp+0xB0], xmm12
00007f4e3fdded5f  vmovaps [rsp+0xC0], xmm13
00007f4e3fdded68  vmovaps [rsp+0xD0], xmm14
00007f4e3fdded71  vmovaps [rsp+0xE0], xmm15
00007f4e3fdded7a  sub rsp, 0x30
00007f4e3fdded7e  movaps [rsp], xmm1
00007f4e3fdded82  movaps [rsp+0x10], xmm4
00007f4e3fdded87  movaps [rsp+0x20], xmm9
00007f4e3fdded8d  lea rdi, [rsp]
00007f4e3fdded91  mov esi, 0x00
00007f4e3fdded96  mov rax, 0x5D97141E9530
00007f4e3fddeda0  call rax
00007f4e3fddeda2  movaps xmm1, [rsp]
00007f4e3fddeda6  add rsp, 0x30
00007f4e3fddedaa  vmovaps xmm0, [rsp]
00007f4e3fddedaf  vmovaps xmm2, [rsp+0x10]
00007f4e3fddedb5  vmovaps xmm3, [rsp+0x20]
00007f4e3fddedbb  vmovaps xmm4, [rsp+0x30]
00007f4e3fddedc1  vmovaps xmm5, [rsp+0x40]
00007f4e3fddedc7  vmovaps xmm6, [rsp+0x50]
00007f4e3fddedcd  vmovaps xmm7, [rsp+0x60]
00007f4e3fddedd3  vmovaps xmm8, [rsp+0x70]
00007f4e3fddedd9  vmovaps xmm9, [rsp+0x80]
00007f4e3fddede2  vmovaps xmm10, [rsp+0x90]
00007f4e3fddedeb  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddedf4  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddedfd  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddee06  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddee0f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddee18  add rsp, 0xF0
00007f4e3fddee1f  pop r11
00007f4e3fddee21  pop r10
00007f4e3fddee23  pop r9
00007f4e3fddee25  pop r8
00007f4e3fddee27  pop rsi
00007f4e3fddee28  pop rdi
00007f4e3fddee29  pop rdx
00007f4e3fddee2a  pop rcx
00007f4e3fddee2b  pop rax
00007f4e3fddee2c  add rsp, 0x08
00007f4e3fddee30  jmp 0x00007F4E3FDDC2EE
00007f4e3fddee35  sub rsp, 0x08
00007f4e3fddee39  push rax
00007f4e3fddee3a  push rcx
00007f4e3fddee3b  push rdx
00007f4e3fddee3c  push rdi
00007f4e3fddee3d  push rsi
00007f4e3fddee3e  push r8
00007f4e3fddee40  push r9
00007f4e3fddee42  push r10
00007f4e3fddee44  push r11
00007f4e3fddee46  sub rsp, 0xF0
00007f4e3fddee4d  vmovaps [rsp], xmm0
00007f4e3fddee52  vmovaps [rsp+0x10], xmm1
00007f4e3fddee58  vmovaps [rsp+0x20], xmm2
00007f4e3fddee5e  vmovaps [rsp+0x30], xmm3
00007f4e3fddee64  vmovaps [rsp+0x40], xmm5
00007f4e3fddee6a  vmovaps [rsp+0x50], xmm6
00007f4e3fddee70  vmovaps [rsp+0x60], xmm7
00007f4e3fddee76  vmovaps [rsp+0x70], xmm8
00007f4e3fddee7c  vmovaps [rsp+0x80], xmm9
00007f4e3fddee85  vmovaps [rsp+0x90], xmm10
00007f4e3fddee8e  vmovaps [rsp+0xA0], xmm11
00007f4e3fddee97  vmovaps [rsp+0xB0], xmm12
00007f4e3fddeea0  vmovaps [rsp+0xC0], xmm13
00007f4e3fddeea9  vmovaps [rsp+0xD0], xmm14
00007f4e3fddeeb2  vmovaps [rsp+0xE0], xmm15
00007f4e3fddeebb  sub rsp, 0x30
00007f4e3fddeebf  movaps [rsp], xmm4
00007f4e3fddeec3  movaps [rsp+0x10], xmm2
00007f4e3fddeec8  movaps [rsp+0x20], xmm9
00007f4e3fddeece  lea rdi, [rsp]
00007f4e3fddeed2  mov esi, 0x00
00007f4e3fddeed7  mov rax, 0x5D97141E9530
00007f4e3fddeee1  call rax
00007f4e3fddeee3  movaps xmm4, [rsp]
00007f4e3fddeee7  add rsp, 0x30
00007f4e3fddeeeb  vmovaps xmm0, [rsp]
00007f4e3fddeef0  vmovaps xmm1, [rsp+0x10]
00007f4e3fddeef6  vmovaps xmm2, [rsp+0x20]
00007f4e3fddeefc  vmovaps xmm3, [rsp+0x30]
00007f4e3fddef02  vmovaps xmm5, [rsp+0x40]
00007f4e3fddef08  vmovaps xmm6, [rsp+0x50]
00007f4e3fddef0e  vmovaps xmm7, [rsp+0x60]
00007f4e3fddef14  vmovaps xmm8, [rsp+0x70]
00007f4e3fddef1a  vmovaps xmm9, [rsp+0x80]
00007f4e3fddef23  vmovaps xmm10, [rsp+0x90]
00007f4e3fddef2c  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddef35  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddef3e  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddef47  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddef50  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddef59  add rsp, 0xF0
00007f4e3fddef60  pop r11
00007f4e3fddef62  pop r10
00007f4e3fddef64  pop r9
00007f4e3fddef66  pop r8
00007f4e3fddef68  pop rsi
00007f4e3fddef69  pop rdi
00007f4e3fddef6a  pop rdx
00007f4e3fddef6b  pop rcx
00007f4e3fddef6c  pop rax
00007f4e3fddef6d  add rsp, 0x08
00007f4e3fddef71  jmp 0x00007F4E3FDDC31E
00007f4e3fddef76  sub rsp, 0x08
00007f4e3fddef7a  push rax
00007f4e3fddef7b  push rcx
00007f4e3fddef7c  push rdx
00007f4e3fddef7d  push rdi
00007f4e3fddef7e  push rsi
00007f4e3fddef7f  push r8
00007f4e3fddef81  push r9
00007f4e3fddef83  push r10
00007f4e3fddef85  push r11
00007f4e3fddef87  sub rsp, 0xF0
00007f4e3fddef8e  vmovaps [rsp], xmm0
00007f4e3fddef93  vmovaps [rsp+0x10], xmm1
00007f4e3fddef99  vmovaps [rsp+0x20], xmm2
00007f4e3fddef9f  vmovaps [rsp+0x30], xmm3
00007f4e3fddefa5  vmovaps [rsp+0x40], xmm4
00007f4e3fddefab  vmovaps [rsp+0x50], xmm5
00007f4e3fddefb1  vmovaps [rsp+0x60], xmm6
00007f4e3fddefb7  vmovaps [rsp+0x70], xmm7
00007f4e3fddefbd  vmovaps [rsp+0x80], xmm8
00007f4e3fddefc6  vmovaps [rsp+0x90], xmm10
00007f4e3fddefcf  vmovaps [rsp+0xA0], xmm11
00007f4e3fddefd8  vmovaps [rsp+0xB0], xmm12
00007f4e3fddefe1  vmovaps [rsp+0xC0], xmm13
00007f4e3fddefea  vmovaps [rsp+0xD0], xmm14
00007f4e3fddeff3  vmovaps [rsp+0xE0], xmm15
00007f4e3fddeffc  sub rsp, 0x30
00007f4e3fddf000  movaps [rsp], xmm9
00007f4e3fddf005  movaps [rsp+0x10], xmm2
00007f4e3fddf00a  movaps [rsp+0x20], xmm1
00007f4e3fddf00f  lea rdi, [rsp]
00007f4e3fddf013  mov esi, 0x00
00007f4e3fddf018  mov rax, 0x5D97141E9530
00007f4e3fddf022  call rax
00007f4e3fddf024  movaps xmm9, [rsp]
00007f4e3fddf029  add rsp, 0x30
00007f4e3fddf02d  vmovaps xmm0, [rsp]
00007f4e3fddf032  vmovaps xmm1, [rsp+0x10]
00007f4e3fddf038  vmovaps xmm2, [rsp+0x20]
00007f4e3fddf03e  vmovaps xmm3, [rsp+0x30]
00007f4e3fddf044  vmovaps xmm4, [rsp+0x40]
00007f4e3fddf04a  vmovaps xmm5, [rsp+0x50]
00007f4e3fddf050  vmovaps xmm6, [rsp+0x60]
00007f4e3fddf056  vmovaps xmm7, [rsp+0x70]
00007f4e3fddf05c  vmovaps xmm8, [rsp+0x80]
00007f4e3fddf065  vmovaps xmm10, [rsp+0x90]
00007f4e3fddf06e  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddf077  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddf080  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddf089  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddf092  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddf09b  add rsp, 0xF0
00007f4e3fddf0a2  pop r11
00007f4e3fddf0a4  pop r10
00007f4e3fddf0a6  pop r9
00007f4e3fddf0a8  pop r8
00007f4e3fddf0aa  pop rsi
00007f4e3fddf0ab  pop rdi
00007f4e3fddf0ac  pop rdx
00007f4e3fddf0ad  pop rcx
00007f4e3fddf0ae  pop rax
00007f4e3fddf0af  add rsp, 0x08
00007f4e3fddf0b3  jmp 0x00007F4E3FDDC354
00007f4e3fddf0b8  sub rsp, 0x08
00007f4e3fddf0bc  push rax
00007f4e3fddf0bd  push rcx
00007f4e3fddf0be  push rdx
00007f4e3fddf0bf  push rdi
00007f4e3fddf0c0  push rsi
00007f4e3fddf0c1  push r8
00007f4e3fddf0c3  push r9
00007f4e3fddf0c5  push r10
00007f4e3fddf0c7  push r11
00007f4e3fddf0c9  sub rsp, 0xF0
00007f4e3fddf0d0  vmovaps [rsp], xmm0
00007f4e3fddf0d5  vmovaps [rsp+0x10], xmm2
00007f4e3fddf0db  vmovaps [rsp+0x20], xmm3
00007f4e3fddf0e1  vmovaps [rsp+0x30], xmm4
00007f4e3fddf0e7  vmovaps [rsp+0x40], xmm5
00007f4e3fddf0ed  vmovaps [rsp+0x50], xmm6
00007f4e3fddf0f3  vmovaps [rsp+0x60], xmm7
00007f4e3fddf0f9  vmovaps [rsp+0x70], xmm8
00007f4e3fddf0ff  vmovaps [rsp+0x80], xmm9
00007f4e3fddf108  vmovaps [rsp+0x90], xmm10
00007f4e3fddf111  vmovaps [rsp+0xA0], xmm11
00007f4e3fddf11a  vmovaps [rsp+0xB0], xmm12
00007f4e3fddf123  vmovaps [rsp+0xC0], xmm13
00007f4e3fddf12c  vmovaps [rsp+0xD0], xmm14
00007f4e3fddf135  vmovaps [rsp+0xE0], xmm15
00007f4e3fddf13e  sub rsp, 0x30
00007f4e3fddf142  movaps [rsp], xmm1
00007f4e3fddf146  movaps [rsp+0x10], xmm15
00007f4e3fddf14c  movaps [rsp+0x20], xmm6
00007f4e3fddf151  lea rdi, [rsp]
00007f4e3fddf155  mov esi, 0x00
00007f4e3fddf15a  mov rax, 0x5D97141E9530
00007f4e3fddf164  call rax
00007f4e3fddf166  movaps xmm1, [rsp]
00007f4e3fddf16a  add rsp, 0x30
00007f4e3fddf16e  vmovaps xmm0, [rsp]
00007f4e3fddf173  vmovaps xmm2, [rsp+0x10]
00007f4e3fddf179  vmovaps xmm3, [rsp+0x20]
00007f4e3fddf17f  vmovaps xmm4, [rsp+0x30]
00007f4e3fddf185  vmovaps xmm5, [rsp+0x40]
00007f4e3fddf18b  vmovaps xmm6, [rsp+0x50]
00007f4e3fddf191  vmovaps xmm7, [rsp+0x60]
00007f4e3fddf197  vmovaps xmm8, [rsp+0x70]
00007f4e3fddf19d  vmovaps xmm9, [rsp+0x80]
00007f4e3fddf1a6  vmovaps xmm10, [rsp+0x90]
00007f4e3fddf1af  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddf1b8  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddf1c1  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddf1ca  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddf1d3  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddf1dc  add rsp, 0xF0
00007f4e3fddf1e3  pop r11
00007f4e3fddf1e5  pop r10
00007f4e3fddf1e7  pop r9
00007f4e3fddf1e9  pop r8
00007f4e3fddf1eb  pop rsi
00007f4e3fddf1ec  pop rdi
00007f4e3fddf1ed  pop rdx
00007f4e3fddf1ee  pop rcx
00007f4e3fddf1ef  pop rax
00007f4e3fddf1f0  add rsp, 0x08
00007f4e3fddf1f4  jmp 0x00007F4E3FDDC375
00007f4e3fddf1f9  sub rsp, 0x08
00007f4e3fddf1fd  push rax
00007f4e3fddf1fe  push rcx
00007f4e3fddf1ff  push rdx
00007f4e3fddf200  push rdi
00007f4e3fddf201  push rsi
00007f4e3fddf202  push r8
00007f4e3fddf204  push r9
00007f4e3fddf206  push r10
00007f4e3fddf208  push r11
00007f4e3fddf20a  sub rsp, 0xF0
00007f4e3fddf211  vmovaps [rsp], xmm0
00007f4e3fddf216  vmovaps [rsp+0x10], xmm1
00007f4e3fddf21c  vmovaps [rsp+0x20], xmm2
00007f4e3fddf222  vmovaps [rsp+0x30], xmm3
00007f4e3fddf228  vmovaps [rsp+0x40], xmm4
00007f4e3fddf22e  vmovaps [rsp+0x50], xmm5
00007f4e3fddf234  vmovaps [rsp+0x60], xmm6
00007f4e3fddf23a  vmovaps [rsp+0x70], xmm7
00007f4e3fddf240  vmovaps [rsp+0x80], xmm8
00007f4e3fddf249  vmovaps [rsp+0x90], xmm9
00007f4e3fddf252  vmovaps [rsp+0xA0], xmm10
00007f4e3fddf25b  vmovaps [rsp+0xB0], xmm11
00007f4e3fddf264  vmovaps [rsp+0xC0], xmm12
00007f4e3fddf26d  vmovaps [rsp+0xD0], xmm13
00007f4e3fddf276  vmovaps [rsp+0xE0], xmm14
00007f4e3fddf27f  sub rsp, 0x30
00007f4e3fddf283  movaps [rsp], xmm15
00007f4e3fddf288  movaps [rsp+0x10], xmm5
00007f4e3fddf28d  movaps [rsp+0x20], xmm3
00007f4e3fddf292  lea rdi, [rsp]
00007f4e3fddf296  mov esi, 0x00
00007f4e3fddf29b  mov rax, 0x5D97141E9530
00007f4e3fddf2a5  call rax
00007f4e3fddf2a7  movaps xmm15, [rsp]
00007f4e3fddf2ac  add rsp, 0x30
00007f4e3fddf2b0  vmovaps xmm0, [rsp]
00007f4e3fddf2b5  vmovaps xmm1, [rsp+0x10]
00007f4e3fddf2bb  vmovaps xmm2, [rsp+0x20]
00007f4e3fddf2c1  vmovaps xmm3, [rsp+0x30]
00007f4e3fddf2c7  vmovaps xmm4, [rsp+0x40]
00007f4e3fddf2cd  vmovaps xmm5, [rsp+0x50]
00007f4e3fddf2d3  vmovaps xmm6, [rsp+0x60]
00007f4e3fddf2d9  vmovaps xmm7, [rsp+0x70]
00007f4e3fddf2df  vmovaps xmm8, [rsp+0x80]
00007f4e3fddf2e8  vmovaps xmm9, [rsp+0x90]
00007f4e3fddf2f1  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddf2fa  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddf303  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddf30c  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddf315  vmovaps xmm14, [rsp+0xE0]
00007f4e3fddf31e  add rsp, 0xF0
00007f4e3fddf325  pop r11
00007f4e3fddf327  pop r10
00007f4e3fddf329  pop r9
00007f4e3fddf32b  pop r8
00007f4e3fddf32d  pop rsi
00007f4e3fddf32e  pop rdi
00007f4e3fddf32f  pop rdx
00007f4e3fddf330  pop rcx
00007f4e3fddf331  pop rax
00007f4e3fddf332  add rsp, 0x08
00007f4e3fddf336  jmp 0x00007F4E3FDDC38F
00007f4e3fddf33b  sub rsp, 0x08
00007f4e3fddf33f  push rax
00007f4e3fddf340  push rcx
00007f4e3fddf341  push rdx
00007f4e3fddf342  push rdi
00007f4e3fddf343  push rsi
00007f4e3fddf344  push r8
00007f4e3fddf346  push r9
00007f4e3fddf348  push r10
00007f4e3fddf34a  push r11
00007f4e3fddf34c  sub rsp, 0xF0
00007f4e3fddf353  vmovaps [rsp], xmm0
00007f4e3fddf358  vmovaps [rsp+0x10], xmm1
00007f4e3fddf35e  vmovaps [rsp+0x20], xmm2
00007f4e3fddf364  vmovaps [rsp+0x30], xmm3
00007f4e3fddf36a  vmovaps [rsp+0x40], xmm4
00007f4e3fddf370  vmovaps [rsp+0x50], xmm6
00007f4e3fddf376  vmovaps [rsp+0x60], xmm7
00007f4e3fddf37c  vmovaps [rsp+0x70], xmm8
00007f4e3fddf382  vmovaps [rsp+0x80], xmm9
00007f4e3fddf38b  vmovaps [rsp+0x90], xmm10
00007f4e3fddf394  vmovaps [rsp+0xA0], xmm11
00007f4e3fddf39d  vmovaps [rsp+0xB0], xmm12
00007f4e3fddf3a6  vmovaps [rsp+0xC0], xmm13
00007f4e3fddf3af  vmovaps [rsp+0xD0], xmm14
00007f4e3fddf3b8  vmovaps [rsp+0xE0], xmm15
00007f4e3fddf3c1  sub rsp, 0x30
00007f4e3fddf3c5  movaps [rsp], xmm5
00007f4e3fddf3c9  movaps [rsp+0x10], xmm8
00007f4e3fddf3cf  movaps [rsp+0x20], xmm6
00007f4e3fddf3d4  lea rdi, [rsp]
00007f4e3fddf3d8  mov esi, 0x00
00007f4e3fddf3dd  mov rax, 0x5D97141E9530
00007f4e3fddf3e7  call rax
00007f4e3fddf3e9  movaps xmm5, [rsp]
00007f4e3fddf3ed  add rsp, 0x30
00007f4e3fddf3f1  vmovaps xmm0, [rsp]
00007f4e3fddf3f6  vmovaps xmm1, [rsp+0x10]
00007f4e3fddf3fc  vmovaps xmm2, [rsp+0x20]
00007f4e3fddf402  vmovaps xmm3, [rsp+0x30]
00007f4e3fddf408  vmovaps xmm4, [rsp+0x40]
00007f4e3fddf40e  vmovaps xmm6, [rsp+0x50]
00007f4e3fddf414  vmovaps xmm7, [rsp+0x60]
00007f4e3fddf41a  vmovaps xmm8, [rsp+0x70]
00007f4e3fddf420  vmovaps xmm9, [rsp+0x80]
00007f4e3fddf429  vmovaps xmm10, [rsp+0x90]
00007f4e3fddf432  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddf43b  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddf444  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddf44d  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddf456  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddf45f  add rsp, 0xF0
00007f4e3fddf466  pop r11
00007f4e3fddf468  pop r10
00007f4e3fddf46a  pop r9
00007f4e3fddf46c  pop r8
00007f4e3fddf46e  pop rsi
00007f4e3fddf46f  pop rdi
00007f4e3fddf470  pop rdx
00007f4e3fddf471  pop rcx
00007f4e3fddf472  pop rax
00007f4e3fddf473  add rsp, 0x08
00007f4e3fddf477  jmp 0x00007F4E3FDDC3B3
00007f4e3fddf47c  sub rsp, 0x08
00007f4e3fddf480  push rax
00007f4e3fddf481  push rcx
00007f4e3fddf482  push rdx
00007f4e3fddf483  push rdi
00007f4e3fddf484  push rsi
00007f4e3fddf485  push r8
00007f4e3fddf487  push r9
00007f4e3fddf489  push r10
00007f4e3fddf48b  push r11
00007f4e3fddf48d  sub rsp, 0xF0
00007f4e3fddf494  vmovaps [rsp], xmm0
00007f4e3fddf499  vmovaps [rsp+0x10], xmm1
00007f4e3fddf49f  vmovaps [rsp+0x20], xmm2
00007f4e3fddf4a5  vmovaps [rsp+0x30], xmm3
00007f4e3fddf4ab  vmovaps [rsp+0x40], xmm4
00007f4e3fddf4b1  vmovaps [rsp+0x50], xmm5
00007f4e3fddf4b7  vmovaps [rsp+0x60], xmm7
00007f4e3fddf4bd  vmovaps [rsp+0x70], xmm8
00007f4e3fddf4c3  vmovaps [rsp+0x80], xmm9
00007f4e3fddf4cc  vmovaps [rsp+0x90], xmm10
00007f4e3fddf4d5  vmovaps [rsp+0xA0], xmm11
00007f4e3fddf4de  vmovaps [rsp+0xB0], xmm12
00007f4e3fddf4e7  vmovaps [rsp+0xC0], xmm13
00007f4e3fddf4f0  vmovaps [rsp+0xD0], xmm14
00007f4e3fddf4f9  vmovaps [rsp+0xE0], xmm15
00007f4e3fddf502  sub rsp, 0x30
00007f4e3fddf506  movaps [rsp], xmm6
00007f4e3fddf50a  movaps [rsp+0x10], xmm10
00007f4e3fddf510  movaps [rsp+0x20], xmm8
00007f4e3fddf516  lea rdi, [rsp]
00007f4e3fddf51a  mov esi, 0x00
00007f4e3fddf51f  mov rax, 0x5D97141E9530
00007f4e3fddf529  call rax
00007f4e3fddf52b  movaps xmm6, [rsp]
00007f4e3fddf52f  add rsp, 0x30
00007f4e3fddf533  vmovaps xmm0, [rsp]
00007f4e3fddf538  vmovaps xmm1, [rsp+0x10]
00007f4e3fddf53e  vmovaps xmm2, [rsp+0x20]
00007f4e3fddf544  vmovaps xmm3, [rsp+0x30]
00007f4e3fddf54a  vmovaps xmm4, [rsp+0x40]
00007f4e3fddf550  vmovaps xmm5, [rsp+0x50]
00007f4e3fddf556  vmovaps xmm7, [rsp+0x60]
00007f4e3fddf55c  vmovaps xmm8, [rsp+0x70]
00007f4e3fddf562  vmovaps xmm9, [rsp+0x80]
00007f4e3fddf56b  vmovaps xmm10, [rsp+0x90]
00007f4e3fddf574  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddf57d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddf586  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddf58f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddf598  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddf5a1  add rsp, 0xF0
00007f4e3fddf5a8  pop r11
00007f4e3fddf5aa  pop r10
00007f4e3fddf5ac  pop r9
00007f4e3fddf5ae  pop r8
00007f4e3fddf5b0  pop rsi
00007f4e3fddf5b1  pop rdi
00007f4e3fddf5b2  pop rdx
00007f4e3fddf5b3  pop rcx
00007f4e3fddf5b4  pop rax
00007f4e3fddf5b5  add rsp, 0x08
00007f4e3fddf5b9  jmp 0x00007F4E3FDDC3D8
00007f4e3fddf5be  sub rsp, 0x08
00007f4e3fddf5c2  push rax
00007f4e3fddf5c3  push rcx
00007f4e3fddf5c4  push rdx
00007f4e3fddf5c5  push rdi
00007f4e3fddf5c6  push rsi
00007f4e3fddf5c7  push r8
00007f4e3fddf5c9  push r9
00007f4e3fddf5cb  push r10
00007f4e3fddf5cd  push r11
00007f4e3fddf5cf  sub rsp, 0xF0
00007f4e3fddf5d6  vmovaps [rsp], xmm0
00007f4e3fddf5db  vmovaps [rsp+0x10], xmm1
00007f4e3fddf5e1  vmovaps [rsp+0x20], xmm2
00007f4e3fddf5e7  vmovaps [rsp+0x30], xmm3
00007f4e3fddf5ed  vmovaps [rsp+0x40], xmm4
00007f4e3fddf5f3  vmovaps [rsp+0x50], xmm5
00007f4e3fddf5f9  vmovaps [rsp+0x60], xmm6
00007f4e3fddf5ff  vmovaps [rsp+0x70], xmm7
00007f4e3fddf605  vmovaps [rsp+0x80], xmm8
00007f4e3fddf60e  vmovaps [rsp+0x90], xmm9
00007f4e3fddf617  vmovaps [rsp+0xA0], xmm11
00007f4e3fddf620  vmovaps [rsp+0xB0], xmm12
00007f4e3fddf629  vmovaps [rsp+0xC0], xmm13
00007f4e3fddf632  vmovaps [rsp+0xD0], xmm14
00007f4e3fddf63b  vmovaps [rsp+0xE0], xmm15
00007f4e3fddf644  sub rsp, 0x30
00007f4e3fddf648  movaps [rsp], xmm10
00007f4e3fddf64d  movaps [rsp+0x10], xmm8
00007f4e3fddf653  movaps [rsp+0x20], xmm14
00007f4e3fddf659  lea rdi, [rsp]
00007f4e3fddf65d  mov esi, 0x00
00007f4e3fddf662  mov rax, 0x5D97141E9530
00007f4e3fddf66c  call rax
00007f4e3fddf66e  movaps xmm10, [rsp]
00007f4e3fddf673  add rsp, 0x30
00007f4e3fddf677  vmovaps xmm0, [rsp]
00007f4e3fddf67c  vmovaps xmm1, [rsp+0x10]
00007f4e3fddf682  vmovaps xmm2, [rsp+0x20]
00007f4e3fddf688  vmovaps xmm3, [rsp+0x30]
00007f4e3fddf68e  vmovaps xmm4, [rsp+0x40]
00007f4e3fddf694  vmovaps xmm5, [rsp+0x50]
00007f4e3fddf69a  vmovaps xmm6, [rsp+0x60]
00007f4e3fddf6a0  vmovaps xmm7, [rsp+0x70]
00007f4e3fddf6a6  vmovaps xmm8, [rsp+0x80]
00007f4e3fddf6af  vmovaps xmm9, [rsp+0x90]
00007f4e3fddf6b8  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddf6c1  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddf6ca  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddf6d3  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddf6dc  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddf6e5  add rsp, 0xF0
00007f4e3fddf6ec  pop r11
00007f4e3fddf6ee  pop r10
00007f4e3fddf6f0  pop r9
00007f4e3fddf6f2  pop r8
00007f4e3fddf6f4  pop rsi
00007f4e3fddf6f5  pop rdi
00007f4e3fddf6f6  pop rdx
00007f4e3fddf6f7  pop rcx
00007f4e3fddf6f8  pop rax
00007f4e3fddf6f9  add rsp, 0x08
00007f4e3fddf6fd  jmp 0x00007F4E3FDDC3F8
00007f4e3fddf702  sub rsp, 0x08
00007f4e3fddf706  push rax
00007f4e3fddf707  push rcx
00007f4e3fddf708  push rdx
00007f4e3fddf709  push rdi
00007f4e3fddf70a  push rsi
00007f4e3fddf70b  push r8
00007f4e3fddf70d  push r9
00007f4e3fddf70f  push r10
00007f4e3fddf711  push r11
00007f4e3fddf713  sub rsp, 0xF0
00007f4e3fddf71a  vmovaps [rsp], xmm0
00007f4e3fddf71f  vmovaps [rsp+0x10], xmm1
00007f4e3fddf725  vmovaps [rsp+0x20], xmm2
00007f4e3fddf72b  vmovaps [rsp+0x30], xmm3
00007f4e3fddf731  vmovaps [rsp+0x40], xmm4
00007f4e3fddf737  vmovaps [rsp+0x50], xmm5
00007f4e3fddf73d  vmovaps [rsp+0x60], xmm6
00007f4e3fddf743  vmovaps [rsp+0x70], xmm7
00007f4e3fddf749  vmovaps [rsp+0x80], xmm8
00007f4e3fddf752  vmovaps [rsp+0x90], xmm9
00007f4e3fddf75b  vmovaps [rsp+0xA0], xmm10
00007f4e3fddf764  vmovaps [rsp+0xB0], xmm11
00007f4e3fddf76d  vmovaps [rsp+0xC0], xmm12
00007f4e3fddf776  vmovaps [rsp+0xD0], xmm13
00007f4e3fddf77f  vmovaps [rsp+0xE0], xmm15
00007f4e3fddf788  sub rsp, 0x30
00007f4e3fddf78c  movaps [rsp], xmm14
00007f4e3fddf791  movaps [rsp+0x10], xmm8
00007f4e3fddf797  movaps [rsp+0x20], xmm4
00007f4e3fddf79c  lea rdi, [rsp]
00007f4e3fddf7a0  mov esi, 0x00
00007f4e3fddf7a5  mov rax, 0x5D97141E9530
00007f4e3fddf7af  call rax
00007f4e3fddf7b1  movaps xmm14, [rsp]
00007f4e3fddf7b6  add rsp, 0x30
00007f4e3fddf7ba  vmovaps xmm0, [rsp]
00007f4e3fddf7bf  vmovaps xmm1, [rsp+0x10]
00007f4e3fddf7c5  vmovaps xmm2, [rsp+0x20]
00007f4e3fddf7cb  vmovaps xmm3, [rsp+0x30]
00007f4e3fddf7d1  vmovaps xmm4, [rsp+0x40]
00007f4e3fddf7d7  vmovaps xmm5, [rsp+0x50]
00007f4e3fddf7dd  vmovaps xmm6, [rsp+0x60]
00007f4e3fddf7e3  vmovaps xmm7, [rsp+0x70]
00007f4e3fddf7e9  vmovaps xmm8, [rsp+0x80]
00007f4e3fddf7f2  vmovaps xmm9, [rsp+0x90]
00007f4e3fddf7fb  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddf804  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddf80d  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddf816  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddf81f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddf828  add rsp, 0xF0
00007f4e3fddf82f  pop r11
00007f4e3fddf831  pop r10
00007f4e3fddf833  pop r9
00007f4e3fddf835  pop r8
00007f4e3fddf837  pop rsi
00007f4e3fddf838  pop rdi
00007f4e3fddf839  pop rdx
00007f4e3fddf83a  pop rcx
00007f4e3fddf83b  pop rax
00007f4e3fddf83c  add rsp, 0x08
00007f4e3fddf840  jmp 0x00007F4E3FDDC418
00007f4e3fddf845  sub rsp, 0x08
00007f4e3fddf849  push rax
00007f4e3fddf84a  push rcx
00007f4e3fddf84b  push rdx
00007f4e3fddf84c  push rdi
00007f4e3fddf84d  push rsi
00007f4e3fddf84e  push r8
00007f4e3fddf850  push r9
00007f4e3fddf852  push r10
00007f4e3fddf854  push r11
00007f4e3fddf856  sub rsp, 0xF0
00007f4e3fddf85d  vmovaps [rsp], xmm0
00007f4e3fddf862  vmovaps [rsp+0x10], xmm1
00007f4e3fddf868  vmovaps [rsp+0x20], xmm2
00007f4e3fddf86e  vmovaps [rsp+0x30], xmm3
00007f4e3fddf874  vmovaps [rsp+0x40], xmm5
00007f4e3fddf87a  vmovaps [rsp+0x50], xmm6
00007f4e3fddf880  vmovaps [rsp+0x60], xmm7
00007f4e3fddf886  vmovaps [rsp+0x70], xmm8
00007f4e3fddf88c  vmovaps [rsp+0x80], xmm9
00007f4e3fddf895  vmovaps [rsp+0x90], xmm10
00007f4e3fddf89e  vmovaps [rsp+0xA0], xmm11
00007f4e3fddf8a7  vmovaps [rsp+0xB0], xmm12
00007f4e3fddf8b0  vmovaps [rsp+0xC0], xmm13
00007f4e3fddf8b9  vmovaps [rsp+0xD0], xmm14
00007f4e3fddf8c2  vmovaps [rsp+0xE0], xmm15
00007f4e3fddf8cb  sub rsp, 0x30
00007f4e3fddf8cf  movaps [rsp], xmm4
00007f4e3fddf8d3  movaps [rsp+0x10], xmm13
00007f4e3fddf8d9  movaps [rsp+0x20], xmm8
00007f4e3fddf8df  lea rdi, [rsp]
00007f4e3fddf8e3  mov esi, 0x00
00007f4e3fddf8e8  mov rax, 0x5D97141E9530
00007f4e3fddf8f2  call rax
00007f4e3fddf8f4  movaps xmm4, [rsp]
00007f4e3fddf8f8  add rsp, 0x30
00007f4e3fddf8fc  vmovaps xmm0, [rsp]
00007f4e3fddf901  vmovaps xmm1, [rsp+0x10]
00007f4e3fddf907  vmovaps xmm2, [rsp+0x20]
00007f4e3fddf90d  vmovaps xmm3, [rsp+0x30]
00007f4e3fddf913  vmovaps xmm5, [rsp+0x40]
00007f4e3fddf919  vmovaps xmm6, [rsp+0x50]
00007f4e3fddf91f  vmovaps xmm7, [rsp+0x60]
00007f4e3fddf925  vmovaps xmm8, [rsp+0x70]
00007f4e3fddf92b  vmovaps xmm9, [rsp+0x80]
00007f4e3fddf934  vmovaps xmm10, [rsp+0x90]
00007f4e3fddf93d  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddf946  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddf94f  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddf958  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddf961  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddf96a  add rsp, 0xF0
00007f4e3fddf971  pop r11
00007f4e3fddf973  pop r10
00007f4e3fddf975  pop r9
00007f4e3fddf977  pop r8
00007f4e3fddf979  pop rsi
00007f4e3fddf97a  pop rdi
00007f4e3fddf97b  pop rdx
00007f4e3fddf97c  pop rcx
00007f4e3fddf97d  pop rax
00007f4e3fddf97e  add rsp, 0x08
00007f4e3fddf982  jmp 0x00007F4E3FDDC43D
00007f4e3fddf987  sub rsp, 0x08
00007f4e3fddf98b  push rax
00007f4e3fddf98c  push rcx
00007f4e3fddf98d  push rdx
00007f4e3fddf98e  push rdi
00007f4e3fddf98f  push rsi
00007f4e3fddf990  push r8
00007f4e3fddf992  push r9
00007f4e3fddf994  push r10
00007f4e3fddf996  push r11
00007f4e3fddf998  sub rsp, 0xF0
00007f4e3fddf99f  vmovaps [rsp], xmm0
00007f4e3fddf9a4  vmovaps [rsp+0x10], xmm1
00007f4e3fddf9aa  vmovaps [rsp+0x20], xmm2
00007f4e3fddf9b0  vmovaps [rsp+0x30], xmm3
00007f4e3fddf9b6  vmovaps [rsp+0x40], xmm4
00007f4e3fddf9bc  vmovaps [rsp+0x50], xmm5
00007f4e3fddf9c2  vmovaps [rsp+0x60], xmm6
00007f4e3fddf9c8  vmovaps [rsp+0x70], xmm7
00007f4e3fddf9ce  vmovaps [rsp+0x80], xmm8
00007f4e3fddf9d7  vmovaps [rsp+0x90], xmm9
00007f4e3fddf9e0  vmovaps [rsp+0xA0], xmm10
00007f4e3fddf9e9  vmovaps [rsp+0xB0], xmm11
00007f4e3fddf9f2  vmovaps [rsp+0xC0], xmm12
00007f4e3fddf9fb  vmovaps [rsp+0xD0], xmm14
00007f4e3fddfa04  vmovaps [rsp+0xE0], xmm15
00007f4e3fddfa0d  sub rsp, 0x30
00007f4e3fddfa11  movaps [rsp], xmm13
00007f4e3fddfa16  movaps [rsp+0x10], xmm15
00007f4e3fddfa1c  movaps [rsp+0x20], xmm9
00007f4e3fddfa22  lea rdi, [rsp]
00007f4e3fddfa26  mov esi, 0x00
00007f4e3fddfa2b  mov rax, 0x5D97141E9530
00007f4e3fddfa35  call rax
00007f4e3fddfa37  movaps xmm13, [rsp]
00007f4e3fddfa3c  add rsp, 0x30
00007f4e3fddfa40  vmovaps xmm0, [rsp]
00007f4e3fddfa45  vmovaps xmm1, [rsp+0x10]
00007f4e3fddfa4b  vmovaps xmm2, [rsp+0x20]
00007f4e3fddfa51  vmovaps xmm3, [rsp+0x30]
00007f4e3fddfa57  vmovaps xmm4, [rsp+0x40]
00007f4e3fddfa5d  vmovaps xmm5, [rsp+0x50]
00007f4e3fddfa63  vmovaps xmm6, [rsp+0x60]
00007f4e3fddfa69  vmovaps xmm7, [rsp+0x70]
00007f4e3fddfa6f  vmovaps xmm8, [rsp+0x80]
00007f4e3fddfa78  vmovaps xmm9, [rsp+0x90]
00007f4e3fddfa81  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddfa8a  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddfa93  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddfa9c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddfaa5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddfaae  add rsp, 0xF0
00007f4e3fddfab5  pop r11
00007f4e3fddfab7  pop r10
00007f4e3fddfab9  pop r9
00007f4e3fddfabb  pop r8
00007f4e3fddfabd  pop rsi
00007f4e3fddfabe  pop rdi
00007f4e3fddfabf  pop rdx
00007f4e3fddfac0  pop rcx
00007f4e3fddfac1  pop rax
00007f4e3fddfac2  add rsp, 0x08
00007f4e3fddfac6  jmp 0x00007F4E3FDDC458
00007f4e3fddfacb  sub rsp, 0x08
00007f4e3fddfacf  push rax
00007f4e3fddfad0  push rcx
00007f4e3fddfad1  push rdx
00007f4e3fddfad2  push rdi
00007f4e3fddfad3  push rsi
00007f4e3fddfad4  push r8
00007f4e3fddfad6  push r9
00007f4e3fddfad8  push r10
00007f4e3fddfada  push r11
00007f4e3fddfadc  sub rsp, 0xF0
00007f4e3fddfae3  vmovaps [rsp], xmm0
00007f4e3fddfae8  vmovaps [rsp+0x10], xmm1
00007f4e3fddfaee  vmovaps [rsp+0x20], xmm2
00007f4e3fddfaf4  vmovaps [rsp+0x30], xmm3
00007f4e3fddfafa  vmovaps [rsp+0x40], xmm4
00007f4e3fddfb00  vmovaps [rsp+0x50], xmm5
00007f4e3fddfb06  vmovaps [rsp+0x60], xmm6
00007f4e3fddfb0c  vmovaps [rsp+0x70], xmm7
00007f4e3fddfb12  vmovaps [rsp+0x80], xmm8
00007f4e3fddfb1b  vmovaps [rsp+0x90], xmm9
00007f4e3fddfb24  vmovaps [rsp+0xA0], xmm10
00007f4e3fddfb2d  vmovaps [rsp+0xB0], xmm11
00007f4e3fddfb36  vmovaps [rsp+0xC0], xmm12
00007f4e3fddfb3f  vmovaps [rsp+0xD0], xmm13
00007f4e3fddfb48  vmovaps [rsp+0xE0], xmm14
00007f4e3fddfb51  sub rsp, 0x30
00007f4e3fddfb55  movaps [rsp], xmm15
00007f4e3fddfb5a  movaps [rsp+0x10], xmm1
00007f4e3fddfb5f  movaps [rsp+0x20], xmm5
00007f4e3fddfb64  lea rdi, [rsp]
00007f4e3fddfb68  mov esi, 0x00
00007f4e3fddfb6d  mov rax, 0x5D97141E9530
00007f4e3fddfb77  call rax
00007f4e3fddfb79  movaps xmm15, [rsp]
00007f4e3fddfb7e  add rsp, 0x30
00007f4e3fddfb82  vmovaps xmm0, [rsp]
00007f4e3fddfb87  vmovaps xmm1, [rsp+0x10]
00007f4e3fddfb8d  vmovaps xmm2, [rsp+0x20]
00007f4e3fddfb93  vmovaps xmm3, [rsp+0x30]
00007f4e3fddfb99  vmovaps xmm4, [rsp+0x40]
00007f4e3fddfb9f  vmovaps xmm5, [rsp+0x50]
00007f4e3fddfba5  vmovaps xmm6, [rsp+0x60]
00007f4e3fddfbab  vmovaps xmm7, [rsp+0x70]
00007f4e3fddfbb1  vmovaps xmm8, [rsp+0x80]
00007f4e3fddfbba  vmovaps xmm9, [rsp+0x90]
00007f4e3fddfbc3  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddfbcc  vmovaps xmm11, [rsp+0xB0]
00007f4e3fddfbd5  vmovaps xmm12, [rsp+0xC0]
00007f4e3fddfbde  vmovaps xmm13, [rsp+0xD0]
00007f4e3fddfbe7  vmovaps xmm14, [rsp+0xE0]
00007f4e3fddfbf0  add rsp, 0xF0
00007f4e3fddfbf7  pop r11
00007f4e3fddfbf9  pop r10
00007f4e3fddfbfb  pop r9
00007f4e3fddfbfd  pop r8
00007f4e3fddfbff  pop rsi
00007f4e3fddfc00  pop rdi
00007f4e3fddfc01  pop rdx
00007f4e3fddfc02  pop rcx
00007f4e3fddfc03  pop rax
00007f4e3fddfc04  add rsp, 0x08
00007f4e3fddfc08  jmp 0x00007F4E3FDDC473
00007f4e3fddfc0d  call 0x00007F4E3FCB52F0
00007f4e3fddfc12  jmp 0x00007F4E3FDDC4CE
00007f4e3fddfc17  sub rsp, 0x08
00007f4e3fddfc1b  push rax
00007f4e3fddfc1c  push rcx
00007f4e3fddfc1d  push rdx
00007f4e3fddfc1e  push rdi
00007f4e3fddfc1f  push rsi
00007f4e3fddfc20  push r8
00007f4e3fddfc22  push r9
00007f4e3fddfc24  push r10
00007f4e3fddfc26  push r11
00007f4e3fddfc28  sub rsp, 0xF0
00007f4e3fddfc2f  vmovaps [rsp], xmm0
00007f4e3fddfc34  vmovaps [rsp+0x10], xmm1
00007f4e3fddfc3a  vmovaps [rsp+0x20], xmm2
00007f4e3fddfc40  vmovaps [rsp+0x30], xmm3
00007f4e3fddfc46  vmovaps [rsp+0x40], xmm4
00007f4e3fddfc4c  vmovaps [rsp+0x50], xmm5
00007f4e3fddfc52  vmovaps [rsp+0x60], xmm6
00007f4e3fddfc58  vmovaps [rsp+0x70], xmm7
00007f4e3fddfc5e  vmovaps [rsp+0x80], xmm8
00007f4e3fddfc67  vmovaps [rsp+0x90], xmm10
00007f4e3fddfc70  vmovaps [rsp+0xA0], xmm11
00007f4e3fddfc79  vmovaps [rsp+0xB0], xmm12
00007f4e3fddfc82  vmovaps [rsp+0xC0], xmm13
00007f4e3fddfc8b  vmovaps [rsp+0xD0], xmm14
00007f4e3fddfc94  vmovaps [rsp+0xE0], xmm15
00007f4e3fddfc9d  sub rsp, 0x30
00007f4e3fddfca1  movaps [rsp], xmm9
00007f4e3fddfca6  movaps [rsp+0x10], xmm8
00007f4e3fddfcac  movaps [rsp+0x20], xmm11
00007f4e3fddfcb2  lea rdi, [rsp]
00007f4e3fddfcb6  mov esi, 0x00
00007f4e3fddfcbb  mov rax, 0x5D97141E9530
00007f4e3fddfcc5  call rax
00007f4e3fddfcc7  movaps xmm9, [rsp]
00007f4e3fddfccc  add rsp, 0x30
00007f4e3fddfcd0  vmovaps xmm0, [rsp]
00007f4e3fddfcd5  vmovaps xmm1, [rsp+0x10]
00007f4e3fddfcdb  vmovaps xmm2, [rsp+0x20]
00007f4e3fddfce1  vmovaps xmm3, [rsp+0x30]
00007f4e3fddfce7  vmovaps xmm4, [rsp+0x40]
00007f4e3fddfced  vmovaps xmm5, [rsp+0x50]
00007f4e3fddfcf3  vmovaps xmm6, [rsp+0x60]
00007f4e3fddfcf9  vmovaps xmm7, [rsp+0x70]
00007f4e3fddfcff  vmovaps xmm8, [rsp+0x80]
00007f4e3fddfd08  vmovaps xmm10, [rsp+0x90]
00007f4e3fddfd11  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddfd1a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddfd23  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddfd2c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddfd35  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddfd3e  add rsp, 0xF0
00007f4e3fddfd45  pop r11
00007f4e3fddfd47  pop r10
00007f4e3fddfd49  pop r9
00007f4e3fddfd4b  pop r8
00007f4e3fddfd4d  pop rsi
00007f4e3fddfd4e  pop rdi
00007f4e3fddfd4f  pop rdx
00007f4e3fddfd50  pop rcx
00007f4e3fddfd51  pop rax
00007f4e3fddfd52  add rsp, 0x08
00007f4e3fddfd56  jmp 0x00007F4E3FDDC505
00007f4e3fddfd5b  sub rsp, 0x08
00007f4e3fddfd5f  push rax
00007f4e3fddfd60  push rcx
00007f4e3fddfd61  push rdx
00007f4e3fddfd62  push rdi
00007f4e3fddfd63  push rsi
00007f4e3fddfd64  push r8
00007f4e3fddfd66  push r9
00007f4e3fddfd68  push r10
00007f4e3fddfd6a  push r11
00007f4e3fddfd6c  sub rsp, 0xF0
00007f4e3fddfd73  vmovaps [rsp], xmm0
00007f4e3fddfd78  vmovaps [rsp+0x10], xmm1
00007f4e3fddfd7e  vmovaps [rsp+0x20], xmm2
00007f4e3fddfd84  vmovaps [rsp+0x30], xmm3
00007f4e3fddfd8a  vmovaps [rsp+0x40], xmm4
00007f4e3fddfd90  vmovaps [rsp+0x50], xmm5
00007f4e3fddfd96  vmovaps [rsp+0x60], xmm6
00007f4e3fddfd9c  vmovaps [rsp+0x70], xmm7
00007f4e3fddfda2  vmovaps [rsp+0x80], xmm8
00007f4e3fddfdab  vmovaps [rsp+0x90], xmm9
00007f4e3fddfdb4  vmovaps [rsp+0xA0], xmm10
00007f4e3fddfdbd  vmovaps [rsp+0xB0], xmm12
00007f4e3fddfdc6  vmovaps [rsp+0xC0], xmm13
00007f4e3fddfdcf  vmovaps [rsp+0xD0], xmm14
00007f4e3fddfdd8  vmovaps [rsp+0xE0], xmm15
00007f4e3fddfde1  sub rsp, 0x30
00007f4e3fddfde5  movaps [rsp], xmm11
00007f4e3fddfdea  movaps [rsp+0x10], xmm10
00007f4e3fddfdf0  movaps [rsp+0x20], xmm6
00007f4e3fddfdf5  lea rdi, [rsp]
00007f4e3fddfdf9  mov esi, 0x00
00007f4e3fddfdfe  mov rax, 0x5D97141E9530
00007f4e3fddfe08  call rax
00007f4e3fddfe0a  movaps xmm11, [rsp]
00007f4e3fddfe0f  add rsp, 0x30
00007f4e3fddfe13  vmovaps xmm0, [rsp]
00007f4e3fddfe18  vmovaps xmm1, [rsp+0x10]
00007f4e3fddfe1e  vmovaps xmm2, [rsp+0x20]
00007f4e3fddfe24  vmovaps xmm3, [rsp+0x30]
00007f4e3fddfe2a  vmovaps xmm4, [rsp+0x40]
00007f4e3fddfe30  vmovaps xmm5, [rsp+0x50]
00007f4e3fddfe36  vmovaps xmm6, [rsp+0x60]
00007f4e3fddfe3c  vmovaps xmm7, [rsp+0x70]
00007f4e3fddfe42  vmovaps xmm8, [rsp+0x80]
00007f4e3fddfe4b  vmovaps xmm9, [rsp+0x90]
00007f4e3fddfe54  vmovaps xmm10, [rsp+0xA0]
00007f4e3fddfe5d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddfe66  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddfe6f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddfe78  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddfe81  add rsp, 0xF0
00007f4e3fddfe88  pop r11
00007f4e3fddfe8a  pop r10
00007f4e3fddfe8c  pop r9
00007f4e3fddfe8e  pop r8
00007f4e3fddfe90  pop rsi
00007f4e3fddfe91  pop rdi
00007f4e3fddfe92  pop rdx
00007f4e3fddfe93  pop rcx
00007f4e3fddfe94  pop rax
00007f4e3fddfe95  add rsp, 0x08
00007f4e3fddfe99  jmp 0x00007F4E3FDDC520
00007f4e3fddfe9e  sub rsp, 0x08
00007f4e3fddfea2  push rax
00007f4e3fddfea3  push rcx
00007f4e3fddfea4  push rdx
00007f4e3fddfea5  push rdi
00007f4e3fddfea6  push rsi
00007f4e3fddfea7  push r8
00007f4e3fddfea9  push r9
00007f4e3fddfeab  push r10
00007f4e3fddfead  push r11
00007f4e3fddfeaf  sub rsp, 0xF0
00007f4e3fddfeb6  vmovaps [rsp], xmm0
00007f4e3fddfebb  vmovaps [rsp+0x10], xmm1
00007f4e3fddfec1  vmovaps [rsp+0x20], xmm2
00007f4e3fddfec7  vmovaps [rsp+0x30], xmm3
00007f4e3fddfecd  vmovaps [rsp+0x40], xmm4
00007f4e3fddfed3  vmovaps [rsp+0x50], xmm5
00007f4e3fddfed9  vmovaps [rsp+0x60], xmm6
00007f4e3fddfedf  vmovaps [rsp+0x70], xmm7
00007f4e3fddfee5  vmovaps [rsp+0x80], xmm8
00007f4e3fddfeee  vmovaps [rsp+0x90], xmm9
00007f4e3fddfef7  vmovaps [rsp+0xA0], xmm11
00007f4e3fddff00  vmovaps [rsp+0xB0], xmm12
00007f4e3fddff09  vmovaps [rsp+0xC0], xmm13
00007f4e3fddff12  vmovaps [rsp+0xD0], xmm14
00007f4e3fddff1b  vmovaps [rsp+0xE0], xmm15
00007f4e3fddff24  sub rsp, 0x30
00007f4e3fddff28  movaps [rsp], xmm10
00007f4e3fddff2d  movaps [rsp+0x10], xmm14
00007f4e3fddff33  movaps [rsp+0x20], xmm4
00007f4e3fddff38  lea rdi, [rsp]
00007f4e3fddff3c  mov esi, 0x00
00007f4e3fddff41  mov rax, 0x5D97141E9530
00007f4e3fddff4b  call rax
00007f4e3fddff4d  movaps xmm10, [rsp]
00007f4e3fddff52  add rsp, 0x30
00007f4e3fddff56  vmovaps xmm0, [rsp]
00007f4e3fddff5b  vmovaps xmm1, [rsp+0x10]
00007f4e3fddff61  vmovaps xmm2, [rsp+0x20]
00007f4e3fddff67  vmovaps xmm3, [rsp+0x30]
00007f4e3fddff6d  vmovaps xmm4, [rsp+0x40]
00007f4e3fddff73  vmovaps xmm5, [rsp+0x50]
00007f4e3fddff79  vmovaps xmm6, [rsp+0x60]
00007f4e3fddff7f  vmovaps xmm7, [rsp+0x70]
00007f4e3fddff85  vmovaps xmm8, [rsp+0x80]
00007f4e3fddff8e  vmovaps xmm9, [rsp+0x90]
00007f4e3fddff97  vmovaps xmm11, [rsp+0xA0]
00007f4e3fddffa0  vmovaps xmm12, [rsp+0xB0]
00007f4e3fddffa9  vmovaps xmm13, [rsp+0xC0]
00007f4e3fddffb2  vmovaps xmm14, [rsp+0xD0]
00007f4e3fddffbb  vmovaps xmm15, [rsp+0xE0]
00007f4e3fddffc4  add rsp, 0xF0
00007f4e3fddffcb  pop r11
00007f4e3fddffcd  pop r10
00007f4e3fddffcf  pop r9
00007f4e3fddffd1  pop r8
00007f4e3fddffd3  pop rsi
00007f4e3fddffd4  pop rdi
00007f4e3fddffd5  pop rdx
00007f4e3fddffd6  pop rcx
00007f4e3fddffd7  pop rax
00007f4e3fddffd8  add rsp, 0x08
00007f4e3fddffdc  jmp 0x00007F4E3FDDC53B
00007f4e3fddffe1  sub rsp, 0x08
00007f4e3fddffe5  push rax
00007f4e3fddffe6  push rcx
00007f4e3fddffe7  push rdx
00007f4e3fddffe8  push rdi
00007f4e3fddffe9  push rsi
00007f4e3fddffea  push r8
00007f4e3fddffec  push r9
00007f4e3fddffee  push r10
00007f4e3fddfff0  push r11
00007f4e3fddfff2  sub rsp, 0xF0
00007f4e3fddfff9  vmovaps [rsp], xmm0
00007f4e3fddfffe  vmovaps [rsp+0x10], xmm1
00007f4e3fde0004  vmovaps [rsp+0x20], xmm2
00007f4e3fde000a  vmovaps [rsp+0x30], xmm3
00007f4e3fde0010  vmovaps [rsp+0x40], xmm4
00007f4e3fde0016  vmovaps [rsp+0x50], xmm5
00007f4e3fde001c  vmovaps [rsp+0x60], xmm6
00007f4e3fde0022  vmovaps [rsp+0x70], xmm7
00007f4e3fde0028  vmovaps [rsp+0x80], xmm9
00007f4e3fde0031  vmovaps [rsp+0x90], xmm10
00007f4e3fde003a  vmovaps [rsp+0xA0], xmm11
00007f4e3fde0043  vmovaps [rsp+0xB0], xmm12
00007f4e3fde004c  vmovaps [rsp+0xC0], xmm13
00007f4e3fde0055  vmovaps [rsp+0xD0], xmm14
00007f4e3fde005e  vmovaps [rsp+0xE0], xmm15
00007f4e3fde0067  sub rsp, 0x30
00007f4e3fde006b  movaps [rsp], xmm8
00007f4e3fde0070  movaps [rsp+0x10], xmm1
00007f4e3fde0075  movaps [rsp+0x20], xmm14
00007f4e3fde007b  lea rdi, [rsp]
00007f4e3fde007f  mov esi, 0x00
00007f4e3fde0084  mov rax, 0x5D97141E9530
00007f4e3fde008e  call rax
00007f4e3fde0090  movaps xmm8, [rsp]
00007f4e3fde0095  add rsp, 0x30
00007f4e3fde0099  vmovaps xmm0, [rsp]
00007f4e3fde009e  vmovaps xmm1, [rsp+0x10]
00007f4e3fde00a4  vmovaps xmm2, [rsp+0x20]
00007f4e3fde00aa  vmovaps xmm3, [rsp+0x30]
00007f4e3fde00b0  vmovaps xmm4, [rsp+0x40]
00007f4e3fde00b6  vmovaps xmm5, [rsp+0x50]
00007f4e3fde00bc  vmovaps xmm6, [rsp+0x60]
00007f4e3fde00c2  vmovaps xmm7, [rsp+0x70]
00007f4e3fde00c8  vmovaps xmm9, [rsp+0x80]
00007f4e3fde00d1  vmovaps xmm10, [rsp+0x90]
00007f4e3fde00da  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde00e3  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde00ec  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde00f5  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde00fe  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0107  add rsp, 0xF0
00007f4e3fde010e  pop r11
00007f4e3fde0110  pop r10
00007f4e3fde0112  pop r9
00007f4e3fde0114  pop r8
00007f4e3fde0116  pop rsi
00007f4e3fde0117  pop rdi
00007f4e3fde0118  pop rdx
00007f4e3fde0119  pop rcx
00007f4e3fde011a  pop rax
00007f4e3fde011b  add rsp, 0x08
00007f4e3fde011f  jmp 0x00007F4E3FDDC561
00007f4e3fde0124  sub rsp, 0x08
00007f4e3fde0128  push rax
00007f4e3fde0129  push rcx
00007f4e3fde012a  push rdx
00007f4e3fde012b  push rdi
00007f4e3fde012c  push rsi
00007f4e3fde012d  push r8
00007f4e3fde012f  push r9
00007f4e3fde0131  push r10
00007f4e3fde0133  push r11
00007f4e3fde0135  sub rsp, 0xF0
00007f4e3fde013c  vmovaps [rsp], xmm0
00007f4e3fde0141  vmovaps [rsp+0x10], xmm1
00007f4e3fde0147  vmovaps [rsp+0x20], xmm2
00007f4e3fde014d  vmovaps [rsp+0x30], xmm3
00007f4e3fde0153  vmovaps [rsp+0x40], xmm4
00007f4e3fde0159  vmovaps [rsp+0x50], xmm5
00007f4e3fde015f  vmovaps [rsp+0x60], xmm7
00007f4e3fde0165  vmovaps [rsp+0x70], xmm8
00007f4e3fde016b  vmovaps [rsp+0x80], xmm9
00007f4e3fde0174  vmovaps [rsp+0x90], xmm10
00007f4e3fde017d  vmovaps [rsp+0xA0], xmm11
00007f4e3fde0186  vmovaps [rsp+0xB0], xmm12
00007f4e3fde018f  vmovaps [rsp+0xC0], xmm13
00007f4e3fde0198  vmovaps [rsp+0xD0], xmm14
00007f4e3fde01a1  vmovaps [rsp+0xE0], xmm15
00007f4e3fde01aa  sub rsp, 0x30
00007f4e3fde01ae  movaps [rsp], xmm6
00007f4e3fde01b2  movaps [rsp+0x10], xmm1
00007f4e3fde01b7  movaps [rsp+0x20], xmm14
00007f4e3fde01bd  lea rdi, [rsp]
00007f4e3fde01c1  mov esi, 0x00
00007f4e3fde01c6  mov rax, 0x5D97141E9530
00007f4e3fde01d0  call rax
00007f4e3fde01d2  movaps xmm6, [rsp]
00007f4e3fde01d6  add rsp, 0x30
00007f4e3fde01da  vmovaps xmm0, [rsp]
00007f4e3fde01df  vmovaps xmm1, [rsp+0x10]
00007f4e3fde01e5  vmovaps xmm2, [rsp+0x20]
00007f4e3fde01eb  vmovaps xmm3, [rsp+0x30]
00007f4e3fde01f1  vmovaps xmm4, [rsp+0x40]
00007f4e3fde01f7  vmovaps xmm5, [rsp+0x50]
00007f4e3fde01fd  vmovaps xmm7, [rsp+0x60]
00007f4e3fde0203  vmovaps xmm8, [rsp+0x70]
00007f4e3fde0209  vmovaps xmm9, [rsp+0x80]
00007f4e3fde0212  vmovaps xmm10, [rsp+0x90]
00007f4e3fde021b  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde0224  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde022d  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde0236  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde023f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0248  add rsp, 0xF0
00007f4e3fde024f  pop r11
00007f4e3fde0251  pop r10
00007f4e3fde0253  pop r9
00007f4e3fde0255  pop r8
00007f4e3fde0257  pop rsi
00007f4e3fde0258  pop rdi
00007f4e3fde0259  pop rdx
00007f4e3fde025a  pop rcx
00007f4e3fde025b  pop rax
00007f4e3fde025c  add rsp, 0x08
00007f4e3fde0260  jmp 0x00007F4E3FDDC58D
00007f4e3fde0265  sub rsp, 0x08
00007f4e3fde0269  push rax
00007f4e3fde026a  push rcx
00007f4e3fde026b  push rdx
00007f4e3fde026c  push rdi
00007f4e3fde026d  push rsi
00007f4e3fde026e  push r8
00007f4e3fde0270  push r9
00007f4e3fde0272  push r10
00007f4e3fde0274  push r11
00007f4e3fde0276  sub rsp, 0xF0
00007f4e3fde027d  vmovaps [rsp], xmm0
00007f4e3fde0282  vmovaps [rsp+0x10], xmm1
00007f4e3fde0288  vmovaps [rsp+0x20], xmm2
00007f4e3fde028e  vmovaps [rsp+0x30], xmm3
00007f4e3fde0294  vmovaps [rsp+0x40], xmm4
00007f4e3fde029a  vmovaps [rsp+0x50], xmm5
00007f4e3fde02a0  vmovaps [rsp+0x60], xmm6
00007f4e3fde02a6  vmovaps [rsp+0x70], xmm7
00007f4e3fde02ac  vmovaps [rsp+0x80], xmm8
00007f4e3fde02b5  vmovaps [rsp+0x90], xmm9
00007f4e3fde02be  vmovaps [rsp+0xA0], xmm10
00007f4e3fde02c7  vmovaps [rsp+0xB0], xmm11
00007f4e3fde02d0  vmovaps [rsp+0xC0], xmm12
00007f4e3fde02d9  vmovaps [rsp+0xD0], xmm13
00007f4e3fde02e2  vmovaps [rsp+0xE0], xmm15
00007f4e3fde02eb  sub rsp, 0x30
00007f4e3fde02ef  movaps [rsp], xmm14
00007f4e3fde02f4  movaps [rsp+0x10], xmm12
00007f4e3fde02fa  movaps [rsp+0x20], xmm1
00007f4e3fde02ff  lea rdi, [rsp]
00007f4e3fde0303  mov esi, 0x00
00007f4e3fde0308  mov rax, 0x5D97141E9530
00007f4e3fde0312  call rax
00007f4e3fde0314  movaps xmm14, [rsp]
00007f4e3fde0319  add rsp, 0x30
00007f4e3fde031d  vmovaps xmm0, [rsp]
00007f4e3fde0322  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0328  vmovaps xmm2, [rsp+0x20]
00007f4e3fde032e  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0334  vmovaps xmm4, [rsp+0x40]
00007f4e3fde033a  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0340  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0346  vmovaps xmm7, [rsp+0x70]
00007f4e3fde034c  vmovaps xmm8, [rsp+0x80]
00007f4e3fde0355  vmovaps xmm9, [rsp+0x90]
00007f4e3fde035e  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde0367  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde0370  vmovaps xmm12, [rsp+0xC0]
00007f4e3fde0379  vmovaps xmm13, [rsp+0xD0]
00007f4e3fde0382  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde038b  add rsp, 0xF0
00007f4e3fde0392  pop r11
00007f4e3fde0394  pop r10
00007f4e3fde0396  pop r9
00007f4e3fde0398  pop r8
00007f4e3fde039a  pop rsi
00007f4e3fde039b  pop rdi
00007f4e3fde039c  pop rdx
00007f4e3fde039d  pop rcx
00007f4e3fde039e  pop rax
00007f4e3fde039f  add rsp, 0x08
00007f4e3fde03a3  jmp 0x00007F4E3FDDC5B3
00007f4e3fde03a8  sub rsp, 0x08
00007f4e3fde03ac  push rax
00007f4e3fde03ad  push rcx
00007f4e3fde03ae  push rdx
00007f4e3fde03af  push rdi
00007f4e3fde03b0  push rsi
00007f4e3fde03b1  push r8
00007f4e3fde03b3  push r9
00007f4e3fde03b5  push r10
00007f4e3fde03b7  push r11
00007f4e3fde03b9  sub rsp, 0xF0
00007f4e3fde03c0  vmovaps [rsp], xmm0
00007f4e3fde03c5  vmovaps [rsp+0x10], xmm2
00007f4e3fde03cb  vmovaps [rsp+0x20], xmm3
00007f4e3fde03d1  vmovaps [rsp+0x30], xmm4
00007f4e3fde03d7  vmovaps [rsp+0x40], xmm5
00007f4e3fde03dd  vmovaps [rsp+0x50], xmm6
00007f4e3fde03e3  vmovaps [rsp+0x60], xmm7
00007f4e3fde03e9  vmovaps [rsp+0x70], xmm8
00007f4e3fde03ef  vmovaps [rsp+0x80], xmm9
00007f4e3fde03f8  vmovaps [rsp+0x90], xmm10
00007f4e3fde0401  vmovaps [rsp+0xA0], xmm11
00007f4e3fde040a  vmovaps [rsp+0xB0], xmm12
00007f4e3fde0413  vmovaps [rsp+0xC0], xmm13
00007f4e3fde041c  vmovaps [rsp+0xD0], xmm14
00007f4e3fde0425  vmovaps [rsp+0xE0], xmm15
00007f4e3fde042e  sub rsp, 0x30
00007f4e3fde0432  movaps [rsp], xmm1
00007f4e3fde0436  movaps [rsp+0x10], xmm13
00007f4e3fde043c  movaps [rsp+0x20], xmm9
00007f4e3fde0442  lea rdi, [rsp]
00007f4e3fde0446  mov esi, 0x00
00007f4e3fde044b  mov rax, 0x5D97141E9530
00007f4e3fde0455  call rax
00007f4e3fde0457  movaps xmm1, [rsp]
00007f4e3fde045b  add rsp, 0x30
00007f4e3fde045f  vmovaps xmm0, [rsp]
00007f4e3fde0464  vmovaps xmm2, [rsp+0x10]
00007f4e3fde046a  vmovaps xmm3, [rsp+0x20]
00007f4e3fde0470  vmovaps xmm4, [rsp+0x30]
00007f4e3fde0476  vmovaps xmm5, [rsp+0x40]
00007f4e3fde047c  vmovaps xmm6, [rsp+0x50]
00007f4e3fde0482  vmovaps xmm7, [rsp+0x60]
00007f4e3fde0488  vmovaps xmm8, [rsp+0x70]
00007f4e3fde048e  vmovaps xmm9, [rsp+0x80]
00007f4e3fde0497  vmovaps xmm10, [rsp+0x90]
00007f4e3fde04a0  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde04a9  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde04b2  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde04bb  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde04c4  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde04cd  add rsp, 0xF0
00007f4e3fde04d4  pop r11
00007f4e3fde04d6  pop r10
00007f4e3fde04d8  pop r9
00007f4e3fde04da  pop r8
00007f4e3fde04dc  pop rsi
00007f4e3fde04dd  pop rdi
00007f4e3fde04de  pop rdx
00007f4e3fde04df  pop rcx
00007f4e3fde04e0  pop rax
00007f4e3fde04e1  add rsp, 0x08
00007f4e3fde04e5  jmp 0x00007F4E3FDDC5CD
00007f4e3fde04ea  sub rsp, 0x08
00007f4e3fde04ee  push rax
00007f4e3fde04ef  push rcx
00007f4e3fde04f0  push rdx
00007f4e3fde04f1  push rdi
00007f4e3fde04f2  push rsi
00007f4e3fde04f3  push r8
00007f4e3fde04f5  push r9
00007f4e3fde04f7  push r10
00007f4e3fde04f9  push r11
00007f4e3fde04fb  sub rsp, 0xF0
00007f4e3fde0502  vmovaps [rsp], xmm0
00007f4e3fde0507  vmovaps [rsp+0x10], xmm1
00007f4e3fde050d  vmovaps [rsp+0x20], xmm2
00007f4e3fde0513  vmovaps [rsp+0x30], xmm3
00007f4e3fde0519  vmovaps [rsp+0x40], xmm4
00007f4e3fde051f  vmovaps [rsp+0x50], xmm5
00007f4e3fde0525  vmovaps [rsp+0x60], xmm6
00007f4e3fde052b  vmovaps [rsp+0x70], xmm7
00007f4e3fde0531  vmovaps [rsp+0x80], xmm8
00007f4e3fde053a  vmovaps [rsp+0x90], xmm9
00007f4e3fde0543  vmovaps [rsp+0xA0], xmm10
00007f4e3fde054c  vmovaps [rsp+0xB0], xmm11
00007f4e3fde0555  vmovaps [rsp+0xC0], xmm13
00007f4e3fde055e  vmovaps [rsp+0xD0], xmm14
00007f4e3fde0567  vmovaps [rsp+0xE0], xmm15
00007f4e3fde0570  sub rsp, 0x30
00007f4e3fde0574  movaps [rsp], xmm12
00007f4e3fde0579  movaps [rsp+0x10], xmm7
00007f4e3fde057e  movaps [rsp+0x20], xmm13
00007f4e3fde0584  lea rdi, [rsp]
00007f4e3fde0588  mov esi, 0x00
00007f4e3fde058d  mov rax, 0x5D97141E9530
00007f4e3fde0597  call rax
00007f4e3fde0599  movaps xmm12, [rsp]
00007f4e3fde059e  add rsp, 0x30
00007f4e3fde05a2  vmovaps xmm0, [rsp]
00007f4e3fde05a7  vmovaps xmm1, [rsp+0x10]
00007f4e3fde05ad  vmovaps xmm2, [rsp+0x20]
00007f4e3fde05b3  vmovaps xmm3, [rsp+0x30]
00007f4e3fde05b9  vmovaps xmm4, [rsp+0x40]
00007f4e3fde05bf  vmovaps xmm5, [rsp+0x50]
00007f4e3fde05c5  vmovaps xmm6, [rsp+0x60]
00007f4e3fde05cb  vmovaps xmm7, [rsp+0x70]
00007f4e3fde05d1  vmovaps xmm8, [rsp+0x80]
00007f4e3fde05da  vmovaps xmm9, [rsp+0x90]
00007f4e3fde05e3  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde05ec  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde05f5  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde05fe  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde0607  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0610  add rsp, 0xF0
00007f4e3fde0617  pop r11
00007f4e3fde0619  pop r10
00007f4e3fde061b  pop r9
00007f4e3fde061d  pop r8
00007f4e3fde061f  pop rsi
00007f4e3fde0620  pop rdi
00007f4e3fde0621  pop rdx
00007f4e3fde0622  pop rcx
00007f4e3fde0623  pop rax
00007f4e3fde0624  add rsp, 0x08
00007f4e3fde0628  jmp 0x00007F4E3FDDC5F4
00007f4e3fde062d  sub rsp, 0x08
00007f4e3fde0631  push rax
00007f4e3fde0632  push rcx
00007f4e3fde0633  push rdx
00007f4e3fde0634  push rdi
00007f4e3fde0635  push rsi
00007f4e3fde0636  push r8
00007f4e3fde0638  push r9
00007f4e3fde063a  push r10
00007f4e3fde063c  push r11
00007f4e3fde063e  sub rsp, 0xF0
00007f4e3fde0645  vmovaps [rsp], xmm0
00007f4e3fde064a  vmovaps [rsp+0x10], xmm1
00007f4e3fde0650  vmovaps [rsp+0x20], xmm2
00007f4e3fde0656  vmovaps [rsp+0x30], xmm3
00007f4e3fde065c  vmovaps [rsp+0x40], xmm4
00007f4e3fde0662  vmovaps [rsp+0x50], xmm5
00007f4e3fde0668  vmovaps [rsp+0x60], xmm6
00007f4e3fde066e  vmovaps [rsp+0x70], xmm7
00007f4e3fde0674  vmovaps [rsp+0x80], xmm8
00007f4e3fde067d  vmovaps [rsp+0x90], xmm9
00007f4e3fde0686  vmovaps [rsp+0xA0], xmm10
00007f4e3fde068f  vmovaps [rsp+0xB0], xmm11
00007f4e3fde0698  vmovaps [rsp+0xC0], xmm12
00007f4e3fde06a1  vmovaps [rsp+0xD0], xmm14
00007f4e3fde06aa  vmovaps [rsp+0xE0], xmm15
00007f4e3fde06b3  sub rsp, 0x30
00007f4e3fde06b7  movaps [rsp], xmm13
00007f4e3fde06bc  movaps [rsp+0x10], xmm15
00007f4e3fde06c2  movaps [rsp+0x20], xmm8
00007f4e3fde06c8  lea rdi, [rsp]
00007f4e3fde06cc  mov esi, 0x00
00007f4e3fde06d1  mov rax, 0x5D97141E9530
00007f4e3fde06db  call rax
00007f4e3fde06dd  movaps xmm13, [rsp]
00007f4e3fde06e2  add rsp, 0x30
00007f4e3fde06e6  vmovaps xmm0, [rsp]
00007f4e3fde06eb  vmovaps xmm1, [rsp+0x10]
00007f4e3fde06f1  vmovaps xmm2, [rsp+0x20]
00007f4e3fde06f7  vmovaps xmm3, [rsp+0x30]
00007f4e3fde06fd  vmovaps xmm4, [rsp+0x40]
00007f4e3fde0703  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0709  vmovaps xmm6, [rsp+0x60]
00007f4e3fde070f  vmovaps xmm7, [rsp+0x70]
00007f4e3fde0715  vmovaps xmm8, [rsp+0x80]
00007f4e3fde071e  vmovaps xmm9, [rsp+0x90]
00007f4e3fde0727  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde0730  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde0739  vmovaps xmm12, [rsp+0xC0]
00007f4e3fde0742  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde074b  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0754  add rsp, 0xF0
00007f4e3fde075b  pop r11
00007f4e3fde075d  pop r10
00007f4e3fde075f  pop r9
00007f4e3fde0761  pop r8
00007f4e3fde0763  pop rsi
00007f4e3fde0764  pop rdi
00007f4e3fde0765  pop rdx
00007f4e3fde0766  pop rcx
00007f4e3fde0767  pop rax
00007f4e3fde0768  add rsp, 0x08
00007f4e3fde076c  jmp 0x00007F4E3FDDC60F
00007f4e3fde0771  sub rsp, 0x08
00007f4e3fde0775  push rax
00007f4e3fde0776  push rcx
00007f4e3fde0777  push rdx
00007f4e3fde0778  push rdi
00007f4e3fde0779  push rsi
00007f4e3fde077a  push r8
00007f4e3fde077c  push r9
00007f4e3fde077e  push r10
00007f4e3fde0780  push r11
00007f4e3fde0782  sub rsp, 0xF0
00007f4e3fde0789  vmovaps [rsp], xmm0
00007f4e3fde078e  vmovaps [rsp+0x10], xmm1
00007f4e3fde0794  vmovaps [rsp+0x20], xmm2
00007f4e3fde079a  vmovaps [rsp+0x30], xmm3
00007f4e3fde07a0  vmovaps [rsp+0x40], xmm4
00007f4e3fde07a6  vmovaps [rsp+0x50], xmm5
00007f4e3fde07ac  vmovaps [rsp+0x60], xmm6
00007f4e3fde07b2  vmovaps [rsp+0x70], xmm7
00007f4e3fde07b8  vmovaps [rsp+0x80], xmm9
00007f4e3fde07c1  vmovaps [rsp+0x90], xmm10
00007f4e3fde07ca  vmovaps [rsp+0xA0], xmm11
00007f4e3fde07d3  vmovaps [rsp+0xB0], xmm12
00007f4e3fde07dc  vmovaps [rsp+0xC0], xmm13
00007f4e3fde07e5  vmovaps [rsp+0xD0], xmm14
00007f4e3fde07ee  vmovaps [rsp+0xE0], xmm15
00007f4e3fde07f7  sub rsp, 0x30
00007f4e3fde07fb  movaps [rsp], xmm8
00007f4e3fde0800  movaps [rsp+0x10], xmm15
00007f4e3fde0806  movaps [rsp+0x20], xmm9
00007f4e3fde080c  lea rdi, [rsp]
00007f4e3fde0810  mov esi, 0x00
00007f4e3fde0815  mov rax, 0x5D97141E9530
00007f4e3fde081f  call rax
00007f4e3fde0821  movaps xmm8, [rsp]
00007f4e3fde0826  add rsp, 0x30
00007f4e3fde082a  vmovaps xmm0, [rsp]
00007f4e3fde082f  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0835  vmovaps xmm2, [rsp+0x20]
00007f4e3fde083b  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0841  vmovaps xmm4, [rsp+0x40]
00007f4e3fde0847  vmovaps xmm5, [rsp+0x50]
00007f4e3fde084d  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0853  vmovaps xmm7, [rsp+0x70]
00007f4e3fde0859  vmovaps xmm9, [rsp+0x80]
00007f4e3fde0862  vmovaps xmm10, [rsp+0x90]
00007f4e3fde086b  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde0874  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde087d  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde0886  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde088f  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0898  add rsp, 0xF0
00007f4e3fde089f  pop r11
00007f4e3fde08a1  pop r10
00007f4e3fde08a3  pop r9
00007f4e3fde08a5  pop r8
00007f4e3fde08a7  pop rsi
00007f4e3fde08a8  pop rdi
00007f4e3fde08a9  pop rdx
00007f4e3fde08aa  pop rcx
00007f4e3fde08ab  pop rax
00007f4e3fde08ac  add rsp, 0x08
00007f4e3fde08b0  jmp 0x00007F4E3FDDC63D
00007f4e3fde08b5  sub rsp, 0x08
00007f4e3fde08b9  push rax
00007f4e3fde08ba  push rcx
00007f4e3fde08bb  push rdx
00007f4e3fde08bc  push rdi
00007f4e3fde08bd  push rsi
00007f4e3fde08be  push r8
00007f4e3fde08c0  push r9
00007f4e3fde08c2  push r10
00007f4e3fde08c4  push r11
00007f4e3fde08c6  sub rsp, 0xF0
00007f4e3fde08cd  vmovaps [rsp], xmm0
00007f4e3fde08d2  vmovaps [rsp+0x10], xmm1
00007f4e3fde08d8  vmovaps [rsp+0x20], xmm2
00007f4e3fde08de  vmovaps [rsp+0x30], xmm3
00007f4e3fde08e4  vmovaps [rsp+0x40], xmm4
00007f4e3fde08ea  vmovaps [rsp+0x50], xmm5
00007f4e3fde08f0  vmovaps [rsp+0x60], xmm6
00007f4e3fde08f6  vmovaps [rsp+0x70], xmm7
00007f4e3fde08fc  vmovaps [rsp+0x80], xmm8
00007f4e3fde0905  vmovaps [rsp+0x90], xmm9
00007f4e3fde090e  vmovaps [rsp+0xA0], xmm10
00007f4e3fde0917  vmovaps [rsp+0xB0], xmm11
00007f4e3fde0920  vmovaps [rsp+0xC0], xmm12
00007f4e3fde0929  vmovaps [rsp+0xD0], xmm13
00007f4e3fde0932  vmovaps [rsp+0xE0], xmm14
00007f4e3fde093b  sub rsp, 0x30
00007f4e3fde093f  movaps [rsp], xmm15
00007f4e3fde0944  movaps [rsp+0x10], xmm11
00007f4e3fde094a  movaps [rsp+0x20], xmm6
00007f4e3fde094f  lea rdi, [rsp]
00007f4e3fde0953  mov esi, 0x00
00007f4e3fde0958  mov rax, 0x5D97141E9530
00007f4e3fde0962  call rax
00007f4e3fde0964  movaps xmm15, [rsp]
00007f4e3fde0969  add rsp, 0x30
00007f4e3fde096d  vmovaps xmm0, [rsp]
00007f4e3fde0972  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0978  vmovaps xmm2, [rsp+0x20]
00007f4e3fde097e  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0984  vmovaps xmm4, [rsp+0x40]
00007f4e3fde098a  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0990  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0996  vmovaps xmm7, [rsp+0x70]
00007f4e3fde099c  vmovaps xmm8, [rsp+0x80]
00007f4e3fde09a5  vmovaps xmm9, [rsp+0x90]
00007f4e3fde09ae  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde09b7  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde09c0  vmovaps xmm12, [rsp+0xC0]
00007f4e3fde09c9  vmovaps xmm13, [rsp+0xD0]
00007f4e3fde09d2  vmovaps xmm14, [rsp+0xE0]
00007f4e3fde09db  add rsp, 0xF0
00007f4e3fde09e2  pop r11
00007f4e3fde09e4  pop r10
00007f4e3fde09e6  pop r9
00007f4e3fde09e8  pop r8
00007f4e3fde09ea  pop rsi
00007f4e3fde09eb  pop rdi
00007f4e3fde09ec  pop rdx
00007f4e3fde09ed  pop rcx
00007f4e3fde09ee  pop rax
00007f4e3fde09ef  add rsp, 0x08
00007f4e3fde09f3  jmp 0x00007F4E3FDDC658
00007f4e3fde09f8  sub rsp, 0x08
00007f4e3fde09fc  push rax
00007f4e3fde09fd  push rcx
00007f4e3fde09fe  push rdx
00007f4e3fde09ff  push rdi
00007f4e3fde0a00  push rsi
00007f4e3fde0a01  push r8
00007f4e3fde0a03  push r9
00007f4e3fde0a05  push r10
00007f4e3fde0a07  push r11
00007f4e3fde0a09  sub rsp, 0xF0
00007f4e3fde0a10  vmovaps [rsp], xmm0
00007f4e3fde0a15  vmovaps [rsp+0x10], xmm1
00007f4e3fde0a1b  vmovaps [rsp+0x20], xmm2
00007f4e3fde0a21  vmovaps [rsp+0x30], xmm3
00007f4e3fde0a27  vmovaps [rsp+0x40], xmm4
00007f4e3fde0a2d  vmovaps [rsp+0x50], xmm5
00007f4e3fde0a33  vmovaps [rsp+0x60], xmm6
00007f4e3fde0a39  vmovaps [rsp+0x70], xmm8
00007f4e3fde0a3f  vmovaps [rsp+0x80], xmm9
00007f4e3fde0a48  vmovaps [rsp+0x90], xmm10
00007f4e3fde0a51  vmovaps [rsp+0xA0], xmm11
00007f4e3fde0a5a  vmovaps [rsp+0xB0], xmm12
00007f4e3fde0a63  vmovaps [rsp+0xC0], xmm13
00007f4e3fde0a6c  vmovaps [rsp+0xD0], xmm14
00007f4e3fde0a75  vmovaps [rsp+0xE0], xmm15
00007f4e3fde0a7e  sub rsp, 0x30
00007f4e3fde0a82  movaps [rsp], xmm7
00007f4e3fde0a86  movaps [rsp+0x10], xmm11
00007f4e3fde0a8c  movaps [rsp+0x20], xmm9
00007f4e3fde0a92  lea rdi, [rsp]
00007f4e3fde0a96  mov esi, 0x00
00007f4e3fde0a9b  mov rax, 0x5D97141E9530
00007f4e3fde0aa5  call rax
00007f4e3fde0aa7  movaps xmm7, [rsp]
00007f4e3fde0aab  add rsp, 0x30
00007f4e3fde0aaf  vmovaps xmm0, [rsp]
00007f4e3fde0ab4  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0aba  vmovaps xmm2, [rsp+0x20]
00007f4e3fde0ac0  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0ac6  vmovaps xmm4, [rsp+0x40]
00007f4e3fde0acc  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0ad2  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0ad8  vmovaps xmm8, [rsp+0x70]
00007f4e3fde0ade  vmovaps xmm9, [rsp+0x80]
00007f4e3fde0ae7  vmovaps xmm10, [rsp+0x90]
00007f4e3fde0af0  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde0af9  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde0b02  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde0b0b  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde0b14  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0b1d  add rsp, 0xF0
00007f4e3fde0b24  pop r11
00007f4e3fde0b26  pop r10
00007f4e3fde0b28  pop r9
00007f4e3fde0b2a  pop r8
00007f4e3fde0b2c  pop rsi
00007f4e3fde0b2d  pop rdi
00007f4e3fde0b2e  pop rdx
00007f4e3fde0b2f  pop rcx
00007f4e3fde0b30  pop rax
00007f4e3fde0b31  add rsp, 0x08
00007f4e3fde0b35  jmp 0x00007F4E3FDDC685
00007f4e3fde0b3a  sub rsp, 0x08
00007f4e3fde0b3e  push rax
00007f4e3fde0b3f  push rcx
00007f4e3fde0b40  push rdx
00007f4e3fde0b41  push rdi
00007f4e3fde0b42  push rsi
00007f4e3fde0b43  push r8
00007f4e3fde0b45  push r9
00007f4e3fde0b47  push r10
00007f4e3fde0b49  push r11
00007f4e3fde0b4b  sub rsp, 0xF0
00007f4e3fde0b52  vmovaps [rsp], xmm0
00007f4e3fde0b57  vmovaps [rsp+0x10], xmm1
00007f4e3fde0b5d  vmovaps [rsp+0x20], xmm2
00007f4e3fde0b63  vmovaps [rsp+0x30], xmm3
00007f4e3fde0b69  vmovaps [rsp+0x40], xmm4
00007f4e3fde0b6f  vmovaps [rsp+0x50], xmm5
00007f4e3fde0b75  vmovaps [rsp+0x60], xmm6
00007f4e3fde0b7b  vmovaps [rsp+0x70], xmm7
00007f4e3fde0b81  vmovaps [rsp+0x80], xmm8
00007f4e3fde0b8a  vmovaps [rsp+0x90], xmm9
00007f4e3fde0b93  vmovaps [rsp+0xA0], xmm10
00007f4e3fde0b9c  vmovaps [rsp+0xB0], xmm12
00007f4e3fde0ba5  vmovaps [rsp+0xC0], xmm13
00007f4e3fde0bae  vmovaps [rsp+0xD0], xmm14
00007f4e3fde0bb7  vmovaps [rsp+0xE0], xmm15
00007f4e3fde0bc0  sub rsp, 0x30
00007f4e3fde0bc4  movaps [rsp], xmm11
00007f4e3fde0bc9  movaps [rsp+0x10], xmm10
00007f4e3fde0bcf  movaps [rsp+0x20], xmm14
00007f4e3fde0bd5  lea rdi, [rsp]
00007f4e3fde0bd9  mov esi, 0x00
00007f4e3fde0bde  mov rax, 0x5D97141E9530
00007f4e3fde0be8  call rax
00007f4e3fde0bea  movaps xmm11, [rsp]
00007f4e3fde0bef  add rsp, 0x30
00007f4e3fde0bf3  vmovaps xmm0, [rsp]
00007f4e3fde0bf8  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0bfe  vmovaps xmm2, [rsp+0x20]
00007f4e3fde0c04  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0c0a  vmovaps xmm4, [rsp+0x40]
00007f4e3fde0c10  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0c16  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0c1c  vmovaps xmm7, [rsp+0x70]
00007f4e3fde0c22  vmovaps xmm8, [rsp+0x80]
00007f4e3fde0c2b  vmovaps xmm9, [rsp+0x90]
00007f4e3fde0c34  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde0c3d  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde0c46  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde0c4f  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde0c58  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0c61  add rsp, 0xF0
00007f4e3fde0c68  pop r11
00007f4e3fde0c6a  pop r10
00007f4e3fde0c6c  pop r9
00007f4e3fde0c6e  pop r8
00007f4e3fde0c70  pop rsi
00007f4e3fde0c71  pop rdi
00007f4e3fde0c72  pop rdx
00007f4e3fde0c73  pop rcx
00007f4e3fde0c74  pop rax
00007f4e3fde0c75  add rsp, 0x08
00007f4e3fde0c79  jmp 0x00007F4E3FDDC6A0
00007f4e3fde0c7e  call 0x00007F4E3FCC33A0
00007f4e3fde0c83  jmp 0x00007F4E3FDDC6AA
00007f4e3fde0c88  sub rsp, 0x08
00007f4e3fde0c8c  push rax
00007f4e3fde0c8d  push rcx
00007f4e3fde0c8e  push rdx
00007f4e3fde0c8f  push rdi
00007f4e3fde0c90  push rsi
00007f4e3fde0c91  push r8
00007f4e3fde0c93  push r9
00007f4e3fde0c95  push r10
00007f4e3fde0c97  push r11
00007f4e3fde0c99  sub rsp, 0xF0
00007f4e3fde0ca0  vmovaps [rsp], xmm0
00007f4e3fde0ca5  vmovaps [rsp+0x10], xmm1
00007f4e3fde0cab  vmovaps [rsp+0x20], xmm2
00007f4e3fde0cb1  vmovaps [rsp+0x30], xmm3
00007f4e3fde0cb7  vmovaps [rsp+0x40], xmm4
00007f4e3fde0cbd  vmovaps [rsp+0x50], xmm5
00007f4e3fde0cc3  vmovaps [rsp+0x60], xmm6
00007f4e3fde0cc9  vmovaps [rsp+0x70], xmm7
00007f4e3fde0ccf  vmovaps [rsp+0x80], xmm8
00007f4e3fde0cd8  vmovaps [rsp+0x90], xmm9
00007f4e3fde0ce1  vmovaps [rsp+0xA0], xmm11
00007f4e3fde0cea  vmovaps [rsp+0xB0], xmm12
00007f4e3fde0cf3  vmovaps [rsp+0xC0], xmm13
00007f4e3fde0cfc  vmovaps [rsp+0xD0], xmm14
00007f4e3fde0d05  vmovaps [rsp+0xE0], xmm15
00007f4e3fde0d0e  sub rsp, 0x30
00007f4e3fde0d12  movaps [rsp], xmm10
00007f4e3fde0d17  movaps [rsp+0x10], xmm1
00007f4e3fde0d1c  movaps [rsp+0x20], xmm12
00007f4e3fde0d22  lea rdi, [rsp]
00007f4e3fde0d26  mov esi, 0x00
00007f4e3fde0d2b  mov rax, 0x5D97141E9530
00007f4e3fde0d35  call rax
00007f4e3fde0d37  movaps xmm10, [rsp]
00007f4e3fde0d3c  add rsp, 0x30
00007f4e3fde0d40  vmovaps xmm0, [rsp]
00007f4e3fde0d45  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0d4b  vmovaps xmm2, [rsp+0x20]
00007f4e3fde0d51  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0d57  vmovaps xmm4, [rsp+0x40]
00007f4e3fde0d5d  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0d63  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0d69  vmovaps xmm7, [rsp+0x70]
00007f4e3fde0d6f  vmovaps xmm8, [rsp+0x80]
00007f4e3fde0d78  vmovaps xmm9, [rsp+0x90]
00007f4e3fde0d81  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde0d8a  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde0d93  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde0d9c  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde0da5  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0dae  add rsp, 0xF0
00007f4e3fde0db5  pop r11
00007f4e3fde0db7  pop r10
00007f4e3fde0db9  pop r9
00007f4e3fde0dbb  pop r8
00007f4e3fde0dbd  pop rsi
00007f4e3fde0dbe  pop rdi
00007f4e3fde0dbf  pop rdx
00007f4e3fde0dc0  pop rcx
00007f4e3fde0dc1  pop rax
00007f4e3fde0dc2  add rsp, 0x08
00007f4e3fde0dc6  jmp 0x00007F4E3FDDC6CD
00007f4e3fde0dcb  sub rsp, 0x08
00007f4e3fde0dcf  push rax
00007f4e3fde0dd0  push rcx
00007f4e3fde0dd1  push rdx
00007f4e3fde0dd2  push rdi
00007f4e3fde0dd3  push rsi
00007f4e3fde0dd4  push r8
00007f4e3fde0dd6  push r9
00007f4e3fde0dd8  push r10
00007f4e3fde0dda  push r11
00007f4e3fde0ddc  sub rsp, 0xF0
00007f4e3fde0de3  vmovaps [rsp], xmm0
00007f4e3fde0de8  vmovaps [rsp+0x10], xmm1
00007f4e3fde0dee  vmovaps [rsp+0x20], xmm2
00007f4e3fde0df4  vmovaps [rsp+0x30], xmm3
00007f4e3fde0dfa  vmovaps [rsp+0x40], xmm4
00007f4e3fde0e00  vmovaps [rsp+0x50], xmm5
00007f4e3fde0e06  vmovaps [rsp+0x60], xmm6
00007f4e3fde0e0c  vmovaps [rsp+0x70], xmm7
00007f4e3fde0e12  vmovaps [rsp+0x80], xmm8
00007f4e3fde0e1b  vmovaps [rsp+0x90], xmm9
00007f4e3fde0e24  vmovaps [rsp+0xA0], xmm10
00007f4e3fde0e2d  vmovaps [rsp+0xB0], xmm11
00007f4e3fde0e36  vmovaps [rsp+0xC0], xmm13
00007f4e3fde0e3f  vmovaps [rsp+0xD0], xmm14
00007f4e3fde0e48  vmovaps [rsp+0xE0], xmm15
00007f4e3fde0e51  sub rsp, 0x30
00007f4e3fde0e55  movaps [rsp], xmm12
00007f4e3fde0e5a  movaps [rsp+0x10], xmm14
00007f4e3fde0e60  movaps [rsp+0x20], xmm1
00007f4e3fde0e65  lea rdi, [rsp]
00007f4e3fde0e69  mov esi, 0x00
00007f4e3fde0e6e  mov rax, 0x5D97141E9530
00007f4e3fde0e78  call rax
00007f4e3fde0e7a  movaps xmm12, [rsp]
00007f4e3fde0e7f  add rsp, 0x30
00007f4e3fde0e83  vmovaps xmm0, [rsp]
00007f4e3fde0e88  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0e8e  vmovaps xmm2, [rsp+0x20]
00007f4e3fde0e94  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0e9a  vmovaps xmm4, [rsp+0x40]
00007f4e3fde0ea0  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0ea6  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0eac  vmovaps xmm7, [rsp+0x70]
00007f4e3fde0eb2  vmovaps xmm8, [rsp+0x80]
00007f4e3fde0ebb  vmovaps xmm9, [rsp+0x90]
00007f4e3fde0ec4  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde0ecd  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde0ed6  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde0edf  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde0ee8  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde0ef1  add rsp, 0xF0
00007f4e3fde0ef8  pop r11
00007f4e3fde0efa  pop r10
00007f4e3fde0efc  pop r9
00007f4e3fde0efe  pop r8
00007f4e3fde0f00  pop rsi
00007f4e3fde0f01  pop rdi
00007f4e3fde0f02  pop rdx
00007f4e3fde0f03  pop rcx
00007f4e3fde0f04  pop rax
00007f4e3fde0f05  add rsp, 0x08
00007f4e3fde0f09  jmp 0x00007F4E3FDDC6FC
00007f4e3fde0f0e  sub rsp, 0x08
00007f4e3fde0f12  push rax
00007f4e3fde0f13  push rcx
00007f4e3fde0f14  push rdx
00007f4e3fde0f15  push rdi
00007f4e3fde0f16  push rsi
00007f4e3fde0f17  push r8
00007f4e3fde0f19  push r9
00007f4e3fde0f1b  push r10
00007f4e3fde0f1d  push r11
00007f4e3fde0f1f  sub rsp, 0xF0
00007f4e3fde0f26  vmovaps [rsp], xmm0
00007f4e3fde0f2b  vmovaps [rsp+0x10], xmm1
00007f4e3fde0f31  vmovaps [rsp+0x20], xmm2
00007f4e3fde0f37  vmovaps [rsp+0x30], xmm3
00007f4e3fde0f3d  vmovaps [rsp+0x40], xmm4
00007f4e3fde0f43  vmovaps [rsp+0x50], xmm5
00007f4e3fde0f49  vmovaps [rsp+0x60], xmm6
00007f4e3fde0f4f  vmovaps [rsp+0x70], xmm7
00007f4e3fde0f55  vmovaps [rsp+0x80], xmm8
00007f4e3fde0f5e  vmovaps [rsp+0x90], xmm9
00007f4e3fde0f67  vmovaps [rsp+0xA0], xmm10
00007f4e3fde0f70  vmovaps [rsp+0xB0], xmm11
00007f4e3fde0f79  vmovaps [rsp+0xC0], xmm12
00007f4e3fde0f82  vmovaps [rsp+0xD0], xmm13
00007f4e3fde0f8b  vmovaps [rsp+0xE0], xmm15
00007f4e3fde0f94  sub rsp, 0x30
00007f4e3fde0f98  movaps [rsp], xmm14
00007f4e3fde0f9d  movaps [rsp+0x10], xmm9
00007f4e3fde0fa3  movaps [rsp+0x20], xmm1
00007f4e3fde0fa8  lea rdi, [rsp]
00007f4e3fde0fac  mov esi, 0x00
00007f4e3fde0fb1  mov rax, 0x5D97141E9530
00007f4e3fde0fbb  call rax
00007f4e3fde0fbd  movaps xmm14, [rsp]
00007f4e3fde0fc2  add rsp, 0x30
00007f4e3fde0fc6  vmovaps xmm0, [rsp]
00007f4e3fde0fcb  vmovaps xmm1, [rsp+0x10]
00007f4e3fde0fd1  vmovaps xmm2, [rsp+0x20]
00007f4e3fde0fd7  vmovaps xmm3, [rsp+0x30]
00007f4e3fde0fdd  vmovaps xmm4, [rsp+0x40]
00007f4e3fde0fe3  vmovaps xmm5, [rsp+0x50]
00007f4e3fde0fe9  vmovaps xmm6, [rsp+0x60]
00007f4e3fde0fef  vmovaps xmm7, [rsp+0x70]
00007f4e3fde0ff5  vmovaps xmm8, [rsp+0x80]
00007f4e3fde0ffe  vmovaps xmm9, [rsp+0x90]
00007f4e3fde1007  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde1010  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde1019  vmovaps xmm12, [rsp+0xC0]
00007f4e3fde1022  vmovaps xmm13, [rsp+0xD0]
00007f4e3fde102b  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde1034  add rsp, 0xF0
00007f4e3fde103b  pop r11
00007f4e3fde103d  pop r10
00007f4e3fde103f  pop r9
00007f4e3fde1041  pop r8
00007f4e3fde1043  pop rsi
00007f4e3fde1044  pop rdi
00007f4e3fde1045  pop rdx
00007f4e3fde1046  pop rcx
00007f4e3fde1047  pop rax
00007f4e3fde1048  add rsp, 0x08
00007f4e3fde104c  jmp 0x00007F4E3FDDC72B
00007f4e3fde1051  sub rsp, 0x08
00007f4e3fde1055  push rax
00007f4e3fde1056  push rcx
00007f4e3fde1057  push rdx
00007f4e3fde1058  push rdi
00007f4e3fde1059  push rsi
00007f4e3fde105a  push r8
00007f4e3fde105c  push r9
00007f4e3fde105e  push r10
00007f4e3fde1060  push r11
00007f4e3fde1062  sub rsp, 0xF0
00007f4e3fde1069  vmovaps [rsp], xmm0
00007f4e3fde106e  vmovaps [rsp+0x10], xmm2
00007f4e3fde1074  vmovaps [rsp+0x20], xmm3
00007f4e3fde107a  vmovaps [rsp+0x30], xmm4
00007f4e3fde1080  vmovaps [rsp+0x40], xmm5
00007f4e3fde1086  vmovaps [rsp+0x50], xmm6
00007f4e3fde108c  vmovaps [rsp+0x60], xmm7
00007f4e3fde1092  vmovaps [rsp+0x70], xmm8
00007f4e3fde1098  vmovaps [rsp+0x80], xmm9
00007f4e3fde10a1  vmovaps [rsp+0x90], xmm10
00007f4e3fde10aa  vmovaps [rsp+0xA0], xmm11
00007f4e3fde10b3  vmovaps [rsp+0xB0], xmm12
00007f4e3fde10bc  vmovaps [rsp+0xC0], xmm13
00007f4e3fde10c5  vmovaps [rsp+0xD0], xmm14
00007f4e3fde10ce  vmovaps [rsp+0xE0], xmm15
00007f4e3fde10d7  sub rsp, 0x30
00007f4e3fde10db  movaps [rsp], xmm1
00007f4e3fde10df  movaps [rsp+0x10], xmm13
00007f4e3fde10e5  movaps [rsp+0x20], xmm8
00007f4e3fde10eb  lea rdi, [rsp]
00007f4e3fde10ef  mov esi, 0x00
00007f4e3fde10f4  mov rax, 0x5D97141E9530
00007f4e3fde10fe  call rax
00007f4e3fde1100  movaps xmm1, [rsp]
00007f4e3fde1104  add rsp, 0x30
00007f4e3fde1108  vmovaps xmm0, [rsp]
00007f4e3fde110d  vmovaps xmm2, [rsp+0x10]
00007f4e3fde1113  vmovaps xmm3, [rsp+0x20]
00007f4e3fde1119  vmovaps xmm4, [rsp+0x30]
00007f4e3fde111f  vmovaps xmm5, [rsp+0x40]
00007f4e3fde1125  vmovaps xmm6, [rsp+0x50]
00007f4e3fde112b  vmovaps xmm7, [rsp+0x60]
00007f4e3fde1131  vmovaps xmm8, [rsp+0x70]
00007f4e3fde1137  vmovaps xmm9, [rsp+0x80]
00007f4e3fde1140  vmovaps xmm10, [rsp+0x90]
00007f4e3fde1149  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde1152  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde115b  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde1164  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde116d  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde1176  add rsp, 0xF0
00007f4e3fde117d  pop r11
00007f4e3fde117f  pop r10
00007f4e3fde1181  pop r9
00007f4e3fde1183  pop r8
00007f4e3fde1185  pop rsi
00007f4e3fde1186  pop rdi
00007f4e3fde1187  pop rdx
00007f4e3fde1188  pop rcx
00007f4e3fde1189  pop rax
00007f4e3fde118a  add rsp, 0x08
00007f4e3fde118e  jmp 0x00007F4E3FDDC74D
00007f4e3fde1193  call 0x00007F4E3FC0C260
00007f4e3fde1198  jmp 0x00007F4E3FDDC75B
00007f4e3fde119d  call 0x00007F4E3FCBD750
00007f4e3fde11a2  jmp 0x00007F4E3FDDC765
00007f4e3fde11a7  sub rsp, 0x08
00007f4e3fde11ab  push rax
00007f4e3fde11ac  push rcx
00007f4e3fde11ad  push rdx
00007f4e3fde11ae  push rdi
00007f4e3fde11af  push rsi
00007f4e3fde11b0  push r8
00007f4e3fde11b2  push r9
00007f4e3fde11b4  push r10
00007f4e3fde11b6  push r11
00007f4e3fde11b8  sub rsp, 0xF0
00007f4e3fde11bf  vmovaps [rsp], xmm0
00007f4e3fde11c4  vmovaps [rsp+0x10], xmm1
00007f4e3fde11ca  vmovaps [rsp+0x20], xmm2
00007f4e3fde11d0  vmovaps [rsp+0x30], xmm3
00007f4e3fde11d6  vmovaps [rsp+0x40], xmm4
00007f4e3fde11dc  vmovaps [rsp+0x50], xmm5
00007f4e3fde11e2  vmovaps [rsp+0x60], xmm6
00007f4e3fde11e8  vmovaps [rsp+0x70], xmm7
00007f4e3fde11ee  vmovaps [rsp+0x80], xmm9
00007f4e3fde11f7  vmovaps [rsp+0x90], xmm10
00007f4e3fde1200  vmovaps [rsp+0xA0], xmm11
00007f4e3fde1209  vmovaps [rsp+0xB0], xmm12
00007f4e3fde1212  vmovaps [rsp+0xC0], xmm13
00007f4e3fde121b  vmovaps [rsp+0xD0], xmm14
00007f4e3fde1224  vmovaps [rsp+0xE0], xmm15
00007f4e3fde122d  sub rsp, 0x30
00007f4e3fde1231  movaps [rsp], xmm8
00007f4e3fde1236  movaps [rsp+0x10], xmm15
00007f4e3fde123c  movaps [rsp+0x20], xmm7
00007f4e3fde1241  lea rdi, [rsp]
00007f4e3fde1245  mov esi, 0x00
00007f4e3fde124a  mov rax, 0x5D97141E9530
00007f4e3fde1254  call rax
00007f4e3fde1256  movaps xmm8, [rsp]
00007f4e3fde125b  add rsp, 0x30
00007f4e3fde125f  vmovaps xmm0, [rsp]
00007f4e3fde1264  vmovaps xmm1, [rsp+0x10]
00007f4e3fde126a  vmovaps xmm2, [rsp+0x20]
00007f4e3fde1270  vmovaps xmm3, [rsp+0x30]
00007f4e3fde1276  vmovaps xmm4, [rsp+0x40]
00007f4e3fde127c  vmovaps xmm5, [rsp+0x50]
00007f4e3fde1282  vmovaps xmm6, [rsp+0x60]
00007f4e3fde1288  vmovaps xmm7, [rsp+0x70]
00007f4e3fde128e  vmovaps xmm9, [rsp+0x80]
00007f4e3fde1297  vmovaps xmm10, [rsp+0x90]
00007f4e3fde12a0  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde12a9  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde12b2  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde12bb  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde12c4  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde12cd  add rsp, 0xF0
00007f4e3fde12d4  pop r11
00007f4e3fde12d6  pop r10
00007f4e3fde12d8  pop r9
00007f4e3fde12da  pop r8
00007f4e3fde12dc  pop rsi
00007f4e3fde12dd  pop rdi
00007f4e3fde12de  pop rdx
00007f4e3fde12df  pop rcx
00007f4e3fde12e0  pop rax
00007f4e3fde12e1  add rsp, 0x08
00007f4e3fde12e5  jmp 0x00007F4E3FDDC787
00007f4e3fde12ea  sub rsp, 0x08
00007f4e3fde12ee  push rax
00007f4e3fde12ef  push rcx
00007f4e3fde12f0  push rdx
00007f4e3fde12f1  push rdi
00007f4e3fde12f2  push rsi
00007f4e3fde12f3  push r8
00007f4e3fde12f5  push r9
00007f4e3fde12f7  push r10
00007f4e3fde12f9  push r11
00007f4e3fde12fb  sub rsp, 0xF0
00007f4e3fde1302  vmovaps [rsp], xmm0
00007f4e3fde1307  vmovaps [rsp+0x10], xmm1
00007f4e3fde130d  vmovaps [rsp+0x20], xmm2
00007f4e3fde1313  vmovaps [rsp+0x30], xmm3
00007f4e3fde1319  vmovaps [rsp+0x40], xmm4
00007f4e3fde131f  vmovaps [rsp+0x50], xmm5
00007f4e3fde1325  vmovaps [rsp+0x60], xmm6
00007f4e3fde132b  vmovaps [rsp+0x70], xmm8
00007f4e3fde1331  vmovaps [rsp+0x80], xmm9
00007f4e3fde133a  vmovaps [rsp+0x90], xmm10
00007f4e3fde1343  vmovaps [rsp+0xA0], xmm11
00007f4e3fde134c  vmovaps [rsp+0xB0], xmm12
00007f4e3fde1355  vmovaps [rsp+0xC0], xmm13
00007f4e3fde135e  vmovaps [rsp+0xD0], xmm14
00007f4e3fde1367  vmovaps [rsp+0xE0], xmm15
00007f4e3fde1370  sub rsp, 0x30
00007f4e3fde1374  movaps [rsp], xmm7
00007f4e3fde1378  movaps [rsp+0x10], xmm9
00007f4e3fde137e  movaps [rsp+0x20], xmm15
00007f4e3fde1384  lea rdi, [rsp]
00007f4e3fde1388  mov esi, 0x00
00007f4e3fde138d  mov rax, 0x5D97141E9530
00007f4e3fde1397  call rax
00007f4e3fde1399  movaps xmm7, [rsp]
00007f4e3fde139d  add rsp, 0x30
00007f4e3fde13a1  vmovaps xmm0, [rsp]
00007f4e3fde13a6  vmovaps xmm1, [rsp+0x10]
00007f4e3fde13ac  vmovaps xmm2, [rsp+0x20]
00007f4e3fde13b2  vmovaps xmm3, [rsp+0x30]
00007f4e3fde13b8  vmovaps xmm4, [rsp+0x40]
00007f4e3fde13be  vmovaps xmm5, [rsp+0x50]
00007f4e3fde13c4  vmovaps xmm6, [rsp+0x60]
00007f4e3fde13ca  vmovaps xmm8, [rsp+0x70]
00007f4e3fde13d0  vmovaps xmm9, [rsp+0x80]
00007f4e3fde13d9  vmovaps xmm10, [rsp+0x90]
00007f4e3fde13e2  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde13eb  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde13f4  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde13fd  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde1406  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde140f  add rsp, 0xF0
00007f4e3fde1416  pop r11
00007f4e3fde1418  pop r10
00007f4e3fde141a  pop r9
00007f4e3fde141c  pop r8
00007f4e3fde141e  pop rsi
00007f4e3fde141f  pop rdi
00007f4e3fde1420  pop rdx
00007f4e3fde1421  pop rcx
00007f4e3fde1422  pop rax
00007f4e3fde1423  add rsp, 0x08
00007f4e3fde1427  jmp 0x00007F4E3FDDC7B4
00007f4e3fde142c  sub rsp, 0x08
00007f4e3fde1430  push rax
00007f4e3fde1431  push rcx
00007f4e3fde1432  push rdx
00007f4e3fde1433  push rdi
00007f4e3fde1434  push rsi
00007f4e3fde1435  push r8
00007f4e3fde1437  push r9
00007f4e3fde1439  push r10
00007f4e3fde143b  push r11
00007f4e3fde143d  sub rsp, 0xF0
00007f4e3fde1444  vmovaps [rsp], xmm0
00007f4e3fde1449  vmovaps [rsp+0x10], xmm1
00007f4e3fde144f  vmovaps [rsp+0x20], xmm2
00007f4e3fde1455  vmovaps [rsp+0x30], xmm3
00007f4e3fde145b  vmovaps [rsp+0x40], xmm4
00007f4e3fde1461  vmovaps [rsp+0x50], xmm5
00007f4e3fde1467  vmovaps [rsp+0x60], xmm6
00007f4e3fde146d  vmovaps [rsp+0x70], xmm7
00007f4e3fde1473  vmovaps [rsp+0x80], xmm8
00007f4e3fde147c  vmovaps [rsp+0x90], xmm10
00007f4e3fde1485  vmovaps [rsp+0xA0], xmm11
00007f4e3fde148e  vmovaps [rsp+0xB0], xmm12
00007f4e3fde1497  vmovaps [rsp+0xC0], xmm13
00007f4e3fde14a0  vmovaps [rsp+0xD0], xmm14
00007f4e3fde14a9  vmovaps [rsp+0xE0], xmm15
00007f4e3fde14b2  sub rsp, 0x30
00007f4e3fde14b6  movaps [rsp], xmm9
00007f4e3fde14bb  movaps [rsp+0x10], xmm13
00007f4e3fde14c1  movaps [rsp+0x20], xmm15
00007f4e3fde14c7  lea rdi, [rsp]
00007f4e3fde14cb  mov esi, 0x00
00007f4e3fde14d0  mov rax, 0x5D97141E9530
00007f4e3fde14da  call rax
00007f4e3fde14dc  movaps xmm9, [rsp]
00007f4e3fde14e1  add rsp, 0x30
00007f4e3fde14e5  vmovaps xmm0, [rsp]
00007f4e3fde14ea  vmovaps xmm1, [rsp+0x10]
00007f4e3fde14f0  vmovaps xmm2, [rsp+0x20]
00007f4e3fde14f6  vmovaps xmm3, [rsp+0x30]
00007f4e3fde14fc  vmovaps xmm4, [rsp+0x40]
00007f4e3fde1502  vmovaps xmm5, [rsp+0x50]
00007f4e3fde1508  vmovaps xmm6, [rsp+0x60]
00007f4e3fde150e  vmovaps xmm7, [rsp+0x70]
00007f4e3fde1514  vmovaps xmm8, [rsp+0x80]
00007f4e3fde151d  vmovaps xmm10, [rsp+0x90]
00007f4e3fde1526  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde152f  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde1538  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde1541  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde154a  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde1553  add rsp, 0xF0
00007f4e3fde155a  pop r11
00007f4e3fde155c  pop r10
00007f4e3fde155e  pop r9
00007f4e3fde1560  pop r8
00007f4e3fde1562  pop rsi
00007f4e3fde1563  pop rdi
00007f4e3fde1564  pop rdx
00007f4e3fde1565  pop rcx
00007f4e3fde1566  pop rax
00007f4e3fde1567  add rsp, 0x08
00007f4e3fde156b  jmp 0x00007F4E3FDDC7E2
00007f4e3fde1570  sub rsp, 0x08
00007f4e3fde1574  push rax
00007f4e3fde1575  push rcx
00007f4e3fde1576  push rdx
00007f4e3fde1577  push rdi
00007f4e3fde1578  push rsi
00007f4e3fde1579  push r8
00007f4e3fde157b  push r9
00007f4e3fde157d  push r10
00007f4e3fde157f  push r11
00007f4e3fde1581  sub rsp, 0xF0
00007f4e3fde1588  vmovaps [rsp], xmm0
00007f4e3fde158d  vmovaps [rsp+0x10], xmm1
00007f4e3fde1593  vmovaps [rsp+0x20], xmm2
00007f4e3fde1599  vmovaps [rsp+0x30], xmm3
00007f4e3fde159f  vmovaps [rsp+0x40], xmm4
00007f4e3fde15a5  vmovaps [rsp+0x50], xmm5
00007f4e3fde15ab  vmovaps [rsp+0x60], xmm6
00007f4e3fde15b1  vmovaps [rsp+0x70], xmm7
00007f4e3fde15b7  vmovaps [rsp+0x80], xmm8
00007f4e3fde15c0  vmovaps [rsp+0x90], xmm9
00007f4e3fde15c9  vmovaps [rsp+0xA0], xmm10
00007f4e3fde15d2  vmovaps [rsp+0xB0], xmm11
00007f4e3fde15db  vmovaps [rsp+0xC0], xmm12
00007f4e3fde15e4  vmovaps [rsp+0xD0], xmm13
00007f4e3fde15ed  vmovaps [rsp+0xE0], xmm14
00007f4e3fde15f6  sub rsp, 0x30
00007f4e3fde15fa  movaps [rsp], xmm15
00007f4e3fde15ff  movaps [rsp+0x10], xmm11
00007f4e3fde1605  movaps [rsp+0x20], xmm12
00007f4e3fde160b  lea rdi, [rsp]
00007f4e3fde160f  mov esi, 0x00
00007f4e3fde1614  mov rax, 0x5D97141E9530
00007f4e3fde161e  call rax
00007f4e3fde1620  movaps xmm15, [rsp]
00007f4e3fde1625  add rsp, 0x30
00007f4e3fde1629  vmovaps xmm0, [rsp]
00007f4e3fde162e  vmovaps xmm1, [rsp+0x10]
00007f4e3fde1634  vmovaps xmm2, [rsp+0x20]
00007f4e3fde163a  vmovaps xmm3, [rsp+0x30]
00007f4e3fde1640  vmovaps xmm4, [rsp+0x40]
00007f4e3fde1646  vmovaps xmm5, [rsp+0x50]
00007f4e3fde164c  vmovaps xmm6, [rsp+0x60]
00007f4e3fde1652  vmovaps xmm7, [rsp+0x70]
00007f4e3fde1658  vmovaps xmm8, [rsp+0x80]
00007f4e3fde1661  vmovaps xmm9, [rsp+0x90]
00007f4e3fde166a  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde1673  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde167c  vmovaps xmm12, [rsp+0xC0]
00007f4e3fde1685  vmovaps xmm13, [rsp+0xD0]
00007f4e3fde168e  vmovaps xmm14, [rsp+0xE0]
00007f4e3fde1697  add rsp, 0xF0
00007f4e3fde169e  pop r11
00007f4e3fde16a0  pop r10
00007f4e3fde16a2  pop r9
00007f4e3fde16a4  pop r8
00007f4e3fde16a6  pop rsi
00007f4e3fde16a7  pop rdi
00007f4e3fde16a8  pop rdx
00007f4e3fde16a9  pop rcx
00007f4e3fde16aa  pop rax
00007f4e3fde16ab  add rsp, 0x08
00007f4e3fde16af  jmp 0x00007F4E3FDDC7FD
00007f4e3fde16b4  sub rsp, 0x08
00007f4e3fde16b8  push rax
00007f4e3fde16b9  push rcx
00007f4e3fde16ba  push rdx
00007f4e3fde16bb  push rdi
00007f4e3fde16bc  push rsi
00007f4e3fde16bd  push r8
00007f4e3fde16bf  push r9
00007f4e3fde16c1  push r10
00007f4e3fde16c3  push r11
00007f4e3fde16c5  sub rsp, 0xF0
00007f4e3fde16cc  vmovaps [rsp], xmm0
00007f4e3fde16d1  vmovaps [rsp+0x10], xmm1
00007f4e3fde16d7  vmovaps [rsp+0x20], xmm2
00007f4e3fde16dd  vmovaps [rsp+0x30], xmm3
00007f4e3fde16e3  vmovaps [rsp+0x40], xmm4
00007f4e3fde16e9  vmovaps [rsp+0x50], xmm5
00007f4e3fde16ef  vmovaps [rsp+0x60], xmm6
00007f4e3fde16f5  vmovaps [rsp+0x70], xmm7
00007f4e3fde16fb  vmovaps [rsp+0x80], xmm8
00007f4e3fde1704  vmovaps [rsp+0x90], xmm9
00007f4e3fde170d  vmovaps [rsp+0xA0], xmm10
00007f4e3fde1716  vmovaps [rsp+0xB0], xmm11
00007f4e3fde171f  vmovaps [rsp+0xC0], xmm12
00007f4e3fde1728  vmovaps [rsp+0xD0], xmm14
00007f4e3fde1731  vmovaps [rsp+0xE0], xmm15
00007f4e3fde173a  sub rsp, 0x30
00007f4e3fde173e  movaps [rsp], xmm13
00007f4e3fde1743  movaps [rsp+0x10], xmm10
00007f4e3fde1749  movaps [rsp+0x20], xmm14
00007f4e3fde174f  lea rdi, [rsp]
00007f4e3fde1753  mov esi, 0x00
00007f4e3fde1758  mov rax, 0x5D97141E9530
00007f4e3fde1762  call rax
00007f4e3fde1764  movaps xmm13, [rsp]
00007f4e3fde1769  add rsp, 0x30
00007f4e3fde176d  vmovaps xmm0, [rsp]
00007f4e3fde1772  vmovaps xmm1, [rsp+0x10]
00007f4e3fde1778  vmovaps xmm2, [rsp+0x20]
00007f4e3fde177e  vmovaps xmm3, [rsp+0x30]
00007f4e3fde1784  vmovaps xmm4, [rsp+0x40]
00007f4e3fde178a  vmovaps xmm5, [rsp+0x50]
00007f4e3fde1790  vmovaps xmm6, [rsp+0x60]
00007f4e3fde1796  vmovaps xmm7, [rsp+0x70]
00007f4e3fde179c  vmovaps xmm8, [rsp+0x80]
00007f4e3fde17a5  vmovaps xmm9, [rsp+0x90]
00007f4e3fde17ae  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde17b7  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde17c0  vmovaps xmm12, [rsp+0xC0]
00007f4e3fde17c9  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde17d2  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde17db  add rsp, 0xF0
00007f4e3fde17e2  pop r11
00007f4e3fde17e4  pop r10
00007f4e3fde17e6  pop r9
00007f4e3fde17e8  pop r8
00007f4e3fde17ea  pop rsi
00007f4e3fde17eb  pop rdi
00007f4e3fde17ec  pop rdx
00007f4e3fde17ed  pop rcx
00007f4e3fde17ee  pop rax
00007f4e3fde17ef  add rsp, 0x08
00007f4e3fde17f3  jmp 0x00007F4E3FDDC820
00007f4e3fde17f8  sub rsp, 0x08
00007f4e3fde17fc  push rax
00007f4e3fde17fd  push rcx
00007f4e3fde17fe  push rdx
00007f4e3fde17ff  push rdi
00007f4e3fde1800  push rsi
00007f4e3fde1801  push r8
00007f4e3fde1803  push r9
00007f4e3fde1805  push r10
00007f4e3fde1807  push r11
00007f4e3fde1809  sub rsp, 0xF0
00007f4e3fde1810  vmovaps [rsp], xmm0
00007f4e3fde1815  vmovaps [rsp+0x10], xmm1
00007f4e3fde181b  vmovaps [rsp+0x20], xmm2
00007f4e3fde1821  vmovaps [rsp+0x30], xmm3
00007f4e3fde1827  vmovaps [rsp+0x40], xmm4
00007f4e3fde182d  vmovaps [rsp+0x50], xmm5
00007f4e3fde1833  vmovaps [rsp+0x60], xmm6
00007f4e3fde1839  vmovaps [rsp+0x70], xmm7
00007f4e3fde183f  vmovaps [rsp+0x80], xmm8
00007f4e3fde1848  vmovaps [rsp+0x90], xmm9
00007f4e3fde1851  vmovaps [rsp+0xA0], xmm10
00007f4e3fde185a  vmovaps [rsp+0xB0], xmm11
00007f4e3fde1863  vmovaps [rsp+0xC0], xmm12
00007f4e3fde186c  vmovaps [rsp+0xD0], xmm13
00007f4e3fde1875  vmovaps [rsp+0xE0], xmm15
00007f4e3fde187e  sub rsp, 0x30
00007f4e3fde1882  movaps [rsp], xmm14
00007f4e3fde1887  movaps [rsp+0x10], xmm1
00007f4e3fde188c  movaps [rsp+0x20], xmm7
00007f4e3fde1891  lea rdi, [rsp]
00007f4e3fde1895  mov esi, 0x00
00007f4e3fde189a  mov rax, 0x5D97141E9530
00007f4e3fde18a4  call rax
00007f4e3fde18a6  movaps xmm14, [rsp]
00007f4e3fde18ab  add rsp, 0x30
00007f4e3fde18af  vmovaps xmm0, [rsp]
00007f4e3fde18b4  vmovaps xmm1, [rsp+0x10]
00007f4e3fde18ba  vmovaps xmm2, [rsp+0x20]
00007f4e3fde18c0  vmovaps xmm3, [rsp+0x30]
00007f4e3fde18c6  vmovaps xmm4, [rsp+0x40]
00007f4e3fde18cc  vmovaps xmm5, [rsp+0x50]
00007f4e3fde18d2  vmovaps xmm6, [rsp+0x60]
00007f4e3fde18d8  vmovaps xmm7, [rsp+0x70]
00007f4e3fde18de  vmovaps xmm8, [rsp+0x80]
00007f4e3fde18e7  vmovaps xmm9, [rsp+0x90]
00007f4e3fde18f0  vmovaps xmm10, [rsp+0xA0]
00007f4e3fde18f9  vmovaps xmm11, [rsp+0xB0]
00007f4e3fde1902  vmovaps xmm12, [rsp+0xC0]
00007f4e3fde190b  vmovaps xmm13, [rsp+0xD0]
00007f4e3fde1914  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde191d  add rsp, 0xF0
00007f4e3fde1924  pop r11
00007f4e3fde1926  pop r10
00007f4e3fde1928  pop r9
00007f4e3fde192a  pop r8
00007f4e3fde192c  pop rsi
00007f4e3fde192d  pop rdi
00007f4e3fde192e  pop rdx
00007f4e3fde192f  pop rcx
00007f4e3fde1930  pop rax
00007f4e3fde1931  add rsp, 0x08
00007f4e3fde1935  jmp 0x00007F4E3FDDC843
00007f4e3fde193a  sub rsp, 0x08
00007f4e3fde193e  push rax
00007f4e3fde193f  push rcx
00007f4e3fde1940  push rdx
00007f4e3fde1941  push rdi
00007f4e3fde1942  push rsi
00007f4e3fde1943  push r8
00007f4e3fde1945  push r9
00007f4e3fde1947  push r10
00007f4e3fde1949  push r11
00007f4e3fde194b  sub rsp, 0xF0
00007f4e3fde1952  vmovaps [rsp], xmm0
00007f4e3fde1957  vmovaps [rsp+0x10], xmm2
00007f4e3fde195d  vmovaps [rsp+0x20], xmm3
00007f4e3fde1963  vmovaps [rsp+0x30], xmm4
00007f4e3fde1969  vmovaps [rsp+0x40], xmm5
00007f4e3fde196f  vmovaps [rsp+0x50], xmm6
00007f4e3fde1975  vmovaps [rsp+0x60], xmm7
00007f4e3fde197b  vmovaps [rsp+0x70], xmm8
00007f4e3fde1981  vmovaps [rsp+0x80], xmm9
00007f4e3fde198a  vmovaps [rsp+0x90], xmm10
00007f4e3fde1993  vmovaps [rsp+0xA0], xmm11
00007f4e3fde199c  vmovaps [rsp+0xB0], xmm12
00007f4e3fde19a5  vmovaps [rsp+0xC0], xmm13
00007f4e3fde19ae  vmovaps [rsp+0xD0], xmm14
00007f4e3fde19b7  vmovaps [rsp+0xE0], xmm15
00007f4e3fde19c0  sub rsp, 0x30
00007f4e3fde19c4  movaps [rsp], xmm1
00007f4e3fde19c8  movaps [rsp+0x10], xmm8
00007f4e3fde19ce  movaps [rsp+0x20], xmm9
00007f4e3fde19d4  lea rdi, [rsp]
00007f4e3fde19d8  mov esi, 0x00
00007f4e3fde19dd  mov rax, 0x5D97141E9530
00007f4e3fde19e7  call rax
00007f4e3fde19e9  movaps xmm1, [rsp]
00007f4e3fde19ed  add rsp, 0x30
00007f4e3fde19f1  vmovaps xmm0, [rsp]
00007f4e3fde19f6  vmovaps xmm2, [rsp+0x10]
00007f4e3fde19fc  vmovaps xmm3, [rsp+0x20]
00007f4e3fde1a02  vmovaps xmm4, [rsp+0x30]
00007f4e3fde1a08  vmovaps xmm5, [rsp+0x40]
00007f4e3fde1a0e  vmovaps xmm6, [rsp+0x50]
00007f4e3fde1a14  vmovaps xmm7, [rsp+0x60]
00007f4e3fde1a1a  vmovaps xmm8, [rsp+0x70]
00007f4e3fde1a20  vmovaps xmm9, [rsp+0x80]
00007f4e3fde1a29  vmovaps xmm10, [rsp+0x90]
00007f4e3fde1a32  vmovaps xmm11, [rsp+0xA0]
00007f4e3fde1a3b  vmovaps xmm12, [rsp+0xB0]
00007f4e3fde1a44  vmovaps xmm13, [rsp+0xC0]
00007f4e3fde1a4d  vmovaps xmm14, [rsp+0xD0]
00007f4e3fde1a56  vmovaps xmm15, [rsp+0xE0]
00007f4e3fde1a5f  add rsp, 0xF0
00007f4e3fde1a66  pop r11
00007f4e3fde1a68  pop r10
00007f4e3fde1a6a  pop r9
00007f4e3fde1a6c  pop r8
00007f4e3fde1a6e  pop rsi
00007f4e3fde1a6f  pop rdi
00007f4e3fde1a70  pop rdx
00007f4e3fde1a71  pop rcx
00007f4e3fde1a72  pop rax
00007f4e3fde1a73  add rsp, 0x08
00007f4e3fde1a77  jmp 0x00007F4E3FDDC865
00007f4e3fde1a7c  call 0x00007F4E3FCE5940
00007f4e3fde1a81  jmp 0x00007F4E3FDDC873
00007f4e3fde1a86  call 0x00007F4E3FC0C380
00007f4e3fde1a8b  jmp 0x00007F4E3FDDC87D
00007f4e3fde1a90  call 0x00007F4E3FC0D600
00007f4e3fde1a95  jmp 0x00007F4E3FDDC887
00007f4e3fde1a9a  call 0x00007F4E3FBFF540
00007f4e3fde1a9f  jmp 0x00007F4E3FDDC891
00007f4e3fde1aa4  int3
00007f4e3fde1aa5  nop [rax+rax*1], ax
00007f4e3fde1aae  nop
00007f4e3fde1ab0  mov rax, [r15+0xF8]
00007f4e3fde1ab7  lea r14, [rax+0x140]
00007f4e3fde1abe  mov r12, [r13+r14*1]
00007f4e3fde1ac3  mov [r15+0xE8], r12
00007f4e3fde1aca  lea r14, [rax+0x130]
00007f4e3fde1ad1  mov r12, [r13+r14*1]
00007f4e3fde1ad6  lea r14, [rax+0x138]
00007f4e3fde1add  mov r11, [r13+r14*1]
00007f4e3fde1ae2  movq xmm1, r12
00007f4e3fde1ae7  movq xmm15, r11
00007f4e3fde1aec  movq xmm1, xmm1
00007f4e3fde1af0  movq xmm1, xmm1
00007f4e3fde1af4  movaps [r15+0x1A0], xmm1
00007f4e3fde1afc  movq xmm15, xmm15
00007f4e3fde1b01  movq xmm15, xmm15
00007f4e3fde1b06  movaps [r15+0x190], xmm15
00007f4e3fde1b0e  lea r14, [rax+0x120]
00007f4e3fde1b15  mov r12, [r13+r14*1]
00007f4e3fde1b1a  lea r14, [rax+0x128]
00007f4e3fde1b21  mov r11, [r13+r14*1]
00007f4e3fde1b26  movq xmm1, r12
00007f4e3fde1b2b  movq xmm15, r11
00007f4e3fde1b30  movq xmm1, xmm1
00007f4e3fde1b34  movq xmm1, xmm1
00007f4e3fde1b38  movaps [r15+0x1C0], xmm1
00007f4e3fde1b40  movq xmm15, xmm15
00007f4e3fde1b45  movq xmm15, xmm15
00007f4e3fde1b4a  movaps [r15+0x1B0], xmm15
00007f4e3fde1b52  lea r14, [rax+0x110]
00007f4e3fde1b59  mov r12, [r13+r14*1]
00007f4e3fde1b5e  lea r14, [rax+0x118]
00007f4e3fde1b65  mov r11, [r13+r14*1]
00007f4e3fde1b6a  movq xmm1, r12
00007f4e3fde1b6f  movq xmm15, r11
00007f4e3fde1b74  movq xmm1, xmm1
00007f4e3fde1b78  movq xmm1, xmm1
00007f4e3fde1b7c  movaps [r15+0x1E0], xmm1
00007f4e3fde1b84  movq xmm15, xmm15
00007f4e3fde1b89  movq xmm15, xmm15
00007f4e3fde1b8e  movaps [r15+0x1D0], xmm15
00007f4e3fde1b96  lea r14, [rax+0x100]
00007f4e3fde1b9d  mov r12, [r13+r14*1]
00007f4e3fde1ba2  lea r14, [rax+0x108]
00007f4e3fde1ba9  mov r11, [r13+r14*1]
00007f4e3fde1bae  movq xmm1, r12
00007f4e3fde1bb3  movq xmm15, r11
00007f4e3fde1bb8  movq xmm1, xmm1
00007f4e3fde1bbc  movq xmm1, xmm1
00007f4e3fde1bc0  movaps [r15+0x200], xmm1
00007f4e3fde1bc8  movq xmm15, xmm15
00007f4e3fde1bcd  movq xmm15, xmm15
00007f4e3fde1bd2  movaps [r15+0x1F0], xmm15
00007f4e3fde1bda  mov qword ptr [r15+0x40], 0x430000
00007f4e3fde1be2  mov r14d, 0x430510
00007f4e3fde1be8  mov r12, [r13+r14*1]
00007f4e3fde1bed  movq xmm1, r12
00007f4e3fde1bf2  lea r14, [rax+0x150]
00007f4e3fde1bf9  mov [r15+0xF8], r14
00007f4e3fde1c00  mov rax, [r15+0x50]
00007f4e3fde1c04  movups xmm15, [r13+rax*1]
00007f4e3fde1c0a  movaps [r15+0x120], xmm15
00007f4e3fde1c12  mov qword ptr [r15+0x48], 0x10
00007f4e3fde1c1a  xor eax, eax
00007f4e3fde1c1c  mov r14d, 0x10
00007f4e3fde1c22  mov r12d, 0x200
00007f4e3fde1c28  cmp r14, r12
00007f4e3fde1c2b  cmc
00007f4e3fde1c2c  lahf
00007f4e3fde1c2d  seto al
00007f4e3fde1c30  mov [r15+0x108], eax
00007f4e3fde1c37  pextrq rax, xmm15, 0x01
00007f4e3fde1c3e  movq xmm14, rax
00007f4e3fde1c43  movaps [r15+0x130], xmm14
00007f4e3fde1c4b  movq rax, xmm1
00007f4e3fde1c50  movq r14, xmm15
00007f4e3fde1c55  vmovq xmm1, rax
00007f4e3fde1c5a  vmovq xmm15, r14
00007f4e3fde1c5f  movaps xmm13, xmm1
00007f4e3fde1c63  addsd xmm13, xmm15
00007f4e3fde1c68  ucomisd xmm13, xmm13
00007f4e3fde1c6d  jp 0x00007F4E3FDE1D86
00007f4e3fde1c73  movq xmm13, xmm13
00007f4e3fde1c78  movq rax, xmm13
00007f4e3fde1c7d  movq r14, xmm14
00007f4e3fde1c82  vmovq xmm1, rax
00007f4e3fde1c87  vmovq xmm15, r14
00007f4e3fde1c8c  movaps xmm14, xmm1
00007f4e3fde1c90  addsd xmm14, xmm15
00007f4e3fde1c95  ucomisd xmm14, xmm14
00007f4e3fde1c9a  jp 0x00007F4E3FDE1DCE
00007f4e3fde1ca0  movq xmm14, xmm14
00007f4e3fde1ca5  movaps [r15+0x110], xmm14
00007f4e3fde1cad  mov eax, [r15+0x108]
00007f4e3fde1cb4  sahf
00007f4e3fde1cb5  jnz 0x00007F4E3FDE1CE7
00007f4e3fde1cb7  cmp dword ptr [r15+0x318], 0x00
00007f4e3fde1cbf  jz 0x00007F4E3FDE1FE0
00007f4e3fde1cc5  nop [rax+rax*1], ax
00007f4e3fde1cce  nop [rax+rax*1], eax
00007f4e3fde1cd6  mov eax, 0x410490
00007f4e3fde1cdb  mov [r15+0x100], rax
00007f4e3fde1ce2  jmp 0x00007F4E3FBFE110
00007f4e3fde1ce7  cmp dword ptr [r15+0x318], 0x00
00007f4e3fde1cef  jz 0x00007F4E3FDE1E20
00007f4e3fde1cf5  nop [rax+rax*1], ax
00007f4e3fde1cfe  nop [rax+rax*1], eax
00007f4e3fde1d06  mov eax, 0x410474
00007f4e3fde1d0b  mov [r15+0x100], rax
00007f4e3fde1d12  jmp 0x00007F4E3FBFE110
00007f4e3fde1d17  int3
00007f4e3fde1d18  call 0x00007F4E3FCE27E0
00007f4e3fde1d1d  jmp 0x00007F4E3FDE1AC3
00007f4e3fde1d22  call 0x00007F4E3FCE27E0
00007f4e3fde1d27  jmp 0x00007F4E3FDE1AD6
00007f4e3fde1d2c  call 0x00007F4E3FCE1570
00007f4e3fde1d31  jmp 0x00007F4E3FDE1AE2
00007f4e3fde1d36  call 0x00007F4E3FCE27E0
00007f4e3fde1d3b  jmp 0x00007F4E3FDE1B1A
00007f4e3fde1d40  call 0x00007F4E3FCE1570
00007f4e3fde1d45  jmp 0x00007F4E3FDE1B26
00007f4e3fde1d4a  call 0x00007F4E3FCE27E0
00007f4e3fde1d4f  jmp 0x00007F4E3FDE1B5E
00007f4e3fde1d54  call 0x00007F4E3FCE1570
00007f4e3fde1d59  jmp 0x00007F4E3FDE1B6A
00007f4e3fde1d5e  call 0x00007F4E3FCE27E0
00007f4e3fde1d63  jmp 0x00007F4E3FDE1BA2
00007f4e3fde1d68  call 0x00007F4E3FCE1570
00007f4e3fde1d6d  jmp 0x00007F4E3FDE1BAE
00007f4e3fde1d72  call 0x00007F4E3FCE27E0
00007f4e3fde1d77  jmp 0x00007F4E3FDE1BED
00007f4e3fde1d7c  call 0x00007F4E3FC0E760
00007f4e3fde1d81  jmp 0x00007F4E3FDE1C0A
00007f4e3fde1d86  ucomisd xmm1, xmm15
00007f4e3fde1d8b  jp 0x00007F4E3FDE1D9A
00007f4e3fde1d8d  movaps xmm13, [0x00007F4E3F9FE060]
00007f4e3fde1d95  jmp 0x00007F4E3FDE1C73
00007f4e3fde1d9a  vxorps xmm0, xmm1, xmm15
00007f4e3fde1d9f  pextrw eax, xmm0, 0x03
00007f4e3fde1da4  and eax, 0x7FF8
00007f4e3fde1da9  cmp eax, 0x08
00007f4e3fde1dac  jnz 0x00007F4E3FDE1C73
00007f4e3fde1db2  movq rax, xmm15
00007f4e3fde1db7  shl rax, 0x0D
00007f4e3fde1dbb  jbe 0x00007F4E3FDE1C73
00007f4e3fde1dc1  vorps xmm13, xmm15, [0x00007F4E3F9FE070]
00007f4e3fde1dc9  jmp 0x00007F4E3FDE1C73
00007f4e3fde1dce  ucomisd xmm1, xmm15
00007f4e3fde1dd3  jp 0x00007F4E3FDE1DE2
00007f4e3fde1dd5  movaps xmm14, [0x00007F4E3F9FE060]
00007f4e3fde1ddd  jmp 0x00007F4E3FDE1CA0
00007f4e3fde1de2  vxorps xmm0, xmm1, xmm15
00007f4e3fde1de7  pextrw eax, xmm0, 0x03
00007f4e3fde1dec  and eax, 0x7FF8
00007f4e3fde1df1  cmp eax, 0x08
00007f4e3fde1df4  jnz 0x00007F4E3FDE1CA0
00007f4e3fde1dfa  movq rax, xmm15
00007f4e3fde1dff  shl rax, 0x0D
00007f4e3fde1e03  jbe 0x00007F4E3FDE1CA0
00007f4e3fde1e09  vorps xmm14, xmm15, [0x00007F4E3F9FE070]
00007f4e3fde1e11  jmp 0x00007F4E3FDE1CA0
00007f4e3fde1e16  int3
00007f4e3fde1e17  nop [rax+rax*1], ax
00007f4e3fde1e20  mov rax, [r15+0x48]
00007f4e3fde1e24  mov r14, [r15+0x50]
00007f4e3fde1e28  lea r12, [r14+rax*1]
00007f4e3fde1e2c  movups xmm1, [r13+r12*1]
00007f4e3fde1e32  movaps [r15+0x120], xmm1
00007f4e3fde1e3a  lea r14, [rax+0x10]
00007f4e3fde1e3e  mov [r15+0x48], r14
00007f4e3fde1e42  xor eax, eax
00007f4e3fde1e44  mov r12d, 0x200
00007f4e3fde1e4a  cmp r14, r12
00007f4e3fde1e4d  cmc
00007f4e3fde1e4e  lahf
00007f4e3fde1e4f  seto al
00007f4e3fde1e52  mov [r15+0x108], eax
00007f4e3fde1e59  pextrq rax, xmm1, 0x01
00007f4e3fde1e60  movq xmm15, rax
00007f4e3fde1e65  movaps [r15+0x130], xmm15
00007f4e3fde1e6d  movaps xmm14, [r15+0x110]
00007f4e3fde1e75  movq rax, xmm14
00007f4e3fde1e7a  movq r14, xmm1
00007f4e3fde1e7f  vmovq xmm1, rax
00007f4e3fde1e84  vmovq xmm14, r14
00007f4e3fde1e89  movaps xmm13, xmm1
00007f4e3fde1e8d  addsd xmm13, xmm14
00007f4e3fde1e92  ucomisd xmm13, xmm13
00007f4e3fde1e97  jp 0x00007F4E3FDE1F4C
00007f4e3fde1e9d  movq xmm13, xmm13
00007f4e3fde1ea2  movq rax, xmm13
00007f4e3fde1ea7  movq r14, xmm15
00007f4e3fde1eac  vmovq xmm1, rax
00007f4e3fde1eb1  vmovq xmm15, r14
00007f4e3fde1eb6  movaps xmm14, xmm1
00007f4e3fde1eba  addsd xmm14, xmm15
00007f4e3fde1ebf  ucomisd xmm14, xmm14
00007f4e3fde1ec4  jp 0x00007F4E3FDE1F94
00007f4e3fde1eca  movq xmm14, xmm14
00007f4e3fde1ecf  movaps [r15+0x110], xmm14
00007f4e3fde1ed7  mov eax, [r15+0x108]
00007f4e3fde1ede  sahf
00007f4e3fde1edf  jnz 0x00007F4E3FDE1F11
00007f4e3fde1ee1  cmp dword ptr [r15+0x318], 0x00
00007f4e3fde1ee9  jz 0x00007F4E3FDE1FE0
00007f4e3fde1eef  nop [rax+rax*1], ax
00007f4e3fde1ef8  nop [rax+rax*1], eax
00007f4e3fde1f00  mov eax, 0x410490
00007f4e3fde1f05  mov [r15+0x100], rax
00007f4e3fde1f0c  jmp 0x00007F4E3FBFE110
00007f4e3fde1f11  cmp dword ptr [r15+0x318], 0x00
00007f4e3fde1f19  jz 0x00007F4E3FDE1E20
00007f4e3fde1f1f  nop [rax+rax*1], ax
00007f4e3fde1f28  nop [rax+rax*1], eax
00007f4e3fde1f30  mov eax, 0x410474
00007f4e3fde1f35  mov [r15+0x100], rax
00007f4e3fde1f3c  jmp 0x00007F4E3FBFE110
00007f4e3fde1f41  int3
00007f4e3fde1f42  call 0x00007F4E3FCB52F0
00007f4e3fde1f47  jmp 0x00007F4E3FDE1E32
00007f4e3fde1f4c  ucomisd xmm1, xmm14
00007f4e3fde1f51  jp 0x00007F4E3FDE1F60
00007f4e3fde1f53  movaps xmm13, [0x00007F4E3F9FE060]
00007f4e3fde1f5b  jmp 0x00007F4E3FDE1E9D
00007f4e3fde1f60  vxorps xmm0, xmm1, xmm14
00007f4e3fde1f65  pextrw eax, xmm0, 0x03
00007f4e3fde1f6a  and eax, 0x7FF8
00007f4e3fde1f6f  cmp eax, 0x08
00007f4e3fde1f72  jnz 0x00007F4E3FDE1E9D
00007f4e3fde1f78  movq rax, xmm14
00007f4e3fde1f7d  shl rax, 0x0D
00007f4e3fde1f81  jbe 0x00007F4E3FDE1E9D
00007f4e3fde1f87  vorps xmm13, xmm14, [0x00007F4E3F9FE070]
00007f4e3fde1f8f  jmp 0x00007F4E3FDE1E9D
00007f4e3fde1f94  ucomisd xmm1, xmm15
00007f4e3fde1f99  jp 0x00007F4E3FDE1FA8
00007f4e3fde1f9b  movaps xmm14, [0x00007F4E3F9FE060]
00007f4e3fde1fa3  jmp 0x00007F4E3FDE1ECA
00007f4e3fde1fa8  vxorps xmm0, xmm1, xmm15
00007f4e3fde1fad  pextrw eax, xmm0, 0x03
00007f4e3fde1fb2  and eax, 0x7FF8
00007f4e3fde1fb7  cmp eax, 0x08
00007f4e3fde1fba  jnz 0x00007F4E3FDE1ECA
00007f4e3fde1fc0  movq rax, xmm15
00007f4e3fde1fc5  shl rax, 0x0D
00007f4e3fde1fc9  jbe 0x00007F4E3FDE1ECA
00007f4e3fde1fcf  vorps xmm14, xmm15, [0x00007F4E3F9FE070]
00007f4e3fde1fd7  jmp 0x00007F4E3FDE1ECA
00007f4e3fde1fdc  int3
00007f4e3fde1fdd  nop [rax], eax
00007f4e3fde1fe0  mov rax, [r15+0x40]
00007f4e3fde1fe4  lea r14, [rax+0x510]
00007f4e3fde1feb  movaps xmm1, [r15+0x110]
00007f4e3fde1ff3  movq rax, xmm1
00007f4e3fde1ff8  mov [r13+r14*1], rax
00007f4e3fde1ffd  mov rax, [r15+0xF0]
00007f4e3fde2004  mov [r15+0x100], rax
00007f4e3fde200b  jmp 0x00007F4E3FDCE5C0
00007f4e3fde2010  int3
00007f4e3fde2011  call 0x00007F4E3FCD5EB0
00007f4e3fde2016  jmp 0x00007F4E3FDE1FFD
00007f4e3fde201b  int3
00007f4e3fde201c  nop [rax], eax
00007f4e3fde2020  mov qword ptr [r15+0x100], 0x04
00007f4e3fde202b  mov esi, 0x00
00007f4e3fde2030  mov edx, 0x09
00007f4e3fde2035  mov rdi, 0x7FFDD8848DE0
00007f4e3fde203f  mov rax, 0x5D971407C970
00007f4e3fde2049  call rax
00007f4e3fde204b  cmp dword ptr [r15+0x318], 0x00
00007f4e3fde2053  jnz 0x00007F4E3FBFE110
00007f4e3fde2059  jmp 0x00007F4E3FBFE0A0
00007f4e3fde205e  int3
00007f4e3fde205f  int3
