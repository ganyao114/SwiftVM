000071c0d83ce69b  nop [rax+rax*1], eax
000071c0d83ce6a0  vmovaps xmm1, [0x000071C0D7FFE010]
000071c0d83ce6a8  movq xmm1, xmm1
000071c0d83ce6ac  movaps [r15+0x110], xmm1
000071c0d83ce6b4  vmovaps xmm1, [0x000071C0D7FFE020]
000071c0d83ce6bc  movq xmm1, xmm1
000071c0d83ce6c0  movaps [r15+0x120], xmm1
000071c0d83ce6c8  mov eax, 0x4204C0
000071c0d83ce6cd  mov r14, [r13+rax*1]
000071c0d83ce6d2  movq xmm1, r14
000071c0d83ce6d7  movaps [r15+0x130], xmm1
000071c0d83ce6df  vmovaps xmm1, [0x000071C0D7FFE030]
000071c0d83ce6e7  vpbroadcastq xmm1, xmm1
000071c0d83ce6ec  movaps [r15+0x140], xmm1
000071c0d83ce6f4  mov qword ptr [r15+0x40], 0x02
000071c0d83ce6fc  vmovaps xmm15, [0x000071C0D7FFE040]
000071c0d83ce704  movq xmm15, xmm15
000071c0d83ce709  movaps [r15+0x150], xmm15
000071c0d83ce711  mov qword ptr [r15+0x58], 0x420000
000071c0d83ce719  vmovaps xmm15, [0x000071C0D7FFE050]
000071c0d83ce721  vpbroadcastq xmm15, xmm15
000071c0d83ce726  movaps [r15+0x160], xmm15
000071c0d83ce72e  mov rax, [r15+0x40]
000071c0d83ce732  vmovq xmm14, rax
000071c0d83ce737  vpbroadcastq xmm14, xmm14
000071c0d83ce73c  movaps [r15+0x170], xmm14
000071c0d83ce744  mov eax, 0x4204D0
000071c0d83ce749  movups xmm13, [r13+rax*1]
000071c0d83ce74f  mov qword ptr [r15+0x40], 0x430518
000071c0d83ce757  mov qword ptr [r15+0x50], 0x430720
000071c0d83ce75f  vpmovqd xmm12, xmm13
000071c0d83ce765  pxor xmm11, xmm11
000071c0d83ce76a  punpcklqdq xmm12, xmm11
000071c0d83ce76f  movaps [r15+0x210], xmm12
000071c0d83ce777  movq xmm12, qword ptr [r15+0x120]
000071c0d83ce780  movq xmm11, qword ptr [r15+0x130]
000071c0d83ce789  psubd xmm12, xmm11
000071c0d83ce78e  movq xmm12, xmm12
000071c0d83ce793  paddq xmm13, xmm14
000071c0d83ce798  movaps [r15+0x180], xmm13
000071c0d83ce7a0  movq xmm14, qword ptr [r15+0x150]
000071c0d83ce7a9  paddd xmm11, xmm14
000071c0d83ce7ae  movq xmm11, xmm11
000071c0d83ce7b3  movq xmm11, xmm11
000071c0d83ce7b8  movaps [r15+0x130], xmm11
000071c0d83ce7c0  pmovzxdq xmm12, xmm12
000071c0d83ce7c6  psllq xmm12, 0x00
000071c0d83ce7cc  movq xmm14, qword ptr [r15+0x210]
000071c0d83ce7d5  movq xmm13, qword ptr [r15+0x110]
000071c0d83ce7de  paddd xmm14, xmm13
000071c0d83ce7e3  movq xmm14, xmm14
000071c0d83ce7e8  vcvtuqq2pd xmm12, xmm12
000071c0d83ce7ee  pmovzxdq xmm14, xmm14
000071c0d83ce7f4  psllq xmm14, 0x00
000071c0d83ce7fa  vcvtuqq2pd xmm14, xmm14
000071c0d83ce800  movaps xmm13, xmm12
000071c0d83ce804  mulpd xmm13, xmm1
000071c0d83ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000071c0d83ce80f  ptest xmm11, xmm11
000071c0d83ce815  jnz 0x000071C0D83CE8FF
000071c0d83ce81b  movaps [r15+0x220], xmm13
000071c0d83ce823  mov eax, 0x430720
000071c0d83ce828  movups [r13+rax*1], xmm13
000071c0d83ce82e  movaps xmm1, xmm14
000071c0d83ce832  mulpd xmm1, xmm15
000071c0d83ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000071c0d83ce83c  ptest xmm13, xmm13
000071c0d83ce842  jnz 0x000071C0D83CEA4C
000071c0d83ce848  movaps [r15+0x210], xmm1
000071c0d83ce850  mov eax, 0x430518
000071c0d83ce855  movups [r13+rax*1], xmm1
000071c0d83ce85b  mov qword ptr [r15+0x48], 0x10
000071c0d83ce863  xor eax, eax
000071c0d83ce865  mov r14d, 0x10
000071c0d83ce86b  mov r12d, 0x200
000071c0d83ce871  cmp r14, r12
000071c0d83ce874  cmc
000071c0d83ce875  lahf
000071c0d83ce876  seto al
000071c0d83ce879  mov [r15+0x108], eax
000071c0d83ce880  mov eax, [r15+0x108]
000071c0d83ce887  sahf
000071c0d83ce888  jnz 0x000071C0D83CE8BA
000071c0d83ce88a  cmp dword ptr [r15+0x318], 0x00
000071c0d83ce892  jz 0x000071C0D83CEFF0
000071c0d83ce898  nop [rax+rax*1], ax
000071c0d83ce8a1  nop [rax+rax*1], eax
000071c0d83ce8a9  mov eax, 0x4101EC
000071c0d83ce8ae  mov [r15+0x100], rax
000071c0d83ce8b5  jmp 0x000071C0D81FE110
000071c0d83ce8ba  cmp dword ptr [r15+0x318], 0x00
000071c0d83ce8c2  jz 0x000071C0D83CEBA0
000071c0d83ce8c8  nop [rax+rax*1], ax
000071c0d83ce8d1  nop [rax+rax*1], eax
000071c0d83ce8d9  mov eax, 0x4101AC
000071c0d83ce8de  mov [r15+0x100], rax
000071c0d83ce8e5  jmp 0x000071C0D81FE110
000071c0d83ce8ea  int3
000071c0d83ce8eb  call 0x000071C0D820DC20
000071c0d83ce8f0  jmp 0x000071C0D83CE6D2
000071c0d83ce8f5  call 0x000071C0D820C260
000071c0d83ce8fa  jmp 0x000071C0D83CE74F
000071c0d83ce8ff  sub rsp, 0x08
000071c0d83ce903  push rax
000071c0d83ce904  push rcx
000071c0d83ce905  push rdx
000071c0d83ce906  push rdi
000071c0d83ce907  push rsi
000071c0d83ce908  push r8
000071c0d83ce90a  push r9
000071c0d83ce90c  push r10
000071c0d83ce90e  push r11
000071c0d83ce910  sub rsp, 0xF0
000071c0d83ce917  vmovaps [rsp], xmm0
000071c0d83ce91c  vmovaps [rsp+0x10], xmm1
000071c0d83ce922  vmovaps [rsp+0x20], xmm2
000071c0d83ce928  vmovaps [rsp+0x30], xmm3
000071c0d83ce92e  vmovaps [rsp+0x40], xmm4
000071c0d83ce934  vmovaps [rsp+0x50], xmm5
000071c0d83ce93a  vmovaps [rsp+0x60], xmm6
000071c0d83ce940  vmovaps [rsp+0x70], xmm7
000071c0d83ce946  vmovaps [rsp+0x80], xmm8
000071c0d83ce94f  vmovaps [rsp+0x90], xmm9
000071c0d83ce958  vmovaps [rsp+0xA0], xmm10
000071c0d83ce961  vmovaps [rsp+0xB0], xmm11
000071c0d83ce96a  vmovaps [rsp+0xC0], xmm12
000071c0d83ce973  vmovaps [rsp+0xD0], xmm14
000071c0d83ce97c  vmovaps [rsp+0xE0], xmm15
000071c0d83ce985  sub rsp, 0x30
000071c0d83ce989  movaps [rsp], xmm13
000071c0d83ce98e  movaps [rsp+0x10], xmm12
000071c0d83ce994  movaps [rsp+0x20], xmm1
000071c0d83ce999  lea rdi, [rsp]
000071c0d83ce99d  mov esi, 0x00
000071c0d83ce9a2  mov rax, 0x5904ED15D530
000071c0d83ce9ac  call rax
000071c0d83ce9ae  movaps xmm13, [rsp]
000071c0d83ce9b3  add rsp, 0x30
000071c0d83ce9b7  vmovaps xmm0, [rsp]
000071c0d83ce9bc  vmovaps xmm1, [rsp+0x10]
000071c0d83ce9c2  vmovaps xmm2, [rsp+0x20]
000071c0d83ce9c8  vmovaps xmm3, [rsp+0x30]
000071c0d83ce9ce  vmovaps xmm4, [rsp+0x40]
000071c0d83ce9d4  vmovaps xmm5, [rsp+0x50]
000071c0d83ce9da  vmovaps xmm6, [rsp+0x60]
000071c0d83ce9e0  vmovaps xmm7, [rsp+0x70]
000071c0d83ce9e6  vmovaps xmm8, [rsp+0x80]
000071c0d83ce9ef  vmovaps xmm9, [rsp+0x90]
000071c0d83ce9f8  vmovaps xmm10, [rsp+0xA0]
000071c0d83cea01  vmovaps xmm11, [rsp+0xB0]
000071c0d83cea0a  vmovaps xmm12, [rsp+0xC0]
000071c0d83cea13  vmovaps xmm14, [rsp+0xD0]
000071c0d83cea1c  vmovaps xmm15, [rsp+0xE0]
000071c0d83cea25  add rsp, 0xF0
000071c0d83cea2c  pop r11
000071c0d83cea2e  pop r10
000071c0d83cea30  pop r9
000071c0d83cea32  pop r8
000071c0d83cea34  pop rsi
000071c0d83cea35  pop rdi
000071c0d83cea36  pop rdx
000071c0d83cea37  pop rcx
000071c0d83cea38  pop rax
000071c0d83cea39  add rsp, 0x08
000071c0d83cea3d  jmp 0x000071C0D83CE81B
000071c0d83cea42  call 0x000071C0D820C380
000071c0d83cea47  jmp 0x000071C0D83CE82E
000071c0d83cea4c  sub rsp, 0x08
000071c0d83cea50  push rax
000071c0d83cea51  push rcx
000071c0d83cea52  push rdx
000071c0d83cea53  push rdi
000071c0d83cea54  push rsi
000071c0d83cea55  push r8
000071c0d83cea57  push r9
000071c0d83cea59  push r10
000071c0d83cea5b  push r11
000071c0d83cea5d  sub rsp, 0xF0
000071c0d83cea64  vmovaps [rsp], xmm0
000071c0d83cea69  vmovaps [rsp+0x10], xmm2
000071c0d83cea6f  vmovaps [rsp+0x20], xmm3
000071c0d83cea75  vmovaps [rsp+0x30], xmm4
000071c0d83cea7b  vmovaps [rsp+0x40], xmm5
000071c0d83cea81  vmovaps [rsp+0x50], xmm6
000071c0d83cea87  vmovaps [rsp+0x60], xmm7
000071c0d83cea8d  vmovaps [rsp+0x70], xmm8
000071c0d83cea93  vmovaps [rsp+0x80], xmm9
000071c0d83cea9c  vmovaps [rsp+0x90], xmm10
000071c0d83ceaa5  vmovaps [rsp+0xA0], xmm11
000071c0d83ceaae  vmovaps [rsp+0xB0], xmm12
000071c0d83ceab7  vmovaps [rsp+0xC0], xmm13
000071c0d83ceac0  vmovaps [rsp+0xD0], xmm14
000071c0d83ceac9  vmovaps [rsp+0xE0], xmm15
000071c0d83cead2  sub rsp, 0x30
000071c0d83cead6  movaps [rsp], xmm1
000071c0d83ceada  movaps [rsp+0x10], xmm14
000071c0d83ceae0  movaps [rsp+0x20], xmm15
000071c0d83ceae6  lea rdi, [rsp]
000071c0d83ceaea  mov esi, 0x00
000071c0d83ceaef  mov rax, 0x5904ED15D530
000071c0d83ceaf9  call rax
000071c0d83ceafb  movaps xmm1, [rsp]
000071c0d83ceaff  add rsp, 0x30
000071c0d83ceb03  vmovaps xmm0, [rsp]
000071c0d83ceb08  vmovaps xmm2, [rsp+0x10]
000071c0d83ceb0e  vmovaps xmm3, [rsp+0x20]
000071c0d83ceb14  vmovaps xmm4, [rsp+0x30]
000071c0d83ceb1a  vmovaps xmm5, [rsp+0x40]
000071c0d83ceb20  vmovaps xmm6, [rsp+0x50]
000071c0d83ceb26  vmovaps xmm7, [rsp+0x60]
000071c0d83ceb2c  vmovaps xmm8, [rsp+0x70]
000071c0d83ceb32  vmovaps xmm9, [rsp+0x80]
000071c0d83ceb3b  vmovaps xmm10, [rsp+0x90]
000071c0d83ceb44  vmovaps xmm11, [rsp+0xA0]
000071c0d83ceb4d  vmovaps xmm12, [rsp+0xB0]
000071c0d83ceb56  vmovaps xmm13, [rsp+0xC0]
000071c0d83ceb5f  vmovaps xmm14, [rsp+0xD0]
000071c0d83ceb68  vmovaps xmm15, [rsp+0xE0]
000071c0d83ceb71  add rsp, 0xF0
000071c0d83ceb78  pop r11
000071c0d83ceb7a  pop r10
000071c0d83ceb7c  pop r9
000071c0d83ceb7e  pop r8
000071c0d83ceb80  pop rsi
000071c0d83ceb81  pop rdi
000071c0d83ceb82  pop rdx
000071c0d83ceb83  pop rcx
000071c0d83ceb84  pop rax
000071c0d83ceb85  add rsp, 0x08
000071c0d83ceb89  jmp 0x000071C0D83CE848
000071c0d83ceb8e  call 0x000071C0D81FF540
000071c0d83ceb93  jmp 0x000071C0D83CE85B
000071c0d83ceb98  int3
000071c0d83ceb99  nop [rax], eax
000071c0d83ceba0  movaps xmm1, [r15+0x180]
000071c0d83ceba8  vpmovqd xmm15, xmm1
000071c0d83cebae  pxor xmm14, xmm14
000071c0d83cebb3  punpcklqdq xmm15, xmm14
000071c0d83cebb8  movaps [r15+0x210], xmm15
000071c0d83cebc0  movq xmm15, qword ptr [r15+0x120]
000071c0d83cebc9  movq xmm14, qword ptr [r15+0x130]
000071c0d83cebd2  psubd xmm15, xmm14
000071c0d83cebd7  movq xmm15, xmm15
000071c0d83cebdc  movaps xmm13, [r15+0x170]
000071c0d83cebe4  paddq xmm1, xmm13
000071c0d83cebe9  movaps [r15+0x180], xmm1
000071c0d83cebf1  movq xmm1, qword ptr [r15+0x150]
000071c0d83cebfa  paddd xmm14, xmm1
000071c0d83cebff  movq xmm14, xmm14
000071c0d83cec04  movq xmm14, xmm14
000071c0d83cec09  movaps [r15+0x130], xmm14
000071c0d83cec11  pmovzxdq xmm15, xmm15
000071c0d83cec17  psllq xmm15, 0x00
000071c0d83cec1d  movq xmm1, qword ptr [r15+0x210]
000071c0d83cec26  movq xmm14, qword ptr [r15+0x110]
000071c0d83cec2f  paddd xmm1, xmm14
000071c0d83cec34  movq xmm1, xmm1
000071c0d83cec38  vcvtuqq2pd xmm15, xmm15
000071c0d83cec3e  pmovzxdq xmm1, xmm1
000071c0d83cec43  psllq xmm1, 0x00
000071c0d83cec48  vcvtuqq2pd xmm1, xmm1
000071c0d83cec4e  movaps xmm14, [r15+0x140]
000071c0d83cec56  movaps xmm13, xmm15
000071c0d83cec5a  mulpd xmm13, xmm14
000071c0d83cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000071c0d83cec65  ptest xmm12, xmm12
000071c0d83cec6b  jnz 0x000071C0D83CED4E
000071c0d83cec71  movaps [r15+0x220], xmm13
000071c0d83cec79  mov rax, [r15+0x48]
000071c0d83cec7d  mov r14, [r15+0x50]
000071c0d83cec81  lea r12, [r14+rax*1]
000071c0d83cec85  movups [r13+r12*1], xmm13
000071c0d83cec8b  movaps xmm15, [r15+0x160]
000071c0d83cec93  movaps xmm14, xmm1
000071c0d83cec97  mulpd xmm14, xmm15
000071c0d83cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000071c0d83ceca2  ptest xmm13, xmm13
000071c0d83ceca8  jnz 0x000071C0D83CEE9C
000071c0d83cecae  movaps [r15+0x210], xmm14
000071c0d83cecb6  mov r14, [r15+0x40]
000071c0d83cecba  lea r12, [r14+rax*1]
000071c0d83cecbe  movups [r13+r12*1], xmm14
000071c0d83cecc4  lea r14, [rax+0x10]
000071c0d83cecc8  mov [r15+0x48], r14
000071c0d83ceccc  xor eax, eax
000071c0d83cecce  mov r12d, 0x200
000071c0d83cecd4  cmp r14, r12
000071c0d83cecd7  cmc
000071c0d83cecd8  lahf
000071c0d83cecd9  seto al
000071c0d83cecdc  mov [r15+0x108], eax
000071c0d83cece3  mov eax, [r15+0x108]
000071c0d83cecea  sahf
000071c0d83ceceb  jnz 0x000071C0D83CED1D
000071c0d83ceced  cmp dword ptr [r15+0x318], 0x00
000071c0d83cecf5  jz 0x000071C0D83CEFF0
000071c0d83cecfb  nop [rax+rax*1], ax
000071c0d83ced04  nop [rax+rax*1], eax
000071c0d83ced0c  mov eax, 0x4101EC
000071c0d83ced11  mov [r15+0x100], rax
000071c0d83ced18  jmp 0x000071C0D81FE110
000071c0d83ced1d  cmp dword ptr [r15+0x318], 0x00
000071c0d83ced25  jz 0x000071C0D83CEBA0
000071c0d83ced2b  nop [rax+rax*1], ax
000071c0d83ced34  nop [rax+rax*1], eax
000071c0d83ced3c  mov eax, 0x4101AC
000071c0d83ced41  mov [r15+0x100], rax
000071c0d83ced48  jmp 0x000071C0D81FE110
000071c0d83ced4d  int3
000071c0d83ced4e  sub rsp, 0x08
000071c0d83ced52  push rax
000071c0d83ced53  push rcx
000071c0d83ced54  push rdx
000071c0d83ced55  push rdi
000071c0d83ced56  push rsi
000071c0d83ced57  push r8
000071c0d83ced59  push r9
000071c0d83ced5b  push r10
000071c0d83ced5d  push r11
000071c0d83ced5f  sub rsp, 0xF0
000071c0d83ced66  vmovaps [rsp], xmm0
000071c0d83ced6b  vmovaps [rsp+0x10], xmm1
000071c0d83ced71  vmovaps [rsp+0x20], xmm2
000071c0d83ced77  vmovaps [rsp+0x30], xmm3
000071c0d83ced7d  vmovaps [rsp+0x40], xmm4
000071c0d83ced83  vmovaps [rsp+0x50], xmm5
000071c0d83ced89  vmovaps [rsp+0x60], xmm6
000071c0d83ced8f  vmovaps [rsp+0x70], xmm7
000071c0d83ced95  vmovaps [rsp+0x80], xmm8
000071c0d83ced9e  vmovaps [rsp+0x90], xmm9
000071c0d83ceda7  vmovaps [rsp+0xA0], xmm10
000071c0d83cedb0  vmovaps [rsp+0xB0], xmm11
000071c0d83cedb9  vmovaps [rsp+0xC0], xmm12
000071c0d83cedc2  vmovaps [rsp+0xD0], xmm14
000071c0d83cedcb  vmovaps [rsp+0xE0], xmm15
000071c0d83cedd4  sub rsp, 0x30
000071c0d83cedd8  movaps [rsp], xmm13
000071c0d83ceddd  movaps [rsp+0x10], xmm15
000071c0d83cede3  movaps [rsp+0x20], xmm14
000071c0d83cede9  lea rdi, [rsp]
000071c0d83ceded  mov esi, 0x00
000071c0d83cedf2  mov rax, 0x5904ED15D530
000071c0d83cedfc  call rax
000071c0d83cedfe  movaps xmm13, [rsp]
000071c0d83cee03  add rsp, 0x30
000071c0d83cee07  vmovaps xmm0, [rsp]
000071c0d83cee0c  vmovaps xmm1, [rsp+0x10]
000071c0d83cee12  vmovaps xmm2, [rsp+0x20]
000071c0d83cee18  vmovaps xmm3, [rsp+0x30]
000071c0d83cee1e  vmovaps xmm4, [rsp+0x40]
000071c0d83cee24  vmovaps xmm5, [rsp+0x50]
000071c0d83cee2a  vmovaps xmm6, [rsp+0x60]
000071c0d83cee30  vmovaps xmm7, [rsp+0x70]
000071c0d83cee36  vmovaps xmm8, [rsp+0x80]
000071c0d83cee3f  vmovaps xmm9, [rsp+0x90]
000071c0d83cee48  vmovaps xmm10, [rsp+0xA0]
000071c0d83cee51  vmovaps xmm11, [rsp+0xB0]
000071c0d83cee5a  vmovaps xmm12, [rsp+0xC0]
000071c0d83cee63  vmovaps xmm14, [rsp+0xD0]
000071c0d83cee6c  vmovaps xmm15, [rsp+0xE0]
000071c0d83cee75  add rsp, 0xF0
000071c0d83cee7c  pop r11
000071c0d83cee7e  pop r10
000071c0d83cee80  pop r9
000071c0d83cee82  pop r8
000071c0d83cee84  pop rsi
000071c0d83cee85  pop rdi
000071c0d83cee86  pop rdx
000071c0d83cee87  pop rcx
000071c0d83cee88  pop rax
000071c0d83cee89  add rsp, 0x08
000071c0d83cee8d  jmp 0x000071C0D83CEC71
000071c0d83cee92  call 0x000071C0D82C2240
000071c0d83cee97  jmp 0x000071C0D83CEC8B
000071c0d83cee9c  sub rsp, 0x08
000071c0d83ceea0  push rax
000071c0d83ceea1  push rcx
000071c0d83ceea2  push rdx
000071c0d83ceea3  push rdi
000071c0d83ceea4  push rsi
000071c0d83ceea5  push r8
000071c0d83ceea7  push r9
000071c0d83ceea9  push r10
000071c0d83ceeab  push r11
000071c0d83ceead  sub rsp, 0xF0
000071c0d83ceeb4  vmovaps [rsp], xmm0
000071c0d83ceeb9  vmovaps [rsp+0x10], xmm1
000071c0d83ceebf  vmovaps [rsp+0x20], xmm2
000071c0d83ceec5  vmovaps [rsp+0x30], xmm3
000071c0d83ceecb  vmovaps [rsp+0x40], xmm4
000071c0d83ceed1  vmovaps [rsp+0x50], xmm5
000071c0d83ceed7  vmovaps [rsp+0x60], xmm6
000071c0d83ceedd  vmovaps [rsp+0x70], xmm7
000071c0d83ceee3  vmovaps [rsp+0x80], xmm8
000071c0d83ceeec  vmovaps [rsp+0x90], xmm9
000071c0d83ceef5  vmovaps [rsp+0xA0], xmm10
000071c0d83ceefe  vmovaps [rsp+0xB0], xmm11
000071c0d83cef07  vmovaps [rsp+0xC0], xmm12
000071c0d83cef10  vmovaps [rsp+0xD0], xmm13
000071c0d83cef19  vmovaps [rsp+0xE0], xmm15
000071c0d83cef22  sub rsp, 0x30
000071c0d83cef26  movaps [rsp], xmm14
000071c0d83cef2b  movaps [rsp+0x10], xmm1
000071c0d83cef30  movaps [rsp+0x20], xmm15
000071c0d83cef36  lea rdi, [rsp]
000071c0d83cef3a  mov esi, 0x00
000071c0d83cef3f  mov rax, 0x5904ED15D530
000071c0d83cef49  call rax
000071c0d83cef4b  movaps xmm14, [rsp]
000071c0d83cef50  add rsp, 0x30
000071c0d83cef54  vmovaps xmm0, [rsp]
000071c0d83cef59  vmovaps xmm1, [rsp+0x10]
000071c0d83cef5f  vmovaps xmm2, [rsp+0x20]
000071c0d83cef65  vmovaps xmm3, [rsp+0x30]
000071c0d83cef6b  vmovaps xmm4, [rsp+0x40]
000071c0d83cef71  vmovaps xmm5, [rsp+0x50]
000071c0d83cef77  vmovaps xmm6, [rsp+0x60]
000071c0d83cef7d  vmovaps xmm7, [rsp+0x70]
000071c0d83cef83  vmovaps xmm8, [rsp+0x80]
000071c0d83cef8c  vmovaps xmm9, [rsp+0x90]
000071c0d83cef95  vmovaps xmm10, [rsp+0xA0]
000071c0d83cef9e  vmovaps xmm11, [rsp+0xB0]
000071c0d83cefa7  vmovaps xmm12, [rsp+0xC0]
000071c0d83cefb0  vmovaps xmm13, [rsp+0xD0]
000071c0d83cefb9  vmovaps xmm15, [rsp+0xE0]
000071c0d83cefc2  add rsp, 0xF0
000071c0d83cefc9  pop r11
000071c0d83cefcb  pop r10
000071c0d83cefcd  pop r9
000071c0d83cefcf  pop r8
000071c0d83cefd1  pop rsi
000071c0d83cefd2  pop rdi
000071c0d83cefd3  pop rdx
000071c0d83cefd4  pop rcx
000071c0d83cefd5  pop rax
000071c0d83cefd6  add rsp, 0x08
000071c0d83cefda  jmp 0x000071C0D83CECAE
000071c0d83cefdf  call 0x000071C0D82C34C0
000071c0d83cefe4  jmp 0x000071C0D83CECC4
000071c0d83cefe9  int3
000071c0d83cefea  nop [rax+rax*1], ax
000071c0d83ceff0  mov rax, [r15+0xF8]
000071c0d83ceff7  lea r14, [rax-0x150]
000071c0d83ceffe  mov [r15+0xF8], r14
000071c0d83cf005  mov rax, [r15+0x50]
000071c0d83cf009  lea r12, [rax+0x80]
000071c0d83cf010  movups xmm1, [r13+r12*1]
000071c0d83cf016  lea r12, [rax+0x90]
000071c0d83cf01d  movups xmm15, [r13+r12*1]
000071c0d83cf023  mov qword ptr [r15+0x48], 0x00
000071c0d83cf02b  lea r12, [rax+0x40]
000071c0d83cf02f  movups xmm14, [r13+r12*1]
000071c0d83cf035  lea r12, [rax+0x50]
000071c0d83cf039  movups xmm13, [r13+r12*1]
000071c0d83cf03f  lea r12, [r14+0x120]
000071c0d83cf046  movq xmm12, qword ptr [r15+0x1C0]
000071c0d83cf04f  movq xmm11, qword ptr [r15+0x1B0]
000071c0d83cf058  movq r11, xmm12
000071c0d83cf05d  movq r10, xmm11
000071c0d83cf062  mov [r13+r12*1], r11
000071c0d83cf067  lea r12, [r14+0x128]
000071c0d83cf06e  mov [r13+r12*1], r10
000071c0d83cf073  vxorps xmm12, xmm12, xmm12
000071c0d83cf078  vpbroadcastq xmm12, xmm12
000071c0d83cf07d  lea r12, [r14+0x100]
000071c0d83cf084  movq xmm11, qword ptr [r15+0x200]
000071c0d83cf08d  movq xmm10, qword ptr [r15+0x1F0]
000071c0d83cf096  movq r11, xmm11
000071c0d83cf09b  movq r10, xmm10
000071c0d83cf0a0  mov [r13+r12*1], r11
000071c0d83cf0a5  lea r12, [r14+0x108]
000071c0d83cf0ac  mov [r13+r12*1], r10
000071c0d83cf0b1  lea r12, [r14+0xE0]
000071c0d83cf0b8  movups [r13+r12*1], xmm15
000071c0d83cf0be  lea r12, [r14+0xF0]
000071c0d83cf0c5  movups [r13+r12*1], xmm1
000071c0d83cf0cb  lea r12, [rax+0xC0]
000071c0d83cf0d2  movups xmm1, [r13+r12*1]
000071c0d83cf0d8  lea r12, [rax+0xD0]
000071c0d83cf0df  movups xmm15, [r13+r12*1]
000071c0d83cf0e5  lea r12, [r14+0x110]
000071c0d83cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000071c0d83cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000071c0d83cf0fe  movq r11, xmm11
000071c0d83cf103  movq r10, xmm10
000071c0d83cf108  mov [r13+r12*1], r11
000071c0d83cf10d  lea r12, [r14+0x118]
000071c0d83cf114  mov [r13+r12*1], r10
000071c0d83cf119  movups xmm11, [r13+rax*1]
000071c0d83cf11f  lea r12, [rax+0x10]
000071c0d83cf123  movups xmm10, [r13+r12*1]
000071c0d83cf129  lea r12, [r14+0x130]
000071c0d83cf130  movq xmm9, qword ptr [r15+0x1A0]
000071c0d83cf139  movq xmm8, qword ptr [r15+0x190]
000071c0d83cf142  movq r11, xmm9
000071c0d83cf147  movq r10, xmm8
000071c0d83cf14c  mov [r13+r12*1], r11
000071c0d83cf151  lea r12, [r14+0x138]
000071c0d83cf158  mov [r13+r12*1], r10
000071c0d83cf15d  lea r12, [rax+0x140]
000071c0d83cf164  movups xmm9, [r13+r12*1]
000071c0d83cf16a  lea r12, [rax+0x150]
000071c0d83cf171  movups xmm8, [r13+r12*1]
000071c0d83cf177  lea r12, [r14+0xC0]
000071c0d83cf17e  movups [r13+r12*1], xmm15
000071c0d83cf184  lea r12, [r14+0xD0]
000071c0d83cf18b  movups [r13+r12*1], xmm1
000071c0d83cf191  lea r12, [rax+0x100]
000071c0d83cf198  movups xmm1, [r13+r12*1]
000071c0d83cf19e  lea r12, [rax+0x110]
000071c0d83cf1a5  movups xmm15, [r13+r12*1]
000071c0d83cf1ab  lea r12, [r14+0x140]
000071c0d83cf1b2  mov r11, [r15+0xE8]
000071c0d83cf1b9  mov [r13+r12*1], r11
000071c0d83cf1be  lea r12, [rax+0x180]
000071c0d83cf1c5  movups xmm7, [r13+r12*1]
000071c0d83cf1cb  lea r12, [rax+0x190]
000071c0d83cf1d2  movups xmm6, [r13+r12*1]
000071c0d83cf1d8  lea r12, [rax+0x1C0]
000071c0d83cf1df  movups xmm5, [r13+r12*1]
000071c0d83cf1e5  lea r12, [rax+0x1D0]
000071c0d83cf1ec  movups xmm4, [r13+r12*1]
000071c0d83cf1f2  lea r12, [r14+0x20]
000071c0d83cf1f6  movups [r13+r12*1], xmm1
000071c0d83cf1fc  lea r12, [r14+0x30]
000071c0d83cf200  movups [r13+r12*1], xmm13
000071c0d83cf206  lea r12, [rax+0x60]
000071c0d83cf20a  movups xmm1, [r13+r12*1]
000071c0d83cf210  lea r12, [rax+0x70]
000071c0d83cf214  movups xmm13, [r13+r12*1]
000071c0d83cf21a  lea r12, [rax+0x20]
000071c0d83cf21e  movups xmm3, [r13+r12*1]
000071c0d83cf224  lea r12, [rax+0x30]
000071c0d83cf228  movups xmm2, [r13+r12*1]
000071c0d83cf22e  movaps [r15+0x1F0], xmm2
000071c0d83cf236  lea r12, [r14+0x60]
000071c0d83cf23a  movups [r13+r12*1], xmm11
000071c0d83cf240  lea r12, [r14+0x70]
000071c0d83cf244  movups [r13+r12*1], xmm5
000071c0d83cf24a  lea r12, [rax+0xE0]
000071c0d83cf251  movups xmm11, [r13+r12*1]
000071c0d83cf257  lea r12, [rax+0xF0]
000071c0d83cf25e  movups xmm5, [r13+r12*1]
000071c0d83cf264  lea r12, [r14+0xA0]
000071c0d83cf26b  movups [r13+r12*1], xmm13
000071c0d83cf271  lea r12, [r14+0xB0]
000071c0d83cf278  movups [r13+r12*1], xmm1
000071c0d83cf27e  lea r12, [rax+0xA0]
000071c0d83cf285  movups xmm1, [r13+r12*1]
000071c0d83cf28b  lea r12, [rax+0xB0]
000071c0d83cf292  movups xmm13, [r13+r12*1]
000071c0d83cf298  lea r12, [rax+0x120]
000071c0d83cf29f  vmovaps [rsp+0x10], xmm1
000071c0d83cf2a5  movups xmm1, [r13+r12*1]
000071c0d83cf2ab  lea r12, [rax+0x130]
000071c0d83cf2b2  vmovaps [rsp+0x20], xmm1
000071c0d83cf2b8  movups xmm1, [r13+r12*1]
000071c0d83cf2be  lea r12, [rax+0x160]
000071c0d83cf2c5  vmovaps [rsp+0x30], xmm1
000071c0d83cf2cb  movups xmm1, [r13+r12*1]
000071c0d83cf2d1  lea r12, [rax+0x170]
000071c0d83cf2d8  vmovaps [rsp+0x40], xmm1
000071c0d83cf2de  movups xmm1, [r13+r12*1]
000071c0d83cf2e4  movaps [r15+0x2B0], xmm1
000071c0d83cf2ec  lea r12, [r14+0x80]
000071c0d83cf2f3  movups [r13+r12*1], xmm13
000071c0d83cf2f9  lea r12, [r14+0x90]
000071c0d83cf300  vmovaps xmm13, [rsp+0x10]
000071c0d83cf306  movups [r13+r12*1], xmm13
000071c0d83cf30c  lea r12, [rax+0x1A0]
000071c0d83cf313  movups xmm13, [r13+r12*1]
000071c0d83cf319  lea r12, [rax+0x1B0]
000071c0d83cf320  vmovaps [rsp+0x10], xmm1
000071c0d83cf326  movups xmm1, [r13+r12*1]
000071c0d83cf32c  movaps [r15+0x290], xmm13
000071c0d83cf334  movaps [r15+0x1E0], xmm1
000071c0d83cf33c  lea r12, [rax+0x1E0]
000071c0d83cf343  vmovaps [rsp+0x50], xmm1
000071c0d83cf349  movups xmm1, [r13+r12*1]
000071c0d83cf34f  lea r12, [rax+0x1F0]
000071c0d83cf356  vmovaps [rsp+0x60], xmm1
000071c0d83cf35c  movups xmm1, [r13+r12*1]
000071c0d83cf362  mov qword ptr [r15+0x50], 0x430920
000071c0d83cf36a  lea rax, [r14+0x40]
000071c0d83cf36e  vmovaps [rsp+0x70], xmm1
000071c0d83cf374  vmovaps xmm1, [rsp+0x40]
000071c0d83cf37a  movups [r13+rax*1], xmm1
000071c0d83cf380  lea rax, [r14+0x50]
000071c0d83cf384  movups [r13+rax*1], xmm10
000071c0d83cf38a  vmovaps xmm1, [rsp+0x70]
000071c0d83cf390  movups [r13+r14*1], xmm1
000071c0d83cf396  lea rax, [r14+0x10]
000071c0d83cf39a  vmovaps xmm1, [rsp+0x60]
000071c0d83cf3a0  movups [r13+rax*1], xmm1
000071c0d83cf3a6  mov rax, [r15+0x40]
000071c0d83cf3aa  vmovaps [rsp+0x40], xmm3
000071c0d83cf3b0  vmovaps xmm1, [rsp+0x40]
000071c0d83cf3b6  por xmm3, xmm1
000071c0d83cf3ba  vmovaps [rsp+0x40], xmm6
000071c0d83cf3c0  vmovaps xmm10, [rsp+0x40]
000071c0d83cf3c6  por xmm6, xmm10
000071c0d83cf3cb  lea r12, [rax+0x30]
000071c0d83cf3cf  mov r11, [r13+r12*1]
000071c0d83cf3d4  lea r12, [rax+0x38]
000071c0d83cf3d8  mov r10, [r13+r12*1]
000071c0d83cf3dd  movq xmm10, r11
000071c0d83cf3e2  vmovaps [rsp+0x40], xmm1
000071c0d83cf3e8  movq xmm1, r10
000071c0d83cf3ed  movq xmm10, xmm10
000071c0d83cf3f2  vmovaps [rsp+0x60], xmm10
000071c0d83cf3f8  movq xmm10, xmm10
000071c0d83cf3fd  movaps [r15+0x130], xmm10
000071c0d83cf405  movq xmm1, xmm1
000071c0d83cf409  vmovaps [rsp+0x70], xmm1
000071c0d83cf40f  movq xmm1, xmm1
000071c0d83cf413  movaps [r15+0x280], xmm1
000071c0d83cf41b  vmovaps [rsp+0x80], xmm9
000071c0d83cf424  vmovaps xmm1, [rsp+0x80]
000071c0d83cf42d  por xmm9, xmm1
000071c0d83cf432  lea r12, [rax+0x20]
000071c0d83cf436  mov r11, [r13+r12*1]
000071c0d83cf43b  lea r12, [rax+0x28]
000071c0d83cf43f  mov r10, [r13+r12*1]
000071c0d83cf444  movq xmm1, r11
000071c0d83cf449  movq xmm10, r10
000071c0d83cf44e  movq xmm1, xmm1
000071c0d83cf452  vmovaps [rsp+0x80], xmm1
000071c0d83cf45b  movq xmm1, xmm1
000071c0d83cf45f  movaps [r15+0x150], xmm1
000071c0d83cf467  movq xmm10, xmm10
000071c0d83cf46c  vmovaps [rsp+0x90], xmm10
000071c0d83cf475  movq xmm10, xmm10
000071c0d83cf47a  movaps [r15+0x140], xmm10
000071c0d83cf482  lea r12, [rax+0x10]
000071c0d83cf486  mov r11, [r13+r12*1]
000071c0d83cf48b  lea r12, [rax+0x18]
000071c0d83cf48f  mov r10, [r13+r12*1]
000071c0d83cf494  movq xmm1, r11
000071c0d83cf499  movq xmm10, r10
000071c0d83cf49e  movq xmm1, xmm1
000071c0d83cf4a2  vmovaps [rsp+0xA0], xmm1
000071c0d83cf4ab  movq xmm1, xmm1
000071c0d83cf4af  movaps [r15+0x170], xmm1
000071c0d83cf4b7  movq xmm10, xmm10
000071c0d83cf4bc  vmovaps [rsp+0xB0], xmm10
000071c0d83cf4c5  movq xmm10, xmm10
000071c0d83cf4ca  movaps [r15+0x160], xmm10
000071c0d83cf4d2  mov r12, [r13+rax*1]
000071c0d83cf4d7  vmovq xmm1, r12
000071c0d83cf4dc  vpbroadcastq xmm1, xmm1
000071c0d83cf4e1  lea r12, [rax+0x08]
000071c0d83cf4e5  mov rax, [r13+r12*1]
000071c0d83cf4ea  movq xmm10, rax
000071c0d83cf4ef  movaps [r15+0x230], xmm10
000071c0d83cf4f7  lea rax, [r14+0x50]
000071c0d83cf4fb  movups xmm10, [r13+rax*1]
000071c0d83cf501  lea rax, [r14+0x60]
000071c0d83cf505  vmovaps [rsp+0xC0], xmm1
000071c0d83cf50e  movups xmm1, [r13+rax*1]
000071c0d83cf514  lea rax, [r14+0x30]
000071c0d83cf518  vmovaps [rsp+0xD0], xmm1
000071c0d83cf521  movups xmm1, [r13+rax*1]
000071c0d83cf527  mov qword ptr [r15+0x60], 0x430920
000071c0d83cf52f  mov qword ptr [r15+0x58], 0x40
000071c0d83cf537  vmovaps [rsp+0xE0], xmm1
000071c0d83cf540  vmovaps [rsp+0xF0], xmm15
000071c0d83cf549  vmovaps xmm15, [rsp+0xC0]
000071c0d83cf552  vmovaps [rsp+0xC0], xmm14
000071c0d83cf55b  vmovaps xmm14, [rsp+0x40]
000071c0d83cf561  vmovaps [rsp+0x40], xmm13
000071c0d83cf567  movaps xmm1, xmm15
000071c0d83cf56b  mulpd xmm1, xmm14
000071c0d83cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000071c0d83cf575  ptest xmm13, xmm13
000071c0d83cf57b  jnz 0x000071C0D83D0682
000071c0d83cf581  movq xmm14, qword ptr [r15+0x230]
000071c0d83cf58a  vmovaps [rsp+0x100], xmm14
000071c0d83cf593  vpermilpd xmm14, xmm14, 0x00
000071c0d83cf599  vmovaps [rsp+0x110], xmm1
000071c0d83cf5a2  vmovaps xmm1, [rsp+0xE0]
000071c0d83cf5ab  vmovaps [rsp+0xE0], xmm15
000071c0d83cf5b4  movaps xmm13, xmm1
000071c0d83cf5b8  mulpd xmm13, xmm14
000071c0d83cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000071c0d83cf5c3  ptest xmm15, xmm15
000071c0d83cf5c9  jnz 0x000071C0D83D07C4
000071c0d83cf5cf  vxorps xmm1, xmm1, xmm1
000071c0d83cf5d3  vpbroadcastq xmm1, xmm1
000071c0d83cf5d8  vmovaps xmm14, [rsp+0xE0]
000071c0d83cf5e1  vmovaps [rsp+0xE0], xmm1
000071c0d83cf5ea  vmovaps xmm1, [rsp+0xD0]
000071c0d83cf5f3  vmovaps [rsp+0xD0], xmm13
000071c0d83cf5fc  movaps xmm15, xmm14
000071c0d83cf600  mulpd xmm15, xmm1
000071c0d83cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000071c0d83cf60b  ptest xmm13, xmm13
000071c0d83cf611  jnz 0x000071C0D83D0907
000071c0d83cf617  movaps xmm1, xmm14
000071c0d83cf61b  mulpd xmm1, xmm10
000071c0d83cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000071c0d83cf625  ptest xmm13, xmm13
000071c0d83cf62b  jnz 0x000071C0D83D0A4A
000071c0d83cf631  movaps xmm13, xmm14
000071c0d83cf635  mulpd xmm13, xmm2
000071c0d83cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000071c0d83cf640  ptest xmm10, xmm10
000071c0d83cf646  jnz 0x000071C0D83D0B8C
000071c0d83cf64c  vmovaps [rsp+0x120], xmm7
000071c0d83cf655  vmovaps xmm14, [rsp+0x120]
000071c0d83cf65e  por xmm7, xmm14
000071c0d83cf663  vmovaps xmm14, [rsp+0xC0]
000071c0d83cf66c  vmovaps xmm10, [rsp+0xC0]
000071c0d83cf675  por xmm14, xmm10
000071c0d83cf67a  vmovaps xmm2, [rsp+0x100]
000071c0d83cf683  vpermilpd xmm2, xmm2, 0x00
000071c0d83cf689  vmovaps [rsp+0xC0], xmm1
000071c0d83cf692  vmovaps [rsp+0x120], xmm15
000071c0d83cf69b  movaps xmm1, xmm10
000071c0d83cf69f  mulpd xmm1, xmm2
000071c0d83cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000071c0d83cf6a8  ptest xmm15, xmm15
000071c0d83cf6ae  jnz 0x000071C0D83D0CCF
000071c0d83cf6b4  xor eax, eax
000071c0d83cf6b6  mov r12d, 0x40
000071c0d83cf6bc  mov r11d, 0x200
000071c0d83cf6c2  cmp r12, r11
000071c0d83cf6c5  cmc
000071c0d83cf6c6  lahf
000071c0d83cf6c7  seto al
000071c0d83cf6ca  mov [r15+0x108], eax
000071c0d83cf6d1  vmovaps xmm10, [rsp+0x110]
000071c0d83cf6da  vmovaps xmm2, [rsp+0xE0]
000071c0d83cf6e3  vmovaps [rsp+0xE0], xmm1
000071c0d83cf6ec  movaps xmm15, xmm10
000071c0d83cf6f0  addpd xmm15, xmm2
000071c0d83cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83cf6fb  ptest xmm1, xmm1
000071c0d83cf700  jnz 0x000071C0D83D0E10
000071c0d83cf706  vmovaps xmm10, [rsp+0x120]
000071c0d83cf70f  vmovaps [rsp+0x110], xmm15
000071c0d83cf718  movaps xmm1, xmm10
000071c0d83cf71c  addpd xmm1, xmm12
000071c0d83cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000071c0d83cf726  ptest xmm15, xmm15
000071c0d83cf72c  jnz 0x000071C0D83D0F53
000071c0d83cf732  vmovaps xmm10, [rsp+0xC0]
000071c0d83cf73b  vmovaps [rsp+0xC0], xmm1
000071c0d83cf744  movaps xmm15, xmm10
000071c0d83cf748  addpd xmm15, xmm12
000071c0d83cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83cf753  ptest xmm1, xmm1
000071c0d83cf758  jnz 0x000071C0D83D1095
000071c0d83cf75e  vmovaps xmm1, [rsp+0x30]
000071c0d83cf764  vmovaps xmm12, [rsp+0x30]
000071c0d83cf76a  por xmm1, xmm12
000071c0d83cf76f  vmovaps xmm12, [rsp+0x20]
000071c0d83cf775  vmovaps xmm10, [rsp+0x20]
000071c0d83cf77b  por xmm12, xmm10
000071c0d83cf780  vmovaps [rsp+0x20], xmm5
000071c0d83cf786  vmovaps xmm10, [rsp+0x20]
000071c0d83cf78c  por xmm5, xmm10
000071c0d83cf791  vmovaps [rsp+0x20], xmm11
000071c0d83cf797  vmovaps xmm10, [rsp+0x20]
000071c0d83cf79d  por xmm11, xmm10
000071c0d83cf7a2  vmovaps [rsp+0x20], xmm4
000071c0d83cf7a8  vmovaps xmm10, [rsp+0x20]
000071c0d83cf7ae  por xmm4, xmm10
000071c0d83cf7b3  vmovaps [rsp+0x20], xmm8
000071c0d83cf7b9  vmovaps xmm10, [rsp+0x20]
000071c0d83cf7bf  por xmm8, xmm10
000071c0d83cf7c4  vmovaps xmm10, [rsp+0xF0]
000071c0d83cf7cd  vmovaps [rsp+0x20], xmm1
000071c0d83cf7d3  vmovaps xmm1, [rsp+0xF0]
000071c0d83cf7dc  por xmm10, xmm1
000071c0d83cf7e1  lea rax, [r14+0xA0]
000071c0d83cf7e8  movups xmm1, [r13+rax*1]
000071c0d83cf7ee  lea rax, [r14+0xB0]
000071c0d83cf7f5  vmovaps [rsp+0x30], xmm1
000071c0d83cf7fb  movups xmm1, [r13+rax*1]
000071c0d83cf801  vmovaps [rsp+0xF0], xmm1
000071c0d83cf80a  vmovaps [rsp+0x120], xmm15
000071c0d83cf813  movaps xmm1, xmm13
000071c0d83cf817  addpd xmm1, xmm2
000071c0d83cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000071c0d83cf820  ptest xmm15, xmm15
000071c0d83cf826  jnz 0x000071C0D83D11ED
000071c0d83cf82c  lea rax, [r14+0xF0]
000071c0d83cf833  movups xmm15, [r13+rax*1]
000071c0d83cf839  vmovaps xmm2, [rsp+0xC0]
000071c0d83cf842  vmovaps [rsp+0xC0], xmm1
000071c0d83cf84b  vmovaps xmm1, [rsp+0xE0]
000071c0d83cf854  vmovaps [rsp+0xE0], xmm15
000071c0d83cf85d  movaps xmm13, xmm2
000071c0d83cf861  addpd xmm13, xmm1
000071c0d83cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000071c0d83cf86c  ptest xmm15, xmm15
000071c0d83cf872  jnz 0x000071C0D83D1338
000071c0d83cf878  vmovaps xmm15, [rsp+0x120]
000071c0d83cf881  vmovaps xmm2, [rsp+0xD0]
000071c0d83cf88a  vmovaps [rsp+0xD0], xmm14
000071c0d83cf893  movaps xmm1, xmm15
000071c0d83cf897  addpd xmm1, xmm2
000071c0d83cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000071c0d83cf8a0  ptest xmm14, xmm14
000071c0d83cf8a6  jnz 0x000071C0D83D147A
000071c0d83cf8ac  vmovaps xmm15, [rsp+0x100]
000071c0d83cf8b5  vpermilpd xmm15, xmm15, 0x00
000071c0d83cf8bb  vmovaps xmm2, [rsp+0xF0]
000071c0d83cf8c4  vmovaps [rsp+0xF0], xmm1
000071c0d83cf8cd  movaps xmm14, xmm2
000071c0d83cf8d1  mulpd xmm14, xmm15
000071c0d83cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000071c0d83cf8dc  ptest xmm1, xmm1
000071c0d83cf8e1  jnz 0x000071C0D83D15BB
000071c0d83cf8e7  vmovaps xmm1, [rsp+0xA0]
000071c0d83cf8f0  vpermilpd xmm1, xmm1, 0x00
000071c0d83cf8f6  vmovaps xmm2, [rsp+0xE0]
000071c0d83cf8ff  vmovaps [rsp+0xE0], xmm14
000071c0d83cf908  movaps xmm15, xmm2
000071c0d83cf90c  mulpd xmm15, xmm1
000071c0d83cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000071c0d83cf917  ptest xmm14, xmm14
000071c0d83cf91d  jnz 0x000071C0D83D16FE
000071c0d83cf923  lea rax, [r14+0xE0]
000071c0d83cf92a  movups xmm1, [r13+rax*1]
000071c0d83cf930  vmovaps xmm14, [rsp+0x100]
000071c0d83cf939  vpermilpd xmm14, xmm14, 0x00
000071c0d83cf93f  vmovaps [rsp+0x100], xmm1
000071c0d83cf948  vmovaps xmm1, [rsp+0x30]
000071c0d83cf94e  vmovaps [rsp+0x30], xmm15
000071c0d83cf954  movaps xmm2, xmm1
000071c0d83cf957  mulpd xmm2, xmm14
000071c0d83cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000071c0d83cf961  ptest xmm15, xmm15
000071c0d83cf967  jnz 0x000071C0D83D184A
000071c0d83cf96d  vmovaps [rsp+0x120], xmm10
000071c0d83cf976  vmovaps xmm1, [rsp+0x120]
000071c0d83cf97f  por xmm10, xmm1
000071c0d83cf984  movaps [r15+0x300], xmm10
000071c0d83cf98c  vmovaps [rsp+0x120], xmm8
000071c0d83cf995  vmovaps xmm1, [rsp+0x120]
000071c0d83cf99e  por xmm8, xmm1
000071c0d83cf9a3  movaps [r15+0x190], xmm8
000071c0d83cf9ab  vmovaps xmm1, [rsp+0xA0]
000071c0d83cf9b4  vpermilpd xmm1, xmm1, 0x00
000071c0d83cf9ba  vmovaps xmm14, [rsp+0x100]
000071c0d83cf9c3  vmovaps [rsp+0x100], xmm13
000071c0d83cf9cc  movaps xmm15, xmm14
000071c0d83cf9d0  mulpd xmm15, xmm1
000071c0d83cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000071c0d83cf9db  ptest xmm13, xmm13
000071c0d83cf9e1  jnz 0x000071C0D83D198B
000071c0d83cf9e7  lea rax, [r14+0x90]
000071c0d83cf9ee  movups xmm1, [r13+rax*1]
000071c0d83cf9f4  vmovaps [rsp+0x120], xmm4
000071c0d83cf9fd  vmovaps xmm14, [rsp+0x120]
000071c0d83cfa06  por xmm4, xmm14
000071c0d83cfa0b  movaps [r15+0x1C0], xmm4
000071c0d83cfa13  vmovaps [rsp+0x120], xmm11
000071c0d83cfa1c  vmovaps xmm14, [rsp+0x120]
000071c0d83cfa25  por xmm11, xmm14
000071c0d83cfa2a  movaps [r15+0x200], xmm11
000071c0d83cfa32  vmovaps [rsp+0x120], xmm5
000071c0d83cfa3b  vmovaps xmm14, [rsp+0x120]
000071c0d83cfa44  por xmm5, xmm14
000071c0d83cfa49  movaps [r15+0x2D0], xmm5
000071c0d83cfa51  vmovaps [rsp+0x120], xmm12
000071c0d83cfa5a  vmovaps xmm14, [rsp+0x120]
000071c0d83cfa63  por xmm12, xmm14
000071c0d83cfa68  movaps [r15+0x2E0], xmm12
000071c0d83cfa70  vmovaps xmm13, [rsp+0x110]
000071c0d83cfa79  vmovaps [rsp+0x110], xmm1
000071c0d83cfa82  vmovaps xmm1, [rsp+0xE0]
000071c0d83cfa8b  vmovaps [rsp+0xE0], xmm15
000071c0d83cfa94  movaps xmm14, xmm13
000071c0d83cfa98  addpd xmm14, xmm1
000071c0d83cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000071c0d83cfaa3  ptest xmm15, xmm15
000071c0d83cfaa9  jnz 0x000071C0D83D1AD8
000071c0d83cfaaf  vmovaps xmm1, [rsp+0xA0]
000071c0d83cfab8  vpermilpd xmm1, xmm1, 0x00
000071c0d83cfabe  vmovaps xmm13, [rsp+0x110]
000071c0d83cfac7  vmovaps [rsp+0x110], xmm14
000071c0d83cfad0  movaps xmm15, xmm13
000071c0d83cfad4  mulpd xmm15, xmm1
000071c0d83cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000071c0d83cfadf  ptest xmm14, xmm14
000071c0d83cfae5  jnz 0x000071C0D83D1C1B
000071c0d83cfaeb  lea rax, [r14+0x80]
000071c0d83cfaf2  movups xmm1, [r13+rax*1]
000071c0d83cfaf8  vmovaps xmm13, [rsp+0xC0]
000071c0d83cfb01  vmovaps [rsp+0xC0], xmm1
000071c0d83cfb0a  movaps xmm14, xmm13
000071c0d83cfb0e  addpd xmm14, xmm2
000071c0d83cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000071c0d83cfb19  ptest xmm1, xmm1
000071c0d83cfb1e  jnz 0x000071C0D83D1D68
000071c0d83cfb24  vmovaps xmm13, [rsp+0x100]
000071c0d83cfb2d  vmovaps xmm2, [rsp+0x30]
000071c0d83cfb33  vmovaps [rsp+0x30], xmm15
000071c0d83cfb39  movaps xmm1, xmm13
000071c0d83cfb3d  addpd xmm1, xmm2
000071c0d83cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000071c0d83cfb46  ptest xmm15, xmm15
000071c0d83cfb4c  jnz 0x000071C0D83D1EAB
000071c0d83cfb52  vmovaps xmm15, [rsp+0x20]
000071c0d83cfb58  vmovaps xmm13, [rsp+0x20]
000071c0d83cfb5e  por xmm15, xmm13
000071c0d83cfb63  movaps [r15+0x2F0], xmm15
000071c0d83cfb6b  vmovaps xmm13, [rsp+0xA0]
000071c0d83cfb74  vpermilpd xmm13, xmm13, 0x00
000071c0d83cfb7a  vmovaps [rsp+0x20], xmm1
000071c0d83cfb80  vmovaps xmm1, [rsp+0xC0]
000071c0d83cfb89  vmovaps [rsp+0xA0], xmm15
000071c0d83cfb92  movaps xmm2, xmm1
000071c0d83cfb95  mulpd xmm2, xmm13
000071c0d83cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000071c0d83cfb9f  ptest xmm15, xmm15
000071c0d83cfba5  jnz 0x000071C0D83D1FEC
000071c0d83cfbab  lea rax, [r14+0xD0]
000071c0d83cfbb2  movups xmm1, [r13+rax*1]
000071c0d83cfbb8  vmovaps xmm13, [rsp+0xF0]
000071c0d83cfbc1  vmovaps [rsp+0xC0], xmm1
000071c0d83cfbca  vmovaps xmm1, [rsp+0xE0]
000071c0d83cfbd3  vmovaps [rsp+0xE0], xmm14
000071c0d83cfbdc  movaps xmm15, xmm13
000071c0d83cfbe0  addpd xmm15, xmm1
000071c0d83cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000071c0d83cfbeb  ptest xmm14, xmm14
000071c0d83cfbf1  jnz 0x000071C0D83D2137
000071c0d83cfbf7  vmovaps xmm1, [rsp+0xB0]
000071c0d83cfc00  vpermilpd xmm1, xmm1, 0x00
000071c0d83cfc06  movaps xmm14, xmm11
000071c0d83cfc0a  mulpd xmm14, xmm1
000071c0d83cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000071c0d83cfc15  ptest xmm13, xmm13
000071c0d83cfc1b  jnz 0x000071C0D83D227A
000071c0d83cfc21  movaps [r15+0x260], xmm14
000071c0d83cfc29  vxorps xmm1, xmm1, xmm1
000071c0d83cfc2d  vpbroadcastq xmm1, xmm1
000071c0d83cfc32  movaps [r15+0x1B0], xmm1
000071c0d83cfc3a  vmovaps xmm1, [rsp+0xB0]
000071c0d83cfc43  vpermilpd xmm1, xmm1, 0x00
000071c0d83cfc49  vmovaps xmm11, [rsp+0xC0]
000071c0d83cfc52  vmovaps [rsp+0xC0], xmm15
000071c0d83cfc5b  movaps xmm13, xmm11
000071c0d83cfc5f  mulpd xmm13, xmm1
000071c0d83cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000071c0d83cfc6a  ptest xmm15, xmm15
000071c0d83cfc70  jnz 0x000071C0D83D23BD
000071c0d83cfc76  lea rax, [r14+0xC0]
000071c0d83cfc7d  movups xmm1, [r13+rax*1]
000071c0d83cfc83  vmovaps xmm11, [rsp+0x110]
000071c0d83cfc8c  vmovaps [rsp+0xF0], xmm1
000071c0d83cfc95  vmovaps xmm1, [rsp+0x30]
000071c0d83cfc9b  vmovaps [rsp+0x30], xmm14
000071c0d83cfca1  movaps xmm15, xmm11
000071c0d83cfca5  addpd xmm15, xmm1
000071c0d83cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000071c0d83cfcb0  ptest xmm14, xmm14
000071c0d83cfcb6  jnz 0x000071C0D83D250A
000071c0d83cfcbc  vmovaps [rsp+0x100], xmm9
000071c0d83cfcc5  vmovaps xmm1, [rsp+0x100]
000071c0d83cfcce  por xmm9, xmm1
000071c0d83cfcd3  movaps [r15+0x270], xmm9
000071c0d83cfcdb  vmovaps [rsp+0x100], xmm6
000071c0d83cfce4  vmovaps xmm1, [rsp+0x100]
000071c0d83cfced  por xmm6, xmm1
000071c0d83cfcf1  movaps [r15+0x1A0], xmm6
000071c0d83cfcf9  vmovaps xmm14, [rsp+0xB0]
000071c0d83cfd02  vpermilpd xmm14, xmm14, 0x00
000071c0d83cfd08  vmovaps xmm6, [rsp+0xF0]
000071c0d83cfd11  vmovaps [rsp+0xF0], xmm1
000071c0d83cfd1a  movaps xmm11, xmm6
000071c0d83cfd1e  mulpd xmm11, xmm14
000071c0d83cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000071c0d83cfd29  ptest xmm1, xmm1
000071c0d83cfd2e  jnz 0x000071C0D83D264D
000071c0d83cfd34  lea rax, [r14+0x20]
000071c0d83cfd38  movups xmm1, [r13+rax*1]
000071c0d83cfd3e  movaps [r15+0x110], xmm1
000071c0d83cfd46  vmovaps xmm6, [rsp+0xE0]
000071c0d83cfd4f  vmovaps [rsp+0xE0], xmm1
000071c0d83cfd58  movaps xmm14, xmm6
000071c0d83cfd5c  addpd xmm14, xmm2
000071c0d83cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000071c0d83cfd67  ptest xmm1, xmm1
000071c0d83cfd6c  jnz 0x000071C0D83D279A
000071c0d83cfd72  vmovaps xmm1, [rsp+0xB0]
000071c0d83cfd7b  vpermilpd xmm1, xmm1, 0x00
000071c0d83cfd81  movaps xmm6, xmm5
000071c0d83cfd84  mulpd xmm6, xmm1
000071c0d83cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000071c0d83cfd8d  ptest xmm2, xmm2
000071c0d83cfd92  jnz 0x000071C0D83D28DC
000071c0d83cfd98  vmovaps xmm5, [rsp+0x20]
000071c0d83cfd9e  movaps xmm1, xmm5
000071c0d83cfda1  addpd xmm1, xmm13
000071c0d83cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000071c0d83cfdab  ptest xmm2, xmm2
000071c0d83cfdb0  jnz 0x000071C0D83D2A1C
000071c0d83cfdb6  vmovaps xmm13, [rsp+0x80]
000071c0d83cfdbf  vpermilpd xmm13, xmm13, 0x00
000071c0d83cfdc5  vmovaps xmm2, [rsp+0xE0]
000071c0d83cfdce  vmovaps [rsp+0x20], xmm1
000071c0d83cfdd4  movaps xmm5, xmm2
000071c0d83cfdd7  mulpd xmm5, xmm13
000071c0d83cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000071c0d83cfde1  ptest xmm1, xmm1
000071c0d83cfde6  jnz 0x000071C0D83D2B5D
000071c0d83cfdec  vmovaps xmm1, [rsp+0x80]
000071c0d83cfdf5  vpermilpd xmm1, xmm1, 0x00
000071c0d83cfdfb  movaps xmm13, xmm10
000071c0d83cfdff  mulpd xmm13, xmm1
000071c0d83cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000071c0d83cfe0a  ptest xmm2, xmm2
000071c0d83cfe0f  jnz 0x000071C0D83D2C9E
000071c0d83cfe15  vmovaps xmm10, [rsp+0x30]
000071c0d83cfe1b  movaps xmm1, xmm15
000071c0d83cfe1f  addpd xmm1, xmm10
000071c0d83cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000071c0d83cfe29  ptest xmm2, xmm2
000071c0d83cfe2e  jnz 0x000071C0D83D2DE1
000071c0d83cfe34  vmovaps xmm10, [rsp+0xC0]
000071c0d83cfe3d  movaps xmm15, xmm10
000071c0d83cfe41  addpd xmm15, xmm11
000071c0d83cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000071c0d83cfe4c  ptest xmm2, xmm2
000071c0d83cfe51  jnz 0x000071C0D83D2F23
000071c0d83cfe57  vmovaps xmm11, [rsp+0x80]
000071c0d83cfe60  vpermilpd xmm11, xmm11, 0x00
000071c0d83cfe66  movaps xmm10, xmm12
000071c0d83cfe6a  mulpd xmm10, xmm11
000071c0d83cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000071c0d83cfe75  ptest xmm2, xmm2
000071c0d83cfe7a  jnz 0x000071C0D83D3067
000071c0d83cfe80  vmovaps xmm12, [rsp+0x80]
000071c0d83cfe89  vpermilpd xmm12, xmm12, 0x00
000071c0d83cfe8f  vmovaps xmm2, [rsp+0xA0]
000071c0d83cfe98  vmovaps [rsp+0x30], xmm1
000071c0d83cfe9e  movaps xmm11, xmm2
000071c0d83cfea2  mulpd xmm11, xmm12
000071c0d83cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000071c0d83cfead  ptest xmm1, xmm1
000071c0d83cfeb2  jnz 0x000071C0D83D31AB
000071c0d83cfeb8  movaps xmm1, xmm14
000071c0d83cfebc  addpd xmm1, xmm6
000071c0d83cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000071c0d83cfec5  ptest xmm12, xmm12
000071c0d83cfecb  jnz 0x000071C0D83D32EE
000071c0d83cfed1  vmovaps xmm12, [rsp+0x20]
000071c0d83cfed7  movaps xmm14, xmm12
000071c0d83cfedb  addpd xmm14, xmm5
000071c0d83cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000071c0d83cfee6  ptest xmm6, xmm6
000071c0d83cfeeb  jnz 0x000071C0D83D342F
000071c0d83cfef1  vmovaps xmm12, [rsp+0x90]
000071c0d83cfefa  vpermilpd xmm12, xmm12, 0x00
000071c0d83cff00  movaps xmm6, xmm9
000071c0d83cff04  mulpd xmm6, xmm12
000071c0d83cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000071c0d83cff0e  ptest xmm5, xmm5
000071c0d83cff13  jnz 0x000071C0D83D3572
000071c0d83cff19  movaps xmm12, xmm15
000071c0d83cff1d  addpd xmm12, xmm13
000071c0d83cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000071c0d83cff28  ptest xmm9, xmm9
000071c0d83cff2e  jnz 0x000071C0D83D36B4
000071c0d83cff34  vmovaps xmm13, [rsp+0x30]
000071c0d83cff3a  movaps xmm15, xmm13
000071c0d83cff3e  addpd xmm15, xmm10
000071c0d83cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000071c0d83cff49  ptest xmm9, xmm9
000071c0d83cff4f  jnz 0x000071C0D83D37F8
000071c0d83cff55  vmovaps xmm13, [rsp+0xD0]
000071c0d83cff5e  vmovaps xmm10, [rsp+0xD0]
000071c0d83cff67  por xmm13, xmm10
000071c0d83cff6c  movaps [r15+0x250], xmm13
000071c0d83cff74  vmovaps [rsp+0x20], xmm7
000071c0d83cff7a  vmovaps xmm13, [rsp+0x20]
000071c0d83cff80  por xmm7, xmm13
000071c0d83cff85  movaps [r15+0x2A0], xmm7
000071c0d83cff8d  vmovaps [rsp+0x20], xmm3
000071c0d83cff93  vmovaps xmm13, [rsp+0x20]
000071c0d83cff99  por xmm3, xmm13
000071c0d83cff9e  movaps [r15+0x1D0], xmm3
000071c0d83cffa6  lea rax, [r14+0x40]
000071c0d83cffaa  movups xmm13, [r13+rax*1]
000071c0d83cffb0  movaps [r15+0x2C0], xmm13
000071c0d83cffb8  vmovaps xmm10, [rsp+0x90]
000071c0d83cffc1  vpermilpd xmm10, xmm10, 0x00
000071c0d83cffc7  movaps xmm9, xmm8
000071c0d83cffcb  mulpd xmm9, xmm10
000071c0d83cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000071c0d83cffd6  ptest xmm5, xmm5
000071c0d83cffdb  jnz 0x000071C0D83D3946
000071c0d83cffe1  movaps xmm10, xmm1
000071c0d83cffe5  addpd xmm10, xmm11
000071c0d83cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000071c0d83cfff0  ptest xmm8, xmm8
000071c0d83cfff6  jnz 0x000071C0D83D3A8A
000071c0d83cfffc  movaps xmm1, xmm14
000071c0d83d0000  addpd xmm1, xmm6
000071c0d83d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000071c0d83d0009  ptest xmm11, xmm11
000071c0d83d000f  jnz 0x000071C0D83D3BCD
000071c0d83d0015  vmovaps xmm14, [rsp+0x90]
000071c0d83d001e  vpermilpd xmm14, xmm14, 0x00
000071c0d83d0024  movaps xmm11, xmm13
000071c0d83d0028  mulpd xmm11, xmm14
000071c0d83d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000071c0d83d0033  ptest xmm8, xmm8
000071c0d83d0039  jnz 0x000071C0D83D3D0E
000071c0d83d003f  vmovaps xmm14, [rsp+0x90]
000071c0d83d0048  vpermilpd xmm14, xmm14, 0x00
000071c0d83d004e  vmovaps xmm8, [rsp+0x10]
000071c0d83d0054  movaps xmm13, xmm8
000071c0d83d0058  mulpd xmm13, xmm14
000071c0d83d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000071c0d83d0063  ptest xmm6, xmm6
000071c0d83d0068  jnz 0x000071C0D83D3E52
000071c0d83d006e  vmovaps xmm14, [rsp+0x60]
000071c0d83d0074  vpermilpd xmm14, xmm14, 0x00
000071c0d83d007a  movaps xmm8, xmm7
000071c0d83d007e  mulpd xmm8, xmm14
000071c0d83d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000071c0d83d0089  ptest xmm6, xmm6
000071c0d83d008e  jnz 0x000071C0D83D3F96
000071c0d83d0094  movaps xmm14, xmm12
000071c0d83d0098  addpd xmm14, xmm9
000071c0d83d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000071c0d83d00a3  ptest xmm7, xmm7
000071c0d83d00a8  jnz 0x000071C0D83D40D9
000071c0d83d00ae  vmovaps xmm12, [rsp+0x60]
000071c0d83d00b4  vpermilpd xmm12, xmm12, 0x00
000071c0d83d00ba  vmovaps xmm7, [rsp+0xF0]
000071c0d83d00c3  movaps xmm9, xmm7
000071c0d83d00c7  mulpd xmm9, xmm12
000071c0d83d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000071c0d83d00d2  ptest xmm6, xmm6
000071c0d83d00d7  jnz 0x000071C0D83D421D
000071c0d83d00dd  movaps xmm12, xmm15
000071c0d83d00e1  addpd xmm12, xmm11
000071c0d83d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000071c0d83d00ec  ptest xmm7, xmm7
000071c0d83d00f1  jnz 0x000071C0D83D4360
000071c0d83d00f7  vmovaps xmm15, [rsp+0x60]
000071c0d83d00fd  vpermilpd xmm15, xmm15, 0x00
000071c0d83d0103  vmovaps xmm7, [rsp+0x40]
000071c0d83d0109  movaps xmm11, xmm7
000071c0d83d010d  mulpd xmm11, xmm15
000071c0d83d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000071c0d83d0118  ptest xmm6, xmm6
000071c0d83d011d  jnz 0x000071C0D83D44A4
000071c0d83d0123  movaps xmm15, xmm10
000071c0d83d0127  addpd xmm15, xmm13
000071c0d83d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000071c0d83d0132  ptest xmm7, xmm7
000071c0d83d0137  jnz 0x000071C0D83D45E7
000071c0d83d013d  vmovaps xmm13, [rsp+0x60]
000071c0d83d0143  vpermilpd xmm13, xmm13, 0x00
000071c0d83d0149  vmovaps xmm7, [rsp+0x50]
000071c0d83d014f  movaps xmm10, xmm7
000071c0d83d0153  mulpd xmm10, xmm13
000071c0d83d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000071c0d83d015e  ptest xmm6, xmm6
000071c0d83d0163  jnz 0x000071C0D83D472B
000071c0d83d0169  movaps xmm13, xmm1
000071c0d83d016d  addpd xmm13, xmm8
000071c0d83d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000071c0d83d0178  ptest xmm7, xmm7
000071c0d83d017d  jnz 0x000071C0D83D486E
000071c0d83d0183  lea rax, [r14+0x70]
000071c0d83d0187  movups xmm1, [r13+rax*1]
000071c0d83d018d  movaps [r15+0x240], xmm1
000071c0d83d0195  movaps xmm8, xmm14
000071c0d83d0199  addpd xmm8, xmm9
000071c0d83d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000071c0d83d01a4  ptest xmm7, xmm7
000071c0d83d01a9  jnz 0x000071C0D83D49BB
000071c0d83d01af  movaps [r15+0x170], xmm8
000071c0d83d01b7  vmovaps xmm14, [rsp+0x70]
000071c0d83d01bd  vpermilpd xmm14, xmm14, 0x00
000071c0d83d01c3  movaps xmm9, xmm1
000071c0d83d01c7  mulpd xmm9, xmm14
000071c0d83d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000071c0d83d01d2  ptest xmm7, xmm7
000071c0d83d01d7  jnz 0x000071C0D83D4AFF
000071c0d83d01dd  vmovaps xmm1, [rsp+0x70]
000071c0d83d01e3  vpermilpd xmm1, xmm1, 0x00
000071c0d83d01e9  movaps xmm14, xmm4
000071c0d83d01ed  mulpd xmm14, xmm1
000071c0d83d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000071c0d83d01f8  ptest xmm7, xmm7
000071c0d83d01fd  jnz 0x000071C0D83D4C42
000071c0d83d0203  movaps [r15+0x180], xmm14
000071c0d83d020b  movaps xmm1, xmm12
000071c0d83d020f  addpd xmm1, xmm11
000071c0d83d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000071c0d83d0219  ptest xmm7, xmm7
000071c0d83d021e  jnz 0x000071C0D83D4D84
000071c0d83d0224  movaps [r15+0x210], xmm1
000071c0d83d022c  movups xmm12, [r13+r14*1]
000071c0d83d0232  lea rax, [r14+0x10]
000071c0d83d0236  movups xmm11, [r13+rax*1]
000071c0d83d023c  movaps [r15+0x230], xmm11
000071c0d83d0244  movaps xmm7, xmm15
000071c0d83d0248  addpd xmm7, xmm10
000071c0d83d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000071c0d83d0252  ptest xmm6, xmm6
000071c0d83d0257  jnz 0x000071C0D83D4EDA
000071c0d83d025d  movaps [r15+0x130], xmm7
000071c0d83d0265  vmovaps xmm15, [rsp+0x70]
000071c0d83d026b  vpermilpd xmm15, xmm15, 0x00
000071c0d83d0271  movaps xmm10, xmm11
000071c0d83d0275  mulpd xmm10, xmm15
000071c0d83d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000071c0d83d0280  ptest xmm6, xmm6
000071c0d83d0285  jnz 0x000071C0D83D501C
000071c0d83d028b  movaps [r15+0x220], xmm10
000071c0d83d0293  vmovaps xmm15, [rsp+0x70]
000071c0d83d0299  vpermilpd xmm15, xmm15, 0x00
000071c0d83d029f  movaps xmm11, xmm12
000071c0d83d02a3  mulpd xmm11, xmm15
000071c0d83d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000071c0d83d02ae  ptest xmm6, xmm6
000071c0d83d02b3  jnz 0x000071C0D83D5160
000071c0d83d02b9  movaps xmm15, xmm13
000071c0d83d02bd  addpd xmm15, xmm9
000071c0d83d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000071c0d83d02c8  ptest xmm12, xmm12
000071c0d83d02ce  jnz 0x000071C0D83D52A4
000071c0d83d02d4  movaps [r15+0x140], xmm15
000071c0d83d02dc  movaps xmm13, xmm8
000071c0d83d02e0  addpd xmm13, xmm14
000071c0d83d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000071c0d83d02eb  ptest xmm12, xmm12
000071c0d83d02f1  jnz 0x000071C0D83D53E8
000071c0d83d02f7  movaps [r15+0x150], xmm13
000071c0d83d02ff  movaps xmm14, xmm1
000071c0d83d0303  addpd xmm14, xmm10
000071c0d83d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000071c0d83d030e  ptest xmm12, xmm12
000071c0d83d0314  jnz 0x000071C0D83D552C
000071c0d83d031a  movaps [r15+0x160], xmm14
000071c0d83d0322  movaps xmm1, xmm7
000071c0d83d0325  addpd xmm1, xmm11
000071c0d83d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000071c0d83d032f  ptest xmm12, xmm12
000071c0d83d0335  jnz 0x000071C0D83D566F
000071c0d83d033b  movaps [r15+0x120], xmm1
000071c0d83d0343  mov eax, 0x430920
000071c0d83d0348  movups [r13+rax*1], xmm15
000071c0d83d034e  mov eax, 0x430930
000071c0d83d0353  movups [r13+rax*1], xmm13
000071c0d83d0359  mov eax, 0x430940
000071c0d83d035e  movups [r13+rax*1], xmm14
000071c0d83d0364  mov eax, 0x430950
000071c0d83d0369  movups [r13+rax*1], xmm1
000071c0d83d036f  mov eax, [r15+0x108]
000071c0d83d0376  sahf
000071c0d83d0377  jnz 0x000071C0D83D03A9
000071c0d83d0379  cmp dword ptr [r15+0x318], 0x00
000071c0d83d0381  jz 0x000071C0D83DB900
000071c0d83d0387  nop [rax+rax*1], ax
000071c0d83d0390  nop [rax+rax*1], eax
000071c0d83d0398  mov eax, 0x410444
000071c0d83d039d  mov [r15+0x100], rax
000071c0d83d03a4  jmp 0x000071C0D81FE110
000071c0d83d03a9  cmp dword ptr [r15+0x318], 0x00
000071c0d83d03b1  jz 0x000071C0D83D57E0
000071c0d83d03b7  nop [rax+rax*1], ax
000071c0d83d03c0  nop [rax+rax*1], eax
000071c0d83d03c8  mov eax, 0x410278
000071c0d83d03cd  mov [r15+0x100], rax
000071c0d83d03d4  jmp 0x000071C0D81FE110
000071c0d83d03d9  int3
000071c0d83d03da  call 0x000071C0D82B52F0
000071c0d83d03df  jmp 0x000071C0D83CF016
000071c0d83d03e4  call 0x000071C0D82C4620
000071c0d83d03e9  jmp 0x000071C0D83CF023
000071c0d83d03ee  call 0x000071C0D82C33A0
000071c0d83d03f3  jmp 0x000071C0D83CF035
000071c0d83d03f8  call 0x000071C0D82C2120
000071c0d83d03fd  jmp 0x000071C0D83CF03F
000071c0d83d0402  call 0x000071C0D82C0860
000071c0d83d0407  jmp 0x000071C0D83CF067
000071c0d83d040c  call 0x000071C0D82BF5F0
000071c0d83d0411  jmp 0x000071C0D83CF073
000071c0d83d0416  call 0x000071C0D82C0860
000071c0d83d041b  jmp 0x000071C0D83CF0A5
000071c0d83d0420  call 0x000071C0D82BF5F0
000071c0d83d0425  jmp 0x000071C0D83CF0B1
000071c0d83d042a  call 0x000071C0D82C4740
000071c0d83d042f  jmp 0x000071C0D83CF0BE
000071c0d83d0434  call 0x000071C0D82B5400
000071c0d83d0439  jmp 0x000071C0D83CF0CB
000071c0d83d043e  call 0x000071C0D82B52F0
000071c0d83d0443  jmp 0x000071C0D83CF0D8
000071c0d83d0448  call 0x000071C0D82C4620
000071c0d83d044d  jmp 0x000071C0D83CF0E5
000071c0d83d0452  call 0x000071C0D82C0860
000071c0d83d0457  jmp 0x000071C0D83CF10D
000071c0d83d045c  call 0x000071C0D82BF5F0
000071c0d83d0461  jmp 0x000071C0D83CF119
000071c0d83d0466  call 0x000071C0D8209D70
000071c0d83d046b  jmp 0x000071C0D83CF11F
000071c0d83d0470  call 0x000071C0D82BE9C0
000071c0d83d0475  jmp 0x000071C0D83CF129
000071c0d83d047a  call 0x000071C0D82C0860
000071c0d83d047f  jmp 0x000071C0D83CF151
000071c0d83d0484  call 0x000071C0D82BF5F0
000071c0d83d0489  jmp 0x000071C0D83CF15D
000071c0d83d048e  call 0x000071C0D82BD750
000071c0d83d0493  jmp 0x000071C0D83CF16A
000071c0d83d0498  call 0x000071C0D82BC4E0
000071c0d83d049d  jmp 0x000071C0D83CF177
000071c0d83d04a2  call 0x000071C0D82C4740
000071c0d83d04a7  jmp 0x000071C0D83CF184
000071c0d83d04ac  call 0x000071C0D82B5400
000071c0d83d04b1  jmp 0x000071C0D83CF191
000071c0d83d04b6  call 0x000071C0D82B52F0
000071c0d83d04bb  jmp 0x000071C0D83CF19E
000071c0d83d04c0  call 0x000071C0D82C4620
000071c0d83d04c5  jmp 0x000071C0D83CF1AB
000071c0d83d04ca  call 0x000071C0D82C0860
000071c0d83d04cf  jmp 0x000071C0D83CF1BE
000071c0d83d04d4  call 0x000071C0D82BB270
000071c0d83d04d9  jmp 0x000071C0D83CF1CB
000071c0d83d04de  call 0x000071C0D82BA000
000071c0d83d04e3  jmp 0x000071C0D83CF1D8
000071c0d83d04e8  call 0x000071C0D82B8D90
000071c0d83d04ed  jmp 0x000071C0D83CF1E5
000071c0d83d04f2  call 0x000071C0D82B8A20
000071c0d83d04f7  jmp 0x000071C0D83CF1F2
000071c0d83d04fc  call 0x000071C0D82B5400
000071c0d83d0501  jmp 0x000071C0D83CF1FC
000071c0d83d0506  call 0x000071C0D82C2240
000071c0d83d050b  jmp 0x000071C0D83CF206
000071c0d83d0510  call 0x000071C0D82B52F0
000071c0d83d0515  jmp 0x000071C0D83CF210
000071c0d83d051a  call 0x000071C0D82C2120
000071c0d83d051f  jmp 0x000071C0D83CF21A
000071c0d83d0524  call 0x000071C0D82B77B0
000071c0d83d0529  jmp 0x000071C0D83CF224
000071c0d83d052e  call 0x000071C0D82B6550
000071c0d83d0533  jmp 0x000071C0D83CF22E
000071c0d83d0538  call 0x000071C0D82BFD50
000071c0d83d053d  jmp 0x000071C0D83CF240
000071c0d83d0542  call 0x000071C0D82B8EA0
000071c0d83d0547  jmp 0x000071C0D83CF24A
000071c0d83d054c  call 0x000071C0D82BFC30
000071c0d83d0551  jmp 0x000071C0D83CF257
000071c0d83d0556  call 0x000071C0D82B8D90
000071c0d83d055b  jmp 0x000071C0D83CF264
000071c0d83d0560  call 0x000071C0D82C2240
000071c0d83d0565  jmp 0x000071C0D83CF271
000071c0d83d056a  call 0x000071C0D82B5400
000071c0d83d056f  jmp 0x000071C0D83CF27E
000071c0d83d0574  call 0x000071C0D82B52F0
000071c0d83d0579  jmp 0x000071C0D83CF28B
000071c0d83d057e  call 0x000071C0D82C2120
000071c0d83d0583  jmp 0x000071C0D83CF298
000071c0d83d0588  call 0x000071C0D82B52F0
000071c0d83d058d  jmp 0x000071C0D83CF2AB
000071c0d83d0592  call 0x000071C0D82B52F0
000071c0d83d0597  jmp 0x000071C0D83CF2BE
000071c0d83d059c  call 0x000071C0D82B52F0
000071c0d83d05a1  jmp 0x000071C0D83CF2D1
000071c0d83d05a6  call 0x000071C0D82B52F0
000071c0d83d05ab  jmp 0x000071C0D83CF2E4
000071c0d83d05b0  call 0x000071C0D82C2240
000071c0d83d05b5  jmp 0x000071C0D83CF2F9
000071c0d83d05ba  call 0x000071C0D82C2240
000071c0d83d05bf  jmp 0x000071C0D83CF30C
000071c0d83d05c4  call 0x000071C0D82C2120
000071c0d83d05c9  jmp 0x000071C0D83CF319
000071c0d83d05ce  call 0x000071C0D82B52F0
000071c0d83d05d3  jmp 0x000071C0D83CF32C
000071c0d83d05d8  call 0x000071C0D82B52F0
000071c0d83d05dd  jmp 0x000071C0D83CF34F
000071c0d83d05e2  call 0x000071C0D82B52F0
000071c0d83d05e7  jmp 0x000071C0D83CF362
000071c0d83d05ec  call 0x000071C0D81FF540
000071c0d83d05f1  jmp 0x000071C0D83CF380
000071c0d83d05f6  call 0x000071C0D8208C20
000071c0d83d05fb  jmp 0x000071C0D83CF38A
000071c0d83d0600  call 0x000071C0D82D6600
000071c0d83d0605  jmp 0x000071C0D83CF396
000071c0d83d060a  call 0x000071C0D81FF540
000071c0d83d060f  jmp 0x000071C0D83CF3A6
000071c0d83d0614  call 0x000071C0D82C0370
000071c0d83d0619  jmp 0x000071C0D83CF3D4
000071c0d83d061e  call 0x000071C0D82BF100
000071c0d83d0623  jmp 0x000071C0D83CF3DD
000071c0d83d0628  call 0x000071C0D82C0370
000071c0d83d062d  jmp 0x000071C0D83CF43B
000071c0d83d0632  call 0x000071C0D82BF100
000071c0d83d0637  jmp 0x000071C0D83CF444
000071c0d83d063c  call 0x000071C0D82C0370
000071c0d83d0641  jmp 0x000071C0D83CF48B
000071c0d83d0646  call 0x000071C0D82BF100
000071c0d83d064b  jmp 0x000071C0D83CF494
000071c0d83d0650  call 0x000071C0D820B720
000071c0d83d0655  jmp 0x000071C0D83CF4D7
000071c0d83d065a  call 0x000071C0D82B47C0
000071c0d83d065f  jmp 0x000071C0D83CF4EA
000071c0d83d0664  call 0x000071C0D8208B00
000071c0d83d0669  jmp 0x000071C0D83CF501
000071c0d83d066e  call 0x000071C0D81FF430
000071c0d83d0673  jmp 0x000071C0D83CF514
000071c0d83d0678  call 0x000071C0D81FF430
000071c0d83d067d  jmp 0x000071C0D83CF527
000071c0d83d0682  sub rsp, 0x08
000071c0d83d0686  push rax
000071c0d83d0687  push rcx
000071c0d83d0688  push rdx
000071c0d83d0689  push rdi
000071c0d83d068a  push rsi
000071c0d83d068b  push r8
000071c0d83d068d  push r9
000071c0d83d068f  push r10
000071c0d83d0691  push r11
000071c0d83d0693  sub rsp, 0xF0
000071c0d83d069a  vmovaps [rsp], xmm0
000071c0d83d069f  vmovaps [rsp+0x10], xmm2
000071c0d83d06a5  vmovaps [rsp+0x20], xmm3
000071c0d83d06ab  vmovaps [rsp+0x30], xmm4
000071c0d83d06b1  vmovaps [rsp+0x40], xmm5
000071c0d83d06b7  vmovaps [rsp+0x50], xmm6
000071c0d83d06bd  vmovaps [rsp+0x60], xmm7
000071c0d83d06c3  vmovaps [rsp+0x70], xmm8
000071c0d83d06c9  vmovaps [rsp+0x80], xmm9
000071c0d83d06d2  vmovaps [rsp+0x90], xmm10
000071c0d83d06db  vmovaps [rsp+0xA0], xmm11
000071c0d83d06e4  vmovaps [rsp+0xB0], xmm12
000071c0d83d06ed  vmovaps [rsp+0xC0], xmm13
000071c0d83d06f6  vmovaps [rsp+0xD0], xmm14
000071c0d83d06ff  vmovaps [rsp+0xE0], xmm15
000071c0d83d0708  sub rsp, 0x30
000071c0d83d070c  movaps [rsp], xmm1
000071c0d83d0710  movaps [rsp+0x10], xmm15
000071c0d83d0716  movaps [rsp+0x20], xmm14
000071c0d83d071c  lea rdi, [rsp]
000071c0d83d0720  mov esi, 0x00
000071c0d83d0725  mov rax, 0x5904ED15D530
000071c0d83d072f  call rax
000071c0d83d0731  movaps xmm1, [rsp]
000071c0d83d0735  add rsp, 0x30
000071c0d83d0739  vmovaps xmm0, [rsp]
000071c0d83d073e  vmovaps xmm2, [rsp+0x10]
000071c0d83d0744  vmovaps xmm3, [rsp+0x20]
000071c0d83d074a  vmovaps xmm4, [rsp+0x30]
000071c0d83d0750  vmovaps xmm5, [rsp+0x40]
000071c0d83d0756  vmovaps xmm6, [rsp+0x50]
000071c0d83d075c  vmovaps xmm7, [rsp+0x60]
000071c0d83d0762  vmovaps xmm8, [rsp+0x70]
000071c0d83d0768  vmovaps xmm9, [rsp+0x80]
000071c0d83d0771  vmovaps xmm10, [rsp+0x90]
000071c0d83d077a  vmovaps xmm11, [rsp+0xA0]
000071c0d83d0783  vmovaps xmm12, [rsp+0xB0]
000071c0d83d078c  vmovaps xmm13, [rsp+0xC0]
000071c0d83d0795  vmovaps xmm14, [rsp+0xD0]
000071c0d83d079e  vmovaps xmm15, [rsp+0xE0]
000071c0d83d07a7  add rsp, 0xF0
000071c0d83d07ae  pop r11
000071c0d83d07b0  pop r10
000071c0d83d07b2  pop r9
000071c0d83d07b4  pop r8
000071c0d83d07b6  pop rsi
000071c0d83d07b7  pop rdi
000071c0d83d07b8  pop rdx
000071c0d83d07b9  pop rcx
000071c0d83d07ba  pop rax
000071c0d83d07bb  add rsp, 0x08
000071c0d83d07bf  jmp 0x000071C0D83CF581
000071c0d83d07c4  sub rsp, 0x08
000071c0d83d07c8  push rax
000071c0d83d07c9  push rcx
000071c0d83d07ca  push rdx
000071c0d83d07cb  push rdi
000071c0d83d07cc  push rsi
000071c0d83d07cd  push r8
000071c0d83d07cf  push r9
000071c0d83d07d1  push r10
000071c0d83d07d3  push r11
000071c0d83d07d5  sub rsp, 0xF0
000071c0d83d07dc  vmovaps [rsp], xmm0
000071c0d83d07e1  vmovaps [rsp+0x10], xmm1
000071c0d83d07e7  vmovaps [rsp+0x20], xmm2
000071c0d83d07ed  vmovaps [rsp+0x30], xmm3
000071c0d83d07f3  vmovaps [rsp+0x40], xmm4
000071c0d83d07f9  vmovaps [rsp+0x50], xmm5
000071c0d83d07ff  vmovaps [rsp+0x60], xmm6
000071c0d83d0805  vmovaps [rsp+0x70], xmm7
000071c0d83d080b  vmovaps [rsp+0x80], xmm8
000071c0d83d0814  vmovaps [rsp+0x90], xmm9
000071c0d83d081d  vmovaps [rsp+0xA0], xmm10
000071c0d83d0826  vmovaps [rsp+0xB0], xmm11
000071c0d83d082f  vmovaps [rsp+0xC0], xmm12
000071c0d83d0838  vmovaps [rsp+0xD0], xmm14
000071c0d83d0841  vmovaps [rsp+0xE0], xmm15
000071c0d83d084a  sub rsp, 0x30
000071c0d83d084e  movaps [rsp], xmm13
000071c0d83d0853  movaps [rsp+0x10], xmm1
000071c0d83d0858  movaps [rsp+0x20], xmm14
000071c0d83d085e  lea rdi, [rsp]
000071c0d83d0862  mov esi, 0x00
000071c0d83d0867  mov rax, 0x5904ED15D530
000071c0d83d0871  call rax
000071c0d83d0873  movaps xmm13, [rsp]
000071c0d83d0878  add rsp, 0x30
000071c0d83d087c  vmovaps xmm0, [rsp]
000071c0d83d0881  vmovaps xmm1, [rsp+0x10]
000071c0d83d0887  vmovaps xmm2, [rsp+0x20]
000071c0d83d088d  vmovaps xmm3, [rsp+0x30]
000071c0d83d0893  vmovaps xmm4, [rsp+0x40]
000071c0d83d0899  vmovaps xmm5, [rsp+0x50]
000071c0d83d089f  vmovaps xmm6, [rsp+0x60]
000071c0d83d08a5  vmovaps xmm7, [rsp+0x70]
000071c0d83d08ab  vmovaps xmm8, [rsp+0x80]
000071c0d83d08b4  vmovaps xmm9, [rsp+0x90]
000071c0d83d08bd  vmovaps xmm10, [rsp+0xA0]
000071c0d83d08c6  vmovaps xmm11, [rsp+0xB0]
000071c0d83d08cf  vmovaps xmm12, [rsp+0xC0]
000071c0d83d08d8  vmovaps xmm14, [rsp+0xD0]
000071c0d83d08e1  vmovaps xmm15, [rsp+0xE0]
000071c0d83d08ea  add rsp, 0xF0
000071c0d83d08f1  pop r11
000071c0d83d08f3  pop r10
000071c0d83d08f5  pop r9
000071c0d83d08f7  pop r8
000071c0d83d08f9  pop rsi
000071c0d83d08fa  pop rdi
000071c0d83d08fb  pop rdx
000071c0d83d08fc  pop rcx
000071c0d83d08fd  pop rax
000071c0d83d08fe  add rsp, 0x08
000071c0d83d0902  jmp 0x000071C0D83CF5CF
000071c0d83d0907  sub rsp, 0x08
000071c0d83d090b  push rax
000071c0d83d090c  push rcx
000071c0d83d090d  push rdx
000071c0d83d090e  push rdi
000071c0d83d090f  push rsi
000071c0d83d0910  push r8
000071c0d83d0912  push r9
000071c0d83d0914  push r10
000071c0d83d0916  push r11
000071c0d83d0918  sub rsp, 0xF0
000071c0d83d091f  vmovaps [rsp], xmm0
000071c0d83d0924  vmovaps [rsp+0x10], xmm1
000071c0d83d092a  vmovaps [rsp+0x20], xmm2
000071c0d83d0930  vmovaps [rsp+0x30], xmm3
000071c0d83d0936  vmovaps [rsp+0x40], xmm4
000071c0d83d093c  vmovaps [rsp+0x50], xmm5
000071c0d83d0942  vmovaps [rsp+0x60], xmm6
000071c0d83d0948  vmovaps [rsp+0x70], xmm7
000071c0d83d094e  vmovaps [rsp+0x80], xmm8
000071c0d83d0957  vmovaps [rsp+0x90], xmm9
000071c0d83d0960  vmovaps [rsp+0xA0], xmm10
000071c0d83d0969  vmovaps [rsp+0xB0], xmm11
000071c0d83d0972  vmovaps [rsp+0xC0], xmm12
000071c0d83d097b  vmovaps [rsp+0xD0], xmm13
000071c0d83d0984  vmovaps [rsp+0xE0], xmm14
000071c0d83d098d  sub rsp, 0x30
000071c0d83d0991  movaps [rsp], xmm15
000071c0d83d0996  movaps [rsp+0x10], xmm14
000071c0d83d099c  movaps [rsp+0x20], xmm1
000071c0d83d09a1  lea rdi, [rsp]
000071c0d83d09a5  mov esi, 0x00
000071c0d83d09aa  mov rax, 0x5904ED15D530
000071c0d83d09b4  call rax
000071c0d83d09b6  movaps xmm15, [rsp]
000071c0d83d09bb  add rsp, 0x30
000071c0d83d09bf  vmovaps xmm0, [rsp]
000071c0d83d09c4  vmovaps xmm1, [rsp+0x10]
000071c0d83d09ca  vmovaps xmm2, [rsp+0x20]
000071c0d83d09d0  vmovaps xmm3, [rsp+0x30]
000071c0d83d09d6  vmovaps xmm4, [rsp+0x40]
000071c0d83d09dc  vmovaps xmm5, [rsp+0x50]
000071c0d83d09e2  vmovaps xmm6, [rsp+0x60]
000071c0d83d09e8  vmovaps xmm7, [rsp+0x70]
000071c0d83d09ee  vmovaps xmm8, [rsp+0x80]
000071c0d83d09f7  vmovaps xmm9, [rsp+0x90]
000071c0d83d0a00  vmovaps xmm10, [rsp+0xA0]
000071c0d83d0a09  vmovaps xmm11, [rsp+0xB0]
000071c0d83d0a12  vmovaps xmm12, [rsp+0xC0]
000071c0d83d0a1b  vmovaps xmm13, [rsp+0xD0]
000071c0d83d0a24  vmovaps xmm14, [rsp+0xE0]
000071c0d83d0a2d  add rsp, 0xF0
000071c0d83d0a34  pop r11
000071c0d83d0a36  pop r10
000071c0d83d0a38  pop r9
000071c0d83d0a3a  pop r8
000071c0d83d0a3c  pop rsi
000071c0d83d0a3d  pop rdi
000071c0d83d0a3e  pop rdx
000071c0d83d0a3f  pop rcx
000071c0d83d0a40  pop rax
000071c0d83d0a41  add rsp, 0x08
000071c0d83d0a45  jmp 0x000071C0D83CF617
000071c0d83d0a4a  sub rsp, 0x08
000071c0d83d0a4e  push rax
000071c0d83d0a4f  push rcx
000071c0d83d0a50  push rdx
000071c0d83d0a51  push rdi
000071c0d83d0a52  push rsi
000071c0d83d0a53  push r8
000071c0d83d0a55  push r9
000071c0d83d0a57  push r10
000071c0d83d0a59  push r11
000071c0d83d0a5b  sub rsp, 0xF0
000071c0d83d0a62  vmovaps [rsp], xmm0
000071c0d83d0a67  vmovaps [rsp+0x10], xmm2
000071c0d83d0a6d  vmovaps [rsp+0x20], xmm3
000071c0d83d0a73  vmovaps [rsp+0x30], xmm4
000071c0d83d0a79  vmovaps [rsp+0x40], xmm5
000071c0d83d0a7f  vmovaps [rsp+0x50], xmm6
000071c0d83d0a85  vmovaps [rsp+0x60], xmm7
000071c0d83d0a8b  vmovaps [rsp+0x70], xmm8
000071c0d83d0a91  vmovaps [rsp+0x80], xmm9
000071c0d83d0a9a  vmovaps [rsp+0x90], xmm10
000071c0d83d0aa3  vmovaps [rsp+0xA0], xmm11
000071c0d83d0aac  vmovaps [rsp+0xB0], xmm12
000071c0d83d0ab5  vmovaps [rsp+0xC0], xmm13
000071c0d83d0abe  vmovaps [rsp+0xD0], xmm14
000071c0d83d0ac7  vmovaps [rsp+0xE0], xmm15
000071c0d83d0ad0  sub rsp, 0x30
000071c0d83d0ad4  movaps [rsp], xmm1
000071c0d83d0ad8  movaps [rsp+0x10], xmm14
000071c0d83d0ade  movaps [rsp+0x20], xmm10
000071c0d83d0ae4  lea rdi, [rsp]
000071c0d83d0ae8  mov esi, 0x00
000071c0d83d0aed  mov rax, 0x5904ED15D530
000071c0d83d0af7  call rax
000071c0d83d0af9  movaps xmm1, [rsp]
000071c0d83d0afd  add rsp, 0x30
000071c0d83d0b01  vmovaps xmm0, [rsp]
000071c0d83d0b06  vmovaps xmm2, [rsp+0x10]
000071c0d83d0b0c  vmovaps xmm3, [rsp+0x20]
000071c0d83d0b12  vmovaps xmm4, [rsp+0x30]
000071c0d83d0b18  vmovaps xmm5, [rsp+0x40]
000071c0d83d0b1e  vmovaps xmm6, [rsp+0x50]
000071c0d83d0b24  vmovaps xmm7, [rsp+0x60]
000071c0d83d0b2a  vmovaps xmm8, [rsp+0x70]
000071c0d83d0b30  vmovaps xmm9, [rsp+0x80]
000071c0d83d0b39  vmovaps xmm10, [rsp+0x90]
000071c0d83d0b42  vmovaps xmm11, [rsp+0xA0]
000071c0d83d0b4b  vmovaps xmm12, [rsp+0xB0]
000071c0d83d0b54  vmovaps xmm13, [rsp+0xC0]
000071c0d83d0b5d  vmovaps xmm14, [rsp+0xD0]
000071c0d83d0b66  vmovaps xmm15, [rsp+0xE0]
000071c0d83d0b6f  add rsp, 0xF0
000071c0d83d0b76  pop r11
000071c0d83d0b78  pop r10
000071c0d83d0b7a  pop r9
000071c0d83d0b7c  pop r8
000071c0d83d0b7e  pop rsi
000071c0d83d0b7f  pop rdi
000071c0d83d0b80  pop rdx
000071c0d83d0b81  pop rcx
000071c0d83d0b82  pop rax
000071c0d83d0b83  add rsp, 0x08
000071c0d83d0b87  jmp 0x000071C0D83CF631
000071c0d83d0b8c  sub rsp, 0x08
000071c0d83d0b90  push rax
000071c0d83d0b91  push rcx
000071c0d83d0b92  push rdx
000071c0d83d0b93  push rdi
000071c0d83d0b94  push rsi
000071c0d83d0b95  push r8
000071c0d83d0b97  push r9
000071c0d83d0b99  push r10
000071c0d83d0b9b  push r11
000071c0d83d0b9d  sub rsp, 0xF0
000071c0d83d0ba4  vmovaps [rsp], xmm0
000071c0d83d0ba9  vmovaps [rsp+0x10], xmm1
000071c0d83d0baf  vmovaps [rsp+0x20], xmm2
000071c0d83d0bb5  vmovaps [rsp+0x30], xmm3
000071c0d83d0bbb  vmovaps [rsp+0x40], xmm4
000071c0d83d0bc1  vmovaps [rsp+0x50], xmm5
000071c0d83d0bc7  vmovaps [rsp+0x60], xmm6
000071c0d83d0bcd  vmovaps [rsp+0x70], xmm7
000071c0d83d0bd3  vmovaps [rsp+0x80], xmm8
000071c0d83d0bdc  vmovaps [rsp+0x90], xmm9
000071c0d83d0be5  vmovaps [rsp+0xA0], xmm10
000071c0d83d0bee  vmovaps [rsp+0xB0], xmm11
000071c0d83d0bf7  vmovaps [rsp+0xC0], xmm12
000071c0d83d0c00  vmovaps [rsp+0xD0], xmm14
000071c0d83d0c09  vmovaps [rsp+0xE0], xmm15
000071c0d83d0c12  sub rsp, 0x30
000071c0d83d0c16  movaps [rsp], xmm13
000071c0d83d0c1b  movaps [rsp+0x10], xmm14
000071c0d83d0c21  movaps [rsp+0x20], xmm2
000071c0d83d0c26  lea rdi, [rsp]
000071c0d83d0c2a  mov esi, 0x00
000071c0d83d0c2f  mov rax, 0x5904ED15D530
000071c0d83d0c39  call rax
000071c0d83d0c3b  movaps xmm13, [rsp]
000071c0d83d0c40  add rsp, 0x30
000071c0d83d0c44  vmovaps xmm0, [rsp]
000071c0d83d0c49  vmovaps xmm1, [rsp+0x10]
000071c0d83d0c4f  vmovaps xmm2, [rsp+0x20]
000071c0d83d0c55  vmovaps xmm3, [rsp+0x30]
000071c0d83d0c5b  vmovaps xmm4, [rsp+0x40]
000071c0d83d0c61  vmovaps xmm5, [rsp+0x50]
000071c0d83d0c67  vmovaps xmm6, [rsp+0x60]
000071c0d83d0c6d  vmovaps xmm7, [rsp+0x70]
000071c0d83d0c73  vmovaps xmm8, [rsp+0x80]
000071c0d83d0c7c  vmovaps xmm9, [rsp+0x90]
000071c0d83d0c85  vmovaps xmm10, [rsp+0xA0]
000071c0d83d0c8e  vmovaps xmm11, [rsp+0xB0]
000071c0d83d0c97  vmovaps xmm12, [rsp+0xC0]
000071c0d83d0ca0  vmovaps xmm14, [rsp+0xD0]
000071c0d83d0ca9  vmovaps xmm15, [rsp+0xE0]
000071c0d83d0cb2  add rsp, 0xF0
000071c0d83d0cb9  pop r11
000071c0d83d0cbb  pop r10
000071c0d83d0cbd  pop r9
000071c0d83d0cbf  pop r8
000071c0d83d0cc1  pop rsi
000071c0d83d0cc2  pop rdi
000071c0d83d0cc3  pop rdx
000071c0d83d0cc4  pop rcx
000071c0d83d0cc5  pop rax
000071c0d83d0cc6  add rsp, 0x08
000071c0d83d0cca  jmp 0x000071C0D83CF64C
000071c0d83d0ccf  sub rsp, 0x08
000071c0d83d0cd3  push rax
000071c0d83d0cd4  push rcx
000071c0d83d0cd5  push rdx
000071c0d83d0cd6  push rdi
000071c0d83d0cd7  push rsi
000071c0d83d0cd8  push r8
000071c0d83d0cda  push r9
000071c0d83d0cdc  push r10
000071c0d83d0cde  push r11
000071c0d83d0ce0  sub rsp, 0xF0
000071c0d83d0ce7  vmovaps [rsp], xmm0
000071c0d83d0cec  vmovaps [rsp+0x10], xmm2
000071c0d83d0cf2  vmovaps [rsp+0x20], xmm3
000071c0d83d0cf8  vmovaps [rsp+0x30], xmm4
000071c0d83d0cfe  vmovaps [rsp+0x40], xmm5
000071c0d83d0d04  vmovaps [rsp+0x50], xmm6
000071c0d83d0d0a  vmovaps [rsp+0x60], xmm7
000071c0d83d0d10  vmovaps [rsp+0x70], xmm8
000071c0d83d0d16  vmovaps [rsp+0x80], xmm9
000071c0d83d0d1f  vmovaps [rsp+0x90], xmm10
000071c0d83d0d28  vmovaps [rsp+0xA0], xmm11
000071c0d83d0d31  vmovaps [rsp+0xB0], xmm12
000071c0d83d0d3a  vmovaps [rsp+0xC0], xmm13
000071c0d83d0d43  vmovaps [rsp+0xD0], xmm14
000071c0d83d0d4c  vmovaps [rsp+0xE0], xmm15
000071c0d83d0d55  sub rsp, 0x30
000071c0d83d0d59  movaps [rsp], xmm1
000071c0d83d0d5d  movaps [rsp+0x10], xmm10
000071c0d83d0d63  movaps [rsp+0x20], xmm2
000071c0d83d0d68  lea rdi, [rsp]
000071c0d83d0d6c  mov esi, 0x00
000071c0d83d0d71  mov rax, 0x5904ED15D530
000071c0d83d0d7b  call rax
000071c0d83d0d7d  movaps xmm1, [rsp]
000071c0d83d0d81  add rsp, 0x30
000071c0d83d0d85  vmovaps xmm0, [rsp]
000071c0d83d0d8a  vmovaps xmm2, [rsp+0x10]
000071c0d83d0d90  vmovaps xmm3, [rsp+0x20]
000071c0d83d0d96  vmovaps xmm4, [rsp+0x30]
000071c0d83d0d9c  vmovaps xmm5, [rsp+0x40]
000071c0d83d0da2  vmovaps xmm6, [rsp+0x50]
000071c0d83d0da8  vmovaps xmm7, [rsp+0x60]
000071c0d83d0dae  vmovaps xmm8, [rsp+0x70]
000071c0d83d0db4  vmovaps xmm9, [rsp+0x80]
000071c0d83d0dbd  vmovaps xmm10, [rsp+0x90]
000071c0d83d0dc6  vmovaps xmm11, [rsp+0xA0]
000071c0d83d0dcf  vmovaps xmm12, [rsp+0xB0]
000071c0d83d0dd8  vmovaps xmm13, [rsp+0xC0]
000071c0d83d0de1  vmovaps xmm14, [rsp+0xD0]
000071c0d83d0dea  vmovaps xmm15, [rsp+0xE0]
000071c0d83d0df3  add rsp, 0xF0
000071c0d83d0dfa  pop r11
000071c0d83d0dfc  pop r10
000071c0d83d0dfe  pop r9
000071c0d83d0e00  pop r8
000071c0d83d0e02  pop rsi
000071c0d83d0e03  pop rdi
000071c0d83d0e04  pop rdx
000071c0d83d0e05  pop rcx
000071c0d83d0e06  pop rax
000071c0d83d0e07  add rsp, 0x08
000071c0d83d0e0b  jmp 0x000071C0D83CF6B4
000071c0d83d0e10  sub rsp, 0x08
000071c0d83d0e14  push rax
000071c0d83d0e15  push rcx
000071c0d83d0e16  push rdx
000071c0d83d0e17  push rdi
000071c0d83d0e18  push rsi
000071c0d83d0e19  push r8
000071c0d83d0e1b  push r9
000071c0d83d0e1d  push r10
000071c0d83d0e1f  push r11
000071c0d83d0e21  sub rsp, 0xF0
000071c0d83d0e28  vmovaps [rsp], xmm0
000071c0d83d0e2d  vmovaps [rsp+0x10], xmm1
000071c0d83d0e33  vmovaps [rsp+0x20], xmm2
000071c0d83d0e39  vmovaps [rsp+0x30], xmm3
000071c0d83d0e3f  vmovaps [rsp+0x40], xmm4
000071c0d83d0e45  vmovaps [rsp+0x50], xmm5
000071c0d83d0e4b  vmovaps [rsp+0x60], xmm6
000071c0d83d0e51  vmovaps [rsp+0x70], xmm7
000071c0d83d0e57  vmovaps [rsp+0x80], xmm8
000071c0d83d0e60  vmovaps [rsp+0x90], xmm9
000071c0d83d0e69  vmovaps [rsp+0xA0], xmm10
000071c0d83d0e72  vmovaps [rsp+0xB0], xmm11
000071c0d83d0e7b  vmovaps [rsp+0xC0], xmm12
000071c0d83d0e84  vmovaps [rsp+0xD0], xmm13
000071c0d83d0e8d  vmovaps [rsp+0xE0], xmm14
000071c0d83d0e96  sub rsp, 0x30
000071c0d83d0e9a  movaps [rsp], xmm15
000071c0d83d0e9f  movaps [rsp+0x10], xmm10
000071c0d83d0ea5  movaps [rsp+0x20], xmm2
000071c0d83d0eaa  lea rdi, [rsp]
000071c0d83d0eae  mov esi, 0x00
000071c0d83d0eb3  mov rax, 0x5904ED15D530
000071c0d83d0ebd  call rax
000071c0d83d0ebf  movaps xmm15, [rsp]
000071c0d83d0ec4  add rsp, 0x30
000071c0d83d0ec8  vmovaps xmm0, [rsp]
000071c0d83d0ecd  vmovaps xmm1, [rsp+0x10]
000071c0d83d0ed3  vmovaps xmm2, [rsp+0x20]
000071c0d83d0ed9  vmovaps xmm3, [rsp+0x30]
000071c0d83d0edf  vmovaps xmm4, [rsp+0x40]
000071c0d83d0ee5  vmovaps xmm5, [rsp+0x50]
000071c0d83d0eeb  vmovaps xmm6, [rsp+0x60]
000071c0d83d0ef1  vmovaps xmm7, [rsp+0x70]
000071c0d83d0ef7  vmovaps xmm8, [rsp+0x80]
000071c0d83d0f00  vmovaps xmm9, [rsp+0x90]
000071c0d83d0f09  vmovaps xmm10, [rsp+0xA0]
000071c0d83d0f12  vmovaps xmm11, [rsp+0xB0]
000071c0d83d0f1b  vmovaps xmm12, [rsp+0xC0]
000071c0d83d0f24  vmovaps xmm13, [rsp+0xD0]
000071c0d83d0f2d  vmovaps xmm14, [rsp+0xE0]
000071c0d83d0f36  add rsp, 0xF0
000071c0d83d0f3d  pop r11
000071c0d83d0f3f  pop r10
000071c0d83d0f41  pop r9
000071c0d83d0f43  pop r8
000071c0d83d0f45  pop rsi
000071c0d83d0f46  pop rdi
000071c0d83d0f47  pop rdx
000071c0d83d0f48  pop rcx
000071c0d83d0f49  pop rax
000071c0d83d0f4a  add rsp, 0x08
000071c0d83d0f4e  jmp 0x000071C0D83CF706
000071c0d83d0f53  sub rsp, 0x08
000071c0d83d0f57  push rax
000071c0d83d0f58  push rcx
000071c0d83d0f59  push rdx
000071c0d83d0f5a  push rdi
000071c0d83d0f5b  push rsi
000071c0d83d0f5c  push r8
000071c0d83d0f5e  push r9
000071c0d83d0f60  push r10
000071c0d83d0f62  push r11
000071c0d83d0f64  sub rsp, 0xF0
000071c0d83d0f6b  vmovaps [rsp], xmm0
000071c0d83d0f70  vmovaps [rsp+0x10], xmm2
000071c0d83d0f76  vmovaps [rsp+0x20], xmm3
000071c0d83d0f7c  vmovaps [rsp+0x30], xmm4
000071c0d83d0f82  vmovaps [rsp+0x40], xmm5
000071c0d83d0f88  vmovaps [rsp+0x50], xmm6
000071c0d83d0f8e  vmovaps [rsp+0x60], xmm7
000071c0d83d0f94  vmovaps [rsp+0x70], xmm8
000071c0d83d0f9a  vmovaps [rsp+0x80], xmm9
000071c0d83d0fa3  vmovaps [rsp+0x90], xmm10
000071c0d83d0fac  vmovaps [rsp+0xA0], xmm11
000071c0d83d0fb5  vmovaps [rsp+0xB0], xmm12
000071c0d83d0fbe  vmovaps [rsp+0xC0], xmm13
000071c0d83d0fc7  vmovaps [rsp+0xD0], xmm14
000071c0d83d0fd0  vmovaps [rsp+0xE0], xmm15
000071c0d83d0fd9  sub rsp, 0x30
000071c0d83d0fdd  movaps [rsp], xmm1
000071c0d83d0fe1  movaps [rsp+0x10], xmm10
000071c0d83d0fe7  movaps [rsp+0x20], xmm12
000071c0d83d0fed  lea rdi, [rsp]
000071c0d83d0ff1  mov esi, 0x00
000071c0d83d0ff6  mov rax, 0x5904ED15D530
000071c0d83d1000  call rax
000071c0d83d1002  movaps xmm1, [rsp]
000071c0d83d1006  add rsp, 0x30
000071c0d83d100a  vmovaps xmm0, [rsp]
000071c0d83d100f  vmovaps xmm2, [rsp+0x10]
000071c0d83d1015  vmovaps xmm3, [rsp+0x20]
000071c0d83d101b  vmovaps xmm4, [rsp+0x30]
000071c0d83d1021  vmovaps xmm5, [rsp+0x40]
000071c0d83d1027  vmovaps xmm6, [rsp+0x50]
000071c0d83d102d  vmovaps xmm7, [rsp+0x60]
000071c0d83d1033  vmovaps xmm8, [rsp+0x70]
000071c0d83d1039  vmovaps xmm9, [rsp+0x80]
000071c0d83d1042  vmovaps xmm10, [rsp+0x90]
000071c0d83d104b  vmovaps xmm11, [rsp+0xA0]
000071c0d83d1054  vmovaps xmm12, [rsp+0xB0]
000071c0d83d105d  vmovaps xmm13, [rsp+0xC0]
000071c0d83d1066  vmovaps xmm14, [rsp+0xD0]
000071c0d83d106f  vmovaps xmm15, [rsp+0xE0]
000071c0d83d1078  add rsp, 0xF0
000071c0d83d107f  pop r11
000071c0d83d1081  pop r10
000071c0d83d1083  pop r9
000071c0d83d1085  pop r8
000071c0d83d1087  pop rsi
000071c0d83d1088  pop rdi
000071c0d83d1089  pop rdx
000071c0d83d108a  pop rcx
000071c0d83d108b  pop rax
000071c0d83d108c  add rsp, 0x08
000071c0d83d1090  jmp 0x000071C0D83CF732
000071c0d83d1095  sub rsp, 0x08
000071c0d83d1099  push rax
000071c0d83d109a  push rcx
000071c0d83d109b  push rdx
000071c0d83d109c  push rdi
000071c0d83d109d  push rsi
000071c0d83d109e  push r8
000071c0d83d10a0  push r9
000071c0d83d10a2  push r10
000071c0d83d10a4  push r11
000071c0d83d10a6  sub rsp, 0xF0
000071c0d83d10ad  vmovaps [rsp], xmm0
000071c0d83d10b2  vmovaps [rsp+0x10], xmm1
000071c0d83d10b8  vmovaps [rsp+0x20], xmm2
000071c0d83d10be  vmovaps [rsp+0x30], xmm3
000071c0d83d10c4  vmovaps [rsp+0x40], xmm4
000071c0d83d10ca  vmovaps [rsp+0x50], xmm5
000071c0d83d10d0  vmovaps [rsp+0x60], xmm6
000071c0d83d10d6  vmovaps [rsp+0x70], xmm7
000071c0d83d10dc  vmovaps [rsp+0x80], xmm8
000071c0d83d10e5  vmovaps [rsp+0x90], xmm9
000071c0d83d10ee  vmovaps [rsp+0xA0], xmm10
000071c0d83d10f7  vmovaps [rsp+0xB0], xmm11
000071c0d83d1100  vmovaps [rsp+0xC0], xmm12
000071c0d83d1109  vmovaps [rsp+0xD0], xmm13
000071c0d83d1112  vmovaps [rsp+0xE0], xmm14
000071c0d83d111b  sub rsp, 0x30
000071c0d83d111f  movaps [rsp], xmm15
000071c0d83d1124  movaps [rsp+0x10], xmm10
000071c0d83d112a  movaps [rsp+0x20], xmm12
000071c0d83d1130  lea rdi, [rsp]
000071c0d83d1134  mov esi, 0x00
000071c0d83d1139  mov rax, 0x5904ED15D530
000071c0d83d1143  call rax
000071c0d83d1145  movaps xmm15, [rsp]
000071c0d83d114a  add rsp, 0x30
000071c0d83d114e  vmovaps xmm0, [rsp]
000071c0d83d1153  vmovaps xmm1, [rsp+0x10]
000071c0d83d1159  vmovaps xmm2, [rsp+0x20]
000071c0d83d115f  vmovaps xmm3, [rsp+0x30]
000071c0d83d1165  vmovaps xmm4, [rsp+0x40]
000071c0d83d116b  vmovaps xmm5, [rsp+0x50]
000071c0d83d1171  vmovaps xmm6, [rsp+0x60]
000071c0d83d1177  vmovaps xmm7, [rsp+0x70]
000071c0d83d117d  vmovaps xmm8, [rsp+0x80]
000071c0d83d1186  vmovaps xmm9, [rsp+0x90]
000071c0d83d118f  vmovaps xmm10, [rsp+0xA0]
000071c0d83d1198  vmovaps xmm11, [rsp+0xB0]
000071c0d83d11a1  vmovaps xmm12, [rsp+0xC0]
000071c0d83d11aa  vmovaps xmm13, [rsp+0xD0]
000071c0d83d11b3  vmovaps xmm14, [rsp+0xE0]
000071c0d83d11bc  add rsp, 0xF0
000071c0d83d11c3  pop r11
000071c0d83d11c5  pop r10
000071c0d83d11c7  pop r9
000071c0d83d11c9  pop r8
000071c0d83d11cb  pop rsi
000071c0d83d11cc  pop rdi
000071c0d83d11cd  pop rdx
000071c0d83d11ce  pop rcx
000071c0d83d11cf  pop rax
000071c0d83d11d0  add rsp, 0x08
000071c0d83d11d4  jmp 0x000071C0D83CF75E
000071c0d83d11d9  call 0x000071C0D81FF430
000071c0d83d11de  jmp 0x000071C0D83CF7EE
000071c0d83d11e3  call 0x000071C0D81FF430
000071c0d83d11e8  jmp 0x000071C0D83CF801
000071c0d83d11ed  sub rsp, 0x08
000071c0d83d11f1  push rax
000071c0d83d11f2  push rcx
000071c0d83d11f3  push rdx
000071c0d83d11f4  push rdi
000071c0d83d11f5  push rsi
000071c0d83d11f6  push r8
000071c0d83d11f8  push r9
000071c0d83d11fa  push r10
000071c0d83d11fc  push r11
000071c0d83d11fe  sub rsp, 0xF0
000071c0d83d1205  vmovaps [rsp], xmm0
000071c0d83d120a  vmovaps [rsp+0x10], xmm2
000071c0d83d1210  vmovaps [rsp+0x20], xmm3
000071c0d83d1216  vmovaps [rsp+0x30], xmm4
000071c0d83d121c  vmovaps [rsp+0x40], xmm5
000071c0d83d1222  vmovaps [rsp+0x50], xmm6
000071c0d83d1228  vmovaps [rsp+0x60], xmm7
000071c0d83d122e  vmovaps [rsp+0x70], xmm8
000071c0d83d1234  vmovaps [rsp+0x80], xmm9
000071c0d83d123d  vmovaps [rsp+0x90], xmm10
000071c0d83d1246  vmovaps [rsp+0xA0], xmm11
000071c0d83d124f  vmovaps [rsp+0xB0], xmm12
000071c0d83d1258  vmovaps [rsp+0xC0], xmm13
000071c0d83d1261  vmovaps [rsp+0xD0], xmm14
000071c0d83d126a  vmovaps [rsp+0xE0], xmm15
000071c0d83d1273  sub rsp, 0x30
000071c0d83d1277  movaps [rsp], xmm1
000071c0d83d127b  movaps [rsp+0x10], xmm13
000071c0d83d1281  movaps [rsp+0x20], xmm2
000071c0d83d1286  lea rdi, [rsp]
000071c0d83d128a  mov esi, 0x00
000071c0d83d128f  mov rax, 0x5904ED15D530
000071c0d83d1299  call rax
000071c0d83d129b  movaps xmm1, [rsp]
000071c0d83d129f  add rsp, 0x30
000071c0d83d12a3  vmovaps xmm0, [rsp]
000071c0d83d12a8  vmovaps xmm2, [rsp+0x10]
000071c0d83d12ae  vmovaps xmm3, [rsp+0x20]
000071c0d83d12b4  vmovaps xmm4, [rsp+0x30]
000071c0d83d12ba  vmovaps xmm5, [rsp+0x40]
000071c0d83d12c0  vmovaps xmm6, [rsp+0x50]
000071c0d83d12c6  vmovaps xmm7, [rsp+0x60]
000071c0d83d12cc  vmovaps xmm8, [rsp+0x70]
000071c0d83d12d2  vmovaps xmm9, [rsp+0x80]
000071c0d83d12db  vmovaps xmm10, [rsp+0x90]
000071c0d83d12e4  vmovaps xmm11, [rsp+0xA0]
000071c0d83d12ed  vmovaps xmm12, [rsp+0xB0]
000071c0d83d12f6  vmovaps xmm13, [rsp+0xC0]
000071c0d83d12ff  vmovaps xmm14, [rsp+0xD0]
000071c0d83d1308  vmovaps xmm15, [rsp+0xE0]
000071c0d83d1311  add rsp, 0xF0
000071c0d83d1318  pop r11
000071c0d83d131a  pop r10
000071c0d83d131c  pop r9
000071c0d83d131e  pop r8
000071c0d83d1320  pop rsi
000071c0d83d1321  pop rdi
000071c0d83d1322  pop rdx
000071c0d83d1323  pop rcx
000071c0d83d1324  pop rax
000071c0d83d1325  add rsp, 0x08
000071c0d83d1329  jmp 0x000071C0D83CF82C
000071c0d83d132e  call 0x000071C0D820E760
000071c0d83d1333  jmp 0x000071C0D83CF839
000071c0d83d1338  sub rsp, 0x08
000071c0d83d133c  push rax
000071c0d83d133d  push rcx
000071c0d83d133e  push rdx
000071c0d83d133f  push rdi
000071c0d83d1340  push rsi
000071c0d83d1341  push r8
000071c0d83d1343  push r9
000071c0d83d1345  push r10
000071c0d83d1347  push r11
000071c0d83d1349  sub rsp, 0xF0
000071c0d83d1350  vmovaps [rsp], xmm0
000071c0d83d1355  vmovaps [rsp+0x10], xmm1
000071c0d83d135b  vmovaps [rsp+0x20], xmm2
000071c0d83d1361  vmovaps [rsp+0x30], xmm3
000071c0d83d1367  vmovaps [rsp+0x40], xmm4
000071c0d83d136d  vmovaps [rsp+0x50], xmm5
000071c0d83d1373  vmovaps [rsp+0x60], xmm6
000071c0d83d1379  vmovaps [rsp+0x70], xmm7
000071c0d83d137f  vmovaps [rsp+0x80], xmm8
000071c0d83d1388  vmovaps [rsp+0x90], xmm9
000071c0d83d1391  vmovaps [rsp+0xA0], xmm10
000071c0d83d139a  vmovaps [rsp+0xB0], xmm11
000071c0d83d13a3  vmovaps [rsp+0xC0], xmm12
000071c0d83d13ac  vmovaps [rsp+0xD0], xmm14
000071c0d83d13b5  vmovaps [rsp+0xE0], xmm15
000071c0d83d13be  sub rsp, 0x30
000071c0d83d13c2  movaps [rsp], xmm13
000071c0d83d13c7  movaps [rsp+0x10], xmm2
000071c0d83d13cc  movaps [rsp+0x20], xmm1
000071c0d83d13d1  lea rdi, [rsp]
000071c0d83d13d5  mov esi, 0x00
000071c0d83d13da  mov rax, 0x5904ED15D530
000071c0d83d13e4  call rax
000071c0d83d13e6  movaps xmm13, [rsp]
000071c0d83d13eb  add rsp, 0x30
000071c0d83d13ef  vmovaps xmm0, [rsp]
000071c0d83d13f4  vmovaps xmm1, [rsp+0x10]
000071c0d83d13fa  vmovaps xmm2, [rsp+0x20]
000071c0d83d1400  vmovaps xmm3, [rsp+0x30]
000071c0d83d1406  vmovaps xmm4, [rsp+0x40]
000071c0d83d140c  vmovaps xmm5, [rsp+0x50]
000071c0d83d1412  vmovaps xmm6, [rsp+0x60]
000071c0d83d1418  vmovaps xmm7, [rsp+0x70]
000071c0d83d141e  vmovaps xmm8, [rsp+0x80]
000071c0d83d1427  vmovaps xmm9, [rsp+0x90]
000071c0d83d1430  vmovaps xmm10, [rsp+0xA0]
000071c0d83d1439  vmovaps xmm11, [rsp+0xB0]
000071c0d83d1442  vmovaps xmm12, [rsp+0xC0]
000071c0d83d144b  vmovaps xmm14, [rsp+0xD0]
000071c0d83d1454  vmovaps xmm15, [rsp+0xE0]
000071c0d83d145d  add rsp, 0xF0
000071c0d83d1464  pop r11
000071c0d83d1466  pop r10
000071c0d83d1468  pop r9
000071c0d83d146a  pop r8
000071c0d83d146c  pop rsi
000071c0d83d146d  pop rdi
000071c0d83d146e  pop rdx
000071c0d83d146f  pop rcx
000071c0d83d1470  pop rax
000071c0d83d1471  add rsp, 0x08
000071c0d83d1475  jmp 0x000071C0D83CF878
000071c0d83d147a  sub rsp, 0x08
000071c0d83d147e  push rax
000071c0d83d147f  push rcx
000071c0d83d1480  push rdx
000071c0d83d1481  push rdi
000071c0d83d1482  push rsi
000071c0d83d1483  push r8
000071c0d83d1485  push r9
000071c0d83d1487  push r10
000071c0d83d1489  push r11
000071c0d83d148b  sub rsp, 0xF0
000071c0d83d1492  vmovaps [rsp], xmm0
000071c0d83d1497  vmovaps [rsp+0x10], xmm2
000071c0d83d149d  vmovaps [rsp+0x20], xmm3
000071c0d83d14a3  vmovaps [rsp+0x30], xmm4
000071c0d83d14a9  vmovaps [rsp+0x40], xmm5
000071c0d83d14af  vmovaps [rsp+0x50], xmm6
000071c0d83d14b5  vmovaps [rsp+0x60], xmm7
000071c0d83d14bb  vmovaps [rsp+0x70], xmm8
000071c0d83d14c1  vmovaps [rsp+0x80], xmm9
000071c0d83d14ca  vmovaps [rsp+0x90], xmm10
000071c0d83d14d3  vmovaps [rsp+0xA0], xmm11
000071c0d83d14dc  vmovaps [rsp+0xB0], xmm12
000071c0d83d14e5  vmovaps [rsp+0xC0], xmm13
000071c0d83d14ee  vmovaps [rsp+0xD0], xmm14
000071c0d83d14f7  vmovaps [rsp+0xE0], xmm15
000071c0d83d1500  sub rsp, 0x30
000071c0d83d1504  movaps [rsp], xmm1
000071c0d83d1508  movaps [rsp+0x10], xmm15
000071c0d83d150e  movaps [rsp+0x20], xmm2
000071c0d83d1513  lea rdi, [rsp]
000071c0d83d1517  mov esi, 0x00
000071c0d83d151c  mov rax, 0x5904ED15D530
000071c0d83d1526  call rax
000071c0d83d1528  movaps xmm1, [rsp]
000071c0d83d152c  add rsp, 0x30
000071c0d83d1530  vmovaps xmm0, [rsp]
000071c0d83d1535  vmovaps xmm2, [rsp+0x10]
000071c0d83d153b  vmovaps xmm3, [rsp+0x20]
000071c0d83d1541  vmovaps xmm4, [rsp+0x30]
000071c0d83d1547  vmovaps xmm5, [rsp+0x40]
000071c0d83d154d  vmovaps xmm6, [rsp+0x50]
000071c0d83d1553  vmovaps xmm7, [rsp+0x60]
000071c0d83d1559  vmovaps xmm8, [rsp+0x70]
000071c0d83d155f  vmovaps xmm9, [rsp+0x80]
000071c0d83d1568  vmovaps xmm10, [rsp+0x90]
000071c0d83d1571  vmovaps xmm11, [rsp+0xA0]
000071c0d83d157a  vmovaps xmm12, [rsp+0xB0]
000071c0d83d1583  vmovaps xmm13, [rsp+0xC0]
000071c0d83d158c  vmovaps xmm14, [rsp+0xD0]
000071c0d83d1595  vmovaps xmm15, [rsp+0xE0]
000071c0d83d159e  add rsp, 0xF0
000071c0d83d15a5  pop r11
000071c0d83d15a7  pop r10
000071c0d83d15a9  pop r9
000071c0d83d15ab  pop r8
000071c0d83d15ad  pop rsi
000071c0d83d15ae  pop rdi
000071c0d83d15af  pop rdx
000071c0d83d15b0  pop rcx
000071c0d83d15b1  pop rax
000071c0d83d15b2  add rsp, 0x08
000071c0d83d15b6  jmp 0x000071C0D83CF8AC
000071c0d83d15bb  sub rsp, 0x08
000071c0d83d15bf  push rax
000071c0d83d15c0  push rcx
000071c0d83d15c1  push rdx
000071c0d83d15c2  push rdi
000071c0d83d15c3  push rsi
000071c0d83d15c4  push r8
000071c0d83d15c6  push r9
000071c0d83d15c8  push r10
000071c0d83d15ca  push r11
000071c0d83d15cc  sub rsp, 0xF0
000071c0d83d15d3  vmovaps [rsp], xmm0
000071c0d83d15d8  vmovaps [rsp+0x10], xmm1
000071c0d83d15de  vmovaps [rsp+0x20], xmm2
000071c0d83d15e4  vmovaps [rsp+0x30], xmm3
000071c0d83d15ea  vmovaps [rsp+0x40], xmm4
000071c0d83d15f0  vmovaps [rsp+0x50], xmm5
000071c0d83d15f6  vmovaps [rsp+0x60], xmm6
000071c0d83d15fc  vmovaps [rsp+0x70], xmm7
000071c0d83d1602  vmovaps [rsp+0x80], xmm8
000071c0d83d160b  vmovaps [rsp+0x90], xmm9
000071c0d83d1614  vmovaps [rsp+0xA0], xmm10
000071c0d83d161d  vmovaps [rsp+0xB0], xmm11
000071c0d83d1626  vmovaps [rsp+0xC0], xmm12
000071c0d83d162f  vmovaps [rsp+0xD0], xmm13
000071c0d83d1638  vmovaps [rsp+0xE0], xmm15
000071c0d83d1641  sub rsp, 0x30
000071c0d83d1645  movaps [rsp], xmm14
000071c0d83d164a  movaps [rsp+0x10], xmm2
000071c0d83d164f  movaps [rsp+0x20], xmm15
000071c0d83d1655  lea rdi, [rsp]
000071c0d83d1659  mov esi, 0x00
000071c0d83d165e  mov rax, 0x5904ED15D530
000071c0d83d1668  call rax
000071c0d83d166a  movaps xmm14, [rsp]
000071c0d83d166f  add rsp, 0x30
000071c0d83d1673  vmovaps xmm0, [rsp]
000071c0d83d1678  vmovaps xmm1, [rsp+0x10]
000071c0d83d167e  vmovaps xmm2, [rsp+0x20]
000071c0d83d1684  vmovaps xmm3, [rsp+0x30]
000071c0d83d168a  vmovaps xmm4, [rsp+0x40]
000071c0d83d1690  vmovaps xmm5, [rsp+0x50]
000071c0d83d1696  vmovaps xmm6, [rsp+0x60]
000071c0d83d169c  vmovaps xmm7, [rsp+0x70]
000071c0d83d16a2  vmovaps xmm8, [rsp+0x80]
000071c0d83d16ab  vmovaps xmm9, [rsp+0x90]
000071c0d83d16b4  vmovaps xmm10, [rsp+0xA0]
000071c0d83d16bd  vmovaps xmm11, [rsp+0xB0]
000071c0d83d16c6  vmovaps xmm12, [rsp+0xC0]
000071c0d83d16cf  vmovaps xmm13, [rsp+0xD0]
000071c0d83d16d8  vmovaps xmm15, [rsp+0xE0]
000071c0d83d16e1  add rsp, 0xF0
000071c0d83d16e8  pop r11
000071c0d83d16ea  pop r10
000071c0d83d16ec  pop r9
000071c0d83d16ee  pop r8
000071c0d83d16f0  pop rsi
000071c0d83d16f1  pop rdi
000071c0d83d16f2  pop rdx
000071c0d83d16f3  pop rcx
000071c0d83d16f4  pop rax
000071c0d83d16f5  add rsp, 0x08
000071c0d83d16f9  jmp 0x000071C0D83CF8E7
000071c0d83d16fe  sub rsp, 0x08
000071c0d83d1702  push rax
000071c0d83d1703  push rcx
000071c0d83d1704  push rdx
000071c0d83d1705  push rdi
000071c0d83d1706  push rsi
000071c0d83d1707  push r8
000071c0d83d1709  push r9
000071c0d83d170b  push r10
000071c0d83d170d  push r11
000071c0d83d170f  sub rsp, 0xF0
000071c0d83d1716  vmovaps [rsp], xmm0
000071c0d83d171b  vmovaps [rsp+0x10], xmm1
000071c0d83d1721  vmovaps [rsp+0x20], xmm2
000071c0d83d1727  vmovaps [rsp+0x30], xmm3
000071c0d83d172d  vmovaps [rsp+0x40], xmm4
000071c0d83d1733  vmovaps [rsp+0x50], xmm5
000071c0d83d1739  vmovaps [rsp+0x60], xmm6
000071c0d83d173f  vmovaps [rsp+0x70], xmm7
000071c0d83d1745  vmovaps [rsp+0x80], xmm8
000071c0d83d174e  vmovaps [rsp+0x90], xmm9
000071c0d83d1757  vmovaps [rsp+0xA0], xmm10
000071c0d83d1760  vmovaps [rsp+0xB0], xmm11
000071c0d83d1769  vmovaps [rsp+0xC0], xmm12
000071c0d83d1772  vmovaps [rsp+0xD0], xmm13
000071c0d83d177b  vmovaps [rsp+0xE0], xmm14
000071c0d83d1784  sub rsp, 0x30
000071c0d83d1788  movaps [rsp], xmm15
000071c0d83d178d  movaps [rsp+0x10], xmm2
000071c0d83d1792  movaps [rsp+0x20], xmm1
000071c0d83d1797  lea rdi, [rsp]
000071c0d83d179b  mov esi, 0x00
000071c0d83d17a0  mov rax, 0x5904ED15D530
000071c0d83d17aa  call rax
000071c0d83d17ac  movaps xmm15, [rsp]
000071c0d83d17b1  add rsp, 0x30
000071c0d83d17b5  vmovaps xmm0, [rsp]
000071c0d83d17ba  vmovaps xmm1, [rsp+0x10]
000071c0d83d17c0  vmovaps xmm2, [rsp+0x20]
000071c0d83d17c6  vmovaps xmm3, [rsp+0x30]
000071c0d83d17cc  vmovaps xmm4, [rsp+0x40]
000071c0d83d17d2  vmovaps xmm5, [rsp+0x50]
000071c0d83d17d8  vmovaps xmm6, [rsp+0x60]
000071c0d83d17de  vmovaps xmm7, [rsp+0x70]
000071c0d83d17e4  vmovaps xmm8, [rsp+0x80]
000071c0d83d17ed  vmovaps xmm9, [rsp+0x90]
000071c0d83d17f6  vmovaps xmm10, [rsp+0xA0]
000071c0d83d17ff  vmovaps xmm11, [rsp+0xB0]
000071c0d83d1808  vmovaps xmm12, [rsp+0xC0]
000071c0d83d1811  vmovaps xmm13, [rsp+0xD0]
000071c0d83d181a  vmovaps xmm14, [rsp+0xE0]
000071c0d83d1823  add rsp, 0xF0
000071c0d83d182a  pop r11
000071c0d83d182c  pop r10
000071c0d83d182e  pop r9
000071c0d83d1830  pop r8
000071c0d83d1832  pop rsi
000071c0d83d1833  pop rdi
000071c0d83d1834  pop rdx
000071c0d83d1835  pop rcx
000071c0d83d1836  pop rax
000071c0d83d1837  add rsp, 0x08
000071c0d83d183b  jmp 0x000071C0D83CF923
000071c0d83d1840  call 0x000071C0D81FF430
000071c0d83d1845  jmp 0x000071C0D83CF930
000071c0d83d184a  sub rsp, 0x08
000071c0d83d184e  push rax
000071c0d83d184f  push rcx
000071c0d83d1850  push rdx
000071c0d83d1851  push rdi
000071c0d83d1852  push rsi
000071c0d83d1853  push r8
000071c0d83d1855  push r9
000071c0d83d1857  push r10
000071c0d83d1859  push r11
000071c0d83d185b  sub rsp, 0xF0
000071c0d83d1862  vmovaps [rsp], xmm0
000071c0d83d1867  vmovaps [rsp+0x10], xmm1
000071c0d83d186d  vmovaps [rsp+0x20], xmm3
000071c0d83d1873  vmovaps [rsp+0x30], xmm4
000071c0d83d1879  vmovaps [rsp+0x40], xmm5
000071c0d83d187f  vmovaps [rsp+0x50], xmm6
000071c0d83d1885  vmovaps [rsp+0x60], xmm7
000071c0d83d188b  vmovaps [rsp+0x70], xmm8
000071c0d83d1891  vmovaps [rsp+0x80], xmm9
000071c0d83d189a  vmovaps [rsp+0x90], xmm10
000071c0d83d18a3  vmovaps [rsp+0xA0], xmm11
000071c0d83d18ac  vmovaps [rsp+0xB0], xmm12
000071c0d83d18b5  vmovaps [rsp+0xC0], xmm13
000071c0d83d18be  vmovaps [rsp+0xD0], xmm14
000071c0d83d18c7  vmovaps [rsp+0xE0], xmm15
000071c0d83d18d0  sub rsp, 0x30
000071c0d83d18d4  movaps [rsp], xmm2
000071c0d83d18d8  movaps [rsp+0x10], xmm1
000071c0d83d18dd  movaps [rsp+0x20], xmm14
000071c0d83d18e3  lea rdi, [rsp]
000071c0d83d18e7  mov esi, 0x00
000071c0d83d18ec  mov rax, 0x5904ED15D530
000071c0d83d18f6  call rax
000071c0d83d18f8  movaps xmm2, [rsp]
000071c0d83d18fc  add rsp, 0x30
000071c0d83d1900  vmovaps xmm0, [rsp]
000071c0d83d1905  vmovaps xmm1, [rsp+0x10]
000071c0d83d190b  vmovaps xmm3, [rsp+0x20]
000071c0d83d1911  vmovaps xmm4, [rsp+0x30]
000071c0d83d1917  vmovaps xmm5, [rsp+0x40]
000071c0d83d191d  vmovaps xmm6, [rsp+0x50]
000071c0d83d1923  vmovaps xmm7, [rsp+0x60]
000071c0d83d1929  vmovaps xmm8, [rsp+0x70]
000071c0d83d192f  vmovaps xmm9, [rsp+0x80]
000071c0d83d1938  vmovaps xmm10, [rsp+0x90]
000071c0d83d1941  vmovaps xmm11, [rsp+0xA0]
000071c0d83d194a  vmovaps xmm12, [rsp+0xB0]
000071c0d83d1953  vmovaps xmm13, [rsp+0xC0]
000071c0d83d195c  vmovaps xmm14, [rsp+0xD0]
000071c0d83d1965  vmovaps xmm15, [rsp+0xE0]
000071c0d83d196e  add rsp, 0xF0
000071c0d83d1975  pop r11
000071c0d83d1977  pop r10
000071c0d83d1979  pop r9
000071c0d83d197b  pop r8
000071c0d83d197d  pop rsi
000071c0d83d197e  pop rdi
000071c0d83d197f  pop rdx
000071c0d83d1980  pop rcx
000071c0d83d1981  pop rax
000071c0d83d1982  add rsp, 0x08
000071c0d83d1986  jmp 0x000071C0D83CF96D
000071c0d83d198b  sub rsp, 0x08
000071c0d83d198f  push rax
000071c0d83d1990  push rcx
000071c0d83d1991  push rdx
000071c0d83d1992  push rdi
000071c0d83d1993  push rsi
000071c0d83d1994  push r8
000071c0d83d1996  push r9
000071c0d83d1998  push r10
000071c0d83d199a  push r11
000071c0d83d199c  sub rsp, 0xF0
000071c0d83d19a3  vmovaps [rsp], xmm0
000071c0d83d19a8  vmovaps [rsp+0x10], xmm1
000071c0d83d19ae  vmovaps [rsp+0x20], xmm2
000071c0d83d19b4  vmovaps [rsp+0x30], xmm3
000071c0d83d19ba  vmovaps [rsp+0x40], xmm4
000071c0d83d19c0  vmovaps [rsp+0x50], xmm5
000071c0d83d19c6  vmovaps [rsp+0x60], xmm6
000071c0d83d19cc  vmovaps [rsp+0x70], xmm7
000071c0d83d19d2  vmovaps [rsp+0x80], xmm8
000071c0d83d19db  vmovaps [rsp+0x90], xmm9
000071c0d83d19e4  vmovaps [rsp+0xA0], xmm10
000071c0d83d19ed  vmovaps [rsp+0xB0], xmm11
000071c0d83d19f6  vmovaps [rsp+0xC0], xmm12
000071c0d83d19ff  vmovaps [rsp+0xD0], xmm13
000071c0d83d1a08  vmovaps [rsp+0xE0], xmm14
000071c0d83d1a11  sub rsp, 0x30
000071c0d83d1a15  movaps [rsp], xmm15
000071c0d83d1a1a  movaps [rsp+0x10], xmm14
000071c0d83d1a20  movaps [rsp+0x20], xmm1
000071c0d83d1a25  lea rdi, [rsp]
000071c0d83d1a29  mov esi, 0x00
000071c0d83d1a2e  mov rax, 0x5904ED15D530
000071c0d83d1a38  call rax
000071c0d83d1a3a  movaps xmm15, [rsp]
000071c0d83d1a3f  add rsp, 0x30
000071c0d83d1a43  vmovaps xmm0, [rsp]
000071c0d83d1a48  vmovaps xmm1, [rsp+0x10]
000071c0d83d1a4e  vmovaps xmm2, [rsp+0x20]
000071c0d83d1a54  vmovaps xmm3, [rsp+0x30]
000071c0d83d1a5a  vmovaps xmm4, [rsp+0x40]
000071c0d83d1a60  vmovaps xmm5, [rsp+0x50]
000071c0d83d1a66  vmovaps xmm6, [rsp+0x60]
000071c0d83d1a6c  vmovaps xmm7, [rsp+0x70]
000071c0d83d1a72  vmovaps xmm8, [rsp+0x80]
000071c0d83d1a7b  vmovaps xmm9, [rsp+0x90]
000071c0d83d1a84  vmovaps xmm10, [rsp+0xA0]
000071c0d83d1a8d  vmovaps xmm11, [rsp+0xB0]
000071c0d83d1a96  vmovaps xmm12, [rsp+0xC0]
000071c0d83d1a9f  vmovaps xmm13, [rsp+0xD0]
000071c0d83d1aa8  vmovaps xmm14, [rsp+0xE0]
000071c0d83d1ab1  add rsp, 0xF0
000071c0d83d1ab8  pop r11
000071c0d83d1aba  pop r10
000071c0d83d1abc  pop r9
000071c0d83d1abe  pop r8
000071c0d83d1ac0  pop rsi
000071c0d83d1ac1  pop rdi
000071c0d83d1ac2  pop rdx
000071c0d83d1ac3  pop rcx
000071c0d83d1ac4  pop rax
000071c0d83d1ac5  add rsp, 0x08
000071c0d83d1ac9  jmp 0x000071C0D83CF9E7
000071c0d83d1ace  call 0x000071C0D81FF430
000071c0d83d1ad3  jmp 0x000071C0D83CF9F4
000071c0d83d1ad8  sub rsp, 0x08
000071c0d83d1adc  push rax
000071c0d83d1add  push rcx
000071c0d83d1ade  push rdx
000071c0d83d1adf  push rdi
000071c0d83d1ae0  push rsi
000071c0d83d1ae1  push r8
000071c0d83d1ae3  push r9
000071c0d83d1ae5  push r10
000071c0d83d1ae7  push r11
000071c0d83d1ae9  sub rsp, 0xF0
000071c0d83d1af0  vmovaps [rsp], xmm0
000071c0d83d1af5  vmovaps [rsp+0x10], xmm1
000071c0d83d1afb  vmovaps [rsp+0x20], xmm2
000071c0d83d1b01  vmovaps [rsp+0x30], xmm3
000071c0d83d1b07  vmovaps [rsp+0x40], xmm4
000071c0d83d1b0d  vmovaps [rsp+0x50], xmm5
000071c0d83d1b13  vmovaps [rsp+0x60], xmm6
000071c0d83d1b19  vmovaps [rsp+0x70], xmm7
000071c0d83d1b1f  vmovaps [rsp+0x80], xmm8
000071c0d83d1b28  vmovaps [rsp+0x90], xmm9
000071c0d83d1b31  vmovaps [rsp+0xA0], xmm10
000071c0d83d1b3a  vmovaps [rsp+0xB0], xmm11
000071c0d83d1b43  vmovaps [rsp+0xC0], xmm12
000071c0d83d1b4c  vmovaps [rsp+0xD0], xmm13
000071c0d83d1b55  vmovaps [rsp+0xE0], xmm15
000071c0d83d1b5e  sub rsp, 0x30
000071c0d83d1b62  movaps [rsp], xmm14
000071c0d83d1b67  movaps [rsp+0x10], xmm13
000071c0d83d1b6d  movaps [rsp+0x20], xmm1
000071c0d83d1b72  lea rdi, [rsp]
000071c0d83d1b76  mov esi, 0x00
000071c0d83d1b7b  mov rax, 0x5904ED15D530
000071c0d83d1b85  call rax
000071c0d83d1b87  movaps xmm14, [rsp]
000071c0d83d1b8c  add rsp, 0x30
000071c0d83d1b90  vmovaps xmm0, [rsp]
000071c0d83d1b95  vmovaps xmm1, [rsp+0x10]
000071c0d83d1b9b  vmovaps xmm2, [rsp+0x20]
000071c0d83d1ba1  vmovaps xmm3, [rsp+0x30]
000071c0d83d1ba7  vmovaps xmm4, [rsp+0x40]
000071c0d83d1bad  vmovaps xmm5, [rsp+0x50]
000071c0d83d1bb3  vmovaps xmm6, [rsp+0x60]
000071c0d83d1bb9  vmovaps xmm7, [rsp+0x70]
000071c0d83d1bbf  vmovaps xmm8, [rsp+0x80]
000071c0d83d1bc8  vmovaps xmm9, [rsp+0x90]
000071c0d83d1bd1  vmovaps xmm10, [rsp+0xA0]
000071c0d83d1bda  vmovaps xmm11, [rsp+0xB0]
000071c0d83d1be3  vmovaps xmm12, [rsp+0xC0]
000071c0d83d1bec  vmovaps xmm13, [rsp+0xD0]
000071c0d83d1bf5  vmovaps xmm15, [rsp+0xE0]
000071c0d83d1bfe  add rsp, 0xF0
000071c0d83d1c05  pop r11
000071c0d83d1c07  pop r10
000071c0d83d1c09  pop r9
000071c0d83d1c0b  pop r8
000071c0d83d1c0d  pop rsi
000071c0d83d1c0e  pop rdi
000071c0d83d1c0f  pop rdx
000071c0d83d1c10  pop rcx
000071c0d83d1c11  pop rax
000071c0d83d1c12  add rsp, 0x08
000071c0d83d1c16  jmp 0x000071C0D83CFAAF
000071c0d83d1c1b  sub rsp, 0x08
000071c0d83d1c1f  push rax
000071c0d83d1c20  push rcx
000071c0d83d1c21  push rdx
000071c0d83d1c22  push rdi
000071c0d83d1c23  push rsi
000071c0d83d1c24  push r8
000071c0d83d1c26  push r9
000071c0d83d1c28  push r10
000071c0d83d1c2a  push r11
000071c0d83d1c2c  sub rsp, 0xF0
000071c0d83d1c33  vmovaps [rsp], xmm0
000071c0d83d1c38  vmovaps [rsp+0x10], xmm1
000071c0d83d1c3e  vmovaps [rsp+0x20], xmm2
000071c0d83d1c44  vmovaps [rsp+0x30], xmm3
000071c0d83d1c4a  vmovaps [rsp+0x40], xmm4
000071c0d83d1c50  vmovaps [rsp+0x50], xmm5
000071c0d83d1c56  vmovaps [rsp+0x60], xmm6
000071c0d83d1c5c  vmovaps [rsp+0x70], xmm7
000071c0d83d1c62  vmovaps [rsp+0x80], xmm8
000071c0d83d1c6b  vmovaps [rsp+0x90], xmm9
000071c0d83d1c74  vmovaps [rsp+0xA0], xmm10
000071c0d83d1c7d  vmovaps [rsp+0xB0], xmm11
000071c0d83d1c86  vmovaps [rsp+0xC0], xmm12
000071c0d83d1c8f  vmovaps [rsp+0xD0], xmm13
000071c0d83d1c98  vmovaps [rsp+0xE0], xmm14
000071c0d83d1ca1  sub rsp, 0x30
000071c0d83d1ca5  movaps [rsp], xmm15
000071c0d83d1caa  movaps [rsp+0x10], xmm13
000071c0d83d1cb0  movaps [rsp+0x20], xmm1
000071c0d83d1cb5  lea rdi, [rsp]
000071c0d83d1cb9  mov esi, 0x00
000071c0d83d1cbe  mov rax, 0x5904ED15D530
000071c0d83d1cc8  call rax
000071c0d83d1cca  movaps xmm15, [rsp]
000071c0d83d1ccf  add rsp, 0x30
000071c0d83d1cd3  vmovaps xmm0, [rsp]
000071c0d83d1cd8  vmovaps xmm1, [rsp+0x10]
000071c0d83d1cde  vmovaps xmm2, [rsp+0x20]
000071c0d83d1ce4  vmovaps xmm3, [rsp+0x30]
000071c0d83d1cea  vmovaps xmm4, [rsp+0x40]
000071c0d83d1cf0  vmovaps xmm5, [rsp+0x50]
000071c0d83d1cf6  vmovaps xmm6, [rsp+0x60]
000071c0d83d1cfc  vmovaps xmm7, [rsp+0x70]
000071c0d83d1d02  vmovaps xmm8, [rsp+0x80]
000071c0d83d1d0b  vmovaps xmm9, [rsp+0x90]
000071c0d83d1d14  vmovaps xmm10, [rsp+0xA0]
000071c0d83d1d1d  vmovaps xmm11, [rsp+0xB0]
000071c0d83d1d26  vmovaps xmm12, [rsp+0xC0]
000071c0d83d1d2f  vmovaps xmm13, [rsp+0xD0]
000071c0d83d1d38  vmovaps xmm14, [rsp+0xE0]
000071c0d83d1d41  add rsp, 0xF0
000071c0d83d1d48  pop r11
000071c0d83d1d4a  pop r10
000071c0d83d1d4c  pop r9
000071c0d83d1d4e  pop r8
000071c0d83d1d50  pop rsi
000071c0d83d1d51  pop rdi
000071c0d83d1d52  pop rdx
000071c0d83d1d53  pop rcx
000071c0d83d1d54  pop rax
000071c0d83d1d55  add rsp, 0x08
000071c0d83d1d59  jmp 0x000071C0D83CFAEB
000071c0d83d1d5e  call 0x000071C0D81FF430
000071c0d83d1d63  jmp 0x000071C0D83CFAF8
000071c0d83d1d68  sub rsp, 0x08
000071c0d83d1d6c  push rax
000071c0d83d1d6d  push rcx
000071c0d83d1d6e  push rdx
000071c0d83d1d6f  push rdi
000071c0d83d1d70  push rsi
000071c0d83d1d71  push r8
000071c0d83d1d73  push r9
000071c0d83d1d75  push r10
000071c0d83d1d77  push r11
000071c0d83d1d79  sub rsp, 0xF0
000071c0d83d1d80  vmovaps [rsp], xmm0
000071c0d83d1d85  vmovaps [rsp+0x10], xmm1
000071c0d83d1d8b  vmovaps [rsp+0x20], xmm2
000071c0d83d1d91  vmovaps [rsp+0x30], xmm3
000071c0d83d1d97  vmovaps [rsp+0x40], xmm4
000071c0d83d1d9d  vmovaps [rsp+0x50], xmm5
000071c0d83d1da3  vmovaps [rsp+0x60], xmm6
000071c0d83d1da9  vmovaps [rsp+0x70], xmm7
000071c0d83d1daf  vmovaps [rsp+0x80], xmm8
000071c0d83d1db8  vmovaps [rsp+0x90], xmm9
000071c0d83d1dc1  vmovaps [rsp+0xA0], xmm10
000071c0d83d1dca  vmovaps [rsp+0xB0], xmm11
000071c0d83d1dd3  vmovaps [rsp+0xC0], xmm12
000071c0d83d1ddc  vmovaps [rsp+0xD0], xmm13
000071c0d83d1de5  vmovaps [rsp+0xE0], xmm15
000071c0d83d1dee  sub rsp, 0x30
000071c0d83d1df2  movaps [rsp], xmm14
000071c0d83d1df7  movaps [rsp+0x10], xmm13
000071c0d83d1dfd  movaps [rsp+0x20], xmm2
000071c0d83d1e02  lea rdi, [rsp]
000071c0d83d1e06  mov esi, 0x00
000071c0d83d1e0b  mov rax, 0x5904ED15D530
000071c0d83d1e15  call rax
000071c0d83d1e17  movaps xmm14, [rsp]
000071c0d83d1e1c  add rsp, 0x30
000071c0d83d1e20  vmovaps xmm0, [rsp]
000071c0d83d1e25  vmovaps xmm1, [rsp+0x10]
000071c0d83d1e2b  vmovaps xmm2, [rsp+0x20]
000071c0d83d1e31  vmovaps xmm3, [rsp+0x30]
000071c0d83d1e37  vmovaps xmm4, [rsp+0x40]
000071c0d83d1e3d  vmovaps xmm5, [rsp+0x50]
000071c0d83d1e43  vmovaps xmm6, [rsp+0x60]
000071c0d83d1e49  vmovaps xmm7, [rsp+0x70]
000071c0d83d1e4f  vmovaps xmm8, [rsp+0x80]
000071c0d83d1e58  vmovaps xmm9, [rsp+0x90]
000071c0d83d1e61  vmovaps xmm10, [rsp+0xA0]
000071c0d83d1e6a  vmovaps xmm11, [rsp+0xB0]
000071c0d83d1e73  vmovaps xmm12, [rsp+0xC0]
000071c0d83d1e7c  vmovaps xmm13, [rsp+0xD0]
000071c0d83d1e85  vmovaps xmm15, [rsp+0xE0]
000071c0d83d1e8e  add rsp, 0xF0
000071c0d83d1e95  pop r11
000071c0d83d1e97  pop r10
000071c0d83d1e99  pop r9
000071c0d83d1e9b  pop r8
000071c0d83d1e9d  pop rsi
000071c0d83d1e9e  pop rdi
000071c0d83d1e9f  pop rdx
000071c0d83d1ea0  pop rcx
000071c0d83d1ea1  pop rax
000071c0d83d1ea2  add rsp, 0x08
000071c0d83d1ea6  jmp 0x000071C0D83CFB24
000071c0d83d1eab  sub rsp, 0x08
000071c0d83d1eaf  push rax
000071c0d83d1eb0  push rcx
000071c0d83d1eb1  push rdx
000071c0d83d1eb2  push rdi
000071c0d83d1eb3  push rsi
000071c0d83d1eb4  push r8
000071c0d83d1eb6  push r9
000071c0d83d1eb8  push r10
000071c0d83d1eba  push r11
000071c0d83d1ebc  sub rsp, 0xF0
000071c0d83d1ec3  vmovaps [rsp], xmm0
000071c0d83d1ec8  vmovaps [rsp+0x10], xmm2
000071c0d83d1ece  vmovaps [rsp+0x20], xmm3
000071c0d83d1ed4  vmovaps [rsp+0x30], xmm4
000071c0d83d1eda  vmovaps [rsp+0x40], xmm5
000071c0d83d1ee0  vmovaps [rsp+0x50], xmm6
000071c0d83d1ee6  vmovaps [rsp+0x60], xmm7
000071c0d83d1eec  vmovaps [rsp+0x70], xmm8
000071c0d83d1ef2  vmovaps [rsp+0x80], xmm9
000071c0d83d1efb  vmovaps [rsp+0x90], xmm10
000071c0d83d1f04  vmovaps [rsp+0xA0], xmm11
000071c0d83d1f0d  vmovaps [rsp+0xB0], xmm12
000071c0d83d1f16  vmovaps [rsp+0xC0], xmm13
000071c0d83d1f1f  vmovaps [rsp+0xD0], xmm14
000071c0d83d1f28  vmovaps [rsp+0xE0], xmm15
000071c0d83d1f31  sub rsp, 0x30
000071c0d83d1f35  movaps [rsp], xmm1
000071c0d83d1f39  movaps [rsp+0x10], xmm13
000071c0d83d1f3f  movaps [rsp+0x20], xmm2
000071c0d83d1f44  lea rdi, [rsp]
000071c0d83d1f48  mov esi, 0x00
000071c0d83d1f4d  mov rax, 0x5904ED15D530
000071c0d83d1f57  call rax
000071c0d83d1f59  movaps xmm1, [rsp]
000071c0d83d1f5d  add rsp, 0x30
000071c0d83d1f61  vmovaps xmm0, [rsp]
000071c0d83d1f66  vmovaps xmm2, [rsp+0x10]
000071c0d83d1f6c  vmovaps xmm3, [rsp+0x20]
000071c0d83d1f72  vmovaps xmm4, [rsp+0x30]
000071c0d83d1f78  vmovaps xmm5, [rsp+0x40]
000071c0d83d1f7e  vmovaps xmm6, [rsp+0x50]
000071c0d83d1f84  vmovaps xmm7, [rsp+0x60]
000071c0d83d1f8a  vmovaps xmm8, [rsp+0x70]
000071c0d83d1f90  vmovaps xmm9, [rsp+0x80]
000071c0d83d1f99  vmovaps xmm10, [rsp+0x90]
000071c0d83d1fa2  vmovaps xmm11, [rsp+0xA0]
000071c0d83d1fab  vmovaps xmm12, [rsp+0xB0]
000071c0d83d1fb4  vmovaps xmm13, [rsp+0xC0]
000071c0d83d1fbd  vmovaps xmm14, [rsp+0xD0]
000071c0d83d1fc6  vmovaps xmm15, [rsp+0xE0]
000071c0d83d1fcf  add rsp, 0xF0
000071c0d83d1fd6  pop r11
000071c0d83d1fd8  pop r10
000071c0d83d1fda  pop r9
000071c0d83d1fdc  pop r8
000071c0d83d1fde  pop rsi
000071c0d83d1fdf  pop rdi
000071c0d83d1fe0  pop rdx
000071c0d83d1fe1  pop rcx
000071c0d83d1fe2  pop rax
000071c0d83d1fe3  add rsp, 0x08
000071c0d83d1fe7  jmp 0x000071C0D83CFB52
000071c0d83d1fec  sub rsp, 0x08
000071c0d83d1ff0  push rax
000071c0d83d1ff1  push rcx
000071c0d83d1ff2  push rdx
000071c0d83d1ff3  push rdi
000071c0d83d1ff4  push rsi
000071c0d83d1ff5  push r8
000071c0d83d1ff7  push r9
000071c0d83d1ff9  push r10
000071c0d83d1ffb  push r11
000071c0d83d1ffd  sub rsp, 0xF0
000071c0d83d2004  vmovaps [rsp], xmm0
000071c0d83d2009  vmovaps [rsp+0x10], xmm1
000071c0d83d200f  vmovaps [rsp+0x20], xmm3
000071c0d83d2015  vmovaps [rsp+0x30], xmm4
000071c0d83d201b  vmovaps [rsp+0x40], xmm5
000071c0d83d2021  vmovaps [rsp+0x50], xmm6
000071c0d83d2027  vmovaps [rsp+0x60], xmm7
000071c0d83d202d  vmovaps [rsp+0x70], xmm8
000071c0d83d2033  vmovaps [rsp+0x80], xmm9
000071c0d83d203c  vmovaps [rsp+0x90], xmm10
000071c0d83d2045  vmovaps [rsp+0xA0], xmm11
000071c0d83d204e  vmovaps [rsp+0xB0], xmm12
000071c0d83d2057  vmovaps [rsp+0xC0], xmm13
000071c0d83d2060  vmovaps [rsp+0xD0], xmm14
000071c0d83d2069  vmovaps [rsp+0xE0], xmm15
000071c0d83d2072  sub rsp, 0x30
000071c0d83d2076  movaps [rsp], xmm2
000071c0d83d207a  movaps [rsp+0x10], xmm1
000071c0d83d207f  movaps [rsp+0x20], xmm13
000071c0d83d2085  lea rdi, [rsp]
000071c0d83d2089  mov esi, 0x00
000071c0d83d208e  mov rax, 0x5904ED15D530
000071c0d83d2098  call rax
000071c0d83d209a  movaps xmm2, [rsp]
000071c0d83d209e  add rsp, 0x30
000071c0d83d20a2  vmovaps xmm0, [rsp]
000071c0d83d20a7  vmovaps xmm1, [rsp+0x10]
000071c0d83d20ad  vmovaps xmm3, [rsp+0x20]
000071c0d83d20b3  vmovaps xmm4, [rsp+0x30]
000071c0d83d20b9  vmovaps xmm5, [rsp+0x40]
000071c0d83d20bf  vmovaps xmm6, [rsp+0x50]
000071c0d83d20c5  vmovaps xmm7, [rsp+0x60]
000071c0d83d20cb  vmovaps xmm8, [rsp+0x70]
000071c0d83d20d1  vmovaps xmm9, [rsp+0x80]
000071c0d83d20da  vmovaps xmm10, [rsp+0x90]
000071c0d83d20e3  vmovaps xmm11, [rsp+0xA0]
000071c0d83d20ec  vmovaps xmm12, [rsp+0xB0]
000071c0d83d20f5  vmovaps xmm13, [rsp+0xC0]
000071c0d83d20fe  vmovaps xmm14, [rsp+0xD0]
000071c0d83d2107  vmovaps xmm15, [rsp+0xE0]
000071c0d83d2110  add rsp, 0xF0
000071c0d83d2117  pop r11
000071c0d83d2119  pop r10
000071c0d83d211b  pop r9
000071c0d83d211d  pop r8
000071c0d83d211f  pop rsi
000071c0d83d2120  pop rdi
000071c0d83d2121  pop rdx
000071c0d83d2122  pop rcx
000071c0d83d2123  pop rax
000071c0d83d2124  add rsp, 0x08
000071c0d83d2128  jmp 0x000071C0D83CFBAB
000071c0d83d212d  call 0x000071C0D81FF430
000071c0d83d2132  jmp 0x000071C0D83CFBB8
000071c0d83d2137  sub rsp, 0x08
000071c0d83d213b  push rax
000071c0d83d213c  push rcx
000071c0d83d213d  push rdx
000071c0d83d213e  push rdi
000071c0d83d213f  push rsi
000071c0d83d2140  push r8
000071c0d83d2142  push r9
000071c0d83d2144  push r10
000071c0d83d2146  push r11
000071c0d83d2148  sub rsp, 0xF0
000071c0d83d214f  vmovaps [rsp], xmm0
000071c0d83d2154  vmovaps [rsp+0x10], xmm1
000071c0d83d215a  vmovaps [rsp+0x20], xmm2
000071c0d83d2160  vmovaps [rsp+0x30], xmm3
000071c0d83d2166  vmovaps [rsp+0x40], xmm4
000071c0d83d216c  vmovaps [rsp+0x50], xmm5
000071c0d83d2172  vmovaps [rsp+0x60], xmm6
000071c0d83d2178  vmovaps [rsp+0x70], xmm7
000071c0d83d217e  vmovaps [rsp+0x80], xmm8
000071c0d83d2187  vmovaps [rsp+0x90], xmm9
000071c0d83d2190  vmovaps [rsp+0xA0], xmm10
000071c0d83d2199  vmovaps [rsp+0xB0], xmm11
000071c0d83d21a2  vmovaps [rsp+0xC0], xmm12
000071c0d83d21ab  vmovaps [rsp+0xD0], xmm13
000071c0d83d21b4  vmovaps [rsp+0xE0], xmm14
000071c0d83d21bd  sub rsp, 0x30
000071c0d83d21c1  movaps [rsp], xmm15
000071c0d83d21c6  movaps [rsp+0x10], xmm13
000071c0d83d21cc  movaps [rsp+0x20], xmm1
000071c0d83d21d1  lea rdi, [rsp]
000071c0d83d21d5  mov esi, 0x00
000071c0d83d21da  mov rax, 0x5904ED15D530
000071c0d83d21e4  call rax
000071c0d83d21e6  movaps xmm15, [rsp]
000071c0d83d21eb  add rsp, 0x30
000071c0d83d21ef  vmovaps xmm0, [rsp]
000071c0d83d21f4  vmovaps xmm1, [rsp+0x10]
000071c0d83d21fa  vmovaps xmm2, [rsp+0x20]
000071c0d83d2200  vmovaps xmm3, [rsp+0x30]
000071c0d83d2206  vmovaps xmm4, [rsp+0x40]
000071c0d83d220c  vmovaps xmm5, [rsp+0x50]
000071c0d83d2212  vmovaps xmm6, [rsp+0x60]
000071c0d83d2218  vmovaps xmm7, [rsp+0x70]
000071c0d83d221e  vmovaps xmm8, [rsp+0x80]
000071c0d83d2227  vmovaps xmm9, [rsp+0x90]
000071c0d83d2230  vmovaps xmm10, [rsp+0xA0]
000071c0d83d2239  vmovaps xmm11, [rsp+0xB0]
000071c0d83d2242  vmovaps xmm12, [rsp+0xC0]
000071c0d83d224b  vmovaps xmm13, [rsp+0xD0]
000071c0d83d2254  vmovaps xmm14, [rsp+0xE0]
000071c0d83d225d  add rsp, 0xF0
000071c0d83d2264  pop r11
000071c0d83d2266  pop r10
000071c0d83d2268  pop r9
000071c0d83d226a  pop r8
000071c0d83d226c  pop rsi
000071c0d83d226d  pop rdi
000071c0d83d226e  pop rdx
000071c0d83d226f  pop rcx
000071c0d83d2270  pop rax
000071c0d83d2271  add rsp, 0x08
000071c0d83d2275  jmp 0x000071C0D83CFBF7
000071c0d83d227a  sub rsp, 0x08
000071c0d83d227e  push rax
000071c0d83d227f  push rcx
000071c0d83d2280  push rdx
000071c0d83d2281  push rdi
000071c0d83d2282  push rsi
000071c0d83d2283  push r8
000071c0d83d2285  push r9
000071c0d83d2287  push r10
000071c0d83d2289  push r11
000071c0d83d228b  sub rsp, 0xF0
000071c0d83d2292  vmovaps [rsp], xmm0
000071c0d83d2297  vmovaps [rsp+0x10], xmm1
000071c0d83d229d  vmovaps [rsp+0x20], xmm2
000071c0d83d22a3  vmovaps [rsp+0x30], xmm3
000071c0d83d22a9  vmovaps [rsp+0x40], xmm4
000071c0d83d22af  vmovaps [rsp+0x50], xmm5
000071c0d83d22b5  vmovaps [rsp+0x60], xmm6
000071c0d83d22bb  vmovaps [rsp+0x70], xmm7
000071c0d83d22c1  vmovaps [rsp+0x80], xmm8
000071c0d83d22ca  vmovaps [rsp+0x90], xmm9
000071c0d83d22d3  vmovaps [rsp+0xA0], xmm10
000071c0d83d22dc  vmovaps [rsp+0xB0], xmm11
000071c0d83d22e5  vmovaps [rsp+0xC0], xmm12
000071c0d83d22ee  vmovaps [rsp+0xD0], xmm13
000071c0d83d22f7  vmovaps [rsp+0xE0], xmm15
000071c0d83d2300  sub rsp, 0x30
000071c0d83d2304  movaps [rsp], xmm14
000071c0d83d2309  movaps [rsp+0x10], xmm11
000071c0d83d230f  movaps [rsp+0x20], xmm1
000071c0d83d2314  lea rdi, [rsp]
000071c0d83d2318  mov esi, 0x00
000071c0d83d231d  mov rax, 0x5904ED15D530
000071c0d83d2327  call rax
000071c0d83d2329  movaps xmm14, [rsp]
000071c0d83d232e  add rsp, 0x30
000071c0d83d2332  vmovaps xmm0, [rsp]
000071c0d83d2337  vmovaps xmm1, [rsp+0x10]
000071c0d83d233d  vmovaps xmm2, [rsp+0x20]
000071c0d83d2343  vmovaps xmm3, [rsp+0x30]
000071c0d83d2349  vmovaps xmm4, [rsp+0x40]
000071c0d83d234f  vmovaps xmm5, [rsp+0x50]
000071c0d83d2355  vmovaps xmm6, [rsp+0x60]
000071c0d83d235b  vmovaps xmm7, [rsp+0x70]
000071c0d83d2361  vmovaps xmm8, [rsp+0x80]
000071c0d83d236a  vmovaps xmm9, [rsp+0x90]
000071c0d83d2373  vmovaps xmm10, [rsp+0xA0]
000071c0d83d237c  vmovaps xmm11, [rsp+0xB0]
000071c0d83d2385  vmovaps xmm12, [rsp+0xC0]
000071c0d83d238e  vmovaps xmm13, [rsp+0xD0]
000071c0d83d2397  vmovaps xmm15, [rsp+0xE0]
000071c0d83d23a0  add rsp, 0xF0
000071c0d83d23a7  pop r11
000071c0d83d23a9  pop r10
000071c0d83d23ab  pop r9
000071c0d83d23ad  pop r8
000071c0d83d23af  pop rsi
000071c0d83d23b0  pop rdi
000071c0d83d23b1  pop rdx
000071c0d83d23b2  pop rcx
000071c0d83d23b3  pop rax
000071c0d83d23b4  add rsp, 0x08
000071c0d83d23b8  jmp 0x000071C0D83CFC21
000071c0d83d23bd  sub rsp, 0x08
000071c0d83d23c1  push rax
000071c0d83d23c2  push rcx
000071c0d83d23c3  push rdx
000071c0d83d23c4  push rdi
000071c0d83d23c5  push rsi
000071c0d83d23c6  push r8
000071c0d83d23c8  push r9
000071c0d83d23ca  push r10
000071c0d83d23cc  push r11
000071c0d83d23ce  sub rsp, 0xF0
000071c0d83d23d5  vmovaps [rsp], xmm0
000071c0d83d23da  vmovaps [rsp+0x10], xmm1
000071c0d83d23e0  vmovaps [rsp+0x20], xmm2
000071c0d83d23e6  vmovaps [rsp+0x30], xmm3
000071c0d83d23ec  vmovaps [rsp+0x40], xmm4
000071c0d83d23f2  vmovaps [rsp+0x50], xmm5
000071c0d83d23f8  vmovaps [rsp+0x60], xmm6
000071c0d83d23fe  vmovaps [rsp+0x70], xmm7
000071c0d83d2404  vmovaps [rsp+0x80], xmm8
000071c0d83d240d  vmovaps [rsp+0x90], xmm9
000071c0d83d2416  vmovaps [rsp+0xA0], xmm10
000071c0d83d241f  vmovaps [rsp+0xB0], xmm11
000071c0d83d2428  vmovaps [rsp+0xC0], xmm12
000071c0d83d2431  vmovaps [rsp+0xD0], xmm14
000071c0d83d243a  vmovaps [rsp+0xE0], xmm15
000071c0d83d2443  sub rsp, 0x30
000071c0d83d2447  movaps [rsp], xmm13
000071c0d83d244c  movaps [rsp+0x10], xmm11
000071c0d83d2452  movaps [rsp+0x20], xmm1
000071c0d83d2457  lea rdi, [rsp]
000071c0d83d245b  mov esi, 0x00
000071c0d83d2460  mov rax, 0x5904ED15D530
000071c0d83d246a  call rax
000071c0d83d246c  movaps xmm13, [rsp]
000071c0d83d2471  add rsp, 0x30
000071c0d83d2475  vmovaps xmm0, [rsp]
000071c0d83d247a  vmovaps xmm1, [rsp+0x10]
000071c0d83d2480  vmovaps xmm2, [rsp+0x20]
000071c0d83d2486  vmovaps xmm3, [rsp+0x30]
000071c0d83d248c  vmovaps xmm4, [rsp+0x40]
000071c0d83d2492  vmovaps xmm5, [rsp+0x50]
000071c0d83d2498  vmovaps xmm6, [rsp+0x60]
000071c0d83d249e  vmovaps xmm7, [rsp+0x70]
000071c0d83d24a4  vmovaps xmm8, [rsp+0x80]
000071c0d83d24ad  vmovaps xmm9, [rsp+0x90]
000071c0d83d24b6  vmovaps xmm10, [rsp+0xA0]
000071c0d83d24bf  vmovaps xmm11, [rsp+0xB0]
000071c0d83d24c8  vmovaps xmm12, [rsp+0xC0]
000071c0d83d24d1  vmovaps xmm14, [rsp+0xD0]
000071c0d83d24da  vmovaps xmm15, [rsp+0xE0]
000071c0d83d24e3  add rsp, 0xF0
000071c0d83d24ea  pop r11
000071c0d83d24ec  pop r10
000071c0d83d24ee  pop r9
000071c0d83d24f0  pop r8
000071c0d83d24f2  pop rsi
000071c0d83d24f3  pop rdi
000071c0d83d24f4  pop rdx
000071c0d83d24f5  pop rcx
000071c0d83d24f6  pop rax
000071c0d83d24f7  add rsp, 0x08
000071c0d83d24fb  jmp 0x000071C0D83CFC76
000071c0d83d2500  call 0x000071C0D81FF430
000071c0d83d2505  jmp 0x000071C0D83CFC83
000071c0d83d250a  sub rsp, 0x08
000071c0d83d250e  push rax
000071c0d83d250f  push rcx
000071c0d83d2510  push rdx
000071c0d83d2511  push rdi
000071c0d83d2512  push rsi
000071c0d83d2513  push r8
000071c0d83d2515  push r9
000071c0d83d2517  push r10
000071c0d83d2519  push r11
000071c0d83d251b  sub rsp, 0xF0
000071c0d83d2522  vmovaps [rsp], xmm0
000071c0d83d2527  vmovaps [rsp+0x10], xmm1
000071c0d83d252d  vmovaps [rsp+0x20], xmm2
000071c0d83d2533  vmovaps [rsp+0x30], xmm3
000071c0d83d2539  vmovaps [rsp+0x40], xmm4
000071c0d83d253f  vmovaps [rsp+0x50], xmm5
000071c0d83d2545  vmovaps [rsp+0x60], xmm6
000071c0d83d254b  vmovaps [rsp+0x70], xmm7
000071c0d83d2551  vmovaps [rsp+0x80], xmm8
000071c0d83d255a  vmovaps [rsp+0x90], xmm9
000071c0d83d2563  vmovaps [rsp+0xA0], xmm10
000071c0d83d256c  vmovaps [rsp+0xB0], xmm11
000071c0d83d2575  vmovaps [rsp+0xC0], xmm12
000071c0d83d257e  vmovaps [rsp+0xD0], xmm13
000071c0d83d2587  vmovaps [rsp+0xE0], xmm14
000071c0d83d2590  sub rsp, 0x30
000071c0d83d2594  movaps [rsp], xmm15
000071c0d83d2599  movaps [rsp+0x10], xmm11
000071c0d83d259f  movaps [rsp+0x20], xmm1
000071c0d83d25a4  lea rdi, [rsp]
000071c0d83d25a8  mov esi, 0x00
000071c0d83d25ad  mov rax, 0x5904ED15D530
000071c0d83d25b7  call rax
000071c0d83d25b9  movaps xmm15, [rsp]
000071c0d83d25be  add rsp, 0x30
000071c0d83d25c2  vmovaps xmm0, [rsp]
000071c0d83d25c7  vmovaps xmm1, [rsp+0x10]
000071c0d83d25cd  vmovaps xmm2, [rsp+0x20]
000071c0d83d25d3  vmovaps xmm3, [rsp+0x30]
000071c0d83d25d9  vmovaps xmm4, [rsp+0x40]
000071c0d83d25df  vmovaps xmm5, [rsp+0x50]
000071c0d83d25e5  vmovaps xmm6, [rsp+0x60]
000071c0d83d25eb  vmovaps xmm7, [rsp+0x70]
000071c0d83d25f1  vmovaps xmm8, [rsp+0x80]
000071c0d83d25fa  vmovaps xmm9, [rsp+0x90]
000071c0d83d2603  vmovaps xmm10, [rsp+0xA0]
000071c0d83d260c  vmovaps xmm11, [rsp+0xB0]
000071c0d83d2615  vmovaps xmm12, [rsp+0xC0]
000071c0d83d261e  vmovaps xmm13, [rsp+0xD0]
000071c0d83d2627  vmovaps xmm14, [rsp+0xE0]
000071c0d83d2630  add rsp, 0xF0
000071c0d83d2637  pop r11
000071c0d83d2639  pop r10
000071c0d83d263b  pop r9
000071c0d83d263d  pop r8
000071c0d83d263f  pop rsi
000071c0d83d2640  pop rdi
000071c0d83d2641  pop rdx
000071c0d83d2642  pop rcx
000071c0d83d2643  pop rax
000071c0d83d2644  add rsp, 0x08
000071c0d83d2648  jmp 0x000071C0D83CFCBC
000071c0d83d264d  sub rsp, 0x08
000071c0d83d2651  push rax
000071c0d83d2652  push rcx
000071c0d83d2653  push rdx
000071c0d83d2654  push rdi
000071c0d83d2655  push rsi
000071c0d83d2656  push r8
000071c0d83d2658  push r9
000071c0d83d265a  push r10
000071c0d83d265c  push r11
000071c0d83d265e  sub rsp, 0xF0
000071c0d83d2665  vmovaps [rsp], xmm0
000071c0d83d266a  vmovaps [rsp+0x10], xmm1
000071c0d83d2670  vmovaps [rsp+0x20], xmm2
000071c0d83d2676  vmovaps [rsp+0x30], xmm3
000071c0d83d267c  vmovaps [rsp+0x40], xmm4
000071c0d83d2682  vmovaps [rsp+0x50], xmm5
000071c0d83d2688  vmovaps [rsp+0x60], xmm6
000071c0d83d268e  vmovaps [rsp+0x70], xmm7
000071c0d83d2694  vmovaps [rsp+0x80], xmm8
000071c0d83d269d  vmovaps [rsp+0x90], xmm9
000071c0d83d26a6  vmovaps [rsp+0xA0], xmm10
000071c0d83d26af  vmovaps [rsp+0xB0], xmm12
000071c0d83d26b8  vmovaps [rsp+0xC0], xmm13
000071c0d83d26c1  vmovaps [rsp+0xD0], xmm14
000071c0d83d26ca  vmovaps [rsp+0xE0], xmm15
000071c0d83d26d3  sub rsp, 0x30
000071c0d83d26d7  movaps [rsp], xmm11
000071c0d83d26dc  movaps [rsp+0x10], xmm6
000071c0d83d26e1  movaps [rsp+0x20], xmm14
000071c0d83d26e7  lea rdi, [rsp]
000071c0d83d26eb  mov esi, 0x00
000071c0d83d26f0  mov rax, 0x5904ED15D530
000071c0d83d26fa  call rax
000071c0d83d26fc  movaps xmm11, [rsp]
000071c0d83d2701  add rsp, 0x30
000071c0d83d2705  vmovaps xmm0, [rsp]
000071c0d83d270a  vmovaps xmm1, [rsp+0x10]
000071c0d83d2710  vmovaps xmm2, [rsp+0x20]
000071c0d83d2716  vmovaps xmm3, [rsp+0x30]
000071c0d83d271c  vmovaps xmm4, [rsp+0x40]
000071c0d83d2722  vmovaps xmm5, [rsp+0x50]
000071c0d83d2728  vmovaps xmm6, [rsp+0x60]
000071c0d83d272e  vmovaps xmm7, [rsp+0x70]
000071c0d83d2734  vmovaps xmm8, [rsp+0x80]
000071c0d83d273d  vmovaps xmm9, [rsp+0x90]
000071c0d83d2746  vmovaps xmm10, [rsp+0xA0]
000071c0d83d274f  vmovaps xmm12, [rsp+0xB0]
000071c0d83d2758  vmovaps xmm13, [rsp+0xC0]
000071c0d83d2761  vmovaps xmm14, [rsp+0xD0]
000071c0d83d276a  vmovaps xmm15, [rsp+0xE0]
000071c0d83d2773  add rsp, 0xF0
000071c0d83d277a  pop r11
000071c0d83d277c  pop r10
000071c0d83d277e  pop r9
000071c0d83d2780  pop r8
000071c0d83d2782  pop rsi
000071c0d83d2783  pop rdi
000071c0d83d2784  pop rdx
000071c0d83d2785  pop rcx
000071c0d83d2786  pop rax
000071c0d83d2787  add rsp, 0x08
000071c0d83d278b  jmp 0x000071C0D83CFD34
000071c0d83d2790  call 0x000071C0D81FF430
000071c0d83d2795  jmp 0x000071C0D83CFD3E
000071c0d83d279a  sub rsp, 0x08
000071c0d83d279e  push rax
000071c0d83d279f  push rcx
000071c0d83d27a0  push rdx
000071c0d83d27a1  push rdi
000071c0d83d27a2  push rsi
000071c0d83d27a3  push r8
000071c0d83d27a5  push r9
000071c0d83d27a7  push r10
000071c0d83d27a9  push r11
000071c0d83d27ab  sub rsp, 0xF0
000071c0d83d27b2  vmovaps [rsp], xmm0
000071c0d83d27b7  vmovaps [rsp+0x10], xmm1
000071c0d83d27bd  vmovaps [rsp+0x20], xmm2
000071c0d83d27c3  vmovaps [rsp+0x30], xmm3
000071c0d83d27c9  vmovaps [rsp+0x40], xmm4
000071c0d83d27cf  vmovaps [rsp+0x50], xmm5
000071c0d83d27d5  vmovaps [rsp+0x60], xmm6
000071c0d83d27db  vmovaps [rsp+0x70], xmm7
000071c0d83d27e1  vmovaps [rsp+0x80], xmm8
000071c0d83d27ea  vmovaps [rsp+0x90], xmm9
000071c0d83d27f3  vmovaps [rsp+0xA0], xmm10
000071c0d83d27fc  vmovaps [rsp+0xB0], xmm11
000071c0d83d2805  vmovaps [rsp+0xC0], xmm12
000071c0d83d280e  vmovaps [rsp+0xD0], xmm13
000071c0d83d2817  vmovaps [rsp+0xE0], xmm15
000071c0d83d2820  sub rsp, 0x30
000071c0d83d2824  movaps [rsp], xmm14
000071c0d83d2829  movaps [rsp+0x10], xmm6
000071c0d83d282e  movaps [rsp+0x20], xmm2
000071c0d83d2833  lea rdi, [rsp]
000071c0d83d2837  mov esi, 0x00
000071c0d83d283c  mov rax, 0x5904ED15D530
000071c0d83d2846  call rax
000071c0d83d2848  movaps xmm14, [rsp]
000071c0d83d284d  add rsp, 0x30
000071c0d83d2851  vmovaps xmm0, [rsp]
000071c0d83d2856  vmovaps xmm1, [rsp+0x10]
000071c0d83d285c  vmovaps xmm2, [rsp+0x20]
000071c0d83d2862  vmovaps xmm3, [rsp+0x30]
000071c0d83d2868  vmovaps xmm4, [rsp+0x40]
000071c0d83d286e  vmovaps xmm5, [rsp+0x50]
000071c0d83d2874  vmovaps xmm6, [rsp+0x60]
000071c0d83d287a  vmovaps xmm7, [rsp+0x70]
000071c0d83d2880  vmovaps xmm8, [rsp+0x80]
000071c0d83d2889  vmovaps xmm9, [rsp+0x90]
000071c0d83d2892  vmovaps xmm10, [rsp+0xA0]
000071c0d83d289b  vmovaps xmm11, [rsp+0xB0]
000071c0d83d28a4  vmovaps xmm12, [rsp+0xC0]
000071c0d83d28ad  vmovaps xmm13, [rsp+0xD0]
000071c0d83d28b6  vmovaps xmm15, [rsp+0xE0]
000071c0d83d28bf  add rsp, 0xF0
000071c0d83d28c6  pop r11
000071c0d83d28c8  pop r10
000071c0d83d28ca  pop r9
000071c0d83d28cc  pop r8
000071c0d83d28ce  pop rsi
000071c0d83d28cf  pop rdi
000071c0d83d28d0  pop rdx
000071c0d83d28d1  pop rcx
000071c0d83d28d2  pop rax
000071c0d83d28d3  add rsp, 0x08
000071c0d83d28d7  jmp 0x000071C0D83CFD72
000071c0d83d28dc  sub rsp, 0x08
000071c0d83d28e0  push rax
000071c0d83d28e1  push rcx
000071c0d83d28e2  push rdx
000071c0d83d28e3  push rdi
000071c0d83d28e4  push rsi
000071c0d83d28e5  push r8
000071c0d83d28e7  push r9
000071c0d83d28e9  push r10
000071c0d83d28eb  push r11
000071c0d83d28ed  sub rsp, 0xF0
000071c0d83d28f4  vmovaps [rsp], xmm0
000071c0d83d28f9  vmovaps [rsp+0x10], xmm1
000071c0d83d28ff  vmovaps [rsp+0x20], xmm2
000071c0d83d2905  vmovaps [rsp+0x30], xmm3
000071c0d83d290b  vmovaps [rsp+0x40], xmm4
000071c0d83d2911  vmovaps [rsp+0x50], xmm5
000071c0d83d2917  vmovaps [rsp+0x60], xmm7
000071c0d83d291d  vmovaps [rsp+0x70], xmm8
000071c0d83d2923  vmovaps [rsp+0x80], xmm9
000071c0d83d292c  vmovaps [rsp+0x90], xmm10
000071c0d83d2935  vmovaps [rsp+0xA0], xmm11
000071c0d83d293e  vmovaps [rsp+0xB0], xmm12
000071c0d83d2947  vmovaps [rsp+0xC0], xmm13
000071c0d83d2950  vmovaps [rsp+0xD0], xmm14
000071c0d83d2959  vmovaps [rsp+0xE0], xmm15
000071c0d83d2962  sub rsp, 0x30
000071c0d83d2966  movaps [rsp], xmm6
000071c0d83d296a  movaps [rsp+0x10], xmm5
000071c0d83d296f  movaps [rsp+0x20], xmm1
000071c0d83d2974  lea rdi, [rsp]
000071c0d83d2978  mov esi, 0x00
000071c0d83d297d  mov rax, 0x5904ED15D530
000071c0d83d2987  call rax
000071c0d83d2989  movaps xmm6, [rsp]
000071c0d83d298d  add rsp, 0x30
000071c0d83d2991  vmovaps xmm0, [rsp]
000071c0d83d2996  vmovaps xmm1, [rsp+0x10]
000071c0d83d299c  vmovaps xmm2, [rsp+0x20]
000071c0d83d29a2  vmovaps xmm3, [rsp+0x30]
000071c0d83d29a8  vmovaps xmm4, [rsp+0x40]
000071c0d83d29ae  vmovaps xmm5, [rsp+0x50]
000071c0d83d29b4  vmovaps xmm7, [rsp+0x60]
000071c0d83d29ba  vmovaps xmm8, [rsp+0x70]
000071c0d83d29c0  vmovaps xmm9, [rsp+0x80]
000071c0d83d29c9  vmovaps xmm10, [rsp+0x90]
000071c0d83d29d2  vmovaps xmm11, [rsp+0xA0]
000071c0d83d29db  vmovaps xmm12, [rsp+0xB0]
000071c0d83d29e4  vmovaps xmm13, [rsp+0xC0]
000071c0d83d29ed  vmovaps xmm14, [rsp+0xD0]
000071c0d83d29f6  vmovaps xmm15, [rsp+0xE0]
000071c0d83d29ff  add rsp, 0xF0
000071c0d83d2a06  pop r11
000071c0d83d2a08  pop r10
000071c0d83d2a0a  pop r9
000071c0d83d2a0c  pop r8
000071c0d83d2a0e  pop rsi
000071c0d83d2a0f  pop rdi
000071c0d83d2a10  pop rdx
000071c0d83d2a11  pop rcx
000071c0d83d2a12  pop rax
000071c0d83d2a13  add rsp, 0x08
000071c0d83d2a17  jmp 0x000071C0D83CFD98
000071c0d83d2a1c  sub rsp, 0x08
000071c0d83d2a20  push rax
000071c0d83d2a21  push rcx
000071c0d83d2a22  push rdx
000071c0d83d2a23  push rdi
000071c0d83d2a24  push rsi
000071c0d83d2a25  push r8
000071c0d83d2a27  push r9
000071c0d83d2a29  push r10
000071c0d83d2a2b  push r11
000071c0d83d2a2d  sub rsp, 0xF0
000071c0d83d2a34  vmovaps [rsp], xmm0
000071c0d83d2a39  vmovaps [rsp+0x10], xmm2
000071c0d83d2a3f  vmovaps [rsp+0x20], xmm3
000071c0d83d2a45  vmovaps [rsp+0x30], xmm4
000071c0d83d2a4b  vmovaps [rsp+0x40], xmm5
000071c0d83d2a51  vmovaps [rsp+0x50], xmm6
000071c0d83d2a57  vmovaps [rsp+0x60], xmm7
000071c0d83d2a5d  vmovaps [rsp+0x70], xmm8
000071c0d83d2a63  vmovaps [rsp+0x80], xmm9
000071c0d83d2a6c  vmovaps [rsp+0x90], xmm10
000071c0d83d2a75  vmovaps [rsp+0xA0], xmm11
000071c0d83d2a7e  vmovaps [rsp+0xB0], xmm12
000071c0d83d2a87  vmovaps [rsp+0xC0], xmm13
000071c0d83d2a90  vmovaps [rsp+0xD0], xmm14
000071c0d83d2a99  vmovaps [rsp+0xE0], xmm15
000071c0d83d2aa2  sub rsp, 0x30
000071c0d83d2aa6  movaps [rsp], xmm1
000071c0d83d2aaa  movaps [rsp+0x10], xmm5
000071c0d83d2aaf  movaps [rsp+0x20], xmm13
000071c0d83d2ab5  lea rdi, [rsp]
000071c0d83d2ab9  mov esi, 0x00
000071c0d83d2abe  mov rax, 0x5904ED15D530
000071c0d83d2ac8  call rax
000071c0d83d2aca  movaps xmm1, [rsp]
000071c0d83d2ace  add rsp, 0x30
000071c0d83d2ad2  vmovaps xmm0, [rsp]
000071c0d83d2ad7  vmovaps xmm2, [rsp+0x10]
000071c0d83d2add  vmovaps xmm3, [rsp+0x20]
000071c0d83d2ae3  vmovaps xmm4, [rsp+0x30]
000071c0d83d2ae9  vmovaps xmm5, [rsp+0x40]
000071c0d83d2aef  vmovaps xmm6, [rsp+0x50]
000071c0d83d2af5  vmovaps xmm7, [rsp+0x60]
000071c0d83d2afb  vmovaps xmm8, [rsp+0x70]
000071c0d83d2b01  vmovaps xmm9, [rsp+0x80]
000071c0d83d2b0a  vmovaps xmm10, [rsp+0x90]
000071c0d83d2b13  vmovaps xmm11, [rsp+0xA0]
000071c0d83d2b1c  vmovaps xmm12, [rsp+0xB0]
000071c0d83d2b25  vmovaps xmm13, [rsp+0xC0]
000071c0d83d2b2e  vmovaps xmm14, [rsp+0xD0]
000071c0d83d2b37  vmovaps xmm15, [rsp+0xE0]
000071c0d83d2b40  add rsp, 0xF0
000071c0d83d2b47  pop r11
000071c0d83d2b49  pop r10
000071c0d83d2b4b  pop r9
000071c0d83d2b4d  pop r8
000071c0d83d2b4f  pop rsi
000071c0d83d2b50  pop rdi
000071c0d83d2b51  pop rdx
000071c0d83d2b52  pop rcx
000071c0d83d2b53  pop rax
000071c0d83d2b54  add rsp, 0x08
000071c0d83d2b58  jmp 0x000071C0D83CFDB6
000071c0d83d2b5d  sub rsp, 0x08
000071c0d83d2b61  push rax
000071c0d83d2b62  push rcx
000071c0d83d2b63  push rdx
000071c0d83d2b64  push rdi
000071c0d83d2b65  push rsi
000071c0d83d2b66  push r8
000071c0d83d2b68  push r9
000071c0d83d2b6a  push r10
000071c0d83d2b6c  push r11
000071c0d83d2b6e  sub rsp, 0xF0
000071c0d83d2b75  vmovaps [rsp], xmm0
000071c0d83d2b7a  vmovaps [rsp+0x10], xmm1
000071c0d83d2b80  vmovaps [rsp+0x20], xmm2
000071c0d83d2b86  vmovaps [rsp+0x30], xmm3
000071c0d83d2b8c  vmovaps [rsp+0x40], xmm4
000071c0d83d2b92  vmovaps [rsp+0x50], xmm6
000071c0d83d2b98  vmovaps [rsp+0x60], xmm7
000071c0d83d2b9e  vmovaps [rsp+0x70], xmm8
000071c0d83d2ba4  vmovaps [rsp+0x80], xmm9
000071c0d83d2bad  vmovaps [rsp+0x90], xmm10
000071c0d83d2bb6  vmovaps [rsp+0xA0], xmm11
000071c0d83d2bbf  vmovaps [rsp+0xB0], xmm12
000071c0d83d2bc8  vmovaps [rsp+0xC0], xmm13
000071c0d83d2bd1  vmovaps [rsp+0xD0], xmm14
000071c0d83d2bda  vmovaps [rsp+0xE0], xmm15
000071c0d83d2be3  sub rsp, 0x30
000071c0d83d2be7  movaps [rsp], xmm5
000071c0d83d2beb  movaps [rsp+0x10], xmm2
000071c0d83d2bf0  movaps [rsp+0x20], xmm13
000071c0d83d2bf6  lea rdi, [rsp]
000071c0d83d2bfa  mov esi, 0x00
000071c0d83d2bff  mov rax, 0x5904ED15D530
000071c0d83d2c09  call rax
000071c0d83d2c0b  movaps xmm5, [rsp]
000071c0d83d2c0f  add rsp, 0x30
000071c0d83d2c13  vmovaps xmm0, [rsp]
000071c0d83d2c18  vmovaps xmm1, [rsp+0x10]
000071c0d83d2c1e  vmovaps xmm2, [rsp+0x20]
000071c0d83d2c24  vmovaps xmm3, [rsp+0x30]
000071c0d83d2c2a  vmovaps xmm4, [rsp+0x40]
000071c0d83d2c30  vmovaps xmm6, [rsp+0x50]
000071c0d83d2c36  vmovaps xmm7, [rsp+0x60]
000071c0d83d2c3c  vmovaps xmm8, [rsp+0x70]
000071c0d83d2c42  vmovaps xmm9, [rsp+0x80]
000071c0d83d2c4b  vmovaps xmm10, [rsp+0x90]
000071c0d83d2c54  vmovaps xmm11, [rsp+0xA0]
000071c0d83d2c5d  vmovaps xmm12, [rsp+0xB0]
000071c0d83d2c66  vmovaps xmm13, [rsp+0xC0]
000071c0d83d2c6f  vmovaps xmm14, [rsp+0xD0]
000071c0d83d2c78  vmovaps xmm15, [rsp+0xE0]
000071c0d83d2c81  add rsp, 0xF0
000071c0d83d2c88  pop r11
000071c0d83d2c8a  pop r10
000071c0d83d2c8c  pop r9
000071c0d83d2c8e  pop r8
000071c0d83d2c90  pop rsi
000071c0d83d2c91  pop rdi
000071c0d83d2c92  pop rdx
000071c0d83d2c93  pop rcx
000071c0d83d2c94  pop rax
000071c0d83d2c95  add rsp, 0x08
000071c0d83d2c99  jmp 0x000071C0D83CFDEC
000071c0d83d2c9e  sub rsp, 0x08
000071c0d83d2ca2  push rax
000071c0d83d2ca3  push rcx
000071c0d83d2ca4  push rdx
000071c0d83d2ca5  push rdi
000071c0d83d2ca6  push rsi
000071c0d83d2ca7  push r8
000071c0d83d2ca9  push r9
000071c0d83d2cab  push r10
000071c0d83d2cad  push r11
000071c0d83d2caf  sub rsp, 0xF0
000071c0d83d2cb6  vmovaps [rsp], xmm0
000071c0d83d2cbb  vmovaps [rsp+0x10], xmm1
000071c0d83d2cc1  vmovaps [rsp+0x20], xmm2
000071c0d83d2cc7  vmovaps [rsp+0x30], xmm3
000071c0d83d2ccd  vmovaps [rsp+0x40], xmm4
000071c0d83d2cd3  vmovaps [rsp+0x50], xmm5
000071c0d83d2cd9  vmovaps [rsp+0x60], xmm6
000071c0d83d2cdf  vmovaps [rsp+0x70], xmm7
000071c0d83d2ce5  vmovaps [rsp+0x80], xmm8
000071c0d83d2cee  vmovaps [rsp+0x90], xmm9
000071c0d83d2cf7  vmovaps [rsp+0xA0], xmm10
000071c0d83d2d00  vmovaps [rsp+0xB0], xmm11
000071c0d83d2d09  vmovaps [rsp+0xC0], xmm12
000071c0d83d2d12  vmovaps [rsp+0xD0], xmm14
000071c0d83d2d1b  vmovaps [rsp+0xE0], xmm15
000071c0d83d2d24  sub rsp, 0x30
000071c0d83d2d28  movaps [rsp], xmm13
000071c0d83d2d2d  movaps [rsp+0x10], xmm10
000071c0d83d2d33  movaps [rsp+0x20], xmm1
000071c0d83d2d38  lea rdi, [rsp]
000071c0d83d2d3c  mov esi, 0x00
000071c0d83d2d41  mov rax, 0x5904ED15D530
000071c0d83d2d4b  call rax
000071c0d83d2d4d  movaps xmm13, [rsp]
000071c0d83d2d52  add rsp, 0x30
000071c0d83d2d56  vmovaps xmm0, [rsp]
000071c0d83d2d5b  vmovaps xmm1, [rsp+0x10]
000071c0d83d2d61  vmovaps xmm2, [rsp+0x20]
000071c0d83d2d67  vmovaps xmm3, [rsp+0x30]
000071c0d83d2d6d  vmovaps xmm4, [rsp+0x40]
000071c0d83d2d73  vmovaps xmm5, [rsp+0x50]
000071c0d83d2d79  vmovaps xmm6, [rsp+0x60]
000071c0d83d2d7f  vmovaps xmm7, [rsp+0x70]
000071c0d83d2d85  vmovaps xmm8, [rsp+0x80]
000071c0d83d2d8e  vmovaps xmm9, [rsp+0x90]
000071c0d83d2d97  vmovaps xmm10, [rsp+0xA0]
000071c0d83d2da0  vmovaps xmm11, [rsp+0xB0]
000071c0d83d2da9  vmovaps xmm12, [rsp+0xC0]
000071c0d83d2db2  vmovaps xmm14, [rsp+0xD0]
000071c0d83d2dbb  vmovaps xmm15, [rsp+0xE0]
000071c0d83d2dc4  add rsp, 0xF0
000071c0d83d2dcb  pop r11
000071c0d83d2dcd  pop r10
000071c0d83d2dcf  pop r9
000071c0d83d2dd1  pop r8
000071c0d83d2dd3  pop rsi
000071c0d83d2dd4  pop rdi
000071c0d83d2dd5  pop rdx
000071c0d83d2dd6  pop rcx
000071c0d83d2dd7  pop rax
000071c0d83d2dd8  add rsp, 0x08
000071c0d83d2ddc  jmp 0x000071C0D83CFE15
000071c0d83d2de1  sub rsp, 0x08
000071c0d83d2de5  push rax
000071c0d83d2de6  push rcx
000071c0d83d2de7  push rdx
000071c0d83d2de8  push rdi
000071c0d83d2de9  push rsi
000071c0d83d2dea  push r8
000071c0d83d2dec  push r9
000071c0d83d2dee  push r10
000071c0d83d2df0  push r11
000071c0d83d2df2  sub rsp, 0xF0
000071c0d83d2df9  vmovaps [rsp], xmm0
000071c0d83d2dfe  vmovaps [rsp+0x10], xmm2
000071c0d83d2e04  vmovaps [rsp+0x20], xmm3
000071c0d83d2e0a  vmovaps [rsp+0x30], xmm4
000071c0d83d2e10  vmovaps [rsp+0x40], xmm5
000071c0d83d2e16  vmovaps [rsp+0x50], xmm6
000071c0d83d2e1c  vmovaps [rsp+0x60], xmm7
000071c0d83d2e22  vmovaps [rsp+0x70], xmm8
000071c0d83d2e28  vmovaps [rsp+0x80], xmm9
000071c0d83d2e31  vmovaps [rsp+0x90], xmm10
000071c0d83d2e3a  vmovaps [rsp+0xA0], xmm11
000071c0d83d2e43  vmovaps [rsp+0xB0], xmm12
000071c0d83d2e4c  vmovaps [rsp+0xC0], xmm13
000071c0d83d2e55  vmovaps [rsp+0xD0], xmm14
000071c0d83d2e5e  vmovaps [rsp+0xE0], xmm15
000071c0d83d2e67  sub rsp, 0x30
000071c0d83d2e6b  movaps [rsp], xmm1
000071c0d83d2e6f  movaps [rsp+0x10], xmm15
000071c0d83d2e75  movaps [rsp+0x20], xmm10
000071c0d83d2e7b  lea rdi, [rsp]
000071c0d83d2e7f  mov esi, 0x00
000071c0d83d2e84  mov rax, 0x5904ED15D530
000071c0d83d2e8e  call rax
000071c0d83d2e90  movaps xmm1, [rsp]
000071c0d83d2e94  add rsp, 0x30
000071c0d83d2e98  vmovaps xmm0, [rsp]
000071c0d83d2e9d  vmovaps xmm2, [rsp+0x10]
000071c0d83d2ea3  vmovaps xmm3, [rsp+0x20]
000071c0d83d2ea9  vmovaps xmm4, [rsp+0x30]
000071c0d83d2eaf  vmovaps xmm5, [rsp+0x40]
000071c0d83d2eb5  vmovaps xmm6, [rsp+0x50]
000071c0d83d2ebb  vmovaps xmm7, [rsp+0x60]
000071c0d83d2ec1  vmovaps xmm8, [rsp+0x70]
000071c0d83d2ec7  vmovaps xmm9, [rsp+0x80]
000071c0d83d2ed0  vmovaps xmm10, [rsp+0x90]
000071c0d83d2ed9  vmovaps xmm11, [rsp+0xA0]
000071c0d83d2ee2  vmovaps xmm12, [rsp+0xB0]
000071c0d83d2eeb  vmovaps xmm13, [rsp+0xC0]
000071c0d83d2ef4  vmovaps xmm14, [rsp+0xD0]
000071c0d83d2efd  vmovaps xmm15, [rsp+0xE0]
000071c0d83d2f06  add rsp, 0xF0
000071c0d83d2f0d  pop r11
000071c0d83d2f0f  pop r10
000071c0d83d2f11  pop r9
000071c0d83d2f13  pop r8
000071c0d83d2f15  pop rsi
000071c0d83d2f16  pop rdi
000071c0d83d2f17  pop rdx
000071c0d83d2f18  pop rcx
000071c0d83d2f19  pop rax
000071c0d83d2f1a  add rsp, 0x08
000071c0d83d2f1e  jmp 0x000071C0D83CFE34
000071c0d83d2f23  sub rsp, 0x08
000071c0d83d2f27  push rax
000071c0d83d2f28  push rcx
000071c0d83d2f29  push rdx
000071c0d83d2f2a  push rdi
000071c0d83d2f2b  push rsi
000071c0d83d2f2c  push r8
000071c0d83d2f2e  push r9
000071c0d83d2f30  push r10
000071c0d83d2f32  push r11
000071c0d83d2f34  sub rsp, 0xF0
000071c0d83d2f3b  vmovaps [rsp], xmm0
000071c0d83d2f40  vmovaps [rsp+0x10], xmm1
000071c0d83d2f46  vmovaps [rsp+0x20], xmm2
000071c0d83d2f4c  vmovaps [rsp+0x30], xmm3
000071c0d83d2f52  vmovaps [rsp+0x40], xmm4
000071c0d83d2f58  vmovaps [rsp+0x50], xmm5
000071c0d83d2f5e  vmovaps [rsp+0x60], xmm6
000071c0d83d2f64  vmovaps [rsp+0x70], xmm7
000071c0d83d2f6a  vmovaps [rsp+0x80], xmm8
000071c0d83d2f73  vmovaps [rsp+0x90], xmm9
000071c0d83d2f7c  vmovaps [rsp+0xA0], xmm10
000071c0d83d2f85  vmovaps [rsp+0xB0], xmm11
000071c0d83d2f8e  vmovaps [rsp+0xC0], xmm12
000071c0d83d2f97  vmovaps [rsp+0xD0], xmm13
000071c0d83d2fa0  vmovaps [rsp+0xE0], xmm14
000071c0d83d2fa9  sub rsp, 0x30
000071c0d83d2fad  movaps [rsp], xmm15
000071c0d83d2fb2  movaps [rsp+0x10], xmm10
000071c0d83d2fb8  movaps [rsp+0x20], xmm11
000071c0d83d2fbe  lea rdi, [rsp]
000071c0d83d2fc2  mov esi, 0x00
000071c0d83d2fc7  mov rax, 0x5904ED15D530
000071c0d83d2fd1  call rax
000071c0d83d2fd3  movaps xmm15, [rsp]
000071c0d83d2fd8  add rsp, 0x30
000071c0d83d2fdc  vmovaps xmm0, [rsp]
000071c0d83d2fe1  vmovaps xmm1, [rsp+0x10]
000071c0d83d2fe7  vmovaps xmm2, [rsp+0x20]
000071c0d83d2fed  vmovaps xmm3, [rsp+0x30]
000071c0d83d2ff3  vmovaps xmm4, [rsp+0x40]
000071c0d83d2ff9  vmovaps xmm5, [rsp+0x50]
000071c0d83d2fff  vmovaps xmm6, [rsp+0x60]
000071c0d83d3005  vmovaps xmm7, [rsp+0x70]
000071c0d83d300b  vmovaps xmm8, [rsp+0x80]
000071c0d83d3014  vmovaps xmm9, [rsp+0x90]
000071c0d83d301d  vmovaps xmm10, [rsp+0xA0]
000071c0d83d3026  vmovaps xmm11, [rsp+0xB0]
000071c0d83d302f  vmovaps xmm12, [rsp+0xC0]
000071c0d83d3038  vmovaps xmm13, [rsp+0xD0]
000071c0d83d3041  vmovaps xmm14, [rsp+0xE0]
000071c0d83d304a  add rsp, 0xF0
000071c0d83d3051  pop r11
000071c0d83d3053  pop r10
000071c0d83d3055  pop r9
000071c0d83d3057  pop r8
000071c0d83d3059  pop rsi
000071c0d83d305a  pop rdi
000071c0d83d305b  pop rdx
000071c0d83d305c  pop rcx
000071c0d83d305d  pop rax
000071c0d83d305e  add rsp, 0x08
000071c0d83d3062  jmp 0x000071C0D83CFE57
000071c0d83d3067  sub rsp, 0x08
000071c0d83d306b  push rax
000071c0d83d306c  push rcx
000071c0d83d306d  push rdx
000071c0d83d306e  push rdi
000071c0d83d306f  push rsi
000071c0d83d3070  push r8
000071c0d83d3072  push r9
000071c0d83d3074  push r10
000071c0d83d3076  push r11
000071c0d83d3078  sub rsp, 0xF0
000071c0d83d307f  vmovaps [rsp], xmm0
000071c0d83d3084  vmovaps [rsp+0x10], xmm1
000071c0d83d308a  vmovaps [rsp+0x20], xmm2
000071c0d83d3090  vmovaps [rsp+0x30], xmm3
000071c0d83d3096  vmovaps [rsp+0x40], xmm4
000071c0d83d309c  vmovaps [rsp+0x50], xmm5
000071c0d83d30a2  vmovaps [rsp+0x60], xmm6
000071c0d83d30a8  vmovaps [rsp+0x70], xmm7
000071c0d83d30ae  vmovaps [rsp+0x80], xmm8
000071c0d83d30b7  vmovaps [rsp+0x90], xmm9
000071c0d83d30c0  vmovaps [rsp+0xA0], xmm11
000071c0d83d30c9  vmovaps [rsp+0xB0], xmm12
000071c0d83d30d2  vmovaps [rsp+0xC0], xmm13
000071c0d83d30db  vmovaps [rsp+0xD0], xmm14
000071c0d83d30e4  vmovaps [rsp+0xE0], xmm15
000071c0d83d30ed  sub rsp, 0x30
000071c0d83d30f1  movaps [rsp], xmm10
000071c0d83d30f6  movaps [rsp+0x10], xmm12
000071c0d83d30fc  movaps [rsp+0x20], xmm11
000071c0d83d3102  lea rdi, [rsp]
000071c0d83d3106  mov esi, 0x00
000071c0d83d310b  mov rax, 0x5904ED15D530
000071c0d83d3115  call rax
000071c0d83d3117  movaps xmm10, [rsp]
000071c0d83d311c  add rsp, 0x30
000071c0d83d3120  vmovaps xmm0, [rsp]
000071c0d83d3125  vmovaps xmm1, [rsp+0x10]
000071c0d83d312b  vmovaps xmm2, [rsp+0x20]
000071c0d83d3131  vmovaps xmm3, [rsp+0x30]
000071c0d83d3137  vmovaps xmm4, [rsp+0x40]
000071c0d83d313d  vmovaps xmm5, [rsp+0x50]
000071c0d83d3143  vmovaps xmm6, [rsp+0x60]
000071c0d83d3149  vmovaps xmm7, [rsp+0x70]
000071c0d83d314f  vmovaps xmm8, [rsp+0x80]
000071c0d83d3158  vmovaps xmm9, [rsp+0x90]
000071c0d83d3161  vmovaps xmm11, [rsp+0xA0]
000071c0d83d316a  vmovaps xmm12, [rsp+0xB0]
000071c0d83d3173  vmovaps xmm13, [rsp+0xC0]
000071c0d83d317c  vmovaps xmm14, [rsp+0xD0]
000071c0d83d3185  vmovaps xmm15, [rsp+0xE0]
000071c0d83d318e  add rsp, 0xF0
000071c0d83d3195  pop r11
000071c0d83d3197  pop r10
000071c0d83d3199  pop r9
000071c0d83d319b  pop r8
000071c0d83d319d  pop rsi
000071c0d83d319e  pop rdi
000071c0d83d319f  pop rdx
000071c0d83d31a0  pop rcx
000071c0d83d31a1  pop rax
000071c0d83d31a2  add rsp, 0x08
000071c0d83d31a6  jmp 0x000071C0D83CFE80
000071c0d83d31ab  sub rsp, 0x08
000071c0d83d31af  push rax
000071c0d83d31b0  push rcx
000071c0d83d31b1  push rdx
000071c0d83d31b2  push rdi
000071c0d83d31b3  push rsi
000071c0d83d31b4  push r8
000071c0d83d31b6  push r9
000071c0d83d31b8  push r10
000071c0d83d31ba  push r11
000071c0d83d31bc  sub rsp, 0xF0
000071c0d83d31c3  vmovaps [rsp], xmm0
000071c0d83d31c8  vmovaps [rsp+0x10], xmm1
000071c0d83d31ce  vmovaps [rsp+0x20], xmm2
000071c0d83d31d4  vmovaps [rsp+0x30], xmm3
000071c0d83d31da  vmovaps [rsp+0x40], xmm4
000071c0d83d31e0  vmovaps [rsp+0x50], xmm5
000071c0d83d31e6  vmovaps [rsp+0x60], xmm6
000071c0d83d31ec  vmovaps [rsp+0x70], xmm7
000071c0d83d31f2  vmovaps [rsp+0x80], xmm8
000071c0d83d31fb  vmovaps [rsp+0x90], xmm9
000071c0d83d3204  vmovaps [rsp+0xA0], xmm10
000071c0d83d320d  vmovaps [rsp+0xB0], xmm12
000071c0d83d3216  vmovaps [rsp+0xC0], xmm13
000071c0d83d321f  vmovaps [rsp+0xD0], xmm14
000071c0d83d3228  vmovaps [rsp+0xE0], xmm15
000071c0d83d3231  sub rsp, 0x30
000071c0d83d3235  movaps [rsp], xmm11
000071c0d83d323a  movaps [rsp+0x10], xmm2
000071c0d83d323f  movaps [rsp+0x20], xmm12
000071c0d83d3245  lea rdi, [rsp]
000071c0d83d3249  mov esi, 0x00
000071c0d83d324e  mov rax, 0x5904ED15D530
000071c0d83d3258  call rax
000071c0d83d325a  movaps xmm11, [rsp]
000071c0d83d325f  add rsp, 0x30
000071c0d83d3263  vmovaps xmm0, [rsp]
000071c0d83d3268  vmovaps xmm1, [rsp+0x10]
000071c0d83d326e  vmovaps xmm2, [rsp+0x20]
000071c0d83d3274  vmovaps xmm3, [rsp+0x30]
000071c0d83d327a  vmovaps xmm4, [rsp+0x40]
000071c0d83d3280  vmovaps xmm5, [rsp+0x50]
000071c0d83d3286  vmovaps xmm6, [rsp+0x60]
000071c0d83d328c  vmovaps xmm7, [rsp+0x70]
000071c0d83d3292  vmovaps xmm8, [rsp+0x80]
000071c0d83d329b  vmovaps xmm9, [rsp+0x90]
000071c0d83d32a4  vmovaps xmm10, [rsp+0xA0]
000071c0d83d32ad  vmovaps xmm12, [rsp+0xB0]
000071c0d83d32b6  vmovaps xmm13, [rsp+0xC0]
000071c0d83d32bf  vmovaps xmm14, [rsp+0xD0]
000071c0d83d32c8  vmovaps xmm15, [rsp+0xE0]
000071c0d83d32d1  add rsp, 0xF0
000071c0d83d32d8  pop r11
000071c0d83d32da  pop r10
000071c0d83d32dc  pop r9
000071c0d83d32de  pop r8
000071c0d83d32e0  pop rsi
000071c0d83d32e1  pop rdi
000071c0d83d32e2  pop rdx
000071c0d83d32e3  pop rcx
000071c0d83d32e4  pop rax
000071c0d83d32e5  add rsp, 0x08
000071c0d83d32e9  jmp 0x000071C0D83CFEB8
000071c0d83d32ee  sub rsp, 0x08
000071c0d83d32f2  push rax
000071c0d83d32f3  push rcx
000071c0d83d32f4  push rdx
000071c0d83d32f5  push rdi
000071c0d83d32f6  push rsi
000071c0d83d32f7  push r8
000071c0d83d32f9  push r9
000071c0d83d32fb  push r10
000071c0d83d32fd  push r11
000071c0d83d32ff  sub rsp, 0xF0
000071c0d83d3306  vmovaps [rsp], xmm0
000071c0d83d330b  vmovaps [rsp+0x10], xmm2
000071c0d83d3311  vmovaps [rsp+0x20], xmm3
000071c0d83d3317  vmovaps [rsp+0x30], xmm4
000071c0d83d331d  vmovaps [rsp+0x40], xmm5
000071c0d83d3323  vmovaps [rsp+0x50], xmm6
000071c0d83d3329  vmovaps [rsp+0x60], xmm7
000071c0d83d332f  vmovaps [rsp+0x70], xmm8
000071c0d83d3335  vmovaps [rsp+0x80], xmm9
000071c0d83d333e  vmovaps [rsp+0x90], xmm10
000071c0d83d3347  vmovaps [rsp+0xA0], xmm11
000071c0d83d3350  vmovaps [rsp+0xB0], xmm12
000071c0d83d3359  vmovaps [rsp+0xC0], xmm13
000071c0d83d3362  vmovaps [rsp+0xD0], xmm14
000071c0d83d336b  vmovaps [rsp+0xE0], xmm15
000071c0d83d3374  sub rsp, 0x30
000071c0d83d3378  movaps [rsp], xmm1
000071c0d83d337c  movaps [rsp+0x10], xmm14
000071c0d83d3382  movaps [rsp+0x20], xmm6
000071c0d83d3387  lea rdi, [rsp]
000071c0d83d338b  mov esi, 0x00
000071c0d83d3390  mov rax, 0x5904ED15D530
000071c0d83d339a  call rax
000071c0d83d339c  movaps xmm1, [rsp]
000071c0d83d33a0  add rsp, 0x30
000071c0d83d33a4  vmovaps xmm0, [rsp]
000071c0d83d33a9  vmovaps xmm2, [rsp+0x10]
000071c0d83d33af  vmovaps xmm3, [rsp+0x20]
000071c0d83d33b5  vmovaps xmm4, [rsp+0x30]
000071c0d83d33bb  vmovaps xmm5, [rsp+0x40]
000071c0d83d33c1  vmovaps xmm6, [rsp+0x50]
000071c0d83d33c7  vmovaps xmm7, [rsp+0x60]
000071c0d83d33cd  vmovaps xmm8, [rsp+0x70]
000071c0d83d33d3  vmovaps xmm9, [rsp+0x80]
000071c0d83d33dc  vmovaps xmm10, [rsp+0x90]
000071c0d83d33e5  vmovaps xmm11, [rsp+0xA0]
000071c0d83d33ee  vmovaps xmm12, [rsp+0xB0]
000071c0d83d33f7  vmovaps xmm13, [rsp+0xC0]
000071c0d83d3400  vmovaps xmm14, [rsp+0xD0]
000071c0d83d3409  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3412  add rsp, 0xF0
000071c0d83d3419  pop r11
000071c0d83d341b  pop r10
000071c0d83d341d  pop r9
000071c0d83d341f  pop r8
000071c0d83d3421  pop rsi
000071c0d83d3422  pop rdi
000071c0d83d3423  pop rdx
000071c0d83d3424  pop rcx
000071c0d83d3425  pop rax
000071c0d83d3426  add rsp, 0x08
000071c0d83d342a  jmp 0x000071C0D83CFED1
000071c0d83d342f  sub rsp, 0x08
000071c0d83d3433  push rax
000071c0d83d3434  push rcx
000071c0d83d3435  push rdx
000071c0d83d3436  push rdi
000071c0d83d3437  push rsi
000071c0d83d3438  push r8
000071c0d83d343a  push r9
000071c0d83d343c  push r10
000071c0d83d343e  push r11
000071c0d83d3440  sub rsp, 0xF0
000071c0d83d3447  vmovaps [rsp], xmm0
000071c0d83d344c  vmovaps [rsp+0x10], xmm1
000071c0d83d3452  vmovaps [rsp+0x20], xmm2
000071c0d83d3458  vmovaps [rsp+0x30], xmm3
000071c0d83d345e  vmovaps [rsp+0x40], xmm4
000071c0d83d3464  vmovaps [rsp+0x50], xmm5
000071c0d83d346a  vmovaps [rsp+0x60], xmm6
000071c0d83d3470  vmovaps [rsp+0x70], xmm7
000071c0d83d3476  vmovaps [rsp+0x80], xmm8
000071c0d83d347f  vmovaps [rsp+0x90], xmm9
000071c0d83d3488  vmovaps [rsp+0xA0], xmm10
000071c0d83d3491  vmovaps [rsp+0xB0], xmm11
000071c0d83d349a  vmovaps [rsp+0xC0], xmm12
000071c0d83d34a3  vmovaps [rsp+0xD0], xmm13
000071c0d83d34ac  vmovaps [rsp+0xE0], xmm15
000071c0d83d34b5  sub rsp, 0x30
000071c0d83d34b9  movaps [rsp], xmm14
000071c0d83d34be  movaps [rsp+0x10], xmm12
000071c0d83d34c4  movaps [rsp+0x20], xmm5
000071c0d83d34c9  lea rdi, [rsp]
000071c0d83d34cd  mov esi, 0x00
000071c0d83d34d2  mov rax, 0x5904ED15D530
000071c0d83d34dc  call rax
000071c0d83d34de  movaps xmm14, [rsp]
000071c0d83d34e3  add rsp, 0x30
000071c0d83d34e7  vmovaps xmm0, [rsp]
000071c0d83d34ec  vmovaps xmm1, [rsp+0x10]
000071c0d83d34f2  vmovaps xmm2, [rsp+0x20]
000071c0d83d34f8  vmovaps xmm3, [rsp+0x30]
000071c0d83d34fe  vmovaps xmm4, [rsp+0x40]
000071c0d83d3504  vmovaps xmm5, [rsp+0x50]
000071c0d83d350a  vmovaps xmm6, [rsp+0x60]
000071c0d83d3510  vmovaps xmm7, [rsp+0x70]
000071c0d83d3516  vmovaps xmm8, [rsp+0x80]
000071c0d83d351f  vmovaps xmm9, [rsp+0x90]
000071c0d83d3528  vmovaps xmm10, [rsp+0xA0]
000071c0d83d3531  vmovaps xmm11, [rsp+0xB0]
000071c0d83d353a  vmovaps xmm12, [rsp+0xC0]
000071c0d83d3543  vmovaps xmm13, [rsp+0xD0]
000071c0d83d354c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3555  add rsp, 0xF0
000071c0d83d355c  pop r11
000071c0d83d355e  pop r10
000071c0d83d3560  pop r9
000071c0d83d3562  pop r8
000071c0d83d3564  pop rsi
000071c0d83d3565  pop rdi
000071c0d83d3566  pop rdx
000071c0d83d3567  pop rcx
000071c0d83d3568  pop rax
000071c0d83d3569  add rsp, 0x08
000071c0d83d356d  jmp 0x000071C0D83CFEF1
000071c0d83d3572  sub rsp, 0x08
000071c0d83d3576  push rax
000071c0d83d3577  push rcx
000071c0d83d3578  push rdx
000071c0d83d3579  push rdi
000071c0d83d357a  push rsi
000071c0d83d357b  push r8
000071c0d83d357d  push r9
000071c0d83d357f  push r10
000071c0d83d3581  push r11
000071c0d83d3583  sub rsp, 0xF0
000071c0d83d358a  vmovaps [rsp], xmm0
000071c0d83d358f  vmovaps [rsp+0x10], xmm1
000071c0d83d3595  vmovaps [rsp+0x20], xmm2
000071c0d83d359b  vmovaps [rsp+0x30], xmm3
000071c0d83d35a1  vmovaps [rsp+0x40], xmm4
000071c0d83d35a7  vmovaps [rsp+0x50], xmm5
000071c0d83d35ad  vmovaps [rsp+0x60], xmm7
000071c0d83d35b3  vmovaps [rsp+0x70], xmm8
000071c0d83d35b9  vmovaps [rsp+0x80], xmm9
000071c0d83d35c2  vmovaps [rsp+0x90], xmm10
000071c0d83d35cb  vmovaps [rsp+0xA0], xmm11
000071c0d83d35d4  vmovaps [rsp+0xB0], xmm12
000071c0d83d35dd  vmovaps [rsp+0xC0], xmm13
000071c0d83d35e6  vmovaps [rsp+0xD0], xmm14
000071c0d83d35ef  vmovaps [rsp+0xE0], xmm15
000071c0d83d35f8  sub rsp, 0x30
000071c0d83d35fc  movaps [rsp], xmm6
000071c0d83d3600  movaps [rsp+0x10], xmm9
000071c0d83d3606  movaps [rsp+0x20], xmm12
000071c0d83d360c  lea rdi, [rsp]
000071c0d83d3610  mov esi, 0x00
000071c0d83d3615  mov rax, 0x5904ED15D530
000071c0d83d361f  call rax
000071c0d83d3621  movaps xmm6, [rsp]
000071c0d83d3625  add rsp, 0x30
000071c0d83d3629  vmovaps xmm0, [rsp]
000071c0d83d362e  vmovaps xmm1, [rsp+0x10]
000071c0d83d3634  vmovaps xmm2, [rsp+0x20]
000071c0d83d363a  vmovaps xmm3, [rsp+0x30]
000071c0d83d3640  vmovaps xmm4, [rsp+0x40]
000071c0d83d3646  vmovaps xmm5, [rsp+0x50]
000071c0d83d364c  vmovaps xmm7, [rsp+0x60]
000071c0d83d3652  vmovaps xmm8, [rsp+0x70]
000071c0d83d3658  vmovaps xmm9, [rsp+0x80]
000071c0d83d3661  vmovaps xmm10, [rsp+0x90]
000071c0d83d366a  vmovaps xmm11, [rsp+0xA0]
000071c0d83d3673  vmovaps xmm12, [rsp+0xB0]
000071c0d83d367c  vmovaps xmm13, [rsp+0xC0]
000071c0d83d3685  vmovaps xmm14, [rsp+0xD0]
000071c0d83d368e  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3697  add rsp, 0xF0
000071c0d83d369e  pop r11
000071c0d83d36a0  pop r10
000071c0d83d36a2  pop r9
000071c0d83d36a4  pop r8
000071c0d83d36a6  pop rsi
000071c0d83d36a7  pop rdi
000071c0d83d36a8  pop rdx
000071c0d83d36a9  pop rcx
000071c0d83d36aa  pop rax
000071c0d83d36ab  add rsp, 0x08
000071c0d83d36af  jmp 0x000071C0D83CFF19
000071c0d83d36b4  sub rsp, 0x08
000071c0d83d36b8  push rax
000071c0d83d36b9  push rcx
000071c0d83d36ba  push rdx
000071c0d83d36bb  push rdi
000071c0d83d36bc  push rsi
000071c0d83d36bd  push r8
000071c0d83d36bf  push r9
000071c0d83d36c1  push r10
000071c0d83d36c3  push r11
000071c0d83d36c5  sub rsp, 0xF0
000071c0d83d36cc  vmovaps [rsp], xmm0
000071c0d83d36d1  vmovaps [rsp+0x10], xmm1
000071c0d83d36d7  vmovaps [rsp+0x20], xmm2
000071c0d83d36dd  vmovaps [rsp+0x30], xmm3
000071c0d83d36e3  vmovaps [rsp+0x40], xmm4
000071c0d83d36e9  vmovaps [rsp+0x50], xmm5
000071c0d83d36ef  vmovaps [rsp+0x60], xmm6
000071c0d83d36f5  vmovaps [rsp+0x70], xmm7
000071c0d83d36fb  vmovaps [rsp+0x80], xmm8
000071c0d83d3704  vmovaps [rsp+0x90], xmm9
000071c0d83d370d  vmovaps [rsp+0xA0], xmm10
000071c0d83d3716  vmovaps [rsp+0xB0], xmm11
000071c0d83d371f  vmovaps [rsp+0xC0], xmm13
000071c0d83d3728  vmovaps [rsp+0xD0], xmm14
000071c0d83d3731  vmovaps [rsp+0xE0], xmm15
000071c0d83d373a  sub rsp, 0x30
000071c0d83d373e  movaps [rsp], xmm12
000071c0d83d3743  movaps [rsp+0x10], xmm15
000071c0d83d3749  movaps [rsp+0x20], xmm13
000071c0d83d374f  lea rdi, [rsp]
000071c0d83d3753  mov esi, 0x00
000071c0d83d3758  mov rax, 0x5904ED15D530
000071c0d83d3762  call rax
000071c0d83d3764  movaps xmm12, [rsp]
000071c0d83d3769  add rsp, 0x30
000071c0d83d376d  vmovaps xmm0, [rsp]
000071c0d83d3772  vmovaps xmm1, [rsp+0x10]
000071c0d83d3778  vmovaps xmm2, [rsp+0x20]
000071c0d83d377e  vmovaps xmm3, [rsp+0x30]
000071c0d83d3784  vmovaps xmm4, [rsp+0x40]
000071c0d83d378a  vmovaps xmm5, [rsp+0x50]
000071c0d83d3790  vmovaps xmm6, [rsp+0x60]
000071c0d83d3796  vmovaps xmm7, [rsp+0x70]
000071c0d83d379c  vmovaps xmm8, [rsp+0x80]
000071c0d83d37a5  vmovaps xmm9, [rsp+0x90]
000071c0d83d37ae  vmovaps xmm10, [rsp+0xA0]
000071c0d83d37b7  vmovaps xmm11, [rsp+0xB0]
000071c0d83d37c0  vmovaps xmm13, [rsp+0xC0]
000071c0d83d37c9  vmovaps xmm14, [rsp+0xD0]
000071c0d83d37d2  vmovaps xmm15, [rsp+0xE0]
000071c0d83d37db  add rsp, 0xF0
000071c0d83d37e2  pop r11
000071c0d83d37e4  pop r10
000071c0d83d37e6  pop r9
000071c0d83d37e8  pop r8
000071c0d83d37ea  pop rsi
000071c0d83d37eb  pop rdi
000071c0d83d37ec  pop rdx
000071c0d83d37ed  pop rcx
000071c0d83d37ee  pop rax
000071c0d83d37ef  add rsp, 0x08
000071c0d83d37f3  jmp 0x000071C0D83CFF34
000071c0d83d37f8  sub rsp, 0x08
000071c0d83d37fc  push rax
000071c0d83d37fd  push rcx
000071c0d83d37fe  push rdx
000071c0d83d37ff  push rdi
000071c0d83d3800  push rsi
000071c0d83d3801  push r8
000071c0d83d3803  push r9
000071c0d83d3805  push r10
000071c0d83d3807  push r11
000071c0d83d3809  sub rsp, 0xF0
000071c0d83d3810  vmovaps [rsp], xmm0
000071c0d83d3815  vmovaps [rsp+0x10], xmm1
000071c0d83d381b  vmovaps [rsp+0x20], xmm2
000071c0d83d3821  vmovaps [rsp+0x30], xmm3
000071c0d83d3827  vmovaps [rsp+0x40], xmm4
000071c0d83d382d  vmovaps [rsp+0x50], xmm5
000071c0d83d3833  vmovaps [rsp+0x60], xmm6
000071c0d83d3839  vmovaps [rsp+0x70], xmm7
000071c0d83d383f  vmovaps [rsp+0x80], xmm8
000071c0d83d3848  vmovaps [rsp+0x90], xmm9
000071c0d83d3851  vmovaps [rsp+0xA0], xmm10
000071c0d83d385a  vmovaps [rsp+0xB0], xmm11
000071c0d83d3863  vmovaps [rsp+0xC0], xmm12
000071c0d83d386c  vmovaps [rsp+0xD0], xmm13
000071c0d83d3875  vmovaps [rsp+0xE0], xmm14
000071c0d83d387e  sub rsp, 0x30
000071c0d83d3882  movaps [rsp], xmm15
000071c0d83d3887  movaps [rsp+0x10], xmm13
000071c0d83d388d  movaps [rsp+0x20], xmm10
000071c0d83d3893  lea rdi, [rsp]
000071c0d83d3897  mov esi, 0x00
000071c0d83d389c  mov rax, 0x5904ED15D530
000071c0d83d38a6  call rax
000071c0d83d38a8  movaps xmm15, [rsp]
000071c0d83d38ad  add rsp, 0x30
000071c0d83d38b1  vmovaps xmm0, [rsp]
000071c0d83d38b6  vmovaps xmm1, [rsp+0x10]
000071c0d83d38bc  vmovaps xmm2, [rsp+0x20]
000071c0d83d38c2  vmovaps xmm3, [rsp+0x30]
000071c0d83d38c8  vmovaps xmm4, [rsp+0x40]
000071c0d83d38ce  vmovaps xmm5, [rsp+0x50]
000071c0d83d38d4  vmovaps xmm6, [rsp+0x60]
000071c0d83d38da  vmovaps xmm7, [rsp+0x70]
000071c0d83d38e0  vmovaps xmm8, [rsp+0x80]
000071c0d83d38e9  vmovaps xmm9, [rsp+0x90]
000071c0d83d38f2  vmovaps xmm10, [rsp+0xA0]
000071c0d83d38fb  vmovaps xmm11, [rsp+0xB0]
000071c0d83d3904  vmovaps xmm12, [rsp+0xC0]
000071c0d83d390d  vmovaps xmm13, [rsp+0xD0]
000071c0d83d3916  vmovaps xmm14, [rsp+0xE0]
000071c0d83d391f  add rsp, 0xF0
000071c0d83d3926  pop r11
000071c0d83d3928  pop r10
000071c0d83d392a  pop r9
000071c0d83d392c  pop r8
000071c0d83d392e  pop rsi
000071c0d83d392f  pop rdi
000071c0d83d3930  pop rdx
000071c0d83d3931  pop rcx
000071c0d83d3932  pop rax
000071c0d83d3933  add rsp, 0x08
000071c0d83d3937  jmp 0x000071C0D83CFF55
000071c0d83d393c  call 0x000071C0D820C260
000071c0d83d3941  jmp 0x000071C0D83CFFB0
000071c0d83d3946  sub rsp, 0x08
000071c0d83d394a  push rax
000071c0d83d394b  push rcx
000071c0d83d394c  push rdx
000071c0d83d394d  push rdi
000071c0d83d394e  push rsi
000071c0d83d394f  push r8
000071c0d83d3951  push r9
000071c0d83d3953  push r10
000071c0d83d3955  push r11
000071c0d83d3957  sub rsp, 0xF0
000071c0d83d395e  vmovaps [rsp], xmm0
000071c0d83d3963  vmovaps [rsp+0x10], xmm1
000071c0d83d3969  vmovaps [rsp+0x20], xmm2
000071c0d83d396f  vmovaps [rsp+0x30], xmm3
000071c0d83d3975  vmovaps [rsp+0x40], xmm4
000071c0d83d397b  vmovaps [rsp+0x50], xmm5
000071c0d83d3981  vmovaps [rsp+0x60], xmm6
000071c0d83d3987  vmovaps [rsp+0x70], xmm7
000071c0d83d398d  vmovaps [rsp+0x80], xmm8
000071c0d83d3996  vmovaps [rsp+0x90], xmm10
000071c0d83d399f  vmovaps [rsp+0xA0], xmm11
000071c0d83d39a8  vmovaps [rsp+0xB0], xmm12
000071c0d83d39b1  vmovaps [rsp+0xC0], xmm13
000071c0d83d39ba  vmovaps [rsp+0xD0], xmm14
000071c0d83d39c3  vmovaps [rsp+0xE0], xmm15
000071c0d83d39cc  sub rsp, 0x30
000071c0d83d39d0  movaps [rsp], xmm9
000071c0d83d39d5  movaps [rsp+0x10], xmm8
000071c0d83d39db  movaps [rsp+0x20], xmm10
000071c0d83d39e1  lea rdi, [rsp]
000071c0d83d39e5  mov esi, 0x00
000071c0d83d39ea  mov rax, 0x5904ED15D530
000071c0d83d39f4  call rax
000071c0d83d39f6  movaps xmm9, [rsp]
000071c0d83d39fb  add rsp, 0x30
000071c0d83d39ff  vmovaps xmm0, [rsp]
000071c0d83d3a04  vmovaps xmm1, [rsp+0x10]
000071c0d83d3a0a  vmovaps xmm2, [rsp+0x20]
000071c0d83d3a10  vmovaps xmm3, [rsp+0x30]
000071c0d83d3a16  vmovaps xmm4, [rsp+0x40]
000071c0d83d3a1c  vmovaps xmm5, [rsp+0x50]
000071c0d83d3a22  vmovaps xmm6, [rsp+0x60]
000071c0d83d3a28  vmovaps xmm7, [rsp+0x70]
000071c0d83d3a2e  vmovaps xmm8, [rsp+0x80]
000071c0d83d3a37  vmovaps xmm10, [rsp+0x90]
000071c0d83d3a40  vmovaps xmm11, [rsp+0xA0]
000071c0d83d3a49  vmovaps xmm12, [rsp+0xB0]
000071c0d83d3a52  vmovaps xmm13, [rsp+0xC0]
000071c0d83d3a5b  vmovaps xmm14, [rsp+0xD0]
000071c0d83d3a64  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3a6d  add rsp, 0xF0
000071c0d83d3a74  pop r11
000071c0d83d3a76  pop r10
000071c0d83d3a78  pop r9
000071c0d83d3a7a  pop r8
000071c0d83d3a7c  pop rsi
000071c0d83d3a7d  pop rdi
000071c0d83d3a7e  pop rdx
000071c0d83d3a7f  pop rcx
000071c0d83d3a80  pop rax
000071c0d83d3a81  add rsp, 0x08
000071c0d83d3a85  jmp 0x000071C0D83CFFE1
000071c0d83d3a8a  sub rsp, 0x08
000071c0d83d3a8e  push rax
000071c0d83d3a8f  push rcx
000071c0d83d3a90  push rdx
000071c0d83d3a91  push rdi
000071c0d83d3a92  push rsi
000071c0d83d3a93  push r8
000071c0d83d3a95  push r9
000071c0d83d3a97  push r10
000071c0d83d3a99  push r11
000071c0d83d3a9b  sub rsp, 0xF0
000071c0d83d3aa2  vmovaps [rsp], xmm0
000071c0d83d3aa7  vmovaps [rsp+0x10], xmm1
000071c0d83d3aad  vmovaps [rsp+0x20], xmm2
000071c0d83d3ab3  vmovaps [rsp+0x30], xmm3
000071c0d83d3ab9  vmovaps [rsp+0x40], xmm4
000071c0d83d3abf  vmovaps [rsp+0x50], xmm5
000071c0d83d3ac5  vmovaps [rsp+0x60], xmm6
000071c0d83d3acb  vmovaps [rsp+0x70], xmm7
000071c0d83d3ad1  vmovaps [rsp+0x80], xmm8
000071c0d83d3ada  vmovaps [rsp+0x90], xmm9
000071c0d83d3ae3  vmovaps [rsp+0xA0], xmm11
000071c0d83d3aec  vmovaps [rsp+0xB0], xmm12
000071c0d83d3af5  vmovaps [rsp+0xC0], xmm13
000071c0d83d3afe  vmovaps [rsp+0xD0], xmm14
000071c0d83d3b07  vmovaps [rsp+0xE0], xmm15
000071c0d83d3b10  sub rsp, 0x30
000071c0d83d3b14  movaps [rsp], xmm10
000071c0d83d3b19  movaps [rsp+0x10], xmm1
000071c0d83d3b1e  movaps [rsp+0x20], xmm11
000071c0d83d3b24  lea rdi, [rsp]
000071c0d83d3b28  mov esi, 0x00
000071c0d83d3b2d  mov rax, 0x5904ED15D530
000071c0d83d3b37  call rax
000071c0d83d3b39  movaps xmm10, [rsp]
000071c0d83d3b3e  add rsp, 0x30
000071c0d83d3b42  vmovaps xmm0, [rsp]
000071c0d83d3b47  vmovaps xmm1, [rsp+0x10]
000071c0d83d3b4d  vmovaps xmm2, [rsp+0x20]
000071c0d83d3b53  vmovaps xmm3, [rsp+0x30]
000071c0d83d3b59  vmovaps xmm4, [rsp+0x40]
000071c0d83d3b5f  vmovaps xmm5, [rsp+0x50]
000071c0d83d3b65  vmovaps xmm6, [rsp+0x60]
000071c0d83d3b6b  vmovaps xmm7, [rsp+0x70]
000071c0d83d3b71  vmovaps xmm8, [rsp+0x80]
000071c0d83d3b7a  vmovaps xmm9, [rsp+0x90]
000071c0d83d3b83  vmovaps xmm11, [rsp+0xA0]
000071c0d83d3b8c  vmovaps xmm12, [rsp+0xB0]
000071c0d83d3b95  vmovaps xmm13, [rsp+0xC0]
000071c0d83d3b9e  vmovaps xmm14, [rsp+0xD0]
000071c0d83d3ba7  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3bb0  add rsp, 0xF0
000071c0d83d3bb7  pop r11
000071c0d83d3bb9  pop r10
000071c0d83d3bbb  pop r9
000071c0d83d3bbd  pop r8
000071c0d83d3bbf  pop rsi
000071c0d83d3bc0  pop rdi
000071c0d83d3bc1  pop rdx
000071c0d83d3bc2  pop rcx
000071c0d83d3bc3  pop rax
000071c0d83d3bc4  add rsp, 0x08
000071c0d83d3bc8  jmp 0x000071C0D83CFFFC
000071c0d83d3bcd  sub rsp, 0x08
000071c0d83d3bd1  push rax
000071c0d83d3bd2  push rcx
000071c0d83d3bd3  push rdx
000071c0d83d3bd4  push rdi
000071c0d83d3bd5  push rsi
000071c0d83d3bd6  push r8
000071c0d83d3bd8  push r9
000071c0d83d3bda  push r10
000071c0d83d3bdc  push r11
000071c0d83d3bde  sub rsp, 0xF0
000071c0d83d3be5  vmovaps [rsp], xmm0
000071c0d83d3bea  vmovaps [rsp+0x10], xmm2
000071c0d83d3bf0  vmovaps [rsp+0x20], xmm3
000071c0d83d3bf6  vmovaps [rsp+0x30], xmm4
000071c0d83d3bfc  vmovaps [rsp+0x40], xmm5
000071c0d83d3c02  vmovaps [rsp+0x50], xmm6
000071c0d83d3c08  vmovaps [rsp+0x60], xmm7
000071c0d83d3c0e  vmovaps [rsp+0x70], xmm8
000071c0d83d3c14  vmovaps [rsp+0x80], xmm9
000071c0d83d3c1d  vmovaps [rsp+0x90], xmm10
000071c0d83d3c26  vmovaps [rsp+0xA0], xmm11
000071c0d83d3c2f  vmovaps [rsp+0xB0], xmm12
000071c0d83d3c38  vmovaps [rsp+0xC0], xmm13
000071c0d83d3c41  vmovaps [rsp+0xD0], xmm14
000071c0d83d3c4a  vmovaps [rsp+0xE0], xmm15
000071c0d83d3c53  sub rsp, 0x30
000071c0d83d3c57  movaps [rsp], xmm1
000071c0d83d3c5b  movaps [rsp+0x10], xmm14
000071c0d83d3c61  movaps [rsp+0x20], xmm6
000071c0d83d3c66  lea rdi, [rsp]
000071c0d83d3c6a  mov esi, 0x00
000071c0d83d3c6f  mov rax, 0x5904ED15D530
000071c0d83d3c79  call rax
000071c0d83d3c7b  movaps xmm1, [rsp]
000071c0d83d3c7f  add rsp, 0x30
000071c0d83d3c83  vmovaps xmm0, [rsp]
000071c0d83d3c88  vmovaps xmm2, [rsp+0x10]
000071c0d83d3c8e  vmovaps xmm3, [rsp+0x20]
000071c0d83d3c94  vmovaps xmm4, [rsp+0x30]
000071c0d83d3c9a  vmovaps xmm5, [rsp+0x40]
000071c0d83d3ca0  vmovaps xmm6, [rsp+0x50]
000071c0d83d3ca6  vmovaps xmm7, [rsp+0x60]
000071c0d83d3cac  vmovaps xmm8, [rsp+0x70]
000071c0d83d3cb2  vmovaps xmm9, [rsp+0x80]
000071c0d83d3cbb  vmovaps xmm10, [rsp+0x90]
000071c0d83d3cc4  vmovaps xmm11, [rsp+0xA0]
000071c0d83d3ccd  vmovaps xmm12, [rsp+0xB0]
000071c0d83d3cd6  vmovaps xmm13, [rsp+0xC0]
000071c0d83d3cdf  vmovaps xmm14, [rsp+0xD0]
000071c0d83d3ce8  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3cf1  add rsp, 0xF0
000071c0d83d3cf8  pop r11
000071c0d83d3cfa  pop r10
000071c0d83d3cfc  pop r9
000071c0d83d3cfe  pop r8
000071c0d83d3d00  pop rsi
000071c0d83d3d01  pop rdi
000071c0d83d3d02  pop rdx
000071c0d83d3d03  pop rcx
000071c0d83d3d04  pop rax
000071c0d83d3d05  add rsp, 0x08
000071c0d83d3d09  jmp 0x000071C0D83D0015
000071c0d83d3d0e  sub rsp, 0x08
000071c0d83d3d12  push rax
000071c0d83d3d13  push rcx
000071c0d83d3d14  push rdx
000071c0d83d3d15  push rdi
000071c0d83d3d16  push rsi
000071c0d83d3d17  push r8
000071c0d83d3d19  push r9
000071c0d83d3d1b  push r10
000071c0d83d3d1d  push r11
000071c0d83d3d1f  sub rsp, 0xF0
000071c0d83d3d26  vmovaps [rsp], xmm0
000071c0d83d3d2b  vmovaps [rsp+0x10], xmm1
000071c0d83d3d31  vmovaps [rsp+0x20], xmm2
000071c0d83d3d37  vmovaps [rsp+0x30], xmm3
000071c0d83d3d3d  vmovaps [rsp+0x40], xmm4
000071c0d83d3d43  vmovaps [rsp+0x50], xmm5
000071c0d83d3d49  vmovaps [rsp+0x60], xmm6
000071c0d83d3d4f  vmovaps [rsp+0x70], xmm7
000071c0d83d3d55  vmovaps [rsp+0x80], xmm8
000071c0d83d3d5e  vmovaps [rsp+0x90], xmm9
000071c0d83d3d67  vmovaps [rsp+0xA0], xmm10
000071c0d83d3d70  vmovaps [rsp+0xB0], xmm12
000071c0d83d3d79  vmovaps [rsp+0xC0], xmm13
000071c0d83d3d82  vmovaps [rsp+0xD0], xmm14
000071c0d83d3d8b  vmovaps [rsp+0xE0], xmm15
000071c0d83d3d94  sub rsp, 0x30
000071c0d83d3d98  movaps [rsp], xmm11
000071c0d83d3d9d  movaps [rsp+0x10], xmm13
000071c0d83d3da3  movaps [rsp+0x20], xmm14
000071c0d83d3da9  lea rdi, [rsp]
000071c0d83d3dad  mov esi, 0x00
000071c0d83d3db2  mov rax, 0x5904ED15D530
000071c0d83d3dbc  call rax
000071c0d83d3dbe  movaps xmm11, [rsp]
000071c0d83d3dc3  add rsp, 0x30
000071c0d83d3dc7  vmovaps xmm0, [rsp]
000071c0d83d3dcc  vmovaps xmm1, [rsp+0x10]
000071c0d83d3dd2  vmovaps xmm2, [rsp+0x20]
000071c0d83d3dd8  vmovaps xmm3, [rsp+0x30]
000071c0d83d3dde  vmovaps xmm4, [rsp+0x40]
000071c0d83d3de4  vmovaps xmm5, [rsp+0x50]
000071c0d83d3dea  vmovaps xmm6, [rsp+0x60]
000071c0d83d3df0  vmovaps xmm7, [rsp+0x70]
000071c0d83d3df6  vmovaps xmm8, [rsp+0x80]
000071c0d83d3dff  vmovaps xmm9, [rsp+0x90]
000071c0d83d3e08  vmovaps xmm10, [rsp+0xA0]
000071c0d83d3e11  vmovaps xmm12, [rsp+0xB0]
000071c0d83d3e1a  vmovaps xmm13, [rsp+0xC0]
000071c0d83d3e23  vmovaps xmm14, [rsp+0xD0]
000071c0d83d3e2c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3e35  add rsp, 0xF0
000071c0d83d3e3c  pop r11
000071c0d83d3e3e  pop r10
000071c0d83d3e40  pop r9
000071c0d83d3e42  pop r8
000071c0d83d3e44  pop rsi
000071c0d83d3e45  pop rdi
000071c0d83d3e46  pop rdx
000071c0d83d3e47  pop rcx
000071c0d83d3e48  pop rax
000071c0d83d3e49  add rsp, 0x08
000071c0d83d3e4d  jmp 0x000071C0D83D003F
000071c0d83d3e52  sub rsp, 0x08
000071c0d83d3e56  push rax
000071c0d83d3e57  push rcx
000071c0d83d3e58  push rdx
000071c0d83d3e59  push rdi
000071c0d83d3e5a  push rsi
000071c0d83d3e5b  push r8
000071c0d83d3e5d  push r9
000071c0d83d3e5f  push r10
000071c0d83d3e61  push r11
000071c0d83d3e63  sub rsp, 0xF0
000071c0d83d3e6a  vmovaps [rsp], xmm0
000071c0d83d3e6f  vmovaps [rsp+0x10], xmm1
000071c0d83d3e75  vmovaps [rsp+0x20], xmm2
000071c0d83d3e7b  vmovaps [rsp+0x30], xmm3
000071c0d83d3e81  vmovaps [rsp+0x40], xmm4
000071c0d83d3e87  vmovaps [rsp+0x50], xmm5
000071c0d83d3e8d  vmovaps [rsp+0x60], xmm6
000071c0d83d3e93  vmovaps [rsp+0x70], xmm7
000071c0d83d3e99  vmovaps [rsp+0x80], xmm8
000071c0d83d3ea2  vmovaps [rsp+0x90], xmm9
000071c0d83d3eab  vmovaps [rsp+0xA0], xmm10
000071c0d83d3eb4  vmovaps [rsp+0xB0], xmm11
000071c0d83d3ebd  vmovaps [rsp+0xC0], xmm12
000071c0d83d3ec6  vmovaps [rsp+0xD0], xmm14
000071c0d83d3ecf  vmovaps [rsp+0xE0], xmm15
000071c0d83d3ed8  sub rsp, 0x30
000071c0d83d3edc  movaps [rsp], xmm13
000071c0d83d3ee1  movaps [rsp+0x10], xmm8
000071c0d83d3ee7  movaps [rsp+0x20], xmm14
000071c0d83d3eed  lea rdi, [rsp]
000071c0d83d3ef1  mov esi, 0x00
000071c0d83d3ef6  mov rax, 0x5904ED15D530
000071c0d83d3f00  call rax
000071c0d83d3f02  movaps xmm13, [rsp]
000071c0d83d3f07  add rsp, 0x30
000071c0d83d3f0b  vmovaps xmm0, [rsp]
000071c0d83d3f10  vmovaps xmm1, [rsp+0x10]
000071c0d83d3f16  vmovaps xmm2, [rsp+0x20]
000071c0d83d3f1c  vmovaps xmm3, [rsp+0x30]
000071c0d83d3f22  vmovaps xmm4, [rsp+0x40]
000071c0d83d3f28  vmovaps xmm5, [rsp+0x50]
000071c0d83d3f2e  vmovaps xmm6, [rsp+0x60]
000071c0d83d3f34  vmovaps xmm7, [rsp+0x70]
000071c0d83d3f3a  vmovaps xmm8, [rsp+0x80]
000071c0d83d3f43  vmovaps xmm9, [rsp+0x90]
000071c0d83d3f4c  vmovaps xmm10, [rsp+0xA0]
000071c0d83d3f55  vmovaps xmm11, [rsp+0xB0]
000071c0d83d3f5e  vmovaps xmm12, [rsp+0xC0]
000071c0d83d3f67  vmovaps xmm14, [rsp+0xD0]
000071c0d83d3f70  vmovaps xmm15, [rsp+0xE0]
000071c0d83d3f79  add rsp, 0xF0
000071c0d83d3f80  pop r11
000071c0d83d3f82  pop r10
000071c0d83d3f84  pop r9
000071c0d83d3f86  pop r8
000071c0d83d3f88  pop rsi
000071c0d83d3f89  pop rdi
000071c0d83d3f8a  pop rdx
000071c0d83d3f8b  pop rcx
000071c0d83d3f8c  pop rax
000071c0d83d3f8d  add rsp, 0x08
000071c0d83d3f91  jmp 0x000071C0D83D006E
000071c0d83d3f96  sub rsp, 0x08
000071c0d83d3f9a  push rax
000071c0d83d3f9b  push rcx
000071c0d83d3f9c  push rdx
000071c0d83d3f9d  push rdi
000071c0d83d3f9e  push rsi
000071c0d83d3f9f  push r8
000071c0d83d3fa1  push r9
000071c0d83d3fa3  push r10
000071c0d83d3fa5  push r11
000071c0d83d3fa7  sub rsp, 0xF0
000071c0d83d3fae  vmovaps [rsp], xmm0
000071c0d83d3fb3  vmovaps [rsp+0x10], xmm1
000071c0d83d3fb9  vmovaps [rsp+0x20], xmm2
000071c0d83d3fbf  vmovaps [rsp+0x30], xmm3
000071c0d83d3fc5  vmovaps [rsp+0x40], xmm4
000071c0d83d3fcb  vmovaps [rsp+0x50], xmm5
000071c0d83d3fd1  vmovaps [rsp+0x60], xmm6
000071c0d83d3fd7  vmovaps [rsp+0x70], xmm7
000071c0d83d3fdd  vmovaps [rsp+0x80], xmm9
000071c0d83d3fe6  vmovaps [rsp+0x90], xmm10
000071c0d83d3fef  vmovaps [rsp+0xA0], xmm11
000071c0d83d3ff8  vmovaps [rsp+0xB0], xmm12
000071c0d83d4001  vmovaps [rsp+0xC0], xmm13
000071c0d83d400a  vmovaps [rsp+0xD0], xmm14
000071c0d83d4013  vmovaps [rsp+0xE0], xmm15
000071c0d83d401c  sub rsp, 0x30
000071c0d83d4020  movaps [rsp], xmm8
000071c0d83d4025  movaps [rsp+0x10], xmm7
000071c0d83d402a  movaps [rsp+0x20], xmm14
000071c0d83d4030  lea rdi, [rsp]
000071c0d83d4034  mov esi, 0x00
000071c0d83d4039  mov rax, 0x5904ED15D530
000071c0d83d4043  call rax
000071c0d83d4045  movaps xmm8, [rsp]
000071c0d83d404a  add rsp, 0x30
000071c0d83d404e  vmovaps xmm0, [rsp]
000071c0d83d4053  vmovaps xmm1, [rsp+0x10]
000071c0d83d4059  vmovaps xmm2, [rsp+0x20]
000071c0d83d405f  vmovaps xmm3, [rsp+0x30]
000071c0d83d4065  vmovaps xmm4, [rsp+0x40]
000071c0d83d406b  vmovaps xmm5, [rsp+0x50]
000071c0d83d4071  vmovaps xmm6, [rsp+0x60]
000071c0d83d4077  vmovaps xmm7, [rsp+0x70]
000071c0d83d407d  vmovaps xmm9, [rsp+0x80]
000071c0d83d4086  vmovaps xmm10, [rsp+0x90]
000071c0d83d408f  vmovaps xmm11, [rsp+0xA0]
000071c0d83d4098  vmovaps xmm12, [rsp+0xB0]
000071c0d83d40a1  vmovaps xmm13, [rsp+0xC0]
000071c0d83d40aa  vmovaps xmm14, [rsp+0xD0]
000071c0d83d40b3  vmovaps xmm15, [rsp+0xE0]
000071c0d83d40bc  add rsp, 0xF0
000071c0d83d40c3  pop r11
000071c0d83d40c5  pop r10
000071c0d83d40c7  pop r9
000071c0d83d40c9  pop r8
000071c0d83d40cb  pop rsi
000071c0d83d40cc  pop rdi
000071c0d83d40cd  pop rdx
000071c0d83d40ce  pop rcx
000071c0d83d40cf  pop rax
000071c0d83d40d0  add rsp, 0x08
000071c0d83d40d4  jmp 0x000071C0D83D0094
000071c0d83d40d9  sub rsp, 0x08
000071c0d83d40dd  push rax
000071c0d83d40de  push rcx
000071c0d83d40df  push rdx
000071c0d83d40e0  push rdi
000071c0d83d40e1  push rsi
000071c0d83d40e2  push r8
000071c0d83d40e4  push r9
000071c0d83d40e6  push r10
000071c0d83d40e8  push r11
000071c0d83d40ea  sub rsp, 0xF0
000071c0d83d40f1  vmovaps [rsp], xmm0
000071c0d83d40f6  vmovaps [rsp+0x10], xmm1
000071c0d83d40fc  vmovaps [rsp+0x20], xmm2
000071c0d83d4102  vmovaps [rsp+0x30], xmm3
000071c0d83d4108  vmovaps [rsp+0x40], xmm4
000071c0d83d410e  vmovaps [rsp+0x50], xmm5
000071c0d83d4114  vmovaps [rsp+0x60], xmm6
000071c0d83d411a  vmovaps [rsp+0x70], xmm7
000071c0d83d4120  vmovaps [rsp+0x80], xmm8
000071c0d83d4129  vmovaps [rsp+0x90], xmm9
000071c0d83d4132  vmovaps [rsp+0xA0], xmm10
000071c0d83d413b  vmovaps [rsp+0xB0], xmm11
000071c0d83d4144  vmovaps [rsp+0xC0], xmm12
000071c0d83d414d  vmovaps [rsp+0xD0], xmm13
000071c0d83d4156  vmovaps [rsp+0xE0], xmm15
000071c0d83d415f  sub rsp, 0x30
000071c0d83d4163  movaps [rsp], xmm14
000071c0d83d4168  movaps [rsp+0x10], xmm12
000071c0d83d416e  movaps [rsp+0x20], xmm9
000071c0d83d4174  lea rdi, [rsp]
000071c0d83d4178  mov esi, 0x00
000071c0d83d417d  mov rax, 0x5904ED15D530
000071c0d83d4187  call rax
000071c0d83d4189  movaps xmm14, [rsp]
000071c0d83d418e  add rsp, 0x30
000071c0d83d4192  vmovaps xmm0, [rsp]
000071c0d83d4197  vmovaps xmm1, [rsp+0x10]
000071c0d83d419d  vmovaps xmm2, [rsp+0x20]
000071c0d83d41a3  vmovaps xmm3, [rsp+0x30]
000071c0d83d41a9  vmovaps xmm4, [rsp+0x40]
000071c0d83d41af  vmovaps xmm5, [rsp+0x50]
000071c0d83d41b5  vmovaps xmm6, [rsp+0x60]
000071c0d83d41bb  vmovaps xmm7, [rsp+0x70]
000071c0d83d41c1  vmovaps xmm8, [rsp+0x80]
000071c0d83d41ca  vmovaps xmm9, [rsp+0x90]
000071c0d83d41d3  vmovaps xmm10, [rsp+0xA0]
000071c0d83d41dc  vmovaps xmm11, [rsp+0xB0]
000071c0d83d41e5  vmovaps xmm12, [rsp+0xC0]
000071c0d83d41ee  vmovaps xmm13, [rsp+0xD0]
000071c0d83d41f7  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4200  add rsp, 0xF0
000071c0d83d4207  pop r11
000071c0d83d4209  pop r10
000071c0d83d420b  pop r9
000071c0d83d420d  pop r8
000071c0d83d420f  pop rsi
000071c0d83d4210  pop rdi
000071c0d83d4211  pop rdx
000071c0d83d4212  pop rcx
000071c0d83d4213  pop rax
000071c0d83d4214  add rsp, 0x08
000071c0d83d4218  jmp 0x000071C0D83D00AE
000071c0d83d421d  sub rsp, 0x08
000071c0d83d4221  push rax
000071c0d83d4222  push rcx
000071c0d83d4223  push rdx
000071c0d83d4224  push rdi
000071c0d83d4225  push rsi
000071c0d83d4226  push r8
000071c0d83d4228  push r9
000071c0d83d422a  push r10
000071c0d83d422c  push r11
000071c0d83d422e  sub rsp, 0xF0
000071c0d83d4235  vmovaps [rsp], xmm0
000071c0d83d423a  vmovaps [rsp+0x10], xmm1
000071c0d83d4240  vmovaps [rsp+0x20], xmm2
000071c0d83d4246  vmovaps [rsp+0x30], xmm3
000071c0d83d424c  vmovaps [rsp+0x40], xmm4
000071c0d83d4252  vmovaps [rsp+0x50], xmm5
000071c0d83d4258  vmovaps [rsp+0x60], xmm6
000071c0d83d425e  vmovaps [rsp+0x70], xmm7
000071c0d83d4264  vmovaps [rsp+0x80], xmm8
000071c0d83d426d  vmovaps [rsp+0x90], xmm10
000071c0d83d4276  vmovaps [rsp+0xA0], xmm11
000071c0d83d427f  vmovaps [rsp+0xB0], xmm12
000071c0d83d4288  vmovaps [rsp+0xC0], xmm13
000071c0d83d4291  vmovaps [rsp+0xD0], xmm14
000071c0d83d429a  vmovaps [rsp+0xE0], xmm15
000071c0d83d42a3  sub rsp, 0x30
000071c0d83d42a7  movaps [rsp], xmm9
000071c0d83d42ac  movaps [rsp+0x10], xmm7
000071c0d83d42b1  movaps [rsp+0x20], xmm12
000071c0d83d42b7  lea rdi, [rsp]
000071c0d83d42bb  mov esi, 0x00
000071c0d83d42c0  mov rax, 0x5904ED15D530
000071c0d83d42ca  call rax
000071c0d83d42cc  movaps xmm9, [rsp]
000071c0d83d42d1  add rsp, 0x30
000071c0d83d42d5  vmovaps xmm0, [rsp]
000071c0d83d42da  vmovaps xmm1, [rsp+0x10]
000071c0d83d42e0  vmovaps xmm2, [rsp+0x20]
000071c0d83d42e6  vmovaps xmm3, [rsp+0x30]
000071c0d83d42ec  vmovaps xmm4, [rsp+0x40]
000071c0d83d42f2  vmovaps xmm5, [rsp+0x50]
000071c0d83d42f8  vmovaps xmm6, [rsp+0x60]
000071c0d83d42fe  vmovaps xmm7, [rsp+0x70]
000071c0d83d4304  vmovaps xmm8, [rsp+0x80]
000071c0d83d430d  vmovaps xmm10, [rsp+0x90]
000071c0d83d4316  vmovaps xmm11, [rsp+0xA0]
000071c0d83d431f  vmovaps xmm12, [rsp+0xB0]
000071c0d83d4328  vmovaps xmm13, [rsp+0xC0]
000071c0d83d4331  vmovaps xmm14, [rsp+0xD0]
000071c0d83d433a  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4343  add rsp, 0xF0
000071c0d83d434a  pop r11
000071c0d83d434c  pop r10
000071c0d83d434e  pop r9
000071c0d83d4350  pop r8
000071c0d83d4352  pop rsi
000071c0d83d4353  pop rdi
000071c0d83d4354  pop rdx
000071c0d83d4355  pop rcx
000071c0d83d4356  pop rax
000071c0d83d4357  add rsp, 0x08
000071c0d83d435b  jmp 0x000071C0D83D00DD
000071c0d83d4360  sub rsp, 0x08
000071c0d83d4364  push rax
000071c0d83d4365  push rcx
000071c0d83d4366  push rdx
000071c0d83d4367  push rdi
000071c0d83d4368  push rsi
000071c0d83d4369  push r8
000071c0d83d436b  push r9
000071c0d83d436d  push r10
000071c0d83d436f  push r11
000071c0d83d4371  sub rsp, 0xF0
000071c0d83d4378  vmovaps [rsp], xmm0
000071c0d83d437d  vmovaps [rsp+0x10], xmm1
000071c0d83d4383  vmovaps [rsp+0x20], xmm2
000071c0d83d4389  vmovaps [rsp+0x30], xmm3
000071c0d83d438f  vmovaps [rsp+0x40], xmm4
000071c0d83d4395  vmovaps [rsp+0x50], xmm5
000071c0d83d439b  vmovaps [rsp+0x60], xmm6
000071c0d83d43a1  vmovaps [rsp+0x70], xmm7
000071c0d83d43a7  vmovaps [rsp+0x80], xmm8
000071c0d83d43b0  vmovaps [rsp+0x90], xmm9
000071c0d83d43b9  vmovaps [rsp+0xA0], xmm10
000071c0d83d43c2  vmovaps [rsp+0xB0], xmm11
000071c0d83d43cb  vmovaps [rsp+0xC0], xmm13
000071c0d83d43d4  vmovaps [rsp+0xD0], xmm14
000071c0d83d43dd  vmovaps [rsp+0xE0], xmm15
000071c0d83d43e6  sub rsp, 0x30
000071c0d83d43ea  movaps [rsp], xmm12
000071c0d83d43ef  movaps [rsp+0x10], xmm15
000071c0d83d43f5  movaps [rsp+0x20], xmm11
000071c0d83d43fb  lea rdi, [rsp]
000071c0d83d43ff  mov esi, 0x00
000071c0d83d4404  mov rax, 0x5904ED15D530
000071c0d83d440e  call rax
000071c0d83d4410  movaps xmm12, [rsp]
000071c0d83d4415  add rsp, 0x30
000071c0d83d4419  vmovaps xmm0, [rsp]
000071c0d83d441e  vmovaps xmm1, [rsp+0x10]
000071c0d83d4424  vmovaps xmm2, [rsp+0x20]
000071c0d83d442a  vmovaps xmm3, [rsp+0x30]
000071c0d83d4430  vmovaps xmm4, [rsp+0x40]
000071c0d83d4436  vmovaps xmm5, [rsp+0x50]
000071c0d83d443c  vmovaps xmm6, [rsp+0x60]
000071c0d83d4442  vmovaps xmm7, [rsp+0x70]
000071c0d83d4448  vmovaps xmm8, [rsp+0x80]
000071c0d83d4451  vmovaps xmm9, [rsp+0x90]
000071c0d83d445a  vmovaps xmm10, [rsp+0xA0]
000071c0d83d4463  vmovaps xmm11, [rsp+0xB0]
000071c0d83d446c  vmovaps xmm13, [rsp+0xC0]
000071c0d83d4475  vmovaps xmm14, [rsp+0xD0]
000071c0d83d447e  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4487  add rsp, 0xF0
000071c0d83d448e  pop r11
000071c0d83d4490  pop r10
000071c0d83d4492  pop r9
000071c0d83d4494  pop r8
000071c0d83d4496  pop rsi
000071c0d83d4497  pop rdi
000071c0d83d4498  pop rdx
000071c0d83d4499  pop rcx
000071c0d83d449a  pop rax
000071c0d83d449b  add rsp, 0x08
000071c0d83d449f  jmp 0x000071C0D83D00F7
000071c0d83d44a4  sub rsp, 0x08
000071c0d83d44a8  push rax
000071c0d83d44a9  push rcx
000071c0d83d44aa  push rdx
000071c0d83d44ab  push rdi
000071c0d83d44ac  push rsi
000071c0d83d44ad  push r8
000071c0d83d44af  push r9
000071c0d83d44b1  push r10
000071c0d83d44b3  push r11
000071c0d83d44b5  sub rsp, 0xF0
000071c0d83d44bc  vmovaps [rsp], xmm0
000071c0d83d44c1  vmovaps [rsp+0x10], xmm1
000071c0d83d44c7  vmovaps [rsp+0x20], xmm2
000071c0d83d44cd  vmovaps [rsp+0x30], xmm3
000071c0d83d44d3  vmovaps [rsp+0x40], xmm4
000071c0d83d44d9  vmovaps [rsp+0x50], xmm5
000071c0d83d44df  vmovaps [rsp+0x60], xmm6
000071c0d83d44e5  vmovaps [rsp+0x70], xmm7
000071c0d83d44eb  vmovaps [rsp+0x80], xmm8
000071c0d83d44f4  vmovaps [rsp+0x90], xmm9
000071c0d83d44fd  vmovaps [rsp+0xA0], xmm10
000071c0d83d4506  vmovaps [rsp+0xB0], xmm12
000071c0d83d450f  vmovaps [rsp+0xC0], xmm13
000071c0d83d4518  vmovaps [rsp+0xD0], xmm14
000071c0d83d4521  vmovaps [rsp+0xE0], xmm15
000071c0d83d452a  sub rsp, 0x30
000071c0d83d452e  movaps [rsp], xmm11
000071c0d83d4533  movaps [rsp+0x10], xmm7
000071c0d83d4538  movaps [rsp+0x20], xmm15
000071c0d83d453e  lea rdi, [rsp]
000071c0d83d4542  mov esi, 0x00
000071c0d83d4547  mov rax, 0x5904ED15D530
000071c0d83d4551  call rax
000071c0d83d4553  movaps xmm11, [rsp]
000071c0d83d4558  add rsp, 0x30
000071c0d83d455c  vmovaps xmm0, [rsp]
000071c0d83d4561  vmovaps xmm1, [rsp+0x10]
000071c0d83d4567  vmovaps xmm2, [rsp+0x20]
000071c0d83d456d  vmovaps xmm3, [rsp+0x30]
000071c0d83d4573  vmovaps xmm4, [rsp+0x40]
000071c0d83d4579  vmovaps xmm5, [rsp+0x50]
000071c0d83d457f  vmovaps xmm6, [rsp+0x60]
000071c0d83d4585  vmovaps xmm7, [rsp+0x70]
000071c0d83d458b  vmovaps xmm8, [rsp+0x80]
000071c0d83d4594  vmovaps xmm9, [rsp+0x90]
000071c0d83d459d  vmovaps xmm10, [rsp+0xA0]
000071c0d83d45a6  vmovaps xmm12, [rsp+0xB0]
000071c0d83d45af  vmovaps xmm13, [rsp+0xC0]
000071c0d83d45b8  vmovaps xmm14, [rsp+0xD0]
000071c0d83d45c1  vmovaps xmm15, [rsp+0xE0]
000071c0d83d45ca  add rsp, 0xF0
000071c0d83d45d1  pop r11
000071c0d83d45d3  pop r10
000071c0d83d45d5  pop r9
000071c0d83d45d7  pop r8
000071c0d83d45d9  pop rsi
000071c0d83d45da  pop rdi
000071c0d83d45db  pop rdx
000071c0d83d45dc  pop rcx
000071c0d83d45dd  pop rax
000071c0d83d45de  add rsp, 0x08
000071c0d83d45e2  jmp 0x000071C0D83D0123
000071c0d83d45e7  sub rsp, 0x08
000071c0d83d45eb  push rax
000071c0d83d45ec  push rcx
000071c0d83d45ed  push rdx
000071c0d83d45ee  push rdi
000071c0d83d45ef  push rsi
000071c0d83d45f0  push r8
000071c0d83d45f2  push r9
000071c0d83d45f4  push r10
000071c0d83d45f6  push r11
000071c0d83d45f8  sub rsp, 0xF0
000071c0d83d45ff  vmovaps [rsp], xmm0
000071c0d83d4604  vmovaps [rsp+0x10], xmm1
000071c0d83d460a  vmovaps [rsp+0x20], xmm2
000071c0d83d4610  vmovaps [rsp+0x30], xmm3
000071c0d83d4616  vmovaps [rsp+0x40], xmm4
000071c0d83d461c  vmovaps [rsp+0x50], xmm5
000071c0d83d4622  vmovaps [rsp+0x60], xmm6
000071c0d83d4628  vmovaps [rsp+0x70], xmm7
000071c0d83d462e  vmovaps [rsp+0x80], xmm8
000071c0d83d4637  vmovaps [rsp+0x90], xmm9
000071c0d83d4640  vmovaps [rsp+0xA0], xmm10
000071c0d83d4649  vmovaps [rsp+0xB0], xmm11
000071c0d83d4652  vmovaps [rsp+0xC0], xmm12
000071c0d83d465b  vmovaps [rsp+0xD0], xmm13
000071c0d83d4664  vmovaps [rsp+0xE0], xmm14
000071c0d83d466d  sub rsp, 0x30
000071c0d83d4671  movaps [rsp], xmm15
000071c0d83d4676  movaps [rsp+0x10], xmm10
000071c0d83d467c  movaps [rsp+0x20], xmm13
000071c0d83d4682  lea rdi, [rsp]
000071c0d83d4686  mov esi, 0x00
000071c0d83d468b  mov rax, 0x5904ED15D530
000071c0d83d4695  call rax
000071c0d83d4697  movaps xmm15, [rsp]
000071c0d83d469c  add rsp, 0x30
000071c0d83d46a0  vmovaps xmm0, [rsp]
000071c0d83d46a5  vmovaps xmm1, [rsp+0x10]
000071c0d83d46ab  vmovaps xmm2, [rsp+0x20]
000071c0d83d46b1  vmovaps xmm3, [rsp+0x30]
000071c0d83d46b7  vmovaps xmm4, [rsp+0x40]
000071c0d83d46bd  vmovaps xmm5, [rsp+0x50]
000071c0d83d46c3  vmovaps xmm6, [rsp+0x60]
000071c0d83d46c9  vmovaps xmm7, [rsp+0x70]
000071c0d83d46cf  vmovaps xmm8, [rsp+0x80]
000071c0d83d46d8  vmovaps xmm9, [rsp+0x90]
000071c0d83d46e1  vmovaps xmm10, [rsp+0xA0]
000071c0d83d46ea  vmovaps xmm11, [rsp+0xB0]
000071c0d83d46f3  vmovaps xmm12, [rsp+0xC0]
000071c0d83d46fc  vmovaps xmm13, [rsp+0xD0]
000071c0d83d4705  vmovaps xmm14, [rsp+0xE0]
000071c0d83d470e  add rsp, 0xF0
000071c0d83d4715  pop r11
000071c0d83d4717  pop r10
000071c0d83d4719  pop r9
000071c0d83d471b  pop r8
000071c0d83d471d  pop rsi
000071c0d83d471e  pop rdi
000071c0d83d471f  pop rdx
000071c0d83d4720  pop rcx
000071c0d83d4721  pop rax
000071c0d83d4722  add rsp, 0x08
000071c0d83d4726  jmp 0x000071C0D83D013D
000071c0d83d472b  sub rsp, 0x08
000071c0d83d472f  push rax
000071c0d83d4730  push rcx
000071c0d83d4731  push rdx
000071c0d83d4732  push rdi
000071c0d83d4733  push rsi
000071c0d83d4734  push r8
000071c0d83d4736  push r9
000071c0d83d4738  push r10
000071c0d83d473a  push r11
000071c0d83d473c  sub rsp, 0xF0
000071c0d83d4743  vmovaps [rsp], xmm0
000071c0d83d4748  vmovaps [rsp+0x10], xmm1
000071c0d83d474e  vmovaps [rsp+0x20], xmm2
000071c0d83d4754  vmovaps [rsp+0x30], xmm3
000071c0d83d475a  vmovaps [rsp+0x40], xmm4
000071c0d83d4760  vmovaps [rsp+0x50], xmm5
000071c0d83d4766  vmovaps [rsp+0x60], xmm6
000071c0d83d476c  vmovaps [rsp+0x70], xmm7
000071c0d83d4772  vmovaps [rsp+0x80], xmm8
000071c0d83d477b  vmovaps [rsp+0x90], xmm9
000071c0d83d4784  vmovaps [rsp+0xA0], xmm11
000071c0d83d478d  vmovaps [rsp+0xB0], xmm12
000071c0d83d4796  vmovaps [rsp+0xC0], xmm13
000071c0d83d479f  vmovaps [rsp+0xD0], xmm14
000071c0d83d47a8  vmovaps [rsp+0xE0], xmm15
000071c0d83d47b1  sub rsp, 0x30
000071c0d83d47b5  movaps [rsp], xmm10
000071c0d83d47ba  movaps [rsp+0x10], xmm7
000071c0d83d47bf  movaps [rsp+0x20], xmm13
000071c0d83d47c5  lea rdi, [rsp]
000071c0d83d47c9  mov esi, 0x00
000071c0d83d47ce  mov rax, 0x5904ED15D530
000071c0d83d47d8  call rax
000071c0d83d47da  movaps xmm10, [rsp]
000071c0d83d47df  add rsp, 0x30
000071c0d83d47e3  vmovaps xmm0, [rsp]
000071c0d83d47e8  vmovaps xmm1, [rsp+0x10]
000071c0d83d47ee  vmovaps xmm2, [rsp+0x20]
000071c0d83d47f4  vmovaps xmm3, [rsp+0x30]
000071c0d83d47fa  vmovaps xmm4, [rsp+0x40]
000071c0d83d4800  vmovaps xmm5, [rsp+0x50]
000071c0d83d4806  vmovaps xmm6, [rsp+0x60]
000071c0d83d480c  vmovaps xmm7, [rsp+0x70]
000071c0d83d4812  vmovaps xmm8, [rsp+0x80]
000071c0d83d481b  vmovaps xmm9, [rsp+0x90]
000071c0d83d4824  vmovaps xmm11, [rsp+0xA0]
000071c0d83d482d  vmovaps xmm12, [rsp+0xB0]
000071c0d83d4836  vmovaps xmm13, [rsp+0xC0]
000071c0d83d483f  vmovaps xmm14, [rsp+0xD0]
000071c0d83d4848  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4851  add rsp, 0xF0
000071c0d83d4858  pop r11
000071c0d83d485a  pop r10
000071c0d83d485c  pop r9
000071c0d83d485e  pop r8
000071c0d83d4860  pop rsi
000071c0d83d4861  pop rdi
000071c0d83d4862  pop rdx
000071c0d83d4863  pop rcx
000071c0d83d4864  pop rax
000071c0d83d4865  add rsp, 0x08
000071c0d83d4869  jmp 0x000071C0D83D0169
000071c0d83d486e  sub rsp, 0x08
000071c0d83d4872  push rax
000071c0d83d4873  push rcx
000071c0d83d4874  push rdx
000071c0d83d4875  push rdi
000071c0d83d4876  push rsi
000071c0d83d4877  push r8
000071c0d83d4879  push r9
000071c0d83d487b  push r10
000071c0d83d487d  push r11
000071c0d83d487f  sub rsp, 0xF0
000071c0d83d4886  vmovaps [rsp], xmm0
000071c0d83d488b  vmovaps [rsp+0x10], xmm1
000071c0d83d4891  vmovaps [rsp+0x20], xmm2
000071c0d83d4897  vmovaps [rsp+0x30], xmm3
000071c0d83d489d  vmovaps [rsp+0x40], xmm4
000071c0d83d48a3  vmovaps [rsp+0x50], xmm5
000071c0d83d48a9  vmovaps [rsp+0x60], xmm6
000071c0d83d48af  vmovaps [rsp+0x70], xmm7
000071c0d83d48b5  vmovaps [rsp+0x80], xmm8
000071c0d83d48be  vmovaps [rsp+0x90], xmm9
000071c0d83d48c7  vmovaps [rsp+0xA0], xmm10
000071c0d83d48d0  vmovaps [rsp+0xB0], xmm11
000071c0d83d48d9  vmovaps [rsp+0xC0], xmm12
000071c0d83d48e2  vmovaps [rsp+0xD0], xmm14
000071c0d83d48eb  vmovaps [rsp+0xE0], xmm15
000071c0d83d48f4  sub rsp, 0x30
000071c0d83d48f8  movaps [rsp], xmm13
000071c0d83d48fd  movaps [rsp+0x10], xmm1
000071c0d83d4902  movaps [rsp+0x20], xmm8
000071c0d83d4908  lea rdi, [rsp]
000071c0d83d490c  mov esi, 0x00
000071c0d83d4911  mov rax, 0x5904ED15D530
000071c0d83d491b  call rax
000071c0d83d491d  movaps xmm13, [rsp]
000071c0d83d4922  add rsp, 0x30
000071c0d83d4926  vmovaps xmm0, [rsp]
000071c0d83d492b  vmovaps xmm1, [rsp+0x10]
000071c0d83d4931  vmovaps xmm2, [rsp+0x20]
000071c0d83d4937  vmovaps xmm3, [rsp+0x30]
000071c0d83d493d  vmovaps xmm4, [rsp+0x40]
000071c0d83d4943  vmovaps xmm5, [rsp+0x50]
000071c0d83d4949  vmovaps xmm6, [rsp+0x60]
000071c0d83d494f  vmovaps xmm7, [rsp+0x70]
000071c0d83d4955  vmovaps xmm8, [rsp+0x80]
000071c0d83d495e  vmovaps xmm9, [rsp+0x90]
000071c0d83d4967  vmovaps xmm10, [rsp+0xA0]
000071c0d83d4970  vmovaps xmm11, [rsp+0xB0]
000071c0d83d4979  vmovaps xmm12, [rsp+0xC0]
000071c0d83d4982  vmovaps xmm14, [rsp+0xD0]
000071c0d83d498b  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4994  add rsp, 0xF0
000071c0d83d499b  pop r11
000071c0d83d499d  pop r10
000071c0d83d499f  pop r9
000071c0d83d49a1  pop r8
000071c0d83d49a3  pop rsi
000071c0d83d49a4  pop rdi
000071c0d83d49a5  pop rdx
000071c0d83d49a6  pop rcx
000071c0d83d49a7  pop rax
000071c0d83d49a8  add rsp, 0x08
000071c0d83d49ac  jmp 0x000071C0D83D0183
000071c0d83d49b1  call 0x000071C0D81FF430
000071c0d83d49b6  jmp 0x000071C0D83D018D
000071c0d83d49bb  sub rsp, 0x08
000071c0d83d49bf  push rax
000071c0d83d49c0  push rcx
000071c0d83d49c1  push rdx
000071c0d83d49c2  push rdi
000071c0d83d49c3  push rsi
000071c0d83d49c4  push r8
000071c0d83d49c6  push r9
000071c0d83d49c8  push r10
000071c0d83d49ca  push r11
000071c0d83d49cc  sub rsp, 0xF0
000071c0d83d49d3  vmovaps [rsp], xmm0
000071c0d83d49d8  vmovaps [rsp+0x10], xmm1
000071c0d83d49de  vmovaps [rsp+0x20], xmm2
000071c0d83d49e4  vmovaps [rsp+0x30], xmm3
000071c0d83d49ea  vmovaps [rsp+0x40], xmm4
000071c0d83d49f0  vmovaps [rsp+0x50], xmm5
000071c0d83d49f6  vmovaps [rsp+0x60], xmm6
000071c0d83d49fc  vmovaps [rsp+0x70], xmm7
000071c0d83d4a02  vmovaps [rsp+0x80], xmm9
000071c0d83d4a0b  vmovaps [rsp+0x90], xmm10
000071c0d83d4a14  vmovaps [rsp+0xA0], xmm11
000071c0d83d4a1d  vmovaps [rsp+0xB0], xmm12
000071c0d83d4a26  vmovaps [rsp+0xC0], xmm13
000071c0d83d4a2f  vmovaps [rsp+0xD0], xmm14
000071c0d83d4a38  vmovaps [rsp+0xE0], xmm15
000071c0d83d4a41  sub rsp, 0x30
000071c0d83d4a45  movaps [rsp], xmm8
000071c0d83d4a4a  movaps [rsp+0x10], xmm14
000071c0d83d4a50  movaps [rsp+0x20], xmm9
000071c0d83d4a56  lea rdi, [rsp]
000071c0d83d4a5a  mov esi, 0x00
000071c0d83d4a5f  mov rax, 0x5904ED15D530
000071c0d83d4a69  call rax
000071c0d83d4a6b  movaps xmm8, [rsp]
000071c0d83d4a70  add rsp, 0x30
000071c0d83d4a74  vmovaps xmm0, [rsp]
000071c0d83d4a79  vmovaps xmm1, [rsp+0x10]
000071c0d83d4a7f  vmovaps xmm2, [rsp+0x20]
000071c0d83d4a85  vmovaps xmm3, [rsp+0x30]
000071c0d83d4a8b  vmovaps xmm4, [rsp+0x40]
000071c0d83d4a91  vmovaps xmm5, [rsp+0x50]
000071c0d83d4a97  vmovaps xmm6, [rsp+0x60]
000071c0d83d4a9d  vmovaps xmm7, [rsp+0x70]
000071c0d83d4aa3  vmovaps xmm9, [rsp+0x80]
000071c0d83d4aac  vmovaps xmm10, [rsp+0x90]
000071c0d83d4ab5  vmovaps xmm11, [rsp+0xA0]
000071c0d83d4abe  vmovaps xmm12, [rsp+0xB0]
000071c0d83d4ac7  vmovaps xmm13, [rsp+0xC0]
000071c0d83d4ad0  vmovaps xmm14, [rsp+0xD0]
000071c0d83d4ad9  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4ae2  add rsp, 0xF0
000071c0d83d4ae9  pop r11
000071c0d83d4aeb  pop r10
000071c0d83d4aed  pop r9
000071c0d83d4aef  pop r8
000071c0d83d4af1  pop rsi
000071c0d83d4af2  pop rdi
000071c0d83d4af3  pop rdx
000071c0d83d4af4  pop rcx
000071c0d83d4af5  pop rax
000071c0d83d4af6  add rsp, 0x08
000071c0d83d4afa  jmp 0x000071C0D83D01AF
000071c0d83d4aff  sub rsp, 0x08
000071c0d83d4b03  push rax
000071c0d83d4b04  push rcx
000071c0d83d4b05  push rdx
000071c0d83d4b06  push rdi
000071c0d83d4b07  push rsi
000071c0d83d4b08  push r8
000071c0d83d4b0a  push r9
000071c0d83d4b0c  push r10
000071c0d83d4b0e  push r11
000071c0d83d4b10  sub rsp, 0xF0
000071c0d83d4b17  vmovaps [rsp], xmm0
000071c0d83d4b1c  vmovaps [rsp+0x10], xmm1
000071c0d83d4b22  vmovaps [rsp+0x20], xmm2
000071c0d83d4b28  vmovaps [rsp+0x30], xmm3
000071c0d83d4b2e  vmovaps [rsp+0x40], xmm4
000071c0d83d4b34  vmovaps [rsp+0x50], xmm5
000071c0d83d4b3a  vmovaps [rsp+0x60], xmm6
000071c0d83d4b40  vmovaps [rsp+0x70], xmm7
000071c0d83d4b46  vmovaps [rsp+0x80], xmm8
000071c0d83d4b4f  vmovaps [rsp+0x90], xmm10
000071c0d83d4b58  vmovaps [rsp+0xA0], xmm11
000071c0d83d4b61  vmovaps [rsp+0xB0], xmm12
000071c0d83d4b6a  vmovaps [rsp+0xC0], xmm13
000071c0d83d4b73  vmovaps [rsp+0xD0], xmm14
000071c0d83d4b7c  vmovaps [rsp+0xE0], xmm15
000071c0d83d4b85  sub rsp, 0x30
000071c0d83d4b89  movaps [rsp], xmm9
000071c0d83d4b8e  movaps [rsp+0x10], xmm1
000071c0d83d4b93  movaps [rsp+0x20], xmm14
000071c0d83d4b99  lea rdi, [rsp]
000071c0d83d4b9d  mov esi, 0x00
000071c0d83d4ba2  mov rax, 0x5904ED15D530
000071c0d83d4bac  call rax
000071c0d83d4bae  movaps xmm9, [rsp]
000071c0d83d4bb3  add rsp, 0x30
000071c0d83d4bb7  vmovaps xmm0, [rsp]
000071c0d83d4bbc  vmovaps xmm1, [rsp+0x10]
000071c0d83d4bc2  vmovaps xmm2, [rsp+0x20]
000071c0d83d4bc8  vmovaps xmm3, [rsp+0x30]
000071c0d83d4bce  vmovaps xmm4, [rsp+0x40]
000071c0d83d4bd4  vmovaps xmm5, [rsp+0x50]
000071c0d83d4bda  vmovaps xmm6, [rsp+0x60]
000071c0d83d4be0  vmovaps xmm7, [rsp+0x70]
000071c0d83d4be6  vmovaps xmm8, [rsp+0x80]
000071c0d83d4bef  vmovaps xmm10, [rsp+0x90]
000071c0d83d4bf8  vmovaps xmm11, [rsp+0xA0]
000071c0d83d4c01  vmovaps xmm12, [rsp+0xB0]
000071c0d83d4c0a  vmovaps xmm13, [rsp+0xC0]
000071c0d83d4c13  vmovaps xmm14, [rsp+0xD0]
000071c0d83d4c1c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4c25  add rsp, 0xF0
000071c0d83d4c2c  pop r11
000071c0d83d4c2e  pop r10
000071c0d83d4c30  pop r9
000071c0d83d4c32  pop r8
000071c0d83d4c34  pop rsi
000071c0d83d4c35  pop rdi
000071c0d83d4c36  pop rdx
000071c0d83d4c37  pop rcx
000071c0d83d4c38  pop rax
000071c0d83d4c39  add rsp, 0x08
000071c0d83d4c3d  jmp 0x000071C0D83D01DD
000071c0d83d4c42  sub rsp, 0x08
000071c0d83d4c46  push rax
000071c0d83d4c47  push rcx
000071c0d83d4c48  push rdx
000071c0d83d4c49  push rdi
000071c0d83d4c4a  push rsi
000071c0d83d4c4b  push r8
000071c0d83d4c4d  push r9
000071c0d83d4c4f  push r10
000071c0d83d4c51  push r11
000071c0d83d4c53  sub rsp, 0xF0
000071c0d83d4c5a  vmovaps [rsp], xmm0
000071c0d83d4c5f  vmovaps [rsp+0x10], xmm1
000071c0d83d4c65  vmovaps [rsp+0x20], xmm2
000071c0d83d4c6b  vmovaps [rsp+0x30], xmm3
000071c0d83d4c71  vmovaps [rsp+0x40], xmm4
000071c0d83d4c77  vmovaps [rsp+0x50], xmm5
000071c0d83d4c7d  vmovaps [rsp+0x60], xmm6
000071c0d83d4c83  vmovaps [rsp+0x70], xmm7
000071c0d83d4c89  vmovaps [rsp+0x80], xmm8
000071c0d83d4c92  vmovaps [rsp+0x90], xmm9
000071c0d83d4c9b  vmovaps [rsp+0xA0], xmm10
000071c0d83d4ca4  vmovaps [rsp+0xB0], xmm11
000071c0d83d4cad  vmovaps [rsp+0xC0], xmm12
000071c0d83d4cb6  vmovaps [rsp+0xD0], xmm13
000071c0d83d4cbf  vmovaps [rsp+0xE0], xmm15
000071c0d83d4cc8  sub rsp, 0x30
000071c0d83d4ccc  movaps [rsp], xmm14
000071c0d83d4cd1  movaps [rsp+0x10], xmm4
000071c0d83d4cd6  movaps [rsp+0x20], xmm1
000071c0d83d4cdb  lea rdi, [rsp]
000071c0d83d4cdf  mov esi, 0x00
000071c0d83d4ce4  mov rax, 0x5904ED15D530
000071c0d83d4cee  call rax
000071c0d83d4cf0  movaps xmm14, [rsp]
000071c0d83d4cf5  add rsp, 0x30
000071c0d83d4cf9  vmovaps xmm0, [rsp]
000071c0d83d4cfe  vmovaps xmm1, [rsp+0x10]
000071c0d83d4d04  vmovaps xmm2, [rsp+0x20]
000071c0d83d4d0a  vmovaps xmm3, [rsp+0x30]
000071c0d83d4d10  vmovaps xmm4, [rsp+0x40]
000071c0d83d4d16  vmovaps xmm5, [rsp+0x50]
000071c0d83d4d1c  vmovaps xmm6, [rsp+0x60]
000071c0d83d4d22  vmovaps xmm7, [rsp+0x70]
000071c0d83d4d28  vmovaps xmm8, [rsp+0x80]
000071c0d83d4d31  vmovaps xmm9, [rsp+0x90]
000071c0d83d4d3a  vmovaps xmm10, [rsp+0xA0]
000071c0d83d4d43  vmovaps xmm11, [rsp+0xB0]
000071c0d83d4d4c  vmovaps xmm12, [rsp+0xC0]
000071c0d83d4d55  vmovaps xmm13, [rsp+0xD0]
000071c0d83d4d5e  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4d67  add rsp, 0xF0
000071c0d83d4d6e  pop r11
000071c0d83d4d70  pop r10
000071c0d83d4d72  pop r9
000071c0d83d4d74  pop r8
000071c0d83d4d76  pop rsi
000071c0d83d4d77  pop rdi
000071c0d83d4d78  pop rdx
000071c0d83d4d79  pop rcx
000071c0d83d4d7a  pop rax
000071c0d83d4d7b  add rsp, 0x08
000071c0d83d4d7f  jmp 0x000071C0D83D0203
000071c0d83d4d84  sub rsp, 0x08
000071c0d83d4d88  push rax
000071c0d83d4d89  push rcx
000071c0d83d4d8a  push rdx
000071c0d83d4d8b  push rdi
000071c0d83d4d8c  push rsi
000071c0d83d4d8d  push r8
000071c0d83d4d8f  push r9
000071c0d83d4d91  push r10
000071c0d83d4d93  push r11
000071c0d83d4d95  sub rsp, 0xF0
000071c0d83d4d9c  vmovaps [rsp], xmm0
000071c0d83d4da1  vmovaps [rsp+0x10], xmm2
000071c0d83d4da7  vmovaps [rsp+0x20], xmm3
000071c0d83d4dad  vmovaps [rsp+0x30], xmm4
000071c0d83d4db3  vmovaps [rsp+0x40], xmm5
000071c0d83d4db9  vmovaps [rsp+0x50], xmm6
000071c0d83d4dbf  vmovaps [rsp+0x60], xmm7
000071c0d83d4dc5  vmovaps [rsp+0x70], xmm8
000071c0d83d4dcb  vmovaps [rsp+0x80], xmm9
000071c0d83d4dd4  vmovaps [rsp+0x90], xmm10
000071c0d83d4ddd  vmovaps [rsp+0xA0], xmm11
000071c0d83d4de6  vmovaps [rsp+0xB0], xmm12
000071c0d83d4def  vmovaps [rsp+0xC0], xmm13
000071c0d83d4df8  vmovaps [rsp+0xD0], xmm14
000071c0d83d4e01  vmovaps [rsp+0xE0], xmm15
000071c0d83d4e0a  sub rsp, 0x30
000071c0d83d4e0e  movaps [rsp], xmm1
000071c0d83d4e12  movaps [rsp+0x10], xmm12
000071c0d83d4e18  movaps [rsp+0x20], xmm11
000071c0d83d4e1e  lea rdi, [rsp]
000071c0d83d4e22  mov esi, 0x00
000071c0d83d4e27  mov rax, 0x5904ED15D530
000071c0d83d4e31  call rax
000071c0d83d4e33  movaps xmm1, [rsp]
000071c0d83d4e37  add rsp, 0x30
000071c0d83d4e3b  vmovaps xmm0, [rsp]
000071c0d83d4e40  vmovaps xmm2, [rsp+0x10]
000071c0d83d4e46  vmovaps xmm3, [rsp+0x20]
000071c0d83d4e4c  vmovaps xmm4, [rsp+0x30]
000071c0d83d4e52  vmovaps xmm5, [rsp+0x40]
000071c0d83d4e58  vmovaps xmm6, [rsp+0x50]
000071c0d83d4e5e  vmovaps xmm7, [rsp+0x60]
000071c0d83d4e64  vmovaps xmm8, [rsp+0x70]
000071c0d83d4e6a  vmovaps xmm9, [rsp+0x80]
000071c0d83d4e73  vmovaps xmm10, [rsp+0x90]
000071c0d83d4e7c  vmovaps xmm11, [rsp+0xA0]
000071c0d83d4e85  vmovaps xmm12, [rsp+0xB0]
000071c0d83d4e8e  vmovaps xmm13, [rsp+0xC0]
000071c0d83d4e97  vmovaps xmm14, [rsp+0xD0]
000071c0d83d4ea0  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4ea9  add rsp, 0xF0
000071c0d83d4eb0  pop r11
000071c0d83d4eb2  pop r10
000071c0d83d4eb4  pop r9
000071c0d83d4eb6  pop r8
000071c0d83d4eb8  pop rsi
000071c0d83d4eb9  pop rdi
000071c0d83d4eba  pop rdx
000071c0d83d4ebb  pop rcx
000071c0d83d4ebc  pop rax
000071c0d83d4ebd  add rsp, 0x08
000071c0d83d4ec1  jmp 0x000071C0D83D0224
000071c0d83d4ec6  call 0x000071C0D82E20A0
000071c0d83d4ecb  jmp 0x000071C0D83D0232
000071c0d83d4ed0  call 0x000071C0D8209D70
000071c0d83d4ed5  jmp 0x000071C0D83D023C
000071c0d83d4eda  sub rsp, 0x08
000071c0d83d4ede  push rax
000071c0d83d4edf  push rcx
000071c0d83d4ee0  push rdx
000071c0d83d4ee1  push rdi
000071c0d83d4ee2  push rsi
000071c0d83d4ee3  push r8
000071c0d83d4ee5  push r9
000071c0d83d4ee7  push r10
000071c0d83d4ee9  push r11
000071c0d83d4eeb  sub rsp, 0xF0
000071c0d83d4ef2  vmovaps [rsp], xmm0
000071c0d83d4ef7  vmovaps [rsp+0x10], xmm1
000071c0d83d4efd  vmovaps [rsp+0x20], xmm2
000071c0d83d4f03  vmovaps [rsp+0x30], xmm3
000071c0d83d4f09  vmovaps [rsp+0x40], xmm4
000071c0d83d4f0f  vmovaps [rsp+0x50], xmm5
000071c0d83d4f15  vmovaps [rsp+0x60], xmm6
000071c0d83d4f1b  vmovaps [rsp+0x70], xmm8
000071c0d83d4f21  vmovaps [rsp+0x80], xmm9
000071c0d83d4f2a  vmovaps [rsp+0x90], xmm10
000071c0d83d4f33  vmovaps [rsp+0xA0], xmm11
000071c0d83d4f3c  vmovaps [rsp+0xB0], xmm12
000071c0d83d4f45  vmovaps [rsp+0xC0], xmm13
000071c0d83d4f4e  vmovaps [rsp+0xD0], xmm14
000071c0d83d4f57  vmovaps [rsp+0xE0], xmm15
000071c0d83d4f60  sub rsp, 0x30
000071c0d83d4f64  movaps [rsp], xmm7
000071c0d83d4f68  movaps [rsp+0x10], xmm15
000071c0d83d4f6e  movaps [rsp+0x20], xmm10
000071c0d83d4f74  lea rdi, [rsp]
000071c0d83d4f78  mov esi, 0x00
000071c0d83d4f7d  mov rax, 0x5904ED15D530
000071c0d83d4f87  call rax
000071c0d83d4f89  movaps xmm7, [rsp]
000071c0d83d4f8d  add rsp, 0x30
000071c0d83d4f91  vmovaps xmm0, [rsp]
000071c0d83d4f96  vmovaps xmm1, [rsp+0x10]
000071c0d83d4f9c  vmovaps xmm2, [rsp+0x20]
000071c0d83d4fa2  vmovaps xmm3, [rsp+0x30]
000071c0d83d4fa8  vmovaps xmm4, [rsp+0x40]
000071c0d83d4fae  vmovaps xmm5, [rsp+0x50]
000071c0d83d4fb4  vmovaps xmm6, [rsp+0x60]
000071c0d83d4fba  vmovaps xmm8, [rsp+0x70]
000071c0d83d4fc0  vmovaps xmm9, [rsp+0x80]
000071c0d83d4fc9  vmovaps xmm10, [rsp+0x90]
000071c0d83d4fd2  vmovaps xmm11, [rsp+0xA0]
000071c0d83d4fdb  vmovaps xmm12, [rsp+0xB0]
000071c0d83d4fe4  vmovaps xmm13, [rsp+0xC0]
000071c0d83d4fed  vmovaps xmm14, [rsp+0xD0]
000071c0d83d4ff6  vmovaps xmm15, [rsp+0xE0]
000071c0d83d4fff  add rsp, 0xF0
000071c0d83d5006  pop r11
000071c0d83d5008  pop r10
000071c0d83d500a  pop r9
000071c0d83d500c  pop r8
000071c0d83d500e  pop rsi
000071c0d83d500f  pop rdi
000071c0d83d5010  pop rdx
000071c0d83d5011  pop rcx
000071c0d83d5012  pop rax
000071c0d83d5013  add rsp, 0x08
000071c0d83d5017  jmp 0x000071C0D83D025D
000071c0d83d501c  sub rsp, 0x08
000071c0d83d5020  push rax
000071c0d83d5021  push rcx
000071c0d83d5022  push rdx
000071c0d83d5023  push rdi
000071c0d83d5024  push rsi
000071c0d83d5025  push r8
000071c0d83d5027  push r9
000071c0d83d5029  push r10
000071c0d83d502b  push r11
000071c0d83d502d  sub rsp, 0xF0
000071c0d83d5034  vmovaps [rsp], xmm0
000071c0d83d5039  vmovaps [rsp+0x10], xmm1
000071c0d83d503f  vmovaps [rsp+0x20], xmm2
000071c0d83d5045  vmovaps [rsp+0x30], xmm3
000071c0d83d504b  vmovaps [rsp+0x40], xmm4
000071c0d83d5051  vmovaps [rsp+0x50], xmm5
000071c0d83d5057  vmovaps [rsp+0x60], xmm6
000071c0d83d505d  vmovaps [rsp+0x70], xmm7
000071c0d83d5063  vmovaps [rsp+0x80], xmm8
000071c0d83d506c  vmovaps [rsp+0x90], xmm9
000071c0d83d5075  vmovaps [rsp+0xA0], xmm11
000071c0d83d507e  vmovaps [rsp+0xB0], xmm12
000071c0d83d5087  vmovaps [rsp+0xC0], xmm13
000071c0d83d5090  vmovaps [rsp+0xD0], xmm14
000071c0d83d5099  vmovaps [rsp+0xE0], xmm15
000071c0d83d50a2  sub rsp, 0x30
000071c0d83d50a6  movaps [rsp], xmm10
000071c0d83d50ab  movaps [rsp+0x10], xmm11
000071c0d83d50b1  movaps [rsp+0x20], xmm15
000071c0d83d50b7  lea rdi, [rsp]
000071c0d83d50bb  mov esi, 0x00
000071c0d83d50c0  mov rax, 0x5904ED15D530
000071c0d83d50ca  call rax
000071c0d83d50cc  movaps xmm10, [rsp]
000071c0d83d50d1  add rsp, 0x30
000071c0d83d50d5  vmovaps xmm0, [rsp]
000071c0d83d50da  vmovaps xmm1, [rsp+0x10]
000071c0d83d50e0  vmovaps xmm2, [rsp+0x20]
000071c0d83d50e6  vmovaps xmm3, [rsp+0x30]
000071c0d83d50ec  vmovaps xmm4, [rsp+0x40]
000071c0d83d50f2  vmovaps xmm5, [rsp+0x50]
000071c0d83d50f8  vmovaps xmm6, [rsp+0x60]
000071c0d83d50fe  vmovaps xmm7, [rsp+0x70]
000071c0d83d5104  vmovaps xmm8, [rsp+0x80]
000071c0d83d510d  vmovaps xmm9, [rsp+0x90]
000071c0d83d5116  vmovaps xmm11, [rsp+0xA0]
000071c0d83d511f  vmovaps xmm12, [rsp+0xB0]
000071c0d83d5128  vmovaps xmm13, [rsp+0xC0]
000071c0d83d5131  vmovaps xmm14, [rsp+0xD0]
000071c0d83d513a  vmovaps xmm15, [rsp+0xE0]
000071c0d83d5143  add rsp, 0xF0
000071c0d83d514a  pop r11
000071c0d83d514c  pop r10
000071c0d83d514e  pop r9
000071c0d83d5150  pop r8
000071c0d83d5152  pop rsi
000071c0d83d5153  pop rdi
000071c0d83d5154  pop rdx
000071c0d83d5155  pop rcx
000071c0d83d5156  pop rax
000071c0d83d5157  add rsp, 0x08
000071c0d83d515b  jmp 0x000071C0D83D028B
000071c0d83d5160  sub rsp, 0x08
000071c0d83d5164  push rax
000071c0d83d5165  push rcx
000071c0d83d5166  push rdx
000071c0d83d5167  push rdi
000071c0d83d5168  push rsi
000071c0d83d5169  push r8
000071c0d83d516b  push r9
000071c0d83d516d  push r10
000071c0d83d516f  push r11
000071c0d83d5171  sub rsp, 0xF0
000071c0d83d5178  vmovaps [rsp], xmm0
000071c0d83d517d  vmovaps [rsp+0x10], xmm1
000071c0d83d5183  vmovaps [rsp+0x20], xmm2
000071c0d83d5189  vmovaps [rsp+0x30], xmm3
000071c0d83d518f  vmovaps [rsp+0x40], xmm4
000071c0d83d5195  vmovaps [rsp+0x50], xmm5
000071c0d83d519b  vmovaps [rsp+0x60], xmm6
000071c0d83d51a1  vmovaps [rsp+0x70], xmm7
000071c0d83d51a7  vmovaps [rsp+0x80], xmm8
000071c0d83d51b0  vmovaps [rsp+0x90], xmm9
000071c0d83d51b9  vmovaps [rsp+0xA0], xmm10
000071c0d83d51c2  vmovaps [rsp+0xB0], xmm12
000071c0d83d51cb  vmovaps [rsp+0xC0], xmm13
000071c0d83d51d4  vmovaps [rsp+0xD0], xmm14
000071c0d83d51dd  vmovaps [rsp+0xE0], xmm15
000071c0d83d51e6  sub rsp, 0x30
000071c0d83d51ea  movaps [rsp], xmm11
000071c0d83d51ef  movaps [rsp+0x10], xmm12
000071c0d83d51f5  movaps [rsp+0x20], xmm15
000071c0d83d51fb  lea rdi, [rsp]
000071c0d83d51ff  mov esi, 0x00
000071c0d83d5204  mov rax, 0x5904ED15D530
000071c0d83d520e  call rax
000071c0d83d5210  movaps xmm11, [rsp]
000071c0d83d5215  add rsp, 0x30
000071c0d83d5219  vmovaps xmm0, [rsp]
000071c0d83d521e  vmovaps xmm1, [rsp+0x10]
000071c0d83d5224  vmovaps xmm2, [rsp+0x20]
000071c0d83d522a  vmovaps xmm3, [rsp+0x30]
000071c0d83d5230  vmovaps xmm4, [rsp+0x40]
000071c0d83d5236  vmovaps xmm5, [rsp+0x50]
000071c0d83d523c  vmovaps xmm6, [rsp+0x60]
000071c0d83d5242  vmovaps xmm7, [rsp+0x70]
000071c0d83d5248  vmovaps xmm8, [rsp+0x80]
000071c0d83d5251  vmovaps xmm9, [rsp+0x90]
000071c0d83d525a  vmovaps xmm10, [rsp+0xA0]
000071c0d83d5263  vmovaps xmm12, [rsp+0xB0]
000071c0d83d526c  vmovaps xmm13, [rsp+0xC0]
000071c0d83d5275  vmovaps xmm14, [rsp+0xD0]
000071c0d83d527e  vmovaps xmm15, [rsp+0xE0]
000071c0d83d5287  add rsp, 0xF0
000071c0d83d528e  pop r11
000071c0d83d5290  pop r10
000071c0d83d5292  pop r9
000071c0d83d5294  pop r8
000071c0d83d5296  pop rsi
000071c0d83d5297  pop rdi
000071c0d83d5298  pop rdx
000071c0d83d5299  pop rcx
000071c0d83d529a  pop rax
000071c0d83d529b  add rsp, 0x08
000071c0d83d529f  jmp 0x000071C0D83D02B9
000071c0d83d52a4  sub rsp, 0x08
000071c0d83d52a8  push rax
000071c0d83d52a9  push rcx
000071c0d83d52aa  push rdx
000071c0d83d52ab  push rdi
000071c0d83d52ac  push rsi
000071c0d83d52ad  push r8
000071c0d83d52af  push r9
000071c0d83d52b1  push r10
000071c0d83d52b3  push r11
000071c0d83d52b5  sub rsp, 0xF0
000071c0d83d52bc  vmovaps [rsp], xmm0
000071c0d83d52c1  vmovaps [rsp+0x10], xmm1
000071c0d83d52c7  vmovaps [rsp+0x20], xmm2
000071c0d83d52cd  vmovaps [rsp+0x30], xmm3
000071c0d83d52d3  vmovaps [rsp+0x40], xmm4
000071c0d83d52d9  vmovaps [rsp+0x50], xmm5
000071c0d83d52df  vmovaps [rsp+0x60], xmm6
000071c0d83d52e5  vmovaps [rsp+0x70], xmm7
000071c0d83d52eb  vmovaps [rsp+0x80], xmm8
000071c0d83d52f4  vmovaps [rsp+0x90], xmm9
000071c0d83d52fd  vmovaps [rsp+0xA0], xmm10
000071c0d83d5306  vmovaps [rsp+0xB0], xmm11
000071c0d83d530f  vmovaps [rsp+0xC0], xmm12
000071c0d83d5318  vmovaps [rsp+0xD0], xmm13
000071c0d83d5321  vmovaps [rsp+0xE0], xmm14
000071c0d83d532a  sub rsp, 0x30
000071c0d83d532e  movaps [rsp], xmm15
000071c0d83d5333  movaps [rsp+0x10], xmm13
000071c0d83d5339  movaps [rsp+0x20], xmm9
000071c0d83d533f  lea rdi, [rsp]
000071c0d83d5343  mov esi, 0x00
000071c0d83d5348  mov rax, 0x5904ED15D530
000071c0d83d5352  call rax
000071c0d83d5354  movaps xmm15, [rsp]
000071c0d83d5359  add rsp, 0x30
000071c0d83d535d  vmovaps xmm0, [rsp]
000071c0d83d5362  vmovaps xmm1, [rsp+0x10]
000071c0d83d5368  vmovaps xmm2, [rsp+0x20]
000071c0d83d536e  vmovaps xmm3, [rsp+0x30]
000071c0d83d5374  vmovaps xmm4, [rsp+0x40]
000071c0d83d537a  vmovaps xmm5, [rsp+0x50]
000071c0d83d5380  vmovaps xmm6, [rsp+0x60]
000071c0d83d5386  vmovaps xmm7, [rsp+0x70]
000071c0d83d538c  vmovaps xmm8, [rsp+0x80]
000071c0d83d5395  vmovaps xmm9, [rsp+0x90]
000071c0d83d539e  vmovaps xmm10, [rsp+0xA0]
000071c0d83d53a7  vmovaps xmm11, [rsp+0xB0]
000071c0d83d53b0  vmovaps xmm12, [rsp+0xC0]
000071c0d83d53b9  vmovaps xmm13, [rsp+0xD0]
000071c0d83d53c2  vmovaps xmm14, [rsp+0xE0]
000071c0d83d53cb  add rsp, 0xF0
000071c0d83d53d2  pop r11
000071c0d83d53d4  pop r10
000071c0d83d53d6  pop r9
000071c0d83d53d8  pop r8
000071c0d83d53da  pop rsi
000071c0d83d53db  pop rdi
000071c0d83d53dc  pop rdx
000071c0d83d53dd  pop rcx
000071c0d83d53de  pop rax
000071c0d83d53df  add rsp, 0x08
000071c0d83d53e3  jmp 0x000071C0D83D02D4
000071c0d83d53e8  sub rsp, 0x08
000071c0d83d53ec  push rax
000071c0d83d53ed  push rcx
000071c0d83d53ee  push rdx
000071c0d83d53ef  push rdi
000071c0d83d53f0  push rsi
000071c0d83d53f1  push r8
000071c0d83d53f3  push r9
000071c0d83d53f5  push r10
000071c0d83d53f7  push r11
000071c0d83d53f9  sub rsp, 0xF0
000071c0d83d5400  vmovaps [rsp], xmm0
000071c0d83d5405  vmovaps [rsp+0x10], xmm1
000071c0d83d540b  vmovaps [rsp+0x20], xmm2
000071c0d83d5411  vmovaps [rsp+0x30], xmm3
000071c0d83d5417  vmovaps [rsp+0x40], xmm4
000071c0d83d541d  vmovaps [rsp+0x50], xmm5
000071c0d83d5423  vmovaps [rsp+0x60], xmm6
000071c0d83d5429  vmovaps [rsp+0x70], xmm7
000071c0d83d542f  vmovaps [rsp+0x80], xmm8
000071c0d83d5438  vmovaps [rsp+0x90], xmm9
000071c0d83d5441  vmovaps [rsp+0xA0], xmm10
000071c0d83d544a  vmovaps [rsp+0xB0], xmm11
000071c0d83d5453  vmovaps [rsp+0xC0], xmm12
000071c0d83d545c  vmovaps [rsp+0xD0], xmm14
000071c0d83d5465  vmovaps [rsp+0xE0], xmm15
000071c0d83d546e  sub rsp, 0x30
000071c0d83d5472  movaps [rsp], xmm13
000071c0d83d5477  movaps [rsp+0x10], xmm8
000071c0d83d547d  movaps [rsp+0x20], xmm14
000071c0d83d5483  lea rdi, [rsp]
000071c0d83d5487  mov esi, 0x00
000071c0d83d548c  mov rax, 0x5904ED15D530
000071c0d83d5496  call rax
000071c0d83d5498  movaps xmm13, [rsp]
000071c0d83d549d  add rsp, 0x30
000071c0d83d54a1  vmovaps xmm0, [rsp]
000071c0d83d54a6  vmovaps xmm1, [rsp+0x10]
000071c0d83d54ac  vmovaps xmm2, [rsp+0x20]
000071c0d83d54b2  vmovaps xmm3, [rsp+0x30]
000071c0d83d54b8  vmovaps xmm4, [rsp+0x40]
000071c0d83d54be  vmovaps xmm5, [rsp+0x50]
000071c0d83d54c4  vmovaps xmm6, [rsp+0x60]
000071c0d83d54ca  vmovaps xmm7, [rsp+0x70]
000071c0d83d54d0  vmovaps xmm8, [rsp+0x80]
000071c0d83d54d9  vmovaps xmm9, [rsp+0x90]
000071c0d83d54e2  vmovaps xmm10, [rsp+0xA0]
000071c0d83d54eb  vmovaps xmm11, [rsp+0xB0]
000071c0d83d54f4  vmovaps xmm12, [rsp+0xC0]
000071c0d83d54fd  vmovaps xmm14, [rsp+0xD0]
000071c0d83d5506  vmovaps xmm15, [rsp+0xE0]
000071c0d83d550f  add rsp, 0xF0
000071c0d83d5516  pop r11
000071c0d83d5518  pop r10
000071c0d83d551a  pop r9
000071c0d83d551c  pop r8
000071c0d83d551e  pop rsi
000071c0d83d551f  pop rdi
000071c0d83d5520  pop rdx
000071c0d83d5521  pop rcx
000071c0d83d5522  pop rax
000071c0d83d5523  add rsp, 0x08
000071c0d83d5527  jmp 0x000071C0D83D02F7
000071c0d83d552c  sub rsp, 0x08
000071c0d83d5530  push rax
000071c0d83d5531  push rcx
000071c0d83d5532  push rdx
000071c0d83d5533  push rdi
000071c0d83d5534  push rsi
000071c0d83d5535  push r8
000071c0d83d5537  push r9
000071c0d83d5539  push r10
000071c0d83d553b  push r11
000071c0d83d553d  sub rsp, 0xF0
000071c0d83d5544  vmovaps [rsp], xmm0
000071c0d83d5549  vmovaps [rsp+0x10], xmm1
000071c0d83d554f  vmovaps [rsp+0x20], xmm2
000071c0d83d5555  vmovaps [rsp+0x30], xmm3
000071c0d83d555b  vmovaps [rsp+0x40], xmm4
000071c0d83d5561  vmovaps [rsp+0x50], xmm5
000071c0d83d5567  vmovaps [rsp+0x60], xmm6
000071c0d83d556d  vmovaps [rsp+0x70], xmm7
000071c0d83d5573  vmovaps [rsp+0x80], xmm8
000071c0d83d557c  vmovaps [rsp+0x90], xmm9
000071c0d83d5585  vmovaps [rsp+0xA0], xmm10
000071c0d83d558e  vmovaps [rsp+0xB0], xmm11
000071c0d83d5597  vmovaps [rsp+0xC0], xmm12
000071c0d83d55a0  vmovaps [rsp+0xD0], xmm13
000071c0d83d55a9  vmovaps [rsp+0xE0], xmm15
000071c0d83d55b2  sub rsp, 0x30
000071c0d83d55b6  movaps [rsp], xmm14
000071c0d83d55bb  movaps [rsp+0x10], xmm1
000071c0d83d55c0  movaps [rsp+0x20], xmm10
000071c0d83d55c6  lea rdi, [rsp]
000071c0d83d55ca  mov esi, 0x00
000071c0d83d55cf  mov rax, 0x5904ED15D530
000071c0d83d55d9  call rax
000071c0d83d55db  movaps xmm14, [rsp]
000071c0d83d55e0  add rsp, 0x30
000071c0d83d55e4  vmovaps xmm0, [rsp]
000071c0d83d55e9  vmovaps xmm1, [rsp+0x10]
000071c0d83d55ef  vmovaps xmm2, [rsp+0x20]
000071c0d83d55f5  vmovaps xmm3, [rsp+0x30]
000071c0d83d55fb  vmovaps xmm4, [rsp+0x40]
000071c0d83d5601  vmovaps xmm5, [rsp+0x50]
000071c0d83d5607  vmovaps xmm6, [rsp+0x60]
000071c0d83d560d  vmovaps xmm7, [rsp+0x70]
000071c0d83d5613  vmovaps xmm8, [rsp+0x80]
000071c0d83d561c  vmovaps xmm9, [rsp+0x90]
000071c0d83d5625  vmovaps xmm10, [rsp+0xA0]
000071c0d83d562e  vmovaps xmm11, [rsp+0xB0]
000071c0d83d5637  vmovaps xmm12, [rsp+0xC0]
000071c0d83d5640  vmovaps xmm13, [rsp+0xD0]
000071c0d83d5649  vmovaps xmm15, [rsp+0xE0]
000071c0d83d5652  add rsp, 0xF0
000071c0d83d5659  pop r11
000071c0d83d565b  pop r10
000071c0d83d565d  pop r9
000071c0d83d565f  pop r8
000071c0d83d5661  pop rsi
000071c0d83d5662  pop rdi
000071c0d83d5663  pop rdx
000071c0d83d5664  pop rcx
000071c0d83d5665  pop rax
000071c0d83d5666  add rsp, 0x08
000071c0d83d566a  jmp 0x000071C0D83D031A
000071c0d83d566f  sub rsp, 0x08
000071c0d83d5673  push rax
000071c0d83d5674  push rcx
000071c0d83d5675  push rdx
000071c0d83d5676  push rdi
000071c0d83d5677  push rsi
000071c0d83d5678  push r8
000071c0d83d567a  push r9
000071c0d83d567c  push r10
000071c0d83d567e  push r11
000071c0d83d5680  sub rsp, 0xF0
000071c0d83d5687  vmovaps [rsp], xmm0
000071c0d83d568c  vmovaps [rsp+0x10], xmm2
000071c0d83d5692  vmovaps [rsp+0x20], xmm3
000071c0d83d5698  vmovaps [rsp+0x30], xmm4
000071c0d83d569e  vmovaps [rsp+0x40], xmm5
000071c0d83d56a4  vmovaps [rsp+0x50], xmm6
000071c0d83d56aa  vmovaps [rsp+0x60], xmm7
000071c0d83d56b0  vmovaps [rsp+0x70], xmm8
000071c0d83d56b6  vmovaps [rsp+0x80], xmm9
000071c0d83d56bf  vmovaps [rsp+0x90], xmm10
000071c0d83d56c8  vmovaps [rsp+0xA0], xmm11
000071c0d83d56d1  vmovaps [rsp+0xB0], xmm12
000071c0d83d56da  vmovaps [rsp+0xC0], xmm13
000071c0d83d56e3  vmovaps [rsp+0xD0], xmm14
000071c0d83d56ec  vmovaps [rsp+0xE0], xmm15
000071c0d83d56f5  sub rsp, 0x30
000071c0d83d56f9  movaps [rsp], xmm1
000071c0d83d56fd  movaps [rsp+0x10], xmm7
000071c0d83d5702  movaps [rsp+0x20], xmm11
000071c0d83d5708  lea rdi, [rsp]
000071c0d83d570c  mov esi, 0x00
000071c0d83d5711  mov rax, 0x5904ED15D530
000071c0d83d571b  call rax
000071c0d83d571d  movaps xmm1, [rsp]
000071c0d83d5721  add rsp, 0x30
000071c0d83d5725  vmovaps xmm0, [rsp]
000071c0d83d572a  vmovaps xmm2, [rsp+0x10]
000071c0d83d5730  vmovaps xmm3, [rsp+0x20]
000071c0d83d5736  vmovaps xmm4, [rsp+0x30]
000071c0d83d573c  vmovaps xmm5, [rsp+0x40]
000071c0d83d5742  vmovaps xmm6, [rsp+0x50]
000071c0d83d5748  vmovaps xmm7, [rsp+0x60]
000071c0d83d574e  vmovaps xmm8, [rsp+0x70]
000071c0d83d5754  vmovaps xmm9, [rsp+0x80]
000071c0d83d575d  vmovaps xmm10, [rsp+0x90]
000071c0d83d5766  vmovaps xmm11, [rsp+0xA0]
000071c0d83d576f  vmovaps xmm12, [rsp+0xB0]
000071c0d83d5778  vmovaps xmm13, [rsp+0xC0]
000071c0d83d5781  vmovaps xmm14, [rsp+0xD0]
000071c0d83d578a  vmovaps xmm15, [rsp+0xE0]
000071c0d83d5793  add rsp, 0xF0
000071c0d83d579a  pop r11
000071c0d83d579c  pop r10
000071c0d83d579e  pop r9
000071c0d83d57a0  pop r8
000071c0d83d57a2  pop rsi
000071c0d83d57a3  pop rdi
000071c0d83d57a4  pop rdx
000071c0d83d57a5  pop rcx
000071c0d83d57a6  pop rax
000071c0d83d57a7  add rsp, 0x08
000071c0d83d57ab  jmp 0x000071C0D83D033B
000071c0d83d57b0  call 0x000071C0D820E880
000071c0d83d57b5  jmp 0x000071C0D83D034E
000071c0d83d57ba  call 0x000071C0D820C380
000071c0d83d57bf  jmp 0x000071C0D83D0359
000071c0d83d57c4  call 0x000071C0D820D600
000071c0d83d57c9  jmp 0x000071C0D83D0364
000071c0d83d57ce  call 0x000071C0D81FF540
000071c0d83d57d3  jmp 0x000071C0D83D036F
000071c0d83d57d8  int3
000071c0d83d57d9  nop [rax], eax
000071c0d83d57e0  mov rax, [r15+0x40]
000071c0d83d57e4  mov r14, [r15+0x58]
000071c0d83d57e8  lea r12, [rax+r14*1]
000071c0d83d57ec  movaps xmm1, [r15+0x1D0]
000071c0d83d57f4  vmovaps [rsp+0x10], xmm1
000071c0d83d57fa  vmovaps xmm15, [rsp+0x10]
000071c0d83d5800  por xmm1, xmm15
000071c0d83d5805  movaps xmm14, [r15+0x1A0]
000071c0d83d580d  vmovaps [rsp+0x10], xmm14
000071c0d83d5813  vmovaps xmm13, [rsp+0x10]
000071c0d83d5819  por xmm14, xmm13
000071c0d83d581e  lea rax, [r12+0x30]
000071c0d83d5823  mov r11, [r13+rax*1]
000071c0d83d5828  lea rax, [r12+0x38]
000071c0d83d582d  mov r10, [r13+rax*1]
000071c0d83d5832  movq xmm13, r11
000071c0d83d5837  movq xmm12, r10
000071c0d83d583c  movq xmm13, xmm13
000071c0d83d5841  vmovaps [rsp+0x10], xmm13
000071c0d83d5847  movq xmm13, xmm13
000071c0d83d584c  movaps [r15+0x130], xmm13
000071c0d83d5854  movq xmm12, xmm12
000071c0d83d5859  vmovaps [rsp+0x20], xmm12
000071c0d83d585f  movq xmm12, xmm12
000071c0d83d5864  movaps [r15+0x280], xmm12
000071c0d83d586c  movaps xmm13, [r15+0x270]
000071c0d83d5874  vmovaps [rsp+0x30], xmm13
000071c0d83d587a  vmovaps xmm12, [rsp+0x30]
000071c0d83d5880  por xmm13, xmm12
000071c0d83d5885  lea rax, [r12+0x20]
000071c0d83d588a  mov r11, [r13+rax*1]
000071c0d83d588f  lea rax, [r12+0x28]
000071c0d83d5894  mov r10, [r13+rax*1]
000071c0d83d5899  movq xmm12, r11
000071c0d83d589e  movq xmm11, r10
000071c0d83d58a3  movq xmm12, xmm12
000071c0d83d58a8  vmovaps [rsp+0x30], xmm12
000071c0d83d58ae  movq xmm12, xmm12
000071c0d83d58b3  movaps [r15+0x150], xmm12
000071c0d83d58bb  movq xmm11, xmm11
000071c0d83d58c0  vmovaps [rsp+0x40], xmm11
000071c0d83d58c6  movq xmm11, xmm11
000071c0d83d58cb  movaps [r15+0x140], xmm11
000071c0d83d58d3  lea rax, [r12+0x10]
000071c0d83d58d8  mov r11, [r13+rax*1]
000071c0d83d58dd  lea rax, [r12+0x18]
000071c0d83d58e2  mov r10, [r13+rax*1]
000071c0d83d58e7  movq xmm12, r11
000071c0d83d58ec  movq xmm11, r10
000071c0d83d58f1  movq xmm12, xmm12
000071c0d83d58f6  vmovaps [rsp+0x50], xmm12
000071c0d83d58fc  movq xmm12, xmm12
000071c0d83d5901  movaps [r15+0x170], xmm12
000071c0d83d5909  movq xmm11, xmm11
000071c0d83d590e  vmovaps [rsp+0x60], xmm11
000071c0d83d5914  movq xmm11, xmm11
000071c0d83d5919  movaps [r15+0x160], xmm11
000071c0d83d5921  mov rax, [r13+r12*1]
000071c0d83d5926  vmovq xmm12, rax
000071c0d83d592b  vpbroadcastq xmm12, xmm12
000071c0d83d5930  lea rax, [r12+0x08]
000071c0d83d5935  mov r12, [r13+rax*1]
000071c0d83d593a  movq xmm11, r12
000071c0d83d593f  movaps [r15+0x230], xmm11
000071c0d83d5947  mov rax, [r15+0xF8]
000071c0d83d594e  lea r12, [rax+0x50]
000071c0d83d5952  movups xmm11, [r13+r12*1]
000071c0d83d5958  lea r12, [rax+0x60]
000071c0d83d595c  movups xmm10, [r13+r12*1]
000071c0d83d5962  lea r12, [rax+0x30]
000071c0d83d5966  movups xmm9, [r13+r12*1]
000071c0d83d596c  mov r12, [r15+0x50]
000071c0d83d5970  lea r11, [r12+r14*1]
000071c0d83d5974  mov [r15+0x60], r11
000071c0d83d5978  lea r12, [r14+0x40]
000071c0d83d597c  mov [r15+0x58], r12
000071c0d83d5980  movaps xmm8, xmm12
000071c0d83d5984  mulpd xmm8, xmm15
000071c0d83d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000071c0d83d598f  ptest xmm7, xmm7
000071c0d83d5994  jnz 0x000071C0D83D67B7
000071c0d83d599a  movq xmm15, qword ptr [r15+0x230]
000071c0d83d59a3  vmovaps [rsp+0x70], xmm15
000071c0d83d59a9  vpermilpd xmm15, xmm15, 0x00
000071c0d83d59af  movaps xmm7, xmm9
000071c0d83d59b3  mulpd xmm7, xmm15
000071c0d83d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000071c0d83d59bd  ptest xmm6, xmm6
000071c0d83d59c2  jnz 0x000071C0D83D68FB
000071c0d83d59c8  vxorps xmm15, xmm15, xmm15
000071c0d83d59cd  vpbroadcastq xmm15, xmm15
000071c0d83d59d2  movaps xmm9, xmm12
000071c0d83d59d6  mulpd xmm9, xmm10
000071c0d83d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000071c0d83d59e1  ptest xmm6, xmm6
000071c0d83d59e6  jnz 0x000071C0D83D6A3D
000071c0d83d59ec  movaps xmm10, xmm12
000071c0d83d59f0  mulpd xmm10, xmm11
000071c0d83d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000071c0d83d59fb  ptest xmm6, xmm6
000071c0d83d5a00  jnz 0x000071C0D83D6B81
000071c0d83d5a06  movaps xmm11, [r15+0x1F0]
000071c0d83d5a0e  movaps xmm6, xmm12
000071c0d83d5a12  mulpd xmm6, xmm11
000071c0d83d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000071c0d83d5a1c  ptest xmm5, xmm5
000071c0d83d5a21  jnz 0x000071C0D83D6CC5
000071c0d83d5a27  movaps xmm12, [r15+0x2A0]
000071c0d83d5a2f  vmovaps [rsp+0x80], xmm12
000071c0d83d5a38  vmovaps xmm11, [rsp+0x80]
000071c0d83d5a41  por xmm12, xmm11
000071c0d83d5a46  movaps xmm11, [r15+0x250]
000071c0d83d5a4e  vmovaps [rsp+0x80], xmm11
000071c0d83d5a57  vmovaps xmm5, [rsp+0x80]
000071c0d83d5a60  por xmm11, xmm5
000071c0d83d5a65  vmovaps xmm4, [rsp+0x70]
000071c0d83d5a6b  vpermilpd xmm4, xmm4, 0x00
000071c0d83d5a71  movaps xmm3, xmm5
000071c0d83d5a74  mulpd xmm3, xmm4
000071c0d83d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000071c0d83d5a7d  ptest xmm2, xmm2
000071c0d83d5a82  jnz 0x000071C0D83D6E07
000071c0d83d5a88  mov [rsp+0x80], rax
000071c0d83d5a90  xor eax, eax
000071c0d83d5a92  mov r14d, 0x200
000071c0d83d5a98  cmp r12, r14
000071c0d83d5a9b  cmc
000071c0d83d5a9c  lahf
000071c0d83d5a9d  seto al
000071c0d83d5aa0  mov [r15+0x108], eax
000071c0d83d5aa7  movaps xmm5, xmm8
000071c0d83d5aab  addpd xmm5, xmm15
000071c0d83d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000071c0d83d5ab5  ptest xmm4, xmm4
000071c0d83d5aba  jnz 0x000071C0D83D6F47
000071c0d83d5ac0  movaps xmm8, [r15+0x1B0]
000071c0d83d5ac8  movaps xmm4, xmm9
000071c0d83d5acc  addpd xmm4, xmm8
000071c0d83d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000071c0d83d5ad6  ptest xmm2, xmm2
000071c0d83d5adb  jnz 0x000071C0D83D7089
000071c0d83d5ae1  movaps xmm9, xmm10
000071c0d83d5ae5  addpd xmm9, xmm8
000071c0d83d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000071c0d83d5af0  ptest xmm2, xmm2
000071c0d83d5af5  jnz 0x000071C0D83D71CB
000071c0d83d5afb  movaps xmm10, [r15+0x2F0]
000071c0d83d5b03  vmovaps [rsp+0x90], xmm10
000071c0d83d5b0c  vmovaps xmm8, [rsp+0x90]
000071c0d83d5b15  por xmm10, xmm8
000071c0d83d5b1a  movaps xmm8, [r15+0x2E0]
000071c0d83d5b22  vmovaps [rsp+0x90], xmm8
000071c0d83d5b2b  vmovaps xmm2, [rsp+0x90]
000071c0d83d5b34  por xmm8, xmm2
000071c0d83d5b39  movaps xmm2, [r15+0x2D0]
000071c0d83d5b41  vmovaps [rsp+0x90], xmm2
000071c0d83d5b4a  vmovaps [rsp+0xA0], xmm1
000071c0d83d5b53  vmovaps xmm1, [rsp+0x90]
000071c0d83d5b5c  por xmm2, xmm1
000071c0d83d5b60  movaps xmm1, [r15+0x200]
000071c0d83d5b68  vmovaps [rsp+0x90], xmm1
000071c0d83d5b71  vmovaps [rsp+0xB0], xmm15
000071c0d83d5b7a  vmovaps xmm15, [rsp+0x90]
000071c0d83d5b83  por xmm1, xmm15
000071c0d83d5b88  movaps xmm15, [r15+0x1C0]
000071c0d83d5b90  vmovaps [rsp+0x90], xmm15
000071c0d83d5b99  vmovaps [rsp+0xC0], xmm1
000071c0d83d5ba2  vmovaps xmm1, [rsp+0x90]
000071c0d83d5bab  por xmm15, xmm1
000071c0d83d5bb0  movaps xmm1, [r15+0x190]
000071c0d83d5bb8  vmovaps [rsp+0x90], xmm1
000071c0d83d5bc1  vmovaps [rsp+0xD0], xmm15
000071c0d83d5bca  vmovaps xmm15, [rsp+0x90]
000071c0d83d5bd3  por xmm1, xmm15
000071c0d83d5bd8  movaps xmm15, [r15+0x300]
000071c0d83d5be0  vmovaps [rsp+0x90], xmm15
000071c0d83d5be9  vmovaps [rsp+0xE0], xmm1
000071c0d83d5bf2  vmovaps xmm1, [rsp+0x90]
000071c0d83d5bfb  por xmm15, xmm1
000071c0d83d5c00  mov rax, [rsp+0x80]
000071c0d83d5c08  lea r14, [rax+0xA0]
000071c0d83d5c0f  movups xmm1, [r13+r14*1]
000071c0d83d5c15  lea r14, [rax+0xB0]
000071c0d83d5c1c  vmovaps [rsp+0x80], xmm1
000071c0d83d5c25  movups xmm1, [r13+r14*1]
000071c0d83d5c2b  vmovaps [rsp+0x90], xmm1
000071c0d83d5c34  vmovaps [rsp+0xF0], xmm15
000071c0d83d5c3d  vmovaps xmm15, [rsp+0xB0]
000071c0d83d5c46  vmovaps [rsp+0xB0], xmm14
000071c0d83d5c4f  movaps xmm1, xmm6
000071c0d83d5c52  addpd xmm1, xmm15
000071c0d83d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000071c0d83d5c5c  ptest xmm14, xmm14
000071c0d83d5c62  jnz 0x000071C0D83D7323
000071c0d83d5c68  lea r14, [rax+0xF0]
000071c0d83d5c6f  movups xmm15, [r13+r14*1]
000071c0d83d5c75  movaps xmm14, xmm4
000071c0d83d5c79  addpd xmm14, xmm3
000071c0d83d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000071c0d83d5c84  ptest xmm6, xmm6
000071c0d83d5c89  jnz 0x000071C0D83D746E
000071c0d83d5c8f  movaps xmm6, xmm9
000071c0d83d5c93  addpd xmm6, xmm7
000071c0d83d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000071c0d83d5c9c  ptest xmm4, xmm4
000071c0d83d5ca1  jnz 0x000071C0D83D75B0
000071c0d83d5ca7  vmovaps xmm9, [rsp+0x70]
000071c0d83d5cad  vpermilpd xmm9, xmm9, 0x00
000071c0d83d5cb3  vmovaps xmm4, [rsp+0x90]
000071c0d83d5cbc  movaps xmm7, xmm4
000071c0d83d5cbf  mulpd xmm7, xmm9
000071c0d83d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000071c0d83d5cc9  ptest xmm3, xmm3
000071c0d83d5cce  jnz 0x000071C0D83D76F1
000071c0d83d5cd4  vmovaps xmm9, [rsp+0x50]
000071c0d83d5cda  vpermilpd xmm9, xmm9, 0x00
000071c0d83d5ce0  movaps xmm4, xmm15
000071c0d83d5ce4  mulpd xmm4, xmm9
000071c0d83d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000071c0d83d5cee  ptest xmm3, xmm3
000071c0d83d5cf3  jnz 0x000071C0D83D7832
000071c0d83d5cf9  lea r14, [rax+0xE0]
000071c0d83d5d00  movups xmm15, [r13+r14*1]
000071c0d83d5d06  vmovaps xmm9, [rsp+0x70]
000071c0d83d5d0c  vpermilpd xmm9, xmm9, 0x00
000071c0d83d5d12  vmovaps [rsp+0x70], xmm1
000071c0d83d5d18  vmovaps xmm1, [rsp+0x80]
000071c0d83d5d21  vmovaps [rsp+0x80], xmm15
000071c0d83d5d2a  movaps xmm3, xmm1
000071c0d83d5d2d  mulpd xmm3, xmm9
000071c0d83d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000071c0d83d5d37  ptest xmm15, xmm15
000071c0d83d5d3d  jnz 0x000071C0D83D797E
000071c0d83d5d43  vmovaps xmm1, [rsp+0xF0]
000071c0d83d5d4c  vmovaps xmm15, [rsp+0xF0]
000071c0d83d5d55  por xmm1, xmm15
000071c0d83d5d5a  movaps [r15+0x300], xmm1
000071c0d83d5d62  vmovaps xmm15, [rsp+0xE0]
000071c0d83d5d6b  vmovaps xmm9, [rsp+0xE0]
000071c0d83d5d74  por xmm15, xmm9
000071c0d83d5d79  movaps [r15+0x190], xmm15
000071c0d83d5d81  vmovaps xmm9, [rsp+0x50]
000071c0d83d5d87  vpermilpd xmm9, xmm9, 0x00
000071c0d83d5d8d  vmovaps [rsp+0x90], xmm1
000071c0d83d5d96  vmovaps [rsp+0xE0], xmm15
000071c0d83d5d9f  vmovaps xmm15, [rsp+0x80]
000071c0d83d5da8  vmovaps [rsp+0x80], xmm14
000071c0d83d5db1  movaps xmm1, xmm15
000071c0d83d5db5  mulpd xmm1, xmm9
000071c0d83d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000071c0d83d5dbf  ptest xmm14, xmm14
000071c0d83d5dc5  jnz 0x000071C0D83D7ABF
000071c0d83d5dcb  lea r14, [rax+0x90]
000071c0d83d5dd2  movups xmm15, [r13+r14*1]
000071c0d83d5dd8  vmovaps xmm14, [rsp+0xD0]
000071c0d83d5de1  vmovaps xmm9, [rsp+0xD0]
000071c0d83d5dea  por xmm14, xmm9
000071c0d83d5def  movaps [r15+0x1C0], xmm14
000071c0d83d5df7  vmovaps xmm9, [rsp+0xC0]
000071c0d83d5e00  vmovaps [rsp+0xD0], xmm1
000071c0d83d5e09  vmovaps xmm1, [rsp+0xC0]
000071c0d83d5e12  por xmm9, xmm1
000071c0d83d5e17  movaps [r15+0x200], xmm9
000071c0d83d5e1f  vmovaps [rsp+0xC0], xmm2
000071c0d83d5e28  vmovaps xmm1, [rsp+0xC0]
000071c0d83d5e31  por xmm2, xmm1
000071c0d83d5e35  movaps [r15+0x2D0], xmm2
000071c0d83d5e3d  vmovaps [rsp+0xC0], xmm8
000071c0d83d5e46  vmovaps xmm1, [rsp+0xC0]
000071c0d83d5e4f  por xmm8, xmm1
000071c0d83d5e54  movaps [r15+0x2E0], xmm8
000071c0d83d5e5c  vmovaps [rsp+0xC0], xmm15
000071c0d83d5e65  movaps xmm1, xmm5
000071c0d83d5e68  addpd xmm1, xmm7
000071c0d83d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000071c0d83d5e71  ptest xmm15, xmm15
000071c0d83d5e77  jnz 0x000071C0D83D7C0B
000071c0d83d5e7d  vmovaps xmm15, [rsp+0x50]
000071c0d83d5e83  vpermilpd xmm15, xmm15, 0x00
000071c0d83d5e89  vmovaps xmm5, [rsp+0xC0]
000071c0d83d5e92  vmovaps [rsp+0xC0], xmm1
000071c0d83d5e9b  movaps xmm7, xmm5
000071c0d83d5e9e  mulpd xmm7, xmm15
000071c0d83d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000071c0d83d5ea8  ptest xmm1, xmm1
000071c0d83d5ead  jnz 0x000071C0D83D7D4B
000071c0d83d5eb3  lea r14, [rax+0x80]
000071c0d83d5eba  movups xmm1, [r13+r14*1]
000071c0d83d5ec0  vmovaps xmm5, [rsp+0x70]
000071c0d83d5ec6  vmovaps [rsp+0x70], xmm1
000071c0d83d5ecc  movaps xmm15, xmm5
000071c0d83d5ed0  addpd xmm15, xmm3
000071c0d83d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83d5edb  ptest xmm1, xmm1
000071c0d83d5ee0  jnz 0x000071C0D83D7E96
000071c0d83d5ee6  vmovaps xmm5, [rsp+0x80]
000071c0d83d5eef  movaps xmm1, xmm5
000071c0d83d5ef2  addpd xmm1, xmm4
000071c0d83d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000071c0d83d5efb  ptest xmm3, xmm3
000071c0d83d5f00  jnz 0x000071C0D83D7FD8
000071c0d83d5f06  vmovaps [rsp+0x80], xmm10
000071c0d83d5f0f  vmovaps xmm5, [rsp+0x80]
000071c0d83d5f18  por xmm10, xmm5
000071c0d83d5f1d  movaps [r15+0x2F0], xmm10
000071c0d83d5f25  vmovaps xmm5, [rsp+0x50]
000071c0d83d5f2b  vpermilpd xmm5, xmm5, 0x00
000071c0d83d5f31  vmovaps xmm3, [rsp+0x70]
000071c0d83d5f37  vmovaps [rsp+0x50], xmm1
000071c0d83d5f3d  movaps xmm4, xmm3
000071c0d83d5f40  mulpd xmm4, xmm5
000071c0d83d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000071c0d83d5f49  ptest xmm1, xmm1
000071c0d83d5f4e  jnz 0x000071C0D83D8118
000071c0d83d5f54  lea r14, [rax+0xD0]
000071c0d83d5f5b  movups xmm1, [r13+r14*1]
000071c0d83d5f61  vmovaps xmm3, [rsp+0xD0]
000071c0d83d5f6a  vmovaps [rsp+0x70], xmm1
000071c0d83d5f70  movaps xmm5, xmm6
000071c0d83d5f73  addpd xmm5, xmm3
000071c0d83d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000071c0d83d5f7c  ptest xmm1, xmm1
000071c0d83d5f81  jnz 0x000071C0D83D8262
000071c0d83d5f87  vmovaps xmm1, [rsp+0x60]
000071c0d83d5f8d  vpermilpd xmm1, xmm1, 0x00
000071c0d83d5f93  movaps xmm6, xmm9
000071c0d83d5f97  mulpd xmm6, xmm1
000071c0d83d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000071c0d83d5fa0  ptest xmm3, xmm3
000071c0d83d5fa5  jnz 0x000071C0D83D83A2
000071c0d83d5fab  movaps [r15+0x260], xmm6
000071c0d83d5fb3  vxorps xmm1, xmm1, xmm1
000071c0d83d5fb7  vpbroadcastq xmm1, xmm1
000071c0d83d5fbc  movaps [r15+0x1B0], xmm1
000071c0d83d5fc4  vmovaps xmm1, [rsp+0x60]
000071c0d83d5fca  vpermilpd xmm1, xmm1, 0x00
000071c0d83d5fd0  vmovaps xmm3, [rsp+0x70]
000071c0d83d5fd6  vmovaps [rsp+0x70], xmm15
000071c0d83d5fdc  movaps xmm9, xmm3
000071c0d83d5fe0  mulpd xmm9, xmm1
000071c0d83d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000071c0d83d5feb  ptest xmm15, xmm15
000071c0d83d5ff1  jnz 0x000071C0D83D84E3
000071c0d83d5ff7  lea r14, [rax+0xC0]
000071c0d83d5ffe  movups xmm1, [r13+r14*1]
000071c0d83d6004  vmovaps xmm3, [rsp+0xC0]
000071c0d83d600d  vmovaps [rsp+0x80], xmm1
000071c0d83d6016  movaps xmm15, xmm3
000071c0d83d601a  addpd xmm15, xmm7
000071c0d83d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83d6025  ptest xmm1, xmm1
000071c0d83d602a  jnz 0x000071C0D83D862F
000071c0d83d6030  vmovaps [rsp+0xC0], xmm13
000071c0d83d6039  vmovaps xmm1, [rsp+0xC0]
000071c0d83d6042  por xmm13, xmm1
000071c0d83d6047  movaps [r15+0x270], xmm13
000071c0d83d604f  vmovaps xmm1, [rsp+0xB0]
000071c0d83d6058  vmovaps xmm7, [rsp+0xB0]
000071c0d83d6061  por xmm1, xmm7
000071c0d83d6065  movaps [r15+0x1A0], xmm1
000071c0d83d606d  vmovaps xmm1, [rsp+0x60]
000071c0d83d6073  vpermilpd xmm1, xmm1, 0x00
000071c0d83d6079  vmovaps [rsp+0xB0], xmm1
000071c0d83d6082  vmovaps xmm1, [rsp+0x80]
000071c0d83d608b  vmovaps [rsp+0x80], xmm15
000071c0d83d6094  vmovaps xmm15, [rsp+0xB0]
000071c0d83d609d  vmovaps [rsp+0xB0], xmm14
000071c0d83d60a6  movaps xmm3, xmm1
000071c0d83d60a9  mulpd xmm3, xmm15
000071c0d83d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000071c0d83d60b3  ptest xmm14, xmm14
000071c0d83d60b9  jnz 0x000071C0D83D8771
000071c0d83d60bf  lea r14, [rax+0x20]
000071c0d83d60c3  movups xmm1, [r13+r14*1]
000071c0d83d60c9  movaps [r15+0x110], xmm1
000071c0d83d60d1  vmovaps xmm14, [rsp+0x70]
000071c0d83d60d7  vmovaps [rsp+0x70], xmm1
000071c0d83d60dd  movaps xmm15, xmm14
000071c0d83d60e1  addpd xmm15, xmm4
000071c0d83d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83d60ec  ptest xmm1, xmm1
000071c0d83d60f1  jnz 0x000071C0D83D88BC
000071c0d83d60f7  vmovaps xmm1, [rsp+0x60]
000071c0d83d60fd  vpermilpd xmm1, xmm1, 0x00
000071c0d83d6103  movaps xmm14, xmm2
000071c0d83d6107  mulpd xmm14, xmm1
000071c0d83d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000071c0d83d6112  ptest xmm4, xmm4
000071c0d83d6117  jnz 0x000071C0D83D89FF
000071c0d83d611d  vmovaps xmm4, [rsp+0x50]
000071c0d83d6123  movaps xmm1, xmm4
000071c0d83d6126  addpd xmm1, xmm9
000071c0d83d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000071c0d83d6130  ptest xmm2, xmm2
000071c0d83d6135  jnz 0x000071C0D83D8B41
000071c0d83d613b  vmovaps xmm9, [rsp+0x30]
000071c0d83d6141  vpermilpd xmm9, xmm9, 0x00
000071c0d83d6147  vmovaps xmm2, [rsp+0x70]
000071c0d83d614d  vmovaps [rsp+0x50], xmm1
000071c0d83d6153  movaps xmm4, xmm2
000071c0d83d6156  mulpd xmm4, xmm9
000071c0d83d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000071c0d83d6160  ptest xmm1, xmm1
000071c0d83d6165  jnz 0x000071C0D83D8C82
000071c0d83d616b  vmovaps xmm1, [rsp+0x30]
000071c0d83d6171  vpermilpd xmm1, xmm1, 0x00
000071c0d83d6177  vmovaps xmm2, [rsp+0x90]
000071c0d83d6180  vmovaps [rsp+0x60], xmm15
000071c0d83d6186  movaps xmm9, xmm2
000071c0d83d618a  mulpd xmm9, xmm1
000071c0d83d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000071c0d83d6195  ptest xmm15, xmm15
000071c0d83d619b  jnz 0x000071C0D83D8DC3
000071c0d83d61a1  vmovaps xmm15, [rsp+0x80]
000071c0d83d61aa  movaps xmm1, xmm15
000071c0d83d61ae  addpd xmm1, xmm6
000071c0d83d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000071c0d83d61b7  ptest xmm2, xmm2
000071c0d83d61bc  jnz 0x000071C0D83D8F05
000071c0d83d61c2  movaps xmm15, xmm5
000071c0d83d61c6  addpd xmm15, xmm3
000071c0d83d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000071c0d83d61d1  ptest xmm6, xmm6
000071c0d83d61d6  jnz 0x000071C0D83D9046
000071c0d83d61dc  vmovaps xmm6, [rsp+0x30]
000071c0d83d61e2  vpermilpd xmm6, xmm6, 0x00
000071c0d83d61e8  movaps xmm5, xmm8
000071c0d83d61ec  mulpd xmm5, xmm6
000071c0d83d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000071c0d83d61f5  ptest xmm3, xmm3
000071c0d83d61fa  jnz 0x000071C0D83D9188
000071c0d83d6200  vmovaps xmm8, [rsp+0x30]
000071c0d83d6206  vpermilpd xmm8, xmm8, 0x00
000071c0d83d620c  movaps xmm6, xmm10
000071c0d83d6210  mulpd xmm6, xmm8
000071c0d83d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000071c0d83d621a  ptest xmm3, xmm3
000071c0d83d621f  jnz 0x000071C0D83D92C9
000071c0d83d6225  vmovaps xmm8, [rsp+0x60]
000071c0d83d622b  movaps xmm10, xmm8
000071c0d83d622f  addpd xmm10, xmm14
000071c0d83d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000071c0d83d623a  ptest xmm3, xmm3
000071c0d83d623f  jnz 0x000071C0D83D940B
000071c0d83d6245  vmovaps xmm8, [rsp+0x50]
000071c0d83d624b  movaps xmm14, xmm8
000071c0d83d624f  addpd xmm14, xmm4
000071c0d83d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000071c0d83d625a  ptest xmm3, xmm3
000071c0d83d625f  jnz 0x000071C0D83D954F
000071c0d83d6265  vmovaps xmm8, [rsp+0x40]
000071c0d83d626b  vpermilpd xmm8, xmm8, 0x00
000071c0d83d6271  movaps xmm4, xmm13
000071c0d83d6275  mulpd xmm4, xmm8
000071c0d83d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000071c0d83d627f  ptest xmm3, xmm3
000071c0d83d6284  jnz 0x000071C0D83D9692
000071c0d83d628a  movaps xmm13, xmm15
000071c0d83d628e  addpd xmm13, xmm9
000071c0d83d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000071c0d83d6299  ptest xmm8, xmm8
000071c0d83d629f  jnz 0x000071C0D83D97D4
000071c0d83d62a5  movaps xmm15, xmm1
000071c0d83d62a9  addpd xmm15, xmm5
000071c0d83d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000071c0d83d62b4  ptest xmm9, xmm9
000071c0d83d62ba  jnz 0x000071C0D83D9918
000071c0d83d62c0  vmovaps [rsp+0x30], xmm11
000071c0d83d62c6  vmovaps xmm1, [rsp+0x30]
000071c0d83d62cc  por xmm11, xmm1
000071c0d83d62d1  movaps [r15+0x250], xmm11
000071c0d83d62d9  vmovaps [rsp+0x30], xmm12
000071c0d83d62df  vmovaps xmm1, [rsp+0x30]
000071c0d83d62e5  por xmm12, xmm1
000071c0d83d62ea  movaps [r15+0x2A0], xmm12
000071c0d83d62f2  vmovaps xmm1, [rsp+0xA0]
000071c0d83d62fb  vmovaps xmm11, [rsp+0xA0]
000071c0d83d6304  por xmm1, xmm11
000071c0d83d6309  movaps [r15+0x1D0], xmm1
000071c0d83d6311  lea r14, [rax+0x40]
000071c0d83d6315  movups xmm1, [r13+r14*1]
000071c0d83d631b  movaps [r15+0x2C0], xmm1
000071c0d83d6323  vmovaps xmm11, [rsp+0x40]
000071c0d83d6329  vpermilpd xmm11, xmm11, 0x00
000071c0d83d632f  vmovaps xmm8, [rsp+0xE0]
000071c0d83d6338  movaps xmm9, xmm8
000071c0d83d633c  mulpd xmm9, xmm11
000071c0d83d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000071c0d83d6347  ptest xmm5, xmm5
000071c0d83d634c  jnz 0x000071C0D83D9A64
000071c0d83d6352  movaps xmm11, xmm10
000071c0d83d6356  addpd xmm11, xmm6
000071c0d83d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000071c0d83d6361  ptest xmm8, xmm8
000071c0d83d6367  jnz 0x000071C0D83D9BA8
000071c0d83d636d  movaps xmm10, xmm14
000071c0d83d6371  addpd xmm10, xmm4
000071c0d83d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000071c0d83d637c  ptest xmm8, xmm8
000071c0d83d6382  jnz 0x000071C0D83D9CEB
000071c0d83d6388  vmovaps xmm14, [rsp+0x40]
000071c0d83d638e  vpermilpd xmm14, xmm14, 0x00
000071c0d83d6394  movaps xmm8, xmm1
000071c0d83d6398  mulpd xmm8, xmm14
000071c0d83d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000071c0d83d63a3  ptest xmm6, xmm6
000071c0d83d63a8  jnz 0x000071C0D83D9E2E
000071c0d83d63ae  movaps xmm1, [r15+0x2B0]
000071c0d83d63b6  vmovaps xmm14, [rsp+0x40]
000071c0d83d63bc  vpermilpd xmm14, xmm14, 0x00
000071c0d83d63c2  movaps xmm6, xmm1
000071c0d83d63c5  mulpd xmm6, xmm14
000071c0d83d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000071c0d83d63cf  ptest xmm5, xmm5
000071c0d83d63d4  jnz 0x000071C0D83D9F71
000071c0d83d63da  vmovaps xmm1, [rsp+0x10]
000071c0d83d63e0  vpermilpd xmm1, xmm1, 0x00
000071c0d83d63e6  movaps xmm14, xmm12
000071c0d83d63ea  mulpd xmm14, xmm1
000071c0d83d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000071c0d83d63f5  ptest xmm5, xmm5
000071c0d83d63fa  jnz 0x000071C0D83DA0B2
000071c0d83d6400  movaps xmm1, xmm13
000071c0d83d6404  addpd xmm1, xmm9
000071c0d83d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000071c0d83d640e  ptest xmm12, xmm12
000071c0d83d6414  jnz 0x000071C0D83DA1F5
000071c0d83d641a  vmovaps xmm13, [rsp+0x10]
000071c0d83d6420  vpermilpd xmm13, xmm13, 0x00
000071c0d83d6426  movaps xmm12, xmm7
000071c0d83d642a  mulpd xmm12, xmm13
000071c0d83d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000071c0d83d6435  ptest xmm9, xmm9
000071c0d83d643b  jnz 0x000071C0D83DA337
000071c0d83d6441  movaps xmm13, xmm15
000071c0d83d6445  addpd xmm13, xmm8
000071c0d83d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000071c0d83d6450  ptest xmm9, xmm9
000071c0d83d6456  jnz 0x000071C0D83DA47A
000071c0d83d645c  movaps xmm15, [r15+0x290]
000071c0d83d6464  vmovaps xmm9, [rsp+0x10]
000071c0d83d646a  vpermilpd xmm9, xmm9, 0x00
000071c0d83d6470  movaps xmm8, xmm15
000071c0d83d6474  mulpd xmm8, xmm9
000071c0d83d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000071c0d83d647f  ptest xmm7, xmm7
000071c0d83d6484  jnz 0x000071C0D83DA5BE
000071c0d83d648a  movaps xmm15, xmm11
000071c0d83d648e  addpd xmm15, xmm6
000071c0d83d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000071c0d83d6499  ptest xmm9, xmm9
000071c0d83d649f  jnz 0x000071C0D83DA702
000071c0d83d64a5  movaps xmm11, [r15+0x1E0]
000071c0d83d64ad  vmovaps xmm9, [rsp+0x10]
000071c0d83d64b3  vpermilpd xmm9, xmm9, 0x00
000071c0d83d64b9  movaps xmm7, xmm11
000071c0d83d64bd  mulpd xmm7, xmm9
000071c0d83d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000071c0d83d64c7  ptest xmm6, xmm6
000071c0d83d64cc  jnz 0x000071C0D83DA845
000071c0d83d64d2  movaps xmm11, xmm10
000071c0d83d64d6  addpd xmm11, xmm14
000071c0d83d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000071c0d83d64e1  ptest xmm9, xmm9
000071c0d83d64e7  jnz 0x000071C0D83DA987
000071c0d83d64ed  lea r14, [rax+0x70]
000071c0d83d64f1  movups xmm14, [r13+r14*1]
000071c0d83d64f7  movaps [r15+0x240], xmm14
000071c0d83d64ff  movaps xmm10, xmm1
000071c0d83d6503  addpd xmm10, xmm12
000071c0d83d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000071c0d83d650e  ptest xmm9, xmm9
000071c0d83d6514  jnz 0x000071C0D83DAAD5
000071c0d83d651a  movaps [r15+0x170], xmm10
000071c0d83d6522  vmovaps xmm1, [rsp+0x20]
000071c0d83d6528  vpermilpd xmm1, xmm1, 0x00
000071c0d83d652e  movaps xmm12, xmm14
000071c0d83d6532  mulpd xmm12, xmm1
000071c0d83d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000071c0d83d653d  ptest xmm9, xmm9
000071c0d83d6543  jnz 0x000071C0D83DAC18
000071c0d83d6549  vmovaps xmm1, [rsp+0x20]
000071c0d83d654f  vpermilpd xmm1, xmm1, 0x00
000071c0d83d6555  vmovaps xmm9, [rsp+0xB0]
000071c0d83d655e  movaps xmm14, xmm9
000071c0d83d6562  mulpd xmm14, xmm1
000071c0d83d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000071c0d83d656d  ptest xmm6, xmm6
000071c0d83d6572  jnz 0x000071C0D83DAD5B
000071c0d83d6578  movaps [r15+0x180], xmm14
000071c0d83d6580  movaps xmm1, xmm13
000071c0d83d6584  addpd xmm1, xmm8
000071c0d83d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000071c0d83d658e  ptest xmm9, xmm9
000071c0d83d6594  jnz 0x000071C0D83DAE9E
000071c0d83d659a  movaps [r15+0x210], xmm1
000071c0d83d65a2  movups xmm13, [r13+rax*1]
000071c0d83d65a8  lea r14, [rax+0x10]
000071c0d83d65ac  movups xmm9, [r13+r14*1]
000071c0d83d65b2  movaps [r15+0x230], xmm9
000071c0d83d65ba  movaps xmm8, xmm15
000071c0d83d65be  addpd xmm8, xmm7
000071c0d83d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000071c0d83d65c9  ptest xmm6, xmm6
000071c0d83d65ce  jnz 0x000071C0D83DAFF4
000071c0d83d65d4  movaps [r15+0x130], xmm8
000071c0d83d65dc  vmovaps xmm15, [rsp+0x20]
000071c0d83d65e2  vpermilpd xmm15, xmm15, 0x00
000071c0d83d65e8  movaps xmm7, xmm9
000071c0d83d65ec  mulpd xmm7, xmm15
000071c0d83d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000071c0d83d65f6  ptest xmm6, xmm6
000071c0d83d65fb  jnz 0x000071C0D83DB137
000071c0d83d6601  movaps [r15+0x220], xmm7
000071c0d83d6609  vmovaps xmm15, [rsp+0x20]
000071c0d83d660f  vpermilpd xmm15, xmm15, 0x00
000071c0d83d6615  movaps xmm9, xmm13
000071c0d83d6619  mulpd xmm9, xmm15
000071c0d83d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000071c0d83d6624  ptest xmm6, xmm6
000071c0d83d6629  jnz 0x000071C0D83DB279
000071c0d83d662f  movaps xmm15, xmm11
000071c0d83d6633  addpd xmm15, xmm12
000071c0d83d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000071c0d83d663e  ptest xmm13, xmm13
000071c0d83d6644  jnz 0x000071C0D83DB3BD
000071c0d83d664a  movaps [r15+0x140], xmm15
000071c0d83d6652  movaps xmm13, xmm10
000071c0d83d6656  addpd xmm13, xmm14
000071c0d83d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000071c0d83d6661  ptest xmm12, xmm12
000071c0d83d6667  jnz 0x000071C0D83DB501
000071c0d83d666d  movaps [r15+0x150], xmm13
000071c0d83d6675  movaps xmm14, xmm1
000071c0d83d6679  addpd xmm14, xmm7
000071c0d83d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000071c0d83d6684  ptest xmm12, xmm12
000071c0d83d668a  jnz 0x000071C0D83DB645
000071c0d83d6690  movaps [r15+0x160], xmm14
000071c0d83d6698  movaps xmm1, xmm8
000071c0d83d669c  addpd xmm1, xmm9
000071c0d83d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000071c0d83d66a6  ptest xmm12, xmm12
000071c0d83d66ac  jnz 0x000071C0D83DB787
000071c0d83d66b2  movaps [r15+0x120], xmm1
000071c0d83d66ba  movups [r13+r11*1], xmm15
000071c0d83d66c0  lea rax, [r11+0x10]
000071c0d83d66c4  movups [r13+rax*1], xmm13
000071c0d83d66ca  lea rax, [r11+0x20]
000071c0d83d66ce  movups [r13+rax*1], xmm14
000071c0d83d66d4  lea rax, [r11+0x30]
000071c0d83d66d8  movups [r13+rax*1], xmm1
000071c0d83d66de  mov eax, [r15+0x108]
000071c0d83d66e5  sahf
000071c0d83d66e6  jnz 0x000071C0D83D6718
000071c0d83d66e8  cmp dword ptr [r15+0x318], 0x00
000071c0d83d66f0  jz 0x000071C0D83DB900
000071c0d83d66f6  nop [rax+rax*1], ax
000071c0d83d66ff  nop [rax+rax*1], eax
000071c0d83d6707  mov eax, 0x410444
000071c0d83d670c  mov [r15+0x100], rax
000071c0d83d6713  jmp 0x000071C0D81FE110
000071c0d83d6718  cmp dword ptr [r15+0x318], 0x00
000071c0d83d6720  jz 0x000071C0D83D57E0
000071c0d83d6726  nop [rax+rax*1], ax
000071c0d83d672f  nop [rax+rax*1], eax
000071c0d83d6737  mov eax, 0x410278
000071c0d83d673c  mov [r15+0x100], rax
000071c0d83d6743  jmp 0x000071C0D81FE110
000071c0d83d6748  int3
000071c0d83d6749  call 0x000071C0D820A4B0
000071c0d83d674e  jmp 0x000071C0D83D5828
000071c0d83d6753  call 0x000071C0D8209240
000071c0d83d6758  jmp 0x000071C0D83D5832
000071c0d83d675d  call 0x000071C0D820A4B0
000071c0d83d6762  jmp 0x000071C0D83D588F
000071c0d83d6767  call 0x000071C0D8209240
000071c0d83d676c  jmp 0x000071C0D83D5899
000071c0d83d6771  call 0x000071C0D820A4B0
000071c0d83d6776  jmp 0x000071C0D83D58DD
000071c0d83d677b  call 0x000071C0D8209240
000071c0d83d6780  jmp 0x000071C0D83D58E7
000071c0d83d6785  call 0x000071C0D82B47C0
000071c0d83d678a  jmp 0x000071C0D83D5926
000071c0d83d678f  call 0x000071C0D820B720
000071c0d83d6794  jmp 0x000071C0D83D593A
000071c0d83d6799  call 0x000071C0D82BFC30
000071c0d83d679e  jmp 0x000071C0D83D5958
000071c0d83d67a3  call 0x000071C0D82BE9C0
000071c0d83d67a8  jmp 0x000071C0D83D5962
000071c0d83d67ad  call 0x000071C0D82BD750
000071c0d83d67b2  jmp 0x000071C0D83D596C
000071c0d83d67b7  sub rsp, 0x08
000071c0d83d67bb  push rax
000071c0d83d67bc  push rcx
000071c0d83d67bd  push rdx
000071c0d83d67be  push rdi
000071c0d83d67bf  push rsi
000071c0d83d67c0  push r8
000071c0d83d67c2  push r9
000071c0d83d67c4  push r10
000071c0d83d67c6  push r11
000071c0d83d67c8  sub rsp, 0xF0
000071c0d83d67cf  vmovaps [rsp], xmm0
000071c0d83d67d4  vmovaps [rsp+0x10], xmm1
000071c0d83d67da  vmovaps [rsp+0x20], xmm2
000071c0d83d67e0  vmovaps [rsp+0x30], xmm3
000071c0d83d67e6  vmovaps [rsp+0x40], xmm4
000071c0d83d67ec  vmovaps [rsp+0x50], xmm5
000071c0d83d67f2  vmovaps [rsp+0x60], xmm6
000071c0d83d67f8  vmovaps [rsp+0x70], xmm7
000071c0d83d67fe  vmovaps [rsp+0x80], xmm9
000071c0d83d6807  vmovaps [rsp+0x90], xmm10
000071c0d83d6810  vmovaps [rsp+0xA0], xmm11
000071c0d83d6819  vmovaps [rsp+0xB0], xmm12
000071c0d83d6822  vmovaps [rsp+0xC0], xmm13
000071c0d83d682b  vmovaps [rsp+0xD0], xmm14
000071c0d83d6834  vmovaps [rsp+0xE0], xmm15
000071c0d83d683d  sub rsp, 0x30
000071c0d83d6841  movaps [rsp], xmm8
000071c0d83d6846  movaps [rsp+0x10], xmm12
000071c0d83d684c  movaps [rsp+0x20], xmm15
000071c0d83d6852  lea rdi, [rsp]
000071c0d83d6856  mov esi, 0x00
000071c0d83d685b  mov rax, 0x5904ED15D530
000071c0d83d6865  call rax
000071c0d83d6867  movaps xmm8, [rsp]
000071c0d83d686c  add rsp, 0x30
000071c0d83d6870  vmovaps xmm0, [rsp]
000071c0d83d6875  vmovaps xmm1, [rsp+0x10]
000071c0d83d687b  vmovaps xmm2, [rsp+0x20]
000071c0d83d6881  vmovaps xmm3, [rsp+0x30]
000071c0d83d6887  vmovaps xmm4, [rsp+0x40]
000071c0d83d688d  vmovaps xmm5, [rsp+0x50]
000071c0d83d6893  vmovaps xmm6, [rsp+0x60]
000071c0d83d6899  vmovaps xmm7, [rsp+0x70]
000071c0d83d689f  vmovaps xmm9, [rsp+0x80]
000071c0d83d68a8  vmovaps xmm10, [rsp+0x90]
000071c0d83d68b1  vmovaps xmm11, [rsp+0xA0]
000071c0d83d68ba  vmovaps xmm12, [rsp+0xB0]
000071c0d83d68c3  vmovaps xmm13, [rsp+0xC0]
000071c0d83d68cc  vmovaps xmm14, [rsp+0xD0]
000071c0d83d68d5  vmovaps xmm15, [rsp+0xE0]
000071c0d83d68de  add rsp, 0xF0
000071c0d83d68e5  pop r11
000071c0d83d68e7  pop r10
000071c0d83d68e9  pop r9
000071c0d83d68eb  pop r8
000071c0d83d68ed  pop rsi
000071c0d83d68ee  pop rdi
000071c0d83d68ef  pop rdx
000071c0d83d68f0  pop rcx
000071c0d83d68f1  pop rax
000071c0d83d68f2  add rsp, 0x08
000071c0d83d68f6  jmp 0x000071C0D83D599A
000071c0d83d68fb  sub rsp, 0x08
000071c0d83d68ff  push rax
000071c0d83d6900  push rcx
000071c0d83d6901  push rdx
000071c0d83d6902  push rdi
000071c0d83d6903  push rsi
000071c0d83d6904  push r8
000071c0d83d6906  push r9
000071c0d83d6908  push r10
000071c0d83d690a  push r11
000071c0d83d690c  sub rsp, 0xF0
000071c0d83d6913  vmovaps [rsp], xmm0
000071c0d83d6918  vmovaps [rsp+0x10], xmm1
000071c0d83d691e  vmovaps [rsp+0x20], xmm2
000071c0d83d6924  vmovaps [rsp+0x30], xmm3
000071c0d83d692a  vmovaps [rsp+0x40], xmm4
000071c0d83d6930  vmovaps [rsp+0x50], xmm5
000071c0d83d6936  vmovaps [rsp+0x60], xmm6
000071c0d83d693c  vmovaps [rsp+0x70], xmm8
000071c0d83d6942  vmovaps [rsp+0x80], xmm9
000071c0d83d694b  vmovaps [rsp+0x90], xmm10
000071c0d83d6954  vmovaps [rsp+0xA0], xmm11
000071c0d83d695d  vmovaps [rsp+0xB0], xmm12
000071c0d83d6966  vmovaps [rsp+0xC0], xmm13
000071c0d83d696f  vmovaps [rsp+0xD0], xmm14
000071c0d83d6978  vmovaps [rsp+0xE0], xmm15
000071c0d83d6981  sub rsp, 0x30
000071c0d83d6985  movaps [rsp], xmm7
000071c0d83d6989  movaps [rsp+0x10], xmm9
000071c0d83d698f  movaps [rsp+0x20], xmm15
000071c0d83d6995  lea rdi, [rsp]
000071c0d83d6999  mov esi, 0x00
000071c0d83d699e  mov rax, 0x5904ED15D530
000071c0d83d69a8  call rax
000071c0d83d69aa  movaps xmm7, [rsp]
000071c0d83d69ae  add rsp, 0x30
000071c0d83d69b2  vmovaps xmm0, [rsp]
000071c0d83d69b7  vmovaps xmm1, [rsp+0x10]
000071c0d83d69bd  vmovaps xmm2, [rsp+0x20]
000071c0d83d69c3  vmovaps xmm3, [rsp+0x30]
000071c0d83d69c9  vmovaps xmm4, [rsp+0x40]
000071c0d83d69cf  vmovaps xmm5, [rsp+0x50]
000071c0d83d69d5  vmovaps xmm6, [rsp+0x60]
000071c0d83d69db  vmovaps xmm8, [rsp+0x70]
000071c0d83d69e1  vmovaps xmm9, [rsp+0x80]
000071c0d83d69ea  vmovaps xmm10, [rsp+0x90]
000071c0d83d69f3  vmovaps xmm11, [rsp+0xA0]
000071c0d83d69fc  vmovaps xmm12, [rsp+0xB0]
000071c0d83d6a05  vmovaps xmm13, [rsp+0xC0]
000071c0d83d6a0e  vmovaps xmm14, [rsp+0xD0]
000071c0d83d6a17  vmovaps xmm15, [rsp+0xE0]
000071c0d83d6a20  add rsp, 0xF0
000071c0d83d6a27  pop r11
000071c0d83d6a29  pop r10
000071c0d83d6a2b  pop r9
000071c0d83d6a2d  pop r8
000071c0d83d6a2f  pop rsi
000071c0d83d6a30  pop rdi
000071c0d83d6a31  pop rdx
000071c0d83d6a32  pop rcx
000071c0d83d6a33  pop rax
000071c0d83d6a34  add rsp, 0x08
000071c0d83d6a38  jmp 0x000071C0D83D59C8
000071c0d83d6a3d  sub rsp, 0x08
000071c0d83d6a41  push rax
000071c0d83d6a42  push rcx
000071c0d83d6a43  push rdx
000071c0d83d6a44  push rdi
000071c0d83d6a45  push rsi
000071c0d83d6a46  push r8
000071c0d83d6a48  push r9
000071c0d83d6a4a  push r10
000071c0d83d6a4c  push r11
000071c0d83d6a4e  sub rsp, 0xF0
000071c0d83d6a55  vmovaps [rsp], xmm0
000071c0d83d6a5a  vmovaps [rsp+0x10], xmm1
000071c0d83d6a60  vmovaps [rsp+0x20], xmm2
000071c0d83d6a66  vmovaps [rsp+0x30], xmm3
000071c0d83d6a6c  vmovaps [rsp+0x40], xmm4
000071c0d83d6a72  vmovaps [rsp+0x50], xmm5
000071c0d83d6a78  vmovaps [rsp+0x60], xmm6
000071c0d83d6a7e  vmovaps [rsp+0x70], xmm7
000071c0d83d6a84  vmovaps [rsp+0x80], xmm8
000071c0d83d6a8d  vmovaps [rsp+0x90], xmm10
000071c0d83d6a96  vmovaps [rsp+0xA0], xmm11
000071c0d83d6a9f  vmovaps [rsp+0xB0], xmm12
000071c0d83d6aa8  vmovaps [rsp+0xC0], xmm13
000071c0d83d6ab1  vmovaps [rsp+0xD0], xmm14
000071c0d83d6aba  vmovaps [rsp+0xE0], xmm15
000071c0d83d6ac3  sub rsp, 0x30
000071c0d83d6ac7  movaps [rsp], xmm9
000071c0d83d6acc  movaps [rsp+0x10], xmm12
000071c0d83d6ad2  movaps [rsp+0x20], xmm10
000071c0d83d6ad8  lea rdi, [rsp]
000071c0d83d6adc  mov esi, 0x00
000071c0d83d6ae1  mov rax, 0x5904ED15D530
000071c0d83d6aeb  call rax
000071c0d83d6aed  movaps xmm9, [rsp]
000071c0d83d6af2  add rsp, 0x30
000071c0d83d6af6  vmovaps xmm0, [rsp]
000071c0d83d6afb  vmovaps xmm1, [rsp+0x10]
000071c0d83d6b01  vmovaps xmm2, [rsp+0x20]
000071c0d83d6b07  vmovaps xmm3, [rsp+0x30]
000071c0d83d6b0d  vmovaps xmm4, [rsp+0x40]
000071c0d83d6b13  vmovaps xmm5, [rsp+0x50]
000071c0d83d6b19  vmovaps xmm6, [rsp+0x60]
000071c0d83d6b1f  vmovaps xmm7, [rsp+0x70]
000071c0d83d6b25  vmovaps xmm8, [rsp+0x80]
000071c0d83d6b2e  vmovaps xmm10, [rsp+0x90]
000071c0d83d6b37  vmovaps xmm11, [rsp+0xA0]
000071c0d83d6b40  vmovaps xmm12, [rsp+0xB0]
000071c0d83d6b49  vmovaps xmm13, [rsp+0xC0]
000071c0d83d6b52  vmovaps xmm14, [rsp+0xD0]
000071c0d83d6b5b  vmovaps xmm15, [rsp+0xE0]
000071c0d83d6b64  add rsp, 0xF0
000071c0d83d6b6b  pop r11
000071c0d83d6b6d  pop r10
000071c0d83d6b6f  pop r9
000071c0d83d6b71  pop r8
000071c0d83d6b73  pop rsi
000071c0d83d6b74  pop rdi
000071c0d83d6b75  pop rdx
000071c0d83d6b76  pop rcx
000071c0d83d6b77  pop rax
000071c0d83d6b78  add rsp, 0x08
000071c0d83d6b7c  jmp 0x000071C0D83D59EC
000071c0d83d6b81  sub rsp, 0x08
000071c0d83d6b85  push rax
000071c0d83d6b86  push rcx
000071c0d83d6b87  push rdx
000071c0d83d6b88  push rdi
000071c0d83d6b89  push rsi
000071c0d83d6b8a  push r8
000071c0d83d6b8c  push r9
000071c0d83d6b8e  push r10
000071c0d83d6b90  push r11
000071c0d83d6b92  sub rsp, 0xF0
000071c0d83d6b99  vmovaps [rsp], xmm0
000071c0d83d6b9e  vmovaps [rsp+0x10], xmm1
000071c0d83d6ba4  vmovaps [rsp+0x20], xmm2
000071c0d83d6baa  vmovaps [rsp+0x30], xmm3
000071c0d83d6bb0  vmovaps [rsp+0x40], xmm4
000071c0d83d6bb6  vmovaps [rsp+0x50], xmm5
000071c0d83d6bbc  vmovaps [rsp+0x60], xmm6
000071c0d83d6bc2  vmovaps [rsp+0x70], xmm7
000071c0d83d6bc8  vmovaps [rsp+0x80], xmm8
000071c0d83d6bd1  vmovaps [rsp+0x90], xmm9
000071c0d83d6bda  vmovaps [rsp+0xA0], xmm11
000071c0d83d6be3  vmovaps [rsp+0xB0], xmm12
000071c0d83d6bec  vmovaps [rsp+0xC0], xmm13
000071c0d83d6bf5  vmovaps [rsp+0xD0], xmm14
000071c0d83d6bfe  vmovaps [rsp+0xE0], xmm15
000071c0d83d6c07  sub rsp, 0x30
000071c0d83d6c0b  movaps [rsp], xmm10
000071c0d83d6c10  movaps [rsp+0x10], xmm12
000071c0d83d6c16  movaps [rsp+0x20], xmm11
000071c0d83d6c1c  lea rdi, [rsp]
000071c0d83d6c20  mov esi, 0x00
000071c0d83d6c25  mov rax, 0x5904ED15D530
000071c0d83d6c2f  call rax
000071c0d83d6c31  movaps xmm10, [rsp]
000071c0d83d6c36  add rsp, 0x30
000071c0d83d6c3a  vmovaps xmm0, [rsp]
000071c0d83d6c3f  vmovaps xmm1, [rsp+0x10]
000071c0d83d6c45  vmovaps xmm2, [rsp+0x20]
000071c0d83d6c4b  vmovaps xmm3, [rsp+0x30]
000071c0d83d6c51  vmovaps xmm4, [rsp+0x40]
000071c0d83d6c57  vmovaps xmm5, [rsp+0x50]
000071c0d83d6c5d  vmovaps xmm6, [rsp+0x60]
000071c0d83d6c63  vmovaps xmm7, [rsp+0x70]
000071c0d83d6c69  vmovaps xmm8, [rsp+0x80]
000071c0d83d6c72  vmovaps xmm9, [rsp+0x90]
000071c0d83d6c7b  vmovaps xmm11, [rsp+0xA0]
000071c0d83d6c84  vmovaps xmm12, [rsp+0xB0]
000071c0d83d6c8d  vmovaps xmm13, [rsp+0xC0]
000071c0d83d6c96  vmovaps xmm14, [rsp+0xD0]
000071c0d83d6c9f  vmovaps xmm15, [rsp+0xE0]
000071c0d83d6ca8  add rsp, 0xF0
000071c0d83d6caf  pop r11
000071c0d83d6cb1  pop r10
000071c0d83d6cb3  pop r9
000071c0d83d6cb5  pop r8
000071c0d83d6cb7  pop rsi
000071c0d83d6cb8  pop rdi
000071c0d83d6cb9  pop rdx
000071c0d83d6cba  pop rcx
000071c0d83d6cbb  pop rax
000071c0d83d6cbc  add rsp, 0x08
000071c0d83d6cc0  jmp 0x000071C0D83D5A06
000071c0d83d6cc5  sub rsp, 0x08
000071c0d83d6cc9  push rax
000071c0d83d6cca  push rcx
000071c0d83d6ccb  push rdx
000071c0d83d6ccc  push rdi
000071c0d83d6ccd  push rsi
000071c0d83d6cce  push r8
000071c0d83d6cd0  push r9
000071c0d83d6cd2  push r10
000071c0d83d6cd4  push r11
000071c0d83d6cd6  sub rsp, 0xF0
000071c0d83d6cdd  vmovaps [rsp], xmm0
000071c0d83d6ce2  vmovaps [rsp+0x10], xmm1
000071c0d83d6ce8  vmovaps [rsp+0x20], xmm2
000071c0d83d6cee  vmovaps [rsp+0x30], xmm3
000071c0d83d6cf4  vmovaps [rsp+0x40], xmm4
000071c0d83d6cfa  vmovaps [rsp+0x50], xmm5
000071c0d83d6d00  vmovaps [rsp+0x60], xmm7
000071c0d83d6d06  vmovaps [rsp+0x70], xmm8
000071c0d83d6d0c  vmovaps [rsp+0x80], xmm9
000071c0d83d6d15  vmovaps [rsp+0x90], xmm10
000071c0d83d6d1e  vmovaps [rsp+0xA0], xmm11
000071c0d83d6d27  vmovaps [rsp+0xB0], xmm12
000071c0d83d6d30  vmovaps [rsp+0xC0], xmm13
000071c0d83d6d39  vmovaps [rsp+0xD0], xmm14
000071c0d83d6d42  vmovaps [rsp+0xE0], xmm15
000071c0d83d6d4b  sub rsp, 0x30
000071c0d83d6d4f  movaps [rsp], xmm6
000071c0d83d6d53  movaps [rsp+0x10], xmm12
000071c0d83d6d59  movaps [rsp+0x20], xmm11
000071c0d83d6d5f  lea rdi, [rsp]
000071c0d83d6d63  mov esi, 0x00
000071c0d83d6d68  mov rax, 0x5904ED15D530
000071c0d83d6d72  call rax
000071c0d83d6d74  movaps xmm6, [rsp]
000071c0d83d6d78  add rsp, 0x30
000071c0d83d6d7c  vmovaps xmm0, [rsp]
000071c0d83d6d81  vmovaps xmm1, [rsp+0x10]
000071c0d83d6d87  vmovaps xmm2, [rsp+0x20]
000071c0d83d6d8d  vmovaps xmm3, [rsp+0x30]
000071c0d83d6d93  vmovaps xmm4, [rsp+0x40]
000071c0d83d6d99  vmovaps xmm5, [rsp+0x50]
000071c0d83d6d9f  vmovaps xmm7, [rsp+0x60]
000071c0d83d6da5  vmovaps xmm8, [rsp+0x70]
000071c0d83d6dab  vmovaps xmm9, [rsp+0x80]
000071c0d83d6db4  vmovaps xmm10, [rsp+0x90]
000071c0d83d6dbd  vmovaps xmm11, [rsp+0xA0]
000071c0d83d6dc6  vmovaps xmm12, [rsp+0xB0]
000071c0d83d6dcf  vmovaps xmm13, [rsp+0xC0]
000071c0d83d6dd8  vmovaps xmm14, [rsp+0xD0]
000071c0d83d6de1  vmovaps xmm15, [rsp+0xE0]
000071c0d83d6dea  add rsp, 0xF0
000071c0d83d6df1  pop r11
000071c0d83d6df3  pop r10
000071c0d83d6df5  pop r9
000071c0d83d6df7  pop r8
000071c0d83d6df9  pop rsi
000071c0d83d6dfa  pop rdi
000071c0d83d6dfb  pop rdx
000071c0d83d6dfc  pop rcx
000071c0d83d6dfd  pop rax
000071c0d83d6dfe  add rsp, 0x08
000071c0d83d6e02  jmp 0x000071C0D83D5A27
000071c0d83d6e07  sub rsp, 0x08
000071c0d83d6e0b  push rax
000071c0d83d6e0c  push rcx
000071c0d83d6e0d  push rdx
000071c0d83d6e0e  push rdi
000071c0d83d6e0f  push rsi
000071c0d83d6e10  push r8
000071c0d83d6e12  push r9
000071c0d83d6e14  push r10
000071c0d83d6e16  push r11
000071c0d83d6e18  sub rsp, 0xF0
000071c0d83d6e1f  vmovaps [rsp], xmm0
000071c0d83d6e24  vmovaps [rsp+0x10], xmm1
000071c0d83d6e2a  vmovaps [rsp+0x20], xmm2
000071c0d83d6e30  vmovaps [rsp+0x30], xmm4
000071c0d83d6e36  vmovaps [rsp+0x40], xmm5
000071c0d83d6e3c  vmovaps [rsp+0x50], xmm6
000071c0d83d6e42  vmovaps [rsp+0x60], xmm7
000071c0d83d6e48  vmovaps [rsp+0x70], xmm8
000071c0d83d6e4e  vmovaps [rsp+0x80], xmm9
000071c0d83d6e57  vmovaps [rsp+0x90], xmm10
000071c0d83d6e60  vmovaps [rsp+0xA0], xmm11
000071c0d83d6e69  vmovaps [rsp+0xB0], xmm12
000071c0d83d6e72  vmovaps [rsp+0xC0], xmm13
000071c0d83d6e7b  vmovaps [rsp+0xD0], xmm14
000071c0d83d6e84  vmovaps [rsp+0xE0], xmm15
000071c0d83d6e8d  sub rsp, 0x30
000071c0d83d6e91  movaps [rsp], xmm3
000071c0d83d6e95  movaps [rsp+0x10], xmm5
000071c0d83d6e9a  movaps [rsp+0x20], xmm4
000071c0d83d6e9f  lea rdi, [rsp]
000071c0d83d6ea3  mov esi, 0x00
000071c0d83d6ea8  mov rax, 0x5904ED15D530
000071c0d83d6eb2  call rax
000071c0d83d6eb4  movaps xmm3, [rsp]
000071c0d83d6eb8  add rsp, 0x30
000071c0d83d6ebc  vmovaps xmm0, [rsp]
000071c0d83d6ec1  vmovaps xmm1, [rsp+0x10]
000071c0d83d6ec7  vmovaps xmm2, [rsp+0x20]
000071c0d83d6ecd  vmovaps xmm4, [rsp+0x30]
000071c0d83d6ed3  vmovaps xmm5, [rsp+0x40]
000071c0d83d6ed9  vmovaps xmm6, [rsp+0x50]
000071c0d83d6edf  vmovaps xmm7, [rsp+0x60]
000071c0d83d6ee5  vmovaps xmm8, [rsp+0x70]
000071c0d83d6eeb  vmovaps xmm9, [rsp+0x80]
000071c0d83d6ef4  vmovaps xmm10, [rsp+0x90]
000071c0d83d6efd  vmovaps xmm11, [rsp+0xA0]
000071c0d83d6f06  vmovaps xmm12, [rsp+0xB0]
000071c0d83d6f0f  vmovaps xmm13, [rsp+0xC0]
000071c0d83d6f18  vmovaps xmm14, [rsp+0xD0]
000071c0d83d6f21  vmovaps xmm15, [rsp+0xE0]
000071c0d83d6f2a  add rsp, 0xF0
000071c0d83d6f31  pop r11
000071c0d83d6f33  pop r10
000071c0d83d6f35  pop r9
000071c0d83d6f37  pop r8
000071c0d83d6f39  pop rsi
000071c0d83d6f3a  pop rdi
000071c0d83d6f3b  pop rdx
000071c0d83d6f3c  pop rcx
000071c0d83d6f3d  pop rax
000071c0d83d6f3e  add rsp, 0x08
000071c0d83d6f42  jmp 0x000071C0D83D5A88
000071c0d83d6f47  sub rsp, 0x08
000071c0d83d6f4b  push rax
000071c0d83d6f4c  push rcx
000071c0d83d6f4d  push rdx
000071c0d83d6f4e  push rdi
000071c0d83d6f4f  push rsi
000071c0d83d6f50  push r8
000071c0d83d6f52  push r9
000071c0d83d6f54  push r10
000071c0d83d6f56  push r11
000071c0d83d6f58  sub rsp, 0xF0
000071c0d83d6f5f  vmovaps [rsp], xmm0
000071c0d83d6f64  vmovaps [rsp+0x10], xmm1
000071c0d83d6f6a  vmovaps [rsp+0x20], xmm2
000071c0d83d6f70  vmovaps [rsp+0x30], xmm3
000071c0d83d6f76  vmovaps [rsp+0x40], xmm4
000071c0d83d6f7c  vmovaps [rsp+0x50], xmm6
000071c0d83d6f82  vmovaps [rsp+0x60], xmm7
000071c0d83d6f88  vmovaps [rsp+0x70], xmm8
000071c0d83d6f8e  vmovaps [rsp+0x80], xmm9
000071c0d83d6f97  vmovaps [rsp+0x90], xmm10
000071c0d83d6fa0  vmovaps [rsp+0xA0], xmm11
000071c0d83d6fa9  vmovaps [rsp+0xB0], xmm12
000071c0d83d6fb2  vmovaps [rsp+0xC0], xmm13
000071c0d83d6fbb  vmovaps [rsp+0xD0], xmm14
000071c0d83d6fc4  vmovaps [rsp+0xE0], xmm15
000071c0d83d6fcd  sub rsp, 0x30
000071c0d83d6fd1  movaps [rsp], xmm5
000071c0d83d6fd5  movaps [rsp+0x10], xmm8
000071c0d83d6fdb  movaps [rsp+0x20], xmm15
000071c0d83d6fe1  lea rdi, [rsp]
000071c0d83d6fe5  mov esi, 0x00
000071c0d83d6fea  mov rax, 0x5904ED15D530
000071c0d83d6ff4  call rax
000071c0d83d6ff6  movaps xmm5, [rsp]
000071c0d83d6ffa  add rsp, 0x30
000071c0d83d6ffe  vmovaps xmm0, [rsp]
000071c0d83d7003  vmovaps xmm1, [rsp+0x10]
000071c0d83d7009  vmovaps xmm2, [rsp+0x20]
000071c0d83d700f  vmovaps xmm3, [rsp+0x30]
000071c0d83d7015  vmovaps xmm4, [rsp+0x40]
000071c0d83d701b  vmovaps xmm6, [rsp+0x50]
000071c0d83d7021  vmovaps xmm7, [rsp+0x60]
000071c0d83d7027  vmovaps xmm8, [rsp+0x70]
000071c0d83d702d  vmovaps xmm9, [rsp+0x80]
000071c0d83d7036  vmovaps xmm10, [rsp+0x90]
000071c0d83d703f  vmovaps xmm11, [rsp+0xA0]
000071c0d83d7048  vmovaps xmm12, [rsp+0xB0]
000071c0d83d7051  vmovaps xmm13, [rsp+0xC0]
000071c0d83d705a  vmovaps xmm14, [rsp+0xD0]
000071c0d83d7063  vmovaps xmm15, [rsp+0xE0]
000071c0d83d706c  add rsp, 0xF0
000071c0d83d7073  pop r11
000071c0d83d7075  pop r10
000071c0d83d7077  pop r9
000071c0d83d7079  pop r8
000071c0d83d707b  pop rsi
000071c0d83d707c  pop rdi
000071c0d83d707d  pop rdx
000071c0d83d707e  pop rcx
000071c0d83d707f  pop rax
000071c0d83d7080  add rsp, 0x08
000071c0d83d7084  jmp 0x000071C0D83D5AC0
000071c0d83d7089  sub rsp, 0x08
000071c0d83d708d  push rax
000071c0d83d708e  push rcx
000071c0d83d708f  push rdx
000071c0d83d7090  push rdi
000071c0d83d7091  push rsi
000071c0d83d7092  push r8
000071c0d83d7094  push r9
000071c0d83d7096  push r10
000071c0d83d7098  push r11
000071c0d83d709a  sub rsp, 0xF0
000071c0d83d70a1  vmovaps [rsp], xmm0
000071c0d83d70a6  vmovaps [rsp+0x10], xmm1
000071c0d83d70ac  vmovaps [rsp+0x20], xmm2
000071c0d83d70b2  vmovaps [rsp+0x30], xmm3
000071c0d83d70b8  vmovaps [rsp+0x40], xmm5
000071c0d83d70be  vmovaps [rsp+0x50], xmm6
000071c0d83d70c4  vmovaps [rsp+0x60], xmm7
000071c0d83d70ca  vmovaps [rsp+0x70], xmm8
000071c0d83d70d0  vmovaps [rsp+0x80], xmm9
000071c0d83d70d9  vmovaps [rsp+0x90], xmm10
000071c0d83d70e2  vmovaps [rsp+0xA0], xmm11
000071c0d83d70eb  vmovaps [rsp+0xB0], xmm12
000071c0d83d70f4  vmovaps [rsp+0xC0], xmm13
000071c0d83d70fd  vmovaps [rsp+0xD0], xmm14
000071c0d83d7106  vmovaps [rsp+0xE0], xmm15
000071c0d83d710f  sub rsp, 0x30
000071c0d83d7113  movaps [rsp], xmm4
000071c0d83d7117  movaps [rsp+0x10], xmm9
000071c0d83d711d  movaps [rsp+0x20], xmm8
000071c0d83d7123  lea rdi, [rsp]
000071c0d83d7127  mov esi, 0x00
000071c0d83d712c  mov rax, 0x5904ED15D530
000071c0d83d7136  call rax
000071c0d83d7138  movaps xmm4, [rsp]
000071c0d83d713c  add rsp, 0x30
000071c0d83d7140  vmovaps xmm0, [rsp]
000071c0d83d7145  vmovaps xmm1, [rsp+0x10]
000071c0d83d714b  vmovaps xmm2, [rsp+0x20]
000071c0d83d7151  vmovaps xmm3, [rsp+0x30]
000071c0d83d7157  vmovaps xmm5, [rsp+0x40]
000071c0d83d715d  vmovaps xmm6, [rsp+0x50]
000071c0d83d7163  vmovaps xmm7, [rsp+0x60]
000071c0d83d7169  vmovaps xmm8, [rsp+0x70]
000071c0d83d716f  vmovaps xmm9, [rsp+0x80]
000071c0d83d7178  vmovaps xmm10, [rsp+0x90]
000071c0d83d7181  vmovaps xmm11, [rsp+0xA0]
000071c0d83d718a  vmovaps xmm12, [rsp+0xB0]
000071c0d83d7193  vmovaps xmm13, [rsp+0xC0]
000071c0d83d719c  vmovaps xmm14, [rsp+0xD0]
000071c0d83d71a5  vmovaps xmm15, [rsp+0xE0]
000071c0d83d71ae  add rsp, 0xF0
000071c0d83d71b5  pop r11
000071c0d83d71b7  pop r10
000071c0d83d71b9  pop r9
000071c0d83d71bb  pop r8
000071c0d83d71bd  pop rsi
000071c0d83d71be  pop rdi
000071c0d83d71bf  pop rdx
000071c0d83d71c0  pop rcx
000071c0d83d71c1  pop rax
000071c0d83d71c2  add rsp, 0x08
000071c0d83d71c6  jmp 0x000071C0D83D5AE1
000071c0d83d71cb  sub rsp, 0x08
000071c0d83d71cf  push rax
000071c0d83d71d0  push rcx
000071c0d83d71d1  push rdx
000071c0d83d71d2  push rdi
000071c0d83d71d3  push rsi
000071c0d83d71d4  push r8
000071c0d83d71d6  push r9
000071c0d83d71d8  push r10
000071c0d83d71da  push r11
000071c0d83d71dc  sub rsp, 0xF0
000071c0d83d71e3  vmovaps [rsp], xmm0
000071c0d83d71e8  vmovaps [rsp+0x10], xmm1
000071c0d83d71ee  vmovaps [rsp+0x20], xmm2
000071c0d83d71f4  vmovaps [rsp+0x30], xmm3
000071c0d83d71fa  vmovaps [rsp+0x40], xmm4
000071c0d83d7200  vmovaps [rsp+0x50], xmm5
000071c0d83d7206  vmovaps [rsp+0x60], xmm6
000071c0d83d720c  vmovaps [rsp+0x70], xmm7
000071c0d83d7212  vmovaps [rsp+0x80], xmm8
000071c0d83d721b  vmovaps [rsp+0x90], xmm10
000071c0d83d7224  vmovaps [rsp+0xA0], xmm11
000071c0d83d722d  vmovaps [rsp+0xB0], xmm12
000071c0d83d7236  vmovaps [rsp+0xC0], xmm13
000071c0d83d723f  vmovaps [rsp+0xD0], xmm14
000071c0d83d7248  vmovaps [rsp+0xE0], xmm15
000071c0d83d7251  sub rsp, 0x30
000071c0d83d7255  movaps [rsp], xmm9
000071c0d83d725a  movaps [rsp+0x10], xmm10
000071c0d83d7260  movaps [rsp+0x20], xmm8
000071c0d83d7266  lea rdi, [rsp]
000071c0d83d726a  mov esi, 0x00
000071c0d83d726f  mov rax, 0x5904ED15D530
000071c0d83d7279  call rax
000071c0d83d727b  movaps xmm9, [rsp]
000071c0d83d7280  add rsp, 0x30
000071c0d83d7284  vmovaps xmm0, [rsp]
000071c0d83d7289  vmovaps xmm1, [rsp+0x10]
000071c0d83d728f  vmovaps xmm2, [rsp+0x20]
000071c0d83d7295  vmovaps xmm3, [rsp+0x30]
000071c0d83d729b  vmovaps xmm4, [rsp+0x40]
000071c0d83d72a1  vmovaps xmm5, [rsp+0x50]
000071c0d83d72a7  vmovaps xmm6, [rsp+0x60]
000071c0d83d72ad  vmovaps xmm7, [rsp+0x70]
000071c0d83d72b3  vmovaps xmm8, [rsp+0x80]
000071c0d83d72bc  vmovaps xmm10, [rsp+0x90]
000071c0d83d72c5  vmovaps xmm11, [rsp+0xA0]
000071c0d83d72ce  vmovaps xmm12, [rsp+0xB0]
000071c0d83d72d7  vmovaps xmm13, [rsp+0xC0]
000071c0d83d72e0  vmovaps xmm14, [rsp+0xD0]
000071c0d83d72e9  vmovaps xmm15, [rsp+0xE0]
000071c0d83d72f2  add rsp, 0xF0
000071c0d83d72f9  pop r11
000071c0d83d72fb  pop r10
000071c0d83d72fd  pop r9
000071c0d83d72ff  pop r8
000071c0d83d7301  pop rsi
000071c0d83d7302  pop rdi
000071c0d83d7303  pop rdx
000071c0d83d7304  pop rcx
000071c0d83d7305  pop rax
000071c0d83d7306  add rsp, 0x08
000071c0d83d730a  jmp 0x000071C0D83D5AFB
000071c0d83d730f  call 0x000071C0D82D64F0
000071c0d83d7314  jmp 0x000071C0D83D5C15
000071c0d83d7319  call 0x000071C0D82D64F0
000071c0d83d731e  jmp 0x000071C0D83D5C2B
000071c0d83d7323  sub rsp, 0x08
000071c0d83d7327  push rax
000071c0d83d7328  push rcx
000071c0d83d7329  push rdx
000071c0d83d732a  push rdi
000071c0d83d732b  push rsi
000071c0d83d732c  push r8
000071c0d83d732e  push r9
000071c0d83d7330  push r10
000071c0d83d7332  push r11
000071c0d83d7334  sub rsp, 0xF0
000071c0d83d733b  vmovaps [rsp], xmm0
000071c0d83d7340  vmovaps [rsp+0x10], xmm2
000071c0d83d7346  vmovaps [rsp+0x20], xmm3
000071c0d83d734c  vmovaps [rsp+0x30], xmm4
000071c0d83d7352  vmovaps [rsp+0x40], xmm5
000071c0d83d7358  vmovaps [rsp+0x50], xmm6
000071c0d83d735e  vmovaps [rsp+0x60], xmm7
000071c0d83d7364  vmovaps [rsp+0x70], xmm8
000071c0d83d736a  vmovaps [rsp+0x80], xmm9
000071c0d83d7373  vmovaps [rsp+0x90], xmm10
000071c0d83d737c  vmovaps [rsp+0xA0], xmm11
000071c0d83d7385  vmovaps [rsp+0xB0], xmm12
000071c0d83d738e  vmovaps [rsp+0xC0], xmm13
000071c0d83d7397  vmovaps [rsp+0xD0], xmm14
000071c0d83d73a0  vmovaps [rsp+0xE0], xmm15
000071c0d83d73a9  sub rsp, 0x30
000071c0d83d73ad  movaps [rsp], xmm1
000071c0d83d73b1  movaps [rsp+0x10], xmm6
000071c0d83d73b6  movaps [rsp+0x20], xmm15
000071c0d83d73bc  lea rdi, [rsp]
000071c0d83d73c0  mov esi, 0x00
000071c0d83d73c5  mov rax, 0x5904ED15D530
000071c0d83d73cf  call rax
000071c0d83d73d1  movaps xmm1, [rsp]
000071c0d83d73d5  add rsp, 0x30
000071c0d83d73d9  vmovaps xmm0, [rsp]
000071c0d83d73de  vmovaps xmm2, [rsp+0x10]
000071c0d83d73e4  vmovaps xmm3, [rsp+0x20]
000071c0d83d73ea  vmovaps xmm4, [rsp+0x30]
000071c0d83d73f0  vmovaps xmm5, [rsp+0x40]
000071c0d83d73f6  vmovaps xmm6, [rsp+0x50]
000071c0d83d73fc  vmovaps xmm7, [rsp+0x60]
000071c0d83d7402  vmovaps xmm8, [rsp+0x70]
000071c0d83d7408  vmovaps xmm9, [rsp+0x80]
000071c0d83d7411  vmovaps xmm10, [rsp+0x90]
000071c0d83d741a  vmovaps xmm11, [rsp+0xA0]
000071c0d83d7423  vmovaps xmm12, [rsp+0xB0]
000071c0d83d742c  vmovaps xmm13, [rsp+0xC0]
000071c0d83d7435  vmovaps xmm14, [rsp+0xD0]
000071c0d83d743e  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7447  add rsp, 0xF0
000071c0d83d744e  pop r11
000071c0d83d7450  pop r10
000071c0d83d7452  pop r9
000071c0d83d7454  pop r8
000071c0d83d7456  pop rsi
000071c0d83d7457  pop rdi
000071c0d83d7458  pop rdx
000071c0d83d7459  pop rcx
000071c0d83d745a  pop rax
000071c0d83d745b  add rsp, 0x08
000071c0d83d745f  jmp 0x000071C0D83D5C68
000071c0d83d7464  call 0x000071C0D82E5820
000071c0d83d7469  jmp 0x000071C0D83D5C75
000071c0d83d746e  sub rsp, 0x08
000071c0d83d7472  push rax
000071c0d83d7473  push rcx
000071c0d83d7474  push rdx
000071c0d83d7475  push rdi
000071c0d83d7476  push rsi
000071c0d83d7477  push r8
000071c0d83d7479  push r9
000071c0d83d747b  push r10
000071c0d83d747d  push r11
000071c0d83d747f  sub rsp, 0xF0
000071c0d83d7486  vmovaps [rsp], xmm0
000071c0d83d748b  vmovaps [rsp+0x10], xmm1
000071c0d83d7491  vmovaps [rsp+0x20], xmm2
000071c0d83d7497  vmovaps [rsp+0x30], xmm3
000071c0d83d749d  vmovaps [rsp+0x40], xmm4
000071c0d83d74a3  vmovaps [rsp+0x50], xmm5
000071c0d83d74a9  vmovaps [rsp+0x60], xmm6
000071c0d83d74af  vmovaps [rsp+0x70], xmm7
000071c0d83d74b5  vmovaps [rsp+0x80], xmm8
000071c0d83d74be  vmovaps [rsp+0x90], xmm9
000071c0d83d74c7  vmovaps [rsp+0xA0], xmm10
000071c0d83d74d0  vmovaps [rsp+0xB0], xmm11
000071c0d83d74d9  vmovaps [rsp+0xC0], xmm12
000071c0d83d74e2  vmovaps [rsp+0xD0], xmm13
000071c0d83d74eb  vmovaps [rsp+0xE0], xmm15
000071c0d83d74f4  sub rsp, 0x30
000071c0d83d74f8  movaps [rsp], xmm14
000071c0d83d74fd  movaps [rsp+0x10], xmm4
000071c0d83d7502  movaps [rsp+0x20], xmm3
000071c0d83d7507  lea rdi, [rsp]
000071c0d83d750b  mov esi, 0x00
000071c0d83d7510  mov rax, 0x5904ED15D530
000071c0d83d751a  call rax
000071c0d83d751c  movaps xmm14, [rsp]
000071c0d83d7521  add rsp, 0x30
000071c0d83d7525  vmovaps xmm0, [rsp]
000071c0d83d752a  vmovaps xmm1, [rsp+0x10]
000071c0d83d7530  vmovaps xmm2, [rsp+0x20]
000071c0d83d7536  vmovaps xmm3, [rsp+0x30]
000071c0d83d753c  vmovaps xmm4, [rsp+0x40]
000071c0d83d7542  vmovaps xmm5, [rsp+0x50]
000071c0d83d7548  vmovaps xmm6, [rsp+0x60]
000071c0d83d754e  vmovaps xmm7, [rsp+0x70]
000071c0d83d7554  vmovaps xmm8, [rsp+0x80]
000071c0d83d755d  vmovaps xmm9, [rsp+0x90]
000071c0d83d7566  vmovaps xmm10, [rsp+0xA0]
000071c0d83d756f  vmovaps xmm11, [rsp+0xB0]
000071c0d83d7578  vmovaps xmm12, [rsp+0xC0]
000071c0d83d7581  vmovaps xmm13, [rsp+0xD0]
000071c0d83d758a  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7593  add rsp, 0xF0
000071c0d83d759a  pop r11
000071c0d83d759c  pop r10
000071c0d83d759e  pop r9
000071c0d83d75a0  pop r8
000071c0d83d75a2  pop rsi
000071c0d83d75a3  pop rdi
000071c0d83d75a4  pop rdx
000071c0d83d75a5  pop rcx
000071c0d83d75a6  pop rax
000071c0d83d75a7  add rsp, 0x08
000071c0d83d75ab  jmp 0x000071C0D83D5C8F
000071c0d83d75b0  sub rsp, 0x08
000071c0d83d75b4  push rax
000071c0d83d75b5  push rcx
000071c0d83d75b6  push rdx
000071c0d83d75b7  push rdi
000071c0d83d75b8  push rsi
000071c0d83d75b9  push r8
000071c0d83d75bb  push r9
000071c0d83d75bd  push r10
000071c0d83d75bf  push r11
000071c0d83d75c1  sub rsp, 0xF0
000071c0d83d75c8  vmovaps [rsp], xmm0
000071c0d83d75cd  vmovaps [rsp+0x10], xmm1
000071c0d83d75d3  vmovaps [rsp+0x20], xmm2
000071c0d83d75d9  vmovaps [rsp+0x30], xmm3
000071c0d83d75df  vmovaps [rsp+0x40], xmm4
000071c0d83d75e5  vmovaps [rsp+0x50], xmm5
000071c0d83d75eb  vmovaps [rsp+0x60], xmm7
000071c0d83d75f1  vmovaps [rsp+0x70], xmm8
000071c0d83d75f7  vmovaps [rsp+0x80], xmm9
000071c0d83d7600  vmovaps [rsp+0x90], xmm10
000071c0d83d7609  vmovaps [rsp+0xA0], xmm11
000071c0d83d7612  vmovaps [rsp+0xB0], xmm12
000071c0d83d761b  vmovaps [rsp+0xC0], xmm13
000071c0d83d7624  vmovaps [rsp+0xD0], xmm14
000071c0d83d762d  vmovaps [rsp+0xE0], xmm15
000071c0d83d7636  sub rsp, 0x30
000071c0d83d763a  movaps [rsp], xmm6
000071c0d83d763e  movaps [rsp+0x10], xmm9
000071c0d83d7644  movaps [rsp+0x20], xmm7
000071c0d83d7649  lea rdi, [rsp]
000071c0d83d764d  mov esi, 0x00
000071c0d83d7652  mov rax, 0x5904ED15D530
000071c0d83d765c  call rax
000071c0d83d765e  movaps xmm6, [rsp]
000071c0d83d7662  add rsp, 0x30
000071c0d83d7666  vmovaps xmm0, [rsp]
000071c0d83d766b  vmovaps xmm1, [rsp+0x10]
000071c0d83d7671  vmovaps xmm2, [rsp+0x20]
000071c0d83d7677  vmovaps xmm3, [rsp+0x30]
000071c0d83d767d  vmovaps xmm4, [rsp+0x40]
000071c0d83d7683  vmovaps xmm5, [rsp+0x50]
000071c0d83d7689  vmovaps xmm7, [rsp+0x60]
000071c0d83d768f  vmovaps xmm8, [rsp+0x70]
000071c0d83d7695  vmovaps xmm9, [rsp+0x80]
000071c0d83d769e  vmovaps xmm10, [rsp+0x90]
000071c0d83d76a7  vmovaps xmm11, [rsp+0xA0]
000071c0d83d76b0  vmovaps xmm12, [rsp+0xB0]
000071c0d83d76b9  vmovaps xmm13, [rsp+0xC0]
000071c0d83d76c2  vmovaps xmm14, [rsp+0xD0]
000071c0d83d76cb  vmovaps xmm15, [rsp+0xE0]
000071c0d83d76d4  add rsp, 0xF0
000071c0d83d76db  pop r11
000071c0d83d76dd  pop r10
000071c0d83d76df  pop r9
000071c0d83d76e1  pop r8
000071c0d83d76e3  pop rsi
000071c0d83d76e4  pop rdi
000071c0d83d76e5  pop rdx
000071c0d83d76e6  pop rcx
000071c0d83d76e7  pop rax
000071c0d83d76e8  add rsp, 0x08
000071c0d83d76ec  jmp 0x000071C0D83D5CA7
000071c0d83d76f1  sub rsp, 0x08
000071c0d83d76f5  push rax
000071c0d83d76f6  push rcx
000071c0d83d76f7  push rdx
000071c0d83d76f8  push rdi
000071c0d83d76f9  push rsi
000071c0d83d76fa  push r8
000071c0d83d76fc  push r9
000071c0d83d76fe  push r10
000071c0d83d7700  push r11
000071c0d83d7702  sub rsp, 0xF0
000071c0d83d7709  vmovaps [rsp], xmm0
000071c0d83d770e  vmovaps [rsp+0x10], xmm1
000071c0d83d7714  vmovaps [rsp+0x20], xmm2
000071c0d83d771a  vmovaps [rsp+0x30], xmm3
000071c0d83d7720  vmovaps [rsp+0x40], xmm4
000071c0d83d7726  vmovaps [rsp+0x50], xmm5
000071c0d83d772c  vmovaps [rsp+0x60], xmm6
000071c0d83d7732  vmovaps [rsp+0x70], xmm8
000071c0d83d7738  vmovaps [rsp+0x80], xmm9
000071c0d83d7741  vmovaps [rsp+0x90], xmm10
000071c0d83d774a  vmovaps [rsp+0xA0], xmm11
000071c0d83d7753  vmovaps [rsp+0xB0], xmm12
000071c0d83d775c  vmovaps [rsp+0xC0], xmm13
000071c0d83d7765  vmovaps [rsp+0xD0], xmm14
000071c0d83d776e  vmovaps [rsp+0xE0], xmm15
000071c0d83d7777  sub rsp, 0x30
000071c0d83d777b  movaps [rsp], xmm7
000071c0d83d777f  movaps [rsp+0x10], xmm4
000071c0d83d7784  movaps [rsp+0x20], xmm9
000071c0d83d778a  lea rdi, [rsp]
000071c0d83d778e  mov esi, 0x00
000071c0d83d7793  mov rax, 0x5904ED15D530
000071c0d83d779d  call rax
000071c0d83d779f  movaps xmm7, [rsp]
000071c0d83d77a3  add rsp, 0x30
000071c0d83d77a7  vmovaps xmm0, [rsp]
000071c0d83d77ac  vmovaps xmm1, [rsp+0x10]
000071c0d83d77b2  vmovaps xmm2, [rsp+0x20]
000071c0d83d77b8  vmovaps xmm3, [rsp+0x30]
000071c0d83d77be  vmovaps xmm4, [rsp+0x40]
000071c0d83d77c4  vmovaps xmm5, [rsp+0x50]
000071c0d83d77ca  vmovaps xmm6, [rsp+0x60]
000071c0d83d77d0  vmovaps xmm8, [rsp+0x70]
000071c0d83d77d6  vmovaps xmm9, [rsp+0x80]
000071c0d83d77df  vmovaps xmm10, [rsp+0x90]
000071c0d83d77e8  vmovaps xmm11, [rsp+0xA0]
000071c0d83d77f1  vmovaps xmm12, [rsp+0xB0]
000071c0d83d77fa  vmovaps xmm13, [rsp+0xC0]
000071c0d83d7803  vmovaps xmm14, [rsp+0xD0]
000071c0d83d780c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7815  add rsp, 0xF0
000071c0d83d781c  pop r11
000071c0d83d781e  pop r10
000071c0d83d7820  pop r9
000071c0d83d7822  pop r8
000071c0d83d7824  pop rsi
000071c0d83d7825  pop rdi
000071c0d83d7826  pop rdx
000071c0d83d7827  pop rcx
000071c0d83d7828  pop rax
000071c0d83d7829  add rsp, 0x08
000071c0d83d782d  jmp 0x000071C0D83D5CD4
000071c0d83d7832  sub rsp, 0x08
000071c0d83d7836  push rax
000071c0d83d7837  push rcx
000071c0d83d7838  push rdx
000071c0d83d7839  push rdi
000071c0d83d783a  push rsi
000071c0d83d783b  push r8
000071c0d83d783d  push r9
000071c0d83d783f  push r10
000071c0d83d7841  push r11
000071c0d83d7843  sub rsp, 0xF0
000071c0d83d784a  vmovaps [rsp], xmm0
000071c0d83d784f  vmovaps [rsp+0x10], xmm1
000071c0d83d7855  vmovaps [rsp+0x20], xmm2
000071c0d83d785b  vmovaps [rsp+0x30], xmm3
000071c0d83d7861  vmovaps [rsp+0x40], xmm5
000071c0d83d7867  vmovaps [rsp+0x50], xmm6
000071c0d83d786d  vmovaps [rsp+0x60], xmm7
000071c0d83d7873  vmovaps [rsp+0x70], xmm8
000071c0d83d7879  vmovaps [rsp+0x80], xmm9
000071c0d83d7882  vmovaps [rsp+0x90], xmm10
000071c0d83d788b  vmovaps [rsp+0xA0], xmm11
000071c0d83d7894  vmovaps [rsp+0xB0], xmm12
000071c0d83d789d  vmovaps [rsp+0xC0], xmm13
000071c0d83d78a6  vmovaps [rsp+0xD0], xmm14
000071c0d83d78af  vmovaps [rsp+0xE0], xmm15
000071c0d83d78b8  sub rsp, 0x30
000071c0d83d78bc  movaps [rsp], xmm4
000071c0d83d78c0  movaps [rsp+0x10], xmm15
000071c0d83d78c6  movaps [rsp+0x20], xmm9
000071c0d83d78cc  lea rdi, [rsp]
000071c0d83d78d0  mov esi, 0x00
000071c0d83d78d5  mov rax, 0x5904ED15D530
000071c0d83d78df  call rax
000071c0d83d78e1  movaps xmm4, [rsp]
000071c0d83d78e5  add rsp, 0x30
000071c0d83d78e9  vmovaps xmm0, [rsp]
000071c0d83d78ee  vmovaps xmm1, [rsp+0x10]
000071c0d83d78f4  vmovaps xmm2, [rsp+0x20]
000071c0d83d78fa  vmovaps xmm3, [rsp+0x30]
000071c0d83d7900  vmovaps xmm5, [rsp+0x40]
000071c0d83d7906  vmovaps xmm6, [rsp+0x50]
000071c0d83d790c  vmovaps xmm7, [rsp+0x60]
000071c0d83d7912  vmovaps xmm8, [rsp+0x70]
000071c0d83d7918  vmovaps xmm9, [rsp+0x80]
000071c0d83d7921  vmovaps xmm10, [rsp+0x90]
000071c0d83d792a  vmovaps xmm11, [rsp+0xA0]
000071c0d83d7933  vmovaps xmm12, [rsp+0xB0]
000071c0d83d793c  vmovaps xmm13, [rsp+0xC0]
000071c0d83d7945  vmovaps xmm14, [rsp+0xD0]
000071c0d83d794e  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7957  add rsp, 0xF0
000071c0d83d795e  pop r11
000071c0d83d7960  pop r10
000071c0d83d7962  pop r9
000071c0d83d7964  pop r8
000071c0d83d7966  pop rsi
000071c0d83d7967  pop rdi
000071c0d83d7968  pop rdx
000071c0d83d7969  pop rcx
000071c0d83d796a  pop rax
000071c0d83d796b  add rsp, 0x08
000071c0d83d796f  jmp 0x000071C0D83D5CF9
000071c0d83d7974  call 0x000071C0D82E5820
000071c0d83d7979  jmp 0x000071C0D83D5D06
000071c0d83d797e  sub rsp, 0x08
000071c0d83d7982  push rax
000071c0d83d7983  push rcx
000071c0d83d7984  push rdx
000071c0d83d7985  push rdi
000071c0d83d7986  push rsi
000071c0d83d7987  push r8
000071c0d83d7989  push r9
000071c0d83d798b  push r10
000071c0d83d798d  push r11
000071c0d83d798f  sub rsp, 0xF0
000071c0d83d7996  vmovaps [rsp], xmm0
000071c0d83d799b  vmovaps [rsp+0x10], xmm1
000071c0d83d79a1  vmovaps [rsp+0x20], xmm2
000071c0d83d79a7  vmovaps [rsp+0x30], xmm4
000071c0d83d79ad  vmovaps [rsp+0x40], xmm5
000071c0d83d79b3  vmovaps [rsp+0x50], xmm6
000071c0d83d79b9  vmovaps [rsp+0x60], xmm7
000071c0d83d79bf  vmovaps [rsp+0x70], xmm8
000071c0d83d79c5  vmovaps [rsp+0x80], xmm9
000071c0d83d79ce  vmovaps [rsp+0x90], xmm10
000071c0d83d79d7  vmovaps [rsp+0xA0], xmm11
000071c0d83d79e0  vmovaps [rsp+0xB0], xmm12
000071c0d83d79e9  vmovaps [rsp+0xC0], xmm13
000071c0d83d79f2  vmovaps [rsp+0xD0], xmm14
000071c0d83d79fb  vmovaps [rsp+0xE0], xmm15
000071c0d83d7a04  sub rsp, 0x30
000071c0d83d7a08  movaps [rsp], xmm3
000071c0d83d7a0c  movaps [rsp+0x10], xmm1
000071c0d83d7a11  movaps [rsp+0x20], xmm9
000071c0d83d7a17  lea rdi, [rsp]
000071c0d83d7a1b  mov esi, 0x00
000071c0d83d7a20  mov rax, 0x5904ED15D530
000071c0d83d7a2a  call rax
000071c0d83d7a2c  movaps xmm3, [rsp]
000071c0d83d7a30  add rsp, 0x30
000071c0d83d7a34  vmovaps xmm0, [rsp]
000071c0d83d7a39  vmovaps xmm1, [rsp+0x10]
000071c0d83d7a3f  vmovaps xmm2, [rsp+0x20]
000071c0d83d7a45  vmovaps xmm4, [rsp+0x30]
000071c0d83d7a4b  vmovaps xmm5, [rsp+0x40]
000071c0d83d7a51  vmovaps xmm6, [rsp+0x50]
000071c0d83d7a57  vmovaps xmm7, [rsp+0x60]
000071c0d83d7a5d  vmovaps xmm8, [rsp+0x70]
000071c0d83d7a63  vmovaps xmm9, [rsp+0x80]
000071c0d83d7a6c  vmovaps xmm10, [rsp+0x90]
000071c0d83d7a75  vmovaps xmm11, [rsp+0xA0]
000071c0d83d7a7e  vmovaps xmm12, [rsp+0xB0]
000071c0d83d7a87  vmovaps xmm13, [rsp+0xC0]
000071c0d83d7a90  vmovaps xmm14, [rsp+0xD0]
000071c0d83d7a99  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7aa2  add rsp, 0xF0
000071c0d83d7aa9  pop r11
000071c0d83d7aab  pop r10
000071c0d83d7aad  pop r9
000071c0d83d7aaf  pop r8
000071c0d83d7ab1  pop rsi
000071c0d83d7ab2  pop rdi
000071c0d83d7ab3  pop rdx
000071c0d83d7ab4  pop rcx
000071c0d83d7ab5  pop rax
000071c0d83d7ab6  add rsp, 0x08
000071c0d83d7aba  jmp 0x000071C0D83D5D43
000071c0d83d7abf  sub rsp, 0x08
000071c0d83d7ac3  push rax
000071c0d83d7ac4  push rcx
000071c0d83d7ac5  push rdx
000071c0d83d7ac6  push rdi
000071c0d83d7ac7  push rsi
000071c0d83d7ac8  push r8
000071c0d83d7aca  push r9
000071c0d83d7acc  push r10
000071c0d83d7ace  push r11
000071c0d83d7ad0  sub rsp, 0xF0
000071c0d83d7ad7  vmovaps [rsp], xmm0
000071c0d83d7adc  vmovaps [rsp+0x10], xmm2
000071c0d83d7ae2  vmovaps [rsp+0x20], xmm3
000071c0d83d7ae8  vmovaps [rsp+0x30], xmm4
000071c0d83d7aee  vmovaps [rsp+0x40], xmm5
000071c0d83d7af4  vmovaps [rsp+0x50], xmm6
000071c0d83d7afa  vmovaps [rsp+0x60], xmm7
000071c0d83d7b00  vmovaps [rsp+0x70], xmm8
000071c0d83d7b06  vmovaps [rsp+0x80], xmm9
000071c0d83d7b0f  vmovaps [rsp+0x90], xmm10
000071c0d83d7b18  vmovaps [rsp+0xA0], xmm11
000071c0d83d7b21  vmovaps [rsp+0xB0], xmm12
000071c0d83d7b2a  vmovaps [rsp+0xC0], xmm13
000071c0d83d7b33  vmovaps [rsp+0xD0], xmm14
000071c0d83d7b3c  vmovaps [rsp+0xE0], xmm15
000071c0d83d7b45  sub rsp, 0x30
000071c0d83d7b49  movaps [rsp], xmm1
000071c0d83d7b4d  movaps [rsp+0x10], xmm15
000071c0d83d7b53  movaps [rsp+0x20], xmm9
000071c0d83d7b59  lea rdi, [rsp]
000071c0d83d7b5d  mov esi, 0x00
000071c0d83d7b62  mov rax, 0x5904ED15D530
000071c0d83d7b6c  call rax
000071c0d83d7b6e  movaps xmm1, [rsp]
000071c0d83d7b72  add rsp, 0x30
000071c0d83d7b76  vmovaps xmm0, [rsp]
000071c0d83d7b7b  vmovaps xmm2, [rsp+0x10]
000071c0d83d7b81  vmovaps xmm3, [rsp+0x20]
000071c0d83d7b87  vmovaps xmm4, [rsp+0x30]
000071c0d83d7b8d  vmovaps xmm5, [rsp+0x40]
000071c0d83d7b93  vmovaps xmm6, [rsp+0x50]
000071c0d83d7b99  vmovaps xmm7, [rsp+0x60]
000071c0d83d7b9f  vmovaps xmm8, [rsp+0x70]
000071c0d83d7ba5  vmovaps xmm9, [rsp+0x80]
000071c0d83d7bae  vmovaps xmm10, [rsp+0x90]
000071c0d83d7bb7  vmovaps xmm11, [rsp+0xA0]
000071c0d83d7bc0  vmovaps xmm12, [rsp+0xB0]
000071c0d83d7bc9  vmovaps xmm13, [rsp+0xC0]
000071c0d83d7bd2  vmovaps xmm14, [rsp+0xD0]
000071c0d83d7bdb  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7be4  add rsp, 0xF0
000071c0d83d7beb  pop r11
000071c0d83d7bed  pop r10
000071c0d83d7bef  pop r9
000071c0d83d7bf1  pop r8
000071c0d83d7bf3  pop rsi
000071c0d83d7bf4  pop rdi
000071c0d83d7bf5  pop rdx
000071c0d83d7bf6  pop rcx
000071c0d83d7bf7  pop rax
000071c0d83d7bf8  add rsp, 0x08
000071c0d83d7bfc  jmp 0x000071C0D83D5DCB
000071c0d83d7c01  call 0x000071C0D82E5820
000071c0d83d7c06  jmp 0x000071C0D83D5DD8
000071c0d83d7c0b  sub rsp, 0x08
000071c0d83d7c0f  push rax
000071c0d83d7c10  push rcx
000071c0d83d7c11  push rdx
000071c0d83d7c12  push rdi
000071c0d83d7c13  push rsi
000071c0d83d7c14  push r8
000071c0d83d7c16  push r9
000071c0d83d7c18  push r10
000071c0d83d7c1a  push r11
000071c0d83d7c1c  sub rsp, 0xF0
000071c0d83d7c23  vmovaps [rsp], xmm0
000071c0d83d7c28  vmovaps [rsp+0x10], xmm2
000071c0d83d7c2e  vmovaps [rsp+0x20], xmm3
000071c0d83d7c34  vmovaps [rsp+0x30], xmm4
000071c0d83d7c3a  vmovaps [rsp+0x40], xmm5
000071c0d83d7c40  vmovaps [rsp+0x50], xmm6
000071c0d83d7c46  vmovaps [rsp+0x60], xmm7
000071c0d83d7c4c  vmovaps [rsp+0x70], xmm8
000071c0d83d7c52  vmovaps [rsp+0x80], xmm9
000071c0d83d7c5b  vmovaps [rsp+0x90], xmm10
000071c0d83d7c64  vmovaps [rsp+0xA0], xmm11
000071c0d83d7c6d  vmovaps [rsp+0xB0], xmm12
000071c0d83d7c76  vmovaps [rsp+0xC0], xmm13
000071c0d83d7c7f  vmovaps [rsp+0xD0], xmm14
000071c0d83d7c88  vmovaps [rsp+0xE0], xmm15
000071c0d83d7c91  sub rsp, 0x30
000071c0d83d7c95  movaps [rsp], xmm1
000071c0d83d7c99  movaps [rsp+0x10], xmm5
000071c0d83d7c9e  movaps [rsp+0x20], xmm7
000071c0d83d7ca3  lea rdi, [rsp]
000071c0d83d7ca7  mov esi, 0x00
000071c0d83d7cac  mov rax, 0x5904ED15D530
000071c0d83d7cb6  call rax
000071c0d83d7cb8  movaps xmm1, [rsp]
000071c0d83d7cbc  add rsp, 0x30
000071c0d83d7cc0  vmovaps xmm0, [rsp]
000071c0d83d7cc5  vmovaps xmm2, [rsp+0x10]
000071c0d83d7ccb  vmovaps xmm3, [rsp+0x20]
000071c0d83d7cd1  vmovaps xmm4, [rsp+0x30]
000071c0d83d7cd7  vmovaps xmm5, [rsp+0x40]
000071c0d83d7cdd  vmovaps xmm6, [rsp+0x50]
000071c0d83d7ce3  vmovaps xmm7, [rsp+0x60]
000071c0d83d7ce9  vmovaps xmm8, [rsp+0x70]
000071c0d83d7cef  vmovaps xmm9, [rsp+0x80]
000071c0d83d7cf8  vmovaps xmm10, [rsp+0x90]
000071c0d83d7d01  vmovaps xmm11, [rsp+0xA0]
000071c0d83d7d0a  vmovaps xmm12, [rsp+0xB0]
000071c0d83d7d13  vmovaps xmm13, [rsp+0xC0]
000071c0d83d7d1c  vmovaps xmm14, [rsp+0xD0]
000071c0d83d7d25  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7d2e  add rsp, 0xF0
000071c0d83d7d35  pop r11
000071c0d83d7d37  pop r10
000071c0d83d7d39  pop r9
000071c0d83d7d3b  pop r8
000071c0d83d7d3d  pop rsi
000071c0d83d7d3e  pop rdi
000071c0d83d7d3f  pop rdx
000071c0d83d7d40  pop rcx
000071c0d83d7d41  pop rax
000071c0d83d7d42  add rsp, 0x08
000071c0d83d7d46  jmp 0x000071C0D83D5E7D
000071c0d83d7d4b  sub rsp, 0x08
000071c0d83d7d4f  push rax
000071c0d83d7d50  push rcx
000071c0d83d7d51  push rdx
000071c0d83d7d52  push rdi
000071c0d83d7d53  push rsi
000071c0d83d7d54  push r8
000071c0d83d7d56  push r9
000071c0d83d7d58  push r10
000071c0d83d7d5a  push r11
000071c0d83d7d5c  sub rsp, 0xF0
000071c0d83d7d63  vmovaps [rsp], xmm0
000071c0d83d7d68  vmovaps [rsp+0x10], xmm1
000071c0d83d7d6e  vmovaps [rsp+0x20], xmm2
000071c0d83d7d74  vmovaps [rsp+0x30], xmm3
000071c0d83d7d7a  vmovaps [rsp+0x40], xmm4
000071c0d83d7d80  vmovaps [rsp+0x50], xmm5
000071c0d83d7d86  vmovaps [rsp+0x60], xmm6
000071c0d83d7d8c  vmovaps [rsp+0x70], xmm8
000071c0d83d7d92  vmovaps [rsp+0x80], xmm9
000071c0d83d7d9b  vmovaps [rsp+0x90], xmm10
000071c0d83d7da4  vmovaps [rsp+0xA0], xmm11
000071c0d83d7dad  vmovaps [rsp+0xB0], xmm12
000071c0d83d7db6  vmovaps [rsp+0xC0], xmm13
000071c0d83d7dbf  vmovaps [rsp+0xD0], xmm14
000071c0d83d7dc8  vmovaps [rsp+0xE0], xmm15
000071c0d83d7dd1  sub rsp, 0x30
000071c0d83d7dd5  movaps [rsp], xmm7
000071c0d83d7dd9  movaps [rsp+0x10], xmm5
000071c0d83d7dde  movaps [rsp+0x20], xmm15
000071c0d83d7de4  lea rdi, [rsp]
000071c0d83d7de8  mov esi, 0x00
000071c0d83d7ded  mov rax, 0x5904ED15D530
000071c0d83d7df7  call rax
000071c0d83d7df9  movaps xmm7, [rsp]
000071c0d83d7dfd  add rsp, 0x30
000071c0d83d7e01  vmovaps xmm0, [rsp]
000071c0d83d7e06  vmovaps xmm1, [rsp+0x10]
000071c0d83d7e0c  vmovaps xmm2, [rsp+0x20]
000071c0d83d7e12  vmovaps xmm3, [rsp+0x30]
000071c0d83d7e18  vmovaps xmm4, [rsp+0x40]
000071c0d83d7e1e  vmovaps xmm5, [rsp+0x50]
000071c0d83d7e24  vmovaps xmm6, [rsp+0x60]
000071c0d83d7e2a  vmovaps xmm8, [rsp+0x70]
000071c0d83d7e30  vmovaps xmm9, [rsp+0x80]
000071c0d83d7e39  vmovaps xmm10, [rsp+0x90]
000071c0d83d7e42  vmovaps xmm11, [rsp+0xA0]
000071c0d83d7e4b  vmovaps xmm12, [rsp+0xB0]
000071c0d83d7e54  vmovaps xmm13, [rsp+0xC0]
000071c0d83d7e5d  vmovaps xmm14, [rsp+0xD0]
000071c0d83d7e66  vmovaps xmm15, [rsp+0xE0]
000071c0d83d7e6f  add rsp, 0xF0
000071c0d83d7e76  pop r11
000071c0d83d7e78  pop r10
000071c0d83d7e7a  pop r9
000071c0d83d7e7c  pop r8
000071c0d83d7e7e  pop rsi
000071c0d83d7e7f  pop rdi
000071c0d83d7e80  pop rdx
000071c0d83d7e81  pop rcx
000071c0d83d7e82  pop rax
000071c0d83d7e83  add rsp, 0x08
000071c0d83d7e87  jmp 0x000071C0D83D5EB3
000071c0d83d7e8c  call 0x000071C0D82D64F0
000071c0d83d7e91  jmp 0x000071C0D83D5EC0
000071c0d83d7e96  sub rsp, 0x08
000071c0d83d7e9a  push rax
000071c0d83d7e9b  push rcx
000071c0d83d7e9c  push rdx
000071c0d83d7e9d  push rdi
000071c0d83d7e9e  push rsi
000071c0d83d7e9f  push r8
000071c0d83d7ea1  push r9
000071c0d83d7ea3  push r10
000071c0d83d7ea5  push r11
000071c0d83d7ea7  sub rsp, 0xF0
000071c0d83d7eae  vmovaps [rsp], xmm0
000071c0d83d7eb3  vmovaps [rsp+0x10], xmm1
000071c0d83d7eb9  vmovaps [rsp+0x20], xmm2
000071c0d83d7ebf  vmovaps [rsp+0x30], xmm3
000071c0d83d7ec5  vmovaps [rsp+0x40], xmm4
000071c0d83d7ecb  vmovaps [rsp+0x50], xmm5
000071c0d83d7ed1  vmovaps [rsp+0x60], xmm6
000071c0d83d7ed7  vmovaps [rsp+0x70], xmm7
000071c0d83d7edd  vmovaps [rsp+0x80], xmm8
000071c0d83d7ee6  vmovaps [rsp+0x90], xmm9
000071c0d83d7eef  vmovaps [rsp+0xA0], xmm10
000071c0d83d7ef8  vmovaps [rsp+0xB0], xmm11
000071c0d83d7f01  vmovaps [rsp+0xC0], xmm12
000071c0d83d7f0a  vmovaps [rsp+0xD0], xmm13
000071c0d83d7f13  vmovaps [rsp+0xE0], xmm14
000071c0d83d7f1c  sub rsp, 0x30
000071c0d83d7f20  movaps [rsp], xmm15
000071c0d83d7f25  movaps [rsp+0x10], xmm5
000071c0d83d7f2a  movaps [rsp+0x20], xmm3
000071c0d83d7f2f  lea rdi, [rsp]
000071c0d83d7f33  mov esi, 0x00
000071c0d83d7f38  mov rax, 0x5904ED15D530
000071c0d83d7f42  call rax
000071c0d83d7f44  movaps xmm15, [rsp]
000071c0d83d7f49  add rsp, 0x30
000071c0d83d7f4d  vmovaps xmm0, [rsp]
000071c0d83d7f52  vmovaps xmm1, [rsp+0x10]
000071c0d83d7f58  vmovaps xmm2, [rsp+0x20]
000071c0d83d7f5e  vmovaps xmm3, [rsp+0x30]
000071c0d83d7f64  vmovaps xmm4, [rsp+0x40]
000071c0d83d7f6a  vmovaps xmm5, [rsp+0x50]
000071c0d83d7f70  vmovaps xmm6, [rsp+0x60]
000071c0d83d7f76  vmovaps xmm7, [rsp+0x70]
000071c0d83d7f7c  vmovaps xmm8, [rsp+0x80]
000071c0d83d7f85  vmovaps xmm9, [rsp+0x90]
000071c0d83d7f8e  vmovaps xmm10, [rsp+0xA0]
000071c0d83d7f97  vmovaps xmm11, [rsp+0xB0]
000071c0d83d7fa0  vmovaps xmm12, [rsp+0xC0]
000071c0d83d7fa9  vmovaps xmm13, [rsp+0xD0]
000071c0d83d7fb2  vmovaps xmm14, [rsp+0xE0]
000071c0d83d7fbb  add rsp, 0xF0
000071c0d83d7fc2  pop r11
000071c0d83d7fc4  pop r10
000071c0d83d7fc6  pop r9
000071c0d83d7fc8  pop r8
000071c0d83d7fca  pop rsi
000071c0d83d7fcb  pop rdi
000071c0d83d7fcc  pop rdx
000071c0d83d7fcd  pop rcx
000071c0d83d7fce  pop rax
000071c0d83d7fcf  add rsp, 0x08
000071c0d83d7fd3  jmp 0x000071C0D83D5EE6
000071c0d83d7fd8  sub rsp, 0x08
000071c0d83d7fdc  push rax
000071c0d83d7fdd  push rcx
000071c0d83d7fde  push rdx
000071c0d83d7fdf  push rdi
000071c0d83d7fe0  push rsi
000071c0d83d7fe1  push r8
000071c0d83d7fe3  push r9
000071c0d83d7fe5  push r10
000071c0d83d7fe7  push r11
000071c0d83d7fe9  sub rsp, 0xF0
000071c0d83d7ff0  vmovaps [rsp], xmm0
000071c0d83d7ff5  vmovaps [rsp+0x10], xmm2
000071c0d83d7ffb  vmovaps [rsp+0x20], xmm3
000071c0d83d8001  vmovaps [rsp+0x30], xmm4
000071c0d83d8007  vmovaps [rsp+0x40], xmm5
000071c0d83d800d  vmovaps [rsp+0x50], xmm6
000071c0d83d8013  vmovaps [rsp+0x60], xmm7
000071c0d83d8019  vmovaps [rsp+0x70], xmm8
000071c0d83d801f  vmovaps [rsp+0x80], xmm9
000071c0d83d8028  vmovaps [rsp+0x90], xmm10
000071c0d83d8031  vmovaps [rsp+0xA0], xmm11
000071c0d83d803a  vmovaps [rsp+0xB0], xmm12
000071c0d83d8043  vmovaps [rsp+0xC0], xmm13
000071c0d83d804c  vmovaps [rsp+0xD0], xmm14
000071c0d83d8055  vmovaps [rsp+0xE0], xmm15
000071c0d83d805e  sub rsp, 0x30
000071c0d83d8062  movaps [rsp], xmm1
000071c0d83d8066  movaps [rsp+0x10], xmm5
000071c0d83d806b  movaps [rsp+0x20], xmm4
000071c0d83d8070  lea rdi, [rsp]
000071c0d83d8074  mov esi, 0x00
000071c0d83d8079  mov rax, 0x5904ED15D530
000071c0d83d8083  call rax
000071c0d83d8085  movaps xmm1, [rsp]
000071c0d83d8089  add rsp, 0x30
000071c0d83d808d  vmovaps xmm0, [rsp]
000071c0d83d8092  vmovaps xmm2, [rsp+0x10]
000071c0d83d8098  vmovaps xmm3, [rsp+0x20]
000071c0d83d809e  vmovaps xmm4, [rsp+0x30]
000071c0d83d80a4  vmovaps xmm5, [rsp+0x40]
000071c0d83d80aa  vmovaps xmm6, [rsp+0x50]
000071c0d83d80b0  vmovaps xmm7, [rsp+0x60]
000071c0d83d80b6  vmovaps xmm8, [rsp+0x70]
000071c0d83d80bc  vmovaps xmm9, [rsp+0x80]
000071c0d83d80c5  vmovaps xmm10, [rsp+0x90]
000071c0d83d80ce  vmovaps xmm11, [rsp+0xA0]
000071c0d83d80d7  vmovaps xmm12, [rsp+0xB0]
000071c0d83d80e0  vmovaps xmm13, [rsp+0xC0]
000071c0d83d80e9  vmovaps xmm14, [rsp+0xD0]
000071c0d83d80f2  vmovaps xmm15, [rsp+0xE0]
000071c0d83d80fb  add rsp, 0xF0
000071c0d83d8102  pop r11
000071c0d83d8104  pop r10
000071c0d83d8106  pop r9
000071c0d83d8108  pop r8
000071c0d83d810a  pop rsi
000071c0d83d810b  pop rdi
000071c0d83d810c  pop rdx
000071c0d83d810d  pop rcx
000071c0d83d810e  pop rax
000071c0d83d810f  add rsp, 0x08
000071c0d83d8113  jmp 0x000071C0D83D5F06
000071c0d83d8118  sub rsp, 0x08
000071c0d83d811c  push rax
000071c0d83d811d  push rcx
000071c0d83d811e  push rdx
000071c0d83d811f  push rdi
000071c0d83d8120  push rsi
000071c0d83d8121  push r8
000071c0d83d8123  push r9
000071c0d83d8125  push r10
000071c0d83d8127  push r11
000071c0d83d8129  sub rsp, 0xF0
000071c0d83d8130  vmovaps [rsp], xmm0
000071c0d83d8135  vmovaps [rsp+0x10], xmm1
000071c0d83d813b  vmovaps [rsp+0x20], xmm2
000071c0d83d8141  vmovaps [rsp+0x30], xmm3
000071c0d83d8147  vmovaps [rsp+0x40], xmm5
000071c0d83d814d  vmovaps [rsp+0x50], xmm6
000071c0d83d8153  vmovaps [rsp+0x60], xmm7
000071c0d83d8159  vmovaps [rsp+0x70], xmm8
000071c0d83d815f  vmovaps [rsp+0x80], xmm9
000071c0d83d8168  vmovaps [rsp+0x90], xmm10
000071c0d83d8171  vmovaps [rsp+0xA0], xmm11
000071c0d83d817a  vmovaps [rsp+0xB0], xmm12
000071c0d83d8183  vmovaps [rsp+0xC0], xmm13
000071c0d83d818c  vmovaps [rsp+0xD0], xmm14
000071c0d83d8195  vmovaps [rsp+0xE0], xmm15
000071c0d83d819e  sub rsp, 0x30
000071c0d83d81a2  movaps [rsp], xmm4
000071c0d83d81a6  movaps [rsp+0x10], xmm3
000071c0d83d81ab  movaps [rsp+0x20], xmm5
000071c0d83d81b0  lea rdi, [rsp]
000071c0d83d81b4  mov esi, 0x00
000071c0d83d81b9  mov rax, 0x5904ED15D530
000071c0d83d81c3  call rax
000071c0d83d81c5  movaps xmm4, [rsp]
000071c0d83d81c9  add rsp, 0x30
000071c0d83d81cd  vmovaps xmm0, [rsp]
000071c0d83d81d2  vmovaps xmm1, [rsp+0x10]
000071c0d83d81d8  vmovaps xmm2, [rsp+0x20]
000071c0d83d81de  vmovaps xmm3, [rsp+0x30]
000071c0d83d81e4  vmovaps xmm5, [rsp+0x40]
000071c0d83d81ea  vmovaps xmm6, [rsp+0x50]
000071c0d83d81f0  vmovaps xmm7, [rsp+0x60]
000071c0d83d81f6  vmovaps xmm8, [rsp+0x70]
000071c0d83d81fc  vmovaps xmm9, [rsp+0x80]
000071c0d83d8205  vmovaps xmm10, [rsp+0x90]
000071c0d83d820e  vmovaps xmm11, [rsp+0xA0]
000071c0d83d8217  vmovaps xmm12, [rsp+0xB0]
000071c0d83d8220  vmovaps xmm13, [rsp+0xC0]
000071c0d83d8229  vmovaps xmm14, [rsp+0xD0]
000071c0d83d8232  vmovaps xmm15, [rsp+0xE0]
000071c0d83d823b  add rsp, 0xF0
000071c0d83d8242  pop r11
000071c0d83d8244  pop r10
000071c0d83d8246  pop r9
000071c0d83d8248  pop r8
000071c0d83d824a  pop rsi
000071c0d83d824b  pop rdi
000071c0d83d824c  pop rdx
000071c0d83d824d  pop rcx
000071c0d83d824e  pop rax
000071c0d83d824f  add rsp, 0x08
000071c0d83d8253  jmp 0x000071C0D83D5F54
000071c0d83d8258  call 0x000071C0D82D64F0
000071c0d83d825d  jmp 0x000071C0D83D5F61
000071c0d83d8262  sub rsp, 0x08
000071c0d83d8266  push rax
000071c0d83d8267  push rcx
000071c0d83d8268  push rdx
000071c0d83d8269  push rdi
000071c0d83d826a  push rsi
000071c0d83d826b  push r8
000071c0d83d826d  push r9
000071c0d83d826f  push r10
000071c0d83d8271  push r11
000071c0d83d8273  sub rsp, 0xF0
000071c0d83d827a  vmovaps [rsp], xmm0
000071c0d83d827f  vmovaps [rsp+0x10], xmm1
000071c0d83d8285  vmovaps [rsp+0x20], xmm2
000071c0d83d828b  vmovaps [rsp+0x30], xmm3
000071c0d83d8291  vmovaps [rsp+0x40], xmm4
000071c0d83d8297  vmovaps [rsp+0x50], xmm6
000071c0d83d829d  vmovaps [rsp+0x60], xmm7
000071c0d83d82a3  vmovaps [rsp+0x70], xmm8
000071c0d83d82a9  vmovaps [rsp+0x80], xmm9
000071c0d83d82b2  vmovaps [rsp+0x90], xmm10
000071c0d83d82bb  vmovaps [rsp+0xA0], xmm11
000071c0d83d82c4  vmovaps [rsp+0xB0], xmm12
000071c0d83d82cd  vmovaps [rsp+0xC0], xmm13
000071c0d83d82d6  vmovaps [rsp+0xD0], xmm14
000071c0d83d82df  vmovaps [rsp+0xE0], xmm15
000071c0d83d82e8  sub rsp, 0x30
000071c0d83d82ec  movaps [rsp], xmm5
000071c0d83d82f0  movaps [rsp+0x10], xmm6
000071c0d83d82f5  movaps [rsp+0x20], xmm3
000071c0d83d82fa  lea rdi, [rsp]
000071c0d83d82fe  mov esi, 0x00
000071c0d83d8303  mov rax, 0x5904ED15D530
000071c0d83d830d  call rax
000071c0d83d830f  movaps xmm5, [rsp]
000071c0d83d8313  add rsp, 0x30
000071c0d83d8317  vmovaps xmm0, [rsp]
000071c0d83d831c  vmovaps xmm1, [rsp+0x10]
000071c0d83d8322  vmovaps xmm2, [rsp+0x20]
000071c0d83d8328  vmovaps xmm3, [rsp+0x30]
000071c0d83d832e  vmovaps xmm4, [rsp+0x40]
000071c0d83d8334  vmovaps xmm6, [rsp+0x50]
000071c0d83d833a  vmovaps xmm7, [rsp+0x60]
000071c0d83d8340  vmovaps xmm8, [rsp+0x70]
000071c0d83d8346  vmovaps xmm9, [rsp+0x80]
000071c0d83d834f  vmovaps xmm10, [rsp+0x90]
000071c0d83d8358  vmovaps xmm11, [rsp+0xA0]
000071c0d83d8361  vmovaps xmm12, [rsp+0xB0]
000071c0d83d836a  vmovaps xmm13, [rsp+0xC0]
000071c0d83d8373  vmovaps xmm14, [rsp+0xD0]
000071c0d83d837c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d8385  add rsp, 0xF0
000071c0d83d838c  pop r11
000071c0d83d838e  pop r10
000071c0d83d8390  pop r9
000071c0d83d8392  pop r8
000071c0d83d8394  pop rsi
000071c0d83d8395  pop rdi
000071c0d83d8396  pop rdx
000071c0d83d8397  pop rcx
000071c0d83d8398  pop rax
000071c0d83d8399  add rsp, 0x08
000071c0d83d839d  jmp 0x000071C0D83D5F87
000071c0d83d83a2  sub rsp, 0x08
000071c0d83d83a6  push rax
000071c0d83d83a7  push rcx
000071c0d83d83a8  push rdx
000071c0d83d83a9  push rdi
000071c0d83d83aa  push rsi
000071c0d83d83ab  push r8
000071c0d83d83ad  push r9
000071c0d83d83af  push r10
000071c0d83d83b1  push r11
000071c0d83d83b3  sub rsp, 0xF0
000071c0d83d83ba  vmovaps [rsp], xmm0
000071c0d83d83bf  vmovaps [rsp+0x10], xmm1
000071c0d83d83c5  vmovaps [rsp+0x20], xmm2
000071c0d83d83cb  vmovaps [rsp+0x30], xmm3
000071c0d83d83d1  vmovaps [rsp+0x40], xmm4
000071c0d83d83d7  vmovaps [rsp+0x50], xmm5
000071c0d83d83dd  vmovaps [rsp+0x60], xmm7
000071c0d83d83e3  vmovaps [rsp+0x70], xmm8
000071c0d83d83e9  vmovaps [rsp+0x80], xmm9
000071c0d83d83f2  vmovaps [rsp+0x90], xmm10
000071c0d83d83fb  vmovaps [rsp+0xA0], xmm11
000071c0d83d8404  vmovaps [rsp+0xB0], xmm12
000071c0d83d840d  vmovaps [rsp+0xC0], xmm13
000071c0d83d8416  vmovaps [rsp+0xD0], xmm14
000071c0d83d841f  vmovaps [rsp+0xE0], xmm15
000071c0d83d8428  sub rsp, 0x30
000071c0d83d842c  movaps [rsp], xmm6
000071c0d83d8430  movaps [rsp+0x10], xmm9
000071c0d83d8436  movaps [rsp+0x20], xmm1
000071c0d83d843b  lea rdi, [rsp]
000071c0d83d843f  mov esi, 0x00
000071c0d83d8444  mov rax, 0x5904ED15D530
000071c0d83d844e  call rax
000071c0d83d8450  movaps xmm6, [rsp]
000071c0d83d8454  add rsp, 0x30
000071c0d83d8458  vmovaps xmm0, [rsp]
000071c0d83d845d  vmovaps xmm1, [rsp+0x10]
000071c0d83d8463  vmovaps xmm2, [rsp+0x20]
000071c0d83d8469  vmovaps xmm3, [rsp+0x30]
000071c0d83d846f  vmovaps xmm4, [rsp+0x40]
000071c0d83d8475  vmovaps xmm5, [rsp+0x50]
000071c0d83d847b  vmovaps xmm7, [rsp+0x60]
000071c0d83d8481  vmovaps xmm8, [rsp+0x70]
000071c0d83d8487  vmovaps xmm9, [rsp+0x80]
000071c0d83d8490  vmovaps xmm10, [rsp+0x90]
000071c0d83d8499  vmovaps xmm11, [rsp+0xA0]
000071c0d83d84a2  vmovaps xmm12, [rsp+0xB0]
000071c0d83d84ab  vmovaps xmm13, [rsp+0xC0]
000071c0d83d84b4  vmovaps xmm14, [rsp+0xD0]
000071c0d83d84bd  vmovaps xmm15, [rsp+0xE0]
000071c0d83d84c6  add rsp, 0xF0
000071c0d83d84cd  pop r11
000071c0d83d84cf  pop r10
000071c0d83d84d1  pop r9
000071c0d83d84d3  pop r8
000071c0d83d84d5  pop rsi
000071c0d83d84d6  pop rdi
000071c0d83d84d7  pop rdx
000071c0d83d84d8  pop rcx
000071c0d83d84d9  pop rax
000071c0d83d84da  add rsp, 0x08
000071c0d83d84de  jmp 0x000071C0D83D5FAB
000071c0d83d84e3  sub rsp, 0x08
000071c0d83d84e7  push rax
000071c0d83d84e8  push rcx
000071c0d83d84e9  push rdx
000071c0d83d84ea  push rdi
000071c0d83d84eb  push rsi
000071c0d83d84ec  push r8
000071c0d83d84ee  push r9
000071c0d83d84f0  push r10
000071c0d83d84f2  push r11
000071c0d83d84f4  sub rsp, 0xF0
000071c0d83d84fb  vmovaps [rsp], xmm0
000071c0d83d8500  vmovaps [rsp+0x10], xmm1
000071c0d83d8506  vmovaps [rsp+0x20], xmm2
000071c0d83d850c  vmovaps [rsp+0x30], xmm3
000071c0d83d8512  vmovaps [rsp+0x40], xmm4
000071c0d83d8518  vmovaps [rsp+0x50], xmm5
000071c0d83d851e  vmovaps [rsp+0x60], xmm6
000071c0d83d8524  vmovaps [rsp+0x70], xmm7
000071c0d83d852a  vmovaps [rsp+0x80], xmm8
000071c0d83d8533  vmovaps [rsp+0x90], xmm10
000071c0d83d853c  vmovaps [rsp+0xA0], xmm11
000071c0d83d8545  vmovaps [rsp+0xB0], xmm12
000071c0d83d854e  vmovaps [rsp+0xC0], xmm13
000071c0d83d8557  vmovaps [rsp+0xD0], xmm14
000071c0d83d8560  vmovaps [rsp+0xE0], xmm15
000071c0d83d8569  sub rsp, 0x30
000071c0d83d856d  movaps [rsp], xmm9
000071c0d83d8572  movaps [rsp+0x10], xmm3
000071c0d83d8577  movaps [rsp+0x20], xmm1
000071c0d83d857c  lea rdi, [rsp]
000071c0d83d8580  mov esi, 0x00
000071c0d83d8585  mov rax, 0x5904ED15D530
000071c0d83d858f  call rax
000071c0d83d8591  movaps xmm9, [rsp]
000071c0d83d8596  add rsp, 0x30
000071c0d83d859a  vmovaps xmm0, [rsp]
000071c0d83d859f  vmovaps xmm1, [rsp+0x10]
000071c0d83d85a5  vmovaps xmm2, [rsp+0x20]
000071c0d83d85ab  vmovaps xmm3, [rsp+0x30]
000071c0d83d85b1  vmovaps xmm4, [rsp+0x40]
000071c0d83d85b7  vmovaps xmm5, [rsp+0x50]
000071c0d83d85bd  vmovaps xmm6, [rsp+0x60]
000071c0d83d85c3  vmovaps xmm7, [rsp+0x70]
000071c0d83d85c9  vmovaps xmm8, [rsp+0x80]
000071c0d83d85d2  vmovaps xmm10, [rsp+0x90]
000071c0d83d85db  vmovaps xmm11, [rsp+0xA0]
000071c0d83d85e4  vmovaps xmm12, [rsp+0xB0]
000071c0d83d85ed  vmovaps xmm13, [rsp+0xC0]
000071c0d83d85f6  vmovaps xmm14, [rsp+0xD0]
000071c0d83d85ff  vmovaps xmm15, [rsp+0xE0]
000071c0d83d8608  add rsp, 0xF0
000071c0d83d860f  pop r11
000071c0d83d8611  pop r10
000071c0d83d8613  pop r9
000071c0d83d8615  pop r8
000071c0d83d8617  pop rsi
000071c0d83d8618  pop rdi
000071c0d83d8619  pop rdx
000071c0d83d861a  pop rcx
000071c0d83d861b  pop rax
000071c0d83d861c  add rsp, 0x08
000071c0d83d8620  jmp 0x000071C0D83D5FF7
000071c0d83d8625  call 0x000071C0D82D64F0
000071c0d83d862a  jmp 0x000071C0D83D6004
000071c0d83d862f  sub rsp, 0x08
000071c0d83d8633  push rax
000071c0d83d8634  push rcx
000071c0d83d8635  push rdx
000071c0d83d8636  push rdi
000071c0d83d8637  push rsi
000071c0d83d8638  push r8
000071c0d83d863a  push r9
000071c0d83d863c  push r10
000071c0d83d863e  push r11
000071c0d83d8640  sub rsp, 0xF0
000071c0d83d8647  vmovaps [rsp], xmm0
000071c0d83d864c  vmovaps [rsp+0x10], xmm1
000071c0d83d8652  vmovaps [rsp+0x20], xmm2
000071c0d83d8658  vmovaps [rsp+0x30], xmm3
000071c0d83d865e  vmovaps [rsp+0x40], xmm4
000071c0d83d8664  vmovaps [rsp+0x50], xmm5
000071c0d83d866a  vmovaps [rsp+0x60], xmm6
000071c0d83d8670  vmovaps [rsp+0x70], xmm7
000071c0d83d8676  vmovaps [rsp+0x80], xmm8
000071c0d83d867f  vmovaps [rsp+0x90], xmm9
000071c0d83d8688  vmovaps [rsp+0xA0], xmm10
000071c0d83d8691  vmovaps [rsp+0xB0], xmm11
000071c0d83d869a  vmovaps [rsp+0xC0], xmm12
000071c0d83d86a3  vmovaps [rsp+0xD0], xmm13
000071c0d83d86ac  vmovaps [rsp+0xE0], xmm14
000071c0d83d86b5  sub rsp, 0x30
000071c0d83d86b9  movaps [rsp], xmm15
000071c0d83d86be  movaps [rsp+0x10], xmm3
000071c0d83d86c3  movaps [rsp+0x20], xmm7
000071c0d83d86c8  lea rdi, [rsp]
000071c0d83d86cc  mov esi, 0x00
000071c0d83d86d1  mov rax, 0x5904ED15D530
000071c0d83d86db  call rax
000071c0d83d86dd  movaps xmm15, [rsp]
000071c0d83d86e2  add rsp, 0x30
000071c0d83d86e6  vmovaps xmm0, [rsp]
000071c0d83d86eb  vmovaps xmm1, [rsp+0x10]
000071c0d83d86f1  vmovaps xmm2, [rsp+0x20]
000071c0d83d86f7  vmovaps xmm3, [rsp+0x30]
000071c0d83d86fd  vmovaps xmm4, [rsp+0x40]
000071c0d83d8703  vmovaps xmm5, [rsp+0x50]
000071c0d83d8709  vmovaps xmm6, [rsp+0x60]
000071c0d83d870f  vmovaps xmm7, [rsp+0x70]
000071c0d83d8715  vmovaps xmm8, [rsp+0x80]
000071c0d83d871e  vmovaps xmm9, [rsp+0x90]
000071c0d83d8727  vmovaps xmm10, [rsp+0xA0]
000071c0d83d8730  vmovaps xmm11, [rsp+0xB0]
000071c0d83d8739  vmovaps xmm12, [rsp+0xC0]
000071c0d83d8742  vmovaps xmm13, [rsp+0xD0]
000071c0d83d874b  vmovaps xmm14, [rsp+0xE0]
000071c0d83d8754  add rsp, 0xF0
000071c0d83d875b  pop r11
000071c0d83d875d  pop r10
000071c0d83d875f  pop r9
000071c0d83d8761  pop r8
000071c0d83d8763  pop rsi
000071c0d83d8764  pop rdi
000071c0d83d8765  pop rdx
000071c0d83d8766  pop rcx
000071c0d83d8767  pop rax
000071c0d83d8768  add rsp, 0x08
000071c0d83d876c  jmp 0x000071C0D83D6030
000071c0d83d8771  sub rsp, 0x08
000071c0d83d8775  push rax
000071c0d83d8776  push rcx
000071c0d83d8777  push rdx
000071c0d83d8778  push rdi
000071c0d83d8779  push rsi
000071c0d83d877a  push r8
000071c0d83d877c  push r9
000071c0d83d877e  push r10
000071c0d83d8780  push r11
000071c0d83d8782  sub rsp, 0xF0
000071c0d83d8789  vmovaps [rsp], xmm0
000071c0d83d878e  vmovaps [rsp+0x10], xmm1
000071c0d83d8794  vmovaps [rsp+0x20], xmm2
000071c0d83d879a  vmovaps [rsp+0x30], xmm4
000071c0d83d87a0  vmovaps [rsp+0x40], xmm5
000071c0d83d87a6  vmovaps [rsp+0x50], xmm6
000071c0d83d87ac  vmovaps [rsp+0x60], xmm7
000071c0d83d87b2  vmovaps [rsp+0x70], xmm8
000071c0d83d87b8  vmovaps [rsp+0x80], xmm9
000071c0d83d87c1  vmovaps [rsp+0x90], xmm10
000071c0d83d87ca  vmovaps [rsp+0xA0], xmm11
000071c0d83d87d3  vmovaps [rsp+0xB0], xmm12
000071c0d83d87dc  vmovaps [rsp+0xC0], xmm13
000071c0d83d87e5  vmovaps [rsp+0xD0], xmm14
000071c0d83d87ee  vmovaps [rsp+0xE0], xmm15
000071c0d83d87f7  sub rsp, 0x30
000071c0d83d87fb  movaps [rsp], xmm3
000071c0d83d87ff  movaps [rsp+0x10], xmm1
000071c0d83d8804  movaps [rsp+0x20], xmm15
000071c0d83d880a  lea rdi, [rsp]
000071c0d83d880e  mov esi, 0x00
000071c0d83d8813  mov rax, 0x5904ED15D530
000071c0d83d881d  call rax
000071c0d83d881f  movaps xmm3, [rsp]
000071c0d83d8823  add rsp, 0x30
000071c0d83d8827  vmovaps xmm0, [rsp]
000071c0d83d882c  vmovaps xmm1, [rsp+0x10]
000071c0d83d8832  vmovaps xmm2, [rsp+0x20]
000071c0d83d8838  vmovaps xmm4, [rsp+0x30]
000071c0d83d883e  vmovaps xmm5, [rsp+0x40]
000071c0d83d8844  vmovaps xmm6, [rsp+0x50]
000071c0d83d884a  vmovaps xmm7, [rsp+0x60]
000071c0d83d8850  vmovaps xmm8, [rsp+0x70]
000071c0d83d8856  vmovaps xmm9, [rsp+0x80]
000071c0d83d885f  vmovaps xmm10, [rsp+0x90]
000071c0d83d8868  vmovaps xmm11, [rsp+0xA0]
000071c0d83d8871  vmovaps xmm12, [rsp+0xB0]
000071c0d83d887a  vmovaps xmm13, [rsp+0xC0]
000071c0d83d8883  vmovaps xmm14, [rsp+0xD0]
000071c0d83d888c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d8895  add rsp, 0xF0
000071c0d83d889c  pop r11
000071c0d83d889e  pop r10
000071c0d83d88a0  pop r9
000071c0d83d88a2  pop r8
000071c0d83d88a4  pop rsi
000071c0d83d88a5  pop rdi
000071c0d83d88a6  pop rdx
000071c0d83d88a7  pop rcx
000071c0d83d88a8  pop rax
000071c0d83d88a9  add rsp, 0x08
000071c0d83d88ad  jmp 0x000071C0D83D60BF
000071c0d83d88b2  call 0x000071C0D82D64F0
000071c0d83d88b7  jmp 0x000071C0D83D60C9
000071c0d83d88bc  sub rsp, 0x08
000071c0d83d88c0  push rax
000071c0d83d88c1  push rcx
000071c0d83d88c2  push rdx
000071c0d83d88c3  push rdi
000071c0d83d88c4  push rsi
000071c0d83d88c5  push r8
000071c0d83d88c7  push r9
000071c0d83d88c9  push r10
000071c0d83d88cb  push r11
000071c0d83d88cd  sub rsp, 0xF0
000071c0d83d88d4  vmovaps [rsp], xmm0
000071c0d83d88d9  vmovaps [rsp+0x10], xmm1
000071c0d83d88df  vmovaps [rsp+0x20], xmm2
000071c0d83d88e5  vmovaps [rsp+0x30], xmm3
000071c0d83d88eb  vmovaps [rsp+0x40], xmm4
000071c0d83d88f1  vmovaps [rsp+0x50], xmm5
000071c0d83d88f7  vmovaps [rsp+0x60], xmm6
000071c0d83d88fd  vmovaps [rsp+0x70], xmm7
000071c0d83d8903  vmovaps [rsp+0x80], xmm8
000071c0d83d890c  vmovaps [rsp+0x90], xmm9
000071c0d83d8915  vmovaps [rsp+0xA0], xmm10
000071c0d83d891e  vmovaps [rsp+0xB0], xmm11
000071c0d83d8927  vmovaps [rsp+0xC0], xmm12
000071c0d83d8930  vmovaps [rsp+0xD0], xmm13
000071c0d83d8939  vmovaps [rsp+0xE0], xmm14
000071c0d83d8942  sub rsp, 0x30
000071c0d83d8946  movaps [rsp], xmm15
000071c0d83d894b  movaps [rsp+0x10], xmm14
000071c0d83d8951  movaps [rsp+0x20], xmm4
000071c0d83d8956  lea rdi, [rsp]
000071c0d83d895a  mov esi, 0x00
000071c0d83d895f  mov rax, 0x5904ED15D530
000071c0d83d8969  call rax
000071c0d83d896b  movaps xmm15, [rsp]
000071c0d83d8970  add rsp, 0x30
000071c0d83d8974  vmovaps xmm0, [rsp]
000071c0d83d8979  vmovaps xmm1, [rsp+0x10]
000071c0d83d897f  vmovaps xmm2, [rsp+0x20]
000071c0d83d8985  vmovaps xmm3, [rsp+0x30]
000071c0d83d898b  vmovaps xmm4, [rsp+0x40]
000071c0d83d8991  vmovaps xmm5, [rsp+0x50]
000071c0d83d8997  vmovaps xmm6, [rsp+0x60]
000071c0d83d899d  vmovaps xmm7, [rsp+0x70]
000071c0d83d89a3  vmovaps xmm8, [rsp+0x80]
000071c0d83d89ac  vmovaps xmm9, [rsp+0x90]
000071c0d83d89b5  vmovaps xmm10, [rsp+0xA0]
000071c0d83d89be  vmovaps xmm11, [rsp+0xB0]
000071c0d83d89c7  vmovaps xmm12, [rsp+0xC0]
000071c0d83d89d0  vmovaps xmm13, [rsp+0xD0]
000071c0d83d89d9  vmovaps xmm14, [rsp+0xE0]
000071c0d83d89e2  add rsp, 0xF0
000071c0d83d89e9  pop r11
000071c0d83d89eb  pop r10
000071c0d83d89ed  pop r9
000071c0d83d89ef  pop r8
000071c0d83d89f1  pop rsi
000071c0d83d89f2  pop rdi
000071c0d83d89f3  pop rdx
000071c0d83d89f4  pop rcx
000071c0d83d89f5  pop rax
000071c0d83d89f6  add rsp, 0x08
000071c0d83d89fa  jmp 0x000071C0D83D60F7
000071c0d83d89ff  sub rsp, 0x08
000071c0d83d8a03  push rax
000071c0d83d8a04  push rcx
000071c0d83d8a05  push rdx
000071c0d83d8a06  push rdi
000071c0d83d8a07  push rsi
000071c0d83d8a08  push r8
000071c0d83d8a0a  push r9
000071c0d83d8a0c  push r10
000071c0d83d8a0e  push r11
000071c0d83d8a10  sub rsp, 0xF0
000071c0d83d8a17  vmovaps [rsp], xmm0
000071c0d83d8a1c  vmovaps [rsp+0x10], xmm1
000071c0d83d8a22  vmovaps [rsp+0x20], xmm2
000071c0d83d8a28  vmovaps [rsp+0x30], xmm3
000071c0d83d8a2e  vmovaps [rsp+0x40], xmm4
000071c0d83d8a34  vmovaps [rsp+0x50], xmm5
000071c0d83d8a3a  vmovaps [rsp+0x60], xmm6
000071c0d83d8a40  vmovaps [rsp+0x70], xmm7
000071c0d83d8a46  vmovaps [rsp+0x80], xmm8
000071c0d83d8a4f  vmovaps [rsp+0x90], xmm9
000071c0d83d8a58  vmovaps [rsp+0xA0], xmm10
000071c0d83d8a61  vmovaps [rsp+0xB0], xmm11
000071c0d83d8a6a  vmovaps [rsp+0xC0], xmm12
000071c0d83d8a73  vmovaps [rsp+0xD0], xmm13
000071c0d83d8a7c  vmovaps [rsp+0xE0], xmm15
000071c0d83d8a85  sub rsp, 0x30
000071c0d83d8a89  movaps [rsp], xmm14
000071c0d83d8a8e  movaps [rsp+0x10], xmm2
000071c0d83d8a93  movaps [rsp+0x20], xmm1
000071c0d83d8a98  lea rdi, [rsp]
000071c0d83d8a9c  mov esi, 0x00
000071c0d83d8aa1  mov rax, 0x5904ED15D530
000071c0d83d8aab  call rax
000071c0d83d8aad  movaps xmm14, [rsp]
000071c0d83d8ab2  add rsp, 0x30
000071c0d83d8ab6  vmovaps xmm0, [rsp]
000071c0d83d8abb  vmovaps xmm1, [rsp+0x10]
000071c0d83d8ac1  vmovaps xmm2, [rsp+0x20]
000071c0d83d8ac7  vmovaps xmm3, [rsp+0x30]
000071c0d83d8acd  vmovaps xmm4, [rsp+0x40]
000071c0d83d8ad3  vmovaps xmm5, [rsp+0x50]
000071c0d83d8ad9  vmovaps xmm6, [rsp+0x60]
000071c0d83d8adf  vmovaps xmm7, [rsp+0x70]
000071c0d83d8ae5  vmovaps xmm8, [rsp+0x80]
000071c0d83d8aee  vmovaps xmm9, [rsp+0x90]
000071c0d83d8af7  vmovaps xmm10, [rsp+0xA0]
000071c0d83d8b00  vmovaps xmm11, [rsp+0xB0]
000071c0d83d8b09  vmovaps xmm12, [rsp+0xC0]
000071c0d83d8b12  vmovaps xmm13, [rsp+0xD0]
000071c0d83d8b1b  vmovaps xmm15, [rsp+0xE0]
000071c0d83d8b24  add rsp, 0xF0
000071c0d83d8b2b  pop r11
000071c0d83d8b2d  pop r10
000071c0d83d8b2f  pop r9
000071c0d83d8b31  pop r8
000071c0d83d8b33  pop rsi
000071c0d83d8b34  pop rdi
000071c0d83d8b35  pop rdx
000071c0d83d8b36  pop rcx
000071c0d83d8b37  pop rax
000071c0d83d8b38  add rsp, 0x08
000071c0d83d8b3c  jmp 0x000071C0D83D611D
000071c0d83d8b41  sub rsp, 0x08
000071c0d83d8b45  push rax
000071c0d83d8b46  push rcx
000071c0d83d8b47  push rdx
000071c0d83d8b48  push rdi
000071c0d83d8b49  push rsi
000071c0d83d8b4a  push r8
000071c0d83d8b4c  push r9
000071c0d83d8b4e  push r10
000071c0d83d8b50  push r11
000071c0d83d8b52  sub rsp, 0xF0
000071c0d83d8b59  vmovaps [rsp], xmm0
000071c0d83d8b5e  vmovaps [rsp+0x10], xmm2
000071c0d83d8b64  vmovaps [rsp+0x20], xmm3
000071c0d83d8b6a  vmovaps [rsp+0x30], xmm4
000071c0d83d8b70  vmovaps [rsp+0x40], xmm5
000071c0d83d8b76  vmovaps [rsp+0x50], xmm6
000071c0d83d8b7c  vmovaps [rsp+0x60], xmm7
000071c0d83d8b82  vmovaps [rsp+0x70], xmm8
000071c0d83d8b88  vmovaps [rsp+0x80], xmm9
000071c0d83d8b91  vmovaps [rsp+0x90], xmm10
000071c0d83d8b9a  vmovaps [rsp+0xA0], xmm11
000071c0d83d8ba3  vmovaps [rsp+0xB0], xmm12
000071c0d83d8bac  vmovaps [rsp+0xC0], xmm13
000071c0d83d8bb5  vmovaps [rsp+0xD0], xmm14
000071c0d83d8bbe  vmovaps [rsp+0xE0], xmm15
000071c0d83d8bc7  sub rsp, 0x30
000071c0d83d8bcb  movaps [rsp], xmm1
000071c0d83d8bcf  movaps [rsp+0x10], xmm4
000071c0d83d8bd4  movaps [rsp+0x20], xmm9
000071c0d83d8bda  lea rdi, [rsp]
000071c0d83d8bde  mov esi, 0x00
000071c0d83d8be3  mov rax, 0x5904ED15D530
000071c0d83d8bed  call rax
000071c0d83d8bef  movaps xmm1, [rsp]
000071c0d83d8bf3  add rsp, 0x30
000071c0d83d8bf7  vmovaps xmm0, [rsp]
000071c0d83d8bfc  vmovaps xmm2, [rsp+0x10]
000071c0d83d8c02  vmovaps xmm3, [rsp+0x20]
000071c0d83d8c08  vmovaps xmm4, [rsp+0x30]
000071c0d83d8c0e  vmovaps xmm5, [rsp+0x40]
000071c0d83d8c14  vmovaps xmm6, [rsp+0x50]
000071c0d83d8c1a  vmovaps xmm7, [rsp+0x60]
000071c0d83d8c20  vmovaps xmm8, [rsp+0x70]
000071c0d83d8c26  vmovaps xmm9, [rsp+0x80]
000071c0d83d8c2f  vmovaps xmm10, [rsp+0x90]
000071c0d83d8c38  vmovaps xmm11, [rsp+0xA0]
000071c0d83d8c41  vmovaps xmm12, [rsp+0xB0]
000071c0d83d8c4a  vmovaps xmm13, [rsp+0xC0]
000071c0d83d8c53  vmovaps xmm14, [rsp+0xD0]
000071c0d83d8c5c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d8c65  add rsp, 0xF0
000071c0d83d8c6c  pop r11
000071c0d83d8c6e  pop r10
000071c0d83d8c70  pop r9
000071c0d83d8c72  pop r8
000071c0d83d8c74  pop rsi
000071c0d83d8c75  pop rdi
000071c0d83d8c76  pop rdx
000071c0d83d8c77  pop rcx
000071c0d83d8c78  pop rax
000071c0d83d8c79  add rsp, 0x08
000071c0d83d8c7d  jmp 0x000071C0D83D613B
000071c0d83d8c82  sub rsp, 0x08
000071c0d83d8c86  push rax
000071c0d83d8c87  push rcx
000071c0d83d8c88  push rdx
000071c0d83d8c89  push rdi
000071c0d83d8c8a  push rsi
000071c0d83d8c8b  push r8
000071c0d83d8c8d  push r9
000071c0d83d8c8f  push r10
000071c0d83d8c91  push r11
000071c0d83d8c93  sub rsp, 0xF0
000071c0d83d8c9a  vmovaps [rsp], xmm0
000071c0d83d8c9f  vmovaps [rsp+0x10], xmm1
000071c0d83d8ca5  vmovaps [rsp+0x20], xmm2
000071c0d83d8cab  vmovaps [rsp+0x30], xmm3
000071c0d83d8cb1  vmovaps [rsp+0x40], xmm5
000071c0d83d8cb7  vmovaps [rsp+0x50], xmm6
000071c0d83d8cbd  vmovaps [rsp+0x60], xmm7
000071c0d83d8cc3  vmovaps [rsp+0x70], xmm8
000071c0d83d8cc9  vmovaps [rsp+0x80], xmm9
000071c0d83d8cd2  vmovaps [rsp+0x90], xmm10
000071c0d83d8cdb  vmovaps [rsp+0xA0], xmm11
000071c0d83d8ce4  vmovaps [rsp+0xB0], xmm12
000071c0d83d8ced  vmovaps [rsp+0xC0], xmm13
000071c0d83d8cf6  vmovaps [rsp+0xD0], xmm14
000071c0d83d8cff  vmovaps [rsp+0xE0], xmm15
000071c0d83d8d08  sub rsp, 0x30
000071c0d83d8d0c  movaps [rsp], xmm4
000071c0d83d8d10  movaps [rsp+0x10], xmm2
000071c0d83d8d15  movaps [rsp+0x20], xmm9
000071c0d83d8d1b  lea rdi, [rsp]
000071c0d83d8d1f  mov esi, 0x00
000071c0d83d8d24  mov rax, 0x5904ED15D530
000071c0d83d8d2e  call rax
000071c0d83d8d30  movaps xmm4, [rsp]
000071c0d83d8d34  add rsp, 0x30
000071c0d83d8d38  vmovaps xmm0, [rsp]
000071c0d83d8d3d  vmovaps xmm1, [rsp+0x10]
000071c0d83d8d43  vmovaps xmm2, [rsp+0x20]
000071c0d83d8d49  vmovaps xmm3, [rsp+0x30]
000071c0d83d8d4f  vmovaps xmm5, [rsp+0x40]
000071c0d83d8d55  vmovaps xmm6, [rsp+0x50]
000071c0d83d8d5b  vmovaps xmm7, [rsp+0x60]
000071c0d83d8d61  vmovaps xmm8, [rsp+0x70]
000071c0d83d8d67  vmovaps xmm9, [rsp+0x80]
000071c0d83d8d70  vmovaps xmm10, [rsp+0x90]
000071c0d83d8d79  vmovaps xmm11, [rsp+0xA0]
000071c0d83d8d82  vmovaps xmm12, [rsp+0xB0]
000071c0d83d8d8b  vmovaps xmm13, [rsp+0xC0]
000071c0d83d8d94  vmovaps xmm14, [rsp+0xD0]
000071c0d83d8d9d  vmovaps xmm15, [rsp+0xE0]
000071c0d83d8da6  add rsp, 0xF0
000071c0d83d8dad  pop r11
000071c0d83d8daf  pop r10
000071c0d83d8db1  pop r9
000071c0d83d8db3  pop r8
000071c0d83d8db5  pop rsi
000071c0d83d8db6  pop rdi
000071c0d83d8db7  pop rdx
000071c0d83d8db8  pop rcx
000071c0d83d8db9  pop rax
000071c0d83d8dba  add rsp, 0x08
000071c0d83d8dbe  jmp 0x000071C0D83D616B
000071c0d83d8dc3  sub rsp, 0x08
000071c0d83d8dc7  push rax
000071c0d83d8dc8  push rcx
000071c0d83d8dc9  push rdx
000071c0d83d8dca  push rdi
000071c0d83d8dcb  push rsi
000071c0d83d8dcc  push r8
000071c0d83d8dce  push r9
000071c0d83d8dd0  push r10
000071c0d83d8dd2  push r11
000071c0d83d8dd4  sub rsp, 0xF0
000071c0d83d8ddb  vmovaps [rsp], xmm0
000071c0d83d8de0  vmovaps [rsp+0x10], xmm1
000071c0d83d8de6  vmovaps [rsp+0x20], xmm2
000071c0d83d8dec  vmovaps [rsp+0x30], xmm3
000071c0d83d8df2  vmovaps [rsp+0x40], xmm4
000071c0d83d8df8  vmovaps [rsp+0x50], xmm5
000071c0d83d8dfe  vmovaps [rsp+0x60], xmm6
000071c0d83d8e04  vmovaps [rsp+0x70], xmm7
000071c0d83d8e0a  vmovaps [rsp+0x80], xmm8
000071c0d83d8e13  vmovaps [rsp+0x90], xmm10
000071c0d83d8e1c  vmovaps [rsp+0xA0], xmm11
000071c0d83d8e25  vmovaps [rsp+0xB0], xmm12
000071c0d83d8e2e  vmovaps [rsp+0xC0], xmm13
000071c0d83d8e37  vmovaps [rsp+0xD0], xmm14
000071c0d83d8e40  vmovaps [rsp+0xE0], xmm15
000071c0d83d8e49  sub rsp, 0x30
000071c0d83d8e4d  movaps [rsp], xmm9
000071c0d83d8e52  movaps [rsp+0x10], xmm2
000071c0d83d8e57  movaps [rsp+0x20], xmm1
000071c0d83d8e5c  lea rdi, [rsp]
000071c0d83d8e60  mov esi, 0x00
000071c0d83d8e65  mov rax, 0x5904ED15D530
000071c0d83d8e6f  call rax
000071c0d83d8e71  movaps xmm9, [rsp]
000071c0d83d8e76  add rsp, 0x30
000071c0d83d8e7a  vmovaps xmm0, [rsp]
000071c0d83d8e7f  vmovaps xmm1, [rsp+0x10]
000071c0d83d8e85  vmovaps xmm2, [rsp+0x20]
000071c0d83d8e8b  vmovaps xmm3, [rsp+0x30]
000071c0d83d8e91  vmovaps xmm4, [rsp+0x40]
000071c0d83d8e97  vmovaps xmm5, [rsp+0x50]
000071c0d83d8e9d  vmovaps xmm6, [rsp+0x60]
000071c0d83d8ea3  vmovaps xmm7, [rsp+0x70]
000071c0d83d8ea9  vmovaps xmm8, [rsp+0x80]
000071c0d83d8eb2  vmovaps xmm10, [rsp+0x90]
000071c0d83d8ebb  vmovaps xmm11, [rsp+0xA0]
000071c0d83d8ec4  vmovaps xmm12, [rsp+0xB0]
000071c0d83d8ecd  vmovaps xmm13, [rsp+0xC0]
000071c0d83d8ed6  vmovaps xmm14, [rsp+0xD0]
000071c0d83d8edf  vmovaps xmm15, [rsp+0xE0]
000071c0d83d8ee8  add rsp, 0xF0
000071c0d83d8eef  pop r11
000071c0d83d8ef1  pop r10
000071c0d83d8ef3  pop r9
000071c0d83d8ef5  pop r8
000071c0d83d8ef7  pop rsi
000071c0d83d8ef8  pop rdi
000071c0d83d8ef9  pop rdx
000071c0d83d8efa  pop rcx
000071c0d83d8efb  pop rax
000071c0d83d8efc  add rsp, 0x08
000071c0d83d8f00  jmp 0x000071C0D83D61A1
000071c0d83d8f05  sub rsp, 0x08
000071c0d83d8f09  push rax
000071c0d83d8f0a  push rcx
000071c0d83d8f0b  push rdx
000071c0d83d8f0c  push rdi
000071c0d83d8f0d  push rsi
000071c0d83d8f0e  push r8
000071c0d83d8f10  push r9
000071c0d83d8f12  push r10
000071c0d83d8f14  push r11
000071c0d83d8f16  sub rsp, 0xF0
000071c0d83d8f1d  vmovaps [rsp], xmm0
000071c0d83d8f22  vmovaps [rsp+0x10], xmm2
000071c0d83d8f28  vmovaps [rsp+0x20], xmm3
000071c0d83d8f2e  vmovaps [rsp+0x30], xmm4
000071c0d83d8f34  vmovaps [rsp+0x40], xmm5
000071c0d83d8f3a  vmovaps [rsp+0x50], xmm6
000071c0d83d8f40  vmovaps [rsp+0x60], xmm7
000071c0d83d8f46  vmovaps [rsp+0x70], xmm8
000071c0d83d8f4c  vmovaps [rsp+0x80], xmm9
000071c0d83d8f55  vmovaps [rsp+0x90], xmm10
000071c0d83d8f5e  vmovaps [rsp+0xA0], xmm11
000071c0d83d8f67  vmovaps [rsp+0xB0], xmm12
000071c0d83d8f70  vmovaps [rsp+0xC0], xmm13
000071c0d83d8f79  vmovaps [rsp+0xD0], xmm14
000071c0d83d8f82  vmovaps [rsp+0xE0], xmm15
000071c0d83d8f8b  sub rsp, 0x30
000071c0d83d8f8f  movaps [rsp], xmm1
000071c0d83d8f93  movaps [rsp+0x10], xmm15
000071c0d83d8f99  movaps [rsp+0x20], xmm6
000071c0d83d8f9e  lea rdi, [rsp]
000071c0d83d8fa2  mov esi, 0x00
000071c0d83d8fa7  mov rax, 0x5904ED15D530
000071c0d83d8fb1  call rax
000071c0d83d8fb3  movaps xmm1, [rsp]
000071c0d83d8fb7  add rsp, 0x30
000071c0d83d8fbb  vmovaps xmm0, [rsp]
000071c0d83d8fc0  vmovaps xmm2, [rsp+0x10]
000071c0d83d8fc6  vmovaps xmm3, [rsp+0x20]
000071c0d83d8fcc  vmovaps xmm4, [rsp+0x30]
000071c0d83d8fd2  vmovaps xmm5, [rsp+0x40]
000071c0d83d8fd8  vmovaps xmm6, [rsp+0x50]
000071c0d83d8fde  vmovaps xmm7, [rsp+0x60]
000071c0d83d8fe4  vmovaps xmm8, [rsp+0x70]
000071c0d83d8fea  vmovaps xmm9, [rsp+0x80]
000071c0d83d8ff3  vmovaps xmm10, [rsp+0x90]
000071c0d83d8ffc  vmovaps xmm11, [rsp+0xA0]
000071c0d83d9005  vmovaps xmm12, [rsp+0xB0]
000071c0d83d900e  vmovaps xmm13, [rsp+0xC0]
000071c0d83d9017  vmovaps xmm14, [rsp+0xD0]
000071c0d83d9020  vmovaps xmm15, [rsp+0xE0]
000071c0d83d9029  add rsp, 0xF0
000071c0d83d9030  pop r11
000071c0d83d9032  pop r10
000071c0d83d9034  pop r9
000071c0d83d9036  pop r8
000071c0d83d9038  pop rsi
000071c0d83d9039  pop rdi
000071c0d83d903a  pop rdx
000071c0d83d903b  pop rcx
000071c0d83d903c  pop rax
000071c0d83d903d  add rsp, 0x08
000071c0d83d9041  jmp 0x000071C0D83D61C2
000071c0d83d9046  sub rsp, 0x08
000071c0d83d904a  push rax
000071c0d83d904b  push rcx
000071c0d83d904c  push rdx
000071c0d83d904d  push rdi
000071c0d83d904e  push rsi
000071c0d83d904f  push r8
000071c0d83d9051  push r9
000071c0d83d9053  push r10
000071c0d83d9055  push r11
000071c0d83d9057  sub rsp, 0xF0
000071c0d83d905e  vmovaps [rsp], xmm0
000071c0d83d9063  vmovaps [rsp+0x10], xmm1
000071c0d83d9069  vmovaps [rsp+0x20], xmm2
000071c0d83d906f  vmovaps [rsp+0x30], xmm3
000071c0d83d9075  vmovaps [rsp+0x40], xmm4
000071c0d83d907b  vmovaps [rsp+0x50], xmm5
000071c0d83d9081  vmovaps [rsp+0x60], xmm6
000071c0d83d9087  vmovaps [rsp+0x70], xmm7
000071c0d83d908d  vmovaps [rsp+0x80], xmm8
000071c0d83d9096  vmovaps [rsp+0x90], xmm9
000071c0d83d909f  vmovaps [rsp+0xA0], xmm10
000071c0d83d90a8  vmovaps [rsp+0xB0], xmm11
000071c0d83d90b1  vmovaps [rsp+0xC0], xmm12
000071c0d83d90ba  vmovaps [rsp+0xD0], xmm13
000071c0d83d90c3  vmovaps [rsp+0xE0], xmm14
000071c0d83d90cc  sub rsp, 0x30
000071c0d83d90d0  movaps [rsp], xmm15
000071c0d83d90d5  movaps [rsp+0x10], xmm5
000071c0d83d90da  movaps [rsp+0x20], xmm3
000071c0d83d90df  lea rdi, [rsp]
000071c0d83d90e3  mov esi, 0x00
000071c0d83d90e8  mov rax, 0x5904ED15D530
000071c0d83d90f2  call rax
000071c0d83d90f4  movaps xmm15, [rsp]
000071c0d83d90f9  add rsp, 0x30
000071c0d83d90fd  vmovaps xmm0, [rsp]
000071c0d83d9102  vmovaps xmm1, [rsp+0x10]
000071c0d83d9108  vmovaps xmm2, [rsp+0x20]
000071c0d83d910e  vmovaps xmm3, [rsp+0x30]
000071c0d83d9114  vmovaps xmm4, [rsp+0x40]
000071c0d83d911a  vmovaps xmm5, [rsp+0x50]
000071c0d83d9120  vmovaps xmm6, [rsp+0x60]
000071c0d83d9126  vmovaps xmm7, [rsp+0x70]
000071c0d83d912c  vmovaps xmm8, [rsp+0x80]
000071c0d83d9135  vmovaps xmm9, [rsp+0x90]
000071c0d83d913e  vmovaps xmm10, [rsp+0xA0]
000071c0d83d9147  vmovaps xmm11, [rsp+0xB0]
000071c0d83d9150  vmovaps xmm12, [rsp+0xC0]
000071c0d83d9159  vmovaps xmm13, [rsp+0xD0]
000071c0d83d9162  vmovaps xmm14, [rsp+0xE0]
000071c0d83d916b  add rsp, 0xF0
000071c0d83d9172  pop r11
000071c0d83d9174  pop r10
000071c0d83d9176  pop r9
000071c0d83d9178  pop r8
000071c0d83d917a  pop rsi
000071c0d83d917b  pop rdi
000071c0d83d917c  pop rdx
000071c0d83d917d  pop rcx
000071c0d83d917e  pop rax
000071c0d83d917f  add rsp, 0x08
000071c0d83d9183  jmp 0x000071C0D83D61DC
000071c0d83d9188  sub rsp, 0x08
000071c0d83d918c  push rax
000071c0d83d918d  push rcx
000071c0d83d918e  push rdx
000071c0d83d918f  push rdi
000071c0d83d9190  push rsi
000071c0d83d9191  push r8
000071c0d83d9193  push r9
000071c0d83d9195  push r10
000071c0d83d9197  push r11
000071c0d83d9199  sub rsp, 0xF0
000071c0d83d91a0  vmovaps [rsp], xmm0
000071c0d83d91a5  vmovaps [rsp+0x10], xmm1
000071c0d83d91ab  vmovaps [rsp+0x20], xmm2
000071c0d83d91b1  vmovaps [rsp+0x30], xmm3
000071c0d83d91b7  vmovaps [rsp+0x40], xmm4
000071c0d83d91bd  vmovaps [rsp+0x50], xmm6
000071c0d83d91c3  vmovaps [rsp+0x60], xmm7
000071c0d83d91c9  vmovaps [rsp+0x70], xmm8
000071c0d83d91cf  vmovaps [rsp+0x80], xmm9
000071c0d83d91d8  vmovaps [rsp+0x90], xmm10
000071c0d83d91e1  vmovaps [rsp+0xA0], xmm11
000071c0d83d91ea  vmovaps [rsp+0xB0], xmm12
000071c0d83d91f3  vmovaps [rsp+0xC0], xmm13
000071c0d83d91fc  vmovaps [rsp+0xD0], xmm14
000071c0d83d9205  vmovaps [rsp+0xE0], xmm15
000071c0d83d920e  sub rsp, 0x30
000071c0d83d9212  movaps [rsp], xmm5
000071c0d83d9216  movaps [rsp+0x10], xmm8
000071c0d83d921c  movaps [rsp+0x20], xmm6
000071c0d83d9221  lea rdi, [rsp]
000071c0d83d9225  mov esi, 0x00
000071c0d83d922a  mov rax, 0x5904ED15D530
000071c0d83d9234  call rax
000071c0d83d9236  movaps xmm5, [rsp]
000071c0d83d923a  add rsp, 0x30
000071c0d83d923e  vmovaps xmm0, [rsp]
000071c0d83d9243  vmovaps xmm1, [rsp+0x10]
000071c0d83d9249  vmovaps xmm2, [rsp+0x20]
000071c0d83d924f  vmovaps xmm3, [rsp+0x30]
000071c0d83d9255  vmovaps xmm4, [rsp+0x40]
000071c0d83d925b  vmovaps xmm6, [rsp+0x50]
000071c0d83d9261  vmovaps xmm7, [rsp+0x60]
000071c0d83d9267  vmovaps xmm8, [rsp+0x70]
000071c0d83d926d  vmovaps xmm9, [rsp+0x80]
000071c0d83d9276  vmovaps xmm10, [rsp+0x90]
000071c0d83d927f  vmovaps xmm11, [rsp+0xA0]
000071c0d83d9288  vmovaps xmm12, [rsp+0xB0]
000071c0d83d9291  vmovaps xmm13, [rsp+0xC0]
000071c0d83d929a  vmovaps xmm14, [rsp+0xD0]
000071c0d83d92a3  vmovaps xmm15, [rsp+0xE0]
000071c0d83d92ac  add rsp, 0xF0
000071c0d83d92b3  pop r11
000071c0d83d92b5  pop r10
000071c0d83d92b7  pop r9
000071c0d83d92b9  pop r8
000071c0d83d92bb  pop rsi
000071c0d83d92bc  pop rdi
000071c0d83d92bd  pop rdx
000071c0d83d92be  pop rcx
000071c0d83d92bf  pop rax
000071c0d83d92c0  add rsp, 0x08
000071c0d83d92c4  jmp 0x000071C0D83D6200
000071c0d83d92c9  sub rsp, 0x08
000071c0d83d92cd  push rax
000071c0d83d92ce  push rcx
000071c0d83d92cf  push rdx
000071c0d83d92d0  push rdi
000071c0d83d92d1  push rsi
000071c0d83d92d2  push r8
000071c0d83d92d4  push r9
000071c0d83d92d6  push r10
000071c0d83d92d8  push r11
000071c0d83d92da  sub rsp, 0xF0
000071c0d83d92e1  vmovaps [rsp], xmm0
000071c0d83d92e6  vmovaps [rsp+0x10], xmm1
000071c0d83d92ec  vmovaps [rsp+0x20], xmm2
000071c0d83d92f2  vmovaps [rsp+0x30], xmm3
000071c0d83d92f8  vmovaps [rsp+0x40], xmm4
000071c0d83d92fe  vmovaps [rsp+0x50], xmm5
000071c0d83d9304  vmovaps [rsp+0x60], xmm7
000071c0d83d930a  vmovaps [rsp+0x70], xmm8
000071c0d83d9310  vmovaps [rsp+0x80], xmm9
000071c0d83d9319  vmovaps [rsp+0x90], xmm10
000071c0d83d9322  vmovaps [rsp+0xA0], xmm11
000071c0d83d932b  vmovaps [rsp+0xB0], xmm12
000071c0d83d9334  vmovaps [rsp+0xC0], xmm13
000071c0d83d933d  vmovaps [rsp+0xD0], xmm14
000071c0d83d9346  vmovaps [rsp+0xE0], xmm15
000071c0d83d934f  sub rsp, 0x30
000071c0d83d9353  movaps [rsp], xmm6
000071c0d83d9357  movaps [rsp+0x10], xmm10
000071c0d83d935d  movaps [rsp+0x20], xmm8
000071c0d83d9363  lea rdi, [rsp]
000071c0d83d9367  mov esi, 0x00
000071c0d83d936c  mov rax, 0x5904ED15D530
000071c0d83d9376  call rax
000071c0d83d9378  movaps xmm6, [rsp]
000071c0d83d937c  add rsp, 0x30
000071c0d83d9380  vmovaps xmm0, [rsp]
000071c0d83d9385  vmovaps xmm1, [rsp+0x10]
000071c0d83d938b  vmovaps xmm2, [rsp+0x20]
000071c0d83d9391  vmovaps xmm3, [rsp+0x30]
000071c0d83d9397  vmovaps xmm4, [rsp+0x40]
000071c0d83d939d  vmovaps xmm5, [rsp+0x50]
000071c0d83d93a3  vmovaps xmm7, [rsp+0x60]
000071c0d83d93a9  vmovaps xmm8, [rsp+0x70]
000071c0d83d93af  vmovaps xmm9, [rsp+0x80]
000071c0d83d93b8  vmovaps xmm10, [rsp+0x90]
000071c0d83d93c1  vmovaps xmm11, [rsp+0xA0]
000071c0d83d93ca  vmovaps xmm12, [rsp+0xB0]
000071c0d83d93d3  vmovaps xmm13, [rsp+0xC0]
000071c0d83d93dc  vmovaps xmm14, [rsp+0xD0]
000071c0d83d93e5  vmovaps xmm15, [rsp+0xE0]
000071c0d83d93ee  add rsp, 0xF0
000071c0d83d93f5  pop r11
000071c0d83d93f7  pop r10
000071c0d83d93f9  pop r9
000071c0d83d93fb  pop r8
000071c0d83d93fd  pop rsi
000071c0d83d93fe  pop rdi
000071c0d83d93ff  pop rdx
000071c0d83d9400  pop rcx
000071c0d83d9401  pop rax
000071c0d83d9402  add rsp, 0x08
000071c0d83d9406  jmp 0x000071C0D83D6225
000071c0d83d940b  sub rsp, 0x08
000071c0d83d940f  push rax
000071c0d83d9410  push rcx
000071c0d83d9411  push rdx
000071c0d83d9412  push rdi
000071c0d83d9413  push rsi
000071c0d83d9414  push r8
000071c0d83d9416  push r9
000071c0d83d9418  push r10
000071c0d83d941a  push r11
000071c0d83d941c  sub rsp, 0xF0
000071c0d83d9423  vmovaps [rsp], xmm0
000071c0d83d9428  vmovaps [rsp+0x10], xmm1
000071c0d83d942e  vmovaps [rsp+0x20], xmm2
000071c0d83d9434  vmovaps [rsp+0x30], xmm3
000071c0d83d943a  vmovaps [rsp+0x40], xmm4
000071c0d83d9440  vmovaps [rsp+0x50], xmm5
000071c0d83d9446  vmovaps [rsp+0x60], xmm6
000071c0d83d944c  vmovaps [rsp+0x70], xmm7
000071c0d83d9452  vmovaps [rsp+0x80], xmm8
000071c0d83d945b  vmovaps [rsp+0x90], xmm9
000071c0d83d9464  vmovaps [rsp+0xA0], xmm11
000071c0d83d946d  vmovaps [rsp+0xB0], xmm12
000071c0d83d9476  vmovaps [rsp+0xC0], xmm13
000071c0d83d947f  vmovaps [rsp+0xD0], xmm14
000071c0d83d9488  vmovaps [rsp+0xE0], xmm15
000071c0d83d9491  sub rsp, 0x30
000071c0d83d9495  movaps [rsp], xmm10
000071c0d83d949a  movaps [rsp+0x10], xmm8
000071c0d83d94a0  movaps [rsp+0x20], xmm14
000071c0d83d94a6  lea rdi, [rsp]
000071c0d83d94aa  mov esi, 0x00
000071c0d83d94af  mov rax, 0x5904ED15D530
000071c0d83d94b9  call rax
000071c0d83d94bb  movaps xmm10, [rsp]
000071c0d83d94c0  add rsp, 0x30
000071c0d83d94c4  vmovaps xmm0, [rsp]
000071c0d83d94c9  vmovaps xmm1, [rsp+0x10]
000071c0d83d94cf  vmovaps xmm2, [rsp+0x20]
000071c0d83d94d5  vmovaps xmm3, [rsp+0x30]
000071c0d83d94db  vmovaps xmm4, [rsp+0x40]
000071c0d83d94e1  vmovaps xmm5, [rsp+0x50]
000071c0d83d94e7  vmovaps xmm6, [rsp+0x60]
000071c0d83d94ed  vmovaps xmm7, [rsp+0x70]
000071c0d83d94f3  vmovaps xmm8, [rsp+0x80]
000071c0d83d94fc  vmovaps xmm9, [rsp+0x90]
000071c0d83d9505  vmovaps xmm11, [rsp+0xA0]
000071c0d83d950e  vmovaps xmm12, [rsp+0xB0]
000071c0d83d9517  vmovaps xmm13, [rsp+0xC0]
000071c0d83d9520  vmovaps xmm14, [rsp+0xD0]
000071c0d83d9529  vmovaps xmm15, [rsp+0xE0]
000071c0d83d9532  add rsp, 0xF0
000071c0d83d9539  pop r11
000071c0d83d953b  pop r10
000071c0d83d953d  pop r9
000071c0d83d953f  pop r8
000071c0d83d9541  pop rsi
000071c0d83d9542  pop rdi
000071c0d83d9543  pop rdx
000071c0d83d9544  pop rcx
000071c0d83d9545  pop rax
000071c0d83d9546  add rsp, 0x08
000071c0d83d954a  jmp 0x000071C0D83D6245
000071c0d83d954f  sub rsp, 0x08
000071c0d83d9553  push rax
000071c0d83d9554  push rcx
000071c0d83d9555  push rdx
000071c0d83d9556  push rdi
000071c0d83d9557  push rsi
000071c0d83d9558  push r8
000071c0d83d955a  push r9
000071c0d83d955c  push r10
000071c0d83d955e  push r11
000071c0d83d9560  sub rsp, 0xF0
000071c0d83d9567  vmovaps [rsp], xmm0
000071c0d83d956c  vmovaps [rsp+0x10], xmm1
000071c0d83d9572  vmovaps [rsp+0x20], xmm2
000071c0d83d9578  vmovaps [rsp+0x30], xmm3
000071c0d83d957e  vmovaps [rsp+0x40], xmm4
000071c0d83d9584  vmovaps [rsp+0x50], xmm5
000071c0d83d958a  vmovaps [rsp+0x60], xmm6
000071c0d83d9590  vmovaps [rsp+0x70], xmm7
000071c0d83d9596  vmovaps [rsp+0x80], xmm8
000071c0d83d959f  vmovaps [rsp+0x90], xmm9
000071c0d83d95a8  vmovaps [rsp+0xA0], xmm10
000071c0d83d95b1  vmovaps [rsp+0xB0], xmm11
000071c0d83d95ba  vmovaps [rsp+0xC0], xmm12
000071c0d83d95c3  vmovaps [rsp+0xD0], xmm13
000071c0d83d95cc  vmovaps [rsp+0xE0], xmm15
000071c0d83d95d5  sub rsp, 0x30
000071c0d83d95d9  movaps [rsp], xmm14
000071c0d83d95de  movaps [rsp+0x10], xmm8
000071c0d83d95e4  movaps [rsp+0x20], xmm4
000071c0d83d95e9  lea rdi, [rsp]
000071c0d83d95ed  mov esi, 0x00
000071c0d83d95f2  mov rax, 0x5904ED15D530
000071c0d83d95fc  call rax
000071c0d83d95fe  movaps xmm14, [rsp]
000071c0d83d9603  add rsp, 0x30
000071c0d83d9607  vmovaps xmm0, [rsp]
000071c0d83d960c  vmovaps xmm1, [rsp+0x10]
000071c0d83d9612  vmovaps xmm2, [rsp+0x20]
000071c0d83d9618  vmovaps xmm3, [rsp+0x30]
000071c0d83d961e  vmovaps xmm4, [rsp+0x40]
000071c0d83d9624  vmovaps xmm5, [rsp+0x50]
000071c0d83d962a  vmovaps xmm6, [rsp+0x60]
000071c0d83d9630  vmovaps xmm7, [rsp+0x70]
000071c0d83d9636  vmovaps xmm8, [rsp+0x80]
000071c0d83d963f  vmovaps xmm9, [rsp+0x90]
000071c0d83d9648  vmovaps xmm10, [rsp+0xA0]
000071c0d83d9651  vmovaps xmm11, [rsp+0xB0]
000071c0d83d965a  vmovaps xmm12, [rsp+0xC0]
000071c0d83d9663  vmovaps xmm13, [rsp+0xD0]
000071c0d83d966c  vmovaps xmm15, [rsp+0xE0]
000071c0d83d9675  add rsp, 0xF0
000071c0d83d967c  pop r11
000071c0d83d967e  pop r10
000071c0d83d9680  pop r9
000071c0d83d9682  pop r8
000071c0d83d9684  pop rsi
000071c0d83d9685  pop rdi
000071c0d83d9686  pop rdx
000071c0d83d9687  pop rcx
000071c0d83d9688  pop rax
000071c0d83d9689  add rsp, 0x08
000071c0d83d968d  jmp 0x000071C0D83D6265
000071c0d83d9692  sub rsp, 0x08
000071c0d83d9696  push rax
000071c0d83d9697  push rcx
000071c0d83d9698  push rdx
000071c0d83d9699  push rdi
000071c0d83d969a  push rsi
000071c0d83d969b  push r8
000071c0d83d969d  push r9
000071c0d83d969f  push r10
000071c0d83d96a1  push r11
000071c0d83d96a3  sub rsp, 0xF0
000071c0d83d96aa  vmovaps [rsp], xmm0
000071c0d83d96af  vmovaps [rsp+0x10], xmm1
000071c0d83d96b5  vmovaps [rsp+0x20], xmm2
000071c0d83d96bb  vmovaps [rsp+0x30], xmm3
000071c0d83d96c1  vmovaps [rsp+0x40], xmm5
000071c0d83d96c7  vmovaps [rsp+0x50], xmm6
000071c0d83d96cd  vmovaps [rsp+0x60], xmm7
000071c0d83d96d3  vmovaps [rsp+0x70], xmm8
000071c0d83d96d9  vmovaps [rsp+0x80], xmm9
000071c0d83d96e2  vmovaps [rsp+0x90], xmm10
000071c0d83d96eb  vmovaps [rsp+0xA0], xmm11
000071c0d83d96f4  vmovaps [rsp+0xB0], xmm12
000071c0d83d96fd  vmovaps [rsp+0xC0], xmm13
000071c0d83d9706  vmovaps [rsp+0xD0], xmm14
000071c0d83d970f  vmovaps [rsp+0xE0], xmm15
000071c0d83d9718  sub rsp, 0x30
000071c0d83d971c  movaps [rsp], xmm4
000071c0d83d9720  movaps [rsp+0x10], xmm13
000071c0d83d9726  movaps [rsp+0x20], xmm8
000071c0d83d972c  lea rdi, [rsp]
000071c0d83d9730  mov esi, 0x00
000071c0d83d9735  mov rax, 0x5904ED15D530
000071c0d83d973f  call rax
000071c0d83d9741  movaps xmm4, [rsp]
000071c0d83d9745  add rsp, 0x30
000071c0d83d9749  vmovaps xmm0, [rsp]
000071c0d83d974e  vmovaps xmm1, [rsp+0x10]
000071c0d83d9754  vmovaps xmm2, [rsp+0x20]
000071c0d83d975a  vmovaps xmm3, [rsp+0x30]
000071c0d83d9760  vmovaps xmm5, [rsp+0x40]
000071c0d83d9766  vmovaps xmm6, [rsp+0x50]
000071c0d83d976c  vmovaps xmm7, [rsp+0x60]
000071c0d83d9772  vmovaps xmm8, [rsp+0x70]
000071c0d83d9778  vmovaps xmm9, [rsp+0x80]
000071c0d83d9781  vmovaps xmm10, [rsp+0x90]
000071c0d83d978a  vmovaps xmm11, [rsp+0xA0]
000071c0d83d9793  vmovaps xmm12, [rsp+0xB0]
000071c0d83d979c  vmovaps xmm13, [rsp+0xC0]
000071c0d83d97a5  vmovaps xmm14, [rsp+0xD0]
000071c0d83d97ae  vmovaps xmm15, [rsp+0xE0]
000071c0d83d97b7  add rsp, 0xF0
000071c0d83d97be  pop r11
000071c0d83d97c0  pop r10
000071c0d83d97c2  pop r9
000071c0d83d97c4  pop r8
000071c0d83d97c6  pop rsi
000071c0d83d97c7  pop rdi
000071c0d83d97c8  pop rdx
000071c0d83d97c9  pop rcx
000071c0d83d97ca  pop rax
000071c0d83d97cb  add rsp, 0x08
000071c0d83d97cf  jmp 0x000071C0D83D628A
000071c0d83d97d4  sub rsp, 0x08
000071c0d83d97d8  push rax
000071c0d83d97d9  push rcx
000071c0d83d97da  push rdx
000071c0d83d97db  push rdi
000071c0d83d97dc  push rsi
000071c0d83d97dd  push r8
000071c0d83d97df  push r9
000071c0d83d97e1  push r10
000071c0d83d97e3  push r11
000071c0d83d97e5  sub rsp, 0xF0
000071c0d83d97ec  vmovaps [rsp], xmm0
000071c0d83d97f1  vmovaps [rsp+0x10], xmm1
000071c0d83d97f7  vmovaps [rsp+0x20], xmm2
000071c0d83d97fd  vmovaps [rsp+0x30], xmm3
000071c0d83d9803  vmovaps [rsp+0x40], xmm4
000071c0d83d9809  vmovaps [rsp+0x50], xmm5
000071c0d83d980f  vmovaps [rsp+0x60], xmm6
000071c0d83d9815  vmovaps [rsp+0x70], xmm7
000071c0d83d981b  vmovaps [rsp+0x80], xmm8
000071c0d83d9824  vmovaps [rsp+0x90], xmm9
000071c0d83d982d  vmovaps [rsp+0xA0], xmm10
000071c0d83d9836  vmovaps [rsp+0xB0], xmm11
000071c0d83d983f  vmovaps [rsp+0xC0], xmm12
000071c0d83d9848  vmovaps [rsp+0xD0], xmm14
000071c0d83d9851  vmovaps [rsp+0xE0], xmm15
000071c0d83d985a  sub rsp, 0x30
000071c0d83d985e  movaps [rsp], xmm13
000071c0d83d9863  movaps [rsp+0x10], xmm15
000071c0d83d9869  movaps [rsp+0x20], xmm9
000071c0d83d986f  lea rdi, [rsp]
000071c0d83d9873  mov esi, 0x00
000071c0d83d9878  mov rax, 0x5904ED15D530
000071c0d83d9882  call rax
000071c0d83d9884  movaps xmm13, [rsp]
000071c0d83d9889  add rsp, 0x30
000071c0d83d988d  vmovaps xmm0, [rsp]
000071c0d83d9892  vmovaps xmm1, [rsp+0x10]
000071c0d83d9898  vmovaps xmm2, [rsp+0x20]
000071c0d83d989e  vmovaps xmm3, [rsp+0x30]
000071c0d83d98a4  vmovaps xmm4, [rsp+0x40]
000071c0d83d98aa  vmovaps xmm5, [rsp+0x50]
000071c0d83d98b0  vmovaps xmm6, [rsp+0x60]
000071c0d83d98b6  vmovaps xmm7, [rsp+0x70]
000071c0d83d98bc  vmovaps xmm8, [rsp+0x80]
000071c0d83d98c5  vmovaps xmm9, [rsp+0x90]
000071c0d83d98ce  vmovaps xmm10, [rsp+0xA0]
000071c0d83d98d7  vmovaps xmm11, [rsp+0xB0]
000071c0d83d98e0  vmovaps xmm12, [rsp+0xC0]
000071c0d83d98e9  vmovaps xmm14, [rsp+0xD0]
000071c0d83d98f2  vmovaps xmm15, [rsp+0xE0]
000071c0d83d98fb  add rsp, 0xF0
000071c0d83d9902  pop r11
000071c0d83d9904  pop r10
000071c0d83d9906  pop r9
000071c0d83d9908  pop r8
000071c0d83d990a  pop rsi
000071c0d83d990b  pop rdi
000071c0d83d990c  pop rdx
000071c0d83d990d  pop rcx
000071c0d83d990e  pop rax
000071c0d83d990f  add rsp, 0x08
000071c0d83d9913  jmp 0x000071C0D83D62A5
000071c0d83d9918  sub rsp, 0x08
000071c0d83d991c  push rax
000071c0d83d991d  push rcx
000071c0d83d991e  push rdx
000071c0d83d991f  push rdi
000071c0d83d9920  push rsi
000071c0d83d9921  push r8
000071c0d83d9923  push r9
000071c0d83d9925  push r10
000071c0d83d9927  push r11
000071c0d83d9929  sub rsp, 0xF0
000071c0d83d9930  vmovaps [rsp], xmm0
000071c0d83d9935  vmovaps [rsp+0x10], xmm1
000071c0d83d993b  vmovaps [rsp+0x20], xmm2
000071c0d83d9941  vmovaps [rsp+0x30], xmm3
000071c0d83d9947  vmovaps [rsp+0x40], xmm4
000071c0d83d994d  vmovaps [rsp+0x50], xmm5
000071c0d83d9953  vmovaps [rsp+0x60], xmm6
000071c0d83d9959  vmovaps [rsp+0x70], xmm7
000071c0d83d995f  vmovaps [rsp+0x80], xmm8
000071c0d83d9968  vmovaps [rsp+0x90], xmm9
000071c0d83d9971  vmovaps [rsp+0xA0], xmm10
000071c0d83d997a  vmovaps [rsp+0xB0], xmm11
000071c0d83d9983  vmovaps [rsp+0xC0], xmm12
000071c0d83d998c  vmovaps [rsp+0xD0], xmm13
000071c0d83d9995  vmovaps [rsp+0xE0], xmm14
000071c0d83d999e  sub rsp, 0x30
000071c0d83d99a2  movaps [rsp], xmm15
000071c0d83d99a7  movaps [rsp+0x10], xmm1
000071c0d83d99ac  movaps [rsp+0x20], xmm5
000071c0d83d99b1  lea rdi, [rsp]
000071c0d83d99b5  mov esi, 0x00
000071c0d83d99ba  mov rax, 0x5904ED15D530
000071c0d83d99c4  call rax
000071c0d83d99c6  movaps xmm15, [rsp]
000071c0d83d99cb  add rsp, 0x30
000071c0d83d99cf  vmovaps xmm0, [rsp]
000071c0d83d99d4  vmovaps xmm1, [rsp+0x10]
000071c0d83d99da  vmovaps xmm2, [rsp+0x20]
000071c0d83d99e0  vmovaps xmm3, [rsp+0x30]
000071c0d83d99e6  vmovaps xmm4, [rsp+0x40]
000071c0d83d99ec  vmovaps xmm5, [rsp+0x50]
000071c0d83d99f2  vmovaps xmm6, [rsp+0x60]
000071c0d83d99f8  vmovaps xmm7, [rsp+0x70]
000071c0d83d99fe  vmovaps xmm8, [rsp+0x80]
000071c0d83d9a07  vmovaps xmm9, [rsp+0x90]
000071c0d83d9a10  vmovaps xmm10, [rsp+0xA0]
000071c0d83d9a19  vmovaps xmm11, [rsp+0xB0]
000071c0d83d9a22  vmovaps xmm12, [rsp+0xC0]
000071c0d83d9a2b  vmovaps xmm13, [rsp+0xD0]
000071c0d83d9a34  vmovaps xmm14, [rsp+0xE0]
000071c0d83d9a3d  add rsp, 0xF0
000071c0d83d9a44  pop r11
000071c0d83d9a46  pop r10
000071c0d83d9a48  pop r9
000071c0d83d9a4a  pop r8
000071c0d83d9a4c  pop rsi
000071c0d83d9a4d  pop rdi
000071c0d83d9a4e  pop rdx
000071c0d83d9a4f  pop rcx
000071c0d83d9a50  pop rax
000071c0d83d9a51  add rsp, 0x08
000071c0d83d9a55  jmp 0x000071C0D83D62C0
000071c0d83d9a5a  call 0x000071C0D82D64F0
000071c0d83d9a5f  jmp 0x000071C0D83D631B
000071c0d83d9a64  sub rsp, 0x08
000071c0d83d9a68  push rax
000071c0d83d9a69  push rcx
000071c0d83d9a6a  push rdx
000071c0d83d9a6b  push rdi
000071c0d83d9a6c  push rsi
000071c0d83d9a6d  push r8
000071c0d83d9a6f  push r9
000071c0d83d9a71  push r10
000071c0d83d9a73  push r11
000071c0d83d9a75  sub rsp, 0xF0
000071c0d83d9a7c  vmovaps [rsp], xmm0
000071c0d83d9a81  vmovaps [rsp+0x10], xmm1
000071c0d83d9a87  vmovaps [rsp+0x20], xmm2
000071c0d83d9a8d  vmovaps [rsp+0x30], xmm3
000071c0d83d9a93  vmovaps [rsp+0x40], xmm4
000071c0d83d9a99  vmovaps [rsp+0x50], xmm5
000071c0d83d9a9f  vmovaps [rsp+0x60], xmm6
000071c0d83d9aa5  vmovaps [rsp+0x70], xmm7
000071c0d83d9aab  vmovaps [rsp+0x80], xmm8
000071c0d83d9ab4  vmovaps [rsp+0x90], xmm10
000071c0d83d9abd  vmovaps [rsp+0xA0], xmm11
000071c0d83d9ac6  vmovaps [rsp+0xB0], xmm12
000071c0d83d9acf  vmovaps [rsp+0xC0], xmm13
000071c0d83d9ad8  vmovaps [rsp+0xD0], xmm14
000071c0d83d9ae1  vmovaps [rsp+0xE0], xmm15
000071c0d83d9aea  sub rsp, 0x30
000071c0d83d9aee  movaps [rsp], xmm9
000071c0d83d9af3  movaps [rsp+0x10], xmm8
000071c0d83d9af9  movaps [rsp+0x20], xmm11
000071c0d83d9aff  lea rdi, [rsp]
000071c0d83d9b03  mov esi, 0x00
000071c0d83d9b08  mov rax, 0x5904ED15D530
000071c0d83d9b12  call rax
000071c0d83d9b14  movaps xmm9, [rsp]
000071c0d83d9b19  add rsp, 0x30
000071c0d83d9b1d  vmovaps xmm0, [rsp]
000071c0d83d9b22  vmovaps xmm1, [rsp+0x10]
000071c0d83d9b28  vmovaps xmm2, [rsp+0x20]
000071c0d83d9b2e  vmovaps xmm3, [rsp+0x30]
000071c0d83d9b34  vmovaps xmm4, [rsp+0x40]
000071c0d83d9b3a  vmovaps xmm5, [rsp+0x50]
000071c0d83d9b40  vmovaps xmm6, [rsp+0x60]
000071c0d83d9b46  vmovaps xmm7, [rsp+0x70]
000071c0d83d9b4c  vmovaps xmm8, [rsp+0x80]
000071c0d83d9b55  vmovaps xmm10, [rsp+0x90]
000071c0d83d9b5e  vmovaps xmm11, [rsp+0xA0]
000071c0d83d9b67  vmovaps xmm12, [rsp+0xB0]
000071c0d83d9b70  vmovaps xmm13, [rsp+0xC0]
000071c0d83d9b79  vmovaps xmm14, [rsp+0xD0]
000071c0d83d9b82  vmovaps xmm15, [rsp+0xE0]
000071c0d83d9b8b  add rsp, 0xF0
000071c0d83d9b92  pop r11
000071c0d83d9b94  pop r10
000071c0d83d9b96  pop r9
000071c0d83d9b98  pop r8
000071c0d83d9b9a  pop rsi
000071c0d83d9b9b  pop rdi
000071c0d83d9b9c  pop rdx
000071c0d83d9b9d  pop rcx
000071c0d83d9b9e  pop rax
000071c0d83d9b9f  add rsp, 0x08
000071c0d83d9ba3  jmp 0x000071C0D83D6352
000071c0d83d9ba8  sub rsp, 0x08
000071c0d83d9bac  push rax
000071c0d83d9bad  push rcx
000071c0d83d9bae  push rdx
000071c0d83d9baf  push rdi
000071c0d83d9bb0  push rsi
000071c0d83d9bb1  push r8
000071c0d83d9bb3  push r9
000071c0d83d9bb5  push r10
000071c0d83d9bb7  push r11
000071c0d83d9bb9  sub rsp, 0xF0
000071c0d83d9bc0  vmovaps [rsp], xmm0
000071c0d83d9bc5  vmovaps [rsp+0x10], xmm1
000071c0d83d9bcb  vmovaps [rsp+0x20], xmm2
000071c0d83d9bd1  vmovaps [rsp+0x30], xmm3
000071c0d83d9bd7  vmovaps [rsp+0x40], xmm4
000071c0d83d9bdd  vmovaps [rsp+0x50], xmm5
000071c0d83d9be3  vmovaps [rsp+0x60], xmm6
000071c0d83d9be9  vmovaps [rsp+0x70], xmm7
000071c0d83d9bef  vmovaps [rsp+0x80], xmm8
000071c0d83d9bf8  vmovaps [rsp+0x90], xmm9
000071c0d83d9c01  vmovaps [rsp+0xA0], xmm10
000071c0d83d9c0a  vmovaps [rsp+0xB0], xmm12
000071c0d83d9c13  vmovaps [rsp+0xC0], xmm13
000071c0d83d9c1c  vmovaps [rsp+0xD0], xmm14
000071c0d83d9c25  vmovaps [rsp+0xE0], xmm15
000071c0d83d9c2e  sub rsp, 0x30
000071c0d83d9c32  movaps [rsp], xmm11
000071c0d83d9c37  movaps [rsp+0x10], xmm10
000071c0d83d9c3d  movaps [rsp+0x20], xmm6
000071c0d83d9c42  lea rdi, [rsp]
000071c0d83d9c46  mov esi, 0x00
000071c0d83d9c4b  mov rax, 0x5904ED15D530
000071c0d83d9c55  call rax
000071c0d83d9c57  movaps xmm11, [rsp]
000071c0d83d9c5c  add rsp, 0x30
000071c0d83d9c60  vmovaps xmm0, [rsp]
000071c0d83d9c65  vmovaps xmm1, [rsp+0x10]
000071c0d83d9c6b  vmovaps xmm2, [rsp+0x20]
000071c0d83d9c71  vmovaps xmm3, [rsp+0x30]
000071c0d83d9c77  vmovaps xmm4, [rsp+0x40]
000071c0d83d9c7d  vmovaps xmm5, [rsp+0x50]
000071c0d83d9c83  vmovaps xmm6, [rsp+0x60]
000071c0d83d9c89  vmovaps xmm7, [rsp+0x70]
000071c0d83d9c8f  vmovaps xmm8, [rsp+0x80]
000071c0d83d9c98  vmovaps xmm9, [rsp+0x90]
000071c0d83d9ca1  vmovaps xmm10, [rsp+0xA0]
000071c0d83d9caa  vmovaps xmm12, [rsp+0xB0]
000071c0d83d9cb3  vmovaps xmm13, [rsp+0xC0]
000071c0d83d9cbc  vmovaps xmm14, [rsp+0xD0]
000071c0d83d9cc5  vmovaps xmm15, [rsp+0xE0]
000071c0d83d9cce  add rsp, 0xF0
000071c0d83d9cd5  pop r11
000071c0d83d9cd7  pop r10
000071c0d83d9cd9  pop r9
000071c0d83d9cdb  pop r8
000071c0d83d9cdd  pop rsi
000071c0d83d9cde  pop rdi
000071c0d83d9cdf  pop rdx
000071c0d83d9ce0  pop rcx
000071c0d83d9ce1  pop rax
000071c0d83d9ce2  add rsp, 0x08
000071c0d83d9ce6  jmp 0x000071C0D83D636D
000071c0d83d9ceb  sub rsp, 0x08
000071c0d83d9cef  push rax
000071c0d83d9cf0  push rcx
000071c0d83d9cf1  push rdx
000071c0d83d9cf2  push rdi
000071c0d83d9cf3  push rsi
000071c0d83d9cf4  push r8
000071c0d83d9cf6  push r9
000071c0d83d9cf8  push r10
000071c0d83d9cfa  push r11
000071c0d83d9cfc  sub rsp, 0xF0
000071c0d83d9d03  vmovaps [rsp], xmm0
000071c0d83d9d08  vmovaps [rsp+0x10], xmm1
000071c0d83d9d0e  vmovaps [rsp+0x20], xmm2
000071c0d83d9d14  vmovaps [rsp+0x30], xmm3
000071c0d83d9d1a  vmovaps [rsp+0x40], xmm4
000071c0d83d9d20  vmovaps [rsp+0x50], xmm5
000071c0d83d9d26  vmovaps [rsp+0x60], xmm6
000071c0d83d9d2c  vmovaps [rsp+0x70], xmm7
000071c0d83d9d32  vmovaps [rsp+0x80], xmm8
000071c0d83d9d3b  vmovaps [rsp+0x90], xmm9
000071c0d83d9d44  vmovaps [rsp+0xA0], xmm11
000071c0d83d9d4d  vmovaps [rsp+0xB0], xmm12
000071c0d83d9d56  vmovaps [rsp+0xC0], xmm13
000071c0d83d9d5f  vmovaps [rsp+0xD0], xmm14
000071c0d83d9d68  vmovaps [rsp+0xE0], xmm15
000071c0d83d9d71  sub rsp, 0x30
000071c0d83d9d75  movaps [rsp], xmm10
000071c0d83d9d7a  movaps [rsp+0x10], xmm14
000071c0d83d9d80  movaps [rsp+0x20], xmm4
000071c0d83d9d85  lea rdi, [rsp]
000071c0d83d9d89  mov esi, 0x00
000071c0d83d9d8e  mov rax, 0x5904ED15D530
000071c0d83d9d98  call rax
000071c0d83d9d9a  movaps xmm10, [rsp]
000071c0d83d9d9f  add rsp, 0x30
000071c0d83d9da3  vmovaps xmm0, [rsp]
000071c0d83d9da8  vmovaps xmm1, [rsp+0x10]
000071c0d83d9dae  vmovaps xmm2, [rsp+0x20]
000071c0d83d9db4  vmovaps xmm3, [rsp+0x30]
000071c0d83d9dba  vmovaps xmm4, [rsp+0x40]
000071c0d83d9dc0  vmovaps xmm5, [rsp+0x50]
000071c0d83d9dc6  vmovaps xmm6, [rsp+0x60]
000071c0d83d9dcc  vmovaps xmm7, [rsp+0x70]
000071c0d83d9dd2  vmovaps xmm8, [rsp+0x80]
000071c0d83d9ddb  vmovaps xmm9, [rsp+0x90]
000071c0d83d9de4  vmovaps xmm11, [rsp+0xA0]
000071c0d83d9ded  vmovaps xmm12, [rsp+0xB0]
000071c0d83d9df6  vmovaps xmm13, [rsp+0xC0]
000071c0d83d9dff  vmovaps xmm14, [rsp+0xD0]
000071c0d83d9e08  vmovaps xmm15, [rsp+0xE0]
000071c0d83d9e11  add rsp, 0xF0
000071c0d83d9e18  pop r11
000071c0d83d9e1a  pop r10
000071c0d83d9e1c  pop r9
000071c0d83d9e1e  pop r8
000071c0d83d9e20  pop rsi
000071c0d83d9e21  pop rdi
000071c0d83d9e22  pop rdx
000071c0d83d9e23  pop rcx
000071c0d83d9e24  pop rax
000071c0d83d9e25  add rsp, 0x08
000071c0d83d9e29  jmp 0x000071C0D83D6388
000071c0d83d9e2e  sub rsp, 0x08
000071c0d83d9e32  push rax
000071c0d83d9e33  push rcx
000071c0d83d9e34  push rdx
000071c0d83d9e35  push rdi
000071c0d83d9e36  push rsi
000071c0d83d9e37  push r8
000071c0d83d9e39  push r9
000071c0d83d9e3b  push r10
000071c0d83d9e3d  push r11
000071c0d83d9e3f  sub rsp, 0xF0
000071c0d83d9e46  vmovaps [rsp], xmm0
000071c0d83d9e4b  vmovaps [rsp+0x10], xmm1
000071c0d83d9e51  vmovaps [rsp+0x20], xmm2
000071c0d83d9e57  vmovaps [rsp+0x30], xmm3
000071c0d83d9e5d  vmovaps [rsp+0x40], xmm4
000071c0d83d9e63  vmovaps [rsp+0x50], xmm5
000071c0d83d9e69  vmovaps [rsp+0x60], xmm6
000071c0d83d9e6f  vmovaps [rsp+0x70], xmm7
000071c0d83d9e75  vmovaps [rsp+0x80], xmm9
000071c0d83d9e7e  vmovaps [rsp+0x90], xmm10
000071c0d83d9e87  vmovaps [rsp+0xA0], xmm11
000071c0d83d9e90  vmovaps [rsp+0xB0], xmm12
000071c0d83d9e99  vmovaps [rsp+0xC0], xmm13
000071c0d83d9ea2  vmovaps [rsp+0xD0], xmm14
000071c0d83d9eab  vmovaps [rsp+0xE0], xmm15
000071c0d83d9eb4  sub rsp, 0x30
000071c0d83d9eb8  movaps [rsp], xmm8
000071c0d83d9ebd  movaps [rsp+0x10], xmm1
000071c0d83d9ec2  movaps [rsp+0x20], xmm14
000071c0d83d9ec8  lea rdi, [rsp]
000071c0d83d9ecc  mov esi, 0x00
000071c0d83d9ed1  mov rax, 0x5904ED15D530
000071c0d83d9edb  call rax
000071c0d83d9edd  movaps xmm8, [rsp]
000071c0d83d9ee2  add rsp, 0x30
000071c0d83d9ee6  vmovaps xmm0, [rsp]
000071c0d83d9eeb  vmovaps xmm1, [rsp+0x10]
000071c0d83d9ef1  vmovaps xmm2, [rsp+0x20]
000071c0d83d9ef7  vmovaps xmm3, [rsp+0x30]
000071c0d83d9efd  vmovaps xmm4, [rsp+0x40]
000071c0d83d9f03  vmovaps xmm5, [rsp+0x50]
000071c0d83d9f09  vmovaps xmm6, [rsp+0x60]
000071c0d83d9f0f  vmovaps xmm7, [rsp+0x70]
000071c0d83d9f15  vmovaps xmm9, [rsp+0x80]
000071c0d83d9f1e  vmovaps xmm10, [rsp+0x90]
000071c0d83d9f27  vmovaps xmm11, [rsp+0xA0]
000071c0d83d9f30  vmovaps xmm12, [rsp+0xB0]
000071c0d83d9f39  vmovaps xmm13, [rsp+0xC0]
000071c0d83d9f42  vmovaps xmm14, [rsp+0xD0]
000071c0d83d9f4b  vmovaps xmm15, [rsp+0xE0]
000071c0d83d9f54  add rsp, 0xF0
000071c0d83d9f5b  pop r11
000071c0d83d9f5d  pop r10
000071c0d83d9f5f  pop r9
000071c0d83d9f61  pop r8
000071c0d83d9f63  pop rsi
000071c0d83d9f64  pop rdi
000071c0d83d9f65  pop rdx
000071c0d83d9f66  pop rcx
000071c0d83d9f67  pop rax
000071c0d83d9f68  add rsp, 0x08
000071c0d83d9f6c  jmp 0x000071C0D83D63AE
000071c0d83d9f71  sub rsp, 0x08
000071c0d83d9f75  push rax
000071c0d83d9f76  push rcx
000071c0d83d9f77  push rdx
000071c0d83d9f78  push rdi
000071c0d83d9f79  push rsi
000071c0d83d9f7a  push r8
000071c0d83d9f7c  push r9
000071c0d83d9f7e  push r10
000071c0d83d9f80  push r11
000071c0d83d9f82  sub rsp, 0xF0
000071c0d83d9f89  vmovaps [rsp], xmm0
000071c0d83d9f8e  vmovaps [rsp+0x10], xmm1
000071c0d83d9f94  vmovaps [rsp+0x20], xmm2
000071c0d83d9f9a  vmovaps [rsp+0x30], xmm3
000071c0d83d9fa0  vmovaps [rsp+0x40], xmm4
000071c0d83d9fa6  vmovaps [rsp+0x50], xmm5
000071c0d83d9fac  vmovaps [rsp+0x60], xmm7
000071c0d83d9fb2  vmovaps [rsp+0x70], xmm8
000071c0d83d9fb8  vmovaps [rsp+0x80], xmm9
000071c0d83d9fc1  vmovaps [rsp+0x90], xmm10
000071c0d83d9fca  vmovaps [rsp+0xA0], xmm11
000071c0d83d9fd3  vmovaps [rsp+0xB0], xmm12
000071c0d83d9fdc  vmovaps [rsp+0xC0], xmm13
000071c0d83d9fe5  vmovaps [rsp+0xD0], xmm14
000071c0d83d9fee  vmovaps [rsp+0xE0], xmm15
000071c0d83d9ff7  sub rsp, 0x30
000071c0d83d9ffb  movaps [rsp], xmm6
000071c0d83d9fff  movaps [rsp+0x10], xmm1
000071c0d83da004  movaps [rsp+0x20], xmm14
000071c0d83da00a  lea rdi, [rsp]
000071c0d83da00e  mov esi, 0x00
000071c0d83da013  mov rax, 0x5904ED15D530
000071c0d83da01d  call rax
000071c0d83da01f  movaps xmm6, [rsp]
000071c0d83da023  add rsp, 0x30
000071c0d83da027  vmovaps xmm0, [rsp]
000071c0d83da02c  vmovaps xmm1, [rsp+0x10]
000071c0d83da032  vmovaps xmm2, [rsp+0x20]
000071c0d83da038  vmovaps xmm3, [rsp+0x30]
000071c0d83da03e  vmovaps xmm4, [rsp+0x40]
000071c0d83da044  vmovaps xmm5, [rsp+0x50]
000071c0d83da04a  vmovaps xmm7, [rsp+0x60]
000071c0d83da050  vmovaps xmm8, [rsp+0x70]
000071c0d83da056  vmovaps xmm9, [rsp+0x80]
000071c0d83da05f  vmovaps xmm10, [rsp+0x90]
000071c0d83da068  vmovaps xmm11, [rsp+0xA0]
000071c0d83da071  vmovaps xmm12, [rsp+0xB0]
000071c0d83da07a  vmovaps xmm13, [rsp+0xC0]
000071c0d83da083  vmovaps xmm14, [rsp+0xD0]
000071c0d83da08c  vmovaps xmm15, [rsp+0xE0]
000071c0d83da095  add rsp, 0xF0
000071c0d83da09c  pop r11
000071c0d83da09e  pop r10
000071c0d83da0a0  pop r9
000071c0d83da0a2  pop r8
000071c0d83da0a4  pop rsi
000071c0d83da0a5  pop rdi
000071c0d83da0a6  pop rdx
000071c0d83da0a7  pop rcx
000071c0d83da0a8  pop rax
000071c0d83da0a9  add rsp, 0x08
000071c0d83da0ad  jmp 0x000071C0D83D63DA
000071c0d83da0b2  sub rsp, 0x08
000071c0d83da0b6  push rax
000071c0d83da0b7  push rcx
000071c0d83da0b8  push rdx
000071c0d83da0b9  push rdi
000071c0d83da0ba  push rsi
000071c0d83da0bb  push r8
000071c0d83da0bd  push r9
000071c0d83da0bf  push r10
000071c0d83da0c1  push r11
000071c0d83da0c3  sub rsp, 0xF0
000071c0d83da0ca  vmovaps [rsp], xmm0
000071c0d83da0cf  vmovaps [rsp+0x10], xmm1
000071c0d83da0d5  vmovaps [rsp+0x20], xmm2
000071c0d83da0db  vmovaps [rsp+0x30], xmm3
000071c0d83da0e1  vmovaps [rsp+0x40], xmm4
000071c0d83da0e7  vmovaps [rsp+0x50], xmm5
000071c0d83da0ed  vmovaps [rsp+0x60], xmm6
000071c0d83da0f3  vmovaps [rsp+0x70], xmm7
000071c0d83da0f9  vmovaps [rsp+0x80], xmm8
000071c0d83da102  vmovaps [rsp+0x90], xmm9
000071c0d83da10b  vmovaps [rsp+0xA0], xmm10
000071c0d83da114  vmovaps [rsp+0xB0], xmm11
000071c0d83da11d  vmovaps [rsp+0xC0], xmm12
000071c0d83da126  vmovaps [rsp+0xD0], xmm13
000071c0d83da12f  vmovaps [rsp+0xE0], xmm15
000071c0d83da138  sub rsp, 0x30
000071c0d83da13c  movaps [rsp], xmm14
000071c0d83da141  movaps [rsp+0x10], xmm12
000071c0d83da147  movaps [rsp+0x20], xmm1
000071c0d83da14c  lea rdi, [rsp]
000071c0d83da150  mov esi, 0x00
000071c0d83da155  mov rax, 0x5904ED15D530
000071c0d83da15f  call rax
000071c0d83da161  movaps xmm14, [rsp]
000071c0d83da166  add rsp, 0x30
000071c0d83da16a  vmovaps xmm0, [rsp]
000071c0d83da16f  vmovaps xmm1, [rsp+0x10]
000071c0d83da175  vmovaps xmm2, [rsp+0x20]
000071c0d83da17b  vmovaps xmm3, [rsp+0x30]
000071c0d83da181  vmovaps xmm4, [rsp+0x40]
000071c0d83da187  vmovaps xmm5, [rsp+0x50]
000071c0d83da18d  vmovaps xmm6, [rsp+0x60]
000071c0d83da193  vmovaps xmm7, [rsp+0x70]
000071c0d83da199  vmovaps xmm8, [rsp+0x80]
000071c0d83da1a2  vmovaps xmm9, [rsp+0x90]
000071c0d83da1ab  vmovaps xmm10, [rsp+0xA0]
000071c0d83da1b4  vmovaps xmm11, [rsp+0xB0]
000071c0d83da1bd  vmovaps xmm12, [rsp+0xC0]
000071c0d83da1c6  vmovaps xmm13, [rsp+0xD0]
000071c0d83da1cf  vmovaps xmm15, [rsp+0xE0]
000071c0d83da1d8  add rsp, 0xF0
000071c0d83da1df  pop r11
000071c0d83da1e1  pop r10
000071c0d83da1e3  pop r9
000071c0d83da1e5  pop r8
000071c0d83da1e7  pop rsi
000071c0d83da1e8  pop rdi
000071c0d83da1e9  pop rdx
000071c0d83da1ea  pop rcx
000071c0d83da1eb  pop rax
000071c0d83da1ec  add rsp, 0x08
000071c0d83da1f0  jmp 0x000071C0D83D6400
000071c0d83da1f5  sub rsp, 0x08
000071c0d83da1f9  push rax
000071c0d83da1fa  push rcx
000071c0d83da1fb  push rdx
000071c0d83da1fc  push rdi
000071c0d83da1fd  push rsi
000071c0d83da1fe  push r8
000071c0d83da200  push r9
000071c0d83da202  push r10
000071c0d83da204  push r11
000071c0d83da206  sub rsp, 0xF0
000071c0d83da20d  vmovaps [rsp], xmm0
000071c0d83da212  vmovaps [rsp+0x10], xmm2
000071c0d83da218  vmovaps [rsp+0x20], xmm3
000071c0d83da21e  vmovaps [rsp+0x30], xmm4
000071c0d83da224  vmovaps [rsp+0x40], xmm5
000071c0d83da22a  vmovaps [rsp+0x50], xmm6
000071c0d83da230  vmovaps [rsp+0x60], xmm7
000071c0d83da236  vmovaps [rsp+0x70], xmm8
000071c0d83da23c  vmovaps [rsp+0x80], xmm9
000071c0d83da245  vmovaps [rsp+0x90], xmm10
000071c0d83da24e  vmovaps [rsp+0xA0], xmm11
000071c0d83da257  vmovaps [rsp+0xB0], xmm12
000071c0d83da260  vmovaps [rsp+0xC0], xmm13
000071c0d83da269  vmovaps [rsp+0xD0], xmm14
000071c0d83da272  vmovaps [rsp+0xE0], xmm15
000071c0d83da27b  sub rsp, 0x30
000071c0d83da27f  movaps [rsp], xmm1
000071c0d83da283  movaps [rsp+0x10], xmm13
000071c0d83da289  movaps [rsp+0x20], xmm9
000071c0d83da28f  lea rdi, [rsp]
000071c0d83da293  mov esi, 0x00
000071c0d83da298  mov rax, 0x5904ED15D530
000071c0d83da2a2  call rax
000071c0d83da2a4  movaps xmm1, [rsp]
000071c0d83da2a8  add rsp, 0x30
000071c0d83da2ac  vmovaps xmm0, [rsp]
000071c0d83da2b1  vmovaps xmm2, [rsp+0x10]
000071c0d83da2b7  vmovaps xmm3, [rsp+0x20]
000071c0d83da2bd  vmovaps xmm4, [rsp+0x30]
000071c0d83da2c3  vmovaps xmm5, [rsp+0x40]
000071c0d83da2c9  vmovaps xmm6, [rsp+0x50]
000071c0d83da2cf  vmovaps xmm7, [rsp+0x60]
000071c0d83da2d5  vmovaps xmm8, [rsp+0x70]
000071c0d83da2db  vmovaps xmm9, [rsp+0x80]
000071c0d83da2e4  vmovaps xmm10, [rsp+0x90]
000071c0d83da2ed  vmovaps xmm11, [rsp+0xA0]
000071c0d83da2f6  vmovaps xmm12, [rsp+0xB0]
000071c0d83da2ff  vmovaps xmm13, [rsp+0xC0]
000071c0d83da308  vmovaps xmm14, [rsp+0xD0]
000071c0d83da311  vmovaps xmm15, [rsp+0xE0]
000071c0d83da31a  add rsp, 0xF0
000071c0d83da321  pop r11
000071c0d83da323  pop r10
000071c0d83da325  pop r9
000071c0d83da327  pop r8
000071c0d83da329  pop rsi
000071c0d83da32a  pop rdi
000071c0d83da32b  pop rdx
000071c0d83da32c  pop rcx
000071c0d83da32d  pop rax
000071c0d83da32e  add rsp, 0x08
000071c0d83da332  jmp 0x000071C0D83D641A
000071c0d83da337  sub rsp, 0x08
000071c0d83da33b  push rax
000071c0d83da33c  push rcx
000071c0d83da33d  push rdx
000071c0d83da33e  push rdi
000071c0d83da33f  push rsi
000071c0d83da340  push r8
000071c0d83da342  push r9
000071c0d83da344  push r10
000071c0d83da346  push r11
000071c0d83da348  sub rsp, 0xF0
000071c0d83da34f  vmovaps [rsp], xmm0
000071c0d83da354  vmovaps [rsp+0x10], xmm1
000071c0d83da35a  vmovaps [rsp+0x20], xmm2
000071c0d83da360  vmovaps [rsp+0x30], xmm3
000071c0d83da366  vmovaps [rsp+0x40], xmm4
000071c0d83da36c  vmovaps [rsp+0x50], xmm5
000071c0d83da372  vmovaps [rsp+0x60], xmm6
000071c0d83da378  vmovaps [rsp+0x70], xmm7
000071c0d83da37e  vmovaps [rsp+0x80], xmm8
000071c0d83da387  vmovaps [rsp+0x90], xmm9
000071c0d83da390  vmovaps [rsp+0xA0], xmm10
000071c0d83da399  vmovaps [rsp+0xB0], xmm11
000071c0d83da3a2  vmovaps [rsp+0xC0], xmm13
000071c0d83da3ab  vmovaps [rsp+0xD0], xmm14
000071c0d83da3b4  vmovaps [rsp+0xE0], xmm15
000071c0d83da3bd  sub rsp, 0x30
000071c0d83da3c1  movaps [rsp], xmm12
000071c0d83da3c6  movaps [rsp+0x10], xmm7
000071c0d83da3cb  movaps [rsp+0x20], xmm13
000071c0d83da3d1  lea rdi, [rsp]
000071c0d83da3d5  mov esi, 0x00
000071c0d83da3da  mov rax, 0x5904ED15D530
000071c0d83da3e4  call rax
000071c0d83da3e6  movaps xmm12, [rsp]
000071c0d83da3eb  add rsp, 0x30
000071c0d83da3ef  vmovaps xmm0, [rsp]
000071c0d83da3f4  vmovaps xmm1, [rsp+0x10]
000071c0d83da3fa  vmovaps xmm2, [rsp+0x20]
000071c0d83da400  vmovaps xmm3, [rsp+0x30]
000071c0d83da406  vmovaps xmm4, [rsp+0x40]
000071c0d83da40c  vmovaps xmm5, [rsp+0x50]
000071c0d83da412  vmovaps xmm6, [rsp+0x60]
000071c0d83da418  vmovaps xmm7, [rsp+0x70]
000071c0d83da41e  vmovaps xmm8, [rsp+0x80]
000071c0d83da427  vmovaps xmm9, [rsp+0x90]
000071c0d83da430  vmovaps xmm10, [rsp+0xA0]
000071c0d83da439  vmovaps xmm11, [rsp+0xB0]
000071c0d83da442  vmovaps xmm13, [rsp+0xC0]
000071c0d83da44b  vmovaps xmm14, [rsp+0xD0]
000071c0d83da454  vmovaps xmm15, [rsp+0xE0]
000071c0d83da45d  add rsp, 0xF0
000071c0d83da464  pop r11
000071c0d83da466  pop r10
000071c0d83da468  pop r9
000071c0d83da46a  pop r8
000071c0d83da46c  pop rsi
000071c0d83da46d  pop rdi
000071c0d83da46e  pop rdx
000071c0d83da46f  pop rcx
000071c0d83da470  pop rax
000071c0d83da471  add rsp, 0x08
000071c0d83da475  jmp 0x000071C0D83D6441
000071c0d83da47a  sub rsp, 0x08
000071c0d83da47e  push rax
000071c0d83da47f  push rcx
000071c0d83da480  push rdx
000071c0d83da481  push rdi
000071c0d83da482  push rsi
000071c0d83da483  push r8
000071c0d83da485  push r9
000071c0d83da487  push r10
000071c0d83da489  push r11
000071c0d83da48b  sub rsp, 0xF0
000071c0d83da492  vmovaps [rsp], xmm0
000071c0d83da497  vmovaps [rsp+0x10], xmm1
000071c0d83da49d  vmovaps [rsp+0x20], xmm2
000071c0d83da4a3  vmovaps [rsp+0x30], xmm3
000071c0d83da4a9  vmovaps [rsp+0x40], xmm4
000071c0d83da4af  vmovaps [rsp+0x50], xmm5
000071c0d83da4b5  vmovaps [rsp+0x60], xmm6
000071c0d83da4bb  vmovaps [rsp+0x70], xmm7
000071c0d83da4c1  vmovaps [rsp+0x80], xmm8
000071c0d83da4ca  vmovaps [rsp+0x90], xmm9
000071c0d83da4d3  vmovaps [rsp+0xA0], xmm10
000071c0d83da4dc  vmovaps [rsp+0xB0], xmm11
000071c0d83da4e5  vmovaps [rsp+0xC0], xmm12
000071c0d83da4ee  vmovaps [rsp+0xD0], xmm14
000071c0d83da4f7  vmovaps [rsp+0xE0], xmm15
000071c0d83da500  sub rsp, 0x30
000071c0d83da504  movaps [rsp], xmm13
000071c0d83da509  movaps [rsp+0x10], xmm15
000071c0d83da50f  movaps [rsp+0x20], xmm8
000071c0d83da515  lea rdi, [rsp]
000071c0d83da519  mov esi, 0x00
000071c0d83da51e  mov rax, 0x5904ED15D530
000071c0d83da528  call rax
000071c0d83da52a  movaps xmm13, [rsp]
000071c0d83da52f  add rsp, 0x30
000071c0d83da533  vmovaps xmm0, [rsp]
000071c0d83da538  vmovaps xmm1, [rsp+0x10]
000071c0d83da53e  vmovaps xmm2, [rsp+0x20]
000071c0d83da544  vmovaps xmm3, [rsp+0x30]
000071c0d83da54a  vmovaps xmm4, [rsp+0x40]
000071c0d83da550  vmovaps xmm5, [rsp+0x50]
000071c0d83da556  vmovaps xmm6, [rsp+0x60]
000071c0d83da55c  vmovaps xmm7, [rsp+0x70]
000071c0d83da562  vmovaps xmm8, [rsp+0x80]
000071c0d83da56b  vmovaps xmm9, [rsp+0x90]
000071c0d83da574  vmovaps xmm10, [rsp+0xA0]
000071c0d83da57d  vmovaps xmm11, [rsp+0xB0]
000071c0d83da586  vmovaps xmm12, [rsp+0xC0]
000071c0d83da58f  vmovaps xmm14, [rsp+0xD0]
000071c0d83da598  vmovaps xmm15, [rsp+0xE0]
000071c0d83da5a1  add rsp, 0xF0
000071c0d83da5a8  pop r11
000071c0d83da5aa  pop r10
000071c0d83da5ac  pop r9
000071c0d83da5ae  pop r8
000071c0d83da5b0  pop rsi
000071c0d83da5b1  pop rdi
000071c0d83da5b2  pop rdx
000071c0d83da5b3  pop rcx
000071c0d83da5b4  pop rax
000071c0d83da5b5  add rsp, 0x08
000071c0d83da5b9  jmp 0x000071C0D83D645C
000071c0d83da5be  sub rsp, 0x08
000071c0d83da5c2  push rax
000071c0d83da5c3  push rcx
000071c0d83da5c4  push rdx
000071c0d83da5c5  push rdi
000071c0d83da5c6  push rsi
000071c0d83da5c7  push r8
000071c0d83da5c9  push r9
000071c0d83da5cb  push r10
000071c0d83da5cd  push r11
000071c0d83da5cf  sub rsp, 0xF0
000071c0d83da5d6  vmovaps [rsp], xmm0
000071c0d83da5db  vmovaps [rsp+0x10], xmm1
000071c0d83da5e1  vmovaps [rsp+0x20], xmm2
000071c0d83da5e7  vmovaps [rsp+0x30], xmm3
000071c0d83da5ed  vmovaps [rsp+0x40], xmm4
000071c0d83da5f3  vmovaps [rsp+0x50], xmm5
000071c0d83da5f9  vmovaps [rsp+0x60], xmm6
000071c0d83da5ff  vmovaps [rsp+0x70], xmm7
000071c0d83da605  vmovaps [rsp+0x80], xmm9
000071c0d83da60e  vmovaps [rsp+0x90], xmm10
000071c0d83da617  vmovaps [rsp+0xA0], xmm11
000071c0d83da620  vmovaps [rsp+0xB0], xmm12
000071c0d83da629  vmovaps [rsp+0xC0], xmm13
000071c0d83da632  vmovaps [rsp+0xD0], xmm14
000071c0d83da63b  vmovaps [rsp+0xE0], xmm15
000071c0d83da644  sub rsp, 0x30
000071c0d83da648  movaps [rsp], xmm8
000071c0d83da64d  movaps [rsp+0x10], xmm15
000071c0d83da653  movaps [rsp+0x20], xmm9
000071c0d83da659  lea rdi, [rsp]
000071c0d83da65d  mov esi, 0x00
000071c0d83da662  mov rax, 0x5904ED15D530
000071c0d83da66c  call rax
000071c0d83da66e  movaps xmm8, [rsp]
000071c0d83da673  add rsp, 0x30
000071c0d83da677  vmovaps xmm0, [rsp]
000071c0d83da67c  vmovaps xmm1, [rsp+0x10]
000071c0d83da682  vmovaps xmm2, [rsp+0x20]
000071c0d83da688  vmovaps xmm3, [rsp+0x30]
000071c0d83da68e  vmovaps xmm4, [rsp+0x40]
000071c0d83da694  vmovaps xmm5, [rsp+0x50]
000071c0d83da69a  vmovaps xmm6, [rsp+0x60]
000071c0d83da6a0  vmovaps xmm7, [rsp+0x70]
000071c0d83da6a6  vmovaps xmm9, [rsp+0x80]
000071c0d83da6af  vmovaps xmm10, [rsp+0x90]
000071c0d83da6b8  vmovaps xmm11, [rsp+0xA0]
000071c0d83da6c1  vmovaps xmm12, [rsp+0xB0]
000071c0d83da6ca  vmovaps xmm13, [rsp+0xC0]
000071c0d83da6d3  vmovaps xmm14, [rsp+0xD0]
000071c0d83da6dc  vmovaps xmm15, [rsp+0xE0]
000071c0d83da6e5  add rsp, 0xF0
000071c0d83da6ec  pop r11
000071c0d83da6ee  pop r10
000071c0d83da6f0  pop r9
000071c0d83da6f2  pop r8
000071c0d83da6f4  pop rsi
000071c0d83da6f5  pop rdi
000071c0d83da6f6  pop rdx
000071c0d83da6f7  pop rcx
000071c0d83da6f8  pop rax
000071c0d83da6f9  add rsp, 0x08
000071c0d83da6fd  jmp 0x000071C0D83D648A
000071c0d83da702  sub rsp, 0x08
000071c0d83da706  push rax
000071c0d83da707  push rcx
000071c0d83da708  push rdx
000071c0d83da709  push rdi
000071c0d83da70a  push rsi
000071c0d83da70b  push r8
000071c0d83da70d  push r9
000071c0d83da70f  push r10
000071c0d83da711  push r11
000071c0d83da713  sub rsp, 0xF0
000071c0d83da71a  vmovaps [rsp], xmm0
000071c0d83da71f  vmovaps [rsp+0x10], xmm1
000071c0d83da725  vmovaps [rsp+0x20], xmm2
000071c0d83da72b  vmovaps [rsp+0x30], xmm3
000071c0d83da731  vmovaps [rsp+0x40], xmm4
000071c0d83da737  vmovaps [rsp+0x50], xmm5
000071c0d83da73d  vmovaps [rsp+0x60], xmm6
000071c0d83da743  vmovaps [rsp+0x70], xmm7
000071c0d83da749  vmovaps [rsp+0x80], xmm8
000071c0d83da752  vmovaps [rsp+0x90], xmm9
000071c0d83da75b  vmovaps [rsp+0xA0], xmm10
000071c0d83da764  vmovaps [rsp+0xB0], xmm11
000071c0d83da76d  vmovaps [rsp+0xC0], xmm12
000071c0d83da776  vmovaps [rsp+0xD0], xmm13
000071c0d83da77f  vmovaps [rsp+0xE0], xmm14
000071c0d83da788  sub rsp, 0x30
000071c0d83da78c  movaps [rsp], xmm15
000071c0d83da791  movaps [rsp+0x10], xmm11
000071c0d83da797  movaps [rsp+0x20], xmm6
000071c0d83da79c  lea rdi, [rsp]
000071c0d83da7a0  mov esi, 0x00
000071c0d83da7a5  mov rax, 0x5904ED15D530
000071c0d83da7af  call rax
000071c0d83da7b1  movaps xmm15, [rsp]
000071c0d83da7b6  add rsp, 0x30
000071c0d83da7ba  vmovaps xmm0, [rsp]
000071c0d83da7bf  vmovaps xmm1, [rsp+0x10]
000071c0d83da7c5  vmovaps xmm2, [rsp+0x20]
000071c0d83da7cb  vmovaps xmm3, [rsp+0x30]
000071c0d83da7d1  vmovaps xmm4, [rsp+0x40]
000071c0d83da7d7  vmovaps xmm5, [rsp+0x50]
000071c0d83da7dd  vmovaps xmm6, [rsp+0x60]
000071c0d83da7e3  vmovaps xmm7, [rsp+0x70]
000071c0d83da7e9  vmovaps xmm8, [rsp+0x80]
000071c0d83da7f2  vmovaps xmm9, [rsp+0x90]
000071c0d83da7fb  vmovaps xmm10, [rsp+0xA0]
000071c0d83da804  vmovaps xmm11, [rsp+0xB0]
000071c0d83da80d  vmovaps xmm12, [rsp+0xC0]
000071c0d83da816  vmovaps xmm13, [rsp+0xD0]
000071c0d83da81f  vmovaps xmm14, [rsp+0xE0]
000071c0d83da828  add rsp, 0xF0
000071c0d83da82f  pop r11
000071c0d83da831  pop r10
000071c0d83da833  pop r9
000071c0d83da835  pop r8
000071c0d83da837  pop rsi
000071c0d83da838  pop rdi
000071c0d83da839  pop rdx
000071c0d83da83a  pop rcx
000071c0d83da83b  pop rax
000071c0d83da83c  add rsp, 0x08
000071c0d83da840  jmp 0x000071C0D83D64A5
000071c0d83da845  sub rsp, 0x08
000071c0d83da849  push rax
000071c0d83da84a  push rcx
000071c0d83da84b  push rdx
000071c0d83da84c  push rdi
000071c0d83da84d  push rsi
000071c0d83da84e  push r8
000071c0d83da850  push r9
000071c0d83da852  push r10
000071c0d83da854  push r11
000071c0d83da856  sub rsp, 0xF0
000071c0d83da85d  vmovaps [rsp], xmm0
000071c0d83da862  vmovaps [rsp+0x10], xmm1
000071c0d83da868  vmovaps [rsp+0x20], xmm2
000071c0d83da86e  vmovaps [rsp+0x30], xmm3
000071c0d83da874  vmovaps [rsp+0x40], xmm4
000071c0d83da87a  vmovaps [rsp+0x50], xmm5
000071c0d83da880  vmovaps [rsp+0x60], xmm6
000071c0d83da886  vmovaps [rsp+0x70], xmm8
000071c0d83da88c  vmovaps [rsp+0x80], xmm9
000071c0d83da895  vmovaps [rsp+0x90], xmm10
000071c0d83da89e  vmovaps [rsp+0xA0], xmm11
000071c0d83da8a7  vmovaps [rsp+0xB0], xmm12
000071c0d83da8b0  vmovaps [rsp+0xC0], xmm13
000071c0d83da8b9  vmovaps [rsp+0xD0], xmm14
000071c0d83da8c2  vmovaps [rsp+0xE0], xmm15
000071c0d83da8cb  sub rsp, 0x30
000071c0d83da8cf  movaps [rsp], xmm7
000071c0d83da8d3  movaps [rsp+0x10], xmm11
000071c0d83da8d9  movaps [rsp+0x20], xmm9
000071c0d83da8df  lea rdi, [rsp]
000071c0d83da8e3  mov esi, 0x00
000071c0d83da8e8  mov rax, 0x5904ED15D530
000071c0d83da8f2  call rax
000071c0d83da8f4  movaps xmm7, [rsp]
000071c0d83da8f8  add rsp, 0x30
000071c0d83da8fc  vmovaps xmm0, [rsp]
000071c0d83da901  vmovaps xmm1, [rsp+0x10]
000071c0d83da907  vmovaps xmm2, [rsp+0x20]
000071c0d83da90d  vmovaps xmm3, [rsp+0x30]
000071c0d83da913  vmovaps xmm4, [rsp+0x40]
000071c0d83da919  vmovaps xmm5, [rsp+0x50]
000071c0d83da91f  vmovaps xmm6, [rsp+0x60]
000071c0d83da925  vmovaps xmm8, [rsp+0x70]
000071c0d83da92b  vmovaps xmm9, [rsp+0x80]
000071c0d83da934  vmovaps xmm10, [rsp+0x90]
000071c0d83da93d  vmovaps xmm11, [rsp+0xA0]
000071c0d83da946  vmovaps xmm12, [rsp+0xB0]
000071c0d83da94f  vmovaps xmm13, [rsp+0xC0]
000071c0d83da958  vmovaps xmm14, [rsp+0xD0]
000071c0d83da961  vmovaps xmm15, [rsp+0xE0]
000071c0d83da96a  add rsp, 0xF0
000071c0d83da971  pop r11
000071c0d83da973  pop r10
000071c0d83da975  pop r9
000071c0d83da977  pop r8
000071c0d83da979  pop rsi
000071c0d83da97a  pop rdi
000071c0d83da97b  pop rdx
000071c0d83da97c  pop rcx
000071c0d83da97d  pop rax
000071c0d83da97e  add rsp, 0x08
000071c0d83da982  jmp 0x000071C0D83D64D2
000071c0d83da987  sub rsp, 0x08
000071c0d83da98b  push rax
000071c0d83da98c  push rcx
000071c0d83da98d  push rdx
000071c0d83da98e  push rdi
000071c0d83da98f  push rsi
000071c0d83da990  push r8
000071c0d83da992  push r9
000071c0d83da994  push r10
000071c0d83da996  push r11
000071c0d83da998  sub rsp, 0xF0
000071c0d83da99f  vmovaps [rsp], xmm0
000071c0d83da9a4  vmovaps [rsp+0x10], xmm1
000071c0d83da9aa  vmovaps [rsp+0x20], xmm2
000071c0d83da9b0  vmovaps [rsp+0x30], xmm3
000071c0d83da9b6  vmovaps [rsp+0x40], xmm4
000071c0d83da9bc  vmovaps [rsp+0x50], xmm5
000071c0d83da9c2  vmovaps [rsp+0x60], xmm6
000071c0d83da9c8  vmovaps [rsp+0x70], xmm7
000071c0d83da9ce  vmovaps [rsp+0x80], xmm8
000071c0d83da9d7  vmovaps [rsp+0x90], xmm9
000071c0d83da9e0  vmovaps [rsp+0xA0], xmm10
000071c0d83da9e9  vmovaps [rsp+0xB0], xmm12
000071c0d83da9f2  vmovaps [rsp+0xC0], xmm13
000071c0d83da9fb  vmovaps [rsp+0xD0], xmm14
000071c0d83daa04  vmovaps [rsp+0xE0], xmm15
000071c0d83daa0d  sub rsp, 0x30
000071c0d83daa11  movaps [rsp], xmm11
000071c0d83daa16  movaps [rsp+0x10], xmm10
000071c0d83daa1c  movaps [rsp+0x20], xmm14
000071c0d83daa22  lea rdi, [rsp]
000071c0d83daa26  mov esi, 0x00
000071c0d83daa2b  mov rax, 0x5904ED15D530
000071c0d83daa35  call rax
000071c0d83daa37  movaps xmm11, [rsp]
000071c0d83daa3c  add rsp, 0x30
000071c0d83daa40  vmovaps xmm0, [rsp]
000071c0d83daa45  vmovaps xmm1, [rsp+0x10]
000071c0d83daa4b  vmovaps xmm2, [rsp+0x20]
000071c0d83daa51  vmovaps xmm3, [rsp+0x30]
000071c0d83daa57  vmovaps xmm4, [rsp+0x40]
000071c0d83daa5d  vmovaps xmm5, [rsp+0x50]
000071c0d83daa63  vmovaps xmm6, [rsp+0x60]
000071c0d83daa69  vmovaps xmm7, [rsp+0x70]
000071c0d83daa6f  vmovaps xmm8, [rsp+0x80]
000071c0d83daa78  vmovaps xmm9, [rsp+0x90]
000071c0d83daa81  vmovaps xmm10, [rsp+0xA0]
000071c0d83daa8a  vmovaps xmm12, [rsp+0xB0]
000071c0d83daa93  vmovaps xmm13, [rsp+0xC0]
000071c0d83daa9c  vmovaps xmm14, [rsp+0xD0]
000071c0d83daaa5  vmovaps xmm15, [rsp+0xE0]
000071c0d83daaae  add rsp, 0xF0
000071c0d83daab5  pop r11
000071c0d83daab7  pop r10
000071c0d83daab9  pop r9
000071c0d83daabb  pop r8
000071c0d83daabd  pop rsi
000071c0d83daabe  pop rdi
000071c0d83daabf  pop rdx
000071c0d83daac0  pop rcx
000071c0d83daac1  pop rax
000071c0d83daac2  add rsp, 0x08
000071c0d83daac6  jmp 0x000071C0D83D64ED
000071c0d83daacb  call 0x000071C0D82E45A0
000071c0d83daad0  jmp 0x000071C0D83D64F7
000071c0d83daad5  sub rsp, 0x08
000071c0d83daad9  push rax
000071c0d83daada  push rcx
000071c0d83daadb  push rdx
000071c0d83daadc  push rdi
000071c0d83daadd  push rsi
000071c0d83daade  push r8
000071c0d83daae0  push r9
000071c0d83daae2  push r10
000071c0d83daae4  push r11
000071c0d83daae6  sub rsp, 0xF0
000071c0d83daaed  vmovaps [rsp], xmm0
000071c0d83daaf2  vmovaps [rsp+0x10], xmm1
000071c0d83daaf8  vmovaps [rsp+0x20], xmm2
000071c0d83daafe  vmovaps [rsp+0x30], xmm3
000071c0d83dab04  vmovaps [rsp+0x40], xmm4
000071c0d83dab0a  vmovaps [rsp+0x50], xmm5
000071c0d83dab10  vmovaps [rsp+0x60], xmm6
000071c0d83dab16  vmovaps [rsp+0x70], xmm7
000071c0d83dab1c  vmovaps [rsp+0x80], xmm8
000071c0d83dab25  vmovaps [rsp+0x90], xmm9
000071c0d83dab2e  vmovaps [rsp+0xA0], xmm11
000071c0d83dab37  vmovaps [rsp+0xB0], xmm12
000071c0d83dab40  vmovaps [rsp+0xC0], xmm13
000071c0d83dab49  vmovaps [rsp+0xD0], xmm14
000071c0d83dab52  vmovaps [rsp+0xE0], xmm15
000071c0d83dab5b  sub rsp, 0x30
000071c0d83dab5f  movaps [rsp], xmm10
000071c0d83dab64  movaps [rsp+0x10], xmm1
000071c0d83dab69  movaps [rsp+0x20], xmm12
000071c0d83dab6f  lea rdi, [rsp]
000071c0d83dab73  mov esi, 0x00
000071c0d83dab78  mov rax, 0x5904ED15D530
000071c0d83dab82  call rax
000071c0d83dab84  movaps xmm10, [rsp]
000071c0d83dab89  add rsp, 0x30
000071c0d83dab8d  vmovaps xmm0, [rsp]
000071c0d83dab92  vmovaps xmm1, [rsp+0x10]
000071c0d83dab98  vmovaps xmm2, [rsp+0x20]
000071c0d83dab9e  vmovaps xmm3, [rsp+0x30]
000071c0d83daba4  vmovaps xmm4, [rsp+0x40]
000071c0d83dabaa  vmovaps xmm5, [rsp+0x50]
000071c0d83dabb0  vmovaps xmm6, [rsp+0x60]
000071c0d83dabb6  vmovaps xmm7, [rsp+0x70]
000071c0d83dabbc  vmovaps xmm8, [rsp+0x80]
000071c0d83dabc5  vmovaps xmm9, [rsp+0x90]
000071c0d83dabce  vmovaps xmm11, [rsp+0xA0]
000071c0d83dabd7  vmovaps xmm12, [rsp+0xB0]
000071c0d83dabe0  vmovaps xmm13, [rsp+0xC0]
000071c0d83dabe9  vmovaps xmm14, [rsp+0xD0]
000071c0d83dabf2  vmovaps xmm15, [rsp+0xE0]
000071c0d83dabfb  add rsp, 0xF0
000071c0d83dac02  pop r11
000071c0d83dac04  pop r10
000071c0d83dac06  pop r9
000071c0d83dac08  pop r8
000071c0d83dac0a  pop rsi
000071c0d83dac0b  pop rdi
000071c0d83dac0c  pop rdx
000071c0d83dac0d  pop rcx
000071c0d83dac0e  pop rax
000071c0d83dac0f  add rsp, 0x08
000071c0d83dac13  jmp 0x000071C0D83D651A
000071c0d83dac18  sub rsp, 0x08
000071c0d83dac1c  push rax
000071c0d83dac1d  push rcx
000071c0d83dac1e  push rdx
000071c0d83dac1f  push rdi
000071c0d83dac20  push rsi
000071c0d83dac21  push r8
000071c0d83dac23  push r9
000071c0d83dac25  push r10
000071c0d83dac27  push r11
000071c0d83dac29  sub rsp, 0xF0
000071c0d83dac30  vmovaps [rsp], xmm0
000071c0d83dac35  vmovaps [rsp+0x10], xmm1
000071c0d83dac3b  vmovaps [rsp+0x20], xmm2
000071c0d83dac41  vmovaps [rsp+0x30], xmm3
000071c0d83dac47  vmovaps [rsp+0x40], xmm4
000071c0d83dac4d  vmovaps [rsp+0x50], xmm5
000071c0d83dac53  vmovaps [rsp+0x60], xmm6
000071c0d83dac59  vmovaps [rsp+0x70], xmm7
000071c0d83dac5f  vmovaps [rsp+0x80], xmm8
000071c0d83dac68  vmovaps [rsp+0x90], xmm9
000071c0d83dac71  vmovaps [rsp+0xA0], xmm10
000071c0d83dac7a  vmovaps [rsp+0xB0], xmm11
000071c0d83dac83  vmovaps [rsp+0xC0], xmm13
000071c0d83dac8c  vmovaps [rsp+0xD0], xmm14
000071c0d83dac95  vmovaps [rsp+0xE0], xmm15
000071c0d83dac9e  sub rsp, 0x30
000071c0d83daca2  movaps [rsp], xmm12
000071c0d83daca7  movaps [rsp+0x10], xmm14
000071c0d83dacad  movaps [rsp+0x20], xmm1
000071c0d83dacb2  lea rdi, [rsp]
000071c0d83dacb6  mov esi, 0x00
000071c0d83dacbb  mov rax, 0x5904ED15D530
000071c0d83dacc5  call rax
000071c0d83dacc7  movaps xmm12, [rsp]
000071c0d83daccc  add rsp, 0x30
000071c0d83dacd0  vmovaps xmm0, [rsp]
000071c0d83dacd5  vmovaps xmm1, [rsp+0x10]
000071c0d83dacdb  vmovaps xmm2, [rsp+0x20]
000071c0d83dace1  vmovaps xmm3, [rsp+0x30]
000071c0d83dace7  vmovaps xmm4, [rsp+0x40]
000071c0d83daced  vmovaps xmm5, [rsp+0x50]
000071c0d83dacf3  vmovaps xmm6, [rsp+0x60]
000071c0d83dacf9  vmovaps xmm7, [rsp+0x70]
000071c0d83dacff  vmovaps xmm8, [rsp+0x80]
000071c0d83dad08  vmovaps xmm9, [rsp+0x90]
000071c0d83dad11  vmovaps xmm10, [rsp+0xA0]
000071c0d83dad1a  vmovaps xmm11, [rsp+0xB0]
000071c0d83dad23  vmovaps xmm13, [rsp+0xC0]
000071c0d83dad2c  vmovaps xmm14, [rsp+0xD0]
000071c0d83dad35  vmovaps xmm15, [rsp+0xE0]
000071c0d83dad3e  add rsp, 0xF0
000071c0d83dad45  pop r11
000071c0d83dad47  pop r10
000071c0d83dad49  pop r9
000071c0d83dad4b  pop r8
000071c0d83dad4d  pop rsi
000071c0d83dad4e  pop rdi
000071c0d83dad4f  pop rdx
000071c0d83dad50  pop rcx
000071c0d83dad51  pop rax
000071c0d83dad52  add rsp, 0x08
000071c0d83dad56  jmp 0x000071C0D83D6549
000071c0d83dad5b  sub rsp, 0x08
000071c0d83dad5f  push rax
000071c0d83dad60  push rcx
000071c0d83dad61  push rdx
000071c0d83dad62  push rdi
000071c0d83dad63  push rsi
000071c0d83dad64  push r8
000071c0d83dad66  push r9
000071c0d83dad68  push r10
000071c0d83dad6a  push r11
000071c0d83dad6c  sub rsp, 0xF0
000071c0d83dad73  vmovaps [rsp], xmm0
000071c0d83dad78  vmovaps [rsp+0x10], xmm1
000071c0d83dad7e  vmovaps [rsp+0x20], xmm2
000071c0d83dad84  vmovaps [rsp+0x30], xmm3
000071c0d83dad8a  vmovaps [rsp+0x40], xmm4
000071c0d83dad90  vmovaps [rsp+0x50], xmm5
000071c0d83dad96  vmovaps [rsp+0x60], xmm6
000071c0d83dad9c  vmovaps [rsp+0x70], xmm7
000071c0d83dada2  vmovaps [rsp+0x80], xmm8
000071c0d83dadab  vmovaps [rsp+0x90], xmm9
000071c0d83dadb4  vmovaps [rsp+0xA0], xmm10
000071c0d83dadbd  vmovaps [rsp+0xB0], xmm11
000071c0d83dadc6  vmovaps [rsp+0xC0], xmm12
000071c0d83dadcf  vmovaps [rsp+0xD0], xmm13
000071c0d83dadd8  vmovaps [rsp+0xE0], xmm15
000071c0d83dade1  sub rsp, 0x30
000071c0d83dade5  movaps [rsp], xmm14
000071c0d83dadea  movaps [rsp+0x10], xmm9
000071c0d83dadf0  movaps [rsp+0x20], xmm1
000071c0d83dadf5  lea rdi, [rsp]
000071c0d83dadf9  mov esi, 0x00
000071c0d83dadfe  mov rax, 0x5904ED15D530
000071c0d83dae08  call rax
000071c0d83dae0a  movaps xmm14, [rsp]
000071c0d83dae0f  add rsp, 0x30
000071c0d83dae13  vmovaps xmm0, [rsp]
000071c0d83dae18  vmovaps xmm1, [rsp+0x10]
000071c0d83dae1e  vmovaps xmm2, [rsp+0x20]
000071c0d83dae24  vmovaps xmm3, [rsp+0x30]
000071c0d83dae2a  vmovaps xmm4, [rsp+0x40]
000071c0d83dae30  vmovaps xmm5, [rsp+0x50]
000071c0d83dae36  vmovaps xmm6, [rsp+0x60]
000071c0d83dae3c  vmovaps xmm7, [rsp+0x70]
000071c0d83dae42  vmovaps xmm8, [rsp+0x80]
000071c0d83dae4b  vmovaps xmm9, [rsp+0x90]
000071c0d83dae54  vmovaps xmm10, [rsp+0xA0]
000071c0d83dae5d  vmovaps xmm11, [rsp+0xB0]
000071c0d83dae66  vmovaps xmm12, [rsp+0xC0]
000071c0d83dae6f  vmovaps xmm13, [rsp+0xD0]
000071c0d83dae78  vmovaps xmm15, [rsp+0xE0]
000071c0d83dae81  add rsp, 0xF0
000071c0d83dae88  pop r11
000071c0d83dae8a  pop r10
000071c0d83dae8c  pop r9
000071c0d83dae8e  pop r8
000071c0d83dae90  pop rsi
000071c0d83dae91  pop rdi
000071c0d83dae92  pop rdx
000071c0d83dae93  pop rcx
000071c0d83dae94  pop rax
000071c0d83dae95  add rsp, 0x08
000071c0d83dae99  jmp 0x000071C0D83D6578
000071c0d83dae9e  sub rsp, 0x08
000071c0d83daea2  push rax
000071c0d83daea3  push rcx
000071c0d83daea4  push rdx
000071c0d83daea5  push rdi
000071c0d83daea6  push rsi
000071c0d83daea7  push r8
000071c0d83daea9  push r9
000071c0d83daeab  push r10
000071c0d83daead  push r11
000071c0d83daeaf  sub rsp, 0xF0
000071c0d83daeb6  vmovaps [rsp], xmm0
000071c0d83daebb  vmovaps [rsp+0x10], xmm2
000071c0d83daec1  vmovaps [rsp+0x20], xmm3
000071c0d83daec7  vmovaps [rsp+0x30], xmm4
000071c0d83daecd  vmovaps [rsp+0x40], xmm5
000071c0d83daed3  vmovaps [rsp+0x50], xmm6
000071c0d83daed9  vmovaps [rsp+0x60], xmm7
000071c0d83daedf  vmovaps [rsp+0x70], xmm8
000071c0d83daee5  vmovaps [rsp+0x80], xmm9
000071c0d83daeee  vmovaps [rsp+0x90], xmm10
000071c0d83daef7  vmovaps [rsp+0xA0], xmm11
000071c0d83daf00  vmovaps [rsp+0xB0], xmm12
000071c0d83daf09  vmovaps [rsp+0xC0], xmm13
000071c0d83daf12  vmovaps [rsp+0xD0], xmm14
000071c0d83daf1b  vmovaps [rsp+0xE0], xmm15
000071c0d83daf24  sub rsp, 0x30
000071c0d83daf28  movaps [rsp], xmm1
000071c0d83daf2c  movaps [rsp+0x10], xmm13
000071c0d83daf32  movaps [rsp+0x20], xmm8
000071c0d83daf38  lea rdi, [rsp]
000071c0d83daf3c  mov esi, 0x00
000071c0d83daf41  mov rax, 0x5904ED15D530
000071c0d83daf4b  call rax
000071c0d83daf4d  movaps xmm1, [rsp]
000071c0d83daf51  add rsp, 0x30
000071c0d83daf55  vmovaps xmm0, [rsp]
000071c0d83daf5a  vmovaps xmm2, [rsp+0x10]
000071c0d83daf60  vmovaps xmm3, [rsp+0x20]
000071c0d83daf66  vmovaps xmm4, [rsp+0x30]
000071c0d83daf6c  vmovaps xmm5, [rsp+0x40]
000071c0d83daf72  vmovaps xmm6, [rsp+0x50]
000071c0d83daf78  vmovaps xmm7, [rsp+0x60]
000071c0d83daf7e  vmovaps xmm8, [rsp+0x70]
000071c0d83daf84  vmovaps xmm9, [rsp+0x80]
000071c0d83daf8d  vmovaps xmm10, [rsp+0x90]
000071c0d83daf96  vmovaps xmm11, [rsp+0xA0]
000071c0d83daf9f  vmovaps xmm12, [rsp+0xB0]
000071c0d83dafa8  vmovaps xmm13, [rsp+0xC0]
000071c0d83dafb1  vmovaps xmm14, [rsp+0xD0]
000071c0d83dafba  vmovaps xmm15, [rsp+0xE0]
000071c0d83dafc3  add rsp, 0xF0
000071c0d83dafca  pop r11
000071c0d83dafcc  pop r10
000071c0d83dafce  pop r9
000071c0d83dafd0  pop r8
000071c0d83dafd2  pop rsi
000071c0d83dafd3  pop rdi
000071c0d83dafd4  pop rdx
000071c0d83dafd5  pop rcx
000071c0d83dafd6  pop rax
000071c0d83dafd7  add rsp, 0x08
000071c0d83dafdb  jmp 0x000071C0D83D659A
000071c0d83dafe0  call 0x000071C0D820C260
000071c0d83dafe5  jmp 0x000071C0D83D65A8
000071c0d83dafea  call 0x000071C0D82DE950
000071c0d83dafef  jmp 0x000071C0D83D65B2
000071c0d83daff4  sub rsp, 0x08
000071c0d83daff8  push rax
000071c0d83daff9  push rcx
000071c0d83daffa  push rdx
000071c0d83daffb  push rdi
000071c0d83daffc  push rsi
000071c0d83daffd  push r8
000071c0d83dafff  push r9
000071c0d83db001  push r10
000071c0d83db003  push r11
000071c0d83db005  sub rsp, 0xF0
000071c0d83db00c  vmovaps [rsp], xmm0
000071c0d83db011  vmovaps [rsp+0x10], xmm1
000071c0d83db017  vmovaps [rsp+0x20], xmm2
000071c0d83db01d  vmovaps [rsp+0x30], xmm3
000071c0d83db023  vmovaps [rsp+0x40], xmm4
000071c0d83db029  vmovaps [rsp+0x50], xmm5
000071c0d83db02f  vmovaps [rsp+0x60], xmm6
000071c0d83db035  vmovaps [rsp+0x70], xmm7
000071c0d83db03b  vmovaps [rsp+0x80], xmm9
000071c0d83db044  vmovaps [rsp+0x90], xmm10
000071c0d83db04d  vmovaps [rsp+0xA0], xmm11
000071c0d83db056  vmovaps [rsp+0xB0], xmm12
000071c0d83db05f  vmovaps [rsp+0xC0], xmm13
000071c0d83db068  vmovaps [rsp+0xD0], xmm14
000071c0d83db071  vmovaps [rsp+0xE0], xmm15
000071c0d83db07a  sub rsp, 0x30
000071c0d83db07e  movaps [rsp], xmm8
000071c0d83db083  movaps [rsp+0x10], xmm15
000071c0d83db089  movaps [rsp+0x20], xmm7
000071c0d83db08e  lea rdi, [rsp]
000071c0d83db092  mov esi, 0x00
000071c0d83db097  mov rax, 0x5904ED15D530
000071c0d83db0a1  call rax
000071c0d83db0a3  movaps xmm8, [rsp]
000071c0d83db0a8  add rsp, 0x30
000071c0d83db0ac  vmovaps xmm0, [rsp]
000071c0d83db0b1  vmovaps xmm1, [rsp+0x10]
000071c0d83db0b7  vmovaps xmm2, [rsp+0x20]
000071c0d83db0bd  vmovaps xmm3, [rsp+0x30]
000071c0d83db0c3  vmovaps xmm4, [rsp+0x40]
000071c0d83db0c9  vmovaps xmm5, [rsp+0x50]
000071c0d83db0cf  vmovaps xmm6, [rsp+0x60]
000071c0d83db0d5  vmovaps xmm7, [rsp+0x70]
000071c0d83db0db  vmovaps xmm9, [rsp+0x80]
000071c0d83db0e4  vmovaps xmm10, [rsp+0x90]
000071c0d83db0ed  vmovaps xmm11, [rsp+0xA0]
000071c0d83db0f6  vmovaps xmm12, [rsp+0xB0]
000071c0d83db0ff  vmovaps xmm13, [rsp+0xC0]
000071c0d83db108  vmovaps xmm14, [rsp+0xD0]
000071c0d83db111  vmovaps xmm15, [rsp+0xE0]
000071c0d83db11a  add rsp, 0xF0
000071c0d83db121  pop r11
000071c0d83db123  pop r10
000071c0d83db125  pop r9
000071c0d83db127  pop r8
000071c0d83db129  pop rsi
000071c0d83db12a  pop rdi
000071c0d83db12b  pop rdx
000071c0d83db12c  pop rcx
000071c0d83db12d  pop rax
000071c0d83db12e  add rsp, 0x08
000071c0d83db132  jmp 0x000071C0D83D65D4
000071c0d83db137  sub rsp, 0x08
000071c0d83db13b  push rax
000071c0d83db13c  push rcx
000071c0d83db13d  push rdx
000071c0d83db13e  push rdi
000071c0d83db13f  push rsi
000071c0d83db140  push r8
000071c0d83db142  push r9
000071c0d83db144  push r10
000071c0d83db146  push r11
000071c0d83db148  sub rsp, 0xF0
000071c0d83db14f  vmovaps [rsp], xmm0
000071c0d83db154  vmovaps [rsp+0x10], xmm1
000071c0d83db15a  vmovaps [rsp+0x20], xmm2
000071c0d83db160  vmovaps [rsp+0x30], xmm3
000071c0d83db166  vmovaps [rsp+0x40], xmm4
000071c0d83db16c  vmovaps [rsp+0x50], xmm5
000071c0d83db172  vmovaps [rsp+0x60], xmm6
000071c0d83db178  vmovaps [rsp+0x70], xmm8
000071c0d83db17e  vmovaps [rsp+0x80], xmm9
000071c0d83db187  vmovaps [rsp+0x90], xmm10
000071c0d83db190  vmovaps [rsp+0xA0], xmm11
000071c0d83db199  vmovaps [rsp+0xB0], xmm12
000071c0d83db1a2  vmovaps [rsp+0xC0], xmm13
000071c0d83db1ab  vmovaps [rsp+0xD0], xmm14
000071c0d83db1b4  vmovaps [rsp+0xE0], xmm15
000071c0d83db1bd  sub rsp, 0x30
000071c0d83db1c1  movaps [rsp], xmm7
000071c0d83db1c5  movaps [rsp+0x10], xmm9
000071c0d83db1cb  movaps [rsp+0x20], xmm15
000071c0d83db1d1  lea rdi, [rsp]
000071c0d83db1d5  mov esi, 0x00
000071c0d83db1da  mov rax, 0x5904ED15D530
000071c0d83db1e4  call rax
000071c0d83db1e6  movaps xmm7, [rsp]
000071c0d83db1ea  add rsp, 0x30
000071c0d83db1ee  vmovaps xmm0, [rsp]
000071c0d83db1f3  vmovaps xmm1, [rsp+0x10]
000071c0d83db1f9  vmovaps xmm2, [rsp+0x20]
000071c0d83db1ff  vmovaps xmm3, [rsp+0x30]
000071c0d83db205  vmovaps xmm4, [rsp+0x40]
000071c0d83db20b  vmovaps xmm5, [rsp+0x50]
000071c0d83db211  vmovaps xmm6, [rsp+0x60]
000071c0d83db217  vmovaps xmm8, [rsp+0x70]
000071c0d83db21d  vmovaps xmm9, [rsp+0x80]
000071c0d83db226  vmovaps xmm10, [rsp+0x90]
000071c0d83db22f  vmovaps xmm11, [rsp+0xA0]
000071c0d83db238  vmovaps xmm12, [rsp+0xB0]
000071c0d83db241  vmovaps xmm13, [rsp+0xC0]
000071c0d83db24a  vmovaps xmm14, [rsp+0xD0]
000071c0d83db253  vmovaps xmm15, [rsp+0xE0]
000071c0d83db25c  add rsp, 0xF0
000071c0d83db263  pop r11
000071c0d83db265  pop r10
000071c0d83db267  pop r9
000071c0d83db269  pop r8
000071c0d83db26b  pop rsi
000071c0d83db26c  pop rdi
000071c0d83db26d  pop rdx
000071c0d83db26e  pop rcx
000071c0d83db26f  pop rax
000071c0d83db270  add rsp, 0x08
000071c0d83db274  jmp 0x000071C0D83D6601
000071c0d83db279  sub rsp, 0x08
000071c0d83db27d  push rax
000071c0d83db27e  push rcx
000071c0d83db27f  push rdx
000071c0d83db280  push rdi
000071c0d83db281  push rsi
000071c0d83db282  push r8
000071c0d83db284  push r9
000071c0d83db286  push r10
000071c0d83db288  push r11
000071c0d83db28a  sub rsp, 0xF0
000071c0d83db291  vmovaps [rsp], xmm0
000071c0d83db296  vmovaps [rsp+0x10], xmm1
000071c0d83db29c  vmovaps [rsp+0x20], xmm2
000071c0d83db2a2  vmovaps [rsp+0x30], xmm3
000071c0d83db2a8  vmovaps [rsp+0x40], xmm4
000071c0d83db2ae  vmovaps [rsp+0x50], xmm5
000071c0d83db2b4  vmovaps [rsp+0x60], xmm6
000071c0d83db2ba  vmovaps [rsp+0x70], xmm7
000071c0d83db2c0  vmovaps [rsp+0x80], xmm8
000071c0d83db2c9  vmovaps [rsp+0x90], xmm10
000071c0d83db2d2  vmovaps [rsp+0xA0], xmm11
000071c0d83db2db  vmovaps [rsp+0xB0], xmm12
000071c0d83db2e4  vmovaps [rsp+0xC0], xmm13
000071c0d83db2ed  vmovaps [rsp+0xD0], xmm14
000071c0d83db2f6  vmovaps [rsp+0xE0], xmm15
000071c0d83db2ff  sub rsp, 0x30
000071c0d83db303  movaps [rsp], xmm9
000071c0d83db308  movaps [rsp+0x10], xmm13
000071c0d83db30e  movaps [rsp+0x20], xmm15
000071c0d83db314  lea rdi, [rsp]
000071c0d83db318  mov esi, 0x00
000071c0d83db31d  mov rax, 0x5904ED15D530
000071c0d83db327  call rax
000071c0d83db329  movaps xmm9, [rsp]
000071c0d83db32e  add rsp, 0x30
000071c0d83db332  vmovaps xmm0, [rsp]
000071c0d83db337  vmovaps xmm1, [rsp+0x10]
000071c0d83db33d  vmovaps xmm2, [rsp+0x20]
000071c0d83db343  vmovaps xmm3, [rsp+0x30]
000071c0d83db349  vmovaps xmm4, [rsp+0x40]
000071c0d83db34f  vmovaps xmm5, [rsp+0x50]
000071c0d83db355  vmovaps xmm6, [rsp+0x60]
000071c0d83db35b  vmovaps xmm7, [rsp+0x70]
000071c0d83db361  vmovaps xmm8, [rsp+0x80]
000071c0d83db36a  vmovaps xmm10, [rsp+0x90]
000071c0d83db373  vmovaps xmm11, [rsp+0xA0]
000071c0d83db37c  vmovaps xmm12, [rsp+0xB0]
000071c0d83db385  vmovaps xmm13, [rsp+0xC0]
000071c0d83db38e  vmovaps xmm14, [rsp+0xD0]
000071c0d83db397  vmovaps xmm15, [rsp+0xE0]
000071c0d83db3a0  add rsp, 0xF0
000071c0d83db3a7  pop r11
000071c0d83db3a9  pop r10
000071c0d83db3ab  pop r9
000071c0d83db3ad  pop r8
000071c0d83db3af  pop rsi
000071c0d83db3b0  pop rdi
000071c0d83db3b1  pop rdx
000071c0d83db3b2  pop rcx
000071c0d83db3b3  pop rax
000071c0d83db3b4  add rsp, 0x08
000071c0d83db3b8  jmp 0x000071C0D83D662F
000071c0d83db3bd  sub rsp, 0x08
000071c0d83db3c1  push rax
000071c0d83db3c2  push rcx
000071c0d83db3c3  push rdx
000071c0d83db3c4  push rdi
000071c0d83db3c5  push rsi
000071c0d83db3c6  push r8
000071c0d83db3c8  push r9
000071c0d83db3ca  push r10
000071c0d83db3cc  push r11
000071c0d83db3ce  sub rsp, 0xF0
000071c0d83db3d5  vmovaps [rsp], xmm0
000071c0d83db3da  vmovaps [rsp+0x10], xmm1
000071c0d83db3e0  vmovaps [rsp+0x20], xmm2
000071c0d83db3e6  vmovaps [rsp+0x30], xmm3
000071c0d83db3ec  vmovaps [rsp+0x40], xmm4
000071c0d83db3f2  vmovaps [rsp+0x50], xmm5
000071c0d83db3f8  vmovaps [rsp+0x60], xmm6
000071c0d83db3fe  vmovaps [rsp+0x70], xmm7
000071c0d83db404  vmovaps [rsp+0x80], xmm8
000071c0d83db40d  vmovaps [rsp+0x90], xmm9
000071c0d83db416  vmovaps [rsp+0xA0], xmm10
000071c0d83db41f  vmovaps [rsp+0xB0], xmm11
000071c0d83db428  vmovaps [rsp+0xC0], xmm12
000071c0d83db431  vmovaps [rsp+0xD0], xmm13
000071c0d83db43a  vmovaps [rsp+0xE0], xmm14
000071c0d83db443  sub rsp, 0x30
000071c0d83db447  movaps [rsp], xmm15
000071c0d83db44c  movaps [rsp+0x10], xmm11
000071c0d83db452  movaps [rsp+0x20], xmm12
000071c0d83db458  lea rdi, [rsp]
000071c0d83db45c  mov esi, 0x00
000071c0d83db461  mov rax, 0x5904ED15D530
000071c0d83db46b  call rax
000071c0d83db46d  movaps xmm15, [rsp]
000071c0d83db472  add rsp, 0x30
000071c0d83db476  vmovaps xmm0, [rsp]
000071c0d83db47b  vmovaps xmm1, [rsp+0x10]
000071c0d83db481  vmovaps xmm2, [rsp+0x20]
000071c0d83db487  vmovaps xmm3, [rsp+0x30]
000071c0d83db48d  vmovaps xmm4, [rsp+0x40]
000071c0d83db493  vmovaps xmm5, [rsp+0x50]
000071c0d83db499  vmovaps xmm6, [rsp+0x60]
000071c0d83db49f  vmovaps xmm7, [rsp+0x70]
000071c0d83db4a5  vmovaps xmm8, [rsp+0x80]
000071c0d83db4ae  vmovaps xmm9, [rsp+0x90]
000071c0d83db4b7  vmovaps xmm10, [rsp+0xA0]
000071c0d83db4c0  vmovaps xmm11, [rsp+0xB0]
000071c0d83db4c9  vmovaps xmm12, [rsp+0xC0]
000071c0d83db4d2  vmovaps xmm13, [rsp+0xD0]
000071c0d83db4db  vmovaps xmm14, [rsp+0xE0]
000071c0d83db4e4  add rsp, 0xF0
000071c0d83db4eb  pop r11
000071c0d83db4ed  pop r10
000071c0d83db4ef  pop r9
000071c0d83db4f1  pop r8
000071c0d83db4f3  pop rsi
000071c0d83db4f4  pop rdi
000071c0d83db4f5  pop rdx
000071c0d83db4f6  pop rcx
000071c0d83db4f7  pop rax
000071c0d83db4f8  add rsp, 0x08
000071c0d83db4fc  jmp 0x000071C0D83D664A
000071c0d83db501  sub rsp, 0x08
000071c0d83db505  push rax
000071c0d83db506  push rcx
000071c0d83db507  push rdx
000071c0d83db508  push rdi
000071c0d83db509  push rsi
000071c0d83db50a  push r8
000071c0d83db50c  push r9
000071c0d83db50e  push r10
000071c0d83db510  push r11
000071c0d83db512  sub rsp, 0xF0
000071c0d83db519  vmovaps [rsp], xmm0
000071c0d83db51e  vmovaps [rsp+0x10], xmm1
000071c0d83db524  vmovaps [rsp+0x20], xmm2
000071c0d83db52a  vmovaps [rsp+0x30], xmm3
000071c0d83db530  vmovaps [rsp+0x40], xmm4
000071c0d83db536  vmovaps [rsp+0x50], xmm5
000071c0d83db53c  vmovaps [rsp+0x60], xmm6
000071c0d83db542  vmovaps [rsp+0x70], xmm7
000071c0d83db548  vmovaps [rsp+0x80], xmm8
000071c0d83db551  vmovaps [rsp+0x90], xmm9
000071c0d83db55a  vmovaps [rsp+0xA0], xmm10
000071c0d83db563  vmovaps [rsp+0xB0], xmm11
000071c0d83db56c  vmovaps [rsp+0xC0], xmm12
000071c0d83db575  vmovaps [rsp+0xD0], xmm14
000071c0d83db57e  vmovaps [rsp+0xE0], xmm15
000071c0d83db587  sub rsp, 0x30
000071c0d83db58b  movaps [rsp], xmm13
000071c0d83db590  movaps [rsp+0x10], xmm10
000071c0d83db596  movaps [rsp+0x20], xmm14
000071c0d83db59c  lea rdi, [rsp]
000071c0d83db5a0  mov esi, 0x00
000071c0d83db5a5  mov rax, 0x5904ED15D530
000071c0d83db5af  call rax
000071c0d83db5b1  movaps xmm13, [rsp]
000071c0d83db5b6  add rsp, 0x30
000071c0d83db5ba  vmovaps xmm0, [rsp]
000071c0d83db5bf  vmovaps xmm1, [rsp+0x10]
000071c0d83db5c5  vmovaps xmm2, [rsp+0x20]
000071c0d83db5cb  vmovaps xmm3, [rsp+0x30]
000071c0d83db5d1  vmovaps xmm4, [rsp+0x40]
000071c0d83db5d7  vmovaps xmm5, [rsp+0x50]
000071c0d83db5dd  vmovaps xmm6, [rsp+0x60]
000071c0d83db5e3  vmovaps xmm7, [rsp+0x70]
000071c0d83db5e9  vmovaps xmm8, [rsp+0x80]
000071c0d83db5f2  vmovaps xmm9, [rsp+0x90]
000071c0d83db5fb  vmovaps xmm10, [rsp+0xA0]
000071c0d83db604  vmovaps xmm11, [rsp+0xB0]
000071c0d83db60d  vmovaps xmm12, [rsp+0xC0]
000071c0d83db616  vmovaps xmm14, [rsp+0xD0]
000071c0d83db61f  vmovaps xmm15, [rsp+0xE0]
000071c0d83db628  add rsp, 0xF0
000071c0d83db62f  pop r11
000071c0d83db631  pop r10
000071c0d83db633  pop r9
000071c0d83db635  pop r8
000071c0d83db637  pop rsi
000071c0d83db638  pop rdi
000071c0d83db639  pop rdx
000071c0d83db63a  pop rcx
000071c0d83db63b  pop rax
000071c0d83db63c  add rsp, 0x08
000071c0d83db640  jmp 0x000071C0D83D666D
000071c0d83db645  sub rsp, 0x08
000071c0d83db649  push rax
000071c0d83db64a  push rcx
000071c0d83db64b  push rdx
000071c0d83db64c  push rdi
000071c0d83db64d  push rsi
000071c0d83db64e  push r8
000071c0d83db650  push r9
000071c0d83db652  push r10
000071c0d83db654  push r11
000071c0d83db656  sub rsp, 0xF0
000071c0d83db65d  vmovaps [rsp], xmm0
000071c0d83db662  vmovaps [rsp+0x10], xmm1
000071c0d83db668  vmovaps [rsp+0x20], xmm2
000071c0d83db66e  vmovaps [rsp+0x30], xmm3
000071c0d83db674  vmovaps [rsp+0x40], xmm4
000071c0d83db67a  vmovaps [rsp+0x50], xmm5
000071c0d83db680  vmovaps [rsp+0x60], xmm6
000071c0d83db686  vmovaps [rsp+0x70], xmm7
000071c0d83db68c  vmovaps [rsp+0x80], xmm8
000071c0d83db695  vmovaps [rsp+0x90], xmm9
000071c0d83db69e  vmovaps [rsp+0xA0], xmm10
000071c0d83db6a7  vmovaps [rsp+0xB0], xmm11
000071c0d83db6b0  vmovaps [rsp+0xC0], xmm12
000071c0d83db6b9  vmovaps [rsp+0xD0], xmm13
000071c0d83db6c2  vmovaps [rsp+0xE0], xmm15
000071c0d83db6cb  sub rsp, 0x30
000071c0d83db6cf  movaps [rsp], xmm14
000071c0d83db6d4  movaps [rsp+0x10], xmm1
000071c0d83db6d9  movaps [rsp+0x20], xmm7
000071c0d83db6de  lea rdi, [rsp]
000071c0d83db6e2  mov esi, 0x00
000071c0d83db6e7  mov rax, 0x5904ED15D530
000071c0d83db6f1  call rax
000071c0d83db6f3  movaps xmm14, [rsp]
000071c0d83db6f8  add rsp, 0x30
000071c0d83db6fc  vmovaps xmm0, [rsp]
000071c0d83db701  vmovaps xmm1, [rsp+0x10]
000071c0d83db707  vmovaps xmm2, [rsp+0x20]
000071c0d83db70d  vmovaps xmm3, [rsp+0x30]
000071c0d83db713  vmovaps xmm4, [rsp+0x40]
000071c0d83db719  vmovaps xmm5, [rsp+0x50]
000071c0d83db71f  vmovaps xmm6, [rsp+0x60]
000071c0d83db725  vmovaps xmm7, [rsp+0x70]
000071c0d83db72b  vmovaps xmm8, [rsp+0x80]
000071c0d83db734  vmovaps xmm9, [rsp+0x90]
000071c0d83db73d  vmovaps xmm10, [rsp+0xA0]
000071c0d83db746  vmovaps xmm11, [rsp+0xB0]
000071c0d83db74f  vmovaps xmm12, [rsp+0xC0]
000071c0d83db758  vmovaps xmm13, [rsp+0xD0]
000071c0d83db761  vmovaps xmm15, [rsp+0xE0]
000071c0d83db76a  add rsp, 0xF0
000071c0d83db771  pop r11
000071c0d83db773  pop r10
000071c0d83db775  pop r9
000071c0d83db777  pop r8
000071c0d83db779  pop rsi
000071c0d83db77a  pop rdi
000071c0d83db77b  pop rdx
000071c0d83db77c  pop rcx
000071c0d83db77d  pop rax
000071c0d83db77e  add rsp, 0x08
000071c0d83db782  jmp 0x000071C0D83D6690
000071c0d83db787  sub rsp, 0x08
000071c0d83db78b  push rax
000071c0d83db78c  push rcx
000071c0d83db78d  push rdx
000071c0d83db78e  push rdi
000071c0d83db78f  push rsi
000071c0d83db790  push r8
000071c0d83db792  push r9
000071c0d83db794  push r10
000071c0d83db796  push r11
000071c0d83db798  sub rsp, 0xF0
000071c0d83db79f  vmovaps [rsp], xmm0
000071c0d83db7a4  vmovaps [rsp+0x10], xmm2
000071c0d83db7aa  vmovaps [rsp+0x20], xmm3
000071c0d83db7b0  vmovaps [rsp+0x30], xmm4
000071c0d83db7b6  vmovaps [rsp+0x40], xmm5
000071c0d83db7bc  vmovaps [rsp+0x50], xmm6
000071c0d83db7c2  vmovaps [rsp+0x60], xmm7
000071c0d83db7c8  vmovaps [rsp+0x70], xmm8
000071c0d83db7ce  vmovaps [rsp+0x80], xmm9
000071c0d83db7d7  vmovaps [rsp+0x90], xmm10
000071c0d83db7e0  vmovaps [rsp+0xA0], xmm11
000071c0d83db7e9  vmovaps [rsp+0xB0], xmm12
000071c0d83db7f2  vmovaps [rsp+0xC0], xmm13
000071c0d83db7fb  vmovaps [rsp+0xD0], xmm14
000071c0d83db804  vmovaps [rsp+0xE0], xmm15
000071c0d83db80d  sub rsp, 0x30
000071c0d83db811  movaps [rsp], xmm1
000071c0d83db815  movaps [rsp+0x10], xmm8
000071c0d83db81b  movaps [rsp+0x20], xmm9
000071c0d83db821  lea rdi, [rsp]
000071c0d83db825  mov esi, 0x00
000071c0d83db82a  mov rax, 0x5904ED15D530
000071c0d83db834  call rax
000071c0d83db836  movaps xmm1, [rsp]
000071c0d83db83a  add rsp, 0x30
000071c0d83db83e  vmovaps xmm0, [rsp]
000071c0d83db843  vmovaps xmm2, [rsp+0x10]
000071c0d83db849  vmovaps xmm3, [rsp+0x20]
000071c0d83db84f  vmovaps xmm4, [rsp+0x30]
000071c0d83db855  vmovaps xmm5, [rsp+0x40]
000071c0d83db85b  vmovaps xmm6, [rsp+0x50]
000071c0d83db861  vmovaps xmm7, [rsp+0x60]
000071c0d83db867  vmovaps xmm8, [rsp+0x70]
000071c0d83db86d  vmovaps xmm9, [rsp+0x80]
000071c0d83db876  vmovaps xmm10, [rsp+0x90]
000071c0d83db87f  vmovaps xmm11, [rsp+0xA0]
000071c0d83db888  vmovaps xmm12, [rsp+0xB0]
000071c0d83db891  vmovaps xmm13, [rsp+0xC0]
000071c0d83db89a  vmovaps xmm14, [rsp+0xD0]
000071c0d83db8a3  vmovaps xmm15, [rsp+0xE0]
000071c0d83db8ac  add rsp, 0xF0
000071c0d83db8b3  pop r11
000071c0d83db8b5  pop r10
000071c0d83db8b7  pop r9
000071c0d83db8b9  pop r8
000071c0d83db8bb  pop rsi
000071c0d83db8bc  pop rdi
000071c0d83db8bd  pop rdx
000071c0d83db8be  pop rcx
000071c0d83db8bf  pop rax
000071c0d83db8c0  add rsp, 0x08
000071c0d83db8c4  jmp 0x000071C0D83D66B2
000071c0d83db8c9  call 0x000071C0D82B3E40
000071c0d83db8ce  jmp 0x000071C0D83D66C0
000071c0d83db8d3  call 0x000071C0D820C380
000071c0d83db8d8  jmp 0x000071C0D83D66CA
000071c0d83db8dd  call 0x000071C0D820D600
000071c0d83db8e2  jmp 0x000071C0D83D66D4
000071c0d83db8e7  call 0x000071C0D81FF540
000071c0d83db8ec  jmp 0x000071C0D83D66DE
000071c0d83db8f1  int3
000071c0d83db8f2  nop [rax+rax*1], ax
000071c0d83db8fb  nop [rax+rax*1], eax
000071c0d83db900  mov eax, [r15+0x48]
000071c0d83db904  lea r14d, [eax+0x01]
000071c0d83db909  mov [rsp+0x10], r14d
000071c0d83db90e  mov r14d, r14d
000071c0d83db911  mov [r15+0x48], r14
000071c0d83db915  xor eax, eax
000071c0d83db917  mov r14d, [rsp+0x10]
000071c0d83db91c  cmp r14d, 0x1F4
000071c0d83db923  cmc
000071c0d83db924  lahf
000071c0d83db925  seto al
000071c0d83db928  mov [r15+0x108], eax
000071c0d83db92f  mov eax, [r15+0x108]
000071c0d83db936  sahf
000071c0d83db937  jnz 0x000071C0D83DB969
000071c0d83db939  cmp dword ptr [r15+0x318], 0x00
000071c0d83db941  jz 0x000071C0D83E1AB0
000071c0d83db947  nop [rax+rax*1], ax
000071c0d83db950  nop [rax+rax*1], eax
000071c0d83db958  mov eax, 0x410450
000071c0d83db95d  mov [r15+0x100], rax
000071c0d83db964  jmp 0x000071C0D81FE110
000071c0d83db969  cmp dword ptr [r15+0x318], 0x00
000071c0d83db971  jz 0x000071C0D83DB9A0
000071c0d83db977  nop [rax+rax*1], ax
000071c0d83db980  nop [rax+rax*1], eax
000071c0d83db988  mov eax, 0x410274
000071c0d83db98d  mov [r15+0x100], rax
000071c0d83db994  jmp 0x000071C0D81FE110
000071c0d83db999  int3
000071c0d83db99a  int3
000071c0d83db99b  nop [rax+rax*1], eax
000071c0d83db9a0  mov rax, [r15+0x40]
000071c0d83db9a4  movaps xmm1, [r15+0x1D0]
000071c0d83db9ac  vmovaps [rsp+0x10], xmm1
000071c0d83db9b2  vmovaps xmm15, [rsp+0x10]
000071c0d83db9b8  por xmm1, xmm15
000071c0d83db9bd  movaps xmm14, [r15+0x1A0]
000071c0d83db9c5  vmovaps [rsp+0x10], xmm14
000071c0d83db9cb  vmovaps xmm13, [rsp+0x10]
000071c0d83db9d1  por xmm14, xmm13
000071c0d83db9d6  lea r14, [rax+0x30]
000071c0d83db9da  mov r12, [r13+r14*1]
000071c0d83db9df  lea r14, [rax+0x38]
000071c0d83db9e3  mov r11, [r13+r14*1]
000071c0d83db9e8  movq xmm13, r12
000071c0d83db9ed  movq xmm12, r11
000071c0d83db9f2  movq xmm13, xmm13
000071c0d83db9f7  vmovaps [rsp+0x10], xmm13
000071c0d83db9fd  movq xmm13, xmm13
000071c0d83dba02  movaps [r15+0x130], xmm13
000071c0d83dba0a  movq xmm12, xmm12
000071c0d83dba0f  vmovaps [rsp+0x20], xmm12
000071c0d83dba15  movq xmm12, xmm12
000071c0d83dba1a  movaps [r15+0x280], xmm12
000071c0d83dba22  movaps xmm13, [r15+0x270]
000071c0d83dba2a  vmovaps [rsp+0x30], xmm13
000071c0d83dba30  vmovaps xmm12, [rsp+0x30]
000071c0d83dba36  por xmm13, xmm12
000071c0d83dba3b  lea r14, [rax+0x20]
000071c0d83dba3f  mov r12, [r13+r14*1]
000071c0d83dba44  lea r14, [rax+0x28]
000071c0d83dba48  mov r11, [r13+r14*1]
000071c0d83dba4d  movq xmm12, r12
000071c0d83dba52  movq xmm11, r11
000071c0d83dba57  movq xmm12, xmm12
000071c0d83dba5c  vmovaps [rsp+0x30], xmm12
000071c0d83dba62  movq xmm12, xmm12
000071c0d83dba67  movaps [r15+0x150], xmm12
000071c0d83dba6f  movq xmm11, xmm11
000071c0d83dba74  vmovaps [rsp+0x40], xmm11
000071c0d83dba7a  movq xmm11, xmm11
000071c0d83dba7f  movaps [r15+0x140], xmm11
000071c0d83dba87  lea r14, [rax+0x10]
000071c0d83dba8b  mov r12, [r13+r14*1]
000071c0d83dba90  lea r14, [rax+0x18]
000071c0d83dba94  mov r11, [r13+r14*1]
000071c0d83dba99  movq xmm12, r12
000071c0d83dba9e  movq xmm11, r11
000071c0d83dbaa3  movq xmm12, xmm12
000071c0d83dbaa8  vmovaps [rsp+0x50], xmm12
000071c0d83dbaae  movq xmm12, xmm12
000071c0d83dbab3  movaps [r15+0x170], xmm12
000071c0d83dbabb  movq xmm11, xmm11
000071c0d83dbac0  vmovaps [rsp+0x60], xmm11
000071c0d83dbac6  movq xmm11, xmm11
000071c0d83dbacb  movaps [r15+0x160], xmm11
000071c0d83dbad3  mov r14, [r13+rax*1]
000071c0d83dbad8  vmovq xmm12, r14
000071c0d83dbadd  vpbroadcastq xmm12, xmm12
000071c0d83dbae2  lea r14, [rax+0x08]
000071c0d83dbae6  mov rax, [r13+r14*1]
000071c0d83dbaeb  movq xmm11, rax
000071c0d83dbaf0  movaps [r15+0x230], xmm11
000071c0d83dbaf8  mov rax, [r15+0xF8]
000071c0d83dbaff  lea r14, [rax+0x50]
000071c0d83dbb03  movups xmm11, [r13+r14*1]
000071c0d83dbb09  lea r14, [rax+0x60]
000071c0d83dbb0d  movups xmm10, [r13+r14*1]
000071c0d83dbb13  lea r14, [rax+0x30]
000071c0d83dbb17  movups xmm9, [r13+r14*1]
000071c0d83dbb1d  mov r14, [r15+0x50]
000071c0d83dbb21  mov [r15+0x60], r14
000071c0d83dbb25  mov qword ptr [r15+0x58], 0x40
000071c0d83dbb2d  movaps xmm8, xmm12
000071c0d83dbb31  mulpd xmm8, xmm15
000071c0d83dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000071c0d83dbb3c  ptest xmm7, xmm7
000071c0d83dbb41  jnz 0x000071C0D83DC96A
000071c0d83dbb47  movq xmm15, qword ptr [r15+0x230]
000071c0d83dbb50  vmovaps [rsp+0x70], xmm15
000071c0d83dbb56  vpermilpd xmm15, xmm15, 0x00
000071c0d83dbb5c  movaps xmm7, xmm9
000071c0d83dbb60  mulpd xmm7, xmm15
000071c0d83dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000071c0d83dbb6a  ptest xmm6, xmm6
000071c0d83dbb6f  jnz 0x000071C0D83DCAAE
000071c0d83dbb75  vxorps xmm15, xmm15, xmm15
000071c0d83dbb7a  vpbroadcastq xmm15, xmm15
000071c0d83dbb7f  movaps xmm9, xmm12
000071c0d83dbb83  mulpd xmm9, xmm10
000071c0d83dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000071c0d83dbb8e  ptest xmm6, xmm6
000071c0d83dbb93  jnz 0x000071C0D83DCBF0
000071c0d83dbb99  movaps xmm10, xmm12
000071c0d83dbb9d  mulpd xmm10, xmm11
000071c0d83dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000071c0d83dbba8  ptest xmm6, xmm6
000071c0d83dbbad  jnz 0x000071C0D83DCD34
000071c0d83dbbb3  movaps xmm11, [r15+0x1F0]
000071c0d83dbbbb  movaps xmm6, xmm12
000071c0d83dbbbf  mulpd xmm6, xmm11
000071c0d83dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000071c0d83dbbc9  ptest xmm5, xmm5
000071c0d83dbbce  jnz 0x000071C0D83DCE78
000071c0d83dbbd4  movaps xmm12, [r15+0x2A0]
000071c0d83dbbdc  vmovaps [rsp+0x80], xmm12
000071c0d83dbbe5  vmovaps xmm11, [rsp+0x80]
000071c0d83dbbee  por xmm12, xmm11
000071c0d83dbbf3  movaps xmm11, [r15+0x250]
000071c0d83dbbfb  vmovaps [rsp+0x80], xmm11
000071c0d83dbc04  vmovaps xmm5, [rsp+0x80]
000071c0d83dbc0d  por xmm11, xmm5
000071c0d83dbc12  vmovaps xmm4, [rsp+0x70]
000071c0d83dbc18  vpermilpd xmm4, xmm4, 0x00
000071c0d83dbc1e  movaps xmm3, xmm5
000071c0d83dbc21  mulpd xmm3, xmm4
000071c0d83dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000071c0d83dbc2a  ptest xmm2, xmm2
000071c0d83dbc2f  jnz 0x000071C0D83DCFBA
000071c0d83dbc35  mov [rsp+0x80], rax
000071c0d83dbc3d  xor eax, eax
000071c0d83dbc3f  mov r12d, 0x40
000071c0d83dbc45  mov r11d, 0x200
000071c0d83dbc4b  cmp r12, r11
000071c0d83dbc4e  cmc
000071c0d83dbc4f  lahf
000071c0d83dbc50  seto al
000071c0d83dbc53  mov [r15+0x108], eax
000071c0d83dbc5a  movaps xmm5, xmm8
000071c0d83dbc5e  addpd xmm5, xmm15
000071c0d83dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000071c0d83dbc68  ptest xmm4, xmm4
000071c0d83dbc6d  jnz 0x000071C0D83DD0FA
000071c0d83dbc73  movaps xmm8, [r15+0x1B0]
000071c0d83dbc7b  movaps xmm4, xmm9
000071c0d83dbc7f  addpd xmm4, xmm8
000071c0d83dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000071c0d83dbc89  ptest xmm2, xmm2
000071c0d83dbc8e  jnz 0x000071C0D83DD23C
000071c0d83dbc94  movaps xmm9, xmm10
000071c0d83dbc98  addpd xmm9, xmm8
000071c0d83dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000071c0d83dbca3  ptest xmm2, xmm2
000071c0d83dbca8  jnz 0x000071C0D83DD37E
000071c0d83dbcae  movaps xmm10, [r15+0x2F0]
000071c0d83dbcb6  vmovaps [rsp+0x90], xmm10
000071c0d83dbcbf  vmovaps xmm8, [rsp+0x90]
000071c0d83dbcc8  por xmm10, xmm8
000071c0d83dbccd  movaps xmm8, [r15+0x2E0]
000071c0d83dbcd5  vmovaps [rsp+0x90], xmm8
000071c0d83dbcde  vmovaps xmm2, [rsp+0x90]
000071c0d83dbce7  por xmm8, xmm2
000071c0d83dbcec  movaps xmm2, [r15+0x2D0]
000071c0d83dbcf4  vmovaps [rsp+0x90], xmm2
000071c0d83dbcfd  vmovaps [rsp+0xA0], xmm1
000071c0d83dbd06  vmovaps xmm1, [rsp+0x90]
000071c0d83dbd0f  por xmm2, xmm1
000071c0d83dbd13  movaps xmm1, [r15+0x200]
000071c0d83dbd1b  vmovaps [rsp+0x90], xmm1
000071c0d83dbd24  vmovaps [rsp+0xB0], xmm15
000071c0d83dbd2d  vmovaps xmm15, [rsp+0x90]
000071c0d83dbd36  por xmm1, xmm15
000071c0d83dbd3b  movaps xmm15, [r15+0x1C0]
000071c0d83dbd43  vmovaps [rsp+0x90], xmm15
000071c0d83dbd4c  vmovaps [rsp+0xC0], xmm1
000071c0d83dbd55  vmovaps xmm1, [rsp+0x90]
000071c0d83dbd5e  por xmm15, xmm1
000071c0d83dbd63  movaps xmm1, [r15+0x190]
000071c0d83dbd6b  vmovaps [rsp+0x90], xmm1
000071c0d83dbd74  vmovaps [rsp+0xD0], xmm15
000071c0d83dbd7d  vmovaps xmm15, [rsp+0x90]
000071c0d83dbd86  por xmm1, xmm15
000071c0d83dbd8b  movaps xmm15, [r15+0x300]
000071c0d83dbd93  vmovaps [rsp+0x90], xmm15
000071c0d83dbd9c  vmovaps [rsp+0xE0], xmm1
000071c0d83dbda5  vmovaps xmm1, [rsp+0x90]
000071c0d83dbdae  por xmm15, xmm1
000071c0d83dbdb3  mov rax, [rsp+0x80]
000071c0d83dbdbb  lea r12, [rax+0xA0]
000071c0d83dbdc2  movups xmm1, [r13+r12*1]
000071c0d83dbdc8  lea r12, [rax+0xB0]
000071c0d83dbdcf  vmovaps [rsp+0x80], xmm1
000071c0d83dbdd8  movups xmm1, [r13+r12*1]
000071c0d83dbdde  vmovaps [rsp+0x90], xmm1
000071c0d83dbde7  vmovaps [rsp+0xF0], xmm15
000071c0d83dbdf0  vmovaps xmm15, [rsp+0xB0]
000071c0d83dbdf9  vmovaps [rsp+0xB0], xmm14
000071c0d83dbe02  movaps xmm1, xmm6
000071c0d83dbe05  addpd xmm1, xmm15
000071c0d83dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000071c0d83dbe0f  ptest xmm14, xmm14
000071c0d83dbe15  jnz 0x000071C0D83DD4D6
000071c0d83dbe1b  lea r12, [rax+0xF0]
000071c0d83dbe22  movups xmm15, [r13+r12*1]
000071c0d83dbe28  movaps xmm14, xmm4
000071c0d83dbe2c  addpd xmm14, xmm3
000071c0d83dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000071c0d83dbe37  ptest xmm6, xmm6
000071c0d83dbe3c  jnz 0x000071C0D83DD621
000071c0d83dbe42  movaps xmm6, xmm9
000071c0d83dbe46  addpd xmm6, xmm7
000071c0d83dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000071c0d83dbe4f  ptest xmm4, xmm4
000071c0d83dbe54  jnz 0x000071C0D83DD763
000071c0d83dbe5a  vmovaps xmm9, [rsp+0x70]
000071c0d83dbe60  vpermilpd xmm9, xmm9, 0x00
000071c0d83dbe66  vmovaps xmm4, [rsp+0x90]
000071c0d83dbe6f  movaps xmm7, xmm4
000071c0d83dbe72  mulpd xmm7, xmm9
000071c0d83dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000071c0d83dbe7c  ptest xmm3, xmm3
000071c0d83dbe81  jnz 0x000071C0D83DD8A4
000071c0d83dbe87  vmovaps xmm9, [rsp+0x50]
000071c0d83dbe8d  vpermilpd xmm9, xmm9, 0x00
000071c0d83dbe93  movaps xmm4, xmm15
000071c0d83dbe97  mulpd xmm4, xmm9
000071c0d83dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000071c0d83dbea1  ptest xmm3, xmm3
000071c0d83dbea6  jnz 0x000071C0D83DD9E5
000071c0d83dbeac  lea r12, [rax+0xE0]
000071c0d83dbeb3  movups xmm15, [r13+r12*1]
000071c0d83dbeb9  vmovaps xmm9, [rsp+0x70]
000071c0d83dbebf  vpermilpd xmm9, xmm9, 0x00
000071c0d83dbec5  vmovaps [rsp+0x70], xmm1
000071c0d83dbecb  vmovaps xmm1, [rsp+0x80]
000071c0d83dbed4  vmovaps [rsp+0x80], xmm15
000071c0d83dbedd  movaps xmm3, xmm1
000071c0d83dbee0  mulpd xmm3, xmm9
000071c0d83dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000071c0d83dbeea  ptest xmm15, xmm15
000071c0d83dbef0  jnz 0x000071C0D83DDB31
000071c0d83dbef6  vmovaps xmm1, [rsp+0xF0]
000071c0d83dbeff  vmovaps xmm15, [rsp+0xF0]
000071c0d83dbf08  por xmm1, xmm15
000071c0d83dbf0d  movaps [r15+0x300], xmm1
000071c0d83dbf15  vmovaps xmm15, [rsp+0xE0]
000071c0d83dbf1e  vmovaps xmm9, [rsp+0xE0]
000071c0d83dbf27  por xmm15, xmm9
000071c0d83dbf2c  movaps [r15+0x190], xmm15
000071c0d83dbf34  vmovaps xmm9, [rsp+0x50]
000071c0d83dbf3a  vpermilpd xmm9, xmm9, 0x00
000071c0d83dbf40  vmovaps [rsp+0x90], xmm1
000071c0d83dbf49  vmovaps [rsp+0xE0], xmm15
000071c0d83dbf52  vmovaps xmm15, [rsp+0x80]
000071c0d83dbf5b  vmovaps [rsp+0x80], xmm14
000071c0d83dbf64  movaps xmm1, xmm15
000071c0d83dbf68  mulpd xmm1, xmm9
000071c0d83dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000071c0d83dbf72  ptest xmm14, xmm14
000071c0d83dbf78  jnz 0x000071C0D83DDC72
000071c0d83dbf7e  lea r12, [rax+0x90]
000071c0d83dbf85  movups xmm15, [r13+r12*1]
000071c0d83dbf8b  vmovaps xmm14, [rsp+0xD0]
000071c0d83dbf94  vmovaps xmm9, [rsp+0xD0]
000071c0d83dbf9d  por xmm14, xmm9
000071c0d83dbfa2  movaps [r15+0x1C0], xmm14
000071c0d83dbfaa  vmovaps xmm9, [rsp+0xC0]
000071c0d83dbfb3  vmovaps [rsp+0xD0], xmm1
000071c0d83dbfbc  vmovaps xmm1, [rsp+0xC0]
000071c0d83dbfc5  por xmm9, xmm1
000071c0d83dbfca  movaps [r15+0x200], xmm9
000071c0d83dbfd2  vmovaps [rsp+0xC0], xmm2
000071c0d83dbfdb  vmovaps xmm1, [rsp+0xC0]
000071c0d83dbfe4  por xmm2, xmm1
000071c0d83dbfe8  movaps [r15+0x2D0], xmm2
000071c0d83dbff0  vmovaps [rsp+0xC0], xmm8
000071c0d83dbff9  vmovaps xmm1, [rsp+0xC0]
000071c0d83dc002  por xmm8, xmm1
000071c0d83dc007  movaps [r15+0x2E0], xmm8
000071c0d83dc00f  vmovaps [rsp+0xC0], xmm15
000071c0d83dc018  movaps xmm1, xmm5
000071c0d83dc01b  addpd xmm1, xmm7
000071c0d83dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000071c0d83dc024  ptest xmm15, xmm15
000071c0d83dc02a  jnz 0x000071C0D83DDDBE
000071c0d83dc030  vmovaps xmm15, [rsp+0x50]
000071c0d83dc036  vpermilpd xmm15, xmm15, 0x00
000071c0d83dc03c  vmovaps xmm5, [rsp+0xC0]
000071c0d83dc045  vmovaps [rsp+0xC0], xmm1
000071c0d83dc04e  movaps xmm7, xmm5
000071c0d83dc051  mulpd xmm7, xmm15
000071c0d83dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000071c0d83dc05b  ptest xmm1, xmm1
000071c0d83dc060  jnz 0x000071C0D83DDEFE
000071c0d83dc066  lea r12, [rax+0x80]
000071c0d83dc06d  movups xmm1, [r13+r12*1]
000071c0d83dc073  vmovaps xmm5, [rsp+0x70]
000071c0d83dc079  vmovaps [rsp+0x70], xmm1
000071c0d83dc07f  movaps xmm15, xmm5
000071c0d83dc083  addpd xmm15, xmm3
000071c0d83dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83dc08e  ptest xmm1, xmm1
000071c0d83dc093  jnz 0x000071C0D83DE049
000071c0d83dc099  vmovaps xmm5, [rsp+0x80]
000071c0d83dc0a2  movaps xmm1, xmm5
000071c0d83dc0a5  addpd xmm1, xmm4
000071c0d83dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000071c0d83dc0ae  ptest xmm3, xmm3
000071c0d83dc0b3  jnz 0x000071C0D83DE18B
000071c0d83dc0b9  vmovaps [rsp+0x80], xmm10
000071c0d83dc0c2  vmovaps xmm5, [rsp+0x80]
000071c0d83dc0cb  por xmm10, xmm5
000071c0d83dc0d0  movaps [r15+0x2F0], xmm10
000071c0d83dc0d8  vmovaps xmm5, [rsp+0x50]
000071c0d83dc0de  vpermilpd xmm5, xmm5, 0x00
000071c0d83dc0e4  vmovaps xmm3, [rsp+0x70]
000071c0d83dc0ea  vmovaps [rsp+0x50], xmm1
000071c0d83dc0f0  movaps xmm4, xmm3
000071c0d83dc0f3  mulpd xmm4, xmm5
000071c0d83dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000071c0d83dc0fc  ptest xmm1, xmm1
000071c0d83dc101  jnz 0x000071C0D83DE2CB
000071c0d83dc107  lea r12, [rax+0xD0]
000071c0d83dc10e  movups xmm1, [r13+r12*1]
000071c0d83dc114  vmovaps xmm3, [rsp+0xD0]
000071c0d83dc11d  vmovaps [rsp+0x70], xmm1
000071c0d83dc123  movaps xmm5, xmm6
000071c0d83dc126  addpd xmm5, xmm3
000071c0d83dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000071c0d83dc12f  ptest xmm1, xmm1
000071c0d83dc134  jnz 0x000071C0D83DE415
000071c0d83dc13a  vmovaps xmm1, [rsp+0x60]
000071c0d83dc140  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc146  movaps xmm6, xmm9
000071c0d83dc14a  mulpd xmm6, xmm1
000071c0d83dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000071c0d83dc153  ptest xmm3, xmm3
000071c0d83dc158  jnz 0x000071C0D83DE555
000071c0d83dc15e  movaps [r15+0x260], xmm6
000071c0d83dc166  vxorps xmm1, xmm1, xmm1
000071c0d83dc16a  vpbroadcastq xmm1, xmm1
000071c0d83dc16f  movaps [r15+0x1B0], xmm1
000071c0d83dc177  vmovaps xmm1, [rsp+0x60]
000071c0d83dc17d  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc183  vmovaps xmm3, [rsp+0x70]
000071c0d83dc189  vmovaps [rsp+0x70], xmm15
000071c0d83dc18f  movaps xmm9, xmm3
000071c0d83dc193  mulpd xmm9, xmm1
000071c0d83dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000071c0d83dc19e  ptest xmm15, xmm15
000071c0d83dc1a4  jnz 0x000071C0D83DE696
000071c0d83dc1aa  lea r12, [rax+0xC0]
000071c0d83dc1b1  movups xmm1, [r13+r12*1]
000071c0d83dc1b7  vmovaps xmm3, [rsp+0xC0]
000071c0d83dc1c0  vmovaps [rsp+0x80], xmm1
000071c0d83dc1c9  movaps xmm15, xmm3
000071c0d83dc1cd  addpd xmm15, xmm7
000071c0d83dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83dc1d8  ptest xmm1, xmm1
000071c0d83dc1dd  jnz 0x000071C0D83DE7E2
000071c0d83dc1e3  vmovaps [rsp+0xC0], xmm13
000071c0d83dc1ec  vmovaps xmm1, [rsp+0xC0]
000071c0d83dc1f5  por xmm13, xmm1
000071c0d83dc1fa  movaps [r15+0x270], xmm13
000071c0d83dc202  vmovaps xmm1, [rsp+0xB0]
000071c0d83dc20b  vmovaps xmm7, [rsp+0xB0]
000071c0d83dc214  por xmm1, xmm7
000071c0d83dc218  movaps [r15+0x1A0], xmm1
000071c0d83dc220  vmovaps xmm1, [rsp+0x60]
000071c0d83dc226  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc22c  vmovaps [rsp+0xB0], xmm1
000071c0d83dc235  vmovaps xmm1, [rsp+0x80]
000071c0d83dc23e  vmovaps [rsp+0x80], xmm15
000071c0d83dc247  vmovaps xmm15, [rsp+0xB0]
000071c0d83dc250  vmovaps [rsp+0xB0], xmm14
000071c0d83dc259  movaps xmm3, xmm1
000071c0d83dc25c  mulpd xmm3, xmm15
000071c0d83dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000071c0d83dc266  ptest xmm14, xmm14
000071c0d83dc26c  jnz 0x000071C0D83DE924
000071c0d83dc272  lea r12, [rax+0x20]
000071c0d83dc276  movups xmm1, [r13+r12*1]
000071c0d83dc27c  movaps [r15+0x110], xmm1
000071c0d83dc284  vmovaps xmm14, [rsp+0x70]
000071c0d83dc28a  vmovaps [rsp+0x70], xmm1
000071c0d83dc290  movaps xmm15, xmm14
000071c0d83dc294  addpd xmm15, xmm4
000071c0d83dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000071c0d83dc29f  ptest xmm1, xmm1
000071c0d83dc2a4  jnz 0x000071C0D83DEA6F
000071c0d83dc2aa  vmovaps xmm1, [rsp+0x60]
000071c0d83dc2b0  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc2b6  movaps xmm14, xmm2
000071c0d83dc2ba  mulpd xmm14, xmm1
000071c0d83dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000071c0d83dc2c5  ptest xmm4, xmm4
000071c0d83dc2ca  jnz 0x000071C0D83DEBB2
000071c0d83dc2d0  vmovaps xmm4, [rsp+0x50]
000071c0d83dc2d6  movaps xmm1, xmm4
000071c0d83dc2d9  addpd xmm1, xmm9
000071c0d83dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000071c0d83dc2e3  ptest xmm2, xmm2
000071c0d83dc2e8  jnz 0x000071C0D83DECF4
000071c0d83dc2ee  vmovaps xmm9, [rsp+0x30]
000071c0d83dc2f4  vpermilpd xmm9, xmm9, 0x00
000071c0d83dc2fa  vmovaps xmm2, [rsp+0x70]
000071c0d83dc300  vmovaps [rsp+0x50], xmm1
000071c0d83dc306  movaps xmm4, xmm2
000071c0d83dc309  mulpd xmm4, xmm9
000071c0d83dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000071c0d83dc313  ptest xmm1, xmm1
000071c0d83dc318  jnz 0x000071C0D83DEE35
000071c0d83dc31e  vmovaps xmm1, [rsp+0x30]
000071c0d83dc324  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc32a  vmovaps xmm2, [rsp+0x90]
000071c0d83dc333  vmovaps [rsp+0x60], xmm15
000071c0d83dc339  movaps xmm9, xmm2
000071c0d83dc33d  mulpd xmm9, xmm1
000071c0d83dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000071c0d83dc348  ptest xmm15, xmm15
000071c0d83dc34e  jnz 0x000071C0D83DEF76
000071c0d83dc354  vmovaps xmm15, [rsp+0x80]
000071c0d83dc35d  movaps xmm1, xmm15
000071c0d83dc361  addpd xmm1, xmm6
000071c0d83dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000071c0d83dc36a  ptest xmm2, xmm2
000071c0d83dc36f  jnz 0x000071C0D83DF0B8
000071c0d83dc375  movaps xmm15, xmm5
000071c0d83dc379  addpd xmm15, xmm3
000071c0d83dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000071c0d83dc384  ptest xmm6, xmm6
000071c0d83dc389  jnz 0x000071C0D83DF1F9
000071c0d83dc38f  vmovaps xmm6, [rsp+0x30]
000071c0d83dc395  vpermilpd xmm6, xmm6, 0x00
000071c0d83dc39b  movaps xmm5, xmm8
000071c0d83dc39f  mulpd xmm5, xmm6
000071c0d83dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000071c0d83dc3a8  ptest xmm3, xmm3
000071c0d83dc3ad  jnz 0x000071C0D83DF33B
000071c0d83dc3b3  vmovaps xmm8, [rsp+0x30]
000071c0d83dc3b9  vpermilpd xmm8, xmm8, 0x00
000071c0d83dc3bf  movaps xmm6, xmm10
000071c0d83dc3c3  mulpd xmm6, xmm8
000071c0d83dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000071c0d83dc3cd  ptest xmm3, xmm3
000071c0d83dc3d2  jnz 0x000071C0D83DF47C
000071c0d83dc3d8  vmovaps xmm8, [rsp+0x60]
000071c0d83dc3de  movaps xmm10, xmm8
000071c0d83dc3e2  addpd xmm10, xmm14
000071c0d83dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000071c0d83dc3ed  ptest xmm3, xmm3
000071c0d83dc3f2  jnz 0x000071C0D83DF5BE
000071c0d83dc3f8  vmovaps xmm8, [rsp+0x50]
000071c0d83dc3fe  movaps xmm14, xmm8
000071c0d83dc402  addpd xmm14, xmm4
000071c0d83dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000071c0d83dc40d  ptest xmm3, xmm3
000071c0d83dc412  jnz 0x000071C0D83DF702
000071c0d83dc418  vmovaps xmm8, [rsp+0x40]
000071c0d83dc41e  vpermilpd xmm8, xmm8, 0x00
000071c0d83dc424  movaps xmm4, xmm13
000071c0d83dc428  mulpd xmm4, xmm8
000071c0d83dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000071c0d83dc432  ptest xmm3, xmm3
000071c0d83dc437  jnz 0x000071C0D83DF845
000071c0d83dc43d  movaps xmm13, xmm15
000071c0d83dc441  addpd xmm13, xmm9
000071c0d83dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000071c0d83dc44c  ptest xmm8, xmm8
000071c0d83dc452  jnz 0x000071C0D83DF987
000071c0d83dc458  movaps xmm15, xmm1
000071c0d83dc45c  addpd xmm15, xmm5
000071c0d83dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000071c0d83dc467  ptest xmm9, xmm9
000071c0d83dc46d  jnz 0x000071C0D83DFACB
000071c0d83dc473  vmovaps [rsp+0x30], xmm11
000071c0d83dc479  vmovaps xmm1, [rsp+0x30]
000071c0d83dc47f  por xmm11, xmm1
000071c0d83dc484  movaps [r15+0x250], xmm11
000071c0d83dc48c  vmovaps [rsp+0x30], xmm12
000071c0d83dc492  vmovaps xmm1, [rsp+0x30]
000071c0d83dc498  por xmm12, xmm1
000071c0d83dc49d  movaps [r15+0x2A0], xmm12
000071c0d83dc4a5  vmovaps xmm1, [rsp+0xA0]
000071c0d83dc4ae  vmovaps xmm11, [rsp+0xA0]
000071c0d83dc4b7  por xmm1, xmm11
000071c0d83dc4bc  movaps [r15+0x1D0], xmm1
000071c0d83dc4c4  lea r12, [rax+0x40]
000071c0d83dc4c8  movups xmm1, [r13+r12*1]
000071c0d83dc4ce  movaps [r15+0x2C0], xmm1
000071c0d83dc4d6  vmovaps xmm11, [rsp+0x40]
000071c0d83dc4dc  vpermilpd xmm11, xmm11, 0x00
000071c0d83dc4e2  vmovaps xmm8, [rsp+0xE0]
000071c0d83dc4eb  movaps xmm9, xmm8
000071c0d83dc4ef  mulpd xmm9, xmm11
000071c0d83dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000071c0d83dc4fa  ptest xmm5, xmm5
000071c0d83dc4ff  jnz 0x000071C0D83DFC17
000071c0d83dc505  movaps xmm11, xmm10
000071c0d83dc509  addpd xmm11, xmm6
000071c0d83dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000071c0d83dc514  ptest xmm8, xmm8
000071c0d83dc51a  jnz 0x000071C0D83DFD5B
000071c0d83dc520  movaps xmm10, xmm14
000071c0d83dc524  addpd xmm10, xmm4
000071c0d83dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000071c0d83dc52f  ptest xmm8, xmm8
000071c0d83dc535  jnz 0x000071C0D83DFE9E
000071c0d83dc53b  vmovaps xmm14, [rsp+0x40]
000071c0d83dc541  vpermilpd xmm14, xmm14, 0x00
000071c0d83dc547  movaps xmm8, xmm1
000071c0d83dc54b  mulpd xmm8, xmm14
000071c0d83dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000071c0d83dc556  ptest xmm6, xmm6
000071c0d83dc55b  jnz 0x000071C0D83DFFE1
000071c0d83dc561  movaps xmm1, [r15+0x2B0]
000071c0d83dc569  vmovaps xmm14, [rsp+0x40]
000071c0d83dc56f  vpermilpd xmm14, xmm14, 0x00
000071c0d83dc575  movaps xmm6, xmm1
000071c0d83dc578  mulpd xmm6, xmm14
000071c0d83dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000071c0d83dc582  ptest xmm5, xmm5
000071c0d83dc587  jnz 0x000071C0D83E0124
000071c0d83dc58d  vmovaps xmm1, [rsp+0x10]
000071c0d83dc593  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc599  movaps xmm14, xmm12
000071c0d83dc59d  mulpd xmm14, xmm1
000071c0d83dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000071c0d83dc5a8  ptest xmm5, xmm5
000071c0d83dc5ad  jnz 0x000071C0D83E0265
000071c0d83dc5b3  movaps xmm1, xmm13
000071c0d83dc5b7  addpd xmm1, xmm9
000071c0d83dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000071c0d83dc5c1  ptest xmm12, xmm12
000071c0d83dc5c7  jnz 0x000071C0D83E03A8
000071c0d83dc5cd  vmovaps xmm13, [rsp+0x10]
000071c0d83dc5d3  vpermilpd xmm13, xmm13, 0x00
000071c0d83dc5d9  movaps xmm12, xmm7
000071c0d83dc5dd  mulpd xmm12, xmm13
000071c0d83dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000071c0d83dc5e8  ptest xmm9, xmm9
000071c0d83dc5ee  jnz 0x000071C0D83E04EA
000071c0d83dc5f4  movaps xmm13, xmm15
000071c0d83dc5f8  addpd xmm13, xmm8
000071c0d83dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000071c0d83dc603  ptest xmm9, xmm9
000071c0d83dc609  jnz 0x000071C0D83E062D
000071c0d83dc60f  movaps xmm15, [r15+0x290]
000071c0d83dc617  vmovaps xmm9, [rsp+0x10]
000071c0d83dc61d  vpermilpd xmm9, xmm9, 0x00
000071c0d83dc623  movaps xmm8, xmm15
000071c0d83dc627  mulpd xmm8, xmm9
000071c0d83dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000071c0d83dc632  ptest xmm7, xmm7
000071c0d83dc637  jnz 0x000071C0D83E0771
000071c0d83dc63d  movaps xmm15, xmm11
000071c0d83dc641  addpd xmm15, xmm6
000071c0d83dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000071c0d83dc64c  ptest xmm9, xmm9
000071c0d83dc652  jnz 0x000071C0D83E08B5
000071c0d83dc658  movaps xmm11, [r15+0x1E0]
000071c0d83dc660  vmovaps xmm9, [rsp+0x10]
000071c0d83dc666  vpermilpd xmm9, xmm9, 0x00
000071c0d83dc66c  movaps xmm7, xmm11
000071c0d83dc670  mulpd xmm7, xmm9
000071c0d83dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000071c0d83dc67a  ptest xmm6, xmm6
000071c0d83dc67f  jnz 0x000071C0D83E09F8
000071c0d83dc685  movaps xmm11, xmm10
000071c0d83dc689  addpd xmm11, xmm14
000071c0d83dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000071c0d83dc694  ptest xmm9, xmm9
000071c0d83dc69a  jnz 0x000071C0D83E0B3A
000071c0d83dc6a0  lea r12, [rax+0x70]
000071c0d83dc6a4  movups xmm14, [r13+r12*1]
000071c0d83dc6aa  movaps [r15+0x240], xmm14
000071c0d83dc6b2  movaps xmm10, xmm1
000071c0d83dc6b6  addpd xmm10, xmm12
000071c0d83dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000071c0d83dc6c1  ptest xmm9, xmm9
000071c0d83dc6c7  jnz 0x000071C0D83E0C88
000071c0d83dc6cd  movaps [r15+0x170], xmm10
000071c0d83dc6d5  vmovaps xmm1, [rsp+0x20]
000071c0d83dc6db  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc6e1  movaps xmm12, xmm14
000071c0d83dc6e5  mulpd xmm12, xmm1
000071c0d83dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000071c0d83dc6f0  ptest xmm9, xmm9
000071c0d83dc6f6  jnz 0x000071C0D83E0DCB
000071c0d83dc6fc  vmovaps xmm1, [rsp+0x20]
000071c0d83dc702  vpermilpd xmm1, xmm1, 0x00
000071c0d83dc708  vmovaps xmm9, [rsp+0xB0]
000071c0d83dc711  movaps xmm14, xmm9
000071c0d83dc715  mulpd xmm14, xmm1
000071c0d83dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000071c0d83dc720  ptest xmm6, xmm6
000071c0d83dc725  jnz 0x000071C0D83E0F0E
000071c0d83dc72b  movaps [r15+0x180], xmm14
000071c0d83dc733  movaps xmm1, xmm13
000071c0d83dc737  addpd xmm1, xmm8
000071c0d83dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000071c0d83dc741  ptest xmm9, xmm9
000071c0d83dc747  jnz 0x000071C0D83E1051
000071c0d83dc74d  movaps [r15+0x210], xmm1
000071c0d83dc755  movups xmm13, [r13+rax*1]
000071c0d83dc75b  lea r12, [rax+0x10]
000071c0d83dc75f  movups xmm9, [r13+r12*1]
000071c0d83dc765  movaps [r15+0x230], xmm9
000071c0d83dc76d  movaps xmm8, xmm15
000071c0d83dc771  addpd xmm8, xmm7
000071c0d83dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000071c0d83dc77c  ptest xmm6, xmm6
000071c0d83dc781  jnz 0x000071C0D83E11A7
000071c0d83dc787  movaps [r15+0x130], xmm8
000071c0d83dc78f  vmovaps xmm15, [rsp+0x20]
000071c0d83dc795  vpermilpd xmm15, xmm15, 0x00
000071c0d83dc79b  movaps xmm7, xmm9
000071c0d83dc79f  mulpd xmm7, xmm15
000071c0d83dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000071c0d83dc7a9  ptest xmm6, xmm6
000071c0d83dc7ae  jnz 0x000071C0D83E12EA
000071c0d83dc7b4  movaps [r15+0x220], xmm7
000071c0d83dc7bc  vmovaps xmm15, [rsp+0x20]
000071c0d83dc7c2  vpermilpd xmm15, xmm15, 0x00
000071c0d83dc7c8  movaps xmm9, xmm13
000071c0d83dc7cc  mulpd xmm9, xmm15
000071c0d83dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000071c0d83dc7d7  ptest xmm6, xmm6
000071c0d83dc7dc  jnz 0x000071C0D83E142C
000071c0d83dc7e2  movaps xmm15, xmm11
000071c0d83dc7e6  addpd xmm15, xmm12
000071c0d83dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000071c0d83dc7f1  ptest xmm13, xmm13
000071c0d83dc7f7  jnz 0x000071C0D83E1570
000071c0d83dc7fd  movaps [r15+0x140], xmm15
000071c0d83dc805  movaps xmm13, xmm10
000071c0d83dc809  addpd xmm13, xmm14
000071c0d83dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000071c0d83dc814  ptest xmm12, xmm12
000071c0d83dc81a  jnz 0x000071C0D83E16B4
000071c0d83dc820  movaps [r15+0x150], xmm13
000071c0d83dc828  movaps xmm14, xmm1
000071c0d83dc82c  addpd xmm14, xmm7
000071c0d83dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000071c0d83dc837  ptest xmm12, xmm12
000071c0d83dc83d  jnz 0x000071C0D83E17F8
000071c0d83dc843  movaps [r15+0x160], xmm14
000071c0d83dc84b  movaps xmm1, xmm8
000071c0d83dc84f  addpd xmm1, xmm9
000071c0d83dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000071c0d83dc859  ptest xmm12, xmm12
000071c0d83dc85f  jnz 0x000071C0D83E193A
000071c0d83dc865  movaps [r15+0x120], xmm1
000071c0d83dc86d  movups [r13+r14*1], xmm15
000071c0d83dc873  lea rax, [r14+0x10]
000071c0d83dc877  movups [r13+rax*1], xmm13
000071c0d83dc87d  lea rax, [r14+0x20]
000071c0d83dc881  movups [r13+rax*1], xmm14
000071c0d83dc887  lea rax, [r14+0x30]
000071c0d83dc88b  movups [r13+rax*1], xmm1
000071c0d83dc891  mov eax, [r15+0x108]
000071c0d83dc898  sahf
000071c0d83dc899  jnz 0x000071C0D83DC8CB
000071c0d83dc89b  cmp dword ptr [r15+0x318], 0x00
000071c0d83dc8a3  jz 0x000071C0D83DB900
000071c0d83dc8a9  nop [rax+rax*1], ax
000071c0d83dc8b2  nop [rax+rax*1], eax
000071c0d83dc8ba  mov eax, 0x410444
000071c0d83dc8bf  mov [r15+0x100], rax
000071c0d83dc8c6  jmp 0x000071C0D81FE110
000071c0d83dc8cb  cmp dword ptr [r15+0x318], 0x00
000071c0d83dc8d3  jz 0x000071C0D83D57E0
000071c0d83dc8d9  nop [rax+rax*1], ax
000071c0d83dc8e2  nop [rax+rax*1], eax
000071c0d83dc8ea  mov eax, 0x410278
000071c0d83dc8ef  mov [r15+0x100], rax
000071c0d83dc8f6  jmp 0x000071C0D81FE110
000071c0d83dc8fb  int3
000071c0d83dc8fc  call 0x000071C0D82E27E0
000071c0d83dc901  jmp 0x000071C0D83DB9DF
000071c0d83dc906  call 0x000071C0D82E1570
000071c0d83dc90b  jmp 0x000071C0D83DB9E8
000071c0d83dc910  call 0x000071C0D82E27E0
000071c0d83dc915  jmp 0x000071C0D83DBA44
000071c0d83dc91a  call 0x000071C0D82E1570
000071c0d83dc91f  jmp 0x000071C0D83DBA4D
000071c0d83dc924  call 0x000071C0D82E27E0
000071c0d83dc929  jmp 0x000071C0D83DBA90
000071c0d83dc92e  call 0x000071C0D82E1570
000071c0d83dc933  jmp 0x000071C0D83DBA99
000071c0d83dc938  call 0x000071C0D820DC20
000071c0d83dc93d  jmp 0x000071C0D83DBAD8
000071c0d83dc942  call 0x000071C0D82D59C0
000071c0d83dc947  jmp 0x000071C0D83DBAEB
000071c0d83dc94c  call 0x000071C0D82E0E30
000071c0d83dc951  jmp 0x000071C0D83DBB09
000071c0d83dc956  call 0x000071C0D82DFBC0
000071c0d83dc95b  jmp 0x000071C0D83DBB13
000071c0d83dc960  call 0x000071C0D82DE950
000071c0d83dc965  jmp 0x000071C0D83DBB1D
000071c0d83dc96a  sub rsp, 0x08
000071c0d83dc96e  push rax
000071c0d83dc96f  push rcx
000071c0d83dc970  push rdx
000071c0d83dc971  push rdi
000071c0d83dc972  push rsi
000071c0d83dc973  push r8
000071c0d83dc975  push r9
000071c0d83dc977  push r10
000071c0d83dc979  push r11
000071c0d83dc97b  sub rsp, 0xF0
000071c0d83dc982  vmovaps [rsp], xmm0
000071c0d83dc987  vmovaps [rsp+0x10], xmm1
000071c0d83dc98d  vmovaps [rsp+0x20], xmm2
000071c0d83dc993  vmovaps [rsp+0x30], xmm3
000071c0d83dc999  vmovaps [rsp+0x40], xmm4
000071c0d83dc99f  vmovaps [rsp+0x50], xmm5
000071c0d83dc9a5  vmovaps [rsp+0x60], xmm6
000071c0d83dc9ab  vmovaps [rsp+0x70], xmm7
000071c0d83dc9b1  vmovaps [rsp+0x80], xmm9
000071c0d83dc9ba  vmovaps [rsp+0x90], xmm10
000071c0d83dc9c3  vmovaps [rsp+0xA0], xmm11
000071c0d83dc9cc  vmovaps [rsp+0xB0], xmm12
000071c0d83dc9d5  vmovaps [rsp+0xC0], xmm13
000071c0d83dc9de  vmovaps [rsp+0xD0], xmm14
000071c0d83dc9e7  vmovaps [rsp+0xE0], xmm15
000071c0d83dc9f0  sub rsp, 0x30
000071c0d83dc9f4  movaps [rsp], xmm8
000071c0d83dc9f9  movaps [rsp+0x10], xmm12
000071c0d83dc9ff  movaps [rsp+0x20], xmm15
000071c0d83dca05  lea rdi, [rsp]
000071c0d83dca09  mov esi, 0x00
000071c0d83dca0e  mov rax, 0x5904ED15D530
000071c0d83dca18  call rax
000071c0d83dca1a  movaps xmm8, [rsp]
000071c0d83dca1f  add rsp, 0x30
000071c0d83dca23  vmovaps xmm0, [rsp]
000071c0d83dca28  vmovaps xmm1, [rsp+0x10]
000071c0d83dca2e  vmovaps xmm2, [rsp+0x20]
000071c0d83dca34  vmovaps xmm3, [rsp+0x30]
000071c0d83dca3a  vmovaps xmm4, [rsp+0x40]
000071c0d83dca40  vmovaps xmm5, [rsp+0x50]
000071c0d83dca46  vmovaps xmm6, [rsp+0x60]
000071c0d83dca4c  vmovaps xmm7, [rsp+0x70]
000071c0d83dca52  vmovaps xmm9, [rsp+0x80]
000071c0d83dca5b  vmovaps xmm10, [rsp+0x90]
000071c0d83dca64  vmovaps xmm11, [rsp+0xA0]
000071c0d83dca6d  vmovaps xmm12, [rsp+0xB0]
000071c0d83dca76  vmovaps xmm13, [rsp+0xC0]
000071c0d83dca7f  vmovaps xmm14, [rsp+0xD0]
000071c0d83dca88  vmovaps xmm15, [rsp+0xE0]
000071c0d83dca91  add rsp, 0xF0
000071c0d83dca98  pop r11
000071c0d83dca9a  pop r10
000071c0d83dca9c  pop r9
000071c0d83dca9e  pop r8
000071c0d83dcaa0  pop rsi
000071c0d83dcaa1  pop rdi
000071c0d83dcaa2  pop rdx
000071c0d83dcaa3  pop rcx
000071c0d83dcaa4  pop rax
000071c0d83dcaa5  add rsp, 0x08
000071c0d83dcaa9  jmp 0x000071C0D83DBB47
000071c0d83dcaae  sub rsp, 0x08
000071c0d83dcab2  push rax
000071c0d83dcab3  push rcx
000071c0d83dcab4  push rdx
000071c0d83dcab5  push rdi
000071c0d83dcab6  push rsi
000071c0d83dcab7  push r8
000071c0d83dcab9  push r9
000071c0d83dcabb  push r10
000071c0d83dcabd  push r11
000071c0d83dcabf  sub rsp, 0xF0
000071c0d83dcac6  vmovaps [rsp], xmm0
000071c0d83dcacb  vmovaps [rsp+0x10], xmm1
000071c0d83dcad1  vmovaps [rsp+0x20], xmm2
000071c0d83dcad7  vmovaps [rsp+0x30], xmm3
000071c0d83dcadd  vmovaps [rsp+0x40], xmm4
000071c0d83dcae3  vmovaps [rsp+0x50], xmm5
000071c0d83dcae9  vmovaps [rsp+0x60], xmm6
000071c0d83dcaef  vmovaps [rsp+0x70], xmm8
000071c0d83dcaf5  vmovaps [rsp+0x80], xmm9
000071c0d83dcafe  vmovaps [rsp+0x90], xmm10
000071c0d83dcb07  vmovaps [rsp+0xA0], xmm11
000071c0d83dcb10  vmovaps [rsp+0xB0], xmm12
000071c0d83dcb19  vmovaps [rsp+0xC0], xmm13
000071c0d83dcb22  vmovaps [rsp+0xD0], xmm14
000071c0d83dcb2b  vmovaps [rsp+0xE0], xmm15
000071c0d83dcb34  sub rsp, 0x30
000071c0d83dcb38  movaps [rsp], xmm7
000071c0d83dcb3c  movaps [rsp+0x10], xmm9
000071c0d83dcb42  movaps [rsp+0x20], xmm15
000071c0d83dcb48  lea rdi, [rsp]
000071c0d83dcb4c  mov esi, 0x00
000071c0d83dcb51  mov rax, 0x5904ED15D530
000071c0d83dcb5b  call rax
000071c0d83dcb5d  movaps xmm7, [rsp]
000071c0d83dcb61  add rsp, 0x30
000071c0d83dcb65  vmovaps xmm0, [rsp]
000071c0d83dcb6a  vmovaps xmm1, [rsp+0x10]
000071c0d83dcb70  vmovaps xmm2, [rsp+0x20]
000071c0d83dcb76  vmovaps xmm3, [rsp+0x30]
000071c0d83dcb7c  vmovaps xmm4, [rsp+0x40]
000071c0d83dcb82  vmovaps xmm5, [rsp+0x50]
000071c0d83dcb88  vmovaps xmm6, [rsp+0x60]
000071c0d83dcb8e  vmovaps xmm8, [rsp+0x70]
000071c0d83dcb94  vmovaps xmm9, [rsp+0x80]
000071c0d83dcb9d  vmovaps xmm10, [rsp+0x90]
000071c0d83dcba6  vmovaps xmm11, [rsp+0xA0]
000071c0d83dcbaf  vmovaps xmm12, [rsp+0xB0]
000071c0d83dcbb8  vmovaps xmm13, [rsp+0xC0]
000071c0d83dcbc1  vmovaps xmm14, [rsp+0xD0]
000071c0d83dcbca  vmovaps xmm15, [rsp+0xE0]
000071c0d83dcbd3  add rsp, 0xF0
000071c0d83dcbda  pop r11
000071c0d83dcbdc  pop r10
000071c0d83dcbde  pop r9
000071c0d83dcbe0  pop r8
000071c0d83dcbe2  pop rsi
000071c0d83dcbe3  pop rdi
000071c0d83dcbe4  pop rdx
000071c0d83dcbe5  pop rcx
000071c0d83dcbe6  pop rax
000071c0d83dcbe7  add rsp, 0x08
000071c0d83dcbeb  jmp 0x000071C0D83DBB75
000071c0d83dcbf0  sub rsp, 0x08
000071c0d83dcbf4  push rax
000071c0d83dcbf5  push rcx
000071c0d83dcbf6  push rdx
000071c0d83dcbf7  push rdi
000071c0d83dcbf8  push rsi
000071c0d83dcbf9  push r8
000071c0d83dcbfb  push r9
000071c0d83dcbfd  push r10
000071c0d83dcbff  push r11
000071c0d83dcc01  sub rsp, 0xF0
000071c0d83dcc08  vmovaps [rsp], xmm0
000071c0d83dcc0d  vmovaps [rsp+0x10], xmm1
000071c0d83dcc13  vmovaps [rsp+0x20], xmm2
000071c0d83dcc19  vmovaps [rsp+0x30], xmm3
000071c0d83dcc1f  vmovaps [rsp+0x40], xmm4
000071c0d83dcc25  vmovaps [rsp+0x50], xmm5
000071c0d83dcc2b  vmovaps [rsp+0x60], xmm6
000071c0d83dcc31  vmovaps [rsp+0x70], xmm7
000071c0d83dcc37  vmovaps [rsp+0x80], xmm8
000071c0d83dcc40  vmovaps [rsp+0x90], xmm10
000071c0d83dcc49  vmovaps [rsp+0xA0], xmm11
000071c0d83dcc52  vmovaps [rsp+0xB0], xmm12
000071c0d83dcc5b  vmovaps [rsp+0xC0], xmm13
000071c0d83dcc64  vmovaps [rsp+0xD0], xmm14
000071c0d83dcc6d  vmovaps [rsp+0xE0], xmm15
000071c0d83dcc76  sub rsp, 0x30
000071c0d83dcc7a  movaps [rsp], xmm9
000071c0d83dcc7f  movaps [rsp+0x10], xmm12
000071c0d83dcc85  movaps [rsp+0x20], xmm10
000071c0d83dcc8b  lea rdi, [rsp]
000071c0d83dcc8f  mov esi, 0x00
000071c0d83dcc94  mov rax, 0x5904ED15D530
000071c0d83dcc9e  call rax
000071c0d83dcca0  movaps xmm9, [rsp]
000071c0d83dcca5  add rsp, 0x30
000071c0d83dcca9  vmovaps xmm0, [rsp]
000071c0d83dccae  vmovaps xmm1, [rsp+0x10]
000071c0d83dccb4  vmovaps xmm2, [rsp+0x20]
000071c0d83dccba  vmovaps xmm3, [rsp+0x30]
000071c0d83dccc0  vmovaps xmm4, [rsp+0x40]
000071c0d83dccc6  vmovaps xmm5, [rsp+0x50]
000071c0d83dcccc  vmovaps xmm6, [rsp+0x60]
000071c0d83dccd2  vmovaps xmm7, [rsp+0x70]
000071c0d83dccd8  vmovaps xmm8, [rsp+0x80]
000071c0d83dcce1  vmovaps xmm10, [rsp+0x90]
000071c0d83dccea  vmovaps xmm11, [rsp+0xA0]
000071c0d83dccf3  vmovaps xmm12, [rsp+0xB0]
000071c0d83dccfc  vmovaps xmm13, [rsp+0xC0]
000071c0d83dcd05  vmovaps xmm14, [rsp+0xD0]
000071c0d83dcd0e  vmovaps xmm15, [rsp+0xE0]
000071c0d83dcd17  add rsp, 0xF0
000071c0d83dcd1e  pop r11
000071c0d83dcd20  pop r10
000071c0d83dcd22  pop r9
000071c0d83dcd24  pop r8
000071c0d83dcd26  pop rsi
000071c0d83dcd27  pop rdi
000071c0d83dcd28  pop rdx
000071c0d83dcd29  pop rcx
000071c0d83dcd2a  pop rax
000071c0d83dcd2b  add rsp, 0x08
000071c0d83dcd2f  jmp 0x000071C0D83DBB99
000071c0d83dcd34  sub rsp, 0x08
000071c0d83dcd38  push rax
000071c0d83dcd39  push rcx
000071c0d83dcd3a  push rdx
000071c0d83dcd3b  push rdi
000071c0d83dcd3c  push rsi
000071c0d83dcd3d  push r8
000071c0d83dcd3f  push r9
000071c0d83dcd41  push r10
000071c0d83dcd43  push r11
000071c0d83dcd45  sub rsp, 0xF0
000071c0d83dcd4c  vmovaps [rsp], xmm0
000071c0d83dcd51  vmovaps [rsp+0x10], xmm1
000071c0d83dcd57  vmovaps [rsp+0x20], xmm2
000071c0d83dcd5d  vmovaps [rsp+0x30], xmm3
000071c0d83dcd63  vmovaps [rsp+0x40], xmm4
000071c0d83dcd69  vmovaps [rsp+0x50], xmm5
000071c0d83dcd6f  vmovaps [rsp+0x60], xmm6
000071c0d83dcd75  vmovaps [rsp+0x70], xmm7
000071c0d83dcd7b  vmovaps [rsp+0x80], xmm8
000071c0d83dcd84  vmovaps [rsp+0x90], xmm9
000071c0d83dcd8d  vmovaps [rsp+0xA0], xmm11
000071c0d83dcd96  vmovaps [rsp+0xB0], xmm12
000071c0d83dcd9f  vmovaps [rsp+0xC0], xmm13
000071c0d83dcda8  vmovaps [rsp+0xD0], xmm14
000071c0d83dcdb1  vmovaps [rsp+0xE0], xmm15
000071c0d83dcdba  sub rsp, 0x30
000071c0d83dcdbe  movaps [rsp], xmm10
000071c0d83dcdc3  movaps [rsp+0x10], xmm12
000071c0d83dcdc9  movaps [rsp+0x20], xmm11
000071c0d83dcdcf  lea rdi, [rsp]
000071c0d83dcdd3  mov esi, 0x00
000071c0d83dcdd8  mov rax, 0x5904ED15D530
000071c0d83dcde2  call rax
000071c0d83dcde4  movaps xmm10, [rsp]
000071c0d83dcde9  add rsp, 0x30
000071c0d83dcded  vmovaps xmm0, [rsp]
000071c0d83dcdf2  vmovaps xmm1, [rsp+0x10]
000071c0d83dcdf8  vmovaps xmm2, [rsp+0x20]
000071c0d83dcdfe  vmovaps xmm3, [rsp+0x30]
000071c0d83dce04  vmovaps xmm4, [rsp+0x40]
000071c0d83dce0a  vmovaps xmm5, [rsp+0x50]
000071c0d83dce10  vmovaps xmm6, [rsp+0x60]
000071c0d83dce16  vmovaps xmm7, [rsp+0x70]
000071c0d83dce1c  vmovaps xmm8, [rsp+0x80]
000071c0d83dce25  vmovaps xmm9, [rsp+0x90]
000071c0d83dce2e  vmovaps xmm11, [rsp+0xA0]
000071c0d83dce37  vmovaps xmm12, [rsp+0xB0]
000071c0d83dce40  vmovaps xmm13, [rsp+0xC0]
000071c0d83dce49  vmovaps xmm14, [rsp+0xD0]
000071c0d83dce52  vmovaps xmm15, [rsp+0xE0]
000071c0d83dce5b  add rsp, 0xF0
000071c0d83dce62  pop r11
000071c0d83dce64  pop r10
000071c0d83dce66  pop r9
000071c0d83dce68  pop r8
000071c0d83dce6a  pop rsi
000071c0d83dce6b  pop rdi
000071c0d83dce6c  pop rdx
000071c0d83dce6d  pop rcx
000071c0d83dce6e  pop rax
000071c0d83dce6f  add rsp, 0x08
000071c0d83dce73  jmp 0x000071C0D83DBBB3
000071c0d83dce78  sub rsp, 0x08
000071c0d83dce7c  push rax
000071c0d83dce7d  push rcx
000071c0d83dce7e  push rdx
000071c0d83dce7f  push rdi
000071c0d83dce80  push rsi
000071c0d83dce81  push r8
000071c0d83dce83  push r9
000071c0d83dce85  push r10
000071c0d83dce87  push r11
000071c0d83dce89  sub rsp, 0xF0
000071c0d83dce90  vmovaps [rsp], xmm0
000071c0d83dce95  vmovaps [rsp+0x10], xmm1
000071c0d83dce9b  vmovaps [rsp+0x20], xmm2
000071c0d83dcea1  vmovaps [rsp+0x30], xmm3
000071c0d83dcea7  vmovaps [rsp+0x40], xmm4
000071c0d83dcead  vmovaps [rsp+0x50], xmm5
000071c0d83dceb3  vmovaps [rsp+0x60], xmm7
000071c0d83dceb9  vmovaps [rsp+0x70], xmm8
000071c0d83dcebf  vmovaps [rsp+0x80], xmm9
000071c0d83dcec8  vmovaps [rsp+0x90], xmm10
000071c0d83dced1  vmovaps [rsp+0xA0], xmm11
000071c0d83dceda  vmovaps [rsp+0xB0], xmm12
000071c0d83dcee3  vmovaps [rsp+0xC0], xmm13
000071c0d83dceec  vmovaps [rsp+0xD0], xmm14
000071c0d83dcef5  vmovaps [rsp+0xE0], xmm15
000071c0d83dcefe  sub rsp, 0x30
000071c0d83dcf02  movaps [rsp], xmm6
000071c0d83dcf06  movaps [rsp+0x10], xmm12
000071c0d83dcf0c  movaps [rsp+0x20], xmm11
000071c0d83dcf12  lea rdi, [rsp]
000071c0d83dcf16  mov esi, 0x00
000071c0d83dcf1b  mov rax, 0x5904ED15D530
000071c0d83dcf25  call rax
000071c0d83dcf27  movaps xmm6, [rsp]
000071c0d83dcf2b  add rsp, 0x30
000071c0d83dcf2f  vmovaps xmm0, [rsp]
000071c0d83dcf34  vmovaps xmm1, [rsp+0x10]
000071c0d83dcf3a  vmovaps xmm2, [rsp+0x20]
000071c0d83dcf40  vmovaps xmm3, [rsp+0x30]
000071c0d83dcf46  vmovaps xmm4, [rsp+0x40]
000071c0d83dcf4c  vmovaps xmm5, [rsp+0x50]
000071c0d83dcf52  vmovaps xmm7, [rsp+0x60]
000071c0d83dcf58  vmovaps xmm8, [rsp+0x70]
000071c0d83dcf5e  vmovaps xmm9, [rsp+0x80]
000071c0d83dcf67  vmovaps xmm10, [rsp+0x90]
000071c0d83dcf70  vmovaps xmm11, [rsp+0xA0]
000071c0d83dcf79  vmovaps xmm12, [rsp+0xB0]
000071c0d83dcf82  vmovaps xmm13, [rsp+0xC0]
000071c0d83dcf8b  vmovaps xmm14, [rsp+0xD0]
000071c0d83dcf94  vmovaps xmm15, [rsp+0xE0]
000071c0d83dcf9d  add rsp, 0xF0
000071c0d83dcfa4  pop r11
000071c0d83dcfa6  pop r10
000071c0d83dcfa8  pop r9
000071c0d83dcfaa  pop r8
000071c0d83dcfac  pop rsi
000071c0d83dcfad  pop rdi
000071c0d83dcfae  pop rdx
000071c0d83dcfaf  pop rcx
000071c0d83dcfb0  pop rax
000071c0d83dcfb1  add rsp, 0x08
000071c0d83dcfb5  jmp 0x000071C0D83DBBD4
000071c0d83dcfba  sub rsp, 0x08
000071c0d83dcfbe  push rax
000071c0d83dcfbf  push rcx
000071c0d83dcfc0  push rdx
000071c0d83dcfc1  push rdi
000071c0d83dcfc2  push rsi
000071c0d83dcfc3  push r8
000071c0d83dcfc5  push r9
000071c0d83dcfc7  push r10
000071c0d83dcfc9  push r11
000071c0d83dcfcb  sub rsp, 0xF0
000071c0d83dcfd2  vmovaps [rsp], xmm0
000071c0d83dcfd7  vmovaps [rsp+0x10], xmm1
000071c0d83dcfdd  vmovaps [rsp+0x20], xmm2
000071c0d83dcfe3  vmovaps [rsp+0x30], xmm4
000071c0d83dcfe9  vmovaps [rsp+0x40], xmm5
000071c0d83dcfef  vmovaps [rsp+0x50], xmm6
000071c0d83dcff5  vmovaps [rsp+0x60], xmm7
000071c0d83dcffb  vmovaps [rsp+0x70], xmm8
000071c0d83dd001  vmovaps [rsp+0x80], xmm9
000071c0d83dd00a  vmovaps [rsp+0x90], xmm10
000071c0d83dd013  vmovaps [rsp+0xA0], xmm11
000071c0d83dd01c  vmovaps [rsp+0xB0], xmm12
000071c0d83dd025  vmovaps [rsp+0xC0], xmm13
000071c0d83dd02e  vmovaps [rsp+0xD0], xmm14
000071c0d83dd037  vmovaps [rsp+0xE0], xmm15
000071c0d83dd040  sub rsp, 0x30
000071c0d83dd044  movaps [rsp], xmm3
000071c0d83dd048  movaps [rsp+0x10], xmm5
000071c0d83dd04d  movaps [rsp+0x20], xmm4
000071c0d83dd052  lea rdi, [rsp]
000071c0d83dd056  mov esi, 0x00
000071c0d83dd05b  mov rax, 0x5904ED15D530
000071c0d83dd065  call rax
000071c0d83dd067  movaps xmm3, [rsp]
000071c0d83dd06b  add rsp, 0x30
000071c0d83dd06f  vmovaps xmm0, [rsp]
000071c0d83dd074  vmovaps xmm1, [rsp+0x10]
000071c0d83dd07a  vmovaps xmm2, [rsp+0x20]
000071c0d83dd080  vmovaps xmm4, [rsp+0x30]
000071c0d83dd086  vmovaps xmm5, [rsp+0x40]
000071c0d83dd08c  vmovaps xmm6, [rsp+0x50]
000071c0d83dd092  vmovaps xmm7, [rsp+0x60]
000071c0d83dd098  vmovaps xmm8, [rsp+0x70]
000071c0d83dd09e  vmovaps xmm9, [rsp+0x80]
000071c0d83dd0a7  vmovaps xmm10, [rsp+0x90]
000071c0d83dd0b0  vmovaps xmm11, [rsp+0xA0]
000071c0d83dd0b9  vmovaps xmm12, [rsp+0xB0]
000071c0d83dd0c2  vmovaps xmm13, [rsp+0xC0]
000071c0d83dd0cb  vmovaps xmm14, [rsp+0xD0]
000071c0d83dd0d4  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd0dd  add rsp, 0xF0
000071c0d83dd0e4  pop r11
000071c0d83dd0e6  pop r10
000071c0d83dd0e8  pop r9
000071c0d83dd0ea  pop r8
000071c0d83dd0ec  pop rsi
000071c0d83dd0ed  pop rdi
000071c0d83dd0ee  pop rdx
000071c0d83dd0ef  pop rcx
000071c0d83dd0f0  pop rax
000071c0d83dd0f1  add rsp, 0x08
000071c0d83dd0f5  jmp 0x000071C0D83DBC35
000071c0d83dd0fa  sub rsp, 0x08
000071c0d83dd0fe  push rax
000071c0d83dd0ff  push rcx
000071c0d83dd100  push rdx
000071c0d83dd101  push rdi
000071c0d83dd102  push rsi
000071c0d83dd103  push r8
000071c0d83dd105  push r9
000071c0d83dd107  push r10
000071c0d83dd109  push r11
000071c0d83dd10b  sub rsp, 0xF0
000071c0d83dd112  vmovaps [rsp], xmm0
000071c0d83dd117  vmovaps [rsp+0x10], xmm1
000071c0d83dd11d  vmovaps [rsp+0x20], xmm2
000071c0d83dd123  vmovaps [rsp+0x30], xmm3
000071c0d83dd129  vmovaps [rsp+0x40], xmm4
000071c0d83dd12f  vmovaps [rsp+0x50], xmm6
000071c0d83dd135  vmovaps [rsp+0x60], xmm7
000071c0d83dd13b  vmovaps [rsp+0x70], xmm8
000071c0d83dd141  vmovaps [rsp+0x80], xmm9
000071c0d83dd14a  vmovaps [rsp+0x90], xmm10
000071c0d83dd153  vmovaps [rsp+0xA0], xmm11
000071c0d83dd15c  vmovaps [rsp+0xB0], xmm12
000071c0d83dd165  vmovaps [rsp+0xC0], xmm13
000071c0d83dd16e  vmovaps [rsp+0xD0], xmm14
000071c0d83dd177  vmovaps [rsp+0xE0], xmm15
000071c0d83dd180  sub rsp, 0x30
000071c0d83dd184  movaps [rsp], xmm5
000071c0d83dd188  movaps [rsp+0x10], xmm8
000071c0d83dd18e  movaps [rsp+0x20], xmm15
000071c0d83dd194  lea rdi, [rsp]
000071c0d83dd198  mov esi, 0x00
000071c0d83dd19d  mov rax, 0x5904ED15D530
000071c0d83dd1a7  call rax
000071c0d83dd1a9  movaps xmm5, [rsp]
000071c0d83dd1ad  add rsp, 0x30
000071c0d83dd1b1  vmovaps xmm0, [rsp]
000071c0d83dd1b6  vmovaps xmm1, [rsp+0x10]
000071c0d83dd1bc  vmovaps xmm2, [rsp+0x20]
000071c0d83dd1c2  vmovaps xmm3, [rsp+0x30]
000071c0d83dd1c8  vmovaps xmm4, [rsp+0x40]
000071c0d83dd1ce  vmovaps xmm6, [rsp+0x50]
000071c0d83dd1d4  vmovaps xmm7, [rsp+0x60]
000071c0d83dd1da  vmovaps xmm8, [rsp+0x70]
000071c0d83dd1e0  vmovaps xmm9, [rsp+0x80]
000071c0d83dd1e9  vmovaps xmm10, [rsp+0x90]
000071c0d83dd1f2  vmovaps xmm11, [rsp+0xA0]
000071c0d83dd1fb  vmovaps xmm12, [rsp+0xB0]
000071c0d83dd204  vmovaps xmm13, [rsp+0xC0]
000071c0d83dd20d  vmovaps xmm14, [rsp+0xD0]
000071c0d83dd216  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd21f  add rsp, 0xF0
000071c0d83dd226  pop r11
000071c0d83dd228  pop r10
000071c0d83dd22a  pop r9
000071c0d83dd22c  pop r8
000071c0d83dd22e  pop rsi
000071c0d83dd22f  pop rdi
000071c0d83dd230  pop rdx
000071c0d83dd231  pop rcx
000071c0d83dd232  pop rax
000071c0d83dd233  add rsp, 0x08
000071c0d83dd237  jmp 0x000071C0D83DBC73
000071c0d83dd23c  sub rsp, 0x08
000071c0d83dd240  push rax
000071c0d83dd241  push rcx
000071c0d83dd242  push rdx
000071c0d83dd243  push rdi
000071c0d83dd244  push rsi
000071c0d83dd245  push r8
000071c0d83dd247  push r9
000071c0d83dd249  push r10
000071c0d83dd24b  push r11
000071c0d83dd24d  sub rsp, 0xF0
000071c0d83dd254  vmovaps [rsp], xmm0
000071c0d83dd259  vmovaps [rsp+0x10], xmm1
000071c0d83dd25f  vmovaps [rsp+0x20], xmm2
000071c0d83dd265  vmovaps [rsp+0x30], xmm3
000071c0d83dd26b  vmovaps [rsp+0x40], xmm5
000071c0d83dd271  vmovaps [rsp+0x50], xmm6
000071c0d83dd277  vmovaps [rsp+0x60], xmm7
000071c0d83dd27d  vmovaps [rsp+0x70], xmm8
000071c0d83dd283  vmovaps [rsp+0x80], xmm9
000071c0d83dd28c  vmovaps [rsp+0x90], xmm10
000071c0d83dd295  vmovaps [rsp+0xA0], xmm11
000071c0d83dd29e  vmovaps [rsp+0xB0], xmm12
000071c0d83dd2a7  vmovaps [rsp+0xC0], xmm13
000071c0d83dd2b0  vmovaps [rsp+0xD0], xmm14
000071c0d83dd2b9  vmovaps [rsp+0xE0], xmm15
000071c0d83dd2c2  sub rsp, 0x30
000071c0d83dd2c6  movaps [rsp], xmm4
000071c0d83dd2ca  movaps [rsp+0x10], xmm9
000071c0d83dd2d0  movaps [rsp+0x20], xmm8
000071c0d83dd2d6  lea rdi, [rsp]
000071c0d83dd2da  mov esi, 0x00
000071c0d83dd2df  mov rax, 0x5904ED15D530
000071c0d83dd2e9  call rax
000071c0d83dd2eb  movaps xmm4, [rsp]
000071c0d83dd2ef  add rsp, 0x30
000071c0d83dd2f3  vmovaps xmm0, [rsp]
000071c0d83dd2f8  vmovaps xmm1, [rsp+0x10]
000071c0d83dd2fe  vmovaps xmm2, [rsp+0x20]
000071c0d83dd304  vmovaps xmm3, [rsp+0x30]
000071c0d83dd30a  vmovaps xmm5, [rsp+0x40]
000071c0d83dd310  vmovaps xmm6, [rsp+0x50]
000071c0d83dd316  vmovaps xmm7, [rsp+0x60]
000071c0d83dd31c  vmovaps xmm8, [rsp+0x70]
000071c0d83dd322  vmovaps xmm9, [rsp+0x80]
000071c0d83dd32b  vmovaps xmm10, [rsp+0x90]
000071c0d83dd334  vmovaps xmm11, [rsp+0xA0]
000071c0d83dd33d  vmovaps xmm12, [rsp+0xB0]
000071c0d83dd346  vmovaps xmm13, [rsp+0xC0]
000071c0d83dd34f  vmovaps xmm14, [rsp+0xD0]
000071c0d83dd358  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd361  add rsp, 0xF0
000071c0d83dd368  pop r11
000071c0d83dd36a  pop r10
000071c0d83dd36c  pop r9
000071c0d83dd36e  pop r8
000071c0d83dd370  pop rsi
000071c0d83dd371  pop rdi
000071c0d83dd372  pop rdx
000071c0d83dd373  pop rcx
000071c0d83dd374  pop rax
000071c0d83dd375  add rsp, 0x08
000071c0d83dd379  jmp 0x000071C0D83DBC94
000071c0d83dd37e  sub rsp, 0x08
000071c0d83dd382  push rax
000071c0d83dd383  push rcx
000071c0d83dd384  push rdx
000071c0d83dd385  push rdi
000071c0d83dd386  push rsi
000071c0d83dd387  push r8
000071c0d83dd389  push r9
000071c0d83dd38b  push r10
000071c0d83dd38d  push r11
000071c0d83dd38f  sub rsp, 0xF0
000071c0d83dd396  vmovaps [rsp], xmm0
000071c0d83dd39b  vmovaps [rsp+0x10], xmm1
000071c0d83dd3a1  vmovaps [rsp+0x20], xmm2
000071c0d83dd3a7  vmovaps [rsp+0x30], xmm3
000071c0d83dd3ad  vmovaps [rsp+0x40], xmm4
000071c0d83dd3b3  vmovaps [rsp+0x50], xmm5
000071c0d83dd3b9  vmovaps [rsp+0x60], xmm6
000071c0d83dd3bf  vmovaps [rsp+0x70], xmm7
000071c0d83dd3c5  vmovaps [rsp+0x80], xmm8
000071c0d83dd3ce  vmovaps [rsp+0x90], xmm10
000071c0d83dd3d7  vmovaps [rsp+0xA0], xmm11
000071c0d83dd3e0  vmovaps [rsp+0xB0], xmm12
000071c0d83dd3e9  vmovaps [rsp+0xC0], xmm13
000071c0d83dd3f2  vmovaps [rsp+0xD0], xmm14
000071c0d83dd3fb  vmovaps [rsp+0xE0], xmm15
000071c0d83dd404  sub rsp, 0x30
000071c0d83dd408  movaps [rsp], xmm9
000071c0d83dd40d  movaps [rsp+0x10], xmm10
000071c0d83dd413  movaps [rsp+0x20], xmm8
000071c0d83dd419  lea rdi, [rsp]
000071c0d83dd41d  mov esi, 0x00
000071c0d83dd422  mov rax, 0x5904ED15D530
000071c0d83dd42c  call rax
000071c0d83dd42e  movaps xmm9, [rsp]
000071c0d83dd433  add rsp, 0x30
000071c0d83dd437  vmovaps xmm0, [rsp]
000071c0d83dd43c  vmovaps xmm1, [rsp+0x10]
000071c0d83dd442  vmovaps xmm2, [rsp+0x20]
000071c0d83dd448  vmovaps xmm3, [rsp+0x30]
000071c0d83dd44e  vmovaps xmm4, [rsp+0x40]
000071c0d83dd454  vmovaps xmm5, [rsp+0x50]
000071c0d83dd45a  vmovaps xmm6, [rsp+0x60]
000071c0d83dd460  vmovaps xmm7, [rsp+0x70]
000071c0d83dd466  vmovaps xmm8, [rsp+0x80]
000071c0d83dd46f  vmovaps xmm10, [rsp+0x90]
000071c0d83dd478  vmovaps xmm11, [rsp+0xA0]
000071c0d83dd481  vmovaps xmm12, [rsp+0xB0]
000071c0d83dd48a  vmovaps xmm13, [rsp+0xC0]
000071c0d83dd493  vmovaps xmm14, [rsp+0xD0]
000071c0d83dd49c  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd4a5  add rsp, 0xF0
000071c0d83dd4ac  pop r11
000071c0d83dd4ae  pop r10
000071c0d83dd4b0  pop r9
000071c0d83dd4b2  pop r8
000071c0d83dd4b4  pop rsi
000071c0d83dd4b5  pop rdi
000071c0d83dd4b6  pop rdx
000071c0d83dd4b7  pop rcx
000071c0d83dd4b8  pop rax
000071c0d83dd4b9  add rsp, 0x08
000071c0d83dd4bd  jmp 0x000071C0D83DBCAE
000071c0d83dd4c2  call 0x000071C0D82B52F0
000071c0d83dd4c7  jmp 0x000071C0D83DBDC8
000071c0d83dd4cc  call 0x000071C0D82B52F0
000071c0d83dd4d1  jmp 0x000071C0D83DBDDE
000071c0d83dd4d6  sub rsp, 0x08
000071c0d83dd4da  push rax
000071c0d83dd4db  push rcx
000071c0d83dd4dc  push rdx
000071c0d83dd4dd  push rdi
000071c0d83dd4de  push rsi
000071c0d83dd4df  push r8
000071c0d83dd4e1  push r9
000071c0d83dd4e3  push r10
000071c0d83dd4e5  push r11
000071c0d83dd4e7  sub rsp, 0xF0
000071c0d83dd4ee  vmovaps [rsp], xmm0
000071c0d83dd4f3  vmovaps [rsp+0x10], xmm2
000071c0d83dd4f9  vmovaps [rsp+0x20], xmm3
000071c0d83dd4ff  vmovaps [rsp+0x30], xmm4
000071c0d83dd505  vmovaps [rsp+0x40], xmm5
000071c0d83dd50b  vmovaps [rsp+0x50], xmm6
000071c0d83dd511  vmovaps [rsp+0x60], xmm7
000071c0d83dd517  vmovaps [rsp+0x70], xmm8
000071c0d83dd51d  vmovaps [rsp+0x80], xmm9
000071c0d83dd526  vmovaps [rsp+0x90], xmm10
000071c0d83dd52f  vmovaps [rsp+0xA0], xmm11
000071c0d83dd538  vmovaps [rsp+0xB0], xmm12
000071c0d83dd541  vmovaps [rsp+0xC0], xmm13
000071c0d83dd54a  vmovaps [rsp+0xD0], xmm14
000071c0d83dd553  vmovaps [rsp+0xE0], xmm15
000071c0d83dd55c  sub rsp, 0x30
000071c0d83dd560  movaps [rsp], xmm1
000071c0d83dd564  movaps [rsp+0x10], xmm6
000071c0d83dd569  movaps [rsp+0x20], xmm15
000071c0d83dd56f  lea rdi, [rsp]
000071c0d83dd573  mov esi, 0x00
000071c0d83dd578  mov rax, 0x5904ED15D530
000071c0d83dd582  call rax
000071c0d83dd584  movaps xmm1, [rsp]
000071c0d83dd588  add rsp, 0x30
000071c0d83dd58c  vmovaps xmm0, [rsp]
000071c0d83dd591  vmovaps xmm2, [rsp+0x10]
000071c0d83dd597  vmovaps xmm3, [rsp+0x20]
000071c0d83dd59d  vmovaps xmm4, [rsp+0x30]
000071c0d83dd5a3  vmovaps xmm5, [rsp+0x40]
000071c0d83dd5a9  vmovaps xmm6, [rsp+0x50]
000071c0d83dd5af  vmovaps xmm7, [rsp+0x60]
000071c0d83dd5b5  vmovaps xmm8, [rsp+0x70]
000071c0d83dd5bb  vmovaps xmm9, [rsp+0x80]
000071c0d83dd5c4  vmovaps xmm10, [rsp+0x90]
000071c0d83dd5cd  vmovaps xmm11, [rsp+0xA0]
000071c0d83dd5d6  vmovaps xmm12, [rsp+0xB0]
000071c0d83dd5df  vmovaps xmm13, [rsp+0xC0]
000071c0d83dd5e8  vmovaps xmm14, [rsp+0xD0]
000071c0d83dd5f1  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd5fa  add rsp, 0xF0
000071c0d83dd601  pop r11
000071c0d83dd603  pop r10
000071c0d83dd605  pop r9
000071c0d83dd607  pop r8
000071c0d83dd609  pop rsi
000071c0d83dd60a  pop rdi
000071c0d83dd60b  pop rdx
000071c0d83dd60c  pop rcx
000071c0d83dd60d  pop rax
000071c0d83dd60e  add rsp, 0x08
000071c0d83dd612  jmp 0x000071C0D83DBE1B
000071c0d83dd617  call 0x000071C0D82C4620
000071c0d83dd61c  jmp 0x000071C0D83DBE28
000071c0d83dd621  sub rsp, 0x08
000071c0d83dd625  push rax
000071c0d83dd626  push rcx
000071c0d83dd627  push rdx
000071c0d83dd628  push rdi
000071c0d83dd629  push rsi
000071c0d83dd62a  push r8
000071c0d83dd62c  push r9
000071c0d83dd62e  push r10
000071c0d83dd630  push r11
000071c0d83dd632  sub rsp, 0xF0
000071c0d83dd639  vmovaps [rsp], xmm0
000071c0d83dd63e  vmovaps [rsp+0x10], xmm1
000071c0d83dd644  vmovaps [rsp+0x20], xmm2
000071c0d83dd64a  vmovaps [rsp+0x30], xmm3
000071c0d83dd650  vmovaps [rsp+0x40], xmm4
000071c0d83dd656  vmovaps [rsp+0x50], xmm5
000071c0d83dd65c  vmovaps [rsp+0x60], xmm6
000071c0d83dd662  vmovaps [rsp+0x70], xmm7
000071c0d83dd668  vmovaps [rsp+0x80], xmm8
000071c0d83dd671  vmovaps [rsp+0x90], xmm9
000071c0d83dd67a  vmovaps [rsp+0xA0], xmm10
000071c0d83dd683  vmovaps [rsp+0xB0], xmm11
000071c0d83dd68c  vmovaps [rsp+0xC0], xmm12
000071c0d83dd695  vmovaps [rsp+0xD0], xmm13
000071c0d83dd69e  vmovaps [rsp+0xE0], xmm15
000071c0d83dd6a7  sub rsp, 0x30
000071c0d83dd6ab  movaps [rsp], xmm14
000071c0d83dd6b0  movaps [rsp+0x10], xmm4
000071c0d83dd6b5  movaps [rsp+0x20], xmm3
000071c0d83dd6ba  lea rdi, [rsp]
000071c0d83dd6be  mov esi, 0x00
000071c0d83dd6c3  mov rax, 0x5904ED15D530
000071c0d83dd6cd  call rax
000071c0d83dd6cf  movaps xmm14, [rsp]
000071c0d83dd6d4  add rsp, 0x30
000071c0d83dd6d8  vmovaps xmm0, [rsp]
000071c0d83dd6dd  vmovaps xmm1, [rsp+0x10]
000071c0d83dd6e3  vmovaps xmm2, [rsp+0x20]
000071c0d83dd6e9  vmovaps xmm3, [rsp+0x30]
000071c0d83dd6ef  vmovaps xmm4, [rsp+0x40]
000071c0d83dd6f5  vmovaps xmm5, [rsp+0x50]
000071c0d83dd6fb  vmovaps xmm6, [rsp+0x60]
000071c0d83dd701  vmovaps xmm7, [rsp+0x70]
000071c0d83dd707  vmovaps xmm8, [rsp+0x80]
000071c0d83dd710  vmovaps xmm9, [rsp+0x90]
000071c0d83dd719  vmovaps xmm10, [rsp+0xA0]
000071c0d83dd722  vmovaps xmm11, [rsp+0xB0]
000071c0d83dd72b  vmovaps xmm12, [rsp+0xC0]
000071c0d83dd734  vmovaps xmm13, [rsp+0xD0]
000071c0d83dd73d  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd746  add rsp, 0xF0
000071c0d83dd74d  pop r11
000071c0d83dd74f  pop r10
000071c0d83dd751  pop r9
000071c0d83dd753  pop r8
000071c0d83dd755  pop rsi
000071c0d83dd756  pop rdi
000071c0d83dd757  pop rdx
000071c0d83dd758  pop rcx
000071c0d83dd759  pop rax
000071c0d83dd75a  add rsp, 0x08
000071c0d83dd75e  jmp 0x000071C0D83DBE42
000071c0d83dd763  sub rsp, 0x08
000071c0d83dd767  push rax
000071c0d83dd768  push rcx
000071c0d83dd769  push rdx
000071c0d83dd76a  push rdi
000071c0d83dd76b  push rsi
000071c0d83dd76c  push r8
000071c0d83dd76e  push r9
000071c0d83dd770  push r10
000071c0d83dd772  push r11
000071c0d83dd774  sub rsp, 0xF0
000071c0d83dd77b  vmovaps [rsp], xmm0
000071c0d83dd780  vmovaps [rsp+0x10], xmm1
000071c0d83dd786  vmovaps [rsp+0x20], xmm2
000071c0d83dd78c  vmovaps [rsp+0x30], xmm3
000071c0d83dd792  vmovaps [rsp+0x40], xmm4
000071c0d83dd798  vmovaps [rsp+0x50], xmm5
000071c0d83dd79e  vmovaps [rsp+0x60], xmm7
000071c0d83dd7a4  vmovaps [rsp+0x70], xmm8
000071c0d83dd7aa  vmovaps [rsp+0x80], xmm9
000071c0d83dd7b3  vmovaps [rsp+0x90], xmm10
000071c0d83dd7bc  vmovaps [rsp+0xA0], xmm11
000071c0d83dd7c5  vmovaps [rsp+0xB0], xmm12
000071c0d83dd7ce  vmovaps [rsp+0xC0], xmm13
000071c0d83dd7d7  vmovaps [rsp+0xD0], xmm14
000071c0d83dd7e0  vmovaps [rsp+0xE0], xmm15
000071c0d83dd7e9  sub rsp, 0x30
000071c0d83dd7ed  movaps [rsp], xmm6
000071c0d83dd7f1  movaps [rsp+0x10], xmm9
000071c0d83dd7f7  movaps [rsp+0x20], xmm7
000071c0d83dd7fc  lea rdi, [rsp]
000071c0d83dd800  mov esi, 0x00
000071c0d83dd805  mov rax, 0x5904ED15D530
000071c0d83dd80f  call rax
000071c0d83dd811  movaps xmm6, [rsp]
000071c0d83dd815  add rsp, 0x30
000071c0d83dd819  vmovaps xmm0, [rsp]
000071c0d83dd81e  vmovaps xmm1, [rsp+0x10]
000071c0d83dd824  vmovaps xmm2, [rsp+0x20]
000071c0d83dd82a  vmovaps xmm3, [rsp+0x30]
000071c0d83dd830  vmovaps xmm4, [rsp+0x40]
000071c0d83dd836  vmovaps xmm5, [rsp+0x50]
000071c0d83dd83c  vmovaps xmm7, [rsp+0x60]
000071c0d83dd842  vmovaps xmm8, [rsp+0x70]
000071c0d83dd848  vmovaps xmm9, [rsp+0x80]
000071c0d83dd851  vmovaps xmm10, [rsp+0x90]
000071c0d83dd85a  vmovaps xmm11, [rsp+0xA0]
000071c0d83dd863  vmovaps xmm12, [rsp+0xB0]
000071c0d83dd86c  vmovaps xmm13, [rsp+0xC0]
000071c0d83dd875  vmovaps xmm14, [rsp+0xD0]
000071c0d83dd87e  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd887  add rsp, 0xF0
000071c0d83dd88e  pop r11
000071c0d83dd890  pop r10
000071c0d83dd892  pop r9
000071c0d83dd894  pop r8
000071c0d83dd896  pop rsi
000071c0d83dd897  pop rdi
000071c0d83dd898  pop rdx
000071c0d83dd899  pop rcx
000071c0d83dd89a  pop rax
000071c0d83dd89b  add rsp, 0x08
000071c0d83dd89f  jmp 0x000071C0D83DBE5A
000071c0d83dd8a4  sub rsp, 0x08
000071c0d83dd8a8  push rax
000071c0d83dd8a9  push rcx
000071c0d83dd8aa  push rdx
000071c0d83dd8ab  push rdi
000071c0d83dd8ac  push rsi
000071c0d83dd8ad  push r8
000071c0d83dd8af  push r9
000071c0d83dd8b1  push r10
000071c0d83dd8b3  push r11
000071c0d83dd8b5  sub rsp, 0xF0
000071c0d83dd8bc  vmovaps [rsp], xmm0
000071c0d83dd8c1  vmovaps [rsp+0x10], xmm1
000071c0d83dd8c7  vmovaps [rsp+0x20], xmm2
000071c0d83dd8cd  vmovaps [rsp+0x30], xmm3
000071c0d83dd8d3  vmovaps [rsp+0x40], xmm4
000071c0d83dd8d9  vmovaps [rsp+0x50], xmm5
000071c0d83dd8df  vmovaps [rsp+0x60], xmm6
000071c0d83dd8e5  vmovaps [rsp+0x70], xmm8
000071c0d83dd8eb  vmovaps [rsp+0x80], xmm9
000071c0d83dd8f4  vmovaps [rsp+0x90], xmm10
000071c0d83dd8fd  vmovaps [rsp+0xA0], xmm11
000071c0d83dd906  vmovaps [rsp+0xB0], xmm12
000071c0d83dd90f  vmovaps [rsp+0xC0], xmm13
000071c0d83dd918  vmovaps [rsp+0xD0], xmm14
000071c0d83dd921  vmovaps [rsp+0xE0], xmm15
000071c0d83dd92a  sub rsp, 0x30
000071c0d83dd92e  movaps [rsp], xmm7
000071c0d83dd932  movaps [rsp+0x10], xmm4
000071c0d83dd937  movaps [rsp+0x20], xmm9
000071c0d83dd93d  lea rdi, [rsp]
000071c0d83dd941  mov esi, 0x00
000071c0d83dd946  mov rax, 0x5904ED15D530
000071c0d83dd950  call rax
000071c0d83dd952  movaps xmm7, [rsp]
000071c0d83dd956  add rsp, 0x30
000071c0d83dd95a  vmovaps xmm0, [rsp]
000071c0d83dd95f  vmovaps xmm1, [rsp+0x10]
000071c0d83dd965  vmovaps xmm2, [rsp+0x20]
000071c0d83dd96b  vmovaps xmm3, [rsp+0x30]
000071c0d83dd971  vmovaps xmm4, [rsp+0x40]
000071c0d83dd977  vmovaps xmm5, [rsp+0x50]
000071c0d83dd97d  vmovaps xmm6, [rsp+0x60]
000071c0d83dd983  vmovaps xmm8, [rsp+0x70]
000071c0d83dd989  vmovaps xmm9, [rsp+0x80]
000071c0d83dd992  vmovaps xmm10, [rsp+0x90]
000071c0d83dd99b  vmovaps xmm11, [rsp+0xA0]
000071c0d83dd9a4  vmovaps xmm12, [rsp+0xB0]
000071c0d83dd9ad  vmovaps xmm13, [rsp+0xC0]
000071c0d83dd9b6  vmovaps xmm14, [rsp+0xD0]
000071c0d83dd9bf  vmovaps xmm15, [rsp+0xE0]
000071c0d83dd9c8  add rsp, 0xF0
000071c0d83dd9cf  pop r11
000071c0d83dd9d1  pop r10
000071c0d83dd9d3  pop r9
000071c0d83dd9d5  pop r8
000071c0d83dd9d7  pop rsi
000071c0d83dd9d8  pop rdi
000071c0d83dd9d9  pop rdx
000071c0d83dd9da  pop rcx
000071c0d83dd9db  pop rax
000071c0d83dd9dc  add rsp, 0x08
000071c0d83dd9e0  jmp 0x000071C0D83DBE87
000071c0d83dd9e5  sub rsp, 0x08
000071c0d83dd9e9  push rax
000071c0d83dd9ea  push rcx
000071c0d83dd9eb  push rdx
000071c0d83dd9ec  push rdi
000071c0d83dd9ed  push rsi
000071c0d83dd9ee  push r8
000071c0d83dd9f0  push r9
000071c0d83dd9f2  push r10
000071c0d83dd9f4  push r11
000071c0d83dd9f6  sub rsp, 0xF0
000071c0d83dd9fd  vmovaps [rsp], xmm0
000071c0d83dda02  vmovaps [rsp+0x10], xmm1
000071c0d83dda08  vmovaps [rsp+0x20], xmm2
000071c0d83dda0e  vmovaps [rsp+0x30], xmm3
000071c0d83dda14  vmovaps [rsp+0x40], xmm5
000071c0d83dda1a  vmovaps [rsp+0x50], xmm6
000071c0d83dda20  vmovaps [rsp+0x60], xmm7
000071c0d83dda26  vmovaps [rsp+0x70], xmm8
000071c0d83dda2c  vmovaps [rsp+0x80], xmm9
000071c0d83dda35  vmovaps [rsp+0x90], xmm10
000071c0d83dda3e  vmovaps [rsp+0xA0], xmm11
000071c0d83dda47  vmovaps [rsp+0xB0], xmm12
000071c0d83dda50  vmovaps [rsp+0xC0], xmm13
000071c0d83dda59  vmovaps [rsp+0xD0], xmm14
000071c0d83dda62  vmovaps [rsp+0xE0], xmm15
000071c0d83dda6b  sub rsp, 0x30
000071c0d83dda6f  movaps [rsp], xmm4
000071c0d83dda73  movaps [rsp+0x10], xmm15
000071c0d83dda79  movaps [rsp+0x20], xmm9
000071c0d83dda7f  lea rdi, [rsp]
000071c0d83dda83  mov esi, 0x00
000071c0d83dda88  mov rax, 0x5904ED15D530
000071c0d83dda92  call rax
000071c0d83dda94  movaps xmm4, [rsp]
000071c0d83dda98  add rsp, 0x30
000071c0d83dda9c  vmovaps xmm0, [rsp]
000071c0d83ddaa1  vmovaps xmm1, [rsp+0x10]
000071c0d83ddaa7  vmovaps xmm2, [rsp+0x20]
000071c0d83ddaad  vmovaps xmm3, [rsp+0x30]
000071c0d83ddab3  vmovaps xmm5, [rsp+0x40]
000071c0d83ddab9  vmovaps xmm6, [rsp+0x50]
000071c0d83ddabf  vmovaps xmm7, [rsp+0x60]
000071c0d83ddac5  vmovaps xmm8, [rsp+0x70]
000071c0d83ddacb  vmovaps xmm9, [rsp+0x80]
000071c0d83ddad4  vmovaps xmm10, [rsp+0x90]
000071c0d83ddadd  vmovaps xmm11, [rsp+0xA0]
000071c0d83ddae6  vmovaps xmm12, [rsp+0xB0]
000071c0d83ddaef  vmovaps xmm13, [rsp+0xC0]
000071c0d83ddaf8  vmovaps xmm14, [rsp+0xD0]
000071c0d83ddb01  vmovaps xmm15, [rsp+0xE0]
000071c0d83ddb0a  add rsp, 0xF0
000071c0d83ddb11  pop r11
000071c0d83ddb13  pop r10
000071c0d83ddb15  pop r9
000071c0d83ddb17  pop r8
000071c0d83ddb19  pop rsi
000071c0d83ddb1a  pop rdi
000071c0d83ddb1b  pop rdx
000071c0d83ddb1c  pop rcx
000071c0d83ddb1d  pop rax
000071c0d83ddb1e  add rsp, 0x08
000071c0d83ddb22  jmp 0x000071C0D83DBEAC
000071c0d83ddb27  call 0x000071C0D82C4620
000071c0d83ddb2c  jmp 0x000071C0D83DBEB9
000071c0d83ddb31  sub rsp, 0x08
000071c0d83ddb35  push rax
000071c0d83ddb36  push rcx
000071c0d83ddb37  push rdx
000071c0d83ddb38  push rdi
000071c0d83ddb39  push rsi
000071c0d83ddb3a  push r8
000071c0d83ddb3c  push r9
000071c0d83ddb3e  push r10
000071c0d83ddb40  push r11
000071c0d83ddb42  sub rsp, 0xF0
000071c0d83ddb49  vmovaps [rsp], xmm0
000071c0d83ddb4e  vmovaps [rsp+0x10], xmm1
000071c0d83ddb54  vmovaps [rsp+0x20], xmm2
000071c0d83ddb5a  vmovaps [rsp+0x30], xmm4
000071c0d83ddb60  vmovaps [rsp+0x40], xmm5
000071c0d83ddb66  vmovaps [rsp+0x50], xmm6
000071c0d83ddb6c  vmovaps [rsp+0x60], xmm7
000071c0d83ddb72  vmovaps [rsp+0x70], xmm8
000071c0d83ddb78  vmovaps [rsp+0x80], xmm9
000071c0d83ddb81  vmovaps [rsp+0x90], xmm10
000071c0d83ddb8a  vmovaps [rsp+0xA0], xmm11
000071c0d83ddb93  vmovaps [rsp+0xB0], xmm12
000071c0d83ddb9c  vmovaps [rsp+0xC0], xmm13
000071c0d83ddba5  vmovaps [rsp+0xD0], xmm14
000071c0d83ddbae  vmovaps [rsp+0xE0], xmm15
000071c0d83ddbb7  sub rsp, 0x30
000071c0d83ddbbb  movaps [rsp], xmm3
000071c0d83ddbbf  movaps [rsp+0x10], xmm1
000071c0d83ddbc4  movaps [rsp+0x20], xmm9
000071c0d83ddbca  lea rdi, [rsp]
000071c0d83ddbce  mov esi, 0x00
000071c0d83ddbd3  mov rax, 0x5904ED15D530
000071c0d83ddbdd  call rax
000071c0d83ddbdf  movaps xmm3, [rsp]
000071c0d83ddbe3  add rsp, 0x30
000071c0d83ddbe7  vmovaps xmm0, [rsp]
000071c0d83ddbec  vmovaps xmm1, [rsp+0x10]
000071c0d83ddbf2  vmovaps xmm2, [rsp+0x20]
000071c0d83ddbf8  vmovaps xmm4, [rsp+0x30]
000071c0d83ddbfe  vmovaps xmm5, [rsp+0x40]
000071c0d83ddc04  vmovaps xmm6, [rsp+0x50]
000071c0d83ddc0a  vmovaps xmm7, [rsp+0x60]
000071c0d83ddc10  vmovaps xmm8, [rsp+0x70]
000071c0d83ddc16  vmovaps xmm9, [rsp+0x80]
000071c0d83ddc1f  vmovaps xmm10, [rsp+0x90]
000071c0d83ddc28  vmovaps xmm11, [rsp+0xA0]
000071c0d83ddc31  vmovaps xmm12, [rsp+0xB0]
000071c0d83ddc3a  vmovaps xmm13, [rsp+0xC0]
000071c0d83ddc43  vmovaps xmm14, [rsp+0xD0]
000071c0d83ddc4c  vmovaps xmm15, [rsp+0xE0]
000071c0d83ddc55  add rsp, 0xF0
000071c0d83ddc5c  pop r11
000071c0d83ddc5e  pop r10
000071c0d83ddc60  pop r9
000071c0d83ddc62  pop r8
000071c0d83ddc64  pop rsi
000071c0d83ddc65  pop rdi
000071c0d83ddc66  pop rdx
000071c0d83ddc67  pop rcx
000071c0d83ddc68  pop rax
000071c0d83ddc69  add rsp, 0x08
000071c0d83ddc6d  jmp 0x000071C0D83DBEF6
000071c0d83ddc72  sub rsp, 0x08
000071c0d83ddc76  push rax
000071c0d83ddc77  push rcx
000071c0d83ddc78  push rdx
000071c0d83ddc79  push rdi
000071c0d83ddc7a  push rsi
000071c0d83ddc7b  push r8
000071c0d83ddc7d  push r9
000071c0d83ddc7f  push r10
000071c0d83ddc81  push r11
000071c0d83ddc83  sub rsp, 0xF0
000071c0d83ddc8a  vmovaps [rsp], xmm0
000071c0d83ddc8f  vmovaps [rsp+0x10], xmm2
000071c0d83ddc95  vmovaps [rsp+0x20], xmm3
000071c0d83ddc9b  vmovaps [rsp+0x30], xmm4
000071c0d83ddca1  vmovaps [rsp+0x40], xmm5
000071c0d83ddca7  vmovaps [rsp+0x50], xmm6
000071c0d83ddcad  vmovaps [rsp+0x60], xmm7
000071c0d83ddcb3  vmovaps [rsp+0x70], xmm8
000071c0d83ddcb9  vmovaps [rsp+0x80], xmm9
000071c0d83ddcc2  vmovaps [rsp+0x90], xmm10
000071c0d83ddccb  vmovaps [rsp+0xA0], xmm11
000071c0d83ddcd4  vmovaps [rsp+0xB0], xmm12
000071c0d83ddcdd  vmovaps [rsp+0xC0], xmm13
000071c0d83ddce6  vmovaps [rsp+0xD0], xmm14
000071c0d83ddcef  vmovaps [rsp+0xE0], xmm15
000071c0d83ddcf8  sub rsp, 0x30
000071c0d83ddcfc  movaps [rsp], xmm1
000071c0d83ddd00  movaps [rsp+0x10], xmm15
000071c0d83ddd06  movaps [rsp+0x20], xmm9
000071c0d83ddd0c  lea rdi, [rsp]
000071c0d83ddd10  mov esi, 0x00
000071c0d83ddd15  mov rax, 0x5904ED15D530
000071c0d83ddd1f  call rax
000071c0d83ddd21  movaps xmm1, [rsp]
000071c0d83ddd25  add rsp, 0x30
000071c0d83ddd29  vmovaps xmm0, [rsp]
000071c0d83ddd2e  vmovaps xmm2, [rsp+0x10]
000071c0d83ddd34  vmovaps xmm3, [rsp+0x20]
000071c0d83ddd3a  vmovaps xmm4, [rsp+0x30]
000071c0d83ddd40  vmovaps xmm5, [rsp+0x40]
000071c0d83ddd46  vmovaps xmm6, [rsp+0x50]
000071c0d83ddd4c  vmovaps xmm7, [rsp+0x60]
000071c0d83ddd52  vmovaps xmm8, [rsp+0x70]
000071c0d83ddd58  vmovaps xmm9, [rsp+0x80]
000071c0d83ddd61  vmovaps xmm10, [rsp+0x90]
000071c0d83ddd6a  vmovaps xmm11, [rsp+0xA0]
000071c0d83ddd73  vmovaps xmm12, [rsp+0xB0]
000071c0d83ddd7c  vmovaps xmm13, [rsp+0xC0]
000071c0d83ddd85  vmovaps xmm14, [rsp+0xD0]
000071c0d83ddd8e  vmovaps xmm15, [rsp+0xE0]
000071c0d83ddd97  add rsp, 0xF0
000071c0d83ddd9e  pop r11
000071c0d83ddda0  pop r10
000071c0d83ddda2  pop r9
000071c0d83ddda4  pop r8
000071c0d83ddda6  pop rsi
000071c0d83ddda7  pop rdi
000071c0d83ddda8  pop rdx
000071c0d83ddda9  pop rcx
000071c0d83dddaa  pop rax
000071c0d83dddab  add rsp, 0x08
000071c0d83dddaf  jmp 0x000071C0D83DBF7E
000071c0d83dddb4  call 0x000071C0D82C4620
000071c0d83dddb9  jmp 0x000071C0D83DBF8B
000071c0d83dddbe  sub rsp, 0x08
000071c0d83dddc2  push rax
000071c0d83dddc3  push rcx
000071c0d83dddc4  push rdx
000071c0d83dddc5  push rdi
000071c0d83dddc6  push rsi
000071c0d83dddc7  push r8
000071c0d83dddc9  push r9
000071c0d83dddcb  push r10
000071c0d83dddcd  push r11
000071c0d83dddcf  sub rsp, 0xF0
000071c0d83dddd6  vmovaps [rsp], xmm0
000071c0d83ddddb  vmovaps [rsp+0x10], xmm2
000071c0d83ddde1  vmovaps [rsp+0x20], xmm3
000071c0d83ddde7  vmovaps [rsp+0x30], xmm4
000071c0d83ddded  vmovaps [rsp+0x40], xmm5
000071c0d83dddf3  vmovaps [rsp+0x50], xmm6
000071c0d83dddf9  vmovaps [rsp+0x60], xmm7
000071c0d83dddff  vmovaps [rsp+0x70], xmm8
000071c0d83dde05  vmovaps [rsp+0x80], xmm9
000071c0d83dde0e  vmovaps [rsp+0x90], xmm10
000071c0d83dde17  vmovaps [rsp+0xA0], xmm11
000071c0d83dde20  vmovaps [rsp+0xB0], xmm12
000071c0d83dde29  vmovaps [rsp+0xC0], xmm13
000071c0d83dde32  vmovaps [rsp+0xD0], xmm14
000071c0d83dde3b  vmovaps [rsp+0xE0], xmm15
000071c0d83dde44  sub rsp, 0x30
000071c0d83dde48  movaps [rsp], xmm1
000071c0d83dde4c  movaps [rsp+0x10], xmm5
000071c0d83dde51  movaps [rsp+0x20], xmm7
000071c0d83dde56  lea rdi, [rsp]
000071c0d83dde5a  mov esi, 0x00
000071c0d83dde5f  mov rax, 0x5904ED15D530
000071c0d83dde69  call rax
000071c0d83dde6b  movaps xmm1, [rsp]
000071c0d83dde6f  add rsp, 0x30
000071c0d83dde73  vmovaps xmm0, [rsp]
000071c0d83dde78  vmovaps xmm2, [rsp+0x10]
000071c0d83dde7e  vmovaps xmm3, [rsp+0x20]
000071c0d83dde84  vmovaps xmm4, [rsp+0x30]
000071c0d83dde8a  vmovaps xmm5, [rsp+0x40]
000071c0d83dde90  vmovaps xmm6, [rsp+0x50]
000071c0d83dde96  vmovaps xmm7, [rsp+0x60]
000071c0d83dde9c  vmovaps xmm8, [rsp+0x70]
000071c0d83ddea2  vmovaps xmm9, [rsp+0x80]
000071c0d83ddeab  vmovaps xmm10, [rsp+0x90]
000071c0d83ddeb4  vmovaps xmm11, [rsp+0xA0]
000071c0d83ddebd  vmovaps xmm12, [rsp+0xB0]
000071c0d83ddec6  vmovaps xmm13, [rsp+0xC0]
000071c0d83ddecf  vmovaps xmm14, [rsp+0xD0]
000071c0d83dded8  vmovaps xmm15, [rsp+0xE0]
000071c0d83ddee1  add rsp, 0xF0
000071c0d83ddee8  pop r11
000071c0d83ddeea  pop r10
000071c0d83ddeec  pop r9
000071c0d83ddeee  pop r8
000071c0d83ddef0  pop rsi
000071c0d83ddef1  pop rdi
000071c0d83ddef2  pop rdx
000071c0d83ddef3  pop rcx
000071c0d83ddef4  pop rax
000071c0d83ddef5  add rsp, 0x08
000071c0d83ddef9  jmp 0x000071C0D83DC030
000071c0d83ddefe  sub rsp, 0x08
000071c0d83ddf02  push rax
000071c0d83ddf03  push rcx
000071c0d83ddf04  push rdx
000071c0d83ddf05  push rdi
000071c0d83ddf06  push rsi
000071c0d83ddf07  push r8
000071c0d83ddf09  push r9
000071c0d83ddf0b  push r10
000071c0d83ddf0d  push r11
000071c0d83ddf0f  sub rsp, 0xF0
000071c0d83ddf16  vmovaps [rsp], xmm0
000071c0d83ddf1b  vmovaps [rsp+0x10], xmm1
000071c0d83ddf21  vmovaps [rsp+0x20], xmm2
000071c0d83ddf27  vmovaps [rsp+0x30], xmm3
000071c0d83ddf2d  vmovaps [rsp+0x40], xmm4
000071c0d83ddf33  vmovaps [rsp+0x50], xmm5
000071c0d83ddf39  vmovaps [rsp+0x60], xmm6
000071c0d83ddf3f  vmovaps [rsp+0x70], xmm8
000071c0d83ddf45  vmovaps [rsp+0x80], xmm9
000071c0d83ddf4e  vmovaps [rsp+0x90], xmm10
000071c0d83ddf57  vmovaps [rsp+0xA0], xmm11
000071c0d83ddf60  vmovaps [rsp+0xB0], xmm12
000071c0d83ddf69  vmovaps [rsp+0xC0], xmm13
000071c0d83ddf72  vmovaps [rsp+0xD0], xmm14
000071c0d83ddf7b  vmovaps [rsp+0xE0], xmm15
000071c0d83ddf84  sub rsp, 0x30
000071c0d83ddf88  movaps [rsp], xmm7
000071c0d83ddf8c  movaps [rsp+0x10], xmm5
000071c0d83ddf91  movaps [rsp+0x20], xmm15
000071c0d83ddf97  lea rdi, [rsp]
000071c0d83ddf9b  mov esi, 0x00
000071c0d83ddfa0  mov rax, 0x5904ED15D530
000071c0d83ddfaa  call rax
000071c0d83ddfac  movaps xmm7, [rsp]
000071c0d83ddfb0  add rsp, 0x30
000071c0d83ddfb4  vmovaps xmm0, [rsp]
000071c0d83ddfb9  vmovaps xmm1, [rsp+0x10]
000071c0d83ddfbf  vmovaps xmm2, [rsp+0x20]
000071c0d83ddfc5  vmovaps xmm3, [rsp+0x30]
000071c0d83ddfcb  vmovaps xmm4, [rsp+0x40]
000071c0d83ddfd1  vmovaps xmm5, [rsp+0x50]
000071c0d83ddfd7  vmovaps xmm6, [rsp+0x60]
000071c0d83ddfdd  vmovaps xmm8, [rsp+0x70]
000071c0d83ddfe3  vmovaps xmm9, [rsp+0x80]
000071c0d83ddfec  vmovaps xmm10, [rsp+0x90]
000071c0d83ddff5  vmovaps xmm11, [rsp+0xA0]
000071c0d83ddffe  vmovaps xmm12, [rsp+0xB0]
000071c0d83de007  vmovaps xmm13, [rsp+0xC0]
000071c0d83de010  vmovaps xmm14, [rsp+0xD0]
000071c0d83de019  vmovaps xmm15, [rsp+0xE0]
000071c0d83de022  add rsp, 0xF0
000071c0d83de029  pop r11
000071c0d83de02b  pop r10
000071c0d83de02d  pop r9
000071c0d83de02f  pop r8
000071c0d83de031  pop rsi
000071c0d83de032  pop rdi
000071c0d83de033  pop rdx
000071c0d83de034  pop rcx
000071c0d83de035  pop rax
000071c0d83de036  add rsp, 0x08
000071c0d83de03a  jmp 0x000071C0D83DC066
000071c0d83de03f  call 0x000071C0D82B52F0
000071c0d83de044  jmp 0x000071C0D83DC073
000071c0d83de049  sub rsp, 0x08
000071c0d83de04d  push rax
000071c0d83de04e  push rcx
000071c0d83de04f  push rdx
000071c0d83de050  push rdi
000071c0d83de051  push rsi
000071c0d83de052  push r8
000071c0d83de054  push r9
000071c0d83de056  push r10
000071c0d83de058  push r11
000071c0d83de05a  sub rsp, 0xF0
000071c0d83de061  vmovaps [rsp], xmm0
000071c0d83de066  vmovaps [rsp+0x10], xmm1
000071c0d83de06c  vmovaps [rsp+0x20], xmm2
000071c0d83de072  vmovaps [rsp+0x30], xmm3
000071c0d83de078  vmovaps [rsp+0x40], xmm4
000071c0d83de07e  vmovaps [rsp+0x50], xmm5
000071c0d83de084  vmovaps [rsp+0x60], xmm6
000071c0d83de08a  vmovaps [rsp+0x70], xmm7
000071c0d83de090  vmovaps [rsp+0x80], xmm8
000071c0d83de099  vmovaps [rsp+0x90], xmm9
000071c0d83de0a2  vmovaps [rsp+0xA0], xmm10
000071c0d83de0ab  vmovaps [rsp+0xB0], xmm11
000071c0d83de0b4  vmovaps [rsp+0xC0], xmm12
000071c0d83de0bd  vmovaps [rsp+0xD0], xmm13
000071c0d83de0c6  vmovaps [rsp+0xE0], xmm14
000071c0d83de0cf  sub rsp, 0x30
000071c0d83de0d3  movaps [rsp], xmm15
000071c0d83de0d8  movaps [rsp+0x10], xmm5
000071c0d83de0dd  movaps [rsp+0x20], xmm3
000071c0d83de0e2  lea rdi, [rsp]
000071c0d83de0e6  mov esi, 0x00
000071c0d83de0eb  mov rax, 0x5904ED15D530
000071c0d83de0f5  call rax
000071c0d83de0f7  movaps xmm15, [rsp]
000071c0d83de0fc  add rsp, 0x30
000071c0d83de100  vmovaps xmm0, [rsp]
000071c0d83de105  vmovaps xmm1, [rsp+0x10]
000071c0d83de10b  vmovaps xmm2, [rsp+0x20]
000071c0d83de111  vmovaps xmm3, [rsp+0x30]
000071c0d83de117  vmovaps xmm4, [rsp+0x40]
000071c0d83de11d  vmovaps xmm5, [rsp+0x50]
000071c0d83de123  vmovaps xmm6, [rsp+0x60]
000071c0d83de129  vmovaps xmm7, [rsp+0x70]
000071c0d83de12f  vmovaps xmm8, [rsp+0x80]
000071c0d83de138  vmovaps xmm9, [rsp+0x90]
000071c0d83de141  vmovaps xmm10, [rsp+0xA0]
000071c0d83de14a  vmovaps xmm11, [rsp+0xB0]
000071c0d83de153  vmovaps xmm12, [rsp+0xC0]
000071c0d83de15c  vmovaps xmm13, [rsp+0xD0]
000071c0d83de165  vmovaps xmm14, [rsp+0xE0]
000071c0d83de16e  add rsp, 0xF0
000071c0d83de175  pop r11
000071c0d83de177  pop r10
000071c0d83de179  pop r9
000071c0d83de17b  pop r8
000071c0d83de17d  pop rsi
000071c0d83de17e  pop rdi
000071c0d83de17f  pop rdx
000071c0d83de180  pop rcx
000071c0d83de181  pop rax
000071c0d83de182  add rsp, 0x08
000071c0d83de186  jmp 0x000071C0D83DC099
000071c0d83de18b  sub rsp, 0x08
000071c0d83de18f  push rax
000071c0d83de190  push rcx
000071c0d83de191  push rdx
000071c0d83de192  push rdi
000071c0d83de193  push rsi
000071c0d83de194  push r8
000071c0d83de196  push r9
000071c0d83de198  push r10
000071c0d83de19a  push r11
000071c0d83de19c  sub rsp, 0xF0
000071c0d83de1a3  vmovaps [rsp], xmm0
000071c0d83de1a8  vmovaps [rsp+0x10], xmm2
000071c0d83de1ae  vmovaps [rsp+0x20], xmm3
000071c0d83de1b4  vmovaps [rsp+0x30], xmm4
000071c0d83de1ba  vmovaps [rsp+0x40], xmm5
000071c0d83de1c0  vmovaps [rsp+0x50], xmm6
000071c0d83de1c6  vmovaps [rsp+0x60], xmm7
000071c0d83de1cc  vmovaps [rsp+0x70], xmm8
000071c0d83de1d2  vmovaps [rsp+0x80], xmm9
000071c0d83de1db  vmovaps [rsp+0x90], xmm10
000071c0d83de1e4  vmovaps [rsp+0xA0], xmm11
000071c0d83de1ed  vmovaps [rsp+0xB0], xmm12
000071c0d83de1f6  vmovaps [rsp+0xC0], xmm13
000071c0d83de1ff  vmovaps [rsp+0xD0], xmm14
000071c0d83de208  vmovaps [rsp+0xE0], xmm15
000071c0d83de211  sub rsp, 0x30
000071c0d83de215  movaps [rsp], xmm1
000071c0d83de219  movaps [rsp+0x10], xmm5
000071c0d83de21e  movaps [rsp+0x20], xmm4
000071c0d83de223  lea rdi, [rsp]
000071c0d83de227  mov esi, 0x00
000071c0d83de22c  mov rax, 0x5904ED15D530
000071c0d83de236  call rax
000071c0d83de238  movaps xmm1, [rsp]
000071c0d83de23c  add rsp, 0x30
000071c0d83de240  vmovaps xmm0, [rsp]
000071c0d83de245  vmovaps xmm2, [rsp+0x10]
000071c0d83de24b  vmovaps xmm3, [rsp+0x20]
000071c0d83de251  vmovaps xmm4, [rsp+0x30]
000071c0d83de257  vmovaps xmm5, [rsp+0x40]
000071c0d83de25d  vmovaps xmm6, [rsp+0x50]
000071c0d83de263  vmovaps xmm7, [rsp+0x60]
000071c0d83de269  vmovaps xmm8, [rsp+0x70]
000071c0d83de26f  vmovaps xmm9, [rsp+0x80]
000071c0d83de278  vmovaps xmm10, [rsp+0x90]
000071c0d83de281  vmovaps xmm11, [rsp+0xA0]
000071c0d83de28a  vmovaps xmm12, [rsp+0xB0]
000071c0d83de293  vmovaps xmm13, [rsp+0xC0]
000071c0d83de29c  vmovaps xmm14, [rsp+0xD0]
000071c0d83de2a5  vmovaps xmm15, [rsp+0xE0]
000071c0d83de2ae  add rsp, 0xF0
000071c0d83de2b5  pop r11
000071c0d83de2b7  pop r10
000071c0d83de2b9  pop r9
000071c0d83de2bb  pop r8
000071c0d83de2bd  pop rsi
000071c0d83de2be  pop rdi
000071c0d83de2bf  pop rdx
000071c0d83de2c0  pop rcx
000071c0d83de2c1  pop rax
000071c0d83de2c2  add rsp, 0x08
000071c0d83de2c6  jmp 0x000071C0D83DC0B9
000071c0d83de2cb  sub rsp, 0x08
000071c0d83de2cf  push rax
000071c0d83de2d0  push rcx
000071c0d83de2d1  push rdx
000071c0d83de2d2  push rdi
000071c0d83de2d3  push rsi
000071c0d83de2d4  push r8
000071c0d83de2d6  push r9
000071c0d83de2d8  push r10
000071c0d83de2da  push r11
000071c0d83de2dc  sub rsp, 0xF0
000071c0d83de2e3  vmovaps [rsp], xmm0
000071c0d83de2e8  vmovaps [rsp+0x10], xmm1
000071c0d83de2ee  vmovaps [rsp+0x20], xmm2
000071c0d83de2f4  vmovaps [rsp+0x30], xmm3
000071c0d83de2fa  vmovaps [rsp+0x40], xmm5
000071c0d83de300  vmovaps [rsp+0x50], xmm6
000071c0d83de306  vmovaps [rsp+0x60], xmm7
000071c0d83de30c  vmovaps [rsp+0x70], xmm8
000071c0d83de312  vmovaps [rsp+0x80], xmm9
000071c0d83de31b  vmovaps [rsp+0x90], xmm10
000071c0d83de324  vmovaps [rsp+0xA0], xmm11
000071c0d83de32d  vmovaps [rsp+0xB0], xmm12
000071c0d83de336  vmovaps [rsp+0xC0], xmm13
000071c0d83de33f  vmovaps [rsp+0xD0], xmm14
000071c0d83de348  vmovaps [rsp+0xE0], xmm15
000071c0d83de351  sub rsp, 0x30
000071c0d83de355  movaps [rsp], xmm4
000071c0d83de359  movaps [rsp+0x10], xmm3
000071c0d83de35e  movaps [rsp+0x20], xmm5
000071c0d83de363  lea rdi, [rsp]
000071c0d83de367  mov esi, 0x00
000071c0d83de36c  mov rax, 0x5904ED15D530
000071c0d83de376  call rax
000071c0d83de378  movaps xmm4, [rsp]
000071c0d83de37c  add rsp, 0x30
000071c0d83de380  vmovaps xmm0, [rsp]
000071c0d83de385  vmovaps xmm1, [rsp+0x10]
000071c0d83de38b  vmovaps xmm2, [rsp+0x20]
000071c0d83de391  vmovaps xmm3, [rsp+0x30]
000071c0d83de397  vmovaps xmm5, [rsp+0x40]
000071c0d83de39d  vmovaps xmm6, [rsp+0x50]
000071c0d83de3a3  vmovaps xmm7, [rsp+0x60]
000071c0d83de3a9  vmovaps xmm8, [rsp+0x70]
000071c0d83de3af  vmovaps xmm9, [rsp+0x80]
000071c0d83de3b8  vmovaps xmm10, [rsp+0x90]
000071c0d83de3c1  vmovaps xmm11, [rsp+0xA0]
000071c0d83de3ca  vmovaps xmm12, [rsp+0xB0]
000071c0d83de3d3  vmovaps xmm13, [rsp+0xC0]
000071c0d83de3dc  vmovaps xmm14, [rsp+0xD0]
000071c0d83de3e5  vmovaps xmm15, [rsp+0xE0]
000071c0d83de3ee  add rsp, 0xF0
000071c0d83de3f5  pop r11
000071c0d83de3f7  pop r10
000071c0d83de3f9  pop r9
000071c0d83de3fb  pop r8
000071c0d83de3fd  pop rsi
000071c0d83de3fe  pop rdi
000071c0d83de3ff  pop rdx
000071c0d83de400  pop rcx
000071c0d83de401  pop rax
000071c0d83de402  add rsp, 0x08
000071c0d83de406  jmp 0x000071C0D83DC107
000071c0d83de40b  call 0x000071C0D82B52F0
000071c0d83de410  jmp 0x000071C0D83DC114
000071c0d83de415  sub rsp, 0x08
000071c0d83de419  push rax
000071c0d83de41a  push rcx
000071c0d83de41b  push rdx
000071c0d83de41c  push rdi
000071c0d83de41d  push rsi
000071c0d83de41e  push r8
000071c0d83de420  push r9
000071c0d83de422  push r10
000071c0d83de424  push r11
000071c0d83de426  sub rsp, 0xF0
000071c0d83de42d  vmovaps [rsp], xmm0
000071c0d83de432  vmovaps [rsp+0x10], xmm1
000071c0d83de438  vmovaps [rsp+0x20], xmm2
000071c0d83de43e  vmovaps [rsp+0x30], xmm3
000071c0d83de444  vmovaps [rsp+0x40], xmm4
000071c0d83de44a  vmovaps [rsp+0x50], xmm6
000071c0d83de450  vmovaps [rsp+0x60], xmm7
000071c0d83de456  vmovaps [rsp+0x70], xmm8
000071c0d83de45c  vmovaps [rsp+0x80], xmm9
000071c0d83de465  vmovaps [rsp+0x90], xmm10
000071c0d83de46e  vmovaps [rsp+0xA0], xmm11
000071c0d83de477  vmovaps [rsp+0xB0], xmm12
000071c0d83de480  vmovaps [rsp+0xC0], xmm13
000071c0d83de489  vmovaps [rsp+0xD0], xmm14
000071c0d83de492  vmovaps [rsp+0xE0], xmm15
000071c0d83de49b  sub rsp, 0x30
000071c0d83de49f  movaps [rsp], xmm5
000071c0d83de4a3  movaps [rsp+0x10], xmm6
000071c0d83de4a8  movaps [rsp+0x20], xmm3
000071c0d83de4ad  lea rdi, [rsp]
000071c0d83de4b1  mov esi, 0x00
000071c0d83de4b6  mov rax, 0x5904ED15D530
000071c0d83de4c0  call rax
000071c0d83de4c2  movaps xmm5, [rsp]
000071c0d83de4c6  add rsp, 0x30
000071c0d83de4ca  vmovaps xmm0, [rsp]
000071c0d83de4cf  vmovaps xmm1, [rsp+0x10]
000071c0d83de4d5  vmovaps xmm2, [rsp+0x20]
000071c0d83de4db  vmovaps xmm3, [rsp+0x30]
000071c0d83de4e1  vmovaps xmm4, [rsp+0x40]
000071c0d83de4e7  vmovaps xmm6, [rsp+0x50]
000071c0d83de4ed  vmovaps xmm7, [rsp+0x60]
000071c0d83de4f3  vmovaps xmm8, [rsp+0x70]
000071c0d83de4f9  vmovaps xmm9, [rsp+0x80]
000071c0d83de502  vmovaps xmm10, [rsp+0x90]
000071c0d83de50b  vmovaps xmm11, [rsp+0xA0]
000071c0d83de514  vmovaps xmm12, [rsp+0xB0]
000071c0d83de51d  vmovaps xmm13, [rsp+0xC0]
000071c0d83de526  vmovaps xmm14, [rsp+0xD0]
000071c0d83de52f  vmovaps xmm15, [rsp+0xE0]
000071c0d83de538  add rsp, 0xF0
000071c0d83de53f  pop r11
000071c0d83de541  pop r10
000071c0d83de543  pop r9
000071c0d83de545  pop r8
000071c0d83de547  pop rsi
000071c0d83de548  pop rdi
000071c0d83de549  pop rdx
000071c0d83de54a  pop rcx
000071c0d83de54b  pop rax
000071c0d83de54c  add rsp, 0x08
000071c0d83de550  jmp 0x000071C0D83DC13A
000071c0d83de555  sub rsp, 0x08
000071c0d83de559  push rax
000071c0d83de55a  push rcx
000071c0d83de55b  push rdx
000071c0d83de55c  push rdi
000071c0d83de55d  push rsi
000071c0d83de55e  push r8
000071c0d83de560  push r9
000071c0d83de562  push r10
000071c0d83de564  push r11
000071c0d83de566  sub rsp, 0xF0
000071c0d83de56d  vmovaps [rsp], xmm0
000071c0d83de572  vmovaps [rsp+0x10], xmm1
000071c0d83de578  vmovaps [rsp+0x20], xmm2
000071c0d83de57e  vmovaps [rsp+0x30], xmm3
000071c0d83de584  vmovaps [rsp+0x40], xmm4
000071c0d83de58a  vmovaps [rsp+0x50], xmm5
000071c0d83de590  vmovaps [rsp+0x60], xmm7
000071c0d83de596  vmovaps [rsp+0x70], xmm8
000071c0d83de59c  vmovaps [rsp+0x80], xmm9
000071c0d83de5a5  vmovaps [rsp+0x90], xmm10
000071c0d83de5ae  vmovaps [rsp+0xA0], xmm11
000071c0d83de5b7  vmovaps [rsp+0xB0], xmm12
000071c0d83de5c0  vmovaps [rsp+0xC0], xmm13
000071c0d83de5c9  vmovaps [rsp+0xD0], xmm14
000071c0d83de5d2  vmovaps [rsp+0xE0], xmm15
000071c0d83de5db  sub rsp, 0x30
000071c0d83de5df  movaps [rsp], xmm6
000071c0d83de5e3  movaps [rsp+0x10], xmm9
000071c0d83de5e9  movaps [rsp+0x20], xmm1
000071c0d83de5ee  lea rdi, [rsp]
000071c0d83de5f2  mov esi, 0x00
000071c0d83de5f7  mov rax, 0x5904ED15D530
000071c0d83de601  call rax
000071c0d83de603  movaps xmm6, [rsp]
000071c0d83de607  add rsp, 0x30
000071c0d83de60b  vmovaps xmm0, [rsp]
000071c0d83de610  vmovaps xmm1, [rsp+0x10]
000071c0d83de616  vmovaps xmm2, [rsp+0x20]
000071c0d83de61c  vmovaps xmm3, [rsp+0x30]
000071c0d83de622  vmovaps xmm4, [rsp+0x40]
000071c0d83de628  vmovaps xmm5, [rsp+0x50]
000071c0d83de62e  vmovaps xmm7, [rsp+0x60]
000071c0d83de634  vmovaps xmm8, [rsp+0x70]
000071c0d83de63a  vmovaps xmm9, [rsp+0x80]
000071c0d83de643  vmovaps xmm10, [rsp+0x90]
000071c0d83de64c  vmovaps xmm11, [rsp+0xA0]
000071c0d83de655  vmovaps xmm12, [rsp+0xB0]
000071c0d83de65e  vmovaps xmm13, [rsp+0xC0]
000071c0d83de667  vmovaps xmm14, [rsp+0xD0]
000071c0d83de670  vmovaps xmm15, [rsp+0xE0]
000071c0d83de679  add rsp, 0xF0
000071c0d83de680  pop r11
000071c0d83de682  pop r10
000071c0d83de684  pop r9
000071c0d83de686  pop r8
000071c0d83de688  pop rsi
000071c0d83de689  pop rdi
000071c0d83de68a  pop rdx
000071c0d83de68b  pop rcx
000071c0d83de68c  pop rax
000071c0d83de68d  add rsp, 0x08
000071c0d83de691  jmp 0x000071C0D83DC15E
000071c0d83de696  sub rsp, 0x08
000071c0d83de69a  push rax
000071c0d83de69b  push rcx
000071c0d83de69c  push rdx
000071c0d83de69d  push rdi
000071c0d83de69e  push rsi
000071c0d83de69f  push r8
000071c0d83de6a1  push r9
000071c0d83de6a3  push r10
000071c0d83de6a5  push r11
000071c0d83de6a7  sub rsp, 0xF0
000071c0d83de6ae  vmovaps [rsp], xmm0
000071c0d83de6b3  vmovaps [rsp+0x10], xmm1
000071c0d83de6b9  vmovaps [rsp+0x20], xmm2
000071c0d83de6bf  vmovaps [rsp+0x30], xmm3
000071c0d83de6c5  vmovaps [rsp+0x40], xmm4
000071c0d83de6cb  vmovaps [rsp+0x50], xmm5
000071c0d83de6d1  vmovaps [rsp+0x60], xmm6
000071c0d83de6d7  vmovaps [rsp+0x70], xmm7
000071c0d83de6dd  vmovaps [rsp+0x80], xmm8
000071c0d83de6e6  vmovaps [rsp+0x90], xmm10
000071c0d83de6ef  vmovaps [rsp+0xA0], xmm11
000071c0d83de6f8  vmovaps [rsp+0xB0], xmm12
000071c0d83de701  vmovaps [rsp+0xC0], xmm13
000071c0d83de70a  vmovaps [rsp+0xD0], xmm14
000071c0d83de713  vmovaps [rsp+0xE0], xmm15
000071c0d83de71c  sub rsp, 0x30
000071c0d83de720  movaps [rsp], xmm9
000071c0d83de725  movaps [rsp+0x10], xmm3
000071c0d83de72a  movaps [rsp+0x20], xmm1
000071c0d83de72f  lea rdi, [rsp]
000071c0d83de733  mov esi, 0x00
000071c0d83de738  mov rax, 0x5904ED15D530
000071c0d83de742  call rax
000071c0d83de744  movaps xmm9, [rsp]
000071c0d83de749  add rsp, 0x30
000071c0d83de74d  vmovaps xmm0, [rsp]
000071c0d83de752  vmovaps xmm1, [rsp+0x10]
000071c0d83de758  vmovaps xmm2, [rsp+0x20]
000071c0d83de75e  vmovaps xmm3, [rsp+0x30]
000071c0d83de764  vmovaps xmm4, [rsp+0x40]
000071c0d83de76a  vmovaps xmm5, [rsp+0x50]
000071c0d83de770  vmovaps xmm6, [rsp+0x60]
000071c0d83de776  vmovaps xmm7, [rsp+0x70]
000071c0d83de77c  vmovaps xmm8, [rsp+0x80]
000071c0d83de785  vmovaps xmm10, [rsp+0x90]
000071c0d83de78e  vmovaps xmm11, [rsp+0xA0]
000071c0d83de797  vmovaps xmm12, [rsp+0xB0]
000071c0d83de7a0  vmovaps xmm13, [rsp+0xC0]
000071c0d83de7a9  vmovaps xmm14, [rsp+0xD0]
000071c0d83de7b2  vmovaps xmm15, [rsp+0xE0]
000071c0d83de7bb  add rsp, 0xF0
000071c0d83de7c2  pop r11
000071c0d83de7c4  pop r10
000071c0d83de7c6  pop r9
000071c0d83de7c8  pop r8
000071c0d83de7ca  pop rsi
000071c0d83de7cb  pop rdi
000071c0d83de7cc  pop rdx
000071c0d83de7cd  pop rcx
000071c0d83de7ce  pop rax
000071c0d83de7cf  add rsp, 0x08
000071c0d83de7d3  jmp 0x000071C0D83DC1AA
000071c0d83de7d8  call 0x000071C0D82B52F0
000071c0d83de7dd  jmp 0x000071C0D83DC1B7
000071c0d83de7e2  sub rsp, 0x08
000071c0d83de7e6  push rax
000071c0d83de7e7  push rcx
000071c0d83de7e8  push rdx
000071c0d83de7e9  push rdi
000071c0d83de7ea  push rsi
000071c0d83de7eb  push r8
000071c0d83de7ed  push r9
000071c0d83de7ef  push r10
000071c0d83de7f1  push r11
000071c0d83de7f3  sub rsp, 0xF0
000071c0d83de7fa  vmovaps [rsp], xmm0
000071c0d83de7ff  vmovaps [rsp+0x10], xmm1
000071c0d83de805  vmovaps [rsp+0x20], xmm2
000071c0d83de80b  vmovaps [rsp+0x30], xmm3
000071c0d83de811  vmovaps [rsp+0x40], xmm4
000071c0d83de817  vmovaps [rsp+0x50], xmm5
000071c0d83de81d  vmovaps [rsp+0x60], xmm6
000071c0d83de823  vmovaps [rsp+0x70], xmm7
000071c0d83de829  vmovaps [rsp+0x80], xmm8
000071c0d83de832  vmovaps [rsp+0x90], xmm9
000071c0d83de83b  vmovaps [rsp+0xA0], xmm10
000071c0d83de844  vmovaps [rsp+0xB0], xmm11
000071c0d83de84d  vmovaps [rsp+0xC0], xmm12
000071c0d83de856  vmovaps [rsp+0xD0], xmm13
000071c0d83de85f  vmovaps [rsp+0xE0], xmm14
000071c0d83de868  sub rsp, 0x30
000071c0d83de86c  movaps [rsp], xmm15
000071c0d83de871  movaps [rsp+0x10], xmm3
000071c0d83de876  movaps [rsp+0x20], xmm7
000071c0d83de87b  lea rdi, [rsp]
000071c0d83de87f  mov esi, 0x00
000071c0d83de884  mov rax, 0x5904ED15D530
000071c0d83de88e  call rax
000071c0d83de890  movaps xmm15, [rsp]
000071c0d83de895  add rsp, 0x30
000071c0d83de899  vmovaps xmm0, [rsp]
000071c0d83de89e  vmovaps xmm1, [rsp+0x10]
000071c0d83de8a4  vmovaps xmm2, [rsp+0x20]
000071c0d83de8aa  vmovaps xmm3, [rsp+0x30]
000071c0d83de8b0  vmovaps xmm4, [rsp+0x40]
000071c0d83de8b6  vmovaps xmm5, [rsp+0x50]
000071c0d83de8bc  vmovaps xmm6, [rsp+0x60]
000071c0d83de8c2  vmovaps xmm7, [rsp+0x70]
000071c0d83de8c8  vmovaps xmm8, [rsp+0x80]
000071c0d83de8d1  vmovaps xmm9, [rsp+0x90]
000071c0d83de8da  vmovaps xmm10, [rsp+0xA0]
000071c0d83de8e3  vmovaps xmm11, [rsp+0xB0]
000071c0d83de8ec  vmovaps xmm12, [rsp+0xC0]
000071c0d83de8f5  vmovaps xmm13, [rsp+0xD0]
000071c0d83de8fe  vmovaps xmm14, [rsp+0xE0]
000071c0d83de907  add rsp, 0xF0
000071c0d83de90e  pop r11
000071c0d83de910  pop r10
000071c0d83de912  pop r9
000071c0d83de914  pop r8
000071c0d83de916  pop rsi
000071c0d83de917  pop rdi
000071c0d83de918  pop rdx
000071c0d83de919  pop rcx
000071c0d83de91a  pop rax
000071c0d83de91b  add rsp, 0x08
000071c0d83de91f  jmp 0x000071C0D83DC1E3
000071c0d83de924  sub rsp, 0x08
000071c0d83de928  push rax
000071c0d83de929  push rcx
000071c0d83de92a  push rdx
000071c0d83de92b  push rdi
000071c0d83de92c  push rsi
000071c0d83de92d  push r8
000071c0d83de92f  push r9
000071c0d83de931  push r10
000071c0d83de933  push r11
000071c0d83de935  sub rsp, 0xF0
000071c0d83de93c  vmovaps [rsp], xmm0
000071c0d83de941  vmovaps [rsp+0x10], xmm1
000071c0d83de947  vmovaps [rsp+0x20], xmm2
000071c0d83de94d  vmovaps [rsp+0x30], xmm4
000071c0d83de953  vmovaps [rsp+0x40], xmm5
000071c0d83de959  vmovaps [rsp+0x50], xmm6
000071c0d83de95f  vmovaps [rsp+0x60], xmm7
000071c0d83de965  vmovaps [rsp+0x70], xmm8
000071c0d83de96b  vmovaps [rsp+0x80], xmm9
000071c0d83de974  vmovaps [rsp+0x90], xmm10
000071c0d83de97d  vmovaps [rsp+0xA0], xmm11
000071c0d83de986  vmovaps [rsp+0xB0], xmm12
000071c0d83de98f  vmovaps [rsp+0xC0], xmm13
000071c0d83de998  vmovaps [rsp+0xD0], xmm14
000071c0d83de9a1  vmovaps [rsp+0xE0], xmm15
000071c0d83de9aa  sub rsp, 0x30
000071c0d83de9ae  movaps [rsp], xmm3
000071c0d83de9b2  movaps [rsp+0x10], xmm1
000071c0d83de9b7  movaps [rsp+0x20], xmm15
000071c0d83de9bd  lea rdi, [rsp]
000071c0d83de9c1  mov esi, 0x00
000071c0d83de9c6  mov rax, 0x5904ED15D530
000071c0d83de9d0  call rax
000071c0d83de9d2  movaps xmm3, [rsp]
000071c0d83de9d6  add rsp, 0x30
000071c0d83de9da  vmovaps xmm0, [rsp]
000071c0d83de9df  vmovaps xmm1, [rsp+0x10]
000071c0d83de9e5  vmovaps xmm2, [rsp+0x20]
000071c0d83de9eb  vmovaps xmm4, [rsp+0x30]
000071c0d83de9f1  vmovaps xmm5, [rsp+0x40]
000071c0d83de9f7  vmovaps xmm6, [rsp+0x50]
000071c0d83de9fd  vmovaps xmm7, [rsp+0x60]
000071c0d83dea03  vmovaps xmm8, [rsp+0x70]
000071c0d83dea09  vmovaps xmm9, [rsp+0x80]
000071c0d83dea12  vmovaps xmm10, [rsp+0x90]
000071c0d83dea1b  vmovaps xmm11, [rsp+0xA0]
000071c0d83dea24  vmovaps xmm12, [rsp+0xB0]
000071c0d83dea2d  vmovaps xmm13, [rsp+0xC0]
000071c0d83dea36  vmovaps xmm14, [rsp+0xD0]
000071c0d83dea3f  vmovaps xmm15, [rsp+0xE0]
000071c0d83dea48  add rsp, 0xF0
000071c0d83dea4f  pop r11
000071c0d83dea51  pop r10
000071c0d83dea53  pop r9
000071c0d83dea55  pop r8
000071c0d83dea57  pop rsi
000071c0d83dea58  pop rdi
000071c0d83dea59  pop rdx
000071c0d83dea5a  pop rcx
000071c0d83dea5b  pop rax
000071c0d83dea5c  add rsp, 0x08
000071c0d83dea60  jmp 0x000071C0D83DC272
000071c0d83dea65  call 0x000071C0D82B52F0
000071c0d83dea6a  jmp 0x000071C0D83DC27C
000071c0d83dea6f  sub rsp, 0x08
000071c0d83dea73  push rax
000071c0d83dea74  push rcx
000071c0d83dea75  push rdx
000071c0d83dea76  push rdi
000071c0d83dea77  push rsi
000071c0d83dea78  push r8
000071c0d83dea7a  push r9
000071c0d83dea7c  push r10
000071c0d83dea7e  push r11
000071c0d83dea80  sub rsp, 0xF0
000071c0d83dea87  vmovaps [rsp], xmm0
000071c0d83dea8c  vmovaps [rsp+0x10], xmm1
000071c0d83dea92  vmovaps [rsp+0x20], xmm2
000071c0d83dea98  vmovaps [rsp+0x30], xmm3
000071c0d83dea9e  vmovaps [rsp+0x40], xmm4
000071c0d83deaa4  vmovaps [rsp+0x50], xmm5
000071c0d83deaaa  vmovaps [rsp+0x60], xmm6
000071c0d83deab0  vmovaps [rsp+0x70], xmm7
000071c0d83deab6  vmovaps [rsp+0x80], xmm8
000071c0d83deabf  vmovaps [rsp+0x90], xmm9
000071c0d83deac8  vmovaps [rsp+0xA0], xmm10
000071c0d83dead1  vmovaps [rsp+0xB0], xmm11
000071c0d83deada  vmovaps [rsp+0xC0], xmm12
000071c0d83deae3  vmovaps [rsp+0xD0], xmm13
000071c0d83deaec  vmovaps [rsp+0xE0], xmm14
000071c0d83deaf5  sub rsp, 0x30
000071c0d83deaf9  movaps [rsp], xmm15
000071c0d83deafe  movaps [rsp+0x10], xmm14
000071c0d83deb04  movaps [rsp+0x20], xmm4
000071c0d83deb09  lea rdi, [rsp]
000071c0d83deb0d  mov esi, 0x00
000071c0d83deb12  mov rax, 0x5904ED15D530
000071c0d83deb1c  call rax
000071c0d83deb1e  movaps xmm15, [rsp]
000071c0d83deb23  add rsp, 0x30
000071c0d83deb27  vmovaps xmm0, [rsp]
000071c0d83deb2c  vmovaps xmm1, [rsp+0x10]
000071c0d83deb32  vmovaps xmm2, [rsp+0x20]
000071c0d83deb38  vmovaps xmm3, [rsp+0x30]
000071c0d83deb3e  vmovaps xmm4, [rsp+0x40]
000071c0d83deb44  vmovaps xmm5, [rsp+0x50]
000071c0d83deb4a  vmovaps xmm6, [rsp+0x60]
000071c0d83deb50  vmovaps xmm7, [rsp+0x70]
000071c0d83deb56  vmovaps xmm8, [rsp+0x80]
000071c0d83deb5f  vmovaps xmm9, [rsp+0x90]
000071c0d83deb68  vmovaps xmm10, [rsp+0xA0]
000071c0d83deb71  vmovaps xmm11, [rsp+0xB0]
000071c0d83deb7a  vmovaps xmm12, [rsp+0xC0]
000071c0d83deb83  vmovaps xmm13, [rsp+0xD0]
000071c0d83deb8c  vmovaps xmm14, [rsp+0xE0]
000071c0d83deb95  add rsp, 0xF0
000071c0d83deb9c  pop r11
000071c0d83deb9e  pop r10
000071c0d83deba0  pop r9
000071c0d83deba2  pop r8
000071c0d83deba4  pop rsi
000071c0d83deba5  pop rdi
000071c0d83deba6  pop rdx
000071c0d83deba7  pop rcx
000071c0d83deba8  pop rax
000071c0d83deba9  add rsp, 0x08
000071c0d83debad  jmp 0x000071C0D83DC2AA
000071c0d83debb2  sub rsp, 0x08
000071c0d83debb6  push rax
000071c0d83debb7  push rcx
000071c0d83debb8  push rdx
000071c0d83debb9  push rdi
000071c0d83debba  push rsi
000071c0d83debbb  push r8
000071c0d83debbd  push r9
000071c0d83debbf  push r10
000071c0d83debc1  push r11
000071c0d83debc3  sub rsp, 0xF0
000071c0d83debca  vmovaps [rsp], xmm0
000071c0d83debcf  vmovaps [rsp+0x10], xmm1
000071c0d83debd5  vmovaps [rsp+0x20], xmm2
000071c0d83debdb  vmovaps [rsp+0x30], xmm3
000071c0d83debe1  vmovaps [rsp+0x40], xmm4
000071c0d83debe7  vmovaps [rsp+0x50], xmm5
000071c0d83debed  vmovaps [rsp+0x60], xmm6
000071c0d83debf3  vmovaps [rsp+0x70], xmm7
000071c0d83debf9  vmovaps [rsp+0x80], xmm8
000071c0d83dec02  vmovaps [rsp+0x90], xmm9
000071c0d83dec0b  vmovaps [rsp+0xA0], xmm10
000071c0d83dec14  vmovaps [rsp+0xB0], xmm11
000071c0d83dec1d  vmovaps [rsp+0xC0], xmm12
000071c0d83dec26  vmovaps [rsp+0xD0], xmm13
000071c0d83dec2f  vmovaps [rsp+0xE0], xmm15
000071c0d83dec38  sub rsp, 0x30
000071c0d83dec3c  movaps [rsp], xmm14
000071c0d83dec41  movaps [rsp+0x10], xmm2
000071c0d83dec46  movaps [rsp+0x20], xmm1
000071c0d83dec4b  lea rdi, [rsp]
000071c0d83dec4f  mov esi, 0x00
000071c0d83dec54  mov rax, 0x5904ED15D530
000071c0d83dec5e  call rax
000071c0d83dec60  movaps xmm14, [rsp]
000071c0d83dec65  add rsp, 0x30
000071c0d83dec69  vmovaps xmm0, [rsp]
000071c0d83dec6e  vmovaps xmm1, [rsp+0x10]
000071c0d83dec74  vmovaps xmm2, [rsp+0x20]
000071c0d83dec7a  vmovaps xmm3, [rsp+0x30]
000071c0d83dec80  vmovaps xmm4, [rsp+0x40]
000071c0d83dec86  vmovaps xmm5, [rsp+0x50]
000071c0d83dec8c  vmovaps xmm6, [rsp+0x60]
000071c0d83dec92  vmovaps xmm7, [rsp+0x70]
000071c0d83dec98  vmovaps xmm8, [rsp+0x80]
000071c0d83deca1  vmovaps xmm9, [rsp+0x90]
000071c0d83decaa  vmovaps xmm10, [rsp+0xA0]
000071c0d83decb3  vmovaps xmm11, [rsp+0xB0]
000071c0d83decbc  vmovaps xmm12, [rsp+0xC0]
000071c0d83decc5  vmovaps xmm13, [rsp+0xD0]
000071c0d83decce  vmovaps xmm15, [rsp+0xE0]
000071c0d83decd7  add rsp, 0xF0
000071c0d83decde  pop r11
000071c0d83dece0  pop r10
000071c0d83dece2  pop r9
000071c0d83dece4  pop r8
000071c0d83dece6  pop rsi
000071c0d83dece7  pop rdi
000071c0d83dece8  pop rdx
000071c0d83dece9  pop rcx
000071c0d83decea  pop rax
000071c0d83deceb  add rsp, 0x08
000071c0d83decef  jmp 0x000071C0D83DC2D0
000071c0d83decf4  sub rsp, 0x08
000071c0d83decf8  push rax
000071c0d83decf9  push rcx
000071c0d83decfa  push rdx
000071c0d83decfb  push rdi
000071c0d83decfc  push rsi
000071c0d83decfd  push r8
000071c0d83decff  push r9
000071c0d83ded01  push r10
000071c0d83ded03  push r11
000071c0d83ded05  sub rsp, 0xF0
000071c0d83ded0c  vmovaps [rsp], xmm0
000071c0d83ded11  vmovaps [rsp+0x10], xmm2
000071c0d83ded17  vmovaps [rsp+0x20], xmm3
000071c0d83ded1d  vmovaps [rsp+0x30], xmm4
000071c0d83ded23  vmovaps [rsp+0x40], xmm5
000071c0d83ded29  vmovaps [rsp+0x50], xmm6
000071c0d83ded2f  vmovaps [rsp+0x60], xmm7
000071c0d83ded35  vmovaps [rsp+0x70], xmm8
000071c0d83ded3b  vmovaps [rsp+0x80], xmm9
000071c0d83ded44  vmovaps [rsp+0x90], xmm10
000071c0d83ded4d  vmovaps [rsp+0xA0], xmm11
000071c0d83ded56  vmovaps [rsp+0xB0], xmm12
000071c0d83ded5f  vmovaps [rsp+0xC0], xmm13
000071c0d83ded68  vmovaps [rsp+0xD0], xmm14
000071c0d83ded71  vmovaps [rsp+0xE0], xmm15
000071c0d83ded7a  sub rsp, 0x30
000071c0d83ded7e  movaps [rsp], xmm1
000071c0d83ded82  movaps [rsp+0x10], xmm4
000071c0d83ded87  movaps [rsp+0x20], xmm9
000071c0d83ded8d  lea rdi, [rsp]
000071c0d83ded91  mov esi, 0x00
000071c0d83ded96  mov rax, 0x5904ED15D530
000071c0d83deda0  call rax
000071c0d83deda2  movaps xmm1, [rsp]
000071c0d83deda6  add rsp, 0x30
000071c0d83dedaa  vmovaps xmm0, [rsp]
000071c0d83dedaf  vmovaps xmm2, [rsp+0x10]
000071c0d83dedb5  vmovaps xmm3, [rsp+0x20]
000071c0d83dedbb  vmovaps xmm4, [rsp+0x30]
000071c0d83dedc1  vmovaps xmm5, [rsp+0x40]
000071c0d83dedc7  vmovaps xmm6, [rsp+0x50]
000071c0d83dedcd  vmovaps xmm7, [rsp+0x60]
000071c0d83dedd3  vmovaps xmm8, [rsp+0x70]
000071c0d83dedd9  vmovaps xmm9, [rsp+0x80]
000071c0d83dede2  vmovaps xmm10, [rsp+0x90]
000071c0d83dedeb  vmovaps xmm11, [rsp+0xA0]
000071c0d83dedf4  vmovaps xmm12, [rsp+0xB0]
000071c0d83dedfd  vmovaps xmm13, [rsp+0xC0]
000071c0d83dee06  vmovaps xmm14, [rsp+0xD0]
000071c0d83dee0f  vmovaps xmm15, [rsp+0xE0]
000071c0d83dee18  add rsp, 0xF0
000071c0d83dee1f  pop r11
000071c0d83dee21  pop r10
000071c0d83dee23  pop r9
000071c0d83dee25  pop r8
000071c0d83dee27  pop rsi
000071c0d83dee28  pop rdi
000071c0d83dee29  pop rdx
000071c0d83dee2a  pop rcx
000071c0d83dee2b  pop rax
000071c0d83dee2c  add rsp, 0x08
000071c0d83dee30  jmp 0x000071C0D83DC2EE
000071c0d83dee35  sub rsp, 0x08
000071c0d83dee39  push rax
000071c0d83dee3a  push rcx
000071c0d83dee3b  push rdx
000071c0d83dee3c  push rdi
000071c0d83dee3d  push rsi
000071c0d83dee3e  push r8
000071c0d83dee40  push r9
000071c0d83dee42  push r10
000071c0d83dee44  push r11
000071c0d83dee46  sub rsp, 0xF0
000071c0d83dee4d  vmovaps [rsp], xmm0
000071c0d83dee52  vmovaps [rsp+0x10], xmm1
000071c0d83dee58  vmovaps [rsp+0x20], xmm2
000071c0d83dee5e  vmovaps [rsp+0x30], xmm3
000071c0d83dee64  vmovaps [rsp+0x40], xmm5
000071c0d83dee6a  vmovaps [rsp+0x50], xmm6
000071c0d83dee70  vmovaps [rsp+0x60], xmm7
000071c0d83dee76  vmovaps [rsp+0x70], xmm8
000071c0d83dee7c  vmovaps [rsp+0x80], xmm9
000071c0d83dee85  vmovaps [rsp+0x90], xmm10
000071c0d83dee8e  vmovaps [rsp+0xA0], xmm11
000071c0d83dee97  vmovaps [rsp+0xB0], xmm12
000071c0d83deea0  vmovaps [rsp+0xC0], xmm13
000071c0d83deea9  vmovaps [rsp+0xD0], xmm14
000071c0d83deeb2  vmovaps [rsp+0xE0], xmm15
000071c0d83deebb  sub rsp, 0x30
000071c0d83deebf  movaps [rsp], xmm4
000071c0d83deec3  movaps [rsp+0x10], xmm2
000071c0d83deec8  movaps [rsp+0x20], xmm9
000071c0d83deece  lea rdi, [rsp]
000071c0d83deed2  mov esi, 0x00
000071c0d83deed7  mov rax, 0x5904ED15D530
000071c0d83deee1  call rax
000071c0d83deee3  movaps xmm4, [rsp]
000071c0d83deee7  add rsp, 0x30
000071c0d83deeeb  vmovaps xmm0, [rsp]
000071c0d83deef0  vmovaps xmm1, [rsp+0x10]
000071c0d83deef6  vmovaps xmm2, [rsp+0x20]
000071c0d83deefc  vmovaps xmm3, [rsp+0x30]
000071c0d83def02  vmovaps xmm5, [rsp+0x40]
000071c0d83def08  vmovaps xmm6, [rsp+0x50]
000071c0d83def0e  vmovaps xmm7, [rsp+0x60]
000071c0d83def14  vmovaps xmm8, [rsp+0x70]
000071c0d83def1a  vmovaps xmm9, [rsp+0x80]
000071c0d83def23  vmovaps xmm10, [rsp+0x90]
000071c0d83def2c  vmovaps xmm11, [rsp+0xA0]
000071c0d83def35  vmovaps xmm12, [rsp+0xB0]
000071c0d83def3e  vmovaps xmm13, [rsp+0xC0]
000071c0d83def47  vmovaps xmm14, [rsp+0xD0]
000071c0d83def50  vmovaps xmm15, [rsp+0xE0]
000071c0d83def59  add rsp, 0xF0
000071c0d83def60  pop r11
000071c0d83def62  pop r10
000071c0d83def64  pop r9
000071c0d83def66  pop r8
000071c0d83def68  pop rsi
000071c0d83def69  pop rdi
000071c0d83def6a  pop rdx
000071c0d83def6b  pop rcx
000071c0d83def6c  pop rax
000071c0d83def6d  add rsp, 0x08
000071c0d83def71  jmp 0x000071C0D83DC31E
000071c0d83def76  sub rsp, 0x08
000071c0d83def7a  push rax
000071c0d83def7b  push rcx
000071c0d83def7c  push rdx
000071c0d83def7d  push rdi
000071c0d83def7e  push rsi
000071c0d83def7f  push r8
000071c0d83def81  push r9
000071c0d83def83  push r10
000071c0d83def85  push r11
000071c0d83def87  sub rsp, 0xF0
000071c0d83def8e  vmovaps [rsp], xmm0
000071c0d83def93  vmovaps [rsp+0x10], xmm1
000071c0d83def99  vmovaps [rsp+0x20], xmm2
000071c0d83def9f  vmovaps [rsp+0x30], xmm3
000071c0d83defa5  vmovaps [rsp+0x40], xmm4
000071c0d83defab  vmovaps [rsp+0x50], xmm5
000071c0d83defb1  vmovaps [rsp+0x60], xmm6
000071c0d83defb7  vmovaps [rsp+0x70], xmm7
000071c0d83defbd  vmovaps [rsp+0x80], xmm8
000071c0d83defc6  vmovaps [rsp+0x90], xmm10
000071c0d83defcf  vmovaps [rsp+0xA0], xmm11
000071c0d83defd8  vmovaps [rsp+0xB0], xmm12
000071c0d83defe1  vmovaps [rsp+0xC0], xmm13
000071c0d83defea  vmovaps [rsp+0xD0], xmm14
000071c0d83deff3  vmovaps [rsp+0xE0], xmm15
000071c0d83deffc  sub rsp, 0x30
000071c0d83df000  movaps [rsp], xmm9
000071c0d83df005  movaps [rsp+0x10], xmm2
000071c0d83df00a  movaps [rsp+0x20], xmm1
000071c0d83df00f  lea rdi, [rsp]
000071c0d83df013  mov esi, 0x00
000071c0d83df018  mov rax, 0x5904ED15D530
000071c0d83df022  call rax
000071c0d83df024  movaps xmm9, [rsp]
000071c0d83df029  add rsp, 0x30
000071c0d83df02d  vmovaps xmm0, [rsp]
000071c0d83df032  vmovaps xmm1, [rsp+0x10]
000071c0d83df038  vmovaps xmm2, [rsp+0x20]
000071c0d83df03e  vmovaps xmm3, [rsp+0x30]
000071c0d83df044  vmovaps xmm4, [rsp+0x40]
000071c0d83df04a  vmovaps xmm5, [rsp+0x50]
000071c0d83df050  vmovaps xmm6, [rsp+0x60]
000071c0d83df056  vmovaps xmm7, [rsp+0x70]
000071c0d83df05c  vmovaps xmm8, [rsp+0x80]
000071c0d83df065  vmovaps xmm10, [rsp+0x90]
000071c0d83df06e  vmovaps xmm11, [rsp+0xA0]
000071c0d83df077  vmovaps xmm12, [rsp+0xB0]
000071c0d83df080  vmovaps xmm13, [rsp+0xC0]
000071c0d83df089  vmovaps xmm14, [rsp+0xD0]
000071c0d83df092  vmovaps xmm15, [rsp+0xE0]
000071c0d83df09b  add rsp, 0xF0
000071c0d83df0a2  pop r11
000071c0d83df0a4  pop r10
000071c0d83df0a6  pop r9
000071c0d83df0a8  pop r8
000071c0d83df0aa  pop rsi
000071c0d83df0ab  pop rdi
000071c0d83df0ac  pop rdx
000071c0d83df0ad  pop rcx
000071c0d83df0ae  pop rax
000071c0d83df0af  add rsp, 0x08
000071c0d83df0b3  jmp 0x000071C0D83DC354
000071c0d83df0b8  sub rsp, 0x08
000071c0d83df0bc  push rax
000071c0d83df0bd  push rcx
000071c0d83df0be  push rdx
000071c0d83df0bf  push rdi
000071c0d83df0c0  push rsi
000071c0d83df0c1  push r8
000071c0d83df0c3  push r9
000071c0d83df0c5  push r10
000071c0d83df0c7  push r11
000071c0d83df0c9  sub rsp, 0xF0
000071c0d83df0d0  vmovaps [rsp], xmm0
000071c0d83df0d5  vmovaps [rsp+0x10], xmm2
000071c0d83df0db  vmovaps [rsp+0x20], xmm3
000071c0d83df0e1  vmovaps [rsp+0x30], xmm4
000071c0d83df0e7  vmovaps [rsp+0x40], xmm5
000071c0d83df0ed  vmovaps [rsp+0x50], xmm6
000071c0d83df0f3  vmovaps [rsp+0x60], xmm7
000071c0d83df0f9  vmovaps [rsp+0x70], xmm8
000071c0d83df0ff  vmovaps [rsp+0x80], xmm9
000071c0d83df108  vmovaps [rsp+0x90], xmm10
000071c0d83df111  vmovaps [rsp+0xA0], xmm11
000071c0d83df11a  vmovaps [rsp+0xB0], xmm12
000071c0d83df123  vmovaps [rsp+0xC0], xmm13
000071c0d83df12c  vmovaps [rsp+0xD0], xmm14
000071c0d83df135  vmovaps [rsp+0xE0], xmm15
000071c0d83df13e  sub rsp, 0x30
000071c0d83df142  movaps [rsp], xmm1
000071c0d83df146  movaps [rsp+0x10], xmm15
000071c0d83df14c  movaps [rsp+0x20], xmm6
000071c0d83df151  lea rdi, [rsp]
000071c0d83df155  mov esi, 0x00
000071c0d83df15a  mov rax, 0x5904ED15D530
000071c0d83df164  call rax
000071c0d83df166  movaps xmm1, [rsp]
000071c0d83df16a  add rsp, 0x30
000071c0d83df16e  vmovaps xmm0, [rsp]
000071c0d83df173  vmovaps xmm2, [rsp+0x10]
000071c0d83df179  vmovaps xmm3, [rsp+0x20]
000071c0d83df17f  vmovaps xmm4, [rsp+0x30]
000071c0d83df185  vmovaps xmm5, [rsp+0x40]
000071c0d83df18b  vmovaps xmm6, [rsp+0x50]
000071c0d83df191  vmovaps xmm7, [rsp+0x60]
000071c0d83df197  vmovaps xmm8, [rsp+0x70]
000071c0d83df19d  vmovaps xmm9, [rsp+0x80]
000071c0d83df1a6  vmovaps xmm10, [rsp+0x90]
000071c0d83df1af  vmovaps xmm11, [rsp+0xA0]
000071c0d83df1b8  vmovaps xmm12, [rsp+0xB0]
000071c0d83df1c1  vmovaps xmm13, [rsp+0xC0]
000071c0d83df1ca  vmovaps xmm14, [rsp+0xD0]
000071c0d83df1d3  vmovaps xmm15, [rsp+0xE0]
000071c0d83df1dc  add rsp, 0xF0
000071c0d83df1e3  pop r11
000071c0d83df1e5  pop r10
000071c0d83df1e7  pop r9
000071c0d83df1e9  pop r8
000071c0d83df1eb  pop rsi
000071c0d83df1ec  pop rdi
000071c0d83df1ed  pop rdx
000071c0d83df1ee  pop rcx
000071c0d83df1ef  pop rax
000071c0d83df1f0  add rsp, 0x08
000071c0d83df1f4  jmp 0x000071C0D83DC375
000071c0d83df1f9  sub rsp, 0x08
000071c0d83df1fd  push rax
000071c0d83df1fe  push rcx
000071c0d83df1ff  push rdx
000071c0d83df200  push rdi
000071c0d83df201  push rsi
000071c0d83df202  push r8
000071c0d83df204  push r9
000071c0d83df206  push r10
000071c0d83df208  push r11
000071c0d83df20a  sub rsp, 0xF0
000071c0d83df211  vmovaps [rsp], xmm0
000071c0d83df216  vmovaps [rsp+0x10], xmm1
000071c0d83df21c  vmovaps [rsp+0x20], xmm2
000071c0d83df222  vmovaps [rsp+0x30], xmm3
000071c0d83df228  vmovaps [rsp+0x40], xmm4
000071c0d83df22e  vmovaps [rsp+0x50], xmm5
000071c0d83df234  vmovaps [rsp+0x60], xmm6
000071c0d83df23a  vmovaps [rsp+0x70], xmm7
000071c0d83df240  vmovaps [rsp+0x80], xmm8
000071c0d83df249  vmovaps [rsp+0x90], xmm9
000071c0d83df252  vmovaps [rsp+0xA0], xmm10
000071c0d83df25b  vmovaps [rsp+0xB0], xmm11
000071c0d83df264  vmovaps [rsp+0xC0], xmm12
000071c0d83df26d  vmovaps [rsp+0xD0], xmm13
000071c0d83df276  vmovaps [rsp+0xE0], xmm14
000071c0d83df27f  sub rsp, 0x30
000071c0d83df283  movaps [rsp], xmm15
000071c0d83df288  movaps [rsp+0x10], xmm5
000071c0d83df28d  movaps [rsp+0x20], xmm3
000071c0d83df292  lea rdi, [rsp]
000071c0d83df296  mov esi, 0x00
000071c0d83df29b  mov rax, 0x5904ED15D530
000071c0d83df2a5  call rax
000071c0d83df2a7  movaps xmm15, [rsp]
000071c0d83df2ac  add rsp, 0x30
000071c0d83df2b0  vmovaps xmm0, [rsp]
000071c0d83df2b5  vmovaps xmm1, [rsp+0x10]
000071c0d83df2bb  vmovaps xmm2, [rsp+0x20]
000071c0d83df2c1  vmovaps xmm3, [rsp+0x30]
000071c0d83df2c7  vmovaps xmm4, [rsp+0x40]
000071c0d83df2cd  vmovaps xmm5, [rsp+0x50]
000071c0d83df2d3  vmovaps xmm6, [rsp+0x60]
000071c0d83df2d9  vmovaps xmm7, [rsp+0x70]
000071c0d83df2df  vmovaps xmm8, [rsp+0x80]
000071c0d83df2e8  vmovaps xmm9, [rsp+0x90]
000071c0d83df2f1  vmovaps xmm10, [rsp+0xA0]
000071c0d83df2fa  vmovaps xmm11, [rsp+0xB0]
000071c0d83df303  vmovaps xmm12, [rsp+0xC0]
000071c0d83df30c  vmovaps xmm13, [rsp+0xD0]
000071c0d83df315  vmovaps xmm14, [rsp+0xE0]
000071c0d83df31e  add rsp, 0xF0
000071c0d83df325  pop r11
000071c0d83df327  pop r10
000071c0d83df329  pop r9
000071c0d83df32b  pop r8
000071c0d83df32d  pop rsi
000071c0d83df32e  pop rdi
000071c0d83df32f  pop rdx
000071c0d83df330  pop rcx
000071c0d83df331  pop rax
000071c0d83df332  add rsp, 0x08
000071c0d83df336  jmp 0x000071C0D83DC38F
000071c0d83df33b  sub rsp, 0x08
000071c0d83df33f  push rax
000071c0d83df340  push rcx
000071c0d83df341  push rdx
000071c0d83df342  push rdi
000071c0d83df343  push rsi
000071c0d83df344  push r8
000071c0d83df346  push r9
000071c0d83df348  push r10
000071c0d83df34a  push r11
000071c0d83df34c  sub rsp, 0xF0
000071c0d83df353  vmovaps [rsp], xmm0
000071c0d83df358  vmovaps [rsp+0x10], xmm1
000071c0d83df35e  vmovaps [rsp+0x20], xmm2
000071c0d83df364  vmovaps [rsp+0x30], xmm3
000071c0d83df36a  vmovaps [rsp+0x40], xmm4
000071c0d83df370  vmovaps [rsp+0x50], xmm6
000071c0d83df376  vmovaps [rsp+0x60], xmm7
000071c0d83df37c  vmovaps [rsp+0x70], xmm8
000071c0d83df382  vmovaps [rsp+0x80], xmm9
000071c0d83df38b  vmovaps [rsp+0x90], xmm10
000071c0d83df394  vmovaps [rsp+0xA0], xmm11
000071c0d83df39d  vmovaps [rsp+0xB0], xmm12
000071c0d83df3a6  vmovaps [rsp+0xC0], xmm13
000071c0d83df3af  vmovaps [rsp+0xD0], xmm14
000071c0d83df3b8  vmovaps [rsp+0xE0], xmm15
000071c0d83df3c1  sub rsp, 0x30
000071c0d83df3c5  movaps [rsp], xmm5
000071c0d83df3c9  movaps [rsp+0x10], xmm8
000071c0d83df3cf  movaps [rsp+0x20], xmm6
000071c0d83df3d4  lea rdi, [rsp]
000071c0d83df3d8  mov esi, 0x00
000071c0d83df3dd  mov rax, 0x5904ED15D530
000071c0d83df3e7  call rax
000071c0d83df3e9  movaps xmm5, [rsp]
000071c0d83df3ed  add rsp, 0x30
000071c0d83df3f1  vmovaps xmm0, [rsp]
000071c0d83df3f6  vmovaps xmm1, [rsp+0x10]
000071c0d83df3fc  vmovaps xmm2, [rsp+0x20]
000071c0d83df402  vmovaps xmm3, [rsp+0x30]
000071c0d83df408  vmovaps xmm4, [rsp+0x40]
000071c0d83df40e  vmovaps xmm6, [rsp+0x50]
000071c0d83df414  vmovaps xmm7, [rsp+0x60]
000071c0d83df41a  vmovaps xmm8, [rsp+0x70]
000071c0d83df420  vmovaps xmm9, [rsp+0x80]
000071c0d83df429  vmovaps xmm10, [rsp+0x90]
000071c0d83df432  vmovaps xmm11, [rsp+0xA0]
000071c0d83df43b  vmovaps xmm12, [rsp+0xB0]
000071c0d83df444  vmovaps xmm13, [rsp+0xC0]
000071c0d83df44d  vmovaps xmm14, [rsp+0xD0]
000071c0d83df456  vmovaps xmm15, [rsp+0xE0]
000071c0d83df45f  add rsp, 0xF0
000071c0d83df466  pop r11
000071c0d83df468  pop r10
000071c0d83df46a  pop r9
000071c0d83df46c  pop r8
000071c0d83df46e  pop rsi
000071c0d83df46f  pop rdi
000071c0d83df470  pop rdx
000071c0d83df471  pop rcx
000071c0d83df472  pop rax
000071c0d83df473  add rsp, 0x08
000071c0d83df477  jmp 0x000071C0D83DC3B3
000071c0d83df47c  sub rsp, 0x08
000071c0d83df480  push rax
000071c0d83df481  push rcx
000071c0d83df482  push rdx
000071c0d83df483  push rdi
000071c0d83df484  push rsi
000071c0d83df485  push r8
000071c0d83df487  push r9
000071c0d83df489  push r10
000071c0d83df48b  push r11
000071c0d83df48d  sub rsp, 0xF0
000071c0d83df494  vmovaps [rsp], xmm0
000071c0d83df499  vmovaps [rsp+0x10], xmm1
000071c0d83df49f  vmovaps [rsp+0x20], xmm2
000071c0d83df4a5  vmovaps [rsp+0x30], xmm3
000071c0d83df4ab  vmovaps [rsp+0x40], xmm4
000071c0d83df4b1  vmovaps [rsp+0x50], xmm5
000071c0d83df4b7  vmovaps [rsp+0x60], xmm7
000071c0d83df4bd  vmovaps [rsp+0x70], xmm8
000071c0d83df4c3  vmovaps [rsp+0x80], xmm9
000071c0d83df4cc  vmovaps [rsp+0x90], xmm10
000071c0d83df4d5  vmovaps [rsp+0xA0], xmm11
000071c0d83df4de  vmovaps [rsp+0xB0], xmm12
000071c0d83df4e7  vmovaps [rsp+0xC0], xmm13
000071c0d83df4f0  vmovaps [rsp+0xD0], xmm14
000071c0d83df4f9  vmovaps [rsp+0xE0], xmm15
000071c0d83df502  sub rsp, 0x30
000071c0d83df506  movaps [rsp], xmm6
000071c0d83df50a  movaps [rsp+0x10], xmm10
000071c0d83df510  movaps [rsp+0x20], xmm8
000071c0d83df516  lea rdi, [rsp]
000071c0d83df51a  mov esi, 0x00
000071c0d83df51f  mov rax, 0x5904ED15D530
000071c0d83df529  call rax
000071c0d83df52b  movaps xmm6, [rsp]
000071c0d83df52f  add rsp, 0x30
000071c0d83df533  vmovaps xmm0, [rsp]
000071c0d83df538  vmovaps xmm1, [rsp+0x10]
000071c0d83df53e  vmovaps xmm2, [rsp+0x20]
000071c0d83df544  vmovaps xmm3, [rsp+0x30]
000071c0d83df54a  vmovaps xmm4, [rsp+0x40]
000071c0d83df550  vmovaps xmm5, [rsp+0x50]
000071c0d83df556  vmovaps xmm7, [rsp+0x60]
000071c0d83df55c  vmovaps xmm8, [rsp+0x70]
000071c0d83df562  vmovaps xmm9, [rsp+0x80]
000071c0d83df56b  vmovaps xmm10, [rsp+0x90]
000071c0d83df574  vmovaps xmm11, [rsp+0xA0]
000071c0d83df57d  vmovaps xmm12, [rsp+0xB0]
000071c0d83df586  vmovaps xmm13, [rsp+0xC0]
000071c0d83df58f  vmovaps xmm14, [rsp+0xD0]
000071c0d83df598  vmovaps xmm15, [rsp+0xE0]
000071c0d83df5a1  add rsp, 0xF0
000071c0d83df5a8  pop r11
000071c0d83df5aa  pop r10
000071c0d83df5ac  pop r9
000071c0d83df5ae  pop r8
000071c0d83df5b0  pop rsi
000071c0d83df5b1  pop rdi
000071c0d83df5b2  pop rdx
000071c0d83df5b3  pop rcx
000071c0d83df5b4  pop rax
000071c0d83df5b5  add rsp, 0x08
000071c0d83df5b9  jmp 0x000071C0D83DC3D8
000071c0d83df5be  sub rsp, 0x08
000071c0d83df5c2  push rax
000071c0d83df5c3  push rcx
000071c0d83df5c4  push rdx
000071c0d83df5c5  push rdi
000071c0d83df5c6  push rsi
000071c0d83df5c7  push r8
000071c0d83df5c9  push r9
000071c0d83df5cb  push r10
000071c0d83df5cd  push r11
000071c0d83df5cf  sub rsp, 0xF0
000071c0d83df5d6  vmovaps [rsp], xmm0
000071c0d83df5db  vmovaps [rsp+0x10], xmm1
000071c0d83df5e1  vmovaps [rsp+0x20], xmm2
000071c0d83df5e7  vmovaps [rsp+0x30], xmm3
000071c0d83df5ed  vmovaps [rsp+0x40], xmm4
000071c0d83df5f3  vmovaps [rsp+0x50], xmm5
000071c0d83df5f9  vmovaps [rsp+0x60], xmm6
000071c0d83df5ff  vmovaps [rsp+0x70], xmm7
000071c0d83df605  vmovaps [rsp+0x80], xmm8
000071c0d83df60e  vmovaps [rsp+0x90], xmm9
000071c0d83df617  vmovaps [rsp+0xA0], xmm11
000071c0d83df620  vmovaps [rsp+0xB0], xmm12
000071c0d83df629  vmovaps [rsp+0xC0], xmm13
000071c0d83df632  vmovaps [rsp+0xD0], xmm14
000071c0d83df63b  vmovaps [rsp+0xE0], xmm15
000071c0d83df644  sub rsp, 0x30
000071c0d83df648  movaps [rsp], xmm10
000071c0d83df64d  movaps [rsp+0x10], xmm8
000071c0d83df653  movaps [rsp+0x20], xmm14
000071c0d83df659  lea rdi, [rsp]
000071c0d83df65d  mov esi, 0x00
000071c0d83df662  mov rax, 0x5904ED15D530
000071c0d83df66c  call rax
000071c0d83df66e  movaps xmm10, [rsp]
000071c0d83df673  add rsp, 0x30
000071c0d83df677  vmovaps xmm0, [rsp]
000071c0d83df67c  vmovaps xmm1, [rsp+0x10]
000071c0d83df682  vmovaps xmm2, [rsp+0x20]
000071c0d83df688  vmovaps xmm3, [rsp+0x30]
000071c0d83df68e  vmovaps xmm4, [rsp+0x40]
000071c0d83df694  vmovaps xmm5, [rsp+0x50]
000071c0d83df69a  vmovaps xmm6, [rsp+0x60]
000071c0d83df6a0  vmovaps xmm7, [rsp+0x70]
000071c0d83df6a6  vmovaps xmm8, [rsp+0x80]
000071c0d83df6af  vmovaps xmm9, [rsp+0x90]
000071c0d83df6b8  vmovaps xmm11, [rsp+0xA0]
000071c0d83df6c1  vmovaps xmm12, [rsp+0xB0]
000071c0d83df6ca  vmovaps xmm13, [rsp+0xC0]
000071c0d83df6d3  vmovaps xmm14, [rsp+0xD0]
000071c0d83df6dc  vmovaps xmm15, [rsp+0xE0]
000071c0d83df6e5  add rsp, 0xF0
000071c0d83df6ec  pop r11
000071c0d83df6ee  pop r10
000071c0d83df6f0  pop r9
000071c0d83df6f2  pop r8
000071c0d83df6f4  pop rsi
000071c0d83df6f5  pop rdi
000071c0d83df6f6  pop rdx
000071c0d83df6f7  pop rcx
000071c0d83df6f8  pop rax
000071c0d83df6f9  add rsp, 0x08
000071c0d83df6fd  jmp 0x000071C0D83DC3F8
000071c0d83df702  sub rsp, 0x08
000071c0d83df706  push rax
000071c0d83df707  push rcx
000071c0d83df708  push rdx
000071c0d83df709  push rdi
000071c0d83df70a  push rsi
000071c0d83df70b  push r8
000071c0d83df70d  push r9
000071c0d83df70f  push r10
000071c0d83df711  push r11
000071c0d83df713  sub rsp, 0xF0
000071c0d83df71a  vmovaps [rsp], xmm0
000071c0d83df71f  vmovaps [rsp+0x10], xmm1
000071c0d83df725  vmovaps [rsp+0x20], xmm2
000071c0d83df72b  vmovaps [rsp+0x30], xmm3
000071c0d83df731  vmovaps [rsp+0x40], xmm4
000071c0d83df737  vmovaps [rsp+0x50], xmm5
000071c0d83df73d  vmovaps [rsp+0x60], xmm6
000071c0d83df743  vmovaps [rsp+0x70], xmm7
000071c0d83df749  vmovaps [rsp+0x80], xmm8
000071c0d83df752  vmovaps [rsp+0x90], xmm9
000071c0d83df75b  vmovaps [rsp+0xA0], xmm10
000071c0d83df764  vmovaps [rsp+0xB0], xmm11
000071c0d83df76d  vmovaps [rsp+0xC0], xmm12
000071c0d83df776  vmovaps [rsp+0xD0], xmm13
000071c0d83df77f  vmovaps [rsp+0xE0], xmm15
000071c0d83df788  sub rsp, 0x30
000071c0d83df78c  movaps [rsp], xmm14
000071c0d83df791  movaps [rsp+0x10], xmm8
000071c0d83df797  movaps [rsp+0x20], xmm4
000071c0d83df79c  lea rdi, [rsp]
000071c0d83df7a0  mov esi, 0x00
000071c0d83df7a5  mov rax, 0x5904ED15D530
000071c0d83df7af  call rax
000071c0d83df7b1  movaps xmm14, [rsp]
000071c0d83df7b6  add rsp, 0x30
000071c0d83df7ba  vmovaps xmm0, [rsp]
000071c0d83df7bf  vmovaps xmm1, [rsp+0x10]
000071c0d83df7c5  vmovaps xmm2, [rsp+0x20]
000071c0d83df7cb  vmovaps xmm3, [rsp+0x30]
000071c0d83df7d1  vmovaps xmm4, [rsp+0x40]
000071c0d83df7d7  vmovaps xmm5, [rsp+0x50]
000071c0d83df7dd  vmovaps xmm6, [rsp+0x60]
000071c0d83df7e3  vmovaps xmm7, [rsp+0x70]
000071c0d83df7e9  vmovaps xmm8, [rsp+0x80]
000071c0d83df7f2  vmovaps xmm9, [rsp+0x90]
000071c0d83df7fb  vmovaps xmm10, [rsp+0xA0]
000071c0d83df804  vmovaps xmm11, [rsp+0xB0]
000071c0d83df80d  vmovaps xmm12, [rsp+0xC0]
000071c0d83df816  vmovaps xmm13, [rsp+0xD0]
000071c0d83df81f  vmovaps xmm15, [rsp+0xE0]
000071c0d83df828  add rsp, 0xF0
000071c0d83df82f  pop r11
000071c0d83df831  pop r10
000071c0d83df833  pop r9
000071c0d83df835  pop r8
000071c0d83df837  pop rsi
000071c0d83df838  pop rdi
000071c0d83df839  pop rdx
000071c0d83df83a  pop rcx
000071c0d83df83b  pop rax
000071c0d83df83c  add rsp, 0x08
000071c0d83df840  jmp 0x000071C0D83DC418
000071c0d83df845  sub rsp, 0x08
000071c0d83df849  push rax
000071c0d83df84a  push rcx
000071c0d83df84b  push rdx
000071c0d83df84c  push rdi
000071c0d83df84d  push rsi
000071c0d83df84e  push r8
000071c0d83df850  push r9
000071c0d83df852  push r10
000071c0d83df854  push r11
000071c0d83df856  sub rsp, 0xF0
000071c0d83df85d  vmovaps [rsp], xmm0
000071c0d83df862  vmovaps [rsp+0x10], xmm1
000071c0d83df868  vmovaps [rsp+0x20], xmm2
000071c0d83df86e  vmovaps [rsp+0x30], xmm3
000071c0d83df874  vmovaps [rsp+0x40], xmm5
000071c0d83df87a  vmovaps [rsp+0x50], xmm6
000071c0d83df880  vmovaps [rsp+0x60], xmm7
000071c0d83df886  vmovaps [rsp+0x70], xmm8
000071c0d83df88c  vmovaps [rsp+0x80], xmm9
000071c0d83df895  vmovaps [rsp+0x90], xmm10
000071c0d83df89e  vmovaps [rsp+0xA0], xmm11
000071c0d83df8a7  vmovaps [rsp+0xB0], xmm12
000071c0d83df8b0  vmovaps [rsp+0xC0], xmm13
000071c0d83df8b9  vmovaps [rsp+0xD0], xmm14
000071c0d83df8c2  vmovaps [rsp+0xE0], xmm15
000071c0d83df8cb  sub rsp, 0x30
000071c0d83df8cf  movaps [rsp], xmm4
000071c0d83df8d3  movaps [rsp+0x10], xmm13
000071c0d83df8d9  movaps [rsp+0x20], xmm8
000071c0d83df8df  lea rdi, [rsp]
000071c0d83df8e3  mov esi, 0x00
000071c0d83df8e8  mov rax, 0x5904ED15D530
000071c0d83df8f2  call rax
000071c0d83df8f4  movaps xmm4, [rsp]
000071c0d83df8f8  add rsp, 0x30
000071c0d83df8fc  vmovaps xmm0, [rsp]
000071c0d83df901  vmovaps xmm1, [rsp+0x10]
000071c0d83df907  vmovaps xmm2, [rsp+0x20]
000071c0d83df90d  vmovaps xmm3, [rsp+0x30]
000071c0d83df913  vmovaps xmm5, [rsp+0x40]
000071c0d83df919  vmovaps xmm6, [rsp+0x50]
000071c0d83df91f  vmovaps xmm7, [rsp+0x60]
000071c0d83df925  vmovaps xmm8, [rsp+0x70]
000071c0d83df92b  vmovaps xmm9, [rsp+0x80]
000071c0d83df934  vmovaps xmm10, [rsp+0x90]
000071c0d83df93d  vmovaps xmm11, [rsp+0xA0]
000071c0d83df946  vmovaps xmm12, [rsp+0xB0]
000071c0d83df94f  vmovaps xmm13, [rsp+0xC0]
000071c0d83df958  vmovaps xmm14, [rsp+0xD0]
000071c0d83df961  vmovaps xmm15, [rsp+0xE0]
000071c0d83df96a  add rsp, 0xF0
000071c0d83df971  pop r11
000071c0d83df973  pop r10
000071c0d83df975  pop r9
000071c0d83df977  pop r8
000071c0d83df979  pop rsi
000071c0d83df97a  pop rdi
000071c0d83df97b  pop rdx
000071c0d83df97c  pop rcx
000071c0d83df97d  pop rax
000071c0d83df97e  add rsp, 0x08
000071c0d83df982  jmp 0x000071C0D83DC43D
000071c0d83df987  sub rsp, 0x08
000071c0d83df98b  push rax
000071c0d83df98c  push rcx
000071c0d83df98d  push rdx
000071c0d83df98e  push rdi
000071c0d83df98f  push rsi
000071c0d83df990  push r8
000071c0d83df992  push r9
000071c0d83df994  push r10
000071c0d83df996  push r11
000071c0d83df998  sub rsp, 0xF0
000071c0d83df99f  vmovaps [rsp], xmm0
000071c0d83df9a4  vmovaps [rsp+0x10], xmm1
000071c0d83df9aa  vmovaps [rsp+0x20], xmm2
000071c0d83df9b0  vmovaps [rsp+0x30], xmm3
000071c0d83df9b6  vmovaps [rsp+0x40], xmm4
000071c0d83df9bc  vmovaps [rsp+0x50], xmm5
000071c0d83df9c2  vmovaps [rsp+0x60], xmm6
000071c0d83df9c8  vmovaps [rsp+0x70], xmm7
000071c0d83df9ce  vmovaps [rsp+0x80], xmm8
000071c0d83df9d7  vmovaps [rsp+0x90], xmm9
000071c0d83df9e0  vmovaps [rsp+0xA0], xmm10
000071c0d83df9e9  vmovaps [rsp+0xB0], xmm11
000071c0d83df9f2  vmovaps [rsp+0xC0], xmm12
000071c0d83df9fb  vmovaps [rsp+0xD0], xmm14
000071c0d83dfa04  vmovaps [rsp+0xE0], xmm15
000071c0d83dfa0d  sub rsp, 0x30
000071c0d83dfa11  movaps [rsp], xmm13
000071c0d83dfa16  movaps [rsp+0x10], xmm15
000071c0d83dfa1c  movaps [rsp+0x20], xmm9
000071c0d83dfa22  lea rdi, [rsp]
000071c0d83dfa26  mov esi, 0x00
000071c0d83dfa2b  mov rax, 0x5904ED15D530
000071c0d83dfa35  call rax
000071c0d83dfa37  movaps xmm13, [rsp]
000071c0d83dfa3c  add rsp, 0x30
000071c0d83dfa40  vmovaps xmm0, [rsp]
000071c0d83dfa45  vmovaps xmm1, [rsp+0x10]
000071c0d83dfa4b  vmovaps xmm2, [rsp+0x20]
000071c0d83dfa51  vmovaps xmm3, [rsp+0x30]
000071c0d83dfa57  vmovaps xmm4, [rsp+0x40]
000071c0d83dfa5d  vmovaps xmm5, [rsp+0x50]
000071c0d83dfa63  vmovaps xmm6, [rsp+0x60]
000071c0d83dfa69  vmovaps xmm7, [rsp+0x70]
000071c0d83dfa6f  vmovaps xmm8, [rsp+0x80]
000071c0d83dfa78  vmovaps xmm9, [rsp+0x90]
000071c0d83dfa81  vmovaps xmm10, [rsp+0xA0]
000071c0d83dfa8a  vmovaps xmm11, [rsp+0xB0]
000071c0d83dfa93  vmovaps xmm12, [rsp+0xC0]
000071c0d83dfa9c  vmovaps xmm14, [rsp+0xD0]
000071c0d83dfaa5  vmovaps xmm15, [rsp+0xE0]
000071c0d83dfaae  add rsp, 0xF0
000071c0d83dfab5  pop r11
000071c0d83dfab7  pop r10
000071c0d83dfab9  pop r9
000071c0d83dfabb  pop r8
000071c0d83dfabd  pop rsi
000071c0d83dfabe  pop rdi
000071c0d83dfabf  pop rdx
000071c0d83dfac0  pop rcx
000071c0d83dfac1  pop rax
000071c0d83dfac2  add rsp, 0x08
000071c0d83dfac6  jmp 0x000071C0D83DC458
000071c0d83dfacb  sub rsp, 0x08
000071c0d83dfacf  push rax
000071c0d83dfad0  push rcx
000071c0d83dfad1  push rdx
000071c0d83dfad2  push rdi
000071c0d83dfad3  push rsi
000071c0d83dfad4  push r8
000071c0d83dfad6  push r9
000071c0d83dfad8  push r10
000071c0d83dfada  push r11
000071c0d83dfadc  sub rsp, 0xF0
000071c0d83dfae3  vmovaps [rsp], xmm0
000071c0d83dfae8  vmovaps [rsp+0x10], xmm1
000071c0d83dfaee  vmovaps [rsp+0x20], xmm2
000071c0d83dfaf4  vmovaps [rsp+0x30], xmm3
000071c0d83dfafa  vmovaps [rsp+0x40], xmm4
000071c0d83dfb00  vmovaps [rsp+0x50], xmm5
000071c0d83dfb06  vmovaps [rsp+0x60], xmm6
000071c0d83dfb0c  vmovaps [rsp+0x70], xmm7
000071c0d83dfb12  vmovaps [rsp+0x80], xmm8
000071c0d83dfb1b  vmovaps [rsp+0x90], xmm9
000071c0d83dfb24  vmovaps [rsp+0xA0], xmm10
000071c0d83dfb2d  vmovaps [rsp+0xB0], xmm11
000071c0d83dfb36  vmovaps [rsp+0xC0], xmm12
000071c0d83dfb3f  vmovaps [rsp+0xD0], xmm13
000071c0d83dfb48  vmovaps [rsp+0xE0], xmm14
000071c0d83dfb51  sub rsp, 0x30
000071c0d83dfb55  movaps [rsp], xmm15
000071c0d83dfb5a  movaps [rsp+0x10], xmm1
000071c0d83dfb5f  movaps [rsp+0x20], xmm5
000071c0d83dfb64  lea rdi, [rsp]
000071c0d83dfb68  mov esi, 0x00
000071c0d83dfb6d  mov rax, 0x5904ED15D530
000071c0d83dfb77  call rax
000071c0d83dfb79  movaps xmm15, [rsp]
000071c0d83dfb7e  add rsp, 0x30
000071c0d83dfb82  vmovaps xmm0, [rsp]
000071c0d83dfb87  vmovaps xmm1, [rsp+0x10]
000071c0d83dfb8d  vmovaps xmm2, [rsp+0x20]
000071c0d83dfb93  vmovaps xmm3, [rsp+0x30]
000071c0d83dfb99  vmovaps xmm4, [rsp+0x40]
000071c0d83dfb9f  vmovaps xmm5, [rsp+0x50]
000071c0d83dfba5  vmovaps xmm6, [rsp+0x60]
000071c0d83dfbab  vmovaps xmm7, [rsp+0x70]
000071c0d83dfbb1  vmovaps xmm8, [rsp+0x80]
000071c0d83dfbba  vmovaps xmm9, [rsp+0x90]
000071c0d83dfbc3  vmovaps xmm10, [rsp+0xA0]
000071c0d83dfbcc  vmovaps xmm11, [rsp+0xB0]
000071c0d83dfbd5  vmovaps xmm12, [rsp+0xC0]
000071c0d83dfbde  vmovaps xmm13, [rsp+0xD0]
000071c0d83dfbe7  vmovaps xmm14, [rsp+0xE0]
000071c0d83dfbf0  add rsp, 0xF0
000071c0d83dfbf7  pop r11
000071c0d83dfbf9  pop r10
000071c0d83dfbfb  pop r9
000071c0d83dfbfd  pop r8
000071c0d83dfbff  pop rsi
000071c0d83dfc00  pop rdi
000071c0d83dfc01  pop rdx
000071c0d83dfc02  pop rcx
000071c0d83dfc03  pop rax
000071c0d83dfc04  add rsp, 0x08
000071c0d83dfc08  jmp 0x000071C0D83DC473
000071c0d83dfc0d  call 0x000071C0D82B52F0
000071c0d83dfc12  jmp 0x000071C0D83DC4CE
000071c0d83dfc17  sub rsp, 0x08
000071c0d83dfc1b  push rax
000071c0d83dfc1c  push rcx
000071c0d83dfc1d  push rdx
000071c0d83dfc1e  push rdi
000071c0d83dfc1f  push rsi
000071c0d83dfc20  push r8
000071c0d83dfc22  push r9
000071c0d83dfc24  push r10
000071c0d83dfc26  push r11
000071c0d83dfc28  sub rsp, 0xF0
000071c0d83dfc2f  vmovaps [rsp], xmm0
000071c0d83dfc34  vmovaps [rsp+0x10], xmm1
000071c0d83dfc3a  vmovaps [rsp+0x20], xmm2
000071c0d83dfc40  vmovaps [rsp+0x30], xmm3
000071c0d83dfc46  vmovaps [rsp+0x40], xmm4
000071c0d83dfc4c  vmovaps [rsp+0x50], xmm5
000071c0d83dfc52  vmovaps [rsp+0x60], xmm6
000071c0d83dfc58  vmovaps [rsp+0x70], xmm7
000071c0d83dfc5e  vmovaps [rsp+0x80], xmm8
000071c0d83dfc67  vmovaps [rsp+0x90], xmm10
000071c0d83dfc70  vmovaps [rsp+0xA0], xmm11
000071c0d83dfc79  vmovaps [rsp+0xB0], xmm12
000071c0d83dfc82  vmovaps [rsp+0xC0], xmm13
000071c0d83dfc8b  vmovaps [rsp+0xD0], xmm14
000071c0d83dfc94  vmovaps [rsp+0xE0], xmm15
000071c0d83dfc9d  sub rsp, 0x30
000071c0d83dfca1  movaps [rsp], xmm9
000071c0d83dfca6  movaps [rsp+0x10], xmm8
000071c0d83dfcac  movaps [rsp+0x20], xmm11
000071c0d83dfcb2  lea rdi, [rsp]
000071c0d83dfcb6  mov esi, 0x00
000071c0d83dfcbb  mov rax, 0x5904ED15D530
000071c0d83dfcc5  call rax
000071c0d83dfcc7  movaps xmm9, [rsp]
000071c0d83dfccc  add rsp, 0x30
000071c0d83dfcd0  vmovaps xmm0, [rsp]
000071c0d83dfcd5  vmovaps xmm1, [rsp+0x10]
000071c0d83dfcdb  vmovaps xmm2, [rsp+0x20]
000071c0d83dfce1  vmovaps xmm3, [rsp+0x30]
000071c0d83dfce7  vmovaps xmm4, [rsp+0x40]
000071c0d83dfced  vmovaps xmm5, [rsp+0x50]
000071c0d83dfcf3  vmovaps xmm6, [rsp+0x60]
000071c0d83dfcf9  vmovaps xmm7, [rsp+0x70]
000071c0d83dfcff  vmovaps xmm8, [rsp+0x80]
000071c0d83dfd08  vmovaps xmm10, [rsp+0x90]
000071c0d83dfd11  vmovaps xmm11, [rsp+0xA0]
000071c0d83dfd1a  vmovaps xmm12, [rsp+0xB0]
000071c0d83dfd23  vmovaps xmm13, [rsp+0xC0]
000071c0d83dfd2c  vmovaps xmm14, [rsp+0xD0]
000071c0d83dfd35  vmovaps xmm15, [rsp+0xE0]
000071c0d83dfd3e  add rsp, 0xF0
000071c0d83dfd45  pop r11
000071c0d83dfd47  pop r10
000071c0d83dfd49  pop r9
000071c0d83dfd4b  pop r8
000071c0d83dfd4d  pop rsi
000071c0d83dfd4e  pop rdi
000071c0d83dfd4f  pop rdx
000071c0d83dfd50  pop rcx
000071c0d83dfd51  pop rax
000071c0d83dfd52  add rsp, 0x08
000071c0d83dfd56  jmp 0x000071C0D83DC505
000071c0d83dfd5b  sub rsp, 0x08
000071c0d83dfd5f  push rax
000071c0d83dfd60  push rcx
000071c0d83dfd61  push rdx
000071c0d83dfd62  push rdi
000071c0d83dfd63  push rsi
000071c0d83dfd64  push r8
000071c0d83dfd66  push r9
000071c0d83dfd68  push r10
000071c0d83dfd6a  push r11
000071c0d83dfd6c  sub rsp, 0xF0
000071c0d83dfd73  vmovaps [rsp], xmm0
000071c0d83dfd78  vmovaps [rsp+0x10], xmm1
000071c0d83dfd7e  vmovaps [rsp+0x20], xmm2
000071c0d83dfd84  vmovaps [rsp+0x30], xmm3
000071c0d83dfd8a  vmovaps [rsp+0x40], xmm4
000071c0d83dfd90  vmovaps [rsp+0x50], xmm5
000071c0d83dfd96  vmovaps [rsp+0x60], xmm6
000071c0d83dfd9c  vmovaps [rsp+0x70], xmm7
000071c0d83dfda2  vmovaps [rsp+0x80], xmm8
000071c0d83dfdab  vmovaps [rsp+0x90], xmm9
000071c0d83dfdb4  vmovaps [rsp+0xA0], xmm10
000071c0d83dfdbd  vmovaps [rsp+0xB0], xmm12
000071c0d83dfdc6  vmovaps [rsp+0xC0], xmm13
000071c0d83dfdcf  vmovaps [rsp+0xD0], xmm14
000071c0d83dfdd8  vmovaps [rsp+0xE0], xmm15
000071c0d83dfde1  sub rsp, 0x30
000071c0d83dfde5  movaps [rsp], xmm11
000071c0d83dfdea  movaps [rsp+0x10], xmm10
000071c0d83dfdf0  movaps [rsp+0x20], xmm6
000071c0d83dfdf5  lea rdi, [rsp]
000071c0d83dfdf9  mov esi, 0x00
000071c0d83dfdfe  mov rax, 0x5904ED15D530
000071c0d83dfe08  call rax
000071c0d83dfe0a  movaps xmm11, [rsp]
000071c0d83dfe0f  add rsp, 0x30
000071c0d83dfe13  vmovaps xmm0, [rsp]
000071c0d83dfe18  vmovaps xmm1, [rsp+0x10]
000071c0d83dfe1e  vmovaps xmm2, [rsp+0x20]
000071c0d83dfe24  vmovaps xmm3, [rsp+0x30]
000071c0d83dfe2a  vmovaps xmm4, [rsp+0x40]
000071c0d83dfe30  vmovaps xmm5, [rsp+0x50]
000071c0d83dfe36  vmovaps xmm6, [rsp+0x60]
000071c0d83dfe3c  vmovaps xmm7, [rsp+0x70]
000071c0d83dfe42  vmovaps xmm8, [rsp+0x80]
000071c0d83dfe4b  vmovaps xmm9, [rsp+0x90]
000071c0d83dfe54  vmovaps xmm10, [rsp+0xA0]
000071c0d83dfe5d  vmovaps xmm12, [rsp+0xB0]
000071c0d83dfe66  vmovaps xmm13, [rsp+0xC0]
000071c0d83dfe6f  vmovaps xmm14, [rsp+0xD0]
000071c0d83dfe78  vmovaps xmm15, [rsp+0xE0]
000071c0d83dfe81  add rsp, 0xF0
000071c0d83dfe88  pop r11
000071c0d83dfe8a  pop r10
000071c0d83dfe8c  pop r9
000071c0d83dfe8e  pop r8
000071c0d83dfe90  pop rsi
000071c0d83dfe91  pop rdi
000071c0d83dfe92  pop rdx
000071c0d83dfe93  pop rcx
000071c0d83dfe94  pop rax
000071c0d83dfe95  add rsp, 0x08
000071c0d83dfe99  jmp 0x000071C0D83DC520
000071c0d83dfe9e  sub rsp, 0x08
000071c0d83dfea2  push rax
000071c0d83dfea3  push rcx
000071c0d83dfea4  push rdx
000071c0d83dfea5  push rdi
000071c0d83dfea6  push rsi
000071c0d83dfea7  push r8
000071c0d83dfea9  push r9
000071c0d83dfeab  push r10
000071c0d83dfead  push r11
000071c0d83dfeaf  sub rsp, 0xF0
000071c0d83dfeb6  vmovaps [rsp], xmm0
000071c0d83dfebb  vmovaps [rsp+0x10], xmm1
000071c0d83dfec1  vmovaps [rsp+0x20], xmm2
000071c0d83dfec7  vmovaps [rsp+0x30], xmm3
000071c0d83dfecd  vmovaps [rsp+0x40], xmm4
000071c0d83dfed3  vmovaps [rsp+0x50], xmm5
000071c0d83dfed9  vmovaps [rsp+0x60], xmm6
000071c0d83dfedf  vmovaps [rsp+0x70], xmm7
000071c0d83dfee5  vmovaps [rsp+0x80], xmm8
000071c0d83dfeee  vmovaps [rsp+0x90], xmm9
000071c0d83dfef7  vmovaps [rsp+0xA0], xmm11
000071c0d83dff00  vmovaps [rsp+0xB0], xmm12
000071c0d83dff09  vmovaps [rsp+0xC0], xmm13
000071c0d83dff12  vmovaps [rsp+0xD0], xmm14
000071c0d83dff1b  vmovaps [rsp+0xE0], xmm15
000071c0d83dff24  sub rsp, 0x30
000071c0d83dff28  movaps [rsp], xmm10
000071c0d83dff2d  movaps [rsp+0x10], xmm14
000071c0d83dff33  movaps [rsp+0x20], xmm4
000071c0d83dff38  lea rdi, [rsp]
000071c0d83dff3c  mov esi, 0x00
000071c0d83dff41  mov rax, 0x5904ED15D530
000071c0d83dff4b  call rax
000071c0d83dff4d  movaps xmm10, [rsp]
000071c0d83dff52  add rsp, 0x30
000071c0d83dff56  vmovaps xmm0, [rsp]
000071c0d83dff5b  vmovaps xmm1, [rsp+0x10]
000071c0d83dff61  vmovaps xmm2, [rsp+0x20]
000071c0d83dff67  vmovaps xmm3, [rsp+0x30]
000071c0d83dff6d  vmovaps xmm4, [rsp+0x40]
000071c0d83dff73  vmovaps xmm5, [rsp+0x50]
000071c0d83dff79  vmovaps xmm6, [rsp+0x60]
000071c0d83dff7f  vmovaps xmm7, [rsp+0x70]
000071c0d83dff85  vmovaps xmm8, [rsp+0x80]
000071c0d83dff8e  vmovaps xmm9, [rsp+0x90]
000071c0d83dff97  vmovaps xmm11, [rsp+0xA0]
000071c0d83dffa0  vmovaps xmm12, [rsp+0xB0]
000071c0d83dffa9  vmovaps xmm13, [rsp+0xC0]
000071c0d83dffb2  vmovaps xmm14, [rsp+0xD0]
000071c0d83dffbb  vmovaps xmm15, [rsp+0xE0]
000071c0d83dffc4  add rsp, 0xF0
000071c0d83dffcb  pop r11
000071c0d83dffcd  pop r10
000071c0d83dffcf  pop r9
000071c0d83dffd1  pop r8
000071c0d83dffd3  pop rsi
000071c0d83dffd4  pop rdi
000071c0d83dffd5  pop rdx
000071c0d83dffd6  pop rcx
000071c0d83dffd7  pop rax
000071c0d83dffd8  add rsp, 0x08
000071c0d83dffdc  jmp 0x000071C0D83DC53B
000071c0d83dffe1  sub rsp, 0x08
000071c0d83dffe5  push rax
000071c0d83dffe6  push rcx
000071c0d83dffe7  push rdx
000071c0d83dffe8  push rdi
000071c0d83dffe9  push rsi
000071c0d83dffea  push r8
000071c0d83dffec  push r9
000071c0d83dffee  push r10
000071c0d83dfff0  push r11
000071c0d83dfff2  sub rsp, 0xF0
000071c0d83dfff9  vmovaps [rsp], xmm0
000071c0d83dfffe  vmovaps [rsp+0x10], xmm1
000071c0d83e0004  vmovaps [rsp+0x20], xmm2
000071c0d83e000a  vmovaps [rsp+0x30], xmm3
000071c0d83e0010  vmovaps [rsp+0x40], xmm4
000071c0d83e0016  vmovaps [rsp+0x50], xmm5
000071c0d83e001c  vmovaps [rsp+0x60], xmm6
000071c0d83e0022  vmovaps [rsp+0x70], xmm7
000071c0d83e0028  vmovaps [rsp+0x80], xmm9
000071c0d83e0031  vmovaps [rsp+0x90], xmm10
000071c0d83e003a  vmovaps [rsp+0xA0], xmm11
000071c0d83e0043  vmovaps [rsp+0xB0], xmm12
000071c0d83e004c  vmovaps [rsp+0xC0], xmm13
000071c0d83e0055  vmovaps [rsp+0xD0], xmm14
000071c0d83e005e  vmovaps [rsp+0xE0], xmm15
000071c0d83e0067  sub rsp, 0x30
000071c0d83e006b  movaps [rsp], xmm8
000071c0d83e0070  movaps [rsp+0x10], xmm1
000071c0d83e0075  movaps [rsp+0x20], xmm14
000071c0d83e007b  lea rdi, [rsp]
000071c0d83e007f  mov esi, 0x00
000071c0d83e0084  mov rax, 0x5904ED15D530
000071c0d83e008e  call rax
000071c0d83e0090  movaps xmm8, [rsp]
000071c0d83e0095  add rsp, 0x30
000071c0d83e0099  vmovaps xmm0, [rsp]
000071c0d83e009e  vmovaps xmm1, [rsp+0x10]
000071c0d83e00a4  vmovaps xmm2, [rsp+0x20]
000071c0d83e00aa  vmovaps xmm3, [rsp+0x30]
000071c0d83e00b0  vmovaps xmm4, [rsp+0x40]
000071c0d83e00b6  vmovaps xmm5, [rsp+0x50]
000071c0d83e00bc  vmovaps xmm6, [rsp+0x60]
000071c0d83e00c2  vmovaps xmm7, [rsp+0x70]
000071c0d83e00c8  vmovaps xmm9, [rsp+0x80]
000071c0d83e00d1  vmovaps xmm10, [rsp+0x90]
000071c0d83e00da  vmovaps xmm11, [rsp+0xA0]
000071c0d83e00e3  vmovaps xmm12, [rsp+0xB0]
000071c0d83e00ec  vmovaps xmm13, [rsp+0xC0]
000071c0d83e00f5  vmovaps xmm14, [rsp+0xD0]
000071c0d83e00fe  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0107  add rsp, 0xF0
000071c0d83e010e  pop r11
000071c0d83e0110  pop r10
000071c0d83e0112  pop r9
000071c0d83e0114  pop r8
000071c0d83e0116  pop rsi
000071c0d83e0117  pop rdi
000071c0d83e0118  pop rdx
000071c0d83e0119  pop rcx
000071c0d83e011a  pop rax
000071c0d83e011b  add rsp, 0x08
000071c0d83e011f  jmp 0x000071C0D83DC561
000071c0d83e0124  sub rsp, 0x08
000071c0d83e0128  push rax
000071c0d83e0129  push rcx
000071c0d83e012a  push rdx
000071c0d83e012b  push rdi
000071c0d83e012c  push rsi
000071c0d83e012d  push r8
000071c0d83e012f  push r9
000071c0d83e0131  push r10
000071c0d83e0133  push r11
000071c0d83e0135  sub rsp, 0xF0
000071c0d83e013c  vmovaps [rsp], xmm0
000071c0d83e0141  vmovaps [rsp+0x10], xmm1
000071c0d83e0147  vmovaps [rsp+0x20], xmm2
000071c0d83e014d  vmovaps [rsp+0x30], xmm3
000071c0d83e0153  vmovaps [rsp+0x40], xmm4
000071c0d83e0159  vmovaps [rsp+0x50], xmm5
000071c0d83e015f  vmovaps [rsp+0x60], xmm7
000071c0d83e0165  vmovaps [rsp+0x70], xmm8
000071c0d83e016b  vmovaps [rsp+0x80], xmm9
000071c0d83e0174  vmovaps [rsp+0x90], xmm10
000071c0d83e017d  vmovaps [rsp+0xA0], xmm11
000071c0d83e0186  vmovaps [rsp+0xB0], xmm12
000071c0d83e018f  vmovaps [rsp+0xC0], xmm13
000071c0d83e0198  vmovaps [rsp+0xD0], xmm14
000071c0d83e01a1  vmovaps [rsp+0xE0], xmm15
000071c0d83e01aa  sub rsp, 0x30
000071c0d83e01ae  movaps [rsp], xmm6
000071c0d83e01b2  movaps [rsp+0x10], xmm1
000071c0d83e01b7  movaps [rsp+0x20], xmm14
000071c0d83e01bd  lea rdi, [rsp]
000071c0d83e01c1  mov esi, 0x00
000071c0d83e01c6  mov rax, 0x5904ED15D530
000071c0d83e01d0  call rax
000071c0d83e01d2  movaps xmm6, [rsp]
000071c0d83e01d6  add rsp, 0x30
000071c0d83e01da  vmovaps xmm0, [rsp]
000071c0d83e01df  vmovaps xmm1, [rsp+0x10]
000071c0d83e01e5  vmovaps xmm2, [rsp+0x20]
000071c0d83e01eb  vmovaps xmm3, [rsp+0x30]
000071c0d83e01f1  vmovaps xmm4, [rsp+0x40]
000071c0d83e01f7  vmovaps xmm5, [rsp+0x50]
000071c0d83e01fd  vmovaps xmm7, [rsp+0x60]
000071c0d83e0203  vmovaps xmm8, [rsp+0x70]
000071c0d83e0209  vmovaps xmm9, [rsp+0x80]
000071c0d83e0212  vmovaps xmm10, [rsp+0x90]
000071c0d83e021b  vmovaps xmm11, [rsp+0xA0]
000071c0d83e0224  vmovaps xmm12, [rsp+0xB0]
000071c0d83e022d  vmovaps xmm13, [rsp+0xC0]
000071c0d83e0236  vmovaps xmm14, [rsp+0xD0]
000071c0d83e023f  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0248  add rsp, 0xF0
000071c0d83e024f  pop r11
000071c0d83e0251  pop r10
000071c0d83e0253  pop r9
000071c0d83e0255  pop r8
000071c0d83e0257  pop rsi
000071c0d83e0258  pop rdi
000071c0d83e0259  pop rdx
000071c0d83e025a  pop rcx
000071c0d83e025b  pop rax
000071c0d83e025c  add rsp, 0x08
000071c0d83e0260  jmp 0x000071C0D83DC58D
000071c0d83e0265  sub rsp, 0x08
000071c0d83e0269  push rax
000071c0d83e026a  push rcx
000071c0d83e026b  push rdx
000071c0d83e026c  push rdi
000071c0d83e026d  push rsi
000071c0d83e026e  push r8
000071c0d83e0270  push r9
000071c0d83e0272  push r10
000071c0d83e0274  push r11
000071c0d83e0276  sub rsp, 0xF0
000071c0d83e027d  vmovaps [rsp], xmm0
000071c0d83e0282  vmovaps [rsp+0x10], xmm1
000071c0d83e0288  vmovaps [rsp+0x20], xmm2
000071c0d83e028e  vmovaps [rsp+0x30], xmm3
000071c0d83e0294  vmovaps [rsp+0x40], xmm4
000071c0d83e029a  vmovaps [rsp+0x50], xmm5
000071c0d83e02a0  vmovaps [rsp+0x60], xmm6
000071c0d83e02a6  vmovaps [rsp+0x70], xmm7
000071c0d83e02ac  vmovaps [rsp+0x80], xmm8
000071c0d83e02b5  vmovaps [rsp+0x90], xmm9
000071c0d83e02be  vmovaps [rsp+0xA0], xmm10
000071c0d83e02c7  vmovaps [rsp+0xB0], xmm11
000071c0d83e02d0  vmovaps [rsp+0xC0], xmm12
000071c0d83e02d9  vmovaps [rsp+0xD0], xmm13
000071c0d83e02e2  vmovaps [rsp+0xE0], xmm15
000071c0d83e02eb  sub rsp, 0x30
000071c0d83e02ef  movaps [rsp], xmm14
000071c0d83e02f4  movaps [rsp+0x10], xmm12
000071c0d83e02fa  movaps [rsp+0x20], xmm1
000071c0d83e02ff  lea rdi, [rsp]
000071c0d83e0303  mov esi, 0x00
000071c0d83e0308  mov rax, 0x5904ED15D530
000071c0d83e0312  call rax
000071c0d83e0314  movaps xmm14, [rsp]
000071c0d83e0319  add rsp, 0x30
000071c0d83e031d  vmovaps xmm0, [rsp]
000071c0d83e0322  vmovaps xmm1, [rsp+0x10]
000071c0d83e0328  vmovaps xmm2, [rsp+0x20]
000071c0d83e032e  vmovaps xmm3, [rsp+0x30]
000071c0d83e0334  vmovaps xmm4, [rsp+0x40]
000071c0d83e033a  vmovaps xmm5, [rsp+0x50]
000071c0d83e0340  vmovaps xmm6, [rsp+0x60]
000071c0d83e0346  vmovaps xmm7, [rsp+0x70]
000071c0d83e034c  vmovaps xmm8, [rsp+0x80]
000071c0d83e0355  vmovaps xmm9, [rsp+0x90]
000071c0d83e035e  vmovaps xmm10, [rsp+0xA0]
000071c0d83e0367  vmovaps xmm11, [rsp+0xB0]
000071c0d83e0370  vmovaps xmm12, [rsp+0xC0]
000071c0d83e0379  vmovaps xmm13, [rsp+0xD0]
000071c0d83e0382  vmovaps xmm15, [rsp+0xE0]
000071c0d83e038b  add rsp, 0xF0
000071c0d83e0392  pop r11
000071c0d83e0394  pop r10
000071c0d83e0396  pop r9
000071c0d83e0398  pop r8
000071c0d83e039a  pop rsi
000071c0d83e039b  pop rdi
000071c0d83e039c  pop rdx
000071c0d83e039d  pop rcx
000071c0d83e039e  pop rax
000071c0d83e039f  add rsp, 0x08
000071c0d83e03a3  jmp 0x000071C0D83DC5B3
000071c0d83e03a8  sub rsp, 0x08
000071c0d83e03ac  push rax
000071c0d83e03ad  push rcx
000071c0d83e03ae  push rdx
000071c0d83e03af  push rdi
000071c0d83e03b0  push rsi
000071c0d83e03b1  push r8
000071c0d83e03b3  push r9
000071c0d83e03b5  push r10
000071c0d83e03b7  push r11
000071c0d83e03b9  sub rsp, 0xF0
000071c0d83e03c0  vmovaps [rsp], xmm0
000071c0d83e03c5  vmovaps [rsp+0x10], xmm2
000071c0d83e03cb  vmovaps [rsp+0x20], xmm3
000071c0d83e03d1  vmovaps [rsp+0x30], xmm4
000071c0d83e03d7  vmovaps [rsp+0x40], xmm5
000071c0d83e03dd  vmovaps [rsp+0x50], xmm6
000071c0d83e03e3  vmovaps [rsp+0x60], xmm7
000071c0d83e03e9  vmovaps [rsp+0x70], xmm8
000071c0d83e03ef  vmovaps [rsp+0x80], xmm9
000071c0d83e03f8  vmovaps [rsp+0x90], xmm10
000071c0d83e0401  vmovaps [rsp+0xA0], xmm11
000071c0d83e040a  vmovaps [rsp+0xB0], xmm12
000071c0d83e0413  vmovaps [rsp+0xC0], xmm13
000071c0d83e041c  vmovaps [rsp+0xD0], xmm14
000071c0d83e0425  vmovaps [rsp+0xE0], xmm15
000071c0d83e042e  sub rsp, 0x30
000071c0d83e0432  movaps [rsp], xmm1
000071c0d83e0436  movaps [rsp+0x10], xmm13
000071c0d83e043c  movaps [rsp+0x20], xmm9
000071c0d83e0442  lea rdi, [rsp]
000071c0d83e0446  mov esi, 0x00
000071c0d83e044b  mov rax, 0x5904ED15D530
000071c0d83e0455  call rax
000071c0d83e0457  movaps xmm1, [rsp]
000071c0d83e045b  add rsp, 0x30
000071c0d83e045f  vmovaps xmm0, [rsp]
000071c0d83e0464  vmovaps xmm2, [rsp+0x10]
000071c0d83e046a  vmovaps xmm3, [rsp+0x20]
000071c0d83e0470  vmovaps xmm4, [rsp+0x30]
000071c0d83e0476  vmovaps xmm5, [rsp+0x40]
000071c0d83e047c  vmovaps xmm6, [rsp+0x50]
000071c0d83e0482  vmovaps xmm7, [rsp+0x60]
000071c0d83e0488  vmovaps xmm8, [rsp+0x70]
000071c0d83e048e  vmovaps xmm9, [rsp+0x80]
000071c0d83e0497  vmovaps xmm10, [rsp+0x90]
000071c0d83e04a0  vmovaps xmm11, [rsp+0xA0]
000071c0d83e04a9  vmovaps xmm12, [rsp+0xB0]
000071c0d83e04b2  vmovaps xmm13, [rsp+0xC0]
000071c0d83e04bb  vmovaps xmm14, [rsp+0xD0]
000071c0d83e04c4  vmovaps xmm15, [rsp+0xE0]
000071c0d83e04cd  add rsp, 0xF0
000071c0d83e04d4  pop r11
000071c0d83e04d6  pop r10
000071c0d83e04d8  pop r9
000071c0d83e04da  pop r8
000071c0d83e04dc  pop rsi
000071c0d83e04dd  pop rdi
000071c0d83e04de  pop rdx
000071c0d83e04df  pop rcx
000071c0d83e04e0  pop rax
000071c0d83e04e1  add rsp, 0x08
000071c0d83e04e5  jmp 0x000071C0D83DC5CD
000071c0d83e04ea  sub rsp, 0x08
000071c0d83e04ee  push rax
000071c0d83e04ef  push rcx
000071c0d83e04f0  push rdx
000071c0d83e04f1  push rdi
000071c0d83e04f2  push rsi
000071c0d83e04f3  push r8
000071c0d83e04f5  push r9
000071c0d83e04f7  push r10
000071c0d83e04f9  push r11
000071c0d83e04fb  sub rsp, 0xF0
000071c0d83e0502  vmovaps [rsp], xmm0
000071c0d83e0507  vmovaps [rsp+0x10], xmm1
000071c0d83e050d  vmovaps [rsp+0x20], xmm2
000071c0d83e0513  vmovaps [rsp+0x30], xmm3
000071c0d83e0519  vmovaps [rsp+0x40], xmm4
000071c0d83e051f  vmovaps [rsp+0x50], xmm5
000071c0d83e0525  vmovaps [rsp+0x60], xmm6
000071c0d83e052b  vmovaps [rsp+0x70], xmm7
000071c0d83e0531  vmovaps [rsp+0x80], xmm8
000071c0d83e053a  vmovaps [rsp+0x90], xmm9
000071c0d83e0543  vmovaps [rsp+0xA0], xmm10
000071c0d83e054c  vmovaps [rsp+0xB0], xmm11
000071c0d83e0555  vmovaps [rsp+0xC0], xmm13
000071c0d83e055e  vmovaps [rsp+0xD0], xmm14
000071c0d83e0567  vmovaps [rsp+0xE0], xmm15
000071c0d83e0570  sub rsp, 0x30
000071c0d83e0574  movaps [rsp], xmm12
000071c0d83e0579  movaps [rsp+0x10], xmm7
000071c0d83e057e  movaps [rsp+0x20], xmm13
000071c0d83e0584  lea rdi, [rsp]
000071c0d83e0588  mov esi, 0x00
000071c0d83e058d  mov rax, 0x5904ED15D530
000071c0d83e0597  call rax
000071c0d83e0599  movaps xmm12, [rsp]
000071c0d83e059e  add rsp, 0x30
000071c0d83e05a2  vmovaps xmm0, [rsp]
000071c0d83e05a7  vmovaps xmm1, [rsp+0x10]
000071c0d83e05ad  vmovaps xmm2, [rsp+0x20]
000071c0d83e05b3  vmovaps xmm3, [rsp+0x30]
000071c0d83e05b9  vmovaps xmm4, [rsp+0x40]
000071c0d83e05bf  vmovaps xmm5, [rsp+0x50]
000071c0d83e05c5  vmovaps xmm6, [rsp+0x60]
000071c0d83e05cb  vmovaps xmm7, [rsp+0x70]
000071c0d83e05d1  vmovaps xmm8, [rsp+0x80]
000071c0d83e05da  vmovaps xmm9, [rsp+0x90]
000071c0d83e05e3  vmovaps xmm10, [rsp+0xA0]
000071c0d83e05ec  vmovaps xmm11, [rsp+0xB0]
000071c0d83e05f5  vmovaps xmm13, [rsp+0xC0]
000071c0d83e05fe  vmovaps xmm14, [rsp+0xD0]
000071c0d83e0607  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0610  add rsp, 0xF0
000071c0d83e0617  pop r11
000071c0d83e0619  pop r10
000071c0d83e061b  pop r9
000071c0d83e061d  pop r8
000071c0d83e061f  pop rsi
000071c0d83e0620  pop rdi
000071c0d83e0621  pop rdx
000071c0d83e0622  pop rcx
000071c0d83e0623  pop rax
000071c0d83e0624  add rsp, 0x08
000071c0d83e0628  jmp 0x000071C0D83DC5F4
000071c0d83e062d  sub rsp, 0x08
000071c0d83e0631  push rax
000071c0d83e0632  push rcx
000071c0d83e0633  push rdx
000071c0d83e0634  push rdi
000071c0d83e0635  push rsi
000071c0d83e0636  push r8
000071c0d83e0638  push r9
000071c0d83e063a  push r10
000071c0d83e063c  push r11
000071c0d83e063e  sub rsp, 0xF0
000071c0d83e0645  vmovaps [rsp], xmm0
000071c0d83e064a  vmovaps [rsp+0x10], xmm1
000071c0d83e0650  vmovaps [rsp+0x20], xmm2
000071c0d83e0656  vmovaps [rsp+0x30], xmm3
000071c0d83e065c  vmovaps [rsp+0x40], xmm4
000071c0d83e0662  vmovaps [rsp+0x50], xmm5
000071c0d83e0668  vmovaps [rsp+0x60], xmm6
000071c0d83e066e  vmovaps [rsp+0x70], xmm7
000071c0d83e0674  vmovaps [rsp+0x80], xmm8
000071c0d83e067d  vmovaps [rsp+0x90], xmm9
000071c0d83e0686  vmovaps [rsp+0xA0], xmm10
000071c0d83e068f  vmovaps [rsp+0xB0], xmm11
000071c0d83e0698  vmovaps [rsp+0xC0], xmm12
000071c0d83e06a1  vmovaps [rsp+0xD0], xmm14
000071c0d83e06aa  vmovaps [rsp+0xE0], xmm15
000071c0d83e06b3  sub rsp, 0x30
000071c0d83e06b7  movaps [rsp], xmm13
000071c0d83e06bc  movaps [rsp+0x10], xmm15
000071c0d83e06c2  movaps [rsp+0x20], xmm8
000071c0d83e06c8  lea rdi, [rsp]
000071c0d83e06cc  mov esi, 0x00
000071c0d83e06d1  mov rax, 0x5904ED15D530
000071c0d83e06db  call rax
000071c0d83e06dd  movaps xmm13, [rsp]
000071c0d83e06e2  add rsp, 0x30
000071c0d83e06e6  vmovaps xmm0, [rsp]
000071c0d83e06eb  vmovaps xmm1, [rsp+0x10]
000071c0d83e06f1  vmovaps xmm2, [rsp+0x20]
000071c0d83e06f7  vmovaps xmm3, [rsp+0x30]
000071c0d83e06fd  vmovaps xmm4, [rsp+0x40]
000071c0d83e0703  vmovaps xmm5, [rsp+0x50]
000071c0d83e0709  vmovaps xmm6, [rsp+0x60]
000071c0d83e070f  vmovaps xmm7, [rsp+0x70]
000071c0d83e0715  vmovaps xmm8, [rsp+0x80]
000071c0d83e071e  vmovaps xmm9, [rsp+0x90]
000071c0d83e0727  vmovaps xmm10, [rsp+0xA0]
000071c0d83e0730  vmovaps xmm11, [rsp+0xB0]
000071c0d83e0739  vmovaps xmm12, [rsp+0xC0]
000071c0d83e0742  vmovaps xmm14, [rsp+0xD0]
000071c0d83e074b  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0754  add rsp, 0xF0
000071c0d83e075b  pop r11
000071c0d83e075d  pop r10
000071c0d83e075f  pop r9
000071c0d83e0761  pop r8
000071c0d83e0763  pop rsi
000071c0d83e0764  pop rdi
000071c0d83e0765  pop rdx
000071c0d83e0766  pop rcx
000071c0d83e0767  pop rax
000071c0d83e0768  add rsp, 0x08
000071c0d83e076c  jmp 0x000071C0D83DC60F
000071c0d83e0771  sub rsp, 0x08
000071c0d83e0775  push rax
000071c0d83e0776  push rcx
000071c0d83e0777  push rdx
000071c0d83e0778  push rdi
000071c0d83e0779  push rsi
000071c0d83e077a  push r8
000071c0d83e077c  push r9
000071c0d83e077e  push r10
000071c0d83e0780  push r11
000071c0d83e0782  sub rsp, 0xF0
000071c0d83e0789  vmovaps [rsp], xmm0
000071c0d83e078e  vmovaps [rsp+0x10], xmm1
000071c0d83e0794  vmovaps [rsp+0x20], xmm2
000071c0d83e079a  vmovaps [rsp+0x30], xmm3
000071c0d83e07a0  vmovaps [rsp+0x40], xmm4
000071c0d83e07a6  vmovaps [rsp+0x50], xmm5
000071c0d83e07ac  vmovaps [rsp+0x60], xmm6
000071c0d83e07b2  vmovaps [rsp+0x70], xmm7
000071c0d83e07b8  vmovaps [rsp+0x80], xmm9
000071c0d83e07c1  vmovaps [rsp+0x90], xmm10
000071c0d83e07ca  vmovaps [rsp+0xA0], xmm11
000071c0d83e07d3  vmovaps [rsp+0xB0], xmm12
000071c0d83e07dc  vmovaps [rsp+0xC0], xmm13
000071c0d83e07e5  vmovaps [rsp+0xD0], xmm14
000071c0d83e07ee  vmovaps [rsp+0xE0], xmm15
000071c0d83e07f7  sub rsp, 0x30
000071c0d83e07fb  movaps [rsp], xmm8
000071c0d83e0800  movaps [rsp+0x10], xmm15
000071c0d83e0806  movaps [rsp+0x20], xmm9
000071c0d83e080c  lea rdi, [rsp]
000071c0d83e0810  mov esi, 0x00
000071c0d83e0815  mov rax, 0x5904ED15D530
000071c0d83e081f  call rax
000071c0d83e0821  movaps xmm8, [rsp]
000071c0d83e0826  add rsp, 0x30
000071c0d83e082a  vmovaps xmm0, [rsp]
000071c0d83e082f  vmovaps xmm1, [rsp+0x10]
000071c0d83e0835  vmovaps xmm2, [rsp+0x20]
000071c0d83e083b  vmovaps xmm3, [rsp+0x30]
000071c0d83e0841  vmovaps xmm4, [rsp+0x40]
000071c0d83e0847  vmovaps xmm5, [rsp+0x50]
000071c0d83e084d  vmovaps xmm6, [rsp+0x60]
000071c0d83e0853  vmovaps xmm7, [rsp+0x70]
000071c0d83e0859  vmovaps xmm9, [rsp+0x80]
000071c0d83e0862  vmovaps xmm10, [rsp+0x90]
000071c0d83e086b  vmovaps xmm11, [rsp+0xA0]
000071c0d83e0874  vmovaps xmm12, [rsp+0xB0]
000071c0d83e087d  vmovaps xmm13, [rsp+0xC0]
000071c0d83e0886  vmovaps xmm14, [rsp+0xD0]
000071c0d83e088f  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0898  add rsp, 0xF0
000071c0d83e089f  pop r11
000071c0d83e08a1  pop r10
000071c0d83e08a3  pop r9
000071c0d83e08a5  pop r8
000071c0d83e08a7  pop rsi
000071c0d83e08a8  pop rdi
000071c0d83e08a9  pop rdx
000071c0d83e08aa  pop rcx
000071c0d83e08ab  pop rax
000071c0d83e08ac  add rsp, 0x08
000071c0d83e08b0  jmp 0x000071C0D83DC63D
000071c0d83e08b5  sub rsp, 0x08
000071c0d83e08b9  push rax
000071c0d83e08ba  push rcx
000071c0d83e08bb  push rdx
000071c0d83e08bc  push rdi
000071c0d83e08bd  push rsi
000071c0d83e08be  push r8
000071c0d83e08c0  push r9
000071c0d83e08c2  push r10
000071c0d83e08c4  push r11
000071c0d83e08c6  sub rsp, 0xF0
000071c0d83e08cd  vmovaps [rsp], xmm0
000071c0d83e08d2  vmovaps [rsp+0x10], xmm1
000071c0d83e08d8  vmovaps [rsp+0x20], xmm2
000071c0d83e08de  vmovaps [rsp+0x30], xmm3
000071c0d83e08e4  vmovaps [rsp+0x40], xmm4
000071c0d83e08ea  vmovaps [rsp+0x50], xmm5
000071c0d83e08f0  vmovaps [rsp+0x60], xmm6
000071c0d83e08f6  vmovaps [rsp+0x70], xmm7
000071c0d83e08fc  vmovaps [rsp+0x80], xmm8
000071c0d83e0905  vmovaps [rsp+0x90], xmm9
000071c0d83e090e  vmovaps [rsp+0xA0], xmm10
000071c0d83e0917  vmovaps [rsp+0xB0], xmm11
000071c0d83e0920  vmovaps [rsp+0xC0], xmm12
000071c0d83e0929  vmovaps [rsp+0xD0], xmm13
000071c0d83e0932  vmovaps [rsp+0xE0], xmm14
000071c0d83e093b  sub rsp, 0x30
000071c0d83e093f  movaps [rsp], xmm15
000071c0d83e0944  movaps [rsp+0x10], xmm11
000071c0d83e094a  movaps [rsp+0x20], xmm6
000071c0d83e094f  lea rdi, [rsp]
000071c0d83e0953  mov esi, 0x00
000071c0d83e0958  mov rax, 0x5904ED15D530
000071c0d83e0962  call rax
000071c0d83e0964  movaps xmm15, [rsp]
000071c0d83e0969  add rsp, 0x30
000071c0d83e096d  vmovaps xmm0, [rsp]
000071c0d83e0972  vmovaps xmm1, [rsp+0x10]
000071c0d83e0978  vmovaps xmm2, [rsp+0x20]
000071c0d83e097e  vmovaps xmm3, [rsp+0x30]
000071c0d83e0984  vmovaps xmm4, [rsp+0x40]
000071c0d83e098a  vmovaps xmm5, [rsp+0x50]
000071c0d83e0990  vmovaps xmm6, [rsp+0x60]
000071c0d83e0996  vmovaps xmm7, [rsp+0x70]
000071c0d83e099c  vmovaps xmm8, [rsp+0x80]
000071c0d83e09a5  vmovaps xmm9, [rsp+0x90]
000071c0d83e09ae  vmovaps xmm10, [rsp+0xA0]
000071c0d83e09b7  vmovaps xmm11, [rsp+0xB0]
000071c0d83e09c0  vmovaps xmm12, [rsp+0xC0]
000071c0d83e09c9  vmovaps xmm13, [rsp+0xD0]
000071c0d83e09d2  vmovaps xmm14, [rsp+0xE0]
000071c0d83e09db  add rsp, 0xF0
000071c0d83e09e2  pop r11
000071c0d83e09e4  pop r10
000071c0d83e09e6  pop r9
000071c0d83e09e8  pop r8
000071c0d83e09ea  pop rsi
000071c0d83e09eb  pop rdi
000071c0d83e09ec  pop rdx
000071c0d83e09ed  pop rcx
000071c0d83e09ee  pop rax
000071c0d83e09ef  add rsp, 0x08
000071c0d83e09f3  jmp 0x000071C0D83DC658
000071c0d83e09f8  sub rsp, 0x08
000071c0d83e09fc  push rax
000071c0d83e09fd  push rcx
000071c0d83e09fe  push rdx
000071c0d83e09ff  push rdi
000071c0d83e0a00  push rsi
000071c0d83e0a01  push r8
000071c0d83e0a03  push r9
000071c0d83e0a05  push r10
000071c0d83e0a07  push r11
000071c0d83e0a09  sub rsp, 0xF0
000071c0d83e0a10  vmovaps [rsp], xmm0
000071c0d83e0a15  vmovaps [rsp+0x10], xmm1
000071c0d83e0a1b  vmovaps [rsp+0x20], xmm2
000071c0d83e0a21  vmovaps [rsp+0x30], xmm3
000071c0d83e0a27  vmovaps [rsp+0x40], xmm4
000071c0d83e0a2d  vmovaps [rsp+0x50], xmm5
000071c0d83e0a33  vmovaps [rsp+0x60], xmm6
000071c0d83e0a39  vmovaps [rsp+0x70], xmm8
000071c0d83e0a3f  vmovaps [rsp+0x80], xmm9
000071c0d83e0a48  vmovaps [rsp+0x90], xmm10
000071c0d83e0a51  vmovaps [rsp+0xA0], xmm11
000071c0d83e0a5a  vmovaps [rsp+0xB0], xmm12
000071c0d83e0a63  vmovaps [rsp+0xC0], xmm13
000071c0d83e0a6c  vmovaps [rsp+0xD0], xmm14
000071c0d83e0a75  vmovaps [rsp+0xE0], xmm15
000071c0d83e0a7e  sub rsp, 0x30
000071c0d83e0a82  movaps [rsp], xmm7
000071c0d83e0a86  movaps [rsp+0x10], xmm11
000071c0d83e0a8c  movaps [rsp+0x20], xmm9
000071c0d83e0a92  lea rdi, [rsp]
000071c0d83e0a96  mov esi, 0x00
000071c0d83e0a9b  mov rax, 0x5904ED15D530
000071c0d83e0aa5  call rax
000071c0d83e0aa7  movaps xmm7, [rsp]
000071c0d83e0aab  add rsp, 0x30
000071c0d83e0aaf  vmovaps xmm0, [rsp]
000071c0d83e0ab4  vmovaps xmm1, [rsp+0x10]
000071c0d83e0aba  vmovaps xmm2, [rsp+0x20]
000071c0d83e0ac0  vmovaps xmm3, [rsp+0x30]
000071c0d83e0ac6  vmovaps xmm4, [rsp+0x40]
000071c0d83e0acc  vmovaps xmm5, [rsp+0x50]
000071c0d83e0ad2  vmovaps xmm6, [rsp+0x60]
000071c0d83e0ad8  vmovaps xmm8, [rsp+0x70]
000071c0d83e0ade  vmovaps xmm9, [rsp+0x80]
000071c0d83e0ae7  vmovaps xmm10, [rsp+0x90]
000071c0d83e0af0  vmovaps xmm11, [rsp+0xA0]
000071c0d83e0af9  vmovaps xmm12, [rsp+0xB0]
000071c0d83e0b02  vmovaps xmm13, [rsp+0xC0]
000071c0d83e0b0b  vmovaps xmm14, [rsp+0xD0]
000071c0d83e0b14  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0b1d  add rsp, 0xF0
000071c0d83e0b24  pop r11
000071c0d83e0b26  pop r10
000071c0d83e0b28  pop r9
000071c0d83e0b2a  pop r8
000071c0d83e0b2c  pop rsi
000071c0d83e0b2d  pop rdi
000071c0d83e0b2e  pop rdx
000071c0d83e0b2f  pop rcx
000071c0d83e0b30  pop rax
000071c0d83e0b31  add rsp, 0x08
000071c0d83e0b35  jmp 0x000071C0D83DC685
000071c0d83e0b3a  sub rsp, 0x08
000071c0d83e0b3e  push rax
000071c0d83e0b3f  push rcx
000071c0d83e0b40  push rdx
000071c0d83e0b41  push rdi
000071c0d83e0b42  push rsi
000071c0d83e0b43  push r8
000071c0d83e0b45  push r9
000071c0d83e0b47  push r10
000071c0d83e0b49  push r11
000071c0d83e0b4b  sub rsp, 0xF0
000071c0d83e0b52  vmovaps [rsp], xmm0
000071c0d83e0b57  vmovaps [rsp+0x10], xmm1
000071c0d83e0b5d  vmovaps [rsp+0x20], xmm2
000071c0d83e0b63  vmovaps [rsp+0x30], xmm3
000071c0d83e0b69  vmovaps [rsp+0x40], xmm4
000071c0d83e0b6f  vmovaps [rsp+0x50], xmm5
000071c0d83e0b75  vmovaps [rsp+0x60], xmm6
000071c0d83e0b7b  vmovaps [rsp+0x70], xmm7
000071c0d83e0b81  vmovaps [rsp+0x80], xmm8
000071c0d83e0b8a  vmovaps [rsp+0x90], xmm9
000071c0d83e0b93  vmovaps [rsp+0xA0], xmm10
000071c0d83e0b9c  vmovaps [rsp+0xB0], xmm12
000071c0d83e0ba5  vmovaps [rsp+0xC0], xmm13
000071c0d83e0bae  vmovaps [rsp+0xD0], xmm14
000071c0d83e0bb7  vmovaps [rsp+0xE0], xmm15
000071c0d83e0bc0  sub rsp, 0x30
000071c0d83e0bc4  movaps [rsp], xmm11
000071c0d83e0bc9  movaps [rsp+0x10], xmm10
000071c0d83e0bcf  movaps [rsp+0x20], xmm14
000071c0d83e0bd5  lea rdi, [rsp]
000071c0d83e0bd9  mov esi, 0x00
000071c0d83e0bde  mov rax, 0x5904ED15D530
000071c0d83e0be8  call rax
000071c0d83e0bea  movaps xmm11, [rsp]
000071c0d83e0bef  add rsp, 0x30
000071c0d83e0bf3  vmovaps xmm0, [rsp]
000071c0d83e0bf8  vmovaps xmm1, [rsp+0x10]
000071c0d83e0bfe  vmovaps xmm2, [rsp+0x20]
000071c0d83e0c04  vmovaps xmm3, [rsp+0x30]
000071c0d83e0c0a  vmovaps xmm4, [rsp+0x40]
000071c0d83e0c10  vmovaps xmm5, [rsp+0x50]
000071c0d83e0c16  vmovaps xmm6, [rsp+0x60]
000071c0d83e0c1c  vmovaps xmm7, [rsp+0x70]
000071c0d83e0c22  vmovaps xmm8, [rsp+0x80]
000071c0d83e0c2b  vmovaps xmm9, [rsp+0x90]
000071c0d83e0c34  vmovaps xmm10, [rsp+0xA0]
000071c0d83e0c3d  vmovaps xmm12, [rsp+0xB0]
000071c0d83e0c46  vmovaps xmm13, [rsp+0xC0]
000071c0d83e0c4f  vmovaps xmm14, [rsp+0xD0]
000071c0d83e0c58  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0c61  add rsp, 0xF0
000071c0d83e0c68  pop r11
000071c0d83e0c6a  pop r10
000071c0d83e0c6c  pop r9
000071c0d83e0c6e  pop r8
000071c0d83e0c70  pop rsi
000071c0d83e0c71  pop rdi
000071c0d83e0c72  pop rdx
000071c0d83e0c73  pop rcx
000071c0d83e0c74  pop rax
000071c0d83e0c75  add rsp, 0x08
000071c0d83e0c79  jmp 0x000071C0D83DC6A0
000071c0d83e0c7e  call 0x000071C0D82C33A0
000071c0d83e0c83  jmp 0x000071C0D83DC6AA
000071c0d83e0c88  sub rsp, 0x08
000071c0d83e0c8c  push rax
000071c0d83e0c8d  push rcx
000071c0d83e0c8e  push rdx
000071c0d83e0c8f  push rdi
000071c0d83e0c90  push rsi
000071c0d83e0c91  push r8
000071c0d83e0c93  push r9
000071c0d83e0c95  push r10
000071c0d83e0c97  push r11
000071c0d83e0c99  sub rsp, 0xF0
000071c0d83e0ca0  vmovaps [rsp], xmm0
000071c0d83e0ca5  vmovaps [rsp+0x10], xmm1
000071c0d83e0cab  vmovaps [rsp+0x20], xmm2
000071c0d83e0cb1  vmovaps [rsp+0x30], xmm3
000071c0d83e0cb7  vmovaps [rsp+0x40], xmm4
000071c0d83e0cbd  vmovaps [rsp+0x50], xmm5
000071c0d83e0cc3  vmovaps [rsp+0x60], xmm6
000071c0d83e0cc9  vmovaps [rsp+0x70], xmm7
000071c0d83e0ccf  vmovaps [rsp+0x80], xmm8
000071c0d83e0cd8  vmovaps [rsp+0x90], xmm9
000071c0d83e0ce1  vmovaps [rsp+0xA0], xmm11
000071c0d83e0cea  vmovaps [rsp+0xB0], xmm12
000071c0d83e0cf3  vmovaps [rsp+0xC0], xmm13
000071c0d83e0cfc  vmovaps [rsp+0xD0], xmm14
000071c0d83e0d05  vmovaps [rsp+0xE0], xmm15
000071c0d83e0d0e  sub rsp, 0x30
000071c0d83e0d12  movaps [rsp], xmm10
000071c0d83e0d17  movaps [rsp+0x10], xmm1
000071c0d83e0d1c  movaps [rsp+0x20], xmm12
000071c0d83e0d22  lea rdi, [rsp]
000071c0d83e0d26  mov esi, 0x00
000071c0d83e0d2b  mov rax, 0x5904ED15D530
000071c0d83e0d35  call rax
000071c0d83e0d37  movaps xmm10, [rsp]
000071c0d83e0d3c  add rsp, 0x30
000071c0d83e0d40  vmovaps xmm0, [rsp]
000071c0d83e0d45  vmovaps xmm1, [rsp+0x10]
000071c0d83e0d4b  vmovaps xmm2, [rsp+0x20]
000071c0d83e0d51  vmovaps xmm3, [rsp+0x30]
000071c0d83e0d57  vmovaps xmm4, [rsp+0x40]
000071c0d83e0d5d  vmovaps xmm5, [rsp+0x50]
000071c0d83e0d63  vmovaps xmm6, [rsp+0x60]
000071c0d83e0d69  vmovaps xmm7, [rsp+0x70]
000071c0d83e0d6f  vmovaps xmm8, [rsp+0x80]
000071c0d83e0d78  vmovaps xmm9, [rsp+0x90]
000071c0d83e0d81  vmovaps xmm11, [rsp+0xA0]
000071c0d83e0d8a  vmovaps xmm12, [rsp+0xB0]
000071c0d83e0d93  vmovaps xmm13, [rsp+0xC0]
000071c0d83e0d9c  vmovaps xmm14, [rsp+0xD0]
000071c0d83e0da5  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0dae  add rsp, 0xF0
000071c0d83e0db5  pop r11
000071c0d83e0db7  pop r10
000071c0d83e0db9  pop r9
000071c0d83e0dbb  pop r8
000071c0d83e0dbd  pop rsi
000071c0d83e0dbe  pop rdi
000071c0d83e0dbf  pop rdx
000071c0d83e0dc0  pop rcx
000071c0d83e0dc1  pop rax
000071c0d83e0dc2  add rsp, 0x08
000071c0d83e0dc6  jmp 0x000071C0D83DC6CD
000071c0d83e0dcb  sub rsp, 0x08
000071c0d83e0dcf  push rax
000071c0d83e0dd0  push rcx
000071c0d83e0dd1  push rdx
000071c0d83e0dd2  push rdi
000071c0d83e0dd3  push rsi
000071c0d83e0dd4  push r8
000071c0d83e0dd6  push r9
000071c0d83e0dd8  push r10
000071c0d83e0dda  push r11
000071c0d83e0ddc  sub rsp, 0xF0
000071c0d83e0de3  vmovaps [rsp], xmm0
000071c0d83e0de8  vmovaps [rsp+0x10], xmm1
000071c0d83e0dee  vmovaps [rsp+0x20], xmm2
000071c0d83e0df4  vmovaps [rsp+0x30], xmm3
000071c0d83e0dfa  vmovaps [rsp+0x40], xmm4
000071c0d83e0e00  vmovaps [rsp+0x50], xmm5
000071c0d83e0e06  vmovaps [rsp+0x60], xmm6
000071c0d83e0e0c  vmovaps [rsp+0x70], xmm7
000071c0d83e0e12  vmovaps [rsp+0x80], xmm8
000071c0d83e0e1b  vmovaps [rsp+0x90], xmm9
000071c0d83e0e24  vmovaps [rsp+0xA0], xmm10
000071c0d83e0e2d  vmovaps [rsp+0xB0], xmm11
000071c0d83e0e36  vmovaps [rsp+0xC0], xmm13
000071c0d83e0e3f  vmovaps [rsp+0xD0], xmm14
000071c0d83e0e48  vmovaps [rsp+0xE0], xmm15
000071c0d83e0e51  sub rsp, 0x30
000071c0d83e0e55  movaps [rsp], xmm12
000071c0d83e0e5a  movaps [rsp+0x10], xmm14
000071c0d83e0e60  movaps [rsp+0x20], xmm1
000071c0d83e0e65  lea rdi, [rsp]
000071c0d83e0e69  mov esi, 0x00
000071c0d83e0e6e  mov rax, 0x5904ED15D530
000071c0d83e0e78  call rax
000071c0d83e0e7a  movaps xmm12, [rsp]
000071c0d83e0e7f  add rsp, 0x30
000071c0d83e0e83  vmovaps xmm0, [rsp]
000071c0d83e0e88  vmovaps xmm1, [rsp+0x10]
000071c0d83e0e8e  vmovaps xmm2, [rsp+0x20]
000071c0d83e0e94  vmovaps xmm3, [rsp+0x30]
000071c0d83e0e9a  vmovaps xmm4, [rsp+0x40]
000071c0d83e0ea0  vmovaps xmm5, [rsp+0x50]
000071c0d83e0ea6  vmovaps xmm6, [rsp+0x60]
000071c0d83e0eac  vmovaps xmm7, [rsp+0x70]
000071c0d83e0eb2  vmovaps xmm8, [rsp+0x80]
000071c0d83e0ebb  vmovaps xmm9, [rsp+0x90]
000071c0d83e0ec4  vmovaps xmm10, [rsp+0xA0]
000071c0d83e0ecd  vmovaps xmm11, [rsp+0xB0]
000071c0d83e0ed6  vmovaps xmm13, [rsp+0xC0]
000071c0d83e0edf  vmovaps xmm14, [rsp+0xD0]
000071c0d83e0ee8  vmovaps xmm15, [rsp+0xE0]
000071c0d83e0ef1  add rsp, 0xF0
000071c0d83e0ef8  pop r11
000071c0d83e0efa  pop r10
000071c0d83e0efc  pop r9
000071c0d83e0efe  pop r8
000071c0d83e0f00  pop rsi
000071c0d83e0f01  pop rdi
000071c0d83e0f02  pop rdx
000071c0d83e0f03  pop rcx
000071c0d83e0f04  pop rax
000071c0d83e0f05  add rsp, 0x08
000071c0d83e0f09  jmp 0x000071C0D83DC6FC
000071c0d83e0f0e  sub rsp, 0x08
000071c0d83e0f12  push rax
000071c0d83e0f13  push rcx
000071c0d83e0f14  push rdx
000071c0d83e0f15  push rdi
000071c0d83e0f16  push rsi
000071c0d83e0f17  push r8
000071c0d83e0f19  push r9
000071c0d83e0f1b  push r10
000071c0d83e0f1d  push r11
000071c0d83e0f1f  sub rsp, 0xF0
000071c0d83e0f26  vmovaps [rsp], xmm0
000071c0d83e0f2b  vmovaps [rsp+0x10], xmm1
000071c0d83e0f31  vmovaps [rsp+0x20], xmm2
000071c0d83e0f37  vmovaps [rsp+0x30], xmm3
000071c0d83e0f3d  vmovaps [rsp+0x40], xmm4
000071c0d83e0f43  vmovaps [rsp+0x50], xmm5
000071c0d83e0f49  vmovaps [rsp+0x60], xmm6
000071c0d83e0f4f  vmovaps [rsp+0x70], xmm7
000071c0d83e0f55  vmovaps [rsp+0x80], xmm8
000071c0d83e0f5e  vmovaps [rsp+0x90], xmm9
000071c0d83e0f67  vmovaps [rsp+0xA0], xmm10
000071c0d83e0f70  vmovaps [rsp+0xB0], xmm11
000071c0d83e0f79  vmovaps [rsp+0xC0], xmm12
000071c0d83e0f82  vmovaps [rsp+0xD0], xmm13
000071c0d83e0f8b  vmovaps [rsp+0xE0], xmm15
000071c0d83e0f94  sub rsp, 0x30
000071c0d83e0f98  movaps [rsp], xmm14
000071c0d83e0f9d  movaps [rsp+0x10], xmm9
000071c0d83e0fa3  movaps [rsp+0x20], xmm1
000071c0d83e0fa8  lea rdi, [rsp]
000071c0d83e0fac  mov esi, 0x00
000071c0d83e0fb1  mov rax, 0x5904ED15D530
000071c0d83e0fbb  call rax
000071c0d83e0fbd  movaps xmm14, [rsp]
000071c0d83e0fc2  add rsp, 0x30
000071c0d83e0fc6  vmovaps xmm0, [rsp]
000071c0d83e0fcb  vmovaps xmm1, [rsp+0x10]
000071c0d83e0fd1  vmovaps xmm2, [rsp+0x20]
000071c0d83e0fd7  vmovaps xmm3, [rsp+0x30]
000071c0d83e0fdd  vmovaps xmm4, [rsp+0x40]
000071c0d83e0fe3  vmovaps xmm5, [rsp+0x50]
000071c0d83e0fe9  vmovaps xmm6, [rsp+0x60]
000071c0d83e0fef  vmovaps xmm7, [rsp+0x70]
000071c0d83e0ff5  vmovaps xmm8, [rsp+0x80]
000071c0d83e0ffe  vmovaps xmm9, [rsp+0x90]
000071c0d83e1007  vmovaps xmm10, [rsp+0xA0]
000071c0d83e1010  vmovaps xmm11, [rsp+0xB0]
000071c0d83e1019  vmovaps xmm12, [rsp+0xC0]
000071c0d83e1022  vmovaps xmm13, [rsp+0xD0]
000071c0d83e102b  vmovaps xmm15, [rsp+0xE0]
000071c0d83e1034  add rsp, 0xF0
000071c0d83e103b  pop r11
000071c0d83e103d  pop r10
000071c0d83e103f  pop r9
000071c0d83e1041  pop r8
000071c0d83e1043  pop rsi
000071c0d83e1044  pop rdi
000071c0d83e1045  pop rdx
000071c0d83e1046  pop rcx
000071c0d83e1047  pop rax
000071c0d83e1048  add rsp, 0x08
000071c0d83e104c  jmp 0x000071C0D83DC72B
000071c0d83e1051  sub rsp, 0x08
000071c0d83e1055  push rax
000071c0d83e1056  push rcx
000071c0d83e1057  push rdx
000071c0d83e1058  push rdi
000071c0d83e1059  push rsi
000071c0d83e105a  push r8
000071c0d83e105c  push r9
000071c0d83e105e  push r10
000071c0d83e1060  push r11
000071c0d83e1062  sub rsp, 0xF0
000071c0d83e1069  vmovaps [rsp], xmm0
000071c0d83e106e  vmovaps [rsp+0x10], xmm2
000071c0d83e1074  vmovaps [rsp+0x20], xmm3
000071c0d83e107a  vmovaps [rsp+0x30], xmm4
000071c0d83e1080  vmovaps [rsp+0x40], xmm5
000071c0d83e1086  vmovaps [rsp+0x50], xmm6
000071c0d83e108c  vmovaps [rsp+0x60], xmm7
000071c0d83e1092  vmovaps [rsp+0x70], xmm8
000071c0d83e1098  vmovaps [rsp+0x80], xmm9
000071c0d83e10a1  vmovaps [rsp+0x90], xmm10
000071c0d83e10aa  vmovaps [rsp+0xA0], xmm11
000071c0d83e10b3  vmovaps [rsp+0xB0], xmm12
000071c0d83e10bc  vmovaps [rsp+0xC0], xmm13
000071c0d83e10c5  vmovaps [rsp+0xD0], xmm14
000071c0d83e10ce  vmovaps [rsp+0xE0], xmm15
000071c0d83e10d7  sub rsp, 0x30
000071c0d83e10db  movaps [rsp], xmm1
000071c0d83e10df  movaps [rsp+0x10], xmm13
000071c0d83e10e5  movaps [rsp+0x20], xmm8
000071c0d83e10eb  lea rdi, [rsp]
000071c0d83e10ef  mov esi, 0x00
000071c0d83e10f4  mov rax, 0x5904ED15D530
000071c0d83e10fe  call rax
000071c0d83e1100  movaps xmm1, [rsp]
000071c0d83e1104  add rsp, 0x30
000071c0d83e1108  vmovaps xmm0, [rsp]
000071c0d83e110d  vmovaps xmm2, [rsp+0x10]
000071c0d83e1113  vmovaps xmm3, [rsp+0x20]
000071c0d83e1119  vmovaps xmm4, [rsp+0x30]
000071c0d83e111f  vmovaps xmm5, [rsp+0x40]
000071c0d83e1125  vmovaps xmm6, [rsp+0x50]
000071c0d83e112b  vmovaps xmm7, [rsp+0x60]
000071c0d83e1131  vmovaps xmm8, [rsp+0x70]
000071c0d83e1137  vmovaps xmm9, [rsp+0x80]
000071c0d83e1140  vmovaps xmm10, [rsp+0x90]
000071c0d83e1149  vmovaps xmm11, [rsp+0xA0]
000071c0d83e1152  vmovaps xmm12, [rsp+0xB0]
000071c0d83e115b  vmovaps xmm13, [rsp+0xC0]
000071c0d83e1164  vmovaps xmm14, [rsp+0xD0]
000071c0d83e116d  vmovaps xmm15, [rsp+0xE0]
000071c0d83e1176  add rsp, 0xF0
000071c0d83e117d  pop r11
000071c0d83e117f  pop r10
000071c0d83e1181  pop r9
000071c0d83e1183  pop r8
000071c0d83e1185  pop rsi
000071c0d83e1186  pop rdi
000071c0d83e1187  pop rdx
000071c0d83e1188  pop rcx
000071c0d83e1189  pop rax
000071c0d83e118a  add rsp, 0x08
000071c0d83e118e  jmp 0x000071C0D83DC74D
000071c0d83e1193  call 0x000071C0D820C260
000071c0d83e1198  jmp 0x000071C0D83DC75B
000071c0d83e119d  call 0x000071C0D82BD750
000071c0d83e11a2  jmp 0x000071C0D83DC765
000071c0d83e11a7  sub rsp, 0x08
000071c0d83e11ab  push rax
000071c0d83e11ac  push rcx
000071c0d83e11ad  push rdx
000071c0d83e11ae  push rdi
000071c0d83e11af  push rsi
000071c0d83e11b0  push r8
000071c0d83e11b2  push r9
000071c0d83e11b4  push r10
000071c0d83e11b6  push r11
000071c0d83e11b8  sub rsp, 0xF0
000071c0d83e11bf  vmovaps [rsp], xmm0
000071c0d83e11c4  vmovaps [rsp+0x10], xmm1
000071c0d83e11ca  vmovaps [rsp+0x20], xmm2
000071c0d83e11d0  vmovaps [rsp+0x30], xmm3
000071c0d83e11d6  vmovaps [rsp+0x40], xmm4
000071c0d83e11dc  vmovaps [rsp+0x50], xmm5
000071c0d83e11e2  vmovaps [rsp+0x60], xmm6
000071c0d83e11e8  vmovaps [rsp+0x70], xmm7
000071c0d83e11ee  vmovaps [rsp+0x80], xmm9
000071c0d83e11f7  vmovaps [rsp+0x90], xmm10
000071c0d83e1200  vmovaps [rsp+0xA0], xmm11
000071c0d83e1209  vmovaps [rsp+0xB0], xmm12
000071c0d83e1212  vmovaps [rsp+0xC0], xmm13
000071c0d83e121b  vmovaps [rsp+0xD0], xmm14
000071c0d83e1224  vmovaps [rsp+0xE0], xmm15
000071c0d83e122d  sub rsp, 0x30
000071c0d83e1231  movaps [rsp], xmm8
000071c0d83e1236  movaps [rsp+0x10], xmm15
000071c0d83e123c  movaps [rsp+0x20], xmm7
000071c0d83e1241  lea rdi, [rsp]
000071c0d83e1245  mov esi, 0x00
000071c0d83e124a  mov rax, 0x5904ED15D530
000071c0d83e1254  call rax
000071c0d83e1256  movaps xmm8, [rsp]
000071c0d83e125b  add rsp, 0x30
000071c0d83e125f  vmovaps xmm0, [rsp]
000071c0d83e1264  vmovaps xmm1, [rsp+0x10]
000071c0d83e126a  vmovaps xmm2, [rsp+0x20]
000071c0d83e1270  vmovaps xmm3, [rsp+0x30]
000071c0d83e1276  vmovaps xmm4, [rsp+0x40]
000071c0d83e127c  vmovaps xmm5, [rsp+0x50]
000071c0d83e1282  vmovaps xmm6, [rsp+0x60]
000071c0d83e1288  vmovaps xmm7, [rsp+0x70]
000071c0d83e128e  vmovaps xmm9, [rsp+0x80]
000071c0d83e1297  vmovaps xmm10, [rsp+0x90]
000071c0d83e12a0  vmovaps xmm11, [rsp+0xA0]
000071c0d83e12a9  vmovaps xmm12, [rsp+0xB0]
000071c0d83e12b2  vmovaps xmm13, [rsp+0xC0]
000071c0d83e12bb  vmovaps xmm14, [rsp+0xD0]
000071c0d83e12c4  vmovaps xmm15, [rsp+0xE0]
000071c0d83e12cd  add rsp, 0xF0
000071c0d83e12d4  pop r11
000071c0d83e12d6  pop r10
000071c0d83e12d8  pop r9
000071c0d83e12da  pop r8
000071c0d83e12dc  pop rsi
000071c0d83e12dd  pop rdi
000071c0d83e12de  pop rdx
000071c0d83e12df  pop rcx
000071c0d83e12e0  pop rax
000071c0d83e12e1  add rsp, 0x08
000071c0d83e12e5  jmp 0x000071C0D83DC787
000071c0d83e12ea  sub rsp, 0x08
000071c0d83e12ee  push rax
000071c0d83e12ef  push rcx
000071c0d83e12f0  push rdx
000071c0d83e12f1  push rdi
000071c0d83e12f2  push rsi
000071c0d83e12f3  push r8
000071c0d83e12f5  push r9
000071c0d83e12f7  push r10
000071c0d83e12f9  push r11
000071c0d83e12fb  sub rsp, 0xF0
000071c0d83e1302  vmovaps [rsp], xmm0
000071c0d83e1307  vmovaps [rsp+0x10], xmm1
000071c0d83e130d  vmovaps [rsp+0x20], xmm2
000071c0d83e1313  vmovaps [rsp+0x30], xmm3
000071c0d83e1319  vmovaps [rsp+0x40], xmm4
000071c0d83e131f  vmovaps [rsp+0x50], xmm5
000071c0d83e1325  vmovaps [rsp+0x60], xmm6
000071c0d83e132b  vmovaps [rsp+0x70], xmm8
000071c0d83e1331  vmovaps [rsp+0x80], xmm9
000071c0d83e133a  vmovaps [rsp+0x90], xmm10
000071c0d83e1343  vmovaps [rsp+0xA0], xmm11
000071c0d83e134c  vmovaps [rsp+0xB0], xmm12
000071c0d83e1355  vmovaps [rsp+0xC0], xmm13
000071c0d83e135e  vmovaps [rsp+0xD0], xmm14
000071c0d83e1367  vmovaps [rsp+0xE0], xmm15
000071c0d83e1370  sub rsp, 0x30
000071c0d83e1374  movaps [rsp], xmm7
000071c0d83e1378  movaps [rsp+0x10], xmm9
000071c0d83e137e  movaps [rsp+0x20], xmm15
000071c0d83e1384  lea rdi, [rsp]
000071c0d83e1388  mov esi, 0x00
000071c0d83e138d  mov rax, 0x5904ED15D530
000071c0d83e1397  call rax
000071c0d83e1399  movaps xmm7, [rsp]
000071c0d83e139d  add rsp, 0x30
000071c0d83e13a1  vmovaps xmm0, [rsp]
000071c0d83e13a6  vmovaps xmm1, [rsp+0x10]
000071c0d83e13ac  vmovaps xmm2, [rsp+0x20]
000071c0d83e13b2  vmovaps xmm3, [rsp+0x30]
000071c0d83e13b8  vmovaps xmm4, [rsp+0x40]
000071c0d83e13be  vmovaps xmm5, [rsp+0x50]
000071c0d83e13c4  vmovaps xmm6, [rsp+0x60]
000071c0d83e13ca  vmovaps xmm8, [rsp+0x70]
000071c0d83e13d0  vmovaps xmm9, [rsp+0x80]
000071c0d83e13d9  vmovaps xmm10, [rsp+0x90]
000071c0d83e13e2  vmovaps xmm11, [rsp+0xA0]
000071c0d83e13eb  vmovaps xmm12, [rsp+0xB0]
000071c0d83e13f4  vmovaps xmm13, [rsp+0xC0]
000071c0d83e13fd  vmovaps xmm14, [rsp+0xD0]
000071c0d83e1406  vmovaps xmm15, [rsp+0xE0]
000071c0d83e140f  add rsp, 0xF0
000071c0d83e1416  pop r11
000071c0d83e1418  pop r10
000071c0d83e141a  pop r9
000071c0d83e141c  pop r8
000071c0d83e141e  pop rsi
000071c0d83e141f  pop rdi
000071c0d83e1420  pop rdx
000071c0d83e1421  pop rcx
000071c0d83e1422  pop rax
000071c0d83e1423  add rsp, 0x08
000071c0d83e1427  jmp 0x000071C0D83DC7B4
000071c0d83e142c  sub rsp, 0x08
000071c0d83e1430  push rax
000071c0d83e1431  push rcx
000071c0d83e1432  push rdx
000071c0d83e1433  push rdi
000071c0d83e1434  push rsi
000071c0d83e1435  push r8
000071c0d83e1437  push r9
000071c0d83e1439  push r10
000071c0d83e143b  push r11
000071c0d83e143d  sub rsp, 0xF0
000071c0d83e1444  vmovaps [rsp], xmm0
000071c0d83e1449  vmovaps [rsp+0x10], xmm1
000071c0d83e144f  vmovaps [rsp+0x20], xmm2
000071c0d83e1455  vmovaps [rsp+0x30], xmm3
000071c0d83e145b  vmovaps [rsp+0x40], xmm4
000071c0d83e1461  vmovaps [rsp+0x50], xmm5
000071c0d83e1467  vmovaps [rsp+0x60], xmm6
000071c0d83e146d  vmovaps [rsp+0x70], xmm7
000071c0d83e1473  vmovaps [rsp+0x80], xmm8
000071c0d83e147c  vmovaps [rsp+0x90], xmm10
000071c0d83e1485  vmovaps [rsp+0xA0], xmm11
000071c0d83e148e  vmovaps [rsp+0xB0], xmm12
000071c0d83e1497  vmovaps [rsp+0xC0], xmm13
000071c0d83e14a0  vmovaps [rsp+0xD0], xmm14
000071c0d83e14a9  vmovaps [rsp+0xE0], xmm15
000071c0d83e14b2  sub rsp, 0x30
000071c0d83e14b6  movaps [rsp], xmm9
000071c0d83e14bb  movaps [rsp+0x10], xmm13
000071c0d83e14c1  movaps [rsp+0x20], xmm15
000071c0d83e14c7  lea rdi, [rsp]
000071c0d83e14cb  mov esi, 0x00
000071c0d83e14d0  mov rax, 0x5904ED15D530
000071c0d83e14da  call rax
000071c0d83e14dc  movaps xmm9, [rsp]
000071c0d83e14e1  add rsp, 0x30
000071c0d83e14e5  vmovaps xmm0, [rsp]
000071c0d83e14ea  vmovaps xmm1, [rsp+0x10]
000071c0d83e14f0  vmovaps xmm2, [rsp+0x20]
000071c0d83e14f6  vmovaps xmm3, [rsp+0x30]
000071c0d83e14fc  vmovaps xmm4, [rsp+0x40]
000071c0d83e1502  vmovaps xmm5, [rsp+0x50]
000071c0d83e1508  vmovaps xmm6, [rsp+0x60]
000071c0d83e150e  vmovaps xmm7, [rsp+0x70]
000071c0d83e1514  vmovaps xmm8, [rsp+0x80]
000071c0d83e151d  vmovaps xmm10, [rsp+0x90]
000071c0d83e1526  vmovaps xmm11, [rsp+0xA0]
000071c0d83e152f  vmovaps xmm12, [rsp+0xB0]
000071c0d83e1538  vmovaps xmm13, [rsp+0xC0]
000071c0d83e1541  vmovaps xmm14, [rsp+0xD0]
000071c0d83e154a  vmovaps xmm15, [rsp+0xE0]
000071c0d83e1553  add rsp, 0xF0
000071c0d83e155a  pop r11
000071c0d83e155c  pop r10
000071c0d83e155e  pop r9
000071c0d83e1560  pop r8
000071c0d83e1562  pop rsi
000071c0d83e1563  pop rdi
000071c0d83e1564  pop rdx
000071c0d83e1565  pop rcx
000071c0d83e1566  pop rax
000071c0d83e1567  add rsp, 0x08
000071c0d83e156b  jmp 0x000071C0D83DC7E2
000071c0d83e1570  sub rsp, 0x08
000071c0d83e1574  push rax
000071c0d83e1575  push rcx
000071c0d83e1576  push rdx
000071c0d83e1577  push rdi
000071c0d83e1578  push rsi
000071c0d83e1579  push r8
000071c0d83e157b  push r9
000071c0d83e157d  push r10
000071c0d83e157f  push r11
000071c0d83e1581  sub rsp, 0xF0
000071c0d83e1588  vmovaps [rsp], xmm0
000071c0d83e158d  vmovaps [rsp+0x10], xmm1
000071c0d83e1593  vmovaps [rsp+0x20], xmm2
000071c0d83e1599  vmovaps [rsp+0x30], xmm3
000071c0d83e159f  vmovaps [rsp+0x40], xmm4
000071c0d83e15a5  vmovaps [rsp+0x50], xmm5
000071c0d83e15ab  vmovaps [rsp+0x60], xmm6
000071c0d83e15b1  vmovaps [rsp+0x70], xmm7
000071c0d83e15b7  vmovaps [rsp+0x80], xmm8
000071c0d83e15c0  vmovaps [rsp+0x90], xmm9
000071c0d83e15c9  vmovaps [rsp+0xA0], xmm10
000071c0d83e15d2  vmovaps [rsp+0xB0], xmm11
000071c0d83e15db  vmovaps [rsp+0xC0], xmm12
000071c0d83e15e4  vmovaps [rsp+0xD0], xmm13
000071c0d83e15ed  vmovaps [rsp+0xE0], xmm14
000071c0d83e15f6  sub rsp, 0x30
000071c0d83e15fa  movaps [rsp], xmm15
000071c0d83e15ff  movaps [rsp+0x10], xmm11
000071c0d83e1605  movaps [rsp+0x20], xmm12
000071c0d83e160b  lea rdi, [rsp]
000071c0d83e160f  mov esi, 0x00
000071c0d83e1614  mov rax, 0x5904ED15D530
000071c0d83e161e  call rax
000071c0d83e1620  movaps xmm15, [rsp]
000071c0d83e1625  add rsp, 0x30
000071c0d83e1629  vmovaps xmm0, [rsp]
000071c0d83e162e  vmovaps xmm1, [rsp+0x10]
000071c0d83e1634  vmovaps xmm2, [rsp+0x20]
000071c0d83e163a  vmovaps xmm3, [rsp+0x30]
000071c0d83e1640  vmovaps xmm4, [rsp+0x40]
000071c0d83e1646  vmovaps xmm5, [rsp+0x50]
000071c0d83e164c  vmovaps xmm6, [rsp+0x60]
000071c0d83e1652  vmovaps xmm7, [rsp+0x70]
000071c0d83e1658  vmovaps xmm8, [rsp+0x80]
000071c0d83e1661  vmovaps xmm9, [rsp+0x90]
000071c0d83e166a  vmovaps xmm10, [rsp+0xA0]
000071c0d83e1673  vmovaps xmm11, [rsp+0xB0]
000071c0d83e167c  vmovaps xmm12, [rsp+0xC0]
000071c0d83e1685  vmovaps xmm13, [rsp+0xD0]
000071c0d83e168e  vmovaps xmm14, [rsp+0xE0]
000071c0d83e1697  add rsp, 0xF0
000071c0d83e169e  pop r11
000071c0d83e16a0  pop r10
000071c0d83e16a2  pop r9
000071c0d83e16a4  pop r8
000071c0d83e16a6  pop rsi
000071c0d83e16a7  pop rdi
000071c0d83e16a8  pop rdx
000071c0d83e16a9  pop rcx
000071c0d83e16aa  pop rax
000071c0d83e16ab  add rsp, 0x08
000071c0d83e16af  jmp 0x000071C0D83DC7FD
000071c0d83e16b4  sub rsp, 0x08
000071c0d83e16b8  push rax
000071c0d83e16b9  push rcx
000071c0d83e16ba  push rdx
000071c0d83e16bb  push rdi
000071c0d83e16bc  push rsi
000071c0d83e16bd  push r8
000071c0d83e16bf  push r9
000071c0d83e16c1  push r10
000071c0d83e16c3  push r11
000071c0d83e16c5  sub rsp, 0xF0
000071c0d83e16cc  vmovaps [rsp], xmm0
000071c0d83e16d1  vmovaps [rsp+0x10], xmm1
000071c0d83e16d7  vmovaps [rsp+0x20], xmm2
000071c0d83e16dd  vmovaps [rsp+0x30], xmm3
000071c0d83e16e3  vmovaps [rsp+0x40], xmm4
000071c0d83e16e9  vmovaps [rsp+0x50], xmm5
000071c0d83e16ef  vmovaps [rsp+0x60], xmm6
000071c0d83e16f5  vmovaps [rsp+0x70], xmm7
000071c0d83e16fb  vmovaps [rsp+0x80], xmm8
000071c0d83e1704  vmovaps [rsp+0x90], xmm9
000071c0d83e170d  vmovaps [rsp+0xA0], xmm10
000071c0d83e1716  vmovaps [rsp+0xB0], xmm11
000071c0d83e171f  vmovaps [rsp+0xC0], xmm12
000071c0d83e1728  vmovaps [rsp+0xD0], xmm14
000071c0d83e1731  vmovaps [rsp+0xE0], xmm15
000071c0d83e173a  sub rsp, 0x30
000071c0d83e173e  movaps [rsp], xmm13
000071c0d83e1743  movaps [rsp+0x10], xmm10
000071c0d83e1749  movaps [rsp+0x20], xmm14
000071c0d83e174f  lea rdi, [rsp]
000071c0d83e1753  mov esi, 0x00
000071c0d83e1758  mov rax, 0x5904ED15D530
000071c0d83e1762  call rax
000071c0d83e1764  movaps xmm13, [rsp]
000071c0d83e1769  add rsp, 0x30
000071c0d83e176d  vmovaps xmm0, [rsp]
000071c0d83e1772  vmovaps xmm1, [rsp+0x10]
000071c0d83e1778  vmovaps xmm2, [rsp+0x20]
000071c0d83e177e  vmovaps xmm3, [rsp+0x30]
000071c0d83e1784  vmovaps xmm4, [rsp+0x40]
000071c0d83e178a  vmovaps xmm5, [rsp+0x50]
000071c0d83e1790  vmovaps xmm6, [rsp+0x60]
000071c0d83e1796  vmovaps xmm7, [rsp+0x70]
000071c0d83e179c  vmovaps xmm8, [rsp+0x80]
000071c0d83e17a5  vmovaps xmm9, [rsp+0x90]
000071c0d83e17ae  vmovaps xmm10, [rsp+0xA0]
000071c0d83e17b7  vmovaps xmm11, [rsp+0xB0]
000071c0d83e17c0  vmovaps xmm12, [rsp+0xC0]
000071c0d83e17c9  vmovaps xmm14, [rsp+0xD0]
000071c0d83e17d2  vmovaps xmm15, [rsp+0xE0]
000071c0d83e17db  add rsp, 0xF0
000071c0d83e17e2  pop r11
000071c0d83e17e4  pop r10
000071c0d83e17e6  pop r9
000071c0d83e17e8  pop r8
000071c0d83e17ea  pop rsi
000071c0d83e17eb  pop rdi
000071c0d83e17ec  pop rdx
000071c0d83e17ed  pop rcx
000071c0d83e17ee  pop rax
000071c0d83e17ef  add rsp, 0x08
000071c0d83e17f3  jmp 0x000071C0D83DC820
000071c0d83e17f8  sub rsp, 0x08
000071c0d83e17fc  push rax
000071c0d83e17fd  push rcx
000071c0d83e17fe  push rdx
000071c0d83e17ff  push rdi
000071c0d83e1800  push rsi
000071c0d83e1801  push r8
000071c0d83e1803  push r9
000071c0d83e1805  push r10
000071c0d83e1807  push r11
000071c0d83e1809  sub rsp, 0xF0
000071c0d83e1810  vmovaps [rsp], xmm0
000071c0d83e1815  vmovaps [rsp+0x10], xmm1
000071c0d83e181b  vmovaps [rsp+0x20], xmm2
000071c0d83e1821  vmovaps [rsp+0x30], xmm3
000071c0d83e1827  vmovaps [rsp+0x40], xmm4
000071c0d83e182d  vmovaps [rsp+0x50], xmm5
000071c0d83e1833  vmovaps [rsp+0x60], xmm6
000071c0d83e1839  vmovaps [rsp+0x70], xmm7
000071c0d83e183f  vmovaps [rsp+0x80], xmm8
000071c0d83e1848  vmovaps [rsp+0x90], xmm9
000071c0d83e1851  vmovaps [rsp+0xA0], xmm10
000071c0d83e185a  vmovaps [rsp+0xB0], xmm11
000071c0d83e1863  vmovaps [rsp+0xC0], xmm12
000071c0d83e186c  vmovaps [rsp+0xD0], xmm13
000071c0d83e1875  vmovaps [rsp+0xE0], xmm15
000071c0d83e187e  sub rsp, 0x30
000071c0d83e1882  movaps [rsp], xmm14
000071c0d83e1887  movaps [rsp+0x10], xmm1
000071c0d83e188c  movaps [rsp+0x20], xmm7
000071c0d83e1891  lea rdi, [rsp]
000071c0d83e1895  mov esi, 0x00
000071c0d83e189a  mov rax, 0x5904ED15D530
000071c0d83e18a4  call rax
000071c0d83e18a6  movaps xmm14, [rsp]
000071c0d83e18ab  add rsp, 0x30
000071c0d83e18af  vmovaps xmm0, [rsp]
000071c0d83e18b4  vmovaps xmm1, [rsp+0x10]
000071c0d83e18ba  vmovaps xmm2, [rsp+0x20]
000071c0d83e18c0  vmovaps xmm3, [rsp+0x30]
000071c0d83e18c6  vmovaps xmm4, [rsp+0x40]
000071c0d83e18cc  vmovaps xmm5, [rsp+0x50]
000071c0d83e18d2  vmovaps xmm6, [rsp+0x60]
000071c0d83e18d8  vmovaps xmm7, [rsp+0x70]
000071c0d83e18de  vmovaps xmm8, [rsp+0x80]
000071c0d83e18e7  vmovaps xmm9, [rsp+0x90]
000071c0d83e18f0  vmovaps xmm10, [rsp+0xA0]
000071c0d83e18f9  vmovaps xmm11, [rsp+0xB0]
000071c0d83e1902  vmovaps xmm12, [rsp+0xC0]
000071c0d83e190b  vmovaps xmm13, [rsp+0xD0]
000071c0d83e1914  vmovaps xmm15, [rsp+0xE0]
000071c0d83e191d  add rsp, 0xF0
000071c0d83e1924  pop r11
000071c0d83e1926  pop r10
000071c0d83e1928  pop r9
000071c0d83e192a  pop r8
000071c0d83e192c  pop rsi
000071c0d83e192d  pop rdi
000071c0d83e192e  pop rdx
000071c0d83e192f  pop rcx
000071c0d83e1930  pop rax
000071c0d83e1931  add rsp, 0x08
000071c0d83e1935  jmp 0x000071C0D83DC843
000071c0d83e193a  sub rsp, 0x08
000071c0d83e193e  push rax
000071c0d83e193f  push rcx
000071c0d83e1940  push rdx
000071c0d83e1941  push rdi
000071c0d83e1942  push rsi
000071c0d83e1943  push r8
000071c0d83e1945  push r9
000071c0d83e1947  push r10
000071c0d83e1949  push r11
000071c0d83e194b  sub rsp, 0xF0
000071c0d83e1952  vmovaps [rsp], xmm0
000071c0d83e1957  vmovaps [rsp+0x10], xmm2
000071c0d83e195d  vmovaps [rsp+0x20], xmm3
000071c0d83e1963  vmovaps [rsp+0x30], xmm4
000071c0d83e1969  vmovaps [rsp+0x40], xmm5
000071c0d83e196f  vmovaps [rsp+0x50], xmm6
000071c0d83e1975  vmovaps [rsp+0x60], xmm7
000071c0d83e197b  vmovaps [rsp+0x70], xmm8
000071c0d83e1981  vmovaps [rsp+0x80], xmm9
000071c0d83e198a  vmovaps [rsp+0x90], xmm10
000071c0d83e1993  vmovaps [rsp+0xA0], xmm11
000071c0d83e199c  vmovaps [rsp+0xB0], xmm12
000071c0d83e19a5  vmovaps [rsp+0xC0], xmm13
000071c0d83e19ae  vmovaps [rsp+0xD0], xmm14
000071c0d83e19b7  vmovaps [rsp+0xE0], xmm15
000071c0d83e19c0  sub rsp, 0x30
000071c0d83e19c4  movaps [rsp], xmm1
000071c0d83e19c8  movaps [rsp+0x10], xmm8
000071c0d83e19ce  movaps [rsp+0x20], xmm9
000071c0d83e19d4  lea rdi, [rsp]
000071c0d83e19d8  mov esi, 0x00
000071c0d83e19dd  mov rax, 0x5904ED15D530
000071c0d83e19e7  call rax
000071c0d83e19e9  movaps xmm1, [rsp]
000071c0d83e19ed  add rsp, 0x30
000071c0d83e19f1  vmovaps xmm0, [rsp]
000071c0d83e19f6  vmovaps xmm2, [rsp+0x10]
000071c0d83e19fc  vmovaps xmm3, [rsp+0x20]
000071c0d83e1a02  vmovaps xmm4, [rsp+0x30]
000071c0d83e1a08  vmovaps xmm5, [rsp+0x40]
000071c0d83e1a0e  vmovaps xmm6, [rsp+0x50]
000071c0d83e1a14  vmovaps xmm7, [rsp+0x60]
000071c0d83e1a1a  vmovaps xmm8, [rsp+0x70]
000071c0d83e1a20  vmovaps xmm9, [rsp+0x80]
000071c0d83e1a29  vmovaps xmm10, [rsp+0x90]
000071c0d83e1a32  vmovaps xmm11, [rsp+0xA0]
000071c0d83e1a3b  vmovaps xmm12, [rsp+0xB0]
000071c0d83e1a44  vmovaps xmm13, [rsp+0xC0]
000071c0d83e1a4d  vmovaps xmm14, [rsp+0xD0]
000071c0d83e1a56  vmovaps xmm15, [rsp+0xE0]
000071c0d83e1a5f  add rsp, 0xF0
000071c0d83e1a66  pop r11
000071c0d83e1a68  pop r10
000071c0d83e1a6a  pop r9
000071c0d83e1a6c  pop r8
000071c0d83e1a6e  pop rsi
000071c0d83e1a6f  pop rdi
000071c0d83e1a70  pop rdx
000071c0d83e1a71  pop rcx
000071c0d83e1a72  pop rax
000071c0d83e1a73  add rsp, 0x08
000071c0d83e1a77  jmp 0x000071C0D83DC865
000071c0d83e1a7c  call 0x000071C0D82E5940
000071c0d83e1a81  jmp 0x000071C0D83DC873
000071c0d83e1a86  call 0x000071C0D820C380
000071c0d83e1a8b  jmp 0x000071C0D83DC87D
000071c0d83e1a90  call 0x000071C0D820D600
000071c0d83e1a95  jmp 0x000071C0D83DC887
000071c0d83e1a9a  call 0x000071C0D81FF540
000071c0d83e1a9f  jmp 0x000071C0D83DC891
000071c0d83e1aa4  int3
000071c0d83e1aa5  nop [rax+rax*1], ax
000071c0d83e1aae  nop
000071c0d83e1ab0  mov rax, [r15+0xF8]
000071c0d83e1ab7  lea r14, [rax+0x140]
000071c0d83e1abe  mov r12, [r13+r14*1]
000071c0d83e1ac3  mov [r15+0xE8], r12
000071c0d83e1aca  lea r14, [rax+0x130]
000071c0d83e1ad1  mov r12, [r13+r14*1]
000071c0d83e1ad6  lea r14, [rax+0x138]
000071c0d83e1add  mov r11, [r13+r14*1]
000071c0d83e1ae2  movq xmm1, r12
000071c0d83e1ae7  movq xmm15, r11
000071c0d83e1aec  movq xmm1, xmm1
000071c0d83e1af0  movq xmm1, xmm1
000071c0d83e1af4  movaps [r15+0x1A0], xmm1
000071c0d83e1afc  movq xmm15, xmm15
000071c0d83e1b01  movq xmm15, xmm15
000071c0d83e1b06  movaps [r15+0x190], xmm15
000071c0d83e1b0e  lea r14, [rax+0x120]
000071c0d83e1b15  mov r12, [r13+r14*1]
000071c0d83e1b1a  lea r14, [rax+0x128]
000071c0d83e1b21  mov r11, [r13+r14*1]
000071c0d83e1b26  movq xmm1, r12
000071c0d83e1b2b  movq xmm15, r11
000071c0d83e1b30  movq xmm1, xmm1
000071c0d83e1b34  movq xmm1, xmm1
000071c0d83e1b38  movaps [r15+0x1C0], xmm1
000071c0d83e1b40  movq xmm15, xmm15
000071c0d83e1b45  movq xmm15, xmm15
000071c0d83e1b4a  movaps [r15+0x1B0], xmm15
000071c0d83e1b52  lea r14, [rax+0x110]
000071c0d83e1b59  mov r12, [r13+r14*1]
000071c0d83e1b5e  lea r14, [rax+0x118]
000071c0d83e1b65  mov r11, [r13+r14*1]
000071c0d83e1b6a  movq xmm1, r12
000071c0d83e1b6f  movq xmm15, r11
000071c0d83e1b74  movq xmm1, xmm1
000071c0d83e1b78  movq xmm1, xmm1
000071c0d83e1b7c  movaps [r15+0x1E0], xmm1
000071c0d83e1b84  movq xmm15, xmm15
000071c0d83e1b89  movq xmm15, xmm15
000071c0d83e1b8e  movaps [r15+0x1D0], xmm15
000071c0d83e1b96  lea r14, [rax+0x100]
000071c0d83e1b9d  mov r12, [r13+r14*1]
000071c0d83e1ba2  lea r14, [rax+0x108]
000071c0d83e1ba9  mov r11, [r13+r14*1]
000071c0d83e1bae  movq xmm1, r12
000071c0d83e1bb3  movq xmm15, r11
000071c0d83e1bb8  movq xmm1, xmm1
000071c0d83e1bbc  movq xmm1, xmm1
000071c0d83e1bc0  movaps [r15+0x200], xmm1
000071c0d83e1bc8  movq xmm15, xmm15
000071c0d83e1bcd  movq xmm15, xmm15
000071c0d83e1bd2  movaps [r15+0x1F0], xmm15
000071c0d83e1bda  mov qword ptr [r15+0x40], 0x430000
000071c0d83e1be2  mov r14d, 0x430510
000071c0d83e1be8  mov r12, [r13+r14*1]
000071c0d83e1bed  movq xmm1, r12
000071c0d83e1bf2  lea r14, [rax+0x150]
000071c0d83e1bf9  mov [r15+0xF8], r14
000071c0d83e1c00  mov rax, [r15+0x50]
000071c0d83e1c04  movups xmm15, [r13+rax*1]
000071c0d83e1c0a  movaps [r15+0x120], xmm15
000071c0d83e1c12  mov qword ptr [r15+0x48], 0x10
000071c0d83e1c1a  xor eax, eax
000071c0d83e1c1c  mov r14d, 0x10
000071c0d83e1c22  mov r12d, 0x200
000071c0d83e1c28  cmp r14, r12
000071c0d83e1c2b  cmc
000071c0d83e1c2c  lahf
000071c0d83e1c2d  seto al
000071c0d83e1c30  mov [r15+0x108], eax
000071c0d83e1c37  pextrq rax, xmm15, 0x01
000071c0d83e1c3e  movq xmm14, rax
000071c0d83e1c43  movaps [r15+0x130], xmm14
000071c0d83e1c4b  movq rax, xmm1
000071c0d83e1c50  movq r14, xmm15
000071c0d83e1c55  vmovq xmm1, rax
000071c0d83e1c5a  vmovq xmm15, r14
000071c0d83e1c5f  movaps xmm13, xmm1
000071c0d83e1c63  addsd xmm13, xmm15
000071c0d83e1c68  ucomisd xmm13, xmm13
000071c0d83e1c6d  jp 0x000071C0D83E1D86
000071c0d83e1c73  movq xmm13, xmm13
000071c0d83e1c78  movq rax, xmm13
000071c0d83e1c7d  movq r14, xmm14
000071c0d83e1c82  vmovq xmm1, rax
000071c0d83e1c87  vmovq xmm15, r14
000071c0d83e1c8c  movaps xmm14, xmm1
000071c0d83e1c90  addsd xmm14, xmm15
000071c0d83e1c95  ucomisd xmm14, xmm14
000071c0d83e1c9a  jp 0x000071C0D83E1DCE
000071c0d83e1ca0  movq xmm14, xmm14
000071c0d83e1ca5  movaps [r15+0x110], xmm14
000071c0d83e1cad  mov eax, [r15+0x108]
000071c0d83e1cb4  sahf
000071c0d83e1cb5  jnz 0x000071C0D83E1CE7
000071c0d83e1cb7  cmp dword ptr [r15+0x318], 0x00
000071c0d83e1cbf  jz 0x000071C0D83E1FE0
000071c0d83e1cc5  nop [rax+rax*1], ax
000071c0d83e1cce  nop [rax+rax*1], eax
000071c0d83e1cd6  mov eax, 0x410490
000071c0d83e1cdb  mov [r15+0x100], rax
000071c0d83e1ce2  jmp 0x000071C0D81FE110
000071c0d83e1ce7  cmp dword ptr [r15+0x318], 0x00
000071c0d83e1cef  jz 0x000071C0D83E1E20
000071c0d83e1cf5  nop [rax+rax*1], ax
000071c0d83e1cfe  nop [rax+rax*1], eax
000071c0d83e1d06  mov eax, 0x410474
000071c0d83e1d0b  mov [r15+0x100], rax
000071c0d83e1d12  jmp 0x000071C0D81FE110
000071c0d83e1d17  int3
000071c0d83e1d18  call 0x000071C0D82E27E0
000071c0d83e1d1d  jmp 0x000071C0D83E1AC3
000071c0d83e1d22  call 0x000071C0D82E27E0
000071c0d83e1d27  jmp 0x000071C0D83E1AD6
000071c0d83e1d2c  call 0x000071C0D82E1570
000071c0d83e1d31  jmp 0x000071C0D83E1AE2
000071c0d83e1d36  call 0x000071C0D82E27E0
000071c0d83e1d3b  jmp 0x000071C0D83E1B1A
000071c0d83e1d40  call 0x000071C0D82E1570
000071c0d83e1d45  jmp 0x000071C0D83E1B26
000071c0d83e1d4a  call 0x000071C0D82E27E0
000071c0d83e1d4f  jmp 0x000071C0D83E1B5E
000071c0d83e1d54  call 0x000071C0D82E1570
000071c0d83e1d59  jmp 0x000071C0D83E1B6A
000071c0d83e1d5e  call 0x000071C0D82E27E0
000071c0d83e1d63  jmp 0x000071C0D83E1BA2
000071c0d83e1d68  call 0x000071C0D82E1570
000071c0d83e1d6d  jmp 0x000071C0D83E1BAE
000071c0d83e1d72  call 0x000071C0D82E27E0
000071c0d83e1d77  jmp 0x000071C0D83E1BED
000071c0d83e1d7c  call 0x000071C0D820E760
000071c0d83e1d81  jmp 0x000071C0D83E1C0A
000071c0d83e1d86  ucomisd xmm1, xmm15
000071c0d83e1d8b  jp 0x000071C0D83E1D9A
000071c0d83e1d8d  movaps xmm13, [0x000071C0D7FFE060]
000071c0d83e1d95  jmp 0x000071C0D83E1C73
000071c0d83e1d9a  vxorps xmm0, xmm1, xmm15
000071c0d83e1d9f  pextrw eax, xmm0, 0x03
000071c0d83e1da4  and eax, 0x7FF8
000071c0d83e1da9  cmp eax, 0x08
000071c0d83e1dac  jnz 0x000071C0D83E1C73
000071c0d83e1db2  movq rax, xmm15
000071c0d83e1db7  shl rax, 0x0D
000071c0d83e1dbb  jbe 0x000071C0D83E1C73
000071c0d83e1dc1  vorps xmm13, xmm15, [0x000071C0D7FFE070]
000071c0d83e1dc9  jmp 0x000071C0D83E1C73
000071c0d83e1dce  ucomisd xmm1, xmm15
000071c0d83e1dd3  jp 0x000071C0D83E1DE2
000071c0d83e1dd5  movaps xmm14, [0x000071C0D7FFE060]
000071c0d83e1ddd  jmp 0x000071C0D83E1CA0
000071c0d83e1de2  vxorps xmm0, xmm1, xmm15
000071c0d83e1de7  pextrw eax, xmm0, 0x03
000071c0d83e1dec  and eax, 0x7FF8
000071c0d83e1df1  cmp eax, 0x08
000071c0d83e1df4  jnz 0x000071C0D83E1CA0
000071c0d83e1dfa  movq rax, xmm15
000071c0d83e1dff  shl rax, 0x0D
000071c0d83e1e03  jbe 0x000071C0D83E1CA0
000071c0d83e1e09  vorps xmm14, xmm15, [0x000071C0D7FFE070]
000071c0d83e1e11  jmp 0x000071C0D83E1CA0
000071c0d83e1e16  int3
000071c0d83e1e17  nop [rax+rax*1], ax
000071c0d83e1e20  mov rax, [r15+0x48]
000071c0d83e1e24  mov r14, [r15+0x50]
000071c0d83e1e28  lea r12, [r14+rax*1]
000071c0d83e1e2c  movups xmm1, [r13+r12*1]
000071c0d83e1e32  movaps [r15+0x120], xmm1
000071c0d83e1e3a  lea r14, [rax+0x10]
000071c0d83e1e3e  mov [r15+0x48], r14
000071c0d83e1e42  xor eax, eax
000071c0d83e1e44  mov r12d, 0x200
000071c0d83e1e4a  cmp r14, r12
000071c0d83e1e4d  cmc
000071c0d83e1e4e  lahf
000071c0d83e1e4f  seto al
000071c0d83e1e52  mov [r15+0x108], eax
000071c0d83e1e59  pextrq rax, xmm1, 0x01
000071c0d83e1e60  movq xmm15, rax
000071c0d83e1e65  movaps [r15+0x130], xmm15
000071c0d83e1e6d  movaps xmm14, [r15+0x110]
000071c0d83e1e75  movq rax, xmm14
000071c0d83e1e7a  movq r14, xmm1
000071c0d83e1e7f  vmovq xmm1, rax
000071c0d83e1e84  vmovq xmm14, r14
000071c0d83e1e89  movaps xmm13, xmm1
000071c0d83e1e8d  addsd xmm13, xmm14
000071c0d83e1e92  ucomisd xmm13, xmm13
000071c0d83e1e97  jp 0x000071C0D83E1F4C
000071c0d83e1e9d  movq xmm13, xmm13
000071c0d83e1ea2  movq rax, xmm13
000071c0d83e1ea7  movq r14, xmm15
000071c0d83e1eac  vmovq xmm1, rax
000071c0d83e1eb1  vmovq xmm15, r14
000071c0d83e1eb6  movaps xmm14, xmm1
000071c0d83e1eba  addsd xmm14, xmm15
000071c0d83e1ebf  ucomisd xmm14, xmm14
000071c0d83e1ec4  jp 0x000071C0D83E1F94
000071c0d83e1eca  movq xmm14, xmm14
000071c0d83e1ecf  movaps [r15+0x110], xmm14
000071c0d83e1ed7  mov eax, [r15+0x108]
000071c0d83e1ede  sahf
000071c0d83e1edf  jnz 0x000071C0D83E1F11
000071c0d83e1ee1  cmp dword ptr [r15+0x318], 0x00
000071c0d83e1ee9  jz 0x000071C0D83E1FE0
000071c0d83e1eef  nop [rax+rax*1], ax
000071c0d83e1ef8  nop [rax+rax*1], eax
000071c0d83e1f00  mov eax, 0x410490
000071c0d83e1f05  mov [r15+0x100], rax
000071c0d83e1f0c  jmp 0x000071C0D81FE110
000071c0d83e1f11  cmp dword ptr [r15+0x318], 0x00
000071c0d83e1f19  jz 0x000071C0D83E1E20
000071c0d83e1f1f  nop [rax+rax*1], ax
000071c0d83e1f28  nop [rax+rax*1], eax
000071c0d83e1f30  mov eax, 0x410474
000071c0d83e1f35  mov [r15+0x100], rax
000071c0d83e1f3c  jmp 0x000071C0D81FE110
000071c0d83e1f41  int3
000071c0d83e1f42  call 0x000071C0D82B52F0
000071c0d83e1f47  jmp 0x000071C0D83E1E32
000071c0d83e1f4c  ucomisd xmm1, xmm14
000071c0d83e1f51  jp 0x000071C0D83E1F60
000071c0d83e1f53  movaps xmm13, [0x000071C0D7FFE060]
000071c0d83e1f5b  jmp 0x000071C0D83E1E9D
000071c0d83e1f60  vxorps xmm0, xmm1, xmm14
000071c0d83e1f65  pextrw eax, xmm0, 0x03
000071c0d83e1f6a  and eax, 0x7FF8
000071c0d83e1f6f  cmp eax, 0x08
000071c0d83e1f72  jnz 0x000071C0D83E1E9D
000071c0d83e1f78  movq rax, xmm14
000071c0d83e1f7d  shl rax, 0x0D
000071c0d83e1f81  jbe 0x000071C0D83E1E9D
000071c0d83e1f87  vorps xmm13, xmm14, [0x000071C0D7FFE070]
000071c0d83e1f8f  jmp 0x000071C0D83E1E9D
000071c0d83e1f94  ucomisd xmm1, xmm15
000071c0d83e1f99  jp 0x000071C0D83E1FA8
000071c0d83e1f9b  movaps xmm14, [0x000071C0D7FFE060]
000071c0d83e1fa3  jmp 0x000071C0D83E1ECA
000071c0d83e1fa8  vxorps xmm0, xmm1, xmm15
000071c0d83e1fad  pextrw eax, xmm0, 0x03
000071c0d83e1fb2  and eax, 0x7FF8
000071c0d83e1fb7  cmp eax, 0x08
000071c0d83e1fba  jnz 0x000071C0D83E1ECA
000071c0d83e1fc0  movq rax, xmm15
000071c0d83e1fc5  shl rax, 0x0D
000071c0d83e1fc9  jbe 0x000071C0D83E1ECA
000071c0d83e1fcf  vorps xmm14, xmm15, [0x000071C0D7FFE070]
000071c0d83e1fd7  jmp 0x000071C0D83E1ECA
000071c0d83e1fdc  int3
000071c0d83e1fdd  nop [rax], eax
000071c0d83e1fe0  mov rax, [r15+0x40]
000071c0d83e1fe4  lea r14, [rax+0x510]
000071c0d83e1feb  movaps xmm1, [r15+0x110]
000071c0d83e1ff3  movq rax, xmm1
000071c0d83e1ff8  mov [r13+r14*1], rax
000071c0d83e1ffd  mov rax, [r15+0xF0]
000071c0d83e2004  mov [r15+0x100], rax
000071c0d83e200b  jmp 0x000071C0D83CE5C0
000071c0d83e2010  int3
000071c0d83e2011  call 0x000071C0D82D5EB0
000071c0d83e2016  jmp 0x000071C0D83E1FFD
000071c0d83e201b  int3
000071c0d83e201c  nop [rax], eax
000071c0d83e2020  mov qword ptr [r15+0x100], 0x04
000071c0d83e202b  mov esi, 0x00
000071c0d83e2030  mov edx, 0x09
000071c0d83e2035  mov rdi, 0x7FFE6F5BD4D0
000071c0d83e203f  mov rax, 0x5904ECFF0970
000071c0d83e2049  call rax
000071c0d83e204b  cmp dword ptr [r15+0x318], 0x00
000071c0d83e2053  jnz 0x000071C0D81FE110
000071c0d83e2059  jmp 0x000071C0D81FE0A0
000071c0d83e205e  int3
000071c0d83e205f  int3
