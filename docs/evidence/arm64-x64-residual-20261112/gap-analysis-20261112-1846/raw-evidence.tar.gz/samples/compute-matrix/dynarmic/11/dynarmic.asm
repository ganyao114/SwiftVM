00007cd93bdce69b  nop [rax+rax*1], eax
00007cd93bdce6a0  vmovaps xmm1, [0x00007CD93B9FE010]
00007cd93bdce6a8  movq xmm1, xmm1
00007cd93bdce6ac  movaps [r15+0x110], xmm1
00007cd93bdce6b4  vmovaps xmm1, [0x00007CD93B9FE020]
00007cd93bdce6bc  movq xmm1, xmm1
00007cd93bdce6c0  movaps [r15+0x120], xmm1
00007cd93bdce6c8  mov eax, 0x4204C0
00007cd93bdce6cd  mov r14, [r13+rax*1]
00007cd93bdce6d2  movq xmm1, r14
00007cd93bdce6d7  movaps [r15+0x130], xmm1
00007cd93bdce6df  vmovaps xmm1, [0x00007CD93B9FE030]
00007cd93bdce6e7  vpbroadcastq xmm1, xmm1
00007cd93bdce6ec  movaps [r15+0x140], xmm1
00007cd93bdce6f4  mov qword ptr [r15+0x40], 0x02
00007cd93bdce6fc  vmovaps xmm15, [0x00007CD93B9FE040]
00007cd93bdce704  movq xmm15, xmm15
00007cd93bdce709  movaps [r15+0x150], xmm15
00007cd93bdce711  mov qword ptr [r15+0x58], 0x420000
00007cd93bdce719  vmovaps xmm15, [0x00007CD93B9FE050]
00007cd93bdce721  vpbroadcastq xmm15, xmm15
00007cd93bdce726  movaps [r15+0x160], xmm15
00007cd93bdce72e  mov rax, [r15+0x40]
00007cd93bdce732  vmovq xmm14, rax
00007cd93bdce737  vpbroadcastq xmm14, xmm14
00007cd93bdce73c  movaps [r15+0x170], xmm14
00007cd93bdce744  mov eax, 0x4204D0
00007cd93bdce749  movups xmm13, [r13+rax*1]
00007cd93bdce74f  mov qword ptr [r15+0x40], 0x430518
00007cd93bdce757  mov qword ptr [r15+0x50], 0x430720
00007cd93bdce75f  vpmovqd xmm12, xmm13
00007cd93bdce765  pxor xmm11, xmm11
00007cd93bdce76a  punpcklqdq xmm12, xmm11
00007cd93bdce76f  movaps [r15+0x210], xmm12
00007cd93bdce777  movq xmm12, qword ptr [r15+0x120]
00007cd93bdce780  movq xmm11, qword ptr [r15+0x130]
00007cd93bdce789  psubd xmm12, xmm11
00007cd93bdce78e  movq xmm12, xmm12
00007cd93bdce793  paddq xmm13, xmm14
00007cd93bdce798  movaps [r15+0x180], xmm13
00007cd93bdce7a0  movq xmm14, qword ptr [r15+0x150]
00007cd93bdce7a9  paddd xmm11, xmm14
00007cd93bdce7ae  movq xmm11, xmm11
00007cd93bdce7b3  movq xmm11, xmm11
00007cd93bdce7b8  movaps [r15+0x130], xmm11
00007cd93bdce7c0  pmovzxdq xmm12, xmm12
00007cd93bdce7c6  psllq xmm12, 0x00
00007cd93bdce7cc  movq xmm14, qword ptr [r15+0x210]
00007cd93bdce7d5  movq xmm13, qword ptr [r15+0x110]
00007cd93bdce7de  paddd xmm14, xmm13
00007cd93bdce7e3  movq xmm14, xmm14
00007cd93bdce7e8  vcvtuqq2pd xmm12, xmm12
00007cd93bdce7ee  pmovzxdq xmm14, xmm14
00007cd93bdce7f4  psllq xmm14, 0x00
00007cd93bdce7fa  vcvtuqq2pd xmm14, xmm14
00007cd93bdce800  movaps xmm13, xmm12
00007cd93bdce804  mulpd xmm13, xmm1
00007cd93bdce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007cd93bdce80f  ptest xmm11, xmm11
00007cd93bdce815  jnz 0x00007CD93BDCE8FF
00007cd93bdce81b  movaps [r15+0x220], xmm13
00007cd93bdce823  mov eax, 0x430720
00007cd93bdce828  movups [r13+rax*1], xmm13
00007cd93bdce82e  movaps xmm1, xmm14
00007cd93bdce832  mulpd xmm1, xmm15
00007cd93bdce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007cd93bdce83c  ptest xmm13, xmm13
00007cd93bdce842  jnz 0x00007CD93BDCEA4C
00007cd93bdce848  movaps [r15+0x210], xmm1
00007cd93bdce850  mov eax, 0x430518
00007cd93bdce855  movups [r13+rax*1], xmm1
00007cd93bdce85b  mov qword ptr [r15+0x48], 0x10
00007cd93bdce863  xor eax, eax
00007cd93bdce865  mov r14d, 0x10
00007cd93bdce86b  mov r12d, 0x200
00007cd93bdce871  cmp r14, r12
00007cd93bdce874  cmc
00007cd93bdce875  lahf
00007cd93bdce876  seto al
00007cd93bdce879  mov [r15+0x108], eax
00007cd93bdce880  mov eax, [r15+0x108]
00007cd93bdce887  sahf
00007cd93bdce888  jnz 0x00007CD93BDCE8BA
00007cd93bdce88a  cmp dword ptr [r15+0x318], 0x00
00007cd93bdce892  jz 0x00007CD93BDCEFF0
00007cd93bdce898  nop [rax+rax*1], ax
00007cd93bdce8a1  nop [rax+rax*1], eax
00007cd93bdce8a9  mov eax, 0x4101EC
00007cd93bdce8ae  mov [r15+0x100], rax
00007cd93bdce8b5  jmp 0x00007CD93BBFE110
00007cd93bdce8ba  cmp dword ptr [r15+0x318], 0x00
00007cd93bdce8c2  jz 0x00007CD93BDCEBA0
00007cd93bdce8c8  nop [rax+rax*1], ax
00007cd93bdce8d1  nop [rax+rax*1], eax
00007cd93bdce8d9  mov eax, 0x4101AC
00007cd93bdce8de  mov [r15+0x100], rax
00007cd93bdce8e5  jmp 0x00007CD93BBFE110
00007cd93bdce8ea  int3
00007cd93bdce8eb  call 0x00007CD93BC0DC20
00007cd93bdce8f0  jmp 0x00007CD93BDCE6D2
00007cd93bdce8f5  call 0x00007CD93BC0C260
00007cd93bdce8fa  jmp 0x00007CD93BDCE74F
00007cd93bdce8ff  sub rsp, 0x08
00007cd93bdce903  push rax
00007cd93bdce904  push rcx
00007cd93bdce905  push rdx
00007cd93bdce906  push rdi
00007cd93bdce907  push rsi
00007cd93bdce908  push r8
00007cd93bdce90a  push r9
00007cd93bdce90c  push r10
00007cd93bdce90e  push r11
00007cd93bdce910  sub rsp, 0xF0
00007cd93bdce917  vmovaps [rsp], xmm0
00007cd93bdce91c  vmovaps [rsp+0x10], xmm1
00007cd93bdce922  vmovaps [rsp+0x20], xmm2
00007cd93bdce928  vmovaps [rsp+0x30], xmm3
00007cd93bdce92e  vmovaps [rsp+0x40], xmm4
00007cd93bdce934  vmovaps [rsp+0x50], xmm5
00007cd93bdce93a  vmovaps [rsp+0x60], xmm6
00007cd93bdce940  vmovaps [rsp+0x70], xmm7
00007cd93bdce946  vmovaps [rsp+0x80], xmm8
00007cd93bdce94f  vmovaps [rsp+0x90], xmm9
00007cd93bdce958  vmovaps [rsp+0xA0], xmm10
00007cd93bdce961  vmovaps [rsp+0xB0], xmm11
00007cd93bdce96a  vmovaps [rsp+0xC0], xmm12
00007cd93bdce973  vmovaps [rsp+0xD0], xmm14
00007cd93bdce97c  vmovaps [rsp+0xE0], xmm15
00007cd93bdce985  sub rsp, 0x30
00007cd93bdce989  movaps [rsp], xmm13
00007cd93bdce98e  movaps [rsp+0x10], xmm12
00007cd93bdce994  movaps [rsp+0x20], xmm1
00007cd93bdce999  lea rdi, [rsp]
00007cd93bdce99d  mov esi, 0x00
00007cd93bdce9a2  mov rax, 0x64A581057530
00007cd93bdce9ac  call rax
00007cd93bdce9ae  movaps xmm13, [rsp]
00007cd93bdce9b3  add rsp, 0x30
00007cd93bdce9b7  vmovaps xmm0, [rsp]
00007cd93bdce9bc  vmovaps xmm1, [rsp+0x10]
00007cd93bdce9c2  vmovaps xmm2, [rsp+0x20]
00007cd93bdce9c8  vmovaps xmm3, [rsp+0x30]
00007cd93bdce9ce  vmovaps xmm4, [rsp+0x40]
00007cd93bdce9d4  vmovaps xmm5, [rsp+0x50]
00007cd93bdce9da  vmovaps xmm6, [rsp+0x60]
00007cd93bdce9e0  vmovaps xmm7, [rsp+0x70]
00007cd93bdce9e6  vmovaps xmm8, [rsp+0x80]
00007cd93bdce9ef  vmovaps xmm9, [rsp+0x90]
00007cd93bdce9f8  vmovaps xmm10, [rsp+0xA0]
00007cd93bdcea01  vmovaps xmm11, [rsp+0xB0]
00007cd93bdcea0a  vmovaps xmm12, [rsp+0xC0]
00007cd93bdcea13  vmovaps xmm14, [rsp+0xD0]
00007cd93bdcea1c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdcea25  add rsp, 0xF0
00007cd93bdcea2c  pop r11
00007cd93bdcea2e  pop r10
00007cd93bdcea30  pop r9
00007cd93bdcea32  pop r8
00007cd93bdcea34  pop rsi
00007cd93bdcea35  pop rdi
00007cd93bdcea36  pop rdx
00007cd93bdcea37  pop rcx
00007cd93bdcea38  pop rax
00007cd93bdcea39  add rsp, 0x08
00007cd93bdcea3d  jmp 0x00007CD93BDCE81B
00007cd93bdcea42  call 0x00007CD93BC0C380
00007cd93bdcea47  jmp 0x00007CD93BDCE82E
00007cd93bdcea4c  sub rsp, 0x08
00007cd93bdcea50  push rax
00007cd93bdcea51  push rcx
00007cd93bdcea52  push rdx
00007cd93bdcea53  push rdi
00007cd93bdcea54  push rsi
00007cd93bdcea55  push r8
00007cd93bdcea57  push r9
00007cd93bdcea59  push r10
00007cd93bdcea5b  push r11
00007cd93bdcea5d  sub rsp, 0xF0
00007cd93bdcea64  vmovaps [rsp], xmm0
00007cd93bdcea69  vmovaps [rsp+0x10], xmm2
00007cd93bdcea6f  vmovaps [rsp+0x20], xmm3
00007cd93bdcea75  vmovaps [rsp+0x30], xmm4
00007cd93bdcea7b  vmovaps [rsp+0x40], xmm5
00007cd93bdcea81  vmovaps [rsp+0x50], xmm6
00007cd93bdcea87  vmovaps [rsp+0x60], xmm7
00007cd93bdcea8d  vmovaps [rsp+0x70], xmm8
00007cd93bdcea93  vmovaps [rsp+0x80], xmm9
00007cd93bdcea9c  vmovaps [rsp+0x90], xmm10
00007cd93bdceaa5  vmovaps [rsp+0xA0], xmm11
00007cd93bdceaae  vmovaps [rsp+0xB0], xmm12
00007cd93bdceab7  vmovaps [rsp+0xC0], xmm13
00007cd93bdceac0  vmovaps [rsp+0xD0], xmm14
00007cd93bdceac9  vmovaps [rsp+0xE0], xmm15
00007cd93bdcead2  sub rsp, 0x30
00007cd93bdcead6  movaps [rsp], xmm1
00007cd93bdceada  movaps [rsp+0x10], xmm14
00007cd93bdceae0  movaps [rsp+0x20], xmm15
00007cd93bdceae6  lea rdi, [rsp]
00007cd93bdceaea  mov esi, 0x00
00007cd93bdceaef  mov rax, 0x64A581057530
00007cd93bdceaf9  call rax
00007cd93bdceafb  movaps xmm1, [rsp]
00007cd93bdceaff  add rsp, 0x30
00007cd93bdceb03  vmovaps xmm0, [rsp]
00007cd93bdceb08  vmovaps xmm2, [rsp+0x10]
00007cd93bdceb0e  vmovaps xmm3, [rsp+0x20]
00007cd93bdceb14  vmovaps xmm4, [rsp+0x30]
00007cd93bdceb1a  vmovaps xmm5, [rsp+0x40]
00007cd93bdceb20  vmovaps xmm6, [rsp+0x50]
00007cd93bdceb26  vmovaps xmm7, [rsp+0x60]
00007cd93bdceb2c  vmovaps xmm8, [rsp+0x70]
00007cd93bdceb32  vmovaps xmm9, [rsp+0x80]
00007cd93bdceb3b  vmovaps xmm10, [rsp+0x90]
00007cd93bdceb44  vmovaps xmm11, [rsp+0xA0]
00007cd93bdceb4d  vmovaps xmm12, [rsp+0xB0]
00007cd93bdceb56  vmovaps xmm13, [rsp+0xC0]
00007cd93bdceb5f  vmovaps xmm14, [rsp+0xD0]
00007cd93bdceb68  vmovaps xmm15, [rsp+0xE0]
00007cd93bdceb71  add rsp, 0xF0
00007cd93bdceb78  pop r11
00007cd93bdceb7a  pop r10
00007cd93bdceb7c  pop r9
00007cd93bdceb7e  pop r8
00007cd93bdceb80  pop rsi
00007cd93bdceb81  pop rdi
00007cd93bdceb82  pop rdx
00007cd93bdceb83  pop rcx
00007cd93bdceb84  pop rax
00007cd93bdceb85  add rsp, 0x08
00007cd93bdceb89  jmp 0x00007CD93BDCE848
00007cd93bdceb8e  call 0x00007CD93BBFF540
00007cd93bdceb93  jmp 0x00007CD93BDCE85B
00007cd93bdceb98  int3
00007cd93bdceb99  nop [rax], eax
00007cd93bdceba0  movaps xmm1, [r15+0x180]
00007cd93bdceba8  vpmovqd xmm15, xmm1
00007cd93bdcebae  pxor xmm14, xmm14
00007cd93bdcebb3  punpcklqdq xmm15, xmm14
00007cd93bdcebb8  movaps [r15+0x210], xmm15
00007cd93bdcebc0  movq xmm15, qword ptr [r15+0x120]
00007cd93bdcebc9  movq xmm14, qword ptr [r15+0x130]
00007cd93bdcebd2  psubd xmm15, xmm14
00007cd93bdcebd7  movq xmm15, xmm15
00007cd93bdcebdc  movaps xmm13, [r15+0x170]
00007cd93bdcebe4  paddq xmm1, xmm13
00007cd93bdcebe9  movaps [r15+0x180], xmm1
00007cd93bdcebf1  movq xmm1, qword ptr [r15+0x150]
00007cd93bdcebfa  paddd xmm14, xmm1
00007cd93bdcebff  movq xmm14, xmm14
00007cd93bdcec04  movq xmm14, xmm14
00007cd93bdcec09  movaps [r15+0x130], xmm14
00007cd93bdcec11  pmovzxdq xmm15, xmm15
00007cd93bdcec17  psllq xmm15, 0x00
00007cd93bdcec1d  movq xmm1, qword ptr [r15+0x210]
00007cd93bdcec26  movq xmm14, qword ptr [r15+0x110]
00007cd93bdcec2f  paddd xmm1, xmm14
00007cd93bdcec34  movq xmm1, xmm1
00007cd93bdcec38  vcvtuqq2pd xmm15, xmm15
00007cd93bdcec3e  pmovzxdq xmm1, xmm1
00007cd93bdcec43  psllq xmm1, 0x00
00007cd93bdcec48  vcvtuqq2pd xmm1, xmm1
00007cd93bdcec4e  movaps xmm14, [r15+0x140]
00007cd93bdcec56  movaps xmm13, xmm15
00007cd93bdcec5a  mulpd xmm13, xmm14
00007cd93bdcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007cd93bdcec65  ptest xmm12, xmm12
00007cd93bdcec6b  jnz 0x00007CD93BDCED4E
00007cd93bdcec71  movaps [r15+0x220], xmm13
00007cd93bdcec79  mov rax, [r15+0x48]
00007cd93bdcec7d  mov r14, [r15+0x50]
00007cd93bdcec81  lea r12, [r14+rax*1]
00007cd93bdcec85  movups [r13+r12*1], xmm13
00007cd93bdcec8b  movaps xmm15, [r15+0x160]
00007cd93bdcec93  movaps xmm14, xmm1
00007cd93bdcec97  mulpd xmm14, xmm15
00007cd93bdcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007cd93bdceca2  ptest xmm13, xmm13
00007cd93bdceca8  jnz 0x00007CD93BDCEE9C
00007cd93bdcecae  movaps [r15+0x210], xmm14
00007cd93bdcecb6  mov r14, [r15+0x40]
00007cd93bdcecba  lea r12, [r14+rax*1]
00007cd93bdcecbe  movups [r13+r12*1], xmm14
00007cd93bdcecc4  lea r14, [rax+0x10]
00007cd93bdcecc8  mov [r15+0x48], r14
00007cd93bdceccc  xor eax, eax
00007cd93bdcecce  mov r12d, 0x200
00007cd93bdcecd4  cmp r14, r12
00007cd93bdcecd7  cmc
00007cd93bdcecd8  lahf
00007cd93bdcecd9  seto al
00007cd93bdcecdc  mov [r15+0x108], eax
00007cd93bdcece3  mov eax, [r15+0x108]
00007cd93bdcecea  sahf
00007cd93bdceceb  jnz 0x00007CD93BDCED1D
00007cd93bdceced  cmp dword ptr [r15+0x318], 0x00
00007cd93bdcecf5  jz 0x00007CD93BDCEFF0
00007cd93bdcecfb  nop [rax+rax*1], ax
00007cd93bdced04  nop [rax+rax*1], eax
00007cd93bdced0c  mov eax, 0x4101EC
00007cd93bdced11  mov [r15+0x100], rax
00007cd93bdced18  jmp 0x00007CD93BBFE110
00007cd93bdced1d  cmp dword ptr [r15+0x318], 0x00
00007cd93bdced25  jz 0x00007CD93BDCEBA0
00007cd93bdced2b  nop [rax+rax*1], ax
00007cd93bdced34  nop [rax+rax*1], eax
00007cd93bdced3c  mov eax, 0x4101AC
00007cd93bdced41  mov [r15+0x100], rax
00007cd93bdced48  jmp 0x00007CD93BBFE110
00007cd93bdced4d  int3
00007cd93bdced4e  sub rsp, 0x08
00007cd93bdced52  push rax
00007cd93bdced53  push rcx
00007cd93bdced54  push rdx
00007cd93bdced55  push rdi
00007cd93bdced56  push rsi
00007cd93bdced57  push r8
00007cd93bdced59  push r9
00007cd93bdced5b  push r10
00007cd93bdced5d  push r11
00007cd93bdced5f  sub rsp, 0xF0
00007cd93bdced66  vmovaps [rsp], xmm0
00007cd93bdced6b  vmovaps [rsp+0x10], xmm1
00007cd93bdced71  vmovaps [rsp+0x20], xmm2
00007cd93bdced77  vmovaps [rsp+0x30], xmm3
00007cd93bdced7d  vmovaps [rsp+0x40], xmm4
00007cd93bdced83  vmovaps [rsp+0x50], xmm5
00007cd93bdced89  vmovaps [rsp+0x60], xmm6
00007cd93bdced8f  vmovaps [rsp+0x70], xmm7
00007cd93bdced95  vmovaps [rsp+0x80], xmm8
00007cd93bdced9e  vmovaps [rsp+0x90], xmm9
00007cd93bdceda7  vmovaps [rsp+0xA0], xmm10
00007cd93bdcedb0  vmovaps [rsp+0xB0], xmm11
00007cd93bdcedb9  vmovaps [rsp+0xC0], xmm12
00007cd93bdcedc2  vmovaps [rsp+0xD0], xmm14
00007cd93bdcedcb  vmovaps [rsp+0xE0], xmm15
00007cd93bdcedd4  sub rsp, 0x30
00007cd93bdcedd8  movaps [rsp], xmm13
00007cd93bdceddd  movaps [rsp+0x10], xmm15
00007cd93bdcede3  movaps [rsp+0x20], xmm14
00007cd93bdcede9  lea rdi, [rsp]
00007cd93bdceded  mov esi, 0x00
00007cd93bdcedf2  mov rax, 0x64A581057530
00007cd93bdcedfc  call rax
00007cd93bdcedfe  movaps xmm13, [rsp]
00007cd93bdcee03  add rsp, 0x30
00007cd93bdcee07  vmovaps xmm0, [rsp]
00007cd93bdcee0c  vmovaps xmm1, [rsp+0x10]
00007cd93bdcee12  vmovaps xmm2, [rsp+0x20]
00007cd93bdcee18  vmovaps xmm3, [rsp+0x30]
00007cd93bdcee1e  vmovaps xmm4, [rsp+0x40]
00007cd93bdcee24  vmovaps xmm5, [rsp+0x50]
00007cd93bdcee2a  vmovaps xmm6, [rsp+0x60]
00007cd93bdcee30  vmovaps xmm7, [rsp+0x70]
00007cd93bdcee36  vmovaps xmm8, [rsp+0x80]
00007cd93bdcee3f  vmovaps xmm9, [rsp+0x90]
00007cd93bdcee48  vmovaps xmm10, [rsp+0xA0]
00007cd93bdcee51  vmovaps xmm11, [rsp+0xB0]
00007cd93bdcee5a  vmovaps xmm12, [rsp+0xC0]
00007cd93bdcee63  vmovaps xmm14, [rsp+0xD0]
00007cd93bdcee6c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdcee75  add rsp, 0xF0
00007cd93bdcee7c  pop r11
00007cd93bdcee7e  pop r10
00007cd93bdcee80  pop r9
00007cd93bdcee82  pop r8
00007cd93bdcee84  pop rsi
00007cd93bdcee85  pop rdi
00007cd93bdcee86  pop rdx
00007cd93bdcee87  pop rcx
00007cd93bdcee88  pop rax
00007cd93bdcee89  add rsp, 0x08
00007cd93bdcee8d  jmp 0x00007CD93BDCEC71
00007cd93bdcee92  call 0x00007CD93BCC2240
00007cd93bdcee97  jmp 0x00007CD93BDCEC8B
00007cd93bdcee9c  sub rsp, 0x08
00007cd93bdceea0  push rax
00007cd93bdceea1  push rcx
00007cd93bdceea2  push rdx
00007cd93bdceea3  push rdi
00007cd93bdceea4  push rsi
00007cd93bdceea5  push r8
00007cd93bdceea7  push r9
00007cd93bdceea9  push r10
00007cd93bdceeab  push r11
00007cd93bdceead  sub rsp, 0xF0
00007cd93bdceeb4  vmovaps [rsp], xmm0
00007cd93bdceeb9  vmovaps [rsp+0x10], xmm1
00007cd93bdceebf  vmovaps [rsp+0x20], xmm2
00007cd93bdceec5  vmovaps [rsp+0x30], xmm3
00007cd93bdceecb  vmovaps [rsp+0x40], xmm4
00007cd93bdceed1  vmovaps [rsp+0x50], xmm5
00007cd93bdceed7  vmovaps [rsp+0x60], xmm6
00007cd93bdceedd  vmovaps [rsp+0x70], xmm7
00007cd93bdceee3  vmovaps [rsp+0x80], xmm8
00007cd93bdceeec  vmovaps [rsp+0x90], xmm9
00007cd93bdceef5  vmovaps [rsp+0xA0], xmm10
00007cd93bdceefe  vmovaps [rsp+0xB0], xmm11
00007cd93bdcef07  vmovaps [rsp+0xC0], xmm12
00007cd93bdcef10  vmovaps [rsp+0xD0], xmm13
00007cd93bdcef19  vmovaps [rsp+0xE0], xmm15
00007cd93bdcef22  sub rsp, 0x30
00007cd93bdcef26  movaps [rsp], xmm14
00007cd93bdcef2b  movaps [rsp+0x10], xmm1
00007cd93bdcef30  movaps [rsp+0x20], xmm15
00007cd93bdcef36  lea rdi, [rsp]
00007cd93bdcef3a  mov esi, 0x00
00007cd93bdcef3f  mov rax, 0x64A581057530
00007cd93bdcef49  call rax
00007cd93bdcef4b  movaps xmm14, [rsp]
00007cd93bdcef50  add rsp, 0x30
00007cd93bdcef54  vmovaps xmm0, [rsp]
00007cd93bdcef59  vmovaps xmm1, [rsp+0x10]
00007cd93bdcef5f  vmovaps xmm2, [rsp+0x20]
00007cd93bdcef65  vmovaps xmm3, [rsp+0x30]
00007cd93bdcef6b  vmovaps xmm4, [rsp+0x40]
00007cd93bdcef71  vmovaps xmm5, [rsp+0x50]
00007cd93bdcef77  vmovaps xmm6, [rsp+0x60]
00007cd93bdcef7d  vmovaps xmm7, [rsp+0x70]
00007cd93bdcef83  vmovaps xmm8, [rsp+0x80]
00007cd93bdcef8c  vmovaps xmm9, [rsp+0x90]
00007cd93bdcef95  vmovaps xmm10, [rsp+0xA0]
00007cd93bdcef9e  vmovaps xmm11, [rsp+0xB0]
00007cd93bdcefa7  vmovaps xmm12, [rsp+0xC0]
00007cd93bdcefb0  vmovaps xmm13, [rsp+0xD0]
00007cd93bdcefb9  vmovaps xmm15, [rsp+0xE0]
00007cd93bdcefc2  add rsp, 0xF0
00007cd93bdcefc9  pop r11
00007cd93bdcefcb  pop r10
00007cd93bdcefcd  pop r9
00007cd93bdcefcf  pop r8
00007cd93bdcefd1  pop rsi
00007cd93bdcefd2  pop rdi
00007cd93bdcefd3  pop rdx
00007cd93bdcefd4  pop rcx
00007cd93bdcefd5  pop rax
00007cd93bdcefd6  add rsp, 0x08
00007cd93bdcefda  jmp 0x00007CD93BDCECAE
00007cd93bdcefdf  call 0x00007CD93BCC34C0
00007cd93bdcefe4  jmp 0x00007CD93BDCECC4
00007cd93bdcefe9  int3
00007cd93bdcefea  nop [rax+rax*1], ax
00007cd93bdceff0  mov rax, [r15+0xF8]
00007cd93bdceff7  lea r14, [rax-0x150]
00007cd93bdceffe  mov [r15+0xF8], r14
00007cd93bdcf005  mov rax, [r15+0x50]
00007cd93bdcf009  lea r12, [rax+0x80]
00007cd93bdcf010  movups xmm1, [r13+r12*1]
00007cd93bdcf016  lea r12, [rax+0x90]
00007cd93bdcf01d  movups xmm15, [r13+r12*1]
00007cd93bdcf023  mov qword ptr [r15+0x48], 0x00
00007cd93bdcf02b  lea r12, [rax+0x40]
00007cd93bdcf02f  movups xmm14, [r13+r12*1]
00007cd93bdcf035  lea r12, [rax+0x50]
00007cd93bdcf039  movups xmm13, [r13+r12*1]
00007cd93bdcf03f  lea r12, [r14+0x120]
00007cd93bdcf046  movq xmm12, qword ptr [r15+0x1C0]
00007cd93bdcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007cd93bdcf058  movq r11, xmm12
00007cd93bdcf05d  movq r10, xmm11
00007cd93bdcf062  mov [r13+r12*1], r11
00007cd93bdcf067  lea r12, [r14+0x128]
00007cd93bdcf06e  mov [r13+r12*1], r10
00007cd93bdcf073  vxorps xmm12, xmm12, xmm12
00007cd93bdcf078  vpbroadcastq xmm12, xmm12
00007cd93bdcf07d  lea r12, [r14+0x100]
00007cd93bdcf084  movq xmm11, qword ptr [r15+0x200]
00007cd93bdcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007cd93bdcf096  movq r11, xmm11
00007cd93bdcf09b  movq r10, xmm10
00007cd93bdcf0a0  mov [r13+r12*1], r11
00007cd93bdcf0a5  lea r12, [r14+0x108]
00007cd93bdcf0ac  mov [r13+r12*1], r10
00007cd93bdcf0b1  lea r12, [r14+0xE0]
00007cd93bdcf0b8  movups [r13+r12*1], xmm15
00007cd93bdcf0be  lea r12, [r14+0xF0]
00007cd93bdcf0c5  movups [r13+r12*1], xmm1
00007cd93bdcf0cb  lea r12, [rax+0xC0]
00007cd93bdcf0d2  movups xmm1, [r13+r12*1]
00007cd93bdcf0d8  lea r12, [rax+0xD0]
00007cd93bdcf0df  movups xmm15, [r13+r12*1]
00007cd93bdcf0e5  lea r12, [r14+0x110]
00007cd93bdcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007cd93bdcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007cd93bdcf0fe  movq r11, xmm11
00007cd93bdcf103  movq r10, xmm10
00007cd93bdcf108  mov [r13+r12*1], r11
00007cd93bdcf10d  lea r12, [r14+0x118]
00007cd93bdcf114  mov [r13+r12*1], r10
00007cd93bdcf119  movups xmm11, [r13+rax*1]
00007cd93bdcf11f  lea r12, [rax+0x10]
00007cd93bdcf123  movups xmm10, [r13+r12*1]
00007cd93bdcf129  lea r12, [r14+0x130]
00007cd93bdcf130  movq xmm9, qword ptr [r15+0x1A0]
00007cd93bdcf139  movq xmm8, qword ptr [r15+0x190]
00007cd93bdcf142  movq r11, xmm9
00007cd93bdcf147  movq r10, xmm8
00007cd93bdcf14c  mov [r13+r12*1], r11
00007cd93bdcf151  lea r12, [r14+0x138]
00007cd93bdcf158  mov [r13+r12*1], r10
00007cd93bdcf15d  lea r12, [rax+0x140]
00007cd93bdcf164  movups xmm9, [r13+r12*1]
00007cd93bdcf16a  lea r12, [rax+0x150]
00007cd93bdcf171  movups xmm8, [r13+r12*1]
00007cd93bdcf177  lea r12, [r14+0xC0]
00007cd93bdcf17e  movups [r13+r12*1], xmm15
00007cd93bdcf184  lea r12, [r14+0xD0]
00007cd93bdcf18b  movups [r13+r12*1], xmm1
00007cd93bdcf191  lea r12, [rax+0x100]
00007cd93bdcf198  movups xmm1, [r13+r12*1]
00007cd93bdcf19e  lea r12, [rax+0x110]
00007cd93bdcf1a5  movups xmm15, [r13+r12*1]
00007cd93bdcf1ab  lea r12, [r14+0x140]
00007cd93bdcf1b2  mov r11, [r15+0xE8]
00007cd93bdcf1b9  mov [r13+r12*1], r11
00007cd93bdcf1be  lea r12, [rax+0x180]
00007cd93bdcf1c5  movups xmm7, [r13+r12*1]
00007cd93bdcf1cb  lea r12, [rax+0x190]
00007cd93bdcf1d2  movups xmm6, [r13+r12*1]
00007cd93bdcf1d8  lea r12, [rax+0x1C0]
00007cd93bdcf1df  movups xmm5, [r13+r12*1]
00007cd93bdcf1e5  lea r12, [rax+0x1D0]
00007cd93bdcf1ec  movups xmm4, [r13+r12*1]
00007cd93bdcf1f2  lea r12, [r14+0x20]
00007cd93bdcf1f6  movups [r13+r12*1], xmm1
00007cd93bdcf1fc  lea r12, [r14+0x30]
00007cd93bdcf200  movups [r13+r12*1], xmm13
00007cd93bdcf206  lea r12, [rax+0x60]
00007cd93bdcf20a  movups xmm1, [r13+r12*1]
00007cd93bdcf210  lea r12, [rax+0x70]
00007cd93bdcf214  movups xmm13, [r13+r12*1]
00007cd93bdcf21a  lea r12, [rax+0x20]
00007cd93bdcf21e  movups xmm3, [r13+r12*1]
00007cd93bdcf224  lea r12, [rax+0x30]
00007cd93bdcf228  movups xmm2, [r13+r12*1]
00007cd93bdcf22e  movaps [r15+0x1F0], xmm2
00007cd93bdcf236  lea r12, [r14+0x60]
00007cd93bdcf23a  movups [r13+r12*1], xmm11
00007cd93bdcf240  lea r12, [r14+0x70]
00007cd93bdcf244  movups [r13+r12*1], xmm5
00007cd93bdcf24a  lea r12, [rax+0xE0]
00007cd93bdcf251  movups xmm11, [r13+r12*1]
00007cd93bdcf257  lea r12, [rax+0xF0]
00007cd93bdcf25e  movups xmm5, [r13+r12*1]
00007cd93bdcf264  lea r12, [r14+0xA0]
00007cd93bdcf26b  movups [r13+r12*1], xmm13
00007cd93bdcf271  lea r12, [r14+0xB0]
00007cd93bdcf278  movups [r13+r12*1], xmm1
00007cd93bdcf27e  lea r12, [rax+0xA0]
00007cd93bdcf285  movups xmm1, [r13+r12*1]
00007cd93bdcf28b  lea r12, [rax+0xB0]
00007cd93bdcf292  movups xmm13, [r13+r12*1]
00007cd93bdcf298  lea r12, [rax+0x120]
00007cd93bdcf29f  vmovaps [rsp+0x10], xmm1
00007cd93bdcf2a5  movups xmm1, [r13+r12*1]
00007cd93bdcf2ab  lea r12, [rax+0x130]
00007cd93bdcf2b2  vmovaps [rsp+0x20], xmm1
00007cd93bdcf2b8  movups xmm1, [r13+r12*1]
00007cd93bdcf2be  lea r12, [rax+0x160]
00007cd93bdcf2c5  vmovaps [rsp+0x30], xmm1
00007cd93bdcf2cb  movups xmm1, [r13+r12*1]
00007cd93bdcf2d1  lea r12, [rax+0x170]
00007cd93bdcf2d8  vmovaps [rsp+0x40], xmm1
00007cd93bdcf2de  movups xmm1, [r13+r12*1]
00007cd93bdcf2e4  movaps [r15+0x2B0], xmm1
00007cd93bdcf2ec  lea r12, [r14+0x80]
00007cd93bdcf2f3  movups [r13+r12*1], xmm13
00007cd93bdcf2f9  lea r12, [r14+0x90]
00007cd93bdcf300  vmovaps xmm13, [rsp+0x10]
00007cd93bdcf306  movups [r13+r12*1], xmm13
00007cd93bdcf30c  lea r12, [rax+0x1A0]
00007cd93bdcf313  movups xmm13, [r13+r12*1]
00007cd93bdcf319  lea r12, [rax+0x1B0]
00007cd93bdcf320  vmovaps [rsp+0x10], xmm1
00007cd93bdcf326  movups xmm1, [r13+r12*1]
00007cd93bdcf32c  movaps [r15+0x290], xmm13
00007cd93bdcf334  movaps [r15+0x1E0], xmm1
00007cd93bdcf33c  lea r12, [rax+0x1E0]
00007cd93bdcf343  vmovaps [rsp+0x50], xmm1
00007cd93bdcf349  movups xmm1, [r13+r12*1]
00007cd93bdcf34f  lea r12, [rax+0x1F0]
00007cd93bdcf356  vmovaps [rsp+0x60], xmm1
00007cd93bdcf35c  movups xmm1, [r13+r12*1]
00007cd93bdcf362  mov qword ptr [r15+0x50], 0x430920
00007cd93bdcf36a  lea rax, [r14+0x40]
00007cd93bdcf36e  vmovaps [rsp+0x70], xmm1
00007cd93bdcf374  vmovaps xmm1, [rsp+0x40]
00007cd93bdcf37a  movups [r13+rax*1], xmm1
00007cd93bdcf380  lea rax, [r14+0x50]
00007cd93bdcf384  movups [r13+rax*1], xmm10
00007cd93bdcf38a  vmovaps xmm1, [rsp+0x70]
00007cd93bdcf390  movups [r13+r14*1], xmm1
00007cd93bdcf396  lea rax, [r14+0x10]
00007cd93bdcf39a  vmovaps xmm1, [rsp+0x60]
00007cd93bdcf3a0  movups [r13+rax*1], xmm1
00007cd93bdcf3a6  mov rax, [r15+0x40]
00007cd93bdcf3aa  vmovaps [rsp+0x40], xmm3
00007cd93bdcf3b0  vmovaps xmm1, [rsp+0x40]
00007cd93bdcf3b6  por xmm3, xmm1
00007cd93bdcf3ba  vmovaps [rsp+0x40], xmm6
00007cd93bdcf3c0  vmovaps xmm10, [rsp+0x40]
00007cd93bdcf3c6  por xmm6, xmm10
00007cd93bdcf3cb  lea r12, [rax+0x30]
00007cd93bdcf3cf  mov r11, [r13+r12*1]
00007cd93bdcf3d4  lea r12, [rax+0x38]
00007cd93bdcf3d8  mov r10, [r13+r12*1]
00007cd93bdcf3dd  movq xmm10, r11
00007cd93bdcf3e2  vmovaps [rsp+0x40], xmm1
00007cd93bdcf3e8  movq xmm1, r10
00007cd93bdcf3ed  movq xmm10, xmm10
00007cd93bdcf3f2  vmovaps [rsp+0x60], xmm10
00007cd93bdcf3f8  movq xmm10, xmm10
00007cd93bdcf3fd  movaps [r15+0x130], xmm10
00007cd93bdcf405  movq xmm1, xmm1
00007cd93bdcf409  vmovaps [rsp+0x70], xmm1
00007cd93bdcf40f  movq xmm1, xmm1
00007cd93bdcf413  movaps [r15+0x280], xmm1
00007cd93bdcf41b  vmovaps [rsp+0x80], xmm9
00007cd93bdcf424  vmovaps xmm1, [rsp+0x80]
00007cd93bdcf42d  por xmm9, xmm1
00007cd93bdcf432  lea r12, [rax+0x20]
00007cd93bdcf436  mov r11, [r13+r12*1]
00007cd93bdcf43b  lea r12, [rax+0x28]
00007cd93bdcf43f  mov r10, [r13+r12*1]
00007cd93bdcf444  movq xmm1, r11
00007cd93bdcf449  movq xmm10, r10
00007cd93bdcf44e  movq xmm1, xmm1
00007cd93bdcf452  vmovaps [rsp+0x80], xmm1
00007cd93bdcf45b  movq xmm1, xmm1
00007cd93bdcf45f  movaps [r15+0x150], xmm1
00007cd93bdcf467  movq xmm10, xmm10
00007cd93bdcf46c  vmovaps [rsp+0x90], xmm10
00007cd93bdcf475  movq xmm10, xmm10
00007cd93bdcf47a  movaps [r15+0x140], xmm10
00007cd93bdcf482  lea r12, [rax+0x10]
00007cd93bdcf486  mov r11, [r13+r12*1]
00007cd93bdcf48b  lea r12, [rax+0x18]
00007cd93bdcf48f  mov r10, [r13+r12*1]
00007cd93bdcf494  movq xmm1, r11
00007cd93bdcf499  movq xmm10, r10
00007cd93bdcf49e  movq xmm1, xmm1
00007cd93bdcf4a2  vmovaps [rsp+0xA0], xmm1
00007cd93bdcf4ab  movq xmm1, xmm1
00007cd93bdcf4af  movaps [r15+0x170], xmm1
00007cd93bdcf4b7  movq xmm10, xmm10
00007cd93bdcf4bc  vmovaps [rsp+0xB0], xmm10
00007cd93bdcf4c5  movq xmm10, xmm10
00007cd93bdcf4ca  movaps [r15+0x160], xmm10
00007cd93bdcf4d2  mov r12, [r13+rax*1]
00007cd93bdcf4d7  vmovq xmm1, r12
00007cd93bdcf4dc  vpbroadcastq xmm1, xmm1
00007cd93bdcf4e1  lea r12, [rax+0x08]
00007cd93bdcf4e5  mov rax, [r13+r12*1]
00007cd93bdcf4ea  movq xmm10, rax
00007cd93bdcf4ef  movaps [r15+0x230], xmm10
00007cd93bdcf4f7  lea rax, [r14+0x50]
00007cd93bdcf4fb  movups xmm10, [r13+rax*1]
00007cd93bdcf501  lea rax, [r14+0x60]
00007cd93bdcf505  vmovaps [rsp+0xC0], xmm1
00007cd93bdcf50e  movups xmm1, [r13+rax*1]
00007cd93bdcf514  lea rax, [r14+0x30]
00007cd93bdcf518  vmovaps [rsp+0xD0], xmm1
00007cd93bdcf521  movups xmm1, [r13+rax*1]
00007cd93bdcf527  mov qword ptr [r15+0x60], 0x430920
00007cd93bdcf52f  mov qword ptr [r15+0x58], 0x40
00007cd93bdcf537  vmovaps [rsp+0xE0], xmm1
00007cd93bdcf540  vmovaps [rsp+0xF0], xmm15
00007cd93bdcf549  vmovaps xmm15, [rsp+0xC0]
00007cd93bdcf552  vmovaps [rsp+0xC0], xmm14
00007cd93bdcf55b  vmovaps xmm14, [rsp+0x40]
00007cd93bdcf561  vmovaps [rsp+0x40], xmm13
00007cd93bdcf567  movaps xmm1, xmm15
00007cd93bdcf56b  mulpd xmm1, xmm14
00007cd93bdcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007cd93bdcf575  ptest xmm13, xmm13
00007cd93bdcf57b  jnz 0x00007CD93BDD0682
00007cd93bdcf581  movq xmm14, qword ptr [r15+0x230]
00007cd93bdcf58a  vmovaps [rsp+0x100], xmm14
00007cd93bdcf593  vpermilpd xmm14, xmm14, 0x00
00007cd93bdcf599  vmovaps [rsp+0x110], xmm1
00007cd93bdcf5a2  vmovaps xmm1, [rsp+0xE0]
00007cd93bdcf5ab  vmovaps [rsp+0xE0], xmm15
00007cd93bdcf5b4  movaps xmm13, xmm1
00007cd93bdcf5b8  mulpd xmm13, xmm14
00007cd93bdcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007cd93bdcf5c3  ptest xmm15, xmm15
00007cd93bdcf5c9  jnz 0x00007CD93BDD07C4
00007cd93bdcf5cf  vxorps xmm1, xmm1, xmm1
00007cd93bdcf5d3  vpbroadcastq xmm1, xmm1
00007cd93bdcf5d8  vmovaps xmm14, [rsp+0xE0]
00007cd93bdcf5e1  vmovaps [rsp+0xE0], xmm1
00007cd93bdcf5ea  vmovaps xmm1, [rsp+0xD0]
00007cd93bdcf5f3  vmovaps [rsp+0xD0], xmm13
00007cd93bdcf5fc  movaps xmm15, xmm14
00007cd93bdcf600  mulpd xmm15, xmm1
00007cd93bdcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007cd93bdcf60b  ptest xmm13, xmm13
00007cd93bdcf611  jnz 0x00007CD93BDD0907
00007cd93bdcf617  movaps xmm1, xmm14
00007cd93bdcf61b  mulpd xmm1, xmm10
00007cd93bdcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007cd93bdcf625  ptest xmm13, xmm13
00007cd93bdcf62b  jnz 0x00007CD93BDD0A4A
00007cd93bdcf631  movaps xmm13, xmm14
00007cd93bdcf635  mulpd xmm13, xmm2
00007cd93bdcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007cd93bdcf640  ptest xmm10, xmm10
00007cd93bdcf646  jnz 0x00007CD93BDD0B8C
00007cd93bdcf64c  vmovaps [rsp+0x120], xmm7
00007cd93bdcf655  vmovaps xmm14, [rsp+0x120]
00007cd93bdcf65e  por xmm7, xmm14
00007cd93bdcf663  vmovaps xmm14, [rsp+0xC0]
00007cd93bdcf66c  vmovaps xmm10, [rsp+0xC0]
00007cd93bdcf675  por xmm14, xmm10
00007cd93bdcf67a  vmovaps xmm2, [rsp+0x100]
00007cd93bdcf683  vpermilpd xmm2, xmm2, 0x00
00007cd93bdcf689  vmovaps [rsp+0xC0], xmm1
00007cd93bdcf692  vmovaps [rsp+0x120], xmm15
00007cd93bdcf69b  movaps xmm1, xmm10
00007cd93bdcf69f  mulpd xmm1, xmm2
00007cd93bdcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007cd93bdcf6a8  ptest xmm15, xmm15
00007cd93bdcf6ae  jnz 0x00007CD93BDD0CCF
00007cd93bdcf6b4  xor eax, eax
00007cd93bdcf6b6  mov r12d, 0x40
00007cd93bdcf6bc  mov r11d, 0x200
00007cd93bdcf6c2  cmp r12, r11
00007cd93bdcf6c5  cmc
00007cd93bdcf6c6  lahf
00007cd93bdcf6c7  seto al
00007cd93bdcf6ca  mov [r15+0x108], eax
00007cd93bdcf6d1  vmovaps xmm10, [rsp+0x110]
00007cd93bdcf6da  vmovaps xmm2, [rsp+0xE0]
00007cd93bdcf6e3  vmovaps [rsp+0xE0], xmm1
00007cd93bdcf6ec  movaps xmm15, xmm10
00007cd93bdcf6f0  addpd xmm15, xmm2
00007cd93bdcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bdcf6fb  ptest xmm1, xmm1
00007cd93bdcf700  jnz 0x00007CD93BDD0E10
00007cd93bdcf706  vmovaps xmm10, [rsp+0x120]
00007cd93bdcf70f  vmovaps [rsp+0x110], xmm15
00007cd93bdcf718  movaps xmm1, xmm10
00007cd93bdcf71c  addpd xmm1, xmm12
00007cd93bdcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007cd93bdcf726  ptest xmm15, xmm15
00007cd93bdcf72c  jnz 0x00007CD93BDD0F53
00007cd93bdcf732  vmovaps xmm10, [rsp+0xC0]
00007cd93bdcf73b  vmovaps [rsp+0xC0], xmm1
00007cd93bdcf744  movaps xmm15, xmm10
00007cd93bdcf748  addpd xmm15, xmm12
00007cd93bdcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bdcf753  ptest xmm1, xmm1
00007cd93bdcf758  jnz 0x00007CD93BDD1095
00007cd93bdcf75e  vmovaps xmm1, [rsp+0x30]
00007cd93bdcf764  vmovaps xmm12, [rsp+0x30]
00007cd93bdcf76a  por xmm1, xmm12
00007cd93bdcf76f  vmovaps xmm12, [rsp+0x20]
00007cd93bdcf775  vmovaps xmm10, [rsp+0x20]
00007cd93bdcf77b  por xmm12, xmm10
00007cd93bdcf780  vmovaps [rsp+0x20], xmm5
00007cd93bdcf786  vmovaps xmm10, [rsp+0x20]
00007cd93bdcf78c  por xmm5, xmm10
00007cd93bdcf791  vmovaps [rsp+0x20], xmm11
00007cd93bdcf797  vmovaps xmm10, [rsp+0x20]
00007cd93bdcf79d  por xmm11, xmm10
00007cd93bdcf7a2  vmovaps [rsp+0x20], xmm4
00007cd93bdcf7a8  vmovaps xmm10, [rsp+0x20]
00007cd93bdcf7ae  por xmm4, xmm10
00007cd93bdcf7b3  vmovaps [rsp+0x20], xmm8
00007cd93bdcf7b9  vmovaps xmm10, [rsp+0x20]
00007cd93bdcf7bf  por xmm8, xmm10
00007cd93bdcf7c4  vmovaps xmm10, [rsp+0xF0]
00007cd93bdcf7cd  vmovaps [rsp+0x20], xmm1
00007cd93bdcf7d3  vmovaps xmm1, [rsp+0xF0]
00007cd93bdcf7dc  por xmm10, xmm1
00007cd93bdcf7e1  lea rax, [r14+0xA0]
00007cd93bdcf7e8  movups xmm1, [r13+rax*1]
00007cd93bdcf7ee  lea rax, [r14+0xB0]
00007cd93bdcf7f5  vmovaps [rsp+0x30], xmm1
00007cd93bdcf7fb  movups xmm1, [r13+rax*1]
00007cd93bdcf801  vmovaps [rsp+0xF0], xmm1
00007cd93bdcf80a  vmovaps [rsp+0x120], xmm15
00007cd93bdcf813  movaps xmm1, xmm13
00007cd93bdcf817  addpd xmm1, xmm2
00007cd93bdcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007cd93bdcf820  ptest xmm15, xmm15
00007cd93bdcf826  jnz 0x00007CD93BDD11ED
00007cd93bdcf82c  lea rax, [r14+0xF0]
00007cd93bdcf833  movups xmm15, [r13+rax*1]
00007cd93bdcf839  vmovaps xmm2, [rsp+0xC0]
00007cd93bdcf842  vmovaps [rsp+0xC0], xmm1
00007cd93bdcf84b  vmovaps xmm1, [rsp+0xE0]
00007cd93bdcf854  vmovaps [rsp+0xE0], xmm15
00007cd93bdcf85d  movaps xmm13, xmm2
00007cd93bdcf861  addpd xmm13, xmm1
00007cd93bdcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007cd93bdcf86c  ptest xmm15, xmm15
00007cd93bdcf872  jnz 0x00007CD93BDD1338
00007cd93bdcf878  vmovaps xmm15, [rsp+0x120]
00007cd93bdcf881  vmovaps xmm2, [rsp+0xD0]
00007cd93bdcf88a  vmovaps [rsp+0xD0], xmm14
00007cd93bdcf893  movaps xmm1, xmm15
00007cd93bdcf897  addpd xmm1, xmm2
00007cd93bdcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007cd93bdcf8a0  ptest xmm14, xmm14
00007cd93bdcf8a6  jnz 0x00007CD93BDD147A
00007cd93bdcf8ac  vmovaps xmm15, [rsp+0x100]
00007cd93bdcf8b5  vpermilpd xmm15, xmm15, 0x00
00007cd93bdcf8bb  vmovaps xmm2, [rsp+0xF0]
00007cd93bdcf8c4  vmovaps [rsp+0xF0], xmm1
00007cd93bdcf8cd  movaps xmm14, xmm2
00007cd93bdcf8d1  mulpd xmm14, xmm15
00007cd93bdcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007cd93bdcf8dc  ptest xmm1, xmm1
00007cd93bdcf8e1  jnz 0x00007CD93BDD15BB
00007cd93bdcf8e7  vmovaps xmm1, [rsp+0xA0]
00007cd93bdcf8f0  vpermilpd xmm1, xmm1, 0x00
00007cd93bdcf8f6  vmovaps xmm2, [rsp+0xE0]
00007cd93bdcf8ff  vmovaps [rsp+0xE0], xmm14
00007cd93bdcf908  movaps xmm15, xmm2
00007cd93bdcf90c  mulpd xmm15, xmm1
00007cd93bdcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007cd93bdcf917  ptest xmm14, xmm14
00007cd93bdcf91d  jnz 0x00007CD93BDD16FE
00007cd93bdcf923  lea rax, [r14+0xE0]
00007cd93bdcf92a  movups xmm1, [r13+rax*1]
00007cd93bdcf930  vmovaps xmm14, [rsp+0x100]
00007cd93bdcf939  vpermilpd xmm14, xmm14, 0x00
00007cd93bdcf93f  vmovaps [rsp+0x100], xmm1
00007cd93bdcf948  vmovaps xmm1, [rsp+0x30]
00007cd93bdcf94e  vmovaps [rsp+0x30], xmm15
00007cd93bdcf954  movaps xmm2, xmm1
00007cd93bdcf957  mulpd xmm2, xmm14
00007cd93bdcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007cd93bdcf961  ptest xmm15, xmm15
00007cd93bdcf967  jnz 0x00007CD93BDD184A
00007cd93bdcf96d  vmovaps [rsp+0x120], xmm10
00007cd93bdcf976  vmovaps xmm1, [rsp+0x120]
00007cd93bdcf97f  por xmm10, xmm1
00007cd93bdcf984  movaps [r15+0x300], xmm10
00007cd93bdcf98c  vmovaps [rsp+0x120], xmm8
00007cd93bdcf995  vmovaps xmm1, [rsp+0x120]
00007cd93bdcf99e  por xmm8, xmm1
00007cd93bdcf9a3  movaps [r15+0x190], xmm8
00007cd93bdcf9ab  vmovaps xmm1, [rsp+0xA0]
00007cd93bdcf9b4  vpermilpd xmm1, xmm1, 0x00
00007cd93bdcf9ba  vmovaps xmm14, [rsp+0x100]
00007cd93bdcf9c3  vmovaps [rsp+0x100], xmm13
00007cd93bdcf9cc  movaps xmm15, xmm14
00007cd93bdcf9d0  mulpd xmm15, xmm1
00007cd93bdcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007cd93bdcf9db  ptest xmm13, xmm13
00007cd93bdcf9e1  jnz 0x00007CD93BDD198B
00007cd93bdcf9e7  lea rax, [r14+0x90]
00007cd93bdcf9ee  movups xmm1, [r13+rax*1]
00007cd93bdcf9f4  vmovaps [rsp+0x120], xmm4
00007cd93bdcf9fd  vmovaps xmm14, [rsp+0x120]
00007cd93bdcfa06  por xmm4, xmm14
00007cd93bdcfa0b  movaps [r15+0x1C0], xmm4
00007cd93bdcfa13  vmovaps [rsp+0x120], xmm11
00007cd93bdcfa1c  vmovaps xmm14, [rsp+0x120]
00007cd93bdcfa25  por xmm11, xmm14
00007cd93bdcfa2a  movaps [r15+0x200], xmm11
00007cd93bdcfa32  vmovaps [rsp+0x120], xmm5
00007cd93bdcfa3b  vmovaps xmm14, [rsp+0x120]
00007cd93bdcfa44  por xmm5, xmm14
00007cd93bdcfa49  movaps [r15+0x2D0], xmm5
00007cd93bdcfa51  vmovaps [rsp+0x120], xmm12
00007cd93bdcfa5a  vmovaps xmm14, [rsp+0x120]
00007cd93bdcfa63  por xmm12, xmm14
00007cd93bdcfa68  movaps [r15+0x2E0], xmm12
00007cd93bdcfa70  vmovaps xmm13, [rsp+0x110]
00007cd93bdcfa79  vmovaps [rsp+0x110], xmm1
00007cd93bdcfa82  vmovaps xmm1, [rsp+0xE0]
00007cd93bdcfa8b  vmovaps [rsp+0xE0], xmm15
00007cd93bdcfa94  movaps xmm14, xmm13
00007cd93bdcfa98  addpd xmm14, xmm1
00007cd93bdcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007cd93bdcfaa3  ptest xmm15, xmm15
00007cd93bdcfaa9  jnz 0x00007CD93BDD1AD8
00007cd93bdcfaaf  vmovaps xmm1, [rsp+0xA0]
00007cd93bdcfab8  vpermilpd xmm1, xmm1, 0x00
00007cd93bdcfabe  vmovaps xmm13, [rsp+0x110]
00007cd93bdcfac7  vmovaps [rsp+0x110], xmm14
00007cd93bdcfad0  movaps xmm15, xmm13
00007cd93bdcfad4  mulpd xmm15, xmm1
00007cd93bdcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007cd93bdcfadf  ptest xmm14, xmm14
00007cd93bdcfae5  jnz 0x00007CD93BDD1C1B
00007cd93bdcfaeb  lea rax, [r14+0x80]
00007cd93bdcfaf2  movups xmm1, [r13+rax*1]
00007cd93bdcfaf8  vmovaps xmm13, [rsp+0xC0]
00007cd93bdcfb01  vmovaps [rsp+0xC0], xmm1
00007cd93bdcfb0a  movaps xmm14, xmm13
00007cd93bdcfb0e  addpd xmm14, xmm2
00007cd93bdcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007cd93bdcfb19  ptest xmm1, xmm1
00007cd93bdcfb1e  jnz 0x00007CD93BDD1D68
00007cd93bdcfb24  vmovaps xmm13, [rsp+0x100]
00007cd93bdcfb2d  vmovaps xmm2, [rsp+0x30]
00007cd93bdcfb33  vmovaps [rsp+0x30], xmm15
00007cd93bdcfb39  movaps xmm1, xmm13
00007cd93bdcfb3d  addpd xmm1, xmm2
00007cd93bdcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007cd93bdcfb46  ptest xmm15, xmm15
00007cd93bdcfb4c  jnz 0x00007CD93BDD1EAB
00007cd93bdcfb52  vmovaps xmm15, [rsp+0x20]
00007cd93bdcfb58  vmovaps xmm13, [rsp+0x20]
00007cd93bdcfb5e  por xmm15, xmm13
00007cd93bdcfb63  movaps [r15+0x2F0], xmm15
00007cd93bdcfb6b  vmovaps xmm13, [rsp+0xA0]
00007cd93bdcfb74  vpermilpd xmm13, xmm13, 0x00
00007cd93bdcfb7a  vmovaps [rsp+0x20], xmm1
00007cd93bdcfb80  vmovaps xmm1, [rsp+0xC0]
00007cd93bdcfb89  vmovaps [rsp+0xA0], xmm15
00007cd93bdcfb92  movaps xmm2, xmm1
00007cd93bdcfb95  mulpd xmm2, xmm13
00007cd93bdcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007cd93bdcfb9f  ptest xmm15, xmm15
00007cd93bdcfba5  jnz 0x00007CD93BDD1FEC
00007cd93bdcfbab  lea rax, [r14+0xD0]
00007cd93bdcfbb2  movups xmm1, [r13+rax*1]
00007cd93bdcfbb8  vmovaps xmm13, [rsp+0xF0]
00007cd93bdcfbc1  vmovaps [rsp+0xC0], xmm1
00007cd93bdcfbca  vmovaps xmm1, [rsp+0xE0]
00007cd93bdcfbd3  vmovaps [rsp+0xE0], xmm14
00007cd93bdcfbdc  movaps xmm15, xmm13
00007cd93bdcfbe0  addpd xmm15, xmm1
00007cd93bdcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007cd93bdcfbeb  ptest xmm14, xmm14
00007cd93bdcfbf1  jnz 0x00007CD93BDD2137
00007cd93bdcfbf7  vmovaps xmm1, [rsp+0xB0]
00007cd93bdcfc00  vpermilpd xmm1, xmm1, 0x00
00007cd93bdcfc06  movaps xmm14, xmm11
00007cd93bdcfc0a  mulpd xmm14, xmm1
00007cd93bdcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007cd93bdcfc15  ptest xmm13, xmm13
00007cd93bdcfc1b  jnz 0x00007CD93BDD227A
00007cd93bdcfc21  movaps [r15+0x260], xmm14
00007cd93bdcfc29  vxorps xmm1, xmm1, xmm1
00007cd93bdcfc2d  vpbroadcastq xmm1, xmm1
00007cd93bdcfc32  movaps [r15+0x1B0], xmm1
00007cd93bdcfc3a  vmovaps xmm1, [rsp+0xB0]
00007cd93bdcfc43  vpermilpd xmm1, xmm1, 0x00
00007cd93bdcfc49  vmovaps xmm11, [rsp+0xC0]
00007cd93bdcfc52  vmovaps [rsp+0xC0], xmm15
00007cd93bdcfc5b  movaps xmm13, xmm11
00007cd93bdcfc5f  mulpd xmm13, xmm1
00007cd93bdcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007cd93bdcfc6a  ptest xmm15, xmm15
00007cd93bdcfc70  jnz 0x00007CD93BDD23BD
00007cd93bdcfc76  lea rax, [r14+0xC0]
00007cd93bdcfc7d  movups xmm1, [r13+rax*1]
00007cd93bdcfc83  vmovaps xmm11, [rsp+0x110]
00007cd93bdcfc8c  vmovaps [rsp+0xF0], xmm1
00007cd93bdcfc95  vmovaps xmm1, [rsp+0x30]
00007cd93bdcfc9b  vmovaps [rsp+0x30], xmm14
00007cd93bdcfca1  movaps xmm15, xmm11
00007cd93bdcfca5  addpd xmm15, xmm1
00007cd93bdcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007cd93bdcfcb0  ptest xmm14, xmm14
00007cd93bdcfcb6  jnz 0x00007CD93BDD250A
00007cd93bdcfcbc  vmovaps [rsp+0x100], xmm9
00007cd93bdcfcc5  vmovaps xmm1, [rsp+0x100]
00007cd93bdcfcce  por xmm9, xmm1
00007cd93bdcfcd3  movaps [r15+0x270], xmm9
00007cd93bdcfcdb  vmovaps [rsp+0x100], xmm6
00007cd93bdcfce4  vmovaps xmm1, [rsp+0x100]
00007cd93bdcfced  por xmm6, xmm1
00007cd93bdcfcf1  movaps [r15+0x1A0], xmm6
00007cd93bdcfcf9  vmovaps xmm14, [rsp+0xB0]
00007cd93bdcfd02  vpermilpd xmm14, xmm14, 0x00
00007cd93bdcfd08  vmovaps xmm6, [rsp+0xF0]
00007cd93bdcfd11  vmovaps [rsp+0xF0], xmm1
00007cd93bdcfd1a  movaps xmm11, xmm6
00007cd93bdcfd1e  mulpd xmm11, xmm14
00007cd93bdcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007cd93bdcfd29  ptest xmm1, xmm1
00007cd93bdcfd2e  jnz 0x00007CD93BDD264D
00007cd93bdcfd34  lea rax, [r14+0x20]
00007cd93bdcfd38  movups xmm1, [r13+rax*1]
00007cd93bdcfd3e  movaps [r15+0x110], xmm1
00007cd93bdcfd46  vmovaps xmm6, [rsp+0xE0]
00007cd93bdcfd4f  vmovaps [rsp+0xE0], xmm1
00007cd93bdcfd58  movaps xmm14, xmm6
00007cd93bdcfd5c  addpd xmm14, xmm2
00007cd93bdcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007cd93bdcfd67  ptest xmm1, xmm1
00007cd93bdcfd6c  jnz 0x00007CD93BDD279A
00007cd93bdcfd72  vmovaps xmm1, [rsp+0xB0]
00007cd93bdcfd7b  vpermilpd xmm1, xmm1, 0x00
00007cd93bdcfd81  movaps xmm6, xmm5
00007cd93bdcfd84  mulpd xmm6, xmm1
00007cd93bdcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007cd93bdcfd8d  ptest xmm2, xmm2
00007cd93bdcfd92  jnz 0x00007CD93BDD28DC
00007cd93bdcfd98  vmovaps xmm5, [rsp+0x20]
00007cd93bdcfd9e  movaps xmm1, xmm5
00007cd93bdcfda1  addpd xmm1, xmm13
00007cd93bdcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007cd93bdcfdab  ptest xmm2, xmm2
00007cd93bdcfdb0  jnz 0x00007CD93BDD2A1C
00007cd93bdcfdb6  vmovaps xmm13, [rsp+0x80]
00007cd93bdcfdbf  vpermilpd xmm13, xmm13, 0x00
00007cd93bdcfdc5  vmovaps xmm2, [rsp+0xE0]
00007cd93bdcfdce  vmovaps [rsp+0x20], xmm1
00007cd93bdcfdd4  movaps xmm5, xmm2
00007cd93bdcfdd7  mulpd xmm5, xmm13
00007cd93bdcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007cd93bdcfde1  ptest xmm1, xmm1
00007cd93bdcfde6  jnz 0x00007CD93BDD2B5D
00007cd93bdcfdec  vmovaps xmm1, [rsp+0x80]
00007cd93bdcfdf5  vpermilpd xmm1, xmm1, 0x00
00007cd93bdcfdfb  movaps xmm13, xmm10
00007cd93bdcfdff  mulpd xmm13, xmm1
00007cd93bdcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007cd93bdcfe0a  ptest xmm2, xmm2
00007cd93bdcfe0f  jnz 0x00007CD93BDD2C9E
00007cd93bdcfe15  vmovaps xmm10, [rsp+0x30]
00007cd93bdcfe1b  movaps xmm1, xmm15
00007cd93bdcfe1f  addpd xmm1, xmm10
00007cd93bdcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007cd93bdcfe29  ptest xmm2, xmm2
00007cd93bdcfe2e  jnz 0x00007CD93BDD2DE1
00007cd93bdcfe34  vmovaps xmm10, [rsp+0xC0]
00007cd93bdcfe3d  movaps xmm15, xmm10
00007cd93bdcfe41  addpd xmm15, xmm11
00007cd93bdcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007cd93bdcfe4c  ptest xmm2, xmm2
00007cd93bdcfe51  jnz 0x00007CD93BDD2F23
00007cd93bdcfe57  vmovaps xmm11, [rsp+0x80]
00007cd93bdcfe60  vpermilpd xmm11, xmm11, 0x00
00007cd93bdcfe66  movaps xmm10, xmm12
00007cd93bdcfe6a  mulpd xmm10, xmm11
00007cd93bdcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007cd93bdcfe75  ptest xmm2, xmm2
00007cd93bdcfe7a  jnz 0x00007CD93BDD3067
00007cd93bdcfe80  vmovaps xmm12, [rsp+0x80]
00007cd93bdcfe89  vpermilpd xmm12, xmm12, 0x00
00007cd93bdcfe8f  vmovaps xmm2, [rsp+0xA0]
00007cd93bdcfe98  vmovaps [rsp+0x30], xmm1
00007cd93bdcfe9e  movaps xmm11, xmm2
00007cd93bdcfea2  mulpd xmm11, xmm12
00007cd93bdcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007cd93bdcfead  ptest xmm1, xmm1
00007cd93bdcfeb2  jnz 0x00007CD93BDD31AB
00007cd93bdcfeb8  movaps xmm1, xmm14
00007cd93bdcfebc  addpd xmm1, xmm6
00007cd93bdcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007cd93bdcfec5  ptest xmm12, xmm12
00007cd93bdcfecb  jnz 0x00007CD93BDD32EE
00007cd93bdcfed1  vmovaps xmm12, [rsp+0x20]
00007cd93bdcfed7  movaps xmm14, xmm12
00007cd93bdcfedb  addpd xmm14, xmm5
00007cd93bdcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007cd93bdcfee6  ptest xmm6, xmm6
00007cd93bdcfeeb  jnz 0x00007CD93BDD342F
00007cd93bdcfef1  vmovaps xmm12, [rsp+0x90]
00007cd93bdcfefa  vpermilpd xmm12, xmm12, 0x00
00007cd93bdcff00  movaps xmm6, xmm9
00007cd93bdcff04  mulpd xmm6, xmm12
00007cd93bdcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007cd93bdcff0e  ptest xmm5, xmm5
00007cd93bdcff13  jnz 0x00007CD93BDD3572
00007cd93bdcff19  movaps xmm12, xmm15
00007cd93bdcff1d  addpd xmm12, xmm13
00007cd93bdcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007cd93bdcff28  ptest xmm9, xmm9
00007cd93bdcff2e  jnz 0x00007CD93BDD36B4
00007cd93bdcff34  vmovaps xmm13, [rsp+0x30]
00007cd93bdcff3a  movaps xmm15, xmm13
00007cd93bdcff3e  addpd xmm15, xmm10
00007cd93bdcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007cd93bdcff49  ptest xmm9, xmm9
00007cd93bdcff4f  jnz 0x00007CD93BDD37F8
00007cd93bdcff55  vmovaps xmm13, [rsp+0xD0]
00007cd93bdcff5e  vmovaps xmm10, [rsp+0xD0]
00007cd93bdcff67  por xmm13, xmm10
00007cd93bdcff6c  movaps [r15+0x250], xmm13
00007cd93bdcff74  vmovaps [rsp+0x20], xmm7
00007cd93bdcff7a  vmovaps xmm13, [rsp+0x20]
00007cd93bdcff80  por xmm7, xmm13
00007cd93bdcff85  movaps [r15+0x2A0], xmm7
00007cd93bdcff8d  vmovaps [rsp+0x20], xmm3
00007cd93bdcff93  vmovaps xmm13, [rsp+0x20]
00007cd93bdcff99  por xmm3, xmm13
00007cd93bdcff9e  movaps [r15+0x1D0], xmm3
00007cd93bdcffa6  lea rax, [r14+0x40]
00007cd93bdcffaa  movups xmm13, [r13+rax*1]
00007cd93bdcffb0  movaps [r15+0x2C0], xmm13
00007cd93bdcffb8  vmovaps xmm10, [rsp+0x90]
00007cd93bdcffc1  vpermilpd xmm10, xmm10, 0x00
00007cd93bdcffc7  movaps xmm9, xmm8
00007cd93bdcffcb  mulpd xmm9, xmm10
00007cd93bdcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007cd93bdcffd6  ptest xmm5, xmm5
00007cd93bdcffdb  jnz 0x00007CD93BDD3946
00007cd93bdcffe1  movaps xmm10, xmm1
00007cd93bdcffe5  addpd xmm10, xmm11
00007cd93bdcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007cd93bdcfff0  ptest xmm8, xmm8
00007cd93bdcfff6  jnz 0x00007CD93BDD3A8A
00007cd93bdcfffc  movaps xmm1, xmm14
00007cd93bdd0000  addpd xmm1, xmm6
00007cd93bdd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007cd93bdd0009  ptest xmm11, xmm11
00007cd93bdd000f  jnz 0x00007CD93BDD3BCD
00007cd93bdd0015  vmovaps xmm14, [rsp+0x90]
00007cd93bdd001e  vpermilpd xmm14, xmm14, 0x00
00007cd93bdd0024  movaps xmm11, xmm13
00007cd93bdd0028  mulpd xmm11, xmm14
00007cd93bdd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007cd93bdd0033  ptest xmm8, xmm8
00007cd93bdd0039  jnz 0x00007CD93BDD3D0E
00007cd93bdd003f  vmovaps xmm14, [rsp+0x90]
00007cd93bdd0048  vpermilpd xmm14, xmm14, 0x00
00007cd93bdd004e  vmovaps xmm8, [rsp+0x10]
00007cd93bdd0054  movaps xmm13, xmm8
00007cd93bdd0058  mulpd xmm13, xmm14
00007cd93bdd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007cd93bdd0063  ptest xmm6, xmm6
00007cd93bdd0068  jnz 0x00007CD93BDD3E52
00007cd93bdd006e  vmovaps xmm14, [rsp+0x60]
00007cd93bdd0074  vpermilpd xmm14, xmm14, 0x00
00007cd93bdd007a  movaps xmm8, xmm7
00007cd93bdd007e  mulpd xmm8, xmm14
00007cd93bdd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007cd93bdd0089  ptest xmm6, xmm6
00007cd93bdd008e  jnz 0x00007CD93BDD3F96
00007cd93bdd0094  movaps xmm14, xmm12
00007cd93bdd0098  addpd xmm14, xmm9
00007cd93bdd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007cd93bdd00a3  ptest xmm7, xmm7
00007cd93bdd00a8  jnz 0x00007CD93BDD40D9
00007cd93bdd00ae  vmovaps xmm12, [rsp+0x60]
00007cd93bdd00b4  vpermilpd xmm12, xmm12, 0x00
00007cd93bdd00ba  vmovaps xmm7, [rsp+0xF0]
00007cd93bdd00c3  movaps xmm9, xmm7
00007cd93bdd00c7  mulpd xmm9, xmm12
00007cd93bdd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007cd93bdd00d2  ptest xmm6, xmm6
00007cd93bdd00d7  jnz 0x00007CD93BDD421D
00007cd93bdd00dd  movaps xmm12, xmm15
00007cd93bdd00e1  addpd xmm12, xmm11
00007cd93bdd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007cd93bdd00ec  ptest xmm7, xmm7
00007cd93bdd00f1  jnz 0x00007CD93BDD4360
00007cd93bdd00f7  vmovaps xmm15, [rsp+0x60]
00007cd93bdd00fd  vpermilpd xmm15, xmm15, 0x00
00007cd93bdd0103  vmovaps xmm7, [rsp+0x40]
00007cd93bdd0109  movaps xmm11, xmm7
00007cd93bdd010d  mulpd xmm11, xmm15
00007cd93bdd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007cd93bdd0118  ptest xmm6, xmm6
00007cd93bdd011d  jnz 0x00007CD93BDD44A4
00007cd93bdd0123  movaps xmm15, xmm10
00007cd93bdd0127  addpd xmm15, xmm13
00007cd93bdd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007cd93bdd0132  ptest xmm7, xmm7
00007cd93bdd0137  jnz 0x00007CD93BDD45E7
00007cd93bdd013d  vmovaps xmm13, [rsp+0x60]
00007cd93bdd0143  vpermilpd xmm13, xmm13, 0x00
00007cd93bdd0149  vmovaps xmm7, [rsp+0x50]
00007cd93bdd014f  movaps xmm10, xmm7
00007cd93bdd0153  mulpd xmm10, xmm13
00007cd93bdd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007cd93bdd015e  ptest xmm6, xmm6
00007cd93bdd0163  jnz 0x00007CD93BDD472B
00007cd93bdd0169  movaps xmm13, xmm1
00007cd93bdd016d  addpd xmm13, xmm8
00007cd93bdd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007cd93bdd0178  ptest xmm7, xmm7
00007cd93bdd017d  jnz 0x00007CD93BDD486E
00007cd93bdd0183  lea rax, [r14+0x70]
00007cd93bdd0187  movups xmm1, [r13+rax*1]
00007cd93bdd018d  movaps [r15+0x240], xmm1
00007cd93bdd0195  movaps xmm8, xmm14
00007cd93bdd0199  addpd xmm8, xmm9
00007cd93bdd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007cd93bdd01a4  ptest xmm7, xmm7
00007cd93bdd01a9  jnz 0x00007CD93BDD49BB
00007cd93bdd01af  movaps [r15+0x170], xmm8
00007cd93bdd01b7  vmovaps xmm14, [rsp+0x70]
00007cd93bdd01bd  vpermilpd xmm14, xmm14, 0x00
00007cd93bdd01c3  movaps xmm9, xmm1
00007cd93bdd01c7  mulpd xmm9, xmm14
00007cd93bdd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007cd93bdd01d2  ptest xmm7, xmm7
00007cd93bdd01d7  jnz 0x00007CD93BDD4AFF
00007cd93bdd01dd  vmovaps xmm1, [rsp+0x70]
00007cd93bdd01e3  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd01e9  movaps xmm14, xmm4
00007cd93bdd01ed  mulpd xmm14, xmm1
00007cd93bdd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007cd93bdd01f8  ptest xmm7, xmm7
00007cd93bdd01fd  jnz 0x00007CD93BDD4C42
00007cd93bdd0203  movaps [r15+0x180], xmm14
00007cd93bdd020b  movaps xmm1, xmm12
00007cd93bdd020f  addpd xmm1, xmm11
00007cd93bdd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007cd93bdd0219  ptest xmm7, xmm7
00007cd93bdd021e  jnz 0x00007CD93BDD4D84
00007cd93bdd0224  movaps [r15+0x210], xmm1
00007cd93bdd022c  movups xmm12, [r13+r14*1]
00007cd93bdd0232  lea rax, [r14+0x10]
00007cd93bdd0236  movups xmm11, [r13+rax*1]
00007cd93bdd023c  movaps [r15+0x230], xmm11
00007cd93bdd0244  movaps xmm7, xmm15
00007cd93bdd0248  addpd xmm7, xmm10
00007cd93bdd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007cd93bdd0252  ptest xmm6, xmm6
00007cd93bdd0257  jnz 0x00007CD93BDD4EDA
00007cd93bdd025d  movaps [r15+0x130], xmm7
00007cd93bdd0265  vmovaps xmm15, [rsp+0x70]
00007cd93bdd026b  vpermilpd xmm15, xmm15, 0x00
00007cd93bdd0271  movaps xmm10, xmm11
00007cd93bdd0275  mulpd xmm10, xmm15
00007cd93bdd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007cd93bdd0280  ptest xmm6, xmm6
00007cd93bdd0285  jnz 0x00007CD93BDD501C
00007cd93bdd028b  movaps [r15+0x220], xmm10
00007cd93bdd0293  vmovaps xmm15, [rsp+0x70]
00007cd93bdd0299  vpermilpd xmm15, xmm15, 0x00
00007cd93bdd029f  movaps xmm11, xmm12
00007cd93bdd02a3  mulpd xmm11, xmm15
00007cd93bdd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007cd93bdd02ae  ptest xmm6, xmm6
00007cd93bdd02b3  jnz 0x00007CD93BDD5160
00007cd93bdd02b9  movaps xmm15, xmm13
00007cd93bdd02bd  addpd xmm15, xmm9
00007cd93bdd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007cd93bdd02c8  ptest xmm12, xmm12
00007cd93bdd02ce  jnz 0x00007CD93BDD52A4
00007cd93bdd02d4  movaps [r15+0x140], xmm15
00007cd93bdd02dc  movaps xmm13, xmm8
00007cd93bdd02e0  addpd xmm13, xmm14
00007cd93bdd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007cd93bdd02eb  ptest xmm12, xmm12
00007cd93bdd02f1  jnz 0x00007CD93BDD53E8
00007cd93bdd02f7  movaps [r15+0x150], xmm13
00007cd93bdd02ff  movaps xmm14, xmm1
00007cd93bdd0303  addpd xmm14, xmm10
00007cd93bdd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007cd93bdd030e  ptest xmm12, xmm12
00007cd93bdd0314  jnz 0x00007CD93BDD552C
00007cd93bdd031a  movaps [r15+0x160], xmm14
00007cd93bdd0322  movaps xmm1, xmm7
00007cd93bdd0325  addpd xmm1, xmm11
00007cd93bdd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007cd93bdd032f  ptest xmm12, xmm12
00007cd93bdd0335  jnz 0x00007CD93BDD566F
00007cd93bdd033b  movaps [r15+0x120], xmm1
00007cd93bdd0343  mov eax, 0x430920
00007cd93bdd0348  movups [r13+rax*1], xmm15
00007cd93bdd034e  mov eax, 0x430930
00007cd93bdd0353  movups [r13+rax*1], xmm13
00007cd93bdd0359  mov eax, 0x430940
00007cd93bdd035e  movups [r13+rax*1], xmm14
00007cd93bdd0364  mov eax, 0x430950
00007cd93bdd0369  movups [r13+rax*1], xmm1
00007cd93bdd036f  mov eax, [r15+0x108]
00007cd93bdd0376  sahf
00007cd93bdd0377  jnz 0x00007CD93BDD03A9
00007cd93bdd0379  cmp dword ptr [r15+0x318], 0x00
00007cd93bdd0381  jz 0x00007CD93BDDB900
00007cd93bdd0387  nop [rax+rax*1], ax
00007cd93bdd0390  nop [rax+rax*1], eax
00007cd93bdd0398  mov eax, 0x410444
00007cd93bdd039d  mov [r15+0x100], rax
00007cd93bdd03a4  jmp 0x00007CD93BBFE110
00007cd93bdd03a9  cmp dword ptr [r15+0x318], 0x00
00007cd93bdd03b1  jz 0x00007CD93BDD57E0
00007cd93bdd03b7  nop [rax+rax*1], ax
00007cd93bdd03c0  nop [rax+rax*1], eax
00007cd93bdd03c8  mov eax, 0x410278
00007cd93bdd03cd  mov [r15+0x100], rax
00007cd93bdd03d4  jmp 0x00007CD93BBFE110
00007cd93bdd03d9  int3
00007cd93bdd03da  call 0x00007CD93BCB52F0
00007cd93bdd03df  jmp 0x00007CD93BDCF016
00007cd93bdd03e4  call 0x00007CD93BCC4620
00007cd93bdd03e9  jmp 0x00007CD93BDCF023
00007cd93bdd03ee  call 0x00007CD93BCC33A0
00007cd93bdd03f3  jmp 0x00007CD93BDCF035
00007cd93bdd03f8  call 0x00007CD93BCC2120
00007cd93bdd03fd  jmp 0x00007CD93BDCF03F
00007cd93bdd0402  call 0x00007CD93BCC0860
00007cd93bdd0407  jmp 0x00007CD93BDCF067
00007cd93bdd040c  call 0x00007CD93BCBF5F0
00007cd93bdd0411  jmp 0x00007CD93BDCF073
00007cd93bdd0416  call 0x00007CD93BCC0860
00007cd93bdd041b  jmp 0x00007CD93BDCF0A5
00007cd93bdd0420  call 0x00007CD93BCBF5F0
00007cd93bdd0425  jmp 0x00007CD93BDCF0B1
00007cd93bdd042a  call 0x00007CD93BCC4740
00007cd93bdd042f  jmp 0x00007CD93BDCF0BE
00007cd93bdd0434  call 0x00007CD93BCB5400
00007cd93bdd0439  jmp 0x00007CD93BDCF0CB
00007cd93bdd043e  call 0x00007CD93BCB52F0
00007cd93bdd0443  jmp 0x00007CD93BDCF0D8
00007cd93bdd0448  call 0x00007CD93BCC4620
00007cd93bdd044d  jmp 0x00007CD93BDCF0E5
00007cd93bdd0452  call 0x00007CD93BCC0860
00007cd93bdd0457  jmp 0x00007CD93BDCF10D
00007cd93bdd045c  call 0x00007CD93BCBF5F0
00007cd93bdd0461  jmp 0x00007CD93BDCF119
00007cd93bdd0466  call 0x00007CD93BC09D70
00007cd93bdd046b  jmp 0x00007CD93BDCF11F
00007cd93bdd0470  call 0x00007CD93BCBE9C0
00007cd93bdd0475  jmp 0x00007CD93BDCF129
00007cd93bdd047a  call 0x00007CD93BCC0860
00007cd93bdd047f  jmp 0x00007CD93BDCF151
00007cd93bdd0484  call 0x00007CD93BCBF5F0
00007cd93bdd0489  jmp 0x00007CD93BDCF15D
00007cd93bdd048e  call 0x00007CD93BCBD750
00007cd93bdd0493  jmp 0x00007CD93BDCF16A
00007cd93bdd0498  call 0x00007CD93BCBC4E0
00007cd93bdd049d  jmp 0x00007CD93BDCF177
00007cd93bdd04a2  call 0x00007CD93BCC4740
00007cd93bdd04a7  jmp 0x00007CD93BDCF184
00007cd93bdd04ac  call 0x00007CD93BCB5400
00007cd93bdd04b1  jmp 0x00007CD93BDCF191
00007cd93bdd04b6  call 0x00007CD93BCB52F0
00007cd93bdd04bb  jmp 0x00007CD93BDCF19E
00007cd93bdd04c0  call 0x00007CD93BCC4620
00007cd93bdd04c5  jmp 0x00007CD93BDCF1AB
00007cd93bdd04ca  call 0x00007CD93BCC0860
00007cd93bdd04cf  jmp 0x00007CD93BDCF1BE
00007cd93bdd04d4  call 0x00007CD93BCBB270
00007cd93bdd04d9  jmp 0x00007CD93BDCF1CB
00007cd93bdd04de  call 0x00007CD93BCBA000
00007cd93bdd04e3  jmp 0x00007CD93BDCF1D8
00007cd93bdd04e8  call 0x00007CD93BCB8D90
00007cd93bdd04ed  jmp 0x00007CD93BDCF1E5
00007cd93bdd04f2  call 0x00007CD93BCB8A20
00007cd93bdd04f7  jmp 0x00007CD93BDCF1F2
00007cd93bdd04fc  call 0x00007CD93BCB5400
00007cd93bdd0501  jmp 0x00007CD93BDCF1FC
00007cd93bdd0506  call 0x00007CD93BCC2240
00007cd93bdd050b  jmp 0x00007CD93BDCF206
00007cd93bdd0510  call 0x00007CD93BCB52F0
00007cd93bdd0515  jmp 0x00007CD93BDCF210
00007cd93bdd051a  call 0x00007CD93BCC2120
00007cd93bdd051f  jmp 0x00007CD93BDCF21A
00007cd93bdd0524  call 0x00007CD93BCB77B0
00007cd93bdd0529  jmp 0x00007CD93BDCF224
00007cd93bdd052e  call 0x00007CD93BCB6550
00007cd93bdd0533  jmp 0x00007CD93BDCF22E
00007cd93bdd0538  call 0x00007CD93BCBFD50
00007cd93bdd053d  jmp 0x00007CD93BDCF240
00007cd93bdd0542  call 0x00007CD93BCB8EA0
00007cd93bdd0547  jmp 0x00007CD93BDCF24A
00007cd93bdd054c  call 0x00007CD93BCBFC30
00007cd93bdd0551  jmp 0x00007CD93BDCF257
00007cd93bdd0556  call 0x00007CD93BCB8D90
00007cd93bdd055b  jmp 0x00007CD93BDCF264
00007cd93bdd0560  call 0x00007CD93BCC2240
00007cd93bdd0565  jmp 0x00007CD93BDCF271
00007cd93bdd056a  call 0x00007CD93BCB5400
00007cd93bdd056f  jmp 0x00007CD93BDCF27E
00007cd93bdd0574  call 0x00007CD93BCB52F0
00007cd93bdd0579  jmp 0x00007CD93BDCF28B
00007cd93bdd057e  call 0x00007CD93BCC2120
00007cd93bdd0583  jmp 0x00007CD93BDCF298
00007cd93bdd0588  call 0x00007CD93BCB52F0
00007cd93bdd058d  jmp 0x00007CD93BDCF2AB
00007cd93bdd0592  call 0x00007CD93BCB52F0
00007cd93bdd0597  jmp 0x00007CD93BDCF2BE
00007cd93bdd059c  call 0x00007CD93BCB52F0
00007cd93bdd05a1  jmp 0x00007CD93BDCF2D1
00007cd93bdd05a6  call 0x00007CD93BCB52F0
00007cd93bdd05ab  jmp 0x00007CD93BDCF2E4
00007cd93bdd05b0  call 0x00007CD93BCC2240
00007cd93bdd05b5  jmp 0x00007CD93BDCF2F9
00007cd93bdd05ba  call 0x00007CD93BCC2240
00007cd93bdd05bf  jmp 0x00007CD93BDCF30C
00007cd93bdd05c4  call 0x00007CD93BCC2120
00007cd93bdd05c9  jmp 0x00007CD93BDCF319
00007cd93bdd05ce  call 0x00007CD93BCB52F0
00007cd93bdd05d3  jmp 0x00007CD93BDCF32C
00007cd93bdd05d8  call 0x00007CD93BCB52F0
00007cd93bdd05dd  jmp 0x00007CD93BDCF34F
00007cd93bdd05e2  call 0x00007CD93BCB52F0
00007cd93bdd05e7  jmp 0x00007CD93BDCF362
00007cd93bdd05ec  call 0x00007CD93BBFF540
00007cd93bdd05f1  jmp 0x00007CD93BDCF380
00007cd93bdd05f6  call 0x00007CD93BC08C20
00007cd93bdd05fb  jmp 0x00007CD93BDCF38A
00007cd93bdd0600  call 0x00007CD93BCD6600
00007cd93bdd0605  jmp 0x00007CD93BDCF396
00007cd93bdd060a  call 0x00007CD93BBFF540
00007cd93bdd060f  jmp 0x00007CD93BDCF3A6
00007cd93bdd0614  call 0x00007CD93BCC0370
00007cd93bdd0619  jmp 0x00007CD93BDCF3D4
00007cd93bdd061e  call 0x00007CD93BCBF100
00007cd93bdd0623  jmp 0x00007CD93BDCF3DD
00007cd93bdd0628  call 0x00007CD93BCC0370
00007cd93bdd062d  jmp 0x00007CD93BDCF43B
00007cd93bdd0632  call 0x00007CD93BCBF100
00007cd93bdd0637  jmp 0x00007CD93BDCF444
00007cd93bdd063c  call 0x00007CD93BCC0370
00007cd93bdd0641  jmp 0x00007CD93BDCF48B
00007cd93bdd0646  call 0x00007CD93BCBF100
00007cd93bdd064b  jmp 0x00007CD93BDCF494
00007cd93bdd0650  call 0x00007CD93BC0B720
00007cd93bdd0655  jmp 0x00007CD93BDCF4D7
00007cd93bdd065a  call 0x00007CD93BCB47C0
00007cd93bdd065f  jmp 0x00007CD93BDCF4EA
00007cd93bdd0664  call 0x00007CD93BC08B00
00007cd93bdd0669  jmp 0x00007CD93BDCF501
00007cd93bdd066e  call 0x00007CD93BBFF430
00007cd93bdd0673  jmp 0x00007CD93BDCF514
00007cd93bdd0678  call 0x00007CD93BBFF430
00007cd93bdd067d  jmp 0x00007CD93BDCF527
00007cd93bdd0682  sub rsp, 0x08
00007cd93bdd0686  push rax
00007cd93bdd0687  push rcx
00007cd93bdd0688  push rdx
00007cd93bdd0689  push rdi
00007cd93bdd068a  push rsi
00007cd93bdd068b  push r8
00007cd93bdd068d  push r9
00007cd93bdd068f  push r10
00007cd93bdd0691  push r11
00007cd93bdd0693  sub rsp, 0xF0
00007cd93bdd069a  vmovaps [rsp], xmm0
00007cd93bdd069f  vmovaps [rsp+0x10], xmm2
00007cd93bdd06a5  vmovaps [rsp+0x20], xmm3
00007cd93bdd06ab  vmovaps [rsp+0x30], xmm4
00007cd93bdd06b1  vmovaps [rsp+0x40], xmm5
00007cd93bdd06b7  vmovaps [rsp+0x50], xmm6
00007cd93bdd06bd  vmovaps [rsp+0x60], xmm7
00007cd93bdd06c3  vmovaps [rsp+0x70], xmm8
00007cd93bdd06c9  vmovaps [rsp+0x80], xmm9
00007cd93bdd06d2  vmovaps [rsp+0x90], xmm10
00007cd93bdd06db  vmovaps [rsp+0xA0], xmm11
00007cd93bdd06e4  vmovaps [rsp+0xB0], xmm12
00007cd93bdd06ed  vmovaps [rsp+0xC0], xmm13
00007cd93bdd06f6  vmovaps [rsp+0xD0], xmm14
00007cd93bdd06ff  vmovaps [rsp+0xE0], xmm15
00007cd93bdd0708  sub rsp, 0x30
00007cd93bdd070c  movaps [rsp], xmm1
00007cd93bdd0710  movaps [rsp+0x10], xmm15
00007cd93bdd0716  movaps [rsp+0x20], xmm14
00007cd93bdd071c  lea rdi, [rsp]
00007cd93bdd0720  mov esi, 0x00
00007cd93bdd0725  mov rax, 0x64A581057530
00007cd93bdd072f  call rax
00007cd93bdd0731  movaps xmm1, [rsp]
00007cd93bdd0735  add rsp, 0x30
00007cd93bdd0739  vmovaps xmm0, [rsp]
00007cd93bdd073e  vmovaps xmm2, [rsp+0x10]
00007cd93bdd0744  vmovaps xmm3, [rsp+0x20]
00007cd93bdd074a  vmovaps xmm4, [rsp+0x30]
00007cd93bdd0750  vmovaps xmm5, [rsp+0x40]
00007cd93bdd0756  vmovaps xmm6, [rsp+0x50]
00007cd93bdd075c  vmovaps xmm7, [rsp+0x60]
00007cd93bdd0762  vmovaps xmm8, [rsp+0x70]
00007cd93bdd0768  vmovaps xmm9, [rsp+0x80]
00007cd93bdd0771  vmovaps xmm10, [rsp+0x90]
00007cd93bdd077a  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd0783  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd078c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd0795  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd079e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd07a7  add rsp, 0xF0
00007cd93bdd07ae  pop r11
00007cd93bdd07b0  pop r10
00007cd93bdd07b2  pop r9
00007cd93bdd07b4  pop r8
00007cd93bdd07b6  pop rsi
00007cd93bdd07b7  pop rdi
00007cd93bdd07b8  pop rdx
00007cd93bdd07b9  pop rcx
00007cd93bdd07ba  pop rax
00007cd93bdd07bb  add rsp, 0x08
00007cd93bdd07bf  jmp 0x00007CD93BDCF581
00007cd93bdd07c4  sub rsp, 0x08
00007cd93bdd07c8  push rax
00007cd93bdd07c9  push rcx
00007cd93bdd07ca  push rdx
00007cd93bdd07cb  push rdi
00007cd93bdd07cc  push rsi
00007cd93bdd07cd  push r8
00007cd93bdd07cf  push r9
00007cd93bdd07d1  push r10
00007cd93bdd07d3  push r11
00007cd93bdd07d5  sub rsp, 0xF0
00007cd93bdd07dc  vmovaps [rsp], xmm0
00007cd93bdd07e1  vmovaps [rsp+0x10], xmm1
00007cd93bdd07e7  vmovaps [rsp+0x20], xmm2
00007cd93bdd07ed  vmovaps [rsp+0x30], xmm3
00007cd93bdd07f3  vmovaps [rsp+0x40], xmm4
00007cd93bdd07f9  vmovaps [rsp+0x50], xmm5
00007cd93bdd07ff  vmovaps [rsp+0x60], xmm6
00007cd93bdd0805  vmovaps [rsp+0x70], xmm7
00007cd93bdd080b  vmovaps [rsp+0x80], xmm8
00007cd93bdd0814  vmovaps [rsp+0x90], xmm9
00007cd93bdd081d  vmovaps [rsp+0xA0], xmm10
00007cd93bdd0826  vmovaps [rsp+0xB0], xmm11
00007cd93bdd082f  vmovaps [rsp+0xC0], xmm12
00007cd93bdd0838  vmovaps [rsp+0xD0], xmm14
00007cd93bdd0841  vmovaps [rsp+0xE0], xmm15
00007cd93bdd084a  sub rsp, 0x30
00007cd93bdd084e  movaps [rsp], xmm13
00007cd93bdd0853  movaps [rsp+0x10], xmm1
00007cd93bdd0858  movaps [rsp+0x20], xmm14
00007cd93bdd085e  lea rdi, [rsp]
00007cd93bdd0862  mov esi, 0x00
00007cd93bdd0867  mov rax, 0x64A581057530
00007cd93bdd0871  call rax
00007cd93bdd0873  movaps xmm13, [rsp]
00007cd93bdd0878  add rsp, 0x30
00007cd93bdd087c  vmovaps xmm0, [rsp]
00007cd93bdd0881  vmovaps xmm1, [rsp+0x10]
00007cd93bdd0887  vmovaps xmm2, [rsp+0x20]
00007cd93bdd088d  vmovaps xmm3, [rsp+0x30]
00007cd93bdd0893  vmovaps xmm4, [rsp+0x40]
00007cd93bdd0899  vmovaps xmm5, [rsp+0x50]
00007cd93bdd089f  vmovaps xmm6, [rsp+0x60]
00007cd93bdd08a5  vmovaps xmm7, [rsp+0x70]
00007cd93bdd08ab  vmovaps xmm8, [rsp+0x80]
00007cd93bdd08b4  vmovaps xmm9, [rsp+0x90]
00007cd93bdd08bd  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd08c6  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd08cf  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd08d8  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd08e1  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd08ea  add rsp, 0xF0
00007cd93bdd08f1  pop r11
00007cd93bdd08f3  pop r10
00007cd93bdd08f5  pop r9
00007cd93bdd08f7  pop r8
00007cd93bdd08f9  pop rsi
00007cd93bdd08fa  pop rdi
00007cd93bdd08fb  pop rdx
00007cd93bdd08fc  pop rcx
00007cd93bdd08fd  pop rax
00007cd93bdd08fe  add rsp, 0x08
00007cd93bdd0902  jmp 0x00007CD93BDCF5CF
00007cd93bdd0907  sub rsp, 0x08
00007cd93bdd090b  push rax
00007cd93bdd090c  push rcx
00007cd93bdd090d  push rdx
00007cd93bdd090e  push rdi
00007cd93bdd090f  push rsi
00007cd93bdd0910  push r8
00007cd93bdd0912  push r9
00007cd93bdd0914  push r10
00007cd93bdd0916  push r11
00007cd93bdd0918  sub rsp, 0xF0
00007cd93bdd091f  vmovaps [rsp], xmm0
00007cd93bdd0924  vmovaps [rsp+0x10], xmm1
00007cd93bdd092a  vmovaps [rsp+0x20], xmm2
00007cd93bdd0930  vmovaps [rsp+0x30], xmm3
00007cd93bdd0936  vmovaps [rsp+0x40], xmm4
00007cd93bdd093c  vmovaps [rsp+0x50], xmm5
00007cd93bdd0942  vmovaps [rsp+0x60], xmm6
00007cd93bdd0948  vmovaps [rsp+0x70], xmm7
00007cd93bdd094e  vmovaps [rsp+0x80], xmm8
00007cd93bdd0957  vmovaps [rsp+0x90], xmm9
00007cd93bdd0960  vmovaps [rsp+0xA0], xmm10
00007cd93bdd0969  vmovaps [rsp+0xB0], xmm11
00007cd93bdd0972  vmovaps [rsp+0xC0], xmm12
00007cd93bdd097b  vmovaps [rsp+0xD0], xmm13
00007cd93bdd0984  vmovaps [rsp+0xE0], xmm14
00007cd93bdd098d  sub rsp, 0x30
00007cd93bdd0991  movaps [rsp], xmm15
00007cd93bdd0996  movaps [rsp+0x10], xmm14
00007cd93bdd099c  movaps [rsp+0x20], xmm1
00007cd93bdd09a1  lea rdi, [rsp]
00007cd93bdd09a5  mov esi, 0x00
00007cd93bdd09aa  mov rax, 0x64A581057530
00007cd93bdd09b4  call rax
00007cd93bdd09b6  movaps xmm15, [rsp]
00007cd93bdd09bb  add rsp, 0x30
00007cd93bdd09bf  vmovaps xmm0, [rsp]
00007cd93bdd09c4  vmovaps xmm1, [rsp+0x10]
00007cd93bdd09ca  vmovaps xmm2, [rsp+0x20]
00007cd93bdd09d0  vmovaps xmm3, [rsp+0x30]
00007cd93bdd09d6  vmovaps xmm4, [rsp+0x40]
00007cd93bdd09dc  vmovaps xmm5, [rsp+0x50]
00007cd93bdd09e2  vmovaps xmm6, [rsp+0x60]
00007cd93bdd09e8  vmovaps xmm7, [rsp+0x70]
00007cd93bdd09ee  vmovaps xmm8, [rsp+0x80]
00007cd93bdd09f7  vmovaps xmm9, [rsp+0x90]
00007cd93bdd0a00  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd0a09  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd0a12  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd0a1b  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd0a24  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd0a2d  add rsp, 0xF0
00007cd93bdd0a34  pop r11
00007cd93bdd0a36  pop r10
00007cd93bdd0a38  pop r9
00007cd93bdd0a3a  pop r8
00007cd93bdd0a3c  pop rsi
00007cd93bdd0a3d  pop rdi
00007cd93bdd0a3e  pop rdx
00007cd93bdd0a3f  pop rcx
00007cd93bdd0a40  pop rax
00007cd93bdd0a41  add rsp, 0x08
00007cd93bdd0a45  jmp 0x00007CD93BDCF617
00007cd93bdd0a4a  sub rsp, 0x08
00007cd93bdd0a4e  push rax
00007cd93bdd0a4f  push rcx
00007cd93bdd0a50  push rdx
00007cd93bdd0a51  push rdi
00007cd93bdd0a52  push rsi
00007cd93bdd0a53  push r8
00007cd93bdd0a55  push r9
00007cd93bdd0a57  push r10
00007cd93bdd0a59  push r11
00007cd93bdd0a5b  sub rsp, 0xF0
00007cd93bdd0a62  vmovaps [rsp], xmm0
00007cd93bdd0a67  vmovaps [rsp+0x10], xmm2
00007cd93bdd0a6d  vmovaps [rsp+0x20], xmm3
00007cd93bdd0a73  vmovaps [rsp+0x30], xmm4
00007cd93bdd0a79  vmovaps [rsp+0x40], xmm5
00007cd93bdd0a7f  vmovaps [rsp+0x50], xmm6
00007cd93bdd0a85  vmovaps [rsp+0x60], xmm7
00007cd93bdd0a8b  vmovaps [rsp+0x70], xmm8
00007cd93bdd0a91  vmovaps [rsp+0x80], xmm9
00007cd93bdd0a9a  vmovaps [rsp+0x90], xmm10
00007cd93bdd0aa3  vmovaps [rsp+0xA0], xmm11
00007cd93bdd0aac  vmovaps [rsp+0xB0], xmm12
00007cd93bdd0ab5  vmovaps [rsp+0xC0], xmm13
00007cd93bdd0abe  vmovaps [rsp+0xD0], xmm14
00007cd93bdd0ac7  vmovaps [rsp+0xE0], xmm15
00007cd93bdd0ad0  sub rsp, 0x30
00007cd93bdd0ad4  movaps [rsp], xmm1
00007cd93bdd0ad8  movaps [rsp+0x10], xmm14
00007cd93bdd0ade  movaps [rsp+0x20], xmm10
00007cd93bdd0ae4  lea rdi, [rsp]
00007cd93bdd0ae8  mov esi, 0x00
00007cd93bdd0aed  mov rax, 0x64A581057530
00007cd93bdd0af7  call rax
00007cd93bdd0af9  movaps xmm1, [rsp]
00007cd93bdd0afd  add rsp, 0x30
00007cd93bdd0b01  vmovaps xmm0, [rsp]
00007cd93bdd0b06  vmovaps xmm2, [rsp+0x10]
00007cd93bdd0b0c  vmovaps xmm3, [rsp+0x20]
00007cd93bdd0b12  vmovaps xmm4, [rsp+0x30]
00007cd93bdd0b18  vmovaps xmm5, [rsp+0x40]
00007cd93bdd0b1e  vmovaps xmm6, [rsp+0x50]
00007cd93bdd0b24  vmovaps xmm7, [rsp+0x60]
00007cd93bdd0b2a  vmovaps xmm8, [rsp+0x70]
00007cd93bdd0b30  vmovaps xmm9, [rsp+0x80]
00007cd93bdd0b39  vmovaps xmm10, [rsp+0x90]
00007cd93bdd0b42  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd0b4b  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd0b54  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd0b5d  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd0b66  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd0b6f  add rsp, 0xF0
00007cd93bdd0b76  pop r11
00007cd93bdd0b78  pop r10
00007cd93bdd0b7a  pop r9
00007cd93bdd0b7c  pop r8
00007cd93bdd0b7e  pop rsi
00007cd93bdd0b7f  pop rdi
00007cd93bdd0b80  pop rdx
00007cd93bdd0b81  pop rcx
00007cd93bdd0b82  pop rax
00007cd93bdd0b83  add rsp, 0x08
00007cd93bdd0b87  jmp 0x00007CD93BDCF631
00007cd93bdd0b8c  sub rsp, 0x08
00007cd93bdd0b90  push rax
00007cd93bdd0b91  push rcx
00007cd93bdd0b92  push rdx
00007cd93bdd0b93  push rdi
00007cd93bdd0b94  push rsi
00007cd93bdd0b95  push r8
00007cd93bdd0b97  push r9
00007cd93bdd0b99  push r10
00007cd93bdd0b9b  push r11
00007cd93bdd0b9d  sub rsp, 0xF0
00007cd93bdd0ba4  vmovaps [rsp], xmm0
00007cd93bdd0ba9  vmovaps [rsp+0x10], xmm1
00007cd93bdd0baf  vmovaps [rsp+0x20], xmm2
00007cd93bdd0bb5  vmovaps [rsp+0x30], xmm3
00007cd93bdd0bbb  vmovaps [rsp+0x40], xmm4
00007cd93bdd0bc1  vmovaps [rsp+0x50], xmm5
00007cd93bdd0bc7  vmovaps [rsp+0x60], xmm6
00007cd93bdd0bcd  vmovaps [rsp+0x70], xmm7
00007cd93bdd0bd3  vmovaps [rsp+0x80], xmm8
00007cd93bdd0bdc  vmovaps [rsp+0x90], xmm9
00007cd93bdd0be5  vmovaps [rsp+0xA0], xmm10
00007cd93bdd0bee  vmovaps [rsp+0xB0], xmm11
00007cd93bdd0bf7  vmovaps [rsp+0xC0], xmm12
00007cd93bdd0c00  vmovaps [rsp+0xD0], xmm14
00007cd93bdd0c09  vmovaps [rsp+0xE0], xmm15
00007cd93bdd0c12  sub rsp, 0x30
00007cd93bdd0c16  movaps [rsp], xmm13
00007cd93bdd0c1b  movaps [rsp+0x10], xmm14
00007cd93bdd0c21  movaps [rsp+0x20], xmm2
00007cd93bdd0c26  lea rdi, [rsp]
00007cd93bdd0c2a  mov esi, 0x00
00007cd93bdd0c2f  mov rax, 0x64A581057530
00007cd93bdd0c39  call rax
00007cd93bdd0c3b  movaps xmm13, [rsp]
00007cd93bdd0c40  add rsp, 0x30
00007cd93bdd0c44  vmovaps xmm0, [rsp]
00007cd93bdd0c49  vmovaps xmm1, [rsp+0x10]
00007cd93bdd0c4f  vmovaps xmm2, [rsp+0x20]
00007cd93bdd0c55  vmovaps xmm3, [rsp+0x30]
00007cd93bdd0c5b  vmovaps xmm4, [rsp+0x40]
00007cd93bdd0c61  vmovaps xmm5, [rsp+0x50]
00007cd93bdd0c67  vmovaps xmm6, [rsp+0x60]
00007cd93bdd0c6d  vmovaps xmm7, [rsp+0x70]
00007cd93bdd0c73  vmovaps xmm8, [rsp+0x80]
00007cd93bdd0c7c  vmovaps xmm9, [rsp+0x90]
00007cd93bdd0c85  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd0c8e  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd0c97  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd0ca0  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd0ca9  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd0cb2  add rsp, 0xF0
00007cd93bdd0cb9  pop r11
00007cd93bdd0cbb  pop r10
00007cd93bdd0cbd  pop r9
00007cd93bdd0cbf  pop r8
00007cd93bdd0cc1  pop rsi
00007cd93bdd0cc2  pop rdi
00007cd93bdd0cc3  pop rdx
00007cd93bdd0cc4  pop rcx
00007cd93bdd0cc5  pop rax
00007cd93bdd0cc6  add rsp, 0x08
00007cd93bdd0cca  jmp 0x00007CD93BDCF64C
00007cd93bdd0ccf  sub rsp, 0x08
00007cd93bdd0cd3  push rax
00007cd93bdd0cd4  push rcx
00007cd93bdd0cd5  push rdx
00007cd93bdd0cd6  push rdi
00007cd93bdd0cd7  push rsi
00007cd93bdd0cd8  push r8
00007cd93bdd0cda  push r9
00007cd93bdd0cdc  push r10
00007cd93bdd0cde  push r11
00007cd93bdd0ce0  sub rsp, 0xF0
00007cd93bdd0ce7  vmovaps [rsp], xmm0
00007cd93bdd0cec  vmovaps [rsp+0x10], xmm2
00007cd93bdd0cf2  vmovaps [rsp+0x20], xmm3
00007cd93bdd0cf8  vmovaps [rsp+0x30], xmm4
00007cd93bdd0cfe  vmovaps [rsp+0x40], xmm5
00007cd93bdd0d04  vmovaps [rsp+0x50], xmm6
00007cd93bdd0d0a  vmovaps [rsp+0x60], xmm7
00007cd93bdd0d10  vmovaps [rsp+0x70], xmm8
00007cd93bdd0d16  vmovaps [rsp+0x80], xmm9
00007cd93bdd0d1f  vmovaps [rsp+0x90], xmm10
00007cd93bdd0d28  vmovaps [rsp+0xA0], xmm11
00007cd93bdd0d31  vmovaps [rsp+0xB0], xmm12
00007cd93bdd0d3a  vmovaps [rsp+0xC0], xmm13
00007cd93bdd0d43  vmovaps [rsp+0xD0], xmm14
00007cd93bdd0d4c  vmovaps [rsp+0xE0], xmm15
00007cd93bdd0d55  sub rsp, 0x30
00007cd93bdd0d59  movaps [rsp], xmm1
00007cd93bdd0d5d  movaps [rsp+0x10], xmm10
00007cd93bdd0d63  movaps [rsp+0x20], xmm2
00007cd93bdd0d68  lea rdi, [rsp]
00007cd93bdd0d6c  mov esi, 0x00
00007cd93bdd0d71  mov rax, 0x64A581057530
00007cd93bdd0d7b  call rax
00007cd93bdd0d7d  movaps xmm1, [rsp]
00007cd93bdd0d81  add rsp, 0x30
00007cd93bdd0d85  vmovaps xmm0, [rsp]
00007cd93bdd0d8a  vmovaps xmm2, [rsp+0x10]
00007cd93bdd0d90  vmovaps xmm3, [rsp+0x20]
00007cd93bdd0d96  vmovaps xmm4, [rsp+0x30]
00007cd93bdd0d9c  vmovaps xmm5, [rsp+0x40]
00007cd93bdd0da2  vmovaps xmm6, [rsp+0x50]
00007cd93bdd0da8  vmovaps xmm7, [rsp+0x60]
00007cd93bdd0dae  vmovaps xmm8, [rsp+0x70]
00007cd93bdd0db4  vmovaps xmm9, [rsp+0x80]
00007cd93bdd0dbd  vmovaps xmm10, [rsp+0x90]
00007cd93bdd0dc6  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd0dcf  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd0dd8  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd0de1  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd0dea  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd0df3  add rsp, 0xF0
00007cd93bdd0dfa  pop r11
00007cd93bdd0dfc  pop r10
00007cd93bdd0dfe  pop r9
00007cd93bdd0e00  pop r8
00007cd93bdd0e02  pop rsi
00007cd93bdd0e03  pop rdi
00007cd93bdd0e04  pop rdx
00007cd93bdd0e05  pop rcx
00007cd93bdd0e06  pop rax
00007cd93bdd0e07  add rsp, 0x08
00007cd93bdd0e0b  jmp 0x00007CD93BDCF6B4
00007cd93bdd0e10  sub rsp, 0x08
00007cd93bdd0e14  push rax
00007cd93bdd0e15  push rcx
00007cd93bdd0e16  push rdx
00007cd93bdd0e17  push rdi
00007cd93bdd0e18  push rsi
00007cd93bdd0e19  push r8
00007cd93bdd0e1b  push r9
00007cd93bdd0e1d  push r10
00007cd93bdd0e1f  push r11
00007cd93bdd0e21  sub rsp, 0xF0
00007cd93bdd0e28  vmovaps [rsp], xmm0
00007cd93bdd0e2d  vmovaps [rsp+0x10], xmm1
00007cd93bdd0e33  vmovaps [rsp+0x20], xmm2
00007cd93bdd0e39  vmovaps [rsp+0x30], xmm3
00007cd93bdd0e3f  vmovaps [rsp+0x40], xmm4
00007cd93bdd0e45  vmovaps [rsp+0x50], xmm5
00007cd93bdd0e4b  vmovaps [rsp+0x60], xmm6
00007cd93bdd0e51  vmovaps [rsp+0x70], xmm7
00007cd93bdd0e57  vmovaps [rsp+0x80], xmm8
00007cd93bdd0e60  vmovaps [rsp+0x90], xmm9
00007cd93bdd0e69  vmovaps [rsp+0xA0], xmm10
00007cd93bdd0e72  vmovaps [rsp+0xB0], xmm11
00007cd93bdd0e7b  vmovaps [rsp+0xC0], xmm12
00007cd93bdd0e84  vmovaps [rsp+0xD0], xmm13
00007cd93bdd0e8d  vmovaps [rsp+0xE0], xmm14
00007cd93bdd0e96  sub rsp, 0x30
00007cd93bdd0e9a  movaps [rsp], xmm15
00007cd93bdd0e9f  movaps [rsp+0x10], xmm10
00007cd93bdd0ea5  movaps [rsp+0x20], xmm2
00007cd93bdd0eaa  lea rdi, [rsp]
00007cd93bdd0eae  mov esi, 0x00
00007cd93bdd0eb3  mov rax, 0x64A581057530
00007cd93bdd0ebd  call rax
00007cd93bdd0ebf  movaps xmm15, [rsp]
00007cd93bdd0ec4  add rsp, 0x30
00007cd93bdd0ec8  vmovaps xmm0, [rsp]
00007cd93bdd0ecd  vmovaps xmm1, [rsp+0x10]
00007cd93bdd0ed3  vmovaps xmm2, [rsp+0x20]
00007cd93bdd0ed9  vmovaps xmm3, [rsp+0x30]
00007cd93bdd0edf  vmovaps xmm4, [rsp+0x40]
00007cd93bdd0ee5  vmovaps xmm5, [rsp+0x50]
00007cd93bdd0eeb  vmovaps xmm6, [rsp+0x60]
00007cd93bdd0ef1  vmovaps xmm7, [rsp+0x70]
00007cd93bdd0ef7  vmovaps xmm8, [rsp+0x80]
00007cd93bdd0f00  vmovaps xmm9, [rsp+0x90]
00007cd93bdd0f09  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd0f12  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd0f1b  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd0f24  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd0f2d  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd0f36  add rsp, 0xF0
00007cd93bdd0f3d  pop r11
00007cd93bdd0f3f  pop r10
00007cd93bdd0f41  pop r9
00007cd93bdd0f43  pop r8
00007cd93bdd0f45  pop rsi
00007cd93bdd0f46  pop rdi
00007cd93bdd0f47  pop rdx
00007cd93bdd0f48  pop rcx
00007cd93bdd0f49  pop rax
00007cd93bdd0f4a  add rsp, 0x08
00007cd93bdd0f4e  jmp 0x00007CD93BDCF706
00007cd93bdd0f53  sub rsp, 0x08
00007cd93bdd0f57  push rax
00007cd93bdd0f58  push rcx
00007cd93bdd0f59  push rdx
00007cd93bdd0f5a  push rdi
00007cd93bdd0f5b  push rsi
00007cd93bdd0f5c  push r8
00007cd93bdd0f5e  push r9
00007cd93bdd0f60  push r10
00007cd93bdd0f62  push r11
00007cd93bdd0f64  sub rsp, 0xF0
00007cd93bdd0f6b  vmovaps [rsp], xmm0
00007cd93bdd0f70  vmovaps [rsp+0x10], xmm2
00007cd93bdd0f76  vmovaps [rsp+0x20], xmm3
00007cd93bdd0f7c  vmovaps [rsp+0x30], xmm4
00007cd93bdd0f82  vmovaps [rsp+0x40], xmm5
00007cd93bdd0f88  vmovaps [rsp+0x50], xmm6
00007cd93bdd0f8e  vmovaps [rsp+0x60], xmm7
00007cd93bdd0f94  vmovaps [rsp+0x70], xmm8
00007cd93bdd0f9a  vmovaps [rsp+0x80], xmm9
00007cd93bdd0fa3  vmovaps [rsp+0x90], xmm10
00007cd93bdd0fac  vmovaps [rsp+0xA0], xmm11
00007cd93bdd0fb5  vmovaps [rsp+0xB0], xmm12
00007cd93bdd0fbe  vmovaps [rsp+0xC0], xmm13
00007cd93bdd0fc7  vmovaps [rsp+0xD0], xmm14
00007cd93bdd0fd0  vmovaps [rsp+0xE0], xmm15
00007cd93bdd0fd9  sub rsp, 0x30
00007cd93bdd0fdd  movaps [rsp], xmm1
00007cd93bdd0fe1  movaps [rsp+0x10], xmm10
00007cd93bdd0fe7  movaps [rsp+0x20], xmm12
00007cd93bdd0fed  lea rdi, [rsp]
00007cd93bdd0ff1  mov esi, 0x00
00007cd93bdd0ff6  mov rax, 0x64A581057530
00007cd93bdd1000  call rax
00007cd93bdd1002  movaps xmm1, [rsp]
00007cd93bdd1006  add rsp, 0x30
00007cd93bdd100a  vmovaps xmm0, [rsp]
00007cd93bdd100f  vmovaps xmm2, [rsp+0x10]
00007cd93bdd1015  vmovaps xmm3, [rsp+0x20]
00007cd93bdd101b  vmovaps xmm4, [rsp+0x30]
00007cd93bdd1021  vmovaps xmm5, [rsp+0x40]
00007cd93bdd1027  vmovaps xmm6, [rsp+0x50]
00007cd93bdd102d  vmovaps xmm7, [rsp+0x60]
00007cd93bdd1033  vmovaps xmm8, [rsp+0x70]
00007cd93bdd1039  vmovaps xmm9, [rsp+0x80]
00007cd93bdd1042  vmovaps xmm10, [rsp+0x90]
00007cd93bdd104b  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd1054  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd105d  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd1066  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd106f  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd1078  add rsp, 0xF0
00007cd93bdd107f  pop r11
00007cd93bdd1081  pop r10
00007cd93bdd1083  pop r9
00007cd93bdd1085  pop r8
00007cd93bdd1087  pop rsi
00007cd93bdd1088  pop rdi
00007cd93bdd1089  pop rdx
00007cd93bdd108a  pop rcx
00007cd93bdd108b  pop rax
00007cd93bdd108c  add rsp, 0x08
00007cd93bdd1090  jmp 0x00007CD93BDCF732
00007cd93bdd1095  sub rsp, 0x08
00007cd93bdd1099  push rax
00007cd93bdd109a  push rcx
00007cd93bdd109b  push rdx
00007cd93bdd109c  push rdi
00007cd93bdd109d  push rsi
00007cd93bdd109e  push r8
00007cd93bdd10a0  push r9
00007cd93bdd10a2  push r10
00007cd93bdd10a4  push r11
00007cd93bdd10a6  sub rsp, 0xF0
00007cd93bdd10ad  vmovaps [rsp], xmm0
00007cd93bdd10b2  vmovaps [rsp+0x10], xmm1
00007cd93bdd10b8  vmovaps [rsp+0x20], xmm2
00007cd93bdd10be  vmovaps [rsp+0x30], xmm3
00007cd93bdd10c4  vmovaps [rsp+0x40], xmm4
00007cd93bdd10ca  vmovaps [rsp+0x50], xmm5
00007cd93bdd10d0  vmovaps [rsp+0x60], xmm6
00007cd93bdd10d6  vmovaps [rsp+0x70], xmm7
00007cd93bdd10dc  vmovaps [rsp+0x80], xmm8
00007cd93bdd10e5  vmovaps [rsp+0x90], xmm9
00007cd93bdd10ee  vmovaps [rsp+0xA0], xmm10
00007cd93bdd10f7  vmovaps [rsp+0xB0], xmm11
00007cd93bdd1100  vmovaps [rsp+0xC0], xmm12
00007cd93bdd1109  vmovaps [rsp+0xD0], xmm13
00007cd93bdd1112  vmovaps [rsp+0xE0], xmm14
00007cd93bdd111b  sub rsp, 0x30
00007cd93bdd111f  movaps [rsp], xmm15
00007cd93bdd1124  movaps [rsp+0x10], xmm10
00007cd93bdd112a  movaps [rsp+0x20], xmm12
00007cd93bdd1130  lea rdi, [rsp]
00007cd93bdd1134  mov esi, 0x00
00007cd93bdd1139  mov rax, 0x64A581057530
00007cd93bdd1143  call rax
00007cd93bdd1145  movaps xmm15, [rsp]
00007cd93bdd114a  add rsp, 0x30
00007cd93bdd114e  vmovaps xmm0, [rsp]
00007cd93bdd1153  vmovaps xmm1, [rsp+0x10]
00007cd93bdd1159  vmovaps xmm2, [rsp+0x20]
00007cd93bdd115f  vmovaps xmm3, [rsp+0x30]
00007cd93bdd1165  vmovaps xmm4, [rsp+0x40]
00007cd93bdd116b  vmovaps xmm5, [rsp+0x50]
00007cd93bdd1171  vmovaps xmm6, [rsp+0x60]
00007cd93bdd1177  vmovaps xmm7, [rsp+0x70]
00007cd93bdd117d  vmovaps xmm8, [rsp+0x80]
00007cd93bdd1186  vmovaps xmm9, [rsp+0x90]
00007cd93bdd118f  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd1198  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd11a1  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd11aa  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd11b3  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd11bc  add rsp, 0xF0
00007cd93bdd11c3  pop r11
00007cd93bdd11c5  pop r10
00007cd93bdd11c7  pop r9
00007cd93bdd11c9  pop r8
00007cd93bdd11cb  pop rsi
00007cd93bdd11cc  pop rdi
00007cd93bdd11cd  pop rdx
00007cd93bdd11ce  pop rcx
00007cd93bdd11cf  pop rax
00007cd93bdd11d0  add rsp, 0x08
00007cd93bdd11d4  jmp 0x00007CD93BDCF75E
00007cd93bdd11d9  call 0x00007CD93BBFF430
00007cd93bdd11de  jmp 0x00007CD93BDCF7EE
00007cd93bdd11e3  call 0x00007CD93BBFF430
00007cd93bdd11e8  jmp 0x00007CD93BDCF801
00007cd93bdd11ed  sub rsp, 0x08
00007cd93bdd11f1  push rax
00007cd93bdd11f2  push rcx
00007cd93bdd11f3  push rdx
00007cd93bdd11f4  push rdi
00007cd93bdd11f5  push rsi
00007cd93bdd11f6  push r8
00007cd93bdd11f8  push r9
00007cd93bdd11fa  push r10
00007cd93bdd11fc  push r11
00007cd93bdd11fe  sub rsp, 0xF0
00007cd93bdd1205  vmovaps [rsp], xmm0
00007cd93bdd120a  vmovaps [rsp+0x10], xmm2
00007cd93bdd1210  vmovaps [rsp+0x20], xmm3
00007cd93bdd1216  vmovaps [rsp+0x30], xmm4
00007cd93bdd121c  vmovaps [rsp+0x40], xmm5
00007cd93bdd1222  vmovaps [rsp+0x50], xmm6
00007cd93bdd1228  vmovaps [rsp+0x60], xmm7
00007cd93bdd122e  vmovaps [rsp+0x70], xmm8
00007cd93bdd1234  vmovaps [rsp+0x80], xmm9
00007cd93bdd123d  vmovaps [rsp+0x90], xmm10
00007cd93bdd1246  vmovaps [rsp+0xA0], xmm11
00007cd93bdd124f  vmovaps [rsp+0xB0], xmm12
00007cd93bdd1258  vmovaps [rsp+0xC0], xmm13
00007cd93bdd1261  vmovaps [rsp+0xD0], xmm14
00007cd93bdd126a  vmovaps [rsp+0xE0], xmm15
00007cd93bdd1273  sub rsp, 0x30
00007cd93bdd1277  movaps [rsp], xmm1
00007cd93bdd127b  movaps [rsp+0x10], xmm13
00007cd93bdd1281  movaps [rsp+0x20], xmm2
00007cd93bdd1286  lea rdi, [rsp]
00007cd93bdd128a  mov esi, 0x00
00007cd93bdd128f  mov rax, 0x64A581057530
00007cd93bdd1299  call rax
00007cd93bdd129b  movaps xmm1, [rsp]
00007cd93bdd129f  add rsp, 0x30
00007cd93bdd12a3  vmovaps xmm0, [rsp]
00007cd93bdd12a8  vmovaps xmm2, [rsp+0x10]
00007cd93bdd12ae  vmovaps xmm3, [rsp+0x20]
00007cd93bdd12b4  vmovaps xmm4, [rsp+0x30]
00007cd93bdd12ba  vmovaps xmm5, [rsp+0x40]
00007cd93bdd12c0  vmovaps xmm6, [rsp+0x50]
00007cd93bdd12c6  vmovaps xmm7, [rsp+0x60]
00007cd93bdd12cc  vmovaps xmm8, [rsp+0x70]
00007cd93bdd12d2  vmovaps xmm9, [rsp+0x80]
00007cd93bdd12db  vmovaps xmm10, [rsp+0x90]
00007cd93bdd12e4  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd12ed  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd12f6  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd12ff  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd1308  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd1311  add rsp, 0xF0
00007cd93bdd1318  pop r11
00007cd93bdd131a  pop r10
00007cd93bdd131c  pop r9
00007cd93bdd131e  pop r8
00007cd93bdd1320  pop rsi
00007cd93bdd1321  pop rdi
00007cd93bdd1322  pop rdx
00007cd93bdd1323  pop rcx
00007cd93bdd1324  pop rax
00007cd93bdd1325  add rsp, 0x08
00007cd93bdd1329  jmp 0x00007CD93BDCF82C
00007cd93bdd132e  call 0x00007CD93BC0E760
00007cd93bdd1333  jmp 0x00007CD93BDCF839
00007cd93bdd1338  sub rsp, 0x08
00007cd93bdd133c  push rax
00007cd93bdd133d  push rcx
00007cd93bdd133e  push rdx
00007cd93bdd133f  push rdi
00007cd93bdd1340  push rsi
00007cd93bdd1341  push r8
00007cd93bdd1343  push r9
00007cd93bdd1345  push r10
00007cd93bdd1347  push r11
00007cd93bdd1349  sub rsp, 0xF0
00007cd93bdd1350  vmovaps [rsp], xmm0
00007cd93bdd1355  vmovaps [rsp+0x10], xmm1
00007cd93bdd135b  vmovaps [rsp+0x20], xmm2
00007cd93bdd1361  vmovaps [rsp+0x30], xmm3
00007cd93bdd1367  vmovaps [rsp+0x40], xmm4
00007cd93bdd136d  vmovaps [rsp+0x50], xmm5
00007cd93bdd1373  vmovaps [rsp+0x60], xmm6
00007cd93bdd1379  vmovaps [rsp+0x70], xmm7
00007cd93bdd137f  vmovaps [rsp+0x80], xmm8
00007cd93bdd1388  vmovaps [rsp+0x90], xmm9
00007cd93bdd1391  vmovaps [rsp+0xA0], xmm10
00007cd93bdd139a  vmovaps [rsp+0xB0], xmm11
00007cd93bdd13a3  vmovaps [rsp+0xC0], xmm12
00007cd93bdd13ac  vmovaps [rsp+0xD0], xmm14
00007cd93bdd13b5  vmovaps [rsp+0xE0], xmm15
00007cd93bdd13be  sub rsp, 0x30
00007cd93bdd13c2  movaps [rsp], xmm13
00007cd93bdd13c7  movaps [rsp+0x10], xmm2
00007cd93bdd13cc  movaps [rsp+0x20], xmm1
00007cd93bdd13d1  lea rdi, [rsp]
00007cd93bdd13d5  mov esi, 0x00
00007cd93bdd13da  mov rax, 0x64A581057530
00007cd93bdd13e4  call rax
00007cd93bdd13e6  movaps xmm13, [rsp]
00007cd93bdd13eb  add rsp, 0x30
00007cd93bdd13ef  vmovaps xmm0, [rsp]
00007cd93bdd13f4  vmovaps xmm1, [rsp+0x10]
00007cd93bdd13fa  vmovaps xmm2, [rsp+0x20]
00007cd93bdd1400  vmovaps xmm3, [rsp+0x30]
00007cd93bdd1406  vmovaps xmm4, [rsp+0x40]
00007cd93bdd140c  vmovaps xmm5, [rsp+0x50]
00007cd93bdd1412  vmovaps xmm6, [rsp+0x60]
00007cd93bdd1418  vmovaps xmm7, [rsp+0x70]
00007cd93bdd141e  vmovaps xmm8, [rsp+0x80]
00007cd93bdd1427  vmovaps xmm9, [rsp+0x90]
00007cd93bdd1430  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd1439  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd1442  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd144b  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd1454  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd145d  add rsp, 0xF0
00007cd93bdd1464  pop r11
00007cd93bdd1466  pop r10
00007cd93bdd1468  pop r9
00007cd93bdd146a  pop r8
00007cd93bdd146c  pop rsi
00007cd93bdd146d  pop rdi
00007cd93bdd146e  pop rdx
00007cd93bdd146f  pop rcx
00007cd93bdd1470  pop rax
00007cd93bdd1471  add rsp, 0x08
00007cd93bdd1475  jmp 0x00007CD93BDCF878
00007cd93bdd147a  sub rsp, 0x08
00007cd93bdd147e  push rax
00007cd93bdd147f  push rcx
00007cd93bdd1480  push rdx
00007cd93bdd1481  push rdi
00007cd93bdd1482  push rsi
00007cd93bdd1483  push r8
00007cd93bdd1485  push r9
00007cd93bdd1487  push r10
00007cd93bdd1489  push r11
00007cd93bdd148b  sub rsp, 0xF0
00007cd93bdd1492  vmovaps [rsp], xmm0
00007cd93bdd1497  vmovaps [rsp+0x10], xmm2
00007cd93bdd149d  vmovaps [rsp+0x20], xmm3
00007cd93bdd14a3  vmovaps [rsp+0x30], xmm4
00007cd93bdd14a9  vmovaps [rsp+0x40], xmm5
00007cd93bdd14af  vmovaps [rsp+0x50], xmm6
00007cd93bdd14b5  vmovaps [rsp+0x60], xmm7
00007cd93bdd14bb  vmovaps [rsp+0x70], xmm8
00007cd93bdd14c1  vmovaps [rsp+0x80], xmm9
00007cd93bdd14ca  vmovaps [rsp+0x90], xmm10
00007cd93bdd14d3  vmovaps [rsp+0xA0], xmm11
00007cd93bdd14dc  vmovaps [rsp+0xB0], xmm12
00007cd93bdd14e5  vmovaps [rsp+0xC0], xmm13
00007cd93bdd14ee  vmovaps [rsp+0xD0], xmm14
00007cd93bdd14f7  vmovaps [rsp+0xE0], xmm15
00007cd93bdd1500  sub rsp, 0x30
00007cd93bdd1504  movaps [rsp], xmm1
00007cd93bdd1508  movaps [rsp+0x10], xmm15
00007cd93bdd150e  movaps [rsp+0x20], xmm2
00007cd93bdd1513  lea rdi, [rsp]
00007cd93bdd1517  mov esi, 0x00
00007cd93bdd151c  mov rax, 0x64A581057530
00007cd93bdd1526  call rax
00007cd93bdd1528  movaps xmm1, [rsp]
00007cd93bdd152c  add rsp, 0x30
00007cd93bdd1530  vmovaps xmm0, [rsp]
00007cd93bdd1535  vmovaps xmm2, [rsp+0x10]
00007cd93bdd153b  vmovaps xmm3, [rsp+0x20]
00007cd93bdd1541  vmovaps xmm4, [rsp+0x30]
00007cd93bdd1547  vmovaps xmm5, [rsp+0x40]
00007cd93bdd154d  vmovaps xmm6, [rsp+0x50]
00007cd93bdd1553  vmovaps xmm7, [rsp+0x60]
00007cd93bdd1559  vmovaps xmm8, [rsp+0x70]
00007cd93bdd155f  vmovaps xmm9, [rsp+0x80]
00007cd93bdd1568  vmovaps xmm10, [rsp+0x90]
00007cd93bdd1571  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd157a  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd1583  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd158c  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd1595  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd159e  add rsp, 0xF0
00007cd93bdd15a5  pop r11
00007cd93bdd15a7  pop r10
00007cd93bdd15a9  pop r9
00007cd93bdd15ab  pop r8
00007cd93bdd15ad  pop rsi
00007cd93bdd15ae  pop rdi
00007cd93bdd15af  pop rdx
00007cd93bdd15b0  pop rcx
00007cd93bdd15b1  pop rax
00007cd93bdd15b2  add rsp, 0x08
00007cd93bdd15b6  jmp 0x00007CD93BDCF8AC
00007cd93bdd15bb  sub rsp, 0x08
00007cd93bdd15bf  push rax
00007cd93bdd15c0  push rcx
00007cd93bdd15c1  push rdx
00007cd93bdd15c2  push rdi
00007cd93bdd15c3  push rsi
00007cd93bdd15c4  push r8
00007cd93bdd15c6  push r9
00007cd93bdd15c8  push r10
00007cd93bdd15ca  push r11
00007cd93bdd15cc  sub rsp, 0xF0
00007cd93bdd15d3  vmovaps [rsp], xmm0
00007cd93bdd15d8  vmovaps [rsp+0x10], xmm1
00007cd93bdd15de  vmovaps [rsp+0x20], xmm2
00007cd93bdd15e4  vmovaps [rsp+0x30], xmm3
00007cd93bdd15ea  vmovaps [rsp+0x40], xmm4
00007cd93bdd15f0  vmovaps [rsp+0x50], xmm5
00007cd93bdd15f6  vmovaps [rsp+0x60], xmm6
00007cd93bdd15fc  vmovaps [rsp+0x70], xmm7
00007cd93bdd1602  vmovaps [rsp+0x80], xmm8
00007cd93bdd160b  vmovaps [rsp+0x90], xmm9
00007cd93bdd1614  vmovaps [rsp+0xA0], xmm10
00007cd93bdd161d  vmovaps [rsp+0xB0], xmm11
00007cd93bdd1626  vmovaps [rsp+0xC0], xmm12
00007cd93bdd162f  vmovaps [rsp+0xD0], xmm13
00007cd93bdd1638  vmovaps [rsp+0xE0], xmm15
00007cd93bdd1641  sub rsp, 0x30
00007cd93bdd1645  movaps [rsp], xmm14
00007cd93bdd164a  movaps [rsp+0x10], xmm2
00007cd93bdd164f  movaps [rsp+0x20], xmm15
00007cd93bdd1655  lea rdi, [rsp]
00007cd93bdd1659  mov esi, 0x00
00007cd93bdd165e  mov rax, 0x64A581057530
00007cd93bdd1668  call rax
00007cd93bdd166a  movaps xmm14, [rsp]
00007cd93bdd166f  add rsp, 0x30
00007cd93bdd1673  vmovaps xmm0, [rsp]
00007cd93bdd1678  vmovaps xmm1, [rsp+0x10]
00007cd93bdd167e  vmovaps xmm2, [rsp+0x20]
00007cd93bdd1684  vmovaps xmm3, [rsp+0x30]
00007cd93bdd168a  vmovaps xmm4, [rsp+0x40]
00007cd93bdd1690  vmovaps xmm5, [rsp+0x50]
00007cd93bdd1696  vmovaps xmm6, [rsp+0x60]
00007cd93bdd169c  vmovaps xmm7, [rsp+0x70]
00007cd93bdd16a2  vmovaps xmm8, [rsp+0x80]
00007cd93bdd16ab  vmovaps xmm9, [rsp+0x90]
00007cd93bdd16b4  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd16bd  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd16c6  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd16cf  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd16d8  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd16e1  add rsp, 0xF0
00007cd93bdd16e8  pop r11
00007cd93bdd16ea  pop r10
00007cd93bdd16ec  pop r9
00007cd93bdd16ee  pop r8
00007cd93bdd16f0  pop rsi
00007cd93bdd16f1  pop rdi
00007cd93bdd16f2  pop rdx
00007cd93bdd16f3  pop rcx
00007cd93bdd16f4  pop rax
00007cd93bdd16f5  add rsp, 0x08
00007cd93bdd16f9  jmp 0x00007CD93BDCF8E7
00007cd93bdd16fe  sub rsp, 0x08
00007cd93bdd1702  push rax
00007cd93bdd1703  push rcx
00007cd93bdd1704  push rdx
00007cd93bdd1705  push rdi
00007cd93bdd1706  push rsi
00007cd93bdd1707  push r8
00007cd93bdd1709  push r9
00007cd93bdd170b  push r10
00007cd93bdd170d  push r11
00007cd93bdd170f  sub rsp, 0xF0
00007cd93bdd1716  vmovaps [rsp], xmm0
00007cd93bdd171b  vmovaps [rsp+0x10], xmm1
00007cd93bdd1721  vmovaps [rsp+0x20], xmm2
00007cd93bdd1727  vmovaps [rsp+0x30], xmm3
00007cd93bdd172d  vmovaps [rsp+0x40], xmm4
00007cd93bdd1733  vmovaps [rsp+0x50], xmm5
00007cd93bdd1739  vmovaps [rsp+0x60], xmm6
00007cd93bdd173f  vmovaps [rsp+0x70], xmm7
00007cd93bdd1745  vmovaps [rsp+0x80], xmm8
00007cd93bdd174e  vmovaps [rsp+0x90], xmm9
00007cd93bdd1757  vmovaps [rsp+0xA0], xmm10
00007cd93bdd1760  vmovaps [rsp+0xB0], xmm11
00007cd93bdd1769  vmovaps [rsp+0xC0], xmm12
00007cd93bdd1772  vmovaps [rsp+0xD0], xmm13
00007cd93bdd177b  vmovaps [rsp+0xE0], xmm14
00007cd93bdd1784  sub rsp, 0x30
00007cd93bdd1788  movaps [rsp], xmm15
00007cd93bdd178d  movaps [rsp+0x10], xmm2
00007cd93bdd1792  movaps [rsp+0x20], xmm1
00007cd93bdd1797  lea rdi, [rsp]
00007cd93bdd179b  mov esi, 0x00
00007cd93bdd17a0  mov rax, 0x64A581057530
00007cd93bdd17aa  call rax
00007cd93bdd17ac  movaps xmm15, [rsp]
00007cd93bdd17b1  add rsp, 0x30
00007cd93bdd17b5  vmovaps xmm0, [rsp]
00007cd93bdd17ba  vmovaps xmm1, [rsp+0x10]
00007cd93bdd17c0  vmovaps xmm2, [rsp+0x20]
00007cd93bdd17c6  vmovaps xmm3, [rsp+0x30]
00007cd93bdd17cc  vmovaps xmm4, [rsp+0x40]
00007cd93bdd17d2  vmovaps xmm5, [rsp+0x50]
00007cd93bdd17d8  vmovaps xmm6, [rsp+0x60]
00007cd93bdd17de  vmovaps xmm7, [rsp+0x70]
00007cd93bdd17e4  vmovaps xmm8, [rsp+0x80]
00007cd93bdd17ed  vmovaps xmm9, [rsp+0x90]
00007cd93bdd17f6  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd17ff  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd1808  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd1811  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd181a  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd1823  add rsp, 0xF0
00007cd93bdd182a  pop r11
00007cd93bdd182c  pop r10
00007cd93bdd182e  pop r9
00007cd93bdd1830  pop r8
00007cd93bdd1832  pop rsi
00007cd93bdd1833  pop rdi
00007cd93bdd1834  pop rdx
00007cd93bdd1835  pop rcx
00007cd93bdd1836  pop rax
00007cd93bdd1837  add rsp, 0x08
00007cd93bdd183b  jmp 0x00007CD93BDCF923
00007cd93bdd1840  call 0x00007CD93BBFF430
00007cd93bdd1845  jmp 0x00007CD93BDCF930
00007cd93bdd184a  sub rsp, 0x08
00007cd93bdd184e  push rax
00007cd93bdd184f  push rcx
00007cd93bdd1850  push rdx
00007cd93bdd1851  push rdi
00007cd93bdd1852  push rsi
00007cd93bdd1853  push r8
00007cd93bdd1855  push r9
00007cd93bdd1857  push r10
00007cd93bdd1859  push r11
00007cd93bdd185b  sub rsp, 0xF0
00007cd93bdd1862  vmovaps [rsp], xmm0
00007cd93bdd1867  vmovaps [rsp+0x10], xmm1
00007cd93bdd186d  vmovaps [rsp+0x20], xmm3
00007cd93bdd1873  vmovaps [rsp+0x30], xmm4
00007cd93bdd1879  vmovaps [rsp+0x40], xmm5
00007cd93bdd187f  vmovaps [rsp+0x50], xmm6
00007cd93bdd1885  vmovaps [rsp+0x60], xmm7
00007cd93bdd188b  vmovaps [rsp+0x70], xmm8
00007cd93bdd1891  vmovaps [rsp+0x80], xmm9
00007cd93bdd189a  vmovaps [rsp+0x90], xmm10
00007cd93bdd18a3  vmovaps [rsp+0xA0], xmm11
00007cd93bdd18ac  vmovaps [rsp+0xB0], xmm12
00007cd93bdd18b5  vmovaps [rsp+0xC0], xmm13
00007cd93bdd18be  vmovaps [rsp+0xD0], xmm14
00007cd93bdd18c7  vmovaps [rsp+0xE0], xmm15
00007cd93bdd18d0  sub rsp, 0x30
00007cd93bdd18d4  movaps [rsp], xmm2
00007cd93bdd18d8  movaps [rsp+0x10], xmm1
00007cd93bdd18dd  movaps [rsp+0x20], xmm14
00007cd93bdd18e3  lea rdi, [rsp]
00007cd93bdd18e7  mov esi, 0x00
00007cd93bdd18ec  mov rax, 0x64A581057530
00007cd93bdd18f6  call rax
00007cd93bdd18f8  movaps xmm2, [rsp]
00007cd93bdd18fc  add rsp, 0x30
00007cd93bdd1900  vmovaps xmm0, [rsp]
00007cd93bdd1905  vmovaps xmm1, [rsp+0x10]
00007cd93bdd190b  vmovaps xmm3, [rsp+0x20]
00007cd93bdd1911  vmovaps xmm4, [rsp+0x30]
00007cd93bdd1917  vmovaps xmm5, [rsp+0x40]
00007cd93bdd191d  vmovaps xmm6, [rsp+0x50]
00007cd93bdd1923  vmovaps xmm7, [rsp+0x60]
00007cd93bdd1929  vmovaps xmm8, [rsp+0x70]
00007cd93bdd192f  vmovaps xmm9, [rsp+0x80]
00007cd93bdd1938  vmovaps xmm10, [rsp+0x90]
00007cd93bdd1941  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd194a  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd1953  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd195c  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd1965  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd196e  add rsp, 0xF0
00007cd93bdd1975  pop r11
00007cd93bdd1977  pop r10
00007cd93bdd1979  pop r9
00007cd93bdd197b  pop r8
00007cd93bdd197d  pop rsi
00007cd93bdd197e  pop rdi
00007cd93bdd197f  pop rdx
00007cd93bdd1980  pop rcx
00007cd93bdd1981  pop rax
00007cd93bdd1982  add rsp, 0x08
00007cd93bdd1986  jmp 0x00007CD93BDCF96D
00007cd93bdd198b  sub rsp, 0x08
00007cd93bdd198f  push rax
00007cd93bdd1990  push rcx
00007cd93bdd1991  push rdx
00007cd93bdd1992  push rdi
00007cd93bdd1993  push rsi
00007cd93bdd1994  push r8
00007cd93bdd1996  push r9
00007cd93bdd1998  push r10
00007cd93bdd199a  push r11
00007cd93bdd199c  sub rsp, 0xF0
00007cd93bdd19a3  vmovaps [rsp], xmm0
00007cd93bdd19a8  vmovaps [rsp+0x10], xmm1
00007cd93bdd19ae  vmovaps [rsp+0x20], xmm2
00007cd93bdd19b4  vmovaps [rsp+0x30], xmm3
00007cd93bdd19ba  vmovaps [rsp+0x40], xmm4
00007cd93bdd19c0  vmovaps [rsp+0x50], xmm5
00007cd93bdd19c6  vmovaps [rsp+0x60], xmm6
00007cd93bdd19cc  vmovaps [rsp+0x70], xmm7
00007cd93bdd19d2  vmovaps [rsp+0x80], xmm8
00007cd93bdd19db  vmovaps [rsp+0x90], xmm9
00007cd93bdd19e4  vmovaps [rsp+0xA0], xmm10
00007cd93bdd19ed  vmovaps [rsp+0xB0], xmm11
00007cd93bdd19f6  vmovaps [rsp+0xC0], xmm12
00007cd93bdd19ff  vmovaps [rsp+0xD0], xmm13
00007cd93bdd1a08  vmovaps [rsp+0xE0], xmm14
00007cd93bdd1a11  sub rsp, 0x30
00007cd93bdd1a15  movaps [rsp], xmm15
00007cd93bdd1a1a  movaps [rsp+0x10], xmm14
00007cd93bdd1a20  movaps [rsp+0x20], xmm1
00007cd93bdd1a25  lea rdi, [rsp]
00007cd93bdd1a29  mov esi, 0x00
00007cd93bdd1a2e  mov rax, 0x64A581057530
00007cd93bdd1a38  call rax
00007cd93bdd1a3a  movaps xmm15, [rsp]
00007cd93bdd1a3f  add rsp, 0x30
00007cd93bdd1a43  vmovaps xmm0, [rsp]
00007cd93bdd1a48  vmovaps xmm1, [rsp+0x10]
00007cd93bdd1a4e  vmovaps xmm2, [rsp+0x20]
00007cd93bdd1a54  vmovaps xmm3, [rsp+0x30]
00007cd93bdd1a5a  vmovaps xmm4, [rsp+0x40]
00007cd93bdd1a60  vmovaps xmm5, [rsp+0x50]
00007cd93bdd1a66  vmovaps xmm6, [rsp+0x60]
00007cd93bdd1a6c  vmovaps xmm7, [rsp+0x70]
00007cd93bdd1a72  vmovaps xmm8, [rsp+0x80]
00007cd93bdd1a7b  vmovaps xmm9, [rsp+0x90]
00007cd93bdd1a84  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd1a8d  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd1a96  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd1a9f  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd1aa8  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd1ab1  add rsp, 0xF0
00007cd93bdd1ab8  pop r11
00007cd93bdd1aba  pop r10
00007cd93bdd1abc  pop r9
00007cd93bdd1abe  pop r8
00007cd93bdd1ac0  pop rsi
00007cd93bdd1ac1  pop rdi
00007cd93bdd1ac2  pop rdx
00007cd93bdd1ac3  pop rcx
00007cd93bdd1ac4  pop rax
00007cd93bdd1ac5  add rsp, 0x08
00007cd93bdd1ac9  jmp 0x00007CD93BDCF9E7
00007cd93bdd1ace  call 0x00007CD93BBFF430
00007cd93bdd1ad3  jmp 0x00007CD93BDCF9F4
00007cd93bdd1ad8  sub rsp, 0x08
00007cd93bdd1adc  push rax
00007cd93bdd1add  push rcx
00007cd93bdd1ade  push rdx
00007cd93bdd1adf  push rdi
00007cd93bdd1ae0  push rsi
00007cd93bdd1ae1  push r8
00007cd93bdd1ae3  push r9
00007cd93bdd1ae5  push r10
00007cd93bdd1ae7  push r11
00007cd93bdd1ae9  sub rsp, 0xF0
00007cd93bdd1af0  vmovaps [rsp], xmm0
00007cd93bdd1af5  vmovaps [rsp+0x10], xmm1
00007cd93bdd1afb  vmovaps [rsp+0x20], xmm2
00007cd93bdd1b01  vmovaps [rsp+0x30], xmm3
00007cd93bdd1b07  vmovaps [rsp+0x40], xmm4
00007cd93bdd1b0d  vmovaps [rsp+0x50], xmm5
00007cd93bdd1b13  vmovaps [rsp+0x60], xmm6
00007cd93bdd1b19  vmovaps [rsp+0x70], xmm7
00007cd93bdd1b1f  vmovaps [rsp+0x80], xmm8
00007cd93bdd1b28  vmovaps [rsp+0x90], xmm9
00007cd93bdd1b31  vmovaps [rsp+0xA0], xmm10
00007cd93bdd1b3a  vmovaps [rsp+0xB0], xmm11
00007cd93bdd1b43  vmovaps [rsp+0xC0], xmm12
00007cd93bdd1b4c  vmovaps [rsp+0xD0], xmm13
00007cd93bdd1b55  vmovaps [rsp+0xE0], xmm15
00007cd93bdd1b5e  sub rsp, 0x30
00007cd93bdd1b62  movaps [rsp], xmm14
00007cd93bdd1b67  movaps [rsp+0x10], xmm13
00007cd93bdd1b6d  movaps [rsp+0x20], xmm1
00007cd93bdd1b72  lea rdi, [rsp]
00007cd93bdd1b76  mov esi, 0x00
00007cd93bdd1b7b  mov rax, 0x64A581057530
00007cd93bdd1b85  call rax
00007cd93bdd1b87  movaps xmm14, [rsp]
00007cd93bdd1b8c  add rsp, 0x30
00007cd93bdd1b90  vmovaps xmm0, [rsp]
00007cd93bdd1b95  vmovaps xmm1, [rsp+0x10]
00007cd93bdd1b9b  vmovaps xmm2, [rsp+0x20]
00007cd93bdd1ba1  vmovaps xmm3, [rsp+0x30]
00007cd93bdd1ba7  vmovaps xmm4, [rsp+0x40]
00007cd93bdd1bad  vmovaps xmm5, [rsp+0x50]
00007cd93bdd1bb3  vmovaps xmm6, [rsp+0x60]
00007cd93bdd1bb9  vmovaps xmm7, [rsp+0x70]
00007cd93bdd1bbf  vmovaps xmm8, [rsp+0x80]
00007cd93bdd1bc8  vmovaps xmm9, [rsp+0x90]
00007cd93bdd1bd1  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd1bda  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd1be3  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd1bec  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd1bf5  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd1bfe  add rsp, 0xF0
00007cd93bdd1c05  pop r11
00007cd93bdd1c07  pop r10
00007cd93bdd1c09  pop r9
00007cd93bdd1c0b  pop r8
00007cd93bdd1c0d  pop rsi
00007cd93bdd1c0e  pop rdi
00007cd93bdd1c0f  pop rdx
00007cd93bdd1c10  pop rcx
00007cd93bdd1c11  pop rax
00007cd93bdd1c12  add rsp, 0x08
00007cd93bdd1c16  jmp 0x00007CD93BDCFAAF
00007cd93bdd1c1b  sub rsp, 0x08
00007cd93bdd1c1f  push rax
00007cd93bdd1c20  push rcx
00007cd93bdd1c21  push rdx
00007cd93bdd1c22  push rdi
00007cd93bdd1c23  push rsi
00007cd93bdd1c24  push r8
00007cd93bdd1c26  push r9
00007cd93bdd1c28  push r10
00007cd93bdd1c2a  push r11
00007cd93bdd1c2c  sub rsp, 0xF0
00007cd93bdd1c33  vmovaps [rsp], xmm0
00007cd93bdd1c38  vmovaps [rsp+0x10], xmm1
00007cd93bdd1c3e  vmovaps [rsp+0x20], xmm2
00007cd93bdd1c44  vmovaps [rsp+0x30], xmm3
00007cd93bdd1c4a  vmovaps [rsp+0x40], xmm4
00007cd93bdd1c50  vmovaps [rsp+0x50], xmm5
00007cd93bdd1c56  vmovaps [rsp+0x60], xmm6
00007cd93bdd1c5c  vmovaps [rsp+0x70], xmm7
00007cd93bdd1c62  vmovaps [rsp+0x80], xmm8
00007cd93bdd1c6b  vmovaps [rsp+0x90], xmm9
00007cd93bdd1c74  vmovaps [rsp+0xA0], xmm10
00007cd93bdd1c7d  vmovaps [rsp+0xB0], xmm11
00007cd93bdd1c86  vmovaps [rsp+0xC0], xmm12
00007cd93bdd1c8f  vmovaps [rsp+0xD0], xmm13
00007cd93bdd1c98  vmovaps [rsp+0xE0], xmm14
00007cd93bdd1ca1  sub rsp, 0x30
00007cd93bdd1ca5  movaps [rsp], xmm15
00007cd93bdd1caa  movaps [rsp+0x10], xmm13
00007cd93bdd1cb0  movaps [rsp+0x20], xmm1
00007cd93bdd1cb5  lea rdi, [rsp]
00007cd93bdd1cb9  mov esi, 0x00
00007cd93bdd1cbe  mov rax, 0x64A581057530
00007cd93bdd1cc8  call rax
00007cd93bdd1cca  movaps xmm15, [rsp]
00007cd93bdd1ccf  add rsp, 0x30
00007cd93bdd1cd3  vmovaps xmm0, [rsp]
00007cd93bdd1cd8  vmovaps xmm1, [rsp+0x10]
00007cd93bdd1cde  vmovaps xmm2, [rsp+0x20]
00007cd93bdd1ce4  vmovaps xmm3, [rsp+0x30]
00007cd93bdd1cea  vmovaps xmm4, [rsp+0x40]
00007cd93bdd1cf0  vmovaps xmm5, [rsp+0x50]
00007cd93bdd1cf6  vmovaps xmm6, [rsp+0x60]
00007cd93bdd1cfc  vmovaps xmm7, [rsp+0x70]
00007cd93bdd1d02  vmovaps xmm8, [rsp+0x80]
00007cd93bdd1d0b  vmovaps xmm9, [rsp+0x90]
00007cd93bdd1d14  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd1d1d  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd1d26  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd1d2f  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd1d38  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd1d41  add rsp, 0xF0
00007cd93bdd1d48  pop r11
00007cd93bdd1d4a  pop r10
00007cd93bdd1d4c  pop r9
00007cd93bdd1d4e  pop r8
00007cd93bdd1d50  pop rsi
00007cd93bdd1d51  pop rdi
00007cd93bdd1d52  pop rdx
00007cd93bdd1d53  pop rcx
00007cd93bdd1d54  pop rax
00007cd93bdd1d55  add rsp, 0x08
00007cd93bdd1d59  jmp 0x00007CD93BDCFAEB
00007cd93bdd1d5e  call 0x00007CD93BBFF430
00007cd93bdd1d63  jmp 0x00007CD93BDCFAF8
00007cd93bdd1d68  sub rsp, 0x08
00007cd93bdd1d6c  push rax
00007cd93bdd1d6d  push rcx
00007cd93bdd1d6e  push rdx
00007cd93bdd1d6f  push rdi
00007cd93bdd1d70  push rsi
00007cd93bdd1d71  push r8
00007cd93bdd1d73  push r9
00007cd93bdd1d75  push r10
00007cd93bdd1d77  push r11
00007cd93bdd1d79  sub rsp, 0xF0
00007cd93bdd1d80  vmovaps [rsp], xmm0
00007cd93bdd1d85  vmovaps [rsp+0x10], xmm1
00007cd93bdd1d8b  vmovaps [rsp+0x20], xmm2
00007cd93bdd1d91  vmovaps [rsp+0x30], xmm3
00007cd93bdd1d97  vmovaps [rsp+0x40], xmm4
00007cd93bdd1d9d  vmovaps [rsp+0x50], xmm5
00007cd93bdd1da3  vmovaps [rsp+0x60], xmm6
00007cd93bdd1da9  vmovaps [rsp+0x70], xmm7
00007cd93bdd1daf  vmovaps [rsp+0x80], xmm8
00007cd93bdd1db8  vmovaps [rsp+0x90], xmm9
00007cd93bdd1dc1  vmovaps [rsp+0xA0], xmm10
00007cd93bdd1dca  vmovaps [rsp+0xB0], xmm11
00007cd93bdd1dd3  vmovaps [rsp+0xC0], xmm12
00007cd93bdd1ddc  vmovaps [rsp+0xD0], xmm13
00007cd93bdd1de5  vmovaps [rsp+0xE0], xmm15
00007cd93bdd1dee  sub rsp, 0x30
00007cd93bdd1df2  movaps [rsp], xmm14
00007cd93bdd1df7  movaps [rsp+0x10], xmm13
00007cd93bdd1dfd  movaps [rsp+0x20], xmm2
00007cd93bdd1e02  lea rdi, [rsp]
00007cd93bdd1e06  mov esi, 0x00
00007cd93bdd1e0b  mov rax, 0x64A581057530
00007cd93bdd1e15  call rax
00007cd93bdd1e17  movaps xmm14, [rsp]
00007cd93bdd1e1c  add rsp, 0x30
00007cd93bdd1e20  vmovaps xmm0, [rsp]
00007cd93bdd1e25  vmovaps xmm1, [rsp+0x10]
00007cd93bdd1e2b  vmovaps xmm2, [rsp+0x20]
00007cd93bdd1e31  vmovaps xmm3, [rsp+0x30]
00007cd93bdd1e37  vmovaps xmm4, [rsp+0x40]
00007cd93bdd1e3d  vmovaps xmm5, [rsp+0x50]
00007cd93bdd1e43  vmovaps xmm6, [rsp+0x60]
00007cd93bdd1e49  vmovaps xmm7, [rsp+0x70]
00007cd93bdd1e4f  vmovaps xmm8, [rsp+0x80]
00007cd93bdd1e58  vmovaps xmm9, [rsp+0x90]
00007cd93bdd1e61  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd1e6a  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd1e73  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd1e7c  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd1e85  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd1e8e  add rsp, 0xF0
00007cd93bdd1e95  pop r11
00007cd93bdd1e97  pop r10
00007cd93bdd1e99  pop r9
00007cd93bdd1e9b  pop r8
00007cd93bdd1e9d  pop rsi
00007cd93bdd1e9e  pop rdi
00007cd93bdd1e9f  pop rdx
00007cd93bdd1ea0  pop rcx
00007cd93bdd1ea1  pop rax
00007cd93bdd1ea2  add rsp, 0x08
00007cd93bdd1ea6  jmp 0x00007CD93BDCFB24
00007cd93bdd1eab  sub rsp, 0x08
00007cd93bdd1eaf  push rax
00007cd93bdd1eb0  push rcx
00007cd93bdd1eb1  push rdx
00007cd93bdd1eb2  push rdi
00007cd93bdd1eb3  push rsi
00007cd93bdd1eb4  push r8
00007cd93bdd1eb6  push r9
00007cd93bdd1eb8  push r10
00007cd93bdd1eba  push r11
00007cd93bdd1ebc  sub rsp, 0xF0
00007cd93bdd1ec3  vmovaps [rsp], xmm0
00007cd93bdd1ec8  vmovaps [rsp+0x10], xmm2
00007cd93bdd1ece  vmovaps [rsp+0x20], xmm3
00007cd93bdd1ed4  vmovaps [rsp+0x30], xmm4
00007cd93bdd1eda  vmovaps [rsp+0x40], xmm5
00007cd93bdd1ee0  vmovaps [rsp+0x50], xmm6
00007cd93bdd1ee6  vmovaps [rsp+0x60], xmm7
00007cd93bdd1eec  vmovaps [rsp+0x70], xmm8
00007cd93bdd1ef2  vmovaps [rsp+0x80], xmm9
00007cd93bdd1efb  vmovaps [rsp+0x90], xmm10
00007cd93bdd1f04  vmovaps [rsp+0xA0], xmm11
00007cd93bdd1f0d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd1f16  vmovaps [rsp+0xC0], xmm13
00007cd93bdd1f1f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd1f28  vmovaps [rsp+0xE0], xmm15
00007cd93bdd1f31  sub rsp, 0x30
00007cd93bdd1f35  movaps [rsp], xmm1
00007cd93bdd1f39  movaps [rsp+0x10], xmm13
00007cd93bdd1f3f  movaps [rsp+0x20], xmm2
00007cd93bdd1f44  lea rdi, [rsp]
00007cd93bdd1f48  mov esi, 0x00
00007cd93bdd1f4d  mov rax, 0x64A581057530
00007cd93bdd1f57  call rax
00007cd93bdd1f59  movaps xmm1, [rsp]
00007cd93bdd1f5d  add rsp, 0x30
00007cd93bdd1f61  vmovaps xmm0, [rsp]
00007cd93bdd1f66  vmovaps xmm2, [rsp+0x10]
00007cd93bdd1f6c  vmovaps xmm3, [rsp+0x20]
00007cd93bdd1f72  vmovaps xmm4, [rsp+0x30]
00007cd93bdd1f78  vmovaps xmm5, [rsp+0x40]
00007cd93bdd1f7e  vmovaps xmm6, [rsp+0x50]
00007cd93bdd1f84  vmovaps xmm7, [rsp+0x60]
00007cd93bdd1f8a  vmovaps xmm8, [rsp+0x70]
00007cd93bdd1f90  vmovaps xmm9, [rsp+0x80]
00007cd93bdd1f99  vmovaps xmm10, [rsp+0x90]
00007cd93bdd1fa2  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd1fab  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd1fb4  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd1fbd  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd1fc6  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd1fcf  add rsp, 0xF0
00007cd93bdd1fd6  pop r11
00007cd93bdd1fd8  pop r10
00007cd93bdd1fda  pop r9
00007cd93bdd1fdc  pop r8
00007cd93bdd1fde  pop rsi
00007cd93bdd1fdf  pop rdi
00007cd93bdd1fe0  pop rdx
00007cd93bdd1fe1  pop rcx
00007cd93bdd1fe2  pop rax
00007cd93bdd1fe3  add rsp, 0x08
00007cd93bdd1fe7  jmp 0x00007CD93BDCFB52
00007cd93bdd1fec  sub rsp, 0x08
00007cd93bdd1ff0  push rax
00007cd93bdd1ff1  push rcx
00007cd93bdd1ff2  push rdx
00007cd93bdd1ff3  push rdi
00007cd93bdd1ff4  push rsi
00007cd93bdd1ff5  push r8
00007cd93bdd1ff7  push r9
00007cd93bdd1ff9  push r10
00007cd93bdd1ffb  push r11
00007cd93bdd1ffd  sub rsp, 0xF0
00007cd93bdd2004  vmovaps [rsp], xmm0
00007cd93bdd2009  vmovaps [rsp+0x10], xmm1
00007cd93bdd200f  vmovaps [rsp+0x20], xmm3
00007cd93bdd2015  vmovaps [rsp+0x30], xmm4
00007cd93bdd201b  vmovaps [rsp+0x40], xmm5
00007cd93bdd2021  vmovaps [rsp+0x50], xmm6
00007cd93bdd2027  vmovaps [rsp+0x60], xmm7
00007cd93bdd202d  vmovaps [rsp+0x70], xmm8
00007cd93bdd2033  vmovaps [rsp+0x80], xmm9
00007cd93bdd203c  vmovaps [rsp+0x90], xmm10
00007cd93bdd2045  vmovaps [rsp+0xA0], xmm11
00007cd93bdd204e  vmovaps [rsp+0xB0], xmm12
00007cd93bdd2057  vmovaps [rsp+0xC0], xmm13
00007cd93bdd2060  vmovaps [rsp+0xD0], xmm14
00007cd93bdd2069  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2072  sub rsp, 0x30
00007cd93bdd2076  movaps [rsp], xmm2
00007cd93bdd207a  movaps [rsp+0x10], xmm1
00007cd93bdd207f  movaps [rsp+0x20], xmm13
00007cd93bdd2085  lea rdi, [rsp]
00007cd93bdd2089  mov esi, 0x00
00007cd93bdd208e  mov rax, 0x64A581057530
00007cd93bdd2098  call rax
00007cd93bdd209a  movaps xmm2, [rsp]
00007cd93bdd209e  add rsp, 0x30
00007cd93bdd20a2  vmovaps xmm0, [rsp]
00007cd93bdd20a7  vmovaps xmm1, [rsp+0x10]
00007cd93bdd20ad  vmovaps xmm3, [rsp+0x20]
00007cd93bdd20b3  vmovaps xmm4, [rsp+0x30]
00007cd93bdd20b9  vmovaps xmm5, [rsp+0x40]
00007cd93bdd20bf  vmovaps xmm6, [rsp+0x50]
00007cd93bdd20c5  vmovaps xmm7, [rsp+0x60]
00007cd93bdd20cb  vmovaps xmm8, [rsp+0x70]
00007cd93bdd20d1  vmovaps xmm9, [rsp+0x80]
00007cd93bdd20da  vmovaps xmm10, [rsp+0x90]
00007cd93bdd20e3  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd20ec  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd20f5  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd20fe  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd2107  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd2110  add rsp, 0xF0
00007cd93bdd2117  pop r11
00007cd93bdd2119  pop r10
00007cd93bdd211b  pop r9
00007cd93bdd211d  pop r8
00007cd93bdd211f  pop rsi
00007cd93bdd2120  pop rdi
00007cd93bdd2121  pop rdx
00007cd93bdd2122  pop rcx
00007cd93bdd2123  pop rax
00007cd93bdd2124  add rsp, 0x08
00007cd93bdd2128  jmp 0x00007CD93BDCFBAB
00007cd93bdd212d  call 0x00007CD93BBFF430
00007cd93bdd2132  jmp 0x00007CD93BDCFBB8
00007cd93bdd2137  sub rsp, 0x08
00007cd93bdd213b  push rax
00007cd93bdd213c  push rcx
00007cd93bdd213d  push rdx
00007cd93bdd213e  push rdi
00007cd93bdd213f  push rsi
00007cd93bdd2140  push r8
00007cd93bdd2142  push r9
00007cd93bdd2144  push r10
00007cd93bdd2146  push r11
00007cd93bdd2148  sub rsp, 0xF0
00007cd93bdd214f  vmovaps [rsp], xmm0
00007cd93bdd2154  vmovaps [rsp+0x10], xmm1
00007cd93bdd215a  vmovaps [rsp+0x20], xmm2
00007cd93bdd2160  vmovaps [rsp+0x30], xmm3
00007cd93bdd2166  vmovaps [rsp+0x40], xmm4
00007cd93bdd216c  vmovaps [rsp+0x50], xmm5
00007cd93bdd2172  vmovaps [rsp+0x60], xmm6
00007cd93bdd2178  vmovaps [rsp+0x70], xmm7
00007cd93bdd217e  vmovaps [rsp+0x80], xmm8
00007cd93bdd2187  vmovaps [rsp+0x90], xmm9
00007cd93bdd2190  vmovaps [rsp+0xA0], xmm10
00007cd93bdd2199  vmovaps [rsp+0xB0], xmm11
00007cd93bdd21a2  vmovaps [rsp+0xC0], xmm12
00007cd93bdd21ab  vmovaps [rsp+0xD0], xmm13
00007cd93bdd21b4  vmovaps [rsp+0xE0], xmm14
00007cd93bdd21bd  sub rsp, 0x30
00007cd93bdd21c1  movaps [rsp], xmm15
00007cd93bdd21c6  movaps [rsp+0x10], xmm13
00007cd93bdd21cc  movaps [rsp+0x20], xmm1
00007cd93bdd21d1  lea rdi, [rsp]
00007cd93bdd21d5  mov esi, 0x00
00007cd93bdd21da  mov rax, 0x64A581057530
00007cd93bdd21e4  call rax
00007cd93bdd21e6  movaps xmm15, [rsp]
00007cd93bdd21eb  add rsp, 0x30
00007cd93bdd21ef  vmovaps xmm0, [rsp]
00007cd93bdd21f4  vmovaps xmm1, [rsp+0x10]
00007cd93bdd21fa  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2200  vmovaps xmm3, [rsp+0x30]
00007cd93bdd2206  vmovaps xmm4, [rsp+0x40]
00007cd93bdd220c  vmovaps xmm5, [rsp+0x50]
00007cd93bdd2212  vmovaps xmm6, [rsp+0x60]
00007cd93bdd2218  vmovaps xmm7, [rsp+0x70]
00007cd93bdd221e  vmovaps xmm8, [rsp+0x80]
00007cd93bdd2227  vmovaps xmm9, [rsp+0x90]
00007cd93bdd2230  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd2239  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd2242  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd224b  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd2254  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd225d  add rsp, 0xF0
00007cd93bdd2264  pop r11
00007cd93bdd2266  pop r10
00007cd93bdd2268  pop r9
00007cd93bdd226a  pop r8
00007cd93bdd226c  pop rsi
00007cd93bdd226d  pop rdi
00007cd93bdd226e  pop rdx
00007cd93bdd226f  pop rcx
00007cd93bdd2270  pop rax
00007cd93bdd2271  add rsp, 0x08
00007cd93bdd2275  jmp 0x00007CD93BDCFBF7
00007cd93bdd227a  sub rsp, 0x08
00007cd93bdd227e  push rax
00007cd93bdd227f  push rcx
00007cd93bdd2280  push rdx
00007cd93bdd2281  push rdi
00007cd93bdd2282  push rsi
00007cd93bdd2283  push r8
00007cd93bdd2285  push r9
00007cd93bdd2287  push r10
00007cd93bdd2289  push r11
00007cd93bdd228b  sub rsp, 0xF0
00007cd93bdd2292  vmovaps [rsp], xmm0
00007cd93bdd2297  vmovaps [rsp+0x10], xmm1
00007cd93bdd229d  vmovaps [rsp+0x20], xmm2
00007cd93bdd22a3  vmovaps [rsp+0x30], xmm3
00007cd93bdd22a9  vmovaps [rsp+0x40], xmm4
00007cd93bdd22af  vmovaps [rsp+0x50], xmm5
00007cd93bdd22b5  vmovaps [rsp+0x60], xmm6
00007cd93bdd22bb  vmovaps [rsp+0x70], xmm7
00007cd93bdd22c1  vmovaps [rsp+0x80], xmm8
00007cd93bdd22ca  vmovaps [rsp+0x90], xmm9
00007cd93bdd22d3  vmovaps [rsp+0xA0], xmm10
00007cd93bdd22dc  vmovaps [rsp+0xB0], xmm11
00007cd93bdd22e5  vmovaps [rsp+0xC0], xmm12
00007cd93bdd22ee  vmovaps [rsp+0xD0], xmm13
00007cd93bdd22f7  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2300  sub rsp, 0x30
00007cd93bdd2304  movaps [rsp], xmm14
00007cd93bdd2309  movaps [rsp+0x10], xmm11
00007cd93bdd230f  movaps [rsp+0x20], xmm1
00007cd93bdd2314  lea rdi, [rsp]
00007cd93bdd2318  mov esi, 0x00
00007cd93bdd231d  mov rax, 0x64A581057530
00007cd93bdd2327  call rax
00007cd93bdd2329  movaps xmm14, [rsp]
00007cd93bdd232e  add rsp, 0x30
00007cd93bdd2332  vmovaps xmm0, [rsp]
00007cd93bdd2337  vmovaps xmm1, [rsp+0x10]
00007cd93bdd233d  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2343  vmovaps xmm3, [rsp+0x30]
00007cd93bdd2349  vmovaps xmm4, [rsp+0x40]
00007cd93bdd234f  vmovaps xmm5, [rsp+0x50]
00007cd93bdd2355  vmovaps xmm6, [rsp+0x60]
00007cd93bdd235b  vmovaps xmm7, [rsp+0x70]
00007cd93bdd2361  vmovaps xmm8, [rsp+0x80]
00007cd93bdd236a  vmovaps xmm9, [rsp+0x90]
00007cd93bdd2373  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd237c  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd2385  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd238e  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd2397  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd23a0  add rsp, 0xF0
00007cd93bdd23a7  pop r11
00007cd93bdd23a9  pop r10
00007cd93bdd23ab  pop r9
00007cd93bdd23ad  pop r8
00007cd93bdd23af  pop rsi
00007cd93bdd23b0  pop rdi
00007cd93bdd23b1  pop rdx
00007cd93bdd23b2  pop rcx
00007cd93bdd23b3  pop rax
00007cd93bdd23b4  add rsp, 0x08
00007cd93bdd23b8  jmp 0x00007CD93BDCFC21
00007cd93bdd23bd  sub rsp, 0x08
00007cd93bdd23c1  push rax
00007cd93bdd23c2  push rcx
00007cd93bdd23c3  push rdx
00007cd93bdd23c4  push rdi
00007cd93bdd23c5  push rsi
00007cd93bdd23c6  push r8
00007cd93bdd23c8  push r9
00007cd93bdd23ca  push r10
00007cd93bdd23cc  push r11
00007cd93bdd23ce  sub rsp, 0xF0
00007cd93bdd23d5  vmovaps [rsp], xmm0
00007cd93bdd23da  vmovaps [rsp+0x10], xmm1
00007cd93bdd23e0  vmovaps [rsp+0x20], xmm2
00007cd93bdd23e6  vmovaps [rsp+0x30], xmm3
00007cd93bdd23ec  vmovaps [rsp+0x40], xmm4
00007cd93bdd23f2  vmovaps [rsp+0x50], xmm5
00007cd93bdd23f8  vmovaps [rsp+0x60], xmm6
00007cd93bdd23fe  vmovaps [rsp+0x70], xmm7
00007cd93bdd2404  vmovaps [rsp+0x80], xmm8
00007cd93bdd240d  vmovaps [rsp+0x90], xmm9
00007cd93bdd2416  vmovaps [rsp+0xA0], xmm10
00007cd93bdd241f  vmovaps [rsp+0xB0], xmm11
00007cd93bdd2428  vmovaps [rsp+0xC0], xmm12
00007cd93bdd2431  vmovaps [rsp+0xD0], xmm14
00007cd93bdd243a  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2443  sub rsp, 0x30
00007cd93bdd2447  movaps [rsp], xmm13
00007cd93bdd244c  movaps [rsp+0x10], xmm11
00007cd93bdd2452  movaps [rsp+0x20], xmm1
00007cd93bdd2457  lea rdi, [rsp]
00007cd93bdd245b  mov esi, 0x00
00007cd93bdd2460  mov rax, 0x64A581057530
00007cd93bdd246a  call rax
00007cd93bdd246c  movaps xmm13, [rsp]
00007cd93bdd2471  add rsp, 0x30
00007cd93bdd2475  vmovaps xmm0, [rsp]
00007cd93bdd247a  vmovaps xmm1, [rsp+0x10]
00007cd93bdd2480  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2486  vmovaps xmm3, [rsp+0x30]
00007cd93bdd248c  vmovaps xmm4, [rsp+0x40]
00007cd93bdd2492  vmovaps xmm5, [rsp+0x50]
00007cd93bdd2498  vmovaps xmm6, [rsp+0x60]
00007cd93bdd249e  vmovaps xmm7, [rsp+0x70]
00007cd93bdd24a4  vmovaps xmm8, [rsp+0x80]
00007cd93bdd24ad  vmovaps xmm9, [rsp+0x90]
00007cd93bdd24b6  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd24bf  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd24c8  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd24d1  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd24da  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd24e3  add rsp, 0xF0
00007cd93bdd24ea  pop r11
00007cd93bdd24ec  pop r10
00007cd93bdd24ee  pop r9
00007cd93bdd24f0  pop r8
00007cd93bdd24f2  pop rsi
00007cd93bdd24f3  pop rdi
00007cd93bdd24f4  pop rdx
00007cd93bdd24f5  pop rcx
00007cd93bdd24f6  pop rax
00007cd93bdd24f7  add rsp, 0x08
00007cd93bdd24fb  jmp 0x00007CD93BDCFC76
00007cd93bdd2500  call 0x00007CD93BBFF430
00007cd93bdd2505  jmp 0x00007CD93BDCFC83
00007cd93bdd250a  sub rsp, 0x08
00007cd93bdd250e  push rax
00007cd93bdd250f  push rcx
00007cd93bdd2510  push rdx
00007cd93bdd2511  push rdi
00007cd93bdd2512  push rsi
00007cd93bdd2513  push r8
00007cd93bdd2515  push r9
00007cd93bdd2517  push r10
00007cd93bdd2519  push r11
00007cd93bdd251b  sub rsp, 0xF0
00007cd93bdd2522  vmovaps [rsp], xmm0
00007cd93bdd2527  vmovaps [rsp+0x10], xmm1
00007cd93bdd252d  vmovaps [rsp+0x20], xmm2
00007cd93bdd2533  vmovaps [rsp+0x30], xmm3
00007cd93bdd2539  vmovaps [rsp+0x40], xmm4
00007cd93bdd253f  vmovaps [rsp+0x50], xmm5
00007cd93bdd2545  vmovaps [rsp+0x60], xmm6
00007cd93bdd254b  vmovaps [rsp+0x70], xmm7
00007cd93bdd2551  vmovaps [rsp+0x80], xmm8
00007cd93bdd255a  vmovaps [rsp+0x90], xmm9
00007cd93bdd2563  vmovaps [rsp+0xA0], xmm10
00007cd93bdd256c  vmovaps [rsp+0xB0], xmm11
00007cd93bdd2575  vmovaps [rsp+0xC0], xmm12
00007cd93bdd257e  vmovaps [rsp+0xD0], xmm13
00007cd93bdd2587  vmovaps [rsp+0xE0], xmm14
00007cd93bdd2590  sub rsp, 0x30
00007cd93bdd2594  movaps [rsp], xmm15
00007cd93bdd2599  movaps [rsp+0x10], xmm11
00007cd93bdd259f  movaps [rsp+0x20], xmm1
00007cd93bdd25a4  lea rdi, [rsp]
00007cd93bdd25a8  mov esi, 0x00
00007cd93bdd25ad  mov rax, 0x64A581057530
00007cd93bdd25b7  call rax
00007cd93bdd25b9  movaps xmm15, [rsp]
00007cd93bdd25be  add rsp, 0x30
00007cd93bdd25c2  vmovaps xmm0, [rsp]
00007cd93bdd25c7  vmovaps xmm1, [rsp+0x10]
00007cd93bdd25cd  vmovaps xmm2, [rsp+0x20]
00007cd93bdd25d3  vmovaps xmm3, [rsp+0x30]
00007cd93bdd25d9  vmovaps xmm4, [rsp+0x40]
00007cd93bdd25df  vmovaps xmm5, [rsp+0x50]
00007cd93bdd25e5  vmovaps xmm6, [rsp+0x60]
00007cd93bdd25eb  vmovaps xmm7, [rsp+0x70]
00007cd93bdd25f1  vmovaps xmm8, [rsp+0x80]
00007cd93bdd25fa  vmovaps xmm9, [rsp+0x90]
00007cd93bdd2603  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd260c  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd2615  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd261e  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd2627  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd2630  add rsp, 0xF0
00007cd93bdd2637  pop r11
00007cd93bdd2639  pop r10
00007cd93bdd263b  pop r9
00007cd93bdd263d  pop r8
00007cd93bdd263f  pop rsi
00007cd93bdd2640  pop rdi
00007cd93bdd2641  pop rdx
00007cd93bdd2642  pop rcx
00007cd93bdd2643  pop rax
00007cd93bdd2644  add rsp, 0x08
00007cd93bdd2648  jmp 0x00007CD93BDCFCBC
00007cd93bdd264d  sub rsp, 0x08
00007cd93bdd2651  push rax
00007cd93bdd2652  push rcx
00007cd93bdd2653  push rdx
00007cd93bdd2654  push rdi
00007cd93bdd2655  push rsi
00007cd93bdd2656  push r8
00007cd93bdd2658  push r9
00007cd93bdd265a  push r10
00007cd93bdd265c  push r11
00007cd93bdd265e  sub rsp, 0xF0
00007cd93bdd2665  vmovaps [rsp], xmm0
00007cd93bdd266a  vmovaps [rsp+0x10], xmm1
00007cd93bdd2670  vmovaps [rsp+0x20], xmm2
00007cd93bdd2676  vmovaps [rsp+0x30], xmm3
00007cd93bdd267c  vmovaps [rsp+0x40], xmm4
00007cd93bdd2682  vmovaps [rsp+0x50], xmm5
00007cd93bdd2688  vmovaps [rsp+0x60], xmm6
00007cd93bdd268e  vmovaps [rsp+0x70], xmm7
00007cd93bdd2694  vmovaps [rsp+0x80], xmm8
00007cd93bdd269d  vmovaps [rsp+0x90], xmm9
00007cd93bdd26a6  vmovaps [rsp+0xA0], xmm10
00007cd93bdd26af  vmovaps [rsp+0xB0], xmm12
00007cd93bdd26b8  vmovaps [rsp+0xC0], xmm13
00007cd93bdd26c1  vmovaps [rsp+0xD0], xmm14
00007cd93bdd26ca  vmovaps [rsp+0xE0], xmm15
00007cd93bdd26d3  sub rsp, 0x30
00007cd93bdd26d7  movaps [rsp], xmm11
00007cd93bdd26dc  movaps [rsp+0x10], xmm6
00007cd93bdd26e1  movaps [rsp+0x20], xmm14
00007cd93bdd26e7  lea rdi, [rsp]
00007cd93bdd26eb  mov esi, 0x00
00007cd93bdd26f0  mov rax, 0x64A581057530
00007cd93bdd26fa  call rax
00007cd93bdd26fc  movaps xmm11, [rsp]
00007cd93bdd2701  add rsp, 0x30
00007cd93bdd2705  vmovaps xmm0, [rsp]
00007cd93bdd270a  vmovaps xmm1, [rsp+0x10]
00007cd93bdd2710  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2716  vmovaps xmm3, [rsp+0x30]
00007cd93bdd271c  vmovaps xmm4, [rsp+0x40]
00007cd93bdd2722  vmovaps xmm5, [rsp+0x50]
00007cd93bdd2728  vmovaps xmm6, [rsp+0x60]
00007cd93bdd272e  vmovaps xmm7, [rsp+0x70]
00007cd93bdd2734  vmovaps xmm8, [rsp+0x80]
00007cd93bdd273d  vmovaps xmm9, [rsp+0x90]
00007cd93bdd2746  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd274f  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd2758  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd2761  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd276a  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd2773  add rsp, 0xF0
00007cd93bdd277a  pop r11
00007cd93bdd277c  pop r10
00007cd93bdd277e  pop r9
00007cd93bdd2780  pop r8
00007cd93bdd2782  pop rsi
00007cd93bdd2783  pop rdi
00007cd93bdd2784  pop rdx
00007cd93bdd2785  pop rcx
00007cd93bdd2786  pop rax
00007cd93bdd2787  add rsp, 0x08
00007cd93bdd278b  jmp 0x00007CD93BDCFD34
00007cd93bdd2790  call 0x00007CD93BBFF430
00007cd93bdd2795  jmp 0x00007CD93BDCFD3E
00007cd93bdd279a  sub rsp, 0x08
00007cd93bdd279e  push rax
00007cd93bdd279f  push rcx
00007cd93bdd27a0  push rdx
00007cd93bdd27a1  push rdi
00007cd93bdd27a2  push rsi
00007cd93bdd27a3  push r8
00007cd93bdd27a5  push r9
00007cd93bdd27a7  push r10
00007cd93bdd27a9  push r11
00007cd93bdd27ab  sub rsp, 0xF0
00007cd93bdd27b2  vmovaps [rsp], xmm0
00007cd93bdd27b7  vmovaps [rsp+0x10], xmm1
00007cd93bdd27bd  vmovaps [rsp+0x20], xmm2
00007cd93bdd27c3  vmovaps [rsp+0x30], xmm3
00007cd93bdd27c9  vmovaps [rsp+0x40], xmm4
00007cd93bdd27cf  vmovaps [rsp+0x50], xmm5
00007cd93bdd27d5  vmovaps [rsp+0x60], xmm6
00007cd93bdd27db  vmovaps [rsp+0x70], xmm7
00007cd93bdd27e1  vmovaps [rsp+0x80], xmm8
00007cd93bdd27ea  vmovaps [rsp+0x90], xmm9
00007cd93bdd27f3  vmovaps [rsp+0xA0], xmm10
00007cd93bdd27fc  vmovaps [rsp+0xB0], xmm11
00007cd93bdd2805  vmovaps [rsp+0xC0], xmm12
00007cd93bdd280e  vmovaps [rsp+0xD0], xmm13
00007cd93bdd2817  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2820  sub rsp, 0x30
00007cd93bdd2824  movaps [rsp], xmm14
00007cd93bdd2829  movaps [rsp+0x10], xmm6
00007cd93bdd282e  movaps [rsp+0x20], xmm2
00007cd93bdd2833  lea rdi, [rsp]
00007cd93bdd2837  mov esi, 0x00
00007cd93bdd283c  mov rax, 0x64A581057530
00007cd93bdd2846  call rax
00007cd93bdd2848  movaps xmm14, [rsp]
00007cd93bdd284d  add rsp, 0x30
00007cd93bdd2851  vmovaps xmm0, [rsp]
00007cd93bdd2856  vmovaps xmm1, [rsp+0x10]
00007cd93bdd285c  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2862  vmovaps xmm3, [rsp+0x30]
00007cd93bdd2868  vmovaps xmm4, [rsp+0x40]
00007cd93bdd286e  vmovaps xmm5, [rsp+0x50]
00007cd93bdd2874  vmovaps xmm6, [rsp+0x60]
00007cd93bdd287a  vmovaps xmm7, [rsp+0x70]
00007cd93bdd2880  vmovaps xmm8, [rsp+0x80]
00007cd93bdd2889  vmovaps xmm9, [rsp+0x90]
00007cd93bdd2892  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd289b  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd28a4  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd28ad  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd28b6  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd28bf  add rsp, 0xF0
00007cd93bdd28c6  pop r11
00007cd93bdd28c8  pop r10
00007cd93bdd28ca  pop r9
00007cd93bdd28cc  pop r8
00007cd93bdd28ce  pop rsi
00007cd93bdd28cf  pop rdi
00007cd93bdd28d0  pop rdx
00007cd93bdd28d1  pop rcx
00007cd93bdd28d2  pop rax
00007cd93bdd28d3  add rsp, 0x08
00007cd93bdd28d7  jmp 0x00007CD93BDCFD72
00007cd93bdd28dc  sub rsp, 0x08
00007cd93bdd28e0  push rax
00007cd93bdd28e1  push rcx
00007cd93bdd28e2  push rdx
00007cd93bdd28e3  push rdi
00007cd93bdd28e4  push rsi
00007cd93bdd28e5  push r8
00007cd93bdd28e7  push r9
00007cd93bdd28e9  push r10
00007cd93bdd28eb  push r11
00007cd93bdd28ed  sub rsp, 0xF0
00007cd93bdd28f4  vmovaps [rsp], xmm0
00007cd93bdd28f9  vmovaps [rsp+0x10], xmm1
00007cd93bdd28ff  vmovaps [rsp+0x20], xmm2
00007cd93bdd2905  vmovaps [rsp+0x30], xmm3
00007cd93bdd290b  vmovaps [rsp+0x40], xmm4
00007cd93bdd2911  vmovaps [rsp+0x50], xmm5
00007cd93bdd2917  vmovaps [rsp+0x60], xmm7
00007cd93bdd291d  vmovaps [rsp+0x70], xmm8
00007cd93bdd2923  vmovaps [rsp+0x80], xmm9
00007cd93bdd292c  vmovaps [rsp+0x90], xmm10
00007cd93bdd2935  vmovaps [rsp+0xA0], xmm11
00007cd93bdd293e  vmovaps [rsp+0xB0], xmm12
00007cd93bdd2947  vmovaps [rsp+0xC0], xmm13
00007cd93bdd2950  vmovaps [rsp+0xD0], xmm14
00007cd93bdd2959  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2962  sub rsp, 0x30
00007cd93bdd2966  movaps [rsp], xmm6
00007cd93bdd296a  movaps [rsp+0x10], xmm5
00007cd93bdd296f  movaps [rsp+0x20], xmm1
00007cd93bdd2974  lea rdi, [rsp]
00007cd93bdd2978  mov esi, 0x00
00007cd93bdd297d  mov rax, 0x64A581057530
00007cd93bdd2987  call rax
00007cd93bdd2989  movaps xmm6, [rsp]
00007cd93bdd298d  add rsp, 0x30
00007cd93bdd2991  vmovaps xmm0, [rsp]
00007cd93bdd2996  vmovaps xmm1, [rsp+0x10]
00007cd93bdd299c  vmovaps xmm2, [rsp+0x20]
00007cd93bdd29a2  vmovaps xmm3, [rsp+0x30]
00007cd93bdd29a8  vmovaps xmm4, [rsp+0x40]
00007cd93bdd29ae  vmovaps xmm5, [rsp+0x50]
00007cd93bdd29b4  vmovaps xmm7, [rsp+0x60]
00007cd93bdd29ba  vmovaps xmm8, [rsp+0x70]
00007cd93bdd29c0  vmovaps xmm9, [rsp+0x80]
00007cd93bdd29c9  vmovaps xmm10, [rsp+0x90]
00007cd93bdd29d2  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd29db  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd29e4  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd29ed  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd29f6  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd29ff  add rsp, 0xF0
00007cd93bdd2a06  pop r11
00007cd93bdd2a08  pop r10
00007cd93bdd2a0a  pop r9
00007cd93bdd2a0c  pop r8
00007cd93bdd2a0e  pop rsi
00007cd93bdd2a0f  pop rdi
00007cd93bdd2a10  pop rdx
00007cd93bdd2a11  pop rcx
00007cd93bdd2a12  pop rax
00007cd93bdd2a13  add rsp, 0x08
00007cd93bdd2a17  jmp 0x00007CD93BDCFD98
00007cd93bdd2a1c  sub rsp, 0x08
00007cd93bdd2a20  push rax
00007cd93bdd2a21  push rcx
00007cd93bdd2a22  push rdx
00007cd93bdd2a23  push rdi
00007cd93bdd2a24  push rsi
00007cd93bdd2a25  push r8
00007cd93bdd2a27  push r9
00007cd93bdd2a29  push r10
00007cd93bdd2a2b  push r11
00007cd93bdd2a2d  sub rsp, 0xF0
00007cd93bdd2a34  vmovaps [rsp], xmm0
00007cd93bdd2a39  vmovaps [rsp+0x10], xmm2
00007cd93bdd2a3f  vmovaps [rsp+0x20], xmm3
00007cd93bdd2a45  vmovaps [rsp+0x30], xmm4
00007cd93bdd2a4b  vmovaps [rsp+0x40], xmm5
00007cd93bdd2a51  vmovaps [rsp+0x50], xmm6
00007cd93bdd2a57  vmovaps [rsp+0x60], xmm7
00007cd93bdd2a5d  vmovaps [rsp+0x70], xmm8
00007cd93bdd2a63  vmovaps [rsp+0x80], xmm9
00007cd93bdd2a6c  vmovaps [rsp+0x90], xmm10
00007cd93bdd2a75  vmovaps [rsp+0xA0], xmm11
00007cd93bdd2a7e  vmovaps [rsp+0xB0], xmm12
00007cd93bdd2a87  vmovaps [rsp+0xC0], xmm13
00007cd93bdd2a90  vmovaps [rsp+0xD0], xmm14
00007cd93bdd2a99  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2aa2  sub rsp, 0x30
00007cd93bdd2aa6  movaps [rsp], xmm1
00007cd93bdd2aaa  movaps [rsp+0x10], xmm5
00007cd93bdd2aaf  movaps [rsp+0x20], xmm13
00007cd93bdd2ab5  lea rdi, [rsp]
00007cd93bdd2ab9  mov esi, 0x00
00007cd93bdd2abe  mov rax, 0x64A581057530
00007cd93bdd2ac8  call rax
00007cd93bdd2aca  movaps xmm1, [rsp]
00007cd93bdd2ace  add rsp, 0x30
00007cd93bdd2ad2  vmovaps xmm0, [rsp]
00007cd93bdd2ad7  vmovaps xmm2, [rsp+0x10]
00007cd93bdd2add  vmovaps xmm3, [rsp+0x20]
00007cd93bdd2ae3  vmovaps xmm4, [rsp+0x30]
00007cd93bdd2ae9  vmovaps xmm5, [rsp+0x40]
00007cd93bdd2aef  vmovaps xmm6, [rsp+0x50]
00007cd93bdd2af5  vmovaps xmm7, [rsp+0x60]
00007cd93bdd2afb  vmovaps xmm8, [rsp+0x70]
00007cd93bdd2b01  vmovaps xmm9, [rsp+0x80]
00007cd93bdd2b0a  vmovaps xmm10, [rsp+0x90]
00007cd93bdd2b13  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd2b1c  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd2b25  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd2b2e  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd2b37  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd2b40  add rsp, 0xF0
00007cd93bdd2b47  pop r11
00007cd93bdd2b49  pop r10
00007cd93bdd2b4b  pop r9
00007cd93bdd2b4d  pop r8
00007cd93bdd2b4f  pop rsi
00007cd93bdd2b50  pop rdi
00007cd93bdd2b51  pop rdx
00007cd93bdd2b52  pop rcx
00007cd93bdd2b53  pop rax
00007cd93bdd2b54  add rsp, 0x08
00007cd93bdd2b58  jmp 0x00007CD93BDCFDB6
00007cd93bdd2b5d  sub rsp, 0x08
00007cd93bdd2b61  push rax
00007cd93bdd2b62  push rcx
00007cd93bdd2b63  push rdx
00007cd93bdd2b64  push rdi
00007cd93bdd2b65  push rsi
00007cd93bdd2b66  push r8
00007cd93bdd2b68  push r9
00007cd93bdd2b6a  push r10
00007cd93bdd2b6c  push r11
00007cd93bdd2b6e  sub rsp, 0xF0
00007cd93bdd2b75  vmovaps [rsp], xmm0
00007cd93bdd2b7a  vmovaps [rsp+0x10], xmm1
00007cd93bdd2b80  vmovaps [rsp+0x20], xmm2
00007cd93bdd2b86  vmovaps [rsp+0x30], xmm3
00007cd93bdd2b8c  vmovaps [rsp+0x40], xmm4
00007cd93bdd2b92  vmovaps [rsp+0x50], xmm6
00007cd93bdd2b98  vmovaps [rsp+0x60], xmm7
00007cd93bdd2b9e  vmovaps [rsp+0x70], xmm8
00007cd93bdd2ba4  vmovaps [rsp+0x80], xmm9
00007cd93bdd2bad  vmovaps [rsp+0x90], xmm10
00007cd93bdd2bb6  vmovaps [rsp+0xA0], xmm11
00007cd93bdd2bbf  vmovaps [rsp+0xB0], xmm12
00007cd93bdd2bc8  vmovaps [rsp+0xC0], xmm13
00007cd93bdd2bd1  vmovaps [rsp+0xD0], xmm14
00007cd93bdd2bda  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2be3  sub rsp, 0x30
00007cd93bdd2be7  movaps [rsp], xmm5
00007cd93bdd2beb  movaps [rsp+0x10], xmm2
00007cd93bdd2bf0  movaps [rsp+0x20], xmm13
00007cd93bdd2bf6  lea rdi, [rsp]
00007cd93bdd2bfa  mov esi, 0x00
00007cd93bdd2bff  mov rax, 0x64A581057530
00007cd93bdd2c09  call rax
00007cd93bdd2c0b  movaps xmm5, [rsp]
00007cd93bdd2c0f  add rsp, 0x30
00007cd93bdd2c13  vmovaps xmm0, [rsp]
00007cd93bdd2c18  vmovaps xmm1, [rsp+0x10]
00007cd93bdd2c1e  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2c24  vmovaps xmm3, [rsp+0x30]
00007cd93bdd2c2a  vmovaps xmm4, [rsp+0x40]
00007cd93bdd2c30  vmovaps xmm6, [rsp+0x50]
00007cd93bdd2c36  vmovaps xmm7, [rsp+0x60]
00007cd93bdd2c3c  vmovaps xmm8, [rsp+0x70]
00007cd93bdd2c42  vmovaps xmm9, [rsp+0x80]
00007cd93bdd2c4b  vmovaps xmm10, [rsp+0x90]
00007cd93bdd2c54  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd2c5d  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd2c66  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd2c6f  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd2c78  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd2c81  add rsp, 0xF0
00007cd93bdd2c88  pop r11
00007cd93bdd2c8a  pop r10
00007cd93bdd2c8c  pop r9
00007cd93bdd2c8e  pop r8
00007cd93bdd2c90  pop rsi
00007cd93bdd2c91  pop rdi
00007cd93bdd2c92  pop rdx
00007cd93bdd2c93  pop rcx
00007cd93bdd2c94  pop rax
00007cd93bdd2c95  add rsp, 0x08
00007cd93bdd2c99  jmp 0x00007CD93BDCFDEC
00007cd93bdd2c9e  sub rsp, 0x08
00007cd93bdd2ca2  push rax
00007cd93bdd2ca3  push rcx
00007cd93bdd2ca4  push rdx
00007cd93bdd2ca5  push rdi
00007cd93bdd2ca6  push rsi
00007cd93bdd2ca7  push r8
00007cd93bdd2ca9  push r9
00007cd93bdd2cab  push r10
00007cd93bdd2cad  push r11
00007cd93bdd2caf  sub rsp, 0xF0
00007cd93bdd2cb6  vmovaps [rsp], xmm0
00007cd93bdd2cbb  vmovaps [rsp+0x10], xmm1
00007cd93bdd2cc1  vmovaps [rsp+0x20], xmm2
00007cd93bdd2cc7  vmovaps [rsp+0x30], xmm3
00007cd93bdd2ccd  vmovaps [rsp+0x40], xmm4
00007cd93bdd2cd3  vmovaps [rsp+0x50], xmm5
00007cd93bdd2cd9  vmovaps [rsp+0x60], xmm6
00007cd93bdd2cdf  vmovaps [rsp+0x70], xmm7
00007cd93bdd2ce5  vmovaps [rsp+0x80], xmm8
00007cd93bdd2cee  vmovaps [rsp+0x90], xmm9
00007cd93bdd2cf7  vmovaps [rsp+0xA0], xmm10
00007cd93bdd2d00  vmovaps [rsp+0xB0], xmm11
00007cd93bdd2d09  vmovaps [rsp+0xC0], xmm12
00007cd93bdd2d12  vmovaps [rsp+0xD0], xmm14
00007cd93bdd2d1b  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2d24  sub rsp, 0x30
00007cd93bdd2d28  movaps [rsp], xmm13
00007cd93bdd2d2d  movaps [rsp+0x10], xmm10
00007cd93bdd2d33  movaps [rsp+0x20], xmm1
00007cd93bdd2d38  lea rdi, [rsp]
00007cd93bdd2d3c  mov esi, 0x00
00007cd93bdd2d41  mov rax, 0x64A581057530
00007cd93bdd2d4b  call rax
00007cd93bdd2d4d  movaps xmm13, [rsp]
00007cd93bdd2d52  add rsp, 0x30
00007cd93bdd2d56  vmovaps xmm0, [rsp]
00007cd93bdd2d5b  vmovaps xmm1, [rsp+0x10]
00007cd93bdd2d61  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2d67  vmovaps xmm3, [rsp+0x30]
00007cd93bdd2d6d  vmovaps xmm4, [rsp+0x40]
00007cd93bdd2d73  vmovaps xmm5, [rsp+0x50]
00007cd93bdd2d79  vmovaps xmm6, [rsp+0x60]
00007cd93bdd2d7f  vmovaps xmm7, [rsp+0x70]
00007cd93bdd2d85  vmovaps xmm8, [rsp+0x80]
00007cd93bdd2d8e  vmovaps xmm9, [rsp+0x90]
00007cd93bdd2d97  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd2da0  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd2da9  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd2db2  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd2dbb  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd2dc4  add rsp, 0xF0
00007cd93bdd2dcb  pop r11
00007cd93bdd2dcd  pop r10
00007cd93bdd2dcf  pop r9
00007cd93bdd2dd1  pop r8
00007cd93bdd2dd3  pop rsi
00007cd93bdd2dd4  pop rdi
00007cd93bdd2dd5  pop rdx
00007cd93bdd2dd6  pop rcx
00007cd93bdd2dd7  pop rax
00007cd93bdd2dd8  add rsp, 0x08
00007cd93bdd2ddc  jmp 0x00007CD93BDCFE15
00007cd93bdd2de1  sub rsp, 0x08
00007cd93bdd2de5  push rax
00007cd93bdd2de6  push rcx
00007cd93bdd2de7  push rdx
00007cd93bdd2de8  push rdi
00007cd93bdd2de9  push rsi
00007cd93bdd2dea  push r8
00007cd93bdd2dec  push r9
00007cd93bdd2dee  push r10
00007cd93bdd2df0  push r11
00007cd93bdd2df2  sub rsp, 0xF0
00007cd93bdd2df9  vmovaps [rsp], xmm0
00007cd93bdd2dfe  vmovaps [rsp+0x10], xmm2
00007cd93bdd2e04  vmovaps [rsp+0x20], xmm3
00007cd93bdd2e0a  vmovaps [rsp+0x30], xmm4
00007cd93bdd2e10  vmovaps [rsp+0x40], xmm5
00007cd93bdd2e16  vmovaps [rsp+0x50], xmm6
00007cd93bdd2e1c  vmovaps [rsp+0x60], xmm7
00007cd93bdd2e22  vmovaps [rsp+0x70], xmm8
00007cd93bdd2e28  vmovaps [rsp+0x80], xmm9
00007cd93bdd2e31  vmovaps [rsp+0x90], xmm10
00007cd93bdd2e3a  vmovaps [rsp+0xA0], xmm11
00007cd93bdd2e43  vmovaps [rsp+0xB0], xmm12
00007cd93bdd2e4c  vmovaps [rsp+0xC0], xmm13
00007cd93bdd2e55  vmovaps [rsp+0xD0], xmm14
00007cd93bdd2e5e  vmovaps [rsp+0xE0], xmm15
00007cd93bdd2e67  sub rsp, 0x30
00007cd93bdd2e6b  movaps [rsp], xmm1
00007cd93bdd2e6f  movaps [rsp+0x10], xmm15
00007cd93bdd2e75  movaps [rsp+0x20], xmm10
00007cd93bdd2e7b  lea rdi, [rsp]
00007cd93bdd2e7f  mov esi, 0x00
00007cd93bdd2e84  mov rax, 0x64A581057530
00007cd93bdd2e8e  call rax
00007cd93bdd2e90  movaps xmm1, [rsp]
00007cd93bdd2e94  add rsp, 0x30
00007cd93bdd2e98  vmovaps xmm0, [rsp]
00007cd93bdd2e9d  vmovaps xmm2, [rsp+0x10]
00007cd93bdd2ea3  vmovaps xmm3, [rsp+0x20]
00007cd93bdd2ea9  vmovaps xmm4, [rsp+0x30]
00007cd93bdd2eaf  vmovaps xmm5, [rsp+0x40]
00007cd93bdd2eb5  vmovaps xmm6, [rsp+0x50]
00007cd93bdd2ebb  vmovaps xmm7, [rsp+0x60]
00007cd93bdd2ec1  vmovaps xmm8, [rsp+0x70]
00007cd93bdd2ec7  vmovaps xmm9, [rsp+0x80]
00007cd93bdd2ed0  vmovaps xmm10, [rsp+0x90]
00007cd93bdd2ed9  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd2ee2  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd2eeb  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd2ef4  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd2efd  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd2f06  add rsp, 0xF0
00007cd93bdd2f0d  pop r11
00007cd93bdd2f0f  pop r10
00007cd93bdd2f11  pop r9
00007cd93bdd2f13  pop r8
00007cd93bdd2f15  pop rsi
00007cd93bdd2f16  pop rdi
00007cd93bdd2f17  pop rdx
00007cd93bdd2f18  pop rcx
00007cd93bdd2f19  pop rax
00007cd93bdd2f1a  add rsp, 0x08
00007cd93bdd2f1e  jmp 0x00007CD93BDCFE34
00007cd93bdd2f23  sub rsp, 0x08
00007cd93bdd2f27  push rax
00007cd93bdd2f28  push rcx
00007cd93bdd2f29  push rdx
00007cd93bdd2f2a  push rdi
00007cd93bdd2f2b  push rsi
00007cd93bdd2f2c  push r8
00007cd93bdd2f2e  push r9
00007cd93bdd2f30  push r10
00007cd93bdd2f32  push r11
00007cd93bdd2f34  sub rsp, 0xF0
00007cd93bdd2f3b  vmovaps [rsp], xmm0
00007cd93bdd2f40  vmovaps [rsp+0x10], xmm1
00007cd93bdd2f46  vmovaps [rsp+0x20], xmm2
00007cd93bdd2f4c  vmovaps [rsp+0x30], xmm3
00007cd93bdd2f52  vmovaps [rsp+0x40], xmm4
00007cd93bdd2f58  vmovaps [rsp+0x50], xmm5
00007cd93bdd2f5e  vmovaps [rsp+0x60], xmm6
00007cd93bdd2f64  vmovaps [rsp+0x70], xmm7
00007cd93bdd2f6a  vmovaps [rsp+0x80], xmm8
00007cd93bdd2f73  vmovaps [rsp+0x90], xmm9
00007cd93bdd2f7c  vmovaps [rsp+0xA0], xmm10
00007cd93bdd2f85  vmovaps [rsp+0xB0], xmm11
00007cd93bdd2f8e  vmovaps [rsp+0xC0], xmm12
00007cd93bdd2f97  vmovaps [rsp+0xD0], xmm13
00007cd93bdd2fa0  vmovaps [rsp+0xE0], xmm14
00007cd93bdd2fa9  sub rsp, 0x30
00007cd93bdd2fad  movaps [rsp], xmm15
00007cd93bdd2fb2  movaps [rsp+0x10], xmm10
00007cd93bdd2fb8  movaps [rsp+0x20], xmm11
00007cd93bdd2fbe  lea rdi, [rsp]
00007cd93bdd2fc2  mov esi, 0x00
00007cd93bdd2fc7  mov rax, 0x64A581057530
00007cd93bdd2fd1  call rax
00007cd93bdd2fd3  movaps xmm15, [rsp]
00007cd93bdd2fd8  add rsp, 0x30
00007cd93bdd2fdc  vmovaps xmm0, [rsp]
00007cd93bdd2fe1  vmovaps xmm1, [rsp+0x10]
00007cd93bdd2fe7  vmovaps xmm2, [rsp+0x20]
00007cd93bdd2fed  vmovaps xmm3, [rsp+0x30]
00007cd93bdd2ff3  vmovaps xmm4, [rsp+0x40]
00007cd93bdd2ff9  vmovaps xmm5, [rsp+0x50]
00007cd93bdd2fff  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3005  vmovaps xmm7, [rsp+0x70]
00007cd93bdd300b  vmovaps xmm8, [rsp+0x80]
00007cd93bdd3014  vmovaps xmm9, [rsp+0x90]
00007cd93bdd301d  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd3026  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd302f  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd3038  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd3041  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd304a  add rsp, 0xF0
00007cd93bdd3051  pop r11
00007cd93bdd3053  pop r10
00007cd93bdd3055  pop r9
00007cd93bdd3057  pop r8
00007cd93bdd3059  pop rsi
00007cd93bdd305a  pop rdi
00007cd93bdd305b  pop rdx
00007cd93bdd305c  pop rcx
00007cd93bdd305d  pop rax
00007cd93bdd305e  add rsp, 0x08
00007cd93bdd3062  jmp 0x00007CD93BDCFE57
00007cd93bdd3067  sub rsp, 0x08
00007cd93bdd306b  push rax
00007cd93bdd306c  push rcx
00007cd93bdd306d  push rdx
00007cd93bdd306e  push rdi
00007cd93bdd306f  push rsi
00007cd93bdd3070  push r8
00007cd93bdd3072  push r9
00007cd93bdd3074  push r10
00007cd93bdd3076  push r11
00007cd93bdd3078  sub rsp, 0xF0
00007cd93bdd307f  vmovaps [rsp], xmm0
00007cd93bdd3084  vmovaps [rsp+0x10], xmm1
00007cd93bdd308a  vmovaps [rsp+0x20], xmm2
00007cd93bdd3090  vmovaps [rsp+0x30], xmm3
00007cd93bdd3096  vmovaps [rsp+0x40], xmm4
00007cd93bdd309c  vmovaps [rsp+0x50], xmm5
00007cd93bdd30a2  vmovaps [rsp+0x60], xmm6
00007cd93bdd30a8  vmovaps [rsp+0x70], xmm7
00007cd93bdd30ae  vmovaps [rsp+0x80], xmm8
00007cd93bdd30b7  vmovaps [rsp+0x90], xmm9
00007cd93bdd30c0  vmovaps [rsp+0xA0], xmm11
00007cd93bdd30c9  vmovaps [rsp+0xB0], xmm12
00007cd93bdd30d2  vmovaps [rsp+0xC0], xmm13
00007cd93bdd30db  vmovaps [rsp+0xD0], xmm14
00007cd93bdd30e4  vmovaps [rsp+0xE0], xmm15
00007cd93bdd30ed  sub rsp, 0x30
00007cd93bdd30f1  movaps [rsp], xmm10
00007cd93bdd30f6  movaps [rsp+0x10], xmm12
00007cd93bdd30fc  movaps [rsp+0x20], xmm11
00007cd93bdd3102  lea rdi, [rsp]
00007cd93bdd3106  mov esi, 0x00
00007cd93bdd310b  mov rax, 0x64A581057530
00007cd93bdd3115  call rax
00007cd93bdd3117  movaps xmm10, [rsp]
00007cd93bdd311c  add rsp, 0x30
00007cd93bdd3120  vmovaps xmm0, [rsp]
00007cd93bdd3125  vmovaps xmm1, [rsp+0x10]
00007cd93bdd312b  vmovaps xmm2, [rsp+0x20]
00007cd93bdd3131  vmovaps xmm3, [rsp+0x30]
00007cd93bdd3137  vmovaps xmm4, [rsp+0x40]
00007cd93bdd313d  vmovaps xmm5, [rsp+0x50]
00007cd93bdd3143  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3149  vmovaps xmm7, [rsp+0x70]
00007cd93bdd314f  vmovaps xmm8, [rsp+0x80]
00007cd93bdd3158  vmovaps xmm9, [rsp+0x90]
00007cd93bdd3161  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd316a  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd3173  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd317c  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd3185  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd318e  add rsp, 0xF0
00007cd93bdd3195  pop r11
00007cd93bdd3197  pop r10
00007cd93bdd3199  pop r9
00007cd93bdd319b  pop r8
00007cd93bdd319d  pop rsi
00007cd93bdd319e  pop rdi
00007cd93bdd319f  pop rdx
00007cd93bdd31a0  pop rcx
00007cd93bdd31a1  pop rax
00007cd93bdd31a2  add rsp, 0x08
00007cd93bdd31a6  jmp 0x00007CD93BDCFE80
00007cd93bdd31ab  sub rsp, 0x08
00007cd93bdd31af  push rax
00007cd93bdd31b0  push rcx
00007cd93bdd31b1  push rdx
00007cd93bdd31b2  push rdi
00007cd93bdd31b3  push rsi
00007cd93bdd31b4  push r8
00007cd93bdd31b6  push r9
00007cd93bdd31b8  push r10
00007cd93bdd31ba  push r11
00007cd93bdd31bc  sub rsp, 0xF0
00007cd93bdd31c3  vmovaps [rsp], xmm0
00007cd93bdd31c8  vmovaps [rsp+0x10], xmm1
00007cd93bdd31ce  vmovaps [rsp+0x20], xmm2
00007cd93bdd31d4  vmovaps [rsp+0x30], xmm3
00007cd93bdd31da  vmovaps [rsp+0x40], xmm4
00007cd93bdd31e0  vmovaps [rsp+0x50], xmm5
00007cd93bdd31e6  vmovaps [rsp+0x60], xmm6
00007cd93bdd31ec  vmovaps [rsp+0x70], xmm7
00007cd93bdd31f2  vmovaps [rsp+0x80], xmm8
00007cd93bdd31fb  vmovaps [rsp+0x90], xmm9
00007cd93bdd3204  vmovaps [rsp+0xA0], xmm10
00007cd93bdd320d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd3216  vmovaps [rsp+0xC0], xmm13
00007cd93bdd321f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd3228  vmovaps [rsp+0xE0], xmm15
00007cd93bdd3231  sub rsp, 0x30
00007cd93bdd3235  movaps [rsp], xmm11
00007cd93bdd323a  movaps [rsp+0x10], xmm2
00007cd93bdd323f  movaps [rsp+0x20], xmm12
00007cd93bdd3245  lea rdi, [rsp]
00007cd93bdd3249  mov esi, 0x00
00007cd93bdd324e  mov rax, 0x64A581057530
00007cd93bdd3258  call rax
00007cd93bdd325a  movaps xmm11, [rsp]
00007cd93bdd325f  add rsp, 0x30
00007cd93bdd3263  vmovaps xmm0, [rsp]
00007cd93bdd3268  vmovaps xmm1, [rsp+0x10]
00007cd93bdd326e  vmovaps xmm2, [rsp+0x20]
00007cd93bdd3274  vmovaps xmm3, [rsp+0x30]
00007cd93bdd327a  vmovaps xmm4, [rsp+0x40]
00007cd93bdd3280  vmovaps xmm5, [rsp+0x50]
00007cd93bdd3286  vmovaps xmm6, [rsp+0x60]
00007cd93bdd328c  vmovaps xmm7, [rsp+0x70]
00007cd93bdd3292  vmovaps xmm8, [rsp+0x80]
00007cd93bdd329b  vmovaps xmm9, [rsp+0x90]
00007cd93bdd32a4  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd32ad  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd32b6  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd32bf  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd32c8  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd32d1  add rsp, 0xF0
00007cd93bdd32d8  pop r11
00007cd93bdd32da  pop r10
00007cd93bdd32dc  pop r9
00007cd93bdd32de  pop r8
00007cd93bdd32e0  pop rsi
00007cd93bdd32e1  pop rdi
00007cd93bdd32e2  pop rdx
00007cd93bdd32e3  pop rcx
00007cd93bdd32e4  pop rax
00007cd93bdd32e5  add rsp, 0x08
00007cd93bdd32e9  jmp 0x00007CD93BDCFEB8
00007cd93bdd32ee  sub rsp, 0x08
00007cd93bdd32f2  push rax
00007cd93bdd32f3  push rcx
00007cd93bdd32f4  push rdx
00007cd93bdd32f5  push rdi
00007cd93bdd32f6  push rsi
00007cd93bdd32f7  push r8
00007cd93bdd32f9  push r9
00007cd93bdd32fb  push r10
00007cd93bdd32fd  push r11
00007cd93bdd32ff  sub rsp, 0xF0
00007cd93bdd3306  vmovaps [rsp], xmm0
00007cd93bdd330b  vmovaps [rsp+0x10], xmm2
00007cd93bdd3311  vmovaps [rsp+0x20], xmm3
00007cd93bdd3317  vmovaps [rsp+0x30], xmm4
00007cd93bdd331d  vmovaps [rsp+0x40], xmm5
00007cd93bdd3323  vmovaps [rsp+0x50], xmm6
00007cd93bdd3329  vmovaps [rsp+0x60], xmm7
00007cd93bdd332f  vmovaps [rsp+0x70], xmm8
00007cd93bdd3335  vmovaps [rsp+0x80], xmm9
00007cd93bdd333e  vmovaps [rsp+0x90], xmm10
00007cd93bdd3347  vmovaps [rsp+0xA0], xmm11
00007cd93bdd3350  vmovaps [rsp+0xB0], xmm12
00007cd93bdd3359  vmovaps [rsp+0xC0], xmm13
00007cd93bdd3362  vmovaps [rsp+0xD0], xmm14
00007cd93bdd336b  vmovaps [rsp+0xE0], xmm15
00007cd93bdd3374  sub rsp, 0x30
00007cd93bdd3378  movaps [rsp], xmm1
00007cd93bdd337c  movaps [rsp+0x10], xmm14
00007cd93bdd3382  movaps [rsp+0x20], xmm6
00007cd93bdd3387  lea rdi, [rsp]
00007cd93bdd338b  mov esi, 0x00
00007cd93bdd3390  mov rax, 0x64A581057530
00007cd93bdd339a  call rax
00007cd93bdd339c  movaps xmm1, [rsp]
00007cd93bdd33a0  add rsp, 0x30
00007cd93bdd33a4  vmovaps xmm0, [rsp]
00007cd93bdd33a9  vmovaps xmm2, [rsp+0x10]
00007cd93bdd33af  vmovaps xmm3, [rsp+0x20]
00007cd93bdd33b5  vmovaps xmm4, [rsp+0x30]
00007cd93bdd33bb  vmovaps xmm5, [rsp+0x40]
00007cd93bdd33c1  vmovaps xmm6, [rsp+0x50]
00007cd93bdd33c7  vmovaps xmm7, [rsp+0x60]
00007cd93bdd33cd  vmovaps xmm8, [rsp+0x70]
00007cd93bdd33d3  vmovaps xmm9, [rsp+0x80]
00007cd93bdd33dc  vmovaps xmm10, [rsp+0x90]
00007cd93bdd33e5  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd33ee  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd33f7  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd3400  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd3409  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3412  add rsp, 0xF0
00007cd93bdd3419  pop r11
00007cd93bdd341b  pop r10
00007cd93bdd341d  pop r9
00007cd93bdd341f  pop r8
00007cd93bdd3421  pop rsi
00007cd93bdd3422  pop rdi
00007cd93bdd3423  pop rdx
00007cd93bdd3424  pop rcx
00007cd93bdd3425  pop rax
00007cd93bdd3426  add rsp, 0x08
00007cd93bdd342a  jmp 0x00007CD93BDCFED1
00007cd93bdd342f  sub rsp, 0x08
00007cd93bdd3433  push rax
00007cd93bdd3434  push rcx
00007cd93bdd3435  push rdx
00007cd93bdd3436  push rdi
00007cd93bdd3437  push rsi
00007cd93bdd3438  push r8
00007cd93bdd343a  push r9
00007cd93bdd343c  push r10
00007cd93bdd343e  push r11
00007cd93bdd3440  sub rsp, 0xF0
00007cd93bdd3447  vmovaps [rsp], xmm0
00007cd93bdd344c  vmovaps [rsp+0x10], xmm1
00007cd93bdd3452  vmovaps [rsp+0x20], xmm2
00007cd93bdd3458  vmovaps [rsp+0x30], xmm3
00007cd93bdd345e  vmovaps [rsp+0x40], xmm4
00007cd93bdd3464  vmovaps [rsp+0x50], xmm5
00007cd93bdd346a  vmovaps [rsp+0x60], xmm6
00007cd93bdd3470  vmovaps [rsp+0x70], xmm7
00007cd93bdd3476  vmovaps [rsp+0x80], xmm8
00007cd93bdd347f  vmovaps [rsp+0x90], xmm9
00007cd93bdd3488  vmovaps [rsp+0xA0], xmm10
00007cd93bdd3491  vmovaps [rsp+0xB0], xmm11
00007cd93bdd349a  vmovaps [rsp+0xC0], xmm12
00007cd93bdd34a3  vmovaps [rsp+0xD0], xmm13
00007cd93bdd34ac  vmovaps [rsp+0xE0], xmm15
00007cd93bdd34b5  sub rsp, 0x30
00007cd93bdd34b9  movaps [rsp], xmm14
00007cd93bdd34be  movaps [rsp+0x10], xmm12
00007cd93bdd34c4  movaps [rsp+0x20], xmm5
00007cd93bdd34c9  lea rdi, [rsp]
00007cd93bdd34cd  mov esi, 0x00
00007cd93bdd34d2  mov rax, 0x64A581057530
00007cd93bdd34dc  call rax
00007cd93bdd34de  movaps xmm14, [rsp]
00007cd93bdd34e3  add rsp, 0x30
00007cd93bdd34e7  vmovaps xmm0, [rsp]
00007cd93bdd34ec  vmovaps xmm1, [rsp+0x10]
00007cd93bdd34f2  vmovaps xmm2, [rsp+0x20]
00007cd93bdd34f8  vmovaps xmm3, [rsp+0x30]
00007cd93bdd34fe  vmovaps xmm4, [rsp+0x40]
00007cd93bdd3504  vmovaps xmm5, [rsp+0x50]
00007cd93bdd350a  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3510  vmovaps xmm7, [rsp+0x70]
00007cd93bdd3516  vmovaps xmm8, [rsp+0x80]
00007cd93bdd351f  vmovaps xmm9, [rsp+0x90]
00007cd93bdd3528  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd3531  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd353a  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd3543  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd354c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3555  add rsp, 0xF0
00007cd93bdd355c  pop r11
00007cd93bdd355e  pop r10
00007cd93bdd3560  pop r9
00007cd93bdd3562  pop r8
00007cd93bdd3564  pop rsi
00007cd93bdd3565  pop rdi
00007cd93bdd3566  pop rdx
00007cd93bdd3567  pop rcx
00007cd93bdd3568  pop rax
00007cd93bdd3569  add rsp, 0x08
00007cd93bdd356d  jmp 0x00007CD93BDCFEF1
00007cd93bdd3572  sub rsp, 0x08
00007cd93bdd3576  push rax
00007cd93bdd3577  push rcx
00007cd93bdd3578  push rdx
00007cd93bdd3579  push rdi
00007cd93bdd357a  push rsi
00007cd93bdd357b  push r8
00007cd93bdd357d  push r9
00007cd93bdd357f  push r10
00007cd93bdd3581  push r11
00007cd93bdd3583  sub rsp, 0xF0
00007cd93bdd358a  vmovaps [rsp], xmm0
00007cd93bdd358f  vmovaps [rsp+0x10], xmm1
00007cd93bdd3595  vmovaps [rsp+0x20], xmm2
00007cd93bdd359b  vmovaps [rsp+0x30], xmm3
00007cd93bdd35a1  vmovaps [rsp+0x40], xmm4
00007cd93bdd35a7  vmovaps [rsp+0x50], xmm5
00007cd93bdd35ad  vmovaps [rsp+0x60], xmm7
00007cd93bdd35b3  vmovaps [rsp+0x70], xmm8
00007cd93bdd35b9  vmovaps [rsp+0x80], xmm9
00007cd93bdd35c2  vmovaps [rsp+0x90], xmm10
00007cd93bdd35cb  vmovaps [rsp+0xA0], xmm11
00007cd93bdd35d4  vmovaps [rsp+0xB0], xmm12
00007cd93bdd35dd  vmovaps [rsp+0xC0], xmm13
00007cd93bdd35e6  vmovaps [rsp+0xD0], xmm14
00007cd93bdd35ef  vmovaps [rsp+0xE0], xmm15
00007cd93bdd35f8  sub rsp, 0x30
00007cd93bdd35fc  movaps [rsp], xmm6
00007cd93bdd3600  movaps [rsp+0x10], xmm9
00007cd93bdd3606  movaps [rsp+0x20], xmm12
00007cd93bdd360c  lea rdi, [rsp]
00007cd93bdd3610  mov esi, 0x00
00007cd93bdd3615  mov rax, 0x64A581057530
00007cd93bdd361f  call rax
00007cd93bdd3621  movaps xmm6, [rsp]
00007cd93bdd3625  add rsp, 0x30
00007cd93bdd3629  vmovaps xmm0, [rsp]
00007cd93bdd362e  vmovaps xmm1, [rsp+0x10]
00007cd93bdd3634  vmovaps xmm2, [rsp+0x20]
00007cd93bdd363a  vmovaps xmm3, [rsp+0x30]
00007cd93bdd3640  vmovaps xmm4, [rsp+0x40]
00007cd93bdd3646  vmovaps xmm5, [rsp+0x50]
00007cd93bdd364c  vmovaps xmm7, [rsp+0x60]
00007cd93bdd3652  vmovaps xmm8, [rsp+0x70]
00007cd93bdd3658  vmovaps xmm9, [rsp+0x80]
00007cd93bdd3661  vmovaps xmm10, [rsp+0x90]
00007cd93bdd366a  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd3673  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd367c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd3685  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd368e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3697  add rsp, 0xF0
00007cd93bdd369e  pop r11
00007cd93bdd36a0  pop r10
00007cd93bdd36a2  pop r9
00007cd93bdd36a4  pop r8
00007cd93bdd36a6  pop rsi
00007cd93bdd36a7  pop rdi
00007cd93bdd36a8  pop rdx
00007cd93bdd36a9  pop rcx
00007cd93bdd36aa  pop rax
00007cd93bdd36ab  add rsp, 0x08
00007cd93bdd36af  jmp 0x00007CD93BDCFF19
00007cd93bdd36b4  sub rsp, 0x08
00007cd93bdd36b8  push rax
00007cd93bdd36b9  push rcx
00007cd93bdd36ba  push rdx
00007cd93bdd36bb  push rdi
00007cd93bdd36bc  push rsi
00007cd93bdd36bd  push r8
00007cd93bdd36bf  push r9
00007cd93bdd36c1  push r10
00007cd93bdd36c3  push r11
00007cd93bdd36c5  sub rsp, 0xF0
00007cd93bdd36cc  vmovaps [rsp], xmm0
00007cd93bdd36d1  vmovaps [rsp+0x10], xmm1
00007cd93bdd36d7  vmovaps [rsp+0x20], xmm2
00007cd93bdd36dd  vmovaps [rsp+0x30], xmm3
00007cd93bdd36e3  vmovaps [rsp+0x40], xmm4
00007cd93bdd36e9  vmovaps [rsp+0x50], xmm5
00007cd93bdd36ef  vmovaps [rsp+0x60], xmm6
00007cd93bdd36f5  vmovaps [rsp+0x70], xmm7
00007cd93bdd36fb  vmovaps [rsp+0x80], xmm8
00007cd93bdd3704  vmovaps [rsp+0x90], xmm9
00007cd93bdd370d  vmovaps [rsp+0xA0], xmm10
00007cd93bdd3716  vmovaps [rsp+0xB0], xmm11
00007cd93bdd371f  vmovaps [rsp+0xC0], xmm13
00007cd93bdd3728  vmovaps [rsp+0xD0], xmm14
00007cd93bdd3731  vmovaps [rsp+0xE0], xmm15
00007cd93bdd373a  sub rsp, 0x30
00007cd93bdd373e  movaps [rsp], xmm12
00007cd93bdd3743  movaps [rsp+0x10], xmm15
00007cd93bdd3749  movaps [rsp+0x20], xmm13
00007cd93bdd374f  lea rdi, [rsp]
00007cd93bdd3753  mov esi, 0x00
00007cd93bdd3758  mov rax, 0x64A581057530
00007cd93bdd3762  call rax
00007cd93bdd3764  movaps xmm12, [rsp]
00007cd93bdd3769  add rsp, 0x30
00007cd93bdd376d  vmovaps xmm0, [rsp]
00007cd93bdd3772  vmovaps xmm1, [rsp+0x10]
00007cd93bdd3778  vmovaps xmm2, [rsp+0x20]
00007cd93bdd377e  vmovaps xmm3, [rsp+0x30]
00007cd93bdd3784  vmovaps xmm4, [rsp+0x40]
00007cd93bdd378a  vmovaps xmm5, [rsp+0x50]
00007cd93bdd3790  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3796  vmovaps xmm7, [rsp+0x70]
00007cd93bdd379c  vmovaps xmm8, [rsp+0x80]
00007cd93bdd37a5  vmovaps xmm9, [rsp+0x90]
00007cd93bdd37ae  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd37b7  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd37c0  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd37c9  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd37d2  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd37db  add rsp, 0xF0
00007cd93bdd37e2  pop r11
00007cd93bdd37e4  pop r10
00007cd93bdd37e6  pop r9
00007cd93bdd37e8  pop r8
00007cd93bdd37ea  pop rsi
00007cd93bdd37eb  pop rdi
00007cd93bdd37ec  pop rdx
00007cd93bdd37ed  pop rcx
00007cd93bdd37ee  pop rax
00007cd93bdd37ef  add rsp, 0x08
00007cd93bdd37f3  jmp 0x00007CD93BDCFF34
00007cd93bdd37f8  sub rsp, 0x08
00007cd93bdd37fc  push rax
00007cd93bdd37fd  push rcx
00007cd93bdd37fe  push rdx
00007cd93bdd37ff  push rdi
00007cd93bdd3800  push rsi
00007cd93bdd3801  push r8
00007cd93bdd3803  push r9
00007cd93bdd3805  push r10
00007cd93bdd3807  push r11
00007cd93bdd3809  sub rsp, 0xF0
00007cd93bdd3810  vmovaps [rsp], xmm0
00007cd93bdd3815  vmovaps [rsp+0x10], xmm1
00007cd93bdd381b  vmovaps [rsp+0x20], xmm2
00007cd93bdd3821  vmovaps [rsp+0x30], xmm3
00007cd93bdd3827  vmovaps [rsp+0x40], xmm4
00007cd93bdd382d  vmovaps [rsp+0x50], xmm5
00007cd93bdd3833  vmovaps [rsp+0x60], xmm6
00007cd93bdd3839  vmovaps [rsp+0x70], xmm7
00007cd93bdd383f  vmovaps [rsp+0x80], xmm8
00007cd93bdd3848  vmovaps [rsp+0x90], xmm9
00007cd93bdd3851  vmovaps [rsp+0xA0], xmm10
00007cd93bdd385a  vmovaps [rsp+0xB0], xmm11
00007cd93bdd3863  vmovaps [rsp+0xC0], xmm12
00007cd93bdd386c  vmovaps [rsp+0xD0], xmm13
00007cd93bdd3875  vmovaps [rsp+0xE0], xmm14
00007cd93bdd387e  sub rsp, 0x30
00007cd93bdd3882  movaps [rsp], xmm15
00007cd93bdd3887  movaps [rsp+0x10], xmm13
00007cd93bdd388d  movaps [rsp+0x20], xmm10
00007cd93bdd3893  lea rdi, [rsp]
00007cd93bdd3897  mov esi, 0x00
00007cd93bdd389c  mov rax, 0x64A581057530
00007cd93bdd38a6  call rax
00007cd93bdd38a8  movaps xmm15, [rsp]
00007cd93bdd38ad  add rsp, 0x30
00007cd93bdd38b1  vmovaps xmm0, [rsp]
00007cd93bdd38b6  vmovaps xmm1, [rsp+0x10]
00007cd93bdd38bc  vmovaps xmm2, [rsp+0x20]
00007cd93bdd38c2  vmovaps xmm3, [rsp+0x30]
00007cd93bdd38c8  vmovaps xmm4, [rsp+0x40]
00007cd93bdd38ce  vmovaps xmm5, [rsp+0x50]
00007cd93bdd38d4  vmovaps xmm6, [rsp+0x60]
00007cd93bdd38da  vmovaps xmm7, [rsp+0x70]
00007cd93bdd38e0  vmovaps xmm8, [rsp+0x80]
00007cd93bdd38e9  vmovaps xmm9, [rsp+0x90]
00007cd93bdd38f2  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd38fb  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd3904  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd390d  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd3916  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd391f  add rsp, 0xF0
00007cd93bdd3926  pop r11
00007cd93bdd3928  pop r10
00007cd93bdd392a  pop r9
00007cd93bdd392c  pop r8
00007cd93bdd392e  pop rsi
00007cd93bdd392f  pop rdi
00007cd93bdd3930  pop rdx
00007cd93bdd3931  pop rcx
00007cd93bdd3932  pop rax
00007cd93bdd3933  add rsp, 0x08
00007cd93bdd3937  jmp 0x00007CD93BDCFF55
00007cd93bdd393c  call 0x00007CD93BC0C260
00007cd93bdd3941  jmp 0x00007CD93BDCFFB0
00007cd93bdd3946  sub rsp, 0x08
00007cd93bdd394a  push rax
00007cd93bdd394b  push rcx
00007cd93bdd394c  push rdx
00007cd93bdd394d  push rdi
00007cd93bdd394e  push rsi
00007cd93bdd394f  push r8
00007cd93bdd3951  push r9
00007cd93bdd3953  push r10
00007cd93bdd3955  push r11
00007cd93bdd3957  sub rsp, 0xF0
00007cd93bdd395e  vmovaps [rsp], xmm0
00007cd93bdd3963  vmovaps [rsp+0x10], xmm1
00007cd93bdd3969  vmovaps [rsp+0x20], xmm2
00007cd93bdd396f  vmovaps [rsp+0x30], xmm3
00007cd93bdd3975  vmovaps [rsp+0x40], xmm4
00007cd93bdd397b  vmovaps [rsp+0x50], xmm5
00007cd93bdd3981  vmovaps [rsp+0x60], xmm6
00007cd93bdd3987  vmovaps [rsp+0x70], xmm7
00007cd93bdd398d  vmovaps [rsp+0x80], xmm8
00007cd93bdd3996  vmovaps [rsp+0x90], xmm10
00007cd93bdd399f  vmovaps [rsp+0xA0], xmm11
00007cd93bdd39a8  vmovaps [rsp+0xB0], xmm12
00007cd93bdd39b1  vmovaps [rsp+0xC0], xmm13
00007cd93bdd39ba  vmovaps [rsp+0xD0], xmm14
00007cd93bdd39c3  vmovaps [rsp+0xE0], xmm15
00007cd93bdd39cc  sub rsp, 0x30
00007cd93bdd39d0  movaps [rsp], xmm9
00007cd93bdd39d5  movaps [rsp+0x10], xmm8
00007cd93bdd39db  movaps [rsp+0x20], xmm10
00007cd93bdd39e1  lea rdi, [rsp]
00007cd93bdd39e5  mov esi, 0x00
00007cd93bdd39ea  mov rax, 0x64A581057530
00007cd93bdd39f4  call rax
00007cd93bdd39f6  movaps xmm9, [rsp]
00007cd93bdd39fb  add rsp, 0x30
00007cd93bdd39ff  vmovaps xmm0, [rsp]
00007cd93bdd3a04  vmovaps xmm1, [rsp+0x10]
00007cd93bdd3a0a  vmovaps xmm2, [rsp+0x20]
00007cd93bdd3a10  vmovaps xmm3, [rsp+0x30]
00007cd93bdd3a16  vmovaps xmm4, [rsp+0x40]
00007cd93bdd3a1c  vmovaps xmm5, [rsp+0x50]
00007cd93bdd3a22  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3a28  vmovaps xmm7, [rsp+0x70]
00007cd93bdd3a2e  vmovaps xmm8, [rsp+0x80]
00007cd93bdd3a37  vmovaps xmm10, [rsp+0x90]
00007cd93bdd3a40  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd3a49  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd3a52  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd3a5b  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd3a64  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3a6d  add rsp, 0xF0
00007cd93bdd3a74  pop r11
00007cd93bdd3a76  pop r10
00007cd93bdd3a78  pop r9
00007cd93bdd3a7a  pop r8
00007cd93bdd3a7c  pop rsi
00007cd93bdd3a7d  pop rdi
00007cd93bdd3a7e  pop rdx
00007cd93bdd3a7f  pop rcx
00007cd93bdd3a80  pop rax
00007cd93bdd3a81  add rsp, 0x08
00007cd93bdd3a85  jmp 0x00007CD93BDCFFE1
00007cd93bdd3a8a  sub rsp, 0x08
00007cd93bdd3a8e  push rax
00007cd93bdd3a8f  push rcx
00007cd93bdd3a90  push rdx
00007cd93bdd3a91  push rdi
00007cd93bdd3a92  push rsi
00007cd93bdd3a93  push r8
00007cd93bdd3a95  push r9
00007cd93bdd3a97  push r10
00007cd93bdd3a99  push r11
00007cd93bdd3a9b  sub rsp, 0xF0
00007cd93bdd3aa2  vmovaps [rsp], xmm0
00007cd93bdd3aa7  vmovaps [rsp+0x10], xmm1
00007cd93bdd3aad  vmovaps [rsp+0x20], xmm2
00007cd93bdd3ab3  vmovaps [rsp+0x30], xmm3
00007cd93bdd3ab9  vmovaps [rsp+0x40], xmm4
00007cd93bdd3abf  vmovaps [rsp+0x50], xmm5
00007cd93bdd3ac5  vmovaps [rsp+0x60], xmm6
00007cd93bdd3acb  vmovaps [rsp+0x70], xmm7
00007cd93bdd3ad1  vmovaps [rsp+0x80], xmm8
00007cd93bdd3ada  vmovaps [rsp+0x90], xmm9
00007cd93bdd3ae3  vmovaps [rsp+0xA0], xmm11
00007cd93bdd3aec  vmovaps [rsp+0xB0], xmm12
00007cd93bdd3af5  vmovaps [rsp+0xC0], xmm13
00007cd93bdd3afe  vmovaps [rsp+0xD0], xmm14
00007cd93bdd3b07  vmovaps [rsp+0xE0], xmm15
00007cd93bdd3b10  sub rsp, 0x30
00007cd93bdd3b14  movaps [rsp], xmm10
00007cd93bdd3b19  movaps [rsp+0x10], xmm1
00007cd93bdd3b1e  movaps [rsp+0x20], xmm11
00007cd93bdd3b24  lea rdi, [rsp]
00007cd93bdd3b28  mov esi, 0x00
00007cd93bdd3b2d  mov rax, 0x64A581057530
00007cd93bdd3b37  call rax
00007cd93bdd3b39  movaps xmm10, [rsp]
00007cd93bdd3b3e  add rsp, 0x30
00007cd93bdd3b42  vmovaps xmm0, [rsp]
00007cd93bdd3b47  vmovaps xmm1, [rsp+0x10]
00007cd93bdd3b4d  vmovaps xmm2, [rsp+0x20]
00007cd93bdd3b53  vmovaps xmm3, [rsp+0x30]
00007cd93bdd3b59  vmovaps xmm4, [rsp+0x40]
00007cd93bdd3b5f  vmovaps xmm5, [rsp+0x50]
00007cd93bdd3b65  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3b6b  vmovaps xmm7, [rsp+0x70]
00007cd93bdd3b71  vmovaps xmm8, [rsp+0x80]
00007cd93bdd3b7a  vmovaps xmm9, [rsp+0x90]
00007cd93bdd3b83  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd3b8c  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd3b95  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd3b9e  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd3ba7  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3bb0  add rsp, 0xF0
00007cd93bdd3bb7  pop r11
00007cd93bdd3bb9  pop r10
00007cd93bdd3bbb  pop r9
00007cd93bdd3bbd  pop r8
00007cd93bdd3bbf  pop rsi
00007cd93bdd3bc0  pop rdi
00007cd93bdd3bc1  pop rdx
00007cd93bdd3bc2  pop rcx
00007cd93bdd3bc3  pop rax
00007cd93bdd3bc4  add rsp, 0x08
00007cd93bdd3bc8  jmp 0x00007CD93BDCFFFC
00007cd93bdd3bcd  sub rsp, 0x08
00007cd93bdd3bd1  push rax
00007cd93bdd3bd2  push rcx
00007cd93bdd3bd3  push rdx
00007cd93bdd3bd4  push rdi
00007cd93bdd3bd5  push rsi
00007cd93bdd3bd6  push r8
00007cd93bdd3bd8  push r9
00007cd93bdd3bda  push r10
00007cd93bdd3bdc  push r11
00007cd93bdd3bde  sub rsp, 0xF0
00007cd93bdd3be5  vmovaps [rsp], xmm0
00007cd93bdd3bea  vmovaps [rsp+0x10], xmm2
00007cd93bdd3bf0  vmovaps [rsp+0x20], xmm3
00007cd93bdd3bf6  vmovaps [rsp+0x30], xmm4
00007cd93bdd3bfc  vmovaps [rsp+0x40], xmm5
00007cd93bdd3c02  vmovaps [rsp+0x50], xmm6
00007cd93bdd3c08  vmovaps [rsp+0x60], xmm7
00007cd93bdd3c0e  vmovaps [rsp+0x70], xmm8
00007cd93bdd3c14  vmovaps [rsp+0x80], xmm9
00007cd93bdd3c1d  vmovaps [rsp+0x90], xmm10
00007cd93bdd3c26  vmovaps [rsp+0xA0], xmm11
00007cd93bdd3c2f  vmovaps [rsp+0xB0], xmm12
00007cd93bdd3c38  vmovaps [rsp+0xC0], xmm13
00007cd93bdd3c41  vmovaps [rsp+0xD0], xmm14
00007cd93bdd3c4a  vmovaps [rsp+0xE0], xmm15
00007cd93bdd3c53  sub rsp, 0x30
00007cd93bdd3c57  movaps [rsp], xmm1
00007cd93bdd3c5b  movaps [rsp+0x10], xmm14
00007cd93bdd3c61  movaps [rsp+0x20], xmm6
00007cd93bdd3c66  lea rdi, [rsp]
00007cd93bdd3c6a  mov esi, 0x00
00007cd93bdd3c6f  mov rax, 0x64A581057530
00007cd93bdd3c79  call rax
00007cd93bdd3c7b  movaps xmm1, [rsp]
00007cd93bdd3c7f  add rsp, 0x30
00007cd93bdd3c83  vmovaps xmm0, [rsp]
00007cd93bdd3c88  vmovaps xmm2, [rsp+0x10]
00007cd93bdd3c8e  vmovaps xmm3, [rsp+0x20]
00007cd93bdd3c94  vmovaps xmm4, [rsp+0x30]
00007cd93bdd3c9a  vmovaps xmm5, [rsp+0x40]
00007cd93bdd3ca0  vmovaps xmm6, [rsp+0x50]
00007cd93bdd3ca6  vmovaps xmm7, [rsp+0x60]
00007cd93bdd3cac  vmovaps xmm8, [rsp+0x70]
00007cd93bdd3cb2  vmovaps xmm9, [rsp+0x80]
00007cd93bdd3cbb  vmovaps xmm10, [rsp+0x90]
00007cd93bdd3cc4  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd3ccd  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd3cd6  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd3cdf  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd3ce8  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3cf1  add rsp, 0xF0
00007cd93bdd3cf8  pop r11
00007cd93bdd3cfa  pop r10
00007cd93bdd3cfc  pop r9
00007cd93bdd3cfe  pop r8
00007cd93bdd3d00  pop rsi
00007cd93bdd3d01  pop rdi
00007cd93bdd3d02  pop rdx
00007cd93bdd3d03  pop rcx
00007cd93bdd3d04  pop rax
00007cd93bdd3d05  add rsp, 0x08
00007cd93bdd3d09  jmp 0x00007CD93BDD0015
00007cd93bdd3d0e  sub rsp, 0x08
00007cd93bdd3d12  push rax
00007cd93bdd3d13  push rcx
00007cd93bdd3d14  push rdx
00007cd93bdd3d15  push rdi
00007cd93bdd3d16  push rsi
00007cd93bdd3d17  push r8
00007cd93bdd3d19  push r9
00007cd93bdd3d1b  push r10
00007cd93bdd3d1d  push r11
00007cd93bdd3d1f  sub rsp, 0xF0
00007cd93bdd3d26  vmovaps [rsp], xmm0
00007cd93bdd3d2b  vmovaps [rsp+0x10], xmm1
00007cd93bdd3d31  vmovaps [rsp+0x20], xmm2
00007cd93bdd3d37  vmovaps [rsp+0x30], xmm3
00007cd93bdd3d3d  vmovaps [rsp+0x40], xmm4
00007cd93bdd3d43  vmovaps [rsp+0x50], xmm5
00007cd93bdd3d49  vmovaps [rsp+0x60], xmm6
00007cd93bdd3d4f  vmovaps [rsp+0x70], xmm7
00007cd93bdd3d55  vmovaps [rsp+0x80], xmm8
00007cd93bdd3d5e  vmovaps [rsp+0x90], xmm9
00007cd93bdd3d67  vmovaps [rsp+0xA0], xmm10
00007cd93bdd3d70  vmovaps [rsp+0xB0], xmm12
00007cd93bdd3d79  vmovaps [rsp+0xC0], xmm13
00007cd93bdd3d82  vmovaps [rsp+0xD0], xmm14
00007cd93bdd3d8b  vmovaps [rsp+0xE0], xmm15
00007cd93bdd3d94  sub rsp, 0x30
00007cd93bdd3d98  movaps [rsp], xmm11
00007cd93bdd3d9d  movaps [rsp+0x10], xmm13
00007cd93bdd3da3  movaps [rsp+0x20], xmm14
00007cd93bdd3da9  lea rdi, [rsp]
00007cd93bdd3dad  mov esi, 0x00
00007cd93bdd3db2  mov rax, 0x64A581057530
00007cd93bdd3dbc  call rax
00007cd93bdd3dbe  movaps xmm11, [rsp]
00007cd93bdd3dc3  add rsp, 0x30
00007cd93bdd3dc7  vmovaps xmm0, [rsp]
00007cd93bdd3dcc  vmovaps xmm1, [rsp+0x10]
00007cd93bdd3dd2  vmovaps xmm2, [rsp+0x20]
00007cd93bdd3dd8  vmovaps xmm3, [rsp+0x30]
00007cd93bdd3dde  vmovaps xmm4, [rsp+0x40]
00007cd93bdd3de4  vmovaps xmm5, [rsp+0x50]
00007cd93bdd3dea  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3df0  vmovaps xmm7, [rsp+0x70]
00007cd93bdd3df6  vmovaps xmm8, [rsp+0x80]
00007cd93bdd3dff  vmovaps xmm9, [rsp+0x90]
00007cd93bdd3e08  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd3e11  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd3e1a  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd3e23  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd3e2c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3e35  add rsp, 0xF0
00007cd93bdd3e3c  pop r11
00007cd93bdd3e3e  pop r10
00007cd93bdd3e40  pop r9
00007cd93bdd3e42  pop r8
00007cd93bdd3e44  pop rsi
00007cd93bdd3e45  pop rdi
00007cd93bdd3e46  pop rdx
00007cd93bdd3e47  pop rcx
00007cd93bdd3e48  pop rax
00007cd93bdd3e49  add rsp, 0x08
00007cd93bdd3e4d  jmp 0x00007CD93BDD003F
00007cd93bdd3e52  sub rsp, 0x08
00007cd93bdd3e56  push rax
00007cd93bdd3e57  push rcx
00007cd93bdd3e58  push rdx
00007cd93bdd3e59  push rdi
00007cd93bdd3e5a  push rsi
00007cd93bdd3e5b  push r8
00007cd93bdd3e5d  push r9
00007cd93bdd3e5f  push r10
00007cd93bdd3e61  push r11
00007cd93bdd3e63  sub rsp, 0xF0
00007cd93bdd3e6a  vmovaps [rsp], xmm0
00007cd93bdd3e6f  vmovaps [rsp+0x10], xmm1
00007cd93bdd3e75  vmovaps [rsp+0x20], xmm2
00007cd93bdd3e7b  vmovaps [rsp+0x30], xmm3
00007cd93bdd3e81  vmovaps [rsp+0x40], xmm4
00007cd93bdd3e87  vmovaps [rsp+0x50], xmm5
00007cd93bdd3e8d  vmovaps [rsp+0x60], xmm6
00007cd93bdd3e93  vmovaps [rsp+0x70], xmm7
00007cd93bdd3e99  vmovaps [rsp+0x80], xmm8
00007cd93bdd3ea2  vmovaps [rsp+0x90], xmm9
00007cd93bdd3eab  vmovaps [rsp+0xA0], xmm10
00007cd93bdd3eb4  vmovaps [rsp+0xB0], xmm11
00007cd93bdd3ebd  vmovaps [rsp+0xC0], xmm12
00007cd93bdd3ec6  vmovaps [rsp+0xD0], xmm14
00007cd93bdd3ecf  vmovaps [rsp+0xE0], xmm15
00007cd93bdd3ed8  sub rsp, 0x30
00007cd93bdd3edc  movaps [rsp], xmm13
00007cd93bdd3ee1  movaps [rsp+0x10], xmm8
00007cd93bdd3ee7  movaps [rsp+0x20], xmm14
00007cd93bdd3eed  lea rdi, [rsp]
00007cd93bdd3ef1  mov esi, 0x00
00007cd93bdd3ef6  mov rax, 0x64A581057530
00007cd93bdd3f00  call rax
00007cd93bdd3f02  movaps xmm13, [rsp]
00007cd93bdd3f07  add rsp, 0x30
00007cd93bdd3f0b  vmovaps xmm0, [rsp]
00007cd93bdd3f10  vmovaps xmm1, [rsp+0x10]
00007cd93bdd3f16  vmovaps xmm2, [rsp+0x20]
00007cd93bdd3f1c  vmovaps xmm3, [rsp+0x30]
00007cd93bdd3f22  vmovaps xmm4, [rsp+0x40]
00007cd93bdd3f28  vmovaps xmm5, [rsp+0x50]
00007cd93bdd3f2e  vmovaps xmm6, [rsp+0x60]
00007cd93bdd3f34  vmovaps xmm7, [rsp+0x70]
00007cd93bdd3f3a  vmovaps xmm8, [rsp+0x80]
00007cd93bdd3f43  vmovaps xmm9, [rsp+0x90]
00007cd93bdd3f4c  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd3f55  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd3f5e  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd3f67  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd3f70  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd3f79  add rsp, 0xF0
00007cd93bdd3f80  pop r11
00007cd93bdd3f82  pop r10
00007cd93bdd3f84  pop r9
00007cd93bdd3f86  pop r8
00007cd93bdd3f88  pop rsi
00007cd93bdd3f89  pop rdi
00007cd93bdd3f8a  pop rdx
00007cd93bdd3f8b  pop rcx
00007cd93bdd3f8c  pop rax
00007cd93bdd3f8d  add rsp, 0x08
00007cd93bdd3f91  jmp 0x00007CD93BDD006E
00007cd93bdd3f96  sub rsp, 0x08
00007cd93bdd3f9a  push rax
00007cd93bdd3f9b  push rcx
00007cd93bdd3f9c  push rdx
00007cd93bdd3f9d  push rdi
00007cd93bdd3f9e  push rsi
00007cd93bdd3f9f  push r8
00007cd93bdd3fa1  push r9
00007cd93bdd3fa3  push r10
00007cd93bdd3fa5  push r11
00007cd93bdd3fa7  sub rsp, 0xF0
00007cd93bdd3fae  vmovaps [rsp], xmm0
00007cd93bdd3fb3  vmovaps [rsp+0x10], xmm1
00007cd93bdd3fb9  vmovaps [rsp+0x20], xmm2
00007cd93bdd3fbf  vmovaps [rsp+0x30], xmm3
00007cd93bdd3fc5  vmovaps [rsp+0x40], xmm4
00007cd93bdd3fcb  vmovaps [rsp+0x50], xmm5
00007cd93bdd3fd1  vmovaps [rsp+0x60], xmm6
00007cd93bdd3fd7  vmovaps [rsp+0x70], xmm7
00007cd93bdd3fdd  vmovaps [rsp+0x80], xmm9
00007cd93bdd3fe6  vmovaps [rsp+0x90], xmm10
00007cd93bdd3fef  vmovaps [rsp+0xA0], xmm11
00007cd93bdd3ff8  vmovaps [rsp+0xB0], xmm12
00007cd93bdd4001  vmovaps [rsp+0xC0], xmm13
00007cd93bdd400a  vmovaps [rsp+0xD0], xmm14
00007cd93bdd4013  vmovaps [rsp+0xE0], xmm15
00007cd93bdd401c  sub rsp, 0x30
00007cd93bdd4020  movaps [rsp], xmm8
00007cd93bdd4025  movaps [rsp+0x10], xmm7
00007cd93bdd402a  movaps [rsp+0x20], xmm14
00007cd93bdd4030  lea rdi, [rsp]
00007cd93bdd4034  mov esi, 0x00
00007cd93bdd4039  mov rax, 0x64A581057530
00007cd93bdd4043  call rax
00007cd93bdd4045  movaps xmm8, [rsp]
00007cd93bdd404a  add rsp, 0x30
00007cd93bdd404e  vmovaps xmm0, [rsp]
00007cd93bdd4053  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4059  vmovaps xmm2, [rsp+0x20]
00007cd93bdd405f  vmovaps xmm3, [rsp+0x30]
00007cd93bdd4065  vmovaps xmm4, [rsp+0x40]
00007cd93bdd406b  vmovaps xmm5, [rsp+0x50]
00007cd93bdd4071  vmovaps xmm6, [rsp+0x60]
00007cd93bdd4077  vmovaps xmm7, [rsp+0x70]
00007cd93bdd407d  vmovaps xmm9, [rsp+0x80]
00007cd93bdd4086  vmovaps xmm10, [rsp+0x90]
00007cd93bdd408f  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd4098  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd40a1  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd40aa  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd40b3  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd40bc  add rsp, 0xF0
00007cd93bdd40c3  pop r11
00007cd93bdd40c5  pop r10
00007cd93bdd40c7  pop r9
00007cd93bdd40c9  pop r8
00007cd93bdd40cb  pop rsi
00007cd93bdd40cc  pop rdi
00007cd93bdd40cd  pop rdx
00007cd93bdd40ce  pop rcx
00007cd93bdd40cf  pop rax
00007cd93bdd40d0  add rsp, 0x08
00007cd93bdd40d4  jmp 0x00007CD93BDD0094
00007cd93bdd40d9  sub rsp, 0x08
00007cd93bdd40dd  push rax
00007cd93bdd40de  push rcx
00007cd93bdd40df  push rdx
00007cd93bdd40e0  push rdi
00007cd93bdd40e1  push rsi
00007cd93bdd40e2  push r8
00007cd93bdd40e4  push r9
00007cd93bdd40e6  push r10
00007cd93bdd40e8  push r11
00007cd93bdd40ea  sub rsp, 0xF0
00007cd93bdd40f1  vmovaps [rsp], xmm0
00007cd93bdd40f6  vmovaps [rsp+0x10], xmm1
00007cd93bdd40fc  vmovaps [rsp+0x20], xmm2
00007cd93bdd4102  vmovaps [rsp+0x30], xmm3
00007cd93bdd4108  vmovaps [rsp+0x40], xmm4
00007cd93bdd410e  vmovaps [rsp+0x50], xmm5
00007cd93bdd4114  vmovaps [rsp+0x60], xmm6
00007cd93bdd411a  vmovaps [rsp+0x70], xmm7
00007cd93bdd4120  vmovaps [rsp+0x80], xmm8
00007cd93bdd4129  vmovaps [rsp+0x90], xmm9
00007cd93bdd4132  vmovaps [rsp+0xA0], xmm10
00007cd93bdd413b  vmovaps [rsp+0xB0], xmm11
00007cd93bdd4144  vmovaps [rsp+0xC0], xmm12
00007cd93bdd414d  vmovaps [rsp+0xD0], xmm13
00007cd93bdd4156  vmovaps [rsp+0xE0], xmm15
00007cd93bdd415f  sub rsp, 0x30
00007cd93bdd4163  movaps [rsp], xmm14
00007cd93bdd4168  movaps [rsp+0x10], xmm12
00007cd93bdd416e  movaps [rsp+0x20], xmm9
00007cd93bdd4174  lea rdi, [rsp]
00007cd93bdd4178  mov esi, 0x00
00007cd93bdd417d  mov rax, 0x64A581057530
00007cd93bdd4187  call rax
00007cd93bdd4189  movaps xmm14, [rsp]
00007cd93bdd418e  add rsp, 0x30
00007cd93bdd4192  vmovaps xmm0, [rsp]
00007cd93bdd4197  vmovaps xmm1, [rsp+0x10]
00007cd93bdd419d  vmovaps xmm2, [rsp+0x20]
00007cd93bdd41a3  vmovaps xmm3, [rsp+0x30]
00007cd93bdd41a9  vmovaps xmm4, [rsp+0x40]
00007cd93bdd41af  vmovaps xmm5, [rsp+0x50]
00007cd93bdd41b5  vmovaps xmm6, [rsp+0x60]
00007cd93bdd41bb  vmovaps xmm7, [rsp+0x70]
00007cd93bdd41c1  vmovaps xmm8, [rsp+0x80]
00007cd93bdd41ca  vmovaps xmm9, [rsp+0x90]
00007cd93bdd41d3  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd41dc  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd41e5  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd41ee  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd41f7  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4200  add rsp, 0xF0
00007cd93bdd4207  pop r11
00007cd93bdd4209  pop r10
00007cd93bdd420b  pop r9
00007cd93bdd420d  pop r8
00007cd93bdd420f  pop rsi
00007cd93bdd4210  pop rdi
00007cd93bdd4211  pop rdx
00007cd93bdd4212  pop rcx
00007cd93bdd4213  pop rax
00007cd93bdd4214  add rsp, 0x08
00007cd93bdd4218  jmp 0x00007CD93BDD00AE
00007cd93bdd421d  sub rsp, 0x08
00007cd93bdd4221  push rax
00007cd93bdd4222  push rcx
00007cd93bdd4223  push rdx
00007cd93bdd4224  push rdi
00007cd93bdd4225  push rsi
00007cd93bdd4226  push r8
00007cd93bdd4228  push r9
00007cd93bdd422a  push r10
00007cd93bdd422c  push r11
00007cd93bdd422e  sub rsp, 0xF0
00007cd93bdd4235  vmovaps [rsp], xmm0
00007cd93bdd423a  vmovaps [rsp+0x10], xmm1
00007cd93bdd4240  vmovaps [rsp+0x20], xmm2
00007cd93bdd4246  vmovaps [rsp+0x30], xmm3
00007cd93bdd424c  vmovaps [rsp+0x40], xmm4
00007cd93bdd4252  vmovaps [rsp+0x50], xmm5
00007cd93bdd4258  vmovaps [rsp+0x60], xmm6
00007cd93bdd425e  vmovaps [rsp+0x70], xmm7
00007cd93bdd4264  vmovaps [rsp+0x80], xmm8
00007cd93bdd426d  vmovaps [rsp+0x90], xmm10
00007cd93bdd4276  vmovaps [rsp+0xA0], xmm11
00007cd93bdd427f  vmovaps [rsp+0xB0], xmm12
00007cd93bdd4288  vmovaps [rsp+0xC0], xmm13
00007cd93bdd4291  vmovaps [rsp+0xD0], xmm14
00007cd93bdd429a  vmovaps [rsp+0xE0], xmm15
00007cd93bdd42a3  sub rsp, 0x30
00007cd93bdd42a7  movaps [rsp], xmm9
00007cd93bdd42ac  movaps [rsp+0x10], xmm7
00007cd93bdd42b1  movaps [rsp+0x20], xmm12
00007cd93bdd42b7  lea rdi, [rsp]
00007cd93bdd42bb  mov esi, 0x00
00007cd93bdd42c0  mov rax, 0x64A581057530
00007cd93bdd42ca  call rax
00007cd93bdd42cc  movaps xmm9, [rsp]
00007cd93bdd42d1  add rsp, 0x30
00007cd93bdd42d5  vmovaps xmm0, [rsp]
00007cd93bdd42da  vmovaps xmm1, [rsp+0x10]
00007cd93bdd42e0  vmovaps xmm2, [rsp+0x20]
00007cd93bdd42e6  vmovaps xmm3, [rsp+0x30]
00007cd93bdd42ec  vmovaps xmm4, [rsp+0x40]
00007cd93bdd42f2  vmovaps xmm5, [rsp+0x50]
00007cd93bdd42f8  vmovaps xmm6, [rsp+0x60]
00007cd93bdd42fe  vmovaps xmm7, [rsp+0x70]
00007cd93bdd4304  vmovaps xmm8, [rsp+0x80]
00007cd93bdd430d  vmovaps xmm10, [rsp+0x90]
00007cd93bdd4316  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd431f  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd4328  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd4331  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd433a  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4343  add rsp, 0xF0
00007cd93bdd434a  pop r11
00007cd93bdd434c  pop r10
00007cd93bdd434e  pop r9
00007cd93bdd4350  pop r8
00007cd93bdd4352  pop rsi
00007cd93bdd4353  pop rdi
00007cd93bdd4354  pop rdx
00007cd93bdd4355  pop rcx
00007cd93bdd4356  pop rax
00007cd93bdd4357  add rsp, 0x08
00007cd93bdd435b  jmp 0x00007CD93BDD00DD
00007cd93bdd4360  sub rsp, 0x08
00007cd93bdd4364  push rax
00007cd93bdd4365  push rcx
00007cd93bdd4366  push rdx
00007cd93bdd4367  push rdi
00007cd93bdd4368  push rsi
00007cd93bdd4369  push r8
00007cd93bdd436b  push r9
00007cd93bdd436d  push r10
00007cd93bdd436f  push r11
00007cd93bdd4371  sub rsp, 0xF0
00007cd93bdd4378  vmovaps [rsp], xmm0
00007cd93bdd437d  vmovaps [rsp+0x10], xmm1
00007cd93bdd4383  vmovaps [rsp+0x20], xmm2
00007cd93bdd4389  vmovaps [rsp+0x30], xmm3
00007cd93bdd438f  vmovaps [rsp+0x40], xmm4
00007cd93bdd4395  vmovaps [rsp+0x50], xmm5
00007cd93bdd439b  vmovaps [rsp+0x60], xmm6
00007cd93bdd43a1  vmovaps [rsp+0x70], xmm7
00007cd93bdd43a7  vmovaps [rsp+0x80], xmm8
00007cd93bdd43b0  vmovaps [rsp+0x90], xmm9
00007cd93bdd43b9  vmovaps [rsp+0xA0], xmm10
00007cd93bdd43c2  vmovaps [rsp+0xB0], xmm11
00007cd93bdd43cb  vmovaps [rsp+0xC0], xmm13
00007cd93bdd43d4  vmovaps [rsp+0xD0], xmm14
00007cd93bdd43dd  vmovaps [rsp+0xE0], xmm15
00007cd93bdd43e6  sub rsp, 0x30
00007cd93bdd43ea  movaps [rsp], xmm12
00007cd93bdd43ef  movaps [rsp+0x10], xmm15
00007cd93bdd43f5  movaps [rsp+0x20], xmm11
00007cd93bdd43fb  lea rdi, [rsp]
00007cd93bdd43ff  mov esi, 0x00
00007cd93bdd4404  mov rax, 0x64A581057530
00007cd93bdd440e  call rax
00007cd93bdd4410  movaps xmm12, [rsp]
00007cd93bdd4415  add rsp, 0x30
00007cd93bdd4419  vmovaps xmm0, [rsp]
00007cd93bdd441e  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4424  vmovaps xmm2, [rsp+0x20]
00007cd93bdd442a  vmovaps xmm3, [rsp+0x30]
00007cd93bdd4430  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4436  vmovaps xmm5, [rsp+0x50]
00007cd93bdd443c  vmovaps xmm6, [rsp+0x60]
00007cd93bdd4442  vmovaps xmm7, [rsp+0x70]
00007cd93bdd4448  vmovaps xmm8, [rsp+0x80]
00007cd93bdd4451  vmovaps xmm9, [rsp+0x90]
00007cd93bdd445a  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd4463  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd446c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd4475  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd447e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4487  add rsp, 0xF0
00007cd93bdd448e  pop r11
00007cd93bdd4490  pop r10
00007cd93bdd4492  pop r9
00007cd93bdd4494  pop r8
00007cd93bdd4496  pop rsi
00007cd93bdd4497  pop rdi
00007cd93bdd4498  pop rdx
00007cd93bdd4499  pop rcx
00007cd93bdd449a  pop rax
00007cd93bdd449b  add rsp, 0x08
00007cd93bdd449f  jmp 0x00007CD93BDD00F7
00007cd93bdd44a4  sub rsp, 0x08
00007cd93bdd44a8  push rax
00007cd93bdd44a9  push rcx
00007cd93bdd44aa  push rdx
00007cd93bdd44ab  push rdi
00007cd93bdd44ac  push rsi
00007cd93bdd44ad  push r8
00007cd93bdd44af  push r9
00007cd93bdd44b1  push r10
00007cd93bdd44b3  push r11
00007cd93bdd44b5  sub rsp, 0xF0
00007cd93bdd44bc  vmovaps [rsp], xmm0
00007cd93bdd44c1  vmovaps [rsp+0x10], xmm1
00007cd93bdd44c7  vmovaps [rsp+0x20], xmm2
00007cd93bdd44cd  vmovaps [rsp+0x30], xmm3
00007cd93bdd44d3  vmovaps [rsp+0x40], xmm4
00007cd93bdd44d9  vmovaps [rsp+0x50], xmm5
00007cd93bdd44df  vmovaps [rsp+0x60], xmm6
00007cd93bdd44e5  vmovaps [rsp+0x70], xmm7
00007cd93bdd44eb  vmovaps [rsp+0x80], xmm8
00007cd93bdd44f4  vmovaps [rsp+0x90], xmm9
00007cd93bdd44fd  vmovaps [rsp+0xA0], xmm10
00007cd93bdd4506  vmovaps [rsp+0xB0], xmm12
00007cd93bdd450f  vmovaps [rsp+0xC0], xmm13
00007cd93bdd4518  vmovaps [rsp+0xD0], xmm14
00007cd93bdd4521  vmovaps [rsp+0xE0], xmm15
00007cd93bdd452a  sub rsp, 0x30
00007cd93bdd452e  movaps [rsp], xmm11
00007cd93bdd4533  movaps [rsp+0x10], xmm7
00007cd93bdd4538  movaps [rsp+0x20], xmm15
00007cd93bdd453e  lea rdi, [rsp]
00007cd93bdd4542  mov esi, 0x00
00007cd93bdd4547  mov rax, 0x64A581057530
00007cd93bdd4551  call rax
00007cd93bdd4553  movaps xmm11, [rsp]
00007cd93bdd4558  add rsp, 0x30
00007cd93bdd455c  vmovaps xmm0, [rsp]
00007cd93bdd4561  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4567  vmovaps xmm2, [rsp+0x20]
00007cd93bdd456d  vmovaps xmm3, [rsp+0x30]
00007cd93bdd4573  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4579  vmovaps xmm5, [rsp+0x50]
00007cd93bdd457f  vmovaps xmm6, [rsp+0x60]
00007cd93bdd4585  vmovaps xmm7, [rsp+0x70]
00007cd93bdd458b  vmovaps xmm8, [rsp+0x80]
00007cd93bdd4594  vmovaps xmm9, [rsp+0x90]
00007cd93bdd459d  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd45a6  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd45af  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd45b8  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd45c1  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd45ca  add rsp, 0xF0
00007cd93bdd45d1  pop r11
00007cd93bdd45d3  pop r10
00007cd93bdd45d5  pop r9
00007cd93bdd45d7  pop r8
00007cd93bdd45d9  pop rsi
00007cd93bdd45da  pop rdi
00007cd93bdd45db  pop rdx
00007cd93bdd45dc  pop rcx
00007cd93bdd45dd  pop rax
00007cd93bdd45de  add rsp, 0x08
00007cd93bdd45e2  jmp 0x00007CD93BDD0123
00007cd93bdd45e7  sub rsp, 0x08
00007cd93bdd45eb  push rax
00007cd93bdd45ec  push rcx
00007cd93bdd45ed  push rdx
00007cd93bdd45ee  push rdi
00007cd93bdd45ef  push rsi
00007cd93bdd45f0  push r8
00007cd93bdd45f2  push r9
00007cd93bdd45f4  push r10
00007cd93bdd45f6  push r11
00007cd93bdd45f8  sub rsp, 0xF0
00007cd93bdd45ff  vmovaps [rsp], xmm0
00007cd93bdd4604  vmovaps [rsp+0x10], xmm1
00007cd93bdd460a  vmovaps [rsp+0x20], xmm2
00007cd93bdd4610  vmovaps [rsp+0x30], xmm3
00007cd93bdd4616  vmovaps [rsp+0x40], xmm4
00007cd93bdd461c  vmovaps [rsp+0x50], xmm5
00007cd93bdd4622  vmovaps [rsp+0x60], xmm6
00007cd93bdd4628  vmovaps [rsp+0x70], xmm7
00007cd93bdd462e  vmovaps [rsp+0x80], xmm8
00007cd93bdd4637  vmovaps [rsp+0x90], xmm9
00007cd93bdd4640  vmovaps [rsp+0xA0], xmm10
00007cd93bdd4649  vmovaps [rsp+0xB0], xmm11
00007cd93bdd4652  vmovaps [rsp+0xC0], xmm12
00007cd93bdd465b  vmovaps [rsp+0xD0], xmm13
00007cd93bdd4664  vmovaps [rsp+0xE0], xmm14
00007cd93bdd466d  sub rsp, 0x30
00007cd93bdd4671  movaps [rsp], xmm15
00007cd93bdd4676  movaps [rsp+0x10], xmm10
00007cd93bdd467c  movaps [rsp+0x20], xmm13
00007cd93bdd4682  lea rdi, [rsp]
00007cd93bdd4686  mov esi, 0x00
00007cd93bdd468b  mov rax, 0x64A581057530
00007cd93bdd4695  call rax
00007cd93bdd4697  movaps xmm15, [rsp]
00007cd93bdd469c  add rsp, 0x30
00007cd93bdd46a0  vmovaps xmm0, [rsp]
00007cd93bdd46a5  vmovaps xmm1, [rsp+0x10]
00007cd93bdd46ab  vmovaps xmm2, [rsp+0x20]
00007cd93bdd46b1  vmovaps xmm3, [rsp+0x30]
00007cd93bdd46b7  vmovaps xmm4, [rsp+0x40]
00007cd93bdd46bd  vmovaps xmm5, [rsp+0x50]
00007cd93bdd46c3  vmovaps xmm6, [rsp+0x60]
00007cd93bdd46c9  vmovaps xmm7, [rsp+0x70]
00007cd93bdd46cf  vmovaps xmm8, [rsp+0x80]
00007cd93bdd46d8  vmovaps xmm9, [rsp+0x90]
00007cd93bdd46e1  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd46ea  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd46f3  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd46fc  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd4705  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd470e  add rsp, 0xF0
00007cd93bdd4715  pop r11
00007cd93bdd4717  pop r10
00007cd93bdd4719  pop r9
00007cd93bdd471b  pop r8
00007cd93bdd471d  pop rsi
00007cd93bdd471e  pop rdi
00007cd93bdd471f  pop rdx
00007cd93bdd4720  pop rcx
00007cd93bdd4721  pop rax
00007cd93bdd4722  add rsp, 0x08
00007cd93bdd4726  jmp 0x00007CD93BDD013D
00007cd93bdd472b  sub rsp, 0x08
00007cd93bdd472f  push rax
00007cd93bdd4730  push rcx
00007cd93bdd4731  push rdx
00007cd93bdd4732  push rdi
00007cd93bdd4733  push rsi
00007cd93bdd4734  push r8
00007cd93bdd4736  push r9
00007cd93bdd4738  push r10
00007cd93bdd473a  push r11
00007cd93bdd473c  sub rsp, 0xF0
00007cd93bdd4743  vmovaps [rsp], xmm0
00007cd93bdd4748  vmovaps [rsp+0x10], xmm1
00007cd93bdd474e  vmovaps [rsp+0x20], xmm2
00007cd93bdd4754  vmovaps [rsp+0x30], xmm3
00007cd93bdd475a  vmovaps [rsp+0x40], xmm4
00007cd93bdd4760  vmovaps [rsp+0x50], xmm5
00007cd93bdd4766  vmovaps [rsp+0x60], xmm6
00007cd93bdd476c  vmovaps [rsp+0x70], xmm7
00007cd93bdd4772  vmovaps [rsp+0x80], xmm8
00007cd93bdd477b  vmovaps [rsp+0x90], xmm9
00007cd93bdd4784  vmovaps [rsp+0xA0], xmm11
00007cd93bdd478d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd4796  vmovaps [rsp+0xC0], xmm13
00007cd93bdd479f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd47a8  vmovaps [rsp+0xE0], xmm15
00007cd93bdd47b1  sub rsp, 0x30
00007cd93bdd47b5  movaps [rsp], xmm10
00007cd93bdd47ba  movaps [rsp+0x10], xmm7
00007cd93bdd47bf  movaps [rsp+0x20], xmm13
00007cd93bdd47c5  lea rdi, [rsp]
00007cd93bdd47c9  mov esi, 0x00
00007cd93bdd47ce  mov rax, 0x64A581057530
00007cd93bdd47d8  call rax
00007cd93bdd47da  movaps xmm10, [rsp]
00007cd93bdd47df  add rsp, 0x30
00007cd93bdd47e3  vmovaps xmm0, [rsp]
00007cd93bdd47e8  vmovaps xmm1, [rsp+0x10]
00007cd93bdd47ee  vmovaps xmm2, [rsp+0x20]
00007cd93bdd47f4  vmovaps xmm3, [rsp+0x30]
00007cd93bdd47fa  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4800  vmovaps xmm5, [rsp+0x50]
00007cd93bdd4806  vmovaps xmm6, [rsp+0x60]
00007cd93bdd480c  vmovaps xmm7, [rsp+0x70]
00007cd93bdd4812  vmovaps xmm8, [rsp+0x80]
00007cd93bdd481b  vmovaps xmm9, [rsp+0x90]
00007cd93bdd4824  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd482d  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd4836  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd483f  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd4848  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4851  add rsp, 0xF0
00007cd93bdd4858  pop r11
00007cd93bdd485a  pop r10
00007cd93bdd485c  pop r9
00007cd93bdd485e  pop r8
00007cd93bdd4860  pop rsi
00007cd93bdd4861  pop rdi
00007cd93bdd4862  pop rdx
00007cd93bdd4863  pop rcx
00007cd93bdd4864  pop rax
00007cd93bdd4865  add rsp, 0x08
00007cd93bdd4869  jmp 0x00007CD93BDD0169
00007cd93bdd486e  sub rsp, 0x08
00007cd93bdd4872  push rax
00007cd93bdd4873  push rcx
00007cd93bdd4874  push rdx
00007cd93bdd4875  push rdi
00007cd93bdd4876  push rsi
00007cd93bdd4877  push r8
00007cd93bdd4879  push r9
00007cd93bdd487b  push r10
00007cd93bdd487d  push r11
00007cd93bdd487f  sub rsp, 0xF0
00007cd93bdd4886  vmovaps [rsp], xmm0
00007cd93bdd488b  vmovaps [rsp+0x10], xmm1
00007cd93bdd4891  vmovaps [rsp+0x20], xmm2
00007cd93bdd4897  vmovaps [rsp+0x30], xmm3
00007cd93bdd489d  vmovaps [rsp+0x40], xmm4
00007cd93bdd48a3  vmovaps [rsp+0x50], xmm5
00007cd93bdd48a9  vmovaps [rsp+0x60], xmm6
00007cd93bdd48af  vmovaps [rsp+0x70], xmm7
00007cd93bdd48b5  vmovaps [rsp+0x80], xmm8
00007cd93bdd48be  vmovaps [rsp+0x90], xmm9
00007cd93bdd48c7  vmovaps [rsp+0xA0], xmm10
00007cd93bdd48d0  vmovaps [rsp+0xB0], xmm11
00007cd93bdd48d9  vmovaps [rsp+0xC0], xmm12
00007cd93bdd48e2  vmovaps [rsp+0xD0], xmm14
00007cd93bdd48eb  vmovaps [rsp+0xE0], xmm15
00007cd93bdd48f4  sub rsp, 0x30
00007cd93bdd48f8  movaps [rsp], xmm13
00007cd93bdd48fd  movaps [rsp+0x10], xmm1
00007cd93bdd4902  movaps [rsp+0x20], xmm8
00007cd93bdd4908  lea rdi, [rsp]
00007cd93bdd490c  mov esi, 0x00
00007cd93bdd4911  mov rax, 0x64A581057530
00007cd93bdd491b  call rax
00007cd93bdd491d  movaps xmm13, [rsp]
00007cd93bdd4922  add rsp, 0x30
00007cd93bdd4926  vmovaps xmm0, [rsp]
00007cd93bdd492b  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4931  vmovaps xmm2, [rsp+0x20]
00007cd93bdd4937  vmovaps xmm3, [rsp+0x30]
00007cd93bdd493d  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4943  vmovaps xmm5, [rsp+0x50]
00007cd93bdd4949  vmovaps xmm6, [rsp+0x60]
00007cd93bdd494f  vmovaps xmm7, [rsp+0x70]
00007cd93bdd4955  vmovaps xmm8, [rsp+0x80]
00007cd93bdd495e  vmovaps xmm9, [rsp+0x90]
00007cd93bdd4967  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd4970  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd4979  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd4982  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd498b  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4994  add rsp, 0xF0
00007cd93bdd499b  pop r11
00007cd93bdd499d  pop r10
00007cd93bdd499f  pop r9
00007cd93bdd49a1  pop r8
00007cd93bdd49a3  pop rsi
00007cd93bdd49a4  pop rdi
00007cd93bdd49a5  pop rdx
00007cd93bdd49a6  pop rcx
00007cd93bdd49a7  pop rax
00007cd93bdd49a8  add rsp, 0x08
00007cd93bdd49ac  jmp 0x00007CD93BDD0183
00007cd93bdd49b1  call 0x00007CD93BBFF430
00007cd93bdd49b6  jmp 0x00007CD93BDD018D
00007cd93bdd49bb  sub rsp, 0x08
00007cd93bdd49bf  push rax
00007cd93bdd49c0  push rcx
00007cd93bdd49c1  push rdx
00007cd93bdd49c2  push rdi
00007cd93bdd49c3  push rsi
00007cd93bdd49c4  push r8
00007cd93bdd49c6  push r9
00007cd93bdd49c8  push r10
00007cd93bdd49ca  push r11
00007cd93bdd49cc  sub rsp, 0xF0
00007cd93bdd49d3  vmovaps [rsp], xmm0
00007cd93bdd49d8  vmovaps [rsp+0x10], xmm1
00007cd93bdd49de  vmovaps [rsp+0x20], xmm2
00007cd93bdd49e4  vmovaps [rsp+0x30], xmm3
00007cd93bdd49ea  vmovaps [rsp+0x40], xmm4
00007cd93bdd49f0  vmovaps [rsp+0x50], xmm5
00007cd93bdd49f6  vmovaps [rsp+0x60], xmm6
00007cd93bdd49fc  vmovaps [rsp+0x70], xmm7
00007cd93bdd4a02  vmovaps [rsp+0x80], xmm9
00007cd93bdd4a0b  vmovaps [rsp+0x90], xmm10
00007cd93bdd4a14  vmovaps [rsp+0xA0], xmm11
00007cd93bdd4a1d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd4a26  vmovaps [rsp+0xC0], xmm13
00007cd93bdd4a2f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd4a38  vmovaps [rsp+0xE0], xmm15
00007cd93bdd4a41  sub rsp, 0x30
00007cd93bdd4a45  movaps [rsp], xmm8
00007cd93bdd4a4a  movaps [rsp+0x10], xmm14
00007cd93bdd4a50  movaps [rsp+0x20], xmm9
00007cd93bdd4a56  lea rdi, [rsp]
00007cd93bdd4a5a  mov esi, 0x00
00007cd93bdd4a5f  mov rax, 0x64A581057530
00007cd93bdd4a69  call rax
00007cd93bdd4a6b  movaps xmm8, [rsp]
00007cd93bdd4a70  add rsp, 0x30
00007cd93bdd4a74  vmovaps xmm0, [rsp]
00007cd93bdd4a79  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4a7f  vmovaps xmm2, [rsp+0x20]
00007cd93bdd4a85  vmovaps xmm3, [rsp+0x30]
00007cd93bdd4a8b  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4a91  vmovaps xmm5, [rsp+0x50]
00007cd93bdd4a97  vmovaps xmm6, [rsp+0x60]
00007cd93bdd4a9d  vmovaps xmm7, [rsp+0x70]
00007cd93bdd4aa3  vmovaps xmm9, [rsp+0x80]
00007cd93bdd4aac  vmovaps xmm10, [rsp+0x90]
00007cd93bdd4ab5  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd4abe  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd4ac7  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd4ad0  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd4ad9  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4ae2  add rsp, 0xF0
00007cd93bdd4ae9  pop r11
00007cd93bdd4aeb  pop r10
00007cd93bdd4aed  pop r9
00007cd93bdd4aef  pop r8
00007cd93bdd4af1  pop rsi
00007cd93bdd4af2  pop rdi
00007cd93bdd4af3  pop rdx
00007cd93bdd4af4  pop rcx
00007cd93bdd4af5  pop rax
00007cd93bdd4af6  add rsp, 0x08
00007cd93bdd4afa  jmp 0x00007CD93BDD01AF
00007cd93bdd4aff  sub rsp, 0x08
00007cd93bdd4b03  push rax
00007cd93bdd4b04  push rcx
00007cd93bdd4b05  push rdx
00007cd93bdd4b06  push rdi
00007cd93bdd4b07  push rsi
00007cd93bdd4b08  push r8
00007cd93bdd4b0a  push r9
00007cd93bdd4b0c  push r10
00007cd93bdd4b0e  push r11
00007cd93bdd4b10  sub rsp, 0xF0
00007cd93bdd4b17  vmovaps [rsp], xmm0
00007cd93bdd4b1c  vmovaps [rsp+0x10], xmm1
00007cd93bdd4b22  vmovaps [rsp+0x20], xmm2
00007cd93bdd4b28  vmovaps [rsp+0x30], xmm3
00007cd93bdd4b2e  vmovaps [rsp+0x40], xmm4
00007cd93bdd4b34  vmovaps [rsp+0x50], xmm5
00007cd93bdd4b3a  vmovaps [rsp+0x60], xmm6
00007cd93bdd4b40  vmovaps [rsp+0x70], xmm7
00007cd93bdd4b46  vmovaps [rsp+0x80], xmm8
00007cd93bdd4b4f  vmovaps [rsp+0x90], xmm10
00007cd93bdd4b58  vmovaps [rsp+0xA0], xmm11
00007cd93bdd4b61  vmovaps [rsp+0xB0], xmm12
00007cd93bdd4b6a  vmovaps [rsp+0xC0], xmm13
00007cd93bdd4b73  vmovaps [rsp+0xD0], xmm14
00007cd93bdd4b7c  vmovaps [rsp+0xE0], xmm15
00007cd93bdd4b85  sub rsp, 0x30
00007cd93bdd4b89  movaps [rsp], xmm9
00007cd93bdd4b8e  movaps [rsp+0x10], xmm1
00007cd93bdd4b93  movaps [rsp+0x20], xmm14
00007cd93bdd4b99  lea rdi, [rsp]
00007cd93bdd4b9d  mov esi, 0x00
00007cd93bdd4ba2  mov rax, 0x64A581057530
00007cd93bdd4bac  call rax
00007cd93bdd4bae  movaps xmm9, [rsp]
00007cd93bdd4bb3  add rsp, 0x30
00007cd93bdd4bb7  vmovaps xmm0, [rsp]
00007cd93bdd4bbc  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4bc2  vmovaps xmm2, [rsp+0x20]
00007cd93bdd4bc8  vmovaps xmm3, [rsp+0x30]
00007cd93bdd4bce  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4bd4  vmovaps xmm5, [rsp+0x50]
00007cd93bdd4bda  vmovaps xmm6, [rsp+0x60]
00007cd93bdd4be0  vmovaps xmm7, [rsp+0x70]
00007cd93bdd4be6  vmovaps xmm8, [rsp+0x80]
00007cd93bdd4bef  vmovaps xmm10, [rsp+0x90]
00007cd93bdd4bf8  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd4c01  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd4c0a  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd4c13  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd4c1c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4c25  add rsp, 0xF0
00007cd93bdd4c2c  pop r11
00007cd93bdd4c2e  pop r10
00007cd93bdd4c30  pop r9
00007cd93bdd4c32  pop r8
00007cd93bdd4c34  pop rsi
00007cd93bdd4c35  pop rdi
00007cd93bdd4c36  pop rdx
00007cd93bdd4c37  pop rcx
00007cd93bdd4c38  pop rax
00007cd93bdd4c39  add rsp, 0x08
00007cd93bdd4c3d  jmp 0x00007CD93BDD01DD
00007cd93bdd4c42  sub rsp, 0x08
00007cd93bdd4c46  push rax
00007cd93bdd4c47  push rcx
00007cd93bdd4c48  push rdx
00007cd93bdd4c49  push rdi
00007cd93bdd4c4a  push rsi
00007cd93bdd4c4b  push r8
00007cd93bdd4c4d  push r9
00007cd93bdd4c4f  push r10
00007cd93bdd4c51  push r11
00007cd93bdd4c53  sub rsp, 0xF0
00007cd93bdd4c5a  vmovaps [rsp], xmm0
00007cd93bdd4c5f  vmovaps [rsp+0x10], xmm1
00007cd93bdd4c65  vmovaps [rsp+0x20], xmm2
00007cd93bdd4c6b  vmovaps [rsp+0x30], xmm3
00007cd93bdd4c71  vmovaps [rsp+0x40], xmm4
00007cd93bdd4c77  vmovaps [rsp+0x50], xmm5
00007cd93bdd4c7d  vmovaps [rsp+0x60], xmm6
00007cd93bdd4c83  vmovaps [rsp+0x70], xmm7
00007cd93bdd4c89  vmovaps [rsp+0x80], xmm8
00007cd93bdd4c92  vmovaps [rsp+0x90], xmm9
00007cd93bdd4c9b  vmovaps [rsp+0xA0], xmm10
00007cd93bdd4ca4  vmovaps [rsp+0xB0], xmm11
00007cd93bdd4cad  vmovaps [rsp+0xC0], xmm12
00007cd93bdd4cb6  vmovaps [rsp+0xD0], xmm13
00007cd93bdd4cbf  vmovaps [rsp+0xE0], xmm15
00007cd93bdd4cc8  sub rsp, 0x30
00007cd93bdd4ccc  movaps [rsp], xmm14
00007cd93bdd4cd1  movaps [rsp+0x10], xmm4
00007cd93bdd4cd6  movaps [rsp+0x20], xmm1
00007cd93bdd4cdb  lea rdi, [rsp]
00007cd93bdd4cdf  mov esi, 0x00
00007cd93bdd4ce4  mov rax, 0x64A581057530
00007cd93bdd4cee  call rax
00007cd93bdd4cf0  movaps xmm14, [rsp]
00007cd93bdd4cf5  add rsp, 0x30
00007cd93bdd4cf9  vmovaps xmm0, [rsp]
00007cd93bdd4cfe  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4d04  vmovaps xmm2, [rsp+0x20]
00007cd93bdd4d0a  vmovaps xmm3, [rsp+0x30]
00007cd93bdd4d10  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4d16  vmovaps xmm5, [rsp+0x50]
00007cd93bdd4d1c  vmovaps xmm6, [rsp+0x60]
00007cd93bdd4d22  vmovaps xmm7, [rsp+0x70]
00007cd93bdd4d28  vmovaps xmm8, [rsp+0x80]
00007cd93bdd4d31  vmovaps xmm9, [rsp+0x90]
00007cd93bdd4d3a  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd4d43  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd4d4c  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd4d55  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd4d5e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4d67  add rsp, 0xF0
00007cd93bdd4d6e  pop r11
00007cd93bdd4d70  pop r10
00007cd93bdd4d72  pop r9
00007cd93bdd4d74  pop r8
00007cd93bdd4d76  pop rsi
00007cd93bdd4d77  pop rdi
00007cd93bdd4d78  pop rdx
00007cd93bdd4d79  pop rcx
00007cd93bdd4d7a  pop rax
00007cd93bdd4d7b  add rsp, 0x08
00007cd93bdd4d7f  jmp 0x00007CD93BDD0203
00007cd93bdd4d84  sub rsp, 0x08
00007cd93bdd4d88  push rax
00007cd93bdd4d89  push rcx
00007cd93bdd4d8a  push rdx
00007cd93bdd4d8b  push rdi
00007cd93bdd4d8c  push rsi
00007cd93bdd4d8d  push r8
00007cd93bdd4d8f  push r9
00007cd93bdd4d91  push r10
00007cd93bdd4d93  push r11
00007cd93bdd4d95  sub rsp, 0xF0
00007cd93bdd4d9c  vmovaps [rsp], xmm0
00007cd93bdd4da1  vmovaps [rsp+0x10], xmm2
00007cd93bdd4da7  vmovaps [rsp+0x20], xmm3
00007cd93bdd4dad  vmovaps [rsp+0x30], xmm4
00007cd93bdd4db3  vmovaps [rsp+0x40], xmm5
00007cd93bdd4db9  vmovaps [rsp+0x50], xmm6
00007cd93bdd4dbf  vmovaps [rsp+0x60], xmm7
00007cd93bdd4dc5  vmovaps [rsp+0x70], xmm8
00007cd93bdd4dcb  vmovaps [rsp+0x80], xmm9
00007cd93bdd4dd4  vmovaps [rsp+0x90], xmm10
00007cd93bdd4ddd  vmovaps [rsp+0xA0], xmm11
00007cd93bdd4de6  vmovaps [rsp+0xB0], xmm12
00007cd93bdd4def  vmovaps [rsp+0xC0], xmm13
00007cd93bdd4df8  vmovaps [rsp+0xD0], xmm14
00007cd93bdd4e01  vmovaps [rsp+0xE0], xmm15
00007cd93bdd4e0a  sub rsp, 0x30
00007cd93bdd4e0e  movaps [rsp], xmm1
00007cd93bdd4e12  movaps [rsp+0x10], xmm12
00007cd93bdd4e18  movaps [rsp+0x20], xmm11
00007cd93bdd4e1e  lea rdi, [rsp]
00007cd93bdd4e22  mov esi, 0x00
00007cd93bdd4e27  mov rax, 0x64A581057530
00007cd93bdd4e31  call rax
00007cd93bdd4e33  movaps xmm1, [rsp]
00007cd93bdd4e37  add rsp, 0x30
00007cd93bdd4e3b  vmovaps xmm0, [rsp]
00007cd93bdd4e40  vmovaps xmm2, [rsp+0x10]
00007cd93bdd4e46  vmovaps xmm3, [rsp+0x20]
00007cd93bdd4e4c  vmovaps xmm4, [rsp+0x30]
00007cd93bdd4e52  vmovaps xmm5, [rsp+0x40]
00007cd93bdd4e58  vmovaps xmm6, [rsp+0x50]
00007cd93bdd4e5e  vmovaps xmm7, [rsp+0x60]
00007cd93bdd4e64  vmovaps xmm8, [rsp+0x70]
00007cd93bdd4e6a  vmovaps xmm9, [rsp+0x80]
00007cd93bdd4e73  vmovaps xmm10, [rsp+0x90]
00007cd93bdd4e7c  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd4e85  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd4e8e  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd4e97  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd4ea0  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4ea9  add rsp, 0xF0
00007cd93bdd4eb0  pop r11
00007cd93bdd4eb2  pop r10
00007cd93bdd4eb4  pop r9
00007cd93bdd4eb6  pop r8
00007cd93bdd4eb8  pop rsi
00007cd93bdd4eb9  pop rdi
00007cd93bdd4eba  pop rdx
00007cd93bdd4ebb  pop rcx
00007cd93bdd4ebc  pop rax
00007cd93bdd4ebd  add rsp, 0x08
00007cd93bdd4ec1  jmp 0x00007CD93BDD0224
00007cd93bdd4ec6  call 0x00007CD93BCE20A0
00007cd93bdd4ecb  jmp 0x00007CD93BDD0232
00007cd93bdd4ed0  call 0x00007CD93BC09D70
00007cd93bdd4ed5  jmp 0x00007CD93BDD023C
00007cd93bdd4eda  sub rsp, 0x08
00007cd93bdd4ede  push rax
00007cd93bdd4edf  push rcx
00007cd93bdd4ee0  push rdx
00007cd93bdd4ee1  push rdi
00007cd93bdd4ee2  push rsi
00007cd93bdd4ee3  push r8
00007cd93bdd4ee5  push r9
00007cd93bdd4ee7  push r10
00007cd93bdd4ee9  push r11
00007cd93bdd4eeb  sub rsp, 0xF0
00007cd93bdd4ef2  vmovaps [rsp], xmm0
00007cd93bdd4ef7  vmovaps [rsp+0x10], xmm1
00007cd93bdd4efd  vmovaps [rsp+0x20], xmm2
00007cd93bdd4f03  vmovaps [rsp+0x30], xmm3
00007cd93bdd4f09  vmovaps [rsp+0x40], xmm4
00007cd93bdd4f0f  vmovaps [rsp+0x50], xmm5
00007cd93bdd4f15  vmovaps [rsp+0x60], xmm6
00007cd93bdd4f1b  vmovaps [rsp+0x70], xmm8
00007cd93bdd4f21  vmovaps [rsp+0x80], xmm9
00007cd93bdd4f2a  vmovaps [rsp+0x90], xmm10
00007cd93bdd4f33  vmovaps [rsp+0xA0], xmm11
00007cd93bdd4f3c  vmovaps [rsp+0xB0], xmm12
00007cd93bdd4f45  vmovaps [rsp+0xC0], xmm13
00007cd93bdd4f4e  vmovaps [rsp+0xD0], xmm14
00007cd93bdd4f57  vmovaps [rsp+0xE0], xmm15
00007cd93bdd4f60  sub rsp, 0x30
00007cd93bdd4f64  movaps [rsp], xmm7
00007cd93bdd4f68  movaps [rsp+0x10], xmm15
00007cd93bdd4f6e  movaps [rsp+0x20], xmm10
00007cd93bdd4f74  lea rdi, [rsp]
00007cd93bdd4f78  mov esi, 0x00
00007cd93bdd4f7d  mov rax, 0x64A581057530
00007cd93bdd4f87  call rax
00007cd93bdd4f89  movaps xmm7, [rsp]
00007cd93bdd4f8d  add rsp, 0x30
00007cd93bdd4f91  vmovaps xmm0, [rsp]
00007cd93bdd4f96  vmovaps xmm1, [rsp+0x10]
00007cd93bdd4f9c  vmovaps xmm2, [rsp+0x20]
00007cd93bdd4fa2  vmovaps xmm3, [rsp+0x30]
00007cd93bdd4fa8  vmovaps xmm4, [rsp+0x40]
00007cd93bdd4fae  vmovaps xmm5, [rsp+0x50]
00007cd93bdd4fb4  vmovaps xmm6, [rsp+0x60]
00007cd93bdd4fba  vmovaps xmm8, [rsp+0x70]
00007cd93bdd4fc0  vmovaps xmm9, [rsp+0x80]
00007cd93bdd4fc9  vmovaps xmm10, [rsp+0x90]
00007cd93bdd4fd2  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd4fdb  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd4fe4  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd4fed  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd4ff6  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd4fff  add rsp, 0xF0
00007cd93bdd5006  pop r11
00007cd93bdd5008  pop r10
00007cd93bdd500a  pop r9
00007cd93bdd500c  pop r8
00007cd93bdd500e  pop rsi
00007cd93bdd500f  pop rdi
00007cd93bdd5010  pop rdx
00007cd93bdd5011  pop rcx
00007cd93bdd5012  pop rax
00007cd93bdd5013  add rsp, 0x08
00007cd93bdd5017  jmp 0x00007CD93BDD025D
00007cd93bdd501c  sub rsp, 0x08
00007cd93bdd5020  push rax
00007cd93bdd5021  push rcx
00007cd93bdd5022  push rdx
00007cd93bdd5023  push rdi
00007cd93bdd5024  push rsi
00007cd93bdd5025  push r8
00007cd93bdd5027  push r9
00007cd93bdd5029  push r10
00007cd93bdd502b  push r11
00007cd93bdd502d  sub rsp, 0xF0
00007cd93bdd5034  vmovaps [rsp], xmm0
00007cd93bdd5039  vmovaps [rsp+0x10], xmm1
00007cd93bdd503f  vmovaps [rsp+0x20], xmm2
00007cd93bdd5045  vmovaps [rsp+0x30], xmm3
00007cd93bdd504b  vmovaps [rsp+0x40], xmm4
00007cd93bdd5051  vmovaps [rsp+0x50], xmm5
00007cd93bdd5057  vmovaps [rsp+0x60], xmm6
00007cd93bdd505d  vmovaps [rsp+0x70], xmm7
00007cd93bdd5063  vmovaps [rsp+0x80], xmm8
00007cd93bdd506c  vmovaps [rsp+0x90], xmm9
00007cd93bdd5075  vmovaps [rsp+0xA0], xmm11
00007cd93bdd507e  vmovaps [rsp+0xB0], xmm12
00007cd93bdd5087  vmovaps [rsp+0xC0], xmm13
00007cd93bdd5090  vmovaps [rsp+0xD0], xmm14
00007cd93bdd5099  vmovaps [rsp+0xE0], xmm15
00007cd93bdd50a2  sub rsp, 0x30
00007cd93bdd50a6  movaps [rsp], xmm10
00007cd93bdd50ab  movaps [rsp+0x10], xmm11
00007cd93bdd50b1  movaps [rsp+0x20], xmm15
00007cd93bdd50b7  lea rdi, [rsp]
00007cd93bdd50bb  mov esi, 0x00
00007cd93bdd50c0  mov rax, 0x64A581057530
00007cd93bdd50ca  call rax
00007cd93bdd50cc  movaps xmm10, [rsp]
00007cd93bdd50d1  add rsp, 0x30
00007cd93bdd50d5  vmovaps xmm0, [rsp]
00007cd93bdd50da  vmovaps xmm1, [rsp+0x10]
00007cd93bdd50e0  vmovaps xmm2, [rsp+0x20]
00007cd93bdd50e6  vmovaps xmm3, [rsp+0x30]
00007cd93bdd50ec  vmovaps xmm4, [rsp+0x40]
00007cd93bdd50f2  vmovaps xmm5, [rsp+0x50]
00007cd93bdd50f8  vmovaps xmm6, [rsp+0x60]
00007cd93bdd50fe  vmovaps xmm7, [rsp+0x70]
00007cd93bdd5104  vmovaps xmm8, [rsp+0x80]
00007cd93bdd510d  vmovaps xmm9, [rsp+0x90]
00007cd93bdd5116  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd511f  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd5128  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd5131  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd513a  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd5143  add rsp, 0xF0
00007cd93bdd514a  pop r11
00007cd93bdd514c  pop r10
00007cd93bdd514e  pop r9
00007cd93bdd5150  pop r8
00007cd93bdd5152  pop rsi
00007cd93bdd5153  pop rdi
00007cd93bdd5154  pop rdx
00007cd93bdd5155  pop rcx
00007cd93bdd5156  pop rax
00007cd93bdd5157  add rsp, 0x08
00007cd93bdd515b  jmp 0x00007CD93BDD028B
00007cd93bdd5160  sub rsp, 0x08
00007cd93bdd5164  push rax
00007cd93bdd5165  push rcx
00007cd93bdd5166  push rdx
00007cd93bdd5167  push rdi
00007cd93bdd5168  push rsi
00007cd93bdd5169  push r8
00007cd93bdd516b  push r9
00007cd93bdd516d  push r10
00007cd93bdd516f  push r11
00007cd93bdd5171  sub rsp, 0xF0
00007cd93bdd5178  vmovaps [rsp], xmm0
00007cd93bdd517d  vmovaps [rsp+0x10], xmm1
00007cd93bdd5183  vmovaps [rsp+0x20], xmm2
00007cd93bdd5189  vmovaps [rsp+0x30], xmm3
00007cd93bdd518f  vmovaps [rsp+0x40], xmm4
00007cd93bdd5195  vmovaps [rsp+0x50], xmm5
00007cd93bdd519b  vmovaps [rsp+0x60], xmm6
00007cd93bdd51a1  vmovaps [rsp+0x70], xmm7
00007cd93bdd51a7  vmovaps [rsp+0x80], xmm8
00007cd93bdd51b0  vmovaps [rsp+0x90], xmm9
00007cd93bdd51b9  vmovaps [rsp+0xA0], xmm10
00007cd93bdd51c2  vmovaps [rsp+0xB0], xmm12
00007cd93bdd51cb  vmovaps [rsp+0xC0], xmm13
00007cd93bdd51d4  vmovaps [rsp+0xD0], xmm14
00007cd93bdd51dd  vmovaps [rsp+0xE0], xmm15
00007cd93bdd51e6  sub rsp, 0x30
00007cd93bdd51ea  movaps [rsp], xmm11
00007cd93bdd51ef  movaps [rsp+0x10], xmm12
00007cd93bdd51f5  movaps [rsp+0x20], xmm15
00007cd93bdd51fb  lea rdi, [rsp]
00007cd93bdd51ff  mov esi, 0x00
00007cd93bdd5204  mov rax, 0x64A581057530
00007cd93bdd520e  call rax
00007cd93bdd5210  movaps xmm11, [rsp]
00007cd93bdd5215  add rsp, 0x30
00007cd93bdd5219  vmovaps xmm0, [rsp]
00007cd93bdd521e  vmovaps xmm1, [rsp+0x10]
00007cd93bdd5224  vmovaps xmm2, [rsp+0x20]
00007cd93bdd522a  vmovaps xmm3, [rsp+0x30]
00007cd93bdd5230  vmovaps xmm4, [rsp+0x40]
00007cd93bdd5236  vmovaps xmm5, [rsp+0x50]
00007cd93bdd523c  vmovaps xmm6, [rsp+0x60]
00007cd93bdd5242  vmovaps xmm7, [rsp+0x70]
00007cd93bdd5248  vmovaps xmm8, [rsp+0x80]
00007cd93bdd5251  vmovaps xmm9, [rsp+0x90]
00007cd93bdd525a  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd5263  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd526c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd5275  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd527e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd5287  add rsp, 0xF0
00007cd93bdd528e  pop r11
00007cd93bdd5290  pop r10
00007cd93bdd5292  pop r9
00007cd93bdd5294  pop r8
00007cd93bdd5296  pop rsi
00007cd93bdd5297  pop rdi
00007cd93bdd5298  pop rdx
00007cd93bdd5299  pop rcx
00007cd93bdd529a  pop rax
00007cd93bdd529b  add rsp, 0x08
00007cd93bdd529f  jmp 0x00007CD93BDD02B9
00007cd93bdd52a4  sub rsp, 0x08
00007cd93bdd52a8  push rax
00007cd93bdd52a9  push rcx
00007cd93bdd52aa  push rdx
00007cd93bdd52ab  push rdi
00007cd93bdd52ac  push rsi
00007cd93bdd52ad  push r8
00007cd93bdd52af  push r9
00007cd93bdd52b1  push r10
00007cd93bdd52b3  push r11
00007cd93bdd52b5  sub rsp, 0xF0
00007cd93bdd52bc  vmovaps [rsp], xmm0
00007cd93bdd52c1  vmovaps [rsp+0x10], xmm1
00007cd93bdd52c7  vmovaps [rsp+0x20], xmm2
00007cd93bdd52cd  vmovaps [rsp+0x30], xmm3
00007cd93bdd52d3  vmovaps [rsp+0x40], xmm4
00007cd93bdd52d9  vmovaps [rsp+0x50], xmm5
00007cd93bdd52df  vmovaps [rsp+0x60], xmm6
00007cd93bdd52e5  vmovaps [rsp+0x70], xmm7
00007cd93bdd52eb  vmovaps [rsp+0x80], xmm8
00007cd93bdd52f4  vmovaps [rsp+0x90], xmm9
00007cd93bdd52fd  vmovaps [rsp+0xA0], xmm10
00007cd93bdd5306  vmovaps [rsp+0xB0], xmm11
00007cd93bdd530f  vmovaps [rsp+0xC0], xmm12
00007cd93bdd5318  vmovaps [rsp+0xD0], xmm13
00007cd93bdd5321  vmovaps [rsp+0xE0], xmm14
00007cd93bdd532a  sub rsp, 0x30
00007cd93bdd532e  movaps [rsp], xmm15
00007cd93bdd5333  movaps [rsp+0x10], xmm13
00007cd93bdd5339  movaps [rsp+0x20], xmm9
00007cd93bdd533f  lea rdi, [rsp]
00007cd93bdd5343  mov esi, 0x00
00007cd93bdd5348  mov rax, 0x64A581057530
00007cd93bdd5352  call rax
00007cd93bdd5354  movaps xmm15, [rsp]
00007cd93bdd5359  add rsp, 0x30
00007cd93bdd535d  vmovaps xmm0, [rsp]
00007cd93bdd5362  vmovaps xmm1, [rsp+0x10]
00007cd93bdd5368  vmovaps xmm2, [rsp+0x20]
00007cd93bdd536e  vmovaps xmm3, [rsp+0x30]
00007cd93bdd5374  vmovaps xmm4, [rsp+0x40]
00007cd93bdd537a  vmovaps xmm5, [rsp+0x50]
00007cd93bdd5380  vmovaps xmm6, [rsp+0x60]
00007cd93bdd5386  vmovaps xmm7, [rsp+0x70]
00007cd93bdd538c  vmovaps xmm8, [rsp+0x80]
00007cd93bdd5395  vmovaps xmm9, [rsp+0x90]
00007cd93bdd539e  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd53a7  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd53b0  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd53b9  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd53c2  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd53cb  add rsp, 0xF0
00007cd93bdd53d2  pop r11
00007cd93bdd53d4  pop r10
00007cd93bdd53d6  pop r9
00007cd93bdd53d8  pop r8
00007cd93bdd53da  pop rsi
00007cd93bdd53db  pop rdi
00007cd93bdd53dc  pop rdx
00007cd93bdd53dd  pop rcx
00007cd93bdd53de  pop rax
00007cd93bdd53df  add rsp, 0x08
00007cd93bdd53e3  jmp 0x00007CD93BDD02D4
00007cd93bdd53e8  sub rsp, 0x08
00007cd93bdd53ec  push rax
00007cd93bdd53ed  push rcx
00007cd93bdd53ee  push rdx
00007cd93bdd53ef  push rdi
00007cd93bdd53f0  push rsi
00007cd93bdd53f1  push r8
00007cd93bdd53f3  push r9
00007cd93bdd53f5  push r10
00007cd93bdd53f7  push r11
00007cd93bdd53f9  sub rsp, 0xF0
00007cd93bdd5400  vmovaps [rsp], xmm0
00007cd93bdd5405  vmovaps [rsp+0x10], xmm1
00007cd93bdd540b  vmovaps [rsp+0x20], xmm2
00007cd93bdd5411  vmovaps [rsp+0x30], xmm3
00007cd93bdd5417  vmovaps [rsp+0x40], xmm4
00007cd93bdd541d  vmovaps [rsp+0x50], xmm5
00007cd93bdd5423  vmovaps [rsp+0x60], xmm6
00007cd93bdd5429  vmovaps [rsp+0x70], xmm7
00007cd93bdd542f  vmovaps [rsp+0x80], xmm8
00007cd93bdd5438  vmovaps [rsp+0x90], xmm9
00007cd93bdd5441  vmovaps [rsp+0xA0], xmm10
00007cd93bdd544a  vmovaps [rsp+0xB0], xmm11
00007cd93bdd5453  vmovaps [rsp+0xC0], xmm12
00007cd93bdd545c  vmovaps [rsp+0xD0], xmm14
00007cd93bdd5465  vmovaps [rsp+0xE0], xmm15
00007cd93bdd546e  sub rsp, 0x30
00007cd93bdd5472  movaps [rsp], xmm13
00007cd93bdd5477  movaps [rsp+0x10], xmm8
00007cd93bdd547d  movaps [rsp+0x20], xmm14
00007cd93bdd5483  lea rdi, [rsp]
00007cd93bdd5487  mov esi, 0x00
00007cd93bdd548c  mov rax, 0x64A581057530
00007cd93bdd5496  call rax
00007cd93bdd5498  movaps xmm13, [rsp]
00007cd93bdd549d  add rsp, 0x30
00007cd93bdd54a1  vmovaps xmm0, [rsp]
00007cd93bdd54a6  vmovaps xmm1, [rsp+0x10]
00007cd93bdd54ac  vmovaps xmm2, [rsp+0x20]
00007cd93bdd54b2  vmovaps xmm3, [rsp+0x30]
00007cd93bdd54b8  vmovaps xmm4, [rsp+0x40]
00007cd93bdd54be  vmovaps xmm5, [rsp+0x50]
00007cd93bdd54c4  vmovaps xmm6, [rsp+0x60]
00007cd93bdd54ca  vmovaps xmm7, [rsp+0x70]
00007cd93bdd54d0  vmovaps xmm8, [rsp+0x80]
00007cd93bdd54d9  vmovaps xmm9, [rsp+0x90]
00007cd93bdd54e2  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd54eb  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd54f4  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd54fd  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd5506  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd550f  add rsp, 0xF0
00007cd93bdd5516  pop r11
00007cd93bdd5518  pop r10
00007cd93bdd551a  pop r9
00007cd93bdd551c  pop r8
00007cd93bdd551e  pop rsi
00007cd93bdd551f  pop rdi
00007cd93bdd5520  pop rdx
00007cd93bdd5521  pop rcx
00007cd93bdd5522  pop rax
00007cd93bdd5523  add rsp, 0x08
00007cd93bdd5527  jmp 0x00007CD93BDD02F7
00007cd93bdd552c  sub rsp, 0x08
00007cd93bdd5530  push rax
00007cd93bdd5531  push rcx
00007cd93bdd5532  push rdx
00007cd93bdd5533  push rdi
00007cd93bdd5534  push rsi
00007cd93bdd5535  push r8
00007cd93bdd5537  push r9
00007cd93bdd5539  push r10
00007cd93bdd553b  push r11
00007cd93bdd553d  sub rsp, 0xF0
00007cd93bdd5544  vmovaps [rsp], xmm0
00007cd93bdd5549  vmovaps [rsp+0x10], xmm1
00007cd93bdd554f  vmovaps [rsp+0x20], xmm2
00007cd93bdd5555  vmovaps [rsp+0x30], xmm3
00007cd93bdd555b  vmovaps [rsp+0x40], xmm4
00007cd93bdd5561  vmovaps [rsp+0x50], xmm5
00007cd93bdd5567  vmovaps [rsp+0x60], xmm6
00007cd93bdd556d  vmovaps [rsp+0x70], xmm7
00007cd93bdd5573  vmovaps [rsp+0x80], xmm8
00007cd93bdd557c  vmovaps [rsp+0x90], xmm9
00007cd93bdd5585  vmovaps [rsp+0xA0], xmm10
00007cd93bdd558e  vmovaps [rsp+0xB0], xmm11
00007cd93bdd5597  vmovaps [rsp+0xC0], xmm12
00007cd93bdd55a0  vmovaps [rsp+0xD0], xmm13
00007cd93bdd55a9  vmovaps [rsp+0xE0], xmm15
00007cd93bdd55b2  sub rsp, 0x30
00007cd93bdd55b6  movaps [rsp], xmm14
00007cd93bdd55bb  movaps [rsp+0x10], xmm1
00007cd93bdd55c0  movaps [rsp+0x20], xmm10
00007cd93bdd55c6  lea rdi, [rsp]
00007cd93bdd55ca  mov esi, 0x00
00007cd93bdd55cf  mov rax, 0x64A581057530
00007cd93bdd55d9  call rax
00007cd93bdd55db  movaps xmm14, [rsp]
00007cd93bdd55e0  add rsp, 0x30
00007cd93bdd55e4  vmovaps xmm0, [rsp]
00007cd93bdd55e9  vmovaps xmm1, [rsp+0x10]
00007cd93bdd55ef  vmovaps xmm2, [rsp+0x20]
00007cd93bdd55f5  vmovaps xmm3, [rsp+0x30]
00007cd93bdd55fb  vmovaps xmm4, [rsp+0x40]
00007cd93bdd5601  vmovaps xmm5, [rsp+0x50]
00007cd93bdd5607  vmovaps xmm6, [rsp+0x60]
00007cd93bdd560d  vmovaps xmm7, [rsp+0x70]
00007cd93bdd5613  vmovaps xmm8, [rsp+0x80]
00007cd93bdd561c  vmovaps xmm9, [rsp+0x90]
00007cd93bdd5625  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd562e  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd5637  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd5640  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd5649  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd5652  add rsp, 0xF0
00007cd93bdd5659  pop r11
00007cd93bdd565b  pop r10
00007cd93bdd565d  pop r9
00007cd93bdd565f  pop r8
00007cd93bdd5661  pop rsi
00007cd93bdd5662  pop rdi
00007cd93bdd5663  pop rdx
00007cd93bdd5664  pop rcx
00007cd93bdd5665  pop rax
00007cd93bdd5666  add rsp, 0x08
00007cd93bdd566a  jmp 0x00007CD93BDD031A
00007cd93bdd566f  sub rsp, 0x08
00007cd93bdd5673  push rax
00007cd93bdd5674  push rcx
00007cd93bdd5675  push rdx
00007cd93bdd5676  push rdi
00007cd93bdd5677  push rsi
00007cd93bdd5678  push r8
00007cd93bdd567a  push r9
00007cd93bdd567c  push r10
00007cd93bdd567e  push r11
00007cd93bdd5680  sub rsp, 0xF0
00007cd93bdd5687  vmovaps [rsp], xmm0
00007cd93bdd568c  vmovaps [rsp+0x10], xmm2
00007cd93bdd5692  vmovaps [rsp+0x20], xmm3
00007cd93bdd5698  vmovaps [rsp+0x30], xmm4
00007cd93bdd569e  vmovaps [rsp+0x40], xmm5
00007cd93bdd56a4  vmovaps [rsp+0x50], xmm6
00007cd93bdd56aa  vmovaps [rsp+0x60], xmm7
00007cd93bdd56b0  vmovaps [rsp+0x70], xmm8
00007cd93bdd56b6  vmovaps [rsp+0x80], xmm9
00007cd93bdd56bf  vmovaps [rsp+0x90], xmm10
00007cd93bdd56c8  vmovaps [rsp+0xA0], xmm11
00007cd93bdd56d1  vmovaps [rsp+0xB0], xmm12
00007cd93bdd56da  vmovaps [rsp+0xC0], xmm13
00007cd93bdd56e3  vmovaps [rsp+0xD0], xmm14
00007cd93bdd56ec  vmovaps [rsp+0xE0], xmm15
00007cd93bdd56f5  sub rsp, 0x30
00007cd93bdd56f9  movaps [rsp], xmm1
00007cd93bdd56fd  movaps [rsp+0x10], xmm7
00007cd93bdd5702  movaps [rsp+0x20], xmm11
00007cd93bdd5708  lea rdi, [rsp]
00007cd93bdd570c  mov esi, 0x00
00007cd93bdd5711  mov rax, 0x64A581057530
00007cd93bdd571b  call rax
00007cd93bdd571d  movaps xmm1, [rsp]
00007cd93bdd5721  add rsp, 0x30
00007cd93bdd5725  vmovaps xmm0, [rsp]
00007cd93bdd572a  vmovaps xmm2, [rsp+0x10]
00007cd93bdd5730  vmovaps xmm3, [rsp+0x20]
00007cd93bdd5736  vmovaps xmm4, [rsp+0x30]
00007cd93bdd573c  vmovaps xmm5, [rsp+0x40]
00007cd93bdd5742  vmovaps xmm6, [rsp+0x50]
00007cd93bdd5748  vmovaps xmm7, [rsp+0x60]
00007cd93bdd574e  vmovaps xmm8, [rsp+0x70]
00007cd93bdd5754  vmovaps xmm9, [rsp+0x80]
00007cd93bdd575d  vmovaps xmm10, [rsp+0x90]
00007cd93bdd5766  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd576f  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd5778  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd5781  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd578a  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd5793  add rsp, 0xF0
00007cd93bdd579a  pop r11
00007cd93bdd579c  pop r10
00007cd93bdd579e  pop r9
00007cd93bdd57a0  pop r8
00007cd93bdd57a2  pop rsi
00007cd93bdd57a3  pop rdi
00007cd93bdd57a4  pop rdx
00007cd93bdd57a5  pop rcx
00007cd93bdd57a6  pop rax
00007cd93bdd57a7  add rsp, 0x08
00007cd93bdd57ab  jmp 0x00007CD93BDD033B
00007cd93bdd57b0  call 0x00007CD93BC0E880
00007cd93bdd57b5  jmp 0x00007CD93BDD034E
00007cd93bdd57ba  call 0x00007CD93BC0C380
00007cd93bdd57bf  jmp 0x00007CD93BDD0359
00007cd93bdd57c4  call 0x00007CD93BC0D600
00007cd93bdd57c9  jmp 0x00007CD93BDD0364
00007cd93bdd57ce  call 0x00007CD93BBFF540
00007cd93bdd57d3  jmp 0x00007CD93BDD036F
00007cd93bdd57d8  int3
00007cd93bdd57d9  nop [rax], eax
00007cd93bdd57e0  mov rax, [r15+0x40]
00007cd93bdd57e4  mov r14, [r15+0x58]
00007cd93bdd57e8  lea r12, [rax+r14*1]
00007cd93bdd57ec  movaps xmm1, [r15+0x1D0]
00007cd93bdd57f4  vmovaps [rsp+0x10], xmm1
00007cd93bdd57fa  vmovaps xmm15, [rsp+0x10]
00007cd93bdd5800  por xmm1, xmm15
00007cd93bdd5805  movaps xmm14, [r15+0x1A0]
00007cd93bdd580d  vmovaps [rsp+0x10], xmm14
00007cd93bdd5813  vmovaps xmm13, [rsp+0x10]
00007cd93bdd5819  por xmm14, xmm13
00007cd93bdd581e  lea rax, [r12+0x30]
00007cd93bdd5823  mov r11, [r13+rax*1]
00007cd93bdd5828  lea rax, [r12+0x38]
00007cd93bdd582d  mov r10, [r13+rax*1]
00007cd93bdd5832  movq xmm13, r11
00007cd93bdd5837  movq xmm12, r10
00007cd93bdd583c  movq xmm13, xmm13
00007cd93bdd5841  vmovaps [rsp+0x10], xmm13
00007cd93bdd5847  movq xmm13, xmm13
00007cd93bdd584c  movaps [r15+0x130], xmm13
00007cd93bdd5854  movq xmm12, xmm12
00007cd93bdd5859  vmovaps [rsp+0x20], xmm12
00007cd93bdd585f  movq xmm12, xmm12
00007cd93bdd5864  movaps [r15+0x280], xmm12
00007cd93bdd586c  movaps xmm13, [r15+0x270]
00007cd93bdd5874  vmovaps [rsp+0x30], xmm13
00007cd93bdd587a  vmovaps xmm12, [rsp+0x30]
00007cd93bdd5880  por xmm13, xmm12
00007cd93bdd5885  lea rax, [r12+0x20]
00007cd93bdd588a  mov r11, [r13+rax*1]
00007cd93bdd588f  lea rax, [r12+0x28]
00007cd93bdd5894  mov r10, [r13+rax*1]
00007cd93bdd5899  movq xmm12, r11
00007cd93bdd589e  movq xmm11, r10
00007cd93bdd58a3  movq xmm12, xmm12
00007cd93bdd58a8  vmovaps [rsp+0x30], xmm12
00007cd93bdd58ae  movq xmm12, xmm12
00007cd93bdd58b3  movaps [r15+0x150], xmm12
00007cd93bdd58bb  movq xmm11, xmm11
00007cd93bdd58c0  vmovaps [rsp+0x40], xmm11
00007cd93bdd58c6  movq xmm11, xmm11
00007cd93bdd58cb  movaps [r15+0x140], xmm11
00007cd93bdd58d3  lea rax, [r12+0x10]
00007cd93bdd58d8  mov r11, [r13+rax*1]
00007cd93bdd58dd  lea rax, [r12+0x18]
00007cd93bdd58e2  mov r10, [r13+rax*1]
00007cd93bdd58e7  movq xmm12, r11
00007cd93bdd58ec  movq xmm11, r10
00007cd93bdd58f1  movq xmm12, xmm12
00007cd93bdd58f6  vmovaps [rsp+0x50], xmm12
00007cd93bdd58fc  movq xmm12, xmm12
00007cd93bdd5901  movaps [r15+0x170], xmm12
00007cd93bdd5909  movq xmm11, xmm11
00007cd93bdd590e  vmovaps [rsp+0x60], xmm11
00007cd93bdd5914  movq xmm11, xmm11
00007cd93bdd5919  movaps [r15+0x160], xmm11
00007cd93bdd5921  mov rax, [r13+r12*1]
00007cd93bdd5926  vmovq xmm12, rax
00007cd93bdd592b  vpbroadcastq xmm12, xmm12
00007cd93bdd5930  lea rax, [r12+0x08]
00007cd93bdd5935  mov r12, [r13+rax*1]
00007cd93bdd593a  movq xmm11, r12
00007cd93bdd593f  movaps [r15+0x230], xmm11
00007cd93bdd5947  mov rax, [r15+0xF8]
00007cd93bdd594e  lea r12, [rax+0x50]
00007cd93bdd5952  movups xmm11, [r13+r12*1]
00007cd93bdd5958  lea r12, [rax+0x60]
00007cd93bdd595c  movups xmm10, [r13+r12*1]
00007cd93bdd5962  lea r12, [rax+0x30]
00007cd93bdd5966  movups xmm9, [r13+r12*1]
00007cd93bdd596c  mov r12, [r15+0x50]
00007cd93bdd5970  lea r11, [r12+r14*1]
00007cd93bdd5974  mov [r15+0x60], r11
00007cd93bdd5978  lea r12, [r14+0x40]
00007cd93bdd597c  mov [r15+0x58], r12
00007cd93bdd5980  movaps xmm8, xmm12
00007cd93bdd5984  mulpd xmm8, xmm15
00007cd93bdd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007cd93bdd598f  ptest xmm7, xmm7
00007cd93bdd5994  jnz 0x00007CD93BDD67B7
00007cd93bdd599a  movq xmm15, qword ptr [r15+0x230]
00007cd93bdd59a3  vmovaps [rsp+0x70], xmm15
00007cd93bdd59a9  vpermilpd xmm15, xmm15, 0x00
00007cd93bdd59af  movaps xmm7, xmm9
00007cd93bdd59b3  mulpd xmm7, xmm15
00007cd93bdd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007cd93bdd59bd  ptest xmm6, xmm6
00007cd93bdd59c2  jnz 0x00007CD93BDD68FB
00007cd93bdd59c8  vxorps xmm15, xmm15, xmm15
00007cd93bdd59cd  vpbroadcastq xmm15, xmm15
00007cd93bdd59d2  movaps xmm9, xmm12
00007cd93bdd59d6  mulpd xmm9, xmm10
00007cd93bdd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007cd93bdd59e1  ptest xmm6, xmm6
00007cd93bdd59e6  jnz 0x00007CD93BDD6A3D
00007cd93bdd59ec  movaps xmm10, xmm12
00007cd93bdd59f0  mulpd xmm10, xmm11
00007cd93bdd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007cd93bdd59fb  ptest xmm6, xmm6
00007cd93bdd5a00  jnz 0x00007CD93BDD6B81
00007cd93bdd5a06  movaps xmm11, [r15+0x1F0]
00007cd93bdd5a0e  movaps xmm6, xmm12
00007cd93bdd5a12  mulpd xmm6, xmm11
00007cd93bdd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007cd93bdd5a1c  ptest xmm5, xmm5
00007cd93bdd5a21  jnz 0x00007CD93BDD6CC5
00007cd93bdd5a27  movaps xmm12, [r15+0x2A0]
00007cd93bdd5a2f  vmovaps [rsp+0x80], xmm12
00007cd93bdd5a38  vmovaps xmm11, [rsp+0x80]
00007cd93bdd5a41  por xmm12, xmm11
00007cd93bdd5a46  movaps xmm11, [r15+0x250]
00007cd93bdd5a4e  vmovaps [rsp+0x80], xmm11
00007cd93bdd5a57  vmovaps xmm5, [rsp+0x80]
00007cd93bdd5a60  por xmm11, xmm5
00007cd93bdd5a65  vmovaps xmm4, [rsp+0x70]
00007cd93bdd5a6b  vpermilpd xmm4, xmm4, 0x00
00007cd93bdd5a71  movaps xmm3, xmm5
00007cd93bdd5a74  mulpd xmm3, xmm4
00007cd93bdd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007cd93bdd5a7d  ptest xmm2, xmm2
00007cd93bdd5a82  jnz 0x00007CD93BDD6E07
00007cd93bdd5a88  mov [rsp+0x80], rax
00007cd93bdd5a90  xor eax, eax
00007cd93bdd5a92  mov r14d, 0x200
00007cd93bdd5a98  cmp r12, r14
00007cd93bdd5a9b  cmc
00007cd93bdd5a9c  lahf
00007cd93bdd5a9d  seto al
00007cd93bdd5aa0  mov [r15+0x108], eax
00007cd93bdd5aa7  movaps xmm5, xmm8
00007cd93bdd5aab  addpd xmm5, xmm15
00007cd93bdd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007cd93bdd5ab5  ptest xmm4, xmm4
00007cd93bdd5aba  jnz 0x00007CD93BDD6F47
00007cd93bdd5ac0  movaps xmm8, [r15+0x1B0]
00007cd93bdd5ac8  movaps xmm4, xmm9
00007cd93bdd5acc  addpd xmm4, xmm8
00007cd93bdd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007cd93bdd5ad6  ptest xmm2, xmm2
00007cd93bdd5adb  jnz 0x00007CD93BDD7089
00007cd93bdd5ae1  movaps xmm9, xmm10
00007cd93bdd5ae5  addpd xmm9, xmm8
00007cd93bdd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007cd93bdd5af0  ptest xmm2, xmm2
00007cd93bdd5af5  jnz 0x00007CD93BDD71CB
00007cd93bdd5afb  movaps xmm10, [r15+0x2F0]
00007cd93bdd5b03  vmovaps [rsp+0x90], xmm10
00007cd93bdd5b0c  vmovaps xmm8, [rsp+0x90]
00007cd93bdd5b15  por xmm10, xmm8
00007cd93bdd5b1a  movaps xmm8, [r15+0x2E0]
00007cd93bdd5b22  vmovaps [rsp+0x90], xmm8
00007cd93bdd5b2b  vmovaps xmm2, [rsp+0x90]
00007cd93bdd5b34  por xmm8, xmm2
00007cd93bdd5b39  movaps xmm2, [r15+0x2D0]
00007cd93bdd5b41  vmovaps [rsp+0x90], xmm2
00007cd93bdd5b4a  vmovaps [rsp+0xA0], xmm1
00007cd93bdd5b53  vmovaps xmm1, [rsp+0x90]
00007cd93bdd5b5c  por xmm2, xmm1
00007cd93bdd5b60  movaps xmm1, [r15+0x200]
00007cd93bdd5b68  vmovaps [rsp+0x90], xmm1
00007cd93bdd5b71  vmovaps [rsp+0xB0], xmm15
00007cd93bdd5b7a  vmovaps xmm15, [rsp+0x90]
00007cd93bdd5b83  por xmm1, xmm15
00007cd93bdd5b88  movaps xmm15, [r15+0x1C0]
00007cd93bdd5b90  vmovaps [rsp+0x90], xmm15
00007cd93bdd5b99  vmovaps [rsp+0xC0], xmm1
00007cd93bdd5ba2  vmovaps xmm1, [rsp+0x90]
00007cd93bdd5bab  por xmm15, xmm1
00007cd93bdd5bb0  movaps xmm1, [r15+0x190]
00007cd93bdd5bb8  vmovaps [rsp+0x90], xmm1
00007cd93bdd5bc1  vmovaps [rsp+0xD0], xmm15
00007cd93bdd5bca  vmovaps xmm15, [rsp+0x90]
00007cd93bdd5bd3  por xmm1, xmm15
00007cd93bdd5bd8  movaps xmm15, [r15+0x300]
00007cd93bdd5be0  vmovaps [rsp+0x90], xmm15
00007cd93bdd5be9  vmovaps [rsp+0xE0], xmm1
00007cd93bdd5bf2  vmovaps xmm1, [rsp+0x90]
00007cd93bdd5bfb  por xmm15, xmm1
00007cd93bdd5c00  mov rax, [rsp+0x80]
00007cd93bdd5c08  lea r14, [rax+0xA0]
00007cd93bdd5c0f  movups xmm1, [r13+r14*1]
00007cd93bdd5c15  lea r14, [rax+0xB0]
00007cd93bdd5c1c  vmovaps [rsp+0x80], xmm1
00007cd93bdd5c25  movups xmm1, [r13+r14*1]
00007cd93bdd5c2b  vmovaps [rsp+0x90], xmm1
00007cd93bdd5c34  vmovaps [rsp+0xF0], xmm15
00007cd93bdd5c3d  vmovaps xmm15, [rsp+0xB0]
00007cd93bdd5c46  vmovaps [rsp+0xB0], xmm14
00007cd93bdd5c4f  movaps xmm1, xmm6
00007cd93bdd5c52  addpd xmm1, xmm15
00007cd93bdd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007cd93bdd5c5c  ptest xmm14, xmm14
00007cd93bdd5c62  jnz 0x00007CD93BDD7323
00007cd93bdd5c68  lea r14, [rax+0xF0]
00007cd93bdd5c6f  movups xmm15, [r13+r14*1]
00007cd93bdd5c75  movaps xmm14, xmm4
00007cd93bdd5c79  addpd xmm14, xmm3
00007cd93bdd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007cd93bdd5c84  ptest xmm6, xmm6
00007cd93bdd5c89  jnz 0x00007CD93BDD746E
00007cd93bdd5c8f  movaps xmm6, xmm9
00007cd93bdd5c93  addpd xmm6, xmm7
00007cd93bdd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007cd93bdd5c9c  ptest xmm4, xmm4
00007cd93bdd5ca1  jnz 0x00007CD93BDD75B0
00007cd93bdd5ca7  vmovaps xmm9, [rsp+0x70]
00007cd93bdd5cad  vpermilpd xmm9, xmm9, 0x00
00007cd93bdd5cb3  vmovaps xmm4, [rsp+0x90]
00007cd93bdd5cbc  movaps xmm7, xmm4
00007cd93bdd5cbf  mulpd xmm7, xmm9
00007cd93bdd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007cd93bdd5cc9  ptest xmm3, xmm3
00007cd93bdd5cce  jnz 0x00007CD93BDD76F1
00007cd93bdd5cd4  vmovaps xmm9, [rsp+0x50]
00007cd93bdd5cda  vpermilpd xmm9, xmm9, 0x00
00007cd93bdd5ce0  movaps xmm4, xmm15
00007cd93bdd5ce4  mulpd xmm4, xmm9
00007cd93bdd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007cd93bdd5cee  ptest xmm3, xmm3
00007cd93bdd5cf3  jnz 0x00007CD93BDD7832
00007cd93bdd5cf9  lea r14, [rax+0xE0]
00007cd93bdd5d00  movups xmm15, [r13+r14*1]
00007cd93bdd5d06  vmovaps xmm9, [rsp+0x70]
00007cd93bdd5d0c  vpermilpd xmm9, xmm9, 0x00
00007cd93bdd5d12  vmovaps [rsp+0x70], xmm1
00007cd93bdd5d18  vmovaps xmm1, [rsp+0x80]
00007cd93bdd5d21  vmovaps [rsp+0x80], xmm15
00007cd93bdd5d2a  movaps xmm3, xmm1
00007cd93bdd5d2d  mulpd xmm3, xmm9
00007cd93bdd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007cd93bdd5d37  ptest xmm15, xmm15
00007cd93bdd5d3d  jnz 0x00007CD93BDD797E
00007cd93bdd5d43  vmovaps xmm1, [rsp+0xF0]
00007cd93bdd5d4c  vmovaps xmm15, [rsp+0xF0]
00007cd93bdd5d55  por xmm1, xmm15
00007cd93bdd5d5a  movaps [r15+0x300], xmm1
00007cd93bdd5d62  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd5d6b  vmovaps xmm9, [rsp+0xE0]
00007cd93bdd5d74  por xmm15, xmm9
00007cd93bdd5d79  movaps [r15+0x190], xmm15
00007cd93bdd5d81  vmovaps xmm9, [rsp+0x50]
00007cd93bdd5d87  vpermilpd xmm9, xmm9, 0x00
00007cd93bdd5d8d  vmovaps [rsp+0x90], xmm1
00007cd93bdd5d96  vmovaps [rsp+0xE0], xmm15
00007cd93bdd5d9f  vmovaps xmm15, [rsp+0x80]
00007cd93bdd5da8  vmovaps [rsp+0x80], xmm14
00007cd93bdd5db1  movaps xmm1, xmm15
00007cd93bdd5db5  mulpd xmm1, xmm9
00007cd93bdd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007cd93bdd5dbf  ptest xmm14, xmm14
00007cd93bdd5dc5  jnz 0x00007CD93BDD7ABF
00007cd93bdd5dcb  lea r14, [rax+0x90]
00007cd93bdd5dd2  movups xmm15, [r13+r14*1]
00007cd93bdd5dd8  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd5de1  vmovaps xmm9, [rsp+0xD0]
00007cd93bdd5dea  por xmm14, xmm9
00007cd93bdd5def  movaps [r15+0x1C0], xmm14
00007cd93bdd5df7  vmovaps xmm9, [rsp+0xC0]
00007cd93bdd5e00  vmovaps [rsp+0xD0], xmm1
00007cd93bdd5e09  vmovaps xmm1, [rsp+0xC0]
00007cd93bdd5e12  por xmm9, xmm1
00007cd93bdd5e17  movaps [r15+0x200], xmm9
00007cd93bdd5e1f  vmovaps [rsp+0xC0], xmm2
00007cd93bdd5e28  vmovaps xmm1, [rsp+0xC0]
00007cd93bdd5e31  por xmm2, xmm1
00007cd93bdd5e35  movaps [r15+0x2D0], xmm2
00007cd93bdd5e3d  vmovaps [rsp+0xC0], xmm8
00007cd93bdd5e46  vmovaps xmm1, [rsp+0xC0]
00007cd93bdd5e4f  por xmm8, xmm1
00007cd93bdd5e54  movaps [r15+0x2E0], xmm8
00007cd93bdd5e5c  vmovaps [rsp+0xC0], xmm15
00007cd93bdd5e65  movaps xmm1, xmm5
00007cd93bdd5e68  addpd xmm1, xmm7
00007cd93bdd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007cd93bdd5e71  ptest xmm15, xmm15
00007cd93bdd5e77  jnz 0x00007CD93BDD7C0B
00007cd93bdd5e7d  vmovaps xmm15, [rsp+0x50]
00007cd93bdd5e83  vpermilpd xmm15, xmm15, 0x00
00007cd93bdd5e89  vmovaps xmm5, [rsp+0xC0]
00007cd93bdd5e92  vmovaps [rsp+0xC0], xmm1
00007cd93bdd5e9b  movaps xmm7, xmm5
00007cd93bdd5e9e  mulpd xmm7, xmm15
00007cd93bdd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007cd93bdd5ea8  ptest xmm1, xmm1
00007cd93bdd5ead  jnz 0x00007CD93BDD7D4B
00007cd93bdd5eb3  lea r14, [rax+0x80]
00007cd93bdd5eba  movups xmm1, [r13+r14*1]
00007cd93bdd5ec0  vmovaps xmm5, [rsp+0x70]
00007cd93bdd5ec6  vmovaps [rsp+0x70], xmm1
00007cd93bdd5ecc  movaps xmm15, xmm5
00007cd93bdd5ed0  addpd xmm15, xmm3
00007cd93bdd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bdd5edb  ptest xmm1, xmm1
00007cd93bdd5ee0  jnz 0x00007CD93BDD7E96
00007cd93bdd5ee6  vmovaps xmm5, [rsp+0x80]
00007cd93bdd5eef  movaps xmm1, xmm5
00007cd93bdd5ef2  addpd xmm1, xmm4
00007cd93bdd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007cd93bdd5efb  ptest xmm3, xmm3
00007cd93bdd5f00  jnz 0x00007CD93BDD7FD8
00007cd93bdd5f06  vmovaps [rsp+0x80], xmm10
00007cd93bdd5f0f  vmovaps xmm5, [rsp+0x80]
00007cd93bdd5f18  por xmm10, xmm5
00007cd93bdd5f1d  movaps [r15+0x2F0], xmm10
00007cd93bdd5f25  vmovaps xmm5, [rsp+0x50]
00007cd93bdd5f2b  vpermilpd xmm5, xmm5, 0x00
00007cd93bdd5f31  vmovaps xmm3, [rsp+0x70]
00007cd93bdd5f37  vmovaps [rsp+0x50], xmm1
00007cd93bdd5f3d  movaps xmm4, xmm3
00007cd93bdd5f40  mulpd xmm4, xmm5
00007cd93bdd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007cd93bdd5f49  ptest xmm1, xmm1
00007cd93bdd5f4e  jnz 0x00007CD93BDD8118
00007cd93bdd5f54  lea r14, [rax+0xD0]
00007cd93bdd5f5b  movups xmm1, [r13+r14*1]
00007cd93bdd5f61  vmovaps xmm3, [rsp+0xD0]
00007cd93bdd5f6a  vmovaps [rsp+0x70], xmm1
00007cd93bdd5f70  movaps xmm5, xmm6
00007cd93bdd5f73  addpd xmm5, xmm3
00007cd93bdd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007cd93bdd5f7c  ptest xmm1, xmm1
00007cd93bdd5f81  jnz 0x00007CD93BDD8262
00007cd93bdd5f87  vmovaps xmm1, [rsp+0x60]
00007cd93bdd5f8d  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd5f93  movaps xmm6, xmm9
00007cd93bdd5f97  mulpd xmm6, xmm1
00007cd93bdd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007cd93bdd5fa0  ptest xmm3, xmm3
00007cd93bdd5fa5  jnz 0x00007CD93BDD83A2
00007cd93bdd5fab  movaps [r15+0x260], xmm6
00007cd93bdd5fb3  vxorps xmm1, xmm1, xmm1
00007cd93bdd5fb7  vpbroadcastq xmm1, xmm1
00007cd93bdd5fbc  movaps [r15+0x1B0], xmm1
00007cd93bdd5fc4  vmovaps xmm1, [rsp+0x60]
00007cd93bdd5fca  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd5fd0  vmovaps xmm3, [rsp+0x70]
00007cd93bdd5fd6  vmovaps [rsp+0x70], xmm15
00007cd93bdd5fdc  movaps xmm9, xmm3
00007cd93bdd5fe0  mulpd xmm9, xmm1
00007cd93bdd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007cd93bdd5feb  ptest xmm15, xmm15
00007cd93bdd5ff1  jnz 0x00007CD93BDD84E3
00007cd93bdd5ff7  lea r14, [rax+0xC0]
00007cd93bdd5ffe  movups xmm1, [r13+r14*1]
00007cd93bdd6004  vmovaps xmm3, [rsp+0xC0]
00007cd93bdd600d  vmovaps [rsp+0x80], xmm1
00007cd93bdd6016  movaps xmm15, xmm3
00007cd93bdd601a  addpd xmm15, xmm7
00007cd93bdd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bdd6025  ptest xmm1, xmm1
00007cd93bdd602a  jnz 0x00007CD93BDD862F
00007cd93bdd6030  vmovaps [rsp+0xC0], xmm13
00007cd93bdd6039  vmovaps xmm1, [rsp+0xC0]
00007cd93bdd6042  por xmm13, xmm1
00007cd93bdd6047  movaps [r15+0x270], xmm13
00007cd93bdd604f  vmovaps xmm1, [rsp+0xB0]
00007cd93bdd6058  vmovaps xmm7, [rsp+0xB0]
00007cd93bdd6061  por xmm1, xmm7
00007cd93bdd6065  movaps [r15+0x1A0], xmm1
00007cd93bdd606d  vmovaps xmm1, [rsp+0x60]
00007cd93bdd6073  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd6079  vmovaps [rsp+0xB0], xmm1
00007cd93bdd6082  vmovaps xmm1, [rsp+0x80]
00007cd93bdd608b  vmovaps [rsp+0x80], xmm15
00007cd93bdd6094  vmovaps xmm15, [rsp+0xB0]
00007cd93bdd609d  vmovaps [rsp+0xB0], xmm14
00007cd93bdd60a6  movaps xmm3, xmm1
00007cd93bdd60a9  mulpd xmm3, xmm15
00007cd93bdd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007cd93bdd60b3  ptest xmm14, xmm14
00007cd93bdd60b9  jnz 0x00007CD93BDD8771
00007cd93bdd60bf  lea r14, [rax+0x20]
00007cd93bdd60c3  movups xmm1, [r13+r14*1]
00007cd93bdd60c9  movaps [r15+0x110], xmm1
00007cd93bdd60d1  vmovaps xmm14, [rsp+0x70]
00007cd93bdd60d7  vmovaps [rsp+0x70], xmm1
00007cd93bdd60dd  movaps xmm15, xmm14
00007cd93bdd60e1  addpd xmm15, xmm4
00007cd93bdd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bdd60ec  ptest xmm1, xmm1
00007cd93bdd60f1  jnz 0x00007CD93BDD88BC
00007cd93bdd60f7  vmovaps xmm1, [rsp+0x60]
00007cd93bdd60fd  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd6103  movaps xmm14, xmm2
00007cd93bdd6107  mulpd xmm14, xmm1
00007cd93bdd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007cd93bdd6112  ptest xmm4, xmm4
00007cd93bdd6117  jnz 0x00007CD93BDD89FF
00007cd93bdd611d  vmovaps xmm4, [rsp+0x50]
00007cd93bdd6123  movaps xmm1, xmm4
00007cd93bdd6126  addpd xmm1, xmm9
00007cd93bdd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007cd93bdd6130  ptest xmm2, xmm2
00007cd93bdd6135  jnz 0x00007CD93BDD8B41
00007cd93bdd613b  vmovaps xmm9, [rsp+0x30]
00007cd93bdd6141  vpermilpd xmm9, xmm9, 0x00
00007cd93bdd6147  vmovaps xmm2, [rsp+0x70]
00007cd93bdd614d  vmovaps [rsp+0x50], xmm1
00007cd93bdd6153  movaps xmm4, xmm2
00007cd93bdd6156  mulpd xmm4, xmm9
00007cd93bdd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007cd93bdd6160  ptest xmm1, xmm1
00007cd93bdd6165  jnz 0x00007CD93BDD8C82
00007cd93bdd616b  vmovaps xmm1, [rsp+0x30]
00007cd93bdd6171  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd6177  vmovaps xmm2, [rsp+0x90]
00007cd93bdd6180  vmovaps [rsp+0x60], xmm15
00007cd93bdd6186  movaps xmm9, xmm2
00007cd93bdd618a  mulpd xmm9, xmm1
00007cd93bdd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007cd93bdd6195  ptest xmm15, xmm15
00007cd93bdd619b  jnz 0x00007CD93BDD8DC3
00007cd93bdd61a1  vmovaps xmm15, [rsp+0x80]
00007cd93bdd61aa  movaps xmm1, xmm15
00007cd93bdd61ae  addpd xmm1, xmm6
00007cd93bdd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007cd93bdd61b7  ptest xmm2, xmm2
00007cd93bdd61bc  jnz 0x00007CD93BDD8F05
00007cd93bdd61c2  movaps xmm15, xmm5
00007cd93bdd61c6  addpd xmm15, xmm3
00007cd93bdd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007cd93bdd61d1  ptest xmm6, xmm6
00007cd93bdd61d6  jnz 0x00007CD93BDD9046
00007cd93bdd61dc  vmovaps xmm6, [rsp+0x30]
00007cd93bdd61e2  vpermilpd xmm6, xmm6, 0x00
00007cd93bdd61e8  movaps xmm5, xmm8
00007cd93bdd61ec  mulpd xmm5, xmm6
00007cd93bdd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007cd93bdd61f5  ptest xmm3, xmm3
00007cd93bdd61fa  jnz 0x00007CD93BDD9188
00007cd93bdd6200  vmovaps xmm8, [rsp+0x30]
00007cd93bdd6206  vpermilpd xmm8, xmm8, 0x00
00007cd93bdd620c  movaps xmm6, xmm10
00007cd93bdd6210  mulpd xmm6, xmm8
00007cd93bdd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007cd93bdd621a  ptest xmm3, xmm3
00007cd93bdd621f  jnz 0x00007CD93BDD92C9
00007cd93bdd6225  vmovaps xmm8, [rsp+0x60]
00007cd93bdd622b  movaps xmm10, xmm8
00007cd93bdd622f  addpd xmm10, xmm14
00007cd93bdd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007cd93bdd623a  ptest xmm3, xmm3
00007cd93bdd623f  jnz 0x00007CD93BDD940B
00007cd93bdd6245  vmovaps xmm8, [rsp+0x50]
00007cd93bdd624b  movaps xmm14, xmm8
00007cd93bdd624f  addpd xmm14, xmm4
00007cd93bdd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007cd93bdd625a  ptest xmm3, xmm3
00007cd93bdd625f  jnz 0x00007CD93BDD954F
00007cd93bdd6265  vmovaps xmm8, [rsp+0x40]
00007cd93bdd626b  vpermilpd xmm8, xmm8, 0x00
00007cd93bdd6271  movaps xmm4, xmm13
00007cd93bdd6275  mulpd xmm4, xmm8
00007cd93bdd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007cd93bdd627f  ptest xmm3, xmm3
00007cd93bdd6284  jnz 0x00007CD93BDD9692
00007cd93bdd628a  movaps xmm13, xmm15
00007cd93bdd628e  addpd xmm13, xmm9
00007cd93bdd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007cd93bdd6299  ptest xmm8, xmm8
00007cd93bdd629f  jnz 0x00007CD93BDD97D4
00007cd93bdd62a5  movaps xmm15, xmm1
00007cd93bdd62a9  addpd xmm15, xmm5
00007cd93bdd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007cd93bdd62b4  ptest xmm9, xmm9
00007cd93bdd62ba  jnz 0x00007CD93BDD9918
00007cd93bdd62c0  vmovaps [rsp+0x30], xmm11
00007cd93bdd62c6  vmovaps xmm1, [rsp+0x30]
00007cd93bdd62cc  por xmm11, xmm1
00007cd93bdd62d1  movaps [r15+0x250], xmm11
00007cd93bdd62d9  vmovaps [rsp+0x30], xmm12
00007cd93bdd62df  vmovaps xmm1, [rsp+0x30]
00007cd93bdd62e5  por xmm12, xmm1
00007cd93bdd62ea  movaps [r15+0x2A0], xmm12
00007cd93bdd62f2  vmovaps xmm1, [rsp+0xA0]
00007cd93bdd62fb  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd6304  por xmm1, xmm11
00007cd93bdd6309  movaps [r15+0x1D0], xmm1
00007cd93bdd6311  lea r14, [rax+0x40]
00007cd93bdd6315  movups xmm1, [r13+r14*1]
00007cd93bdd631b  movaps [r15+0x2C0], xmm1
00007cd93bdd6323  vmovaps xmm11, [rsp+0x40]
00007cd93bdd6329  vpermilpd xmm11, xmm11, 0x00
00007cd93bdd632f  vmovaps xmm8, [rsp+0xE0]
00007cd93bdd6338  movaps xmm9, xmm8
00007cd93bdd633c  mulpd xmm9, xmm11
00007cd93bdd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007cd93bdd6347  ptest xmm5, xmm5
00007cd93bdd634c  jnz 0x00007CD93BDD9A64
00007cd93bdd6352  movaps xmm11, xmm10
00007cd93bdd6356  addpd xmm11, xmm6
00007cd93bdd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007cd93bdd6361  ptest xmm8, xmm8
00007cd93bdd6367  jnz 0x00007CD93BDD9BA8
00007cd93bdd636d  movaps xmm10, xmm14
00007cd93bdd6371  addpd xmm10, xmm4
00007cd93bdd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007cd93bdd637c  ptest xmm8, xmm8
00007cd93bdd6382  jnz 0x00007CD93BDD9CEB
00007cd93bdd6388  vmovaps xmm14, [rsp+0x40]
00007cd93bdd638e  vpermilpd xmm14, xmm14, 0x00
00007cd93bdd6394  movaps xmm8, xmm1
00007cd93bdd6398  mulpd xmm8, xmm14
00007cd93bdd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007cd93bdd63a3  ptest xmm6, xmm6
00007cd93bdd63a8  jnz 0x00007CD93BDD9E2E
00007cd93bdd63ae  movaps xmm1, [r15+0x2B0]
00007cd93bdd63b6  vmovaps xmm14, [rsp+0x40]
00007cd93bdd63bc  vpermilpd xmm14, xmm14, 0x00
00007cd93bdd63c2  movaps xmm6, xmm1
00007cd93bdd63c5  mulpd xmm6, xmm14
00007cd93bdd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007cd93bdd63cf  ptest xmm5, xmm5
00007cd93bdd63d4  jnz 0x00007CD93BDD9F71
00007cd93bdd63da  vmovaps xmm1, [rsp+0x10]
00007cd93bdd63e0  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd63e6  movaps xmm14, xmm12
00007cd93bdd63ea  mulpd xmm14, xmm1
00007cd93bdd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007cd93bdd63f5  ptest xmm5, xmm5
00007cd93bdd63fa  jnz 0x00007CD93BDDA0B2
00007cd93bdd6400  movaps xmm1, xmm13
00007cd93bdd6404  addpd xmm1, xmm9
00007cd93bdd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007cd93bdd640e  ptest xmm12, xmm12
00007cd93bdd6414  jnz 0x00007CD93BDDA1F5
00007cd93bdd641a  vmovaps xmm13, [rsp+0x10]
00007cd93bdd6420  vpermilpd xmm13, xmm13, 0x00
00007cd93bdd6426  movaps xmm12, xmm7
00007cd93bdd642a  mulpd xmm12, xmm13
00007cd93bdd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007cd93bdd6435  ptest xmm9, xmm9
00007cd93bdd643b  jnz 0x00007CD93BDDA337
00007cd93bdd6441  movaps xmm13, xmm15
00007cd93bdd6445  addpd xmm13, xmm8
00007cd93bdd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007cd93bdd6450  ptest xmm9, xmm9
00007cd93bdd6456  jnz 0x00007CD93BDDA47A
00007cd93bdd645c  movaps xmm15, [r15+0x290]
00007cd93bdd6464  vmovaps xmm9, [rsp+0x10]
00007cd93bdd646a  vpermilpd xmm9, xmm9, 0x00
00007cd93bdd6470  movaps xmm8, xmm15
00007cd93bdd6474  mulpd xmm8, xmm9
00007cd93bdd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007cd93bdd647f  ptest xmm7, xmm7
00007cd93bdd6484  jnz 0x00007CD93BDDA5BE
00007cd93bdd648a  movaps xmm15, xmm11
00007cd93bdd648e  addpd xmm15, xmm6
00007cd93bdd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007cd93bdd6499  ptest xmm9, xmm9
00007cd93bdd649f  jnz 0x00007CD93BDDA702
00007cd93bdd64a5  movaps xmm11, [r15+0x1E0]
00007cd93bdd64ad  vmovaps xmm9, [rsp+0x10]
00007cd93bdd64b3  vpermilpd xmm9, xmm9, 0x00
00007cd93bdd64b9  movaps xmm7, xmm11
00007cd93bdd64bd  mulpd xmm7, xmm9
00007cd93bdd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007cd93bdd64c7  ptest xmm6, xmm6
00007cd93bdd64cc  jnz 0x00007CD93BDDA845
00007cd93bdd64d2  movaps xmm11, xmm10
00007cd93bdd64d6  addpd xmm11, xmm14
00007cd93bdd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007cd93bdd64e1  ptest xmm9, xmm9
00007cd93bdd64e7  jnz 0x00007CD93BDDA987
00007cd93bdd64ed  lea r14, [rax+0x70]
00007cd93bdd64f1  movups xmm14, [r13+r14*1]
00007cd93bdd64f7  movaps [r15+0x240], xmm14
00007cd93bdd64ff  movaps xmm10, xmm1
00007cd93bdd6503  addpd xmm10, xmm12
00007cd93bdd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007cd93bdd650e  ptest xmm9, xmm9
00007cd93bdd6514  jnz 0x00007CD93BDDAAD5
00007cd93bdd651a  movaps [r15+0x170], xmm10
00007cd93bdd6522  vmovaps xmm1, [rsp+0x20]
00007cd93bdd6528  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd652e  movaps xmm12, xmm14
00007cd93bdd6532  mulpd xmm12, xmm1
00007cd93bdd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007cd93bdd653d  ptest xmm9, xmm9
00007cd93bdd6543  jnz 0x00007CD93BDDAC18
00007cd93bdd6549  vmovaps xmm1, [rsp+0x20]
00007cd93bdd654f  vpermilpd xmm1, xmm1, 0x00
00007cd93bdd6555  vmovaps xmm9, [rsp+0xB0]
00007cd93bdd655e  movaps xmm14, xmm9
00007cd93bdd6562  mulpd xmm14, xmm1
00007cd93bdd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007cd93bdd656d  ptest xmm6, xmm6
00007cd93bdd6572  jnz 0x00007CD93BDDAD5B
00007cd93bdd6578  movaps [r15+0x180], xmm14
00007cd93bdd6580  movaps xmm1, xmm13
00007cd93bdd6584  addpd xmm1, xmm8
00007cd93bdd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007cd93bdd658e  ptest xmm9, xmm9
00007cd93bdd6594  jnz 0x00007CD93BDDAE9E
00007cd93bdd659a  movaps [r15+0x210], xmm1
00007cd93bdd65a2  movups xmm13, [r13+rax*1]
00007cd93bdd65a8  lea r14, [rax+0x10]
00007cd93bdd65ac  movups xmm9, [r13+r14*1]
00007cd93bdd65b2  movaps [r15+0x230], xmm9
00007cd93bdd65ba  movaps xmm8, xmm15
00007cd93bdd65be  addpd xmm8, xmm7
00007cd93bdd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007cd93bdd65c9  ptest xmm6, xmm6
00007cd93bdd65ce  jnz 0x00007CD93BDDAFF4
00007cd93bdd65d4  movaps [r15+0x130], xmm8
00007cd93bdd65dc  vmovaps xmm15, [rsp+0x20]
00007cd93bdd65e2  vpermilpd xmm15, xmm15, 0x00
00007cd93bdd65e8  movaps xmm7, xmm9
00007cd93bdd65ec  mulpd xmm7, xmm15
00007cd93bdd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007cd93bdd65f6  ptest xmm6, xmm6
00007cd93bdd65fb  jnz 0x00007CD93BDDB137
00007cd93bdd6601  movaps [r15+0x220], xmm7
00007cd93bdd6609  vmovaps xmm15, [rsp+0x20]
00007cd93bdd660f  vpermilpd xmm15, xmm15, 0x00
00007cd93bdd6615  movaps xmm9, xmm13
00007cd93bdd6619  mulpd xmm9, xmm15
00007cd93bdd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007cd93bdd6624  ptest xmm6, xmm6
00007cd93bdd6629  jnz 0x00007CD93BDDB279
00007cd93bdd662f  movaps xmm15, xmm11
00007cd93bdd6633  addpd xmm15, xmm12
00007cd93bdd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007cd93bdd663e  ptest xmm13, xmm13
00007cd93bdd6644  jnz 0x00007CD93BDDB3BD
00007cd93bdd664a  movaps [r15+0x140], xmm15
00007cd93bdd6652  movaps xmm13, xmm10
00007cd93bdd6656  addpd xmm13, xmm14
00007cd93bdd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007cd93bdd6661  ptest xmm12, xmm12
00007cd93bdd6667  jnz 0x00007CD93BDDB501
00007cd93bdd666d  movaps [r15+0x150], xmm13
00007cd93bdd6675  movaps xmm14, xmm1
00007cd93bdd6679  addpd xmm14, xmm7
00007cd93bdd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007cd93bdd6684  ptest xmm12, xmm12
00007cd93bdd668a  jnz 0x00007CD93BDDB645
00007cd93bdd6690  movaps [r15+0x160], xmm14
00007cd93bdd6698  movaps xmm1, xmm8
00007cd93bdd669c  addpd xmm1, xmm9
00007cd93bdd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007cd93bdd66a6  ptest xmm12, xmm12
00007cd93bdd66ac  jnz 0x00007CD93BDDB787
00007cd93bdd66b2  movaps [r15+0x120], xmm1
00007cd93bdd66ba  movups [r13+r11*1], xmm15
00007cd93bdd66c0  lea rax, [r11+0x10]
00007cd93bdd66c4  movups [r13+rax*1], xmm13
00007cd93bdd66ca  lea rax, [r11+0x20]
00007cd93bdd66ce  movups [r13+rax*1], xmm14
00007cd93bdd66d4  lea rax, [r11+0x30]
00007cd93bdd66d8  movups [r13+rax*1], xmm1
00007cd93bdd66de  mov eax, [r15+0x108]
00007cd93bdd66e5  sahf
00007cd93bdd66e6  jnz 0x00007CD93BDD6718
00007cd93bdd66e8  cmp dword ptr [r15+0x318], 0x00
00007cd93bdd66f0  jz 0x00007CD93BDDB900
00007cd93bdd66f6  nop [rax+rax*1], ax
00007cd93bdd66ff  nop [rax+rax*1], eax
00007cd93bdd6707  mov eax, 0x410444
00007cd93bdd670c  mov [r15+0x100], rax
00007cd93bdd6713  jmp 0x00007CD93BBFE110
00007cd93bdd6718  cmp dword ptr [r15+0x318], 0x00
00007cd93bdd6720  jz 0x00007CD93BDD57E0
00007cd93bdd6726  nop [rax+rax*1], ax
00007cd93bdd672f  nop [rax+rax*1], eax
00007cd93bdd6737  mov eax, 0x410278
00007cd93bdd673c  mov [r15+0x100], rax
00007cd93bdd6743  jmp 0x00007CD93BBFE110
00007cd93bdd6748  int3
00007cd93bdd6749  call 0x00007CD93BC0A4B0
00007cd93bdd674e  jmp 0x00007CD93BDD5828
00007cd93bdd6753  call 0x00007CD93BC09240
00007cd93bdd6758  jmp 0x00007CD93BDD5832
00007cd93bdd675d  call 0x00007CD93BC0A4B0
00007cd93bdd6762  jmp 0x00007CD93BDD588F
00007cd93bdd6767  call 0x00007CD93BC09240
00007cd93bdd676c  jmp 0x00007CD93BDD5899
00007cd93bdd6771  call 0x00007CD93BC0A4B0
00007cd93bdd6776  jmp 0x00007CD93BDD58DD
00007cd93bdd677b  call 0x00007CD93BC09240
00007cd93bdd6780  jmp 0x00007CD93BDD58E7
00007cd93bdd6785  call 0x00007CD93BCB47C0
00007cd93bdd678a  jmp 0x00007CD93BDD5926
00007cd93bdd678f  call 0x00007CD93BC0B720
00007cd93bdd6794  jmp 0x00007CD93BDD593A
00007cd93bdd6799  call 0x00007CD93BCBFC30
00007cd93bdd679e  jmp 0x00007CD93BDD5958
00007cd93bdd67a3  call 0x00007CD93BCBE9C0
00007cd93bdd67a8  jmp 0x00007CD93BDD5962
00007cd93bdd67ad  call 0x00007CD93BCBD750
00007cd93bdd67b2  jmp 0x00007CD93BDD596C
00007cd93bdd67b7  sub rsp, 0x08
00007cd93bdd67bb  push rax
00007cd93bdd67bc  push rcx
00007cd93bdd67bd  push rdx
00007cd93bdd67be  push rdi
00007cd93bdd67bf  push rsi
00007cd93bdd67c0  push r8
00007cd93bdd67c2  push r9
00007cd93bdd67c4  push r10
00007cd93bdd67c6  push r11
00007cd93bdd67c8  sub rsp, 0xF0
00007cd93bdd67cf  vmovaps [rsp], xmm0
00007cd93bdd67d4  vmovaps [rsp+0x10], xmm1
00007cd93bdd67da  vmovaps [rsp+0x20], xmm2
00007cd93bdd67e0  vmovaps [rsp+0x30], xmm3
00007cd93bdd67e6  vmovaps [rsp+0x40], xmm4
00007cd93bdd67ec  vmovaps [rsp+0x50], xmm5
00007cd93bdd67f2  vmovaps [rsp+0x60], xmm6
00007cd93bdd67f8  vmovaps [rsp+0x70], xmm7
00007cd93bdd67fe  vmovaps [rsp+0x80], xmm9
00007cd93bdd6807  vmovaps [rsp+0x90], xmm10
00007cd93bdd6810  vmovaps [rsp+0xA0], xmm11
00007cd93bdd6819  vmovaps [rsp+0xB0], xmm12
00007cd93bdd6822  vmovaps [rsp+0xC0], xmm13
00007cd93bdd682b  vmovaps [rsp+0xD0], xmm14
00007cd93bdd6834  vmovaps [rsp+0xE0], xmm15
00007cd93bdd683d  sub rsp, 0x30
00007cd93bdd6841  movaps [rsp], xmm8
00007cd93bdd6846  movaps [rsp+0x10], xmm12
00007cd93bdd684c  movaps [rsp+0x20], xmm15
00007cd93bdd6852  lea rdi, [rsp]
00007cd93bdd6856  mov esi, 0x00
00007cd93bdd685b  mov rax, 0x64A581057530
00007cd93bdd6865  call rax
00007cd93bdd6867  movaps xmm8, [rsp]
00007cd93bdd686c  add rsp, 0x30
00007cd93bdd6870  vmovaps xmm0, [rsp]
00007cd93bdd6875  vmovaps xmm1, [rsp+0x10]
00007cd93bdd687b  vmovaps xmm2, [rsp+0x20]
00007cd93bdd6881  vmovaps xmm3, [rsp+0x30]
00007cd93bdd6887  vmovaps xmm4, [rsp+0x40]
00007cd93bdd688d  vmovaps xmm5, [rsp+0x50]
00007cd93bdd6893  vmovaps xmm6, [rsp+0x60]
00007cd93bdd6899  vmovaps xmm7, [rsp+0x70]
00007cd93bdd689f  vmovaps xmm9, [rsp+0x80]
00007cd93bdd68a8  vmovaps xmm10, [rsp+0x90]
00007cd93bdd68b1  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd68ba  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd68c3  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd68cc  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd68d5  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd68de  add rsp, 0xF0
00007cd93bdd68e5  pop r11
00007cd93bdd68e7  pop r10
00007cd93bdd68e9  pop r9
00007cd93bdd68eb  pop r8
00007cd93bdd68ed  pop rsi
00007cd93bdd68ee  pop rdi
00007cd93bdd68ef  pop rdx
00007cd93bdd68f0  pop rcx
00007cd93bdd68f1  pop rax
00007cd93bdd68f2  add rsp, 0x08
00007cd93bdd68f6  jmp 0x00007CD93BDD599A
00007cd93bdd68fb  sub rsp, 0x08
00007cd93bdd68ff  push rax
00007cd93bdd6900  push rcx
00007cd93bdd6901  push rdx
00007cd93bdd6902  push rdi
00007cd93bdd6903  push rsi
00007cd93bdd6904  push r8
00007cd93bdd6906  push r9
00007cd93bdd6908  push r10
00007cd93bdd690a  push r11
00007cd93bdd690c  sub rsp, 0xF0
00007cd93bdd6913  vmovaps [rsp], xmm0
00007cd93bdd6918  vmovaps [rsp+0x10], xmm1
00007cd93bdd691e  vmovaps [rsp+0x20], xmm2
00007cd93bdd6924  vmovaps [rsp+0x30], xmm3
00007cd93bdd692a  vmovaps [rsp+0x40], xmm4
00007cd93bdd6930  vmovaps [rsp+0x50], xmm5
00007cd93bdd6936  vmovaps [rsp+0x60], xmm6
00007cd93bdd693c  vmovaps [rsp+0x70], xmm8
00007cd93bdd6942  vmovaps [rsp+0x80], xmm9
00007cd93bdd694b  vmovaps [rsp+0x90], xmm10
00007cd93bdd6954  vmovaps [rsp+0xA0], xmm11
00007cd93bdd695d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd6966  vmovaps [rsp+0xC0], xmm13
00007cd93bdd696f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd6978  vmovaps [rsp+0xE0], xmm15
00007cd93bdd6981  sub rsp, 0x30
00007cd93bdd6985  movaps [rsp], xmm7
00007cd93bdd6989  movaps [rsp+0x10], xmm9
00007cd93bdd698f  movaps [rsp+0x20], xmm15
00007cd93bdd6995  lea rdi, [rsp]
00007cd93bdd6999  mov esi, 0x00
00007cd93bdd699e  mov rax, 0x64A581057530
00007cd93bdd69a8  call rax
00007cd93bdd69aa  movaps xmm7, [rsp]
00007cd93bdd69ae  add rsp, 0x30
00007cd93bdd69b2  vmovaps xmm0, [rsp]
00007cd93bdd69b7  vmovaps xmm1, [rsp+0x10]
00007cd93bdd69bd  vmovaps xmm2, [rsp+0x20]
00007cd93bdd69c3  vmovaps xmm3, [rsp+0x30]
00007cd93bdd69c9  vmovaps xmm4, [rsp+0x40]
00007cd93bdd69cf  vmovaps xmm5, [rsp+0x50]
00007cd93bdd69d5  vmovaps xmm6, [rsp+0x60]
00007cd93bdd69db  vmovaps xmm8, [rsp+0x70]
00007cd93bdd69e1  vmovaps xmm9, [rsp+0x80]
00007cd93bdd69ea  vmovaps xmm10, [rsp+0x90]
00007cd93bdd69f3  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd69fc  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd6a05  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd6a0e  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd6a17  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd6a20  add rsp, 0xF0
00007cd93bdd6a27  pop r11
00007cd93bdd6a29  pop r10
00007cd93bdd6a2b  pop r9
00007cd93bdd6a2d  pop r8
00007cd93bdd6a2f  pop rsi
00007cd93bdd6a30  pop rdi
00007cd93bdd6a31  pop rdx
00007cd93bdd6a32  pop rcx
00007cd93bdd6a33  pop rax
00007cd93bdd6a34  add rsp, 0x08
00007cd93bdd6a38  jmp 0x00007CD93BDD59C8
00007cd93bdd6a3d  sub rsp, 0x08
00007cd93bdd6a41  push rax
00007cd93bdd6a42  push rcx
00007cd93bdd6a43  push rdx
00007cd93bdd6a44  push rdi
00007cd93bdd6a45  push rsi
00007cd93bdd6a46  push r8
00007cd93bdd6a48  push r9
00007cd93bdd6a4a  push r10
00007cd93bdd6a4c  push r11
00007cd93bdd6a4e  sub rsp, 0xF0
00007cd93bdd6a55  vmovaps [rsp], xmm0
00007cd93bdd6a5a  vmovaps [rsp+0x10], xmm1
00007cd93bdd6a60  vmovaps [rsp+0x20], xmm2
00007cd93bdd6a66  vmovaps [rsp+0x30], xmm3
00007cd93bdd6a6c  vmovaps [rsp+0x40], xmm4
00007cd93bdd6a72  vmovaps [rsp+0x50], xmm5
00007cd93bdd6a78  vmovaps [rsp+0x60], xmm6
00007cd93bdd6a7e  vmovaps [rsp+0x70], xmm7
00007cd93bdd6a84  vmovaps [rsp+0x80], xmm8
00007cd93bdd6a8d  vmovaps [rsp+0x90], xmm10
00007cd93bdd6a96  vmovaps [rsp+0xA0], xmm11
00007cd93bdd6a9f  vmovaps [rsp+0xB0], xmm12
00007cd93bdd6aa8  vmovaps [rsp+0xC0], xmm13
00007cd93bdd6ab1  vmovaps [rsp+0xD0], xmm14
00007cd93bdd6aba  vmovaps [rsp+0xE0], xmm15
00007cd93bdd6ac3  sub rsp, 0x30
00007cd93bdd6ac7  movaps [rsp], xmm9
00007cd93bdd6acc  movaps [rsp+0x10], xmm12
00007cd93bdd6ad2  movaps [rsp+0x20], xmm10
00007cd93bdd6ad8  lea rdi, [rsp]
00007cd93bdd6adc  mov esi, 0x00
00007cd93bdd6ae1  mov rax, 0x64A581057530
00007cd93bdd6aeb  call rax
00007cd93bdd6aed  movaps xmm9, [rsp]
00007cd93bdd6af2  add rsp, 0x30
00007cd93bdd6af6  vmovaps xmm0, [rsp]
00007cd93bdd6afb  vmovaps xmm1, [rsp+0x10]
00007cd93bdd6b01  vmovaps xmm2, [rsp+0x20]
00007cd93bdd6b07  vmovaps xmm3, [rsp+0x30]
00007cd93bdd6b0d  vmovaps xmm4, [rsp+0x40]
00007cd93bdd6b13  vmovaps xmm5, [rsp+0x50]
00007cd93bdd6b19  vmovaps xmm6, [rsp+0x60]
00007cd93bdd6b1f  vmovaps xmm7, [rsp+0x70]
00007cd93bdd6b25  vmovaps xmm8, [rsp+0x80]
00007cd93bdd6b2e  vmovaps xmm10, [rsp+0x90]
00007cd93bdd6b37  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd6b40  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd6b49  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd6b52  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd6b5b  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd6b64  add rsp, 0xF0
00007cd93bdd6b6b  pop r11
00007cd93bdd6b6d  pop r10
00007cd93bdd6b6f  pop r9
00007cd93bdd6b71  pop r8
00007cd93bdd6b73  pop rsi
00007cd93bdd6b74  pop rdi
00007cd93bdd6b75  pop rdx
00007cd93bdd6b76  pop rcx
00007cd93bdd6b77  pop rax
00007cd93bdd6b78  add rsp, 0x08
00007cd93bdd6b7c  jmp 0x00007CD93BDD59EC
00007cd93bdd6b81  sub rsp, 0x08
00007cd93bdd6b85  push rax
00007cd93bdd6b86  push rcx
00007cd93bdd6b87  push rdx
00007cd93bdd6b88  push rdi
00007cd93bdd6b89  push rsi
00007cd93bdd6b8a  push r8
00007cd93bdd6b8c  push r9
00007cd93bdd6b8e  push r10
00007cd93bdd6b90  push r11
00007cd93bdd6b92  sub rsp, 0xF0
00007cd93bdd6b99  vmovaps [rsp], xmm0
00007cd93bdd6b9e  vmovaps [rsp+0x10], xmm1
00007cd93bdd6ba4  vmovaps [rsp+0x20], xmm2
00007cd93bdd6baa  vmovaps [rsp+0x30], xmm3
00007cd93bdd6bb0  vmovaps [rsp+0x40], xmm4
00007cd93bdd6bb6  vmovaps [rsp+0x50], xmm5
00007cd93bdd6bbc  vmovaps [rsp+0x60], xmm6
00007cd93bdd6bc2  vmovaps [rsp+0x70], xmm7
00007cd93bdd6bc8  vmovaps [rsp+0x80], xmm8
00007cd93bdd6bd1  vmovaps [rsp+0x90], xmm9
00007cd93bdd6bda  vmovaps [rsp+0xA0], xmm11
00007cd93bdd6be3  vmovaps [rsp+0xB0], xmm12
00007cd93bdd6bec  vmovaps [rsp+0xC0], xmm13
00007cd93bdd6bf5  vmovaps [rsp+0xD0], xmm14
00007cd93bdd6bfe  vmovaps [rsp+0xE0], xmm15
00007cd93bdd6c07  sub rsp, 0x30
00007cd93bdd6c0b  movaps [rsp], xmm10
00007cd93bdd6c10  movaps [rsp+0x10], xmm12
00007cd93bdd6c16  movaps [rsp+0x20], xmm11
00007cd93bdd6c1c  lea rdi, [rsp]
00007cd93bdd6c20  mov esi, 0x00
00007cd93bdd6c25  mov rax, 0x64A581057530
00007cd93bdd6c2f  call rax
00007cd93bdd6c31  movaps xmm10, [rsp]
00007cd93bdd6c36  add rsp, 0x30
00007cd93bdd6c3a  vmovaps xmm0, [rsp]
00007cd93bdd6c3f  vmovaps xmm1, [rsp+0x10]
00007cd93bdd6c45  vmovaps xmm2, [rsp+0x20]
00007cd93bdd6c4b  vmovaps xmm3, [rsp+0x30]
00007cd93bdd6c51  vmovaps xmm4, [rsp+0x40]
00007cd93bdd6c57  vmovaps xmm5, [rsp+0x50]
00007cd93bdd6c5d  vmovaps xmm6, [rsp+0x60]
00007cd93bdd6c63  vmovaps xmm7, [rsp+0x70]
00007cd93bdd6c69  vmovaps xmm8, [rsp+0x80]
00007cd93bdd6c72  vmovaps xmm9, [rsp+0x90]
00007cd93bdd6c7b  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd6c84  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd6c8d  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd6c96  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd6c9f  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd6ca8  add rsp, 0xF0
00007cd93bdd6caf  pop r11
00007cd93bdd6cb1  pop r10
00007cd93bdd6cb3  pop r9
00007cd93bdd6cb5  pop r8
00007cd93bdd6cb7  pop rsi
00007cd93bdd6cb8  pop rdi
00007cd93bdd6cb9  pop rdx
00007cd93bdd6cba  pop rcx
00007cd93bdd6cbb  pop rax
00007cd93bdd6cbc  add rsp, 0x08
00007cd93bdd6cc0  jmp 0x00007CD93BDD5A06
00007cd93bdd6cc5  sub rsp, 0x08
00007cd93bdd6cc9  push rax
00007cd93bdd6cca  push rcx
00007cd93bdd6ccb  push rdx
00007cd93bdd6ccc  push rdi
00007cd93bdd6ccd  push rsi
00007cd93bdd6cce  push r8
00007cd93bdd6cd0  push r9
00007cd93bdd6cd2  push r10
00007cd93bdd6cd4  push r11
00007cd93bdd6cd6  sub rsp, 0xF0
00007cd93bdd6cdd  vmovaps [rsp], xmm0
00007cd93bdd6ce2  vmovaps [rsp+0x10], xmm1
00007cd93bdd6ce8  vmovaps [rsp+0x20], xmm2
00007cd93bdd6cee  vmovaps [rsp+0x30], xmm3
00007cd93bdd6cf4  vmovaps [rsp+0x40], xmm4
00007cd93bdd6cfa  vmovaps [rsp+0x50], xmm5
00007cd93bdd6d00  vmovaps [rsp+0x60], xmm7
00007cd93bdd6d06  vmovaps [rsp+0x70], xmm8
00007cd93bdd6d0c  vmovaps [rsp+0x80], xmm9
00007cd93bdd6d15  vmovaps [rsp+0x90], xmm10
00007cd93bdd6d1e  vmovaps [rsp+0xA0], xmm11
00007cd93bdd6d27  vmovaps [rsp+0xB0], xmm12
00007cd93bdd6d30  vmovaps [rsp+0xC0], xmm13
00007cd93bdd6d39  vmovaps [rsp+0xD0], xmm14
00007cd93bdd6d42  vmovaps [rsp+0xE0], xmm15
00007cd93bdd6d4b  sub rsp, 0x30
00007cd93bdd6d4f  movaps [rsp], xmm6
00007cd93bdd6d53  movaps [rsp+0x10], xmm12
00007cd93bdd6d59  movaps [rsp+0x20], xmm11
00007cd93bdd6d5f  lea rdi, [rsp]
00007cd93bdd6d63  mov esi, 0x00
00007cd93bdd6d68  mov rax, 0x64A581057530
00007cd93bdd6d72  call rax
00007cd93bdd6d74  movaps xmm6, [rsp]
00007cd93bdd6d78  add rsp, 0x30
00007cd93bdd6d7c  vmovaps xmm0, [rsp]
00007cd93bdd6d81  vmovaps xmm1, [rsp+0x10]
00007cd93bdd6d87  vmovaps xmm2, [rsp+0x20]
00007cd93bdd6d8d  vmovaps xmm3, [rsp+0x30]
00007cd93bdd6d93  vmovaps xmm4, [rsp+0x40]
00007cd93bdd6d99  vmovaps xmm5, [rsp+0x50]
00007cd93bdd6d9f  vmovaps xmm7, [rsp+0x60]
00007cd93bdd6da5  vmovaps xmm8, [rsp+0x70]
00007cd93bdd6dab  vmovaps xmm9, [rsp+0x80]
00007cd93bdd6db4  vmovaps xmm10, [rsp+0x90]
00007cd93bdd6dbd  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd6dc6  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd6dcf  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd6dd8  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd6de1  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd6dea  add rsp, 0xF0
00007cd93bdd6df1  pop r11
00007cd93bdd6df3  pop r10
00007cd93bdd6df5  pop r9
00007cd93bdd6df7  pop r8
00007cd93bdd6df9  pop rsi
00007cd93bdd6dfa  pop rdi
00007cd93bdd6dfb  pop rdx
00007cd93bdd6dfc  pop rcx
00007cd93bdd6dfd  pop rax
00007cd93bdd6dfe  add rsp, 0x08
00007cd93bdd6e02  jmp 0x00007CD93BDD5A27
00007cd93bdd6e07  sub rsp, 0x08
00007cd93bdd6e0b  push rax
00007cd93bdd6e0c  push rcx
00007cd93bdd6e0d  push rdx
00007cd93bdd6e0e  push rdi
00007cd93bdd6e0f  push rsi
00007cd93bdd6e10  push r8
00007cd93bdd6e12  push r9
00007cd93bdd6e14  push r10
00007cd93bdd6e16  push r11
00007cd93bdd6e18  sub rsp, 0xF0
00007cd93bdd6e1f  vmovaps [rsp], xmm0
00007cd93bdd6e24  vmovaps [rsp+0x10], xmm1
00007cd93bdd6e2a  vmovaps [rsp+0x20], xmm2
00007cd93bdd6e30  vmovaps [rsp+0x30], xmm4
00007cd93bdd6e36  vmovaps [rsp+0x40], xmm5
00007cd93bdd6e3c  vmovaps [rsp+0x50], xmm6
00007cd93bdd6e42  vmovaps [rsp+0x60], xmm7
00007cd93bdd6e48  vmovaps [rsp+0x70], xmm8
00007cd93bdd6e4e  vmovaps [rsp+0x80], xmm9
00007cd93bdd6e57  vmovaps [rsp+0x90], xmm10
00007cd93bdd6e60  vmovaps [rsp+0xA0], xmm11
00007cd93bdd6e69  vmovaps [rsp+0xB0], xmm12
00007cd93bdd6e72  vmovaps [rsp+0xC0], xmm13
00007cd93bdd6e7b  vmovaps [rsp+0xD0], xmm14
00007cd93bdd6e84  vmovaps [rsp+0xE0], xmm15
00007cd93bdd6e8d  sub rsp, 0x30
00007cd93bdd6e91  movaps [rsp], xmm3
00007cd93bdd6e95  movaps [rsp+0x10], xmm5
00007cd93bdd6e9a  movaps [rsp+0x20], xmm4
00007cd93bdd6e9f  lea rdi, [rsp]
00007cd93bdd6ea3  mov esi, 0x00
00007cd93bdd6ea8  mov rax, 0x64A581057530
00007cd93bdd6eb2  call rax
00007cd93bdd6eb4  movaps xmm3, [rsp]
00007cd93bdd6eb8  add rsp, 0x30
00007cd93bdd6ebc  vmovaps xmm0, [rsp]
00007cd93bdd6ec1  vmovaps xmm1, [rsp+0x10]
00007cd93bdd6ec7  vmovaps xmm2, [rsp+0x20]
00007cd93bdd6ecd  vmovaps xmm4, [rsp+0x30]
00007cd93bdd6ed3  vmovaps xmm5, [rsp+0x40]
00007cd93bdd6ed9  vmovaps xmm6, [rsp+0x50]
00007cd93bdd6edf  vmovaps xmm7, [rsp+0x60]
00007cd93bdd6ee5  vmovaps xmm8, [rsp+0x70]
00007cd93bdd6eeb  vmovaps xmm9, [rsp+0x80]
00007cd93bdd6ef4  vmovaps xmm10, [rsp+0x90]
00007cd93bdd6efd  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd6f06  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd6f0f  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd6f18  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd6f21  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd6f2a  add rsp, 0xF0
00007cd93bdd6f31  pop r11
00007cd93bdd6f33  pop r10
00007cd93bdd6f35  pop r9
00007cd93bdd6f37  pop r8
00007cd93bdd6f39  pop rsi
00007cd93bdd6f3a  pop rdi
00007cd93bdd6f3b  pop rdx
00007cd93bdd6f3c  pop rcx
00007cd93bdd6f3d  pop rax
00007cd93bdd6f3e  add rsp, 0x08
00007cd93bdd6f42  jmp 0x00007CD93BDD5A88
00007cd93bdd6f47  sub rsp, 0x08
00007cd93bdd6f4b  push rax
00007cd93bdd6f4c  push rcx
00007cd93bdd6f4d  push rdx
00007cd93bdd6f4e  push rdi
00007cd93bdd6f4f  push rsi
00007cd93bdd6f50  push r8
00007cd93bdd6f52  push r9
00007cd93bdd6f54  push r10
00007cd93bdd6f56  push r11
00007cd93bdd6f58  sub rsp, 0xF0
00007cd93bdd6f5f  vmovaps [rsp], xmm0
00007cd93bdd6f64  vmovaps [rsp+0x10], xmm1
00007cd93bdd6f6a  vmovaps [rsp+0x20], xmm2
00007cd93bdd6f70  vmovaps [rsp+0x30], xmm3
00007cd93bdd6f76  vmovaps [rsp+0x40], xmm4
00007cd93bdd6f7c  vmovaps [rsp+0x50], xmm6
00007cd93bdd6f82  vmovaps [rsp+0x60], xmm7
00007cd93bdd6f88  vmovaps [rsp+0x70], xmm8
00007cd93bdd6f8e  vmovaps [rsp+0x80], xmm9
00007cd93bdd6f97  vmovaps [rsp+0x90], xmm10
00007cd93bdd6fa0  vmovaps [rsp+0xA0], xmm11
00007cd93bdd6fa9  vmovaps [rsp+0xB0], xmm12
00007cd93bdd6fb2  vmovaps [rsp+0xC0], xmm13
00007cd93bdd6fbb  vmovaps [rsp+0xD0], xmm14
00007cd93bdd6fc4  vmovaps [rsp+0xE0], xmm15
00007cd93bdd6fcd  sub rsp, 0x30
00007cd93bdd6fd1  movaps [rsp], xmm5
00007cd93bdd6fd5  movaps [rsp+0x10], xmm8
00007cd93bdd6fdb  movaps [rsp+0x20], xmm15
00007cd93bdd6fe1  lea rdi, [rsp]
00007cd93bdd6fe5  mov esi, 0x00
00007cd93bdd6fea  mov rax, 0x64A581057530
00007cd93bdd6ff4  call rax
00007cd93bdd6ff6  movaps xmm5, [rsp]
00007cd93bdd6ffa  add rsp, 0x30
00007cd93bdd6ffe  vmovaps xmm0, [rsp]
00007cd93bdd7003  vmovaps xmm1, [rsp+0x10]
00007cd93bdd7009  vmovaps xmm2, [rsp+0x20]
00007cd93bdd700f  vmovaps xmm3, [rsp+0x30]
00007cd93bdd7015  vmovaps xmm4, [rsp+0x40]
00007cd93bdd701b  vmovaps xmm6, [rsp+0x50]
00007cd93bdd7021  vmovaps xmm7, [rsp+0x60]
00007cd93bdd7027  vmovaps xmm8, [rsp+0x70]
00007cd93bdd702d  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7036  vmovaps xmm10, [rsp+0x90]
00007cd93bdd703f  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd7048  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd7051  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd705a  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd7063  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd706c  add rsp, 0xF0
00007cd93bdd7073  pop r11
00007cd93bdd7075  pop r10
00007cd93bdd7077  pop r9
00007cd93bdd7079  pop r8
00007cd93bdd707b  pop rsi
00007cd93bdd707c  pop rdi
00007cd93bdd707d  pop rdx
00007cd93bdd707e  pop rcx
00007cd93bdd707f  pop rax
00007cd93bdd7080  add rsp, 0x08
00007cd93bdd7084  jmp 0x00007CD93BDD5AC0
00007cd93bdd7089  sub rsp, 0x08
00007cd93bdd708d  push rax
00007cd93bdd708e  push rcx
00007cd93bdd708f  push rdx
00007cd93bdd7090  push rdi
00007cd93bdd7091  push rsi
00007cd93bdd7092  push r8
00007cd93bdd7094  push r9
00007cd93bdd7096  push r10
00007cd93bdd7098  push r11
00007cd93bdd709a  sub rsp, 0xF0
00007cd93bdd70a1  vmovaps [rsp], xmm0
00007cd93bdd70a6  vmovaps [rsp+0x10], xmm1
00007cd93bdd70ac  vmovaps [rsp+0x20], xmm2
00007cd93bdd70b2  vmovaps [rsp+0x30], xmm3
00007cd93bdd70b8  vmovaps [rsp+0x40], xmm5
00007cd93bdd70be  vmovaps [rsp+0x50], xmm6
00007cd93bdd70c4  vmovaps [rsp+0x60], xmm7
00007cd93bdd70ca  vmovaps [rsp+0x70], xmm8
00007cd93bdd70d0  vmovaps [rsp+0x80], xmm9
00007cd93bdd70d9  vmovaps [rsp+0x90], xmm10
00007cd93bdd70e2  vmovaps [rsp+0xA0], xmm11
00007cd93bdd70eb  vmovaps [rsp+0xB0], xmm12
00007cd93bdd70f4  vmovaps [rsp+0xC0], xmm13
00007cd93bdd70fd  vmovaps [rsp+0xD0], xmm14
00007cd93bdd7106  vmovaps [rsp+0xE0], xmm15
00007cd93bdd710f  sub rsp, 0x30
00007cd93bdd7113  movaps [rsp], xmm4
00007cd93bdd7117  movaps [rsp+0x10], xmm9
00007cd93bdd711d  movaps [rsp+0x20], xmm8
00007cd93bdd7123  lea rdi, [rsp]
00007cd93bdd7127  mov esi, 0x00
00007cd93bdd712c  mov rax, 0x64A581057530
00007cd93bdd7136  call rax
00007cd93bdd7138  movaps xmm4, [rsp]
00007cd93bdd713c  add rsp, 0x30
00007cd93bdd7140  vmovaps xmm0, [rsp]
00007cd93bdd7145  vmovaps xmm1, [rsp+0x10]
00007cd93bdd714b  vmovaps xmm2, [rsp+0x20]
00007cd93bdd7151  vmovaps xmm3, [rsp+0x30]
00007cd93bdd7157  vmovaps xmm5, [rsp+0x40]
00007cd93bdd715d  vmovaps xmm6, [rsp+0x50]
00007cd93bdd7163  vmovaps xmm7, [rsp+0x60]
00007cd93bdd7169  vmovaps xmm8, [rsp+0x70]
00007cd93bdd716f  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7178  vmovaps xmm10, [rsp+0x90]
00007cd93bdd7181  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd718a  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd7193  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd719c  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd71a5  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd71ae  add rsp, 0xF0
00007cd93bdd71b5  pop r11
00007cd93bdd71b7  pop r10
00007cd93bdd71b9  pop r9
00007cd93bdd71bb  pop r8
00007cd93bdd71bd  pop rsi
00007cd93bdd71be  pop rdi
00007cd93bdd71bf  pop rdx
00007cd93bdd71c0  pop rcx
00007cd93bdd71c1  pop rax
00007cd93bdd71c2  add rsp, 0x08
00007cd93bdd71c6  jmp 0x00007CD93BDD5AE1
00007cd93bdd71cb  sub rsp, 0x08
00007cd93bdd71cf  push rax
00007cd93bdd71d0  push rcx
00007cd93bdd71d1  push rdx
00007cd93bdd71d2  push rdi
00007cd93bdd71d3  push rsi
00007cd93bdd71d4  push r8
00007cd93bdd71d6  push r9
00007cd93bdd71d8  push r10
00007cd93bdd71da  push r11
00007cd93bdd71dc  sub rsp, 0xF0
00007cd93bdd71e3  vmovaps [rsp], xmm0
00007cd93bdd71e8  vmovaps [rsp+0x10], xmm1
00007cd93bdd71ee  vmovaps [rsp+0x20], xmm2
00007cd93bdd71f4  vmovaps [rsp+0x30], xmm3
00007cd93bdd71fa  vmovaps [rsp+0x40], xmm4
00007cd93bdd7200  vmovaps [rsp+0x50], xmm5
00007cd93bdd7206  vmovaps [rsp+0x60], xmm6
00007cd93bdd720c  vmovaps [rsp+0x70], xmm7
00007cd93bdd7212  vmovaps [rsp+0x80], xmm8
00007cd93bdd721b  vmovaps [rsp+0x90], xmm10
00007cd93bdd7224  vmovaps [rsp+0xA0], xmm11
00007cd93bdd722d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd7236  vmovaps [rsp+0xC0], xmm13
00007cd93bdd723f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd7248  vmovaps [rsp+0xE0], xmm15
00007cd93bdd7251  sub rsp, 0x30
00007cd93bdd7255  movaps [rsp], xmm9
00007cd93bdd725a  movaps [rsp+0x10], xmm10
00007cd93bdd7260  movaps [rsp+0x20], xmm8
00007cd93bdd7266  lea rdi, [rsp]
00007cd93bdd726a  mov esi, 0x00
00007cd93bdd726f  mov rax, 0x64A581057530
00007cd93bdd7279  call rax
00007cd93bdd727b  movaps xmm9, [rsp]
00007cd93bdd7280  add rsp, 0x30
00007cd93bdd7284  vmovaps xmm0, [rsp]
00007cd93bdd7289  vmovaps xmm1, [rsp+0x10]
00007cd93bdd728f  vmovaps xmm2, [rsp+0x20]
00007cd93bdd7295  vmovaps xmm3, [rsp+0x30]
00007cd93bdd729b  vmovaps xmm4, [rsp+0x40]
00007cd93bdd72a1  vmovaps xmm5, [rsp+0x50]
00007cd93bdd72a7  vmovaps xmm6, [rsp+0x60]
00007cd93bdd72ad  vmovaps xmm7, [rsp+0x70]
00007cd93bdd72b3  vmovaps xmm8, [rsp+0x80]
00007cd93bdd72bc  vmovaps xmm10, [rsp+0x90]
00007cd93bdd72c5  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd72ce  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd72d7  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd72e0  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd72e9  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd72f2  add rsp, 0xF0
00007cd93bdd72f9  pop r11
00007cd93bdd72fb  pop r10
00007cd93bdd72fd  pop r9
00007cd93bdd72ff  pop r8
00007cd93bdd7301  pop rsi
00007cd93bdd7302  pop rdi
00007cd93bdd7303  pop rdx
00007cd93bdd7304  pop rcx
00007cd93bdd7305  pop rax
00007cd93bdd7306  add rsp, 0x08
00007cd93bdd730a  jmp 0x00007CD93BDD5AFB
00007cd93bdd730f  call 0x00007CD93BCD64F0
00007cd93bdd7314  jmp 0x00007CD93BDD5C15
00007cd93bdd7319  call 0x00007CD93BCD64F0
00007cd93bdd731e  jmp 0x00007CD93BDD5C2B
00007cd93bdd7323  sub rsp, 0x08
00007cd93bdd7327  push rax
00007cd93bdd7328  push rcx
00007cd93bdd7329  push rdx
00007cd93bdd732a  push rdi
00007cd93bdd732b  push rsi
00007cd93bdd732c  push r8
00007cd93bdd732e  push r9
00007cd93bdd7330  push r10
00007cd93bdd7332  push r11
00007cd93bdd7334  sub rsp, 0xF0
00007cd93bdd733b  vmovaps [rsp], xmm0
00007cd93bdd7340  vmovaps [rsp+0x10], xmm2
00007cd93bdd7346  vmovaps [rsp+0x20], xmm3
00007cd93bdd734c  vmovaps [rsp+0x30], xmm4
00007cd93bdd7352  vmovaps [rsp+0x40], xmm5
00007cd93bdd7358  vmovaps [rsp+0x50], xmm6
00007cd93bdd735e  vmovaps [rsp+0x60], xmm7
00007cd93bdd7364  vmovaps [rsp+0x70], xmm8
00007cd93bdd736a  vmovaps [rsp+0x80], xmm9
00007cd93bdd7373  vmovaps [rsp+0x90], xmm10
00007cd93bdd737c  vmovaps [rsp+0xA0], xmm11
00007cd93bdd7385  vmovaps [rsp+0xB0], xmm12
00007cd93bdd738e  vmovaps [rsp+0xC0], xmm13
00007cd93bdd7397  vmovaps [rsp+0xD0], xmm14
00007cd93bdd73a0  vmovaps [rsp+0xE0], xmm15
00007cd93bdd73a9  sub rsp, 0x30
00007cd93bdd73ad  movaps [rsp], xmm1
00007cd93bdd73b1  movaps [rsp+0x10], xmm6
00007cd93bdd73b6  movaps [rsp+0x20], xmm15
00007cd93bdd73bc  lea rdi, [rsp]
00007cd93bdd73c0  mov esi, 0x00
00007cd93bdd73c5  mov rax, 0x64A581057530
00007cd93bdd73cf  call rax
00007cd93bdd73d1  movaps xmm1, [rsp]
00007cd93bdd73d5  add rsp, 0x30
00007cd93bdd73d9  vmovaps xmm0, [rsp]
00007cd93bdd73de  vmovaps xmm2, [rsp+0x10]
00007cd93bdd73e4  vmovaps xmm3, [rsp+0x20]
00007cd93bdd73ea  vmovaps xmm4, [rsp+0x30]
00007cd93bdd73f0  vmovaps xmm5, [rsp+0x40]
00007cd93bdd73f6  vmovaps xmm6, [rsp+0x50]
00007cd93bdd73fc  vmovaps xmm7, [rsp+0x60]
00007cd93bdd7402  vmovaps xmm8, [rsp+0x70]
00007cd93bdd7408  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7411  vmovaps xmm10, [rsp+0x90]
00007cd93bdd741a  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd7423  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd742c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd7435  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd743e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7447  add rsp, 0xF0
00007cd93bdd744e  pop r11
00007cd93bdd7450  pop r10
00007cd93bdd7452  pop r9
00007cd93bdd7454  pop r8
00007cd93bdd7456  pop rsi
00007cd93bdd7457  pop rdi
00007cd93bdd7458  pop rdx
00007cd93bdd7459  pop rcx
00007cd93bdd745a  pop rax
00007cd93bdd745b  add rsp, 0x08
00007cd93bdd745f  jmp 0x00007CD93BDD5C68
00007cd93bdd7464  call 0x00007CD93BCE5820
00007cd93bdd7469  jmp 0x00007CD93BDD5C75
00007cd93bdd746e  sub rsp, 0x08
00007cd93bdd7472  push rax
00007cd93bdd7473  push rcx
00007cd93bdd7474  push rdx
00007cd93bdd7475  push rdi
00007cd93bdd7476  push rsi
00007cd93bdd7477  push r8
00007cd93bdd7479  push r9
00007cd93bdd747b  push r10
00007cd93bdd747d  push r11
00007cd93bdd747f  sub rsp, 0xF0
00007cd93bdd7486  vmovaps [rsp], xmm0
00007cd93bdd748b  vmovaps [rsp+0x10], xmm1
00007cd93bdd7491  vmovaps [rsp+0x20], xmm2
00007cd93bdd7497  vmovaps [rsp+0x30], xmm3
00007cd93bdd749d  vmovaps [rsp+0x40], xmm4
00007cd93bdd74a3  vmovaps [rsp+0x50], xmm5
00007cd93bdd74a9  vmovaps [rsp+0x60], xmm6
00007cd93bdd74af  vmovaps [rsp+0x70], xmm7
00007cd93bdd74b5  vmovaps [rsp+0x80], xmm8
00007cd93bdd74be  vmovaps [rsp+0x90], xmm9
00007cd93bdd74c7  vmovaps [rsp+0xA0], xmm10
00007cd93bdd74d0  vmovaps [rsp+0xB0], xmm11
00007cd93bdd74d9  vmovaps [rsp+0xC0], xmm12
00007cd93bdd74e2  vmovaps [rsp+0xD0], xmm13
00007cd93bdd74eb  vmovaps [rsp+0xE0], xmm15
00007cd93bdd74f4  sub rsp, 0x30
00007cd93bdd74f8  movaps [rsp], xmm14
00007cd93bdd74fd  movaps [rsp+0x10], xmm4
00007cd93bdd7502  movaps [rsp+0x20], xmm3
00007cd93bdd7507  lea rdi, [rsp]
00007cd93bdd750b  mov esi, 0x00
00007cd93bdd7510  mov rax, 0x64A581057530
00007cd93bdd751a  call rax
00007cd93bdd751c  movaps xmm14, [rsp]
00007cd93bdd7521  add rsp, 0x30
00007cd93bdd7525  vmovaps xmm0, [rsp]
00007cd93bdd752a  vmovaps xmm1, [rsp+0x10]
00007cd93bdd7530  vmovaps xmm2, [rsp+0x20]
00007cd93bdd7536  vmovaps xmm3, [rsp+0x30]
00007cd93bdd753c  vmovaps xmm4, [rsp+0x40]
00007cd93bdd7542  vmovaps xmm5, [rsp+0x50]
00007cd93bdd7548  vmovaps xmm6, [rsp+0x60]
00007cd93bdd754e  vmovaps xmm7, [rsp+0x70]
00007cd93bdd7554  vmovaps xmm8, [rsp+0x80]
00007cd93bdd755d  vmovaps xmm9, [rsp+0x90]
00007cd93bdd7566  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd756f  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd7578  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd7581  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd758a  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7593  add rsp, 0xF0
00007cd93bdd759a  pop r11
00007cd93bdd759c  pop r10
00007cd93bdd759e  pop r9
00007cd93bdd75a0  pop r8
00007cd93bdd75a2  pop rsi
00007cd93bdd75a3  pop rdi
00007cd93bdd75a4  pop rdx
00007cd93bdd75a5  pop rcx
00007cd93bdd75a6  pop rax
00007cd93bdd75a7  add rsp, 0x08
00007cd93bdd75ab  jmp 0x00007CD93BDD5C8F
00007cd93bdd75b0  sub rsp, 0x08
00007cd93bdd75b4  push rax
00007cd93bdd75b5  push rcx
00007cd93bdd75b6  push rdx
00007cd93bdd75b7  push rdi
00007cd93bdd75b8  push rsi
00007cd93bdd75b9  push r8
00007cd93bdd75bb  push r9
00007cd93bdd75bd  push r10
00007cd93bdd75bf  push r11
00007cd93bdd75c1  sub rsp, 0xF0
00007cd93bdd75c8  vmovaps [rsp], xmm0
00007cd93bdd75cd  vmovaps [rsp+0x10], xmm1
00007cd93bdd75d3  vmovaps [rsp+0x20], xmm2
00007cd93bdd75d9  vmovaps [rsp+0x30], xmm3
00007cd93bdd75df  vmovaps [rsp+0x40], xmm4
00007cd93bdd75e5  vmovaps [rsp+0x50], xmm5
00007cd93bdd75eb  vmovaps [rsp+0x60], xmm7
00007cd93bdd75f1  vmovaps [rsp+0x70], xmm8
00007cd93bdd75f7  vmovaps [rsp+0x80], xmm9
00007cd93bdd7600  vmovaps [rsp+0x90], xmm10
00007cd93bdd7609  vmovaps [rsp+0xA0], xmm11
00007cd93bdd7612  vmovaps [rsp+0xB0], xmm12
00007cd93bdd761b  vmovaps [rsp+0xC0], xmm13
00007cd93bdd7624  vmovaps [rsp+0xD0], xmm14
00007cd93bdd762d  vmovaps [rsp+0xE0], xmm15
00007cd93bdd7636  sub rsp, 0x30
00007cd93bdd763a  movaps [rsp], xmm6
00007cd93bdd763e  movaps [rsp+0x10], xmm9
00007cd93bdd7644  movaps [rsp+0x20], xmm7
00007cd93bdd7649  lea rdi, [rsp]
00007cd93bdd764d  mov esi, 0x00
00007cd93bdd7652  mov rax, 0x64A581057530
00007cd93bdd765c  call rax
00007cd93bdd765e  movaps xmm6, [rsp]
00007cd93bdd7662  add rsp, 0x30
00007cd93bdd7666  vmovaps xmm0, [rsp]
00007cd93bdd766b  vmovaps xmm1, [rsp+0x10]
00007cd93bdd7671  vmovaps xmm2, [rsp+0x20]
00007cd93bdd7677  vmovaps xmm3, [rsp+0x30]
00007cd93bdd767d  vmovaps xmm4, [rsp+0x40]
00007cd93bdd7683  vmovaps xmm5, [rsp+0x50]
00007cd93bdd7689  vmovaps xmm7, [rsp+0x60]
00007cd93bdd768f  vmovaps xmm8, [rsp+0x70]
00007cd93bdd7695  vmovaps xmm9, [rsp+0x80]
00007cd93bdd769e  vmovaps xmm10, [rsp+0x90]
00007cd93bdd76a7  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd76b0  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd76b9  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd76c2  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd76cb  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd76d4  add rsp, 0xF0
00007cd93bdd76db  pop r11
00007cd93bdd76dd  pop r10
00007cd93bdd76df  pop r9
00007cd93bdd76e1  pop r8
00007cd93bdd76e3  pop rsi
00007cd93bdd76e4  pop rdi
00007cd93bdd76e5  pop rdx
00007cd93bdd76e6  pop rcx
00007cd93bdd76e7  pop rax
00007cd93bdd76e8  add rsp, 0x08
00007cd93bdd76ec  jmp 0x00007CD93BDD5CA7
00007cd93bdd76f1  sub rsp, 0x08
00007cd93bdd76f5  push rax
00007cd93bdd76f6  push rcx
00007cd93bdd76f7  push rdx
00007cd93bdd76f8  push rdi
00007cd93bdd76f9  push rsi
00007cd93bdd76fa  push r8
00007cd93bdd76fc  push r9
00007cd93bdd76fe  push r10
00007cd93bdd7700  push r11
00007cd93bdd7702  sub rsp, 0xF0
00007cd93bdd7709  vmovaps [rsp], xmm0
00007cd93bdd770e  vmovaps [rsp+0x10], xmm1
00007cd93bdd7714  vmovaps [rsp+0x20], xmm2
00007cd93bdd771a  vmovaps [rsp+0x30], xmm3
00007cd93bdd7720  vmovaps [rsp+0x40], xmm4
00007cd93bdd7726  vmovaps [rsp+0x50], xmm5
00007cd93bdd772c  vmovaps [rsp+0x60], xmm6
00007cd93bdd7732  vmovaps [rsp+0x70], xmm8
00007cd93bdd7738  vmovaps [rsp+0x80], xmm9
00007cd93bdd7741  vmovaps [rsp+0x90], xmm10
00007cd93bdd774a  vmovaps [rsp+0xA0], xmm11
00007cd93bdd7753  vmovaps [rsp+0xB0], xmm12
00007cd93bdd775c  vmovaps [rsp+0xC0], xmm13
00007cd93bdd7765  vmovaps [rsp+0xD0], xmm14
00007cd93bdd776e  vmovaps [rsp+0xE0], xmm15
00007cd93bdd7777  sub rsp, 0x30
00007cd93bdd777b  movaps [rsp], xmm7
00007cd93bdd777f  movaps [rsp+0x10], xmm4
00007cd93bdd7784  movaps [rsp+0x20], xmm9
00007cd93bdd778a  lea rdi, [rsp]
00007cd93bdd778e  mov esi, 0x00
00007cd93bdd7793  mov rax, 0x64A581057530
00007cd93bdd779d  call rax
00007cd93bdd779f  movaps xmm7, [rsp]
00007cd93bdd77a3  add rsp, 0x30
00007cd93bdd77a7  vmovaps xmm0, [rsp]
00007cd93bdd77ac  vmovaps xmm1, [rsp+0x10]
00007cd93bdd77b2  vmovaps xmm2, [rsp+0x20]
00007cd93bdd77b8  vmovaps xmm3, [rsp+0x30]
00007cd93bdd77be  vmovaps xmm4, [rsp+0x40]
00007cd93bdd77c4  vmovaps xmm5, [rsp+0x50]
00007cd93bdd77ca  vmovaps xmm6, [rsp+0x60]
00007cd93bdd77d0  vmovaps xmm8, [rsp+0x70]
00007cd93bdd77d6  vmovaps xmm9, [rsp+0x80]
00007cd93bdd77df  vmovaps xmm10, [rsp+0x90]
00007cd93bdd77e8  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd77f1  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd77fa  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd7803  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd780c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7815  add rsp, 0xF0
00007cd93bdd781c  pop r11
00007cd93bdd781e  pop r10
00007cd93bdd7820  pop r9
00007cd93bdd7822  pop r8
00007cd93bdd7824  pop rsi
00007cd93bdd7825  pop rdi
00007cd93bdd7826  pop rdx
00007cd93bdd7827  pop rcx
00007cd93bdd7828  pop rax
00007cd93bdd7829  add rsp, 0x08
00007cd93bdd782d  jmp 0x00007CD93BDD5CD4
00007cd93bdd7832  sub rsp, 0x08
00007cd93bdd7836  push rax
00007cd93bdd7837  push rcx
00007cd93bdd7838  push rdx
00007cd93bdd7839  push rdi
00007cd93bdd783a  push rsi
00007cd93bdd783b  push r8
00007cd93bdd783d  push r9
00007cd93bdd783f  push r10
00007cd93bdd7841  push r11
00007cd93bdd7843  sub rsp, 0xF0
00007cd93bdd784a  vmovaps [rsp], xmm0
00007cd93bdd784f  vmovaps [rsp+0x10], xmm1
00007cd93bdd7855  vmovaps [rsp+0x20], xmm2
00007cd93bdd785b  vmovaps [rsp+0x30], xmm3
00007cd93bdd7861  vmovaps [rsp+0x40], xmm5
00007cd93bdd7867  vmovaps [rsp+0x50], xmm6
00007cd93bdd786d  vmovaps [rsp+0x60], xmm7
00007cd93bdd7873  vmovaps [rsp+0x70], xmm8
00007cd93bdd7879  vmovaps [rsp+0x80], xmm9
00007cd93bdd7882  vmovaps [rsp+0x90], xmm10
00007cd93bdd788b  vmovaps [rsp+0xA0], xmm11
00007cd93bdd7894  vmovaps [rsp+0xB0], xmm12
00007cd93bdd789d  vmovaps [rsp+0xC0], xmm13
00007cd93bdd78a6  vmovaps [rsp+0xD0], xmm14
00007cd93bdd78af  vmovaps [rsp+0xE0], xmm15
00007cd93bdd78b8  sub rsp, 0x30
00007cd93bdd78bc  movaps [rsp], xmm4
00007cd93bdd78c0  movaps [rsp+0x10], xmm15
00007cd93bdd78c6  movaps [rsp+0x20], xmm9
00007cd93bdd78cc  lea rdi, [rsp]
00007cd93bdd78d0  mov esi, 0x00
00007cd93bdd78d5  mov rax, 0x64A581057530
00007cd93bdd78df  call rax
00007cd93bdd78e1  movaps xmm4, [rsp]
00007cd93bdd78e5  add rsp, 0x30
00007cd93bdd78e9  vmovaps xmm0, [rsp]
00007cd93bdd78ee  vmovaps xmm1, [rsp+0x10]
00007cd93bdd78f4  vmovaps xmm2, [rsp+0x20]
00007cd93bdd78fa  vmovaps xmm3, [rsp+0x30]
00007cd93bdd7900  vmovaps xmm5, [rsp+0x40]
00007cd93bdd7906  vmovaps xmm6, [rsp+0x50]
00007cd93bdd790c  vmovaps xmm7, [rsp+0x60]
00007cd93bdd7912  vmovaps xmm8, [rsp+0x70]
00007cd93bdd7918  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7921  vmovaps xmm10, [rsp+0x90]
00007cd93bdd792a  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd7933  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd793c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd7945  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd794e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7957  add rsp, 0xF0
00007cd93bdd795e  pop r11
00007cd93bdd7960  pop r10
00007cd93bdd7962  pop r9
00007cd93bdd7964  pop r8
00007cd93bdd7966  pop rsi
00007cd93bdd7967  pop rdi
00007cd93bdd7968  pop rdx
00007cd93bdd7969  pop rcx
00007cd93bdd796a  pop rax
00007cd93bdd796b  add rsp, 0x08
00007cd93bdd796f  jmp 0x00007CD93BDD5CF9
00007cd93bdd7974  call 0x00007CD93BCE5820
00007cd93bdd7979  jmp 0x00007CD93BDD5D06
00007cd93bdd797e  sub rsp, 0x08
00007cd93bdd7982  push rax
00007cd93bdd7983  push rcx
00007cd93bdd7984  push rdx
00007cd93bdd7985  push rdi
00007cd93bdd7986  push rsi
00007cd93bdd7987  push r8
00007cd93bdd7989  push r9
00007cd93bdd798b  push r10
00007cd93bdd798d  push r11
00007cd93bdd798f  sub rsp, 0xF0
00007cd93bdd7996  vmovaps [rsp], xmm0
00007cd93bdd799b  vmovaps [rsp+0x10], xmm1
00007cd93bdd79a1  vmovaps [rsp+0x20], xmm2
00007cd93bdd79a7  vmovaps [rsp+0x30], xmm4
00007cd93bdd79ad  vmovaps [rsp+0x40], xmm5
00007cd93bdd79b3  vmovaps [rsp+0x50], xmm6
00007cd93bdd79b9  vmovaps [rsp+0x60], xmm7
00007cd93bdd79bf  vmovaps [rsp+0x70], xmm8
00007cd93bdd79c5  vmovaps [rsp+0x80], xmm9
00007cd93bdd79ce  vmovaps [rsp+0x90], xmm10
00007cd93bdd79d7  vmovaps [rsp+0xA0], xmm11
00007cd93bdd79e0  vmovaps [rsp+0xB0], xmm12
00007cd93bdd79e9  vmovaps [rsp+0xC0], xmm13
00007cd93bdd79f2  vmovaps [rsp+0xD0], xmm14
00007cd93bdd79fb  vmovaps [rsp+0xE0], xmm15
00007cd93bdd7a04  sub rsp, 0x30
00007cd93bdd7a08  movaps [rsp], xmm3
00007cd93bdd7a0c  movaps [rsp+0x10], xmm1
00007cd93bdd7a11  movaps [rsp+0x20], xmm9
00007cd93bdd7a17  lea rdi, [rsp]
00007cd93bdd7a1b  mov esi, 0x00
00007cd93bdd7a20  mov rax, 0x64A581057530
00007cd93bdd7a2a  call rax
00007cd93bdd7a2c  movaps xmm3, [rsp]
00007cd93bdd7a30  add rsp, 0x30
00007cd93bdd7a34  vmovaps xmm0, [rsp]
00007cd93bdd7a39  vmovaps xmm1, [rsp+0x10]
00007cd93bdd7a3f  vmovaps xmm2, [rsp+0x20]
00007cd93bdd7a45  vmovaps xmm4, [rsp+0x30]
00007cd93bdd7a4b  vmovaps xmm5, [rsp+0x40]
00007cd93bdd7a51  vmovaps xmm6, [rsp+0x50]
00007cd93bdd7a57  vmovaps xmm7, [rsp+0x60]
00007cd93bdd7a5d  vmovaps xmm8, [rsp+0x70]
00007cd93bdd7a63  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7a6c  vmovaps xmm10, [rsp+0x90]
00007cd93bdd7a75  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd7a7e  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd7a87  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd7a90  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd7a99  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7aa2  add rsp, 0xF0
00007cd93bdd7aa9  pop r11
00007cd93bdd7aab  pop r10
00007cd93bdd7aad  pop r9
00007cd93bdd7aaf  pop r8
00007cd93bdd7ab1  pop rsi
00007cd93bdd7ab2  pop rdi
00007cd93bdd7ab3  pop rdx
00007cd93bdd7ab4  pop rcx
00007cd93bdd7ab5  pop rax
00007cd93bdd7ab6  add rsp, 0x08
00007cd93bdd7aba  jmp 0x00007CD93BDD5D43
00007cd93bdd7abf  sub rsp, 0x08
00007cd93bdd7ac3  push rax
00007cd93bdd7ac4  push rcx
00007cd93bdd7ac5  push rdx
00007cd93bdd7ac6  push rdi
00007cd93bdd7ac7  push rsi
00007cd93bdd7ac8  push r8
00007cd93bdd7aca  push r9
00007cd93bdd7acc  push r10
00007cd93bdd7ace  push r11
00007cd93bdd7ad0  sub rsp, 0xF0
00007cd93bdd7ad7  vmovaps [rsp], xmm0
00007cd93bdd7adc  vmovaps [rsp+0x10], xmm2
00007cd93bdd7ae2  vmovaps [rsp+0x20], xmm3
00007cd93bdd7ae8  vmovaps [rsp+0x30], xmm4
00007cd93bdd7aee  vmovaps [rsp+0x40], xmm5
00007cd93bdd7af4  vmovaps [rsp+0x50], xmm6
00007cd93bdd7afa  vmovaps [rsp+0x60], xmm7
00007cd93bdd7b00  vmovaps [rsp+0x70], xmm8
00007cd93bdd7b06  vmovaps [rsp+0x80], xmm9
00007cd93bdd7b0f  vmovaps [rsp+0x90], xmm10
00007cd93bdd7b18  vmovaps [rsp+0xA0], xmm11
00007cd93bdd7b21  vmovaps [rsp+0xB0], xmm12
00007cd93bdd7b2a  vmovaps [rsp+0xC0], xmm13
00007cd93bdd7b33  vmovaps [rsp+0xD0], xmm14
00007cd93bdd7b3c  vmovaps [rsp+0xE0], xmm15
00007cd93bdd7b45  sub rsp, 0x30
00007cd93bdd7b49  movaps [rsp], xmm1
00007cd93bdd7b4d  movaps [rsp+0x10], xmm15
00007cd93bdd7b53  movaps [rsp+0x20], xmm9
00007cd93bdd7b59  lea rdi, [rsp]
00007cd93bdd7b5d  mov esi, 0x00
00007cd93bdd7b62  mov rax, 0x64A581057530
00007cd93bdd7b6c  call rax
00007cd93bdd7b6e  movaps xmm1, [rsp]
00007cd93bdd7b72  add rsp, 0x30
00007cd93bdd7b76  vmovaps xmm0, [rsp]
00007cd93bdd7b7b  vmovaps xmm2, [rsp+0x10]
00007cd93bdd7b81  vmovaps xmm3, [rsp+0x20]
00007cd93bdd7b87  vmovaps xmm4, [rsp+0x30]
00007cd93bdd7b8d  vmovaps xmm5, [rsp+0x40]
00007cd93bdd7b93  vmovaps xmm6, [rsp+0x50]
00007cd93bdd7b99  vmovaps xmm7, [rsp+0x60]
00007cd93bdd7b9f  vmovaps xmm8, [rsp+0x70]
00007cd93bdd7ba5  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7bae  vmovaps xmm10, [rsp+0x90]
00007cd93bdd7bb7  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd7bc0  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd7bc9  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd7bd2  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd7bdb  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7be4  add rsp, 0xF0
00007cd93bdd7beb  pop r11
00007cd93bdd7bed  pop r10
00007cd93bdd7bef  pop r9
00007cd93bdd7bf1  pop r8
00007cd93bdd7bf3  pop rsi
00007cd93bdd7bf4  pop rdi
00007cd93bdd7bf5  pop rdx
00007cd93bdd7bf6  pop rcx
00007cd93bdd7bf7  pop rax
00007cd93bdd7bf8  add rsp, 0x08
00007cd93bdd7bfc  jmp 0x00007CD93BDD5DCB
00007cd93bdd7c01  call 0x00007CD93BCE5820
00007cd93bdd7c06  jmp 0x00007CD93BDD5DD8
00007cd93bdd7c0b  sub rsp, 0x08
00007cd93bdd7c0f  push rax
00007cd93bdd7c10  push rcx
00007cd93bdd7c11  push rdx
00007cd93bdd7c12  push rdi
00007cd93bdd7c13  push rsi
00007cd93bdd7c14  push r8
00007cd93bdd7c16  push r9
00007cd93bdd7c18  push r10
00007cd93bdd7c1a  push r11
00007cd93bdd7c1c  sub rsp, 0xF0
00007cd93bdd7c23  vmovaps [rsp], xmm0
00007cd93bdd7c28  vmovaps [rsp+0x10], xmm2
00007cd93bdd7c2e  vmovaps [rsp+0x20], xmm3
00007cd93bdd7c34  vmovaps [rsp+0x30], xmm4
00007cd93bdd7c3a  vmovaps [rsp+0x40], xmm5
00007cd93bdd7c40  vmovaps [rsp+0x50], xmm6
00007cd93bdd7c46  vmovaps [rsp+0x60], xmm7
00007cd93bdd7c4c  vmovaps [rsp+0x70], xmm8
00007cd93bdd7c52  vmovaps [rsp+0x80], xmm9
00007cd93bdd7c5b  vmovaps [rsp+0x90], xmm10
00007cd93bdd7c64  vmovaps [rsp+0xA0], xmm11
00007cd93bdd7c6d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd7c76  vmovaps [rsp+0xC0], xmm13
00007cd93bdd7c7f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd7c88  vmovaps [rsp+0xE0], xmm15
00007cd93bdd7c91  sub rsp, 0x30
00007cd93bdd7c95  movaps [rsp], xmm1
00007cd93bdd7c99  movaps [rsp+0x10], xmm5
00007cd93bdd7c9e  movaps [rsp+0x20], xmm7
00007cd93bdd7ca3  lea rdi, [rsp]
00007cd93bdd7ca7  mov esi, 0x00
00007cd93bdd7cac  mov rax, 0x64A581057530
00007cd93bdd7cb6  call rax
00007cd93bdd7cb8  movaps xmm1, [rsp]
00007cd93bdd7cbc  add rsp, 0x30
00007cd93bdd7cc0  vmovaps xmm0, [rsp]
00007cd93bdd7cc5  vmovaps xmm2, [rsp+0x10]
00007cd93bdd7ccb  vmovaps xmm3, [rsp+0x20]
00007cd93bdd7cd1  vmovaps xmm4, [rsp+0x30]
00007cd93bdd7cd7  vmovaps xmm5, [rsp+0x40]
00007cd93bdd7cdd  vmovaps xmm6, [rsp+0x50]
00007cd93bdd7ce3  vmovaps xmm7, [rsp+0x60]
00007cd93bdd7ce9  vmovaps xmm8, [rsp+0x70]
00007cd93bdd7cef  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7cf8  vmovaps xmm10, [rsp+0x90]
00007cd93bdd7d01  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd7d0a  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd7d13  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd7d1c  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd7d25  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7d2e  add rsp, 0xF0
00007cd93bdd7d35  pop r11
00007cd93bdd7d37  pop r10
00007cd93bdd7d39  pop r9
00007cd93bdd7d3b  pop r8
00007cd93bdd7d3d  pop rsi
00007cd93bdd7d3e  pop rdi
00007cd93bdd7d3f  pop rdx
00007cd93bdd7d40  pop rcx
00007cd93bdd7d41  pop rax
00007cd93bdd7d42  add rsp, 0x08
00007cd93bdd7d46  jmp 0x00007CD93BDD5E7D
00007cd93bdd7d4b  sub rsp, 0x08
00007cd93bdd7d4f  push rax
00007cd93bdd7d50  push rcx
00007cd93bdd7d51  push rdx
00007cd93bdd7d52  push rdi
00007cd93bdd7d53  push rsi
00007cd93bdd7d54  push r8
00007cd93bdd7d56  push r9
00007cd93bdd7d58  push r10
00007cd93bdd7d5a  push r11
00007cd93bdd7d5c  sub rsp, 0xF0
00007cd93bdd7d63  vmovaps [rsp], xmm0
00007cd93bdd7d68  vmovaps [rsp+0x10], xmm1
00007cd93bdd7d6e  vmovaps [rsp+0x20], xmm2
00007cd93bdd7d74  vmovaps [rsp+0x30], xmm3
00007cd93bdd7d7a  vmovaps [rsp+0x40], xmm4
00007cd93bdd7d80  vmovaps [rsp+0x50], xmm5
00007cd93bdd7d86  vmovaps [rsp+0x60], xmm6
00007cd93bdd7d8c  vmovaps [rsp+0x70], xmm8
00007cd93bdd7d92  vmovaps [rsp+0x80], xmm9
00007cd93bdd7d9b  vmovaps [rsp+0x90], xmm10
00007cd93bdd7da4  vmovaps [rsp+0xA0], xmm11
00007cd93bdd7dad  vmovaps [rsp+0xB0], xmm12
00007cd93bdd7db6  vmovaps [rsp+0xC0], xmm13
00007cd93bdd7dbf  vmovaps [rsp+0xD0], xmm14
00007cd93bdd7dc8  vmovaps [rsp+0xE0], xmm15
00007cd93bdd7dd1  sub rsp, 0x30
00007cd93bdd7dd5  movaps [rsp], xmm7
00007cd93bdd7dd9  movaps [rsp+0x10], xmm5
00007cd93bdd7dde  movaps [rsp+0x20], xmm15
00007cd93bdd7de4  lea rdi, [rsp]
00007cd93bdd7de8  mov esi, 0x00
00007cd93bdd7ded  mov rax, 0x64A581057530
00007cd93bdd7df7  call rax
00007cd93bdd7df9  movaps xmm7, [rsp]
00007cd93bdd7dfd  add rsp, 0x30
00007cd93bdd7e01  vmovaps xmm0, [rsp]
00007cd93bdd7e06  vmovaps xmm1, [rsp+0x10]
00007cd93bdd7e0c  vmovaps xmm2, [rsp+0x20]
00007cd93bdd7e12  vmovaps xmm3, [rsp+0x30]
00007cd93bdd7e18  vmovaps xmm4, [rsp+0x40]
00007cd93bdd7e1e  vmovaps xmm5, [rsp+0x50]
00007cd93bdd7e24  vmovaps xmm6, [rsp+0x60]
00007cd93bdd7e2a  vmovaps xmm8, [rsp+0x70]
00007cd93bdd7e30  vmovaps xmm9, [rsp+0x80]
00007cd93bdd7e39  vmovaps xmm10, [rsp+0x90]
00007cd93bdd7e42  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd7e4b  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd7e54  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd7e5d  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd7e66  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd7e6f  add rsp, 0xF0
00007cd93bdd7e76  pop r11
00007cd93bdd7e78  pop r10
00007cd93bdd7e7a  pop r9
00007cd93bdd7e7c  pop r8
00007cd93bdd7e7e  pop rsi
00007cd93bdd7e7f  pop rdi
00007cd93bdd7e80  pop rdx
00007cd93bdd7e81  pop rcx
00007cd93bdd7e82  pop rax
00007cd93bdd7e83  add rsp, 0x08
00007cd93bdd7e87  jmp 0x00007CD93BDD5EB3
00007cd93bdd7e8c  call 0x00007CD93BCD64F0
00007cd93bdd7e91  jmp 0x00007CD93BDD5EC0
00007cd93bdd7e96  sub rsp, 0x08
00007cd93bdd7e9a  push rax
00007cd93bdd7e9b  push rcx
00007cd93bdd7e9c  push rdx
00007cd93bdd7e9d  push rdi
00007cd93bdd7e9e  push rsi
00007cd93bdd7e9f  push r8
00007cd93bdd7ea1  push r9
00007cd93bdd7ea3  push r10
00007cd93bdd7ea5  push r11
00007cd93bdd7ea7  sub rsp, 0xF0
00007cd93bdd7eae  vmovaps [rsp], xmm0
00007cd93bdd7eb3  vmovaps [rsp+0x10], xmm1
00007cd93bdd7eb9  vmovaps [rsp+0x20], xmm2
00007cd93bdd7ebf  vmovaps [rsp+0x30], xmm3
00007cd93bdd7ec5  vmovaps [rsp+0x40], xmm4
00007cd93bdd7ecb  vmovaps [rsp+0x50], xmm5
00007cd93bdd7ed1  vmovaps [rsp+0x60], xmm6
00007cd93bdd7ed7  vmovaps [rsp+0x70], xmm7
00007cd93bdd7edd  vmovaps [rsp+0x80], xmm8
00007cd93bdd7ee6  vmovaps [rsp+0x90], xmm9
00007cd93bdd7eef  vmovaps [rsp+0xA0], xmm10
00007cd93bdd7ef8  vmovaps [rsp+0xB0], xmm11
00007cd93bdd7f01  vmovaps [rsp+0xC0], xmm12
00007cd93bdd7f0a  vmovaps [rsp+0xD0], xmm13
00007cd93bdd7f13  vmovaps [rsp+0xE0], xmm14
00007cd93bdd7f1c  sub rsp, 0x30
00007cd93bdd7f20  movaps [rsp], xmm15
00007cd93bdd7f25  movaps [rsp+0x10], xmm5
00007cd93bdd7f2a  movaps [rsp+0x20], xmm3
00007cd93bdd7f2f  lea rdi, [rsp]
00007cd93bdd7f33  mov esi, 0x00
00007cd93bdd7f38  mov rax, 0x64A581057530
00007cd93bdd7f42  call rax
00007cd93bdd7f44  movaps xmm15, [rsp]
00007cd93bdd7f49  add rsp, 0x30
00007cd93bdd7f4d  vmovaps xmm0, [rsp]
00007cd93bdd7f52  vmovaps xmm1, [rsp+0x10]
00007cd93bdd7f58  vmovaps xmm2, [rsp+0x20]
00007cd93bdd7f5e  vmovaps xmm3, [rsp+0x30]
00007cd93bdd7f64  vmovaps xmm4, [rsp+0x40]
00007cd93bdd7f6a  vmovaps xmm5, [rsp+0x50]
00007cd93bdd7f70  vmovaps xmm6, [rsp+0x60]
00007cd93bdd7f76  vmovaps xmm7, [rsp+0x70]
00007cd93bdd7f7c  vmovaps xmm8, [rsp+0x80]
00007cd93bdd7f85  vmovaps xmm9, [rsp+0x90]
00007cd93bdd7f8e  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd7f97  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd7fa0  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd7fa9  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd7fb2  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd7fbb  add rsp, 0xF0
00007cd93bdd7fc2  pop r11
00007cd93bdd7fc4  pop r10
00007cd93bdd7fc6  pop r9
00007cd93bdd7fc8  pop r8
00007cd93bdd7fca  pop rsi
00007cd93bdd7fcb  pop rdi
00007cd93bdd7fcc  pop rdx
00007cd93bdd7fcd  pop rcx
00007cd93bdd7fce  pop rax
00007cd93bdd7fcf  add rsp, 0x08
00007cd93bdd7fd3  jmp 0x00007CD93BDD5EE6
00007cd93bdd7fd8  sub rsp, 0x08
00007cd93bdd7fdc  push rax
00007cd93bdd7fdd  push rcx
00007cd93bdd7fde  push rdx
00007cd93bdd7fdf  push rdi
00007cd93bdd7fe0  push rsi
00007cd93bdd7fe1  push r8
00007cd93bdd7fe3  push r9
00007cd93bdd7fe5  push r10
00007cd93bdd7fe7  push r11
00007cd93bdd7fe9  sub rsp, 0xF0
00007cd93bdd7ff0  vmovaps [rsp], xmm0
00007cd93bdd7ff5  vmovaps [rsp+0x10], xmm2
00007cd93bdd7ffb  vmovaps [rsp+0x20], xmm3
00007cd93bdd8001  vmovaps [rsp+0x30], xmm4
00007cd93bdd8007  vmovaps [rsp+0x40], xmm5
00007cd93bdd800d  vmovaps [rsp+0x50], xmm6
00007cd93bdd8013  vmovaps [rsp+0x60], xmm7
00007cd93bdd8019  vmovaps [rsp+0x70], xmm8
00007cd93bdd801f  vmovaps [rsp+0x80], xmm9
00007cd93bdd8028  vmovaps [rsp+0x90], xmm10
00007cd93bdd8031  vmovaps [rsp+0xA0], xmm11
00007cd93bdd803a  vmovaps [rsp+0xB0], xmm12
00007cd93bdd8043  vmovaps [rsp+0xC0], xmm13
00007cd93bdd804c  vmovaps [rsp+0xD0], xmm14
00007cd93bdd8055  vmovaps [rsp+0xE0], xmm15
00007cd93bdd805e  sub rsp, 0x30
00007cd93bdd8062  movaps [rsp], xmm1
00007cd93bdd8066  movaps [rsp+0x10], xmm5
00007cd93bdd806b  movaps [rsp+0x20], xmm4
00007cd93bdd8070  lea rdi, [rsp]
00007cd93bdd8074  mov esi, 0x00
00007cd93bdd8079  mov rax, 0x64A581057530
00007cd93bdd8083  call rax
00007cd93bdd8085  movaps xmm1, [rsp]
00007cd93bdd8089  add rsp, 0x30
00007cd93bdd808d  vmovaps xmm0, [rsp]
00007cd93bdd8092  vmovaps xmm2, [rsp+0x10]
00007cd93bdd8098  vmovaps xmm3, [rsp+0x20]
00007cd93bdd809e  vmovaps xmm4, [rsp+0x30]
00007cd93bdd80a4  vmovaps xmm5, [rsp+0x40]
00007cd93bdd80aa  vmovaps xmm6, [rsp+0x50]
00007cd93bdd80b0  vmovaps xmm7, [rsp+0x60]
00007cd93bdd80b6  vmovaps xmm8, [rsp+0x70]
00007cd93bdd80bc  vmovaps xmm9, [rsp+0x80]
00007cd93bdd80c5  vmovaps xmm10, [rsp+0x90]
00007cd93bdd80ce  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd80d7  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd80e0  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd80e9  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd80f2  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd80fb  add rsp, 0xF0
00007cd93bdd8102  pop r11
00007cd93bdd8104  pop r10
00007cd93bdd8106  pop r9
00007cd93bdd8108  pop r8
00007cd93bdd810a  pop rsi
00007cd93bdd810b  pop rdi
00007cd93bdd810c  pop rdx
00007cd93bdd810d  pop rcx
00007cd93bdd810e  pop rax
00007cd93bdd810f  add rsp, 0x08
00007cd93bdd8113  jmp 0x00007CD93BDD5F06
00007cd93bdd8118  sub rsp, 0x08
00007cd93bdd811c  push rax
00007cd93bdd811d  push rcx
00007cd93bdd811e  push rdx
00007cd93bdd811f  push rdi
00007cd93bdd8120  push rsi
00007cd93bdd8121  push r8
00007cd93bdd8123  push r9
00007cd93bdd8125  push r10
00007cd93bdd8127  push r11
00007cd93bdd8129  sub rsp, 0xF0
00007cd93bdd8130  vmovaps [rsp], xmm0
00007cd93bdd8135  vmovaps [rsp+0x10], xmm1
00007cd93bdd813b  vmovaps [rsp+0x20], xmm2
00007cd93bdd8141  vmovaps [rsp+0x30], xmm3
00007cd93bdd8147  vmovaps [rsp+0x40], xmm5
00007cd93bdd814d  vmovaps [rsp+0x50], xmm6
00007cd93bdd8153  vmovaps [rsp+0x60], xmm7
00007cd93bdd8159  vmovaps [rsp+0x70], xmm8
00007cd93bdd815f  vmovaps [rsp+0x80], xmm9
00007cd93bdd8168  vmovaps [rsp+0x90], xmm10
00007cd93bdd8171  vmovaps [rsp+0xA0], xmm11
00007cd93bdd817a  vmovaps [rsp+0xB0], xmm12
00007cd93bdd8183  vmovaps [rsp+0xC0], xmm13
00007cd93bdd818c  vmovaps [rsp+0xD0], xmm14
00007cd93bdd8195  vmovaps [rsp+0xE0], xmm15
00007cd93bdd819e  sub rsp, 0x30
00007cd93bdd81a2  movaps [rsp], xmm4
00007cd93bdd81a6  movaps [rsp+0x10], xmm3
00007cd93bdd81ab  movaps [rsp+0x20], xmm5
00007cd93bdd81b0  lea rdi, [rsp]
00007cd93bdd81b4  mov esi, 0x00
00007cd93bdd81b9  mov rax, 0x64A581057530
00007cd93bdd81c3  call rax
00007cd93bdd81c5  movaps xmm4, [rsp]
00007cd93bdd81c9  add rsp, 0x30
00007cd93bdd81cd  vmovaps xmm0, [rsp]
00007cd93bdd81d2  vmovaps xmm1, [rsp+0x10]
00007cd93bdd81d8  vmovaps xmm2, [rsp+0x20]
00007cd93bdd81de  vmovaps xmm3, [rsp+0x30]
00007cd93bdd81e4  vmovaps xmm5, [rsp+0x40]
00007cd93bdd81ea  vmovaps xmm6, [rsp+0x50]
00007cd93bdd81f0  vmovaps xmm7, [rsp+0x60]
00007cd93bdd81f6  vmovaps xmm8, [rsp+0x70]
00007cd93bdd81fc  vmovaps xmm9, [rsp+0x80]
00007cd93bdd8205  vmovaps xmm10, [rsp+0x90]
00007cd93bdd820e  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd8217  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd8220  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd8229  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd8232  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd823b  add rsp, 0xF0
00007cd93bdd8242  pop r11
00007cd93bdd8244  pop r10
00007cd93bdd8246  pop r9
00007cd93bdd8248  pop r8
00007cd93bdd824a  pop rsi
00007cd93bdd824b  pop rdi
00007cd93bdd824c  pop rdx
00007cd93bdd824d  pop rcx
00007cd93bdd824e  pop rax
00007cd93bdd824f  add rsp, 0x08
00007cd93bdd8253  jmp 0x00007CD93BDD5F54
00007cd93bdd8258  call 0x00007CD93BCD64F0
00007cd93bdd825d  jmp 0x00007CD93BDD5F61
00007cd93bdd8262  sub rsp, 0x08
00007cd93bdd8266  push rax
00007cd93bdd8267  push rcx
00007cd93bdd8268  push rdx
00007cd93bdd8269  push rdi
00007cd93bdd826a  push rsi
00007cd93bdd826b  push r8
00007cd93bdd826d  push r9
00007cd93bdd826f  push r10
00007cd93bdd8271  push r11
00007cd93bdd8273  sub rsp, 0xF0
00007cd93bdd827a  vmovaps [rsp], xmm0
00007cd93bdd827f  vmovaps [rsp+0x10], xmm1
00007cd93bdd8285  vmovaps [rsp+0x20], xmm2
00007cd93bdd828b  vmovaps [rsp+0x30], xmm3
00007cd93bdd8291  vmovaps [rsp+0x40], xmm4
00007cd93bdd8297  vmovaps [rsp+0x50], xmm6
00007cd93bdd829d  vmovaps [rsp+0x60], xmm7
00007cd93bdd82a3  vmovaps [rsp+0x70], xmm8
00007cd93bdd82a9  vmovaps [rsp+0x80], xmm9
00007cd93bdd82b2  vmovaps [rsp+0x90], xmm10
00007cd93bdd82bb  vmovaps [rsp+0xA0], xmm11
00007cd93bdd82c4  vmovaps [rsp+0xB0], xmm12
00007cd93bdd82cd  vmovaps [rsp+0xC0], xmm13
00007cd93bdd82d6  vmovaps [rsp+0xD0], xmm14
00007cd93bdd82df  vmovaps [rsp+0xE0], xmm15
00007cd93bdd82e8  sub rsp, 0x30
00007cd93bdd82ec  movaps [rsp], xmm5
00007cd93bdd82f0  movaps [rsp+0x10], xmm6
00007cd93bdd82f5  movaps [rsp+0x20], xmm3
00007cd93bdd82fa  lea rdi, [rsp]
00007cd93bdd82fe  mov esi, 0x00
00007cd93bdd8303  mov rax, 0x64A581057530
00007cd93bdd830d  call rax
00007cd93bdd830f  movaps xmm5, [rsp]
00007cd93bdd8313  add rsp, 0x30
00007cd93bdd8317  vmovaps xmm0, [rsp]
00007cd93bdd831c  vmovaps xmm1, [rsp+0x10]
00007cd93bdd8322  vmovaps xmm2, [rsp+0x20]
00007cd93bdd8328  vmovaps xmm3, [rsp+0x30]
00007cd93bdd832e  vmovaps xmm4, [rsp+0x40]
00007cd93bdd8334  vmovaps xmm6, [rsp+0x50]
00007cd93bdd833a  vmovaps xmm7, [rsp+0x60]
00007cd93bdd8340  vmovaps xmm8, [rsp+0x70]
00007cd93bdd8346  vmovaps xmm9, [rsp+0x80]
00007cd93bdd834f  vmovaps xmm10, [rsp+0x90]
00007cd93bdd8358  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd8361  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd836a  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd8373  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd837c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd8385  add rsp, 0xF0
00007cd93bdd838c  pop r11
00007cd93bdd838e  pop r10
00007cd93bdd8390  pop r9
00007cd93bdd8392  pop r8
00007cd93bdd8394  pop rsi
00007cd93bdd8395  pop rdi
00007cd93bdd8396  pop rdx
00007cd93bdd8397  pop rcx
00007cd93bdd8398  pop rax
00007cd93bdd8399  add rsp, 0x08
00007cd93bdd839d  jmp 0x00007CD93BDD5F87
00007cd93bdd83a2  sub rsp, 0x08
00007cd93bdd83a6  push rax
00007cd93bdd83a7  push rcx
00007cd93bdd83a8  push rdx
00007cd93bdd83a9  push rdi
00007cd93bdd83aa  push rsi
00007cd93bdd83ab  push r8
00007cd93bdd83ad  push r9
00007cd93bdd83af  push r10
00007cd93bdd83b1  push r11
00007cd93bdd83b3  sub rsp, 0xF0
00007cd93bdd83ba  vmovaps [rsp], xmm0
00007cd93bdd83bf  vmovaps [rsp+0x10], xmm1
00007cd93bdd83c5  vmovaps [rsp+0x20], xmm2
00007cd93bdd83cb  vmovaps [rsp+0x30], xmm3
00007cd93bdd83d1  vmovaps [rsp+0x40], xmm4
00007cd93bdd83d7  vmovaps [rsp+0x50], xmm5
00007cd93bdd83dd  vmovaps [rsp+0x60], xmm7
00007cd93bdd83e3  vmovaps [rsp+0x70], xmm8
00007cd93bdd83e9  vmovaps [rsp+0x80], xmm9
00007cd93bdd83f2  vmovaps [rsp+0x90], xmm10
00007cd93bdd83fb  vmovaps [rsp+0xA0], xmm11
00007cd93bdd8404  vmovaps [rsp+0xB0], xmm12
00007cd93bdd840d  vmovaps [rsp+0xC0], xmm13
00007cd93bdd8416  vmovaps [rsp+0xD0], xmm14
00007cd93bdd841f  vmovaps [rsp+0xE0], xmm15
00007cd93bdd8428  sub rsp, 0x30
00007cd93bdd842c  movaps [rsp], xmm6
00007cd93bdd8430  movaps [rsp+0x10], xmm9
00007cd93bdd8436  movaps [rsp+0x20], xmm1
00007cd93bdd843b  lea rdi, [rsp]
00007cd93bdd843f  mov esi, 0x00
00007cd93bdd8444  mov rax, 0x64A581057530
00007cd93bdd844e  call rax
00007cd93bdd8450  movaps xmm6, [rsp]
00007cd93bdd8454  add rsp, 0x30
00007cd93bdd8458  vmovaps xmm0, [rsp]
00007cd93bdd845d  vmovaps xmm1, [rsp+0x10]
00007cd93bdd8463  vmovaps xmm2, [rsp+0x20]
00007cd93bdd8469  vmovaps xmm3, [rsp+0x30]
00007cd93bdd846f  vmovaps xmm4, [rsp+0x40]
00007cd93bdd8475  vmovaps xmm5, [rsp+0x50]
00007cd93bdd847b  vmovaps xmm7, [rsp+0x60]
00007cd93bdd8481  vmovaps xmm8, [rsp+0x70]
00007cd93bdd8487  vmovaps xmm9, [rsp+0x80]
00007cd93bdd8490  vmovaps xmm10, [rsp+0x90]
00007cd93bdd8499  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd84a2  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd84ab  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd84b4  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd84bd  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd84c6  add rsp, 0xF0
00007cd93bdd84cd  pop r11
00007cd93bdd84cf  pop r10
00007cd93bdd84d1  pop r9
00007cd93bdd84d3  pop r8
00007cd93bdd84d5  pop rsi
00007cd93bdd84d6  pop rdi
00007cd93bdd84d7  pop rdx
00007cd93bdd84d8  pop rcx
00007cd93bdd84d9  pop rax
00007cd93bdd84da  add rsp, 0x08
00007cd93bdd84de  jmp 0x00007CD93BDD5FAB
00007cd93bdd84e3  sub rsp, 0x08
00007cd93bdd84e7  push rax
00007cd93bdd84e8  push rcx
00007cd93bdd84e9  push rdx
00007cd93bdd84ea  push rdi
00007cd93bdd84eb  push rsi
00007cd93bdd84ec  push r8
00007cd93bdd84ee  push r9
00007cd93bdd84f0  push r10
00007cd93bdd84f2  push r11
00007cd93bdd84f4  sub rsp, 0xF0
00007cd93bdd84fb  vmovaps [rsp], xmm0
00007cd93bdd8500  vmovaps [rsp+0x10], xmm1
00007cd93bdd8506  vmovaps [rsp+0x20], xmm2
00007cd93bdd850c  vmovaps [rsp+0x30], xmm3
00007cd93bdd8512  vmovaps [rsp+0x40], xmm4
00007cd93bdd8518  vmovaps [rsp+0x50], xmm5
00007cd93bdd851e  vmovaps [rsp+0x60], xmm6
00007cd93bdd8524  vmovaps [rsp+0x70], xmm7
00007cd93bdd852a  vmovaps [rsp+0x80], xmm8
00007cd93bdd8533  vmovaps [rsp+0x90], xmm10
00007cd93bdd853c  vmovaps [rsp+0xA0], xmm11
00007cd93bdd8545  vmovaps [rsp+0xB0], xmm12
00007cd93bdd854e  vmovaps [rsp+0xC0], xmm13
00007cd93bdd8557  vmovaps [rsp+0xD0], xmm14
00007cd93bdd8560  vmovaps [rsp+0xE0], xmm15
00007cd93bdd8569  sub rsp, 0x30
00007cd93bdd856d  movaps [rsp], xmm9
00007cd93bdd8572  movaps [rsp+0x10], xmm3
00007cd93bdd8577  movaps [rsp+0x20], xmm1
00007cd93bdd857c  lea rdi, [rsp]
00007cd93bdd8580  mov esi, 0x00
00007cd93bdd8585  mov rax, 0x64A581057530
00007cd93bdd858f  call rax
00007cd93bdd8591  movaps xmm9, [rsp]
00007cd93bdd8596  add rsp, 0x30
00007cd93bdd859a  vmovaps xmm0, [rsp]
00007cd93bdd859f  vmovaps xmm1, [rsp+0x10]
00007cd93bdd85a5  vmovaps xmm2, [rsp+0x20]
00007cd93bdd85ab  vmovaps xmm3, [rsp+0x30]
00007cd93bdd85b1  vmovaps xmm4, [rsp+0x40]
00007cd93bdd85b7  vmovaps xmm5, [rsp+0x50]
00007cd93bdd85bd  vmovaps xmm6, [rsp+0x60]
00007cd93bdd85c3  vmovaps xmm7, [rsp+0x70]
00007cd93bdd85c9  vmovaps xmm8, [rsp+0x80]
00007cd93bdd85d2  vmovaps xmm10, [rsp+0x90]
00007cd93bdd85db  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd85e4  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd85ed  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd85f6  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd85ff  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd8608  add rsp, 0xF0
00007cd93bdd860f  pop r11
00007cd93bdd8611  pop r10
00007cd93bdd8613  pop r9
00007cd93bdd8615  pop r8
00007cd93bdd8617  pop rsi
00007cd93bdd8618  pop rdi
00007cd93bdd8619  pop rdx
00007cd93bdd861a  pop rcx
00007cd93bdd861b  pop rax
00007cd93bdd861c  add rsp, 0x08
00007cd93bdd8620  jmp 0x00007CD93BDD5FF7
00007cd93bdd8625  call 0x00007CD93BCD64F0
00007cd93bdd862a  jmp 0x00007CD93BDD6004
00007cd93bdd862f  sub rsp, 0x08
00007cd93bdd8633  push rax
00007cd93bdd8634  push rcx
00007cd93bdd8635  push rdx
00007cd93bdd8636  push rdi
00007cd93bdd8637  push rsi
00007cd93bdd8638  push r8
00007cd93bdd863a  push r9
00007cd93bdd863c  push r10
00007cd93bdd863e  push r11
00007cd93bdd8640  sub rsp, 0xF0
00007cd93bdd8647  vmovaps [rsp], xmm0
00007cd93bdd864c  vmovaps [rsp+0x10], xmm1
00007cd93bdd8652  vmovaps [rsp+0x20], xmm2
00007cd93bdd8658  vmovaps [rsp+0x30], xmm3
00007cd93bdd865e  vmovaps [rsp+0x40], xmm4
00007cd93bdd8664  vmovaps [rsp+0x50], xmm5
00007cd93bdd866a  vmovaps [rsp+0x60], xmm6
00007cd93bdd8670  vmovaps [rsp+0x70], xmm7
00007cd93bdd8676  vmovaps [rsp+0x80], xmm8
00007cd93bdd867f  vmovaps [rsp+0x90], xmm9
00007cd93bdd8688  vmovaps [rsp+0xA0], xmm10
00007cd93bdd8691  vmovaps [rsp+0xB0], xmm11
00007cd93bdd869a  vmovaps [rsp+0xC0], xmm12
00007cd93bdd86a3  vmovaps [rsp+0xD0], xmm13
00007cd93bdd86ac  vmovaps [rsp+0xE0], xmm14
00007cd93bdd86b5  sub rsp, 0x30
00007cd93bdd86b9  movaps [rsp], xmm15
00007cd93bdd86be  movaps [rsp+0x10], xmm3
00007cd93bdd86c3  movaps [rsp+0x20], xmm7
00007cd93bdd86c8  lea rdi, [rsp]
00007cd93bdd86cc  mov esi, 0x00
00007cd93bdd86d1  mov rax, 0x64A581057530
00007cd93bdd86db  call rax
00007cd93bdd86dd  movaps xmm15, [rsp]
00007cd93bdd86e2  add rsp, 0x30
00007cd93bdd86e6  vmovaps xmm0, [rsp]
00007cd93bdd86eb  vmovaps xmm1, [rsp+0x10]
00007cd93bdd86f1  vmovaps xmm2, [rsp+0x20]
00007cd93bdd86f7  vmovaps xmm3, [rsp+0x30]
00007cd93bdd86fd  vmovaps xmm4, [rsp+0x40]
00007cd93bdd8703  vmovaps xmm5, [rsp+0x50]
00007cd93bdd8709  vmovaps xmm6, [rsp+0x60]
00007cd93bdd870f  vmovaps xmm7, [rsp+0x70]
00007cd93bdd8715  vmovaps xmm8, [rsp+0x80]
00007cd93bdd871e  vmovaps xmm9, [rsp+0x90]
00007cd93bdd8727  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd8730  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd8739  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd8742  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd874b  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd8754  add rsp, 0xF0
00007cd93bdd875b  pop r11
00007cd93bdd875d  pop r10
00007cd93bdd875f  pop r9
00007cd93bdd8761  pop r8
00007cd93bdd8763  pop rsi
00007cd93bdd8764  pop rdi
00007cd93bdd8765  pop rdx
00007cd93bdd8766  pop rcx
00007cd93bdd8767  pop rax
00007cd93bdd8768  add rsp, 0x08
00007cd93bdd876c  jmp 0x00007CD93BDD6030
00007cd93bdd8771  sub rsp, 0x08
00007cd93bdd8775  push rax
00007cd93bdd8776  push rcx
00007cd93bdd8777  push rdx
00007cd93bdd8778  push rdi
00007cd93bdd8779  push rsi
00007cd93bdd877a  push r8
00007cd93bdd877c  push r9
00007cd93bdd877e  push r10
00007cd93bdd8780  push r11
00007cd93bdd8782  sub rsp, 0xF0
00007cd93bdd8789  vmovaps [rsp], xmm0
00007cd93bdd878e  vmovaps [rsp+0x10], xmm1
00007cd93bdd8794  vmovaps [rsp+0x20], xmm2
00007cd93bdd879a  vmovaps [rsp+0x30], xmm4
00007cd93bdd87a0  vmovaps [rsp+0x40], xmm5
00007cd93bdd87a6  vmovaps [rsp+0x50], xmm6
00007cd93bdd87ac  vmovaps [rsp+0x60], xmm7
00007cd93bdd87b2  vmovaps [rsp+0x70], xmm8
00007cd93bdd87b8  vmovaps [rsp+0x80], xmm9
00007cd93bdd87c1  vmovaps [rsp+0x90], xmm10
00007cd93bdd87ca  vmovaps [rsp+0xA0], xmm11
00007cd93bdd87d3  vmovaps [rsp+0xB0], xmm12
00007cd93bdd87dc  vmovaps [rsp+0xC0], xmm13
00007cd93bdd87e5  vmovaps [rsp+0xD0], xmm14
00007cd93bdd87ee  vmovaps [rsp+0xE0], xmm15
00007cd93bdd87f7  sub rsp, 0x30
00007cd93bdd87fb  movaps [rsp], xmm3
00007cd93bdd87ff  movaps [rsp+0x10], xmm1
00007cd93bdd8804  movaps [rsp+0x20], xmm15
00007cd93bdd880a  lea rdi, [rsp]
00007cd93bdd880e  mov esi, 0x00
00007cd93bdd8813  mov rax, 0x64A581057530
00007cd93bdd881d  call rax
00007cd93bdd881f  movaps xmm3, [rsp]
00007cd93bdd8823  add rsp, 0x30
00007cd93bdd8827  vmovaps xmm0, [rsp]
00007cd93bdd882c  vmovaps xmm1, [rsp+0x10]
00007cd93bdd8832  vmovaps xmm2, [rsp+0x20]
00007cd93bdd8838  vmovaps xmm4, [rsp+0x30]
00007cd93bdd883e  vmovaps xmm5, [rsp+0x40]
00007cd93bdd8844  vmovaps xmm6, [rsp+0x50]
00007cd93bdd884a  vmovaps xmm7, [rsp+0x60]
00007cd93bdd8850  vmovaps xmm8, [rsp+0x70]
00007cd93bdd8856  vmovaps xmm9, [rsp+0x80]
00007cd93bdd885f  vmovaps xmm10, [rsp+0x90]
00007cd93bdd8868  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd8871  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd887a  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd8883  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd888c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd8895  add rsp, 0xF0
00007cd93bdd889c  pop r11
00007cd93bdd889e  pop r10
00007cd93bdd88a0  pop r9
00007cd93bdd88a2  pop r8
00007cd93bdd88a4  pop rsi
00007cd93bdd88a5  pop rdi
00007cd93bdd88a6  pop rdx
00007cd93bdd88a7  pop rcx
00007cd93bdd88a8  pop rax
00007cd93bdd88a9  add rsp, 0x08
00007cd93bdd88ad  jmp 0x00007CD93BDD60BF
00007cd93bdd88b2  call 0x00007CD93BCD64F0
00007cd93bdd88b7  jmp 0x00007CD93BDD60C9
00007cd93bdd88bc  sub rsp, 0x08
00007cd93bdd88c0  push rax
00007cd93bdd88c1  push rcx
00007cd93bdd88c2  push rdx
00007cd93bdd88c3  push rdi
00007cd93bdd88c4  push rsi
00007cd93bdd88c5  push r8
00007cd93bdd88c7  push r9
00007cd93bdd88c9  push r10
00007cd93bdd88cb  push r11
00007cd93bdd88cd  sub rsp, 0xF0
00007cd93bdd88d4  vmovaps [rsp], xmm0
00007cd93bdd88d9  vmovaps [rsp+0x10], xmm1
00007cd93bdd88df  vmovaps [rsp+0x20], xmm2
00007cd93bdd88e5  vmovaps [rsp+0x30], xmm3
00007cd93bdd88eb  vmovaps [rsp+0x40], xmm4
00007cd93bdd88f1  vmovaps [rsp+0x50], xmm5
00007cd93bdd88f7  vmovaps [rsp+0x60], xmm6
00007cd93bdd88fd  vmovaps [rsp+0x70], xmm7
00007cd93bdd8903  vmovaps [rsp+0x80], xmm8
00007cd93bdd890c  vmovaps [rsp+0x90], xmm9
00007cd93bdd8915  vmovaps [rsp+0xA0], xmm10
00007cd93bdd891e  vmovaps [rsp+0xB0], xmm11
00007cd93bdd8927  vmovaps [rsp+0xC0], xmm12
00007cd93bdd8930  vmovaps [rsp+0xD0], xmm13
00007cd93bdd8939  vmovaps [rsp+0xE0], xmm14
00007cd93bdd8942  sub rsp, 0x30
00007cd93bdd8946  movaps [rsp], xmm15
00007cd93bdd894b  movaps [rsp+0x10], xmm14
00007cd93bdd8951  movaps [rsp+0x20], xmm4
00007cd93bdd8956  lea rdi, [rsp]
00007cd93bdd895a  mov esi, 0x00
00007cd93bdd895f  mov rax, 0x64A581057530
00007cd93bdd8969  call rax
00007cd93bdd896b  movaps xmm15, [rsp]
00007cd93bdd8970  add rsp, 0x30
00007cd93bdd8974  vmovaps xmm0, [rsp]
00007cd93bdd8979  vmovaps xmm1, [rsp+0x10]
00007cd93bdd897f  vmovaps xmm2, [rsp+0x20]
00007cd93bdd8985  vmovaps xmm3, [rsp+0x30]
00007cd93bdd898b  vmovaps xmm4, [rsp+0x40]
00007cd93bdd8991  vmovaps xmm5, [rsp+0x50]
00007cd93bdd8997  vmovaps xmm6, [rsp+0x60]
00007cd93bdd899d  vmovaps xmm7, [rsp+0x70]
00007cd93bdd89a3  vmovaps xmm8, [rsp+0x80]
00007cd93bdd89ac  vmovaps xmm9, [rsp+0x90]
00007cd93bdd89b5  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd89be  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd89c7  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd89d0  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd89d9  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd89e2  add rsp, 0xF0
00007cd93bdd89e9  pop r11
00007cd93bdd89eb  pop r10
00007cd93bdd89ed  pop r9
00007cd93bdd89ef  pop r8
00007cd93bdd89f1  pop rsi
00007cd93bdd89f2  pop rdi
00007cd93bdd89f3  pop rdx
00007cd93bdd89f4  pop rcx
00007cd93bdd89f5  pop rax
00007cd93bdd89f6  add rsp, 0x08
00007cd93bdd89fa  jmp 0x00007CD93BDD60F7
00007cd93bdd89ff  sub rsp, 0x08
00007cd93bdd8a03  push rax
00007cd93bdd8a04  push rcx
00007cd93bdd8a05  push rdx
00007cd93bdd8a06  push rdi
00007cd93bdd8a07  push rsi
00007cd93bdd8a08  push r8
00007cd93bdd8a0a  push r9
00007cd93bdd8a0c  push r10
00007cd93bdd8a0e  push r11
00007cd93bdd8a10  sub rsp, 0xF0
00007cd93bdd8a17  vmovaps [rsp], xmm0
00007cd93bdd8a1c  vmovaps [rsp+0x10], xmm1
00007cd93bdd8a22  vmovaps [rsp+0x20], xmm2
00007cd93bdd8a28  vmovaps [rsp+0x30], xmm3
00007cd93bdd8a2e  vmovaps [rsp+0x40], xmm4
00007cd93bdd8a34  vmovaps [rsp+0x50], xmm5
00007cd93bdd8a3a  vmovaps [rsp+0x60], xmm6
00007cd93bdd8a40  vmovaps [rsp+0x70], xmm7
00007cd93bdd8a46  vmovaps [rsp+0x80], xmm8
00007cd93bdd8a4f  vmovaps [rsp+0x90], xmm9
00007cd93bdd8a58  vmovaps [rsp+0xA0], xmm10
00007cd93bdd8a61  vmovaps [rsp+0xB0], xmm11
00007cd93bdd8a6a  vmovaps [rsp+0xC0], xmm12
00007cd93bdd8a73  vmovaps [rsp+0xD0], xmm13
00007cd93bdd8a7c  vmovaps [rsp+0xE0], xmm15
00007cd93bdd8a85  sub rsp, 0x30
00007cd93bdd8a89  movaps [rsp], xmm14
00007cd93bdd8a8e  movaps [rsp+0x10], xmm2
00007cd93bdd8a93  movaps [rsp+0x20], xmm1
00007cd93bdd8a98  lea rdi, [rsp]
00007cd93bdd8a9c  mov esi, 0x00
00007cd93bdd8aa1  mov rax, 0x64A581057530
00007cd93bdd8aab  call rax
00007cd93bdd8aad  movaps xmm14, [rsp]
00007cd93bdd8ab2  add rsp, 0x30
00007cd93bdd8ab6  vmovaps xmm0, [rsp]
00007cd93bdd8abb  vmovaps xmm1, [rsp+0x10]
00007cd93bdd8ac1  vmovaps xmm2, [rsp+0x20]
00007cd93bdd8ac7  vmovaps xmm3, [rsp+0x30]
00007cd93bdd8acd  vmovaps xmm4, [rsp+0x40]
00007cd93bdd8ad3  vmovaps xmm5, [rsp+0x50]
00007cd93bdd8ad9  vmovaps xmm6, [rsp+0x60]
00007cd93bdd8adf  vmovaps xmm7, [rsp+0x70]
00007cd93bdd8ae5  vmovaps xmm8, [rsp+0x80]
00007cd93bdd8aee  vmovaps xmm9, [rsp+0x90]
00007cd93bdd8af7  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd8b00  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd8b09  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd8b12  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd8b1b  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd8b24  add rsp, 0xF0
00007cd93bdd8b2b  pop r11
00007cd93bdd8b2d  pop r10
00007cd93bdd8b2f  pop r9
00007cd93bdd8b31  pop r8
00007cd93bdd8b33  pop rsi
00007cd93bdd8b34  pop rdi
00007cd93bdd8b35  pop rdx
00007cd93bdd8b36  pop rcx
00007cd93bdd8b37  pop rax
00007cd93bdd8b38  add rsp, 0x08
00007cd93bdd8b3c  jmp 0x00007CD93BDD611D
00007cd93bdd8b41  sub rsp, 0x08
00007cd93bdd8b45  push rax
00007cd93bdd8b46  push rcx
00007cd93bdd8b47  push rdx
00007cd93bdd8b48  push rdi
00007cd93bdd8b49  push rsi
00007cd93bdd8b4a  push r8
00007cd93bdd8b4c  push r9
00007cd93bdd8b4e  push r10
00007cd93bdd8b50  push r11
00007cd93bdd8b52  sub rsp, 0xF0
00007cd93bdd8b59  vmovaps [rsp], xmm0
00007cd93bdd8b5e  vmovaps [rsp+0x10], xmm2
00007cd93bdd8b64  vmovaps [rsp+0x20], xmm3
00007cd93bdd8b6a  vmovaps [rsp+0x30], xmm4
00007cd93bdd8b70  vmovaps [rsp+0x40], xmm5
00007cd93bdd8b76  vmovaps [rsp+0x50], xmm6
00007cd93bdd8b7c  vmovaps [rsp+0x60], xmm7
00007cd93bdd8b82  vmovaps [rsp+0x70], xmm8
00007cd93bdd8b88  vmovaps [rsp+0x80], xmm9
00007cd93bdd8b91  vmovaps [rsp+0x90], xmm10
00007cd93bdd8b9a  vmovaps [rsp+0xA0], xmm11
00007cd93bdd8ba3  vmovaps [rsp+0xB0], xmm12
00007cd93bdd8bac  vmovaps [rsp+0xC0], xmm13
00007cd93bdd8bb5  vmovaps [rsp+0xD0], xmm14
00007cd93bdd8bbe  vmovaps [rsp+0xE0], xmm15
00007cd93bdd8bc7  sub rsp, 0x30
00007cd93bdd8bcb  movaps [rsp], xmm1
00007cd93bdd8bcf  movaps [rsp+0x10], xmm4
00007cd93bdd8bd4  movaps [rsp+0x20], xmm9
00007cd93bdd8bda  lea rdi, [rsp]
00007cd93bdd8bde  mov esi, 0x00
00007cd93bdd8be3  mov rax, 0x64A581057530
00007cd93bdd8bed  call rax
00007cd93bdd8bef  movaps xmm1, [rsp]
00007cd93bdd8bf3  add rsp, 0x30
00007cd93bdd8bf7  vmovaps xmm0, [rsp]
00007cd93bdd8bfc  vmovaps xmm2, [rsp+0x10]
00007cd93bdd8c02  vmovaps xmm3, [rsp+0x20]
00007cd93bdd8c08  vmovaps xmm4, [rsp+0x30]
00007cd93bdd8c0e  vmovaps xmm5, [rsp+0x40]
00007cd93bdd8c14  vmovaps xmm6, [rsp+0x50]
00007cd93bdd8c1a  vmovaps xmm7, [rsp+0x60]
00007cd93bdd8c20  vmovaps xmm8, [rsp+0x70]
00007cd93bdd8c26  vmovaps xmm9, [rsp+0x80]
00007cd93bdd8c2f  vmovaps xmm10, [rsp+0x90]
00007cd93bdd8c38  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd8c41  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd8c4a  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd8c53  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd8c5c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd8c65  add rsp, 0xF0
00007cd93bdd8c6c  pop r11
00007cd93bdd8c6e  pop r10
00007cd93bdd8c70  pop r9
00007cd93bdd8c72  pop r8
00007cd93bdd8c74  pop rsi
00007cd93bdd8c75  pop rdi
00007cd93bdd8c76  pop rdx
00007cd93bdd8c77  pop rcx
00007cd93bdd8c78  pop rax
00007cd93bdd8c79  add rsp, 0x08
00007cd93bdd8c7d  jmp 0x00007CD93BDD613B
00007cd93bdd8c82  sub rsp, 0x08
00007cd93bdd8c86  push rax
00007cd93bdd8c87  push rcx
00007cd93bdd8c88  push rdx
00007cd93bdd8c89  push rdi
00007cd93bdd8c8a  push rsi
00007cd93bdd8c8b  push r8
00007cd93bdd8c8d  push r9
00007cd93bdd8c8f  push r10
00007cd93bdd8c91  push r11
00007cd93bdd8c93  sub rsp, 0xF0
00007cd93bdd8c9a  vmovaps [rsp], xmm0
00007cd93bdd8c9f  vmovaps [rsp+0x10], xmm1
00007cd93bdd8ca5  vmovaps [rsp+0x20], xmm2
00007cd93bdd8cab  vmovaps [rsp+0x30], xmm3
00007cd93bdd8cb1  vmovaps [rsp+0x40], xmm5
00007cd93bdd8cb7  vmovaps [rsp+0x50], xmm6
00007cd93bdd8cbd  vmovaps [rsp+0x60], xmm7
00007cd93bdd8cc3  vmovaps [rsp+0x70], xmm8
00007cd93bdd8cc9  vmovaps [rsp+0x80], xmm9
00007cd93bdd8cd2  vmovaps [rsp+0x90], xmm10
00007cd93bdd8cdb  vmovaps [rsp+0xA0], xmm11
00007cd93bdd8ce4  vmovaps [rsp+0xB0], xmm12
00007cd93bdd8ced  vmovaps [rsp+0xC0], xmm13
00007cd93bdd8cf6  vmovaps [rsp+0xD0], xmm14
00007cd93bdd8cff  vmovaps [rsp+0xE0], xmm15
00007cd93bdd8d08  sub rsp, 0x30
00007cd93bdd8d0c  movaps [rsp], xmm4
00007cd93bdd8d10  movaps [rsp+0x10], xmm2
00007cd93bdd8d15  movaps [rsp+0x20], xmm9
00007cd93bdd8d1b  lea rdi, [rsp]
00007cd93bdd8d1f  mov esi, 0x00
00007cd93bdd8d24  mov rax, 0x64A581057530
00007cd93bdd8d2e  call rax
00007cd93bdd8d30  movaps xmm4, [rsp]
00007cd93bdd8d34  add rsp, 0x30
00007cd93bdd8d38  vmovaps xmm0, [rsp]
00007cd93bdd8d3d  vmovaps xmm1, [rsp+0x10]
00007cd93bdd8d43  vmovaps xmm2, [rsp+0x20]
00007cd93bdd8d49  vmovaps xmm3, [rsp+0x30]
00007cd93bdd8d4f  vmovaps xmm5, [rsp+0x40]
00007cd93bdd8d55  vmovaps xmm6, [rsp+0x50]
00007cd93bdd8d5b  vmovaps xmm7, [rsp+0x60]
00007cd93bdd8d61  vmovaps xmm8, [rsp+0x70]
00007cd93bdd8d67  vmovaps xmm9, [rsp+0x80]
00007cd93bdd8d70  vmovaps xmm10, [rsp+0x90]
00007cd93bdd8d79  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd8d82  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd8d8b  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd8d94  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd8d9d  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd8da6  add rsp, 0xF0
00007cd93bdd8dad  pop r11
00007cd93bdd8daf  pop r10
00007cd93bdd8db1  pop r9
00007cd93bdd8db3  pop r8
00007cd93bdd8db5  pop rsi
00007cd93bdd8db6  pop rdi
00007cd93bdd8db7  pop rdx
00007cd93bdd8db8  pop rcx
00007cd93bdd8db9  pop rax
00007cd93bdd8dba  add rsp, 0x08
00007cd93bdd8dbe  jmp 0x00007CD93BDD616B
00007cd93bdd8dc3  sub rsp, 0x08
00007cd93bdd8dc7  push rax
00007cd93bdd8dc8  push rcx
00007cd93bdd8dc9  push rdx
00007cd93bdd8dca  push rdi
00007cd93bdd8dcb  push rsi
00007cd93bdd8dcc  push r8
00007cd93bdd8dce  push r9
00007cd93bdd8dd0  push r10
00007cd93bdd8dd2  push r11
00007cd93bdd8dd4  sub rsp, 0xF0
00007cd93bdd8ddb  vmovaps [rsp], xmm0
00007cd93bdd8de0  vmovaps [rsp+0x10], xmm1
00007cd93bdd8de6  vmovaps [rsp+0x20], xmm2
00007cd93bdd8dec  vmovaps [rsp+0x30], xmm3
00007cd93bdd8df2  vmovaps [rsp+0x40], xmm4
00007cd93bdd8df8  vmovaps [rsp+0x50], xmm5
00007cd93bdd8dfe  vmovaps [rsp+0x60], xmm6
00007cd93bdd8e04  vmovaps [rsp+0x70], xmm7
00007cd93bdd8e0a  vmovaps [rsp+0x80], xmm8
00007cd93bdd8e13  vmovaps [rsp+0x90], xmm10
00007cd93bdd8e1c  vmovaps [rsp+0xA0], xmm11
00007cd93bdd8e25  vmovaps [rsp+0xB0], xmm12
00007cd93bdd8e2e  vmovaps [rsp+0xC0], xmm13
00007cd93bdd8e37  vmovaps [rsp+0xD0], xmm14
00007cd93bdd8e40  vmovaps [rsp+0xE0], xmm15
00007cd93bdd8e49  sub rsp, 0x30
00007cd93bdd8e4d  movaps [rsp], xmm9
00007cd93bdd8e52  movaps [rsp+0x10], xmm2
00007cd93bdd8e57  movaps [rsp+0x20], xmm1
00007cd93bdd8e5c  lea rdi, [rsp]
00007cd93bdd8e60  mov esi, 0x00
00007cd93bdd8e65  mov rax, 0x64A581057530
00007cd93bdd8e6f  call rax
00007cd93bdd8e71  movaps xmm9, [rsp]
00007cd93bdd8e76  add rsp, 0x30
00007cd93bdd8e7a  vmovaps xmm0, [rsp]
00007cd93bdd8e7f  vmovaps xmm1, [rsp+0x10]
00007cd93bdd8e85  vmovaps xmm2, [rsp+0x20]
00007cd93bdd8e8b  vmovaps xmm3, [rsp+0x30]
00007cd93bdd8e91  vmovaps xmm4, [rsp+0x40]
00007cd93bdd8e97  vmovaps xmm5, [rsp+0x50]
00007cd93bdd8e9d  vmovaps xmm6, [rsp+0x60]
00007cd93bdd8ea3  vmovaps xmm7, [rsp+0x70]
00007cd93bdd8ea9  vmovaps xmm8, [rsp+0x80]
00007cd93bdd8eb2  vmovaps xmm10, [rsp+0x90]
00007cd93bdd8ebb  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd8ec4  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd8ecd  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd8ed6  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd8edf  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd8ee8  add rsp, 0xF0
00007cd93bdd8eef  pop r11
00007cd93bdd8ef1  pop r10
00007cd93bdd8ef3  pop r9
00007cd93bdd8ef5  pop r8
00007cd93bdd8ef7  pop rsi
00007cd93bdd8ef8  pop rdi
00007cd93bdd8ef9  pop rdx
00007cd93bdd8efa  pop rcx
00007cd93bdd8efb  pop rax
00007cd93bdd8efc  add rsp, 0x08
00007cd93bdd8f00  jmp 0x00007CD93BDD61A1
00007cd93bdd8f05  sub rsp, 0x08
00007cd93bdd8f09  push rax
00007cd93bdd8f0a  push rcx
00007cd93bdd8f0b  push rdx
00007cd93bdd8f0c  push rdi
00007cd93bdd8f0d  push rsi
00007cd93bdd8f0e  push r8
00007cd93bdd8f10  push r9
00007cd93bdd8f12  push r10
00007cd93bdd8f14  push r11
00007cd93bdd8f16  sub rsp, 0xF0
00007cd93bdd8f1d  vmovaps [rsp], xmm0
00007cd93bdd8f22  vmovaps [rsp+0x10], xmm2
00007cd93bdd8f28  vmovaps [rsp+0x20], xmm3
00007cd93bdd8f2e  vmovaps [rsp+0x30], xmm4
00007cd93bdd8f34  vmovaps [rsp+0x40], xmm5
00007cd93bdd8f3a  vmovaps [rsp+0x50], xmm6
00007cd93bdd8f40  vmovaps [rsp+0x60], xmm7
00007cd93bdd8f46  vmovaps [rsp+0x70], xmm8
00007cd93bdd8f4c  vmovaps [rsp+0x80], xmm9
00007cd93bdd8f55  vmovaps [rsp+0x90], xmm10
00007cd93bdd8f5e  vmovaps [rsp+0xA0], xmm11
00007cd93bdd8f67  vmovaps [rsp+0xB0], xmm12
00007cd93bdd8f70  vmovaps [rsp+0xC0], xmm13
00007cd93bdd8f79  vmovaps [rsp+0xD0], xmm14
00007cd93bdd8f82  vmovaps [rsp+0xE0], xmm15
00007cd93bdd8f8b  sub rsp, 0x30
00007cd93bdd8f8f  movaps [rsp], xmm1
00007cd93bdd8f93  movaps [rsp+0x10], xmm15
00007cd93bdd8f99  movaps [rsp+0x20], xmm6
00007cd93bdd8f9e  lea rdi, [rsp]
00007cd93bdd8fa2  mov esi, 0x00
00007cd93bdd8fa7  mov rax, 0x64A581057530
00007cd93bdd8fb1  call rax
00007cd93bdd8fb3  movaps xmm1, [rsp]
00007cd93bdd8fb7  add rsp, 0x30
00007cd93bdd8fbb  vmovaps xmm0, [rsp]
00007cd93bdd8fc0  vmovaps xmm2, [rsp+0x10]
00007cd93bdd8fc6  vmovaps xmm3, [rsp+0x20]
00007cd93bdd8fcc  vmovaps xmm4, [rsp+0x30]
00007cd93bdd8fd2  vmovaps xmm5, [rsp+0x40]
00007cd93bdd8fd8  vmovaps xmm6, [rsp+0x50]
00007cd93bdd8fde  vmovaps xmm7, [rsp+0x60]
00007cd93bdd8fe4  vmovaps xmm8, [rsp+0x70]
00007cd93bdd8fea  vmovaps xmm9, [rsp+0x80]
00007cd93bdd8ff3  vmovaps xmm10, [rsp+0x90]
00007cd93bdd8ffc  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd9005  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd900e  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd9017  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd9020  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd9029  add rsp, 0xF0
00007cd93bdd9030  pop r11
00007cd93bdd9032  pop r10
00007cd93bdd9034  pop r9
00007cd93bdd9036  pop r8
00007cd93bdd9038  pop rsi
00007cd93bdd9039  pop rdi
00007cd93bdd903a  pop rdx
00007cd93bdd903b  pop rcx
00007cd93bdd903c  pop rax
00007cd93bdd903d  add rsp, 0x08
00007cd93bdd9041  jmp 0x00007CD93BDD61C2
00007cd93bdd9046  sub rsp, 0x08
00007cd93bdd904a  push rax
00007cd93bdd904b  push rcx
00007cd93bdd904c  push rdx
00007cd93bdd904d  push rdi
00007cd93bdd904e  push rsi
00007cd93bdd904f  push r8
00007cd93bdd9051  push r9
00007cd93bdd9053  push r10
00007cd93bdd9055  push r11
00007cd93bdd9057  sub rsp, 0xF0
00007cd93bdd905e  vmovaps [rsp], xmm0
00007cd93bdd9063  vmovaps [rsp+0x10], xmm1
00007cd93bdd9069  vmovaps [rsp+0x20], xmm2
00007cd93bdd906f  vmovaps [rsp+0x30], xmm3
00007cd93bdd9075  vmovaps [rsp+0x40], xmm4
00007cd93bdd907b  vmovaps [rsp+0x50], xmm5
00007cd93bdd9081  vmovaps [rsp+0x60], xmm6
00007cd93bdd9087  vmovaps [rsp+0x70], xmm7
00007cd93bdd908d  vmovaps [rsp+0x80], xmm8
00007cd93bdd9096  vmovaps [rsp+0x90], xmm9
00007cd93bdd909f  vmovaps [rsp+0xA0], xmm10
00007cd93bdd90a8  vmovaps [rsp+0xB0], xmm11
00007cd93bdd90b1  vmovaps [rsp+0xC0], xmm12
00007cd93bdd90ba  vmovaps [rsp+0xD0], xmm13
00007cd93bdd90c3  vmovaps [rsp+0xE0], xmm14
00007cd93bdd90cc  sub rsp, 0x30
00007cd93bdd90d0  movaps [rsp], xmm15
00007cd93bdd90d5  movaps [rsp+0x10], xmm5
00007cd93bdd90da  movaps [rsp+0x20], xmm3
00007cd93bdd90df  lea rdi, [rsp]
00007cd93bdd90e3  mov esi, 0x00
00007cd93bdd90e8  mov rax, 0x64A581057530
00007cd93bdd90f2  call rax
00007cd93bdd90f4  movaps xmm15, [rsp]
00007cd93bdd90f9  add rsp, 0x30
00007cd93bdd90fd  vmovaps xmm0, [rsp]
00007cd93bdd9102  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9108  vmovaps xmm2, [rsp+0x20]
00007cd93bdd910e  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9114  vmovaps xmm4, [rsp+0x40]
00007cd93bdd911a  vmovaps xmm5, [rsp+0x50]
00007cd93bdd9120  vmovaps xmm6, [rsp+0x60]
00007cd93bdd9126  vmovaps xmm7, [rsp+0x70]
00007cd93bdd912c  vmovaps xmm8, [rsp+0x80]
00007cd93bdd9135  vmovaps xmm9, [rsp+0x90]
00007cd93bdd913e  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd9147  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd9150  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd9159  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd9162  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd916b  add rsp, 0xF0
00007cd93bdd9172  pop r11
00007cd93bdd9174  pop r10
00007cd93bdd9176  pop r9
00007cd93bdd9178  pop r8
00007cd93bdd917a  pop rsi
00007cd93bdd917b  pop rdi
00007cd93bdd917c  pop rdx
00007cd93bdd917d  pop rcx
00007cd93bdd917e  pop rax
00007cd93bdd917f  add rsp, 0x08
00007cd93bdd9183  jmp 0x00007CD93BDD61DC
00007cd93bdd9188  sub rsp, 0x08
00007cd93bdd918c  push rax
00007cd93bdd918d  push rcx
00007cd93bdd918e  push rdx
00007cd93bdd918f  push rdi
00007cd93bdd9190  push rsi
00007cd93bdd9191  push r8
00007cd93bdd9193  push r9
00007cd93bdd9195  push r10
00007cd93bdd9197  push r11
00007cd93bdd9199  sub rsp, 0xF0
00007cd93bdd91a0  vmovaps [rsp], xmm0
00007cd93bdd91a5  vmovaps [rsp+0x10], xmm1
00007cd93bdd91ab  vmovaps [rsp+0x20], xmm2
00007cd93bdd91b1  vmovaps [rsp+0x30], xmm3
00007cd93bdd91b7  vmovaps [rsp+0x40], xmm4
00007cd93bdd91bd  vmovaps [rsp+0x50], xmm6
00007cd93bdd91c3  vmovaps [rsp+0x60], xmm7
00007cd93bdd91c9  vmovaps [rsp+0x70], xmm8
00007cd93bdd91cf  vmovaps [rsp+0x80], xmm9
00007cd93bdd91d8  vmovaps [rsp+0x90], xmm10
00007cd93bdd91e1  vmovaps [rsp+0xA0], xmm11
00007cd93bdd91ea  vmovaps [rsp+0xB0], xmm12
00007cd93bdd91f3  vmovaps [rsp+0xC0], xmm13
00007cd93bdd91fc  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9205  vmovaps [rsp+0xE0], xmm15
00007cd93bdd920e  sub rsp, 0x30
00007cd93bdd9212  movaps [rsp], xmm5
00007cd93bdd9216  movaps [rsp+0x10], xmm8
00007cd93bdd921c  movaps [rsp+0x20], xmm6
00007cd93bdd9221  lea rdi, [rsp]
00007cd93bdd9225  mov esi, 0x00
00007cd93bdd922a  mov rax, 0x64A581057530
00007cd93bdd9234  call rax
00007cd93bdd9236  movaps xmm5, [rsp]
00007cd93bdd923a  add rsp, 0x30
00007cd93bdd923e  vmovaps xmm0, [rsp]
00007cd93bdd9243  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9249  vmovaps xmm2, [rsp+0x20]
00007cd93bdd924f  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9255  vmovaps xmm4, [rsp+0x40]
00007cd93bdd925b  vmovaps xmm6, [rsp+0x50]
00007cd93bdd9261  vmovaps xmm7, [rsp+0x60]
00007cd93bdd9267  vmovaps xmm8, [rsp+0x70]
00007cd93bdd926d  vmovaps xmm9, [rsp+0x80]
00007cd93bdd9276  vmovaps xmm10, [rsp+0x90]
00007cd93bdd927f  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd9288  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd9291  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd929a  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd92a3  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd92ac  add rsp, 0xF0
00007cd93bdd92b3  pop r11
00007cd93bdd92b5  pop r10
00007cd93bdd92b7  pop r9
00007cd93bdd92b9  pop r8
00007cd93bdd92bb  pop rsi
00007cd93bdd92bc  pop rdi
00007cd93bdd92bd  pop rdx
00007cd93bdd92be  pop rcx
00007cd93bdd92bf  pop rax
00007cd93bdd92c0  add rsp, 0x08
00007cd93bdd92c4  jmp 0x00007CD93BDD6200
00007cd93bdd92c9  sub rsp, 0x08
00007cd93bdd92cd  push rax
00007cd93bdd92ce  push rcx
00007cd93bdd92cf  push rdx
00007cd93bdd92d0  push rdi
00007cd93bdd92d1  push rsi
00007cd93bdd92d2  push r8
00007cd93bdd92d4  push r9
00007cd93bdd92d6  push r10
00007cd93bdd92d8  push r11
00007cd93bdd92da  sub rsp, 0xF0
00007cd93bdd92e1  vmovaps [rsp], xmm0
00007cd93bdd92e6  vmovaps [rsp+0x10], xmm1
00007cd93bdd92ec  vmovaps [rsp+0x20], xmm2
00007cd93bdd92f2  vmovaps [rsp+0x30], xmm3
00007cd93bdd92f8  vmovaps [rsp+0x40], xmm4
00007cd93bdd92fe  vmovaps [rsp+0x50], xmm5
00007cd93bdd9304  vmovaps [rsp+0x60], xmm7
00007cd93bdd930a  vmovaps [rsp+0x70], xmm8
00007cd93bdd9310  vmovaps [rsp+0x80], xmm9
00007cd93bdd9319  vmovaps [rsp+0x90], xmm10
00007cd93bdd9322  vmovaps [rsp+0xA0], xmm11
00007cd93bdd932b  vmovaps [rsp+0xB0], xmm12
00007cd93bdd9334  vmovaps [rsp+0xC0], xmm13
00007cd93bdd933d  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9346  vmovaps [rsp+0xE0], xmm15
00007cd93bdd934f  sub rsp, 0x30
00007cd93bdd9353  movaps [rsp], xmm6
00007cd93bdd9357  movaps [rsp+0x10], xmm10
00007cd93bdd935d  movaps [rsp+0x20], xmm8
00007cd93bdd9363  lea rdi, [rsp]
00007cd93bdd9367  mov esi, 0x00
00007cd93bdd936c  mov rax, 0x64A581057530
00007cd93bdd9376  call rax
00007cd93bdd9378  movaps xmm6, [rsp]
00007cd93bdd937c  add rsp, 0x30
00007cd93bdd9380  vmovaps xmm0, [rsp]
00007cd93bdd9385  vmovaps xmm1, [rsp+0x10]
00007cd93bdd938b  vmovaps xmm2, [rsp+0x20]
00007cd93bdd9391  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9397  vmovaps xmm4, [rsp+0x40]
00007cd93bdd939d  vmovaps xmm5, [rsp+0x50]
00007cd93bdd93a3  vmovaps xmm7, [rsp+0x60]
00007cd93bdd93a9  vmovaps xmm8, [rsp+0x70]
00007cd93bdd93af  vmovaps xmm9, [rsp+0x80]
00007cd93bdd93b8  vmovaps xmm10, [rsp+0x90]
00007cd93bdd93c1  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd93ca  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd93d3  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd93dc  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd93e5  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd93ee  add rsp, 0xF0
00007cd93bdd93f5  pop r11
00007cd93bdd93f7  pop r10
00007cd93bdd93f9  pop r9
00007cd93bdd93fb  pop r8
00007cd93bdd93fd  pop rsi
00007cd93bdd93fe  pop rdi
00007cd93bdd93ff  pop rdx
00007cd93bdd9400  pop rcx
00007cd93bdd9401  pop rax
00007cd93bdd9402  add rsp, 0x08
00007cd93bdd9406  jmp 0x00007CD93BDD6225
00007cd93bdd940b  sub rsp, 0x08
00007cd93bdd940f  push rax
00007cd93bdd9410  push rcx
00007cd93bdd9411  push rdx
00007cd93bdd9412  push rdi
00007cd93bdd9413  push rsi
00007cd93bdd9414  push r8
00007cd93bdd9416  push r9
00007cd93bdd9418  push r10
00007cd93bdd941a  push r11
00007cd93bdd941c  sub rsp, 0xF0
00007cd93bdd9423  vmovaps [rsp], xmm0
00007cd93bdd9428  vmovaps [rsp+0x10], xmm1
00007cd93bdd942e  vmovaps [rsp+0x20], xmm2
00007cd93bdd9434  vmovaps [rsp+0x30], xmm3
00007cd93bdd943a  vmovaps [rsp+0x40], xmm4
00007cd93bdd9440  vmovaps [rsp+0x50], xmm5
00007cd93bdd9446  vmovaps [rsp+0x60], xmm6
00007cd93bdd944c  vmovaps [rsp+0x70], xmm7
00007cd93bdd9452  vmovaps [rsp+0x80], xmm8
00007cd93bdd945b  vmovaps [rsp+0x90], xmm9
00007cd93bdd9464  vmovaps [rsp+0xA0], xmm11
00007cd93bdd946d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd9476  vmovaps [rsp+0xC0], xmm13
00007cd93bdd947f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9488  vmovaps [rsp+0xE0], xmm15
00007cd93bdd9491  sub rsp, 0x30
00007cd93bdd9495  movaps [rsp], xmm10
00007cd93bdd949a  movaps [rsp+0x10], xmm8
00007cd93bdd94a0  movaps [rsp+0x20], xmm14
00007cd93bdd94a6  lea rdi, [rsp]
00007cd93bdd94aa  mov esi, 0x00
00007cd93bdd94af  mov rax, 0x64A581057530
00007cd93bdd94b9  call rax
00007cd93bdd94bb  movaps xmm10, [rsp]
00007cd93bdd94c0  add rsp, 0x30
00007cd93bdd94c4  vmovaps xmm0, [rsp]
00007cd93bdd94c9  vmovaps xmm1, [rsp+0x10]
00007cd93bdd94cf  vmovaps xmm2, [rsp+0x20]
00007cd93bdd94d5  vmovaps xmm3, [rsp+0x30]
00007cd93bdd94db  vmovaps xmm4, [rsp+0x40]
00007cd93bdd94e1  vmovaps xmm5, [rsp+0x50]
00007cd93bdd94e7  vmovaps xmm6, [rsp+0x60]
00007cd93bdd94ed  vmovaps xmm7, [rsp+0x70]
00007cd93bdd94f3  vmovaps xmm8, [rsp+0x80]
00007cd93bdd94fc  vmovaps xmm9, [rsp+0x90]
00007cd93bdd9505  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd950e  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd9517  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd9520  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd9529  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd9532  add rsp, 0xF0
00007cd93bdd9539  pop r11
00007cd93bdd953b  pop r10
00007cd93bdd953d  pop r9
00007cd93bdd953f  pop r8
00007cd93bdd9541  pop rsi
00007cd93bdd9542  pop rdi
00007cd93bdd9543  pop rdx
00007cd93bdd9544  pop rcx
00007cd93bdd9545  pop rax
00007cd93bdd9546  add rsp, 0x08
00007cd93bdd954a  jmp 0x00007CD93BDD6245
00007cd93bdd954f  sub rsp, 0x08
00007cd93bdd9553  push rax
00007cd93bdd9554  push rcx
00007cd93bdd9555  push rdx
00007cd93bdd9556  push rdi
00007cd93bdd9557  push rsi
00007cd93bdd9558  push r8
00007cd93bdd955a  push r9
00007cd93bdd955c  push r10
00007cd93bdd955e  push r11
00007cd93bdd9560  sub rsp, 0xF0
00007cd93bdd9567  vmovaps [rsp], xmm0
00007cd93bdd956c  vmovaps [rsp+0x10], xmm1
00007cd93bdd9572  vmovaps [rsp+0x20], xmm2
00007cd93bdd9578  vmovaps [rsp+0x30], xmm3
00007cd93bdd957e  vmovaps [rsp+0x40], xmm4
00007cd93bdd9584  vmovaps [rsp+0x50], xmm5
00007cd93bdd958a  vmovaps [rsp+0x60], xmm6
00007cd93bdd9590  vmovaps [rsp+0x70], xmm7
00007cd93bdd9596  vmovaps [rsp+0x80], xmm8
00007cd93bdd959f  vmovaps [rsp+0x90], xmm9
00007cd93bdd95a8  vmovaps [rsp+0xA0], xmm10
00007cd93bdd95b1  vmovaps [rsp+0xB0], xmm11
00007cd93bdd95ba  vmovaps [rsp+0xC0], xmm12
00007cd93bdd95c3  vmovaps [rsp+0xD0], xmm13
00007cd93bdd95cc  vmovaps [rsp+0xE0], xmm15
00007cd93bdd95d5  sub rsp, 0x30
00007cd93bdd95d9  movaps [rsp], xmm14
00007cd93bdd95de  movaps [rsp+0x10], xmm8
00007cd93bdd95e4  movaps [rsp+0x20], xmm4
00007cd93bdd95e9  lea rdi, [rsp]
00007cd93bdd95ed  mov esi, 0x00
00007cd93bdd95f2  mov rax, 0x64A581057530
00007cd93bdd95fc  call rax
00007cd93bdd95fe  movaps xmm14, [rsp]
00007cd93bdd9603  add rsp, 0x30
00007cd93bdd9607  vmovaps xmm0, [rsp]
00007cd93bdd960c  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9612  vmovaps xmm2, [rsp+0x20]
00007cd93bdd9618  vmovaps xmm3, [rsp+0x30]
00007cd93bdd961e  vmovaps xmm4, [rsp+0x40]
00007cd93bdd9624  vmovaps xmm5, [rsp+0x50]
00007cd93bdd962a  vmovaps xmm6, [rsp+0x60]
00007cd93bdd9630  vmovaps xmm7, [rsp+0x70]
00007cd93bdd9636  vmovaps xmm8, [rsp+0x80]
00007cd93bdd963f  vmovaps xmm9, [rsp+0x90]
00007cd93bdd9648  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd9651  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd965a  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd9663  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd966c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd9675  add rsp, 0xF0
00007cd93bdd967c  pop r11
00007cd93bdd967e  pop r10
00007cd93bdd9680  pop r9
00007cd93bdd9682  pop r8
00007cd93bdd9684  pop rsi
00007cd93bdd9685  pop rdi
00007cd93bdd9686  pop rdx
00007cd93bdd9687  pop rcx
00007cd93bdd9688  pop rax
00007cd93bdd9689  add rsp, 0x08
00007cd93bdd968d  jmp 0x00007CD93BDD6265
00007cd93bdd9692  sub rsp, 0x08
00007cd93bdd9696  push rax
00007cd93bdd9697  push rcx
00007cd93bdd9698  push rdx
00007cd93bdd9699  push rdi
00007cd93bdd969a  push rsi
00007cd93bdd969b  push r8
00007cd93bdd969d  push r9
00007cd93bdd969f  push r10
00007cd93bdd96a1  push r11
00007cd93bdd96a3  sub rsp, 0xF0
00007cd93bdd96aa  vmovaps [rsp], xmm0
00007cd93bdd96af  vmovaps [rsp+0x10], xmm1
00007cd93bdd96b5  vmovaps [rsp+0x20], xmm2
00007cd93bdd96bb  vmovaps [rsp+0x30], xmm3
00007cd93bdd96c1  vmovaps [rsp+0x40], xmm5
00007cd93bdd96c7  vmovaps [rsp+0x50], xmm6
00007cd93bdd96cd  vmovaps [rsp+0x60], xmm7
00007cd93bdd96d3  vmovaps [rsp+0x70], xmm8
00007cd93bdd96d9  vmovaps [rsp+0x80], xmm9
00007cd93bdd96e2  vmovaps [rsp+0x90], xmm10
00007cd93bdd96eb  vmovaps [rsp+0xA0], xmm11
00007cd93bdd96f4  vmovaps [rsp+0xB0], xmm12
00007cd93bdd96fd  vmovaps [rsp+0xC0], xmm13
00007cd93bdd9706  vmovaps [rsp+0xD0], xmm14
00007cd93bdd970f  vmovaps [rsp+0xE0], xmm15
00007cd93bdd9718  sub rsp, 0x30
00007cd93bdd971c  movaps [rsp], xmm4
00007cd93bdd9720  movaps [rsp+0x10], xmm13
00007cd93bdd9726  movaps [rsp+0x20], xmm8
00007cd93bdd972c  lea rdi, [rsp]
00007cd93bdd9730  mov esi, 0x00
00007cd93bdd9735  mov rax, 0x64A581057530
00007cd93bdd973f  call rax
00007cd93bdd9741  movaps xmm4, [rsp]
00007cd93bdd9745  add rsp, 0x30
00007cd93bdd9749  vmovaps xmm0, [rsp]
00007cd93bdd974e  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9754  vmovaps xmm2, [rsp+0x20]
00007cd93bdd975a  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9760  vmovaps xmm5, [rsp+0x40]
00007cd93bdd9766  vmovaps xmm6, [rsp+0x50]
00007cd93bdd976c  vmovaps xmm7, [rsp+0x60]
00007cd93bdd9772  vmovaps xmm8, [rsp+0x70]
00007cd93bdd9778  vmovaps xmm9, [rsp+0x80]
00007cd93bdd9781  vmovaps xmm10, [rsp+0x90]
00007cd93bdd978a  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd9793  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd979c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd97a5  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd97ae  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd97b7  add rsp, 0xF0
00007cd93bdd97be  pop r11
00007cd93bdd97c0  pop r10
00007cd93bdd97c2  pop r9
00007cd93bdd97c4  pop r8
00007cd93bdd97c6  pop rsi
00007cd93bdd97c7  pop rdi
00007cd93bdd97c8  pop rdx
00007cd93bdd97c9  pop rcx
00007cd93bdd97ca  pop rax
00007cd93bdd97cb  add rsp, 0x08
00007cd93bdd97cf  jmp 0x00007CD93BDD628A
00007cd93bdd97d4  sub rsp, 0x08
00007cd93bdd97d8  push rax
00007cd93bdd97d9  push rcx
00007cd93bdd97da  push rdx
00007cd93bdd97db  push rdi
00007cd93bdd97dc  push rsi
00007cd93bdd97dd  push r8
00007cd93bdd97df  push r9
00007cd93bdd97e1  push r10
00007cd93bdd97e3  push r11
00007cd93bdd97e5  sub rsp, 0xF0
00007cd93bdd97ec  vmovaps [rsp], xmm0
00007cd93bdd97f1  vmovaps [rsp+0x10], xmm1
00007cd93bdd97f7  vmovaps [rsp+0x20], xmm2
00007cd93bdd97fd  vmovaps [rsp+0x30], xmm3
00007cd93bdd9803  vmovaps [rsp+0x40], xmm4
00007cd93bdd9809  vmovaps [rsp+0x50], xmm5
00007cd93bdd980f  vmovaps [rsp+0x60], xmm6
00007cd93bdd9815  vmovaps [rsp+0x70], xmm7
00007cd93bdd981b  vmovaps [rsp+0x80], xmm8
00007cd93bdd9824  vmovaps [rsp+0x90], xmm9
00007cd93bdd982d  vmovaps [rsp+0xA0], xmm10
00007cd93bdd9836  vmovaps [rsp+0xB0], xmm11
00007cd93bdd983f  vmovaps [rsp+0xC0], xmm12
00007cd93bdd9848  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9851  vmovaps [rsp+0xE0], xmm15
00007cd93bdd985a  sub rsp, 0x30
00007cd93bdd985e  movaps [rsp], xmm13
00007cd93bdd9863  movaps [rsp+0x10], xmm15
00007cd93bdd9869  movaps [rsp+0x20], xmm9
00007cd93bdd986f  lea rdi, [rsp]
00007cd93bdd9873  mov esi, 0x00
00007cd93bdd9878  mov rax, 0x64A581057530
00007cd93bdd9882  call rax
00007cd93bdd9884  movaps xmm13, [rsp]
00007cd93bdd9889  add rsp, 0x30
00007cd93bdd988d  vmovaps xmm0, [rsp]
00007cd93bdd9892  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9898  vmovaps xmm2, [rsp+0x20]
00007cd93bdd989e  vmovaps xmm3, [rsp+0x30]
00007cd93bdd98a4  vmovaps xmm4, [rsp+0x40]
00007cd93bdd98aa  vmovaps xmm5, [rsp+0x50]
00007cd93bdd98b0  vmovaps xmm6, [rsp+0x60]
00007cd93bdd98b6  vmovaps xmm7, [rsp+0x70]
00007cd93bdd98bc  vmovaps xmm8, [rsp+0x80]
00007cd93bdd98c5  vmovaps xmm9, [rsp+0x90]
00007cd93bdd98ce  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd98d7  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd98e0  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd98e9  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd98f2  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd98fb  add rsp, 0xF0
00007cd93bdd9902  pop r11
00007cd93bdd9904  pop r10
00007cd93bdd9906  pop r9
00007cd93bdd9908  pop r8
00007cd93bdd990a  pop rsi
00007cd93bdd990b  pop rdi
00007cd93bdd990c  pop rdx
00007cd93bdd990d  pop rcx
00007cd93bdd990e  pop rax
00007cd93bdd990f  add rsp, 0x08
00007cd93bdd9913  jmp 0x00007CD93BDD62A5
00007cd93bdd9918  sub rsp, 0x08
00007cd93bdd991c  push rax
00007cd93bdd991d  push rcx
00007cd93bdd991e  push rdx
00007cd93bdd991f  push rdi
00007cd93bdd9920  push rsi
00007cd93bdd9921  push r8
00007cd93bdd9923  push r9
00007cd93bdd9925  push r10
00007cd93bdd9927  push r11
00007cd93bdd9929  sub rsp, 0xF0
00007cd93bdd9930  vmovaps [rsp], xmm0
00007cd93bdd9935  vmovaps [rsp+0x10], xmm1
00007cd93bdd993b  vmovaps [rsp+0x20], xmm2
00007cd93bdd9941  vmovaps [rsp+0x30], xmm3
00007cd93bdd9947  vmovaps [rsp+0x40], xmm4
00007cd93bdd994d  vmovaps [rsp+0x50], xmm5
00007cd93bdd9953  vmovaps [rsp+0x60], xmm6
00007cd93bdd9959  vmovaps [rsp+0x70], xmm7
00007cd93bdd995f  vmovaps [rsp+0x80], xmm8
00007cd93bdd9968  vmovaps [rsp+0x90], xmm9
00007cd93bdd9971  vmovaps [rsp+0xA0], xmm10
00007cd93bdd997a  vmovaps [rsp+0xB0], xmm11
00007cd93bdd9983  vmovaps [rsp+0xC0], xmm12
00007cd93bdd998c  vmovaps [rsp+0xD0], xmm13
00007cd93bdd9995  vmovaps [rsp+0xE0], xmm14
00007cd93bdd999e  sub rsp, 0x30
00007cd93bdd99a2  movaps [rsp], xmm15
00007cd93bdd99a7  movaps [rsp+0x10], xmm1
00007cd93bdd99ac  movaps [rsp+0x20], xmm5
00007cd93bdd99b1  lea rdi, [rsp]
00007cd93bdd99b5  mov esi, 0x00
00007cd93bdd99ba  mov rax, 0x64A581057530
00007cd93bdd99c4  call rax
00007cd93bdd99c6  movaps xmm15, [rsp]
00007cd93bdd99cb  add rsp, 0x30
00007cd93bdd99cf  vmovaps xmm0, [rsp]
00007cd93bdd99d4  vmovaps xmm1, [rsp+0x10]
00007cd93bdd99da  vmovaps xmm2, [rsp+0x20]
00007cd93bdd99e0  vmovaps xmm3, [rsp+0x30]
00007cd93bdd99e6  vmovaps xmm4, [rsp+0x40]
00007cd93bdd99ec  vmovaps xmm5, [rsp+0x50]
00007cd93bdd99f2  vmovaps xmm6, [rsp+0x60]
00007cd93bdd99f8  vmovaps xmm7, [rsp+0x70]
00007cd93bdd99fe  vmovaps xmm8, [rsp+0x80]
00007cd93bdd9a07  vmovaps xmm9, [rsp+0x90]
00007cd93bdd9a10  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd9a19  vmovaps xmm11, [rsp+0xB0]
00007cd93bdd9a22  vmovaps xmm12, [rsp+0xC0]
00007cd93bdd9a2b  vmovaps xmm13, [rsp+0xD0]
00007cd93bdd9a34  vmovaps xmm14, [rsp+0xE0]
00007cd93bdd9a3d  add rsp, 0xF0
00007cd93bdd9a44  pop r11
00007cd93bdd9a46  pop r10
00007cd93bdd9a48  pop r9
00007cd93bdd9a4a  pop r8
00007cd93bdd9a4c  pop rsi
00007cd93bdd9a4d  pop rdi
00007cd93bdd9a4e  pop rdx
00007cd93bdd9a4f  pop rcx
00007cd93bdd9a50  pop rax
00007cd93bdd9a51  add rsp, 0x08
00007cd93bdd9a55  jmp 0x00007CD93BDD62C0
00007cd93bdd9a5a  call 0x00007CD93BCD64F0
00007cd93bdd9a5f  jmp 0x00007CD93BDD631B
00007cd93bdd9a64  sub rsp, 0x08
00007cd93bdd9a68  push rax
00007cd93bdd9a69  push rcx
00007cd93bdd9a6a  push rdx
00007cd93bdd9a6b  push rdi
00007cd93bdd9a6c  push rsi
00007cd93bdd9a6d  push r8
00007cd93bdd9a6f  push r9
00007cd93bdd9a71  push r10
00007cd93bdd9a73  push r11
00007cd93bdd9a75  sub rsp, 0xF0
00007cd93bdd9a7c  vmovaps [rsp], xmm0
00007cd93bdd9a81  vmovaps [rsp+0x10], xmm1
00007cd93bdd9a87  vmovaps [rsp+0x20], xmm2
00007cd93bdd9a8d  vmovaps [rsp+0x30], xmm3
00007cd93bdd9a93  vmovaps [rsp+0x40], xmm4
00007cd93bdd9a99  vmovaps [rsp+0x50], xmm5
00007cd93bdd9a9f  vmovaps [rsp+0x60], xmm6
00007cd93bdd9aa5  vmovaps [rsp+0x70], xmm7
00007cd93bdd9aab  vmovaps [rsp+0x80], xmm8
00007cd93bdd9ab4  vmovaps [rsp+0x90], xmm10
00007cd93bdd9abd  vmovaps [rsp+0xA0], xmm11
00007cd93bdd9ac6  vmovaps [rsp+0xB0], xmm12
00007cd93bdd9acf  vmovaps [rsp+0xC0], xmm13
00007cd93bdd9ad8  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9ae1  vmovaps [rsp+0xE0], xmm15
00007cd93bdd9aea  sub rsp, 0x30
00007cd93bdd9aee  movaps [rsp], xmm9
00007cd93bdd9af3  movaps [rsp+0x10], xmm8
00007cd93bdd9af9  movaps [rsp+0x20], xmm11
00007cd93bdd9aff  lea rdi, [rsp]
00007cd93bdd9b03  mov esi, 0x00
00007cd93bdd9b08  mov rax, 0x64A581057530
00007cd93bdd9b12  call rax
00007cd93bdd9b14  movaps xmm9, [rsp]
00007cd93bdd9b19  add rsp, 0x30
00007cd93bdd9b1d  vmovaps xmm0, [rsp]
00007cd93bdd9b22  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9b28  vmovaps xmm2, [rsp+0x20]
00007cd93bdd9b2e  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9b34  vmovaps xmm4, [rsp+0x40]
00007cd93bdd9b3a  vmovaps xmm5, [rsp+0x50]
00007cd93bdd9b40  vmovaps xmm6, [rsp+0x60]
00007cd93bdd9b46  vmovaps xmm7, [rsp+0x70]
00007cd93bdd9b4c  vmovaps xmm8, [rsp+0x80]
00007cd93bdd9b55  vmovaps xmm10, [rsp+0x90]
00007cd93bdd9b5e  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd9b67  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd9b70  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd9b79  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd9b82  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd9b8b  add rsp, 0xF0
00007cd93bdd9b92  pop r11
00007cd93bdd9b94  pop r10
00007cd93bdd9b96  pop r9
00007cd93bdd9b98  pop r8
00007cd93bdd9b9a  pop rsi
00007cd93bdd9b9b  pop rdi
00007cd93bdd9b9c  pop rdx
00007cd93bdd9b9d  pop rcx
00007cd93bdd9b9e  pop rax
00007cd93bdd9b9f  add rsp, 0x08
00007cd93bdd9ba3  jmp 0x00007CD93BDD6352
00007cd93bdd9ba8  sub rsp, 0x08
00007cd93bdd9bac  push rax
00007cd93bdd9bad  push rcx
00007cd93bdd9bae  push rdx
00007cd93bdd9baf  push rdi
00007cd93bdd9bb0  push rsi
00007cd93bdd9bb1  push r8
00007cd93bdd9bb3  push r9
00007cd93bdd9bb5  push r10
00007cd93bdd9bb7  push r11
00007cd93bdd9bb9  sub rsp, 0xF0
00007cd93bdd9bc0  vmovaps [rsp], xmm0
00007cd93bdd9bc5  vmovaps [rsp+0x10], xmm1
00007cd93bdd9bcb  vmovaps [rsp+0x20], xmm2
00007cd93bdd9bd1  vmovaps [rsp+0x30], xmm3
00007cd93bdd9bd7  vmovaps [rsp+0x40], xmm4
00007cd93bdd9bdd  vmovaps [rsp+0x50], xmm5
00007cd93bdd9be3  vmovaps [rsp+0x60], xmm6
00007cd93bdd9be9  vmovaps [rsp+0x70], xmm7
00007cd93bdd9bef  vmovaps [rsp+0x80], xmm8
00007cd93bdd9bf8  vmovaps [rsp+0x90], xmm9
00007cd93bdd9c01  vmovaps [rsp+0xA0], xmm10
00007cd93bdd9c0a  vmovaps [rsp+0xB0], xmm12
00007cd93bdd9c13  vmovaps [rsp+0xC0], xmm13
00007cd93bdd9c1c  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9c25  vmovaps [rsp+0xE0], xmm15
00007cd93bdd9c2e  sub rsp, 0x30
00007cd93bdd9c32  movaps [rsp], xmm11
00007cd93bdd9c37  movaps [rsp+0x10], xmm10
00007cd93bdd9c3d  movaps [rsp+0x20], xmm6
00007cd93bdd9c42  lea rdi, [rsp]
00007cd93bdd9c46  mov esi, 0x00
00007cd93bdd9c4b  mov rax, 0x64A581057530
00007cd93bdd9c55  call rax
00007cd93bdd9c57  movaps xmm11, [rsp]
00007cd93bdd9c5c  add rsp, 0x30
00007cd93bdd9c60  vmovaps xmm0, [rsp]
00007cd93bdd9c65  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9c6b  vmovaps xmm2, [rsp+0x20]
00007cd93bdd9c71  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9c77  vmovaps xmm4, [rsp+0x40]
00007cd93bdd9c7d  vmovaps xmm5, [rsp+0x50]
00007cd93bdd9c83  vmovaps xmm6, [rsp+0x60]
00007cd93bdd9c89  vmovaps xmm7, [rsp+0x70]
00007cd93bdd9c8f  vmovaps xmm8, [rsp+0x80]
00007cd93bdd9c98  vmovaps xmm9, [rsp+0x90]
00007cd93bdd9ca1  vmovaps xmm10, [rsp+0xA0]
00007cd93bdd9caa  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd9cb3  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd9cbc  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd9cc5  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd9cce  add rsp, 0xF0
00007cd93bdd9cd5  pop r11
00007cd93bdd9cd7  pop r10
00007cd93bdd9cd9  pop r9
00007cd93bdd9cdb  pop r8
00007cd93bdd9cdd  pop rsi
00007cd93bdd9cde  pop rdi
00007cd93bdd9cdf  pop rdx
00007cd93bdd9ce0  pop rcx
00007cd93bdd9ce1  pop rax
00007cd93bdd9ce2  add rsp, 0x08
00007cd93bdd9ce6  jmp 0x00007CD93BDD636D
00007cd93bdd9ceb  sub rsp, 0x08
00007cd93bdd9cef  push rax
00007cd93bdd9cf0  push rcx
00007cd93bdd9cf1  push rdx
00007cd93bdd9cf2  push rdi
00007cd93bdd9cf3  push rsi
00007cd93bdd9cf4  push r8
00007cd93bdd9cf6  push r9
00007cd93bdd9cf8  push r10
00007cd93bdd9cfa  push r11
00007cd93bdd9cfc  sub rsp, 0xF0
00007cd93bdd9d03  vmovaps [rsp], xmm0
00007cd93bdd9d08  vmovaps [rsp+0x10], xmm1
00007cd93bdd9d0e  vmovaps [rsp+0x20], xmm2
00007cd93bdd9d14  vmovaps [rsp+0x30], xmm3
00007cd93bdd9d1a  vmovaps [rsp+0x40], xmm4
00007cd93bdd9d20  vmovaps [rsp+0x50], xmm5
00007cd93bdd9d26  vmovaps [rsp+0x60], xmm6
00007cd93bdd9d2c  vmovaps [rsp+0x70], xmm7
00007cd93bdd9d32  vmovaps [rsp+0x80], xmm8
00007cd93bdd9d3b  vmovaps [rsp+0x90], xmm9
00007cd93bdd9d44  vmovaps [rsp+0xA0], xmm11
00007cd93bdd9d4d  vmovaps [rsp+0xB0], xmm12
00007cd93bdd9d56  vmovaps [rsp+0xC0], xmm13
00007cd93bdd9d5f  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9d68  vmovaps [rsp+0xE0], xmm15
00007cd93bdd9d71  sub rsp, 0x30
00007cd93bdd9d75  movaps [rsp], xmm10
00007cd93bdd9d7a  movaps [rsp+0x10], xmm14
00007cd93bdd9d80  movaps [rsp+0x20], xmm4
00007cd93bdd9d85  lea rdi, [rsp]
00007cd93bdd9d89  mov esi, 0x00
00007cd93bdd9d8e  mov rax, 0x64A581057530
00007cd93bdd9d98  call rax
00007cd93bdd9d9a  movaps xmm10, [rsp]
00007cd93bdd9d9f  add rsp, 0x30
00007cd93bdd9da3  vmovaps xmm0, [rsp]
00007cd93bdd9da8  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9dae  vmovaps xmm2, [rsp+0x20]
00007cd93bdd9db4  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9dba  vmovaps xmm4, [rsp+0x40]
00007cd93bdd9dc0  vmovaps xmm5, [rsp+0x50]
00007cd93bdd9dc6  vmovaps xmm6, [rsp+0x60]
00007cd93bdd9dcc  vmovaps xmm7, [rsp+0x70]
00007cd93bdd9dd2  vmovaps xmm8, [rsp+0x80]
00007cd93bdd9ddb  vmovaps xmm9, [rsp+0x90]
00007cd93bdd9de4  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd9ded  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd9df6  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd9dff  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd9e08  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd9e11  add rsp, 0xF0
00007cd93bdd9e18  pop r11
00007cd93bdd9e1a  pop r10
00007cd93bdd9e1c  pop r9
00007cd93bdd9e1e  pop r8
00007cd93bdd9e20  pop rsi
00007cd93bdd9e21  pop rdi
00007cd93bdd9e22  pop rdx
00007cd93bdd9e23  pop rcx
00007cd93bdd9e24  pop rax
00007cd93bdd9e25  add rsp, 0x08
00007cd93bdd9e29  jmp 0x00007CD93BDD6388
00007cd93bdd9e2e  sub rsp, 0x08
00007cd93bdd9e32  push rax
00007cd93bdd9e33  push rcx
00007cd93bdd9e34  push rdx
00007cd93bdd9e35  push rdi
00007cd93bdd9e36  push rsi
00007cd93bdd9e37  push r8
00007cd93bdd9e39  push r9
00007cd93bdd9e3b  push r10
00007cd93bdd9e3d  push r11
00007cd93bdd9e3f  sub rsp, 0xF0
00007cd93bdd9e46  vmovaps [rsp], xmm0
00007cd93bdd9e4b  vmovaps [rsp+0x10], xmm1
00007cd93bdd9e51  vmovaps [rsp+0x20], xmm2
00007cd93bdd9e57  vmovaps [rsp+0x30], xmm3
00007cd93bdd9e5d  vmovaps [rsp+0x40], xmm4
00007cd93bdd9e63  vmovaps [rsp+0x50], xmm5
00007cd93bdd9e69  vmovaps [rsp+0x60], xmm6
00007cd93bdd9e6f  vmovaps [rsp+0x70], xmm7
00007cd93bdd9e75  vmovaps [rsp+0x80], xmm9
00007cd93bdd9e7e  vmovaps [rsp+0x90], xmm10
00007cd93bdd9e87  vmovaps [rsp+0xA0], xmm11
00007cd93bdd9e90  vmovaps [rsp+0xB0], xmm12
00007cd93bdd9e99  vmovaps [rsp+0xC0], xmm13
00007cd93bdd9ea2  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9eab  vmovaps [rsp+0xE0], xmm15
00007cd93bdd9eb4  sub rsp, 0x30
00007cd93bdd9eb8  movaps [rsp], xmm8
00007cd93bdd9ebd  movaps [rsp+0x10], xmm1
00007cd93bdd9ec2  movaps [rsp+0x20], xmm14
00007cd93bdd9ec8  lea rdi, [rsp]
00007cd93bdd9ecc  mov esi, 0x00
00007cd93bdd9ed1  mov rax, 0x64A581057530
00007cd93bdd9edb  call rax
00007cd93bdd9edd  movaps xmm8, [rsp]
00007cd93bdd9ee2  add rsp, 0x30
00007cd93bdd9ee6  vmovaps xmm0, [rsp]
00007cd93bdd9eeb  vmovaps xmm1, [rsp+0x10]
00007cd93bdd9ef1  vmovaps xmm2, [rsp+0x20]
00007cd93bdd9ef7  vmovaps xmm3, [rsp+0x30]
00007cd93bdd9efd  vmovaps xmm4, [rsp+0x40]
00007cd93bdd9f03  vmovaps xmm5, [rsp+0x50]
00007cd93bdd9f09  vmovaps xmm6, [rsp+0x60]
00007cd93bdd9f0f  vmovaps xmm7, [rsp+0x70]
00007cd93bdd9f15  vmovaps xmm9, [rsp+0x80]
00007cd93bdd9f1e  vmovaps xmm10, [rsp+0x90]
00007cd93bdd9f27  vmovaps xmm11, [rsp+0xA0]
00007cd93bdd9f30  vmovaps xmm12, [rsp+0xB0]
00007cd93bdd9f39  vmovaps xmm13, [rsp+0xC0]
00007cd93bdd9f42  vmovaps xmm14, [rsp+0xD0]
00007cd93bdd9f4b  vmovaps xmm15, [rsp+0xE0]
00007cd93bdd9f54  add rsp, 0xF0
00007cd93bdd9f5b  pop r11
00007cd93bdd9f5d  pop r10
00007cd93bdd9f5f  pop r9
00007cd93bdd9f61  pop r8
00007cd93bdd9f63  pop rsi
00007cd93bdd9f64  pop rdi
00007cd93bdd9f65  pop rdx
00007cd93bdd9f66  pop rcx
00007cd93bdd9f67  pop rax
00007cd93bdd9f68  add rsp, 0x08
00007cd93bdd9f6c  jmp 0x00007CD93BDD63AE
00007cd93bdd9f71  sub rsp, 0x08
00007cd93bdd9f75  push rax
00007cd93bdd9f76  push rcx
00007cd93bdd9f77  push rdx
00007cd93bdd9f78  push rdi
00007cd93bdd9f79  push rsi
00007cd93bdd9f7a  push r8
00007cd93bdd9f7c  push r9
00007cd93bdd9f7e  push r10
00007cd93bdd9f80  push r11
00007cd93bdd9f82  sub rsp, 0xF0
00007cd93bdd9f89  vmovaps [rsp], xmm0
00007cd93bdd9f8e  vmovaps [rsp+0x10], xmm1
00007cd93bdd9f94  vmovaps [rsp+0x20], xmm2
00007cd93bdd9f9a  vmovaps [rsp+0x30], xmm3
00007cd93bdd9fa0  vmovaps [rsp+0x40], xmm4
00007cd93bdd9fa6  vmovaps [rsp+0x50], xmm5
00007cd93bdd9fac  vmovaps [rsp+0x60], xmm7
00007cd93bdd9fb2  vmovaps [rsp+0x70], xmm8
00007cd93bdd9fb8  vmovaps [rsp+0x80], xmm9
00007cd93bdd9fc1  vmovaps [rsp+0x90], xmm10
00007cd93bdd9fca  vmovaps [rsp+0xA0], xmm11
00007cd93bdd9fd3  vmovaps [rsp+0xB0], xmm12
00007cd93bdd9fdc  vmovaps [rsp+0xC0], xmm13
00007cd93bdd9fe5  vmovaps [rsp+0xD0], xmm14
00007cd93bdd9fee  vmovaps [rsp+0xE0], xmm15
00007cd93bdd9ff7  sub rsp, 0x30
00007cd93bdd9ffb  movaps [rsp], xmm6
00007cd93bdd9fff  movaps [rsp+0x10], xmm1
00007cd93bdda004  movaps [rsp+0x20], xmm14
00007cd93bdda00a  lea rdi, [rsp]
00007cd93bdda00e  mov esi, 0x00
00007cd93bdda013  mov rax, 0x64A581057530
00007cd93bdda01d  call rax
00007cd93bdda01f  movaps xmm6, [rsp]
00007cd93bdda023  add rsp, 0x30
00007cd93bdda027  vmovaps xmm0, [rsp]
00007cd93bdda02c  vmovaps xmm1, [rsp+0x10]
00007cd93bdda032  vmovaps xmm2, [rsp+0x20]
00007cd93bdda038  vmovaps xmm3, [rsp+0x30]
00007cd93bdda03e  vmovaps xmm4, [rsp+0x40]
00007cd93bdda044  vmovaps xmm5, [rsp+0x50]
00007cd93bdda04a  vmovaps xmm7, [rsp+0x60]
00007cd93bdda050  vmovaps xmm8, [rsp+0x70]
00007cd93bdda056  vmovaps xmm9, [rsp+0x80]
00007cd93bdda05f  vmovaps xmm10, [rsp+0x90]
00007cd93bdda068  vmovaps xmm11, [rsp+0xA0]
00007cd93bdda071  vmovaps xmm12, [rsp+0xB0]
00007cd93bdda07a  vmovaps xmm13, [rsp+0xC0]
00007cd93bdda083  vmovaps xmm14, [rsp+0xD0]
00007cd93bdda08c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdda095  add rsp, 0xF0
00007cd93bdda09c  pop r11
00007cd93bdda09e  pop r10
00007cd93bdda0a0  pop r9
00007cd93bdda0a2  pop r8
00007cd93bdda0a4  pop rsi
00007cd93bdda0a5  pop rdi
00007cd93bdda0a6  pop rdx
00007cd93bdda0a7  pop rcx
00007cd93bdda0a8  pop rax
00007cd93bdda0a9  add rsp, 0x08
00007cd93bdda0ad  jmp 0x00007CD93BDD63DA
00007cd93bdda0b2  sub rsp, 0x08
00007cd93bdda0b6  push rax
00007cd93bdda0b7  push rcx
00007cd93bdda0b8  push rdx
00007cd93bdda0b9  push rdi
00007cd93bdda0ba  push rsi
00007cd93bdda0bb  push r8
00007cd93bdda0bd  push r9
00007cd93bdda0bf  push r10
00007cd93bdda0c1  push r11
00007cd93bdda0c3  sub rsp, 0xF0
00007cd93bdda0ca  vmovaps [rsp], xmm0
00007cd93bdda0cf  vmovaps [rsp+0x10], xmm1
00007cd93bdda0d5  vmovaps [rsp+0x20], xmm2
00007cd93bdda0db  vmovaps [rsp+0x30], xmm3
00007cd93bdda0e1  vmovaps [rsp+0x40], xmm4
00007cd93bdda0e7  vmovaps [rsp+0x50], xmm5
00007cd93bdda0ed  vmovaps [rsp+0x60], xmm6
00007cd93bdda0f3  vmovaps [rsp+0x70], xmm7
00007cd93bdda0f9  vmovaps [rsp+0x80], xmm8
00007cd93bdda102  vmovaps [rsp+0x90], xmm9
00007cd93bdda10b  vmovaps [rsp+0xA0], xmm10
00007cd93bdda114  vmovaps [rsp+0xB0], xmm11
00007cd93bdda11d  vmovaps [rsp+0xC0], xmm12
00007cd93bdda126  vmovaps [rsp+0xD0], xmm13
00007cd93bdda12f  vmovaps [rsp+0xE0], xmm15
00007cd93bdda138  sub rsp, 0x30
00007cd93bdda13c  movaps [rsp], xmm14
00007cd93bdda141  movaps [rsp+0x10], xmm12
00007cd93bdda147  movaps [rsp+0x20], xmm1
00007cd93bdda14c  lea rdi, [rsp]
00007cd93bdda150  mov esi, 0x00
00007cd93bdda155  mov rax, 0x64A581057530
00007cd93bdda15f  call rax
00007cd93bdda161  movaps xmm14, [rsp]
00007cd93bdda166  add rsp, 0x30
00007cd93bdda16a  vmovaps xmm0, [rsp]
00007cd93bdda16f  vmovaps xmm1, [rsp+0x10]
00007cd93bdda175  vmovaps xmm2, [rsp+0x20]
00007cd93bdda17b  vmovaps xmm3, [rsp+0x30]
00007cd93bdda181  vmovaps xmm4, [rsp+0x40]
00007cd93bdda187  vmovaps xmm5, [rsp+0x50]
00007cd93bdda18d  vmovaps xmm6, [rsp+0x60]
00007cd93bdda193  vmovaps xmm7, [rsp+0x70]
00007cd93bdda199  vmovaps xmm8, [rsp+0x80]
00007cd93bdda1a2  vmovaps xmm9, [rsp+0x90]
00007cd93bdda1ab  vmovaps xmm10, [rsp+0xA0]
00007cd93bdda1b4  vmovaps xmm11, [rsp+0xB0]
00007cd93bdda1bd  vmovaps xmm12, [rsp+0xC0]
00007cd93bdda1c6  vmovaps xmm13, [rsp+0xD0]
00007cd93bdda1cf  vmovaps xmm15, [rsp+0xE0]
00007cd93bdda1d8  add rsp, 0xF0
00007cd93bdda1df  pop r11
00007cd93bdda1e1  pop r10
00007cd93bdda1e3  pop r9
00007cd93bdda1e5  pop r8
00007cd93bdda1e7  pop rsi
00007cd93bdda1e8  pop rdi
00007cd93bdda1e9  pop rdx
00007cd93bdda1ea  pop rcx
00007cd93bdda1eb  pop rax
00007cd93bdda1ec  add rsp, 0x08
00007cd93bdda1f0  jmp 0x00007CD93BDD6400
00007cd93bdda1f5  sub rsp, 0x08
00007cd93bdda1f9  push rax
00007cd93bdda1fa  push rcx
00007cd93bdda1fb  push rdx
00007cd93bdda1fc  push rdi
00007cd93bdda1fd  push rsi
00007cd93bdda1fe  push r8
00007cd93bdda200  push r9
00007cd93bdda202  push r10
00007cd93bdda204  push r11
00007cd93bdda206  sub rsp, 0xF0
00007cd93bdda20d  vmovaps [rsp], xmm0
00007cd93bdda212  vmovaps [rsp+0x10], xmm2
00007cd93bdda218  vmovaps [rsp+0x20], xmm3
00007cd93bdda21e  vmovaps [rsp+0x30], xmm4
00007cd93bdda224  vmovaps [rsp+0x40], xmm5
00007cd93bdda22a  vmovaps [rsp+0x50], xmm6
00007cd93bdda230  vmovaps [rsp+0x60], xmm7
00007cd93bdda236  vmovaps [rsp+0x70], xmm8
00007cd93bdda23c  vmovaps [rsp+0x80], xmm9
00007cd93bdda245  vmovaps [rsp+0x90], xmm10
00007cd93bdda24e  vmovaps [rsp+0xA0], xmm11
00007cd93bdda257  vmovaps [rsp+0xB0], xmm12
00007cd93bdda260  vmovaps [rsp+0xC0], xmm13
00007cd93bdda269  vmovaps [rsp+0xD0], xmm14
00007cd93bdda272  vmovaps [rsp+0xE0], xmm15
00007cd93bdda27b  sub rsp, 0x30
00007cd93bdda27f  movaps [rsp], xmm1
00007cd93bdda283  movaps [rsp+0x10], xmm13
00007cd93bdda289  movaps [rsp+0x20], xmm9
00007cd93bdda28f  lea rdi, [rsp]
00007cd93bdda293  mov esi, 0x00
00007cd93bdda298  mov rax, 0x64A581057530
00007cd93bdda2a2  call rax
00007cd93bdda2a4  movaps xmm1, [rsp]
00007cd93bdda2a8  add rsp, 0x30
00007cd93bdda2ac  vmovaps xmm0, [rsp]
00007cd93bdda2b1  vmovaps xmm2, [rsp+0x10]
00007cd93bdda2b7  vmovaps xmm3, [rsp+0x20]
00007cd93bdda2bd  vmovaps xmm4, [rsp+0x30]
00007cd93bdda2c3  vmovaps xmm5, [rsp+0x40]
00007cd93bdda2c9  vmovaps xmm6, [rsp+0x50]
00007cd93bdda2cf  vmovaps xmm7, [rsp+0x60]
00007cd93bdda2d5  vmovaps xmm8, [rsp+0x70]
00007cd93bdda2db  vmovaps xmm9, [rsp+0x80]
00007cd93bdda2e4  vmovaps xmm10, [rsp+0x90]
00007cd93bdda2ed  vmovaps xmm11, [rsp+0xA0]
00007cd93bdda2f6  vmovaps xmm12, [rsp+0xB0]
00007cd93bdda2ff  vmovaps xmm13, [rsp+0xC0]
00007cd93bdda308  vmovaps xmm14, [rsp+0xD0]
00007cd93bdda311  vmovaps xmm15, [rsp+0xE0]
00007cd93bdda31a  add rsp, 0xF0
00007cd93bdda321  pop r11
00007cd93bdda323  pop r10
00007cd93bdda325  pop r9
00007cd93bdda327  pop r8
00007cd93bdda329  pop rsi
00007cd93bdda32a  pop rdi
00007cd93bdda32b  pop rdx
00007cd93bdda32c  pop rcx
00007cd93bdda32d  pop rax
00007cd93bdda32e  add rsp, 0x08
00007cd93bdda332  jmp 0x00007CD93BDD641A
00007cd93bdda337  sub rsp, 0x08
00007cd93bdda33b  push rax
00007cd93bdda33c  push rcx
00007cd93bdda33d  push rdx
00007cd93bdda33e  push rdi
00007cd93bdda33f  push rsi
00007cd93bdda340  push r8
00007cd93bdda342  push r9
00007cd93bdda344  push r10
00007cd93bdda346  push r11
00007cd93bdda348  sub rsp, 0xF0
00007cd93bdda34f  vmovaps [rsp], xmm0
00007cd93bdda354  vmovaps [rsp+0x10], xmm1
00007cd93bdda35a  vmovaps [rsp+0x20], xmm2
00007cd93bdda360  vmovaps [rsp+0x30], xmm3
00007cd93bdda366  vmovaps [rsp+0x40], xmm4
00007cd93bdda36c  vmovaps [rsp+0x50], xmm5
00007cd93bdda372  vmovaps [rsp+0x60], xmm6
00007cd93bdda378  vmovaps [rsp+0x70], xmm7
00007cd93bdda37e  vmovaps [rsp+0x80], xmm8
00007cd93bdda387  vmovaps [rsp+0x90], xmm9
00007cd93bdda390  vmovaps [rsp+0xA0], xmm10
00007cd93bdda399  vmovaps [rsp+0xB0], xmm11
00007cd93bdda3a2  vmovaps [rsp+0xC0], xmm13
00007cd93bdda3ab  vmovaps [rsp+0xD0], xmm14
00007cd93bdda3b4  vmovaps [rsp+0xE0], xmm15
00007cd93bdda3bd  sub rsp, 0x30
00007cd93bdda3c1  movaps [rsp], xmm12
00007cd93bdda3c6  movaps [rsp+0x10], xmm7
00007cd93bdda3cb  movaps [rsp+0x20], xmm13
00007cd93bdda3d1  lea rdi, [rsp]
00007cd93bdda3d5  mov esi, 0x00
00007cd93bdda3da  mov rax, 0x64A581057530
00007cd93bdda3e4  call rax
00007cd93bdda3e6  movaps xmm12, [rsp]
00007cd93bdda3eb  add rsp, 0x30
00007cd93bdda3ef  vmovaps xmm0, [rsp]
00007cd93bdda3f4  vmovaps xmm1, [rsp+0x10]
00007cd93bdda3fa  vmovaps xmm2, [rsp+0x20]
00007cd93bdda400  vmovaps xmm3, [rsp+0x30]
00007cd93bdda406  vmovaps xmm4, [rsp+0x40]
00007cd93bdda40c  vmovaps xmm5, [rsp+0x50]
00007cd93bdda412  vmovaps xmm6, [rsp+0x60]
00007cd93bdda418  vmovaps xmm7, [rsp+0x70]
00007cd93bdda41e  vmovaps xmm8, [rsp+0x80]
00007cd93bdda427  vmovaps xmm9, [rsp+0x90]
00007cd93bdda430  vmovaps xmm10, [rsp+0xA0]
00007cd93bdda439  vmovaps xmm11, [rsp+0xB0]
00007cd93bdda442  vmovaps xmm13, [rsp+0xC0]
00007cd93bdda44b  vmovaps xmm14, [rsp+0xD0]
00007cd93bdda454  vmovaps xmm15, [rsp+0xE0]
00007cd93bdda45d  add rsp, 0xF0
00007cd93bdda464  pop r11
00007cd93bdda466  pop r10
00007cd93bdda468  pop r9
00007cd93bdda46a  pop r8
00007cd93bdda46c  pop rsi
00007cd93bdda46d  pop rdi
00007cd93bdda46e  pop rdx
00007cd93bdda46f  pop rcx
00007cd93bdda470  pop rax
00007cd93bdda471  add rsp, 0x08
00007cd93bdda475  jmp 0x00007CD93BDD6441
00007cd93bdda47a  sub rsp, 0x08
00007cd93bdda47e  push rax
00007cd93bdda47f  push rcx
00007cd93bdda480  push rdx
00007cd93bdda481  push rdi
00007cd93bdda482  push rsi
00007cd93bdda483  push r8
00007cd93bdda485  push r9
00007cd93bdda487  push r10
00007cd93bdda489  push r11
00007cd93bdda48b  sub rsp, 0xF0
00007cd93bdda492  vmovaps [rsp], xmm0
00007cd93bdda497  vmovaps [rsp+0x10], xmm1
00007cd93bdda49d  vmovaps [rsp+0x20], xmm2
00007cd93bdda4a3  vmovaps [rsp+0x30], xmm3
00007cd93bdda4a9  vmovaps [rsp+0x40], xmm4
00007cd93bdda4af  vmovaps [rsp+0x50], xmm5
00007cd93bdda4b5  vmovaps [rsp+0x60], xmm6
00007cd93bdda4bb  vmovaps [rsp+0x70], xmm7
00007cd93bdda4c1  vmovaps [rsp+0x80], xmm8
00007cd93bdda4ca  vmovaps [rsp+0x90], xmm9
00007cd93bdda4d3  vmovaps [rsp+0xA0], xmm10
00007cd93bdda4dc  vmovaps [rsp+0xB0], xmm11
00007cd93bdda4e5  vmovaps [rsp+0xC0], xmm12
00007cd93bdda4ee  vmovaps [rsp+0xD0], xmm14
00007cd93bdda4f7  vmovaps [rsp+0xE0], xmm15
00007cd93bdda500  sub rsp, 0x30
00007cd93bdda504  movaps [rsp], xmm13
00007cd93bdda509  movaps [rsp+0x10], xmm15
00007cd93bdda50f  movaps [rsp+0x20], xmm8
00007cd93bdda515  lea rdi, [rsp]
00007cd93bdda519  mov esi, 0x00
00007cd93bdda51e  mov rax, 0x64A581057530
00007cd93bdda528  call rax
00007cd93bdda52a  movaps xmm13, [rsp]
00007cd93bdda52f  add rsp, 0x30
00007cd93bdda533  vmovaps xmm0, [rsp]
00007cd93bdda538  vmovaps xmm1, [rsp+0x10]
00007cd93bdda53e  vmovaps xmm2, [rsp+0x20]
00007cd93bdda544  vmovaps xmm3, [rsp+0x30]
00007cd93bdda54a  vmovaps xmm4, [rsp+0x40]
00007cd93bdda550  vmovaps xmm5, [rsp+0x50]
00007cd93bdda556  vmovaps xmm6, [rsp+0x60]
00007cd93bdda55c  vmovaps xmm7, [rsp+0x70]
00007cd93bdda562  vmovaps xmm8, [rsp+0x80]
00007cd93bdda56b  vmovaps xmm9, [rsp+0x90]
00007cd93bdda574  vmovaps xmm10, [rsp+0xA0]
00007cd93bdda57d  vmovaps xmm11, [rsp+0xB0]
00007cd93bdda586  vmovaps xmm12, [rsp+0xC0]
00007cd93bdda58f  vmovaps xmm14, [rsp+0xD0]
00007cd93bdda598  vmovaps xmm15, [rsp+0xE0]
00007cd93bdda5a1  add rsp, 0xF0
00007cd93bdda5a8  pop r11
00007cd93bdda5aa  pop r10
00007cd93bdda5ac  pop r9
00007cd93bdda5ae  pop r8
00007cd93bdda5b0  pop rsi
00007cd93bdda5b1  pop rdi
00007cd93bdda5b2  pop rdx
00007cd93bdda5b3  pop rcx
00007cd93bdda5b4  pop rax
00007cd93bdda5b5  add rsp, 0x08
00007cd93bdda5b9  jmp 0x00007CD93BDD645C
00007cd93bdda5be  sub rsp, 0x08
00007cd93bdda5c2  push rax
00007cd93bdda5c3  push rcx
00007cd93bdda5c4  push rdx
00007cd93bdda5c5  push rdi
00007cd93bdda5c6  push rsi
00007cd93bdda5c7  push r8
00007cd93bdda5c9  push r9
00007cd93bdda5cb  push r10
00007cd93bdda5cd  push r11
00007cd93bdda5cf  sub rsp, 0xF0
00007cd93bdda5d6  vmovaps [rsp], xmm0
00007cd93bdda5db  vmovaps [rsp+0x10], xmm1
00007cd93bdda5e1  vmovaps [rsp+0x20], xmm2
00007cd93bdda5e7  vmovaps [rsp+0x30], xmm3
00007cd93bdda5ed  vmovaps [rsp+0x40], xmm4
00007cd93bdda5f3  vmovaps [rsp+0x50], xmm5
00007cd93bdda5f9  vmovaps [rsp+0x60], xmm6
00007cd93bdda5ff  vmovaps [rsp+0x70], xmm7
00007cd93bdda605  vmovaps [rsp+0x80], xmm9
00007cd93bdda60e  vmovaps [rsp+0x90], xmm10
00007cd93bdda617  vmovaps [rsp+0xA0], xmm11
00007cd93bdda620  vmovaps [rsp+0xB0], xmm12
00007cd93bdda629  vmovaps [rsp+0xC0], xmm13
00007cd93bdda632  vmovaps [rsp+0xD0], xmm14
00007cd93bdda63b  vmovaps [rsp+0xE0], xmm15
00007cd93bdda644  sub rsp, 0x30
00007cd93bdda648  movaps [rsp], xmm8
00007cd93bdda64d  movaps [rsp+0x10], xmm15
00007cd93bdda653  movaps [rsp+0x20], xmm9
00007cd93bdda659  lea rdi, [rsp]
00007cd93bdda65d  mov esi, 0x00
00007cd93bdda662  mov rax, 0x64A581057530
00007cd93bdda66c  call rax
00007cd93bdda66e  movaps xmm8, [rsp]
00007cd93bdda673  add rsp, 0x30
00007cd93bdda677  vmovaps xmm0, [rsp]
00007cd93bdda67c  vmovaps xmm1, [rsp+0x10]
00007cd93bdda682  vmovaps xmm2, [rsp+0x20]
00007cd93bdda688  vmovaps xmm3, [rsp+0x30]
00007cd93bdda68e  vmovaps xmm4, [rsp+0x40]
00007cd93bdda694  vmovaps xmm5, [rsp+0x50]
00007cd93bdda69a  vmovaps xmm6, [rsp+0x60]
00007cd93bdda6a0  vmovaps xmm7, [rsp+0x70]
00007cd93bdda6a6  vmovaps xmm9, [rsp+0x80]
00007cd93bdda6af  vmovaps xmm10, [rsp+0x90]
00007cd93bdda6b8  vmovaps xmm11, [rsp+0xA0]
00007cd93bdda6c1  vmovaps xmm12, [rsp+0xB0]
00007cd93bdda6ca  vmovaps xmm13, [rsp+0xC0]
00007cd93bdda6d3  vmovaps xmm14, [rsp+0xD0]
00007cd93bdda6dc  vmovaps xmm15, [rsp+0xE0]
00007cd93bdda6e5  add rsp, 0xF0
00007cd93bdda6ec  pop r11
00007cd93bdda6ee  pop r10
00007cd93bdda6f0  pop r9
00007cd93bdda6f2  pop r8
00007cd93bdda6f4  pop rsi
00007cd93bdda6f5  pop rdi
00007cd93bdda6f6  pop rdx
00007cd93bdda6f7  pop rcx
00007cd93bdda6f8  pop rax
00007cd93bdda6f9  add rsp, 0x08
00007cd93bdda6fd  jmp 0x00007CD93BDD648A
00007cd93bdda702  sub rsp, 0x08
00007cd93bdda706  push rax
00007cd93bdda707  push rcx
00007cd93bdda708  push rdx
00007cd93bdda709  push rdi
00007cd93bdda70a  push rsi
00007cd93bdda70b  push r8
00007cd93bdda70d  push r9
00007cd93bdda70f  push r10
00007cd93bdda711  push r11
00007cd93bdda713  sub rsp, 0xF0
00007cd93bdda71a  vmovaps [rsp], xmm0
00007cd93bdda71f  vmovaps [rsp+0x10], xmm1
00007cd93bdda725  vmovaps [rsp+0x20], xmm2
00007cd93bdda72b  vmovaps [rsp+0x30], xmm3
00007cd93bdda731  vmovaps [rsp+0x40], xmm4
00007cd93bdda737  vmovaps [rsp+0x50], xmm5
00007cd93bdda73d  vmovaps [rsp+0x60], xmm6
00007cd93bdda743  vmovaps [rsp+0x70], xmm7
00007cd93bdda749  vmovaps [rsp+0x80], xmm8
00007cd93bdda752  vmovaps [rsp+0x90], xmm9
00007cd93bdda75b  vmovaps [rsp+0xA0], xmm10
00007cd93bdda764  vmovaps [rsp+0xB0], xmm11
00007cd93bdda76d  vmovaps [rsp+0xC0], xmm12
00007cd93bdda776  vmovaps [rsp+0xD0], xmm13
00007cd93bdda77f  vmovaps [rsp+0xE0], xmm14
00007cd93bdda788  sub rsp, 0x30
00007cd93bdda78c  movaps [rsp], xmm15
00007cd93bdda791  movaps [rsp+0x10], xmm11
00007cd93bdda797  movaps [rsp+0x20], xmm6
00007cd93bdda79c  lea rdi, [rsp]
00007cd93bdda7a0  mov esi, 0x00
00007cd93bdda7a5  mov rax, 0x64A581057530
00007cd93bdda7af  call rax
00007cd93bdda7b1  movaps xmm15, [rsp]
00007cd93bdda7b6  add rsp, 0x30
00007cd93bdda7ba  vmovaps xmm0, [rsp]
00007cd93bdda7bf  vmovaps xmm1, [rsp+0x10]
00007cd93bdda7c5  vmovaps xmm2, [rsp+0x20]
00007cd93bdda7cb  vmovaps xmm3, [rsp+0x30]
00007cd93bdda7d1  vmovaps xmm4, [rsp+0x40]
00007cd93bdda7d7  vmovaps xmm5, [rsp+0x50]
00007cd93bdda7dd  vmovaps xmm6, [rsp+0x60]
00007cd93bdda7e3  vmovaps xmm7, [rsp+0x70]
00007cd93bdda7e9  vmovaps xmm8, [rsp+0x80]
00007cd93bdda7f2  vmovaps xmm9, [rsp+0x90]
00007cd93bdda7fb  vmovaps xmm10, [rsp+0xA0]
00007cd93bdda804  vmovaps xmm11, [rsp+0xB0]
00007cd93bdda80d  vmovaps xmm12, [rsp+0xC0]
00007cd93bdda816  vmovaps xmm13, [rsp+0xD0]
00007cd93bdda81f  vmovaps xmm14, [rsp+0xE0]
00007cd93bdda828  add rsp, 0xF0
00007cd93bdda82f  pop r11
00007cd93bdda831  pop r10
00007cd93bdda833  pop r9
00007cd93bdda835  pop r8
00007cd93bdda837  pop rsi
00007cd93bdda838  pop rdi
00007cd93bdda839  pop rdx
00007cd93bdda83a  pop rcx
00007cd93bdda83b  pop rax
00007cd93bdda83c  add rsp, 0x08
00007cd93bdda840  jmp 0x00007CD93BDD64A5
00007cd93bdda845  sub rsp, 0x08
00007cd93bdda849  push rax
00007cd93bdda84a  push rcx
00007cd93bdda84b  push rdx
00007cd93bdda84c  push rdi
00007cd93bdda84d  push rsi
00007cd93bdda84e  push r8
00007cd93bdda850  push r9
00007cd93bdda852  push r10
00007cd93bdda854  push r11
00007cd93bdda856  sub rsp, 0xF0
00007cd93bdda85d  vmovaps [rsp], xmm0
00007cd93bdda862  vmovaps [rsp+0x10], xmm1
00007cd93bdda868  vmovaps [rsp+0x20], xmm2
00007cd93bdda86e  vmovaps [rsp+0x30], xmm3
00007cd93bdda874  vmovaps [rsp+0x40], xmm4
00007cd93bdda87a  vmovaps [rsp+0x50], xmm5
00007cd93bdda880  vmovaps [rsp+0x60], xmm6
00007cd93bdda886  vmovaps [rsp+0x70], xmm8
00007cd93bdda88c  vmovaps [rsp+0x80], xmm9
00007cd93bdda895  vmovaps [rsp+0x90], xmm10
00007cd93bdda89e  vmovaps [rsp+0xA0], xmm11
00007cd93bdda8a7  vmovaps [rsp+0xB0], xmm12
00007cd93bdda8b0  vmovaps [rsp+0xC0], xmm13
00007cd93bdda8b9  vmovaps [rsp+0xD0], xmm14
00007cd93bdda8c2  vmovaps [rsp+0xE0], xmm15
00007cd93bdda8cb  sub rsp, 0x30
00007cd93bdda8cf  movaps [rsp], xmm7
00007cd93bdda8d3  movaps [rsp+0x10], xmm11
00007cd93bdda8d9  movaps [rsp+0x20], xmm9
00007cd93bdda8df  lea rdi, [rsp]
00007cd93bdda8e3  mov esi, 0x00
00007cd93bdda8e8  mov rax, 0x64A581057530
00007cd93bdda8f2  call rax
00007cd93bdda8f4  movaps xmm7, [rsp]
00007cd93bdda8f8  add rsp, 0x30
00007cd93bdda8fc  vmovaps xmm0, [rsp]
00007cd93bdda901  vmovaps xmm1, [rsp+0x10]
00007cd93bdda907  vmovaps xmm2, [rsp+0x20]
00007cd93bdda90d  vmovaps xmm3, [rsp+0x30]
00007cd93bdda913  vmovaps xmm4, [rsp+0x40]
00007cd93bdda919  vmovaps xmm5, [rsp+0x50]
00007cd93bdda91f  vmovaps xmm6, [rsp+0x60]
00007cd93bdda925  vmovaps xmm8, [rsp+0x70]
00007cd93bdda92b  vmovaps xmm9, [rsp+0x80]
00007cd93bdda934  vmovaps xmm10, [rsp+0x90]
00007cd93bdda93d  vmovaps xmm11, [rsp+0xA0]
00007cd93bdda946  vmovaps xmm12, [rsp+0xB0]
00007cd93bdda94f  vmovaps xmm13, [rsp+0xC0]
00007cd93bdda958  vmovaps xmm14, [rsp+0xD0]
00007cd93bdda961  vmovaps xmm15, [rsp+0xE0]
00007cd93bdda96a  add rsp, 0xF0
00007cd93bdda971  pop r11
00007cd93bdda973  pop r10
00007cd93bdda975  pop r9
00007cd93bdda977  pop r8
00007cd93bdda979  pop rsi
00007cd93bdda97a  pop rdi
00007cd93bdda97b  pop rdx
00007cd93bdda97c  pop rcx
00007cd93bdda97d  pop rax
00007cd93bdda97e  add rsp, 0x08
00007cd93bdda982  jmp 0x00007CD93BDD64D2
00007cd93bdda987  sub rsp, 0x08
00007cd93bdda98b  push rax
00007cd93bdda98c  push rcx
00007cd93bdda98d  push rdx
00007cd93bdda98e  push rdi
00007cd93bdda98f  push rsi
00007cd93bdda990  push r8
00007cd93bdda992  push r9
00007cd93bdda994  push r10
00007cd93bdda996  push r11
00007cd93bdda998  sub rsp, 0xF0
00007cd93bdda99f  vmovaps [rsp], xmm0
00007cd93bdda9a4  vmovaps [rsp+0x10], xmm1
00007cd93bdda9aa  vmovaps [rsp+0x20], xmm2
00007cd93bdda9b0  vmovaps [rsp+0x30], xmm3
00007cd93bdda9b6  vmovaps [rsp+0x40], xmm4
00007cd93bdda9bc  vmovaps [rsp+0x50], xmm5
00007cd93bdda9c2  vmovaps [rsp+0x60], xmm6
00007cd93bdda9c8  vmovaps [rsp+0x70], xmm7
00007cd93bdda9ce  vmovaps [rsp+0x80], xmm8
00007cd93bdda9d7  vmovaps [rsp+0x90], xmm9
00007cd93bdda9e0  vmovaps [rsp+0xA0], xmm10
00007cd93bdda9e9  vmovaps [rsp+0xB0], xmm12
00007cd93bdda9f2  vmovaps [rsp+0xC0], xmm13
00007cd93bdda9fb  vmovaps [rsp+0xD0], xmm14
00007cd93bddaa04  vmovaps [rsp+0xE0], xmm15
00007cd93bddaa0d  sub rsp, 0x30
00007cd93bddaa11  movaps [rsp], xmm11
00007cd93bddaa16  movaps [rsp+0x10], xmm10
00007cd93bddaa1c  movaps [rsp+0x20], xmm14
00007cd93bddaa22  lea rdi, [rsp]
00007cd93bddaa26  mov esi, 0x00
00007cd93bddaa2b  mov rax, 0x64A581057530
00007cd93bddaa35  call rax
00007cd93bddaa37  movaps xmm11, [rsp]
00007cd93bddaa3c  add rsp, 0x30
00007cd93bddaa40  vmovaps xmm0, [rsp]
00007cd93bddaa45  vmovaps xmm1, [rsp+0x10]
00007cd93bddaa4b  vmovaps xmm2, [rsp+0x20]
00007cd93bddaa51  vmovaps xmm3, [rsp+0x30]
00007cd93bddaa57  vmovaps xmm4, [rsp+0x40]
00007cd93bddaa5d  vmovaps xmm5, [rsp+0x50]
00007cd93bddaa63  vmovaps xmm6, [rsp+0x60]
00007cd93bddaa69  vmovaps xmm7, [rsp+0x70]
00007cd93bddaa6f  vmovaps xmm8, [rsp+0x80]
00007cd93bddaa78  vmovaps xmm9, [rsp+0x90]
00007cd93bddaa81  vmovaps xmm10, [rsp+0xA0]
00007cd93bddaa8a  vmovaps xmm12, [rsp+0xB0]
00007cd93bddaa93  vmovaps xmm13, [rsp+0xC0]
00007cd93bddaa9c  vmovaps xmm14, [rsp+0xD0]
00007cd93bddaaa5  vmovaps xmm15, [rsp+0xE0]
00007cd93bddaaae  add rsp, 0xF0
00007cd93bddaab5  pop r11
00007cd93bddaab7  pop r10
00007cd93bddaab9  pop r9
00007cd93bddaabb  pop r8
00007cd93bddaabd  pop rsi
00007cd93bddaabe  pop rdi
00007cd93bddaabf  pop rdx
00007cd93bddaac0  pop rcx
00007cd93bddaac1  pop rax
00007cd93bddaac2  add rsp, 0x08
00007cd93bddaac6  jmp 0x00007CD93BDD64ED
00007cd93bddaacb  call 0x00007CD93BCE45A0
00007cd93bddaad0  jmp 0x00007CD93BDD64F7
00007cd93bddaad5  sub rsp, 0x08
00007cd93bddaad9  push rax
00007cd93bddaada  push rcx
00007cd93bddaadb  push rdx
00007cd93bddaadc  push rdi
00007cd93bddaadd  push rsi
00007cd93bddaade  push r8
00007cd93bddaae0  push r9
00007cd93bddaae2  push r10
00007cd93bddaae4  push r11
00007cd93bddaae6  sub rsp, 0xF0
00007cd93bddaaed  vmovaps [rsp], xmm0
00007cd93bddaaf2  vmovaps [rsp+0x10], xmm1
00007cd93bddaaf8  vmovaps [rsp+0x20], xmm2
00007cd93bddaafe  vmovaps [rsp+0x30], xmm3
00007cd93bddab04  vmovaps [rsp+0x40], xmm4
00007cd93bddab0a  vmovaps [rsp+0x50], xmm5
00007cd93bddab10  vmovaps [rsp+0x60], xmm6
00007cd93bddab16  vmovaps [rsp+0x70], xmm7
00007cd93bddab1c  vmovaps [rsp+0x80], xmm8
00007cd93bddab25  vmovaps [rsp+0x90], xmm9
00007cd93bddab2e  vmovaps [rsp+0xA0], xmm11
00007cd93bddab37  vmovaps [rsp+0xB0], xmm12
00007cd93bddab40  vmovaps [rsp+0xC0], xmm13
00007cd93bddab49  vmovaps [rsp+0xD0], xmm14
00007cd93bddab52  vmovaps [rsp+0xE0], xmm15
00007cd93bddab5b  sub rsp, 0x30
00007cd93bddab5f  movaps [rsp], xmm10
00007cd93bddab64  movaps [rsp+0x10], xmm1
00007cd93bddab69  movaps [rsp+0x20], xmm12
00007cd93bddab6f  lea rdi, [rsp]
00007cd93bddab73  mov esi, 0x00
00007cd93bddab78  mov rax, 0x64A581057530
00007cd93bddab82  call rax
00007cd93bddab84  movaps xmm10, [rsp]
00007cd93bddab89  add rsp, 0x30
00007cd93bddab8d  vmovaps xmm0, [rsp]
00007cd93bddab92  vmovaps xmm1, [rsp+0x10]
00007cd93bddab98  vmovaps xmm2, [rsp+0x20]
00007cd93bddab9e  vmovaps xmm3, [rsp+0x30]
00007cd93bddaba4  vmovaps xmm4, [rsp+0x40]
00007cd93bddabaa  vmovaps xmm5, [rsp+0x50]
00007cd93bddabb0  vmovaps xmm6, [rsp+0x60]
00007cd93bddabb6  vmovaps xmm7, [rsp+0x70]
00007cd93bddabbc  vmovaps xmm8, [rsp+0x80]
00007cd93bddabc5  vmovaps xmm9, [rsp+0x90]
00007cd93bddabce  vmovaps xmm11, [rsp+0xA0]
00007cd93bddabd7  vmovaps xmm12, [rsp+0xB0]
00007cd93bddabe0  vmovaps xmm13, [rsp+0xC0]
00007cd93bddabe9  vmovaps xmm14, [rsp+0xD0]
00007cd93bddabf2  vmovaps xmm15, [rsp+0xE0]
00007cd93bddabfb  add rsp, 0xF0
00007cd93bddac02  pop r11
00007cd93bddac04  pop r10
00007cd93bddac06  pop r9
00007cd93bddac08  pop r8
00007cd93bddac0a  pop rsi
00007cd93bddac0b  pop rdi
00007cd93bddac0c  pop rdx
00007cd93bddac0d  pop rcx
00007cd93bddac0e  pop rax
00007cd93bddac0f  add rsp, 0x08
00007cd93bddac13  jmp 0x00007CD93BDD651A
00007cd93bddac18  sub rsp, 0x08
00007cd93bddac1c  push rax
00007cd93bddac1d  push rcx
00007cd93bddac1e  push rdx
00007cd93bddac1f  push rdi
00007cd93bddac20  push rsi
00007cd93bddac21  push r8
00007cd93bddac23  push r9
00007cd93bddac25  push r10
00007cd93bddac27  push r11
00007cd93bddac29  sub rsp, 0xF0
00007cd93bddac30  vmovaps [rsp], xmm0
00007cd93bddac35  vmovaps [rsp+0x10], xmm1
00007cd93bddac3b  vmovaps [rsp+0x20], xmm2
00007cd93bddac41  vmovaps [rsp+0x30], xmm3
00007cd93bddac47  vmovaps [rsp+0x40], xmm4
00007cd93bddac4d  vmovaps [rsp+0x50], xmm5
00007cd93bddac53  vmovaps [rsp+0x60], xmm6
00007cd93bddac59  vmovaps [rsp+0x70], xmm7
00007cd93bddac5f  vmovaps [rsp+0x80], xmm8
00007cd93bddac68  vmovaps [rsp+0x90], xmm9
00007cd93bddac71  vmovaps [rsp+0xA0], xmm10
00007cd93bddac7a  vmovaps [rsp+0xB0], xmm11
00007cd93bddac83  vmovaps [rsp+0xC0], xmm13
00007cd93bddac8c  vmovaps [rsp+0xD0], xmm14
00007cd93bddac95  vmovaps [rsp+0xE0], xmm15
00007cd93bddac9e  sub rsp, 0x30
00007cd93bddaca2  movaps [rsp], xmm12
00007cd93bddaca7  movaps [rsp+0x10], xmm14
00007cd93bddacad  movaps [rsp+0x20], xmm1
00007cd93bddacb2  lea rdi, [rsp]
00007cd93bddacb6  mov esi, 0x00
00007cd93bddacbb  mov rax, 0x64A581057530
00007cd93bddacc5  call rax
00007cd93bddacc7  movaps xmm12, [rsp]
00007cd93bddaccc  add rsp, 0x30
00007cd93bddacd0  vmovaps xmm0, [rsp]
00007cd93bddacd5  vmovaps xmm1, [rsp+0x10]
00007cd93bddacdb  vmovaps xmm2, [rsp+0x20]
00007cd93bddace1  vmovaps xmm3, [rsp+0x30]
00007cd93bddace7  vmovaps xmm4, [rsp+0x40]
00007cd93bddaced  vmovaps xmm5, [rsp+0x50]
00007cd93bddacf3  vmovaps xmm6, [rsp+0x60]
00007cd93bddacf9  vmovaps xmm7, [rsp+0x70]
00007cd93bddacff  vmovaps xmm8, [rsp+0x80]
00007cd93bddad08  vmovaps xmm9, [rsp+0x90]
00007cd93bddad11  vmovaps xmm10, [rsp+0xA0]
00007cd93bddad1a  vmovaps xmm11, [rsp+0xB0]
00007cd93bddad23  vmovaps xmm13, [rsp+0xC0]
00007cd93bddad2c  vmovaps xmm14, [rsp+0xD0]
00007cd93bddad35  vmovaps xmm15, [rsp+0xE0]
00007cd93bddad3e  add rsp, 0xF0
00007cd93bddad45  pop r11
00007cd93bddad47  pop r10
00007cd93bddad49  pop r9
00007cd93bddad4b  pop r8
00007cd93bddad4d  pop rsi
00007cd93bddad4e  pop rdi
00007cd93bddad4f  pop rdx
00007cd93bddad50  pop rcx
00007cd93bddad51  pop rax
00007cd93bddad52  add rsp, 0x08
00007cd93bddad56  jmp 0x00007CD93BDD6549
00007cd93bddad5b  sub rsp, 0x08
00007cd93bddad5f  push rax
00007cd93bddad60  push rcx
00007cd93bddad61  push rdx
00007cd93bddad62  push rdi
00007cd93bddad63  push rsi
00007cd93bddad64  push r8
00007cd93bddad66  push r9
00007cd93bddad68  push r10
00007cd93bddad6a  push r11
00007cd93bddad6c  sub rsp, 0xF0
00007cd93bddad73  vmovaps [rsp], xmm0
00007cd93bddad78  vmovaps [rsp+0x10], xmm1
00007cd93bddad7e  vmovaps [rsp+0x20], xmm2
00007cd93bddad84  vmovaps [rsp+0x30], xmm3
00007cd93bddad8a  vmovaps [rsp+0x40], xmm4
00007cd93bddad90  vmovaps [rsp+0x50], xmm5
00007cd93bddad96  vmovaps [rsp+0x60], xmm6
00007cd93bddad9c  vmovaps [rsp+0x70], xmm7
00007cd93bddada2  vmovaps [rsp+0x80], xmm8
00007cd93bddadab  vmovaps [rsp+0x90], xmm9
00007cd93bddadb4  vmovaps [rsp+0xA0], xmm10
00007cd93bddadbd  vmovaps [rsp+0xB0], xmm11
00007cd93bddadc6  vmovaps [rsp+0xC0], xmm12
00007cd93bddadcf  vmovaps [rsp+0xD0], xmm13
00007cd93bddadd8  vmovaps [rsp+0xE0], xmm15
00007cd93bddade1  sub rsp, 0x30
00007cd93bddade5  movaps [rsp], xmm14
00007cd93bddadea  movaps [rsp+0x10], xmm9
00007cd93bddadf0  movaps [rsp+0x20], xmm1
00007cd93bddadf5  lea rdi, [rsp]
00007cd93bddadf9  mov esi, 0x00
00007cd93bddadfe  mov rax, 0x64A581057530
00007cd93bddae08  call rax
00007cd93bddae0a  movaps xmm14, [rsp]
00007cd93bddae0f  add rsp, 0x30
00007cd93bddae13  vmovaps xmm0, [rsp]
00007cd93bddae18  vmovaps xmm1, [rsp+0x10]
00007cd93bddae1e  vmovaps xmm2, [rsp+0x20]
00007cd93bddae24  vmovaps xmm3, [rsp+0x30]
00007cd93bddae2a  vmovaps xmm4, [rsp+0x40]
00007cd93bddae30  vmovaps xmm5, [rsp+0x50]
00007cd93bddae36  vmovaps xmm6, [rsp+0x60]
00007cd93bddae3c  vmovaps xmm7, [rsp+0x70]
00007cd93bddae42  vmovaps xmm8, [rsp+0x80]
00007cd93bddae4b  vmovaps xmm9, [rsp+0x90]
00007cd93bddae54  vmovaps xmm10, [rsp+0xA0]
00007cd93bddae5d  vmovaps xmm11, [rsp+0xB0]
00007cd93bddae66  vmovaps xmm12, [rsp+0xC0]
00007cd93bddae6f  vmovaps xmm13, [rsp+0xD0]
00007cd93bddae78  vmovaps xmm15, [rsp+0xE0]
00007cd93bddae81  add rsp, 0xF0
00007cd93bddae88  pop r11
00007cd93bddae8a  pop r10
00007cd93bddae8c  pop r9
00007cd93bddae8e  pop r8
00007cd93bddae90  pop rsi
00007cd93bddae91  pop rdi
00007cd93bddae92  pop rdx
00007cd93bddae93  pop rcx
00007cd93bddae94  pop rax
00007cd93bddae95  add rsp, 0x08
00007cd93bddae99  jmp 0x00007CD93BDD6578
00007cd93bddae9e  sub rsp, 0x08
00007cd93bddaea2  push rax
00007cd93bddaea3  push rcx
00007cd93bddaea4  push rdx
00007cd93bddaea5  push rdi
00007cd93bddaea6  push rsi
00007cd93bddaea7  push r8
00007cd93bddaea9  push r9
00007cd93bddaeab  push r10
00007cd93bddaead  push r11
00007cd93bddaeaf  sub rsp, 0xF0
00007cd93bddaeb6  vmovaps [rsp], xmm0
00007cd93bddaebb  vmovaps [rsp+0x10], xmm2
00007cd93bddaec1  vmovaps [rsp+0x20], xmm3
00007cd93bddaec7  vmovaps [rsp+0x30], xmm4
00007cd93bddaecd  vmovaps [rsp+0x40], xmm5
00007cd93bddaed3  vmovaps [rsp+0x50], xmm6
00007cd93bddaed9  vmovaps [rsp+0x60], xmm7
00007cd93bddaedf  vmovaps [rsp+0x70], xmm8
00007cd93bddaee5  vmovaps [rsp+0x80], xmm9
00007cd93bddaeee  vmovaps [rsp+0x90], xmm10
00007cd93bddaef7  vmovaps [rsp+0xA0], xmm11
00007cd93bddaf00  vmovaps [rsp+0xB0], xmm12
00007cd93bddaf09  vmovaps [rsp+0xC0], xmm13
00007cd93bddaf12  vmovaps [rsp+0xD0], xmm14
00007cd93bddaf1b  vmovaps [rsp+0xE0], xmm15
00007cd93bddaf24  sub rsp, 0x30
00007cd93bddaf28  movaps [rsp], xmm1
00007cd93bddaf2c  movaps [rsp+0x10], xmm13
00007cd93bddaf32  movaps [rsp+0x20], xmm8
00007cd93bddaf38  lea rdi, [rsp]
00007cd93bddaf3c  mov esi, 0x00
00007cd93bddaf41  mov rax, 0x64A581057530
00007cd93bddaf4b  call rax
00007cd93bddaf4d  movaps xmm1, [rsp]
00007cd93bddaf51  add rsp, 0x30
00007cd93bddaf55  vmovaps xmm0, [rsp]
00007cd93bddaf5a  vmovaps xmm2, [rsp+0x10]
00007cd93bddaf60  vmovaps xmm3, [rsp+0x20]
00007cd93bddaf66  vmovaps xmm4, [rsp+0x30]
00007cd93bddaf6c  vmovaps xmm5, [rsp+0x40]
00007cd93bddaf72  vmovaps xmm6, [rsp+0x50]
00007cd93bddaf78  vmovaps xmm7, [rsp+0x60]
00007cd93bddaf7e  vmovaps xmm8, [rsp+0x70]
00007cd93bddaf84  vmovaps xmm9, [rsp+0x80]
00007cd93bddaf8d  vmovaps xmm10, [rsp+0x90]
00007cd93bddaf96  vmovaps xmm11, [rsp+0xA0]
00007cd93bddaf9f  vmovaps xmm12, [rsp+0xB0]
00007cd93bddafa8  vmovaps xmm13, [rsp+0xC0]
00007cd93bddafb1  vmovaps xmm14, [rsp+0xD0]
00007cd93bddafba  vmovaps xmm15, [rsp+0xE0]
00007cd93bddafc3  add rsp, 0xF0
00007cd93bddafca  pop r11
00007cd93bddafcc  pop r10
00007cd93bddafce  pop r9
00007cd93bddafd0  pop r8
00007cd93bddafd2  pop rsi
00007cd93bddafd3  pop rdi
00007cd93bddafd4  pop rdx
00007cd93bddafd5  pop rcx
00007cd93bddafd6  pop rax
00007cd93bddafd7  add rsp, 0x08
00007cd93bddafdb  jmp 0x00007CD93BDD659A
00007cd93bddafe0  call 0x00007CD93BC0C260
00007cd93bddafe5  jmp 0x00007CD93BDD65A8
00007cd93bddafea  call 0x00007CD93BCDE950
00007cd93bddafef  jmp 0x00007CD93BDD65B2
00007cd93bddaff4  sub rsp, 0x08
00007cd93bddaff8  push rax
00007cd93bddaff9  push rcx
00007cd93bddaffa  push rdx
00007cd93bddaffb  push rdi
00007cd93bddaffc  push rsi
00007cd93bddaffd  push r8
00007cd93bddafff  push r9
00007cd93bddb001  push r10
00007cd93bddb003  push r11
00007cd93bddb005  sub rsp, 0xF0
00007cd93bddb00c  vmovaps [rsp], xmm0
00007cd93bddb011  vmovaps [rsp+0x10], xmm1
00007cd93bddb017  vmovaps [rsp+0x20], xmm2
00007cd93bddb01d  vmovaps [rsp+0x30], xmm3
00007cd93bddb023  vmovaps [rsp+0x40], xmm4
00007cd93bddb029  vmovaps [rsp+0x50], xmm5
00007cd93bddb02f  vmovaps [rsp+0x60], xmm6
00007cd93bddb035  vmovaps [rsp+0x70], xmm7
00007cd93bddb03b  vmovaps [rsp+0x80], xmm9
00007cd93bddb044  vmovaps [rsp+0x90], xmm10
00007cd93bddb04d  vmovaps [rsp+0xA0], xmm11
00007cd93bddb056  vmovaps [rsp+0xB0], xmm12
00007cd93bddb05f  vmovaps [rsp+0xC0], xmm13
00007cd93bddb068  vmovaps [rsp+0xD0], xmm14
00007cd93bddb071  vmovaps [rsp+0xE0], xmm15
00007cd93bddb07a  sub rsp, 0x30
00007cd93bddb07e  movaps [rsp], xmm8
00007cd93bddb083  movaps [rsp+0x10], xmm15
00007cd93bddb089  movaps [rsp+0x20], xmm7
00007cd93bddb08e  lea rdi, [rsp]
00007cd93bddb092  mov esi, 0x00
00007cd93bddb097  mov rax, 0x64A581057530
00007cd93bddb0a1  call rax
00007cd93bddb0a3  movaps xmm8, [rsp]
00007cd93bddb0a8  add rsp, 0x30
00007cd93bddb0ac  vmovaps xmm0, [rsp]
00007cd93bddb0b1  vmovaps xmm1, [rsp+0x10]
00007cd93bddb0b7  vmovaps xmm2, [rsp+0x20]
00007cd93bddb0bd  vmovaps xmm3, [rsp+0x30]
00007cd93bddb0c3  vmovaps xmm4, [rsp+0x40]
00007cd93bddb0c9  vmovaps xmm5, [rsp+0x50]
00007cd93bddb0cf  vmovaps xmm6, [rsp+0x60]
00007cd93bddb0d5  vmovaps xmm7, [rsp+0x70]
00007cd93bddb0db  vmovaps xmm9, [rsp+0x80]
00007cd93bddb0e4  vmovaps xmm10, [rsp+0x90]
00007cd93bddb0ed  vmovaps xmm11, [rsp+0xA0]
00007cd93bddb0f6  vmovaps xmm12, [rsp+0xB0]
00007cd93bddb0ff  vmovaps xmm13, [rsp+0xC0]
00007cd93bddb108  vmovaps xmm14, [rsp+0xD0]
00007cd93bddb111  vmovaps xmm15, [rsp+0xE0]
00007cd93bddb11a  add rsp, 0xF0
00007cd93bddb121  pop r11
00007cd93bddb123  pop r10
00007cd93bddb125  pop r9
00007cd93bddb127  pop r8
00007cd93bddb129  pop rsi
00007cd93bddb12a  pop rdi
00007cd93bddb12b  pop rdx
00007cd93bddb12c  pop rcx
00007cd93bddb12d  pop rax
00007cd93bddb12e  add rsp, 0x08
00007cd93bddb132  jmp 0x00007CD93BDD65D4
00007cd93bddb137  sub rsp, 0x08
00007cd93bddb13b  push rax
00007cd93bddb13c  push rcx
00007cd93bddb13d  push rdx
00007cd93bddb13e  push rdi
00007cd93bddb13f  push rsi
00007cd93bddb140  push r8
00007cd93bddb142  push r9
00007cd93bddb144  push r10
00007cd93bddb146  push r11
00007cd93bddb148  sub rsp, 0xF0
00007cd93bddb14f  vmovaps [rsp], xmm0
00007cd93bddb154  vmovaps [rsp+0x10], xmm1
00007cd93bddb15a  vmovaps [rsp+0x20], xmm2
00007cd93bddb160  vmovaps [rsp+0x30], xmm3
00007cd93bddb166  vmovaps [rsp+0x40], xmm4
00007cd93bddb16c  vmovaps [rsp+0x50], xmm5
00007cd93bddb172  vmovaps [rsp+0x60], xmm6
00007cd93bddb178  vmovaps [rsp+0x70], xmm8
00007cd93bddb17e  vmovaps [rsp+0x80], xmm9
00007cd93bddb187  vmovaps [rsp+0x90], xmm10
00007cd93bddb190  vmovaps [rsp+0xA0], xmm11
00007cd93bddb199  vmovaps [rsp+0xB0], xmm12
00007cd93bddb1a2  vmovaps [rsp+0xC0], xmm13
00007cd93bddb1ab  vmovaps [rsp+0xD0], xmm14
00007cd93bddb1b4  vmovaps [rsp+0xE0], xmm15
00007cd93bddb1bd  sub rsp, 0x30
00007cd93bddb1c1  movaps [rsp], xmm7
00007cd93bddb1c5  movaps [rsp+0x10], xmm9
00007cd93bddb1cb  movaps [rsp+0x20], xmm15
00007cd93bddb1d1  lea rdi, [rsp]
00007cd93bddb1d5  mov esi, 0x00
00007cd93bddb1da  mov rax, 0x64A581057530
00007cd93bddb1e4  call rax
00007cd93bddb1e6  movaps xmm7, [rsp]
00007cd93bddb1ea  add rsp, 0x30
00007cd93bddb1ee  vmovaps xmm0, [rsp]
00007cd93bddb1f3  vmovaps xmm1, [rsp+0x10]
00007cd93bddb1f9  vmovaps xmm2, [rsp+0x20]
00007cd93bddb1ff  vmovaps xmm3, [rsp+0x30]
00007cd93bddb205  vmovaps xmm4, [rsp+0x40]
00007cd93bddb20b  vmovaps xmm5, [rsp+0x50]
00007cd93bddb211  vmovaps xmm6, [rsp+0x60]
00007cd93bddb217  vmovaps xmm8, [rsp+0x70]
00007cd93bddb21d  vmovaps xmm9, [rsp+0x80]
00007cd93bddb226  vmovaps xmm10, [rsp+0x90]
00007cd93bddb22f  vmovaps xmm11, [rsp+0xA0]
00007cd93bddb238  vmovaps xmm12, [rsp+0xB0]
00007cd93bddb241  vmovaps xmm13, [rsp+0xC0]
00007cd93bddb24a  vmovaps xmm14, [rsp+0xD0]
00007cd93bddb253  vmovaps xmm15, [rsp+0xE0]
00007cd93bddb25c  add rsp, 0xF0
00007cd93bddb263  pop r11
00007cd93bddb265  pop r10
00007cd93bddb267  pop r9
00007cd93bddb269  pop r8
00007cd93bddb26b  pop rsi
00007cd93bddb26c  pop rdi
00007cd93bddb26d  pop rdx
00007cd93bddb26e  pop rcx
00007cd93bddb26f  pop rax
00007cd93bddb270  add rsp, 0x08
00007cd93bddb274  jmp 0x00007CD93BDD6601
00007cd93bddb279  sub rsp, 0x08
00007cd93bddb27d  push rax
00007cd93bddb27e  push rcx
00007cd93bddb27f  push rdx
00007cd93bddb280  push rdi
00007cd93bddb281  push rsi
00007cd93bddb282  push r8
00007cd93bddb284  push r9
00007cd93bddb286  push r10
00007cd93bddb288  push r11
00007cd93bddb28a  sub rsp, 0xF0
00007cd93bddb291  vmovaps [rsp], xmm0
00007cd93bddb296  vmovaps [rsp+0x10], xmm1
00007cd93bddb29c  vmovaps [rsp+0x20], xmm2
00007cd93bddb2a2  vmovaps [rsp+0x30], xmm3
00007cd93bddb2a8  vmovaps [rsp+0x40], xmm4
00007cd93bddb2ae  vmovaps [rsp+0x50], xmm5
00007cd93bddb2b4  vmovaps [rsp+0x60], xmm6
00007cd93bddb2ba  vmovaps [rsp+0x70], xmm7
00007cd93bddb2c0  vmovaps [rsp+0x80], xmm8
00007cd93bddb2c9  vmovaps [rsp+0x90], xmm10
00007cd93bddb2d2  vmovaps [rsp+0xA0], xmm11
00007cd93bddb2db  vmovaps [rsp+0xB0], xmm12
00007cd93bddb2e4  vmovaps [rsp+0xC0], xmm13
00007cd93bddb2ed  vmovaps [rsp+0xD0], xmm14
00007cd93bddb2f6  vmovaps [rsp+0xE0], xmm15
00007cd93bddb2ff  sub rsp, 0x30
00007cd93bddb303  movaps [rsp], xmm9
00007cd93bddb308  movaps [rsp+0x10], xmm13
00007cd93bddb30e  movaps [rsp+0x20], xmm15
00007cd93bddb314  lea rdi, [rsp]
00007cd93bddb318  mov esi, 0x00
00007cd93bddb31d  mov rax, 0x64A581057530
00007cd93bddb327  call rax
00007cd93bddb329  movaps xmm9, [rsp]
00007cd93bddb32e  add rsp, 0x30
00007cd93bddb332  vmovaps xmm0, [rsp]
00007cd93bddb337  vmovaps xmm1, [rsp+0x10]
00007cd93bddb33d  vmovaps xmm2, [rsp+0x20]
00007cd93bddb343  vmovaps xmm3, [rsp+0x30]
00007cd93bddb349  vmovaps xmm4, [rsp+0x40]
00007cd93bddb34f  vmovaps xmm5, [rsp+0x50]
00007cd93bddb355  vmovaps xmm6, [rsp+0x60]
00007cd93bddb35b  vmovaps xmm7, [rsp+0x70]
00007cd93bddb361  vmovaps xmm8, [rsp+0x80]
00007cd93bddb36a  vmovaps xmm10, [rsp+0x90]
00007cd93bddb373  vmovaps xmm11, [rsp+0xA0]
00007cd93bddb37c  vmovaps xmm12, [rsp+0xB0]
00007cd93bddb385  vmovaps xmm13, [rsp+0xC0]
00007cd93bddb38e  vmovaps xmm14, [rsp+0xD0]
00007cd93bddb397  vmovaps xmm15, [rsp+0xE0]
00007cd93bddb3a0  add rsp, 0xF0
00007cd93bddb3a7  pop r11
00007cd93bddb3a9  pop r10
00007cd93bddb3ab  pop r9
00007cd93bddb3ad  pop r8
00007cd93bddb3af  pop rsi
00007cd93bddb3b0  pop rdi
00007cd93bddb3b1  pop rdx
00007cd93bddb3b2  pop rcx
00007cd93bddb3b3  pop rax
00007cd93bddb3b4  add rsp, 0x08
00007cd93bddb3b8  jmp 0x00007CD93BDD662F
00007cd93bddb3bd  sub rsp, 0x08
00007cd93bddb3c1  push rax
00007cd93bddb3c2  push rcx
00007cd93bddb3c3  push rdx
00007cd93bddb3c4  push rdi
00007cd93bddb3c5  push rsi
00007cd93bddb3c6  push r8
00007cd93bddb3c8  push r9
00007cd93bddb3ca  push r10
00007cd93bddb3cc  push r11
00007cd93bddb3ce  sub rsp, 0xF0
00007cd93bddb3d5  vmovaps [rsp], xmm0
00007cd93bddb3da  vmovaps [rsp+0x10], xmm1
00007cd93bddb3e0  vmovaps [rsp+0x20], xmm2
00007cd93bddb3e6  vmovaps [rsp+0x30], xmm3
00007cd93bddb3ec  vmovaps [rsp+0x40], xmm4
00007cd93bddb3f2  vmovaps [rsp+0x50], xmm5
00007cd93bddb3f8  vmovaps [rsp+0x60], xmm6
00007cd93bddb3fe  vmovaps [rsp+0x70], xmm7
00007cd93bddb404  vmovaps [rsp+0x80], xmm8
00007cd93bddb40d  vmovaps [rsp+0x90], xmm9
00007cd93bddb416  vmovaps [rsp+0xA0], xmm10
00007cd93bddb41f  vmovaps [rsp+0xB0], xmm11
00007cd93bddb428  vmovaps [rsp+0xC0], xmm12
00007cd93bddb431  vmovaps [rsp+0xD0], xmm13
00007cd93bddb43a  vmovaps [rsp+0xE0], xmm14
00007cd93bddb443  sub rsp, 0x30
00007cd93bddb447  movaps [rsp], xmm15
00007cd93bddb44c  movaps [rsp+0x10], xmm11
00007cd93bddb452  movaps [rsp+0x20], xmm12
00007cd93bddb458  lea rdi, [rsp]
00007cd93bddb45c  mov esi, 0x00
00007cd93bddb461  mov rax, 0x64A581057530
00007cd93bddb46b  call rax
00007cd93bddb46d  movaps xmm15, [rsp]
00007cd93bddb472  add rsp, 0x30
00007cd93bddb476  vmovaps xmm0, [rsp]
00007cd93bddb47b  vmovaps xmm1, [rsp+0x10]
00007cd93bddb481  vmovaps xmm2, [rsp+0x20]
00007cd93bddb487  vmovaps xmm3, [rsp+0x30]
00007cd93bddb48d  vmovaps xmm4, [rsp+0x40]
00007cd93bddb493  vmovaps xmm5, [rsp+0x50]
00007cd93bddb499  vmovaps xmm6, [rsp+0x60]
00007cd93bddb49f  vmovaps xmm7, [rsp+0x70]
00007cd93bddb4a5  vmovaps xmm8, [rsp+0x80]
00007cd93bddb4ae  vmovaps xmm9, [rsp+0x90]
00007cd93bddb4b7  vmovaps xmm10, [rsp+0xA0]
00007cd93bddb4c0  vmovaps xmm11, [rsp+0xB0]
00007cd93bddb4c9  vmovaps xmm12, [rsp+0xC0]
00007cd93bddb4d2  vmovaps xmm13, [rsp+0xD0]
00007cd93bddb4db  vmovaps xmm14, [rsp+0xE0]
00007cd93bddb4e4  add rsp, 0xF0
00007cd93bddb4eb  pop r11
00007cd93bddb4ed  pop r10
00007cd93bddb4ef  pop r9
00007cd93bddb4f1  pop r8
00007cd93bddb4f3  pop rsi
00007cd93bddb4f4  pop rdi
00007cd93bddb4f5  pop rdx
00007cd93bddb4f6  pop rcx
00007cd93bddb4f7  pop rax
00007cd93bddb4f8  add rsp, 0x08
00007cd93bddb4fc  jmp 0x00007CD93BDD664A
00007cd93bddb501  sub rsp, 0x08
00007cd93bddb505  push rax
00007cd93bddb506  push rcx
00007cd93bddb507  push rdx
00007cd93bddb508  push rdi
00007cd93bddb509  push rsi
00007cd93bddb50a  push r8
00007cd93bddb50c  push r9
00007cd93bddb50e  push r10
00007cd93bddb510  push r11
00007cd93bddb512  sub rsp, 0xF0
00007cd93bddb519  vmovaps [rsp], xmm0
00007cd93bddb51e  vmovaps [rsp+0x10], xmm1
00007cd93bddb524  vmovaps [rsp+0x20], xmm2
00007cd93bddb52a  vmovaps [rsp+0x30], xmm3
00007cd93bddb530  vmovaps [rsp+0x40], xmm4
00007cd93bddb536  vmovaps [rsp+0x50], xmm5
00007cd93bddb53c  vmovaps [rsp+0x60], xmm6
00007cd93bddb542  vmovaps [rsp+0x70], xmm7
00007cd93bddb548  vmovaps [rsp+0x80], xmm8
00007cd93bddb551  vmovaps [rsp+0x90], xmm9
00007cd93bddb55a  vmovaps [rsp+0xA0], xmm10
00007cd93bddb563  vmovaps [rsp+0xB0], xmm11
00007cd93bddb56c  vmovaps [rsp+0xC0], xmm12
00007cd93bddb575  vmovaps [rsp+0xD0], xmm14
00007cd93bddb57e  vmovaps [rsp+0xE0], xmm15
00007cd93bddb587  sub rsp, 0x30
00007cd93bddb58b  movaps [rsp], xmm13
00007cd93bddb590  movaps [rsp+0x10], xmm10
00007cd93bddb596  movaps [rsp+0x20], xmm14
00007cd93bddb59c  lea rdi, [rsp]
00007cd93bddb5a0  mov esi, 0x00
00007cd93bddb5a5  mov rax, 0x64A581057530
00007cd93bddb5af  call rax
00007cd93bddb5b1  movaps xmm13, [rsp]
00007cd93bddb5b6  add rsp, 0x30
00007cd93bddb5ba  vmovaps xmm0, [rsp]
00007cd93bddb5bf  vmovaps xmm1, [rsp+0x10]
00007cd93bddb5c5  vmovaps xmm2, [rsp+0x20]
00007cd93bddb5cb  vmovaps xmm3, [rsp+0x30]
00007cd93bddb5d1  vmovaps xmm4, [rsp+0x40]
00007cd93bddb5d7  vmovaps xmm5, [rsp+0x50]
00007cd93bddb5dd  vmovaps xmm6, [rsp+0x60]
00007cd93bddb5e3  vmovaps xmm7, [rsp+0x70]
00007cd93bddb5e9  vmovaps xmm8, [rsp+0x80]
00007cd93bddb5f2  vmovaps xmm9, [rsp+0x90]
00007cd93bddb5fb  vmovaps xmm10, [rsp+0xA0]
00007cd93bddb604  vmovaps xmm11, [rsp+0xB0]
00007cd93bddb60d  vmovaps xmm12, [rsp+0xC0]
00007cd93bddb616  vmovaps xmm14, [rsp+0xD0]
00007cd93bddb61f  vmovaps xmm15, [rsp+0xE0]
00007cd93bddb628  add rsp, 0xF0
00007cd93bddb62f  pop r11
00007cd93bddb631  pop r10
00007cd93bddb633  pop r9
00007cd93bddb635  pop r8
00007cd93bddb637  pop rsi
00007cd93bddb638  pop rdi
00007cd93bddb639  pop rdx
00007cd93bddb63a  pop rcx
00007cd93bddb63b  pop rax
00007cd93bddb63c  add rsp, 0x08
00007cd93bddb640  jmp 0x00007CD93BDD666D
00007cd93bddb645  sub rsp, 0x08
00007cd93bddb649  push rax
00007cd93bddb64a  push rcx
00007cd93bddb64b  push rdx
00007cd93bddb64c  push rdi
00007cd93bddb64d  push rsi
00007cd93bddb64e  push r8
00007cd93bddb650  push r9
00007cd93bddb652  push r10
00007cd93bddb654  push r11
00007cd93bddb656  sub rsp, 0xF0
00007cd93bddb65d  vmovaps [rsp], xmm0
00007cd93bddb662  vmovaps [rsp+0x10], xmm1
00007cd93bddb668  vmovaps [rsp+0x20], xmm2
00007cd93bddb66e  vmovaps [rsp+0x30], xmm3
00007cd93bddb674  vmovaps [rsp+0x40], xmm4
00007cd93bddb67a  vmovaps [rsp+0x50], xmm5
00007cd93bddb680  vmovaps [rsp+0x60], xmm6
00007cd93bddb686  vmovaps [rsp+0x70], xmm7
00007cd93bddb68c  vmovaps [rsp+0x80], xmm8
00007cd93bddb695  vmovaps [rsp+0x90], xmm9
00007cd93bddb69e  vmovaps [rsp+0xA0], xmm10
00007cd93bddb6a7  vmovaps [rsp+0xB0], xmm11
00007cd93bddb6b0  vmovaps [rsp+0xC0], xmm12
00007cd93bddb6b9  vmovaps [rsp+0xD0], xmm13
00007cd93bddb6c2  vmovaps [rsp+0xE0], xmm15
00007cd93bddb6cb  sub rsp, 0x30
00007cd93bddb6cf  movaps [rsp], xmm14
00007cd93bddb6d4  movaps [rsp+0x10], xmm1
00007cd93bddb6d9  movaps [rsp+0x20], xmm7
00007cd93bddb6de  lea rdi, [rsp]
00007cd93bddb6e2  mov esi, 0x00
00007cd93bddb6e7  mov rax, 0x64A581057530
00007cd93bddb6f1  call rax
00007cd93bddb6f3  movaps xmm14, [rsp]
00007cd93bddb6f8  add rsp, 0x30
00007cd93bddb6fc  vmovaps xmm0, [rsp]
00007cd93bddb701  vmovaps xmm1, [rsp+0x10]
00007cd93bddb707  vmovaps xmm2, [rsp+0x20]
00007cd93bddb70d  vmovaps xmm3, [rsp+0x30]
00007cd93bddb713  vmovaps xmm4, [rsp+0x40]
00007cd93bddb719  vmovaps xmm5, [rsp+0x50]
00007cd93bddb71f  vmovaps xmm6, [rsp+0x60]
00007cd93bddb725  vmovaps xmm7, [rsp+0x70]
00007cd93bddb72b  vmovaps xmm8, [rsp+0x80]
00007cd93bddb734  vmovaps xmm9, [rsp+0x90]
00007cd93bddb73d  vmovaps xmm10, [rsp+0xA0]
00007cd93bddb746  vmovaps xmm11, [rsp+0xB0]
00007cd93bddb74f  vmovaps xmm12, [rsp+0xC0]
00007cd93bddb758  vmovaps xmm13, [rsp+0xD0]
00007cd93bddb761  vmovaps xmm15, [rsp+0xE0]
00007cd93bddb76a  add rsp, 0xF0
00007cd93bddb771  pop r11
00007cd93bddb773  pop r10
00007cd93bddb775  pop r9
00007cd93bddb777  pop r8
00007cd93bddb779  pop rsi
00007cd93bddb77a  pop rdi
00007cd93bddb77b  pop rdx
00007cd93bddb77c  pop rcx
00007cd93bddb77d  pop rax
00007cd93bddb77e  add rsp, 0x08
00007cd93bddb782  jmp 0x00007CD93BDD6690
00007cd93bddb787  sub rsp, 0x08
00007cd93bddb78b  push rax
00007cd93bddb78c  push rcx
00007cd93bddb78d  push rdx
00007cd93bddb78e  push rdi
00007cd93bddb78f  push rsi
00007cd93bddb790  push r8
00007cd93bddb792  push r9
00007cd93bddb794  push r10
00007cd93bddb796  push r11
00007cd93bddb798  sub rsp, 0xF0
00007cd93bddb79f  vmovaps [rsp], xmm0
00007cd93bddb7a4  vmovaps [rsp+0x10], xmm2
00007cd93bddb7aa  vmovaps [rsp+0x20], xmm3
00007cd93bddb7b0  vmovaps [rsp+0x30], xmm4
00007cd93bddb7b6  vmovaps [rsp+0x40], xmm5
00007cd93bddb7bc  vmovaps [rsp+0x50], xmm6
00007cd93bddb7c2  vmovaps [rsp+0x60], xmm7
00007cd93bddb7c8  vmovaps [rsp+0x70], xmm8
00007cd93bddb7ce  vmovaps [rsp+0x80], xmm9
00007cd93bddb7d7  vmovaps [rsp+0x90], xmm10
00007cd93bddb7e0  vmovaps [rsp+0xA0], xmm11
00007cd93bddb7e9  vmovaps [rsp+0xB0], xmm12
00007cd93bddb7f2  vmovaps [rsp+0xC0], xmm13
00007cd93bddb7fb  vmovaps [rsp+0xD0], xmm14
00007cd93bddb804  vmovaps [rsp+0xE0], xmm15
00007cd93bddb80d  sub rsp, 0x30
00007cd93bddb811  movaps [rsp], xmm1
00007cd93bddb815  movaps [rsp+0x10], xmm8
00007cd93bddb81b  movaps [rsp+0x20], xmm9
00007cd93bddb821  lea rdi, [rsp]
00007cd93bddb825  mov esi, 0x00
00007cd93bddb82a  mov rax, 0x64A581057530
00007cd93bddb834  call rax
00007cd93bddb836  movaps xmm1, [rsp]
00007cd93bddb83a  add rsp, 0x30
00007cd93bddb83e  vmovaps xmm0, [rsp]
00007cd93bddb843  vmovaps xmm2, [rsp+0x10]
00007cd93bddb849  vmovaps xmm3, [rsp+0x20]
00007cd93bddb84f  vmovaps xmm4, [rsp+0x30]
00007cd93bddb855  vmovaps xmm5, [rsp+0x40]
00007cd93bddb85b  vmovaps xmm6, [rsp+0x50]
00007cd93bddb861  vmovaps xmm7, [rsp+0x60]
00007cd93bddb867  vmovaps xmm8, [rsp+0x70]
00007cd93bddb86d  vmovaps xmm9, [rsp+0x80]
00007cd93bddb876  vmovaps xmm10, [rsp+0x90]
00007cd93bddb87f  vmovaps xmm11, [rsp+0xA0]
00007cd93bddb888  vmovaps xmm12, [rsp+0xB0]
00007cd93bddb891  vmovaps xmm13, [rsp+0xC0]
00007cd93bddb89a  vmovaps xmm14, [rsp+0xD0]
00007cd93bddb8a3  vmovaps xmm15, [rsp+0xE0]
00007cd93bddb8ac  add rsp, 0xF0
00007cd93bddb8b3  pop r11
00007cd93bddb8b5  pop r10
00007cd93bddb8b7  pop r9
00007cd93bddb8b9  pop r8
00007cd93bddb8bb  pop rsi
00007cd93bddb8bc  pop rdi
00007cd93bddb8bd  pop rdx
00007cd93bddb8be  pop rcx
00007cd93bddb8bf  pop rax
00007cd93bddb8c0  add rsp, 0x08
00007cd93bddb8c4  jmp 0x00007CD93BDD66B2
00007cd93bddb8c9  call 0x00007CD93BCB3E40
00007cd93bddb8ce  jmp 0x00007CD93BDD66C0
00007cd93bddb8d3  call 0x00007CD93BC0C380
00007cd93bddb8d8  jmp 0x00007CD93BDD66CA
00007cd93bddb8dd  call 0x00007CD93BC0D600
00007cd93bddb8e2  jmp 0x00007CD93BDD66D4
00007cd93bddb8e7  call 0x00007CD93BBFF540
00007cd93bddb8ec  jmp 0x00007CD93BDD66DE
00007cd93bddb8f1  int3
00007cd93bddb8f2  nop [rax+rax*1], ax
00007cd93bddb8fb  nop [rax+rax*1], eax
00007cd93bddb900  mov eax, [r15+0x48]
00007cd93bddb904  lea r14d, [eax+0x01]
00007cd93bddb909  mov [rsp+0x10], r14d
00007cd93bddb90e  mov r14d, r14d
00007cd93bddb911  mov [r15+0x48], r14
00007cd93bddb915  xor eax, eax
00007cd93bddb917  mov r14d, [rsp+0x10]
00007cd93bddb91c  cmp r14d, 0x1F4
00007cd93bddb923  cmc
00007cd93bddb924  lahf
00007cd93bddb925  seto al
00007cd93bddb928  mov [r15+0x108], eax
00007cd93bddb92f  mov eax, [r15+0x108]
00007cd93bddb936  sahf
00007cd93bddb937  jnz 0x00007CD93BDDB969
00007cd93bddb939  cmp dword ptr [r15+0x318], 0x00
00007cd93bddb941  jz 0x00007CD93BDE1AB0
00007cd93bddb947  nop [rax+rax*1], ax
00007cd93bddb950  nop [rax+rax*1], eax
00007cd93bddb958  mov eax, 0x410450
00007cd93bddb95d  mov [r15+0x100], rax
00007cd93bddb964  jmp 0x00007CD93BBFE110
00007cd93bddb969  cmp dword ptr [r15+0x318], 0x00
00007cd93bddb971  jz 0x00007CD93BDDB9A0
00007cd93bddb977  nop [rax+rax*1], ax
00007cd93bddb980  nop [rax+rax*1], eax
00007cd93bddb988  mov eax, 0x410274
00007cd93bddb98d  mov [r15+0x100], rax
00007cd93bddb994  jmp 0x00007CD93BBFE110
00007cd93bddb999  int3
00007cd93bddb99a  int3
00007cd93bddb99b  nop [rax+rax*1], eax
00007cd93bddb9a0  mov rax, [r15+0x40]
00007cd93bddb9a4  movaps xmm1, [r15+0x1D0]
00007cd93bddb9ac  vmovaps [rsp+0x10], xmm1
00007cd93bddb9b2  vmovaps xmm15, [rsp+0x10]
00007cd93bddb9b8  por xmm1, xmm15
00007cd93bddb9bd  movaps xmm14, [r15+0x1A0]
00007cd93bddb9c5  vmovaps [rsp+0x10], xmm14
00007cd93bddb9cb  vmovaps xmm13, [rsp+0x10]
00007cd93bddb9d1  por xmm14, xmm13
00007cd93bddb9d6  lea r14, [rax+0x30]
00007cd93bddb9da  mov r12, [r13+r14*1]
00007cd93bddb9df  lea r14, [rax+0x38]
00007cd93bddb9e3  mov r11, [r13+r14*1]
00007cd93bddb9e8  movq xmm13, r12
00007cd93bddb9ed  movq xmm12, r11
00007cd93bddb9f2  movq xmm13, xmm13
00007cd93bddb9f7  vmovaps [rsp+0x10], xmm13
00007cd93bddb9fd  movq xmm13, xmm13
00007cd93bddba02  movaps [r15+0x130], xmm13
00007cd93bddba0a  movq xmm12, xmm12
00007cd93bddba0f  vmovaps [rsp+0x20], xmm12
00007cd93bddba15  movq xmm12, xmm12
00007cd93bddba1a  movaps [r15+0x280], xmm12
00007cd93bddba22  movaps xmm13, [r15+0x270]
00007cd93bddba2a  vmovaps [rsp+0x30], xmm13
00007cd93bddba30  vmovaps xmm12, [rsp+0x30]
00007cd93bddba36  por xmm13, xmm12
00007cd93bddba3b  lea r14, [rax+0x20]
00007cd93bddba3f  mov r12, [r13+r14*1]
00007cd93bddba44  lea r14, [rax+0x28]
00007cd93bddba48  mov r11, [r13+r14*1]
00007cd93bddba4d  movq xmm12, r12
00007cd93bddba52  movq xmm11, r11
00007cd93bddba57  movq xmm12, xmm12
00007cd93bddba5c  vmovaps [rsp+0x30], xmm12
00007cd93bddba62  movq xmm12, xmm12
00007cd93bddba67  movaps [r15+0x150], xmm12
00007cd93bddba6f  movq xmm11, xmm11
00007cd93bddba74  vmovaps [rsp+0x40], xmm11
00007cd93bddba7a  movq xmm11, xmm11
00007cd93bddba7f  movaps [r15+0x140], xmm11
00007cd93bddba87  lea r14, [rax+0x10]
00007cd93bddba8b  mov r12, [r13+r14*1]
00007cd93bddba90  lea r14, [rax+0x18]
00007cd93bddba94  mov r11, [r13+r14*1]
00007cd93bddba99  movq xmm12, r12
00007cd93bddba9e  movq xmm11, r11
00007cd93bddbaa3  movq xmm12, xmm12
00007cd93bddbaa8  vmovaps [rsp+0x50], xmm12
00007cd93bddbaae  movq xmm12, xmm12
00007cd93bddbab3  movaps [r15+0x170], xmm12
00007cd93bddbabb  movq xmm11, xmm11
00007cd93bddbac0  vmovaps [rsp+0x60], xmm11
00007cd93bddbac6  movq xmm11, xmm11
00007cd93bddbacb  movaps [r15+0x160], xmm11
00007cd93bddbad3  mov r14, [r13+rax*1]
00007cd93bddbad8  vmovq xmm12, r14
00007cd93bddbadd  vpbroadcastq xmm12, xmm12
00007cd93bddbae2  lea r14, [rax+0x08]
00007cd93bddbae6  mov rax, [r13+r14*1]
00007cd93bddbaeb  movq xmm11, rax
00007cd93bddbaf0  movaps [r15+0x230], xmm11
00007cd93bddbaf8  mov rax, [r15+0xF8]
00007cd93bddbaff  lea r14, [rax+0x50]
00007cd93bddbb03  movups xmm11, [r13+r14*1]
00007cd93bddbb09  lea r14, [rax+0x60]
00007cd93bddbb0d  movups xmm10, [r13+r14*1]
00007cd93bddbb13  lea r14, [rax+0x30]
00007cd93bddbb17  movups xmm9, [r13+r14*1]
00007cd93bddbb1d  mov r14, [r15+0x50]
00007cd93bddbb21  mov [r15+0x60], r14
00007cd93bddbb25  mov qword ptr [r15+0x58], 0x40
00007cd93bddbb2d  movaps xmm8, xmm12
00007cd93bddbb31  mulpd xmm8, xmm15
00007cd93bddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007cd93bddbb3c  ptest xmm7, xmm7
00007cd93bddbb41  jnz 0x00007CD93BDDC96A
00007cd93bddbb47  movq xmm15, qword ptr [r15+0x230]
00007cd93bddbb50  vmovaps [rsp+0x70], xmm15
00007cd93bddbb56  vpermilpd xmm15, xmm15, 0x00
00007cd93bddbb5c  movaps xmm7, xmm9
00007cd93bddbb60  mulpd xmm7, xmm15
00007cd93bddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007cd93bddbb6a  ptest xmm6, xmm6
00007cd93bddbb6f  jnz 0x00007CD93BDDCAAE
00007cd93bddbb75  vxorps xmm15, xmm15, xmm15
00007cd93bddbb7a  vpbroadcastq xmm15, xmm15
00007cd93bddbb7f  movaps xmm9, xmm12
00007cd93bddbb83  mulpd xmm9, xmm10
00007cd93bddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007cd93bddbb8e  ptest xmm6, xmm6
00007cd93bddbb93  jnz 0x00007CD93BDDCBF0
00007cd93bddbb99  movaps xmm10, xmm12
00007cd93bddbb9d  mulpd xmm10, xmm11
00007cd93bddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007cd93bddbba8  ptest xmm6, xmm6
00007cd93bddbbad  jnz 0x00007CD93BDDCD34
00007cd93bddbbb3  movaps xmm11, [r15+0x1F0]
00007cd93bddbbbb  movaps xmm6, xmm12
00007cd93bddbbbf  mulpd xmm6, xmm11
00007cd93bddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007cd93bddbbc9  ptest xmm5, xmm5
00007cd93bddbbce  jnz 0x00007CD93BDDCE78
00007cd93bddbbd4  movaps xmm12, [r15+0x2A0]
00007cd93bddbbdc  vmovaps [rsp+0x80], xmm12
00007cd93bddbbe5  vmovaps xmm11, [rsp+0x80]
00007cd93bddbbee  por xmm12, xmm11
00007cd93bddbbf3  movaps xmm11, [r15+0x250]
00007cd93bddbbfb  vmovaps [rsp+0x80], xmm11
00007cd93bddbc04  vmovaps xmm5, [rsp+0x80]
00007cd93bddbc0d  por xmm11, xmm5
00007cd93bddbc12  vmovaps xmm4, [rsp+0x70]
00007cd93bddbc18  vpermilpd xmm4, xmm4, 0x00
00007cd93bddbc1e  movaps xmm3, xmm5
00007cd93bddbc21  mulpd xmm3, xmm4
00007cd93bddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007cd93bddbc2a  ptest xmm2, xmm2
00007cd93bddbc2f  jnz 0x00007CD93BDDCFBA
00007cd93bddbc35  mov [rsp+0x80], rax
00007cd93bddbc3d  xor eax, eax
00007cd93bddbc3f  mov r12d, 0x40
00007cd93bddbc45  mov r11d, 0x200
00007cd93bddbc4b  cmp r12, r11
00007cd93bddbc4e  cmc
00007cd93bddbc4f  lahf
00007cd93bddbc50  seto al
00007cd93bddbc53  mov [r15+0x108], eax
00007cd93bddbc5a  movaps xmm5, xmm8
00007cd93bddbc5e  addpd xmm5, xmm15
00007cd93bddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007cd93bddbc68  ptest xmm4, xmm4
00007cd93bddbc6d  jnz 0x00007CD93BDDD0FA
00007cd93bddbc73  movaps xmm8, [r15+0x1B0]
00007cd93bddbc7b  movaps xmm4, xmm9
00007cd93bddbc7f  addpd xmm4, xmm8
00007cd93bddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007cd93bddbc89  ptest xmm2, xmm2
00007cd93bddbc8e  jnz 0x00007CD93BDDD23C
00007cd93bddbc94  movaps xmm9, xmm10
00007cd93bddbc98  addpd xmm9, xmm8
00007cd93bddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007cd93bddbca3  ptest xmm2, xmm2
00007cd93bddbca8  jnz 0x00007CD93BDDD37E
00007cd93bddbcae  movaps xmm10, [r15+0x2F0]
00007cd93bddbcb6  vmovaps [rsp+0x90], xmm10
00007cd93bddbcbf  vmovaps xmm8, [rsp+0x90]
00007cd93bddbcc8  por xmm10, xmm8
00007cd93bddbccd  movaps xmm8, [r15+0x2E0]
00007cd93bddbcd5  vmovaps [rsp+0x90], xmm8
00007cd93bddbcde  vmovaps xmm2, [rsp+0x90]
00007cd93bddbce7  por xmm8, xmm2
00007cd93bddbcec  movaps xmm2, [r15+0x2D0]
00007cd93bddbcf4  vmovaps [rsp+0x90], xmm2
00007cd93bddbcfd  vmovaps [rsp+0xA0], xmm1
00007cd93bddbd06  vmovaps xmm1, [rsp+0x90]
00007cd93bddbd0f  por xmm2, xmm1
00007cd93bddbd13  movaps xmm1, [r15+0x200]
00007cd93bddbd1b  vmovaps [rsp+0x90], xmm1
00007cd93bddbd24  vmovaps [rsp+0xB0], xmm15
00007cd93bddbd2d  vmovaps xmm15, [rsp+0x90]
00007cd93bddbd36  por xmm1, xmm15
00007cd93bddbd3b  movaps xmm15, [r15+0x1C0]
00007cd93bddbd43  vmovaps [rsp+0x90], xmm15
00007cd93bddbd4c  vmovaps [rsp+0xC0], xmm1
00007cd93bddbd55  vmovaps xmm1, [rsp+0x90]
00007cd93bddbd5e  por xmm15, xmm1
00007cd93bddbd63  movaps xmm1, [r15+0x190]
00007cd93bddbd6b  vmovaps [rsp+0x90], xmm1
00007cd93bddbd74  vmovaps [rsp+0xD0], xmm15
00007cd93bddbd7d  vmovaps xmm15, [rsp+0x90]
00007cd93bddbd86  por xmm1, xmm15
00007cd93bddbd8b  movaps xmm15, [r15+0x300]
00007cd93bddbd93  vmovaps [rsp+0x90], xmm15
00007cd93bddbd9c  vmovaps [rsp+0xE0], xmm1
00007cd93bddbda5  vmovaps xmm1, [rsp+0x90]
00007cd93bddbdae  por xmm15, xmm1
00007cd93bddbdb3  mov rax, [rsp+0x80]
00007cd93bddbdbb  lea r12, [rax+0xA0]
00007cd93bddbdc2  movups xmm1, [r13+r12*1]
00007cd93bddbdc8  lea r12, [rax+0xB0]
00007cd93bddbdcf  vmovaps [rsp+0x80], xmm1
00007cd93bddbdd8  movups xmm1, [r13+r12*1]
00007cd93bddbdde  vmovaps [rsp+0x90], xmm1
00007cd93bddbde7  vmovaps [rsp+0xF0], xmm15
00007cd93bddbdf0  vmovaps xmm15, [rsp+0xB0]
00007cd93bddbdf9  vmovaps [rsp+0xB0], xmm14
00007cd93bddbe02  movaps xmm1, xmm6
00007cd93bddbe05  addpd xmm1, xmm15
00007cd93bddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007cd93bddbe0f  ptest xmm14, xmm14
00007cd93bddbe15  jnz 0x00007CD93BDDD4D6
00007cd93bddbe1b  lea r12, [rax+0xF0]
00007cd93bddbe22  movups xmm15, [r13+r12*1]
00007cd93bddbe28  movaps xmm14, xmm4
00007cd93bddbe2c  addpd xmm14, xmm3
00007cd93bddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007cd93bddbe37  ptest xmm6, xmm6
00007cd93bddbe3c  jnz 0x00007CD93BDDD621
00007cd93bddbe42  movaps xmm6, xmm9
00007cd93bddbe46  addpd xmm6, xmm7
00007cd93bddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007cd93bddbe4f  ptest xmm4, xmm4
00007cd93bddbe54  jnz 0x00007CD93BDDD763
00007cd93bddbe5a  vmovaps xmm9, [rsp+0x70]
00007cd93bddbe60  vpermilpd xmm9, xmm9, 0x00
00007cd93bddbe66  vmovaps xmm4, [rsp+0x90]
00007cd93bddbe6f  movaps xmm7, xmm4
00007cd93bddbe72  mulpd xmm7, xmm9
00007cd93bddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007cd93bddbe7c  ptest xmm3, xmm3
00007cd93bddbe81  jnz 0x00007CD93BDDD8A4
00007cd93bddbe87  vmovaps xmm9, [rsp+0x50]
00007cd93bddbe8d  vpermilpd xmm9, xmm9, 0x00
00007cd93bddbe93  movaps xmm4, xmm15
00007cd93bddbe97  mulpd xmm4, xmm9
00007cd93bddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007cd93bddbea1  ptest xmm3, xmm3
00007cd93bddbea6  jnz 0x00007CD93BDDD9E5
00007cd93bddbeac  lea r12, [rax+0xE0]
00007cd93bddbeb3  movups xmm15, [r13+r12*1]
00007cd93bddbeb9  vmovaps xmm9, [rsp+0x70]
00007cd93bddbebf  vpermilpd xmm9, xmm9, 0x00
00007cd93bddbec5  vmovaps [rsp+0x70], xmm1
00007cd93bddbecb  vmovaps xmm1, [rsp+0x80]
00007cd93bddbed4  vmovaps [rsp+0x80], xmm15
00007cd93bddbedd  movaps xmm3, xmm1
00007cd93bddbee0  mulpd xmm3, xmm9
00007cd93bddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007cd93bddbeea  ptest xmm15, xmm15
00007cd93bddbef0  jnz 0x00007CD93BDDDB31
00007cd93bddbef6  vmovaps xmm1, [rsp+0xF0]
00007cd93bddbeff  vmovaps xmm15, [rsp+0xF0]
00007cd93bddbf08  por xmm1, xmm15
00007cd93bddbf0d  movaps [r15+0x300], xmm1
00007cd93bddbf15  vmovaps xmm15, [rsp+0xE0]
00007cd93bddbf1e  vmovaps xmm9, [rsp+0xE0]
00007cd93bddbf27  por xmm15, xmm9
00007cd93bddbf2c  movaps [r15+0x190], xmm15
00007cd93bddbf34  vmovaps xmm9, [rsp+0x50]
00007cd93bddbf3a  vpermilpd xmm9, xmm9, 0x00
00007cd93bddbf40  vmovaps [rsp+0x90], xmm1
00007cd93bddbf49  vmovaps [rsp+0xE0], xmm15
00007cd93bddbf52  vmovaps xmm15, [rsp+0x80]
00007cd93bddbf5b  vmovaps [rsp+0x80], xmm14
00007cd93bddbf64  movaps xmm1, xmm15
00007cd93bddbf68  mulpd xmm1, xmm9
00007cd93bddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007cd93bddbf72  ptest xmm14, xmm14
00007cd93bddbf78  jnz 0x00007CD93BDDDC72
00007cd93bddbf7e  lea r12, [rax+0x90]
00007cd93bddbf85  movups xmm15, [r13+r12*1]
00007cd93bddbf8b  vmovaps xmm14, [rsp+0xD0]
00007cd93bddbf94  vmovaps xmm9, [rsp+0xD0]
00007cd93bddbf9d  por xmm14, xmm9
00007cd93bddbfa2  movaps [r15+0x1C0], xmm14
00007cd93bddbfaa  vmovaps xmm9, [rsp+0xC0]
00007cd93bddbfb3  vmovaps [rsp+0xD0], xmm1
00007cd93bddbfbc  vmovaps xmm1, [rsp+0xC0]
00007cd93bddbfc5  por xmm9, xmm1
00007cd93bddbfca  movaps [r15+0x200], xmm9
00007cd93bddbfd2  vmovaps [rsp+0xC0], xmm2
00007cd93bddbfdb  vmovaps xmm1, [rsp+0xC0]
00007cd93bddbfe4  por xmm2, xmm1
00007cd93bddbfe8  movaps [r15+0x2D0], xmm2
00007cd93bddbff0  vmovaps [rsp+0xC0], xmm8
00007cd93bddbff9  vmovaps xmm1, [rsp+0xC0]
00007cd93bddc002  por xmm8, xmm1
00007cd93bddc007  movaps [r15+0x2E0], xmm8
00007cd93bddc00f  vmovaps [rsp+0xC0], xmm15
00007cd93bddc018  movaps xmm1, xmm5
00007cd93bddc01b  addpd xmm1, xmm7
00007cd93bddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007cd93bddc024  ptest xmm15, xmm15
00007cd93bddc02a  jnz 0x00007CD93BDDDDBE
00007cd93bddc030  vmovaps xmm15, [rsp+0x50]
00007cd93bddc036  vpermilpd xmm15, xmm15, 0x00
00007cd93bddc03c  vmovaps xmm5, [rsp+0xC0]
00007cd93bddc045  vmovaps [rsp+0xC0], xmm1
00007cd93bddc04e  movaps xmm7, xmm5
00007cd93bddc051  mulpd xmm7, xmm15
00007cd93bddc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007cd93bddc05b  ptest xmm1, xmm1
00007cd93bddc060  jnz 0x00007CD93BDDDEFE
00007cd93bddc066  lea r12, [rax+0x80]
00007cd93bddc06d  movups xmm1, [r13+r12*1]
00007cd93bddc073  vmovaps xmm5, [rsp+0x70]
00007cd93bddc079  vmovaps [rsp+0x70], xmm1
00007cd93bddc07f  movaps xmm15, xmm5
00007cd93bddc083  addpd xmm15, xmm3
00007cd93bddc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bddc08e  ptest xmm1, xmm1
00007cd93bddc093  jnz 0x00007CD93BDDE049
00007cd93bddc099  vmovaps xmm5, [rsp+0x80]
00007cd93bddc0a2  movaps xmm1, xmm5
00007cd93bddc0a5  addpd xmm1, xmm4
00007cd93bddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007cd93bddc0ae  ptest xmm3, xmm3
00007cd93bddc0b3  jnz 0x00007CD93BDDE18B
00007cd93bddc0b9  vmovaps [rsp+0x80], xmm10
00007cd93bddc0c2  vmovaps xmm5, [rsp+0x80]
00007cd93bddc0cb  por xmm10, xmm5
00007cd93bddc0d0  movaps [r15+0x2F0], xmm10
00007cd93bddc0d8  vmovaps xmm5, [rsp+0x50]
00007cd93bddc0de  vpermilpd xmm5, xmm5, 0x00
00007cd93bddc0e4  vmovaps xmm3, [rsp+0x70]
00007cd93bddc0ea  vmovaps [rsp+0x50], xmm1
00007cd93bddc0f0  movaps xmm4, xmm3
00007cd93bddc0f3  mulpd xmm4, xmm5
00007cd93bddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007cd93bddc0fc  ptest xmm1, xmm1
00007cd93bddc101  jnz 0x00007CD93BDDE2CB
00007cd93bddc107  lea r12, [rax+0xD0]
00007cd93bddc10e  movups xmm1, [r13+r12*1]
00007cd93bddc114  vmovaps xmm3, [rsp+0xD0]
00007cd93bddc11d  vmovaps [rsp+0x70], xmm1
00007cd93bddc123  movaps xmm5, xmm6
00007cd93bddc126  addpd xmm5, xmm3
00007cd93bddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007cd93bddc12f  ptest xmm1, xmm1
00007cd93bddc134  jnz 0x00007CD93BDDE415
00007cd93bddc13a  vmovaps xmm1, [rsp+0x60]
00007cd93bddc140  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc146  movaps xmm6, xmm9
00007cd93bddc14a  mulpd xmm6, xmm1
00007cd93bddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007cd93bddc153  ptest xmm3, xmm3
00007cd93bddc158  jnz 0x00007CD93BDDE555
00007cd93bddc15e  movaps [r15+0x260], xmm6
00007cd93bddc166  vxorps xmm1, xmm1, xmm1
00007cd93bddc16a  vpbroadcastq xmm1, xmm1
00007cd93bddc16f  movaps [r15+0x1B0], xmm1
00007cd93bddc177  vmovaps xmm1, [rsp+0x60]
00007cd93bddc17d  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc183  vmovaps xmm3, [rsp+0x70]
00007cd93bddc189  vmovaps [rsp+0x70], xmm15
00007cd93bddc18f  movaps xmm9, xmm3
00007cd93bddc193  mulpd xmm9, xmm1
00007cd93bddc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007cd93bddc19e  ptest xmm15, xmm15
00007cd93bddc1a4  jnz 0x00007CD93BDDE696
00007cd93bddc1aa  lea r12, [rax+0xC0]
00007cd93bddc1b1  movups xmm1, [r13+r12*1]
00007cd93bddc1b7  vmovaps xmm3, [rsp+0xC0]
00007cd93bddc1c0  vmovaps [rsp+0x80], xmm1
00007cd93bddc1c9  movaps xmm15, xmm3
00007cd93bddc1cd  addpd xmm15, xmm7
00007cd93bddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bddc1d8  ptest xmm1, xmm1
00007cd93bddc1dd  jnz 0x00007CD93BDDE7E2
00007cd93bddc1e3  vmovaps [rsp+0xC0], xmm13
00007cd93bddc1ec  vmovaps xmm1, [rsp+0xC0]
00007cd93bddc1f5  por xmm13, xmm1
00007cd93bddc1fa  movaps [r15+0x270], xmm13
00007cd93bddc202  vmovaps xmm1, [rsp+0xB0]
00007cd93bddc20b  vmovaps xmm7, [rsp+0xB0]
00007cd93bddc214  por xmm1, xmm7
00007cd93bddc218  movaps [r15+0x1A0], xmm1
00007cd93bddc220  vmovaps xmm1, [rsp+0x60]
00007cd93bddc226  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc22c  vmovaps [rsp+0xB0], xmm1
00007cd93bddc235  vmovaps xmm1, [rsp+0x80]
00007cd93bddc23e  vmovaps [rsp+0x80], xmm15
00007cd93bddc247  vmovaps xmm15, [rsp+0xB0]
00007cd93bddc250  vmovaps [rsp+0xB0], xmm14
00007cd93bddc259  movaps xmm3, xmm1
00007cd93bddc25c  mulpd xmm3, xmm15
00007cd93bddc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007cd93bddc266  ptest xmm14, xmm14
00007cd93bddc26c  jnz 0x00007CD93BDDE924
00007cd93bddc272  lea r12, [rax+0x20]
00007cd93bddc276  movups xmm1, [r13+r12*1]
00007cd93bddc27c  movaps [r15+0x110], xmm1
00007cd93bddc284  vmovaps xmm14, [rsp+0x70]
00007cd93bddc28a  vmovaps [rsp+0x70], xmm1
00007cd93bddc290  movaps xmm15, xmm14
00007cd93bddc294  addpd xmm15, xmm4
00007cd93bddc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007cd93bddc29f  ptest xmm1, xmm1
00007cd93bddc2a4  jnz 0x00007CD93BDDEA6F
00007cd93bddc2aa  vmovaps xmm1, [rsp+0x60]
00007cd93bddc2b0  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc2b6  movaps xmm14, xmm2
00007cd93bddc2ba  mulpd xmm14, xmm1
00007cd93bddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007cd93bddc2c5  ptest xmm4, xmm4
00007cd93bddc2ca  jnz 0x00007CD93BDDEBB2
00007cd93bddc2d0  vmovaps xmm4, [rsp+0x50]
00007cd93bddc2d6  movaps xmm1, xmm4
00007cd93bddc2d9  addpd xmm1, xmm9
00007cd93bddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007cd93bddc2e3  ptest xmm2, xmm2
00007cd93bddc2e8  jnz 0x00007CD93BDDECF4
00007cd93bddc2ee  vmovaps xmm9, [rsp+0x30]
00007cd93bddc2f4  vpermilpd xmm9, xmm9, 0x00
00007cd93bddc2fa  vmovaps xmm2, [rsp+0x70]
00007cd93bddc300  vmovaps [rsp+0x50], xmm1
00007cd93bddc306  movaps xmm4, xmm2
00007cd93bddc309  mulpd xmm4, xmm9
00007cd93bddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007cd93bddc313  ptest xmm1, xmm1
00007cd93bddc318  jnz 0x00007CD93BDDEE35
00007cd93bddc31e  vmovaps xmm1, [rsp+0x30]
00007cd93bddc324  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc32a  vmovaps xmm2, [rsp+0x90]
00007cd93bddc333  vmovaps [rsp+0x60], xmm15
00007cd93bddc339  movaps xmm9, xmm2
00007cd93bddc33d  mulpd xmm9, xmm1
00007cd93bddc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007cd93bddc348  ptest xmm15, xmm15
00007cd93bddc34e  jnz 0x00007CD93BDDEF76
00007cd93bddc354  vmovaps xmm15, [rsp+0x80]
00007cd93bddc35d  movaps xmm1, xmm15
00007cd93bddc361  addpd xmm1, xmm6
00007cd93bddc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007cd93bddc36a  ptest xmm2, xmm2
00007cd93bddc36f  jnz 0x00007CD93BDDF0B8
00007cd93bddc375  movaps xmm15, xmm5
00007cd93bddc379  addpd xmm15, xmm3
00007cd93bddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007cd93bddc384  ptest xmm6, xmm6
00007cd93bddc389  jnz 0x00007CD93BDDF1F9
00007cd93bddc38f  vmovaps xmm6, [rsp+0x30]
00007cd93bddc395  vpermilpd xmm6, xmm6, 0x00
00007cd93bddc39b  movaps xmm5, xmm8
00007cd93bddc39f  mulpd xmm5, xmm6
00007cd93bddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007cd93bddc3a8  ptest xmm3, xmm3
00007cd93bddc3ad  jnz 0x00007CD93BDDF33B
00007cd93bddc3b3  vmovaps xmm8, [rsp+0x30]
00007cd93bddc3b9  vpermilpd xmm8, xmm8, 0x00
00007cd93bddc3bf  movaps xmm6, xmm10
00007cd93bddc3c3  mulpd xmm6, xmm8
00007cd93bddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007cd93bddc3cd  ptest xmm3, xmm3
00007cd93bddc3d2  jnz 0x00007CD93BDDF47C
00007cd93bddc3d8  vmovaps xmm8, [rsp+0x60]
00007cd93bddc3de  movaps xmm10, xmm8
00007cd93bddc3e2  addpd xmm10, xmm14
00007cd93bddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007cd93bddc3ed  ptest xmm3, xmm3
00007cd93bddc3f2  jnz 0x00007CD93BDDF5BE
00007cd93bddc3f8  vmovaps xmm8, [rsp+0x50]
00007cd93bddc3fe  movaps xmm14, xmm8
00007cd93bddc402  addpd xmm14, xmm4
00007cd93bddc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007cd93bddc40d  ptest xmm3, xmm3
00007cd93bddc412  jnz 0x00007CD93BDDF702
00007cd93bddc418  vmovaps xmm8, [rsp+0x40]
00007cd93bddc41e  vpermilpd xmm8, xmm8, 0x00
00007cd93bddc424  movaps xmm4, xmm13
00007cd93bddc428  mulpd xmm4, xmm8
00007cd93bddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007cd93bddc432  ptest xmm3, xmm3
00007cd93bddc437  jnz 0x00007CD93BDDF845
00007cd93bddc43d  movaps xmm13, xmm15
00007cd93bddc441  addpd xmm13, xmm9
00007cd93bddc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007cd93bddc44c  ptest xmm8, xmm8
00007cd93bddc452  jnz 0x00007CD93BDDF987
00007cd93bddc458  movaps xmm15, xmm1
00007cd93bddc45c  addpd xmm15, xmm5
00007cd93bddc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007cd93bddc467  ptest xmm9, xmm9
00007cd93bddc46d  jnz 0x00007CD93BDDFACB
00007cd93bddc473  vmovaps [rsp+0x30], xmm11
00007cd93bddc479  vmovaps xmm1, [rsp+0x30]
00007cd93bddc47f  por xmm11, xmm1
00007cd93bddc484  movaps [r15+0x250], xmm11
00007cd93bddc48c  vmovaps [rsp+0x30], xmm12
00007cd93bddc492  vmovaps xmm1, [rsp+0x30]
00007cd93bddc498  por xmm12, xmm1
00007cd93bddc49d  movaps [r15+0x2A0], xmm12
00007cd93bddc4a5  vmovaps xmm1, [rsp+0xA0]
00007cd93bddc4ae  vmovaps xmm11, [rsp+0xA0]
00007cd93bddc4b7  por xmm1, xmm11
00007cd93bddc4bc  movaps [r15+0x1D0], xmm1
00007cd93bddc4c4  lea r12, [rax+0x40]
00007cd93bddc4c8  movups xmm1, [r13+r12*1]
00007cd93bddc4ce  movaps [r15+0x2C0], xmm1
00007cd93bddc4d6  vmovaps xmm11, [rsp+0x40]
00007cd93bddc4dc  vpermilpd xmm11, xmm11, 0x00
00007cd93bddc4e2  vmovaps xmm8, [rsp+0xE0]
00007cd93bddc4eb  movaps xmm9, xmm8
00007cd93bddc4ef  mulpd xmm9, xmm11
00007cd93bddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007cd93bddc4fa  ptest xmm5, xmm5
00007cd93bddc4ff  jnz 0x00007CD93BDDFC17
00007cd93bddc505  movaps xmm11, xmm10
00007cd93bddc509  addpd xmm11, xmm6
00007cd93bddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007cd93bddc514  ptest xmm8, xmm8
00007cd93bddc51a  jnz 0x00007CD93BDDFD5B
00007cd93bddc520  movaps xmm10, xmm14
00007cd93bddc524  addpd xmm10, xmm4
00007cd93bddc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007cd93bddc52f  ptest xmm8, xmm8
00007cd93bddc535  jnz 0x00007CD93BDDFE9E
00007cd93bddc53b  vmovaps xmm14, [rsp+0x40]
00007cd93bddc541  vpermilpd xmm14, xmm14, 0x00
00007cd93bddc547  movaps xmm8, xmm1
00007cd93bddc54b  mulpd xmm8, xmm14
00007cd93bddc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007cd93bddc556  ptest xmm6, xmm6
00007cd93bddc55b  jnz 0x00007CD93BDDFFE1
00007cd93bddc561  movaps xmm1, [r15+0x2B0]
00007cd93bddc569  vmovaps xmm14, [rsp+0x40]
00007cd93bddc56f  vpermilpd xmm14, xmm14, 0x00
00007cd93bddc575  movaps xmm6, xmm1
00007cd93bddc578  mulpd xmm6, xmm14
00007cd93bddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007cd93bddc582  ptest xmm5, xmm5
00007cd93bddc587  jnz 0x00007CD93BDE0124
00007cd93bddc58d  vmovaps xmm1, [rsp+0x10]
00007cd93bddc593  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc599  movaps xmm14, xmm12
00007cd93bddc59d  mulpd xmm14, xmm1
00007cd93bddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007cd93bddc5a8  ptest xmm5, xmm5
00007cd93bddc5ad  jnz 0x00007CD93BDE0265
00007cd93bddc5b3  movaps xmm1, xmm13
00007cd93bddc5b7  addpd xmm1, xmm9
00007cd93bddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007cd93bddc5c1  ptest xmm12, xmm12
00007cd93bddc5c7  jnz 0x00007CD93BDE03A8
00007cd93bddc5cd  vmovaps xmm13, [rsp+0x10]
00007cd93bddc5d3  vpermilpd xmm13, xmm13, 0x00
00007cd93bddc5d9  movaps xmm12, xmm7
00007cd93bddc5dd  mulpd xmm12, xmm13
00007cd93bddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007cd93bddc5e8  ptest xmm9, xmm9
00007cd93bddc5ee  jnz 0x00007CD93BDE04EA
00007cd93bddc5f4  movaps xmm13, xmm15
00007cd93bddc5f8  addpd xmm13, xmm8
00007cd93bddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007cd93bddc603  ptest xmm9, xmm9
00007cd93bddc609  jnz 0x00007CD93BDE062D
00007cd93bddc60f  movaps xmm15, [r15+0x290]
00007cd93bddc617  vmovaps xmm9, [rsp+0x10]
00007cd93bddc61d  vpermilpd xmm9, xmm9, 0x00
00007cd93bddc623  movaps xmm8, xmm15
00007cd93bddc627  mulpd xmm8, xmm9
00007cd93bddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007cd93bddc632  ptest xmm7, xmm7
00007cd93bddc637  jnz 0x00007CD93BDE0771
00007cd93bddc63d  movaps xmm15, xmm11
00007cd93bddc641  addpd xmm15, xmm6
00007cd93bddc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007cd93bddc64c  ptest xmm9, xmm9
00007cd93bddc652  jnz 0x00007CD93BDE08B5
00007cd93bddc658  movaps xmm11, [r15+0x1E0]
00007cd93bddc660  vmovaps xmm9, [rsp+0x10]
00007cd93bddc666  vpermilpd xmm9, xmm9, 0x00
00007cd93bddc66c  movaps xmm7, xmm11
00007cd93bddc670  mulpd xmm7, xmm9
00007cd93bddc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007cd93bddc67a  ptest xmm6, xmm6
00007cd93bddc67f  jnz 0x00007CD93BDE09F8
00007cd93bddc685  movaps xmm11, xmm10
00007cd93bddc689  addpd xmm11, xmm14
00007cd93bddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007cd93bddc694  ptest xmm9, xmm9
00007cd93bddc69a  jnz 0x00007CD93BDE0B3A
00007cd93bddc6a0  lea r12, [rax+0x70]
00007cd93bddc6a4  movups xmm14, [r13+r12*1]
00007cd93bddc6aa  movaps [r15+0x240], xmm14
00007cd93bddc6b2  movaps xmm10, xmm1
00007cd93bddc6b6  addpd xmm10, xmm12
00007cd93bddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007cd93bddc6c1  ptest xmm9, xmm9
00007cd93bddc6c7  jnz 0x00007CD93BDE0C88
00007cd93bddc6cd  movaps [r15+0x170], xmm10
00007cd93bddc6d5  vmovaps xmm1, [rsp+0x20]
00007cd93bddc6db  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc6e1  movaps xmm12, xmm14
00007cd93bddc6e5  mulpd xmm12, xmm1
00007cd93bddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007cd93bddc6f0  ptest xmm9, xmm9
00007cd93bddc6f6  jnz 0x00007CD93BDE0DCB
00007cd93bddc6fc  vmovaps xmm1, [rsp+0x20]
00007cd93bddc702  vpermilpd xmm1, xmm1, 0x00
00007cd93bddc708  vmovaps xmm9, [rsp+0xB0]
00007cd93bddc711  movaps xmm14, xmm9
00007cd93bddc715  mulpd xmm14, xmm1
00007cd93bddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007cd93bddc720  ptest xmm6, xmm6
00007cd93bddc725  jnz 0x00007CD93BDE0F0E
00007cd93bddc72b  movaps [r15+0x180], xmm14
00007cd93bddc733  movaps xmm1, xmm13
00007cd93bddc737  addpd xmm1, xmm8
00007cd93bddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007cd93bddc741  ptest xmm9, xmm9
00007cd93bddc747  jnz 0x00007CD93BDE1051
00007cd93bddc74d  movaps [r15+0x210], xmm1
00007cd93bddc755  movups xmm13, [r13+rax*1]
00007cd93bddc75b  lea r12, [rax+0x10]
00007cd93bddc75f  movups xmm9, [r13+r12*1]
00007cd93bddc765  movaps [r15+0x230], xmm9
00007cd93bddc76d  movaps xmm8, xmm15
00007cd93bddc771  addpd xmm8, xmm7
00007cd93bddc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007cd93bddc77c  ptest xmm6, xmm6
00007cd93bddc781  jnz 0x00007CD93BDE11A7
00007cd93bddc787  movaps [r15+0x130], xmm8
00007cd93bddc78f  vmovaps xmm15, [rsp+0x20]
00007cd93bddc795  vpermilpd xmm15, xmm15, 0x00
00007cd93bddc79b  movaps xmm7, xmm9
00007cd93bddc79f  mulpd xmm7, xmm15
00007cd93bddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007cd93bddc7a9  ptest xmm6, xmm6
00007cd93bddc7ae  jnz 0x00007CD93BDE12EA
00007cd93bddc7b4  movaps [r15+0x220], xmm7
00007cd93bddc7bc  vmovaps xmm15, [rsp+0x20]
00007cd93bddc7c2  vpermilpd xmm15, xmm15, 0x00
00007cd93bddc7c8  movaps xmm9, xmm13
00007cd93bddc7cc  mulpd xmm9, xmm15
00007cd93bddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007cd93bddc7d7  ptest xmm6, xmm6
00007cd93bddc7dc  jnz 0x00007CD93BDE142C
00007cd93bddc7e2  movaps xmm15, xmm11
00007cd93bddc7e6  addpd xmm15, xmm12
00007cd93bddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007cd93bddc7f1  ptest xmm13, xmm13
00007cd93bddc7f7  jnz 0x00007CD93BDE1570
00007cd93bddc7fd  movaps [r15+0x140], xmm15
00007cd93bddc805  movaps xmm13, xmm10
00007cd93bddc809  addpd xmm13, xmm14
00007cd93bddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007cd93bddc814  ptest xmm12, xmm12
00007cd93bddc81a  jnz 0x00007CD93BDE16B4
00007cd93bddc820  movaps [r15+0x150], xmm13
00007cd93bddc828  movaps xmm14, xmm1
00007cd93bddc82c  addpd xmm14, xmm7
00007cd93bddc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007cd93bddc837  ptest xmm12, xmm12
00007cd93bddc83d  jnz 0x00007CD93BDE17F8
00007cd93bddc843  movaps [r15+0x160], xmm14
00007cd93bddc84b  movaps xmm1, xmm8
00007cd93bddc84f  addpd xmm1, xmm9
00007cd93bddc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007cd93bddc859  ptest xmm12, xmm12
00007cd93bddc85f  jnz 0x00007CD93BDE193A
00007cd93bddc865  movaps [r15+0x120], xmm1
00007cd93bddc86d  movups [r13+r14*1], xmm15
00007cd93bddc873  lea rax, [r14+0x10]
00007cd93bddc877  movups [r13+rax*1], xmm13
00007cd93bddc87d  lea rax, [r14+0x20]
00007cd93bddc881  movups [r13+rax*1], xmm14
00007cd93bddc887  lea rax, [r14+0x30]
00007cd93bddc88b  movups [r13+rax*1], xmm1
00007cd93bddc891  mov eax, [r15+0x108]
00007cd93bddc898  sahf
00007cd93bddc899  jnz 0x00007CD93BDDC8CB
00007cd93bddc89b  cmp dword ptr [r15+0x318], 0x00
00007cd93bddc8a3  jz 0x00007CD93BDDB900
00007cd93bddc8a9  nop [rax+rax*1], ax
00007cd93bddc8b2  nop [rax+rax*1], eax
00007cd93bddc8ba  mov eax, 0x410444
00007cd93bddc8bf  mov [r15+0x100], rax
00007cd93bddc8c6  jmp 0x00007CD93BBFE110
00007cd93bddc8cb  cmp dword ptr [r15+0x318], 0x00
00007cd93bddc8d3  jz 0x00007CD93BDD57E0
00007cd93bddc8d9  nop [rax+rax*1], ax
00007cd93bddc8e2  nop [rax+rax*1], eax
00007cd93bddc8ea  mov eax, 0x410278
00007cd93bddc8ef  mov [r15+0x100], rax
00007cd93bddc8f6  jmp 0x00007CD93BBFE110
00007cd93bddc8fb  int3
00007cd93bddc8fc  call 0x00007CD93BCE27E0
00007cd93bddc901  jmp 0x00007CD93BDDB9DF
00007cd93bddc906  call 0x00007CD93BCE1570
00007cd93bddc90b  jmp 0x00007CD93BDDB9E8
00007cd93bddc910  call 0x00007CD93BCE27E0
00007cd93bddc915  jmp 0x00007CD93BDDBA44
00007cd93bddc91a  call 0x00007CD93BCE1570
00007cd93bddc91f  jmp 0x00007CD93BDDBA4D
00007cd93bddc924  call 0x00007CD93BCE27E0
00007cd93bddc929  jmp 0x00007CD93BDDBA90
00007cd93bddc92e  call 0x00007CD93BCE1570
00007cd93bddc933  jmp 0x00007CD93BDDBA99
00007cd93bddc938  call 0x00007CD93BC0DC20
00007cd93bddc93d  jmp 0x00007CD93BDDBAD8
00007cd93bddc942  call 0x00007CD93BCD59C0
00007cd93bddc947  jmp 0x00007CD93BDDBAEB
00007cd93bddc94c  call 0x00007CD93BCE0E30
00007cd93bddc951  jmp 0x00007CD93BDDBB09
00007cd93bddc956  call 0x00007CD93BCDFBC0
00007cd93bddc95b  jmp 0x00007CD93BDDBB13
00007cd93bddc960  call 0x00007CD93BCDE950
00007cd93bddc965  jmp 0x00007CD93BDDBB1D
00007cd93bddc96a  sub rsp, 0x08
00007cd93bddc96e  push rax
00007cd93bddc96f  push rcx
00007cd93bddc970  push rdx
00007cd93bddc971  push rdi
00007cd93bddc972  push rsi
00007cd93bddc973  push r8
00007cd93bddc975  push r9
00007cd93bddc977  push r10
00007cd93bddc979  push r11
00007cd93bddc97b  sub rsp, 0xF0
00007cd93bddc982  vmovaps [rsp], xmm0
00007cd93bddc987  vmovaps [rsp+0x10], xmm1
00007cd93bddc98d  vmovaps [rsp+0x20], xmm2
00007cd93bddc993  vmovaps [rsp+0x30], xmm3
00007cd93bddc999  vmovaps [rsp+0x40], xmm4
00007cd93bddc99f  vmovaps [rsp+0x50], xmm5
00007cd93bddc9a5  vmovaps [rsp+0x60], xmm6
00007cd93bddc9ab  vmovaps [rsp+0x70], xmm7
00007cd93bddc9b1  vmovaps [rsp+0x80], xmm9
00007cd93bddc9ba  vmovaps [rsp+0x90], xmm10
00007cd93bddc9c3  vmovaps [rsp+0xA0], xmm11
00007cd93bddc9cc  vmovaps [rsp+0xB0], xmm12
00007cd93bddc9d5  vmovaps [rsp+0xC0], xmm13
00007cd93bddc9de  vmovaps [rsp+0xD0], xmm14
00007cd93bddc9e7  vmovaps [rsp+0xE0], xmm15
00007cd93bddc9f0  sub rsp, 0x30
00007cd93bddc9f4  movaps [rsp], xmm8
00007cd93bddc9f9  movaps [rsp+0x10], xmm12
00007cd93bddc9ff  movaps [rsp+0x20], xmm15
00007cd93bddca05  lea rdi, [rsp]
00007cd93bddca09  mov esi, 0x00
00007cd93bddca0e  mov rax, 0x64A581057530
00007cd93bddca18  call rax
00007cd93bddca1a  movaps xmm8, [rsp]
00007cd93bddca1f  add rsp, 0x30
00007cd93bddca23  vmovaps xmm0, [rsp]
00007cd93bddca28  vmovaps xmm1, [rsp+0x10]
00007cd93bddca2e  vmovaps xmm2, [rsp+0x20]
00007cd93bddca34  vmovaps xmm3, [rsp+0x30]
00007cd93bddca3a  vmovaps xmm4, [rsp+0x40]
00007cd93bddca40  vmovaps xmm5, [rsp+0x50]
00007cd93bddca46  vmovaps xmm6, [rsp+0x60]
00007cd93bddca4c  vmovaps xmm7, [rsp+0x70]
00007cd93bddca52  vmovaps xmm9, [rsp+0x80]
00007cd93bddca5b  vmovaps xmm10, [rsp+0x90]
00007cd93bddca64  vmovaps xmm11, [rsp+0xA0]
00007cd93bddca6d  vmovaps xmm12, [rsp+0xB0]
00007cd93bddca76  vmovaps xmm13, [rsp+0xC0]
00007cd93bddca7f  vmovaps xmm14, [rsp+0xD0]
00007cd93bddca88  vmovaps xmm15, [rsp+0xE0]
00007cd93bddca91  add rsp, 0xF0
00007cd93bddca98  pop r11
00007cd93bddca9a  pop r10
00007cd93bddca9c  pop r9
00007cd93bddca9e  pop r8
00007cd93bddcaa0  pop rsi
00007cd93bddcaa1  pop rdi
00007cd93bddcaa2  pop rdx
00007cd93bddcaa3  pop rcx
00007cd93bddcaa4  pop rax
00007cd93bddcaa5  add rsp, 0x08
00007cd93bddcaa9  jmp 0x00007CD93BDDBB47
00007cd93bddcaae  sub rsp, 0x08
00007cd93bddcab2  push rax
00007cd93bddcab3  push rcx
00007cd93bddcab4  push rdx
00007cd93bddcab5  push rdi
00007cd93bddcab6  push rsi
00007cd93bddcab7  push r8
00007cd93bddcab9  push r9
00007cd93bddcabb  push r10
00007cd93bddcabd  push r11
00007cd93bddcabf  sub rsp, 0xF0
00007cd93bddcac6  vmovaps [rsp], xmm0
00007cd93bddcacb  vmovaps [rsp+0x10], xmm1
00007cd93bddcad1  vmovaps [rsp+0x20], xmm2
00007cd93bddcad7  vmovaps [rsp+0x30], xmm3
00007cd93bddcadd  vmovaps [rsp+0x40], xmm4
00007cd93bddcae3  vmovaps [rsp+0x50], xmm5
00007cd93bddcae9  vmovaps [rsp+0x60], xmm6
00007cd93bddcaef  vmovaps [rsp+0x70], xmm8
00007cd93bddcaf5  vmovaps [rsp+0x80], xmm9
00007cd93bddcafe  vmovaps [rsp+0x90], xmm10
00007cd93bddcb07  vmovaps [rsp+0xA0], xmm11
00007cd93bddcb10  vmovaps [rsp+0xB0], xmm12
00007cd93bddcb19  vmovaps [rsp+0xC0], xmm13
00007cd93bddcb22  vmovaps [rsp+0xD0], xmm14
00007cd93bddcb2b  vmovaps [rsp+0xE0], xmm15
00007cd93bddcb34  sub rsp, 0x30
00007cd93bddcb38  movaps [rsp], xmm7
00007cd93bddcb3c  movaps [rsp+0x10], xmm9
00007cd93bddcb42  movaps [rsp+0x20], xmm15
00007cd93bddcb48  lea rdi, [rsp]
00007cd93bddcb4c  mov esi, 0x00
00007cd93bddcb51  mov rax, 0x64A581057530
00007cd93bddcb5b  call rax
00007cd93bddcb5d  movaps xmm7, [rsp]
00007cd93bddcb61  add rsp, 0x30
00007cd93bddcb65  vmovaps xmm0, [rsp]
00007cd93bddcb6a  vmovaps xmm1, [rsp+0x10]
00007cd93bddcb70  vmovaps xmm2, [rsp+0x20]
00007cd93bddcb76  vmovaps xmm3, [rsp+0x30]
00007cd93bddcb7c  vmovaps xmm4, [rsp+0x40]
00007cd93bddcb82  vmovaps xmm5, [rsp+0x50]
00007cd93bddcb88  vmovaps xmm6, [rsp+0x60]
00007cd93bddcb8e  vmovaps xmm8, [rsp+0x70]
00007cd93bddcb94  vmovaps xmm9, [rsp+0x80]
00007cd93bddcb9d  vmovaps xmm10, [rsp+0x90]
00007cd93bddcba6  vmovaps xmm11, [rsp+0xA0]
00007cd93bddcbaf  vmovaps xmm12, [rsp+0xB0]
00007cd93bddcbb8  vmovaps xmm13, [rsp+0xC0]
00007cd93bddcbc1  vmovaps xmm14, [rsp+0xD0]
00007cd93bddcbca  vmovaps xmm15, [rsp+0xE0]
00007cd93bddcbd3  add rsp, 0xF0
00007cd93bddcbda  pop r11
00007cd93bddcbdc  pop r10
00007cd93bddcbde  pop r9
00007cd93bddcbe0  pop r8
00007cd93bddcbe2  pop rsi
00007cd93bddcbe3  pop rdi
00007cd93bddcbe4  pop rdx
00007cd93bddcbe5  pop rcx
00007cd93bddcbe6  pop rax
00007cd93bddcbe7  add rsp, 0x08
00007cd93bddcbeb  jmp 0x00007CD93BDDBB75
00007cd93bddcbf0  sub rsp, 0x08
00007cd93bddcbf4  push rax
00007cd93bddcbf5  push rcx
00007cd93bddcbf6  push rdx
00007cd93bddcbf7  push rdi
00007cd93bddcbf8  push rsi
00007cd93bddcbf9  push r8
00007cd93bddcbfb  push r9
00007cd93bddcbfd  push r10
00007cd93bddcbff  push r11
00007cd93bddcc01  sub rsp, 0xF0
00007cd93bddcc08  vmovaps [rsp], xmm0
00007cd93bddcc0d  vmovaps [rsp+0x10], xmm1
00007cd93bddcc13  vmovaps [rsp+0x20], xmm2
00007cd93bddcc19  vmovaps [rsp+0x30], xmm3
00007cd93bddcc1f  vmovaps [rsp+0x40], xmm4
00007cd93bddcc25  vmovaps [rsp+0x50], xmm5
00007cd93bddcc2b  vmovaps [rsp+0x60], xmm6
00007cd93bddcc31  vmovaps [rsp+0x70], xmm7
00007cd93bddcc37  vmovaps [rsp+0x80], xmm8
00007cd93bddcc40  vmovaps [rsp+0x90], xmm10
00007cd93bddcc49  vmovaps [rsp+0xA0], xmm11
00007cd93bddcc52  vmovaps [rsp+0xB0], xmm12
00007cd93bddcc5b  vmovaps [rsp+0xC0], xmm13
00007cd93bddcc64  vmovaps [rsp+0xD0], xmm14
00007cd93bddcc6d  vmovaps [rsp+0xE0], xmm15
00007cd93bddcc76  sub rsp, 0x30
00007cd93bddcc7a  movaps [rsp], xmm9
00007cd93bddcc7f  movaps [rsp+0x10], xmm12
00007cd93bddcc85  movaps [rsp+0x20], xmm10
00007cd93bddcc8b  lea rdi, [rsp]
00007cd93bddcc8f  mov esi, 0x00
00007cd93bddcc94  mov rax, 0x64A581057530
00007cd93bddcc9e  call rax
00007cd93bddcca0  movaps xmm9, [rsp]
00007cd93bddcca5  add rsp, 0x30
00007cd93bddcca9  vmovaps xmm0, [rsp]
00007cd93bddccae  vmovaps xmm1, [rsp+0x10]
00007cd93bddccb4  vmovaps xmm2, [rsp+0x20]
00007cd93bddccba  vmovaps xmm3, [rsp+0x30]
00007cd93bddccc0  vmovaps xmm4, [rsp+0x40]
00007cd93bddccc6  vmovaps xmm5, [rsp+0x50]
00007cd93bddcccc  vmovaps xmm6, [rsp+0x60]
00007cd93bddccd2  vmovaps xmm7, [rsp+0x70]
00007cd93bddccd8  vmovaps xmm8, [rsp+0x80]
00007cd93bddcce1  vmovaps xmm10, [rsp+0x90]
00007cd93bddccea  vmovaps xmm11, [rsp+0xA0]
00007cd93bddccf3  vmovaps xmm12, [rsp+0xB0]
00007cd93bddccfc  vmovaps xmm13, [rsp+0xC0]
00007cd93bddcd05  vmovaps xmm14, [rsp+0xD0]
00007cd93bddcd0e  vmovaps xmm15, [rsp+0xE0]
00007cd93bddcd17  add rsp, 0xF0
00007cd93bddcd1e  pop r11
00007cd93bddcd20  pop r10
00007cd93bddcd22  pop r9
00007cd93bddcd24  pop r8
00007cd93bddcd26  pop rsi
00007cd93bddcd27  pop rdi
00007cd93bddcd28  pop rdx
00007cd93bddcd29  pop rcx
00007cd93bddcd2a  pop rax
00007cd93bddcd2b  add rsp, 0x08
00007cd93bddcd2f  jmp 0x00007CD93BDDBB99
00007cd93bddcd34  sub rsp, 0x08
00007cd93bddcd38  push rax
00007cd93bddcd39  push rcx
00007cd93bddcd3a  push rdx
00007cd93bddcd3b  push rdi
00007cd93bddcd3c  push rsi
00007cd93bddcd3d  push r8
00007cd93bddcd3f  push r9
00007cd93bddcd41  push r10
00007cd93bddcd43  push r11
00007cd93bddcd45  sub rsp, 0xF0
00007cd93bddcd4c  vmovaps [rsp], xmm0
00007cd93bddcd51  vmovaps [rsp+0x10], xmm1
00007cd93bddcd57  vmovaps [rsp+0x20], xmm2
00007cd93bddcd5d  vmovaps [rsp+0x30], xmm3
00007cd93bddcd63  vmovaps [rsp+0x40], xmm4
00007cd93bddcd69  vmovaps [rsp+0x50], xmm5
00007cd93bddcd6f  vmovaps [rsp+0x60], xmm6
00007cd93bddcd75  vmovaps [rsp+0x70], xmm7
00007cd93bddcd7b  vmovaps [rsp+0x80], xmm8
00007cd93bddcd84  vmovaps [rsp+0x90], xmm9
00007cd93bddcd8d  vmovaps [rsp+0xA0], xmm11
00007cd93bddcd96  vmovaps [rsp+0xB0], xmm12
00007cd93bddcd9f  vmovaps [rsp+0xC0], xmm13
00007cd93bddcda8  vmovaps [rsp+0xD0], xmm14
00007cd93bddcdb1  vmovaps [rsp+0xE0], xmm15
00007cd93bddcdba  sub rsp, 0x30
00007cd93bddcdbe  movaps [rsp], xmm10
00007cd93bddcdc3  movaps [rsp+0x10], xmm12
00007cd93bddcdc9  movaps [rsp+0x20], xmm11
00007cd93bddcdcf  lea rdi, [rsp]
00007cd93bddcdd3  mov esi, 0x00
00007cd93bddcdd8  mov rax, 0x64A581057530
00007cd93bddcde2  call rax
00007cd93bddcde4  movaps xmm10, [rsp]
00007cd93bddcde9  add rsp, 0x30
00007cd93bddcded  vmovaps xmm0, [rsp]
00007cd93bddcdf2  vmovaps xmm1, [rsp+0x10]
00007cd93bddcdf8  vmovaps xmm2, [rsp+0x20]
00007cd93bddcdfe  vmovaps xmm3, [rsp+0x30]
00007cd93bddce04  vmovaps xmm4, [rsp+0x40]
00007cd93bddce0a  vmovaps xmm5, [rsp+0x50]
00007cd93bddce10  vmovaps xmm6, [rsp+0x60]
00007cd93bddce16  vmovaps xmm7, [rsp+0x70]
00007cd93bddce1c  vmovaps xmm8, [rsp+0x80]
00007cd93bddce25  vmovaps xmm9, [rsp+0x90]
00007cd93bddce2e  vmovaps xmm11, [rsp+0xA0]
00007cd93bddce37  vmovaps xmm12, [rsp+0xB0]
00007cd93bddce40  vmovaps xmm13, [rsp+0xC0]
00007cd93bddce49  vmovaps xmm14, [rsp+0xD0]
00007cd93bddce52  vmovaps xmm15, [rsp+0xE0]
00007cd93bddce5b  add rsp, 0xF0
00007cd93bddce62  pop r11
00007cd93bddce64  pop r10
00007cd93bddce66  pop r9
00007cd93bddce68  pop r8
00007cd93bddce6a  pop rsi
00007cd93bddce6b  pop rdi
00007cd93bddce6c  pop rdx
00007cd93bddce6d  pop rcx
00007cd93bddce6e  pop rax
00007cd93bddce6f  add rsp, 0x08
00007cd93bddce73  jmp 0x00007CD93BDDBBB3
00007cd93bddce78  sub rsp, 0x08
00007cd93bddce7c  push rax
00007cd93bddce7d  push rcx
00007cd93bddce7e  push rdx
00007cd93bddce7f  push rdi
00007cd93bddce80  push rsi
00007cd93bddce81  push r8
00007cd93bddce83  push r9
00007cd93bddce85  push r10
00007cd93bddce87  push r11
00007cd93bddce89  sub rsp, 0xF0
00007cd93bddce90  vmovaps [rsp], xmm0
00007cd93bddce95  vmovaps [rsp+0x10], xmm1
00007cd93bddce9b  vmovaps [rsp+0x20], xmm2
00007cd93bddcea1  vmovaps [rsp+0x30], xmm3
00007cd93bddcea7  vmovaps [rsp+0x40], xmm4
00007cd93bddcead  vmovaps [rsp+0x50], xmm5
00007cd93bddceb3  vmovaps [rsp+0x60], xmm7
00007cd93bddceb9  vmovaps [rsp+0x70], xmm8
00007cd93bddcebf  vmovaps [rsp+0x80], xmm9
00007cd93bddcec8  vmovaps [rsp+0x90], xmm10
00007cd93bddced1  vmovaps [rsp+0xA0], xmm11
00007cd93bddceda  vmovaps [rsp+0xB0], xmm12
00007cd93bddcee3  vmovaps [rsp+0xC0], xmm13
00007cd93bddceec  vmovaps [rsp+0xD0], xmm14
00007cd93bddcef5  vmovaps [rsp+0xE0], xmm15
00007cd93bddcefe  sub rsp, 0x30
00007cd93bddcf02  movaps [rsp], xmm6
00007cd93bddcf06  movaps [rsp+0x10], xmm12
00007cd93bddcf0c  movaps [rsp+0x20], xmm11
00007cd93bddcf12  lea rdi, [rsp]
00007cd93bddcf16  mov esi, 0x00
00007cd93bddcf1b  mov rax, 0x64A581057530
00007cd93bddcf25  call rax
00007cd93bddcf27  movaps xmm6, [rsp]
00007cd93bddcf2b  add rsp, 0x30
00007cd93bddcf2f  vmovaps xmm0, [rsp]
00007cd93bddcf34  vmovaps xmm1, [rsp+0x10]
00007cd93bddcf3a  vmovaps xmm2, [rsp+0x20]
00007cd93bddcf40  vmovaps xmm3, [rsp+0x30]
00007cd93bddcf46  vmovaps xmm4, [rsp+0x40]
00007cd93bddcf4c  vmovaps xmm5, [rsp+0x50]
00007cd93bddcf52  vmovaps xmm7, [rsp+0x60]
00007cd93bddcf58  vmovaps xmm8, [rsp+0x70]
00007cd93bddcf5e  vmovaps xmm9, [rsp+0x80]
00007cd93bddcf67  vmovaps xmm10, [rsp+0x90]
00007cd93bddcf70  vmovaps xmm11, [rsp+0xA0]
00007cd93bddcf79  vmovaps xmm12, [rsp+0xB0]
00007cd93bddcf82  vmovaps xmm13, [rsp+0xC0]
00007cd93bddcf8b  vmovaps xmm14, [rsp+0xD0]
00007cd93bddcf94  vmovaps xmm15, [rsp+0xE0]
00007cd93bddcf9d  add rsp, 0xF0
00007cd93bddcfa4  pop r11
00007cd93bddcfa6  pop r10
00007cd93bddcfa8  pop r9
00007cd93bddcfaa  pop r8
00007cd93bddcfac  pop rsi
00007cd93bddcfad  pop rdi
00007cd93bddcfae  pop rdx
00007cd93bddcfaf  pop rcx
00007cd93bddcfb0  pop rax
00007cd93bddcfb1  add rsp, 0x08
00007cd93bddcfb5  jmp 0x00007CD93BDDBBD4
00007cd93bddcfba  sub rsp, 0x08
00007cd93bddcfbe  push rax
00007cd93bddcfbf  push rcx
00007cd93bddcfc0  push rdx
00007cd93bddcfc1  push rdi
00007cd93bddcfc2  push rsi
00007cd93bddcfc3  push r8
00007cd93bddcfc5  push r9
00007cd93bddcfc7  push r10
00007cd93bddcfc9  push r11
00007cd93bddcfcb  sub rsp, 0xF0
00007cd93bddcfd2  vmovaps [rsp], xmm0
00007cd93bddcfd7  vmovaps [rsp+0x10], xmm1
00007cd93bddcfdd  vmovaps [rsp+0x20], xmm2
00007cd93bddcfe3  vmovaps [rsp+0x30], xmm4
00007cd93bddcfe9  vmovaps [rsp+0x40], xmm5
00007cd93bddcfef  vmovaps [rsp+0x50], xmm6
00007cd93bddcff5  vmovaps [rsp+0x60], xmm7
00007cd93bddcffb  vmovaps [rsp+0x70], xmm8
00007cd93bddd001  vmovaps [rsp+0x80], xmm9
00007cd93bddd00a  vmovaps [rsp+0x90], xmm10
00007cd93bddd013  vmovaps [rsp+0xA0], xmm11
00007cd93bddd01c  vmovaps [rsp+0xB0], xmm12
00007cd93bddd025  vmovaps [rsp+0xC0], xmm13
00007cd93bddd02e  vmovaps [rsp+0xD0], xmm14
00007cd93bddd037  vmovaps [rsp+0xE0], xmm15
00007cd93bddd040  sub rsp, 0x30
00007cd93bddd044  movaps [rsp], xmm3
00007cd93bddd048  movaps [rsp+0x10], xmm5
00007cd93bddd04d  movaps [rsp+0x20], xmm4
00007cd93bddd052  lea rdi, [rsp]
00007cd93bddd056  mov esi, 0x00
00007cd93bddd05b  mov rax, 0x64A581057530
00007cd93bddd065  call rax
00007cd93bddd067  movaps xmm3, [rsp]
00007cd93bddd06b  add rsp, 0x30
00007cd93bddd06f  vmovaps xmm0, [rsp]
00007cd93bddd074  vmovaps xmm1, [rsp+0x10]
00007cd93bddd07a  vmovaps xmm2, [rsp+0x20]
00007cd93bddd080  vmovaps xmm4, [rsp+0x30]
00007cd93bddd086  vmovaps xmm5, [rsp+0x40]
00007cd93bddd08c  vmovaps xmm6, [rsp+0x50]
00007cd93bddd092  vmovaps xmm7, [rsp+0x60]
00007cd93bddd098  vmovaps xmm8, [rsp+0x70]
00007cd93bddd09e  vmovaps xmm9, [rsp+0x80]
00007cd93bddd0a7  vmovaps xmm10, [rsp+0x90]
00007cd93bddd0b0  vmovaps xmm11, [rsp+0xA0]
00007cd93bddd0b9  vmovaps xmm12, [rsp+0xB0]
00007cd93bddd0c2  vmovaps xmm13, [rsp+0xC0]
00007cd93bddd0cb  vmovaps xmm14, [rsp+0xD0]
00007cd93bddd0d4  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd0dd  add rsp, 0xF0
00007cd93bddd0e4  pop r11
00007cd93bddd0e6  pop r10
00007cd93bddd0e8  pop r9
00007cd93bddd0ea  pop r8
00007cd93bddd0ec  pop rsi
00007cd93bddd0ed  pop rdi
00007cd93bddd0ee  pop rdx
00007cd93bddd0ef  pop rcx
00007cd93bddd0f0  pop rax
00007cd93bddd0f1  add rsp, 0x08
00007cd93bddd0f5  jmp 0x00007CD93BDDBC35
00007cd93bddd0fa  sub rsp, 0x08
00007cd93bddd0fe  push rax
00007cd93bddd0ff  push rcx
00007cd93bddd100  push rdx
00007cd93bddd101  push rdi
00007cd93bddd102  push rsi
00007cd93bddd103  push r8
00007cd93bddd105  push r9
00007cd93bddd107  push r10
00007cd93bddd109  push r11
00007cd93bddd10b  sub rsp, 0xF0
00007cd93bddd112  vmovaps [rsp], xmm0
00007cd93bddd117  vmovaps [rsp+0x10], xmm1
00007cd93bddd11d  vmovaps [rsp+0x20], xmm2
00007cd93bddd123  vmovaps [rsp+0x30], xmm3
00007cd93bddd129  vmovaps [rsp+0x40], xmm4
00007cd93bddd12f  vmovaps [rsp+0x50], xmm6
00007cd93bddd135  vmovaps [rsp+0x60], xmm7
00007cd93bddd13b  vmovaps [rsp+0x70], xmm8
00007cd93bddd141  vmovaps [rsp+0x80], xmm9
00007cd93bddd14a  vmovaps [rsp+0x90], xmm10
00007cd93bddd153  vmovaps [rsp+0xA0], xmm11
00007cd93bddd15c  vmovaps [rsp+0xB0], xmm12
00007cd93bddd165  vmovaps [rsp+0xC0], xmm13
00007cd93bddd16e  vmovaps [rsp+0xD0], xmm14
00007cd93bddd177  vmovaps [rsp+0xE0], xmm15
00007cd93bddd180  sub rsp, 0x30
00007cd93bddd184  movaps [rsp], xmm5
00007cd93bddd188  movaps [rsp+0x10], xmm8
00007cd93bddd18e  movaps [rsp+0x20], xmm15
00007cd93bddd194  lea rdi, [rsp]
00007cd93bddd198  mov esi, 0x00
00007cd93bddd19d  mov rax, 0x64A581057530
00007cd93bddd1a7  call rax
00007cd93bddd1a9  movaps xmm5, [rsp]
00007cd93bddd1ad  add rsp, 0x30
00007cd93bddd1b1  vmovaps xmm0, [rsp]
00007cd93bddd1b6  vmovaps xmm1, [rsp+0x10]
00007cd93bddd1bc  vmovaps xmm2, [rsp+0x20]
00007cd93bddd1c2  vmovaps xmm3, [rsp+0x30]
00007cd93bddd1c8  vmovaps xmm4, [rsp+0x40]
00007cd93bddd1ce  vmovaps xmm6, [rsp+0x50]
00007cd93bddd1d4  vmovaps xmm7, [rsp+0x60]
00007cd93bddd1da  vmovaps xmm8, [rsp+0x70]
00007cd93bddd1e0  vmovaps xmm9, [rsp+0x80]
00007cd93bddd1e9  vmovaps xmm10, [rsp+0x90]
00007cd93bddd1f2  vmovaps xmm11, [rsp+0xA0]
00007cd93bddd1fb  vmovaps xmm12, [rsp+0xB0]
00007cd93bddd204  vmovaps xmm13, [rsp+0xC0]
00007cd93bddd20d  vmovaps xmm14, [rsp+0xD0]
00007cd93bddd216  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd21f  add rsp, 0xF0
00007cd93bddd226  pop r11
00007cd93bddd228  pop r10
00007cd93bddd22a  pop r9
00007cd93bddd22c  pop r8
00007cd93bddd22e  pop rsi
00007cd93bddd22f  pop rdi
00007cd93bddd230  pop rdx
00007cd93bddd231  pop rcx
00007cd93bddd232  pop rax
00007cd93bddd233  add rsp, 0x08
00007cd93bddd237  jmp 0x00007CD93BDDBC73
00007cd93bddd23c  sub rsp, 0x08
00007cd93bddd240  push rax
00007cd93bddd241  push rcx
00007cd93bddd242  push rdx
00007cd93bddd243  push rdi
00007cd93bddd244  push rsi
00007cd93bddd245  push r8
00007cd93bddd247  push r9
00007cd93bddd249  push r10
00007cd93bddd24b  push r11
00007cd93bddd24d  sub rsp, 0xF0
00007cd93bddd254  vmovaps [rsp], xmm0
00007cd93bddd259  vmovaps [rsp+0x10], xmm1
00007cd93bddd25f  vmovaps [rsp+0x20], xmm2
00007cd93bddd265  vmovaps [rsp+0x30], xmm3
00007cd93bddd26b  vmovaps [rsp+0x40], xmm5
00007cd93bddd271  vmovaps [rsp+0x50], xmm6
00007cd93bddd277  vmovaps [rsp+0x60], xmm7
00007cd93bddd27d  vmovaps [rsp+0x70], xmm8
00007cd93bddd283  vmovaps [rsp+0x80], xmm9
00007cd93bddd28c  vmovaps [rsp+0x90], xmm10
00007cd93bddd295  vmovaps [rsp+0xA0], xmm11
00007cd93bddd29e  vmovaps [rsp+0xB0], xmm12
00007cd93bddd2a7  vmovaps [rsp+0xC0], xmm13
00007cd93bddd2b0  vmovaps [rsp+0xD0], xmm14
00007cd93bddd2b9  vmovaps [rsp+0xE0], xmm15
00007cd93bddd2c2  sub rsp, 0x30
00007cd93bddd2c6  movaps [rsp], xmm4
00007cd93bddd2ca  movaps [rsp+0x10], xmm9
00007cd93bddd2d0  movaps [rsp+0x20], xmm8
00007cd93bddd2d6  lea rdi, [rsp]
00007cd93bddd2da  mov esi, 0x00
00007cd93bddd2df  mov rax, 0x64A581057530
00007cd93bddd2e9  call rax
00007cd93bddd2eb  movaps xmm4, [rsp]
00007cd93bddd2ef  add rsp, 0x30
00007cd93bddd2f3  vmovaps xmm0, [rsp]
00007cd93bddd2f8  vmovaps xmm1, [rsp+0x10]
00007cd93bddd2fe  vmovaps xmm2, [rsp+0x20]
00007cd93bddd304  vmovaps xmm3, [rsp+0x30]
00007cd93bddd30a  vmovaps xmm5, [rsp+0x40]
00007cd93bddd310  vmovaps xmm6, [rsp+0x50]
00007cd93bddd316  vmovaps xmm7, [rsp+0x60]
00007cd93bddd31c  vmovaps xmm8, [rsp+0x70]
00007cd93bddd322  vmovaps xmm9, [rsp+0x80]
00007cd93bddd32b  vmovaps xmm10, [rsp+0x90]
00007cd93bddd334  vmovaps xmm11, [rsp+0xA0]
00007cd93bddd33d  vmovaps xmm12, [rsp+0xB0]
00007cd93bddd346  vmovaps xmm13, [rsp+0xC0]
00007cd93bddd34f  vmovaps xmm14, [rsp+0xD0]
00007cd93bddd358  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd361  add rsp, 0xF0
00007cd93bddd368  pop r11
00007cd93bddd36a  pop r10
00007cd93bddd36c  pop r9
00007cd93bddd36e  pop r8
00007cd93bddd370  pop rsi
00007cd93bddd371  pop rdi
00007cd93bddd372  pop rdx
00007cd93bddd373  pop rcx
00007cd93bddd374  pop rax
00007cd93bddd375  add rsp, 0x08
00007cd93bddd379  jmp 0x00007CD93BDDBC94
00007cd93bddd37e  sub rsp, 0x08
00007cd93bddd382  push rax
00007cd93bddd383  push rcx
00007cd93bddd384  push rdx
00007cd93bddd385  push rdi
00007cd93bddd386  push rsi
00007cd93bddd387  push r8
00007cd93bddd389  push r9
00007cd93bddd38b  push r10
00007cd93bddd38d  push r11
00007cd93bddd38f  sub rsp, 0xF0
00007cd93bddd396  vmovaps [rsp], xmm0
00007cd93bddd39b  vmovaps [rsp+0x10], xmm1
00007cd93bddd3a1  vmovaps [rsp+0x20], xmm2
00007cd93bddd3a7  vmovaps [rsp+0x30], xmm3
00007cd93bddd3ad  vmovaps [rsp+0x40], xmm4
00007cd93bddd3b3  vmovaps [rsp+0x50], xmm5
00007cd93bddd3b9  vmovaps [rsp+0x60], xmm6
00007cd93bddd3bf  vmovaps [rsp+0x70], xmm7
00007cd93bddd3c5  vmovaps [rsp+0x80], xmm8
00007cd93bddd3ce  vmovaps [rsp+0x90], xmm10
00007cd93bddd3d7  vmovaps [rsp+0xA0], xmm11
00007cd93bddd3e0  vmovaps [rsp+0xB0], xmm12
00007cd93bddd3e9  vmovaps [rsp+0xC0], xmm13
00007cd93bddd3f2  vmovaps [rsp+0xD0], xmm14
00007cd93bddd3fb  vmovaps [rsp+0xE0], xmm15
00007cd93bddd404  sub rsp, 0x30
00007cd93bddd408  movaps [rsp], xmm9
00007cd93bddd40d  movaps [rsp+0x10], xmm10
00007cd93bddd413  movaps [rsp+0x20], xmm8
00007cd93bddd419  lea rdi, [rsp]
00007cd93bddd41d  mov esi, 0x00
00007cd93bddd422  mov rax, 0x64A581057530
00007cd93bddd42c  call rax
00007cd93bddd42e  movaps xmm9, [rsp]
00007cd93bddd433  add rsp, 0x30
00007cd93bddd437  vmovaps xmm0, [rsp]
00007cd93bddd43c  vmovaps xmm1, [rsp+0x10]
00007cd93bddd442  vmovaps xmm2, [rsp+0x20]
00007cd93bddd448  vmovaps xmm3, [rsp+0x30]
00007cd93bddd44e  vmovaps xmm4, [rsp+0x40]
00007cd93bddd454  vmovaps xmm5, [rsp+0x50]
00007cd93bddd45a  vmovaps xmm6, [rsp+0x60]
00007cd93bddd460  vmovaps xmm7, [rsp+0x70]
00007cd93bddd466  vmovaps xmm8, [rsp+0x80]
00007cd93bddd46f  vmovaps xmm10, [rsp+0x90]
00007cd93bddd478  vmovaps xmm11, [rsp+0xA0]
00007cd93bddd481  vmovaps xmm12, [rsp+0xB0]
00007cd93bddd48a  vmovaps xmm13, [rsp+0xC0]
00007cd93bddd493  vmovaps xmm14, [rsp+0xD0]
00007cd93bddd49c  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd4a5  add rsp, 0xF0
00007cd93bddd4ac  pop r11
00007cd93bddd4ae  pop r10
00007cd93bddd4b0  pop r9
00007cd93bddd4b2  pop r8
00007cd93bddd4b4  pop rsi
00007cd93bddd4b5  pop rdi
00007cd93bddd4b6  pop rdx
00007cd93bddd4b7  pop rcx
00007cd93bddd4b8  pop rax
00007cd93bddd4b9  add rsp, 0x08
00007cd93bddd4bd  jmp 0x00007CD93BDDBCAE
00007cd93bddd4c2  call 0x00007CD93BCB52F0
00007cd93bddd4c7  jmp 0x00007CD93BDDBDC8
00007cd93bddd4cc  call 0x00007CD93BCB52F0
00007cd93bddd4d1  jmp 0x00007CD93BDDBDDE
00007cd93bddd4d6  sub rsp, 0x08
00007cd93bddd4da  push rax
00007cd93bddd4db  push rcx
00007cd93bddd4dc  push rdx
00007cd93bddd4dd  push rdi
00007cd93bddd4de  push rsi
00007cd93bddd4df  push r8
00007cd93bddd4e1  push r9
00007cd93bddd4e3  push r10
00007cd93bddd4e5  push r11
00007cd93bddd4e7  sub rsp, 0xF0
00007cd93bddd4ee  vmovaps [rsp], xmm0
00007cd93bddd4f3  vmovaps [rsp+0x10], xmm2
00007cd93bddd4f9  vmovaps [rsp+0x20], xmm3
00007cd93bddd4ff  vmovaps [rsp+0x30], xmm4
00007cd93bddd505  vmovaps [rsp+0x40], xmm5
00007cd93bddd50b  vmovaps [rsp+0x50], xmm6
00007cd93bddd511  vmovaps [rsp+0x60], xmm7
00007cd93bddd517  vmovaps [rsp+0x70], xmm8
00007cd93bddd51d  vmovaps [rsp+0x80], xmm9
00007cd93bddd526  vmovaps [rsp+0x90], xmm10
00007cd93bddd52f  vmovaps [rsp+0xA0], xmm11
00007cd93bddd538  vmovaps [rsp+0xB0], xmm12
00007cd93bddd541  vmovaps [rsp+0xC0], xmm13
00007cd93bddd54a  vmovaps [rsp+0xD0], xmm14
00007cd93bddd553  vmovaps [rsp+0xE0], xmm15
00007cd93bddd55c  sub rsp, 0x30
00007cd93bddd560  movaps [rsp], xmm1
00007cd93bddd564  movaps [rsp+0x10], xmm6
00007cd93bddd569  movaps [rsp+0x20], xmm15
00007cd93bddd56f  lea rdi, [rsp]
00007cd93bddd573  mov esi, 0x00
00007cd93bddd578  mov rax, 0x64A581057530
00007cd93bddd582  call rax
00007cd93bddd584  movaps xmm1, [rsp]
00007cd93bddd588  add rsp, 0x30
00007cd93bddd58c  vmovaps xmm0, [rsp]
00007cd93bddd591  vmovaps xmm2, [rsp+0x10]
00007cd93bddd597  vmovaps xmm3, [rsp+0x20]
00007cd93bddd59d  vmovaps xmm4, [rsp+0x30]
00007cd93bddd5a3  vmovaps xmm5, [rsp+0x40]
00007cd93bddd5a9  vmovaps xmm6, [rsp+0x50]
00007cd93bddd5af  vmovaps xmm7, [rsp+0x60]
00007cd93bddd5b5  vmovaps xmm8, [rsp+0x70]
00007cd93bddd5bb  vmovaps xmm9, [rsp+0x80]
00007cd93bddd5c4  vmovaps xmm10, [rsp+0x90]
00007cd93bddd5cd  vmovaps xmm11, [rsp+0xA0]
00007cd93bddd5d6  vmovaps xmm12, [rsp+0xB0]
00007cd93bddd5df  vmovaps xmm13, [rsp+0xC0]
00007cd93bddd5e8  vmovaps xmm14, [rsp+0xD0]
00007cd93bddd5f1  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd5fa  add rsp, 0xF0
00007cd93bddd601  pop r11
00007cd93bddd603  pop r10
00007cd93bddd605  pop r9
00007cd93bddd607  pop r8
00007cd93bddd609  pop rsi
00007cd93bddd60a  pop rdi
00007cd93bddd60b  pop rdx
00007cd93bddd60c  pop rcx
00007cd93bddd60d  pop rax
00007cd93bddd60e  add rsp, 0x08
00007cd93bddd612  jmp 0x00007CD93BDDBE1B
00007cd93bddd617  call 0x00007CD93BCC4620
00007cd93bddd61c  jmp 0x00007CD93BDDBE28
00007cd93bddd621  sub rsp, 0x08
00007cd93bddd625  push rax
00007cd93bddd626  push rcx
00007cd93bddd627  push rdx
00007cd93bddd628  push rdi
00007cd93bddd629  push rsi
00007cd93bddd62a  push r8
00007cd93bddd62c  push r9
00007cd93bddd62e  push r10
00007cd93bddd630  push r11
00007cd93bddd632  sub rsp, 0xF0
00007cd93bddd639  vmovaps [rsp], xmm0
00007cd93bddd63e  vmovaps [rsp+0x10], xmm1
00007cd93bddd644  vmovaps [rsp+0x20], xmm2
00007cd93bddd64a  vmovaps [rsp+0x30], xmm3
00007cd93bddd650  vmovaps [rsp+0x40], xmm4
00007cd93bddd656  vmovaps [rsp+0x50], xmm5
00007cd93bddd65c  vmovaps [rsp+0x60], xmm6
00007cd93bddd662  vmovaps [rsp+0x70], xmm7
00007cd93bddd668  vmovaps [rsp+0x80], xmm8
00007cd93bddd671  vmovaps [rsp+0x90], xmm9
00007cd93bddd67a  vmovaps [rsp+0xA0], xmm10
00007cd93bddd683  vmovaps [rsp+0xB0], xmm11
00007cd93bddd68c  vmovaps [rsp+0xC0], xmm12
00007cd93bddd695  vmovaps [rsp+0xD0], xmm13
00007cd93bddd69e  vmovaps [rsp+0xE0], xmm15
00007cd93bddd6a7  sub rsp, 0x30
00007cd93bddd6ab  movaps [rsp], xmm14
00007cd93bddd6b0  movaps [rsp+0x10], xmm4
00007cd93bddd6b5  movaps [rsp+0x20], xmm3
00007cd93bddd6ba  lea rdi, [rsp]
00007cd93bddd6be  mov esi, 0x00
00007cd93bddd6c3  mov rax, 0x64A581057530
00007cd93bddd6cd  call rax
00007cd93bddd6cf  movaps xmm14, [rsp]
00007cd93bddd6d4  add rsp, 0x30
00007cd93bddd6d8  vmovaps xmm0, [rsp]
00007cd93bddd6dd  vmovaps xmm1, [rsp+0x10]
00007cd93bddd6e3  vmovaps xmm2, [rsp+0x20]
00007cd93bddd6e9  vmovaps xmm3, [rsp+0x30]
00007cd93bddd6ef  vmovaps xmm4, [rsp+0x40]
00007cd93bddd6f5  vmovaps xmm5, [rsp+0x50]
00007cd93bddd6fb  vmovaps xmm6, [rsp+0x60]
00007cd93bddd701  vmovaps xmm7, [rsp+0x70]
00007cd93bddd707  vmovaps xmm8, [rsp+0x80]
00007cd93bddd710  vmovaps xmm9, [rsp+0x90]
00007cd93bddd719  vmovaps xmm10, [rsp+0xA0]
00007cd93bddd722  vmovaps xmm11, [rsp+0xB0]
00007cd93bddd72b  vmovaps xmm12, [rsp+0xC0]
00007cd93bddd734  vmovaps xmm13, [rsp+0xD0]
00007cd93bddd73d  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd746  add rsp, 0xF0
00007cd93bddd74d  pop r11
00007cd93bddd74f  pop r10
00007cd93bddd751  pop r9
00007cd93bddd753  pop r8
00007cd93bddd755  pop rsi
00007cd93bddd756  pop rdi
00007cd93bddd757  pop rdx
00007cd93bddd758  pop rcx
00007cd93bddd759  pop rax
00007cd93bddd75a  add rsp, 0x08
00007cd93bddd75e  jmp 0x00007CD93BDDBE42
00007cd93bddd763  sub rsp, 0x08
00007cd93bddd767  push rax
00007cd93bddd768  push rcx
00007cd93bddd769  push rdx
00007cd93bddd76a  push rdi
00007cd93bddd76b  push rsi
00007cd93bddd76c  push r8
00007cd93bddd76e  push r9
00007cd93bddd770  push r10
00007cd93bddd772  push r11
00007cd93bddd774  sub rsp, 0xF0
00007cd93bddd77b  vmovaps [rsp], xmm0
00007cd93bddd780  vmovaps [rsp+0x10], xmm1
00007cd93bddd786  vmovaps [rsp+0x20], xmm2
00007cd93bddd78c  vmovaps [rsp+0x30], xmm3
00007cd93bddd792  vmovaps [rsp+0x40], xmm4
00007cd93bddd798  vmovaps [rsp+0x50], xmm5
00007cd93bddd79e  vmovaps [rsp+0x60], xmm7
00007cd93bddd7a4  vmovaps [rsp+0x70], xmm8
00007cd93bddd7aa  vmovaps [rsp+0x80], xmm9
00007cd93bddd7b3  vmovaps [rsp+0x90], xmm10
00007cd93bddd7bc  vmovaps [rsp+0xA0], xmm11
00007cd93bddd7c5  vmovaps [rsp+0xB0], xmm12
00007cd93bddd7ce  vmovaps [rsp+0xC0], xmm13
00007cd93bddd7d7  vmovaps [rsp+0xD0], xmm14
00007cd93bddd7e0  vmovaps [rsp+0xE0], xmm15
00007cd93bddd7e9  sub rsp, 0x30
00007cd93bddd7ed  movaps [rsp], xmm6
00007cd93bddd7f1  movaps [rsp+0x10], xmm9
00007cd93bddd7f7  movaps [rsp+0x20], xmm7
00007cd93bddd7fc  lea rdi, [rsp]
00007cd93bddd800  mov esi, 0x00
00007cd93bddd805  mov rax, 0x64A581057530
00007cd93bddd80f  call rax
00007cd93bddd811  movaps xmm6, [rsp]
00007cd93bddd815  add rsp, 0x30
00007cd93bddd819  vmovaps xmm0, [rsp]
00007cd93bddd81e  vmovaps xmm1, [rsp+0x10]
00007cd93bddd824  vmovaps xmm2, [rsp+0x20]
00007cd93bddd82a  vmovaps xmm3, [rsp+0x30]
00007cd93bddd830  vmovaps xmm4, [rsp+0x40]
00007cd93bddd836  vmovaps xmm5, [rsp+0x50]
00007cd93bddd83c  vmovaps xmm7, [rsp+0x60]
00007cd93bddd842  vmovaps xmm8, [rsp+0x70]
00007cd93bddd848  vmovaps xmm9, [rsp+0x80]
00007cd93bddd851  vmovaps xmm10, [rsp+0x90]
00007cd93bddd85a  vmovaps xmm11, [rsp+0xA0]
00007cd93bddd863  vmovaps xmm12, [rsp+0xB0]
00007cd93bddd86c  vmovaps xmm13, [rsp+0xC0]
00007cd93bddd875  vmovaps xmm14, [rsp+0xD0]
00007cd93bddd87e  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd887  add rsp, 0xF0
00007cd93bddd88e  pop r11
00007cd93bddd890  pop r10
00007cd93bddd892  pop r9
00007cd93bddd894  pop r8
00007cd93bddd896  pop rsi
00007cd93bddd897  pop rdi
00007cd93bddd898  pop rdx
00007cd93bddd899  pop rcx
00007cd93bddd89a  pop rax
00007cd93bddd89b  add rsp, 0x08
00007cd93bddd89f  jmp 0x00007CD93BDDBE5A
00007cd93bddd8a4  sub rsp, 0x08
00007cd93bddd8a8  push rax
00007cd93bddd8a9  push rcx
00007cd93bddd8aa  push rdx
00007cd93bddd8ab  push rdi
00007cd93bddd8ac  push rsi
00007cd93bddd8ad  push r8
00007cd93bddd8af  push r9
00007cd93bddd8b1  push r10
00007cd93bddd8b3  push r11
00007cd93bddd8b5  sub rsp, 0xF0
00007cd93bddd8bc  vmovaps [rsp], xmm0
00007cd93bddd8c1  vmovaps [rsp+0x10], xmm1
00007cd93bddd8c7  vmovaps [rsp+0x20], xmm2
00007cd93bddd8cd  vmovaps [rsp+0x30], xmm3
00007cd93bddd8d3  vmovaps [rsp+0x40], xmm4
00007cd93bddd8d9  vmovaps [rsp+0x50], xmm5
00007cd93bddd8df  vmovaps [rsp+0x60], xmm6
00007cd93bddd8e5  vmovaps [rsp+0x70], xmm8
00007cd93bddd8eb  vmovaps [rsp+0x80], xmm9
00007cd93bddd8f4  vmovaps [rsp+0x90], xmm10
00007cd93bddd8fd  vmovaps [rsp+0xA0], xmm11
00007cd93bddd906  vmovaps [rsp+0xB0], xmm12
00007cd93bddd90f  vmovaps [rsp+0xC0], xmm13
00007cd93bddd918  vmovaps [rsp+0xD0], xmm14
00007cd93bddd921  vmovaps [rsp+0xE0], xmm15
00007cd93bddd92a  sub rsp, 0x30
00007cd93bddd92e  movaps [rsp], xmm7
00007cd93bddd932  movaps [rsp+0x10], xmm4
00007cd93bddd937  movaps [rsp+0x20], xmm9
00007cd93bddd93d  lea rdi, [rsp]
00007cd93bddd941  mov esi, 0x00
00007cd93bddd946  mov rax, 0x64A581057530
00007cd93bddd950  call rax
00007cd93bddd952  movaps xmm7, [rsp]
00007cd93bddd956  add rsp, 0x30
00007cd93bddd95a  vmovaps xmm0, [rsp]
00007cd93bddd95f  vmovaps xmm1, [rsp+0x10]
00007cd93bddd965  vmovaps xmm2, [rsp+0x20]
00007cd93bddd96b  vmovaps xmm3, [rsp+0x30]
00007cd93bddd971  vmovaps xmm4, [rsp+0x40]
00007cd93bddd977  vmovaps xmm5, [rsp+0x50]
00007cd93bddd97d  vmovaps xmm6, [rsp+0x60]
00007cd93bddd983  vmovaps xmm8, [rsp+0x70]
00007cd93bddd989  vmovaps xmm9, [rsp+0x80]
00007cd93bddd992  vmovaps xmm10, [rsp+0x90]
00007cd93bddd99b  vmovaps xmm11, [rsp+0xA0]
00007cd93bddd9a4  vmovaps xmm12, [rsp+0xB0]
00007cd93bddd9ad  vmovaps xmm13, [rsp+0xC0]
00007cd93bddd9b6  vmovaps xmm14, [rsp+0xD0]
00007cd93bddd9bf  vmovaps xmm15, [rsp+0xE0]
00007cd93bddd9c8  add rsp, 0xF0
00007cd93bddd9cf  pop r11
00007cd93bddd9d1  pop r10
00007cd93bddd9d3  pop r9
00007cd93bddd9d5  pop r8
00007cd93bddd9d7  pop rsi
00007cd93bddd9d8  pop rdi
00007cd93bddd9d9  pop rdx
00007cd93bddd9da  pop rcx
00007cd93bddd9db  pop rax
00007cd93bddd9dc  add rsp, 0x08
00007cd93bddd9e0  jmp 0x00007CD93BDDBE87
00007cd93bddd9e5  sub rsp, 0x08
00007cd93bddd9e9  push rax
00007cd93bddd9ea  push rcx
00007cd93bddd9eb  push rdx
00007cd93bddd9ec  push rdi
00007cd93bddd9ed  push rsi
00007cd93bddd9ee  push r8
00007cd93bddd9f0  push r9
00007cd93bddd9f2  push r10
00007cd93bddd9f4  push r11
00007cd93bddd9f6  sub rsp, 0xF0
00007cd93bddd9fd  vmovaps [rsp], xmm0
00007cd93bddda02  vmovaps [rsp+0x10], xmm1
00007cd93bddda08  vmovaps [rsp+0x20], xmm2
00007cd93bddda0e  vmovaps [rsp+0x30], xmm3
00007cd93bddda14  vmovaps [rsp+0x40], xmm5
00007cd93bddda1a  vmovaps [rsp+0x50], xmm6
00007cd93bddda20  vmovaps [rsp+0x60], xmm7
00007cd93bddda26  vmovaps [rsp+0x70], xmm8
00007cd93bddda2c  vmovaps [rsp+0x80], xmm9
00007cd93bddda35  vmovaps [rsp+0x90], xmm10
00007cd93bddda3e  vmovaps [rsp+0xA0], xmm11
00007cd93bddda47  vmovaps [rsp+0xB0], xmm12
00007cd93bddda50  vmovaps [rsp+0xC0], xmm13
00007cd93bddda59  vmovaps [rsp+0xD0], xmm14
00007cd93bddda62  vmovaps [rsp+0xE0], xmm15
00007cd93bddda6b  sub rsp, 0x30
00007cd93bddda6f  movaps [rsp], xmm4
00007cd93bddda73  movaps [rsp+0x10], xmm15
00007cd93bddda79  movaps [rsp+0x20], xmm9
00007cd93bddda7f  lea rdi, [rsp]
00007cd93bddda83  mov esi, 0x00
00007cd93bddda88  mov rax, 0x64A581057530
00007cd93bddda92  call rax
00007cd93bddda94  movaps xmm4, [rsp]
00007cd93bddda98  add rsp, 0x30
00007cd93bddda9c  vmovaps xmm0, [rsp]
00007cd93bdddaa1  vmovaps xmm1, [rsp+0x10]
00007cd93bdddaa7  vmovaps xmm2, [rsp+0x20]
00007cd93bdddaad  vmovaps xmm3, [rsp+0x30]
00007cd93bdddab3  vmovaps xmm5, [rsp+0x40]
00007cd93bdddab9  vmovaps xmm6, [rsp+0x50]
00007cd93bdddabf  vmovaps xmm7, [rsp+0x60]
00007cd93bdddac5  vmovaps xmm8, [rsp+0x70]
00007cd93bdddacb  vmovaps xmm9, [rsp+0x80]
00007cd93bdddad4  vmovaps xmm10, [rsp+0x90]
00007cd93bdddadd  vmovaps xmm11, [rsp+0xA0]
00007cd93bdddae6  vmovaps xmm12, [rsp+0xB0]
00007cd93bdddaef  vmovaps xmm13, [rsp+0xC0]
00007cd93bdddaf8  vmovaps xmm14, [rsp+0xD0]
00007cd93bdddb01  vmovaps xmm15, [rsp+0xE0]
00007cd93bdddb0a  add rsp, 0xF0
00007cd93bdddb11  pop r11
00007cd93bdddb13  pop r10
00007cd93bdddb15  pop r9
00007cd93bdddb17  pop r8
00007cd93bdddb19  pop rsi
00007cd93bdddb1a  pop rdi
00007cd93bdddb1b  pop rdx
00007cd93bdddb1c  pop rcx
00007cd93bdddb1d  pop rax
00007cd93bdddb1e  add rsp, 0x08
00007cd93bdddb22  jmp 0x00007CD93BDDBEAC
00007cd93bdddb27  call 0x00007CD93BCC4620
00007cd93bdddb2c  jmp 0x00007CD93BDDBEB9
00007cd93bdddb31  sub rsp, 0x08
00007cd93bdddb35  push rax
00007cd93bdddb36  push rcx
00007cd93bdddb37  push rdx
00007cd93bdddb38  push rdi
00007cd93bdddb39  push rsi
00007cd93bdddb3a  push r8
00007cd93bdddb3c  push r9
00007cd93bdddb3e  push r10
00007cd93bdddb40  push r11
00007cd93bdddb42  sub rsp, 0xF0
00007cd93bdddb49  vmovaps [rsp], xmm0
00007cd93bdddb4e  vmovaps [rsp+0x10], xmm1
00007cd93bdddb54  vmovaps [rsp+0x20], xmm2
00007cd93bdddb5a  vmovaps [rsp+0x30], xmm4
00007cd93bdddb60  vmovaps [rsp+0x40], xmm5
00007cd93bdddb66  vmovaps [rsp+0x50], xmm6
00007cd93bdddb6c  vmovaps [rsp+0x60], xmm7
00007cd93bdddb72  vmovaps [rsp+0x70], xmm8
00007cd93bdddb78  vmovaps [rsp+0x80], xmm9
00007cd93bdddb81  vmovaps [rsp+0x90], xmm10
00007cd93bdddb8a  vmovaps [rsp+0xA0], xmm11
00007cd93bdddb93  vmovaps [rsp+0xB0], xmm12
00007cd93bdddb9c  vmovaps [rsp+0xC0], xmm13
00007cd93bdddba5  vmovaps [rsp+0xD0], xmm14
00007cd93bdddbae  vmovaps [rsp+0xE0], xmm15
00007cd93bdddbb7  sub rsp, 0x30
00007cd93bdddbbb  movaps [rsp], xmm3
00007cd93bdddbbf  movaps [rsp+0x10], xmm1
00007cd93bdddbc4  movaps [rsp+0x20], xmm9
00007cd93bdddbca  lea rdi, [rsp]
00007cd93bdddbce  mov esi, 0x00
00007cd93bdddbd3  mov rax, 0x64A581057530
00007cd93bdddbdd  call rax
00007cd93bdddbdf  movaps xmm3, [rsp]
00007cd93bdddbe3  add rsp, 0x30
00007cd93bdddbe7  vmovaps xmm0, [rsp]
00007cd93bdddbec  vmovaps xmm1, [rsp+0x10]
00007cd93bdddbf2  vmovaps xmm2, [rsp+0x20]
00007cd93bdddbf8  vmovaps xmm4, [rsp+0x30]
00007cd93bdddbfe  vmovaps xmm5, [rsp+0x40]
00007cd93bdddc04  vmovaps xmm6, [rsp+0x50]
00007cd93bdddc0a  vmovaps xmm7, [rsp+0x60]
00007cd93bdddc10  vmovaps xmm8, [rsp+0x70]
00007cd93bdddc16  vmovaps xmm9, [rsp+0x80]
00007cd93bdddc1f  vmovaps xmm10, [rsp+0x90]
00007cd93bdddc28  vmovaps xmm11, [rsp+0xA0]
00007cd93bdddc31  vmovaps xmm12, [rsp+0xB0]
00007cd93bdddc3a  vmovaps xmm13, [rsp+0xC0]
00007cd93bdddc43  vmovaps xmm14, [rsp+0xD0]
00007cd93bdddc4c  vmovaps xmm15, [rsp+0xE0]
00007cd93bdddc55  add rsp, 0xF0
00007cd93bdddc5c  pop r11
00007cd93bdddc5e  pop r10
00007cd93bdddc60  pop r9
00007cd93bdddc62  pop r8
00007cd93bdddc64  pop rsi
00007cd93bdddc65  pop rdi
00007cd93bdddc66  pop rdx
00007cd93bdddc67  pop rcx
00007cd93bdddc68  pop rax
00007cd93bdddc69  add rsp, 0x08
00007cd93bdddc6d  jmp 0x00007CD93BDDBEF6
00007cd93bdddc72  sub rsp, 0x08
00007cd93bdddc76  push rax
00007cd93bdddc77  push rcx
00007cd93bdddc78  push rdx
00007cd93bdddc79  push rdi
00007cd93bdddc7a  push rsi
00007cd93bdddc7b  push r8
00007cd93bdddc7d  push r9
00007cd93bdddc7f  push r10
00007cd93bdddc81  push r11
00007cd93bdddc83  sub rsp, 0xF0
00007cd93bdddc8a  vmovaps [rsp], xmm0
00007cd93bdddc8f  vmovaps [rsp+0x10], xmm2
00007cd93bdddc95  vmovaps [rsp+0x20], xmm3
00007cd93bdddc9b  vmovaps [rsp+0x30], xmm4
00007cd93bdddca1  vmovaps [rsp+0x40], xmm5
00007cd93bdddca7  vmovaps [rsp+0x50], xmm6
00007cd93bdddcad  vmovaps [rsp+0x60], xmm7
00007cd93bdddcb3  vmovaps [rsp+0x70], xmm8
00007cd93bdddcb9  vmovaps [rsp+0x80], xmm9
00007cd93bdddcc2  vmovaps [rsp+0x90], xmm10
00007cd93bdddccb  vmovaps [rsp+0xA0], xmm11
00007cd93bdddcd4  vmovaps [rsp+0xB0], xmm12
00007cd93bdddcdd  vmovaps [rsp+0xC0], xmm13
00007cd93bdddce6  vmovaps [rsp+0xD0], xmm14
00007cd93bdddcef  vmovaps [rsp+0xE0], xmm15
00007cd93bdddcf8  sub rsp, 0x30
00007cd93bdddcfc  movaps [rsp], xmm1
00007cd93bdddd00  movaps [rsp+0x10], xmm15
00007cd93bdddd06  movaps [rsp+0x20], xmm9
00007cd93bdddd0c  lea rdi, [rsp]
00007cd93bdddd10  mov esi, 0x00
00007cd93bdddd15  mov rax, 0x64A581057530
00007cd93bdddd1f  call rax
00007cd93bdddd21  movaps xmm1, [rsp]
00007cd93bdddd25  add rsp, 0x30
00007cd93bdddd29  vmovaps xmm0, [rsp]
00007cd93bdddd2e  vmovaps xmm2, [rsp+0x10]
00007cd93bdddd34  vmovaps xmm3, [rsp+0x20]
00007cd93bdddd3a  vmovaps xmm4, [rsp+0x30]
00007cd93bdddd40  vmovaps xmm5, [rsp+0x40]
00007cd93bdddd46  vmovaps xmm6, [rsp+0x50]
00007cd93bdddd4c  vmovaps xmm7, [rsp+0x60]
00007cd93bdddd52  vmovaps xmm8, [rsp+0x70]
00007cd93bdddd58  vmovaps xmm9, [rsp+0x80]
00007cd93bdddd61  vmovaps xmm10, [rsp+0x90]
00007cd93bdddd6a  vmovaps xmm11, [rsp+0xA0]
00007cd93bdddd73  vmovaps xmm12, [rsp+0xB0]
00007cd93bdddd7c  vmovaps xmm13, [rsp+0xC0]
00007cd93bdddd85  vmovaps xmm14, [rsp+0xD0]
00007cd93bdddd8e  vmovaps xmm15, [rsp+0xE0]
00007cd93bdddd97  add rsp, 0xF0
00007cd93bdddd9e  pop r11
00007cd93bdddda0  pop r10
00007cd93bdddda2  pop r9
00007cd93bdddda4  pop r8
00007cd93bdddda6  pop rsi
00007cd93bdddda7  pop rdi
00007cd93bdddda8  pop rdx
00007cd93bdddda9  pop rcx
00007cd93bddddaa  pop rax
00007cd93bddddab  add rsp, 0x08
00007cd93bddddaf  jmp 0x00007CD93BDDBF7E
00007cd93bddddb4  call 0x00007CD93BCC4620
00007cd93bddddb9  jmp 0x00007CD93BDDBF8B
00007cd93bddddbe  sub rsp, 0x08
00007cd93bddddc2  push rax
00007cd93bddddc3  push rcx
00007cd93bddddc4  push rdx
00007cd93bddddc5  push rdi
00007cd93bddddc6  push rsi
00007cd93bddddc7  push r8
00007cd93bddddc9  push r9
00007cd93bddddcb  push r10
00007cd93bddddcd  push r11
00007cd93bddddcf  sub rsp, 0xF0
00007cd93bddddd6  vmovaps [rsp], xmm0
00007cd93bdddddb  vmovaps [rsp+0x10], xmm2
00007cd93bdddde1  vmovaps [rsp+0x20], xmm3
00007cd93bdddde7  vmovaps [rsp+0x30], xmm4
00007cd93bdddded  vmovaps [rsp+0x40], xmm5
00007cd93bddddf3  vmovaps [rsp+0x50], xmm6
00007cd93bddddf9  vmovaps [rsp+0x60], xmm7
00007cd93bddddff  vmovaps [rsp+0x70], xmm8
00007cd93bddde05  vmovaps [rsp+0x80], xmm9
00007cd93bddde0e  vmovaps [rsp+0x90], xmm10
00007cd93bddde17  vmovaps [rsp+0xA0], xmm11
00007cd93bddde20  vmovaps [rsp+0xB0], xmm12
00007cd93bddde29  vmovaps [rsp+0xC0], xmm13
00007cd93bddde32  vmovaps [rsp+0xD0], xmm14
00007cd93bddde3b  vmovaps [rsp+0xE0], xmm15
00007cd93bddde44  sub rsp, 0x30
00007cd93bddde48  movaps [rsp], xmm1
00007cd93bddde4c  movaps [rsp+0x10], xmm5
00007cd93bddde51  movaps [rsp+0x20], xmm7
00007cd93bddde56  lea rdi, [rsp]
00007cd93bddde5a  mov esi, 0x00
00007cd93bddde5f  mov rax, 0x64A581057530
00007cd93bddde69  call rax
00007cd93bddde6b  movaps xmm1, [rsp]
00007cd93bddde6f  add rsp, 0x30
00007cd93bddde73  vmovaps xmm0, [rsp]
00007cd93bddde78  vmovaps xmm2, [rsp+0x10]
00007cd93bddde7e  vmovaps xmm3, [rsp+0x20]
00007cd93bddde84  vmovaps xmm4, [rsp+0x30]
00007cd93bddde8a  vmovaps xmm5, [rsp+0x40]
00007cd93bddde90  vmovaps xmm6, [rsp+0x50]
00007cd93bddde96  vmovaps xmm7, [rsp+0x60]
00007cd93bddde9c  vmovaps xmm8, [rsp+0x70]
00007cd93bdddea2  vmovaps xmm9, [rsp+0x80]
00007cd93bdddeab  vmovaps xmm10, [rsp+0x90]
00007cd93bdddeb4  vmovaps xmm11, [rsp+0xA0]
00007cd93bdddebd  vmovaps xmm12, [rsp+0xB0]
00007cd93bdddec6  vmovaps xmm13, [rsp+0xC0]
00007cd93bdddecf  vmovaps xmm14, [rsp+0xD0]
00007cd93bddded8  vmovaps xmm15, [rsp+0xE0]
00007cd93bdddee1  add rsp, 0xF0
00007cd93bdddee8  pop r11
00007cd93bdddeea  pop r10
00007cd93bdddeec  pop r9
00007cd93bdddeee  pop r8
00007cd93bdddef0  pop rsi
00007cd93bdddef1  pop rdi
00007cd93bdddef2  pop rdx
00007cd93bdddef3  pop rcx
00007cd93bdddef4  pop rax
00007cd93bdddef5  add rsp, 0x08
00007cd93bdddef9  jmp 0x00007CD93BDDC030
00007cd93bdddefe  sub rsp, 0x08
00007cd93bdddf02  push rax
00007cd93bdddf03  push rcx
00007cd93bdddf04  push rdx
00007cd93bdddf05  push rdi
00007cd93bdddf06  push rsi
00007cd93bdddf07  push r8
00007cd93bdddf09  push r9
00007cd93bdddf0b  push r10
00007cd93bdddf0d  push r11
00007cd93bdddf0f  sub rsp, 0xF0
00007cd93bdddf16  vmovaps [rsp], xmm0
00007cd93bdddf1b  vmovaps [rsp+0x10], xmm1
00007cd93bdddf21  vmovaps [rsp+0x20], xmm2
00007cd93bdddf27  vmovaps [rsp+0x30], xmm3
00007cd93bdddf2d  vmovaps [rsp+0x40], xmm4
00007cd93bdddf33  vmovaps [rsp+0x50], xmm5
00007cd93bdddf39  vmovaps [rsp+0x60], xmm6
00007cd93bdddf3f  vmovaps [rsp+0x70], xmm8
00007cd93bdddf45  vmovaps [rsp+0x80], xmm9
00007cd93bdddf4e  vmovaps [rsp+0x90], xmm10
00007cd93bdddf57  vmovaps [rsp+0xA0], xmm11
00007cd93bdddf60  vmovaps [rsp+0xB0], xmm12
00007cd93bdddf69  vmovaps [rsp+0xC0], xmm13
00007cd93bdddf72  vmovaps [rsp+0xD0], xmm14
00007cd93bdddf7b  vmovaps [rsp+0xE0], xmm15
00007cd93bdddf84  sub rsp, 0x30
00007cd93bdddf88  movaps [rsp], xmm7
00007cd93bdddf8c  movaps [rsp+0x10], xmm5
00007cd93bdddf91  movaps [rsp+0x20], xmm15
00007cd93bdddf97  lea rdi, [rsp]
00007cd93bdddf9b  mov esi, 0x00
00007cd93bdddfa0  mov rax, 0x64A581057530
00007cd93bdddfaa  call rax
00007cd93bdddfac  movaps xmm7, [rsp]
00007cd93bdddfb0  add rsp, 0x30
00007cd93bdddfb4  vmovaps xmm0, [rsp]
00007cd93bdddfb9  vmovaps xmm1, [rsp+0x10]
00007cd93bdddfbf  vmovaps xmm2, [rsp+0x20]
00007cd93bdddfc5  vmovaps xmm3, [rsp+0x30]
00007cd93bdddfcb  vmovaps xmm4, [rsp+0x40]
00007cd93bdddfd1  vmovaps xmm5, [rsp+0x50]
00007cd93bdddfd7  vmovaps xmm6, [rsp+0x60]
00007cd93bdddfdd  vmovaps xmm8, [rsp+0x70]
00007cd93bdddfe3  vmovaps xmm9, [rsp+0x80]
00007cd93bdddfec  vmovaps xmm10, [rsp+0x90]
00007cd93bdddff5  vmovaps xmm11, [rsp+0xA0]
00007cd93bdddffe  vmovaps xmm12, [rsp+0xB0]
00007cd93bdde007  vmovaps xmm13, [rsp+0xC0]
00007cd93bdde010  vmovaps xmm14, [rsp+0xD0]
00007cd93bdde019  vmovaps xmm15, [rsp+0xE0]
00007cd93bdde022  add rsp, 0xF0
00007cd93bdde029  pop r11
00007cd93bdde02b  pop r10
00007cd93bdde02d  pop r9
00007cd93bdde02f  pop r8
00007cd93bdde031  pop rsi
00007cd93bdde032  pop rdi
00007cd93bdde033  pop rdx
00007cd93bdde034  pop rcx
00007cd93bdde035  pop rax
00007cd93bdde036  add rsp, 0x08
00007cd93bdde03a  jmp 0x00007CD93BDDC066
00007cd93bdde03f  call 0x00007CD93BCB52F0
00007cd93bdde044  jmp 0x00007CD93BDDC073
00007cd93bdde049  sub rsp, 0x08
00007cd93bdde04d  push rax
00007cd93bdde04e  push rcx
00007cd93bdde04f  push rdx
00007cd93bdde050  push rdi
00007cd93bdde051  push rsi
00007cd93bdde052  push r8
00007cd93bdde054  push r9
00007cd93bdde056  push r10
00007cd93bdde058  push r11
00007cd93bdde05a  sub rsp, 0xF0
00007cd93bdde061  vmovaps [rsp], xmm0
00007cd93bdde066  vmovaps [rsp+0x10], xmm1
00007cd93bdde06c  vmovaps [rsp+0x20], xmm2
00007cd93bdde072  vmovaps [rsp+0x30], xmm3
00007cd93bdde078  vmovaps [rsp+0x40], xmm4
00007cd93bdde07e  vmovaps [rsp+0x50], xmm5
00007cd93bdde084  vmovaps [rsp+0x60], xmm6
00007cd93bdde08a  vmovaps [rsp+0x70], xmm7
00007cd93bdde090  vmovaps [rsp+0x80], xmm8
00007cd93bdde099  vmovaps [rsp+0x90], xmm9
00007cd93bdde0a2  vmovaps [rsp+0xA0], xmm10
00007cd93bdde0ab  vmovaps [rsp+0xB0], xmm11
00007cd93bdde0b4  vmovaps [rsp+0xC0], xmm12
00007cd93bdde0bd  vmovaps [rsp+0xD0], xmm13
00007cd93bdde0c6  vmovaps [rsp+0xE0], xmm14
00007cd93bdde0cf  sub rsp, 0x30
00007cd93bdde0d3  movaps [rsp], xmm15
00007cd93bdde0d8  movaps [rsp+0x10], xmm5
00007cd93bdde0dd  movaps [rsp+0x20], xmm3
00007cd93bdde0e2  lea rdi, [rsp]
00007cd93bdde0e6  mov esi, 0x00
00007cd93bdde0eb  mov rax, 0x64A581057530
00007cd93bdde0f5  call rax
00007cd93bdde0f7  movaps xmm15, [rsp]
00007cd93bdde0fc  add rsp, 0x30
00007cd93bdde100  vmovaps xmm0, [rsp]
00007cd93bdde105  vmovaps xmm1, [rsp+0x10]
00007cd93bdde10b  vmovaps xmm2, [rsp+0x20]
00007cd93bdde111  vmovaps xmm3, [rsp+0x30]
00007cd93bdde117  vmovaps xmm4, [rsp+0x40]
00007cd93bdde11d  vmovaps xmm5, [rsp+0x50]
00007cd93bdde123  vmovaps xmm6, [rsp+0x60]
00007cd93bdde129  vmovaps xmm7, [rsp+0x70]
00007cd93bdde12f  vmovaps xmm8, [rsp+0x80]
00007cd93bdde138  vmovaps xmm9, [rsp+0x90]
00007cd93bdde141  vmovaps xmm10, [rsp+0xA0]
00007cd93bdde14a  vmovaps xmm11, [rsp+0xB0]
00007cd93bdde153  vmovaps xmm12, [rsp+0xC0]
00007cd93bdde15c  vmovaps xmm13, [rsp+0xD0]
00007cd93bdde165  vmovaps xmm14, [rsp+0xE0]
00007cd93bdde16e  add rsp, 0xF0
00007cd93bdde175  pop r11
00007cd93bdde177  pop r10
00007cd93bdde179  pop r9
00007cd93bdde17b  pop r8
00007cd93bdde17d  pop rsi
00007cd93bdde17e  pop rdi
00007cd93bdde17f  pop rdx
00007cd93bdde180  pop rcx
00007cd93bdde181  pop rax
00007cd93bdde182  add rsp, 0x08
00007cd93bdde186  jmp 0x00007CD93BDDC099
00007cd93bdde18b  sub rsp, 0x08
00007cd93bdde18f  push rax
00007cd93bdde190  push rcx
00007cd93bdde191  push rdx
00007cd93bdde192  push rdi
00007cd93bdde193  push rsi
00007cd93bdde194  push r8
00007cd93bdde196  push r9
00007cd93bdde198  push r10
00007cd93bdde19a  push r11
00007cd93bdde19c  sub rsp, 0xF0
00007cd93bdde1a3  vmovaps [rsp], xmm0
00007cd93bdde1a8  vmovaps [rsp+0x10], xmm2
00007cd93bdde1ae  vmovaps [rsp+0x20], xmm3
00007cd93bdde1b4  vmovaps [rsp+0x30], xmm4
00007cd93bdde1ba  vmovaps [rsp+0x40], xmm5
00007cd93bdde1c0  vmovaps [rsp+0x50], xmm6
00007cd93bdde1c6  vmovaps [rsp+0x60], xmm7
00007cd93bdde1cc  vmovaps [rsp+0x70], xmm8
00007cd93bdde1d2  vmovaps [rsp+0x80], xmm9
00007cd93bdde1db  vmovaps [rsp+0x90], xmm10
00007cd93bdde1e4  vmovaps [rsp+0xA0], xmm11
00007cd93bdde1ed  vmovaps [rsp+0xB0], xmm12
00007cd93bdde1f6  vmovaps [rsp+0xC0], xmm13
00007cd93bdde1ff  vmovaps [rsp+0xD0], xmm14
00007cd93bdde208  vmovaps [rsp+0xE0], xmm15
00007cd93bdde211  sub rsp, 0x30
00007cd93bdde215  movaps [rsp], xmm1
00007cd93bdde219  movaps [rsp+0x10], xmm5
00007cd93bdde21e  movaps [rsp+0x20], xmm4
00007cd93bdde223  lea rdi, [rsp]
00007cd93bdde227  mov esi, 0x00
00007cd93bdde22c  mov rax, 0x64A581057530
00007cd93bdde236  call rax
00007cd93bdde238  movaps xmm1, [rsp]
00007cd93bdde23c  add rsp, 0x30
00007cd93bdde240  vmovaps xmm0, [rsp]
00007cd93bdde245  vmovaps xmm2, [rsp+0x10]
00007cd93bdde24b  vmovaps xmm3, [rsp+0x20]
00007cd93bdde251  vmovaps xmm4, [rsp+0x30]
00007cd93bdde257  vmovaps xmm5, [rsp+0x40]
00007cd93bdde25d  vmovaps xmm6, [rsp+0x50]
00007cd93bdde263  vmovaps xmm7, [rsp+0x60]
00007cd93bdde269  vmovaps xmm8, [rsp+0x70]
00007cd93bdde26f  vmovaps xmm9, [rsp+0x80]
00007cd93bdde278  vmovaps xmm10, [rsp+0x90]
00007cd93bdde281  vmovaps xmm11, [rsp+0xA0]
00007cd93bdde28a  vmovaps xmm12, [rsp+0xB0]
00007cd93bdde293  vmovaps xmm13, [rsp+0xC0]
00007cd93bdde29c  vmovaps xmm14, [rsp+0xD0]
00007cd93bdde2a5  vmovaps xmm15, [rsp+0xE0]
00007cd93bdde2ae  add rsp, 0xF0
00007cd93bdde2b5  pop r11
00007cd93bdde2b7  pop r10
00007cd93bdde2b9  pop r9
00007cd93bdde2bb  pop r8
00007cd93bdde2bd  pop rsi
00007cd93bdde2be  pop rdi
00007cd93bdde2bf  pop rdx
00007cd93bdde2c0  pop rcx
00007cd93bdde2c1  pop rax
00007cd93bdde2c2  add rsp, 0x08
00007cd93bdde2c6  jmp 0x00007CD93BDDC0B9
00007cd93bdde2cb  sub rsp, 0x08
00007cd93bdde2cf  push rax
00007cd93bdde2d0  push rcx
00007cd93bdde2d1  push rdx
00007cd93bdde2d2  push rdi
00007cd93bdde2d3  push rsi
00007cd93bdde2d4  push r8
00007cd93bdde2d6  push r9
00007cd93bdde2d8  push r10
00007cd93bdde2da  push r11
00007cd93bdde2dc  sub rsp, 0xF0
00007cd93bdde2e3  vmovaps [rsp], xmm0
00007cd93bdde2e8  vmovaps [rsp+0x10], xmm1
00007cd93bdde2ee  vmovaps [rsp+0x20], xmm2
00007cd93bdde2f4  vmovaps [rsp+0x30], xmm3
00007cd93bdde2fa  vmovaps [rsp+0x40], xmm5
00007cd93bdde300  vmovaps [rsp+0x50], xmm6
00007cd93bdde306  vmovaps [rsp+0x60], xmm7
00007cd93bdde30c  vmovaps [rsp+0x70], xmm8
00007cd93bdde312  vmovaps [rsp+0x80], xmm9
00007cd93bdde31b  vmovaps [rsp+0x90], xmm10
00007cd93bdde324  vmovaps [rsp+0xA0], xmm11
00007cd93bdde32d  vmovaps [rsp+0xB0], xmm12
00007cd93bdde336  vmovaps [rsp+0xC0], xmm13
00007cd93bdde33f  vmovaps [rsp+0xD0], xmm14
00007cd93bdde348  vmovaps [rsp+0xE0], xmm15
00007cd93bdde351  sub rsp, 0x30
00007cd93bdde355  movaps [rsp], xmm4
00007cd93bdde359  movaps [rsp+0x10], xmm3
00007cd93bdde35e  movaps [rsp+0x20], xmm5
00007cd93bdde363  lea rdi, [rsp]
00007cd93bdde367  mov esi, 0x00
00007cd93bdde36c  mov rax, 0x64A581057530
00007cd93bdde376  call rax
00007cd93bdde378  movaps xmm4, [rsp]
00007cd93bdde37c  add rsp, 0x30
00007cd93bdde380  vmovaps xmm0, [rsp]
00007cd93bdde385  vmovaps xmm1, [rsp+0x10]
00007cd93bdde38b  vmovaps xmm2, [rsp+0x20]
00007cd93bdde391  vmovaps xmm3, [rsp+0x30]
00007cd93bdde397  vmovaps xmm5, [rsp+0x40]
00007cd93bdde39d  vmovaps xmm6, [rsp+0x50]
00007cd93bdde3a3  vmovaps xmm7, [rsp+0x60]
00007cd93bdde3a9  vmovaps xmm8, [rsp+0x70]
00007cd93bdde3af  vmovaps xmm9, [rsp+0x80]
00007cd93bdde3b8  vmovaps xmm10, [rsp+0x90]
00007cd93bdde3c1  vmovaps xmm11, [rsp+0xA0]
00007cd93bdde3ca  vmovaps xmm12, [rsp+0xB0]
00007cd93bdde3d3  vmovaps xmm13, [rsp+0xC0]
00007cd93bdde3dc  vmovaps xmm14, [rsp+0xD0]
00007cd93bdde3e5  vmovaps xmm15, [rsp+0xE0]
00007cd93bdde3ee  add rsp, 0xF0
00007cd93bdde3f5  pop r11
00007cd93bdde3f7  pop r10
00007cd93bdde3f9  pop r9
00007cd93bdde3fb  pop r8
00007cd93bdde3fd  pop rsi
00007cd93bdde3fe  pop rdi
00007cd93bdde3ff  pop rdx
00007cd93bdde400  pop rcx
00007cd93bdde401  pop rax
00007cd93bdde402  add rsp, 0x08
00007cd93bdde406  jmp 0x00007CD93BDDC107
00007cd93bdde40b  call 0x00007CD93BCB52F0
00007cd93bdde410  jmp 0x00007CD93BDDC114
00007cd93bdde415  sub rsp, 0x08
00007cd93bdde419  push rax
00007cd93bdde41a  push rcx
00007cd93bdde41b  push rdx
00007cd93bdde41c  push rdi
00007cd93bdde41d  push rsi
00007cd93bdde41e  push r8
00007cd93bdde420  push r9
00007cd93bdde422  push r10
00007cd93bdde424  push r11
00007cd93bdde426  sub rsp, 0xF0
00007cd93bdde42d  vmovaps [rsp], xmm0
00007cd93bdde432  vmovaps [rsp+0x10], xmm1
00007cd93bdde438  vmovaps [rsp+0x20], xmm2
00007cd93bdde43e  vmovaps [rsp+0x30], xmm3
00007cd93bdde444  vmovaps [rsp+0x40], xmm4
00007cd93bdde44a  vmovaps [rsp+0x50], xmm6
00007cd93bdde450  vmovaps [rsp+0x60], xmm7
00007cd93bdde456  vmovaps [rsp+0x70], xmm8
00007cd93bdde45c  vmovaps [rsp+0x80], xmm9
00007cd93bdde465  vmovaps [rsp+0x90], xmm10
00007cd93bdde46e  vmovaps [rsp+0xA0], xmm11
00007cd93bdde477  vmovaps [rsp+0xB0], xmm12
00007cd93bdde480  vmovaps [rsp+0xC0], xmm13
00007cd93bdde489  vmovaps [rsp+0xD0], xmm14
00007cd93bdde492  vmovaps [rsp+0xE0], xmm15
00007cd93bdde49b  sub rsp, 0x30
00007cd93bdde49f  movaps [rsp], xmm5
00007cd93bdde4a3  movaps [rsp+0x10], xmm6
00007cd93bdde4a8  movaps [rsp+0x20], xmm3
00007cd93bdde4ad  lea rdi, [rsp]
00007cd93bdde4b1  mov esi, 0x00
00007cd93bdde4b6  mov rax, 0x64A581057530
00007cd93bdde4c0  call rax
00007cd93bdde4c2  movaps xmm5, [rsp]
00007cd93bdde4c6  add rsp, 0x30
00007cd93bdde4ca  vmovaps xmm0, [rsp]
00007cd93bdde4cf  vmovaps xmm1, [rsp+0x10]
00007cd93bdde4d5  vmovaps xmm2, [rsp+0x20]
00007cd93bdde4db  vmovaps xmm3, [rsp+0x30]
00007cd93bdde4e1  vmovaps xmm4, [rsp+0x40]
00007cd93bdde4e7  vmovaps xmm6, [rsp+0x50]
00007cd93bdde4ed  vmovaps xmm7, [rsp+0x60]
00007cd93bdde4f3  vmovaps xmm8, [rsp+0x70]
00007cd93bdde4f9  vmovaps xmm9, [rsp+0x80]
00007cd93bdde502  vmovaps xmm10, [rsp+0x90]
00007cd93bdde50b  vmovaps xmm11, [rsp+0xA0]
00007cd93bdde514  vmovaps xmm12, [rsp+0xB0]
00007cd93bdde51d  vmovaps xmm13, [rsp+0xC0]
00007cd93bdde526  vmovaps xmm14, [rsp+0xD0]
00007cd93bdde52f  vmovaps xmm15, [rsp+0xE0]
00007cd93bdde538  add rsp, 0xF0
00007cd93bdde53f  pop r11
00007cd93bdde541  pop r10
00007cd93bdde543  pop r9
00007cd93bdde545  pop r8
00007cd93bdde547  pop rsi
00007cd93bdde548  pop rdi
00007cd93bdde549  pop rdx
00007cd93bdde54a  pop rcx
00007cd93bdde54b  pop rax
00007cd93bdde54c  add rsp, 0x08
00007cd93bdde550  jmp 0x00007CD93BDDC13A
00007cd93bdde555  sub rsp, 0x08
00007cd93bdde559  push rax
00007cd93bdde55a  push rcx
00007cd93bdde55b  push rdx
00007cd93bdde55c  push rdi
00007cd93bdde55d  push rsi
00007cd93bdde55e  push r8
00007cd93bdde560  push r9
00007cd93bdde562  push r10
00007cd93bdde564  push r11
00007cd93bdde566  sub rsp, 0xF0
00007cd93bdde56d  vmovaps [rsp], xmm0
00007cd93bdde572  vmovaps [rsp+0x10], xmm1
00007cd93bdde578  vmovaps [rsp+0x20], xmm2
00007cd93bdde57e  vmovaps [rsp+0x30], xmm3
00007cd93bdde584  vmovaps [rsp+0x40], xmm4
00007cd93bdde58a  vmovaps [rsp+0x50], xmm5
00007cd93bdde590  vmovaps [rsp+0x60], xmm7
00007cd93bdde596  vmovaps [rsp+0x70], xmm8
00007cd93bdde59c  vmovaps [rsp+0x80], xmm9
00007cd93bdde5a5  vmovaps [rsp+0x90], xmm10
00007cd93bdde5ae  vmovaps [rsp+0xA0], xmm11
00007cd93bdde5b7  vmovaps [rsp+0xB0], xmm12
00007cd93bdde5c0  vmovaps [rsp+0xC0], xmm13
00007cd93bdde5c9  vmovaps [rsp+0xD0], xmm14
00007cd93bdde5d2  vmovaps [rsp+0xE0], xmm15
00007cd93bdde5db  sub rsp, 0x30
00007cd93bdde5df  movaps [rsp], xmm6
00007cd93bdde5e3  movaps [rsp+0x10], xmm9
00007cd93bdde5e9  movaps [rsp+0x20], xmm1
00007cd93bdde5ee  lea rdi, [rsp]
00007cd93bdde5f2  mov esi, 0x00
00007cd93bdde5f7  mov rax, 0x64A581057530
00007cd93bdde601  call rax
00007cd93bdde603  movaps xmm6, [rsp]
00007cd93bdde607  add rsp, 0x30
00007cd93bdde60b  vmovaps xmm0, [rsp]
00007cd93bdde610  vmovaps xmm1, [rsp+0x10]
00007cd93bdde616  vmovaps xmm2, [rsp+0x20]
00007cd93bdde61c  vmovaps xmm3, [rsp+0x30]
00007cd93bdde622  vmovaps xmm4, [rsp+0x40]
00007cd93bdde628  vmovaps xmm5, [rsp+0x50]
00007cd93bdde62e  vmovaps xmm7, [rsp+0x60]
00007cd93bdde634  vmovaps xmm8, [rsp+0x70]
00007cd93bdde63a  vmovaps xmm9, [rsp+0x80]
00007cd93bdde643  vmovaps xmm10, [rsp+0x90]
00007cd93bdde64c  vmovaps xmm11, [rsp+0xA0]
00007cd93bdde655  vmovaps xmm12, [rsp+0xB0]
00007cd93bdde65e  vmovaps xmm13, [rsp+0xC0]
00007cd93bdde667  vmovaps xmm14, [rsp+0xD0]
00007cd93bdde670  vmovaps xmm15, [rsp+0xE0]
00007cd93bdde679  add rsp, 0xF0
00007cd93bdde680  pop r11
00007cd93bdde682  pop r10
00007cd93bdde684  pop r9
00007cd93bdde686  pop r8
00007cd93bdde688  pop rsi
00007cd93bdde689  pop rdi
00007cd93bdde68a  pop rdx
00007cd93bdde68b  pop rcx
00007cd93bdde68c  pop rax
00007cd93bdde68d  add rsp, 0x08
00007cd93bdde691  jmp 0x00007CD93BDDC15E
00007cd93bdde696  sub rsp, 0x08
00007cd93bdde69a  push rax
00007cd93bdde69b  push rcx
00007cd93bdde69c  push rdx
00007cd93bdde69d  push rdi
00007cd93bdde69e  push rsi
00007cd93bdde69f  push r8
00007cd93bdde6a1  push r9
00007cd93bdde6a3  push r10
00007cd93bdde6a5  push r11
00007cd93bdde6a7  sub rsp, 0xF0
00007cd93bdde6ae  vmovaps [rsp], xmm0
00007cd93bdde6b3  vmovaps [rsp+0x10], xmm1
00007cd93bdde6b9  vmovaps [rsp+0x20], xmm2
00007cd93bdde6bf  vmovaps [rsp+0x30], xmm3
00007cd93bdde6c5  vmovaps [rsp+0x40], xmm4
00007cd93bdde6cb  vmovaps [rsp+0x50], xmm5
00007cd93bdde6d1  vmovaps [rsp+0x60], xmm6
00007cd93bdde6d7  vmovaps [rsp+0x70], xmm7
00007cd93bdde6dd  vmovaps [rsp+0x80], xmm8
00007cd93bdde6e6  vmovaps [rsp+0x90], xmm10
00007cd93bdde6ef  vmovaps [rsp+0xA0], xmm11
00007cd93bdde6f8  vmovaps [rsp+0xB0], xmm12
00007cd93bdde701  vmovaps [rsp+0xC0], xmm13
00007cd93bdde70a  vmovaps [rsp+0xD0], xmm14
00007cd93bdde713  vmovaps [rsp+0xE0], xmm15
00007cd93bdde71c  sub rsp, 0x30
00007cd93bdde720  movaps [rsp], xmm9
00007cd93bdde725  movaps [rsp+0x10], xmm3
00007cd93bdde72a  movaps [rsp+0x20], xmm1
00007cd93bdde72f  lea rdi, [rsp]
00007cd93bdde733  mov esi, 0x00
00007cd93bdde738  mov rax, 0x64A581057530
00007cd93bdde742  call rax
00007cd93bdde744  movaps xmm9, [rsp]
00007cd93bdde749  add rsp, 0x30
00007cd93bdde74d  vmovaps xmm0, [rsp]
00007cd93bdde752  vmovaps xmm1, [rsp+0x10]
00007cd93bdde758  vmovaps xmm2, [rsp+0x20]
00007cd93bdde75e  vmovaps xmm3, [rsp+0x30]
00007cd93bdde764  vmovaps xmm4, [rsp+0x40]
00007cd93bdde76a  vmovaps xmm5, [rsp+0x50]
00007cd93bdde770  vmovaps xmm6, [rsp+0x60]
00007cd93bdde776  vmovaps xmm7, [rsp+0x70]
00007cd93bdde77c  vmovaps xmm8, [rsp+0x80]
00007cd93bdde785  vmovaps xmm10, [rsp+0x90]
00007cd93bdde78e  vmovaps xmm11, [rsp+0xA0]
00007cd93bdde797  vmovaps xmm12, [rsp+0xB0]
00007cd93bdde7a0  vmovaps xmm13, [rsp+0xC0]
00007cd93bdde7a9  vmovaps xmm14, [rsp+0xD0]
00007cd93bdde7b2  vmovaps xmm15, [rsp+0xE0]
00007cd93bdde7bb  add rsp, 0xF0
00007cd93bdde7c2  pop r11
00007cd93bdde7c4  pop r10
00007cd93bdde7c6  pop r9
00007cd93bdde7c8  pop r8
00007cd93bdde7ca  pop rsi
00007cd93bdde7cb  pop rdi
00007cd93bdde7cc  pop rdx
00007cd93bdde7cd  pop rcx
00007cd93bdde7ce  pop rax
00007cd93bdde7cf  add rsp, 0x08
00007cd93bdde7d3  jmp 0x00007CD93BDDC1AA
00007cd93bdde7d8  call 0x00007CD93BCB52F0
00007cd93bdde7dd  jmp 0x00007CD93BDDC1B7
00007cd93bdde7e2  sub rsp, 0x08
00007cd93bdde7e6  push rax
00007cd93bdde7e7  push rcx
00007cd93bdde7e8  push rdx
00007cd93bdde7e9  push rdi
00007cd93bdde7ea  push rsi
00007cd93bdde7eb  push r8
00007cd93bdde7ed  push r9
00007cd93bdde7ef  push r10
00007cd93bdde7f1  push r11
00007cd93bdde7f3  sub rsp, 0xF0
00007cd93bdde7fa  vmovaps [rsp], xmm0
00007cd93bdde7ff  vmovaps [rsp+0x10], xmm1
00007cd93bdde805  vmovaps [rsp+0x20], xmm2
00007cd93bdde80b  vmovaps [rsp+0x30], xmm3
00007cd93bdde811  vmovaps [rsp+0x40], xmm4
00007cd93bdde817  vmovaps [rsp+0x50], xmm5
00007cd93bdde81d  vmovaps [rsp+0x60], xmm6
00007cd93bdde823  vmovaps [rsp+0x70], xmm7
00007cd93bdde829  vmovaps [rsp+0x80], xmm8
00007cd93bdde832  vmovaps [rsp+0x90], xmm9
00007cd93bdde83b  vmovaps [rsp+0xA0], xmm10
00007cd93bdde844  vmovaps [rsp+0xB0], xmm11
00007cd93bdde84d  vmovaps [rsp+0xC0], xmm12
00007cd93bdde856  vmovaps [rsp+0xD0], xmm13
00007cd93bdde85f  vmovaps [rsp+0xE0], xmm14
00007cd93bdde868  sub rsp, 0x30
00007cd93bdde86c  movaps [rsp], xmm15
00007cd93bdde871  movaps [rsp+0x10], xmm3
00007cd93bdde876  movaps [rsp+0x20], xmm7
00007cd93bdde87b  lea rdi, [rsp]
00007cd93bdde87f  mov esi, 0x00
00007cd93bdde884  mov rax, 0x64A581057530
00007cd93bdde88e  call rax
00007cd93bdde890  movaps xmm15, [rsp]
00007cd93bdde895  add rsp, 0x30
00007cd93bdde899  vmovaps xmm0, [rsp]
00007cd93bdde89e  vmovaps xmm1, [rsp+0x10]
00007cd93bdde8a4  vmovaps xmm2, [rsp+0x20]
00007cd93bdde8aa  vmovaps xmm3, [rsp+0x30]
00007cd93bdde8b0  vmovaps xmm4, [rsp+0x40]
00007cd93bdde8b6  vmovaps xmm5, [rsp+0x50]
00007cd93bdde8bc  vmovaps xmm6, [rsp+0x60]
00007cd93bdde8c2  vmovaps xmm7, [rsp+0x70]
00007cd93bdde8c8  vmovaps xmm8, [rsp+0x80]
00007cd93bdde8d1  vmovaps xmm9, [rsp+0x90]
00007cd93bdde8da  vmovaps xmm10, [rsp+0xA0]
00007cd93bdde8e3  vmovaps xmm11, [rsp+0xB0]
00007cd93bdde8ec  vmovaps xmm12, [rsp+0xC0]
00007cd93bdde8f5  vmovaps xmm13, [rsp+0xD0]
00007cd93bdde8fe  vmovaps xmm14, [rsp+0xE0]
00007cd93bdde907  add rsp, 0xF0
00007cd93bdde90e  pop r11
00007cd93bdde910  pop r10
00007cd93bdde912  pop r9
00007cd93bdde914  pop r8
00007cd93bdde916  pop rsi
00007cd93bdde917  pop rdi
00007cd93bdde918  pop rdx
00007cd93bdde919  pop rcx
00007cd93bdde91a  pop rax
00007cd93bdde91b  add rsp, 0x08
00007cd93bdde91f  jmp 0x00007CD93BDDC1E3
00007cd93bdde924  sub rsp, 0x08
00007cd93bdde928  push rax
00007cd93bdde929  push rcx
00007cd93bdde92a  push rdx
00007cd93bdde92b  push rdi
00007cd93bdde92c  push rsi
00007cd93bdde92d  push r8
00007cd93bdde92f  push r9
00007cd93bdde931  push r10
00007cd93bdde933  push r11
00007cd93bdde935  sub rsp, 0xF0
00007cd93bdde93c  vmovaps [rsp], xmm0
00007cd93bdde941  vmovaps [rsp+0x10], xmm1
00007cd93bdde947  vmovaps [rsp+0x20], xmm2
00007cd93bdde94d  vmovaps [rsp+0x30], xmm4
00007cd93bdde953  vmovaps [rsp+0x40], xmm5
00007cd93bdde959  vmovaps [rsp+0x50], xmm6
00007cd93bdde95f  vmovaps [rsp+0x60], xmm7
00007cd93bdde965  vmovaps [rsp+0x70], xmm8
00007cd93bdde96b  vmovaps [rsp+0x80], xmm9
00007cd93bdde974  vmovaps [rsp+0x90], xmm10
00007cd93bdde97d  vmovaps [rsp+0xA0], xmm11
00007cd93bdde986  vmovaps [rsp+0xB0], xmm12
00007cd93bdde98f  vmovaps [rsp+0xC0], xmm13
00007cd93bdde998  vmovaps [rsp+0xD0], xmm14
00007cd93bdde9a1  vmovaps [rsp+0xE0], xmm15
00007cd93bdde9aa  sub rsp, 0x30
00007cd93bdde9ae  movaps [rsp], xmm3
00007cd93bdde9b2  movaps [rsp+0x10], xmm1
00007cd93bdde9b7  movaps [rsp+0x20], xmm15
00007cd93bdde9bd  lea rdi, [rsp]
00007cd93bdde9c1  mov esi, 0x00
00007cd93bdde9c6  mov rax, 0x64A581057530
00007cd93bdde9d0  call rax
00007cd93bdde9d2  movaps xmm3, [rsp]
00007cd93bdde9d6  add rsp, 0x30
00007cd93bdde9da  vmovaps xmm0, [rsp]
00007cd93bdde9df  vmovaps xmm1, [rsp+0x10]
00007cd93bdde9e5  vmovaps xmm2, [rsp+0x20]
00007cd93bdde9eb  vmovaps xmm4, [rsp+0x30]
00007cd93bdde9f1  vmovaps xmm5, [rsp+0x40]
00007cd93bdde9f7  vmovaps xmm6, [rsp+0x50]
00007cd93bdde9fd  vmovaps xmm7, [rsp+0x60]
00007cd93bddea03  vmovaps xmm8, [rsp+0x70]
00007cd93bddea09  vmovaps xmm9, [rsp+0x80]
00007cd93bddea12  vmovaps xmm10, [rsp+0x90]
00007cd93bddea1b  vmovaps xmm11, [rsp+0xA0]
00007cd93bddea24  vmovaps xmm12, [rsp+0xB0]
00007cd93bddea2d  vmovaps xmm13, [rsp+0xC0]
00007cd93bddea36  vmovaps xmm14, [rsp+0xD0]
00007cd93bddea3f  vmovaps xmm15, [rsp+0xE0]
00007cd93bddea48  add rsp, 0xF0
00007cd93bddea4f  pop r11
00007cd93bddea51  pop r10
00007cd93bddea53  pop r9
00007cd93bddea55  pop r8
00007cd93bddea57  pop rsi
00007cd93bddea58  pop rdi
00007cd93bddea59  pop rdx
00007cd93bddea5a  pop rcx
00007cd93bddea5b  pop rax
00007cd93bddea5c  add rsp, 0x08
00007cd93bddea60  jmp 0x00007CD93BDDC272
00007cd93bddea65  call 0x00007CD93BCB52F0
00007cd93bddea6a  jmp 0x00007CD93BDDC27C
00007cd93bddea6f  sub rsp, 0x08
00007cd93bddea73  push rax
00007cd93bddea74  push rcx
00007cd93bddea75  push rdx
00007cd93bddea76  push rdi
00007cd93bddea77  push rsi
00007cd93bddea78  push r8
00007cd93bddea7a  push r9
00007cd93bddea7c  push r10
00007cd93bddea7e  push r11
00007cd93bddea80  sub rsp, 0xF0
00007cd93bddea87  vmovaps [rsp], xmm0
00007cd93bddea8c  vmovaps [rsp+0x10], xmm1
00007cd93bddea92  vmovaps [rsp+0x20], xmm2
00007cd93bddea98  vmovaps [rsp+0x30], xmm3
00007cd93bddea9e  vmovaps [rsp+0x40], xmm4
00007cd93bddeaa4  vmovaps [rsp+0x50], xmm5
00007cd93bddeaaa  vmovaps [rsp+0x60], xmm6
00007cd93bddeab0  vmovaps [rsp+0x70], xmm7
00007cd93bddeab6  vmovaps [rsp+0x80], xmm8
00007cd93bddeabf  vmovaps [rsp+0x90], xmm9
00007cd93bddeac8  vmovaps [rsp+0xA0], xmm10
00007cd93bddead1  vmovaps [rsp+0xB0], xmm11
00007cd93bddeada  vmovaps [rsp+0xC0], xmm12
00007cd93bddeae3  vmovaps [rsp+0xD0], xmm13
00007cd93bddeaec  vmovaps [rsp+0xE0], xmm14
00007cd93bddeaf5  sub rsp, 0x30
00007cd93bddeaf9  movaps [rsp], xmm15
00007cd93bddeafe  movaps [rsp+0x10], xmm14
00007cd93bddeb04  movaps [rsp+0x20], xmm4
00007cd93bddeb09  lea rdi, [rsp]
00007cd93bddeb0d  mov esi, 0x00
00007cd93bddeb12  mov rax, 0x64A581057530
00007cd93bddeb1c  call rax
00007cd93bddeb1e  movaps xmm15, [rsp]
00007cd93bddeb23  add rsp, 0x30
00007cd93bddeb27  vmovaps xmm0, [rsp]
00007cd93bddeb2c  vmovaps xmm1, [rsp+0x10]
00007cd93bddeb32  vmovaps xmm2, [rsp+0x20]
00007cd93bddeb38  vmovaps xmm3, [rsp+0x30]
00007cd93bddeb3e  vmovaps xmm4, [rsp+0x40]
00007cd93bddeb44  vmovaps xmm5, [rsp+0x50]
00007cd93bddeb4a  vmovaps xmm6, [rsp+0x60]
00007cd93bddeb50  vmovaps xmm7, [rsp+0x70]
00007cd93bddeb56  vmovaps xmm8, [rsp+0x80]
00007cd93bddeb5f  vmovaps xmm9, [rsp+0x90]
00007cd93bddeb68  vmovaps xmm10, [rsp+0xA0]
00007cd93bddeb71  vmovaps xmm11, [rsp+0xB0]
00007cd93bddeb7a  vmovaps xmm12, [rsp+0xC0]
00007cd93bddeb83  vmovaps xmm13, [rsp+0xD0]
00007cd93bddeb8c  vmovaps xmm14, [rsp+0xE0]
00007cd93bddeb95  add rsp, 0xF0
00007cd93bddeb9c  pop r11
00007cd93bddeb9e  pop r10
00007cd93bddeba0  pop r9
00007cd93bddeba2  pop r8
00007cd93bddeba4  pop rsi
00007cd93bddeba5  pop rdi
00007cd93bddeba6  pop rdx
00007cd93bddeba7  pop rcx
00007cd93bddeba8  pop rax
00007cd93bddeba9  add rsp, 0x08
00007cd93bddebad  jmp 0x00007CD93BDDC2AA
00007cd93bddebb2  sub rsp, 0x08
00007cd93bddebb6  push rax
00007cd93bddebb7  push rcx
00007cd93bddebb8  push rdx
00007cd93bddebb9  push rdi
00007cd93bddebba  push rsi
00007cd93bddebbb  push r8
00007cd93bddebbd  push r9
00007cd93bddebbf  push r10
00007cd93bddebc1  push r11
00007cd93bddebc3  sub rsp, 0xF0
00007cd93bddebca  vmovaps [rsp], xmm0
00007cd93bddebcf  vmovaps [rsp+0x10], xmm1
00007cd93bddebd5  vmovaps [rsp+0x20], xmm2
00007cd93bddebdb  vmovaps [rsp+0x30], xmm3
00007cd93bddebe1  vmovaps [rsp+0x40], xmm4
00007cd93bddebe7  vmovaps [rsp+0x50], xmm5
00007cd93bddebed  vmovaps [rsp+0x60], xmm6
00007cd93bddebf3  vmovaps [rsp+0x70], xmm7
00007cd93bddebf9  vmovaps [rsp+0x80], xmm8
00007cd93bddec02  vmovaps [rsp+0x90], xmm9
00007cd93bddec0b  vmovaps [rsp+0xA0], xmm10
00007cd93bddec14  vmovaps [rsp+0xB0], xmm11
00007cd93bddec1d  vmovaps [rsp+0xC0], xmm12
00007cd93bddec26  vmovaps [rsp+0xD0], xmm13
00007cd93bddec2f  vmovaps [rsp+0xE0], xmm15
00007cd93bddec38  sub rsp, 0x30
00007cd93bddec3c  movaps [rsp], xmm14
00007cd93bddec41  movaps [rsp+0x10], xmm2
00007cd93bddec46  movaps [rsp+0x20], xmm1
00007cd93bddec4b  lea rdi, [rsp]
00007cd93bddec4f  mov esi, 0x00
00007cd93bddec54  mov rax, 0x64A581057530
00007cd93bddec5e  call rax
00007cd93bddec60  movaps xmm14, [rsp]
00007cd93bddec65  add rsp, 0x30
00007cd93bddec69  vmovaps xmm0, [rsp]
00007cd93bddec6e  vmovaps xmm1, [rsp+0x10]
00007cd93bddec74  vmovaps xmm2, [rsp+0x20]
00007cd93bddec7a  vmovaps xmm3, [rsp+0x30]
00007cd93bddec80  vmovaps xmm4, [rsp+0x40]
00007cd93bddec86  vmovaps xmm5, [rsp+0x50]
00007cd93bddec8c  vmovaps xmm6, [rsp+0x60]
00007cd93bddec92  vmovaps xmm7, [rsp+0x70]
00007cd93bddec98  vmovaps xmm8, [rsp+0x80]
00007cd93bddeca1  vmovaps xmm9, [rsp+0x90]
00007cd93bddecaa  vmovaps xmm10, [rsp+0xA0]
00007cd93bddecb3  vmovaps xmm11, [rsp+0xB0]
00007cd93bddecbc  vmovaps xmm12, [rsp+0xC0]
00007cd93bddecc5  vmovaps xmm13, [rsp+0xD0]
00007cd93bddecce  vmovaps xmm15, [rsp+0xE0]
00007cd93bddecd7  add rsp, 0xF0
00007cd93bddecde  pop r11
00007cd93bddece0  pop r10
00007cd93bddece2  pop r9
00007cd93bddece4  pop r8
00007cd93bddece6  pop rsi
00007cd93bddece7  pop rdi
00007cd93bddece8  pop rdx
00007cd93bddece9  pop rcx
00007cd93bddecea  pop rax
00007cd93bddeceb  add rsp, 0x08
00007cd93bddecef  jmp 0x00007CD93BDDC2D0
00007cd93bddecf4  sub rsp, 0x08
00007cd93bddecf8  push rax
00007cd93bddecf9  push rcx
00007cd93bddecfa  push rdx
00007cd93bddecfb  push rdi
00007cd93bddecfc  push rsi
00007cd93bddecfd  push r8
00007cd93bddecff  push r9
00007cd93bdded01  push r10
00007cd93bdded03  push r11
00007cd93bdded05  sub rsp, 0xF0
00007cd93bdded0c  vmovaps [rsp], xmm0
00007cd93bdded11  vmovaps [rsp+0x10], xmm2
00007cd93bdded17  vmovaps [rsp+0x20], xmm3
00007cd93bdded1d  vmovaps [rsp+0x30], xmm4
00007cd93bdded23  vmovaps [rsp+0x40], xmm5
00007cd93bdded29  vmovaps [rsp+0x50], xmm6
00007cd93bdded2f  vmovaps [rsp+0x60], xmm7
00007cd93bdded35  vmovaps [rsp+0x70], xmm8
00007cd93bdded3b  vmovaps [rsp+0x80], xmm9
00007cd93bdded44  vmovaps [rsp+0x90], xmm10
00007cd93bdded4d  vmovaps [rsp+0xA0], xmm11
00007cd93bdded56  vmovaps [rsp+0xB0], xmm12
00007cd93bdded5f  vmovaps [rsp+0xC0], xmm13
00007cd93bdded68  vmovaps [rsp+0xD0], xmm14
00007cd93bdded71  vmovaps [rsp+0xE0], xmm15
00007cd93bdded7a  sub rsp, 0x30
00007cd93bdded7e  movaps [rsp], xmm1
00007cd93bdded82  movaps [rsp+0x10], xmm4
00007cd93bdded87  movaps [rsp+0x20], xmm9
00007cd93bdded8d  lea rdi, [rsp]
00007cd93bdded91  mov esi, 0x00
00007cd93bdded96  mov rax, 0x64A581057530
00007cd93bddeda0  call rax
00007cd93bddeda2  movaps xmm1, [rsp]
00007cd93bddeda6  add rsp, 0x30
00007cd93bddedaa  vmovaps xmm0, [rsp]
00007cd93bddedaf  vmovaps xmm2, [rsp+0x10]
00007cd93bddedb5  vmovaps xmm3, [rsp+0x20]
00007cd93bddedbb  vmovaps xmm4, [rsp+0x30]
00007cd93bddedc1  vmovaps xmm5, [rsp+0x40]
00007cd93bddedc7  vmovaps xmm6, [rsp+0x50]
00007cd93bddedcd  vmovaps xmm7, [rsp+0x60]
00007cd93bddedd3  vmovaps xmm8, [rsp+0x70]
00007cd93bddedd9  vmovaps xmm9, [rsp+0x80]
00007cd93bddede2  vmovaps xmm10, [rsp+0x90]
00007cd93bddedeb  vmovaps xmm11, [rsp+0xA0]
00007cd93bddedf4  vmovaps xmm12, [rsp+0xB0]
00007cd93bddedfd  vmovaps xmm13, [rsp+0xC0]
00007cd93bddee06  vmovaps xmm14, [rsp+0xD0]
00007cd93bddee0f  vmovaps xmm15, [rsp+0xE0]
00007cd93bddee18  add rsp, 0xF0
00007cd93bddee1f  pop r11
00007cd93bddee21  pop r10
00007cd93bddee23  pop r9
00007cd93bddee25  pop r8
00007cd93bddee27  pop rsi
00007cd93bddee28  pop rdi
00007cd93bddee29  pop rdx
00007cd93bddee2a  pop rcx
00007cd93bddee2b  pop rax
00007cd93bddee2c  add rsp, 0x08
00007cd93bddee30  jmp 0x00007CD93BDDC2EE
00007cd93bddee35  sub rsp, 0x08
00007cd93bddee39  push rax
00007cd93bddee3a  push rcx
00007cd93bddee3b  push rdx
00007cd93bddee3c  push rdi
00007cd93bddee3d  push rsi
00007cd93bddee3e  push r8
00007cd93bddee40  push r9
00007cd93bddee42  push r10
00007cd93bddee44  push r11
00007cd93bddee46  sub rsp, 0xF0
00007cd93bddee4d  vmovaps [rsp], xmm0
00007cd93bddee52  vmovaps [rsp+0x10], xmm1
00007cd93bddee58  vmovaps [rsp+0x20], xmm2
00007cd93bddee5e  vmovaps [rsp+0x30], xmm3
00007cd93bddee64  vmovaps [rsp+0x40], xmm5
00007cd93bddee6a  vmovaps [rsp+0x50], xmm6
00007cd93bddee70  vmovaps [rsp+0x60], xmm7
00007cd93bddee76  vmovaps [rsp+0x70], xmm8
00007cd93bddee7c  vmovaps [rsp+0x80], xmm9
00007cd93bddee85  vmovaps [rsp+0x90], xmm10
00007cd93bddee8e  vmovaps [rsp+0xA0], xmm11
00007cd93bddee97  vmovaps [rsp+0xB0], xmm12
00007cd93bddeea0  vmovaps [rsp+0xC0], xmm13
00007cd93bddeea9  vmovaps [rsp+0xD0], xmm14
00007cd93bddeeb2  vmovaps [rsp+0xE0], xmm15
00007cd93bddeebb  sub rsp, 0x30
00007cd93bddeebf  movaps [rsp], xmm4
00007cd93bddeec3  movaps [rsp+0x10], xmm2
00007cd93bddeec8  movaps [rsp+0x20], xmm9
00007cd93bddeece  lea rdi, [rsp]
00007cd93bddeed2  mov esi, 0x00
00007cd93bddeed7  mov rax, 0x64A581057530
00007cd93bddeee1  call rax
00007cd93bddeee3  movaps xmm4, [rsp]
00007cd93bddeee7  add rsp, 0x30
00007cd93bddeeeb  vmovaps xmm0, [rsp]
00007cd93bddeef0  vmovaps xmm1, [rsp+0x10]
00007cd93bddeef6  vmovaps xmm2, [rsp+0x20]
00007cd93bddeefc  vmovaps xmm3, [rsp+0x30]
00007cd93bddef02  vmovaps xmm5, [rsp+0x40]
00007cd93bddef08  vmovaps xmm6, [rsp+0x50]
00007cd93bddef0e  vmovaps xmm7, [rsp+0x60]
00007cd93bddef14  vmovaps xmm8, [rsp+0x70]
00007cd93bddef1a  vmovaps xmm9, [rsp+0x80]
00007cd93bddef23  vmovaps xmm10, [rsp+0x90]
00007cd93bddef2c  vmovaps xmm11, [rsp+0xA0]
00007cd93bddef35  vmovaps xmm12, [rsp+0xB0]
00007cd93bddef3e  vmovaps xmm13, [rsp+0xC0]
00007cd93bddef47  vmovaps xmm14, [rsp+0xD0]
00007cd93bddef50  vmovaps xmm15, [rsp+0xE0]
00007cd93bddef59  add rsp, 0xF0
00007cd93bddef60  pop r11
00007cd93bddef62  pop r10
00007cd93bddef64  pop r9
00007cd93bddef66  pop r8
00007cd93bddef68  pop rsi
00007cd93bddef69  pop rdi
00007cd93bddef6a  pop rdx
00007cd93bddef6b  pop rcx
00007cd93bddef6c  pop rax
00007cd93bddef6d  add rsp, 0x08
00007cd93bddef71  jmp 0x00007CD93BDDC31E
00007cd93bddef76  sub rsp, 0x08
00007cd93bddef7a  push rax
00007cd93bddef7b  push rcx
00007cd93bddef7c  push rdx
00007cd93bddef7d  push rdi
00007cd93bddef7e  push rsi
00007cd93bddef7f  push r8
00007cd93bddef81  push r9
00007cd93bddef83  push r10
00007cd93bddef85  push r11
00007cd93bddef87  sub rsp, 0xF0
00007cd93bddef8e  vmovaps [rsp], xmm0
00007cd93bddef93  vmovaps [rsp+0x10], xmm1
00007cd93bddef99  vmovaps [rsp+0x20], xmm2
00007cd93bddef9f  vmovaps [rsp+0x30], xmm3
00007cd93bddefa5  vmovaps [rsp+0x40], xmm4
00007cd93bddefab  vmovaps [rsp+0x50], xmm5
00007cd93bddefb1  vmovaps [rsp+0x60], xmm6
00007cd93bddefb7  vmovaps [rsp+0x70], xmm7
00007cd93bddefbd  vmovaps [rsp+0x80], xmm8
00007cd93bddefc6  vmovaps [rsp+0x90], xmm10
00007cd93bddefcf  vmovaps [rsp+0xA0], xmm11
00007cd93bddefd8  vmovaps [rsp+0xB0], xmm12
00007cd93bddefe1  vmovaps [rsp+0xC0], xmm13
00007cd93bddefea  vmovaps [rsp+0xD0], xmm14
00007cd93bddeff3  vmovaps [rsp+0xE0], xmm15
00007cd93bddeffc  sub rsp, 0x30
00007cd93bddf000  movaps [rsp], xmm9
00007cd93bddf005  movaps [rsp+0x10], xmm2
00007cd93bddf00a  movaps [rsp+0x20], xmm1
00007cd93bddf00f  lea rdi, [rsp]
00007cd93bddf013  mov esi, 0x00
00007cd93bddf018  mov rax, 0x64A581057530
00007cd93bddf022  call rax
00007cd93bddf024  movaps xmm9, [rsp]
00007cd93bddf029  add rsp, 0x30
00007cd93bddf02d  vmovaps xmm0, [rsp]
00007cd93bddf032  vmovaps xmm1, [rsp+0x10]
00007cd93bddf038  vmovaps xmm2, [rsp+0x20]
00007cd93bddf03e  vmovaps xmm3, [rsp+0x30]
00007cd93bddf044  vmovaps xmm4, [rsp+0x40]
00007cd93bddf04a  vmovaps xmm5, [rsp+0x50]
00007cd93bddf050  vmovaps xmm6, [rsp+0x60]
00007cd93bddf056  vmovaps xmm7, [rsp+0x70]
00007cd93bddf05c  vmovaps xmm8, [rsp+0x80]
00007cd93bddf065  vmovaps xmm10, [rsp+0x90]
00007cd93bddf06e  vmovaps xmm11, [rsp+0xA0]
00007cd93bddf077  vmovaps xmm12, [rsp+0xB0]
00007cd93bddf080  vmovaps xmm13, [rsp+0xC0]
00007cd93bddf089  vmovaps xmm14, [rsp+0xD0]
00007cd93bddf092  vmovaps xmm15, [rsp+0xE0]
00007cd93bddf09b  add rsp, 0xF0
00007cd93bddf0a2  pop r11
00007cd93bddf0a4  pop r10
00007cd93bddf0a6  pop r9
00007cd93bddf0a8  pop r8
00007cd93bddf0aa  pop rsi
00007cd93bddf0ab  pop rdi
00007cd93bddf0ac  pop rdx
00007cd93bddf0ad  pop rcx
00007cd93bddf0ae  pop rax
00007cd93bddf0af  add rsp, 0x08
00007cd93bddf0b3  jmp 0x00007CD93BDDC354
00007cd93bddf0b8  sub rsp, 0x08
00007cd93bddf0bc  push rax
00007cd93bddf0bd  push rcx
00007cd93bddf0be  push rdx
00007cd93bddf0bf  push rdi
00007cd93bddf0c0  push rsi
00007cd93bddf0c1  push r8
00007cd93bddf0c3  push r9
00007cd93bddf0c5  push r10
00007cd93bddf0c7  push r11
00007cd93bddf0c9  sub rsp, 0xF0
00007cd93bddf0d0  vmovaps [rsp], xmm0
00007cd93bddf0d5  vmovaps [rsp+0x10], xmm2
00007cd93bddf0db  vmovaps [rsp+0x20], xmm3
00007cd93bddf0e1  vmovaps [rsp+0x30], xmm4
00007cd93bddf0e7  vmovaps [rsp+0x40], xmm5
00007cd93bddf0ed  vmovaps [rsp+0x50], xmm6
00007cd93bddf0f3  vmovaps [rsp+0x60], xmm7
00007cd93bddf0f9  vmovaps [rsp+0x70], xmm8
00007cd93bddf0ff  vmovaps [rsp+0x80], xmm9
00007cd93bddf108  vmovaps [rsp+0x90], xmm10
00007cd93bddf111  vmovaps [rsp+0xA0], xmm11
00007cd93bddf11a  vmovaps [rsp+0xB0], xmm12
00007cd93bddf123  vmovaps [rsp+0xC0], xmm13
00007cd93bddf12c  vmovaps [rsp+0xD0], xmm14
00007cd93bddf135  vmovaps [rsp+0xE0], xmm15
00007cd93bddf13e  sub rsp, 0x30
00007cd93bddf142  movaps [rsp], xmm1
00007cd93bddf146  movaps [rsp+0x10], xmm15
00007cd93bddf14c  movaps [rsp+0x20], xmm6
00007cd93bddf151  lea rdi, [rsp]
00007cd93bddf155  mov esi, 0x00
00007cd93bddf15a  mov rax, 0x64A581057530
00007cd93bddf164  call rax
00007cd93bddf166  movaps xmm1, [rsp]
00007cd93bddf16a  add rsp, 0x30
00007cd93bddf16e  vmovaps xmm0, [rsp]
00007cd93bddf173  vmovaps xmm2, [rsp+0x10]
00007cd93bddf179  vmovaps xmm3, [rsp+0x20]
00007cd93bddf17f  vmovaps xmm4, [rsp+0x30]
00007cd93bddf185  vmovaps xmm5, [rsp+0x40]
00007cd93bddf18b  vmovaps xmm6, [rsp+0x50]
00007cd93bddf191  vmovaps xmm7, [rsp+0x60]
00007cd93bddf197  vmovaps xmm8, [rsp+0x70]
00007cd93bddf19d  vmovaps xmm9, [rsp+0x80]
00007cd93bddf1a6  vmovaps xmm10, [rsp+0x90]
00007cd93bddf1af  vmovaps xmm11, [rsp+0xA0]
00007cd93bddf1b8  vmovaps xmm12, [rsp+0xB0]
00007cd93bddf1c1  vmovaps xmm13, [rsp+0xC0]
00007cd93bddf1ca  vmovaps xmm14, [rsp+0xD0]
00007cd93bddf1d3  vmovaps xmm15, [rsp+0xE0]
00007cd93bddf1dc  add rsp, 0xF0
00007cd93bddf1e3  pop r11
00007cd93bddf1e5  pop r10
00007cd93bddf1e7  pop r9
00007cd93bddf1e9  pop r8
00007cd93bddf1eb  pop rsi
00007cd93bddf1ec  pop rdi
00007cd93bddf1ed  pop rdx
00007cd93bddf1ee  pop rcx
00007cd93bddf1ef  pop rax
00007cd93bddf1f0  add rsp, 0x08
00007cd93bddf1f4  jmp 0x00007CD93BDDC375
00007cd93bddf1f9  sub rsp, 0x08
00007cd93bddf1fd  push rax
00007cd93bddf1fe  push rcx
00007cd93bddf1ff  push rdx
00007cd93bddf200  push rdi
00007cd93bddf201  push rsi
00007cd93bddf202  push r8
00007cd93bddf204  push r9
00007cd93bddf206  push r10
00007cd93bddf208  push r11
00007cd93bddf20a  sub rsp, 0xF0
00007cd93bddf211  vmovaps [rsp], xmm0
00007cd93bddf216  vmovaps [rsp+0x10], xmm1
00007cd93bddf21c  vmovaps [rsp+0x20], xmm2
00007cd93bddf222  vmovaps [rsp+0x30], xmm3
00007cd93bddf228  vmovaps [rsp+0x40], xmm4
00007cd93bddf22e  vmovaps [rsp+0x50], xmm5
00007cd93bddf234  vmovaps [rsp+0x60], xmm6
00007cd93bddf23a  vmovaps [rsp+0x70], xmm7
00007cd93bddf240  vmovaps [rsp+0x80], xmm8
00007cd93bddf249  vmovaps [rsp+0x90], xmm9
00007cd93bddf252  vmovaps [rsp+0xA0], xmm10
00007cd93bddf25b  vmovaps [rsp+0xB0], xmm11
00007cd93bddf264  vmovaps [rsp+0xC0], xmm12
00007cd93bddf26d  vmovaps [rsp+0xD0], xmm13
00007cd93bddf276  vmovaps [rsp+0xE0], xmm14
00007cd93bddf27f  sub rsp, 0x30
00007cd93bddf283  movaps [rsp], xmm15
00007cd93bddf288  movaps [rsp+0x10], xmm5
00007cd93bddf28d  movaps [rsp+0x20], xmm3
00007cd93bddf292  lea rdi, [rsp]
00007cd93bddf296  mov esi, 0x00
00007cd93bddf29b  mov rax, 0x64A581057530
00007cd93bddf2a5  call rax
00007cd93bddf2a7  movaps xmm15, [rsp]
00007cd93bddf2ac  add rsp, 0x30
00007cd93bddf2b0  vmovaps xmm0, [rsp]
00007cd93bddf2b5  vmovaps xmm1, [rsp+0x10]
00007cd93bddf2bb  vmovaps xmm2, [rsp+0x20]
00007cd93bddf2c1  vmovaps xmm3, [rsp+0x30]
00007cd93bddf2c7  vmovaps xmm4, [rsp+0x40]
00007cd93bddf2cd  vmovaps xmm5, [rsp+0x50]
00007cd93bddf2d3  vmovaps xmm6, [rsp+0x60]
00007cd93bddf2d9  vmovaps xmm7, [rsp+0x70]
00007cd93bddf2df  vmovaps xmm8, [rsp+0x80]
00007cd93bddf2e8  vmovaps xmm9, [rsp+0x90]
00007cd93bddf2f1  vmovaps xmm10, [rsp+0xA0]
00007cd93bddf2fa  vmovaps xmm11, [rsp+0xB0]
00007cd93bddf303  vmovaps xmm12, [rsp+0xC0]
00007cd93bddf30c  vmovaps xmm13, [rsp+0xD0]
00007cd93bddf315  vmovaps xmm14, [rsp+0xE0]
00007cd93bddf31e  add rsp, 0xF0
00007cd93bddf325  pop r11
00007cd93bddf327  pop r10
00007cd93bddf329  pop r9
00007cd93bddf32b  pop r8
00007cd93bddf32d  pop rsi
00007cd93bddf32e  pop rdi
00007cd93bddf32f  pop rdx
00007cd93bddf330  pop rcx
00007cd93bddf331  pop rax
00007cd93bddf332  add rsp, 0x08
00007cd93bddf336  jmp 0x00007CD93BDDC38F
00007cd93bddf33b  sub rsp, 0x08
00007cd93bddf33f  push rax
00007cd93bddf340  push rcx
00007cd93bddf341  push rdx
00007cd93bddf342  push rdi
00007cd93bddf343  push rsi
00007cd93bddf344  push r8
00007cd93bddf346  push r9
00007cd93bddf348  push r10
00007cd93bddf34a  push r11
00007cd93bddf34c  sub rsp, 0xF0
00007cd93bddf353  vmovaps [rsp], xmm0
00007cd93bddf358  vmovaps [rsp+0x10], xmm1
00007cd93bddf35e  vmovaps [rsp+0x20], xmm2
00007cd93bddf364  vmovaps [rsp+0x30], xmm3
00007cd93bddf36a  vmovaps [rsp+0x40], xmm4
00007cd93bddf370  vmovaps [rsp+0x50], xmm6
00007cd93bddf376  vmovaps [rsp+0x60], xmm7
00007cd93bddf37c  vmovaps [rsp+0x70], xmm8
00007cd93bddf382  vmovaps [rsp+0x80], xmm9
00007cd93bddf38b  vmovaps [rsp+0x90], xmm10
00007cd93bddf394  vmovaps [rsp+0xA0], xmm11
00007cd93bddf39d  vmovaps [rsp+0xB0], xmm12
00007cd93bddf3a6  vmovaps [rsp+0xC0], xmm13
00007cd93bddf3af  vmovaps [rsp+0xD0], xmm14
00007cd93bddf3b8  vmovaps [rsp+0xE0], xmm15
00007cd93bddf3c1  sub rsp, 0x30
00007cd93bddf3c5  movaps [rsp], xmm5
00007cd93bddf3c9  movaps [rsp+0x10], xmm8
00007cd93bddf3cf  movaps [rsp+0x20], xmm6
00007cd93bddf3d4  lea rdi, [rsp]
00007cd93bddf3d8  mov esi, 0x00
00007cd93bddf3dd  mov rax, 0x64A581057530
00007cd93bddf3e7  call rax
00007cd93bddf3e9  movaps xmm5, [rsp]
00007cd93bddf3ed  add rsp, 0x30
00007cd93bddf3f1  vmovaps xmm0, [rsp]
00007cd93bddf3f6  vmovaps xmm1, [rsp+0x10]
00007cd93bddf3fc  vmovaps xmm2, [rsp+0x20]
00007cd93bddf402  vmovaps xmm3, [rsp+0x30]
00007cd93bddf408  vmovaps xmm4, [rsp+0x40]
00007cd93bddf40e  vmovaps xmm6, [rsp+0x50]
00007cd93bddf414  vmovaps xmm7, [rsp+0x60]
00007cd93bddf41a  vmovaps xmm8, [rsp+0x70]
00007cd93bddf420  vmovaps xmm9, [rsp+0x80]
00007cd93bddf429  vmovaps xmm10, [rsp+0x90]
00007cd93bddf432  vmovaps xmm11, [rsp+0xA0]
00007cd93bddf43b  vmovaps xmm12, [rsp+0xB0]
00007cd93bddf444  vmovaps xmm13, [rsp+0xC0]
00007cd93bddf44d  vmovaps xmm14, [rsp+0xD0]
00007cd93bddf456  vmovaps xmm15, [rsp+0xE0]
00007cd93bddf45f  add rsp, 0xF0
00007cd93bddf466  pop r11
00007cd93bddf468  pop r10
00007cd93bddf46a  pop r9
00007cd93bddf46c  pop r8
00007cd93bddf46e  pop rsi
00007cd93bddf46f  pop rdi
00007cd93bddf470  pop rdx
00007cd93bddf471  pop rcx
00007cd93bddf472  pop rax
00007cd93bddf473  add rsp, 0x08
00007cd93bddf477  jmp 0x00007CD93BDDC3B3
00007cd93bddf47c  sub rsp, 0x08
00007cd93bddf480  push rax
00007cd93bddf481  push rcx
00007cd93bddf482  push rdx
00007cd93bddf483  push rdi
00007cd93bddf484  push rsi
00007cd93bddf485  push r8
00007cd93bddf487  push r9
00007cd93bddf489  push r10
00007cd93bddf48b  push r11
00007cd93bddf48d  sub rsp, 0xF0
00007cd93bddf494  vmovaps [rsp], xmm0
00007cd93bddf499  vmovaps [rsp+0x10], xmm1
00007cd93bddf49f  vmovaps [rsp+0x20], xmm2
00007cd93bddf4a5  vmovaps [rsp+0x30], xmm3
00007cd93bddf4ab  vmovaps [rsp+0x40], xmm4
00007cd93bddf4b1  vmovaps [rsp+0x50], xmm5
00007cd93bddf4b7  vmovaps [rsp+0x60], xmm7
00007cd93bddf4bd  vmovaps [rsp+0x70], xmm8
00007cd93bddf4c3  vmovaps [rsp+0x80], xmm9
00007cd93bddf4cc  vmovaps [rsp+0x90], xmm10
00007cd93bddf4d5  vmovaps [rsp+0xA0], xmm11
00007cd93bddf4de  vmovaps [rsp+0xB0], xmm12
00007cd93bddf4e7  vmovaps [rsp+0xC0], xmm13
00007cd93bddf4f0  vmovaps [rsp+0xD0], xmm14
00007cd93bddf4f9  vmovaps [rsp+0xE0], xmm15
00007cd93bddf502  sub rsp, 0x30
00007cd93bddf506  movaps [rsp], xmm6
00007cd93bddf50a  movaps [rsp+0x10], xmm10
00007cd93bddf510  movaps [rsp+0x20], xmm8
00007cd93bddf516  lea rdi, [rsp]
00007cd93bddf51a  mov esi, 0x00
00007cd93bddf51f  mov rax, 0x64A581057530
00007cd93bddf529  call rax
00007cd93bddf52b  movaps xmm6, [rsp]
00007cd93bddf52f  add rsp, 0x30
00007cd93bddf533  vmovaps xmm0, [rsp]
00007cd93bddf538  vmovaps xmm1, [rsp+0x10]
00007cd93bddf53e  vmovaps xmm2, [rsp+0x20]
00007cd93bddf544  vmovaps xmm3, [rsp+0x30]
00007cd93bddf54a  vmovaps xmm4, [rsp+0x40]
00007cd93bddf550  vmovaps xmm5, [rsp+0x50]
00007cd93bddf556  vmovaps xmm7, [rsp+0x60]
00007cd93bddf55c  vmovaps xmm8, [rsp+0x70]
00007cd93bddf562  vmovaps xmm9, [rsp+0x80]
00007cd93bddf56b  vmovaps xmm10, [rsp+0x90]
00007cd93bddf574  vmovaps xmm11, [rsp+0xA0]
00007cd93bddf57d  vmovaps xmm12, [rsp+0xB0]
00007cd93bddf586  vmovaps xmm13, [rsp+0xC0]
00007cd93bddf58f  vmovaps xmm14, [rsp+0xD0]
00007cd93bddf598  vmovaps xmm15, [rsp+0xE0]
00007cd93bddf5a1  add rsp, 0xF0
00007cd93bddf5a8  pop r11
00007cd93bddf5aa  pop r10
00007cd93bddf5ac  pop r9
00007cd93bddf5ae  pop r8
00007cd93bddf5b0  pop rsi
00007cd93bddf5b1  pop rdi
00007cd93bddf5b2  pop rdx
00007cd93bddf5b3  pop rcx
00007cd93bddf5b4  pop rax
00007cd93bddf5b5  add rsp, 0x08
00007cd93bddf5b9  jmp 0x00007CD93BDDC3D8
00007cd93bddf5be  sub rsp, 0x08
00007cd93bddf5c2  push rax
00007cd93bddf5c3  push rcx
00007cd93bddf5c4  push rdx
00007cd93bddf5c5  push rdi
00007cd93bddf5c6  push rsi
00007cd93bddf5c7  push r8
00007cd93bddf5c9  push r9
00007cd93bddf5cb  push r10
00007cd93bddf5cd  push r11
00007cd93bddf5cf  sub rsp, 0xF0
00007cd93bddf5d6  vmovaps [rsp], xmm0
00007cd93bddf5db  vmovaps [rsp+0x10], xmm1
00007cd93bddf5e1  vmovaps [rsp+0x20], xmm2
00007cd93bddf5e7  vmovaps [rsp+0x30], xmm3
00007cd93bddf5ed  vmovaps [rsp+0x40], xmm4
00007cd93bddf5f3  vmovaps [rsp+0x50], xmm5
00007cd93bddf5f9  vmovaps [rsp+0x60], xmm6
00007cd93bddf5ff  vmovaps [rsp+0x70], xmm7
00007cd93bddf605  vmovaps [rsp+0x80], xmm8
00007cd93bddf60e  vmovaps [rsp+0x90], xmm9
00007cd93bddf617  vmovaps [rsp+0xA0], xmm11
00007cd93bddf620  vmovaps [rsp+0xB0], xmm12
00007cd93bddf629  vmovaps [rsp+0xC0], xmm13
00007cd93bddf632  vmovaps [rsp+0xD0], xmm14
00007cd93bddf63b  vmovaps [rsp+0xE0], xmm15
00007cd93bddf644  sub rsp, 0x30
00007cd93bddf648  movaps [rsp], xmm10
00007cd93bddf64d  movaps [rsp+0x10], xmm8
00007cd93bddf653  movaps [rsp+0x20], xmm14
00007cd93bddf659  lea rdi, [rsp]
00007cd93bddf65d  mov esi, 0x00
00007cd93bddf662  mov rax, 0x64A581057530
00007cd93bddf66c  call rax
00007cd93bddf66e  movaps xmm10, [rsp]
00007cd93bddf673  add rsp, 0x30
00007cd93bddf677  vmovaps xmm0, [rsp]
00007cd93bddf67c  vmovaps xmm1, [rsp+0x10]
00007cd93bddf682  vmovaps xmm2, [rsp+0x20]
00007cd93bddf688  vmovaps xmm3, [rsp+0x30]
00007cd93bddf68e  vmovaps xmm4, [rsp+0x40]
00007cd93bddf694  vmovaps xmm5, [rsp+0x50]
00007cd93bddf69a  vmovaps xmm6, [rsp+0x60]
00007cd93bddf6a0  vmovaps xmm7, [rsp+0x70]
00007cd93bddf6a6  vmovaps xmm8, [rsp+0x80]
00007cd93bddf6af  vmovaps xmm9, [rsp+0x90]
00007cd93bddf6b8  vmovaps xmm11, [rsp+0xA0]
00007cd93bddf6c1  vmovaps xmm12, [rsp+0xB0]
00007cd93bddf6ca  vmovaps xmm13, [rsp+0xC0]
00007cd93bddf6d3  vmovaps xmm14, [rsp+0xD0]
00007cd93bddf6dc  vmovaps xmm15, [rsp+0xE0]
00007cd93bddf6e5  add rsp, 0xF0
00007cd93bddf6ec  pop r11
00007cd93bddf6ee  pop r10
00007cd93bddf6f0  pop r9
00007cd93bddf6f2  pop r8
00007cd93bddf6f4  pop rsi
00007cd93bddf6f5  pop rdi
00007cd93bddf6f6  pop rdx
00007cd93bddf6f7  pop rcx
00007cd93bddf6f8  pop rax
00007cd93bddf6f9  add rsp, 0x08
00007cd93bddf6fd  jmp 0x00007CD93BDDC3F8
00007cd93bddf702  sub rsp, 0x08
00007cd93bddf706  push rax
00007cd93bddf707  push rcx
00007cd93bddf708  push rdx
00007cd93bddf709  push rdi
00007cd93bddf70a  push rsi
00007cd93bddf70b  push r8
00007cd93bddf70d  push r9
00007cd93bddf70f  push r10
00007cd93bddf711  push r11
00007cd93bddf713  sub rsp, 0xF0
00007cd93bddf71a  vmovaps [rsp], xmm0
00007cd93bddf71f  vmovaps [rsp+0x10], xmm1
00007cd93bddf725  vmovaps [rsp+0x20], xmm2
00007cd93bddf72b  vmovaps [rsp+0x30], xmm3
00007cd93bddf731  vmovaps [rsp+0x40], xmm4
00007cd93bddf737  vmovaps [rsp+0x50], xmm5
00007cd93bddf73d  vmovaps [rsp+0x60], xmm6
00007cd93bddf743  vmovaps [rsp+0x70], xmm7
00007cd93bddf749  vmovaps [rsp+0x80], xmm8
00007cd93bddf752  vmovaps [rsp+0x90], xmm9
00007cd93bddf75b  vmovaps [rsp+0xA0], xmm10
00007cd93bddf764  vmovaps [rsp+0xB0], xmm11
00007cd93bddf76d  vmovaps [rsp+0xC0], xmm12
00007cd93bddf776  vmovaps [rsp+0xD0], xmm13
00007cd93bddf77f  vmovaps [rsp+0xE0], xmm15
00007cd93bddf788  sub rsp, 0x30
00007cd93bddf78c  movaps [rsp], xmm14
00007cd93bddf791  movaps [rsp+0x10], xmm8
00007cd93bddf797  movaps [rsp+0x20], xmm4
00007cd93bddf79c  lea rdi, [rsp]
00007cd93bddf7a0  mov esi, 0x00
00007cd93bddf7a5  mov rax, 0x64A581057530
00007cd93bddf7af  call rax
00007cd93bddf7b1  movaps xmm14, [rsp]
00007cd93bddf7b6  add rsp, 0x30
00007cd93bddf7ba  vmovaps xmm0, [rsp]
00007cd93bddf7bf  vmovaps xmm1, [rsp+0x10]
00007cd93bddf7c5  vmovaps xmm2, [rsp+0x20]
00007cd93bddf7cb  vmovaps xmm3, [rsp+0x30]
00007cd93bddf7d1  vmovaps xmm4, [rsp+0x40]
00007cd93bddf7d7  vmovaps xmm5, [rsp+0x50]
00007cd93bddf7dd  vmovaps xmm6, [rsp+0x60]
00007cd93bddf7e3  vmovaps xmm7, [rsp+0x70]
00007cd93bddf7e9  vmovaps xmm8, [rsp+0x80]
00007cd93bddf7f2  vmovaps xmm9, [rsp+0x90]
00007cd93bddf7fb  vmovaps xmm10, [rsp+0xA0]
00007cd93bddf804  vmovaps xmm11, [rsp+0xB0]
00007cd93bddf80d  vmovaps xmm12, [rsp+0xC0]
00007cd93bddf816  vmovaps xmm13, [rsp+0xD0]
00007cd93bddf81f  vmovaps xmm15, [rsp+0xE0]
00007cd93bddf828  add rsp, 0xF0
00007cd93bddf82f  pop r11
00007cd93bddf831  pop r10
00007cd93bddf833  pop r9
00007cd93bddf835  pop r8
00007cd93bddf837  pop rsi
00007cd93bddf838  pop rdi
00007cd93bddf839  pop rdx
00007cd93bddf83a  pop rcx
00007cd93bddf83b  pop rax
00007cd93bddf83c  add rsp, 0x08
00007cd93bddf840  jmp 0x00007CD93BDDC418
00007cd93bddf845  sub rsp, 0x08
00007cd93bddf849  push rax
00007cd93bddf84a  push rcx
00007cd93bddf84b  push rdx
00007cd93bddf84c  push rdi
00007cd93bddf84d  push rsi
00007cd93bddf84e  push r8
00007cd93bddf850  push r9
00007cd93bddf852  push r10
00007cd93bddf854  push r11
00007cd93bddf856  sub rsp, 0xF0
00007cd93bddf85d  vmovaps [rsp], xmm0
00007cd93bddf862  vmovaps [rsp+0x10], xmm1
00007cd93bddf868  vmovaps [rsp+0x20], xmm2
00007cd93bddf86e  vmovaps [rsp+0x30], xmm3
00007cd93bddf874  vmovaps [rsp+0x40], xmm5
00007cd93bddf87a  vmovaps [rsp+0x50], xmm6
00007cd93bddf880  vmovaps [rsp+0x60], xmm7
00007cd93bddf886  vmovaps [rsp+0x70], xmm8
00007cd93bddf88c  vmovaps [rsp+0x80], xmm9
00007cd93bddf895  vmovaps [rsp+0x90], xmm10
00007cd93bddf89e  vmovaps [rsp+0xA0], xmm11
00007cd93bddf8a7  vmovaps [rsp+0xB0], xmm12
00007cd93bddf8b0  vmovaps [rsp+0xC0], xmm13
00007cd93bddf8b9  vmovaps [rsp+0xD0], xmm14
00007cd93bddf8c2  vmovaps [rsp+0xE0], xmm15
00007cd93bddf8cb  sub rsp, 0x30
00007cd93bddf8cf  movaps [rsp], xmm4
00007cd93bddf8d3  movaps [rsp+0x10], xmm13
00007cd93bddf8d9  movaps [rsp+0x20], xmm8
00007cd93bddf8df  lea rdi, [rsp]
00007cd93bddf8e3  mov esi, 0x00
00007cd93bddf8e8  mov rax, 0x64A581057530
00007cd93bddf8f2  call rax
00007cd93bddf8f4  movaps xmm4, [rsp]
00007cd93bddf8f8  add rsp, 0x30
00007cd93bddf8fc  vmovaps xmm0, [rsp]
00007cd93bddf901  vmovaps xmm1, [rsp+0x10]
00007cd93bddf907  vmovaps xmm2, [rsp+0x20]
00007cd93bddf90d  vmovaps xmm3, [rsp+0x30]
00007cd93bddf913  vmovaps xmm5, [rsp+0x40]
00007cd93bddf919  vmovaps xmm6, [rsp+0x50]
00007cd93bddf91f  vmovaps xmm7, [rsp+0x60]
00007cd93bddf925  vmovaps xmm8, [rsp+0x70]
00007cd93bddf92b  vmovaps xmm9, [rsp+0x80]
00007cd93bddf934  vmovaps xmm10, [rsp+0x90]
00007cd93bddf93d  vmovaps xmm11, [rsp+0xA0]
00007cd93bddf946  vmovaps xmm12, [rsp+0xB0]
00007cd93bddf94f  vmovaps xmm13, [rsp+0xC0]
00007cd93bddf958  vmovaps xmm14, [rsp+0xD0]
00007cd93bddf961  vmovaps xmm15, [rsp+0xE0]
00007cd93bddf96a  add rsp, 0xF0
00007cd93bddf971  pop r11
00007cd93bddf973  pop r10
00007cd93bddf975  pop r9
00007cd93bddf977  pop r8
00007cd93bddf979  pop rsi
00007cd93bddf97a  pop rdi
00007cd93bddf97b  pop rdx
00007cd93bddf97c  pop rcx
00007cd93bddf97d  pop rax
00007cd93bddf97e  add rsp, 0x08
00007cd93bddf982  jmp 0x00007CD93BDDC43D
00007cd93bddf987  sub rsp, 0x08
00007cd93bddf98b  push rax
00007cd93bddf98c  push rcx
00007cd93bddf98d  push rdx
00007cd93bddf98e  push rdi
00007cd93bddf98f  push rsi
00007cd93bddf990  push r8
00007cd93bddf992  push r9
00007cd93bddf994  push r10
00007cd93bddf996  push r11
00007cd93bddf998  sub rsp, 0xF0
00007cd93bddf99f  vmovaps [rsp], xmm0
00007cd93bddf9a4  vmovaps [rsp+0x10], xmm1
00007cd93bddf9aa  vmovaps [rsp+0x20], xmm2
00007cd93bddf9b0  vmovaps [rsp+0x30], xmm3
00007cd93bddf9b6  vmovaps [rsp+0x40], xmm4
00007cd93bddf9bc  vmovaps [rsp+0x50], xmm5
00007cd93bddf9c2  vmovaps [rsp+0x60], xmm6
00007cd93bddf9c8  vmovaps [rsp+0x70], xmm7
00007cd93bddf9ce  vmovaps [rsp+0x80], xmm8
00007cd93bddf9d7  vmovaps [rsp+0x90], xmm9
00007cd93bddf9e0  vmovaps [rsp+0xA0], xmm10
00007cd93bddf9e9  vmovaps [rsp+0xB0], xmm11
00007cd93bddf9f2  vmovaps [rsp+0xC0], xmm12
00007cd93bddf9fb  vmovaps [rsp+0xD0], xmm14
00007cd93bddfa04  vmovaps [rsp+0xE0], xmm15
00007cd93bddfa0d  sub rsp, 0x30
00007cd93bddfa11  movaps [rsp], xmm13
00007cd93bddfa16  movaps [rsp+0x10], xmm15
00007cd93bddfa1c  movaps [rsp+0x20], xmm9
00007cd93bddfa22  lea rdi, [rsp]
00007cd93bddfa26  mov esi, 0x00
00007cd93bddfa2b  mov rax, 0x64A581057530
00007cd93bddfa35  call rax
00007cd93bddfa37  movaps xmm13, [rsp]
00007cd93bddfa3c  add rsp, 0x30
00007cd93bddfa40  vmovaps xmm0, [rsp]
00007cd93bddfa45  vmovaps xmm1, [rsp+0x10]
00007cd93bddfa4b  vmovaps xmm2, [rsp+0x20]
00007cd93bddfa51  vmovaps xmm3, [rsp+0x30]
00007cd93bddfa57  vmovaps xmm4, [rsp+0x40]
00007cd93bddfa5d  vmovaps xmm5, [rsp+0x50]
00007cd93bddfa63  vmovaps xmm6, [rsp+0x60]
00007cd93bddfa69  vmovaps xmm7, [rsp+0x70]
00007cd93bddfa6f  vmovaps xmm8, [rsp+0x80]
00007cd93bddfa78  vmovaps xmm9, [rsp+0x90]
00007cd93bddfa81  vmovaps xmm10, [rsp+0xA0]
00007cd93bddfa8a  vmovaps xmm11, [rsp+0xB0]
00007cd93bddfa93  vmovaps xmm12, [rsp+0xC0]
00007cd93bddfa9c  vmovaps xmm14, [rsp+0xD0]
00007cd93bddfaa5  vmovaps xmm15, [rsp+0xE0]
00007cd93bddfaae  add rsp, 0xF0
00007cd93bddfab5  pop r11
00007cd93bddfab7  pop r10
00007cd93bddfab9  pop r9
00007cd93bddfabb  pop r8
00007cd93bddfabd  pop rsi
00007cd93bddfabe  pop rdi
00007cd93bddfabf  pop rdx
00007cd93bddfac0  pop rcx
00007cd93bddfac1  pop rax
00007cd93bddfac2  add rsp, 0x08
00007cd93bddfac6  jmp 0x00007CD93BDDC458
00007cd93bddfacb  sub rsp, 0x08
00007cd93bddfacf  push rax
00007cd93bddfad0  push rcx
00007cd93bddfad1  push rdx
00007cd93bddfad2  push rdi
00007cd93bddfad3  push rsi
00007cd93bddfad4  push r8
00007cd93bddfad6  push r9
00007cd93bddfad8  push r10
00007cd93bddfada  push r11
00007cd93bddfadc  sub rsp, 0xF0
00007cd93bddfae3  vmovaps [rsp], xmm0
00007cd93bddfae8  vmovaps [rsp+0x10], xmm1
00007cd93bddfaee  vmovaps [rsp+0x20], xmm2
00007cd93bddfaf4  vmovaps [rsp+0x30], xmm3
00007cd93bddfafa  vmovaps [rsp+0x40], xmm4
00007cd93bddfb00  vmovaps [rsp+0x50], xmm5
00007cd93bddfb06  vmovaps [rsp+0x60], xmm6
00007cd93bddfb0c  vmovaps [rsp+0x70], xmm7
00007cd93bddfb12  vmovaps [rsp+0x80], xmm8
00007cd93bddfb1b  vmovaps [rsp+0x90], xmm9
00007cd93bddfb24  vmovaps [rsp+0xA0], xmm10
00007cd93bddfb2d  vmovaps [rsp+0xB0], xmm11
00007cd93bddfb36  vmovaps [rsp+0xC0], xmm12
00007cd93bddfb3f  vmovaps [rsp+0xD0], xmm13
00007cd93bddfb48  vmovaps [rsp+0xE0], xmm14
00007cd93bddfb51  sub rsp, 0x30
00007cd93bddfb55  movaps [rsp], xmm15
00007cd93bddfb5a  movaps [rsp+0x10], xmm1
00007cd93bddfb5f  movaps [rsp+0x20], xmm5
00007cd93bddfb64  lea rdi, [rsp]
00007cd93bddfb68  mov esi, 0x00
00007cd93bddfb6d  mov rax, 0x64A581057530
00007cd93bddfb77  call rax
00007cd93bddfb79  movaps xmm15, [rsp]
00007cd93bddfb7e  add rsp, 0x30
00007cd93bddfb82  vmovaps xmm0, [rsp]
00007cd93bddfb87  vmovaps xmm1, [rsp+0x10]
00007cd93bddfb8d  vmovaps xmm2, [rsp+0x20]
00007cd93bddfb93  vmovaps xmm3, [rsp+0x30]
00007cd93bddfb99  vmovaps xmm4, [rsp+0x40]
00007cd93bddfb9f  vmovaps xmm5, [rsp+0x50]
00007cd93bddfba5  vmovaps xmm6, [rsp+0x60]
00007cd93bddfbab  vmovaps xmm7, [rsp+0x70]
00007cd93bddfbb1  vmovaps xmm8, [rsp+0x80]
00007cd93bddfbba  vmovaps xmm9, [rsp+0x90]
00007cd93bddfbc3  vmovaps xmm10, [rsp+0xA0]
00007cd93bddfbcc  vmovaps xmm11, [rsp+0xB0]
00007cd93bddfbd5  vmovaps xmm12, [rsp+0xC0]
00007cd93bddfbde  vmovaps xmm13, [rsp+0xD0]
00007cd93bddfbe7  vmovaps xmm14, [rsp+0xE0]
00007cd93bddfbf0  add rsp, 0xF0
00007cd93bddfbf7  pop r11
00007cd93bddfbf9  pop r10
00007cd93bddfbfb  pop r9
00007cd93bddfbfd  pop r8
00007cd93bddfbff  pop rsi
00007cd93bddfc00  pop rdi
00007cd93bddfc01  pop rdx
00007cd93bddfc02  pop rcx
00007cd93bddfc03  pop rax
00007cd93bddfc04  add rsp, 0x08
00007cd93bddfc08  jmp 0x00007CD93BDDC473
00007cd93bddfc0d  call 0x00007CD93BCB52F0
00007cd93bddfc12  jmp 0x00007CD93BDDC4CE
00007cd93bddfc17  sub rsp, 0x08
00007cd93bddfc1b  push rax
00007cd93bddfc1c  push rcx
00007cd93bddfc1d  push rdx
00007cd93bddfc1e  push rdi
00007cd93bddfc1f  push rsi
00007cd93bddfc20  push r8
00007cd93bddfc22  push r9
00007cd93bddfc24  push r10
00007cd93bddfc26  push r11
00007cd93bddfc28  sub rsp, 0xF0
00007cd93bddfc2f  vmovaps [rsp], xmm0
00007cd93bddfc34  vmovaps [rsp+0x10], xmm1
00007cd93bddfc3a  vmovaps [rsp+0x20], xmm2
00007cd93bddfc40  vmovaps [rsp+0x30], xmm3
00007cd93bddfc46  vmovaps [rsp+0x40], xmm4
00007cd93bddfc4c  vmovaps [rsp+0x50], xmm5
00007cd93bddfc52  vmovaps [rsp+0x60], xmm6
00007cd93bddfc58  vmovaps [rsp+0x70], xmm7
00007cd93bddfc5e  vmovaps [rsp+0x80], xmm8
00007cd93bddfc67  vmovaps [rsp+0x90], xmm10
00007cd93bddfc70  vmovaps [rsp+0xA0], xmm11
00007cd93bddfc79  vmovaps [rsp+0xB0], xmm12
00007cd93bddfc82  vmovaps [rsp+0xC0], xmm13
00007cd93bddfc8b  vmovaps [rsp+0xD0], xmm14
00007cd93bddfc94  vmovaps [rsp+0xE0], xmm15
00007cd93bddfc9d  sub rsp, 0x30
00007cd93bddfca1  movaps [rsp], xmm9
00007cd93bddfca6  movaps [rsp+0x10], xmm8
00007cd93bddfcac  movaps [rsp+0x20], xmm11
00007cd93bddfcb2  lea rdi, [rsp]
00007cd93bddfcb6  mov esi, 0x00
00007cd93bddfcbb  mov rax, 0x64A581057530
00007cd93bddfcc5  call rax
00007cd93bddfcc7  movaps xmm9, [rsp]
00007cd93bddfccc  add rsp, 0x30
00007cd93bddfcd0  vmovaps xmm0, [rsp]
00007cd93bddfcd5  vmovaps xmm1, [rsp+0x10]
00007cd93bddfcdb  vmovaps xmm2, [rsp+0x20]
00007cd93bddfce1  vmovaps xmm3, [rsp+0x30]
00007cd93bddfce7  vmovaps xmm4, [rsp+0x40]
00007cd93bddfced  vmovaps xmm5, [rsp+0x50]
00007cd93bddfcf3  vmovaps xmm6, [rsp+0x60]
00007cd93bddfcf9  vmovaps xmm7, [rsp+0x70]
00007cd93bddfcff  vmovaps xmm8, [rsp+0x80]
00007cd93bddfd08  vmovaps xmm10, [rsp+0x90]
00007cd93bddfd11  vmovaps xmm11, [rsp+0xA0]
00007cd93bddfd1a  vmovaps xmm12, [rsp+0xB0]
00007cd93bddfd23  vmovaps xmm13, [rsp+0xC0]
00007cd93bddfd2c  vmovaps xmm14, [rsp+0xD0]
00007cd93bddfd35  vmovaps xmm15, [rsp+0xE0]
00007cd93bddfd3e  add rsp, 0xF0
00007cd93bddfd45  pop r11
00007cd93bddfd47  pop r10
00007cd93bddfd49  pop r9
00007cd93bddfd4b  pop r8
00007cd93bddfd4d  pop rsi
00007cd93bddfd4e  pop rdi
00007cd93bddfd4f  pop rdx
00007cd93bddfd50  pop rcx
00007cd93bddfd51  pop rax
00007cd93bddfd52  add rsp, 0x08
00007cd93bddfd56  jmp 0x00007CD93BDDC505
00007cd93bddfd5b  sub rsp, 0x08
00007cd93bddfd5f  push rax
00007cd93bddfd60  push rcx
00007cd93bddfd61  push rdx
00007cd93bddfd62  push rdi
00007cd93bddfd63  push rsi
00007cd93bddfd64  push r8
00007cd93bddfd66  push r9
00007cd93bddfd68  push r10
00007cd93bddfd6a  push r11
00007cd93bddfd6c  sub rsp, 0xF0
00007cd93bddfd73  vmovaps [rsp], xmm0
00007cd93bddfd78  vmovaps [rsp+0x10], xmm1
00007cd93bddfd7e  vmovaps [rsp+0x20], xmm2
00007cd93bddfd84  vmovaps [rsp+0x30], xmm3
00007cd93bddfd8a  vmovaps [rsp+0x40], xmm4
00007cd93bddfd90  vmovaps [rsp+0x50], xmm5
00007cd93bddfd96  vmovaps [rsp+0x60], xmm6
00007cd93bddfd9c  vmovaps [rsp+0x70], xmm7
00007cd93bddfda2  vmovaps [rsp+0x80], xmm8
00007cd93bddfdab  vmovaps [rsp+0x90], xmm9
00007cd93bddfdb4  vmovaps [rsp+0xA0], xmm10
00007cd93bddfdbd  vmovaps [rsp+0xB0], xmm12
00007cd93bddfdc6  vmovaps [rsp+0xC0], xmm13
00007cd93bddfdcf  vmovaps [rsp+0xD0], xmm14
00007cd93bddfdd8  vmovaps [rsp+0xE0], xmm15
00007cd93bddfde1  sub rsp, 0x30
00007cd93bddfde5  movaps [rsp], xmm11
00007cd93bddfdea  movaps [rsp+0x10], xmm10
00007cd93bddfdf0  movaps [rsp+0x20], xmm6
00007cd93bddfdf5  lea rdi, [rsp]
00007cd93bddfdf9  mov esi, 0x00
00007cd93bddfdfe  mov rax, 0x64A581057530
00007cd93bddfe08  call rax
00007cd93bddfe0a  movaps xmm11, [rsp]
00007cd93bddfe0f  add rsp, 0x30
00007cd93bddfe13  vmovaps xmm0, [rsp]
00007cd93bddfe18  vmovaps xmm1, [rsp+0x10]
00007cd93bddfe1e  vmovaps xmm2, [rsp+0x20]
00007cd93bddfe24  vmovaps xmm3, [rsp+0x30]
00007cd93bddfe2a  vmovaps xmm4, [rsp+0x40]
00007cd93bddfe30  vmovaps xmm5, [rsp+0x50]
00007cd93bddfe36  vmovaps xmm6, [rsp+0x60]
00007cd93bddfe3c  vmovaps xmm7, [rsp+0x70]
00007cd93bddfe42  vmovaps xmm8, [rsp+0x80]
00007cd93bddfe4b  vmovaps xmm9, [rsp+0x90]
00007cd93bddfe54  vmovaps xmm10, [rsp+0xA0]
00007cd93bddfe5d  vmovaps xmm12, [rsp+0xB0]
00007cd93bddfe66  vmovaps xmm13, [rsp+0xC0]
00007cd93bddfe6f  vmovaps xmm14, [rsp+0xD0]
00007cd93bddfe78  vmovaps xmm15, [rsp+0xE0]
00007cd93bddfe81  add rsp, 0xF0
00007cd93bddfe88  pop r11
00007cd93bddfe8a  pop r10
00007cd93bddfe8c  pop r9
00007cd93bddfe8e  pop r8
00007cd93bddfe90  pop rsi
00007cd93bddfe91  pop rdi
00007cd93bddfe92  pop rdx
00007cd93bddfe93  pop rcx
00007cd93bddfe94  pop rax
00007cd93bddfe95  add rsp, 0x08
00007cd93bddfe99  jmp 0x00007CD93BDDC520
00007cd93bddfe9e  sub rsp, 0x08
00007cd93bddfea2  push rax
00007cd93bddfea3  push rcx
00007cd93bddfea4  push rdx
00007cd93bddfea5  push rdi
00007cd93bddfea6  push rsi
00007cd93bddfea7  push r8
00007cd93bddfea9  push r9
00007cd93bddfeab  push r10
00007cd93bddfead  push r11
00007cd93bddfeaf  sub rsp, 0xF0
00007cd93bddfeb6  vmovaps [rsp], xmm0
00007cd93bddfebb  vmovaps [rsp+0x10], xmm1
00007cd93bddfec1  vmovaps [rsp+0x20], xmm2
00007cd93bddfec7  vmovaps [rsp+0x30], xmm3
00007cd93bddfecd  vmovaps [rsp+0x40], xmm4
00007cd93bddfed3  vmovaps [rsp+0x50], xmm5
00007cd93bddfed9  vmovaps [rsp+0x60], xmm6
00007cd93bddfedf  vmovaps [rsp+0x70], xmm7
00007cd93bddfee5  vmovaps [rsp+0x80], xmm8
00007cd93bddfeee  vmovaps [rsp+0x90], xmm9
00007cd93bddfef7  vmovaps [rsp+0xA0], xmm11
00007cd93bddff00  vmovaps [rsp+0xB0], xmm12
00007cd93bddff09  vmovaps [rsp+0xC0], xmm13
00007cd93bddff12  vmovaps [rsp+0xD0], xmm14
00007cd93bddff1b  vmovaps [rsp+0xE0], xmm15
00007cd93bddff24  sub rsp, 0x30
00007cd93bddff28  movaps [rsp], xmm10
00007cd93bddff2d  movaps [rsp+0x10], xmm14
00007cd93bddff33  movaps [rsp+0x20], xmm4
00007cd93bddff38  lea rdi, [rsp]
00007cd93bddff3c  mov esi, 0x00
00007cd93bddff41  mov rax, 0x64A581057530
00007cd93bddff4b  call rax
00007cd93bddff4d  movaps xmm10, [rsp]
00007cd93bddff52  add rsp, 0x30
00007cd93bddff56  vmovaps xmm0, [rsp]
00007cd93bddff5b  vmovaps xmm1, [rsp+0x10]
00007cd93bddff61  vmovaps xmm2, [rsp+0x20]
00007cd93bddff67  vmovaps xmm3, [rsp+0x30]
00007cd93bddff6d  vmovaps xmm4, [rsp+0x40]
00007cd93bddff73  vmovaps xmm5, [rsp+0x50]
00007cd93bddff79  vmovaps xmm6, [rsp+0x60]
00007cd93bddff7f  vmovaps xmm7, [rsp+0x70]
00007cd93bddff85  vmovaps xmm8, [rsp+0x80]
00007cd93bddff8e  vmovaps xmm9, [rsp+0x90]
00007cd93bddff97  vmovaps xmm11, [rsp+0xA0]
00007cd93bddffa0  vmovaps xmm12, [rsp+0xB0]
00007cd93bddffa9  vmovaps xmm13, [rsp+0xC0]
00007cd93bddffb2  vmovaps xmm14, [rsp+0xD0]
00007cd93bddffbb  vmovaps xmm15, [rsp+0xE0]
00007cd93bddffc4  add rsp, 0xF0
00007cd93bddffcb  pop r11
00007cd93bddffcd  pop r10
00007cd93bddffcf  pop r9
00007cd93bddffd1  pop r8
00007cd93bddffd3  pop rsi
00007cd93bddffd4  pop rdi
00007cd93bddffd5  pop rdx
00007cd93bddffd6  pop rcx
00007cd93bddffd7  pop rax
00007cd93bddffd8  add rsp, 0x08
00007cd93bddffdc  jmp 0x00007CD93BDDC53B
00007cd93bddffe1  sub rsp, 0x08
00007cd93bddffe5  push rax
00007cd93bddffe6  push rcx
00007cd93bddffe7  push rdx
00007cd93bddffe8  push rdi
00007cd93bddffe9  push rsi
00007cd93bddffea  push r8
00007cd93bddffec  push r9
00007cd93bddffee  push r10
00007cd93bddfff0  push r11
00007cd93bddfff2  sub rsp, 0xF0
00007cd93bddfff9  vmovaps [rsp], xmm0
00007cd93bddfffe  vmovaps [rsp+0x10], xmm1
00007cd93bde0004  vmovaps [rsp+0x20], xmm2
00007cd93bde000a  vmovaps [rsp+0x30], xmm3
00007cd93bde0010  vmovaps [rsp+0x40], xmm4
00007cd93bde0016  vmovaps [rsp+0x50], xmm5
00007cd93bde001c  vmovaps [rsp+0x60], xmm6
00007cd93bde0022  vmovaps [rsp+0x70], xmm7
00007cd93bde0028  vmovaps [rsp+0x80], xmm9
00007cd93bde0031  vmovaps [rsp+0x90], xmm10
00007cd93bde003a  vmovaps [rsp+0xA0], xmm11
00007cd93bde0043  vmovaps [rsp+0xB0], xmm12
00007cd93bde004c  vmovaps [rsp+0xC0], xmm13
00007cd93bde0055  vmovaps [rsp+0xD0], xmm14
00007cd93bde005e  vmovaps [rsp+0xE0], xmm15
00007cd93bde0067  sub rsp, 0x30
00007cd93bde006b  movaps [rsp], xmm8
00007cd93bde0070  movaps [rsp+0x10], xmm1
00007cd93bde0075  movaps [rsp+0x20], xmm14
00007cd93bde007b  lea rdi, [rsp]
00007cd93bde007f  mov esi, 0x00
00007cd93bde0084  mov rax, 0x64A581057530
00007cd93bde008e  call rax
00007cd93bde0090  movaps xmm8, [rsp]
00007cd93bde0095  add rsp, 0x30
00007cd93bde0099  vmovaps xmm0, [rsp]
00007cd93bde009e  vmovaps xmm1, [rsp+0x10]
00007cd93bde00a4  vmovaps xmm2, [rsp+0x20]
00007cd93bde00aa  vmovaps xmm3, [rsp+0x30]
00007cd93bde00b0  vmovaps xmm4, [rsp+0x40]
00007cd93bde00b6  vmovaps xmm5, [rsp+0x50]
00007cd93bde00bc  vmovaps xmm6, [rsp+0x60]
00007cd93bde00c2  vmovaps xmm7, [rsp+0x70]
00007cd93bde00c8  vmovaps xmm9, [rsp+0x80]
00007cd93bde00d1  vmovaps xmm10, [rsp+0x90]
00007cd93bde00da  vmovaps xmm11, [rsp+0xA0]
00007cd93bde00e3  vmovaps xmm12, [rsp+0xB0]
00007cd93bde00ec  vmovaps xmm13, [rsp+0xC0]
00007cd93bde00f5  vmovaps xmm14, [rsp+0xD0]
00007cd93bde00fe  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0107  add rsp, 0xF0
00007cd93bde010e  pop r11
00007cd93bde0110  pop r10
00007cd93bde0112  pop r9
00007cd93bde0114  pop r8
00007cd93bde0116  pop rsi
00007cd93bde0117  pop rdi
00007cd93bde0118  pop rdx
00007cd93bde0119  pop rcx
00007cd93bde011a  pop rax
00007cd93bde011b  add rsp, 0x08
00007cd93bde011f  jmp 0x00007CD93BDDC561
00007cd93bde0124  sub rsp, 0x08
00007cd93bde0128  push rax
00007cd93bde0129  push rcx
00007cd93bde012a  push rdx
00007cd93bde012b  push rdi
00007cd93bde012c  push rsi
00007cd93bde012d  push r8
00007cd93bde012f  push r9
00007cd93bde0131  push r10
00007cd93bde0133  push r11
00007cd93bde0135  sub rsp, 0xF0
00007cd93bde013c  vmovaps [rsp], xmm0
00007cd93bde0141  vmovaps [rsp+0x10], xmm1
00007cd93bde0147  vmovaps [rsp+0x20], xmm2
00007cd93bde014d  vmovaps [rsp+0x30], xmm3
00007cd93bde0153  vmovaps [rsp+0x40], xmm4
00007cd93bde0159  vmovaps [rsp+0x50], xmm5
00007cd93bde015f  vmovaps [rsp+0x60], xmm7
00007cd93bde0165  vmovaps [rsp+0x70], xmm8
00007cd93bde016b  vmovaps [rsp+0x80], xmm9
00007cd93bde0174  vmovaps [rsp+0x90], xmm10
00007cd93bde017d  vmovaps [rsp+0xA0], xmm11
00007cd93bde0186  vmovaps [rsp+0xB0], xmm12
00007cd93bde018f  vmovaps [rsp+0xC0], xmm13
00007cd93bde0198  vmovaps [rsp+0xD0], xmm14
00007cd93bde01a1  vmovaps [rsp+0xE0], xmm15
00007cd93bde01aa  sub rsp, 0x30
00007cd93bde01ae  movaps [rsp], xmm6
00007cd93bde01b2  movaps [rsp+0x10], xmm1
00007cd93bde01b7  movaps [rsp+0x20], xmm14
00007cd93bde01bd  lea rdi, [rsp]
00007cd93bde01c1  mov esi, 0x00
00007cd93bde01c6  mov rax, 0x64A581057530
00007cd93bde01d0  call rax
00007cd93bde01d2  movaps xmm6, [rsp]
00007cd93bde01d6  add rsp, 0x30
00007cd93bde01da  vmovaps xmm0, [rsp]
00007cd93bde01df  vmovaps xmm1, [rsp+0x10]
00007cd93bde01e5  vmovaps xmm2, [rsp+0x20]
00007cd93bde01eb  vmovaps xmm3, [rsp+0x30]
00007cd93bde01f1  vmovaps xmm4, [rsp+0x40]
00007cd93bde01f7  vmovaps xmm5, [rsp+0x50]
00007cd93bde01fd  vmovaps xmm7, [rsp+0x60]
00007cd93bde0203  vmovaps xmm8, [rsp+0x70]
00007cd93bde0209  vmovaps xmm9, [rsp+0x80]
00007cd93bde0212  vmovaps xmm10, [rsp+0x90]
00007cd93bde021b  vmovaps xmm11, [rsp+0xA0]
00007cd93bde0224  vmovaps xmm12, [rsp+0xB0]
00007cd93bde022d  vmovaps xmm13, [rsp+0xC0]
00007cd93bde0236  vmovaps xmm14, [rsp+0xD0]
00007cd93bde023f  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0248  add rsp, 0xF0
00007cd93bde024f  pop r11
00007cd93bde0251  pop r10
00007cd93bde0253  pop r9
00007cd93bde0255  pop r8
00007cd93bde0257  pop rsi
00007cd93bde0258  pop rdi
00007cd93bde0259  pop rdx
00007cd93bde025a  pop rcx
00007cd93bde025b  pop rax
00007cd93bde025c  add rsp, 0x08
00007cd93bde0260  jmp 0x00007CD93BDDC58D
00007cd93bde0265  sub rsp, 0x08
00007cd93bde0269  push rax
00007cd93bde026a  push rcx
00007cd93bde026b  push rdx
00007cd93bde026c  push rdi
00007cd93bde026d  push rsi
00007cd93bde026e  push r8
00007cd93bde0270  push r9
00007cd93bde0272  push r10
00007cd93bde0274  push r11
00007cd93bde0276  sub rsp, 0xF0
00007cd93bde027d  vmovaps [rsp], xmm0
00007cd93bde0282  vmovaps [rsp+0x10], xmm1
00007cd93bde0288  vmovaps [rsp+0x20], xmm2
00007cd93bde028e  vmovaps [rsp+0x30], xmm3
00007cd93bde0294  vmovaps [rsp+0x40], xmm4
00007cd93bde029a  vmovaps [rsp+0x50], xmm5
00007cd93bde02a0  vmovaps [rsp+0x60], xmm6
00007cd93bde02a6  vmovaps [rsp+0x70], xmm7
00007cd93bde02ac  vmovaps [rsp+0x80], xmm8
00007cd93bde02b5  vmovaps [rsp+0x90], xmm9
00007cd93bde02be  vmovaps [rsp+0xA0], xmm10
00007cd93bde02c7  vmovaps [rsp+0xB0], xmm11
00007cd93bde02d0  vmovaps [rsp+0xC0], xmm12
00007cd93bde02d9  vmovaps [rsp+0xD0], xmm13
00007cd93bde02e2  vmovaps [rsp+0xE0], xmm15
00007cd93bde02eb  sub rsp, 0x30
00007cd93bde02ef  movaps [rsp], xmm14
00007cd93bde02f4  movaps [rsp+0x10], xmm12
00007cd93bde02fa  movaps [rsp+0x20], xmm1
00007cd93bde02ff  lea rdi, [rsp]
00007cd93bde0303  mov esi, 0x00
00007cd93bde0308  mov rax, 0x64A581057530
00007cd93bde0312  call rax
00007cd93bde0314  movaps xmm14, [rsp]
00007cd93bde0319  add rsp, 0x30
00007cd93bde031d  vmovaps xmm0, [rsp]
00007cd93bde0322  vmovaps xmm1, [rsp+0x10]
00007cd93bde0328  vmovaps xmm2, [rsp+0x20]
00007cd93bde032e  vmovaps xmm3, [rsp+0x30]
00007cd93bde0334  vmovaps xmm4, [rsp+0x40]
00007cd93bde033a  vmovaps xmm5, [rsp+0x50]
00007cd93bde0340  vmovaps xmm6, [rsp+0x60]
00007cd93bde0346  vmovaps xmm7, [rsp+0x70]
00007cd93bde034c  vmovaps xmm8, [rsp+0x80]
00007cd93bde0355  vmovaps xmm9, [rsp+0x90]
00007cd93bde035e  vmovaps xmm10, [rsp+0xA0]
00007cd93bde0367  vmovaps xmm11, [rsp+0xB0]
00007cd93bde0370  vmovaps xmm12, [rsp+0xC0]
00007cd93bde0379  vmovaps xmm13, [rsp+0xD0]
00007cd93bde0382  vmovaps xmm15, [rsp+0xE0]
00007cd93bde038b  add rsp, 0xF0
00007cd93bde0392  pop r11
00007cd93bde0394  pop r10
00007cd93bde0396  pop r9
00007cd93bde0398  pop r8
00007cd93bde039a  pop rsi
00007cd93bde039b  pop rdi
00007cd93bde039c  pop rdx
00007cd93bde039d  pop rcx
00007cd93bde039e  pop rax
00007cd93bde039f  add rsp, 0x08
00007cd93bde03a3  jmp 0x00007CD93BDDC5B3
00007cd93bde03a8  sub rsp, 0x08
00007cd93bde03ac  push rax
00007cd93bde03ad  push rcx
00007cd93bde03ae  push rdx
00007cd93bde03af  push rdi
00007cd93bde03b0  push rsi
00007cd93bde03b1  push r8
00007cd93bde03b3  push r9
00007cd93bde03b5  push r10
00007cd93bde03b7  push r11
00007cd93bde03b9  sub rsp, 0xF0
00007cd93bde03c0  vmovaps [rsp], xmm0
00007cd93bde03c5  vmovaps [rsp+0x10], xmm2
00007cd93bde03cb  vmovaps [rsp+0x20], xmm3
00007cd93bde03d1  vmovaps [rsp+0x30], xmm4
00007cd93bde03d7  vmovaps [rsp+0x40], xmm5
00007cd93bde03dd  vmovaps [rsp+0x50], xmm6
00007cd93bde03e3  vmovaps [rsp+0x60], xmm7
00007cd93bde03e9  vmovaps [rsp+0x70], xmm8
00007cd93bde03ef  vmovaps [rsp+0x80], xmm9
00007cd93bde03f8  vmovaps [rsp+0x90], xmm10
00007cd93bde0401  vmovaps [rsp+0xA0], xmm11
00007cd93bde040a  vmovaps [rsp+0xB0], xmm12
00007cd93bde0413  vmovaps [rsp+0xC0], xmm13
00007cd93bde041c  vmovaps [rsp+0xD0], xmm14
00007cd93bde0425  vmovaps [rsp+0xE0], xmm15
00007cd93bde042e  sub rsp, 0x30
00007cd93bde0432  movaps [rsp], xmm1
00007cd93bde0436  movaps [rsp+0x10], xmm13
00007cd93bde043c  movaps [rsp+0x20], xmm9
00007cd93bde0442  lea rdi, [rsp]
00007cd93bde0446  mov esi, 0x00
00007cd93bde044b  mov rax, 0x64A581057530
00007cd93bde0455  call rax
00007cd93bde0457  movaps xmm1, [rsp]
00007cd93bde045b  add rsp, 0x30
00007cd93bde045f  vmovaps xmm0, [rsp]
00007cd93bde0464  vmovaps xmm2, [rsp+0x10]
00007cd93bde046a  vmovaps xmm3, [rsp+0x20]
00007cd93bde0470  vmovaps xmm4, [rsp+0x30]
00007cd93bde0476  vmovaps xmm5, [rsp+0x40]
00007cd93bde047c  vmovaps xmm6, [rsp+0x50]
00007cd93bde0482  vmovaps xmm7, [rsp+0x60]
00007cd93bde0488  vmovaps xmm8, [rsp+0x70]
00007cd93bde048e  vmovaps xmm9, [rsp+0x80]
00007cd93bde0497  vmovaps xmm10, [rsp+0x90]
00007cd93bde04a0  vmovaps xmm11, [rsp+0xA0]
00007cd93bde04a9  vmovaps xmm12, [rsp+0xB0]
00007cd93bde04b2  vmovaps xmm13, [rsp+0xC0]
00007cd93bde04bb  vmovaps xmm14, [rsp+0xD0]
00007cd93bde04c4  vmovaps xmm15, [rsp+0xE0]
00007cd93bde04cd  add rsp, 0xF0
00007cd93bde04d4  pop r11
00007cd93bde04d6  pop r10
00007cd93bde04d8  pop r9
00007cd93bde04da  pop r8
00007cd93bde04dc  pop rsi
00007cd93bde04dd  pop rdi
00007cd93bde04de  pop rdx
00007cd93bde04df  pop rcx
00007cd93bde04e0  pop rax
00007cd93bde04e1  add rsp, 0x08
00007cd93bde04e5  jmp 0x00007CD93BDDC5CD
00007cd93bde04ea  sub rsp, 0x08
00007cd93bde04ee  push rax
00007cd93bde04ef  push rcx
00007cd93bde04f0  push rdx
00007cd93bde04f1  push rdi
00007cd93bde04f2  push rsi
00007cd93bde04f3  push r8
00007cd93bde04f5  push r9
00007cd93bde04f7  push r10
00007cd93bde04f9  push r11
00007cd93bde04fb  sub rsp, 0xF0
00007cd93bde0502  vmovaps [rsp], xmm0
00007cd93bde0507  vmovaps [rsp+0x10], xmm1
00007cd93bde050d  vmovaps [rsp+0x20], xmm2
00007cd93bde0513  vmovaps [rsp+0x30], xmm3
00007cd93bde0519  vmovaps [rsp+0x40], xmm4
00007cd93bde051f  vmovaps [rsp+0x50], xmm5
00007cd93bde0525  vmovaps [rsp+0x60], xmm6
00007cd93bde052b  vmovaps [rsp+0x70], xmm7
00007cd93bde0531  vmovaps [rsp+0x80], xmm8
00007cd93bde053a  vmovaps [rsp+0x90], xmm9
00007cd93bde0543  vmovaps [rsp+0xA0], xmm10
00007cd93bde054c  vmovaps [rsp+0xB0], xmm11
00007cd93bde0555  vmovaps [rsp+0xC0], xmm13
00007cd93bde055e  vmovaps [rsp+0xD0], xmm14
00007cd93bde0567  vmovaps [rsp+0xE0], xmm15
00007cd93bde0570  sub rsp, 0x30
00007cd93bde0574  movaps [rsp], xmm12
00007cd93bde0579  movaps [rsp+0x10], xmm7
00007cd93bde057e  movaps [rsp+0x20], xmm13
00007cd93bde0584  lea rdi, [rsp]
00007cd93bde0588  mov esi, 0x00
00007cd93bde058d  mov rax, 0x64A581057530
00007cd93bde0597  call rax
00007cd93bde0599  movaps xmm12, [rsp]
00007cd93bde059e  add rsp, 0x30
00007cd93bde05a2  vmovaps xmm0, [rsp]
00007cd93bde05a7  vmovaps xmm1, [rsp+0x10]
00007cd93bde05ad  vmovaps xmm2, [rsp+0x20]
00007cd93bde05b3  vmovaps xmm3, [rsp+0x30]
00007cd93bde05b9  vmovaps xmm4, [rsp+0x40]
00007cd93bde05bf  vmovaps xmm5, [rsp+0x50]
00007cd93bde05c5  vmovaps xmm6, [rsp+0x60]
00007cd93bde05cb  vmovaps xmm7, [rsp+0x70]
00007cd93bde05d1  vmovaps xmm8, [rsp+0x80]
00007cd93bde05da  vmovaps xmm9, [rsp+0x90]
00007cd93bde05e3  vmovaps xmm10, [rsp+0xA0]
00007cd93bde05ec  vmovaps xmm11, [rsp+0xB0]
00007cd93bde05f5  vmovaps xmm13, [rsp+0xC0]
00007cd93bde05fe  vmovaps xmm14, [rsp+0xD0]
00007cd93bde0607  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0610  add rsp, 0xF0
00007cd93bde0617  pop r11
00007cd93bde0619  pop r10
00007cd93bde061b  pop r9
00007cd93bde061d  pop r8
00007cd93bde061f  pop rsi
00007cd93bde0620  pop rdi
00007cd93bde0621  pop rdx
00007cd93bde0622  pop rcx
00007cd93bde0623  pop rax
00007cd93bde0624  add rsp, 0x08
00007cd93bde0628  jmp 0x00007CD93BDDC5F4
00007cd93bde062d  sub rsp, 0x08
00007cd93bde0631  push rax
00007cd93bde0632  push rcx
00007cd93bde0633  push rdx
00007cd93bde0634  push rdi
00007cd93bde0635  push rsi
00007cd93bde0636  push r8
00007cd93bde0638  push r9
00007cd93bde063a  push r10
00007cd93bde063c  push r11
00007cd93bde063e  sub rsp, 0xF0
00007cd93bde0645  vmovaps [rsp], xmm0
00007cd93bde064a  vmovaps [rsp+0x10], xmm1
00007cd93bde0650  vmovaps [rsp+0x20], xmm2
00007cd93bde0656  vmovaps [rsp+0x30], xmm3
00007cd93bde065c  vmovaps [rsp+0x40], xmm4
00007cd93bde0662  vmovaps [rsp+0x50], xmm5
00007cd93bde0668  vmovaps [rsp+0x60], xmm6
00007cd93bde066e  vmovaps [rsp+0x70], xmm7
00007cd93bde0674  vmovaps [rsp+0x80], xmm8
00007cd93bde067d  vmovaps [rsp+0x90], xmm9
00007cd93bde0686  vmovaps [rsp+0xA0], xmm10
00007cd93bde068f  vmovaps [rsp+0xB0], xmm11
00007cd93bde0698  vmovaps [rsp+0xC0], xmm12
00007cd93bde06a1  vmovaps [rsp+0xD0], xmm14
00007cd93bde06aa  vmovaps [rsp+0xE0], xmm15
00007cd93bde06b3  sub rsp, 0x30
00007cd93bde06b7  movaps [rsp], xmm13
00007cd93bde06bc  movaps [rsp+0x10], xmm15
00007cd93bde06c2  movaps [rsp+0x20], xmm8
00007cd93bde06c8  lea rdi, [rsp]
00007cd93bde06cc  mov esi, 0x00
00007cd93bde06d1  mov rax, 0x64A581057530
00007cd93bde06db  call rax
00007cd93bde06dd  movaps xmm13, [rsp]
00007cd93bde06e2  add rsp, 0x30
00007cd93bde06e6  vmovaps xmm0, [rsp]
00007cd93bde06eb  vmovaps xmm1, [rsp+0x10]
00007cd93bde06f1  vmovaps xmm2, [rsp+0x20]
00007cd93bde06f7  vmovaps xmm3, [rsp+0x30]
00007cd93bde06fd  vmovaps xmm4, [rsp+0x40]
00007cd93bde0703  vmovaps xmm5, [rsp+0x50]
00007cd93bde0709  vmovaps xmm6, [rsp+0x60]
00007cd93bde070f  vmovaps xmm7, [rsp+0x70]
00007cd93bde0715  vmovaps xmm8, [rsp+0x80]
00007cd93bde071e  vmovaps xmm9, [rsp+0x90]
00007cd93bde0727  vmovaps xmm10, [rsp+0xA0]
00007cd93bde0730  vmovaps xmm11, [rsp+0xB0]
00007cd93bde0739  vmovaps xmm12, [rsp+0xC0]
00007cd93bde0742  vmovaps xmm14, [rsp+0xD0]
00007cd93bde074b  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0754  add rsp, 0xF0
00007cd93bde075b  pop r11
00007cd93bde075d  pop r10
00007cd93bde075f  pop r9
00007cd93bde0761  pop r8
00007cd93bde0763  pop rsi
00007cd93bde0764  pop rdi
00007cd93bde0765  pop rdx
00007cd93bde0766  pop rcx
00007cd93bde0767  pop rax
00007cd93bde0768  add rsp, 0x08
00007cd93bde076c  jmp 0x00007CD93BDDC60F
00007cd93bde0771  sub rsp, 0x08
00007cd93bde0775  push rax
00007cd93bde0776  push rcx
00007cd93bde0777  push rdx
00007cd93bde0778  push rdi
00007cd93bde0779  push rsi
00007cd93bde077a  push r8
00007cd93bde077c  push r9
00007cd93bde077e  push r10
00007cd93bde0780  push r11
00007cd93bde0782  sub rsp, 0xF0
00007cd93bde0789  vmovaps [rsp], xmm0
00007cd93bde078e  vmovaps [rsp+0x10], xmm1
00007cd93bde0794  vmovaps [rsp+0x20], xmm2
00007cd93bde079a  vmovaps [rsp+0x30], xmm3
00007cd93bde07a0  vmovaps [rsp+0x40], xmm4
00007cd93bde07a6  vmovaps [rsp+0x50], xmm5
00007cd93bde07ac  vmovaps [rsp+0x60], xmm6
00007cd93bde07b2  vmovaps [rsp+0x70], xmm7
00007cd93bde07b8  vmovaps [rsp+0x80], xmm9
00007cd93bde07c1  vmovaps [rsp+0x90], xmm10
00007cd93bde07ca  vmovaps [rsp+0xA0], xmm11
00007cd93bde07d3  vmovaps [rsp+0xB0], xmm12
00007cd93bde07dc  vmovaps [rsp+0xC0], xmm13
00007cd93bde07e5  vmovaps [rsp+0xD0], xmm14
00007cd93bde07ee  vmovaps [rsp+0xE0], xmm15
00007cd93bde07f7  sub rsp, 0x30
00007cd93bde07fb  movaps [rsp], xmm8
00007cd93bde0800  movaps [rsp+0x10], xmm15
00007cd93bde0806  movaps [rsp+0x20], xmm9
00007cd93bde080c  lea rdi, [rsp]
00007cd93bde0810  mov esi, 0x00
00007cd93bde0815  mov rax, 0x64A581057530
00007cd93bde081f  call rax
00007cd93bde0821  movaps xmm8, [rsp]
00007cd93bde0826  add rsp, 0x30
00007cd93bde082a  vmovaps xmm0, [rsp]
00007cd93bde082f  vmovaps xmm1, [rsp+0x10]
00007cd93bde0835  vmovaps xmm2, [rsp+0x20]
00007cd93bde083b  vmovaps xmm3, [rsp+0x30]
00007cd93bde0841  vmovaps xmm4, [rsp+0x40]
00007cd93bde0847  vmovaps xmm5, [rsp+0x50]
00007cd93bde084d  vmovaps xmm6, [rsp+0x60]
00007cd93bde0853  vmovaps xmm7, [rsp+0x70]
00007cd93bde0859  vmovaps xmm9, [rsp+0x80]
00007cd93bde0862  vmovaps xmm10, [rsp+0x90]
00007cd93bde086b  vmovaps xmm11, [rsp+0xA0]
00007cd93bde0874  vmovaps xmm12, [rsp+0xB0]
00007cd93bde087d  vmovaps xmm13, [rsp+0xC0]
00007cd93bde0886  vmovaps xmm14, [rsp+0xD0]
00007cd93bde088f  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0898  add rsp, 0xF0
00007cd93bde089f  pop r11
00007cd93bde08a1  pop r10
00007cd93bde08a3  pop r9
00007cd93bde08a5  pop r8
00007cd93bde08a7  pop rsi
00007cd93bde08a8  pop rdi
00007cd93bde08a9  pop rdx
00007cd93bde08aa  pop rcx
00007cd93bde08ab  pop rax
00007cd93bde08ac  add rsp, 0x08
00007cd93bde08b0  jmp 0x00007CD93BDDC63D
00007cd93bde08b5  sub rsp, 0x08
00007cd93bde08b9  push rax
00007cd93bde08ba  push rcx
00007cd93bde08bb  push rdx
00007cd93bde08bc  push rdi
00007cd93bde08bd  push rsi
00007cd93bde08be  push r8
00007cd93bde08c0  push r9
00007cd93bde08c2  push r10
00007cd93bde08c4  push r11
00007cd93bde08c6  sub rsp, 0xF0
00007cd93bde08cd  vmovaps [rsp], xmm0
00007cd93bde08d2  vmovaps [rsp+0x10], xmm1
00007cd93bde08d8  vmovaps [rsp+0x20], xmm2
00007cd93bde08de  vmovaps [rsp+0x30], xmm3
00007cd93bde08e4  vmovaps [rsp+0x40], xmm4
00007cd93bde08ea  vmovaps [rsp+0x50], xmm5
00007cd93bde08f0  vmovaps [rsp+0x60], xmm6
00007cd93bde08f6  vmovaps [rsp+0x70], xmm7
00007cd93bde08fc  vmovaps [rsp+0x80], xmm8
00007cd93bde0905  vmovaps [rsp+0x90], xmm9
00007cd93bde090e  vmovaps [rsp+0xA0], xmm10
00007cd93bde0917  vmovaps [rsp+0xB0], xmm11
00007cd93bde0920  vmovaps [rsp+0xC0], xmm12
00007cd93bde0929  vmovaps [rsp+0xD0], xmm13
00007cd93bde0932  vmovaps [rsp+0xE0], xmm14
00007cd93bde093b  sub rsp, 0x30
00007cd93bde093f  movaps [rsp], xmm15
00007cd93bde0944  movaps [rsp+0x10], xmm11
00007cd93bde094a  movaps [rsp+0x20], xmm6
00007cd93bde094f  lea rdi, [rsp]
00007cd93bde0953  mov esi, 0x00
00007cd93bde0958  mov rax, 0x64A581057530
00007cd93bde0962  call rax
00007cd93bde0964  movaps xmm15, [rsp]
00007cd93bde0969  add rsp, 0x30
00007cd93bde096d  vmovaps xmm0, [rsp]
00007cd93bde0972  vmovaps xmm1, [rsp+0x10]
00007cd93bde0978  vmovaps xmm2, [rsp+0x20]
00007cd93bde097e  vmovaps xmm3, [rsp+0x30]
00007cd93bde0984  vmovaps xmm4, [rsp+0x40]
00007cd93bde098a  vmovaps xmm5, [rsp+0x50]
00007cd93bde0990  vmovaps xmm6, [rsp+0x60]
00007cd93bde0996  vmovaps xmm7, [rsp+0x70]
00007cd93bde099c  vmovaps xmm8, [rsp+0x80]
00007cd93bde09a5  vmovaps xmm9, [rsp+0x90]
00007cd93bde09ae  vmovaps xmm10, [rsp+0xA0]
00007cd93bde09b7  vmovaps xmm11, [rsp+0xB0]
00007cd93bde09c0  vmovaps xmm12, [rsp+0xC0]
00007cd93bde09c9  vmovaps xmm13, [rsp+0xD0]
00007cd93bde09d2  vmovaps xmm14, [rsp+0xE0]
00007cd93bde09db  add rsp, 0xF0
00007cd93bde09e2  pop r11
00007cd93bde09e4  pop r10
00007cd93bde09e6  pop r9
00007cd93bde09e8  pop r8
00007cd93bde09ea  pop rsi
00007cd93bde09eb  pop rdi
00007cd93bde09ec  pop rdx
00007cd93bde09ed  pop rcx
00007cd93bde09ee  pop rax
00007cd93bde09ef  add rsp, 0x08
00007cd93bde09f3  jmp 0x00007CD93BDDC658
00007cd93bde09f8  sub rsp, 0x08
00007cd93bde09fc  push rax
00007cd93bde09fd  push rcx
00007cd93bde09fe  push rdx
00007cd93bde09ff  push rdi
00007cd93bde0a00  push rsi
00007cd93bde0a01  push r8
00007cd93bde0a03  push r9
00007cd93bde0a05  push r10
00007cd93bde0a07  push r11
00007cd93bde0a09  sub rsp, 0xF0
00007cd93bde0a10  vmovaps [rsp], xmm0
00007cd93bde0a15  vmovaps [rsp+0x10], xmm1
00007cd93bde0a1b  vmovaps [rsp+0x20], xmm2
00007cd93bde0a21  vmovaps [rsp+0x30], xmm3
00007cd93bde0a27  vmovaps [rsp+0x40], xmm4
00007cd93bde0a2d  vmovaps [rsp+0x50], xmm5
00007cd93bde0a33  vmovaps [rsp+0x60], xmm6
00007cd93bde0a39  vmovaps [rsp+0x70], xmm8
00007cd93bde0a3f  vmovaps [rsp+0x80], xmm9
00007cd93bde0a48  vmovaps [rsp+0x90], xmm10
00007cd93bde0a51  vmovaps [rsp+0xA0], xmm11
00007cd93bde0a5a  vmovaps [rsp+0xB0], xmm12
00007cd93bde0a63  vmovaps [rsp+0xC0], xmm13
00007cd93bde0a6c  vmovaps [rsp+0xD0], xmm14
00007cd93bde0a75  vmovaps [rsp+0xE0], xmm15
00007cd93bde0a7e  sub rsp, 0x30
00007cd93bde0a82  movaps [rsp], xmm7
00007cd93bde0a86  movaps [rsp+0x10], xmm11
00007cd93bde0a8c  movaps [rsp+0x20], xmm9
00007cd93bde0a92  lea rdi, [rsp]
00007cd93bde0a96  mov esi, 0x00
00007cd93bde0a9b  mov rax, 0x64A581057530
00007cd93bde0aa5  call rax
00007cd93bde0aa7  movaps xmm7, [rsp]
00007cd93bde0aab  add rsp, 0x30
00007cd93bde0aaf  vmovaps xmm0, [rsp]
00007cd93bde0ab4  vmovaps xmm1, [rsp+0x10]
00007cd93bde0aba  vmovaps xmm2, [rsp+0x20]
00007cd93bde0ac0  vmovaps xmm3, [rsp+0x30]
00007cd93bde0ac6  vmovaps xmm4, [rsp+0x40]
00007cd93bde0acc  vmovaps xmm5, [rsp+0x50]
00007cd93bde0ad2  vmovaps xmm6, [rsp+0x60]
00007cd93bde0ad8  vmovaps xmm8, [rsp+0x70]
00007cd93bde0ade  vmovaps xmm9, [rsp+0x80]
00007cd93bde0ae7  vmovaps xmm10, [rsp+0x90]
00007cd93bde0af0  vmovaps xmm11, [rsp+0xA0]
00007cd93bde0af9  vmovaps xmm12, [rsp+0xB0]
00007cd93bde0b02  vmovaps xmm13, [rsp+0xC0]
00007cd93bde0b0b  vmovaps xmm14, [rsp+0xD0]
00007cd93bde0b14  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0b1d  add rsp, 0xF0
00007cd93bde0b24  pop r11
00007cd93bde0b26  pop r10
00007cd93bde0b28  pop r9
00007cd93bde0b2a  pop r8
00007cd93bde0b2c  pop rsi
00007cd93bde0b2d  pop rdi
00007cd93bde0b2e  pop rdx
00007cd93bde0b2f  pop rcx
00007cd93bde0b30  pop rax
00007cd93bde0b31  add rsp, 0x08
00007cd93bde0b35  jmp 0x00007CD93BDDC685
00007cd93bde0b3a  sub rsp, 0x08
00007cd93bde0b3e  push rax
00007cd93bde0b3f  push rcx
00007cd93bde0b40  push rdx
00007cd93bde0b41  push rdi
00007cd93bde0b42  push rsi
00007cd93bde0b43  push r8
00007cd93bde0b45  push r9
00007cd93bde0b47  push r10
00007cd93bde0b49  push r11
00007cd93bde0b4b  sub rsp, 0xF0
00007cd93bde0b52  vmovaps [rsp], xmm0
00007cd93bde0b57  vmovaps [rsp+0x10], xmm1
00007cd93bde0b5d  vmovaps [rsp+0x20], xmm2
00007cd93bde0b63  vmovaps [rsp+0x30], xmm3
00007cd93bde0b69  vmovaps [rsp+0x40], xmm4
00007cd93bde0b6f  vmovaps [rsp+0x50], xmm5
00007cd93bde0b75  vmovaps [rsp+0x60], xmm6
00007cd93bde0b7b  vmovaps [rsp+0x70], xmm7
00007cd93bde0b81  vmovaps [rsp+0x80], xmm8
00007cd93bde0b8a  vmovaps [rsp+0x90], xmm9
00007cd93bde0b93  vmovaps [rsp+0xA0], xmm10
00007cd93bde0b9c  vmovaps [rsp+0xB0], xmm12
00007cd93bde0ba5  vmovaps [rsp+0xC0], xmm13
00007cd93bde0bae  vmovaps [rsp+0xD0], xmm14
00007cd93bde0bb7  vmovaps [rsp+0xE0], xmm15
00007cd93bde0bc0  sub rsp, 0x30
00007cd93bde0bc4  movaps [rsp], xmm11
00007cd93bde0bc9  movaps [rsp+0x10], xmm10
00007cd93bde0bcf  movaps [rsp+0x20], xmm14
00007cd93bde0bd5  lea rdi, [rsp]
00007cd93bde0bd9  mov esi, 0x00
00007cd93bde0bde  mov rax, 0x64A581057530
00007cd93bde0be8  call rax
00007cd93bde0bea  movaps xmm11, [rsp]
00007cd93bde0bef  add rsp, 0x30
00007cd93bde0bf3  vmovaps xmm0, [rsp]
00007cd93bde0bf8  vmovaps xmm1, [rsp+0x10]
00007cd93bde0bfe  vmovaps xmm2, [rsp+0x20]
00007cd93bde0c04  vmovaps xmm3, [rsp+0x30]
00007cd93bde0c0a  vmovaps xmm4, [rsp+0x40]
00007cd93bde0c10  vmovaps xmm5, [rsp+0x50]
00007cd93bde0c16  vmovaps xmm6, [rsp+0x60]
00007cd93bde0c1c  vmovaps xmm7, [rsp+0x70]
00007cd93bde0c22  vmovaps xmm8, [rsp+0x80]
00007cd93bde0c2b  vmovaps xmm9, [rsp+0x90]
00007cd93bde0c34  vmovaps xmm10, [rsp+0xA0]
00007cd93bde0c3d  vmovaps xmm12, [rsp+0xB0]
00007cd93bde0c46  vmovaps xmm13, [rsp+0xC0]
00007cd93bde0c4f  vmovaps xmm14, [rsp+0xD0]
00007cd93bde0c58  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0c61  add rsp, 0xF0
00007cd93bde0c68  pop r11
00007cd93bde0c6a  pop r10
00007cd93bde0c6c  pop r9
00007cd93bde0c6e  pop r8
00007cd93bde0c70  pop rsi
00007cd93bde0c71  pop rdi
00007cd93bde0c72  pop rdx
00007cd93bde0c73  pop rcx
00007cd93bde0c74  pop rax
00007cd93bde0c75  add rsp, 0x08
00007cd93bde0c79  jmp 0x00007CD93BDDC6A0
00007cd93bde0c7e  call 0x00007CD93BCC33A0
00007cd93bde0c83  jmp 0x00007CD93BDDC6AA
00007cd93bde0c88  sub rsp, 0x08
00007cd93bde0c8c  push rax
00007cd93bde0c8d  push rcx
00007cd93bde0c8e  push rdx
00007cd93bde0c8f  push rdi
00007cd93bde0c90  push rsi
00007cd93bde0c91  push r8
00007cd93bde0c93  push r9
00007cd93bde0c95  push r10
00007cd93bde0c97  push r11
00007cd93bde0c99  sub rsp, 0xF0
00007cd93bde0ca0  vmovaps [rsp], xmm0
00007cd93bde0ca5  vmovaps [rsp+0x10], xmm1
00007cd93bde0cab  vmovaps [rsp+0x20], xmm2
00007cd93bde0cb1  vmovaps [rsp+0x30], xmm3
00007cd93bde0cb7  vmovaps [rsp+0x40], xmm4
00007cd93bde0cbd  vmovaps [rsp+0x50], xmm5
00007cd93bde0cc3  vmovaps [rsp+0x60], xmm6
00007cd93bde0cc9  vmovaps [rsp+0x70], xmm7
00007cd93bde0ccf  vmovaps [rsp+0x80], xmm8
00007cd93bde0cd8  vmovaps [rsp+0x90], xmm9
00007cd93bde0ce1  vmovaps [rsp+0xA0], xmm11
00007cd93bde0cea  vmovaps [rsp+0xB0], xmm12
00007cd93bde0cf3  vmovaps [rsp+0xC0], xmm13
00007cd93bde0cfc  vmovaps [rsp+0xD0], xmm14
00007cd93bde0d05  vmovaps [rsp+0xE0], xmm15
00007cd93bde0d0e  sub rsp, 0x30
00007cd93bde0d12  movaps [rsp], xmm10
00007cd93bde0d17  movaps [rsp+0x10], xmm1
00007cd93bde0d1c  movaps [rsp+0x20], xmm12
00007cd93bde0d22  lea rdi, [rsp]
00007cd93bde0d26  mov esi, 0x00
00007cd93bde0d2b  mov rax, 0x64A581057530
00007cd93bde0d35  call rax
00007cd93bde0d37  movaps xmm10, [rsp]
00007cd93bde0d3c  add rsp, 0x30
00007cd93bde0d40  vmovaps xmm0, [rsp]
00007cd93bde0d45  vmovaps xmm1, [rsp+0x10]
00007cd93bde0d4b  vmovaps xmm2, [rsp+0x20]
00007cd93bde0d51  vmovaps xmm3, [rsp+0x30]
00007cd93bde0d57  vmovaps xmm4, [rsp+0x40]
00007cd93bde0d5d  vmovaps xmm5, [rsp+0x50]
00007cd93bde0d63  vmovaps xmm6, [rsp+0x60]
00007cd93bde0d69  vmovaps xmm7, [rsp+0x70]
00007cd93bde0d6f  vmovaps xmm8, [rsp+0x80]
00007cd93bde0d78  vmovaps xmm9, [rsp+0x90]
00007cd93bde0d81  vmovaps xmm11, [rsp+0xA0]
00007cd93bde0d8a  vmovaps xmm12, [rsp+0xB0]
00007cd93bde0d93  vmovaps xmm13, [rsp+0xC0]
00007cd93bde0d9c  vmovaps xmm14, [rsp+0xD0]
00007cd93bde0da5  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0dae  add rsp, 0xF0
00007cd93bde0db5  pop r11
00007cd93bde0db7  pop r10
00007cd93bde0db9  pop r9
00007cd93bde0dbb  pop r8
00007cd93bde0dbd  pop rsi
00007cd93bde0dbe  pop rdi
00007cd93bde0dbf  pop rdx
00007cd93bde0dc0  pop rcx
00007cd93bde0dc1  pop rax
00007cd93bde0dc2  add rsp, 0x08
00007cd93bde0dc6  jmp 0x00007CD93BDDC6CD
00007cd93bde0dcb  sub rsp, 0x08
00007cd93bde0dcf  push rax
00007cd93bde0dd0  push rcx
00007cd93bde0dd1  push rdx
00007cd93bde0dd2  push rdi
00007cd93bde0dd3  push rsi
00007cd93bde0dd4  push r8
00007cd93bde0dd6  push r9
00007cd93bde0dd8  push r10
00007cd93bde0dda  push r11
00007cd93bde0ddc  sub rsp, 0xF0
00007cd93bde0de3  vmovaps [rsp], xmm0
00007cd93bde0de8  vmovaps [rsp+0x10], xmm1
00007cd93bde0dee  vmovaps [rsp+0x20], xmm2
00007cd93bde0df4  vmovaps [rsp+0x30], xmm3
00007cd93bde0dfa  vmovaps [rsp+0x40], xmm4
00007cd93bde0e00  vmovaps [rsp+0x50], xmm5
00007cd93bde0e06  vmovaps [rsp+0x60], xmm6
00007cd93bde0e0c  vmovaps [rsp+0x70], xmm7
00007cd93bde0e12  vmovaps [rsp+0x80], xmm8
00007cd93bde0e1b  vmovaps [rsp+0x90], xmm9
00007cd93bde0e24  vmovaps [rsp+0xA0], xmm10
00007cd93bde0e2d  vmovaps [rsp+0xB0], xmm11
00007cd93bde0e36  vmovaps [rsp+0xC0], xmm13
00007cd93bde0e3f  vmovaps [rsp+0xD0], xmm14
00007cd93bde0e48  vmovaps [rsp+0xE0], xmm15
00007cd93bde0e51  sub rsp, 0x30
00007cd93bde0e55  movaps [rsp], xmm12
00007cd93bde0e5a  movaps [rsp+0x10], xmm14
00007cd93bde0e60  movaps [rsp+0x20], xmm1
00007cd93bde0e65  lea rdi, [rsp]
00007cd93bde0e69  mov esi, 0x00
00007cd93bde0e6e  mov rax, 0x64A581057530
00007cd93bde0e78  call rax
00007cd93bde0e7a  movaps xmm12, [rsp]
00007cd93bde0e7f  add rsp, 0x30
00007cd93bde0e83  vmovaps xmm0, [rsp]
00007cd93bde0e88  vmovaps xmm1, [rsp+0x10]
00007cd93bde0e8e  vmovaps xmm2, [rsp+0x20]
00007cd93bde0e94  vmovaps xmm3, [rsp+0x30]
00007cd93bde0e9a  vmovaps xmm4, [rsp+0x40]
00007cd93bde0ea0  vmovaps xmm5, [rsp+0x50]
00007cd93bde0ea6  vmovaps xmm6, [rsp+0x60]
00007cd93bde0eac  vmovaps xmm7, [rsp+0x70]
00007cd93bde0eb2  vmovaps xmm8, [rsp+0x80]
00007cd93bde0ebb  vmovaps xmm9, [rsp+0x90]
00007cd93bde0ec4  vmovaps xmm10, [rsp+0xA0]
00007cd93bde0ecd  vmovaps xmm11, [rsp+0xB0]
00007cd93bde0ed6  vmovaps xmm13, [rsp+0xC0]
00007cd93bde0edf  vmovaps xmm14, [rsp+0xD0]
00007cd93bde0ee8  vmovaps xmm15, [rsp+0xE0]
00007cd93bde0ef1  add rsp, 0xF0
00007cd93bde0ef8  pop r11
00007cd93bde0efa  pop r10
00007cd93bde0efc  pop r9
00007cd93bde0efe  pop r8
00007cd93bde0f00  pop rsi
00007cd93bde0f01  pop rdi
00007cd93bde0f02  pop rdx
00007cd93bde0f03  pop rcx
00007cd93bde0f04  pop rax
00007cd93bde0f05  add rsp, 0x08
00007cd93bde0f09  jmp 0x00007CD93BDDC6FC
00007cd93bde0f0e  sub rsp, 0x08
00007cd93bde0f12  push rax
00007cd93bde0f13  push rcx
00007cd93bde0f14  push rdx
00007cd93bde0f15  push rdi
00007cd93bde0f16  push rsi
00007cd93bde0f17  push r8
00007cd93bde0f19  push r9
00007cd93bde0f1b  push r10
00007cd93bde0f1d  push r11
00007cd93bde0f1f  sub rsp, 0xF0
00007cd93bde0f26  vmovaps [rsp], xmm0
00007cd93bde0f2b  vmovaps [rsp+0x10], xmm1
00007cd93bde0f31  vmovaps [rsp+0x20], xmm2
00007cd93bde0f37  vmovaps [rsp+0x30], xmm3
00007cd93bde0f3d  vmovaps [rsp+0x40], xmm4
00007cd93bde0f43  vmovaps [rsp+0x50], xmm5
00007cd93bde0f49  vmovaps [rsp+0x60], xmm6
00007cd93bde0f4f  vmovaps [rsp+0x70], xmm7
00007cd93bde0f55  vmovaps [rsp+0x80], xmm8
00007cd93bde0f5e  vmovaps [rsp+0x90], xmm9
00007cd93bde0f67  vmovaps [rsp+0xA0], xmm10
00007cd93bde0f70  vmovaps [rsp+0xB0], xmm11
00007cd93bde0f79  vmovaps [rsp+0xC0], xmm12
00007cd93bde0f82  vmovaps [rsp+0xD0], xmm13
00007cd93bde0f8b  vmovaps [rsp+0xE0], xmm15
00007cd93bde0f94  sub rsp, 0x30
00007cd93bde0f98  movaps [rsp], xmm14
00007cd93bde0f9d  movaps [rsp+0x10], xmm9
00007cd93bde0fa3  movaps [rsp+0x20], xmm1
00007cd93bde0fa8  lea rdi, [rsp]
00007cd93bde0fac  mov esi, 0x00
00007cd93bde0fb1  mov rax, 0x64A581057530
00007cd93bde0fbb  call rax
00007cd93bde0fbd  movaps xmm14, [rsp]
00007cd93bde0fc2  add rsp, 0x30
00007cd93bde0fc6  vmovaps xmm0, [rsp]
00007cd93bde0fcb  vmovaps xmm1, [rsp+0x10]
00007cd93bde0fd1  vmovaps xmm2, [rsp+0x20]
00007cd93bde0fd7  vmovaps xmm3, [rsp+0x30]
00007cd93bde0fdd  vmovaps xmm4, [rsp+0x40]
00007cd93bde0fe3  vmovaps xmm5, [rsp+0x50]
00007cd93bde0fe9  vmovaps xmm6, [rsp+0x60]
00007cd93bde0fef  vmovaps xmm7, [rsp+0x70]
00007cd93bde0ff5  vmovaps xmm8, [rsp+0x80]
00007cd93bde0ffe  vmovaps xmm9, [rsp+0x90]
00007cd93bde1007  vmovaps xmm10, [rsp+0xA0]
00007cd93bde1010  vmovaps xmm11, [rsp+0xB0]
00007cd93bde1019  vmovaps xmm12, [rsp+0xC0]
00007cd93bde1022  vmovaps xmm13, [rsp+0xD0]
00007cd93bde102b  vmovaps xmm15, [rsp+0xE0]
00007cd93bde1034  add rsp, 0xF0
00007cd93bde103b  pop r11
00007cd93bde103d  pop r10
00007cd93bde103f  pop r9
00007cd93bde1041  pop r8
00007cd93bde1043  pop rsi
00007cd93bde1044  pop rdi
00007cd93bde1045  pop rdx
00007cd93bde1046  pop rcx
00007cd93bde1047  pop rax
00007cd93bde1048  add rsp, 0x08
00007cd93bde104c  jmp 0x00007CD93BDDC72B
00007cd93bde1051  sub rsp, 0x08
00007cd93bde1055  push rax
00007cd93bde1056  push rcx
00007cd93bde1057  push rdx
00007cd93bde1058  push rdi
00007cd93bde1059  push rsi
00007cd93bde105a  push r8
00007cd93bde105c  push r9
00007cd93bde105e  push r10
00007cd93bde1060  push r11
00007cd93bde1062  sub rsp, 0xF0
00007cd93bde1069  vmovaps [rsp], xmm0
00007cd93bde106e  vmovaps [rsp+0x10], xmm2
00007cd93bde1074  vmovaps [rsp+0x20], xmm3
00007cd93bde107a  vmovaps [rsp+0x30], xmm4
00007cd93bde1080  vmovaps [rsp+0x40], xmm5
00007cd93bde1086  vmovaps [rsp+0x50], xmm6
00007cd93bde108c  vmovaps [rsp+0x60], xmm7
00007cd93bde1092  vmovaps [rsp+0x70], xmm8
00007cd93bde1098  vmovaps [rsp+0x80], xmm9
00007cd93bde10a1  vmovaps [rsp+0x90], xmm10
00007cd93bde10aa  vmovaps [rsp+0xA0], xmm11
00007cd93bde10b3  vmovaps [rsp+0xB0], xmm12
00007cd93bde10bc  vmovaps [rsp+0xC0], xmm13
00007cd93bde10c5  vmovaps [rsp+0xD0], xmm14
00007cd93bde10ce  vmovaps [rsp+0xE0], xmm15
00007cd93bde10d7  sub rsp, 0x30
00007cd93bde10db  movaps [rsp], xmm1
00007cd93bde10df  movaps [rsp+0x10], xmm13
00007cd93bde10e5  movaps [rsp+0x20], xmm8
00007cd93bde10eb  lea rdi, [rsp]
00007cd93bde10ef  mov esi, 0x00
00007cd93bde10f4  mov rax, 0x64A581057530
00007cd93bde10fe  call rax
00007cd93bde1100  movaps xmm1, [rsp]
00007cd93bde1104  add rsp, 0x30
00007cd93bde1108  vmovaps xmm0, [rsp]
00007cd93bde110d  vmovaps xmm2, [rsp+0x10]
00007cd93bde1113  vmovaps xmm3, [rsp+0x20]
00007cd93bde1119  vmovaps xmm4, [rsp+0x30]
00007cd93bde111f  vmovaps xmm5, [rsp+0x40]
00007cd93bde1125  vmovaps xmm6, [rsp+0x50]
00007cd93bde112b  vmovaps xmm7, [rsp+0x60]
00007cd93bde1131  vmovaps xmm8, [rsp+0x70]
00007cd93bde1137  vmovaps xmm9, [rsp+0x80]
00007cd93bde1140  vmovaps xmm10, [rsp+0x90]
00007cd93bde1149  vmovaps xmm11, [rsp+0xA0]
00007cd93bde1152  vmovaps xmm12, [rsp+0xB0]
00007cd93bde115b  vmovaps xmm13, [rsp+0xC0]
00007cd93bde1164  vmovaps xmm14, [rsp+0xD0]
00007cd93bde116d  vmovaps xmm15, [rsp+0xE0]
00007cd93bde1176  add rsp, 0xF0
00007cd93bde117d  pop r11
00007cd93bde117f  pop r10
00007cd93bde1181  pop r9
00007cd93bde1183  pop r8
00007cd93bde1185  pop rsi
00007cd93bde1186  pop rdi
00007cd93bde1187  pop rdx
00007cd93bde1188  pop rcx
00007cd93bde1189  pop rax
00007cd93bde118a  add rsp, 0x08
00007cd93bde118e  jmp 0x00007CD93BDDC74D
00007cd93bde1193  call 0x00007CD93BC0C260
00007cd93bde1198  jmp 0x00007CD93BDDC75B
00007cd93bde119d  call 0x00007CD93BCBD750
00007cd93bde11a2  jmp 0x00007CD93BDDC765
00007cd93bde11a7  sub rsp, 0x08
00007cd93bde11ab  push rax
00007cd93bde11ac  push rcx
00007cd93bde11ad  push rdx
00007cd93bde11ae  push rdi
00007cd93bde11af  push rsi
00007cd93bde11b0  push r8
00007cd93bde11b2  push r9
00007cd93bde11b4  push r10
00007cd93bde11b6  push r11
00007cd93bde11b8  sub rsp, 0xF0
00007cd93bde11bf  vmovaps [rsp], xmm0
00007cd93bde11c4  vmovaps [rsp+0x10], xmm1
00007cd93bde11ca  vmovaps [rsp+0x20], xmm2
00007cd93bde11d0  vmovaps [rsp+0x30], xmm3
00007cd93bde11d6  vmovaps [rsp+0x40], xmm4
00007cd93bde11dc  vmovaps [rsp+0x50], xmm5
00007cd93bde11e2  vmovaps [rsp+0x60], xmm6
00007cd93bde11e8  vmovaps [rsp+0x70], xmm7
00007cd93bde11ee  vmovaps [rsp+0x80], xmm9
00007cd93bde11f7  vmovaps [rsp+0x90], xmm10
00007cd93bde1200  vmovaps [rsp+0xA0], xmm11
00007cd93bde1209  vmovaps [rsp+0xB0], xmm12
00007cd93bde1212  vmovaps [rsp+0xC0], xmm13
00007cd93bde121b  vmovaps [rsp+0xD0], xmm14
00007cd93bde1224  vmovaps [rsp+0xE0], xmm15
00007cd93bde122d  sub rsp, 0x30
00007cd93bde1231  movaps [rsp], xmm8
00007cd93bde1236  movaps [rsp+0x10], xmm15
00007cd93bde123c  movaps [rsp+0x20], xmm7
00007cd93bde1241  lea rdi, [rsp]
00007cd93bde1245  mov esi, 0x00
00007cd93bde124a  mov rax, 0x64A581057530
00007cd93bde1254  call rax
00007cd93bde1256  movaps xmm8, [rsp]
00007cd93bde125b  add rsp, 0x30
00007cd93bde125f  vmovaps xmm0, [rsp]
00007cd93bde1264  vmovaps xmm1, [rsp+0x10]
00007cd93bde126a  vmovaps xmm2, [rsp+0x20]
00007cd93bde1270  vmovaps xmm3, [rsp+0x30]
00007cd93bde1276  vmovaps xmm4, [rsp+0x40]
00007cd93bde127c  vmovaps xmm5, [rsp+0x50]
00007cd93bde1282  vmovaps xmm6, [rsp+0x60]
00007cd93bde1288  vmovaps xmm7, [rsp+0x70]
00007cd93bde128e  vmovaps xmm9, [rsp+0x80]
00007cd93bde1297  vmovaps xmm10, [rsp+0x90]
00007cd93bde12a0  vmovaps xmm11, [rsp+0xA0]
00007cd93bde12a9  vmovaps xmm12, [rsp+0xB0]
00007cd93bde12b2  vmovaps xmm13, [rsp+0xC0]
00007cd93bde12bb  vmovaps xmm14, [rsp+0xD0]
00007cd93bde12c4  vmovaps xmm15, [rsp+0xE0]
00007cd93bde12cd  add rsp, 0xF0
00007cd93bde12d4  pop r11
00007cd93bde12d6  pop r10
00007cd93bde12d8  pop r9
00007cd93bde12da  pop r8
00007cd93bde12dc  pop rsi
00007cd93bde12dd  pop rdi
00007cd93bde12de  pop rdx
00007cd93bde12df  pop rcx
00007cd93bde12e0  pop rax
00007cd93bde12e1  add rsp, 0x08
00007cd93bde12e5  jmp 0x00007CD93BDDC787
00007cd93bde12ea  sub rsp, 0x08
00007cd93bde12ee  push rax
00007cd93bde12ef  push rcx
00007cd93bde12f0  push rdx
00007cd93bde12f1  push rdi
00007cd93bde12f2  push rsi
00007cd93bde12f3  push r8
00007cd93bde12f5  push r9
00007cd93bde12f7  push r10
00007cd93bde12f9  push r11
00007cd93bde12fb  sub rsp, 0xF0
00007cd93bde1302  vmovaps [rsp], xmm0
00007cd93bde1307  vmovaps [rsp+0x10], xmm1
00007cd93bde130d  vmovaps [rsp+0x20], xmm2
00007cd93bde1313  vmovaps [rsp+0x30], xmm3
00007cd93bde1319  vmovaps [rsp+0x40], xmm4
00007cd93bde131f  vmovaps [rsp+0x50], xmm5
00007cd93bde1325  vmovaps [rsp+0x60], xmm6
00007cd93bde132b  vmovaps [rsp+0x70], xmm8
00007cd93bde1331  vmovaps [rsp+0x80], xmm9
00007cd93bde133a  vmovaps [rsp+0x90], xmm10
00007cd93bde1343  vmovaps [rsp+0xA0], xmm11
00007cd93bde134c  vmovaps [rsp+0xB0], xmm12
00007cd93bde1355  vmovaps [rsp+0xC0], xmm13
00007cd93bde135e  vmovaps [rsp+0xD0], xmm14
00007cd93bde1367  vmovaps [rsp+0xE0], xmm15
00007cd93bde1370  sub rsp, 0x30
00007cd93bde1374  movaps [rsp], xmm7
00007cd93bde1378  movaps [rsp+0x10], xmm9
00007cd93bde137e  movaps [rsp+0x20], xmm15
00007cd93bde1384  lea rdi, [rsp]
00007cd93bde1388  mov esi, 0x00
00007cd93bde138d  mov rax, 0x64A581057530
00007cd93bde1397  call rax
00007cd93bde1399  movaps xmm7, [rsp]
00007cd93bde139d  add rsp, 0x30
00007cd93bde13a1  vmovaps xmm0, [rsp]
00007cd93bde13a6  vmovaps xmm1, [rsp+0x10]
00007cd93bde13ac  vmovaps xmm2, [rsp+0x20]
00007cd93bde13b2  vmovaps xmm3, [rsp+0x30]
00007cd93bde13b8  vmovaps xmm4, [rsp+0x40]
00007cd93bde13be  vmovaps xmm5, [rsp+0x50]
00007cd93bde13c4  vmovaps xmm6, [rsp+0x60]
00007cd93bde13ca  vmovaps xmm8, [rsp+0x70]
00007cd93bde13d0  vmovaps xmm9, [rsp+0x80]
00007cd93bde13d9  vmovaps xmm10, [rsp+0x90]
00007cd93bde13e2  vmovaps xmm11, [rsp+0xA0]
00007cd93bde13eb  vmovaps xmm12, [rsp+0xB0]
00007cd93bde13f4  vmovaps xmm13, [rsp+0xC0]
00007cd93bde13fd  vmovaps xmm14, [rsp+0xD0]
00007cd93bde1406  vmovaps xmm15, [rsp+0xE0]
00007cd93bde140f  add rsp, 0xF0
00007cd93bde1416  pop r11
00007cd93bde1418  pop r10
00007cd93bde141a  pop r9
00007cd93bde141c  pop r8
00007cd93bde141e  pop rsi
00007cd93bde141f  pop rdi
00007cd93bde1420  pop rdx
00007cd93bde1421  pop rcx
00007cd93bde1422  pop rax
00007cd93bde1423  add rsp, 0x08
00007cd93bde1427  jmp 0x00007CD93BDDC7B4
00007cd93bde142c  sub rsp, 0x08
00007cd93bde1430  push rax
00007cd93bde1431  push rcx
00007cd93bde1432  push rdx
00007cd93bde1433  push rdi
00007cd93bde1434  push rsi
00007cd93bde1435  push r8
00007cd93bde1437  push r9
00007cd93bde1439  push r10
00007cd93bde143b  push r11
00007cd93bde143d  sub rsp, 0xF0
00007cd93bde1444  vmovaps [rsp], xmm0
00007cd93bde1449  vmovaps [rsp+0x10], xmm1
00007cd93bde144f  vmovaps [rsp+0x20], xmm2
00007cd93bde1455  vmovaps [rsp+0x30], xmm3
00007cd93bde145b  vmovaps [rsp+0x40], xmm4
00007cd93bde1461  vmovaps [rsp+0x50], xmm5
00007cd93bde1467  vmovaps [rsp+0x60], xmm6
00007cd93bde146d  vmovaps [rsp+0x70], xmm7
00007cd93bde1473  vmovaps [rsp+0x80], xmm8
00007cd93bde147c  vmovaps [rsp+0x90], xmm10
00007cd93bde1485  vmovaps [rsp+0xA0], xmm11
00007cd93bde148e  vmovaps [rsp+0xB0], xmm12
00007cd93bde1497  vmovaps [rsp+0xC0], xmm13
00007cd93bde14a0  vmovaps [rsp+0xD0], xmm14
00007cd93bde14a9  vmovaps [rsp+0xE0], xmm15
00007cd93bde14b2  sub rsp, 0x30
00007cd93bde14b6  movaps [rsp], xmm9
00007cd93bde14bb  movaps [rsp+0x10], xmm13
00007cd93bde14c1  movaps [rsp+0x20], xmm15
00007cd93bde14c7  lea rdi, [rsp]
00007cd93bde14cb  mov esi, 0x00
00007cd93bde14d0  mov rax, 0x64A581057530
00007cd93bde14da  call rax
00007cd93bde14dc  movaps xmm9, [rsp]
00007cd93bde14e1  add rsp, 0x30
00007cd93bde14e5  vmovaps xmm0, [rsp]
00007cd93bde14ea  vmovaps xmm1, [rsp+0x10]
00007cd93bde14f0  vmovaps xmm2, [rsp+0x20]
00007cd93bde14f6  vmovaps xmm3, [rsp+0x30]
00007cd93bde14fc  vmovaps xmm4, [rsp+0x40]
00007cd93bde1502  vmovaps xmm5, [rsp+0x50]
00007cd93bde1508  vmovaps xmm6, [rsp+0x60]
00007cd93bde150e  vmovaps xmm7, [rsp+0x70]
00007cd93bde1514  vmovaps xmm8, [rsp+0x80]
00007cd93bde151d  vmovaps xmm10, [rsp+0x90]
00007cd93bde1526  vmovaps xmm11, [rsp+0xA0]
00007cd93bde152f  vmovaps xmm12, [rsp+0xB0]
00007cd93bde1538  vmovaps xmm13, [rsp+0xC0]
00007cd93bde1541  vmovaps xmm14, [rsp+0xD0]
00007cd93bde154a  vmovaps xmm15, [rsp+0xE0]
00007cd93bde1553  add rsp, 0xF0
00007cd93bde155a  pop r11
00007cd93bde155c  pop r10
00007cd93bde155e  pop r9
00007cd93bde1560  pop r8
00007cd93bde1562  pop rsi
00007cd93bde1563  pop rdi
00007cd93bde1564  pop rdx
00007cd93bde1565  pop rcx
00007cd93bde1566  pop rax
00007cd93bde1567  add rsp, 0x08
00007cd93bde156b  jmp 0x00007CD93BDDC7E2
00007cd93bde1570  sub rsp, 0x08
00007cd93bde1574  push rax
00007cd93bde1575  push rcx
00007cd93bde1576  push rdx
00007cd93bde1577  push rdi
00007cd93bde1578  push rsi
00007cd93bde1579  push r8
00007cd93bde157b  push r9
00007cd93bde157d  push r10
00007cd93bde157f  push r11
00007cd93bde1581  sub rsp, 0xF0
00007cd93bde1588  vmovaps [rsp], xmm0
00007cd93bde158d  vmovaps [rsp+0x10], xmm1
00007cd93bde1593  vmovaps [rsp+0x20], xmm2
00007cd93bde1599  vmovaps [rsp+0x30], xmm3
00007cd93bde159f  vmovaps [rsp+0x40], xmm4
00007cd93bde15a5  vmovaps [rsp+0x50], xmm5
00007cd93bde15ab  vmovaps [rsp+0x60], xmm6
00007cd93bde15b1  vmovaps [rsp+0x70], xmm7
00007cd93bde15b7  vmovaps [rsp+0x80], xmm8
00007cd93bde15c0  vmovaps [rsp+0x90], xmm9
00007cd93bde15c9  vmovaps [rsp+0xA0], xmm10
00007cd93bde15d2  vmovaps [rsp+0xB0], xmm11
00007cd93bde15db  vmovaps [rsp+0xC0], xmm12
00007cd93bde15e4  vmovaps [rsp+0xD0], xmm13
00007cd93bde15ed  vmovaps [rsp+0xE0], xmm14
00007cd93bde15f6  sub rsp, 0x30
00007cd93bde15fa  movaps [rsp], xmm15
00007cd93bde15ff  movaps [rsp+0x10], xmm11
00007cd93bde1605  movaps [rsp+0x20], xmm12
00007cd93bde160b  lea rdi, [rsp]
00007cd93bde160f  mov esi, 0x00
00007cd93bde1614  mov rax, 0x64A581057530
00007cd93bde161e  call rax
00007cd93bde1620  movaps xmm15, [rsp]
00007cd93bde1625  add rsp, 0x30
00007cd93bde1629  vmovaps xmm0, [rsp]
00007cd93bde162e  vmovaps xmm1, [rsp+0x10]
00007cd93bde1634  vmovaps xmm2, [rsp+0x20]
00007cd93bde163a  vmovaps xmm3, [rsp+0x30]
00007cd93bde1640  vmovaps xmm4, [rsp+0x40]
00007cd93bde1646  vmovaps xmm5, [rsp+0x50]
00007cd93bde164c  vmovaps xmm6, [rsp+0x60]
00007cd93bde1652  vmovaps xmm7, [rsp+0x70]
00007cd93bde1658  vmovaps xmm8, [rsp+0x80]
00007cd93bde1661  vmovaps xmm9, [rsp+0x90]
00007cd93bde166a  vmovaps xmm10, [rsp+0xA0]
00007cd93bde1673  vmovaps xmm11, [rsp+0xB0]
00007cd93bde167c  vmovaps xmm12, [rsp+0xC0]
00007cd93bde1685  vmovaps xmm13, [rsp+0xD0]
00007cd93bde168e  vmovaps xmm14, [rsp+0xE0]
00007cd93bde1697  add rsp, 0xF0
00007cd93bde169e  pop r11
00007cd93bde16a0  pop r10
00007cd93bde16a2  pop r9
00007cd93bde16a4  pop r8
00007cd93bde16a6  pop rsi
00007cd93bde16a7  pop rdi
00007cd93bde16a8  pop rdx
00007cd93bde16a9  pop rcx
00007cd93bde16aa  pop rax
00007cd93bde16ab  add rsp, 0x08
00007cd93bde16af  jmp 0x00007CD93BDDC7FD
00007cd93bde16b4  sub rsp, 0x08
00007cd93bde16b8  push rax
00007cd93bde16b9  push rcx
00007cd93bde16ba  push rdx
00007cd93bde16bb  push rdi
00007cd93bde16bc  push rsi
00007cd93bde16bd  push r8
00007cd93bde16bf  push r9
00007cd93bde16c1  push r10
00007cd93bde16c3  push r11
00007cd93bde16c5  sub rsp, 0xF0
00007cd93bde16cc  vmovaps [rsp], xmm0
00007cd93bde16d1  vmovaps [rsp+0x10], xmm1
00007cd93bde16d7  vmovaps [rsp+0x20], xmm2
00007cd93bde16dd  vmovaps [rsp+0x30], xmm3
00007cd93bde16e3  vmovaps [rsp+0x40], xmm4
00007cd93bde16e9  vmovaps [rsp+0x50], xmm5
00007cd93bde16ef  vmovaps [rsp+0x60], xmm6
00007cd93bde16f5  vmovaps [rsp+0x70], xmm7
00007cd93bde16fb  vmovaps [rsp+0x80], xmm8
00007cd93bde1704  vmovaps [rsp+0x90], xmm9
00007cd93bde170d  vmovaps [rsp+0xA0], xmm10
00007cd93bde1716  vmovaps [rsp+0xB0], xmm11
00007cd93bde171f  vmovaps [rsp+0xC0], xmm12
00007cd93bde1728  vmovaps [rsp+0xD0], xmm14
00007cd93bde1731  vmovaps [rsp+0xE0], xmm15
00007cd93bde173a  sub rsp, 0x30
00007cd93bde173e  movaps [rsp], xmm13
00007cd93bde1743  movaps [rsp+0x10], xmm10
00007cd93bde1749  movaps [rsp+0x20], xmm14
00007cd93bde174f  lea rdi, [rsp]
00007cd93bde1753  mov esi, 0x00
00007cd93bde1758  mov rax, 0x64A581057530
00007cd93bde1762  call rax
00007cd93bde1764  movaps xmm13, [rsp]
00007cd93bde1769  add rsp, 0x30
00007cd93bde176d  vmovaps xmm0, [rsp]
00007cd93bde1772  vmovaps xmm1, [rsp+0x10]
00007cd93bde1778  vmovaps xmm2, [rsp+0x20]
00007cd93bde177e  vmovaps xmm3, [rsp+0x30]
00007cd93bde1784  vmovaps xmm4, [rsp+0x40]
00007cd93bde178a  vmovaps xmm5, [rsp+0x50]
00007cd93bde1790  vmovaps xmm6, [rsp+0x60]
00007cd93bde1796  vmovaps xmm7, [rsp+0x70]
00007cd93bde179c  vmovaps xmm8, [rsp+0x80]
00007cd93bde17a5  vmovaps xmm9, [rsp+0x90]
00007cd93bde17ae  vmovaps xmm10, [rsp+0xA0]
00007cd93bde17b7  vmovaps xmm11, [rsp+0xB0]
00007cd93bde17c0  vmovaps xmm12, [rsp+0xC0]
00007cd93bde17c9  vmovaps xmm14, [rsp+0xD0]
00007cd93bde17d2  vmovaps xmm15, [rsp+0xE0]
00007cd93bde17db  add rsp, 0xF0
00007cd93bde17e2  pop r11
00007cd93bde17e4  pop r10
00007cd93bde17e6  pop r9
00007cd93bde17e8  pop r8
00007cd93bde17ea  pop rsi
00007cd93bde17eb  pop rdi
00007cd93bde17ec  pop rdx
00007cd93bde17ed  pop rcx
00007cd93bde17ee  pop rax
00007cd93bde17ef  add rsp, 0x08
00007cd93bde17f3  jmp 0x00007CD93BDDC820
00007cd93bde17f8  sub rsp, 0x08
00007cd93bde17fc  push rax
00007cd93bde17fd  push rcx
00007cd93bde17fe  push rdx
00007cd93bde17ff  push rdi
00007cd93bde1800  push rsi
00007cd93bde1801  push r8
00007cd93bde1803  push r9
00007cd93bde1805  push r10
00007cd93bde1807  push r11
00007cd93bde1809  sub rsp, 0xF0
00007cd93bde1810  vmovaps [rsp], xmm0
00007cd93bde1815  vmovaps [rsp+0x10], xmm1
00007cd93bde181b  vmovaps [rsp+0x20], xmm2
00007cd93bde1821  vmovaps [rsp+0x30], xmm3
00007cd93bde1827  vmovaps [rsp+0x40], xmm4
00007cd93bde182d  vmovaps [rsp+0x50], xmm5
00007cd93bde1833  vmovaps [rsp+0x60], xmm6
00007cd93bde1839  vmovaps [rsp+0x70], xmm7
00007cd93bde183f  vmovaps [rsp+0x80], xmm8
00007cd93bde1848  vmovaps [rsp+0x90], xmm9
00007cd93bde1851  vmovaps [rsp+0xA0], xmm10
00007cd93bde185a  vmovaps [rsp+0xB0], xmm11
00007cd93bde1863  vmovaps [rsp+0xC0], xmm12
00007cd93bde186c  vmovaps [rsp+0xD0], xmm13
00007cd93bde1875  vmovaps [rsp+0xE0], xmm15
00007cd93bde187e  sub rsp, 0x30
00007cd93bde1882  movaps [rsp], xmm14
00007cd93bde1887  movaps [rsp+0x10], xmm1
00007cd93bde188c  movaps [rsp+0x20], xmm7
00007cd93bde1891  lea rdi, [rsp]
00007cd93bde1895  mov esi, 0x00
00007cd93bde189a  mov rax, 0x64A581057530
00007cd93bde18a4  call rax
00007cd93bde18a6  movaps xmm14, [rsp]
00007cd93bde18ab  add rsp, 0x30
00007cd93bde18af  vmovaps xmm0, [rsp]
00007cd93bde18b4  vmovaps xmm1, [rsp+0x10]
00007cd93bde18ba  vmovaps xmm2, [rsp+0x20]
00007cd93bde18c0  vmovaps xmm3, [rsp+0x30]
00007cd93bde18c6  vmovaps xmm4, [rsp+0x40]
00007cd93bde18cc  vmovaps xmm5, [rsp+0x50]
00007cd93bde18d2  vmovaps xmm6, [rsp+0x60]
00007cd93bde18d8  vmovaps xmm7, [rsp+0x70]
00007cd93bde18de  vmovaps xmm8, [rsp+0x80]
00007cd93bde18e7  vmovaps xmm9, [rsp+0x90]
00007cd93bde18f0  vmovaps xmm10, [rsp+0xA0]
00007cd93bde18f9  vmovaps xmm11, [rsp+0xB0]
00007cd93bde1902  vmovaps xmm12, [rsp+0xC0]
00007cd93bde190b  vmovaps xmm13, [rsp+0xD0]
00007cd93bde1914  vmovaps xmm15, [rsp+0xE0]
00007cd93bde191d  add rsp, 0xF0
00007cd93bde1924  pop r11
00007cd93bde1926  pop r10
00007cd93bde1928  pop r9
00007cd93bde192a  pop r8
00007cd93bde192c  pop rsi
00007cd93bde192d  pop rdi
00007cd93bde192e  pop rdx
00007cd93bde192f  pop rcx
00007cd93bde1930  pop rax
00007cd93bde1931  add rsp, 0x08
00007cd93bde1935  jmp 0x00007CD93BDDC843
00007cd93bde193a  sub rsp, 0x08
00007cd93bde193e  push rax
00007cd93bde193f  push rcx
00007cd93bde1940  push rdx
00007cd93bde1941  push rdi
00007cd93bde1942  push rsi
00007cd93bde1943  push r8
00007cd93bde1945  push r9
00007cd93bde1947  push r10
00007cd93bde1949  push r11
00007cd93bde194b  sub rsp, 0xF0
00007cd93bde1952  vmovaps [rsp], xmm0
00007cd93bde1957  vmovaps [rsp+0x10], xmm2
00007cd93bde195d  vmovaps [rsp+0x20], xmm3
00007cd93bde1963  vmovaps [rsp+0x30], xmm4
00007cd93bde1969  vmovaps [rsp+0x40], xmm5
00007cd93bde196f  vmovaps [rsp+0x50], xmm6
00007cd93bde1975  vmovaps [rsp+0x60], xmm7
00007cd93bde197b  vmovaps [rsp+0x70], xmm8
00007cd93bde1981  vmovaps [rsp+0x80], xmm9
00007cd93bde198a  vmovaps [rsp+0x90], xmm10
00007cd93bde1993  vmovaps [rsp+0xA0], xmm11
00007cd93bde199c  vmovaps [rsp+0xB0], xmm12
00007cd93bde19a5  vmovaps [rsp+0xC0], xmm13
00007cd93bde19ae  vmovaps [rsp+0xD0], xmm14
00007cd93bde19b7  vmovaps [rsp+0xE0], xmm15
00007cd93bde19c0  sub rsp, 0x30
00007cd93bde19c4  movaps [rsp], xmm1
00007cd93bde19c8  movaps [rsp+0x10], xmm8
00007cd93bde19ce  movaps [rsp+0x20], xmm9
00007cd93bde19d4  lea rdi, [rsp]
00007cd93bde19d8  mov esi, 0x00
00007cd93bde19dd  mov rax, 0x64A581057530
00007cd93bde19e7  call rax
00007cd93bde19e9  movaps xmm1, [rsp]
00007cd93bde19ed  add rsp, 0x30
00007cd93bde19f1  vmovaps xmm0, [rsp]
00007cd93bde19f6  vmovaps xmm2, [rsp+0x10]
00007cd93bde19fc  vmovaps xmm3, [rsp+0x20]
00007cd93bde1a02  vmovaps xmm4, [rsp+0x30]
00007cd93bde1a08  vmovaps xmm5, [rsp+0x40]
00007cd93bde1a0e  vmovaps xmm6, [rsp+0x50]
00007cd93bde1a14  vmovaps xmm7, [rsp+0x60]
00007cd93bde1a1a  vmovaps xmm8, [rsp+0x70]
00007cd93bde1a20  vmovaps xmm9, [rsp+0x80]
00007cd93bde1a29  vmovaps xmm10, [rsp+0x90]
00007cd93bde1a32  vmovaps xmm11, [rsp+0xA0]
00007cd93bde1a3b  vmovaps xmm12, [rsp+0xB0]
00007cd93bde1a44  vmovaps xmm13, [rsp+0xC0]
00007cd93bde1a4d  vmovaps xmm14, [rsp+0xD0]
00007cd93bde1a56  vmovaps xmm15, [rsp+0xE0]
00007cd93bde1a5f  add rsp, 0xF0
00007cd93bde1a66  pop r11
00007cd93bde1a68  pop r10
00007cd93bde1a6a  pop r9
00007cd93bde1a6c  pop r8
00007cd93bde1a6e  pop rsi
00007cd93bde1a6f  pop rdi
00007cd93bde1a70  pop rdx
00007cd93bde1a71  pop rcx
00007cd93bde1a72  pop rax
00007cd93bde1a73  add rsp, 0x08
00007cd93bde1a77  jmp 0x00007CD93BDDC865
00007cd93bde1a7c  call 0x00007CD93BCE5940
00007cd93bde1a81  jmp 0x00007CD93BDDC873
00007cd93bde1a86  call 0x00007CD93BC0C380
00007cd93bde1a8b  jmp 0x00007CD93BDDC87D
00007cd93bde1a90  call 0x00007CD93BC0D600
00007cd93bde1a95  jmp 0x00007CD93BDDC887
00007cd93bde1a9a  call 0x00007CD93BBFF540
00007cd93bde1a9f  jmp 0x00007CD93BDDC891
00007cd93bde1aa4  int3
00007cd93bde1aa5  nop [rax+rax*1], ax
00007cd93bde1aae  nop
00007cd93bde1ab0  mov rax, [r15+0xF8]
00007cd93bde1ab7  lea r14, [rax+0x140]
00007cd93bde1abe  mov r12, [r13+r14*1]
00007cd93bde1ac3  mov [r15+0xE8], r12
00007cd93bde1aca  lea r14, [rax+0x130]
00007cd93bde1ad1  mov r12, [r13+r14*1]
00007cd93bde1ad6  lea r14, [rax+0x138]
00007cd93bde1add  mov r11, [r13+r14*1]
00007cd93bde1ae2  movq xmm1, r12
00007cd93bde1ae7  movq xmm15, r11
00007cd93bde1aec  movq xmm1, xmm1
00007cd93bde1af0  movq xmm1, xmm1
00007cd93bde1af4  movaps [r15+0x1A0], xmm1
00007cd93bde1afc  movq xmm15, xmm15
00007cd93bde1b01  movq xmm15, xmm15
00007cd93bde1b06  movaps [r15+0x190], xmm15
00007cd93bde1b0e  lea r14, [rax+0x120]
00007cd93bde1b15  mov r12, [r13+r14*1]
00007cd93bde1b1a  lea r14, [rax+0x128]
00007cd93bde1b21  mov r11, [r13+r14*1]
00007cd93bde1b26  movq xmm1, r12
00007cd93bde1b2b  movq xmm15, r11
00007cd93bde1b30  movq xmm1, xmm1
00007cd93bde1b34  movq xmm1, xmm1
00007cd93bde1b38  movaps [r15+0x1C0], xmm1
00007cd93bde1b40  movq xmm15, xmm15
00007cd93bde1b45  movq xmm15, xmm15
00007cd93bde1b4a  movaps [r15+0x1B0], xmm15
00007cd93bde1b52  lea r14, [rax+0x110]
00007cd93bde1b59  mov r12, [r13+r14*1]
00007cd93bde1b5e  lea r14, [rax+0x118]
00007cd93bde1b65  mov r11, [r13+r14*1]
00007cd93bde1b6a  movq xmm1, r12
00007cd93bde1b6f  movq xmm15, r11
00007cd93bde1b74  movq xmm1, xmm1
00007cd93bde1b78  movq xmm1, xmm1
00007cd93bde1b7c  movaps [r15+0x1E0], xmm1
00007cd93bde1b84  movq xmm15, xmm15
00007cd93bde1b89  movq xmm15, xmm15
00007cd93bde1b8e  movaps [r15+0x1D0], xmm15
00007cd93bde1b96  lea r14, [rax+0x100]
00007cd93bde1b9d  mov r12, [r13+r14*1]
00007cd93bde1ba2  lea r14, [rax+0x108]
00007cd93bde1ba9  mov r11, [r13+r14*1]
00007cd93bde1bae  movq xmm1, r12
00007cd93bde1bb3  movq xmm15, r11
00007cd93bde1bb8  movq xmm1, xmm1
00007cd93bde1bbc  movq xmm1, xmm1
00007cd93bde1bc0  movaps [r15+0x200], xmm1
00007cd93bde1bc8  movq xmm15, xmm15
00007cd93bde1bcd  movq xmm15, xmm15
00007cd93bde1bd2  movaps [r15+0x1F0], xmm15
00007cd93bde1bda  mov qword ptr [r15+0x40], 0x430000
00007cd93bde1be2  mov r14d, 0x430510
00007cd93bde1be8  mov r12, [r13+r14*1]
00007cd93bde1bed  movq xmm1, r12
00007cd93bde1bf2  lea r14, [rax+0x150]
00007cd93bde1bf9  mov [r15+0xF8], r14
00007cd93bde1c00  mov rax, [r15+0x50]
00007cd93bde1c04  movups xmm15, [r13+rax*1]
00007cd93bde1c0a  movaps [r15+0x120], xmm15
00007cd93bde1c12  mov qword ptr [r15+0x48], 0x10
00007cd93bde1c1a  xor eax, eax
00007cd93bde1c1c  mov r14d, 0x10
00007cd93bde1c22  mov r12d, 0x200
00007cd93bde1c28  cmp r14, r12
00007cd93bde1c2b  cmc
00007cd93bde1c2c  lahf
00007cd93bde1c2d  seto al
00007cd93bde1c30  mov [r15+0x108], eax
00007cd93bde1c37  pextrq rax, xmm15, 0x01
00007cd93bde1c3e  movq xmm14, rax
00007cd93bde1c43  movaps [r15+0x130], xmm14
00007cd93bde1c4b  movq rax, xmm1
00007cd93bde1c50  movq r14, xmm15
00007cd93bde1c55  vmovq xmm1, rax
00007cd93bde1c5a  vmovq xmm15, r14
00007cd93bde1c5f  movaps xmm13, xmm1
00007cd93bde1c63  addsd xmm13, xmm15
00007cd93bde1c68  ucomisd xmm13, xmm13
00007cd93bde1c6d  jp 0x00007CD93BDE1D86
00007cd93bde1c73  movq xmm13, xmm13
00007cd93bde1c78  movq rax, xmm13
00007cd93bde1c7d  movq r14, xmm14
00007cd93bde1c82  vmovq xmm1, rax
00007cd93bde1c87  vmovq xmm15, r14
00007cd93bde1c8c  movaps xmm14, xmm1
00007cd93bde1c90  addsd xmm14, xmm15
00007cd93bde1c95  ucomisd xmm14, xmm14
00007cd93bde1c9a  jp 0x00007CD93BDE1DCE
00007cd93bde1ca0  movq xmm14, xmm14
00007cd93bde1ca5  movaps [r15+0x110], xmm14
00007cd93bde1cad  mov eax, [r15+0x108]
00007cd93bde1cb4  sahf
00007cd93bde1cb5  jnz 0x00007CD93BDE1CE7
00007cd93bde1cb7  cmp dword ptr [r15+0x318], 0x00
00007cd93bde1cbf  jz 0x00007CD93BDE1FE0
00007cd93bde1cc5  nop [rax+rax*1], ax
00007cd93bde1cce  nop [rax+rax*1], eax
00007cd93bde1cd6  mov eax, 0x410490
00007cd93bde1cdb  mov [r15+0x100], rax
00007cd93bde1ce2  jmp 0x00007CD93BBFE110
00007cd93bde1ce7  cmp dword ptr [r15+0x318], 0x00
00007cd93bde1cef  jz 0x00007CD93BDE1E20
00007cd93bde1cf5  nop [rax+rax*1], ax
00007cd93bde1cfe  nop [rax+rax*1], eax
00007cd93bde1d06  mov eax, 0x410474
00007cd93bde1d0b  mov [r15+0x100], rax
00007cd93bde1d12  jmp 0x00007CD93BBFE110
00007cd93bde1d17  int3
00007cd93bde1d18  call 0x00007CD93BCE27E0
00007cd93bde1d1d  jmp 0x00007CD93BDE1AC3
00007cd93bde1d22  call 0x00007CD93BCE27E0
00007cd93bde1d27  jmp 0x00007CD93BDE1AD6
00007cd93bde1d2c  call 0x00007CD93BCE1570
00007cd93bde1d31  jmp 0x00007CD93BDE1AE2
00007cd93bde1d36  call 0x00007CD93BCE27E0
00007cd93bde1d3b  jmp 0x00007CD93BDE1B1A
00007cd93bde1d40  call 0x00007CD93BCE1570
00007cd93bde1d45  jmp 0x00007CD93BDE1B26
00007cd93bde1d4a  call 0x00007CD93BCE27E0
00007cd93bde1d4f  jmp 0x00007CD93BDE1B5E
00007cd93bde1d54  call 0x00007CD93BCE1570
00007cd93bde1d59  jmp 0x00007CD93BDE1B6A
00007cd93bde1d5e  call 0x00007CD93BCE27E0
00007cd93bde1d63  jmp 0x00007CD93BDE1BA2
00007cd93bde1d68  call 0x00007CD93BCE1570
00007cd93bde1d6d  jmp 0x00007CD93BDE1BAE
00007cd93bde1d72  call 0x00007CD93BCE27E0
00007cd93bde1d77  jmp 0x00007CD93BDE1BED
00007cd93bde1d7c  call 0x00007CD93BC0E760
00007cd93bde1d81  jmp 0x00007CD93BDE1C0A
00007cd93bde1d86  ucomisd xmm1, xmm15
00007cd93bde1d8b  jp 0x00007CD93BDE1D9A
00007cd93bde1d8d  movaps xmm13, [0x00007CD93B9FE060]
00007cd93bde1d95  jmp 0x00007CD93BDE1C73
00007cd93bde1d9a  vxorps xmm0, xmm1, xmm15
00007cd93bde1d9f  pextrw eax, xmm0, 0x03
00007cd93bde1da4  and eax, 0x7FF8
00007cd93bde1da9  cmp eax, 0x08
00007cd93bde1dac  jnz 0x00007CD93BDE1C73
00007cd93bde1db2  movq rax, xmm15
00007cd93bde1db7  shl rax, 0x0D
00007cd93bde1dbb  jbe 0x00007CD93BDE1C73
00007cd93bde1dc1  vorps xmm13, xmm15, [0x00007CD93B9FE070]
00007cd93bde1dc9  jmp 0x00007CD93BDE1C73
00007cd93bde1dce  ucomisd xmm1, xmm15
00007cd93bde1dd3  jp 0x00007CD93BDE1DE2
00007cd93bde1dd5  movaps xmm14, [0x00007CD93B9FE060]
00007cd93bde1ddd  jmp 0x00007CD93BDE1CA0
00007cd93bde1de2  vxorps xmm0, xmm1, xmm15
00007cd93bde1de7  pextrw eax, xmm0, 0x03
00007cd93bde1dec  and eax, 0x7FF8
00007cd93bde1df1  cmp eax, 0x08
00007cd93bde1df4  jnz 0x00007CD93BDE1CA0
00007cd93bde1dfa  movq rax, xmm15
00007cd93bde1dff  shl rax, 0x0D
00007cd93bde1e03  jbe 0x00007CD93BDE1CA0
00007cd93bde1e09  vorps xmm14, xmm15, [0x00007CD93B9FE070]
00007cd93bde1e11  jmp 0x00007CD93BDE1CA0
00007cd93bde1e16  int3
00007cd93bde1e17  nop [rax+rax*1], ax
00007cd93bde1e20  mov rax, [r15+0x48]
00007cd93bde1e24  mov r14, [r15+0x50]
00007cd93bde1e28  lea r12, [r14+rax*1]
00007cd93bde1e2c  movups xmm1, [r13+r12*1]
00007cd93bde1e32  movaps [r15+0x120], xmm1
00007cd93bde1e3a  lea r14, [rax+0x10]
00007cd93bde1e3e  mov [r15+0x48], r14
00007cd93bde1e42  xor eax, eax
00007cd93bde1e44  mov r12d, 0x200
00007cd93bde1e4a  cmp r14, r12
00007cd93bde1e4d  cmc
00007cd93bde1e4e  lahf
00007cd93bde1e4f  seto al
00007cd93bde1e52  mov [r15+0x108], eax
00007cd93bde1e59  pextrq rax, xmm1, 0x01
00007cd93bde1e60  movq xmm15, rax
00007cd93bde1e65  movaps [r15+0x130], xmm15
00007cd93bde1e6d  movaps xmm14, [r15+0x110]
00007cd93bde1e75  movq rax, xmm14
00007cd93bde1e7a  movq r14, xmm1
00007cd93bde1e7f  vmovq xmm1, rax
00007cd93bde1e84  vmovq xmm14, r14
00007cd93bde1e89  movaps xmm13, xmm1
00007cd93bde1e8d  addsd xmm13, xmm14
00007cd93bde1e92  ucomisd xmm13, xmm13
00007cd93bde1e97  jp 0x00007CD93BDE1F4C
00007cd93bde1e9d  movq xmm13, xmm13
00007cd93bde1ea2  movq rax, xmm13
00007cd93bde1ea7  movq r14, xmm15
00007cd93bde1eac  vmovq xmm1, rax
00007cd93bde1eb1  vmovq xmm15, r14
00007cd93bde1eb6  movaps xmm14, xmm1
00007cd93bde1eba  addsd xmm14, xmm15
00007cd93bde1ebf  ucomisd xmm14, xmm14
00007cd93bde1ec4  jp 0x00007CD93BDE1F94
00007cd93bde1eca  movq xmm14, xmm14
00007cd93bde1ecf  movaps [r15+0x110], xmm14
00007cd93bde1ed7  mov eax, [r15+0x108]
00007cd93bde1ede  sahf
00007cd93bde1edf  jnz 0x00007CD93BDE1F11
00007cd93bde1ee1  cmp dword ptr [r15+0x318], 0x00
00007cd93bde1ee9  jz 0x00007CD93BDE1FE0
00007cd93bde1eef  nop [rax+rax*1], ax
00007cd93bde1ef8  nop [rax+rax*1], eax
00007cd93bde1f00  mov eax, 0x410490
00007cd93bde1f05  mov [r15+0x100], rax
00007cd93bde1f0c  jmp 0x00007CD93BBFE110
00007cd93bde1f11  cmp dword ptr [r15+0x318], 0x00
00007cd93bde1f19  jz 0x00007CD93BDE1E20
00007cd93bde1f1f  nop [rax+rax*1], ax
00007cd93bde1f28  nop [rax+rax*1], eax
00007cd93bde1f30  mov eax, 0x410474
00007cd93bde1f35  mov [r15+0x100], rax
00007cd93bde1f3c  jmp 0x00007CD93BBFE110
00007cd93bde1f41  int3
00007cd93bde1f42  call 0x00007CD93BCB52F0
00007cd93bde1f47  jmp 0x00007CD93BDE1E32
00007cd93bde1f4c  ucomisd xmm1, xmm14
00007cd93bde1f51  jp 0x00007CD93BDE1F60
00007cd93bde1f53  movaps xmm13, [0x00007CD93B9FE060]
00007cd93bde1f5b  jmp 0x00007CD93BDE1E9D
00007cd93bde1f60  vxorps xmm0, xmm1, xmm14
00007cd93bde1f65  pextrw eax, xmm0, 0x03
00007cd93bde1f6a  and eax, 0x7FF8
00007cd93bde1f6f  cmp eax, 0x08
00007cd93bde1f72  jnz 0x00007CD93BDE1E9D
00007cd93bde1f78  movq rax, xmm14
00007cd93bde1f7d  shl rax, 0x0D
00007cd93bde1f81  jbe 0x00007CD93BDE1E9D
00007cd93bde1f87  vorps xmm13, xmm14, [0x00007CD93B9FE070]
00007cd93bde1f8f  jmp 0x00007CD93BDE1E9D
00007cd93bde1f94  ucomisd xmm1, xmm15
00007cd93bde1f99  jp 0x00007CD93BDE1FA8
00007cd93bde1f9b  movaps xmm14, [0x00007CD93B9FE060]
00007cd93bde1fa3  jmp 0x00007CD93BDE1ECA
00007cd93bde1fa8  vxorps xmm0, xmm1, xmm15
00007cd93bde1fad  pextrw eax, xmm0, 0x03
00007cd93bde1fb2  and eax, 0x7FF8
00007cd93bde1fb7  cmp eax, 0x08
00007cd93bde1fba  jnz 0x00007CD93BDE1ECA
00007cd93bde1fc0  movq rax, xmm15
00007cd93bde1fc5  shl rax, 0x0D
00007cd93bde1fc9  jbe 0x00007CD93BDE1ECA
00007cd93bde1fcf  vorps xmm14, xmm15, [0x00007CD93B9FE070]
00007cd93bde1fd7  jmp 0x00007CD93BDE1ECA
00007cd93bde1fdc  int3
00007cd93bde1fdd  nop [rax], eax
00007cd93bde1fe0  mov rax, [r15+0x40]
00007cd93bde1fe4  lea r14, [rax+0x510]
00007cd93bde1feb  movaps xmm1, [r15+0x110]
00007cd93bde1ff3  movq rax, xmm1
00007cd93bde1ff8  mov [r13+r14*1], rax
00007cd93bde1ffd  mov rax, [r15+0xF0]
00007cd93bde2004  mov [r15+0x100], rax
00007cd93bde200b  jmp 0x00007CD93BDCE5C0
00007cd93bde2010  int3
00007cd93bde2011  call 0x00007CD93BCD5EB0
00007cd93bde2016  jmp 0x00007CD93BDE1FFD
00007cd93bde201b  int3
00007cd93bde201c  nop [rax], eax
00007cd93bde2020  mov qword ptr [r15+0x100], 0x04
00007cd93bde202b  mov esi, 0x00
00007cd93bde2030  mov edx, 0x09
00007cd93bde2035  mov rdi, 0x7FFE03B76200
00007cd93bde203f  mov rax, 0x64A580EEA970
00007cd93bde2049  call rax
00007cd93bde204b  cmp dword ptr [r15+0x318], 0x00
00007cd93bde2053  jnz 0x00007CD93BBFE110
00007cd93bde2059  jmp 0x00007CD93BBFE0A0
00007cd93bde205e  int3
00007cd93bde205f  int3
