00007fa9d6dce69b  nop [rax+rax*1], eax
00007fa9d6dce6a0  vmovaps xmm1, [0x00007FA9D69FE010]
00007fa9d6dce6a8  movq xmm1, xmm1
00007fa9d6dce6ac  movaps [r15+0x110], xmm1
00007fa9d6dce6b4  vmovaps xmm1, [0x00007FA9D69FE020]
00007fa9d6dce6bc  movq xmm1, xmm1
00007fa9d6dce6c0  movaps [r15+0x120], xmm1
00007fa9d6dce6c8  mov eax, 0x4204C0
00007fa9d6dce6cd  mov r14, [r13+rax*1]
00007fa9d6dce6d2  movq xmm1, r14
00007fa9d6dce6d7  movaps [r15+0x130], xmm1
00007fa9d6dce6df  vmovaps xmm1, [0x00007FA9D69FE030]
00007fa9d6dce6e7  vpbroadcastq xmm1, xmm1
00007fa9d6dce6ec  movaps [r15+0x140], xmm1
00007fa9d6dce6f4  mov qword ptr [r15+0x40], 0x02
00007fa9d6dce6fc  vmovaps xmm15, [0x00007FA9D69FE040]
00007fa9d6dce704  movq xmm15, xmm15
00007fa9d6dce709  movaps [r15+0x150], xmm15
00007fa9d6dce711  mov qword ptr [r15+0x58], 0x420000
00007fa9d6dce719  vmovaps xmm15, [0x00007FA9D69FE050]
00007fa9d6dce721  vpbroadcastq xmm15, xmm15
00007fa9d6dce726  movaps [r15+0x160], xmm15
00007fa9d6dce72e  mov rax, [r15+0x40]
00007fa9d6dce732  vmovq xmm14, rax
00007fa9d6dce737  vpbroadcastq xmm14, xmm14
00007fa9d6dce73c  movaps [r15+0x170], xmm14
00007fa9d6dce744  mov eax, 0x4204D0
00007fa9d6dce749  movups xmm13, [r13+rax*1]
00007fa9d6dce74f  mov qword ptr [r15+0x40], 0x430518
00007fa9d6dce757  mov qword ptr [r15+0x50], 0x430720
00007fa9d6dce75f  vpmovqd xmm12, xmm13
00007fa9d6dce765  pxor xmm11, xmm11
00007fa9d6dce76a  punpcklqdq xmm12, xmm11
00007fa9d6dce76f  movaps [r15+0x210], xmm12
00007fa9d6dce777  movq xmm12, qword ptr [r15+0x120]
00007fa9d6dce780  movq xmm11, qword ptr [r15+0x130]
00007fa9d6dce789  psubd xmm12, xmm11
00007fa9d6dce78e  movq xmm12, xmm12
00007fa9d6dce793  paddq xmm13, xmm14
00007fa9d6dce798  movaps [r15+0x180], xmm13
00007fa9d6dce7a0  movq xmm14, qword ptr [r15+0x150]
00007fa9d6dce7a9  paddd xmm11, xmm14
00007fa9d6dce7ae  movq xmm11, xmm11
00007fa9d6dce7b3  movq xmm11, xmm11
00007fa9d6dce7b8  movaps [r15+0x130], xmm11
00007fa9d6dce7c0  pmovzxdq xmm12, xmm12
00007fa9d6dce7c6  psllq xmm12, 0x00
00007fa9d6dce7cc  movq xmm14, qword ptr [r15+0x210]
00007fa9d6dce7d5  movq xmm13, qword ptr [r15+0x110]
00007fa9d6dce7de  paddd xmm14, xmm13
00007fa9d6dce7e3  movq xmm14, xmm14
00007fa9d6dce7e8  vcvtuqq2pd xmm12, xmm12
00007fa9d6dce7ee  pmovzxdq xmm14, xmm14
00007fa9d6dce7f4  psllq xmm14, 0x00
00007fa9d6dce7fa  vcvtuqq2pd xmm14, xmm14
00007fa9d6dce800  movaps xmm13, xmm12
00007fa9d6dce804  mulpd xmm13, xmm1
00007fa9d6dce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007fa9d6dce80f  ptest xmm11, xmm11
00007fa9d6dce815  jnz 0x00007FA9D6DCE8FF
00007fa9d6dce81b  movaps [r15+0x220], xmm13
00007fa9d6dce823  mov eax, 0x430720
00007fa9d6dce828  movups [r13+rax*1], xmm13
00007fa9d6dce82e  movaps xmm1, xmm14
00007fa9d6dce832  mulpd xmm1, xmm15
00007fa9d6dce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007fa9d6dce83c  ptest xmm13, xmm13
00007fa9d6dce842  jnz 0x00007FA9D6DCEA4C
00007fa9d6dce848  movaps [r15+0x210], xmm1
00007fa9d6dce850  mov eax, 0x430518
00007fa9d6dce855  movups [r13+rax*1], xmm1
00007fa9d6dce85b  mov qword ptr [r15+0x48], 0x10
00007fa9d6dce863  xor eax, eax
00007fa9d6dce865  mov r14d, 0x10
00007fa9d6dce86b  mov r12d, 0x200
00007fa9d6dce871  cmp r14, r12
00007fa9d6dce874  cmc
00007fa9d6dce875  lahf
00007fa9d6dce876  seto al
00007fa9d6dce879  mov [r15+0x108], eax
00007fa9d6dce880  mov eax, [r15+0x108]
00007fa9d6dce887  sahf
00007fa9d6dce888  jnz 0x00007FA9D6DCE8BA
00007fa9d6dce88a  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dce892  jz 0x00007FA9D6DCEFF0
00007fa9d6dce898  nop [rax+rax*1], ax
00007fa9d6dce8a1  nop [rax+rax*1], eax
00007fa9d6dce8a9  mov eax, 0x4101EC
00007fa9d6dce8ae  mov [r15+0x100], rax
00007fa9d6dce8b5  jmp 0x00007FA9D6BFE110
00007fa9d6dce8ba  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dce8c2  jz 0x00007FA9D6DCEBA0
00007fa9d6dce8c8  nop [rax+rax*1], ax
00007fa9d6dce8d1  nop [rax+rax*1], eax
00007fa9d6dce8d9  mov eax, 0x4101AC
00007fa9d6dce8de  mov [r15+0x100], rax
00007fa9d6dce8e5  jmp 0x00007FA9D6BFE110
00007fa9d6dce8ea  int3
00007fa9d6dce8eb  call 0x00007FA9D6C0DC20
00007fa9d6dce8f0  jmp 0x00007FA9D6DCE6D2
00007fa9d6dce8f5  call 0x00007FA9D6C0C260
00007fa9d6dce8fa  jmp 0x00007FA9D6DCE74F
00007fa9d6dce8ff  sub rsp, 0x08
00007fa9d6dce903  push rax
00007fa9d6dce904  push rcx
00007fa9d6dce905  push rdx
00007fa9d6dce906  push rdi
00007fa9d6dce907  push rsi
00007fa9d6dce908  push r8
00007fa9d6dce90a  push r9
00007fa9d6dce90c  push r10
00007fa9d6dce90e  push r11
00007fa9d6dce910  sub rsp, 0xF0
00007fa9d6dce917  vmovaps [rsp], xmm0
00007fa9d6dce91c  vmovaps [rsp+0x10], xmm1
00007fa9d6dce922  vmovaps [rsp+0x20], xmm2
00007fa9d6dce928  vmovaps [rsp+0x30], xmm3
00007fa9d6dce92e  vmovaps [rsp+0x40], xmm4
00007fa9d6dce934  vmovaps [rsp+0x50], xmm5
00007fa9d6dce93a  vmovaps [rsp+0x60], xmm6
00007fa9d6dce940  vmovaps [rsp+0x70], xmm7
00007fa9d6dce946  vmovaps [rsp+0x80], xmm8
00007fa9d6dce94f  vmovaps [rsp+0x90], xmm9
00007fa9d6dce958  vmovaps [rsp+0xA0], xmm10
00007fa9d6dce961  vmovaps [rsp+0xB0], xmm11
00007fa9d6dce96a  vmovaps [rsp+0xC0], xmm12
00007fa9d6dce973  vmovaps [rsp+0xD0], xmm14
00007fa9d6dce97c  vmovaps [rsp+0xE0], xmm15
00007fa9d6dce985  sub rsp, 0x30
00007fa9d6dce989  movaps [rsp], xmm13
00007fa9d6dce98e  movaps [rsp+0x10], xmm12
00007fa9d6dce994  movaps [rsp+0x20], xmm1
00007fa9d6dce999  lea rdi, [rsp]
00007fa9d6dce99d  mov esi, 0x00
00007fa9d6dce9a2  mov rax, 0x61DF872DB530
00007fa9d6dce9ac  call rax
00007fa9d6dce9ae  movaps xmm13, [rsp]
00007fa9d6dce9b3  add rsp, 0x30
00007fa9d6dce9b7  vmovaps xmm0, [rsp]
00007fa9d6dce9bc  vmovaps xmm1, [rsp+0x10]
00007fa9d6dce9c2  vmovaps xmm2, [rsp+0x20]
00007fa9d6dce9c8  vmovaps xmm3, [rsp+0x30]
00007fa9d6dce9ce  vmovaps xmm4, [rsp+0x40]
00007fa9d6dce9d4  vmovaps xmm5, [rsp+0x50]
00007fa9d6dce9da  vmovaps xmm6, [rsp+0x60]
00007fa9d6dce9e0  vmovaps xmm7, [rsp+0x70]
00007fa9d6dce9e6  vmovaps xmm8, [rsp+0x80]
00007fa9d6dce9ef  vmovaps xmm9, [rsp+0x90]
00007fa9d6dce9f8  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dcea01  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dcea0a  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dcea13  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dcea1c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dcea25  add rsp, 0xF0
00007fa9d6dcea2c  pop r11
00007fa9d6dcea2e  pop r10
00007fa9d6dcea30  pop r9
00007fa9d6dcea32  pop r8
00007fa9d6dcea34  pop rsi
00007fa9d6dcea35  pop rdi
00007fa9d6dcea36  pop rdx
00007fa9d6dcea37  pop rcx
00007fa9d6dcea38  pop rax
00007fa9d6dcea39  add rsp, 0x08
00007fa9d6dcea3d  jmp 0x00007FA9D6DCE81B
00007fa9d6dcea42  call 0x00007FA9D6C0C380
00007fa9d6dcea47  jmp 0x00007FA9D6DCE82E
00007fa9d6dcea4c  sub rsp, 0x08
00007fa9d6dcea50  push rax
00007fa9d6dcea51  push rcx
00007fa9d6dcea52  push rdx
00007fa9d6dcea53  push rdi
00007fa9d6dcea54  push rsi
00007fa9d6dcea55  push r8
00007fa9d6dcea57  push r9
00007fa9d6dcea59  push r10
00007fa9d6dcea5b  push r11
00007fa9d6dcea5d  sub rsp, 0xF0
00007fa9d6dcea64  vmovaps [rsp], xmm0
00007fa9d6dcea69  vmovaps [rsp+0x10], xmm2
00007fa9d6dcea6f  vmovaps [rsp+0x20], xmm3
00007fa9d6dcea75  vmovaps [rsp+0x30], xmm4
00007fa9d6dcea7b  vmovaps [rsp+0x40], xmm5
00007fa9d6dcea81  vmovaps [rsp+0x50], xmm6
00007fa9d6dcea87  vmovaps [rsp+0x60], xmm7
00007fa9d6dcea8d  vmovaps [rsp+0x70], xmm8
00007fa9d6dcea93  vmovaps [rsp+0x80], xmm9
00007fa9d6dcea9c  vmovaps [rsp+0x90], xmm10
00007fa9d6dceaa5  vmovaps [rsp+0xA0], xmm11
00007fa9d6dceaae  vmovaps [rsp+0xB0], xmm12
00007fa9d6dceab7  vmovaps [rsp+0xC0], xmm13
00007fa9d6dceac0  vmovaps [rsp+0xD0], xmm14
00007fa9d6dceac9  vmovaps [rsp+0xE0], xmm15
00007fa9d6dcead2  sub rsp, 0x30
00007fa9d6dcead6  movaps [rsp], xmm1
00007fa9d6dceada  movaps [rsp+0x10], xmm14
00007fa9d6dceae0  movaps [rsp+0x20], xmm15
00007fa9d6dceae6  lea rdi, [rsp]
00007fa9d6dceaea  mov esi, 0x00
00007fa9d6dceaef  mov rax, 0x61DF872DB530
00007fa9d6dceaf9  call rax
00007fa9d6dceafb  movaps xmm1, [rsp]
00007fa9d6dceaff  add rsp, 0x30
00007fa9d6dceb03  vmovaps xmm0, [rsp]
00007fa9d6dceb08  vmovaps xmm2, [rsp+0x10]
00007fa9d6dceb0e  vmovaps xmm3, [rsp+0x20]
00007fa9d6dceb14  vmovaps xmm4, [rsp+0x30]
00007fa9d6dceb1a  vmovaps xmm5, [rsp+0x40]
00007fa9d6dceb20  vmovaps xmm6, [rsp+0x50]
00007fa9d6dceb26  vmovaps xmm7, [rsp+0x60]
00007fa9d6dceb2c  vmovaps xmm8, [rsp+0x70]
00007fa9d6dceb32  vmovaps xmm9, [rsp+0x80]
00007fa9d6dceb3b  vmovaps xmm10, [rsp+0x90]
00007fa9d6dceb44  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dceb4d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dceb56  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dceb5f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dceb68  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dceb71  add rsp, 0xF0
00007fa9d6dceb78  pop r11
00007fa9d6dceb7a  pop r10
00007fa9d6dceb7c  pop r9
00007fa9d6dceb7e  pop r8
00007fa9d6dceb80  pop rsi
00007fa9d6dceb81  pop rdi
00007fa9d6dceb82  pop rdx
00007fa9d6dceb83  pop rcx
00007fa9d6dceb84  pop rax
00007fa9d6dceb85  add rsp, 0x08
00007fa9d6dceb89  jmp 0x00007FA9D6DCE848
00007fa9d6dceb8e  call 0x00007FA9D6BFF540
00007fa9d6dceb93  jmp 0x00007FA9D6DCE85B
00007fa9d6dceb98  int3
00007fa9d6dceb99  nop [rax], eax
00007fa9d6dceba0  movaps xmm1, [r15+0x180]
00007fa9d6dceba8  vpmovqd xmm15, xmm1
00007fa9d6dcebae  pxor xmm14, xmm14
00007fa9d6dcebb3  punpcklqdq xmm15, xmm14
00007fa9d6dcebb8  movaps [r15+0x210], xmm15
00007fa9d6dcebc0  movq xmm15, qword ptr [r15+0x120]
00007fa9d6dcebc9  movq xmm14, qword ptr [r15+0x130]
00007fa9d6dcebd2  psubd xmm15, xmm14
00007fa9d6dcebd7  movq xmm15, xmm15
00007fa9d6dcebdc  movaps xmm13, [r15+0x170]
00007fa9d6dcebe4  paddq xmm1, xmm13
00007fa9d6dcebe9  movaps [r15+0x180], xmm1
00007fa9d6dcebf1  movq xmm1, qword ptr [r15+0x150]
00007fa9d6dcebfa  paddd xmm14, xmm1
00007fa9d6dcebff  movq xmm14, xmm14
00007fa9d6dcec04  movq xmm14, xmm14
00007fa9d6dcec09  movaps [r15+0x130], xmm14
00007fa9d6dcec11  pmovzxdq xmm15, xmm15
00007fa9d6dcec17  psllq xmm15, 0x00
00007fa9d6dcec1d  movq xmm1, qword ptr [r15+0x210]
00007fa9d6dcec26  movq xmm14, qword ptr [r15+0x110]
00007fa9d6dcec2f  paddd xmm1, xmm14
00007fa9d6dcec34  movq xmm1, xmm1
00007fa9d6dcec38  vcvtuqq2pd xmm15, xmm15
00007fa9d6dcec3e  pmovzxdq xmm1, xmm1
00007fa9d6dcec43  psllq xmm1, 0x00
00007fa9d6dcec48  vcvtuqq2pd xmm1, xmm1
00007fa9d6dcec4e  movaps xmm14, [r15+0x140]
00007fa9d6dcec56  movaps xmm13, xmm15
00007fa9d6dcec5a  mulpd xmm13, xmm14
00007fa9d6dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa9d6dcec65  ptest xmm12, xmm12
00007fa9d6dcec6b  jnz 0x00007FA9D6DCED4E
00007fa9d6dcec71  movaps [r15+0x220], xmm13
00007fa9d6dcec79  mov rax, [r15+0x48]
00007fa9d6dcec7d  mov r14, [r15+0x50]
00007fa9d6dcec81  lea r12, [r14+rax*1]
00007fa9d6dcec85  movups [r13+r12*1], xmm13
00007fa9d6dcec8b  movaps xmm15, [r15+0x160]
00007fa9d6dcec93  movaps xmm14, xmm1
00007fa9d6dcec97  mulpd xmm14, xmm15
00007fa9d6dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007fa9d6dceca2  ptest xmm13, xmm13
00007fa9d6dceca8  jnz 0x00007FA9D6DCEE9C
00007fa9d6dcecae  movaps [r15+0x210], xmm14
00007fa9d6dcecb6  mov r14, [r15+0x40]
00007fa9d6dcecba  lea r12, [r14+rax*1]
00007fa9d6dcecbe  movups [r13+r12*1], xmm14
00007fa9d6dcecc4  lea r14, [rax+0x10]
00007fa9d6dcecc8  mov [r15+0x48], r14
00007fa9d6dceccc  xor eax, eax
00007fa9d6dcecce  mov r12d, 0x200
00007fa9d6dcecd4  cmp r14, r12
00007fa9d6dcecd7  cmc
00007fa9d6dcecd8  lahf
00007fa9d6dcecd9  seto al
00007fa9d6dcecdc  mov [r15+0x108], eax
00007fa9d6dcece3  mov eax, [r15+0x108]
00007fa9d6dcecea  sahf
00007fa9d6dceceb  jnz 0x00007FA9D6DCED1D
00007fa9d6dceced  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dcecf5  jz 0x00007FA9D6DCEFF0
00007fa9d6dcecfb  nop [rax+rax*1], ax
00007fa9d6dced04  nop [rax+rax*1], eax
00007fa9d6dced0c  mov eax, 0x4101EC
00007fa9d6dced11  mov [r15+0x100], rax
00007fa9d6dced18  jmp 0x00007FA9D6BFE110
00007fa9d6dced1d  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dced25  jz 0x00007FA9D6DCEBA0
00007fa9d6dced2b  nop [rax+rax*1], ax
00007fa9d6dced34  nop [rax+rax*1], eax
00007fa9d6dced3c  mov eax, 0x4101AC
00007fa9d6dced41  mov [r15+0x100], rax
00007fa9d6dced48  jmp 0x00007FA9D6BFE110
00007fa9d6dced4d  int3
00007fa9d6dced4e  sub rsp, 0x08
00007fa9d6dced52  push rax
00007fa9d6dced53  push rcx
00007fa9d6dced54  push rdx
00007fa9d6dced55  push rdi
00007fa9d6dced56  push rsi
00007fa9d6dced57  push r8
00007fa9d6dced59  push r9
00007fa9d6dced5b  push r10
00007fa9d6dced5d  push r11
00007fa9d6dced5f  sub rsp, 0xF0
00007fa9d6dced66  vmovaps [rsp], xmm0
00007fa9d6dced6b  vmovaps [rsp+0x10], xmm1
00007fa9d6dced71  vmovaps [rsp+0x20], xmm2
00007fa9d6dced77  vmovaps [rsp+0x30], xmm3
00007fa9d6dced7d  vmovaps [rsp+0x40], xmm4
00007fa9d6dced83  vmovaps [rsp+0x50], xmm5
00007fa9d6dced89  vmovaps [rsp+0x60], xmm6
00007fa9d6dced8f  vmovaps [rsp+0x70], xmm7
00007fa9d6dced95  vmovaps [rsp+0x80], xmm8
00007fa9d6dced9e  vmovaps [rsp+0x90], xmm9
00007fa9d6dceda7  vmovaps [rsp+0xA0], xmm10
00007fa9d6dcedb0  vmovaps [rsp+0xB0], xmm11
00007fa9d6dcedb9  vmovaps [rsp+0xC0], xmm12
00007fa9d6dcedc2  vmovaps [rsp+0xD0], xmm14
00007fa9d6dcedcb  vmovaps [rsp+0xE0], xmm15
00007fa9d6dcedd4  sub rsp, 0x30
00007fa9d6dcedd8  movaps [rsp], xmm13
00007fa9d6dceddd  movaps [rsp+0x10], xmm15
00007fa9d6dcede3  movaps [rsp+0x20], xmm14
00007fa9d6dcede9  lea rdi, [rsp]
00007fa9d6dceded  mov esi, 0x00
00007fa9d6dcedf2  mov rax, 0x61DF872DB530
00007fa9d6dcedfc  call rax
00007fa9d6dcedfe  movaps xmm13, [rsp]
00007fa9d6dcee03  add rsp, 0x30
00007fa9d6dcee07  vmovaps xmm0, [rsp]
00007fa9d6dcee0c  vmovaps xmm1, [rsp+0x10]
00007fa9d6dcee12  vmovaps xmm2, [rsp+0x20]
00007fa9d6dcee18  vmovaps xmm3, [rsp+0x30]
00007fa9d6dcee1e  vmovaps xmm4, [rsp+0x40]
00007fa9d6dcee24  vmovaps xmm5, [rsp+0x50]
00007fa9d6dcee2a  vmovaps xmm6, [rsp+0x60]
00007fa9d6dcee30  vmovaps xmm7, [rsp+0x70]
00007fa9d6dcee36  vmovaps xmm8, [rsp+0x80]
00007fa9d6dcee3f  vmovaps xmm9, [rsp+0x90]
00007fa9d6dcee48  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dcee51  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dcee5a  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dcee63  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dcee6c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dcee75  add rsp, 0xF0
00007fa9d6dcee7c  pop r11
00007fa9d6dcee7e  pop r10
00007fa9d6dcee80  pop r9
00007fa9d6dcee82  pop r8
00007fa9d6dcee84  pop rsi
00007fa9d6dcee85  pop rdi
00007fa9d6dcee86  pop rdx
00007fa9d6dcee87  pop rcx
00007fa9d6dcee88  pop rax
00007fa9d6dcee89  add rsp, 0x08
00007fa9d6dcee8d  jmp 0x00007FA9D6DCEC71
00007fa9d6dcee92  call 0x00007FA9D6CC2240
00007fa9d6dcee97  jmp 0x00007FA9D6DCEC8B
00007fa9d6dcee9c  sub rsp, 0x08
00007fa9d6dceea0  push rax
00007fa9d6dceea1  push rcx
00007fa9d6dceea2  push rdx
00007fa9d6dceea3  push rdi
00007fa9d6dceea4  push rsi
00007fa9d6dceea5  push r8
00007fa9d6dceea7  push r9
00007fa9d6dceea9  push r10
00007fa9d6dceeab  push r11
00007fa9d6dceead  sub rsp, 0xF0
00007fa9d6dceeb4  vmovaps [rsp], xmm0
00007fa9d6dceeb9  vmovaps [rsp+0x10], xmm1
00007fa9d6dceebf  vmovaps [rsp+0x20], xmm2
00007fa9d6dceec5  vmovaps [rsp+0x30], xmm3
00007fa9d6dceecb  vmovaps [rsp+0x40], xmm4
00007fa9d6dceed1  vmovaps [rsp+0x50], xmm5
00007fa9d6dceed7  vmovaps [rsp+0x60], xmm6
00007fa9d6dceedd  vmovaps [rsp+0x70], xmm7
00007fa9d6dceee3  vmovaps [rsp+0x80], xmm8
00007fa9d6dceeec  vmovaps [rsp+0x90], xmm9
00007fa9d6dceef5  vmovaps [rsp+0xA0], xmm10
00007fa9d6dceefe  vmovaps [rsp+0xB0], xmm11
00007fa9d6dcef07  vmovaps [rsp+0xC0], xmm12
00007fa9d6dcef10  vmovaps [rsp+0xD0], xmm13
00007fa9d6dcef19  vmovaps [rsp+0xE0], xmm15
00007fa9d6dcef22  sub rsp, 0x30
00007fa9d6dcef26  movaps [rsp], xmm14
00007fa9d6dcef2b  movaps [rsp+0x10], xmm1
00007fa9d6dcef30  movaps [rsp+0x20], xmm15
00007fa9d6dcef36  lea rdi, [rsp]
00007fa9d6dcef3a  mov esi, 0x00
00007fa9d6dcef3f  mov rax, 0x61DF872DB530
00007fa9d6dcef49  call rax
00007fa9d6dcef4b  movaps xmm14, [rsp]
00007fa9d6dcef50  add rsp, 0x30
00007fa9d6dcef54  vmovaps xmm0, [rsp]
00007fa9d6dcef59  vmovaps xmm1, [rsp+0x10]
00007fa9d6dcef5f  vmovaps xmm2, [rsp+0x20]
00007fa9d6dcef65  vmovaps xmm3, [rsp+0x30]
00007fa9d6dcef6b  vmovaps xmm4, [rsp+0x40]
00007fa9d6dcef71  vmovaps xmm5, [rsp+0x50]
00007fa9d6dcef77  vmovaps xmm6, [rsp+0x60]
00007fa9d6dcef7d  vmovaps xmm7, [rsp+0x70]
00007fa9d6dcef83  vmovaps xmm8, [rsp+0x80]
00007fa9d6dcef8c  vmovaps xmm9, [rsp+0x90]
00007fa9d6dcef95  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dcef9e  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dcefa7  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dcefb0  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dcefb9  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dcefc2  add rsp, 0xF0
00007fa9d6dcefc9  pop r11
00007fa9d6dcefcb  pop r10
00007fa9d6dcefcd  pop r9
00007fa9d6dcefcf  pop r8
00007fa9d6dcefd1  pop rsi
00007fa9d6dcefd2  pop rdi
00007fa9d6dcefd3  pop rdx
00007fa9d6dcefd4  pop rcx
00007fa9d6dcefd5  pop rax
00007fa9d6dcefd6  add rsp, 0x08
00007fa9d6dcefda  jmp 0x00007FA9D6DCECAE
00007fa9d6dcefdf  call 0x00007FA9D6CC34C0
00007fa9d6dcefe4  jmp 0x00007FA9D6DCECC4
00007fa9d6dcefe9  int3
00007fa9d6dcefea  nop [rax+rax*1], ax
00007fa9d6dceff0  mov rax, [r15+0xF8]
00007fa9d6dceff7  lea r14, [rax-0x150]
00007fa9d6dceffe  mov [r15+0xF8], r14
00007fa9d6dcf005  mov rax, [r15+0x50]
00007fa9d6dcf009  lea r12, [rax+0x80]
00007fa9d6dcf010  movups xmm1, [r13+r12*1]
00007fa9d6dcf016  lea r12, [rax+0x90]
00007fa9d6dcf01d  movups xmm15, [r13+r12*1]
00007fa9d6dcf023  mov qword ptr [r15+0x48], 0x00
00007fa9d6dcf02b  lea r12, [rax+0x40]
00007fa9d6dcf02f  movups xmm14, [r13+r12*1]
00007fa9d6dcf035  lea r12, [rax+0x50]
00007fa9d6dcf039  movups xmm13, [r13+r12*1]
00007fa9d6dcf03f  lea r12, [r14+0x120]
00007fa9d6dcf046  movq xmm12, qword ptr [r15+0x1C0]
00007fa9d6dcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007fa9d6dcf058  movq r11, xmm12
00007fa9d6dcf05d  movq r10, xmm11
00007fa9d6dcf062  mov [r13+r12*1], r11
00007fa9d6dcf067  lea r12, [r14+0x128]
00007fa9d6dcf06e  mov [r13+r12*1], r10
00007fa9d6dcf073  vxorps xmm12, xmm12, xmm12
00007fa9d6dcf078  vpbroadcastq xmm12, xmm12
00007fa9d6dcf07d  lea r12, [r14+0x100]
00007fa9d6dcf084  movq xmm11, qword ptr [r15+0x200]
00007fa9d6dcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007fa9d6dcf096  movq r11, xmm11
00007fa9d6dcf09b  movq r10, xmm10
00007fa9d6dcf0a0  mov [r13+r12*1], r11
00007fa9d6dcf0a5  lea r12, [r14+0x108]
00007fa9d6dcf0ac  mov [r13+r12*1], r10
00007fa9d6dcf0b1  lea r12, [r14+0xE0]
00007fa9d6dcf0b8  movups [r13+r12*1], xmm15
00007fa9d6dcf0be  lea r12, [r14+0xF0]
00007fa9d6dcf0c5  movups [r13+r12*1], xmm1
00007fa9d6dcf0cb  lea r12, [rax+0xC0]
00007fa9d6dcf0d2  movups xmm1, [r13+r12*1]
00007fa9d6dcf0d8  lea r12, [rax+0xD0]
00007fa9d6dcf0df  movups xmm15, [r13+r12*1]
00007fa9d6dcf0e5  lea r12, [r14+0x110]
00007fa9d6dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007fa9d6dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007fa9d6dcf0fe  movq r11, xmm11
00007fa9d6dcf103  movq r10, xmm10
00007fa9d6dcf108  mov [r13+r12*1], r11
00007fa9d6dcf10d  lea r12, [r14+0x118]
00007fa9d6dcf114  mov [r13+r12*1], r10
00007fa9d6dcf119  movups xmm11, [r13+rax*1]
00007fa9d6dcf11f  lea r12, [rax+0x10]
00007fa9d6dcf123  movups xmm10, [r13+r12*1]
00007fa9d6dcf129  lea r12, [r14+0x130]
00007fa9d6dcf130  movq xmm9, qword ptr [r15+0x1A0]
00007fa9d6dcf139  movq xmm8, qword ptr [r15+0x190]
00007fa9d6dcf142  movq r11, xmm9
00007fa9d6dcf147  movq r10, xmm8
00007fa9d6dcf14c  mov [r13+r12*1], r11
00007fa9d6dcf151  lea r12, [r14+0x138]
00007fa9d6dcf158  mov [r13+r12*1], r10
00007fa9d6dcf15d  lea r12, [rax+0x140]
00007fa9d6dcf164  movups xmm9, [r13+r12*1]
00007fa9d6dcf16a  lea r12, [rax+0x150]
00007fa9d6dcf171  movups xmm8, [r13+r12*1]
00007fa9d6dcf177  lea r12, [r14+0xC0]
00007fa9d6dcf17e  movups [r13+r12*1], xmm15
00007fa9d6dcf184  lea r12, [r14+0xD0]
00007fa9d6dcf18b  movups [r13+r12*1], xmm1
00007fa9d6dcf191  lea r12, [rax+0x100]
00007fa9d6dcf198  movups xmm1, [r13+r12*1]
00007fa9d6dcf19e  lea r12, [rax+0x110]
00007fa9d6dcf1a5  movups xmm15, [r13+r12*1]
00007fa9d6dcf1ab  lea r12, [r14+0x140]
00007fa9d6dcf1b2  mov r11, [r15+0xE8]
00007fa9d6dcf1b9  mov [r13+r12*1], r11
00007fa9d6dcf1be  lea r12, [rax+0x180]
00007fa9d6dcf1c5  movups xmm7, [r13+r12*1]
00007fa9d6dcf1cb  lea r12, [rax+0x190]
00007fa9d6dcf1d2  movups xmm6, [r13+r12*1]
00007fa9d6dcf1d8  lea r12, [rax+0x1C0]
00007fa9d6dcf1df  movups xmm5, [r13+r12*1]
00007fa9d6dcf1e5  lea r12, [rax+0x1D0]
00007fa9d6dcf1ec  movups xmm4, [r13+r12*1]
00007fa9d6dcf1f2  lea r12, [r14+0x20]
00007fa9d6dcf1f6  movups [r13+r12*1], xmm1
00007fa9d6dcf1fc  lea r12, [r14+0x30]
00007fa9d6dcf200  movups [r13+r12*1], xmm13
00007fa9d6dcf206  lea r12, [rax+0x60]
00007fa9d6dcf20a  movups xmm1, [r13+r12*1]
00007fa9d6dcf210  lea r12, [rax+0x70]
00007fa9d6dcf214  movups xmm13, [r13+r12*1]
00007fa9d6dcf21a  lea r12, [rax+0x20]
00007fa9d6dcf21e  movups xmm3, [r13+r12*1]
00007fa9d6dcf224  lea r12, [rax+0x30]
00007fa9d6dcf228  movups xmm2, [r13+r12*1]
00007fa9d6dcf22e  movaps [r15+0x1F0], xmm2
00007fa9d6dcf236  lea r12, [r14+0x60]
00007fa9d6dcf23a  movups [r13+r12*1], xmm11
00007fa9d6dcf240  lea r12, [r14+0x70]
00007fa9d6dcf244  movups [r13+r12*1], xmm5
00007fa9d6dcf24a  lea r12, [rax+0xE0]
00007fa9d6dcf251  movups xmm11, [r13+r12*1]
00007fa9d6dcf257  lea r12, [rax+0xF0]
00007fa9d6dcf25e  movups xmm5, [r13+r12*1]
00007fa9d6dcf264  lea r12, [r14+0xA0]
00007fa9d6dcf26b  movups [r13+r12*1], xmm13
00007fa9d6dcf271  lea r12, [r14+0xB0]
00007fa9d6dcf278  movups [r13+r12*1], xmm1
00007fa9d6dcf27e  lea r12, [rax+0xA0]
00007fa9d6dcf285  movups xmm1, [r13+r12*1]
00007fa9d6dcf28b  lea r12, [rax+0xB0]
00007fa9d6dcf292  movups xmm13, [r13+r12*1]
00007fa9d6dcf298  lea r12, [rax+0x120]
00007fa9d6dcf29f  vmovaps [rsp+0x10], xmm1
00007fa9d6dcf2a5  movups xmm1, [r13+r12*1]
00007fa9d6dcf2ab  lea r12, [rax+0x130]
00007fa9d6dcf2b2  vmovaps [rsp+0x20], xmm1
00007fa9d6dcf2b8  movups xmm1, [r13+r12*1]
00007fa9d6dcf2be  lea r12, [rax+0x160]
00007fa9d6dcf2c5  vmovaps [rsp+0x30], xmm1
00007fa9d6dcf2cb  movups xmm1, [r13+r12*1]
00007fa9d6dcf2d1  lea r12, [rax+0x170]
00007fa9d6dcf2d8  vmovaps [rsp+0x40], xmm1
00007fa9d6dcf2de  movups xmm1, [r13+r12*1]
00007fa9d6dcf2e4  movaps [r15+0x2B0], xmm1
00007fa9d6dcf2ec  lea r12, [r14+0x80]
00007fa9d6dcf2f3  movups [r13+r12*1], xmm13
00007fa9d6dcf2f9  lea r12, [r14+0x90]
00007fa9d6dcf300  vmovaps xmm13, [rsp+0x10]
00007fa9d6dcf306  movups [r13+r12*1], xmm13
00007fa9d6dcf30c  lea r12, [rax+0x1A0]
00007fa9d6dcf313  movups xmm13, [r13+r12*1]
00007fa9d6dcf319  lea r12, [rax+0x1B0]
00007fa9d6dcf320  vmovaps [rsp+0x10], xmm1
00007fa9d6dcf326  movups xmm1, [r13+r12*1]
00007fa9d6dcf32c  movaps [r15+0x290], xmm13
00007fa9d6dcf334  movaps [r15+0x1E0], xmm1
00007fa9d6dcf33c  lea r12, [rax+0x1E0]
00007fa9d6dcf343  vmovaps [rsp+0x50], xmm1
00007fa9d6dcf349  movups xmm1, [r13+r12*1]
00007fa9d6dcf34f  lea r12, [rax+0x1F0]
00007fa9d6dcf356  vmovaps [rsp+0x60], xmm1
00007fa9d6dcf35c  movups xmm1, [r13+r12*1]
00007fa9d6dcf362  mov qword ptr [r15+0x50], 0x430920
00007fa9d6dcf36a  lea rax, [r14+0x40]
00007fa9d6dcf36e  vmovaps [rsp+0x70], xmm1
00007fa9d6dcf374  vmovaps xmm1, [rsp+0x40]
00007fa9d6dcf37a  movups [r13+rax*1], xmm1
00007fa9d6dcf380  lea rax, [r14+0x50]
00007fa9d6dcf384  movups [r13+rax*1], xmm10
00007fa9d6dcf38a  vmovaps xmm1, [rsp+0x70]
00007fa9d6dcf390  movups [r13+r14*1], xmm1
00007fa9d6dcf396  lea rax, [r14+0x10]
00007fa9d6dcf39a  vmovaps xmm1, [rsp+0x60]
00007fa9d6dcf3a0  movups [r13+rax*1], xmm1
00007fa9d6dcf3a6  mov rax, [r15+0x40]
00007fa9d6dcf3aa  vmovaps [rsp+0x40], xmm3
00007fa9d6dcf3b0  vmovaps xmm1, [rsp+0x40]
00007fa9d6dcf3b6  por xmm3, xmm1
00007fa9d6dcf3ba  vmovaps [rsp+0x40], xmm6
00007fa9d6dcf3c0  vmovaps xmm10, [rsp+0x40]
00007fa9d6dcf3c6  por xmm6, xmm10
00007fa9d6dcf3cb  lea r12, [rax+0x30]
00007fa9d6dcf3cf  mov r11, [r13+r12*1]
00007fa9d6dcf3d4  lea r12, [rax+0x38]
00007fa9d6dcf3d8  mov r10, [r13+r12*1]
00007fa9d6dcf3dd  movq xmm10, r11
00007fa9d6dcf3e2  vmovaps [rsp+0x40], xmm1
00007fa9d6dcf3e8  movq xmm1, r10
00007fa9d6dcf3ed  movq xmm10, xmm10
00007fa9d6dcf3f2  vmovaps [rsp+0x60], xmm10
00007fa9d6dcf3f8  movq xmm10, xmm10
00007fa9d6dcf3fd  movaps [r15+0x130], xmm10
00007fa9d6dcf405  movq xmm1, xmm1
00007fa9d6dcf409  vmovaps [rsp+0x70], xmm1
00007fa9d6dcf40f  movq xmm1, xmm1
00007fa9d6dcf413  movaps [r15+0x280], xmm1
00007fa9d6dcf41b  vmovaps [rsp+0x80], xmm9
00007fa9d6dcf424  vmovaps xmm1, [rsp+0x80]
00007fa9d6dcf42d  por xmm9, xmm1
00007fa9d6dcf432  lea r12, [rax+0x20]
00007fa9d6dcf436  mov r11, [r13+r12*1]
00007fa9d6dcf43b  lea r12, [rax+0x28]
00007fa9d6dcf43f  mov r10, [r13+r12*1]
00007fa9d6dcf444  movq xmm1, r11
00007fa9d6dcf449  movq xmm10, r10
00007fa9d6dcf44e  movq xmm1, xmm1
00007fa9d6dcf452  vmovaps [rsp+0x80], xmm1
00007fa9d6dcf45b  movq xmm1, xmm1
00007fa9d6dcf45f  movaps [r15+0x150], xmm1
00007fa9d6dcf467  movq xmm10, xmm10
00007fa9d6dcf46c  vmovaps [rsp+0x90], xmm10
00007fa9d6dcf475  movq xmm10, xmm10
00007fa9d6dcf47a  movaps [r15+0x140], xmm10
00007fa9d6dcf482  lea r12, [rax+0x10]
00007fa9d6dcf486  mov r11, [r13+r12*1]
00007fa9d6dcf48b  lea r12, [rax+0x18]
00007fa9d6dcf48f  mov r10, [r13+r12*1]
00007fa9d6dcf494  movq xmm1, r11
00007fa9d6dcf499  movq xmm10, r10
00007fa9d6dcf49e  movq xmm1, xmm1
00007fa9d6dcf4a2  vmovaps [rsp+0xA0], xmm1
00007fa9d6dcf4ab  movq xmm1, xmm1
00007fa9d6dcf4af  movaps [r15+0x170], xmm1
00007fa9d6dcf4b7  movq xmm10, xmm10
00007fa9d6dcf4bc  vmovaps [rsp+0xB0], xmm10
00007fa9d6dcf4c5  movq xmm10, xmm10
00007fa9d6dcf4ca  movaps [r15+0x160], xmm10
00007fa9d6dcf4d2  mov r12, [r13+rax*1]
00007fa9d6dcf4d7  vmovq xmm1, r12
00007fa9d6dcf4dc  vpbroadcastq xmm1, xmm1
00007fa9d6dcf4e1  lea r12, [rax+0x08]
00007fa9d6dcf4e5  mov rax, [r13+r12*1]
00007fa9d6dcf4ea  movq xmm10, rax
00007fa9d6dcf4ef  movaps [r15+0x230], xmm10
00007fa9d6dcf4f7  lea rax, [r14+0x50]
00007fa9d6dcf4fb  movups xmm10, [r13+rax*1]
00007fa9d6dcf501  lea rax, [r14+0x60]
00007fa9d6dcf505  vmovaps [rsp+0xC0], xmm1
00007fa9d6dcf50e  movups xmm1, [r13+rax*1]
00007fa9d6dcf514  lea rax, [r14+0x30]
00007fa9d6dcf518  vmovaps [rsp+0xD0], xmm1
00007fa9d6dcf521  movups xmm1, [r13+rax*1]
00007fa9d6dcf527  mov qword ptr [r15+0x60], 0x430920
00007fa9d6dcf52f  mov qword ptr [r15+0x58], 0x40
00007fa9d6dcf537  vmovaps [rsp+0xE0], xmm1
00007fa9d6dcf540  vmovaps [rsp+0xF0], xmm15
00007fa9d6dcf549  vmovaps xmm15, [rsp+0xC0]
00007fa9d6dcf552  vmovaps [rsp+0xC0], xmm14
00007fa9d6dcf55b  vmovaps xmm14, [rsp+0x40]
00007fa9d6dcf561  vmovaps [rsp+0x40], xmm13
00007fa9d6dcf567  movaps xmm1, xmm15
00007fa9d6dcf56b  mulpd xmm1, xmm14
00007fa9d6dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007fa9d6dcf575  ptest xmm13, xmm13
00007fa9d6dcf57b  jnz 0x00007FA9D6DD0682
00007fa9d6dcf581  movq xmm14, qword ptr [r15+0x230]
00007fa9d6dcf58a  vmovaps [rsp+0x100], xmm14
00007fa9d6dcf593  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dcf599  vmovaps [rsp+0x110], xmm1
00007fa9d6dcf5a2  vmovaps xmm1, [rsp+0xE0]
00007fa9d6dcf5ab  vmovaps [rsp+0xE0], xmm15
00007fa9d6dcf5b4  movaps xmm13, xmm1
00007fa9d6dcf5b8  mulpd xmm13, xmm14
00007fa9d6dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007fa9d6dcf5c3  ptest xmm15, xmm15
00007fa9d6dcf5c9  jnz 0x00007FA9D6DD07C4
00007fa9d6dcf5cf  vxorps xmm1, xmm1, xmm1
00007fa9d6dcf5d3  vpbroadcastq xmm1, xmm1
00007fa9d6dcf5d8  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dcf5e1  vmovaps [rsp+0xE0], xmm1
00007fa9d6dcf5ea  vmovaps xmm1, [rsp+0xD0]
00007fa9d6dcf5f3  vmovaps [rsp+0xD0], xmm13
00007fa9d6dcf5fc  movaps xmm15, xmm14
00007fa9d6dcf600  mulpd xmm15, xmm1
00007fa9d6dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa9d6dcf60b  ptest xmm13, xmm13
00007fa9d6dcf611  jnz 0x00007FA9D6DD0907
00007fa9d6dcf617  movaps xmm1, xmm14
00007fa9d6dcf61b  mulpd xmm1, xmm10
00007fa9d6dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007fa9d6dcf625  ptest xmm13, xmm13
00007fa9d6dcf62b  jnz 0x00007FA9D6DD0A4A
00007fa9d6dcf631  movaps xmm13, xmm14
00007fa9d6dcf635  mulpd xmm13, xmm2
00007fa9d6dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007fa9d6dcf640  ptest xmm10, xmm10
00007fa9d6dcf646  jnz 0x00007FA9D6DD0B8C
00007fa9d6dcf64c  vmovaps [rsp+0x120], xmm7
00007fa9d6dcf655  vmovaps xmm14, [rsp+0x120]
00007fa9d6dcf65e  por xmm7, xmm14
00007fa9d6dcf663  vmovaps xmm14, [rsp+0xC0]
00007fa9d6dcf66c  vmovaps xmm10, [rsp+0xC0]
00007fa9d6dcf675  por xmm14, xmm10
00007fa9d6dcf67a  vmovaps xmm2, [rsp+0x100]
00007fa9d6dcf683  vpermilpd xmm2, xmm2, 0x00
00007fa9d6dcf689  vmovaps [rsp+0xC0], xmm1
00007fa9d6dcf692  vmovaps [rsp+0x120], xmm15
00007fa9d6dcf69b  movaps xmm1, xmm10
00007fa9d6dcf69f  mulpd xmm1, xmm2
00007fa9d6dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa9d6dcf6a8  ptest xmm15, xmm15
00007fa9d6dcf6ae  jnz 0x00007FA9D6DD0CCF
00007fa9d6dcf6b4  xor eax, eax
00007fa9d6dcf6b6  mov r12d, 0x40
00007fa9d6dcf6bc  mov r11d, 0x200
00007fa9d6dcf6c2  cmp r12, r11
00007fa9d6dcf6c5  cmc
00007fa9d6dcf6c6  lahf
00007fa9d6dcf6c7  seto al
00007fa9d6dcf6ca  mov [r15+0x108], eax
00007fa9d6dcf6d1  vmovaps xmm10, [rsp+0x110]
00007fa9d6dcf6da  vmovaps xmm2, [rsp+0xE0]
00007fa9d6dcf6e3  vmovaps [rsp+0xE0], xmm1
00007fa9d6dcf6ec  movaps xmm15, xmm10
00007fa9d6dcf6f0  addpd xmm15, xmm2
00007fa9d6dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6dcf6fb  ptest xmm1, xmm1
00007fa9d6dcf700  jnz 0x00007FA9D6DD0E10
00007fa9d6dcf706  vmovaps xmm10, [rsp+0x120]
00007fa9d6dcf70f  vmovaps [rsp+0x110], xmm15
00007fa9d6dcf718  movaps xmm1, xmm10
00007fa9d6dcf71c  addpd xmm1, xmm12
00007fa9d6dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa9d6dcf726  ptest xmm15, xmm15
00007fa9d6dcf72c  jnz 0x00007FA9D6DD0F53
00007fa9d6dcf732  vmovaps xmm10, [rsp+0xC0]
00007fa9d6dcf73b  vmovaps [rsp+0xC0], xmm1
00007fa9d6dcf744  movaps xmm15, xmm10
00007fa9d6dcf748  addpd xmm15, xmm12
00007fa9d6dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6dcf753  ptest xmm1, xmm1
00007fa9d6dcf758  jnz 0x00007FA9D6DD1095
00007fa9d6dcf75e  vmovaps xmm1, [rsp+0x30]
00007fa9d6dcf764  vmovaps xmm12, [rsp+0x30]
00007fa9d6dcf76a  por xmm1, xmm12
00007fa9d6dcf76f  vmovaps xmm12, [rsp+0x20]
00007fa9d6dcf775  vmovaps xmm10, [rsp+0x20]
00007fa9d6dcf77b  por xmm12, xmm10
00007fa9d6dcf780  vmovaps [rsp+0x20], xmm5
00007fa9d6dcf786  vmovaps xmm10, [rsp+0x20]
00007fa9d6dcf78c  por xmm5, xmm10
00007fa9d6dcf791  vmovaps [rsp+0x20], xmm11
00007fa9d6dcf797  vmovaps xmm10, [rsp+0x20]
00007fa9d6dcf79d  por xmm11, xmm10
00007fa9d6dcf7a2  vmovaps [rsp+0x20], xmm4
00007fa9d6dcf7a8  vmovaps xmm10, [rsp+0x20]
00007fa9d6dcf7ae  por xmm4, xmm10
00007fa9d6dcf7b3  vmovaps [rsp+0x20], xmm8
00007fa9d6dcf7b9  vmovaps xmm10, [rsp+0x20]
00007fa9d6dcf7bf  por xmm8, xmm10
00007fa9d6dcf7c4  vmovaps xmm10, [rsp+0xF0]
00007fa9d6dcf7cd  vmovaps [rsp+0x20], xmm1
00007fa9d6dcf7d3  vmovaps xmm1, [rsp+0xF0]
00007fa9d6dcf7dc  por xmm10, xmm1
00007fa9d6dcf7e1  lea rax, [r14+0xA0]
00007fa9d6dcf7e8  movups xmm1, [r13+rax*1]
00007fa9d6dcf7ee  lea rax, [r14+0xB0]
00007fa9d6dcf7f5  vmovaps [rsp+0x30], xmm1
00007fa9d6dcf7fb  movups xmm1, [r13+rax*1]
00007fa9d6dcf801  vmovaps [rsp+0xF0], xmm1
00007fa9d6dcf80a  vmovaps [rsp+0x120], xmm15
00007fa9d6dcf813  movaps xmm1, xmm13
00007fa9d6dcf817  addpd xmm1, xmm2
00007fa9d6dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa9d6dcf820  ptest xmm15, xmm15
00007fa9d6dcf826  jnz 0x00007FA9D6DD11ED
00007fa9d6dcf82c  lea rax, [r14+0xF0]
00007fa9d6dcf833  movups xmm15, [r13+rax*1]
00007fa9d6dcf839  vmovaps xmm2, [rsp+0xC0]
00007fa9d6dcf842  vmovaps [rsp+0xC0], xmm1
00007fa9d6dcf84b  vmovaps xmm1, [rsp+0xE0]
00007fa9d6dcf854  vmovaps [rsp+0xE0], xmm15
00007fa9d6dcf85d  movaps xmm13, xmm2
00007fa9d6dcf861  addpd xmm13, xmm1
00007fa9d6dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007fa9d6dcf86c  ptest xmm15, xmm15
00007fa9d6dcf872  jnz 0x00007FA9D6DD1338
00007fa9d6dcf878  vmovaps xmm15, [rsp+0x120]
00007fa9d6dcf881  vmovaps xmm2, [rsp+0xD0]
00007fa9d6dcf88a  vmovaps [rsp+0xD0], xmm14
00007fa9d6dcf893  movaps xmm1, xmm15
00007fa9d6dcf897  addpd xmm1, xmm2
00007fa9d6dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa9d6dcf8a0  ptest xmm14, xmm14
00007fa9d6dcf8a6  jnz 0x00007FA9D6DD147A
00007fa9d6dcf8ac  vmovaps xmm15, [rsp+0x100]
00007fa9d6dcf8b5  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dcf8bb  vmovaps xmm2, [rsp+0xF0]
00007fa9d6dcf8c4  vmovaps [rsp+0xF0], xmm1
00007fa9d6dcf8cd  movaps xmm14, xmm2
00007fa9d6dcf8d1  mulpd xmm14, xmm15
00007fa9d6dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007fa9d6dcf8dc  ptest xmm1, xmm1
00007fa9d6dcf8e1  jnz 0x00007FA9D6DD15BB
00007fa9d6dcf8e7  vmovaps xmm1, [rsp+0xA0]
00007fa9d6dcf8f0  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dcf8f6  vmovaps xmm2, [rsp+0xE0]
00007fa9d6dcf8ff  vmovaps [rsp+0xE0], xmm14
00007fa9d6dcf908  movaps xmm15, xmm2
00007fa9d6dcf90c  mulpd xmm15, xmm1
00007fa9d6dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa9d6dcf917  ptest xmm14, xmm14
00007fa9d6dcf91d  jnz 0x00007FA9D6DD16FE
00007fa9d6dcf923  lea rax, [r14+0xE0]
00007fa9d6dcf92a  movups xmm1, [r13+rax*1]
00007fa9d6dcf930  vmovaps xmm14, [rsp+0x100]
00007fa9d6dcf939  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dcf93f  vmovaps [rsp+0x100], xmm1
00007fa9d6dcf948  vmovaps xmm1, [rsp+0x30]
00007fa9d6dcf94e  vmovaps [rsp+0x30], xmm15
00007fa9d6dcf954  movaps xmm2, xmm1
00007fa9d6dcf957  mulpd xmm2, xmm14
00007fa9d6dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007fa9d6dcf961  ptest xmm15, xmm15
00007fa9d6dcf967  jnz 0x00007FA9D6DD184A
00007fa9d6dcf96d  vmovaps [rsp+0x120], xmm10
00007fa9d6dcf976  vmovaps xmm1, [rsp+0x120]
00007fa9d6dcf97f  por xmm10, xmm1
00007fa9d6dcf984  movaps [r15+0x300], xmm10
00007fa9d6dcf98c  vmovaps [rsp+0x120], xmm8
00007fa9d6dcf995  vmovaps xmm1, [rsp+0x120]
00007fa9d6dcf99e  por xmm8, xmm1
00007fa9d6dcf9a3  movaps [r15+0x190], xmm8
00007fa9d6dcf9ab  vmovaps xmm1, [rsp+0xA0]
00007fa9d6dcf9b4  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dcf9ba  vmovaps xmm14, [rsp+0x100]
00007fa9d6dcf9c3  vmovaps [rsp+0x100], xmm13
00007fa9d6dcf9cc  movaps xmm15, xmm14
00007fa9d6dcf9d0  mulpd xmm15, xmm1
00007fa9d6dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa9d6dcf9db  ptest xmm13, xmm13
00007fa9d6dcf9e1  jnz 0x00007FA9D6DD198B
00007fa9d6dcf9e7  lea rax, [r14+0x90]
00007fa9d6dcf9ee  movups xmm1, [r13+rax*1]
00007fa9d6dcf9f4  vmovaps [rsp+0x120], xmm4
00007fa9d6dcf9fd  vmovaps xmm14, [rsp+0x120]
00007fa9d6dcfa06  por xmm4, xmm14
00007fa9d6dcfa0b  movaps [r15+0x1C0], xmm4
00007fa9d6dcfa13  vmovaps [rsp+0x120], xmm11
00007fa9d6dcfa1c  vmovaps xmm14, [rsp+0x120]
00007fa9d6dcfa25  por xmm11, xmm14
00007fa9d6dcfa2a  movaps [r15+0x200], xmm11
00007fa9d6dcfa32  vmovaps [rsp+0x120], xmm5
00007fa9d6dcfa3b  vmovaps xmm14, [rsp+0x120]
00007fa9d6dcfa44  por xmm5, xmm14
00007fa9d6dcfa49  movaps [r15+0x2D0], xmm5
00007fa9d6dcfa51  vmovaps [rsp+0x120], xmm12
00007fa9d6dcfa5a  vmovaps xmm14, [rsp+0x120]
00007fa9d6dcfa63  por xmm12, xmm14
00007fa9d6dcfa68  movaps [r15+0x2E0], xmm12
00007fa9d6dcfa70  vmovaps xmm13, [rsp+0x110]
00007fa9d6dcfa79  vmovaps [rsp+0x110], xmm1
00007fa9d6dcfa82  vmovaps xmm1, [rsp+0xE0]
00007fa9d6dcfa8b  vmovaps [rsp+0xE0], xmm15
00007fa9d6dcfa94  movaps xmm14, xmm13
00007fa9d6dcfa98  addpd xmm14, xmm1
00007fa9d6dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007fa9d6dcfaa3  ptest xmm15, xmm15
00007fa9d6dcfaa9  jnz 0x00007FA9D6DD1AD8
00007fa9d6dcfaaf  vmovaps xmm1, [rsp+0xA0]
00007fa9d6dcfab8  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dcfabe  vmovaps xmm13, [rsp+0x110]
00007fa9d6dcfac7  vmovaps [rsp+0x110], xmm14
00007fa9d6dcfad0  movaps xmm15, xmm13
00007fa9d6dcfad4  mulpd xmm15, xmm1
00007fa9d6dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa9d6dcfadf  ptest xmm14, xmm14
00007fa9d6dcfae5  jnz 0x00007FA9D6DD1C1B
00007fa9d6dcfaeb  lea rax, [r14+0x80]
00007fa9d6dcfaf2  movups xmm1, [r13+rax*1]
00007fa9d6dcfaf8  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dcfb01  vmovaps [rsp+0xC0], xmm1
00007fa9d6dcfb0a  movaps xmm14, xmm13
00007fa9d6dcfb0e  addpd xmm14, xmm2
00007fa9d6dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007fa9d6dcfb19  ptest xmm1, xmm1
00007fa9d6dcfb1e  jnz 0x00007FA9D6DD1D68
00007fa9d6dcfb24  vmovaps xmm13, [rsp+0x100]
00007fa9d6dcfb2d  vmovaps xmm2, [rsp+0x30]
00007fa9d6dcfb33  vmovaps [rsp+0x30], xmm15
00007fa9d6dcfb39  movaps xmm1, xmm13
00007fa9d6dcfb3d  addpd xmm1, xmm2
00007fa9d6dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa9d6dcfb46  ptest xmm15, xmm15
00007fa9d6dcfb4c  jnz 0x00007FA9D6DD1EAB
00007fa9d6dcfb52  vmovaps xmm15, [rsp+0x20]
00007fa9d6dcfb58  vmovaps xmm13, [rsp+0x20]
00007fa9d6dcfb5e  por xmm15, xmm13
00007fa9d6dcfb63  movaps [r15+0x2F0], xmm15
00007fa9d6dcfb6b  vmovaps xmm13, [rsp+0xA0]
00007fa9d6dcfb74  vpermilpd xmm13, xmm13, 0x00
00007fa9d6dcfb7a  vmovaps [rsp+0x20], xmm1
00007fa9d6dcfb80  vmovaps xmm1, [rsp+0xC0]
00007fa9d6dcfb89  vmovaps [rsp+0xA0], xmm15
00007fa9d6dcfb92  movaps xmm2, xmm1
00007fa9d6dcfb95  mulpd xmm2, xmm13
00007fa9d6dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007fa9d6dcfb9f  ptest xmm15, xmm15
00007fa9d6dcfba5  jnz 0x00007FA9D6DD1FEC
00007fa9d6dcfbab  lea rax, [r14+0xD0]
00007fa9d6dcfbb2  movups xmm1, [r13+rax*1]
00007fa9d6dcfbb8  vmovaps xmm13, [rsp+0xF0]
00007fa9d6dcfbc1  vmovaps [rsp+0xC0], xmm1
00007fa9d6dcfbca  vmovaps xmm1, [rsp+0xE0]
00007fa9d6dcfbd3  vmovaps [rsp+0xE0], xmm14
00007fa9d6dcfbdc  movaps xmm15, xmm13
00007fa9d6dcfbe0  addpd xmm15, xmm1
00007fa9d6dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa9d6dcfbeb  ptest xmm14, xmm14
00007fa9d6dcfbf1  jnz 0x00007FA9D6DD2137
00007fa9d6dcfbf7  vmovaps xmm1, [rsp+0xB0]
00007fa9d6dcfc00  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dcfc06  movaps xmm14, xmm11
00007fa9d6dcfc0a  mulpd xmm14, xmm1
00007fa9d6dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007fa9d6dcfc15  ptest xmm13, xmm13
00007fa9d6dcfc1b  jnz 0x00007FA9D6DD227A
00007fa9d6dcfc21  movaps [r15+0x260], xmm14
00007fa9d6dcfc29  vxorps xmm1, xmm1, xmm1
00007fa9d6dcfc2d  vpbroadcastq xmm1, xmm1
00007fa9d6dcfc32  movaps [r15+0x1B0], xmm1
00007fa9d6dcfc3a  vmovaps xmm1, [rsp+0xB0]
00007fa9d6dcfc43  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dcfc49  vmovaps xmm11, [rsp+0xC0]
00007fa9d6dcfc52  vmovaps [rsp+0xC0], xmm15
00007fa9d6dcfc5b  movaps xmm13, xmm11
00007fa9d6dcfc5f  mulpd xmm13, xmm1
00007fa9d6dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007fa9d6dcfc6a  ptest xmm15, xmm15
00007fa9d6dcfc70  jnz 0x00007FA9D6DD23BD
00007fa9d6dcfc76  lea rax, [r14+0xC0]
00007fa9d6dcfc7d  movups xmm1, [r13+rax*1]
00007fa9d6dcfc83  vmovaps xmm11, [rsp+0x110]
00007fa9d6dcfc8c  vmovaps [rsp+0xF0], xmm1
00007fa9d6dcfc95  vmovaps xmm1, [rsp+0x30]
00007fa9d6dcfc9b  vmovaps [rsp+0x30], xmm14
00007fa9d6dcfca1  movaps xmm15, xmm11
00007fa9d6dcfca5  addpd xmm15, xmm1
00007fa9d6dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007fa9d6dcfcb0  ptest xmm14, xmm14
00007fa9d6dcfcb6  jnz 0x00007FA9D6DD250A
00007fa9d6dcfcbc  vmovaps [rsp+0x100], xmm9
00007fa9d6dcfcc5  vmovaps xmm1, [rsp+0x100]
00007fa9d6dcfcce  por xmm9, xmm1
00007fa9d6dcfcd3  movaps [r15+0x270], xmm9
00007fa9d6dcfcdb  vmovaps [rsp+0x100], xmm6
00007fa9d6dcfce4  vmovaps xmm1, [rsp+0x100]
00007fa9d6dcfced  por xmm6, xmm1
00007fa9d6dcfcf1  movaps [r15+0x1A0], xmm6
00007fa9d6dcfcf9  vmovaps xmm14, [rsp+0xB0]
00007fa9d6dcfd02  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dcfd08  vmovaps xmm6, [rsp+0xF0]
00007fa9d6dcfd11  vmovaps [rsp+0xF0], xmm1
00007fa9d6dcfd1a  movaps xmm11, xmm6
00007fa9d6dcfd1e  mulpd xmm11, xmm14
00007fa9d6dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007fa9d6dcfd29  ptest xmm1, xmm1
00007fa9d6dcfd2e  jnz 0x00007FA9D6DD264D
00007fa9d6dcfd34  lea rax, [r14+0x20]
00007fa9d6dcfd38  movups xmm1, [r13+rax*1]
00007fa9d6dcfd3e  movaps [r15+0x110], xmm1
00007fa9d6dcfd46  vmovaps xmm6, [rsp+0xE0]
00007fa9d6dcfd4f  vmovaps [rsp+0xE0], xmm1
00007fa9d6dcfd58  movaps xmm14, xmm6
00007fa9d6dcfd5c  addpd xmm14, xmm2
00007fa9d6dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007fa9d6dcfd67  ptest xmm1, xmm1
00007fa9d6dcfd6c  jnz 0x00007FA9D6DD279A
00007fa9d6dcfd72  vmovaps xmm1, [rsp+0xB0]
00007fa9d6dcfd7b  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dcfd81  movaps xmm6, xmm5
00007fa9d6dcfd84  mulpd xmm6, xmm1
00007fa9d6dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007fa9d6dcfd8d  ptest xmm2, xmm2
00007fa9d6dcfd92  jnz 0x00007FA9D6DD28DC
00007fa9d6dcfd98  vmovaps xmm5, [rsp+0x20]
00007fa9d6dcfd9e  movaps xmm1, xmm5
00007fa9d6dcfda1  addpd xmm1, xmm13
00007fa9d6dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa9d6dcfdab  ptest xmm2, xmm2
00007fa9d6dcfdb0  jnz 0x00007FA9D6DD2A1C
00007fa9d6dcfdb6  vmovaps xmm13, [rsp+0x80]
00007fa9d6dcfdbf  vpermilpd xmm13, xmm13, 0x00
00007fa9d6dcfdc5  vmovaps xmm2, [rsp+0xE0]
00007fa9d6dcfdce  vmovaps [rsp+0x20], xmm1
00007fa9d6dcfdd4  movaps xmm5, xmm2
00007fa9d6dcfdd7  mulpd xmm5, xmm13
00007fa9d6dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007fa9d6dcfde1  ptest xmm1, xmm1
00007fa9d6dcfde6  jnz 0x00007FA9D6DD2B5D
00007fa9d6dcfdec  vmovaps xmm1, [rsp+0x80]
00007fa9d6dcfdf5  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dcfdfb  movaps xmm13, xmm10
00007fa9d6dcfdff  mulpd xmm13, xmm1
00007fa9d6dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007fa9d6dcfe0a  ptest xmm2, xmm2
00007fa9d6dcfe0f  jnz 0x00007FA9D6DD2C9E
00007fa9d6dcfe15  vmovaps xmm10, [rsp+0x30]
00007fa9d6dcfe1b  movaps xmm1, xmm15
00007fa9d6dcfe1f  addpd xmm1, xmm10
00007fa9d6dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa9d6dcfe29  ptest xmm2, xmm2
00007fa9d6dcfe2e  jnz 0x00007FA9D6DD2DE1
00007fa9d6dcfe34  vmovaps xmm10, [rsp+0xC0]
00007fa9d6dcfe3d  movaps xmm15, xmm10
00007fa9d6dcfe41  addpd xmm15, xmm11
00007fa9d6dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007fa9d6dcfe4c  ptest xmm2, xmm2
00007fa9d6dcfe51  jnz 0x00007FA9D6DD2F23
00007fa9d6dcfe57  vmovaps xmm11, [rsp+0x80]
00007fa9d6dcfe60  vpermilpd xmm11, xmm11, 0x00
00007fa9d6dcfe66  movaps xmm10, xmm12
00007fa9d6dcfe6a  mulpd xmm10, xmm11
00007fa9d6dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007fa9d6dcfe75  ptest xmm2, xmm2
00007fa9d6dcfe7a  jnz 0x00007FA9D6DD3067
00007fa9d6dcfe80  vmovaps xmm12, [rsp+0x80]
00007fa9d6dcfe89  vpermilpd xmm12, xmm12, 0x00
00007fa9d6dcfe8f  vmovaps xmm2, [rsp+0xA0]
00007fa9d6dcfe98  vmovaps [rsp+0x30], xmm1
00007fa9d6dcfe9e  movaps xmm11, xmm2
00007fa9d6dcfea2  mulpd xmm11, xmm12
00007fa9d6dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007fa9d6dcfead  ptest xmm1, xmm1
00007fa9d6dcfeb2  jnz 0x00007FA9D6DD31AB
00007fa9d6dcfeb8  movaps xmm1, xmm14
00007fa9d6dcfebc  addpd xmm1, xmm6
00007fa9d6dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa9d6dcfec5  ptest xmm12, xmm12
00007fa9d6dcfecb  jnz 0x00007FA9D6DD32EE
00007fa9d6dcfed1  vmovaps xmm12, [rsp+0x20]
00007fa9d6dcfed7  movaps xmm14, xmm12
00007fa9d6dcfedb  addpd xmm14, xmm5
00007fa9d6dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa9d6dcfee6  ptest xmm6, xmm6
00007fa9d6dcfeeb  jnz 0x00007FA9D6DD342F
00007fa9d6dcfef1  vmovaps xmm12, [rsp+0x90]
00007fa9d6dcfefa  vpermilpd xmm12, xmm12, 0x00
00007fa9d6dcff00  movaps xmm6, xmm9
00007fa9d6dcff04  mulpd xmm6, xmm12
00007fa9d6dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa9d6dcff0e  ptest xmm5, xmm5
00007fa9d6dcff13  jnz 0x00007FA9D6DD3572
00007fa9d6dcff19  movaps xmm12, xmm15
00007fa9d6dcff1d  addpd xmm12, xmm13
00007fa9d6dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa9d6dcff28  ptest xmm9, xmm9
00007fa9d6dcff2e  jnz 0x00007FA9D6DD36B4
00007fa9d6dcff34  vmovaps xmm13, [rsp+0x30]
00007fa9d6dcff3a  movaps xmm15, xmm13
00007fa9d6dcff3e  addpd xmm15, xmm10
00007fa9d6dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa9d6dcff49  ptest xmm9, xmm9
00007fa9d6dcff4f  jnz 0x00007FA9D6DD37F8
00007fa9d6dcff55  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dcff5e  vmovaps xmm10, [rsp+0xD0]
00007fa9d6dcff67  por xmm13, xmm10
00007fa9d6dcff6c  movaps [r15+0x250], xmm13
00007fa9d6dcff74  vmovaps [rsp+0x20], xmm7
00007fa9d6dcff7a  vmovaps xmm13, [rsp+0x20]
00007fa9d6dcff80  por xmm7, xmm13
00007fa9d6dcff85  movaps [r15+0x2A0], xmm7
00007fa9d6dcff8d  vmovaps [rsp+0x20], xmm3
00007fa9d6dcff93  vmovaps xmm13, [rsp+0x20]
00007fa9d6dcff99  por xmm3, xmm13
00007fa9d6dcff9e  movaps [r15+0x1D0], xmm3
00007fa9d6dcffa6  lea rax, [r14+0x40]
00007fa9d6dcffaa  movups xmm13, [r13+rax*1]
00007fa9d6dcffb0  movaps [r15+0x2C0], xmm13
00007fa9d6dcffb8  vmovaps xmm10, [rsp+0x90]
00007fa9d6dcffc1  vpermilpd xmm10, xmm10, 0x00
00007fa9d6dcffc7  movaps xmm9, xmm8
00007fa9d6dcffcb  mulpd xmm9, xmm10
00007fa9d6dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007fa9d6dcffd6  ptest xmm5, xmm5
00007fa9d6dcffdb  jnz 0x00007FA9D6DD3946
00007fa9d6dcffe1  movaps xmm10, xmm1
00007fa9d6dcffe5  addpd xmm10, xmm11
00007fa9d6dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007fa9d6dcfff0  ptest xmm8, xmm8
00007fa9d6dcfff6  jnz 0x00007FA9D6DD3A8A
00007fa9d6dcfffc  movaps xmm1, xmm14
00007fa9d6dd0000  addpd xmm1, xmm6
00007fa9d6dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007fa9d6dd0009  ptest xmm11, xmm11
00007fa9d6dd000f  jnz 0x00007FA9D6DD3BCD
00007fa9d6dd0015  vmovaps xmm14, [rsp+0x90]
00007fa9d6dd001e  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dd0024  movaps xmm11, xmm13
00007fa9d6dd0028  mulpd xmm11, xmm14
00007fa9d6dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007fa9d6dd0033  ptest xmm8, xmm8
00007fa9d6dd0039  jnz 0x00007FA9D6DD3D0E
00007fa9d6dd003f  vmovaps xmm14, [rsp+0x90]
00007fa9d6dd0048  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dd004e  vmovaps xmm8, [rsp+0x10]
00007fa9d6dd0054  movaps xmm13, xmm8
00007fa9d6dd0058  mulpd xmm13, xmm14
00007fa9d6dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007fa9d6dd0063  ptest xmm6, xmm6
00007fa9d6dd0068  jnz 0x00007FA9D6DD3E52
00007fa9d6dd006e  vmovaps xmm14, [rsp+0x60]
00007fa9d6dd0074  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dd007a  movaps xmm8, xmm7
00007fa9d6dd007e  mulpd xmm8, xmm14
00007fa9d6dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa9d6dd0089  ptest xmm6, xmm6
00007fa9d6dd008e  jnz 0x00007FA9D6DD3F96
00007fa9d6dd0094  movaps xmm14, xmm12
00007fa9d6dd0098  addpd xmm14, xmm9
00007fa9d6dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007fa9d6dd00a3  ptest xmm7, xmm7
00007fa9d6dd00a8  jnz 0x00007FA9D6DD40D9
00007fa9d6dd00ae  vmovaps xmm12, [rsp+0x60]
00007fa9d6dd00b4  vpermilpd xmm12, xmm12, 0x00
00007fa9d6dd00ba  vmovaps xmm7, [rsp+0xF0]
00007fa9d6dd00c3  movaps xmm9, xmm7
00007fa9d6dd00c7  mulpd xmm9, xmm12
00007fa9d6dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa9d6dd00d2  ptest xmm6, xmm6
00007fa9d6dd00d7  jnz 0x00007FA9D6DD421D
00007fa9d6dd00dd  movaps xmm12, xmm15
00007fa9d6dd00e1  addpd xmm12, xmm11
00007fa9d6dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007fa9d6dd00ec  ptest xmm7, xmm7
00007fa9d6dd00f1  jnz 0x00007FA9D6DD4360
00007fa9d6dd00f7  vmovaps xmm15, [rsp+0x60]
00007fa9d6dd00fd  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dd0103  vmovaps xmm7, [rsp+0x40]
00007fa9d6dd0109  movaps xmm11, xmm7
00007fa9d6dd010d  mulpd xmm11, xmm15
00007fa9d6dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007fa9d6dd0118  ptest xmm6, xmm6
00007fa9d6dd011d  jnz 0x00007FA9D6DD44A4
00007fa9d6dd0123  movaps xmm15, xmm10
00007fa9d6dd0127  addpd xmm15, xmm13
00007fa9d6dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007fa9d6dd0132  ptest xmm7, xmm7
00007fa9d6dd0137  jnz 0x00007FA9D6DD45E7
00007fa9d6dd013d  vmovaps xmm13, [rsp+0x60]
00007fa9d6dd0143  vpermilpd xmm13, xmm13, 0x00
00007fa9d6dd0149  vmovaps xmm7, [rsp+0x50]
00007fa9d6dd014f  movaps xmm10, xmm7
00007fa9d6dd0153  mulpd xmm10, xmm13
00007fa9d6dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa9d6dd015e  ptest xmm6, xmm6
00007fa9d6dd0163  jnz 0x00007FA9D6DD472B
00007fa9d6dd0169  movaps xmm13, xmm1
00007fa9d6dd016d  addpd xmm13, xmm8
00007fa9d6dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007fa9d6dd0178  ptest xmm7, xmm7
00007fa9d6dd017d  jnz 0x00007FA9D6DD486E
00007fa9d6dd0183  lea rax, [r14+0x70]
00007fa9d6dd0187  movups xmm1, [r13+rax*1]
00007fa9d6dd018d  movaps [r15+0x240], xmm1
00007fa9d6dd0195  movaps xmm8, xmm14
00007fa9d6dd0199  addpd xmm8, xmm9
00007fa9d6dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa9d6dd01a4  ptest xmm7, xmm7
00007fa9d6dd01a9  jnz 0x00007FA9D6DD49BB
00007fa9d6dd01af  movaps [r15+0x170], xmm8
00007fa9d6dd01b7  vmovaps xmm14, [rsp+0x70]
00007fa9d6dd01bd  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dd01c3  movaps xmm9, xmm1
00007fa9d6dd01c7  mulpd xmm9, xmm14
00007fa9d6dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007fa9d6dd01d2  ptest xmm7, xmm7
00007fa9d6dd01d7  jnz 0x00007FA9D6DD4AFF
00007fa9d6dd01dd  vmovaps xmm1, [rsp+0x70]
00007fa9d6dd01e3  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd01e9  movaps xmm14, xmm4
00007fa9d6dd01ed  mulpd xmm14, xmm1
00007fa9d6dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007fa9d6dd01f8  ptest xmm7, xmm7
00007fa9d6dd01fd  jnz 0x00007FA9D6DD4C42
00007fa9d6dd0203  movaps [r15+0x180], xmm14
00007fa9d6dd020b  movaps xmm1, xmm12
00007fa9d6dd020f  addpd xmm1, xmm11
00007fa9d6dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007fa9d6dd0219  ptest xmm7, xmm7
00007fa9d6dd021e  jnz 0x00007FA9D6DD4D84
00007fa9d6dd0224  movaps [r15+0x210], xmm1
00007fa9d6dd022c  movups xmm12, [r13+r14*1]
00007fa9d6dd0232  lea rax, [r14+0x10]
00007fa9d6dd0236  movups xmm11, [r13+rax*1]
00007fa9d6dd023c  movaps [r15+0x230], xmm11
00007fa9d6dd0244  movaps xmm7, xmm15
00007fa9d6dd0248  addpd xmm7, xmm10
00007fa9d6dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa9d6dd0252  ptest xmm6, xmm6
00007fa9d6dd0257  jnz 0x00007FA9D6DD4EDA
00007fa9d6dd025d  movaps [r15+0x130], xmm7
00007fa9d6dd0265  vmovaps xmm15, [rsp+0x70]
00007fa9d6dd026b  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dd0271  movaps xmm10, xmm11
00007fa9d6dd0275  mulpd xmm10, xmm15
00007fa9d6dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa9d6dd0280  ptest xmm6, xmm6
00007fa9d6dd0285  jnz 0x00007FA9D6DD501C
00007fa9d6dd028b  movaps [r15+0x220], xmm10
00007fa9d6dd0293  vmovaps xmm15, [rsp+0x70]
00007fa9d6dd0299  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dd029f  movaps xmm11, xmm12
00007fa9d6dd02a3  mulpd xmm11, xmm15
00007fa9d6dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007fa9d6dd02ae  ptest xmm6, xmm6
00007fa9d6dd02b3  jnz 0x00007FA9D6DD5160
00007fa9d6dd02b9  movaps xmm15, xmm13
00007fa9d6dd02bd  addpd xmm15, xmm9
00007fa9d6dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007fa9d6dd02c8  ptest xmm12, xmm12
00007fa9d6dd02ce  jnz 0x00007FA9D6DD52A4
00007fa9d6dd02d4  movaps [r15+0x140], xmm15
00007fa9d6dd02dc  movaps xmm13, xmm8
00007fa9d6dd02e0  addpd xmm13, xmm14
00007fa9d6dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa9d6dd02eb  ptest xmm12, xmm12
00007fa9d6dd02f1  jnz 0x00007FA9D6DD53E8
00007fa9d6dd02f7  movaps [r15+0x150], xmm13
00007fa9d6dd02ff  movaps xmm14, xmm1
00007fa9d6dd0303  addpd xmm14, xmm10
00007fa9d6dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007fa9d6dd030e  ptest xmm12, xmm12
00007fa9d6dd0314  jnz 0x00007FA9D6DD552C
00007fa9d6dd031a  movaps [r15+0x160], xmm14
00007fa9d6dd0322  movaps xmm1, xmm7
00007fa9d6dd0325  addpd xmm1, xmm11
00007fa9d6dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa9d6dd032f  ptest xmm12, xmm12
00007fa9d6dd0335  jnz 0x00007FA9D6DD566F
00007fa9d6dd033b  movaps [r15+0x120], xmm1
00007fa9d6dd0343  mov eax, 0x430920
00007fa9d6dd0348  movups [r13+rax*1], xmm15
00007fa9d6dd034e  mov eax, 0x430930
00007fa9d6dd0353  movups [r13+rax*1], xmm13
00007fa9d6dd0359  mov eax, 0x430940
00007fa9d6dd035e  movups [r13+rax*1], xmm14
00007fa9d6dd0364  mov eax, 0x430950
00007fa9d6dd0369  movups [r13+rax*1], xmm1
00007fa9d6dd036f  mov eax, [r15+0x108]
00007fa9d6dd0376  sahf
00007fa9d6dd0377  jnz 0x00007FA9D6DD03A9
00007fa9d6dd0379  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dd0381  jz 0x00007FA9D6DDB900
00007fa9d6dd0387  nop [rax+rax*1], ax
00007fa9d6dd0390  nop [rax+rax*1], eax
00007fa9d6dd0398  mov eax, 0x410444
00007fa9d6dd039d  mov [r15+0x100], rax
00007fa9d6dd03a4  jmp 0x00007FA9D6BFE110
00007fa9d6dd03a9  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dd03b1  jz 0x00007FA9D6DD57E0
00007fa9d6dd03b7  nop [rax+rax*1], ax
00007fa9d6dd03c0  nop [rax+rax*1], eax
00007fa9d6dd03c8  mov eax, 0x410278
00007fa9d6dd03cd  mov [r15+0x100], rax
00007fa9d6dd03d4  jmp 0x00007FA9D6BFE110
00007fa9d6dd03d9  int3
00007fa9d6dd03da  call 0x00007FA9D6CB52F0
00007fa9d6dd03df  jmp 0x00007FA9D6DCF016
00007fa9d6dd03e4  call 0x00007FA9D6CC4620
00007fa9d6dd03e9  jmp 0x00007FA9D6DCF023
00007fa9d6dd03ee  call 0x00007FA9D6CC33A0
00007fa9d6dd03f3  jmp 0x00007FA9D6DCF035
00007fa9d6dd03f8  call 0x00007FA9D6CC2120
00007fa9d6dd03fd  jmp 0x00007FA9D6DCF03F
00007fa9d6dd0402  call 0x00007FA9D6CC0860
00007fa9d6dd0407  jmp 0x00007FA9D6DCF067
00007fa9d6dd040c  call 0x00007FA9D6CBF5F0
00007fa9d6dd0411  jmp 0x00007FA9D6DCF073
00007fa9d6dd0416  call 0x00007FA9D6CC0860
00007fa9d6dd041b  jmp 0x00007FA9D6DCF0A5
00007fa9d6dd0420  call 0x00007FA9D6CBF5F0
00007fa9d6dd0425  jmp 0x00007FA9D6DCF0B1
00007fa9d6dd042a  call 0x00007FA9D6CC4740
00007fa9d6dd042f  jmp 0x00007FA9D6DCF0BE
00007fa9d6dd0434  call 0x00007FA9D6CB5400
00007fa9d6dd0439  jmp 0x00007FA9D6DCF0CB
00007fa9d6dd043e  call 0x00007FA9D6CB52F0
00007fa9d6dd0443  jmp 0x00007FA9D6DCF0D8
00007fa9d6dd0448  call 0x00007FA9D6CC4620
00007fa9d6dd044d  jmp 0x00007FA9D6DCF0E5
00007fa9d6dd0452  call 0x00007FA9D6CC0860
00007fa9d6dd0457  jmp 0x00007FA9D6DCF10D
00007fa9d6dd045c  call 0x00007FA9D6CBF5F0
00007fa9d6dd0461  jmp 0x00007FA9D6DCF119
00007fa9d6dd0466  call 0x00007FA9D6C09D70
00007fa9d6dd046b  jmp 0x00007FA9D6DCF11F
00007fa9d6dd0470  call 0x00007FA9D6CBE9C0
00007fa9d6dd0475  jmp 0x00007FA9D6DCF129
00007fa9d6dd047a  call 0x00007FA9D6CC0860
00007fa9d6dd047f  jmp 0x00007FA9D6DCF151
00007fa9d6dd0484  call 0x00007FA9D6CBF5F0
00007fa9d6dd0489  jmp 0x00007FA9D6DCF15D
00007fa9d6dd048e  call 0x00007FA9D6CBD750
00007fa9d6dd0493  jmp 0x00007FA9D6DCF16A
00007fa9d6dd0498  call 0x00007FA9D6CBC4E0
00007fa9d6dd049d  jmp 0x00007FA9D6DCF177
00007fa9d6dd04a2  call 0x00007FA9D6CC4740
00007fa9d6dd04a7  jmp 0x00007FA9D6DCF184
00007fa9d6dd04ac  call 0x00007FA9D6CB5400
00007fa9d6dd04b1  jmp 0x00007FA9D6DCF191
00007fa9d6dd04b6  call 0x00007FA9D6CB52F0
00007fa9d6dd04bb  jmp 0x00007FA9D6DCF19E
00007fa9d6dd04c0  call 0x00007FA9D6CC4620
00007fa9d6dd04c5  jmp 0x00007FA9D6DCF1AB
00007fa9d6dd04ca  call 0x00007FA9D6CC0860
00007fa9d6dd04cf  jmp 0x00007FA9D6DCF1BE
00007fa9d6dd04d4  call 0x00007FA9D6CBB270
00007fa9d6dd04d9  jmp 0x00007FA9D6DCF1CB
00007fa9d6dd04de  call 0x00007FA9D6CBA000
00007fa9d6dd04e3  jmp 0x00007FA9D6DCF1D8
00007fa9d6dd04e8  call 0x00007FA9D6CB8D90
00007fa9d6dd04ed  jmp 0x00007FA9D6DCF1E5
00007fa9d6dd04f2  call 0x00007FA9D6CB8A20
00007fa9d6dd04f7  jmp 0x00007FA9D6DCF1F2
00007fa9d6dd04fc  call 0x00007FA9D6CB5400
00007fa9d6dd0501  jmp 0x00007FA9D6DCF1FC
00007fa9d6dd0506  call 0x00007FA9D6CC2240
00007fa9d6dd050b  jmp 0x00007FA9D6DCF206
00007fa9d6dd0510  call 0x00007FA9D6CB52F0
00007fa9d6dd0515  jmp 0x00007FA9D6DCF210
00007fa9d6dd051a  call 0x00007FA9D6CC2120
00007fa9d6dd051f  jmp 0x00007FA9D6DCF21A
00007fa9d6dd0524  call 0x00007FA9D6CB77B0
00007fa9d6dd0529  jmp 0x00007FA9D6DCF224
00007fa9d6dd052e  call 0x00007FA9D6CB6550
00007fa9d6dd0533  jmp 0x00007FA9D6DCF22E
00007fa9d6dd0538  call 0x00007FA9D6CBFD50
00007fa9d6dd053d  jmp 0x00007FA9D6DCF240
00007fa9d6dd0542  call 0x00007FA9D6CB8EA0
00007fa9d6dd0547  jmp 0x00007FA9D6DCF24A
00007fa9d6dd054c  call 0x00007FA9D6CBFC30
00007fa9d6dd0551  jmp 0x00007FA9D6DCF257
00007fa9d6dd0556  call 0x00007FA9D6CB8D90
00007fa9d6dd055b  jmp 0x00007FA9D6DCF264
00007fa9d6dd0560  call 0x00007FA9D6CC2240
00007fa9d6dd0565  jmp 0x00007FA9D6DCF271
00007fa9d6dd056a  call 0x00007FA9D6CB5400
00007fa9d6dd056f  jmp 0x00007FA9D6DCF27E
00007fa9d6dd0574  call 0x00007FA9D6CB52F0
00007fa9d6dd0579  jmp 0x00007FA9D6DCF28B
00007fa9d6dd057e  call 0x00007FA9D6CC2120
00007fa9d6dd0583  jmp 0x00007FA9D6DCF298
00007fa9d6dd0588  call 0x00007FA9D6CB52F0
00007fa9d6dd058d  jmp 0x00007FA9D6DCF2AB
00007fa9d6dd0592  call 0x00007FA9D6CB52F0
00007fa9d6dd0597  jmp 0x00007FA9D6DCF2BE
00007fa9d6dd059c  call 0x00007FA9D6CB52F0
00007fa9d6dd05a1  jmp 0x00007FA9D6DCF2D1
00007fa9d6dd05a6  call 0x00007FA9D6CB52F0
00007fa9d6dd05ab  jmp 0x00007FA9D6DCF2E4
00007fa9d6dd05b0  call 0x00007FA9D6CC2240
00007fa9d6dd05b5  jmp 0x00007FA9D6DCF2F9
00007fa9d6dd05ba  call 0x00007FA9D6CC2240
00007fa9d6dd05bf  jmp 0x00007FA9D6DCF30C
00007fa9d6dd05c4  call 0x00007FA9D6CC2120
00007fa9d6dd05c9  jmp 0x00007FA9D6DCF319
00007fa9d6dd05ce  call 0x00007FA9D6CB52F0
00007fa9d6dd05d3  jmp 0x00007FA9D6DCF32C
00007fa9d6dd05d8  call 0x00007FA9D6CB52F0
00007fa9d6dd05dd  jmp 0x00007FA9D6DCF34F
00007fa9d6dd05e2  call 0x00007FA9D6CB52F0
00007fa9d6dd05e7  jmp 0x00007FA9D6DCF362
00007fa9d6dd05ec  call 0x00007FA9D6BFF540
00007fa9d6dd05f1  jmp 0x00007FA9D6DCF380
00007fa9d6dd05f6  call 0x00007FA9D6C08C20
00007fa9d6dd05fb  jmp 0x00007FA9D6DCF38A
00007fa9d6dd0600  call 0x00007FA9D6CD6600
00007fa9d6dd0605  jmp 0x00007FA9D6DCF396
00007fa9d6dd060a  call 0x00007FA9D6BFF540
00007fa9d6dd060f  jmp 0x00007FA9D6DCF3A6
00007fa9d6dd0614  call 0x00007FA9D6CC0370
00007fa9d6dd0619  jmp 0x00007FA9D6DCF3D4
00007fa9d6dd061e  call 0x00007FA9D6CBF100
00007fa9d6dd0623  jmp 0x00007FA9D6DCF3DD
00007fa9d6dd0628  call 0x00007FA9D6CC0370
00007fa9d6dd062d  jmp 0x00007FA9D6DCF43B
00007fa9d6dd0632  call 0x00007FA9D6CBF100
00007fa9d6dd0637  jmp 0x00007FA9D6DCF444
00007fa9d6dd063c  call 0x00007FA9D6CC0370
00007fa9d6dd0641  jmp 0x00007FA9D6DCF48B
00007fa9d6dd0646  call 0x00007FA9D6CBF100
00007fa9d6dd064b  jmp 0x00007FA9D6DCF494
00007fa9d6dd0650  call 0x00007FA9D6C0B720
00007fa9d6dd0655  jmp 0x00007FA9D6DCF4D7
00007fa9d6dd065a  call 0x00007FA9D6CB47C0
00007fa9d6dd065f  jmp 0x00007FA9D6DCF4EA
00007fa9d6dd0664  call 0x00007FA9D6C08B00
00007fa9d6dd0669  jmp 0x00007FA9D6DCF501
00007fa9d6dd066e  call 0x00007FA9D6BFF430
00007fa9d6dd0673  jmp 0x00007FA9D6DCF514
00007fa9d6dd0678  call 0x00007FA9D6BFF430
00007fa9d6dd067d  jmp 0x00007FA9D6DCF527
00007fa9d6dd0682  sub rsp, 0x08
00007fa9d6dd0686  push rax
00007fa9d6dd0687  push rcx
00007fa9d6dd0688  push rdx
00007fa9d6dd0689  push rdi
00007fa9d6dd068a  push rsi
00007fa9d6dd068b  push r8
00007fa9d6dd068d  push r9
00007fa9d6dd068f  push r10
00007fa9d6dd0691  push r11
00007fa9d6dd0693  sub rsp, 0xF0
00007fa9d6dd069a  vmovaps [rsp], xmm0
00007fa9d6dd069f  vmovaps [rsp+0x10], xmm2
00007fa9d6dd06a5  vmovaps [rsp+0x20], xmm3
00007fa9d6dd06ab  vmovaps [rsp+0x30], xmm4
00007fa9d6dd06b1  vmovaps [rsp+0x40], xmm5
00007fa9d6dd06b7  vmovaps [rsp+0x50], xmm6
00007fa9d6dd06bd  vmovaps [rsp+0x60], xmm7
00007fa9d6dd06c3  vmovaps [rsp+0x70], xmm8
00007fa9d6dd06c9  vmovaps [rsp+0x80], xmm9
00007fa9d6dd06d2  vmovaps [rsp+0x90], xmm10
00007fa9d6dd06db  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd06e4  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd06ed  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd06f6  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd06ff  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd0708  sub rsp, 0x30
00007fa9d6dd070c  movaps [rsp], xmm1
00007fa9d6dd0710  movaps [rsp+0x10], xmm15
00007fa9d6dd0716  movaps [rsp+0x20], xmm14
00007fa9d6dd071c  lea rdi, [rsp]
00007fa9d6dd0720  mov esi, 0x00
00007fa9d6dd0725  mov rax, 0x61DF872DB530
00007fa9d6dd072f  call rax
00007fa9d6dd0731  movaps xmm1, [rsp]
00007fa9d6dd0735  add rsp, 0x30
00007fa9d6dd0739  vmovaps xmm0, [rsp]
00007fa9d6dd073e  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd0744  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd074a  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd0750  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd0756  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd075c  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd0762  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd0768  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd0771  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd077a  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd0783  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd078c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd0795  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd079e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd07a7  add rsp, 0xF0
00007fa9d6dd07ae  pop r11
00007fa9d6dd07b0  pop r10
00007fa9d6dd07b2  pop r9
00007fa9d6dd07b4  pop r8
00007fa9d6dd07b6  pop rsi
00007fa9d6dd07b7  pop rdi
00007fa9d6dd07b8  pop rdx
00007fa9d6dd07b9  pop rcx
00007fa9d6dd07ba  pop rax
00007fa9d6dd07bb  add rsp, 0x08
00007fa9d6dd07bf  jmp 0x00007FA9D6DCF581
00007fa9d6dd07c4  sub rsp, 0x08
00007fa9d6dd07c8  push rax
00007fa9d6dd07c9  push rcx
00007fa9d6dd07ca  push rdx
00007fa9d6dd07cb  push rdi
00007fa9d6dd07cc  push rsi
00007fa9d6dd07cd  push r8
00007fa9d6dd07cf  push r9
00007fa9d6dd07d1  push r10
00007fa9d6dd07d3  push r11
00007fa9d6dd07d5  sub rsp, 0xF0
00007fa9d6dd07dc  vmovaps [rsp], xmm0
00007fa9d6dd07e1  vmovaps [rsp+0x10], xmm1
00007fa9d6dd07e7  vmovaps [rsp+0x20], xmm2
00007fa9d6dd07ed  vmovaps [rsp+0x30], xmm3
00007fa9d6dd07f3  vmovaps [rsp+0x40], xmm4
00007fa9d6dd07f9  vmovaps [rsp+0x50], xmm5
00007fa9d6dd07ff  vmovaps [rsp+0x60], xmm6
00007fa9d6dd0805  vmovaps [rsp+0x70], xmm7
00007fa9d6dd080b  vmovaps [rsp+0x80], xmm8
00007fa9d6dd0814  vmovaps [rsp+0x90], xmm9
00007fa9d6dd081d  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd0826  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd082f  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd0838  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd0841  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd084a  sub rsp, 0x30
00007fa9d6dd084e  movaps [rsp], xmm13
00007fa9d6dd0853  movaps [rsp+0x10], xmm1
00007fa9d6dd0858  movaps [rsp+0x20], xmm14
00007fa9d6dd085e  lea rdi, [rsp]
00007fa9d6dd0862  mov esi, 0x00
00007fa9d6dd0867  mov rax, 0x61DF872DB530
00007fa9d6dd0871  call rax
00007fa9d6dd0873  movaps xmm13, [rsp]
00007fa9d6dd0878  add rsp, 0x30
00007fa9d6dd087c  vmovaps xmm0, [rsp]
00007fa9d6dd0881  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd0887  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd088d  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd0893  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd0899  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd089f  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd08a5  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd08ab  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd08b4  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd08bd  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd08c6  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd08cf  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd08d8  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd08e1  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd08ea  add rsp, 0xF0
00007fa9d6dd08f1  pop r11
00007fa9d6dd08f3  pop r10
00007fa9d6dd08f5  pop r9
00007fa9d6dd08f7  pop r8
00007fa9d6dd08f9  pop rsi
00007fa9d6dd08fa  pop rdi
00007fa9d6dd08fb  pop rdx
00007fa9d6dd08fc  pop rcx
00007fa9d6dd08fd  pop rax
00007fa9d6dd08fe  add rsp, 0x08
00007fa9d6dd0902  jmp 0x00007FA9D6DCF5CF
00007fa9d6dd0907  sub rsp, 0x08
00007fa9d6dd090b  push rax
00007fa9d6dd090c  push rcx
00007fa9d6dd090d  push rdx
00007fa9d6dd090e  push rdi
00007fa9d6dd090f  push rsi
00007fa9d6dd0910  push r8
00007fa9d6dd0912  push r9
00007fa9d6dd0914  push r10
00007fa9d6dd0916  push r11
00007fa9d6dd0918  sub rsp, 0xF0
00007fa9d6dd091f  vmovaps [rsp], xmm0
00007fa9d6dd0924  vmovaps [rsp+0x10], xmm1
00007fa9d6dd092a  vmovaps [rsp+0x20], xmm2
00007fa9d6dd0930  vmovaps [rsp+0x30], xmm3
00007fa9d6dd0936  vmovaps [rsp+0x40], xmm4
00007fa9d6dd093c  vmovaps [rsp+0x50], xmm5
00007fa9d6dd0942  vmovaps [rsp+0x60], xmm6
00007fa9d6dd0948  vmovaps [rsp+0x70], xmm7
00007fa9d6dd094e  vmovaps [rsp+0x80], xmm8
00007fa9d6dd0957  vmovaps [rsp+0x90], xmm9
00007fa9d6dd0960  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd0969  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd0972  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd097b  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd0984  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd098d  sub rsp, 0x30
00007fa9d6dd0991  movaps [rsp], xmm15
00007fa9d6dd0996  movaps [rsp+0x10], xmm14
00007fa9d6dd099c  movaps [rsp+0x20], xmm1
00007fa9d6dd09a1  lea rdi, [rsp]
00007fa9d6dd09a5  mov esi, 0x00
00007fa9d6dd09aa  mov rax, 0x61DF872DB530
00007fa9d6dd09b4  call rax
00007fa9d6dd09b6  movaps xmm15, [rsp]
00007fa9d6dd09bb  add rsp, 0x30
00007fa9d6dd09bf  vmovaps xmm0, [rsp]
00007fa9d6dd09c4  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd09ca  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd09d0  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd09d6  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd09dc  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd09e2  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd09e8  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd09ee  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd09f7  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd0a00  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd0a09  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd0a12  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd0a1b  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd0a24  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd0a2d  add rsp, 0xF0
00007fa9d6dd0a34  pop r11
00007fa9d6dd0a36  pop r10
00007fa9d6dd0a38  pop r9
00007fa9d6dd0a3a  pop r8
00007fa9d6dd0a3c  pop rsi
00007fa9d6dd0a3d  pop rdi
00007fa9d6dd0a3e  pop rdx
00007fa9d6dd0a3f  pop rcx
00007fa9d6dd0a40  pop rax
00007fa9d6dd0a41  add rsp, 0x08
00007fa9d6dd0a45  jmp 0x00007FA9D6DCF617
00007fa9d6dd0a4a  sub rsp, 0x08
00007fa9d6dd0a4e  push rax
00007fa9d6dd0a4f  push rcx
00007fa9d6dd0a50  push rdx
00007fa9d6dd0a51  push rdi
00007fa9d6dd0a52  push rsi
00007fa9d6dd0a53  push r8
00007fa9d6dd0a55  push r9
00007fa9d6dd0a57  push r10
00007fa9d6dd0a59  push r11
00007fa9d6dd0a5b  sub rsp, 0xF0
00007fa9d6dd0a62  vmovaps [rsp], xmm0
00007fa9d6dd0a67  vmovaps [rsp+0x10], xmm2
00007fa9d6dd0a6d  vmovaps [rsp+0x20], xmm3
00007fa9d6dd0a73  vmovaps [rsp+0x30], xmm4
00007fa9d6dd0a79  vmovaps [rsp+0x40], xmm5
00007fa9d6dd0a7f  vmovaps [rsp+0x50], xmm6
00007fa9d6dd0a85  vmovaps [rsp+0x60], xmm7
00007fa9d6dd0a8b  vmovaps [rsp+0x70], xmm8
00007fa9d6dd0a91  vmovaps [rsp+0x80], xmm9
00007fa9d6dd0a9a  vmovaps [rsp+0x90], xmm10
00007fa9d6dd0aa3  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd0aac  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd0ab5  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd0abe  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd0ac7  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd0ad0  sub rsp, 0x30
00007fa9d6dd0ad4  movaps [rsp], xmm1
00007fa9d6dd0ad8  movaps [rsp+0x10], xmm14
00007fa9d6dd0ade  movaps [rsp+0x20], xmm10
00007fa9d6dd0ae4  lea rdi, [rsp]
00007fa9d6dd0ae8  mov esi, 0x00
00007fa9d6dd0aed  mov rax, 0x61DF872DB530
00007fa9d6dd0af7  call rax
00007fa9d6dd0af9  movaps xmm1, [rsp]
00007fa9d6dd0afd  add rsp, 0x30
00007fa9d6dd0b01  vmovaps xmm0, [rsp]
00007fa9d6dd0b06  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd0b0c  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd0b12  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd0b18  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd0b1e  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd0b24  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd0b2a  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd0b30  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd0b39  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd0b42  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd0b4b  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd0b54  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd0b5d  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd0b66  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd0b6f  add rsp, 0xF0
00007fa9d6dd0b76  pop r11
00007fa9d6dd0b78  pop r10
00007fa9d6dd0b7a  pop r9
00007fa9d6dd0b7c  pop r8
00007fa9d6dd0b7e  pop rsi
00007fa9d6dd0b7f  pop rdi
00007fa9d6dd0b80  pop rdx
00007fa9d6dd0b81  pop rcx
00007fa9d6dd0b82  pop rax
00007fa9d6dd0b83  add rsp, 0x08
00007fa9d6dd0b87  jmp 0x00007FA9D6DCF631
00007fa9d6dd0b8c  sub rsp, 0x08
00007fa9d6dd0b90  push rax
00007fa9d6dd0b91  push rcx
00007fa9d6dd0b92  push rdx
00007fa9d6dd0b93  push rdi
00007fa9d6dd0b94  push rsi
00007fa9d6dd0b95  push r8
00007fa9d6dd0b97  push r9
00007fa9d6dd0b99  push r10
00007fa9d6dd0b9b  push r11
00007fa9d6dd0b9d  sub rsp, 0xF0
00007fa9d6dd0ba4  vmovaps [rsp], xmm0
00007fa9d6dd0ba9  vmovaps [rsp+0x10], xmm1
00007fa9d6dd0baf  vmovaps [rsp+0x20], xmm2
00007fa9d6dd0bb5  vmovaps [rsp+0x30], xmm3
00007fa9d6dd0bbb  vmovaps [rsp+0x40], xmm4
00007fa9d6dd0bc1  vmovaps [rsp+0x50], xmm5
00007fa9d6dd0bc7  vmovaps [rsp+0x60], xmm6
00007fa9d6dd0bcd  vmovaps [rsp+0x70], xmm7
00007fa9d6dd0bd3  vmovaps [rsp+0x80], xmm8
00007fa9d6dd0bdc  vmovaps [rsp+0x90], xmm9
00007fa9d6dd0be5  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd0bee  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd0bf7  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd0c00  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd0c09  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd0c12  sub rsp, 0x30
00007fa9d6dd0c16  movaps [rsp], xmm13
00007fa9d6dd0c1b  movaps [rsp+0x10], xmm14
00007fa9d6dd0c21  movaps [rsp+0x20], xmm2
00007fa9d6dd0c26  lea rdi, [rsp]
00007fa9d6dd0c2a  mov esi, 0x00
00007fa9d6dd0c2f  mov rax, 0x61DF872DB530
00007fa9d6dd0c39  call rax
00007fa9d6dd0c3b  movaps xmm13, [rsp]
00007fa9d6dd0c40  add rsp, 0x30
00007fa9d6dd0c44  vmovaps xmm0, [rsp]
00007fa9d6dd0c49  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd0c4f  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd0c55  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd0c5b  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd0c61  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd0c67  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd0c6d  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd0c73  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd0c7c  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd0c85  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd0c8e  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd0c97  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd0ca0  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd0ca9  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd0cb2  add rsp, 0xF0
00007fa9d6dd0cb9  pop r11
00007fa9d6dd0cbb  pop r10
00007fa9d6dd0cbd  pop r9
00007fa9d6dd0cbf  pop r8
00007fa9d6dd0cc1  pop rsi
00007fa9d6dd0cc2  pop rdi
00007fa9d6dd0cc3  pop rdx
00007fa9d6dd0cc4  pop rcx
00007fa9d6dd0cc5  pop rax
00007fa9d6dd0cc6  add rsp, 0x08
00007fa9d6dd0cca  jmp 0x00007FA9D6DCF64C
00007fa9d6dd0ccf  sub rsp, 0x08
00007fa9d6dd0cd3  push rax
00007fa9d6dd0cd4  push rcx
00007fa9d6dd0cd5  push rdx
00007fa9d6dd0cd6  push rdi
00007fa9d6dd0cd7  push rsi
00007fa9d6dd0cd8  push r8
00007fa9d6dd0cda  push r9
00007fa9d6dd0cdc  push r10
00007fa9d6dd0cde  push r11
00007fa9d6dd0ce0  sub rsp, 0xF0
00007fa9d6dd0ce7  vmovaps [rsp], xmm0
00007fa9d6dd0cec  vmovaps [rsp+0x10], xmm2
00007fa9d6dd0cf2  vmovaps [rsp+0x20], xmm3
00007fa9d6dd0cf8  vmovaps [rsp+0x30], xmm4
00007fa9d6dd0cfe  vmovaps [rsp+0x40], xmm5
00007fa9d6dd0d04  vmovaps [rsp+0x50], xmm6
00007fa9d6dd0d0a  vmovaps [rsp+0x60], xmm7
00007fa9d6dd0d10  vmovaps [rsp+0x70], xmm8
00007fa9d6dd0d16  vmovaps [rsp+0x80], xmm9
00007fa9d6dd0d1f  vmovaps [rsp+0x90], xmm10
00007fa9d6dd0d28  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd0d31  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd0d3a  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd0d43  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd0d4c  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd0d55  sub rsp, 0x30
00007fa9d6dd0d59  movaps [rsp], xmm1
00007fa9d6dd0d5d  movaps [rsp+0x10], xmm10
00007fa9d6dd0d63  movaps [rsp+0x20], xmm2
00007fa9d6dd0d68  lea rdi, [rsp]
00007fa9d6dd0d6c  mov esi, 0x00
00007fa9d6dd0d71  mov rax, 0x61DF872DB530
00007fa9d6dd0d7b  call rax
00007fa9d6dd0d7d  movaps xmm1, [rsp]
00007fa9d6dd0d81  add rsp, 0x30
00007fa9d6dd0d85  vmovaps xmm0, [rsp]
00007fa9d6dd0d8a  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd0d90  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd0d96  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd0d9c  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd0da2  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd0da8  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd0dae  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd0db4  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd0dbd  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd0dc6  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd0dcf  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd0dd8  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd0de1  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd0dea  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd0df3  add rsp, 0xF0
00007fa9d6dd0dfa  pop r11
00007fa9d6dd0dfc  pop r10
00007fa9d6dd0dfe  pop r9
00007fa9d6dd0e00  pop r8
00007fa9d6dd0e02  pop rsi
00007fa9d6dd0e03  pop rdi
00007fa9d6dd0e04  pop rdx
00007fa9d6dd0e05  pop rcx
00007fa9d6dd0e06  pop rax
00007fa9d6dd0e07  add rsp, 0x08
00007fa9d6dd0e0b  jmp 0x00007FA9D6DCF6B4
00007fa9d6dd0e10  sub rsp, 0x08
00007fa9d6dd0e14  push rax
00007fa9d6dd0e15  push rcx
00007fa9d6dd0e16  push rdx
00007fa9d6dd0e17  push rdi
00007fa9d6dd0e18  push rsi
00007fa9d6dd0e19  push r8
00007fa9d6dd0e1b  push r9
00007fa9d6dd0e1d  push r10
00007fa9d6dd0e1f  push r11
00007fa9d6dd0e21  sub rsp, 0xF0
00007fa9d6dd0e28  vmovaps [rsp], xmm0
00007fa9d6dd0e2d  vmovaps [rsp+0x10], xmm1
00007fa9d6dd0e33  vmovaps [rsp+0x20], xmm2
00007fa9d6dd0e39  vmovaps [rsp+0x30], xmm3
00007fa9d6dd0e3f  vmovaps [rsp+0x40], xmm4
00007fa9d6dd0e45  vmovaps [rsp+0x50], xmm5
00007fa9d6dd0e4b  vmovaps [rsp+0x60], xmm6
00007fa9d6dd0e51  vmovaps [rsp+0x70], xmm7
00007fa9d6dd0e57  vmovaps [rsp+0x80], xmm8
00007fa9d6dd0e60  vmovaps [rsp+0x90], xmm9
00007fa9d6dd0e69  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd0e72  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd0e7b  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd0e84  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd0e8d  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd0e96  sub rsp, 0x30
00007fa9d6dd0e9a  movaps [rsp], xmm15
00007fa9d6dd0e9f  movaps [rsp+0x10], xmm10
00007fa9d6dd0ea5  movaps [rsp+0x20], xmm2
00007fa9d6dd0eaa  lea rdi, [rsp]
00007fa9d6dd0eae  mov esi, 0x00
00007fa9d6dd0eb3  mov rax, 0x61DF872DB530
00007fa9d6dd0ebd  call rax
00007fa9d6dd0ebf  movaps xmm15, [rsp]
00007fa9d6dd0ec4  add rsp, 0x30
00007fa9d6dd0ec8  vmovaps xmm0, [rsp]
00007fa9d6dd0ecd  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd0ed3  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd0ed9  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd0edf  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd0ee5  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd0eeb  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd0ef1  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd0ef7  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd0f00  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd0f09  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd0f12  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd0f1b  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd0f24  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd0f2d  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd0f36  add rsp, 0xF0
00007fa9d6dd0f3d  pop r11
00007fa9d6dd0f3f  pop r10
00007fa9d6dd0f41  pop r9
00007fa9d6dd0f43  pop r8
00007fa9d6dd0f45  pop rsi
00007fa9d6dd0f46  pop rdi
00007fa9d6dd0f47  pop rdx
00007fa9d6dd0f48  pop rcx
00007fa9d6dd0f49  pop rax
00007fa9d6dd0f4a  add rsp, 0x08
00007fa9d6dd0f4e  jmp 0x00007FA9D6DCF706
00007fa9d6dd0f53  sub rsp, 0x08
00007fa9d6dd0f57  push rax
00007fa9d6dd0f58  push rcx
00007fa9d6dd0f59  push rdx
00007fa9d6dd0f5a  push rdi
00007fa9d6dd0f5b  push rsi
00007fa9d6dd0f5c  push r8
00007fa9d6dd0f5e  push r9
00007fa9d6dd0f60  push r10
00007fa9d6dd0f62  push r11
00007fa9d6dd0f64  sub rsp, 0xF0
00007fa9d6dd0f6b  vmovaps [rsp], xmm0
00007fa9d6dd0f70  vmovaps [rsp+0x10], xmm2
00007fa9d6dd0f76  vmovaps [rsp+0x20], xmm3
00007fa9d6dd0f7c  vmovaps [rsp+0x30], xmm4
00007fa9d6dd0f82  vmovaps [rsp+0x40], xmm5
00007fa9d6dd0f88  vmovaps [rsp+0x50], xmm6
00007fa9d6dd0f8e  vmovaps [rsp+0x60], xmm7
00007fa9d6dd0f94  vmovaps [rsp+0x70], xmm8
00007fa9d6dd0f9a  vmovaps [rsp+0x80], xmm9
00007fa9d6dd0fa3  vmovaps [rsp+0x90], xmm10
00007fa9d6dd0fac  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd0fb5  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd0fbe  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd0fc7  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd0fd0  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd0fd9  sub rsp, 0x30
00007fa9d6dd0fdd  movaps [rsp], xmm1
00007fa9d6dd0fe1  movaps [rsp+0x10], xmm10
00007fa9d6dd0fe7  movaps [rsp+0x20], xmm12
00007fa9d6dd0fed  lea rdi, [rsp]
00007fa9d6dd0ff1  mov esi, 0x00
00007fa9d6dd0ff6  mov rax, 0x61DF872DB530
00007fa9d6dd1000  call rax
00007fa9d6dd1002  movaps xmm1, [rsp]
00007fa9d6dd1006  add rsp, 0x30
00007fa9d6dd100a  vmovaps xmm0, [rsp]
00007fa9d6dd100f  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd1015  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd101b  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd1021  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd1027  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd102d  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd1033  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd1039  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd1042  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd104b  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd1054  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd105d  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd1066  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd106f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd1078  add rsp, 0xF0
00007fa9d6dd107f  pop r11
00007fa9d6dd1081  pop r10
00007fa9d6dd1083  pop r9
00007fa9d6dd1085  pop r8
00007fa9d6dd1087  pop rsi
00007fa9d6dd1088  pop rdi
00007fa9d6dd1089  pop rdx
00007fa9d6dd108a  pop rcx
00007fa9d6dd108b  pop rax
00007fa9d6dd108c  add rsp, 0x08
00007fa9d6dd1090  jmp 0x00007FA9D6DCF732
00007fa9d6dd1095  sub rsp, 0x08
00007fa9d6dd1099  push rax
00007fa9d6dd109a  push rcx
00007fa9d6dd109b  push rdx
00007fa9d6dd109c  push rdi
00007fa9d6dd109d  push rsi
00007fa9d6dd109e  push r8
00007fa9d6dd10a0  push r9
00007fa9d6dd10a2  push r10
00007fa9d6dd10a4  push r11
00007fa9d6dd10a6  sub rsp, 0xF0
00007fa9d6dd10ad  vmovaps [rsp], xmm0
00007fa9d6dd10b2  vmovaps [rsp+0x10], xmm1
00007fa9d6dd10b8  vmovaps [rsp+0x20], xmm2
00007fa9d6dd10be  vmovaps [rsp+0x30], xmm3
00007fa9d6dd10c4  vmovaps [rsp+0x40], xmm4
00007fa9d6dd10ca  vmovaps [rsp+0x50], xmm5
00007fa9d6dd10d0  vmovaps [rsp+0x60], xmm6
00007fa9d6dd10d6  vmovaps [rsp+0x70], xmm7
00007fa9d6dd10dc  vmovaps [rsp+0x80], xmm8
00007fa9d6dd10e5  vmovaps [rsp+0x90], xmm9
00007fa9d6dd10ee  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd10f7  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd1100  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd1109  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd1112  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd111b  sub rsp, 0x30
00007fa9d6dd111f  movaps [rsp], xmm15
00007fa9d6dd1124  movaps [rsp+0x10], xmm10
00007fa9d6dd112a  movaps [rsp+0x20], xmm12
00007fa9d6dd1130  lea rdi, [rsp]
00007fa9d6dd1134  mov esi, 0x00
00007fa9d6dd1139  mov rax, 0x61DF872DB530
00007fa9d6dd1143  call rax
00007fa9d6dd1145  movaps xmm15, [rsp]
00007fa9d6dd114a  add rsp, 0x30
00007fa9d6dd114e  vmovaps xmm0, [rsp]
00007fa9d6dd1153  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd1159  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd115f  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd1165  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd116b  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd1171  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd1177  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd117d  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd1186  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd118f  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd1198  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd11a1  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd11aa  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd11b3  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd11bc  add rsp, 0xF0
00007fa9d6dd11c3  pop r11
00007fa9d6dd11c5  pop r10
00007fa9d6dd11c7  pop r9
00007fa9d6dd11c9  pop r8
00007fa9d6dd11cb  pop rsi
00007fa9d6dd11cc  pop rdi
00007fa9d6dd11cd  pop rdx
00007fa9d6dd11ce  pop rcx
00007fa9d6dd11cf  pop rax
00007fa9d6dd11d0  add rsp, 0x08
00007fa9d6dd11d4  jmp 0x00007FA9D6DCF75E
00007fa9d6dd11d9  call 0x00007FA9D6BFF430
00007fa9d6dd11de  jmp 0x00007FA9D6DCF7EE
00007fa9d6dd11e3  call 0x00007FA9D6BFF430
00007fa9d6dd11e8  jmp 0x00007FA9D6DCF801
00007fa9d6dd11ed  sub rsp, 0x08
00007fa9d6dd11f1  push rax
00007fa9d6dd11f2  push rcx
00007fa9d6dd11f3  push rdx
00007fa9d6dd11f4  push rdi
00007fa9d6dd11f5  push rsi
00007fa9d6dd11f6  push r8
00007fa9d6dd11f8  push r9
00007fa9d6dd11fa  push r10
00007fa9d6dd11fc  push r11
00007fa9d6dd11fe  sub rsp, 0xF0
00007fa9d6dd1205  vmovaps [rsp], xmm0
00007fa9d6dd120a  vmovaps [rsp+0x10], xmm2
00007fa9d6dd1210  vmovaps [rsp+0x20], xmm3
00007fa9d6dd1216  vmovaps [rsp+0x30], xmm4
00007fa9d6dd121c  vmovaps [rsp+0x40], xmm5
00007fa9d6dd1222  vmovaps [rsp+0x50], xmm6
00007fa9d6dd1228  vmovaps [rsp+0x60], xmm7
00007fa9d6dd122e  vmovaps [rsp+0x70], xmm8
00007fa9d6dd1234  vmovaps [rsp+0x80], xmm9
00007fa9d6dd123d  vmovaps [rsp+0x90], xmm10
00007fa9d6dd1246  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd124f  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd1258  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd1261  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd126a  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd1273  sub rsp, 0x30
00007fa9d6dd1277  movaps [rsp], xmm1
00007fa9d6dd127b  movaps [rsp+0x10], xmm13
00007fa9d6dd1281  movaps [rsp+0x20], xmm2
00007fa9d6dd1286  lea rdi, [rsp]
00007fa9d6dd128a  mov esi, 0x00
00007fa9d6dd128f  mov rax, 0x61DF872DB530
00007fa9d6dd1299  call rax
00007fa9d6dd129b  movaps xmm1, [rsp]
00007fa9d6dd129f  add rsp, 0x30
00007fa9d6dd12a3  vmovaps xmm0, [rsp]
00007fa9d6dd12a8  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd12ae  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd12b4  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd12ba  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd12c0  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd12c6  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd12cc  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd12d2  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd12db  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd12e4  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd12ed  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd12f6  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd12ff  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd1308  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd1311  add rsp, 0xF0
00007fa9d6dd1318  pop r11
00007fa9d6dd131a  pop r10
00007fa9d6dd131c  pop r9
00007fa9d6dd131e  pop r8
00007fa9d6dd1320  pop rsi
00007fa9d6dd1321  pop rdi
00007fa9d6dd1322  pop rdx
00007fa9d6dd1323  pop rcx
00007fa9d6dd1324  pop rax
00007fa9d6dd1325  add rsp, 0x08
00007fa9d6dd1329  jmp 0x00007FA9D6DCF82C
00007fa9d6dd132e  call 0x00007FA9D6C0E760
00007fa9d6dd1333  jmp 0x00007FA9D6DCF839
00007fa9d6dd1338  sub rsp, 0x08
00007fa9d6dd133c  push rax
00007fa9d6dd133d  push rcx
00007fa9d6dd133e  push rdx
00007fa9d6dd133f  push rdi
00007fa9d6dd1340  push rsi
00007fa9d6dd1341  push r8
00007fa9d6dd1343  push r9
00007fa9d6dd1345  push r10
00007fa9d6dd1347  push r11
00007fa9d6dd1349  sub rsp, 0xF0
00007fa9d6dd1350  vmovaps [rsp], xmm0
00007fa9d6dd1355  vmovaps [rsp+0x10], xmm1
00007fa9d6dd135b  vmovaps [rsp+0x20], xmm2
00007fa9d6dd1361  vmovaps [rsp+0x30], xmm3
00007fa9d6dd1367  vmovaps [rsp+0x40], xmm4
00007fa9d6dd136d  vmovaps [rsp+0x50], xmm5
00007fa9d6dd1373  vmovaps [rsp+0x60], xmm6
00007fa9d6dd1379  vmovaps [rsp+0x70], xmm7
00007fa9d6dd137f  vmovaps [rsp+0x80], xmm8
00007fa9d6dd1388  vmovaps [rsp+0x90], xmm9
00007fa9d6dd1391  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd139a  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd13a3  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd13ac  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd13b5  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd13be  sub rsp, 0x30
00007fa9d6dd13c2  movaps [rsp], xmm13
00007fa9d6dd13c7  movaps [rsp+0x10], xmm2
00007fa9d6dd13cc  movaps [rsp+0x20], xmm1
00007fa9d6dd13d1  lea rdi, [rsp]
00007fa9d6dd13d5  mov esi, 0x00
00007fa9d6dd13da  mov rax, 0x61DF872DB530
00007fa9d6dd13e4  call rax
00007fa9d6dd13e6  movaps xmm13, [rsp]
00007fa9d6dd13eb  add rsp, 0x30
00007fa9d6dd13ef  vmovaps xmm0, [rsp]
00007fa9d6dd13f4  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd13fa  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd1400  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd1406  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd140c  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd1412  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd1418  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd141e  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd1427  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd1430  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd1439  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd1442  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd144b  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd1454  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd145d  add rsp, 0xF0
00007fa9d6dd1464  pop r11
00007fa9d6dd1466  pop r10
00007fa9d6dd1468  pop r9
00007fa9d6dd146a  pop r8
00007fa9d6dd146c  pop rsi
00007fa9d6dd146d  pop rdi
00007fa9d6dd146e  pop rdx
00007fa9d6dd146f  pop rcx
00007fa9d6dd1470  pop rax
00007fa9d6dd1471  add rsp, 0x08
00007fa9d6dd1475  jmp 0x00007FA9D6DCF878
00007fa9d6dd147a  sub rsp, 0x08
00007fa9d6dd147e  push rax
00007fa9d6dd147f  push rcx
00007fa9d6dd1480  push rdx
00007fa9d6dd1481  push rdi
00007fa9d6dd1482  push rsi
00007fa9d6dd1483  push r8
00007fa9d6dd1485  push r9
00007fa9d6dd1487  push r10
00007fa9d6dd1489  push r11
00007fa9d6dd148b  sub rsp, 0xF0
00007fa9d6dd1492  vmovaps [rsp], xmm0
00007fa9d6dd1497  vmovaps [rsp+0x10], xmm2
00007fa9d6dd149d  vmovaps [rsp+0x20], xmm3
00007fa9d6dd14a3  vmovaps [rsp+0x30], xmm4
00007fa9d6dd14a9  vmovaps [rsp+0x40], xmm5
00007fa9d6dd14af  vmovaps [rsp+0x50], xmm6
00007fa9d6dd14b5  vmovaps [rsp+0x60], xmm7
00007fa9d6dd14bb  vmovaps [rsp+0x70], xmm8
00007fa9d6dd14c1  vmovaps [rsp+0x80], xmm9
00007fa9d6dd14ca  vmovaps [rsp+0x90], xmm10
00007fa9d6dd14d3  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd14dc  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd14e5  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd14ee  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd14f7  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd1500  sub rsp, 0x30
00007fa9d6dd1504  movaps [rsp], xmm1
00007fa9d6dd1508  movaps [rsp+0x10], xmm15
00007fa9d6dd150e  movaps [rsp+0x20], xmm2
00007fa9d6dd1513  lea rdi, [rsp]
00007fa9d6dd1517  mov esi, 0x00
00007fa9d6dd151c  mov rax, 0x61DF872DB530
00007fa9d6dd1526  call rax
00007fa9d6dd1528  movaps xmm1, [rsp]
00007fa9d6dd152c  add rsp, 0x30
00007fa9d6dd1530  vmovaps xmm0, [rsp]
00007fa9d6dd1535  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd153b  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd1541  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd1547  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd154d  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd1553  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd1559  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd155f  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd1568  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd1571  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd157a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd1583  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd158c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd1595  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd159e  add rsp, 0xF0
00007fa9d6dd15a5  pop r11
00007fa9d6dd15a7  pop r10
00007fa9d6dd15a9  pop r9
00007fa9d6dd15ab  pop r8
00007fa9d6dd15ad  pop rsi
00007fa9d6dd15ae  pop rdi
00007fa9d6dd15af  pop rdx
00007fa9d6dd15b0  pop rcx
00007fa9d6dd15b1  pop rax
00007fa9d6dd15b2  add rsp, 0x08
00007fa9d6dd15b6  jmp 0x00007FA9D6DCF8AC
00007fa9d6dd15bb  sub rsp, 0x08
00007fa9d6dd15bf  push rax
00007fa9d6dd15c0  push rcx
00007fa9d6dd15c1  push rdx
00007fa9d6dd15c2  push rdi
00007fa9d6dd15c3  push rsi
00007fa9d6dd15c4  push r8
00007fa9d6dd15c6  push r9
00007fa9d6dd15c8  push r10
00007fa9d6dd15ca  push r11
00007fa9d6dd15cc  sub rsp, 0xF0
00007fa9d6dd15d3  vmovaps [rsp], xmm0
00007fa9d6dd15d8  vmovaps [rsp+0x10], xmm1
00007fa9d6dd15de  vmovaps [rsp+0x20], xmm2
00007fa9d6dd15e4  vmovaps [rsp+0x30], xmm3
00007fa9d6dd15ea  vmovaps [rsp+0x40], xmm4
00007fa9d6dd15f0  vmovaps [rsp+0x50], xmm5
00007fa9d6dd15f6  vmovaps [rsp+0x60], xmm6
00007fa9d6dd15fc  vmovaps [rsp+0x70], xmm7
00007fa9d6dd1602  vmovaps [rsp+0x80], xmm8
00007fa9d6dd160b  vmovaps [rsp+0x90], xmm9
00007fa9d6dd1614  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd161d  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd1626  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd162f  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd1638  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd1641  sub rsp, 0x30
00007fa9d6dd1645  movaps [rsp], xmm14
00007fa9d6dd164a  movaps [rsp+0x10], xmm2
00007fa9d6dd164f  movaps [rsp+0x20], xmm15
00007fa9d6dd1655  lea rdi, [rsp]
00007fa9d6dd1659  mov esi, 0x00
00007fa9d6dd165e  mov rax, 0x61DF872DB530
00007fa9d6dd1668  call rax
00007fa9d6dd166a  movaps xmm14, [rsp]
00007fa9d6dd166f  add rsp, 0x30
00007fa9d6dd1673  vmovaps xmm0, [rsp]
00007fa9d6dd1678  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd167e  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd1684  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd168a  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd1690  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd1696  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd169c  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd16a2  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd16ab  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd16b4  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd16bd  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd16c6  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd16cf  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd16d8  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd16e1  add rsp, 0xF0
00007fa9d6dd16e8  pop r11
00007fa9d6dd16ea  pop r10
00007fa9d6dd16ec  pop r9
00007fa9d6dd16ee  pop r8
00007fa9d6dd16f0  pop rsi
00007fa9d6dd16f1  pop rdi
00007fa9d6dd16f2  pop rdx
00007fa9d6dd16f3  pop rcx
00007fa9d6dd16f4  pop rax
00007fa9d6dd16f5  add rsp, 0x08
00007fa9d6dd16f9  jmp 0x00007FA9D6DCF8E7
00007fa9d6dd16fe  sub rsp, 0x08
00007fa9d6dd1702  push rax
00007fa9d6dd1703  push rcx
00007fa9d6dd1704  push rdx
00007fa9d6dd1705  push rdi
00007fa9d6dd1706  push rsi
00007fa9d6dd1707  push r8
00007fa9d6dd1709  push r9
00007fa9d6dd170b  push r10
00007fa9d6dd170d  push r11
00007fa9d6dd170f  sub rsp, 0xF0
00007fa9d6dd1716  vmovaps [rsp], xmm0
00007fa9d6dd171b  vmovaps [rsp+0x10], xmm1
00007fa9d6dd1721  vmovaps [rsp+0x20], xmm2
00007fa9d6dd1727  vmovaps [rsp+0x30], xmm3
00007fa9d6dd172d  vmovaps [rsp+0x40], xmm4
00007fa9d6dd1733  vmovaps [rsp+0x50], xmm5
00007fa9d6dd1739  vmovaps [rsp+0x60], xmm6
00007fa9d6dd173f  vmovaps [rsp+0x70], xmm7
00007fa9d6dd1745  vmovaps [rsp+0x80], xmm8
00007fa9d6dd174e  vmovaps [rsp+0x90], xmm9
00007fa9d6dd1757  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd1760  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd1769  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd1772  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd177b  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd1784  sub rsp, 0x30
00007fa9d6dd1788  movaps [rsp], xmm15
00007fa9d6dd178d  movaps [rsp+0x10], xmm2
00007fa9d6dd1792  movaps [rsp+0x20], xmm1
00007fa9d6dd1797  lea rdi, [rsp]
00007fa9d6dd179b  mov esi, 0x00
00007fa9d6dd17a0  mov rax, 0x61DF872DB530
00007fa9d6dd17aa  call rax
00007fa9d6dd17ac  movaps xmm15, [rsp]
00007fa9d6dd17b1  add rsp, 0x30
00007fa9d6dd17b5  vmovaps xmm0, [rsp]
00007fa9d6dd17ba  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd17c0  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd17c6  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd17cc  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd17d2  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd17d8  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd17de  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd17e4  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd17ed  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd17f6  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd17ff  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd1808  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd1811  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd181a  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd1823  add rsp, 0xF0
00007fa9d6dd182a  pop r11
00007fa9d6dd182c  pop r10
00007fa9d6dd182e  pop r9
00007fa9d6dd1830  pop r8
00007fa9d6dd1832  pop rsi
00007fa9d6dd1833  pop rdi
00007fa9d6dd1834  pop rdx
00007fa9d6dd1835  pop rcx
00007fa9d6dd1836  pop rax
00007fa9d6dd1837  add rsp, 0x08
00007fa9d6dd183b  jmp 0x00007FA9D6DCF923
00007fa9d6dd1840  call 0x00007FA9D6BFF430
00007fa9d6dd1845  jmp 0x00007FA9D6DCF930
00007fa9d6dd184a  sub rsp, 0x08
00007fa9d6dd184e  push rax
00007fa9d6dd184f  push rcx
00007fa9d6dd1850  push rdx
00007fa9d6dd1851  push rdi
00007fa9d6dd1852  push rsi
00007fa9d6dd1853  push r8
00007fa9d6dd1855  push r9
00007fa9d6dd1857  push r10
00007fa9d6dd1859  push r11
00007fa9d6dd185b  sub rsp, 0xF0
00007fa9d6dd1862  vmovaps [rsp], xmm0
00007fa9d6dd1867  vmovaps [rsp+0x10], xmm1
00007fa9d6dd186d  vmovaps [rsp+0x20], xmm3
00007fa9d6dd1873  vmovaps [rsp+0x30], xmm4
00007fa9d6dd1879  vmovaps [rsp+0x40], xmm5
00007fa9d6dd187f  vmovaps [rsp+0x50], xmm6
00007fa9d6dd1885  vmovaps [rsp+0x60], xmm7
00007fa9d6dd188b  vmovaps [rsp+0x70], xmm8
00007fa9d6dd1891  vmovaps [rsp+0x80], xmm9
00007fa9d6dd189a  vmovaps [rsp+0x90], xmm10
00007fa9d6dd18a3  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd18ac  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd18b5  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd18be  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd18c7  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd18d0  sub rsp, 0x30
00007fa9d6dd18d4  movaps [rsp], xmm2
00007fa9d6dd18d8  movaps [rsp+0x10], xmm1
00007fa9d6dd18dd  movaps [rsp+0x20], xmm14
00007fa9d6dd18e3  lea rdi, [rsp]
00007fa9d6dd18e7  mov esi, 0x00
00007fa9d6dd18ec  mov rax, 0x61DF872DB530
00007fa9d6dd18f6  call rax
00007fa9d6dd18f8  movaps xmm2, [rsp]
00007fa9d6dd18fc  add rsp, 0x30
00007fa9d6dd1900  vmovaps xmm0, [rsp]
00007fa9d6dd1905  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd190b  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd1911  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd1917  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd191d  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd1923  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd1929  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd192f  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd1938  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd1941  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd194a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd1953  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd195c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd1965  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd196e  add rsp, 0xF0
00007fa9d6dd1975  pop r11
00007fa9d6dd1977  pop r10
00007fa9d6dd1979  pop r9
00007fa9d6dd197b  pop r8
00007fa9d6dd197d  pop rsi
00007fa9d6dd197e  pop rdi
00007fa9d6dd197f  pop rdx
00007fa9d6dd1980  pop rcx
00007fa9d6dd1981  pop rax
00007fa9d6dd1982  add rsp, 0x08
00007fa9d6dd1986  jmp 0x00007FA9D6DCF96D
00007fa9d6dd198b  sub rsp, 0x08
00007fa9d6dd198f  push rax
00007fa9d6dd1990  push rcx
00007fa9d6dd1991  push rdx
00007fa9d6dd1992  push rdi
00007fa9d6dd1993  push rsi
00007fa9d6dd1994  push r8
00007fa9d6dd1996  push r9
00007fa9d6dd1998  push r10
00007fa9d6dd199a  push r11
00007fa9d6dd199c  sub rsp, 0xF0
00007fa9d6dd19a3  vmovaps [rsp], xmm0
00007fa9d6dd19a8  vmovaps [rsp+0x10], xmm1
00007fa9d6dd19ae  vmovaps [rsp+0x20], xmm2
00007fa9d6dd19b4  vmovaps [rsp+0x30], xmm3
00007fa9d6dd19ba  vmovaps [rsp+0x40], xmm4
00007fa9d6dd19c0  vmovaps [rsp+0x50], xmm5
00007fa9d6dd19c6  vmovaps [rsp+0x60], xmm6
00007fa9d6dd19cc  vmovaps [rsp+0x70], xmm7
00007fa9d6dd19d2  vmovaps [rsp+0x80], xmm8
00007fa9d6dd19db  vmovaps [rsp+0x90], xmm9
00007fa9d6dd19e4  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd19ed  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd19f6  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd19ff  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd1a08  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd1a11  sub rsp, 0x30
00007fa9d6dd1a15  movaps [rsp], xmm15
00007fa9d6dd1a1a  movaps [rsp+0x10], xmm14
00007fa9d6dd1a20  movaps [rsp+0x20], xmm1
00007fa9d6dd1a25  lea rdi, [rsp]
00007fa9d6dd1a29  mov esi, 0x00
00007fa9d6dd1a2e  mov rax, 0x61DF872DB530
00007fa9d6dd1a38  call rax
00007fa9d6dd1a3a  movaps xmm15, [rsp]
00007fa9d6dd1a3f  add rsp, 0x30
00007fa9d6dd1a43  vmovaps xmm0, [rsp]
00007fa9d6dd1a48  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd1a4e  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd1a54  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd1a5a  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd1a60  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd1a66  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd1a6c  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd1a72  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd1a7b  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd1a84  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd1a8d  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd1a96  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd1a9f  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd1aa8  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd1ab1  add rsp, 0xF0
00007fa9d6dd1ab8  pop r11
00007fa9d6dd1aba  pop r10
00007fa9d6dd1abc  pop r9
00007fa9d6dd1abe  pop r8
00007fa9d6dd1ac0  pop rsi
00007fa9d6dd1ac1  pop rdi
00007fa9d6dd1ac2  pop rdx
00007fa9d6dd1ac3  pop rcx
00007fa9d6dd1ac4  pop rax
00007fa9d6dd1ac5  add rsp, 0x08
00007fa9d6dd1ac9  jmp 0x00007FA9D6DCF9E7
00007fa9d6dd1ace  call 0x00007FA9D6BFF430
00007fa9d6dd1ad3  jmp 0x00007FA9D6DCF9F4
00007fa9d6dd1ad8  sub rsp, 0x08
00007fa9d6dd1adc  push rax
00007fa9d6dd1add  push rcx
00007fa9d6dd1ade  push rdx
00007fa9d6dd1adf  push rdi
00007fa9d6dd1ae0  push rsi
00007fa9d6dd1ae1  push r8
00007fa9d6dd1ae3  push r9
00007fa9d6dd1ae5  push r10
00007fa9d6dd1ae7  push r11
00007fa9d6dd1ae9  sub rsp, 0xF0
00007fa9d6dd1af0  vmovaps [rsp], xmm0
00007fa9d6dd1af5  vmovaps [rsp+0x10], xmm1
00007fa9d6dd1afb  vmovaps [rsp+0x20], xmm2
00007fa9d6dd1b01  vmovaps [rsp+0x30], xmm3
00007fa9d6dd1b07  vmovaps [rsp+0x40], xmm4
00007fa9d6dd1b0d  vmovaps [rsp+0x50], xmm5
00007fa9d6dd1b13  vmovaps [rsp+0x60], xmm6
00007fa9d6dd1b19  vmovaps [rsp+0x70], xmm7
00007fa9d6dd1b1f  vmovaps [rsp+0x80], xmm8
00007fa9d6dd1b28  vmovaps [rsp+0x90], xmm9
00007fa9d6dd1b31  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd1b3a  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd1b43  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd1b4c  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd1b55  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd1b5e  sub rsp, 0x30
00007fa9d6dd1b62  movaps [rsp], xmm14
00007fa9d6dd1b67  movaps [rsp+0x10], xmm13
00007fa9d6dd1b6d  movaps [rsp+0x20], xmm1
00007fa9d6dd1b72  lea rdi, [rsp]
00007fa9d6dd1b76  mov esi, 0x00
00007fa9d6dd1b7b  mov rax, 0x61DF872DB530
00007fa9d6dd1b85  call rax
00007fa9d6dd1b87  movaps xmm14, [rsp]
00007fa9d6dd1b8c  add rsp, 0x30
00007fa9d6dd1b90  vmovaps xmm0, [rsp]
00007fa9d6dd1b95  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd1b9b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd1ba1  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd1ba7  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd1bad  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd1bb3  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd1bb9  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd1bbf  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd1bc8  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd1bd1  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd1bda  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd1be3  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd1bec  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd1bf5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd1bfe  add rsp, 0xF0
00007fa9d6dd1c05  pop r11
00007fa9d6dd1c07  pop r10
00007fa9d6dd1c09  pop r9
00007fa9d6dd1c0b  pop r8
00007fa9d6dd1c0d  pop rsi
00007fa9d6dd1c0e  pop rdi
00007fa9d6dd1c0f  pop rdx
00007fa9d6dd1c10  pop rcx
00007fa9d6dd1c11  pop rax
00007fa9d6dd1c12  add rsp, 0x08
00007fa9d6dd1c16  jmp 0x00007FA9D6DCFAAF
00007fa9d6dd1c1b  sub rsp, 0x08
00007fa9d6dd1c1f  push rax
00007fa9d6dd1c20  push rcx
00007fa9d6dd1c21  push rdx
00007fa9d6dd1c22  push rdi
00007fa9d6dd1c23  push rsi
00007fa9d6dd1c24  push r8
00007fa9d6dd1c26  push r9
00007fa9d6dd1c28  push r10
00007fa9d6dd1c2a  push r11
00007fa9d6dd1c2c  sub rsp, 0xF0
00007fa9d6dd1c33  vmovaps [rsp], xmm0
00007fa9d6dd1c38  vmovaps [rsp+0x10], xmm1
00007fa9d6dd1c3e  vmovaps [rsp+0x20], xmm2
00007fa9d6dd1c44  vmovaps [rsp+0x30], xmm3
00007fa9d6dd1c4a  vmovaps [rsp+0x40], xmm4
00007fa9d6dd1c50  vmovaps [rsp+0x50], xmm5
00007fa9d6dd1c56  vmovaps [rsp+0x60], xmm6
00007fa9d6dd1c5c  vmovaps [rsp+0x70], xmm7
00007fa9d6dd1c62  vmovaps [rsp+0x80], xmm8
00007fa9d6dd1c6b  vmovaps [rsp+0x90], xmm9
00007fa9d6dd1c74  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd1c7d  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd1c86  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd1c8f  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd1c98  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd1ca1  sub rsp, 0x30
00007fa9d6dd1ca5  movaps [rsp], xmm15
00007fa9d6dd1caa  movaps [rsp+0x10], xmm13
00007fa9d6dd1cb0  movaps [rsp+0x20], xmm1
00007fa9d6dd1cb5  lea rdi, [rsp]
00007fa9d6dd1cb9  mov esi, 0x00
00007fa9d6dd1cbe  mov rax, 0x61DF872DB530
00007fa9d6dd1cc8  call rax
00007fa9d6dd1cca  movaps xmm15, [rsp]
00007fa9d6dd1ccf  add rsp, 0x30
00007fa9d6dd1cd3  vmovaps xmm0, [rsp]
00007fa9d6dd1cd8  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd1cde  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd1ce4  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd1cea  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd1cf0  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd1cf6  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd1cfc  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd1d02  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd1d0b  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd1d14  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd1d1d  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd1d26  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd1d2f  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd1d38  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd1d41  add rsp, 0xF0
00007fa9d6dd1d48  pop r11
00007fa9d6dd1d4a  pop r10
00007fa9d6dd1d4c  pop r9
00007fa9d6dd1d4e  pop r8
00007fa9d6dd1d50  pop rsi
00007fa9d6dd1d51  pop rdi
00007fa9d6dd1d52  pop rdx
00007fa9d6dd1d53  pop rcx
00007fa9d6dd1d54  pop rax
00007fa9d6dd1d55  add rsp, 0x08
00007fa9d6dd1d59  jmp 0x00007FA9D6DCFAEB
00007fa9d6dd1d5e  call 0x00007FA9D6BFF430
00007fa9d6dd1d63  jmp 0x00007FA9D6DCFAF8
00007fa9d6dd1d68  sub rsp, 0x08
00007fa9d6dd1d6c  push rax
00007fa9d6dd1d6d  push rcx
00007fa9d6dd1d6e  push rdx
00007fa9d6dd1d6f  push rdi
00007fa9d6dd1d70  push rsi
00007fa9d6dd1d71  push r8
00007fa9d6dd1d73  push r9
00007fa9d6dd1d75  push r10
00007fa9d6dd1d77  push r11
00007fa9d6dd1d79  sub rsp, 0xF0
00007fa9d6dd1d80  vmovaps [rsp], xmm0
00007fa9d6dd1d85  vmovaps [rsp+0x10], xmm1
00007fa9d6dd1d8b  vmovaps [rsp+0x20], xmm2
00007fa9d6dd1d91  vmovaps [rsp+0x30], xmm3
00007fa9d6dd1d97  vmovaps [rsp+0x40], xmm4
00007fa9d6dd1d9d  vmovaps [rsp+0x50], xmm5
00007fa9d6dd1da3  vmovaps [rsp+0x60], xmm6
00007fa9d6dd1da9  vmovaps [rsp+0x70], xmm7
00007fa9d6dd1daf  vmovaps [rsp+0x80], xmm8
00007fa9d6dd1db8  vmovaps [rsp+0x90], xmm9
00007fa9d6dd1dc1  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd1dca  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd1dd3  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd1ddc  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd1de5  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd1dee  sub rsp, 0x30
00007fa9d6dd1df2  movaps [rsp], xmm14
00007fa9d6dd1df7  movaps [rsp+0x10], xmm13
00007fa9d6dd1dfd  movaps [rsp+0x20], xmm2
00007fa9d6dd1e02  lea rdi, [rsp]
00007fa9d6dd1e06  mov esi, 0x00
00007fa9d6dd1e0b  mov rax, 0x61DF872DB530
00007fa9d6dd1e15  call rax
00007fa9d6dd1e17  movaps xmm14, [rsp]
00007fa9d6dd1e1c  add rsp, 0x30
00007fa9d6dd1e20  vmovaps xmm0, [rsp]
00007fa9d6dd1e25  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd1e2b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd1e31  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd1e37  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd1e3d  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd1e43  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd1e49  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd1e4f  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd1e58  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd1e61  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd1e6a  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd1e73  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd1e7c  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd1e85  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd1e8e  add rsp, 0xF0
00007fa9d6dd1e95  pop r11
00007fa9d6dd1e97  pop r10
00007fa9d6dd1e99  pop r9
00007fa9d6dd1e9b  pop r8
00007fa9d6dd1e9d  pop rsi
00007fa9d6dd1e9e  pop rdi
00007fa9d6dd1e9f  pop rdx
00007fa9d6dd1ea0  pop rcx
00007fa9d6dd1ea1  pop rax
00007fa9d6dd1ea2  add rsp, 0x08
00007fa9d6dd1ea6  jmp 0x00007FA9D6DCFB24
00007fa9d6dd1eab  sub rsp, 0x08
00007fa9d6dd1eaf  push rax
00007fa9d6dd1eb0  push rcx
00007fa9d6dd1eb1  push rdx
00007fa9d6dd1eb2  push rdi
00007fa9d6dd1eb3  push rsi
00007fa9d6dd1eb4  push r8
00007fa9d6dd1eb6  push r9
00007fa9d6dd1eb8  push r10
00007fa9d6dd1eba  push r11
00007fa9d6dd1ebc  sub rsp, 0xF0
00007fa9d6dd1ec3  vmovaps [rsp], xmm0
00007fa9d6dd1ec8  vmovaps [rsp+0x10], xmm2
00007fa9d6dd1ece  vmovaps [rsp+0x20], xmm3
00007fa9d6dd1ed4  vmovaps [rsp+0x30], xmm4
00007fa9d6dd1eda  vmovaps [rsp+0x40], xmm5
00007fa9d6dd1ee0  vmovaps [rsp+0x50], xmm6
00007fa9d6dd1ee6  vmovaps [rsp+0x60], xmm7
00007fa9d6dd1eec  vmovaps [rsp+0x70], xmm8
00007fa9d6dd1ef2  vmovaps [rsp+0x80], xmm9
00007fa9d6dd1efb  vmovaps [rsp+0x90], xmm10
00007fa9d6dd1f04  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd1f0d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd1f16  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd1f1f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd1f28  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd1f31  sub rsp, 0x30
00007fa9d6dd1f35  movaps [rsp], xmm1
00007fa9d6dd1f39  movaps [rsp+0x10], xmm13
00007fa9d6dd1f3f  movaps [rsp+0x20], xmm2
00007fa9d6dd1f44  lea rdi, [rsp]
00007fa9d6dd1f48  mov esi, 0x00
00007fa9d6dd1f4d  mov rax, 0x61DF872DB530
00007fa9d6dd1f57  call rax
00007fa9d6dd1f59  movaps xmm1, [rsp]
00007fa9d6dd1f5d  add rsp, 0x30
00007fa9d6dd1f61  vmovaps xmm0, [rsp]
00007fa9d6dd1f66  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd1f6c  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd1f72  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd1f78  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd1f7e  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd1f84  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd1f8a  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd1f90  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd1f99  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd1fa2  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd1fab  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd1fb4  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd1fbd  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd1fc6  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd1fcf  add rsp, 0xF0
00007fa9d6dd1fd6  pop r11
00007fa9d6dd1fd8  pop r10
00007fa9d6dd1fda  pop r9
00007fa9d6dd1fdc  pop r8
00007fa9d6dd1fde  pop rsi
00007fa9d6dd1fdf  pop rdi
00007fa9d6dd1fe0  pop rdx
00007fa9d6dd1fe1  pop rcx
00007fa9d6dd1fe2  pop rax
00007fa9d6dd1fe3  add rsp, 0x08
00007fa9d6dd1fe7  jmp 0x00007FA9D6DCFB52
00007fa9d6dd1fec  sub rsp, 0x08
00007fa9d6dd1ff0  push rax
00007fa9d6dd1ff1  push rcx
00007fa9d6dd1ff2  push rdx
00007fa9d6dd1ff3  push rdi
00007fa9d6dd1ff4  push rsi
00007fa9d6dd1ff5  push r8
00007fa9d6dd1ff7  push r9
00007fa9d6dd1ff9  push r10
00007fa9d6dd1ffb  push r11
00007fa9d6dd1ffd  sub rsp, 0xF0
00007fa9d6dd2004  vmovaps [rsp], xmm0
00007fa9d6dd2009  vmovaps [rsp+0x10], xmm1
00007fa9d6dd200f  vmovaps [rsp+0x20], xmm3
00007fa9d6dd2015  vmovaps [rsp+0x30], xmm4
00007fa9d6dd201b  vmovaps [rsp+0x40], xmm5
00007fa9d6dd2021  vmovaps [rsp+0x50], xmm6
00007fa9d6dd2027  vmovaps [rsp+0x60], xmm7
00007fa9d6dd202d  vmovaps [rsp+0x70], xmm8
00007fa9d6dd2033  vmovaps [rsp+0x80], xmm9
00007fa9d6dd203c  vmovaps [rsp+0x90], xmm10
00007fa9d6dd2045  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd204e  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd2057  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd2060  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd2069  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2072  sub rsp, 0x30
00007fa9d6dd2076  movaps [rsp], xmm2
00007fa9d6dd207a  movaps [rsp+0x10], xmm1
00007fa9d6dd207f  movaps [rsp+0x20], xmm13
00007fa9d6dd2085  lea rdi, [rsp]
00007fa9d6dd2089  mov esi, 0x00
00007fa9d6dd208e  mov rax, 0x61DF872DB530
00007fa9d6dd2098  call rax
00007fa9d6dd209a  movaps xmm2, [rsp]
00007fa9d6dd209e  add rsp, 0x30
00007fa9d6dd20a2  vmovaps xmm0, [rsp]
00007fa9d6dd20a7  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd20ad  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd20b3  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd20b9  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd20bf  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd20c5  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd20cb  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd20d1  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd20da  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd20e3  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd20ec  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd20f5  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd20fe  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd2107  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd2110  add rsp, 0xF0
00007fa9d6dd2117  pop r11
00007fa9d6dd2119  pop r10
00007fa9d6dd211b  pop r9
00007fa9d6dd211d  pop r8
00007fa9d6dd211f  pop rsi
00007fa9d6dd2120  pop rdi
00007fa9d6dd2121  pop rdx
00007fa9d6dd2122  pop rcx
00007fa9d6dd2123  pop rax
00007fa9d6dd2124  add rsp, 0x08
00007fa9d6dd2128  jmp 0x00007FA9D6DCFBAB
00007fa9d6dd212d  call 0x00007FA9D6BFF430
00007fa9d6dd2132  jmp 0x00007FA9D6DCFBB8
00007fa9d6dd2137  sub rsp, 0x08
00007fa9d6dd213b  push rax
00007fa9d6dd213c  push rcx
00007fa9d6dd213d  push rdx
00007fa9d6dd213e  push rdi
00007fa9d6dd213f  push rsi
00007fa9d6dd2140  push r8
00007fa9d6dd2142  push r9
00007fa9d6dd2144  push r10
00007fa9d6dd2146  push r11
00007fa9d6dd2148  sub rsp, 0xF0
00007fa9d6dd214f  vmovaps [rsp], xmm0
00007fa9d6dd2154  vmovaps [rsp+0x10], xmm1
00007fa9d6dd215a  vmovaps [rsp+0x20], xmm2
00007fa9d6dd2160  vmovaps [rsp+0x30], xmm3
00007fa9d6dd2166  vmovaps [rsp+0x40], xmm4
00007fa9d6dd216c  vmovaps [rsp+0x50], xmm5
00007fa9d6dd2172  vmovaps [rsp+0x60], xmm6
00007fa9d6dd2178  vmovaps [rsp+0x70], xmm7
00007fa9d6dd217e  vmovaps [rsp+0x80], xmm8
00007fa9d6dd2187  vmovaps [rsp+0x90], xmm9
00007fa9d6dd2190  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd2199  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd21a2  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd21ab  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd21b4  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd21bd  sub rsp, 0x30
00007fa9d6dd21c1  movaps [rsp], xmm15
00007fa9d6dd21c6  movaps [rsp+0x10], xmm13
00007fa9d6dd21cc  movaps [rsp+0x20], xmm1
00007fa9d6dd21d1  lea rdi, [rsp]
00007fa9d6dd21d5  mov esi, 0x00
00007fa9d6dd21da  mov rax, 0x61DF872DB530
00007fa9d6dd21e4  call rax
00007fa9d6dd21e6  movaps xmm15, [rsp]
00007fa9d6dd21eb  add rsp, 0x30
00007fa9d6dd21ef  vmovaps xmm0, [rsp]
00007fa9d6dd21f4  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd21fa  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2200  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd2206  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd220c  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd2212  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd2218  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd221e  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd2227  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd2230  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd2239  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd2242  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd224b  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd2254  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd225d  add rsp, 0xF0
00007fa9d6dd2264  pop r11
00007fa9d6dd2266  pop r10
00007fa9d6dd2268  pop r9
00007fa9d6dd226a  pop r8
00007fa9d6dd226c  pop rsi
00007fa9d6dd226d  pop rdi
00007fa9d6dd226e  pop rdx
00007fa9d6dd226f  pop rcx
00007fa9d6dd2270  pop rax
00007fa9d6dd2271  add rsp, 0x08
00007fa9d6dd2275  jmp 0x00007FA9D6DCFBF7
00007fa9d6dd227a  sub rsp, 0x08
00007fa9d6dd227e  push rax
00007fa9d6dd227f  push rcx
00007fa9d6dd2280  push rdx
00007fa9d6dd2281  push rdi
00007fa9d6dd2282  push rsi
00007fa9d6dd2283  push r8
00007fa9d6dd2285  push r9
00007fa9d6dd2287  push r10
00007fa9d6dd2289  push r11
00007fa9d6dd228b  sub rsp, 0xF0
00007fa9d6dd2292  vmovaps [rsp], xmm0
00007fa9d6dd2297  vmovaps [rsp+0x10], xmm1
00007fa9d6dd229d  vmovaps [rsp+0x20], xmm2
00007fa9d6dd22a3  vmovaps [rsp+0x30], xmm3
00007fa9d6dd22a9  vmovaps [rsp+0x40], xmm4
00007fa9d6dd22af  vmovaps [rsp+0x50], xmm5
00007fa9d6dd22b5  vmovaps [rsp+0x60], xmm6
00007fa9d6dd22bb  vmovaps [rsp+0x70], xmm7
00007fa9d6dd22c1  vmovaps [rsp+0x80], xmm8
00007fa9d6dd22ca  vmovaps [rsp+0x90], xmm9
00007fa9d6dd22d3  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd22dc  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd22e5  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd22ee  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd22f7  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2300  sub rsp, 0x30
00007fa9d6dd2304  movaps [rsp], xmm14
00007fa9d6dd2309  movaps [rsp+0x10], xmm11
00007fa9d6dd230f  movaps [rsp+0x20], xmm1
00007fa9d6dd2314  lea rdi, [rsp]
00007fa9d6dd2318  mov esi, 0x00
00007fa9d6dd231d  mov rax, 0x61DF872DB530
00007fa9d6dd2327  call rax
00007fa9d6dd2329  movaps xmm14, [rsp]
00007fa9d6dd232e  add rsp, 0x30
00007fa9d6dd2332  vmovaps xmm0, [rsp]
00007fa9d6dd2337  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd233d  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2343  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd2349  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd234f  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd2355  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd235b  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd2361  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd236a  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd2373  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd237c  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd2385  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd238e  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd2397  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd23a0  add rsp, 0xF0
00007fa9d6dd23a7  pop r11
00007fa9d6dd23a9  pop r10
00007fa9d6dd23ab  pop r9
00007fa9d6dd23ad  pop r8
00007fa9d6dd23af  pop rsi
00007fa9d6dd23b0  pop rdi
00007fa9d6dd23b1  pop rdx
00007fa9d6dd23b2  pop rcx
00007fa9d6dd23b3  pop rax
00007fa9d6dd23b4  add rsp, 0x08
00007fa9d6dd23b8  jmp 0x00007FA9D6DCFC21
00007fa9d6dd23bd  sub rsp, 0x08
00007fa9d6dd23c1  push rax
00007fa9d6dd23c2  push rcx
00007fa9d6dd23c3  push rdx
00007fa9d6dd23c4  push rdi
00007fa9d6dd23c5  push rsi
00007fa9d6dd23c6  push r8
00007fa9d6dd23c8  push r9
00007fa9d6dd23ca  push r10
00007fa9d6dd23cc  push r11
00007fa9d6dd23ce  sub rsp, 0xF0
00007fa9d6dd23d5  vmovaps [rsp], xmm0
00007fa9d6dd23da  vmovaps [rsp+0x10], xmm1
00007fa9d6dd23e0  vmovaps [rsp+0x20], xmm2
00007fa9d6dd23e6  vmovaps [rsp+0x30], xmm3
00007fa9d6dd23ec  vmovaps [rsp+0x40], xmm4
00007fa9d6dd23f2  vmovaps [rsp+0x50], xmm5
00007fa9d6dd23f8  vmovaps [rsp+0x60], xmm6
00007fa9d6dd23fe  vmovaps [rsp+0x70], xmm7
00007fa9d6dd2404  vmovaps [rsp+0x80], xmm8
00007fa9d6dd240d  vmovaps [rsp+0x90], xmm9
00007fa9d6dd2416  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd241f  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd2428  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd2431  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd243a  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2443  sub rsp, 0x30
00007fa9d6dd2447  movaps [rsp], xmm13
00007fa9d6dd244c  movaps [rsp+0x10], xmm11
00007fa9d6dd2452  movaps [rsp+0x20], xmm1
00007fa9d6dd2457  lea rdi, [rsp]
00007fa9d6dd245b  mov esi, 0x00
00007fa9d6dd2460  mov rax, 0x61DF872DB530
00007fa9d6dd246a  call rax
00007fa9d6dd246c  movaps xmm13, [rsp]
00007fa9d6dd2471  add rsp, 0x30
00007fa9d6dd2475  vmovaps xmm0, [rsp]
00007fa9d6dd247a  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd2480  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2486  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd248c  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd2492  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd2498  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd249e  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd24a4  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd24ad  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd24b6  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd24bf  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd24c8  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd24d1  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd24da  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd24e3  add rsp, 0xF0
00007fa9d6dd24ea  pop r11
00007fa9d6dd24ec  pop r10
00007fa9d6dd24ee  pop r9
00007fa9d6dd24f0  pop r8
00007fa9d6dd24f2  pop rsi
00007fa9d6dd24f3  pop rdi
00007fa9d6dd24f4  pop rdx
00007fa9d6dd24f5  pop rcx
00007fa9d6dd24f6  pop rax
00007fa9d6dd24f7  add rsp, 0x08
00007fa9d6dd24fb  jmp 0x00007FA9D6DCFC76
00007fa9d6dd2500  call 0x00007FA9D6BFF430
00007fa9d6dd2505  jmp 0x00007FA9D6DCFC83
00007fa9d6dd250a  sub rsp, 0x08
00007fa9d6dd250e  push rax
00007fa9d6dd250f  push rcx
00007fa9d6dd2510  push rdx
00007fa9d6dd2511  push rdi
00007fa9d6dd2512  push rsi
00007fa9d6dd2513  push r8
00007fa9d6dd2515  push r9
00007fa9d6dd2517  push r10
00007fa9d6dd2519  push r11
00007fa9d6dd251b  sub rsp, 0xF0
00007fa9d6dd2522  vmovaps [rsp], xmm0
00007fa9d6dd2527  vmovaps [rsp+0x10], xmm1
00007fa9d6dd252d  vmovaps [rsp+0x20], xmm2
00007fa9d6dd2533  vmovaps [rsp+0x30], xmm3
00007fa9d6dd2539  vmovaps [rsp+0x40], xmm4
00007fa9d6dd253f  vmovaps [rsp+0x50], xmm5
00007fa9d6dd2545  vmovaps [rsp+0x60], xmm6
00007fa9d6dd254b  vmovaps [rsp+0x70], xmm7
00007fa9d6dd2551  vmovaps [rsp+0x80], xmm8
00007fa9d6dd255a  vmovaps [rsp+0x90], xmm9
00007fa9d6dd2563  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd256c  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd2575  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd257e  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd2587  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd2590  sub rsp, 0x30
00007fa9d6dd2594  movaps [rsp], xmm15
00007fa9d6dd2599  movaps [rsp+0x10], xmm11
00007fa9d6dd259f  movaps [rsp+0x20], xmm1
00007fa9d6dd25a4  lea rdi, [rsp]
00007fa9d6dd25a8  mov esi, 0x00
00007fa9d6dd25ad  mov rax, 0x61DF872DB530
00007fa9d6dd25b7  call rax
00007fa9d6dd25b9  movaps xmm15, [rsp]
00007fa9d6dd25be  add rsp, 0x30
00007fa9d6dd25c2  vmovaps xmm0, [rsp]
00007fa9d6dd25c7  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd25cd  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd25d3  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd25d9  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd25df  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd25e5  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd25eb  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd25f1  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd25fa  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd2603  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd260c  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd2615  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd261e  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd2627  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd2630  add rsp, 0xF0
00007fa9d6dd2637  pop r11
00007fa9d6dd2639  pop r10
00007fa9d6dd263b  pop r9
00007fa9d6dd263d  pop r8
00007fa9d6dd263f  pop rsi
00007fa9d6dd2640  pop rdi
00007fa9d6dd2641  pop rdx
00007fa9d6dd2642  pop rcx
00007fa9d6dd2643  pop rax
00007fa9d6dd2644  add rsp, 0x08
00007fa9d6dd2648  jmp 0x00007FA9D6DCFCBC
00007fa9d6dd264d  sub rsp, 0x08
00007fa9d6dd2651  push rax
00007fa9d6dd2652  push rcx
00007fa9d6dd2653  push rdx
00007fa9d6dd2654  push rdi
00007fa9d6dd2655  push rsi
00007fa9d6dd2656  push r8
00007fa9d6dd2658  push r9
00007fa9d6dd265a  push r10
00007fa9d6dd265c  push r11
00007fa9d6dd265e  sub rsp, 0xF0
00007fa9d6dd2665  vmovaps [rsp], xmm0
00007fa9d6dd266a  vmovaps [rsp+0x10], xmm1
00007fa9d6dd2670  vmovaps [rsp+0x20], xmm2
00007fa9d6dd2676  vmovaps [rsp+0x30], xmm3
00007fa9d6dd267c  vmovaps [rsp+0x40], xmm4
00007fa9d6dd2682  vmovaps [rsp+0x50], xmm5
00007fa9d6dd2688  vmovaps [rsp+0x60], xmm6
00007fa9d6dd268e  vmovaps [rsp+0x70], xmm7
00007fa9d6dd2694  vmovaps [rsp+0x80], xmm8
00007fa9d6dd269d  vmovaps [rsp+0x90], xmm9
00007fa9d6dd26a6  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd26af  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd26b8  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd26c1  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd26ca  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd26d3  sub rsp, 0x30
00007fa9d6dd26d7  movaps [rsp], xmm11
00007fa9d6dd26dc  movaps [rsp+0x10], xmm6
00007fa9d6dd26e1  movaps [rsp+0x20], xmm14
00007fa9d6dd26e7  lea rdi, [rsp]
00007fa9d6dd26eb  mov esi, 0x00
00007fa9d6dd26f0  mov rax, 0x61DF872DB530
00007fa9d6dd26fa  call rax
00007fa9d6dd26fc  movaps xmm11, [rsp]
00007fa9d6dd2701  add rsp, 0x30
00007fa9d6dd2705  vmovaps xmm0, [rsp]
00007fa9d6dd270a  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd2710  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2716  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd271c  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd2722  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd2728  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd272e  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd2734  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd273d  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd2746  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd274f  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd2758  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd2761  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd276a  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd2773  add rsp, 0xF0
00007fa9d6dd277a  pop r11
00007fa9d6dd277c  pop r10
00007fa9d6dd277e  pop r9
00007fa9d6dd2780  pop r8
00007fa9d6dd2782  pop rsi
00007fa9d6dd2783  pop rdi
00007fa9d6dd2784  pop rdx
00007fa9d6dd2785  pop rcx
00007fa9d6dd2786  pop rax
00007fa9d6dd2787  add rsp, 0x08
00007fa9d6dd278b  jmp 0x00007FA9D6DCFD34
00007fa9d6dd2790  call 0x00007FA9D6BFF430
00007fa9d6dd2795  jmp 0x00007FA9D6DCFD3E
00007fa9d6dd279a  sub rsp, 0x08
00007fa9d6dd279e  push rax
00007fa9d6dd279f  push rcx
00007fa9d6dd27a0  push rdx
00007fa9d6dd27a1  push rdi
00007fa9d6dd27a2  push rsi
00007fa9d6dd27a3  push r8
00007fa9d6dd27a5  push r9
00007fa9d6dd27a7  push r10
00007fa9d6dd27a9  push r11
00007fa9d6dd27ab  sub rsp, 0xF0
00007fa9d6dd27b2  vmovaps [rsp], xmm0
00007fa9d6dd27b7  vmovaps [rsp+0x10], xmm1
00007fa9d6dd27bd  vmovaps [rsp+0x20], xmm2
00007fa9d6dd27c3  vmovaps [rsp+0x30], xmm3
00007fa9d6dd27c9  vmovaps [rsp+0x40], xmm4
00007fa9d6dd27cf  vmovaps [rsp+0x50], xmm5
00007fa9d6dd27d5  vmovaps [rsp+0x60], xmm6
00007fa9d6dd27db  vmovaps [rsp+0x70], xmm7
00007fa9d6dd27e1  vmovaps [rsp+0x80], xmm8
00007fa9d6dd27ea  vmovaps [rsp+0x90], xmm9
00007fa9d6dd27f3  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd27fc  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd2805  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd280e  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd2817  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2820  sub rsp, 0x30
00007fa9d6dd2824  movaps [rsp], xmm14
00007fa9d6dd2829  movaps [rsp+0x10], xmm6
00007fa9d6dd282e  movaps [rsp+0x20], xmm2
00007fa9d6dd2833  lea rdi, [rsp]
00007fa9d6dd2837  mov esi, 0x00
00007fa9d6dd283c  mov rax, 0x61DF872DB530
00007fa9d6dd2846  call rax
00007fa9d6dd2848  movaps xmm14, [rsp]
00007fa9d6dd284d  add rsp, 0x30
00007fa9d6dd2851  vmovaps xmm0, [rsp]
00007fa9d6dd2856  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd285c  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2862  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd2868  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd286e  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd2874  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd287a  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd2880  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd2889  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd2892  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd289b  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd28a4  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd28ad  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd28b6  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd28bf  add rsp, 0xF0
00007fa9d6dd28c6  pop r11
00007fa9d6dd28c8  pop r10
00007fa9d6dd28ca  pop r9
00007fa9d6dd28cc  pop r8
00007fa9d6dd28ce  pop rsi
00007fa9d6dd28cf  pop rdi
00007fa9d6dd28d0  pop rdx
00007fa9d6dd28d1  pop rcx
00007fa9d6dd28d2  pop rax
00007fa9d6dd28d3  add rsp, 0x08
00007fa9d6dd28d7  jmp 0x00007FA9D6DCFD72
00007fa9d6dd28dc  sub rsp, 0x08
00007fa9d6dd28e0  push rax
00007fa9d6dd28e1  push rcx
00007fa9d6dd28e2  push rdx
00007fa9d6dd28e3  push rdi
00007fa9d6dd28e4  push rsi
00007fa9d6dd28e5  push r8
00007fa9d6dd28e7  push r9
00007fa9d6dd28e9  push r10
00007fa9d6dd28eb  push r11
00007fa9d6dd28ed  sub rsp, 0xF0
00007fa9d6dd28f4  vmovaps [rsp], xmm0
00007fa9d6dd28f9  vmovaps [rsp+0x10], xmm1
00007fa9d6dd28ff  vmovaps [rsp+0x20], xmm2
00007fa9d6dd2905  vmovaps [rsp+0x30], xmm3
00007fa9d6dd290b  vmovaps [rsp+0x40], xmm4
00007fa9d6dd2911  vmovaps [rsp+0x50], xmm5
00007fa9d6dd2917  vmovaps [rsp+0x60], xmm7
00007fa9d6dd291d  vmovaps [rsp+0x70], xmm8
00007fa9d6dd2923  vmovaps [rsp+0x80], xmm9
00007fa9d6dd292c  vmovaps [rsp+0x90], xmm10
00007fa9d6dd2935  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd293e  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd2947  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd2950  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd2959  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2962  sub rsp, 0x30
00007fa9d6dd2966  movaps [rsp], xmm6
00007fa9d6dd296a  movaps [rsp+0x10], xmm5
00007fa9d6dd296f  movaps [rsp+0x20], xmm1
00007fa9d6dd2974  lea rdi, [rsp]
00007fa9d6dd2978  mov esi, 0x00
00007fa9d6dd297d  mov rax, 0x61DF872DB530
00007fa9d6dd2987  call rax
00007fa9d6dd2989  movaps xmm6, [rsp]
00007fa9d6dd298d  add rsp, 0x30
00007fa9d6dd2991  vmovaps xmm0, [rsp]
00007fa9d6dd2996  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd299c  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd29a2  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd29a8  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd29ae  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd29b4  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd29ba  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd29c0  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd29c9  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd29d2  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd29db  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd29e4  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd29ed  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd29f6  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd29ff  add rsp, 0xF0
00007fa9d6dd2a06  pop r11
00007fa9d6dd2a08  pop r10
00007fa9d6dd2a0a  pop r9
00007fa9d6dd2a0c  pop r8
00007fa9d6dd2a0e  pop rsi
00007fa9d6dd2a0f  pop rdi
00007fa9d6dd2a10  pop rdx
00007fa9d6dd2a11  pop rcx
00007fa9d6dd2a12  pop rax
00007fa9d6dd2a13  add rsp, 0x08
00007fa9d6dd2a17  jmp 0x00007FA9D6DCFD98
00007fa9d6dd2a1c  sub rsp, 0x08
00007fa9d6dd2a20  push rax
00007fa9d6dd2a21  push rcx
00007fa9d6dd2a22  push rdx
00007fa9d6dd2a23  push rdi
00007fa9d6dd2a24  push rsi
00007fa9d6dd2a25  push r8
00007fa9d6dd2a27  push r9
00007fa9d6dd2a29  push r10
00007fa9d6dd2a2b  push r11
00007fa9d6dd2a2d  sub rsp, 0xF0
00007fa9d6dd2a34  vmovaps [rsp], xmm0
00007fa9d6dd2a39  vmovaps [rsp+0x10], xmm2
00007fa9d6dd2a3f  vmovaps [rsp+0x20], xmm3
00007fa9d6dd2a45  vmovaps [rsp+0x30], xmm4
00007fa9d6dd2a4b  vmovaps [rsp+0x40], xmm5
00007fa9d6dd2a51  vmovaps [rsp+0x50], xmm6
00007fa9d6dd2a57  vmovaps [rsp+0x60], xmm7
00007fa9d6dd2a5d  vmovaps [rsp+0x70], xmm8
00007fa9d6dd2a63  vmovaps [rsp+0x80], xmm9
00007fa9d6dd2a6c  vmovaps [rsp+0x90], xmm10
00007fa9d6dd2a75  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd2a7e  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd2a87  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd2a90  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd2a99  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2aa2  sub rsp, 0x30
00007fa9d6dd2aa6  movaps [rsp], xmm1
00007fa9d6dd2aaa  movaps [rsp+0x10], xmm5
00007fa9d6dd2aaf  movaps [rsp+0x20], xmm13
00007fa9d6dd2ab5  lea rdi, [rsp]
00007fa9d6dd2ab9  mov esi, 0x00
00007fa9d6dd2abe  mov rax, 0x61DF872DB530
00007fa9d6dd2ac8  call rax
00007fa9d6dd2aca  movaps xmm1, [rsp]
00007fa9d6dd2ace  add rsp, 0x30
00007fa9d6dd2ad2  vmovaps xmm0, [rsp]
00007fa9d6dd2ad7  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd2add  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd2ae3  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd2ae9  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd2aef  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd2af5  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd2afb  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd2b01  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd2b0a  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd2b13  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd2b1c  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd2b25  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd2b2e  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd2b37  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd2b40  add rsp, 0xF0
00007fa9d6dd2b47  pop r11
00007fa9d6dd2b49  pop r10
00007fa9d6dd2b4b  pop r9
00007fa9d6dd2b4d  pop r8
00007fa9d6dd2b4f  pop rsi
00007fa9d6dd2b50  pop rdi
00007fa9d6dd2b51  pop rdx
00007fa9d6dd2b52  pop rcx
00007fa9d6dd2b53  pop rax
00007fa9d6dd2b54  add rsp, 0x08
00007fa9d6dd2b58  jmp 0x00007FA9D6DCFDB6
00007fa9d6dd2b5d  sub rsp, 0x08
00007fa9d6dd2b61  push rax
00007fa9d6dd2b62  push rcx
00007fa9d6dd2b63  push rdx
00007fa9d6dd2b64  push rdi
00007fa9d6dd2b65  push rsi
00007fa9d6dd2b66  push r8
00007fa9d6dd2b68  push r9
00007fa9d6dd2b6a  push r10
00007fa9d6dd2b6c  push r11
00007fa9d6dd2b6e  sub rsp, 0xF0
00007fa9d6dd2b75  vmovaps [rsp], xmm0
00007fa9d6dd2b7a  vmovaps [rsp+0x10], xmm1
00007fa9d6dd2b80  vmovaps [rsp+0x20], xmm2
00007fa9d6dd2b86  vmovaps [rsp+0x30], xmm3
00007fa9d6dd2b8c  vmovaps [rsp+0x40], xmm4
00007fa9d6dd2b92  vmovaps [rsp+0x50], xmm6
00007fa9d6dd2b98  vmovaps [rsp+0x60], xmm7
00007fa9d6dd2b9e  vmovaps [rsp+0x70], xmm8
00007fa9d6dd2ba4  vmovaps [rsp+0x80], xmm9
00007fa9d6dd2bad  vmovaps [rsp+0x90], xmm10
00007fa9d6dd2bb6  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd2bbf  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd2bc8  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd2bd1  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd2bda  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2be3  sub rsp, 0x30
00007fa9d6dd2be7  movaps [rsp], xmm5
00007fa9d6dd2beb  movaps [rsp+0x10], xmm2
00007fa9d6dd2bf0  movaps [rsp+0x20], xmm13
00007fa9d6dd2bf6  lea rdi, [rsp]
00007fa9d6dd2bfa  mov esi, 0x00
00007fa9d6dd2bff  mov rax, 0x61DF872DB530
00007fa9d6dd2c09  call rax
00007fa9d6dd2c0b  movaps xmm5, [rsp]
00007fa9d6dd2c0f  add rsp, 0x30
00007fa9d6dd2c13  vmovaps xmm0, [rsp]
00007fa9d6dd2c18  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd2c1e  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2c24  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd2c2a  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd2c30  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd2c36  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd2c3c  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd2c42  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd2c4b  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd2c54  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd2c5d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd2c66  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd2c6f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd2c78  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd2c81  add rsp, 0xF0
00007fa9d6dd2c88  pop r11
00007fa9d6dd2c8a  pop r10
00007fa9d6dd2c8c  pop r9
00007fa9d6dd2c8e  pop r8
00007fa9d6dd2c90  pop rsi
00007fa9d6dd2c91  pop rdi
00007fa9d6dd2c92  pop rdx
00007fa9d6dd2c93  pop rcx
00007fa9d6dd2c94  pop rax
00007fa9d6dd2c95  add rsp, 0x08
00007fa9d6dd2c99  jmp 0x00007FA9D6DCFDEC
00007fa9d6dd2c9e  sub rsp, 0x08
00007fa9d6dd2ca2  push rax
00007fa9d6dd2ca3  push rcx
00007fa9d6dd2ca4  push rdx
00007fa9d6dd2ca5  push rdi
00007fa9d6dd2ca6  push rsi
00007fa9d6dd2ca7  push r8
00007fa9d6dd2ca9  push r9
00007fa9d6dd2cab  push r10
00007fa9d6dd2cad  push r11
00007fa9d6dd2caf  sub rsp, 0xF0
00007fa9d6dd2cb6  vmovaps [rsp], xmm0
00007fa9d6dd2cbb  vmovaps [rsp+0x10], xmm1
00007fa9d6dd2cc1  vmovaps [rsp+0x20], xmm2
00007fa9d6dd2cc7  vmovaps [rsp+0x30], xmm3
00007fa9d6dd2ccd  vmovaps [rsp+0x40], xmm4
00007fa9d6dd2cd3  vmovaps [rsp+0x50], xmm5
00007fa9d6dd2cd9  vmovaps [rsp+0x60], xmm6
00007fa9d6dd2cdf  vmovaps [rsp+0x70], xmm7
00007fa9d6dd2ce5  vmovaps [rsp+0x80], xmm8
00007fa9d6dd2cee  vmovaps [rsp+0x90], xmm9
00007fa9d6dd2cf7  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd2d00  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd2d09  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd2d12  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd2d1b  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2d24  sub rsp, 0x30
00007fa9d6dd2d28  movaps [rsp], xmm13
00007fa9d6dd2d2d  movaps [rsp+0x10], xmm10
00007fa9d6dd2d33  movaps [rsp+0x20], xmm1
00007fa9d6dd2d38  lea rdi, [rsp]
00007fa9d6dd2d3c  mov esi, 0x00
00007fa9d6dd2d41  mov rax, 0x61DF872DB530
00007fa9d6dd2d4b  call rax
00007fa9d6dd2d4d  movaps xmm13, [rsp]
00007fa9d6dd2d52  add rsp, 0x30
00007fa9d6dd2d56  vmovaps xmm0, [rsp]
00007fa9d6dd2d5b  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd2d61  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2d67  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd2d6d  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd2d73  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd2d79  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd2d7f  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd2d85  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd2d8e  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd2d97  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd2da0  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd2da9  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd2db2  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd2dbb  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd2dc4  add rsp, 0xF0
00007fa9d6dd2dcb  pop r11
00007fa9d6dd2dcd  pop r10
00007fa9d6dd2dcf  pop r9
00007fa9d6dd2dd1  pop r8
00007fa9d6dd2dd3  pop rsi
00007fa9d6dd2dd4  pop rdi
00007fa9d6dd2dd5  pop rdx
00007fa9d6dd2dd6  pop rcx
00007fa9d6dd2dd7  pop rax
00007fa9d6dd2dd8  add rsp, 0x08
00007fa9d6dd2ddc  jmp 0x00007FA9D6DCFE15
00007fa9d6dd2de1  sub rsp, 0x08
00007fa9d6dd2de5  push rax
00007fa9d6dd2de6  push rcx
00007fa9d6dd2de7  push rdx
00007fa9d6dd2de8  push rdi
00007fa9d6dd2de9  push rsi
00007fa9d6dd2dea  push r8
00007fa9d6dd2dec  push r9
00007fa9d6dd2dee  push r10
00007fa9d6dd2df0  push r11
00007fa9d6dd2df2  sub rsp, 0xF0
00007fa9d6dd2df9  vmovaps [rsp], xmm0
00007fa9d6dd2dfe  vmovaps [rsp+0x10], xmm2
00007fa9d6dd2e04  vmovaps [rsp+0x20], xmm3
00007fa9d6dd2e0a  vmovaps [rsp+0x30], xmm4
00007fa9d6dd2e10  vmovaps [rsp+0x40], xmm5
00007fa9d6dd2e16  vmovaps [rsp+0x50], xmm6
00007fa9d6dd2e1c  vmovaps [rsp+0x60], xmm7
00007fa9d6dd2e22  vmovaps [rsp+0x70], xmm8
00007fa9d6dd2e28  vmovaps [rsp+0x80], xmm9
00007fa9d6dd2e31  vmovaps [rsp+0x90], xmm10
00007fa9d6dd2e3a  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd2e43  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd2e4c  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd2e55  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd2e5e  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd2e67  sub rsp, 0x30
00007fa9d6dd2e6b  movaps [rsp], xmm1
00007fa9d6dd2e6f  movaps [rsp+0x10], xmm15
00007fa9d6dd2e75  movaps [rsp+0x20], xmm10
00007fa9d6dd2e7b  lea rdi, [rsp]
00007fa9d6dd2e7f  mov esi, 0x00
00007fa9d6dd2e84  mov rax, 0x61DF872DB530
00007fa9d6dd2e8e  call rax
00007fa9d6dd2e90  movaps xmm1, [rsp]
00007fa9d6dd2e94  add rsp, 0x30
00007fa9d6dd2e98  vmovaps xmm0, [rsp]
00007fa9d6dd2e9d  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd2ea3  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd2ea9  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd2eaf  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd2eb5  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd2ebb  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd2ec1  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd2ec7  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd2ed0  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd2ed9  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd2ee2  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd2eeb  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd2ef4  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd2efd  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd2f06  add rsp, 0xF0
00007fa9d6dd2f0d  pop r11
00007fa9d6dd2f0f  pop r10
00007fa9d6dd2f11  pop r9
00007fa9d6dd2f13  pop r8
00007fa9d6dd2f15  pop rsi
00007fa9d6dd2f16  pop rdi
00007fa9d6dd2f17  pop rdx
00007fa9d6dd2f18  pop rcx
00007fa9d6dd2f19  pop rax
00007fa9d6dd2f1a  add rsp, 0x08
00007fa9d6dd2f1e  jmp 0x00007FA9D6DCFE34
00007fa9d6dd2f23  sub rsp, 0x08
00007fa9d6dd2f27  push rax
00007fa9d6dd2f28  push rcx
00007fa9d6dd2f29  push rdx
00007fa9d6dd2f2a  push rdi
00007fa9d6dd2f2b  push rsi
00007fa9d6dd2f2c  push r8
00007fa9d6dd2f2e  push r9
00007fa9d6dd2f30  push r10
00007fa9d6dd2f32  push r11
00007fa9d6dd2f34  sub rsp, 0xF0
00007fa9d6dd2f3b  vmovaps [rsp], xmm0
00007fa9d6dd2f40  vmovaps [rsp+0x10], xmm1
00007fa9d6dd2f46  vmovaps [rsp+0x20], xmm2
00007fa9d6dd2f4c  vmovaps [rsp+0x30], xmm3
00007fa9d6dd2f52  vmovaps [rsp+0x40], xmm4
00007fa9d6dd2f58  vmovaps [rsp+0x50], xmm5
00007fa9d6dd2f5e  vmovaps [rsp+0x60], xmm6
00007fa9d6dd2f64  vmovaps [rsp+0x70], xmm7
00007fa9d6dd2f6a  vmovaps [rsp+0x80], xmm8
00007fa9d6dd2f73  vmovaps [rsp+0x90], xmm9
00007fa9d6dd2f7c  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd2f85  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd2f8e  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd2f97  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd2fa0  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd2fa9  sub rsp, 0x30
00007fa9d6dd2fad  movaps [rsp], xmm15
00007fa9d6dd2fb2  movaps [rsp+0x10], xmm10
00007fa9d6dd2fb8  movaps [rsp+0x20], xmm11
00007fa9d6dd2fbe  lea rdi, [rsp]
00007fa9d6dd2fc2  mov esi, 0x00
00007fa9d6dd2fc7  mov rax, 0x61DF872DB530
00007fa9d6dd2fd1  call rax
00007fa9d6dd2fd3  movaps xmm15, [rsp]
00007fa9d6dd2fd8  add rsp, 0x30
00007fa9d6dd2fdc  vmovaps xmm0, [rsp]
00007fa9d6dd2fe1  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd2fe7  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd2fed  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd2ff3  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd2ff9  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd2fff  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3005  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd300b  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd3014  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd301d  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd3026  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd302f  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd3038  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd3041  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd304a  add rsp, 0xF0
00007fa9d6dd3051  pop r11
00007fa9d6dd3053  pop r10
00007fa9d6dd3055  pop r9
00007fa9d6dd3057  pop r8
00007fa9d6dd3059  pop rsi
00007fa9d6dd305a  pop rdi
00007fa9d6dd305b  pop rdx
00007fa9d6dd305c  pop rcx
00007fa9d6dd305d  pop rax
00007fa9d6dd305e  add rsp, 0x08
00007fa9d6dd3062  jmp 0x00007FA9D6DCFE57
00007fa9d6dd3067  sub rsp, 0x08
00007fa9d6dd306b  push rax
00007fa9d6dd306c  push rcx
00007fa9d6dd306d  push rdx
00007fa9d6dd306e  push rdi
00007fa9d6dd306f  push rsi
00007fa9d6dd3070  push r8
00007fa9d6dd3072  push r9
00007fa9d6dd3074  push r10
00007fa9d6dd3076  push r11
00007fa9d6dd3078  sub rsp, 0xF0
00007fa9d6dd307f  vmovaps [rsp], xmm0
00007fa9d6dd3084  vmovaps [rsp+0x10], xmm1
00007fa9d6dd308a  vmovaps [rsp+0x20], xmm2
00007fa9d6dd3090  vmovaps [rsp+0x30], xmm3
00007fa9d6dd3096  vmovaps [rsp+0x40], xmm4
00007fa9d6dd309c  vmovaps [rsp+0x50], xmm5
00007fa9d6dd30a2  vmovaps [rsp+0x60], xmm6
00007fa9d6dd30a8  vmovaps [rsp+0x70], xmm7
00007fa9d6dd30ae  vmovaps [rsp+0x80], xmm8
00007fa9d6dd30b7  vmovaps [rsp+0x90], xmm9
00007fa9d6dd30c0  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd30c9  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd30d2  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd30db  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd30e4  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd30ed  sub rsp, 0x30
00007fa9d6dd30f1  movaps [rsp], xmm10
00007fa9d6dd30f6  movaps [rsp+0x10], xmm12
00007fa9d6dd30fc  movaps [rsp+0x20], xmm11
00007fa9d6dd3102  lea rdi, [rsp]
00007fa9d6dd3106  mov esi, 0x00
00007fa9d6dd310b  mov rax, 0x61DF872DB530
00007fa9d6dd3115  call rax
00007fa9d6dd3117  movaps xmm10, [rsp]
00007fa9d6dd311c  add rsp, 0x30
00007fa9d6dd3120  vmovaps xmm0, [rsp]
00007fa9d6dd3125  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd312b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd3131  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd3137  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd313d  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd3143  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3149  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd314f  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd3158  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd3161  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd316a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd3173  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd317c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd3185  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd318e  add rsp, 0xF0
00007fa9d6dd3195  pop r11
00007fa9d6dd3197  pop r10
00007fa9d6dd3199  pop r9
00007fa9d6dd319b  pop r8
00007fa9d6dd319d  pop rsi
00007fa9d6dd319e  pop rdi
00007fa9d6dd319f  pop rdx
00007fa9d6dd31a0  pop rcx
00007fa9d6dd31a1  pop rax
00007fa9d6dd31a2  add rsp, 0x08
00007fa9d6dd31a6  jmp 0x00007FA9D6DCFE80
00007fa9d6dd31ab  sub rsp, 0x08
00007fa9d6dd31af  push rax
00007fa9d6dd31b0  push rcx
00007fa9d6dd31b1  push rdx
00007fa9d6dd31b2  push rdi
00007fa9d6dd31b3  push rsi
00007fa9d6dd31b4  push r8
00007fa9d6dd31b6  push r9
00007fa9d6dd31b8  push r10
00007fa9d6dd31ba  push r11
00007fa9d6dd31bc  sub rsp, 0xF0
00007fa9d6dd31c3  vmovaps [rsp], xmm0
00007fa9d6dd31c8  vmovaps [rsp+0x10], xmm1
00007fa9d6dd31ce  vmovaps [rsp+0x20], xmm2
00007fa9d6dd31d4  vmovaps [rsp+0x30], xmm3
00007fa9d6dd31da  vmovaps [rsp+0x40], xmm4
00007fa9d6dd31e0  vmovaps [rsp+0x50], xmm5
00007fa9d6dd31e6  vmovaps [rsp+0x60], xmm6
00007fa9d6dd31ec  vmovaps [rsp+0x70], xmm7
00007fa9d6dd31f2  vmovaps [rsp+0x80], xmm8
00007fa9d6dd31fb  vmovaps [rsp+0x90], xmm9
00007fa9d6dd3204  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd320d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd3216  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd321f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd3228  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd3231  sub rsp, 0x30
00007fa9d6dd3235  movaps [rsp], xmm11
00007fa9d6dd323a  movaps [rsp+0x10], xmm2
00007fa9d6dd323f  movaps [rsp+0x20], xmm12
00007fa9d6dd3245  lea rdi, [rsp]
00007fa9d6dd3249  mov esi, 0x00
00007fa9d6dd324e  mov rax, 0x61DF872DB530
00007fa9d6dd3258  call rax
00007fa9d6dd325a  movaps xmm11, [rsp]
00007fa9d6dd325f  add rsp, 0x30
00007fa9d6dd3263  vmovaps xmm0, [rsp]
00007fa9d6dd3268  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd326e  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd3274  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd327a  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd3280  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd3286  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd328c  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd3292  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd329b  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd32a4  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd32ad  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd32b6  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd32bf  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd32c8  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd32d1  add rsp, 0xF0
00007fa9d6dd32d8  pop r11
00007fa9d6dd32da  pop r10
00007fa9d6dd32dc  pop r9
00007fa9d6dd32de  pop r8
00007fa9d6dd32e0  pop rsi
00007fa9d6dd32e1  pop rdi
00007fa9d6dd32e2  pop rdx
00007fa9d6dd32e3  pop rcx
00007fa9d6dd32e4  pop rax
00007fa9d6dd32e5  add rsp, 0x08
00007fa9d6dd32e9  jmp 0x00007FA9D6DCFEB8
00007fa9d6dd32ee  sub rsp, 0x08
00007fa9d6dd32f2  push rax
00007fa9d6dd32f3  push rcx
00007fa9d6dd32f4  push rdx
00007fa9d6dd32f5  push rdi
00007fa9d6dd32f6  push rsi
00007fa9d6dd32f7  push r8
00007fa9d6dd32f9  push r9
00007fa9d6dd32fb  push r10
00007fa9d6dd32fd  push r11
00007fa9d6dd32ff  sub rsp, 0xF0
00007fa9d6dd3306  vmovaps [rsp], xmm0
00007fa9d6dd330b  vmovaps [rsp+0x10], xmm2
00007fa9d6dd3311  vmovaps [rsp+0x20], xmm3
00007fa9d6dd3317  vmovaps [rsp+0x30], xmm4
00007fa9d6dd331d  vmovaps [rsp+0x40], xmm5
00007fa9d6dd3323  vmovaps [rsp+0x50], xmm6
00007fa9d6dd3329  vmovaps [rsp+0x60], xmm7
00007fa9d6dd332f  vmovaps [rsp+0x70], xmm8
00007fa9d6dd3335  vmovaps [rsp+0x80], xmm9
00007fa9d6dd333e  vmovaps [rsp+0x90], xmm10
00007fa9d6dd3347  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd3350  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd3359  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd3362  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd336b  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd3374  sub rsp, 0x30
00007fa9d6dd3378  movaps [rsp], xmm1
00007fa9d6dd337c  movaps [rsp+0x10], xmm14
00007fa9d6dd3382  movaps [rsp+0x20], xmm6
00007fa9d6dd3387  lea rdi, [rsp]
00007fa9d6dd338b  mov esi, 0x00
00007fa9d6dd3390  mov rax, 0x61DF872DB530
00007fa9d6dd339a  call rax
00007fa9d6dd339c  movaps xmm1, [rsp]
00007fa9d6dd33a0  add rsp, 0x30
00007fa9d6dd33a4  vmovaps xmm0, [rsp]
00007fa9d6dd33a9  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd33af  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd33b5  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd33bb  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd33c1  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd33c7  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd33cd  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd33d3  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd33dc  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd33e5  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd33ee  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd33f7  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd3400  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd3409  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3412  add rsp, 0xF0
00007fa9d6dd3419  pop r11
00007fa9d6dd341b  pop r10
00007fa9d6dd341d  pop r9
00007fa9d6dd341f  pop r8
00007fa9d6dd3421  pop rsi
00007fa9d6dd3422  pop rdi
00007fa9d6dd3423  pop rdx
00007fa9d6dd3424  pop rcx
00007fa9d6dd3425  pop rax
00007fa9d6dd3426  add rsp, 0x08
00007fa9d6dd342a  jmp 0x00007FA9D6DCFED1
00007fa9d6dd342f  sub rsp, 0x08
00007fa9d6dd3433  push rax
00007fa9d6dd3434  push rcx
00007fa9d6dd3435  push rdx
00007fa9d6dd3436  push rdi
00007fa9d6dd3437  push rsi
00007fa9d6dd3438  push r8
00007fa9d6dd343a  push r9
00007fa9d6dd343c  push r10
00007fa9d6dd343e  push r11
00007fa9d6dd3440  sub rsp, 0xF0
00007fa9d6dd3447  vmovaps [rsp], xmm0
00007fa9d6dd344c  vmovaps [rsp+0x10], xmm1
00007fa9d6dd3452  vmovaps [rsp+0x20], xmm2
00007fa9d6dd3458  vmovaps [rsp+0x30], xmm3
00007fa9d6dd345e  vmovaps [rsp+0x40], xmm4
00007fa9d6dd3464  vmovaps [rsp+0x50], xmm5
00007fa9d6dd346a  vmovaps [rsp+0x60], xmm6
00007fa9d6dd3470  vmovaps [rsp+0x70], xmm7
00007fa9d6dd3476  vmovaps [rsp+0x80], xmm8
00007fa9d6dd347f  vmovaps [rsp+0x90], xmm9
00007fa9d6dd3488  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd3491  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd349a  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd34a3  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd34ac  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd34b5  sub rsp, 0x30
00007fa9d6dd34b9  movaps [rsp], xmm14
00007fa9d6dd34be  movaps [rsp+0x10], xmm12
00007fa9d6dd34c4  movaps [rsp+0x20], xmm5
00007fa9d6dd34c9  lea rdi, [rsp]
00007fa9d6dd34cd  mov esi, 0x00
00007fa9d6dd34d2  mov rax, 0x61DF872DB530
00007fa9d6dd34dc  call rax
00007fa9d6dd34de  movaps xmm14, [rsp]
00007fa9d6dd34e3  add rsp, 0x30
00007fa9d6dd34e7  vmovaps xmm0, [rsp]
00007fa9d6dd34ec  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd34f2  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd34f8  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd34fe  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd3504  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd350a  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3510  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd3516  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd351f  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd3528  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd3531  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd353a  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd3543  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd354c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3555  add rsp, 0xF0
00007fa9d6dd355c  pop r11
00007fa9d6dd355e  pop r10
00007fa9d6dd3560  pop r9
00007fa9d6dd3562  pop r8
00007fa9d6dd3564  pop rsi
00007fa9d6dd3565  pop rdi
00007fa9d6dd3566  pop rdx
00007fa9d6dd3567  pop rcx
00007fa9d6dd3568  pop rax
00007fa9d6dd3569  add rsp, 0x08
00007fa9d6dd356d  jmp 0x00007FA9D6DCFEF1
00007fa9d6dd3572  sub rsp, 0x08
00007fa9d6dd3576  push rax
00007fa9d6dd3577  push rcx
00007fa9d6dd3578  push rdx
00007fa9d6dd3579  push rdi
00007fa9d6dd357a  push rsi
00007fa9d6dd357b  push r8
00007fa9d6dd357d  push r9
00007fa9d6dd357f  push r10
00007fa9d6dd3581  push r11
00007fa9d6dd3583  sub rsp, 0xF0
00007fa9d6dd358a  vmovaps [rsp], xmm0
00007fa9d6dd358f  vmovaps [rsp+0x10], xmm1
00007fa9d6dd3595  vmovaps [rsp+0x20], xmm2
00007fa9d6dd359b  vmovaps [rsp+0x30], xmm3
00007fa9d6dd35a1  vmovaps [rsp+0x40], xmm4
00007fa9d6dd35a7  vmovaps [rsp+0x50], xmm5
00007fa9d6dd35ad  vmovaps [rsp+0x60], xmm7
00007fa9d6dd35b3  vmovaps [rsp+0x70], xmm8
00007fa9d6dd35b9  vmovaps [rsp+0x80], xmm9
00007fa9d6dd35c2  vmovaps [rsp+0x90], xmm10
00007fa9d6dd35cb  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd35d4  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd35dd  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd35e6  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd35ef  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd35f8  sub rsp, 0x30
00007fa9d6dd35fc  movaps [rsp], xmm6
00007fa9d6dd3600  movaps [rsp+0x10], xmm9
00007fa9d6dd3606  movaps [rsp+0x20], xmm12
00007fa9d6dd360c  lea rdi, [rsp]
00007fa9d6dd3610  mov esi, 0x00
00007fa9d6dd3615  mov rax, 0x61DF872DB530
00007fa9d6dd361f  call rax
00007fa9d6dd3621  movaps xmm6, [rsp]
00007fa9d6dd3625  add rsp, 0x30
00007fa9d6dd3629  vmovaps xmm0, [rsp]
00007fa9d6dd362e  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd3634  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd363a  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd3640  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd3646  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd364c  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd3652  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd3658  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd3661  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd366a  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd3673  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd367c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd3685  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd368e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3697  add rsp, 0xF0
00007fa9d6dd369e  pop r11
00007fa9d6dd36a0  pop r10
00007fa9d6dd36a2  pop r9
00007fa9d6dd36a4  pop r8
00007fa9d6dd36a6  pop rsi
00007fa9d6dd36a7  pop rdi
00007fa9d6dd36a8  pop rdx
00007fa9d6dd36a9  pop rcx
00007fa9d6dd36aa  pop rax
00007fa9d6dd36ab  add rsp, 0x08
00007fa9d6dd36af  jmp 0x00007FA9D6DCFF19
00007fa9d6dd36b4  sub rsp, 0x08
00007fa9d6dd36b8  push rax
00007fa9d6dd36b9  push rcx
00007fa9d6dd36ba  push rdx
00007fa9d6dd36bb  push rdi
00007fa9d6dd36bc  push rsi
00007fa9d6dd36bd  push r8
00007fa9d6dd36bf  push r9
00007fa9d6dd36c1  push r10
00007fa9d6dd36c3  push r11
00007fa9d6dd36c5  sub rsp, 0xF0
00007fa9d6dd36cc  vmovaps [rsp], xmm0
00007fa9d6dd36d1  vmovaps [rsp+0x10], xmm1
00007fa9d6dd36d7  vmovaps [rsp+0x20], xmm2
00007fa9d6dd36dd  vmovaps [rsp+0x30], xmm3
00007fa9d6dd36e3  vmovaps [rsp+0x40], xmm4
00007fa9d6dd36e9  vmovaps [rsp+0x50], xmm5
00007fa9d6dd36ef  vmovaps [rsp+0x60], xmm6
00007fa9d6dd36f5  vmovaps [rsp+0x70], xmm7
00007fa9d6dd36fb  vmovaps [rsp+0x80], xmm8
00007fa9d6dd3704  vmovaps [rsp+0x90], xmm9
00007fa9d6dd370d  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd3716  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd371f  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd3728  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd3731  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd373a  sub rsp, 0x30
00007fa9d6dd373e  movaps [rsp], xmm12
00007fa9d6dd3743  movaps [rsp+0x10], xmm15
00007fa9d6dd3749  movaps [rsp+0x20], xmm13
00007fa9d6dd374f  lea rdi, [rsp]
00007fa9d6dd3753  mov esi, 0x00
00007fa9d6dd3758  mov rax, 0x61DF872DB530
00007fa9d6dd3762  call rax
00007fa9d6dd3764  movaps xmm12, [rsp]
00007fa9d6dd3769  add rsp, 0x30
00007fa9d6dd376d  vmovaps xmm0, [rsp]
00007fa9d6dd3772  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd3778  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd377e  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd3784  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd378a  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd3790  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3796  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd379c  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd37a5  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd37ae  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd37b7  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd37c0  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd37c9  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd37d2  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd37db  add rsp, 0xF0
00007fa9d6dd37e2  pop r11
00007fa9d6dd37e4  pop r10
00007fa9d6dd37e6  pop r9
00007fa9d6dd37e8  pop r8
00007fa9d6dd37ea  pop rsi
00007fa9d6dd37eb  pop rdi
00007fa9d6dd37ec  pop rdx
00007fa9d6dd37ed  pop rcx
00007fa9d6dd37ee  pop rax
00007fa9d6dd37ef  add rsp, 0x08
00007fa9d6dd37f3  jmp 0x00007FA9D6DCFF34
00007fa9d6dd37f8  sub rsp, 0x08
00007fa9d6dd37fc  push rax
00007fa9d6dd37fd  push rcx
00007fa9d6dd37fe  push rdx
00007fa9d6dd37ff  push rdi
00007fa9d6dd3800  push rsi
00007fa9d6dd3801  push r8
00007fa9d6dd3803  push r9
00007fa9d6dd3805  push r10
00007fa9d6dd3807  push r11
00007fa9d6dd3809  sub rsp, 0xF0
00007fa9d6dd3810  vmovaps [rsp], xmm0
00007fa9d6dd3815  vmovaps [rsp+0x10], xmm1
00007fa9d6dd381b  vmovaps [rsp+0x20], xmm2
00007fa9d6dd3821  vmovaps [rsp+0x30], xmm3
00007fa9d6dd3827  vmovaps [rsp+0x40], xmm4
00007fa9d6dd382d  vmovaps [rsp+0x50], xmm5
00007fa9d6dd3833  vmovaps [rsp+0x60], xmm6
00007fa9d6dd3839  vmovaps [rsp+0x70], xmm7
00007fa9d6dd383f  vmovaps [rsp+0x80], xmm8
00007fa9d6dd3848  vmovaps [rsp+0x90], xmm9
00007fa9d6dd3851  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd385a  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd3863  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd386c  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd3875  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd387e  sub rsp, 0x30
00007fa9d6dd3882  movaps [rsp], xmm15
00007fa9d6dd3887  movaps [rsp+0x10], xmm13
00007fa9d6dd388d  movaps [rsp+0x20], xmm10
00007fa9d6dd3893  lea rdi, [rsp]
00007fa9d6dd3897  mov esi, 0x00
00007fa9d6dd389c  mov rax, 0x61DF872DB530
00007fa9d6dd38a6  call rax
00007fa9d6dd38a8  movaps xmm15, [rsp]
00007fa9d6dd38ad  add rsp, 0x30
00007fa9d6dd38b1  vmovaps xmm0, [rsp]
00007fa9d6dd38b6  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd38bc  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd38c2  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd38c8  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd38ce  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd38d4  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd38da  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd38e0  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd38e9  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd38f2  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd38fb  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd3904  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd390d  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd3916  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd391f  add rsp, 0xF0
00007fa9d6dd3926  pop r11
00007fa9d6dd3928  pop r10
00007fa9d6dd392a  pop r9
00007fa9d6dd392c  pop r8
00007fa9d6dd392e  pop rsi
00007fa9d6dd392f  pop rdi
00007fa9d6dd3930  pop rdx
00007fa9d6dd3931  pop rcx
00007fa9d6dd3932  pop rax
00007fa9d6dd3933  add rsp, 0x08
00007fa9d6dd3937  jmp 0x00007FA9D6DCFF55
00007fa9d6dd393c  call 0x00007FA9D6C0C260
00007fa9d6dd3941  jmp 0x00007FA9D6DCFFB0
00007fa9d6dd3946  sub rsp, 0x08
00007fa9d6dd394a  push rax
00007fa9d6dd394b  push rcx
00007fa9d6dd394c  push rdx
00007fa9d6dd394d  push rdi
00007fa9d6dd394e  push rsi
00007fa9d6dd394f  push r8
00007fa9d6dd3951  push r9
00007fa9d6dd3953  push r10
00007fa9d6dd3955  push r11
00007fa9d6dd3957  sub rsp, 0xF0
00007fa9d6dd395e  vmovaps [rsp], xmm0
00007fa9d6dd3963  vmovaps [rsp+0x10], xmm1
00007fa9d6dd3969  vmovaps [rsp+0x20], xmm2
00007fa9d6dd396f  vmovaps [rsp+0x30], xmm3
00007fa9d6dd3975  vmovaps [rsp+0x40], xmm4
00007fa9d6dd397b  vmovaps [rsp+0x50], xmm5
00007fa9d6dd3981  vmovaps [rsp+0x60], xmm6
00007fa9d6dd3987  vmovaps [rsp+0x70], xmm7
00007fa9d6dd398d  vmovaps [rsp+0x80], xmm8
00007fa9d6dd3996  vmovaps [rsp+0x90], xmm10
00007fa9d6dd399f  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd39a8  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd39b1  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd39ba  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd39c3  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd39cc  sub rsp, 0x30
00007fa9d6dd39d0  movaps [rsp], xmm9
00007fa9d6dd39d5  movaps [rsp+0x10], xmm8
00007fa9d6dd39db  movaps [rsp+0x20], xmm10
00007fa9d6dd39e1  lea rdi, [rsp]
00007fa9d6dd39e5  mov esi, 0x00
00007fa9d6dd39ea  mov rax, 0x61DF872DB530
00007fa9d6dd39f4  call rax
00007fa9d6dd39f6  movaps xmm9, [rsp]
00007fa9d6dd39fb  add rsp, 0x30
00007fa9d6dd39ff  vmovaps xmm0, [rsp]
00007fa9d6dd3a04  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd3a0a  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd3a10  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd3a16  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd3a1c  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd3a22  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3a28  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd3a2e  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd3a37  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd3a40  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd3a49  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd3a52  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd3a5b  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd3a64  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3a6d  add rsp, 0xF0
00007fa9d6dd3a74  pop r11
00007fa9d6dd3a76  pop r10
00007fa9d6dd3a78  pop r9
00007fa9d6dd3a7a  pop r8
00007fa9d6dd3a7c  pop rsi
00007fa9d6dd3a7d  pop rdi
00007fa9d6dd3a7e  pop rdx
00007fa9d6dd3a7f  pop rcx
00007fa9d6dd3a80  pop rax
00007fa9d6dd3a81  add rsp, 0x08
00007fa9d6dd3a85  jmp 0x00007FA9D6DCFFE1
00007fa9d6dd3a8a  sub rsp, 0x08
00007fa9d6dd3a8e  push rax
00007fa9d6dd3a8f  push rcx
00007fa9d6dd3a90  push rdx
00007fa9d6dd3a91  push rdi
00007fa9d6dd3a92  push rsi
00007fa9d6dd3a93  push r8
00007fa9d6dd3a95  push r9
00007fa9d6dd3a97  push r10
00007fa9d6dd3a99  push r11
00007fa9d6dd3a9b  sub rsp, 0xF0
00007fa9d6dd3aa2  vmovaps [rsp], xmm0
00007fa9d6dd3aa7  vmovaps [rsp+0x10], xmm1
00007fa9d6dd3aad  vmovaps [rsp+0x20], xmm2
00007fa9d6dd3ab3  vmovaps [rsp+0x30], xmm3
00007fa9d6dd3ab9  vmovaps [rsp+0x40], xmm4
00007fa9d6dd3abf  vmovaps [rsp+0x50], xmm5
00007fa9d6dd3ac5  vmovaps [rsp+0x60], xmm6
00007fa9d6dd3acb  vmovaps [rsp+0x70], xmm7
00007fa9d6dd3ad1  vmovaps [rsp+0x80], xmm8
00007fa9d6dd3ada  vmovaps [rsp+0x90], xmm9
00007fa9d6dd3ae3  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd3aec  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd3af5  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd3afe  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd3b07  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd3b10  sub rsp, 0x30
00007fa9d6dd3b14  movaps [rsp], xmm10
00007fa9d6dd3b19  movaps [rsp+0x10], xmm1
00007fa9d6dd3b1e  movaps [rsp+0x20], xmm11
00007fa9d6dd3b24  lea rdi, [rsp]
00007fa9d6dd3b28  mov esi, 0x00
00007fa9d6dd3b2d  mov rax, 0x61DF872DB530
00007fa9d6dd3b37  call rax
00007fa9d6dd3b39  movaps xmm10, [rsp]
00007fa9d6dd3b3e  add rsp, 0x30
00007fa9d6dd3b42  vmovaps xmm0, [rsp]
00007fa9d6dd3b47  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd3b4d  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd3b53  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd3b59  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd3b5f  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd3b65  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3b6b  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd3b71  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd3b7a  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd3b83  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd3b8c  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd3b95  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd3b9e  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd3ba7  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3bb0  add rsp, 0xF0
00007fa9d6dd3bb7  pop r11
00007fa9d6dd3bb9  pop r10
00007fa9d6dd3bbb  pop r9
00007fa9d6dd3bbd  pop r8
00007fa9d6dd3bbf  pop rsi
00007fa9d6dd3bc0  pop rdi
00007fa9d6dd3bc1  pop rdx
00007fa9d6dd3bc2  pop rcx
00007fa9d6dd3bc3  pop rax
00007fa9d6dd3bc4  add rsp, 0x08
00007fa9d6dd3bc8  jmp 0x00007FA9D6DCFFFC
00007fa9d6dd3bcd  sub rsp, 0x08
00007fa9d6dd3bd1  push rax
00007fa9d6dd3bd2  push rcx
00007fa9d6dd3bd3  push rdx
00007fa9d6dd3bd4  push rdi
00007fa9d6dd3bd5  push rsi
00007fa9d6dd3bd6  push r8
00007fa9d6dd3bd8  push r9
00007fa9d6dd3bda  push r10
00007fa9d6dd3bdc  push r11
00007fa9d6dd3bde  sub rsp, 0xF0
00007fa9d6dd3be5  vmovaps [rsp], xmm0
00007fa9d6dd3bea  vmovaps [rsp+0x10], xmm2
00007fa9d6dd3bf0  vmovaps [rsp+0x20], xmm3
00007fa9d6dd3bf6  vmovaps [rsp+0x30], xmm4
00007fa9d6dd3bfc  vmovaps [rsp+0x40], xmm5
00007fa9d6dd3c02  vmovaps [rsp+0x50], xmm6
00007fa9d6dd3c08  vmovaps [rsp+0x60], xmm7
00007fa9d6dd3c0e  vmovaps [rsp+0x70], xmm8
00007fa9d6dd3c14  vmovaps [rsp+0x80], xmm9
00007fa9d6dd3c1d  vmovaps [rsp+0x90], xmm10
00007fa9d6dd3c26  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd3c2f  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd3c38  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd3c41  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd3c4a  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd3c53  sub rsp, 0x30
00007fa9d6dd3c57  movaps [rsp], xmm1
00007fa9d6dd3c5b  movaps [rsp+0x10], xmm14
00007fa9d6dd3c61  movaps [rsp+0x20], xmm6
00007fa9d6dd3c66  lea rdi, [rsp]
00007fa9d6dd3c6a  mov esi, 0x00
00007fa9d6dd3c6f  mov rax, 0x61DF872DB530
00007fa9d6dd3c79  call rax
00007fa9d6dd3c7b  movaps xmm1, [rsp]
00007fa9d6dd3c7f  add rsp, 0x30
00007fa9d6dd3c83  vmovaps xmm0, [rsp]
00007fa9d6dd3c88  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd3c8e  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd3c94  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd3c9a  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd3ca0  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd3ca6  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd3cac  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd3cb2  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd3cbb  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd3cc4  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd3ccd  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd3cd6  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd3cdf  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd3ce8  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3cf1  add rsp, 0xF0
00007fa9d6dd3cf8  pop r11
00007fa9d6dd3cfa  pop r10
00007fa9d6dd3cfc  pop r9
00007fa9d6dd3cfe  pop r8
00007fa9d6dd3d00  pop rsi
00007fa9d6dd3d01  pop rdi
00007fa9d6dd3d02  pop rdx
00007fa9d6dd3d03  pop rcx
00007fa9d6dd3d04  pop rax
00007fa9d6dd3d05  add rsp, 0x08
00007fa9d6dd3d09  jmp 0x00007FA9D6DD0015
00007fa9d6dd3d0e  sub rsp, 0x08
00007fa9d6dd3d12  push rax
00007fa9d6dd3d13  push rcx
00007fa9d6dd3d14  push rdx
00007fa9d6dd3d15  push rdi
00007fa9d6dd3d16  push rsi
00007fa9d6dd3d17  push r8
00007fa9d6dd3d19  push r9
00007fa9d6dd3d1b  push r10
00007fa9d6dd3d1d  push r11
00007fa9d6dd3d1f  sub rsp, 0xF0
00007fa9d6dd3d26  vmovaps [rsp], xmm0
00007fa9d6dd3d2b  vmovaps [rsp+0x10], xmm1
00007fa9d6dd3d31  vmovaps [rsp+0x20], xmm2
00007fa9d6dd3d37  vmovaps [rsp+0x30], xmm3
00007fa9d6dd3d3d  vmovaps [rsp+0x40], xmm4
00007fa9d6dd3d43  vmovaps [rsp+0x50], xmm5
00007fa9d6dd3d49  vmovaps [rsp+0x60], xmm6
00007fa9d6dd3d4f  vmovaps [rsp+0x70], xmm7
00007fa9d6dd3d55  vmovaps [rsp+0x80], xmm8
00007fa9d6dd3d5e  vmovaps [rsp+0x90], xmm9
00007fa9d6dd3d67  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd3d70  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd3d79  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd3d82  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd3d8b  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd3d94  sub rsp, 0x30
00007fa9d6dd3d98  movaps [rsp], xmm11
00007fa9d6dd3d9d  movaps [rsp+0x10], xmm13
00007fa9d6dd3da3  movaps [rsp+0x20], xmm14
00007fa9d6dd3da9  lea rdi, [rsp]
00007fa9d6dd3dad  mov esi, 0x00
00007fa9d6dd3db2  mov rax, 0x61DF872DB530
00007fa9d6dd3dbc  call rax
00007fa9d6dd3dbe  movaps xmm11, [rsp]
00007fa9d6dd3dc3  add rsp, 0x30
00007fa9d6dd3dc7  vmovaps xmm0, [rsp]
00007fa9d6dd3dcc  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd3dd2  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd3dd8  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd3dde  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd3de4  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd3dea  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3df0  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd3df6  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd3dff  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd3e08  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd3e11  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd3e1a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd3e23  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd3e2c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3e35  add rsp, 0xF0
00007fa9d6dd3e3c  pop r11
00007fa9d6dd3e3e  pop r10
00007fa9d6dd3e40  pop r9
00007fa9d6dd3e42  pop r8
00007fa9d6dd3e44  pop rsi
00007fa9d6dd3e45  pop rdi
00007fa9d6dd3e46  pop rdx
00007fa9d6dd3e47  pop rcx
00007fa9d6dd3e48  pop rax
00007fa9d6dd3e49  add rsp, 0x08
00007fa9d6dd3e4d  jmp 0x00007FA9D6DD003F
00007fa9d6dd3e52  sub rsp, 0x08
00007fa9d6dd3e56  push rax
00007fa9d6dd3e57  push rcx
00007fa9d6dd3e58  push rdx
00007fa9d6dd3e59  push rdi
00007fa9d6dd3e5a  push rsi
00007fa9d6dd3e5b  push r8
00007fa9d6dd3e5d  push r9
00007fa9d6dd3e5f  push r10
00007fa9d6dd3e61  push r11
00007fa9d6dd3e63  sub rsp, 0xF0
00007fa9d6dd3e6a  vmovaps [rsp], xmm0
00007fa9d6dd3e6f  vmovaps [rsp+0x10], xmm1
00007fa9d6dd3e75  vmovaps [rsp+0x20], xmm2
00007fa9d6dd3e7b  vmovaps [rsp+0x30], xmm3
00007fa9d6dd3e81  vmovaps [rsp+0x40], xmm4
00007fa9d6dd3e87  vmovaps [rsp+0x50], xmm5
00007fa9d6dd3e8d  vmovaps [rsp+0x60], xmm6
00007fa9d6dd3e93  vmovaps [rsp+0x70], xmm7
00007fa9d6dd3e99  vmovaps [rsp+0x80], xmm8
00007fa9d6dd3ea2  vmovaps [rsp+0x90], xmm9
00007fa9d6dd3eab  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd3eb4  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd3ebd  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd3ec6  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd3ecf  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd3ed8  sub rsp, 0x30
00007fa9d6dd3edc  movaps [rsp], xmm13
00007fa9d6dd3ee1  movaps [rsp+0x10], xmm8
00007fa9d6dd3ee7  movaps [rsp+0x20], xmm14
00007fa9d6dd3eed  lea rdi, [rsp]
00007fa9d6dd3ef1  mov esi, 0x00
00007fa9d6dd3ef6  mov rax, 0x61DF872DB530
00007fa9d6dd3f00  call rax
00007fa9d6dd3f02  movaps xmm13, [rsp]
00007fa9d6dd3f07  add rsp, 0x30
00007fa9d6dd3f0b  vmovaps xmm0, [rsp]
00007fa9d6dd3f10  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd3f16  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd3f1c  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd3f22  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd3f28  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd3f2e  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd3f34  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd3f3a  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd3f43  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd3f4c  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd3f55  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd3f5e  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd3f67  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd3f70  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd3f79  add rsp, 0xF0
00007fa9d6dd3f80  pop r11
00007fa9d6dd3f82  pop r10
00007fa9d6dd3f84  pop r9
00007fa9d6dd3f86  pop r8
00007fa9d6dd3f88  pop rsi
00007fa9d6dd3f89  pop rdi
00007fa9d6dd3f8a  pop rdx
00007fa9d6dd3f8b  pop rcx
00007fa9d6dd3f8c  pop rax
00007fa9d6dd3f8d  add rsp, 0x08
00007fa9d6dd3f91  jmp 0x00007FA9D6DD006E
00007fa9d6dd3f96  sub rsp, 0x08
00007fa9d6dd3f9a  push rax
00007fa9d6dd3f9b  push rcx
00007fa9d6dd3f9c  push rdx
00007fa9d6dd3f9d  push rdi
00007fa9d6dd3f9e  push rsi
00007fa9d6dd3f9f  push r8
00007fa9d6dd3fa1  push r9
00007fa9d6dd3fa3  push r10
00007fa9d6dd3fa5  push r11
00007fa9d6dd3fa7  sub rsp, 0xF0
00007fa9d6dd3fae  vmovaps [rsp], xmm0
00007fa9d6dd3fb3  vmovaps [rsp+0x10], xmm1
00007fa9d6dd3fb9  vmovaps [rsp+0x20], xmm2
00007fa9d6dd3fbf  vmovaps [rsp+0x30], xmm3
00007fa9d6dd3fc5  vmovaps [rsp+0x40], xmm4
00007fa9d6dd3fcb  vmovaps [rsp+0x50], xmm5
00007fa9d6dd3fd1  vmovaps [rsp+0x60], xmm6
00007fa9d6dd3fd7  vmovaps [rsp+0x70], xmm7
00007fa9d6dd3fdd  vmovaps [rsp+0x80], xmm9
00007fa9d6dd3fe6  vmovaps [rsp+0x90], xmm10
00007fa9d6dd3fef  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd3ff8  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd4001  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd400a  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd4013  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd401c  sub rsp, 0x30
00007fa9d6dd4020  movaps [rsp], xmm8
00007fa9d6dd4025  movaps [rsp+0x10], xmm7
00007fa9d6dd402a  movaps [rsp+0x20], xmm14
00007fa9d6dd4030  lea rdi, [rsp]
00007fa9d6dd4034  mov esi, 0x00
00007fa9d6dd4039  mov rax, 0x61DF872DB530
00007fa9d6dd4043  call rax
00007fa9d6dd4045  movaps xmm8, [rsp]
00007fa9d6dd404a  add rsp, 0x30
00007fa9d6dd404e  vmovaps xmm0, [rsp]
00007fa9d6dd4053  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4059  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd405f  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd4065  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd406b  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd4071  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd4077  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd407d  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd4086  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd408f  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd4098  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd40a1  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd40aa  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd40b3  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd40bc  add rsp, 0xF0
00007fa9d6dd40c3  pop r11
00007fa9d6dd40c5  pop r10
00007fa9d6dd40c7  pop r9
00007fa9d6dd40c9  pop r8
00007fa9d6dd40cb  pop rsi
00007fa9d6dd40cc  pop rdi
00007fa9d6dd40cd  pop rdx
00007fa9d6dd40ce  pop rcx
00007fa9d6dd40cf  pop rax
00007fa9d6dd40d0  add rsp, 0x08
00007fa9d6dd40d4  jmp 0x00007FA9D6DD0094
00007fa9d6dd40d9  sub rsp, 0x08
00007fa9d6dd40dd  push rax
00007fa9d6dd40de  push rcx
00007fa9d6dd40df  push rdx
00007fa9d6dd40e0  push rdi
00007fa9d6dd40e1  push rsi
00007fa9d6dd40e2  push r8
00007fa9d6dd40e4  push r9
00007fa9d6dd40e6  push r10
00007fa9d6dd40e8  push r11
00007fa9d6dd40ea  sub rsp, 0xF0
00007fa9d6dd40f1  vmovaps [rsp], xmm0
00007fa9d6dd40f6  vmovaps [rsp+0x10], xmm1
00007fa9d6dd40fc  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4102  vmovaps [rsp+0x30], xmm3
00007fa9d6dd4108  vmovaps [rsp+0x40], xmm4
00007fa9d6dd410e  vmovaps [rsp+0x50], xmm5
00007fa9d6dd4114  vmovaps [rsp+0x60], xmm6
00007fa9d6dd411a  vmovaps [rsp+0x70], xmm7
00007fa9d6dd4120  vmovaps [rsp+0x80], xmm8
00007fa9d6dd4129  vmovaps [rsp+0x90], xmm9
00007fa9d6dd4132  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd413b  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd4144  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd414d  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd4156  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd415f  sub rsp, 0x30
00007fa9d6dd4163  movaps [rsp], xmm14
00007fa9d6dd4168  movaps [rsp+0x10], xmm12
00007fa9d6dd416e  movaps [rsp+0x20], xmm9
00007fa9d6dd4174  lea rdi, [rsp]
00007fa9d6dd4178  mov esi, 0x00
00007fa9d6dd417d  mov rax, 0x61DF872DB530
00007fa9d6dd4187  call rax
00007fa9d6dd4189  movaps xmm14, [rsp]
00007fa9d6dd418e  add rsp, 0x30
00007fa9d6dd4192  vmovaps xmm0, [rsp]
00007fa9d6dd4197  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd419d  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd41a3  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd41a9  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd41af  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd41b5  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd41bb  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd41c1  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd41ca  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd41d3  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd41dc  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd41e5  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd41ee  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd41f7  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4200  add rsp, 0xF0
00007fa9d6dd4207  pop r11
00007fa9d6dd4209  pop r10
00007fa9d6dd420b  pop r9
00007fa9d6dd420d  pop r8
00007fa9d6dd420f  pop rsi
00007fa9d6dd4210  pop rdi
00007fa9d6dd4211  pop rdx
00007fa9d6dd4212  pop rcx
00007fa9d6dd4213  pop rax
00007fa9d6dd4214  add rsp, 0x08
00007fa9d6dd4218  jmp 0x00007FA9D6DD00AE
00007fa9d6dd421d  sub rsp, 0x08
00007fa9d6dd4221  push rax
00007fa9d6dd4222  push rcx
00007fa9d6dd4223  push rdx
00007fa9d6dd4224  push rdi
00007fa9d6dd4225  push rsi
00007fa9d6dd4226  push r8
00007fa9d6dd4228  push r9
00007fa9d6dd422a  push r10
00007fa9d6dd422c  push r11
00007fa9d6dd422e  sub rsp, 0xF0
00007fa9d6dd4235  vmovaps [rsp], xmm0
00007fa9d6dd423a  vmovaps [rsp+0x10], xmm1
00007fa9d6dd4240  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4246  vmovaps [rsp+0x30], xmm3
00007fa9d6dd424c  vmovaps [rsp+0x40], xmm4
00007fa9d6dd4252  vmovaps [rsp+0x50], xmm5
00007fa9d6dd4258  vmovaps [rsp+0x60], xmm6
00007fa9d6dd425e  vmovaps [rsp+0x70], xmm7
00007fa9d6dd4264  vmovaps [rsp+0x80], xmm8
00007fa9d6dd426d  vmovaps [rsp+0x90], xmm10
00007fa9d6dd4276  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd427f  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd4288  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd4291  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd429a  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd42a3  sub rsp, 0x30
00007fa9d6dd42a7  movaps [rsp], xmm9
00007fa9d6dd42ac  movaps [rsp+0x10], xmm7
00007fa9d6dd42b1  movaps [rsp+0x20], xmm12
00007fa9d6dd42b7  lea rdi, [rsp]
00007fa9d6dd42bb  mov esi, 0x00
00007fa9d6dd42c0  mov rax, 0x61DF872DB530
00007fa9d6dd42ca  call rax
00007fa9d6dd42cc  movaps xmm9, [rsp]
00007fa9d6dd42d1  add rsp, 0x30
00007fa9d6dd42d5  vmovaps xmm0, [rsp]
00007fa9d6dd42da  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd42e0  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd42e6  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd42ec  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd42f2  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd42f8  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd42fe  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd4304  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd430d  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd4316  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd431f  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd4328  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd4331  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd433a  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4343  add rsp, 0xF0
00007fa9d6dd434a  pop r11
00007fa9d6dd434c  pop r10
00007fa9d6dd434e  pop r9
00007fa9d6dd4350  pop r8
00007fa9d6dd4352  pop rsi
00007fa9d6dd4353  pop rdi
00007fa9d6dd4354  pop rdx
00007fa9d6dd4355  pop rcx
00007fa9d6dd4356  pop rax
00007fa9d6dd4357  add rsp, 0x08
00007fa9d6dd435b  jmp 0x00007FA9D6DD00DD
00007fa9d6dd4360  sub rsp, 0x08
00007fa9d6dd4364  push rax
00007fa9d6dd4365  push rcx
00007fa9d6dd4366  push rdx
00007fa9d6dd4367  push rdi
00007fa9d6dd4368  push rsi
00007fa9d6dd4369  push r8
00007fa9d6dd436b  push r9
00007fa9d6dd436d  push r10
00007fa9d6dd436f  push r11
00007fa9d6dd4371  sub rsp, 0xF0
00007fa9d6dd4378  vmovaps [rsp], xmm0
00007fa9d6dd437d  vmovaps [rsp+0x10], xmm1
00007fa9d6dd4383  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4389  vmovaps [rsp+0x30], xmm3
00007fa9d6dd438f  vmovaps [rsp+0x40], xmm4
00007fa9d6dd4395  vmovaps [rsp+0x50], xmm5
00007fa9d6dd439b  vmovaps [rsp+0x60], xmm6
00007fa9d6dd43a1  vmovaps [rsp+0x70], xmm7
00007fa9d6dd43a7  vmovaps [rsp+0x80], xmm8
00007fa9d6dd43b0  vmovaps [rsp+0x90], xmm9
00007fa9d6dd43b9  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd43c2  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd43cb  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd43d4  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd43dd  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd43e6  sub rsp, 0x30
00007fa9d6dd43ea  movaps [rsp], xmm12
00007fa9d6dd43ef  movaps [rsp+0x10], xmm15
00007fa9d6dd43f5  movaps [rsp+0x20], xmm11
00007fa9d6dd43fb  lea rdi, [rsp]
00007fa9d6dd43ff  mov esi, 0x00
00007fa9d6dd4404  mov rax, 0x61DF872DB530
00007fa9d6dd440e  call rax
00007fa9d6dd4410  movaps xmm12, [rsp]
00007fa9d6dd4415  add rsp, 0x30
00007fa9d6dd4419  vmovaps xmm0, [rsp]
00007fa9d6dd441e  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4424  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd442a  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd4430  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4436  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd443c  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd4442  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd4448  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd4451  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd445a  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd4463  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd446c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd4475  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd447e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4487  add rsp, 0xF0
00007fa9d6dd448e  pop r11
00007fa9d6dd4490  pop r10
00007fa9d6dd4492  pop r9
00007fa9d6dd4494  pop r8
00007fa9d6dd4496  pop rsi
00007fa9d6dd4497  pop rdi
00007fa9d6dd4498  pop rdx
00007fa9d6dd4499  pop rcx
00007fa9d6dd449a  pop rax
00007fa9d6dd449b  add rsp, 0x08
00007fa9d6dd449f  jmp 0x00007FA9D6DD00F7
00007fa9d6dd44a4  sub rsp, 0x08
00007fa9d6dd44a8  push rax
00007fa9d6dd44a9  push rcx
00007fa9d6dd44aa  push rdx
00007fa9d6dd44ab  push rdi
00007fa9d6dd44ac  push rsi
00007fa9d6dd44ad  push r8
00007fa9d6dd44af  push r9
00007fa9d6dd44b1  push r10
00007fa9d6dd44b3  push r11
00007fa9d6dd44b5  sub rsp, 0xF0
00007fa9d6dd44bc  vmovaps [rsp], xmm0
00007fa9d6dd44c1  vmovaps [rsp+0x10], xmm1
00007fa9d6dd44c7  vmovaps [rsp+0x20], xmm2
00007fa9d6dd44cd  vmovaps [rsp+0x30], xmm3
00007fa9d6dd44d3  vmovaps [rsp+0x40], xmm4
00007fa9d6dd44d9  vmovaps [rsp+0x50], xmm5
00007fa9d6dd44df  vmovaps [rsp+0x60], xmm6
00007fa9d6dd44e5  vmovaps [rsp+0x70], xmm7
00007fa9d6dd44eb  vmovaps [rsp+0x80], xmm8
00007fa9d6dd44f4  vmovaps [rsp+0x90], xmm9
00007fa9d6dd44fd  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd4506  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd450f  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd4518  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd4521  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd452a  sub rsp, 0x30
00007fa9d6dd452e  movaps [rsp], xmm11
00007fa9d6dd4533  movaps [rsp+0x10], xmm7
00007fa9d6dd4538  movaps [rsp+0x20], xmm15
00007fa9d6dd453e  lea rdi, [rsp]
00007fa9d6dd4542  mov esi, 0x00
00007fa9d6dd4547  mov rax, 0x61DF872DB530
00007fa9d6dd4551  call rax
00007fa9d6dd4553  movaps xmm11, [rsp]
00007fa9d6dd4558  add rsp, 0x30
00007fa9d6dd455c  vmovaps xmm0, [rsp]
00007fa9d6dd4561  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4567  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd456d  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd4573  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4579  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd457f  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd4585  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd458b  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd4594  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd459d  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd45a6  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd45af  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd45b8  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd45c1  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd45ca  add rsp, 0xF0
00007fa9d6dd45d1  pop r11
00007fa9d6dd45d3  pop r10
00007fa9d6dd45d5  pop r9
00007fa9d6dd45d7  pop r8
00007fa9d6dd45d9  pop rsi
00007fa9d6dd45da  pop rdi
00007fa9d6dd45db  pop rdx
00007fa9d6dd45dc  pop rcx
00007fa9d6dd45dd  pop rax
00007fa9d6dd45de  add rsp, 0x08
00007fa9d6dd45e2  jmp 0x00007FA9D6DD0123
00007fa9d6dd45e7  sub rsp, 0x08
00007fa9d6dd45eb  push rax
00007fa9d6dd45ec  push rcx
00007fa9d6dd45ed  push rdx
00007fa9d6dd45ee  push rdi
00007fa9d6dd45ef  push rsi
00007fa9d6dd45f0  push r8
00007fa9d6dd45f2  push r9
00007fa9d6dd45f4  push r10
00007fa9d6dd45f6  push r11
00007fa9d6dd45f8  sub rsp, 0xF0
00007fa9d6dd45ff  vmovaps [rsp], xmm0
00007fa9d6dd4604  vmovaps [rsp+0x10], xmm1
00007fa9d6dd460a  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4610  vmovaps [rsp+0x30], xmm3
00007fa9d6dd4616  vmovaps [rsp+0x40], xmm4
00007fa9d6dd461c  vmovaps [rsp+0x50], xmm5
00007fa9d6dd4622  vmovaps [rsp+0x60], xmm6
00007fa9d6dd4628  vmovaps [rsp+0x70], xmm7
00007fa9d6dd462e  vmovaps [rsp+0x80], xmm8
00007fa9d6dd4637  vmovaps [rsp+0x90], xmm9
00007fa9d6dd4640  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd4649  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd4652  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd465b  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd4664  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd466d  sub rsp, 0x30
00007fa9d6dd4671  movaps [rsp], xmm15
00007fa9d6dd4676  movaps [rsp+0x10], xmm10
00007fa9d6dd467c  movaps [rsp+0x20], xmm13
00007fa9d6dd4682  lea rdi, [rsp]
00007fa9d6dd4686  mov esi, 0x00
00007fa9d6dd468b  mov rax, 0x61DF872DB530
00007fa9d6dd4695  call rax
00007fa9d6dd4697  movaps xmm15, [rsp]
00007fa9d6dd469c  add rsp, 0x30
00007fa9d6dd46a0  vmovaps xmm0, [rsp]
00007fa9d6dd46a5  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd46ab  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd46b1  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd46b7  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd46bd  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd46c3  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd46c9  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd46cf  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd46d8  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd46e1  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd46ea  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd46f3  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd46fc  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd4705  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd470e  add rsp, 0xF0
00007fa9d6dd4715  pop r11
00007fa9d6dd4717  pop r10
00007fa9d6dd4719  pop r9
00007fa9d6dd471b  pop r8
00007fa9d6dd471d  pop rsi
00007fa9d6dd471e  pop rdi
00007fa9d6dd471f  pop rdx
00007fa9d6dd4720  pop rcx
00007fa9d6dd4721  pop rax
00007fa9d6dd4722  add rsp, 0x08
00007fa9d6dd4726  jmp 0x00007FA9D6DD013D
00007fa9d6dd472b  sub rsp, 0x08
00007fa9d6dd472f  push rax
00007fa9d6dd4730  push rcx
00007fa9d6dd4731  push rdx
00007fa9d6dd4732  push rdi
00007fa9d6dd4733  push rsi
00007fa9d6dd4734  push r8
00007fa9d6dd4736  push r9
00007fa9d6dd4738  push r10
00007fa9d6dd473a  push r11
00007fa9d6dd473c  sub rsp, 0xF0
00007fa9d6dd4743  vmovaps [rsp], xmm0
00007fa9d6dd4748  vmovaps [rsp+0x10], xmm1
00007fa9d6dd474e  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4754  vmovaps [rsp+0x30], xmm3
00007fa9d6dd475a  vmovaps [rsp+0x40], xmm4
00007fa9d6dd4760  vmovaps [rsp+0x50], xmm5
00007fa9d6dd4766  vmovaps [rsp+0x60], xmm6
00007fa9d6dd476c  vmovaps [rsp+0x70], xmm7
00007fa9d6dd4772  vmovaps [rsp+0x80], xmm8
00007fa9d6dd477b  vmovaps [rsp+0x90], xmm9
00007fa9d6dd4784  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd478d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd4796  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd479f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd47a8  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd47b1  sub rsp, 0x30
00007fa9d6dd47b5  movaps [rsp], xmm10
00007fa9d6dd47ba  movaps [rsp+0x10], xmm7
00007fa9d6dd47bf  movaps [rsp+0x20], xmm13
00007fa9d6dd47c5  lea rdi, [rsp]
00007fa9d6dd47c9  mov esi, 0x00
00007fa9d6dd47ce  mov rax, 0x61DF872DB530
00007fa9d6dd47d8  call rax
00007fa9d6dd47da  movaps xmm10, [rsp]
00007fa9d6dd47df  add rsp, 0x30
00007fa9d6dd47e3  vmovaps xmm0, [rsp]
00007fa9d6dd47e8  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd47ee  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd47f4  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd47fa  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4800  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd4806  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd480c  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd4812  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd481b  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd4824  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd482d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd4836  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd483f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd4848  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4851  add rsp, 0xF0
00007fa9d6dd4858  pop r11
00007fa9d6dd485a  pop r10
00007fa9d6dd485c  pop r9
00007fa9d6dd485e  pop r8
00007fa9d6dd4860  pop rsi
00007fa9d6dd4861  pop rdi
00007fa9d6dd4862  pop rdx
00007fa9d6dd4863  pop rcx
00007fa9d6dd4864  pop rax
00007fa9d6dd4865  add rsp, 0x08
00007fa9d6dd4869  jmp 0x00007FA9D6DD0169
00007fa9d6dd486e  sub rsp, 0x08
00007fa9d6dd4872  push rax
00007fa9d6dd4873  push rcx
00007fa9d6dd4874  push rdx
00007fa9d6dd4875  push rdi
00007fa9d6dd4876  push rsi
00007fa9d6dd4877  push r8
00007fa9d6dd4879  push r9
00007fa9d6dd487b  push r10
00007fa9d6dd487d  push r11
00007fa9d6dd487f  sub rsp, 0xF0
00007fa9d6dd4886  vmovaps [rsp], xmm0
00007fa9d6dd488b  vmovaps [rsp+0x10], xmm1
00007fa9d6dd4891  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4897  vmovaps [rsp+0x30], xmm3
00007fa9d6dd489d  vmovaps [rsp+0x40], xmm4
00007fa9d6dd48a3  vmovaps [rsp+0x50], xmm5
00007fa9d6dd48a9  vmovaps [rsp+0x60], xmm6
00007fa9d6dd48af  vmovaps [rsp+0x70], xmm7
00007fa9d6dd48b5  vmovaps [rsp+0x80], xmm8
00007fa9d6dd48be  vmovaps [rsp+0x90], xmm9
00007fa9d6dd48c7  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd48d0  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd48d9  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd48e2  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd48eb  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd48f4  sub rsp, 0x30
00007fa9d6dd48f8  movaps [rsp], xmm13
00007fa9d6dd48fd  movaps [rsp+0x10], xmm1
00007fa9d6dd4902  movaps [rsp+0x20], xmm8
00007fa9d6dd4908  lea rdi, [rsp]
00007fa9d6dd490c  mov esi, 0x00
00007fa9d6dd4911  mov rax, 0x61DF872DB530
00007fa9d6dd491b  call rax
00007fa9d6dd491d  movaps xmm13, [rsp]
00007fa9d6dd4922  add rsp, 0x30
00007fa9d6dd4926  vmovaps xmm0, [rsp]
00007fa9d6dd492b  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4931  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd4937  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd493d  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4943  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd4949  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd494f  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd4955  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd495e  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd4967  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd4970  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd4979  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd4982  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd498b  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4994  add rsp, 0xF0
00007fa9d6dd499b  pop r11
00007fa9d6dd499d  pop r10
00007fa9d6dd499f  pop r9
00007fa9d6dd49a1  pop r8
00007fa9d6dd49a3  pop rsi
00007fa9d6dd49a4  pop rdi
00007fa9d6dd49a5  pop rdx
00007fa9d6dd49a6  pop rcx
00007fa9d6dd49a7  pop rax
00007fa9d6dd49a8  add rsp, 0x08
00007fa9d6dd49ac  jmp 0x00007FA9D6DD0183
00007fa9d6dd49b1  call 0x00007FA9D6BFF430
00007fa9d6dd49b6  jmp 0x00007FA9D6DD018D
00007fa9d6dd49bb  sub rsp, 0x08
00007fa9d6dd49bf  push rax
00007fa9d6dd49c0  push rcx
00007fa9d6dd49c1  push rdx
00007fa9d6dd49c2  push rdi
00007fa9d6dd49c3  push rsi
00007fa9d6dd49c4  push r8
00007fa9d6dd49c6  push r9
00007fa9d6dd49c8  push r10
00007fa9d6dd49ca  push r11
00007fa9d6dd49cc  sub rsp, 0xF0
00007fa9d6dd49d3  vmovaps [rsp], xmm0
00007fa9d6dd49d8  vmovaps [rsp+0x10], xmm1
00007fa9d6dd49de  vmovaps [rsp+0x20], xmm2
00007fa9d6dd49e4  vmovaps [rsp+0x30], xmm3
00007fa9d6dd49ea  vmovaps [rsp+0x40], xmm4
00007fa9d6dd49f0  vmovaps [rsp+0x50], xmm5
00007fa9d6dd49f6  vmovaps [rsp+0x60], xmm6
00007fa9d6dd49fc  vmovaps [rsp+0x70], xmm7
00007fa9d6dd4a02  vmovaps [rsp+0x80], xmm9
00007fa9d6dd4a0b  vmovaps [rsp+0x90], xmm10
00007fa9d6dd4a14  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd4a1d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd4a26  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd4a2f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd4a38  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd4a41  sub rsp, 0x30
00007fa9d6dd4a45  movaps [rsp], xmm8
00007fa9d6dd4a4a  movaps [rsp+0x10], xmm14
00007fa9d6dd4a50  movaps [rsp+0x20], xmm9
00007fa9d6dd4a56  lea rdi, [rsp]
00007fa9d6dd4a5a  mov esi, 0x00
00007fa9d6dd4a5f  mov rax, 0x61DF872DB530
00007fa9d6dd4a69  call rax
00007fa9d6dd4a6b  movaps xmm8, [rsp]
00007fa9d6dd4a70  add rsp, 0x30
00007fa9d6dd4a74  vmovaps xmm0, [rsp]
00007fa9d6dd4a79  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4a7f  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd4a85  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd4a8b  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4a91  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd4a97  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd4a9d  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd4aa3  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd4aac  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd4ab5  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd4abe  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd4ac7  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd4ad0  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd4ad9  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4ae2  add rsp, 0xF0
00007fa9d6dd4ae9  pop r11
00007fa9d6dd4aeb  pop r10
00007fa9d6dd4aed  pop r9
00007fa9d6dd4aef  pop r8
00007fa9d6dd4af1  pop rsi
00007fa9d6dd4af2  pop rdi
00007fa9d6dd4af3  pop rdx
00007fa9d6dd4af4  pop rcx
00007fa9d6dd4af5  pop rax
00007fa9d6dd4af6  add rsp, 0x08
00007fa9d6dd4afa  jmp 0x00007FA9D6DD01AF
00007fa9d6dd4aff  sub rsp, 0x08
00007fa9d6dd4b03  push rax
00007fa9d6dd4b04  push rcx
00007fa9d6dd4b05  push rdx
00007fa9d6dd4b06  push rdi
00007fa9d6dd4b07  push rsi
00007fa9d6dd4b08  push r8
00007fa9d6dd4b0a  push r9
00007fa9d6dd4b0c  push r10
00007fa9d6dd4b0e  push r11
00007fa9d6dd4b10  sub rsp, 0xF0
00007fa9d6dd4b17  vmovaps [rsp], xmm0
00007fa9d6dd4b1c  vmovaps [rsp+0x10], xmm1
00007fa9d6dd4b22  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4b28  vmovaps [rsp+0x30], xmm3
00007fa9d6dd4b2e  vmovaps [rsp+0x40], xmm4
00007fa9d6dd4b34  vmovaps [rsp+0x50], xmm5
00007fa9d6dd4b3a  vmovaps [rsp+0x60], xmm6
00007fa9d6dd4b40  vmovaps [rsp+0x70], xmm7
00007fa9d6dd4b46  vmovaps [rsp+0x80], xmm8
00007fa9d6dd4b4f  vmovaps [rsp+0x90], xmm10
00007fa9d6dd4b58  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd4b61  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd4b6a  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd4b73  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd4b7c  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd4b85  sub rsp, 0x30
00007fa9d6dd4b89  movaps [rsp], xmm9
00007fa9d6dd4b8e  movaps [rsp+0x10], xmm1
00007fa9d6dd4b93  movaps [rsp+0x20], xmm14
00007fa9d6dd4b99  lea rdi, [rsp]
00007fa9d6dd4b9d  mov esi, 0x00
00007fa9d6dd4ba2  mov rax, 0x61DF872DB530
00007fa9d6dd4bac  call rax
00007fa9d6dd4bae  movaps xmm9, [rsp]
00007fa9d6dd4bb3  add rsp, 0x30
00007fa9d6dd4bb7  vmovaps xmm0, [rsp]
00007fa9d6dd4bbc  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4bc2  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd4bc8  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd4bce  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4bd4  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd4bda  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd4be0  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd4be6  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd4bef  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd4bf8  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd4c01  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd4c0a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd4c13  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd4c1c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4c25  add rsp, 0xF0
00007fa9d6dd4c2c  pop r11
00007fa9d6dd4c2e  pop r10
00007fa9d6dd4c30  pop r9
00007fa9d6dd4c32  pop r8
00007fa9d6dd4c34  pop rsi
00007fa9d6dd4c35  pop rdi
00007fa9d6dd4c36  pop rdx
00007fa9d6dd4c37  pop rcx
00007fa9d6dd4c38  pop rax
00007fa9d6dd4c39  add rsp, 0x08
00007fa9d6dd4c3d  jmp 0x00007FA9D6DD01DD
00007fa9d6dd4c42  sub rsp, 0x08
00007fa9d6dd4c46  push rax
00007fa9d6dd4c47  push rcx
00007fa9d6dd4c48  push rdx
00007fa9d6dd4c49  push rdi
00007fa9d6dd4c4a  push rsi
00007fa9d6dd4c4b  push r8
00007fa9d6dd4c4d  push r9
00007fa9d6dd4c4f  push r10
00007fa9d6dd4c51  push r11
00007fa9d6dd4c53  sub rsp, 0xF0
00007fa9d6dd4c5a  vmovaps [rsp], xmm0
00007fa9d6dd4c5f  vmovaps [rsp+0x10], xmm1
00007fa9d6dd4c65  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4c6b  vmovaps [rsp+0x30], xmm3
00007fa9d6dd4c71  vmovaps [rsp+0x40], xmm4
00007fa9d6dd4c77  vmovaps [rsp+0x50], xmm5
00007fa9d6dd4c7d  vmovaps [rsp+0x60], xmm6
00007fa9d6dd4c83  vmovaps [rsp+0x70], xmm7
00007fa9d6dd4c89  vmovaps [rsp+0x80], xmm8
00007fa9d6dd4c92  vmovaps [rsp+0x90], xmm9
00007fa9d6dd4c9b  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd4ca4  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd4cad  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd4cb6  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd4cbf  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd4cc8  sub rsp, 0x30
00007fa9d6dd4ccc  movaps [rsp], xmm14
00007fa9d6dd4cd1  movaps [rsp+0x10], xmm4
00007fa9d6dd4cd6  movaps [rsp+0x20], xmm1
00007fa9d6dd4cdb  lea rdi, [rsp]
00007fa9d6dd4cdf  mov esi, 0x00
00007fa9d6dd4ce4  mov rax, 0x61DF872DB530
00007fa9d6dd4cee  call rax
00007fa9d6dd4cf0  movaps xmm14, [rsp]
00007fa9d6dd4cf5  add rsp, 0x30
00007fa9d6dd4cf9  vmovaps xmm0, [rsp]
00007fa9d6dd4cfe  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4d04  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd4d0a  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd4d10  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4d16  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd4d1c  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd4d22  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd4d28  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd4d31  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd4d3a  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd4d43  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd4d4c  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd4d55  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd4d5e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4d67  add rsp, 0xF0
00007fa9d6dd4d6e  pop r11
00007fa9d6dd4d70  pop r10
00007fa9d6dd4d72  pop r9
00007fa9d6dd4d74  pop r8
00007fa9d6dd4d76  pop rsi
00007fa9d6dd4d77  pop rdi
00007fa9d6dd4d78  pop rdx
00007fa9d6dd4d79  pop rcx
00007fa9d6dd4d7a  pop rax
00007fa9d6dd4d7b  add rsp, 0x08
00007fa9d6dd4d7f  jmp 0x00007FA9D6DD0203
00007fa9d6dd4d84  sub rsp, 0x08
00007fa9d6dd4d88  push rax
00007fa9d6dd4d89  push rcx
00007fa9d6dd4d8a  push rdx
00007fa9d6dd4d8b  push rdi
00007fa9d6dd4d8c  push rsi
00007fa9d6dd4d8d  push r8
00007fa9d6dd4d8f  push r9
00007fa9d6dd4d91  push r10
00007fa9d6dd4d93  push r11
00007fa9d6dd4d95  sub rsp, 0xF0
00007fa9d6dd4d9c  vmovaps [rsp], xmm0
00007fa9d6dd4da1  vmovaps [rsp+0x10], xmm2
00007fa9d6dd4da7  vmovaps [rsp+0x20], xmm3
00007fa9d6dd4dad  vmovaps [rsp+0x30], xmm4
00007fa9d6dd4db3  vmovaps [rsp+0x40], xmm5
00007fa9d6dd4db9  vmovaps [rsp+0x50], xmm6
00007fa9d6dd4dbf  vmovaps [rsp+0x60], xmm7
00007fa9d6dd4dc5  vmovaps [rsp+0x70], xmm8
00007fa9d6dd4dcb  vmovaps [rsp+0x80], xmm9
00007fa9d6dd4dd4  vmovaps [rsp+0x90], xmm10
00007fa9d6dd4ddd  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd4de6  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd4def  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd4df8  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd4e01  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd4e0a  sub rsp, 0x30
00007fa9d6dd4e0e  movaps [rsp], xmm1
00007fa9d6dd4e12  movaps [rsp+0x10], xmm12
00007fa9d6dd4e18  movaps [rsp+0x20], xmm11
00007fa9d6dd4e1e  lea rdi, [rsp]
00007fa9d6dd4e22  mov esi, 0x00
00007fa9d6dd4e27  mov rax, 0x61DF872DB530
00007fa9d6dd4e31  call rax
00007fa9d6dd4e33  movaps xmm1, [rsp]
00007fa9d6dd4e37  add rsp, 0x30
00007fa9d6dd4e3b  vmovaps xmm0, [rsp]
00007fa9d6dd4e40  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd4e46  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd4e4c  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd4e52  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd4e58  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd4e5e  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd4e64  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd4e6a  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd4e73  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd4e7c  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd4e85  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd4e8e  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd4e97  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd4ea0  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4ea9  add rsp, 0xF0
00007fa9d6dd4eb0  pop r11
00007fa9d6dd4eb2  pop r10
00007fa9d6dd4eb4  pop r9
00007fa9d6dd4eb6  pop r8
00007fa9d6dd4eb8  pop rsi
00007fa9d6dd4eb9  pop rdi
00007fa9d6dd4eba  pop rdx
00007fa9d6dd4ebb  pop rcx
00007fa9d6dd4ebc  pop rax
00007fa9d6dd4ebd  add rsp, 0x08
00007fa9d6dd4ec1  jmp 0x00007FA9D6DD0224
00007fa9d6dd4ec6  call 0x00007FA9D6CE20A0
00007fa9d6dd4ecb  jmp 0x00007FA9D6DD0232
00007fa9d6dd4ed0  call 0x00007FA9D6C09D70
00007fa9d6dd4ed5  jmp 0x00007FA9D6DD023C
00007fa9d6dd4eda  sub rsp, 0x08
00007fa9d6dd4ede  push rax
00007fa9d6dd4edf  push rcx
00007fa9d6dd4ee0  push rdx
00007fa9d6dd4ee1  push rdi
00007fa9d6dd4ee2  push rsi
00007fa9d6dd4ee3  push r8
00007fa9d6dd4ee5  push r9
00007fa9d6dd4ee7  push r10
00007fa9d6dd4ee9  push r11
00007fa9d6dd4eeb  sub rsp, 0xF0
00007fa9d6dd4ef2  vmovaps [rsp], xmm0
00007fa9d6dd4ef7  vmovaps [rsp+0x10], xmm1
00007fa9d6dd4efd  vmovaps [rsp+0x20], xmm2
00007fa9d6dd4f03  vmovaps [rsp+0x30], xmm3
00007fa9d6dd4f09  vmovaps [rsp+0x40], xmm4
00007fa9d6dd4f0f  vmovaps [rsp+0x50], xmm5
00007fa9d6dd4f15  vmovaps [rsp+0x60], xmm6
00007fa9d6dd4f1b  vmovaps [rsp+0x70], xmm8
00007fa9d6dd4f21  vmovaps [rsp+0x80], xmm9
00007fa9d6dd4f2a  vmovaps [rsp+0x90], xmm10
00007fa9d6dd4f33  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd4f3c  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd4f45  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd4f4e  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd4f57  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd4f60  sub rsp, 0x30
00007fa9d6dd4f64  movaps [rsp], xmm7
00007fa9d6dd4f68  movaps [rsp+0x10], xmm15
00007fa9d6dd4f6e  movaps [rsp+0x20], xmm10
00007fa9d6dd4f74  lea rdi, [rsp]
00007fa9d6dd4f78  mov esi, 0x00
00007fa9d6dd4f7d  mov rax, 0x61DF872DB530
00007fa9d6dd4f87  call rax
00007fa9d6dd4f89  movaps xmm7, [rsp]
00007fa9d6dd4f8d  add rsp, 0x30
00007fa9d6dd4f91  vmovaps xmm0, [rsp]
00007fa9d6dd4f96  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd4f9c  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd4fa2  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd4fa8  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd4fae  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd4fb4  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd4fba  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd4fc0  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd4fc9  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd4fd2  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd4fdb  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd4fe4  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd4fed  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd4ff6  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd4fff  add rsp, 0xF0
00007fa9d6dd5006  pop r11
00007fa9d6dd5008  pop r10
00007fa9d6dd500a  pop r9
00007fa9d6dd500c  pop r8
00007fa9d6dd500e  pop rsi
00007fa9d6dd500f  pop rdi
00007fa9d6dd5010  pop rdx
00007fa9d6dd5011  pop rcx
00007fa9d6dd5012  pop rax
00007fa9d6dd5013  add rsp, 0x08
00007fa9d6dd5017  jmp 0x00007FA9D6DD025D
00007fa9d6dd501c  sub rsp, 0x08
00007fa9d6dd5020  push rax
00007fa9d6dd5021  push rcx
00007fa9d6dd5022  push rdx
00007fa9d6dd5023  push rdi
00007fa9d6dd5024  push rsi
00007fa9d6dd5025  push r8
00007fa9d6dd5027  push r9
00007fa9d6dd5029  push r10
00007fa9d6dd502b  push r11
00007fa9d6dd502d  sub rsp, 0xF0
00007fa9d6dd5034  vmovaps [rsp], xmm0
00007fa9d6dd5039  vmovaps [rsp+0x10], xmm1
00007fa9d6dd503f  vmovaps [rsp+0x20], xmm2
00007fa9d6dd5045  vmovaps [rsp+0x30], xmm3
00007fa9d6dd504b  vmovaps [rsp+0x40], xmm4
00007fa9d6dd5051  vmovaps [rsp+0x50], xmm5
00007fa9d6dd5057  vmovaps [rsp+0x60], xmm6
00007fa9d6dd505d  vmovaps [rsp+0x70], xmm7
00007fa9d6dd5063  vmovaps [rsp+0x80], xmm8
00007fa9d6dd506c  vmovaps [rsp+0x90], xmm9
00007fa9d6dd5075  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd507e  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd5087  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd5090  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd5099  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd50a2  sub rsp, 0x30
00007fa9d6dd50a6  movaps [rsp], xmm10
00007fa9d6dd50ab  movaps [rsp+0x10], xmm11
00007fa9d6dd50b1  movaps [rsp+0x20], xmm15
00007fa9d6dd50b7  lea rdi, [rsp]
00007fa9d6dd50bb  mov esi, 0x00
00007fa9d6dd50c0  mov rax, 0x61DF872DB530
00007fa9d6dd50ca  call rax
00007fa9d6dd50cc  movaps xmm10, [rsp]
00007fa9d6dd50d1  add rsp, 0x30
00007fa9d6dd50d5  vmovaps xmm0, [rsp]
00007fa9d6dd50da  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd50e0  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd50e6  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd50ec  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd50f2  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd50f8  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd50fe  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd5104  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd510d  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd5116  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd511f  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd5128  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd5131  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd513a  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd5143  add rsp, 0xF0
00007fa9d6dd514a  pop r11
00007fa9d6dd514c  pop r10
00007fa9d6dd514e  pop r9
00007fa9d6dd5150  pop r8
00007fa9d6dd5152  pop rsi
00007fa9d6dd5153  pop rdi
00007fa9d6dd5154  pop rdx
00007fa9d6dd5155  pop rcx
00007fa9d6dd5156  pop rax
00007fa9d6dd5157  add rsp, 0x08
00007fa9d6dd515b  jmp 0x00007FA9D6DD028B
00007fa9d6dd5160  sub rsp, 0x08
00007fa9d6dd5164  push rax
00007fa9d6dd5165  push rcx
00007fa9d6dd5166  push rdx
00007fa9d6dd5167  push rdi
00007fa9d6dd5168  push rsi
00007fa9d6dd5169  push r8
00007fa9d6dd516b  push r9
00007fa9d6dd516d  push r10
00007fa9d6dd516f  push r11
00007fa9d6dd5171  sub rsp, 0xF0
00007fa9d6dd5178  vmovaps [rsp], xmm0
00007fa9d6dd517d  vmovaps [rsp+0x10], xmm1
00007fa9d6dd5183  vmovaps [rsp+0x20], xmm2
00007fa9d6dd5189  vmovaps [rsp+0x30], xmm3
00007fa9d6dd518f  vmovaps [rsp+0x40], xmm4
00007fa9d6dd5195  vmovaps [rsp+0x50], xmm5
00007fa9d6dd519b  vmovaps [rsp+0x60], xmm6
00007fa9d6dd51a1  vmovaps [rsp+0x70], xmm7
00007fa9d6dd51a7  vmovaps [rsp+0x80], xmm8
00007fa9d6dd51b0  vmovaps [rsp+0x90], xmm9
00007fa9d6dd51b9  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd51c2  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd51cb  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd51d4  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd51dd  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd51e6  sub rsp, 0x30
00007fa9d6dd51ea  movaps [rsp], xmm11
00007fa9d6dd51ef  movaps [rsp+0x10], xmm12
00007fa9d6dd51f5  movaps [rsp+0x20], xmm15
00007fa9d6dd51fb  lea rdi, [rsp]
00007fa9d6dd51ff  mov esi, 0x00
00007fa9d6dd5204  mov rax, 0x61DF872DB530
00007fa9d6dd520e  call rax
00007fa9d6dd5210  movaps xmm11, [rsp]
00007fa9d6dd5215  add rsp, 0x30
00007fa9d6dd5219  vmovaps xmm0, [rsp]
00007fa9d6dd521e  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd5224  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd522a  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd5230  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd5236  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd523c  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd5242  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd5248  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd5251  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd525a  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd5263  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd526c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd5275  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd527e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd5287  add rsp, 0xF0
00007fa9d6dd528e  pop r11
00007fa9d6dd5290  pop r10
00007fa9d6dd5292  pop r9
00007fa9d6dd5294  pop r8
00007fa9d6dd5296  pop rsi
00007fa9d6dd5297  pop rdi
00007fa9d6dd5298  pop rdx
00007fa9d6dd5299  pop rcx
00007fa9d6dd529a  pop rax
00007fa9d6dd529b  add rsp, 0x08
00007fa9d6dd529f  jmp 0x00007FA9D6DD02B9
00007fa9d6dd52a4  sub rsp, 0x08
00007fa9d6dd52a8  push rax
00007fa9d6dd52a9  push rcx
00007fa9d6dd52aa  push rdx
00007fa9d6dd52ab  push rdi
00007fa9d6dd52ac  push rsi
00007fa9d6dd52ad  push r8
00007fa9d6dd52af  push r9
00007fa9d6dd52b1  push r10
00007fa9d6dd52b3  push r11
00007fa9d6dd52b5  sub rsp, 0xF0
00007fa9d6dd52bc  vmovaps [rsp], xmm0
00007fa9d6dd52c1  vmovaps [rsp+0x10], xmm1
00007fa9d6dd52c7  vmovaps [rsp+0x20], xmm2
00007fa9d6dd52cd  vmovaps [rsp+0x30], xmm3
00007fa9d6dd52d3  vmovaps [rsp+0x40], xmm4
00007fa9d6dd52d9  vmovaps [rsp+0x50], xmm5
00007fa9d6dd52df  vmovaps [rsp+0x60], xmm6
00007fa9d6dd52e5  vmovaps [rsp+0x70], xmm7
00007fa9d6dd52eb  vmovaps [rsp+0x80], xmm8
00007fa9d6dd52f4  vmovaps [rsp+0x90], xmm9
00007fa9d6dd52fd  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd5306  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd530f  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd5318  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd5321  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd532a  sub rsp, 0x30
00007fa9d6dd532e  movaps [rsp], xmm15
00007fa9d6dd5333  movaps [rsp+0x10], xmm13
00007fa9d6dd5339  movaps [rsp+0x20], xmm9
00007fa9d6dd533f  lea rdi, [rsp]
00007fa9d6dd5343  mov esi, 0x00
00007fa9d6dd5348  mov rax, 0x61DF872DB530
00007fa9d6dd5352  call rax
00007fa9d6dd5354  movaps xmm15, [rsp]
00007fa9d6dd5359  add rsp, 0x30
00007fa9d6dd535d  vmovaps xmm0, [rsp]
00007fa9d6dd5362  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd5368  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd536e  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd5374  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd537a  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd5380  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd5386  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd538c  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd5395  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd539e  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd53a7  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd53b0  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd53b9  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd53c2  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd53cb  add rsp, 0xF0
00007fa9d6dd53d2  pop r11
00007fa9d6dd53d4  pop r10
00007fa9d6dd53d6  pop r9
00007fa9d6dd53d8  pop r8
00007fa9d6dd53da  pop rsi
00007fa9d6dd53db  pop rdi
00007fa9d6dd53dc  pop rdx
00007fa9d6dd53dd  pop rcx
00007fa9d6dd53de  pop rax
00007fa9d6dd53df  add rsp, 0x08
00007fa9d6dd53e3  jmp 0x00007FA9D6DD02D4
00007fa9d6dd53e8  sub rsp, 0x08
00007fa9d6dd53ec  push rax
00007fa9d6dd53ed  push rcx
00007fa9d6dd53ee  push rdx
00007fa9d6dd53ef  push rdi
00007fa9d6dd53f0  push rsi
00007fa9d6dd53f1  push r8
00007fa9d6dd53f3  push r9
00007fa9d6dd53f5  push r10
00007fa9d6dd53f7  push r11
00007fa9d6dd53f9  sub rsp, 0xF0
00007fa9d6dd5400  vmovaps [rsp], xmm0
00007fa9d6dd5405  vmovaps [rsp+0x10], xmm1
00007fa9d6dd540b  vmovaps [rsp+0x20], xmm2
00007fa9d6dd5411  vmovaps [rsp+0x30], xmm3
00007fa9d6dd5417  vmovaps [rsp+0x40], xmm4
00007fa9d6dd541d  vmovaps [rsp+0x50], xmm5
00007fa9d6dd5423  vmovaps [rsp+0x60], xmm6
00007fa9d6dd5429  vmovaps [rsp+0x70], xmm7
00007fa9d6dd542f  vmovaps [rsp+0x80], xmm8
00007fa9d6dd5438  vmovaps [rsp+0x90], xmm9
00007fa9d6dd5441  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd544a  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd5453  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd545c  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd5465  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd546e  sub rsp, 0x30
00007fa9d6dd5472  movaps [rsp], xmm13
00007fa9d6dd5477  movaps [rsp+0x10], xmm8
00007fa9d6dd547d  movaps [rsp+0x20], xmm14
00007fa9d6dd5483  lea rdi, [rsp]
00007fa9d6dd5487  mov esi, 0x00
00007fa9d6dd548c  mov rax, 0x61DF872DB530
00007fa9d6dd5496  call rax
00007fa9d6dd5498  movaps xmm13, [rsp]
00007fa9d6dd549d  add rsp, 0x30
00007fa9d6dd54a1  vmovaps xmm0, [rsp]
00007fa9d6dd54a6  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd54ac  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd54b2  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd54b8  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd54be  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd54c4  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd54ca  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd54d0  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd54d9  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd54e2  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd54eb  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd54f4  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd54fd  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd5506  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd550f  add rsp, 0xF0
00007fa9d6dd5516  pop r11
00007fa9d6dd5518  pop r10
00007fa9d6dd551a  pop r9
00007fa9d6dd551c  pop r8
00007fa9d6dd551e  pop rsi
00007fa9d6dd551f  pop rdi
00007fa9d6dd5520  pop rdx
00007fa9d6dd5521  pop rcx
00007fa9d6dd5522  pop rax
00007fa9d6dd5523  add rsp, 0x08
00007fa9d6dd5527  jmp 0x00007FA9D6DD02F7
00007fa9d6dd552c  sub rsp, 0x08
00007fa9d6dd5530  push rax
00007fa9d6dd5531  push rcx
00007fa9d6dd5532  push rdx
00007fa9d6dd5533  push rdi
00007fa9d6dd5534  push rsi
00007fa9d6dd5535  push r8
00007fa9d6dd5537  push r9
00007fa9d6dd5539  push r10
00007fa9d6dd553b  push r11
00007fa9d6dd553d  sub rsp, 0xF0
00007fa9d6dd5544  vmovaps [rsp], xmm0
00007fa9d6dd5549  vmovaps [rsp+0x10], xmm1
00007fa9d6dd554f  vmovaps [rsp+0x20], xmm2
00007fa9d6dd5555  vmovaps [rsp+0x30], xmm3
00007fa9d6dd555b  vmovaps [rsp+0x40], xmm4
00007fa9d6dd5561  vmovaps [rsp+0x50], xmm5
00007fa9d6dd5567  vmovaps [rsp+0x60], xmm6
00007fa9d6dd556d  vmovaps [rsp+0x70], xmm7
00007fa9d6dd5573  vmovaps [rsp+0x80], xmm8
00007fa9d6dd557c  vmovaps [rsp+0x90], xmm9
00007fa9d6dd5585  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd558e  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd5597  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd55a0  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd55a9  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd55b2  sub rsp, 0x30
00007fa9d6dd55b6  movaps [rsp], xmm14
00007fa9d6dd55bb  movaps [rsp+0x10], xmm1
00007fa9d6dd55c0  movaps [rsp+0x20], xmm10
00007fa9d6dd55c6  lea rdi, [rsp]
00007fa9d6dd55ca  mov esi, 0x00
00007fa9d6dd55cf  mov rax, 0x61DF872DB530
00007fa9d6dd55d9  call rax
00007fa9d6dd55db  movaps xmm14, [rsp]
00007fa9d6dd55e0  add rsp, 0x30
00007fa9d6dd55e4  vmovaps xmm0, [rsp]
00007fa9d6dd55e9  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd55ef  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd55f5  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd55fb  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd5601  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd5607  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd560d  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd5613  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd561c  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd5625  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd562e  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd5637  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd5640  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd5649  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd5652  add rsp, 0xF0
00007fa9d6dd5659  pop r11
00007fa9d6dd565b  pop r10
00007fa9d6dd565d  pop r9
00007fa9d6dd565f  pop r8
00007fa9d6dd5661  pop rsi
00007fa9d6dd5662  pop rdi
00007fa9d6dd5663  pop rdx
00007fa9d6dd5664  pop rcx
00007fa9d6dd5665  pop rax
00007fa9d6dd5666  add rsp, 0x08
00007fa9d6dd566a  jmp 0x00007FA9D6DD031A
00007fa9d6dd566f  sub rsp, 0x08
00007fa9d6dd5673  push rax
00007fa9d6dd5674  push rcx
00007fa9d6dd5675  push rdx
00007fa9d6dd5676  push rdi
00007fa9d6dd5677  push rsi
00007fa9d6dd5678  push r8
00007fa9d6dd567a  push r9
00007fa9d6dd567c  push r10
00007fa9d6dd567e  push r11
00007fa9d6dd5680  sub rsp, 0xF0
00007fa9d6dd5687  vmovaps [rsp], xmm0
00007fa9d6dd568c  vmovaps [rsp+0x10], xmm2
00007fa9d6dd5692  vmovaps [rsp+0x20], xmm3
00007fa9d6dd5698  vmovaps [rsp+0x30], xmm4
00007fa9d6dd569e  vmovaps [rsp+0x40], xmm5
00007fa9d6dd56a4  vmovaps [rsp+0x50], xmm6
00007fa9d6dd56aa  vmovaps [rsp+0x60], xmm7
00007fa9d6dd56b0  vmovaps [rsp+0x70], xmm8
00007fa9d6dd56b6  vmovaps [rsp+0x80], xmm9
00007fa9d6dd56bf  vmovaps [rsp+0x90], xmm10
00007fa9d6dd56c8  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd56d1  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd56da  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd56e3  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd56ec  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd56f5  sub rsp, 0x30
00007fa9d6dd56f9  movaps [rsp], xmm1
00007fa9d6dd56fd  movaps [rsp+0x10], xmm7
00007fa9d6dd5702  movaps [rsp+0x20], xmm11
00007fa9d6dd5708  lea rdi, [rsp]
00007fa9d6dd570c  mov esi, 0x00
00007fa9d6dd5711  mov rax, 0x61DF872DB530
00007fa9d6dd571b  call rax
00007fa9d6dd571d  movaps xmm1, [rsp]
00007fa9d6dd5721  add rsp, 0x30
00007fa9d6dd5725  vmovaps xmm0, [rsp]
00007fa9d6dd572a  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd5730  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd5736  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd573c  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd5742  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd5748  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd574e  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd5754  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd575d  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd5766  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd576f  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd5778  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd5781  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd578a  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd5793  add rsp, 0xF0
00007fa9d6dd579a  pop r11
00007fa9d6dd579c  pop r10
00007fa9d6dd579e  pop r9
00007fa9d6dd57a0  pop r8
00007fa9d6dd57a2  pop rsi
00007fa9d6dd57a3  pop rdi
00007fa9d6dd57a4  pop rdx
00007fa9d6dd57a5  pop rcx
00007fa9d6dd57a6  pop rax
00007fa9d6dd57a7  add rsp, 0x08
00007fa9d6dd57ab  jmp 0x00007FA9D6DD033B
00007fa9d6dd57b0  call 0x00007FA9D6C0E880
00007fa9d6dd57b5  jmp 0x00007FA9D6DD034E
00007fa9d6dd57ba  call 0x00007FA9D6C0C380
00007fa9d6dd57bf  jmp 0x00007FA9D6DD0359
00007fa9d6dd57c4  call 0x00007FA9D6C0D600
00007fa9d6dd57c9  jmp 0x00007FA9D6DD0364
00007fa9d6dd57ce  call 0x00007FA9D6BFF540
00007fa9d6dd57d3  jmp 0x00007FA9D6DD036F
00007fa9d6dd57d8  int3
00007fa9d6dd57d9  nop [rax], eax
00007fa9d6dd57e0  mov rax, [r15+0x40]
00007fa9d6dd57e4  mov r14, [r15+0x58]
00007fa9d6dd57e8  lea r12, [rax+r14*1]
00007fa9d6dd57ec  movaps xmm1, [r15+0x1D0]
00007fa9d6dd57f4  vmovaps [rsp+0x10], xmm1
00007fa9d6dd57fa  vmovaps xmm15, [rsp+0x10]
00007fa9d6dd5800  por xmm1, xmm15
00007fa9d6dd5805  movaps xmm14, [r15+0x1A0]
00007fa9d6dd580d  vmovaps [rsp+0x10], xmm14
00007fa9d6dd5813  vmovaps xmm13, [rsp+0x10]
00007fa9d6dd5819  por xmm14, xmm13
00007fa9d6dd581e  lea rax, [r12+0x30]
00007fa9d6dd5823  mov r11, [r13+rax*1]
00007fa9d6dd5828  lea rax, [r12+0x38]
00007fa9d6dd582d  mov r10, [r13+rax*1]
00007fa9d6dd5832  movq xmm13, r11
00007fa9d6dd5837  movq xmm12, r10
00007fa9d6dd583c  movq xmm13, xmm13
00007fa9d6dd5841  vmovaps [rsp+0x10], xmm13
00007fa9d6dd5847  movq xmm13, xmm13
00007fa9d6dd584c  movaps [r15+0x130], xmm13
00007fa9d6dd5854  movq xmm12, xmm12
00007fa9d6dd5859  vmovaps [rsp+0x20], xmm12
00007fa9d6dd585f  movq xmm12, xmm12
00007fa9d6dd5864  movaps [r15+0x280], xmm12
00007fa9d6dd586c  movaps xmm13, [r15+0x270]
00007fa9d6dd5874  vmovaps [rsp+0x30], xmm13
00007fa9d6dd587a  vmovaps xmm12, [rsp+0x30]
00007fa9d6dd5880  por xmm13, xmm12
00007fa9d6dd5885  lea rax, [r12+0x20]
00007fa9d6dd588a  mov r11, [r13+rax*1]
00007fa9d6dd588f  lea rax, [r12+0x28]
00007fa9d6dd5894  mov r10, [r13+rax*1]
00007fa9d6dd5899  movq xmm12, r11
00007fa9d6dd589e  movq xmm11, r10
00007fa9d6dd58a3  movq xmm12, xmm12
00007fa9d6dd58a8  vmovaps [rsp+0x30], xmm12
00007fa9d6dd58ae  movq xmm12, xmm12
00007fa9d6dd58b3  movaps [r15+0x150], xmm12
00007fa9d6dd58bb  movq xmm11, xmm11
00007fa9d6dd58c0  vmovaps [rsp+0x40], xmm11
00007fa9d6dd58c6  movq xmm11, xmm11
00007fa9d6dd58cb  movaps [r15+0x140], xmm11
00007fa9d6dd58d3  lea rax, [r12+0x10]
00007fa9d6dd58d8  mov r11, [r13+rax*1]
00007fa9d6dd58dd  lea rax, [r12+0x18]
00007fa9d6dd58e2  mov r10, [r13+rax*1]
00007fa9d6dd58e7  movq xmm12, r11
00007fa9d6dd58ec  movq xmm11, r10
00007fa9d6dd58f1  movq xmm12, xmm12
00007fa9d6dd58f6  vmovaps [rsp+0x50], xmm12
00007fa9d6dd58fc  movq xmm12, xmm12
00007fa9d6dd5901  movaps [r15+0x170], xmm12
00007fa9d6dd5909  movq xmm11, xmm11
00007fa9d6dd590e  vmovaps [rsp+0x60], xmm11
00007fa9d6dd5914  movq xmm11, xmm11
00007fa9d6dd5919  movaps [r15+0x160], xmm11
00007fa9d6dd5921  mov rax, [r13+r12*1]
00007fa9d6dd5926  vmovq xmm12, rax
00007fa9d6dd592b  vpbroadcastq xmm12, xmm12
00007fa9d6dd5930  lea rax, [r12+0x08]
00007fa9d6dd5935  mov r12, [r13+rax*1]
00007fa9d6dd593a  movq xmm11, r12
00007fa9d6dd593f  movaps [r15+0x230], xmm11
00007fa9d6dd5947  mov rax, [r15+0xF8]
00007fa9d6dd594e  lea r12, [rax+0x50]
00007fa9d6dd5952  movups xmm11, [r13+r12*1]
00007fa9d6dd5958  lea r12, [rax+0x60]
00007fa9d6dd595c  movups xmm10, [r13+r12*1]
00007fa9d6dd5962  lea r12, [rax+0x30]
00007fa9d6dd5966  movups xmm9, [r13+r12*1]
00007fa9d6dd596c  mov r12, [r15+0x50]
00007fa9d6dd5970  lea r11, [r12+r14*1]
00007fa9d6dd5974  mov [r15+0x60], r11
00007fa9d6dd5978  lea r12, [r14+0x40]
00007fa9d6dd597c  mov [r15+0x58], r12
00007fa9d6dd5980  movaps xmm8, xmm12
00007fa9d6dd5984  mulpd xmm8, xmm15
00007fa9d6dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa9d6dd598f  ptest xmm7, xmm7
00007fa9d6dd5994  jnz 0x00007FA9D6DD67B7
00007fa9d6dd599a  movq xmm15, qword ptr [r15+0x230]
00007fa9d6dd59a3  vmovaps [rsp+0x70], xmm15
00007fa9d6dd59a9  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dd59af  movaps xmm7, xmm9
00007fa9d6dd59b3  mulpd xmm7, xmm15
00007fa9d6dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa9d6dd59bd  ptest xmm6, xmm6
00007fa9d6dd59c2  jnz 0x00007FA9D6DD68FB
00007fa9d6dd59c8  vxorps xmm15, xmm15, xmm15
00007fa9d6dd59cd  vpbroadcastq xmm15, xmm15
00007fa9d6dd59d2  movaps xmm9, xmm12
00007fa9d6dd59d6  mulpd xmm9, xmm10
00007fa9d6dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa9d6dd59e1  ptest xmm6, xmm6
00007fa9d6dd59e6  jnz 0x00007FA9D6DD6A3D
00007fa9d6dd59ec  movaps xmm10, xmm12
00007fa9d6dd59f0  mulpd xmm10, xmm11
00007fa9d6dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa9d6dd59fb  ptest xmm6, xmm6
00007fa9d6dd5a00  jnz 0x00007FA9D6DD6B81
00007fa9d6dd5a06  movaps xmm11, [r15+0x1F0]
00007fa9d6dd5a0e  movaps xmm6, xmm12
00007fa9d6dd5a12  mulpd xmm6, xmm11
00007fa9d6dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa9d6dd5a1c  ptest xmm5, xmm5
00007fa9d6dd5a21  jnz 0x00007FA9D6DD6CC5
00007fa9d6dd5a27  movaps xmm12, [r15+0x2A0]
00007fa9d6dd5a2f  vmovaps [rsp+0x80], xmm12
00007fa9d6dd5a38  vmovaps xmm11, [rsp+0x80]
00007fa9d6dd5a41  por xmm12, xmm11
00007fa9d6dd5a46  movaps xmm11, [r15+0x250]
00007fa9d6dd5a4e  vmovaps [rsp+0x80], xmm11
00007fa9d6dd5a57  vmovaps xmm5, [rsp+0x80]
00007fa9d6dd5a60  por xmm11, xmm5
00007fa9d6dd5a65  vmovaps xmm4, [rsp+0x70]
00007fa9d6dd5a6b  vpermilpd xmm4, xmm4, 0x00
00007fa9d6dd5a71  movaps xmm3, xmm5
00007fa9d6dd5a74  mulpd xmm3, xmm4
00007fa9d6dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007fa9d6dd5a7d  ptest xmm2, xmm2
00007fa9d6dd5a82  jnz 0x00007FA9D6DD6E07
00007fa9d6dd5a88  mov [rsp+0x80], rax
00007fa9d6dd5a90  xor eax, eax
00007fa9d6dd5a92  mov r14d, 0x200
00007fa9d6dd5a98  cmp r12, r14
00007fa9d6dd5a9b  cmc
00007fa9d6dd5a9c  lahf
00007fa9d6dd5a9d  seto al
00007fa9d6dd5aa0  mov [r15+0x108], eax
00007fa9d6dd5aa7  movaps xmm5, xmm8
00007fa9d6dd5aab  addpd xmm5, xmm15
00007fa9d6dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007fa9d6dd5ab5  ptest xmm4, xmm4
00007fa9d6dd5aba  jnz 0x00007FA9D6DD6F47
00007fa9d6dd5ac0  movaps xmm8, [r15+0x1B0]
00007fa9d6dd5ac8  movaps xmm4, xmm9
00007fa9d6dd5acc  addpd xmm4, xmm8
00007fa9d6dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007fa9d6dd5ad6  ptest xmm2, xmm2
00007fa9d6dd5adb  jnz 0x00007FA9D6DD7089
00007fa9d6dd5ae1  movaps xmm9, xmm10
00007fa9d6dd5ae5  addpd xmm9, xmm8
00007fa9d6dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007fa9d6dd5af0  ptest xmm2, xmm2
00007fa9d6dd5af5  jnz 0x00007FA9D6DD71CB
00007fa9d6dd5afb  movaps xmm10, [r15+0x2F0]
00007fa9d6dd5b03  vmovaps [rsp+0x90], xmm10
00007fa9d6dd5b0c  vmovaps xmm8, [rsp+0x90]
00007fa9d6dd5b15  por xmm10, xmm8
00007fa9d6dd5b1a  movaps xmm8, [r15+0x2E0]
00007fa9d6dd5b22  vmovaps [rsp+0x90], xmm8
00007fa9d6dd5b2b  vmovaps xmm2, [rsp+0x90]
00007fa9d6dd5b34  por xmm8, xmm2
00007fa9d6dd5b39  movaps xmm2, [r15+0x2D0]
00007fa9d6dd5b41  vmovaps [rsp+0x90], xmm2
00007fa9d6dd5b4a  vmovaps [rsp+0xA0], xmm1
00007fa9d6dd5b53  vmovaps xmm1, [rsp+0x90]
00007fa9d6dd5b5c  por xmm2, xmm1
00007fa9d6dd5b60  movaps xmm1, [r15+0x200]
00007fa9d6dd5b68  vmovaps [rsp+0x90], xmm1
00007fa9d6dd5b71  vmovaps [rsp+0xB0], xmm15
00007fa9d6dd5b7a  vmovaps xmm15, [rsp+0x90]
00007fa9d6dd5b83  por xmm1, xmm15
00007fa9d6dd5b88  movaps xmm15, [r15+0x1C0]
00007fa9d6dd5b90  vmovaps [rsp+0x90], xmm15
00007fa9d6dd5b99  vmovaps [rsp+0xC0], xmm1
00007fa9d6dd5ba2  vmovaps xmm1, [rsp+0x90]
00007fa9d6dd5bab  por xmm15, xmm1
00007fa9d6dd5bb0  movaps xmm1, [r15+0x190]
00007fa9d6dd5bb8  vmovaps [rsp+0x90], xmm1
00007fa9d6dd5bc1  vmovaps [rsp+0xD0], xmm15
00007fa9d6dd5bca  vmovaps xmm15, [rsp+0x90]
00007fa9d6dd5bd3  por xmm1, xmm15
00007fa9d6dd5bd8  movaps xmm15, [r15+0x300]
00007fa9d6dd5be0  vmovaps [rsp+0x90], xmm15
00007fa9d6dd5be9  vmovaps [rsp+0xE0], xmm1
00007fa9d6dd5bf2  vmovaps xmm1, [rsp+0x90]
00007fa9d6dd5bfb  por xmm15, xmm1
00007fa9d6dd5c00  mov rax, [rsp+0x80]
00007fa9d6dd5c08  lea r14, [rax+0xA0]
00007fa9d6dd5c0f  movups xmm1, [r13+r14*1]
00007fa9d6dd5c15  lea r14, [rax+0xB0]
00007fa9d6dd5c1c  vmovaps [rsp+0x80], xmm1
00007fa9d6dd5c25  movups xmm1, [r13+r14*1]
00007fa9d6dd5c2b  vmovaps [rsp+0x90], xmm1
00007fa9d6dd5c34  vmovaps [rsp+0xF0], xmm15
00007fa9d6dd5c3d  vmovaps xmm15, [rsp+0xB0]
00007fa9d6dd5c46  vmovaps [rsp+0xB0], xmm14
00007fa9d6dd5c4f  movaps xmm1, xmm6
00007fa9d6dd5c52  addpd xmm1, xmm15
00007fa9d6dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa9d6dd5c5c  ptest xmm14, xmm14
00007fa9d6dd5c62  jnz 0x00007FA9D6DD7323
00007fa9d6dd5c68  lea r14, [rax+0xF0]
00007fa9d6dd5c6f  movups xmm15, [r13+r14*1]
00007fa9d6dd5c75  movaps xmm14, xmm4
00007fa9d6dd5c79  addpd xmm14, xmm3
00007fa9d6dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa9d6dd5c84  ptest xmm6, xmm6
00007fa9d6dd5c89  jnz 0x00007FA9D6DD746E
00007fa9d6dd5c8f  movaps xmm6, xmm9
00007fa9d6dd5c93  addpd xmm6, xmm7
00007fa9d6dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007fa9d6dd5c9c  ptest xmm4, xmm4
00007fa9d6dd5ca1  jnz 0x00007FA9D6DD75B0
00007fa9d6dd5ca7  vmovaps xmm9, [rsp+0x70]
00007fa9d6dd5cad  vpermilpd xmm9, xmm9, 0x00
00007fa9d6dd5cb3  vmovaps xmm4, [rsp+0x90]
00007fa9d6dd5cbc  movaps xmm7, xmm4
00007fa9d6dd5cbf  mulpd xmm7, xmm9
00007fa9d6dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007fa9d6dd5cc9  ptest xmm3, xmm3
00007fa9d6dd5cce  jnz 0x00007FA9D6DD76F1
00007fa9d6dd5cd4  vmovaps xmm9, [rsp+0x50]
00007fa9d6dd5cda  vpermilpd xmm9, xmm9, 0x00
00007fa9d6dd5ce0  movaps xmm4, xmm15
00007fa9d6dd5ce4  mulpd xmm4, xmm9
00007fa9d6dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa9d6dd5cee  ptest xmm3, xmm3
00007fa9d6dd5cf3  jnz 0x00007FA9D6DD7832
00007fa9d6dd5cf9  lea r14, [rax+0xE0]
00007fa9d6dd5d00  movups xmm15, [r13+r14*1]
00007fa9d6dd5d06  vmovaps xmm9, [rsp+0x70]
00007fa9d6dd5d0c  vpermilpd xmm9, xmm9, 0x00
00007fa9d6dd5d12  vmovaps [rsp+0x70], xmm1
00007fa9d6dd5d18  vmovaps xmm1, [rsp+0x80]
00007fa9d6dd5d21  vmovaps [rsp+0x80], xmm15
00007fa9d6dd5d2a  movaps xmm3, xmm1
00007fa9d6dd5d2d  mulpd xmm3, xmm9
00007fa9d6dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007fa9d6dd5d37  ptest xmm15, xmm15
00007fa9d6dd5d3d  jnz 0x00007FA9D6DD797E
00007fa9d6dd5d43  vmovaps xmm1, [rsp+0xF0]
00007fa9d6dd5d4c  vmovaps xmm15, [rsp+0xF0]
00007fa9d6dd5d55  por xmm1, xmm15
00007fa9d6dd5d5a  movaps [r15+0x300], xmm1
00007fa9d6dd5d62  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd5d6b  vmovaps xmm9, [rsp+0xE0]
00007fa9d6dd5d74  por xmm15, xmm9
00007fa9d6dd5d79  movaps [r15+0x190], xmm15
00007fa9d6dd5d81  vmovaps xmm9, [rsp+0x50]
00007fa9d6dd5d87  vpermilpd xmm9, xmm9, 0x00
00007fa9d6dd5d8d  vmovaps [rsp+0x90], xmm1
00007fa9d6dd5d96  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd5d9f  vmovaps xmm15, [rsp+0x80]
00007fa9d6dd5da8  vmovaps [rsp+0x80], xmm14
00007fa9d6dd5db1  movaps xmm1, xmm15
00007fa9d6dd5db5  mulpd xmm1, xmm9
00007fa9d6dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa9d6dd5dbf  ptest xmm14, xmm14
00007fa9d6dd5dc5  jnz 0x00007FA9D6DD7ABF
00007fa9d6dd5dcb  lea r14, [rax+0x90]
00007fa9d6dd5dd2  movups xmm15, [r13+r14*1]
00007fa9d6dd5dd8  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd5de1  vmovaps xmm9, [rsp+0xD0]
00007fa9d6dd5dea  por xmm14, xmm9
00007fa9d6dd5def  movaps [r15+0x1C0], xmm14
00007fa9d6dd5df7  vmovaps xmm9, [rsp+0xC0]
00007fa9d6dd5e00  vmovaps [rsp+0xD0], xmm1
00007fa9d6dd5e09  vmovaps xmm1, [rsp+0xC0]
00007fa9d6dd5e12  por xmm9, xmm1
00007fa9d6dd5e17  movaps [r15+0x200], xmm9
00007fa9d6dd5e1f  vmovaps [rsp+0xC0], xmm2
00007fa9d6dd5e28  vmovaps xmm1, [rsp+0xC0]
00007fa9d6dd5e31  por xmm2, xmm1
00007fa9d6dd5e35  movaps [r15+0x2D0], xmm2
00007fa9d6dd5e3d  vmovaps [rsp+0xC0], xmm8
00007fa9d6dd5e46  vmovaps xmm1, [rsp+0xC0]
00007fa9d6dd5e4f  por xmm8, xmm1
00007fa9d6dd5e54  movaps [r15+0x2E0], xmm8
00007fa9d6dd5e5c  vmovaps [rsp+0xC0], xmm15
00007fa9d6dd5e65  movaps xmm1, xmm5
00007fa9d6dd5e68  addpd xmm1, xmm7
00007fa9d6dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa9d6dd5e71  ptest xmm15, xmm15
00007fa9d6dd5e77  jnz 0x00007FA9D6DD7C0B
00007fa9d6dd5e7d  vmovaps xmm15, [rsp+0x50]
00007fa9d6dd5e83  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dd5e89  vmovaps xmm5, [rsp+0xC0]
00007fa9d6dd5e92  vmovaps [rsp+0xC0], xmm1
00007fa9d6dd5e9b  movaps xmm7, xmm5
00007fa9d6dd5e9e  mulpd xmm7, xmm15
00007fa9d6dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007fa9d6dd5ea8  ptest xmm1, xmm1
00007fa9d6dd5ead  jnz 0x00007FA9D6DD7D4B
00007fa9d6dd5eb3  lea r14, [rax+0x80]
00007fa9d6dd5eba  movups xmm1, [r13+r14*1]
00007fa9d6dd5ec0  vmovaps xmm5, [rsp+0x70]
00007fa9d6dd5ec6  vmovaps [rsp+0x70], xmm1
00007fa9d6dd5ecc  movaps xmm15, xmm5
00007fa9d6dd5ed0  addpd xmm15, xmm3
00007fa9d6dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6dd5edb  ptest xmm1, xmm1
00007fa9d6dd5ee0  jnz 0x00007FA9D6DD7E96
00007fa9d6dd5ee6  vmovaps xmm5, [rsp+0x80]
00007fa9d6dd5eef  movaps xmm1, xmm5
00007fa9d6dd5ef2  addpd xmm1, xmm4
00007fa9d6dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007fa9d6dd5efb  ptest xmm3, xmm3
00007fa9d6dd5f00  jnz 0x00007FA9D6DD7FD8
00007fa9d6dd5f06  vmovaps [rsp+0x80], xmm10
00007fa9d6dd5f0f  vmovaps xmm5, [rsp+0x80]
00007fa9d6dd5f18  por xmm10, xmm5
00007fa9d6dd5f1d  movaps [r15+0x2F0], xmm10
00007fa9d6dd5f25  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd5f2b  vpermilpd xmm5, xmm5, 0x00
00007fa9d6dd5f31  vmovaps xmm3, [rsp+0x70]
00007fa9d6dd5f37  vmovaps [rsp+0x50], xmm1
00007fa9d6dd5f3d  movaps xmm4, xmm3
00007fa9d6dd5f40  mulpd xmm4, xmm5
00007fa9d6dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa9d6dd5f49  ptest xmm1, xmm1
00007fa9d6dd5f4e  jnz 0x00007FA9D6DD8118
00007fa9d6dd5f54  lea r14, [rax+0xD0]
00007fa9d6dd5f5b  movups xmm1, [r13+r14*1]
00007fa9d6dd5f61  vmovaps xmm3, [rsp+0xD0]
00007fa9d6dd5f6a  vmovaps [rsp+0x70], xmm1
00007fa9d6dd5f70  movaps xmm5, xmm6
00007fa9d6dd5f73  addpd xmm5, xmm3
00007fa9d6dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007fa9d6dd5f7c  ptest xmm1, xmm1
00007fa9d6dd5f81  jnz 0x00007FA9D6DD8262
00007fa9d6dd5f87  vmovaps xmm1, [rsp+0x60]
00007fa9d6dd5f8d  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd5f93  movaps xmm6, xmm9
00007fa9d6dd5f97  mulpd xmm6, xmm1
00007fa9d6dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa9d6dd5fa0  ptest xmm3, xmm3
00007fa9d6dd5fa5  jnz 0x00007FA9D6DD83A2
00007fa9d6dd5fab  movaps [r15+0x260], xmm6
00007fa9d6dd5fb3  vxorps xmm1, xmm1, xmm1
00007fa9d6dd5fb7  vpbroadcastq xmm1, xmm1
00007fa9d6dd5fbc  movaps [r15+0x1B0], xmm1
00007fa9d6dd5fc4  vmovaps xmm1, [rsp+0x60]
00007fa9d6dd5fca  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd5fd0  vmovaps xmm3, [rsp+0x70]
00007fa9d6dd5fd6  vmovaps [rsp+0x70], xmm15
00007fa9d6dd5fdc  movaps xmm9, xmm3
00007fa9d6dd5fe0  mulpd xmm9, xmm1
00007fa9d6dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa9d6dd5feb  ptest xmm15, xmm15
00007fa9d6dd5ff1  jnz 0x00007FA9D6DD84E3
00007fa9d6dd5ff7  lea r14, [rax+0xC0]
00007fa9d6dd5ffe  movups xmm1, [r13+r14*1]
00007fa9d6dd6004  vmovaps xmm3, [rsp+0xC0]
00007fa9d6dd600d  vmovaps [rsp+0x80], xmm1
00007fa9d6dd6016  movaps xmm15, xmm3
00007fa9d6dd601a  addpd xmm15, xmm7
00007fa9d6dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6dd6025  ptest xmm1, xmm1
00007fa9d6dd602a  jnz 0x00007FA9D6DD862F
00007fa9d6dd6030  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd6039  vmovaps xmm1, [rsp+0xC0]
00007fa9d6dd6042  por xmm13, xmm1
00007fa9d6dd6047  movaps [r15+0x270], xmm13
00007fa9d6dd604f  vmovaps xmm1, [rsp+0xB0]
00007fa9d6dd6058  vmovaps xmm7, [rsp+0xB0]
00007fa9d6dd6061  por xmm1, xmm7
00007fa9d6dd6065  movaps [r15+0x1A0], xmm1
00007fa9d6dd606d  vmovaps xmm1, [rsp+0x60]
00007fa9d6dd6073  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd6079  vmovaps [rsp+0xB0], xmm1
00007fa9d6dd6082  vmovaps xmm1, [rsp+0x80]
00007fa9d6dd608b  vmovaps [rsp+0x80], xmm15
00007fa9d6dd6094  vmovaps xmm15, [rsp+0xB0]
00007fa9d6dd609d  vmovaps [rsp+0xB0], xmm14
00007fa9d6dd60a6  movaps xmm3, xmm1
00007fa9d6dd60a9  mulpd xmm3, xmm15
00007fa9d6dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007fa9d6dd60b3  ptest xmm14, xmm14
00007fa9d6dd60b9  jnz 0x00007FA9D6DD8771
00007fa9d6dd60bf  lea r14, [rax+0x20]
00007fa9d6dd60c3  movups xmm1, [r13+r14*1]
00007fa9d6dd60c9  movaps [r15+0x110], xmm1
00007fa9d6dd60d1  vmovaps xmm14, [rsp+0x70]
00007fa9d6dd60d7  vmovaps [rsp+0x70], xmm1
00007fa9d6dd60dd  movaps xmm15, xmm14
00007fa9d6dd60e1  addpd xmm15, xmm4
00007fa9d6dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6dd60ec  ptest xmm1, xmm1
00007fa9d6dd60f1  jnz 0x00007FA9D6DD88BC
00007fa9d6dd60f7  vmovaps xmm1, [rsp+0x60]
00007fa9d6dd60fd  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd6103  movaps xmm14, xmm2
00007fa9d6dd6107  mulpd xmm14, xmm1
00007fa9d6dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007fa9d6dd6112  ptest xmm4, xmm4
00007fa9d6dd6117  jnz 0x00007FA9D6DD89FF
00007fa9d6dd611d  vmovaps xmm4, [rsp+0x50]
00007fa9d6dd6123  movaps xmm1, xmm4
00007fa9d6dd6126  addpd xmm1, xmm9
00007fa9d6dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa9d6dd6130  ptest xmm2, xmm2
00007fa9d6dd6135  jnz 0x00007FA9D6DD8B41
00007fa9d6dd613b  vmovaps xmm9, [rsp+0x30]
00007fa9d6dd6141  vpermilpd xmm9, xmm9, 0x00
00007fa9d6dd6147  vmovaps xmm2, [rsp+0x70]
00007fa9d6dd614d  vmovaps [rsp+0x50], xmm1
00007fa9d6dd6153  movaps xmm4, xmm2
00007fa9d6dd6156  mulpd xmm4, xmm9
00007fa9d6dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa9d6dd6160  ptest xmm1, xmm1
00007fa9d6dd6165  jnz 0x00007FA9D6DD8C82
00007fa9d6dd616b  vmovaps xmm1, [rsp+0x30]
00007fa9d6dd6171  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd6177  vmovaps xmm2, [rsp+0x90]
00007fa9d6dd6180  vmovaps [rsp+0x60], xmm15
00007fa9d6dd6186  movaps xmm9, xmm2
00007fa9d6dd618a  mulpd xmm9, xmm1
00007fa9d6dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa9d6dd6195  ptest xmm15, xmm15
00007fa9d6dd619b  jnz 0x00007FA9D6DD8DC3
00007fa9d6dd61a1  vmovaps xmm15, [rsp+0x80]
00007fa9d6dd61aa  movaps xmm1, xmm15
00007fa9d6dd61ae  addpd xmm1, xmm6
00007fa9d6dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa9d6dd61b7  ptest xmm2, xmm2
00007fa9d6dd61bc  jnz 0x00007FA9D6DD8F05
00007fa9d6dd61c2  movaps xmm15, xmm5
00007fa9d6dd61c6  addpd xmm15, xmm3
00007fa9d6dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007fa9d6dd61d1  ptest xmm6, xmm6
00007fa9d6dd61d6  jnz 0x00007FA9D6DD9046
00007fa9d6dd61dc  vmovaps xmm6, [rsp+0x30]
00007fa9d6dd61e2  vpermilpd xmm6, xmm6, 0x00
00007fa9d6dd61e8  movaps xmm5, xmm8
00007fa9d6dd61ec  mulpd xmm5, xmm6
00007fa9d6dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007fa9d6dd61f5  ptest xmm3, xmm3
00007fa9d6dd61fa  jnz 0x00007FA9D6DD9188
00007fa9d6dd6200  vmovaps xmm8, [rsp+0x30]
00007fa9d6dd6206  vpermilpd xmm8, xmm8, 0x00
00007fa9d6dd620c  movaps xmm6, xmm10
00007fa9d6dd6210  mulpd xmm6, xmm8
00007fa9d6dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa9d6dd621a  ptest xmm3, xmm3
00007fa9d6dd621f  jnz 0x00007FA9D6DD92C9
00007fa9d6dd6225  vmovaps xmm8, [rsp+0x60]
00007fa9d6dd622b  movaps xmm10, xmm8
00007fa9d6dd622f  addpd xmm10, xmm14
00007fa9d6dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007fa9d6dd623a  ptest xmm3, xmm3
00007fa9d6dd623f  jnz 0x00007FA9D6DD940B
00007fa9d6dd6245  vmovaps xmm8, [rsp+0x50]
00007fa9d6dd624b  movaps xmm14, xmm8
00007fa9d6dd624f  addpd xmm14, xmm4
00007fa9d6dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007fa9d6dd625a  ptest xmm3, xmm3
00007fa9d6dd625f  jnz 0x00007FA9D6DD954F
00007fa9d6dd6265  vmovaps xmm8, [rsp+0x40]
00007fa9d6dd626b  vpermilpd xmm8, xmm8, 0x00
00007fa9d6dd6271  movaps xmm4, xmm13
00007fa9d6dd6275  mulpd xmm4, xmm8
00007fa9d6dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa9d6dd627f  ptest xmm3, xmm3
00007fa9d6dd6284  jnz 0x00007FA9D6DD9692
00007fa9d6dd628a  movaps xmm13, xmm15
00007fa9d6dd628e  addpd xmm13, xmm9
00007fa9d6dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007fa9d6dd6299  ptest xmm8, xmm8
00007fa9d6dd629f  jnz 0x00007FA9D6DD97D4
00007fa9d6dd62a5  movaps xmm15, xmm1
00007fa9d6dd62a9  addpd xmm15, xmm5
00007fa9d6dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa9d6dd62b4  ptest xmm9, xmm9
00007fa9d6dd62ba  jnz 0x00007FA9D6DD9918
00007fa9d6dd62c0  vmovaps [rsp+0x30], xmm11
00007fa9d6dd62c6  vmovaps xmm1, [rsp+0x30]
00007fa9d6dd62cc  por xmm11, xmm1
00007fa9d6dd62d1  movaps [r15+0x250], xmm11
00007fa9d6dd62d9  vmovaps [rsp+0x30], xmm12
00007fa9d6dd62df  vmovaps xmm1, [rsp+0x30]
00007fa9d6dd62e5  por xmm12, xmm1
00007fa9d6dd62ea  movaps [r15+0x2A0], xmm12
00007fa9d6dd62f2  vmovaps xmm1, [rsp+0xA0]
00007fa9d6dd62fb  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd6304  por xmm1, xmm11
00007fa9d6dd6309  movaps [r15+0x1D0], xmm1
00007fa9d6dd6311  lea r14, [rax+0x40]
00007fa9d6dd6315  movups xmm1, [r13+r14*1]
00007fa9d6dd631b  movaps [r15+0x2C0], xmm1
00007fa9d6dd6323  vmovaps xmm11, [rsp+0x40]
00007fa9d6dd6329  vpermilpd xmm11, xmm11, 0x00
00007fa9d6dd632f  vmovaps xmm8, [rsp+0xE0]
00007fa9d6dd6338  movaps xmm9, xmm8
00007fa9d6dd633c  mulpd xmm9, xmm11
00007fa9d6dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007fa9d6dd6347  ptest xmm5, xmm5
00007fa9d6dd634c  jnz 0x00007FA9D6DD9A64
00007fa9d6dd6352  movaps xmm11, xmm10
00007fa9d6dd6356  addpd xmm11, xmm6
00007fa9d6dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007fa9d6dd6361  ptest xmm8, xmm8
00007fa9d6dd6367  jnz 0x00007FA9D6DD9BA8
00007fa9d6dd636d  movaps xmm10, xmm14
00007fa9d6dd6371  addpd xmm10, xmm4
00007fa9d6dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007fa9d6dd637c  ptest xmm8, xmm8
00007fa9d6dd6382  jnz 0x00007FA9D6DD9CEB
00007fa9d6dd6388  vmovaps xmm14, [rsp+0x40]
00007fa9d6dd638e  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dd6394  movaps xmm8, xmm1
00007fa9d6dd6398  mulpd xmm8, xmm14
00007fa9d6dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa9d6dd63a3  ptest xmm6, xmm6
00007fa9d6dd63a8  jnz 0x00007FA9D6DD9E2E
00007fa9d6dd63ae  movaps xmm1, [r15+0x2B0]
00007fa9d6dd63b6  vmovaps xmm14, [rsp+0x40]
00007fa9d6dd63bc  vpermilpd xmm14, xmm14, 0x00
00007fa9d6dd63c2  movaps xmm6, xmm1
00007fa9d6dd63c5  mulpd xmm6, xmm14
00007fa9d6dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa9d6dd63cf  ptest xmm5, xmm5
00007fa9d6dd63d4  jnz 0x00007FA9D6DD9F71
00007fa9d6dd63da  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd63e0  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd63e6  movaps xmm14, xmm12
00007fa9d6dd63ea  mulpd xmm14, xmm1
00007fa9d6dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007fa9d6dd63f5  ptest xmm5, xmm5
00007fa9d6dd63fa  jnz 0x00007FA9D6DDA0B2
00007fa9d6dd6400  movaps xmm1, xmm13
00007fa9d6dd6404  addpd xmm1, xmm9
00007fa9d6dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa9d6dd640e  ptest xmm12, xmm12
00007fa9d6dd6414  jnz 0x00007FA9D6DDA1F5
00007fa9d6dd641a  vmovaps xmm13, [rsp+0x10]
00007fa9d6dd6420  vpermilpd xmm13, xmm13, 0x00
00007fa9d6dd6426  movaps xmm12, xmm7
00007fa9d6dd642a  mulpd xmm12, xmm13
00007fa9d6dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa9d6dd6435  ptest xmm9, xmm9
00007fa9d6dd643b  jnz 0x00007FA9D6DDA337
00007fa9d6dd6441  movaps xmm13, xmm15
00007fa9d6dd6445  addpd xmm13, xmm8
00007fa9d6dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007fa9d6dd6450  ptest xmm9, xmm9
00007fa9d6dd6456  jnz 0x00007FA9D6DDA47A
00007fa9d6dd645c  movaps xmm15, [r15+0x290]
00007fa9d6dd6464  vmovaps xmm9, [rsp+0x10]
00007fa9d6dd646a  vpermilpd xmm9, xmm9, 0x00
00007fa9d6dd6470  movaps xmm8, xmm15
00007fa9d6dd6474  mulpd xmm8, xmm9
00007fa9d6dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa9d6dd647f  ptest xmm7, xmm7
00007fa9d6dd6484  jnz 0x00007FA9D6DDA5BE
00007fa9d6dd648a  movaps xmm15, xmm11
00007fa9d6dd648e  addpd xmm15, xmm6
00007fa9d6dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa9d6dd6499  ptest xmm9, xmm9
00007fa9d6dd649f  jnz 0x00007FA9D6DDA702
00007fa9d6dd64a5  movaps xmm11, [r15+0x1E0]
00007fa9d6dd64ad  vmovaps xmm9, [rsp+0x10]
00007fa9d6dd64b3  vpermilpd xmm9, xmm9, 0x00
00007fa9d6dd64b9  movaps xmm7, xmm11
00007fa9d6dd64bd  mulpd xmm7, xmm9
00007fa9d6dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa9d6dd64c7  ptest xmm6, xmm6
00007fa9d6dd64cc  jnz 0x00007FA9D6DDA845
00007fa9d6dd64d2  movaps xmm11, xmm10
00007fa9d6dd64d6  addpd xmm11, xmm14
00007fa9d6dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007fa9d6dd64e1  ptest xmm9, xmm9
00007fa9d6dd64e7  jnz 0x00007FA9D6DDA987
00007fa9d6dd64ed  lea r14, [rax+0x70]
00007fa9d6dd64f1  movups xmm14, [r13+r14*1]
00007fa9d6dd64f7  movaps [r15+0x240], xmm14
00007fa9d6dd64ff  movaps xmm10, xmm1
00007fa9d6dd6503  addpd xmm10, xmm12
00007fa9d6dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007fa9d6dd650e  ptest xmm9, xmm9
00007fa9d6dd6514  jnz 0x00007FA9D6DDAAD5
00007fa9d6dd651a  movaps [r15+0x170], xmm10
00007fa9d6dd6522  vmovaps xmm1, [rsp+0x20]
00007fa9d6dd6528  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd652e  movaps xmm12, xmm14
00007fa9d6dd6532  mulpd xmm12, xmm1
00007fa9d6dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa9d6dd653d  ptest xmm9, xmm9
00007fa9d6dd6543  jnz 0x00007FA9D6DDAC18
00007fa9d6dd6549  vmovaps xmm1, [rsp+0x20]
00007fa9d6dd654f  vpermilpd xmm1, xmm1, 0x00
00007fa9d6dd6555  vmovaps xmm9, [rsp+0xB0]
00007fa9d6dd655e  movaps xmm14, xmm9
00007fa9d6dd6562  mulpd xmm14, xmm1
00007fa9d6dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa9d6dd656d  ptest xmm6, xmm6
00007fa9d6dd6572  jnz 0x00007FA9D6DDAD5B
00007fa9d6dd6578  movaps [r15+0x180], xmm14
00007fa9d6dd6580  movaps xmm1, xmm13
00007fa9d6dd6584  addpd xmm1, xmm8
00007fa9d6dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007fa9d6dd658e  ptest xmm9, xmm9
00007fa9d6dd6594  jnz 0x00007FA9D6DDAE9E
00007fa9d6dd659a  movaps [r15+0x210], xmm1
00007fa9d6dd65a2  movups xmm13, [r13+rax*1]
00007fa9d6dd65a8  lea r14, [rax+0x10]
00007fa9d6dd65ac  movups xmm9, [r13+r14*1]
00007fa9d6dd65b2  movaps [r15+0x230], xmm9
00007fa9d6dd65ba  movaps xmm8, xmm15
00007fa9d6dd65be  addpd xmm8, xmm7
00007fa9d6dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa9d6dd65c9  ptest xmm6, xmm6
00007fa9d6dd65ce  jnz 0x00007FA9D6DDAFF4
00007fa9d6dd65d4  movaps [r15+0x130], xmm8
00007fa9d6dd65dc  vmovaps xmm15, [rsp+0x20]
00007fa9d6dd65e2  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dd65e8  movaps xmm7, xmm9
00007fa9d6dd65ec  mulpd xmm7, xmm15
00007fa9d6dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa9d6dd65f6  ptest xmm6, xmm6
00007fa9d6dd65fb  jnz 0x00007FA9D6DDB137
00007fa9d6dd6601  movaps [r15+0x220], xmm7
00007fa9d6dd6609  vmovaps xmm15, [rsp+0x20]
00007fa9d6dd660f  vpermilpd xmm15, xmm15, 0x00
00007fa9d6dd6615  movaps xmm9, xmm13
00007fa9d6dd6619  mulpd xmm9, xmm15
00007fa9d6dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa9d6dd6624  ptest xmm6, xmm6
00007fa9d6dd6629  jnz 0x00007FA9D6DDB279
00007fa9d6dd662f  movaps xmm15, xmm11
00007fa9d6dd6633  addpd xmm15, xmm12
00007fa9d6dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa9d6dd663e  ptest xmm13, xmm13
00007fa9d6dd6644  jnz 0x00007FA9D6DDB3BD
00007fa9d6dd664a  movaps [r15+0x140], xmm15
00007fa9d6dd6652  movaps xmm13, xmm10
00007fa9d6dd6656  addpd xmm13, xmm14
00007fa9d6dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa9d6dd6661  ptest xmm12, xmm12
00007fa9d6dd6667  jnz 0x00007FA9D6DDB501
00007fa9d6dd666d  movaps [r15+0x150], xmm13
00007fa9d6dd6675  movaps xmm14, xmm1
00007fa9d6dd6679  addpd xmm14, xmm7
00007fa9d6dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007fa9d6dd6684  ptest xmm12, xmm12
00007fa9d6dd668a  jnz 0x00007FA9D6DDB645
00007fa9d6dd6690  movaps [r15+0x160], xmm14
00007fa9d6dd6698  movaps xmm1, xmm8
00007fa9d6dd669c  addpd xmm1, xmm9
00007fa9d6dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa9d6dd66a6  ptest xmm12, xmm12
00007fa9d6dd66ac  jnz 0x00007FA9D6DDB787
00007fa9d6dd66b2  movaps [r15+0x120], xmm1
00007fa9d6dd66ba  movups [r13+r11*1], xmm15
00007fa9d6dd66c0  lea rax, [r11+0x10]
00007fa9d6dd66c4  movups [r13+rax*1], xmm13
00007fa9d6dd66ca  lea rax, [r11+0x20]
00007fa9d6dd66ce  movups [r13+rax*1], xmm14
00007fa9d6dd66d4  lea rax, [r11+0x30]
00007fa9d6dd66d8  movups [r13+rax*1], xmm1
00007fa9d6dd66de  mov eax, [r15+0x108]
00007fa9d6dd66e5  sahf
00007fa9d6dd66e6  jnz 0x00007FA9D6DD6718
00007fa9d6dd66e8  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dd66f0  jz 0x00007FA9D6DDB900
00007fa9d6dd66f6  nop [rax+rax*1], ax
00007fa9d6dd66ff  nop [rax+rax*1], eax
00007fa9d6dd6707  mov eax, 0x410444
00007fa9d6dd670c  mov [r15+0x100], rax
00007fa9d6dd6713  jmp 0x00007FA9D6BFE110
00007fa9d6dd6718  cmp dword ptr [r15+0x318], 0x00
00007fa9d6dd6720  jz 0x00007FA9D6DD57E0
00007fa9d6dd6726  nop [rax+rax*1], ax
00007fa9d6dd672f  nop [rax+rax*1], eax
00007fa9d6dd6737  mov eax, 0x410278
00007fa9d6dd673c  mov [r15+0x100], rax
00007fa9d6dd6743  jmp 0x00007FA9D6BFE110
00007fa9d6dd6748  int3
00007fa9d6dd6749  call 0x00007FA9D6C0A4B0
00007fa9d6dd674e  jmp 0x00007FA9D6DD5828
00007fa9d6dd6753  call 0x00007FA9D6C09240
00007fa9d6dd6758  jmp 0x00007FA9D6DD5832
00007fa9d6dd675d  call 0x00007FA9D6C0A4B0
00007fa9d6dd6762  jmp 0x00007FA9D6DD588F
00007fa9d6dd6767  call 0x00007FA9D6C09240
00007fa9d6dd676c  jmp 0x00007FA9D6DD5899
00007fa9d6dd6771  call 0x00007FA9D6C0A4B0
00007fa9d6dd6776  jmp 0x00007FA9D6DD58DD
00007fa9d6dd677b  call 0x00007FA9D6C09240
00007fa9d6dd6780  jmp 0x00007FA9D6DD58E7
00007fa9d6dd6785  call 0x00007FA9D6CB47C0
00007fa9d6dd678a  jmp 0x00007FA9D6DD5926
00007fa9d6dd678f  call 0x00007FA9D6C0B720
00007fa9d6dd6794  jmp 0x00007FA9D6DD593A
00007fa9d6dd6799  call 0x00007FA9D6CBFC30
00007fa9d6dd679e  jmp 0x00007FA9D6DD5958
00007fa9d6dd67a3  call 0x00007FA9D6CBE9C0
00007fa9d6dd67a8  jmp 0x00007FA9D6DD5962
00007fa9d6dd67ad  call 0x00007FA9D6CBD750
00007fa9d6dd67b2  jmp 0x00007FA9D6DD596C
00007fa9d6dd67b7  sub rsp, 0x08
00007fa9d6dd67bb  push rax
00007fa9d6dd67bc  push rcx
00007fa9d6dd67bd  push rdx
00007fa9d6dd67be  push rdi
00007fa9d6dd67bf  push rsi
00007fa9d6dd67c0  push r8
00007fa9d6dd67c2  push r9
00007fa9d6dd67c4  push r10
00007fa9d6dd67c6  push r11
00007fa9d6dd67c8  sub rsp, 0xF0
00007fa9d6dd67cf  vmovaps [rsp], xmm0
00007fa9d6dd67d4  vmovaps [rsp+0x10], xmm1
00007fa9d6dd67da  vmovaps [rsp+0x20], xmm2
00007fa9d6dd67e0  vmovaps [rsp+0x30], xmm3
00007fa9d6dd67e6  vmovaps [rsp+0x40], xmm4
00007fa9d6dd67ec  vmovaps [rsp+0x50], xmm5
00007fa9d6dd67f2  vmovaps [rsp+0x60], xmm6
00007fa9d6dd67f8  vmovaps [rsp+0x70], xmm7
00007fa9d6dd67fe  vmovaps [rsp+0x80], xmm9
00007fa9d6dd6807  vmovaps [rsp+0x90], xmm10
00007fa9d6dd6810  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd6819  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd6822  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd682b  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd6834  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd683d  sub rsp, 0x30
00007fa9d6dd6841  movaps [rsp], xmm8
00007fa9d6dd6846  movaps [rsp+0x10], xmm12
00007fa9d6dd684c  movaps [rsp+0x20], xmm15
00007fa9d6dd6852  lea rdi, [rsp]
00007fa9d6dd6856  mov esi, 0x00
00007fa9d6dd685b  mov rax, 0x61DF872DB530
00007fa9d6dd6865  call rax
00007fa9d6dd6867  movaps xmm8, [rsp]
00007fa9d6dd686c  add rsp, 0x30
00007fa9d6dd6870  vmovaps xmm0, [rsp]
00007fa9d6dd6875  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd687b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd6881  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd6887  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd688d  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd6893  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd6899  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd689f  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd68a8  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd68b1  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd68ba  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd68c3  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd68cc  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd68d5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd68de  add rsp, 0xF0
00007fa9d6dd68e5  pop r11
00007fa9d6dd68e7  pop r10
00007fa9d6dd68e9  pop r9
00007fa9d6dd68eb  pop r8
00007fa9d6dd68ed  pop rsi
00007fa9d6dd68ee  pop rdi
00007fa9d6dd68ef  pop rdx
00007fa9d6dd68f0  pop rcx
00007fa9d6dd68f1  pop rax
00007fa9d6dd68f2  add rsp, 0x08
00007fa9d6dd68f6  jmp 0x00007FA9D6DD599A
00007fa9d6dd68fb  sub rsp, 0x08
00007fa9d6dd68ff  push rax
00007fa9d6dd6900  push rcx
00007fa9d6dd6901  push rdx
00007fa9d6dd6902  push rdi
00007fa9d6dd6903  push rsi
00007fa9d6dd6904  push r8
00007fa9d6dd6906  push r9
00007fa9d6dd6908  push r10
00007fa9d6dd690a  push r11
00007fa9d6dd690c  sub rsp, 0xF0
00007fa9d6dd6913  vmovaps [rsp], xmm0
00007fa9d6dd6918  vmovaps [rsp+0x10], xmm1
00007fa9d6dd691e  vmovaps [rsp+0x20], xmm2
00007fa9d6dd6924  vmovaps [rsp+0x30], xmm3
00007fa9d6dd692a  vmovaps [rsp+0x40], xmm4
00007fa9d6dd6930  vmovaps [rsp+0x50], xmm5
00007fa9d6dd6936  vmovaps [rsp+0x60], xmm6
00007fa9d6dd693c  vmovaps [rsp+0x70], xmm8
00007fa9d6dd6942  vmovaps [rsp+0x80], xmm9
00007fa9d6dd694b  vmovaps [rsp+0x90], xmm10
00007fa9d6dd6954  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd695d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd6966  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd696f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd6978  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd6981  sub rsp, 0x30
00007fa9d6dd6985  movaps [rsp], xmm7
00007fa9d6dd6989  movaps [rsp+0x10], xmm9
00007fa9d6dd698f  movaps [rsp+0x20], xmm15
00007fa9d6dd6995  lea rdi, [rsp]
00007fa9d6dd6999  mov esi, 0x00
00007fa9d6dd699e  mov rax, 0x61DF872DB530
00007fa9d6dd69a8  call rax
00007fa9d6dd69aa  movaps xmm7, [rsp]
00007fa9d6dd69ae  add rsp, 0x30
00007fa9d6dd69b2  vmovaps xmm0, [rsp]
00007fa9d6dd69b7  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd69bd  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd69c3  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd69c9  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd69cf  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd69d5  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd69db  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd69e1  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd69ea  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd69f3  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd69fc  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd6a05  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd6a0e  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd6a17  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd6a20  add rsp, 0xF0
00007fa9d6dd6a27  pop r11
00007fa9d6dd6a29  pop r10
00007fa9d6dd6a2b  pop r9
00007fa9d6dd6a2d  pop r8
00007fa9d6dd6a2f  pop rsi
00007fa9d6dd6a30  pop rdi
00007fa9d6dd6a31  pop rdx
00007fa9d6dd6a32  pop rcx
00007fa9d6dd6a33  pop rax
00007fa9d6dd6a34  add rsp, 0x08
00007fa9d6dd6a38  jmp 0x00007FA9D6DD59C8
00007fa9d6dd6a3d  sub rsp, 0x08
00007fa9d6dd6a41  push rax
00007fa9d6dd6a42  push rcx
00007fa9d6dd6a43  push rdx
00007fa9d6dd6a44  push rdi
00007fa9d6dd6a45  push rsi
00007fa9d6dd6a46  push r8
00007fa9d6dd6a48  push r9
00007fa9d6dd6a4a  push r10
00007fa9d6dd6a4c  push r11
00007fa9d6dd6a4e  sub rsp, 0xF0
00007fa9d6dd6a55  vmovaps [rsp], xmm0
00007fa9d6dd6a5a  vmovaps [rsp+0x10], xmm1
00007fa9d6dd6a60  vmovaps [rsp+0x20], xmm2
00007fa9d6dd6a66  vmovaps [rsp+0x30], xmm3
00007fa9d6dd6a6c  vmovaps [rsp+0x40], xmm4
00007fa9d6dd6a72  vmovaps [rsp+0x50], xmm5
00007fa9d6dd6a78  vmovaps [rsp+0x60], xmm6
00007fa9d6dd6a7e  vmovaps [rsp+0x70], xmm7
00007fa9d6dd6a84  vmovaps [rsp+0x80], xmm8
00007fa9d6dd6a8d  vmovaps [rsp+0x90], xmm10
00007fa9d6dd6a96  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd6a9f  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd6aa8  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd6ab1  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd6aba  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd6ac3  sub rsp, 0x30
00007fa9d6dd6ac7  movaps [rsp], xmm9
00007fa9d6dd6acc  movaps [rsp+0x10], xmm12
00007fa9d6dd6ad2  movaps [rsp+0x20], xmm10
00007fa9d6dd6ad8  lea rdi, [rsp]
00007fa9d6dd6adc  mov esi, 0x00
00007fa9d6dd6ae1  mov rax, 0x61DF872DB530
00007fa9d6dd6aeb  call rax
00007fa9d6dd6aed  movaps xmm9, [rsp]
00007fa9d6dd6af2  add rsp, 0x30
00007fa9d6dd6af6  vmovaps xmm0, [rsp]
00007fa9d6dd6afb  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd6b01  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd6b07  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd6b0d  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd6b13  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd6b19  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd6b1f  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd6b25  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd6b2e  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd6b37  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd6b40  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd6b49  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd6b52  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd6b5b  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd6b64  add rsp, 0xF0
00007fa9d6dd6b6b  pop r11
00007fa9d6dd6b6d  pop r10
00007fa9d6dd6b6f  pop r9
00007fa9d6dd6b71  pop r8
00007fa9d6dd6b73  pop rsi
00007fa9d6dd6b74  pop rdi
00007fa9d6dd6b75  pop rdx
00007fa9d6dd6b76  pop rcx
00007fa9d6dd6b77  pop rax
00007fa9d6dd6b78  add rsp, 0x08
00007fa9d6dd6b7c  jmp 0x00007FA9D6DD59EC
00007fa9d6dd6b81  sub rsp, 0x08
00007fa9d6dd6b85  push rax
00007fa9d6dd6b86  push rcx
00007fa9d6dd6b87  push rdx
00007fa9d6dd6b88  push rdi
00007fa9d6dd6b89  push rsi
00007fa9d6dd6b8a  push r8
00007fa9d6dd6b8c  push r9
00007fa9d6dd6b8e  push r10
00007fa9d6dd6b90  push r11
00007fa9d6dd6b92  sub rsp, 0xF0
00007fa9d6dd6b99  vmovaps [rsp], xmm0
00007fa9d6dd6b9e  vmovaps [rsp+0x10], xmm1
00007fa9d6dd6ba4  vmovaps [rsp+0x20], xmm2
00007fa9d6dd6baa  vmovaps [rsp+0x30], xmm3
00007fa9d6dd6bb0  vmovaps [rsp+0x40], xmm4
00007fa9d6dd6bb6  vmovaps [rsp+0x50], xmm5
00007fa9d6dd6bbc  vmovaps [rsp+0x60], xmm6
00007fa9d6dd6bc2  vmovaps [rsp+0x70], xmm7
00007fa9d6dd6bc8  vmovaps [rsp+0x80], xmm8
00007fa9d6dd6bd1  vmovaps [rsp+0x90], xmm9
00007fa9d6dd6bda  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd6be3  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd6bec  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd6bf5  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd6bfe  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd6c07  sub rsp, 0x30
00007fa9d6dd6c0b  movaps [rsp], xmm10
00007fa9d6dd6c10  movaps [rsp+0x10], xmm12
00007fa9d6dd6c16  movaps [rsp+0x20], xmm11
00007fa9d6dd6c1c  lea rdi, [rsp]
00007fa9d6dd6c20  mov esi, 0x00
00007fa9d6dd6c25  mov rax, 0x61DF872DB530
00007fa9d6dd6c2f  call rax
00007fa9d6dd6c31  movaps xmm10, [rsp]
00007fa9d6dd6c36  add rsp, 0x30
00007fa9d6dd6c3a  vmovaps xmm0, [rsp]
00007fa9d6dd6c3f  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd6c45  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd6c4b  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd6c51  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd6c57  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd6c5d  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd6c63  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd6c69  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd6c72  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd6c7b  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd6c84  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd6c8d  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd6c96  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd6c9f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd6ca8  add rsp, 0xF0
00007fa9d6dd6caf  pop r11
00007fa9d6dd6cb1  pop r10
00007fa9d6dd6cb3  pop r9
00007fa9d6dd6cb5  pop r8
00007fa9d6dd6cb7  pop rsi
00007fa9d6dd6cb8  pop rdi
00007fa9d6dd6cb9  pop rdx
00007fa9d6dd6cba  pop rcx
00007fa9d6dd6cbb  pop rax
00007fa9d6dd6cbc  add rsp, 0x08
00007fa9d6dd6cc0  jmp 0x00007FA9D6DD5A06
00007fa9d6dd6cc5  sub rsp, 0x08
00007fa9d6dd6cc9  push rax
00007fa9d6dd6cca  push rcx
00007fa9d6dd6ccb  push rdx
00007fa9d6dd6ccc  push rdi
00007fa9d6dd6ccd  push rsi
00007fa9d6dd6cce  push r8
00007fa9d6dd6cd0  push r9
00007fa9d6dd6cd2  push r10
00007fa9d6dd6cd4  push r11
00007fa9d6dd6cd6  sub rsp, 0xF0
00007fa9d6dd6cdd  vmovaps [rsp], xmm0
00007fa9d6dd6ce2  vmovaps [rsp+0x10], xmm1
00007fa9d6dd6ce8  vmovaps [rsp+0x20], xmm2
00007fa9d6dd6cee  vmovaps [rsp+0x30], xmm3
00007fa9d6dd6cf4  vmovaps [rsp+0x40], xmm4
00007fa9d6dd6cfa  vmovaps [rsp+0x50], xmm5
00007fa9d6dd6d00  vmovaps [rsp+0x60], xmm7
00007fa9d6dd6d06  vmovaps [rsp+0x70], xmm8
00007fa9d6dd6d0c  vmovaps [rsp+0x80], xmm9
00007fa9d6dd6d15  vmovaps [rsp+0x90], xmm10
00007fa9d6dd6d1e  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd6d27  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd6d30  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd6d39  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd6d42  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd6d4b  sub rsp, 0x30
00007fa9d6dd6d4f  movaps [rsp], xmm6
00007fa9d6dd6d53  movaps [rsp+0x10], xmm12
00007fa9d6dd6d59  movaps [rsp+0x20], xmm11
00007fa9d6dd6d5f  lea rdi, [rsp]
00007fa9d6dd6d63  mov esi, 0x00
00007fa9d6dd6d68  mov rax, 0x61DF872DB530
00007fa9d6dd6d72  call rax
00007fa9d6dd6d74  movaps xmm6, [rsp]
00007fa9d6dd6d78  add rsp, 0x30
00007fa9d6dd6d7c  vmovaps xmm0, [rsp]
00007fa9d6dd6d81  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd6d87  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd6d8d  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd6d93  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd6d99  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd6d9f  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd6da5  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd6dab  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd6db4  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd6dbd  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd6dc6  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd6dcf  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd6dd8  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd6de1  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd6dea  add rsp, 0xF0
00007fa9d6dd6df1  pop r11
00007fa9d6dd6df3  pop r10
00007fa9d6dd6df5  pop r9
00007fa9d6dd6df7  pop r8
00007fa9d6dd6df9  pop rsi
00007fa9d6dd6dfa  pop rdi
00007fa9d6dd6dfb  pop rdx
00007fa9d6dd6dfc  pop rcx
00007fa9d6dd6dfd  pop rax
00007fa9d6dd6dfe  add rsp, 0x08
00007fa9d6dd6e02  jmp 0x00007FA9D6DD5A27
00007fa9d6dd6e07  sub rsp, 0x08
00007fa9d6dd6e0b  push rax
00007fa9d6dd6e0c  push rcx
00007fa9d6dd6e0d  push rdx
00007fa9d6dd6e0e  push rdi
00007fa9d6dd6e0f  push rsi
00007fa9d6dd6e10  push r8
00007fa9d6dd6e12  push r9
00007fa9d6dd6e14  push r10
00007fa9d6dd6e16  push r11
00007fa9d6dd6e18  sub rsp, 0xF0
00007fa9d6dd6e1f  vmovaps [rsp], xmm0
00007fa9d6dd6e24  vmovaps [rsp+0x10], xmm1
00007fa9d6dd6e2a  vmovaps [rsp+0x20], xmm2
00007fa9d6dd6e30  vmovaps [rsp+0x30], xmm4
00007fa9d6dd6e36  vmovaps [rsp+0x40], xmm5
00007fa9d6dd6e3c  vmovaps [rsp+0x50], xmm6
00007fa9d6dd6e42  vmovaps [rsp+0x60], xmm7
00007fa9d6dd6e48  vmovaps [rsp+0x70], xmm8
00007fa9d6dd6e4e  vmovaps [rsp+0x80], xmm9
00007fa9d6dd6e57  vmovaps [rsp+0x90], xmm10
00007fa9d6dd6e60  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd6e69  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd6e72  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd6e7b  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd6e84  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd6e8d  sub rsp, 0x30
00007fa9d6dd6e91  movaps [rsp], xmm3
00007fa9d6dd6e95  movaps [rsp+0x10], xmm5
00007fa9d6dd6e9a  movaps [rsp+0x20], xmm4
00007fa9d6dd6e9f  lea rdi, [rsp]
00007fa9d6dd6ea3  mov esi, 0x00
00007fa9d6dd6ea8  mov rax, 0x61DF872DB530
00007fa9d6dd6eb2  call rax
00007fa9d6dd6eb4  movaps xmm3, [rsp]
00007fa9d6dd6eb8  add rsp, 0x30
00007fa9d6dd6ebc  vmovaps xmm0, [rsp]
00007fa9d6dd6ec1  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd6ec7  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd6ecd  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd6ed3  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd6ed9  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd6edf  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd6ee5  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd6eeb  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd6ef4  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd6efd  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd6f06  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd6f0f  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd6f18  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd6f21  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd6f2a  add rsp, 0xF0
00007fa9d6dd6f31  pop r11
00007fa9d6dd6f33  pop r10
00007fa9d6dd6f35  pop r9
00007fa9d6dd6f37  pop r8
00007fa9d6dd6f39  pop rsi
00007fa9d6dd6f3a  pop rdi
00007fa9d6dd6f3b  pop rdx
00007fa9d6dd6f3c  pop rcx
00007fa9d6dd6f3d  pop rax
00007fa9d6dd6f3e  add rsp, 0x08
00007fa9d6dd6f42  jmp 0x00007FA9D6DD5A88
00007fa9d6dd6f47  sub rsp, 0x08
00007fa9d6dd6f4b  push rax
00007fa9d6dd6f4c  push rcx
00007fa9d6dd6f4d  push rdx
00007fa9d6dd6f4e  push rdi
00007fa9d6dd6f4f  push rsi
00007fa9d6dd6f50  push r8
00007fa9d6dd6f52  push r9
00007fa9d6dd6f54  push r10
00007fa9d6dd6f56  push r11
00007fa9d6dd6f58  sub rsp, 0xF0
00007fa9d6dd6f5f  vmovaps [rsp], xmm0
00007fa9d6dd6f64  vmovaps [rsp+0x10], xmm1
00007fa9d6dd6f6a  vmovaps [rsp+0x20], xmm2
00007fa9d6dd6f70  vmovaps [rsp+0x30], xmm3
00007fa9d6dd6f76  vmovaps [rsp+0x40], xmm4
00007fa9d6dd6f7c  vmovaps [rsp+0x50], xmm6
00007fa9d6dd6f82  vmovaps [rsp+0x60], xmm7
00007fa9d6dd6f88  vmovaps [rsp+0x70], xmm8
00007fa9d6dd6f8e  vmovaps [rsp+0x80], xmm9
00007fa9d6dd6f97  vmovaps [rsp+0x90], xmm10
00007fa9d6dd6fa0  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd6fa9  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd6fb2  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd6fbb  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd6fc4  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd6fcd  sub rsp, 0x30
00007fa9d6dd6fd1  movaps [rsp], xmm5
00007fa9d6dd6fd5  movaps [rsp+0x10], xmm8
00007fa9d6dd6fdb  movaps [rsp+0x20], xmm15
00007fa9d6dd6fe1  lea rdi, [rsp]
00007fa9d6dd6fe5  mov esi, 0x00
00007fa9d6dd6fea  mov rax, 0x61DF872DB530
00007fa9d6dd6ff4  call rax
00007fa9d6dd6ff6  movaps xmm5, [rsp]
00007fa9d6dd6ffa  add rsp, 0x30
00007fa9d6dd6ffe  vmovaps xmm0, [rsp]
00007fa9d6dd7003  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd7009  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd700f  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd7015  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd701b  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd7021  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd7027  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd702d  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7036  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd703f  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd7048  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd7051  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd705a  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd7063  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd706c  add rsp, 0xF0
00007fa9d6dd7073  pop r11
00007fa9d6dd7075  pop r10
00007fa9d6dd7077  pop r9
00007fa9d6dd7079  pop r8
00007fa9d6dd707b  pop rsi
00007fa9d6dd707c  pop rdi
00007fa9d6dd707d  pop rdx
00007fa9d6dd707e  pop rcx
00007fa9d6dd707f  pop rax
00007fa9d6dd7080  add rsp, 0x08
00007fa9d6dd7084  jmp 0x00007FA9D6DD5AC0
00007fa9d6dd7089  sub rsp, 0x08
00007fa9d6dd708d  push rax
00007fa9d6dd708e  push rcx
00007fa9d6dd708f  push rdx
00007fa9d6dd7090  push rdi
00007fa9d6dd7091  push rsi
00007fa9d6dd7092  push r8
00007fa9d6dd7094  push r9
00007fa9d6dd7096  push r10
00007fa9d6dd7098  push r11
00007fa9d6dd709a  sub rsp, 0xF0
00007fa9d6dd70a1  vmovaps [rsp], xmm0
00007fa9d6dd70a6  vmovaps [rsp+0x10], xmm1
00007fa9d6dd70ac  vmovaps [rsp+0x20], xmm2
00007fa9d6dd70b2  vmovaps [rsp+0x30], xmm3
00007fa9d6dd70b8  vmovaps [rsp+0x40], xmm5
00007fa9d6dd70be  vmovaps [rsp+0x50], xmm6
00007fa9d6dd70c4  vmovaps [rsp+0x60], xmm7
00007fa9d6dd70ca  vmovaps [rsp+0x70], xmm8
00007fa9d6dd70d0  vmovaps [rsp+0x80], xmm9
00007fa9d6dd70d9  vmovaps [rsp+0x90], xmm10
00007fa9d6dd70e2  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd70eb  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd70f4  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd70fd  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd7106  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd710f  sub rsp, 0x30
00007fa9d6dd7113  movaps [rsp], xmm4
00007fa9d6dd7117  movaps [rsp+0x10], xmm9
00007fa9d6dd711d  movaps [rsp+0x20], xmm8
00007fa9d6dd7123  lea rdi, [rsp]
00007fa9d6dd7127  mov esi, 0x00
00007fa9d6dd712c  mov rax, 0x61DF872DB530
00007fa9d6dd7136  call rax
00007fa9d6dd7138  movaps xmm4, [rsp]
00007fa9d6dd713c  add rsp, 0x30
00007fa9d6dd7140  vmovaps xmm0, [rsp]
00007fa9d6dd7145  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd714b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd7151  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd7157  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd715d  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd7163  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd7169  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd716f  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7178  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd7181  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd718a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd7193  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd719c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd71a5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd71ae  add rsp, 0xF0
00007fa9d6dd71b5  pop r11
00007fa9d6dd71b7  pop r10
00007fa9d6dd71b9  pop r9
00007fa9d6dd71bb  pop r8
00007fa9d6dd71bd  pop rsi
00007fa9d6dd71be  pop rdi
00007fa9d6dd71bf  pop rdx
00007fa9d6dd71c0  pop rcx
00007fa9d6dd71c1  pop rax
00007fa9d6dd71c2  add rsp, 0x08
00007fa9d6dd71c6  jmp 0x00007FA9D6DD5AE1
00007fa9d6dd71cb  sub rsp, 0x08
00007fa9d6dd71cf  push rax
00007fa9d6dd71d0  push rcx
00007fa9d6dd71d1  push rdx
00007fa9d6dd71d2  push rdi
00007fa9d6dd71d3  push rsi
00007fa9d6dd71d4  push r8
00007fa9d6dd71d6  push r9
00007fa9d6dd71d8  push r10
00007fa9d6dd71da  push r11
00007fa9d6dd71dc  sub rsp, 0xF0
00007fa9d6dd71e3  vmovaps [rsp], xmm0
00007fa9d6dd71e8  vmovaps [rsp+0x10], xmm1
00007fa9d6dd71ee  vmovaps [rsp+0x20], xmm2
00007fa9d6dd71f4  vmovaps [rsp+0x30], xmm3
00007fa9d6dd71fa  vmovaps [rsp+0x40], xmm4
00007fa9d6dd7200  vmovaps [rsp+0x50], xmm5
00007fa9d6dd7206  vmovaps [rsp+0x60], xmm6
00007fa9d6dd720c  vmovaps [rsp+0x70], xmm7
00007fa9d6dd7212  vmovaps [rsp+0x80], xmm8
00007fa9d6dd721b  vmovaps [rsp+0x90], xmm10
00007fa9d6dd7224  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd722d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd7236  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd723f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd7248  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd7251  sub rsp, 0x30
00007fa9d6dd7255  movaps [rsp], xmm9
00007fa9d6dd725a  movaps [rsp+0x10], xmm10
00007fa9d6dd7260  movaps [rsp+0x20], xmm8
00007fa9d6dd7266  lea rdi, [rsp]
00007fa9d6dd726a  mov esi, 0x00
00007fa9d6dd726f  mov rax, 0x61DF872DB530
00007fa9d6dd7279  call rax
00007fa9d6dd727b  movaps xmm9, [rsp]
00007fa9d6dd7280  add rsp, 0x30
00007fa9d6dd7284  vmovaps xmm0, [rsp]
00007fa9d6dd7289  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd728f  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd7295  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd729b  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd72a1  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd72a7  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd72ad  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd72b3  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd72bc  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd72c5  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd72ce  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd72d7  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd72e0  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd72e9  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd72f2  add rsp, 0xF0
00007fa9d6dd72f9  pop r11
00007fa9d6dd72fb  pop r10
00007fa9d6dd72fd  pop r9
00007fa9d6dd72ff  pop r8
00007fa9d6dd7301  pop rsi
00007fa9d6dd7302  pop rdi
00007fa9d6dd7303  pop rdx
00007fa9d6dd7304  pop rcx
00007fa9d6dd7305  pop rax
00007fa9d6dd7306  add rsp, 0x08
00007fa9d6dd730a  jmp 0x00007FA9D6DD5AFB
00007fa9d6dd730f  call 0x00007FA9D6CD64F0
00007fa9d6dd7314  jmp 0x00007FA9D6DD5C15
00007fa9d6dd7319  call 0x00007FA9D6CD64F0
00007fa9d6dd731e  jmp 0x00007FA9D6DD5C2B
00007fa9d6dd7323  sub rsp, 0x08
00007fa9d6dd7327  push rax
00007fa9d6dd7328  push rcx
00007fa9d6dd7329  push rdx
00007fa9d6dd732a  push rdi
00007fa9d6dd732b  push rsi
00007fa9d6dd732c  push r8
00007fa9d6dd732e  push r9
00007fa9d6dd7330  push r10
00007fa9d6dd7332  push r11
00007fa9d6dd7334  sub rsp, 0xF0
00007fa9d6dd733b  vmovaps [rsp], xmm0
00007fa9d6dd7340  vmovaps [rsp+0x10], xmm2
00007fa9d6dd7346  vmovaps [rsp+0x20], xmm3
00007fa9d6dd734c  vmovaps [rsp+0x30], xmm4
00007fa9d6dd7352  vmovaps [rsp+0x40], xmm5
00007fa9d6dd7358  vmovaps [rsp+0x50], xmm6
00007fa9d6dd735e  vmovaps [rsp+0x60], xmm7
00007fa9d6dd7364  vmovaps [rsp+0x70], xmm8
00007fa9d6dd736a  vmovaps [rsp+0x80], xmm9
00007fa9d6dd7373  vmovaps [rsp+0x90], xmm10
00007fa9d6dd737c  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd7385  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd738e  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd7397  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd73a0  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd73a9  sub rsp, 0x30
00007fa9d6dd73ad  movaps [rsp], xmm1
00007fa9d6dd73b1  movaps [rsp+0x10], xmm6
00007fa9d6dd73b6  movaps [rsp+0x20], xmm15
00007fa9d6dd73bc  lea rdi, [rsp]
00007fa9d6dd73c0  mov esi, 0x00
00007fa9d6dd73c5  mov rax, 0x61DF872DB530
00007fa9d6dd73cf  call rax
00007fa9d6dd73d1  movaps xmm1, [rsp]
00007fa9d6dd73d5  add rsp, 0x30
00007fa9d6dd73d9  vmovaps xmm0, [rsp]
00007fa9d6dd73de  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd73e4  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd73ea  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd73f0  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd73f6  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd73fc  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd7402  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd7408  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7411  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd741a  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd7423  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd742c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd7435  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd743e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7447  add rsp, 0xF0
00007fa9d6dd744e  pop r11
00007fa9d6dd7450  pop r10
00007fa9d6dd7452  pop r9
00007fa9d6dd7454  pop r8
00007fa9d6dd7456  pop rsi
00007fa9d6dd7457  pop rdi
00007fa9d6dd7458  pop rdx
00007fa9d6dd7459  pop rcx
00007fa9d6dd745a  pop rax
00007fa9d6dd745b  add rsp, 0x08
00007fa9d6dd745f  jmp 0x00007FA9D6DD5C68
00007fa9d6dd7464  call 0x00007FA9D6CE5820
00007fa9d6dd7469  jmp 0x00007FA9D6DD5C75
00007fa9d6dd746e  sub rsp, 0x08
00007fa9d6dd7472  push rax
00007fa9d6dd7473  push rcx
00007fa9d6dd7474  push rdx
00007fa9d6dd7475  push rdi
00007fa9d6dd7476  push rsi
00007fa9d6dd7477  push r8
00007fa9d6dd7479  push r9
00007fa9d6dd747b  push r10
00007fa9d6dd747d  push r11
00007fa9d6dd747f  sub rsp, 0xF0
00007fa9d6dd7486  vmovaps [rsp], xmm0
00007fa9d6dd748b  vmovaps [rsp+0x10], xmm1
00007fa9d6dd7491  vmovaps [rsp+0x20], xmm2
00007fa9d6dd7497  vmovaps [rsp+0x30], xmm3
00007fa9d6dd749d  vmovaps [rsp+0x40], xmm4
00007fa9d6dd74a3  vmovaps [rsp+0x50], xmm5
00007fa9d6dd74a9  vmovaps [rsp+0x60], xmm6
00007fa9d6dd74af  vmovaps [rsp+0x70], xmm7
00007fa9d6dd74b5  vmovaps [rsp+0x80], xmm8
00007fa9d6dd74be  vmovaps [rsp+0x90], xmm9
00007fa9d6dd74c7  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd74d0  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd74d9  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd74e2  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd74eb  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd74f4  sub rsp, 0x30
00007fa9d6dd74f8  movaps [rsp], xmm14
00007fa9d6dd74fd  movaps [rsp+0x10], xmm4
00007fa9d6dd7502  movaps [rsp+0x20], xmm3
00007fa9d6dd7507  lea rdi, [rsp]
00007fa9d6dd750b  mov esi, 0x00
00007fa9d6dd7510  mov rax, 0x61DF872DB530
00007fa9d6dd751a  call rax
00007fa9d6dd751c  movaps xmm14, [rsp]
00007fa9d6dd7521  add rsp, 0x30
00007fa9d6dd7525  vmovaps xmm0, [rsp]
00007fa9d6dd752a  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd7530  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd7536  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd753c  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd7542  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd7548  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd754e  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd7554  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd755d  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd7566  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd756f  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd7578  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd7581  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd758a  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7593  add rsp, 0xF0
00007fa9d6dd759a  pop r11
00007fa9d6dd759c  pop r10
00007fa9d6dd759e  pop r9
00007fa9d6dd75a0  pop r8
00007fa9d6dd75a2  pop rsi
00007fa9d6dd75a3  pop rdi
00007fa9d6dd75a4  pop rdx
00007fa9d6dd75a5  pop rcx
00007fa9d6dd75a6  pop rax
00007fa9d6dd75a7  add rsp, 0x08
00007fa9d6dd75ab  jmp 0x00007FA9D6DD5C8F
00007fa9d6dd75b0  sub rsp, 0x08
00007fa9d6dd75b4  push rax
00007fa9d6dd75b5  push rcx
00007fa9d6dd75b6  push rdx
00007fa9d6dd75b7  push rdi
00007fa9d6dd75b8  push rsi
00007fa9d6dd75b9  push r8
00007fa9d6dd75bb  push r9
00007fa9d6dd75bd  push r10
00007fa9d6dd75bf  push r11
00007fa9d6dd75c1  sub rsp, 0xF0
00007fa9d6dd75c8  vmovaps [rsp], xmm0
00007fa9d6dd75cd  vmovaps [rsp+0x10], xmm1
00007fa9d6dd75d3  vmovaps [rsp+0x20], xmm2
00007fa9d6dd75d9  vmovaps [rsp+0x30], xmm3
00007fa9d6dd75df  vmovaps [rsp+0x40], xmm4
00007fa9d6dd75e5  vmovaps [rsp+0x50], xmm5
00007fa9d6dd75eb  vmovaps [rsp+0x60], xmm7
00007fa9d6dd75f1  vmovaps [rsp+0x70], xmm8
00007fa9d6dd75f7  vmovaps [rsp+0x80], xmm9
00007fa9d6dd7600  vmovaps [rsp+0x90], xmm10
00007fa9d6dd7609  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd7612  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd761b  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd7624  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd762d  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd7636  sub rsp, 0x30
00007fa9d6dd763a  movaps [rsp], xmm6
00007fa9d6dd763e  movaps [rsp+0x10], xmm9
00007fa9d6dd7644  movaps [rsp+0x20], xmm7
00007fa9d6dd7649  lea rdi, [rsp]
00007fa9d6dd764d  mov esi, 0x00
00007fa9d6dd7652  mov rax, 0x61DF872DB530
00007fa9d6dd765c  call rax
00007fa9d6dd765e  movaps xmm6, [rsp]
00007fa9d6dd7662  add rsp, 0x30
00007fa9d6dd7666  vmovaps xmm0, [rsp]
00007fa9d6dd766b  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd7671  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd7677  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd767d  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd7683  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd7689  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd768f  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd7695  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd769e  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd76a7  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd76b0  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd76b9  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd76c2  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd76cb  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd76d4  add rsp, 0xF0
00007fa9d6dd76db  pop r11
00007fa9d6dd76dd  pop r10
00007fa9d6dd76df  pop r9
00007fa9d6dd76e1  pop r8
00007fa9d6dd76e3  pop rsi
00007fa9d6dd76e4  pop rdi
00007fa9d6dd76e5  pop rdx
00007fa9d6dd76e6  pop rcx
00007fa9d6dd76e7  pop rax
00007fa9d6dd76e8  add rsp, 0x08
00007fa9d6dd76ec  jmp 0x00007FA9D6DD5CA7
00007fa9d6dd76f1  sub rsp, 0x08
00007fa9d6dd76f5  push rax
00007fa9d6dd76f6  push rcx
00007fa9d6dd76f7  push rdx
00007fa9d6dd76f8  push rdi
00007fa9d6dd76f9  push rsi
00007fa9d6dd76fa  push r8
00007fa9d6dd76fc  push r9
00007fa9d6dd76fe  push r10
00007fa9d6dd7700  push r11
00007fa9d6dd7702  sub rsp, 0xF0
00007fa9d6dd7709  vmovaps [rsp], xmm0
00007fa9d6dd770e  vmovaps [rsp+0x10], xmm1
00007fa9d6dd7714  vmovaps [rsp+0x20], xmm2
00007fa9d6dd771a  vmovaps [rsp+0x30], xmm3
00007fa9d6dd7720  vmovaps [rsp+0x40], xmm4
00007fa9d6dd7726  vmovaps [rsp+0x50], xmm5
00007fa9d6dd772c  vmovaps [rsp+0x60], xmm6
00007fa9d6dd7732  vmovaps [rsp+0x70], xmm8
00007fa9d6dd7738  vmovaps [rsp+0x80], xmm9
00007fa9d6dd7741  vmovaps [rsp+0x90], xmm10
00007fa9d6dd774a  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd7753  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd775c  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd7765  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd776e  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd7777  sub rsp, 0x30
00007fa9d6dd777b  movaps [rsp], xmm7
00007fa9d6dd777f  movaps [rsp+0x10], xmm4
00007fa9d6dd7784  movaps [rsp+0x20], xmm9
00007fa9d6dd778a  lea rdi, [rsp]
00007fa9d6dd778e  mov esi, 0x00
00007fa9d6dd7793  mov rax, 0x61DF872DB530
00007fa9d6dd779d  call rax
00007fa9d6dd779f  movaps xmm7, [rsp]
00007fa9d6dd77a3  add rsp, 0x30
00007fa9d6dd77a7  vmovaps xmm0, [rsp]
00007fa9d6dd77ac  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd77b2  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd77b8  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd77be  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd77c4  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd77ca  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd77d0  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd77d6  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd77df  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd77e8  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd77f1  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd77fa  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd7803  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd780c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7815  add rsp, 0xF0
00007fa9d6dd781c  pop r11
00007fa9d6dd781e  pop r10
00007fa9d6dd7820  pop r9
00007fa9d6dd7822  pop r8
00007fa9d6dd7824  pop rsi
00007fa9d6dd7825  pop rdi
00007fa9d6dd7826  pop rdx
00007fa9d6dd7827  pop rcx
00007fa9d6dd7828  pop rax
00007fa9d6dd7829  add rsp, 0x08
00007fa9d6dd782d  jmp 0x00007FA9D6DD5CD4
00007fa9d6dd7832  sub rsp, 0x08
00007fa9d6dd7836  push rax
00007fa9d6dd7837  push rcx
00007fa9d6dd7838  push rdx
00007fa9d6dd7839  push rdi
00007fa9d6dd783a  push rsi
00007fa9d6dd783b  push r8
00007fa9d6dd783d  push r9
00007fa9d6dd783f  push r10
00007fa9d6dd7841  push r11
00007fa9d6dd7843  sub rsp, 0xF0
00007fa9d6dd784a  vmovaps [rsp], xmm0
00007fa9d6dd784f  vmovaps [rsp+0x10], xmm1
00007fa9d6dd7855  vmovaps [rsp+0x20], xmm2
00007fa9d6dd785b  vmovaps [rsp+0x30], xmm3
00007fa9d6dd7861  vmovaps [rsp+0x40], xmm5
00007fa9d6dd7867  vmovaps [rsp+0x50], xmm6
00007fa9d6dd786d  vmovaps [rsp+0x60], xmm7
00007fa9d6dd7873  vmovaps [rsp+0x70], xmm8
00007fa9d6dd7879  vmovaps [rsp+0x80], xmm9
00007fa9d6dd7882  vmovaps [rsp+0x90], xmm10
00007fa9d6dd788b  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd7894  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd789d  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd78a6  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd78af  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd78b8  sub rsp, 0x30
00007fa9d6dd78bc  movaps [rsp], xmm4
00007fa9d6dd78c0  movaps [rsp+0x10], xmm15
00007fa9d6dd78c6  movaps [rsp+0x20], xmm9
00007fa9d6dd78cc  lea rdi, [rsp]
00007fa9d6dd78d0  mov esi, 0x00
00007fa9d6dd78d5  mov rax, 0x61DF872DB530
00007fa9d6dd78df  call rax
00007fa9d6dd78e1  movaps xmm4, [rsp]
00007fa9d6dd78e5  add rsp, 0x30
00007fa9d6dd78e9  vmovaps xmm0, [rsp]
00007fa9d6dd78ee  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd78f4  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd78fa  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd7900  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd7906  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd790c  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd7912  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd7918  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7921  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd792a  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd7933  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd793c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd7945  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd794e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7957  add rsp, 0xF0
00007fa9d6dd795e  pop r11
00007fa9d6dd7960  pop r10
00007fa9d6dd7962  pop r9
00007fa9d6dd7964  pop r8
00007fa9d6dd7966  pop rsi
00007fa9d6dd7967  pop rdi
00007fa9d6dd7968  pop rdx
00007fa9d6dd7969  pop rcx
00007fa9d6dd796a  pop rax
00007fa9d6dd796b  add rsp, 0x08
00007fa9d6dd796f  jmp 0x00007FA9D6DD5CF9
00007fa9d6dd7974  call 0x00007FA9D6CE5820
00007fa9d6dd7979  jmp 0x00007FA9D6DD5D06
00007fa9d6dd797e  sub rsp, 0x08
00007fa9d6dd7982  push rax
00007fa9d6dd7983  push rcx
00007fa9d6dd7984  push rdx
00007fa9d6dd7985  push rdi
00007fa9d6dd7986  push rsi
00007fa9d6dd7987  push r8
00007fa9d6dd7989  push r9
00007fa9d6dd798b  push r10
00007fa9d6dd798d  push r11
00007fa9d6dd798f  sub rsp, 0xF0
00007fa9d6dd7996  vmovaps [rsp], xmm0
00007fa9d6dd799b  vmovaps [rsp+0x10], xmm1
00007fa9d6dd79a1  vmovaps [rsp+0x20], xmm2
00007fa9d6dd79a7  vmovaps [rsp+0x30], xmm4
00007fa9d6dd79ad  vmovaps [rsp+0x40], xmm5
00007fa9d6dd79b3  vmovaps [rsp+0x50], xmm6
00007fa9d6dd79b9  vmovaps [rsp+0x60], xmm7
00007fa9d6dd79bf  vmovaps [rsp+0x70], xmm8
00007fa9d6dd79c5  vmovaps [rsp+0x80], xmm9
00007fa9d6dd79ce  vmovaps [rsp+0x90], xmm10
00007fa9d6dd79d7  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd79e0  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd79e9  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd79f2  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd79fb  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd7a04  sub rsp, 0x30
00007fa9d6dd7a08  movaps [rsp], xmm3
00007fa9d6dd7a0c  movaps [rsp+0x10], xmm1
00007fa9d6dd7a11  movaps [rsp+0x20], xmm9
00007fa9d6dd7a17  lea rdi, [rsp]
00007fa9d6dd7a1b  mov esi, 0x00
00007fa9d6dd7a20  mov rax, 0x61DF872DB530
00007fa9d6dd7a2a  call rax
00007fa9d6dd7a2c  movaps xmm3, [rsp]
00007fa9d6dd7a30  add rsp, 0x30
00007fa9d6dd7a34  vmovaps xmm0, [rsp]
00007fa9d6dd7a39  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd7a3f  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd7a45  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd7a4b  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd7a51  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd7a57  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd7a5d  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd7a63  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7a6c  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd7a75  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd7a7e  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd7a87  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd7a90  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd7a99  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7aa2  add rsp, 0xF0
00007fa9d6dd7aa9  pop r11
00007fa9d6dd7aab  pop r10
00007fa9d6dd7aad  pop r9
00007fa9d6dd7aaf  pop r8
00007fa9d6dd7ab1  pop rsi
00007fa9d6dd7ab2  pop rdi
00007fa9d6dd7ab3  pop rdx
00007fa9d6dd7ab4  pop rcx
00007fa9d6dd7ab5  pop rax
00007fa9d6dd7ab6  add rsp, 0x08
00007fa9d6dd7aba  jmp 0x00007FA9D6DD5D43
00007fa9d6dd7abf  sub rsp, 0x08
00007fa9d6dd7ac3  push rax
00007fa9d6dd7ac4  push rcx
00007fa9d6dd7ac5  push rdx
00007fa9d6dd7ac6  push rdi
00007fa9d6dd7ac7  push rsi
00007fa9d6dd7ac8  push r8
00007fa9d6dd7aca  push r9
00007fa9d6dd7acc  push r10
00007fa9d6dd7ace  push r11
00007fa9d6dd7ad0  sub rsp, 0xF0
00007fa9d6dd7ad7  vmovaps [rsp], xmm0
00007fa9d6dd7adc  vmovaps [rsp+0x10], xmm2
00007fa9d6dd7ae2  vmovaps [rsp+0x20], xmm3
00007fa9d6dd7ae8  vmovaps [rsp+0x30], xmm4
00007fa9d6dd7aee  vmovaps [rsp+0x40], xmm5
00007fa9d6dd7af4  vmovaps [rsp+0x50], xmm6
00007fa9d6dd7afa  vmovaps [rsp+0x60], xmm7
00007fa9d6dd7b00  vmovaps [rsp+0x70], xmm8
00007fa9d6dd7b06  vmovaps [rsp+0x80], xmm9
00007fa9d6dd7b0f  vmovaps [rsp+0x90], xmm10
00007fa9d6dd7b18  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd7b21  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd7b2a  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd7b33  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd7b3c  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd7b45  sub rsp, 0x30
00007fa9d6dd7b49  movaps [rsp], xmm1
00007fa9d6dd7b4d  movaps [rsp+0x10], xmm15
00007fa9d6dd7b53  movaps [rsp+0x20], xmm9
00007fa9d6dd7b59  lea rdi, [rsp]
00007fa9d6dd7b5d  mov esi, 0x00
00007fa9d6dd7b62  mov rax, 0x61DF872DB530
00007fa9d6dd7b6c  call rax
00007fa9d6dd7b6e  movaps xmm1, [rsp]
00007fa9d6dd7b72  add rsp, 0x30
00007fa9d6dd7b76  vmovaps xmm0, [rsp]
00007fa9d6dd7b7b  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd7b81  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd7b87  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd7b8d  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd7b93  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd7b99  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd7b9f  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd7ba5  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7bae  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd7bb7  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd7bc0  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd7bc9  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd7bd2  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd7bdb  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7be4  add rsp, 0xF0
00007fa9d6dd7beb  pop r11
00007fa9d6dd7bed  pop r10
00007fa9d6dd7bef  pop r9
00007fa9d6dd7bf1  pop r8
00007fa9d6dd7bf3  pop rsi
00007fa9d6dd7bf4  pop rdi
00007fa9d6dd7bf5  pop rdx
00007fa9d6dd7bf6  pop rcx
00007fa9d6dd7bf7  pop rax
00007fa9d6dd7bf8  add rsp, 0x08
00007fa9d6dd7bfc  jmp 0x00007FA9D6DD5DCB
00007fa9d6dd7c01  call 0x00007FA9D6CE5820
00007fa9d6dd7c06  jmp 0x00007FA9D6DD5DD8
00007fa9d6dd7c0b  sub rsp, 0x08
00007fa9d6dd7c0f  push rax
00007fa9d6dd7c10  push rcx
00007fa9d6dd7c11  push rdx
00007fa9d6dd7c12  push rdi
00007fa9d6dd7c13  push rsi
00007fa9d6dd7c14  push r8
00007fa9d6dd7c16  push r9
00007fa9d6dd7c18  push r10
00007fa9d6dd7c1a  push r11
00007fa9d6dd7c1c  sub rsp, 0xF0
00007fa9d6dd7c23  vmovaps [rsp], xmm0
00007fa9d6dd7c28  vmovaps [rsp+0x10], xmm2
00007fa9d6dd7c2e  vmovaps [rsp+0x20], xmm3
00007fa9d6dd7c34  vmovaps [rsp+0x30], xmm4
00007fa9d6dd7c3a  vmovaps [rsp+0x40], xmm5
00007fa9d6dd7c40  vmovaps [rsp+0x50], xmm6
00007fa9d6dd7c46  vmovaps [rsp+0x60], xmm7
00007fa9d6dd7c4c  vmovaps [rsp+0x70], xmm8
00007fa9d6dd7c52  vmovaps [rsp+0x80], xmm9
00007fa9d6dd7c5b  vmovaps [rsp+0x90], xmm10
00007fa9d6dd7c64  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd7c6d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd7c76  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd7c7f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd7c88  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd7c91  sub rsp, 0x30
00007fa9d6dd7c95  movaps [rsp], xmm1
00007fa9d6dd7c99  movaps [rsp+0x10], xmm5
00007fa9d6dd7c9e  movaps [rsp+0x20], xmm7
00007fa9d6dd7ca3  lea rdi, [rsp]
00007fa9d6dd7ca7  mov esi, 0x00
00007fa9d6dd7cac  mov rax, 0x61DF872DB530
00007fa9d6dd7cb6  call rax
00007fa9d6dd7cb8  movaps xmm1, [rsp]
00007fa9d6dd7cbc  add rsp, 0x30
00007fa9d6dd7cc0  vmovaps xmm0, [rsp]
00007fa9d6dd7cc5  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd7ccb  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd7cd1  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd7cd7  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd7cdd  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd7ce3  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd7ce9  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd7cef  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7cf8  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd7d01  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd7d0a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd7d13  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd7d1c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd7d25  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7d2e  add rsp, 0xF0
00007fa9d6dd7d35  pop r11
00007fa9d6dd7d37  pop r10
00007fa9d6dd7d39  pop r9
00007fa9d6dd7d3b  pop r8
00007fa9d6dd7d3d  pop rsi
00007fa9d6dd7d3e  pop rdi
00007fa9d6dd7d3f  pop rdx
00007fa9d6dd7d40  pop rcx
00007fa9d6dd7d41  pop rax
00007fa9d6dd7d42  add rsp, 0x08
00007fa9d6dd7d46  jmp 0x00007FA9D6DD5E7D
00007fa9d6dd7d4b  sub rsp, 0x08
00007fa9d6dd7d4f  push rax
00007fa9d6dd7d50  push rcx
00007fa9d6dd7d51  push rdx
00007fa9d6dd7d52  push rdi
00007fa9d6dd7d53  push rsi
00007fa9d6dd7d54  push r8
00007fa9d6dd7d56  push r9
00007fa9d6dd7d58  push r10
00007fa9d6dd7d5a  push r11
00007fa9d6dd7d5c  sub rsp, 0xF0
00007fa9d6dd7d63  vmovaps [rsp], xmm0
00007fa9d6dd7d68  vmovaps [rsp+0x10], xmm1
00007fa9d6dd7d6e  vmovaps [rsp+0x20], xmm2
00007fa9d6dd7d74  vmovaps [rsp+0x30], xmm3
00007fa9d6dd7d7a  vmovaps [rsp+0x40], xmm4
00007fa9d6dd7d80  vmovaps [rsp+0x50], xmm5
00007fa9d6dd7d86  vmovaps [rsp+0x60], xmm6
00007fa9d6dd7d8c  vmovaps [rsp+0x70], xmm8
00007fa9d6dd7d92  vmovaps [rsp+0x80], xmm9
00007fa9d6dd7d9b  vmovaps [rsp+0x90], xmm10
00007fa9d6dd7da4  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd7dad  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd7db6  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd7dbf  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd7dc8  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd7dd1  sub rsp, 0x30
00007fa9d6dd7dd5  movaps [rsp], xmm7
00007fa9d6dd7dd9  movaps [rsp+0x10], xmm5
00007fa9d6dd7dde  movaps [rsp+0x20], xmm15
00007fa9d6dd7de4  lea rdi, [rsp]
00007fa9d6dd7de8  mov esi, 0x00
00007fa9d6dd7ded  mov rax, 0x61DF872DB530
00007fa9d6dd7df7  call rax
00007fa9d6dd7df9  movaps xmm7, [rsp]
00007fa9d6dd7dfd  add rsp, 0x30
00007fa9d6dd7e01  vmovaps xmm0, [rsp]
00007fa9d6dd7e06  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd7e0c  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd7e12  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd7e18  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd7e1e  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd7e24  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd7e2a  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd7e30  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd7e39  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd7e42  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd7e4b  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd7e54  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd7e5d  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd7e66  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd7e6f  add rsp, 0xF0
00007fa9d6dd7e76  pop r11
00007fa9d6dd7e78  pop r10
00007fa9d6dd7e7a  pop r9
00007fa9d6dd7e7c  pop r8
00007fa9d6dd7e7e  pop rsi
00007fa9d6dd7e7f  pop rdi
00007fa9d6dd7e80  pop rdx
00007fa9d6dd7e81  pop rcx
00007fa9d6dd7e82  pop rax
00007fa9d6dd7e83  add rsp, 0x08
00007fa9d6dd7e87  jmp 0x00007FA9D6DD5EB3
00007fa9d6dd7e8c  call 0x00007FA9D6CD64F0
00007fa9d6dd7e91  jmp 0x00007FA9D6DD5EC0
00007fa9d6dd7e96  sub rsp, 0x08
00007fa9d6dd7e9a  push rax
00007fa9d6dd7e9b  push rcx
00007fa9d6dd7e9c  push rdx
00007fa9d6dd7e9d  push rdi
00007fa9d6dd7e9e  push rsi
00007fa9d6dd7e9f  push r8
00007fa9d6dd7ea1  push r9
00007fa9d6dd7ea3  push r10
00007fa9d6dd7ea5  push r11
00007fa9d6dd7ea7  sub rsp, 0xF0
00007fa9d6dd7eae  vmovaps [rsp], xmm0
00007fa9d6dd7eb3  vmovaps [rsp+0x10], xmm1
00007fa9d6dd7eb9  vmovaps [rsp+0x20], xmm2
00007fa9d6dd7ebf  vmovaps [rsp+0x30], xmm3
00007fa9d6dd7ec5  vmovaps [rsp+0x40], xmm4
00007fa9d6dd7ecb  vmovaps [rsp+0x50], xmm5
00007fa9d6dd7ed1  vmovaps [rsp+0x60], xmm6
00007fa9d6dd7ed7  vmovaps [rsp+0x70], xmm7
00007fa9d6dd7edd  vmovaps [rsp+0x80], xmm8
00007fa9d6dd7ee6  vmovaps [rsp+0x90], xmm9
00007fa9d6dd7eef  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd7ef8  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd7f01  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd7f0a  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd7f13  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd7f1c  sub rsp, 0x30
00007fa9d6dd7f20  movaps [rsp], xmm15
00007fa9d6dd7f25  movaps [rsp+0x10], xmm5
00007fa9d6dd7f2a  movaps [rsp+0x20], xmm3
00007fa9d6dd7f2f  lea rdi, [rsp]
00007fa9d6dd7f33  mov esi, 0x00
00007fa9d6dd7f38  mov rax, 0x61DF872DB530
00007fa9d6dd7f42  call rax
00007fa9d6dd7f44  movaps xmm15, [rsp]
00007fa9d6dd7f49  add rsp, 0x30
00007fa9d6dd7f4d  vmovaps xmm0, [rsp]
00007fa9d6dd7f52  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd7f58  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd7f5e  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd7f64  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd7f6a  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd7f70  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd7f76  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd7f7c  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd7f85  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd7f8e  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd7f97  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd7fa0  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd7fa9  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd7fb2  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd7fbb  add rsp, 0xF0
00007fa9d6dd7fc2  pop r11
00007fa9d6dd7fc4  pop r10
00007fa9d6dd7fc6  pop r9
00007fa9d6dd7fc8  pop r8
00007fa9d6dd7fca  pop rsi
00007fa9d6dd7fcb  pop rdi
00007fa9d6dd7fcc  pop rdx
00007fa9d6dd7fcd  pop rcx
00007fa9d6dd7fce  pop rax
00007fa9d6dd7fcf  add rsp, 0x08
00007fa9d6dd7fd3  jmp 0x00007FA9D6DD5EE6
00007fa9d6dd7fd8  sub rsp, 0x08
00007fa9d6dd7fdc  push rax
00007fa9d6dd7fdd  push rcx
00007fa9d6dd7fde  push rdx
00007fa9d6dd7fdf  push rdi
00007fa9d6dd7fe0  push rsi
00007fa9d6dd7fe1  push r8
00007fa9d6dd7fe3  push r9
00007fa9d6dd7fe5  push r10
00007fa9d6dd7fe7  push r11
00007fa9d6dd7fe9  sub rsp, 0xF0
00007fa9d6dd7ff0  vmovaps [rsp], xmm0
00007fa9d6dd7ff5  vmovaps [rsp+0x10], xmm2
00007fa9d6dd7ffb  vmovaps [rsp+0x20], xmm3
00007fa9d6dd8001  vmovaps [rsp+0x30], xmm4
00007fa9d6dd8007  vmovaps [rsp+0x40], xmm5
00007fa9d6dd800d  vmovaps [rsp+0x50], xmm6
00007fa9d6dd8013  vmovaps [rsp+0x60], xmm7
00007fa9d6dd8019  vmovaps [rsp+0x70], xmm8
00007fa9d6dd801f  vmovaps [rsp+0x80], xmm9
00007fa9d6dd8028  vmovaps [rsp+0x90], xmm10
00007fa9d6dd8031  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd803a  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd8043  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd804c  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd8055  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd805e  sub rsp, 0x30
00007fa9d6dd8062  movaps [rsp], xmm1
00007fa9d6dd8066  movaps [rsp+0x10], xmm5
00007fa9d6dd806b  movaps [rsp+0x20], xmm4
00007fa9d6dd8070  lea rdi, [rsp]
00007fa9d6dd8074  mov esi, 0x00
00007fa9d6dd8079  mov rax, 0x61DF872DB530
00007fa9d6dd8083  call rax
00007fa9d6dd8085  movaps xmm1, [rsp]
00007fa9d6dd8089  add rsp, 0x30
00007fa9d6dd808d  vmovaps xmm0, [rsp]
00007fa9d6dd8092  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd8098  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd809e  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd80a4  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd80aa  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd80b0  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd80b6  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd80bc  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd80c5  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd80ce  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd80d7  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd80e0  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd80e9  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd80f2  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd80fb  add rsp, 0xF0
00007fa9d6dd8102  pop r11
00007fa9d6dd8104  pop r10
00007fa9d6dd8106  pop r9
00007fa9d6dd8108  pop r8
00007fa9d6dd810a  pop rsi
00007fa9d6dd810b  pop rdi
00007fa9d6dd810c  pop rdx
00007fa9d6dd810d  pop rcx
00007fa9d6dd810e  pop rax
00007fa9d6dd810f  add rsp, 0x08
00007fa9d6dd8113  jmp 0x00007FA9D6DD5F06
00007fa9d6dd8118  sub rsp, 0x08
00007fa9d6dd811c  push rax
00007fa9d6dd811d  push rcx
00007fa9d6dd811e  push rdx
00007fa9d6dd811f  push rdi
00007fa9d6dd8120  push rsi
00007fa9d6dd8121  push r8
00007fa9d6dd8123  push r9
00007fa9d6dd8125  push r10
00007fa9d6dd8127  push r11
00007fa9d6dd8129  sub rsp, 0xF0
00007fa9d6dd8130  vmovaps [rsp], xmm0
00007fa9d6dd8135  vmovaps [rsp+0x10], xmm1
00007fa9d6dd813b  vmovaps [rsp+0x20], xmm2
00007fa9d6dd8141  vmovaps [rsp+0x30], xmm3
00007fa9d6dd8147  vmovaps [rsp+0x40], xmm5
00007fa9d6dd814d  vmovaps [rsp+0x50], xmm6
00007fa9d6dd8153  vmovaps [rsp+0x60], xmm7
00007fa9d6dd8159  vmovaps [rsp+0x70], xmm8
00007fa9d6dd815f  vmovaps [rsp+0x80], xmm9
00007fa9d6dd8168  vmovaps [rsp+0x90], xmm10
00007fa9d6dd8171  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd817a  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd8183  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd818c  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd8195  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd819e  sub rsp, 0x30
00007fa9d6dd81a2  movaps [rsp], xmm4
00007fa9d6dd81a6  movaps [rsp+0x10], xmm3
00007fa9d6dd81ab  movaps [rsp+0x20], xmm5
00007fa9d6dd81b0  lea rdi, [rsp]
00007fa9d6dd81b4  mov esi, 0x00
00007fa9d6dd81b9  mov rax, 0x61DF872DB530
00007fa9d6dd81c3  call rax
00007fa9d6dd81c5  movaps xmm4, [rsp]
00007fa9d6dd81c9  add rsp, 0x30
00007fa9d6dd81cd  vmovaps xmm0, [rsp]
00007fa9d6dd81d2  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd81d8  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd81de  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd81e4  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd81ea  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd81f0  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd81f6  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd81fc  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd8205  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd820e  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd8217  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd8220  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd8229  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd8232  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd823b  add rsp, 0xF0
00007fa9d6dd8242  pop r11
00007fa9d6dd8244  pop r10
00007fa9d6dd8246  pop r9
00007fa9d6dd8248  pop r8
00007fa9d6dd824a  pop rsi
00007fa9d6dd824b  pop rdi
00007fa9d6dd824c  pop rdx
00007fa9d6dd824d  pop rcx
00007fa9d6dd824e  pop rax
00007fa9d6dd824f  add rsp, 0x08
00007fa9d6dd8253  jmp 0x00007FA9D6DD5F54
00007fa9d6dd8258  call 0x00007FA9D6CD64F0
00007fa9d6dd825d  jmp 0x00007FA9D6DD5F61
00007fa9d6dd8262  sub rsp, 0x08
00007fa9d6dd8266  push rax
00007fa9d6dd8267  push rcx
00007fa9d6dd8268  push rdx
00007fa9d6dd8269  push rdi
00007fa9d6dd826a  push rsi
00007fa9d6dd826b  push r8
00007fa9d6dd826d  push r9
00007fa9d6dd826f  push r10
00007fa9d6dd8271  push r11
00007fa9d6dd8273  sub rsp, 0xF0
00007fa9d6dd827a  vmovaps [rsp], xmm0
00007fa9d6dd827f  vmovaps [rsp+0x10], xmm1
00007fa9d6dd8285  vmovaps [rsp+0x20], xmm2
00007fa9d6dd828b  vmovaps [rsp+0x30], xmm3
00007fa9d6dd8291  vmovaps [rsp+0x40], xmm4
00007fa9d6dd8297  vmovaps [rsp+0x50], xmm6
00007fa9d6dd829d  vmovaps [rsp+0x60], xmm7
00007fa9d6dd82a3  vmovaps [rsp+0x70], xmm8
00007fa9d6dd82a9  vmovaps [rsp+0x80], xmm9
00007fa9d6dd82b2  vmovaps [rsp+0x90], xmm10
00007fa9d6dd82bb  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd82c4  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd82cd  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd82d6  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd82df  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd82e8  sub rsp, 0x30
00007fa9d6dd82ec  movaps [rsp], xmm5
00007fa9d6dd82f0  movaps [rsp+0x10], xmm6
00007fa9d6dd82f5  movaps [rsp+0x20], xmm3
00007fa9d6dd82fa  lea rdi, [rsp]
00007fa9d6dd82fe  mov esi, 0x00
00007fa9d6dd8303  mov rax, 0x61DF872DB530
00007fa9d6dd830d  call rax
00007fa9d6dd830f  movaps xmm5, [rsp]
00007fa9d6dd8313  add rsp, 0x30
00007fa9d6dd8317  vmovaps xmm0, [rsp]
00007fa9d6dd831c  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd8322  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd8328  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd832e  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd8334  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd833a  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd8340  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd8346  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd834f  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd8358  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd8361  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd836a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd8373  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd837c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd8385  add rsp, 0xF0
00007fa9d6dd838c  pop r11
00007fa9d6dd838e  pop r10
00007fa9d6dd8390  pop r9
00007fa9d6dd8392  pop r8
00007fa9d6dd8394  pop rsi
00007fa9d6dd8395  pop rdi
00007fa9d6dd8396  pop rdx
00007fa9d6dd8397  pop rcx
00007fa9d6dd8398  pop rax
00007fa9d6dd8399  add rsp, 0x08
00007fa9d6dd839d  jmp 0x00007FA9D6DD5F87
00007fa9d6dd83a2  sub rsp, 0x08
00007fa9d6dd83a6  push rax
00007fa9d6dd83a7  push rcx
00007fa9d6dd83a8  push rdx
00007fa9d6dd83a9  push rdi
00007fa9d6dd83aa  push rsi
00007fa9d6dd83ab  push r8
00007fa9d6dd83ad  push r9
00007fa9d6dd83af  push r10
00007fa9d6dd83b1  push r11
00007fa9d6dd83b3  sub rsp, 0xF0
00007fa9d6dd83ba  vmovaps [rsp], xmm0
00007fa9d6dd83bf  vmovaps [rsp+0x10], xmm1
00007fa9d6dd83c5  vmovaps [rsp+0x20], xmm2
00007fa9d6dd83cb  vmovaps [rsp+0x30], xmm3
00007fa9d6dd83d1  vmovaps [rsp+0x40], xmm4
00007fa9d6dd83d7  vmovaps [rsp+0x50], xmm5
00007fa9d6dd83dd  vmovaps [rsp+0x60], xmm7
00007fa9d6dd83e3  vmovaps [rsp+0x70], xmm8
00007fa9d6dd83e9  vmovaps [rsp+0x80], xmm9
00007fa9d6dd83f2  vmovaps [rsp+0x90], xmm10
00007fa9d6dd83fb  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd8404  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd840d  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd8416  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd841f  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd8428  sub rsp, 0x30
00007fa9d6dd842c  movaps [rsp], xmm6
00007fa9d6dd8430  movaps [rsp+0x10], xmm9
00007fa9d6dd8436  movaps [rsp+0x20], xmm1
00007fa9d6dd843b  lea rdi, [rsp]
00007fa9d6dd843f  mov esi, 0x00
00007fa9d6dd8444  mov rax, 0x61DF872DB530
00007fa9d6dd844e  call rax
00007fa9d6dd8450  movaps xmm6, [rsp]
00007fa9d6dd8454  add rsp, 0x30
00007fa9d6dd8458  vmovaps xmm0, [rsp]
00007fa9d6dd845d  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd8463  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd8469  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd846f  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd8475  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd847b  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd8481  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd8487  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd8490  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd8499  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd84a2  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd84ab  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd84b4  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd84bd  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd84c6  add rsp, 0xF0
00007fa9d6dd84cd  pop r11
00007fa9d6dd84cf  pop r10
00007fa9d6dd84d1  pop r9
00007fa9d6dd84d3  pop r8
00007fa9d6dd84d5  pop rsi
00007fa9d6dd84d6  pop rdi
00007fa9d6dd84d7  pop rdx
00007fa9d6dd84d8  pop rcx
00007fa9d6dd84d9  pop rax
00007fa9d6dd84da  add rsp, 0x08
00007fa9d6dd84de  jmp 0x00007FA9D6DD5FAB
00007fa9d6dd84e3  sub rsp, 0x08
00007fa9d6dd84e7  push rax
00007fa9d6dd84e8  push rcx
00007fa9d6dd84e9  push rdx
00007fa9d6dd84ea  push rdi
00007fa9d6dd84eb  push rsi
00007fa9d6dd84ec  push r8
00007fa9d6dd84ee  push r9
00007fa9d6dd84f0  push r10
00007fa9d6dd84f2  push r11
00007fa9d6dd84f4  sub rsp, 0xF0
00007fa9d6dd84fb  vmovaps [rsp], xmm0
00007fa9d6dd8500  vmovaps [rsp+0x10], xmm1
00007fa9d6dd8506  vmovaps [rsp+0x20], xmm2
00007fa9d6dd850c  vmovaps [rsp+0x30], xmm3
00007fa9d6dd8512  vmovaps [rsp+0x40], xmm4
00007fa9d6dd8518  vmovaps [rsp+0x50], xmm5
00007fa9d6dd851e  vmovaps [rsp+0x60], xmm6
00007fa9d6dd8524  vmovaps [rsp+0x70], xmm7
00007fa9d6dd852a  vmovaps [rsp+0x80], xmm8
00007fa9d6dd8533  vmovaps [rsp+0x90], xmm10
00007fa9d6dd853c  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd8545  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd854e  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd8557  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd8560  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd8569  sub rsp, 0x30
00007fa9d6dd856d  movaps [rsp], xmm9
00007fa9d6dd8572  movaps [rsp+0x10], xmm3
00007fa9d6dd8577  movaps [rsp+0x20], xmm1
00007fa9d6dd857c  lea rdi, [rsp]
00007fa9d6dd8580  mov esi, 0x00
00007fa9d6dd8585  mov rax, 0x61DF872DB530
00007fa9d6dd858f  call rax
00007fa9d6dd8591  movaps xmm9, [rsp]
00007fa9d6dd8596  add rsp, 0x30
00007fa9d6dd859a  vmovaps xmm0, [rsp]
00007fa9d6dd859f  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd85a5  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd85ab  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd85b1  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd85b7  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd85bd  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd85c3  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd85c9  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd85d2  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd85db  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd85e4  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd85ed  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd85f6  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd85ff  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd8608  add rsp, 0xF0
00007fa9d6dd860f  pop r11
00007fa9d6dd8611  pop r10
00007fa9d6dd8613  pop r9
00007fa9d6dd8615  pop r8
00007fa9d6dd8617  pop rsi
00007fa9d6dd8618  pop rdi
00007fa9d6dd8619  pop rdx
00007fa9d6dd861a  pop rcx
00007fa9d6dd861b  pop rax
00007fa9d6dd861c  add rsp, 0x08
00007fa9d6dd8620  jmp 0x00007FA9D6DD5FF7
00007fa9d6dd8625  call 0x00007FA9D6CD64F0
00007fa9d6dd862a  jmp 0x00007FA9D6DD6004
00007fa9d6dd862f  sub rsp, 0x08
00007fa9d6dd8633  push rax
00007fa9d6dd8634  push rcx
00007fa9d6dd8635  push rdx
00007fa9d6dd8636  push rdi
00007fa9d6dd8637  push rsi
00007fa9d6dd8638  push r8
00007fa9d6dd863a  push r9
00007fa9d6dd863c  push r10
00007fa9d6dd863e  push r11
00007fa9d6dd8640  sub rsp, 0xF0
00007fa9d6dd8647  vmovaps [rsp], xmm0
00007fa9d6dd864c  vmovaps [rsp+0x10], xmm1
00007fa9d6dd8652  vmovaps [rsp+0x20], xmm2
00007fa9d6dd8658  vmovaps [rsp+0x30], xmm3
00007fa9d6dd865e  vmovaps [rsp+0x40], xmm4
00007fa9d6dd8664  vmovaps [rsp+0x50], xmm5
00007fa9d6dd866a  vmovaps [rsp+0x60], xmm6
00007fa9d6dd8670  vmovaps [rsp+0x70], xmm7
00007fa9d6dd8676  vmovaps [rsp+0x80], xmm8
00007fa9d6dd867f  vmovaps [rsp+0x90], xmm9
00007fa9d6dd8688  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd8691  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd869a  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd86a3  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd86ac  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd86b5  sub rsp, 0x30
00007fa9d6dd86b9  movaps [rsp], xmm15
00007fa9d6dd86be  movaps [rsp+0x10], xmm3
00007fa9d6dd86c3  movaps [rsp+0x20], xmm7
00007fa9d6dd86c8  lea rdi, [rsp]
00007fa9d6dd86cc  mov esi, 0x00
00007fa9d6dd86d1  mov rax, 0x61DF872DB530
00007fa9d6dd86db  call rax
00007fa9d6dd86dd  movaps xmm15, [rsp]
00007fa9d6dd86e2  add rsp, 0x30
00007fa9d6dd86e6  vmovaps xmm0, [rsp]
00007fa9d6dd86eb  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd86f1  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd86f7  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd86fd  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd8703  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd8709  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd870f  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd8715  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd871e  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd8727  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd8730  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd8739  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd8742  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd874b  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd8754  add rsp, 0xF0
00007fa9d6dd875b  pop r11
00007fa9d6dd875d  pop r10
00007fa9d6dd875f  pop r9
00007fa9d6dd8761  pop r8
00007fa9d6dd8763  pop rsi
00007fa9d6dd8764  pop rdi
00007fa9d6dd8765  pop rdx
00007fa9d6dd8766  pop rcx
00007fa9d6dd8767  pop rax
00007fa9d6dd8768  add rsp, 0x08
00007fa9d6dd876c  jmp 0x00007FA9D6DD6030
00007fa9d6dd8771  sub rsp, 0x08
00007fa9d6dd8775  push rax
00007fa9d6dd8776  push rcx
00007fa9d6dd8777  push rdx
00007fa9d6dd8778  push rdi
00007fa9d6dd8779  push rsi
00007fa9d6dd877a  push r8
00007fa9d6dd877c  push r9
00007fa9d6dd877e  push r10
00007fa9d6dd8780  push r11
00007fa9d6dd8782  sub rsp, 0xF0
00007fa9d6dd8789  vmovaps [rsp], xmm0
00007fa9d6dd878e  vmovaps [rsp+0x10], xmm1
00007fa9d6dd8794  vmovaps [rsp+0x20], xmm2
00007fa9d6dd879a  vmovaps [rsp+0x30], xmm4
00007fa9d6dd87a0  vmovaps [rsp+0x40], xmm5
00007fa9d6dd87a6  vmovaps [rsp+0x50], xmm6
00007fa9d6dd87ac  vmovaps [rsp+0x60], xmm7
00007fa9d6dd87b2  vmovaps [rsp+0x70], xmm8
00007fa9d6dd87b8  vmovaps [rsp+0x80], xmm9
00007fa9d6dd87c1  vmovaps [rsp+0x90], xmm10
00007fa9d6dd87ca  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd87d3  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd87dc  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd87e5  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd87ee  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd87f7  sub rsp, 0x30
00007fa9d6dd87fb  movaps [rsp], xmm3
00007fa9d6dd87ff  movaps [rsp+0x10], xmm1
00007fa9d6dd8804  movaps [rsp+0x20], xmm15
00007fa9d6dd880a  lea rdi, [rsp]
00007fa9d6dd880e  mov esi, 0x00
00007fa9d6dd8813  mov rax, 0x61DF872DB530
00007fa9d6dd881d  call rax
00007fa9d6dd881f  movaps xmm3, [rsp]
00007fa9d6dd8823  add rsp, 0x30
00007fa9d6dd8827  vmovaps xmm0, [rsp]
00007fa9d6dd882c  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd8832  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd8838  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd883e  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd8844  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd884a  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd8850  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd8856  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd885f  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd8868  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd8871  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd887a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd8883  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd888c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd8895  add rsp, 0xF0
00007fa9d6dd889c  pop r11
00007fa9d6dd889e  pop r10
00007fa9d6dd88a0  pop r9
00007fa9d6dd88a2  pop r8
00007fa9d6dd88a4  pop rsi
00007fa9d6dd88a5  pop rdi
00007fa9d6dd88a6  pop rdx
00007fa9d6dd88a7  pop rcx
00007fa9d6dd88a8  pop rax
00007fa9d6dd88a9  add rsp, 0x08
00007fa9d6dd88ad  jmp 0x00007FA9D6DD60BF
00007fa9d6dd88b2  call 0x00007FA9D6CD64F0
00007fa9d6dd88b7  jmp 0x00007FA9D6DD60C9
00007fa9d6dd88bc  sub rsp, 0x08
00007fa9d6dd88c0  push rax
00007fa9d6dd88c1  push rcx
00007fa9d6dd88c2  push rdx
00007fa9d6dd88c3  push rdi
00007fa9d6dd88c4  push rsi
00007fa9d6dd88c5  push r8
00007fa9d6dd88c7  push r9
00007fa9d6dd88c9  push r10
00007fa9d6dd88cb  push r11
00007fa9d6dd88cd  sub rsp, 0xF0
00007fa9d6dd88d4  vmovaps [rsp], xmm0
00007fa9d6dd88d9  vmovaps [rsp+0x10], xmm1
00007fa9d6dd88df  vmovaps [rsp+0x20], xmm2
00007fa9d6dd88e5  vmovaps [rsp+0x30], xmm3
00007fa9d6dd88eb  vmovaps [rsp+0x40], xmm4
00007fa9d6dd88f1  vmovaps [rsp+0x50], xmm5
00007fa9d6dd88f7  vmovaps [rsp+0x60], xmm6
00007fa9d6dd88fd  vmovaps [rsp+0x70], xmm7
00007fa9d6dd8903  vmovaps [rsp+0x80], xmm8
00007fa9d6dd890c  vmovaps [rsp+0x90], xmm9
00007fa9d6dd8915  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd891e  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd8927  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd8930  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd8939  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd8942  sub rsp, 0x30
00007fa9d6dd8946  movaps [rsp], xmm15
00007fa9d6dd894b  movaps [rsp+0x10], xmm14
00007fa9d6dd8951  movaps [rsp+0x20], xmm4
00007fa9d6dd8956  lea rdi, [rsp]
00007fa9d6dd895a  mov esi, 0x00
00007fa9d6dd895f  mov rax, 0x61DF872DB530
00007fa9d6dd8969  call rax
00007fa9d6dd896b  movaps xmm15, [rsp]
00007fa9d6dd8970  add rsp, 0x30
00007fa9d6dd8974  vmovaps xmm0, [rsp]
00007fa9d6dd8979  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd897f  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd8985  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd898b  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd8991  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd8997  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd899d  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd89a3  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd89ac  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd89b5  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd89be  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd89c7  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd89d0  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd89d9  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd89e2  add rsp, 0xF0
00007fa9d6dd89e9  pop r11
00007fa9d6dd89eb  pop r10
00007fa9d6dd89ed  pop r9
00007fa9d6dd89ef  pop r8
00007fa9d6dd89f1  pop rsi
00007fa9d6dd89f2  pop rdi
00007fa9d6dd89f3  pop rdx
00007fa9d6dd89f4  pop rcx
00007fa9d6dd89f5  pop rax
00007fa9d6dd89f6  add rsp, 0x08
00007fa9d6dd89fa  jmp 0x00007FA9D6DD60F7
00007fa9d6dd89ff  sub rsp, 0x08
00007fa9d6dd8a03  push rax
00007fa9d6dd8a04  push rcx
00007fa9d6dd8a05  push rdx
00007fa9d6dd8a06  push rdi
00007fa9d6dd8a07  push rsi
00007fa9d6dd8a08  push r8
00007fa9d6dd8a0a  push r9
00007fa9d6dd8a0c  push r10
00007fa9d6dd8a0e  push r11
00007fa9d6dd8a10  sub rsp, 0xF0
00007fa9d6dd8a17  vmovaps [rsp], xmm0
00007fa9d6dd8a1c  vmovaps [rsp+0x10], xmm1
00007fa9d6dd8a22  vmovaps [rsp+0x20], xmm2
00007fa9d6dd8a28  vmovaps [rsp+0x30], xmm3
00007fa9d6dd8a2e  vmovaps [rsp+0x40], xmm4
00007fa9d6dd8a34  vmovaps [rsp+0x50], xmm5
00007fa9d6dd8a3a  vmovaps [rsp+0x60], xmm6
00007fa9d6dd8a40  vmovaps [rsp+0x70], xmm7
00007fa9d6dd8a46  vmovaps [rsp+0x80], xmm8
00007fa9d6dd8a4f  vmovaps [rsp+0x90], xmm9
00007fa9d6dd8a58  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd8a61  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd8a6a  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd8a73  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd8a7c  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd8a85  sub rsp, 0x30
00007fa9d6dd8a89  movaps [rsp], xmm14
00007fa9d6dd8a8e  movaps [rsp+0x10], xmm2
00007fa9d6dd8a93  movaps [rsp+0x20], xmm1
00007fa9d6dd8a98  lea rdi, [rsp]
00007fa9d6dd8a9c  mov esi, 0x00
00007fa9d6dd8aa1  mov rax, 0x61DF872DB530
00007fa9d6dd8aab  call rax
00007fa9d6dd8aad  movaps xmm14, [rsp]
00007fa9d6dd8ab2  add rsp, 0x30
00007fa9d6dd8ab6  vmovaps xmm0, [rsp]
00007fa9d6dd8abb  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd8ac1  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd8ac7  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd8acd  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd8ad3  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd8ad9  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd8adf  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd8ae5  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd8aee  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd8af7  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd8b00  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd8b09  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd8b12  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd8b1b  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd8b24  add rsp, 0xF0
00007fa9d6dd8b2b  pop r11
00007fa9d6dd8b2d  pop r10
00007fa9d6dd8b2f  pop r9
00007fa9d6dd8b31  pop r8
00007fa9d6dd8b33  pop rsi
00007fa9d6dd8b34  pop rdi
00007fa9d6dd8b35  pop rdx
00007fa9d6dd8b36  pop rcx
00007fa9d6dd8b37  pop rax
00007fa9d6dd8b38  add rsp, 0x08
00007fa9d6dd8b3c  jmp 0x00007FA9D6DD611D
00007fa9d6dd8b41  sub rsp, 0x08
00007fa9d6dd8b45  push rax
00007fa9d6dd8b46  push rcx
00007fa9d6dd8b47  push rdx
00007fa9d6dd8b48  push rdi
00007fa9d6dd8b49  push rsi
00007fa9d6dd8b4a  push r8
00007fa9d6dd8b4c  push r9
00007fa9d6dd8b4e  push r10
00007fa9d6dd8b50  push r11
00007fa9d6dd8b52  sub rsp, 0xF0
00007fa9d6dd8b59  vmovaps [rsp], xmm0
00007fa9d6dd8b5e  vmovaps [rsp+0x10], xmm2
00007fa9d6dd8b64  vmovaps [rsp+0x20], xmm3
00007fa9d6dd8b6a  vmovaps [rsp+0x30], xmm4
00007fa9d6dd8b70  vmovaps [rsp+0x40], xmm5
00007fa9d6dd8b76  vmovaps [rsp+0x50], xmm6
00007fa9d6dd8b7c  vmovaps [rsp+0x60], xmm7
00007fa9d6dd8b82  vmovaps [rsp+0x70], xmm8
00007fa9d6dd8b88  vmovaps [rsp+0x80], xmm9
00007fa9d6dd8b91  vmovaps [rsp+0x90], xmm10
00007fa9d6dd8b9a  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd8ba3  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd8bac  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd8bb5  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd8bbe  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd8bc7  sub rsp, 0x30
00007fa9d6dd8bcb  movaps [rsp], xmm1
00007fa9d6dd8bcf  movaps [rsp+0x10], xmm4
00007fa9d6dd8bd4  movaps [rsp+0x20], xmm9
00007fa9d6dd8bda  lea rdi, [rsp]
00007fa9d6dd8bde  mov esi, 0x00
00007fa9d6dd8be3  mov rax, 0x61DF872DB530
00007fa9d6dd8bed  call rax
00007fa9d6dd8bef  movaps xmm1, [rsp]
00007fa9d6dd8bf3  add rsp, 0x30
00007fa9d6dd8bf7  vmovaps xmm0, [rsp]
00007fa9d6dd8bfc  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd8c02  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd8c08  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd8c0e  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd8c14  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd8c1a  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd8c20  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd8c26  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd8c2f  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd8c38  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd8c41  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd8c4a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd8c53  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd8c5c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd8c65  add rsp, 0xF0
00007fa9d6dd8c6c  pop r11
00007fa9d6dd8c6e  pop r10
00007fa9d6dd8c70  pop r9
00007fa9d6dd8c72  pop r8
00007fa9d6dd8c74  pop rsi
00007fa9d6dd8c75  pop rdi
00007fa9d6dd8c76  pop rdx
00007fa9d6dd8c77  pop rcx
00007fa9d6dd8c78  pop rax
00007fa9d6dd8c79  add rsp, 0x08
00007fa9d6dd8c7d  jmp 0x00007FA9D6DD613B
00007fa9d6dd8c82  sub rsp, 0x08
00007fa9d6dd8c86  push rax
00007fa9d6dd8c87  push rcx
00007fa9d6dd8c88  push rdx
00007fa9d6dd8c89  push rdi
00007fa9d6dd8c8a  push rsi
00007fa9d6dd8c8b  push r8
00007fa9d6dd8c8d  push r9
00007fa9d6dd8c8f  push r10
00007fa9d6dd8c91  push r11
00007fa9d6dd8c93  sub rsp, 0xF0
00007fa9d6dd8c9a  vmovaps [rsp], xmm0
00007fa9d6dd8c9f  vmovaps [rsp+0x10], xmm1
00007fa9d6dd8ca5  vmovaps [rsp+0x20], xmm2
00007fa9d6dd8cab  vmovaps [rsp+0x30], xmm3
00007fa9d6dd8cb1  vmovaps [rsp+0x40], xmm5
00007fa9d6dd8cb7  vmovaps [rsp+0x50], xmm6
00007fa9d6dd8cbd  vmovaps [rsp+0x60], xmm7
00007fa9d6dd8cc3  vmovaps [rsp+0x70], xmm8
00007fa9d6dd8cc9  vmovaps [rsp+0x80], xmm9
00007fa9d6dd8cd2  vmovaps [rsp+0x90], xmm10
00007fa9d6dd8cdb  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd8ce4  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd8ced  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd8cf6  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd8cff  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd8d08  sub rsp, 0x30
00007fa9d6dd8d0c  movaps [rsp], xmm4
00007fa9d6dd8d10  movaps [rsp+0x10], xmm2
00007fa9d6dd8d15  movaps [rsp+0x20], xmm9
00007fa9d6dd8d1b  lea rdi, [rsp]
00007fa9d6dd8d1f  mov esi, 0x00
00007fa9d6dd8d24  mov rax, 0x61DF872DB530
00007fa9d6dd8d2e  call rax
00007fa9d6dd8d30  movaps xmm4, [rsp]
00007fa9d6dd8d34  add rsp, 0x30
00007fa9d6dd8d38  vmovaps xmm0, [rsp]
00007fa9d6dd8d3d  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd8d43  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd8d49  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd8d4f  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd8d55  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd8d5b  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd8d61  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd8d67  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd8d70  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd8d79  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd8d82  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd8d8b  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd8d94  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd8d9d  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd8da6  add rsp, 0xF0
00007fa9d6dd8dad  pop r11
00007fa9d6dd8daf  pop r10
00007fa9d6dd8db1  pop r9
00007fa9d6dd8db3  pop r8
00007fa9d6dd8db5  pop rsi
00007fa9d6dd8db6  pop rdi
00007fa9d6dd8db7  pop rdx
00007fa9d6dd8db8  pop rcx
00007fa9d6dd8db9  pop rax
00007fa9d6dd8dba  add rsp, 0x08
00007fa9d6dd8dbe  jmp 0x00007FA9D6DD616B
00007fa9d6dd8dc3  sub rsp, 0x08
00007fa9d6dd8dc7  push rax
00007fa9d6dd8dc8  push rcx
00007fa9d6dd8dc9  push rdx
00007fa9d6dd8dca  push rdi
00007fa9d6dd8dcb  push rsi
00007fa9d6dd8dcc  push r8
00007fa9d6dd8dce  push r9
00007fa9d6dd8dd0  push r10
00007fa9d6dd8dd2  push r11
00007fa9d6dd8dd4  sub rsp, 0xF0
00007fa9d6dd8ddb  vmovaps [rsp], xmm0
00007fa9d6dd8de0  vmovaps [rsp+0x10], xmm1
00007fa9d6dd8de6  vmovaps [rsp+0x20], xmm2
00007fa9d6dd8dec  vmovaps [rsp+0x30], xmm3
00007fa9d6dd8df2  vmovaps [rsp+0x40], xmm4
00007fa9d6dd8df8  vmovaps [rsp+0x50], xmm5
00007fa9d6dd8dfe  vmovaps [rsp+0x60], xmm6
00007fa9d6dd8e04  vmovaps [rsp+0x70], xmm7
00007fa9d6dd8e0a  vmovaps [rsp+0x80], xmm8
00007fa9d6dd8e13  vmovaps [rsp+0x90], xmm10
00007fa9d6dd8e1c  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd8e25  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd8e2e  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd8e37  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd8e40  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd8e49  sub rsp, 0x30
00007fa9d6dd8e4d  movaps [rsp], xmm9
00007fa9d6dd8e52  movaps [rsp+0x10], xmm2
00007fa9d6dd8e57  movaps [rsp+0x20], xmm1
00007fa9d6dd8e5c  lea rdi, [rsp]
00007fa9d6dd8e60  mov esi, 0x00
00007fa9d6dd8e65  mov rax, 0x61DF872DB530
00007fa9d6dd8e6f  call rax
00007fa9d6dd8e71  movaps xmm9, [rsp]
00007fa9d6dd8e76  add rsp, 0x30
00007fa9d6dd8e7a  vmovaps xmm0, [rsp]
00007fa9d6dd8e7f  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd8e85  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd8e8b  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd8e91  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd8e97  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd8e9d  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd8ea3  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd8ea9  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd8eb2  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd8ebb  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd8ec4  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd8ecd  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd8ed6  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd8edf  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd8ee8  add rsp, 0xF0
00007fa9d6dd8eef  pop r11
00007fa9d6dd8ef1  pop r10
00007fa9d6dd8ef3  pop r9
00007fa9d6dd8ef5  pop r8
00007fa9d6dd8ef7  pop rsi
00007fa9d6dd8ef8  pop rdi
00007fa9d6dd8ef9  pop rdx
00007fa9d6dd8efa  pop rcx
00007fa9d6dd8efb  pop rax
00007fa9d6dd8efc  add rsp, 0x08
00007fa9d6dd8f00  jmp 0x00007FA9D6DD61A1
00007fa9d6dd8f05  sub rsp, 0x08
00007fa9d6dd8f09  push rax
00007fa9d6dd8f0a  push rcx
00007fa9d6dd8f0b  push rdx
00007fa9d6dd8f0c  push rdi
00007fa9d6dd8f0d  push rsi
00007fa9d6dd8f0e  push r8
00007fa9d6dd8f10  push r9
00007fa9d6dd8f12  push r10
00007fa9d6dd8f14  push r11
00007fa9d6dd8f16  sub rsp, 0xF0
00007fa9d6dd8f1d  vmovaps [rsp], xmm0
00007fa9d6dd8f22  vmovaps [rsp+0x10], xmm2
00007fa9d6dd8f28  vmovaps [rsp+0x20], xmm3
00007fa9d6dd8f2e  vmovaps [rsp+0x30], xmm4
00007fa9d6dd8f34  vmovaps [rsp+0x40], xmm5
00007fa9d6dd8f3a  vmovaps [rsp+0x50], xmm6
00007fa9d6dd8f40  vmovaps [rsp+0x60], xmm7
00007fa9d6dd8f46  vmovaps [rsp+0x70], xmm8
00007fa9d6dd8f4c  vmovaps [rsp+0x80], xmm9
00007fa9d6dd8f55  vmovaps [rsp+0x90], xmm10
00007fa9d6dd8f5e  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd8f67  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd8f70  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd8f79  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd8f82  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd8f8b  sub rsp, 0x30
00007fa9d6dd8f8f  movaps [rsp], xmm1
00007fa9d6dd8f93  movaps [rsp+0x10], xmm15
00007fa9d6dd8f99  movaps [rsp+0x20], xmm6
00007fa9d6dd8f9e  lea rdi, [rsp]
00007fa9d6dd8fa2  mov esi, 0x00
00007fa9d6dd8fa7  mov rax, 0x61DF872DB530
00007fa9d6dd8fb1  call rax
00007fa9d6dd8fb3  movaps xmm1, [rsp]
00007fa9d6dd8fb7  add rsp, 0x30
00007fa9d6dd8fbb  vmovaps xmm0, [rsp]
00007fa9d6dd8fc0  vmovaps xmm2, [rsp+0x10]
00007fa9d6dd8fc6  vmovaps xmm3, [rsp+0x20]
00007fa9d6dd8fcc  vmovaps xmm4, [rsp+0x30]
00007fa9d6dd8fd2  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd8fd8  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd8fde  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd8fe4  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd8fea  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd8ff3  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd8ffc  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd9005  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd900e  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd9017  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd9020  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd9029  add rsp, 0xF0
00007fa9d6dd9030  pop r11
00007fa9d6dd9032  pop r10
00007fa9d6dd9034  pop r9
00007fa9d6dd9036  pop r8
00007fa9d6dd9038  pop rsi
00007fa9d6dd9039  pop rdi
00007fa9d6dd903a  pop rdx
00007fa9d6dd903b  pop rcx
00007fa9d6dd903c  pop rax
00007fa9d6dd903d  add rsp, 0x08
00007fa9d6dd9041  jmp 0x00007FA9D6DD61C2
00007fa9d6dd9046  sub rsp, 0x08
00007fa9d6dd904a  push rax
00007fa9d6dd904b  push rcx
00007fa9d6dd904c  push rdx
00007fa9d6dd904d  push rdi
00007fa9d6dd904e  push rsi
00007fa9d6dd904f  push r8
00007fa9d6dd9051  push r9
00007fa9d6dd9053  push r10
00007fa9d6dd9055  push r11
00007fa9d6dd9057  sub rsp, 0xF0
00007fa9d6dd905e  vmovaps [rsp], xmm0
00007fa9d6dd9063  vmovaps [rsp+0x10], xmm1
00007fa9d6dd9069  vmovaps [rsp+0x20], xmm2
00007fa9d6dd906f  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9075  vmovaps [rsp+0x40], xmm4
00007fa9d6dd907b  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9081  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9087  vmovaps [rsp+0x70], xmm7
00007fa9d6dd908d  vmovaps [rsp+0x80], xmm8
00007fa9d6dd9096  vmovaps [rsp+0x90], xmm9
00007fa9d6dd909f  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd90a8  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd90b1  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd90ba  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd90c3  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd90cc  sub rsp, 0x30
00007fa9d6dd90d0  movaps [rsp], xmm15
00007fa9d6dd90d5  movaps [rsp+0x10], xmm5
00007fa9d6dd90da  movaps [rsp+0x20], xmm3
00007fa9d6dd90df  lea rdi, [rsp]
00007fa9d6dd90e3  mov esi, 0x00
00007fa9d6dd90e8  mov rax, 0x61DF872DB530
00007fa9d6dd90f2  call rax
00007fa9d6dd90f4  movaps xmm15, [rsp]
00007fa9d6dd90f9  add rsp, 0x30
00007fa9d6dd90fd  vmovaps xmm0, [rsp]
00007fa9d6dd9102  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9108  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd910e  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9114  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd911a  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd9120  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd9126  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd912c  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd9135  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd913e  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd9147  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd9150  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd9159  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd9162  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd916b  add rsp, 0xF0
00007fa9d6dd9172  pop r11
00007fa9d6dd9174  pop r10
00007fa9d6dd9176  pop r9
00007fa9d6dd9178  pop r8
00007fa9d6dd917a  pop rsi
00007fa9d6dd917b  pop rdi
00007fa9d6dd917c  pop rdx
00007fa9d6dd917d  pop rcx
00007fa9d6dd917e  pop rax
00007fa9d6dd917f  add rsp, 0x08
00007fa9d6dd9183  jmp 0x00007FA9D6DD61DC
00007fa9d6dd9188  sub rsp, 0x08
00007fa9d6dd918c  push rax
00007fa9d6dd918d  push rcx
00007fa9d6dd918e  push rdx
00007fa9d6dd918f  push rdi
00007fa9d6dd9190  push rsi
00007fa9d6dd9191  push r8
00007fa9d6dd9193  push r9
00007fa9d6dd9195  push r10
00007fa9d6dd9197  push r11
00007fa9d6dd9199  sub rsp, 0xF0
00007fa9d6dd91a0  vmovaps [rsp], xmm0
00007fa9d6dd91a5  vmovaps [rsp+0x10], xmm1
00007fa9d6dd91ab  vmovaps [rsp+0x20], xmm2
00007fa9d6dd91b1  vmovaps [rsp+0x30], xmm3
00007fa9d6dd91b7  vmovaps [rsp+0x40], xmm4
00007fa9d6dd91bd  vmovaps [rsp+0x50], xmm6
00007fa9d6dd91c3  vmovaps [rsp+0x60], xmm7
00007fa9d6dd91c9  vmovaps [rsp+0x70], xmm8
00007fa9d6dd91cf  vmovaps [rsp+0x80], xmm9
00007fa9d6dd91d8  vmovaps [rsp+0x90], xmm10
00007fa9d6dd91e1  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd91ea  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd91f3  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd91fc  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9205  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd920e  sub rsp, 0x30
00007fa9d6dd9212  movaps [rsp], xmm5
00007fa9d6dd9216  movaps [rsp+0x10], xmm8
00007fa9d6dd921c  movaps [rsp+0x20], xmm6
00007fa9d6dd9221  lea rdi, [rsp]
00007fa9d6dd9225  mov esi, 0x00
00007fa9d6dd922a  mov rax, 0x61DF872DB530
00007fa9d6dd9234  call rax
00007fa9d6dd9236  movaps xmm5, [rsp]
00007fa9d6dd923a  add rsp, 0x30
00007fa9d6dd923e  vmovaps xmm0, [rsp]
00007fa9d6dd9243  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9249  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd924f  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9255  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd925b  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd9261  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd9267  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd926d  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd9276  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd927f  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd9288  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd9291  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd929a  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd92a3  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd92ac  add rsp, 0xF0
00007fa9d6dd92b3  pop r11
00007fa9d6dd92b5  pop r10
00007fa9d6dd92b7  pop r9
00007fa9d6dd92b9  pop r8
00007fa9d6dd92bb  pop rsi
00007fa9d6dd92bc  pop rdi
00007fa9d6dd92bd  pop rdx
00007fa9d6dd92be  pop rcx
00007fa9d6dd92bf  pop rax
00007fa9d6dd92c0  add rsp, 0x08
00007fa9d6dd92c4  jmp 0x00007FA9D6DD6200
00007fa9d6dd92c9  sub rsp, 0x08
00007fa9d6dd92cd  push rax
00007fa9d6dd92ce  push rcx
00007fa9d6dd92cf  push rdx
00007fa9d6dd92d0  push rdi
00007fa9d6dd92d1  push rsi
00007fa9d6dd92d2  push r8
00007fa9d6dd92d4  push r9
00007fa9d6dd92d6  push r10
00007fa9d6dd92d8  push r11
00007fa9d6dd92da  sub rsp, 0xF0
00007fa9d6dd92e1  vmovaps [rsp], xmm0
00007fa9d6dd92e6  vmovaps [rsp+0x10], xmm1
00007fa9d6dd92ec  vmovaps [rsp+0x20], xmm2
00007fa9d6dd92f2  vmovaps [rsp+0x30], xmm3
00007fa9d6dd92f8  vmovaps [rsp+0x40], xmm4
00007fa9d6dd92fe  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9304  vmovaps [rsp+0x60], xmm7
00007fa9d6dd930a  vmovaps [rsp+0x70], xmm8
00007fa9d6dd9310  vmovaps [rsp+0x80], xmm9
00007fa9d6dd9319  vmovaps [rsp+0x90], xmm10
00007fa9d6dd9322  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd932b  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd9334  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd933d  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9346  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd934f  sub rsp, 0x30
00007fa9d6dd9353  movaps [rsp], xmm6
00007fa9d6dd9357  movaps [rsp+0x10], xmm10
00007fa9d6dd935d  movaps [rsp+0x20], xmm8
00007fa9d6dd9363  lea rdi, [rsp]
00007fa9d6dd9367  mov esi, 0x00
00007fa9d6dd936c  mov rax, 0x61DF872DB530
00007fa9d6dd9376  call rax
00007fa9d6dd9378  movaps xmm6, [rsp]
00007fa9d6dd937c  add rsp, 0x30
00007fa9d6dd9380  vmovaps xmm0, [rsp]
00007fa9d6dd9385  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd938b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd9391  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9397  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd939d  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd93a3  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd93a9  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd93af  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd93b8  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd93c1  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd93ca  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd93d3  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd93dc  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd93e5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd93ee  add rsp, 0xF0
00007fa9d6dd93f5  pop r11
00007fa9d6dd93f7  pop r10
00007fa9d6dd93f9  pop r9
00007fa9d6dd93fb  pop r8
00007fa9d6dd93fd  pop rsi
00007fa9d6dd93fe  pop rdi
00007fa9d6dd93ff  pop rdx
00007fa9d6dd9400  pop rcx
00007fa9d6dd9401  pop rax
00007fa9d6dd9402  add rsp, 0x08
00007fa9d6dd9406  jmp 0x00007FA9D6DD6225
00007fa9d6dd940b  sub rsp, 0x08
00007fa9d6dd940f  push rax
00007fa9d6dd9410  push rcx
00007fa9d6dd9411  push rdx
00007fa9d6dd9412  push rdi
00007fa9d6dd9413  push rsi
00007fa9d6dd9414  push r8
00007fa9d6dd9416  push r9
00007fa9d6dd9418  push r10
00007fa9d6dd941a  push r11
00007fa9d6dd941c  sub rsp, 0xF0
00007fa9d6dd9423  vmovaps [rsp], xmm0
00007fa9d6dd9428  vmovaps [rsp+0x10], xmm1
00007fa9d6dd942e  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9434  vmovaps [rsp+0x30], xmm3
00007fa9d6dd943a  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9440  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9446  vmovaps [rsp+0x60], xmm6
00007fa9d6dd944c  vmovaps [rsp+0x70], xmm7
00007fa9d6dd9452  vmovaps [rsp+0x80], xmm8
00007fa9d6dd945b  vmovaps [rsp+0x90], xmm9
00007fa9d6dd9464  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd946d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd9476  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd947f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9488  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd9491  sub rsp, 0x30
00007fa9d6dd9495  movaps [rsp], xmm10
00007fa9d6dd949a  movaps [rsp+0x10], xmm8
00007fa9d6dd94a0  movaps [rsp+0x20], xmm14
00007fa9d6dd94a6  lea rdi, [rsp]
00007fa9d6dd94aa  mov esi, 0x00
00007fa9d6dd94af  mov rax, 0x61DF872DB530
00007fa9d6dd94b9  call rax
00007fa9d6dd94bb  movaps xmm10, [rsp]
00007fa9d6dd94c0  add rsp, 0x30
00007fa9d6dd94c4  vmovaps xmm0, [rsp]
00007fa9d6dd94c9  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd94cf  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd94d5  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd94db  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd94e1  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd94e7  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd94ed  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd94f3  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd94fc  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd9505  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd950e  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd9517  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd9520  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd9529  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd9532  add rsp, 0xF0
00007fa9d6dd9539  pop r11
00007fa9d6dd953b  pop r10
00007fa9d6dd953d  pop r9
00007fa9d6dd953f  pop r8
00007fa9d6dd9541  pop rsi
00007fa9d6dd9542  pop rdi
00007fa9d6dd9543  pop rdx
00007fa9d6dd9544  pop rcx
00007fa9d6dd9545  pop rax
00007fa9d6dd9546  add rsp, 0x08
00007fa9d6dd954a  jmp 0x00007FA9D6DD6245
00007fa9d6dd954f  sub rsp, 0x08
00007fa9d6dd9553  push rax
00007fa9d6dd9554  push rcx
00007fa9d6dd9555  push rdx
00007fa9d6dd9556  push rdi
00007fa9d6dd9557  push rsi
00007fa9d6dd9558  push r8
00007fa9d6dd955a  push r9
00007fa9d6dd955c  push r10
00007fa9d6dd955e  push r11
00007fa9d6dd9560  sub rsp, 0xF0
00007fa9d6dd9567  vmovaps [rsp], xmm0
00007fa9d6dd956c  vmovaps [rsp+0x10], xmm1
00007fa9d6dd9572  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9578  vmovaps [rsp+0x30], xmm3
00007fa9d6dd957e  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9584  vmovaps [rsp+0x50], xmm5
00007fa9d6dd958a  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9590  vmovaps [rsp+0x70], xmm7
00007fa9d6dd9596  vmovaps [rsp+0x80], xmm8
00007fa9d6dd959f  vmovaps [rsp+0x90], xmm9
00007fa9d6dd95a8  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd95b1  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd95ba  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd95c3  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd95cc  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd95d5  sub rsp, 0x30
00007fa9d6dd95d9  movaps [rsp], xmm14
00007fa9d6dd95de  movaps [rsp+0x10], xmm8
00007fa9d6dd95e4  movaps [rsp+0x20], xmm4
00007fa9d6dd95e9  lea rdi, [rsp]
00007fa9d6dd95ed  mov esi, 0x00
00007fa9d6dd95f2  mov rax, 0x61DF872DB530
00007fa9d6dd95fc  call rax
00007fa9d6dd95fe  movaps xmm14, [rsp]
00007fa9d6dd9603  add rsp, 0x30
00007fa9d6dd9607  vmovaps xmm0, [rsp]
00007fa9d6dd960c  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9612  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd9618  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd961e  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd9624  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd962a  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd9630  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd9636  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd963f  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd9648  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd9651  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd965a  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd9663  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd966c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd9675  add rsp, 0xF0
00007fa9d6dd967c  pop r11
00007fa9d6dd967e  pop r10
00007fa9d6dd9680  pop r9
00007fa9d6dd9682  pop r8
00007fa9d6dd9684  pop rsi
00007fa9d6dd9685  pop rdi
00007fa9d6dd9686  pop rdx
00007fa9d6dd9687  pop rcx
00007fa9d6dd9688  pop rax
00007fa9d6dd9689  add rsp, 0x08
00007fa9d6dd968d  jmp 0x00007FA9D6DD6265
00007fa9d6dd9692  sub rsp, 0x08
00007fa9d6dd9696  push rax
00007fa9d6dd9697  push rcx
00007fa9d6dd9698  push rdx
00007fa9d6dd9699  push rdi
00007fa9d6dd969a  push rsi
00007fa9d6dd969b  push r8
00007fa9d6dd969d  push r9
00007fa9d6dd969f  push r10
00007fa9d6dd96a1  push r11
00007fa9d6dd96a3  sub rsp, 0xF0
00007fa9d6dd96aa  vmovaps [rsp], xmm0
00007fa9d6dd96af  vmovaps [rsp+0x10], xmm1
00007fa9d6dd96b5  vmovaps [rsp+0x20], xmm2
00007fa9d6dd96bb  vmovaps [rsp+0x30], xmm3
00007fa9d6dd96c1  vmovaps [rsp+0x40], xmm5
00007fa9d6dd96c7  vmovaps [rsp+0x50], xmm6
00007fa9d6dd96cd  vmovaps [rsp+0x60], xmm7
00007fa9d6dd96d3  vmovaps [rsp+0x70], xmm8
00007fa9d6dd96d9  vmovaps [rsp+0x80], xmm9
00007fa9d6dd96e2  vmovaps [rsp+0x90], xmm10
00007fa9d6dd96eb  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd96f4  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd96fd  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd9706  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd970f  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd9718  sub rsp, 0x30
00007fa9d6dd971c  movaps [rsp], xmm4
00007fa9d6dd9720  movaps [rsp+0x10], xmm13
00007fa9d6dd9726  movaps [rsp+0x20], xmm8
00007fa9d6dd972c  lea rdi, [rsp]
00007fa9d6dd9730  mov esi, 0x00
00007fa9d6dd9735  mov rax, 0x61DF872DB530
00007fa9d6dd973f  call rax
00007fa9d6dd9741  movaps xmm4, [rsp]
00007fa9d6dd9745  add rsp, 0x30
00007fa9d6dd9749  vmovaps xmm0, [rsp]
00007fa9d6dd974e  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9754  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd975a  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9760  vmovaps xmm5, [rsp+0x40]
00007fa9d6dd9766  vmovaps xmm6, [rsp+0x50]
00007fa9d6dd976c  vmovaps xmm7, [rsp+0x60]
00007fa9d6dd9772  vmovaps xmm8, [rsp+0x70]
00007fa9d6dd9778  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd9781  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd978a  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd9793  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd979c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd97a5  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd97ae  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd97b7  add rsp, 0xF0
00007fa9d6dd97be  pop r11
00007fa9d6dd97c0  pop r10
00007fa9d6dd97c2  pop r9
00007fa9d6dd97c4  pop r8
00007fa9d6dd97c6  pop rsi
00007fa9d6dd97c7  pop rdi
00007fa9d6dd97c8  pop rdx
00007fa9d6dd97c9  pop rcx
00007fa9d6dd97ca  pop rax
00007fa9d6dd97cb  add rsp, 0x08
00007fa9d6dd97cf  jmp 0x00007FA9D6DD628A
00007fa9d6dd97d4  sub rsp, 0x08
00007fa9d6dd97d8  push rax
00007fa9d6dd97d9  push rcx
00007fa9d6dd97da  push rdx
00007fa9d6dd97db  push rdi
00007fa9d6dd97dc  push rsi
00007fa9d6dd97dd  push r8
00007fa9d6dd97df  push r9
00007fa9d6dd97e1  push r10
00007fa9d6dd97e3  push r11
00007fa9d6dd97e5  sub rsp, 0xF0
00007fa9d6dd97ec  vmovaps [rsp], xmm0
00007fa9d6dd97f1  vmovaps [rsp+0x10], xmm1
00007fa9d6dd97f7  vmovaps [rsp+0x20], xmm2
00007fa9d6dd97fd  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9803  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9809  vmovaps [rsp+0x50], xmm5
00007fa9d6dd980f  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9815  vmovaps [rsp+0x70], xmm7
00007fa9d6dd981b  vmovaps [rsp+0x80], xmm8
00007fa9d6dd9824  vmovaps [rsp+0x90], xmm9
00007fa9d6dd982d  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd9836  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd983f  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd9848  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9851  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd985a  sub rsp, 0x30
00007fa9d6dd985e  movaps [rsp], xmm13
00007fa9d6dd9863  movaps [rsp+0x10], xmm15
00007fa9d6dd9869  movaps [rsp+0x20], xmm9
00007fa9d6dd986f  lea rdi, [rsp]
00007fa9d6dd9873  mov esi, 0x00
00007fa9d6dd9878  mov rax, 0x61DF872DB530
00007fa9d6dd9882  call rax
00007fa9d6dd9884  movaps xmm13, [rsp]
00007fa9d6dd9889  add rsp, 0x30
00007fa9d6dd988d  vmovaps xmm0, [rsp]
00007fa9d6dd9892  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9898  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd989e  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd98a4  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd98aa  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd98b0  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd98b6  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd98bc  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd98c5  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd98ce  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd98d7  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd98e0  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd98e9  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd98f2  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd98fb  add rsp, 0xF0
00007fa9d6dd9902  pop r11
00007fa9d6dd9904  pop r10
00007fa9d6dd9906  pop r9
00007fa9d6dd9908  pop r8
00007fa9d6dd990a  pop rsi
00007fa9d6dd990b  pop rdi
00007fa9d6dd990c  pop rdx
00007fa9d6dd990d  pop rcx
00007fa9d6dd990e  pop rax
00007fa9d6dd990f  add rsp, 0x08
00007fa9d6dd9913  jmp 0x00007FA9D6DD62A5
00007fa9d6dd9918  sub rsp, 0x08
00007fa9d6dd991c  push rax
00007fa9d6dd991d  push rcx
00007fa9d6dd991e  push rdx
00007fa9d6dd991f  push rdi
00007fa9d6dd9920  push rsi
00007fa9d6dd9921  push r8
00007fa9d6dd9923  push r9
00007fa9d6dd9925  push r10
00007fa9d6dd9927  push r11
00007fa9d6dd9929  sub rsp, 0xF0
00007fa9d6dd9930  vmovaps [rsp], xmm0
00007fa9d6dd9935  vmovaps [rsp+0x10], xmm1
00007fa9d6dd993b  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9941  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9947  vmovaps [rsp+0x40], xmm4
00007fa9d6dd994d  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9953  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9959  vmovaps [rsp+0x70], xmm7
00007fa9d6dd995f  vmovaps [rsp+0x80], xmm8
00007fa9d6dd9968  vmovaps [rsp+0x90], xmm9
00007fa9d6dd9971  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd997a  vmovaps [rsp+0xB0], xmm11
00007fa9d6dd9983  vmovaps [rsp+0xC0], xmm12
00007fa9d6dd998c  vmovaps [rsp+0xD0], xmm13
00007fa9d6dd9995  vmovaps [rsp+0xE0], xmm14
00007fa9d6dd999e  sub rsp, 0x30
00007fa9d6dd99a2  movaps [rsp], xmm15
00007fa9d6dd99a7  movaps [rsp+0x10], xmm1
00007fa9d6dd99ac  movaps [rsp+0x20], xmm5
00007fa9d6dd99b1  lea rdi, [rsp]
00007fa9d6dd99b5  mov esi, 0x00
00007fa9d6dd99ba  mov rax, 0x61DF872DB530
00007fa9d6dd99c4  call rax
00007fa9d6dd99c6  movaps xmm15, [rsp]
00007fa9d6dd99cb  add rsp, 0x30
00007fa9d6dd99cf  vmovaps xmm0, [rsp]
00007fa9d6dd99d4  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd99da  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd99e0  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd99e6  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd99ec  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd99f2  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd99f8  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd99fe  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd9a07  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd9a10  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd9a19  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dd9a22  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dd9a2b  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dd9a34  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dd9a3d  add rsp, 0xF0
00007fa9d6dd9a44  pop r11
00007fa9d6dd9a46  pop r10
00007fa9d6dd9a48  pop r9
00007fa9d6dd9a4a  pop r8
00007fa9d6dd9a4c  pop rsi
00007fa9d6dd9a4d  pop rdi
00007fa9d6dd9a4e  pop rdx
00007fa9d6dd9a4f  pop rcx
00007fa9d6dd9a50  pop rax
00007fa9d6dd9a51  add rsp, 0x08
00007fa9d6dd9a55  jmp 0x00007FA9D6DD62C0
00007fa9d6dd9a5a  call 0x00007FA9D6CD64F0
00007fa9d6dd9a5f  jmp 0x00007FA9D6DD631B
00007fa9d6dd9a64  sub rsp, 0x08
00007fa9d6dd9a68  push rax
00007fa9d6dd9a69  push rcx
00007fa9d6dd9a6a  push rdx
00007fa9d6dd9a6b  push rdi
00007fa9d6dd9a6c  push rsi
00007fa9d6dd9a6d  push r8
00007fa9d6dd9a6f  push r9
00007fa9d6dd9a71  push r10
00007fa9d6dd9a73  push r11
00007fa9d6dd9a75  sub rsp, 0xF0
00007fa9d6dd9a7c  vmovaps [rsp], xmm0
00007fa9d6dd9a81  vmovaps [rsp+0x10], xmm1
00007fa9d6dd9a87  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9a8d  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9a93  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9a99  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9a9f  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9aa5  vmovaps [rsp+0x70], xmm7
00007fa9d6dd9aab  vmovaps [rsp+0x80], xmm8
00007fa9d6dd9ab4  vmovaps [rsp+0x90], xmm10
00007fa9d6dd9abd  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd9ac6  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd9acf  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd9ad8  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9ae1  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd9aea  sub rsp, 0x30
00007fa9d6dd9aee  movaps [rsp], xmm9
00007fa9d6dd9af3  movaps [rsp+0x10], xmm8
00007fa9d6dd9af9  movaps [rsp+0x20], xmm11
00007fa9d6dd9aff  lea rdi, [rsp]
00007fa9d6dd9b03  mov esi, 0x00
00007fa9d6dd9b08  mov rax, 0x61DF872DB530
00007fa9d6dd9b12  call rax
00007fa9d6dd9b14  movaps xmm9, [rsp]
00007fa9d6dd9b19  add rsp, 0x30
00007fa9d6dd9b1d  vmovaps xmm0, [rsp]
00007fa9d6dd9b22  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9b28  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd9b2e  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9b34  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd9b3a  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd9b40  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd9b46  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd9b4c  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd9b55  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd9b5e  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd9b67  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd9b70  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd9b79  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd9b82  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd9b8b  add rsp, 0xF0
00007fa9d6dd9b92  pop r11
00007fa9d6dd9b94  pop r10
00007fa9d6dd9b96  pop r9
00007fa9d6dd9b98  pop r8
00007fa9d6dd9b9a  pop rsi
00007fa9d6dd9b9b  pop rdi
00007fa9d6dd9b9c  pop rdx
00007fa9d6dd9b9d  pop rcx
00007fa9d6dd9b9e  pop rax
00007fa9d6dd9b9f  add rsp, 0x08
00007fa9d6dd9ba3  jmp 0x00007FA9D6DD6352
00007fa9d6dd9ba8  sub rsp, 0x08
00007fa9d6dd9bac  push rax
00007fa9d6dd9bad  push rcx
00007fa9d6dd9bae  push rdx
00007fa9d6dd9baf  push rdi
00007fa9d6dd9bb0  push rsi
00007fa9d6dd9bb1  push r8
00007fa9d6dd9bb3  push r9
00007fa9d6dd9bb5  push r10
00007fa9d6dd9bb7  push r11
00007fa9d6dd9bb9  sub rsp, 0xF0
00007fa9d6dd9bc0  vmovaps [rsp], xmm0
00007fa9d6dd9bc5  vmovaps [rsp+0x10], xmm1
00007fa9d6dd9bcb  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9bd1  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9bd7  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9bdd  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9be3  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9be9  vmovaps [rsp+0x70], xmm7
00007fa9d6dd9bef  vmovaps [rsp+0x80], xmm8
00007fa9d6dd9bf8  vmovaps [rsp+0x90], xmm9
00007fa9d6dd9c01  vmovaps [rsp+0xA0], xmm10
00007fa9d6dd9c0a  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd9c13  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd9c1c  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9c25  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd9c2e  sub rsp, 0x30
00007fa9d6dd9c32  movaps [rsp], xmm11
00007fa9d6dd9c37  movaps [rsp+0x10], xmm10
00007fa9d6dd9c3d  movaps [rsp+0x20], xmm6
00007fa9d6dd9c42  lea rdi, [rsp]
00007fa9d6dd9c46  mov esi, 0x00
00007fa9d6dd9c4b  mov rax, 0x61DF872DB530
00007fa9d6dd9c55  call rax
00007fa9d6dd9c57  movaps xmm11, [rsp]
00007fa9d6dd9c5c  add rsp, 0x30
00007fa9d6dd9c60  vmovaps xmm0, [rsp]
00007fa9d6dd9c65  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9c6b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd9c71  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9c77  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd9c7d  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd9c83  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd9c89  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd9c8f  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd9c98  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd9ca1  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dd9caa  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd9cb3  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd9cbc  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd9cc5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd9cce  add rsp, 0xF0
00007fa9d6dd9cd5  pop r11
00007fa9d6dd9cd7  pop r10
00007fa9d6dd9cd9  pop r9
00007fa9d6dd9cdb  pop r8
00007fa9d6dd9cdd  pop rsi
00007fa9d6dd9cde  pop rdi
00007fa9d6dd9cdf  pop rdx
00007fa9d6dd9ce0  pop rcx
00007fa9d6dd9ce1  pop rax
00007fa9d6dd9ce2  add rsp, 0x08
00007fa9d6dd9ce6  jmp 0x00007FA9D6DD636D
00007fa9d6dd9ceb  sub rsp, 0x08
00007fa9d6dd9cef  push rax
00007fa9d6dd9cf0  push rcx
00007fa9d6dd9cf1  push rdx
00007fa9d6dd9cf2  push rdi
00007fa9d6dd9cf3  push rsi
00007fa9d6dd9cf4  push r8
00007fa9d6dd9cf6  push r9
00007fa9d6dd9cf8  push r10
00007fa9d6dd9cfa  push r11
00007fa9d6dd9cfc  sub rsp, 0xF0
00007fa9d6dd9d03  vmovaps [rsp], xmm0
00007fa9d6dd9d08  vmovaps [rsp+0x10], xmm1
00007fa9d6dd9d0e  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9d14  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9d1a  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9d20  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9d26  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9d2c  vmovaps [rsp+0x70], xmm7
00007fa9d6dd9d32  vmovaps [rsp+0x80], xmm8
00007fa9d6dd9d3b  vmovaps [rsp+0x90], xmm9
00007fa9d6dd9d44  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd9d4d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd9d56  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd9d5f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9d68  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd9d71  sub rsp, 0x30
00007fa9d6dd9d75  movaps [rsp], xmm10
00007fa9d6dd9d7a  movaps [rsp+0x10], xmm14
00007fa9d6dd9d80  movaps [rsp+0x20], xmm4
00007fa9d6dd9d85  lea rdi, [rsp]
00007fa9d6dd9d89  mov esi, 0x00
00007fa9d6dd9d8e  mov rax, 0x61DF872DB530
00007fa9d6dd9d98  call rax
00007fa9d6dd9d9a  movaps xmm10, [rsp]
00007fa9d6dd9d9f  add rsp, 0x30
00007fa9d6dd9da3  vmovaps xmm0, [rsp]
00007fa9d6dd9da8  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9dae  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd9db4  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9dba  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd9dc0  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd9dc6  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd9dcc  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd9dd2  vmovaps xmm8, [rsp+0x80]
00007fa9d6dd9ddb  vmovaps xmm9, [rsp+0x90]
00007fa9d6dd9de4  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd9ded  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd9df6  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd9dff  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd9e08  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd9e11  add rsp, 0xF0
00007fa9d6dd9e18  pop r11
00007fa9d6dd9e1a  pop r10
00007fa9d6dd9e1c  pop r9
00007fa9d6dd9e1e  pop r8
00007fa9d6dd9e20  pop rsi
00007fa9d6dd9e21  pop rdi
00007fa9d6dd9e22  pop rdx
00007fa9d6dd9e23  pop rcx
00007fa9d6dd9e24  pop rax
00007fa9d6dd9e25  add rsp, 0x08
00007fa9d6dd9e29  jmp 0x00007FA9D6DD6388
00007fa9d6dd9e2e  sub rsp, 0x08
00007fa9d6dd9e32  push rax
00007fa9d6dd9e33  push rcx
00007fa9d6dd9e34  push rdx
00007fa9d6dd9e35  push rdi
00007fa9d6dd9e36  push rsi
00007fa9d6dd9e37  push r8
00007fa9d6dd9e39  push r9
00007fa9d6dd9e3b  push r10
00007fa9d6dd9e3d  push r11
00007fa9d6dd9e3f  sub rsp, 0xF0
00007fa9d6dd9e46  vmovaps [rsp], xmm0
00007fa9d6dd9e4b  vmovaps [rsp+0x10], xmm1
00007fa9d6dd9e51  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9e57  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9e5d  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9e63  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9e69  vmovaps [rsp+0x60], xmm6
00007fa9d6dd9e6f  vmovaps [rsp+0x70], xmm7
00007fa9d6dd9e75  vmovaps [rsp+0x80], xmm9
00007fa9d6dd9e7e  vmovaps [rsp+0x90], xmm10
00007fa9d6dd9e87  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd9e90  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd9e99  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd9ea2  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9eab  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd9eb4  sub rsp, 0x30
00007fa9d6dd9eb8  movaps [rsp], xmm8
00007fa9d6dd9ebd  movaps [rsp+0x10], xmm1
00007fa9d6dd9ec2  movaps [rsp+0x20], xmm14
00007fa9d6dd9ec8  lea rdi, [rsp]
00007fa9d6dd9ecc  mov esi, 0x00
00007fa9d6dd9ed1  mov rax, 0x61DF872DB530
00007fa9d6dd9edb  call rax
00007fa9d6dd9edd  movaps xmm8, [rsp]
00007fa9d6dd9ee2  add rsp, 0x30
00007fa9d6dd9ee6  vmovaps xmm0, [rsp]
00007fa9d6dd9eeb  vmovaps xmm1, [rsp+0x10]
00007fa9d6dd9ef1  vmovaps xmm2, [rsp+0x20]
00007fa9d6dd9ef7  vmovaps xmm3, [rsp+0x30]
00007fa9d6dd9efd  vmovaps xmm4, [rsp+0x40]
00007fa9d6dd9f03  vmovaps xmm5, [rsp+0x50]
00007fa9d6dd9f09  vmovaps xmm6, [rsp+0x60]
00007fa9d6dd9f0f  vmovaps xmm7, [rsp+0x70]
00007fa9d6dd9f15  vmovaps xmm9, [rsp+0x80]
00007fa9d6dd9f1e  vmovaps xmm10, [rsp+0x90]
00007fa9d6dd9f27  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dd9f30  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dd9f39  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dd9f42  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dd9f4b  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dd9f54  add rsp, 0xF0
00007fa9d6dd9f5b  pop r11
00007fa9d6dd9f5d  pop r10
00007fa9d6dd9f5f  pop r9
00007fa9d6dd9f61  pop r8
00007fa9d6dd9f63  pop rsi
00007fa9d6dd9f64  pop rdi
00007fa9d6dd9f65  pop rdx
00007fa9d6dd9f66  pop rcx
00007fa9d6dd9f67  pop rax
00007fa9d6dd9f68  add rsp, 0x08
00007fa9d6dd9f6c  jmp 0x00007FA9D6DD63AE
00007fa9d6dd9f71  sub rsp, 0x08
00007fa9d6dd9f75  push rax
00007fa9d6dd9f76  push rcx
00007fa9d6dd9f77  push rdx
00007fa9d6dd9f78  push rdi
00007fa9d6dd9f79  push rsi
00007fa9d6dd9f7a  push r8
00007fa9d6dd9f7c  push r9
00007fa9d6dd9f7e  push r10
00007fa9d6dd9f80  push r11
00007fa9d6dd9f82  sub rsp, 0xF0
00007fa9d6dd9f89  vmovaps [rsp], xmm0
00007fa9d6dd9f8e  vmovaps [rsp+0x10], xmm1
00007fa9d6dd9f94  vmovaps [rsp+0x20], xmm2
00007fa9d6dd9f9a  vmovaps [rsp+0x30], xmm3
00007fa9d6dd9fa0  vmovaps [rsp+0x40], xmm4
00007fa9d6dd9fa6  vmovaps [rsp+0x50], xmm5
00007fa9d6dd9fac  vmovaps [rsp+0x60], xmm7
00007fa9d6dd9fb2  vmovaps [rsp+0x70], xmm8
00007fa9d6dd9fb8  vmovaps [rsp+0x80], xmm9
00007fa9d6dd9fc1  vmovaps [rsp+0x90], xmm10
00007fa9d6dd9fca  vmovaps [rsp+0xA0], xmm11
00007fa9d6dd9fd3  vmovaps [rsp+0xB0], xmm12
00007fa9d6dd9fdc  vmovaps [rsp+0xC0], xmm13
00007fa9d6dd9fe5  vmovaps [rsp+0xD0], xmm14
00007fa9d6dd9fee  vmovaps [rsp+0xE0], xmm15
00007fa9d6dd9ff7  sub rsp, 0x30
00007fa9d6dd9ffb  movaps [rsp], xmm6
00007fa9d6dd9fff  movaps [rsp+0x10], xmm1
00007fa9d6dda004  movaps [rsp+0x20], xmm14
00007fa9d6dda00a  lea rdi, [rsp]
00007fa9d6dda00e  mov esi, 0x00
00007fa9d6dda013  mov rax, 0x61DF872DB530
00007fa9d6dda01d  call rax
00007fa9d6dda01f  movaps xmm6, [rsp]
00007fa9d6dda023  add rsp, 0x30
00007fa9d6dda027  vmovaps xmm0, [rsp]
00007fa9d6dda02c  vmovaps xmm1, [rsp+0x10]
00007fa9d6dda032  vmovaps xmm2, [rsp+0x20]
00007fa9d6dda038  vmovaps xmm3, [rsp+0x30]
00007fa9d6dda03e  vmovaps xmm4, [rsp+0x40]
00007fa9d6dda044  vmovaps xmm5, [rsp+0x50]
00007fa9d6dda04a  vmovaps xmm7, [rsp+0x60]
00007fa9d6dda050  vmovaps xmm8, [rsp+0x70]
00007fa9d6dda056  vmovaps xmm9, [rsp+0x80]
00007fa9d6dda05f  vmovaps xmm10, [rsp+0x90]
00007fa9d6dda068  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dda071  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dda07a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dda083  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dda08c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dda095  add rsp, 0xF0
00007fa9d6dda09c  pop r11
00007fa9d6dda09e  pop r10
00007fa9d6dda0a0  pop r9
00007fa9d6dda0a2  pop r8
00007fa9d6dda0a4  pop rsi
00007fa9d6dda0a5  pop rdi
00007fa9d6dda0a6  pop rdx
00007fa9d6dda0a7  pop rcx
00007fa9d6dda0a8  pop rax
00007fa9d6dda0a9  add rsp, 0x08
00007fa9d6dda0ad  jmp 0x00007FA9D6DD63DA
00007fa9d6dda0b2  sub rsp, 0x08
00007fa9d6dda0b6  push rax
00007fa9d6dda0b7  push rcx
00007fa9d6dda0b8  push rdx
00007fa9d6dda0b9  push rdi
00007fa9d6dda0ba  push rsi
00007fa9d6dda0bb  push r8
00007fa9d6dda0bd  push r9
00007fa9d6dda0bf  push r10
00007fa9d6dda0c1  push r11
00007fa9d6dda0c3  sub rsp, 0xF0
00007fa9d6dda0ca  vmovaps [rsp], xmm0
00007fa9d6dda0cf  vmovaps [rsp+0x10], xmm1
00007fa9d6dda0d5  vmovaps [rsp+0x20], xmm2
00007fa9d6dda0db  vmovaps [rsp+0x30], xmm3
00007fa9d6dda0e1  vmovaps [rsp+0x40], xmm4
00007fa9d6dda0e7  vmovaps [rsp+0x50], xmm5
00007fa9d6dda0ed  vmovaps [rsp+0x60], xmm6
00007fa9d6dda0f3  vmovaps [rsp+0x70], xmm7
00007fa9d6dda0f9  vmovaps [rsp+0x80], xmm8
00007fa9d6dda102  vmovaps [rsp+0x90], xmm9
00007fa9d6dda10b  vmovaps [rsp+0xA0], xmm10
00007fa9d6dda114  vmovaps [rsp+0xB0], xmm11
00007fa9d6dda11d  vmovaps [rsp+0xC0], xmm12
00007fa9d6dda126  vmovaps [rsp+0xD0], xmm13
00007fa9d6dda12f  vmovaps [rsp+0xE0], xmm15
00007fa9d6dda138  sub rsp, 0x30
00007fa9d6dda13c  movaps [rsp], xmm14
00007fa9d6dda141  movaps [rsp+0x10], xmm12
00007fa9d6dda147  movaps [rsp+0x20], xmm1
00007fa9d6dda14c  lea rdi, [rsp]
00007fa9d6dda150  mov esi, 0x00
00007fa9d6dda155  mov rax, 0x61DF872DB530
00007fa9d6dda15f  call rax
00007fa9d6dda161  movaps xmm14, [rsp]
00007fa9d6dda166  add rsp, 0x30
00007fa9d6dda16a  vmovaps xmm0, [rsp]
00007fa9d6dda16f  vmovaps xmm1, [rsp+0x10]
00007fa9d6dda175  vmovaps xmm2, [rsp+0x20]
00007fa9d6dda17b  vmovaps xmm3, [rsp+0x30]
00007fa9d6dda181  vmovaps xmm4, [rsp+0x40]
00007fa9d6dda187  vmovaps xmm5, [rsp+0x50]
00007fa9d6dda18d  vmovaps xmm6, [rsp+0x60]
00007fa9d6dda193  vmovaps xmm7, [rsp+0x70]
00007fa9d6dda199  vmovaps xmm8, [rsp+0x80]
00007fa9d6dda1a2  vmovaps xmm9, [rsp+0x90]
00007fa9d6dda1ab  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dda1b4  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dda1bd  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dda1c6  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dda1cf  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dda1d8  add rsp, 0xF0
00007fa9d6dda1df  pop r11
00007fa9d6dda1e1  pop r10
00007fa9d6dda1e3  pop r9
00007fa9d6dda1e5  pop r8
00007fa9d6dda1e7  pop rsi
00007fa9d6dda1e8  pop rdi
00007fa9d6dda1e9  pop rdx
00007fa9d6dda1ea  pop rcx
00007fa9d6dda1eb  pop rax
00007fa9d6dda1ec  add rsp, 0x08
00007fa9d6dda1f0  jmp 0x00007FA9D6DD6400
00007fa9d6dda1f5  sub rsp, 0x08
00007fa9d6dda1f9  push rax
00007fa9d6dda1fa  push rcx
00007fa9d6dda1fb  push rdx
00007fa9d6dda1fc  push rdi
00007fa9d6dda1fd  push rsi
00007fa9d6dda1fe  push r8
00007fa9d6dda200  push r9
00007fa9d6dda202  push r10
00007fa9d6dda204  push r11
00007fa9d6dda206  sub rsp, 0xF0
00007fa9d6dda20d  vmovaps [rsp], xmm0
00007fa9d6dda212  vmovaps [rsp+0x10], xmm2
00007fa9d6dda218  vmovaps [rsp+0x20], xmm3
00007fa9d6dda21e  vmovaps [rsp+0x30], xmm4
00007fa9d6dda224  vmovaps [rsp+0x40], xmm5
00007fa9d6dda22a  vmovaps [rsp+0x50], xmm6
00007fa9d6dda230  vmovaps [rsp+0x60], xmm7
00007fa9d6dda236  vmovaps [rsp+0x70], xmm8
00007fa9d6dda23c  vmovaps [rsp+0x80], xmm9
00007fa9d6dda245  vmovaps [rsp+0x90], xmm10
00007fa9d6dda24e  vmovaps [rsp+0xA0], xmm11
00007fa9d6dda257  vmovaps [rsp+0xB0], xmm12
00007fa9d6dda260  vmovaps [rsp+0xC0], xmm13
00007fa9d6dda269  vmovaps [rsp+0xD0], xmm14
00007fa9d6dda272  vmovaps [rsp+0xE0], xmm15
00007fa9d6dda27b  sub rsp, 0x30
00007fa9d6dda27f  movaps [rsp], xmm1
00007fa9d6dda283  movaps [rsp+0x10], xmm13
00007fa9d6dda289  movaps [rsp+0x20], xmm9
00007fa9d6dda28f  lea rdi, [rsp]
00007fa9d6dda293  mov esi, 0x00
00007fa9d6dda298  mov rax, 0x61DF872DB530
00007fa9d6dda2a2  call rax
00007fa9d6dda2a4  movaps xmm1, [rsp]
00007fa9d6dda2a8  add rsp, 0x30
00007fa9d6dda2ac  vmovaps xmm0, [rsp]
00007fa9d6dda2b1  vmovaps xmm2, [rsp+0x10]
00007fa9d6dda2b7  vmovaps xmm3, [rsp+0x20]
00007fa9d6dda2bd  vmovaps xmm4, [rsp+0x30]
00007fa9d6dda2c3  vmovaps xmm5, [rsp+0x40]
00007fa9d6dda2c9  vmovaps xmm6, [rsp+0x50]
00007fa9d6dda2cf  vmovaps xmm7, [rsp+0x60]
00007fa9d6dda2d5  vmovaps xmm8, [rsp+0x70]
00007fa9d6dda2db  vmovaps xmm9, [rsp+0x80]
00007fa9d6dda2e4  vmovaps xmm10, [rsp+0x90]
00007fa9d6dda2ed  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dda2f6  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dda2ff  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dda308  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dda311  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dda31a  add rsp, 0xF0
00007fa9d6dda321  pop r11
00007fa9d6dda323  pop r10
00007fa9d6dda325  pop r9
00007fa9d6dda327  pop r8
00007fa9d6dda329  pop rsi
00007fa9d6dda32a  pop rdi
00007fa9d6dda32b  pop rdx
00007fa9d6dda32c  pop rcx
00007fa9d6dda32d  pop rax
00007fa9d6dda32e  add rsp, 0x08
00007fa9d6dda332  jmp 0x00007FA9D6DD641A
00007fa9d6dda337  sub rsp, 0x08
00007fa9d6dda33b  push rax
00007fa9d6dda33c  push rcx
00007fa9d6dda33d  push rdx
00007fa9d6dda33e  push rdi
00007fa9d6dda33f  push rsi
00007fa9d6dda340  push r8
00007fa9d6dda342  push r9
00007fa9d6dda344  push r10
00007fa9d6dda346  push r11
00007fa9d6dda348  sub rsp, 0xF0
00007fa9d6dda34f  vmovaps [rsp], xmm0
00007fa9d6dda354  vmovaps [rsp+0x10], xmm1
00007fa9d6dda35a  vmovaps [rsp+0x20], xmm2
00007fa9d6dda360  vmovaps [rsp+0x30], xmm3
00007fa9d6dda366  vmovaps [rsp+0x40], xmm4
00007fa9d6dda36c  vmovaps [rsp+0x50], xmm5
00007fa9d6dda372  vmovaps [rsp+0x60], xmm6
00007fa9d6dda378  vmovaps [rsp+0x70], xmm7
00007fa9d6dda37e  vmovaps [rsp+0x80], xmm8
00007fa9d6dda387  vmovaps [rsp+0x90], xmm9
00007fa9d6dda390  vmovaps [rsp+0xA0], xmm10
00007fa9d6dda399  vmovaps [rsp+0xB0], xmm11
00007fa9d6dda3a2  vmovaps [rsp+0xC0], xmm13
00007fa9d6dda3ab  vmovaps [rsp+0xD0], xmm14
00007fa9d6dda3b4  vmovaps [rsp+0xE0], xmm15
00007fa9d6dda3bd  sub rsp, 0x30
00007fa9d6dda3c1  movaps [rsp], xmm12
00007fa9d6dda3c6  movaps [rsp+0x10], xmm7
00007fa9d6dda3cb  movaps [rsp+0x20], xmm13
00007fa9d6dda3d1  lea rdi, [rsp]
00007fa9d6dda3d5  mov esi, 0x00
00007fa9d6dda3da  mov rax, 0x61DF872DB530
00007fa9d6dda3e4  call rax
00007fa9d6dda3e6  movaps xmm12, [rsp]
00007fa9d6dda3eb  add rsp, 0x30
00007fa9d6dda3ef  vmovaps xmm0, [rsp]
00007fa9d6dda3f4  vmovaps xmm1, [rsp+0x10]
00007fa9d6dda3fa  vmovaps xmm2, [rsp+0x20]
00007fa9d6dda400  vmovaps xmm3, [rsp+0x30]
00007fa9d6dda406  vmovaps xmm4, [rsp+0x40]
00007fa9d6dda40c  vmovaps xmm5, [rsp+0x50]
00007fa9d6dda412  vmovaps xmm6, [rsp+0x60]
00007fa9d6dda418  vmovaps xmm7, [rsp+0x70]
00007fa9d6dda41e  vmovaps xmm8, [rsp+0x80]
00007fa9d6dda427  vmovaps xmm9, [rsp+0x90]
00007fa9d6dda430  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dda439  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dda442  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dda44b  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dda454  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dda45d  add rsp, 0xF0
00007fa9d6dda464  pop r11
00007fa9d6dda466  pop r10
00007fa9d6dda468  pop r9
00007fa9d6dda46a  pop r8
00007fa9d6dda46c  pop rsi
00007fa9d6dda46d  pop rdi
00007fa9d6dda46e  pop rdx
00007fa9d6dda46f  pop rcx
00007fa9d6dda470  pop rax
00007fa9d6dda471  add rsp, 0x08
00007fa9d6dda475  jmp 0x00007FA9D6DD6441
00007fa9d6dda47a  sub rsp, 0x08
00007fa9d6dda47e  push rax
00007fa9d6dda47f  push rcx
00007fa9d6dda480  push rdx
00007fa9d6dda481  push rdi
00007fa9d6dda482  push rsi
00007fa9d6dda483  push r8
00007fa9d6dda485  push r9
00007fa9d6dda487  push r10
00007fa9d6dda489  push r11
00007fa9d6dda48b  sub rsp, 0xF0
00007fa9d6dda492  vmovaps [rsp], xmm0
00007fa9d6dda497  vmovaps [rsp+0x10], xmm1
00007fa9d6dda49d  vmovaps [rsp+0x20], xmm2
00007fa9d6dda4a3  vmovaps [rsp+0x30], xmm3
00007fa9d6dda4a9  vmovaps [rsp+0x40], xmm4
00007fa9d6dda4af  vmovaps [rsp+0x50], xmm5
00007fa9d6dda4b5  vmovaps [rsp+0x60], xmm6
00007fa9d6dda4bb  vmovaps [rsp+0x70], xmm7
00007fa9d6dda4c1  vmovaps [rsp+0x80], xmm8
00007fa9d6dda4ca  vmovaps [rsp+0x90], xmm9
00007fa9d6dda4d3  vmovaps [rsp+0xA0], xmm10
00007fa9d6dda4dc  vmovaps [rsp+0xB0], xmm11
00007fa9d6dda4e5  vmovaps [rsp+0xC0], xmm12
00007fa9d6dda4ee  vmovaps [rsp+0xD0], xmm14
00007fa9d6dda4f7  vmovaps [rsp+0xE0], xmm15
00007fa9d6dda500  sub rsp, 0x30
00007fa9d6dda504  movaps [rsp], xmm13
00007fa9d6dda509  movaps [rsp+0x10], xmm15
00007fa9d6dda50f  movaps [rsp+0x20], xmm8
00007fa9d6dda515  lea rdi, [rsp]
00007fa9d6dda519  mov esi, 0x00
00007fa9d6dda51e  mov rax, 0x61DF872DB530
00007fa9d6dda528  call rax
00007fa9d6dda52a  movaps xmm13, [rsp]
00007fa9d6dda52f  add rsp, 0x30
00007fa9d6dda533  vmovaps xmm0, [rsp]
00007fa9d6dda538  vmovaps xmm1, [rsp+0x10]
00007fa9d6dda53e  vmovaps xmm2, [rsp+0x20]
00007fa9d6dda544  vmovaps xmm3, [rsp+0x30]
00007fa9d6dda54a  vmovaps xmm4, [rsp+0x40]
00007fa9d6dda550  vmovaps xmm5, [rsp+0x50]
00007fa9d6dda556  vmovaps xmm6, [rsp+0x60]
00007fa9d6dda55c  vmovaps xmm7, [rsp+0x70]
00007fa9d6dda562  vmovaps xmm8, [rsp+0x80]
00007fa9d6dda56b  vmovaps xmm9, [rsp+0x90]
00007fa9d6dda574  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dda57d  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dda586  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dda58f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dda598  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dda5a1  add rsp, 0xF0
00007fa9d6dda5a8  pop r11
00007fa9d6dda5aa  pop r10
00007fa9d6dda5ac  pop r9
00007fa9d6dda5ae  pop r8
00007fa9d6dda5b0  pop rsi
00007fa9d6dda5b1  pop rdi
00007fa9d6dda5b2  pop rdx
00007fa9d6dda5b3  pop rcx
00007fa9d6dda5b4  pop rax
00007fa9d6dda5b5  add rsp, 0x08
00007fa9d6dda5b9  jmp 0x00007FA9D6DD645C
00007fa9d6dda5be  sub rsp, 0x08
00007fa9d6dda5c2  push rax
00007fa9d6dda5c3  push rcx
00007fa9d6dda5c4  push rdx
00007fa9d6dda5c5  push rdi
00007fa9d6dda5c6  push rsi
00007fa9d6dda5c7  push r8
00007fa9d6dda5c9  push r9
00007fa9d6dda5cb  push r10
00007fa9d6dda5cd  push r11
00007fa9d6dda5cf  sub rsp, 0xF0
00007fa9d6dda5d6  vmovaps [rsp], xmm0
00007fa9d6dda5db  vmovaps [rsp+0x10], xmm1
00007fa9d6dda5e1  vmovaps [rsp+0x20], xmm2
00007fa9d6dda5e7  vmovaps [rsp+0x30], xmm3
00007fa9d6dda5ed  vmovaps [rsp+0x40], xmm4
00007fa9d6dda5f3  vmovaps [rsp+0x50], xmm5
00007fa9d6dda5f9  vmovaps [rsp+0x60], xmm6
00007fa9d6dda5ff  vmovaps [rsp+0x70], xmm7
00007fa9d6dda605  vmovaps [rsp+0x80], xmm9
00007fa9d6dda60e  vmovaps [rsp+0x90], xmm10
00007fa9d6dda617  vmovaps [rsp+0xA0], xmm11
00007fa9d6dda620  vmovaps [rsp+0xB0], xmm12
00007fa9d6dda629  vmovaps [rsp+0xC0], xmm13
00007fa9d6dda632  vmovaps [rsp+0xD0], xmm14
00007fa9d6dda63b  vmovaps [rsp+0xE0], xmm15
00007fa9d6dda644  sub rsp, 0x30
00007fa9d6dda648  movaps [rsp], xmm8
00007fa9d6dda64d  movaps [rsp+0x10], xmm15
00007fa9d6dda653  movaps [rsp+0x20], xmm9
00007fa9d6dda659  lea rdi, [rsp]
00007fa9d6dda65d  mov esi, 0x00
00007fa9d6dda662  mov rax, 0x61DF872DB530
00007fa9d6dda66c  call rax
00007fa9d6dda66e  movaps xmm8, [rsp]
00007fa9d6dda673  add rsp, 0x30
00007fa9d6dda677  vmovaps xmm0, [rsp]
00007fa9d6dda67c  vmovaps xmm1, [rsp+0x10]
00007fa9d6dda682  vmovaps xmm2, [rsp+0x20]
00007fa9d6dda688  vmovaps xmm3, [rsp+0x30]
00007fa9d6dda68e  vmovaps xmm4, [rsp+0x40]
00007fa9d6dda694  vmovaps xmm5, [rsp+0x50]
00007fa9d6dda69a  vmovaps xmm6, [rsp+0x60]
00007fa9d6dda6a0  vmovaps xmm7, [rsp+0x70]
00007fa9d6dda6a6  vmovaps xmm9, [rsp+0x80]
00007fa9d6dda6af  vmovaps xmm10, [rsp+0x90]
00007fa9d6dda6b8  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dda6c1  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dda6ca  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dda6d3  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dda6dc  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dda6e5  add rsp, 0xF0
00007fa9d6dda6ec  pop r11
00007fa9d6dda6ee  pop r10
00007fa9d6dda6f0  pop r9
00007fa9d6dda6f2  pop r8
00007fa9d6dda6f4  pop rsi
00007fa9d6dda6f5  pop rdi
00007fa9d6dda6f6  pop rdx
00007fa9d6dda6f7  pop rcx
00007fa9d6dda6f8  pop rax
00007fa9d6dda6f9  add rsp, 0x08
00007fa9d6dda6fd  jmp 0x00007FA9D6DD648A
00007fa9d6dda702  sub rsp, 0x08
00007fa9d6dda706  push rax
00007fa9d6dda707  push rcx
00007fa9d6dda708  push rdx
00007fa9d6dda709  push rdi
00007fa9d6dda70a  push rsi
00007fa9d6dda70b  push r8
00007fa9d6dda70d  push r9
00007fa9d6dda70f  push r10
00007fa9d6dda711  push r11
00007fa9d6dda713  sub rsp, 0xF0
00007fa9d6dda71a  vmovaps [rsp], xmm0
00007fa9d6dda71f  vmovaps [rsp+0x10], xmm1
00007fa9d6dda725  vmovaps [rsp+0x20], xmm2
00007fa9d6dda72b  vmovaps [rsp+0x30], xmm3
00007fa9d6dda731  vmovaps [rsp+0x40], xmm4
00007fa9d6dda737  vmovaps [rsp+0x50], xmm5
00007fa9d6dda73d  vmovaps [rsp+0x60], xmm6
00007fa9d6dda743  vmovaps [rsp+0x70], xmm7
00007fa9d6dda749  vmovaps [rsp+0x80], xmm8
00007fa9d6dda752  vmovaps [rsp+0x90], xmm9
00007fa9d6dda75b  vmovaps [rsp+0xA0], xmm10
00007fa9d6dda764  vmovaps [rsp+0xB0], xmm11
00007fa9d6dda76d  vmovaps [rsp+0xC0], xmm12
00007fa9d6dda776  vmovaps [rsp+0xD0], xmm13
00007fa9d6dda77f  vmovaps [rsp+0xE0], xmm14
00007fa9d6dda788  sub rsp, 0x30
00007fa9d6dda78c  movaps [rsp], xmm15
00007fa9d6dda791  movaps [rsp+0x10], xmm11
00007fa9d6dda797  movaps [rsp+0x20], xmm6
00007fa9d6dda79c  lea rdi, [rsp]
00007fa9d6dda7a0  mov esi, 0x00
00007fa9d6dda7a5  mov rax, 0x61DF872DB530
00007fa9d6dda7af  call rax
00007fa9d6dda7b1  movaps xmm15, [rsp]
00007fa9d6dda7b6  add rsp, 0x30
00007fa9d6dda7ba  vmovaps xmm0, [rsp]
00007fa9d6dda7bf  vmovaps xmm1, [rsp+0x10]
00007fa9d6dda7c5  vmovaps xmm2, [rsp+0x20]
00007fa9d6dda7cb  vmovaps xmm3, [rsp+0x30]
00007fa9d6dda7d1  vmovaps xmm4, [rsp+0x40]
00007fa9d6dda7d7  vmovaps xmm5, [rsp+0x50]
00007fa9d6dda7dd  vmovaps xmm6, [rsp+0x60]
00007fa9d6dda7e3  vmovaps xmm7, [rsp+0x70]
00007fa9d6dda7e9  vmovaps xmm8, [rsp+0x80]
00007fa9d6dda7f2  vmovaps xmm9, [rsp+0x90]
00007fa9d6dda7fb  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dda804  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dda80d  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dda816  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dda81f  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dda828  add rsp, 0xF0
00007fa9d6dda82f  pop r11
00007fa9d6dda831  pop r10
00007fa9d6dda833  pop r9
00007fa9d6dda835  pop r8
00007fa9d6dda837  pop rsi
00007fa9d6dda838  pop rdi
00007fa9d6dda839  pop rdx
00007fa9d6dda83a  pop rcx
00007fa9d6dda83b  pop rax
00007fa9d6dda83c  add rsp, 0x08
00007fa9d6dda840  jmp 0x00007FA9D6DD64A5
00007fa9d6dda845  sub rsp, 0x08
00007fa9d6dda849  push rax
00007fa9d6dda84a  push rcx
00007fa9d6dda84b  push rdx
00007fa9d6dda84c  push rdi
00007fa9d6dda84d  push rsi
00007fa9d6dda84e  push r8
00007fa9d6dda850  push r9
00007fa9d6dda852  push r10
00007fa9d6dda854  push r11
00007fa9d6dda856  sub rsp, 0xF0
00007fa9d6dda85d  vmovaps [rsp], xmm0
00007fa9d6dda862  vmovaps [rsp+0x10], xmm1
00007fa9d6dda868  vmovaps [rsp+0x20], xmm2
00007fa9d6dda86e  vmovaps [rsp+0x30], xmm3
00007fa9d6dda874  vmovaps [rsp+0x40], xmm4
00007fa9d6dda87a  vmovaps [rsp+0x50], xmm5
00007fa9d6dda880  vmovaps [rsp+0x60], xmm6
00007fa9d6dda886  vmovaps [rsp+0x70], xmm8
00007fa9d6dda88c  vmovaps [rsp+0x80], xmm9
00007fa9d6dda895  vmovaps [rsp+0x90], xmm10
00007fa9d6dda89e  vmovaps [rsp+0xA0], xmm11
00007fa9d6dda8a7  vmovaps [rsp+0xB0], xmm12
00007fa9d6dda8b0  vmovaps [rsp+0xC0], xmm13
00007fa9d6dda8b9  vmovaps [rsp+0xD0], xmm14
00007fa9d6dda8c2  vmovaps [rsp+0xE0], xmm15
00007fa9d6dda8cb  sub rsp, 0x30
00007fa9d6dda8cf  movaps [rsp], xmm7
00007fa9d6dda8d3  movaps [rsp+0x10], xmm11
00007fa9d6dda8d9  movaps [rsp+0x20], xmm9
00007fa9d6dda8df  lea rdi, [rsp]
00007fa9d6dda8e3  mov esi, 0x00
00007fa9d6dda8e8  mov rax, 0x61DF872DB530
00007fa9d6dda8f2  call rax
00007fa9d6dda8f4  movaps xmm7, [rsp]
00007fa9d6dda8f8  add rsp, 0x30
00007fa9d6dda8fc  vmovaps xmm0, [rsp]
00007fa9d6dda901  vmovaps xmm1, [rsp+0x10]
00007fa9d6dda907  vmovaps xmm2, [rsp+0x20]
00007fa9d6dda90d  vmovaps xmm3, [rsp+0x30]
00007fa9d6dda913  vmovaps xmm4, [rsp+0x40]
00007fa9d6dda919  vmovaps xmm5, [rsp+0x50]
00007fa9d6dda91f  vmovaps xmm6, [rsp+0x60]
00007fa9d6dda925  vmovaps xmm8, [rsp+0x70]
00007fa9d6dda92b  vmovaps xmm9, [rsp+0x80]
00007fa9d6dda934  vmovaps xmm10, [rsp+0x90]
00007fa9d6dda93d  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dda946  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dda94f  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dda958  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dda961  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dda96a  add rsp, 0xF0
00007fa9d6dda971  pop r11
00007fa9d6dda973  pop r10
00007fa9d6dda975  pop r9
00007fa9d6dda977  pop r8
00007fa9d6dda979  pop rsi
00007fa9d6dda97a  pop rdi
00007fa9d6dda97b  pop rdx
00007fa9d6dda97c  pop rcx
00007fa9d6dda97d  pop rax
00007fa9d6dda97e  add rsp, 0x08
00007fa9d6dda982  jmp 0x00007FA9D6DD64D2
00007fa9d6dda987  sub rsp, 0x08
00007fa9d6dda98b  push rax
00007fa9d6dda98c  push rcx
00007fa9d6dda98d  push rdx
00007fa9d6dda98e  push rdi
00007fa9d6dda98f  push rsi
00007fa9d6dda990  push r8
00007fa9d6dda992  push r9
00007fa9d6dda994  push r10
00007fa9d6dda996  push r11
00007fa9d6dda998  sub rsp, 0xF0
00007fa9d6dda99f  vmovaps [rsp], xmm0
00007fa9d6dda9a4  vmovaps [rsp+0x10], xmm1
00007fa9d6dda9aa  vmovaps [rsp+0x20], xmm2
00007fa9d6dda9b0  vmovaps [rsp+0x30], xmm3
00007fa9d6dda9b6  vmovaps [rsp+0x40], xmm4
00007fa9d6dda9bc  vmovaps [rsp+0x50], xmm5
00007fa9d6dda9c2  vmovaps [rsp+0x60], xmm6
00007fa9d6dda9c8  vmovaps [rsp+0x70], xmm7
00007fa9d6dda9ce  vmovaps [rsp+0x80], xmm8
00007fa9d6dda9d7  vmovaps [rsp+0x90], xmm9
00007fa9d6dda9e0  vmovaps [rsp+0xA0], xmm10
00007fa9d6dda9e9  vmovaps [rsp+0xB0], xmm12
00007fa9d6dda9f2  vmovaps [rsp+0xC0], xmm13
00007fa9d6dda9fb  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddaa04  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddaa0d  sub rsp, 0x30
00007fa9d6ddaa11  movaps [rsp], xmm11
00007fa9d6ddaa16  movaps [rsp+0x10], xmm10
00007fa9d6ddaa1c  movaps [rsp+0x20], xmm14
00007fa9d6ddaa22  lea rdi, [rsp]
00007fa9d6ddaa26  mov esi, 0x00
00007fa9d6ddaa2b  mov rax, 0x61DF872DB530
00007fa9d6ddaa35  call rax
00007fa9d6ddaa37  movaps xmm11, [rsp]
00007fa9d6ddaa3c  add rsp, 0x30
00007fa9d6ddaa40  vmovaps xmm0, [rsp]
00007fa9d6ddaa45  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddaa4b  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddaa51  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddaa57  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddaa5d  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddaa63  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddaa69  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddaa6f  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddaa78  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddaa81  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddaa8a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddaa93  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddaa9c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddaaa5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddaaae  add rsp, 0xF0
00007fa9d6ddaab5  pop r11
00007fa9d6ddaab7  pop r10
00007fa9d6ddaab9  pop r9
00007fa9d6ddaabb  pop r8
00007fa9d6ddaabd  pop rsi
00007fa9d6ddaabe  pop rdi
00007fa9d6ddaabf  pop rdx
00007fa9d6ddaac0  pop rcx
00007fa9d6ddaac1  pop rax
00007fa9d6ddaac2  add rsp, 0x08
00007fa9d6ddaac6  jmp 0x00007FA9D6DD64ED
00007fa9d6ddaacb  call 0x00007FA9D6CE45A0
00007fa9d6ddaad0  jmp 0x00007FA9D6DD64F7
00007fa9d6ddaad5  sub rsp, 0x08
00007fa9d6ddaad9  push rax
00007fa9d6ddaada  push rcx
00007fa9d6ddaadb  push rdx
00007fa9d6ddaadc  push rdi
00007fa9d6ddaadd  push rsi
00007fa9d6ddaade  push r8
00007fa9d6ddaae0  push r9
00007fa9d6ddaae2  push r10
00007fa9d6ddaae4  push r11
00007fa9d6ddaae6  sub rsp, 0xF0
00007fa9d6ddaaed  vmovaps [rsp], xmm0
00007fa9d6ddaaf2  vmovaps [rsp+0x10], xmm1
00007fa9d6ddaaf8  vmovaps [rsp+0x20], xmm2
00007fa9d6ddaafe  vmovaps [rsp+0x30], xmm3
00007fa9d6ddab04  vmovaps [rsp+0x40], xmm4
00007fa9d6ddab0a  vmovaps [rsp+0x50], xmm5
00007fa9d6ddab10  vmovaps [rsp+0x60], xmm6
00007fa9d6ddab16  vmovaps [rsp+0x70], xmm7
00007fa9d6ddab1c  vmovaps [rsp+0x80], xmm8
00007fa9d6ddab25  vmovaps [rsp+0x90], xmm9
00007fa9d6ddab2e  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddab37  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddab40  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddab49  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddab52  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddab5b  sub rsp, 0x30
00007fa9d6ddab5f  movaps [rsp], xmm10
00007fa9d6ddab64  movaps [rsp+0x10], xmm1
00007fa9d6ddab69  movaps [rsp+0x20], xmm12
00007fa9d6ddab6f  lea rdi, [rsp]
00007fa9d6ddab73  mov esi, 0x00
00007fa9d6ddab78  mov rax, 0x61DF872DB530
00007fa9d6ddab82  call rax
00007fa9d6ddab84  movaps xmm10, [rsp]
00007fa9d6ddab89  add rsp, 0x30
00007fa9d6ddab8d  vmovaps xmm0, [rsp]
00007fa9d6ddab92  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddab98  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddab9e  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddaba4  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddabaa  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddabb0  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddabb6  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddabbc  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddabc5  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddabce  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddabd7  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddabe0  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddabe9  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddabf2  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddabfb  add rsp, 0xF0
00007fa9d6ddac02  pop r11
00007fa9d6ddac04  pop r10
00007fa9d6ddac06  pop r9
00007fa9d6ddac08  pop r8
00007fa9d6ddac0a  pop rsi
00007fa9d6ddac0b  pop rdi
00007fa9d6ddac0c  pop rdx
00007fa9d6ddac0d  pop rcx
00007fa9d6ddac0e  pop rax
00007fa9d6ddac0f  add rsp, 0x08
00007fa9d6ddac13  jmp 0x00007FA9D6DD651A
00007fa9d6ddac18  sub rsp, 0x08
00007fa9d6ddac1c  push rax
00007fa9d6ddac1d  push rcx
00007fa9d6ddac1e  push rdx
00007fa9d6ddac1f  push rdi
00007fa9d6ddac20  push rsi
00007fa9d6ddac21  push r8
00007fa9d6ddac23  push r9
00007fa9d6ddac25  push r10
00007fa9d6ddac27  push r11
00007fa9d6ddac29  sub rsp, 0xF0
00007fa9d6ddac30  vmovaps [rsp], xmm0
00007fa9d6ddac35  vmovaps [rsp+0x10], xmm1
00007fa9d6ddac3b  vmovaps [rsp+0x20], xmm2
00007fa9d6ddac41  vmovaps [rsp+0x30], xmm3
00007fa9d6ddac47  vmovaps [rsp+0x40], xmm4
00007fa9d6ddac4d  vmovaps [rsp+0x50], xmm5
00007fa9d6ddac53  vmovaps [rsp+0x60], xmm6
00007fa9d6ddac59  vmovaps [rsp+0x70], xmm7
00007fa9d6ddac5f  vmovaps [rsp+0x80], xmm8
00007fa9d6ddac68  vmovaps [rsp+0x90], xmm9
00007fa9d6ddac71  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddac7a  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddac83  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddac8c  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddac95  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddac9e  sub rsp, 0x30
00007fa9d6ddaca2  movaps [rsp], xmm12
00007fa9d6ddaca7  movaps [rsp+0x10], xmm14
00007fa9d6ddacad  movaps [rsp+0x20], xmm1
00007fa9d6ddacb2  lea rdi, [rsp]
00007fa9d6ddacb6  mov esi, 0x00
00007fa9d6ddacbb  mov rax, 0x61DF872DB530
00007fa9d6ddacc5  call rax
00007fa9d6ddacc7  movaps xmm12, [rsp]
00007fa9d6ddaccc  add rsp, 0x30
00007fa9d6ddacd0  vmovaps xmm0, [rsp]
00007fa9d6ddacd5  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddacdb  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddace1  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddace7  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddaced  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddacf3  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddacf9  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddacff  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddad08  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddad11  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddad1a  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddad23  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddad2c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddad35  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddad3e  add rsp, 0xF0
00007fa9d6ddad45  pop r11
00007fa9d6ddad47  pop r10
00007fa9d6ddad49  pop r9
00007fa9d6ddad4b  pop r8
00007fa9d6ddad4d  pop rsi
00007fa9d6ddad4e  pop rdi
00007fa9d6ddad4f  pop rdx
00007fa9d6ddad50  pop rcx
00007fa9d6ddad51  pop rax
00007fa9d6ddad52  add rsp, 0x08
00007fa9d6ddad56  jmp 0x00007FA9D6DD6549
00007fa9d6ddad5b  sub rsp, 0x08
00007fa9d6ddad5f  push rax
00007fa9d6ddad60  push rcx
00007fa9d6ddad61  push rdx
00007fa9d6ddad62  push rdi
00007fa9d6ddad63  push rsi
00007fa9d6ddad64  push r8
00007fa9d6ddad66  push r9
00007fa9d6ddad68  push r10
00007fa9d6ddad6a  push r11
00007fa9d6ddad6c  sub rsp, 0xF0
00007fa9d6ddad73  vmovaps [rsp], xmm0
00007fa9d6ddad78  vmovaps [rsp+0x10], xmm1
00007fa9d6ddad7e  vmovaps [rsp+0x20], xmm2
00007fa9d6ddad84  vmovaps [rsp+0x30], xmm3
00007fa9d6ddad8a  vmovaps [rsp+0x40], xmm4
00007fa9d6ddad90  vmovaps [rsp+0x50], xmm5
00007fa9d6ddad96  vmovaps [rsp+0x60], xmm6
00007fa9d6ddad9c  vmovaps [rsp+0x70], xmm7
00007fa9d6ddada2  vmovaps [rsp+0x80], xmm8
00007fa9d6ddadab  vmovaps [rsp+0x90], xmm9
00007fa9d6ddadb4  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddadbd  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddadc6  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddadcf  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddadd8  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddade1  sub rsp, 0x30
00007fa9d6ddade5  movaps [rsp], xmm14
00007fa9d6ddadea  movaps [rsp+0x10], xmm9
00007fa9d6ddadf0  movaps [rsp+0x20], xmm1
00007fa9d6ddadf5  lea rdi, [rsp]
00007fa9d6ddadf9  mov esi, 0x00
00007fa9d6ddadfe  mov rax, 0x61DF872DB530
00007fa9d6ddae08  call rax
00007fa9d6ddae0a  movaps xmm14, [rsp]
00007fa9d6ddae0f  add rsp, 0x30
00007fa9d6ddae13  vmovaps xmm0, [rsp]
00007fa9d6ddae18  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddae1e  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddae24  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddae2a  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddae30  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddae36  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddae3c  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddae42  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddae4b  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddae54  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddae5d  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddae66  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddae6f  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddae78  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddae81  add rsp, 0xF0
00007fa9d6ddae88  pop r11
00007fa9d6ddae8a  pop r10
00007fa9d6ddae8c  pop r9
00007fa9d6ddae8e  pop r8
00007fa9d6ddae90  pop rsi
00007fa9d6ddae91  pop rdi
00007fa9d6ddae92  pop rdx
00007fa9d6ddae93  pop rcx
00007fa9d6ddae94  pop rax
00007fa9d6ddae95  add rsp, 0x08
00007fa9d6ddae99  jmp 0x00007FA9D6DD6578
00007fa9d6ddae9e  sub rsp, 0x08
00007fa9d6ddaea2  push rax
00007fa9d6ddaea3  push rcx
00007fa9d6ddaea4  push rdx
00007fa9d6ddaea5  push rdi
00007fa9d6ddaea6  push rsi
00007fa9d6ddaea7  push r8
00007fa9d6ddaea9  push r9
00007fa9d6ddaeab  push r10
00007fa9d6ddaead  push r11
00007fa9d6ddaeaf  sub rsp, 0xF0
00007fa9d6ddaeb6  vmovaps [rsp], xmm0
00007fa9d6ddaebb  vmovaps [rsp+0x10], xmm2
00007fa9d6ddaec1  vmovaps [rsp+0x20], xmm3
00007fa9d6ddaec7  vmovaps [rsp+0x30], xmm4
00007fa9d6ddaecd  vmovaps [rsp+0x40], xmm5
00007fa9d6ddaed3  vmovaps [rsp+0x50], xmm6
00007fa9d6ddaed9  vmovaps [rsp+0x60], xmm7
00007fa9d6ddaedf  vmovaps [rsp+0x70], xmm8
00007fa9d6ddaee5  vmovaps [rsp+0x80], xmm9
00007fa9d6ddaeee  vmovaps [rsp+0x90], xmm10
00007fa9d6ddaef7  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddaf00  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddaf09  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddaf12  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddaf1b  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddaf24  sub rsp, 0x30
00007fa9d6ddaf28  movaps [rsp], xmm1
00007fa9d6ddaf2c  movaps [rsp+0x10], xmm13
00007fa9d6ddaf32  movaps [rsp+0x20], xmm8
00007fa9d6ddaf38  lea rdi, [rsp]
00007fa9d6ddaf3c  mov esi, 0x00
00007fa9d6ddaf41  mov rax, 0x61DF872DB530
00007fa9d6ddaf4b  call rax
00007fa9d6ddaf4d  movaps xmm1, [rsp]
00007fa9d6ddaf51  add rsp, 0x30
00007fa9d6ddaf55  vmovaps xmm0, [rsp]
00007fa9d6ddaf5a  vmovaps xmm2, [rsp+0x10]
00007fa9d6ddaf60  vmovaps xmm3, [rsp+0x20]
00007fa9d6ddaf66  vmovaps xmm4, [rsp+0x30]
00007fa9d6ddaf6c  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddaf72  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddaf78  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddaf7e  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddaf84  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddaf8d  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddaf96  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddaf9f  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddafa8  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddafb1  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddafba  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddafc3  add rsp, 0xF0
00007fa9d6ddafca  pop r11
00007fa9d6ddafcc  pop r10
00007fa9d6ddafce  pop r9
00007fa9d6ddafd0  pop r8
00007fa9d6ddafd2  pop rsi
00007fa9d6ddafd3  pop rdi
00007fa9d6ddafd4  pop rdx
00007fa9d6ddafd5  pop rcx
00007fa9d6ddafd6  pop rax
00007fa9d6ddafd7  add rsp, 0x08
00007fa9d6ddafdb  jmp 0x00007FA9D6DD659A
00007fa9d6ddafe0  call 0x00007FA9D6C0C260
00007fa9d6ddafe5  jmp 0x00007FA9D6DD65A8
00007fa9d6ddafea  call 0x00007FA9D6CDE950
00007fa9d6ddafef  jmp 0x00007FA9D6DD65B2
00007fa9d6ddaff4  sub rsp, 0x08
00007fa9d6ddaff8  push rax
00007fa9d6ddaff9  push rcx
00007fa9d6ddaffa  push rdx
00007fa9d6ddaffb  push rdi
00007fa9d6ddaffc  push rsi
00007fa9d6ddaffd  push r8
00007fa9d6ddafff  push r9
00007fa9d6ddb001  push r10
00007fa9d6ddb003  push r11
00007fa9d6ddb005  sub rsp, 0xF0
00007fa9d6ddb00c  vmovaps [rsp], xmm0
00007fa9d6ddb011  vmovaps [rsp+0x10], xmm1
00007fa9d6ddb017  vmovaps [rsp+0x20], xmm2
00007fa9d6ddb01d  vmovaps [rsp+0x30], xmm3
00007fa9d6ddb023  vmovaps [rsp+0x40], xmm4
00007fa9d6ddb029  vmovaps [rsp+0x50], xmm5
00007fa9d6ddb02f  vmovaps [rsp+0x60], xmm6
00007fa9d6ddb035  vmovaps [rsp+0x70], xmm7
00007fa9d6ddb03b  vmovaps [rsp+0x80], xmm9
00007fa9d6ddb044  vmovaps [rsp+0x90], xmm10
00007fa9d6ddb04d  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddb056  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddb05f  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddb068  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddb071  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddb07a  sub rsp, 0x30
00007fa9d6ddb07e  movaps [rsp], xmm8
00007fa9d6ddb083  movaps [rsp+0x10], xmm15
00007fa9d6ddb089  movaps [rsp+0x20], xmm7
00007fa9d6ddb08e  lea rdi, [rsp]
00007fa9d6ddb092  mov esi, 0x00
00007fa9d6ddb097  mov rax, 0x61DF872DB530
00007fa9d6ddb0a1  call rax
00007fa9d6ddb0a3  movaps xmm8, [rsp]
00007fa9d6ddb0a8  add rsp, 0x30
00007fa9d6ddb0ac  vmovaps xmm0, [rsp]
00007fa9d6ddb0b1  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddb0b7  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddb0bd  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddb0c3  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddb0c9  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddb0cf  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddb0d5  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddb0db  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddb0e4  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddb0ed  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddb0f6  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddb0ff  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddb108  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddb111  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddb11a  add rsp, 0xF0
00007fa9d6ddb121  pop r11
00007fa9d6ddb123  pop r10
00007fa9d6ddb125  pop r9
00007fa9d6ddb127  pop r8
00007fa9d6ddb129  pop rsi
00007fa9d6ddb12a  pop rdi
00007fa9d6ddb12b  pop rdx
00007fa9d6ddb12c  pop rcx
00007fa9d6ddb12d  pop rax
00007fa9d6ddb12e  add rsp, 0x08
00007fa9d6ddb132  jmp 0x00007FA9D6DD65D4
00007fa9d6ddb137  sub rsp, 0x08
00007fa9d6ddb13b  push rax
00007fa9d6ddb13c  push rcx
00007fa9d6ddb13d  push rdx
00007fa9d6ddb13e  push rdi
00007fa9d6ddb13f  push rsi
00007fa9d6ddb140  push r8
00007fa9d6ddb142  push r9
00007fa9d6ddb144  push r10
00007fa9d6ddb146  push r11
00007fa9d6ddb148  sub rsp, 0xF0
00007fa9d6ddb14f  vmovaps [rsp], xmm0
00007fa9d6ddb154  vmovaps [rsp+0x10], xmm1
00007fa9d6ddb15a  vmovaps [rsp+0x20], xmm2
00007fa9d6ddb160  vmovaps [rsp+0x30], xmm3
00007fa9d6ddb166  vmovaps [rsp+0x40], xmm4
00007fa9d6ddb16c  vmovaps [rsp+0x50], xmm5
00007fa9d6ddb172  vmovaps [rsp+0x60], xmm6
00007fa9d6ddb178  vmovaps [rsp+0x70], xmm8
00007fa9d6ddb17e  vmovaps [rsp+0x80], xmm9
00007fa9d6ddb187  vmovaps [rsp+0x90], xmm10
00007fa9d6ddb190  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddb199  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddb1a2  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddb1ab  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddb1b4  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddb1bd  sub rsp, 0x30
00007fa9d6ddb1c1  movaps [rsp], xmm7
00007fa9d6ddb1c5  movaps [rsp+0x10], xmm9
00007fa9d6ddb1cb  movaps [rsp+0x20], xmm15
00007fa9d6ddb1d1  lea rdi, [rsp]
00007fa9d6ddb1d5  mov esi, 0x00
00007fa9d6ddb1da  mov rax, 0x61DF872DB530
00007fa9d6ddb1e4  call rax
00007fa9d6ddb1e6  movaps xmm7, [rsp]
00007fa9d6ddb1ea  add rsp, 0x30
00007fa9d6ddb1ee  vmovaps xmm0, [rsp]
00007fa9d6ddb1f3  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddb1f9  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddb1ff  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddb205  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddb20b  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddb211  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddb217  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddb21d  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddb226  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddb22f  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddb238  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddb241  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddb24a  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddb253  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddb25c  add rsp, 0xF0
00007fa9d6ddb263  pop r11
00007fa9d6ddb265  pop r10
00007fa9d6ddb267  pop r9
00007fa9d6ddb269  pop r8
00007fa9d6ddb26b  pop rsi
00007fa9d6ddb26c  pop rdi
00007fa9d6ddb26d  pop rdx
00007fa9d6ddb26e  pop rcx
00007fa9d6ddb26f  pop rax
00007fa9d6ddb270  add rsp, 0x08
00007fa9d6ddb274  jmp 0x00007FA9D6DD6601
00007fa9d6ddb279  sub rsp, 0x08
00007fa9d6ddb27d  push rax
00007fa9d6ddb27e  push rcx
00007fa9d6ddb27f  push rdx
00007fa9d6ddb280  push rdi
00007fa9d6ddb281  push rsi
00007fa9d6ddb282  push r8
00007fa9d6ddb284  push r9
00007fa9d6ddb286  push r10
00007fa9d6ddb288  push r11
00007fa9d6ddb28a  sub rsp, 0xF0
00007fa9d6ddb291  vmovaps [rsp], xmm0
00007fa9d6ddb296  vmovaps [rsp+0x10], xmm1
00007fa9d6ddb29c  vmovaps [rsp+0x20], xmm2
00007fa9d6ddb2a2  vmovaps [rsp+0x30], xmm3
00007fa9d6ddb2a8  vmovaps [rsp+0x40], xmm4
00007fa9d6ddb2ae  vmovaps [rsp+0x50], xmm5
00007fa9d6ddb2b4  vmovaps [rsp+0x60], xmm6
00007fa9d6ddb2ba  vmovaps [rsp+0x70], xmm7
00007fa9d6ddb2c0  vmovaps [rsp+0x80], xmm8
00007fa9d6ddb2c9  vmovaps [rsp+0x90], xmm10
00007fa9d6ddb2d2  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddb2db  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddb2e4  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddb2ed  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddb2f6  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddb2ff  sub rsp, 0x30
00007fa9d6ddb303  movaps [rsp], xmm9
00007fa9d6ddb308  movaps [rsp+0x10], xmm13
00007fa9d6ddb30e  movaps [rsp+0x20], xmm15
00007fa9d6ddb314  lea rdi, [rsp]
00007fa9d6ddb318  mov esi, 0x00
00007fa9d6ddb31d  mov rax, 0x61DF872DB530
00007fa9d6ddb327  call rax
00007fa9d6ddb329  movaps xmm9, [rsp]
00007fa9d6ddb32e  add rsp, 0x30
00007fa9d6ddb332  vmovaps xmm0, [rsp]
00007fa9d6ddb337  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddb33d  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddb343  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddb349  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddb34f  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddb355  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddb35b  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddb361  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddb36a  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddb373  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddb37c  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddb385  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddb38e  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddb397  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddb3a0  add rsp, 0xF0
00007fa9d6ddb3a7  pop r11
00007fa9d6ddb3a9  pop r10
00007fa9d6ddb3ab  pop r9
00007fa9d6ddb3ad  pop r8
00007fa9d6ddb3af  pop rsi
00007fa9d6ddb3b0  pop rdi
00007fa9d6ddb3b1  pop rdx
00007fa9d6ddb3b2  pop rcx
00007fa9d6ddb3b3  pop rax
00007fa9d6ddb3b4  add rsp, 0x08
00007fa9d6ddb3b8  jmp 0x00007FA9D6DD662F
00007fa9d6ddb3bd  sub rsp, 0x08
00007fa9d6ddb3c1  push rax
00007fa9d6ddb3c2  push rcx
00007fa9d6ddb3c3  push rdx
00007fa9d6ddb3c4  push rdi
00007fa9d6ddb3c5  push rsi
00007fa9d6ddb3c6  push r8
00007fa9d6ddb3c8  push r9
00007fa9d6ddb3ca  push r10
00007fa9d6ddb3cc  push r11
00007fa9d6ddb3ce  sub rsp, 0xF0
00007fa9d6ddb3d5  vmovaps [rsp], xmm0
00007fa9d6ddb3da  vmovaps [rsp+0x10], xmm1
00007fa9d6ddb3e0  vmovaps [rsp+0x20], xmm2
00007fa9d6ddb3e6  vmovaps [rsp+0x30], xmm3
00007fa9d6ddb3ec  vmovaps [rsp+0x40], xmm4
00007fa9d6ddb3f2  vmovaps [rsp+0x50], xmm5
00007fa9d6ddb3f8  vmovaps [rsp+0x60], xmm6
00007fa9d6ddb3fe  vmovaps [rsp+0x70], xmm7
00007fa9d6ddb404  vmovaps [rsp+0x80], xmm8
00007fa9d6ddb40d  vmovaps [rsp+0x90], xmm9
00007fa9d6ddb416  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddb41f  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddb428  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddb431  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddb43a  vmovaps [rsp+0xE0], xmm14
00007fa9d6ddb443  sub rsp, 0x30
00007fa9d6ddb447  movaps [rsp], xmm15
00007fa9d6ddb44c  movaps [rsp+0x10], xmm11
00007fa9d6ddb452  movaps [rsp+0x20], xmm12
00007fa9d6ddb458  lea rdi, [rsp]
00007fa9d6ddb45c  mov esi, 0x00
00007fa9d6ddb461  mov rax, 0x61DF872DB530
00007fa9d6ddb46b  call rax
00007fa9d6ddb46d  movaps xmm15, [rsp]
00007fa9d6ddb472  add rsp, 0x30
00007fa9d6ddb476  vmovaps xmm0, [rsp]
00007fa9d6ddb47b  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddb481  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddb487  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddb48d  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddb493  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddb499  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddb49f  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddb4a5  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddb4ae  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddb4b7  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddb4c0  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddb4c9  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddb4d2  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddb4db  vmovaps xmm14, [rsp+0xE0]
00007fa9d6ddb4e4  add rsp, 0xF0
00007fa9d6ddb4eb  pop r11
00007fa9d6ddb4ed  pop r10
00007fa9d6ddb4ef  pop r9
00007fa9d6ddb4f1  pop r8
00007fa9d6ddb4f3  pop rsi
00007fa9d6ddb4f4  pop rdi
00007fa9d6ddb4f5  pop rdx
00007fa9d6ddb4f6  pop rcx
00007fa9d6ddb4f7  pop rax
00007fa9d6ddb4f8  add rsp, 0x08
00007fa9d6ddb4fc  jmp 0x00007FA9D6DD664A
00007fa9d6ddb501  sub rsp, 0x08
00007fa9d6ddb505  push rax
00007fa9d6ddb506  push rcx
00007fa9d6ddb507  push rdx
00007fa9d6ddb508  push rdi
00007fa9d6ddb509  push rsi
00007fa9d6ddb50a  push r8
00007fa9d6ddb50c  push r9
00007fa9d6ddb50e  push r10
00007fa9d6ddb510  push r11
00007fa9d6ddb512  sub rsp, 0xF0
00007fa9d6ddb519  vmovaps [rsp], xmm0
00007fa9d6ddb51e  vmovaps [rsp+0x10], xmm1
00007fa9d6ddb524  vmovaps [rsp+0x20], xmm2
00007fa9d6ddb52a  vmovaps [rsp+0x30], xmm3
00007fa9d6ddb530  vmovaps [rsp+0x40], xmm4
00007fa9d6ddb536  vmovaps [rsp+0x50], xmm5
00007fa9d6ddb53c  vmovaps [rsp+0x60], xmm6
00007fa9d6ddb542  vmovaps [rsp+0x70], xmm7
00007fa9d6ddb548  vmovaps [rsp+0x80], xmm8
00007fa9d6ddb551  vmovaps [rsp+0x90], xmm9
00007fa9d6ddb55a  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddb563  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddb56c  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddb575  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddb57e  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddb587  sub rsp, 0x30
00007fa9d6ddb58b  movaps [rsp], xmm13
00007fa9d6ddb590  movaps [rsp+0x10], xmm10
00007fa9d6ddb596  movaps [rsp+0x20], xmm14
00007fa9d6ddb59c  lea rdi, [rsp]
00007fa9d6ddb5a0  mov esi, 0x00
00007fa9d6ddb5a5  mov rax, 0x61DF872DB530
00007fa9d6ddb5af  call rax
00007fa9d6ddb5b1  movaps xmm13, [rsp]
00007fa9d6ddb5b6  add rsp, 0x30
00007fa9d6ddb5ba  vmovaps xmm0, [rsp]
00007fa9d6ddb5bf  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddb5c5  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddb5cb  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddb5d1  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddb5d7  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddb5dd  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddb5e3  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddb5e9  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddb5f2  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddb5fb  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddb604  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddb60d  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddb616  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddb61f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddb628  add rsp, 0xF0
00007fa9d6ddb62f  pop r11
00007fa9d6ddb631  pop r10
00007fa9d6ddb633  pop r9
00007fa9d6ddb635  pop r8
00007fa9d6ddb637  pop rsi
00007fa9d6ddb638  pop rdi
00007fa9d6ddb639  pop rdx
00007fa9d6ddb63a  pop rcx
00007fa9d6ddb63b  pop rax
00007fa9d6ddb63c  add rsp, 0x08
00007fa9d6ddb640  jmp 0x00007FA9D6DD666D
00007fa9d6ddb645  sub rsp, 0x08
00007fa9d6ddb649  push rax
00007fa9d6ddb64a  push rcx
00007fa9d6ddb64b  push rdx
00007fa9d6ddb64c  push rdi
00007fa9d6ddb64d  push rsi
00007fa9d6ddb64e  push r8
00007fa9d6ddb650  push r9
00007fa9d6ddb652  push r10
00007fa9d6ddb654  push r11
00007fa9d6ddb656  sub rsp, 0xF0
00007fa9d6ddb65d  vmovaps [rsp], xmm0
00007fa9d6ddb662  vmovaps [rsp+0x10], xmm1
00007fa9d6ddb668  vmovaps [rsp+0x20], xmm2
00007fa9d6ddb66e  vmovaps [rsp+0x30], xmm3
00007fa9d6ddb674  vmovaps [rsp+0x40], xmm4
00007fa9d6ddb67a  vmovaps [rsp+0x50], xmm5
00007fa9d6ddb680  vmovaps [rsp+0x60], xmm6
00007fa9d6ddb686  vmovaps [rsp+0x70], xmm7
00007fa9d6ddb68c  vmovaps [rsp+0x80], xmm8
00007fa9d6ddb695  vmovaps [rsp+0x90], xmm9
00007fa9d6ddb69e  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddb6a7  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddb6b0  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddb6b9  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddb6c2  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddb6cb  sub rsp, 0x30
00007fa9d6ddb6cf  movaps [rsp], xmm14
00007fa9d6ddb6d4  movaps [rsp+0x10], xmm1
00007fa9d6ddb6d9  movaps [rsp+0x20], xmm7
00007fa9d6ddb6de  lea rdi, [rsp]
00007fa9d6ddb6e2  mov esi, 0x00
00007fa9d6ddb6e7  mov rax, 0x61DF872DB530
00007fa9d6ddb6f1  call rax
00007fa9d6ddb6f3  movaps xmm14, [rsp]
00007fa9d6ddb6f8  add rsp, 0x30
00007fa9d6ddb6fc  vmovaps xmm0, [rsp]
00007fa9d6ddb701  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddb707  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddb70d  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddb713  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddb719  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddb71f  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddb725  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddb72b  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddb734  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddb73d  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddb746  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddb74f  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddb758  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddb761  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddb76a  add rsp, 0xF0
00007fa9d6ddb771  pop r11
00007fa9d6ddb773  pop r10
00007fa9d6ddb775  pop r9
00007fa9d6ddb777  pop r8
00007fa9d6ddb779  pop rsi
00007fa9d6ddb77a  pop rdi
00007fa9d6ddb77b  pop rdx
00007fa9d6ddb77c  pop rcx
00007fa9d6ddb77d  pop rax
00007fa9d6ddb77e  add rsp, 0x08
00007fa9d6ddb782  jmp 0x00007FA9D6DD6690
00007fa9d6ddb787  sub rsp, 0x08
00007fa9d6ddb78b  push rax
00007fa9d6ddb78c  push rcx
00007fa9d6ddb78d  push rdx
00007fa9d6ddb78e  push rdi
00007fa9d6ddb78f  push rsi
00007fa9d6ddb790  push r8
00007fa9d6ddb792  push r9
00007fa9d6ddb794  push r10
00007fa9d6ddb796  push r11
00007fa9d6ddb798  sub rsp, 0xF0
00007fa9d6ddb79f  vmovaps [rsp], xmm0
00007fa9d6ddb7a4  vmovaps [rsp+0x10], xmm2
00007fa9d6ddb7aa  vmovaps [rsp+0x20], xmm3
00007fa9d6ddb7b0  vmovaps [rsp+0x30], xmm4
00007fa9d6ddb7b6  vmovaps [rsp+0x40], xmm5
00007fa9d6ddb7bc  vmovaps [rsp+0x50], xmm6
00007fa9d6ddb7c2  vmovaps [rsp+0x60], xmm7
00007fa9d6ddb7c8  vmovaps [rsp+0x70], xmm8
00007fa9d6ddb7ce  vmovaps [rsp+0x80], xmm9
00007fa9d6ddb7d7  vmovaps [rsp+0x90], xmm10
00007fa9d6ddb7e0  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddb7e9  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddb7f2  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddb7fb  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddb804  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddb80d  sub rsp, 0x30
00007fa9d6ddb811  movaps [rsp], xmm1
00007fa9d6ddb815  movaps [rsp+0x10], xmm8
00007fa9d6ddb81b  movaps [rsp+0x20], xmm9
00007fa9d6ddb821  lea rdi, [rsp]
00007fa9d6ddb825  mov esi, 0x00
00007fa9d6ddb82a  mov rax, 0x61DF872DB530
00007fa9d6ddb834  call rax
00007fa9d6ddb836  movaps xmm1, [rsp]
00007fa9d6ddb83a  add rsp, 0x30
00007fa9d6ddb83e  vmovaps xmm0, [rsp]
00007fa9d6ddb843  vmovaps xmm2, [rsp+0x10]
00007fa9d6ddb849  vmovaps xmm3, [rsp+0x20]
00007fa9d6ddb84f  vmovaps xmm4, [rsp+0x30]
00007fa9d6ddb855  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddb85b  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddb861  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddb867  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddb86d  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddb876  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddb87f  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddb888  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddb891  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddb89a  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddb8a3  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddb8ac  add rsp, 0xF0
00007fa9d6ddb8b3  pop r11
00007fa9d6ddb8b5  pop r10
00007fa9d6ddb8b7  pop r9
00007fa9d6ddb8b9  pop r8
00007fa9d6ddb8bb  pop rsi
00007fa9d6ddb8bc  pop rdi
00007fa9d6ddb8bd  pop rdx
00007fa9d6ddb8be  pop rcx
00007fa9d6ddb8bf  pop rax
00007fa9d6ddb8c0  add rsp, 0x08
00007fa9d6ddb8c4  jmp 0x00007FA9D6DD66B2
00007fa9d6ddb8c9  call 0x00007FA9D6CB3E40
00007fa9d6ddb8ce  jmp 0x00007FA9D6DD66C0
00007fa9d6ddb8d3  call 0x00007FA9D6C0C380
00007fa9d6ddb8d8  jmp 0x00007FA9D6DD66CA
00007fa9d6ddb8dd  call 0x00007FA9D6C0D600
00007fa9d6ddb8e2  jmp 0x00007FA9D6DD66D4
00007fa9d6ddb8e7  call 0x00007FA9D6BFF540
00007fa9d6ddb8ec  jmp 0x00007FA9D6DD66DE
00007fa9d6ddb8f1  int3
00007fa9d6ddb8f2  nop [rax+rax*1], ax
00007fa9d6ddb8fb  nop [rax+rax*1], eax
00007fa9d6ddb900  mov eax, [r15+0x48]
00007fa9d6ddb904  lea r14d, [eax+0x01]
00007fa9d6ddb909  mov [rsp+0x10], r14d
00007fa9d6ddb90e  mov r14d, r14d
00007fa9d6ddb911  mov [r15+0x48], r14
00007fa9d6ddb915  xor eax, eax
00007fa9d6ddb917  mov r14d, [rsp+0x10]
00007fa9d6ddb91c  cmp r14d, 0x1F4
00007fa9d6ddb923  cmc
00007fa9d6ddb924  lahf
00007fa9d6ddb925  seto al
00007fa9d6ddb928  mov [r15+0x108], eax
00007fa9d6ddb92f  mov eax, [r15+0x108]
00007fa9d6ddb936  sahf
00007fa9d6ddb937  jnz 0x00007FA9D6DDB969
00007fa9d6ddb939  cmp dword ptr [r15+0x318], 0x00
00007fa9d6ddb941  jz 0x00007FA9D6DE1AB0
00007fa9d6ddb947  nop [rax+rax*1], ax
00007fa9d6ddb950  nop [rax+rax*1], eax
00007fa9d6ddb958  mov eax, 0x410450
00007fa9d6ddb95d  mov [r15+0x100], rax
00007fa9d6ddb964  jmp 0x00007FA9D6BFE110
00007fa9d6ddb969  cmp dword ptr [r15+0x318], 0x00
00007fa9d6ddb971  jz 0x00007FA9D6DDB9A0
00007fa9d6ddb977  nop [rax+rax*1], ax
00007fa9d6ddb980  nop [rax+rax*1], eax
00007fa9d6ddb988  mov eax, 0x410274
00007fa9d6ddb98d  mov [r15+0x100], rax
00007fa9d6ddb994  jmp 0x00007FA9D6BFE110
00007fa9d6ddb999  int3
00007fa9d6ddb99a  int3
00007fa9d6ddb99b  nop [rax+rax*1], eax
00007fa9d6ddb9a0  mov rax, [r15+0x40]
00007fa9d6ddb9a4  movaps xmm1, [r15+0x1D0]
00007fa9d6ddb9ac  vmovaps [rsp+0x10], xmm1
00007fa9d6ddb9b2  vmovaps xmm15, [rsp+0x10]
00007fa9d6ddb9b8  por xmm1, xmm15
00007fa9d6ddb9bd  movaps xmm14, [r15+0x1A0]
00007fa9d6ddb9c5  vmovaps [rsp+0x10], xmm14
00007fa9d6ddb9cb  vmovaps xmm13, [rsp+0x10]
00007fa9d6ddb9d1  por xmm14, xmm13
00007fa9d6ddb9d6  lea r14, [rax+0x30]
00007fa9d6ddb9da  mov r12, [r13+r14*1]
00007fa9d6ddb9df  lea r14, [rax+0x38]
00007fa9d6ddb9e3  mov r11, [r13+r14*1]
00007fa9d6ddb9e8  movq xmm13, r12
00007fa9d6ddb9ed  movq xmm12, r11
00007fa9d6ddb9f2  movq xmm13, xmm13
00007fa9d6ddb9f7  vmovaps [rsp+0x10], xmm13
00007fa9d6ddb9fd  movq xmm13, xmm13
00007fa9d6ddba02  movaps [r15+0x130], xmm13
00007fa9d6ddba0a  movq xmm12, xmm12
00007fa9d6ddba0f  vmovaps [rsp+0x20], xmm12
00007fa9d6ddba15  movq xmm12, xmm12
00007fa9d6ddba1a  movaps [r15+0x280], xmm12
00007fa9d6ddba22  movaps xmm13, [r15+0x270]
00007fa9d6ddba2a  vmovaps [rsp+0x30], xmm13
00007fa9d6ddba30  vmovaps xmm12, [rsp+0x30]
00007fa9d6ddba36  por xmm13, xmm12
00007fa9d6ddba3b  lea r14, [rax+0x20]
00007fa9d6ddba3f  mov r12, [r13+r14*1]
00007fa9d6ddba44  lea r14, [rax+0x28]
00007fa9d6ddba48  mov r11, [r13+r14*1]
00007fa9d6ddba4d  movq xmm12, r12
00007fa9d6ddba52  movq xmm11, r11
00007fa9d6ddba57  movq xmm12, xmm12
00007fa9d6ddba5c  vmovaps [rsp+0x30], xmm12
00007fa9d6ddba62  movq xmm12, xmm12
00007fa9d6ddba67  movaps [r15+0x150], xmm12
00007fa9d6ddba6f  movq xmm11, xmm11
00007fa9d6ddba74  vmovaps [rsp+0x40], xmm11
00007fa9d6ddba7a  movq xmm11, xmm11
00007fa9d6ddba7f  movaps [r15+0x140], xmm11
00007fa9d6ddba87  lea r14, [rax+0x10]
00007fa9d6ddba8b  mov r12, [r13+r14*1]
00007fa9d6ddba90  lea r14, [rax+0x18]
00007fa9d6ddba94  mov r11, [r13+r14*1]
00007fa9d6ddba99  movq xmm12, r12
00007fa9d6ddba9e  movq xmm11, r11
00007fa9d6ddbaa3  movq xmm12, xmm12
00007fa9d6ddbaa8  vmovaps [rsp+0x50], xmm12
00007fa9d6ddbaae  movq xmm12, xmm12
00007fa9d6ddbab3  movaps [r15+0x170], xmm12
00007fa9d6ddbabb  movq xmm11, xmm11
00007fa9d6ddbac0  vmovaps [rsp+0x60], xmm11
00007fa9d6ddbac6  movq xmm11, xmm11
00007fa9d6ddbacb  movaps [r15+0x160], xmm11
00007fa9d6ddbad3  mov r14, [r13+rax*1]
00007fa9d6ddbad8  vmovq xmm12, r14
00007fa9d6ddbadd  vpbroadcastq xmm12, xmm12
00007fa9d6ddbae2  lea r14, [rax+0x08]
00007fa9d6ddbae6  mov rax, [r13+r14*1]
00007fa9d6ddbaeb  movq xmm11, rax
00007fa9d6ddbaf0  movaps [r15+0x230], xmm11
00007fa9d6ddbaf8  mov rax, [r15+0xF8]
00007fa9d6ddbaff  lea r14, [rax+0x50]
00007fa9d6ddbb03  movups xmm11, [r13+r14*1]
00007fa9d6ddbb09  lea r14, [rax+0x60]
00007fa9d6ddbb0d  movups xmm10, [r13+r14*1]
00007fa9d6ddbb13  lea r14, [rax+0x30]
00007fa9d6ddbb17  movups xmm9, [r13+r14*1]
00007fa9d6ddbb1d  mov r14, [r15+0x50]
00007fa9d6ddbb21  mov [r15+0x60], r14
00007fa9d6ddbb25  mov qword ptr [r15+0x58], 0x40
00007fa9d6ddbb2d  movaps xmm8, xmm12
00007fa9d6ddbb31  mulpd xmm8, xmm15
00007fa9d6ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa9d6ddbb3c  ptest xmm7, xmm7
00007fa9d6ddbb41  jnz 0x00007FA9D6DDC96A
00007fa9d6ddbb47  movq xmm15, qword ptr [r15+0x230]
00007fa9d6ddbb50  vmovaps [rsp+0x70], xmm15
00007fa9d6ddbb56  vpermilpd xmm15, xmm15, 0x00
00007fa9d6ddbb5c  movaps xmm7, xmm9
00007fa9d6ddbb60  mulpd xmm7, xmm15
00007fa9d6ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa9d6ddbb6a  ptest xmm6, xmm6
00007fa9d6ddbb6f  jnz 0x00007FA9D6DDCAAE
00007fa9d6ddbb75  vxorps xmm15, xmm15, xmm15
00007fa9d6ddbb7a  vpbroadcastq xmm15, xmm15
00007fa9d6ddbb7f  movaps xmm9, xmm12
00007fa9d6ddbb83  mulpd xmm9, xmm10
00007fa9d6ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa9d6ddbb8e  ptest xmm6, xmm6
00007fa9d6ddbb93  jnz 0x00007FA9D6DDCBF0
00007fa9d6ddbb99  movaps xmm10, xmm12
00007fa9d6ddbb9d  mulpd xmm10, xmm11
00007fa9d6ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007fa9d6ddbba8  ptest xmm6, xmm6
00007fa9d6ddbbad  jnz 0x00007FA9D6DDCD34
00007fa9d6ddbbb3  movaps xmm11, [r15+0x1F0]
00007fa9d6ddbbbb  movaps xmm6, xmm12
00007fa9d6ddbbbf  mulpd xmm6, xmm11
00007fa9d6ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa9d6ddbbc9  ptest xmm5, xmm5
00007fa9d6ddbbce  jnz 0x00007FA9D6DDCE78
00007fa9d6ddbbd4  movaps xmm12, [r15+0x2A0]
00007fa9d6ddbbdc  vmovaps [rsp+0x80], xmm12
00007fa9d6ddbbe5  vmovaps xmm11, [rsp+0x80]
00007fa9d6ddbbee  por xmm12, xmm11
00007fa9d6ddbbf3  movaps xmm11, [r15+0x250]
00007fa9d6ddbbfb  vmovaps [rsp+0x80], xmm11
00007fa9d6ddbc04  vmovaps xmm5, [rsp+0x80]
00007fa9d6ddbc0d  por xmm11, xmm5
00007fa9d6ddbc12  vmovaps xmm4, [rsp+0x70]
00007fa9d6ddbc18  vpermilpd xmm4, xmm4, 0x00
00007fa9d6ddbc1e  movaps xmm3, xmm5
00007fa9d6ddbc21  mulpd xmm3, xmm4
00007fa9d6ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007fa9d6ddbc2a  ptest xmm2, xmm2
00007fa9d6ddbc2f  jnz 0x00007FA9D6DDCFBA
00007fa9d6ddbc35  mov [rsp+0x80], rax
00007fa9d6ddbc3d  xor eax, eax
00007fa9d6ddbc3f  mov r12d, 0x40
00007fa9d6ddbc45  mov r11d, 0x200
00007fa9d6ddbc4b  cmp r12, r11
00007fa9d6ddbc4e  cmc
00007fa9d6ddbc4f  lahf
00007fa9d6ddbc50  seto al
00007fa9d6ddbc53  mov [r15+0x108], eax
00007fa9d6ddbc5a  movaps xmm5, xmm8
00007fa9d6ddbc5e  addpd xmm5, xmm15
00007fa9d6ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007fa9d6ddbc68  ptest xmm4, xmm4
00007fa9d6ddbc6d  jnz 0x00007FA9D6DDD0FA
00007fa9d6ddbc73  movaps xmm8, [r15+0x1B0]
00007fa9d6ddbc7b  movaps xmm4, xmm9
00007fa9d6ddbc7f  addpd xmm4, xmm8
00007fa9d6ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007fa9d6ddbc89  ptest xmm2, xmm2
00007fa9d6ddbc8e  jnz 0x00007FA9D6DDD23C
00007fa9d6ddbc94  movaps xmm9, xmm10
00007fa9d6ddbc98  addpd xmm9, xmm8
00007fa9d6ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007fa9d6ddbca3  ptest xmm2, xmm2
00007fa9d6ddbca8  jnz 0x00007FA9D6DDD37E
00007fa9d6ddbcae  movaps xmm10, [r15+0x2F0]
00007fa9d6ddbcb6  vmovaps [rsp+0x90], xmm10
00007fa9d6ddbcbf  vmovaps xmm8, [rsp+0x90]
00007fa9d6ddbcc8  por xmm10, xmm8
00007fa9d6ddbccd  movaps xmm8, [r15+0x2E0]
00007fa9d6ddbcd5  vmovaps [rsp+0x90], xmm8
00007fa9d6ddbcde  vmovaps xmm2, [rsp+0x90]
00007fa9d6ddbce7  por xmm8, xmm2
00007fa9d6ddbcec  movaps xmm2, [r15+0x2D0]
00007fa9d6ddbcf4  vmovaps [rsp+0x90], xmm2
00007fa9d6ddbcfd  vmovaps [rsp+0xA0], xmm1
00007fa9d6ddbd06  vmovaps xmm1, [rsp+0x90]
00007fa9d6ddbd0f  por xmm2, xmm1
00007fa9d6ddbd13  movaps xmm1, [r15+0x200]
00007fa9d6ddbd1b  vmovaps [rsp+0x90], xmm1
00007fa9d6ddbd24  vmovaps [rsp+0xB0], xmm15
00007fa9d6ddbd2d  vmovaps xmm15, [rsp+0x90]
00007fa9d6ddbd36  por xmm1, xmm15
00007fa9d6ddbd3b  movaps xmm15, [r15+0x1C0]
00007fa9d6ddbd43  vmovaps [rsp+0x90], xmm15
00007fa9d6ddbd4c  vmovaps [rsp+0xC0], xmm1
00007fa9d6ddbd55  vmovaps xmm1, [rsp+0x90]
00007fa9d6ddbd5e  por xmm15, xmm1
00007fa9d6ddbd63  movaps xmm1, [r15+0x190]
00007fa9d6ddbd6b  vmovaps [rsp+0x90], xmm1
00007fa9d6ddbd74  vmovaps [rsp+0xD0], xmm15
00007fa9d6ddbd7d  vmovaps xmm15, [rsp+0x90]
00007fa9d6ddbd86  por xmm1, xmm15
00007fa9d6ddbd8b  movaps xmm15, [r15+0x300]
00007fa9d6ddbd93  vmovaps [rsp+0x90], xmm15
00007fa9d6ddbd9c  vmovaps [rsp+0xE0], xmm1
00007fa9d6ddbda5  vmovaps xmm1, [rsp+0x90]
00007fa9d6ddbdae  por xmm15, xmm1
00007fa9d6ddbdb3  mov rax, [rsp+0x80]
00007fa9d6ddbdbb  lea r12, [rax+0xA0]
00007fa9d6ddbdc2  movups xmm1, [r13+r12*1]
00007fa9d6ddbdc8  lea r12, [rax+0xB0]
00007fa9d6ddbdcf  vmovaps [rsp+0x80], xmm1
00007fa9d6ddbdd8  movups xmm1, [r13+r12*1]
00007fa9d6ddbdde  vmovaps [rsp+0x90], xmm1
00007fa9d6ddbde7  vmovaps [rsp+0xF0], xmm15
00007fa9d6ddbdf0  vmovaps xmm15, [rsp+0xB0]
00007fa9d6ddbdf9  vmovaps [rsp+0xB0], xmm14
00007fa9d6ddbe02  movaps xmm1, xmm6
00007fa9d6ddbe05  addpd xmm1, xmm15
00007fa9d6ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa9d6ddbe0f  ptest xmm14, xmm14
00007fa9d6ddbe15  jnz 0x00007FA9D6DDD4D6
00007fa9d6ddbe1b  lea r12, [rax+0xF0]
00007fa9d6ddbe22  movups xmm15, [r13+r12*1]
00007fa9d6ddbe28  movaps xmm14, xmm4
00007fa9d6ddbe2c  addpd xmm14, xmm3
00007fa9d6ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa9d6ddbe37  ptest xmm6, xmm6
00007fa9d6ddbe3c  jnz 0x00007FA9D6DDD621
00007fa9d6ddbe42  movaps xmm6, xmm9
00007fa9d6ddbe46  addpd xmm6, xmm7
00007fa9d6ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007fa9d6ddbe4f  ptest xmm4, xmm4
00007fa9d6ddbe54  jnz 0x00007FA9D6DDD763
00007fa9d6ddbe5a  vmovaps xmm9, [rsp+0x70]
00007fa9d6ddbe60  vpermilpd xmm9, xmm9, 0x00
00007fa9d6ddbe66  vmovaps xmm4, [rsp+0x90]
00007fa9d6ddbe6f  movaps xmm7, xmm4
00007fa9d6ddbe72  mulpd xmm7, xmm9
00007fa9d6ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007fa9d6ddbe7c  ptest xmm3, xmm3
00007fa9d6ddbe81  jnz 0x00007FA9D6DDD8A4
00007fa9d6ddbe87  vmovaps xmm9, [rsp+0x50]
00007fa9d6ddbe8d  vpermilpd xmm9, xmm9, 0x00
00007fa9d6ddbe93  movaps xmm4, xmm15
00007fa9d6ddbe97  mulpd xmm4, xmm9
00007fa9d6ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa9d6ddbea1  ptest xmm3, xmm3
00007fa9d6ddbea6  jnz 0x00007FA9D6DDD9E5
00007fa9d6ddbeac  lea r12, [rax+0xE0]
00007fa9d6ddbeb3  movups xmm15, [r13+r12*1]
00007fa9d6ddbeb9  vmovaps xmm9, [rsp+0x70]
00007fa9d6ddbebf  vpermilpd xmm9, xmm9, 0x00
00007fa9d6ddbec5  vmovaps [rsp+0x70], xmm1
00007fa9d6ddbecb  vmovaps xmm1, [rsp+0x80]
00007fa9d6ddbed4  vmovaps [rsp+0x80], xmm15
00007fa9d6ddbedd  movaps xmm3, xmm1
00007fa9d6ddbee0  mulpd xmm3, xmm9
00007fa9d6ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007fa9d6ddbeea  ptest xmm15, xmm15
00007fa9d6ddbef0  jnz 0x00007FA9D6DDDB31
00007fa9d6ddbef6  vmovaps xmm1, [rsp+0xF0]
00007fa9d6ddbeff  vmovaps xmm15, [rsp+0xF0]
00007fa9d6ddbf08  por xmm1, xmm15
00007fa9d6ddbf0d  movaps [r15+0x300], xmm1
00007fa9d6ddbf15  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddbf1e  vmovaps xmm9, [rsp+0xE0]
00007fa9d6ddbf27  por xmm15, xmm9
00007fa9d6ddbf2c  movaps [r15+0x190], xmm15
00007fa9d6ddbf34  vmovaps xmm9, [rsp+0x50]
00007fa9d6ddbf3a  vpermilpd xmm9, xmm9, 0x00
00007fa9d6ddbf40  vmovaps [rsp+0x90], xmm1
00007fa9d6ddbf49  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddbf52  vmovaps xmm15, [rsp+0x80]
00007fa9d6ddbf5b  vmovaps [rsp+0x80], xmm14
00007fa9d6ddbf64  movaps xmm1, xmm15
00007fa9d6ddbf68  mulpd xmm1, xmm9
00007fa9d6ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007fa9d6ddbf72  ptest xmm14, xmm14
00007fa9d6ddbf78  jnz 0x00007FA9D6DDDC72
00007fa9d6ddbf7e  lea r12, [rax+0x90]
00007fa9d6ddbf85  movups xmm15, [r13+r12*1]
00007fa9d6ddbf8b  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddbf94  vmovaps xmm9, [rsp+0xD0]
00007fa9d6ddbf9d  por xmm14, xmm9
00007fa9d6ddbfa2  movaps [r15+0x1C0], xmm14
00007fa9d6ddbfaa  vmovaps xmm9, [rsp+0xC0]
00007fa9d6ddbfb3  vmovaps [rsp+0xD0], xmm1
00007fa9d6ddbfbc  vmovaps xmm1, [rsp+0xC0]
00007fa9d6ddbfc5  por xmm9, xmm1
00007fa9d6ddbfca  movaps [r15+0x200], xmm9
00007fa9d6ddbfd2  vmovaps [rsp+0xC0], xmm2
00007fa9d6ddbfdb  vmovaps xmm1, [rsp+0xC0]
00007fa9d6ddbfe4  por xmm2, xmm1
00007fa9d6ddbfe8  movaps [r15+0x2D0], xmm2
00007fa9d6ddbff0  vmovaps [rsp+0xC0], xmm8
00007fa9d6ddbff9  vmovaps xmm1, [rsp+0xC0]
00007fa9d6ddc002  por xmm8, xmm1
00007fa9d6ddc007  movaps [r15+0x2E0], xmm8
00007fa9d6ddc00f  vmovaps [rsp+0xC0], xmm15
00007fa9d6ddc018  movaps xmm1, xmm5
00007fa9d6ddc01b  addpd xmm1, xmm7
00007fa9d6ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007fa9d6ddc024  ptest xmm15, xmm15
00007fa9d6ddc02a  jnz 0x00007FA9D6DDDDBE
00007fa9d6ddc030  vmovaps xmm15, [rsp+0x50]
00007fa9d6ddc036  vpermilpd xmm15, xmm15, 0x00
00007fa9d6ddc03c  vmovaps xmm5, [rsp+0xC0]
00007fa9d6ddc045  vmovaps [rsp+0xC0], xmm1
00007fa9d6ddc04e  movaps xmm7, xmm5
00007fa9d6ddc051  mulpd xmm7, xmm15
00007fa9d6ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007fa9d6ddc05b  ptest xmm1, xmm1
00007fa9d6ddc060  jnz 0x00007FA9D6DDDEFE
00007fa9d6ddc066  lea r12, [rax+0x80]
00007fa9d6ddc06d  movups xmm1, [r13+r12*1]
00007fa9d6ddc073  vmovaps xmm5, [rsp+0x70]
00007fa9d6ddc079  vmovaps [rsp+0x70], xmm1
00007fa9d6ddc07f  movaps xmm15, xmm5
00007fa9d6ddc083  addpd xmm15, xmm3
00007fa9d6ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6ddc08e  ptest xmm1, xmm1
00007fa9d6ddc093  jnz 0x00007FA9D6DDE049
00007fa9d6ddc099  vmovaps xmm5, [rsp+0x80]
00007fa9d6ddc0a2  movaps xmm1, xmm5
00007fa9d6ddc0a5  addpd xmm1, xmm4
00007fa9d6ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007fa9d6ddc0ae  ptest xmm3, xmm3
00007fa9d6ddc0b3  jnz 0x00007FA9D6DDE18B
00007fa9d6ddc0b9  vmovaps [rsp+0x80], xmm10
00007fa9d6ddc0c2  vmovaps xmm5, [rsp+0x80]
00007fa9d6ddc0cb  por xmm10, xmm5
00007fa9d6ddc0d0  movaps [r15+0x2F0], xmm10
00007fa9d6ddc0d8  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddc0de  vpermilpd xmm5, xmm5, 0x00
00007fa9d6ddc0e4  vmovaps xmm3, [rsp+0x70]
00007fa9d6ddc0ea  vmovaps [rsp+0x50], xmm1
00007fa9d6ddc0f0  movaps xmm4, xmm3
00007fa9d6ddc0f3  mulpd xmm4, xmm5
00007fa9d6ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa9d6ddc0fc  ptest xmm1, xmm1
00007fa9d6ddc101  jnz 0x00007FA9D6DDE2CB
00007fa9d6ddc107  lea r12, [rax+0xD0]
00007fa9d6ddc10e  movups xmm1, [r13+r12*1]
00007fa9d6ddc114  vmovaps xmm3, [rsp+0xD0]
00007fa9d6ddc11d  vmovaps [rsp+0x70], xmm1
00007fa9d6ddc123  movaps xmm5, xmm6
00007fa9d6ddc126  addpd xmm5, xmm3
00007fa9d6ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007fa9d6ddc12f  ptest xmm1, xmm1
00007fa9d6ddc134  jnz 0x00007FA9D6DDE415
00007fa9d6ddc13a  vmovaps xmm1, [rsp+0x60]
00007fa9d6ddc140  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc146  movaps xmm6, xmm9
00007fa9d6ddc14a  mulpd xmm6, xmm1
00007fa9d6ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa9d6ddc153  ptest xmm3, xmm3
00007fa9d6ddc158  jnz 0x00007FA9D6DDE555
00007fa9d6ddc15e  movaps [r15+0x260], xmm6
00007fa9d6ddc166  vxorps xmm1, xmm1, xmm1
00007fa9d6ddc16a  vpbroadcastq xmm1, xmm1
00007fa9d6ddc16f  movaps [r15+0x1B0], xmm1
00007fa9d6ddc177  vmovaps xmm1, [rsp+0x60]
00007fa9d6ddc17d  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc183  vmovaps xmm3, [rsp+0x70]
00007fa9d6ddc189  vmovaps [rsp+0x70], xmm15
00007fa9d6ddc18f  movaps xmm9, xmm3
00007fa9d6ddc193  mulpd xmm9, xmm1
00007fa9d6ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa9d6ddc19e  ptest xmm15, xmm15
00007fa9d6ddc1a4  jnz 0x00007FA9D6DDE696
00007fa9d6ddc1aa  lea r12, [rax+0xC0]
00007fa9d6ddc1b1  movups xmm1, [r13+r12*1]
00007fa9d6ddc1b7  vmovaps xmm3, [rsp+0xC0]
00007fa9d6ddc1c0  vmovaps [rsp+0x80], xmm1
00007fa9d6ddc1c9  movaps xmm15, xmm3
00007fa9d6ddc1cd  addpd xmm15, xmm7
00007fa9d6ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6ddc1d8  ptest xmm1, xmm1
00007fa9d6ddc1dd  jnz 0x00007FA9D6DDE7E2
00007fa9d6ddc1e3  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddc1ec  vmovaps xmm1, [rsp+0xC0]
00007fa9d6ddc1f5  por xmm13, xmm1
00007fa9d6ddc1fa  movaps [r15+0x270], xmm13
00007fa9d6ddc202  vmovaps xmm1, [rsp+0xB0]
00007fa9d6ddc20b  vmovaps xmm7, [rsp+0xB0]
00007fa9d6ddc214  por xmm1, xmm7
00007fa9d6ddc218  movaps [r15+0x1A0], xmm1
00007fa9d6ddc220  vmovaps xmm1, [rsp+0x60]
00007fa9d6ddc226  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc22c  vmovaps [rsp+0xB0], xmm1
00007fa9d6ddc235  vmovaps xmm1, [rsp+0x80]
00007fa9d6ddc23e  vmovaps [rsp+0x80], xmm15
00007fa9d6ddc247  vmovaps xmm15, [rsp+0xB0]
00007fa9d6ddc250  vmovaps [rsp+0xB0], xmm14
00007fa9d6ddc259  movaps xmm3, xmm1
00007fa9d6ddc25c  mulpd xmm3, xmm15
00007fa9d6ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007fa9d6ddc266  ptest xmm14, xmm14
00007fa9d6ddc26c  jnz 0x00007FA9D6DDE924
00007fa9d6ddc272  lea r12, [rax+0x20]
00007fa9d6ddc276  movups xmm1, [r13+r12*1]
00007fa9d6ddc27c  movaps [r15+0x110], xmm1
00007fa9d6ddc284  vmovaps xmm14, [rsp+0x70]
00007fa9d6ddc28a  vmovaps [rsp+0x70], xmm1
00007fa9d6ddc290  movaps xmm15, xmm14
00007fa9d6ddc294  addpd xmm15, xmm4
00007fa9d6ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007fa9d6ddc29f  ptest xmm1, xmm1
00007fa9d6ddc2a4  jnz 0x00007FA9D6DDEA6F
00007fa9d6ddc2aa  vmovaps xmm1, [rsp+0x60]
00007fa9d6ddc2b0  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc2b6  movaps xmm14, xmm2
00007fa9d6ddc2ba  mulpd xmm14, xmm1
00007fa9d6ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007fa9d6ddc2c5  ptest xmm4, xmm4
00007fa9d6ddc2ca  jnz 0x00007FA9D6DDEBB2
00007fa9d6ddc2d0  vmovaps xmm4, [rsp+0x50]
00007fa9d6ddc2d6  movaps xmm1, xmm4
00007fa9d6ddc2d9  addpd xmm1, xmm9
00007fa9d6ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa9d6ddc2e3  ptest xmm2, xmm2
00007fa9d6ddc2e8  jnz 0x00007FA9D6DDECF4
00007fa9d6ddc2ee  vmovaps xmm9, [rsp+0x30]
00007fa9d6ddc2f4  vpermilpd xmm9, xmm9, 0x00
00007fa9d6ddc2fa  vmovaps xmm2, [rsp+0x70]
00007fa9d6ddc300  vmovaps [rsp+0x50], xmm1
00007fa9d6ddc306  movaps xmm4, xmm2
00007fa9d6ddc309  mulpd xmm4, xmm9
00007fa9d6ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007fa9d6ddc313  ptest xmm1, xmm1
00007fa9d6ddc318  jnz 0x00007FA9D6DDEE35
00007fa9d6ddc31e  vmovaps xmm1, [rsp+0x30]
00007fa9d6ddc324  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc32a  vmovaps xmm2, [rsp+0x90]
00007fa9d6ddc333  vmovaps [rsp+0x60], xmm15
00007fa9d6ddc339  movaps xmm9, xmm2
00007fa9d6ddc33d  mulpd xmm9, xmm1
00007fa9d6ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007fa9d6ddc348  ptest xmm15, xmm15
00007fa9d6ddc34e  jnz 0x00007FA9D6DDEF76
00007fa9d6ddc354  vmovaps xmm15, [rsp+0x80]
00007fa9d6ddc35d  movaps xmm1, xmm15
00007fa9d6ddc361  addpd xmm1, xmm6
00007fa9d6ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007fa9d6ddc36a  ptest xmm2, xmm2
00007fa9d6ddc36f  jnz 0x00007FA9D6DDF0B8
00007fa9d6ddc375  movaps xmm15, xmm5
00007fa9d6ddc379  addpd xmm15, xmm3
00007fa9d6ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007fa9d6ddc384  ptest xmm6, xmm6
00007fa9d6ddc389  jnz 0x00007FA9D6DDF1F9
00007fa9d6ddc38f  vmovaps xmm6, [rsp+0x30]
00007fa9d6ddc395  vpermilpd xmm6, xmm6, 0x00
00007fa9d6ddc39b  movaps xmm5, xmm8
00007fa9d6ddc39f  mulpd xmm5, xmm6
00007fa9d6ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007fa9d6ddc3a8  ptest xmm3, xmm3
00007fa9d6ddc3ad  jnz 0x00007FA9D6DDF33B
00007fa9d6ddc3b3  vmovaps xmm8, [rsp+0x30]
00007fa9d6ddc3b9  vpermilpd xmm8, xmm8, 0x00
00007fa9d6ddc3bf  movaps xmm6, xmm10
00007fa9d6ddc3c3  mulpd xmm6, xmm8
00007fa9d6ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007fa9d6ddc3cd  ptest xmm3, xmm3
00007fa9d6ddc3d2  jnz 0x00007FA9D6DDF47C
00007fa9d6ddc3d8  vmovaps xmm8, [rsp+0x60]
00007fa9d6ddc3de  movaps xmm10, xmm8
00007fa9d6ddc3e2  addpd xmm10, xmm14
00007fa9d6ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007fa9d6ddc3ed  ptest xmm3, xmm3
00007fa9d6ddc3f2  jnz 0x00007FA9D6DDF5BE
00007fa9d6ddc3f8  vmovaps xmm8, [rsp+0x50]
00007fa9d6ddc3fe  movaps xmm14, xmm8
00007fa9d6ddc402  addpd xmm14, xmm4
00007fa9d6ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007fa9d6ddc40d  ptest xmm3, xmm3
00007fa9d6ddc412  jnz 0x00007FA9D6DDF702
00007fa9d6ddc418  vmovaps xmm8, [rsp+0x40]
00007fa9d6ddc41e  vpermilpd xmm8, xmm8, 0x00
00007fa9d6ddc424  movaps xmm4, xmm13
00007fa9d6ddc428  mulpd xmm4, xmm8
00007fa9d6ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007fa9d6ddc432  ptest xmm3, xmm3
00007fa9d6ddc437  jnz 0x00007FA9D6DDF845
00007fa9d6ddc43d  movaps xmm13, xmm15
00007fa9d6ddc441  addpd xmm13, xmm9
00007fa9d6ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007fa9d6ddc44c  ptest xmm8, xmm8
00007fa9d6ddc452  jnz 0x00007FA9D6DDF987
00007fa9d6ddc458  movaps xmm15, xmm1
00007fa9d6ddc45c  addpd xmm15, xmm5
00007fa9d6ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa9d6ddc467  ptest xmm9, xmm9
00007fa9d6ddc46d  jnz 0x00007FA9D6DDFACB
00007fa9d6ddc473  vmovaps [rsp+0x30], xmm11
00007fa9d6ddc479  vmovaps xmm1, [rsp+0x30]
00007fa9d6ddc47f  por xmm11, xmm1
00007fa9d6ddc484  movaps [r15+0x250], xmm11
00007fa9d6ddc48c  vmovaps [rsp+0x30], xmm12
00007fa9d6ddc492  vmovaps xmm1, [rsp+0x30]
00007fa9d6ddc498  por xmm12, xmm1
00007fa9d6ddc49d  movaps [r15+0x2A0], xmm12
00007fa9d6ddc4a5  vmovaps xmm1, [rsp+0xA0]
00007fa9d6ddc4ae  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddc4b7  por xmm1, xmm11
00007fa9d6ddc4bc  movaps [r15+0x1D0], xmm1
00007fa9d6ddc4c4  lea r12, [rax+0x40]
00007fa9d6ddc4c8  movups xmm1, [r13+r12*1]
00007fa9d6ddc4ce  movaps [r15+0x2C0], xmm1
00007fa9d6ddc4d6  vmovaps xmm11, [rsp+0x40]
00007fa9d6ddc4dc  vpermilpd xmm11, xmm11, 0x00
00007fa9d6ddc4e2  vmovaps xmm8, [rsp+0xE0]
00007fa9d6ddc4eb  movaps xmm9, xmm8
00007fa9d6ddc4ef  mulpd xmm9, xmm11
00007fa9d6ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007fa9d6ddc4fa  ptest xmm5, xmm5
00007fa9d6ddc4ff  jnz 0x00007FA9D6DDFC17
00007fa9d6ddc505  movaps xmm11, xmm10
00007fa9d6ddc509  addpd xmm11, xmm6
00007fa9d6ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007fa9d6ddc514  ptest xmm8, xmm8
00007fa9d6ddc51a  jnz 0x00007FA9D6DDFD5B
00007fa9d6ddc520  movaps xmm10, xmm14
00007fa9d6ddc524  addpd xmm10, xmm4
00007fa9d6ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007fa9d6ddc52f  ptest xmm8, xmm8
00007fa9d6ddc535  jnz 0x00007FA9D6DDFE9E
00007fa9d6ddc53b  vmovaps xmm14, [rsp+0x40]
00007fa9d6ddc541  vpermilpd xmm14, xmm14, 0x00
00007fa9d6ddc547  movaps xmm8, xmm1
00007fa9d6ddc54b  mulpd xmm8, xmm14
00007fa9d6ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa9d6ddc556  ptest xmm6, xmm6
00007fa9d6ddc55b  jnz 0x00007FA9D6DDFFE1
00007fa9d6ddc561  movaps xmm1, [r15+0x2B0]
00007fa9d6ddc569  vmovaps xmm14, [rsp+0x40]
00007fa9d6ddc56f  vpermilpd xmm14, xmm14, 0x00
00007fa9d6ddc575  movaps xmm6, xmm1
00007fa9d6ddc578  mulpd xmm6, xmm14
00007fa9d6ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007fa9d6ddc582  ptest xmm5, xmm5
00007fa9d6ddc587  jnz 0x00007FA9D6DE0124
00007fa9d6ddc58d  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddc593  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc599  movaps xmm14, xmm12
00007fa9d6ddc59d  mulpd xmm14, xmm1
00007fa9d6ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007fa9d6ddc5a8  ptest xmm5, xmm5
00007fa9d6ddc5ad  jnz 0x00007FA9D6DE0265
00007fa9d6ddc5b3  movaps xmm1, xmm13
00007fa9d6ddc5b7  addpd xmm1, xmm9
00007fa9d6ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa9d6ddc5c1  ptest xmm12, xmm12
00007fa9d6ddc5c7  jnz 0x00007FA9D6DE03A8
00007fa9d6ddc5cd  vmovaps xmm13, [rsp+0x10]
00007fa9d6ddc5d3  vpermilpd xmm13, xmm13, 0x00
00007fa9d6ddc5d9  movaps xmm12, xmm7
00007fa9d6ddc5dd  mulpd xmm12, xmm13
00007fa9d6ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa9d6ddc5e8  ptest xmm9, xmm9
00007fa9d6ddc5ee  jnz 0x00007FA9D6DE04EA
00007fa9d6ddc5f4  movaps xmm13, xmm15
00007fa9d6ddc5f8  addpd xmm13, xmm8
00007fa9d6ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007fa9d6ddc603  ptest xmm9, xmm9
00007fa9d6ddc609  jnz 0x00007FA9D6DE062D
00007fa9d6ddc60f  movaps xmm15, [r15+0x290]
00007fa9d6ddc617  vmovaps xmm9, [rsp+0x10]
00007fa9d6ddc61d  vpermilpd xmm9, xmm9, 0x00
00007fa9d6ddc623  movaps xmm8, xmm15
00007fa9d6ddc627  mulpd xmm8, xmm9
00007fa9d6ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007fa9d6ddc632  ptest xmm7, xmm7
00007fa9d6ddc637  jnz 0x00007FA9D6DE0771
00007fa9d6ddc63d  movaps xmm15, xmm11
00007fa9d6ddc641  addpd xmm15, xmm6
00007fa9d6ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007fa9d6ddc64c  ptest xmm9, xmm9
00007fa9d6ddc652  jnz 0x00007FA9D6DE08B5
00007fa9d6ddc658  movaps xmm11, [r15+0x1E0]
00007fa9d6ddc660  vmovaps xmm9, [rsp+0x10]
00007fa9d6ddc666  vpermilpd xmm9, xmm9, 0x00
00007fa9d6ddc66c  movaps xmm7, xmm11
00007fa9d6ddc670  mulpd xmm7, xmm9
00007fa9d6ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa9d6ddc67a  ptest xmm6, xmm6
00007fa9d6ddc67f  jnz 0x00007FA9D6DE09F8
00007fa9d6ddc685  movaps xmm11, xmm10
00007fa9d6ddc689  addpd xmm11, xmm14
00007fa9d6ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007fa9d6ddc694  ptest xmm9, xmm9
00007fa9d6ddc69a  jnz 0x00007FA9D6DE0B3A
00007fa9d6ddc6a0  lea r12, [rax+0x70]
00007fa9d6ddc6a4  movups xmm14, [r13+r12*1]
00007fa9d6ddc6aa  movaps [r15+0x240], xmm14
00007fa9d6ddc6b2  movaps xmm10, xmm1
00007fa9d6ddc6b6  addpd xmm10, xmm12
00007fa9d6ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007fa9d6ddc6c1  ptest xmm9, xmm9
00007fa9d6ddc6c7  jnz 0x00007FA9D6DE0C88
00007fa9d6ddc6cd  movaps [r15+0x170], xmm10
00007fa9d6ddc6d5  vmovaps xmm1, [rsp+0x20]
00007fa9d6ddc6db  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc6e1  movaps xmm12, xmm14
00007fa9d6ddc6e5  mulpd xmm12, xmm1
00007fa9d6ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007fa9d6ddc6f0  ptest xmm9, xmm9
00007fa9d6ddc6f6  jnz 0x00007FA9D6DE0DCB
00007fa9d6ddc6fc  vmovaps xmm1, [rsp+0x20]
00007fa9d6ddc702  vpermilpd xmm1, xmm1, 0x00
00007fa9d6ddc708  vmovaps xmm9, [rsp+0xB0]
00007fa9d6ddc711  movaps xmm14, xmm9
00007fa9d6ddc715  mulpd xmm14, xmm1
00007fa9d6ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007fa9d6ddc720  ptest xmm6, xmm6
00007fa9d6ddc725  jnz 0x00007FA9D6DE0F0E
00007fa9d6ddc72b  movaps [r15+0x180], xmm14
00007fa9d6ddc733  movaps xmm1, xmm13
00007fa9d6ddc737  addpd xmm1, xmm8
00007fa9d6ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007fa9d6ddc741  ptest xmm9, xmm9
00007fa9d6ddc747  jnz 0x00007FA9D6DE1051
00007fa9d6ddc74d  movaps [r15+0x210], xmm1
00007fa9d6ddc755  movups xmm13, [r13+rax*1]
00007fa9d6ddc75b  lea r12, [rax+0x10]
00007fa9d6ddc75f  movups xmm9, [r13+r12*1]
00007fa9d6ddc765  movaps [r15+0x230], xmm9
00007fa9d6ddc76d  movaps xmm8, xmm15
00007fa9d6ddc771  addpd xmm8, xmm7
00007fa9d6ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007fa9d6ddc77c  ptest xmm6, xmm6
00007fa9d6ddc781  jnz 0x00007FA9D6DE11A7
00007fa9d6ddc787  movaps [r15+0x130], xmm8
00007fa9d6ddc78f  vmovaps xmm15, [rsp+0x20]
00007fa9d6ddc795  vpermilpd xmm15, xmm15, 0x00
00007fa9d6ddc79b  movaps xmm7, xmm9
00007fa9d6ddc79f  mulpd xmm7, xmm15
00007fa9d6ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007fa9d6ddc7a9  ptest xmm6, xmm6
00007fa9d6ddc7ae  jnz 0x00007FA9D6DE12EA
00007fa9d6ddc7b4  movaps [r15+0x220], xmm7
00007fa9d6ddc7bc  vmovaps xmm15, [rsp+0x20]
00007fa9d6ddc7c2  vpermilpd xmm15, xmm15, 0x00
00007fa9d6ddc7c8  movaps xmm9, xmm13
00007fa9d6ddc7cc  mulpd xmm9, xmm15
00007fa9d6ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007fa9d6ddc7d7  ptest xmm6, xmm6
00007fa9d6ddc7dc  jnz 0x00007FA9D6DE142C
00007fa9d6ddc7e2  movaps xmm15, xmm11
00007fa9d6ddc7e6  addpd xmm15, xmm12
00007fa9d6ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007fa9d6ddc7f1  ptest xmm13, xmm13
00007fa9d6ddc7f7  jnz 0x00007FA9D6DE1570
00007fa9d6ddc7fd  movaps [r15+0x140], xmm15
00007fa9d6ddc805  movaps xmm13, xmm10
00007fa9d6ddc809  addpd xmm13, xmm14
00007fa9d6ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007fa9d6ddc814  ptest xmm12, xmm12
00007fa9d6ddc81a  jnz 0x00007FA9D6DE16B4
00007fa9d6ddc820  movaps [r15+0x150], xmm13
00007fa9d6ddc828  movaps xmm14, xmm1
00007fa9d6ddc82c  addpd xmm14, xmm7
00007fa9d6ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007fa9d6ddc837  ptest xmm12, xmm12
00007fa9d6ddc83d  jnz 0x00007FA9D6DE17F8
00007fa9d6ddc843  movaps [r15+0x160], xmm14
00007fa9d6ddc84b  movaps xmm1, xmm8
00007fa9d6ddc84f  addpd xmm1, xmm9
00007fa9d6ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007fa9d6ddc859  ptest xmm12, xmm12
00007fa9d6ddc85f  jnz 0x00007FA9D6DE193A
00007fa9d6ddc865  movaps [r15+0x120], xmm1
00007fa9d6ddc86d  movups [r13+r14*1], xmm15
00007fa9d6ddc873  lea rax, [r14+0x10]
00007fa9d6ddc877  movups [r13+rax*1], xmm13
00007fa9d6ddc87d  lea rax, [r14+0x20]
00007fa9d6ddc881  movups [r13+rax*1], xmm14
00007fa9d6ddc887  lea rax, [r14+0x30]
00007fa9d6ddc88b  movups [r13+rax*1], xmm1
00007fa9d6ddc891  mov eax, [r15+0x108]
00007fa9d6ddc898  sahf
00007fa9d6ddc899  jnz 0x00007FA9D6DDC8CB
00007fa9d6ddc89b  cmp dword ptr [r15+0x318], 0x00
00007fa9d6ddc8a3  jz 0x00007FA9D6DDB900
00007fa9d6ddc8a9  nop [rax+rax*1], ax
00007fa9d6ddc8b2  nop [rax+rax*1], eax
00007fa9d6ddc8ba  mov eax, 0x410444
00007fa9d6ddc8bf  mov [r15+0x100], rax
00007fa9d6ddc8c6  jmp 0x00007FA9D6BFE110
00007fa9d6ddc8cb  cmp dword ptr [r15+0x318], 0x00
00007fa9d6ddc8d3  jz 0x00007FA9D6DD57E0
00007fa9d6ddc8d9  nop [rax+rax*1], ax
00007fa9d6ddc8e2  nop [rax+rax*1], eax
00007fa9d6ddc8ea  mov eax, 0x410278
00007fa9d6ddc8ef  mov [r15+0x100], rax
00007fa9d6ddc8f6  jmp 0x00007FA9D6BFE110
00007fa9d6ddc8fb  int3
00007fa9d6ddc8fc  call 0x00007FA9D6CE27E0
00007fa9d6ddc901  jmp 0x00007FA9D6DDB9DF
00007fa9d6ddc906  call 0x00007FA9D6CE1570
00007fa9d6ddc90b  jmp 0x00007FA9D6DDB9E8
00007fa9d6ddc910  call 0x00007FA9D6CE27E0
00007fa9d6ddc915  jmp 0x00007FA9D6DDBA44
00007fa9d6ddc91a  call 0x00007FA9D6CE1570
00007fa9d6ddc91f  jmp 0x00007FA9D6DDBA4D
00007fa9d6ddc924  call 0x00007FA9D6CE27E0
00007fa9d6ddc929  jmp 0x00007FA9D6DDBA90
00007fa9d6ddc92e  call 0x00007FA9D6CE1570
00007fa9d6ddc933  jmp 0x00007FA9D6DDBA99
00007fa9d6ddc938  call 0x00007FA9D6C0DC20
00007fa9d6ddc93d  jmp 0x00007FA9D6DDBAD8
00007fa9d6ddc942  call 0x00007FA9D6CD59C0
00007fa9d6ddc947  jmp 0x00007FA9D6DDBAEB
00007fa9d6ddc94c  call 0x00007FA9D6CE0E30
00007fa9d6ddc951  jmp 0x00007FA9D6DDBB09
00007fa9d6ddc956  call 0x00007FA9D6CDFBC0
00007fa9d6ddc95b  jmp 0x00007FA9D6DDBB13
00007fa9d6ddc960  call 0x00007FA9D6CDE950
00007fa9d6ddc965  jmp 0x00007FA9D6DDBB1D
00007fa9d6ddc96a  sub rsp, 0x08
00007fa9d6ddc96e  push rax
00007fa9d6ddc96f  push rcx
00007fa9d6ddc970  push rdx
00007fa9d6ddc971  push rdi
00007fa9d6ddc972  push rsi
00007fa9d6ddc973  push r8
00007fa9d6ddc975  push r9
00007fa9d6ddc977  push r10
00007fa9d6ddc979  push r11
00007fa9d6ddc97b  sub rsp, 0xF0
00007fa9d6ddc982  vmovaps [rsp], xmm0
00007fa9d6ddc987  vmovaps [rsp+0x10], xmm1
00007fa9d6ddc98d  vmovaps [rsp+0x20], xmm2
00007fa9d6ddc993  vmovaps [rsp+0x30], xmm3
00007fa9d6ddc999  vmovaps [rsp+0x40], xmm4
00007fa9d6ddc99f  vmovaps [rsp+0x50], xmm5
00007fa9d6ddc9a5  vmovaps [rsp+0x60], xmm6
00007fa9d6ddc9ab  vmovaps [rsp+0x70], xmm7
00007fa9d6ddc9b1  vmovaps [rsp+0x80], xmm9
00007fa9d6ddc9ba  vmovaps [rsp+0x90], xmm10
00007fa9d6ddc9c3  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddc9cc  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddc9d5  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddc9de  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddc9e7  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddc9f0  sub rsp, 0x30
00007fa9d6ddc9f4  movaps [rsp], xmm8
00007fa9d6ddc9f9  movaps [rsp+0x10], xmm12
00007fa9d6ddc9ff  movaps [rsp+0x20], xmm15
00007fa9d6ddca05  lea rdi, [rsp]
00007fa9d6ddca09  mov esi, 0x00
00007fa9d6ddca0e  mov rax, 0x61DF872DB530
00007fa9d6ddca18  call rax
00007fa9d6ddca1a  movaps xmm8, [rsp]
00007fa9d6ddca1f  add rsp, 0x30
00007fa9d6ddca23  vmovaps xmm0, [rsp]
00007fa9d6ddca28  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddca2e  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddca34  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddca3a  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddca40  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddca46  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddca4c  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddca52  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddca5b  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddca64  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddca6d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddca76  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddca7f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddca88  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddca91  add rsp, 0xF0
00007fa9d6ddca98  pop r11
00007fa9d6ddca9a  pop r10
00007fa9d6ddca9c  pop r9
00007fa9d6ddca9e  pop r8
00007fa9d6ddcaa0  pop rsi
00007fa9d6ddcaa1  pop rdi
00007fa9d6ddcaa2  pop rdx
00007fa9d6ddcaa3  pop rcx
00007fa9d6ddcaa4  pop rax
00007fa9d6ddcaa5  add rsp, 0x08
00007fa9d6ddcaa9  jmp 0x00007FA9D6DDBB47
00007fa9d6ddcaae  sub rsp, 0x08
00007fa9d6ddcab2  push rax
00007fa9d6ddcab3  push rcx
00007fa9d6ddcab4  push rdx
00007fa9d6ddcab5  push rdi
00007fa9d6ddcab6  push rsi
00007fa9d6ddcab7  push r8
00007fa9d6ddcab9  push r9
00007fa9d6ddcabb  push r10
00007fa9d6ddcabd  push r11
00007fa9d6ddcabf  sub rsp, 0xF0
00007fa9d6ddcac6  vmovaps [rsp], xmm0
00007fa9d6ddcacb  vmovaps [rsp+0x10], xmm1
00007fa9d6ddcad1  vmovaps [rsp+0x20], xmm2
00007fa9d6ddcad7  vmovaps [rsp+0x30], xmm3
00007fa9d6ddcadd  vmovaps [rsp+0x40], xmm4
00007fa9d6ddcae3  vmovaps [rsp+0x50], xmm5
00007fa9d6ddcae9  vmovaps [rsp+0x60], xmm6
00007fa9d6ddcaef  vmovaps [rsp+0x70], xmm8
00007fa9d6ddcaf5  vmovaps [rsp+0x80], xmm9
00007fa9d6ddcafe  vmovaps [rsp+0x90], xmm10
00007fa9d6ddcb07  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddcb10  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddcb19  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddcb22  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddcb2b  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddcb34  sub rsp, 0x30
00007fa9d6ddcb38  movaps [rsp], xmm7
00007fa9d6ddcb3c  movaps [rsp+0x10], xmm9
00007fa9d6ddcb42  movaps [rsp+0x20], xmm15
00007fa9d6ddcb48  lea rdi, [rsp]
00007fa9d6ddcb4c  mov esi, 0x00
00007fa9d6ddcb51  mov rax, 0x61DF872DB530
00007fa9d6ddcb5b  call rax
00007fa9d6ddcb5d  movaps xmm7, [rsp]
00007fa9d6ddcb61  add rsp, 0x30
00007fa9d6ddcb65  vmovaps xmm0, [rsp]
00007fa9d6ddcb6a  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddcb70  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddcb76  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddcb7c  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddcb82  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddcb88  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddcb8e  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddcb94  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddcb9d  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddcba6  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddcbaf  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddcbb8  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddcbc1  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddcbca  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddcbd3  add rsp, 0xF0
00007fa9d6ddcbda  pop r11
00007fa9d6ddcbdc  pop r10
00007fa9d6ddcbde  pop r9
00007fa9d6ddcbe0  pop r8
00007fa9d6ddcbe2  pop rsi
00007fa9d6ddcbe3  pop rdi
00007fa9d6ddcbe4  pop rdx
00007fa9d6ddcbe5  pop rcx
00007fa9d6ddcbe6  pop rax
00007fa9d6ddcbe7  add rsp, 0x08
00007fa9d6ddcbeb  jmp 0x00007FA9D6DDBB75
00007fa9d6ddcbf0  sub rsp, 0x08
00007fa9d6ddcbf4  push rax
00007fa9d6ddcbf5  push rcx
00007fa9d6ddcbf6  push rdx
00007fa9d6ddcbf7  push rdi
00007fa9d6ddcbf8  push rsi
00007fa9d6ddcbf9  push r8
00007fa9d6ddcbfb  push r9
00007fa9d6ddcbfd  push r10
00007fa9d6ddcbff  push r11
00007fa9d6ddcc01  sub rsp, 0xF0
00007fa9d6ddcc08  vmovaps [rsp], xmm0
00007fa9d6ddcc0d  vmovaps [rsp+0x10], xmm1
00007fa9d6ddcc13  vmovaps [rsp+0x20], xmm2
00007fa9d6ddcc19  vmovaps [rsp+0x30], xmm3
00007fa9d6ddcc1f  vmovaps [rsp+0x40], xmm4
00007fa9d6ddcc25  vmovaps [rsp+0x50], xmm5
00007fa9d6ddcc2b  vmovaps [rsp+0x60], xmm6
00007fa9d6ddcc31  vmovaps [rsp+0x70], xmm7
00007fa9d6ddcc37  vmovaps [rsp+0x80], xmm8
00007fa9d6ddcc40  vmovaps [rsp+0x90], xmm10
00007fa9d6ddcc49  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddcc52  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddcc5b  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddcc64  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddcc6d  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddcc76  sub rsp, 0x30
00007fa9d6ddcc7a  movaps [rsp], xmm9
00007fa9d6ddcc7f  movaps [rsp+0x10], xmm12
00007fa9d6ddcc85  movaps [rsp+0x20], xmm10
00007fa9d6ddcc8b  lea rdi, [rsp]
00007fa9d6ddcc8f  mov esi, 0x00
00007fa9d6ddcc94  mov rax, 0x61DF872DB530
00007fa9d6ddcc9e  call rax
00007fa9d6ddcca0  movaps xmm9, [rsp]
00007fa9d6ddcca5  add rsp, 0x30
00007fa9d6ddcca9  vmovaps xmm0, [rsp]
00007fa9d6ddccae  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddccb4  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddccba  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddccc0  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddccc6  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddcccc  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddccd2  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddccd8  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddcce1  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddccea  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddccf3  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddccfc  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddcd05  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddcd0e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddcd17  add rsp, 0xF0
00007fa9d6ddcd1e  pop r11
00007fa9d6ddcd20  pop r10
00007fa9d6ddcd22  pop r9
00007fa9d6ddcd24  pop r8
00007fa9d6ddcd26  pop rsi
00007fa9d6ddcd27  pop rdi
00007fa9d6ddcd28  pop rdx
00007fa9d6ddcd29  pop rcx
00007fa9d6ddcd2a  pop rax
00007fa9d6ddcd2b  add rsp, 0x08
00007fa9d6ddcd2f  jmp 0x00007FA9D6DDBB99
00007fa9d6ddcd34  sub rsp, 0x08
00007fa9d6ddcd38  push rax
00007fa9d6ddcd39  push rcx
00007fa9d6ddcd3a  push rdx
00007fa9d6ddcd3b  push rdi
00007fa9d6ddcd3c  push rsi
00007fa9d6ddcd3d  push r8
00007fa9d6ddcd3f  push r9
00007fa9d6ddcd41  push r10
00007fa9d6ddcd43  push r11
00007fa9d6ddcd45  sub rsp, 0xF0
00007fa9d6ddcd4c  vmovaps [rsp], xmm0
00007fa9d6ddcd51  vmovaps [rsp+0x10], xmm1
00007fa9d6ddcd57  vmovaps [rsp+0x20], xmm2
00007fa9d6ddcd5d  vmovaps [rsp+0x30], xmm3
00007fa9d6ddcd63  vmovaps [rsp+0x40], xmm4
00007fa9d6ddcd69  vmovaps [rsp+0x50], xmm5
00007fa9d6ddcd6f  vmovaps [rsp+0x60], xmm6
00007fa9d6ddcd75  vmovaps [rsp+0x70], xmm7
00007fa9d6ddcd7b  vmovaps [rsp+0x80], xmm8
00007fa9d6ddcd84  vmovaps [rsp+0x90], xmm9
00007fa9d6ddcd8d  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddcd96  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddcd9f  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddcda8  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddcdb1  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddcdba  sub rsp, 0x30
00007fa9d6ddcdbe  movaps [rsp], xmm10
00007fa9d6ddcdc3  movaps [rsp+0x10], xmm12
00007fa9d6ddcdc9  movaps [rsp+0x20], xmm11
00007fa9d6ddcdcf  lea rdi, [rsp]
00007fa9d6ddcdd3  mov esi, 0x00
00007fa9d6ddcdd8  mov rax, 0x61DF872DB530
00007fa9d6ddcde2  call rax
00007fa9d6ddcde4  movaps xmm10, [rsp]
00007fa9d6ddcde9  add rsp, 0x30
00007fa9d6ddcded  vmovaps xmm0, [rsp]
00007fa9d6ddcdf2  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddcdf8  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddcdfe  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddce04  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddce0a  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddce10  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddce16  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddce1c  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddce25  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddce2e  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddce37  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddce40  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddce49  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddce52  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddce5b  add rsp, 0xF0
00007fa9d6ddce62  pop r11
00007fa9d6ddce64  pop r10
00007fa9d6ddce66  pop r9
00007fa9d6ddce68  pop r8
00007fa9d6ddce6a  pop rsi
00007fa9d6ddce6b  pop rdi
00007fa9d6ddce6c  pop rdx
00007fa9d6ddce6d  pop rcx
00007fa9d6ddce6e  pop rax
00007fa9d6ddce6f  add rsp, 0x08
00007fa9d6ddce73  jmp 0x00007FA9D6DDBBB3
00007fa9d6ddce78  sub rsp, 0x08
00007fa9d6ddce7c  push rax
00007fa9d6ddce7d  push rcx
00007fa9d6ddce7e  push rdx
00007fa9d6ddce7f  push rdi
00007fa9d6ddce80  push rsi
00007fa9d6ddce81  push r8
00007fa9d6ddce83  push r9
00007fa9d6ddce85  push r10
00007fa9d6ddce87  push r11
00007fa9d6ddce89  sub rsp, 0xF0
00007fa9d6ddce90  vmovaps [rsp], xmm0
00007fa9d6ddce95  vmovaps [rsp+0x10], xmm1
00007fa9d6ddce9b  vmovaps [rsp+0x20], xmm2
00007fa9d6ddcea1  vmovaps [rsp+0x30], xmm3
00007fa9d6ddcea7  vmovaps [rsp+0x40], xmm4
00007fa9d6ddcead  vmovaps [rsp+0x50], xmm5
00007fa9d6ddceb3  vmovaps [rsp+0x60], xmm7
00007fa9d6ddceb9  vmovaps [rsp+0x70], xmm8
00007fa9d6ddcebf  vmovaps [rsp+0x80], xmm9
00007fa9d6ddcec8  vmovaps [rsp+0x90], xmm10
00007fa9d6ddced1  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddceda  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddcee3  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddceec  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddcef5  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddcefe  sub rsp, 0x30
00007fa9d6ddcf02  movaps [rsp], xmm6
00007fa9d6ddcf06  movaps [rsp+0x10], xmm12
00007fa9d6ddcf0c  movaps [rsp+0x20], xmm11
00007fa9d6ddcf12  lea rdi, [rsp]
00007fa9d6ddcf16  mov esi, 0x00
00007fa9d6ddcf1b  mov rax, 0x61DF872DB530
00007fa9d6ddcf25  call rax
00007fa9d6ddcf27  movaps xmm6, [rsp]
00007fa9d6ddcf2b  add rsp, 0x30
00007fa9d6ddcf2f  vmovaps xmm0, [rsp]
00007fa9d6ddcf34  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddcf3a  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddcf40  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddcf46  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddcf4c  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddcf52  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddcf58  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddcf5e  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddcf67  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddcf70  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddcf79  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddcf82  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddcf8b  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddcf94  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddcf9d  add rsp, 0xF0
00007fa9d6ddcfa4  pop r11
00007fa9d6ddcfa6  pop r10
00007fa9d6ddcfa8  pop r9
00007fa9d6ddcfaa  pop r8
00007fa9d6ddcfac  pop rsi
00007fa9d6ddcfad  pop rdi
00007fa9d6ddcfae  pop rdx
00007fa9d6ddcfaf  pop rcx
00007fa9d6ddcfb0  pop rax
00007fa9d6ddcfb1  add rsp, 0x08
00007fa9d6ddcfb5  jmp 0x00007FA9D6DDBBD4
00007fa9d6ddcfba  sub rsp, 0x08
00007fa9d6ddcfbe  push rax
00007fa9d6ddcfbf  push rcx
00007fa9d6ddcfc0  push rdx
00007fa9d6ddcfc1  push rdi
00007fa9d6ddcfc2  push rsi
00007fa9d6ddcfc3  push r8
00007fa9d6ddcfc5  push r9
00007fa9d6ddcfc7  push r10
00007fa9d6ddcfc9  push r11
00007fa9d6ddcfcb  sub rsp, 0xF0
00007fa9d6ddcfd2  vmovaps [rsp], xmm0
00007fa9d6ddcfd7  vmovaps [rsp+0x10], xmm1
00007fa9d6ddcfdd  vmovaps [rsp+0x20], xmm2
00007fa9d6ddcfe3  vmovaps [rsp+0x30], xmm4
00007fa9d6ddcfe9  vmovaps [rsp+0x40], xmm5
00007fa9d6ddcfef  vmovaps [rsp+0x50], xmm6
00007fa9d6ddcff5  vmovaps [rsp+0x60], xmm7
00007fa9d6ddcffb  vmovaps [rsp+0x70], xmm8
00007fa9d6ddd001  vmovaps [rsp+0x80], xmm9
00007fa9d6ddd00a  vmovaps [rsp+0x90], xmm10
00007fa9d6ddd013  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddd01c  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddd025  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddd02e  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddd037  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd040  sub rsp, 0x30
00007fa9d6ddd044  movaps [rsp], xmm3
00007fa9d6ddd048  movaps [rsp+0x10], xmm5
00007fa9d6ddd04d  movaps [rsp+0x20], xmm4
00007fa9d6ddd052  lea rdi, [rsp]
00007fa9d6ddd056  mov esi, 0x00
00007fa9d6ddd05b  mov rax, 0x61DF872DB530
00007fa9d6ddd065  call rax
00007fa9d6ddd067  movaps xmm3, [rsp]
00007fa9d6ddd06b  add rsp, 0x30
00007fa9d6ddd06f  vmovaps xmm0, [rsp]
00007fa9d6ddd074  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddd07a  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddd080  vmovaps xmm4, [rsp+0x30]
00007fa9d6ddd086  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddd08c  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddd092  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddd098  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddd09e  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddd0a7  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddd0b0  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddd0b9  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddd0c2  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddd0cb  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddd0d4  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd0dd  add rsp, 0xF0
00007fa9d6ddd0e4  pop r11
00007fa9d6ddd0e6  pop r10
00007fa9d6ddd0e8  pop r9
00007fa9d6ddd0ea  pop r8
00007fa9d6ddd0ec  pop rsi
00007fa9d6ddd0ed  pop rdi
00007fa9d6ddd0ee  pop rdx
00007fa9d6ddd0ef  pop rcx
00007fa9d6ddd0f0  pop rax
00007fa9d6ddd0f1  add rsp, 0x08
00007fa9d6ddd0f5  jmp 0x00007FA9D6DDBC35
00007fa9d6ddd0fa  sub rsp, 0x08
00007fa9d6ddd0fe  push rax
00007fa9d6ddd0ff  push rcx
00007fa9d6ddd100  push rdx
00007fa9d6ddd101  push rdi
00007fa9d6ddd102  push rsi
00007fa9d6ddd103  push r8
00007fa9d6ddd105  push r9
00007fa9d6ddd107  push r10
00007fa9d6ddd109  push r11
00007fa9d6ddd10b  sub rsp, 0xF0
00007fa9d6ddd112  vmovaps [rsp], xmm0
00007fa9d6ddd117  vmovaps [rsp+0x10], xmm1
00007fa9d6ddd11d  vmovaps [rsp+0x20], xmm2
00007fa9d6ddd123  vmovaps [rsp+0x30], xmm3
00007fa9d6ddd129  vmovaps [rsp+0x40], xmm4
00007fa9d6ddd12f  vmovaps [rsp+0x50], xmm6
00007fa9d6ddd135  vmovaps [rsp+0x60], xmm7
00007fa9d6ddd13b  vmovaps [rsp+0x70], xmm8
00007fa9d6ddd141  vmovaps [rsp+0x80], xmm9
00007fa9d6ddd14a  vmovaps [rsp+0x90], xmm10
00007fa9d6ddd153  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddd15c  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddd165  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddd16e  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddd177  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd180  sub rsp, 0x30
00007fa9d6ddd184  movaps [rsp], xmm5
00007fa9d6ddd188  movaps [rsp+0x10], xmm8
00007fa9d6ddd18e  movaps [rsp+0x20], xmm15
00007fa9d6ddd194  lea rdi, [rsp]
00007fa9d6ddd198  mov esi, 0x00
00007fa9d6ddd19d  mov rax, 0x61DF872DB530
00007fa9d6ddd1a7  call rax
00007fa9d6ddd1a9  movaps xmm5, [rsp]
00007fa9d6ddd1ad  add rsp, 0x30
00007fa9d6ddd1b1  vmovaps xmm0, [rsp]
00007fa9d6ddd1b6  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddd1bc  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddd1c2  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddd1c8  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddd1ce  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddd1d4  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddd1da  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddd1e0  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddd1e9  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddd1f2  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddd1fb  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddd204  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddd20d  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddd216  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd21f  add rsp, 0xF0
00007fa9d6ddd226  pop r11
00007fa9d6ddd228  pop r10
00007fa9d6ddd22a  pop r9
00007fa9d6ddd22c  pop r8
00007fa9d6ddd22e  pop rsi
00007fa9d6ddd22f  pop rdi
00007fa9d6ddd230  pop rdx
00007fa9d6ddd231  pop rcx
00007fa9d6ddd232  pop rax
00007fa9d6ddd233  add rsp, 0x08
00007fa9d6ddd237  jmp 0x00007FA9D6DDBC73
00007fa9d6ddd23c  sub rsp, 0x08
00007fa9d6ddd240  push rax
00007fa9d6ddd241  push rcx
00007fa9d6ddd242  push rdx
00007fa9d6ddd243  push rdi
00007fa9d6ddd244  push rsi
00007fa9d6ddd245  push r8
00007fa9d6ddd247  push r9
00007fa9d6ddd249  push r10
00007fa9d6ddd24b  push r11
00007fa9d6ddd24d  sub rsp, 0xF0
00007fa9d6ddd254  vmovaps [rsp], xmm0
00007fa9d6ddd259  vmovaps [rsp+0x10], xmm1
00007fa9d6ddd25f  vmovaps [rsp+0x20], xmm2
00007fa9d6ddd265  vmovaps [rsp+0x30], xmm3
00007fa9d6ddd26b  vmovaps [rsp+0x40], xmm5
00007fa9d6ddd271  vmovaps [rsp+0x50], xmm6
00007fa9d6ddd277  vmovaps [rsp+0x60], xmm7
00007fa9d6ddd27d  vmovaps [rsp+0x70], xmm8
00007fa9d6ddd283  vmovaps [rsp+0x80], xmm9
00007fa9d6ddd28c  vmovaps [rsp+0x90], xmm10
00007fa9d6ddd295  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddd29e  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddd2a7  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddd2b0  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddd2b9  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd2c2  sub rsp, 0x30
00007fa9d6ddd2c6  movaps [rsp], xmm4
00007fa9d6ddd2ca  movaps [rsp+0x10], xmm9
00007fa9d6ddd2d0  movaps [rsp+0x20], xmm8
00007fa9d6ddd2d6  lea rdi, [rsp]
00007fa9d6ddd2da  mov esi, 0x00
00007fa9d6ddd2df  mov rax, 0x61DF872DB530
00007fa9d6ddd2e9  call rax
00007fa9d6ddd2eb  movaps xmm4, [rsp]
00007fa9d6ddd2ef  add rsp, 0x30
00007fa9d6ddd2f3  vmovaps xmm0, [rsp]
00007fa9d6ddd2f8  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddd2fe  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddd304  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddd30a  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddd310  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddd316  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddd31c  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddd322  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddd32b  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddd334  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddd33d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddd346  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddd34f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddd358  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd361  add rsp, 0xF0
00007fa9d6ddd368  pop r11
00007fa9d6ddd36a  pop r10
00007fa9d6ddd36c  pop r9
00007fa9d6ddd36e  pop r8
00007fa9d6ddd370  pop rsi
00007fa9d6ddd371  pop rdi
00007fa9d6ddd372  pop rdx
00007fa9d6ddd373  pop rcx
00007fa9d6ddd374  pop rax
00007fa9d6ddd375  add rsp, 0x08
00007fa9d6ddd379  jmp 0x00007FA9D6DDBC94
00007fa9d6ddd37e  sub rsp, 0x08
00007fa9d6ddd382  push rax
00007fa9d6ddd383  push rcx
00007fa9d6ddd384  push rdx
00007fa9d6ddd385  push rdi
00007fa9d6ddd386  push rsi
00007fa9d6ddd387  push r8
00007fa9d6ddd389  push r9
00007fa9d6ddd38b  push r10
00007fa9d6ddd38d  push r11
00007fa9d6ddd38f  sub rsp, 0xF0
00007fa9d6ddd396  vmovaps [rsp], xmm0
00007fa9d6ddd39b  vmovaps [rsp+0x10], xmm1
00007fa9d6ddd3a1  vmovaps [rsp+0x20], xmm2
00007fa9d6ddd3a7  vmovaps [rsp+0x30], xmm3
00007fa9d6ddd3ad  vmovaps [rsp+0x40], xmm4
00007fa9d6ddd3b3  vmovaps [rsp+0x50], xmm5
00007fa9d6ddd3b9  vmovaps [rsp+0x60], xmm6
00007fa9d6ddd3bf  vmovaps [rsp+0x70], xmm7
00007fa9d6ddd3c5  vmovaps [rsp+0x80], xmm8
00007fa9d6ddd3ce  vmovaps [rsp+0x90], xmm10
00007fa9d6ddd3d7  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddd3e0  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddd3e9  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddd3f2  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddd3fb  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd404  sub rsp, 0x30
00007fa9d6ddd408  movaps [rsp], xmm9
00007fa9d6ddd40d  movaps [rsp+0x10], xmm10
00007fa9d6ddd413  movaps [rsp+0x20], xmm8
00007fa9d6ddd419  lea rdi, [rsp]
00007fa9d6ddd41d  mov esi, 0x00
00007fa9d6ddd422  mov rax, 0x61DF872DB530
00007fa9d6ddd42c  call rax
00007fa9d6ddd42e  movaps xmm9, [rsp]
00007fa9d6ddd433  add rsp, 0x30
00007fa9d6ddd437  vmovaps xmm0, [rsp]
00007fa9d6ddd43c  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddd442  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddd448  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddd44e  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddd454  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddd45a  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddd460  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddd466  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddd46f  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddd478  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddd481  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddd48a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddd493  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddd49c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd4a5  add rsp, 0xF0
00007fa9d6ddd4ac  pop r11
00007fa9d6ddd4ae  pop r10
00007fa9d6ddd4b0  pop r9
00007fa9d6ddd4b2  pop r8
00007fa9d6ddd4b4  pop rsi
00007fa9d6ddd4b5  pop rdi
00007fa9d6ddd4b6  pop rdx
00007fa9d6ddd4b7  pop rcx
00007fa9d6ddd4b8  pop rax
00007fa9d6ddd4b9  add rsp, 0x08
00007fa9d6ddd4bd  jmp 0x00007FA9D6DDBCAE
00007fa9d6ddd4c2  call 0x00007FA9D6CB52F0
00007fa9d6ddd4c7  jmp 0x00007FA9D6DDBDC8
00007fa9d6ddd4cc  call 0x00007FA9D6CB52F0
00007fa9d6ddd4d1  jmp 0x00007FA9D6DDBDDE
00007fa9d6ddd4d6  sub rsp, 0x08
00007fa9d6ddd4da  push rax
00007fa9d6ddd4db  push rcx
00007fa9d6ddd4dc  push rdx
00007fa9d6ddd4dd  push rdi
00007fa9d6ddd4de  push rsi
00007fa9d6ddd4df  push r8
00007fa9d6ddd4e1  push r9
00007fa9d6ddd4e3  push r10
00007fa9d6ddd4e5  push r11
00007fa9d6ddd4e7  sub rsp, 0xF0
00007fa9d6ddd4ee  vmovaps [rsp], xmm0
00007fa9d6ddd4f3  vmovaps [rsp+0x10], xmm2
00007fa9d6ddd4f9  vmovaps [rsp+0x20], xmm3
00007fa9d6ddd4ff  vmovaps [rsp+0x30], xmm4
00007fa9d6ddd505  vmovaps [rsp+0x40], xmm5
00007fa9d6ddd50b  vmovaps [rsp+0x50], xmm6
00007fa9d6ddd511  vmovaps [rsp+0x60], xmm7
00007fa9d6ddd517  vmovaps [rsp+0x70], xmm8
00007fa9d6ddd51d  vmovaps [rsp+0x80], xmm9
00007fa9d6ddd526  vmovaps [rsp+0x90], xmm10
00007fa9d6ddd52f  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddd538  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddd541  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddd54a  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddd553  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd55c  sub rsp, 0x30
00007fa9d6ddd560  movaps [rsp], xmm1
00007fa9d6ddd564  movaps [rsp+0x10], xmm6
00007fa9d6ddd569  movaps [rsp+0x20], xmm15
00007fa9d6ddd56f  lea rdi, [rsp]
00007fa9d6ddd573  mov esi, 0x00
00007fa9d6ddd578  mov rax, 0x61DF872DB530
00007fa9d6ddd582  call rax
00007fa9d6ddd584  movaps xmm1, [rsp]
00007fa9d6ddd588  add rsp, 0x30
00007fa9d6ddd58c  vmovaps xmm0, [rsp]
00007fa9d6ddd591  vmovaps xmm2, [rsp+0x10]
00007fa9d6ddd597  vmovaps xmm3, [rsp+0x20]
00007fa9d6ddd59d  vmovaps xmm4, [rsp+0x30]
00007fa9d6ddd5a3  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddd5a9  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddd5af  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddd5b5  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddd5bb  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddd5c4  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddd5cd  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddd5d6  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddd5df  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddd5e8  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddd5f1  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd5fa  add rsp, 0xF0
00007fa9d6ddd601  pop r11
00007fa9d6ddd603  pop r10
00007fa9d6ddd605  pop r9
00007fa9d6ddd607  pop r8
00007fa9d6ddd609  pop rsi
00007fa9d6ddd60a  pop rdi
00007fa9d6ddd60b  pop rdx
00007fa9d6ddd60c  pop rcx
00007fa9d6ddd60d  pop rax
00007fa9d6ddd60e  add rsp, 0x08
00007fa9d6ddd612  jmp 0x00007FA9D6DDBE1B
00007fa9d6ddd617  call 0x00007FA9D6CC4620
00007fa9d6ddd61c  jmp 0x00007FA9D6DDBE28
00007fa9d6ddd621  sub rsp, 0x08
00007fa9d6ddd625  push rax
00007fa9d6ddd626  push rcx
00007fa9d6ddd627  push rdx
00007fa9d6ddd628  push rdi
00007fa9d6ddd629  push rsi
00007fa9d6ddd62a  push r8
00007fa9d6ddd62c  push r9
00007fa9d6ddd62e  push r10
00007fa9d6ddd630  push r11
00007fa9d6ddd632  sub rsp, 0xF0
00007fa9d6ddd639  vmovaps [rsp], xmm0
00007fa9d6ddd63e  vmovaps [rsp+0x10], xmm1
00007fa9d6ddd644  vmovaps [rsp+0x20], xmm2
00007fa9d6ddd64a  vmovaps [rsp+0x30], xmm3
00007fa9d6ddd650  vmovaps [rsp+0x40], xmm4
00007fa9d6ddd656  vmovaps [rsp+0x50], xmm5
00007fa9d6ddd65c  vmovaps [rsp+0x60], xmm6
00007fa9d6ddd662  vmovaps [rsp+0x70], xmm7
00007fa9d6ddd668  vmovaps [rsp+0x80], xmm8
00007fa9d6ddd671  vmovaps [rsp+0x90], xmm9
00007fa9d6ddd67a  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddd683  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddd68c  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddd695  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddd69e  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd6a7  sub rsp, 0x30
00007fa9d6ddd6ab  movaps [rsp], xmm14
00007fa9d6ddd6b0  movaps [rsp+0x10], xmm4
00007fa9d6ddd6b5  movaps [rsp+0x20], xmm3
00007fa9d6ddd6ba  lea rdi, [rsp]
00007fa9d6ddd6be  mov esi, 0x00
00007fa9d6ddd6c3  mov rax, 0x61DF872DB530
00007fa9d6ddd6cd  call rax
00007fa9d6ddd6cf  movaps xmm14, [rsp]
00007fa9d6ddd6d4  add rsp, 0x30
00007fa9d6ddd6d8  vmovaps xmm0, [rsp]
00007fa9d6ddd6dd  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddd6e3  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddd6e9  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddd6ef  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddd6f5  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddd6fb  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddd701  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddd707  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddd710  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddd719  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddd722  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddd72b  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddd734  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddd73d  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd746  add rsp, 0xF0
00007fa9d6ddd74d  pop r11
00007fa9d6ddd74f  pop r10
00007fa9d6ddd751  pop r9
00007fa9d6ddd753  pop r8
00007fa9d6ddd755  pop rsi
00007fa9d6ddd756  pop rdi
00007fa9d6ddd757  pop rdx
00007fa9d6ddd758  pop rcx
00007fa9d6ddd759  pop rax
00007fa9d6ddd75a  add rsp, 0x08
00007fa9d6ddd75e  jmp 0x00007FA9D6DDBE42
00007fa9d6ddd763  sub rsp, 0x08
00007fa9d6ddd767  push rax
00007fa9d6ddd768  push rcx
00007fa9d6ddd769  push rdx
00007fa9d6ddd76a  push rdi
00007fa9d6ddd76b  push rsi
00007fa9d6ddd76c  push r8
00007fa9d6ddd76e  push r9
00007fa9d6ddd770  push r10
00007fa9d6ddd772  push r11
00007fa9d6ddd774  sub rsp, 0xF0
00007fa9d6ddd77b  vmovaps [rsp], xmm0
00007fa9d6ddd780  vmovaps [rsp+0x10], xmm1
00007fa9d6ddd786  vmovaps [rsp+0x20], xmm2
00007fa9d6ddd78c  vmovaps [rsp+0x30], xmm3
00007fa9d6ddd792  vmovaps [rsp+0x40], xmm4
00007fa9d6ddd798  vmovaps [rsp+0x50], xmm5
00007fa9d6ddd79e  vmovaps [rsp+0x60], xmm7
00007fa9d6ddd7a4  vmovaps [rsp+0x70], xmm8
00007fa9d6ddd7aa  vmovaps [rsp+0x80], xmm9
00007fa9d6ddd7b3  vmovaps [rsp+0x90], xmm10
00007fa9d6ddd7bc  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddd7c5  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddd7ce  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddd7d7  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddd7e0  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd7e9  sub rsp, 0x30
00007fa9d6ddd7ed  movaps [rsp], xmm6
00007fa9d6ddd7f1  movaps [rsp+0x10], xmm9
00007fa9d6ddd7f7  movaps [rsp+0x20], xmm7
00007fa9d6ddd7fc  lea rdi, [rsp]
00007fa9d6ddd800  mov esi, 0x00
00007fa9d6ddd805  mov rax, 0x61DF872DB530
00007fa9d6ddd80f  call rax
00007fa9d6ddd811  movaps xmm6, [rsp]
00007fa9d6ddd815  add rsp, 0x30
00007fa9d6ddd819  vmovaps xmm0, [rsp]
00007fa9d6ddd81e  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddd824  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddd82a  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddd830  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddd836  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddd83c  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddd842  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddd848  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddd851  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddd85a  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddd863  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddd86c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddd875  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddd87e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd887  add rsp, 0xF0
00007fa9d6ddd88e  pop r11
00007fa9d6ddd890  pop r10
00007fa9d6ddd892  pop r9
00007fa9d6ddd894  pop r8
00007fa9d6ddd896  pop rsi
00007fa9d6ddd897  pop rdi
00007fa9d6ddd898  pop rdx
00007fa9d6ddd899  pop rcx
00007fa9d6ddd89a  pop rax
00007fa9d6ddd89b  add rsp, 0x08
00007fa9d6ddd89f  jmp 0x00007FA9D6DDBE5A
00007fa9d6ddd8a4  sub rsp, 0x08
00007fa9d6ddd8a8  push rax
00007fa9d6ddd8a9  push rcx
00007fa9d6ddd8aa  push rdx
00007fa9d6ddd8ab  push rdi
00007fa9d6ddd8ac  push rsi
00007fa9d6ddd8ad  push r8
00007fa9d6ddd8af  push r9
00007fa9d6ddd8b1  push r10
00007fa9d6ddd8b3  push r11
00007fa9d6ddd8b5  sub rsp, 0xF0
00007fa9d6ddd8bc  vmovaps [rsp], xmm0
00007fa9d6ddd8c1  vmovaps [rsp+0x10], xmm1
00007fa9d6ddd8c7  vmovaps [rsp+0x20], xmm2
00007fa9d6ddd8cd  vmovaps [rsp+0x30], xmm3
00007fa9d6ddd8d3  vmovaps [rsp+0x40], xmm4
00007fa9d6ddd8d9  vmovaps [rsp+0x50], xmm5
00007fa9d6ddd8df  vmovaps [rsp+0x60], xmm6
00007fa9d6ddd8e5  vmovaps [rsp+0x70], xmm8
00007fa9d6ddd8eb  vmovaps [rsp+0x80], xmm9
00007fa9d6ddd8f4  vmovaps [rsp+0x90], xmm10
00007fa9d6ddd8fd  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddd906  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddd90f  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddd918  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddd921  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddd92a  sub rsp, 0x30
00007fa9d6ddd92e  movaps [rsp], xmm7
00007fa9d6ddd932  movaps [rsp+0x10], xmm4
00007fa9d6ddd937  movaps [rsp+0x20], xmm9
00007fa9d6ddd93d  lea rdi, [rsp]
00007fa9d6ddd941  mov esi, 0x00
00007fa9d6ddd946  mov rax, 0x61DF872DB530
00007fa9d6ddd950  call rax
00007fa9d6ddd952  movaps xmm7, [rsp]
00007fa9d6ddd956  add rsp, 0x30
00007fa9d6ddd95a  vmovaps xmm0, [rsp]
00007fa9d6ddd95f  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddd965  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddd96b  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddd971  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddd977  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddd97d  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddd983  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddd989  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddd992  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddd99b  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddd9a4  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddd9ad  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddd9b6  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddd9bf  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddd9c8  add rsp, 0xF0
00007fa9d6ddd9cf  pop r11
00007fa9d6ddd9d1  pop r10
00007fa9d6ddd9d3  pop r9
00007fa9d6ddd9d5  pop r8
00007fa9d6ddd9d7  pop rsi
00007fa9d6ddd9d8  pop rdi
00007fa9d6ddd9d9  pop rdx
00007fa9d6ddd9da  pop rcx
00007fa9d6ddd9db  pop rax
00007fa9d6ddd9dc  add rsp, 0x08
00007fa9d6ddd9e0  jmp 0x00007FA9D6DDBE87
00007fa9d6ddd9e5  sub rsp, 0x08
00007fa9d6ddd9e9  push rax
00007fa9d6ddd9ea  push rcx
00007fa9d6ddd9eb  push rdx
00007fa9d6ddd9ec  push rdi
00007fa9d6ddd9ed  push rsi
00007fa9d6ddd9ee  push r8
00007fa9d6ddd9f0  push r9
00007fa9d6ddd9f2  push r10
00007fa9d6ddd9f4  push r11
00007fa9d6ddd9f6  sub rsp, 0xF0
00007fa9d6ddd9fd  vmovaps [rsp], xmm0
00007fa9d6ddda02  vmovaps [rsp+0x10], xmm1
00007fa9d6ddda08  vmovaps [rsp+0x20], xmm2
00007fa9d6ddda0e  vmovaps [rsp+0x30], xmm3
00007fa9d6ddda14  vmovaps [rsp+0x40], xmm5
00007fa9d6ddda1a  vmovaps [rsp+0x50], xmm6
00007fa9d6ddda20  vmovaps [rsp+0x60], xmm7
00007fa9d6ddda26  vmovaps [rsp+0x70], xmm8
00007fa9d6ddda2c  vmovaps [rsp+0x80], xmm9
00007fa9d6ddda35  vmovaps [rsp+0x90], xmm10
00007fa9d6ddda3e  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddda47  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddda50  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddda59  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddda62  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddda6b  sub rsp, 0x30
00007fa9d6ddda6f  movaps [rsp], xmm4
00007fa9d6ddda73  movaps [rsp+0x10], xmm15
00007fa9d6ddda79  movaps [rsp+0x20], xmm9
00007fa9d6ddda7f  lea rdi, [rsp]
00007fa9d6ddda83  mov esi, 0x00
00007fa9d6ddda88  mov rax, 0x61DF872DB530
00007fa9d6ddda92  call rax
00007fa9d6ddda94  movaps xmm4, [rsp]
00007fa9d6ddda98  add rsp, 0x30
00007fa9d6ddda9c  vmovaps xmm0, [rsp]
00007fa9d6dddaa1  vmovaps xmm1, [rsp+0x10]
00007fa9d6dddaa7  vmovaps xmm2, [rsp+0x20]
00007fa9d6dddaad  vmovaps xmm3, [rsp+0x30]
00007fa9d6dddab3  vmovaps xmm5, [rsp+0x40]
00007fa9d6dddab9  vmovaps xmm6, [rsp+0x50]
00007fa9d6dddabf  vmovaps xmm7, [rsp+0x60]
00007fa9d6dddac5  vmovaps xmm8, [rsp+0x70]
00007fa9d6dddacb  vmovaps xmm9, [rsp+0x80]
00007fa9d6dddad4  vmovaps xmm10, [rsp+0x90]
00007fa9d6dddadd  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dddae6  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dddaef  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dddaf8  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dddb01  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dddb0a  add rsp, 0xF0
00007fa9d6dddb11  pop r11
00007fa9d6dddb13  pop r10
00007fa9d6dddb15  pop r9
00007fa9d6dddb17  pop r8
00007fa9d6dddb19  pop rsi
00007fa9d6dddb1a  pop rdi
00007fa9d6dddb1b  pop rdx
00007fa9d6dddb1c  pop rcx
00007fa9d6dddb1d  pop rax
00007fa9d6dddb1e  add rsp, 0x08
00007fa9d6dddb22  jmp 0x00007FA9D6DDBEAC
00007fa9d6dddb27  call 0x00007FA9D6CC4620
00007fa9d6dddb2c  jmp 0x00007FA9D6DDBEB9
00007fa9d6dddb31  sub rsp, 0x08
00007fa9d6dddb35  push rax
00007fa9d6dddb36  push rcx
00007fa9d6dddb37  push rdx
00007fa9d6dddb38  push rdi
00007fa9d6dddb39  push rsi
00007fa9d6dddb3a  push r8
00007fa9d6dddb3c  push r9
00007fa9d6dddb3e  push r10
00007fa9d6dddb40  push r11
00007fa9d6dddb42  sub rsp, 0xF0
00007fa9d6dddb49  vmovaps [rsp], xmm0
00007fa9d6dddb4e  vmovaps [rsp+0x10], xmm1
00007fa9d6dddb54  vmovaps [rsp+0x20], xmm2
00007fa9d6dddb5a  vmovaps [rsp+0x30], xmm4
00007fa9d6dddb60  vmovaps [rsp+0x40], xmm5
00007fa9d6dddb66  vmovaps [rsp+0x50], xmm6
00007fa9d6dddb6c  vmovaps [rsp+0x60], xmm7
00007fa9d6dddb72  vmovaps [rsp+0x70], xmm8
00007fa9d6dddb78  vmovaps [rsp+0x80], xmm9
00007fa9d6dddb81  vmovaps [rsp+0x90], xmm10
00007fa9d6dddb8a  vmovaps [rsp+0xA0], xmm11
00007fa9d6dddb93  vmovaps [rsp+0xB0], xmm12
00007fa9d6dddb9c  vmovaps [rsp+0xC0], xmm13
00007fa9d6dddba5  vmovaps [rsp+0xD0], xmm14
00007fa9d6dddbae  vmovaps [rsp+0xE0], xmm15
00007fa9d6dddbb7  sub rsp, 0x30
00007fa9d6dddbbb  movaps [rsp], xmm3
00007fa9d6dddbbf  movaps [rsp+0x10], xmm1
00007fa9d6dddbc4  movaps [rsp+0x20], xmm9
00007fa9d6dddbca  lea rdi, [rsp]
00007fa9d6dddbce  mov esi, 0x00
00007fa9d6dddbd3  mov rax, 0x61DF872DB530
00007fa9d6dddbdd  call rax
00007fa9d6dddbdf  movaps xmm3, [rsp]
00007fa9d6dddbe3  add rsp, 0x30
00007fa9d6dddbe7  vmovaps xmm0, [rsp]
00007fa9d6dddbec  vmovaps xmm1, [rsp+0x10]
00007fa9d6dddbf2  vmovaps xmm2, [rsp+0x20]
00007fa9d6dddbf8  vmovaps xmm4, [rsp+0x30]
00007fa9d6dddbfe  vmovaps xmm5, [rsp+0x40]
00007fa9d6dddc04  vmovaps xmm6, [rsp+0x50]
00007fa9d6dddc0a  vmovaps xmm7, [rsp+0x60]
00007fa9d6dddc10  vmovaps xmm8, [rsp+0x70]
00007fa9d6dddc16  vmovaps xmm9, [rsp+0x80]
00007fa9d6dddc1f  vmovaps xmm10, [rsp+0x90]
00007fa9d6dddc28  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dddc31  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dddc3a  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dddc43  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dddc4c  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dddc55  add rsp, 0xF0
00007fa9d6dddc5c  pop r11
00007fa9d6dddc5e  pop r10
00007fa9d6dddc60  pop r9
00007fa9d6dddc62  pop r8
00007fa9d6dddc64  pop rsi
00007fa9d6dddc65  pop rdi
00007fa9d6dddc66  pop rdx
00007fa9d6dddc67  pop rcx
00007fa9d6dddc68  pop rax
00007fa9d6dddc69  add rsp, 0x08
00007fa9d6dddc6d  jmp 0x00007FA9D6DDBEF6
00007fa9d6dddc72  sub rsp, 0x08
00007fa9d6dddc76  push rax
00007fa9d6dddc77  push rcx
00007fa9d6dddc78  push rdx
00007fa9d6dddc79  push rdi
00007fa9d6dddc7a  push rsi
00007fa9d6dddc7b  push r8
00007fa9d6dddc7d  push r9
00007fa9d6dddc7f  push r10
00007fa9d6dddc81  push r11
00007fa9d6dddc83  sub rsp, 0xF0
00007fa9d6dddc8a  vmovaps [rsp], xmm0
00007fa9d6dddc8f  vmovaps [rsp+0x10], xmm2
00007fa9d6dddc95  vmovaps [rsp+0x20], xmm3
00007fa9d6dddc9b  vmovaps [rsp+0x30], xmm4
00007fa9d6dddca1  vmovaps [rsp+0x40], xmm5
00007fa9d6dddca7  vmovaps [rsp+0x50], xmm6
00007fa9d6dddcad  vmovaps [rsp+0x60], xmm7
00007fa9d6dddcb3  vmovaps [rsp+0x70], xmm8
00007fa9d6dddcb9  vmovaps [rsp+0x80], xmm9
00007fa9d6dddcc2  vmovaps [rsp+0x90], xmm10
00007fa9d6dddccb  vmovaps [rsp+0xA0], xmm11
00007fa9d6dddcd4  vmovaps [rsp+0xB0], xmm12
00007fa9d6dddcdd  vmovaps [rsp+0xC0], xmm13
00007fa9d6dddce6  vmovaps [rsp+0xD0], xmm14
00007fa9d6dddcef  vmovaps [rsp+0xE0], xmm15
00007fa9d6dddcf8  sub rsp, 0x30
00007fa9d6dddcfc  movaps [rsp], xmm1
00007fa9d6dddd00  movaps [rsp+0x10], xmm15
00007fa9d6dddd06  movaps [rsp+0x20], xmm9
00007fa9d6dddd0c  lea rdi, [rsp]
00007fa9d6dddd10  mov esi, 0x00
00007fa9d6dddd15  mov rax, 0x61DF872DB530
00007fa9d6dddd1f  call rax
00007fa9d6dddd21  movaps xmm1, [rsp]
00007fa9d6dddd25  add rsp, 0x30
00007fa9d6dddd29  vmovaps xmm0, [rsp]
00007fa9d6dddd2e  vmovaps xmm2, [rsp+0x10]
00007fa9d6dddd34  vmovaps xmm3, [rsp+0x20]
00007fa9d6dddd3a  vmovaps xmm4, [rsp+0x30]
00007fa9d6dddd40  vmovaps xmm5, [rsp+0x40]
00007fa9d6dddd46  vmovaps xmm6, [rsp+0x50]
00007fa9d6dddd4c  vmovaps xmm7, [rsp+0x60]
00007fa9d6dddd52  vmovaps xmm8, [rsp+0x70]
00007fa9d6dddd58  vmovaps xmm9, [rsp+0x80]
00007fa9d6dddd61  vmovaps xmm10, [rsp+0x90]
00007fa9d6dddd6a  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dddd73  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dddd7c  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dddd85  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dddd8e  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dddd97  add rsp, 0xF0
00007fa9d6dddd9e  pop r11
00007fa9d6dddda0  pop r10
00007fa9d6dddda2  pop r9
00007fa9d6dddda4  pop r8
00007fa9d6dddda6  pop rsi
00007fa9d6dddda7  pop rdi
00007fa9d6dddda8  pop rdx
00007fa9d6dddda9  pop rcx
00007fa9d6ddddaa  pop rax
00007fa9d6ddddab  add rsp, 0x08
00007fa9d6ddddaf  jmp 0x00007FA9D6DDBF7E
00007fa9d6ddddb4  call 0x00007FA9D6CC4620
00007fa9d6ddddb9  jmp 0x00007FA9D6DDBF8B
00007fa9d6ddddbe  sub rsp, 0x08
00007fa9d6ddddc2  push rax
00007fa9d6ddddc3  push rcx
00007fa9d6ddddc4  push rdx
00007fa9d6ddddc5  push rdi
00007fa9d6ddddc6  push rsi
00007fa9d6ddddc7  push r8
00007fa9d6ddddc9  push r9
00007fa9d6ddddcb  push r10
00007fa9d6ddddcd  push r11
00007fa9d6ddddcf  sub rsp, 0xF0
00007fa9d6ddddd6  vmovaps [rsp], xmm0
00007fa9d6dddddb  vmovaps [rsp+0x10], xmm2
00007fa9d6dddde1  vmovaps [rsp+0x20], xmm3
00007fa9d6dddde7  vmovaps [rsp+0x30], xmm4
00007fa9d6dddded  vmovaps [rsp+0x40], xmm5
00007fa9d6ddddf3  vmovaps [rsp+0x50], xmm6
00007fa9d6ddddf9  vmovaps [rsp+0x60], xmm7
00007fa9d6ddddff  vmovaps [rsp+0x70], xmm8
00007fa9d6ddde05  vmovaps [rsp+0x80], xmm9
00007fa9d6ddde0e  vmovaps [rsp+0x90], xmm10
00007fa9d6ddde17  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddde20  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddde29  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddde32  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddde3b  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddde44  sub rsp, 0x30
00007fa9d6ddde48  movaps [rsp], xmm1
00007fa9d6ddde4c  movaps [rsp+0x10], xmm5
00007fa9d6ddde51  movaps [rsp+0x20], xmm7
00007fa9d6ddde56  lea rdi, [rsp]
00007fa9d6ddde5a  mov esi, 0x00
00007fa9d6ddde5f  mov rax, 0x61DF872DB530
00007fa9d6ddde69  call rax
00007fa9d6ddde6b  movaps xmm1, [rsp]
00007fa9d6ddde6f  add rsp, 0x30
00007fa9d6ddde73  vmovaps xmm0, [rsp]
00007fa9d6ddde78  vmovaps xmm2, [rsp+0x10]
00007fa9d6ddde7e  vmovaps xmm3, [rsp+0x20]
00007fa9d6ddde84  vmovaps xmm4, [rsp+0x30]
00007fa9d6ddde8a  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddde90  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddde96  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddde9c  vmovaps xmm8, [rsp+0x70]
00007fa9d6dddea2  vmovaps xmm9, [rsp+0x80]
00007fa9d6dddeab  vmovaps xmm10, [rsp+0x90]
00007fa9d6dddeb4  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dddebd  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dddec6  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dddecf  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddded8  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dddee1  add rsp, 0xF0
00007fa9d6dddee8  pop r11
00007fa9d6dddeea  pop r10
00007fa9d6dddeec  pop r9
00007fa9d6dddeee  pop r8
00007fa9d6dddef0  pop rsi
00007fa9d6dddef1  pop rdi
00007fa9d6dddef2  pop rdx
00007fa9d6dddef3  pop rcx
00007fa9d6dddef4  pop rax
00007fa9d6dddef5  add rsp, 0x08
00007fa9d6dddef9  jmp 0x00007FA9D6DDC030
00007fa9d6dddefe  sub rsp, 0x08
00007fa9d6dddf02  push rax
00007fa9d6dddf03  push rcx
00007fa9d6dddf04  push rdx
00007fa9d6dddf05  push rdi
00007fa9d6dddf06  push rsi
00007fa9d6dddf07  push r8
00007fa9d6dddf09  push r9
00007fa9d6dddf0b  push r10
00007fa9d6dddf0d  push r11
00007fa9d6dddf0f  sub rsp, 0xF0
00007fa9d6dddf16  vmovaps [rsp], xmm0
00007fa9d6dddf1b  vmovaps [rsp+0x10], xmm1
00007fa9d6dddf21  vmovaps [rsp+0x20], xmm2
00007fa9d6dddf27  vmovaps [rsp+0x30], xmm3
00007fa9d6dddf2d  vmovaps [rsp+0x40], xmm4
00007fa9d6dddf33  vmovaps [rsp+0x50], xmm5
00007fa9d6dddf39  vmovaps [rsp+0x60], xmm6
00007fa9d6dddf3f  vmovaps [rsp+0x70], xmm8
00007fa9d6dddf45  vmovaps [rsp+0x80], xmm9
00007fa9d6dddf4e  vmovaps [rsp+0x90], xmm10
00007fa9d6dddf57  vmovaps [rsp+0xA0], xmm11
00007fa9d6dddf60  vmovaps [rsp+0xB0], xmm12
00007fa9d6dddf69  vmovaps [rsp+0xC0], xmm13
00007fa9d6dddf72  vmovaps [rsp+0xD0], xmm14
00007fa9d6dddf7b  vmovaps [rsp+0xE0], xmm15
00007fa9d6dddf84  sub rsp, 0x30
00007fa9d6dddf88  movaps [rsp], xmm7
00007fa9d6dddf8c  movaps [rsp+0x10], xmm5
00007fa9d6dddf91  movaps [rsp+0x20], xmm15
00007fa9d6dddf97  lea rdi, [rsp]
00007fa9d6dddf9b  mov esi, 0x00
00007fa9d6dddfa0  mov rax, 0x61DF872DB530
00007fa9d6dddfaa  call rax
00007fa9d6dddfac  movaps xmm7, [rsp]
00007fa9d6dddfb0  add rsp, 0x30
00007fa9d6dddfb4  vmovaps xmm0, [rsp]
00007fa9d6dddfb9  vmovaps xmm1, [rsp+0x10]
00007fa9d6dddfbf  vmovaps xmm2, [rsp+0x20]
00007fa9d6dddfc5  vmovaps xmm3, [rsp+0x30]
00007fa9d6dddfcb  vmovaps xmm4, [rsp+0x40]
00007fa9d6dddfd1  vmovaps xmm5, [rsp+0x50]
00007fa9d6dddfd7  vmovaps xmm6, [rsp+0x60]
00007fa9d6dddfdd  vmovaps xmm8, [rsp+0x70]
00007fa9d6dddfe3  vmovaps xmm9, [rsp+0x80]
00007fa9d6dddfec  vmovaps xmm10, [rsp+0x90]
00007fa9d6dddff5  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dddffe  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dde007  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dde010  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dde019  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dde022  add rsp, 0xF0
00007fa9d6dde029  pop r11
00007fa9d6dde02b  pop r10
00007fa9d6dde02d  pop r9
00007fa9d6dde02f  pop r8
00007fa9d6dde031  pop rsi
00007fa9d6dde032  pop rdi
00007fa9d6dde033  pop rdx
00007fa9d6dde034  pop rcx
00007fa9d6dde035  pop rax
00007fa9d6dde036  add rsp, 0x08
00007fa9d6dde03a  jmp 0x00007FA9D6DDC066
00007fa9d6dde03f  call 0x00007FA9D6CB52F0
00007fa9d6dde044  jmp 0x00007FA9D6DDC073
00007fa9d6dde049  sub rsp, 0x08
00007fa9d6dde04d  push rax
00007fa9d6dde04e  push rcx
00007fa9d6dde04f  push rdx
00007fa9d6dde050  push rdi
00007fa9d6dde051  push rsi
00007fa9d6dde052  push r8
00007fa9d6dde054  push r9
00007fa9d6dde056  push r10
00007fa9d6dde058  push r11
00007fa9d6dde05a  sub rsp, 0xF0
00007fa9d6dde061  vmovaps [rsp], xmm0
00007fa9d6dde066  vmovaps [rsp+0x10], xmm1
00007fa9d6dde06c  vmovaps [rsp+0x20], xmm2
00007fa9d6dde072  vmovaps [rsp+0x30], xmm3
00007fa9d6dde078  vmovaps [rsp+0x40], xmm4
00007fa9d6dde07e  vmovaps [rsp+0x50], xmm5
00007fa9d6dde084  vmovaps [rsp+0x60], xmm6
00007fa9d6dde08a  vmovaps [rsp+0x70], xmm7
00007fa9d6dde090  vmovaps [rsp+0x80], xmm8
00007fa9d6dde099  vmovaps [rsp+0x90], xmm9
00007fa9d6dde0a2  vmovaps [rsp+0xA0], xmm10
00007fa9d6dde0ab  vmovaps [rsp+0xB0], xmm11
00007fa9d6dde0b4  vmovaps [rsp+0xC0], xmm12
00007fa9d6dde0bd  vmovaps [rsp+0xD0], xmm13
00007fa9d6dde0c6  vmovaps [rsp+0xE0], xmm14
00007fa9d6dde0cf  sub rsp, 0x30
00007fa9d6dde0d3  movaps [rsp], xmm15
00007fa9d6dde0d8  movaps [rsp+0x10], xmm5
00007fa9d6dde0dd  movaps [rsp+0x20], xmm3
00007fa9d6dde0e2  lea rdi, [rsp]
00007fa9d6dde0e6  mov esi, 0x00
00007fa9d6dde0eb  mov rax, 0x61DF872DB530
00007fa9d6dde0f5  call rax
00007fa9d6dde0f7  movaps xmm15, [rsp]
00007fa9d6dde0fc  add rsp, 0x30
00007fa9d6dde100  vmovaps xmm0, [rsp]
00007fa9d6dde105  vmovaps xmm1, [rsp+0x10]
00007fa9d6dde10b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dde111  vmovaps xmm3, [rsp+0x30]
00007fa9d6dde117  vmovaps xmm4, [rsp+0x40]
00007fa9d6dde11d  vmovaps xmm5, [rsp+0x50]
00007fa9d6dde123  vmovaps xmm6, [rsp+0x60]
00007fa9d6dde129  vmovaps xmm7, [rsp+0x70]
00007fa9d6dde12f  vmovaps xmm8, [rsp+0x80]
00007fa9d6dde138  vmovaps xmm9, [rsp+0x90]
00007fa9d6dde141  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dde14a  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dde153  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dde15c  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dde165  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dde16e  add rsp, 0xF0
00007fa9d6dde175  pop r11
00007fa9d6dde177  pop r10
00007fa9d6dde179  pop r9
00007fa9d6dde17b  pop r8
00007fa9d6dde17d  pop rsi
00007fa9d6dde17e  pop rdi
00007fa9d6dde17f  pop rdx
00007fa9d6dde180  pop rcx
00007fa9d6dde181  pop rax
00007fa9d6dde182  add rsp, 0x08
00007fa9d6dde186  jmp 0x00007FA9D6DDC099
00007fa9d6dde18b  sub rsp, 0x08
00007fa9d6dde18f  push rax
00007fa9d6dde190  push rcx
00007fa9d6dde191  push rdx
00007fa9d6dde192  push rdi
00007fa9d6dde193  push rsi
00007fa9d6dde194  push r8
00007fa9d6dde196  push r9
00007fa9d6dde198  push r10
00007fa9d6dde19a  push r11
00007fa9d6dde19c  sub rsp, 0xF0
00007fa9d6dde1a3  vmovaps [rsp], xmm0
00007fa9d6dde1a8  vmovaps [rsp+0x10], xmm2
00007fa9d6dde1ae  vmovaps [rsp+0x20], xmm3
00007fa9d6dde1b4  vmovaps [rsp+0x30], xmm4
00007fa9d6dde1ba  vmovaps [rsp+0x40], xmm5
00007fa9d6dde1c0  vmovaps [rsp+0x50], xmm6
00007fa9d6dde1c6  vmovaps [rsp+0x60], xmm7
00007fa9d6dde1cc  vmovaps [rsp+0x70], xmm8
00007fa9d6dde1d2  vmovaps [rsp+0x80], xmm9
00007fa9d6dde1db  vmovaps [rsp+0x90], xmm10
00007fa9d6dde1e4  vmovaps [rsp+0xA0], xmm11
00007fa9d6dde1ed  vmovaps [rsp+0xB0], xmm12
00007fa9d6dde1f6  vmovaps [rsp+0xC0], xmm13
00007fa9d6dde1ff  vmovaps [rsp+0xD0], xmm14
00007fa9d6dde208  vmovaps [rsp+0xE0], xmm15
00007fa9d6dde211  sub rsp, 0x30
00007fa9d6dde215  movaps [rsp], xmm1
00007fa9d6dde219  movaps [rsp+0x10], xmm5
00007fa9d6dde21e  movaps [rsp+0x20], xmm4
00007fa9d6dde223  lea rdi, [rsp]
00007fa9d6dde227  mov esi, 0x00
00007fa9d6dde22c  mov rax, 0x61DF872DB530
00007fa9d6dde236  call rax
00007fa9d6dde238  movaps xmm1, [rsp]
00007fa9d6dde23c  add rsp, 0x30
00007fa9d6dde240  vmovaps xmm0, [rsp]
00007fa9d6dde245  vmovaps xmm2, [rsp+0x10]
00007fa9d6dde24b  vmovaps xmm3, [rsp+0x20]
00007fa9d6dde251  vmovaps xmm4, [rsp+0x30]
00007fa9d6dde257  vmovaps xmm5, [rsp+0x40]
00007fa9d6dde25d  vmovaps xmm6, [rsp+0x50]
00007fa9d6dde263  vmovaps xmm7, [rsp+0x60]
00007fa9d6dde269  vmovaps xmm8, [rsp+0x70]
00007fa9d6dde26f  vmovaps xmm9, [rsp+0x80]
00007fa9d6dde278  vmovaps xmm10, [rsp+0x90]
00007fa9d6dde281  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dde28a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dde293  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dde29c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dde2a5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dde2ae  add rsp, 0xF0
00007fa9d6dde2b5  pop r11
00007fa9d6dde2b7  pop r10
00007fa9d6dde2b9  pop r9
00007fa9d6dde2bb  pop r8
00007fa9d6dde2bd  pop rsi
00007fa9d6dde2be  pop rdi
00007fa9d6dde2bf  pop rdx
00007fa9d6dde2c0  pop rcx
00007fa9d6dde2c1  pop rax
00007fa9d6dde2c2  add rsp, 0x08
00007fa9d6dde2c6  jmp 0x00007FA9D6DDC0B9
00007fa9d6dde2cb  sub rsp, 0x08
00007fa9d6dde2cf  push rax
00007fa9d6dde2d0  push rcx
00007fa9d6dde2d1  push rdx
00007fa9d6dde2d2  push rdi
00007fa9d6dde2d3  push rsi
00007fa9d6dde2d4  push r8
00007fa9d6dde2d6  push r9
00007fa9d6dde2d8  push r10
00007fa9d6dde2da  push r11
00007fa9d6dde2dc  sub rsp, 0xF0
00007fa9d6dde2e3  vmovaps [rsp], xmm0
00007fa9d6dde2e8  vmovaps [rsp+0x10], xmm1
00007fa9d6dde2ee  vmovaps [rsp+0x20], xmm2
00007fa9d6dde2f4  vmovaps [rsp+0x30], xmm3
00007fa9d6dde2fa  vmovaps [rsp+0x40], xmm5
00007fa9d6dde300  vmovaps [rsp+0x50], xmm6
00007fa9d6dde306  vmovaps [rsp+0x60], xmm7
00007fa9d6dde30c  vmovaps [rsp+0x70], xmm8
00007fa9d6dde312  vmovaps [rsp+0x80], xmm9
00007fa9d6dde31b  vmovaps [rsp+0x90], xmm10
00007fa9d6dde324  vmovaps [rsp+0xA0], xmm11
00007fa9d6dde32d  vmovaps [rsp+0xB0], xmm12
00007fa9d6dde336  vmovaps [rsp+0xC0], xmm13
00007fa9d6dde33f  vmovaps [rsp+0xD0], xmm14
00007fa9d6dde348  vmovaps [rsp+0xE0], xmm15
00007fa9d6dde351  sub rsp, 0x30
00007fa9d6dde355  movaps [rsp], xmm4
00007fa9d6dde359  movaps [rsp+0x10], xmm3
00007fa9d6dde35e  movaps [rsp+0x20], xmm5
00007fa9d6dde363  lea rdi, [rsp]
00007fa9d6dde367  mov esi, 0x00
00007fa9d6dde36c  mov rax, 0x61DF872DB530
00007fa9d6dde376  call rax
00007fa9d6dde378  movaps xmm4, [rsp]
00007fa9d6dde37c  add rsp, 0x30
00007fa9d6dde380  vmovaps xmm0, [rsp]
00007fa9d6dde385  vmovaps xmm1, [rsp+0x10]
00007fa9d6dde38b  vmovaps xmm2, [rsp+0x20]
00007fa9d6dde391  vmovaps xmm3, [rsp+0x30]
00007fa9d6dde397  vmovaps xmm5, [rsp+0x40]
00007fa9d6dde39d  vmovaps xmm6, [rsp+0x50]
00007fa9d6dde3a3  vmovaps xmm7, [rsp+0x60]
00007fa9d6dde3a9  vmovaps xmm8, [rsp+0x70]
00007fa9d6dde3af  vmovaps xmm9, [rsp+0x80]
00007fa9d6dde3b8  vmovaps xmm10, [rsp+0x90]
00007fa9d6dde3c1  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dde3ca  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dde3d3  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dde3dc  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dde3e5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dde3ee  add rsp, 0xF0
00007fa9d6dde3f5  pop r11
00007fa9d6dde3f7  pop r10
00007fa9d6dde3f9  pop r9
00007fa9d6dde3fb  pop r8
00007fa9d6dde3fd  pop rsi
00007fa9d6dde3fe  pop rdi
00007fa9d6dde3ff  pop rdx
00007fa9d6dde400  pop rcx
00007fa9d6dde401  pop rax
00007fa9d6dde402  add rsp, 0x08
00007fa9d6dde406  jmp 0x00007FA9D6DDC107
00007fa9d6dde40b  call 0x00007FA9D6CB52F0
00007fa9d6dde410  jmp 0x00007FA9D6DDC114
00007fa9d6dde415  sub rsp, 0x08
00007fa9d6dde419  push rax
00007fa9d6dde41a  push rcx
00007fa9d6dde41b  push rdx
00007fa9d6dde41c  push rdi
00007fa9d6dde41d  push rsi
00007fa9d6dde41e  push r8
00007fa9d6dde420  push r9
00007fa9d6dde422  push r10
00007fa9d6dde424  push r11
00007fa9d6dde426  sub rsp, 0xF0
00007fa9d6dde42d  vmovaps [rsp], xmm0
00007fa9d6dde432  vmovaps [rsp+0x10], xmm1
00007fa9d6dde438  vmovaps [rsp+0x20], xmm2
00007fa9d6dde43e  vmovaps [rsp+0x30], xmm3
00007fa9d6dde444  vmovaps [rsp+0x40], xmm4
00007fa9d6dde44a  vmovaps [rsp+0x50], xmm6
00007fa9d6dde450  vmovaps [rsp+0x60], xmm7
00007fa9d6dde456  vmovaps [rsp+0x70], xmm8
00007fa9d6dde45c  vmovaps [rsp+0x80], xmm9
00007fa9d6dde465  vmovaps [rsp+0x90], xmm10
00007fa9d6dde46e  vmovaps [rsp+0xA0], xmm11
00007fa9d6dde477  vmovaps [rsp+0xB0], xmm12
00007fa9d6dde480  vmovaps [rsp+0xC0], xmm13
00007fa9d6dde489  vmovaps [rsp+0xD0], xmm14
00007fa9d6dde492  vmovaps [rsp+0xE0], xmm15
00007fa9d6dde49b  sub rsp, 0x30
00007fa9d6dde49f  movaps [rsp], xmm5
00007fa9d6dde4a3  movaps [rsp+0x10], xmm6
00007fa9d6dde4a8  movaps [rsp+0x20], xmm3
00007fa9d6dde4ad  lea rdi, [rsp]
00007fa9d6dde4b1  mov esi, 0x00
00007fa9d6dde4b6  mov rax, 0x61DF872DB530
00007fa9d6dde4c0  call rax
00007fa9d6dde4c2  movaps xmm5, [rsp]
00007fa9d6dde4c6  add rsp, 0x30
00007fa9d6dde4ca  vmovaps xmm0, [rsp]
00007fa9d6dde4cf  vmovaps xmm1, [rsp+0x10]
00007fa9d6dde4d5  vmovaps xmm2, [rsp+0x20]
00007fa9d6dde4db  vmovaps xmm3, [rsp+0x30]
00007fa9d6dde4e1  vmovaps xmm4, [rsp+0x40]
00007fa9d6dde4e7  vmovaps xmm6, [rsp+0x50]
00007fa9d6dde4ed  vmovaps xmm7, [rsp+0x60]
00007fa9d6dde4f3  vmovaps xmm8, [rsp+0x70]
00007fa9d6dde4f9  vmovaps xmm9, [rsp+0x80]
00007fa9d6dde502  vmovaps xmm10, [rsp+0x90]
00007fa9d6dde50b  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dde514  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dde51d  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dde526  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dde52f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dde538  add rsp, 0xF0
00007fa9d6dde53f  pop r11
00007fa9d6dde541  pop r10
00007fa9d6dde543  pop r9
00007fa9d6dde545  pop r8
00007fa9d6dde547  pop rsi
00007fa9d6dde548  pop rdi
00007fa9d6dde549  pop rdx
00007fa9d6dde54a  pop rcx
00007fa9d6dde54b  pop rax
00007fa9d6dde54c  add rsp, 0x08
00007fa9d6dde550  jmp 0x00007FA9D6DDC13A
00007fa9d6dde555  sub rsp, 0x08
00007fa9d6dde559  push rax
00007fa9d6dde55a  push rcx
00007fa9d6dde55b  push rdx
00007fa9d6dde55c  push rdi
00007fa9d6dde55d  push rsi
00007fa9d6dde55e  push r8
00007fa9d6dde560  push r9
00007fa9d6dde562  push r10
00007fa9d6dde564  push r11
00007fa9d6dde566  sub rsp, 0xF0
00007fa9d6dde56d  vmovaps [rsp], xmm0
00007fa9d6dde572  vmovaps [rsp+0x10], xmm1
00007fa9d6dde578  vmovaps [rsp+0x20], xmm2
00007fa9d6dde57e  vmovaps [rsp+0x30], xmm3
00007fa9d6dde584  vmovaps [rsp+0x40], xmm4
00007fa9d6dde58a  vmovaps [rsp+0x50], xmm5
00007fa9d6dde590  vmovaps [rsp+0x60], xmm7
00007fa9d6dde596  vmovaps [rsp+0x70], xmm8
00007fa9d6dde59c  vmovaps [rsp+0x80], xmm9
00007fa9d6dde5a5  vmovaps [rsp+0x90], xmm10
00007fa9d6dde5ae  vmovaps [rsp+0xA0], xmm11
00007fa9d6dde5b7  vmovaps [rsp+0xB0], xmm12
00007fa9d6dde5c0  vmovaps [rsp+0xC0], xmm13
00007fa9d6dde5c9  vmovaps [rsp+0xD0], xmm14
00007fa9d6dde5d2  vmovaps [rsp+0xE0], xmm15
00007fa9d6dde5db  sub rsp, 0x30
00007fa9d6dde5df  movaps [rsp], xmm6
00007fa9d6dde5e3  movaps [rsp+0x10], xmm9
00007fa9d6dde5e9  movaps [rsp+0x20], xmm1
00007fa9d6dde5ee  lea rdi, [rsp]
00007fa9d6dde5f2  mov esi, 0x00
00007fa9d6dde5f7  mov rax, 0x61DF872DB530
00007fa9d6dde601  call rax
00007fa9d6dde603  movaps xmm6, [rsp]
00007fa9d6dde607  add rsp, 0x30
00007fa9d6dde60b  vmovaps xmm0, [rsp]
00007fa9d6dde610  vmovaps xmm1, [rsp+0x10]
00007fa9d6dde616  vmovaps xmm2, [rsp+0x20]
00007fa9d6dde61c  vmovaps xmm3, [rsp+0x30]
00007fa9d6dde622  vmovaps xmm4, [rsp+0x40]
00007fa9d6dde628  vmovaps xmm5, [rsp+0x50]
00007fa9d6dde62e  vmovaps xmm7, [rsp+0x60]
00007fa9d6dde634  vmovaps xmm8, [rsp+0x70]
00007fa9d6dde63a  vmovaps xmm9, [rsp+0x80]
00007fa9d6dde643  vmovaps xmm10, [rsp+0x90]
00007fa9d6dde64c  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dde655  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dde65e  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dde667  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dde670  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dde679  add rsp, 0xF0
00007fa9d6dde680  pop r11
00007fa9d6dde682  pop r10
00007fa9d6dde684  pop r9
00007fa9d6dde686  pop r8
00007fa9d6dde688  pop rsi
00007fa9d6dde689  pop rdi
00007fa9d6dde68a  pop rdx
00007fa9d6dde68b  pop rcx
00007fa9d6dde68c  pop rax
00007fa9d6dde68d  add rsp, 0x08
00007fa9d6dde691  jmp 0x00007FA9D6DDC15E
00007fa9d6dde696  sub rsp, 0x08
00007fa9d6dde69a  push rax
00007fa9d6dde69b  push rcx
00007fa9d6dde69c  push rdx
00007fa9d6dde69d  push rdi
00007fa9d6dde69e  push rsi
00007fa9d6dde69f  push r8
00007fa9d6dde6a1  push r9
00007fa9d6dde6a3  push r10
00007fa9d6dde6a5  push r11
00007fa9d6dde6a7  sub rsp, 0xF0
00007fa9d6dde6ae  vmovaps [rsp], xmm0
00007fa9d6dde6b3  vmovaps [rsp+0x10], xmm1
00007fa9d6dde6b9  vmovaps [rsp+0x20], xmm2
00007fa9d6dde6bf  vmovaps [rsp+0x30], xmm3
00007fa9d6dde6c5  vmovaps [rsp+0x40], xmm4
00007fa9d6dde6cb  vmovaps [rsp+0x50], xmm5
00007fa9d6dde6d1  vmovaps [rsp+0x60], xmm6
00007fa9d6dde6d7  vmovaps [rsp+0x70], xmm7
00007fa9d6dde6dd  vmovaps [rsp+0x80], xmm8
00007fa9d6dde6e6  vmovaps [rsp+0x90], xmm10
00007fa9d6dde6ef  vmovaps [rsp+0xA0], xmm11
00007fa9d6dde6f8  vmovaps [rsp+0xB0], xmm12
00007fa9d6dde701  vmovaps [rsp+0xC0], xmm13
00007fa9d6dde70a  vmovaps [rsp+0xD0], xmm14
00007fa9d6dde713  vmovaps [rsp+0xE0], xmm15
00007fa9d6dde71c  sub rsp, 0x30
00007fa9d6dde720  movaps [rsp], xmm9
00007fa9d6dde725  movaps [rsp+0x10], xmm3
00007fa9d6dde72a  movaps [rsp+0x20], xmm1
00007fa9d6dde72f  lea rdi, [rsp]
00007fa9d6dde733  mov esi, 0x00
00007fa9d6dde738  mov rax, 0x61DF872DB530
00007fa9d6dde742  call rax
00007fa9d6dde744  movaps xmm9, [rsp]
00007fa9d6dde749  add rsp, 0x30
00007fa9d6dde74d  vmovaps xmm0, [rsp]
00007fa9d6dde752  vmovaps xmm1, [rsp+0x10]
00007fa9d6dde758  vmovaps xmm2, [rsp+0x20]
00007fa9d6dde75e  vmovaps xmm3, [rsp+0x30]
00007fa9d6dde764  vmovaps xmm4, [rsp+0x40]
00007fa9d6dde76a  vmovaps xmm5, [rsp+0x50]
00007fa9d6dde770  vmovaps xmm6, [rsp+0x60]
00007fa9d6dde776  vmovaps xmm7, [rsp+0x70]
00007fa9d6dde77c  vmovaps xmm8, [rsp+0x80]
00007fa9d6dde785  vmovaps xmm10, [rsp+0x90]
00007fa9d6dde78e  vmovaps xmm11, [rsp+0xA0]
00007fa9d6dde797  vmovaps xmm12, [rsp+0xB0]
00007fa9d6dde7a0  vmovaps xmm13, [rsp+0xC0]
00007fa9d6dde7a9  vmovaps xmm14, [rsp+0xD0]
00007fa9d6dde7b2  vmovaps xmm15, [rsp+0xE0]
00007fa9d6dde7bb  add rsp, 0xF0
00007fa9d6dde7c2  pop r11
00007fa9d6dde7c4  pop r10
00007fa9d6dde7c6  pop r9
00007fa9d6dde7c8  pop r8
00007fa9d6dde7ca  pop rsi
00007fa9d6dde7cb  pop rdi
00007fa9d6dde7cc  pop rdx
00007fa9d6dde7cd  pop rcx
00007fa9d6dde7ce  pop rax
00007fa9d6dde7cf  add rsp, 0x08
00007fa9d6dde7d3  jmp 0x00007FA9D6DDC1AA
00007fa9d6dde7d8  call 0x00007FA9D6CB52F0
00007fa9d6dde7dd  jmp 0x00007FA9D6DDC1B7
00007fa9d6dde7e2  sub rsp, 0x08
00007fa9d6dde7e6  push rax
00007fa9d6dde7e7  push rcx
00007fa9d6dde7e8  push rdx
00007fa9d6dde7e9  push rdi
00007fa9d6dde7ea  push rsi
00007fa9d6dde7eb  push r8
00007fa9d6dde7ed  push r9
00007fa9d6dde7ef  push r10
00007fa9d6dde7f1  push r11
00007fa9d6dde7f3  sub rsp, 0xF0
00007fa9d6dde7fa  vmovaps [rsp], xmm0
00007fa9d6dde7ff  vmovaps [rsp+0x10], xmm1
00007fa9d6dde805  vmovaps [rsp+0x20], xmm2
00007fa9d6dde80b  vmovaps [rsp+0x30], xmm3
00007fa9d6dde811  vmovaps [rsp+0x40], xmm4
00007fa9d6dde817  vmovaps [rsp+0x50], xmm5
00007fa9d6dde81d  vmovaps [rsp+0x60], xmm6
00007fa9d6dde823  vmovaps [rsp+0x70], xmm7
00007fa9d6dde829  vmovaps [rsp+0x80], xmm8
00007fa9d6dde832  vmovaps [rsp+0x90], xmm9
00007fa9d6dde83b  vmovaps [rsp+0xA0], xmm10
00007fa9d6dde844  vmovaps [rsp+0xB0], xmm11
00007fa9d6dde84d  vmovaps [rsp+0xC0], xmm12
00007fa9d6dde856  vmovaps [rsp+0xD0], xmm13
00007fa9d6dde85f  vmovaps [rsp+0xE0], xmm14
00007fa9d6dde868  sub rsp, 0x30
00007fa9d6dde86c  movaps [rsp], xmm15
00007fa9d6dde871  movaps [rsp+0x10], xmm3
00007fa9d6dde876  movaps [rsp+0x20], xmm7
00007fa9d6dde87b  lea rdi, [rsp]
00007fa9d6dde87f  mov esi, 0x00
00007fa9d6dde884  mov rax, 0x61DF872DB530
00007fa9d6dde88e  call rax
00007fa9d6dde890  movaps xmm15, [rsp]
00007fa9d6dde895  add rsp, 0x30
00007fa9d6dde899  vmovaps xmm0, [rsp]
00007fa9d6dde89e  vmovaps xmm1, [rsp+0x10]
00007fa9d6dde8a4  vmovaps xmm2, [rsp+0x20]
00007fa9d6dde8aa  vmovaps xmm3, [rsp+0x30]
00007fa9d6dde8b0  vmovaps xmm4, [rsp+0x40]
00007fa9d6dde8b6  vmovaps xmm5, [rsp+0x50]
00007fa9d6dde8bc  vmovaps xmm6, [rsp+0x60]
00007fa9d6dde8c2  vmovaps xmm7, [rsp+0x70]
00007fa9d6dde8c8  vmovaps xmm8, [rsp+0x80]
00007fa9d6dde8d1  vmovaps xmm9, [rsp+0x90]
00007fa9d6dde8da  vmovaps xmm10, [rsp+0xA0]
00007fa9d6dde8e3  vmovaps xmm11, [rsp+0xB0]
00007fa9d6dde8ec  vmovaps xmm12, [rsp+0xC0]
00007fa9d6dde8f5  vmovaps xmm13, [rsp+0xD0]
00007fa9d6dde8fe  vmovaps xmm14, [rsp+0xE0]
00007fa9d6dde907  add rsp, 0xF0
00007fa9d6dde90e  pop r11
00007fa9d6dde910  pop r10
00007fa9d6dde912  pop r9
00007fa9d6dde914  pop r8
00007fa9d6dde916  pop rsi
00007fa9d6dde917  pop rdi
00007fa9d6dde918  pop rdx
00007fa9d6dde919  pop rcx
00007fa9d6dde91a  pop rax
00007fa9d6dde91b  add rsp, 0x08
00007fa9d6dde91f  jmp 0x00007FA9D6DDC1E3
00007fa9d6dde924  sub rsp, 0x08
00007fa9d6dde928  push rax
00007fa9d6dde929  push rcx
00007fa9d6dde92a  push rdx
00007fa9d6dde92b  push rdi
00007fa9d6dde92c  push rsi
00007fa9d6dde92d  push r8
00007fa9d6dde92f  push r9
00007fa9d6dde931  push r10
00007fa9d6dde933  push r11
00007fa9d6dde935  sub rsp, 0xF0
00007fa9d6dde93c  vmovaps [rsp], xmm0
00007fa9d6dde941  vmovaps [rsp+0x10], xmm1
00007fa9d6dde947  vmovaps [rsp+0x20], xmm2
00007fa9d6dde94d  vmovaps [rsp+0x30], xmm4
00007fa9d6dde953  vmovaps [rsp+0x40], xmm5
00007fa9d6dde959  vmovaps [rsp+0x50], xmm6
00007fa9d6dde95f  vmovaps [rsp+0x60], xmm7
00007fa9d6dde965  vmovaps [rsp+0x70], xmm8
00007fa9d6dde96b  vmovaps [rsp+0x80], xmm9
00007fa9d6dde974  vmovaps [rsp+0x90], xmm10
00007fa9d6dde97d  vmovaps [rsp+0xA0], xmm11
00007fa9d6dde986  vmovaps [rsp+0xB0], xmm12
00007fa9d6dde98f  vmovaps [rsp+0xC0], xmm13
00007fa9d6dde998  vmovaps [rsp+0xD0], xmm14
00007fa9d6dde9a1  vmovaps [rsp+0xE0], xmm15
00007fa9d6dde9aa  sub rsp, 0x30
00007fa9d6dde9ae  movaps [rsp], xmm3
00007fa9d6dde9b2  movaps [rsp+0x10], xmm1
00007fa9d6dde9b7  movaps [rsp+0x20], xmm15
00007fa9d6dde9bd  lea rdi, [rsp]
00007fa9d6dde9c1  mov esi, 0x00
00007fa9d6dde9c6  mov rax, 0x61DF872DB530
00007fa9d6dde9d0  call rax
00007fa9d6dde9d2  movaps xmm3, [rsp]
00007fa9d6dde9d6  add rsp, 0x30
00007fa9d6dde9da  vmovaps xmm0, [rsp]
00007fa9d6dde9df  vmovaps xmm1, [rsp+0x10]
00007fa9d6dde9e5  vmovaps xmm2, [rsp+0x20]
00007fa9d6dde9eb  vmovaps xmm4, [rsp+0x30]
00007fa9d6dde9f1  vmovaps xmm5, [rsp+0x40]
00007fa9d6dde9f7  vmovaps xmm6, [rsp+0x50]
00007fa9d6dde9fd  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddea03  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddea09  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddea12  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddea1b  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddea24  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddea2d  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddea36  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddea3f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddea48  add rsp, 0xF0
00007fa9d6ddea4f  pop r11
00007fa9d6ddea51  pop r10
00007fa9d6ddea53  pop r9
00007fa9d6ddea55  pop r8
00007fa9d6ddea57  pop rsi
00007fa9d6ddea58  pop rdi
00007fa9d6ddea59  pop rdx
00007fa9d6ddea5a  pop rcx
00007fa9d6ddea5b  pop rax
00007fa9d6ddea5c  add rsp, 0x08
00007fa9d6ddea60  jmp 0x00007FA9D6DDC272
00007fa9d6ddea65  call 0x00007FA9D6CB52F0
00007fa9d6ddea6a  jmp 0x00007FA9D6DDC27C
00007fa9d6ddea6f  sub rsp, 0x08
00007fa9d6ddea73  push rax
00007fa9d6ddea74  push rcx
00007fa9d6ddea75  push rdx
00007fa9d6ddea76  push rdi
00007fa9d6ddea77  push rsi
00007fa9d6ddea78  push r8
00007fa9d6ddea7a  push r9
00007fa9d6ddea7c  push r10
00007fa9d6ddea7e  push r11
00007fa9d6ddea80  sub rsp, 0xF0
00007fa9d6ddea87  vmovaps [rsp], xmm0
00007fa9d6ddea8c  vmovaps [rsp+0x10], xmm1
00007fa9d6ddea92  vmovaps [rsp+0x20], xmm2
00007fa9d6ddea98  vmovaps [rsp+0x30], xmm3
00007fa9d6ddea9e  vmovaps [rsp+0x40], xmm4
00007fa9d6ddeaa4  vmovaps [rsp+0x50], xmm5
00007fa9d6ddeaaa  vmovaps [rsp+0x60], xmm6
00007fa9d6ddeab0  vmovaps [rsp+0x70], xmm7
00007fa9d6ddeab6  vmovaps [rsp+0x80], xmm8
00007fa9d6ddeabf  vmovaps [rsp+0x90], xmm9
00007fa9d6ddeac8  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddead1  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddeada  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddeae3  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddeaec  vmovaps [rsp+0xE0], xmm14
00007fa9d6ddeaf5  sub rsp, 0x30
00007fa9d6ddeaf9  movaps [rsp], xmm15
00007fa9d6ddeafe  movaps [rsp+0x10], xmm14
00007fa9d6ddeb04  movaps [rsp+0x20], xmm4
00007fa9d6ddeb09  lea rdi, [rsp]
00007fa9d6ddeb0d  mov esi, 0x00
00007fa9d6ddeb12  mov rax, 0x61DF872DB530
00007fa9d6ddeb1c  call rax
00007fa9d6ddeb1e  movaps xmm15, [rsp]
00007fa9d6ddeb23  add rsp, 0x30
00007fa9d6ddeb27  vmovaps xmm0, [rsp]
00007fa9d6ddeb2c  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddeb32  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddeb38  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddeb3e  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddeb44  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddeb4a  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddeb50  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddeb56  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddeb5f  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddeb68  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddeb71  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddeb7a  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddeb83  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddeb8c  vmovaps xmm14, [rsp+0xE0]
00007fa9d6ddeb95  add rsp, 0xF0
00007fa9d6ddeb9c  pop r11
00007fa9d6ddeb9e  pop r10
00007fa9d6ddeba0  pop r9
00007fa9d6ddeba2  pop r8
00007fa9d6ddeba4  pop rsi
00007fa9d6ddeba5  pop rdi
00007fa9d6ddeba6  pop rdx
00007fa9d6ddeba7  pop rcx
00007fa9d6ddeba8  pop rax
00007fa9d6ddeba9  add rsp, 0x08
00007fa9d6ddebad  jmp 0x00007FA9D6DDC2AA
00007fa9d6ddebb2  sub rsp, 0x08
00007fa9d6ddebb6  push rax
00007fa9d6ddebb7  push rcx
00007fa9d6ddebb8  push rdx
00007fa9d6ddebb9  push rdi
00007fa9d6ddebba  push rsi
00007fa9d6ddebbb  push r8
00007fa9d6ddebbd  push r9
00007fa9d6ddebbf  push r10
00007fa9d6ddebc1  push r11
00007fa9d6ddebc3  sub rsp, 0xF0
00007fa9d6ddebca  vmovaps [rsp], xmm0
00007fa9d6ddebcf  vmovaps [rsp+0x10], xmm1
00007fa9d6ddebd5  vmovaps [rsp+0x20], xmm2
00007fa9d6ddebdb  vmovaps [rsp+0x30], xmm3
00007fa9d6ddebe1  vmovaps [rsp+0x40], xmm4
00007fa9d6ddebe7  vmovaps [rsp+0x50], xmm5
00007fa9d6ddebed  vmovaps [rsp+0x60], xmm6
00007fa9d6ddebf3  vmovaps [rsp+0x70], xmm7
00007fa9d6ddebf9  vmovaps [rsp+0x80], xmm8
00007fa9d6ddec02  vmovaps [rsp+0x90], xmm9
00007fa9d6ddec0b  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddec14  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddec1d  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddec26  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddec2f  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddec38  sub rsp, 0x30
00007fa9d6ddec3c  movaps [rsp], xmm14
00007fa9d6ddec41  movaps [rsp+0x10], xmm2
00007fa9d6ddec46  movaps [rsp+0x20], xmm1
00007fa9d6ddec4b  lea rdi, [rsp]
00007fa9d6ddec4f  mov esi, 0x00
00007fa9d6ddec54  mov rax, 0x61DF872DB530
00007fa9d6ddec5e  call rax
00007fa9d6ddec60  movaps xmm14, [rsp]
00007fa9d6ddec65  add rsp, 0x30
00007fa9d6ddec69  vmovaps xmm0, [rsp]
00007fa9d6ddec6e  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddec74  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddec7a  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddec80  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddec86  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddec8c  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddec92  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddec98  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddeca1  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddecaa  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddecb3  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddecbc  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddecc5  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddecce  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddecd7  add rsp, 0xF0
00007fa9d6ddecde  pop r11
00007fa9d6ddece0  pop r10
00007fa9d6ddece2  pop r9
00007fa9d6ddece4  pop r8
00007fa9d6ddece6  pop rsi
00007fa9d6ddece7  pop rdi
00007fa9d6ddece8  pop rdx
00007fa9d6ddece9  pop rcx
00007fa9d6ddecea  pop rax
00007fa9d6ddeceb  add rsp, 0x08
00007fa9d6ddecef  jmp 0x00007FA9D6DDC2D0
00007fa9d6ddecf4  sub rsp, 0x08
00007fa9d6ddecf8  push rax
00007fa9d6ddecf9  push rcx
00007fa9d6ddecfa  push rdx
00007fa9d6ddecfb  push rdi
00007fa9d6ddecfc  push rsi
00007fa9d6ddecfd  push r8
00007fa9d6ddecff  push r9
00007fa9d6dded01  push r10
00007fa9d6dded03  push r11
00007fa9d6dded05  sub rsp, 0xF0
00007fa9d6dded0c  vmovaps [rsp], xmm0
00007fa9d6dded11  vmovaps [rsp+0x10], xmm2
00007fa9d6dded17  vmovaps [rsp+0x20], xmm3
00007fa9d6dded1d  vmovaps [rsp+0x30], xmm4
00007fa9d6dded23  vmovaps [rsp+0x40], xmm5
00007fa9d6dded29  vmovaps [rsp+0x50], xmm6
00007fa9d6dded2f  vmovaps [rsp+0x60], xmm7
00007fa9d6dded35  vmovaps [rsp+0x70], xmm8
00007fa9d6dded3b  vmovaps [rsp+0x80], xmm9
00007fa9d6dded44  vmovaps [rsp+0x90], xmm10
00007fa9d6dded4d  vmovaps [rsp+0xA0], xmm11
00007fa9d6dded56  vmovaps [rsp+0xB0], xmm12
00007fa9d6dded5f  vmovaps [rsp+0xC0], xmm13
00007fa9d6dded68  vmovaps [rsp+0xD0], xmm14
00007fa9d6dded71  vmovaps [rsp+0xE0], xmm15
00007fa9d6dded7a  sub rsp, 0x30
00007fa9d6dded7e  movaps [rsp], xmm1
00007fa9d6dded82  movaps [rsp+0x10], xmm4
00007fa9d6dded87  movaps [rsp+0x20], xmm9
00007fa9d6dded8d  lea rdi, [rsp]
00007fa9d6dded91  mov esi, 0x00
00007fa9d6dded96  mov rax, 0x61DF872DB530
00007fa9d6ddeda0  call rax
00007fa9d6ddeda2  movaps xmm1, [rsp]
00007fa9d6ddeda6  add rsp, 0x30
00007fa9d6ddedaa  vmovaps xmm0, [rsp]
00007fa9d6ddedaf  vmovaps xmm2, [rsp+0x10]
00007fa9d6ddedb5  vmovaps xmm3, [rsp+0x20]
00007fa9d6ddedbb  vmovaps xmm4, [rsp+0x30]
00007fa9d6ddedc1  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddedc7  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddedcd  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddedd3  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddedd9  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddede2  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddedeb  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddedf4  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddedfd  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddee06  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddee0f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddee18  add rsp, 0xF0
00007fa9d6ddee1f  pop r11
00007fa9d6ddee21  pop r10
00007fa9d6ddee23  pop r9
00007fa9d6ddee25  pop r8
00007fa9d6ddee27  pop rsi
00007fa9d6ddee28  pop rdi
00007fa9d6ddee29  pop rdx
00007fa9d6ddee2a  pop rcx
00007fa9d6ddee2b  pop rax
00007fa9d6ddee2c  add rsp, 0x08
00007fa9d6ddee30  jmp 0x00007FA9D6DDC2EE
00007fa9d6ddee35  sub rsp, 0x08
00007fa9d6ddee39  push rax
00007fa9d6ddee3a  push rcx
00007fa9d6ddee3b  push rdx
00007fa9d6ddee3c  push rdi
00007fa9d6ddee3d  push rsi
00007fa9d6ddee3e  push r8
00007fa9d6ddee40  push r9
00007fa9d6ddee42  push r10
00007fa9d6ddee44  push r11
00007fa9d6ddee46  sub rsp, 0xF0
00007fa9d6ddee4d  vmovaps [rsp], xmm0
00007fa9d6ddee52  vmovaps [rsp+0x10], xmm1
00007fa9d6ddee58  vmovaps [rsp+0x20], xmm2
00007fa9d6ddee5e  vmovaps [rsp+0x30], xmm3
00007fa9d6ddee64  vmovaps [rsp+0x40], xmm5
00007fa9d6ddee6a  vmovaps [rsp+0x50], xmm6
00007fa9d6ddee70  vmovaps [rsp+0x60], xmm7
00007fa9d6ddee76  vmovaps [rsp+0x70], xmm8
00007fa9d6ddee7c  vmovaps [rsp+0x80], xmm9
00007fa9d6ddee85  vmovaps [rsp+0x90], xmm10
00007fa9d6ddee8e  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddee97  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddeea0  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddeea9  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddeeb2  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddeebb  sub rsp, 0x30
00007fa9d6ddeebf  movaps [rsp], xmm4
00007fa9d6ddeec3  movaps [rsp+0x10], xmm2
00007fa9d6ddeec8  movaps [rsp+0x20], xmm9
00007fa9d6ddeece  lea rdi, [rsp]
00007fa9d6ddeed2  mov esi, 0x00
00007fa9d6ddeed7  mov rax, 0x61DF872DB530
00007fa9d6ddeee1  call rax
00007fa9d6ddeee3  movaps xmm4, [rsp]
00007fa9d6ddeee7  add rsp, 0x30
00007fa9d6ddeeeb  vmovaps xmm0, [rsp]
00007fa9d6ddeef0  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddeef6  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddeefc  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddef02  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddef08  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddef0e  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddef14  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddef1a  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddef23  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddef2c  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddef35  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddef3e  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddef47  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddef50  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddef59  add rsp, 0xF0
00007fa9d6ddef60  pop r11
00007fa9d6ddef62  pop r10
00007fa9d6ddef64  pop r9
00007fa9d6ddef66  pop r8
00007fa9d6ddef68  pop rsi
00007fa9d6ddef69  pop rdi
00007fa9d6ddef6a  pop rdx
00007fa9d6ddef6b  pop rcx
00007fa9d6ddef6c  pop rax
00007fa9d6ddef6d  add rsp, 0x08
00007fa9d6ddef71  jmp 0x00007FA9D6DDC31E
00007fa9d6ddef76  sub rsp, 0x08
00007fa9d6ddef7a  push rax
00007fa9d6ddef7b  push rcx
00007fa9d6ddef7c  push rdx
00007fa9d6ddef7d  push rdi
00007fa9d6ddef7e  push rsi
00007fa9d6ddef7f  push r8
00007fa9d6ddef81  push r9
00007fa9d6ddef83  push r10
00007fa9d6ddef85  push r11
00007fa9d6ddef87  sub rsp, 0xF0
00007fa9d6ddef8e  vmovaps [rsp], xmm0
00007fa9d6ddef93  vmovaps [rsp+0x10], xmm1
00007fa9d6ddef99  vmovaps [rsp+0x20], xmm2
00007fa9d6ddef9f  vmovaps [rsp+0x30], xmm3
00007fa9d6ddefa5  vmovaps [rsp+0x40], xmm4
00007fa9d6ddefab  vmovaps [rsp+0x50], xmm5
00007fa9d6ddefb1  vmovaps [rsp+0x60], xmm6
00007fa9d6ddefb7  vmovaps [rsp+0x70], xmm7
00007fa9d6ddefbd  vmovaps [rsp+0x80], xmm8
00007fa9d6ddefc6  vmovaps [rsp+0x90], xmm10
00007fa9d6ddefcf  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddefd8  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddefe1  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddefea  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddeff3  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddeffc  sub rsp, 0x30
00007fa9d6ddf000  movaps [rsp], xmm9
00007fa9d6ddf005  movaps [rsp+0x10], xmm2
00007fa9d6ddf00a  movaps [rsp+0x20], xmm1
00007fa9d6ddf00f  lea rdi, [rsp]
00007fa9d6ddf013  mov esi, 0x00
00007fa9d6ddf018  mov rax, 0x61DF872DB530
00007fa9d6ddf022  call rax
00007fa9d6ddf024  movaps xmm9, [rsp]
00007fa9d6ddf029  add rsp, 0x30
00007fa9d6ddf02d  vmovaps xmm0, [rsp]
00007fa9d6ddf032  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddf038  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddf03e  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddf044  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddf04a  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddf050  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddf056  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddf05c  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddf065  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddf06e  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddf077  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddf080  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddf089  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddf092  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddf09b  add rsp, 0xF0
00007fa9d6ddf0a2  pop r11
00007fa9d6ddf0a4  pop r10
00007fa9d6ddf0a6  pop r9
00007fa9d6ddf0a8  pop r8
00007fa9d6ddf0aa  pop rsi
00007fa9d6ddf0ab  pop rdi
00007fa9d6ddf0ac  pop rdx
00007fa9d6ddf0ad  pop rcx
00007fa9d6ddf0ae  pop rax
00007fa9d6ddf0af  add rsp, 0x08
00007fa9d6ddf0b3  jmp 0x00007FA9D6DDC354
00007fa9d6ddf0b8  sub rsp, 0x08
00007fa9d6ddf0bc  push rax
00007fa9d6ddf0bd  push rcx
00007fa9d6ddf0be  push rdx
00007fa9d6ddf0bf  push rdi
00007fa9d6ddf0c0  push rsi
00007fa9d6ddf0c1  push r8
00007fa9d6ddf0c3  push r9
00007fa9d6ddf0c5  push r10
00007fa9d6ddf0c7  push r11
00007fa9d6ddf0c9  sub rsp, 0xF0
00007fa9d6ddf0d0  vmovaps [rsp], xmm0
00007fa9d6ddf0d5  vmovaps [rsp+0x10], xmm2
00007fa9d6ddf0db  vmovaps [rsp+0x20], xmm3
00007fa9d6ddf0e1  vmovaps [rsp+0x30], xmm4
00007fa9d6ddf0e7  vmovaps [rsp+0x40], xmm5
00007fa9d6ddf0ed  vmovaps [rsp+0x50], xmm6
00007fa9d6ddf0f3  vmovaps [rsp+0x60], xmm7
00007fa9d6ddf0f9  vmovaps [rsp+0x70], xmm8
00007fa9d6ddf0ff  vmovaps [rsp+0x80], xmm9
00007fa9d6ddf108  vmovaps [rsp+0x90], xmm10
00007fa9d6ddf111  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddf11a  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddf123  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddf12c  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddf135  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddf13e  sub rsp, 0x30
00007fa9d6ddf142  movaps [rsp], xmm1
00007fa9d6ddf146  movaps [rsp+0x10], xmm15
00007fa9d6ddf14c  movaps [rsp+0x20], xmm6
00007fa9d6ddf151  lea rdi, [rsp]
00007fa9d6ddf155  mov esi, 0x00
00007fa9d6ddf15a  mov rax, 0x61DF872DB530
00007fa9d6ddf164  call rax
00007fa9d6ddf166  movaps xmm1, [rsp]
00007fa9d6ddf16a  add rsp, 0x30
00007fa9d6ddf16e  vmovaps xmm0, [rsp]
00007fa9d6ddf173  vmovaps xmm2, [rsp+0x10]
00007fa9d6ddf179  vmovaps xmm3, [rsp+0x20]
00007fa9d6ddf17f  vmovaps xmm4, [rsp+0x30]
00007fa9d6ddf185  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddf18b  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddf191  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddf197  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddf19d  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddf1a6  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddf1af  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddf1b8  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddf1c1  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddf1ca  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddf1d3  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddf1dc  add rsp, 0xF0
00007fa9d6ddf1e3  pop r11
00007fa9d6ddf1e5  pop r10
00007fa9d6ddf1e7  pop r9
00007fa9d6ddf1e9  pop r8
00007fa9d6ddf1eb  pop rsi
00007fa9d6ddf1ec  pop rdi
00007fa9d6ddf1ed  pop rdx
00007fa9d6ddf1ee  pop rcx
00007fa9d6ddf1ef  pop rax
00007fa9d6ddf1f0  add rsp, 0x08
00007fa9d6ddf1f4  jmp 0x00007FA9D6DDC375
00007fa9d6ddf1f9  sub rsp, 0x08
00007fa9d6ddf1fd  push rax
00007fa9d6ddf1fe  push rcx
00007fa9d6ddf1ff  push rdx
00007fa9d6ddf200  push rdi
00007fa9d6ddf201  push rsi
00007fa9d6ddf202  push r8
00007fa9d6ddf204  push r9
00007fa9d6ddf206  push r10
00007fa9d6ddf208  push r11
00007fa9d6ddf20a  sub rsp, 0xF0
00007fa9d6ddf211  vmovaps [rsp], xmm0
00007fa9d6ddf216  vmovaps [rsp+0x10], xmm1
00007fa9d6ddf21c  vmovaps [rsp+0x20], xmm2
00007fa9d6ddf222  vmovaps [rsp+0x30], xmm3
00007fa9d6ddf228  vmovaps [rsp+0x40], xmm4
00007fa9d6ddf22e  vmovaps [rsp+0x50], xmm5
00007fa9d6ddf234  vmovaps [rsp+0x60], xmm6
00007fa9d6ddf23a  vmovaps [rsp+0x70], xmm7
00007fa9d6ddf240  vmovaps [rsp+0x80], xmm8
00007fa9d6ddf249  vmovaps [rsp+0x90], xmm9
00007fa9d6ddf252  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddf25b  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddf264  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddf26d  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddf276  vmovaps [rsp+0xE0], xmm14
00007fa9d6ddf27f  sub rsp, 0x30
00007fa9d6ddf283  movaps [rsp], xmm15
00007fa9d6ddf288  movaps [rsp+0x10], xmm5
00007fa9d6ddf28d  movaps [rsp+0x20], xmm3
00007fa9d6ddf292  lea rdi, [rsp]
00007fa9d6ddf296  mov esi, 0x00
00007fa9d6ddf29b  mov rax, 0x61DF872DB530
00007fa9d6ddf2a5  call rax
00007fa9d6ddf2a7  movaps xmm15, [rsp]
00007fa9d6ddf2ac  add rsp, 0x30
00007fa9d6ddf2b0  vmovaps xmm0, [rsp]
00007fa9d6ddf2b5  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddf2bb  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddf2c1  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddf2c7  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddf2cd  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddf2d3  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddf2d9  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddf2df  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddf2e8  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddf2f1  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddf2fa  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddf303  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddf30c  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddf315  vmovaps xmm14, [rsp+0xE0]
00007fa9d6ddf31e  add rsp, 0xF0
00007fa9d6ddf325  pop r11
00007fa9d6ddf327  pop r10
00007fa9d6ddf329  pop r9
00007fa9d6ddf32b  pop r8
00007fa9d6ddf32d  pop rsi
00007fa9d6ddf32e  pop rdi
00007fa9d6ddf32f  pop rdx
00007fa9d6ddf330  pop rcx
00007fa9d6ddf331  pop rax
00007fa9d6ddf332  add rsp, 0x08
00007fa9d6ddf336  jmp 0x00007FA9D6DDC38F
00007fa9d6ddf33b  sub rsp, 0x08
00007fa9d6ddf33f  push rax
00007fa9d6ddf340  push rcx
00007fa9d6ddf341  push rdx
00007fa9d6ddf342  push rdi
00007fa9d6ddf343  push rsi
00007fa9d6ddf344  push r8
00007fa9d6ddf346  push r9
00007fa9d6ddf348  push r10
00007fa9d6ddf34a  push r11
00007fa9d6ddf34c  sub rsp, 0xF0
00007fa9d6ddf353  vmovaps [rsp], xmm0
00007fa9d6ddf358  vmovaps [rsp+0x10], xmm1
00007fa9d6ddf35e  vmovaps [rsp+0x20], xmm2
00007fa9d6ddf364  vmovaps [rsp+0x30], xmm3
00007fa9d6ddf36a  vmovaps [rsp+0x40], xmm4
00007fa9d6ddf370  vmovaps [rsp+0x50], xmm6
00007fa9d6ddf376  vmovaps [rsp+0x60], xmm7
00007fa9d6ddf37c  vmovaps [rsp+0x70], xmm8
00007fa9d6ddf382  vmovaps [rsp+0x80], xmm9
00007fa9d6ddf38b  vmovaps [rsp+0x90], xmm10
00007fa9d6ddf394  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddf39d  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddf3a6  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddf3af  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddf3b8  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddf3c1  sub rsp, 0x30
00007fa9d6ddf3c5  movaps [rsp], xmm5
00007fa9d6ddf3c9  movaps [rsp+0x10], xmm8
00007fa9d6ddf3cf  movaps [rsp+0x20], xmm6
00007fa9d6ddf3d4  lea rdi, [rsp]
00007fa9d6ddf3d8  mov esi, 0x00
00007fa9d6ddf3dd  mov rax, 0x61DF872DB530
00007fa9d6ddf3e7  call rax
00007fa9d6ddf3e9  movaps xmm5, [rsp]
00007fa9d6ddf3ed  add rsp, 0x30
00007fa9d6ddf3f1  vmovaps xmm0, [rsp]
00007fa9d6ddf3f6  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddf3fc  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddf402  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddf408  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddf40e  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddf414  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddf41a  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddf420  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddf429  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddf432  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddf43b  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddf444  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddf44d  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddf456  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddf45f  add rsp, 0xF0
00007fa9d6ddf466  pop r11
00007fa9d6ddf468  pop r10
00007fa9d6ddf46a  pop r9
00007fa9d6ddf46c  pop r8
00007fa9d6ddf46e  pop rsi
00007fa9d6ddf46f  pop rdi
00007fa9d6ddf470  pop rdx
00007fa9d6ddf471  pop rcx
00007fa9d6ddf472  pop rax
00007fa9d6ddf473  add rsp, 0x08
00007fa9d6ddf477  jmp 0x00007FA9D6DDC3B3
00007fa9d6ddf47c  sub rsp, 0x08
00007fa9d6ddf480  push rax
00007fa9d6ddf481  push rcx
00007fa9d6ddf482  push rdx
00007fa9d6ddf483  push rdi
00007fa9d6ddf484  push rsi
00007fa9d6ddf485  push r8
00007fa9d6ddf487  push r9
00007fa9d6ddf489  push r10
00007fa9d6ddf48b  push r11
00007fa9d6ddf48d  sub rsp, 0xF0
00007fa9d6ddf494  vmovaps [rsp], xmm0
00007fa9d6ddf499  vmovaps [rsp+0x10], xmm1
00007fa9d6ddf49f  vmovaps [rsp+0x20], xmm2
00007fa9d6ddf4a5  vmovaps [rsp+0x30], xmm3
00007fa9d6ddf4ab  vmovaps [rsp+0x40], xmm4
00007fa9d6ddf4b1  vmovaps [rsp+0x50], xmm5
00007fa9d6ddf4b7  vmovaps [rsp+0x60], xmm7
00007fa9d6ddf4bd  vmovaps [rsp+0x70], xmm8
00007fa9d6ddf4c3  vmovaps [rsp+0x80], xmm9
00007fa9d6ddf4cc  vmovaps [rsp+0x90], xmm10
00007fa9d6ddf4d5  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddf4de  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddf4e7  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddf4f0  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddf4f9  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddf502  sub rsp, 0x30
00007fa9d6ddf506  movaps [rsp], xmm6
00007fa9d6ddf50a  movaps [rsp+0x10], xmm10
00007fa9d6ddf510  movaps [rsp+0x20], xmm8
00007fa9d6ddf516  lea rdi, [rsp]
00007fa9d6ddf51a  mov esi, 0x00
00007fa9d6ddf51f  mov rax, 0x61DF872DB530
00007fa9d6ddf529  call rax
00007fa9d6ddf52b  movaps xmm6, [rsp]
00007fa9d6ddf52f  add rsp, 0x30
00007fa9d6ddf533  vmovaps xmm0, [rsp]
00007fa9d6ddf538  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddf53e  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddf544  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddf54a  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddf550  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddf556  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddf55c  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddf562  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddf56b  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddf574  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddf57d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddf586  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddf58f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddf598  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddf5a1  add rsp, 0xF0
00007fa9d6ddf5a8  pop r11
00007fa9d6ddf5aa  pop r10
00007fa9d6ddf5ac  pop r9
00007fa9d6ddf5ae  pop r8
00007fa9d6ddf5b0  pop rsi
00007fa9d6ddf5b1  pop rdi
00007fa9d6ddf5b2  pop rdx
00007fa9d6ddf5b3  pop rcx
00007fa9d6ddf5b4  pop rax
00007fa9d6ddf5b5  add rsp, 0x08
00007fa9d6ddf5b9  jmp 0x00007FA9D6DDC3D8
00007fa9d6ddf5be  sub rsp, 0x08
00007fa9d6ddf5c2  push rax
00007fa9d6ddf5c3  push rcx
00007fa9d6ddf5c4  push rdx
00007fa9d6ddf5c5  push rdi
00007fa9d6ddf5c6  push rsi
00007fa9d6ddf5c7  push r8
00007fa9d6ddf5c9  push r9
00007fa9d6ddf5cb  push r10
00007fa9d6ddf5cd  push r11
00007fa9d6ddf5cf  sub rsp, 0xF0
00007fa9d6ddf5d6  vmovaps [rsp], xmm0
00007fa9d6ddf5db  vmovaps [rsp+0x10], xmm1
00007fa9d6ddf5e1  vmovaps [rsp+0x20], xmm2
00007fa9d6ddf5e7  vmovaps [rsp+0x30], xmm3
00007fa9d6ddf5ed  vmovaps [rsp+0x40], xmm4
00007fa9d6ddf5f3  vmovaps [rsp+0x50], xmm5
00007fa9d6ddf5f9  vmovaps [rsp+0x60], xmm6
00007fa9d6ddf5ff  vmovaps [rsp+0x70], xmm7
00007fa9d6ddf605  vmovaps [rsp+0x80], xmm8
00007fa9d6ddf60e  vmovaps [rsp+0x90], xmm9
00007fa9d6ddf617  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddf620  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddf629  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddf632  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddf63b  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddf644  sub rsp, 0x30
00007fa9d6ddf648  movaps [rsp], xmm10
00007fa9d6ddf64d  movaps [rsp+0x10], xmm8
00007fa9d6ddf653  movaps [rsp+0x20], xmm14
00007fa9d6ddf659  lea rdi, [rsp]
00007fa9d6ddf65d  mov esi, 0x00
00007fa9d6ddf662  mov rax, 0x61DF872DB530
00007fa9d6ddf66c  call rax
00007fa9d6ddf66e  movaps xmm10, [rsp]
00007fa9d6ddf673  add rsp, 0x30
00007fa9d6ddf677  vmovaps xmm0, [rsp]
00007fa9d6ddf67c  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddf682  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddf688  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddf68e  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddf694  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddf69a  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddf6a0  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddf6a6  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddf6af  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddf6b8  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddf6c1  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddf6ca  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddf6d3  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddf6dc  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddf6e5  add rsp, 0xF0
00007fa9d6ddf6ec  pop r11
00007fa9d6ddf6ee  pop r10
00007fa9d6ddf6f0  pop r9
00007fa9d6ddf6f2  pop r8
00007fa9d6ddf6f4  pop rsi
00007fa9d6ddf6f5  pop rdi
00007fa9d6ddf6f6  pop rdx
00007fa9d6ddf6f7  pop rcx
00007fa9d6ddf6f8  pop rax
00007fa9d6ddf6f9  add rsp, 0x08
00007fa9d6ddf6fd  jmp 0x00007FA9D6DDC3F8
00007fa9d6ddf702  sub rsp, 0x08
00007fa9d6ddf706  push rax
00007fa9d6ddf707  push rcx
00007fa9d6ddf708  push rdx
00007fa9d6ddf709  push rdi
00007fa9d6ddf70a  push rsi
00007fa9d6ddf70b  push r8
00007fa9d6ddf70d  push r9
00007fa9d6ddf70f  push r10
00007fa9d6ddf711  push r11
00007fa9d6ddf713  sub rsp, 0xF0
00007fa9d6ddf71a  vmovaps [rsp], xmm0
00007fa9d6ddf71f  vmovaps [rsp+0x10], xmm1
00007fa9d6ddf725  vmovaps [rsp+0x20], xmm2
00007fa9d6ddf72b  vmovaps [rsp+0x30], xmm3
00007fa9d6ddf731  vmovaps [rsp+0x40], xmm4
00007fa9d6ddf737  vmovaps [rsp+0x50], xmm5
00007fa9d6ddf73d  vmovaps [rsp+0x60], xmm6
00007fa9d6ddf743  vmovaps [rsp+0x70], xmm7
00007fa9d6ddf749  vmovaps [rsp+0x80], xmm8
00007fa9d6ddf752  vmovaps [rsp+0x90], xmm9
00007fa9d6ddf75b  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddf764  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddf76d  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddf776  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddf77f  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddf788  sub rsp, 0x30
00007fa9d6ddf78c  movaps [rsp], xmm14
00007fa9d6ddf791  movaps [rsp+0x10], xmm8
00007fa9d6ddf797  movaps [rsp+0x20], xmm4
00007fa9d6ddf79c  lea rdi, [rsp]
00007fa9d6ddf7a0  mov esi, 0x00
00007fa9d6ddf7a5  mov rax, 0x61DF872DB530
00007fa9d6ddf7af  call rax
00007fa9d6ddf7b1  movaps xmm14, [rsp]
00007fa9d6ddf7b6  add rsp, 0x30
00007fa9d6ddf7ba  vmovaps xmm0, [rsp]
00007fa9d6ddf7bf  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddf7c5  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddf7cb  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddf7d1  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddf7d7  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddf7dd  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddf7e3  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddf7e9  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddf7f2  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddf7fb  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddf804  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddf80d  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddf816  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddf81f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddf828  add rsp, 0xF0
00007fa9d6ddf82f  pop r11
00007fa9d6ddf831  pop r10
00007fa9d6ddf833  pop r9
00007fa9d6ddf835  pop r8
00007fa9d6ddf837  pop rsi
00007fa9d6ddf838  pop rdi
00007fa9d6ddf839  pop rdx
00007fa9d6ddf83a  pop rcx
00007fa9d6ddf83b  pop rax
00007fa9d6ddf83c  add rsp, 0x08
00007fa9d6ddf840  jmp 0x00007FA9D6DDC418
00007fa9d6ddf845  sub rsp, 0x08
00007fa9d6ddf849  push rax
00007fa9d6ddf84a  push rcx
00007fa9d6ddf84b  push rdx
00007fa9d6ddf84c  push rdi
00007fa9d6ddf84d  push rsi
00007fa9d6ddf84e  push r8
00007fa9d6ddf850  push r9
00007fa9d6ddf852  push r10
00007fa9d6ddf854  push r11
00007fa9d6ddf856  sub rsp, 0xF0
00007fa9d6ddf85d  vmovaps [rsp], xmm0
00007fa9d6ddf862  vmovaps [rsp+0x10], xmm1
00007fa9d6ddf868  vmovaps [rsp+0x20], xmm2
00007fa9d6ddf86e  vmovaps [rsp+0x30], xmm3
00007fa9d6ddf874  vmovaps [rsp+0x40], xmm5
00007fa9d6ddf87a  vmovaps [rsp+0x50], xmm6
00007fa9d6ddf880  vmovaps [rsp+0x60], xmm7
00007fa9d6ddf886  vmovaps [rsp+0x70], xmm8
00007fa9d6ddf88c  vmovaps [rsp+0x80], xmm9
00007fa9d6ddf895  vmovaps [rsp+0x90], xmm10
00007fa9d6ddf89e  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddf8a7  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddf8b0  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddf8b9  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddf8c2  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddf8cb  sub rsp, 0x30
00007fa9d6ddf8cf  movaps [rsp], xmm4
00007fa9d6ddf8d3  movaps [rsp+0x10], xmm13
00007fa9d6ddf8d9  movaps [rsp+0x20], xmm8
00007fa9d6ddf8df  lea rdi, [rsp]
00007fa9d6ddf8e3  mov esi, 0x00
00007fa9d6ddf8e8  mov rax, 0x61DF872DB530
00007fa9d6ddf8f2  call rax
00007fa9d6ddf8f4  movaps xmm4, [rsp]
00007fa9d6ddf8f8  add rsp, 0x30
00007fa9d6ddf8fc  vmovaps xmm0, [rsp]
00007fa9d6ddf901  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddf907  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddf90d  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddf913  vmovaps xmm5, [rsp+0x40]
00007fa9d6ddf919  vmovaps xmm6, [rsp+0x50]
00007fa9d6ddf91f  vmovaps xmm7, [rsp+0x60]
00007fa9d6ddf925  vmovaps xmm8, [rsp+0x70]
00007fa9d6ddf92b  vmovaps xmm9, [rsp+0x80]
00007fa9d6ddf934  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddf93d  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddf946  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddf94f  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddf958  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddf961  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddf96a  add rsp, 0xF0
00007fa9d6ddf971  pop r11
00007fa9d6ddf973  pop r10
00007fa9d6ddf975  pop r9
00007fa9d6ddf977  pop r8
00007fa9d6ddf979  pop rsi
00007fa9d6ddf97a  pop rdi
00007fa9d6ddf97b  pop rdx
00007fa9d6ddf97c  pop rcx
00007fa9d6ddf97d  pop rax
00007fa9d6ddf97e  add rsp, 0x08
00007fa9d6ddf982  jmp 0x00007FA9D6DDC43D
00007fa9d6ddf987  sub rsp, 0x08
00007fa9d6ddf98b  push rax
00007fa9d6ddf98c  push rcx
00007fa9d6ddf98d  push rdx
00007fa9d6ddf98e  push rdi
00007fa9d6ddf98f  push rsi
00007fa9d6ddf990  push r8
00007fa9d6ddf992  push r9
00007fa9d6ddf994  push r10
00007fa9d6ddf996  push r11
00007fa9d6ddf998  sub rsp, 0xF0
00007fa9d6ddf99f  vmovaps [rsp], xmm0
00007fa9d6ddf9a4  vmovaps [rsp+0x10], xmm1
00007fa9d6ddf9aa  vmovaps [rsp+0x20], xmm2
00007fa9d6ddf9b0  vmovaps [rsp+0x30], xmm3
00007fa9d6ddf9b6  vmovaps [rsp+0x40], xmm4
00007fa9d6ddf9bc  vmovaps [rsp+0x50], xmm5
00007fa9d6ddf9c2  vmovaps [rsp+0x60], xmm6
00007fa9d6ddf9c8  vmovaps [rsp+0x70], xmm7
00007fa9d6ddf9ce  vmovaps [rsp+0x80], xmm8
00007fa9d6ddf9d7  vmovaps [rsp+0x90], xmm9
00007fa9d6ddf9e0  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddf9e9  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddf9f2  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddf9fb  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddfa04  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddfa0d  sub rsp, 0x30
00007fa9d6ddfa11  movaps [rsp], xmm13
00007fa9d6ddfa16  movaps [rsp+0x10], xmm15
00007fa9d6ddfa1c  movaps [rsp+0x20], xmm9
00007fa9d6ddfa22  lea rdi, [rsp]
00007fa9d6ddfa26  mov esi, 0x00
00007fa9d6ddfa2b  mov rax, 0x61DF872DB530
00007fa9d6ddfa35  call rax
00007fa9d6ddfa37  movaps xmm13, [rsp]
00007fa9d6ddfa3c  add rsp, 0x30
00007fa9d6ddfa40  vmovaps xmm0, [rsp]
00007fa9d6ddfa45  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddfa4b  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddfa51  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddfa57  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddfa5d  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddfa63  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddfa69  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddfa6f  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddfa78  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddfa81  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddfa8a  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddfa93  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddfa9c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddfaa5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddfaae  add rsp, 0xF0
00007fa9d6ddfab5  pop r11
00007fa9d6ddfab7  pop r10
00007fa9d6ddfab9  pop r9
00007fa9d6ddfabb  pop r8
00007fa9d6ddfabd  pop rsi
00007fa9d6ddfabe  pop rdi
00007fa9d6ddfabf  pop rdx
00007fa9d6ddfac0  pop rcx
00007fa9d6ddfac1  pop rax
00007fa9d6ddfac2  add rsp, 0x08
00007fa9d6ddfac6  jmp 0x00007FA9D6DDC458
00007fa9d6ddfacb  sub rsp, 0x08
00007fa9d6ddfacf  push rax
00007fa9d6ddfad0  push rcx
00007fa9d6ddfad1  push rdx
00007fa9d6ddfad2  push rdi
00007fa9d6ddfad3  push rsi
00007fa9d6ddfad4  push r8
00007fa9d6ddfad6  push r9
00007fa9d6ddfad8  push r10
00007fa9d6ddfada  push r11
00007fa9d6ddfadc  sub rsp, 0xF0
00007fa9d6ddfae3  vmovaps [rsp], xmm0
00007fa9d6ddfae8  vmovaps [rsp+0x10], xmm1
00007fa9d6ddfaee  vmovaps [rsp+0x20], xmm2
00007fa9d6ddfaf4  vmovaps [rsp+0x30], xmm3
00007fa9d6ddfafa  vmovaps [rsp+0x40], xmm4
00007fa9d6ddfb00  vmovaps [rsp+0x50], xmm5
00007fa9d6ddfb06  vmovaps [rsp+0x60], xmm6
00007fa9d6ddfb0c  vmovaps [rsp+0x70], xmm7
00007fa9d6ddfb12  vmovaps [rsp+0x80], xmm8
00007fa9d6ddfb1b  vmovaps [rsp+0x90], xmm9
00007fa9d6ddfb24  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddfb2d  vmovaps [rsp+0xB0], xmm11
00007fa9d6ddfb36  vmovaps [rsp+0xC0], xmm12
00007fa9d6ddfb3f  vmovaps [rsp+0xD0], xmm13
00007fa9d6ddfb48  vmovaps [rsp+0xE0], xmm14
00007fa9d6ddfb51  sub rsp, 0x30
00007fa9d6ddfb55  movaps [rsp], xmm15
00007fa9d6ddfb5a  movaps [rsp+0x10], xmm1
00007fa9d6ddfb5f  movaps [rsp+0x20], xmm5
00007fa9d6ddfb64  lea rdi, [rsp]
00007fa9d6ddfb68  mov esi, 0x00
00007fa9d6ddfb6d  mov rax, 0x61DF872DB530
00007fa9d6ddfb77  call rax
00007fa9d6ddfb79  movaps xmm15, [rsp]
00007fa9d6ddfb7e  add rsp, 0x30
00007fa9d6ddfb82  vmovaps xmm0, [rsp]
00007fa9d6ddfb87  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddfb8d  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddfb93  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddfb99  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddfb9f  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddfba5  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddfbab  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddfbb1  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddfbba  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddfbc3  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddfbcc  vmovaps xmm11, [rsp+0xB0]
00007fa9d6ddfbd5  vmovaps xmm12, [rsp+0xC0]
00007fa9d6ddfbde  vmovaps xmm13, [rsp+0xD0]
00007fa9d6ddfbe7  vmovaps xmm14, [rsp+0xE0]
00007fa9d6ddfbf0  add rsp, 0xF0
00007fa9d6ddfbf7  pop r11
00007fa9d6ddfbf9  pop r10
00007fa9d6ddfbfb  pop r9
00007fa9d6ddfbfd  pop r8
00007fa9d6ddfbff  pop rsi
00007fa9d6ddfc00  pop rdi
00007fa9d6ddfc01  pop rdx
00007fa9d6ddfc02  pop rcx
00007fa9d6ddfc03  pop rax
00007fa9d6ddfc04  add rsp, 0x08
00007fa9d6ddfc08  jmp 0x00007FA9D6DDC473
00007fa9d6ddfc0d  call 0x00007FA9D6CB52F0
00007fa9d6ddfc12  jmp 0x00007FA9D6DDC4CE
00007fa9d6ddfc17  sub rsp, 0x08
00007fa9d6ddfc1b  push rax
00007fa9d6ddfc1c  push rcx
00007fa9d6ddfc1d  push rdx
00007fa9d6ddfc1e  push rdi
00007fa9d6ddfc1f  push rsi
00007fa9d6ddfc20  push r8
00007fa9d6ddfc22  push r9
00007fa9d6ddfc24  push r10
00007fa9d6ddfc26  push r11
00007fa9d6ddfc28  sub rsp, 0xF0
00007fa9d6ddfc2f  vmovaps [rsp], xmm0
00007fa9d6ddfc34  vmovaps [rsp+0x10], xmm1
00007fa9d6ddfc3a  vmovaps [rsp+0x20], xmm2
00007fa9d6ddfc40  vmovaps [rsp+0x30], xmm3
00007fa9d6ddfc46  vmovaps [rsp+0x40], xmm4
00007fa9d6ddfc4c  vmovaps [rsp+0x50], xmm5
00007fa9d6ddfc52  vmovaps [rsp+0x60], xmm6
00007fa9d6ddfc58  vmovaps [rsp+0x70], xmm7
00007fa9d6ddfc5e  vmovaps [rsp+0x80], xmm8
00007fa9d6ddfc67  vmovaps [rsp+0x90], xmm10
00007fa9d6ddfc70  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddfc79  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddfc82  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddfc8b  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddfc94  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddfc9d  sub rsp, 0x30
00007fa9d6ddfca1  movaps [rsp], xmm9
00007fa9d6ddfca6  movaps [rsp+0x10], xmm8
00007fa9d6ddfcac  movaps [rsp+0x20], xmm11
00007fa9d6ddfcb2  lea rdi, [rsp]
00007fa9d6ddfcb6  mov esi, 0x00
00007fa9d6ddfcbb  mov rax, 0x61DF872DB530
00007fa9d6ddfcc5  call rax
00007fa9d6ddfcc7  movaps xmm9, [rsp]
00007fa9d6ddfccc  add rsp, 0x30
00007fa9d6ddfcd0  vmovaps xmm0, [rsp]
00007fa9d6ddfcd5  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddfcdb  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddfce1  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddfce7  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddfced  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddfcf3  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddfcf9  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddfcff  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddfd08  vmovaps xmm10, [rsp+0x90]
00007fa9d6ddfd11  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddfd1a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddfd23  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddfd2c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddfd35  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddfd3e  add rsp, 0xF0
00007fa9d6ddfd45  pop r11
00007fa9d6ddfd47  pop r10
00007fa9d6ddfd49  pop r9
00007fa9d6ddfd4b  pop r8
00007fa9d6ddfd4d  pop rsi
00007fa9d6ddfd4e  pop rdi
00007fa9d6ddfd4f  pop rdx
00007fa9d6ddfd50  pop rcx
00007fa9d6ddfd51  pop rax
00007fa9d6ddfd52  add rsp, 0x08
00007fa9d6ddfd56  jmp 0x00007FA9D6DDC505
00007fa9d6ddfd5b  sub rsp, 0x08
00007fa9d6ddfd5f  push rax
00007fa9d6ddfd60  push rcx
00007fa9d6ddfd61  push rdx
00007fa9d6ddfd62  push rdi
00007fa9d6ddfd63  push rsi
00007fa9d6ddfd64  push r8
00007fa9d6ddfd66  push r9
00007fa9d6ddfd68  push r10
00007fa9d6ddfd6a  push r11
00007fa9d6ddfd6c  sub rsp, 0xF0
00007fa9d6ddfd73  vmovaps [rsp], xmm0
00007fa9d6ddfd78  vmovaps [rsp+0x10], xmm1
00007fa9d6ddfd7e  vmovaps [rsp+0x20], xmm2
00007fa9d6ddfd84  vmovaps [rsp+0x30], xmm3
00007fa9d6ddfd8a  vmovaps [rsp+0x40], xmm4
00007fa9d6ddfd90  vmovaps [rsp+0x50], xmm5
00007fa9d6ddfd96  vmovaps [rsp+0x60], xmm6
00007fa9d6ddfd9c  vmovaps [rsp+0x70], xmm7
00007fa9d6ddfda2  vmovaps [rsp+0x80], xmm8
00007fa9d6ddfdab  vmovaps [rsp+0x90], xmm9
00007fa9d6ddfdb4  vmovaps [rsp+0xA0], xmm10
00007fa9d6ddfdbd  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddfdc6  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddfdcf  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddfdd8  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddfde1  sub rsp, 0x30
00007fa9d6ddfde5  movaps [rsp], xmm11
00007fa9d6ddfdea  movaps [rsp+0x10], xmm10
00007fa9d6ddfdf0  movaps [rsp+0x20], xmm6
00007fa9d6ddfdf5  lea rdi, [rsp]
00007fa9d6ddfdf9  mov esi, 0x00
00007fa9d6ddfdfe  mov rax, 0x61DF872DB530
00007fa9d6ddfe08  call rax
00007fa9d6ddfe0a  movaps xmm11, [rsp]
00007fa9d6ddfe0f  add rsp, 0x30
00007fa9d6ddfe13  vmovaps xmm0, [rsp]
00007fa9d6ddfe18  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddfe1e  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddfe24  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddfe2a  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddfe30  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddfe36  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddfe3c  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddfe42  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddfe4b  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddfe54  vmovaps xmm10, [rsp+0xA0]
00007fa9d6ddfe5d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddfe66  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddfe6f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddfe78  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddfe81  add rsp, 0xF0
00007fa9d6ddfe88  pop r11
00007fa9d6ddfe8a  pop r10
00007fa9d6ddfe8c  pop r9
00007fa9d6ddfe8e  pop r8
00007fa9d6ddfe90  pop rsi
00007fa9d6ddfe91  pop rdi
00007fa9d6ddfe92  pop rdx
00007fa9d6ddfe93  pop rcx
00007fa9d6ddfe94  pop rax
00007fa9d6ddfe95  add rsp, 0x08
00007fa9d6ddfe99  jmp 0x00007FA9D6DDC520
00007fa9d6ddfe9e  sub rsp, 0x08
00007fa9d6ddfea2  push rax
00007fa9d6ddfea3  push rcx
00007fa9d6ddfea4  push rdx
00007fa9d6ddfea5  push rdi
00007fa9d6ddfea6  push rsi
00007fa9d6ddfea7  push r8
00007fa9d6ddfea9  push r9
00007fa9d6ddfeab  push r10
00007fa9d6ddfead  push r11
00007fa9d6ddfeaf  sub rsp, 0xF0
00007fa9d6ddfeb6  vmovaps [rsp], xmm0
00007fa9d6ddfebb  vmovaps [rsp+0x10], xmm1
00007fa9d6ddfec1  vmovaps [rsp+0x20], xmm2
00007fa9d6ddfec7  vmovaps [rsp+0x30], xmm3
00007fa9d6ddfecd  vmovaps [rsp+0x40], xmm4
00007fa9d6ddfed3  vmovaps [rsp+0x50], xmm5
00007fa9d6ddfed9  vmovaps [rsp+0x60], xmm6
00007fa9d6ddfedf  vmovaps [rsp+0x70], xmm7
00007fa9d6ddfee5  vmovaps [rsp+0x80], xmm8
00007fa9d6ddfeee  vmovaps [rsp+0x90], xmm9
00007fa9d6ddfef7  vmovaps [rsp+0xA0], xmm11
00007fa9d6ddff00  vmovaps [rsp+0xB0], xmm12
00007fa9d6ddff09  vmovaps [rsp+0xC0], xmm13
00007fa9d6ddff12  vmovaps [rsp+0xD0], xmm14
00007fa9d6ddff1b  vmovaps [rsp+0xE0], xmm15
00007fa9d6ddff24  sub rsp, 0x30
00007fa9d6ddff28  movaps [rsp], xmm10
00007fa9d6ddff2d  movaps [rsp+0x10], xmm14
00007fa9d6ddff33  movaps [rsp+0x20], xmm4
00007fa9d6ddff38  lea rdi, [rsp]
00007fa9d6ddff3c  mov esi, 0x00
00007fa9d6ddff41  mov rax, 0x61DF872DB530
00007fa9d6ddff4b  call rax
00007fa9d6ddff4d  movaps xmm10, [rsp]
00007fa9d6ddff52  add rsp, 0x30
00007fa9d6ddff56  vmovaps xmm0, [rsp]
00007fa9d6ddff5b  vmovaps xmm1, [rsp+0x10]
00007fa9d6ddff61  vmovaps xmm2, [rsp+0x20]
00007fa9d6ddff67  vmovaps xmm3, [rsp+0x30]
00007fa9d6ddff6d  vmovaps xmm4, [rsp+0x40]
00007fa9d6ddff73  vmovaps xmm5, [rsp+0x50]
00007fa9d6ddff79  vmovaps xmm6, [rsp+0x60]
00007fa9d6ddff7f  vmovaps xmm7, [rsp+0x70]
00007fa9d6ddff85  vmovaps xmm8, [rsp+0x80]
00007fa9d6ddff8e  vmovaps xmm9, [rsp+0x90]
00007fa9d6ddff97  vmovaps xmm11, [rsp+0xA0]
00007fa9d6ddffa0  vmovaps xmm12, [rsp+0xB0]
00007fa9d6ddffa9  vmovaps xmm13, [rsp+0xC0]
00007fa9d6ddffb2  vmovaps xmm14, [rsp+0xD0]
00007fa9d6ddffbb  vmovaps xmm15, [rsp+0xE0]
00007fa9d6ddffc4  add rsp, 0xF0
00007fa9d6ddffcb  pop r11
00007fa9d6ddffcd  pop r10
00007fa9d6ddffcf  pop r9
00007fa9d6ddffd1  pop r8
00007fa9d6ddffd3  pop rsi
00007fa9d6ddffd4  pop rdi
00007fa9d6ddffd5  pop rdx
00007fa9d6ddffd6  pop rcx
00007fa9d6ddffd7  pop rax
00007fa9d6ddffd8  add rsp, 0x08
00007fa9d6ddffdc  jmp 0x00007FA9D6DDC53B
00007fa9d6ddffe1  sub rsp, 0x08
00007fa9d6ddffe5  push rax
00007fa9d6ddffe6  push rcx
00007fa9d6ddffe7  push rdx
00007fa9d6ddffe8  push rdi
00007fa9d6ddffe9  push rsi
00007fa9d6ddffea  push r8
00007fa9d6ddffec  push r9
00007fa9d6ddffee  push r10
00007fa9d6ddfff0  push r11
00007fa9d6ddfff2  sub rsp, 0xF0
00007fa9d6ddfff9  vmovaps [rsp], xmm0
00007fa9d6ddfffe  vmovaps [rsp+0x10], xmm1
00007fa9d6de0004  vmovaps [rsp+0x20], xmm2
00007fa9d6de000a  vmovaps [rsp+0x30], xmm3
00007fa9d6de0010  vmovaps [rsp+0x40], xmm4
00007fa9d6de0016  vmovaps [rsp+0x50], xmm5
00007fa9d6de001c  vmovaps [rsp+0x60], xmm6
00007fa9d6de0022  vmovaps [rsp+0x70], xmm7
00007fa9d6de0028  vmovaps [rsp+0x80], xmm9
00007fa9d6de0031  vmovaps [rsp+0x90], xmm10
00007fa9d6de003a  vmovaps [rsp+0xA0], xmm11
00007fa9d6de0043  vmovaps [rsp+0xB0], xmm12
00007fa9d6de004c  vmovaps [rsp+0xC0], xmm13
00007fa9d6de0055  vmovaps [rsp+0xD0], xmm14
00007fa9d6de005e  vmovaps [rsp+0xE0], xmm15
00007fa9d6de0067  sub rsp, 0x30
00007fa9d6de006b  movaps [rsp], xmm8
00007fa9d6de0070  movaps [rsp+0x10], xmm1
00007fa9d6de0075  movaps [rsp+0x20], xmm14
00007fa9d6de007b  lea rdi, [rsp]
00007fa9d6de007f  mov esi, 0x00
00007fa9d6de0084  mov rax, 0x61DF872DB530
00007fa9d6de008e  call rax
00007fa9d6de0090  movaps xmm8, [rsp]
00007fa9d6de0095  add rsp, 0x30
00007fa9d6de0099  vmovaps xmm0, [rsp]
00007fa9d6de009e  vmovaps xmm1, [rsp+0x10]
00007fa9d6de00a4  vmovaps xmm2, [rsp+0x20]
00007fa9d6de00aa  vmovaps xmm3, [rsp+0x30]
00007fa9d6de00b0  vmovaps xmm4, [rsp+0x40]
00007fa9d6de00b6  vmovaps xmm5, [rsp+0x50]
00007fa9d6de00bc  vmovaps xmm6, [rsp+0x60]
00007fa9d6de00c2  vmovaps xmm7, [rsp+0x70]
00007fa9d6de00c8  vmovaps xmm9, [rsp+0x80]
00007fa9d6de00d1  vmovaps xmm10, [rsp+0x90]
00007fa9d6de00da  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de00e3  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de00ec  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de00f5  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de00fe  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0107  add rsp, 0xF0
00007fa9d6de010e  pop r11
00007fa9d6de0110  pop r10
00007fa9d6de0112  pop r9
00007fa9d6de0114  pop r8
00007fa9d6de0116  pop rsi
00007fa9d6de0117  pop rdi
00007fa9d6de0118  pop rdx
00007fa9d6de0119  pop rcx
00007fa9d6de011a  pop rax
00007fa9d6de011b  add rsp, 0x08
00007fa9d6de011f  jmp 0x00007FA9D6DDC561
00007fa9d6de0124  sub rsp, 0x08
00007fa9d6de0128  push rax
00007fa9d6de0129  push rcx
00007fa9d6de012a  push rdx
00007fa9d6de012b  push rdi
00007fa9d6de012c  push rsi
00007fa9d6de012d  push r8
00007fa9d6de012f  push r9
00007fa9d6de0131  push r10
00007fa9d6de0133  push r11
00007fa9d6de0135  sub rsp, 0xF0
00007fa9d6de013c  vmovaps [rsp], xmm0
00007fa9d6de0141  vmovaps [rsp+0x10], xmm1
00007fa9d6de0147  vmovaps [rsp+0x20], xmm2
00007fa9d6de014d  vmovaps [rsp+0x30], xmm3
00007fa9d6de0153  vmovaps [rsp+0x40], xmm4
00007fa9d6de0159  vmovaps [rsp+0x50], xmm5
00007fa9d6de015f  vmovaps [rsp+0x60], xmm7
00007fa9d6de0165  vmovaps [rsp+0x70], xmm8
00007fa9d6de016b  vmovaps [rsp+0x80], xmm9
00007fa9d6de0174  vmovaps [rsp+0x90], xmm10
00007fa9d6de017d  vmovaps [rsp+0xA0], xmm11
00007fa9d6de0186  vmovaps [rsp+0xB0], xmm12
00007fa9d6de018f  vmovaps [rsp+0xC0], xmm13
00007fa9d6de0198  vmovaps [rsp+0xD0], xmm14
00007fa9d6de01a1  vmovaps [rsp+0xE0], xmm15
00007fa9d6de01aa  sub rsp, 0x30
00007fa9d6de01ae  movaps [rsp], xmm6
00007fa9d6de01b2  movaps [rsp+0x10], xmm1
00007fa9d6de01b7  movaps [rsp+0x20], xmm14
00007fa9d6de01bd  lea rdi, [rsp]
00007fa9d6de01c1  mov esi, 0x00
00007fa9d6de01c6  mov rax, 0x61DF872DB530
00007fa9d6de01d0  call rax
00007fa9d6de01d2  movaps xmm6, [rsp]
00007fa9d6de01d6  add rsp, 0x30
00007fa9d6de01da  vmovaps xmm0, [rsp]
00007fa9d6de01df  vmovaps xmm1, [rsp+0x10]
00007fa9d6de01e5  vmovaps xmm2, [rsp+0x20]
00007fa9d6de01eb  vmovaps xmm3, [rsp+0x30]
00007fa9d6de01f1  vmovaps xmm4, [rsp+0x40]
00007fa9d6de01f7  vmovaps xmm5, [rsp+0x50]
00007fa9d6de01fd  vmovaps xmm7, [rsp+0x60]
00007fa9d6de0203  vmovaps xmm8, [rsp+0x70]
00007fa9d6de0209  vmovaps xmm9, [rsp+0x80]
00007fa9d6de0212  vmovaps xmm10, [rsp+0x90]
00007fa9d6de021b  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de0224  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de022d  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de0236  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de023f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0248  add rsp, 0xF0
00007fa9d6de024f  pop r11
00007fa9d6de0251  pop r10
00007fa9d6de0253  pop r9
00007fa9d6de0255  pop r8
00007fa9d6de0257  pop rsi
00007fa9d6de0258  pop rdi
00007fa9d6de0259  pop rdx
00007fa9d6de025a  pop rcx
00007fa9d6de025b  pop rax
00007fa9d6de025c  add rsp, 0x08
00007fa9d6de0260  jmp 0x00007FA9D6DDC58D
00007fa9d6de0265  sub rsp, 0x08
00007fa9d6de0269  push rax
00007fa9d6de026a  push rcx
00007fa9d6de026b  push rdx
00007fa9d6de026c  push rdi
00007fa9d6de026d  push rsi
00007fa9d6de026e  push r8
00007fa9d6de0270  push r9
00007fa9d6de0272  push r10
00007fa9d6de0274  push r11
00007fa9d6de0276  sub rsp, 0xF0
00007fa9d6de027d  vmovaps [rsp], xmm0
00007fa9d6de0282  vmovaps [rsp+0x10], xmm1
00007fa9d6de0288  vmovaps [rsp+0x20], xmm2
00007fa9d6de028e  vmovaps [rsp+0x30], xmm3
00007fa9d6de0294  vmovaps [rsp+0x40], xmm4
00007fa9d6de029a  vmovaps [rsp+0x50], xmm5
00007fa9d6de02a0  vmovaps [rsp+0x60], xmm6
00007fa9d6de02a6  vmovaps [rsp+0x70], xmm7
00007fa9d6de02ac  vmovaps [rsp+0x80], xmm8
00007fa9d6de02b5  vmovaps [rsp+0x90], xmm9
00007fa9d6de02be  vmovaps [rsp+0xA0], xmm10
00007fa9d6de02c7  vmovaps [rsp+0xB0], xmm11
00007fa9d6de02d0  vmovaps [rsp+0xC0], xmm12
00007fa9d6de02d9  vmovaps [rsp+0xD0], xmm13
00007fa9d6de02e2  vmovaps [rsp+0xE0], xmm15
00007fa9d6de02eb  sub rsp, 0x30
00007fa9d6de02ef  movaps [rsp], xmm14
00007fa9d6de02f4  movaps [rsp+0x10], xmm12
00007fa9d6de02fa  movaps [rsp+0x20], xmm1
00007fa9d6de02ff  lea rdi, [rsp]
00007fa9d6de0303  mov esi, 0x00
00007fa9d6de0308  mov rax, 0x61DF872DB530
00007fa9d6de0312  call rax
00007fa9d6de0314  movaps xmm14, [rsp]
00007fa9d6de0319  add rsp, 0x30
00007fa9d6de031d  vmovaps xmm0, [rsp]
00007fa9d6de0322  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0328  vmovaps xmm2, [rsp+0x20]
00007fa9d6de032e  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0334  vmovaps xmm4, [rsp+0x40]
00007fa9d6de033a  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0340  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0346  vmovaps xmm7, [rsp+0x70]
00007fa9d6de034c  vmovaps xmm8, [rsp+0x80]
00007fa9d6de0355  vmovaps xmm9, [rsp+0x90]
00007fa9d6de035e  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de0367  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de0370  vmovaps xmm12, [rsp+0xC0]
00007fa9d6de0379  vmovaps xmm13, [rsp+0xD0]
00007fa9d6de0382  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de038b  add rsp, 0xF0
00007fa9d6de0392  pop r11
00007fa9d6de0394  pop r10
00007fa9d6de0396  pop r9
00007fa9d6de0398  pop r8
00007fa9d6de039a  pop rsi
00007fa9d6de039b  pop rdi
00007fa9d6de039c  pop rdx
00007fa9d6de039d  pop rcx
00007fa9d6de039e  pop rax
00007fa9d6de039f  add rsp, 0x08
00007fa9d6de03a3  jmp 0x00007FA9D6DDC5B3
00007fa9d6de03a8  sub rsp, 0x08
00007fa9d6de03ac  push rax
00007fa9d6de03ad  push rcx
00007fa9d6de03ae  push rdx
00007fa9d6de03af  push rdi
00007fa9d6de03b0  push rsi
00007fa9d6de03b1  push r8
00007fa9d6de03b3  push r9
00007fa9d6de03b5  push r10
00007fa9d6de03b7  push r11
00007fa9d6de03b9  sub rsp, 0xF0
00007fa9d6de03c0  vmovaps [rsp], xmm0
00007fa9d6de03c5  vmovaps [rsp+0x10], xmm2
00007fa9d6de03cb  vmovaps [rsp+0x20], xmm3
00007fa9d6de03d1  vmovaps [rsp+0x30], xmm4
00007fa9d6de03d7  vmovaps [rsp+0x40], xmm5
00007fa9d6de03dd  vmovaps [rsp+0x50], xmm6
00007fa9d6de03e3  vmovaps [rsp+0x60], xmm7
00007fa9d6de03e9  vmovaps [rsp+0x70], xmm8
00007fa9d6de03ef  vmovaps [rsp+0x80], xmm9
00007fa9d6de03f8  vmovaps [rsp+0x90], xmm10
00007fa9d6de0401  vmovaps [rsp+0xA0], xmm11
00007fa9d6de040a  vmovaps [rsp+0xB0], xmm12
00007fa9d6de0413  vmovaps [rsp+0xC0], xmm13
00007fa9d6de041c  vmovaps [rsp+0xD0], xmm14
00007fa9d6de0425  vmovaps [rsp+0xE0], xmm15
00007fa9d6de042e  sub rsp, 0x30
00007fa9d6de0432  movaps [rsp], xmm1
00007fa9d6de0436  movaps [rsp+0x10], xmm13
00007fa9d6de043c  movaps [rsp+0x20], xmm9
00007fa9d6de0442  lea rdi, [rsp]
00007fa9d6de0446  mov esi, 0x00
00007fa9d6de044b  mov rax, 0x61DF872DB530
00007fa9d6de0455  call rax
00007fa9d6de0457  movaps xmm1, [rsp]
00007fa9d6de045b  add rsp, 0x30
00007fa9d6de045f  vmovaps xmm0, [rsp]
00007fa9d6de0464  vmovaps xmm2, [rsp+0x10]
00007fa9d6de046a  vmovaps xmm3, [rsp+0x20]
00007fa9d6de0470  vmovaps xmm4, [rsp+0x30]
00007fa9d6de0476  vmovaps xmm5, [rsp+0x40]
00007fa9d6de047c  vmovaps xmm6, [rsp+0x50]
00007fa9d6de0482  vmovaps xmm7, [rsp+0x60]
00007fa9d6de0488  vmovaps xmm8, [rsp+0x70]
00007fa9d6de048e  vmovaps xmm9, [rsp+0x80]
00007fa9d6de0497  vmovaps xmm10, [rsp+0x90]
00007fa9d6de04a0  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de04a9  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de04b2  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de04bb  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de04c4  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de04cd  add rsp, 0xF0
00007fa9d6de04d4  pop r11
00007fa9d6de04d6  pop r10
00007fa9d6de04d8  pop r9
00007fa9d6de04da  pop r8
00007fa9d6de04dc  pop rsi
00007fa9d6de04dd  pop rdi
00007fa9d6de04de  pop rdx
00007fa9d6de04df  pop rcx
00007fa9d6de04e0  pop rax
00007fa9d6de04e1  add rsp, 0x08
00007fa9d6de04e5  jmp 0x00007FA9D6DDC5CD
00007fa9d6de04ea  sub rsp, 0x08
00007fa9d6de04ee  push rax
00007fa9d6de04ef  push rcx
00007fa9d6de04f0  push rdx
00007fa9d6de04f1  push rdi
00007fa9d6de04f2  push rsi
00007fa9d6de04f3  push r8
00007fa9d6de04f5  push r9
00007fa9d6de04f7  push r10
00007fa9d6de04f9  push r11
00007fa9d6de04fb  sub rsp, 0xF0
00007fa9d6de0502  vmovaps [rsp], xmm0
00007fa9d6de0507  vmovaps [rsp+0x10], xmm1
00007fa9d6de050d  vmovaps [rsp+0x20], xmm2
00007fa9d6de0513  vmovaps [rsp+0x30], xmm3
00007fa9d6de0519  vmovaps [rsp+0x40], xmm4
00007fa9d6de051f  vmovaps [rsp+0x50], xmm5
00007fa9d6de0525  vmovaps [rsp+0x60], xmm6
00007fa9d6de052b  vmovaps [rsp+0x70], xmm7
00007fa9d6de0531  vmovaps [rsp+0x80], xmm8
00007fa9d6de053a  vmovaps [rsp+0x90], xmm9
00007fa9d6de0543  vmovaps [rsp+0xA0], xmm10
00007fa9d6de054c  vmovaps [rsp+0xB0], xmm11
00007fa9d6de0555  vmovaps [rsp+0xC0], xmm13
00007fa9d6de055e  vmovaps [rsp+0xD0], xmm14
00007fa9d6de0567  vmovaps [rsp+0xE0], xmm15
00007fa9d6de0570  sub rsp, 0x30
00007fa9d6de0574  movaps [rsp], xmm12
00007fa9d6de0579  movaps [rsp+0x10], xmm7
00007fa9d6de057e  movaps [rsp+0x20], xmm13
00007fa9d6de0584  lea rdi, [rsp]
00007fa9d6de0588  mov esi, 0x00
00007fa9d6de058d  mov rax, 0x61DF872DB530
00007fa9d6de0597  call rax
00007fa9d6de0599  movaps xmm12, [rsp]
00007fa9d6de059e  add rsp, 0x30
00007fa9d6de05a2  vmovaps xmm0, [rsp]
00007fa9d6de05a7  vmovaps xmm1, [rsp+0x10]
00007fa9d6de05ad  vmovaps xmm2, [rsp+0x20]
00007fa9d6de05b3  vmovaps xmm3, [rsp+0x30]
00007fa9d6de05b9  vmovaps xmm4, [rsp+0x40]
00007fa9d6de05bf  vmovaps xmm5, [rsp+0x50]
00007fa9d6de05c5  vmovaps xmm6, [rsp+0x60]
00007fa9d6de05cb  vmovaps xmm7, [rsp+0x70]
00007fa9d6de05d1  vmovaps xmm8, [rsp+0x80]
00007fa9d6de05da  vmovaps xmm9, [rsp+0x90]
00007fa9d6de05e3  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de05ec  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de05f5  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de05fe  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de0607  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0610  add rsp, 0xF0
00007fa9d6de0617  pop r11
00007fa9d6de0619  pop r10
00007fa9d6de061b  pop r9
00007fa9d6de061d  pop r8
00007fa9d6de061f  pop rsi
00007fa9d6de0620  pop rdi
00007fa9d6de0621  pop rdx
00007fa9d6de0622  pop rcx
00007fa9d6de0623  pop rax
00007fa9d6de0624  add rsp, 0x08
00007fa9d6de0628  jmp 0x00007FA9D6DDC5F4
00007fa9d6de062d  sub rsp, 0x08
00007fa9d6de0631  push rax
00007fa9d6de0632  push rcx
00007fa9d6de0633  push rdx
00007fa9d6de0634  push rdi
00007fa9d6de0635  push rsi
00007fa9d6de0636  push r8
00007fa9d6de0638  push r9
00007fa9d6de063a  push r10
00007fa9d6de063c  push r11
00007fa9d6de063e  sub rsp, 0xF0
00007fa9d6de0645  vmovaps [rsp], xmm0
00007fa9d6de064a  vmovaps [rsp+0x10], xmm1
00007fa9d6de0650  vmovaps [rsp+0x20], xmm2
00007fa9d6de0656  vmovaps [rsp+0x30], xmm3
00007fa9d6de065c  vmovaps [rsp+0x40], xmm4
00007fa9d6de0662  vmovaps [rsp+0x50], xmm5
00007fa9d6de0668  vmovaps [rsp+0x60], xmm6
00007fa9d6de066e  vmovaps [rsp+0x70], xmm7
00007fa9d6de0674  vmovaps [rsp+0x80], xmm8
00007fa9d6de067d  vmovaps [rsp+0x90], xmm9
00007fa9d6de0686  vmovaps [rsp+0xA0], xmm10
00007fa9d6de068f  vmovaps [rsp+0xB0], xmm11
00007fa9d6de0698  vmovaps [rsp+0xC0], xmm12
00007fa9d6de06a1  vmovaps [rsp+0xD0], xmm14
00007fa9d6de06aa  vmovaps [rsp+0xE0], xmm15
00007fa9d6de06b3  sub rsp, 0x30
00007fa9d6de06b7  movaps [rsp], xmm13
00007fa9d6de06bc  movaps [rsp+0x10], xmm15
00007fa9d6de06c2  movaps [rsp+0x20], xmm8
00007fa9d6de06c8  lea rdi, [rsp]
00007fa9d6de06cc  mov esi, 0x00
00007fa9d6de06d1  mov rax, 0x61DF872DB530
00007fa9d6de06db  call rax
00007fa9d6de06dd  movaps xmm13, [rsp]
00007fa9d6de06e2  add rsp, 0x30
00007fa9d6de06e6  vmovaps xmm0, [rsp]
00007fa9d6de06eb  vmovaps xmm1, [rsp+0x10]
00007fa9d6de06f1  vmovaps xmm2, [rsp+0x20]
00007fa9d6de06f7  vmovaps xmm3, [rsp+0x30]
00007fa9d6de06fd  vmovaps xmm4, [rsp+0x40]
00007fa9d6de0703  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0709  vmovaps xmm6, [rsp+0x60]
00007fa9d6de070f  vmovaps xmm7, [rsp+0x70]
00007fa9d6de0715  vmovaps xmm8, [rsp+0x80]
00007fa9d6de071e  vmovaps xmm9, [rsp+0x90]
00007fa9d6de0727  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de0730  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de0739  vmovaps xmm12, [rsp+0xC0]
00007fa9d6de0742  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de074b  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0754  add rsp, 0xF0
00007fa9d6de075b  pop r11
00007fa9d6de075d  pop r10
00007fa9d6de075f  pop r9
00007fa9d6de0761  pop r8
00007fa9d6de0763  pop rsi
00007fa9d6de0764  pop rdi
00007fa9d6de0765  pop rdx
00007fa9d6de0766  pop rcx
00007fa9d6de0767  pop rax
00007fa9d6de0768  add rsp, 0x08
00007fa9d6de076c  jmp 0x00007FA9D6DDC60F
00007fa9d6de0771  sub rsp, 0x08
00007fa9d6de0775  push rax
00007fa9d6de0776  push rcx
00007fa9d6de0777  push rdx
00007fa9d6de0778  push rdi
00007fa9d6de0779  push rsi
00007fa9d6de077a  push r8
00007fa9d6de077c  push r9
00007fa9d6de077e  push r10
00007fa9d6de0780  push r11
00007fa9d6de0782  sub rsp, 0xF0
00007fa9d6de0789  vmovaps [rsp], xmm0
00007fa9d6de078e  vmovaps [rsp+0x10], xmm1
00007fa9d6de0794  vmovaps [rsp+0x20], xmm2
00007fa9d6de079a  vmovaps [rsp+0x30], xmm3
00007fa9d6de07a0  vmovaps [rsp+0x40], xmm4
00007fa9d6de07a6  vmovaps [rsp+0x50], xmm5
00007fa9d6de07ac  vmovaps [rsp+0x60], xmm6
00007fa9d6de07b2  vmovaps [rsp+0x70], xmm7
00007fa9d6de07b8  vmovaps [rsp+0x80], xmm9
00007fa9d6de07c1  vmovaps [rsp+0x90], xmm10
00007fa9d6de07ca  vmovaps [rsp+0xA0], xmm11
00007fa9d6de07d3  vmovaps [rsp+0xB0], xmm12
00007fa9d6de07dc  vmovaps [rsp+0xC0], xmm13
00007fa9d6de07e5  vmovaps [rsp+0xD0], xmm14
00007fa9d6de07ee  vmovaps [rsp+0xE0], xmm15
00007fa9d6de07f7  sub rsp, 0x30
00007fa9d6de07fb  movaps [rsp], xmm8
00007fa9d6de0800  movaps [rsp+0x10], xmm15
00007fa9d6de0806  movaps [rsp+0x20], xmm9
00007fa9d6de080c  lea rdi, [rsp]
00007fa9d6de0810  mov esi, 0x00
00007fa9d6de0815  mov rax, 0x61DF872DB530
00007fa9d6de081f  call rax
00007fa9d6de0821  movaps xmm8, [rsp]
00007fa9d6de0826  add rsp, 0x30
00007fa9d6de082a  vmovaps xmm0, [rsp]
00007fa9d6de082f  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0835  vmovaps xmm2, [rsp+0x20]
00007fa9d6de083b  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0841  vmovaps xmm4, [rsp+0x40]
00007fa9d6de0847  vmovaps xmm5, [rsp+0x50]
00007fa9d6de084d  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0853  vmovaps xmm7, [rsp+0x70]
00007fa9d6de0859  vmovaps xmm9, [rsp+0x80]
00007fa9d6de0862  vmovaps xmm10, [rsp+0x90]
00007fa9d6de086b  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de0874  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de087d  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de0886  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de088f  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0898  add rsp, 0xF0
00007fa9d6de089f  pop r11
00007fa9d6de08a1  pop r10
00007fa9d6de08a3  pop r9
00007fa9d6de08a5  pop r8
00007fa9d6de08a7  pop rsi
00007fa9d6de08a8  pop rdi
00007fa9d6de08a9  pop rdx
00007fa9d6de08aa  pop rcx
00007fa9d6de08ab  pop rax
00007fa9d6de08ac  add rsp, 0x08
00007fa9d6de08b0  jmp 0x00007FA9D6DDC63D
00007fa9d6de08b5  sub rsp, 0x08
00007fa9d6de08b9  push rax
00007fa9d6de08ba  push rcx
00007fa9d6de08bb  push rdx
00007fa9d6de08bc  push rdi
00007fa9d6de08bd  push rsi
00007fa9d6de08be  push r8
00007fa9d6de08c0  push r9
00007fa9d6de08c2  push r10
00007fa9d6de08c4  push r11
00007fa9d6de08c6  sub rsp, 0xF0
00007fa9d6de08cd  vmovaps [rsp], xmm0
00007fa9d6de08d2  vmovaps [rsp+0x10], xmm1
00007fa9d6de08d8  vmovaps [rsp+0x20], xmm2
00007fa9d6de08de  vmovaps [rsp+0x30], xmm3
00007fa9d6de08e4  vmovaps [rsp+0x40], xmm4
00007fa9d6de08ea  vmovaps [rsp+0x50], xmm5
00007fa9d6de08f0  vmovaps [rsp+0x60], xmm6
00007fa9d6de08f6  vmovaps [rsp+0x70], xmm7
00007fa9d6de08fc  vmovaps [rsp+0x80], xmm8
00007fa9d6de0905  vmovaps [rsp+0x90], xmm9
00007fa9d6de090e  vmovaps [rsp+0xA0], xmm10
00007fa9d6de0917  vmovaps [rsp+0xB0], xmm11
00007fa9d6de0920  vmovaps [rsp+0xC0], xmm12
00007fa9d6de0929  vmovaps [rsp+0xD0], xmm13
00007fa9d6de0932  vmovaps [rsp+0xE0], xmm14
00007fa9d6de093b  sub rsp, 0x30
00007fa9d6de093f  movaps [rsp], xmm15
00007fa9d6de0944  movaps [rsp+0x10], xmm11
00007fa9d6de094a  movaps [rsp+0x20], xmm6
00007fa9d6de094f  lea rdi, [rsp]
00007fa9d6de0953  mov esi, 0x00
00007fa9d6de0958  mov rax, 0x61DF872DB530
00007fa9d6de0962  call rax
00007fa9d6de0964  movaps xmm15, [rsp]
00007fa9d6de0969  add rsp, 0x30
00007fa9d6de096d  vmovaps xmm0, [rsp]
00007fa9d6de0972  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0978  vmovaps xmm2, [rsp+0x20]
00007fa9d6de097e  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0984  vmovaps xmm4, [rsp+0x40]
00007fa9d6de098a  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0990  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0996  vmovaps xmm7, [rsp+0x70]
00007fa9d6de099c  vmovaps xmm8, [rsp+0x80]
00007fa9d6de09a5  vmovaps xmm9, [rsp+0x90]
00007fa9d6de09ae  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de09b7  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de09c0  vmovaps xmm12, [rsp+0xC0]
00007fa9d6de09c9  vmovaps xmm13, [rsp+0xD0]
00007fa9d6de09d2  vmovaps xmm14, [rsp+0xE0]
00007fa9d6de09db  add rsp, 0xF0
00007fa9d6de09e2  pop r11
00007fa9d6de09e4  pop r10
00007fa9d6de09e6  pop r9
00007fa9d6de09e8  pop r8
00007fa9d6de09ea  pop rsi
00007fa9d6de09eb  pop rdi
00007fa9d6de09ec  pop rdx
00007fa9d6de09ed  pop rcx
00007fa9d6de09ee  pop rax
00007fa9d6de09ef  add rsp, 0x08
00007fa9d6de09f3  jmp 0x00007FA9D6DDC658
00007fa9d6de09f8  sub rsp, 0x08
00007fa9d6de09fc  push rax
00007fa9d6de09fd  push rcx
00007fa9d6de09fe  push rdx
00007fa9d6de09ff  push rdi
00007fa9d6de0a00  push rsi
00007fa9d6de0a01  push r8
00007fa9d6de0a03  push r9
00007fa9d6de0a05  push r10
00007fa9d6de0a07  push r11
00007fa9d6de0a09  sub rsp, 0xF0
00007fa9d6de0a10  vmovaps [rsp], xmm0
00007fa9d6de0a15  vmovaps [rsp+0x10], xmm1
00007fa9d6de0a1b  vmovaps [rsp+0x20], xmm2
00007fa9d6de0a21  vmovaps [rsp+0x30], xmm3
00007fa9d6de0a27  vmovaps [rsp+0x40], xmm4
00007fa9d6de0a2d  vmovaps [rsp+0x50], xmm5
00007fa9d6de0a33  vmovaps [rsp+0x60], xmm6
00007fa9d6de0a39  vmovaps [rsp+0x70], xmm8
00007fa9d6de0a3f  vmovaps [rsp+0x80], xmm9
00007fa9d6de0a48  vmovaps [rsp+0x90], xmm10
00007fa9d6de0a51  vmovaps [rsp+0xA0], xmm11
00007fa9d6de0a5a  vmovaps [rsp+0xB0], xmm12
00007fa9d6de0a63  vmovaps [rsp+0xC0], xmm13
00007fa9d6de0a6c  vmovaps [rsp+0xD0], xmm14
00007fa9d6de0a75  vmovaps [rsp+0xE0], xmm15
00007fa9d6de0a7e  sub rsp, 0x30
00007fa9d6de0a82  movaps [rsp], xmm7
00007fa9d6de0a86  movaps [rsp+0x10], xmm11
00007fa9d6de0a8c  movaps [rsp+0x20], xmm9
00007fa9d6de0a92  lea rdi, [rsp]
00007fa9d6de0a96  mov esi, 0x00
00007fa9d6de0a9b  mov rax, 0x61DF872DB530
00007fa9d6de0aa5  call rax
00007fa9d6de0aa7  movaps xmm7, [rsp]
00007fa9d6de0aab  add rsp, 0x30
00007fa9d6de0aaf  vmovaps xmm0, [rsp]
00007fa9d6de0ab4  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0aba  vmovaps xmm2, [rsp+0x20]
00007fa9d6de0ac0  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0ac6  vmovaps xmm4, [rsp+0x40]
00007fa9d6de0acc  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0ad2  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0ad8  vmovaps xmm8, [rsp+0x70]
00007fa9d6de0ade  vmovaps xmm9, [rsp+0x80]
00007fa9d6de0ae7  vmovaps xmm10, [rsp+0x90]
00007fa9d6de0af0  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de0af9  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de0b02  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de0b0b  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de0b14  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0b1d  add rsp, 0xF0
00007fa9d6de0b24  pop r11
00007fa9d6de0b26  pop r10
00007fa9d6de0b28  pop r9
00007fa9d6de0b2a  pop r8
00007fa9d6de0b2c  pop rsi
00007fa9d6de0b2d  pop rdi
00007fa9d6de0b2e  pop rdx
00007fa9d6de0b2f  pop rcx
00007fa9d6de0b30  pop rax
00007fa9d6de0b31  add rsp, 0x08
00007fa9d6de0b35  jmp 0x00007FA9D6DDC685
00007fa9d6de0b3a  sub rsp, 0x08
00007fa9d6de0b3e  push rax
00007fa9d6de0b3f  push rcx
00007fa9d6de0b40  push rdx
00007fa9d6de0b41  push rdi
00007fa9d6de0b42  push rsi
00007fa9d6de0b43  push r8
00007fa9d6de0b45  push r9
00007fa9d6de0b47  push r10
00007fa9d6de0b49  push r11
00007fa9d6de0b4b  sub rsp, 0xF0
00007fa9d6de0b52  vmovaps [rsp], xmm0
00007fa9d6de0b57  vmovaps [rsp+0x10], xmm1
00007fa9d6de0b5d  vmovaps [rsp+0x20], xmm2
00007fa9d6de0b63  vmovaps [rsp+0x30], xmm3
00007fa9d6de0b69  vmovaps [rsp+0x40], xmm4
00007fa9d6de0b6f  vmovaps [rsp+0x50], xmm5
00007fa9d6de0b75  vmovaps [rsp+0x60], xmm6
00007fa9d6de0b7b  vmovaps [rsp+0x70], xmm7
00007fa9d6de0b81  vmovaps [rsp+0x80], xmm8
00007fa9d6de0b8a  vmovaps [rsp+0x90], xmm9
00007fa9d6de0b93  vmovaps [rsp+0xA0], xmm10
00007fa9d6de0b9c  vmovaps [rsp+0xB0], xmm12
00007fa9d6de0ba5  vmovaps [rsp+0xC0], xmm13
00007fa9d6de0bae  vmovaps [rsp+0xD0], xmm14
00007fa9d6de0bb7  vmovaps [rsp+0xE0], xmm15
00007fa9d6de0bc0  sub rsp, 0x30
00007fa9d6de0bc4  movaps [rsp], xmm11
00007fa9d6de0bc9  movaps [rsp+0x10], xmm10
00007fa9d6de0bcf  movaps [rsp+0x20], xmm14
00007fa9d6de0bd5  lea rdi, [rsp]
00007fa9d6de0bd9  mov esi, 0x00
00007fa9d6de0bde  mov rax, 0x61DF872DB530
00007fa9d6de0be8  call rax
00007fa9d6de0bea  movaps xmm11, [rsp]
00007fa9d6de0bef  add rsp, 0x30
00007fa9d6de0bf3  vmovaps xmm0, [rsp]
00007fa9d6de0bf8  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0bfe  vmovaps xmm2, [rsp+0x20]
00007fa9d6de0c04  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0c0a  vmovaps xmm4, [rsp+0x40]
00007fa9d6de0c10  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0c16  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0c1c  vmovaps xmm7, [rsp+0x70]
00007fa9d6de0c22  vmovaps xmm8, [rsp+0x80]
00007fa9d6de0c2b  vmovaps xmm9, [rsp+0x90]
00007fa9d6de0c34  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de0c3d  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de0c46  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de0c4f  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de0c58  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0c61  add rsp, 0xF0
00007fa9d6de0c68  pop r11
00007fa9d6de0c6a  pop r10
00007fa9d6de0c6c  pop r9
00007fa9d6de0c6e  pop r8
00007fa9d6de0c70  pop rsi
00007fa9d6de0c71  pop rdi
00007fa9d6de0c72  pop rdx
00007fa9d6de0c73  pop rcx
00007fa9d6de0c74  pop rax
00007fa9d6de0c75  add rsp, 0x08
00007fa9d6de0c79  jmp 0x00007FA9D6DDC6A0
00007fa9d6de0c7e  call 0x00007FA9D6CC33A0
00007fa9d6de0c83  jmp 0x00007FA9D6DDC6AA
00007fa9d6de0c88  sub rsp, 0x08
00007fa9d6de0c8c  push rax
00007fa9d6de0c8d  push rcx
00007fa9d6de0c8e  push rdx
00007fa9d6de0c8f  push rdi
00007fa9d6de0c90  push rsi
00007fa9d6de0c91  push r8
00007fa9d6de0c93  push r9
00007fa9d6de0c95  push r10
00007fa9d6de0c97  push r11
00007fa9d6de0c99  sub rsp, 0xF0
00007fa9d6de0ca0  vmovaps [rsp], xmm0
00007fa9d6de0ca5  vmovaps [rsp+0x10], xmm1
00007fa9d6de0cab  vmovaps [rsp+0x20], xmm2
00007fa9d6de0cb1  vmovaps [rsp+0x30], xmm3
00007fa9d6de0cb7  vmovaps [rsp+0x40], xmm4
00007fa9d6de0cbd  vmovaps [rsp+0x50], xmm5
00007fa9d6de0cc3  vmovaps [rsp+0x60], xmm6
00007fa9d6de0cc9  vmovaps [rsp+0x70], xmm7
00007fa9d6de0ccf  vmovaps [rsp+0x80], xmm8
00007fa9d6de0cd8  vmovaps [rsp+0x90], xmm9
00007fa9d6de0ce1  vmovaps [rsp+0xA0], xmm11
00007fa9d6de0cea  vmovaps [rsp+0xB0], xmm12
00007fa9d6de0cf3  vmovaps [rsp+0xC0], xmm13
00007fa9d6de0cfc  vmovaps [rsp+0xD0], xmm14
00007fa9d6de0d05  vmovaps [rsp+0xE0], xmm15
00007fa9d6de0d0e  sub rsp, 0x30
00007fa9d6de0d12  movaps [rsp], xmm10
00007fa9d6de0d17  movaps [rsp+0x10], xmm1
00007fa9d6de0d1c  movaps [rsp+0x20], xmm12
00007fa9d6de0d22  lea rdi, [rsp]
00007fa9d6de0d26  mov esi, 0x00
00007fa9d6de0d2b  mov rax, 0x61DF872DB530
00007fa9d6de0d35  call rax
00007fa9d6de0d37  movaps xmm10, [rsp]
00007fa9d6de0d3c  add rsp, 0x30
00007fa9d6de0d40  vmovaps xmm0, [rsp]
00007fa9d6de0d45  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0d4b  vmovaps xmm2, [rsp+0x20]
00007fa9d6de0d51  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0d57  vmovaps xmm4, [rsp+0x40]
00007fa9d6de0d5d  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0d63  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0d69  vmovaps xmm7, [rsp+0x70]
00007fa9d6de0d6f  vmovaps xmm8, [rsp+0x80]
00007fa9d6de0d78  vmovaps xmm9, [rsp+0x90]
00007fa9d6de0d81  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de0d8a  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de0d93  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de0d9c  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de0da5  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0dae  add rsp, 0xF0
00007fa9d6de0db5  pop r11
00007fa9d6de0db7  pop r10
00007fa9d6de0db9  pop r9
00007fa9d6de0dbb  pop r8
00007fa9d6de0dbd  pop rsi
00007fa9d6de0dbe  pop rdi
00007fa9d6de0dbf  pop rdx
00007fa9d6de0dc0  pop rcx
00007fa9d6de0dc1  pop rax
00007fa9d6de0dc2  add rsp, 0x08
00007fa9d6de0dc6  jmp 0x00007FA9D6DDC6CD
00007fa9d6de0dcb  sub rsp, 0x08
00007fa9d6de0dcf  push rax
00007fa9d6de0dd0  push rcx
00007fa9d6de0dd1  push rdx
00007fa9d6de0dd2  push rdi
00007fa9d6de0dd3  push rsi
00007fa9d6de0dd4  push r8
00007fa9d6de0dd6  push r9
00007fa9d6de0dd8  push r10
00007fa9d6de0dda  push r11
00007fa9d6de0ddc  sub rsp, 0xF0
00007fa9d6de0de3  vmovaps [rsp], xmm0
00007fa9d6de0de8  vmovaps [rsp+0x10], xmm1
00007fa9d6de0dee  vmovaps [rsp+0x20], xmm2
00007fa9d6de0df4  vmovaps [rsp+0x30], xmm3
00007fa9d6de0dfa  vmovaps [rsp+0x40], xmm4
00007fa9d6de0e00  vmovaps [rsp+0x50], xmm5
00007fa9d6de0e06  vmovaps [rsp+0x60], xmm6
00007fa9d6de0e0c  vmovaps [rsp+0x70], xmm7
00007fa9d6de0e12  vmovaps [rsp+0x80], xmm8
00007fa9d6de0e1b  vmovaps [rsp+0x90], xmm9
00007fa9d6de0e24  vmovaps [rsp+0xA0], xmm10
00007fa9d6de0e2d  vmovaps [rsp+0xB0], xmm11
00007fa9d6de0e36  vmovaps [rsp+0xC0], xmm13
00007fa9d6de0e3f  vmovaps [rsp+0xD0], xmm14
00007fa9d6de0e48  vmovaps [rsp+0xE0], xmm15
00007fa9d6de0e51  sub rsp, 0x30
00007fa9d6de0e55  movaps [rsp], xmm12
00007fa9d6de0e5a  movaps [rsp+0x10], xmm14
00007fa9d6de0e60  movaps [rsp+0x20], xmm1
00007fa9d6de0e65  lea rdi, [rsp]
00007fa9d6de0e69  mov esi, 0x00
00007fa9d6de0e6e  mov rax, 0x61DF872DB530
00007fa9d6de0e78  call rax
00007fa9d6de0e7a  movaps xmm12, [rsp]
00007fa9d6de0e7f  add rsp, 0x30
00007fa9d6de0e83  vmovaps xmm0, [rsp]
00007fa9d6de0e88  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0e8e  vmovaps xmm2, [rsp+0x20]
00007fa9d6de0e94  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0e9a  vmovaps xmm4, [rsp+0x40]
00007fa9d6de0ea0  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0ea6  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0eac  vmovaps xmm7, [rsp+0x70]
00007fa9d6de0eb2  vmovaps xmm8, [rsp+0x80]
00007fa9d6de0ebb  vmovaps xmm9, [rsp+0x90]
00007fa9d6de0ec4  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de0ecd  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de0ed6  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de0edf  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de0ee8  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de0ef1  add rsp, 0xF0
00007fa9d6de0ef8  pop r11
00007fa9d6de0efa  pop r10
00007fa9d6de0efc  pop r9
00007fa9d6de0efe  pop r8
00007fa9d6de0f00  pop rsi
00007fa9d6de0f01  pop rdi
00007fa9d6de0f02  pop rdx
00007fa9d6de0f03  pop rcx
00007fa9d6de0f04  pop rax
00007fa9d6de0f05  add rsp, 0x08
00007fa9d6de0f09  jmp 0x00007FA9D6DDC6FC
00007fa9d6de0f0e  sub rsp, 0x08
00007fa9d6de0f12  push rax
00007fa9d6de0f13  push rcx
00007fa9d6de0f14  push rdx
00007fa9d6de0f15  push rdi
00007fa9d6de0f16  push rsi
00007fa9d6de0f17  push r8
00007fa9d6de0f19  push r9
00007fa9d6de0f1b  push r10
00007fa9d6de0f1d  push r11
00007fa9d6de0f1f  sub rsp, 0xF0
00007fa9d6de0f26  vmovaps [rsp], xmm0
00007fa9d6de0f2b  vmovaps [rsp+0x10], xmm1
00007fa9d6de0f31  vmovaps [rsp+0x20], xmm2
00007fa9d6de0f37  vmovaps [rsp+0x30], xmm3
00007fa9d6de0f3d  vmovaps [rsp+0x40], xmm4
00007fa9d6de0f43  vmovaps [rsp+0x50], xmm5
00007fa9d6de0f49  vmovaps [rsp+0x60], xmm6
00007fa9d6de0f4f  vmovaps [rsp+0x70], xmm7
00007fa9d6de0f55  vmovaps [rsp+0x80], xmm8
00007fa9d6de0f5e  vmovaps [rsp+0x90], xmm9
00007fa9d6de0f67  vmovaps [rsp+0xA0], xmm10
00007fa9d6de0f70  vmovaps [rsp+0xB0], xmm11
00007fa9d6de0f79  vmovaps [rsp+0xC0], xmm12
00007fa9d6de0f82  vmovaps [rsp+0xD0], xmm13
00007fa9d6de0f8b  vmovaps [rsp+0xE0], xmm15
00007fa9d6de0f94  sub rsp, 0x30
00007fa9d6de0f98  movaps [rsp], xmm14
00007fa9d6de0f9d  movaps [rsp+0x10], xmm9
00007fa9d6de0fa3  movaps [rsp+0x20], xmm1
00007fa9d6de0fa8  lea rdi, [rsp]
00007fa9d6de0fac  mov esi, 0x00
00007fa9d6de0fb1  mov rax, 0x61DF872DB530
00007fa9d6de0fbb  call rax
00007fa9d6de0fbd  movaps xmm14, [rsp]
00007fa9d6de0fc2  add rsp, 0x30
00007fa9d6de0fc6  vmovaps xmm0, [rsp]
00007fa9d6de0fcb  vmovaps xmm1, [rsp+0x10]
00007fa9d6de0fd1  vmovaps xmm2, [rsp+0x20]
00007fa9d6de0fd7  vmovaps xmm3, [rsp+0x30]
00007fa9d6de0fdd  vmovaps xmm4, [rsp+0x40]
00007fa9d6de0fe3  vmovaps xmm5, [rsp+0x50]
00007fa9d6de0fe9  vmovaps xmm6, [rsp+0x60]
00007fa9d6de0fef  vmovaps xmm7, [rsp+0x70]
00007fa9d6de0ff5  vmovaps xmm8, [rsp+0x80]
00007fa9d6de0ffe  vmovaps xmm9, [rsp+0x90]
00007fa9d6de1007  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de1010  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de1019  vmovaps xmm12, [rsp+0xC0]
00007fa9d6de1022  vmovaps xmm13, [rsp+0xD0]
00007fa9d6de102b  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de1034  add rsp, 0xF0
00007fa9d6de103b  pop r11
00007fa9d6de103d  pop r10
00007fa9d6de103f  pop r9
00007fa9d6de1041  pop r8
00007fa9d6de1043  pop rsi
00007fa9d6de1044  pop rdi
00007fa9d6de1045  pop rdx
00007fa9d6de1046  pop rcx
00007fa9d6de1047  pop rax
00007fa9d6de1048  add rsp, 0x08
00007fa9d6de104c  jmp 0x00007FA9D6DDC72B
00007fa9d6de1051  sub rsp, 0x08
00007fa9d6de1055  push rax
00007fa9d6de1056  push rcx
00007fa9d6de1057  push rdx
00007fa9d6de1058  push rdi
00007fa9d6de1059  push rsi
00007fa9d6de105a  push r8
00007fa9d6de105c  push r9
00007fa9d6de105e  push r10
00007fa9d6de1060  push r11
00007fa9d6de1062  sub rsp, 0xF0
00007fa9d6de1069  vmovaps [rsp], xmm0
00007fa9d6de106e  vmovaps [rsp+0x10], xmm2
00007fa9d6de1074  vmovaps [rsp+0x20], xmm3
00007fa9d6de107a  vmovaps [rsp+0x30], xmm4
00007fa9d6de1080  vmovaps [rsp+0x40], xmm5
00007fa9d6de1086  vmovaps [rsp+0x50], xmm6
00007fa9d6de108c  vmovaps [rsp+0x60], xmm7
00007fa9d6de1092  vmovaps [rsp+0x70], xmm8
00007fa9d6de1098  vmovaps [rsp+0x80], xmm9
00007fa9d6de10a1  vmovaps [rsp+0x90], xmm10
00007fa9d6de10aa  vmovaps [rsp+0xA0], xmm11
00007fa9d6de10b3  vmovaps [rsp+0xB0], xmm12
00007fa9d6de10bc  vmovaps [rsp+0xC0], xmm13
00007fa9d6de10c5  vmovaps [rsp+0xD0], xmm14
00007fa9d6de10ce  vmovaps [rsp+0xE0], xmm15
00007fa9d6de10d7  sub rsp, 0x30
00007fa9d6de10db  movaps [rsp], xmm1
00007fa9d6de10df  movaps [rsp+0x10], xmm13
00007fa9d6de10e5  movaps [rsp+0x20], xmm8
00007fa9d6de10eb  lea rdi, [rsp]
00007fa9d6de10ef  mov esi, 0x00
00007fa9d6de10f4  mov rax, 0x61DF872DB530
00007fa9d6de10fe  call rax
00007fa9d6de1100  movaps xmm1, [rsp]
00007fa9d6de1104  add rsp, 0x30
00007fa9d6de1108  vmovaps xmm0, [rsp]
00007fa9d6de110d  vmovaps xmm2, [rsp+0x10]
00007fa9d6de1113  vmovaps xmm3, [rsp+0x20]
00007fa9d6de1119  vmovaps xmm4, [rsp+0x30]
00007fa9d6de111f  vmovaps xmm5, [rsp+0x40]
00007fa9d6de1125  vmovaps xmm6, [rsp+0x50]
00007fa9d6de112b  vmovaps xmm7, [rsp+0x60]
00007fa9d6de1131  vmovaps xmm8, [rsp+0x70]
00007fa9d6de1137  vmovaps xmm9, [rsp+0x80]
00007fa9d6de1140  vmovaps xmm10, [rsp+0x90]
00007fa9d6de1149  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de1152  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de115b  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de1164  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de116d  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de1176  add rsp, 0xF0
00007fa9d6de117d  pop r11
00007fa9d6de117f  pop r10
00007fa9d6de1181  pop r9
00007fa9d6de1183  pop r8
00007fa9d6de1185  pop rsi
00007fa9d6de1186  pop rdi
00007fa9d6de1187  pop rdx
00007fa9d6de1188  pop rcx
00007fa9d6de1189  pop rax
00007fa9d6de118a  add rsp, 0x08
00007fa9d6de118e  jmp 0x00007FA9D6DDC74D
00007fa9d6de1193  call 0x00007FA9D6C0C260
00007fa9d6de1198  jmp 0x00007FA9D6DDC75B
00007fa9d6de119d  call 0x00007FA9D6CBD750
00007fa9d6de11a2  jmp 0x00007FA9D6DDC765
00007fa9d6de11a7  sub rsp, 0x08
00007fa9d6de11ab  push rax
00007fa9d6de11ac  push rcx
00007fa9d6de11ad  push rdx
00007fa9d6de11ae  push rdi
00007fa9d6de11af  push rsi
00007fa9d6de11b0  push r8
00007fa9d6de11b2  push r9
00007fa9d6de11b4  push r10
00007fa9d6de11b6  push r11
00007fa9d6de11b8  sub rsp, 0xF0
00007fa9d6de11bf  vmovaps [rsp], xmm0
00007fa9d6de11c4  vmovaps [rsp+0x10], xmm1
00007fa9d6de11ca  vmovaps [rsp+0x20], xmm2
00007fa9d6de11d0  vmovaps [rsp+0x30], xmm3
00007fa9d6de11d6  vmovaps [rsp+0x40], xmm4
00007fa9d6de11dc  vmovaps [rsp+0x50], xmm5
00007fa9d6de11e2  vmovaps [rsp+0x60], xmm6
00007fa9d6de11e8  vmovaps [rsp+0x70], xmm7
00007fa9d6de11ee  vmovaps [rsp+0x80], xmm9
00007fa9d6de11f7  vmovaps [rsp+0x90], xmm10
00007fa9d6de1200  vmovaps [rsp+0xA0], xmm11
00007fa9d6de1209  vmovaps [rsp+0xB0], xmm12
00007fa9d6de1212  vmovaps [rsp+0xC0], xmm13
00007fa9d6de121b  vmovaps [rsp+0xD0], xmm14
00007fa9d6de1224  vmovaps [rsp+0xE0], xmm15
00007fa9d6de122d  sub rsp, 0x30
00007fa9d6de1231  movaps [rsp], xmm8
00007fa9d6de1236  movaps [rsp+0x10], xmm15
00007fa9d6de123c  movaps [rsp+0x20], xmm7
00007fa9d6de1241  lea rdi, [rsp]
00007fa9d6de1245  mov esi, 0x00
00007fa9d6de124a  mov rax, 0x61DF872DB530
00007fa9d6de1254  call rax
00007fa9d6de1256  movaps xmm8, [rsp]
00007fa9d6de125b  add rsp, 0x30
00007fa9d6de125f  vmovaps xmm0, [rsp]
00007fa9d6de1264  vmovaps xmm1, [rsp+0x10]
00007fa9d6de126a  vmovaps xmm2, [rsp+0x20]
00007fa9d6de1270  vmovaps xmm3, [rsp+0x30]
00007fa9d6de1276  vmovaps xmm4, [rsp+0x40]
00007fa9d6de127c  vmovaps xmm5, [rsp+0x50]
00007fa9d6de1282  vmovaps xmm6, [rsp+0x60]
00007fa9d6de1288  vmovaps xmm7, [rsp+0x70]
00007fa9d6de128e  vmovaps xmm9, [rsp+0x80]
00007fa9d6de1297  vmovaps xmm10, [rsp+0x90]
00007fa9d6de12a0  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de12a9  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de12b2  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de12bb  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de12c4  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de12cd  add rsp, 0xF0
00007fa9d6de12d4  pop r11
00007fa9d6de12d6  pop r10
00007fa9d6de12d8  pop r9
00007fa9d6de12da  pop r8
00007fa9d6de12dc  pop rsi
00007fa9d6de12dd  pop rdi
00007fa9d6de12de  pop rdx
00007fa9d6de12df  pop rcx
00007fa9d6de12e0  pop rax
00007fa9d6de12e1  add rsp, 0x08
00007fa9d6de12e5  jmp 0x00007FA9D6DDC787
00007fa9d6de12ea  sub rsp, 0x08
00007fa9d6de12ee  push rax
00007fa9d6de12ef  push rcx
00007fa9d6de12f0  push rdx
00007fa9d6de12f1  push rdi
00007fa9d6de12f2  push rsi
00007fa9d6de12f3  push r8
00007fa9d6de12f5  push r9
00007fa9d6de12f7  push r10
00007fa9d6de12f9  push r11
00007fa9d6de12fb  sub rsp, 0xF0
00007fa9d6de1302  vmovaps [rsp], xmm0
00007fa9d6de1307  vmovaps [rsp+0x10], xmm1
00007fa9d6de130d  vmovaps [rsp+0x20], xmm2
00007fa9d6de1313  vmovaps [rsp+0x30], xmm3
00007fa9d6de1319  vmovaps [rsp+0x40], xmm4
00007fa9d6de131f  vmovaps [rsp+0x50], xmm5
00007fa9d6de1325  vmovaps [rsp+0x60], xmm6
00007fa9d6de132b  vmovaps [rsp+0x70], xmm8
00007fa9d6de1331  vmovaps [rsp+0x80], xmm9
00007fa9d6de133a  vmovaps [rsp+0x90], xmm10
00007fa9d6de1343  vmovaps [rsp+0xA0], xmm11
00007fa9d6de134c  vmovaps [rsp+0xB0], xmm12
00007fa9d6de1355  vmovaps [rsp+0xC0], xmm13
00007fa9d6de135e  vmovaps [rsp+0xD0], xmm14
00007fa9d6de1367  vmovaps [rsp+0xE0], xmm15
00007fa9d6de1370  sub rsp, 0x30
00007fa9d6de1374  movaps [rsp], xmm7
00007fa9d6de1378  movaps [rsp+0x10], xmm9
00007fa9d6de137e  movaps [rsp+0x20], xmm15
00007fa9d6de1384  lea rdi, [rsp]
00007fa9d6de1388  mov esi, 0x00
00007fa9d6de138d  mov rax, 0x61DF872DB530
00007fa9d6de1397  call rax
00007fa9d6de1399  movaps xmm7, [rsp]
00007fa9d6de139d  add rsp, 0x30
00007fa9d6de13a1  vmovaps xmm0, [rsp]
00007fa9d6de13a6  vmovaps xmm1, [rsp+0x10]
00007fa9d6de13ac  vmovaps xmm2, [rsp+0x20]
00007fa9d6de13b2  vmovaps xmm3, [rsp+0x30]
00007fa9d6de13b8  vmovaps xmm4, [rsp+0x40]
00007fa9d6de13be  vmovaps xmm5, [rsp+0x50]
00007fa9d6de13c4  vmovaps xmm6, [rsp+0x60]
00007fa9d6de13ca  vmovaps xmm8, [rsp+0x70]
00007fa9d6de13d0  vmovaps xmm9, [rsp+0x80]
00007fa9d6de13d9  vmovaps xmm10, [rsp+0x90]
00007fa9d6de13e2  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de13eb  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de13f4  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de13fd  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de1406  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de140f  add rsp, 0xF0
00007fa9d6de1416  pop r11
00007fa9d6de1418  pop r10
00007fa9d6de141a  pop r9
00007fa9d6de141c  pop r8
00007fa9d6de141e  pop rsi
00007fa9d6de141f  pop rdi
00007fa9d6de1420  pop rdx
00007fa9d6de1421  pop rcx
00007fa9d6de1422  pop rax
00007fa9d6de1423  add rsp, 0x08
00007fa9d6de1427  jmp 0x00007FA9D6DDC7B4
00007fa9d6de142c  sub rsp, 0x08
00007fa9d6de1430  push rax
00007fa9d6de1431  push rcx
00007fa9d6de1432  push rdx
00007fa9d6de1433  push rdi
00007fa9d6de1434  push rsi
00007fa9d6de1435  push r8
00007fa9d6de1437  push r9
00007fa9d6de1439  push r10
00007fa9d6de143b  push r11
00007fa9d6de143d  sub rsp, 0xF0
00007fa9d6de1444  vmovaps [rsp], xmm0
00007fa9d6de1449  vmovaps [rsp+0x10], xmm1
00007fa9d6de144f  vmovaps [rsp+0x20], xmm2
00007fa9d6de1455  vmovaps [rsp+0x30], xmm3
00007fa9d6de145b  vmovaps [rsp+0x40], xmm4
00007fa9d6de1461  vmovaps [rsp+0x50], xmm5
00007fa9d6de1467  vmovaps [rsp+0x60], xmm6
00007fa9d6de146d  vmovaps [rsp+0x70], xmm7
00007fa9d6de1473  vmovaps [rsp+0x80], xmm8
00007fa9d6de147c  vmovaps [rsp+0x90], xmm10
00007fa9d6de1485  vmovaps [rsp+0xA0], xmm11
00007fa9d6de148e  vmovaps [rsp+0xB0], xmm12
00007fa9d6de1497  vmovaps [rsp+0xC0], xmm13
00007fa9d6de14a0  vmovaps [rsp+0xD0], xmm14
00007fa9d6de14a9  vmovaps [rsp+0xE0], xmm15
00007fa9d6de14b2  sub rsp, 0x30
00007fa9d6de14b6  movaps [rsp], xmm9
00007fa9d6de14bb  movaps [rsp+0x10], xmm13
00007fa9d6de14c1  movaps [rsp+0x20], xmm15
00007fa9d6de14c7  lea rdi, [rsp]
00007fa9d6de14cb  mov esi, 0x00
00007fa9d6de14d0  mov rax, 0x61DF872DB530
00007fa9d6de14da  call rax
00007fa9d6de14dc  movaps xmm9, [rsp]
00007fa9d6de14e1  add rsp, 0x30
00007fa9d6de14e5  vmovaps xmm0, [rsp]
00007fa9d6de14ea  vmovaps xmm1, [rsp+0x10]
00007fa9d6de14f0  vmovaps xmm2, [rsp+0x20]
00007fa9d6de14f6  vmovaps xmm3, [rsp+0x30]
00007fa9d6de14fc  vmovaps xmm4, [rsp+0x40]
00007fa9d6de1502  vmovaps xmm5, [rsp+0x50]
00007fa9d6de1508  vmovaps xmm6, [rsp+0x60]
00007fa9d6de150e  vmovaps xmm7, [rsp+0x70]
00007fa9d6de1514  vmovaps xmm8, [rsp+0x80]
00007fa9d6de151d  vmovaps xmm10, [rsp+0x90]
00007fa9d6de1526  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de152f  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de1538  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de1541  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de154a  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de1553  add rsp, 0xF0
00007fa9d6de155a  pop r11
00007fa9d6de155c  pop r10
00007fa9d6de155e  pop r9
00007fa9d6de1560  pop r8
00007fa9d6de1562  pop rsi
00007fa9d6de1563  pop rdi
00007fa9d6de1564  pop rdx
00007fa9d6de1565  pop rcx
00007fa9d6de1566  pop rax
00007fa9d6de1567  add rsp, 0x08
00007fa9d6de156b  jmp 0x00007FA9D6DDC7E2
00007fa9d6de1570  sub rsp, 0x08
00007fa9d6de1574  push rax
00007fa9d6de1575  push rcx
00007fa9d6de1576  push rdx
00007fa9d6de1577  push rdi
00007fa9d6de1578  push rsi
00007fa9d6de1579  push r8
00007fa9d6de157b  push r9
00007fa9d6de157d  push r10
00007fa9d6de157f  push r11
00007fa9d6de1581  sub rsp, 0xF0
00007fa9d6de1588  vmovaps [rsp], xmm0
00007fa9d6de158d  vmovaps [rsp+0x10], xmm1
00007fa9d6de1593  vmovaps [rsp+0x20], xmm2
00007fa9d6de1599  vmovaps [rsp+0x30], xmm3
00007fa9d6de159f  vmovaps [rsp+0x40], xmm4
00007fa9d6de15a5  vmovaps [rsp+0x50], xmm5
00007fa9d6de15ab  vmovaps [rsp+0x60], xmm6
00007fa9d6de15b1  vmovaps [rsp+0x70], xmm7
00007fa9d6de15b7  vmovaps [rsp+0x80], xmm8
00007fa9d6de15c0  vmovaps [rsp+0x90], xmm9
00007fa9d6de15c9  vmovaps [rsp+0xA0], xmm10
00007fa9d6de15d2  vmovaps [rsp+0xB0], xmm11
00007fa9d6de15db  vmovaps [rsp+0xC0], xmm12
00007fa9d6de15e4  vmovaps [rsp+0xD0], xmm13
00007fa9d6de15ed  vmovaps [rsp+0xE0], xmm14
00007fa9d6de15f6  sub rsp, 0x30
00007fa9d6de15fa  movaps [rsp], xmm15
00007fa9d6de15ff  movaps [rsp+0x10], xmm11
00007fa9d6de1605  movaps [rsp+0x20], xmm12
00007fa9d6de160b  lea rdi, [rsp]
00007fa9d6de160f  mov esi, 0x00
00007fa9d6de1614  mov rax, 0x61DF872DB530
00007fa9d6de161e  call rax
00007fa9d6de1620  movaps xmm15, [rsp]
00007fa9d6de1625  add rsp, 0x30
00007fa9d6de1629  vmovaps xmm0, [rsp]
00007fa9d6de162e  vmovaps xmm1, [rsp+0x10]
00007fa9d6de1634  vmovaps xmm2, [rsp+0x20]
00007fa9d6de163a  vmovaps xmm3, [rsp+0x30]
00007fa9d6de1640  vmovaps xmm4, [rsp+0x40]
00007fa9d6de1646  vmovaps xmm5, [rsp+0x50]
00007fa9d6de164c  vmovaps xmm6, [rsp+0x60]
00007fa9d6de1652  vmovaps xmm7, [rsp+0x70]
00007fa9d6de1658  vmovaps xmm8, [rsp+0x80]
00007fa9d6de1661  vmovaps xmm9, [rsp+0x90]
00007fa9d6de166a  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de1673  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de167c  vmovaps xmm12, [rsp+0xC0]
00007fa9d6de1685  vmovaps xmm13, [rsp+0xD0]
00007fa9d6de168e  vmovaps xmm14, [rsp+0xE0]
00007fa9d6de1697  add rsp, 0xF0
00007fa9d6de169e  pop r11
00007fa9d6de16a0  pop r10
00007fa9d6de16a2  pop r9
00007fa9d6de16a4  pop r8
00007fa9d6de16a6  pop rsi
00007fa9d6de16a7  pop rdi
00007fa9d6de16a8  pop rdx
00007fa9d6de16a9  pop rcx
00007fa9d6de16aa  pop rax
00007fa9d6de16ab  add rsp, 0x08
00007fa9d6de16af  jmp 0x00007FA9D6DDC7FD
00007fa9d6de16b4  sub rsp, 0x08
00007fa9d6de16b8  push rax
00007fa9d6de16b9  push rcx
00007fa9d6de16ba  push rdx
00007fa9d6de16bb  push rdi
00007fa9d6de16bc  push rsi
00007fa9d6de16bd  push r8
00007fa9d6de16bf  push r9
00007fa9d6de16c1  push r10
00007fa9d6de16c3  push r11
00007fa9d6de16c5  sub rsp, 0xF0
00007fa9d6de16cc  vmovaps [rsp], xmm0
00007fa9d6de16d1  vmovaps [rsp+0x10], xmm1
00007fa9d6de16d7  vmovaps [rsp+0x20], xmm2
00007fa9d6de16dd  vmovaps [rsp+0x30], xmm3
00007fa9d6de16e3  vmovaps [rsp+0x40], xmm4
00007fa9d6de16e9  vmovaps [rsp+0x50], xmm5
00007fa9d6de16ef  vmovaps [rsp+0x60], xmm6
00007fa9d6de16f5  vmovaps [rsp+0x70], xmm7
00007fa9d6de16fb  vmovaps [rsp+0x80], xmm8
00007fa9d6de1704  vmovaps [rsp+0x90], xmm9
00007fa9d6de170d  vmovaps [rsp+0xA0], xmm10
00007fa9d6de1716  vmovaps [rsp+0xB0], xmm11
00007fa9d6de171f  vmovaps [rsp+0xC0], xmm12
00007fa9d6de1728  vmovaps [rsp+0xD0], xmm14
00007fa9d6de1731  vmovaps [rsp+0xE0], xmm15
00007fa9d6de173a  sub rsp, 0x30
00007fa9d6de173e  movaps [rsp], xmm13
00007fa9d6de1743  movaps [rsp+0x10], xmm10
00007fa9d6de1749  movaps [rsp+0x20], xmm14
00007fa9d6de174f  lea rdi, [rsp]
00007fa9d6de1753  mov esi, 0x00
00007fa9d6de1758  mov rax, 0x61DF872DB530
00007fa9d6de1762  call rax
00007fa9d6de1764  movaps xmm13, [rsp]
00007fa9d6de1769  add rsp, 0x30
00007fa9d6de176d  vmovaps xmm0, [rsp]
00007fa9d6de1772  vmovaps xmm1, [rsp+0x10]
00007fa9d6de1778  vmovaps xmm2, [rsp+0x20]
00007fa9d6de177e  vmovaps xmm3, [rsp+0x30]
00007fa9d6de1784  vmovaps xmm4, [rsp+0x40]
00007fa9d6de178a  vmovaps xmm5, [rsp+0x50]
00007fa9d6de1790  vmovaps xmm6, [rsp+0x60]
00007fa9d6de1796  vmovaps xmm7, [rsp+0x70]
00007fa9d6de179c  vmovaps xmm8, [rsp+0x80]
00007fa9d6de17a5  vmovaps xmm9, [rsp+0x90]
00007fa9d6de17ae  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de17b7  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de17c0  vmovaps xmm12, [rsp+0xC0]
00007fa9d6de17c9  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de17d2  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de17db  add rsp, 0xF0
00007fa9d6de17e2  pop r11
00007fa9d6de17e4  pop r10
00007fa9d6de17e6  pop r9
00007fa9d6de17e8  pop r8
00007fa9d6de17ea  pop rsi
00007fa9d6de17eb  pop rdi
00007fa9d6de17ec  pop rdx
00007fa9d6de17ed  pop rcx
00007fa9d6de17ee  pop rax
00007fa9d6de17ef  add rsp, 0x08
00007fa9d6de17f3  jmp 0x00007FA9D6DDC820
00007fa9d6de17f8  sub rsp, 0x08
00007fa9d6de17fc  push rax
00007fa9d6de17fd  push rcx
00007fa9d6de17fe  push rdx
00007fa9d6de17ff  push rdi
00007fa9d6de1800  push rsi
00007fa9d6de1801  push r8
00007fa9d6de1803  push r9
00007fa9d6de1805  push r10
00007fa9d6de1807  push r11
00007fa9d6de1809  sub rsp, 0xF0
00007fa9d6de1810  vmovaps [rsp], xmm0
00007fa9d6de1815  vmovaps [rsp+0x10], xmm1
00007fa9d6de181b  vmovaps [rsp+0x20], xmm2
00007fa9d6de1821  vmovaps [rsp+0x30], xmm3
00007fa9d6de1827  vmovaps [rsp+0x40], xmm4
00007fa9d6de182d  vmovaps [rsp+0x50], xmm5
00007fa9d6de1833  vmovaps [rsp+0x60], xmm6
00007fa9d6de1839  vmovaps [rsp+0x70], xmm7
00007fa9d6de183f  vmovaps [rsp+0x80], xmm8
00007fa9d6de1848  vmovaps [rsp+0x90], xmm9
00007fa9d6de1851  vmovaps [rsp+0xA0], xmm10
00007fa9d6de185a  vmovaps [rsp+0xB0], xmm11
00007fa9d6de1863  vmovaps [rsp+0xC0], xmm12
00007fa9d6de186c  vmovaps [rsp+0xD0], xmm13
00007fa9d6de1875  vmovaps [rsp+0xE0], xmm15
00007fa9d6de187e  sub rsp, 0x30
00007fa9d6de1882  movaps [rsp], xmm14
00007fa9d6de1887  movaps [rsp+0x10], xmm1
00007fa9d6de188c  movaps [rsp+0x20], xmm7
00007fa9d6de1891  lea rdi, [rsp]
00007fa9d6de1895  mov esi, 0x00
00007fa9d6de189a  mov rax, 0x61DF872DB530
00007fa9d6de18a4  call rax
00007fa9d6de18a6  movaps xmm14, [rsp]
00007fa9d6de18ab  add rsp, 0x30
00007fa9d6de18af  vmovaps xmm0, [rsp]
00007fa9d6de18b4  vmovaps xmm1, [rsp+0x10]
00007fa9d6de18ba  vmovaps xmm2, [rsp+0x20]
00007fa9d6de18c0  vmovaps xmm3, [rsp+0x30]
00007fa9d6de18c6  vmovaps xmm4, [rsp+0x40]
00007fa9d6de18cc  vmovaps xmm5, [rsp+0x50]
00007fa9d6de18d2  vmovaps xmm6, [rsp+0x60]
00007fa9d6de18d8  vmovaps xmm7, [rsp+0x70]
00007fa9d6de18de  vmovaps xmm8, [rsp+0x80]
00007fa9d6de18e7  vmovaps xmm9, [rsp+0x90]
00007fa9d6de18f0  vmovaps xmm10, [rsp+0xA0]
00007fa9d6de18f9  vmovaps xmm11, [rsp+0xB0]
00007fa9d6de1902  vmovaps xmm12, [rsp+0xC0]
00007fa9d6de190b  vmovaps xmm13, [rsp+0xD0]
00007fa9d6de1914  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de191d  add rsp, 0xF0
00007fa9d6de1924  pop r11
00007fa9d6de1926  pop r10
00007fa9d6de1928  pop r9
00007fa9d6de192a  pop r8
00007fa9d6de192c  pop rsi
00007fa9d6de192d  pop rdi
00007fa9d6de192e  pop rdx
00007fa9d6de192f  pop rcx
00007fa9d6de1930  pop rax
00007fa9d6de1931  add rsp, 0x08
00007fa9d6de1935  jmp 0x00007FA9D6DDC843
00007fa9d6de193a  sub rsp, 0x08
00007fa9d6de193e  push rax
00007fa9d6de193f  push rcx
00007fa9d6de1940  push rdx
00007fa9d6de1941  push rdi
00007fa9d6de1942  push rsi
00007fa9d6de1943  push r8
00007fa9d6de1945  push r9
00007fa9d6de1947  push r10
00007fa9d6de1949  push r11
00007fa9d6de194b  sub rsp, 0xF0
00007fa9d6de1952  vmovaps [rsp], xmm0
00007fa9d6de1957  vmovaps [rsp+0x10], xmm2
00007fa9d6de195d  vmovaps [rsp+0x20], xmm3
00007fa9d6de1963  vmovaps [rsp+0x30], xmm4
00007fa9d6de1969  vmovaps [rsp+0x40], xmm5
00007fa9d6de196f  vmovaps [rsp+0x50], xmm6
00007fa9d6de1975  vmovaps [rsp+0x60], xmm7
00007fa9d6de197b  vmovaps [rsp+0x70], xmm8
00007fa9d6de1981  vmovaps [rsp+0x80], xmm9
00007fa9d6de198a  vmovaps [rsp+0x90], xmm10
00007fa9d6de1993  vmovaps [rsp+0xA0], xmm11
00007fa9d6de199c  vmovaps [rsp+0xB0], xmm12
00007fa9d6de19a5  vmovaps [rsp+0xC0], xmm13
00007fa9d6de19ae  vmovaps [rsp+0xD0], xmm14
00007fa9d6de19b7  vmovaps [rsp+0xE0], xmm15
00007fa9d6de19c0  sub rsp, 0x30
00007fa9d6de19c4  movaps [rsp], xmm1
00007fa9d6de19c8  movaps [rsp+0x10], xmm8
00007fa9d6de19ce  movaps [rsp+0x20], xmm9
00007fa9d6de19d4  lea rdi, [rsp]
00007fa9d6de19d8  mov esi, 0x00
00007fa9d6de19dd  mov rax, 0x61DF872DB530
00007fa9d6de19e7  call rax
00007fa9d6de19e9  movaps xmm1, [rsp]
00007fa9d6de19ed  add rsp, 0x30
00007fa9d6de19f1  vmovaps xmm0, [rsp]
00007fa9d6de19f6  vmovaps xmm2, [rsp+0x10]
00007fa9d6de19fc  vmovaps xmm3, [rsp+0x20]
00007fa9d6de1a02  vmovaps xmm4, [rsp+0x30]
00007fa9d6de1a08  vmovaps xmm5, [rsp+0x40]
00007fa9d6de1a0e  vmovaps xmm6, [rsp+0x50]
00007fa9d6de1a14  vmovaps xmm7, [rsp+0x60]
00007fa9d6de1a1a  vmovaps xmm8, [rsp+0x70]
00007fa9d6de1a20  vmovaps xmm9, [rsp+0x80]
00007fa9d6de1a29  vmovaps xmm10, [rsp+0x90]
00007fa9d6de1a32  vmovaps xmm11, [rsp+0xA0]
00007fa9d6de1a3b  vmovaps xmm12, [rsp+0xB0]
00007fa9d6de1a44  vmovaps xmm13, [rsp+0xC0]
00007fa9d6de1a4d  vmovaps xmm14, [rsp+0xD0]
00007fa9d6de1a56  vmovaps xmm15, [rsp+0xE0]
00007fa9d6de1a5f  add rsp, 0xF0
00007fa9d6de1a66  pop r11
00007fa9d6de1a68  pop r10
00007fa9d6de1a6a  pop r9
00007fa9d6de1a6c  pop r8
00007fa9d6de1a6e  pop rsi
00007fa9d6de1a6f  pop rdi
00007fa9d6de1a70  pop rdx
00007fa9d6de1a71  pop rcx
00007fa9d6de1a72  pop rax
00007fa9d6de1a73  add rsp, 0x08
00007fa9d6de1a77  jmp 0x00007FA9D6DDC865
00007fa9d6de1a7c  call 0x00007FA9D6CE5940
00007fa9d6de1a81  jmp 0x00007FA9D6DDC873
00007fa9d6de1a86  call 0x00007FA9D6C0C380
00007fa9d6de1a8b  jmp 0x00007FA9D6DDC87D
00007fa9d6de1a90  call 0x00007FA9D6C0D600
00007fa9d6de1a95  jmp 0x00007FA9D6DDC887
00007fa9d6de1a9a  call 0x00007FA9D6BFF540
00007fa9d6de1a9f  jmp 0x00007FA9D6DDC891
00007fa9d6de1aa4  int3
00007fa9d6de1aa5  nop [rax+rax*1], ax
00007fa9d6de1aae  nop
00007fa9d6de1ab0  mov rax, [r15+0xF8]
00007fa9d6de1ab7  lea r14, [rax+0x140]
00007fa9d6de1abe  mov r12, [r13+r14*1]
00007fa9d6de1ac3  mov [r15+0xE8], r12
00007fa9d6de1aca  lea r14, [rax+0x130]
00007fa9d6de1ad1  mov r12, [r13+r14*1]
00007fa9d6de1ad6  lea r14, [rax+0x138]
00007fa9d6de1add  mov r11, [r13+r14*1]
00007fa9d6de1ae2  movq xmm1, r12
00007fa9d6de1ae7  movq xmm15, r11
00007fa9d6de1aec  movq xmm1, xmm1
00007fa9d6de1af0  movq xmm1, xmm1
00007fa9d6de1af4  movaps [r15+0x1A0], xmm1
00007fa9d6de1afc  movq xmm15, xmm15
00007fa9d6de1b01  movq xmm15, xmm15
00007fa9d6de1b06  movaps [r15+0x190], xmm15
00007fa9d6de1b0e  lea r14, [rax+0x120]
00007fa9d6de1b15  mov r12, [r13+r14*1]
00007fa9d6de1b1a  lea r14, [rax+0x128]
00007fa9d6de1b21  mov r11, [r13+r14*1]
00007fa9d6de1b26  movq xmm1, r12
00007fa9d6de1b2b  movq xmm15, r11
00007fa9d6de1b30  movq xmm1, xmm1
00007fa9d6de1b34  movq xmm1, xmm1
00007fa9d6de1b38  movaps [r15+0x1C0], xmm1
00007fa9d6de1b40  movq xmm15, xmm15
00007fa9d6de1b45  movq xmm15, xmm15
00007fa9d6de1b4a  movaps [r15+0x1B0], xmm15
00007fa9d6de1b52  lea r14, [rax+0x110]
00007fa9d6de1b59  mov r12, [r13+r14*1]
00007fa9d6de1b5e  lea r14, [rax+0x118]
00007fa9d6de1b65  mov r11, [r13+r14*1]
00007fa9d6de1b6a  movq xmm1, r12
00007fa9d6de1b6f  movq xmm15, r11
00007fa9d6de1b74  movq xmm1, xmm1
00007fa9d6de1b78  movq xmm1, xmm1
00007fa9d6de1b7c  movaps [r15+0x1E0], xmm1
00007fa9d6de1b84  movq xmm15, xmm15
00007fa9d6de1b89  movq xmm15, xmm15
00007fa9d6de1b8e  movaps [r15+0x1D0], xmm15
00007fa9d6de1b96  lea r14, [rax+0x100]
00007fa9d6de1b9d  mov r12, [r13+r14*1]
00007fa9d6de1ba2  lea r14, [rax+0x108]
00007fa9d6de1ba9  mov r11, [r13+r14*1]
00007fa9d6de1bae  movq xmm1, r12
00007fa9d6de1bb3  movq xmm15, r11
00007fa9d6de1bb8  movq xmm1, xmm1
00007fa9d6de1bbc  movq xmm1, xmm1
00007fa9d6de1bc0  movaps [r15+0x200], xmm1
00007fa9d6de1bc8  movq xmm15, xmm15
00007fa9d6de1bcd  movq xmm15, xmm15
00007fa9d6de1bd2  movaps [r15+0x1F0], xmm15
00007fa9d6de1bda  mov qword ptr [r15+0x40], 0x430000
00007fa9d6de1be2  mov r14d, 0x430510
00007fa9d6de1be8  mov r12, [r13+r14*1]
00007fa9d6de1bed  movq xmm1, r12
00007fa9d6de1bf2  lea r14, [rax+0x150]
00007fa9d6de1bf9  mov [r15+0xF8], r14
00007fa9d6de1c00  mov rax, [r15+0x50]
00007fa9d6de1c04  movups xmm15, [r13+rax*1]
00007fa9d6de1c0a  movaps [r15+0x120], xmm15
00007fa9d6de1c12  mov qword ptr [r15+0x48], 0x10
00007fa9d6de1c1a  xor eax, eax
00007fa9d6de1c1c  mov r14d, 0x10
00007fa9d6de1c22  mov r12d, 0x200
00007fa9d6de1c28  cmp r14, r12
00007fa9d6de1c2b  cmc
00007fa9d6de1c2c  lahf
00007fa9d6de1c2d  seto al
00007fa9d6de1c30  mov [r15+0x108], eax
00007fa9d6de1c37  pextrq rax, xmm15, 0x01
00007fa9d6de1c3e  movq xmm14, rax
00007fa9d6de1c43  movaps [r15+0x130], xmm14
00007fa9d6de1c4b  movq rax, xmm1
00007fa9d6de1c50  movq r14, xmm15
00007fa9d6de1c55  vmovq xmm1, rax
00007fa9d6de1c5a  vmovq xmm15, r14
00007fa9d6de1c5f  movaps xmm13, xmm1
00007fa9d6de1c63  addsd xmm13, xmm15
00007fa9d6de1c68  ucomisd xmm13, xmm13
00007fa9d6de1c6d  jp 0x00007FA9D6DE1D86
00007fa9d6de1c73  movq xmm13, xmm13
00007fa9d6de1c78  movq rax, xmm13
00007fa9d6de1c7d  movq r14, xmm14
00007fa9d6de1c82  vmovq xmm1, rax
00007fa9d6de1c87  vmovq xmm15, r14
00007fa9d6de1c8c  movaps xmm14, xmm1
00007fa9d6de1c90  addsd xmm14, xmm15
00007fa9d6de1c95  ucomisd xmm14, xmm14
00007fa9d6de1c9a  jp 0x00007FA9D6DE1DCE
00007fa9d6de1ca0  movq xmm14, xmm14
00007fa9d6de1ca5  movaps [r15+0x110], xmm14
00007fa9d6de1cad  mov eax, [r15+0x108]
00007fa9d6de1cb4  sahf
00007fa9d6de1cb5  jnz 0x00007FA9D6DE1CE7
00007fa9d6de1cb7  cmp dword ptr [r15+0x318], 0x00
00007fa9d6de1cbf  jz 0x00007FA9D6DE1FE0
00007fa9d6de1cc5  nop [rax+rax*1], ax
00007fa9d6de1cce  nop [rax+rax*1], eax
00007fa9d6de1cd6  mov eax, 0x410490
00007fa9d6de1cdb  mov [r15+0x100], rax
00007fa9d6de1ce2  jmp 0x00007FA9D6BFE110
00007fa9d6de1ce7  cmp dword ptr [r15+0x318], 0x00
00007fa9d6de1cef  jz 0x00007FA9D6DE1E20
00007fa9d6de1cf5  nop [rax+rax*1], ax
00007fa9d6de1cfe  nop [rax+rax*1], eax
00007fa9d6de1d06  mov eax, 0x410474
00007fa9d6de1d0b  mov [r15+0x100], rax
00007fa9d6de1d12  jmp 0x00007FA9D6BFE110
00007fa9d6de1d17  int3
00007fa9d6de1d18  call 0x00007FA9D6CE27E0
00007fa9d6de1d1d  jmp 0x00007FA9D6DE1AC3
00007fa9d6de1d22  call 0x00007FA9D6CE27E0
00007fa9d6de1d27  jmp 0x00007FA9D6DE1AD6
00007fa9d6de1d2c  call 0x00007FA9D6CE1570
00007fa9d6de1d31  jmp 0x00007FA9D6DE1AE2
00007fa9d6de1d36  call 0x00007FA9D6CE27E0
00007fa9d6de1d3b  jmp 0x00007FA9D6DE1B1A
00007fa9d6de1d40  call 0x00007FA9D6CE1570
00007fa9d6de1d45  jmp 0x00007FA9D6DE1B26
00007fa9d6de1d4a  call 0x00007FA9D6CE27E0
00007fa9d6de1d4f  jmp 0x00007FA9D6DE1B5E
00007fa9d6de1d54  call 0x00007FA9D6CE1570
00007fa9d6de1d59  jmp 0x00007FA9D6DE1B6A
00007fa9d6de1d5e  call 0x00007FA9D6CE27E0
00007fa9d6de1d63  jmp 0x00007FA9D6DE1BA2
00007fa9d6de1d68  call 0x00007FA9D6CE1570
00007fa9d6de1d6d  jmp 0x00007FA9D6DE1BAE
00007fa9d6de1d72  call 0x00007FA9D6CE27E0
00007fa9d6de1d77  jmp 0x00007FA9D6DE1BED
00007fa9d6de1d7c  call 0x00007FA9D6C0E760
00007fa9d6de1d81  jmp 0x00007FA9D6DE1C0A
00007fa9d6de1d86  ucomisd xmm1, xmm15
00007fa9d6de1d8b  jp 0x00007FA9D6DE1D9A
00007fa9d6de1d8d  movaps xmm13, [0x00007FA9D69FE060]
00007fa9d6de1d95  jmp 0x00007FA9D6DE1C73
00007fa9d6de1d9a  vxorps xmm0, xmm1, xmm15
00007fa9d6de1d9f  pextrw eax, xmm0, 0x03
00007fa9d6de1da4  and eax, 0x7FF8
00007fa9d6de1da9  cmp eax, 0x08
00007fa9d6de1dac  jnz 0x00007FA9D6DE1C73
00007fa9d6de1db2  movq rax, xmm15
00007fa9d6de1db7  shl rax, 0x0D
00007fa9d6de1dbb  jbe 0x00007FA9D6DE1C73
00007fa9d6de1dc1  vorps xmm13, xmm15, [0x00007FA9D69FE070]
00007fa9d6de1dc9  jmp 0x00007FA9D6DE1C73
00007fa9d6de1dce  ucomisd xmm1, xmm15
00007fa9d6de1dd3  jp 0x00007FA9D6DE1DE2
00007fa9d6de1dd5  movaps xmm14, [0x00007FA9D69FE060]
00007fa9d6de1ddd  jmp 0x00007FA9D6DE1CA0
00007fa9d6de1de2  vxorps xmm0, xmm1, xmm15
00007fa9d6de1de7  pextrw eax, xmm0, 0x03
00007fa9d6de1dec  and eax, 0x7FF8
00007fa9d6de1df1  cmp eax, 0x08
00007fa9d6de1df4  jnz 0x00007FA9D6DE1CA0
00007fa9d6de1dfa  movq rax, xmm15
00007fa9d6de1dff  shl rax, 0x0D
00007fa9d6de1e03  jbe 0x00007FA9D6DE1CA0
00007fa9d6de1e09  vorps xmm14, xmm15, [0x00007FA9D69FE070]
00007fa9d6de1e11  jmp 0x00007FA9D6DE1CA0
00007fa9d6de1e16  int3
00007fa9d6de1e17  nop [rax+rax*1], ax
00007fa9d6de1e20  mov rax, [r15+0x48]
00007fa9d6de1e24  mov r14, [r15+0x50]
00007fa9d6de1e28  lea r12, [r14+rax*1]
00007fa9d6de1e2c  movups xmm1, [r13+r12*1]
00007fa9d6de1e32  movaps [r15+0x120], xmm1
00007fa9d6de1e3a  lea r14, [rax+0x10]
00007fa9d6de1e3e  mov [r15+0x48], r14
00007fa9d6de1e42  xor eax, eax
00007fa9d6de1e44  mov r12d, 0x200
00007fa9d6de1e4a  cmp r14, r12
00007fa9d6de1e4d  cmc
00007fa9d6de1e4e  lahf
00007fa9d6de1e4f  seto al
00007fa9d6de1e52  mov [r15+0x108], eax
00007fa9d6de1e59  pextrq rax, xmm1, 0x01
00007fa9d6de1e60  movq xmm15, rax
00007fa9d6de1e65  movaps [r15+0x130], xmm15
00007fa9d6de1e6d  movaps xmm14, [r15+0x110]
00007fa9d6de1e75  movq rax, xmm14
00007fa9d6de1e7a  movq r14, xmm1
00007fa9d6de1e7f  vmovq xmm1, rax
00007fa9d6de1e84  vmovq xmm14, r14
00007fa9d6de1e89  movaps xmm13, xmm1
00007fa9d6de1e8d  addsd xmm13, xmm14
00007fa9d6de1e92  ucomisd xmm13, xmm13
00007fa9d6de1e97  jp 0x00007FA9D6DE1F4C
00007fa9d6de1e9d  movq xmm13, xmm13
00007fa9d6de1ea2  movq rax, xmm13
00007fa9d6de1ea7  movq r14, xmm15
00007fa9d6de1eac  vmovq xmm1, rax
00007fa9d6de1eb1  vmovq xmm15, r14
00007fa9d6de1eb6  movaps xmm14, xmm1
00007fa9d6de1eba  addsd xmm14, xmm15
00007fa9d6de1ebf  ucomisd xmm14, xmm14
00007fa9d6de1ec4  jp 0x00007FA9D6DE1F94
00007fa9d6de1eca  movq xmm14, xmm14
00007fa9d6de1ecf  movaps [r15+0x110], xmm14
00007fa9d6de1ed7  mov eax, [r15+0x108]
00007fa9d6de1ede  sahf
00007fa9d6de1edf  jnz 0x00007FA9D6DE1F11
00007fa9d6de1ee1  cmp dword ptr [r15+0x318], 0x00
00007fa9d6de1ee9  jz 0x00007FA9D6DE1FE0
00007fa9d6de1eef  nop [rax+rax*1], ax
00007fa9d6de1ef8  nop [rax+rax*1], eax
00007fa9d6de1f00  mov eax, 0x410490
00007fa9d6de1f05  mov [r15+0x100], rax
00007fa9d6de1f0c  jmp 0x00007FA9D6BFE110
00007fa9d6de1f11  cmp dword ptr [r15+0x318], 0x00
00007fa9d6de1f19  jz 0x00007FA9D6DE1E20
00007fa9d6de1f1f  nop [rax+rax*1], ax
00007fa9d6de1f28  nop [rax+rax*1], eax
00007fa9d6de1f30  mov eax, 0x410474
00007fa9d6de1f35  mov [r15+0x100], rax
00007fa9d6de1f3c  jmp 0x00007FA9D6BFE110
00007fa9d6de1f41  int3
00007fa9d6de1f42  call 0x00007FA9D6CB52F0
00007fa9d6de1f47  jmp 0x00007FA9D6DE1E32
00007fa9d6de1f4c  ucomisd xmm1, xmm14
00007fa9d6de1f51  jp 0x00007FA9D6DE1F60
00007fa9d6de1f53  movaps xmm13, [0x00007FA9D69FE060]
00007fa9d6de1f5b  jmp 0x00007FA9D6DE1E9D
00007fa9d6de1f60  vxorps xmm0, xmm1, xmm14
00007fa9d6de1f65  pextrw eax, xmm0, 0x03
00007fa9d6de1f6a  and eax, 0x7FF8
00007fa9d6de1f6f  cmp eax, 0x08
00007fa9d6de1f72  jnz 0x00007FA9D6DE1E9D
00007fa9d6de1f78  movq rax, xmm14
00007fa9d6de1f7d  shl rax, 0x0D
00007fa9d6de1f81  jbe 0x00007FA9D6DE1E9D
00007fa9d6de1f87  vorps xmm13, xmm14, [0x00007FA9D69FE070]
00007fa9d6de1f8f  jmp 0x00007FA9D6DE1E9D
00007fa9d6de1f94  ucomisd xmm1, xmm15
00007fa9d6de1f99  jp 0x00007FA9D6DE1FA8
00007fa9d6de1f9b  movaps xmm14, [0x00007FA9D69FE060]
00007fa9d6de1fa3  jmp 0x00007FA9D6DE1ECA
00007fa9d6de1fa8  vxorps xmm0, xmm1, xmm15
00007fa9d6de1fad  pextrw eax, xmm0, 0x03
00007fa9d6de1fb2  and eax, 0x7FF8
00007fa9d6de1fb7  cmp eax, 0x08
00007fa9d6de1fba  jnz 0x00007FA9D6DE1ECA
00007fa9d6de1fc0  movq rax, xmm15
00007fa9d6de1fc5  shl rax, 0x0D
00007fa9d6de1fc9  jbe 0x00007FA9D6DE1ECA
00007fa9d6de1fcf  vorps xmm14, xmm15, [0x00007FA9D69FE070]
00007fa9d6de1fd7  jmp 0x00007FA9D6DE1ECA
00007fa9d6de1fdc  int3
00007fa9d6de1fdd  nop [rax], eax
00007fa9d6de1fe0  mov rax, [r15+0x40]
00007fa9d6de1fe4  lea r14, [rax+0x510]
00007fa9d6de1feb  movaps xmm1, [r15+0x110]
00007fa9d6de1ff3  movq rax, xmm1
00007fa9d6de1ff8  mov [r13+r14*1], rax
00007fa9d6de1ffd  mov rax, [r15+0xF0]
00007fa9d6de2004  mov [r15+0x100], rax
00007fa9d6de200b  jmp 0x00007FA9D6DCE5C0
00007fa9d6de2010  int3
00007fa9d6de2011  call 0x00007FA9D6CD5EB0
00007fa9d6de2016  jmp 0x00007FA9D6DE1FFD
00007fa9d6de201b  int3
00007fa9d6de201c  nop [rax], eax
00007fa9d6de2020  mov qword ptr [r15+0x100], 0x04
00007fa9d6de202b  mov esi, 0x00
00007fa9d6de2030  mov edx, 0x09
00007fa9d6de2035  mov rdi, 0x7FFEACFB1770
00007fa9d6de203f  mov rax, 0x61DF8716E970
00007fa9d6de2049  call rax
00007fa9d6de204b  cmp dword ptr [r15+0x318], 0x00
00007fa9d6de2053  jnz 0x00007FA9D6BFE110
00007fa9d6de2059  jmp 0x00007FA9D6BFE0A0
00007fa9d6de205e  int3
00007fa9d6de205f  int3
